import json,sys,tempfile,hashlib
from pathlib import Path
sys.path.insert(0,str(Path('selfhost/tests').resolve()))
import run_body_check_qualification as D
F=D.F
cache=Path('/home/epentland/ai/canopy/.selka-agent-cache/loops'); host=cache/'nested-gather-native-prefix/bin/mylang';components=cache/'comprehension-installed-direct';fixtures=Path('selfhost/tests/fixtures/body_text_methods_candidate').resolve()
report={'complete':False,'scope':'native check-only fixture selection, not producer admission','compiler_sha256':F.digest(host),'packages':D.packages(components,body_schema=10),'records':[]};out=cache/'text-methods-native-selection.json'
with tempfile.TemporaryDirectory(dir=cache/'tmp',prefix='text-methods-native-') as name:
 work=Path(name);empty=work/'empty';empty.mkdir();entry=work/'main.my'
 for source in sorted(fixtures.glob('*.input')):
  entry.write_bytes(source.read_bytes());argv=[host,'check-project',entry,'--no-cache','--diagnostics=json'];result=F.execute(argv,D.environment('reference',components,empty),work,120)
  report['records'].append({'name':source.with_suffix('.my').name,'source_sha256':F.digest(source),'status':result[0],'stdout_hex':result[1].hex(),'stderr_hex':result[2].hex()});out.write_text(json.dumps(report,indent=2)+'\n')
report.update(complete=True,operations=len(report['records']));out.write_text(json.dumps(report,indent=2)+'\n');print('native text methods:',len(report['records']),'checks')
