import sys,json,tempfile
from pathlib import Path
sys.path.insert(0,str(Path('selfhost/tests').resolve()))
import run_body_check_qualification as D
cache=Path('/home/epentland/ai/canopy/.selka-agent-cache/loops');original=Path('selfhost/components/parser_pilot/syntax_diagnostics.my').resolve();content=original.read_text();start=content.index('func utf8(');end=content.index('\n\n',start);snippet=content[start:end]
source=snippet+'\n\n\nfunc main() -> int:\n    if utf8("é") != b"\\xc3\\xa9":\n        return 1\n    return 7\n'
(cache/'actual-syntax-diagnostics-utf8.input').write_text(source)
print('preserved exact actual-source function:',original,D.F.digest(original),repr(snippet))
