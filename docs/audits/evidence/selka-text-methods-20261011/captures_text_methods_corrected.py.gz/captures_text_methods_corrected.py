import sys,shutil,json
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path('selfhost/tests').resolve()))
import run_body_check_qualification as D
cache=Path('/home/epentland/ai/canopy/.selka-agent-cache/loops');args=SimpleNamespace(zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'),component_dir=cache/'text-methods-installed')
host=cache/'text-methods-native-prefix/bin/mylang';base=D.packages;D.packages=lambda directory:base(directory,body_schema=10);records=[]
for name in ('decode_buffer','decode_utf8','split_text','encode_local','ranged_prefix_suffix'):
 work=cache/('capture-text-corrected-'+name);work.mkdir(exist_ok=True);empty=work/'empty';empty.mkdir(exist_ok=True);q=SimpleNamespace(work=work,source=work,empty_path=empty,compiler=host)
 shutil.copyfile('selfhost/tests/fixtures/body_text_methods_candidate/'+name+'.input',work/'main.my');private,real=D.private_fixture(args,q);result,request,reply=D.capture_exchange(args,q,private,real,'main.my')
 record={'name':name,'status':result[0],'stdout_hex':result[1].hex(),'stderr_hex':result[2].hex(),'request_bytes':len(request),'reply_bytes':len(reply),'request_sha256':D.F.hashlib.sha256(request).hexdigest(),'reply_sha256':D.F.hashlib.sha256(reply).hexdigest()};records.append(record);(cache/'captures-text-corrected.json').write_text(json.dumps(records,indent=2)+'\n');print(name,result[0],len(request),len(reply),flush=True)

assert len(records)==5 and all(r['status']==0 and not r['stdout_hex'] and not r['stderr_hex'] for r in records)
