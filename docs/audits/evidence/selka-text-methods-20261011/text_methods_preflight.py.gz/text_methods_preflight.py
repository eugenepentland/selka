import os,subprocess,hashlib
from pathlib import Path
seed=Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
assert hashlib.sha256(seed.read_bytes()).hexdigest()=='c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b'
files=[Path('selfhost/components/body_check')/name for name in ('engine.my','text_methods.my','text_methods_tests.my')]
for source in files:
 result=subprocess.run([seed,'fmt',source],capture_output=True)
 if result.returncode:print(result.stderr.decode(),flush=True);raise SystemExit(result.returncode)
 source.write_bytes(result.stdout)
 result=subprocess.run([seed,'fmt',source,'--check'])
 if result.returncode:raise SystemExit(result.returncode)
for command in ([seed,'check-project','selfhost/components/body_check/main.my','--no-cache'],[seed,'test',files[-1],'--no-cache'],[seed,'test',files[-1],'--no-cache','--release','--verify-facts']):
 env=os.environ.copy()
 if '--release' in command:env['MYL_CORE_LEAKCHECK']='1'
 result=subprocess.run(command,env=env)
 if result.returncode:raise SystemExit(result.returncode)
print('text methods: main check, three formats, 3 Debug + 3 release/facts/leak tests passed',flush=True)
