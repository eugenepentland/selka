import subprocess,sys
from pathlib import Path
cache=Path('/home/epentland/ai/canopy/.selka-agent-cache/loops')
root=Path('/home/epentland/.codex/worktrees/selka-chained-comparison/mylang')
prefix=cache/'text-methods-native-prefix'
for name in ('text_methods','comprehension','iteration'):
    cmd=[sys.executable,f'selfhost/tests/run_body_{name}_admission.py','--compiler',str(prefix/'bin/mylang'),'--zig','/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig','--component-dir',str(cache/'text-methods-installed'),'--builder',str(prefix/'tools/selka-components'),'--source-root',str(root),'--report',str(cache/f'{name}-text-corrected.json')]
    result=subprocess.run(cmd,cwd=root)
    if result.returncode:sys.exit(result.returncode)
result=subprocess.run([sys.executable,str(cache/'text_actual_utf8_qualify.py')],cwd=root)
sys.exit(result.returncode)
