import json,sys,tempfile,shutil,hashlib
from pathlib import Path
sys.path.insert(0,str(Path('selfhost/tests').resolve()))
import run_body_check_qualification as D
F=D.F
cache=Path('/home/epentland/ai/canopy/.selka-agent-cache/loops')
host=cache/'text-methods-native-prefix/bin/mylang'
components=cache/'text-methods-installed'
source=cache/'actual-syntax-diagnostics-utf8.input'
report={'complete':False,'scope':'exact unchanged actual syntax_diagnostics utf8 function, isolated main wrapper','source_sha256':F.digest(source),'compiler_sha256':F.digest(host),'packages':D.packages(components,body_schema=10),'records':[]}
output=cache/'text-actual-utf8-corrected.json'
def checkpoint():output.write_text(json.dumps(report,indent=2)+'\n')
checkpoint()
with tempfile.TemporaryDirectory(dir=cache/'tmp',prefix='actual-utf8-') as name:
 work=Path(name);empty=work/'empty';empty.mkdir();entry=work/'main.my';shutil.copyfile(source,entry)
 commands=[['check-project',entry,'--no-cache','--diagnostics=json'],['dump-typed',entry],['run-project',entry,'--no-cache','--release','--verify-facts','--print-result','--cache-dir',work/'guest-cache','--zig=/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig']]
 for phase,command in zip(('check','typed','runtime'),commands):
  native=None
  for mode in ('reference','shadow','component'):
   argv=[host,*command];result=F.execute(argv,dict(D.environment(mode,components,empty),MYL_CORE_LEAKCHECK='1'),work,600)
   report['records'].append({'phase':phase,'mode':mode,'command':list(map(str,argv)),'status':result[0],'stdout_hex':result[1].hex(),'stderr_hex':result[2].hex()});checkpoint()
   if mode=='reference':native=result
   assert result==native,(phase,mode,result)
   if phase=='check':assert result==(0,b'',b'')
   if phase=='typed':assert result[0]==0 and result[1] and not result[2]
   if phase=='runtime':assert result==(7,b'7\n',b'')
assert F.digest(host)==report['compiler_sha256'] and D.packages(components,body_schema=10)==report['packages']
report.update(complete=True,operations=9,failed=0,skipped=0);checkpoint();print('actual compiler utf8 function: 9 passed, 0 failed, 0 skipped')
