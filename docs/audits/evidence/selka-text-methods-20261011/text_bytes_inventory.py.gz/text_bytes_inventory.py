import json,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path('selfhost/tests').resolve()))
import run_body_check_qualification as D
F=D.F
cache=Path('/home/epentland/ai/canopy/.selka-agent-cache/loops')
host=cache/'nested-gather-native-prefix/bin/mylang'; components=cache/'comprehension-installed-direct'
cases={'encode':'return len("é".encode())','decode':'match b"abc".decode():\n        case Ok(text):\n            return len(text)\n        case Err(reason):\n            _ = reason\n            return 0','find':'return "abc".find("b")','rfind':'return b"abc".rfind(b"b", 0, 3)','strip':'return len(" abc ".strip())','split':'return len(b"a,b".split(b","))','replace':'return len("aba".replace("a", "z"))','hex':'return len(b"ab".hex())','upper':'return len("abc".upper())','startswith':'return int("abc".startswith("a"))','to_list':'return len(b"ab".to_list())','scalar_count':'return b"abc".scalar_count()'}
report={'complete':False,'compiler_sha256':F.digest(host),'packages':D.packages(components,body_schema=10),'records':[]}; out=cache/'text-bytes-inventory.json'
with tempfile.TemporaryDirectory(dir=cache/'tmp',prefix='text-bytes-inventory-') as name:
 work=Path(name);empty=work/'empty';empty.mkdir();entry=work/'main.my'
 for case,body in cases.items():
  source='func main() -> int:\n    '+body+'\n';entry.write_text(source)
  for mode in ('reference','component'):
   argv=[host,'check-project',entry,'--no-cache','--diagnostics=json'];result=F.execute(argv,D.environment(mode,components,empty),work,120)
   report['records'].append({'case':case,'mode':mode,'source':source,'status':result[0],'stdout_hex':result[1].hex(),'stderr_hex':result[2].hex()});out.write_text(json.dumps(report,indent=2)+'\n')
report.update(complete=True,operations=len(report['records']));out.write_text(json.dumps(report,indent=2)+'\n');print('text/bytes inventory:',len(report['records']),'checks')
