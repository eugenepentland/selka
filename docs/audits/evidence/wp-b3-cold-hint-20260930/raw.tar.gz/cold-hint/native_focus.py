from pathlib import Path
import importlib.util,json
root=Path.cwd();directory=root/'.tmp/cold-hint/native';directory.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('suite',root/'scripts/test_native_memory.py');suite=importlib.util.module_from_spec(spec);spec.loader.exec_module(suite)
flags=['-O3','-std=c11','-Wall','-Wextra','-Werror','-UNDEBUG','-fsanitize=undefined','-ffunction-sections','-fdata-sections','-Wl,--gc-sections']
sources=dict(suite.SUITES)['native_rc_execution'];rows=[]
for side,compiler in [('clang',['zig','cc']),('gcc',['cc'])]:
 out=directory/side;out.mkdir(exist_ok=True)
 suite.run_suite(root,compiler+flags,out,'native_rc_execution',list(sources))
 rows.append({'compiler':compiler,'flags':flags,'suite':'native_rc_execution','modes':['success','trap','fast'],'actual_armed_longjmp_and_RC_traffic':True,'status':0})
(directory/'receipt.json').write_text(json.dumps({'admission':'serial entire runner through build-slot build','rows':rows},indent=2)+'\n')
print('Native execution: Clang and GCC each success/trap/fast, six actual modes passed with official RC-traffic checks')
