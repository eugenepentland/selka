
/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-cold-hint-20260930/.tmp/cold-hint/raytrace.qbe:     file format elf64-x86-64


Disassembly of section .text:

00000000010079a0 <_start>:
 10079a0:	endbr64
 10079a4:	xor    %ebp,%ebp
 10079a6:	mov    %rdx,%r9
 10079a9:	pop    %rsi
 10079aa:	mov    %rsp,%rdx
 10079ad:	and    $0xfffffffffffffff0,%rsp
 10079b1:	push   %rax
 10079b2:	push   %rsp
 10079b3:	xor    %r8d,%r8d
 10079b6:	xor    %ecx,%ecx
 10079b8:	lea    0x35d1(%rip),%rdi        # 100af90 <main>
 10079bf:	call   *0x21983(%rip)        # 1029348 <__libc_start_main@GLIBC_2.34>
 10079c5:	hlt
 10079c6:	cs nopw 0x0(%rax,%rax,1)

00000000010079d0 <_dl_relocate_static_pie>:
 10079d0:	endbr64
 10079d4:	ret
 10079d5:	int3
 10079d6:	int3
 10079d7:	int3
 10079d8:	int3
 10079d9:	int3
 10079da:	int3
 10079db:	int3
 10079dc:	int3
 10079dd:	int3
 10079de:	int3
 10079df:	int3

00000000010079e0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 10079e0:	endbr64
 10079e4:	push   %rbp
 10079e5:	mov    %rsp,%rbp
 10079e8:	sub    $0x448,%rsp
 10079ef:	push   %rbx
 10079f0:	push   %r12
 10079f2:	push   %r13
 10079f4:	push   %r14
 10079f6:	push   %r15
 10079f8:	mov    %rsi,-0x48(%rbp)
 10079fc:	mov    0x40(%rdi),%rax
 1007a00:	lea    -0x58(%rbp),%rcx
 1007a04:	cmp    %rax,%rcx
 1007a07:	setb   %al
 1007a0a:	movzbq %al,%rax
 1007a0e:	mov    $0x2,%ecx
 1007a13:	mov    %ecx,-0x24(%rbp)
 1007a16:	cmp    $0x10,%ecx
 1007a19:	sete   %dl
 1007a1c:	movzbl %dl,%edx
 1007a1f:	mov    %edx,-0x10(%rbp)
 1007a22:	mov    $0x0,%edx
 1007a27:	mov    %edx,-0x28(%rbp)
 1007a2a:	cmp    $0x0,%eax
 1007a2d:	jne    10099e7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2007>
 1007a33:	movq   $0x0,-0x370(%rbp)
 1007a3e:	movq   $0x0,-0x368(%rbp)
 1007a49:	mov    %rdi,%rbx
 1007a4c:	call   100b830 <myl_qbe_heap>
 1007a51:	mov    %rbx,%rdi
 1007a54:	mov    %rax,%rbx
 1007a57:	mov    %rbx,-0x50(%rbp)
 1007a5b:	mov    %rdi,%r12
 1007a5e:	call   100d750 <myl_qbe_region_mark>
 1007a63:	mov    %r12,%rdi
 1007a66:	mov    %rax,%r13
 1007a69:	movl   $0x0,-0x3f0(%rbp)
 1007a73:	mov    %rdi,%r12
 1007a76:	call   100b9d0 <myl_qbe_require_step_accounting>
 1007a7b:	mov    %r12,%rdi
 1007a7e:	mov    %rdi,%r12
 1007a81:	call   100ba20 <myl_qbe_require_frame_accounting>
 1007a86:	mov    %r12,%rdi
 1007a89:	mov    $0x6,%edx
 1007a8e:	lea    0x1ed9b(%rip),%rsi        # 1026830 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf>
 1007a95:	mov    %rdi,%r12
 1007a98:	mov    %rbx,%rdi
 1007a9b:	call   1011590 <myl_native_list_new>
 1007aa0:	mov    %r13,%rcx
 1007aa3:	mov    %r12,%rdi
 1007aa6:	cmp    $0x0,%eax
 1007aa9:	jne    1007ab5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd5>
 1007aab:	mov    %rdi,%rbx
 1007aae:	call   100b590 <myl_qbe_fail_allocation>
 1007ab3:	ud2
 1007ab5:	xchg   %rdi,%rbx
 1007ab8:	mov    %rax,-0x3b0(%rbp)
 1007abf:	mov    -0x3b0(%rbp),%rdx
 1007ac6:	mov    %rdx,-0x3a8(%rbp)
 1007acd:	mov    -0x3a8(%rbp),%rdx
 1007ad4:	mov    %rdx,-0x3e8(%rbp)
 1007adb:	mov    %rax,-0x3b0(%rbp)
 1007ae2:	lea    -0x3a8(%rbp),%rsi
 1007ae9:	lea    -0x3b0(%rbp),%rdx
 1007af0:	neg    %rsi
 1007af3:	add    %rdx,%rsi
 1007af6:	lea    -0x3b0(%rbp),%r8
 1007afd:	lea    -0x3a8(%rbp),%rdx
 1007b04:	sub    %r8,%rdx
 1007b07:	cmp    $0x8,%rsi
 1007b0b:	setb   %r12b
 1007b0f:	movzbl %r12b,%r12d
 1007b13:	cmp    $0x8,%rdx
 1007b17:	setb   %r13b
 1007b1b:	movzbl %r13b,%r13d
 1007b1f:	mov    %r12d,%edx
 1007b22:	or     %r13d,%edx
 1007b25:	jne    1007b65 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x185>
 1007b27:	cmp    $0x0,%rax
 1007b2b:	je     1007b47 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x167>
 1007b2d:	sub    $0x10,%rax
 1007b31:	mov    (%rax),%rax
 1007b34:	movabs $0x5000000000000001,%rdx
 1007b3e:	and    %rdx,%rax
 1007b41:	cmp    $0x0,%rax
 1007b45:	jne    1007b65 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x185>
 1007b47:	mov    -0x3b0(%rbp),%rax
 1007b4e:	mov    %rax,-0x3a8(%rbp)
 1007b55:	movq   $0x0,-0x3b0(%rbp)
 1007b60:	xchg   %rbx,%rdi
 1007b63:	jmp    1007ba0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1c0>
 1007b65:	mov    %rcx,%r15
 1007b68:	lea    -0x3b0(%rbp),%rdx
 1007b6f:	lea    -0x3a8(%rbp),%rsi
 1007b76:	mov    %rdi,%r14
 1007b79:	call   100ada0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take>
 1007b7e:	mov    %r15,%rcx
 1007b81:	mov    %r14,%rdi
 1007b84:	cmp    $0x0,%eax
 1007b87:	jne    1007b9d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1bd>
 1007b89:	call   1012590 <myl_rc_take_failure>
 1007b8e:	mov    %rbx,%rdi
 1007b91:	mov    %eax,%esi
 1007b93:	call   100b020 <myl_qbe_rc_status>
 1007b98:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1007b9d:	xchg   %rbx,%rdi
 1007ba0:	mov    -0x3f0(%rbp),%eax
 1007ba6:	cmp    $0x0,%eax
 1007ba9:	jne    1007bb3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d3>
 1007bab:	mov    %rcx,%r15
 1007bae:	jmp    1007c33 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x253>
 1007bb3:	movl   $0x0,-0x3f0(%rbp)
 1007bbd:	mov    %rcx,%r15
 1007bc0:	mov    -0x370(%rbp),%rcx
 1007bc7:	cmp    $0x0,%rcx
 1007bcb:	je     1007c33 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x253>
 1007bcd:	mov    %rcx,%rax
 1007bd0:	sub    $0x10,%rax
 1007bd4:	mov    (%rax),%rax
 1007bd7:	movabs $0x4000000000000002,%rdx
 1007be1:	and    %rdx,%rax
 1007be4:	cmp    $0x0,%rax
 1007be8:	jne    1007c28 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x248>
 1007bea:	mov    %rcx,%rax
 1007bed:	sub    $0x20,%rax
 1007bf1:	mov    (%rax),%rax
 1007bf4:	sub    $0x1,%rax
 1007bf8:	jne    1007c21 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x241>
 1007bfa:	mov    %rcx,%rdx
 1007bfd:	sub    $0x18,%rdx
 1007c01:	mov    (%rdx),%rdx
 1007c04:	cmp    $0x0,%rdx
 1007c08:	jne    1007c21 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x241>
 1007c0a:	lea    -0x370(%rbp),%rsi
 1007c11:	mov    %rdi,%r14
 1007c14:	mov    %rbx,%rdi
 1007c17:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1007c1c:	mov    %r14,%rdi
 1007c1f:	jmp    1007c33 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x253>
 1007c21:	sub    $0x20,%rcx
 1007c25:	mov    %rax,(%rcx)
 1007c28:	movq   $0x0,-0x370(%rbp)
 1007c33:	mov    -0x3a8(%rbp),%rax
 1007c3a:	mov    %rax,-0x370(%rbp)
 1007c41:	movl   $0x1,-0x3f0(%rbp)
 1007c4b:	movabs $0x408f400000000000,%rax
 1007c55:	mov    %rax,-0x318(%rbp)
 1007c5c:	movabs $0x408f400000000000,%rdx
 1007c66:	mov    $0x7,%esi
 1007c6b:	mov    %rdi,%r14
 1007c6e:	call   100b850 <myl_qbe_float_unary>
 1007c73:	mov    %r15,%rcx
 1007c76:	mov    %r14,%rdi
 1007c79:	mov    %rax,%rsi
 1007c7c:	mov    -0x24(%rbp),%eax
 1007c7f:	mov    -0x10(%rbp),%edx
 1007c82:	mov    %rsi,-0x318(%rbp)
 1007c89:	movq   $0x0,-0x310(%rbp)
 1007c94:	mov    %rsi,-0x308(%rbp)
 1007c9b:	movq   $0x0,-0x300(%rbp)
 1007ca6:	movabs $0x408f380000000000,%rsi
 1007cb0:	mov    %rsi,-0x318(%rbp)
 1007cb7:	movabs $0x3fe0000000000000,%rsi
 1007cc1:	mov    %rsi,-0x2f8(%rbp)
 1007cc8:	movabs $0x3fe0000000000000,%rsi
 1007cd2:	mov    %rsi,-0x2f0(%rbp)
 1007cd9:	movabs $0x3fe0000000000000,%rsi
 1007ce3:	mov    %rsi,-0x2e8(%rbp)
 1007cea:	mov    -0x310(%rbp),%rsi
 1007cf1:	mov    %rsi,-0x2e0(%rbp)
 1007cf8:	mov    -0x308(%rbp),%rsi
 1007cff:	mov    %rsi,-0x2d8(%rbp)
 1007d06:	mov    -0x300(%rbp),%rsi
 1007d0d:	mov    %rsi,-0x2d0(%rbp)
 1007d14:	movabs $0x408f380000000000,%rsi
 1007d1e:	mov    %rsi,-0x2c8(%rbp)
 1007d25:	mov    -0x2f8(%rbp),%rsi
 1007d2c:	mov    %rsi,-0x2c0(%rbp)
 1007d33:	mov    -0x2f0(%rbp),%rsi
 1007d3a:	mov    %rsi,-0x2b8(%rbp)
 1007d41:	mov    -0x2e8(%rbp),%rsi
 1007d48:	mov    %rsi,-0x2b0(%rbp)
 1007d4f:	mov    -0x3f0(%rbp),%esi
 1007d55:	test   %edx,%esi
 1007d57:	je     1007f5c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x57c>
 1007d5d:	mov    -0x370(%rbp),%rdx
 1007d64:	cmp    $0x0,%rdx
 1007d68:	jne    1007d6f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x38f>
 1007d6a:	xchg   %rdi,%rbx
 1007d6d:	jmp    1007dd3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3f3>
 1007d6f:	mov    %rdx,%rsi
 1007d72:	sub    $0x10,%rsi
 1007d76:	mov    (%rsi),%rsi
 1007d79:	movabs $0x4000000000000002,%r8
 1007d83:	and    %rsi,%r8
 1007d86:	cmp    $0x0,%r8
 1007d8a:	jne    1007dbd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3dd>
 1007d8c:	mov    %rdx,%rsi
 1007d8f:	sub    $0x20,%rsi
 1007d93:	mov    (%rsi),%rsi
 1007d96:	add    $0x1,%rsi
 1007d9a:	je     1007dab <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3cb>
 1007d9c:	mov    %rdx,%r8
 1007d9f:	sub    $0x20,%r8
 1007da3:	mov    %rsi,(%r8)
 1007da6:	xchg   %rdi,%rbx
 1007da9:	jmp    1007dd3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3f3>
 1007dab:	mov    $0x2,%esi
 1007db0:	mov    %rdi,%rbx
 1007db3:	call   100b020 <myl_qbe_rc_status>
 1007db8:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1007dbd:	xchg   %rdi,%rbx
 1007dc0:	movabs $0x4000000000000000,%r8
 1007dca:	and    %r8,%rsi
 1007dcd:	cmp    $0x0,%rsi
 1007dd1:	jne    1007ddf <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3ff>
 1007dd3:	mov    %rdx,-0x3a8(%rbp)
 1007dda:	xchg   %rbx,%rdi
 1007ddd:	jmp    1007e1f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x43f>
 1007ddf:	mov    %rcx,%r15
 1007de2:	lea    -0x370(%rbp),%rdx
 1007de9:	lea    -0x3a8(%rbp),%rsi
 1007df0:	mov    %rdi,%r14
 1007df3:	call   100ad50 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 1007df8:	mov    %r15,%rcx
 1007dfb:	mov    %r14,%rdi
 1007dfe:	mov    %eax,%edx
 1007e00:	mov    -0x24(%rbp),%eax
 1007e03:	cmp    $0x0,%edx
 1007e06:	jne    1007e1c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x43c>
 1007e08:	call   1012590 <myl_rc_take_failure>
 1007e0d:	mov    %rbx,%rdi
 1007e10:	mov    %eax,%esi
 1007e12:	call   100b020 <myl_qbe_rc_status>
 1007e17:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1007e1c:	xchg   %rbx,%rdi
 1007e1f:	mov    -0x3f0(%rbp),%edx
 1007e25:	cmp    $0x0,%edx
 1007e28:	je     1007f44 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007e2e:	movl   $0x0,-0x3f0(%rbp)
 1007e38:	test   $0x1c,%eax
 1007e3d:	jne    1007ec8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4e8>
 1007e43:	mov    -0x370(%rbp),%rdx
 1007e4a:	cmp    $0x0,%rdx
 1007e4e:	je     1007f44 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007e54:	mov    %rdx,%rax
 1007e57:	sub    $0x10,%rax
 1007e5b:	mov    (%rax),%rax
 1007e5e:	movabs $0x4000000000000002,%rsi
 1007e68:	and    %rsi,%rax
 1007e6b:	cmp    $0x0,%rax
 1007e6f:	jne    1007ebb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4db>
 1007e71:	mov    %rdx,%rax
 1007e74:	sub    $0x20,%rax
 1007e78:	mov    (%rax),%rax
 1007e7b:	sub    $0x1,%rax
 1007e7f:	jne    1007eb4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4d4>
 1007e81:	mov    %rcx,%r15
 1007e84:	mov    %rdx,%rcx
 1007e87:	sub    $0x18,%rcx
 1007e8b:	mov    (%rcx),%rcx
 1007e8e:	cmp    $0x0,%rcx
 1007e92:	jne    1007eb1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4d1>
 1007e94:	lea    -0x370(%rbp),%rsi
 1007e9b:	mov    %rdi,%r14
 1007e9e:	mov    %rbx,%rdi
 1007ea1:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1007ea6:	mov    %r15,%rcx
 1007ea9:	mov    %r14,%rdi
 1007eac:	jmp    1007f44 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007eb1:	mov    %r15,%rcx
 1007eb4:	sub    $0x20,%rdx
 1007eb8:	mov    %rax,(%rdx)
 1007ebb:	movq   $0x0,-0x370(%rbp)
 1007ec6:	jmp    1007f44 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007ec8:	mov    -0x370(%rbp),%rdx
 1007ecf:	cmp    $0x0,%rdx
 1007ed3:	je     1007f44 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007ed5:	mov    %rdx,%rax
 1007ed8:	sub    $0x10,%rax
 1007edc:	mov    (%rax),%rax
 1007edf:	movabs $0x4000000000000002,%rsi
 1007ee9:	and    %rsi,%rax
 1007eec:	cmp    $0x0,%rax
 1007ef0:	jne    1007f39 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x559>
 1007ef2:	mov    %rdx,%rax
 1007ef5:	sub    $0x18,%rax
 1007ef9:	mov    (%rax),%rax
 1007efc:	sub    $0x1,%rax
 1007f00:	jne    1007f32 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x552>
 1007f02:	mov    %rcx,%r15
 1007f05:	mov    %rdx,%rcx
 1007f08:	sub    $0x20,%rcx
 1007f0c:	mov    (%rcx),%rcx
 1007f0f:	cmp    $0x0,%rcx
 1007f13:	jne    1007f2f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x54f>
 1007f15:	lea    -0x370(%rbp),%rsi
 1007f1c:	mov    %rdi,%r14
 1007f1f:	mov    %rbx,%rdi
 1007f22:	call   100ac70 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 1007f27:	mov    %r15,%rcx
 1007f2a:	mov    %r14,%rdi
 1007f2d:	jmp    1007f44 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007f2f:	mov    %r15,%rcx
 1007f32:	sub    $0x18,%rdx
 1007f36:	mov    %rax,(%rdx)
 1007f39:	movq   $0x0,-0x370(%rbp)
 1007f44:	mov    -0x3a8(%rbp),%rax
 1007f4b:	mov    %rax,-0x370(%rbp)
 1007f52:	movl   $0x1,-0x3f0(%rbp)
 1007f5c:	mov    -0x370(%rbp),%rax
 1007f63:	cmp    $0x0,%rax
 1007f67:	jne    1007f6e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x58e>
 1007f69:	mov    %rcx,%r15
 1007f6c:	jmp    1007fc9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5e9>
 1007f6e:	mov    %rax,%rdx
 1007f71:	sub    $0x10,%rdx
 1007f75:	mov    (%rdx),%rdx
 1007f78:	movabs $0x6000000000000002,%rsi
 1007f82:	and    %rsi,%rdx
 1007f85:	cmp    $0x0,%rdx
 1007f89:	jne    1007f9d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5bd>
 1007f8b:	sub    $0x20,%rax
 1007f8f:	mov    (%rax),%rax
 1007f92:	cmp    $0x2,%rax
 1007f96:	jae    1007f9d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5bd>
 1007f98:	mov    %rcx,%r15
 1007f9b:	jmp    1007fc9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5e9>
 1007f9d:	mov    %rcx,%r15
 1007fa0:	lea    -0x3f0(%rbp),%rcx
 1007fa7:	lea    -0x370(%rbp),%rdx
 1007fae:	lea    0x1e8eb(%rip),%rsi        # 10268a0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 1007fb5:	mov    %rdi,%r14
 1007fb8:	call   100b2c0 <myl_qbe_rc_unique_local>
 1007fbd:	mov    %r14,%rdi
 1007fc0:	cmp    $0x0,%eax
 1007fc3:	je     10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1007fc9:	mov    -0x370(%rbp),%rsi
 1007fd0:	lea    -0x2e0(%rbp),%rdx
 1007fd7:	mov    %rdi,%r14
 1007fda:	mov    %rbx,%rdi
 1007fdd:	call   100adf0 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1007fe2:	mov    %r14,%rdi
 1007fe5:	cmp    $0x0,%eax
 1007fe8:	jne    1007ff1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x611>
 1007fea:	call   100b590 <myl_qbe_fail_allocation>
 1007fef:	ud2
 1007ff1:	movq   $0x0,-0x318(%rbp)
 1007ffc:	movabs $0x4008000000000000,%rdx
 1008006:	mov    $0x7,%esi
 100800b:	mov    %rdi,%r14
 100800e:	call   100b850 <myl_qbe_float_unary>
 1008013:	mov    %r15,%rcx
 1008016:	mov    %r14,%rdi
 1008019:	movq   $0x0,-0x2a8(%rbp)
 1008024:	mov    -0x318(%rbp),%rdx
 100802b:	mov    %rdx,-0x2a0(%rbp)
 1008032:	mov    %rax,-0x298(%rbp)
 1008039:	movabs $0x3ff0000000000000,%rax
 1008043:	mov    %rax,-0x318(%rbp)
 100804a:	movabs $0x3ff0000000000000,%rax
 1008054:	mov    %rax,-0x290(%rbp)
 100805b:	movabs $0x3fc999999999999a,%rax
 1008065:	mov    %rax,-0x288(%rbp)
 100806c:	movabs $0x3fc999999999999a,%rax
 1008076:	mov    %rax,-0x280(%rbp)
 100807d:	mov    -0x2a8(%rbp),%rax
 1008084:	mov    %rax,-0x278(%rbp)
 100808b:	mov    -0x2a0(%rbp),%rax
 1008092:	mov    %rax,-0x270(%rbp)
 1008099:	mov    -0x298(%rbp),%rax
 10080a0:	mov    %rax,-0x268(%rbp)
 10080a7:	movabs $0x3ff0000000000000,%rax
 10080b1:	mov    %rax,-0x260(%rbp)
 10080b8:	mov    -0x290(%rbp),%rax
 10080bf:	mov    %rax,-0x258(%rbp)
 10080c6:	mov    -0x288(%rbp),%rax
 10080cd:	mov    %rax,-0x250(%rbp)
 10080d4:	mov    -0x280(%rbp),%rax
 10080db:	mov    %rax,-0x248(%rbp)
 10080e2:	mov    -0x3f0(%rbp),%eax
 10080e8:	test   $0x0,%eax
 10080ed:	je     100825d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x87d>
 10080f3:	mov    -0x370(%rbp),%rax
 10080fa:	cmp    $0x0,%rax
 10080fe:	jne    1008105 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x725>
 1008100:	xchg   %rdi,%rbx
 1008103:	jmp    1008169 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x789>
 1008105:	mov    %rax,%rdx
 1008108:	sub    $0x10,%rdx
 100810c:	mov    (%rdx),%rdx
 100810f:	movabs $0x4000000000000002,%rsi
 1008119:	and    %rdx,%rsi
 100811c:	cmp    $0x0,%rsi
 1008120:	jne    1008153 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x773>
 1008122:	mov    %rax,%rdx
 1008125:	sub    $0x20,%rdx
 1008129:	mov    (%rdx),%rdx
 100812c:	add    $0x1,%rdx
 1008130:	je     1008141 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x761>
 1008132:	mov    %rax,%rsi
 1008135:	sub    $0x20,%rsi
 1008139:	mov    %rdx,(%rsi)
 100813c:	xchg   %rdi,%rbx
 100813f:	jmp    1008169 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x789>
 1008141:	mov    $0x2,%esi
 1008146:	mov    %rdi,%rbx
 1008149:	call   100b020 <myl_qbe_rc_status>
 100814e:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008153:	xchg   %rdi,%rbx
 1008156:	movabs $0x4000000000000000,%rsi
 1008160:	and    %rsi,%rdx
 1008163:	cmp    $0x0,%rdx
 1008167:	jne    1008175 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x795>
 1008169:	mov    %rax,-0x3a8(%rbp)
 1008170:	xchg   %rbx,%rdi
 1008173:	jmp    10081b0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7d0>
 1008175:	mov    %rcx,%r15
 1008178:	lea    -0x370(%rbp),%rdx
 100817f:	lea    -0x3a8(%rbp),%rsi
 1008186:	mov    %rdi,%r14
 1008189:	call   100ad50 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 100818e:	mov    %r15,%rcx
 1008191:	mov    %r14,%rdi
 1008194:	cmp    $0x0,%eax
 1008197:	jne    10081ad <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7cd>
 1008199:	call   1012590 <myl_rc_take_failure>
 100819e:	mov    %rbx,%rdi
 10081a1:	mov    %eax,%esi
 10081a3:	call   100b020 <myl_qbe_rc_status>
 10081a8:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 10081ad:	xchg   %rbx,%rdi
 10081b0:	mov    -0x3f0(%rbp),%eax
 10081b6:	cmp    $0x0,%eax
 10081b9:	je     1008245 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x865>
 10081bf:	movl   $0x0,-0x3f0(%rbp)
 10081c9:	mov    -0x370(%rbp),%rdx
 10081d0:	cmp    $0x0,%rdx
 10081d4:	je     1008245 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x865>
 10081d6:	mov    %rdx,%rax
 10081d9:	sub    $0x10,%rax
 10081dd:	mov    (%rax),%rax
 10081e0:	movabs $0x4000000000000002,%rsi
 10081ea:	and    %rsi,%rax
 10081ed:	cmp    $0x0,%rax
 10081f1:	jne    100823a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x85a>
 10081f3:	mov    %rdx,%rax
 10081f6:	sub    $0x20,%rax
 10081fa:	mov    (%rax),%rax
 10081fd:	sub    $0x1,%rax
 1008201:	jne    1008233 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x853>
 1008203:	mov    %rcx,%r15
 1008206:	mov    %rdx,%rcx
 1008209:	sub    $0x18,%rcx
 100820d:	mov    (%rcx),%rcx
 1008210:	cmp    $0x0,%rcx
 1008214:	jne    1008230 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x850>
 1008216:	lea    -0x370(%rbp),%rsi
 100821d:	mov    %rdi,%r14
 1008220:	mov    %rbx,%rdi
 1008223:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1008228:	mov    %r15,%rcx
 100822b:	mov    %r14,%rdi
 100822e:	jmp    1008245 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x865>
 1008230:	mov    %r15,%rcx
 1008233:	sub    $0x20,%rdx
 1008237:	mov    %rax,(%rdx)
 100823a:	movq   $0x0,-0x370(%rbp)
 1008245:	mov    -0x3a8(%rbp),%rax
 100824c:	mov    %rax,-0x370(%rbp)
 1008253:	movl   $0x1,-0x3f0(%rbp)
 100825d:	mov    -0x370(%rbp),%rax
 1008264:	cmp    $0x0,%rax
 1008268:	jne    100826f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x88f>
 100826a:	mov    %rcx,%r15
 100826d:	jmp    10082ca <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8ea>
 100826f:	mov    %rax,%rdx
 1008272:	sub    $0x10,%rdx
 1008276:	mov    (%rdx),%rdx
 1008279:	movabs $0x6000000000000002,%rsi
 1008283:	and    %rsi,%rdx
 1008286:	cmp    $0x0,%rdx
 100828a:	jne    100829e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8be>
 100828c:	sub    $0x20,%rax
 1008290:	mov    (%rax),%rax
 1008293:	cmp    $0x2,%rax
 1008297:	jae    100829e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8be>
 1008299:	mov    %rcx,%r15
 100829c:	jmp    10082ca <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8ea>
 100829e:	mov    %rcx,%r15
 10082a1:	lea    -0x3f0(%rbp),%rcx
 10082a8:	lea    -0x370(%rbp),%rdx
 10082af:	lea    0x1e5ea(%rip),%rsi        # 10268a0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 10082b6:	mov    %rdi,%r14
 10082b9:	call   100b2c0 <myl_qbe_rc_unique_local>
 10082be:	mov    %r14,%rdi
 10082c1:	cmp    $0x0,%eax
 10082c4:	je     10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 10082ca:	mov    -0x370(%rbp),%rsi
 10082d1:	lea    -0x278(%rbp),%rdx
 10082d8:	mov    %rdi,%r14
 10082db:	mov    %rbx,%rdi
 10082de:	call   100adf0 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 10082e3:	mov    %r14,%rdi
 10082e6:	cmp    $0x0,%eax
 10082e9:	jne    10082f2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x912>
 10082eb:	call   100b590 <myl_qbe_fail_allocation>
 10082f0:	ud2
 10082f2:	movabs $0x4000000000000000,%rdx
 10082fc:	mov    $0x7,%esi
 1008301:	mov    %rdi,%r14
 1008304:	call   100b850 <myl_qbe_float_unary>
 1008309:	mov    %r14,%rdi
 100830c:	mov    %rax,-0x18(%rbp)
 1008310:	movq   $0x0,-0x318(%rbp)
 100831b:	movabs $0x4010000000000000,%rdx
 1008325:	mov    $0x7,%esi
 100832a:	mov    %rdi,%r14
 100832d:	call   100b850 <myl_qbe_float_unary>
 1008332:	mov    %r15,%rcx
 1008335:	mov    %r14,%rdi
 1008338:	mov    -0x18(%rbp),%rdx
 100833c:	mov    %rdx,-0x240(%rbp)
 1008343:	mov    -0x318(%rbp),%rdx
 100834a:	mov    %rdx,-0x238(%rbp)
 1008351:	mov    %rax,-0x230(%rbp)
 1008358:	movabs $0x3ff0000000000000,%rax
 1008362:	mov    %rax,-0x318(%rbp)
 1008369:	movabs $0x3fc999999999999a,%rax
 1008373:	mov    %rax,-0x228(%rbp)
 100837a:	movabs $0x3ff0000000000000,%rax
 1008384:	mov    %rax,-0x220(%rbp)
 100838b:	movabs $0x3fc999999999999a,%rax
 1008395:	mov    %rax,-0x218(%rbp)
 100839c:	mov    -0x240(%rbp),%rax
 10083a3:	mov    %rax,-0x210(%rbp)
 10083aa:	mov    -0x238(%rbp),%rax
 10083b1:	mov    %rax,-0x208(%rbp)
 10083b8:	mov    -0x230(%rbp),%rax
 10083bf:	mov    %rax,-0x200(%rbp)
 10083c6:	movabs $0x3ff0000000000000,%rax
 10083d0:	mov    %rax,-0x1f8(%rbp)
 10083d7:	mov    -0x228(%rbp),%rax
 10083de:	mov    %rax,-0x1f0(%rbp)
 10083e5:	mov    -0x220(%rbp),%rax
 10083ec:	mov    %rax,-0x1e8(%rbp)
 10083f3:	mov    -0x218(%rbp),%rax
 10083fa:	mov    %rax,-0x1e0(%rbp)
 1008401:	mov    -0x3f0(%rbp),%eax
 1008407:	test   $0x0,%eax
 100840c:	je     100857c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb9c>
 1008412:	mov    -0x370(%rbp),%rax
 1008419:	cmp    $0x0,%rax
 100841d:	jne    1008424 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa44>
 100841f:	xchg   %rdi,%rbx
 1008422:	jmp    1008488 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaa8>
 1008424:	mov    %rax,%rdx
 1008427:	sub    $0x10,%rdx
 100842b:	mov    (%rdx),%rdx
 100842e:	movabs $0x4000000000000002,%rsi
 1008438:	and    %rdx,%rsi
 100843b:	cmp    $0x0,%rsi
 100843f:	jne    1008472 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa92>
 1008441:	mov    %rax,%rdx
 1008444:	sub    $0x20,%rdx
 1008448:	mov    (%rdx),%rdx
 100844b:	add    $0x1,%rdx
 100844f:	je     1008460 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa80>
 1008451:	mov    %rax,%rsi
 1008454:	sub    $0x20,%rsi
 1008458:	mov    %rdx,(%rsi)
 100845b:	xchg   %rdi,%rbx
 100845e:	jmp    1008488 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaa8>
 1008460:	mov    $0x2,%esi
 1008465:	mov    %rdi,%rbx
 1008468:	call   100b020 <myl_qbe_rc_status>
 100846d:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008472:	xchg   %rdi,%rbx
 1008475:	movabs $0x4000000000000000,%rsi
 100847f:	and    %rsi,%rdx
 1008482:	cmp    $0x0,%rdx
 1008486:	jne    1008494 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xab4>
 1008488:	mov    %rax,-0x3a8(%rbp)
 100848f:	xchg   %rbx,%rdi
 1008492:	jmp    10084cf <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaef>
 1008494:	mov    %rcx,%r15
 1008497:	lea    -0x370(%rbp),%rdx
 100849e:	lea    -0x3a8(%rbp),%rsi
 10084a5:	mov    %rdi,%r14
 10084a8:	call   100ad50 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 10084ad:	mov    %r15,%rcx
 10084b0:	mov    %r14,%rdi
 10084b3:	cmp    $0x0,%eax
 10084b6:	jne    10084cc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaec>
 10084b8:	call   1012590 <myl_rc_take_failure>
 10084bd:	mov    %rbx,%rdi
 10084c0:	mov    %eax,%esi
 10084c2:	call   100b020 <myl_qbe_rc_status>
 10084c7:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 10084cc:	xchg   %rbx,%rdi
 10084cf:	mov    -0x3f0(%rbp),%eax
 10084d5:	cmp    $0x0,%eax
 10084d8:	je     1008564 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb84>
 10084de:	movl   $0x0,-0x3f0(%rbp)
 10084e8:	mov    -0x370(%rbp),%rdx
 10084ef:	cmp    $0x0,%rdx
 10084f3:	je     1008564 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb84>
 10084f5:	mov    %rdx,%rax
 10084f8:	sub    $0x10,%rax
 10084fc:	mov    (%rax),%rax
 10084ff:	movabs $0x4000000000000002,%rsi
 1008509:	and    %rsi,%rax
 100850c:	cmp    $0x0,%rax
 1008510:	jne    1008559 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb79>
 1008512:	mov    %rdx,%rax
 1008515:	sub    $0x20,%rax
 1008519:	mov    (%rax),%rax
 100851c:	sub    $0x1,%rax
 1008520:	jne    1008552 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb72>
 1008522:	mov    %rcx,%r15
 1008525:	mov    %rdx,%rcx
 1008528:	sub    $0x18,%rcx
 100852c:	mov    (%rcx),%rcx
 100852f:	cmp    $0x0,%rcx
 1008533:	jne    100854f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb6f>
 1008535:	lea    -0x370(%rbp),%rsi
 100853c:	mov    %rdi,%r14
 100853f:	mov    %rbx,%rdi
 1008542:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1008547:	mov    %r15,%rcx
 100854a:	mov    %r14,%rdi
 100854d:	jmp    1008564 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb84>
 100854f:	mov    %r15,%rcx
 1008552:	sub    $0x20,%rdx
 1008556:	mov    %rax,(%rdx)
 1008559:	movq   $0x0,-0x370(%rbp)
 1008564:	mov    -0x3a8(%rbp),%rax
 100856b:	mov    %rax,-0x370(%rbp)
 1008572:	movl   $0x1,-0x3f0(%rbp)
 100857c:	mov    -0x370(%rbp),%rax
 1008583:	cmp    $0x0,%rax
 1008587:	jne    100858e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xbae>
 1008589:	mov    %rcx,%r15
 100858c:	jmp    10085e9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc09>
 100858e:	mov    %rax,%rdx
 1008591:	sub    $0x10,%rdx
 1008595:	mov    (%rdx),%rdx
 1008598:	movabs $0x6000000000000002,%rsi
 10085a2:	and    %rsi,%rdx
 10085a5:	cmp    $0x0,%rdx
 10085a9:	jne    10085bd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xbdd>
 10085ab:	sub    $0x20,%rax
 10085af:	mov    (%rax),%rax
 10085b2:	cmp    $0x2,%rax
 10085b6:	jae    10085bd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xbdd>
 10085b8:	mov    %rcx,%r15
 10085bb:	jmp    10085e9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc09>
 10085bd:	mov    %rcx,%r15
 10085c0:	lea    -0x3f0(%rbp),%rcx
 10085c7:	lea    -0x370(%rbp),%rdx
 10085ce:	lea    0x1e2cb(%rip),%rsi        # 10268a0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 10085d5:	mov    %rdi,%r14
 10085d8:	call   100b2c0 <myl_qbe_rc_unique_local>
 10085dd:	mov    %r14,%rdi
 10085e0:	cmp    $0x0,%eax
 10085e3:	je     10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 10085e9:	mov    -0x370(%rbp),%rsi
 10085f0:	lea    -0x210(%rbp),%rdx
 10085f7:	mov    %rdi,%r14
 10085fa:	mov    %rbx,%rdi
 10085fd:	call   100adf0 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1008602:	mov    %r14,%rdi
 1008605:	cmp    $0x0,%eax
 1008608:	jne    1008611 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc31>
 100860a:	call   100b590 <myl_qbe_fail_allocation>
 100860f:	ud2
 1008611:	movq   $0x0,-0x318(%rbp)
 100861c:	movabs $0x4010000000000000,%rdx
 1008626:	mov    $0x7,%esi
 100862b:	mov    %rdi,%r14
 100862e:	call   100b850 <myl_qbe_float_unary>
 1008633:	mov    %r15,%rcx
 1008636:	mov    %r14,%rdi
 1008639:	movabs $0x4000000000000000,%rdx
 1008643:	mov    %rdx,-0x1d8(%rbp)
 100864a:	mov    -0x318(%rbp),%rdx
 1008651:	mov    %rdx,-0x1d0(%rbp)
 1008658:	mov    %rax,-0x1c8(%rbp)
 100865f:	movabs $0x3ff0000000000000,%rax
 1008669:	mov    %rax,-0x318(%rbp)
 1008670:	movabs $0x3fc999999999999a,%rax
 100867a:	mov    %rax,-0x1c0(%rbp)
 1008681:	movabs $0x3fc999999999999a,%rax
 100868b:	mov    %rax,-0x1b8(%rbp)
 1008692:	movabs $0x3ff0000000000000,%rax
 100869c:	mov    %rax,-0x1b0(%rbp)
 10086a3:	mov    -0x1d8(%rbp),%rax
 10086aa:	mov    %rax,-0x1a8(%rbp)
 10086b1:	mov    -0x1d0(%rbp),%rax
 10086b8:	mov    %rax,-0x1a0(%rbp)
 10086bf:	mov    -0x1c8(%rbp),%rax
 10086c6:	mov    %rax,-0x198(%rbp)
 10086cd:	movabs $0x3ff0000000000000,%rax
 10086d7:	mov    %rax,-0x190(%rbp)
 10086de:	mov    -0x1c0(%rbp),%rax
 10086e5:	mov    %rax,-0x188(%rbp)
 10086ec:	mov    -0x1b8(%rbp),%rax
 10086f3:	mov    %rax,-0x180(%rbp)
 10086fa:	mov    -0x1b0(%rbp),%rax
 1008701:	mov    %rax,-0x178(%rbp)
 1008708:	mov    -0x3f0(%rbp),%eax
 100870e:	test   $0x0,%eax
 1008713:	je     1008883 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xea3>
 1008719:	mov    -0x370(%rbp),%rax
 1008720:	cmp    $0x0,%rax
 1008724:	jne    100872b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd4b>
 1008726:	xchg   %rdi,%rbx
 1008729:	jmp    100878f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdaf>
 100872b:	mov    %rax,%rdx
 100872e:	sub    $0x10,%rdx
 1008732:	mov    (%rdx),%rdx
 1008735:	movabs $0x4000000000000002,%rsi
 100873f:	and    %rdx,%rsi
 1008742:	cmp    $0x0,%rsi
 1008746:	jne    1008779 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd99>
 1008748:	mov    %rax,%rdx
 100874b:	sub    $0x20,%rdx
 100874f:	mov    (%rdx),%rdx
 1008752:	add    $0x1,%rdx
 1008756:	je     1008767 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd87>
 1008758:	mov    %rax,%rsi
 100875b:	sub    $0x20,%rsi
 100875f:	mov    %rdx,(%rsi)
 1008762:	xchg   %rdi,%rbx
 1008765:	jmp    100878f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdaf>
 1008767:	mov    $0x2,%esi
 100876c:	mov    %rdi,%rbx
 100876f:	call   100b020 <myl_qbe_rc_status>
 1008774:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008779:	xchg   %rdi,%rbx
 100877c:	movabs $0x4000000000000000,%rsi
 1008786:	and    %rsi,%rdx
 1008789:	cmp    $0x0,%rdx
 100878d:	jne    100879b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdbb>
 100878f:	mov    %rax,-0x3a8(%rbp)
 1008796:	xchg   %rbx,%rdi
 1008799:	jmp    10087d6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf6>
 100879b:	mov    %rcx,%r15
 100879e:	lea    -0x370(%rbp),%rdx
 10087a5:	lea    -0x3a8(%rbp),%rsi
 10087ac:	mov    %rdi,%r14
 10087af:	call   100ad50 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 10087b4:	mov    %r15,%rcx
 10087b7:	mov    %r14,%rdi
 10087ba:	cmp    $0x0,%eax
 10087bd:	jne    10087d3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf3>
 10087bf:	call   1012590 <myl_rc_take_failure>
 10087c4:	mov    %rbx,%rdi
 10087c7:	mov    %eax,%esi
 10087c9:	call   100b020 <myl_qbe_rc_status>
 10087ce:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 10087d3:	xchg   %rbx,%rdi
 10087d6:	mov    -0x3f0(%rbp),%eax
 10087dc:	cmp    $0x0,%eax
 10087df:	je     100886b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe8b>
 10087e5:	movl   $0x0,-0x3f0(%rbp)
 10087ef:	mov    -0x370(%rbp),%rdx
 10087f6:	cmp    $0x0,%rdx
 10087fa:	je     100886b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe8b>
 10087fc:	mov    %rdx,%rax
 10087ff:	sub    $0x10,%rax
 1008803:	mov    (%rax),%rax
 1008806:	movabs $0x4000000000000002,%rsi
 1008810:	and    %rsi,%rax
 1008813:	cmp    $0x0,%rax
 1008817:	jne    1008860 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe80>
 1008819:	mov    %rdx,%rax
 100881c:	sub    $0x20,%rax
 1008820:	mov    (%rax),%rax
 1008823:	sub    $0x1,%rax
 1008827:	jne    1008859 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe79>
 1008829:	mov    %rcx,%r15
 100882c:	mov    %rdx,%rcx
 100882f:	sub    $0x18,%rcx
 1008833:	mov    (%rcx),%rcx
 1008836:	cmp    $0x0,%rcx
 100883a:	jne    1008856 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe76>
 100883c:	lea    -0x370(%rbp),%rsi
 1008843:	mov    %rdi,%r14
 1008846:	mov    %rbx,%rdi
 1008849:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 100884e:	mov    %r15,%rcx
 1008851:	mov    %r14,%rdi
 1008854:	jmp    100886b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe8b>
 1008856:	mov    %r15,%rcx
 1008859:	sub    $0x20,%rdx
 100885d:	mov    %rax,(%rdx)
 1008860:	movq   $0x0,-0x370(%rbp)
 100886b:	mov    -0x3a8(%rbp),%rax
 1008872:	mov    %rax,-0x370(%rbp)
 1008879:	movl   $0x1,-0x3f0(%rbp)
 1008883:	mov    -0x370(%rbp),%rax
 100888a:	cmp    $0x0,%rax
 100888e:	jne    1008895 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xeb5>
 1008890:	mov    %rcx,%r15
 1008893:	jmp    10088f0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf10>
 1008895:	mov    %rax,%rdx
 1008898:	sub    $0x10,%rdx
 100889c:	mov    (%rdx),%rdx
 100889f:	movabs $0x6000000000000002,%rsi
 10088a9:	and    %rsi,%rdx
 10088ac:	cmp    $0x0,%rdx
 10088b0:	jne    10088c4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xee4>
 10088b2:	sub    $0x20,%rax
 10088b6:	mov    (%rax),%rax
 10088b9:	cmp    $0x2,%rax
 10088bd:	jae    10088c4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xee4>
 10088bf:	mov    %rcx,%r15
 10088c2:	jmp    10088f0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf10>
 10088c4:	mov    %rcx,%r15
 10088c7:	lea    -0x3f0(%rbp),%rcx
 10088ce:	lea    -0x370(%rbp),%rdx
 10088d5:	lea    0x1dfc4(%rip),%rsi        # 10268a0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 10088dc:	mov    %rdi,%r14
 10088df:	call   100b2c0 <myl_qbe_rc_unique_local>
 10088e4:	mov    %r14,%rdi
 10088e7:	cmp    $0x0,%eax
 10088ea:	je     10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 10088f0:	mov    -0x370(%rbp),%rsi
 10088f7:	lea    -0x1a8(%rbp),%rdx
 10088fe:	mov    %rdi,%r14
 1008901:	mov    %rbx,%rdi
 1008904:	call   100adf0 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1008909:	mov    %r14,%rdi
 100890c:	cmp    $0x0,%eax
 100890f:	jne    1008918 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf38>
 1008911:	call   100b590 <myl_qbe_fail_allocation>
 1008916:	ud2
 1008918:	movabs $0x4000000000000000,%rax
 1008922:	mov    %rax,-0x318(%rbp)
 1008929:	movabs $0x4018000000000000,%rdx
 1008933:	mov    $0x7,%esi
 1008938:	mov    %rdi,%r14
 100893b:	call   100b850 <myl_qbe_float_unary>
 1008940:	mov    %r15,%rcx
 1008943:	mov    %r14,%rdi
 1008946:	movq   $0x0,-0x170(%rbp)
 1008951:	mov    -0x318(%rbp),%rdx
 1008958:	mov    %rdx,-0x168(%rbp)
 100895f:	mov    %rax,-0x160(%rbp)
 1008966:	movabs $0x3ff8000000000000,%rax
 1008970:	mov    %rax,-0x318(%rbp)
 1008977:	movabs $0x3ff0000000000000,%rax
 1008981:	mov    %rax,-0x158(%rbp)
 1008988:	movabs $0x3ff0000000000000,%rax
 1008992:	mov    %rax,-0x150(%rbp)
 1008999:	movabs $0x3fc999999999999a,%rax
 10089a3:	mov    %rax,-0x148(%rbp)
 10089aa:	mov    -0x170(%rbp),%rax
 10089b1:	mov    %rax,-0x140(%rbp)
 10089b8:	mov    -0x168(%rbp),%rax
 10089bf:	mov    %rax,-0x138(%rbp)
 10089c6:	mov    -0x160(%rbp),%rax
 10089cd:	mov    %rax,-0x130(%rbp)
 10089d4:	movabs $0x3ff8000000000000,%rax
 10089de:	mov    %rax,-0x128(%rbp)
 10089e5:	mov    -0x158(%rbp),%rax
 10089ec:	mov    %rax,-0x120(%rbp)
 10089f3:	mov    -0x150(%rbp),%rax
 10089fa:	mov    %rax,-0x118(%rbp)
 1008a01:	mov    -0x148(%rbp),%rax
 1008a08:	mov    %rax,-0x110(%rbp)
 1008a0f:	mov    -0x3f0(%rbp),%eax
 1008a15:	test   $0x0,%eax
 1008a1a:	je     1008b8a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11aa>
 1008a20:	mov    -0x370(%rbp),%rax
 1008a27:	cmp    $0x0,%rax
 1008a2b:	jne    1008a32 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1052>
 1008a2d:	xchg   %rdi,%rbx
 1008a30:	jmp    1008a96 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10b6>
 1008a32:	mov    %rax,%rdx
 1008a35:	sub    $0x10,%rdx
 1008a39:	mov    (%rdx),%rdx
 1008a3c:	movabs $0x4000000000000002,%rsi
 1008a46:	and    %rdx,%rsi
 1008a49:	cmp    $0x0,%rsi
 1008a4d:	jne    1008a80 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10a0>
 1008a4f:	mov    %rax,%rdx
 1008a52:	sub    $0x20,%rdx
 1008a56:	mov    (%rdx),%rdx
 1008a59:	add    $0x1,%rdx
 1008a5d:	je     1008a6e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x108e>
 1008a5f:	mov    %rax,%rsi
 1008a62:	sub    $0x20,%rsi
 1008a66:	mov    %rdx,(%rsi)
 1008a69:	xchg   %rdi,%rbx
 1008a6c:	jmp    1008a96 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10b6>
 1008a6e:	mov    $0x2,%esi
 1008a73:	mov    %rdi,%rbx
 1008a76:	call   100b020 <myl_qbe_rc_status>
 1008a7b:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008a80:	xchg   %rdi,%rbx
 1008a83:	movabs $0x4000000000000000,%rsi
 1008a8d:	and    %rsi,%rdx
 1008a90:	cmp    $0x0,%rdx
 1008a94:	jne    1008aa2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10c2>
 1008a96:	mov    %rax,-0x3a8(%rbp)
 1008a9d:	xchg   %rbx,%rdi
 1008aa0:	jmp    1008add <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10fd>
 1008aa2:	mov    %rcx,%r15
 1008aa5:	lea    -0x370(%rbp),%rdx
 1008aac:	lea    -0x3a8(%rbp),%rsi
 1008ab3:	mov    %rdi,%r14
 1008ab6:	call   100ad50 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 1008abb:	mov    %r15,%rcx
 1008abe:	mov    %r14,%rdi
 1008ac1:	cmp    $0x0,%eax
 1008ac4:	jne    1008ada <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10fa>
 1008ac6:	call   1012590 <myl_rc_take_failure>
 1008acb:	mov    %rbx,%rdi
 1008ace:	mov    %eax,%esi
 1008ad0:	call   100b020 <myl_qbe_rc_status>
 1008ad5:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008ada:	xchg   %rbx,%rdi
 1008add:	mov    -0x3f0(%rbp),%eax
 1008ae3:	cmp    $0x0,%eax
 1008ae6:	je     1008b72 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1192>
 1008aec:	movl   $0x0,-0x3f0(%rbp)
 1008af6:	mov    -0x370(%rbp),%rdx
 1008afd:	cmp    $0x0,%rdx
 1008b01:	je     1008b72 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1192>
 1008b03:	mov    %rdx,%rax
 1008b06:	sub    $0x10,%rax
 1008b0a:	mov    (%rax),%rax
 1008b0d:	movabs $0x4000000000000002,%rsi
 1008b17:	and    %rsi,%rax
 1008b1a:	cmp    $0x0,%rax
 1008b1e:	jne    1008b67 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1187>
 1008b20:	mov    %rdx,%rax
 1008b23:	sub    $0x20,%rax
 1008b27:	mov    (%rax),%rax
 1008b2a:	sub    $0x1,%rax
 1008b2e:	jne    1008b60 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1180>
 1008b30:	mov    %rcx,%r15
 1008b33:	mov    %rdx,%rcx
 1008b36:	sub    $0x18,%rcx
 1008b3a:	mov    (%rcx),%rcx
 1008b3d:	cmp    $0x0,%rcx
 1008b41:	jne    1008b5d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x117d>
 1008b43:	lea    -0x370(%rbp),%rsi
 1008b4a:	mov    %rdi,%r14
 1008b4d:	mov    %rbx,%rdi
 1008b50:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1008b55:	mov    %r15,%rcx
 1008b58:	mov    %r14,%rdi
 1008b5b:	jmp    1008b72 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1192>
 1008b5d:	mov    %r15,%rcx
 1008b60:	sub    $0x20,%rdx
 1008b64:	mov    %rax,(%rdx)
 1008b67:	movq   $0x0,-0x370(%rbp)
 1008b72:	mov    -0x3a8(%rbp),%rax
 1008b79:	mov    %rax,-0x370(%rbp)
 1008b80:	movl   $0x1,-0x3f0(%rbp)
 1008b8a:	mov    -0x370(%rbp),%rax
 1008b91:	cmp    $0x0,%rax
 1008b95:	jne    1008b9c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11bc>
 1008b97:	mov    %rcx,%r15
 1008b9a:	jmp    1008bf7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1217>
 1008b9c:	mov    %rax,%rdx
 1008b9f:	sub    $0x10,%rdx
 1008ba3:	mov    (%rdx),%rdx
 1008ba6:	movabs $0x6000000000000002,%rsi
 1008bb0:	and    %rsi,%rdx
 1008bb3:	cmp    $0x0,%rdx
 1008bb7:	jne    1008bcb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11eb>
 1008bb9:	sub    $0x20,%rax
 1008bbd:	mov    (%rax),%rax
 1008bc0:	cmp    $0x2,%rax
 1008bc4:	jae    1008bcb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11eb>
 1008bc6:	mov    %rcx,%r15
 1008bc9:	jmp    1008bf7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1217>
 1008bcb:	mov    %rcx,%r15
 1008bce:	lea    -0x3f0(%rbp),%rcx
 1008bd5:	lea    -0x370(%rbp),%rdx
 1008bdc:	lea    0x1dcbd(%rip),%rsi        # 10268a0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 1008be3:	mov    %rdi,%r14
 1008be6:	call   100b2c0 <myl_qbe_rc_unique_local>
 1008beb:	mov    %r14,%rdi
 1008bee:	cmp    $0x0,%eax
 1008bf1:	je     10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008bf7:	mov    -0x370(%rbp),%rsi
 1008bfe:	lea    -0x140(%rbp),%rdx
 1008c05:	mov    %rdi,%r14
 1008c08:	mov    %rbx,%rdi
 1008c0b:	call   100adf0 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1008c10:	mov    %r14,%rdi
 1008c13:	cmp    $0x0,%eax
 1008c16:	jne    1008c1f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x123f>
 1008c18:	call   100b590 <myl_qbe_fail_allocation>
 1008c1d:	ud2
 1008c1f:	movabs $0x3ff8000000000000,%rdx
 1008c29:	mov    $0x7,%esi
 1008c2e:	mov    %rdi,%r14
 1008c31:	call   100b850 <myl_qbe_float_unary>
 1008c36:	mov    %r14,%rdi
 1008c39:	mov    %rax,-0x20(%rbp)
 1008c3d:	movabs $0x3fe0000000000000,%rax
 1008c47:	mov    %rax,-0x318(%rbp)
 1008c4e:	movabs $0x3fe0000000000000,%rdx
 1008c58:	mov    $0x7,%esi
 1008c5d:	mov    %rdi,%r14
 1008c60:	call   100b850 <myl_qbe_float_unary>
 1008c65:	mov    %r14,%rdi
 1008c68:	mov    %rax,-0x318(%rbp)
 1008c6f:	movabs $0x4000000000000000,%rdx
 1008c79:	mov    $0x7,%esi
 1008c7e:	mov    %rdi,%r14
 1008c81:	call   100b850 <myl_qbe_float_unary>
 1008c86:	mov    %r15,%rcx
 1008c89:	mov    %r14,%rdi
 1008c8c:	mov    -0x20(%rbp),%rdx
 1008c90:	mov    %rdx,-0x108(%rbp)
 1008c97:	mov    -0x318(%rbp),%rdx
 1008c9e:	mov    %rdx,-0x100(%rbp)
 1008ca5:	mov    %rax,-0xf8(%rbp)
 1008cac:	movabs $0x3fe0000000000000,%rax
 1008cb6:	mov    %rax,-0x318(%rbp)
 1008cbd:	movabs $0x3fc999999999999a,%rax
 1008cc7:	mov    %rax,-0xf0(%rbp)
 1008cce:	movabs $0x3ff0000000000000,%rax
 1008cd8:	mov    %rax,-0xe8(%rbp)
 1008cdf:	movabs $0x3ff0000000000000,%rax
 1008ce9:	mov    %rax,-0xe0(%rbp)
 1008cf0:	mov    -0x108(%rbp),%rax
 1008cf7:	mov    %rax,-0xd8(%rbp)
 1008cfe:	mov    -0x100(%rbp),%rax
 1008d05:	mov    %rax,-0xd0(%rbp)
 1008d0c:	mov    -0xf8(%rbp),%rax
 1008d13:	mov    %rax,-0xc8(%rbp)
 1008d1a:	movabs $0x3fe0000000000000,%rax
 1008d24:	mov    %rax,-0xc0(%rbp)
 1008d2b:	mov    -0xf0(%rbp),%rax
 1008d32:	mov    %rax,-0xb8(%rbp)
 1008d39:	mov    -0xe8(%rbp),%rax
 1008d40:	mov    %rax,-0xb0(%rbp)
 1008d47:	mov    -0xe0(%rbp),%rax
 1008d4e:	mov    %rax,-0xa8(%rbp)
 1008d55:	mov    -0x3f0(%rbp),%eax
 1008d5b:	test   $0x0,%eax
 1008d60:	je     1008ed0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14f0>
 1008d66:	mov    -0x370(%rbp),%rax
 1008d6d:	cmp    $0x0,%rax
 1008d71:	jne    1008d78 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1398>
 1008d73:	xchg   %rdi,%rbx
 1008d76:	jmp    1008ddc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13fc>
 1008d78:	mov    %rax,%rdx
 1008d7b:	sub    $0x10,%rdx
 1008d7f:	mov    (%rdx),%rdx
 1008d82:	movabs $0x4000000000000002,%rsi
 1008d8c:	and    %rdx,%rsi
 1008d8f:	cmp    $0x0,%rsi
 1008d93:	jne    1008dc6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13e6>
 1008d95:	mov    %rax,%rdx
 1008d98:	sub    $0x20,%rdx
 1008d9c:	mov    (%rdx),%rdx
 1008d9f:	add    $0x1,%rdx
 1008da3:	je     1008db4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13d4>
 1008da5:	mov    %rax,%rsi
 1008da8:	sub    $0x20,%rsi
 1008dac:	mov    %rdx,(%rsi)
 1008daf:	xchg   %rdi,%rbx
 1008db2:	jmp    1008ddc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13fc>
 1008db4:	mov    $0x2,%esi
 1008db9:	mov    %rdi,%rbx
 1008dbc:	call   100b020 <myl_qbe_rc_status>
 1008dc1:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008dc6:	xchg   %rdi,%rbx
 1008dc9:	movabs $0x4000000000000000,%rsi
 1008dd3:	and    %rsi,%rdx
 1008dd6:	cmp    $0x0,%rdx
 1008dda:	jne    1008de8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1408>
 1008ddc:	mov    %rax,-0x3a8(%rbp)
 1008de3:	xchg   %rbx,%rdi
 1008de6:	jmp    1008e23 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1443>
 1008de8:	mov    %rcx,%r15
 1008deb:	lea    -0x370(%rbp),%rdx
 1008df2:	lea    -0x3a8(%rbp),%rsi
 1008df9:	mov    %rdi,%r14
 1008dfc:	call   100ad50 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 1008e01:	mov    %r15,%rcx
 1008e04:	mov    %r14,%rdi
 1008e07:	cmp    $0x0,%eax
 1008e0a:	jne    1008e20 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1440>
 1008e0c:	call   1012590 <myl_rc_take_failure>
 1008e11:	mov    %rbx,%rdi
 1008e14:	mov    %eax,%esi
 1008e16:	call   100b020 <myl_qbe_rc_status>
 1008e1b:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008e20:	xchg   %rbx,%rdi
 1008e23:	mov    -0x3f0(%rbp),%eax
 1008e29:	cmp    $0x0,%eax
 1008e2c:	je     1008eb8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d8>
 1008e32:	movl   $0x0,-0x3f0(%rbp)
 1008e3c:	mov    -0x370(%rbp),%rdx
 1008e43:	cmp    $0x0,%rdx
 1008e47:	je     1008eb8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d8>
 1008e49:	mov    %rdx,%rax
 1008e4c:	sub    $0x10,%rax
 1008e50:	mov    (%rax),%rax
 1008e53:	movabs $0x4000000000000002,%rsi
 1008e5d:	and    %rsi,%rax
 1008e60:	cmp    $0x0,%rax
 1008e64:	jne    1008ead <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14cd>
 1008e66:	mov    %rdx,%rax
 1008e69:	sub    $0x20,%rax
 1008e6d:	mov    (%rax),%rax
 1008e70:	sub    $0x1,%rax
 1008e74:	jne    1008ea6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14c6>
 1008e76:	mov    %rcx,%r15
 1008e79:	mov    %rdx,%rcx
 1008e7c:	sub    $0x18,%rcx
 1008e80:	mov    (%rcx),%rcx
 1008e83:	cmp    $0x0,%rcx
 1008e87:	jne    1008ea3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14c3>
 1008e89:	lea    -0x370(%rbp),%rsi
 1008e90:	mov    %rdi,%r14
 1008e93:	mov    %rbx,%rdi
 1008e96:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1008e9b:	mov    %r15,%rcx
 1008e9e:	mov    %r14,%rdi
 1008ea1:	jmp    1008eb8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d8>
 1008ea3:	mov    %r15,%rcx
 1008ea6:	sub    $0x20,%rdx
 1008eaa:	mov    %rax,(%rdx)
 1008ead:	movq   $0x0,-0x370(%rbp)
 1008eb8:	mov    -0x3a8(%rbp),%rax
 1008ebf:	mov    %rax,-0x370(%rbp)
 1008ec6:	movl   $0x1,-0x3f0(%rbp)
 1008ed0:	mov    -0x370(%rbp),%rax
 1008ed7:	cmp    $0x0,%rax
 1008edb:	jne    1008ee2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1502>
 1008edd:	mov    %rcx,%r15
 1008ee0:	jmp    1008f3d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x155d>
 1008ee2:	mov    %rax,%rdx
 1008ee5:	sub    $0x10,%rdx
 1008ee9:	mov    (%rdx),%rdx
 1008eec:	movabs $0x6000000000000002,%rsi
 1008ef6:	and    %rsi,%rdx
 1008ef9:	cmp    $0x0,%rdx
 1008efd:	jne    1008f11 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1531>
 1008eff:	sub    $0x20,%rax
 1008f03:	mov    (%rax),%rax
 1008f06:	cmp    $0x2,%rax
 1008f0a:	jae    1008f11 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1531>
 1008f0c:	mov    %rcx,%r15
 1008f0f:	jmp    1008f3d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x155d>
 1008f11:	mov    %rcx,%r15
 1008f14:	lea    -0x3f0(%rbp),%rcx
 1008f1b:	lea    -0x370(%rbp),%rdx
 1008f22:	lea    0x1d977(%rip),%rsi        # 10268a0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 1008f29:	mov    %rdi,%r14
 1008f2c:	call   100b2c0 <myl_qbe_rc_unique_local>
 1008f31:	mov    %r14,%rdi
 1008f34:	cmp    $0x0,%eax
 1008f37:	je     10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008f3d:	mov    -0x370(%rbp),%rsi
 1008f44:	lea    -0xd8(%rbp),%rdx
 1008f4b:	mov    %rdi,%r14
 1008f4e:	mov    %rbx,%rdi
 1008f51:	call   100adf0 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1008f56:	mov    %r15,%rcx
 1008f59:	mov    %r14,%rdi
 1008f5c:	mov    -0x28(%rbp),%edx
 1008f5f:	cmp    $0x0,%eax
 1008f62:	jne    1008f6b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x158b>
 1008f64:	call   100b590 <myl_qbe_fail_allocation>
 1008f69:	ud2
 1008f6b:	mov    -0x370(%rbp),%rax
 1008f72:	mov    %rax,-0x3b0(%rbp)
 1008f79:	cmp    $0x0,%edx
 1008f7c:	jne    1009033 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1653>
 1008f82:	cmp    $0x0,%rax
 1008f86:	jne    1008f8d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x15ad>
 1008f88:	xchg   %rdi,%rbx
 1008f8b:	jmp    1008ff1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1611>
 1008f8d:	mov    %rax,%rdx
 1008f90:	sub    $0x10,%rdx
 1008f94:	mov    (%rdx),%rdx
 1008f97:	movabs $0x4000000000000002,%rsi
 1008fa1:	and    %rdx,%rsi
 1008fa4:	cmp    $0x0,%rsi
 1008fa8:	jne    1008fdb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x15fb>
 1008faa:	mov    %rax,%rcx
 1008fad:	sub    $0x20,%rcx
 1008fb1:	mov    (%rcx),%rcx
 1008fb4:	add    $0x1,%rcx
 1008fb8:	je     1008fc9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x15e9>
 1008fba:	mov    %rax,%rdx
 1008fbd:	sub    $0x20,%rdx
 1008fc1:	mov    %rcx,(%rdx)
 1008fc4:	xchg   %rdi,%rbx
 1008fc7:	jmp    1008ff1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1611>
 1008fc9:	mov    $0x2,%esi
 1008fce:	mov    %rdi,%rbx
 1008fd1:	call   100b020 <myl_qbe_rc_status>
 1008fd6:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008fdb:	xchg   %rdi,%rbx
 1008fde:	movabs $0x4000000000000000,%rsi
 1008fe8:	and    %rsi,%rdx
 1008feb:	cmp    $0x0,%rdx
 1008fef:	jne    1008ffd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x161d>
 1008ff1:	mov    %rax,-0x3a8(%rbp)
 1008ff8:	jmp    10090b3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16d3>
 1008ffd:	lea    -0x3b0(%rbp),%rdx
 1009004:	lea    -0x3a8(%rbp),%rsi
 100900b:	mov    %rdi,%r12
 100900e:	call   100ad50 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 1009013:	mov    %r12,%rdi
 1009016:	cmp    $0x0,%eax
 1009019:	jne    10090b3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16d3>
 100901f:	call   1012590 <myl_rc_take_failure>
 1009024:	mov    %rbx,%rdi
 1009027:	mov    %eax,%esi
 1009029:	mov    %rdi,%rbx
 100902c:	call   100b020 <myl_qbe_rc_status>
 1009031:	jmp    10090a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1009033:	xchg   %rdi,%rbx
 1009036:	mov    %r12d,%edx
 1009039:	or     %r13d,%edx
 100903c:	jne    1009079 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1699>
 100903e:	cmp    $0x0,%rax
 1009042:	je     100905e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x167e>
 1009044:	sub    $0x10,%rax
 1009048:	mov    (%rax),%rax
 100904b:	movabs $0x5000000000000001,%rdx
 1009055:	and    %rdx,%rax
 1009058:	cmp    $0x0,%rax
 100905c:	jne    1009079 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1699>
 100905e:	mov    -0x3b0(%rbp),%rax
 1009065:	mov    %rax,-0x3a8(%rbp)
 100906c:	movq   $0x0,-0x3b0(%rbp)
 1009077:	jmp    10090b3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16d3>
 1009079:	lea    -0x3b0(%rbp),%rdx
 1009080:	lea    -0x3a8(%rbp),%rsi
 1009087:	mov    %rdi,%r12
 100908a:	call   100ada0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take>
 100908f:	mov    %r12,%rdi
 1009092:	cmp    $0x0,%eax
 1009095:	jne    10090b3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16d3>
 1009097:	call   1012590 <myl_rc_take_failure>
 100909c:	mov    %rbx,%rdi
 100909f:	mov    %eax,%esi
 10090a1:	mov    %rdi,%rbx
 10090a4:	call   100b020 <myl_qbe_rc_status>
 10090a9:	mov    $0x0,%eax
 10090ae:	jmp    10099dc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ffc>
 10090b3:	mov    -0x3a8(%rbp),%rax
 10090ba:	mov    %rax,-0x368(%rbp)
 10090c1:	mov    -0x3f0(%rbp),%eax
 10090c7:	cmp    $0x0,%eax
 10090ca:	jne    10090d4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16f4>
 10090cc:	mov    %rbx,%rdi
 10090cf:	jmp    1009158 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1778>
 10090d4:	movl   $0x0,-0x3f0(%rbp)
 10090de:	mov    -0x370(%rbp),%rcx
 10090e5:	cmp    $0x0,%rcx
 10090e9:	jne    10090f0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1710>
 10090eb:	mov    %rbx,%rdi
 10090ee:	jmp    1009158 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1778>
 10090f0:	mov    %rcx,%rax
 10090f3:	sub    $0x10,%rax
 10090f7:	mov    (%rax),%rax
 10090fa:	movabs $0x4000000000000002,%rdx
 1009104:	and    %rdx,%rax
 1009107:	cmp    $0x0,%rax
 100910b:	jne    100914a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x176a>
 100910d:	mov    %rcx,%rax
 1009110:	sub    $0x20,%rax
 1009114:	mov    (%rax),%rax
 1009117:	sub    $0x1,%rax
 100911b:	jne    100913e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x175e>
 100911d:	mov    %rcx,%rdx
 1009120:	sub    $0x18,%rdx
 1009124:	mov    (%rdx),%rdx
 1009127:	cmp    $0x0,%rdx
 100912b:	jne    100913e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x175e>
 100912d:	lea    -0x370(%rbp),%rsi
 1009134:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1009139:	mov    %rbx,%rdi
 100913c:	jmp    1009158 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1778>
 100913e:	mov    %rbx,%rdi
 1009141:	sub    $0x20,%rcx
 1009145:	mov    %rax,(%rcx)
 1009148:	jmp    100914d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x176d>
 100914a:	mov    %rbx,%rdi
 100914d:	movq   $0x0,-0x370(%rbp)
 1009158:	movabs $0x3ff0000000000000,%rax
 1009162:	mov    %rax,-0x318(%rbp)
 1009169:	movabs $0x3ff0000000000000,%rax
 1009173:	mov    %rax,-0xa0(%rbp)
 100917a:	movabs $0x3ff0000000000000,%rax
 1009184:	mov    %rax,-0x98(%rbp)
 100918b:	movabs $0x3ff0000000000000,%rax
 1009195:	mov    %rax,-0x90(%rbp)
 100919c:	lea    -0xa0(%rbp),%rdx
 10091a3:	mov    %rdi,%rsi
 10091a6:	mov    %rdi,%rbx
 10091a9:	lea    -0x438(%rbp),%rdi
 10091b0:	call   1009cb0 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380>
 10091b5:	mov    %rbx,%rdi
 10091b8:	mov    (%rax),%rcx
 10091bb:	mov    %rcx,-0x360(%rbp)
 10091c2:	mov    0x8(%rax),%rcx
 10091c6:	mov    %rcx,-0x358(%rbp)
 10091cd:	mov    0x10(%rax),%rax
 10091d1:	mov    %rax,-0x350(%rbp)
 10091d8:	mov    $0x780,%edx
 10091dd:	mov    $0xa,%esi
 10091e2:	mov    %rdi,%rbx
 10091e5:	call   100b850 <myl_qbe_float_unary>
 10091ea:	mov    %rbx,%rdi
 10091ed:	mov    %rax,%rbx
 10091f0:	mov    $0x438,%edx
 10091f5:	mov    $0xa,%esi
 10091fa:	mov    %rdi,%r12
 10091fd:	call   100b850 <myl_qbe_float_unary>
 1009202:	mov    %r12,%rdi
 1009205:	mov    %rax,-0x318(%rbp)
 100920c:	movq   %rbx,%xmm0
 1009211:	movq   %rax,%xmm1
 1009216:	divsd  %xmm1,%xmm0
 100921a:	movq   %xmm0,%r14
 100921f:	mov    %r14,-0x30(%rbp)
 1009223:	movq   $0x0,-0x318(%rbp)
 100922e:	movq   $0x0,-0x88(%rbp)
 1009239:	movq   $0x0,-0x80(%rbp)
 1009241:	movq   $0x0,-0x78(%rbp)
 1009249:	mov    -0x88(%rbp),%rax
 1009250:	mov    %rax,-0x348(%rbp)
 1009257:	mov    -0x80(%rbp),%rax
 100925b:	mov    %rax,-0x340(%rbp)
 1009262:	mov    -0x78(%rbp),%rax
 1009266:	mov    %rax,-0x338(%rbp)
 100926d:	movq   %r14,%xmm0
 1009272:	movsd  %xmm0,-0x40(%rbp)
 1009277:	mov    $0x0,%ebx
 100927c:	mov    $0x0,%r13d
 1009282:	cs nopw 0x0(%rax,%rax,1)
 100928c:	nopl   0x0(%rax)
 1009290:	mov    %r13,-0x38(%rbp)
 1009294:	movq   $0x438,-0x318(%rbp)
 100929f:	cmp    $0x438,%r13
 10092a6:	jge    1009867 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e87>
 10092ac:	mov    $0x0,%r12d
 10092b2:	cs nopw 0x0(%rax,%rax,1)
 10092bc:	nopl   0x0(%rax)
 10092c0:	movq   $0x780,-0x318(%rbp)
 10092cb:	cmp    $0x780,%r12
 10092d2:	jge    1009821 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e41>
 10092d8:	mov    %r12,%rdx
 10092db:	mov    $0xa,%esi
 10092e0:	mov    %rdi,%r14
 10092e3:	call   100b850 <myl_qbe_float_unary>
 10092e8:	mov    %r14,%rdi
 10092eb:	movabs $0x3fe0000000000000,%rcx
 10092f5:	mov    %rcx,-0x318(%rbp)
 10092fc:	movq   %rax,%xmm0
 1009301:	addsd  -0x7c49(%rip),%xmm0        # 10016c0 <__abi_tag+0x13c4>
 1009309:	movq   %xmm0,%rax
 100930e:	mov    %rax,-0x318(%rbp)
 1009315:	movq   %rax,%xmm0
 100931a:	mulsd  -0x7c6a(%rip),%xmm0        # 10016b8 <__abi_tag+0x13bc>
 1009322:	movq   %xmm0,%r15
 1009327:	mov    $0x780,%edx
 100932c:	mov    $0xa,%esi
 1009331:	mov    %rdi,%r14
 1009334:	call   100b850 <myl_qbe_float_unary>
 1009339:	mov    %r14,%rdi
 100933c:	movsd  -0x40(%rbp),%xmm0
 1009341:	mov    -0x30(%rbp),%r14
 1009345:	mov    %rax,-0x318(%rbp)
 100934c:	movq   %r15,%xmm1
 1009351:	movq   %rax,%xmm2
 1009356:	divsd  %xmm2,%xmm1
 100935a:	movq   %xmm1,%rax
 100935f:	movabs $0x3ff0000000000000,%rcx
 1009369:	mov    %rcx,-0x318(%rbp)
 1009370:	movq   %rax,%xmm1
 1009375:	subsd  -0x7ccd(%rip),%xmm1        # 10016b0 <__abi_tag+0x13b4>
 100937d:	movq   %xmm1,%rax
 1009382:	mov    %r14,-0x318(%rbp)
 1009389:	movq   %rax,%xmm1
 100938e:	mulsd  %xmm1,%xmm0
 1009392:	movq   %xmm0,%r14
 1009397:	mov    %r13,%rdx
 100939a:	mov    $0xa,%esi
 100939f:	mov    %rdi,%r13
 10093a2:	call   100b850 <myl_qbe_float_unary>
 10093a7:	mov    %r13,%rdi
 10093aa:	movabs $0x3fe0000000000000,%rcx
 10093b4:	mov    %rcx,-0x318(%rbp)
 10093bb:	movq   %rax,%xmm0
 10093c0:	addsd  -0x7d08(%rip),%xmm0        # 10016c0 <__abi_tag+0x13c4>
 10093c8:	movq   %xmm0,%rax
 10093cd:	mov    %rax,-0x318(%rbp)
 10093d4:	movq   %rax,%xmm0
 10093d9:	mulsd  -0x7d29(%rip),%xmm0        # 10016b8 <__abi_tag+0x13bc>
 10093e1:	movq   %xmm0,%r13
 10093e6:	mov    $0x438,%edx
 10093eb:	mov    $0xa,%esi
 10093f0:	mov    %rdi,%r15
 10093f3:	call   100b850 <myl_qbe_float_unary>
 10093f8:	mov    %r15,%rdi
 10093fb:	mov    %rax,-0x318(%rbp)
 1009402:	movq   %r13,%xmm0
 1009407:	movq   %rax,%xmm1
 100940c:	divsd  %xmm1,%xmm0
 1009410:	movq   %xmm0,%rax
 1009415:	mov    %rax,-0x318(%rbp)
 100941c:	movq   %rax,%xmm0
 1009421:	xorpd  -0x7d89(%rip),%xmm0        # 10016a0 <__abi_tag+0x13a4>
 1009429:	addsd  -0x7d81(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 1009431:	movq   %xmm0,%r13
 1009436:	mov    %r14,-0x318(%rbp)
 100943d:	movabs $0x3ff8000000000000,%rdx
 1009447:	mov    $0x7,%esi
 100944c:	mov    %rdi,%r14
 100944f:	call   100b850 <myl_qbe_float_unary>
 1009454:	mov    %r14,%rdi
 1009457:	mov    -0x318(%rbp),%rcx
 100945e:	mov    %rcx,-0x70(%rbp)
 1009462:	mov    %r13,-0x68(%rbp)
 1009466:	mov    %rax,-0x60(%rbp)
 100946a:	lea    -0x70(%rbp),%rax
 100946e:	mov    %rax,-0x318(%rbp)
 1009475:	lea    -0x70(%rbp),%rdx
 1009479:	mov    %rdi,%rsi
 100947c:	mov    %rdi,%r13
 100947f:	lea    -0x408(%rbp),%rdi
 1009486:	call   1009cb0 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380>
 100948b:	mov    %r13,%rdi
 100948e:	mov    %rax,%rcx
 1009491:	mov    %rcx,-0x318(%rbp)
 1009498:	mov    -0x368(%rbp),%r8
 100949f:	lea    -0x360(%rbp),%r9
 10094a6:	lea    -0x348(%rbp),%rdx
 10094ad:	mov    %rdi,%rsi
 10094b0:	mov    %rdi,%r13
 10094b3:	lea    -0x420(%rbp),%rdi
 10094ba:	call   1009e70 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814>
 10094bf:	mov    %r13,%rdi
 10094c2:	mov    (%rax),%rcx
 10094c5:	mov    %rcx,-0x330(%rbp)
 10094cc:	mov    0x8(%rax),%rcx
 10094d0:	mov    %rcx,-0x328(%rbp)
 10094d7:	mov    0x10(%rax),%rax
 10094db:	mov    %rax,-0x320(%rbp)
 10094e2:	mov    -0x330(%rbp),%rcx
 10094e9:	mov    %rcx,-0x318(%rbp)
 10094f0:	movq   %rcx,%xmm0
 10094f5:	ucomisd -0x7e4d(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 10094fd:	movabs $0x3ff0000000000000,%rax
 1009507:	cmovbe %rcx,%rax
 100950b:	movabs $0x406fe00000000000,%rcx
 1009515:	mov    %rcx,-0x318(%rbp)
 100951c:	movq   %rax,%xmm0
 1009521:	mulsd  -0x7e61(%rip),%xmm0        # 10016c8 <__abi_tag+0x13cc>
 1009529:	movq   %xmm0,%rdx
 100952e:	mov    $0xb,%esi
 1009533:	mov    %rdi,%r13
 1009536:	call   100b850 <myl_qbe_float_unary>
 100953b:	mov    %r13,%rdi
 100953e:	mov    -0x328(%rbp),%rcx
 1009545:	mov    %rcx,-0x318(%rbp)
 100954c:	movq   %rcx,%xmm0
 1009551:	ucomisd -0x7ea9(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 1009559:	mov    %rax,%r13
 100955c:	movabs $0x3ff0000000000000,%rax
 1009566:	cmovbe %rcx,%rax
 100956a:	movabs $0x406fe00000000000,%rcx
 1009574:	mov    %rcx,-0x318(%rbp)
 100957b:	movq   %rax,%xmm0
 1009580:	mulsd  -0x7ec0(%rip),%xmm0        # 10016c8 <__abi_tag+0x13cc>
 1009588:	movq   %xmm0,%rdx
 100958d:	mov    $0xb,%esi
 1009592:	mov    %rdi,%r14
 1009595:	call   100b850 <myl_qbe_float_unary>
 100959a:	mov    %r14,%rdi
 100959d:	mov    %rax,%r15
 10095a0:	mov    %r13,%rax
 10095a3:	mov    -0x320(%rbp),%rcx
 10095aa:	mov    %rcx,-0x318(%rbp)
 10095b1:	movq   %rcx,%xmm0
 10095b6:	ucomisd -0x7f0e(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 10095be:	mov    %rax,%r13
 10095c1:	movabs $0x3ff0000000000000,%rax
 10095cb:	cmovbe %rcx,%rax
 10095cf:	movabs $0x406fe00000000000,%rcx
 10095d9:	mov    %rcx,-0x318(%rbp)
 10095e0:	movq   %rax,%xmm0
 10095e5:	mulsd  -0x7f25(%rip),%xmm0        # 10016c8 <__abi_tag+0x13cc>
 10095ed:	movq   %xmm0,%rdx
 10095f2:	mov    $0xb,%esi
 10095f7:	mov    %rdi,%r14
 10095fa:	call   100b850 <myl_qbe_float_unary>
 10095ff:	mov    %r14,%rdi
 1009602:	mov    %rax,%rcx
 1009605:	mov    %r13,%rax
 1009608:	mov    -0x38(%rbp),%r13
 100960c:	mov    -0x30(%rbp),%r14
 1009610:	mov    %rax,-0x318(%rbp)
 1009617:	imul   $0x10000,%rax,%rdx
 100961e:	mov    $0xffffffff,%esi
 1009623:	mov    %rax,%r10
 1009626:	and    %rsi,%r10
 1009629:	mov    %rax,%r9
 100962c:	shr    $0x20,%r9
 1009630:	imul   $0x10000,%r10,%rsi
 1009637:	shr    $0x20,%rsi
 100963b:	imul   $0x10000,%r9,%r8
 1009642:	add    %rsi,%r8
 1009645:	mov    $0xffffffff,%esi
 100964a:	and    %r8,%rsi
 100964d:	shr    $0x20,%r8
 1009651:	imul   $0x0,%r10,%r10
 1009655:	add    %r10,%rsi
 1009658:	shr    $0x20,%rsi
 100965c:	imul   $0x0,%r9,%r9
 1009660:	add    %r9,%r8
 1009663:	add    %r8,%rsi
 1009666:	cmp    $0x0,%rax
 100966a:	setl   %r8b
 100966e:	movzbq %r8b,%r8
 1009672:	neg    %r8
 1009675:	mov    %r8,%r9
 1009678:	and    $0x10000,%r9
 100967f:	mov    %rax,%r8
 1009682:	and    $0x0,%r8
 1009686:	sub    %r9,%rsi
 1009689:	sub    %r8,%rsi
 100968c:	mov    %rdx,%r8
 100968f:	sar    $0x3f,%r8
 1009693:	cmp    %rsi,%r8
 1009696:	jne    1009807 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e27>
 100969c:	mov    %rdx,-0x318(%rbp)
 10096a3:	imul   $0x100,%r15,%rsi
 10096aa:	mov    $0xffffffff,%eax
 10096af:	mov    %r15,%r10
 10096b2:	and    %rax,%r10
 10096b5:	mov    %r15,%r9
 10096b8:	shr    $0x20,%r9
 10096bc:	imul   $0x100,%r10,%rax
 10096c3:	shr    $0x20,%rax
 10096c7:	imul   $0x100,%r9,%r8
 10096ce:	add    %rax,%r8
 10096d1:	mov    $0xffffffff,%eax
 10096d6:	and    %r8,%rax
 10096d9:	shr    $0x20,%r8
 10096dd:	imul   $0x0,%r10,%r10
 10096e1:	add    %r10,%rax
 10096e4:	shr    $0x20,%rax
 10096e8:	imul   $0x0,%r9,%r9
 10096ec:	add    %r9,%r8
 10096ef:	add    %r8,%rax
 10096f2:	cmp    $0x0,%r15
 10096f6:	setl   %r8b
 10096fa:	movzbq %r8b,%r8
 10096fe:	neg    %r8
 1009701:	mov    %r8,%r9
 1009704:	and    $0x100,%r9
 100970b:	mov    %r15,%r8
 100970e:	and    $0x0,%r8
 1009712:	sub    %r9,%rax
 1009715:	sub    %r8,%rax
 1009718:	mov    %rsi,%r8
 100971b:	sar    $0x3f,%r8
 100971f:	cmp    %rax,%r8
 1009722:	jne    10097ed <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e0d>
 1009728:	mov    %rdx,%rax
 100972b:	add    %rsi,%rax
 100972e:	mov    %rdx,%r8
 1009731:	xor    %rax,%r8
 1009734:	mov    %rsi,%r9
 1009737:	xor    %rax,%r9
 100973a:	and    %r9,%r8
 100973d:	cmp    $0x0,%r8
 1009741:	jl     10097d8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df8>
 1009747:	mov    %rax,-0x318(%rbp)
 100974e:	mov    %rcx,%rdx
 1009751:	add    %rax,%rdx
 1009754:	mov    %rax,%rsi
 1009757:	xor    %rdx,%rsi
 100975a:	mov    %rcx,%r8
 100975d:	xor    %rdx,%r8
 1009760:	and    %r8,%rsi
 1009763:	cmp    $0x0,%rsi
 1009767:	jl     10097c3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1de3>
 1009769:	mov    %rdx,-0x318(%rbp)
 1009770:	mov    %rbx,%rsi
 1009773:	mov    %rdi,%rbx
 1009776:	call   10099f0 <myl_f_2f907a6de331cc77376c52e70ba55765a30be18cd9bc69587585fbb71b80de1d>
 100977b:	mov    %rbx,%rdi
 100977e:	mov    %rax,%rbx
 1009781:	movsd  -0x40(%rbp),%xmm0
 1009786:	movq   $0x1,-0x318(%rbp)
 1009791:	movabs $0x7ffffffffffffffe,%rax
 100979b:	cmp    %rax,%r12
 100979e:	jg     10097a9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dc9>
 10097a0:	add    $0x1,%r12
 10097a4:	jmp    10092c0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x18e0>
 10097a9:	mov    %r12,%rdx
 10097ac:	mov    $0x40,%r8d
 10097b2:	mov    $0x1,%ecx
 10097b7:	mov    $0x0,%esi
 10097bc:	call   100b680 <myl_qbe_fail_overflow_op>
 10097c1:	ud2
 10097c3:	mov    %rax,%rdx
 10097c6:	mov    $0x40,%r8d
 10097cc:	mov    $0x0,%esi
 10097d1:	call   100b680 <myl_qbe_fail_overflow_op>
 10097d6:	ud2
 10097d8:	mov    %rsi,%rcx
 10097db:	mov    $0x40,%r8d
 10097e1:	mov    $0x0,%esi
 10097e6:	call   100b680 <myl_qbe_fail_overflow_op>
 10097eb:	ud2
 10097ed:	mov    %r15,%rdx
 10097f0:	mov    $0x40,%r8d
 10097f6:	mov    $0x100,%ecx
 10097fb:	mov    $0x2,%esi
 1009800:	call   100b680 <myl_qbe_fail_overflow_op>
 1009805:	ud2
 1009807:	mov    %rax,%rdx
 100980a:	mov    $0x40,%r8d
 1009810:	mov    $0x10000,%ecx
 1009815:	mov    $0x2,%esi
 100981a:	call   100b680 <myl_qbe_fail_overflow_op>
 100981f:	ud2
 1009821:	movsd  -0x40(%rbp),%xmm0
 1009826:	mov    -0x30(%rbp),%r14
 100982a:	movq   $0x1,-0x318(%rbp)
 1009835:	movabs $0x7ffffffffffffffe,%rax
 100983f:	cmp    %rax,%r13
 1009842:	jg     100984d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e6d>
 1009844:	add    $0x1,%r13
 1009848:	jmp    1009290 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x18b0>
 100984d:	mov    %r13,%rdx
 1009850:	mov    $0x40,%r8d
 1009856:	mov    $0x1,%ecx
 100985b:	mov    $0x0,%esi
 1009860:	call   100b680 <myl_qbe_fail_overflow_op>
 1009865:	ud2
 1009867:	mov    %rbx,%r12
 100986a:	mov    -0x50(%rbp),%rbx
 100986e:	mov    -0x48(%rbp),%r13
 1009872:	mov    %r12,-0x318(%rbp)
 1009879:	mov    %r13,%rsi
 100987c:	mov    %rdi,%r12
 100987f:	call   100d810 <myl_qbe_stream_begin>
 1009884:	mov    %r13,%rdx
 1009887:	mov    %r12,%rdi
 100988a:	mov    %rax,%rsi
 100988d:	mov    %rdx,%r14
 1009890:	mov    $0x0,%edx
 1009895:	mov    %rsi,%r13
 1009898:	lea    -0x318(%rbp),%rsi
 100989f:	mov    %rdi,%r12
 10098a2:	mov    %r13,%rdi
 10098a5:	call   100ac60 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 10098aa:	mov    %r13,%rsi
 10098ad:	mov    %r12,%rdi
 10098b0:	mov    %rsi,%r13
 10098b3:	mov    $0xa,%esi
 10098b8:	mov    %rdi,%r12
 10098bb:	mov    %r13,%rdi
 10098be:	call   100d760 <myl_qbe_print_byte>
 10098c3:	mov    %r14,%rdx
 10098c6:	mov    %r13,%rsi
 10098c9:	mov    %r12,%rdi
 10098cc:	mov    %rdi,%r12
 10098cf:	call   100d850 <myl_qbe_stream_finish>
 10098d4:	mov    %r12,%rdi
 10098d7:	call   100b4a0 <myl_qbe_exit_skip>
 10098dc:	mov    %rbx,%rdi
 10098df:	cmp    $0x0,%eax
 10098e2:	jne    10099d7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ff7>
 10098e8:	mov    -0x368(%rbp),%rcx
 10098ef:	cmp    $0x0,%rcx
 10098f3:	je     1009958 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f78>
 10098f5:	mov    %rcx,%rax
 10098f8:	sub    $0x10,%rax
 10098fc:	mov    (%rax),%rax
 10098ff:	movabs $0x4000000000000002,%rdx
 1009909:	and    %rdx,%rax
 100990c:	cmp    $0x0,%rax
 1009910:	jne    100994d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f6d>
 1009912:	mov    %rcx,%rax
 1009915:	sub    $0x20,%rax
 1009919:	mov    (%rax),%rax
 100991c:	sub    $0x1,%rax
 1009920:	jne    1009946 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f66>
 1009922:	mov    %rcx,%rdx
 1009925:	sub    $0x18,%rdx
 1009929:	mov    (%rdx),%rdx
 100992c:	cmp    $0x0,%rdx
 1009930:	jne    1009946 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f66>
 1009932:	lea    -0x368(%rbp),%rsi
 1009939:	mov    %rdi,%rbx
 100993c:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1009941:	mov    %rbx,%rdi
 1009944:	jmp    1009958 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f78>
 1009946:	sub    $0x20,%rcx
 100994a:	mov    %rax,(%rcx)
 100994d:	movq   $0x0,-0x368(%rbp)
 1009958:	mov    -0x3f0(%rbp),%eax
 100995e:	cmp    $0x0,%eax
 1009961:	je     10099d7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ff7>
 1009963:	movl   $0x0,-0x3f0(%rbp)
 100996d:	mov    -0x370(%rbp),%rcx
 1009974:	cmp    $0x0,%rcx
 1009978:	je     10099d7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ff7>
 100997a:	mov    %rcx,%rax
 100997d:	sub    $0x10,%rax
 1009981:	mov    (%rax),%rax
 1009984:	movabs $0x4000000000000002,%rdx
 100998e:	and    %rdx,%rax
 1009991:	cmp    $0x0,%rax
 1009995:	jne    10099cc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1fec>
 1009997:	mov    %rcx,%rax
 100999a:	sub    $0x20,%rax
 100999e:	mov    (%rax),%rax
 10099a1:	sub    $0x1,%rax
 10099a5:	jne    10099c5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1fe5>
 10099a7:	mov    %rcx,%rdx
 10099aa:	sub    $0x18,%rdx
 10099ae:	mov    (%rdx),%rdx
 10099b1:	cmp    $0x0,%rdx
 10099b5:	jne    10099c5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1fe5>
 10099b7:	lea    -0x370(%rbp),%rsi
 10099be:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10099c3:	jmp    10099d7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ff7>
 10099c5:	sub    $0x20,%rcx
 10099c9:	mov    %rax,(%rcx)
 10099cc:	movq   $0x0,-0x370(%rbp)
 10099d7:	mov    $0x0,%eax
 10099dc:	pop    %r15
 10099de:	pop    %r14
 10099e0:	pop    %r13
 10099e2:	pop    %r12
 10099e4:	pop    %rbx
 10099e5:	leave
 10099e6:	ret
 10099e7:	call   100b840 <myl_qbe_fail_frame>
 10099ec:	ud2
 10099ee:	int3
 10099ef:	int3

00000000010099f0 <myl_f_2f907a6de331cc77376c52e70ba55765a30be18cd9bc69587585fbb71b80de1d>:
 10099f0:	endbr64
 10099f4:	push   %rbp
 10099f5:	mov    %rsp,%rbp
 10099f8:	mov    %rdx,%rcx
 10099fb:	mov    %rsi,%rdx
 10099fe:	imul   $0x1f,%rdx,%rax
 1009a02:	mov    $0xffffffff,%esi
 1009a07:	mov    %rdx,%r10
 1009a0a:	and    %rsi,%r10
 1009a0d:	mov    %rdx,%r9
 1009a10:	shr    $0x20,%r9
 1009a14:	imul   $0x1f,%r10,%rsi
 1009a18:	shr    $0x20,%rsi
 1009a1c:	imul   $0x1f,%r9,%r8
 1009a20:	add    %rsi,%r8
 1009a23:	mov    $0xffffffff,%esi
 1009a28:	and    %r8,%rsi
 1009a2b:	shr    $0x20,%r8
 1009a2f:	imul   $0x0,%r10,%r10
 1009a33:	add    %r10,%rsi
 1009a36:	shr    $0x20,%rsi
 1009a3a:	imul   $0x0,%r9,%r9
 1009a3e:	add    %r9,%r8
 1009a41:	add    %r8,%rsi
 1009a44:	cmp    $0x0,%rdx
 1009a48:	setl   %r8b
 1009a4c:	movzbq %r8b,%r8
 1009a50:	neg    %r8
 1009a53:	mov    %r8,%r9
 1009a56:	and    $0x1f,%r9
 1009a5a:	mov    %rdx,%r8
 1009a5d:	and    $0x0,%r8
 1009a61:	sub    %r9,%rsi
 1009a64:	sub    %r8,%rsi
 1009a67:	mov    %rax,%r8
 1009a6a:	sar    $0x3f,%r8
 1009a6e:	cmp    %rsi,%r8
 1009a71:	jne    1009b05 <myl_f_2f907a6de331cc77376c52e70ba55765a30be18cd9bc69587585fbb71b80de1d+0x115>
 1009a77:	mov    %rax,%rdx
 1009a7a:	mov    %rcx,%rax
 1009a7d:	add    %rdx,%rax
 1009a80:	mov    %rdx,%rsi
 1009a83:	xor    %rax,%rsi
 1009a86:	mov    %rcx,%r8
 1009a89:	xor    %rax,%r8
 1009a8c:	and    %r8,%rsi
 1009a8f:	cmp    $0x0,%rsi
 1009a93:	jl     1009af3 <myl_f_2f907a6de331cc77376c52e70ba55765a30be18cd9bc69587585fbb71b80de1d+0x103>
 1009a95:	movabs $0x8000000000000000,%rcx
 1009a9f:	cmp    %rcx,%rax
 1009aa2:	sete   %cl
 1009aa5:	movzbq %cl,%rcx
 1009aa9:	and    $0x0,%rcx
 1009aad:	neg    %rcx
 1009ab0:	and    $0x3b9aca06,%rcx
 1009ab7:	mov    %rcx,%rsi
 1009aba:	xor    $0x3b9aca07,%rsi
 1009ac1:	cqto
 1009ac3:	idiv   %rsi
 1009ac6:	mov    %rdx,%rcx
 1009ac9:	cmp    $0x0,%rcx
 1009acd:	setne  %al
 1009ad0:	movzbq %al,%rax
 1009ad4:	mov    %rsi,%rdx
 1009ad7:	xor    %rcx,%rdx
 1009ada:	cmp    $0x0,%rdx
 1009ade:	setl   %dl
 1009ae1:	movzbq %dl,%rdx
 1009ae5:	and    %rdx,%rax
 1009ae8:	neg    %rax
 1009aeb:	and    %rsi,%rax
 1009aee:	add    %rcx,%rax
 1009af1:	leave
 1009af2:	ret
 1009af3:	mov    $0x40,%r8d
 1009af9:	mov    $0x0,%esi
 1009afe:	call   100b680 <myl_qbe_fail_overflow_op>
 1009b03:	ud2
 1009b05:	mov    $0x40,%r8d
 1009b0b:	mov    $0x1f,%ecx
 1009b10:	mov    $0x2,%esi
 1009b15:	call   100b680 <myl_qbe_fail_overflow_op>
 1009b1a:	ud2
 1009b1c:	int3
 1009b1d:	int3
 1009b1e:	int3
 1009b1f:	int3

0000000001009b20 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986>:
 1009b20:	endbr64
 1009b24:	push   %rbp
 1009b25:	mov    %rsp,%rbp
 1009b28:	sub    $0x58,%rsp
 1009b2c:	push   %rbx
 1009b2d:	push   %r12
 1009b2f:	push   %r13
 1009b31:	mov    %rcx,%r12
 1009b34:	mov    %rdx,%r13
 1009b37:	mov    %rsi,%rdx
 1009b3a:	mov    0x40(%rdi),%rax
 1009b3e:	lea    -0x18(%rbp),%rcx
 1009b42:	cmp    %rax,%rcx
 1009b45:	jb     1009c9a <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x17a>
 1009b4b:	mov    %r12,%rcx
 1009b4e:	mov    %rdi,%rsi
 1009b51:	mov    %rdi,%rbx
 1009b54:	lea    -0x48(%rbp),%rdi
 1009b58:	call   1009de0 <myl_f_ddc6e2b224d0fd821669202258386936fc9ce2899e215eec6322b95f8dd96d6a>
 1009b5d:	mov    %r13,%rdx
 1009b60:	mov    %rbx,%rdi
 1009b63:	mov    (%rax),%rcx
 1009b66:	mov    %rcx,-0x30(%rbp)
 1009b6a:	mov    0x8(%rax),%rcx
 1009b6e:	mov    %rcx,-0x28(%rbp)
 1009b72:	mov    0x10(%rax),%rax
 1009b76:	mov    %rax,-0x20(%rbp)
 1009b7a:	lea    -0x30(%rbp),%rsi
 1009b7e:	mov    %rdi,%rbx
 1009b81:	call   100ab60 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>
 1009b86:	mov    %rbx,%rdi
 1009b89:	mov    %rax,%rbx
 1009b8c:	lea    -0x30(%rbp),%rdx
 1009b90:	lea    -0x30(%rbp),%rsi
 1009b94:	mov    %rdi,%r13
 1009b97:	call   100ab60 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>
 1009b9c:	mov    %r13,%rdi
 1009b9f:	mov    %rax,%rcx
 1009ba2:	mov    0x18(%r12),%rax
 1009ba7:	movq   %rax,%xmm0
 1009bac:	mulsd  %xmm0,%xmm0
 1009bb0:	movq   %xmm0,%rax
 1009bb5:	movq   %rcx,%xmm0
 1009bba:	movq   %rax,%xmm1
 1009bbf:	subsd  %xmm1,%xmm0
 1009bc3:	movq   %xmm0,%rax
 1009bc8:	movq   %rbx,%xmm0
 1009bcd:	movsd  %xmm0,-0x10(%rbp)
 1009bd2:	mulsd  %xmm0,%xmm0
 1009bd6:	movq   %xmm0,%rcx
 1009bdb:	movq   %rcx,%xmm0
 1009be0:	movq   %rax,%xmm1
 1009be5:	subsd  %xmm1,%xmm0
 1009be9:	movq   %xmm0,%rdx
 1009bee:	movq   %rdx,%xmm0
 1009bf3:	movsd  -0x852b(%rip),%xmm1        # 10016d0 <__abi_tag+0x13d4>
 1009bfb:	ucomisd %xmm0,%xmm1
 1009bff:	ja     1009c7f <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x15f>
 1009c01:	mov    $0x2,%esi
 1009c06:	mov    %rdi,%rbx
 1009c09:	call   100b850 <myl_qbe_float_unary>
 1009c0e:	mov    %rbx,%rdi
 1009c11:	movsd  -0x10(%rbp),%xmm0
 1009c16:	xorpd  -0x857e(%rip),%xmm0        # 10016a0 <__abi_tag+0x13a4>
 1009c1e:	addsd  -0x8556(%rip),%xmm0        # 10016d0 <__abi_tag+0x13d4>
 1009c26:	movq   %xmm0,%rcx
 1009c2b:	movq   %rcx,%xmm0
 1009c30:	movq   %rax,%xmm1
 1009c35:	movsd  %xmm0,%xmm2
 1009c39:	subsd  %xmm1,%xmm2
 1009c3d:	movq   %xmm2,%rax
 1009c42:	movq   %rax,%xmm2
 1009c47:	ucomisd -0x8577(%rip),%xmm2        # 10016d8 <__abi_tag+0x13dc>
 1009c4f:	ja     1009c93 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x173>
 1009c51:	addsd  %xmm1,%xmm0
 1009c55:	movq   %xmm0,%rax
 1009c5a:	movq   %rax,%xmm0
 1009c5f:	ucomisd -0x858f(%rip),%xmm0        # 10016d8 <__abi_tag+0x13dc>
 1009c67:	ja     1009c93 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x173>
 1009c69:	movabs $0x3ff0000000000000,%rdx
 1009c73:	mov    $0x7,%esi
 1009c78:	call   100b850 <myl_qbe_float_unary>
 1009c7d:	jmp    1009c93 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x173>
 1009c7f:	movabs $0x3ff0000000000000,%rdx
 1009c89:	mov    $0x7,%esi
 1009c8e:	call   100b850 <myl_qbe_float_unary>
 1009c93:	pop    %r13
 1009c95:	pop    %r12
 1009c97:	pop    %rbx
 1009c98:	leave
 1009c99:	ret
 1009c9a:	call   100b840 <myl_qbe_fail_frame>
 1009c9f:	ud2
 1009ca1:	int3
 1009ca2:	int3
 1009ca3:	int3
 1009ca4:	int3
 1009ca5:	int3
 1009ca6:	int3
 1009ca7:	int3
 1009ca8:	int3
 1009ca9:	int3
 1009caa:	int3
 1009cab:	int3
 1009cac:	int3
 1009cad:	int3
 1009cae:	int3
 1009caf:	int3

0000000001009cb0 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380>:
 1009cb0:	endbr64
 1009cb4:	push   %rbp
 1009cb5:	mov    %rsp,%rbp
 1009cb8:	sub    $0x28,%rsp
 1009cbc:	push   %rbx
 1009cbd:	push   %r12
 1009cbf:	push   %r13
 1009cc1:	mov    %rdi,%rax
 1009cc4:	mov    %rsi,%rdi
 1009cc7:	mov    %rax,%rbx
 1009cca:	mov    0x40(%rdi),%rax
 1009cce:	lea    -0x8(%rbp),%rcx
 1009cd2:	cmp    %rax,%rcx
 1009cd5:	jb     1009d49 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380+0x99>
 1009cd7:	mov    %rdx,%r13
 1009cda:	mov    %r13,%rsi
 1009cdd:	mov    %rdi,%r12
 1009ce0:	call   100ab60 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>
 1009ce5:	mov    %r12,%rdi
 1009ce8:	mov    %rax,%rdx
 1009ceb:	mov    $0x2,%esi
 1009cf0:	mov    %rdi,%r12
 1009cf3:	call   100b850 <myl_qbe_float_unary>
 1009cf8:	mov    %r13,%rdx
 1009cfb:	mov    %r12,%rdi
 1009cfe:	movq   %rax,%xmm0
 1009d03:	movsd  %xmm0,%xmm15
 1009d08:	movsd  -0x8660(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 1009d10:	divsd  %xmm15,%xmm0
 1009d15:	movq   %xmm0,%rcx
 1009d1a:	mov    %rdi,%rsi
 1009d1d:	lea    -0x20(%rbp),%rdi
 1009d21:	call   100abe0 <myl_f_f469802a31447f90d6a033d43f18db7ebfbee7cc3c378024bcc0f1573d3feef8>
 1009d26:	mov    %rax,%rcx
 1009d29:	mov    %rbx,%rax
 1009d2c:	mov    (%rcx),%rdx
 1009d2f:	mov    %rdx,(%rax)
 1009d32:	mov    0x8(%rcx),%rdx
 1009d36:	mov    %rdx,0x8(%rax)
 1009d3a:	mov    0x10(%rcx),%rcx
 1009d3e:	mov    %rcx,0x10(%rax)
 1009d42:	pop    %r13
 1009d44:	pop    %r12
 1009d46:	pop    %rbx
 1009d47:	leave
 1009d48:	ret
 1009d49:	call   100b840 <myl_qbe_fail_frame>
 1009d4e:	ud2

0000000001009d50 <myl_f_7e9e5ac30f2216fd0fd6f5faed316f2d5983361a4203c3330cfa46ef65bb4767>:
 1009d50:	endbr64
 1009d54:	push   %rbp
 1009d55:	mov    %rsp,%rbp
 1009d58:	sub    $0x20,%rsp
 1009d5c:	mov    %rdi,%rax
 1009d5f:	mov    %rdx,%rdi
 1009d62:	mov    (%rdi),%rsi
 1009d65:	mov    (%rcx),%rdx
 1009d68:	movq   %rsi,%xmm0
 1009d6d:	movq   %rdx,%xmm1
 1009d72:	addsd  %xmm1,%xmm0
 1009d76:	movq   %xmm0,%rsi
 1009d7b:	mov    0x8(%rdi),%r8
 1009d7f:	mov    0x8(%rcx),%rdx
 1009d83:	movq   %r8,%xmm0
 1009d88:	movq   %rdx,%xmm1
 1009d8d:	addsd  %xmm1,%xmm0
 1009d91:	movq   %xmm0,%rdx
 1009d96:	mov    0x10(%rdi),%rdi
 1009d9a:	mov    0x10(%rcx),%rcx
 1009d9e:	movq   %rdi,%xmm0
 1009da3:	movq   %rcx,%xmm1
 1009da8:	addsd  %xmm1,%xmm0
 1009dac:	movq   %xmm0,%rcx
 1009db1:	mov    %rsi,-0x18(%rbp)
 1009db5:	mov    %rdx,-0x10(%rbp)
 1009db9:	mov    %rcx,-0x8(%rbp)
 1009dbd:	mov    -0x18(%rbp),%rcx
 1009dc1:	mov    %rcx,(%rax)
 1009dc4:	mov    -0x10(%rbp),%rcx
 1009dc8:	mov    %rcx,0x8(%rax)
 1009dcc:	mov    -0x8(%rbp),%rcx
 1009dd0:	mov    %rcx,0x10(%rax)
 1009dd4:	leave
 1009dd5:	ret
 1009dd6:	int3
 1009dd7:	int3
 1009dd8:	int3
 1009dd9:	int3
 1009dda:	int3
 1009ddb:	int3
 1009ddc:	int3
 1009ddd:	int3
 1009dde:	int3
 1009ddf:	int3

0000000001009de0 <myl_f_ddc6e2b224d0fd821669202258386936fc9ce2899e215eec6322b95f8dd96d6a>:
 1009de0:	endbr64
 1009de4:	push   %rbp
 1009de5:	mov    %rsp,%rbp
 1009de8:	sub    $0x20,%rsp
 1009dec:	mov    %rdi,%rax
 1009def:	mov    %rdx,%rdi
 1009df2:	mov    (%rdi),%rsi
 1009df5:	mov    (%rcx),%rdx
 1009df8:	movq   %rsi,%xmm0
 1009dfd:	movq   %rdx,%xmm1
 1009e02:	subsd  %xmm1,%xmm0
 1009e06:	movq   %xmm0,%rsi
 1009e0b:	mov    0x8(%rdi),%r8
 1009e0f:	mov    0x8(%rcx),%rdx
 1009e13:	movq   %r8,%xmm0
 1009e18:	movq   %rdx,%xmm1
 1009e1d:	subsd  %xmm1,%xmm0
 1009e21:	movq   %xmm0,%rdx
 1009e26:	mov    0x10(%rdi),%rdi
 1009e2a:	mov    0x10(%rcx),%rcx
 1009e2e:	movq   %rdi,%xmm0
 1009e33:	movq   %rcx,%xmm1
 1009e38:	subsd  %xmm1,%xmm0
 1009e3c:	movq   %xmm0,%rcx
 1009e41:	mov    %rsi,-0x18(%rbp)
 1009e45:	mov    %rdx,-0x10(%rbp)
 1009e49:	mov    %rcx,-0x8(%rbp)
 1009e4d:	mov    -0x18(%rbp),%rcx
 1009e51:	mov    %rcx,(%rax)
 1009e54:	mov    -0x10(%rbp),%rcx
 1009e58:	mov    %rcx,0x8(%rax)
 1009e5c:	mov    -0x8(%rbp),%rcx
 1009e60:	mov    %rcx,0x10(%rax)
 1009e64:	leave
 1009e65:	ret
 1009e66:	int3
 1009e67:	int3
 1009e68:	int3
 1009e69:	int3
 1009e6a:	int3
 1009e6b:	int3
 1009e6c:	int3
 1009e6d:	int3
 1009e6e:	int3
 1009e6f:	int3

0000000001009e70 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814>:
 1009e70:	endbr64
 1009e74:	push   %rbp
 1009e75:	mov    %rsp,%rbp
 1009e78:	sub    $0x238,%rsp
 1009e7f:	push   %rbx
 1009e80:	push   %r12
 1009e82:	push   %r13
 1009e84:	push   %r14
 1009e86:	push   %r15
 1009e88:	mov    %r9,-0x28(%rbp)
 1009e8c:	mov    %r8,%r15
 1009e8f:	mov    %rcx,%r13
 1009e92:	mov    %rdx,%r14
 1009e95:	mov    %rdi,%rbx
 1009e98:	mov    %rsi,%rdi
 1009e9b:	mov    %r15,-0x30(%rbp)
 1009e9f:	mov    %r13,-0x18(%rbp)
 1009ea3:	mov    %r14,-0x20(%rbp)
 1009ea7:	mov    %rbx,-0x48(%rbp)
 1009eab:	movq   $0x0,-0x150(%rbp)
 1009eb6:	movq   $0x0,-0x130(%rbp)
 1009ec1:	movq   $0x0,-0x110(%rbp)
 1009ecc:	mov    0x40(%rdi),%rax
 1009ed0:	lea    -0x58(%rbp),%rcx
 1009ed4:	cmp    %rax,%rcx
 1009ed7:	setb   %al
 1009eda:	movzbq %al,%rax
 1009ede:	mov    $0x0,%ecx
 1009ee3:	mov    %ecx,-0x10(%rbp)
 1009ee6:	mov    $0x0,%esi
 1009eeb:	mov    %esi,-0xc(%rbp)
 1009eee:	mov    $0x0,%esi
 1009ef3:	mov    %esi,-0x34(%rbp)
 1009ef6:	cmp    $0x0,%eax
 1009ef9:	jne    100ab59 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xce9>
 1009eff:	movq   $0x0,-0xf0(%rbp)
 1009f0a:	movq   $0x0,-0xe8(%rbp)
 1009f15:	movq   $0x0,-0x78(%rbp)
 1009f1d:	mov    %rdi,%r12
 1009f20:	call   100b830 <myl_qbe_heap>
 1009f25:	mov    %r12,%rdi
 1009f28:	mov    %rax,-0x40(%rbp)
 1009f2c:	mov    %rdi,%r12
 1009f2f:	call   100d750 <myl_qbe_region_mark>
 1009f34:	mov    %r13,%rdx
 1009f37:	mov    %r12,%rdi
 1009f3a:	mov    %rdx,%r13
 1009f3d:	movabs $0x3ff0000000000000,%rdx
 1009f47:	mov    $0x7,%esi
 1009f4c:	mov    %rdi,%r12
 1009f4f:	call   100b850 <myl_qbe_float_unary>
 1009f54:	mov    %r15,%r8
 1009f57:	mov    %r13,%rdx
 1009f5a:	mov    %r12,%rdi
 1009f5d:	mov    %rax,%rcx
 1009f60:	mov    %rbx,%rax
 1009f63:	mov    -0xc(%rbp),%esi
 1009f66:	mov    %rax,%rbx
 1009f69:	mov    -0x10(%rbp),%eax
 1009f6c:	mov    -0x40(%rbp),%r12
 1009f70:	cmp    $0x0,%r8
 1009f74:	setne  %r9b
 1009f78:	movzbl %r9b,%r9d
 1009f7c:	cmp    $0x0,%r9d
 1009f80:	jne    1009f8d <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x11d>
 1009f82:	mov    %r8,%r15
 1009f85:	mov    %rdi,%rbx
 1009f88:	mov    %r12,%rdi
 1009f8b:	jmp    1009fea <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x17a>
 1009f8d:	mov    %r8,%r9
 1009f90:	sub    $0x10,%r9
 1009f94:	mov    (%r9),%r9
 1009f97:	movabs $0x4000000000000002,%r10
 1009fa1:	and    %r10,%r9
 1009fa4:	cmp    $0x0,%r9
 1009fa8:	jne    1009fe1 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x171>
 1009faa:	mov    %r8,%r15
 1009fad:	sub    $0x18,%r8
 1009fb1:	mov    (%r8),%r8
 1009fb4:	add    $0x1,%r8
 1009fb8:	je     1009fcc <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x15c>
 1009fba:	mov    %r12,%rbx
 1009fbd:	mov    %r15,%r9
 1009fc0:	sub    $0x18,%r9
 1009fc4:	mov    %r8,(%r9)
 1009fc7:	xchg   %rdi,%rbx
 1009fca:	jmp    1009fea <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x17a>
 1009fcc:	mov    $0x2,%esi
 1009fd1:	call   100b020 <myl_qbe_rc_status>
 1009fd6:	mov    %rbx,%rax
 1009fd9:	mov    %rax,%rbx
 1009fdc:	jmp    100a4c1 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x651>
 1009fe1:	mov    %r8,%r15
 1009fe4:	mov    %rdi,%rbx
 1009fe7:	mov    %r12,%rdi
 1009fea:	cmp    $0x0,%esi
 1009fed:	jne    1009ffa <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x18a>
 1009fef:	mov    %r15,%r8
 1009ff2:	mov    %rbx,%rdi
 1009ff5:	jmp    100a12f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2bf>
 1009ffa:	test   $0x1c,%eax
 1009fff:	jne    100a091 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x221>
 100a005:	mov    -0x1a0(%rbp),%rsi
 100a00c:	cmp    $0x0,%rsi
 100a010:	je     100a086 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x216>
 100a012:	mov    %rsi,%rax
 100a015:	sub    $0x10,%rax
 100a019:	mov    (%rax),%rax
 100a01c:	mov    %rdx,%r12
 100a01f:	movabs $0x4000000000000002,%rdx
 100a029:	and    %rdx,%rax
 100a02c:	cmp    $0x0,%rax
 100a030:	jne    100a078 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x208>
 100a032:	mov    %rsi,%rax
 100a035:	sub    $0x20,%rax
 100a039:	mov    (%rax),%rax
 100a03c:	sub    $0x1,%rax
 100a040:	jne    100a06c <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x1fc>
 100a042:	mov    %rcx,%r13
 100a045:	mov    %rsi,%rcx
 100a048:	sub    $0x18,%rcx
 100a04c:	mov    (%rcx),%rcx
 100a04f:	cmp    $0x0,%rcx
 100a053:	jne    100a069 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x1f9>
 100a055:	lea    -0x1a0(%rbp),%rsi
 100a05c:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 100a061:	mov    %r13,%rcx
 100a064:	mov    %r12,%rdx
 100a067:	jmp    100a086 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x216>
 100a069:	mov    %r13,%rcx
 100a06c:	mov    %r12,%rdx
 100a06f:	sub    $0x20,%rsi
 100a073:	mov    %rax,(%rsi)
 100a076:	jmp    100a07b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x20b>
 100a078:	mov    %r12,%rdx
 100a07b:	movq   $0x0,-0x1a0(%rbp)
 100a086:	mov    %r15,%r8
 100a089:	mov    %rbx,%rdi
 100a08c:	jmp    100a12f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2bf>
 100a091:	mov    -0x1a0(%rbp),%rsi
 100a098:	cmp    $0x0,%rsi
 100a09c:	jne    100a0a9 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x239>
 100a09e:	mov    %r15,%r8
 100a0a1:	mov    %rbx,%rdi
 100a0a4:	jmp    100a12f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2bf>
 100a0a9:	mov    %rsi,%rax
 100a0ac:	sub    $0x10,%rax
 100a0b0:	mov    (%rax),%rax
 100a0b3:	mov    %rdx,%r12
 100a0b6:	movabs $0x4000000000000002,%rdx
 100a0c0:	and    %rdx,%rax
 100a0c3:	cmp    $0x0,%rax
 100a0c7:	jne    100a11b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2ab>
 100a0c9:	mov    %rsi,%rax
 100a0cc:	sub    $0x18,%rax
 100a0d0:	mov    (%rax),%rax
 100a0d3:	sub    $0x1,%rax
 100a0d7:	jne    100a109 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x299>
 100a0d9:	mov    %rcx,%r13
 100a0dc:	mov    %rsi,%rcx
 100a0df:	sub    $0x20,%rcx
 100a0e3:	mov    (%rcx),%rcx
 100a0e6:	cmp    $0x0,%rcx
 100a0ea:	jne    100a106 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x296>
 100a0ec:	lea    -0x1a0(%rbp),%rsi
 100a0f3:	call   100ac70 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100a0f8:	mov    %r15,%r8
 100a0fb:	mov    %r13,%rcx
 100a0fe:	mov    %r12,%rdx
 100a101:	mov    %rbx,%rdi
 100a104:	jmp    100a12f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2bf>
 100a106:	mov    %r13,%rcx
 100a109:	mov    %r12,%rdx
 100a10c:	mov    %r15,%r8
 100a10f:	mov    %rbx,%rdi
 100a112:	sub    $0x18,%rsi
 100a116:	mov    %rax,(%rsi)
 100a119:	jmp    100a124 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2b4>
 100a11b:	mov    %r15,%r8
 100a11e:	mov    %r12,%rdx
 100a121:	mov    %rbx,%rdi
 100a124:	movq   $0x0,-0x1a0(%rbp)
 100a12f:	mov    %r8,-0x1a0(%rbp)
 100a136:	mov    %r8,-0xf0(%rbp)
 100a13d:	mov    (%r8),%rsi
 100a140:	movabs $0x7fffffffffffffff,%rax
 100a14a:	cmp    %rax,%rsi
 100a14d:	ja     100ab4d <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcdd>
 100a153:	mov    %rsi,%rbx
 100a156:	mov    %rdi,%rsi
 100a159:	mov    %rcx,%r13
 100a15c:	mov    %rdx,%rcx
 100a15f:	mov    %r14,%rdx
 100a162:	mov    $0xffffffffffffffff,%r12
 100a169:	mov    $0x0,%r14d
 100a16f:	nop
 100a170:	cmp    %rbx,%r14
 100a173:	setl   %al
 100a176:	movzbq %al,%rax
 100a17a:	cmp    $0x0,%eax
 100a17d:	je     100a27a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x40a>
 100a183:	mov    (%r8),%rax
 100a186:	cmp    %rax,%rbx
 100a189:	jne    100a270 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x400>
 100a18f:	cmp    %rax,%r14
 100a192:	jae    100a260 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x3f0>
 100a198:	mov    0x20(%r8),%rax
 100a19c:	mov    %rcx,%r15
 100a19f:	imul   $0x38,%r14,%rcx
 100a1a3:	add    %rax,%rcx
 100a1a6:	mov    %rdx,%rax
 100a1a9:	mov    %r15,%rdx
 100a1ac:	mov    %rsi,%r15
 100a1af:	mov    %rax,%rsi
 100a1b2:	mov    %r15,%rdi
 100a1b5:	call   1009b20 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986>
 100a1ba:	mov    %r15,%rsi
 100a1bd:	mov    -0x18(%rbp),%rcx
 100a1c1:	mov    -0x20(%rbp),%rdx
 100a1c5:	movq   %rax,%xmm0
 100a1ca:	ucomisd -0x8b02(%rip),%xmm0        # 10016d0 <__abi_tag+0x13d4>
 100a1d2:	ja     100a1db <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x36b>
 100a1d4:	mov    $0x0,%edi
 100a1d9:	jmp    100a204 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x394>
 100a1db:	cmp    $0x0,%r12
 100a1df:	setl   %dil
 100a1e3:	movzbq %dil,%rdi
 100a1e7:	movq   %r13,%xmm1
 100a1ec:	ucomisd %xmm0,%xmm1
 100a1f0:	seta   %r8b
 100a1f4:	movzbq %r8b,%r8
 100a1f8:	cmp    $0x0,%edi
 100a1fb:	mov    $0x1,%edi
 100a200:	cmove  %r8,%rdi
 100a204:	cmp    $0x0,%edi
 100a207:	cmovne %r14,%r12
 100a20b:	cmovne %rax,%r13
 100a20f:	mov    -0xf0(%rbp),%r8
 100a216:	mov    (%r8),%rax
 100a219:	cmp    %rax,%rbx
 100a21c:	jne    100a256 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x3e6>
 100a21e:	movabs $0x7ffffffffffffffe,%rax
 100a228:	cmp    %rax,%r14
 100a22b:	jg     100a236 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x3c6>
 100a22d:	add    $0x1,%r14
 100a231:	jmp    100a170 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x300>
 100a236:	mov    %rsi,%rdi
 100a239:	mov    %r14,%rsi
 100a23c:	mov    $0x40,%r8d
 100a242:	mov    $0x1,%ecx
 100a247:	mov    %rsi,%rdx
 100a24a:	mov    $0x0,%esi
 100a24f:	call   100b680 <myl_qbe_fail_overflow_op>
 100a254:	ud2
 100a256:	mov    %rsi,%rdi
 100a259:	call   100b600 <myl_qbe_fail_iteration>
 100a25e:	ud2
 100a260:	mov    %rax,%rdx
 100a263:	mov    %rsi,%rdi
 100a266:	mov    %r14,%rsi
 100a269:	call   100b610 <myl_qbe_fail_normalized_index_bounds>
 100a26e:	ud2
 100a270:	mov    %rsi,%rdi
 100a273:	call   100b600 <myl_qbe_fail_iteration>
 100a278:	ud2
 100a27a:	mov    -0x48(%rbp),%rax
 100a27e:	mov    -0x40(%rbp),%rbx
 100a282:	mov    -0x28(%rbp),%r15
 100a286:	mov    -0x30(%rbp),%r8
 100a28a:	mov    %rdx,%r14
 100a28d:	mov    %rcx,%rdx
 100a290:	mov    %r13,%rcx
 100a293:	mov    %rsi,%rdi
 100a296:	mov    -0x34(%rbp),%esi
 100a299:	cmp    $0x0,%r12
 100a29d:	jl     100aa2a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xbba>
 100a2a3:	cmp    $0x0,%esi
 100a2a6:	jne    100a2c2 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x452>
 100a2a8:	mov    %r8,-0xe8(%rbp)
 100a2af:	movl   $0x0,-0x4c(%rbp)
 100a2b6:	movl   $0x2,-0x50(%rbp)
 100a2bd:	mov    %esi,-0x38(%rbp)
 100a2c0:	jmp    100a2de <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x46e>
 100a2c2:	mov    %r8,-0xe8(%rbp)
 100a2c9:	movl   $0x1,-0x4c(%rbp)
 100a2d0:	movl   $0x8,-0x50(%rbp)
 100a2d7:	movl   $0x0,-0x38(%rbp)
 100a2de:	mov    %r12,%rsi
 100a2e1:	mov    (%r8),%r9
 100a2e4:	cmp    %r9,%rsi
 100a2e7:	jb     100a2f3 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x483>
 100a2e9:	mov    %r9,%rdx
 100a2ec:	call   100b610 <myl_qbe_fail_normalized_index_bounds>
 100a2f1:	ud2
 100a2f3:	mov    %rax,%rbx
 100a2f6:	mov    0x20(%r8),%rax
 100a2fa:	imul   $0x38,%rsi,%rsi
 100a2fe:	mov    (%rax,%rsi,1),%r9
 100a302:	mov    %r9,-0xe0(%rbp)
 100a309:	mov    0x8(%rax,%rsi,1),%r9
 100a30e:	mov    %r9,-0xd8(%rbp)
 100a315:	mov    0x10(%rax,%rsi,1),%r9
 100a31a:	mov    %r9,-0xd0(%rbp)
 100a321:	mov    0x18(%rax,%rsi,1),%r9
 100a326:	mov    %r9,-0xc8(%rbp)
 100a32d:	mov    0x20(%rax,%rsi,1),%r9
 100a332:	mov    %r9,-0xc0(%rbp)
 100a339:	mov    %r8,%r12
 100a33c:	mov    0x28(%rax,%rsi,1),%r8
 100a341:	mov    %r8,-0xb8(%rbp)
 100a348:	mov    0x30(%rax,%rsi,1),%rax
 100a34d:	mov    %rax,-0xb0(%rbp)
 100a354:	mov    %rdi,%rsi
 100a357:	mov    %rdi,%r13
 100a35a:	lea    -0x1e8(%rbp),%rdi
 100a361:	call   100abe0 <myl_f_f469802a31447f90d6a033d43f18db7ebfbee7cc3c378024bcc0f1573d3feef8>
 100a366:	mov    %r14,%rdx
 100a369:	mov    %r13,%rdi
 100a36c:	mov    %rax,%rcx
 100a36f:	mov    -0x40(%rbp),%r14
 100a373:	mov    %rdi,%rsi
 100a376:	mov    %rdi,%r13
 100a379:	lea    -0x200(%rbp),%rdi
 100a380:	call   1009d50 <myl_f_7e9e5ac30f2216fd0fd6f5faed316f2d5983361a4203c3330cfa46ef65bb4767>
 100a385:	mov    %r13,%rdi
 100a388:	mov    (%rax),%rcx
 100a38b:	mov    %rcx,-0xa8(%rbp)
 100a392:	mov    0x8(%rax),%rcx
 100a396:	mov    %rcx,-0xa0(%rbp)
 100a39d:	mov    0x10(%rax),%rax
 100a3a1:	mov    %rax,-0x98(%rbp)
 100a3a8:	lea    -0xe0(%rbp),%rcx
 100a3af:	lea    -0xa8(%rbp),%rdx
 100a3b6:	mov    %rdi,%rsi
 100a3b9:	mov    %rdi,%r13
 100a3bc:	lea    -0x218(%rbp),%rdi
 100a3c3:	call   1009de0 <myl_f_ddc6e2b224d0fd821669202258386936fc9ce2899e215eec6322b95f8dd96d6a>
 100a3c8:	mov    %r13,%rdi
 100a3cb:	mov    %rax,%rdx
 100a3ce:	mov    %rdi,%rsi
 100a3d1:	mov    %rdi,%r13
 100a3d4:	lea    -0x230(%rbp),%rdi
 100a3db:	call   1009cb0 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380>
 100a3e0:	mov    %r13,%rdi
 100a3e3:	mov    (%rax),%rcx
 100a3e6:	mov    %rcx,-0x90(%rbp)
 100a3ed:	mov    0x8(%rax),%rcx
 100a3f1:	mov    %rcx,-0x88(%rbp)
 100a3f8:	mov    0x10(%rax),%rax
 100a3fc:	mov    %rax,-0x80(%rbp)
 100a400:	mov    %r15,%rdx
 100a403:	lea    -0x90(%rbp),%rsi
 100a40a:	mov    %rdi,%r13
 100a40d:	call   100ab60 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>
 100a412:	mov    %r13,%rdi
 100a415:	mov    %rax,%rdx
 100a418:	mov    %rbx,%rax
 100a41b:	mov    %rax,%rbx
 100a41e:	mov    -0x38(%rbp),%eax
 100a421:	movq   %rdx,%xmm0
 100a426:	movsd  -0x8d5e(%rip),%xmm1        # 10016d0 <__abi_tag+0x13d4>
 100a42e:	ucomisd %xmm0,%xmm1
 100a432:	mov    $0x0,%ecx
 100a437:	mov    %rcx,%r13
 100a43a:	cmovbe %rdx,%r13
 100a43e:	movq   %r13,%xmm0
 100a443:	ucomisd -0x8d7b(%rip),%xmm0        # 10016d0 <__abi_tag+0x13d4>
 100a44b:	ja     100a467 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x5f7>
 100a44d:	mov    %rbx,%rax
 100a450:	mov    $0x0,%r15d
 100a456:	mov    %r13,%rbx
 100a459:	mov    %r14,%r13
 100a45c:	mov    $0x2,%r14d
 100a462:	jmp    100a6c3 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x853>
 100a467:	cmp    $0x0,%r12
 100a46b:	jne    100a478 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x608>
 100a46d:	mov    %rdi,%rbx
 100a470:	mov    %r14,%rdi
 100a473:	jmp    100a505 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x695>
 100a478:	mov    %r12,%rcx
 100a47b:	sub    $0x10,%rcx
 100a47f:	mov    (%rcx),%rcx
 100a482:	movabs $0x4000000000000002,%rdx
 100a48c:	and    %rdx,%rcx
 100a48f:	cmp    $0x0,%rcx
 100a493:	jne    100a4ff <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x68f>
 100a495:	mov    %r12,%rcx
 100a498:	sub    $0x18,%rcx
 100a49c:	mov    (%rcx),%rcx
 100a49f:	add    $0x1,%rcx
 100a4a3:	je     100a4b7 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x647>
 100a4a5:	mov    %r14,%rbx
 100a4a8:	mov    %r12,%rdx
 100a4ab:	sub    $0x18,%rdx
 100a4af:	mov    %rcx,(%rdx)
 100a4b2:	xchg   %rdi,%rbx
 100a4b5:	jmp    100a505 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x695>
 100a4b7:	mov    $0x2,%esi
 100a4bc:	call   100b020 <myl_qbe_rc_status>
 100a4c1:	mov    $0x18,%edx
 100a4c6:	mov    $0x0,%esi
 100a4cb:	lea    -0x1b8(%rbp),%rdi
 100a4d2:	call   101e4a0 <compiler_rt.fastMemset>
 100a4d7:	mov    %rbx,%rax
 100a4da:	mov    -0x1b8(%rbp),%rcx
 100a4e1:	mov    %rcx,(%rax)
 100a4e4:	mov    -0x1b0(%rbp),%rcx
 100a4eb:	mov    %rcx,0x8(%rax)
 100a4ef:	mov    -0x1a8(%rbp),%rcx
 100a4f6:	mov    %rcx,0x10(%rax)
 100a4fa:	jmp    100ab42 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcd2>
 100a4ff:	mov    %rdi,%rbx
 100a502:	mov    %r14,%rdi
 100a505:	cmp    $0x0,%eax
 100a508:	jne    100a515 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x6a5>
 100a50a:	mov    %r12,%r8
 100a50d:	mov    %rbx,%rdi
 100a510:	jmp    100a59b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x72b>
 100a515:	mov    -0x1a0(%rbp),%rcx
 100a51c:	cmp    $0x0,%rcx
 100a520:	jne    100a52a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x6ba>
 100a522:	mov    %r12,%r8
 100a525:	mov    %rbx,%rdi
 100a528:	jmp    100a59b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x72b>
 100a52a:	mov    %rcx,%rax
 100a52d:	sub    $0x10,%rax
 100a531:	mov    (%rax),%rax
 100a534:	movabs $0x4000000000000002,%rdx
 100a53e:	and    %rdx,%rax
 100a541:	cmp    $0x0,%rax
 100a545:	jne    100a58a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x71a>
 100a547:	mov    %rcx,%rax
 100a54a:	sub    $0x18,%rax
 100a54e:	mov    (%rax),%rax
 100a551:	sub    $0x1,%rax
 100a555:	jne    100a57b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x70b>
 100a557:	mov    %rcx,%rdx
 100a55a:	sub    $0x20,%rdx
 100a55e:	mov    (%rdx),%rdx
 100a561:	cmp    $0x0,%rdx
 100a565:	jne    100a57b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x70b>
 100a567:	lea    -0x1a0(%rbp),%rsi
 100a56e:	call   100ac70 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100a573:	mov    %r12,%r8
 100a576:	mov    %rbx,%rdi
 100a579:	jmp    100a59b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x72b>
 100a57b:	mov    %r12,%r8
 100a57e:	mov    %rbx,%rdi
 100a581:	sub    $0x18,%rcx
 100a585:	mov    %rax,(%rcx)
 100a588:	jmp    100a590 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x720>
 100a58a:	mov    %r12,%r8
 100a58d:	mov    %rbx,%rdi
 100a590:	movq   $0x0,-0x1a0(%rbp)
 100a59b:	mov    %r8,-0x1a0(%rbp)
 100a5a2:	mov    %r8,-0x78(%rbp)
 100a5a6:	mov    (%r8),%rsi
 100a5a9:	movabs $0x7fffffffffffffff,%rax
 100a5b3:	cmp    %rax,%rsi
 100a5b6:	ja     100aa1e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xbae>
 100a5bc:	mov    %rsi,%rbx
 100a5bf:	mov    %rdi,%rsi
 100a5c2:	mov    $0x0,%r12d
 100a5c8:	nopl   0x0(%rax,%rax,1)
 100a5d0:	cmp    %rbx,%r12
 100a5d3:	jge    100a6a9 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x839>
 100a5d9:	mov    (%r8),%rax
 100a5dc:	cmp    %rax,%rbx
 100a5df:	jne    100a69f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x82f>
 100a5e5:	cmp    %rax,%r12
 100a5e8:	jae    100a68f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x81f>
 100a5ee:	mov    0x20(%r8),%rax
 100a5f2:	imul   $0x38,%r12,%rcx
 100a5f6:	add    %rax,%rcx
 100a5f9:	mov    %r15,%rdx
 100a5fc:	mov    %rsi,%r14
 100a5ff:	lea    -0xa8(%rbp),%rsi
 100a606:	mov    %r14,%rdi
 100a609:	call   1009b20 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986>
 100a60e:	mov    %r15,%r9
 100a611:	mov    %r14,%rsi
 100a614:	movq   %rax,%xmm0
 100a619:	ucomisd -0x8f51(%rip),%xmm0        # 10016d0 <__abi_tag+0x13d4>
 100a621:	ja     100a671 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x801>
 100a623:	mov    -0x78(%rbp),%r8
 100a627:	mov    (%r8),%rax
 100a62a:	cmp    %rax,%rbx
 100a62d:	jne    100a667 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x7f7>
 100a62f:	movabs $0x7ffffffffffffffe,%rax
 100a639:	cmp    %rax,%r12
 100a63c:	jg     100a647 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x7d7>
 100a63e:	add    $0x1,%r12
 100a642:	mov    %r9,%r15
 100a645:	jmp    100a5d0 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x760>
 100a647:	mov    %rsi,%rdi
 100a64a:	mov    %r12,%rsi
 100a64d:	mov    $0x40,%r8d
 100a653:	mov    $0x1,%ecx
 100a658:	mov    %rsi,%rdx
 100a65b:	mov    $0x0,%esi
 100a660:	call   100b680 <myl_qbe_fail_overflow_op>
 100a665:	ud2
 100a667:	mov    %rsi,%rdi
 100a66a:	call   100b600 <myl_qbe_fail_iteration>
 100a66f:	ud2
 100a671:	mov    -0x48(%rbp),%rax
 100a675:	mov    -0x40(%rbp),%r13
 100a679:	mov    %rsi,%rdi
 100a67c:	mov    $0x1,%r15d
 100a682:	mov    $0x8,%r14d
 100a688:	mov    $0x0,%ebx
 100a68d:	jmp    100a6c3 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x853>
 100a68f:	mov    %rax,%rdx
 100a692:	mov    %rsi,%rdi
 100a695:	mov    %r12,%rsi
 100a698:	call   100b610 <myl_qbe_fail_normalized_index_bounds>
 100a69d:	ud2
 100a69f:	mov    %rsi,%rdi
 100a6a2:	call   100b600 <myl_qbe_fail_iteration>
 100a6a7:	ud2
 100a6a9:	mov    -0x48(%rbp),%rax
 100a6ad:	mov    %rsi,%rdi
 100a6b0:	mov    $0x1,%r15d
 100a6b6:	mov    $0x8,%r14d
 100a6bc:	mov    %r13,%rbx
 100a6bf:	mov    -0x40(%rbp),%r13
 100a6c3:	lea    -0xe0(%rbp),%rcx
 100a6ca:	mov    %rcx,%rdx
 100a6cd:	add    $0x20,%rdx
 100a6d1:	movq   %rbx,%xmm0
 100a6d6:	mulsd  -0x8ff6(%rip),%xmm0        # 10016e8 <__abi_tag+0x13ec>
 100a6de:	mov    %rax,%rbx
 100a6e1:	movq   %xmm0,%rax
 100a6e6:	movq   %rax,%xmm0
 100a6eb:	addsd  -0x9013(%rip),%xmm0        # 10016e0 <__abi_tag+0x13e4>
 100a6f3:	movq   %xmm0,%rcx
 100a6f8:	mov    %rdi,%rsi
 100a6fb:	mov    %rdi,%r12
 100a6fe:	lea    -0x1d0(%rbp),%rdi
 100a705:	call   100abe0 <myl_f_f469802a31447f90d6a033d43f18db7ebfbee7cc3c378024bcc0f1573d3feef8>
 100a70a:	mov    %r12,%rdi
 100a70d:	xchg   %rax,%rbx
 100a70f:	mov    -0x4c(%rbp),%ecx
 100a712:	mov    -0x50(%rbp),%r12d
 100a716:	mov    -0x150(%rbp),%edx
 100a71c:	mov    -0x130(%rbp),%esi
 100a722:	or     %esi,%edx
 100a724:	mov    -0x110(%rbp),%esi
 100a72a:	or     %esi,%edx
 100a72c:	jne    100a736 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x8c6>
 100a72e:	mov    %r13,%rdi
 100a731:	mov    %ecx,%r13d
 100a734:	jmp    100a782 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x912>
 100a736:	lea    -0x168(%rbp),%rcx
 100a73d:	mov    %rcx,-0x108(%rbp)
 100a744:	lea    -0x148(%rbp),%rcx
 100a74b:	mov    %rcx,-0x100(%rbp)
 100a752:	mov    %rax,%r12
 100a755:	lea    -0x128(%rbp),%rax
 100a75c:	mov    %rax,-0xf8(%rbp)
 100a763:	mov    $0x3,%edx
 100a768:	lea    -0x108(%rbp),%rsi
 100a76f:	call   100b160 <myl_qbe_rc_scopes_close>
 100a774:	mov    %r13,%rdi
 100a777:	mov    %r12,%rax
 100a77a:	mov    -0x4c(%rbp),%r13d
 100a77e:	mov    -0x50(%rbp),%r12d
 100a782:	cmp    $0x0,%r15d
 100a786:	je     100a87e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a78c:	test   $0x1c,%r14d
 100a793:	jne    100a80e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x99e>
 100a795:	mov    -0x78(%rbp),%rdx
 100a799:	cmp    $0x0,%rdx
 100a79d:	je     100a87e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a7a3:	mov    %rdx,%rcx
 100a7a6:	sub    $0x10,%rcx
 100a7aa:	mov    (%rcx),%rcx
 100a7ad:	movabs $0x4000000000000002,%rsi
 100a7b7:	and    %rsi,%rcx
 100a7ba:	cmp    $0x0,%rcx
 100a7be:	jne    100a804 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x994>
 100a7c0:	mov    %rdx,%rcx
 100a7c3:	sub    $0x20,%rcx
 100a7c7:	mov    (%rcx),%rcx
 100a7ca:	sub    $0x1,%rcx
 100a7ce:	jne    100a7fd <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x98d>
 100a7d0:	mov    %rax,%r14
 100a7d3:	mov    %rdx,%rax
 100a7d6:	sub    $0x18,%rax
 100a7da:	mov    (%rax),%rax
 100a7dd:	cmp    $0x0,%rax
 100a7e1:	jne    100a7fa <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x98a>
 100a7e3:	lea    -0x78(%rbp),%rsi
 100a7e7:	mov    %rdi,%r15
 100a7ea:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 100a7ef:	mov    %r15,%rdi
 100a7f2:	mov    %r14,%rax
 100a7f5:	jmp    100a87e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a7fa:	mov    %r14,%rax
 100a7fd:	sub    $0x20,%rdx
 100a801:	mov    %rcx,(%rdx)
 100a804:	movq   $0x0,-0x78(%rbp)
 100a80c:	jmp    100a87e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a80e:	mov    -0x78(%rbp),%rdx
 100a812:	cmp    $0x0,%rdx
 100a816:	je     100a87e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a818:	mov    %rdx,%rcx
 100a81b:	sub    $0x10,%rcx
 100a81f:	mov    (%rcx),%rcx
 100a822:	movabs $0x4000000000000002,%rsi
 100a82c:	and    %rsi,%rcx
 100a82f:	cmp    $0x0,%rcx
 100a833:	jne    100a876 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa06>
 100a835:	mov    %rdx,%rcx
 100a838:	sub    $0x18,%rcx
 100a83c:	mov    (%rcx),%rcx
 100a83f:	sub    $0x1,%rcx
 100a843:	jne    100a86f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x9ff>
 100a845:	mov    %rax,%r14
 100a848:	mov    %rdx,%rax
 100a84b:	sub    $0x20,%rax
 100a84f:	mov    (%rax),%rax
 100a852:	cmp    $0x0,%rax
 100a856:	jne    100a86c <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x9fc>
 100a858:	lea    -0x78(%rbp),%rsi
 100a85c:	mov    %rdi,%r15
 100a85f:	call   100ac70 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100a864:	mov    %r15,%rdi
 100a867:	mov    %r14,%rax
 100a86a:	jmp    100a87e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a86c:	mov    %r14,%rax
 100a86f:	sub    $0x18,%rdx
 100a873:	mov    %rcx,(%rdx)
 100a876:	movq   $0x0,-0x78(%rbp)
 100a87e:	cmp    $0x0,%r13d
 100a882:	je     100a990 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a888:	test   $0x1c,%r12d
 100a88f:	jne    100a917 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xaa7>
 100a895:	mov    -0xe8(%rbp),%rdx
 100a89c:	cmp    $0x0,%rdx
 100a8a0:	je     100a990 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a8a6:	mov    %rdx,%rcx
 100a8a9:	sub    $0x10,%rcx
 100a8ad:	mov    (%rcx),%rcx
 100a8b0:	movabs $0x4000000000000002,%rsi
 100a8ba:	and    %rsi,%rcx
 100a8bd:	cmp    $0x0,%rcx
 100a8c1:	jne    100a90a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa9a>
 100a8c3:	mov    %rdx,%rcx
 100a8c6:	sub    $0x20,%rcx
 100a8ca:	mov    (%rcx),%rcx
 100a8cd:	sub    $0x1,%rcx
 100a8d1:	jne    100a903 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa93>
 100a8d3:	mov    %rax,%r12
 100a8d6:	mov    %rdx,%rax
 100a8d9:	sub    $0x18,%rax
 100a8dd:	mov    (%rax),%rax
 100a8e0:	cmp    $0x0,%rax
 100a8e4:	jne    100a900 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa90>
 100a8e6:	lea    -0xe8(%rbp),%rsi
 100a8ed:	mov    %rdi,%r13
 100a8f0:	call   100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 100a8f5:	mov    %r13,%rdi
 100a8f8:	mov    %r12,%rax
 100a8fb:	jmp    100a990 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a900:	mov    %r12,%rax
 100a903:	sub    $0x20,%rdx
 100a907:	mov    %rcx,(%rdx)
 100a90a:	movq   $0x0,-0xe8(%rbp)
 100a915:	jmp    100a990 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a917:	mov    -0xe8(%rbp),%rdx
 100a91e:	cmp    $0x0,%rdx
 100a922:	je     100a990 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a924:	mov    %rdx,%rcx
 100a927:	sub    $0x10,%rcx
 100a92b:	mov    (%rcx),%rcx
 100a92e:	movabs $0x4000000000000002,%rsi
 100a938:	and    %rsi,%rcx
 100a93b:	cmp    $0x0,%rcx
 100a93f:	jne    100a985 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb15>
 100a941:	mov    %rdx,%rcx
 100a944:	sub    $0x18,%rcx
 100a948:	mov    (%rcx),%rcx
 100a94b:	sub    $0x1,%rcx
 100a94f:	jne    100a97e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb0e>
 100a951:	mov    %rax,%r12
 100a954:	mov    %rdx,%rax
 100a957:	sub    $0x20,%rax
 100a95b:	mov    (%rax),%rax
 100a95e:	cmp    $0x0,%rax
 100a962:	jne    100a97b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb0b>
 100a964:	lea    -0xe8(%rbp),%rsi
 100a96b:	mov    %rdi,%r13
 100a96e:	call   100ac70 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100a973:	mov    %r13,%rdi
 100a976:	mov    %r12,%rax
 100a979:	jmp    100a990 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a97b:	mov    %r12,%rax
 100a97e:	sub    $0x18,%rdx
 100a982:	mov    %rcx,(%rdx)
 100a985:	movq   $0x0,-0xe8(%rbp)
 100a990:	mov    -0xf0(%rbp),%rdx
 100a997:	cmp    $0x0,%rdx
 100a99b:	je     100aa03 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb93>
 100a99d:	mov    %rdx,%rcx
 100a9a0:	sub    $0x10,%rcx
 100a9a4:	mov    (%rcx),%rcx
 100a9a7:	movabs $0x4000000000000002,%rsi
 100a9b1:	and    %rsi,%rcx
 100a9b4:	cmp    $0x0,%rcx
 100a9b8:	jne    100a9f8 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb88>
 100a9ba:	mov    %rdx,%rcx
 100a9bd:	sub    $0x18,%rcx
 100a9c1:	mov    (%rcx),%rcx
 100a9c4:	sub    $0x1,%rcx
 100a9c8:	jne    100a9f1 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb81>
 100a9ca:	mov    %rax,%r12
 100a9cd:	mov    %rdx,%rax
 100a9d0:	sub    $0x20,%rax
 100a9d4:	mov    (%rax),%rax
 100a9d7:	cmp    $0x0,%rax
 100a9db:	jne    100a9ee <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb7e>
 100a9dd:	lea    -0xf0(%rbp),%rsi
 100a9e4:	call   100ac70 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100a9e9:	mov    %r12,%rax
 100a9ec:	jmp    100aa03 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb93>
 100a9ee:	mov    %r12,%rax
 100a9f1:	sub    $0x18,%rdx
 100a9f5:	mov    %rcx,(%rdx)
 100a9f8:	movq   $0x0,-0xf0(%rbp)
 100aa03:	mov    (%rbx),%rcx
 100aa06:	mov    %rcx,(%rax)
 100aa09:	mov    0x8(%rbx),%rcx
 100aa0d:	mov    %rcx,0x8(%rax)
 100aa11:	mov    0x10(%rbx),%rcx
 100aa15:	mov    %rcx,0x10(%rax)
 100aa19:	jmp    100ab42 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcd2>
 100aa1e:	mov    $0x140,%edx
 100aa23:	call   100b7c0 <myl_qbe_fail_cast>
 100aa28:	ud2
 100aa2a:	mov    %rbx,%r12
 100aa2d:	movabs $0x3fe3333333333333,%rcx
 100aa37:	mov    %rcx,-0x70(%rbp)
 100aa3b:	movabs $0x3fe6666666666666,%rcx
 100aa45:	mov    %rcx,-0x68(%rbp)
 100aa49:	movabs $0x3feccccccccccccd,%rcx
 100aa53:	mov    %rcx,-0x60(%rbp)
 100aa57:	mov    -0x150(%rbp),%ecx
 100aa5d:	mov    -0x130(%rbp),%edx
 100aa63:	or     %edx,%ecx
 100aa65:	mov    -0x110(%rbp),%edx
 100aa6b:	or     %edx,%ecx
 100aa6d:	jne    100aa74 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xc04>
 100aa6f:	mov    %r12,%rdi
 100aa72:	jmp    100aab8 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xc48>
 100aa74:	lea    -0x168(%rbp),%rcx
 100aa7b:	mov    %rcx,-0x108(%rbp)
 100aa82:	lea    -0x148(%rbp),%rcx
 100aa89:	mov    %rcx,-0x100(%rbp)
 100aa90:	mov    %rax,%rbx
 100aa93:	lea    -0x128(%rbp),%rax
 100aa9a:	mov    %rax,-0xf8(%rbp)
 100aaa1:	mov    $0x3,%edx
 100aaa6:	lea    -0x108(%rbp),%rsi
 100aaad:	call   100b160 <myl_qbe_rc_scopes_close>
 100aab2:	mov    %r12,%rdi
 100aab5:	mov    %rbx,%rax
 100aab8:	mov    -0xf0(%rbp),%rdx
 100aabf:	cmp    $0x0,%rdx
 100aac3:	je     100ab2b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcbb>
 100aac5:	mov    %rdx,%rcx
 100aac8:	sub    $0x10,%rcx
 100aacc:	mov    (%rcx),%rcx
 100aacf:	movabs $0x4000000000000002,%rsi
 100aad9:	and    %rsi,%rcx
 100aadc:	cmp    $0x0,%rcx
 100aae0:	jne    100ab20 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcb0>
 100aae2:	mov    %rdx,%rcx
 100aae5:	sub    $0x18,%rcx
 100aae9:	mov    (%rcx),%rcx
 100aaec:	sub    $0x1,%rcx
 100aaf0:	jne    100ab19 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xca9>
 100aaf2:	mov    %rax,%rbx
 100aaf5:	mov    %rdx,%rax
 100aaf8:	sub    $0x20,%rax
 100aafc:	mov    (%rax),%rax
 100aaff:	cmp    $0x0,%rax
 100ab03:	jne    100ab16 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xca6>
 100ab05:	lea    -0xf0(%rbp),%rsi
 100ab0c:	call   100ac70 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100ab11:	mov    %rbx,%rax
 100ab14:	jmp    100ab2b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcbb>
 100ab16:	mov    %rbx,%rax
 100ab19:	sub    $0x18,%rdx
 100ab1d:	mov    %rcx,(%rdx)
 100ab20:	movq   $0x0,-0xf0(%rbp)
 100ab2b:	mov    -0x70(%rbp),%rcx
 100ab2f:	mov    %rcx,(%rax)
 100ab32:	mov    -0x68(%rbp),%rcx
 100ab36:	mov    %rcx,0x8(%rax)
 100ab3a:	mov    -0x60(%rbp),%rcx
 100ab3e:	mov    %rcx,0x10(%rax)
 100ab42:	pop    %r15
 100ab44:	pop    %r14
 100ab46:	pop    %r13
 100ab48:	pop    %r12
 100ab4a:	pop    %rbx
 100ab4b:	leave
 100ab4c:	ret
 100ab4d:	mov    $0x140,%edx
 100ab52:	call   100b7c0 <myl_qbe_fail_cast>
 100ab57:	ud2
 100ab59:	call   100b840 <myl_qbe_fail_frame>
 100ab5e:	ud2

000000000100ab60 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>:
 100ab60:	endbr64
 100ab64:	mov    %rdx,%rax
 100ab67:	mov    (%rsi),%rdx
 100ab6a:	mov    (%rax),%rcx
 100ab6d:	movq   %rdx,%xmm0
 100ab72:	movq   %rcx,%xmm1
 100ab77:	mulsd  %xmm1,%xmm0
 100ab7b:	movq   %xmm0,%rdx
 100ab80:	mov    0x8(%rsi),%rdi
 100ab84:	mov    0x8(%rax),%rcx
 100ab88:	movq   %rdi,%xmm0
 100ab8d:	movq   %rcx,%xmm1
 100ab92:	mulsd  %xmm1,%xmm0
 100ab96:	movq   %xmm0,%rcx
 100ab9b:	movq   %rdx,%xmm0
 100aba0:	movq   %rcx,%xmm1
 100aba5:	addsd  %xmm1,%xmm0
 100aba9:	movq   %xmm0,%rcx
 100abae:	mov    0x10(%rsi),%rdx
 100abb2:	mov    0x10(%rax),%rax
 100abb6:	movq   %rdx,%xmm0
 100abbb:	movq   %rax,%xmm1
 100abc0:	mulsd  %xmm1,%xmm0
 100abc4:	movq   %xmm0,%rax
 100abc9:	movq   %rcx,%xmm0
 100abce:	movq   %rax,%xmm1
 100abd3:	addsd  %xmm1,%xmm0
 100abd7:	movq   %xmm0,%rax
 100abdc:	ret
 100abdd:	int3
 100abde:	int3
 100abdf:	int3

000000000100abe0 <myl_f_f469802a31447f90d6a033d43f18db7ebfbee7cc3c378024bcc0f1573d3feef8>:
 100abe0:	endbr64
 100abe4:	push   %rbp
 100abe5:	mov    %rsp,%rbp
 100abe8:	sub    $0x20,%rsp
 100abec:	xchg   %rdx,%rcx
 100abef:	mov    %rdi,%rax
 100abf2:	mov    (%rcx),%rsi
 100abf5:	movq   %rsi,%xmm1
 100abfa:	movq   %rdx,%xmm0
 100abff:	mulsd  %xmm0,%xmm1
 100ac03:	movq   %xmm1,%rsi
 100ac08:	mov    0x8(%rcx),%rdx
 100ac0c:	movq   %rdx,%xmm1
 100ac11:	mulsd  %xmm0,%xmm1
 100ac15:	movq   %xmm1,%rdx
 100ac1a:	mov    0x10(%rcx),%rcx
 100ac1e:	movq   %rcx,%xmm1
 100ac23:	mulsd  %xmm1,%xmm0
 100ac27:	movq   %xmm0,%rcx
 100ac2c:	mov    %rsi,-0x18(%rbp)
 100ac30:	mov    %rdx,-0x10(%rbp)
 100ac34:	mov    %rcx,-0x8(%rbp)
 100ac38:	mov    -0x18(%rbp),%rcx
 100ac3c:	mov    %rcx,(%rax)
 100ac3f:	mov    -0x10(%rbp),%rcx
 100ac43:	mov    %rcx,0x8(%rax)
 100ac47:	mov    -0x8(%rbp),%rcx
 100ac4b:	mov    %rcx,0x10(%rax)
 100ac4f:	leave
 100ac50:	ret
 100ac51:	int3
 100ac52:	int3
 100ac53:	int3
 100ac54:	int3
 100ac55:	int3
 100ac56:	int3
 100ac57:	int3
 100ac58:	int3
 100ac59:	int3
 100ac5a:	int3
 100ac5b:	int3
 100ac5c:	int3
 100ac5d:	int3
 100ac5e:	int3
 100ac5f:	int3

000000000100ac60 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>:
 100ac60:	mov    $0x8,%ecx
 100ac65:	mov    $0x1,%r8d
 100ac6b:	jmp    1017170 <myl_print_integer>

000000000100ac70 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>:
 100ac70:	mov    (%rsi),%rax
 100ac73:	movq   $0x0,(%rsi)
 100ac7a:	test   %rax,%rax
 100ac7d:	je     100ac8f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan+0x1f>
 100ac7f:	movabs $0x4000000000000002,%rcx
 100ac89:	test   %rcx,-0x10(%rax)
 100ac8d:	je     100ac97 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan+0x27>
 100ac8f:	movq   $0x0,(%rsi)
 100ac96:	ret
 100ac97:	mov    -0x18(%rax),%rcx
 100ac9b:	cmp    $0x1,%rcx
 100ac9f:	jne    100aca8 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan+0x38>
 100aca1:	cmpq   $0x0,-0x20(%rax)
 100aca6:	je     100acb7 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan+0x47>
 100aca8:	dec    %rcx
 100acab:	mov    %rcx,-0x18(%rax)
 100acaf:	movq   $0x0,(%rsi)
 100acb6:	ret
 100acb7:	push   %rbp
 100acb8:	mov    %rsp,%rbp
 100acbb:	push   %r14
 100acbd:	push   %rbx
 100acbe:	mov    %rdi,%rbx
 100acc1:	mov    %rsi,%r14
 100acc4:	mov    %rax,%rsi
 100acc7:	call   1012bf0 <myl_rc_hold_edge_release>
 100accc:	movq   $0x0,(%r14)
 100acd3:	mov    %rbx,%rdi
 100acd6:	pop    %rbx
 100acd7:	pop    %r14
 100acd9:	pop    %rbp
 100acda:	jmp    1016000 <myl_rc_drain>
 100acdf:	int3

000000000100ace0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>:
 100ace0:	mov    (%rsi),%rax
 100ace3:	movq   $0x0,(%rsi)
 100acea:	test   %rax,%rax
 100aced:	je     100acff <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x1f>
 100acef:	movabs $0x4000000000000002,%rcx
 100acf9:	test   %rcx,-0x10(%rax)
 100acfd:	je     100ad07 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x27>
 100acff:	movq   $0x0,(%rsi)
 100ad06:	ret
 100ad07:	mov    -0x20(%rax),%rcx
 100ad0b:	cmp    $0x1,%rcx
 100ad0f:	jne    100ad18 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x38>
 100ad11:	cmpq   $0x0,-0x18(%rax)
 100ad16:	je     100ad27 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x47>
 100ad18:	dec    %rcx
 100ad1b:	mov    %rcx,-0x20(%rax)
 100ad1f:	movq   $0x0,(%rsi)
 100ad26:	ret
 100ad27:	push   %rbp
 100ad28:	mov    %rsp,%rbp
 100ad2b:	push   %r14
 100ad2d:	push   %rbx
 100ad2e:	mov    %rdi,%rbx
 100ad31:	mov    %rsi,%r14
 100ad34:	mov    %rax,%rsi
 100ad37:	call   10129a0 <myl_rc_edge_release>
 100ad3c:	movq   $0x0,(%r14)
 100ad43:	mov    %rbx,%rdi
 100ad46:	pop    %rbx
 100ad47:	pop    %r14
 100ad49:	pop    %rbp
 100ad4a:	jmp    1016000 <myl_rc_drain>
 100ad4f:	int3

000000000100ad50 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>:
 100ad50:	mov    %ecx,%r8d
 100ad53:	mov    %rdx,%rcx
 100ad56:	mov    %rsi,%rdx
 100ad59:	mov    (%rcx),%rax
 100ad5c:	test   %rax,%rax
 100ad5f:	je     100ad86 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain+0x36>
 100ad61:	mov    -0x10(%rax),%rsi
 100ad65:	bt     $0x3e,%rsi
 100ad6a:	jb     100ad8f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain+0x3f>
 100ad6c:	test   $0x2,%sil
 100ad70:	jne    100ad86 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain+0x36>
 100ad72:	mov    -0x20(%rax),%rsi
 100ad76:	cmp    $0xffffffffffffffff,%rsi
 100ad7a:	je     100ad8f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain+0x3f>
 100ad7c:	inc    %rsi
 100ad7f:	mov    %rsi,-0x20(%rax)
 100ad83:	mov    (%rcx),%rax
 100ad86:	mov    %rax,(%rdx)
 100ad89:	mov    $0x1,%eax
 100ad8e:	ret
 100ad8f:	lea    0x1bb0a(%rip),%rsi        # 10268a0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 100ad96:	jmp    101dec0 <myl_rc_native_retain>
 100ad9b:	int3
 100ad9c:	int3
 100ad9d:	int3
 100ad9e:	int3
 100ad9f:	int3

000000000100ada0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take>:
 100ada0:	mov    %ecx,%r8d
 100ada3:	mov    %rdx,%rcx
 100ada6:	mov    %rsi,%rdx
 100ada9:	mov    (%rcx),%rax
 100adac:	test   %rax,%rax
 100adaf:	je     100adb7 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take+0x17>
 100adb1:	testb  $0x50,-0x9(%rax)
 100adb5:	jne    100addd <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take+0x3d>
 100adb7:	mov    %rdx,%rsi
 100adba:	sub    %rcx,%rsi
 100adbd:	mov    %rcx,%r9
 100adc0:	sub    %rdx,%r9
 100adc3:	cmovb  %rsi,%r9
 100adc7:	cmp    $0x7,%r9
 100adcb:	jbe    100addd <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take+0x3d>
 100adcd:	mov    %rax,(%rdx)
 100add0:	movq   $0x0,(%rcx)
 100add7:	mov    $0x1,%eax
 100addc:	ret
 100addd:	lea    0x1babc(%rip),%rsi        # 10268a0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 100ade4:	jmp    101dbd0 <myl_rc_native_take>
 100ade9:	int3
 100adea:	int3
 100adeb:	int3
 100adec:	int3
 100aded:	int3
 100adee:	int3
 100adef:	int3

000000000100adf0 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>:
 100adf0:	mov    (%rsi),%rax
 100adf3:	cmp    0x8(%rsi),%rax
 100adf7:	jae    1011780 <myl_rc_list_append>
 100adfd:	cmpq   $0xffffffffffffffff,0x10(%rsi)
 100ae02:	je     1011780 <myl_rc_list_append>
 100ae08:	mov    0x20(%rsi),%rcx
 100ae0c:	mov    %rdx,%r9
 100ae0f:	sub    %rcx,%r9
 100ae12:	imul   $0x38,%rax,%r8
 100ae16:	cmp    %r8,%r9
 100ae19:	jb     1011780 <myl_rc_list_append>
 100ae1f:	vmovups (%rdx),%ymm0
 100ae23:	vmovups 0x18(%rdx),%ymm1
 100ae28:	vmovups %ymm1,0x18(%rcx,%r8,1)
 100ae2f:	vmovups %ymm0,(%rcx,%r8,1)
 100ae35:	inc    %rax
 100ae38:	mov    %rax,(%rsi)
 100ae3b:	incq   0x10(%rsi)
 100ae3f:	mov    $0x1,%eax
 100ae44:	vzeroupper
 100ae47:	ret
 100ae48:	int3
 100ae49:	int3
 100ae4a:	int3
 100ae4b:	int3
 100ae4c:	int3
 100ae4d:	int3
 100ae4e:	int3
 100ae4f:	int3

000000000100ae50 <myl_qbe_host_begin>:
 100ae50:	push   %rbp
 100ae51:	mov    %rsp,%rbp
 100ae54:	push   %rbx
 100ae55:	push   %rax
 100ae56:	cmpq   $0x0,0x39a8(%rdi)
 100ae5e:	je     100ae67 <myl_qbe_host_begin+0x17>
 100ae60:	add    $0x8,%rsp
 100ae64:	pop    %rbx
 100ae65:	pop    %rbp
 100ae66:	ret
 100ae67:	mov    %rdi,%rbx
 100ae6a:	mov    $0x1,%edi
 100ae6f:	mov    $0x40,%esi
 100ae74:	call   101ed70 <calloc@plt>
 100ae79:	test   %rax,%rax
 100ae7c:	je     100af4e <myl_qbe_host_begin+0xfe>
 100ae82:	mov    %rax,0x39a8(%rbx)
 100ae89:	mov    0x3978(%rbx),%rcx
 100ae90:	lea    0xa0(%rcx),%rdx
 100ae97:	test   %rcx,%rcx
 100ae9a:	lea    -0x80f9(%rip),%rcx        # 1002da8 <qbe_empty_registry>
 100aea1:	cmovne %rdx,%rcx
 100aea5:	mov    %rcx,(%rax)
 100aea8:	cmpq   $0x0,0x8(%rcx)
 100aead:	je     100aeb9 <myl_qbe_host_begin+0x69>
 100aeaf:	cmpq   $0x0,(%rcx)
 100aeb3:	je     100af57 <myl_qbe_host_begin+0x107>
 100aeb9:	mov    0x10(%rcx),%rdx
 100aebd:	test   %rdx,%rdx
 100aec0:	mov    $0x2710,%esi
 100aec5:	cmovne %rdx,%rsi
 100aec9:	mov    %rsi,0x18(%rax)
 100aecd:	mov    0x18(%rcx),%rdx
 100aed1:	test   %rdx,%rdx
 100aed4:	mov    $0xf4240,%esi
 100aed9:	cmovne %rdx,%rsi
 100aedd:	mov    %rsi,0x10(%rax)
 100aee1:	mov    0x20(%rcx),%rdx
 100aee5:	test   %rdx,%rdx
 100aee8:	mov    $0x10000,%r8d
 100aeee:	cmovne %rdx,%r8
 100aef2:	mov    %r8,0x20(%rax)
 100aef6:	mov    0x28(%rcx),%rsi
 100aefa:	test   %rsi,%rsi
 100aefd:	mov    $0x40,%edx
 100af02:	cmovne %rsi,%rdx
 100af06:	mov    %rdx,0x28(%rax)
 100af0a:	mov    0x30(%rcx),%r9
 100af0e:	test   %r9,%r9
 100af11:	mov    $0x100000,%esi
 100af16:	cmovne %r9,%rsi
 100af1a:	mov    %rsi,0x30(%rax)
 100af1e:	cmp    $0x186a0,%r8
 100af25:	ja     100af45 <myl_qbe_host_begin+0xf5>
 100af27:	cmp    $0x81,%rdx
 100af2e:	setae  %dl
 100af31:	cmp    $0x4000001,%rsi
 100af38:	setae  %sil
 100af3c:	or     %dl,%sil
 100af3f:	cmp    $0x1,%sil
 100af43:	jne    100af60 <myl_qbe_host_begin+0x110>
 100af45:	lea    -0x96e5(%rip),%rsi        # 1001867 <__abi_tag+0x156b>
 100af4c:	jmp    100af6e <myl_qbe_host_begin+0x11e>
 100af4e:	lea    -0x9863(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100af55:	jmp    100af6e <myl_qbe_host_begin+0x11e>
 100af57:	lea    -0x9686(%rip),%rsi        # 10018d8 <__abi_tag+0x15dc>
 100af5e:	jmp    100af6e <myl_qbe_host_begin+0x11e>
 100af60:	cmpq   $0x0,0x8(%rcx)
 100af65:	je     100af7c <myl_qbe_host_begin+0x12c>
 100af67:	lea    -0x96aa(%rip),%rsi        # 10018c4 <__abi_tag+0x15c8>
 100af6e:	mov    %rbx,%rdi
 100af71:	add    $0x8,%rsp
 100af75:	pop    %rbx
 100af76:	pop    %rbp
 100af77:	jmp    100b4d5 <fail>
 100af7c:	movl   $0x1,0x38(%rax)
 100af83:	jmp    100ae60 <myl_qbe_host_begin+0x10>
 100af88:	int3
 100af89:	int3
 100af8a:	int3
 100af8b:	int3
 100af8c:	int3
 100af8d:	int3
 100af8e:	int3
 100af8f:	int3

000000000100af90 <main>:
 100af90:	push   %rbp
 100af91:	mov    %rsp,%rbp
 100af94:	push   %r14
 100af96:	push   %rbx
 100af97:	mov    %rsi,%rbx
 100af9a:	mov    %edi,%r14d
 100af9d:	call   100b490 <myl_qbe_exit_without_sweep>
 100afa2:	lea    0x17(%rip),%rdi        # 100afc0 <entry_run>
 100afa9:	mov    %r14d,%esi
 100afac:	mov    %rbx,%rdx
 100afaf:	xor    %ecx,%ecx
 100afb1:	pop    %rbx
 100afb2:	pop    %r14
 100afb4:	pop    %rbp
 100afb5:	jmp    100d880 <mylang_qbe_run_grants>
 100afba:	int3
 100afbb:	int3
 100afbc:	int3
 100afbd:	int3
 100afbe:	int3
 100afbf:	int3

000000000100afc0 <entry_run>:
 100afc0:	push   %rbp
 100afc1:	mov    %rsp,%rbp
 100afc4:	push   %rbx
 100afc5:	push   %rax
 100afc6:	mov    %rdi,%rbx
 100afc9:	call   100ae50 <myl_qbe_host_begin>
 100afce:	mov    %rbx,%rdi
 100afd1:	call   100b580 <myl_qbe_failed>
 100afd6:	test   %rax,%rax
 100afd9:	jne    100aff5 <entry_run+0x35>
 100afdb:	mov    %rbx,%rdi
 100afde:	call   100b580 <myl_qbe_failed>
 100afe3:	test   %rax,%rax
 100afe6:	jne    100aff5 <entry_run+0x35>
 100afe8:	mov    %rbx,%rdi
 100afeb:	call   100b580 <myl_qbe_failed>
 100aff0:	test   %rax,%rax
 100aff3:	je     100affe <entry_run+0x3e>
 100aff5:	xor    %eax,%eax
 100aff7:	add    $0x8,%rsp
 100affb:	pop    %rbx
 100affc:	pop    %rbp
 100affd:	ret
 100affe:	mov    $0x1,%esi
 100b003:	mov    %rbx,%rdi
 100b006:	add    $0x8,%rsp
 100b00a:	pop    %rbx
 100b00b:	pop    %rbp
 100b00c:	jmp    10079e0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>
 100b011:	int3
 100b012:	int3
 100b013:	int3
 100b014:	int3
 100b015:	int3
 100b016:	int3
 100b017:	int3
 100b018:	int3
 100b019:	int3
 100b01a:	int3
 100b01b:	int3
 100b01c:	int3
 100b01d:	int3
 100b01e:	int3
 100b01f:	int3

000000000100b020 <myl_qbe_rc_status>:
 100b020:	test   %esi,%esi
 100b022:	je     100b05f <myl_qbe_rc_status+0x3f>
 100b024:	push   %rbp
 100b025:	mov    %rsp,%rbp
 100b028:	push   %rbx
 100b029:	push   %rax
 100b02a:	cmp    $0x1,%esi
 100b02d:	jne    100b041 <myl_qbe_rc_status+0x21>
 100b02f:	cmpl   $0x0,0x2c4(%rdi)
 100b036:	je     100b041 <myl_qbe_rc_status+0x21>
 100b038:	lea    -0x941b(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100b03f:	jmp    100b051 <myl_qbe_rc_status+0x31>
 100b041:	mov    %rdi,%rbx
 100b044:	mov    %esi,%edi
 100b046:	call   1012540 <myl_rc_status_code>
 100b04b:	mov    %rbx,%rdi
 100b04e:	mov    %rax,%rsi
 100b051:	call   100b4d5 <fail>
 100b056:	xor    %eax,%eax
 100b058:	add    $0x8,%rsp
 100b05c:	pop    %rbx
 100b05d:	pop    %rbp
 100b05e:	ret
 100b05f:	mov    $0x1,%eax
 100b064:	ret
 100b065:	int3
 100b066:	int3
 100b067:	int3
 100b068:	int3
 100b069:	int3
 100b06a:	int3
 100b06b:	int3
 100b06c:	int3
 100b06d:	int3
 100b06e:	int3
 100b06f:	int3

000000000100b070 <myl_qbe_rc_initialize>:
 100b070:	push   %rbp
 100b071:	mov    %rsp,%rbp
 100b074:	push   %rbx
 100b075:	push   %rax
 100b076:	cmpq   $0x0,0x1860(%rdi)
 100b07e:	je     100b0e6 <myl_qbe_rc_initialize+0x76>
 100b080:	lea    0x258(%rdi),%rax
 100b087:	lea    -0x93c1(%rip),%rsi        # 1001ccd <__abi_tag+0x19d1>
 100b08e:	cmpq   $0x0,0x1e2ca(%rip)        # 1029360 <_DYNAMIC+0x1a8>
 100b096:	je     100b0f8 <myl_qbe_rc_initialize+0x88>
 100b098:	cmpq   $0x0,0x1e2b8(%rip)        # 1029358 <_DYNAMIC+0x1a0>
 100b0a0:	je     100b143 <myl_qbe_rc_initialize+0xd3>
 100b0a6:	lea    0x1c783(%rip),%rcx        # 1027830 <myl_rc_generated_module>
 100b0ad:	cmpl   $0x5,(%rcx)
 100b0b0:	jne    100b143 <myl_qbe_rc_initialize+0xd3>
 100b0b6:	mov    %rdi,%rbx
 100b0b9:	lea    0x1c770(%rip),%rsi        # 1027830 <myl_rc_generated_module>
 100b0c0:	lea    0x1c861(%rip),%rdx        # 1027928 <myl_rc_generated_image>
 100b0c7:	mov    %rax,%rdi
 100b0ca:	call   10142f0 <myl_rc_module_register_image>
 100b0cf:	test   %eax,%eax
 100b0d1:	je     100b151 <myl_qbe_rc_initialize+0xe1>
 100b0d3:	cmp    $0x1,%eax
 100b0d6:	jne    100b129 <myl_qbe_rc_initialize+0xb9>
 100b0d8:	mov    %rbx,%rdi
 100b0db:	cmpl   $0x0,0x2c4(%rbx)
 100b0e2:	jne    100b0ef <myl_qbe_rc_initialize+0x7f>
 100b0e4:	jmp    100b133 <myl_qbe_rc_initialize+0xc3>
 100b0e6:	cmpl   $0x0,0x2c4(%rdi)
 100b0ed:	je     100b12e <myl_qbe_rc_initialize+0xbe>
 100b0ef:	lea    -0x94d2(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100b0f6:	jmp    100b143 <myl_qbe_rc_initialize+0xd3>
 100b0f8:	cmpq   $0x0,0x1e258(%rip)        # 1029358 <_DYNAMIC+0x1a0>
 100b100:	je     100b143 <myl_qbe_rc_initialize+0xd3>
 100b102:	lea    0x1c727(%rip),%rcx        # 1027830 <myl_rc_generated_module>
 100b109:	cmpl   $0x5,(%rcx)
 100b10c:	jne    100b143 <myl_qbe_rc_initialize+0xd3>
 100b10e:	mov    %rdi,%rbx
 100b111:	lea    0x1c718(%rip),%rsi        # 1027830 <myl_rc_generated_module>
 100b118:	mov    %rax,%rdi
 100b11b:	call   1013410 <myl_rc_module_register>
 100b120:	test   %eax,%eax
 100b122:	je     100b151 <myl_qbe_rc_initialize+0xe1>
 100b124:	cmp    $0x1,%eax
 100b127:	je     100b0d8 <myl_qbe_rc_initialize+0x68>
 100b129:	mov    %rbx,%rdi
 100b12c:	jmp    100b133 <myl_qbe_rc_initialize+0xc3>
 100b12e:	mov    $0x1,%eax
 100b133:	mov    %rdi,%rbx
 100b136:	mov    %eax,%edi
 100b138:	call   1012540 <myl_rc_status_code>
 100b13d:	mov    %rbx,%rdi
 100b140:	mov    %rax,%rsi
 100b143:	call   100b4d5 <fail>
 100b148:	xor    %eax,%eax
 100b14a:	add    $0x8,%rsp
 100b14e:	pop    %rbx
 100b14f:	pop    %rbp
 100b150:	ret
 100b151:	mov    $0x1,%eax
 100b156:	jmp    100b14a <myl_qbe_rc_initialize+0xda>
 100b158:	int3
 100b159:	int3
 100b15a:	int3
 100b15b:	int3
 100b15c:	int3
 100b15d:	int3
 100b15e:	int3
 100b15f:	int3

000000000100b160 <myl_qbe_rc_scopes_close>:
 100b160:	push   %rbp
 100b161:	mov    %rsp,%rbp
 100b164:	push   %r15
 100b166:	push   %r14
 100b168:	push   %rbx
 100b169:	push   %rax
 100b16a:	test   %rdx,%rdx
 100b16d:	sete   %al
 100b170:	test   %rsi,%rsi
 100b173:	setne  %cl
 100b176:	or     %al,%cl
 100b178:	je     100b1d5 <myl_qbe_rc_scopes_close+0x75>
 100b17a:	mov    %rdx,%r14
 100b17d:	mov    %rsi,%r15
 100b180:	mov    %rdi,%rbx
 100b183:	add    $0x258,%rbx
 100b18a:	mov    %rbx,%rdi
 100b18d:	call   1018fd0 <myl_rc_scope_current>
 100b192:	test   %r14,%r14
 100b195:	je     100b1c0 <myl_qbe_rc_scopes_close+0x60>
 100b197:	xor    %ecx,%ecx
 100b199:	nopl   0x0(%rax)
 100b1a0:	cmp    %rax,(%r15,%rcx,8)
 100b1a4:	je     100b1b0 <myl_qbe_rc_scopes_close+0x50>
 100b1a6:	inc    %rcx
 100b1a9:	cmp    %rcx,%r14
 100b1ac:	jne    100b1a0 <myl_qbe_rc_scopes_close+0x40>
 100b1ae:	jmp    100b1c0 <myl_qbe_rc_scopes_close+0x60>
 100b1b0:	test   %rax,%rax
 100b1b3:	je     100b1c0 <myl_qbe_rc_scopes_close+0x60>
 100b1b5:	cmp    %rcx,%r14
 100b1b8:	je     100b1c0 <myl_qbe_rc_scopes_close+0x60>
 100b1ba:	mov    0x8(%rax),%rax
 100b1be:	jmp    100b197 <myl_qbe_rc_scopes_close+0x37>
 100b1c0:	mov    %rbx,%rdi
 100b1c3:	mov    %rax,%rsi
 100b1c6:	add    $0x8,%rsp
 100b1ca:	pop    %rbx
 100b1cb:	pop    %r14
 100b1cd:	pop    %r15
 100b1cf:	pop    %rbp
 100b1d0:	jmp    1018cd0 <myl_rc_scope_unwind>
 100b1d5:	call   101246d <myl_rc_invariant_failed>
 100b1da:	int3
 100b1db:	int3
 100b1dc:	int3
 100b1dd:	int3
 100b1de:	int3
 100b1df:	int3

000000000100b1e0 <myl_qbe_rc_trap>:
 100b1e0:	cmpq   $0x0,0x1860(%rdi)
 100b1e8:	je     100b1f6 <myl_qbe_rc_trap+0x16>
 100b1ea:	add    $0x258,%rdi
 100b1f1:	jmp    1018b80 <myl_rc_scopes_abandon>
 100b1f6:	ret
 100b1f7:	int3
 100b1f8:	int3
 100b1f9:	int3
 100b1fa:	int3
 100b1fb:	int3
 100b1fc:	int3
 100b1fd:	int3
 100b1fe:	int3
 100b1ff:	int3

000000000100b200 <myl_qbe_rc_finish>:
 100b200:	push   %rbp
 100b201:	mov    %rsp,%rbp
 100b204:	push   %r15
 100b206:	push   %r14
 100b208:	push   %r12
 100b20a:	push   %rbx
 100b20b:	cmpq   $0x0,0x1860(%rdi)
 100b213:	je     100b2b0 <myl_qbe_rc_finish+0xb0>
 100b219:	mov    %rdi,%r15
 100b21c:	lea    0x258(%rdi),%rbx
 100b223:	lea    0x328(%rdi),%r14
 100b22a:	cmpq   $0x0,0x20(%rdi)
 100b22f:	je     100b26b <myl_qbe_rc_finish+0x6b>
 100b231:	mov    %rbx,%rdi
 100b234:	call   1018b80 <myl_rc_scopes_abandon>
 100b239:	mov    %rbx,%rdi
 100b23c:	call   1010e00 <myl_native_arena_discard>
 100b241:	movl   $0x0,0x2c8(%r15)
 100b24c:	mov    $0x400,%edx
 100b251:	mov    %r14,%rdi
 100b254:	xor    %esi,%esi
 100b256:	call   101e4a0 <compiler_rt.fastMemset>
 100b25b:	mov    %rbx,%rdi
 100b25e:	pop    %rbx
 100b25f:	pop    %r12
 100b261:	pop    %r14
 100b263:	pop    %r15
 100b265:	pop    %rbp
 100b266:	jmp    10127c0 <myl_rc_heap_teardown>
 100b26b:	xor    %r12d,%r12d
 100b26e:	mov    %rbx,%rdi
 100b271:	xor    %esi,%esi
 100b273:	call   1018cd0 <myl_rc_scope_unwind>
 100b278:	mov    %rbx,%rdi
 100b27b:	xor    %esi,%esi
 100b27d:	call   1011050 <myl_native_arena_release>
 100b282:	movl   $0x0,0x2c8(%r15)
 100b28d:	nopl   (%rax)
 100b290:	mov    (%r14,%r12,8),%rsi
 100b294:	movq   $0x0,(%r14,%r12,8)
 100b29c:	mov    %rbx,%rdi
 100b29f:	call   1012ac0 <myl_rc_owner_release>
 100b2a4:	inc    %r12
 100b2a7:	cmp    $0x80,%r12
 100b2ae:	jne    100b290 <myl_qbe_rc_finish+0x90>
 100b2b0:	pop    %rbx
 100b2b1:	pop    %r12
 100b2b3:	pop    %r14
 100b2b5:	pop    %r15
 100b2b7:	pop    %rbp
 100b2b8:	ret
 100b2b9:	int3
 100b2ba:	int3
 100b2bb:	int3
 100b2bc:	int3
 100b2bd:	int3
 100b2be:	int3
 100b2bf:	int3

000000000100b2c0 <myl_qbe_rc_unique_local>:
 100b2c0:	push   %rbp
 100b2c1:	mov    %rsp,%rbp
 100b2c4:	push   %r15
 100b2c6:	push   %r14
 100b2c8:	push   %rbx
 100b2c9:	sub    $0x38,%rsp
 100b2cd:	test   %rcx,%rcx
 100b2d0:	je     100b3b1 <myl_qbe_rc_unique_local+0xf1>
 100b2d6:	mov    (%rdx),%r8
 100b2d9:	mov    $0x1,%eax
 100b2de:	test   %r8,%r8
 100b2e1:	je     100b45b <myl_qbe_rc_unique_local+0x19b>
 100b2e7:	mov    -0x10(%r8),%r9
 100b2eb:	movabs $0x2000000000000002,%r10
 100b2f5:	test   %r10,%r9
 100b2f8:	je     100b37e <myl_qbe_rc_unique_local+0xbe>
 100b2fe:	lea    0x258(%rdi),%r8
 100b305:	mov    0x1860(%rdi),%r9
 100b30c:	mov    0x34(%rsi),%eax
 100b30f:	cmp    %rax,0xa0(%r9)
 100b316:	jbe    100b466 <myl_qbe_rc_unique_local+0x1a6>
 100b31c:	mov    0x98(%r9),%r9
 100b323:	shl    $0x4,%rax
 100b327:	cmp    %rsi,(%r9,%rax,1)
 100b32b:	jne    100b466 <myl_qbe_rc_unique_local+0x1a6>
 100b331:	add    %rax,%r9
 100b334:	mov    0x8(%r9),%rax
 100b338:	test   %rax,%rax
 100b33b:	je     100b3b1 <myl_qbe_rc_unique_local+0xf1>
 100b33d:	mov    0x8(%rax),%rax
 100b341:	cmpl   $0x1,0x8(%rax)
 100b345:	jne    100b3b1 <myl_qbe_rc_unique_local+0xf1>
 100b347:	mov    %rax,-0x50(%rbp)
 100b34b:	mov    %rdx,-0x48(%rbp)
 100b34f:	movq   $0x0,-0x40(%rbp)
 100b357:	mov    (%rdx),%rax
 100b35a:	test   %rax,%rax
 100b35d:	je     100b3b6 <myl_qbe_rc_unique_local+0xf6>
 100b35f:	mov    -0x10(%rax),%rsi
 100b363:	mov    %rsi,%r9
 100b366:	shr    $0x28,%r9
 100b36a:	and    $0xfffff,%r9d
 100b371:	xor    %eax,%eax
 100b373:	bt     $0x3e,%rsi
 100b378:	cmovb  %r9d,%eax
 100b37c:	jmp    100b3b8 <myl_qbe_rc_unique_local+0xf8>
 100b37e:	bt     $0x3e,%r9
 100b383:	jb     100b45b <myl_qbe_rc_unique_local+0x19b>
 100b389:	test   $0x1,%r9b
 100b38d:	jne    100b3b1 <myl_qbe_rc_unique_local+0xf1>
 100b38f:	mov    -0x20(%r8),%r9
 100b393:	cmp    $0x1,%r9
 100b397:	je     100b45b <myl_qbe_rc_unique_local+0x19b>
 100b39d:	test   %r9,%r9
 100b3a0:	jne    100b2fe <myl_qbe_rc_unique_local+0x3e>
 100b3a6:	cmpq   $0x0,-0x18(%r8)
 100b3ab:	jne    100b45b <myl_qbe_rc_unique_local+0x19b>
 100b3b1:	call   101246d <myl_rc_invariant_failed>
 100b3b6:	xor    %eax,%eax
 100b3b8:	mov    %rdi,%rbx
 100b3bb:	mov    %eax,-0x38(%rbp)
 100b3be:	movl   $0x0,-0x34(%rbp)
 100b3c5:	cmpl   $0x0,(%rcx)
 100b3c8:	je     100b3ea <myl_qbe_rc_unique_local+0x12a>
 100b3ca:	lea    -0x50(%rbp),%rsi
 100b3ce:	mov    %r8,%rdi
 100b3d1:	call   101a600 <myl_rc_unique_owned>
 100b3d6:	test   %eax,%eax
 100b3d8:	je     100b440 <myl_qbe_rc_unique_local+0x180>
 100b3da:	cmp    $0x1,%eax
 100b3dd:	jne    100b447 <myl_qbe_rc_unique_local+0x187>
 100b3df:	cmpl   $0x0,0x2c4(%rbx)
 100b3e6:	jne    100b437 <myl_qbe_rc_unique_local+0x177>
 100b3e8:	jmp    100b447 <myl_qbe_rc_unique_local+0x187>
 100b3ea:	mov    %rdx,%r15
 100b3ed:	mov    %rcx,%r14
 100b3f0:	vxorps %xmm0,%xmm0,%xmm0
 100b3f4:	vmovaps %xmm0,-0x30(%rbp)
 100b3f9:	lea    -0x50(%rbp),%rsi
 100b3fd:	lea    -0x30(%rbp),%rcx
 100b401:	mov    %r8,%rdi
 100b404:	xor    %edx,%edx
 100b406:	call   101a8c0 <myl_rc_unique_borrow>
 100b40b:	test   %eax,%eax
 100b40d:	jne    100b425 <myl_qbe_rc_unique_local+0x165>
 100b40f:	cmpl   $0x0,-0x28(%rbp)
 100b413:	je     100b425 <myl_qbe_rc_unique_local+0x165>
 100b415:	mov    -0x30(%rbp),%rax
 100b419:	mov    %rax,(%r15)
 100b41c:	movl   $0x1,(%r14)
 100b423:	jmp    100b440 <myl_qbe_rc_unique_local+0x180>
 100b425:	test   %eax,%eax
 100b427:	je     100b440 <myl_qbe_rc_unique_local+0x180>
 100b429:	cmp    $0x1,%eax
 100b42c:	jne    100b447 <myl_qbe_rc_unique_local+0x187>
 100b42e:	cmpl   $0x0,0x2c4(%rbx)
 100b435:	je     100b447 <myl_qbe_rc_unique_local+0x187>
 100b437:	lea    -0x981a(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100b43e:	jmp    100b451 <myl_qbe_rc_unique_local+0x191>
 100b440:	mov    $0x1,%eax
 100b445:	jmp    100b45b <myl_qbe_rc_unique_local+0x19b>
 100b447:	mov    %eax,%edi
 100b449:	call   1012540 <myl_rc_status_code>
 100b44e:	mov    %rax,%rsi
 100b451:	mov    %rbx,%rdi
 100b454:	call   100b4d5 <fail>
 100b459:	xor    %eax,%eax
 100b45b:	add    $0x38,%rsp
 100b45f:	pop    %rbx
 100b460:	pop    %r14
 100b462:	pop    %r15
 100b464:	pop    %rbp
 100b465:	ret
 100b466:	mov    %rdi,%r9
 100b469:	mov    %r8,%rdi
 100b46c:	call   1012eea <myl_rc_binding_find_slow>
 100b471:	mov    %r9,%rdi
 100b474:	test   %rax,%rax
 100b477:	jne    100b33d <myl_qbe_rc_unique_local+0x7d>
 100b47d:	jmp    100b3b1 <myl_qbe_rc_unique_local+0xf1>
 100b482:	int3
 100b483:	int3
 100b484:	int3
 100b485:	int3
 100b486:	int3
 100b487:	int3
 100b488:	int3
 100b489:	int3
 100b48a:	int3
 100b48b:	int3
 100b48c:	int3
 100b48d:	int3
 100b48e:	int3
 100b48f:	int3

000000000100b490 <myl_qbe_exit_without_sweep>:
 100b490:	movb   $0x1,0x1f111(%rip)        # 102a5a8 <exit_without_sweep>
 100b497:	ret
 100b498:	int3
 100b499:	int3
 100b49a:	int3
 100b49b:	int3
 100b49c:	int3
 100b49d:	int3
 100b49e:	int3
 100b49f:	int3

000000000100b4a0 <myl_qbe_exit_skip>:
 100b4a0:	xor    %eax,%eax
 100b4a2:	cmpb   $0x1,0x1f0ff(%rip)        # 102a5a8 <exit_without_sweep>
 100b4a9:	jne    100b4b4 <myl_qbe_exit_skip+0x14>
 100b4ab:	cmpl   $0x0,0x2c0(%rdi)
 100b4b2:	je     100b4b5 <myl_qbe_exit_skip+0x15>
 100b4b4:	ret
 100b4b5:	cmpq   $0x0,0x3990(%rdi)
 100b4bd:	jne    100b4b4 <myl_qbe_exit_skip+0x14>
 100b4bf:	xor    %eax,%eax
 100b4c1:	cmpq   $0x0,0x3998(%rdi)
 100b4c9:	sete   %al
 100b4cc:	ret
 100b4cd:	int3
 100b4ce:	int3
 100b4cf:	int3

000000000100b4d0 <myl_qbe_fail>:
 100b4d0:	jmp    100b4d5 <fail>

000000000100b4d5 <fail>:
 100b4d5:	push   %rbp
 100b4d6:	mov    %rsp,%rbp
 100b4d9:	push   %r15
 100b4db:	push   %r14
 100b4dd:	push   %rbx
 100b4de:	push   %rax
 100b4df:	cmpq   $0x0,0x20(%rdi)
 100b4e4:	jne    100b55b <fail+0x86>
 100b4e6:	mov    %rdi,%rbx
 100b4e9:	mov    %rsi,0x20(%rdi)
 100b4ed:	movq   $0x0,-0x20(%rbp)
 100b4f5:	mov    0x30(%rdi),%r15
 100b4f9:	test   %r15,%r15
 100b4fc:	je     100b526 <fail+0x51>
 100b4fe:	lea    -0x20(%rbp),%r14
 100b502:	mov    0x8(%r15),%rsi
 100b506:	mov    0x10(%r15),%rdx
 100b50a:	mov    %rbx,%rdi
 100b50d:	xor    %ecx,%ecx
 100b50f:	mov    %r14,%r8
 100b512:	call   100ccb0 <trace_frame>
 100b517:	mov    (%r15),%r15
 100b51a:	test   %r15,%r15
 100b51d:	jne    100b502 <fail+0x2d>
 100b51f:	cmpq   $0x0,0x30(%rbx)
 100b524:	jne    100b539 <fail+0x64>
 100b526:	lea    0x1a03(%rip),%rsi        # 100cf30 <trace_visit>
 100b52d:	lea    -0x20(%rbp),%rdx
 100b531:	mov    %rbx,%rdi
 100b534:	call   100cdf0 <walk_frames>
 100b539:	mov    -0x20(%rbp),%rax
 100b53d:	xor    %ecx,%ecx
 100b53f:	sub    0x248(%rbx),%rax
 100b546:	cmovae %rax,%rcx
 100b54a:	mov    %rcx,0x250(%rbx)
 100b551:	cmpq   $0x0,0x3e60(%rbx)
 100b559:	jne    100b566 <fail+0x91>
 100b55b:	add    $0x8,%rsp
 100b55f:	pop    %rbx
 100b560:	pop    %r14
 100b562:	pop    %r15
 100b564:	pop    %rbp
 100b565:	ret
 100b566:	mov    %rbx,%rdi
 100b569:	call   100b1e0 <myl_qbe_rc_trap>
 100b56e:	mov    0x3e60(%rbx),%rdi
 100b575:	mov    $0x1,%esi
 100b57a:	call   101ed80 <longjmp@plt>
 100b57f:	int3

000000000100b580 <myl_qbe_failed>:
 100b580:	xor    %eax,%eax
 100b582:	cmpq   $0x0,0x20(%rdi)
 100b587:	setne  %al
 100b58a:	ret
 100b58b:	int3
 100b58c:	int3
 100b58d:	int3
 100b58e:	int3
 100b58f:	int3

000000000100b590 <myl_qbe_fail_allocation>:
 100b590:	push   %rbp
 100b591:	mov    %rsp,%rbp
 100b594:	push   %rbx
 100b595:	push   %rax
 100b596:	mov    %rdi,%rbx
 100b599:	cmpq   $0x0,0x1860(%rdi)
 100b5a1:	je     100b5c3 <myl_qbe_fail_allocation+0x33>
 100b5a3:	lea    0x258(%rbx),%rdi
 100b5aa:	call   1012590 <myl_rc_take_failure>
 100b5af:	test   %eax,%eax
 100b5b1:	je     100b5c3 <myl_qbe_fail_allocation+0x33>
 100b5b3:	mov    %rbx,%rdi
 100b5b6:	mov    %eax,%esi
 100b5b8:	add    $0x8,%rsp
 100b5bc:	pop    %rbx
 100b5bd:	pop    %rbp
 100b5be:	jmp    100b020 <myl_qbe_rc_status>
 100b5c3:	call   1018ae0 <myl_native_cow_take_depth_failure>
 100b5c8:	test   %eax,%eax
 100b5ca:	jne    100b5e7 <myl_qbe_fail_allocation+0x57>
 100b5cc:	cmpl   $0x0,0x2c4(%rbx)
 100b5d3:	lea    -0x9ee8(%rip),%rax        # 10016f2 <__abi_tag+0x13f6>
 100b5da:	lea    -0x99bd(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100b5e1:	cmove  %rax,%rsi
 100b5e5:	jmp    100b5ee <myl_qbe_fail_allocation+0x5e>
 100b5e7:	lea    -0x9916(%rip),%rsi        # 1001cd8 <__abi_tag+0x19dc>
 100b5ee:	mov    %rbx,%rdi
 100b5f1:	add    $0x8,%rsp
 100b5f5:	pop    %rbx
 100b5f6:	pop    %rbp
 100b5f7:	jmp    100b4d5 <fail>
 100b5fc:	int3
 100b5fd:	int3
 100b5fe:	int3
 100b5ff:	int3

000000000100b600 <myl_qbe_fail_iteration>:
 100b600:	lea    -0x99a1(%rip),%rsi        # 1001c66 <__abi_tag+0x196a>
 100b607:	jmp    100b4d5 <fail>
 100b60c:	int3
 100b60d:	int3
 100b60e:	int3
 100b60f:	int3

000000000100b610 <myl_qbe_fail_normalized_index_bounds>:
 100b610:	cmpq   $0x0,0x20(%rdi)
 100b615:	jne    100b668 <myl_qbe_fail_normalized_index_bounds+0x58>
 100b617:	mov    %rsi,%rax
 100b61a:	sar    $0x3f,%rax
 100b61e:	and    %rdx,%rax
 100b621:	sub    %rax,%rsi
 100b624:	movabs $0x300000001,%rax
 100b62e:	mov    %rax,0x39e8(%rdi)
 100b635:	mov    %rsi,0x39f0(%rdi)
 100b63c:	mov    %rdx,0x39f8(%rdi)
 100b643:	vxorps %xmm0,%xmm0,%xmm0
 100b647:	vmovups %xmm0,0x3a00(%rdi)
 100b64f:	movq   $0x0,0x3a10(%rdi)
 100b65a:	lea    -0x9eef(%rip),%rax        # 1001772 <__abi_tag+0x1476>
 100b661:	mov    %rax,0x3a18(%rdi)
 100b668:	lea    -0x9a17(%rip),%rsi        # 1001c58 <__abi_tag+0x195c>
 100b66f:	jmp    100b4d5 <fail>
 100b674:	int3
 100b675:	int3
 100b676:	int3
 100b677:	int3
 100b678:	int3
 100b679:	int3
 100b67a:	int3
 100b67b:	int3
 100b67c:	int3
 100b67d:	int3
 100b67e:	int3
 100b67f:	int3

000000000100b680 <myl_qbe_fail_overflow_op>:
 100b680:	cmp    $0x6,%rsi
 100b684:	ja     100b6ad <myl_qbe_fail_overflow_op+0x2d>
 100b686:	lea    -0x88ad(%rip),%rax        # 1002de0 <qbe_empty_registry+0x38>
 100b68d:	movslq (%rax,%rsi,4),%rsi
 100b691:	add    %rax,%rsi
 100b694:	jmp    *%rsi
 100b696:	lea    -0x9b28(%rip),%rax        # 1001b75 <__abi_tag+0x1879>
 100b69d:	cmpq   $0x0,0x20(%rdi)
 100b6a2:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b6a8:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b6ad:	cmp    $0x64,%rsi
 100b6b1:	je     100b6f6 <myl_qbe_fail_overflow_op+0x76>
 100b6b3:	cmp    $0x65,%rsi
 100b6b7:	jne    100b7a2 <myl_qbe_fail_overflow_op+0x122>
 100b6bd:	lea    -0x9c6d(%rip),%rax        # 1001a57 <__abi_tag+0x175b>
 100b6c4:	cmpq   $0x0,0x20(%rdi)
 100b6c9:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b6cb:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b6d0:	lea    -0x9dc3(%rip),%rax        # 1001914 <__abi_tag+0x1618>
 100b6d7:	cmpq   $0x0,0x20(%rdi)
 100b6dc:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b6de:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b6e3:	lea    -0x9dd2(%rip),%rax        # 1001918 <__abi_tag+0x161c>
 100b6ea:	cmpq   $0x0,0x20(%rdi)
 100b6ef:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b6f1:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b6f6:	lea    -0x9ecb(%rip),%rax        # 1001832 <__abi_tag+0x1536>
 100b6fd:	cmpq   $0x0,0x20(%rdi)
 100b702:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b704:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b709:	lea    -0x9f7f(%rip),%rax        # 1001791 <__abi_tag+0x1495>
 100b710:	cmpq   $0x0,0x20(%rdi)
 100b715:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b717:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b719:	lea    -0x9b98(%rip),%rax        # 1001b88 <__abi_tag+0x188c>
 100b720:	cmpq   $0x0,0x20(%rdi)
 100b725:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b727:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b729:	lea    -0x9fa5(%rip),%rax        # 100178b <__abi_tag+0x148f>
 100b730:	cmpq   $0x0,0x20(%rdi)
 100b735:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b737:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b739:	lea    -0x9e32(%rip),%rax        # 100190e <__abi_tag+0x1612>
 100b740:	cmpq   $0x0,0x20(%rdi)
 100b745:	jne    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b747:	mov    %r8,%rsi
 100b74a:	and    $0xfffffffffffffeff,%rsi
 100b751:	shr    $0x3,%r8d
 100b755:	and    $0x20,%r8d
 100b759:	or     $0x1c,%r8d
 100b75d:	movl   $0x1,0x39e8(%rdi)
 100b767:	mov    %r8d,0x39ec(%rdi)
 100b76e:	vxorps %xmm0,%xmm0,%xmm0
 100b772:	vmovups %xmm0,0x39f0(%rdi)
 100b77a:	mov    %rdx,0x3a00(%rdi)
 100b781:	mov    %rcx,0x3a08(%rdi)
 100b788:	mov    %rsi,0x3a10(%rdi)
 100b78f:	mov    %rax,0x3a18(%rdi)
 100b796:	lea    -0x9c11(%rip),%rsi        # 1001b8c <__abi_tag+0x1890>
 100b79d:	jmp    100b4d5 <fail>
 100b7a2:	lea    -0x9c30(%rip),%rax        # 1001b79 <__abi_tag+0x187d>
 100b7a9:	cmpq   $0x0,0x20(%rdi)
 100b7ae:	je     100b747 <myl_qbe_fail_overflow_op+0xc7>
 100b7b0:	jmp    100b796 <myl_qbe_fail_overflow_op+0x116>
 100b7b2:	int3
 100b7b3:	int3
 100b7b4:	int3
 100b7b5:	int3
 100b7b6:	int3
 100b7b7:	int3
 100b7b8:	int3
 100b7b9:	int3
 100b7ba:	int3
 100b7bb:	int3
 100b7bc:	int3
 100b7bd:	int3
 100b7be:	int3
 100b7bf:	int3

000000000100b7c0 <myl_qbe_fail_cast>:
 100b7c0:	cmpq   $0x0,0x20(%rdi)
 100b7c5:	jne    100b81c <myl_qbe_fail_cast+0x5c>
 100b7c7:	mov    %rdx,%rax
 100b7ca:	and    $0xfffffffffffffeff,%rax
 100b7d0:	shr    $0x3,%edx
 100b7d3:	and    $0x20,%edx
 100b7d6:	or     $0x14,%edx
 100b7d9:	movl   $0x1,0x39e8(%rdi)
 100b7e3:	mov    %edx,0x39ec(%rdi)
 100b7e9:	vxorps %xmm0,%xmm0,%xmm0
 100b7ed:	vmovups %xmm0,0x39f0(%rdi)
 100b7f5:	mov    %rsi,0x3a00(%rdi)
 100b7fc:	movq   $0x0,0x3a08(%rdi)
 100b807:	mov    %rax,0x3a10(%rdi)
 100b80e:	lea    -0x9fe3(%rip),%rax        # 1001832 <__abi_tag+0x1536>
 100b815:	mov    %rax,0x3a18(%rdi)
 100b81c:	lea    -0x9c97(%rip),%rsi        # 1001b8c <__abi_tag+0x1890>
 100b823:	jmp    100b4d5 <fail>
 100b828:	int3
 100b829:	int3
 100b82a:	int3
 100b82b:	int3
 100b82c:	int3
 100b82d:	int3
 100b82e:	int3
 100b82f:	int3

000000000100b830 <myl_qbe_heap>:
 100b830:	lea    0x258(%rdi),%rax
 100b837:	ret
 100b838:	int3
 100b839:	int3
 100b83a:	int3
 100b83b:	int3
 100b83c:	int3
 100b83d:	int3
 100b83e:	int3
 100b83f:	int3

000000000100b840 <myl_qbe_fail_frame>:
 100b840:	lea    -0x9c31(%rip),%rsi        # 1001c16 <__abi_tag+0x191a>
 100b847:	jmp    100b4d5 <fail>
 100b84c:	int3
 100b84d:	int3
 100b84e:	int3
 100b84f:	int3

000000000100b850 <myl_qbe_float_unary>:
 100b850:	push   %rbp
 100b851:	mov    %rsp,%rbp
 100b854:	add    $0xfffffffffffffffe,%rsi
 100b858:	cmp    $0x9,%rsi
 100b85c:	ja     100b9bf <myl_qbe_float_unary+0x16f>
 100b862:	vmovq  %rdx,%xmm0
 100b867:	lea    -0x8a0e(%rip),%rax        # 1002e60 <qbe_empty_registry+0xb8>
 100b86e:	movslq (%rax,%rsi,4),%rcx
 100b872:	add    %rax,%rcx
 100b875:	jmp    *%rcx
 100b877:	vxorpd %xmm1,%xmm1,%xmm1
 100b87b:	vucomisd %xmm1,%xmm0
 100b87f:	jb     100b9aa <myl_qbe_float_unary+0x15a>
 100b885:	vsqrtsd %xmm0,%xmm0,%xmm0
 100b889:	jmp    100b9af <myl_qbe_float_unary+0x15f>
 100b88e:	mov    $0x3f,%al
 100b890:	bzhi   %rax,%rdx,%rax
 100b895:	pop    %rbp
 100b896:	ret
 100b897:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 100b89d:	vmovq  %xmm0,%rax
 100b8a2:	mov    $0x3f,%cl
 100b8a4:	bzhi   %rcx,%rax,%rax
 100b8a9:	movabs $0x7fefffffffffffff,%rcx
 100b8b3:	cmp    %rcx,%rax
 100b8b6:	jg     100b9b6 <myl_qbe_float_unary+0x166>
 100b8bc:	vmovsd -0x8aa4(%rip),%xmm1        # 1002e20 <qbe_empty_registry+0x78>
 100b8c4:	vucomisd %xmm0,%xmm1
 100b8c8:	ja     100b9b6 <myl_qbe_float_unary+0x166>
 100b8ce:	vucomisd -0x8abe(%rip),%xmm0        # 1002e18 <qbe_empty_registry+0x70>
 100b8d6:	jae    100b9b6 <myl_qbe_float_unary+0x166>
 100b8dc:	vcvttsd2si %xmm0,%rax
 100b8e1:	pop    %rbp
 100b8e2:	ret
 100b8e3:	vroundsd $0xa,%xmm0,%xmm0,%xmm0
 100b8e9:	jmp    100b9af <myl_qbe_float_unary+0x15f>
 100b8ee:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 100b8f4:	jmp    100b9af <myl_qbe_float_unary+0x15f>
 100b8f9:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 100b8ff:	vmovq  %xmm0,%rax
 100b904:	mov    $0x3f,%cl
 100b906:	bzhi   %rcx,%rax,%rcx
 100b90b:	movabs $0xfff0000000000000,%rdx
 100b915:	add    %rcx,%rdx
 100b918:	shr    $0x35,%rdx
 100b91c:	cmp    $0x3ff,%edx
 100b922:	setb   %dl
 100b925:	test   %rax,%rax
 100b928:	sets   %al
 100b92b:	and    %dl,%al
 100b92d:	movabs $0x7fefffffffffffff,%rdx
 100b937:	cmp    %rdx,%rcx
 100b93a:	setg   %cl
 100b93d:	or     %al,%cl
 100b93f:	jne    100b9b6 <myl_qbe_float_unary+0x166>
 100b941:	vucomisd -0x8b39(%rip),%xmm0        # 1002e10 <qbe_empty_registry+0x68>
 100b949:	jae    100b9b6 <myl_qbe_float_unary+0x166>
 100b94b:	vcvttsd2si %xmm0,%rcx
 100b950:	mov    %rcx,%rdx
 100b953:	sar    $0x3f,%rdx
 100b957:	vsubsd -0x8b47(%rip),%xmm0,%xmm0        # 1002e18 <qbe_empty_registry+0x70>
 100b95f:	vcvttsd2si %xmm0,%rax
 100b964:	and    %rdx,%rax
 100b967:	or     %rcx,%rax
 100b96a:	pop    %rbp
 100b96b:	ret
 100b96c:	vroundsd $0x9,%xmm0,%xmm0,%xmm0
 100b972:	jmp    100b9af <myl_qbe_float_unary+0x15f>
 100b974:	movabs $0x8000000000000000,%rax
 100b97e:	xor    %rdx,%rax
 100b981:	pop    %rbp
 100b982:	ret
 100b983:	vmovq  %rdx,%xmm0
 100b988:	vpunpckldq -0x8b50(%rip),%xmm0,%xmm0        # 1002e40 <qbe_empty_registry+0x98>
 100b990:	vsubpd -0x8b68(%rip),%xmm0,%xmm0        # 1002e30 <qbe_empty_registry+0x88>
 100b998:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 100b99d:	vaddsd %xmm0,%xmm1,%xmm0
 100b9a1:	jmp    100b9af <myl_qbe_float_unary+0x15f>
 100b9a3:	vcvtsi2sd %rdx,%xmm15,%xmm0
 100b9a8:	jmp    100b9af <myl_qbe_float_unary+0x15f>
 100b9aa:	call   101eb80 <compiler_rt.sqrt.sqrt>
 100b9af:	vmovq  %xmm0,%rax
 100b9b4:	pop    %rbp
 100b9b5:	ret
 100b9b6:	lea    -0x9d3d(%rip),%rsi        # 1001c80 <__abi_tag+0x1984>
 100b9bd:	jmp    100b9c6 <myl_qbe_float_unary+0x176>
 100b9bf:	lea    -0x9cf9(%rip),%rsi        # 1001ccd <__abi_tag+0x19d1>
 100b9c6:	call   100b4d5 <fail>
 100b9cb:	xor    %eax,%eax
 100b9cd:	pop    %rbp
 100b9ce:	ret
 100b9cf:	int3

000000000100b9d0 <myl_qbe_require_step_accounting>:
 100b9d0:	cmpq   $0xffffffffffffffff,0x10(%rdi)
 100b9d5:	jne    100b9d8 <myl_qbe_require_step_accounting+0x8>
 100b9d7:	ret
 100b9d8:	cmpq   $0x0,0x20(%rdi)
 100b9dd:	jne    100ba0b <myl_qbe_require_step_accounting+0x3b>
 100b9df:	movl   $0x1,0x39e8(%rdi)
 100b9e9:	vxorps %xmm0,%xmm0,%xmm0
 100b9ed:	vmovups %ymm0,0x39ec(%rdi)
 100b9f5:	vmovups %ymm0,0x39f8(%rdi)
 100b9fd:	lea    -0xa0b5(%rip),%rax        # 100194f <__abi_tag+0x1653>
 100ba04:	mov    %rax,0x3a18(%rdi)
 100ba0b:	lea    -0x9d2e(%rip),%rsi        # 1001ce4 <__abi_tag+0x19e8>
 100ba12:	vzeroupper
 100ba15:	jmp    100b4d5 <fail>
 100ba1a:	int3
 100ba1b:	int3
 100ba1c:	int3
 100ba1d:	int3
 100ba1e:	int3
 100ba1f:	int3

000000000100ba20 <myl_qbe_require_frame_accounting>:
 100ba20:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 100ba25:	jne    100ba28 <myl_qbe_require_frame_accounting+0x8>
 100ba27:	ret
 100ba28:	cmpq   $0x0,0x20(%rdi)
 100ba2d:	jne    100ba5b <myl_qbe_require_frame_accounting+0x3b>
 100ba2f:	movl   $0x1,0x39e8(%rdi)
 100ba39:	vxorps %xmm0,%xmm0,%xmm0
 100ba3d:	vmovups %ymm0,0x39ec(%rdi)
 100ba45:	vmovups %ymm0,0x39f8(%rdi)
 100ba4d:	lea    -0xa0bc(%rip),%rax        # 1001998 <__abi_tag+0x169c>
 100ba54:	mov    %rax,0x3a18(%rdi)
 100ba5b:	lea    -0x9d69(%rip),%rsi        # 1001cf9 <__abi_tag+0x19fd>
 100ba62:	vzeroupper
 100ba65:	jmp    100b4d5 <fail>
 100ba6a:	int3
 100ba6b:	int3
 100ba6c:	int3
 100ba6d:	int3
 100ba6e:	int3
 100ba6f:	int3

000000000100ba70 <myl_qbe_control>:
 100ba70:	push   %rbp
 100ba71:	mov    %rsp,%rbp
 100ba74:	push   %r14
 100ba76:	push   %rbx
 100ba77:	mov    %rsi,%r14
 100ba7a:	mov    %rdi,%rbx
 100ba7d:	lea    -0x9d0c(%rip),%rsi        # 1001d78 <__abi_tag+0x1a7c>
 100ba84:	mov    $0xc,%edx
 100ba89:	mov    %r14,%rdi
 100ba8c:	call   101edd0 <strncmp@plt>
 100ba91:	test   %eax,%eax
 100ba93:	je     100bb20 <myl_qbe_control+0xb0>
 100ba99:	lea    -0x9d1b(%rip),%rsi        # 1001d85 <__abi_tag+0x1a89>
 100baa0:	mov    $0xd,%edx
 100baa5:	mov    %r14,%rdi
 100baa8:	call   101edd0 <strncmp@plt>
 100baad:	test   %eax,%eax
 100baaf:	je     100bbb6 <myl_qbe_control+0x146>
 100bab5:	lea    -0x9d61(%rip),%rsi        # 1001d5b <__abi_tag+0x1a5f>
 100babc:	mov    $0xa,%edx
 100bac1:	mov    %r14,%rdi
 100bac4:	call   101edd0 <strncmp@plt>
 100bac9:	test   %eax,%eax
 100bacb:	je     100bc47 <myl_qbe_control+0x1d7>
 100bad1:	lea    -0xa24a(%rip),%rsi        # 100188e <__abi_tag+0x1592>
 100bad8:	mov    %r14,%rdi
 100badb:	call   101ede0 <strcmp@plt>
 100bae0:	test   %eax,%eax
 100bae2:	je     100bcd4 <myl_qbe_control+0x264>
 100bae8:	lea    -0xa2b8(%rip),%rsi        # 1001837 <__abi_tag+0x153b>
 100baef:	mov    %r14,%rdi
 100baf2:	call   101ede0 <strcmp@plt>
 100baf7:	mov    %eax,%ecx
 100baf9:	xor    %eax,%eax
 100bafb:	test   %ecx,%ecx
 100bafd:	jne    100bcf1 <myl_qbe_control+0x281>
 100bb03:	cmpl   $0x0,0x28(%rbx)
 100bb07:	je     100bb14 <myl_qbe_control+0xa4>
 100bb09:	lea    -0xa262(%rip),%rax        # 10018ae <__abi_tag+0x15b2>
 100bb10:	mov    %rax,0x30(%rbx)
 100bb14:	movl   $0x1,0x28(%rbx)
 100bb1b:	jmp    100bcec <myl_qbe_control+0x27c>
 100bb20:	movzbl 0xc(%r14),%edx
 100bb25:	test   %dl,%dl
 100bb27:	je     100bb86 <myl_qbe_control+0x116>
 100bb29:	add    $0xd,%r14
 100bb2d:	xor    %eax,%eax
 100bb2f:	movabs $0xcccccccccccccccd,%rcx
 100bb39:	nopl   0x0(%rax)
 100bb40:	lea    -0x3a(%rdx),%esi
 100bb43:	cmp    $0xf6,%sil
 100bb47:	jb     100bb86 <myl_qbe_control+0x116>
 100bb49:	add    $0xd0,%dl
 100bb4c:	movzbl %dl,%esi
 100bb4f:	mov    %rsi,%rdx
 100bb52:	not    %rdx
 100bb55:	mulx   %rcx,%rdx,%rdx
 100bb5a:	shr    $0x3,%rdx
 100bb5e:	cmp    %rdx,%rax
 100bb61:	ja     100bb86 <myl_qbe_control+0x116>
 100bb63:	lea    (%rax,%rax,4),%rax
 100bb67:	lea    (%rsi,%rax,2),%rax
 100bb6b:	movzbl (%r14),%edx
 100bb6f:	inc    %r14
 100bb72:	test   %dl,%dl
 100bb74:	jne    100bb40 <myl_qbe_control+0xd0>
 100bb76:	cmpl   $0x0,0x18(%rbx)
 100bb7a:	sete   %cl
 100bb7d:	jne    100bb8f <myl_qbe_control+0x11f>
 100bb7f:	test   %rax,%rax
 100bb82:	jne    100bba7 <myl_qbe_control+0x137>
 100bb84:	jmp    100bb8f <myl_qbe_control+0x11f>
 100bb86:	cmpl   $0x0,0x18(%rbx)
 100bb8a:	sete   %cl
 100bb8d:	xor    %eax,%eax
 100bb8f:	lea    -0xa32b(%rip),%rdx        # 100186b <__abi_tag+0x156f>
 100bb96:	lea    -0xa2ef(%rip),%rsi        # 10018ae <__abi_tag+0x15b2>
 100bb9d:	test   %cl,%cl
 100bb9f:	cmovne %rdx,%rsi
 100bba3:	mov    %rsi,0x30(%rbx)
 100bba7:	movl   $0x1,0x18(%rbx)
 100bbae:	mov    %rax,(%rbx)
 100bbb1:	jmp    100bcec <myl_qbe_control+0x27c>
 100bbb6:	movzbl 0xd(%r14),%edx
 100bbbb:	test   %dl,%dl
 100bbbd:	je     100bc16 <myl_qbe_control+0x1a6>
 100bbbf:	add    $0xe,%r14
 100bbc3:	xor    %eax,%eax
 100bbc5:	movabs $0xcccccccccccccccd,%rcx
 100bbcf:	nop
 100bbd0:	lea    -0x3a(%rdx),%esi
 100bbd3:	cmp    $0xf6,%sil
 100bbd7:	jb     100bc16 <myl_qbe_control+0x1a6>
 100bbd9:	add    $0xd0,%dl
 100bbdc:	movzbl %dl,%esi
 100bbdf:	mov    %rsi,%rdx
 100bbe2:	not    %rdx
 100bbe5:	mulx   %rcx,%rdx,%rdx
 100bbea:	shr    $0x3,%rdx
 100bbee:	cmp    %rdx,%rax
 100bbf1:	ja     100bc16 <myl_qbe_control+0x1a6>
 100bbf3:	lea    (%rax,%rax,4),%rax
 100bbf7:	lea    (%rsi,%rax,2),%rax
 100bbfb:	movzbl (%r14),%edx
 100bbff:	inc    %r14
 100bc02:	test   %dl,%dl
 100bc04:	jne    100bbd0 <myl_qbe_control+0x160>
 100bc06:	cmpl   $0x0,0x1c(%rbx)
 100bc0a:	sete   %cl
 100bc0d:	jne    100bc1f <myl_qbe_control+0x1af>
 100bc0f:	test   %rax,%rax
 100bc12:	jne    100bc37 <myl_qbe_control+0x1c7>
 100bc14:	jmp    100bc1f <myl_qbe_control+0x1af>
 100bc16:	cmpl   $0x0,0x1c(%rbx)
 100bc1a:	sete   %cl
 100bc1d:	xor    %eax,%eax
 100bc1f:	lea    -0xa3bb(%rip),%rdx        # 100186b <__abi_tag+0x156f>
 100bc26:	lea    -0xa37f(%rip),%rsi        # 10018ae <__abi_tag+0x15b2>
 100bc2d:	test   %cl,%cl
 100bc2f:	cmovne %rdx,%rsi
 100bc33:	mov    %rsi,0x30(%rbx)
 100bc37:	movl   $0x1,0x1c(%rbx)
 100bc3e:	mov    %rax,0x8(%rbx)
 100bc42:	jmp    100bcec <myl_qbe_control+0x27c>
 100bc47:	movzbl 0xa(%r14),%edx
 100bc4c:	test   %dl,%dl
 100bc4e:	je     100bca6 <myl_qbe_control+0x236>
 100bc50:	add    $0xb,%r14
 100bc54:	xor    %eax,%eax
 100bc56:	movabs $0xcccccccccccccccd,%rcx
 100bc60:	lea    -0x3a(%rdx),%esi
 100bc63:	cmp    $0xf6,%sil
 100bc67:	jb     100bca6 <myl_qbe_control+0x236>
 100bc69:	add    $0xd0,%dl
 100bc6c:	movzbl %dl,%esi
 100bc6f:	mov    %rsi,%rdx
 100bc72:	not    %rdx
 100bc75:	mulx   %rcx,%rdx,%rdx
 100bc7a:	shr    $0x3,%rdx
 100bc7e:	cmp    %rdx,%rax
 100bc81:	ja     100bca6 <myl_qbe_control+0x236>
 100bc83:	lea    (%rax,%rax,4),%rax
 100bc87:	lea    (%rsi,%rax,2),%rax
 100bc8b:	movzbl (%r14),%edx
 100bc8f:	inc    %r14
 100bc92:	test   %dl,%dl
 100bc94:	jne    100bc60 <myl_qbe_control+0x1f0>
 100bc96:	cmpl   $0x0,0x20(%rbx)
 100bc9a:	sete   %cl
 100bc9d:	jne    100bcaf <myl_qbe_control+0x23f>
 100bc9f:	test   %rax,%rax
 100bca2:	jne    100bcc7 <myl_qbe_control+0x257>
 100bca4:	jmp    100bcaf <myl_qbe_control+0x23f>
 100bca6:	cmpl   $0x0,0x20(%rbx)
 100bcaa:	sete   %cl
 100bcad:	xor    %eax,%eax
 100bcaf:	lea    -0xa44b(%rip),%rdx        # 100186b <__abi_tag+0x156f>
 100bcb6:	lea    -0xa40f(%rip),%rsi        # 10018ae <__abi_tag+0x15b2>
 100bcbd:	test   %cl,%cl
 100bcbf:	cmovne %rdx,%rsi
 100bcc3:	mov    %rsi,0x30(%rbx)
 100bcc7:	movl   $0x1,0x20(%rbx)
 100bcce:	mov    %rax,0x10(%rbx)
 100bcd2:	jmp    100bcec <myl_qbe_control+0x27c>
 100bcd4:	cmpl   $0x0,0x24(%rbx)
 100bcd8:	je     100bcf6 <myl_qbe_control+0x286>
 100bcda:	lea    -0xa433(%rip),%rax        # 10018ae <__abi_tag+0x15b2>
 100bce1:	mov    %rax,0x30(%rbx)
 100bce5:	movl   $0x1,0x24(%rbx)
 100bcec:	mov    $0x1,%eax
 100bcf1:	pop    %rbx
 100bcf2:	pop    %r14
 100bcf4:	pop    %rbp
 100bcf5:	ret
 100bcf6:	cmpq   $0x0,0x30(%rbx)
 100bcfb:	movl   $0x1,0x24(%rbx)
 100bd02:	mov    $0x1,%eax
 100bd07:	jne    100bcf1 <myl_qbe_control+0x281>
 100bd09:	lea    -0x8e80(%rip),%rcx        # 1002e90 <stress_needs_gc>
 100bd10:	mov    %rcx,0x30(%rbx)
 100bd14:	jmp    100bcf1 <myl_qbe_control+0x281>
 100bd16:	int3
 100bd17:	int3
 100bd18:	int3
 100bd19:	int3
 100bd1a:	int3
 100bd1b:	int3
 100bd1c:	int3
 100bd1d:	int3
 100bd1e:	int3
 100bd1f:	int3

000000000100bd20 <mylang_qbe_run_process>:
 100bd20:	push   %rbp
 100bd21:	mov    %rsp,%rbp
 100bd24:	push   %r15
 100bd26:	push   %r14
 100bd28:	push   %r13
 100bd2a:	push   %r12
 100bd2c:	push   %rbx
 100bd2d:	sub    $0xc98,%rsp
 100bd34:	mov    %edx,%r14d
 100bd37:	mov    0x30(%rsi),%rdx
 100bd3b:	lea    -0x8eb2(%rip),%rax        # 1002e90 <stress_needs_gc>
 100bd42:	cmp    %rax,%rdx
 100bd45:	je     100bfb7 <mylang_qbe_run_process+0x297>
 100bd4b:	test   %rdx,%rdx
 100bd4e:	jne    100bfcf <mylang_qbe_run_process+0x2af>
 100bd54:	mov    %rcx,%r15
 100bd57:	mov    %rsi,%rbx
 100bd5a:	mov    $0xffffffffffffffff,%r13
 100bd61:	cmpl   $0x0,0x18(%rsi)
 100bd65:	mov    $0xffffffffffffffff,%rax
 100bd6c:	je     100bd71 <mylang_qbe_run_process+0x51>
 100bd6e:	mov    (%rbx),%rax
 100bd71:	mov    %rax,-0x58(%rbp)
 100bd75:	mov    %rdi,-0x48(%rbp)
 100bd79:	mov    %r8,-0x38(%rbp)
 100bd7d:	cmpl   $0x0,0x1c(%rbx)
 100bd81:	je     100bd87 <mylang_qbe_run_process+0x67>
 100bd83:	mov    0x8(%rbx),%r13
 100bd87:	mov    0x10(%rbx),%r12
 100bd8b:	test   %r12,%r12
 100bd8e:	je     100be6e <mylang_qbe_run_process+0x14e>
 100bd94:	lea    -0x8b8(%rbp),%rdi
 100bd9b:	vxorps %xmm0,%xmm0,%xmm0
 100bd9f:	vmovups %ymm0,-0x848(%rbp)
 100bda7:	vmovups %ymm0,-0x858(%rbp)
 100bdaf:	vmovups %ymm0,-0x878(%rbp)
 100bdb7:	vmovups %ymm0,-0x898(%rbp)
 100bdbf:	vmovups %ymm0,-0x8b8(%rbp)
 100bdc7:	lea    0x14f2(%rip),%rax        # 100d2c0 <on_timeout>
 100bdce:	mov    %rax,-0x8c0(%rbp)
 100bdd5:	vzeroupper
 100bdd8:	call   101edf0 <sigemptyset@plt>
 100bddd:	lea    -0x8c0(%rbp),%rsi
 100bde4:	mov    $0xe,%edi
 100bde9:	xor    %edx,%edx
 100bdeb:	call   101ee00 <sigaction@plt>
 100bdf0:	test   %eax,%eax
 100bdf2:	jne    100bf9f <mylang_qbe_run_process+0x27f>
 100bdf8:	vxorps %xmm0,%xmm0,%xmm0
 100bdfc:	vmovups %ymm0,-0xcc0(%rbp)
 100be04:	vmovups %ymm0,-0xca0(%rbp)
 100be0c:	movl   $0xe,-0xcb8(%rbp)
 100be16:	lea    0x1e7ab(%rip),%rdx        # 102a5c8 <timeout_timer>
 100be1d:	lea    -0xcc0(%rbp),%rsi
 100be24:	mov    $0x1,%edi
 100be29:	vzeroupper
 100be2c:	call   101ee10 <timer_create@plt>
 100be31:	test   %eax,%eax
 100be33:	jne    100bf9f <mylang_qbe_run_process+0x27f>
 100be39:	vxorps %xmm0,%xmm0,%xmm0
 100be3d:	vmovups %ymm0,-0x2c0(%rbp)
 100be45:	mov    %r12,-0x2b0(%rbp)
 100be4c:	mov    0x1e775(%rip),%rdi        # 102a5c8 <timeout_timer>
 100be53:	lea    -0x2c0(%rbp),%rdx
 100be5a:	xor    %esi,%esi
 100be5c:	xor    %ecx,%ecx
 100be5e:	vzeroupper
 100be61:	call   101ee20 <timer_settime@plt>
 100be66:	test   %eax,%eax
 100be68:	jne    100bf9f <mylang_qbe_run_process+0x27f>
 100be6e:	mov    %r13,-0x50(%rbp)
 100be72:	mov    %r14,-0x40(%rbp)
 100be76:	test   %r14d,%r14d
 100be79:	jle    100beb7 <mylang_qbe_run_process+0x197>
 100be7b:	mov    -0x40(%rbp),%r13d
 100be7f:	xor    %r14d,%r14d
 100be82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100be90:	mov    (%r15,%r14,8),%r12
 100be94:	mov    %r12,%rdi
 100be97:	call   101e450 <compiler_rt.strlen>
 100be9c:	mov    %r12,%rdi
 100be9f:	mov    %rax,%rsi
 100bea2:	call   1012210 <myl_native_text_valid_utf8>
 100bea7:	test   %eax,%eax
 100bea9:	je     100bfe9 <mylang_qbe_run_process+0x2c9>
 100beaf:	inc    %r14
 100beb2:	cmp    %r14,%r13
 100beb5:	jne    100be90 <mylang_qbe_run_process+0x170>
 100beb7:	mov    0x24(%rbx),%ecx
 100beba:	sub    $0x8,%rsp
 100bebe:	lea    -0x2c0(%rbp),%rax
 100bec5:	mov    -0x48(%rbp),%rdi
 100bec9:	mov    -0x58(%rbp),%rsi
 100becd:	mov    -0x50(%rbp),%rdx
 100bed1:	mov    -0x38(%rbp),%r8
 100bed5:	xor    %r9d,%r9d
 100bed8:	push   %rax
 100bed9:	push   %r15
 100bedb:	push   -0x40(%rbp)
 100bede:	call   100c630 <execute_config_args>
 100bee3:	add    $0x20,%rsp
 100bee7:	test   %eax,%eax
 100bee9:	je     100bf7b <mylang_qbe_run_process+0x25b>
 100beef:	mov    $0x2,%eax
 100bef4:	cmpl   $0x0,-0x98(%rbp)
 100befb:	jne    100c00e <mylang_qbe_run_process+0x2ee>
 100bf01:	lea    -0xcc0(%rbp),%rdi
 100bf08:	mov    $0x400,%edx
 100bf0d:	xor    %esi,%esi
 100bf0f:	call   101e4a0 <compiler_rt.fastMemset>
 100bf14:	movq   $0x0,-0x8c0(%rbp)
 100bf1f:	movb   $0x0,-0xcc0(%rbp)
 100bf26:	mov    -0x90(%rbp),%eax
 100bf2c:	mov    %eax,-0x40(%rbp)
 100bf2f:	test   %eax,%eax
 100bf31:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100bf37:	mov    -0x8c(%rbp),%ebx
 100bf3d:	test   $0x1,%bl
 100bf40:	jne    100c020 <mylang_qbe_run_process+0x300>
 100bf46:	test   $0x2,%bl
 100bf49:	jne    100c09d <mylang_qbe_run_process+0x37d>
 100bf4f:	mov    -0x60(%rbp),%r8
 100bf53:	test   $0x1c,%bl
 100bf56:	jne    100c3fc <mylang_qbe_run_process+0x6dc>
 100bf5c:	test   %r8,%r8
 100bf5f:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100bf65:	cmpb   $0x0,(%r8)
 100bf69:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100bf6f:	lea    -0xa6db(%rip),%rcx        # 100189b <__abi_tag+0x159f>
 100bf76:	jmp    100c0a8 <mylang_qbe_run_process+0x388>
 100bf7b:	mov    -0x2c0(%rbp),%r14
 100bf82:	cmpl   $0x0,0x28(%rbx)
 100bf86:	je     100bf99 <mylang_qbe_run_process+0x279>
 100bf88:	lea    -0x9e35(%rip),%rdi        # 100215a <__abi_tag+0x1e5e>
 100bf8f:	mov    %r14,%rsi
 100bf92:	xor    %eax,%eax
 100bf94:	call   101ee30 <printf@plt>
 100bf99:	movzbl %r14b,%eax
 100bf9d:	jmp    100c00e <mylang_qbe_run_process+0x2ee>
 100bf9f:	mov    0x1d3c2(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100bfa6:	mov    (%rax),%rcx
 100bfa9:	lea    -0x9e89(%rip),%rdi        # 1002127 <__abi_tag+0x1e2b>
 100bfb0:	mov    $0x32,%esi
 100bfb5:	jmp    100bfff <mylang_qbe_run_process+0x2df>
 100bfb7:	mov    0x1d3aa(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100bfbe:	mov    (%rax),%rcx
 100bfc1:	lea    -0x9f6d(%rip),%rdi        # 100205b <__abi_tag+0x1d5f>
 100bfc8:	mov    $0x5e,%esi
 100bfcd:	jmp    100bfff <mylang_qbe_run_process+0x2df>
 100bfcf:	mov    0x1d392(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100bfd6:	mov    (%rax),%rdi
 100bfd9:	lea    -0x9ed2(%rip),%rsi        # 100210e <__abi_tag+0x1e12>
 100bfe0:	xor    %eax,%eax
 100bfe2:	call   101eda0 <fprintf@plt>
 100bfe7:	jmp    100c009 <mylang_qbe_run_process+0x2e9>
 100bfe9:	mov    0x1d378(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100bff0:	mov    (%rax),%rcx
 100bff3:	lea    -0x9e62(%rip),%rdi        # 1002198 <__abi_tag+0x1e9c>
 100bffa:	mov    $0x2a,%esi
 100bfff:	mov    $0x1,%edx
 100c004:	call   101ed90 <fwrite@plt>
 100c009:	mov    $0x2,%eax
 100c00e:	add    $0xc98,%rsp
 100c015:	pop    %rbx
 100c016:	pop    %r12
 100c018:	pop    %r13
 100c01a:	pop    %r14
 100c01c:	pop    %r15
 100c01e:	pop    %rbp
 100c01f:	ret
 100c020:	mov    -0x88(%rbp),%r8
 100c027:	lea    -0xa573(%rip),%rcx        # 1001abb <__abi_tag+0x17bf>
 100c02e:	lea    -0xcc0(%rbp),%rdi
 100c035:	lea    -0x8c0(%rbp),%rdx
 100c03c:	mov    $0x400,%esi
 100c041:	xor    %eax,%eax
 100c043:	call   100c9c0 <append>
 100c048:	test   %eax,%eax
 100c04a:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100c04c:	test   $0x2,%bl
 100c04f:	je     100c07a <mylang_qbe_run_process+0x35a>
 100c051:	mov    -0x80(%rbp),%r8
 100c055:	lea    -0xa850(%rip),%rcx        # 100180c <__abi_tag+0x1510>
 100c05c:	lea    -0xcc0(%rbp),%rdi
 100c063:	lea    -0x8c0(%rbp),%rdx
 100c06a:	mov    $0x400,%esi
 100c06f:	xor    %eax,%eax
 100c071:	call   100c9c0 <append>
 100c076:	test   %eax,%eax
 100c078:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100c07a:	lea    -0xa208(%rip),%rcx        # 1001e79 <__abi_tag+0x1b7d>
 100c081:	lea    -0xcc0(%rbp),%rdi
 100c088:	lea    -0x8c0(%rbp),%rdx
 100c08f:	mov    $0x400,%esi
 100c094:	xor    %eax,%eax
 100c096:	call   100c9c0 <append>
 100c09b:	jmp    100c0c2 <mylang_qbe_run_process+0x3a2>
 100c09d:	mov    -0x80(%rbp),%r8
 100c0a1:	lea    -0xa2c8(%rip),%rcx        # 1001de0 <__abi_tag+0x1ae4>
 100c0a8:	lea    -0xcc0(%rbp),%rdi
 100c0af:	lea    -0x8c0(%rbp),%rdx
 100c0b6:	mov    $0x400,%esi
 100c0bb:	xor    %eax,%eax
 100c0bd:	call   100c9c0 <append>
 100c0c2:	mov    -0x2b0(%rbp),%r14
 100c0c9:	lea    -0xa483(%rip),%rsi        # 1001c4d <__abi_tag+0x1951>
 100c0d0:	mov    %r14,%rdi
 100c0d3:	call   101ede0 <strcmp@plt>
 100c0d8:	test   %eax,%eax
 100c0da:	sete   %al
 100c0dd:	mov    -0xa8(%rbp),%rbx
 100c0e4:	cmp    $0x2,%rbx
 100c0e8:	setae  %cl
 100c0eb:	and    %al,%cl
 100c0ed:	cmp    $0x1,%cl
 100c0f0:	jne    100c14a <mylang_qbe_run_process+0x42a>
 100c0f2:	lea    -0xcc0(%rbp),%r12
 100c0f9:	mov    %r12,%rdi
 100c0fc:	call   101e450 <compiler_rt.strlen>
 100c101:	mov    %rax,-0x8c0(%rbp)
 100c108:	mov    -0x288(%rbp),%r8
 100c10f:	mov    -0x280(%rbp),%r9
 100c116:	vmovups -0x278(%rbp),%xmm0
 100c11e:	sub    $0x10,%rsp
 100c122:	vmovups %xmm0,(%rsp)
 100c127:	lea    -0xa994(%rip),%rcx        # 100179a <__abi_tag+0x149e>
 100c12e:	lea    -0x8c0(%rbp),%rdx
 100c135:	mov    $0x400,%esi
 100c13a:	mov    %r12,%rdi
 100c13d:	xor    %eax,%eax
 100c13f:	call   100c9c0 <append>
 100c144:	add    $0x10,%rsp
 100c148:	jmp    100c187 <mylang_qbe_run_process+0x467>
 100c14a:	test   %rbx,%rbx
 100c14d:	jne    100c187 <mylang_qbe_run_process+0x467>
 100c14f:	mov    0x1d212(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100c156:	mov    (%rax),%r15
 100c159:	mov    %r14,%rdi
 100c15c:	call   100cb80 <describe>
 100c161:	lea    -0xa188(%rip),%rsi        # 1001fe0 <__abi_tag+0x1ce4>
 100c168:	lea    -0xcc0(%rbp),%r8
 100c16f:	mov    %r15,%rdi
 100c172:	mov    %r14,%r13
 100c175:	mov    %r14,%rdx
 100c178:	mov    %rax,%rcx
 100c17b:	xor    %eax,%eax
 100c17d:	call   101eda0 <fprintf@plt>
 100c182:	jmp    100c225 <mylang_qbe_run_process+0x505>
 100c187:	mov    0x1d1da(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100c18e:	mov    (%rax),%r12
 100c191:	mov    -0x2a0(%rbp),%rax
 100c198:	mov    %rax,-0x38(%rbp)
 100c19c:	mov    -0x298(%rbp),%rax
 100c1a3:	mov    %rax,-0x48(%rbp)
 100c1a7:	lea    -0x290(%rbp),%r15
 100c1ae:	mov    -0x290(%rbp),%r13
 100c1b5:	mov    %r14,%rdi
 100c1b8:	call   100cb80 <describe>
 100c1bd:	mov    %rax,%r10
 100c1c0:	lea    -0xa1dd(%rip),%rsi        # 1001fea <__abi_tag+0x1cee>
 100c1c7:	mov    %r12,%rdi
 100c1ca:	mov    0x1d197(%rip),%r12        # 1029368 <stderr@GLIBC_2.2.5>
 100c1d1:	mov    -0x38(%rbp),%rdx
 100c1d5:	mov    -0x48(%rbp),%rcx
 100c1d9:	mov    %r13,%r8
 100c1dc:	mov    %r14,%r13
 100c1df:	mov    %r14,%r9
 100c1e2:	xor    %eax,%eax
 100c1e4:	lea    -0xcc0(%rbp),%r11
 100c1eb:	push   %r11
 100c1ed:	push   %r10
 100c1ef:	call   101eda0 <fprintf@plt>
 100c1f4:	add    $0x10,%rsp
 100c1f8:	lea    -0xa374(%rip),%r14        # 1001e8b <__abi_tag+0x1b8f>
 100c1ff:	mov    -0x18(%r15),%rdx
 100c203:	mov    -0x10(%r15),%rcx
 100c207:	mov    -0x8(%r15),%r8
 100c20b:	mov    (%r15),%r9
 100c20e:	mov    (%r12),%rdi
 100c212:	mov    %r14,%rsi
 100c215:	xor    %eax,%eax
 100c217:	call   101eda0 <fprintf@plt>
 100c21c:	add    $0x20,%r15
 100c220:	dec    %rbx
 100c223:	jne    100c1ff <mylang_qbe_run_process+0x4df>
 100c225:	movq   $0x0,-0x30(%rbp)
 100c22d:	movb   $0x0,-0x8c0(%rbp)
 100c234:	mov    -0x40(%rbp),%r8d
 100c238:	test   %r8d,%r8d
 100c23b:	je     100c565 <mylang_qbe_run_process+0x845>
 100c241:	mov    -0x8c(%rbp),%eax
 100c247:	mov    %eax,-0x38(%rbp)
 100c24a:	lea    -0xa49b(%rip),%rcx        # 1001db6 <__abi_tag+0x1aba>
 100c251:	lea    -0x8c0(%rbp),%rdi
 100c258:	lea    -0x30(%rbp),%rdx
 100c25c:	mov    $0x600,%esi
 100c261:	xor    %eax,%eax
 100c263:	call   100c9c0 <append>
 100c268:	test   %eax,%eax
 100c26a:	je     100c565 <mylang_qbe_run_process+0x845>
 100c270:	mov    -0x60(%rbp),%r14
 100c274:	lea    -0xa400(%rip),%rcx        # 1001e7b <__abi_tag+0x1b7f>
 100c27b:	lea    -0x8c0(%rbp),%rdi
 100c282:	lea    -0x30(%rbp),%rdx
 100c286:	mov    $0x600,%esi
 100c28b:	xor    %eax,%eax
 100c28d:	call   100c9c0 <append>
 100c292:	test   %eax,%eax
 100c294:	je     100c565 <mylang_qbe_run_process+0x845>
 100c29a:	test   %r14,%r14
 100c29d:	lea    -0xa9b4(%rip),%rbx        # 10018f0 <__abi_tag+0x15f4>
 100c2a4:	cmovne %r14,%rbx
 100c2a8:	movzbl (%rbx),%eax
 100c2ab:	test   %al,%al
 100c2ad:	je     100c320 <mylang_qbe_run_process+0x600>
 100c2af:	inc    %rbx
 100c2b2:	lea    -0xa735(%rip),%r14        # 1001b84 <__abi_tag+0x1888>
 100c2b9:	lea    -0x8c0(%rbp),%r15
 100c2c0:	lea    -0x30(%rbp),%r12
 100c2c4:	movzbl %al,%r8d
 100c2c8:	cmp    $0x5c,%r8b
 100c2cc:	je     100c2d4 <mylang_qbe_run_process+0x5b4>
 100c2ce:	cmp    $0x22,%r8d
 100c2d2:	jne    100c2fd <mylang_qbe_run_process+0x5dd>
 100c2d4:	mov    $0x600,%esi
 100c2d9:	mov    %r15,%rdi
 100c2dc:	mov    %r12,%rdx
 100c2df:	mov    %r14,%rcx
 100c2e2:	xor    %eax,%eax
 100c2e4:	call   100c9c0 <append>
 100c2e9:	test   %eax,%eax
 100c2eb:	je     100c565 <mylang_qbe_run_process+0x845>
 100c2f1:	movzbl (%rbx),%eax
 100c2f4:	inc    %rbx
 100c2f7:	test   %al,%al
 100c2f9:	jne    100c2c4 <mylang_qbe_run_process+0x5a4>
 100c2fb:	jmp    100c320 <mylang_qbe_run_process+0x600>
 100c2fd:	mov    $0x600,%esi
 100c302:	mov    %r15,%rdi
 100c305:	mov    %r12,%rdx
 100c308:	cmp    $0x1f,%r8b
 100c30c:	ja     100c317 <mylang_qbe_run_process+0x5f7>
 100c30e:	lea    -0xab9d(%rip),%rcx        # 1001778 <__abi_tag+0x147c>
 100c315:	jmp    100c2e2 <mylang_qbe_run_process+0x5c2>
 100c317:	lea    -0xa799(%rip),%rcx        # 1001b85 <__abi_tag+0x1889>
 100c31e:	jmp    100c2e2 <mylang_qbe_run_process+0x5c2>
 100c320:	lea    -0xa4ac(%rip),%rcx        # 1001e7b <__abi_tag+0x1b7f>
 100c327:	lea    -0x8c0(%rbp),%rdi
 100c32e:	lea    -0x30(%rbp),%rdx
 100c332:	mov    $0x600,%esi
 100c337:	xor    %eax,%eax
 100c339:	call   100c9c0 <append>
 100c33e:	test   %eax,%eax
 100c340:	je     100c565 <mylang_qbe_run_process+0x845>
 100c346:	testb  $0x1,-0x38(%rbp)
 100c34a:	je     100c379 <mylang_qbe_run_process+0x659>
 100c34c:	mov    -0x88(%rbp),%r8
 100c353:	lea    -0xa8c5(%rip),%rcx        # 1001a95 <__abi_tag+0x1799>
 100c35a:	lea    -0x8c0(%rbp),%rdi
 100c361:	lea    -0x30(%rbp),%rdx
 100c365:	mov    $0x600,%esi
 100c36a:	xor    %eax,%eax
 100c36c:	call   100c9c0 <append>
 100c371:	test   %eax,%eax
 100c373:	je     100c565 <mylang_qbe_run_process+0x845>
 100c379:	testb  $0x2,-0x38(%rbp)
 100c37d:	je     100c3a9 <mylang_qbe_run_process+0x689>
 100c37f:	mov    -0x80(%rbp),%r8
 100c383:	lea    -0xabaf(%rip),%rcx        # 10017db <__abi_tag+0x14df>
 100c38a:	lea    -0x8c0(%rbp),%rdi
 100c391:	lea    -0x30(%rbp),%rdx
 100c395:	mov    $0x600,%esi
 100c39a:	xor    %eax,%eax
 100c39c:	call   100c9c0 <append>
 100c3a1:	test   %eax,%eax
 100c3a3:	je     100c565 <mylang_qbe_run_process+0x845>
 100c3a9:	mov    -0x38(%rbp),%eax
 100c3ac:	test   $0x20,%al
 100c3ae:	jne    100c48a <mylang_qbe_run_process+0x76a>
 100c3b4:	test   $0x4,%al
 100c3b6:	je     100c3e2 <mylang_qbe_run_process+0x6c2>
 100c3b8:	mov    -0x78(%rbp),%r8
 100c3bc:	lea    -0xa914(%rip),%rcx        # 1001aaf <__abi_tag+0x17b3>
 100c3c3:	lea    -0x8c0(%rbp),%rdi
 100c3ca:	lea    -0x30(%rbp),%rdx
 100c3ce:	mov    $0x600,%esi
 100c3d3:	xor    %eax,%eax
 100c3d5:	call   100c9c0 <append>
 100c3da:	test   %eax,%eax
 100c3dc:	je     100c565 <mylang_qbe_run_process+0x845>
 100c3e2:	testb  $0x8,-0x38(%rbp)
 100c3e6:	je     100c50c <mylang_qbe_run_process+0x7ec>
 100c3ec:	mov    -0x70(%rbp),%r8
 100c3f0:	lea    -0xa955(%rip),%rcx        # 1001aa2 <__abi_tag+0x17a6>
 100c3f7:	jmp    100c4f1 <mylang_qbe_run_process+0x7d1>
 100c3fc:	test   %r8,%r8
 100c3ff:	lea    -0xa88d(%rip),%rax        # 1001b79 <__abi_tag+0x187d>
 100c406:	cmovne %r8,%rax
 100c40a:	lea    -0xa661(%rip),%rcx        # 1001db0 <__abi_tag+0x1ab4>
 100c411:	lea    -0xcc0(%rbp),%rdi
 100c418:	lea    -0x8c0(%rbp),%rdx
 100c41f:	mov    $0x400,%esi
 100c424:	mov    %rax,%r8
 100c427:	xor    %eax,%eax
 100c429:	call   100c9c0 <append>
 100c42e:	test   %eax,%eax
 100c430:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100c436:	test   $0x20,%bl
 100c439:	jne    100c586 <mylang_qbe_run_process+0x866>
 100c43f:	test   $0x4,%bl
 100c442:	je     100c471 <mylang_qbe_run_process+0x751>
 100c444:	mov    -0x78(%rbp),%r8
 100c448:	lea    -0xa97c(%rip),%rcx        # 1001ad3 <__abi_tag+0x17d7>
 100c44f:	lea    -0xcc0(%rbp),%rdi
 100c456:	lea    -0x8c0(%rbp),%rdx
 100c45d:	mov    $0x400,%esi
 100c462:	xor    %eax,%eax
 100c464:	call   100c9c0 <append>
 100c469:	test   %eax,%eax
 100c46b:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100c471:	test   $0x8,%bl
 100c474:	je     100c5ea <mylang_qbe_run_process+0x8ca>
 100c47a:	mov    -0x70(%rbp),%r8
 100c47e:	lea    -0xa9be(%rip),%rcx        # 1001ac7 <__abi_tag+0x17cb>
 100c485:	jmp    100c5c8 <mylang_qbe_run_process+0x8a8>
 100c48a:	lea    -0xaa2c(%rip),%rcx        # 1001a65 <__abi_tag+0x1769>
 100c491:	lea    -0x8c0(%rbp),%rdi
 100c498:	lea    -0x30(%rbp),%rdx
 100c49c:	mov    $0x600,%esi
 100c4a1:	xor    %eax,%eax
 100c4a3:	call   100c9c0 <append>
 100c4a8:	test   %eax,%eax
 100c4aa:	je     100c565 <mylang_qbe_run_process+0x845>
 100c4b0:	testb  $0x4,-0x38(%rbp)
 100c4b4:	je     100c4e0 <mylang_qbe_run_process+0x7c0>
 100c4b6:	mov    -0x78(%rbp),%r8
 100c4ba:	lea    -0xacf2(%rip),%rcx        # 10017cf <__abi_tag+0x14d3>
 100c4c1:	lea    -0x8c0(%rbp),%rdi
 100c4c8:	lea    -0x30(%rbp),%rdx
 100c4cc:	mov    $0x600,%esi
 100c4d1:	xor    %eax,%eax
 100c4d3:	call   100c9c0 <append>
 100c4d8:	test   %eax,%eax
 100c4da:	je     100c565 <mylang_qbe_run_process+0x845>
 100c4e0:	testb  $0x8,-0x38(%rbp)
 100c4e4:	je     100c50c <mylang_qbe_run_process+0x7ec>
 100c4e6:	mov    -0x70(%rbp),%r8
 100c4ea:	lea    -0xad2f(%rip),%rcx        # 10017c2 <__abi_tag+0x14c6>
 100c4f1:	lea    -0x8c0(%rbp),%rdi
 100c4f8:	lea    -0x30(%rbp),%rdx
 100c4fc:	mov    $0x600,%esi
 100c501:	xor    %eax,%eax
 100c503:	call   100c9c0 <append>
 100c508:	test   %eax,%eax
 100c50a:	je     100c565 <mylang_qbe_run_process+0x845>
 100c50c:	testb  $0x10,-0x38(%rbp)
 100c510:	je     100c538 <mylang_qbe_run_process+0x818>
 100c512:	mov    -0x68(%rbp),%r8
 100c516:	lea    -0xad34(%rip),%rcx        # 10017e9 <__abi_tag+0x14ed>
 100c51d:	lea    -0x8c0(%rbp),%rdi
 100c524:	lea    -0x30(%rbp),%rdx
 100c528:	mov    $0x600,%esi
 100c52d:	xor    %eax,%eax
 100c52f:	call   100c9c0 <append>
 100c534:	test   %eax,%eax
 100c536:	je     100c565 <mylang_qbe_run_process+0x845>
 100c538:	lea    -0xae4f(%rip),%rcx        # 10016f0 <__abi_tag+0x13f4>
 100c53f:	lea    -0x8c0(%rbp),%rdi
 100c546:	lea    -0x30(%rbp),%rdx
 100c54a:	mov    $0x600,%esi
 100c54f:	xor    %eax,%eax
 100c551:	call   100c9c0 <append>
 100c556:	test   %eax,%eax
 100c558:	je     100c565 <mylang_qbe_run_process+0x845>
 100c55a:	cmpq   $0x0,-0x30(%rbp)
 100c55f:	jne    100c603 <mylang_qbe_run_process+0x8e3>
 100c565:	mov    $0x2,%eax
 100c56a:	cmpb   $0x52,0x0(%r13)
 100c56f:	jne    100c00e <mylang_qbe_run_process+0x2ee>
 100c575:	xor    %eax,%eax
 100c577:	cmpb   $0x5f,0x1(%r13)
 100c57c:	setne  %al
 100c57f:	inc    %eax
 100c581:	jmp    100c00e <mylang_qbe_run_process+0x2ee>
 100c586:	test   $0x4,%bl
 100c589:	je     100c5b8 <mylang_qbe_run_process+0x898>
 100c58b:	mov    -0x78(%rbp),%r8
 100c58f:	lea    -0xad94(%rip),%rcx        # 1001802 <__abi_tag+0x1506>
 100c596:	lea    -0xcc0(%rbp),%rdi
 100c59d:	lea    -0x8c0(%rbp),%rdx
 100c5a4:	mov    $0x400,%esi
 100c5a9:	xor    %eax,%eax
 100c5ab:	call   100c9c0 <append>
 100c5b0:	test   %eax,%eax
 100c5b2:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100c5b8:	test   $0x8,%bl
 100c5bb:	je     100c5ea <mylang_qbe_run_process+0x8ca>
 100c5bd:	mov    -0x70(%rbp),%r8
 100c5c1:	lea    -0xadd2(%rip),%rcx        # 10017f6 <__abi_tag+0x14fa>
 100c5c8:	lea    -0xcc0(%rbp),%rdi
 100c5cf:	lea    -0x8c0(%rbp),%rdx
 100c5d6:	mov    $0x400,%esi
 100c5db:	xor    %eax,%eax
 100c5dd:	call   100c9c0 <append>
 100c5e2:	test   %eax,%eax
 100c5e4:	je     100c0c2 <mylang_qbe_run_process+0x3a2>
 100c5ea:	test   $0x10,%bl
 100c5ed:	je     100c07a <mylang_qbe_run_process+0x35a>
 100c5f3:	mov    -0x68(%rbp),%r8
 100c5f7:	lea    -0xade5(%rip),%rcx        # 1001819 <__abi_tag+0x151d>
 100c5fe:	jmp    100c05c <mylang_qbe_run_process+0x33c>
 100c603:	mov    0x1cd5e(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100c60a:	mov    (%rax),%rdi
 100c60d:	lea    -0xa5ff(%rip),%rsi        # 1002015 <__abi_tag+0x1d19>
 100c614:	lea    -0xa79e(%rip),%rdx        # 1001e7d <__abi_tag+0x1b81>
 100c61b:	lea    -0x8c0(%rbp),%rcx
 100c622:	xor    %eax,%eax
 100c624:	call   101eda0 <fprintf@plt>
 100c629:	jmp    100c565 <mylang_qbe_run_process+0x845>
 100c62e:	int3
 100c62f:	int3

000000000100c630 <execute_config_args>:
 100c630:	push   %rbp
 100c631:	mov    %rsp,%rbp
 100c634:	push   %r15
 100c636:	push   %r14
 100c638:	push   %r13
 100c63a:	push   %r12
 100c63c:	push   %rbx
 100c63d:	sub    $0x48,%rsp
 100c641:	mov    %r9,%r12
 100c644:	mov    %r8,-0x50(%rbp)
 100c648:	mov    %ecx,-0x30(%rbp)
 100c64b:	mov    %rdx,%r14
 100c64e:	mov    %rsi,%r13
 100c651:	mov    %rdi,%rbx
 100c654:	mov    0x20(%rbp),%r15
 100c658:	mov    $0x268,%edx
 100c65d:	mov    %r15,%rdi
 100c660:	xor    %esi,%esi
 100c662:	call   101e4a0 <compiler_rt.fastMemset>
 100c667:	test   %r13,%r13
 100c66a:	setne  %al
 100c66d:	test   %r14,%r14
 100c670:	setne  %cl
 100c673:	test   %cl,%al
 100c675:	je     100c69b <execute_config_args+0x6b>
 100c677:	mov    %r12,-0x48(%rbp)
 100c67b:	cmp    $0xffffffffffffffff,%r14
 100c67f:	mov    $0x400,%r12d
 100c685:	cmovne %r14,%r12
 100c689:	mov    %r12,%rax
 100c68c:	shr    $0x3b,%rax
 100c690:	je     100c6ba <execute_config_args+0x8a>
 100c692:	lea    -0xafa7(%rip),%rax        # 10016f2 <__abi_tag+0x13f6>
 100c699:	jmp    100c6a2 <execute_config_args+0x72>
 100c69b:	lea    -0xae37(%rip),%rax        # 100186b <__abi_tag+0x156f>
 100c6a2:	mov    %rax,0x10(%r15)
 100c6a6:	mov    $0x1,%eax
 100c6ab:	add    $0x48,%rsp
 100c6af:	pop    %rbx
 100c6b0:	pop    %r12
 100c6b2:	pop    %r13
 100c6b4:	pop    %r14
 100c6b6:	pop    %r15
 100c6b8:	pop    %rbp
 100c6b9:	ret
 100c6ba:	movl   $0x1,-0x2c(%rbp)
 100c6c1:	lea    -0x2c(%rbp),%rdi
 100c6c5:	call   100e820 <myl_native_budget_environment>
 100c6ca:	cmpl   $0x0,-0x2c(%rbp)
 100c6ce:	je     100c7fa <execute_config_args+0x1ca>
 100c6d4:	mov    %rbx,-0x38(%rbp)
 100c6d8:	mov    %rax,-0x40(%rbp)
 100c6dc:	mov    %rax,%rdi
 100c6df:	call   100e940 <myl_native_budget_guard>
 100c6e4:	mov    $0x1,%edi
 100c6e9:	mov    $0x3e88,%esi
 100c6ee:	call   101ed70 <calloc@plt>
 100c6f3:	test   %rax,%rax
 100c6f6:	je     100c692 <execute_config_args+0x62>
 100c6f8:	mov    %rax,%rbx
 100c6fb:	mov    0x18(%rbp),%rax
 100c6ff:	mov    0x10(%rbp),%ecx
 100c702:	mov    %r13,0x10(%rbx)
 100c706:	mov    %r12,0x18(%rbx)
 100c70a:	mov    %r14,0x38(%rbx)
 100c70e:	mov    -0x50(%rbp),%rdx
 100c712:	mov    %rdx,0x3978(%rbx)
 100c719:	mov    %ecx,0x39d0(%rbx)
 100c71f:	mov    %rax,0x39d8(%rbx)
 100c726:	lea    0x258(%rbx),%r14
 100c72d:	xor    %esi,%esi
 100c72f:	mov    -0x40(%rbp),%rax
 100c733:	cmp    $0x1,%rax
 100c737:	sbb    %rsi,%rsi
 100c73a:	or     %rax,%rsi
 100c73d:	mov    %r14,%rdi
 100c740:	call   100eb30 <myl_native_heap_init>
 100c745:	mov    -0x30(%rbp),%eax
 100c748:	mov    %eax,0x2c0(%rbx)
 100c74e:	mov    %rbx,%rdi
 100c751:	call   100b070 <myl_qbe_rc_initialize>
 100c756:	cmpq   $0x0,0x20(%rbx)
 100c75b:	jne    100c811 <execute_config_args+0x1e1>
 100c761:	mov    $0x20,%esi
 100c766:	mov    %r12,%rdi
 100c769:	call   101ed70 <calloc@plt>
 100c76e:	mov    %rax,0x28(%rbx)
 100c772:	test   %rax,%rax
 100c775:	je     100c806 <execute_config_args+0x1d6>
 100c77b:	call   101edb0 <fegetround@plt>
 100c780:	test   %eax,%eax
 100c782:	jne    100c7e9 <execute_config_args+0x1b9>
 100c784:	movabs $0x10000000000000,%rax
 100c78e:	mov    %rax,-0x70(%rbp)
 100c792:	movabs $0x3fe0000000000000,%rax
 100c79c:	mov    %rax,-0x68(%rbp)
 100c7a0:	movq   $0x1,-0x60(%rbp)
 100c7a8:	movabs $0x3ff0000000000000,%rax
 100c7b2:	mov    %rax,-0x58(%rbp)
 100c7b6:	vmovsd -0x70(%rbp),%xmm0
 100c7bb:	vmulsd -0x68(%rbp),%xmm0,%xmm0
 100c7c0:	vmovq  %xmm0,%rax
 100c7c5:	movabs $0x8000000000000,%rcx
 100c7cf:	cmp    %rcx,%rax
 100c7d2:	jne    100c7e9 <execute_config_args+0x1b9>
 100c7d4:	vmovsd -0x60(%rbp),%xmm0
 100c7d9:	vmulsd -0x58(%rbp),%xmm0,%xmm0
 100c7de:	vmovq  %xmm0,%rax
 100c7e3:	cmp    $0x1,%rax
 100c7e7:	je     100c811 <execute_config_args+0x1e1>
 100c7e9:	lea    -0xac33(%rip),%rsi        # 1001bbd <__abi_tag+0x18c1>
 100c7f0:	mov    %rbx,%rdi
 100c7f3:	call   100b4d5 <fail>
 100c7f8:	jmp    100c811 <execute_config_args+0x1e1>
 100c7fa:	lea    -0xafad(%rip),%rax        # 1001854 <__abi_tag+0x1558>
 100c801:	jmp    100c6a2 <execute_config_args+0x72>
 100c806:	lea    -0xb11b(%rip),%rax        # 10016f2 <__abi_tag+0x13f6>
 100c80d:	mov    %rax,0x20(%rbx)
 100c811:	mov    0x20(%rbx),%rax
 100c815:	test   %rax,%rax
 100c818:	setne  %cl
 100c81b:	mov    -0x48(%rbp),%rsi
 100c81f:	test   %rsi,%rsi
 100c822:	sete   %dl
 100c825:	or     %cl,%dl
 100c827:	jne    100c832 <execute_config_args+0x202>
 100c829:	mov    %rbx,%rdi
 100c82c:	call   *%rsi
 100c82e:	mov    0x20(%rbx),%rax
 100c832:	test   %rax,%rax
 100c835:	jne    100c865 <execute_config_args+0x235>
 100c837:	mov    -0x38(%rbp),%rdi
 100c83b:	mov    %rbx,%rsi
 100c83e:	call   100d2f0 <myl_qbe_on_stack>
 100c843:	mov    %rax,(%r15)
 100c846:	mov    0x20(%rbx),%rax
 100c84a:	test   %rax,%rax
 100c84d:	jne    100c865 <execute_config_args+0x235>
 100c84f:	cmpq   $0x0,0x8(%rbx)
 100c854:	je     100c863 <execute_config_args+0x233>
 100c856:	lea    -0xab90(%rip),%rax        # 1001ccd <__abi_tag+0x19d1>
 100c85d:	mov    %rax,0x20(%rbx)
 100c861:	jmp    100c865 <execute_config_args+0x235>
 100c863:	xor    %eax,%eax
 100c865:	mov    (%rbx),%rcx
 100c868:	mov    %rcx,0x8(%r15)
 100c86c:	mov    %rax,0x10(%r15)
 100c870:	vmovups 0x248(%rbx),%xmm0
 100c878:	vmovups %xmm0,0x218(%r15)
 100c881:	mov    0x39e0(%rbx),%eax
 100c887:	mov    %eax,0x228(%r15)
 100c88e:	vmovups 0x39e8(%rbx),%ymm0
 100c896:	vmovups 0x3a00(%rbx),%ymm1
 100c89e:	vmovups %ymm0,0x230(%r15)
 100c8a7:	vmovups %ymm1,0x248(%r15)
 100c8b0:	add    $0x18,%r15
 100c8b4:	mov    %rbx,%rsi
 100c8b7:	add    $0x48,%rsi
 100c8bb:	mov    $0x200,%edx
 100c8c0:	mov    %r15,%rdi
 100c8c3:	vzeroupper
 100c8c6:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 100c8cb:	mov    0x3e80(%rbx),%rax
 100c8d2:	test   %rax,%rax
 100c8d5:	je     100c8dc <execute_config_args+0x2ac>
 100c8d7:	mov    %rbx,%rdi
 100c8da:	call   *%rax
 100c8dc:	mov    0x39a0(%rbx),%rax
 100c8e3:	test   %rax,%rax
 100c8e6:	je     100c8ed <execute_config_args+0x2bd>
 100c8e8:	mov    %rbx,%rdi
 100c8eb:	call   *%rax
 100c8ed:	mov    0x3e78(%rbx),%rax
 100c8f4:	test   %rax,%rax
 100c8f7:	je     100c8fe <execute_config_args+0x2ce>
 100c8f9:	mov    %rbx,%rdi
 100c8fc:	call   *%rax
 100c8fe:	cmpq   $0x0,0x20(%rbx)
 100c903:	jne    100c92b <execute_config_args+0x2fb>
 100c905:	cmpb   $0x1,0x1dc9c(%rip)        # 102a5a8 <exit_without_sweep>
 100c90c:	jne    100c92b <execute_config_args+0x2fb>
 100c90e:	cmpl   $0x0,0x2c0(%rbx)
 100c915:	jne    100c92b <execute_config_args+0x2fb>
 100c917:	cmpq   $0x0,0x3990(%rbx)
 100c91f:	jne    100c92b <execute_config_args+0x2fb>
 100c921:	cmpq   $0x0,0x3998(%rbx)
 100c929:	je     100c954 <execute_config_args+0x324>
 100c92b:	mov    %rbx,%rdi
 100c92e:	call   100b200 <myl_qbe_rc_finish>
 100c933:	jmp    100c954 <execute_config_args+0x324>
 100c935:	data16 cs nopw 0x0(%rax,%rax,1)
 100c940:	mov    %rcx,0x39c8(%rbx)
 100c947:	test   %rcx,%rcx
 100c94a:	je     100c94f <execute_config_args+0x31f>
 100c94c:	mov    %rax,(%rcx)
 100c94f:	call   101edc0 <free@plt>
 100c954:	mov    0x39c8(%rbx),%rdi
 100c95b:	test   %rdi,%rdi
 100c95e:	je     100c977 <execute_config_args+0x347>
 100c960:	mov    (%rdi),%rax
 100c963:	mov    0x8(%rdi),%rcx
 100c967:	test   %rax,%rax
 100c96a:	je     100c940 <execute_config_args+0x310>
 100c96c:	mov    %rcx,0x8(%rax)
 100c970:	test   %rcx,%rcx
 100c973:	jne    100c94c <execute_config_args+0x31c>
 100c975:	jmp    100c94f <execute_config_args+0x31f>
 100c977:	mov    0x39a8(%rbx),%rdi
 100c97e:	call   101edc0 <free@plt>
 100c983:	mov    0x28(%rbx),%rdi
 100c987:	call   101edc0 <free@plt>
 100c98c:	cmpb   $0x0,0x1dc15(%rip)        # 102a5a8 <exit_without_sweep>
 100c993:	jne    100c99d <execute_config_args+0x36d>
 100c995:	mov    %r14,%rdi
 100c998:	call   100fc20 <myl_native_heap_destroy>
 100c99d:	xor    %r14d,%r14d
 100c9a0:	cmpq   $0x0,0x20(%rbx)
 100c9a5:	setne  %r14b
 100c9a9:	mov    %rbx,%rdi
 100c9ac:	call   101edc0 <free@plt>
 100c9b1:	mov    %r14d,%eax
 100c9b4:	jmp    100c6ab <execute_config_args+0x7b>
 100c9b9:	int3
 100c9ba:	int3
 100c9bb:	int3
 100c9bc:	int3
 100c9bd:	int3
 100c9be:	int3
 100c9bf:	int3

000000000100c9c0 <append>:
 100c9c0:	push   %rbp
 100c9c1:	mov    %rsp,%rbp
 100c9c4:	push   %r14
 100c9c6:	push   %rbx
 100c9c7:	sub    $0xd0,%rsp
 100c9ce:	mov    %rdx,%rbx
 100c9d1:	mov    %rsi,%r14
 100c9d4:	mov    %r8,-0xc0(%rbp)
 100c9db:	mov    %r9,-0xb8(%rbp)
 100c9e2:	test   %al,%al
 100c9e4:	je     100ca17 <append+0x57>
 100c9e6:	vmovaps %xmm0,-0xb0(%rbp)
 100c9ee:	vmovaps %xmm1,-0xa0(%rbp)
 100c9f6:	vmovaps %xmm2,-0x90(%rbp)
 100c9fe:	vmovaps %xmm3,-0x80(%rbp)
 100ca03:	vmovaps %xmm4,-0x70(%rbp)
 100ca08:	vmovaps %xmm5,-0x60(%rbp)
 100ca0d:	vmovaps %xmm6,-0x50(%rbp)
 100ca12:	vmovaps %xmm7,-0x40(%rbp)
 100ca17:	lea    -0xe0(%rbp),%rax
 100ca1e:	mov    %rax,-0x20(%rbp)
 100ca22:	lea    0x10(%rbp),%rax
 100ca26:	mov    %rax,-0x28(%rbp)
 100ca2a:	movabs $0x3000000020,%rax
 100ca34:	mov    %rax,-0x30(%rbp)
 100ca38:	mov    (%rdx),%rax
 100ca3b:	add    %rax,%rdi
 100ca3e:	sub    %rax,%rsi
 100ca41:	lea    -0x30(%rbp),%rax
 100ca45:	mov    %rcx,%rdx
 100ca48:	mov    %rax,%rcx
 100ca4b:	call   101ee40 <vsnprintf@plt>
 100ca50:	mov    %eax,%ecx
 100ca52:	xor    %eax,%eax
 100ca54:	test   %ecx,%ecx
 100ca56:	js     100ca70 <append+0xb0>
 100ca58:	mov    %ecx,%ecx
 100ca5a:	mov    (%rbx),%rdx
 100ca5d:	sub    %rdx,%r14
 100ca60:	cmp    %rcx,%r14
 100ca63:	jbe    100ca70 <append+0xb0>
 100ca65:	add    %rcx,%rdx
 100ca68:	mov    %rdx,(%rbx)
 100ca6b:	mov    $0x1,%eax
 100ca70:	add    $0xd0,%rsp
 100ca77:	pop    %rbx
 100ca78:	pop    %r14
 100ca7a:	pop    %rbp
 100ca7b:	ret
 100ca7c:	int3
 100ca7d:	int3
 100ca7e:	int3
 100ca7f:	int3

000000000100ca80 <append>:
 100ca80:	push   %rbp
 100ca81:	mov    %rsp,%rbp
 100ca84:	push   %r15
 100ca86:	push   %r14
 100ca88:	push   %r13
 100ca8a:	push   %r12
 100ca8c:	push   %rbx
 100ca8d:	push   %rax
 100ca8e:	mov    %rdx,%r14
 100ca91:	mov    %esi,%r15d
 100ca94:	mov    %rdi,%rbx
 100ca97:	mov    0x3e70(%rdi),%r12
 100ca9e:	test   %r12,%r12
 100caa1:	jne    100cad3 <append+0x53>
 100caa3:	mov    $0x1,%edi
 100caa8:	mov    $0x18,%esi
 100caad:	call   101ed70 <calloc@plt>
 100cab2:	test   %rax,%rax
 100cab5:	je     100cb5a <append+0xda>
 100cabb:	mov    %rax,%r12
 100cabe:	mov    %rax,0x3e70(%rbx)
 100cac5:	lea    0x1bc4(%rip),%rax        # 100e690 <release_all>
 100cacc:	mov    %rax,0x3e78(%rbx)
 100cad3:	mov    0x8(%r12),%rax
 100cad8:	cmp    $0x1000,%rax
 100cade:	jne    100caf1 <append+0x71>
 100cae0:	lea    -0xb2a1(%rip),%rsi        # 1001846 <__abi_tag+0x154a>
 100cae7:	mov    %rbx,%rdi
 100caea:	call   100b4d5 <fail>
 100caef:	jmp    100cb62 <append+0xe2>
 100caf1:	cmp    0x10(%r12),%rax
 100caf6:	jne    100cb28 <append+0xa8>
 100caf8:	lea    (%rax,%rax,1),%rcx
 100cafc:	test   %rax,%rax
 100caff:	mov    $0x8,%r13d
 100cb05:	cmovne %rcx,%r13
 100cb09:	mov    (%r12),%rdi
 100cb0d:	lea    0x0(,%r13,8),%rsi
 100cb15:	call   101ef70 <realloc@plt>
 100cb1a:	test   %rax,%rax
 100cb1d:	je     100cb5a <append+0xda>
 100cb1f:	mov    %rax,(%r12)
 100cb23:	mov    %r13,0x10(%r12)
 100cb28:	mov    $0x1,%edi
 100cb2d:	mov    $0x70,%esi
 100cb32:	call   101ed70 <calloc@plt>
 100cb37:	test   %rax,%rax
 100cb3a:	je     100cb5a <append+0xda>
 100cb3c:	mov    %r15d,(%rax)
 100cb3f:	mov    0x8(%r12),%rcx
 100cb44:	mov    %rcx,(%r14)
 100cb47:	mov    (%r12),%rdx
 100cb4b:	lea    0x1(%rcx),%rsi
 100cb4f:	mov    %rsi,0x8(%r12)
 100cb54:	mov    %rax,(%rdx,%rcx,8)
 100cb58:	jmp    100cb64 <append+0xe4>
 100cb5a:	mov    %rbx,%rdi
 100cb5d:	call   100b590 <myl_qbe_fail_allocation>
 100cb62:	xor    %eax,%eax
 100cb64:	add    $0x8,%rsp
 100cb68:	pop    %rbx
 100cb69:	pop    %r12
 100cb6b:	pop    %r13
 100cb6d:	pop    %r14
 100cb6f:	pop    %r15
 100cb71:	pop    %rbp
 100cb72:	ret
 100cb73:	int3
 100cb74:	int3
 100cb75:	int3
 100cb76:	int3
 100cb77:	int3
 100cb78:	int3
 100cb79:	int3
 100cb7a:	int3
 100cb7b:	int3
 100cb7c:	int3
 100cb7d:	int3
 100cb7e:	int3
 100cb7f:	int3

000000000100cb80 <describe>:
 100cb80:	push   %rbp
 100cb81:	mov    %rsp,%rbp
 100cb84:	push   %rbx
 100cb85:	push   %rax
 100cb86:	mov    %rdi,%rbx
 100cb89:	lea    -0xaf6c(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100cb90:	call   101ede0 <strcmp@plt>
 100cb95:	test   %eax,%eax
 100cb97:	je     100cc4b <describe+0xcb>
 100cb9d:	lea    -0xaf9b(%rip),%rsi        # 1001c09 <__abi_tag+0x190d>
 100cba4:	mov    %rbx,%rdi
 100cba7:	call   101ede0 <strcmp@plt>
 100cbac:	test   %eax,%eax
 100cbae:	je     100cc54 <describe+0xd4>
 100cbb4:	lea    -0xaed7(%rip),%rsi        # 1001ce4 <__abi_tag+0x19e8>
 100cbbb:	mov    %rbx,%rdi
 100cbbe:	call   101ede0 <strcmp@plt>
 100cbc3:	test   %eax,%eax
 100cbc5:	je     100cc5d <describe+0xdd>
 100cbcb:	lea    -0xaed9(%rip),%rsi        # 1001cf9 <__abi_tag+0x19fd>
 100cbd2:	mov    %rbx,%rdi
 100cbd5:	call   101ede0 <strcmp@plt>
 100cbda:	test   %eax,%eax
 100cbdc:	je     100cc66 <describe+0xe6>
 100cbe2:	lea    -0xafd3(%rip),%rsi        # 1001c16 <__abi_tag+0x191a>
 100cbe9:	mov    %rbx,%rdi
 100cbec:	call   101ede0 <strcmp@plt>
 100cbf1:	test   %eax,%eax
 100cbf3:	je     100cc6f <describe+0xef>
 100cbf5:	lea    -0xafaf(%rip),%rsi        # 1001c4d <__abi_tag+0x1951>
 100cbfc:	mov    %rbx,%rdi
 100cbff:	call   101ede0 <strcmp@plt>
 100cc04:	test   %eax,%eax
 100cc06:	je     100cc78 <describe+0xf8>
 100cc08:	lea    -0xafcc(%rip),%rsi        # 1001c43 <__abi_tag+0x1947>
 100cc0f:	mov    %rbx,%rdi
 100cc12:	call   101ede0 <strcmp@plt>
 100cc17:	test   %eax,%eax
 100cc19:	je     100cc81 <describe+0x101>
 100cc1b:	lea    -0xb051(%rip),%rsi        # 1001bd1 <__abi_tag+0x18d5>
 100cc22:	mov    %rbx,%rdi
 100cc25:	call   101ede0 <strcmp@plt>
 100cc2a:	test   %eax,%eax
 100cc2c:	je     100cc8a <describe+0x10a>
 100cc2e:	cmpb   $0x52,(%rbx)
 100cc31:	jne    100cc93 <describe+0x113>
 100cc33:	cmpb   $0x5f,0x1(%rbx)
 100cc37:	lea    -0xb0e1(%rip),%rcx        # 1001b5d <__abi_tag+0x1861>
 100cc3e:	lea    -0xb1cf(%rip),%rax        # 1001a76 <__abi_tag+0x177a>
 100cc45:	cmove  %rcx,%rax
 100cc49:	jmp    100cc9a <describe+0x11a>
 100cc4b:	lea    -0xb175(%rip),%rax        # 1001add <__abi_tag+0x17e1>
 100cc52:	jmp    100cc9a <describe+0x11a>
 100cc54:	lea    -0xafc8(%rip),%rax        # 1001c93 <__abi_tag+0x1997>
 100cc5b:	jmp    100cc9a <describe+0x11a>
 100cc5d:	lea    -0xb282(%rip),%rax        # 10019e2 <__abi_tag+0x16e6>
 100cc64:	jmp    100cc9a <describe+0x11a>
 100cc66:	lea    -0xb25c(%rip),%rax        # 1001a11 <__abi_tag+0x1715>
 100cc6d:	jmp    100cc9a <describe+0x11a>
 100cc6f:	lea    -0xae88(%rip),%rax        # 1001dee <__abi_tag+0x1af2>
 100cc76:	jmp    100cc9a <describe+0x11a>
 100cc78:	lea    -0xb160(%rip),%rax        # 1001b1f <__abi_tag+0x1823>
 100cc7f:	jmp    100cc9a <describe+0x11a>
 100cc81:	lea    -0xb180(%rip),%rax        # 1001b08 <__abi_tag+0x180c>
 100cc88:	jmp    100cc9a <describe+0x11a>
 100cc8a:	lea    -0xb19c(%rip),%rax        # 1001af5 <__abi_tag+0x17f9>
 100cc91:	jmp    100cc9a <describe+0x11a>
 100cc93:	lea    -0xb224(%rip),%rax        # 1001a76 <__abi_tag+0x177a>
 100cc9a:	add    $0x8,%rsp
 100cc9e:	pop    %rbx
 100cc9f:	pop    %rbp
 100cca0:	ret
 100cca1:	int3
 100cca2:	int3
 100cca3:	int3
 100cca4:	int3
 100cca5:	int3
 100cca6:	int3
 100cca7:	int3
 100cca8:	int3
 100cca9:	int3
 100ccaa:	int3
 100ccab:	int3
 100ccac:	int3
 100ccad:	int3
 100ccae:	int3
 100ccaf:	int3

000000000100ccb0 <trace_frame>:
 100ccb0:	test   %rsi,%rsi
 100ccb3:	je     100cd99 <trace_frame+0xe9>
 100ccb9:	cmp    0x10(%rsi),%rdx
 100ccbd:	jae    100cd99 <trace_frame+0xe9>
 100ccc3:	push   %rbp
 100ccc4:	mov    %rsp,%rbp
 100ccc7:	push   %r15
 100ccc9:	push   %r14
 100cccb:	push   %r12
 100cccd:	push   %rbx
 100ccce:	cmp    $0x1f,%ecx
 100ccd1:	ja     100cd9d <trace_frame+0xed>
 100ccd7:	mov    0x20(%rsi),%r15
 100ccdb:	test   %r15,%r15
 100ccde:	je     100cd9d <trace_frame+0xed>
 100cce4:	mov    0x28(%rsi),%rax
 100cce8:	test   %rax,%rax
 100cceb:	je     100cd9d <trace_frame+0xed>
 100ccf1:	add    $0x20,%r15
 100ccf5:	jmp    100cd0d <trace_frame+0x5d>
 100ccf7:	nopw   0x0(%rax,%rax,1)
 100cd00:	add    $0x28,%r15
 100cd04:	dec    %rax
 100cd07:	je     100cd9d <trace_frame+0xed>
 100cd0d:	mov    -0x18(%r15),%r9
 100cd11:	cmp    %r9,%rdx
 100cd14:	jb     100cd00 <trace_frame+0x50>
 100cd16:	cmp    -0x10(%r15),%rdx
 100cd1a:	jae    100cd00 <trace_frame+0x50>
 100cd1c:	mov    -0x20(%r15),%rax
 100cd20:	test   %rax,%rax
 100cd23:	je     100cd9d <trace_frame+0xed>
 100cd25:	add    -0x8(%r15),%rdx
 100cd29:	sub    %r9,%rdx
 100cd2c:	inc    %ecx
 100cd2e:	mov    %rdi,%rbx
 100cd31:	mov    %rsi,%r12
 100cd34:	mov    %rax,%rsi
 100cd37:	mov    %r8,%r14
 100cd3a:	call   100ccb0 <trace_frame>
 100cd3f:	mov    (%r15),%rdx
 100cd42:	incq   (%r14)
 100cd45:	cmp    0x10(%r12),%rdx
 100cd4a:	jae    100cde7 <trace_frame+0x137>
 100cd50:	mov    0x248(%rbx),%rax
 100cd57:	cmp    $0xf,%rax
 100cd5b:	ja     100cde7 <trace_frame+0x137>
 100cd61:	mov    (%r12),%rsi
 100cd65:	mov    0x8(%r12),%rcx
 100cd6a:	lea    (%rdx,%rdx,2),%rdx
 100cd6e:	mov    (%rcx,%rdx,8),%rdi
 100cd72:	lea    0x1(%rax),%r8
 100cd76:	shl    $0x5,%rax
 100cd7a:	mov    %rsi,0x48(%rbx,%rax,1)
 100cd7f:	mov    %rdi,0x50(%rbx,%rax,1)
 100cd84:	vmovups 0x8(%rcx,%rdx,8),%xmm0
 100cd8a:	mov    %r8,0x248(%rbx)
 100cd91:	vmovups %xmm0,0x58(%rbx,%rax,1)
 100cd97:	jmp    100cde7 <trace_frame+0x137>
 100cd99:	incq   (%r8)
 100cd9c:	ret
 100cd9d:	incq   (%r8)
 100cda0:	cmp    0x10(%rsi),%rdx
 100cda4:	jae    100cde7 <trace_frame+0x137>
 100cda6:	mov    0x248(%rdi),%rax
 100cdad:	cmp    $0xf,%rax
 100cdb1:	ja     100cde7 <trace_frame+0x137>
 100cdb3:	mov    (%rsi),%rcx
 100cdb6:	mov    0x8(%rsi),%rsi
 100cdba:	lea    (%rdx,%rdx,2),%rdx
 100cdbe:	mov    (%rsi,%rdx,8),%r8
 100cdc2:	lea    0x1(%rax),%r9
 100cdc6:	shl    $0x5,%rax
 100cdca:	mov    %rcx,0x48(%rdi,%rax,1)
 100cdcf:	mov    %r8,0x50(%rdi,%rax,1)
 100cdd4:	vmovups 0x8(%rsi,%rdx,8),%xmm0
 100cdda:	mov    %r9,0x248(%rdi)
 100cde1:	vmovups %xmm0,0x58(%rdi,%rax,1)
 100cde7:	pop    %rbx
 100cde8:	pop    %r12
 100cdea:	pop    %r14
 100cdec:	pop    %r15
 100cdee:	pop    %rbp
 100cdef:	ret

000000000100cdf0 <walk_frames>:
 100cdf0:	push   %rbp
 100cdf1:	mov    %rsp,%rbp
 100cdf4:	push   %r15
 100cdf6:	push   %r14
 100cdf8:	push   %r13
 100cdfa:	push   %r12
 100cdfc:	push   %rbx
 100cdfd:	sub    $0x38,%rsp
 100ce01:	mov    %rdx,-0x38(%rbp)
 100ce05:	mov    %rsi,-0x30(%rbp)
 100ce09:	mov    0x39c0(%rdi),%r12
 100ce10:	mov    0x3e68(%rdi),%r13
 100ce17:	test   %r12,%r12
 100ce1a:	setne  %al
 100ce1d:	cmp    %r12,%r13
 100ce20:	seta   %cl
 100ce23:	and    %al,%cl
 100ce25:	cmp    $0x1,%cl
 100ce28:	jne    100cf12 <walk_frames+0x122>
 100ce2e:	lea    -0x8f5d(%rip),%rax        # 1003ed8 <__stop_mylang_frame_map>
 100ce35:	mov    %rax,%rcx
 100ce38:	sub    $0x10037a0,%rcx
 100ce3f:	cmp    $0x9,%rcx
 100ce43:	jb     100cf12 <walk_frames+0x122>
 100ce49:	cmpq   $0x0,0x1c51f(%rip)        # 1029370 <_DYNAMIC+0x1b8>
 100ce51:	je     100cf12 <walk_frames+0x122>
 100ce57:	cmp    $0x10037a0,%rax
 100ce5e:	jbe    100cf12 <walk_frames+0x122>
 100ce64:	mov    %rdi,%r15
 100ce67:	lea    -0x96ce(%rip),%rax        # 10037a0 <__start_mylang_frame_map>
 100ce6e:	testb  $0x20,0x7(%rax)
 100ce72:	jne    100cecc <walk_frames+0xdc>
 100ce74:	mov    %rbp,%rbx
 100ce77:	add    $0xfffffffffffffff0,%r13
 100ce7b:	nopl   0x0(%rax,%rax,1)
 100ce80:	cmp    %r12,%rbx
 100ce83:	jb     100cf12 <walk_frames+0x122>
 100ce89:	cmp    %r13,%rbx
 100ce8c:	ja     100cf12 <walk_frames+0x122>
 100ce92:	mov    %ebx,%eax
 100ce94:	and    $0x7,%eax
 100ce97:	jne    100cf12 <walk_frames+0x122>
 100ce99:	mov    (%rbx),%r14
 100ce9c:	mov    0x8(%rbx),%rsi
 100cea0:	mov    %r15,%rdi
 100cea3:	mov    -0x30(%rbp),%rdx
 100cea7:	mov    -0x38(%rbp),%rcx
 100ceab:	call   100cf90 <visit_return>
 100ceb0:	cmp    %rbx,%r14
 100ceb3:	mov    %rbx,%rcx
 100ceb6:	cmova  %r14,%rcx
 100ceba:	test   %eax,%eax
 100cebc:	cmove  %rbx,%rcx
 100cec0:	je     100cf12 <walk_frames+0x122>
 100cec2:	cmp    %rbx,%r14
 100cec5:	mov    %rcx,%rbx
 100cec8:	ja     100ce80 <walk_frames+0x90>
 100ceca:	jmp    100cf12 <walk_frames+0x122>
 100cecc:	mov    %r15,-0x58(%rbp)
 100ced0:	mov    -0x30(%rbp),%rax
 100ced4:	mov    %rax,-0x50(%rbp)
 100ced8:	mov    -0x38(%rbp),%rax
 100cedc:	mov    %rax,-0x48(%rbp)
 100cee0:	movq   $0x0,-0x40(%rbp)
 100cee8:	cmpq   $0x0,0x1c488(%rip)        # 1029378 <_Unwind_Backtrace>
 100cef0:	sete   %al
 100cef3:	cmpq   $0x0,0x1c485(%rip)        # 1029380 <_Unwind_GetIP>
 100cefb:	sete   %cl
 100cefe:	or     %al,%cl
 100cf00:	jne    100cf12 <walk_frames+0x122>
 100cf02:	lea    0x47(%rip),%rdi        # 100cf50 <unwind_step>
 100cf09:	lea    -0x58(%rbp),%rsi
 100cf0d:	call   101ee80 <_Unwind_Backtrace@plt>
 100cf12:	add    $0x38,%rsp
 100cf16:	pop    %rbx
 100cf17:	pop    %r12
 100cf19:	pop    %r13
 100cf1b:	pop    %r14
 100cf1d:	pop    %r15
 100cf1f:	pop    %rbp
 100cf20:	ret
 100cf21:	int3
 100cf22:	int3
 100cf23:	int3
 100cf24:	int3
 100cf25:	int3
 100cf26:	int3
 100cf27:	int3
 100cf28:	int3
 100cf29:	int3
 100cf2a:	int3
 100cf2b:	int3
 100cf2c:	int3
 100cf2d:	int3
 100cf2e:	int3
 100cf2f:	int3

000000000100cf30 <trace_visit>:
 100cf30:	push   %rbp
 100cf31:	mov    %rsp,%rbp
 100cf34:	mov    %rcx,%r8
 100cf37:	xor    %ecx,%ecx
 100cf39:	call   100ccb0 <trace_frame>
 100cf3e:	mov    $0x1,%eax
 100cf43:	pop    %rbp
 100cf44:	ret
 100cf45:	int3
 100cf46:	int3
 100cf47:	int3
 100cf48:	int3
 100cf49:	int3
 100cf4a:	int3
 100cf4b:	int3
 100cf4c:	int3
 100cf4d:	int3
 100cf4e:	int3
 100cf4f:	int3

000000000100cf50 <unwind_step>:
 100cf50:	push   %rbp
 100cf51:	mov    %rsp,%rbp
 100cf54:	push   %r14
 100cf56:	push   %rbx
 100cf57:	mov    %rsi,%rbx
 100cf5a:	mov    (%rsi),%r14
 100cf5d:	call   101ee90 <_Unwind_GetIP@plt>
 100cf62:	mov    0x8(%rbx),%rdx
 100cf66:	mov    0x10(%rbx),%rcx
 100cf6a:	mov    %r14,%rdi
 100cf6d:	mov    %rax,%rsi
 100cf70:	call   100cf90 <visit_return>
 100cf75:	mov    %eax,%ecx
 100cf77:	xor    %eax,%eax
 100cf79:	test   %ecx,%ecx
 100cf7b:	jne    100cf89 <unwind_step+0x39>
 100cf7d:	movl   $0x1,0x18(%rbx)
 100cf84:	mov    $0x5,%eax
 100cf89:	pop    %rbx
 100cf8a:	pop    %r14
 100cf8c:	pop    %rbp
 100cf8d:	ret
 100cf8e:	int3
 100cf8f:	int3

000000000100cf90 <visit_return>:
 100cf90:	push   %rbp
 100cf91:	mov    %rsp,%rbp
 100cf94:	push   %r15
 100cf96:	push   %r14
 100cf98:	push   %r13
 100cf9a:	push   %r12
 100cf9c:	push   %rbx
 100cf9d:	sub    $0x18,%rsp
 100cfa1:	mov    %rcx,-0x38(%rbp)
 100cfa5:	mov    %rdx,%r14
 100cfa8:	mov    %rdi,%r15
 100cfab:	cmpb   $0x0,0x1d60e(%rip)        # 102a5c0 <frame_sites_ready>
 100cfb2:	jne    100d06f <visit_return+0xdf>
 100cfb8:	movb   $0x1,0x1d601(%rip)        # 102a5c0 <frame_sites_ready>
 100cfbf:	lea    -0x9826(%rip),%r13        # 10037a0 <__start_mylang_frame_map>
 100cfc6:	test   %r13,%r13
 100cfc9:	sete   %al
 100cfcc:	lea    -0x90fb(%rip),%r12        # 1003ed8 <__stop_mylang_frame_map>
 100cfd3:	cmp    %r13,%r12
 100cfd6:	setbe  %cl
 100cfd9:	or     %al,%cl
 100cfdb:	jne    100d06f <visit_return+0xdf>
 100cfe1:	sub    $0x10037a0,%r12
 100cfe8:	sar    $0x2,%r12
 100cfec:	movabs $0xaaaaaaaaaaaaaaab,%rax
 100cff6:	mov    %r12,%rdx
 100cff9:	mulx   %rax,%rbx,%rbx
 100cffe:	shr    $1,%rbx
 100d001:	movabs $0xf555555555555555,%rax
 100d00b:	lea    (%rbx,%rax,1),%rcx
 100d00f:	inc    %rax
 100d012:	cmp    %rax,%rcx
 100d015:	jb     100d06f <visit_return+0xdf>
 100d017:	lea    0x0(,%rbx,8),%rax
 100d01f:	lea    (%rax,%rax,2),%rdi
 100d023:	mov    %rsi,-0x30(%rbp)
 100d027:	call   101ee60 <malloc@plt>
 100d02c:	mov    -0x30(%rbp),%rsi
 100d030:	mov    %rax,0x1d579(%rip)        # 102a5b0 <frame_sites>
 100d037:	test   %rax,%rax
 100d03a:	je     100d14b <visit_return+0x1bb>
 100d040:	cmp    $0x3,%r12
 100d044:	jae    100d217 <visit_return+0x287>
 100d04a:	xor    %r12d,%r12d
 100d04d:	lea    0x25c(%rip),%rcx        # 100d2b0 <site_order>
 100d054:	mov    $0x18,%edx
 100d059:	mov    %rax,%rdi
 100d05c:	mov    %r12,%rsi
 100d05f:	call   101eea0 <qsort@plt>
 100d064:	mov    %r12,0x1d54d(%rip)        # 102a5b8 <frame_site_count>
 100d06b:	mov    -0x30(%rbp),%rsi
 100d06f:	mov    0x1d53a(%rip),%rcx        # 102a5b0 <frame_sites>
 100d076:	test   %rcx,%rcx
 100d079:	je     100d14b <visit_return+0x1bb>
 100d07f:	mov    0x1d532(%rip),%rdx        # 102a5b8 <frame_site_count>
 100d086:	xor    %edi,%edi
 100d088:	test   %rdx,%rdx
 100d08b:	je     100d0ca <visit_return+0x13a>
 100d08d:	mov    %rdx,%rax
 100d090:	jmp    100d0a8 <visit_return+0x118>
 100d092:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100d0a0:	mov    %r9,%rax
 100d0a3:	cmp    %rax,%rdi
 100d0a6:	jae    100d0ca <visit_return+0x13a>
 100d0a8:	mov    %rax,%r8
 100d0ab:	sub    %rdi,%r8
 100d0ae:	shr    $1,%r8
 100d0b1:	lea    (%r8,%rdi,1),%r9
 100d0b5:	lea    (%r9,%r9,2),%r10
 100d0b9:	cmp    %rsi,(%rcx,%r10,8)
 100d0bd:	jae    100d0a0 <visit_return+0x110>
 100d0bf:	add    %r8,%rdi
 100d0c2:	inc    %rdi
 100d0c5:	cmp    %rax,%rdi
 100d0c8:	jb     100d0a8 <visit_return+0x118>
 100d0ca:	mov    $0x1,%eax
 100d0cf:	cmp    %rdx,%rdi
 100d0d2:	jae    100d208 <visit_return+0x278>
 100d0d8:	lea    (%rdi,%rdi,2),%rdx
 100d0dc:	cmp    %rsi,(%rcx,%rdx,8)
 100d0e0:	jne    100d208 <visit_return+0x278>
 100d0e6:	lea    (%rcx,%rdx,8),%rcx
 100d0ea:	mov    0x10(%rcx),%r12
 100d0ee:	test   %r12,%r12
 100d0f1:	je     100d208 <visit_return+0x278>
 100d0f7:	mov    0x8(%rcx),%r13
 100d0fb:	add    $0x8,%r13
 100d0ff:	mov    %r13,%rbx
 100d102:	jmp    100d121 <visit_return+0x191>
 100d104:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100d110:	add    $0xc,%r13
 100d114:	add    $0xc,%rbx
 100d118:	dec    %r12
 100d11b:	je     100d203 <visit_return+0x273>
 100d121:	mov    -0x4(%r13),%edx
 100d125:	test   %edx,%edx
 100d127:	js     100d110 <visit_return+0x180>
 100d129:	movslq 0x0(%r13),%rsi
 100d12d:	add    %rbx,%rsi
 100d130:	and    $0x1fffffff,%edx
 100d136:	mov    %r15,%rdi
 100d139:	mov    -0x38(%rbp),%rcx
 100d13d:	call   *%r14
 100d140:	test   %eax,%eax
 100d142:	jne    100d110 <visit_return+0x180>
 100d144:	xor    %eax,%eax
 100d146:	jmp    100d208 <visit_return+0x278>
 100d14b:	lea    -0x99b2(%rip),%rcx        # 10037a0 <__start_mylang_frame_map>
 100d152:	test   %rcx,%rcx
 100d155:	sete   %al
 100d158:	lea    -0x9287(%rip),%rdx        # 1003ed8 <__stop_mylang_frame_map>
 100d15f:	cmp    %rcx,%rdx
 100d162:	setbe  %dil
 100d166:	or     %al,%dil
 100d169:	mov    $0x1,%eax
 100d16e:	jne    100d208 <visit_return+0x278>
 100d174:	sub    $0x10037a0,%rdx
 100d17b:	sar    $0x2,%rdx
 100d17f:	movabs $0xaaaaaaaaaaaaaaab,%rdi
 100d189:	mulx   %rdi,%rdi,%rdi
 100d18e:	cmp    $0x3,%rdx
 100d192:	jb     100d208 <visit_return+0x278>
 100d194:	shr    $1,%rdi
 100d197:	lea    -0x1(%rdi),%rdx
 100d19b:	xor    %r8d,%r8d
 100d19e:	xchg   %ax,%ax
 100d1a0:	lea    0x0(,%r8,4),%r9
 100d1a8:	lea    (%r9,%r9,2),%r13
 100d1ac:	mov    $0x1,%r12d
 100d1b2:	cmp    %rdx,%r8
 100d1b5:	jae    100d1e6 <visit_return+0x256>
 100d1b7:	mov    %rdi,%r9
 100d1ba:	sub    %r8,%r9
 100d1bd:	lea    (%rcx,%r13,1),%r10
 100d1c1:	add    $0x10,%r10
 100d1c5:	data16 cs nopw 0x0(%rax,%rax,1)
 100d1d0:	testb  $0x40,0x3(%r10)
 100d1d5:	je     100d1e6 <visit_return+0x256>
 100d1d7:	inc    %r12
 100d1da:	add    $0xc,%r10
 100d1de:	cmp    %r12,%r9
 100d1e1:	jne    100d1d0 <visit_return+0x240>
 100d1e3:	mov    %r9,%r12
 100d1e6:	add    %rcx,%r13
 100d1e9:	movslq 0x0(%r13),%r9
 100d1ed:	add    %r13,%r9
 100d1f0:	cmp    %rsi,%r9
 100d1f3:	je     100d0fb <visit_return+0x16b>
 100d1f9:	add    %r12,%r8
 100d1fc:	cmp    %rdi,%r8
 100d1ff:	jb     100d1a0 <visit_return+0x210>
 100d201:	jmp    100d208 <visit_return+0x278>
 100d203:	mov    $0x1,%eax
 100d208:	add    $0x18,%rsp
 100d20c:	pop    %rbx
 100d20d:	pop    %r12
 100d20f:	pop    %r13
 100d211:	pop    %r14
 100d213:	pop    %r15
 100d215:	pop    %rbp
 100d216:	ret
 100d217:	lea    -0x1(%rbx),%rcx
 100d21b:	xor    %r12d,%r12d
 100d21e:	xor    %edx,%edx
 100d220:	jmp    100d25e <visit_return+0x2ce>
 100d222:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100d230:	mov    %r8,%rdi
 100d233:	lea    (%r12,%r12,2),%r8
 100d237:	lea    (%rax,%r8,8),%r8
 100d23b:	add    %r13,%rsi
 100d23e:	movslq (%rsi),%r9
 100d241:	add    %rsi,%r9
 100d244:	mov    %r9,(%r8)
 100d247:	mov    %rsi,0x8(%r8)
 100d24b:	mov    %rdi,0x10(%r8)
 100d24f:	add    %rdi,%rdx
 100d252:	inc    %r12
 100d255:	cmp    %rbx,%rdx
 100d258:	jae    100d04d <visit_return+0xbd>
 100d25e:	lea    0x0(,%rdx,4),%rsi
 100d266:	lea    (%rsi,%rsi,2),%rsi
 100d26a:	mov    $0x1,%edi
 100d26f:	cmp    %rcx,%rdx
 100d272:	jae    100d233 <visit_return+0x2a3>
 100d274:	mov    %rbx,%r8
 100d277:	sub    %rdx,%r8
 100d27a:	lea    (%rsi,%r13,1),%r9
 100d27e:	add    $0x10,%r9
 100d282:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100d290:	testb  $0x40,0x3(%r9)
 100d295:	je     100d233 <visit_return+0x2a3>
 100d297:	inc    %rdi
 100d29a:	add    $0xc,%r9
 100d29e:	cmp    %rdi,%r8
 100d2a1:	jne    100d290 <visit_return+0x300>
 100d2a3:	jmp    100d230 <visit_return+0x2a0>
 100d2a5:	int3
 100d2a6:	int3
 100d2a7:	int3
 100d2a8:	int3
 100d2a9:	int3
 100d2aa:	int3
 100d2ab:	int3
 100d2ac:	int3
 100d2ad:	int3
 100d2ae:	int3
 100d2af:	int3

000000000100d2b0 <site_order>:
 100d2b0:	mov    (%rdi),%rax
 100d2b3:	cmp    (%rsi),%rax
 100d2b6:	seta   %al
 100d2b9:	sbb    $0x0,%al
 100d2bb:	movsbl %al,%eax
 100d2be:	ret
 100d2bf:	int3

000000000100d2c0 <on_timeout>:
 100d2c0:	push   %rbp
 100d2c1:	mov    %rsp,%rbp
 100d2c4:	lea    -0xa41b(%rip),%rsi        # 1002eb0 <on_timeout.message>
 100d2cb:	mov    $0x48,%edx
 100d2d0:	mov    $0x2,%edi
 100d2d5:	call   101eeb0 <write@plt>
 100d2da:	mov    $0x1,%edi
 100d2df:	call   101eec0 <_exit@plt>
 100d2e4:	int3
 100d2e5:	int3
 100d2e6:	int3
 100d2e7:	int3
 100d2e8:	int3
 100d2e9:	int3
 100d2ea:	int3
 100d2eb:	int3
 100d2ec:	int3
 100d2ed:	int3
 100d2ee:	int3
 100d2ef:	int3

000000000100d2f0 <myl_qbe_on_stack>:
 100d2f0:	push   %rbp
 100d2f1:	mov    %rsp,%rbp
 100d2f4:	push   %r15
 100d2f6:	push   %r14
 100d2f8:	push   %r13
 100d2fa:	push   %r12
 100d2fc:	push   %rbx
 100d2fd:	sub    $0x878,%rsp
 100d304:	mov    %rsi,%rbx
 100d307:	mov    %rdi,%r12
 100d30a:	mov    $0x1e,%edi
 100d30f:	call   101eed0 <sysconf@plt>
 100d314:	test   %rax,%rax
 100d317:	jle    100d3af <myl_qbe_on_stack+0xbf>
 100d31d:	mov    %rax,%rcx
 100d320:	shr    $0x3e,%rcx
 100d324:	jne    100d341 <myl_qbe_on_stack+0x51>
 100d326:	lea    (%rax,%rax,1),%r14
 100d32a:	mov    0x18(%rbx),%rcx
 100d32e:	mov    $0xffffffffff7ffffe,%rdx
 100d335:	sub    %r14,%rdx
 100d338:	shr    $0xf,%rdx
 100d33c:	cmp    %rdx,%rcx
 100d33f:	jbe    100d352 <myl_qbe_on_stack+0x62>
 100d341:	mov    $0xffffffffffffffff,%rsi
 100d348:	mov    %rbx,%rdi
 100d34b:	call   100d560 <stack_refused>
 100d350:	jmp    100d3be <myl_qbe_on_stack+0xce>
 100d352:	shl    $0xf,%rcx
 100d356:	mov    %rcx,%rdx
 100d359:	add    $0x800000,%rdx
 100d360:	mov    %rax,%rcx
 100d363:	neg    %rcx
 100d366:	cmp    %rcx,%rdx
 100d369:	ja     100d3af <myl_qbe_on_stack+0xbf>
 100d36b:	mov    %r14,%rcx
 100d36e:	not    %rcx
 100d371:	lea    (%rdx,%rax,1),%r13
 100d375:	dec    %r13
 100d378:	mov    %r13,%rdx
 100d37b:	or     %rax,%rdx
 100d37e:	shr    $0x20,%rdx
 100d382:	je     100d399 <myl_qbe_on_stack+0xa9>
 100d384:	mov    %rax,%rsi
 100d387:	mov    %rax,%r15
 100d38a:	xor    %eax,%eax
 100d38c:	mov    %eax,%edx
 100d38e:	mov    %r13,%rax
 100d391:	div    %rsi
 100d394:	mov    %rdx,%rax
 100d397:	jmp    100d3a7 <myl_qbe_on_stack+0xb7>
 100d399:	mov    %rax,%r15
 100d39c:	mov    %eax,%esi
 100d39e:	mov    %r13d,%eax
 100d3a1:	xor    %edx,%edx
 100d3a3:	div    %esi
 100d3a5:	mov    %edx,%eax
 100d3a7:	sub    %rax,%r13
 100d3aa:	cmp    %rcx,%r13
 100d3ad:	jbe    100d3d2 <myl_qbe_on_stack+0xe2>
 100d3af:	lea    -0xbcc4(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100d3b6:	mov    %rbx,%rdi
 100d3b9:	call   100b4d5 <fail>
 100d3be:	xor    %eax,%eax
 100d3c0:	add    $0x878,%rsp
 100d3c7:	pop    %rbx
 100d3c8:	pop    %r12
 100d3ca:	pop    %r13
 100d3cc:	pop    %r14
 100d3ce:	pop    %r15
 100d3d0:	pop    %rbp
 100d3d1:	ret
 100d3d2:	add    %r13,%r14
 100d3d5:	xor    %eax,%eax
 100d3d7:	mov    %eax,%edi
 100d3d9:	mov    %r14,%rsi
 100d3dc:	xor    %edx,%edx
 100d3de:	mov    $0x20022,%ecx
 100d3e3:	mov    $0xffffffff,%r8d
 100d3e9:	mov    %rdi,%r9
 100d3ec:	call   101eee0 <mmap@plt>
 100d3f1:	cmp    $0xffffffffffffffff,%rax
 100d3f5:	je     100d548 <myl_qbe_on_stack+0x258>
 100d3fb:	mov    %rax,-0x30(%rbp)
 100d3ff:	add    %rax,%r15
 100d402:	vxorps %xmm0,%xmm0,%xmm0
 100d406:	vmovups %ymm0,-0x50(%rbp)
 100d40b:	vmovups %ymm0,-0x60(%rbp)
 100d410:	vmovups %ymm0,-0x80(%rbp)
 100d415:	vmovups %ymm0,-0xa0(%rbp)
 100d41d:	vmovups %ymm0,-0xc0(%rbp)
 100d425:	vmovups %ymm0,-0xe0(%rbp)
 100d42d:	vmovups %ymm0,-0x100(%rbp)
 100d435:	mov    %r12,-0x110(%rbp)
 100d43c:	mov    %rbx,-0x108(%rbp)
 100d443:	mov    %r15,%rdi
 100d446:	mov    %r13,%rsi
 100d449:	mov    $0x3,%edx
 100d44e:	vzeroupper
 100d451:	call   101eef0 <mprotect@plt>
 100d456:	test   %eax,%eax
 100d458:	jne    100d502 <myl_qbe_on_stack+0x212>
 100d45e:	lea    -0x4d8(%rbp),%rdi
 100d465:	call   101ef00 <getcontext@plt>
 100d46a:	test   %eax,%eax
 100d46c:	jne    100d502 <myl_qbe_on_stack+0x212>
 100d472:	lea    -0x800000(%r13),%rax
 100d479:	mov    %rax,0x39b8(%rbx)
 100d480:	mov    %r15,0x39c0(%rbx)
 100d487:	lea    (%r15,%r13,1),%rax
 100d48b:	mov    %rax,0x3e68(%rbx)
 100d492:	lea    0x10000(%r15),%rax
 100d499:	mov    %rax,0x40(%rbx)
 100d49d:	mov    %r15,-0x4c8(%rbp)
 100d4a4:	mov    %r13,-0x4b8(%rbp)
 100d4ab:	movl   $0x0,-0x4c0(%rbp)
 100d4b5:	lea    -0x8a0(%rbp),%r15
 100d4bc:	mov    %r15,-0x4d0(%rbp)
 100d4c3:	lea    -0x110(%rbp),%rax
 100d4ca:	mov    %rax,%rdx
 100d4cd:	mov    %eax,%ecx
 100d4cf:	shr    $0x20,%rdx
 100d4d3:	mov    %edx,%r8d
 100d4d6:	lea    0x1f3(%rip),%rsi        # 100d6d0 <launch>
 100d4dd:	xor    %eax,%eax
 100d4df:	lea    -0x4d8(%rbp),%r12
 100d4e6:	mov    %r12,%rdi
 100d4e9:	mov    $0x2,%edx
 100d4ee:	call   101ef10 <makecontext@plt>
 100d4f3:	mov    %r15,%rdi
 100d4f6:	mov    %r12,%rsi
 100d4f9:	call   101ef20 <swapcontext@plt>
 100d4fe:	test   %eax,%eax
 100d500:	je     100d553 <myl_qbe_on_stack+0x263>
 100d502:	lea    -0xbe17(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100d509:	mov    %rbx,%rdi
 100d50c:	call   100b4d5 <fail>
 100d511:	xor    %eax,%eax
 100d513:	mov    %rax,%r15
 100d516:	movq   $0x0,0x39c0(%rbx)
 100d521:	movq   $0x0,0x3e68(%rbx)
 100d52c:	movq   $0x0,0x40(%rbx)
 100d534:	mov    -0x30(%rbp),%rdi
 100d538:	mov    %r14,%rsi
 100d53b:	call   101ef30 <munmap@plt>
 100d540:	mov    %r15,%rax
 100d543:	jmp    100d3c0 <myl_qbe_on_stack+0xd0>
 100d548:	mov    %rbx,%rdi
 100d54b:	mov    %r14,%rsi
 100d54e:	jmp    100d34b <myl_qbe_on_stack+0x5b>
 100d553:	mov    -0x100(%rbp),%rax
 100d55a:	jmp    100d513 <myl_qbe_on_stack+0x223>
 100d55c:	int3
 100d55d:	int3
 100d55e:	int3
 100d55f:	int3

000000000100d560 <stack_refused>:
 100d560:	push   %rbp
 100d561:	mov    %rsp,%rbp
 100d564:	push   %r14
 100d566:	push   %rbx
 100d567:	sub    $0x80,%rsp
 100d56e:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 100d573:	je     100d590 <stack_refused+0x30>
 100d575:	mov    %rsi,%rbx
 100d578:	lea    -0x20(%rbp),%rsi
 100d57c:	mov    %rdi,%r14
 100d57f:	mov    $0x9,%edi
 100d584:	call   101ef40 <getrlimit@plt>
 100d589:	mov    %r14,%rdi
 100d58c:	test   %eax,%eax
 100d58e:	je     100d5a8 <stack_refused+0x48>
 100d590:	lea    -0xbea5(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100d597:	call   100b4d5 <fail>
 100d59c:	add    $0x80,%rsp
 100d5a3:	pop    %rbx
 100d5a4:	pop    %r14
 100d5a6:	pop    %rbp
 100d5a7:	ret
 100d5a8:	cmp    $0xffffffffffffffff,%rbx
 100d5ac:	jne    100d5cb <stack_refused+0x6b>
 100d5ae:	vmovupd -0xba81(%rip),%ymm0        # 1001b35 <__abi_tag+0x1839>
 100d5b6:	vmovupd %ymm0,-0x50(%rbp)
 100d5bb:	movabs $0x64657373657264,%rax
 100d5c5:	mov    %rax,-0x30(%rbp)
 100d5c9:	jmp    100d608 <stack_refused+0xa8>
 100d5cb:	vmovq  %rbx,%xmm0
 100d5d0:	vpunpckldq -0xa798(%rip),%xmm0,%xmm0        # 1002e40 <qbe_empty_registry+0x98>
 100d5d8:	vsubpd -0xa7b0(%rip),%xmm0,%xmm0        # 1002e30 <qbe_empty_registry+0x88>
 100d5e0:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 100d5e5:	vaddsd %xmm0,%xmm1,%xmm0
 100d5e9:	vmulsd -0xa7c9(%rip),%xmm0,%xmm0        # 1002e28 <qbe_empty_registry+0x80>
 100d5f1:	lea    -0xbcc2(%rip),%rdx        # 1001936 <__abi_tag+0x163a>
 100d5f8:	lea    -0x50(%rbp),%rdi
 100d5fc:	mov    $0x30,%esi
 100d601:	mov    $0x1,%al
 100d603:	call   101ee50 <snprintf@plt>
 100d608:	mov    -0x20(%rbp),%rax
 100d60c:	cmp    $0xffffffffffffffff,%rax
 100d610:	jne    100d634 <stack_refused+0xd4>
 100d612:	vmovups -0xbbd3(%rip),%xmm0        # 1001a47 <__abi_tag+0x174b>
 100d61a:	vmovups %xmm0,-0x81(%rbp)
 100d622:	vmovupd -0xbbf2(%rip),%xmm0        # 1001a38 <__abi_tag+0x173c>
 100d62a:	vmovapd %xmm0,-0x90(%rbp)
 100d632:	jmp    100d677 <stack_refused+0x117>
 100d634:	vmovq  %rax,%xmm0
 100d639:	vpunpckldq -0xa801(%rip),%xmm0,%xmm0        # 1002e40 <qbe_empty_registry+0x98>
 100d641:	vsubpd -0xa819(%rip),%xmm0,%xmm0        # 1002e30 <qbe_empty_registry+0x88>
 100d649:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 100d64e:	vaddsd %xmm0,%xmm1,%xmm0
 100d652:	vmulsd -0xa832(%rip),%xmm0,%xmm0        # 1002e28 <qbe_empty_registry+0x80>
 100d65a:	lea    -0xb929(%rip),%rdx        # 1001d38 <__abi_tag+0x1a3c>
 100d661:	lea    -0x90(%rbp),%rdi
 100d668:	mov    $0x40,%esi
 100d66d:	mov    $0x1,%al
 100d66f:	vzeroupper
 100d672:	call   101ee50 <snprintf@plt>
 100d677:	mov    0x1bcea(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100d67e:	mov    (%rax),%rdi
 100d681:	mov    0x18(%r14),%rdx
 100d685:	lea    -0xb7b2(%rip),%rsi        # 1001eda <__abi_tag+0x1bde>
 100d68c:	lea    -0x50(%rbp),%rcx
 100d690:	lea    -0x90(%rbp),%r9
 100d697:	mov    $0x20,%r8d
 100d69d:	xor    %eax,%eax
 100d69f:	vzeroupper
 100d6a2:	call   101eda0 <fprintf@plt>
 100d6a7:	movl   $0x1,0x39e0(%r14)
 100d6b2:	lea    -0xbfc7(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100d6b9:	mov    %r14,%rdi
 100d6bc:	jmp    100d597 <stack_refused+0x37>
 100d6c1:	int3
 100d6c2:	int3
 100d6c3:	int3
 100d6c4:	int3
 100d6c5:	int3
 100d6c6:	int3
 100d6c7:	int3
 100d6c8:	int3
 100d6c9:	int3
 100d6ca:	int3
 100d6cb:	int3
 100d6cc:	int3
 100d6cd:	int3
 100d6ce:	int3
 100d6cf:	int3

000000000100d6d0 <launch>:
 100d6d0:	push   %rbp
 100d6d1:	mov    %rsp,%rbp
 100d6d4:	sub    $0x10,%rsp
 100d6d8:	mov    %edi,%edi
 100d6da:	mov    %edi,%eax
 100d6dc:	mov    %esi,%ecx
 100d6de:	shl    $0x20,%rcx
 100d6e2:	or     %rax,%rcx
 100d6e5:	mov    %rcx,-0x8(%rbp)
 100d6e9:	mov    -0x8(%rbp),%rdi
 100d6ed:	add    $0x18,%rdi
 100d6f1:	call   101ef50 <_setjmp@plt>
 100d6f6:	mov    -0x8(%rbp),%rcx
 100d6fa:	test   %eax,%eax
 100d6fc:	je     100d702 <launch+0x32>
 100d6fe:	xor    %eax,%eax
 100d700:	jmp    100d727 <launch+0x57>
 100d702:	add    $0x18,%rcx
 100d706:	mov    -0x8(%rbp),%rax
 100d70a:	mov    0x8(%rax),%rax
 100d70e:	mov    %rcx,0x3e60(%rax)
 100d715:	mov    -0x8(%rbp),%rax
 100d719:	mov    -0x8(%rbp),%rcx
 100d71d:	mov    0x8(%rcx),%rdi
 100d721:	call   *(%rax)
 100d723:	mov    -0x8(%rbp),%rcx
 100d727:	mov    %rax,0x10(%rcx)
 100d72b:	mov    -0x8(%rbp),%rax
 100d72f:	mov    0x8(%rax),%rax
 100d733:	movq   $0x0,0x3e60(%rax)
 100d73e:	add    $0x10,%rsp
 100d742:	pop    %rbp
 100d743:	ret
 100d744:	int3
 100d745:	int3
 100d746:	int3
 100d747:	int3
 100d748:	int3
 100d749:	int3
 100d74a:	int3
 100d74b:	int3
 100d74c:	int3
 100d74d:	int3
 100d74e:	int3
 100d74f:	int3

000000000100d750 <myl_qbe_region_mark>:
 100d750:	push   %rbp
 100d751:	mov    %rsp,%rbp
 100d754:	call   100b830 <myl_qbe_heap>
 100d759:	mov    0x70(%rax),%eax
 100d75c:	pop    %rbp
 100d75d:	ret
 100d75e:	int3
 100d75f:	int3

000000000100d760 <myl_qbe_print_byte>:
 100d760:	push   %rbp
 100d761:	mov    %rsp,%rbp
 100d764:	sub    $0x10,%rsp
 100d768:	mov    %sil,-0x1(%rbp)
 100d76c:	lea    -0x1(%rbp),%rsi
 100d770:	mov    $0x1,%edx
 100d775:	call   1016fe0 <myl_print_raw>
 100d77a:	add    $0x10,%rsp
 100d77e:	pop    %rbp
 100d77f:	ret

000000000100d780 <print_finish>:
 100d780:	test   %rsi,%rsi
 100d783:	je     100d7a6 <print_finish+0x26>
 100d785:	push   %rbp
 100d786:	mov    %rsp,%rbp
 100d789:	push   %r15
 100d78b:	push   %r14
 100d78d:	push   %rbx
 100d78e:	push   %rax
 100d78f:	mov    %rsi,%rbx
 100d792:	cmpl   $0x0,0x1c(%rsi)
 100d796:	je     100d7a7 <print_finish+0x27>
 100d798:	lea    -0xbeff(%rip),%rsi        # 10018a0 <__abi_tag+0x15a4>
 100d79f:	call   100b4d5 <fail>
 100d7a4:	jmp    100d7b2 <print_finish+0x32>
 100d7a6:	ret
 100d7a7:	cmpl   $0x0,0x18(%rbx)
 100d7ab:	je     100d7cc <print_finish+0x4c>
 100d7ad:	call   100b590 <myl_qbe_fail_allocation>
 100d7b2:	mov    (%rbx),%rdi
 100d7b5:	call   101edc0 <free@plt>
 100d7ba:	mov    %rbx,%rdi
 100d7bd:	add    $0x8,%rsp
 100d7c1:	pop    %rbx
 100d7c2:	pop    %r14
 100d7c4:	pop    %r15
 100d7c6:	pop    %rbp
 100d7c7:	jmp    101edc0 <free@plt>
 100d7cc:	mov    %rdi,%r14
 100d7cf:	mov    0x8(%rbx),%rax
 100d7d3:	test   %rax,%rax
 100d7d6:	je     100d7f7 <print_finish+0x77>
 100d7d8:	mov    (%rbx),%rdi
 100d7db:	mov    $0x1,%esi
 100d7e0:	mov    %rdx,%r15
 100d7e3:	mov    %rax,%rdx
 100d7e6:	mov    %r15,%rcx
 100d7e9:	call   101ed90 <fwrite@plt>
 100d7ee:	mov    %r15,%rdx
 100d7f1:	cmp    0x8(%rbx),%rax
 100d7f5:	jne    100d803 <print_finish+0x83>
 100d7f7:	mov    %rdx,%rdi
 100d7fa:	call   101ee70 <fflush@plt>
 100d7ff:	test   %eax,%eax
 100d801:	je     100d7b2 <print_finish+0x32>
 100d803:	lea    -0xbc73(%rip),%rsi        # 1001b97 <__abi_tag+0x189b>
 100d80a:	mov    %r14,%rdi
 100d80d:	jmp    100d79f <print_finish+0x1f>
 100d80f:	int3

000000000100d810 <myl_qbe_stream_begin>:
 100d810:	push   %rbp
 100d811:	mov    %rsp,%rbp
 100d814:	push   %rbx
 100d815:	push   %rax
 100d816:	mov    %rdi,%rbx
 100d819:	mov    $0x1,%edi
 100d81e:	mov    $0x20,%esi
 100d823:	call   101ed70 <calloc@plt>
 100d828:	test   %rax,%rax
 100d82b:	jne    100d83b <myl_qbe_stream_begin+0x2b>
 100d82d:	mov    %rbx,%rdi
 100d830:	mov    %rax,%rbx
 100d833:	call   100b590 <myl_qbe_fail_allocation>
 100d838:	mov    %rbx,%rax
 100d83b:	add    $0x8,%rsp
 100d83f:	pop    %rbx
 100d840:	pop    %rbp
 100d841:	ret
 100d842:	int3
 100d843:	int3
 100d844:	int3
 100d845:	int3
 100d846:	int3
 100d847:	int3
 100d848:	int3
 100d849:	int3
 100d84a:	int3
 100d84b:	int3
 100d84c:	int3
 100d84d:	int3
 100d84e:	int3
 100d84f:	int3

000000000100d850 <myl_qbe_stream_finish>:
 100d850:	cmp    $0x2,%rdx
 100d854:	jne    100d865 <myl_qbe_stream_finish+0x15>
 100d856:	mov    0x1bb0b(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100d85d:	mov    (%rax),%rdx
 100d860:	jmp    100d780 <print_finish>
 100d865:	mov    0x1bb1c(%rip),%rax        # 1029388 <stdout@GLIBC_2.2.5>
 100d86c:	mov    (%rax),%rdx
 100d86f:	jmp    100d780 <print_finish>
 100d874:	int3
 100d875:	int3
 100d876:	int3
 100d877:	int3
 100d878:	int3
 100d879:	int3
 100d87a:	int3
 100d87b:	int3
 100d87c:	int3
 100d87d:	int3
 100d87e:	int3
 100d87f:	int3

000000000100d880 <mylang_qbe_run_grants>:
 100d880:	push   %rbp
 100d881:	mov    %rsp,%rbp
 100d884:	push   %r15
 100d886:	push   %r14
 100d888:	push   %r13
 100d88a:	push   %r12
 100d88c:	push   %rbx
 100d88d:	sub    $0x2b28,%rsp
 100d894:	mov    %rcx,%r14
 100d897:	mov    %rdx,-0x60(%rbp)
 100d89b:	mov    %esi,-0x4c(%rbp)
 100d89e:	mov    %rdi,-0x68(%rbp)
 100d8a2:	lea    -0x2b50(%rbp),%rbx
 100d8a9:	xor    %r12d,%r12d
 100d8ac:	mov    $0x29a0,%edx
 100d8b1:	mov    %rbx,%rdi
 100d8b4:	xor    %esi,%esi
 100d8b6:	call   101e4a0 <compiler_rt.fastMemset>
 100d8bb:	mov    %rbx,%rdi
 100d8be:	call   1017a50 <mylang_scoped_init>
 100d8c3:	lea    -0xb6e9(%rip),%rax        # 10021e1 <__abi_tag+0x1ee5>
 100d8ca:	mov    %rax,-0x1c0(%rbp)
 100d8d1:	vpxor  %xmm0,%xmm0,%xmm0
 100d8d5:	vmovdqu %ymm0,-0x198(%rbp)
 100d8dd:	vmovdqu %ymm0,-0x1b0(%rbp)
 100d8e5:	lea    -0xbcb8(%rip),%rdi        # 1001c34 <__abi_tag+0x1938>
 100d8ec:	vzeroupper
 100d8ef:	call   101ef90 <getenv@plt>
 100d8f4:	test   %rax,%rax
 100d8f7:	je     100df5a <mylang_qbe_run_grants+0x6da>
 100d8fd:	mov    %rax,%r15
 100d900:	cmpb   $0x0,(%rax)
 100d903:	je     100dfe5 <mylang_qbe_run_grants+0x765>
 100d909:	mov    %r14,-0x58(%rbp)
 100d90d:	mov    %r15,%rdi
 100d910:	call   101e450 <compiler_rt.strlen>
 100d915:	mov    %rax,%r14
 100d918:	lea    0x1(%rax),%rbx
 100d91c:	mov    %rbx,%rdi
 100d91f:	call   101ee60 <malloc@plt>
 100d924:	mov    %rax,%r12
 100d927:	shr    $1,%r14
 100d92a:	inc    %r14
 100d92d:	mov    $0x8,%esi
 100d932:	mov    %r14,%rdi
 100d935:	call   101ed70 <calloc@plt>
 100d93a:	mov    %rax,%r13
 100d93d:	mov    %r12,-0x40(%rbp)
 100d941:	test   %r12,%r12
 100d944:	je     100e281 <mylang_qbe_run_grants+0xa01>
 100d94a:	test   %r13,%r13
 100d94d:	je     100e281 <mylang_qbe_run_grants+0xa01>
 100d953:	mov    -0x40(%rbp),%r14
 100d957:	mov    %r14,%rdi
 100d95a:	mov    %r15,%rsi
 100d95d:	mov    %rbx,%rdx
 100d960:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 100d965:	movzbl (%r14),%esi
 100d969:	test   %sil,%sil
 100d96c:	je     100df4a <mylang_qbe_run_grants+0x6ca>
 100d972:	xor    %ebx,%ebx
 100d974:	movabs $0x100002600,%rax
 100d97e:	mov    -0x40(%rbp),%rdi
 100d982:	mov    %rdi,%rcx
 100d985:	mov    %rdi,%rdx
 100d988:	cmp    $0x20,%sil
 100d98c:	ja     100d9b9 <mylang_qbe_run_grants+0x139>
 100d98e:	xchg   %ax,%ax
 100d990:	movzbl %sil,%esi
 100d994:	bt     %rsi,%rax
 100d998:	jae    100d9b0 <mylang_qbe_run_grants+0x130>
 100d99a:	movzbl 0x1(%rdx),%esi
 100d99e:	inc    %rdx
 100d9a1:	cmp    $0x20,%sil
 100d9a5:	jbe    100d990 <mylang_qbe_run_grants+0x110>
 100d9a7:	jmp    100d9b9 <mylang_qbe_run_grants+0x139>
 100d9a9:	nopl   0x0(%rax)
 100d9b0:	test   %rsi,%rsi
 100d9b3:	je     100da5f <mylang_qbe_run_grants+0x1df>
 100d9b9:	mov    %rcx,0x0(%r13,%rbx,8)
 100d9be:	movzbl (%rdx),%edi
 100d9c1:	test   %dil,%dil
 100d9c4:	je     100da3c <mylang_qbe_run_grants+0x1bc>
 100d9c6:	xor    %esi,%esi
 100d9c8:	jmp    100d9df <mylang_qbe_run_grants+0x15f>
 100d9ca:	nopw   0x0(%rax,%rax,1)
 100d9d0:	xor    $0x1,%esi
 100d9d3:	movzbl 0x1(%rdx),%edi
 100d9d7:	inc    %rdx
 100d9da:	test   %dil,%dil
 100d9dd:	je     100da34 <mylang_qbe_run_grants+0x1b4>
 100d9df:	test   %esi,%esi
 100d9e1:	je     100da00 <mylang_qbe_run_grants+0x180>
 100d9e3:	cmp    $0x5c,%dil
 100d9e7:	je     100da20 <mylang_qbe_run_grants+0x1a0>
 100d9e9:	movzbl %dil,%r8d
 100d9ed:	cmp    $0x22,%r8d
 100d9f1:	je     100d9d0 <mylang_qbe_run_grants+0x150>
 100d9f3:	jmp    100da2c <mylang_qbe_run_grants+0x1ac>
 100d9f5:	data16 cs nopw 0x0(%rax,%rax,1)
 100da00:	cmp    $0x22,%dil
 100da04:	ja     100da2c <mylang_qbe_run_grants+0x1ac>
 100da06:	movzbl %dil,%r8d
 100da0a:	cmp    $0x22,%r8
 100da0e:	je     100d9d0 <mylang_qbe_run_grants+0x150>
 100da10:	bt     %r8,%rax
 100da14:	jae    100da2c <mylang_qbe_run_grants+0x1ac>
 100da16:	jmp    100da40 <mylang_qbe_run_grants+0x1c0>
 100da18:	nopl   0x0(%rax,%rax,1)
 100da20:	cmpb   $0x0,0x1(%rdx)
 100da24:	je     100da29 <mylang_qbe_run_grants+0x1a9>
 100da26:	inc    %rdx
 100da29:	movzbl (%rdx),%edi
 100da2c:	mov    %dil,(%rcx)
 100da2f:	inc    %rcx
 100da32:	jmp    100d9d3 <mylang_qbe_run_grants+0x153>
 100da34:	test   %esi,%esi
 100da36:	jne    100e365 <mylang_qbe_run_grants+0xae5>
 100da3c:	xor    %esi,%esi
 100da3e:	jmp    100da45 <mylang_qbe_run_grants+0x1c5>
 100da40:	mov    $0x1,%esi
 100da45:	inc    %rbx
 100da48:	lea    (%rdx,%rsi,1),%rdi
 100da4c:	movb   $0x0,(%rcx)
 100da4f:	inc    %rcx
 100da52:	movzbl (%rdx,%rsi,1),%esi
 100da56:	test   %sil,%sil
 100da59:	jne    100d985 <mylang_qbe_run_grants+0x105>
 100da5f:	test   %ebx,%ebx
 100da61:	js     100e365 <mylang_qbe_run_grants+0xae5>
 100da67:	je     100df4a <mylang_qbe_run_grants+0x6ca>
 100da6d:	and    $0x7fffffff,%ebx
 100da73:	xor    %r14d,%r14d
 100da76:	lea    -0xc204(%rip),%r15        # 1001879 <__abi_tag+0x157d>
 100da7d:	mov    %r13,-0x38(%rbp)
 100da81:	mov    %rbx,-0x30(%rbp)
 100da85:	jmp    100daac <mylang_qbe_run_grants+0x22c>
 100da87:	movl   $0x1,-0x1cc(%rbp)
 100da91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100daa0:	inc    %r14
 100daa3:	cmp    %rbx,%r14
 100daa6:	je     100df4a <mylang_qbe_run_grants+0x6ca>
 100daac:	mov    0x0(%r13,%r14,8),%r12
 100dab1:	mov    %r12,%rdi
 100dab4:	mov    %r15,%rsi
 100dab7:	call   101ede0 <strcmp@plt>
 100dabc:	test   %eax,%eax
 100dabe:	mov    %r12,-0x48(%rbp)
 100dac2:	je     100dbe0 <mylang_qbe_run_grants+0x360>
 100dac8:	mov    $0xd,%edx
 100dacd:	mov    %r12,%rdi
 100dad0:	lea    -0xbd35(%rip),%rsi        # 1001da2 <__abi_tag+0x1aa6>
 100dad7:	call   101edd0 <strncmp@plt>
 100dadc:	test   %eax,%eax
 100dade:	je     100dc00 <mylang_qbe_run_grants+0x380>
 100dae4:	mov    $0xe,%edx
 100dae9:	mov    %r12,%rdi
 100daec:	lea    -0xbd60(%rip),%rsi        # 1001d93 <__abi_tag+0x1a97>
 100daf3:	call   101edd0 <strncmp@plt>
 100daf8:	test   %eax,%eax
 100dafa:	je     100dc65 <mylang_qbe_run_grants+0x3e5>
 100db00:	mov    $0x11,%edx
 100db05:	mov    %r12,%rdi
 100db08:	lea    -0xbda9(%rip),%rsi        # 1001d66 <__abi_tag+0x1a6a>
 100db0f:	call   101edd0 <strncmp@plt>
 100db14:	test   %eax,%eax
 100db16:	je     100dcdb <mylang_qbe_run_grants+0x45b>
 100db1c:	mov    %r12,%rdi
 100db1f:	lea    -0xc1fe(%rip),%rsi        # 1001928 <__abi_tag+0x162c>
 100db26:	call   101ede0 <strcmp@plt>
 100db2b:	test   %eax,%eax
 100db2d:	je     100dd1e <mylang_qbe_run_grants+0x49e>
 100db33:	mov    %r12,%rdi
 100db36:	lea    -0xc318(%rip),%rsi        # 1001825 <__abi_tag+0x1529>
 100db3d:	call   101ede0 <strcmp@plt>
 100db42:	test   %eax,%eax
 100db44:	je     100dd6d <mylang_qbe_run_grants+0x4ed>
 100db4a:	mov    $0xe,%edx
 100db4f:	mov    %r12,%rdi
 100db52:	lea    -0xc25a(%rip),%rsi        # 10018ff <__abi_tag+0x1603>
 100db59:	call   101edd0 <strncmp@plt>
 100db5e:	test   %eax,%eax
 100db60:	je     100ddb5 <mylang_qbe_run_grants+0x535>
 100db66:	mov    $0xb,%edx
 100db6b:	mov    %r12,%rdi
 100db6e:	lea    -0xc3f6(%rip),%rsi        # 100177f <__abi_tag+0x1483>
 100db75:	call   101edd0 <strncmp@plt>
 100db7a:	mov    -0x48(%rbp),%r12
 100db7e:	test   %eax,%eax
 100db80:	je     100ddf1 <mylang_qbe_run_grants+0x571>
 100db86:	mov    %r12,%rdi
 100db89:	lea    -0xc274(%rip),%rsi        # 100191c <__abi_tag+0x1620>
 100db90:	call   101ede0 <strcmp@plt>
 100db95:	test   %eax,%eax
 100db97:	je     100de2d <mylang_qbe_run_grants+0x5ad>
 100db9d:	mov    $0x8,%edx
 100dba2:	mov    %r12,%rdi
 100dba5:	lea    -0xbdd7(%rip),%rsi        # 1001dd5 <__abi_tag+0x1ad9>
 100dbac:	call   101edd0 <strncmp@plt>
 100dbb1:	test   %eax,%eax
 100dbb3:	je     100dd80 <mylang_qbe_run_grants+0x500>
 100dbb9:	mov    $0xa,%edx
 100dbbe:	mov    %r12,%rdi
 100dbc1:	mov    %r15,%rsi
 100dbc4:	call   101edd0 <strncmp@plt>
 100dbc9:	test   %eax,%eax
 100dbcb:	setne  %al
 100dbce:	mov    %eax,%ecx
 100dbd0:	jmp    100dd84 <mylang_qbe_run_grants+0x504>
 100dbd5:	data16 cs nopw 0x0(%rax,%rax,1)
 100dbe0:	cmpl   $0x0,-0x1cc(%rbp)
 100dbe7:	jne    100dd80 <mylang_qbe_run_grants+0x500>
 100dbed:	jmp    100da87 <mylang_qbe_run_grants+0x207>
 100dbf2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100dc00:	cmpb   $0x0,0xd(%r12)
 100dc06:	je     100dd80 <mylang_qbe_run_grants+0x500>
 100dc0c:	lea    0xd(%r12),%rbx
 100dc11:	mov    -0x1e0(%rbp),%r12
 100dc18:	test   %r12,%r12
 100dc1b:	je     100dcf8 <mylang_qbe_run_grants+0x478>
 100dc21:	cmp    $0x8,%r12
 100dc25:	je     100dcc3 <mylang_qbe_run_grants+0x443>
 100dc2b:	lea    -0x258(%rbp),%r15
 100dc32:	mov    %r12,%r13
 100dc35:	jmp    100dc4d <mylang_qbe_run_grants+0x3cd>
 100dc37:	nopw   0x0(%rax,%rax,1)
 100dc40:	add    $0x10,%r15
 100dc44:	dec    %r13
 100dc47:	je     100dcf8 <mylang_qbe_run_grants+0x478>
 100dc4d:	mov    -0x8(%r15),%rdi
 100dc51:	mov    %rbx,%rsi
 100dc54:	call   101ede0 <strcmp@plt>
 100dc59:	test   %eax,%eax
 100dc5b:	jne    100dc40 <mylang_qbe_run_grants+0x3c0>
 100dc5d:	cmpl   $0x0,(%r15)
 100dc61:	jne    100dc40 <mylang_qbe_run_grants+0x3c0>
 100dc63:	jmp    100dcc3 <mylang_qbe_run_grants+0x443>
 100dc65:	cmpb   $0x0,0xe(%r12)
 100dc6b:	je     100dd80 <mylang_qbe_run_grants+0x500>
 100dc71:	lea    0xe(%r12),%rbx
 100dc76:	mov    -0x1e0(%rbp),%r13
 100dc7d:	test   %r13,%r13
 100dc80:	je     100dd36 <mylang_qbe_run_grants+0x4b6>
 100dc86:	cmp    $0x8,%r13
 100dc8a:	je     100dcc3 <mylang_qbe_run_grants+0x443>
 100dc8c:	lea    -0x258(%rbp),%r15
 100dc93:	mov    %r13,%r12
 100dc96:	jmp    100dcad <mylang_qbe_run_grants+0x42d>
 100dc98:	nopl   0x0(%rax,%rax,1)
 100dca0:	add    $0x10,%r15
 100dca4:	dec    %r12
 100dca7:	je     100dd36 <mylang_qbe_run_grants+0x4b6>
 100dcad:	mov    -0x8(%r15),%rdi
 100dcb1:	mov    %rbx,%rsi
 100dcb4:	call   101ede0 <strcmp@plt>
 100dcb9:	test   %eax,%eax
 100dcbb:	jne    100dca0 <mylang_qbe_run_grants+0x420>
 100dcbd:	cmpl   $0x1,(%r15)
 100dcc1:	jne    100dca0 <mylang_qbe_run_grants+0x420>
 100dcc3:	xor    %eax,%eax
 100dcc5:	xor    %ecx,%ecx
 100dcc7:	mov    -0x38(%rbp),%r13
 100dccb:	mov    -0x30(%rbp),%rbx
 100dccf:	lea    -0xc45d(%rip),%r15        # 1001879 <__abi_tag+0x157d>
 100dcd6:	jmp    100dd84 <mylang_qbe_run_grants+0x504>
 100dcdb:	lea    0x11(%r12),%rsi
 100dce0:	lea    -0x2b50(%rbp),%rdi
 100dce7:	call   10172d0 <mylang_scoped_endpoint>
 100dcec:	test   %eax,%eax
 100dcee:	setne  %cl
 100dcf1:	xor    %eax,%eax
 100dcf3:	jmp    100dd84 <mylang_qbe_run_grants+0x504>
 100dcf8:	lea    0x1(%r12),%rax
 100dcfd:	mov    %rax,-0x1e0(%rbp)
 100dd04:	shl    $0x4,%r12
 100dd08:	lea    -0x260(%rbp),%rax
 100dd0f:	mov    %rbx,(%rax,%r12,1)
 100dd13:	movq   $0x0,0x8(%rax,%r12,1)
 100dd1c:	jmp    100dd59 <mylang_qbe_run_grants+0x4d9>
 100dd1e:	cmpl   $0x0,-0x1d8(%rbp)
 100dd25:	jne    100dd80 <mylang_qbe_run_grants+0x500>
 100dd27:	movl   $0x1,-0x1d8(%rbp)
 100dd31:	jmp    100daa0 <mylang_qbe_run_grants+0x220>
 100dd36:	lea    0x1(%r13),%rax
 100dd3a:	mov    %rax,-0x1e0(%rbp)
 100dd41:	shl    $0x4,%r13
 100dd45:	lea    -0x260(%rbp),%rax
 100dd4c:	mov    %rbx,(%rax,%r13,1)
 100dd50:	movq   $0x1,0x8(%rax,%r13,1)
 100dd59:	mov    -0x38(%rbp),%r13
 100dd5d:	mov    -0x30(%rbp),%rbx
 100dd61:	lea    -0xc4ef(%rip),%r15        # 1001879 <__abi_tag+0x157d>
 100dd68:	jmp    100daa0 <mylang_qbe_run_grants+0x220>
 100dd6d:	cmpl   $0x0,-0x1c8(%rbp)
 100dd74:	je     100ded2 <mylang_qbe_run_grants+0x652>
 100dd7a:	nopw   0x0(%rax,%rax,1)
 100dd80:	xor    %eax,%eax
 100dd82:	xor    %ecx,%ecx
 100dd84:	test   %al,%al
 100dd86:	jne    100dd90 <mylang_qbe_run_grants+0x510>
 100dd88:	test   %cl,%cl
 100dd8a:	je     100e387 <mylang_qbe_run_grants+0xb07>
 100dd90:	test   %al,%al
 100dd92:	je     100daa0 <mylang_qbe_run_grants+0x220>
 100dd98:	lea    -0x1b0(%rbp),%rdi
 100dd9f:	mov    -0x48(%rbp),%rsi
 100dda3:	call   100ba70 <myl_qbe_control>
 100dda8:	test   %eax,%eax
 100ddaa:	jne    100daa0 <mylang_qbe_run_grants+0x220>
 100ddb0:	jmp    100e390 <mylang_qbe_run_grants+0xb10>
 100ddb5:	movzbl 0xe(%r12),%eax
 100ddbb:	test   %eax,%eax
 100ddbd:	je     100dee1 <mylang_qbe_run_grants+0x661>
 100ddc3:	cmp    $0x3d,%eax
 100ddc6:	jne    100db66 <mylang_qbe_run_grants+0x2e6>
 100ddcc:	cmpb   $0x0,0xf(%r12)
 100ddd2:	je     100db66 <mylang_qbe_run_grants+0x2e6>
 100ddd8:	cmpl   $0x0,-0x1d4(%rbp)
 100dddf:	jne    100db66 <mylang_qbe_run_grants+0x2e6>
 100dde5:	add    $0xf,%r12
 100dde9:	mov    %r12,%rdi
 100ddec:	jmp    100def5 <mylang_qbe_run_grants+0x675>
 100ddf1:	movzbl 0xb(%r12),%eax
 100ddf7:	test   %eax,%eax
 100ddf9:	je     100df20 <mylang_qbe_run_grants+0x6a0>
 100ddff:	cmp    $0x3d,%eax
 100de02:	jne    100db86 <mylang_qbe_run_grants+0x306>
 100de08:	cmpb   $0x0,0xc(%r12)
 100de0e:	je     100db86 <mylang_qbe_run_grants+0x306>
 100de14:	cmpl   $0x0,-0x1d0(%rbp)
 100de1b:	jne    100db86 <mylang_qbe_run_grants+0x306>
 100de21:	add    $0xc,%r12
 100de25:	mov    %r12,%rax
 100de28:	jmp    100df34 <mylang_qbe_run_grants+0x6b4>
 100de2d:	vmovdqu -0x1d8(%rbp),%xmm0
 100de35:	vpinsrd $0x3,-0x1c8(%rbp),%xmm0,%xmm0
 100de3f:	xor    %eax,%eax
 100de41:	vptest %xmm0,%xmm0
 100de46:	jne    100dd82 <mylang_qbe_run_grants+0x502>
 100de4c:	cmpq   $0x0,-0x1e0(%rbp)
 100de54:	jne    100dd82 <mylang_qbe_run_grants+0x502>
 100de5a:	cmpq   $0x0,-0x268(%rbp)
 100de62:	mov    $0x0,%ecx
 100de67:	jne    100dd84 <mylang_qbe_run_grants+0x504>
 100de6d:	movl   $0x1,-0x1c8(%rbp)
 100de77:	movl   $0x1,-0x1d0(%rbp)
 100de81:	movabs $0x100000001,%rax
 100de8b:	mov    %rax,-0x1d8(%rbp)
 100de92:	lea    -0xbcb8(%rip),%rax        # 10021e1 <__abi_tag+0x1ee5>
 100de99:	mov    %rax,-0x1c0(%rbp)
 100dea0:	lea    -0x2b50(%rbp),%r12
 100dea7:	mov    %r12,%rdi
 100deaa:	lea    -0xc0de(%rip),%rsi        # 1001dd3 <__abi_tag+0x1ad7>
 100deb1:	mov    $0x1,%edx
 100deb6:	call   100e3d0 <directory>
 100debb:	test   %eax,%eax
 100debd:	je     100dd80 <mylang_qbe_run_grants+0x500>
 100dec3:	mov    %r12,%rdi
 100dec6:	lea    -0xc0ef(%rip),%rsi        # 1001dde <__abi_tag+0x1ae2>
 100decd:	jmp    100dce7 <mylang_qbe_run_grants+0x467>
 100ded2:	movl   $0x1,-0x1c8(%rbp)
 100dedc:	jmp    100daa0 <mylang_qbe_run_grants+0x220>
 100dee1:	cmpl   $0x0,-0x1d4(%rbp)
 100dee8:	lea    -0xbd0e(%rip),%rdi        # 10021e1 <__abi_tag+0x1ee5>
 100deef:	jne    100db66 <mylang_qbe_run_grants+0x2e6>
 100def5:	movl   $0x1,-0x1d4(%rbp)
 100deff:	cmpb   $0x0,(%rdi)
 100df02:	je     100daa0 <mylang_qbe_run_grants+0x220>
 100df08:	xor    %esi,%esi
 100df0a:	mov    $0xa,%edx
 100df0f:	call   101efa0 <strtoull@plt>
 100df14:	mov    %rax,-0x1b8(%rbp)
 100df1b:	jmp    100daa0 <mylang_qbe_run_grants+0x220>
 100df20:	cmpl   $0x0,-0x1d0(%rbp)
 100df27:	lea    -0xbd4d(%rip),%rax        # 10021e1 <__abi_tag+0x1ee5>
 100df2e:	jne    100db86 <mylang_qbe_run_grants+0x306>
 100df34:	movl   $0x1,-0x1d0(%rbp)
 100df3e:	mov    %rax,-0x1c0(%rbp)
 100df45:	jmp    100daa0 <mylang_qbe_run_grants+0x220>
 100df4a:	mov    %r13,%rdi
 100df4d:	call   101edc0 <free@plt>
 100df52:	mov    -0x58(%rbp),%r14
 100df56:	mov    -0x40(%rbp),%r12
 100df5a:	test   %r14,%r14
 100df5d:	je     100dff1 <mylang_qbe_run_grants+0x771>
 100df63:	vmovups 0xb8(%r14),%ymm0
 100df6c:	vmovups %ymm0,-0x88(%rbp)
 100df74:	vmovups 0xa0(%r14),%ymm0
 100df7d:	vmovups %ymm0,-0xa0(%rbp)
 100df85:	vmovups 0x80(%r14),%ymm0
 100df8e:	vmovups %ymm0,-0xc0(%rbp)
 100df96:	vmovdqu (%r14),%ymm0
 100df9b:	vmovups 0x20(%r14),%ymm1
 100dfa1:	vmovups 0x40(%r14),%ymm2
 100dfa7:	vmovups 0x60(%r14),%ymm3
 100dfad:	vmovups %ymm3,-0xe0(%rbp)
 100dfb5:	vmovups %ymm2,-0x100(%rbp)
 100dfbd:	vmovups %ymm1,-0x120(%rbp)
 100dfc5:	vmovdqu %ymm0,-0x140(%rbp)
 100dfcd:	cmpl   $0x0,-0x1cc(%rbp)
 100dfd4:	jne    100e036 <mylang_qbe_run_grants+0x7b6>
 100dfd6:	movl   $0x1,0x1c5f0(%rip)        # 102a5d0 <host_authority>
 100dfe0:	jmp    100e302 <mylang_qbe_run_grants+0xa82>
 100dfe5:	xor    %r12d,%r12d
 100dfe8:	test   %r14,%r14
 100dfeb:	jne    100df63 <mylang_qbe_run_grants+0x6e3>
 100dff1:	vpxor  %xmm0,%xmm0,%xmm0
 100dff5:	vmovdqu %ymm0,-0x88(%rbp)
 100dffd:	vmovdqu %ymm0,-0xa0(%rbp)
 100e005:	vmovdqu %ymm0,-0xc0(%rbp)
 100e00d:	vmovdqu %ymm0,-0xe0(%rbp)
 100e015:	vmovdqu %ymm0,-0x100(%rbp)
 100e01d:	vmovdqu %ymm0,-0x120(%rbp)
 100e025:	vmovdqu %ymm0,-0x140(%rbp)
 100e02d:	cmpl   $0x0,-0x1cc(%rbp)
 100e034:	je     100e09c <mylang_qbe_run_grants+0x81c>
 100e036:	xor    %eax,%eax
 100e038:	cmpl   $0x0,-0x1c8(%rbp)
 100e03f:	setne  %al
 100e042:	mov    %eax,0x1c588(%rip)        # 102a5d0 <host_authority>
 100e048:	cmpq   $0x0,-0x1e0(%rbp)
 100e050:	je     100e0bd <mylang_qbe_run_grants+0x83d>
 100e052:	lea    -0x258(%rbp),%r14
 100e059:	xor    %r15d,%r15d
 100e05c:	lea    -0x2b50(%rbp),%rbx
 100e063:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100e070:	mov    -0x8(%r14),%rsi
 100e074:	mov    (%r14),%edx
 100e077:	mov    %rbx,%rdi
 100e07a:	vzeroupper
 100e07d:	call   1017ab0 <mylang_scoped_grant>
 100e082:	test   %eax,%eax
 100e084:	je     100e257 <mylang_qbe_run_grants+0x9d7>
 100e08a:	inc    %r15
 100e08d:	add    $0x10,%r14
 100e091:	cmp    -0x1e0(%rbp),%r15
 100e098:	jb     100e070 <mylang_qbe_run_grants+0x7f0>
 100e09a:	jmp    100e0bd <mylang_qbe_run_grants+0x83d>
 100e09c:	movl   $0x1,0x1c52a(%rip)        # 102a5d0 <host_authority>
 100e0a6:	lea    -0x2b50(%rbp),%rdi
 100e0ad:	vzeroupper
 100e0b0:	call   1017b20 <mylang_scoped_working_directory>
 100e0b5:	test   %eax,%eax
 100e0b7:	je     100e257 <mylang_qbe_run_grants+0x9d7>
 100e0bd:	mov    -0x1cc(%rbp),%ebx
 100e0c3:	lea    -0x110(%rbp),%rdi
 100e0ca:	cmpq   $0x0,-0x2af0(%rbp)
 100e0d2:	je     100e114 <mylang_qbe_run_grants+0x894>
 100e0d4:	mov    $0x7,%edx
 100e0d9:	test   %ebx,%ebx
 100e0db:	je     100e103 <mylang_qbe_run_grants+0x883>
 100e0dd:	mov    -0x1e0(%rbp),%rax
 100e0e4:	test   %rax,%rax
 100e0e7:	je     100e0fe <mylang_qbe_run_grants+0x87e>
 100e0e9:	lea    -0x258(%rbp),%rcx
 100e0f0:	cmpl   $0x0,(%rcx)
 100e0f3:	jne    100e103 <mylang_qbe_run_grants+0x883>
 100e0f5:	add    $0x10,%rcx
 100e0f9:	dec    %rax
 100e0fc:	jne    100e0f0 <mylang_qbe_run_grants+0x870>
 100e0fe:	mov    $0x5,%edx
 100e103:	lea    -0x2b50(%rbp),%rsi
 100e10a:	vzeroupper
 100e10d:	call   1017c80 <mylang_scoped_provider>
 100e112:	jmp    100e121 <mylang_qbe_run_grants+0x8a1>
 100e114:	vpxor  %xmm0,%xmm0,%xmm0
 100e118:	vmovdqu %ymm0,0x18(%rdi)
 100e11d:	vmovdqu %ymm0,(%rdi)
 100e121:	lea    -0xd8(%rbp),%r14
 100e128:	cmpq   $0x0,-0x268(%rbp)
 100e130:	je     100e165 <mylang_qbe_run_grants+0x8e5>
 100e132:	lea    -0x178(%rbp),%rdi
 100e139:	lea    -0x2b50(%rbp),%rsi
 100e140:	mov    $0x7,%edx
 100e145:	vzeroupper
 100e148:	call   1017490 <mylang_scoped_network_provider>
 100e14d:	vmovdqu -0x178(%rbp),%ymm0
 100e155:	vmovups -0x160(%rbp),%ymm1
 100e15d:	vmovups %ymm1,0x18(%r14)
 100e163:	jmp    100e16f <mylang_qbe_run_grants+0x8ef>
 100e165:	vpxor  %xmm0,%xmm0,%xmm0
 100e169:	vmovdqu %ymm0,0x18(%r14)
 100e16f:	vmovdqu %ymm0,(%r14)
 100e174:	test   %ebx,%ebx
 100e176:	je     100e1de <mylang_qbe_run_grants+0x95e>
 100e178:	xor    %eax,%eax
 100e17a:	cmpl   $0x0,-0x1d8(%rbp)
 100e181:	lea    0x2f8(%rip),%rcx        # 100e480 <clock_now>
 100e188:	cmovne %rcx,%rax
 100e18c:	mov    %rax,-0x138(%rbp)
 100e193:	vpxor  %xmm0,%xmm0,%xmm0
 100e197:	vmovdqa %xmm0,-0x130(%rbp)
 100e19f:	cmpl   $0x0,-0x1d4(%rbp)
 100e1a6:	je     100e1c4 <mylang_qbe_run_grants+0x944>
 100e1a8:	lea    -0x1b8(%rbp),%rax
 100e1af:	mov    %rax,-0x130(%rbp)
 100e1b6:	lea    0x333(%rip),%rax        # 100e4f0 <random_u64>
 100e1bd:	mov    %rax,-0x128(%rbp)
 100e1c4:	vmovdqa %xmm0,-0x120(%rbp)
 100e1cc:	cmpl   $0x0,-0x1d0(%rbp)
 100e1d3:	jne    100e2e6 <mylang_qbe_run_grants+0xa66>
 100e1d9:	jmp    100e302 <mylang_qbe_run_grants+0xa82>
 100e1de:	lea    0x29b(%rip),%rax        # 100e480 <clock_now>
 100e1e5:	mov    %rax,-0x138(%rbp)
 100e1ec:	vpxor  %xmm0,%xmm0,%xmm0
 100e1f0:	vmovdqa %xmm0,-0x130(%rbp)
 100e1f8:	cmpl   $0x0,-0x1d4(%rbp)
 100e1ff:	jne    100e2bf <mylang_qbe_run_grants+0xa3f>
 100e205:	xor    %ebx,%ebx
 100e207:	lea    -0x178(%rbp),%rsi
 100e20e:	xor    %edi,%edi
 100e210:	vzeroupper
 100e213:	call   101efb0 <clock_gettime@plt>
 100e218:	test   %eax,%eax
 100e21a:	jne    100e2b8 <mylang_qbe_run_grants+0xa38>
 100e220:	mov    -0x178(%rbp),%rcx
 100e227:	mov    -0x170(%rbp),%rax
 100e22e:	movabs $0x7fffffffffffffff,%rdx
 100e238:	xor    %rax,%rdx
 100e23b:	movabs $0x112e0be826d694b3,%rsi
 100e245:	mulx   %rsi,%rdx,%rdx
 100e24a:	shr    $0x1a,%rdx
 100e24e:	cmp    %rdx,%rcx
 100e251:	jle    100e2ae <mylang_qbe_run_grants+0xa2e>
 100e253:	xor    %ebx,%ebx
 100e255:	jmp    100e2b8 <mylang_qbe_run_grants+0xa38>
 100e257:	mov    0x1b10a(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100e25e:	mov    (%rax),%rcx
 100e261:	lea    -0xc109(%rip),%rdi        # 100215f <__abi_tag+0x1e63>
 100e268:	mov    $0x38,%esi
 100e26d:	mov    $0x1,%edx
 100e272:	call   101ed90 <fwrite@plt>
 100e277:	mov    $0x2,%ebx
 100e27c:	jmp    100e33d <mylang_qbe_run_grants+0xabd>
 100e281:	mov    %r13,%rdi
 100e284:	call   101edc0 <free@plt>
 100e289:	mov    0x1b0d8(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100e290:	mov    (%rax),%rcx
 100e293:	lea    -0xc1ae(%rip),%rdi        # 10020ec <__abi_tag+0x1df0>
 100e29a:	mov    $0x21,%esi
 100e29f:	mov    $0x1,%edx
 100e2a4:	call   101ed90 <fwrite@plt>
 100e2a9:	jmp    100e3b4 <mylang_qbe_run_grants+0xb34>
 100e2ae:	imul   $0x3b9aca00,%rcx,%rbx
 100e2b5:	add    %rax,%rbx
 100e2b8:	mov    %rbx,-0x1b8(%rbp)
 100e2bf:	lea    -0x1b8(%rbp),%rax
 100e2c6:	mov    %rax,-0x130(%rbp)
 100e2cd:	lea    0x21c(%rip),%rax        # 100e4f0 <random_u64>
 100e2d4:	mov    %rax,-0x128(%rbp)
 100e2db:	movq   $0x0,-0x120(%rbp)
 100e2e6:	mov    -0x1c0(%rbp),%rax
 100e2ed:	mov    %rax,-0x120(%rbp)
 100e2f4:	lea    0x245(%rip),%rax        # 100e540 <environment_get>
 100e2fb:	mov    %rax,-0x118(%rbp)
 100e302:	xor    %eax,%eax
 100e304:	mov    -0x4c(%rbp),%ecx
 100e307:	test   %ecx,%ecx
 100e309:	setg   %al
 100e30c:	cmp    $0x2,%ecx
 100e30f:	mov    $0x1,%edx
 100e314:	cmovge %ecx,%edx
 100e317:	dec    %edx
 100e319:	mov    -0x60(%rbp),%rcx
 100e31d:	lea    (%rcx,%rax,8),%rcx
 100e321:	lea    -0x1b0(%rbp),%rsi
 100e328:	lea    -0x140(%rbp),%r8
 100e32f:	mov    -0x68(%rbp),%rdi
 100e333:	vzeroupper
 100e336:	call   100bd20 <mylang_qbe_run_process>
 100e33b:	mov    %eax,%ebx
 100e33d:	lea    -0x2b50(%rbp),%rdi
 100e344:	call   1017b80 <mylang_scoped_close>
 100e349:	mov    %r12,%rdi
 100e34c:	call   101edc0 <free@plt>
 100e351:	mov    %ebx,%eax
 100e353:	add    $0x2b28,%rsp
 100e35a:	pop    %rbx
 100e35b:	pop    %r12
 100e35d:	pop    %r13
 100e35f:	pop    %r14
 100e361:	pop    %r15
 100e363:	pop    %rbp
 100e364:	ret
 100e365:	mov    0x1affc(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100e36c:	mov    (%rax),%rcx
 100e36f:	lea    -0xc2bc(%rip),%rdi        # 10020ba <__abi_tag+0x1dbe>
 100e376:	mov    $0x31,%esi
 100e37b:	mov    $0x1,%edx
 100e380:	call   101ed90 <fwrite@plt>
 100e385:	jmp    100e3ac <mylang_qbe_run_grants+0xb2c>
 100e387:	lea    -0xc4ec(%rip),%rsi        # 1001ea2 <__abi_tag+0x1ba6>
 100e38e:	jmp    100e397 <mylang_qbe_run_grants+0xb17>
 100e390:	lea    -0xc37c(%rip),%rsi        # 100201b <__abi_tag+0x1d1f>
 100e397:	mov    0x1afca(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100e39e:	mov    (%rax),%rdi
 100e3a1:	mov    -0x48(%rbp),%rdx
 100e3a5:	xor    %eax,%eax
 100e3a7:	call   101eda0 <fprintf@plt>
 100e3ac:	mov    %r13,%rdi
 100e3af:	call   101edc0 <free@plt>
 100e3b4:	mov    -0x40(%rbp),%rdi
 100e3b8:	call   101edc0 <free@plt>
 100e3bd:	mov    $0x2,%ebx
 100e3c2:	jmp    100e351 <mylang_qbe_run_grants+0xad1>
 100e3c4:	int3
 100e3c5:	int3
 100e3c6:	int3
 100e3c7:	int3
 100e3c8:	int3
 100e3c9:	int3
 100e3ca:	int3
 100e3cb:	int3
 100e3cc:	int3
 100e3cd:	int3
 100e3ce:	int3
 100e3cf:	int3

000000000100e3d0 <directory>:
 100e3d0:	push   %rbp
 100e3d1:	mov    %rsp,%rbp
 100e3d4:	push   %r15
 100e3d6:	push   %r14
 100e3d8:	push   %r13
 100e3da:	push   %r12
 100e3dc:	push   %rbx
 100e3dd:	push   %rax
 100e3de:	mov    %edx,-0x2c(%rbp)
 100e3e1:	xor    %eax,%eax
 100e3e3:	cmpb   $0x0,(%rsi)
 100e3e6:	je     100e467 <directory+0x97>
 100e3e8:	mov    %rsi,%r12
 100e3eb:	mov    %rdi,%r15
 100e3ee:	mov    0x2970(%rdi),%r14
 100e3f5:	test   %r14,%r14
 100e3f8:	je     100e434 <directory+0x64>
 100e3fa:	cmp    $0x8,%r14
 100e3fe:	je     100e430 <directory+0x60>
 100e400:	lea    0x28f8(%r15),%rbx
 100e407:	mov    %r14,%r13
 100e40a:	jmp    100e419 <directory+0x49>
 100e40c:	nopl   0x0(%rax)
 100e410:	add    $0x10,%rbx
 100e414:	dec    %r13
 100e417:	je     100e434 <directory+0x64>
 100e419:	mov    -0x8(%rbx),%rdi
 100e41d:	mov    %r12,%rsi
 100e420:	call   101ede0 <strcmp@plt>
 100e425:	test   %eax,%eax
 100e427:	jne    100e410 <directory+0x40>
 100e429:	mov    -0x2c(%rbp),%eax
 100e42c:	cmp    %eax,(%rbx)
 100e42e:	jne    100e410 <directory+0x40>
 100e430:	xor    %eax,%eax
 100e432:	jmp    100e467 <directory+0x97>
 100e434:	lea    0x1(%r14),%rax
 100e438:	mov    %rax,0x2970(%r15)
 100e43f:	shl    $0x4,%r14
 100e443:	mov    %r12,0x28f0(%r15,%r14,1)
 100e44b:	mov    -0x2c(%rbp),%eax
 100e44e:	mov    %eax,0x28f8(%r15,%r14,1)
 100e456:	movl   $0x0,0x28fc(%r15,%r14,1)
 100e462:	mov    $0x1,%eax
 100e467:	add    $0x8,%rsp
 100e46b:	pop    %rbx
 100e46c:	pop    %r12
 100e46e:	pop    %r13
 100e470:	pop    %r14
 100e472:	pop    %r15
 100e474:	pop    %rbp
 100e475:	ret
 100e476:	int3
 100e477:	int3
 100e478:	int3
 100e479:	int3
 100e47a:	int3
 100e47b:	int3
 100e47c:	int3
 100e47d:	int3
 100e47e:	int3
 100e47f:	int3

000000000100e480 <clock_now>:
 100e480:	push   %rbp
 100e481:	mov    %rsp,%rbp
 100e484:	push   %rbx
 100e485:	sub    $0x18,%rsp
 100e489:	xor    %ebx,%ebx
 100e48b:	lea    -0x18(%rbp),%rsi
 100e48f:	xor    %edi,%edi
 100e491:	call   101efb0 <clock_gettime@plt>
 100e496:	mov    %eax,%ecx
 100e498:	mov    $0x3,%eax
 100e49d:	test   %ecx,%ecx
 100e49f:	jne    100e4dc <clock_now+0x5c>
 100e4a1:	mov    -0x18(%rbp),%rsi
 100e4a5:	mov    -0x10(%rbp),%rcx
 100e4a9:	movabs $0x7fffffffffffffff,%rdx
 100e4b3:	xor    %rcx,%rdx
 100e4b6:	movabs $0x112e0be826d694b3,%rdi
 100e4c0:	mulx   %rdi,%rdx,%rdx
 100e4c5:	shr    $0x1a,%rdx
 100e4c9:	xor    %ebx,%ebx
 100e4cb:	cmp    %rdx,%rsi
 100e4ce:	jg     100e4dc <clock_now+0x5c>
 100e4d0:	imul   $0x3b9aca00,%rsi,%rbx
 100e4d7:	add    %rcx,%rbx
 100e4da:	xor    %eax,%eax
 100e4dc:	mov    %rbx,%rdx
 100e4df:	add    $0x18,%rsp
 100e4e3:	pop    %rbx
 100e4e4:	pop    %rbp
 100e4e5:	ret
 100e4e6:	int3
 100e4e7:	int3
 100e4e8:	int3
 100e4e9:	int3
 100e4ea:	int3
 100e4eb:	int3
 100e4ec:	int3
 100e4ed:	int3
 100e4ee:	int3
 100e4ef:	int3

000000000100e4f0 <random_u64>:
 100e4f0:	movabs $0x9e3779b97f4a7c15,%rax
 100e4fa:	add    (%rdi),%rax
 100e4fd:	mov    %rax,(%rdi)
 100e500:	mov    %rax,%rcx
 100e503:	shr    $0x1e,%rcx
 100e507:	xor    %rax,%rcx
 100e50a:	movabs $0xbf58476d1ce4e5b9,%rax
 100e514:	imul   %rcx,%rax
 100e518:	mov    %rax,%rcx
 100e51b:	shr    $0x1b,%rcx
 100e51f:	xor    %rax,%rcx
 100e522:	movabs $0x94d049bb133111eb,%rax
 100e52c:	imul   %rcx,%rax
 100e530:	mov    %rax,%rdx
 100e533:	shr    $0x1f,%rdx
 100e537:	xor    %rax,%rdx
 100e53a:	xor    %eax,%eax
 100e53c:	ret
 100e53d:	int3
 100e53e:	int3
 100e53f:	int3

000000000100e540 <environment_get>:
 100e540:	push   %rbp
 100e541:	mov    %rsp,%rbp
 100e544:	push   %r15
 100e546:	push   %r14
 100e548:	push   %r13
 100e54a:	push   %r12
 100e54c:	push   %rbx
 100e54d:	sub    $0x118,%rsp
 100e554:	mov    %rdi,%rbx
 100e557:	vxorps %xmm0,%xmm0,%xmm0
 100e55b:	vmovups %xmm0,(%rdi)
 100e55f:	movq   $0x0,0x10(%rdi)
 100e567:	cmp    $0x100,%rcx
 100e56e:	jb     100e58b <environment_get+0x4b>
 100e570:	movl   $0x2,(%rbx)
 100e576:	mov    %rbx,%rax
 100e579:	add    $0x118,%rsp
 100e580:	pop    %rbx
 100e581:	pop    %r12
 100e583:	pop    %r13
 100e585:	pop    %r14
 100e587:	pop    %r15
 100e589:	pop    %rbp
 100e58a:	ret
 100e58b:	mov    %rcx,%r15
 100e58e:	mov    %rsi,%r14
 100e591:	mov    %r9,-0x38(%rbp)
 100e595:	mov    %r8,-0x30(%rbp)
 100e599:	lea    -0x140(%rbp),%rdi
 100e5a0:	mov    %rdx,%rsi
 100e5a3:	mov    %rcx,%rdx
 100e5a6:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 100e5ab:	movb   $0x0,-0x140(%rbp,%r15,1)
 100e5b4:	cmpb   $0x0,(%r14)
 100e5b8:	je     100e63b <environment_get+0xfb>
 100e5be:	lea    -0x140(%rbp),%r13
 100e5c5:	jmp    100e5df <environment_get+0x9f>
 100e5c7:	nopw   0x0(%rax,%rax,1)
 100e5d0:	mov    %r12,%rax
 100e5d3:	inc    %r12
 100e5d6:	cmpb   $0x0,0x1(%rax)
 100e5da:	mov    %r12,%r14
 100e5dd:	je     100e570 <environment_get+0x30>
 100e5df:	mov    %r14,%rdi
 100e5e2:	mov    $0x2c,%esi
 100e5e7:	call   101ef60 <strchr@plt>
 100e5ec:	test   %rax,%rax
 100e5ef:	je     100e610 <environment_get+0xd0>
 100e5f1:	mov    %rax,%r12
 100e5f4:	sub    %r14,%rax
 100e5f7:	cmp    %r15,%rax
 100e5fa:	jne    100e5d0 <environment_get+0x90>
 100e5fc:	mov    %r14,%rdi
 100e5ff:	mov    %r13,%rsi
 100e602:	mov    %r15,%rdx
 100e605:	call   101e470 <bcmp>
 100e60a:	test   %eax,%eax
 100e60c:	jne    100e5d0 <environment_get+0x90>
 100e60e:	jmp    100e63b <environment_get+0xfb>
 100e610:	mov    %r14,%rdi
 100e613:	call   101e450 <compiler_rt.strlen>
 100e618:	cmp    %r15,%rax
 100e61b:	jne    100e570 <environment_get+0x30>
 100e621:	lea    -0x140(%rbp),%rsi
 100e628:	mov    %r14,%rdi
 100e62b:	mov    %r15,%rdx
 100e62e:	call   101e470 <bcmp>
 100e633:	test   %eax,%eax
 100e635:	jne    100e570 <environment_get+0x30>
 100e63b:	lea    -0x140(%rbp),%rdi
 100e642:	call   101ef90 <getenv@plt>
 100e647:	test   %rax,%rax
 100e64a:	je     100e576 <environment_get+0x36>
 100e650:	mov    %rax,%r14
 100e653:	mov    %rax,%rdi
 100e656:	call   101e450 <compiler_rt.strlen>
 100e65b:	cmp    -0x38(%rbp),%rax
 100e65f:	jbe    100e66c <environment_get+0x12c>
 100e661:	movl   $0x5,(%rbx)
 100e667:	jmp    100e576 <environment_get+0x36>
 100e66c:	mov    -0x30(%rbp),%rdi
 100e670:	mov    %r14,%rsi
 100e673:	mov    %rax,%rdx
 100e676:	mov    %rax,%r14
 100e679:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 100e67e:	movl   $0x1,0x10(%rbx)
 100e685:	mov    %r14,0x8(%rbx)
 100e689:	jmp    100e576 <environment_get+0x36>
 100e68e:	int3
 100e68f:	int3

000000000100e690 <release_all>:
 100e690:	push   %rbp
 100e691:	mov    %rsp,%rbp
 100e694:	push   %r15
 100e696:	push   %r14
 100e698:	push   %r13
 100e69a:	push   %r12
 100e69c:	push   %rbx
 100e69d:	sub    $0x18,%rsp
 100e6a1:	mov    0x3e70(%rdi),%r14
 100e6a8:	test   %r14,%r14
 100e6ab:	je     100e810 <release_all+0x180>
 100e6b1:	add    $0x3e70,%rdi
 100e6b8:	mov    %rdi,-0x30(%rbp)
 100e6bc:	cmpq   $0x0,0x8(%r14)
 100e6c1:	je     100e7f4 <release_all+0x164>
 100e6c7:	xor    %ebx,%ebx
 100e6c9:	mov    %r14,-0x38(%rbp)
 100e6cd:	jmp    100e70f <release_all+0x7f>
 100e6cf:	nop
 100e6d0:	mov    (%r12),%rdi
 100e6d4:	vzeroupper
 100e6d7:	call   101edc0 <free@plt>
 100e6dc:	mov    %r12,%rdi
 100e6df:	call   101edc0 <free@plt>
 100e6e4:	mov    -0x38(%rbp),%r14
 100e6e8:	mov    0x50(%r15),%rdi
 100e6ec:	call   101edc0 <free@plt>
 100e6f1:	mov    0x58(%r15),%rdi
 100e6f5:	call   101edc0 <free@plt>
 100e6fa:	mov    %r15,%rdi
 100e6fd:	call   101edc0 <free@plt>
 100e702:	inc    %rbx
 100e705:	cmp    0x8(%r14),%rbx
 100e709:	jae    100e7f4 <release_all+0x164>
 100e70f:	mov    (%r14),%rax
 100e712:	mov    (%rax,%rbx,8),%r15
 100e716:	mov    0x10(%r15),%r12
 100e71a:	test   %r12,%r12
 100e71d:	je     100e6e8 <release_all+0x58>
 100e71f:	mov    $0x30,%r14d
 100e725:	jmp    100e761 <release_all+0xd1>
 100e727:	nopw   0x0(%rax,%rax,1)
 100e730:	lea    (%r12,%r14,1),%r13
 100e734:	add    $0xfffffffffffffff0,%r13
 100e738:	mov    (%r12,%r14,1),%rdi
 100e73c:	vzeroupper
 100e73f:	call   101edc0 <free@plt>
 100e744:	vxorps %xmm0,%xmm0,%xmm0
 100e748:	vmovups %ymm0,0x10(%r13)
 100e74e:	vmovups %ymm0,0x0(%r13)
 100e754:	add    $0x30,%r14
 100e758:	cmp    $0x3030,%r14
 100e75f:	je     100e7b0 <release_all+0x120>
 100e761:	cmpl   $0x0,-0x10(%r12,%r14,1)
 100e767:	je     100e754 <release_all+0xc4>
 100e769:	mov    -0x8(%r12,%r14,1),%r13
 100e76e:	test   %r13,%r13
 100e771:	je     100e730 <release_all+0xa0>
 100e773:	mov    0x30(%r13),%eax
 100e777:	cmpl   $0x0,0x14(%r13)
 100e77c:	setne  %cl
 100e77f:	dec    %eax
 100e781:	mov    %eax,0x30(%r13)
 100e785:	sete   %al
 100e788:	and    %cl,%al
 100e78a:	cmp    $0x1,%al
 100e78c:	jne    100e730 <release_all+0xa0>
 100e78e:	mov    0x0(%r13),%rdi
 100e792:	vzeroupper
 100e795:	call   101edc0 <free@plt>
 100e79a:	mov    0x18(%r13),%rdi
 100e79e:	call   101edc0 <free@plt>
 100e7a3:	mov    %r13,%rdi
 100e7a6:	call   101edc0 <free@plt>
 100e7ab:	jmp    100e730 <release_all+0xa0>
 100e7ad:	nopl   (%rax)
 100e7b0:	cmpq   $0x0,0x8(%r12)
 100e7b6:	je     100e6d0 <release_all+0x40>
 100e7bc:	xor    %r14d,%r14d
 100e7bf:	nop
 100e7c0:	mov    (%r12),%rax
 100e7c4:	mov    (%rax,%r14,8),%r13
 100e7c8:	mov    0x0(%r13),%rdi
 100e7cc:	vzeroupper
 100e7cf:	call   101edc0 <free@plt>
 100e7d4:	mov    0x18(%r13),%rdi
 100e7d8:	call   101edc0 <free@plt>
 100e7dd:	mov    %r13,%rdi
 100e7e0:	call   101edc0 <free@plt>
 100e7e5:	inc    %r14
 100e7e8:	cmp    0x8(%r12),%r14
 100e7ed:	jb     100e7c0 <release_all+0x130>
 100e7ef:	jmp    100e6d0 <release_all+0x40>
 100e7f4:	mov    (%r14),%rdi
 100e7f7:	call   101edc0 <free@plt>
 100e7fc:	mov    %r14,%rdi
 100e7ff:	call   101edc0 <free@plt>
 100e804:	vxorps %xmm0,%xmm0,%xmm0
 100e808:	mov    -0x30(%rbp),%rax
 100e80c:	vmovups %xmm0,(%rax)
 100e810:	add    $0x18,%rsp
 100e814:	pop    %rbx
 100e815:	pop    %r12
 100e817:	pop    %r13
 100e819:	pop    %r14
 100e81b:	pop    %r15
 100e81d:	pop    %rbp
 100e81e:	ret
 100e81f:	int3

000000000100e820 <myl_native_budget_environment>:
 100e820:	push   %rbp
 100e821:	mov    %rsp,%rbp
 100e824:	push   %rbx
 100e825:	push   %rax
 100e826:	mov    %rdi,%rbx
 100e829:	lea    -0xcc53(%rip),%rdi        # 1001bdd <__abi_tag+0x18e1>
 100e830:	call   101ef90 <getenv@plt>
 100e835:	test   %rbx,%rbx
 100e838:	je     100e840 <myl_native_budget_environment+0x20>
 100e83a:	movl   $0x1,(%rbx)
 100e840:	test   %rax,%rax
 100e843:	je     100e925 <myl_native_budget_environment+0x105>
 100e849:	movzbl (%rax),%edx
 100e84c:	test   %dl,%dl
 100e84e:	je     100e925 <myl_native_budget_environment+0x105>
 100e854:	lea    -0x30(%rdx),%ecx
 100e857:	cmp    $0x9,%cl
 100e85a:	ja     100e91a <myl_native_budget_environment+0xfa>
 100e860:	inc    %rax
 100e863:	xor    %ecx,%ecx
 100e865:	movabs $0xcccccccccccccccd,%rsi
 100e86f:	nop
 100e870:	add    $0xd0,%dl
 100e873:	movzbl %dl,%edi
 100e876:	mov    %rdi,%rdx
 100e879:	not    %rdx
 100e87c:	mulx   %rsi,%rdx,%rdx
 100e881:	shr    $0x3,%rdx
 100e885:	cmp    %rdx,%rcx
 100e888:	ja     100e91a <myl_native_budget_environment+0xfa>
 100e88e:	lea    (%rcx,%rcx,4),%rcx
 100e892:	lea    (%rdi,%rcx,2),%rcx
 100e896:	movzbl (%rax),%edx
 100e899:	lea    -0x30(%rdx),%edi
 100e89c:	inc    %rax
 100e89f:	cmp    $0xa,%dil
 100e8a3:	jb     100e870 <myl_native_budget_environment+0x50>
 100e8a5:	movzbl %dl,%edx
 100e8a8:	lea    -0x47(%rdx),%esi
 100e8ab:	cmp    $0x26,%esi
 100e8ae:	ja     100e8ec <myl_native_budget_environment+0xcc>
 100e8b0:	movabs $0x100000001,%rdi
 100e8ba:	bt     %rsi,%rdi
 100e8be:	jb     100e8f7 <myl_native_budget_environment+0xd7>
 100e8c0:	mov    $0x400,%edi
 100e8c5:	movabs $0x1000000010,%r8
 100e8cf:	bt     %rsi,%r8
 100e8d3:	jb     100e8fc <myl_native_budget_environment+0xdc>
 100e8d5:	movabs $0x4000000040,%rdi
 100e8df:	bt     %rsi,%rdi
 100e8e3:	jae    100e8ec <myl_native_budget_environment+0xcc>
 100e8e5:	mov    $0x100000,%edi
 100e8ea:	jmp    100e8fc <myl_native_budget_environment+0xdc>
 100e8ec:	mov    $0x1,%eax
 100e8f1:	test   %edx,%edx
 100e8f3:	je     100e904 <myl_native_budget_environment+0xe4>
 100e8f5:	jmp    100e91a <myl_native_budget_environment+0xfa>
 100e8f7:	mov    $0x40000000,%edi
 100e8fc:	cmpb   $0x0,(%rax)
 100e8ff:	mov    %rdi,%rax
 100e902:	jne    100e91a <myl_native_budget_environment+0xfa>
 100e904:	tzcnt  %rax,%rdx
 100e909:	mov    $0xffffffffffffffff,%rsi
 100e910:	shrx   %rdx,%rsi,%rdx
 100e915:	cmp    %rdx,%rcx
 100e918:	jbe    100e92e <myl_native_budget_environment+0x10e>
 100e91a:	test   %rbx,%rbx
 100e91d:	je     100e925 <myl_native_budget_environment+0x105>
 100e91f:	movl   $0x0,(%rbx)
 100e925:	xor    %eax,%eax
 100e927:	add    $0x8,%rsp
 100e92b:	pop    %rbx
 100e92c:	pop    %rbp
 100e92d:	ret
 100e92e:	imul   %rcx,%rax
 100e932:	jmp    100e927 <myl_native_budget_environment+0x107>
 100e934:	int3
 100e935:	int3
 100e936:	int3
 100e937:	int3
 100e938:	int3
 100e939:	int3
 100e93a:	int3
 100e93b:	int3
 100e93c:	int3
 100e93d:	int3
 100e93e:	int3
 100e93f:	int3

000000000100e940 <myl_native_budget_guard>:
 100e940:	push   %rbp
 100e941:	mov    %rsp,%rbp
 100e944:	push   %r15
 100e946:	push   %r14
 100e948:	push   %r12
 100e94a:	push   %rbx
 100e94b:	sub    $0x10,%rsp
 100e94f:	mov    %rdi,%rbx
 100e952:	lea    -0xcc4a(%rip),%rdi        # 1001d0f <__abi_tag+0x1a13>
 100e959:	call   101ef90 <getenv@plt>
 100e95e:	test   %rax,%rax
 100e961:	je     100e98a <myl_native_budget_guard+0x4a>
 100e963:	movzbl (%rax),%edx
 100e966:	lea    -0x3a(%rdx),%ecx
 100e969:	cmp    $0xf6,%cl
 100e96c:	jae    100ea08 <myl_native_budget_guard+0xc8>
 100e972:	lea    -0xcc6a(%rip),%rdi        # 1001d0f <__abi_tag+0x1a13>
 100e979:	call   101efc0 <unsetenv@plt>
 100e97e:	lea    -0xcde5(%rip),%rdi        # 1001ba0 <__abi_tag+0x18a4>
 100e985:	call   101efc0 <unsetenv@plt>
 100e98a:	add    $0x10000000,%rbx
 100e991:	xor    %r14d,%r14d
 100e994:	cmp    $0x10000001,%rbx
 100e99b:	jb     100e9f8 <myl_native_budget_guard+0xb8>
 100e99d:	lea    -0x30(%rbp),%rsi
 100e9a1:	mov    $0x9,%edi
 100e9a6:	call   101ef40 <getrlimit@plt>
 100e9ab:	test   %eax,%eax
 100e9ad:	jne    100e9f8 <myl_native_budget_guard+0xb8>
 100e9af:	mov    -0x28(%rbp),%rcx
 100e9b3:	cmp    %rcx,%rbx
 100e9b6:	mov    %rcx,%rax
 100e9b9:	cmovb  %rbx,%rax
 100e9bd:	cmp    $0xffffffffffffffff,%rcx
 100e9c1:	cmove  %rbx,%rax
 100e9c5:	mov    -0x30(%rbp),%rcx
 100e9c9:	cmp    $0xffffffffffffffff,%rcx
 100e9cd:	sete   %dl
 100e9d0:	cmp    %rax,%rcx
 100e9d3:	seta   %cl
 100e9d6:	or     %dl,%cl
 100e9d8:	cmp    $0x1,%cl
 100e9db:	jne    100e9f8 <myl_native_budget_guard+0xb8>
 100e9dd:	mov    %rax,-0x30(%rbp)
 100e9e1:	lea    -0x30(%rbp),%rsi
 100e9e5:	mov    $0x9,%edi
 100e9ea:	call   101efd0 <setrlimit@plt>
 100e9ef:	xor    %r14d,%r14d
 100e9f2:	test   %eax,%eax
 100e9f4:	sete   %r14b
 100e9f8:	mov    %r14d,%eax
 100e9fb:	add    $0x10,%rsp
 100e9ff:	pop    %rbx
 100ea00:	pop    %r12
 100ea02:	pop    %r14
 100ea04:	pop    %r15
 100ea06:	pop    %rbp
 100ea07:	ret
 100ea08:	add    $0x2,%rax
 100ea0c:	xor    %r14d,%r14d
 100ea0f:	movabs $0xcccccccccccccccd,%rcx
 100ea19:	nopl   0x0(%rax)
 100ea20:	add    $0xd0,%dl
 100ea23:	movzbl %dl,%esi
 100ea26:	mov    %rsi,%rdx
 100ea29:	not    %rdx
 100ea2c:	mulx   %rcx,%rdx,%rdx
 100ea31:	shr    $0x3,%rdx
 100ea35:	cmp    %rdx,%r14
 100ea38:	ja     100e972 <myl_native_budget_guard+0x32>
 100ea3e:	lea    (%r14,%r14,4),%rdx
 100ea42:	lea    (%rsi,%rdx,2),%r14
 100ea46:	movzbl -0x1(%rax),%edx
 100ea4a:	lea    -0x30(%rdx),%esi
 100ea4d:	inc    %rax
 100ea50:	cmp    $0xa,%sil
 100ea54:	jb     100ea20 <myl_native_budget_guard+0xe0>
 100ea56:	cmp    $0x3a,%dl
 100ea59:	jne    100e972 <myl_native_budget_guard+0x32>
 100ea5f:	movzbl -0x1(%rax),%r12d
 100ea64:	lea    -0x3a(%r12),%edx
 100ea69:	cmp    $0xf6,%dl
 100ea6c:	jb     100e972 <myl_native_budget_guard+0x32>
 100ea72:	xor    %r15d,%r15d
 100ea75:	data16 cs nopw 0x0(%rax,%rax,1)
 100ea80:	add    $0xd0,%r12b
 100ea84:	movzbl %r12b,%esi
 100ea88:	mov    %rsi,%rdx
 100ea8b:	not    %rdx
 100ea8e:	mulx   %rcx,%rdx,%rdx
 100ea93:	shr    $0x3,%rdx
 100ea97:	cmp    %rdx,%r15
 100ea9a:	ja     100e972 <myl_native_budget_guard+0x32>
 100eaa0:	lea    (%r15,%r15,4),%rdx
 100eaa4:	lea    (%rsi,%rdx,2),%r15
 100eaa8:	movzbl (%rax),%r12d
 100eaac:	lea    -0x30(%r12),%edx
 100eab1:	inc    %rax
 100eab4:	cmp    $0xa,%dl
 100eab7:	jb     100ea80 <myl_native_budget_guard+0x140>
 100eab9:	lea    -0xcdb1(%rip),%rdi        # 1001d0f <__abi_tag+0x1a13>
 100eac0:	call   101efc0 <unsetenv@plt>
 100eac5:	lea    -0xcf2c(%rip),%rdi        # 1001ba0 <__abi_tag+0x18a4>
 100eacc:	call   101efc0 <unsetenv@plt>
 100ead1:	test   %r12b,%r12b
 100ead4:	jne    100e98a <myl_native_budget_guard+0x4a>
 100eada:	lea    -0x30(%rbp),%rsi
 100eade:	mov    $0x9,%edi
 100eae3:	call   101ef40 <getrlimit@plt>
 100eae8:	test   %eax,%eax
 100eaea:	jne    100e98a <myl_native_budget_guard+0x4a>
 100eaf0:	cmp    %r14,-0x30(%rbp)
 100eaf4:	jne    100e98a <myl_native_budget_guard+0x4a>
 100eafa:	mov    -0x28(%rbp),%rcx
 100eafe:	cmp    %rcx,%r15
 100eb01:	mov    %rcx,%rax
 100eb04:	cmovb  %r15,%rax
 100eb08:	cmp    $0xffffffffffffffff,%rcx
 100eb0c:	cmove  %r15,%rax
 100eb10:	cmp    %r14,%rax
 100eb13:	jbe    100e98a <myl_native_budget_guard+0x4a>
 100eb19:	mov    %rax,-0x30(%rbp)
 100eb1d:	lea    -0x30(%rbp),%rsi
 100eb21:	mov    $0x9,%edi
 100eb26:	call   101efd0 <setrlimit@plt>
 100eb2b:	jmp    100e98a <myl_native_budget_guard+0x4a>

000000000100eb30 <myl_native_heap_init>:
 100eb30:	push   %rbp
 100eb31:	mov    %rsp,%rbp
 100eb34:	push   %r14
 100eb36:	push   %rbx
 100eb37:	mov    %rsi,%r14
 100eb3a:	mov    %rdi,%rbx
 100eb3d:	mov    $0x1718,%edx
 100eb42:	xor    %esi,%esi
 100eb44:	call   101e4a0 <compiler_rt.fastMemset>
 100eb49:	mov    %r14,0x58(%rbx)
 100eb4d:	movq   $0x1,0x38(%rbx)
 100eb55:	movq   $0x100000,0x60(%rbx)
 100eb5d:	mov    %rbx,%rdi
 100eb60:	call   101c5f0 <myl_rc_storage_init>
 100eb65:	test   %eax,%eax
 100eb67:	je     100eb73 <myl_native_heap_init+0x43>
 100eb69:	movl   $0x1,0x4f8(%rbx)
 100eb73:	pop    %rbx
 100eb74:	pop    %r14
 100eb76:	pop    %rbp
 100eb77:	ret
 100eb78:	int3
 100eb79:	int3
 100eb7a:	int3
 100eb7b:	int3
 100eb7c:	int3
 100eb7d:	int3
 100eb7e:	int3
 100eb7f:	int3

000000000100eb80 <myl_native_root_push>:
 100eb80:	push   %rbp
 100eb81:	mov    %rsp,%rbp
 100eb84:	mov    0x10(%rdi),%rax
 100eb88:	mov    %rax,(%rsi)
 100eb8b:	mov    %rdx,0x8(%rsi)
 100eb8f:	mov    %rcx,0x10(%rsi)
 100eb93:	mov    %rsi,0x10(%rdi)
 100eb97:	pop    %rbp
 100eb98:	ret
 100eb99:	int3
 100eb9a:	int3
 100eb9b:	int3
 100eb9c:	int3
 100eb9d:	int3
 100eb9e:	int3
 100eb9f:	int3

000000000100eba0 <myl_native_root_pop>:
 100eba0:	push   %rbp
 100eba1:	mov    %rsp,%rbp
 100eba4:	xor    %eax,%eax
 100eba6:	cmp    %rsi,0x10(%rdi)
 100ebaa:	je     100ebae <myl_native_root_pop+0xe>
 100ebac:	pop    %rbp
 100ebad:	ret
 100ebae:	mov    (%rsi),%rax
 100ebb1:	mov    %rax,0x10(%rdi)
 100ebb5:	mov    $0x1,%eax
 100ebba:	pop    %rbp
 100ebbb:	ret
 100ebbc:	int3
 100ebbd:	int3
 100ebbe:	int3
 100ebbf:	int3

000000000100ebc0 <flatten>:
 100ebc0:	mov    0x58(%rsi),%r9d
 100ebc4:	cmp    $0x1,%r9d
 100ebc8:	jne    100ebd0 <flatten+0x10>
 100ebca:	mov    $0x1,%eax
 100ebcf:	ret
 100ebd0:	mov    $0xffffffff,%r10d
 100ebd6:	sub    (%rsi),%r10
 100ebd9:	xor    %eax,%eax
 100ebdb:	cmp    %r10,%rdx
 100ebde:	jbe    100ebe1 <flatten+0x21>
 100ebe0:	ret
 100ebe1:	push   %rbp
 100ebe2:	mov    %rsp,%rbp
 100ebe5:	push   %r15
 100ebe7:	push   %r14
 100ebe9:	push   %r13
 100ebeb:	push   %r12
 100ebed:	push   %rbx
 100ebee:	sub    $0x28,%rsp
 100ebf2:	mov    %rcx,%r15
 100ebf5:	shr    $0x20,%r15
 100ebf9:	movzwl 0x30(%rsi),%r10d
 100ebfe:	cmp    $0x6,%r10d
 100ec02:	ja     100ec4a <flatten+0x8a>
 100ec04:	mov    $0x62,%r11d
 100ec0a:	bt     %r10d,%r11d
 100ec0e:	jae    100ec4a <flatten+0x8a>
 100ec10:	mov    0x10(%rdi),%rcx
 100ec14:	cmp    0x8(%rdi),%rcx
 100ec18:	je     100ec3b <flatten+0x7b>
 100ec1a:	mov    (%rdi),%rax
 100ec1d:	lea    0x1(%rcx),%rsi
 100ec21:	mov    %rsi,0x10(%rdi)
 100ec25:	lea    (%rcx,%rcx,2),%rcx
 100ec29:	mov    %edx,(%rax,%rcx,4)
 100ec2c:	mov    %r15d,0x4(%rax,%rcx,4)
 100ec31:	mov    %r8d,0x8(%rax,%rcx,4)
 100ec36:	mov    $0x1,%eax
 100ec3b:	add    $0x28,%rsp
 100ec3f:	pop    %rbx
 100ec40:	pop    %r12
 100ec42:	pop    %r13
 100ec44:	pop    %r14
 100ec46:	pop    %r15
 100ec48:	pop    %rbp
 100ec49:	ret
 100ec4a:	lea    0x10(%rsi),%r11
 100ec4e:	lea    0x48(%rsi),%rbx
 100ec52:	cmp    $0x2,%r9d
 100ec56:	cmove  %rbx,%r11
 100ec5a:	mov    (%r11),%rbx
 100ec5d:	cmp    $0x2,%r10d
 100ec61:	mov    %r8d,-0x2c(%rbp)
 100ec65:	mov    %rdx,-0x40(%rbp)
 100ec69:	mov    %rdi,%r13
 100ec6c:	mov    %rcx,%r14
 100ec6f:	mov    %rsi,-0x38(%rbp)
 100ec73:	je     100eccd <flatten+0x10d>
 100ec75:	cmp    $0x4,%r10d
 100ec79:	je     100eccd <flatten+0x10d>
 100ec7b:	cmp    $0x3,%r10d
 100ec7f:	jne    100ec36 <flatten+0x76>
 100ec81:	cmpq   $0x0,0x20(%rsi)
 100ec86:	je     100ec36 <flatten+0x76>
 100ec88:	xor    %r15d,%r15d
 100ec8b:	mov    0x8(%rbx),%rax
 100ec8f:	mov    0x28(%rsi),%r9
 100ec93:	imul   %r15,%r9
 100ec97:	add    %rdx,%r9
 100ec9a:	mov    %rax,%rsi
 100ec9d:	mov    %r9,%rdx
 100eca0:	call   100ebc0 <flatten>
 100eca5:	test   %eax,%eax
 100eca7:	je     100ed64 <flatten+0x1a4>
 100ecad:	inc    %r15
 100ecb0:	mov    -0x38(%rbp),%rsi
 100ecb4:	cmp    0x20(%rsi),%r15
 100ecb8:	mov    -0x2c(%rbp),%r8d
 100ecbc:	mov    -0x40(%rbp),%rdx
 100ecc0:	mov    %r13,%rdi
 100ecc3:	mov    %r14,%rcx
 100ecc6:	jb     100ec8b <flatten+0xcb>
 100ecc8:	jmp    100ec36 <flatten+0x76>
 100eccd:	lea    0x18(%rsi),%r11
 100ecd1:	lea    0x50(%rsi),%r12
 100ecd5:	cmp    $0x2,%r9d
 100ecd9:	cmove  %r12,%r11
 100ecdd:	cmp    $0x4,%r10d
 100ece1:	sete   %r9b
 100ece5:	mov    $0xffffffff,%r10d
 100eceb:	cmp    %r10,%r15
 100ecee:	setne  %r10b
 100ecf2:	test   %r10b,%r9b
 100ecf5:	jne    100ec3b <flatten+0x7b>
 100ecfb:	mov    (%r11),%r12
 100ecfe:	test   %r12,%r12
 100ed01:	je     100ec36 <flatten+0x76>
 100ed07:	mov    %edx,%eax
 100ed09:	mov    %rax,-0x48(%rbp)
 100ed0d:	add    $0x10,%rbx
 100ed11:	cmpw   $0x4,0x30(%rsi)
 100ed16:	mov    %r15,%r9
 100ed19:	jne    100ed24 <flatten+0x164>
 100ed1b:	mov    (%rbx),%r8d
 100ed1e:	xor    %ecx,%ecx
 100ed20:	mov    -0x48(%rbp),%r9
 100ed24:	mov    -0x8(%rbx),%rsi
 100ed28:	mov    -0x10(%rbx),%rax
 100ed2c:	add    %rdx,%rax
 100ed2f:	shl    $0x20,%r9
 100ed33:	mov    %ecx,%ecx
 100ed35:	or     %r9,%rcx
 100ed38:	mov    %rax,%rdx
 100ed3b:	call   100ebc0 <flatten>
 100ed40:	test   %eax,%eax
 100ed42:	je     100ed64 <flatten+0x1a4>
 100ed44:	add    $0x18,%rbx
 100ed48:	dec    %r12
 100ed4b:	mov    -0x2c(%rbp),%r8d
 100ed4f:	mov    -0x40(%rbp),%rdx
 100ed53:	mov    %r13,%rdi
 100ed56:	mov    %r14,%rcx
 100ed59:	mov    -0x38(%rbp),%rsi
 100ed5d:	jne    100ed11 <flatten+0x151>
 100ed5f:	jmp    100ec36 <flatten+0x76>
 100ed64:	xor    %eax,%eax
 100ed66:	jmp    100ec3b <flatten+0x7b>
 100ed6b:	int3
 100ed6c:	int3
 100ed6d:	int3
 100ed6e:	int3
 100ed6f:	int3

000000000100ed70 <myl_native_heap_collect>:
 100ed70:	push   %rbp
 100ed71:	mov    %rsp,%rbp
 100ed74:	test   %rdi,%rdi
 100ed77:	je     100ed89 <myl_native_heap_collect+0x19>
 100ed79:	cmpq   $0x0,0x1608(%rdi)
 100ed81:	je     100ed89 <myl_native_heap_collect+0x19>
 100ed83:	pop    %rbp
 100ed84:	jmp    1016000 <myl_rc_drain>
 100ed89:	mov    $0x1,%esi
 100ed8e:	pop    %rbp
 100ed8f:	jmp    100eda0 <collect>
 100ed94:	int3
 100ed95:	int3
 100ed96:	int3
 100ed97:	int3
 100ed98:	int3
 100ed99:	int3
 100ed9a:	int3
 100ed9b:	int3
 100ed9c:	int3
 100ed9d:	int3
 100ed9e:	int3
 100ed9f:	int3

000000000100eda0 <collect>:
 100eda0:	cmpl   $0x0,0x74(%rdi)
 100eda4:	je     100eda7 <collect+0x7>
 100eda6:	ret
 100eda7:	push   %rbp
 100eda8:	mov    %rsp,%rbp
 100edab:	push   %r15
 100edad:	push   %r14
 100edaf:	push   %r13
 100edb1:	push   %r12
 100edb3:	push   %rbx
 100edb4:	and    $0xffffffffffffffe0,%rsp
 100edb8:	sub    $0x80,%rsp
 100edbf:	mov    %rdi,%rbx
 100edc2:	mov    0x1170(%rdi),%eax
 100edc8:	incq   0x50(%rdi)
 100edcc:	movq   $0x0,0x4e8(%rdi)
 100edd7:	movl   $0x0,0x4f8(%rdi)
 100ede1:	vpxor  %xmm0,%xmm0,%xmm0
 100ede5:	vmovdqu %ymm0,0x500(%rdi)
 100eded:	vmovdqu %ymm0,0x520(%rdi)
 100edf5:	vmovdqu %ymm0,0x540(%rdi)
 100edfd:	vmovdqu %ymm0,0x560(%rdi)
 100ee05:	vmovdqu %ymm0,0x580(%rdi)
 100ee0d:	vmovdqu %ymm0,0x5a0(%rdi)
 100ee15:	mov    $0x688,%ecx
 100ee1a:	nopw   0x0(%rax,%rax,1)
 100ee20:	vmovdqu %ymm0,-0xa8(%rbx,%rcx,1)
 100ee29:	movq   $0x0,-0x88(%rbx,%rcx,1)
 100ee35:	vmovdqu %ymm0,-0x70(%rbx,%rcx,1)
 100ee3b:	movq   $0x0,-0x50(%rbx,%rcx,1)
 100ee44:	vmovdqu %ymm0,-0x38(%rbx,%rcx,1)
 100ee4a:	movq   $0x0,-0x18(%rbx,%rcx,1)
 100ee53:	vmovdqu %ymm0,(%rbx,%rcx,1)
 100ee58:	movq   $0x0,0x20(%rbx,%rcx,1)
 100ee61:	add    $0xe0,%rcx
 100ee68:	cmp    $0x11e8,%rcx
 100ee6f:	jne    100ee20 <collect+0x80>
 100ee71:	test   %eax,%eax
 100ee73:	mov    $0x1,%r15d
 100ee79:	cmove  %esi,%r15d
 100ee7d:	test   %r15d,%r15d
 100ee80:	je     100ef6e <collect+0x1ce>
 100ee86:	mov    (%rbx),%r14
 100ee89:	test   %r14,%r14
 100ee8c:	jne    100eebf <collect+0x11f>
 100ee8e:	jmp    100ef47 <collect+0x1a7>
 100ee93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100eea0:	lea    0x48(%r14),%rdi
 100eea4:	mov    $0x400,%edx
 100eea9:	xor    %esi,%esi
 100eeab:	vzeroupper
 100eeae:	call   101e4a0 <compiler_rt.fastMemset>
 100eeb3:	mov    (%r14),%r14
 100eeb6:	test   %r14,%r14
 100eeb9:	je     100ef47 <collect+0x1a7>
 100eebf:	cmpq   $0x20,0x20(%r14)
 100eec4:	jb     100eea0 <collect+0x100>
 100eec6:	mov    0x18(%r14),%rdx
 100eeca:	test   %rdx,%rdx
 100eecd:	je     100ef3b <collect+0x19b>
 100eecf:	mov    0x8(%r14),%rax
 100eed3:	mov    %edx,%ecx
 100eed5:	and    $0x3,%ecx
 100eed8:	cmp    $0x4,%rdx
 100eedc:	jae    100eee2 <collect+0x142>
 100eede:	xor    %esi,%esi
 100eee0:	jmp    100ef21 <collect+0x181>
 100eee2:	lea    0x470(%r14),%rdi
 100eee9:	and    $0xfffffffffffffffc,%rdx
 100eeed:	lea    (%rax,%rax,2),%r8
 100eef1:	lea    0x0(,%rax,4),%r9
 100eef9:	xor    %esi,%esi
 100eefb:	nopl   0x0(%rax,%rax,1)
 100ef00:	andb   $0xfe,(%rdi)
 100ef03:	andb   $0xfe,(%rdi,%rax,1)
 100ef07:	andb   $0xfe,(%rdi,%rax,2)
 100ef0b:	andb   $0xfe,(%rdi,%r8,1)
 100ef10:	add    $0x4,%rsi
 100ef14:	add    %r9,%rdi
 100ef17:	cmp    %rsi,%rdx
 100ef1a:	jne    100ef00 <collect+0x160>
 100ef1c:	test   %rcx,%rcx
 100ef1f:	je     100ef3b <collect+0x19b>
 100ef21:	imul   %rax,%rsi
 100ef25:	lea    (%r14,%rsi,1),%rdx
 100ef29:	add    $0x470,%rdx
 100ef30:	andb   $0xfe,(%rdx)
 100ef33:	add    %rax,%rdx
 100ef36:	dec    %rcx
 100ef39:	jne    100ef30 <collect+0x190>
 100ef3b:	mov    (%r14),%r14
 100ef3e:	test   %r14,%r14
 100ef41:	jne    100eebf <collect+0x11f>
 100ef47:	movq   $0x0,0x1158(%rbx)
 100ef52:	movq   $0x0,0x1140(%rbx)
 100ef5d:	movl   $0x0,0x1170(%rbx)
 100ef67:	mov    $0x1180,%eax
 100ef6c:	jmp    100ef73 <collect+0x1d3>
 100ef6e:	mov    $0x1178,%eax
 100ef73:	incq   (%rbx,%rax,1)
 100ef77:	mov    %r15d,%eax
 100ef7a:	xor    $0x1,%al
 100ef7c:	mov    %al,0x1174(%rbx)
 100ef82:	mov    0x10(%rbx),%r14
 100ef86:	test   %r14,%r14
 100ef89:	je     100efab <collect+0x20b>
 100ef8b:	nopl   0x0(%rax,%rax,1)
 100ef90:	mov    0x8(%r14),%rdx
 100ef94:	mov    0x10(%r14),%rsi
 100ef98:	mov    %rbx,%rdi
 100ef9b:	vzeroupper
 100ef9e:	call   100fd40 <trace>
 100efa3:	mov    (%r14),%r14
 100efa6:	test   %r14,%r14
 100efa9:	jne    100ef90 <collect+0x1f0>
 100efab:	mov    $0x1a,%r14d
 100efb1:	jmp    100efcc <collect+0x22c>
 100efb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100efc0:	inc    %r14
 100efc3:	cmp    $0x9a,%r14
 100efca:	je     100efe2 <collect+0x242>
 100efcc:	mov    (%rbx,%r14,8),%rsi
 100efd0:	test   %rsi,%rsi
 100efd3:	je     100efc0 <collect+0x220>
 100efd5:	mov    %rbx,%rdi
 100efd8:	vzeroupper
 100efdb:	call   100ff90 <mark>
 100efe0:	jmp    100efc0 <collect+0x220>
 100efe2:	cmpq   $0x0,(%rbx)
 100efe6:	je     100effa <collect+0x25a>
 100efe8:	lea    0xd51(%rip),%rsi        # 100fd40 <trace>
 100efef:	mov    %rbx,%rdi
 100eff2:	vzeroupper
 100eff5:	call   1010c70 <myl_native_arena_trace>
 100effa:	mov    %r15d,0x14(%rsp)
 100efff:	test   %r15d,%r15d
 100f002:	jne    100f234 <collect+0x494>
 100f008:	movb   $0x2,0x1174(%rbx)
 100f00f:	mov    0x1140(%rbx),%rax
 100f016:	xor    %r14d,%r14d
 100f019:	test   %rax,%rax
 100f01c:	je     100f08f <collect+0x2ef>
 100f01e:	xor    %r15d,%r15d
 100f021:	jmp    100f038 <collect+0x298>
 100f023:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f030:	inc    %r15
 100f033:	cmp    %rax,%r15
 100f036:	jae    100f08f <collect+0x2ef>
 100f038:	mov    0x1138(%rbx),%rcx
 100f03f:	mov    (%rcx,%r15,8),%rsi
 100f043:	mov    (%rsi),%rdx
 100f046:	test   %rdx,%rdx
 100f049:	js     100f06f <collect+0x2cf>
 100f04b:	mov    %rsi,%rdx
 100f04e:	and    $0xffffffffffff0000,%rdx
 100f055:	mov    %esi,%edi
 100f057:	shr    $0x4,%edi
 100f05a:	mov    %esi,%r8d
 100f05d:	shr    $0x7,%r8d
 100f061:	and    $0x1f8,%r8d
 100f068:	shrx   %rdi,0x48(%rdx,%r8,1),%rdx
 100f06f:	test   $0x1,%dl
 100f072:	je     100f030 <collect+0x290>
 100f074:	mov    %rsi,(%rcx,%r14,8)
 100f078:	inc    %r14
 100f07b:	mov    %rbx,%rdi
 100f07e:	vzeroupper
 100f081:	call   10101e0 <scan_payload>
 100f086:	mov    0x1140(%rbx),%rax
 100f08d:	jmp    100f030 <collect+0x290>
 100f08f:	mov    %r14,0x1140(%rbx)
 100f096:	mov    (%rbx),%r14
 100f099:	jmp    100f0a3 <collect+0x303>
 100f09b:	nopl   0x0(%rax,%rax,1)
 100f0a0:	mov    (%r14),%r14
 100f0a3:	test   %r14,%r14
 100f0a6:	je     100f0e7 <collect+0x347>
 100f0a8:	cmpq   $0x34,0x20(%r14)
 100f0ad:	jb     100f0a0 <collect+0x300>
 100f0af:	testb  $0x1,0x470(%r14)
 100f0b7:	je     100f0a0 <collect+0x300>
 100f0b9:	mov    0x478(%r14),%rax
 100f0c0:	cmpw   $0x0,0x30(%rax)
 100f0c5:	je     100f0a0 <collect+0x300>
 100f0c7:	cmpl   $0x1,0x58(%rax)
 100f0cb:	je     100f0a0 <collect+0x300>
 100f0cd:	cmpl   $0x0,0x5c(%rax)
 100f0d1:	jne    100f0a0 <collect+0x300>
 100f0d3:	lea    0x470(%r14),%rsi
 100f0da:	mov    %rbx,%rdi
 100f0dd:	vzeroupper
 100f0e0:	call   10101e0 <scan_payload>
 100f0e5:	jmp    100f0a0 <collect+0x300>
 100f0e7:	mov    0x1158(%rbx),%rax
 100f0ee:	test   %rax,%rax
 100f0f1:	je     100f22d <collect+0x48d>
 100f0f7:	mov    0x1150(%rbx),%r8
 100f0fe:	xor    %ecx,%ecx
 100f100:	xor    %edi,%edi
 100f102:	jmp    100f118 <collect+0x378>
 100f104:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f110:	inc    %rcx
 100f113:	cmp    %rcx,%rax
 100f116:	je     100f13c <collect+0x39c>
 100f118:	mov    (%r8,%rcx,8),%rdx
 100f11c:	cmpq   $0x0,0x8(%rdx)
 100f121:	je     100f110 <collect+0x370>
 100f123:	mov    (%rdx),%rsi
 100f126:	test   $0x1,%sil
 100f12a:	jne    100f110 <collect+0x370>
 100f12c:	or     $0x1,%rsi
 100f130:	mov    %rsi,(%rdx)
 100f133:	mov    %rdx,(%r8,%rdi,8)
 100f137:	inc    %rdi
 100f13a:	jmp    100f110 <collect+0x370>
 100f13c:	movq   $0x0,0x1158(%rbx)
 100f147:	test   %rdi,%rdi
 100f14a:	je     100f22d <collect+0x48d>
 100f150:	xor    %r13d,%r13d
 100f153:	jmp    100f177 <collect+0x3d7>
 100f155:	mov    0x1150(%rbx),%rax
 100f15c:	lea    0x1(%rcx),%rdx
 100f160:	mov    %rdx,0x1158(%rbx)
 100f167:	mov    %r14,(%rax,%rcx,8)
 100f16b:	inc    %r13
 100f16e:	cmp    %r13,%rdi
 100f171:	je     100f22d <collect+0x48d>
 100f177:	mov    (%r8,%r13,8),%r14
 100f17b:	cmpq   $0x0,0x8(%r14)
 100f180:	je     100f16b <collect+0x3cb>
 100f182:	movb   $0x0,0x1175(%rbx)
 100f189:	mov    %rdi,%r15
 100f18c:	mov    %rbx,%rdi
 100f18f:	mov    %r14,%rsi
 100f192:	mov    %r8,%r12
 100f195:	vzeroupper
 100f198:	call   10101e0 <scan_payload>
 100f19d:	mov    %r12,%r8
 100f1a0:	mov    %r15,%rdi
 100f1a3:	cmpb   $0x0,0x1175(%rbx)
 100f1aa:	je     100f16b <collect+0x3cb>
 100f1ac:	mov    0x1158(%rbx),%rcx
 100f1b3:	cmp    0x1160(%rbx),%rcx
 100f1ba:	jne    100f155 <collect+0x3b5>
 100f1bc:	lea    (%rcx,%rcx,1),%rdx
 100f1c0:	test   %rcx,%rcx
 100f1c3:	mov    $0x100,%eax
 100f1c8:	cmove  %rax,%rdx
 100f1cc:	cmp    %rcx,%rdx
 100f1cf:	setbe  %al
 100f1d2:	movabs $0x1fffffffffffffff,%rcx
 100f1dc:	cmp    %rcx,%rdx
 100f1df:	seta   %cl
 100f1e2:	or     %al,%cl
 100f1e4:	jne    100f16b <collect+0x3cb>
 100f1e6:	mov    0x1150(%rbx),%rdi
 100f1ed:	lea    0x0(,%rdx,8),%rsi
 100f1f5:	mov    %rdx,0x20(%rsp)
 100f1fa:	call   101ef70 <realloc@plt>
 100f1ff:	mov    0x20(%rsp),%rcx
 100f204:	mov    %r12,%r8
 100f207:	mov    %r15,%rdi
 100f20a:	test   %rax,%rax
 100f20d:	je     100f16b <collect+0x3cb>
 100f213:	mov    %rax,0x1150(%rbx)
 100f21a:	mov    %rcx,0x1160(%rbx)
 100f221:	mov    0x1158(%rbx),%rcx
 100f228:	jmp    100f15c <collect+0x3bc>
 100f22d:	movb   $0x1,0x1174(%rbx)
 100f234:	mov    0x4e8(%rbx),%rax
 100f23b:	test   %rax,%rax
 100f23e:	je     100f432 <collect+0x692>
 100f244:	mov    $0x3c,%r12d
 100f24a:	mov    $0x100,%r13d
 100f250:	jmp    100f270 <collect+0x4d0>
 100f252:	movl   $0x1,0x1170(%rbx)
 100f25c:	nopl   0x0(%rax)
 100f260:	mov    0x4e8(%rbx),%rax
 100f267:	test   %rax,%rax
 100f26a:	je     100f432 <collect+0x692>
 100f270:	mov    0x8(%rbx),%rcx
 100f274:	lea    -0x1(%rax),%rdx
 100f278:	mov    %rdx,0x4e8(%rbx)
 100f27f:	mov    -0x8(%rcx,%rax,8),%r14
 100f284:	movb   $0x0,0x1175(%rbx)
 100f28b:	mov    %rbx,%rdi
 100f28e:	mov    %r14,%rsi
 100f291:	vzeroupper
 100f294:	call   10101e0 <scan_payload>
 100f299:	mov    (%r14),%rax
 100f29c:	test   $0x1,%al
 100f29e:	je     100f260 <collect+0x4c0>
 100f2a0:	mov    0x8(%r14),%rcx
 100f2a4:	cmpw   $0x0,0x30(%rcx)
 100f2a9:	je     100f260 <collect+0x4c0>
 100f2ab:	cmpl   $0x1,0x58(%rcx)
 100f2af:	je     100f260 <collect+0x4c0>
 100f2b1:	cmpl   $0x0,0x5c(%rcx)
 100f2b5:	je     100f331 <collect+0x591>
 100f2b7:	cmpb   $0x0,0x1175(%rbx)
 100f2be:	je     100f260 <collect+0x4c0>
 100f2c0:	mov    0x1158(%rbx),%rcx
 100f2c7:	cmp    0x1160(%rbx),%rcx
 100f2ce:	jne    100f35f <collect+0x5bf>
 100f2d4:	lea    (%rcx,%rcx,1),%r15
 100f2d8:	test   %rcx,%rcx
 100f2db:	cmove  %r13,%r15
 100f2df:	cmp    %rcx,%r15
 100f2e2:	setbe  %al
 100f2e5:	movabs $0x1fffffffffffffff,%rcx
 100f2ef:	cmp    %rcx,%r15
 100f2f2:	seta   %cl
 100f2f5:	or     %al,%cl
 100f2f7:	jne    100f252 <collect+0x4b2>
 100f2fd:	mov    0x1150(%rbx),%rdi
 100f304:	lea    0x0(,%r15,8),%rsi
 100f30c:	call   101ef70 <realloc@plt>
 100f311:	test   %rax,%rax
 100f314:	je     100f252 <collect+0x4b2>
 100f31a:	mov    %rax,0x1150(%rbx)
 100f321:	mov    %r15,0x1160(%rbx)
 100f328:	mov    0x1158(%rbx),%rcx
 100f32f:	jmp    100f366 <collect+0x5c6>
 100f331:	mov    (%rcx),%rcx
 100f334:	bzhi   %r12,%rax,%rsi
 100f339:	shr    $0x2,%rsi
 100f33d:	test   %rcx,%rcx
 100f340:	je     100f385 <collect+0x5e5>
 100f342:	cmp    $0x3fff0,%rcx
 100f349:	ja     100f37a <collect+0x5da>
 100f34b:	mov    $0x3fff0,%eax
 100f350:	xor    %edx,%edx
 100f352:	div    %ecx
 100f354:	cmp    %rax,%rsi
 100f357:	ja     100f260 <collect+0x4c0>
 100f35d:	jmp    100f385 <collect+0x5e5>
 100f35f:	mov    0x1150(%rbx),%rax
 100f366:	lea    0x1(%rcx),%rdx
 100f36a:	mov    %rdx,0x1158(%rbx)
 100f371:	mov    %r14,(%rax,%rcx,8)
 100f375:	jmp    100f260 <collect+0x4c0>
 100f37a:	xor    %eax,%eax
 100f37c:	cmp    %rax,%rsi
 100f37f:	ja     100f260 <collect+0x4c0>
 100f385:	imul   %rsi,%rcx
 100f389:	add    $0x1f,%rcx
 100f38d:	cmp    $0xf,%rcx
 100f391:	setae  %al
 100f394:	and    $0xfffffffffffffff0,%rcx
 100f398:	cmp    $0x40001,%rcx
 100f39f:	setae  %cl
 100f3a2:	test   %cl,%al
 100f3a4:	jne    100f260 <collect+0x4c0>
 100f3aa:	mov    0x1140(%rbx),%rcx
 100f3b1:	cmp    0x1148(%rbx),%rcx
 100f3b8:	jne    100f417 <collect+0x677>
 100f3ba:	lea    (%rcx,%rcx,1),%r15
 100f3be:	test   %rcx,%rcx
 100f3c1:	cmove  %r13,%r15
 100f3c5:	cmp    %rcx,%r15
 100f3c8:	setbe  %al
 100f3cb:	movabs $0x1fffffffffffffff,%rcx
 100f3d5:	cmp    %rcx,%r15
 100f3d8:	seta   %cl
 100f3db:	or     %al,%cl
 100f3dd:	jne    100f252 <collect+0x4b2>
 100f3e3:	mov    0x1138(%rbx),%rdi
 100f3ea:	lea    0x0(,%r15,8),%rsi
 100f3f2:	call   101ef70 <realloc@plt>
 100f3f7:	test   %rax,%rax
 100f3fa:	je     100f252 <collect+0x4b2>
 100f400:	mov    %rax,0x1138(%rbx)
 100f407:	mov    %r15,0x1148(%rbx)
 100f40e:	mov    0x1140(%rbx),%rcx
 100f415:	jmp    100f41e <collect+0x67e>
 100f417:	mov    0x1138(%rbx),%rax
 100f41e:	lea    0x1(%rcx),%rdx
 100f422:	mov    %rdx,0x1140(%rbx)
 100f429:	mov    %r14,(%rax,%rcx,8)
 100f42d:	jmp    100f260 <collect+0x4c0>
 100f432:	movb   $0x0,0x1174(%rbx)
 100f439:	cmpl   $0x0,0x4f8(%rbx)
 100f440:	mov    (%rbx),%r14
 100f443:	jne    100fa26 <collect+0xc86>
 100f449:	test   %r14,%r14
 100f44c:	je     100fad1 <collect+0xd31>
 100f452:	xor    %r15d,%r15d
 100f455:	vpbroadcastb -0xc53e(%rip),%ymm12        # 1002f20 <on_timeout.message+0x70>
 100f45e:	vmovdqa -0xc566(%rip),%ymm13        # 1002f00 <on_timeout.message+0x50>
 100f466:	vpbroadcastq -0xc66f(%rip),%ymm14        # 1002e00 <qbe_empty_registry+0x58>
 100f46f:	vpxor  %xmm15,%xmm15,%xmm15
 100f474:	xor    %r11d,%r11d
 100f477:	xor    %r13d,%r13d
 100f47a:	mov    %rbx,%rdi
 100f47d:	mov    0x14(%rsp),%r12d
 100f482:	vmovdqa %ymm14,0x40(%rsp)
 100f488:	nopl   0x0(%rax,%rax,1)
 100f490:	mov    0x20(%r14),%rax
 100f494:	cmp    $0x34,%rax
 100f498:	jb     100f500 <collect+0x760>
 100f49a:	testb  $0x1,0x470(%r14)
 100f4a2:	jne    100f5a0 <collect+0x800>
 100f4a8:	mov    (%r14),%rax
 100f4ab:	mov    %rax,(%rdi)
 100f4ae:	mov    %r15,0x20(%rsp)
 100f4b3:	mov    %r12d,%r15d
 100f4b6:	mov    %rdi,%r12
 100f4b9:	mov    %r14,%rdi
 100f4bc:	mov    %r11,%r14
 100f4bf:	vzeroupper
 100f4c2:	call   101edc0 <free@plt>
 100f4c7:	vpxor  %xmm15,%xmm15,%xmm15
 100f4cc:	vmovdqa 0x40(%rsp),%ymm14
 100f4d2:	vmovdqa -0xc5da(%rip),%ymm13        # 1002f00 <on_timeout.message+0x50>
 100f4da:	vpbroadcastb -0xc5c3(%rip),%ymm12        # 1002f20 <on_timeout.message+0x70>
 100f4e3:	mov    %r14,%r11
 100f4e6:	mov    %r12,%r14
 100f4e9:	mov    %r15d,%r12d
 100f4ec:	mov    0x20(%rsp),%r15
 100f4f1:	jmp    100f99e <collect+0xbfe>
 100f4f6:	cs nopw 0x0(%rax,%rax,1)
 100f500:	test   %r12d,%r12d
 100f503:	mov    %rax,0x38(%rsp)
 100f508:	jne    100f515 <collect+0x775>
 100f50a:	cmpb   $0x0,0x40(%r14)
 100f50f:	je     100f6ce <collect+0x92e>
 100f515:	mov    %r13,0x18(%rsp)
 100f51a:	lea    0x470(%r14),%r13
 100f521:	mov    0x8(%r14),%rcx
 100f525:	mov    0x18(%r14),%r9
 100f529:	imul   %rcx,%r9
 100f52d:	lea    (%r14,%r9,1),%r8
 100f531:	add    $0x470,%r8
 100f538:	cmp    $0x20,%rax
 100f53c:	jb     100f5b0 <collect+0x810>
 100f53e:	test   %r9,%r9
 100f541:	je     100f6c3 <collect+0x923>
 100f547:	mov    %r13,%r9
 100f54a:	xor    %edx,%edx
 100f54c:	xor    %r10d,%r10d
 100f54f:	xor    %esi,%esi
 100f551:	jmp    100f579 <collect+0x7d9>
 100f553:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f560:	mov    %r10,%r13
 100f563:	mov    %r13,%r10
 100f566:	lea    (%r9,%rcx,1),%r13
 100f56a:	inc    %rdx
 100f56d:	add    %rcx,%r9
 100f570:	cmp    %r8,%r9
 100f573:	jae    100f68b <collect+0x8eb>
 100f579:	testb  $0x1,(%r9)
 100f57d:	je     100f56d <collect+0x7cd>
 100f57f:	cmp    %r9,%r13
 100f582:	jae    100f560 <collect+0x7c0>
 100f584:	mov    %r9,0x0(%r13)
 100f588:	movq   $0x0,0x8(%r13)
 100f590:	test   %r10,%r10
 100f593:	je     100f59b <collect+0x7fb>
 100f595:	mov    %r13,0x8(%r10)
 100f599:	jmp    100f563 <collect+0x7c3>
 100f59b:	mov    %r13,%rsi
 100f59e:	jmp    100f563 <collect+0x7c3>
 100f5a0:	add    0x8(%r14),%r15
 100f5a4:	inc    %r11
 100f5a7:	jmp    100f99e <collect+0xbfe>
 100f5ac:	nopl   0x0(%rax)
 100f5b0:	mov    %rdi,0x30(%rsp)
 100f5b5:	mov    %r11,0x28(%rsp)
 100f5ba:	mov    %r15,0x20(%rsp)
 100f5bf:	add    $0x470,%r9
 100f5c6:	shr    $0x4,%r9
 100f5ca:	lea    0x3f(%r9),%r10
 100f5ce:	shr    $0x6,%r10
 100f5d2:	mov    $0x1,%r12d
 100f5d8:	xor    %esi,%esi
 100f5da:	xor    %eax,%eax
 100f5dc:	xor    %edx,%edx
 100f5de:	jmp    100f5e8 <collect+0x848>
 100f5e0:	inc    %r12
 100f5e3:	cmp    %r10,%r12
 100f5e6:	je     100f660 <collect+0x8c0>
 100f5e8:	mov    0x48(%r14,%r12,8),%r15
 100f5ed:	test   %r15,%r15
 100f5f0:	je     100f5e0 <collect+0x840>
 100f5f2:	mov    %r12,%r11
 100f5f5:	shl    $0x6,%r11
 100f5f9:	jmp    100f616 <collect+0x876>
 100f5fb:	nopl   0x0(%rax,%rax,1)
 100f600:	mov    %rax,%r13
 100f603:	add    %rcx,%rdi
 100f606:	inc    %rdx
 100f609:	mov    %r13,%rax
 100f60c:	mov    %rdi,%r13
 100f60f:	blsr   %r15,%r15
 100f614:	je     100f5e0 <collect+0x840>
 100f616:	tzcnt  %r15,%rdi
 100f61b:	or     %r11,%rdi
 100f61e:	cmp    $0x47,%rdi
 100f622:	jb     100f60f <collect+0x86f>
 100f624:	cmp    %r9,%rdi
 100f627:	jae    100f60f <collect+0x86f>
 100f629:	shl    $0x4,%rdi
 100f62d:	add    %r14,%rdi
 100f630:	cmp    %rdi,%r13
 100f633:	jae    100f600 <collect+0x860>
 100f635:	mov    %rdi,0x0(%r13)
 100f639:	movq   $0x0,0x8(%r13)
 100f641:	test   %rax,%rax
 100f644:	je     100f64c <collect+0x8ac>
 100f646:	mov    %r13,0x8(%rax)
 100f64a:	jmp    100f603 <collect+0x863>
 100f64c:	mov    %r13,%rsi
 100f64f:	jmp    100f603 <collect+0x863>
 100f651:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f660:	cmp    %r8,%r13
 100f663:	jae    100f6b2 <collect+0x912>
 100f665:	mov    %r8,0x0(%r13)
 100f669:	movq   $0x0,0x8(%r13)
 100f671:	test   %rax,%rax
 100f674:	mov    0x14(%rsp),%r12d
 100f679:	mov    0x20(%rsp),%r15
 100f67e:	mov    0x28(%rsp),%r11
 100f683:	je     100f6e0 <collect+0x940>
 100f685:	mov    %r13,0x8(%rax)
 100f689:	jmp    100f6f0 <collect+0x950>
 100f68b:	cmp    %r8,%r13
 100f68e:	jae    100f87b <collect+0xadb>
 100f694:	mov    %r8,0x0(%r13)
 100f698:	movq   $0x0,0x8(%r13)
 100f6a0:	test   %r10,%r10
 100f6a3:	je     100f878 <collect+0xad8>
 100f6a9:	mov    %r13,0x8(%r10)
 100f6ad:	jmp    100f87b <collect+0xadb>
 100f6b2:	mov    0x14(%rsp),%r12d
 100f6b7:	mov    0x20(%rsp),%r15
 100f6bc:	mov    0x28(%rsp),%r11
 100f6c1:	jmp    100f6f0 <collect+0x950>
 100f6c3:	xor    %esi,%esi
 100f6c5:	xor    %eax,%eax
 100f6c7:	xor    %edx,%edx
 100f6c9:	jmp    100f87d <collect+0xadd>
 100f6ce:	mov    0x30(%r14),%rdx
 100f6d2:	test   %rdx,%rdx
 100f6d5:	jne    100f963 <collect+0xbc3>
 100f6db:	jmp    100f8a2 <collect+0xb02>
 100f6e0:	mov    %r13,%rsi
 100f6e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f6f0:	vpxor  %xmm0,%xmm0,%xmm0
 100f6f4:	mov    $0xfffffffffffffe00,%rdi
 100f6fb:	vpxor  %xmm1,%xmm1,%xmm1
 100f6ff:	vpxor  %xmm2,%xmm2,%xmm2
 100f703:	vpxor  %xmm3,%xmm3,%xmm3
 100f707:	mov    0x18(%rsp),%r13
 100f70c:	nopl   0x0(%rax)
 100f710:	vmovdqu 0x248(%r14,%rdi,1),%ymm5
 100f71a:	vmovdqu 0x268(%r14,%rdi,1),%ymm6
 100f724:	vmovdqu 0x288(%r14,%rdi,1),%ymm7
 100f72e:	vpand  0x448(%r14,%rdi,1),%ymm5,%ymm8
 100f738:	vpand  0x468(%r14,%rdi,1),%ymm6,%ymm9
 100f742:	vpand  0x488(%r14,%rdi,1),%ymm7,%ymm10
 100f74c:	vmovdqu 0x2a8(%r14,%rdi,1),%ymm11
 100f756:	vpand  0x4a8(%r14,%rdi,1),%ymm11,%ymm4
 100f760:	vmovdqu %ymm8,0x448(%r14,%rdi,1)
 100f76a:	vmovdqu %ymm9,0x468(%r14,%rdi,1)
 100f774:	vmovdqu %ymm10,0x488(%r14,%rdi,1)
 100f77e:	vmovdqu %ymm4,0x4a8(%r14,%rdi,1)
 100f788:	vpxor  %ymm5,%ymm8,%ymm5
 100f78c:	vpxor  %ymm6,%ymm9,%ymm6
 100f790:	vpxor  %ymm7,%ymm10,%ymm7
 100f794:	vpxor  %ymm4,%ymm11,%ymm11
 100f798:	vmovdqu %ymm5,0x248(%r14,%rdi,1)
 100f7a2:	vmovdqu %ymm6,0x268(%r14,%rdi,1)
 100f7ac:	vmovdqu %ymm7,0x288(%r14,%rdi,1)
 100f7b6:	vmovdqu %ymm11,0x2a8(%r14,%rdi,1)
 100f7c0:	vpand  %ymm12,%ymm8,%ymm5
 100f7c5:	vpshufb %ymm5,%ymm13,%ymm5
 100f7ca:	vgf2p8affineqb $0x0,%ymm14,%ymm8,%ymm6
 100f7d0:	vpshufb %ymm6,%ymm13,%ymm6
 100f7d5:	vpaddb %ymm5,%ymm6,%ymm5
 100f7d9:	vpsadbw %ymm5,%ymm15,%ymm5
 100f7dd:	vpaddq %ymm0,%ymm5,%ymm0
 100f7e1:	vpand  %ymm12,%ymm9,%ymm5
 100f7e6:	vpshufb %ymm5,%ymm13,%ymm5
 100f7eb:	vgf2p8affineqb $0x0,%ymm14,%ymm9,%ymm6
 100f7f1:	vpshufb %ymm6,%ymm13,%ymm6
 100f7f6:	vpaddb %ymm5,%ymm6,%ymm5
 100f7fa:	vpsadbw %ymm5,%ymm15,%ymm5
 100f7fe:	vpaddq %ymm1,%ymm5,%ymm1
 100f802:	vpand  %ymm12,%ymm10,%ymm5
 100f807:	vpshufb %ymm5,%ymm13,%ymm5
 100f80c:	vgf2p8affineqb $0x0,%ymm14,%ymm10,%ymm6
 100f812:	vpshufb %ymm6,%ymm13,%ymm6
 100f817:	vpaddb %ymm5,%ymm6,%ymm5
 100f81b:	vpsadbw %ymm5,%ymm15,%ymm5
 100f81f:	vpaddq %ymm2,%ymm5,%ymm2
 100f823:	vpand  %ymm4,%ymm12,%ymm5
 100f827:	vpshufb %ymm5,%ymm13,%ymm5
 100f82c:	vgf2p8affineqb $0x0,%ymm14,%ymm4,%ymm4
 100f832:	vpshufb %ymm4,%ymm13,%ymm4
 100f837:	vpaddb %ymm5,%ymm4,%ymm4
 100f83b:	vpsadbw %ymm4,%ymm15,%ymm4
 100f83f:	vpaddq %ymm3,%ymm4,%ymm3
 100f843:	sub    $0xffffffffffffff80,%rdi
 100f847:	jne    100f710 <collect+0x970>
 100f84d:	vpaddq %ymm0,%ymm1,%ymm0
 100f851:	vpaddq %ymm0,%ymm2,%ymm0
 100f855:	vpaddq %ymm0,%ymm3,%ymm0
 100f859:	vextracti128 $0x1,%ymm0,%xmm1
 100f85f:	vpaddq %xmm1,%xmm0,%xmm0
 100f863:	vpshufd $0xee,%xmm0,%xmm1
 100f868:	vpaddq %xmm1,%xmm0,%xmm0
 100f86c:	vmovq  %xmm0,%rax
 100f871:	mov    0x30(%rsp),%rdi
 100f876:	jmp    100f882 <collect+0xae2>
 100f878:	mov    %r13,%rsi
 100f87b:	xor    %eax,%eax
 100f87d:	mov    0x18(%rsp),%r13
 100f882:	mov    %rsi,0x28(%r14)
 100f886:	mov    %rdx,0x30(%r14)
 100f88a:	test   %rax,%rax
 100f88d:	setne  0x40(%r14)
 100f892:	imul   %rax,%rcx
 100f896:	add    %rcx,%r13
 100f899:	test   %rdx,%rdx
 100f89c:	jne    100f963 <collect+0xbc3>
 100f8a2:	mov    0x38(%rsp),%rax
 100f8a7:	cmp    $0x1f,%rax
 100f8ab:	ja     100f961 <collect+0xbc1>
 100f8b1:	imul   $0x38,%rax,%rax
 100f8b5:	lea    0x5d8(%rbx),%rcx
 100f8bc:	cmp    %r14,(%rcx,%rax,1)
 100f8c0:	je     100f961 <collect+0xbc1>
 100f8c6:	mov    0x11d8(%rbx),%rcx
 100f8cd:	cmp    0x11e0(%rbx),%rcx
 100f8d4:	jne    100f9b5 <collect+0xc15>
 100f8da:	mov    %rdi,0x30(%rsp)
 100f8df:	mov    %r11,0x28(%rsp)
 100f8e4:	mov    %r13,0x18(%rsp)
 100f8e9:	mov    %r15,%r13
 100f8ec:	lea    (%rcx,%rcx,1),%r15
 100f8f0:	test   %rcx,%rcx
 100f8f3:	mov    $0x40,%eax
 100f8f8:	cmove  %rax,%r15
 100f8fc:	mov    0x11d0(%rbx),%rdi
 100f903:	lea    0x0(,%r15,8),%rsi
 100f90b:	vzeroupper
 100f90e:	call   101ef70 <realloc@plt>
 100f913:	test   %rax,%rax
 100f916:	je     100f9d3 <collect+0xc33>
 100f91c:	mov    %rax,0x11d0(%rbx)
 100f923:	mov    %r15,0x11e0(%rbx)
 100f92a:	mov    0x11d8(%rbx),%rcx
 100f931:	mov    %r13,%r15
 100f934:	mov    0x18(%rsp),%r13
 100f939:	mov    0x28(%rsp),%r11
 100f93e:	vpbroadcastb -0xca27(%rip),%ymm12        # 1002f20 <on_timeout.message+0x70>
 100f947:	vmovdqa -0xca4f(%rip),%ymm13        # 1002f00 <on_timeout.message+0x50>
 100f94f:	vmovdqa 0x40(%rsp),%ymm14
 100f955:	vpxor  %xmm15,%xmm15,%xmm15
 100f95a:	mov    0x30(%rsp),%rdi
 100f95f:	jmp    100f9bc <collect+0xc1c>
 100f961:	xor    %edx,%edx
 100f963:	mov    0x8(%r14),%rax
 100f967:	imul   %rdx,%rax
 100f96b:	add    %rax,%r15
 100f96e:	add    %rdx,%r11
 100f971:	movq   $0x0,0x38(%r14)
 100f979:	cmpq   $0x0,0x28(%r14)
 100f97e:	setne  0x41(%r14)
 100f983:	je     100f99e <collect+0xbfe>
 100f985:	imul   $0x38,0x20(%r14),%rax
 100f98a:	mov    0x5e8(%rbx,%rax,1),%rcx
 100f992:	mov    %rcx,0x38(%r14)
 100f996:	mov    %r14,0x5e8(%rbx,%rax,1)
 100f99e:	mov    (%r14),%rax
 100f9a1:	mov    %r14,%rdi
 100f9a4:	mov    %rax,%r14
 100f9a7:	test   %rax,%rax
 100f9aa:	jne    100f490 <collect+0x6f0>
 100f9b0:	jmp    100fadf <collect+0xd3f>
 100f9b5:	mov    0x11d0(%rbx),%rax
 100f9bc:	lea    0x1(%rcx),%rdx
 100f9c0:	mov    %rdx,0x11d8(%rbx)
 100f9c7:	mov    %r14,(%rax,%rcx,8)
 100f9cb:	mov    (%r14),%rax
 100f9ce:	mov    %rax,(%rdi)
 100f9d1:	jmp    100f9a4 <collect+0xc04>
 100f9d3:	mov    0x30(%r14),%rdx
 100f9d7:	mov    %r13,%r15
 100f9da:	mov    0x18(%rsp),%r13
 100f9df:	mov    0x28(%rsp),%r11
 100f9e4:	vpbroadcastb -0xcacd(%rip),%ymm12        # 1002f20 <on_timeout.message+0x70>
 100f9ed:	vmovdqa -0xcaf5(%rip),%ymm13        # 1002f00 <on_timeout.message+0x50>
 100f9f5:	vmovdqa 0x40(%rsp),%ymm14
 100f9fb:	vpxor  %xmm15,%xmm15,%xmm15
 100fa00:	jmp    100f963 <collect+0xbc3>
 100fa05:	data16 cs nopw 0x0(%rax,%rax,1)
 100fa10:	lea    0x48(%r14),%rdi
 100fa14:	mov    $0x400,%edx
 100fa19:	xor    %esi,%esi
 100fa1b:	vzeroupper
 100fa1e:	call   101e4a0 <compiler_rt.fastMemset>
 100fa23:	mov    (%r14),%r14
 100fa26:	test   %r14,%r14
 100fa29:	je     100fab7 <collect+0xd17>
 100fa2f:	cmpq   $0x20,0x20(%r14)
 100fa34:	jb     100fa10 <collect+0xc70>
 100fa36:	mov    0x18(%r14),%rdx
 100fa3a:	test   %rdx,%rdx
 100fa3d:	je     100faab <collect+0xd0b>
 100fa3f:	mov    0x8(%r14),%rax
 100fa43:	mov    %edx,%ecx
 100fa45:	and    $0x3,%ecx
 100fa48:	cmp    $0x4,%rdx
 100fa4c:	jae    100fa52 <collect+0xcb2>
 100fa4e:	xor    %esi,%esi
 100fa50:	jmp    100fa91 <collect+0xcf1>
 100fa52:	lea    0x470(%r14),%rdi
 100fa59:	and    $0xfffffffffffffffc,%rdx
 100fa5d:	lea    (%rax,%rax,2),%r8
 100fa61:	lea    0x0(,%rax,4),%r9
 100fa69:	xor    %esi,%esi
 100fa6b:	nopl   0x0(%rax,%rax,1)
 100fa70:	andb   $0xfe,(%rdi)
 100fa73:	andb   $0xfe,(%rdi,%rax,1)
 100fa77:	andb   $0xfe,(%rdi,%rax,2)
 100fa7b:	andb   $0xfe,(%rdi,%r8,1)
 100fa80:	add    $0x4,%rsi
 100fa84:	add    %r9,%rdi
 100fa87:	cmp    %rsi,%rdx
 100fa8a:	jne    100fa70 <collect+0xcd0>
 100fa8c:	test   %rcx,%rcx
 100fa8f:	je     100faab <collect+0xd0b>
 100fa91:	imul   %rax,%rsi
 100fa95:	lea    (%r14,%rsi,1),%rdx
 100fa99:	add    $0x470,%rdx
 100faa0:	andb   $0xfe,(%rdx)
 100faa3:	add    %rax,%rdx
 100faa6:	dec    %rcx
 100faa9:	jne    100faa0 <collect+0xd00>
 100faab:	mov    (%r14),%r14
 100faae:	test   %r14,%r14
 100fab1:	jne    100fa2f <collect+0xc8f>
 100fab7:	movq   $0x0,0x4e8(%rbx)
 100fac2:	movl   $0x1,0x1170(%rbx)
 100facc:	jmp    100fbe3 <collect+0xe43>
 100fad1:	xor    %r13d,%r13d
 100fad4:	xor    %r11d,%r11d
 100fad7:	xor    %r15d,%r15d
 100fada:	mov    0x14(%rsp),%r12d
 100fadf:	mov    0xb0(%rbx),%rax
 100fae6:	add    %r15,%rax
 100fae9:	mov    %rax,0x18(%rbx)
 100faed:	mov    0x40(%rbx),%rax
 100faf1:	add    %r11,%rax
 100faf4:	sub    0x1198(%rbx),%rax
 100fafb:	mov    %rax,0x40(%rbx)
 100faff:	mov    %r11,0x1198(%rbx)
 100fb06:	mov    %r13,0x1190(%rbx)
 100fb0d:	mov    0x1158(%rbx),%rdx
 100fb14:	test   %rdx,%rdx
 100fb17:	je     100fb90 <collect+0xdf0>
 100fb19:	mov    0x1150(%rbx),%rcx
 100fb20:	mov    %edx,%eax
 100fb22:	and    $0x3,%eax
 100fb25:	cmp    $0x4,%rdx
 100fb29:	jae    100fb2f <collect+0xd8f>
 100fb2b:	xor    %esi,%esi
 100fb2d:	jmp    100fb71 <collect+0xdd1>
 100fb2f:	and    $0xfffffffffffffffc,%rdx
 100fb33:	xor    %esi,%esi
 100fb35:	data16 cs nopw 0x0(%rax,%rax,1)
 100fb40:	mov    (%rcx,%rsi,8),%rdi
 100fb44:	andq   $0xfffffffffffffffe,(%rdi)
 100fb48:	mov    0x8(%rcx,%rsi,8),%rdi
 100fb4d:	andq   $0xfffffffffffffffe,(%rdi)
 100fb51:	mov    0x10(%rcx,%rsi,8),%rdi
 100fb56:	andq   $0xfffffffffffffffe,(%rdi)
 100fb5a:	mov    0x18(%rcx,%rsi,8),%rdi
 100fb5f:	andq   $0xfffffffffffffffe,(%rdi)
 100fb63:	add    $0x4,%rsi
 100fb67:	cmp    %rsi,%rdx
 100fb6a:	jne    100fb40 <collect+0xda0>
 100fb6c:	test   %rax,%rax
 100fb6f:	je     100fb90 <collect+0xdf0>
 100fb71:	lea    (%rcx,%rsi,8),%rcx
 100fb75:	xor    %edx,%edx
 100fb77:	nopw   0x0(%rax,%rax,1)
 100fb80:	mov    (%rcx,%rdx,8),%rsi
 100fb84:	andq   $0xfffffffffffffffe,(%rsi)
 100fb88:	inc    %rdx
 100fb8b:	cmp    %rdx,%rax
 100fb8e:	jne    100fb80 <collect+0xde0>
 100fb90:	mov    %r15,%rax
 100fb93:	shr    $1,%rax
 100fb96:	cmp    $0x400001,%rax
 100fb9c:	mov    $0x400000,%ecx
 100fba1:	cmovae %rax,%rcx
 100fba5:	add    %r15,%rcx
 100fba8:	mov    $0xffffffffffffffff,%rax
 100fbaf:	cmovb  %rax,%rcx
 100fbb3:	mov    %r15,%rdx
 100fbb6:	sub    %r13,%rdx
 100fbb9:	mov    %rcx,0x60(%rbx)
 100fbbd:	mov    %rdx,0x1188(%rbx)
 100fbc4:	test   %r12d,%r12d
 100fbc7:	je     100fbe3 <collect+0xe43>
 100fbc9:	test   %r15,%r15
 100fbcc:	js     100fbdc <collect+0xe3c>
 100fbce:	add    %r15,%r15
 100fbd1:	add    $0x400000,%r15
 100fbd8:	cmovae %r15,%rax
 100fbdc:	mov    %rax,0x1168(%rbx)
 100fbe3:	lea    -0x28(%rbp),%rsp
 100fbe7:	pop    %rbx
 100fbe8:	pop    %r12
 100fbea:	pop    %r13
 100fbec:	pop    %r14
 100fbee:	pop    %r15
 100fbf0:	pop    %rbp
 100fbf1:	vzeroupper
 100fbf4:	ret
 100fbf5:	int3
 100fbf6:	int3
 100fbf7:	int3
 100fbf8:	int3
 100fbf9:	int3
 100fbfa:	int3
 100fbfb:	int3
 100fbfc:	int3
 100fbfd:	int3
 100fbfe:	int3
 100fbff:	int3

000000000100fc00 <myl_native_heap_alloc>:
 100fc00:	push   %rbp
 100fc01:	mov    %rsp,%rbp
 100fc04:	cmpq   $0x0,0x1608(%rdi)
 100fc0c:	je     100fc17 <myl_native_heap_alloc+0x17>
 100fc0e:	mov    0x70(%rdi),%ecx
 100fc11:	pop    %rbp
 100fc12:	jmp    101bc50 <myl_rc_storage_alloc>
 100fc17:	xor    %eax,%eax
 100fc19:	pop    %rbp
 100fc1a:	ret
 100fc1b:	int3
 100fc1c:	int3
 100fc1d:	int3
 100fc1e:	int3
 100fc1f:	int3

000000000100fc20 <myl_native_heap_destroy>:
 100fc20:	push   %rbp
 100fc21:	mov    %rsp,%rbp
 100fc24:	push   %r14
 100fc26:	push   %rbx
 100fc27:	mov    %rdi,%rbx
 100fc2a:	call   10113b0 <myl_native_arena_destroy>
 100fc2f:	test   %rbx,%rbx
 100fc32:	je     100fc70 <myl_native_heap_destroy+0x50>
 100fc34:	cmpq   $0x0,0x1608(%rbx)
 100fc3c:	je     100fc70 <myl_native_heap_destroy+0x50>
 100fc3e:	mov    $0x1a,%r14d
 100fc44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100fc50:	mov    (%rbx,%r14,8),%rsi
 100fc54:	mov    %rbx,%rdi
 100fc57:	call   1012ac0 <myl_rc_owner_release>
 100fc5c:	inc    %r14
 100fc5f:	cmp    $0x9a,%r14
 100fc66:	jne    100fc50 <myl_native_heap_destroy+0x30>
 100fc68:	mov    %rbx,%rdi
 100fc6b:	call   1012690 <myl_rc_heap_destroy>
 100fc70:	mov    (%rbx),%rdi
 100fc73:	test   %rdi,%rdi
 100fc76:	jne    100fd1c <myl_native_heap_destroy+0xfc>
 100fc7c:	cmpq   $0x0,0x11c0(%rbx)
 100fc84:	je     100fcb1 <myl_native_heap_destroy+0x91>
 100fc86:	xor    %r14d,%r14d
 100fc89:	nopl   0x0(%rax)
 100fc90:	mov    0x11b8(%rbx),%rax
 100fc97:	mov    (%rax,%r14,8),%rdi
 100fc9b:	mov    $0x200000,%esi
 100fca0:	call   101ef30 <munmap@plt>
 100fca5:	inc    %r14
 100fca8:	cmp    0x11c0(%rbx),%r14
 100fcaf:	jb     100fc90 <myl_native_heap_destroy+0x70>
 100fcb1:	mov    0x11f8(%rbx),%rdi
 100fcb8:	call   101edc0 <free@plt>
 100fcbd:	mov    0x11b8(%rbx),%rdi
 100fcc4:	call   101edc0 <free@plt>
 100fcc9:	mov    0x11d0(%rbx),%rdi
 100fcd0:	call   101edc0 <free@plt>
 100fcd5:	mov    0x8(%rbx),%rdi
 100fcd9:	call   101edc0 <free@plt>
 100fcde:	mov    0x1138(%rbx),%rdi
 100fce5:	call   101edc0 <free@plt>
 100fcea:	mov    0x1150(%rbx),%rdi
 100fcf1:	call   101edc0 <free@plt>
 100fcf6:	mov    $0x1718,%edx
 100fcfb:	mov    %rbx,%rdi
 100fcfe:	xor    %esi,%esi
 100fd00:	pop    %rbx
 100fd01:	pop    %r14
 100fd03:	pop    %rbp
 100fd04:	jmp    101e4a0 <compiler_rt.fastMemset>
 100fd09:	nopl   0x0(%rax)
 100fd10:	mov    %rax,%rdi
 100fd13:	test   %rax,%rax
 100fd16:	je     100fc7c <myl_native_heap_destroy+0x5c>
 100fd1c:	mov    (%rdi),%rax
 100fd1f:	mov    %rax,(%rbx)
 100fd22:	cmpq   $0x20,0x20(%rdi)
 100fd27:	jb     100fd10 <myl_native_heap_destroy+0xf0>
 100fd29:	call   101edc0 <free@plt>
 100fd2e:	mov    (%rbx),%rax
 100fd31:	jmp    100fd10 <myl_native_heap_destroy+0xf0>
 100fd33:	int3
 100fd34:	int3
 100fd35:	int3
 100fd36:	int3
 100fd37:	int3
 100fd38:	int3
 100fd39:	int3
 100fd3a:	int3
 100fd3b:	int3
 100fd3c:	int3
 100fd3d:	int3
 100fd3e:	int3
 100fd3f:	int3

000000000100fd40 <trace>:
 100fd40:	push   %rbp
 100fd41:	mov    %rsp,%rbp
 100fd44:	push   %r15
 100fd46:	push   %r14
 100fd48:	push   %r13
 100fd4a:	push   %r12
 100fd4c:	push   %rbx
 100fd4d:	sub    $0x88,%rsp
 100fd54:	mov    0x58(%rsi),%eax
 100fd57:	cmp    $0x1,%eax
 100fd5a:	jne    100fd6e <trace+0x2e>
 100fd5c:	add    $0x88,%rsp
 100fd63:	pop    %rbx
 100fd64:	pop    %r12
 100fd66:	pop    %r13
 100fd68:	pop    %r14
 100fd6a:	pop    %r15
 100fd6c:	pop    %rbp
 100fd6d:	ret
 100fd6e:	mov    %rdx,%rbx
 100fd71:	mov    %rsi,%r15
 100fd74:	mov    %rdi,%r14
 100fd77:	movzwl 0x30(%rsi),%ecx
 100fd7b:	cmp    $0x6,%ecx
 100fd7e:	ja     100fda6 <trace+0x66>
 100fd80:	mov    $0x62,%edx
 100fd85:	bt     %ecx,%edx
 100fd88:	jae    100fda6 <trace+0x66>
 100fd8a:	mov    (%rbx),%rsi
 100fd8d:	mov    %r14,%rdi
 100fd90:	add    $0x88,%rsp
 100fd97:	pop    %rbx
 100fd98:	pop    %r12
 100fd9a:	pop    %r13
 100fd9c:	pop    %r14
 100fd9e:	pop    %r15
 100fda0:	pop    %rbp
 100fda1:	jmp    100ff90 <mark>
 100fda6:	mov    0x60(%r15),%r12
 100fdaa:	test   %r12,%r12
 100fdad:	je     100fe54 <trace+0x114>
 100fdb3:	cmpl   $0x0,0x68(%r14)
 100fdb8:	je     100feb6 <trace+0x176>
 100fdbe:	lea    -0xb0(%rbp),%rax
 100fdc5:	mov    %rax,-0x48(%rbp)
 100fdc9:	movq   $0x8,-0x40(%rbp)
 100fdd1:	movq   $0x0,-0x38(%rbp)
 100fdd9:	lea    -0x48(%rbp),%rdi
 100fddd:	movabs $0xffffffff00000000,%rcx
 100fde7:	mov    %r15,%rsi
 100fdea:	xor    %edx,%edx
 100fdec:	xor    %r8d,%r8d
 100fdef:	call   100ebc0 <flatten>
 100fdf4:	test   %eax,%eax
 100fdf6:	je     100fe2f <trace+0xef>
 100fdf8:	mov    -0x38(%rbp),%r13
 100fdfc:	cmp    0x68(%r15),%r13
 100fe00:	jne    100fe2f <trace+0xef>
 100fe02:	test   %r13,%r13
 100fe05:	je     100fd5c <trace+0x1c>
 100fe0b:	mov    0x60(%r15),%rsi
 100fe0f:	lea    0x0(,%r13,4),%rax
 100fe17:	lea    (%rax,%rax,2),%rdx
 100fe1b:	lea    -0xb0(%rbp),%rdi
 100fe22:	call   101e470 <bcmp>
 100fe27:	test   %eax,%eax
 100fe29:	je     100fec3 <trace+0x183>
 100fe2f:	mov    0x19532(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 100fe36:	mov    (%rax),%rcx
 100fe39:	lea    -0xdea4(%rip),%rdi        # 1001f9c <__abi_tag+0x1ca0>
 100fe40:	mov    $0x43,%esi
 100fe45:	mov    $0x1,%edx
 100fe4a:	call   101ed90 <fwrite@plt>
 100fe4f:	call   101efe0 <abort@plt>
 100fe54:	cmp    $0x2,%ecx
 100fe57:	je     100ff03 <trace+0x1c3>
 100fe5d:	cmp    $0x4,%ecx
 100fe60:	je     100ff03 <trace+0x1c3>
 100fe66:	cmp    $0x3,%ecx
 100fe69:	jne    100fd5c <trace+0x1c>
 100fe6f:	cmpq   $0x0,0x20(%r15)
 100fe74:	je     100fd5c <trace+0x1c>
 100fe7a:	lea    0x10(%r15),%rcx
 100fe7e:	lea    0x48(%r15),%rdx
 100fe82:	cmp    $0x2,%eax
 100fe85:	cmove  %rdx,%rcx
 100fe89:	mov    (%rcx),%r12
 100fe8c:	xor    %r13d,%r13d
 100fe8f:	nop
 100fe90:	mov    0x8(%r12),%rsi
 100fe95:	mov    0x28(%r15),%rdx
 100fe99:	imul   %r13,%rdx
 100fe9d:	add    %rbx,%rdx
 100fea0:	mov    %r14,%rdi
 100fea3:	call   100fd40 <trace>
 100fea8:	inc    %r13
 100feab:	cmp    0x20(%r15),%r13
 100feaf:	jb     100fe90 <trace+0x150>
 100feb1:	jmp    100fd5c <trace+0x1c>
 100feb6:	mov    0x68(%r15),%r13
 100feba:	test   %r13,%r13
 100febd:	je     100fd5c <trace+0x1c>
 100fec3:	add    $0x8,%r12
 100fec7:	mov    $0xffffffff,%r15d
 100fecd:	jmp    100feee <trace+0x1ae>
 100fecf:	nop
 100fed0:	mov    -0x8(%r12),%eax
 100fed5:	mov    (%rbx,%rax,1),%rsi
 100fed9:	mov    %r14,%rdi
 100fedc:	call   100ff90 <mark>
 100fee1:	add    $0xc,%r12
 100fee5:	dec    %r13
 100fee8:	je     100fd5c <trace+0x1c>
 100feee:	mov    -0x4(%r12),%eax
 100fef3:	cmp    %r15,%rax
 100fef6:	je     100fed0 <trace+0x190>
 100fef8:	mov    (%rbx,%rax,1),%eax
 100fefb:	cmp    (%r12),%eax
 100feff:	je     100fed0 <trace+0x190>
 100ff01:	jmp    100fee1 <trace+0x1a1>
 100ff03:	lea    0x10(%r15),%rdx
 100ff07:	lea    0x48(%r15),%rsi
 100ff0b:	lea    0x18(%r15),%rdi
 100ff0f:	lea    0x50(%r15),%r8
 100ff13:	cmp    $0x2,%eax
 100ff16:	cmove  %rsi,%rdx
 100ff1a:	cmovne %rdi,%r8
 100ff1e:	mov    (%r8),%r12
 100ff21:	movl   $0x0,-0x2c(%rbp)
 100ff28:	cmp    $0x4,%ecx
 100ff2b:	jne    100ff32 <trace+0x1f2>
 100ff2d:	mov    (%rbx),%eax
 100ff2f:	mov    %eax,-0x2c(%rbp)
 100ff32:	test   %r12,%r12
 100ff35:	je     100fd5c <trace+0x1c>
 100ff3b:	mov    (%rdx),%r13
 100ff3e:	add    $0x10,%r13
 100ff42:	jmp    100ff70 <trace+0x230>
 100ff44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100ff50:	mov    -0x8(%r13),%rsi
 100ff54:	mov    -0x10(%r13),%rdx
 100ff58:	add    %rbx,%rdx
 100ff5b:	mov    %r14,%rdi
 100ff5e:	call   100fd40 <trace>
 100ff63:	add    $0x18,%r13
 100ff67:	dec    %r12
 100ff6a:	je     100fd5c <trace+0x1c>
 100ff70:	cmpw   $0x2,0x30(%r15)
 100ff76:	je     100ff50 <trace+0x210>
 100ff78:	mov    -0x2c(%rbp),%eax
 100ff7b:	cmp    0x0(%r13),%eax
 100ff7f:	je     100ff50 <trace+0x210>
 100ff81:	jmp    100ff63 <trace+0x223>
 100ff83:	int3
 100ff84:	int3
 100ff85:	int3
 100ff86:	int3
 100ff87:	int3
 100ff88:	int3
 100ff89:	int3
 100ff8a:	int3
 100ff8b:	int3
 100ff8c:	int3
 100ff8d:	int3
 100ff8e:	int3
 100ff8f:	int3

000000000100ff90 <mark>:
 100ff90:	test   %rsi,%rsi
 100ff93:	je     10101dc <mark+0x24c>
 100ff99:	push   %rbp
 100ff9a:	mov    %rsp,%rbp
 100ff9d:	push   %r15
 100ff9f:	push   %r14
 100ffa1:	push   %r13
 100ffa3:	push   %r12
 100ffa5:	push   %rbx
 100ffa6:	push   %rax
 100ffa7:	add    $0xfffffffffffffff0,%rsi
 100ffab:	mov    %rsi,%rax
 100ffae:	shr    $0x15,%rax
 100ffb2:	mov    %eax,%ecx
 100ffb4:	and    $0x7f,%ecx
 100ffb7:	mov    %ecx,%edx
 100ffb9:	cmp    %rax,0x1208(%rdi,%rdx,8)
 100ffc1:	je     1010011 <mark+0x81>
 100ffc3:	mov    0x1200(%rdi),%rdx
 100ffca:	test   %rdx,%rdx
 100ffcd:	je     101005e <mark+0xce>
 100ffd3:	mov    0x11f8(%rdi),%r8
 100ffda:	dec    %rdx
 100ffdd:	movabs $0x9e3779b97f4a7c15,%r9
 100ffe7:	imul   %rax,%r9
 100ffeb:	shr    $0x20,%r9
 100ffef:	nop
 100fff0:	and    %rdx,%r9
 100fff3:	mov    (%r8,%r9,8),%r10
 100fff7:	test   %r10,%r10
 100fffa:	je     1010004 <mark+0x74>
 100fffc:	inc    %r9
 100ffff:	cmp    %rax,%r10
 1010002:	jne    100fff0 <mark+0x60>
 1010004:	cmp    %rax,%r10
 1010007:	jne    101005e <mark+0xce>
 1010009:	mov    %rax,0x1208(%rdi,%rcx,8)
 1010011:	mov    %rsi,%rbx
 1010014:	and    $0xffffffffffff0000,%rbx
 101001b:	mov    %esi,%eax
 101001d:	shr    $0x4,%eax
 1010020:	mov    %esi,%r14d
 1010023:	shr    $0xa,%r14d
 1010027:	and    $0x3f,%r14d
 101002b:	mov    $0x1,%ecx
 1010030:	shlx   %rax,%rcx,%r15
 1010035:	mov    0x48(%rbx,%r14,8),%rcx
 101003a:	bt     %rax,%rcx
 101003e:	jae    10100e1 <mark+0x151>
 1010044:	test   %r15,0x248(%rbx,%r14,8)
 101004c:	je     10101ce <mark+0x23e>
 1010052:	movb   $0x1,0x1175(%rdi)
 1010059:	jmp    10101ce <mark+0x23e>
 101005e:	mov    (%rsi),%rbx
 1010061:	movabs $0x4000000000000003,%rax
 101006b:	test   %rax,%rbx
 101006e:	jne    10101ce <mark+0x23e>
 1010074:	mov    0x4e8(%rdi),%rcx
 101007b:	cmp    0x4f0(%rdi),%rcx
 1010082:	jne    101019a <mark+0x20a>
 1010088:	lea    (%rcx,%rcx,1),%rax
 101008c:	test   %rcx,%rcx
 101008f:	mov    $0x400,%r14d
 1010095:	cmovne %rax,%r14
 1010099:	cmp    %rcx,%r14
 101009c:	jbe    1010145 <mark+0x1b5>
 10100a2:	mov    0x8(%rdi),%rax
 10100a6:	lea    0x0(,%r14,8),%rcx
 10100ae:	mov    %rdi,%r15
 10100b1:	mov    %rax,%rdi
 10100b4:	mov    %rsi,%r12
 10100b7:	mov    %rcx,%rsi
 10100ba:	call   101ef70 <realloc@plt>
 10100bf:	mov    %r15,%rdi
 10100c2:	test   %rax,%rax
 10100c5:	je     1010145 <mark+0x1b5>
 10100c7:	mov    %r12,%rsi
 10100ca:	mov    %rax,0x8(%rdi)
 10100ce:	mov    %r14,0x4f0(%rdi)
 10100d5:	mov    0x4e8(%rdi),%rcx
 10100dc:	jmp    101019e <mark+0x20e>
 10100e1:	mov    0x4e8(%rdi),%rcx
 10100e8:	cmp    0x4f0(%rdi),%rcx
 10100ef:	jne    1010151 <mark+0x1c1>
 10100f1:	lea    (%rcx,%rcx,1),%rax
 10100f5:	test   %rcx,%rcx
 10100f8:	mov    $0x400,%r12d
 10100fe:	cmovne %rax,%r12
 1010102:	cmp    %rcx,%r12
 1010105:	jbe    1010145 <mark+0x1b5>
 1010107:	mov    0x8(%rdi),%rax
 101010b:	lea    0x0(,%r12,8),%rcx
 1010113:	mov    %rdi,-0x30(%rbp)
 1010117:	mov    %rax,%rdi
 101011a:	mov    %rsi,%r13
 101011d:	mov    %rcx,%rsi
 1010120:	call   101ef70 <realloc@plt>
 1010125:	mov    -0x30(%rbp),%rdi
 1010129:	test   %rax,%rax
 101012c:	je     1010145 <mark+0x1b5>
 101012e:	mov    %r13,%rsi
 1010131:	mov    %rax,0x8(%rdi)
 1010135:	mov    %r12,0x4f0(%rdi)
 101013c:	mov    0x4e8(%rdi),%rcx
 1010143:	jmp    1010155 <mark+0x1c5>
 1010145:	movl   $0x1,0x4f8(%rdi)
 101014f:	jmp    10101ce <mark+0x23e>
 1010151:	mov    0x8(%rdi),%rax
 1010155:	lea    0x1(%rcx),%rdx
 1010159:	mov    %rdx,0x4e8(%rdi)
 1010160:	mov    %rsi,(%rax,%rcx,8)
 1010164:	or     %r15,0x48(%rbx,%r14,8)
 1010169:	movzbl 0x1174(%rdi),%eax
 1010170:	test   %eax,%eax
 1010172:	je     10101cb <mark+0x23b>
 1010174:	cmp    $0x1,%eax
 1010177:	jne    10101b6 <mark+0x226>
 1010179:	mov    0x248(%rbx,%r14,8),%rax
 1010181:	test   %r15,%rax
 1010184:	jne    10101be <mark+0x22e>
 1010186:	or     %r15,%rax
 1010189:	mov    %rax,0x248(%rbx,%r14,8)
 1010191:	movb   $0x1,0x1175(%rdi)
 1010198:	jmp    10101ce <mark+0x23e>
 101019a:	mov    0x8(%rdi),%rax
 101019e:	lea    0x1(%rcx),%rdx
 10101a2:	mov    %rdx,0x4e8(%rdi)
 10101a9:	mov    %rsi,(%rax,%rcx,8)
 10101ad:	or     $0x1,%rbx
 10101b1:	mov    %rbx,(%rsi)
 10101b4:	jmp    10101ce <mark+0x23e>
 10101b6:	mov    0x248(%rbx,%r14,8),%rax
 10101be:	andn   %rax,%r15,%rax
 10101c3:	mov    %rax,0x248(%rbx,%r14,8)
 10101cb:	orb    $0x1,(%rsi)
 10101ce:	add    $0x8,%rsp
 10101d2:	pop    %rbx
 10101d3:	pop    %r12
 10101d5:	pop    %r13
 10101d7:	pop    %r14
 10101d9:	pop    %r15
 10101db:	pop    %rbp
 10101dc:	ret
 10101dd:	int3
 10101de:	int3
 10101df:	int3

00000000010101e0 <scan_payload>:
 10101e0:	push   %rbp
 10101e1:	mov    %rsp,%rbp
 10101e4:	push   %r15
 10101e6:	push   %r14
 10101e8:	push   %r13
 10101ea:	push   %r12
 10101ec:	push   %rbx
 10101ed:	sub    $0x98,%rsp
 10101f4:	mov    0x8(%rsi),%r15
 10101f8:	movzwl 0x30(%r15),%eax
 10101fd:	test   %eax,%eax
 10101ff:	je     1010253 <scan_payload+0x73>
 1010201:	cmpl   $0x1,0x58(%r15)
 1010206:	je     1010253 <scan_payload+0x73>
 1010208:	mov    %rsi,%rbx
 101020b:	mov    %rdi,%r13
 101020e:	mov    $0x3c,%ecx
 1010213:	bzhi   %rcx,(%rsi),%r12
 1010218:	add    $0x10,%rbx
 101021c:	shr    $0x2,%r12
 1010220:	cmp    $0x6,%eax
 1010223:	ja     1010265 <scan_payload+0x85>
 1010225:	mov    $0x62,%ecx
 101022a:	bt     %eax,%ecx
 101022d:	jae    1010265 <scan_payload+0x85>
 101022f:	test   %r12,%r12
 1010232:	je     1010253 <scan_payload+0x73>
 1010234:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010240:	mov    (%rbx),%rsi
 1010243:	mov    %r13,%rdi
 1010246:	call   100ff90 <mark>
 101024b:	add    (%r15),%rbx
 101024e:	dec    %r12
 1010251:	jne    1010240 <scan_payload+0x60>
 1010253:	add    $0x98,%rsp
 101025a:	pop    %rbx
 101025b:	pop    %r12
 101025d:	pop    %r13
 101025f:	pop    %r14
 1010261:	pop    %r15
 1010263:	pop    %rbp
 1010264:	ret
 1010265:	mov    0x60(%r15),%rax
 1010269:	mov    %rax,-0x30(%rbp)
 101026d:	test   %rax,%rax
 1010270:	je     101030f <scan_payload+0x12f>
 1010276:	cmpl   $0x0,0x68(%r13)
 101027b:	je     1010342 <scan_payload+0x162>
 1010281:	lea    -0xc0(%rbp),%rax
 1010288:	mov    %rax,-0x60(%rbp)
 101028c:	movq   $0x8,-0x58(%rbp)
 1010294:	movq   $0x0,-0x50(%rbp)
 101029c:	lea    -0x60(%rbp),%rdi
 10102a0:	movabs $0xffffffff00000000,%rcx
 10102aa:	mov    %r15,%rsi
 10102ad:	xor    %edx,%edx
 10102af:	xor    %r8d,%r8d
 10102b2:	call   100ebc0 <flatten>
 10102b7:	test   %eax,%eax
 10102b9:	je     10102ea <scan_payload+0x10a>
 10102bb:	mov    -0x50(%rbp),%r14
 10102bf:	cmp    0x68(%r15),%r14
 10102c3:	jne    10102ea <scan_payload+0x10a>
 10102c5:	test   %r14,%r14
 10102c8:	je     1010253 <scan_payload+0x73>
 10102ca:	mov    0x60(%r15),%rsi
 10102ce:	lea    0x0(,%r14,4),%rax
 10102d6:	lea    (%rax,%rax,2),%rdx
 10102da:	lea    -0xc0(%rbp),%rdi
 10102e1:	call   101e470 <bcmp>
 10102e6:	test   %eax,%eax
 10102e8:	je     101034f <scan_payload+0x16f>
 10102ea:	mov    0x19077(%rip),%rax        # 1029368 <stderr@GLIBC_2.2.5>
 10102f1:	mov    (%rax),%rcx
 10102f4:	lea    -0xe35f(%rip),%rdi        # 1001f9c <__abi_tag+0x1ca0>
 10102fb:	mov    $0x43,%esi
 1010300:	mov    $0x1,%edx
 1010305:	call   101ed90 <fwrite@plt>
 101030a:	call   101efe0 <abort@plt>
 101030f:	test   %r12,%r12
 1010312:	je     1010253 <scan_payload+0x73>
 1010318:	xor    %r14d,%r14d
 101031b:	nopl   0x0(%rax,%rax,1)
 1010320:	mov    (%r15),%rdx
 1010323:	imul   %r14,%rdx
 1010327:	add    %rbx,%rdx
 101032a:	mov    %r13,%rdi
 101032d:	mov    %r15,%rsi
 1010330:	call   100fd40 <trace>
 1010335:	inc    %r14
 1010338:	cmp    %r14,%r12
 101033b:	jne    1010320 <scan_payload+0x140>
 101033d:	jmp    1010253 <scan_payload+0x73>
 1010342:	mov    0x68(%r15),%r14
 1010346:	test   %r14,%r14
 1010349:	je     1010253 <scan_payload+0x73>
 101034f:	test   %r12,%r12
 1010352:	je     1010253 <scan_payload+0x73>
 1010358:	mov    (%r15),%rax
 101035b:	mov    %rax,-0x38(%rbp)
 101035f:	addq   $0x8,-0x30(%rbp)
 1010364:	xor    %eax,%eax
 1010366:	mov    %r14,-0x40(%rbp)
 101036a:	jmp    101038b <scan_payload+0x1ab>
 101036c:	nopl   0x0(%rax)
 1010370:	mov    -0x48(%rbp),%rax
 1010374:	inc    %rax
 1010377:	add    -0x38(%rbp),%rbx
 101037b:	cmp    %r12,%rax
 101037e:	mov    %r15,%r13
 1010381:	mov    -0x40(%rbp),%r14
 1010385:	je     1010253 <scan_payload+0x73>
 101038b:	mov    %rax,-0x48(%rbp)
 101038f:	mov    %r13,%r15
 1010392:	mov    -0x30(%rbp),%r13
 1010396:	jmp    10103b9 <scan_payload+0x1d9>
 1010398:	nopl   0x0(%rax,%rax,1)
 10103a0:	mov    -0x8(%r13),%eax
 10103a4:	mov    (%rbx,%rax,1),%rsi
 10103a8:	mov    %r15,%rdi
 10103ab:	call   100ff90 <mark>
 10103b0:	add    $0xc,%r13
 10103b4:	dec    %r14
 10103b7:	je     1010370 <scan_payload+0x190>
 10103b9:	mov    -0x4(%r13),%eax
 10103bd:	mov    $0xffffffff,%ecx
 10103c2:	cmp    %rcx,%rax
 10103c5:	je     10103a0 <scan_payload+0x1c0>
 10103c7:	mov    (%rbx,%rax,1),%eax
 10103ca:	cmp    0x0(%r13),%eax
 10103ce:	je     10103a0 <scan_payload+0x1c0>
 10103d0:	jmp    10103b0 <scan_payload+0x1d0>
 10103d2:	int3
 10103d3:	int3
 10103d4:	int3
 10103d5:	int3
 10103d6:	int3
 10103d7:	int3
 10103d8:	int3
 10103d9:	int3
 10103da:	int3
 10103db:	int3
 10103dc:	int3
 10103dd:	int3
 10103de:	int3
 10103df:	int3

00000000010103e0 <myl_native_arena_reclaim>:
 10103e0:	push   %rbp
 10103e1:	mov    %rsp,%rbp
 10103e4:	push   %rbx
 10103e5:	push   %rax
 10103e6:	mov    %rdi,%rbx
 10103e9:	mov    0x4e0(%rdi),%rdi
 10103f0:	jmp    101040c <myl_native_arena_reclaim+0x2c>
 10103f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010400:	call   101edc0 <free@plt>
 1010405:	mov    0x4e0(%rbx),%rdi
 101040c:	test   %rdi,%rdi
 101040f:	je     101042f <myl_native_arena_reclaim+0x4f>
 1010411:	mov    (%rdi),%rax
 1010414:	mov    %rax,0x4e0(%rbx)
 101041b:	cmpq   $0x0,0x1608(%rbx)
 1010423:	je     1010400 <myl_native_arena_reclaim+0x20>
 1010425:	mov    0x8(%rdi),%rax
 1010429:	sub    %rax,0x18(%rbx)
 101042d:	jmp    1010400 <myl_native_arena_reclaim+0x20>
 101042f:	vxorps %xmm0,%xmm0,%xmm0
 1010433:	vmovups %xmm0,0xc0(%rbx)
 101043b:	add    $0x8,%rsp
 101043f:	pop    %rbx
 1010440:	pop    %rbp
 1010441:	ret
 1010442:	int3
 1010443:	int3
 1010444:	int3
 1010445:	int3
 1010446:	int3
 1010447:	int3
 1010448:	int3
 1010449:	int3
 101044a:	int3
 101044b:	int3
 101044c:	int3
 101044d:	int3
 101044e:	int3
 101044f:	int3

0000000001010450 <myl_native_arena_alloc>:
 1010450:	push   %rbp
 1010451:	mov    %rsp,%rbp
 1010454:	push   %r15
 1010456:	push   %r14
 1010458:	push   %r13
 101045a:	push   %r12
 101045c:	push   %rbx
 101045d:	sub    $0x48,%rsp
 1010461:	mov    %rdi,%rbx
 1010464:	mov    %rdx,%rax
 1010467:	shr    $0x26,%rax
 101046b:	setne  %al
 101046e:	cmp    $0x100000,%ecx
 1010474:	setae  %dil
 1010478:	or     %al,%dil
 101047b:	je     1010484 <myl_native_arena_alloc+0x34>
 101047d:	xor    %eax,%eax
 101047f:	jmp    1010bae <myl_native_arena_alloc+0x75e>
 1010484:	mov    (%rsi),%r14
 1010487:	imul   %rdx,%r14
 101048b:	cmp    $0x1,%r14
 101048f:	mov    %r14,%r15
 1010492:	adc    $0x0,%r15
 1010496:	cmpl   $0x0,0x68(%rbx)
 101049a:	je     10104c4 <myl_native_arena_alloc+0x74>
 101049c:	cmpl   $0x0,0x74(%rbx)
 10104a0:	jne    10104c4 <myl_native_arena_alloc+0x74>
 10104a2:	mov    %rbx,%rdi
 10104a5:	mov    %r15,-0x38(%rbp)
 10104a9:	mov    %rcx,%r15
 10104ac:	mov    %rsi,%r13
 10104af:	mov    %rdx,%r12
 10104b2:	call   100ed70 <myl_native_heap_collect>
 10104b7:	mov    %r12,%rdx
 10104ba:	mov    %r13,%rsi
 10104bd:	mov    %r15,%rcx
 10104c0:	mov    -0x38(%rbp),%r15
 10104c4:	mov    0x11a0(%rbx),%rdi
 10104cb:	test   %rdi,%rdi
 10104ce:	je     1010594 <myl_native_arena_alloc+0x144>
 10104d4:	mov    0x5c0(%rbx),%rax
 10104db:	mov    0x5c8(%rbx),%r8
 10104e2:	mov    %r8,%r9
 10104e5:	sub    %rax,%r9
 10104e8:	sub    $0x10,%r9
 10104ec:	setb   %r10b
 10104f0:	cmp    %ecx,0x20(%rdi)
 10104f3:	jne    101056e <myl_native_arena_alloc+0x11e>
 10104f5:	test   %r10b,%r10b
 10104f8:	jne    101056e <myl_native_arena_alloc+0x11e>
 10104fa:	cmp    %r9,%r15
 10104fd:	ja     101056e <myl_native_arena_alloc+0x11e>
 10104ff:	shl    $0x28,%rcx
 1010503:	shl    $0x2,%rdx
 1010507:	or     %rcx,%rdx
 101050a:	movabs $0x4000000000000000,%rcx
 1010514:	or     %rdx,%rcx
 1010517:	mov    %rcx,(%rax)
 101051a:	mov    %rsi,0x8(%rax)
 101051e:	incq   0x18(%rdi)
 1010522:	lea    0x50(%rdi),%rcx
 1010526:	sub    %rcx,%r15
 1010529:	lea    (%r15,%rax,1),%rcx
 101052d:	add    $0x1f,%rcx
 1010531:	and    $0xfffffffffffffff0,%rcx
 1010535:	mov    0x8(%rdi),%rdx
 1010539:	add    $0xffffffffffffffb0,%rdx
 101053d:	cmp    %rdx,%rcx
 1010540:	lea    0x50(%rdi,%rcx,1),%rcx
 1010545:	cmovb  %rcx,%r8
 1010549:	mov    %r8,0x5c0(%rbx)
 1010550:	vmovdqu 0x40(%rbx),%xmm0
 1010555:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1010559:	vpsubq %xmm1,%xmm0,%xmm0
 101055d:	vmovdqu %xmm0,0x40(%rbx)
 1010562:	incq   0x90(%rbx)
 1010569:	jmp    1010baa <myl_native_arena_alloc+0x75a>
 101056e:	lea    0x5c0(%rbx),%r8
 1010575:	sub    %rdi,%rax
 1010578:	add    $0xffffffffffffffb0,%rax
 101057c:	mov    %rax,0x10(%rdi)
 1010580:	movq   $0x0,0x11a0(%rbx)
 101058b:	vpxor  %xmm0,%xmm0,%xmm0
 101058f:	vmovdqu %xmm0,(%r8)
 1010594:	mov    %ecx,%r13d
 1010597:	cmp    %r13,0x11e8(%rbx)
 101059e:	jbe    10105c2 <myl_native_arena_alloc+0x172>
 10105a0:	mov    0x4d8(%rbx),%rax
 10105a7:	mov    (%rax,%r13,8),%r12
 10105ab:	test   %r12,%r12
 10105ae:	je     10105c2 <myl_native_arena_alloc+0x172>
 10105b0:	mov    0x10(%r12),%rax
 10105b5:	cmp    $0xfffffffffffffff1,%rax
 10105b9:	jb     10105d0 <myl_native_arena_alloc+0x180>
 10105bb:	mov    0x8(%r12),%rdi
 10105c0:	jmp    1010602 <myl_native_arena_alloc+0x1b2>
 10105c2:	xor    %eax,%eax
 10105c4:	cmp    $0xffffffffffffff90,%r14
 10105c8:	ja     101047d <myl_native_arena_alloc+0x2d>
 10105ce:	jmp    101061e <myl_native_arena_alloc+0x1ce>
 10105d0:	add    $0xf,%rax
 10105d4:	and    $0xfffffffffffffff0,%rax
 10105d8:	mov    0x8(%r12),%rdi
 10105dd:	lea    -0x50(%rdi),%r8
 10105e1:	sub    %rax,%r8
 10105e4:	jb     1010602 <myl_native_arena_alloc+0x1b2>
 10105e6:	sub    $0x10,%r8
 10105ea:	setb   %r9b
 10105ee:	cmp    %r8,%r15
 10105f1:	seta   %r8b
 10105f5:	or     %r9b,%r8b
 10105f8:	cmp    $0x1,%r8b
 10105fc:	jne    1010af7 <myl_native_arena_alloc+0x6a7>
 1010602:	cmp    $0x80000,%rdi
 1010609:	mov    $0x80000,%eax
 101060e:	cmovb  %rdi,%rax
 1010612:	add    %eax,%eax
 1010614:	cmp    $0xffffffffffffff90,%r14
 1010618:	ja     101047d <myl_native_arena_alloc+0x2d>
 101061e:	mov    %r15,-0x38(%rbp)
 1010622:	lea    0x6f(%r15),%r12
 1010626:	and    $0xfffffffffffffff0,%r12
 101062a:	cmp    %r12,%rax
 101062d:	cmovbe %r12,%rax
 1010631:	cmp    $0x10001,%rax
 1010637:	mov    $0x10000,%r15d
 101063d:	cmovae %rax,%r15
 1010641:	cmpq   $0x0,0x1608(%rbx)
 1010649:	mov    0x11f0(%rbx),%r14
 1010650:	mov    %rcx,-0x58(%rbp)
 1010654:	mov    %rdx,-0x48(%rbp)
 1010658:	mov    %rsi,-0x40(%rbp)
 101065c:	je     1010674 <myl_native_arena_alloc+0x224>
 101065e:	cmp    %r13,%r14
 1010661:	jbe    1010736 <myl_native_arena_alloc+0x2e6>
 1010667:	movq   $0x0,-0x30(%rbp)
 101066f:	jmp    1010797 <myl_native_arena_alloc+0x347>
 1010674:	cmp    %r13,%r14
 1010677:	ja     10106ea <myl_native_arena_alloc+0x29a>
 1010679:	test   %r14,%r14
 101067c:	mov    $0x8,%eax
 1010681:	cmovne %r14,%rax
 1010685:	data16 cs nopw 0x0(%rax,%rax,1)
 1010690:	mov    %rax,%r14
 1010693:	add    %rax,%rax
 1010696:	cmp    %r13,%r14
 1010699:	jbe    1010690 <myl_native_arena_alloc+0x240>
 101069b:	mov    0x4d8(%rbx),%rdi
 10106a2:	lea    0x0(,%r14,8),%rsi
 10106aa:	call   101ef70 <realloc@plt>
 10106af:	test   %rax,%rax
 10106b2:	je     101047d <myl_native_arena_alloc+0x2d>
 10106b8:	mov    0x11f0(%rbx),%rcx
 10106bf:	lea    (%rax,%rcx,8),%rdi
 10106c3:	mov    %r14,%rdx
 10106c6:	sub    %rcx,%rdx
 10106c9:	shl    $0x3,%rdx
 10106cd:	xor    %esi,%esi
 10106cf:	mov    %rax,-0x30(%rbp)
 10106d3:	call   101e4a0 <compiler_rt.fastMemset>
 10106d8:	mov    -0x30(%rbp),%rax
 10106dc:	mov    %rax,0x4d8(%rbx)
 10106e3:	mov    %r14,0x11f0(%rbx)
 10106ea:	mov    0x18(%rbx),%rdi
 10106ee:	mov    0x58(%rbx),%rax
 10106f2:	mov    %rax,%r8
 10106f5:	sub    %rdi,%r8
 10106f8:	jb     10106ff <myl_native_arena_alloc+0x2af>
 10106fa:	cmp    %r8,%r12
 10106fd:	jbe    1010715 <myl_native_arena_alloc+0x2c5>
 10106ff:	cmpl   $0x0,0x74(%rbx)
 1010703:	jne    1010715 <myl_native_arena_alloc+0x2c5>
 1010705:	mov    %rbx,%rdi
 1010708:	call   100ed70 <myl_native_heap_collect>
 101070d:	mov    0x18(%rbx),%rdi
 1010711:	mov    0x58(%rbx),%rax
 1010715:	xor    %r8d,%r8d
 1010718:	sub    %rdi,%rax
 101071b:	cmovae %rax,%r8
 101071f:	cmp    %r8,%r12
 1010722:	jbe    1010853 <myl_native_arena_alloc+0x403>
 1010728:	movl   $0x1,0x6c(%rbx)
 101072f:	xor    %eax,%eax
 1010731:	jmp    1010bae <myl_native_arena_alloc+0x75e>
 1010736:	test   %r14,%r14
 1010739:	mov    $0x8,%eax
 101073e:	cmovne %r14,%rax
 1010742:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010750:	mov    %rax,%r14
 1010753:	add    %rax,%rax
 1010756:	cmp    %r13,%r14
 1010759:	jbe    1010750 <myl_native_arena_alloc+0x300>
 101075b:	lea    0x0(,%r14,8),%rsi
 1010763:	mov    %rbx,%rdi
 1010766:	call   1012480 <myl_rc_meta_alloc>
 101076b:	test   %rax,%rax
 101076e:	je     101047d <myl_native_arena_alloc+0x2d>
 1010774:	mov    0x11f0(%rbx),%rdx
 101077b:	test   %rdx,%rdx
 101077e:	mov    %rax,-0x30(%rbp)
 1010782:	je     1010797 <myl_native_arena_alloc+0x347>
 1010784:	mov    0x4d8(%rbx),%rsi
 101078b:	shl    $0x3,%rdx
 101078f:	mov    %rax,%rdi
 1010792:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1010797:	mov    0x4e0(%rbx),%rdi
 101079e:	test   %rdi,%rdi
 10107a1:	je     101083b <myl_native_arena_alloc+0x3eb>
 10107a7:	xor    %eax,%eax
 10107a9:	mov    %rdi,%r10
 10107ac:	lea    0x4e0(%rbx),%r8
 10107b3:	jmp    10107cb <myl_native_arena_alloc+0x37b>
 10107b5:	data16 cs nopw 0x0(%rax,%rax,1)
 10107c0:	mov    %r9,%rax
 10107c3:	mov    (%r8),%r10
 10107c6:	test   %r10,%r10
 10107c9:	je     10107ef <myl_native_arena_alloc+0x39f>
 10107cb:	mov    %r8,%r9
 10107ce:	mov    %r10,%r8
 10107d1:	mov    0x8(%r10),%r10
 10107d5:	cmp    %r12,%r10
 10107d8:	jb     10107c3 <myl_native_arena_alloc+0x373>
 10107da:	cmp    %r15,%r10
 10107dd:	ja     10107c3 <myl_native_arena_alloc+0x373>
 10107df:	test   %rax,%rax
 10107e2:	je     10107c0 <myl_native_arena_alloc+0x370>
 10107e4:	mov    (%rax),%r11
 10107e7:	cmp    0x8(%r11),%r10
 10107eb:	ja     10107c0 <myl_native_arena_alloc+0x370>
 10107ed:	jmp    10107c3 <myl_native_arena_alloc+0x373>
 10107ef:	test   %rax,%rax
 10107f2:	je     101083b <myl_native_arena_alloc+0x3eb>
 10107f4:	mov    (%rax),%r12
 10107f7:	mov    (%r12),%rcx
 10107fb:	mov    %rcx,(%rax)
 10107fe:	decq   0xc0(%rbx)
 1010805:	mov    0x8(%r12),%rax
 101080a:	sub    %rax,0xc8(%rbx)
 1010811:	lea    0x50(%r12),%rdi
 1010816:	mov    0x10(%r12),%rdx
 101081b:	xor    %esi,%esi
 101081d:	call   101e4a0 <compiler_rt.fastMemset>
 1010822:	vpxor  %xmm0,%xmm0,%xmm0
 1010826:	vmovdqa %xmm0,0x10(%r12)
 101082d:	mov    $0xa0,%eax
 1010832:	mov    -0x38(%rbp),%r15
 1010836:	jmp    1010a5e <myl_native_arena_alloc+0x60e>
 101083b:	mov    0x18(%rbx),%r9
 101083f:	mov    0x58(%rbx),%r8
 1010843:	test   %r8,%r8
 1010846:	je     10108b3 <myl_native_arena_alloc+0x463>
 1010848:	xor    %eax,%eax
 101084a:	sub    %r9,%r8
 101084d:	cmovae %r8,%rax
 1010851:	jmp    10108b9 <myl_native_arena_alloc+0x469>
 1010853:	mov    %r8,%r14
 1010856:	and    $0xfffffffffffffff0,%r14
 101085a:	cmp    %r8,%r15
 101085d:	cmovb  %r15,%r14
 1010861:	mov    0x4e0(%rbx),%rdx
 1010868:	test   %rdx,%rdx
 101086b:	mov    -0x38(%rbp),%r15
 101086f:	je     1010992 <myl_native_arena_alloc+0x542>
 1010875:	lea    0x4e0(%rbx),%rcx
 101087c:	xor    %eax,%eax
 101087e:	jmp    101088f <myl_native_arena_alloc+0x43f>
 1010880:	mov    %rsi,%rax
 1010883:	mov    (%rcx),%rdx
 1010886:	test   %rdx,%rdx
 1010889:	je     1010946 <myl_native_arena_alloc+0x4f6>
 101088f:	mov    %rcx,%rsi
 1010892:	mov    %rdx,%rcx
 1010895:	mov    0x8(%rdx),%rdx
 1010899:	cmp    %r12,%rdx
 101089c:	jb     1010883 <myl_native_arena_alloc+0x433>
 101089e:	cmp    %r14,%rdx
 10108a1:	ja     1010883 <myl_native_arena_alloc+0x433>
 10108a3:	test   %rax,%rax
 10108a6:	je     1010880 <myl_native_arena_alloc+0x430>
 10108a8:	mov    (%rax),%rdi
 10108ab:	cmp    0x8(%rdi),%rdx
 10108af:	ja     1010880 <myl_native_arena_alloc+0x430>
 10108b1:	jmp    1010883 <myl_native_arena_alloc+0x433>
 10108b3:	mov    %r9,%rax
 10108b6:	not    %rax
 10108b9:	xor    %r8d,%r8d
 10108bc:	cmp    %rax,%r12
 10108bf:	cmovbe %rdi,%r8
 10108c3:	mov    %r8,-0x50(%rbp)
 10108c7:	test   %rdi,%rdi
 10108ca:	je     10109f1 <myl_native_arena_alloc+0x5a1>
 10108d0:	cmp    %rax,%r12
 10108d3:	ja     10108f4 <myl_native_arena_alloc+0x4a4>
 10108d5:	jmp    10109f1 <myl_native_arena_alloc+0x5a1>
 10108da:	nopw   0x0(%rax,%rax,1)
 10108e0:	call   101edc0 <free@plt>
 10108e5:	lea    0x4e0(%rbx),%rax
 10108ec:	mov    (%rax),%rdi
 10108ef:	test   %rdi,%rdi
 10108f2:	je     1010912 <myl_native_arena_alloc+0x4c2>
 10108f4:	mov    (%rdi),%rax
 10108f7:	mov    %rax,0x4e0(%rbx)
 10108fe:	cmpq   $0x0,0x1608(%rbx)
 1010906:	je     10108e0 <myl_native_arena_alloc+0x490>
 1010908:	mov    0x8(%rdi),%rax
 101090c:	sub    %rax,0x18(%rbx)
 1010910:	jmp    10108e0 <myl_native_arena_alloc+0x490>
 1010912:	vpxor  %xmm0,%xmm0,%xmm0
 1010916:	vmovdqu %xmm0,0xc0(%rbx)
 101091e:	mov    0x18(%rbx),%r9
 1010922:	mov    0x58(%rbx),%rax
 1010926:	test   %rax,%rax
 1010929:	je     10109e3 <myl_native_arena_alloc+0x593>
 101092f:	xor    %edx,%edx
 1010931:	sub    %r9,%rax
 1010934:	mov    $0x0,%ecx
 1010939:	mov    %rcx,-0x50(%rbp)
 101093d:	cmovb  %rdx,%rax
 1010941:	jmp    10109f1 <myl_native_arena_alloc+0x5a1>
 1010946:	test   %rax,%rax
 1010949:	je     1010992 <myl_native_arena_alloc+0x542>
 101094b:	mov    (%rax),%r12
 101094e:	mov    (%r12),%rcx
 1010952:	mov    %rcx,(%rax)
 1010955:	decq   0xc0(%rbx)
 101095c:	mov    0x8(%r12),%rax
 1010961:	sub    %rax,0xc8(%rbx)
 1010968:	lea    0x50(%r12),%rdi
 101096d:	mov    0x10(%r12),%rdx
 1010972:	xor    %esi,%esi
 1010974:	call   101e4a0 <compiler_rt.fastMemset>
 1010979:	vpxor  %xmm0,%xmm0,%xmm0
 101097d:	vmovdqa %xmm0,0x10(%r12)
 1010984:	incq   0xa0(%rbx)
 101098b:	mov    0x8(%r12),%r14
 1010990:	jmp    10109b6 <myl_native_arena_alloc+0x566>
 1010992:	mov    $0x1,%edi
 1010997:	mov    %r14,%rsi
 101099a:	call   101ed70 <calloc@plt>
 101099f:	test   %rax,%rax
 10109a2:	je     1010c3c <myl_native_arena_alloc+0x7ec>
 10109a8:	mov    %rax,%r12
 10109ab:	mov    %r14,0x8(%rax)
 10109af:	incq   0x98(%rbx)
 10109b6:	mov    -0x58(%rbp),%rcx
 10109ba:	mov    -0x40(%rbp),%rsi
 10109be:	mov    -0x48(%rbp),%rdx
 10109c2:	add    %r14,0x18(%rbx)
 10109c6:	mov    0x4d8(%rbx),%rax
 10109cd:	mov    (%rax,%r13,8),%rdi
 10109d1:	mov    %rdi,(%r12)
 10109d5:	mov    %ecx,0x20(%r12)
 10109da:	mov    %r12,(%rax,%r13,8)
 10109de:	jmp    1010ab7 <myl_native_arena_alloc+0x667>
 10109e3:	mov    %r9,%rax
 10109e6:	not    %rax
 10109e9:	movq   $0x0,-0x50(%rbp)
 10109f1:	cmp    %rax,%r12
 10109f4:	jbe    1010a17 <myl_native_arena_alloc+0x5c7>
 10109f6:	movl   $0x1,0x6c(%rbx)
 10109fd:	shl    $0x3,%r14
 1010a01:	mov    %rbx,%rdi
 1010a04:	mov    -0x30(%rbp),%rsi
 1010a08:	mov    %r14,%rdx
 1010a0b:	call   1012500 <myl_rc_meta_free>
 1010a10:	xor    %eax,%eax
 1010a12:	jmp    1010bae <myl_native_arena_alloc+0x75e>
 1010a17:	mov    %r9,-0x68(%rbp)
 1010a1b:	mov    %rax,%r12
 1010a1e:	and    $0xfffffffffffffff0,%r12
 1010a22:	cmp    %rax,%r15
 1010a25:	cmovb  %r15,%r12
 1010a29:	mov    $0x1,%edi
 1010a2e:	mov    %r12,%rsi
 1010a31:	call   101ed70 <calloc@plt>
 1010a36:	mov    %r12,%rcx
 1010a39:	mov    %rax,%r12
 1010a3c:	test   %rax,%rax
 1010a3f:	mov    -0x38(%rbp),%r15
 1010a43:	je     1010bbd <myl_native_arena_alloc+0x76d>
 1010a49:	mov    %rcx,0x8(%r12)
 1010a4e:	mov    -0x68(%rbp),%rax
 1010a52:	add    %rcx,%rax
 1010a55:	mov    %rax,0x18(%rbx)
 1010a59:	mov    $0x98,%eax
 1010a5e:	incq   (%rbx,%rax,1)
 1010a62:	mov    0x4d8(%rbx),%rsi
 1010a69:	cmpq   $0x0,-0x30(%rbp)
 1010a6e:	je     1010a97 <myl_native_arena_alloc+0x647>
 1010a70:	mov    0x11f0(%rbx),%rdx
 1010a77:	shl    $0x3,%rdx
 1010a7b:	mov    %rbx,%rdi
 1010a7e:	call   1012500 <myl_rc_meta_free>
 1010a83:	mov    -0x30(%rbp),%rdi
 1010a87:	mov    %rdi,0x4d8(%rbx)
 1010a8e:	mov    %r14,0x11f0(%rbx)
 1010a95:	jmp    1010a9a <myl_native_arena_alloc+0x64a>
 1010a97:	mov    %rsi,%rdi
 1010a9a:	mov    -0x40(%rbp),%rsi
 1010a9e:	mov    -0x48(%rbp),%rdx
 1010aa2:	mov    (%rdi,%r13,8),%rax
 1010aa6:	mov    %rax,(%r12)
 1010aaa:	mov    -0x58(%rbp),%rcx
 1010aae:	mov    %ecx,0x20(%r12)
 1010ab3:	mov    %r12,(%rdi,%r13,8)
 1010ab7:	cmp    %r13,0x11e8(%rbx)
 1010abe:	ja     1010acb <myl_native_arena_alloc+0x67b>
 1010ac0:	lea    0x1(%r13),%rax
 1010ac4:	mov    %rax,0x11e8(%rbx)
 1010acb:	incq   0xa8(%rbx)
 1010ad2:	mov    0xb0(%rbx),%rax
 1010ad9:	add    0x8(%r12),%rax
 1010ade:	mov    %rax,0xb0(%rbx)
 1010ae5:	cmp    0xb8(%rbx),%rax
 1010aec:	jbe    1010af5 <myl_native_arena_alloc+0x6a5>
 1010aee:	mov    %rax,0xb8(%rbx)
 1010af5:	xor    %eax,%eax
 1010af7:	movabs $0x4000000000000000,%rdi
 1010b01:	shl    $0x28,%r13
 1010b05:	lea    0x0(,%rdx,4),%rdx
 1010b0d:	add    %r13,%rdx
 1010b10:	or     %rdi,%rdx
 1010b13:	mov    %rdx,0x50(%r12,%rax,1)
 1010b18:	mov    %rsi,0x58(%r12,%rax,1)
 1010b1d:	incq   0x18(%r12)
 1010b22:	lea    (%r15,%rax,1),%rdx
 1010b26:	add    $0x10,%rdx
 1010b2a:	mov    %rdx,0x10(%r12)
 1010b2f:	vmovdqu 0x40(%rbx),%xmm0
 1010b34:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1010b38:	vpsubq %xmm1,%xmm0,%xmm0
 1010b3c:	vmovdqu %xmm0,0x40(%rbx)
 1010b41:	incq   0x90(%rbx)
 1010b48:	add    %r12,%rax
 1010b4b:	add    $0x50,%rax
 1010b4f:	cmp    0x70(%rbx),%ecx
 1010b52:	jne    1010baa <myl_native_arena_alloc+0x75a>
 1010b54:	cmpl   $0x0,0x74(%rbx)
 1010b58:	jne    1010baa <myl_native_arena_alloc+0x75a>
 1010b5a:	cmpl   $0x0,0x68(%rbx)
 1010b5e:	jne    1010baa <myl_native_arena_alloc+0x75a>
 1010b60:	mov    0x8(%r12),%rcx
 1010b65:	mov    0x10(%r12),%rdx
 1010b6a:	add    $0xf,%rdx
 1010b6e:	and    $0xfffffffffffffff0,%rdx
 1010b72:	lea    -0x50(%rcx),%rsi
 1010b76:	cmp    %rsi,%rdx
 1010b79:	jae    1010baa <myl_native_arena_alloc+0x75a>
 1010b7b:	lea    0x50(%r12),%rsi
 1010b80:	add    %rdx,%rsi
 1010b83:	add    %r12,%rcx
 1010b86:	mov    %rsi,0x5c0(%rbx)
 1010b8d:	mov    %rcx,0x5c8(%rbx)
 1010b94:	lea    (%rdi,%r13,1),%rcx
 1010b98:	add    $0x4,%rcx
 1010b9c:	mov    %rcx,0x5d0(%rbx)
 1010ba3:	mov    %r12,0x11a0(%rbx)
 1010baa:	add    $0x10,%rax
 1010bae:	add    $0x48,%rsp
 1010bb2:	pop    %rbx
 1010bb3:	pop    %r12
 1010bb5:	pop    %r13
 1010bb7:	pop    %r14
 1010bb9:	pop    %r15
 1010bbb:	pop    %rbp
 1010bbc:	ret
 1010bbd:	mov    %rcx,-0x60(%rbp)
 1010bc1:	mov    -0x50(%rbp),%rdi
 1010bc5:	test   %rdi,%rdi
 1010bc8:	je     10109fd <myl_native_arena_alloc+0x5ad>
 1010bce:	mov    -0x60(%rbp),%r12
 1010bd2:	jmp    1010be8 <myl_native_arena_alloc+0x798>
 1010bd4:	call   101edc0 <free@plt>
 1010bd9:	lea    0x4e0(%rbx),%rax
 1010be0:	mov    (%rax),%rdi
 1010be3:	test   %rdi,%rdi
 1010be6:	je     1010c06 <myl_native_arena_alloc+0x7b6>
 1010be8:	mov    (%rdi),%rax
 1010beb:	mov    %rax,0x4e0(%rbx)
 1010bf2:	cmpq   $0x0,0x1608(%rbx)
 1010bfa:	je     1010bd4 <myl_native_arena_alloc+0x784>
 1010bfc:	mov    0x8(%rdi),%rax
 1010c00:	sub    %rax,0x18(%rbx)
 1010c04:	jmp    1010bd4 <myl_native_arena_alloc+0x784>
 1010c06:	vpxor  %xmm0,%xmm0,%xmm0
 1010c0a:	vmovdqu %xmm0,0xc0(%rbx)
 1010c12:	mov    $0x1,%edi
 1010c17:	mov    %r12,%rsi
 1010c1a:	call   101ed70 <calloc@plt>
 1010c1f:	test   %rax,%rax
 1010c22:	je     10109fd <myl_native_arena_alloc+0x5ad>
 1010c28:	mov    %rax,%r12
 1010c2b:	mov    0x18(%rbx),%rax
 1010c2f:	mov    %rax,-0x68(%rbp)
 1010c33:	mov    -0x60(%rbp),%rcx
 1010c37:	jmp    1010a49 <myl_native_arena_alloc+0x5f9>
 1010c3c:	cmpq   $0x0,0xc0(%rbx)
 1010c44:	je     101047d <myl_native_arena_alloc+0x2d>
 1010c4a:	mov    %rbx,%rdi
 1010c4d:	call   10103e0 <myl_native_arena_reclaim>
 1010c52:	mov    $0x1,%edi
 1010c57:	mov    %r14,%rsi
 1010c5a:	call   101ed70 <calloc@plt>
 1010c5f:	test   %rax,%rax
 1010c62:	jne    10109a8 <myl_native_arena_alloc+0x558>
 1010c68:	jmp    101047d <myl_native_arena_alloc+0x2d>
 1010c6d:	int3
 1010c6e:	int3
 1010c6f:	int3

0000000001010c70 <myl_native_arena_trace>:
 1010c70:	push   %rbp
 1010c71:	mov    %rsp,%rbp
 1010c74:	push   %r15
 1010c76:	push   %r14
 1010c78:	push   %r13
 1010c7a:	push   %r12
 1010c7c:	push   %rbx
 1010c7d:	sub    $0x38,%rsp
 1010c81:	mov    %rsi,%r8
 1010c84:	mov    %rdi,%r12
 1010c87:	mov    0x11a0(%rdi),%rax
 1010c8e:	test   %rax,%rax
 1010c91:	je     1010cc0 <myl_native_arena_trace+0x50>
 1010c93:	mov    0x5c0(%r12),%rcx
 1010c9b:	sub    %rax,%rcx
 1010c9e:	add    $0xffffffffffffffb0,%rcx
 1010ca2:	mov    %rcx,0x10(%rax)
 1010ca6:	movq   $0x0,0x11a0(%r12)
 1010cb2:	vxorps %xmm0,%xmm0,%xmm0
 1010cb6:	vmovups %xmm0,0x5c0(%r12)
 1010cc0:	mov    0x11e8(%r12),%rax
 1010cc8:	test   %rax,%rax
 1010ccb:	je     1010df0 <myl_native_arena_trace+0x180>
 1010cd1:	xor    %edx,%edx
 1010cd3:	mov    $0x28,%esi
 1010cd8:	jmp    1010cf8 <myl_native_arena_trace+0x88>
 1010cda:	nopw   0x0(%rax,%rax,1)
 1010ce0:	mov    0x11e8(%r12),%rax
 1010ce8:	mov    -0x30(%rbp),%rdx
 1010cec:	inc    %rdx
 1010cef:	cmp    %rax,%rdx
 1010cf2:	jae    1010df0 <myl_native_arena_trace+0x180>
 1010cf8:	mov    0x4d8(%r12),%rcx
 1010d00:	mov    %rdx,-0x30(%rbp)
 1010d04:	mov    (%rcx,%rdx,8),%r9
 1010d08:	test   %r9,%r9
 1010d0b:	jne    1010d18 <myl_native_arena_trace+0xa8>
 1010d0d:	jmp    1010ce8 <myl_native_arena_trace+0x78>
 1010d0f:	nop
 1010d10:	mov    (%r9),%r9
 1010d13:	test   %r9,%r9
 1010d16:	je     1010ce0 <myl_native_arena_trace+0x70>
 1010d18:	mov    0x10(%r9),%rax
 1010d1c:	test   %rax,%rax
 1010d1f:	je     1010d10 <myl_native_arena_trace+0xa0>
 1010d21:	lea    0x50(%r9),%r10
 1010d25:	xor    %r11d,%r11d
 1010d28:	mov    %r9,-0x40(%rbp)
 1010d2c:	mov    %r10,-0x38(%rbp)
 1010d30:	jmp    1010d50 <myl_native_arena_trace+0xe0>
 1010d32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010d40:	add    %r14,%r11
 1010d43:	add    $0x1f,%r11
 1010d47:	and    $0xfffffffffffffff0,%r11
 1010d4b:	cmp    %rax,%r11
 1010d4e:	jae    1010d10 <myl_native_arena_trace+0xa0>
 1010d50:	mov    0x8(%r10,%r11,1),%r15
 1010d55:	bzhi   %rsi,(%r10,%r11,1),%rbx
 1010d5b:	shr    $0x2,%rbx
 1010d5f:	mov    (%r15),%r14
 1010d62:	imul   %rbx,%r14
 1010d66:	cmp    $0x1,%r14
 1010d6a:	adc    $0x0,%r14
 1010d6e:	cmpw   $0x0,0x30(%r15)
 1010d74:	je     1010d40 <myl_native_arena_trace+0xd0>
 1010d76:	cmpl   $0x1,0x58(%r15)
 1010d7b:	setne  %cl
 1010d7e:	test   %rbx,%rbx
 1010d81:	setne  %dl
 1010d84:	and    %cl,%dl
 1010d86:	cmp    $0x1,%dl
 1010d89:	jne    1010d40 <myl_native_arena_trace+0xd0>
 1010d8b:	mov    %r14,-0x48(%rbp)
 1010d8f:	mov    %r11,-0x50(%rbp)
 1010d93:	lea    (%r10,%r11,1),%rax
 1010d97:	add    $0x10,%rax
 1010d9b:	mov    %rax,-0x58(%rbp)
 1010d9f:	xor    %r13d,%r13d
 1010da2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010db0:	mov    (%r15),%rdx
 1010db3:	imul   %r13,%rdx
 1010db7:	add    -0x58(%rbp),%rdx
 1010dbb:	mov    %r12,%rdi
 1010dbe:	mov    %r15,%rsi
 1010dc1:	mov    %r8,%r14
 1010dc4:	call   *%r8
 1010dc7:	mov    %r14,%r8
 1010dca:	inc    %r13
 1010dcd:	cmp    %r13,%rbx
 1010dd0:	jne    1010db0 <myl_native_arena_trace+0x140>
 1010dd2:	mov    -0x40(%rbp),%r9
 1010dd6:	mov    0x10(%r9),%rax
 1010dda:	mov    $0x28,%esi
 1010ddf:	mov    -0x38(%rbp),%r10
 1010de3:	mov    -0x50(%rbp),%r11
 1010de7:	mov    -0x48(%rbp),%r14
 1010deb:	jmp    1010d40 <myl_native_arena_trace+0xd0>
 1010df0:	add    $0x38,%rsp
 1010df4:	pop    %rbx
 1010df5:	pop    %r12
 1010df7:	pop    %r13
 1010df9:	pop    %r14
 1010dfb:	pop    %r15
 1010dfd:	pop    %rbp
 1010dfe:	ret
 1010dff:	int3

0000000001010e00 <myl_native_arena_discard>:
 1010e00:	push   %rbp
 1010e01:	mov    %rsp,%rbp
 1010e04:	test   %rdi,%rdi
 1010e07:	je     1010f33 <myl_native_arena_discard+0x133>
 1010e0d:	cmpq   $0x0,0x1608(%rdi)
 1010e15:	je     1010f33 <myl_native_arena_discard+0x133>
 1010e1b:	mov    0x11a0(%rdi),%rax
 1010e22:	test   %rax,%rax
 1010e25:	je     1010e50 <myl_native_arena_discard+0x50>
 1010e27:	mov    0x5c0(%rdi),%rcx
 1010e2e:	sub    %rax,%rcx
 1010e31:	add    $0xffffffffffffffb0,%rcx
 1010e35:	mov    %rcx,0x10(%rax)
 1010e39:	movq   $0x0,0x11a0(%rdi)
 1010e44:	vxorps %xmm0,%xmm0,%xmm0
 1010e48:	vmovups %xmm0,0x5c0(%rdi)
 1010e50:	mov    0x11e8(%rdi),%r8
 1010e57:	test   %r8,%r8
 1010e5a:	je     1010e70 <myl_native_arena_discard+0x70>
 1010e5c:	mov    0x4d8(%rdi),%rax
 1010e63:	test   $0x1,%r8b
 1010e67:	jne    1010e78 <myl_native_arena_discard+0x78>
 1010e69:	xor    %edx,%edx
 1010e6b:	mov    %r8,%rcx
 1010e6e:	jmp    1010eb5 <myl_native_arena_discard+0xb5>
 1010e70:	xor    %esi,%esi
 1010e72:	pop    %rbp
 1010e73:	jmp    1010f40 <rc_retire_chunks>
 1010e78:	lea    -0x1(%r8),%rcx
 1010e7c:	mov    -0x8(%rax,%r8,8),%rsi
 1010e81:	movq   $0x0,-0x8(%rax,%r8,8)
 1010e8a:	test   %rsi,%rsi
 1010e8d:	je     1010eb3 <myl_native_arena_discard+0xb3>
 1010e8f:	xor    %r9d,%r9d
 1010e92:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010ea0:	mov    %rsi,%rdx
 1010ea3:	mov    (%rsi),%rsi
 1010ea6:	mov    %r9,(%rdx)
 1010ea9:	mov    %rdx,%r9
 1010eac:	test   %rsi,%rsi
 1010eaf:	jne    1010ea0 <myl_native_arena_discard+0xa0>
 1010eb1:	jmp    1010eb5 <myl_native_arena_discard+0xb5>
 1010eb3:	xor    %edx,%edx
 1010eb5:	mov    %rdx,%rsi
 1010eb8:	cmp    $0x1,%r8
 1010ebc:	jne    1010edc <myl_native_arena_discard+0xdc>
 1010ebe:	movq   $0x0,0x11e8(%rdi)
 1010ec9:	pop    %rbp
 1010eca:	jmp    1010f40 <rc_retire_chunks>
 1010ecf:	nop
 1010ed0:	mov    %rdx,%rsi
 1010ed3:	mov    %rsi,%rdx
 1010ed6:	add    $0xfffffffffffffffe,%rcx
 1010eda:	je     1010ebe <myl_native_arena_discard+0xbe>
 1010edc:	mov    -0x8(%rax,%rcx,8),%rsi
 1010ee1:	movq   $0x0,-0x8(%rax,%rcx,8)
 1010eea:	test   %rsi,%rsi
 1010eed:	je     1010f01 <myl_native_arena_discard+0x101>
 1010eef:	nop
 1010ef0:	mov    (%rsi),%r8
 1010ef3:	mov    %rdx,(%rsi)
 1010ef6:	mov    %rsi,%rdx
 1010ef9:	mov    %r8,%rsi
 1010efc:	test   %r8,%r8
 1010eff:	jne    1010ef0 <myl_native_arena_discard+0xf0>
 1010f01:	mov    -0x10(%rax,%rcx,8),%r8
 1010f06:	movq   $0x0,-0x10(%rax,%rcx,8)
 1010f0f:	test   %r8,%r8
 1010f12:	je     1010ed0 <myl_native_arena_discard+0xd0>
 1010f14:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010f20:	mov    %r8,%rsi
 1010f23:	mov    (%r8),%r8
 1010f26:	mov    %rdx,(%rsi)
 1010f29:	mov    %rsi,%rdx
 1010f2c:	test   %r8,%r8
 1010f2f:	jne    1010f20 <myl_native_arena_discard+0x120>
 1010f31:	jmp    1010ed3 <myl_native_arena_discard+0xd3>
 1010f33:	call   101246d <myl_rc_invariant_failed>
 1010f38:	int3
 1010f39:	int3
 1010f3a:	int3
 1010f3b:	int3
 1010f3c:	int3
 1010f3d:	int3
 1010f3e:	int3
 1010f3f:	int3

0000000001010f40 <rc_retire_chunks>:
 1010f40:	test   %rsi,%rsi
 1010f43:	je     101104f <rc_retire_chunks+0x10f>
 1010f49:	push   %rbp
 1010f4a:	mov    %rsp,%rbp
 1010f4d:	push   %r15
 1010f4f:	push   %r14
 1010f51:	push   %rbx
 1010f52:	push   %rax
 1010f53:	mov    %rdi,%rbx
 1010f56:	mov    $0x200000,%r14d
 1010f5c:	jmp    1010f78 <rc_retire_chunks+0x38>
 1010f5e:	xchg   %ax,%ax
 1010f60:	sub    %rcx,0x18(%rbx)
 1010f64:	mov    %rsi,%rdi
 1010f67:	call   101edc0 <free@plt>
 1010f6c:	mov    %r15,%rsi
 1010f6f:	test   %r15,%r15
 1010f72:	je     1011045 <rc_retire_chunks+0x105>
 1010f78:	mov    (%rsi),%r15
 1010f7b:	mov    0x18(%rsi),%rax
 1010f7f:	sub    %rax,0x40(%rbx)
 1010f83:	mov    0x18(%rsi),%rax
 1010f87:	add    %rax,0x80(%rbx)
 1010f8e:	vmovdqu 0xa8(%rbx),%xmm0
 1010f96:	vmovdqa -0xe14e(%rip),%xmm1        # 1002e50 <qbe_empty_registry+0xa8>
 1010f9e:	vpinsrq $0x1,0x8(%rsi),%xmm1,%xmm1
 1010fa5:	vpsubq %xmm1,%xmm0,%xmm0
 1010fa9:	vmovdqu %xmm0,0xa8(%rbx)
 1010fb1:	mov    0x58(%rbx),%rax
 1010fb5:	cmp    $0x200000,%rax
 1010fbb:	mov    $0x200000,%ecx
 1010fc0:	cmovb  %rax,%rcx
 1010fc4:	test   %rax,%rax
 1010fc7:	mov    %rcx,%rdi
 1010fca:	cmove  %r14,%rdi
 1010fce:	cmpq   $0x0,0x1608(%rbx)
 1010fd6:	cmove  %rcx,%rdi
 1010fda:	mov    0x8(%rsi),%rcx
 1010fde:	cmp    $0x100000,%rcx
 1010fe5:	ja     1010f60 <rc_retire_chunks+0x20>
 1010feb:	mov    0xc0(%rbx),%rax
 1010ff2:	cmp    $0x3,%rax
 1010ff6:	ja     1010f60 <rc_retire_chunks+0x20>
 1010ffc:	mov    0xc8(%rbx),%rdx
 1011003:	sub    %rdx,%rdi
 1011006:	setbe  %r8b
 101100a:	cmp    %rdi,%rcx
 101100d:	seta   %dil
 1011011:	or     %r8b,%dil
 1011014:	jne    1010f60 <rc_retire_chunks+0x20>
 101101a:	mov    0x4e0(%rbx),%rcx
 1011021:	mov    %rcx,(%rsi)
 1011024:	mov    %rsi,0x4e0(%rbx)
 101102b:	inc    %rax
 101102e:	mov    %rax,0xc0(%rbx)
 1011035:	add    0x8(%rsi),%rdx
 1011039:	mov    %rdx,0xc8(%rbx)
 1011040:	jmp    1010f6c <rc_retire_chunks+0x2c>
 1011045:	add    $0x8,%rsp
 1011049:	pop    %rbx
 101104a:	pop    %r14
 101104c:	pop    %r15
 101104e:	pop    %rbp
 101104f:	ret

0000000001011050 <myl_native_arena_release>:
 1011050:	push   %rbp
 1011051:	mov    %rsp,%rbp
 1011054:	push   %r15
 1011056:	push   %r14
 1011058:	push   %r13
 101105a:	push   %r12
 101105c:	push   %rbx
 101105d:	push   %rax
 101105e:	mov    %rdi,%rbx
 1011061:	mov    0x11a0(%rdi),%rax
 1011068:	test   %rax,%rax
 101106b:	je     1011096 <myl_native_arena_release+0x46>
 101106d:	mov    0x5c0(%rbx),%rcx
 1011074:	sub    %rax,%rcx
 1011077:	add    $0xffffffffffffffb0,%rcx
 101107b:	mov    %rcx,0x10(%rax)
 101107f:	movq   $0x0,0x11a0(%rbx)
 101108a:	vpxor  %xmm0,%xmm0,%xmm0
 101108e:	vmovdqu %xmm0,0x5c0(%rbx)
 1011096:	cmpq   $0x0,0x1608(%rbx)
 101109e:	mov    %esi,%r15d
 10110a1:	mov    0x11e8(%rbx),%rcx
 10110a8:	je     10110d6 <myl_native_arena_release+0x86>
 10110aa:	cmp    %r15,%rcx
 10110ad:	jbe    1011243 <myl_native_arena_release+0x1f3>
 10110b3:	mov    0x4d8(%rbx),%rax
 10110ba:	mov    %ecx,%edx
 10110bc:	sub    %r15d,%edx
 10110bf:	lea    0x1(%r15),%r8
 10110c3:	test   $0x1,%dl
 10110c6:	jne    1011248 <myl_native_arena_release+0x1f8>
 10110cc:	xor    %edi,%edi
 10110ce:	mov    %rcx,%rdx
 10110d1:	jmp    1011285 <myl_native_arena_release+0x235>
 10110d6:	cmp    %r15,%rcx
 10110d9:	jbe    101120d <myl_native_arena_release+0x1bd>
 10110df:	mov    $0x200000,%r14d
 10110e5:	jmp    1011100 <myl_native_arena_release+0xb0>
 10110e7:	nopw   0x0(%rax,%rax,1)
 10110f0:	mov    0x11e8(%rbx),%rcx
 10110f7:	cmp    %r15,%rcx
 10110fa:	jbe    101120d <myl_native_arena_release+0x1bd>
 1011100:	lea    -0x1(%rcx),%rax
 1011104:	mov    %rax,0x11e8(%rbx)
 101110b:	mov    0x4d8(%rbx),%rdx
 1011112:	mov    -0x8(%rdx,%rcx,8),%rdi
 1011117:	movq   $0x0,-0x8(%rdx,%rcx,8)
 1011120:	mov    %rax,%rcx
 1011123:	test   %rdi,%rdi
 1011126:	jne    101113d <myl_native_arena_release+0xed>
 1011128:	jmp    10110f7 <myl_native_arena_release+0xa7>
 101112a:	nopw   0x0(%rax,%rax,1)
 1011130:	call   101edc0 <free@plt>
 1011135:	mov    %r12,%rdi
 1011138:	test   %r12,%r12
 101113b:	je     10110f0 <myl_native_arena_release+0xa0>
 101113d:	mov    (%rdi),%r12
 1011140:	mov    0x8(%rdi),%rax
 1011144:	sub    %rax,0x18(%rbx)
 1011148:	mov    0x18(%rdi),%rax
 101114c:	sub    %rax,0x40(%rbx)
 1011150:	mov    0x18(%rdi),%rax
 1011154:	add    %rax,0x80(%rbx)
 101115b:	vmovdqu 0xa8(%rbx),%xmm0
 1011163:	vmovdqa -0xe31b(%rip),%xmm1        # 1002e50 <qbe_empty_registry+0xa8>
 101116b:	vpinsrq $0x1,0x8(%rdi),%xmm1,%xmm1
 1011172:	vpsubq %xmm1,%xmm0,%xmm0
 1011176:	vmovdqu %xmm0,0xa8(%rbx)
 101117e:	mov    0x58(%rbx),%rax
 1011182:	cmp    $0x200000,%rax
 1011188:	mov    $0x200000,%ecx
 101118d:	cmovb  %rax,%rcx
 1011191:	test   %rax,%rax
 1011194:	mov    %rcx,%rax
 1011197:	cmove  %r14,%rax
 101119b:	cmpq   $0x0,0x1608(%rbx)
 10111a3:	cmove  %rcx,%rax
 10111a7:	mov    0x8(%rdi),%rsi
 10111ab:	cmp    $0x100000,%rsi
 10111b2:	ja     1011130 <myl_native_arena_release+0xe0>
 10111b8:	mov    0xc0(%rbx),%rcx
 10111bf:	cmp    $0x3,%rcx
 10111c3:	ja     1011130 <myl_native_arena_release+0xe0>
 10111c9:	mov    0xc8(%rbx),%rdx
 10111d0:	sub    %rdx,%rax
 10111d3:	jbe    1011130 <myl_native_arena_release+0xe0>
 10111d9:	cmp    %rax,%rsi
 10111dc:	ja     1011130 <myl_native_arena_release+0xe0>
 10111e2:	mov    0x4e0(%rbx),%rax
 10111e9:	mov    %rax,(%rdi)
 10111ec:	mov    %rdi,0x4e0(%rbx)
 10111f3:	inc    %rcx
 10111f6:	mov    %rcx,0xc0(%rbx)
 10111fd:	add    0x8(%rdi),%rdx
 1011201:	mov    %rdx,0xc8(%rbx)
 1011208:	jmp    1011135 <myl_native_arena_release+0xe5>
 101120d:	test   %rcx,%rcx
 1011210:	je     1011234 <myl_native_arena_release+0x1e4>
 1011212:	mov    0x4d8(%rbx),%rax
 1011219:	dec    %rcx
 101121c:	nopl   0x0(%rax)
 1011220:	cmpq   $0x0,(%rax,%rcx,8)
 1011225:	jne    1011234 <myl_native_arena_release+0x1e4>
 1011227:	mov    %rcx,0x11e8(%rbx)
 101122e:	add    $0xffffffffffffffff,%rcx
 1011232:	jb     1011220 <myl_native_arena_release+0x1d0>
 1011234:	add    $0x8,%rsp
 1011238:	pop    %rbx
 1011239:	pop    %r12
 101123b:	pop    %r13
 101123d:	pop    %r14
 101123f:	pop    %r15
 1011241:	pop    %rbp
 1011242:	ret
 1011243:	xor    %r14d,%r14d
 1011246:	jmp    1011298 <myl_native_arena_release+0x248>
 1011248:	lea    -0x1(%rcx),%rdx
 101124c:	mov    -0x8(%rax,%rcx,8),%r9
 1011251:	movq   $0x0,-0x8(%rax,%rcx,8)
 101125a:	test   %r9,%r9
 101125d:	je     1011283 <myl_native_arena_release+0x233>
 101125f:	xor    %r10d,%r10d
 1011262:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011270:	mov    %r9,%rdi
 1011273:	mov    (%r9),%r9
 1011276:	mov    %r10,(%rdi)
 1011279:	mov    %rdi,%r10
 101127c:	test   %r9,%r9
 101127f:	jne    1011270 <myl_native_arena_release+0x220>
 1011281:	jmp    1011285 <myl_native_arena_release+0x235>
 1011283:	xor    %edi,%edi
 1011285:	mov    %rdi,%r14
 1011288:	cmp    %r8,%rcx
 101128b:	jne    1011343 <myl_native_arena_release+0x2f3>
 1011291:	mov    %rdx,0x11e8(%rbx)
 1011298:	mov    0x70(%rbx),%r12d
 101129c:	cmp    $0x1,%esi
 101129f:	mov    %esi,%r13d
 10112a2:	adc    $0xffffffff,%r13d
 10112a6:	mov    %r13d,0x70(%rbx)
 10112aa:	mov    %rbx,%rdi
 10112ad:	call   1018c90 <myl_rc_scopes_close_region>
 10112b2:	test   %r14,%r14
 10112b5:	je     10112f5 <myl_native_arena_release+0x2a5>
 10112b7:	mov    %r14,%r15
 10112ba:	nopw   0x0(%rax,%rax,1)
 10112c0:	mov    %rbx,%rdi
 10112c3:	mov    %r15,%rsi
 10112c6:	mov    $0x1,%edx
 10112cb:	call   1011460 <release_pass>
 10112d0:	mov    (%r15),%r15
 10112d3:	test   %r15,%r15
 10112d6:	jne    10112c0 <myl_native_arena_release+0x270>
 10112d8:	mov    %r14,%r15
 10112db:	nopl   0x0(%rax,%rax,1)
 10112e0:	mov    %rbx,%rdi
 10112e3:	mov    %r15,%rsi
 10112e6:	xor    %edx,%edx
 10112e8:	call   1011460 <release_pass>
 10112ed:	mov    (%r15),%r15
 10112f0:	test   %r15,%r15
 10112f3:	jne    10112e0 <myl_native_arena_release+0x290>
 10112f5:	mov    %rbx,%rdi
 10112f8:	call   1016000 <myl_rc_drain>
 10112fd:	cmp    %r13d,0x70(%rbx)
 1011301:	jne    10113a3 <myl_native_arena_release+0x353>
 1011307:	mov    %r12d,0x70(%rbx)
 101130b:	mov    %rbx,%rdi
 101130e:	mov    %r14,%rsi
 1011311:	add    $0x8,%rsp
 1011315:	pop    %rbx
 1011316:	pop    %r12
 1011318:	pop    %r13
 101131a:	pop    %r14
 101131c:	pop    %r15
 101131e:	pop    %rbp
 101131f:	jmp    1010f40 <rc_retire_chunks>
 1011324:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011330:	mov    %rdi,%r14
 1011333:	add    $0xfffffffffffffffe,%rdx
 1011337:	mov    %r14,%rdi
 101133a:	cmp    %r15,%rdx
 101133d:	jbe    1011291 <myl_native_arena_release+0x241>
 1011343:	mov    -0x8(%rax,%rdx,8),%rcx
 1011348:	movq   $0x0,-0x8(%rax,%rdx,8)
 1011351:	test   %rcx,%rcx
 1011354:	je     1011371 <myl_native_arena_release+0x321>
 1011356:	cs nopw 0x0(%rax,%rax,1)
 1011360:	mov    (%rcx),%r8
 1011363:	mov    %rdi,(%rcx)
 1011366:	mov    %rcx,%rdi
 1011369:	mov    %r8,%rcx
 101136c:	test   %r8,%r8
 101136f:	jne    1011360 <myl_native_arena_release+0x310>
 1011371:	mov    -0x10(%rax,%rdx,8),%rcx
 1011376:	movq   $0x0,-0x10(%rax,%rdx,8)
 101137f:	test   %rcx,%rcx
 1011382:	je     1011330 <myl_native_arena_release+0x2e0>
 1011384:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011390:	mov    %rcx,%r14
 1011393:	mov    (%rcx),%rcx
 1011396:	mov    %rdi,(%r14)
 1011399:	mov    %r14,%rdi
 101139c:	test   %rcx,%rcx
 101139f:	jne    1011390 <myl_native_arena_release+0x340>
 10113a1:	jmp    1011333 <myl_native_arena_release+0x2e3>
 10113a3:	call   101246d <myl_rc_invariant_failed>
 10113a8:	int3
 10113a9:	int3
 10113aa:	int3
 10113ab:	int3
 10113ac:	int3
 10113ad:	int3
 10113ae:	int3
 10113af:	int3

00000000010113b0 <myl_native_arena_destroy>:
 10113b0:	push   %rbp
 10113b1:	mov    %rsp,%rbp
 10113b4:	push   %rbx
 10113b5:	push   %rax
 10113b6:	mov    %rdi,%rbx
 10113b9:	xor    %esi,%esi
 10113bb:	call   1011050 <myl_native_arena_release>
 10113c0:	jmp    10113d5 <myl_native_arena_destroy+0x25>
 10113c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10113d0:	call   101edc0 <free@plt>
 10113d5:	mov    0x4e0(%rbx),%rdi
 10113dc:	test   %rdi,%rdi
 10113df:	je     10113ff <myl_native_arena_destroy+0x4f>
 10113e1:	mov    (%rdi),%rax
 10113e4:	mov    %rax,0x4e0(%rbx)
 10113eb:	cmpq   $0x0,0x1608(%rbx)
 10113f3:	je     10113d0 <myl_native_arena_destroy+0x20>
 10113f5:	mov    0x8(%rdi),%rax
 10113f9:	sub    %rax,0x18(%rbx)
 10113fd:	jmp    10113d0 <myl_native_arena_destroy+0x20>
 10113ff:	vxorps %xmm0,%xmm0,%xmm0
 1011403:	vmovups %xmm0,0xc0(%rbx)
 101140b:	cmpq   $0x0,0x1608(%rbx)
 1011413:	mov    0x4d8(%rbx),%rsi
 101141a:	je     1011431 <myl_native_arena_destroy+0x81>
 101141c:	mov    0x11f0(%rbx),%rdx
 1011423:	shl    $0x3,%rdx
 1011427:	mov    %rbx,%rdi
 101142a:	call   1012500 <myl_rc_meta_free>
 101142f:	jmp    1011439 <myl_native_arena_destroy+0x89>
 1011431:	mov    %rsi,%rdi
 1011434:	call   101edc0 <free@plt>
 1011439:	movq   $0x0,0x4d8(%rbx)
 1011444:	movq   $0x0,0x11f0(%rbx)
 101144f:	add    $0x8,%rsp
 1011453:	pop    %rbx
 1011454:	pop    %rbp
 1011455:	ret
 1011456:	int3
 1011457:	int3
 1011458:	int3
 1011459:	int3
 101145a:	int3
 101145b:	int3
 101145c:	int3
 101145d:	int3
 101145e:	int3
 101145f:	int3

0000000001011460 <release_pass>:
 1011460:	push   %rbp
 1011461:	mov    %rsp,%rbp
 1011464:	push   %r15
 1011466:	push   %r14
 1011468:	push   %r13
 101146a:	push   %r12
 101146c:	push   %rbx
 101146d:	push   %rax
 101146e:	cmpq   $0x0,0x10(%rsi)
 1011473:	je     101157d <release_pass+0x11d>
 1011479:	mov    %edx,%ebx
 101147b:	mov    %rsi,%r14
 101147e:	lea    0x50(%rsi),%r12
 1011482:	xor    %r13d,%r13d
 1011485:	mov    $0x28,%r8d
 101148b:	mov    %rdi,-0x30(%rbp)
 101148f:	jmp    10114c5 <release_pass+0x65>
 1011491:	mov    0x8(%rax),%rsi
 1011495:	add    $0x10,%rdx
 1011499:	call   10159a0 <myl_rc_edges_release>
 101149e:	mov    -0x30(%rbp),%rdi
 10114a2:	mov    $0x28,%r8d
 10114a8:	nopl   0x0(%rax,%rax,1)
 10114b0:	add    %r15,%r13
 10114b3:	add    $0x1f,%r13
 10114b7:	and    $0xfffffffffffffff0,%r13
 10114bb:	cmp    0x10(%r14),%r13
 10114bf:	jae    101157d <release_pass+0x11d>
 10114c5:	mov    (%r12,%r13,1),%rax
 10114c9:	mov    0x8(%r12,%r13,1),%rsi
 10114ce:	bzhi   %r8,%rax,%rcx
 10114d3:	shr    $0x2,%rcx
 10114d7:	mov    (%rsi),%r15
 10114da:	imul   %rcx,%r15
 10114de:	cmp    $0x1,%r15
 10114e2:	adc    $0x0,%r15
 10114e6:	test   %ebx,%ebx
 10114e8:	je     10114ef <release_pass+0x8f>
 10114ea:	and    $0x1,%eax
 10114ed:	jne    10114b0 <release_pass+0x50>
 10114ef:	mov    0x1608(%rdi),%rdx
 10114f6:	mov    0x34(%rsi),%eax
 10114f9:	cmp    %rax,0xa0(%rdx)
 1011500:	jbe    101156e <release_pass+0x10e>
 1011502:	mov    0x98(%rdx),%rdx
 1011509:	shl    $0x4,%rax
 101150d:	cmp    %rsi,(%rdx,%rax,1)
 1011511:	jne    101156e <release_pass+0x10e>
 1011513:	add    %rax,%rdx
 1011516:	mov    0x8(%rdx),%rax
 101151a:	test   %rax,%rax
 101151d:	je     1011578 <release_pass+0x118>
 101151f:	lea    (%r12,%r13,1),%rdx
 1011523:	test   %ebx,%ebx
 1011525:	je     101154f <release_pass+0xef>
 1011527:	orb    $0x1,(%rdx)
 101152a:	mov    0x18(%rax),%rax
 101152e:	test   %rax,%rax
 1011531:	je     10114b0 <release_pass+0x50>
 1011537:	add    $0x10,%rdx
 101153b:	mov    %rdx,%rsi
 101153e:	call   *%rax
 1011540:	mov    $0x28,%r8d
 1011546:	mov    -0x30(%rbp),%rdi
 101154a:	jmp    10114b0 <release_pass+0x50>
 101154f:	mov    0x10(%rax),%r8
 1011553:	test   %r8,%r8
 1011556:	je     1011491 <release_pass+0x31>
 101155c:	add    $0x10,%rdx
 1011560:	mov    %rdx,%rsi
 1011563:	mov    %rcx,%rdx
 1011566:	call   *%r8
 1011569:	jmp    101149e <release_pass+0x3e>
 101156e:	call   1012eea <myl_rc_binding_find_slow>
 1011573:	test   %rax,%rax
 1011576:	jne    101151f <release_pass+0xbf>
 1011578:	call   101246d <myl_rc_invariant_failed>
 101157d:	add    $0x8,%rsp
 1011581:	pop    %rbx
 1011582:	pop    %r12
 1011584:	pop    %r13
 1011586:	pop    %r14
 1011588:	pop    %r15
 101158a:	pop    %rbp
 101158b:	ret
 101158c:	int3
 101158d:	int3
 101158e:	int3
 101158f:	int3

0000000001011590 <myl_native_list_new>:
 1011590:	push   %rbp
 1011591:	mov    %rsp,%rbp
 1011594:	push   %r15
 1011596:	push   %r14
 1011598:	push   %rbx
 1011599:	sub    $0x28,%rsp
 101159d:	test   %rsi,%rsi
 10115a0:	je     101165a <myl_native_list_new+0xca>
 10115a6:	mov    %rdi,%rbx
 10115a9:	test   %rdi,%rdi
 10115ac:	je     10115d0 <myl_native_list_new+0x40>
 10115ae:	cmpq   $0x0,0x1608(%rbx)
 10115b6:	je     10115d0 <myl_native_list_new+0x40>
 10115b8:	mov    0x70(%rbx),%ecx
 10115bb:	mov    %rbx,%rdi
 10115be:	xor    %r8d,%r8d
 10115c1:	add    $0x28,%rsp
 10115c5:	pop    %rbx
 10115c6:	pop    %r14
 10115c8:	pop    %r15
 10115ca:	pop    %rbp
 10115cb:	jmp    1011670 <rc_list_new>
 10115d0:	mov    %rsi,%r15
 10115d3:	mov    %rdx,%r14
 10115d6:	lea    0x1794b(%rip),%rsi        # 1028f28 <myl_native_list_header_descriptor>
 10115dd:	mov    $0x1,%edx
 10115e2:	mov    %rbx,%rdi
 10115e5:	call   100fc00 <myl_native_heap_alloc>
 10115ea:	mov    %rax,-0x20(%rbp)
 10115ee:	test   %rax,%rax
 10115f1:	je     101165a <myl_native_list_new+0xca>
 10115f3:	lea    -0xe42a(%rip),%rcx        # 10031d0 <myl_rc_pointer_leaf>
 10115fa:	lea    -0x40(%rbp),%rsi
 10115fe:	lea    -0x20(%rbp),%rdx
 1011602:	mov    %rbx,%rdi
 1011605:	call   100eb80 <myl_native_root_push>
 101160a:	mov    -0x20(%rbp),%rdx
 101160e:	mov    %r15,0x18(%rdx)
 1011612:	mov    %r14,%rcx
 1011615:	test   %r14,%r14
 1011618:	je     1011638 <myl_native_list_new+0xa8>
 101161a:	mov    %r15,%rsi
 101161d:	mov    %rbx,%rdi
 1011620:	mov    %r14,%rdx
 1011623:	call   100fc00 <myl_native_heap_alloc>
 1011628:	mov    %r14,%rcx
 101162b:	mov    -0x20(%rbp),%rdx
 101162f:	mov    %rax,0x20(%rdx)
 1011633:	test   %rax,%rax
 1011636:	je     101164e <myl_native_list_new+0xbe>
 1011638:	mov    %rcx,0x8(%rdx)
 101163c:	lea    -0x40(%rbp),%rsi
 1011640:	mov    %rbx,%rdi
 1011643:	call   100eba0 <myl_native_root_pop>
 1011648:	mov    -0x20(%rbp),%rax
 101164c:	jmp    101165c <myl_native_list_new+0xcc>
 101164e:	lea    -0x40(%rbp),%rsi
 1011652:	mov    %rbx,%rdi
 1011655:	call   100eba0 <myl_native_root_pop>
 101165a:	xor    %eax,%eax
 101165c:	add    $0x28,%rsp
 1011660:	pop    %rbx
 1011661:	pop    %r14
 1011663:	pop    %r15
 1011665:	pop    %rbp
 1011666:	ret
 1011667:	int3
 1011668:	int3
 1011669:	int3
 101166a:	int3
 101166b:	int3
 101166c:	int3
 101166d:	int3
 101166e:	int3
 101166f:	int3

0000000001011670 <rc_list_new>:
 1011670:	push   %rbp
 1011671:	mov    %rsp,%rbp
 1011674:	push   %r15
 1011676:	push   %r14
 1011678:	push   %r13
 101167a:	push   %r12
 101167c:	push   %rbx
 101167d:	push   %rax
 101167e:	mov    %r8d,%r13d
 1011681:	mov    %ecx,%r15d
 1011684:	mov    %rdx,%r14
 1011687:	mov    %rsi,%r12
 101168a:	mov    %rdi,%rbx
 101168d:	test   %r8d,%r8d
 1011690:	je     10116b0 <rc_list_new+0x40>
 1011692:	mov    0x1608(%rbx),%rax
 1011699:	cmpb   $0x0,0x120(%rax)
 10116a0:	je     10116d5 <rc_list_new+0x65>
 10116a2:	test   %r13d,%r13d
 10116a5:	jne    1011707 <rc_list_new+0x97>
 10116a7:	lea    0x1787a(%rip),%rsi        # 1028f28 <myl_native_list_header_descriptor>
 10116ae:	jmp    101170e <rc_list_new+0x9e>
 10116b0:	mov    0x1608(%rbx),%rax
 10116b7:	cmp    %r12,0x110(%rax)
 10116be:	je     1011692 <rc_list_new+0x22>
 10116c0:	mov    %rbx,%rdi
 10116c3:	mov    %r12,%rsi
 10116c6:	call   101d5a0 <myl_rc_native_shape>
 10116cb:	test   %rax,%rax
 10116ce:	jne    1011692 <rc_list_new+0x22>
 10116d0:	jmp    1011760 <rc_list_new+0xf0>
 10116d5:	lea    0x17964(%rip),%rsi        # 1029040 <rc_list_module>
 10116dc:	mov    %rbx,%rdi
 10116df:	call   1013410 <myl_rc_module_register>
 10116e4:	test   %eax,%eax
 10116e6:	je     10116f4 <rc_list_new+0x84>
 10116e8:	mov    %rbx,%rdi
 10116eb:	mov    %eax,%esi
 10116ed:	call   1012560 <myl_rc_record_failure>
 10116f2:	jmp    1011760 <rc_list_new+0xf0>
 10116f4:	mov    0x1608(%rbx),%rax
 10116fb:	movb   $0x1,0x120(%rax)
 1011702:	test   %r13d,%r13d
 1011705:	je     10116a7 <rc_list_new+0x37>
 1011707:	lea    -0xe7ce(%rip),%rsi        # 1002f40 <rc_storage_type>
 101170e:	mov    $0x1,%edx
 1011713:	mov    %rbx,%rdi
 1011716:	mov    %r15d,%ecx
 1011719:	call   101bc50 <myl_rc_storage_alloc>
 101171e:	test   %rax,%rax
 1011721:	je     1011760 <rc_list_new+0xf0>
 1011723:	mov    %r12,0x18(%rax)
 1011727:	test   %r14,%r14
 101172a:	je     101174f <rc_list_new+0xdf>
 101172c:	mov    %rbx,%rdi
 101172f:	mov    %r12,%rsi
 1011732:	mov    %r14,%rdx
 1011735:	mov    %r15d,%ecx
 1011738:	mov    %rax,%r15
 101173b:	call   101e3d0 <myl_rc_native_storage>
 1011740:	mov    %rax,%rcx
 1011743:	mov    %r15,%rax
 1011746:	mov    %rcx,0x20(%r15)
 101174a:	test   %rcx,%rcx
 101174d:	je     1011755 <rc_list_new+0xe5>
 101174f:	mov    %r14,0x8(%rax)
 1011753:	jmp    1011762 <rc_list_new+0xf2>
 1011755:	mov    %rbx,%rdi
 1011758:	mov    %rax,%rsi
 101175b:	call   101e440 <myl_rc_native_abort>
 1011760:	xor    %eax,%eax
 1011762:	add    $0x8,%rsp
 1011766:	pop    %rbx
 1011767:	pop    %r12
 1011769:	pop    %r13
 101176b:	pop    %r14
 101176d:	pop    %r15
 101176f:	pop    %rbp
 1011770:	ret
 1011771:	int3
 1011772:	int3
 1011773:	int3
 1011774:	int3
 1011775:	int3
 1011776:	int3
 1011777:	int3
 1011778:	int3
 1011779:	int3
 101177a:	int3
 101177b:	int3
 101177c:	int3
 101177d:	int3
 101177e:	int3
 101177f:	int3

0000000001011780 <myl_rc_list_append>:
 1011780:	push   %rbp
 1011781:	mov    %rsp,%rbp
 1011784:	mov    %rdx,%rcx
 1011787:	mov    (%rsi),%rdx
 101178a:	pop    %rbp
 101178b:	jmp    1011b20 <rc_list_insert_at>

0000000001011790 <rc_list_clone>:
 1011790:	push   %rbp
 1011791:	mov    %rsp,%rbp
 1011794:	push   %r15
 1011796:	push   %r14
 1011798:	push   %r13
 101179a:	push   %r12
 101179c:	push   %rbx
 101179d:	push   %rax
 101179e:	mov    %rdx,%r15
 10117a1:	mov    %rsi,%r14
 10117a4:	mov    %rdi,%r12
 10117a7:	mov    (%rsi),%rdx
 10117aa:	mov    0x8(%rsi),%rax
 10117ae:	cmp    %rdx,%rax
 10117b1:	cmova  %rax,%rdx
 10117b5:	mov    %r15,%rsi
 10117b8:	xor    %r8d,%r8d
 10117bb:	call   1011670 <rc_list_new>
 10117c0:	test   %rax,%rax
 10117c3:	je     1011872 <rc_list_clone+0xe2>
 10117c9:	mov    %rax,%rbx
 10117cc:	mov    (%r14),%rax
 10117cf:	test   %rax,%rax
 10117d2:	je     10118a2 <rc_list_clone+0x112>
 10117d8:	mov    (%r15),%rdx
 10117db:	test   %rdx,%rdx
 10117de:	je     1011839 <rc_list_clone+0xa9>
 10117e0:	mov    0x1608(%r12),%rcx
 10117e8:	cmp    %r15,0x110(%rcx)
 10117ef:	je     101188b <rc_list_clone+0xfb>
 10117f5:	mov    0x34(%r15),%eax
 10117f9:	cmp    %rax,0xa0(%rcx)
 1011800:	jbe    10118bc <rc_list_clone+0x12c>
 1011806:	mov    0x98(%rcx),%rcx
 101180d:	shl    $0x4,%rax
 1011811:	cmp    %r15,(%rcx,%rax,1)
 1011815:	jne    10118bc <rc_list_clone+0x12c>
 101181b:	add    %rax,%rcx
 101181e:	mov    0x8(%rcx),%rax
 1011822:	test   %rax,%rax
 1011825:	je     1011833 <rc_list_clone+0xa3>
 1011827:	cmpl   $0x0,0x40(%rax)
 101182b:	jne    1011833 <rc_list_clone+0xa3>
 101182d:	cmpb   $0x0,0x45(%rax)
 1011831:	je     1011876 <rc_list_clone+0xe6>
 1011833:	cmpq   $0x0,(%r14)
 1011837:	je     10118a2 <rc_list_clone+0x112>
 1011839:	xor    %r13d,%r13d
 101183c:	nopl   0x0(%rax)
 1011840:	mov    (%r15),%rcx
 1011843:	imul   %r13,%rcx
 1011847:	add    0x20(%r14),%rcx
 101184b:	mov    (%rbx),%rdx
 101184e:	mov    %r12,%rdi
 1011851:	mov    %rbx,%rsi
 1011854:	call   1011b20 <rc_list_insert_at>
 1011859:	test   %eax,%eax
 101185b:	je     1011867 <rc_list_clone+0xd7>
 101185d:	inc    %r13
 1011860:	cmp    (%r14),%r13
 1011863:	jb     1011840 <rc_list_clone+0xb0>
 1011865:	jmp    10118a2 <rc_list_clone+0x112>
 1011867:	mov    %r12,%rdi
 101186a:	mov    %rbx,%rsi
 101186d:	call   101e440 <myl_rc_native_abort>
 1011872:	xor    %ebx,%ebx
 1011874:	jmp    10118aa <rc_list_clone+0x11a>
 1011876:	mov    0x1608(%r12),%rax
 101187e:	mov    %r15,0x110(%rax)
 1011885:	mov    (%r14),%rax
 1011888:	mov    (%r15),%rdx
 101188b:	imul   %rax,%rdx
 101188f:	mov    0x20(%rbx),%rdi
 1011893:	mov    0x20(%r14),%rsi
 1011897:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101189c:	mov    (%r14),%rax
 101189f:	mov    %rax,(%rbx)
 10118a2:	movq   $0x0,0x10(%rbx)
 10118aa:	mov    %rbx,%rax
 10118ad:	add    $0x8,%rsp
 10118b1:	pop    %rbx
 10118b2:	pop    %r12
 10118b4:	pop    %r13
 10118b6:	pop    %r14
 10118b8:	pop    %r15
 10118ba:	pop    %rbp
 10118bb:	ret
 10118bc:	mov    %r12,%rdi
 10118bf:	mov    %r15,%rsi
 10118c2:	call   1012eea <myl_rc_binding_find_slow>
 10118c7:	test   %rax,%rax
 10118ca:	jne    1011827 <rc_list_clone+0x97>
 10118d0:	jmp    1011833 <rc_list_clone+0xa3>
 10118d5:	int3
 10118d6:	int3
 10118d7:	int3
 10118d8:	int3
 10118d9:	int3
 10118da:	int3
 10118db:	int3
 10118dc:	int3
 10118dd:	int3
 10118de:	int3
 10118df:	int3

00000000010118e0 <myl_native_list_header>:
 10118e0:	test   %rdi,%rdi
 10118e3:	je     10118fb <myl_native_list_header+0x1b>
 10118e5:	push   %rbp
 10118e6:	mov    %rsp,%rbp
 10118e9:	mov    -0x8(%rdi),%rcx
 10118ed:	xor    %eax,%eax
 10118ef:	cmp    $0x1028f28,%rcx
 10118f6:	sete   %al
 10118f9:	pop    %rbp
 10118fa:	ret
 10118fb:	xor    %eax,%eax
 10118fd:	ret
 10118fe:	int3
 10118ff:	int3

0000000001011900 <myl_rc_list_require>:
 1011900:	push   %rbp
 1011901:	mov    %rsp,%rbp
 1011904:	push   %rbx
 1011905:	push   %rax
 1011906:	mov    0x1608(%rdi),%rcx
 101190d:	xor    %eax,%eax
 101190f:	cmpb   $0x0,0x120(%rcx)
 1011916:	jne    101193b <myl_rc_list_require+0x3b>
 1011918:	lea    0x17721(%rip),%rsi        # 1029040 <rc_list_module>
 101191f:	mov    %rdi,%rbx
 1011922:	call   1013410 <myl_rc_module_register>
 1011927:	test   %eax,%eax
 1011929:	jne    101193b <myl_rc_list_require+0x3b>
 101192b:	mov    0x1608(%rbx),%rax
 1011932:	movb   $0x1,0x120(%rax)
 1011939:	xor    %eax,%eax
 101193b:	add    $0x8,%rsp
 101193f:	pop    %rbx
 1011940:	pop    %rbp
 1011941:	ret
 1011942:	int3
 1011943:	int3
 1011944:	int3
 1011945:	int3
 1011946:	int3
 1011947:	int3
 1011948:	int3
 1011949:	int3
 101194a:	int3
 101194b:	int3
 101194c:	int3
 101194d:	int3
 101194e:	int3
 101194f:	int3

0000000001011950 <myl_rc_list_storage_reserve>:
 1011950:	mov    0x8(%rsi),%rcx
 1011954:	mov    $0x1,%eax
 1011959:	cmp    %rcx,%rdx
 101195c:	jbe    1011b02 <myl_rc_list_storage_reserve+0x1b2>
 1011962:	push   %rbp
 1011963:	mov    %rsp,%rbp
 1011966:	push   %r15
 1011968:	push   %r14
 101196a:	push   %r13
 101196c:	push   %r12
 101196e:	push   %rbx
 101196f:	push   %rax
 1011970:	mov    %rsi,%rbx
 1011973:	cmp    $0x5,%rcx
 1011977:	mov    $0x4,%r14d
 101197d:	cmovae %rcx,%r14
 1011981:	cmp    $0x5,%rdx
 1011985:	jb     10119a1 <myl_rc_list_storage_reserve+0x51>
 1011987:	nopw   0x0(%rax,%rax,1)
 1011990:	test   %r14,%r14
 1011993:	js     1011af2 <myl_rc_list_storage_reserve+0x1a2>
 1011999:	add    %r14,%r14
 101199c:	cmp    %rdx,%r14
 101199f:	jb     1011990 <myl_rc_list_storage_reserve+0x40>
 10119a1:	mov    0x18(%rbx),%rsi
 10119a5:	mov    (%rsi),%rcx
 10119a8:	test   %rcx,%rcx
 10119ab:	je     10119b9 <myl_rc_list_storage_reserve+0x69>
 10119ad:	mov    %rcx,%rax
 10119b0:	mul    %r14
 10119b3:	jo     1011af2 <myl_rc_list_storage_reserve+0x1a2>
 10119b9:	mov    0x20(%rbx),%r15
 10119bd:	mov    0x1608(%rdi),%rdx
 10119c4:	cmp    %rsi,0x110(%rdx)
 10119cb:	je     1011a6a <myl_rc_list_storage_reserve+0x11a>
 10119d1:	mov    0x34(%rsi),%eax
 10119d4:	cmp    %rax,0xa0(%rdx)
 10119db:	jbe    1011b03 <myl_rc_list_storage_reserve+0x1b3>
 10119e1:	mov    0x98(%rdx),%rcx
 10119e8:	shl    $0x4,%rax
 10119ec:	cmp    %rsi,(%rcx,%rax,1)
 10119f0:	jne    1011b03 <myl_rc_list_storage_reserve+0x1b3>
 10119f6:	add    %rax,%rcx
 10119f9:	mov    0x8(%rcx),%rax
 10119fd:	test   %rax,%rax
 1011a00:	je     1011a0e <myl_rc_list_storage_reserve+0xbe>
 1011a02:	cmpl   $0x0,0x40(%rax)
 1011a06:	jne    1011a0e <myl_rc_list_storage_reserve+0xbe>
 1011a08:	cmpb   $0x0,0x45(%rax)
 1011a0c:	je     1011a55 <myl_rc_list_storage_reserve+0x105>
 1011a0e:	mov    0x18(%rbx),%rax
 1011a12:	mov    (%rax),%rdx
 1011a15:	imul   %r14,%rdx
 1011a19:	mov    %rdi,%r12
 1011a1c:	mov    %r15,%rsi
 1011a1f:	call   101c8c0 <myl_rc_storage_extend>
 1011a24:	test   %rax,%rax
 1011a27:	jne    1011a81 <myl_rc_list_storage_reserve+0x131>
 1011a29:	mov    -0x10(%rbx),%rax
 1011a2d:	mov    0x18(%rbx),%rsi
 1011a31:	mov    %rax,%rdx
 1011a34:	shr    $0x28,%rdx
 1011a38:	and    $0xfffff,%edx
 1011a3e:	xor    %ecx,%ecx
 1011a40:	bt     $0x3e,%rax
 1011a45:	cmovb  %edx,%ecx
 1011a48:	mov    %r12,%rdi
 1011a4b:	mov    %r14,%rdx
 1011a4e:	call   101e3d0 <myl_rc_native_storage>
 1011a53:	jmp    1011ab5 <myl_rc_list_storage_reserve+0x165>
 1011a55:	mov    0x1608(%rdi),%rax
 1011a5c:	mov    %rsi,0x110(%rax)
 1011a63:	mov    0x18(%rbx),%rax
 1011a67:	mov    (%rax),%rcx
 1011a6a:	imul   %r14,%rcx
 1011a6e:	mov    %rdi,%r12
 1011a71:	mov    %r15,%rsi
 1011a74:	mov    %rcx,%rdx
 1011a77:	call   101ca80 <myl_rc_storage_extend_opaque>
 1011a7c:	test   %rax,%rax
 1011a7f:	je     1011a87 <myl_rc_list_storage_reserve+0x137>
 1011a81:	mov    %rax,0x20(%rbx)
 1011a85:	jmp    1011ae7 <myl_rc_list_storage_reserve+0x197>
 1011a87:	mov    -0x10(%rbx),%rax
 1011a8b:	mov    0x18(%rbx),%rcx
 1011a8f:	mov    (%rcx),%rsi
 1011a92:	imul   %r14,%rsi
 1011a96:	mov    %rax,%rcx
 1011a99:	shr    $0x28,%rcx
 1011a9d:	and    $0xfffff,%ecx
 1011aa3:	xor    %edx,%edx
 1011aa5:	bt     $0x3e,%rax
 1011aaa:	cmovb  %ecx,%edx
 1011aad:	mov    %r12,%rdi
 1011ab0:	call   101c8b0 <myl_rc_storage_block>
 1011ab5:	mov    %rax,%r13
 1011ab8:	test   %rax,%rax
 1011abb:	je     1011af2 <myl_rc_list_storage_reserve+0x1a2>
 1011abd:	mov    (%rbx),%rdx
 1011ac0:	test   %rdx,%rdx
 1011ac3:	je     1011ad8 <myl_rc_list_storage_reserve+0x188>
 1011ac5:	mov    0x18(%rbx),%rax
 1011ac9:	imul   (%rax),%rdx
 1011acd:	mov    %r13,%rdi
 1011ad0:	mov    %r15,%rsi
 1011ad3:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1011ad8:	mov    %r13,0x20(%rbx)
 1011adc:	mov    %r12,%rdi
 1011adf:	mov    %r15,%rsi
 1011ae2:	call   1012ac0 <myl_rc_owner_release>
 1011ae7:	mov    $0x1,%eax
 1011aec:	mov    %r14,0x8(%rbx)
 1011af0:	jmp    1011af4 <myl_rc_list_storage_reserve+0x1a4>
 1011af2:	xor    %eax,%eax
 1011af4:	add    $0x8,%rsp
 1011af8:	pop    %rbx
 1011af9:	pop    %r12
 1011afb:	pop    %r13
 1011afd:	pop    %r14
 1011aff:	pop    %r15
 1011b01:	pop    %rbp
 1011b02:	ret
 1011b03:	call   1012eea <myl_rc_binding_find_slow>
 1011b08:	test   %rax,%rax
 1011b0b:	jne    1011a02 <myl_rc_list_storage_reserve+0xb2>
 1011b11:	jmp    1011a0e <myl_rc_list_storage_reserve+0xbe>
 1011b16:	int3
 1011b17:	int3
 1011b18:	int3
 1011b19:	int3
 1011b1a:	int3
 1011b1b:	int3
 1011b1c:	int3
 1011b1d:	int3
 1011b1e:	int3
 1011b1f:	int3

0000000001011b20 <rc_list_insert_at>:
 1011b20:	push   %rbp
 1011b21:	mov    %rsp,%rbp
 1011b24:	push   %r15
 1011b26:	push   %r14
 1011b28:	push   %r13
 1011b2a:	push   %r12
 1011b2c:	push   %rbx
 1011b2d:	sub    $0xa8,%rsp
 1011b34:	xor    %r12d,%r12d
 1011b37:	cmpq   $0xffffffffffffffff,0x10(%rsi)
 1011b3c:	je     1011ce4 <rc_list_insert_at+0x1c4>
 1011b42:	mov    %rsi,%rbx
 1011b45:	mov    (%rsi),%r15
 1011b48:	cmp    $0xffffffffffffffff,%r15
 1011b4c:	je     1011ce4 <rc_list_insert_at+0x1c4>
 1011b52:	mov    0x18(%rbx),%rax
 1011b56:	mov    (%rax),%rsi
 1011b59:	cmp    %r15,%rdx
 1011b5c:	mov    %rdx,-0x50(%rbp)
 1011b60:	mov    %rdi,-0x38(%rbp)
 1011b64:	jne    1011b80 <rc_list_insert_at+0x60>
 1011b66:	test   %rsi,%rsi
 1011b69:	je     1011bc2 <rc_list_insert_at+0xa2>
 1011b6b:	mov    0x1608(%rdi),%rax
 1011b72:	cmpq   $0x0,0xc8(%rax)
 1011b7a:	je     1011cf9 <rc_list_insert_at+0x1d9>
 1011b80:	cmp    $0x81,%rsi
 1011b87:	jae    1011b96 <rc_list_insert_at+0x76>
 1011b89:	lea    -0xd0(%rbp),%rax
 1011b90:	mov    %rax,-0x40(%rbp)
 1011b94:	jmp    1011bcf <rc_list_insert_at+0xaf>
 1011b96:	mov    %rcx,%r14
 1011b99:	xor    %r12d,%r12d
 1011b9c:	mov    %rsi,%r13
 1011b9f:	xor    %edx,%edx
 1011ba1:	call   101c6d0 <myl_rc_storage_bytes>
 1011ba6:	mov    %rax,-0x40(%rbp)
 1011baa:	test   %rax,%rax
 1011bad:	je     1011ce4 <rc_list_insert_at+0x1c4>
 1011bb3:	mov    (%rbx),%r15
 1011bb6:	mov    %r14,%rcx
 1011bb9:	mov    -0x38(%rbp),%rdi
 1011bbd:	mov    %r13,%rsi
 1011bc0:	jmp    1011bcf <rc_list_insert_at+0xaf>
 1011bc2:	lea    -0xd0(%rbp),%rax
 1011bc9:	mov    %rax,-0x40(%rbp)
 1011bcd:	xor    %esi,%esi
 1011bcf:	mov    %rsi,-0x30(%rbp)
 1011bd3:	mov    -0x10(%rbx),%rax
 1011bd7:	mov    0x20(%rbx),%rdx
 1011bdb:	mov    %rax,%r14
 1011bde:	shr    $0x28,%r14
 1011be2:	and    $0xfffff,%r14d
 1011be9:	xor    %r12d,%r12d
 1011bec:	bt     $0x3e,%rax
 1011bf1:	cmovae %r12d,%r14d
 1011bf5:	test   %rdx,%rdx
 1011bf8:	sete   %al
 1011bfb:	mov    %rcx,-0x48(%rbp)
 1011bff:	mov    %rcx,%r13
 1011c02:	sub    %rdx,%r13
 1011c05:	setb   %cl
 1011c08:	or     %al,%cl
 1011c0a:	je     1011c23 <rc_list_insert_at+0x103>
 1011c0c:	inc    %r15
 1011c0f:	mov    %rbx,%rsi
 1011c12:	mov    %r15,%rdx
 1011c15:	call   1011950 <myl_rc_list_storage_reserve>
 1011c1a:	test   %eax,%eax
 1011c1c:	jne    1011c49 <rc_list_insert_at+0x129>
 1011c1e:	jmp    1011cc8 <rc_list_insert_at+0x1a8>
 1011c23:	lea    0x1(%r15),%rdx
 1011c27:	mov    %rbx,%rsi
 1011c2a:	call   1011950 <myl_rc_list_storage_reserve>
 1011c2f:	test   %eax,%eax
 1011c31:	je     1011cc8 <rc_list_insert_at+0x1a8>
 1011c37:	imul   -0x30(%rbp),%r15
 1011c3c:	cmp    %r15,%r13
 1011c3f:	jae    1011c49 <rc_list_insert_at+0x129>
 1011c41:	add    0x20(%rbx),%r13
 1011c45:	mov    %r13,-0x48(%rbp)
 1011c49:	mov    0x18(%rbx),%rsi
 1011c4d:	mov    -0x38(%rbp),%rdi
 1011c51:	mov    -0x40(%rbp),%r13
 1011c55:	mov    %r13,%rdx
 1011c58:	mov    -0x48(%rbp),%rcx
 1011c5c:	mov    %r14d,%r8d
 1011c5f:	call   101dec0 <myl_rc_native_retain>
 1011c64:	test   %eax,%eax
 1011c66:	je     1011ccc <rc_list_insert_at+0x1ac>
 1011c68:	mov    %eax,%r14d
 1011c6b:	mov    (%rbx),%rdx
 1011c6e:	mov    0x20(%rbx),%r15
 1011c72:	mov    -0x50(%rbp),%rax
 1011c76:	sub    %rax,%rdx
 1011c79:	jbe    1011ca1 <rc_list_insert_at+0x181>
 1011c7b:	lea    0x1(%rax),%rdi
 1011c7f:	mov    -0x30(%rbp),%rcx
 1011c83:	imul   %rcx,%rdi
 1011c87:	add    %r15,%rdi
 1011c8a:	mov    %rcx,%rsi
 1011c8d:	imul   %rax,%rsi
 1011c91:	add    %r15,%rsi
 1011c94:	imul   %rcx,%rdx
 1011c98:	call   101e610 <compiler_rt.memmove.memmoveFast>
 1011c9d:	mov    -0x50(%rbp),%rax
 1011ca1:	mov    -0x30(%rbp),%rdx
 1011ca5:	test   %rdx,%rdx
 1011ca8:	je     1011cbc <rc_list_insert_at+0x19c>
 1011caa:	imul   %rdx,%rax
 1011cae:	add    %rax,%r15
 1011cb1:	mov    %r15,%rdi
 1011cb4:	mov    %r13,%rsi
 1011cb7:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1011cbc:	incq   (%rbx)
 1011cbf:	incq   0x10(%rbx)
 1011cc3:	mov    %r14d,%r12d
 1011cc6:	jmp    1011ccc <rc_list_insert_at+0x1ac>
 1011cc8:	mov    -0x40(%rbp),%r13
 1011ccc:	lea    -0xd0(%rbp),%rax
 1011cd3:	cmp    %rax,%r13
 1011cd6:	je     1011ce4 <rc_list_insert_at+0x1c4>
 1011cd8:	mov    -0x38(%rbp),%rdi
 1011cdc:	mov    %r13,%rsi
 1011cdf:	call   1012ac0 <myl_rc_owner_release>
 1011ce4:	mov    %r12d,%eax
 1011ce7:	add    $0xa8,%rsp
 1011cee:	pop    %rbx
 1011cef:	pop    %r12
 1011cf1:	pop    %r13
 1011cf3:	pop    %r14
 1011cf5:	pop    %r15
 1011cf7:	pop    %rbp
 1011cf8:	ret
 1011cf9:	mov    0x20(%rbx),%rax
 1011cfd:	mov    %rsi,%r14
 1011d00:	imul   %rdx,%r14
 1011d04:	test   %rax,%rax
 1011d07:	sete   %r8b
 1011d0b:	mov    %rcx,%r13
 1011d0e:	sub    %rax,%r13
 1011d11:	setb   %al
 1011d14:	or     %r8b,%al
 1011d17:	je     1011d3e <rc_list_insert_at+0x21e>
 1011d19:	mov    %rsi,%r13
 1011d1c:	mov    %rcx,%r15
 1011d1f:	inc    %rdx
 1011d22:	mov    %rbx,%rsi
 1011d25:	call   1011950 <myl_rc_list_storage_reserve>
 1011d2a:	test   %eax,%eax
 1011d2c:	je     1011ce4 <rc_list_insert_at+0x1c4>
 1011d2e:	mov    0x20(%rbx),%rdx
 1011d32:	mov    %r15,%rcx
 1011d35:	mov    -0x38(%rbp),%rdi
 1011d39:	mov    %r13,%r9
 1011d3c:	jmp    1011d93 <rc_list_insert_at+0x273>
 1011d3e:	cmp    %r14,%r13
 1011d41:	setb   %r8b
 1011d45:	jb     1011d58 <rc_list_insert_at+0x238>
 1011d47:	mov    0x8(%rbx),%rax
 1011d4b:	imul   %rsi,%rax
 1011d4f:	cmp    %rax,%r13
 1011d52:	jb     1011b80 <rc_list_insert_at+0x60>
 1011d58:	mov    %r8d,%r15d
 1011d5b:	mov    %rsi,-0x30(%rbp)
 1011d5f:	mov    %rcx,-0x48(%rbp)
 1011d63:	inc    %rdx
 1011d66:	mov    %rbx,%rsi
 1011d69:	call   1011950 <myl_rc_list_storage_reserve>
 1011d6e:	test   %eax,%eax
 1011d70:	je     1011ce4 <rc_list_insert_at+0x1c4>
 1011d76:	mov    0x20(%rbx),%rdx
 1011d7a:	test   %r15b,%r15b
 1011d7d:	je     1011d87 <rc_list_insert_at+0x267>
 1011d7f:	add    %rdx,%r13
 1011d82:	mov    %r13,%rcx
 1011d85:	jmp    1011d8b <rc_list_insert_at+0x26b>
 1011d87:	mov    -0x48(%rbp),%rcx
 1011d8b:	mov    -0x38(%rbp),%rdi
 1011d8f:	mov    -0x30(%rbp),%r9
 1011d93:	add    %r14,%rdx
 1011d96:	lea    (%rcx,%r9,1),%rax
 1011d9a:	cmp    %rdx,%rax
 1011d9d:	jbe    1011dac <rc_list_insert_at+0x28c>
 1011d9f:	lea    (%r9,%rdx,1),%rax
 1011da3:	cmp    %rcx,%rax
 1011da6:	ja     1011e65 <rc_list_insert_at+0x345>
 1011dac:	mov    0x18(%rbx),%rsi
 1011db0:	mov    0x1608(%rdi),%r8
 1011db7:	cmp    %rsi,0x110(%r8)
 1011dbe:	je     1011e37 <rc_list_insert_at+0x317>
 1011dc0:	mov    0x34(%rsi),%eax
 1011dc3:	cmp    %rax,0xa0(%r8)
 1011dca:	jbe    1011e59 <rc_list_insert_at+0x339>
 1011dd0:	mov    0x98(%r8),%r8
 1011dd7:	shl    $0x4,%rax
 1011ddb:	cmp    %rsi,(%r8,%rax,1)
 1011ddf:	jne    1011e59 <rc_list_insert_at+0x339>
 1011de1:	add    %rax,%r8
 1011de4:	mov    0x8(%r8),%rax
 1011de8:	test   %rax,%rax
 1011deb:	je     1011df9 <rc_list_insert_at+0x2d9>
 1011ded:	cmpl   $0x0,0x40(%rax)
 1011df1:	jne    1011df9 <rc_list_insert_at+0x2d9>
 1011df3:	cmpb   $0x0,0x45(%rax)
 1011df7:	je     1011e29 <rc_list_insert_at+0x309>
 1011df9:	mov    -0x10(%rbx),%rax
 1011dfd:	mov    0x18(%rbx),%rsi
 1011e01:	mov    %rax,%r8
 1011e04:	shr    $0x28,%r8
 1011e08:	and    $0xfffff,%r8d
 1011e0f:	xor    %r12d,%r12d
 1011e12:	bt     $0x3e,%rax
 1011e17:	cmovae %r12d,%r8d
 1011e1b:	call   101dec0 <myl_rc_native_retain>
 1011e20:	test   %eax,%eax
 1011e22:	jne    1011e4a <rc_list_insert_at+0x32a>
 1011e24:	jmp    1011ce4 <rc_list_insert_at+0x1c4>
 1011e29:	mov    0x1608(%rdi),%rax
 1011e30:	mov    %rsi,0x110(%rax)
 1011e37:	mov    %rdx,%rdi
 1011e3a:	mov    %rcx,%rsi
 1011e3d:	mov    %r9,%rdx
 1011e40:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1011e45:	mov    $0x1,%eax
 1011e4a:	incq   (%rbx)
 1011e4d:	incq   0x10(%rbx)
 1011e51:	mov    %eax,%r12d
 1011e54:	jmp    1011ce4 <rc_list_insert_at+0x1c4>
 1011e59:	call   1012eea <myl_rc_binding_find_slow>
 1011e5e:	test   %rax,%rax
 1011e61:	jne    1011ded <rc_list_insert_at+0x2cd>
 1011e63:	jmp    1011df9 <rc_list_insert_at+0x2d9>
 1011e65:	call   101246d <myl_rc_invariant_failed>
 1011e6a:	int3
 1011e6b:	int3
 1011e6c:	int3
 1011e6d:	int3
 1011e6e:	int3
 1011e6f:	int3

0000000001011e70 <rc_elements_release>:
 1011e70:	push   %rbp
 1011e71:	mov    %rsp,%rbp
 1011e74:	mov    0x1608(%rdi),%r8
 1011e7b:	mov    0x34(%rsi),%eax
 1011e7e:	cmp    %rax,0xa0(%r8)
 1011e85:	jbe    1011ed8 <rc_elements_release+0x68>
 1011e87:	mov    0x98(%r8),%r8
 1011e8e:	shl    $0x4,%rax
 1011e92:	cmp    %rsi,(%r8,%rax,1)
 1011e96:	jne    1011ed8 <rc_elements_release+0x68>
 1011e98:	add    %rax,%r8
 1011e9b:	mov    0x8(%r8),%rsi
 1011e9f:	test   %rsi,%rsi
 1011ea2:	je     1011ee5 <rc_elements_release+0x75>
 1011ea4:	mov    0x40(%rsi),%eax
 1011ea7:	test   %eax,%eax
 1011ea9:	je     1011eb6 <rc_elements_release+0x46>
 1011eab:	cmp    $0x11,%eax
 1011eae:	jb     1011ebc <rc_elements_release+0x4c>
 1011eb0:	mov    0x8(%rsi),%rax
 1011eb4:	jmp    1011ecd <rc_elements_release+0x5d>
 1011eb6:	cmpb   $0x0,0x45(%rsi)
 1011eba:	je     1011ed6 <rc_elements_release+0x66>
 1011ebc:	mov    0x8(%rsi),%rax
 1011ec0:	cmpq   $0x3,0x28(%rax)
 1011ec5:	jb     1011ecd <rc_elements_release+0x5d>
 1011ec7:	pop    %rbp
 1011ec8:	jmp    1015e50 <myl_rc_flat_edges_release>
 1011ecd:	mov    %rax,%rsi
 1011ed0:	pop    %rbp
 1011ed1:	jmp    10159a0 <myl_rc_edges_release>
 1011ed6:	pop    %rbp
 1011ed7:	ret
 1011ed8:	call   1012eea <myl_rc_binding_find_slow>
 1011edd:	mov    %rax,%rsi
 1011ee0:	test   %rsi,%rsi
 1011ee3:	jne    1011ea4 <rc_elements_release+0x34>
 1011ee5:	call   101efe0 <abort@plt>
 1011eea:	int3
 1011eeb:	int3
 1011eec:	int3
 1011eed:	int3
 1011eee:	int3
 1011eef:	int3

0000000001011ef0 <rc_list_edges>:
 1011ef0:	cmpq   $0x0,(%rsi)
 1011ef4:	je     1011f69 <rc_list_edges+0x79>
 1011ef6:	push   %rbp
 1011ef7:	mov    %rsp,%rbp
 1011efa:	push   %r14
 1011efc:	push   %rbx
 1011efd:	mov    0x18(%rsi),%rcx
 1011f01:	mov    0x1608(%rdi),%rdx
 1011f08:	cmp    %rcx,0x110(%rdx)
 1011f0f:	je     1011f65 <rc_list_edges+0x75>
 1011f11:	mov    0x34(%rcx),%eax
 1011f14:	cmp    %rax,0xa0(%rdx)
 1011f1b:	jbe    1011f82 <rc_list_edges+0x92>
 1011f1d:	mov    0x98(%rdx),%rdx
 1011f24:	shl    $0x4,%rax
 1011f28:	cmp    %rcx,(%rdx,%rax,1)
 1011f2c:	jne    1011f82 <rc_list_edges+0x92>
 1011f2e:	add    %rax,%rdx
 1011f31:	mov    0x8(%rdx),%rax
 1011f35:	test   %rax,%rax
 1011f38:	je     1011f46 <rc_list_edges+0x56>
 1011f3a:	cmpl   $0x0,0x40(%rax)
 1011f3e:	jne    1011f46 <rc_list_edges+0x56>
 1011f40:	cmpb   $0x0,0x45(%rax)
 1011f44:	je     1011f72 <rc_list_edges+0x82>
 1011f46:	mov    (%rsi),%rcx
 1011f49:	mov    0x18(%rsi),%rax
 1011f4d:	mov    0x20(%rsi),%rdx
 1011f51:	mov    %rdi,%rbx
 1011f54:	mov    %rsi,%r14
 1011f57:	mov    %rax,%rsi
 1011f5a:	call   1011e70 <rc_elements_release>
 1011f5f:	mov    %r14,%rsi
 1011f62:	mov    %rbx,%rdi
 1011f65:	pop    %rbx
 1011f66:	pop    %r14
 1011f68:	pop    %rbp
 1011f69:	mov    0x20(%rsi),%rsi
 1011f6d:	jmp    10129a0 <myl_rc_edge_release>
 1011f72:	mov    0x1608(%rdi),%rax
 1011f79:	mov    %rcx,0x110(%rax)
 1011f80:	jmp    1011f65 <rc_list_edges+0x75>
 1011f82:	mov    %rsi,%rdx
 1011f85:	mov    %rcx,%rsi
 1011f88:	call   1012eea <myl_rc_binding_find_slow>
 1011f8d:	mov    %rdx,%rsi
 1011f90:	test   %rax,%rax
 1011f93:	jne    1011f3a <rc_list_edges+0x4a>
 1011f95:	jmp    1011f46 <rc_list_edges+0x56>
 1011f97:	int3
 1011f98:	int3
 1011f99:	int3
 1011f9a:	int3
 1011f9b:	int3
 1011f9c:	int3
 1011f9d:	int3
 1011f9e:	int3
 1011f9f:	int3

0000000001011fa0 <rc_list_clone_adapter>:
 1011fa0:	push   %rbp
 1011fa1:	mov    %rsp,%rbp
 1011fa4:	push   %r14
 1011fa6:	push   %rbx
 1011fa7:	mov    %rcx,%rbx
 1011faa:	mov    %edx,%ecx
 1011fac:	mov    %rdi,%r14
 1011faf:	mov    0x18(%rsi),%rdx
 1011fb3:	call   1011790 <rc_list_clone>
 1011fb8:	mov    %rax,(%rbx)
 1011fbb:	mov    %r14,%rdi
 1011fbe:	mov    %rax,%rsi
 1011fc1:	pop    %rbx
 1011fc2:	pop    %r14
 1011fc4:	pop    %rbp
 1011fc5:	jmp    101e400 <myl_rc_native_result>
 1011fca:	int3
 1011fcb:	int3
 1011fcc:	int3
 1011fcd:	int3
 1011fce:	int3
 1011fcf:	int3

0000000001011fd0 <rc_list_shell>:
 1011fd0:	push   %rbp
 1011fd1:	mov    %rsp,%rbp
 1011fd4:	push   %r15
 1011fd6:	push   %r14
 1011fd8:	push   %r12
 1011fda:	push   %rbx
 1011fdb:	mov    %rcx,%r12
 1011fde:	mov    %edx,%ecx
 1011fe0:	mov    %rsi,%rbx
 1011fe3:	mov    %rdi,%r14
 1011fe6:	mov    (%rsi),%rdx
 1011fe9:	mov    0x8(%rsi),%rax
 1011fed:	cmp    %rdx,%rax
 1011ff0:	cmova  %rax,%rdx
 1011ff4:	mov    0x18(%rsi),%rsi
 1011ff8:	xor    %r8d,%r8d
 1011ffb:	call   1011670 <rc_list_new>
 1012000:	mov    %rax,(%r12)
 1012004:	test   %rax,%rax
 1012007:	je     1012061 <rc_list_shell+0x91>
 1012009:	mov    %rax,%r15
 101200c:	mov    0x18(%rbx),%rsi
 1012010:	mov    0x1608(%r14),%rcx
 1012017:	mov    0x34(%rsi),%eax
 101201a:	cmp    %rax,0xa0(%rcx)
 1012021:	jbe    1012083 <rc_list_shell+0xb3>
 1012023:	mov    0x98(%rcx),%rcx
 101202a:	shl    $0x4,%rax
 101202e:	cmp    %rsi,(%rcx,%rax,1)
 1012032:	jne    1012083 <rc_list_shell+0xb3>
 1012034:	add    %rax,%rcx
 1012037:	mov    0x8(%rcx),%rax
 101203b:	test   %rax,%rax
 101203e:	je     1012090 <rc_list_shell+0xc0>
 1012040:	mov    (%rbx),%r8
 1012043:	test   %r8,%r8
 1012046:	je     1012073 <rc_list_shell+0xa3>
 1012048:	mov    0x8(%rax),%rsi
 101204c:	mov    0x20(%r15),%rdx
 1012050:	mov    0x20(%rbx),%rcx
 1012054:	mov    %r14,%rdi
 1012057:	call   1016a40 <myl_rc_value_seed>
 101205c:	mov    (%rbx),%rax
 101205f:	jmp    1012075 <rc_list_shell+0xa5>
 1012061:	mov    %r14,%rdi
 1012064:	xor    %esi,%esi
 1012066:	pop    %rbx
 1012067:	pop    %r12
 1012069:	pop    %r14
 101206b:	pop    %r15
 101206d:	pop    %rbp
 101206e:	jmp    101e400 <myl_rc_native_result>
 1012073:	xor    %eax,%eax
 1012075:	mov    %rax,(%r15)
 1012078:	xor    %eax,%eax
 101207a:	pop    %rbx
 101207b:	pop    %r12
 101207d:	pop    %r14
 101207f:	pop    %r15
 1012081:	pop    %rbp
 1012082:	ret
 1012083:	mov    %r14,%rdi
 1012086:	call   1012eea <myl_rc_binding_find_slow>
 101208b:	test   %rax,%rax
 101208e:	jne    1012040 <rc_list_shell+0x70>
 1012090:	call   101efe0 <abort@plt>
 1012095:	int3
 1012096:	int3
 1012097:	int3
 1012098:	int3
 1012099:	int3
 101209a:	int3
 101209b:	int3
 101209c:	int3
 101209d:	int3
 101209e:	int3
 101209f:	int3

00000000010120a0 <rc_list_next>:
 10120a0:	push   %rbp
 10120a1:	mov    %rsp,%rbp
 10120a4:	push   %r14
 10120a6:	push   %rbx
 10120a7:	mov    0x18(%rsi),%rax
 10120ab:	mov    0x1608(%rdi),%r11
 10120b2:	mov    0x34(%rax),%r10d
 10120b6:	cmp    %r10,0xa0(%r11)
 10120bd:	jbe    1012194 <rc_list_next+0xf4>
 10120c3:	mov    0x98(%r11),%r11
 10120ca:	shl    $0x4,%r10
 10120ce:	cmp    %rax,(%r11,%r10,1)
 10120d2:	jne    1012194 <rc_list_next+0xf4>
 10120d8:	add    %r10,%r11
 10120db:	mov    0x8(%r11),%rax
 10120df:	test   %rax,%rax
 10120e2:	je     10121ab <rc_list_next+0x10b>
 10120e8:	mov    (%rcx),%r10
 10120eb:	xor    %edi,%edi
 10120ed:	cmp    (%rsi),%r10
 10120f0:	jae    101218d <rc_list_next+0xed>
 10120f6:	mov    0x8(%rax),%r11
 10120fa:	cmpl   $0x0,0x8(%r11)
 10120ff:	je     101218d <rc_list_next+0xed>
 1012105:	lea    0x1(%r10),%rdi
 1012109:	mov    %rdi,(%rcx)
 101210c:	mov    0x18(%rsi),%rcx
 1012110:	imul   (%rcx),%r10
 1012114:	mov    0x20(%rdx),%rcx
 1012118:	add    %r10,%rcx
 101211b:	mov    -0x10(%rdx),%rdi
 101211f:	mov    %rdi,%rbx
 1012122:	shr    $0x28,%rbx
 1012126:	and    $0xfffff,%ebx
 101212c:	xor    %r14d,%r14d
 101212f:	bt     $0x3e,%rdi
 1012134:	cmovae %r14d,%ebx
 1012138:	mov    %r11,(%r8)
 101213b:	mov    %rcx,0x8(%r8)
 101213f:	mov    %rdx,0x10(%r8)
 1012143:	mov    %ebx,0x18(%r8)
 1012147:	movl   $0x0,0x1c(%r8)
 101214f:	mov    0x8(%rax),%rax
 1012153:	add    0x20(%rsi),%r10
 1012157:	mov    -0x10(%rsi),%rcx
 101215b:	mov    %rcx,%rdx
 101215e:	shr    $0x28,%rdx
 1012162:	and    $0xfffff,%edx
 1012168:	bt     $0x3e,%rcx
 101216d:	cmovae %r14d,%edx
 1012171:	mov    %rax,(%r9)
 1012174:	mov    %r10,0x8(%r9)
 1012178:	mov    %rsi,0x10(%r9)
 101217c:	mov    %edx,0x18(%r9)
 1012180:	movl   $0x0,0x1c(%r9)
 1012188:	mov    $0x1,%edi
 101218d:	mov    %edi,%eax
 101218f:	pop    %rbx
 1012190:	pop    %r14
 1012192:	pop    %rbp
 1012193:	ret
 1012194:	mov    %rsi,%r10
 1012197:	mov    %rax,%rsi
 101219a:	call   1012eea <myl_rc_binding_find_slow>
 101219f:	mov    %r10,%rsi
 10121a2:	test   %rax,%rax
 10121a5:	jne    10120e8 <rc_list_next+0x48>
 10121ab:	call   101efe0 <abort@plt>

00000000010121b0 <rc_list_span>:
 10121b0:	push   %rbp
 10121b1:	mov    %rsp,%rbp
 10121b4:	push   %r15
 10121b6:	push   %r14
 10121b8:	push   %rbx
 10121b9:	push   %rax
 10121ba:	mov    %rcx,%rbx
 10121bd:	mov    %rsi,%r14
 10121c0:	mov    (%rcx),%r15
 10121c3:	call   10120a0 <rc_list_next>
 10121c8:	test   %eax,%eax
 10121ca:	je     10121e6 <rc_list_span+0x36>
 10121cc:	mov    0x10(%rbp),%rax
 10121d0:	mov    (%r14),%rcx
 10121d3:	sub    %r15,%rcx
 10121d6:	mov    %rcx,(%rax)
 10121d9:	mov    (%r14),%rax
 10121dc:	mov    %rax,(%rbx)
 10121df:	mov    $0x1,%eax
 10121e4:	jmp    10121e8 <rc_list_span+0x38>
 10121e6:	xor    %eax,%eax
 10121e8:	add    $0x8,%rsp
 10121ec:	pop    %rbx
 10121ed:	pop    %r14
 10121ef:	pop    %r15
 10121f1:	pop    %rbp
 10121f2:	ret
 10121f3:	int3
 10121f4:	int3
 10121f5:	int3
 10121f6:	int3
 10121f7:	int3
 10121f8:	int3
 10121f9:	int3
 10121fa:	int3
 10121fb:	int3
 10121fc:	int3
 10121fd:	int3
 10121fe:	int3
 10121ff:	int3

0000000001012200 <rc_storage_edges>:
 1012200:	push   %rbp
 1012201:	mov    %rsp,%rbp
 1012204:	mov    0x20(%rsi),%rsi
 1012208:	pop    %rbp
 1012209:	jmp    10129a0 <myl_rc_edge_release>
 101220e:	int3
 101220f:	int3

0000000001012210 <myl_native_text_valid_utf8>:
 1012210:	test   %rsi,%rsi
 1012213:	je     101236f <myl_native_text_valid_utf8+0x15f>
 1012219:	push   %rbp
 101221a:	mov    %rsp,%rbp
 101221d:	push   %r15
 101221f:	push   %r14
 1012221:	push   %r12
 1012223:	push   %rbx
 1012224:	xor    %ecx,%ecx
 1012226:	jmp    1012246 <myl_native_text_valid_utf8+0x36>
 1012228:	nopl   0x0(%rax,%rax,1)
 1012230:	dec    %edx
 1012232:	lea    (%rcx,%rdx,1),%r10
 1012236:	add    $0x2,%r10
 101223a:	mov    %r10,%rcx
 101223d:	cmp    %rsi,%r10
 1012240:	je     1012375 <myl_native_text_valid_utf8+0x165>
 1012246:	lea    0x1(%rcx),%r10
 101224a:	movzbl (%rdi,%rcx,1),%r9d
 101224f:	test   %r9b,%r9b
 1012252:	jns    101223a <myl_native_text_valid_utf8+0x2a>
 1012254:	lea    0x3e(%r9),%r11d
 1012258:	xor    %eax,%eax
 101225a:	cmp    $0x1e,%r11b
 101225e:	jae    1012275 <myl_native_text_valid_utf8+0x65>
 1012260:	mov    $0x80,%r8d
 1012266:	mov    $0x1,%edx
 101226b:	mov    $0x1f,%ebx
 1012270:	xor    %r14d,%r14d
 1012273:	jmp    10122b5 <myl_native_text_valid_utf8+0xa5>
 1012275:	mov    %r9d,%edx
 1012278:	and    $0xf0,%dl
 101227b:	cmp    $0xe0,%dl
 101227e:	jne    1012295 <myl_native_text_valid_utf8+0x85>
 1012280:	mov    $0x800,%r8d
 1012286:	mov    $0x2,%edx
 101228b:	mov    $0x1,%r14b
 101228e:	mov    $0xf,%ebx
 1012293:	jmp    10122b5 <myl_native_text_valid_utf8+0xa5>
 1012295:	lea    0x10(%r9),%edx
 1012299:	xor    %r14d,%r14d
 101229c:	cmp    $0x4,%dl
 101229f:	ja     1012383 <myl_native_text_valid_utf8+0x173>
 10122a5:	mov    $0x10000,%r8d
 10122ab:	mov    $0x3,%edx
 10122b0:	mov    $0x7,%ebx
 10122b5:	mov    %edx,%r15d
 10122b8:	mov    %rsi,%r12
 10122bb:	sub    %r10,%r12
 10122be:	cmp    %r15,%r12
 10122c1:	jb     101237a <myl_native_text_valid_utf8+0x16a>
 10122c7:	movzbl 0x1(%rdi,%rcx,1),%r10d
 10122cd:	mov    %r10d,%r15d
 10122d0:	and    $0xffffffc0,%r15d
 10122d4:	cmp    $0x80,%r15d
 10122db:	jne    101237a <myl_native_text_valid_utf8+0x16a>
 10122e1:	and    %r9d,%ebx
 10122e4:	shl    $0x6,%ebx
 10122e7:	and    $0x3f,%r10d
 10122eb:	or     %ebx,%r10d
 10122ee:	cmp    $0x1e,%r11b
 10122f2:	jb     1012320 <myl_native_text_valid_utf8+0x110>
 10122f4:	movzbl 0x2(%rdi,%rcx,1),%r9d
 10122fa:	mov    %r9d,%r11d
 10122fd:	and    $0xffffffc0,%r11d
 1012301:	cmp    $0x80,%r11d
 1012308:	jne    101237a <myl_native_text_valid_utf8+0x16a>
 101230a:	shl    $0x6,%r10d
 101230e:	and    $0x3f,%r9d
 1012312:	or     %r10d,%r9d
 1012315:	test   %r14b,%r14b
 1012318:	je     1012341 <myl_native_text_valid_utf8+0x131>
 101231a:	mov    %r10d,%ebx
 101231d:	mov    %r9d,%r10d
 1012320:	cmp    $0x10ffff,%ebx
 1012326:	ja     101237a <myl_native_text_valid_utf8+0x16a>
 1012328:	cmp    %r8d,%r10d
 101232b:	jb     101237a <myl_native_text_valid_utf8+0x16a>
 101232d:	add    $0xffff2000,%ebx
 1012333:	cmp    $0xfffff7ff,%ebx
 1012339:	jbe    1012230 <myl_native_text_valid_utf8+0x20>
 101233f:	jmp    101237a <myl_native_text_valid_utf8+0x16a>
 1012341:	movzbl 0x3(%rdi,%rcx,1),%r10d
 1012347:	mov    %r10d,%r11d
 101234a:	and    $0xffffffc0,%r11d
 101234e:	cmp    $0x80,%r11d
 1012355:	jne    101237a <myl_native_text_valid_utf8+0x16a>
 1012357:	shl    $0x6,%r9d
 101235b:	and    $0x3f,%r10d
 101235f:	or     %r9d,%r10d
 1012362:	mov    %r9d,%ebx
 1012365:	cmp    $0x10ffff,%ebx
 101236b:	jbe    1012328 <myl_native_text_valid_utf8+0x118>
 101236d:	jmp    101237a <myl_native_text_valid_utf8+0x16a>
 101236f:	mov    $0x1,%eax
 1012374:	ret
 1012375:	mov    $0x1,%eax
 101237a:	pop    %rbx
 101237b:	pop    %r12
 101237d:	pop    %r14
 101237f:	pop    %r15
 1012381:	pop    %rbp
 1012382:	ret
 1012383:	xor    %eax,%eax
 1012385:	jmp    101237a <myl_native_text_valid_utf8+0x16a>
 1012387:	int3
 1012388:	int3
 1012389:	int3
 101238a:	int3
 101238b:	int3
 101238c:	int3
 101238d:	int3
 101238e:	int3
 101238f:	int3

0000000001012390 <myl_native_dictionary_header>:
 1012390:	push   %rbp
 1012391:	mov    %rsp,%rbp
 1012394:	test   %rdi,%rdi
 1012397:	je     10123ba <myl_native_dictionary_header+0x2a>
 1012399:	mov    -0x8(%rdi),%rcx
 101239d:	lea    0x16cc4(%rip),%rax        # 1029068 <dict_type>
 10123a4:	cmp    %rax,%rcx
 10123a7:	je     10123be <myl_native_dictionary_header+0x2e>
 10123a9:	lea    -0xf3d8(%rip),%rdx        # 1002fd8 <rc_dict_type>
 10123b0:	xor    %eax,%eax
 10123b2:	cmp    %rdx,%rcx
 10123b5:	sete   %al
 10123b8:	pop    %rbp
 10123b9:	ret
 10123ba:	xor    %eax,%eax
 10123bc:	pop    %rbp
 10123bd:	ret
 10123be:	mov    $0x1,%eax
 10123c3:	pop    %rbp
 10123c4:	ret
 10123c5:	int3
 10123c6:	int3
 10123c7:	int3
 10123c8:	int3
 10123c9:	int3
 10123ca:	int3
 10123cb:	int3
 10123cc:	int3
 10123cd:	int3
 10123ce:	int3
 10123cf:	int3

00000000010123d0 <myl_rc_owner_take>:
 10123d0:	xor    %eax,%eax
 10123d2:	test   %rdi,%rdi
 10123d5:	je     10123ea <myl_rc_owner_take+0x1a>
 10123d7:	mov    -0x10(%rdi),%rcx
 10123db:	movabs $0x4000000000000002,%rdx
 10123e5:	test   %rdx,%rcx
 10123e8:	je     10123eb <myl_rc_owner_take+0x1b>
 10123ea:	ret
 10123eb:	test   $0x1,%cl
 10123ee:	jne    1012414 <myl_rc_owner_take+0x44>
 10123f0:	mov    -0x20(%rdi),%rcx
 10123f4:	cmp    $0xffffffffffffffff,%rcx
 10123f8:	je     101240e <myl_rc_owner_take+0x3e>
 10123fa:	test   %rcx,%rcx
 10123fd:	jne    1012406 <myl_rc_owner_take+0x36>
 10123ff:	cmpq   $0x0,-0x18(%rdi)
 1012404:	je     1012414 <myl_rc_owner_take+0x44>
 1012406:	inc    %rcx
 1012409:	mov    %rcx,-0x20(%rdi)
 101240d:	ret
 101240e:	mov    $0x2,%eax
 1012413:	ret
 1012414:	push   %rbp
 1012415:	mov    %rsp,%rbp
 1012418:	call   101246d <myl_rc_invariant_failed>
 101241d:	int3
 101241e:	int3
 101241f:	int3

0000000001012420 <myl_rc_owner_take>:
 1012420:	xor    %eax,%eax
 1012422:	test   %rdi,%rdi
 1012425:	je     101243a <myl_rc_owner_take+0x1a>
 1012427:	mov    -0x10(%rdi),%rcx
 101242b:	movabs $0x4000000000000002,%rdx
 1012435:	test   %rdx,%rcx
 1012438:	je     101243b <myl_rc_owner_take+0x1b>
 101243a:	ret
 101243b:	test   $0x1,%cl
 101243e:	jne    1012464 <myl_rc_owner_take+0x44>
 1012440:	mov    -0x20(%rdi),%rcx
 1012444:	cmp    $0xffffffffffffffff,%rcx
 1012448:	je     101245e <myl_rc_owner_take+0x3e>
 101244a:	test   %rcx,%rcx
 101244d:	jne    1012456 <myl_rc_owner_take+0x36>
 101244f:	cmpq   $0x0,-0x18(%rdi)
 1012454:	je     1012464 <myl_rc_owner_take+0x44>
 1012456:	inc    %rcx
 1012459:	mov    %rcx,-0x20(%rdi)
 101245d:	ret
 101245e:	mov    $0x2,%eax
 1012463:	ret
 1012464:	push   %rbp
 1012465:	mov    %rsp,%rbp
 1012468:	call   101246d <myl_rc_invariant_failed>

000000000101246d <myl_rc_invariant_failed>:
 101246d:	push   %rbp
 101246e:	mov    %rsp,%rbp
 1012471:	call   101efe0 <abort@plt>
 1012476:	int3
 1012477:	int3
 1012478:	int3
 1012479:	int3
 101247a:	int3
 101247b:	int3
 101247c:	int3
 101247d:	int3
 101247e:	int3
 101247f:	int3

0000000001012480 <myl_rc_meta_alloc>:
 1012480:	push   %rbp
 1012481:	mov    %rsp,%rbp
 1012484:	push   %r15
 1012486:	push   %r14
 1012488:	push   %r12
 101248a:	push   %rbx
 101248b:	test   %rdi,%rdi
 101248e:	je     10124f1 <myl_rc_meta_alloc+0x71>
 1012490:	test   %rsi,%rsi
 1012493:	je     10124f1 <myl_rc_meta_alloc+0x71>
 1012495:	mov    0x1608(%rdi),%rbx
 101249c:	test   %rbx,%rbx
 101249f:	je     10124f1 <myl_rc_meta_alloc+0x71>
 10124a1:	mov    0x18(%rdi),%r14
 10124a5:	add    %rsi,%r14
 10124a8:	jb     10124c0 <myl_rc_meta_alloc+0x40>
 10124aa:	mov    0x58(%rdi),%rax
 10124ae:	test   %rax,%rax
 10124b1:	setne  %cl
 10124b4:	cmp    %rax,%r14
 10124b7:	seta   %al
 10124ba:	and    %cl,%al
 10124bc:	cmp    $0x1,%al
 10124be:	jne    10124d2 <myl_rc_meta_alloc+0x52>
 10124c0:	movl   $0x1,0x6c(%rdi)
 10124c7:	xor    %eax,%eax
 10124c9:	pop    %rbx
 10124ca:	pop    %r12
 10124cc:	pop    %r14
 10124ce:	pop    %r15
 10124d0:	pop    %rbp
 10124d1:	ret
 10124d2:	mov    %rdi,%r15
 10124d5:	mov    $0x1,%edi
 10124da:	mov    %rsi,%r12
 10124dd:	call   101ed70 <calloc@plt>
 10124e2:	test   %rax,%rax
 10124e5:	je     10124c7 <myl_rc_meta_alloc+0x47>
 10124e7:	mov    %r14,0x18(%r15)
 10124eb:	add    %r12,0x30(%rbx)
 10124ef:	jmp    10124c9 <myl_rc_meta_alloc+0x49>
 10124f1:	call   101246d <myl_rc_invariant_failed>
 10124f6:	int3
 10124f7:	int3
 10124f8:	int3
 10124f9:	int3
 10124fa:	int3
 10124fb:	int3
 10124fc:	int3
 10124fd:	int3
 10124fe:	int3
 10124ff:	int3

0000000001012500 <myl_rc_meta_free>:
 1012500:	test   %rsi,%rsi
 1012503:	je     101252e <myl_rc_meta_free+0x2e>
 1012505:	mov    0x18(%rdi),%rax
 1012509:	sub    %rdx,%rax
 101250c:	jb     101252f <myl_rc_meta_free+0x2f>
 101250e:	mov    0x1608(%rdi),%rcx
 1012515:	mov    0x30(%rcx),%r8
 1012519:	sub    %rdx,%r8
 101251c:	jb     101252f <myl_rc_meta_free+0x2f>
 101251e:	mov    %rax,0x18(%rdi)
 1012522:	mov    %r8,0x30(%rcx)
 1012526:	mov    %rsi,%rdi
 1012529:	jmp    101edc0 <free@plt>
 101252e:	ret
 101252f:	push   %rbp
 1012530:	mov    %rsp,%rbp
 1012533:	call   101246d <myl_rc_invariant_failed>
 1012538:	int3
 1012539:	int3
 101253a:	int3
 101253b:	int3
 101253c:	int3
 101253d:	int3
 101253e:	int3
 101253f:	int3

0000000001012540 <myl_rc_status_code>:
 1012540:	cmp    $0x4,%edi
 1012543:	jae    1012553 <myl_rc_status_code+0x13>
 1012545:	mov    %edi,%eax
 1012547:	lea    0x16bc2(%rip),%rcx        # 1029110 <dict_fields+0x30>
 101254e:	mov    (%rcx,%rax,8),%rax
 1012552:	ret
 1012553:	push   %rbp
 1012554:	mov    %rsp,%rbp
 1012557:	call   101efe0 <abort@plt>
 101255c:	int3
 101255d:	int3
 101255e:	int3
 101255f:	int3

0000000001012560 <myl_rc_record_failure>:
 1012560:	test   %rdi,%rdi
 1012563:	je     1012582 <myl_rc_record_failure+0x22>
 1012565:	mov    0x1608(%rdi),%rax
 101256c:	test   %rax,%rax
 101256f:	je     1012582 <myl_rc_record_failure+0x22>
 1012571:	cmpl   $0x0,0x124(%rax)
 1012578:	je     101257b <myl_rc_record_failure+0x1b>
 101257a:	ret
 101257b:	mov    %esi,0x124(%rax)
 1012581:	ret
 1012582:	push   %rbp
 1012583:	mov    %rsp,%rbp
 1012586:	call   101246d <myl_rc_invariant_failed>
 101258b:	int3
 101258c:	int3
 101258d:	int3
 101258e:	int3
 101258f:	int3

0000000001012590 <myl_rc_take_failure>:
 1012590:	test   %rdi,%rdi
 1012593:	je     10125b2 <myl_rc_take_failure+0x22>
 1012595:	mov    0x1608(%rdi),%rcx
 101259c:	test   %rcx,%rcx
 101259f:	je     10125b2 <myl_rc_take_failure+0x22>
 10125a1:	mov    0x124(%rcx),%eax
 10125a7:	movl   $0x0,0x124(%rcx)
 10125b1:	ret
 10125b2:	push   %rbp
 10125b3:	mov    %rsp,%rbp
 10125b6:	call   101246d <myl_rc_invariant_failed>
 10125bb:	int3
 10125bc:	int3
 10125bd:	int3
 10125be:	int3
 10125bf:	int3

00000000010125c0 <myl_rc_heap_init>:
 10125c0:	push   %rbp
 10125c1:	mov    %rsp,%rbp
 10125c4:	push   %r15
 10125c6:	push   %r14
 10125c8:	push   %r12
 10125ca:	push   %rbx
 10125cb:	test   %rdi,%rdi
 10125ce:	je     1012686 <myl_rc_heap_init+0xc6>
 10125d4:	test   %rsi,%rsi
 10125d7:	je     1012686 <myl_rc_heap_init+0xc6>
 10125dd:	cmpq   $0x0,0x1608(%rdi)
 10125e5:	jne    1012686 <myl_rc_heap_init+0xc6>
 10125eb:	cmpq   $0x0,(%rsi)
 10125ef:	je     1012686 <myl_rc_heap_init+0xc6>
 10125f5:	cmpq   $0x0,0x8(%rsi)
 10125fa:	je     1012686 <myl_rc_heap_init+0xc6>
 1012600:	mov    $0x128,%ebx
 1012605:	add    0x18(%rdi),%rbx
 1012609:	jb     1012621 <myl_rc_heap_init+0x61>
 101260b:	mov    0x58(%rdi),%rax
 101260f:	test   %rax,%rax
 1012612:	setne  %cl
 1012615:	cmp    %rax,%rbx
 1012618:	seta   %al
 101261b:	and    %cl,%al
 101261d:	cmp    $0x1,%al
 101261f:	jne    1012636 <myl_rc_heap_init+0x76>
 1012621:	movl   $0x1,0x6c(%rdi)
 1012628:	mov    $0x1,%eax
 101262d:	pop    %rbx
 101262e:	pop    %r12
 1012630:	pop    %r14
 1012632:	pop    %r15
 1012634:	pop    %rbp
 1012635:	ret
 1012636:	mov    %rsi,%r12
 1012639:	mov    %rdx,%r15
 101263c:	mov    %rdi,%r14
 101263f:	mov    $0x1,%edi
 1012644:	mov    $0x128,%esi
 1012649:	call   101ed70 <calloc@plt>
 101264e:	test   %rax,%rax
 1012651:	je     1012628 <myl_rc_heap_init+0x68>
 1012653:	vmovups (%r12),%ymm0
 1012659:	vmovups %ymm0,(%rax)
 101265d:	mov    %r15,0x20(%rax)
 1012661:	movq   $0x128,0x30(%rax)
 1012669:	mov    %rax,%rdi
 101266c:	mov    %rax,%r15
 101266f:	vzeroupper
 1012672:	call   1012d70 <myl_rc_metadata_init>
 1012677:	mov    %rbx,0x18(%r14)
 101267b:	mov    %r15,0x1608(%r14)
 1012682:	xor    %eax,%eax
 1012684:	jmp    101262d <myl_rc_heap_init+0x6d>
 1012686:	call   101246d <myl_rc_invariant_failed>
 101268b:	int3
 101268c:	int3
 101268d:	int3
 101268e:	int3
 101268f:	int3

0000000001012690 <myl_rc_heap_destroy>:
 1012690:	push   %rbp
 1012691:	mov    %rsp,%rbp
 1012694:	push   %r14
 1012696:	push   %rbx
 1012697:	cmpq   $0x0,0x1608(%rdi)
 101269f:	je     10127b0 <myl_rc_heap_destroy+0x120>
 10126a5:	mov    %rdi,%rbx
 10126a8:	call   1016000 <myl_rc_drain>
 10126ad:	mov    0x1608(%rbx),%r14
 10126b4:	cmpq   $0x0,0xf8(%r14)
 10126bc:	jne    10127b5 <myl_rc_heap_destroy+0x125>
 10126c2:	cmpq   $0x0,0xc0(%r14)
 10126ca:	jne    10127b5 <myl_rc_heap_destroy+0x125>
 10126d0:	cmpl   $0x0,0xd0(%r14)
 10126d8:	jne    10127b5 <myl_rc_heap_destroy+0x125>
 10126de:	mov    %rbx,%rdi
 10126e1:	call   1018b10 <myl_rc_scope_spares_release>
 10126e6:	mov    0x10(%r14),%rax
 10126ea:	test   %rax,%rax
 10126ed:	je     1012739 <myl_rc_heap_destroy+0xa9>
 10126ef:	mov    %rbx,%rdi
 10126f2:	call   *%rax
 10126f4:	jmp    1012739 <myl_rc_heap_destroy+0xa9>
 10126f6:	cs nopw 0x0(%rax,%rax,1)
 1012700:	mov    (%rdi),%rax
 1012703:	mov    %rax,0x28(%r14)
 1012707:	mov    0x30(%rdi),%rcx
 101270b:	mov    0x18(%rbx),%rax
 101270f:	sub    %rcx,%rax
 1012712:	jb     10127b5 <myl_rc_heap_destroy+0x125>
 1012718:	mov    0x1608(%rbx),%rdx
 101271f:	mov    0x30(%rdx),%rsi
 1012723:	sub    %rcx,%rsi
 1012726:	jb     10127b5 <myl_rc_heap_destroy+0x125>
 101272c:	mov    %rax,0x18(%rbx)
 1012730:	mov    %rsi,0x30(%rdx)
 1012734:	call   101edc0 <free@plt>
 1012739:	mov    0x28(%r14),%rdi
 101273d:	test   %rdi,%rdi
 1012740:	jne    1012700 <myl_rc_heap_destroy+0x70>
 1012742:	mov    0xb0(%r14),%rdi
 1012749:	test   %rdi,%rdi
 101274c:	je     1012783 <myl_rc_heap_destroy+0xf3>
 101274e:	mov    0xb8(%r14),%rax
 1012755:	shl    $0x3,%rax
 1012759:	lea    (%rax,%rax,2),%rcx
 101275d:	mov    0x18(%rbx),%rax
 1012761:	sub    %rcx,%rax
 1012764:	jb     10127b5 <myl_rc_heap_destroy+0x125>
 1012766:	mov    0x1608(%rbx),%rdx
 101276d:	mov    0x30(%rdx),%rsi
 1012771:	sub    %rcx,%rsi
 1012774:	jb     10127b5 <myl_rc_heap_destroy+0x125>
 1012776:	mov    %rax,0x18(%rbx)
 101277a:	mov    %rsi,0x30(%rdx)
 101277e:	call   101edc0 <free@plt>
 1012783:	mov    %rbx,%rdi
 1012786:	call   1012dc0 <myl_rc_metadata_release>
 101278b:	cmpq   $0x128,0x30(%r14)
 1012793:	jne    10127b5 <myl_rc_heap_destroy+0x125>
 1012795:	addq   $0xfffffffffffffed8,0x18(%rbx)
 101279d:	mov    %r14,%rdi
 10127a0:	call   101edc0 <free@plt>
 10127a5:	movq   $0x0,0x1608(%rbx)
 10127b0:	pop    %rbx
 10127b1:	pop    %r14
 10127b3:	pop    %rbp
 10127b4:	ret
 10127b5:	call   101246d <myl_rc_invariant_failed>
 10127ba:	int3
 10127bb:	int3
 10127bc:	int3
 10127bd:	int3
 10127be:	int3
 10127bf:	int3

00000000010127c0 <myl_rc_heap_teardown>:
 10127c0:	push   %rbp
 10127c1:	mov    %rsp,%rbp
 10127c4:	push   %r14
 10127c6:	push   %rbx
 10127c7:	mov    0x1608(%rdi),%r14
 10127ce:	test   %r14,%r14
 10127d1:	je     1012810 <myl_rc_heap_teardown+0x50>
 10127d3:	mov    %rdi,%rbx
 10127d6:	call   1018b80 <myl_rc_scopes_abandon>
 10127db:	movl   $0x0,0x124(%r14)
 10127e6:	vxorps %xmm0,%xmm0,%xmm0
 10127ea:	vmovups %xmm0,0xc0(%r14)
 10127f3:	movl   $0x0,0xd0(%r14)
 10127fe:	mov    0x18(%r14),%rax
 1012802:	test   %rax,%rax
 1012805:	je     1012815 <myl_rc_heap_teardown+0x55>
 1012807:	mov    %rbx,%rdi
 101280a:	pop    %rbx
 101280b:	pop    %r14
 101280d:	pop    %rbp
 101280e:	jmp    *%rax
 1012810:	pop    %rbx
 1012811:	pop    %r14
 1012813:	pop    %rbp
 1012814:	ret
 1012815:	call   101246d <myl_rc_invariant_failed>
 101281a:	int3
 101281b:	int3
 101281c:	int3
 101281d:	int3
 101281e:	int3
 101281f:	int3

0000000001012820 <myl_rc_new>:
 1012820:	push   %rbp
 1012821:	mov    %rsp,%rbp
 1012824:	push   %rbx
 1012825:	push   %rax
 1012826:	test   %rdi,%rdi
 1012829:	je     10128e8 <myl_rc_new+0xc8>
 101282f:	mov    %rdx,%rbx
 1012832:	test   %rdx,%rdx
 1012835:	je     10128e8 <myl_rc_new+0xc8>
 101283b:	test   %rsi,%rsi
 101283e:	je     10128e8 <myl_rc_new+0xc8>
 1012844:	cmpq   $0x0,0x1608(%rdi)
 101284c:	je     10128e8 <myl_rc_new+0xc8>
 1012852:	movq   $0x0,(%rbx)
 1012859:	mov    (%rsi),%rdx
 101285c:	test   %rdx,%rdx
 101285f:	je     10128e8 <myl_rc_new+0xc8>
 1012865:	mov    0x8(%rsi),%rcx
 1012869:	mov    %rcx,%rax
 101286c:	mulq   (%rdx)
 101286f:	mov    %rax,%rdx
 1012872:	mov    $0x1,%eax
 1012877:	jo     10128da <myl_rc_new+0xba>
 1012879:	mov    0x10(%rsi),%r8d
 101287d:	xor    %r9d,%r9d
 1012880:	test   %r8d,%r8d
 1012883:	sete   %r9b
 1012887:	movabs $0x3ffffffffffffff,%r10
 1012891:	movabs $0x3fffffffff,%r11
 101289b:	cmove  %r10,%r11
 101289f:	shl    $0x4,%r9d
 10128a3:	add    $0x10,%r9
 10128a7:	add    %r9,%rdx
 10128aa:	setb   %dl
 10128ad:	cmp    %r11,%rcx
 10128b0:	seta   %cl
 10128b3:	or     %dl,%cl
 10128b5:	jne    10128da <myl_rc_new+0xba>
 10128b7:	mov    $0x3,%eax
 10128bc:	cmp    0x70(%rdi),%r8d
 10128c0:	ja     10128da <myl_rc_new+0xba>
 10128c2:	mov    0x1608(%rdi),%rax
 10128c9:	mov    %rbx,%rdx
 10128cc:	call   *(%rax)
 10128ce:	mov    (%rbx),%rcx
 10128d1:	test   %eax,%eax
 10128d3:	je     10128e1 <myl_rc_new+0xc1>
 10128d5:	test   %rcx,%rcx
 10128d8:	jne    10128e8 <myl_rc_new+0xc8>
 10128da:	add    $0x8,%rsp
 10128de:	pop    %rbx
 10128df:	pop    %rbp
 10128e0:	ret
 10128e1:	xor    %eax,%eax
 10128e3:	test   %rcx,%rcx
 10128e6:	jne    10128da <myl_rc_new+0xba>
 10128e8:	call   101246d <myl_rc_invariant_failed>
 10128ed:	int3
 10128ee:	int3
 10128ef:	int3

00000000010128f0 <myl_rc_dead_outside>:
 10128f0:	push   %rbp
 10128f1:	mov    %rsp,%rbp
 10128f4:	mov    0x18(%rsi),%rax
 10128f8:	mov    0x1608(%rdi),%rdx
 10128ff:	cmp    %rax,0x110(%rdx)
 1012906:	je     1012958 <myl_rc_dead_outside+0x68>
 1012908:	mov    0x34(%rax),%ecx
 101290b:	cmp    %rcx,0xa0(%rdx)
 1012912:	jbe    101297e <myl_rc_dead_outside+0x8e>
 1012914:	mov    0x98(%rdx),%rdx
 101291b:	shl    $0x4,%rcx
 101291f:	cmp    %rax,(%rdx,%rcx,1)
 1012923:	jne    101297e <myl_rc_dead_outside+0x8e>
 1012925:	add    %rcx,%rdx
 1012928:	mov    0x8(%rdx),%rax
 101292c:	test   %rax,%rax
 101292f:	je     1012937 <myl_rc_dead_outside+0x47>
 1012931:	cmpl   $0x0,0x40(%rax)
 1012935:	je     1012958 <myl_rc_dead_outside+0x68>
 1012937:	mov    0x1608(%rdi),%rax
 101293e:	mov    0xc8(%rax),%rax
 1012945:	mov    %rax,(%rsi)
 1012948:	mov    0x1608(%rdi),%rax
 101294f:	mov    %rsi,0xc8(%rax)
 1012956:	pop    %rbp
 1012957:	ret
 1012958:	movabs $0x4000000000000003,%rax
 1012962:	and    0x10(%rsi),%rax
 1012966:	cmp    $0x1,%rax
 101296a:	jne    1012993 <myl_rc_dead_outside+0xa3>
 101296c:	mov    0x1608(%rdi),%rax
 1012973:	mov    0x8(%rax),%rax
 1012977:	add    $0x20,%rsi
 101297b:	pop    %rbp
 101297c:	jmp    *%rax
 101297e:	mov    %rsi,%rcx
 1012981:	mov    %rax,%rsi
 1012984:	call   1012eea <myl_rc_binding_find_slow>
 1012989:	mov    %rcx,%rsi
 101298c:	test   %rax,%rax
 101298f:	jne    1012931 <myl_rc_dead_outside+0x41>
 1012991:	jmp    1012937 <myl_rc_dead_outside+0x47>
 1012993:	call   101246d <myl_rc_invariant_failed>
 1012998:	int3
 1012999:	int3
 101299a:	int3
 101299b:	int3
 101299c:	int3
 101299d:	int3
 101299e:	int3
 101299f:	int3

00000000010129a0 <myl_rc_edge_release>:
 10129a0:	push   %rbp
 10129a1:	mov    %rsp,%rbp
 10129a4:	test   %rsi,%rsi
 10129a7:	je     10129bc <myl_rc_edge_release+0x1c>
 10129a9:	movabs $0x4000000000000002,%rcx
 10129b3:	mov    -0x10(%rsi),%r8
 10129b7:	test   %rcx,%r8
 10129ba:	je     10129be <myl_rc_edge_release+0x1e>
 10129bc:	pop    %rbp
 10129bd:	ret
 10129be:	test   %rdi,%rdi
 10129c1:	je     1012ab2 <myl_rc_edge_release+0x112>
 10129c7:	cmpq   $0x0,0x1608(%rdi)
 10129cf:	je     1012ab2 <myl_rc_edge_release+0x112>
 10129d5:	test   $0x1,%r8b
 10129d9:	jne    1012ab2 <myl_rc_edge_release+0x112>
 10129df:	mov    -0x20(%rsi),%rax
 10129e3:	test   %rax,%rax
 10129e6:	je     1012ab2 <myl_rc_edge_release+0x112>
 10129ec:	lea    -0x20(%rsi),%rdx
 10129f0:	dec    %rax
 10129f3:	mov    %rax,(%rdx)
 10129f6:	jne    10129bc <myl_rc_edge_release+0x1c>
 10129f8:	cmpq   $0x0,-0x18(%rsi)
 10129fd:	jne    10129bc <myl_rc_edge_release+0x1c>
 10129ff:	or     $0x1,%r8
 1012a03:	mov    %r8,-0x10(%rsi)
 1012a07:	mov    0x1608(%rdi),%r9
 1012a0e:	cmpl   $0x0,0xd0(%r9)
 1012a16:	je     1012a21 <myl_rc_edge_release+0x81>
 1012a18:	mov    0xc8(%r9),%rax
 1012a1f:	jmp    1012a6c <myl_rc_edge_release+0xcc>
 1012a21:	mov    -0x8(%rsi),%rax
 1012a25:	cmp    %rax,0x110(%r9)
 1012a2c:	je     1012a83 <myl_rc_edge_release+0xe3>
 1012a2e:	mov    0x34(%rax),%r8d
 1012a32:	cmp    %r8,0xa0(%r9)
 1012a39:	jbe    1012a9d <myl_rc_edge_release+0xfd>
 1012a3b:	mov    0x98(%r9),%r9
 1012a42:	shl    $0x4,%r8
 1012a46:	cmp    %rax,(%r9,%r8,1)
 1012a4a:	jne    1012a9d <myl_rc_edge_release+0xfd>
 1012a4c:	add    %r8,%r9
 1012a4f:	mov    0x8(%r9),%rax
 1012a53:	test   %rax,%rax
 1012a56:	je     1012a5e <myl_rc_edge_release+0xbe>
 1012a58:	cmpl   $0x0,0x40(%rax)
 1012a5c:	je     1012a7f <myl_rc_edge_release+0xdf>
 1012a5e:	mov    0x1608(%rdi),%rax
 1012a65:	mov    0xc8(%rax),%rax
 1012a6c:	mov    %rax,(%rdx)
 1012a6f:	mov    0x1608(%rdi),%rax
 1012a76:	mov    %rdx,0xc8(%rax)
 1012a7d:	pop    %rbp
 1012a7e:	ret
 1012a7f:	mov    -0x10(%rsi),%r8
 1012a83:	inc    %rcx
 1012a86:	and    %r8,%rcx
 1012a89:	cmp    $0x1,%rcx
 1012a8d:	jne    1012ab2 <myl_rc_edge_release+0x112>
 1012a8f:	mov    0x1608(%rdi),%rax
 1012a96:	mov    0x8(%rax),%rax
 1012a9a:	pop    %rbp
 1012a9b:	jmp    *%rax
 1012a9d:	mov    %rsi,%r8
 1012aa0:	mov    %rax,%rsi
 1012aa3:	call   1012eea <myl_rc_binding_find_slow>
 1012aa8:	mov    %r8,%rsi
 1012aab:	test   %rax,%rax
 1012aae:	jne    1012a58 <myl_rc_edge_release+0xb8>
 1012ab0:	jmp    1012a5e <myl_rc_edge_release+0xbe>
 1012ab2:	call   101246d <myl_rc_invariant_failed>
 1012ab7:	int3
 1012ab8:	int3
 1012ab9:	int3
 1012aba:	int3
 1012abb:	int3
 1012abc:	int3
 1012abd:	int3
 1012abe:	int3
 1012abf:	int3

0000000001012ac0 <myl_rc_owner_release>:
 1012ac0:	push   %rbp
 1012ac1:	mov    %rsp,%rbp
 1012ac4:	push   %rbx
 1012ac5:	push   %rax
 1012ac6:	mov    %rdi,%rbx
 1012ac9:	call   10129a0 <myl_rc_edge_release>
 1012ace:	test   %rbx,%rbx
 1012ad1:	je     1012af7 <myl_rc_owner_release+0x37>
 1012ad3:	mov    0x1608(%rbx),%rax
 1012ada:	test   %rax,%rax
 1012add:	je     1012af7 <myl_rc_owner_release+0x37>
 1012adf:	cmpq   $0x0,0xc8(%rax)
 1012ae7:	je     1012af7 <myl_rc_owner_release+0x37>
 1012ae9:	mov    %rbx,%rdi
 1012aec:	add    $0x8,%rsp
 1012af0:	pop    %rbx
 1012af1:	pop    %rbp
 1012af2:	jmp    1016000 <myl_rc_drain>
 1012af7:	add    $0x8,%rsp
 1012afb:	pop    %rbx
 1012afc:	pop    %rbp
 1012afd:	ret
 1012afe:	int3
 1012aff:	int3

0000000001012b00 <myl_rc_unique>:
 1012b00:	push   %rbp
 1012b01:	mov    %rsp,%rbp
 1012b04:	mov    $0x1,%eax
 1012b09:	test   %rsi,%rsi
 1012b0c:	je     1012b41 <myl_rc_unique+0x41>
 1012b0e:	mov    -0x10(%rsi),%rcx
 1012b12:	movabs $0x6000000000000002,%rax
 1012b1c:	test   %rax,%rcx
 1012b1f:	jne    1012b30 <myl_rc_unique+0x30>
 1012b21:	test   %rdi,%rdi
 1012b24:	je     1012b6f <myl_rc_unique+0x6f>
 1012b26:	cmpq   $0x0,0x1608(%rdi)
 1012b2e:	je     1012b6f <myl_rc_unique+0x6f>
 1012b30:	xor    %eax,%eax
 1012b32:	movabs $0x2000000000000002,%rdx
 1012b3c:	test   %rdx,%rcx
 1012b3f:	je     1012b43 <myl_rc_unique+0x43>
 1012b41:	pop    %rbp
 1012b42:	ret
 1012b43:	bt     $0x3e,%rcx
 1012b48:	mov    $0x1,%eax
 1012b4d:	jb     1012b41 <myl_rc_unique+0x41>
 1012b4f:	test   $0x1,%cl
 1012b52:	jne    1012b6f <myl_rc_unique+0x6f>
 1012b54:	mov    -0x20(%rsi),%rcx
 1012b58:	test   %rcx,%rcx
 1012b5b:	jne    1012b64 <myl_rc_unique+0x64>
 1012b5d:	cmpq   $0x0,-0x18(%rsi)
 1012b62:	je     1012b6f <myl_rc_unique+0x6f>
 1012b64:	xor    %eax,%eax
 1012b66:	cmp    $0x2,%rcx
 1012b6a:	setb   %al
 1012b6d:	pop    %rbp
 1012b6e:	ret
 1012b6f:	call   101246d <myl_rc_invariant_failed>
 1012b74:	int3
 1012b75:	int3
 1012b76:	int3
 1012b77:	int3
 1012b78:	int3
 1012b79:	int3
 1012b7a:	int3
 1012b7b:	int3
 1012b7c:	int3
 1012b7d:	int3
 1012b7e:	int3
 1012b7f:	int3

0000000001012b80 <myl_rc_hold_acquire>:
 1012b80:	push   %rbp
 1012b81:	mov    %rsp,%rbp
 1012b84:	test   %rdx,%rdx
 1012b87:	je     1012be2 <myl_rc_hold_acquire+0x62>
 1012b89:	cmpq   $0x0,(%rdx)
 1012b8d:	jne    1012be2 <myl_rc_hold_acquire+0x62>
 1012b8f:	test   %rsi,%rsi
 1012b92:	je     1012bd4 <myl_rc_hold_acquire+0x54>
 1012b94:	mov    -0x10(%rsi),%rax
 1012b98:	movabs $0x4000000000000002,%rcx
 1012ba2:	test   %rcx,%rax
 1012ba5:	jne    1012bd4 <myl_rc_hold_acquire+0x54>
 1012ba7:	test   %rdi,%rdi
 1012baa:	je     1012be2 <myl_rc_hold_acquire+0x62>
 1012bac:	cmpq   $0x0,0x1608(%rdi)
 1012bb4:	je     1012be2 <myl_rc_hold_acquire+0x62>
 1012bb6:	test   $0x1,%al
 1012bb8:	jne    1012be2 <myl_rc_hold_acquire+0x62>
 1012bba:	mov    -0x18(%rsi),%rax
 1012bbe:	mov    -0x20(%rsi),%rcx
 1012bc2:	or     %rax,%rcx
 1012bc5:	je     1012be2 <myl_rc_hold_acquire+0x62>
 1012bc7:	cmp    $0xffffffffffffffff,%rax
 1012bcb:	je     1012bdb <myl_rc_hold_acquire+0x5b>
 1012bcd:	inc    %rax
 1012bd0:	mov    %rax,-0x18(%rsi)
 1012bd4:	mov    %rsi,(%rdx)
 1012bd7:	xor    %eax,%eax
 1012bd9:	pop    %rbp
 1012bda:	ret
 1012bdb:	mov    $0x2,%eax
 1012be0:	pop    %rbp
 1012be1:	ret
 1012be2:	call   101246d <myl_rc_invariant_failed>
 1012be7:	int3
 1012be8:	int3
 1012be9:	int3
 1012bea:	int3
 1012beb:	int3
 1012bec:	int3
 1012bed:	int3
 1012bee:	int3
 1012bef:	int3

0000000001012bf0 <myl_rc_hold_edge_release>:
 1012bf0:	push   %rbp
 1012bf1:	mov    %rsp,%rbp
 1012bf4:	test   %rsi,%rsi
 1012bf7:	je     1012c0c <myl_rc_hold_edge_release+0x1c>
 1012bf9:	movabs $0x4000000000000002,%rcx
 1012c03:	mov    -0x10(%rsi),%r8
 1012c07:	test   %rcx,%r8
 1012c0a:	je     1012c0e <myl_rc_hold_edge_release+0x1e>
 1012c0c:	pop    %rbp
 1012c0d:	ret
 1012c0e:	test   %rdi,%rdi
 1012c11:	je     1012d00 <myl_rc_hold_edge_release+0x110>
 1012c17:	cmpq   $0x0,0x1608(%rdi)
 1012c1f:	je     1012d00 <myl_rc_hold_edge_release+0x110>
 1012c25:	test   $0x1,%r8b
 1012c29:	jne    1012d00 <myl_rc_hold_edge_release+0x110>
 1012c2f:	mov    -0x18(%rsi),%rax
 1012c33:	test   %rax,%rax
 1012c36:	je     1012d00 <myl_rc_hold_edge_release+0x110>
 1012c3c:	dec    %rax
 1012c3f:	mov    %rax,-0x18(%rsi)
 1012c43:	or     -0x20(%rsi),%rax
 1012c47:	jne    1012c0c <myl_rc_hold_edge_release+0x1c>
 1012c49:	lea    -0x20(%rsi),%rdx
 1012c4d:	or     $0x1,%r8
 1012c51:	mov    %r8,-0x10(%rsi)
 1012c55:	mov    0x1608(%rdi),%r9
 1012c5c:	cmpl   $0x0,0xd0(%r9)
 1012c64:	je     1012c6f <myl_rc_hold_edge_release+0x7f>
 1012c66:	mov    0xc8(%r9),%rax
 1012c6d:	jmp    1012cba <myl_rc_hold_edge_release+0xca>
 1012c6f:	mov    -0x8(%rsi),%rax
 1012c73:	cmp    %rax,0x110(%r9)
 1012c7a:	je     1012cd1 <myl_rc_hold_edge_release+0xe1>
 1012c7c:	mov    0x34(%rax),%r8d
 1012c80:	cmp    %r8,0xa0(%r9)
 1012c87:	jbe    1012ceb <myl_rc_hold_edge_release+0xfb>
 1012c89:	mov    0x98(%r9),%r9
 1012c90:	shl    $0x4,%r8
 1012c94:	cmp    %rax,(%r9,%r8,1)
 1012c98:	jne    1012ceb <myl_rc_hold_edge_release+0xfb>
 1012c9a:	add    %r8,%r9
 1012c9d:	mov    0x8(%r9),%rax
 1012ca1:	test   %rax,%rax
 1012ca4:	je     1012cac <myl_rc_hold_edge_release+0xbc>
 1012ca6:	cmpl   $0x0,0x40(%rax)
 1012caa:	je     1012ccd <myl_rc_hold_edge_release+0xdd>
 1012cac:	mov    0x1608(%rdi),%rax
 1012cb3:	mov    0xc8(%rax),%rax
 1012cba:	mov    %rax,(%rdx)
 1012cbd:	mov    0x1608(%rdi),%rax
 1012cc4:	mov    %rdx,0xc8(%rax)
 1012ccb:	pop    %rbp
 1012ccc:	ret
 1012ccd:	mov    -0x10(%rsi),%r8
 1012cd1:	inc    %rcx
 1012cd4:	and    %r8,%rcx
 1012cd7:	cmp    $0x1,%rcx
 1012cdb:	jne    1012d00 <myl_rc_hold_edge_release+0x110>
 1012cdd:	mov    0x1608(%rdi),%rax
 1012ce4:	mov    0x8(%rax),%rax
 1012ce8:	pop    %rbp
 1012ce9:	jmp    *%rax
 1012ceb:	mov    %rsi,%r8
 1012cee:	mov    %rax,%rsi
 1012cf1:	call   1012eea <myl_rc_binding_find_slow>
 1012cf6:	mov    %r8,%rsi
 1012cf9:	test   %rax,%rax
 1012cfc:	jne    1012ca6 <myl_rc_hold_edge_release+0xb6>
 1012cfe:	jmp    1012cac <myl_rc_hold_edge_release+0xbc>
 1012d00:	call   101246d <myl_rc_invariant_failed>
 1012d05:	int3
 1012d06:	int3
 1012d07:	int3
 1012d08:	int3
 1012d09:	int3
 1012d0a:	int3
 1012d0b:	int3
 1012d0c:	int3
 1012d0d:	int3
 1012d0e:	int3
 1012d0f:	int3

0000000001012d10 <myl_rc_hold_release>:
 1012d10:	push   %rbp
 1012d11:	mov    %rsp,%rbp
 1012d14:	push   %rbx
 1012d15:	push   %rax
 1012d16:	test   %rsi,%rsi
 1012d19:	je     1012d60 <myl_rc_hold_release+0x50>
 1012d1b:	mov    %rdi,%rbx
 1012d1e:	mov    (%rsi),%rax
 1012d21:	movq   $0x0,(%rsi)
 1012d28:	mov    %rax,%rsi
 1012d2b:	call   1012bf0 <myl_rc_hold_edge_release>
 1012d30:	test   %rbx,%rbx
 1012d33:	je     1012d59 <myl_rc_hold_release+0x49>
 1012d35:	mov    0x1608(%rbx),%rax
 1012d3c:	test   %rax,%rax
 1012d3f:	je     1012d59 <myl_rc_hold_release+0x49>
 1012d41:	cmpq   $0x0,0xc8(%rax)
 1012d49:	je     1012d59 <myl_rc_hold_release+0x49>
 1012d4b:	mov    %rbx,%rdi
 1012d4e:	add    $0x8,%rsp
 1012d52:	pop    %rbx
 1012d53:	pop    %rbp
 1012d54:	jmp    1016000 <myl_rc_drain>
 1012d59:	add    $0x8,%rsp
 1012d5d:	pop    %rbx
 1012d5e:	pop    %rbp
 1012d5f:	ret
 1012d60:	call   101246d <myl_rc_invariant_failed>
 1012d65:	int3
 1012d66:	int3
 1012d67:	int3
 1012d68:	int3
 1012d69:	int3
 1012d6a:	int3
 1012d6b:	int3
 1012d6c:	int3
 1012d6d:	int3
 1012d6e:	int3
 1012d6f:	int3

0000000001012d70 <myl_rc_metadata_init>:
 1012d70:	push   %rbp
 1012d71:	mov    %rsp,%rbp
 1012d74:	lea    -0xfcdb(%rip),%rax        # 10030a0 <myl_rc_map_sentinel>
 1012d7b:	mov    %rax,0x78(%rdi)
 1012d7f:	vxorps %xmm0,%xmm0,%xmm0
 1012d83:	vmovups %xmm0,0x80(%rdi)
 1012d8b:	movq   $0x3f,0x90(%rdi)
 1012d96:	vmovups 0x78(%rdi),%ymm1
 1012d9b:	vmovups %ymm1,0x58(%rdi)
 1012da0:	vmovups %ymm1,0x38(%rdi)
 1012da5:	vmovups %xmm0,0x98(%rdi)
 1012dad:	movq   $0x0,0xa8(%rdi)
 1012db8:	pop    %rbp
 1012db9:	vzeroupper
 1012dbc:	ret
 1012dbd:	int3
 1012dbe:	int3
 1012dbf:	int3

0000000001012dc0 <myl_rc_metadata_release>:
 1012dc0:	push   %rbp
 1012dc1:	mov    %rsp,%rbp
 1012dc4:	push   %r15
 1012dc6:	push   %r14
 1012dc8:	push   %rbx
 1012dc9:	push   %rax
 1012dca:	mov    %rdi,%rbx
 1012dcd:	mov    0x1608(%rdi),%r15
 1012dd4:	mov    0x38(%r15),%rsi
 1012dd8:	cmp    $0x10030a0,%rsi
 1012ddf:	je     1012dfb <myl_rc_metadata_release+0x3b>
 1012de1:	mov    0x40(%r15),%rdx
 1012de5:	cmp    $0xffffffffffffffff,%rdx
 1012de9:	je     1012dfb <myl_rc_metadata_release+0x3b>
 1012deb:	shl    $0x4,%rdx
 1012def:	add    $0x10,%rdx
 1012df3:	mov    %rbx,%rdi
 1012df6:	call   1012500 <myl_rc_meta_free>
 1012dfb:	lea    -0xfd62(%rip),%r14        # 10030a0 <myl_rc_map_sentinel>
 1012e02:	mov    %r14,0x38(%r15)
 1012e06:	vxorps %xmm0,%xmm0,%xmm0
 1012e0a:	vmovups %xmm0,0x40(%r15)
 1012e10:	movq   $0x3f,0x50(%r15)
 1012e18:	mov    0x1608(%rbx),%r15
 1012e1f:	mov    0x58(%r15),%rsi
 1012e23:	cmp    %r14,%rsi
 1012e26:	je     1012e46 <myl_rc_metadata_release+0x86>
 1012e28:	mov    0x60(%r15),%rdx
 1012e2c:	cmp    $0xffffffffffffffff,%rdx
 1012e30:	je     1012e46 <myl_rc_metadata_release+0x86>
 1012e32:	shl    $0x4,%rdx
 1012e36:	add    $0x10,%rdx
 1012e3a:	mov    %rbx,%rdi
 1012e3d:	call   1012500 <myl_rc_meta_free>
 1012e42:	vxorps %xmm0,%xmm0,%xmm0
 1012e46:	mov    %r14,0x58(%r15)
 1012e4a:	vmovups %xmm0,0x60(%r15)
 1012e50:	movq   $0x3f,0x70(%r15)
 1012e58:	mov    0x1608(%rbx),%r15
 1012e5f:	mov    0x78(%r15),%rsi
 1012e63:	cmp    %r14,%rsi
 1012e66:	je     1012e85 <myl_rc_metadata_release+0xc5>
 1012e68:	mov    0x80(%r15),%rdx
 1012e6f:	cmp    $0xffffffffffffffff,%rdx
 1012e73:	je     1012e85 <myl_rc_metadata_release+0xc5>
 1012e75:	shl    $0x4,%rdx
 1012e79:	add    $0x10,%rdx
 1012e7d:	mov    %rbx,%rdi
 1012e80:	call   1012500 <myl_rc_meta_free>
 1012e85:	mov    %r14,0x78(%r15)
 1012e89:	vxorps %xmm0,%xmm0,%xmm0
 1012e8d:	vmovups %xmm0,0x80(%r15)
 1012e96:	movq   $0x3f,0x90(%r15)
 1012ea1:	mov    0x1608(%rbx),%rax
 1012ea8:	lea    0x98(%rax),%r14
 1012eaf:	mov    0x98(%rax),%rsi
 1012eb6:	test   %rsi,%rsi
 1012eb9:	je     1012ed2 <myl_rc_metadata_release+0x112>
 1012ebb:	mov    0xa0(%rax),%rdx
 1012ec2:	shl    $0x4,%rdx
 1012ec6:	mov    %rbx,%rdi
 1012ec9:	call   1012500 <myl_rc_meta_free>
 1012ece:	vxorps %xmm0,%xmm0,%xmm0
 1012ed2:	vmovups %xmm0,(%r14)
 1012ed7:	movq   $0x0,0x10(%r14)
 1012edf:	add    $0x8,%rsp
 1012ee3:	pop    %rbx
 1012ee4:	pop    %r14
 1012ee6:	pop    %r15
 1012ee8:	pop    %rbp
 1012ee9:	ret

0000000001012eea <myl_rc_binding_find_slow>:
 1012eea:	push   %rbp
 1012eeb:	mov    %rsp,%rbp
 1012eee:	push   %r10
 1012ef0:	push   %r9
 1012ef2:	push   %r8
 1012ef4:	push   %rdi
 1012ef5:	push   %rsi
 1012ef6:	push   %rdx
 1012ef7:	push   %rcx
 1012ef8:	push   %r15
 1012efa:	push   %r14
 1012efc:	push   %rbx
 1012efd:	mov    %rsi,%rbx
 1012f00:	mov    0x1608(%rdi),%r11
 1012f07:	mov    0x34(%rsi),%eax
 1012f0a:	cmp    %rax,0xa0(%r11)
 1012f11:	jbe    1012f30 <myl_rc_binding_find_slow+0x46>
 1012f13:	mov    0x98(%r11),%rcx
 1012f1a:	shl    $0x4,%rax
 1012f1e:	lea    (%rcx,%rax,1),%r15
 1012f22:	mov    (%rcx,%rax,1),%rax
 1012f26:	cmp    %rbx,%rax
 1012f29:	je     1012f91 <myl_rc_binding_find_slow+0xa7>
 1012f2b:	test   %rax,%rax
 1012f2e:	je     1012fa9 <myl_rc_binding_find_slow+0xbf>
 1012f30:	mov    0x78(%r11),%rax
 1012f34:	mov    0x80(%r11),%rcx
 1012f3b:	mov    0x90(%r11),%r11b
 1012f42:	movabs $0x9e3779b97f4a7c15,%rdx
 1012f4c:	imul   %rbx,%rdx
 1012f50:	shrx   %r11,%rdx,%r11
 1012f55:	and    %rcx,%r11
 1012f58:	mov    %r11,%rdx
 1012f5b:	shl    $0x4,%rdx
 1012f5f:	mov    (%rax,%rdx,1),%rdx
 1012f63:	cmp    %rbx,%rdx
 1012f66:	je     1012f86 <myl_rc_binding_find_slow+0x9c>
 1012f68:	xor    %r14d,%r14d
 1012f6b:	test   %rdx,%rdx
 1012f6e:	je     1012f95 <myl_rc_binding_find_slow+0xab>
 1012f70:	inc    %r11
 1012f73:	and    %rcx,%r11
 1012f76:	mov    %r11,%rdx
 1012f79:	shl    $0x4,%rdx
 1012f7d:	mov    (%rax,%rdx,1),%rdx
 1012f81:	cmp    %rbx,%rdx
 1012f84:	jne    1012f6b <myl_rc_binding_find_slow+0x81>
 1012f86:	shl    $0x4,%r11
 1012f8a:	mov    0x8(%rax,%r11,1),%r14
 1012f8f:	jmp    1012f95 <myl_rc_binding_find_slow+0xab>
 1012f91:	mov    0x8(%r15),%r14
 1012f95:	mov    %r14,%rax
 1012f98:	pop    %rbx
 1012f99:	pop    %r14
 1012f9b:	pop    %r15
 1012f9d:	pop    %rcx
 1012f9e:	pop    %rdx
 1012f9f:	pop    %rsi
 1012fa0:	pop    %rdi
 1012fa1:	pop    %r8
 1012fa3:	pop    %r9
 1012fa5:	pop    %r10
 1012fa7:	pop    %rbp
 1012fa8:	ret
 1012fa9:	mov    0x8(%r15),%r14
 1012fad:	test   %r14,%r14
 1012fb0:	je     1012f30 <myl_rc_binding_find_slow+0x46>
 1012fb6:	cmp    %rbx,(%r14)
 1012fb9:	jne    1012f30 <myl_rc_binding_find_slow+0x46>
 1012fbf:	mov    %r14,%rdi
 1012fc2:	call   1012fd0 <flat_build>
 1012fc7:	mov    %rbx,(%r15)
 1012fca:	jmp    1012f95 <myl_rc_binding_find_slow+0xab>
 1012fcc:	int3
 1012fcd:	int3
 1012fce:	int3
 1012fcf:	int3

0000000001012fd0 <flat_build>:
 1012fd0:	push   %rbp
 1012fd1:	mov    %rsp,%rbp
 1012fd4:	push   %r15
 1012fd6:	push   %r14
 1012fd8:	push   %r13
 1012fda:	push   %r12
 1012fdc:	push   %rbx
 1012fdd:	sub    $0x368,%rsp
 1012fe4:	movl   $0x11,0x40(%rdi)
 1012feb:	movw   $0x0,0x44(%rdi)
 1012ff1:	movb   $0x0,0x46(%rdi)
 1012ff5:	mov    (%rdi),%r14
 1012ff8:	mov    (%r14),%rax
 1012ffb:	mov    %rax,0x50(%rdi)
 1012fff:	cmpq   $0x0,0x10(%rdi)
 1013004:	jne    1013029 <flat_build+0x59>
 1013006:	cmpq   $0x0,0x18(%rdi)
 101300b:	jne    1013029 <flat_build+0x59>
 101300d:	cmpq   $0x0,0x20(%rdi)
 1013012:	jne    1013029 <flat_build+0x59>
 1013014:	cmpq   $0x0,0x28(%rdi)
 1013019:	jne    1013029 <flat_build+0x59>
 101301b:	cmpq   $0x0,0x30(%rdi)
 1013020:	jne    1013029 <flat_build+0x59>
 1013022:	cmpq   $0x0,0x38(%rdi)
 1013027:	je     101303b <flat_build+0x6b>
 1013029:	add    $0x368,%rsp
 1013030:	pop    %rbx
 1013031:	pop    %r12
 1013033:	pop    %r13
 1013035:	pop    %r14
 1013037:	pop    %r15
 1013039:	pop    %rbp
 101303a:	ret
 101303b:	lea    0x40(%rdi),%rax
 101303f:	mov    %rax,-0x48(%rbp)
 1013043:	lea    -0x380(%rbp),%rax
 101304a:	mov    $0x270,%edx
 101304f:	mov    %rdi,-0x38(%rbp)
 1013053:	mov    %rax,%rdi
 1013056:	xor    %esi,%esi
 1013058:	call   101e4a0 <compiler_rt.fastMemset>
 101305d:	mov    %r14,-0x390(%rbp)
 1013064:	mov    -0x38(%rbp),%rax
 1013068:	mov    0x8(%rax),%rax
 101306c:	mov    %rax,-0x388(%rbp)
 1013073:	movl   $0xffffffff,-0x370(%rbp)
 101307d:	mov    $0x1,%r12b
 1013080:	mov    $0x1,%ecx
 1013085:	mov    $0xc1,%esi
 101308a:	xor    %r14d,%r14d
 101308d:	xor    %ebx,%ebx
 101308f:	cmp    $0x9,%rcx
 1013093:	movzbl %r12b,%r12d
 1013097:	mov    $0x0,%eax
 101309c:	cmovae %eax,%r12d
 10130a0:	dec    %rsi
 10130a3:	je     1013029 <flat_build+0x59>
 10130a5:	lea    (%rcx,%rcx,4),%rax
 10130a9:	mov    -0x3b8(%rbp,%rax,8),%r8
 10130b1:	test   %r8,%r8
 10130b4:	je     1013029 <flat_build+0x59>
 10130ba:	mov    -0x3b0(%rbp,%rax,8),%r11
 10130c2:	test   %r11,%r11
 10130c5:	je     10130d9 <flat_build+0x109>
 10130c7:	mov    (%r8),%rdx
 10130ca:	cmp    (%r11),%rdx
 10130cd:	jne    1013029 <flat_build+0x59>
 10130d3:	mov    0x8(%r11),%r13d
 10130d7:	jmp    10130dc <flat_build+0x10c>
 10130d9:	xor    %r13d,%r13d
 10130dc:	movzwl 0x30(%r8),%edx
 10130e1:	cmp    $0x7,%edx
 10130e4:	je     10130fe <flat_build+0x12e>
 10130e6:	lea    -0x390(,%rax,8),%rdi
 10130ee:	add    %rbp,%rdi
 10130f1:	cmp    $0x1,%edx
 10130f4:	je     1013108 <flat_build+0x138>
 10130f6:	test   %edx,%edx
 10130f8:	jne    1013180 <flat_build+0x1b0>
 10130fe:	test   %r13d,%r13d
 1013101:	je     101316f <flat_build+0x19f>
 1013103:	jmp    1013029 <flat_build+0x59>
 1013108:	cmpw   $0x5,0x32(%r8)
 101310e:	jne    1013122 <flat_build+0x152>
 1013110:	cmpq   $0x0,0x38(%r8)
 1013115:	movzbl %r12b,%r12d
 1013119:	mov    $0x0,%eax
 101311e:	cmovne %eax,%r12d
 1013122:	cmp    $0x1,%r13d
 1013126:	jne    1013029 <flat_build+0x59>
 101312c:	cmpq   $0x8,(%r8)
 1013130:	jne    1013029 <flat_build+0x59>
 1013136:	cmp    $0x10,%r14d
 101313a:	je     1013029 <flat_build+0x59>
 1013140:	mov    -0x18(%rdi),%rax
 1013144:	mov    $0xfffffff7,%edx
 1013149:	cmp    %rdx,%rax
 101314c:	ja     1013029 <flat_build+0x59>
 1013152:	mov    %r14d,%edx
 1013155:	inc    %r14d
 1013158:	lea    (%rdx,%rdx,2),%rdx
 101315c:	mov    %eax,-0x110(%rbp,%rdx,4)
 1013163:	mov    -0x8(%rdi),%rax
 1013167:	mov    %rax,-0x10c(%rbp,%rdx,4)
 101316f:	dec    %rcx
 1013172:	test   %rcx,%rcx
 1013175:	jne    101308f <flat_build+0xbf>
 101317b:	jmp    10133c2 <flat_build+0x3f2>
 1013180:	mov    -0x8(%rdi),%eax
 1013183:	mov    %rax,-0x30(%rbp)
 1013187:	mov    -0x4(%rdi),%r9d
 101318b:	cmp    $0x4,%edx
 101318e:	je     101329c <flat_build+0x2cc>
 1013194:	cmp    $0x3,%edx
 1013197:	je     1013213 <flat_build+0x243>
 1013199:	cmp    $0x2,%edx
 101319c:	jne    1013029 <flat_build+0x59>
 10131a2:	test   $0xfffffffd,%r13d
 10131a9:	jne    1013029 <flat_build+0x59>
 10131af:	mov    0x18(%r8),%rdx
 10131b3:	cmp    $0x2,%r13d
 10131b7:	jne    10131c3 <flat_build+0x1f3>
 10131b9:	cmp    0x18(%r11),%rdx
 10131bd:	jne    1013029 <flat_build+0x59>
 10131c3:	mov    -0x10(%rdi),%rax
 10131c7:	cmp    %rdx,%rax
 10131ca:	je     101316f <flat_build+0x19f>
 10131cc:	mov    0x10(%r8),%r10
 10131d0:	test   %r10,%r10
 10131d3:	je     1013029 <flat_build+0x59>
 10131d9:	lea    0x1(%rax),%rdx
 10131dd:	mov    %rdx,-0x10(%rdi)
 10131e1:	lea    (%rax,%rax,2),%rdx
 10131e5:	mov    (%r10,%rdx,8),%rax
 10131e9:	mov    0x8(%r10,%rdx,8),%r15
 10131ee:	cmp    $0x2,%r13d
 10131f2:	jne    1013351 <flat_build+0x381>
 10131f8:	mov    0x10(%r11),%r10
 10131fc:	cmp    (%r10,%rdx,8),%rax
 1013200:	jne    1013029 <flat_build+0x59>
 1013206:	lea    (%r10,%rdx,8),%rdx
 101320a:	mov    0x8(%rdx),%rdx
 101320e:	jmp    101335b <flat_build+0x38b>
 1013213:	cmp    $0x3,%r13d
 1013217:	je     1013222 <flat_build+0x252>
 1013219:	test   %r13d,%r13d
 101321c:	jne    1013029 <flat_build+0x59>
 1013222:	mov    0x20(%r8),%rdx
 1013226:	cmp    $0x3,%r13d
 101322a:	jne    1013244 <flat_build+0x274>
 101322c:	cmp    0x18(%r11),%rdx
 1013230:	jne    1013029 <flat_build+0x59>
 1013236:	mov    0x28(%r8),%rax
 101323a:	cmp    0x20(%r11),%rax
 101323e:	jne    1013029 <flat_build+0x59>
 1013244:	mov    -0x10(%rdi),%rax
 1013248:	cmp    %rdx,%rax
 101324b:	je     101316f <flat_build+0x19f>
 1013251:	mov    0x38(%r8),%r15
 1013255:	test   %r15,%r15
 1013258:	jne    1013277 <flat_build+0x2a7>
 101325a:	cmpq   $0x1,0x18(%r8)
 101325f:	jne    1013274 <flat_build+0x2a4>
 1013261:	mov    0x10(%r8),%rdx
 1013265:	test   %rdx,%rdx
 1013268:	je     1013274 <flat_build+0x2a4>
 101326a:	cmpq   $0x0,(%rdx)
 101326e:	je     10133b9 <flat_build+0x3e9>
 1013274:	xor    %r15d,%r15d
 1013277:	lea    0x1(%rax),%rdx
 101327b:	mov    %rdx,-0x10(%rdi)
 101327f:	mulq   0x28(%r8)
 1013283:	jo     1013029 <flat_build+0x59>
 1013289:	cmp    $0x3,%r13d
 101328d:	jne    1013351 <flat_build+0x381>
 1013293:	mov    0x10(%r11),%rdx
 1013297:	jmp    101335b <flat_build+0x38b>
 101329c:	test   $0xfffffffb,%r13d
 10132a3:	jne    1013029 <flat_build+0x59>
 10132a9:	mov    -0x10(%rdi),%rax
 10132ad:	mov    0x18(%r8),%r10
 10132b1:	cmp    %r10,%rax
 10132b4:	je     101316f <flat_build+0x19f>
 10132ba:	mov    0x10(%r8),%rdx
 10132be:	test   %rdx,%rdx
 10132c1:	je     1013029 <flat_build+0x59>
 10132c7:	mov    %rbx,-0x40(%rbp)
 10132cb:	lea    0x1(%rax),%rbx
 10132cf:	mov    %rbx,-0x10(%rdi)
 10132d3:	lea    (%rax,%rax,2),%rbx
 10132d7:	mov    (%rdx,%rbx,8),%rax
 10132db:	mov    0x8(%rdx,%rbx,8),%r15
 10132e0:	cmp    $0x4,%r13d
 10132e4:	jne    1013355 <flat_build+0x385>
 10132e6:	cmp    0x18(%r11),%r10
 10132ea:	jne    1013029 <flat_build+0x59>
 10132f0:	cmpl   $0xffffffff,-0x30(%rbp)
 10132f4:	jne    1013029 <flat_build+0x59>
 10132fa:	lea    0x0(,%rbx,8),%r13
 1013302:	add    0x10(%r11),%r13
 1013306:	cmp    0x0(%r13),%rax
 101330a:	jne    1013029 <flat_build+0x59>
 1013310:	lea    (%rdx,%rbx,8),%rdx
 1013314:	mov    0x10(%rdx),%edx
 1013317:	cmp    0x10(%r13),%edx
 101331b:	jne    1013029 <flat_build+0x59>
 1013321:	mov    %edx,%r9d
 1013324:	mov    -0x18(%rdi),%rdx
 1013328:	add    0x20(%r11),%rdx
 101332c:	mov    %rdx,-0x30(%rbp)
 1013330:	jb     1013029 <flat_build+0x59>
 1013336:	mov    $0xfffffff7,%edx
 101333b:	add    $0x4,%rdx
 101333f:	cmp    %rdx,-0x30(%rbp)
 1013343:	ja     1013029 <flat_build+0x59>
 1013349:	mov    0x8(%r13),%rdx
 101334d:	mov    $0x1,%bl
 101334f:	jmp    101335b <flat_build+0x38b>
 1013351:	xor    %edx,%edx
 1013353:	jmp    101335b <flat_build+0x38b>
 1013355:	xor    %edx,%edx
 1013357:	mov    -0x40(%rbp),%rbx
 101335b:	cmp    $0x10,%rcx
 101335f:	je     1013029 <flat_build+0x59>
 1013365:	test   %r15,%r15
 1013368:	je     1013029 <flat_build+0x59>
 101336e:	mov    (%r8),%r8
 1013371:	sub    %rax,%r8
 1013374:	jb     1013029 <flat_build+0x59>
 101337a:	cmp    %r8,(%r15)
 101337d:	ja     1013029 <flat_build+0x59>
 1013383:	add    -0x18(%rdi),%rax
 1013387:	jb     1013029 <flat_build+0x59>
 101338d:	inc    %rcx
 1013390:	mov    %r15,(%rdi)
 1013393:	mov    %rdx,0x8(%rdi)
 1013397:	mov    %rax,0x10(%rdi)
 101339b:	movq   $0x0,0x18(%rdi)
 10133a3:	mov    -0x30(%rbp),%rax
 10133a7:	mov    %eax,0x20(%rdi)
 10133aa:	mov    %r9d,0x24(%rdi)
 10133ae:	test   %rcx,%rcx
 10133b1:	jne    101308f <flat_build+0xbf>
 10133b7:	jmp    10133c2 <flat_build+0x3f2>
 10133b9:	mov    0x8(%rdx),%r15
 10133bd:	jmp    1013277 <flat_build+0x2a7>
 10133c2:	lea    -0x110(%rbp),%rdi
 10133c9:	mov    %r14d,%esi
 10133cc:	call   1015360 <flat_disjoint>
 10133d1:	test   %eax,%eax
 10133d3:	je     1013029 <flat_build+0x59>
 10133d9:	lea    -0x110(%rbp),%rsi
 10133e0:	mov    -0x48(%rbp),%rdi
 10133e4:	mov    %r14d,%edx
 10133e7:	call   1015450 <flat_masks>
 10133ec:	mov    -0x38(%rbp),%rcx
 10133f0:	test   %eax,%eax
 10133f2:	je     1013029 <flat_build+0x59>
 10133f8:	mov    %r14d,0x40(%rcx)
 10133fc:	mov    %r12b,0x44(%rcx)
 1013400:	mov    %bl,0x46(%rcx)
 1013403:	jmp    1013029 <flat_build+0x59>
 1013408:	int3
 1013409:	int3
 101340a:	int3
 101340b:	int3
 101340c:	int3
 101340d:	int3
 101340e:	int3
 101340f:	int3

0000000001013410 <myl_rc_module_register>:
 1013410:	push   %rbp
 1013411:	mov    %rsp,%rbp
 1013414:	push   %r15
 1013416:	push   %r14
 1013418:	push   %r12
 101341a:	push   %rbx
 101341b:	sub    $0x30,%rsp
 101341f:	test   %rdi,%rdi
 1013422:	je     10135eb <myl_rc_module_register+0x1db>
 1013428:	mov    %rsi,%rbx
 101342b:	test   %rsi,%rsi
 101342e:	je     10135eb <myl_rc_module_register+0x1db>
 1013434:	mov    0x1608(%rdi),%rcx
 101343b:	test   %rcx,%rcx
 101343e:	je     10135eb <myl_rc_module_register+0x1db>
 1013444:	cmpl   $0x5,(%rbx)
 1013447:	jne    10135eb <myl_rc_module_register+0x1db>
 101344d:	cmpq   $0x0,0xc0(%rcx)
 1013455:	jne    10135eb <myl_rc_module_register+0x1db>
 101345b:	mov    0x38(%rcx),%rax
 101345f:	mov    0x40(%rcx),%rdx
 1013463:	movzbl 0x50(%rcx),%ecx
 1013467:	movabs $0x9e3779b97f4a7c15,%rsi
 1013471:	imul   %rbx,%rsi
 1013475:	shrx   %rcx,%rsi,%rcx
 101347a:	nopw   0x0(%rax,%rax,1)
 1013480:	and    %rdx,%rcx
 1013483:	mov    %rcx,%rsi
 1013486:	shl    $0x4,%rsi
 101348a:	mov    (%rax,%rsi,1),%rsi
 101348e:	cmp    %rbx,%rsi
 1013491:	je     101349d <myl_rc_module_register+0x8d>
 1013493:	test   %rsi,%rsi
 1013496:	je     10134b0 <myl_rc_module_register+0xa0>
 1013498:	inc    %rcx
 101349b:	jmp    1013480 <myl_rc_module_register+0x70>
 101349d:	shl    $0x4,%rcx
 10134a1:	xor    %r14d,%r14d
 10134a4:	cmpq   $0x0,0x8(%rax,%rcx,1)
 10134aa:	jne    10135db <myl_rc_module_register+0x1cb>
 10134b0:	mov    0x10(%rbx),%rax
 10134b4:	test   %rax,%rax
 10134b7:	je     10134c4 <myl_rc_module_register+0xb4>
 10134b9:	cmpq   $0x0,0x8(%rbx)
 10134be:	je     10135eb <myl_rc_module_register+0x1db>
 10134c4:	mov    0x20(%rbx),%rcx
 10134c8:	test   %rcx,%rcx
 10134cb:	je     10134d8 <myl_rc_module_register+0xc8>
 10134cd:	cmpq   $0x0,0x18(%rbx)
 10134d2:	je     10135eb <myl_rc_module_register+0x1db>
 10134d8:	vxorps %xmm0,%xmm0,%xmm0
 10134dc:	vmovups %ymm0,-0x48(%rbp)
 10134e1:	movq   $0x0,-0x28(%rbp)
 10134e9:	mov    %rdi,-0x50(%rbp)
 10134ed:	test   %rax,%rax
 10134f0:	je     1013528 <myl_rc_module_register+0x118>
 10134f2:	xor    %r15d,%r15d
 10134f5:	lea    -0x50(%rbp),%r14
 10134f9:	nopl   0x0(%rax)
 1013500:	mov    0x8(%rbx),%rax
 1013504:	mov    (%rax,%r15,8),%rsi
 1013508:	mov    %r14,%rdi
 101350b:	vzeroupper
 101350e:	call   1013600 <builder_add>
 1013513:	test   %eax,%eax
 1013515:	je     10135a2 <myl_rc_module_register+0x192>
 101351b:	inc    %r15
 101351e:	cmp    0x10(%rbx),%r15
 1013522:	jb     1013500 <myl_rc_module_register+0xf0>
 1013524:	mov    0x20(%rbx),%rcx
 1013528:	test   %rcx,%rcx
 101352b:	je     1013587 <myl_rc_module_register+0x177>
 101352d:	mov    $0x8,%r15d
 1013533:	xor    %r12d,%r12d
 1013536:	lea    -0x50(%rbp),%r14
 101353a:	nopw   0x0(%rax,%rax,1)
 1013540:	mov    0x18(%rbx),%rcx
 1013544:	mov    -0x8(%rcx,%r15,1),%rax
 1013549:	test   %rax,%rax
 101354c:	je     10135eb <myl_rc_module_register+0x1db>
 1013552:	mov    (%rcx,%r15,1),%rsi
 1013556:	test   %rsi,%rsi
 1013559:	je     10135eb <myl_rc_module_register+0x1db>
 101355f:	mov    (%rax),%rax
 1013562:	cmp    (%rsi),%rax
 1013565:	jne    10135eb <myl_rc_module_register+0x1db>
 101356b:	mov    %r14,%rdi
 101356e:	vzeroupper
 1013571:	call   1013600 <builder_add>
 1013576:	test   %eax,%eax
 1013578:	je     10135a2 <myl_rc_module_register+0x192>
 101357a:	inc    %r12
 101357d:	add    $0x40,%r15
 1013581:	cmp    0x20(%rbx),%r12
 1013585:	jb     1013540 <myl_rc_module_register+0x130>
 1013587:	lea    -0x50(%rbp),%rdi
 101358b:	mov    %rbx,%rsi
 101358e:	xor    %edx,%edx
 1013590:	mov    $0x1,%ecx
 1013595:	vzeroupper
 1013598:	call   10138b0 <register_shapes>
 101359d:	mov    %eax,%r14d
 10135a0:	jmp    10135a8 <myl_rc_module_register+0x198>
 10135a2:	mov    $0x1,%r14d
 10135a8:	mov    -0x50(%rbp),%rbx
 10135ac:	mov    -0x48(%rbp),%rsi
 10135b0:	mov    -0x30(%rbp),%r15
 10135b4:	lea    0x0(,%r15,8),%rax
 10135bc:	lea    (%rax,%rax,4),%rdx
 10135c0:	mov    %rbx,%rdi
 10135c3:	call   1012500 <myl_rc_meta_free>
 10135c8:	mov    -0x40(%rbp),%rsi
 10135cc:	shl    $0x4,%r15
 10135d0:	mov    %rbx,%rdi
 10135d3:	mov    %r15,%rdx
 10135d6:	call   1012500 <myl_rc_meta_free>
 10135db:	mov    %r14d,%eax
 10135de:	add    $0x30,%rsp
 10135e2:	pop    %rbx
 10135e3:	pop    %r12
 10135e5:	pop    %r14
 10135e7:	pop    %r15
 10135e9:	pop    %rbp
 10135ea:	ret
 10135eb:	vzeroupper
 10135ee:	call   101246d <myl_rc_invariant_failed>
 10135f3:	int3
 10135f4:	int3
 10135f5:	int3
 10135f6:	int3
 10135f7:	int3
 10135f8:	int3
 10135f9:	int3
 10135fa:	int3
 10135fb:	int3
 10135fc:	int3
 10135fd:	int3
 10135fe:	int3
 10135ff:	int3

0000000001013600 <builder_add>:
 1013600:	push   %rbp
 1013601:	mov    %rsp,%rbp
 1013604:	push   %r15
 1013606:	push   %r14
 1013608:	push   %r13
 101360a:	push   %r12
 101360c:	push   %rbx
 101360d:	sub    $0x18,%rsp
 1013611:	test   %rsi,%rsi
 1013614:	je     10138a0 <builder_add+0x2a0>
 101361a:	movabs $0xbf58476d1ce4e5b9,%r13
 1013624:	mov    0x20(%rdi),%rcx
 1013628:	test   %rcx,%rcx
 101362b:	je     101368e <builder_add+0x8e>
 101362d:	mov    0x10(%rdi),%rax
 1013631:	mov    %rsi,%rdx
 1013634:	shr    $0x3,%rdx
 1013638:	mov    %rsi,%r8
 101363b:	shr    $0x21,%r8
 101363f:	xor    %rdx,%r8
 1013642:	imul   %r13,%r8
 1013646:	mov    %r8,%rdx
 1013649:	shr    $0x1b,%rdx
 101364d:	xor    %r8,%rdx
 1013650:	lea    -0x1(,%rcx,2),%r8
 1013658:	and    %r8,%rdx
 101365b:	mov    (%rax,%rdx,8),%r10
 101365f:	test   %r10,%r10
 1013662:	je     101368e <builder_add+0x8e>
 1013664:	mov    0x8(%rdi),%r9
 1013668:	nopl   0x0(%rax,%rax,1)
 1013670:	lea    (%r10,%r10,4),%r10
 1013674:	cmp    %rsi,-0x28(%r9,%r10,8)
 1013679:	je     101385d <builder_add+0x25d>
 101367f:	inc    %rdx
 1013682:	and    %r8,%rdx
 1013685:	mov    (%rax,%rdx,8),%r10
 1013689:	test   %r10,%r10
 101368c:	jne    1013670 <builder_add+0x70>
 101368e:	mov    0x18(%rdi),%rax
 1013692:	cmp    %rcx,%rax
 1013695:	jne    10137ec <builder_add+0x1ec>
 101369b:	lea    (%rcx,%rcx,1),%rax
 101369f:	test   %rcx,%rcx
 10136a2:	mov    $0x10,%r15d
 10136a8:	cmovne %rax,%r15
 10136ac:	xor    %eax,%eax
 10136ae:	cmp    %rcx,%r15
 10136b1:	jb     1013862 <builder_add+0x262>
 10136b7:	mov    $0x28,%ecx
 10136bc:	mov    %r15,%rax
 10136bf:	mul    %rcx
 10136c2:	jo     1013871 <builder_add+0x271>
 10136c8:	mov    %rsi,-0x30(%rbp)
 10136cc:	mov    %rdi,%r12
 10136cf:	mov    (%rdi),%rdi
 10136d2:	mov    %rax,-0x38(%rbp)
 10136d6:	mov    %rax,%rsi
 10136d9:	call   1012480 <myl_rc_meta_alloc>
 10136de:	test   %rax,%rax
 10136e1:	je     1013871 <builder_add+0x271>
 10136e7:	mov    %rax,%r14
 10136ea:	mov    %r15,%rsi
 10136ed:	shl    $0x4,%rsi
 10136f1:	mov    (%r12),%rdi
 10136f5:	call   1012480 <myl_rc_meta_alloc>
 10136fa:	test   %rax,%rax
 10136fd:	je     101387e <builder_add+0x27e>
 1013703:	mov    %rax,%rbx
 1013706:	mov    %r12,%rax
 1013709:	mov    0x18(%r12),%rcx
 101370e:	test   %rcx,%rcx
 1013711:	je     101372a <builder_add+0x12a>
 1013713:	mov    0x8(%rax),%rsi
 1013717:	shl    $0x3,%rcx
 101371b:	lea    (%rcx,%rcx,4),%rdx
 101371f:	mov    %r14,%rdi
 1013722:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1013727:	mov    %r12,%rax
 101372a:	mov    (%rax),%rdi
 101372d:	mov    0x8(%rax),%rsi
 1013731:	mov    0x20(%rax),%rax
 1013735:	shl    $0x3,%rax
 1013739:	lea    (%rax,%rax,4),%rdx
 101373d:	call   1012500 <myl_rc_meta_free>
 1013742:	mov    (%r12),%rdi
 1013746:	mov    0x10(%r12),%rsi
 101374b:	mov    0x20(%r12),%rdx
 1013750:	shl    $0x4,%rdx
 1013754:	call   1012500 <myl_rc_meta_free>
 1013759:	mov    %r12,%rdi
 101375c:	mov    %r14,0x8(%r12)
 1013761:	mov    %rbx,0x10(%r12)
 1013766:	mov    %r15,0x20(%r12)
 101376b:	cmpq   $0x0,0x18(%r12)
 1013771:	je     1013892 <builder_add+0x292>
 1013777:	xor    %ecx,%ecx
 1013779:	mov    -0x30(%rbp),%rsi
 101377d:	jmp    1013794 <builder_add+0x194>
 101377f:	nop
 1013780:	inc    %rcx
 1013783:	mov    %rcx,(%rbx,%rax,8)
 1013787:	mov    0x18(%rdi),%rax
 101378b:	cmp    %rax,%rcx
 101378e:	jae    1013875 <builder_add+0x275>
 1013794:	lea    (%rcx,%rcx,4),%rax
 1013798:	mov    (%r14,%rax,8),%rdx
 101379c:	mov    %rdx,%rax
 101379f:	shr    $0x3,%rax
 10137a3:	mov    %rdx,%r8
 10137a6:	shr    $0x21,%r8
 10137aa:	xor    %rax,%r8
 10137ad:	imul   %r13,%r8
 10137b1:	mov    %r8,%rax
 10137b4:	shr    $0x1b,%rax
 10137b8:	xor    %r8,%rax
 10137bb:	mov    0x20(%rdi),%r8
 10137bf:	lea    -0x1(,%r8,2),%r8
 10137c7:	nopw   0x0(%rax,%rax,1)
 10137d0:	and    %r8,%rax
 10137d3:	mov    (%rbx,%rax,8),%r9
 10137d7:	test   %r9,%r9
 10137da:	je     1013780 <builder_add+0x180>
 10137dc:	lea    (%r9,%r9,4),%r9
 10137e0:	cmp    %rdx,-0x28(%r14,%r9,8)
 10137e5:	je     1013780 <builder_add+0x180>
 10137e7:	inc    %rax
 10137ea:	jmp    10137d0 <builder_add+0x1d0>
 10137ec:	mov    0x10(%rdi),%rbx
 10137f0:	mov    %rsi,%rdx
 10137f3:	shr    $0x3,%rdx
 10137f7:	mov    %rsi,%r8
 10137fa:	shr    $0x21,%r8
 10137fe:	xor    %rdx,%r8
 1013801:	imul   %r13,%r8
 1013805:	mov    %r8,%rdx
 1013808:	shr    $0x1b,%rdx
 101380c:	xor    %r8,%rdx
 101380f:	lea    -0x1(,%rcx,2),%r8
 1013817:	and    %r8,%rdx
 101381a:	mov    (%rbx,%rdx,8),%r9
 101381e:	mov    0x8(%rdi),%rcx
 1013822:	test   %r9,%r9
 1013825:	je     101384a <builder_add+0x24a>
 1013827:	nopw   0x0(%rax,%rax,1)
 1013830:	lea    (%r9,%r9,4),%r9
 1013834:	cmp    %rsi,-0x28(%rcx,%r9,8)
 1013839:	je     101384a <builder_add+0x24a>
 101383b:	inc    %rdx
 101383e:	and    %r8,%rdx
 1013841:	mov    (%rbx,%rdx,8),%r9
 1013845:	test   %r9,%r9
 1013848:	jne    1013830 <builder_add+0x230>
 101384a:	lea    (%rax,%rax,4),%r8
 101384e:	mov    %rsi,(%rcx,%r8,8)
 1013852:	inc    %rax
 1013855:	mov    %rax,0x18(%rdi)
 1013859:	mov    %rax,(%rbx,%rdx,8)
 101385d:	mov    $0x1,%eax
 1013862:	add    $0x18,%rsp
 1013866:	pop    %rbx
 1013867:	pop    %r12
 1013869:	pop    %r13
 101386b:	pop    %r14
 101386d:	pop    %r15
 101386f:	pop    %rbp
 1013870:	ret
 1013871:	xor    %eax,%eax
 1013873:	jmp    1013862 <builder_add+0x262>
 1013875:	mov    0x20(%rdi),%rcx
 1013879:	jmp    10137f0 <builder_add+0x1f0>
 101387e:	mov    (%r12),%rdi
 1013882:	mov    %r14,%rsi
 1013885:	mov    -0x38(%rbp),%rdx
 1013889:	call   1012500 <myl_rc_meta_free>
 101388e:	xor    %eax,%eax
 1013890:	jmp    1013862 <builder_add+0x262>
 1013892:	xor    %eax,%eax
 1013894:	mov    %r15,%rcx
 1013897:	mov    -0x30(%rbp),%rsi
 101389b:	jmp    10137f0 <builder_add+0x1f0>
 10138a0:	call   101246d <myl_rc_invariant_failed>
 10138a5:	int3
 10138a6:	int3
 10138a7:	int3
 10138a8:	int3
 10138a9:	int3
 10138aa:	int3
 10138ab:	int3
 10138ac:	int3
 10138ad:	int3
 10138ae:	int3
 10138af:	int3

00000000010138b0 <register_shapes>:
 10138b0:	push   %rbp
 10138b1:	mov    %rsp,%rbp
 10138b4:	push   %r15
 10138b6:	push   %r14
 10138b8:	push   %r13
 10138ba:	push   %r12
 10138bc:	push   %rbx
 10138bd:	sub    $0x88,%rsp
 10138c4:	mov    %ecx,-0x3c(%rbp)
 10138c7:	mov    %rsi,-0x58(%rbp)
 10138cb:	mov    (%rdi),%rax
 10138ce:	mov    %rax,-0x48(%rbp)
 10138d2:	mov    0x18(%rdi),%r15
 10138d6:	test   %r15,%r15
 10138d9:	mov    %rdi,-0x30(%rbp)
 10138dd:	mov    %rdx,-0x68(%rbp)
 10138e1:	je     10138ee <register_shapes+0x3e>
 10138e3:	xor    %ebx,%ebx
 10138e5:	lea    -0x10884(%rip),%r8        # 1003068 <dict_scan+0x18>
 10138ec:	jmp    101393c <register_shapes+0x8c>
 10138ee:	xor    %esi,%esi
 10138f0:	xor    %edx,%edx
 10138f2:	movq   $0x0,-0x38(%rbp)
 10138fa:	mov    (%rdi),%rdi
 10138fd:	call   1012500 <myl_rc_meta_free>
 1013902:	mov    -0x58(%rbp),%rax
 1013906:	test   %rax,%rax
 1013909:	je     1013ac3 <register_shapes+0x213>
 101390f:	mov    0x20(%rax),%r13
 1013913:	jmp    1013ac6 <register_shapes+0x216>
 1013918:	mov    0x18(%rdi),%r15
 101391c:	lea    -0x108bb(%rip),%r8        # 1003068 <dict_scan+0x18>
 1013923:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013930:	inc    %rbx
 1013933:	cmp    %r15,%rbx
 1013936:	jae    1013da3 <register_shapes+0x4f3>
 101393c:	mov    0x8(%rdi),%rax
 1013940:	lea    (%rbx,%rbx,4),%rcx
 1013944:	mov    (%rax,%rcx,8),%r12
 1013948:	mov    0x8(%r12),%ecx
 101394d:	cmp    $0x5,%rcx
 1013951:	ja     10142e5 <register_shapes+0xa35>
 1013957:	movslq (%r8,%rcx,4),%rax
 101395b:	add    %r8,%rax
 101395e:	jmp    *%rax
 1013960:	cmpq   $0x8,(%r12)
 1013965:	jne    10142e5 <register_shapes+0xa35>
 101396b:	cmp    $0x2,%ecx
 101396e:	je     1013975 <register_shapes+0xc5>
 1013970:	cmp    $0x4,%ecx
 1013973:	jne    1013930 <register_shapes+0x80>
 1013975:	mov    0x10(%r12),%rax
 101397a:	xor    %r14d,%r14d
 101397d:	jmp    10139a4 <register_shapes+0xf4>
 101397f:	nop
 1013980:	mov    0x10(%r12),%rax
 1013985:	mov    0x18(%r12),%r14
 101398a:	test   %r14,%r14
 101398d:	setne  %dl
 1013990:	test   %rax,%rax
 1013993:	sete   %sil
 1013997:	and    %dl,%sil
 101399a:	cmp    $0x1,%sil
 101399e:	je     10142e5 <register_shapes+0xa35>
 10139a4:	cmp    $0x4,%ecx
 10139a7:	jne    10139c2 <register_shapes+0x112>
 10139a9:	mov    0x20(%r12),%rcx
 10139ae:	add    $0x4,%rcx
 10139b2:	jb     10142ca <register_shapes+0xa1a>
 10139b8:	cmp    (%r12),%rcx
 10139bc:	ja     10142e5 <register_shapes+0xa35>
 10139c2:	mov    $0x1,%r9d
 10139c8:	add    %r14,0x28(%rdi)
 10139cc:	jb     10142d0 <register_shapes+0xa20>
 10139d2:	test   %r14,%r14
 10139d5:	je     1013930 <register_shapes+0x80>
 10139db:	add    $0x8,%rax
 10139df:	mov    %r14,%rcx
 10139e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10139f0:	mov    (%rax),%rdx
 10139f3:	test   %rdx,%rdx
 10139f6:	je     10142e5 <register_shapes+0xa35>
 10139fc:	mov    -0x8(%rax),%rsi
 1013a00:	add    (%rdx),%rsi
 1013a03:	jb     10142d0 <register_shapes+0xa20>
 1013a09:	cmp    (%r12),%rsi
 1013a0d:	ja     10142e5 <register_shapes+0xa35>
 1013a13:	add    $0x18,%rax
 1013a17:	dec    %rcx
 1013a1a:	jne    10139f0 <register_shapes+0x140>
 1013a1c:	jmp    1013a76 <register_shapes+0x1c6>
 1013a1e:	mov    0x18(%r12),%rax
 1013a23:	test   %rax,%rax
 1013a26:	je     1013930 <register_shapes+0x80>
 1013a2c:	mov    0x10(%r12),%rcx
 1013a31:	test   %rcx,%rcx
 1013a34:	je     10142e5 <register_shapes+0xa35>
 1013a3a:	mov    0x20(%r12),%rdx
 1013a3f:	mov    (%rcx),%rcx
 1013a42:	cmp    %rcx,%rdx
 1013a45:	jb     10142e5 <register_shapes+0xa35>
 1013a4b:	dec    %rax
 1013a4e:	mul    %rdx
 1013a51:	mov    $0x1,%r9d
 1013a57:	jo     10142d0 <register_shapes+0xa20>
 1013a5d:	add    %rcx,%rax
 1013a60:	jb     10142d0 <register_shapes+0xa20>
 1013a66:	mov    $0x1,%r14d
 1013a6c:	cmp    (%r12),%rax
 1013a70:	ja     10142e5 <register_shapes+0xa35>
 1013a76:	lea    0x10(%r12),%r15
 1013a7b:	mov    $0x8,%r13d
 1013a81:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013a90:	cmpl   $0x3,0x8(%r12)
 1013a96:	mov    %r15,%rax
 1013a99:	je     1013aa1 <register_shapes+0x1f1>
 1013a9b:	mov    (%r15),%rax
 1013a9e:	add    %r13,%rax
 1013aa1:	mov    (%rax),%rsi
 1013aa4:	call   1013600 <builder_add>
 1013aa9:	test   %eax,%eax
 1013aab:	je     10142ca <register_shapes+0xa1a>
 1013ab1:	add    $0x18,%r13
 1013ab5:	dec    %r14
 1013ab8:	mov    -0x30(%rbp),%rdi
 1013abc:	jne    1013a90 <register_shapes+0x1e0>
 1013abe:	jmp    1013918 <register_shapes+0x68>
 1013ac3:	xor    %r13d,%r13d
 1013ac6:	mov    -0x30(%rbp),%r8
 1013aca:	mov    0x18(%r8),%r14
 1013ace:	mov    %r14,%rax
 1013ad1:	shr    $0x3a,%rax
 1013ad5:	mov    $0x1,%r9d
 1013adb:	jne    10142d0 <register_shapes+0xa20>
 1013ae1:	mov    $0x18,%eax
 1013ae6:	mulq   0x28(%r8)
 1013aea:	jo     10142d0 <register_shapes+0xa20>
 1013af0:	mov    %rax,%r12
 1013af3:	mov    $0xc8,%ecx
 1013af8:	mov    %r13,%rax
 1013afb:	mul    %rcx
 1013afe:	jo     10142d0 <register_shapes+0xa20>
 1013b04:	shl    $0x6,%r14
 1013b08:	mov    %r14,%r15
 1013b0b:	add    $0x40,%r15
 1013b0f:	jb     10142d0 <register_shapes+0xa20>
 1013b15:	add    %r12,%r15
 1013b18:	jb     10142d0 <register_shapes+0xa20>
 1013b1e:	add    %rax,%r15
 1013b21:	jb     10142d0 <register_shapes+0xa20>
 1013b27:	mov    (%r8),%rdi
 1013b2a:	mov    %r15,%rsi
 1013b2d:	mov    %r8,%rbx
 1013b30:	call   1012480 <myl_rc_meta_alloc>
 1013b35:	test   %rax,%rax
 1013b38:	je     10142ca <register_shapes+0xa1a>
 1013b3e:	xor    %ecx,%ecx
 1013b40:	mov    %r13,%rsi
 1013b43:	mov    -0x3c(%rbp),%r13d
 1013b47:	test   %r13d,%r13d
 1013b4a:	cmovne -0x58(%rbp),%rcx
 1013b4f:	mov    %rcx,0x8(%rax)
 1013b53:	mov    0x18(%rbx),%rdx
 1013b57:	mov    %rdx,0x20(%rax)
 1013b5b:	mov    %rsi,-0x60(%rbp)
 1013b5f:	mov    %rsi,0x28(%rax)
 1013b63:	mov    %r15,0x30(%rax)
 1013b67:	lea    0x40(%rax),%rcx
 1013b6b:	mov    %rcx,0x10(%rax)
 1013b6f:	lea    (%rax,%r14,1),%rcx
 1013b73:	add    $0x40,%rcx
 1013b77:	add    %rcx,%r12
 1013b7a:	mov    %r12,0x18(%rax)
 1013b7e:	test   %rdx,%rdx
 1013b81:	mov    %rbx,%r9
 1013b84:	mov    %rax,%rbx
 1013b87:	je     1014093 <register_shapes+0x7e3>
 1013b8d:	xor    %edx,%edx
 1013b8f:	jmp    1013bb6 <register_shapes+0x306>
 1013b91:	mov    -0x50(%rbp),%rax
 1013b95:	mov    %rcx,0x18(%rax)
 1013b99:	lea    (%r8,%r8,2),%rax
 1013b9d:	lea    (%rcx,%rax,8),%rcx
 1013ba1:	mov    -0x3c(%rbp),%r13d
 1013ba5:	inc    %rdx
 1013ba8:	mov    -0x30(%rbp),%r9
 1013bac:	cmp    0x18(%r9),%rdx
 1013bb0:	jae    1014093 <register_shapes+0x7e3>
 1013bb6:	lea    0x0(,%rdx,8),%rsi
 1013bbe:	mov    %r9,%r11
 1013bc1:	mov    0x10(%rbx),%r9
 1013bc5:	mov    %rdx,%r10
 1013bc8:	shl    $0x6,%r10
 1013bcc:	lea    (%r9,%r10,1),%r12
 1013bd0:	test   %r13d,%r13d
 1013bd3:	mov    0x8(%r11),%rdi
 1013bd7:	lea    (%rsi,%rsi,4),%rsi
 1013bdb:	mov    (%rdi,%rsi,1),%rdi
 1013bdf:	mov    $0x0,%r8d
 1013be5:	cmovne %rdi,%r8
 1013be9:	mov    %r8,(%r9,%r10,1)
 1013bed:	vmovups (%rdi),%ymm0
 1013bf1:	vmovups %ymm0,0x8(%r9,%r10,1)
 1013bf8:	mov    0x20(%rdi),%r8
 1013bfc:	mov    %r8,0x28(%r9,%r10,1)
 1013c01:	mov    0x8(%r11),%r8
 1013c05:	vmovups 0x10(%r8,%rsi,1),%xmm0
 1013c0c:	cmpq   $0x0,0x10(%r8,%rsi,1)
 1013c12:	vmovups %xmm0,0x30(%r9,%r10,1)
 1013c19:	jne    1013c24 <register_shapes+0x374>
 1013c1b:	movl   $0x0,0x10(%r12)
 1013c24:	mov    0x8(%rdi),%esi
 1013c27:	cmp    $0x3,%esi
 1013c2a:	jne    1013cb6 <register_shapes+0x406>
 1013c30:	cmpq   $0x0,0x18(%rdi)
 1013c35:	je     1013ba5 <register_shapes+0x2f5>
 1013c3b:	mov    0x10(%rdi),%r9
 1013c3f:	mov    -0x30(%rbp),%rsi
 1013c43:	mov    0x10(%rsi),%r10
 1013c47:	mov    0x20(%rsi),%rsi
 1013c4b:	mov    %r9,%r11
 1013c4e:	shr    $0x3,%r11
 1013c52:	mov    %r9,%r14
 1013c55:	shr    $0x21,%r14
 1013c59:	xor    %r11,%r14
 1013c5c:	movabs $0xbf58476d1ce4e5b9,%rax
 1013c66:	imul   %rax,%r14
 1013c6a:	mov    %r14,%r11
 1013c6d:	shr    $0x1b,%r11
 1013c71:	xor    %r14,%r11
 1013c74:	lea    -0x1(,%rsi,2),%r14
 1013c7c:	nopl   0x0(%rax)
 1013c80:	and    %r14,%r11
 1013c83:	mov    (%r10,%r11,8),%r15
 1013c87:	test   %r15,%r15
 1013c8a:	je     1013c9c <register_shapes+0x3ec>
 1013c8c:	lea    (%r15,%r15,4),%rsi
 1013c90:	cmp    %r9,-0x28(%r8,%rsi,8)
 1013c95:	je     1013c9f <register_shapes+0x3ef>
 1013c97:	inc    %r11
 1013c9a:	jmp    1013c80 <register_shapes+0x3d0>
 1013c9c:	xor    %r15d,%r15d
 1013c9f:	mov    0x10(%rbx),%rsi
 1013ca3:	shl    $0x6,%r15
 1013ca7:	add    %r15,%rsi
 1013caa:	add    $0xffffffffffffffc8,%rsi
 1013cae:	mov    %rsi,0x18(%r12)
 1013cb3:	mov    0x8(%rdi),%esi
 1013cb6:	cmp    $0x4,%esi
 1013cb9:	je     1013cc4 <register_shapes+0x414>
 1013cbb:	cmp    $0x2,%esi
 1013cbe:	jne    1013ba5 <register_shapes+0x2f5>
 1013cc4:	mov    %r12,-0x50(%rbp)
 1013cc8:	mov    0x18(%rdi),%r8
 1013ccc:	test   %r8,%r8
 1013ccf:	je     1013b91 <register_shapes+0x2e1>
 1013cd5:	mov    0x10(%rdi),%rdi
 1013cd9:	xor    %r9d,%r9d
 1013cdc:	jmp    1013d05 <register_shapes+0x455>
 1013cde:	xchg   %ax,%ax
 1013ce0:	xor    %r12d,%r12d
 1013ce3:	add    %rcx,%r10
 1013ce6:	mov    0x10(%rbx),%rax
 1013cea:	shl    $0x6,%r12
 1013cee:	add    %r12,%rax
 1013cf1:	add    $0xffffffffffffffc8,%rax
 1013cf5:	mov    %rax,0x8(%r10)
 1013cf9:	inc    %r9
 1013cfc:	cmp    %r8,%r9
 1013cff:	je     1013b91 <register_shapes+0x2e1>
 1013d05:	lea    0x0(,%r9,8),%rsi
 1013d0d:	lea    (%rsi,%rsi,2),%r10
 1013d11:	mov    0x10(%rdi,%r10,1),%rsi
 1013d16:	mov    %rsi,0x10(%rcx,%r10,1)
 1013d1b:	vmovups (%rdi,%r10,1),%xmm0
 1013d21:	vmovups %xmm0,(%rcx,%r10,1)
 1013d27:	mov    0x8(%rdi,%r10,1),%r11
 1013d2c:	mov    -0x30(%rbp),%rax
 1013d30:	mov    0x10(%rax),%r14
 1013d34:	mov    0x20(%rax),%rsi
 1013d38:	mov    %r11,%r15
 1013d3b:	shr    $0x3,%r15
 1013d3f:	mov    %r11,%r12
 1013d42:	shr    $0x21,%r12
 1013d46:	xor    %r15,%r12
 1013d49:	movabs $0xbf58476d1ce4e5b9,%r15
 1013d53:	imul   %r15,%r12
 1013d57:	mov    %r12,%r15
 1013d5a:	shr    $0x1b,%r15
 1013d5e:	xor    %r12,%r15
 1013d61:	lea    -0x1(,%rsi,2),%r13
 1013d69:	and    %r13,%r15
 1013d6c:	mov    (%r14,%r15,8),%r12
 1013d70:	test   %r12,%r12
 1013d73:	je     1013ce0 <register_shapes+0x430>
 1013d79:	mov    0x8(%rax),%rsi
 1013d7d:	nopl   (%rax)
 1013d80:	lea    (%r12,%r12,4),%rax
 1013d84:	cmp    %r11,-0x28(%rsi,%rax,8)
 1013d89:	je     1013ce3 <register_shapes+0x433>
 1013d8f:	inc    %r15
 1013d92:	and    %r13,%r15
 1013d95:	mov    (%r14,%r15,8),%r12
 1013d99:	test   %r12,%r12
 1013d9c:	jne    1013d80 <register_shapes+0x4d0>
 1013d9e:	jmp    1013ce0 <register_shapes+0x430>
 1013da3:	mov    %r15,%rax
 1013da6:	shr    $0x3d,%rax
 1013daa:	mov    $0x1,%r9d
 1013db0:	jne    10142d0 <register_shapes+0xa20>
 1013db6:	test   %r15,%r15
 1013db9:	je     1013de9 <register_shapes+0x539>
 1013dbb:	shl    $0x3,%r15
 1013dbf:	mov    (%rdi),%rdi
 1013dc2:	mov    %r15,%rsi
 1013dc5:	call   1012480 <myl_rc_meta_alloc>
 1013dca:	mov    $0x1,%r9d
 1013dd0:	mov    -0x30(%rbp),%rdi
 1013dd4:	test   %rax,%rax
 1013dd7:	je     10142d0 <register_shapes+0xa20>
 1013ddd:	mov    %rax,%rsi
 1013de0:	mov    %r15,%rdx
 1013de3:	mov    0x18(%rdi),%r15
 1013de7:	jmp    1013ded <register_shapes+0x53d>
 1013de9:	xor    %edx,%edx
 1013deb:	xor    %esi,%esi
 1013ded:	test   %r15,%r15
 1013df0:	je     10138f2 <register_shapes+0x42>
 1013df6:	mov    %rdx,-0x50(%rbp)
 1013dfa:	mov    0x8(%rdi),%rcx
 1013dfe:	xor    %r9d,%r9d
 1013e01:	lea    -0x10d88(%rip),%rbx        # 1003080 <dict_scan+0x30>
 1013e08:	xor    %edx,%edx
 1013e0a:	jmp    1013e20 <register_shapes+0x570>
 1013e0c:	mov    0x18(%rdi),%r15
 1013e10:	mov    -0x38(%rbp),%rdx
 1013e14:	inc    %rdx
 1013e17:	cmp    %r15,%rdx
 1013e1a:	jae    1014086 <register_shapes+0x7d6>
 1013e20:	lea    (%rdx,%rdx,4),%rax
 1013e24:	cmpl   $0x2,0x20(%rcx,%rax,8)
 1013e29:	je     1013e14 <register_shapes+0x564>
 1013e2b:	mov    %rdx,-0x38(%rbp)
 1013e2f:	mov    %rdx,(%rsi)
 1013e32:	mov    $0x1,%r10d
 1013e38:	jmp    1013e57 <register_shapes+0x5a7>
 1013e3a:	nopw   0x0(%rax,%rax,1)
 1013e40:	cmp    %r9,%r14
 1013e43:	cmova  %r14,%r9
 1013e47:	movl   $0x2,0x20(%r11)
 1013e4f:	dec    %r10
 1013e52:	test   %r10,%r10
 1013e55:	je     1013e0c <register_shapes+0x55c>
 1013e57:	mov    -0x8(%rsi,%r10,8),%rax
 1013e5c:	lea    (%rax,%rax,4),%rdx
 1013e60:	movl   $0x1,0x20(%rcx,%rdx,8)
 1013e68:	mov    (%rcx,%rdx,8),%r15
 1013e6c:	mov    0x8(%r15),%eax
 1013e70:	cmp    $0x5,%rax
 1013e74:	ja     10142e5 <register_shapes+0xa35>
 1013e7a:	lea    (%rcx,%rdx,8),%r11
 1013e7e:	mov    0x8(%rcx,%rdx,8),%r14
 1013e83:	movslq (%rbx,%rax,4),%rdx
 1013e87:	add    %rbx,%rdx
 1013e8a:	jmp    *%rdx
 1013e8c:	movq   $0x1,0x10(%r11)
 1013e94:	jmp    1013f80 <register_shapes+0x6d0>
 1013e99:	nopl   0x0(%rax)
 1013ea0:	cmp    0x18(%r15),%r14
 1013ea4:	jae    1013f70 <register_shapes+0x6c0>
 1013eaa:	add    $0x10,%r15
 1013eae:	mov    %r9,%rbx
 1013eb1:	cmp    $0x3,%eax
 1013eb4:	je     1013ee2 <register_shapes+0x632>
 1013eb6:	mov    (%r15),%rax
 1013eb9:	lea    (%r14,%r14,2),%rdx
 1013ebd:	lea    (%rax,%rdx,8),%r15
 1013ec1:	add    $0x8,%r15
 1013ec5:	jmp    1013ee2 <register_shapes+0x632>
 1013ec7:	test   %r14,%r14
 1013eca:	jne    1013f70 <register_shapes+0x6c0>
 1013ed0:	cmpq   $0x0,0x18(%r15)
 1013ed5:	je     1013f70 <register_shapes+0x6c0>
 1013edb:	mov    %r9,%rbx
 1013ede:	add    $0x10,%r15
 1013ee2:	mov    (%r15),%r15
 1013ee5:	mov    0x10(%rdi),%r12
 1013ee9:	mov    0x20(%rdi),%rax
 1013eed:	mov    %r15,%rdx
 1013ef0:	shr    $0x3,%rdx
 1013ef4:	mov    %r15,%r8
 1013ef7:	shr    $0x21,%r8
 1013efb:	xor    %rdx,%r8
 1013efe:	movabs $0xbf58476d1ce4e5b9,%rdx
 1013f08:	imul   %rdx,%r8
 1013f0c:	mov    %r8,%r13
 1013f0f:	shr    $0x1b,%r13
 1013f13:	xor    %r8,%r13
 1013f16:	lea    -0x1(,%rax,2),%r8
 1013f1e:	and    %r8,%r13
 1013f21:	mov    (%r12,%r13,8),%rax
 1013f25:	mov    $0xffffffffffffffff,%rdx
 1013f2c:	test   %rax,%rax
 1013f2f:	je     1014025 <register_shapes+0x775>
 1013f35:	data16 cs nopw 0x0(%rax,%rax,1)
 1013f40:	lea    (%rax,%rax,4),%r9
 1013f44:	cmp    %r15,-0x28(%rcx,%r9,8)
 1013f49:	je     101401b <register_shapes+0x76b>
 1013f4f:	inc    %r13
 1013f52:	and    %r8,%r13
 1013f55:	mov    (%r12,%r13,8),%rax
 1013f59:	test   %rax,%rax
 1013f5c:	jne    1013f40 <register_shapes+0x690>
 1013f5e:	jmp    1014021 <register_shapes+0x771>
 1013f63:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013f70:	mov    0x10(%r11),%rax
 1013f74:	test   %rax,%rax
 1013f77:	je     1013f80 <register_shapes+0x6d0>
 1013f79:	inc    %rax
 1013f7c:	mov    %rax,0x10(%r11)
 1013f80:	mov    0x18(%r11),%r14
 1013f84:	inc    %r14
 1013f87:	mov    %r14,0x18(%r11)
 1013f8b:	mov    (%rdi),%rax
 1013f8e:	mov    0x1608(%rax),%rdx
 1013f95:	mov    0x58(%rdx),%r12
 1013f99:	mov    0x60(%rdx),%rax
 1013f9d:	movzbl 0x70(%rdx),%edx
 1013fa1:	mov    %r15,%r8
 1013fa4:	movabs $0x9e3779b97f4a7c15,%r13
 1013fae:	imul   %r13,%r8
 1013fb2:	shrx   %rdx,%r8,%r13
 1013fb7:	nopw   0x0(%rax,%rax,1)
 1013fc0:	and    %rax,%r13
 1013fc3:	mov    %r13,%rdx
 1013fc6:	shl    $0x4,%rdx
 1013fca:	mov    (%r12,%rdx,1),%rdx
 1013fce:	cmp    %r15,%rdx
 1013fd1:	je     1013ff0 <register_shapes+0x740>
 1013fd3:	test   %rdx,%rdx
 1013fd6:	je     1013e40 <register_shapes+0x590>
 1013fdc:	inc    %r13
 1013fdf:	jmp    1013fc0 <register_shapes+0x710>
 1013fe1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013ff0:	shl    $0x4,%r13
 1013ff4:	mov    0x8(%r12,%r13,1),%rax
 1013ff9:	test   %rax,%rax
 1013ffc:	je     1013e40 <register_shapes+0x590>
 1014002:	mov    0x30(%rax),%rax
 1014006:	cmp    %r14,%rax
 1014009:	jbe    1013e40 <register_shapes+0x590>
 101400f:	mov    %rax,0x18(%r11)
 1014013:	mov    %rax,%r14
 1014016:	jmp    1013e40 <register_shapes+0x590>
 101401b:	dec    %rax
 101401e:	mov    %rax,%rdx
 1014021:	mov    -0x30(%rbp),%rdi
 1014025:	lea    (%rdx,%rdx,4),%rax
 1014029:	mov    0x20(%rcx,%rax,8),%r8d
 101402e:	test   %r8d,%r8d
 1014031:	mov    %rbx,%r9
 1014034:	je     1014073 <register_shapes+0x7c3>
 1014036:	cmp    $0x1,%r8d
 101403a:	lea    -0x10fc1(%rip),%rbx        # 1003080 <dict_scan+0x30>
 1014041:	je     10142e5 <register_shapes+0xa35>
 1014047:	lea    (%rcx,%rax,8),%rax
 101404b:	mov    0x10(%rax),%rdx
 101404f:	cmp    0x10(%r11),%rdx
 1014053:	jbe    1014059 <register_shapes+0x7a9>
 1014055:	mov    %rdx,0x10(%r11)
 1014059:	mov    0x18(%rax),%rax
 101405d:	cmp    0x18(%r11),%rax
 1014061:	jbe    1014067 <register_shapes+0x7b7>
 1014063:	mov    %rax,0x18(%r11)
 1014067:	inc    %r14
 101406a:	mov    %r14,0x8(%r11)
 101406e:	jmp    1013e52 <register_shapes+0x5a2>
 1014073:	mov    %rdx,(%rsi,%r10,8)
 1014077:	inc    %r10
 101407a:	lea    -0x11001(%rip),%rbx        # 1003080 <dict_scan+0x30>
 1014081:	jmp    1013e52 <register_shapes+0x5a2>
 1014086:	mov    %r9,-0x38(%rbp)
 101408a:	mov    -0x50(%rbp),%rdx
 101408e:	jmp    10138fa <register_shapes+0x4a>
 1014093:	mov    -0x60(%rbp),%r13
 1014097:	test   %r13,%r13
 101409a:	mov    -0x58(%rbp),%r15
 101409e:	je     1014196 <register_shapes+0x8e6>
 10140a4:	mov    0x18(%rbx),%rdi
 10140a8:	mov    0x18(%r15),%rdx
 10140ac:	xor    %ecx,%ecx
 10140ae:	jmp    10140de <register_shapes+0x82e>
 10140b0:	xor    %r10d,%r10d
 10140b3:	mov    %r12,%rbx
 10140b6:	shl    $0x6,%r10
 10140ba:	mov    0x10(%rbx),%rax
 10140be:	mov    0x18(%rbx),%rdi
 10140c2:	add    %r10,%rax
 10140c5:	add    $0xffffffffffffffc8,%rax
 10140c9:	mov    %rax,0x8(%rdi,%rsi,1)
 10140ce:	inc    %rcx
 10140d1:	cmp    %r13,%rcx
 10140d4:	mov    -0x30(%rbp),%r9
 10140d8:	je     1014196 <register_shapes+0x8e6>
 10140de:	mov    %rbx,%r12
 10140e1:	imul   $0xc8,%rcx,%rsi
 10140e8:	mov    %rcx,%rax
 10140eb:	shl    $0x6,%rax
 10140ef:	vmovups (%rdx,%rax,1),%ymm0
 10140f4:	vmovups 0x20(%rdx,%rax,1),%ymm1
 10140fa:	vmovups %ymm1,0x20(%rdi,%rsi,1)
 1014100:	vmovups %ymm0,(%rdi,%rsi,1)
 1014105:	mov    0x18(%r15),%rdx
 1014109:	mov    0x8(%rdx,%rax,1),%rdi
 101410e:	mov    0x10(%r9),%r8
 1014112:	mov    0x20(%r9),%rax
 1014116:	mov    %r9,%rbx
 1014119:	mov    %rdi,%r9
 101411c:	shr    $0x3,%r9
 1014120:	mov    %rdi,%r10
 1014123:	shr    $0x21,%r10
 1014127:	xor    %r9,%r10
 101412a:	movabs $0xbf58476d1ce4e5b9,%r9
 1014134:	imul   %r9,%r10
 1014138:	mov    %r10,%r9
 101413b:	shr    $0x1b,%r9
 101413f:	xor    %r10,%r9
 1014142:	lea    -0x1(,%rax,2),%r11
 101414a:	and    %r11,%r9
 101414d:	mov    (%r8,%r9,8),%r10
 1014151:	test   %r10,%r10
 1014154:	je     10140b0 <register_shapes+0x800>
 101415a:	mov    0x8(%rbx),%r14
 101415e:	mov    %r12,%rbx
 1014161:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1014170:	lea    (%r10,%r10,4),%rax
 1014174:	cmp    %rdi,-0x28(%r14,%rax,8)
 1014179:	je     10140b6 <register_shapes+0x806>
 101417f:	inc    %r9
 1014182:	and    %r11,%r9
 1014185:	mov    (%r8,%r9,8),%r10
 1014189:	test   %r10,%r10
 101418c:	jne    1014170 <register_shapes+0x8c0>
 101418e:	xor    %r10d,%r10d
 1014191:	jmp    10140b6 <register_shapes+0x806>
 1014196:	mov    -0x48(%rbp),%rdi
 101419a:	mov    0x1608(%rdi),%rax
 10141a1:	mov    -0x38(%rbp),%rsi
 10141a5:	cmp    0xb8(%rax),%rsi
 10141ac:	jbe    10141e6 <register_shapes+0x936>
 10141ae:	mov    $0x18,%ecx
 10141b3:	mov    %rsi,%rax
 10141b6:	mul    %rcx
 10141b9:	mov    -0x48(%rbp),%rdi
 10141bd:	jo     10141da <register_shapes+0x92a>
 10141bf:	mov    %rax,%rsi
 10141c2:	vzeroupper
 10141c5:	call   1012480 <myl_rc_meta_alloc>
 10141ca:	mov    -0x38(%rbp),%rsi
 10141ce:	mov    -0x48(%rbp),%rdi
 10141d2:	mov    %rax,%r12
 10141d5:	test   %rax,%rax
 10141d8:	jne    10141e9 <register_shapes+0x939>
 10141da:	mov    0x30(%rbx),%rdx
 10141de:	mov    %rbx,%rsi
 10141e1:	jmp    10142c2 <register_shapes+0xa12>
 10141e6:	xor    %r12d,%r12d
 10141e9:	mov    -0x3c(%rbp),%ecx
 10141ec:	cmp    $0x1,%ecx
 10141ef:	mov    $0x2,%eax
 10141f4:	sbb    $0x0,%rax
 10141f8:	mulq   0x20(%rbx)
 10141fc:	jo     101429f <register_shapes+0x9ef>
 1014202:	mov    %ecx,%esi
 1014204:	lea    -0xa8(%rbp),%r8
 101420b:	mov    %rax,%rdx
 101420e:	mov    %rbx,%rcx
 1014211:	vzeroupper
 1014214:	call   10148b0 <index_prepare>
 1014219:	mov    -0x38(%rbp),%rsi
 101421d:	mov    -0x48(%rbp),%rdi
 1014221:	test   %eax,%eax
 1014223:	je     101429f <register_shapes+0x9ef>
 1014225:	lea    -0xa8(%rbp),%rdx
 101422c:	mov    %rbx,%rsi
 101422f:	call   1014b40 <index_commit>
 1014234:	mov    -0x48(%rbp),%rdi
 1014238:	mov    0x1608(%rdi),%rax
 101423f:	test   %r12,%r12
 1014242:	je     101427b <register_shapes+0x9cb>
 1014244:	mov    0xb0(%rax),%rsi
 101424b:	mov    0xb8(%rax),%rax
 1014252:	shl    $0x3,%rax
 1014256:	lea    (%rax,%rax,2),%rdx
 101425a:	mov    %rdi,%r14
 101425d:	call   1012500 <myl_rc_meta_free>
 1014262:	mov    0x1608(%r14),%rax
 1014269:	mov    %r12,0xb0(%rax)
 1014270:	mov    -0x38(%rbp),%rcx
 1014274:	mov    %rcx,0xb8(%rax)
 101427b:	mov    0x28(%rax),%rcx
 101427f:	mov    %rcx,(%rbx)
 1014282:	mov    %rbx,0x28(%rax)
 1014286:	xor    %r9d,%r9d
 1014289:	mov    -0x68(%rbp),%rcx
 101428d:	test   %rcx,%rcx
 1014290:	je     10142d0 <register_shapes+0xa20>
 1014292:	mov    0x10(%rbx),%rax
 1014296:	add    $0x8,%rax
 101429a:	mov    %rax,(%rcx)
 101429d:	jmp    10142d0 <register_shapes+0xa20>
 101429f:	shl    $0x3,%rsi
 10142a3:	lea    (%rsi,%rsi,2),%rdx
 10142a7:	mov    %r12,%rsi
 10142aa:	mov    %rbx,%r14
 10142ad:	mov    %rdi,%rbx
 10142b0:	vzeroupper
 10142b3:	call   1012500 <myl_rc_meta_free>
 10142b8:	mov    0x30(%r14),%rdx
 10142bc:	mov    %rbx,%rdi
 10142bf:	mov    %r14,%rsi
 10142c2:	vzeroupper
 10142c5:	call   1012500 <myl_rc_meta_free>
 10142ca:	mov    $0x1,%r9d
 10142d0:	mov    %r9d,%eax
 10142d3:	add    $0x88,%rsp
 10142da:	pop    %rbx
 10142db:	pop    %r12
 10142dd:	pop    %r13
 10142df:	pop    %r14
 10142e1:	pop    %r15
 10142e3:	pop    %rbp
 10142e4:	ret
 10142e5:	call   101246d <myl_rc_invariant_failed>
 10142ea:	int3
 10142eb:	int3
 10142ec:	int3
 10142ed:	int3
 10142ee:	int3
 10142ef:	int3

00000000010142f0 <myl_rc_module_register_image>:
 10142f0:	push   %rbp
 10142f1:	mov    %rsp,%rbp
 10142f4:	push   %r15
 10142f6:	push   %r14
 10142f8:	push   %r13
 10142fa:	push   %r12
 10142fc:	push   %rbx
 10142fd:	sub    $0x78,%rsp
 1014301:	test   %rdi,%rdi
 1014304:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 101430a:	test   %rsi,%rsi
 101430d:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014313:	mov    0x1608(%rdi),%r8
 101431a:	test   %r8,%r8
 101431d:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014323:	cmpl   $0x5,(%rsi)
 1014326:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101432c:	cmpq   $0x0,0xc0(%r8)
 1014334:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101433a:	test   %rdx,%rdx
 101433d:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014343:	cmpl   $0x1,(%rdx)
 1014346:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101434c:	mov    0x10(%rdx),%rax
 1014350:	cmp    0x10(%rsi),%rax
 1014354:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101435a:	mov    0x20(%rdx),%rcx
 101435e:	mov    %rcx,-0x40(%rbp)
 1014362:	cmp    0x20(%rsi),%rcx
 1014366:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101436c:	test   %rax,%rax
 101436f:	je     1014387 <myl_rc_module_register_image+0x97>
 1014371:	cmpq   $0x0,0x8(%rdx)
 1014376:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 101437c:	cmpq   $0x0,0x8(%rsi)
 1014381:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014387:	cmpq   $0x0,-0x40(%rbp)
 101438c:	je     10143a4 <myl_rc_module_register_image+0xb4>
 101438e:	cmpq   $0x0,0x18(%rdx)
 1014393:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014399:	cmpq   $0x0,0x18(%rsi)
 101439e:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 10143a4:	mov    %r8,-0x58(%rbp)
 10143a8:	mov    %rsi,-0x50(%rbp)
 10143ac:	mov    %rdi,-0x30(%rbp)
 10143b0:	test   %rax,%rax
 10143b3:	mov    %rax,-0x48(%rbp)
 10143b7:	mov    %rdx,-0x38(%rbp)
 10143bb:	je     10144a1 <myl_rc_module_register_image+0x1b1>
 10143c1:	mov    0x8(%rdx),%rcx
 10143c5:	mov    (%rcx),%r8
 10143c8:	test   %r8,%r8
 10143cb:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 10143d1:	mov    (%r8),%rdx
 10143d4:	test   %rdx,%rdx
 10143d7:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 10143dd:	mov    -0x50(%rbp),%rax
 10143e1:	mov    0x8(%rax),%rdi
 10143e5:	cmp    (%rdi),%rdx
 10143e8:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 10143ee:	mov    0x8(%r8),%rsi
 10143f2:	cmp    (%rdx),%rsi
 10143f5:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 10143fb:	mov    0x38(%r8),%rdx
 10143ff:	test   %rdx,%rdx
 1014402:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014408:	cmp    %rdx,0x30(%r8)
 101440c:	ja     10148a7 <myl_rc_module_register_image+0x5b7>
 1014412:	mov    -0x38(%rbp),%rax
 1014416:	mov    0x28(%rax),%r8
 101441a:	mov    -0x48(%rbp),%rax
 101441e:	cmp    %r8,%rdx
 1014421:	ja     10148a7 <myl_rc_module_register_image+0x5b7>
 1014427:	cmp    $0x1,%rax
 101442b:	je     10144a7 <myl_rc_module_register_image+0x1b7>
 101442d:	mov    $0x1,%r9d
 1014433:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1014440:	mov    (%rcx,%r9,8),%r10
 1014444:	test   %r10,%r10
 1014447:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 101444d:	mov    (%r10),%rsi
 1014450:	test   %rsi,%rsi
 1014453:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014459:	cmp    (%rdi,%r9,8),%rsi
 101445d:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 1014463:	mov    0x8(%r10),%r11
 1014467:	cmp    (%rsi),%r11
 101446a:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 1014470:	mov    0x38(%r10),%rsi
 1014474:	test   %rsi,%rsi
 1014477:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 101447d:	cmp    %r8,%rsi
 1014480:	ja     10148a7 <myl_rc_module_register_image+0x5b7>
 1014486:	cmp    %rsi,0x30(%r10)
 101448a:	ja     10148a7 <myl_rc_module_register_image+0x5b7>
 1014490:	cmp    %rdx,%rsi
 1014493:	cmova  %rsi,%rdx
 1014497:	inc    %r9
 101449a:	cmp    %r9,%rax
 101449d:	jne    1014440 <myl_rc_module_register_image+0x150>
 101449f:	jmp    10144a7 <myl_rc_module_register_image+0x1b7>
 10144a1:	mov    0x28(%rdx),%r8
 10144a5:	xor    %edx,%edx
 10144a7:	cmp    %rdx,%r8
 10144aa:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 10144b0:	cmpq   $0x0,-0x40(%rbp)
 10144b5:	je     10146a5 <myl_rc_module_register_image+0x3b5>
 10144bb:	mov    -0x38(%rbp),%rax
 10144bf:	mov    0x18(%rax),%rdx
 10144c3:	mov    -0x50(%rbp),%rax
 10144c7:	mov    0x18(%rax),%rax
 10144cb:	lea    0x9c(%rdx),%r8
 10144d2:	lea    0x60(%rdx),%r9
 10144d6:	xor    %r10d,%r10d
 10144d9:	jmp    1014504 <myl_rc_module_register_image+0x214>
 10144db:	nopl   0x0(%rax,%rax,1)
 10144e0:	or     %cl,%r11b
 10144e3:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 10144e9:	inc    %r10
 10144ec:	add    $0xc8,%r8
 10144f3:	add    $0xc8,%r9
 10144fa:	cmp    -0x40(%rbp),%r10
 10144fe:	je     10146a5 <myl_rc_module_register_image+0x3b5>
 1014504:	imul   $0xc8,%r10,%rbx
 101450b:	mov    (%rdx,%rbx,1),%rcx
 101450f:	test   %rcx,%rcx
 1014512:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014518:	add    %rdx,%rbx
 101451b:	mov    0x8(%rbx),%rdi
 101451f:	test   %rdi,%rdi
 1014522:	je     10148a7 <myl_rc_module_register_image+0x5b7>
 1014528:	mov    %r10,%r11
 101452b:	shl    $0x6,%r11
 101452f:	add    %rax,%r11
 1014532:	cmp    (%r11),%rcx
 1014535:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101453b:	mov    (%rcx),%r15
 101453e:	cmp    (%rdi),%r15
 1014541:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 1014547:	cmpl   $0x0,0xc0(%rbx)
 101454e:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 1014554:	cmp    %r15,0x50(%rbx)
 1014558:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101455e:	mov    0x40(%rbx),%r14d
 1014562:	cmp    $0x11,%r14
 1014566:	ja     10148a7 <myl_rc_module_register_image+0x5b7>
 101456c:	movzbl 0x44(%rbx),%ecx
 1014570:	cmp    $0x1,%cl
 1014573:	ja     10148a7 <myl_rc_module_register_image+0x5b7>
 1014579:	cmpb   $0x0,0x45(%rbx)
 101457d:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 1014583:	movzbl 0x46(%rbx),%r11d
 1014588:	cmp    $0x2,%r11b
 101458c:	jae    10148a7 <myl_rc_module_register_image+0x5b7>
 1014592:	cmp    $0x11,%r14d
 1014596:	je     10144e0 <myl_rc_module_register_image+0x1f0>
 101459c:	movzwl 0x58(%rbx),%r12d
 10145a1:	mov    $0xffff,%ecx
 10145a6:	shrx   %r14d,%ecx,%ecx
 10145ab:	shlx   %r14d,%ecx,%ecx
 10145b0:	xor    %r12d,%ecx
 10145b3:	cmp    $0xffff,%ecx
 10145b9:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 10145bf:	movzwl 0x5a(%rbx),%r13d
 10145c4:	andn   %r13d,%r12d,%ecx
 10145c9:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 10145cf:	test   %r14,%r14
 10145d2:	je     1014606 <myl_rc_module_register_image+0x316>
 10145d4:	mov    %r15,%rcx
 10145d7:	sub    $0x8,%rcx
 10145db:	jb     10148a7 <myl_rc_module_register_image+0x5b7>
 10145e1:	xor    %edi,%edi
 10145e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10145f0:	movzwl (%r8,%rdi,2),%esi
 10145f5:	cmp    %rsi,%rcx
 10145f8:	jb     10148a7 <myl_rc_module_register_image+0x5b7>
 10145fe:	inc    %rdi
 1014601:	cmp    %rdi,%r14
 1014604:	jne    10145f0 <myl_rc_module_register_image+0x300>
 1014606:	test   %r11b,%r11b
 1014609:	je     1014626 <myl_rc_module_register_image+0x336>
 101460b:	cmp    $0x4,%r15
 101460f:	jb     10148a7 <myl_rc_module_register_image+0x5b7>
 1014615:	mov    0x48(%rbx),%ecx
 1014618:	add    $0xfffffffffffffffc,%r15
 101461c:	cmp    %rcx,%r15
 101461f:	jae    101463a <myl_rc_module_register_image+0x34a>
 1014621:	jmp    10148a7 <myl_rc_module_register_image+0x5b7>
 1014626:	cmp    %r12w,%r13w
 101462a:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 1014630:	cmpl   $0xffffffff,0x48(%rbx)
 1014634:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101463a:	not    %r12d
 101463d:	movzwl 0x5c(%rbx),%ecx
 1014641:	test   %r12d,%ecx
 1014644:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101464a:	and    %r13d,%ecx
 101464d:	cmp    %r13d,%ecx
 1014650:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 1014656:	xor    %ecx,%ecx
 1014658:	nopl   0x0(%rax,%rax,1)
 1014660:	movzwl -0x2(%r9,%rcx,2),%edi
 1014666:	test   %r12d,%edi
 1014669:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101466f:	and    %r13d,%edi
 1014672:	cmp    %r13d,%edi
 1014675:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101467b:	cmp    $0x1e,%rcx
 101467f:	je     10144e9 <myl_rc_module_register_image+0x1f9>
 1014685:	movzwl (%r9,%rcx,2),%edi
 101468a:	test   %r12d,%edi
 101468d:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 1014693:	and    %r13d,%edi
 1014696:	cmp    %r13d,%edi
 1014699:	jne    10148a7 <myl_rc_module_register_image+0x5b7>
 101469f:	add    $0x2,%rcx
 10146a3:	jmp    1014660 <myl_rc_module_register_image+0x370>
 10146a5:	mov    -0x58(%rbp),%rax
 10146a9:	mov    0x38(%rax),%rcx
 10146ad:	mov    0x40(%rax),%rdi
 10146b1:	movzbl 0x50(%rax),%eax
 10146b5:	movabs $0x9e3779b97f4a7c15,%rdx
 10146bf:	mov    -0x50(%rbp),%r14
 10146c3:	imul   %r14,%rdx
 10146c7:	shrx   %rax,%rdx,%rdx
 10146cc:	nopl   0x0(%rax)
 10146d0:	and    %rdi,%rdx
 10146d3:	mov    %rdx,%rax
 10146d6:	shl    $0x4,%rax
 10146da:	mov    (%rcx,%rax,1),%r8
 10146de:	cmp    %r14,%r8
 10146e1:	je     10146ed <myl_rc_module_register_image+0x3fd>
 10146e3:	test   %r8,%r8
 10146e6:	je     1014700 <myl_rc_module_register_image+0x410>
 10146e8:	inc    %rdx
 10146eb:	jmp    10146d0 <myl_rc_module_register_image+0x3e0>
 10146ed:	shl    $0x4,%rdx
 10146f1:	xor    %r12d,%r12d
 10146f4:	cmpq   $0x0,0x8(%rcx,%rdx,1)
 10146fa:	jne    1014895 <myl_rc_module_register_image+0x5a5>
 1014700:	mov    $0xc8,%ecx
 1014705:	mov    -0x40(%rbp),%rax
 1014709:	mul    %rcx
 101470c:	mov    $0x1,%r12d
 1014712:	jo     1014895 <myl_rc_module_register_image+0x5a5>
 1014718:	mov    %rax,%r13
 101471b:	mov    %rax,%rbx
 101471e:	add    $0x40,%rbx
 1014722:	jb     1014895 <myl_rc_module_register_image+0x5a5>
 1014728:	cmpq   $0x0,-0x48(%rbp)
 101472d:	js     1014895 <myl_rc_module_register_image+0x5a5>
 1014733:	mov    -0x30(%rbp),%rdi
 1014737:	mov    %rbx,%rsi
 101473a:	call   1012480 <myl_rc_meta_alloc>
 101473f:	test   %rax,%rax
 1014742:	je     1014895 <myl_rc_module_register_image+0x5a5>
 1014748:	mov    %r14,0x8(%rax)
 101474c:	mov    -0x38(%rbp),%rcx
 1014750:	mov    %rcx,0x38(%rax)
 1014754:	mov    0x10(%rcx),%rdx
 1014758:	mov    %rdx,0x20(%rax)
 101475c:	mov    0x20(%rcx),%rdx
 1014760:	mov    %rdx,0x28(%rax)
 1014764:	mov    %rbx,0x30(%rax)
 1014768:	mov    %rax,%rdi
 101476b:	add    $0x40,%rdi
 101476f:	mov    %rdi,0x18(%rax)
 1014773:	test   %r13,%r13
 1014776:	mov    %rax,%r12
 1014779:	je     101478d <myl_rc_module_register_image+0x49d>
 101477b:	mov    0x18(%rcx),%rsi
 101477f:	mov    %rcx,%r14
 1014782:	mov    %r13,%rdx
 1014785:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101478a:	mov    %r14,%rcx
 101478d:	mov    0x28(%rcx),%rax
 1014791:	mov    -0x30(%rbp),%rdi
 1014795:	mov    0x1608(%rdi),%rcx
 101479c:	xor    %r15d,%r15d
 101479f:	mov    $0x0,%r13d
 10147a5:	cmp    0xb8(%rcx),%rax
 10147ac:	jbe    10147db <myl_rc_module_register_image+0x4eb>
 10147ae:	mov    $0x18,%ecx
 10147b3:	mul    %rcx
 10147b6:	mov    %rax,%r15
 10147b9:	jno    10147c3 <myl_rc_module_register_image+0x4d3>
 10147bb:	xor    %r13d,%r13d
 10147be:	jmp    1014873 <myl_rc_module_register_image+0x583>
 10147c3:	mov    %r15,%rsi
 10147c6:	call   1012480 <myl_rc_meta_alloc>
 10147cb:	test   %rax,%rax
 10147ce:	je     101486c <myl_rc_module_register_image+0x57c>
 10147d4:	mov    %rax,%r13
 10147d7:	mov    -0x30(%rbp),%rdi
 10147db:	mov    -0x48(%rbp),%rdx
 10147df:	add    %rdx,%rdx
 10147e2:	lea    -0x98(%rbp),%r8
 10147e9:	mov    $0x1,%esi
 10147ee:	mov    %r12,%rcx
 10147f1:	mov    %rdi,%r14
 10147f4:	call   10148b0 <index_prepare>
 10147f9:	test   %eax,%eax
 10147fb:	je     1014867 <myl_rc_module_register_image+0x577>
 10147fd:	lea    -0x98(%rbp),%rdx
 1014804:	mov    %r14,%rdi
 1014807:	mov    %r12,%rsi
 101480a:	call   1014b40 <index_commit>
 101480f:	mov    0x1608(%r14),%rax
 1014816:	test   %r13,%r13
 1014819:	je     1014856 <myl_rc_module_register_image+0x566>
 101481b:	mov    0xb0(%rax),%rsi
 1014822:	mov    0xb8(%rax),%rax
 1014829:	shl    $0x3,%rax
 101482d:	lea    (%rax,%rax,2),%rdx
 1014831:	mov    %r14,%rdi
 1014834:	call   1012500 <myl_rc_meta_free>
 1014839:	mov    0x1608(%r14),%rax
 1014840:	mov    %r13,0xb0(%rax)
 1014847:	mov    -0x38(%rbp),%rcx
 101484b:	mov    0x28(%rcx),%rcx
 101484f:	mov    %rcx,0xb8(%rax)
 1014856:	mov    0x28(%rax),%rcx
 101485a:	mov    %rcx,(%r12)
 101485e:	mov    %r12,0x28(%rax)
 1014862:	xor    %r12d,%r12d
 1014865:	jmp    1014895 <myl_rc_module_register_image+0x5a5>
 1014867:	mov    %r14,%rdi
 101486a:	jmp    1014873 <myl_rc_module_register_image+0x583>
 101486c:	xor    %r13d,%r13d
 101486f:	mov    -0x30(%rbp),%rdi
 1014873:	mov    %r13,%rsi
 1014876:	mov    %r15,%rdx
 1014879:	mov    %rdi,%r14
 101487c:	call   1012500 <myl_rc_meta_free>
 1014881:	mov    %r14,%rdi
 1014884:	mov    %r12,%rsi
 1014887:	mov    %rbx,%rdx
 101488a:	call   1012500 <myl_rc_meta_free>
 101488f:	mov    $0x1,%r12d
 1014895:	mov    %r12d,%eax
 1014898:	add    $0x78,%rsp
 101489c:	pop    %rbx
 101489d:	pop    %r12
 101489f:	pop    %r13
 10148a1:	pop    %r14
 10148a3:	pop    %r15
 10148a5:	pop    %rbp
 10148a6:	ret
 10148a7:	call   101246d <myl_rc_invariant_failed>
 10148ac:	int3
 10148ad:	int3
 10148ae:	int3
 10148af:	int3

00000000010148b0 <index_prepare>:
 10148b0:	push   %rbp
 10148b1:	mov    %rsp,%rbp
 10148b4:	push   %r15
 10148b6:	push   %r14
 10148b8:	push   %r13
 10148ba:	push   %r12
 10148bc:	push   %rbx
 10148bd:	sub    $0x18,%rsp
 10148c1:	mov    %r8,%rbx
 10148c4:	mov    %rdx,-0x40(%rbp)
 10148c8:	mov    %rsi,%rdx
 10148cb:	mov    %rdi,%r14
 10148ce:	vxorps %xmm0,%xmm0,%xmm0
 10148d2:	vmovups %ymm0,0x20(%r8)
 10148d8:	vmovups %ymm0,(%r8)
 10148dd:	mov    0x1608(%rdi),%r15
 10148e4:	mov    0x28(%rcx),%rax
 10148e8:	xor    %edi,%edi
 10148ea:	test   %rax,%rax
 10148ed:	je     10149a3 <index_prepare+0xf3>
 10148f3:	mov    %rdx,-0x30(%rbp)
 10148f7:	mov    %r14,-0x38(%rbp)
 10148fb:	mov    0xa8(%r15),%rdx
 1014902:	add    %rax,%rdx
 1014905:	lea    0x10(,%rdx,4),%rdx
 101490d:	mov    0xa0(%r15),%r13
 1014914:	mov    0x18(%rcx),%rsi
 1014918:	xor    %r12d,%r12d
 101491b:	xor    %r8d,%r8d
 101491e:	mov    %r13,%rcx
 1014921:	jmp    1014952 <index_prepare+0xa2>
 1014923:	mov    0x98(%r15),%r11
 101492a:	mov    %r10,%r14
 101492d:	shl    $0x4,%r14
 1014931:	cmpq   $0x0,(%r11,%r14,1)
 1014936:	je     101498c <index_prepare+0xdc>
 1014938:	nopl   0x0(%rax,%rax,1)
 1014940:	inc    %r8
 1014943:	mov    %r8,%r12
 1014946:	add    $0xc8,%rsi
 101494d:	dec    %rax
 1014950:	je     1014998 <index_prepare+0xe8>
 1014952:	mov    (%rsi),%r9
 1014955:	mov    0x34(%r9),%r9d
 1014959:	test   %r9d,%r9d
 101495c:	setne  %r10b
 1014960:	cmp    %edi,%r9d
 1014963:	seta   %r11b
 1014967:	and    %r10b,%r11b
 101496a:	cmp    $0x1,%r11b
 101496e:	jne    1014940 <index_prepare+0x90>
 1014970:	mov    %r9d,%r10d
 1014973:	cmp    %r10,%rdx
 1014976:	jbe    1014940 <index_prepare+0x90>
 1014978:	cmp    %r10,%r13
 101497b:	ja     1014923 <index_prepare+0x73>
 101497d:	inc    %r10
 1014980:	cmp    %r10,%rcx
 1014983:	cmovbe %r10,%rcx
 1014987:	mov    %r9d,%edi
 101498a:	jmp    1014946 <index_prepare+0x96>
 101498c:	add    %r14,%r11
 101498f:	cmpq   $0x0,0x8(%r11)
 1014994:	jne    1014940 <index_prepare+0x90>
 1014996:	jmp    101497d <index_prepare+0xcd>
 1014998:	cmp    %r13,%rcx
 101499b:	jne    10149a8 <index_prepare+0xf8>
 101499d:	mov    -0x38(%rbp),%r14
 10149a1:	jmp    1014a12 <index_prepare+0x162>
 10149a3:	xor    %r12d,%r12d
 10149a6:	jmp    1014a16 <index_prepare+0x166>
 10149a8:	add    %r13,%r13
 10149ab:	cmp    %r13,%rcx
 10149ae:	cmova  %rcx,%r13
 10149b2:	mov    %r13,%rax
 10149b5:	shr    $0x3c,%rax
 10149b9:	mov    -0x38(%rbp),%r14
 10149bd:	jne    1014a77 <index_prepare+0x1c7>
 10149c3:	mov    %r13,%rsi
 10149c6:	shl    $0x4,%rsi
 10149ca:	mov    %r14,%rdi
 10149cd:	vzeroupper
 10149d0:	call   1012480 <myl_rc_meta_alloc>
 10149d5:	test   %rax,%rax
 10149d8:	je     1014a77 <index_prepare+0x1c7>
 10149de:	mov    0xa0(%r15),%rdx
 10149e5:	test   %rdx,%rdx
 10149e8:	je     1014a03 <index_prepare+0x153>
 10149ea:	mov    0x98(%r15),%rsi
 10149f1:	shl    $0x4,%rdx
 10149f5:	mov    %rax,%rdi
 10149f8:	mov    %rax,%r15
 10149fb:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1014a00:	mov    %r15,%rax
 1014a03:	mov    %rax,0x30(%rbx)
 1014a07:	mov    %r13,0x38(%rbx)
 1014a0b:	mov    0x1608(%r14),%r15
 1014a12:	mov    -0x30(%rbp),%rdx
 1014a16:	add    $0x38,%r15
 1014a1a:	mov    %r14,%rdi
 1014a1d:	mov    %r15,%rsi
 1014a20:	mov    %rbx,%rcx
 1014a23:	vzeroupper
 1014a26:	call   10155d0 <map_prepare>
 1014a2b:	test   %eax,%eax
 1014a2d:	je     1014a77 <index_prepare+0x1c7>
 1014a2f:	mov    0x1608(%r14),%rsi
 1014a36:	add    $0x58,%rsi
 1014a3a:	lea    0x10(%rbx),%rcx
 1014a3e:	mov    %r14,%rdi
 1014a41:	mov    -0x40(%rbp),%rdx
 1014a45:	call   10155d0 <map_prepare>
 1014a4a:	test   %eax,%eax
 1014a4c:	je     1014a77 <index_prepare+0x1c7>
 1014a4e:	mov    0x1608(%r14),%rsi
 1014a55:	add    $0x78,%rsi
 1014a59:	lea    0x20(%rbx),%rcx
 1014a5d:	mov    %r14,%rdi
 1014a60:	mov    %r12,%rdx
 1014a63:	call   10155d0 <map_prepare>
 1014a68:	mov    %eax,%ecx
 1014a6a:	mov    $0x1,%eax
 1014a6f:	test   %ecx,%ecx
 1014a71:	jne    1014b23 <index_prepare+0x273>
 1014a77:	mov    (%rbx),%rsi
 1014a7a:	test   %rsi,%rsi
 1014a7d:	je     1014a96 <index_prepare+0x1e6>
 1014a7f:	mov    0x8(%rbx),%rdx
 1014a83:	shl    $0x4,%rdx
 1014a87:	add    $0x10,%rdx
 1014a8b:	mov    %r14,%rdi
 1014a8e:	vzeroupper
 1014a91:	call   1012500 <myl_rc_meta_free>
 1014a96:	vxorps %xmm0,%xmm0,%xmm0
 1014a9a:	vmovups %xmm0,(%rbx)
 1014a9e:	lea    0x10(%rbx),%r15
 1014aa2:	mov    0x10(%rbx),%rsi
 1014aa6:	test   %rsi,%rsi
 1014aa9:	je     1014ac6 <index_prepare+0x216>
 1014aab:	mov    0x18(%rbx),%rdx
 1014aaf:	shl    $0x4,%rdx
 1014ab3:	add    $0x10,%rdx
 1014ab7:	mov    %r14,%rdi
 1014aba:	vzeroupper
 1014abd:	call   1012500 <myl_rc_meta_free>
 1014ac2:	vxorps %xmm0,%xmm0,%xmm0
 1014ac6:	vmovups %xmm0,(%r15)
 1014acb:	lea    0x20(%rbx),%r15
 1014acf:	mov    0x20(%rbx),%rsi
 1014ad3:	test   %rsi,%rsi
 1014ad6:	je     1014aef <index_prepare+0x23f>
 1014ad8:	mov    0x28(%rbx),%rdx
 1014adc:	shl    $0x4,%rdx
 1014ae0:	add    $0x10,%rdx
 1014ae4:	mov    %r14,%rdi
 1014ae7:	vzeroupper
 1014aea:	call   1012500 <myl_rc_meta_free>
 1014aef:	vxorps %xmm0,%xmm0,%xmm0
 1014af3:	vmovups %xmm0,(%r15)
 1014af8:	mov    0x30(%rbx),%rsi
 1014afc:	test   %rsi,%rsi
 1014aff:	je     1014b14 <index_prepare+0x264>
 1014b01:	mov    0x38(%rbx),%rdx
 1014b05:	shl    $0x4,%rdx
 1014b09:	mov    %r14,%rdi
 1014b0c:	vzeroupper
 1014b0f:	call   1012500 <myl_rc_meta_free>
 1014b14:	vxorps %xmm0,%xmm0,%xmm0
 1014b18:	vmovups %ymm0,0x20(%rbx)
 1014b1d:	vmovups %ymm0,(%rbx)
 1014b21:	xor    %eax,%eax
 1014b23:	add    $0x18,%rsp
 1014b27:	pop    %rbx
 1014b28:	pop    %r12
 1014b2a:	pop    %r13
 1014b2c:	pop    %r14
 1014b2e:	pop    %r15
 1014b30:	pop    %rbp
 1014b31:	vzeroupper
 1014b34:	ret
 1014b35:	int3
 1014b36:	int3
 1014b37:	int3
 1014b38:	int3
 1014b39:	int3
 1014b3a:	int3
 1014b3b:	int3
 1014b3c:	int3
 1014b3d:	int3
 1014b3e:	int3
 1014b3f:	int3

0000000001014b40 <index_commit>:
 1014b40:	push   %rbp
 1014b41:	mov    %rsp,%rbp
 1014b44:	push   %r15
 1014b46:	push   %r14
 1014b48:	push   %r13
 1014b4a:	push   %r12
 1014b4c:	push   %rbx
 1014b4d:	sub    $0x28,%rsp
 1014b51:	mov    %rdx,%r15
 1014b54:	mov    %rsi,%rbx
 1014b57:	mov    %rdi,%r13
 1014b5a:	mov    0x1608(%rdi),%rax
 1014b61:	cmpq   $0x0,(%rdx)
 1014b65:	je     1014c1d <index_commit+0xdd>
 1014b6b:	mov    0x38(%rax),%rsi
 1014b6f:	mov    0x48(%rax),%r14
 1014b73:	cmp    $0x10030a0,%rsi
 1014b7a:	je     1014b9c <index_commit+0x5c>
 1014b7c:	mov    0x40(%rax),%rdx
 1014b80:	cmp    $0xffffffffffffffff,%rdx
 1014b84:	je     1014b9c <index_commit+0x5c>
 1014b86:	shl    $0x4,%rdx
 1014b8a:	add    $0x10,%rdx
 1014b8e:	mov    %r13,%rdi
 1014b91:	mov    %rax,%r12
 1014b94:	call   1012500 <myl_rc_meta_free>
 1014b99:	mov    %r12,%rax
 1014b9c:	mov    %rax,%rcx
 1014b9f:	lea    -0x11b06(%rip),%rax        # 10030a0 <myl_rc_map_sentinel>
 1014ba6:	mov    %rax,0x38(%rcx)
 1014baa:	vxorps %xmm0,%xmm0,%xmm0
 1014bae:	vmovups %xmm0,0x40(%rcx)
 1014bb3:	mov    %rcx,%r8
 1014bb6:	movl   $0x0,0x54(%rcx)
 1014bbd:	mov    (%r15),%rax
 1014bc0:	mov    0x8(%r15),%rcx
 1014bc4:	lea    0x1(%rcx),%rdx
 1014bc8:	mov    $0x3f,%edi
 1014bcd:	cmp    $0x2,%rdx
 1014bd1:	jb     1014bf9 <index_commit+0xb9>
 1014bd3:	mov    $0x40,%esi
 1014bd8:	mov    %rdx,%rdi
 1014bdb:	nopl   0x0(%rax,%rax,1)
 1014be0:	shr    $1,%rdi
 1014be3:	dec    %esi
 1014be5:	cmp    $0x3,%rdx
 1014be9:	mov    %rdi,%rdx
 1014bec:	ja     1014be0 <index_commit+0xa0>
 1014bee:	cmp    $0x3f,%esi
 1014bf1:	mov    $0x3f,%edi
 1014bf6:	cmovb  %esi,%edi
 1014bf9:	mov    %rax,0x38(%r8)
 1014bfd:	mov    %rcx,0x40(%r8)
 1014c01:	mov    %r14,0x48(%r8)
 1014c05:	mov    %edi,0x50(%r8)
 1014c09:	movl   $0x0,0x54(%r8)
 1014c11:	vmovups %xmm0,(%r15)
 1014c16:	mov    0x1608(%r13),%rax
 1014c1d:	cmpq   $0x0,0x10(%r15)
 1014c22:	je     1014cde <index_commit+0x19e>
 1014c28:	mov    0x58(%rax),%rsi
 1014c2c:	mov    0x68(%rax),%r14
 1014c30:	cmp    $0x10030a0,%rsi
 1014c37:	je     1014c59 <index_commit+0x119>
 1014c39:	mov    0x60(%rax),%rdx
 1014c3d:	cmp    $0xffffffffffffffff,%rdx
 1014c41:	je     1014c59 <index_commit+0x119>
 1014c43:	shl    $0x4,%rdx
 1014c47:	add    $0x10,%rdx
 1014c4b:	mov    %r13,%rdi
 1014c4e:	mov    %rax,%r12
 1014c51:	call   1012500 <myl_rc_meta_free>
 1014c56:	mov    %r12,%rax
 1014c59:	mov    %rax,%rdx
 1014c5c:	lea    0x10(%r15),%rax
 1014c60:	lea    -0x11bc7(%rip),%rcx        # 10030a0 <myl_rc_map_sentinel>
 1014c67:	mov    %rcx,0x58(%rdx)
 1014c6b:	vxorps %xmm0,%xmm0,%xmm0
 1014c6f:	vmovups %xmm0,0x60(%rdx)
 1014c74:	mov    %rdx,%r9
 1014c77:	movl   $0x0,0x74(%rdx)
 1014c7e:	mov    0x10(%r15),%rcx
 1014c82:	mov    0x18(%r15),%rdx
 1014c86:	lea    0x1(%rdx),%rsi
 1014c8a:	mov    $0x3f,%r8d
 1014c90:	cmp    $0x2,%rsi
 1014c94:	jb     1014cbb <index_commit+0x17b>
 1014c96:	mov    $0x40,%edi
 1014c9b:	mov    %rsi,%r8
 1014c9e:	xchg   %ax,%ax
 1014ca0:	shr    $1,%r8
 1014ca3:	dec    %edi
 1014ca5:	cmp    $0x3,%rsi
 1014ca9:	mov    %r8,%rsi
 1014cac:	ja     1014ca0 <index_commit+0x160>
 1014cae:	cmp    $0x3f,%edi
 1014cb1:	mov    $0x3f,%r8d
 1014cb7:	cmovb  %edi,%r8d
 1014cbb:	mov    %rcx,0x58(%r9)
 1014cbf:	mov    %rdx,0x60(%r9)
 1014cc3:	mov    %r14,0x68(%r9)
 1014cc7:	mov    %r8d,0x70(%r9)
 1014ccb:	movl   $0x0,0x74(%r9)
 1014cd3:	vmovups %xmm0,(%rax)
 1014cd7:	mov    0x1608(%r13),%rax
 1014cde:	cmpq   $0x0,0x20(%r15)
 1014ce3:	je     1014dba <index_commit+0x27a>
 1014ce9:	mov    0x78(%rax),%rsi
 1014ced:	mov    0x88(%rax),%r14
 1014cf4:	cmp    $0x10030a0,%rsi
 1014cfb:	je     1014d20 <index_commit+0x1e0>
 1014cfd:	mov    0x80(%rax),%rdx
 1014d04:	cmp    $0xffffffffffffffff,%rdx
 1014d08:	je     1014d20 <index_commit+0x1e0>
 1014d0a:	shl    $0x4,%rdx
 1014d0e:	add    $0x10,%rdx
 1014d12:	mov    %r13,%rdi
 1014d15:	mov    %rax,%r12
 1014d18:	call   1012500 <myl_rc_meta_free>
 1014d1d:	mov    %r12,%rax
 1014d20:	mov    %rax,%rdx
 1014d23:	lea    0x20(%r15),%rax
 1014d27:	lea    -0x11c8e(%rip),%rcx        # 10030a0 <myl_rc_map_sentinel>
 1014d2e:	mov    %rcx,0x78(%rdx)
 1014d32:	vxorps %xmm0,%xmm0,%xmm0
 1014d36:	vmovups %xmm0,0x80(%rdx)
 1014d3e:	mov    %rdx,%r9
 1014d41:	movl   $0x0,0x94(%rdx)
 1014d4b:	mov    0x20(%r15),%rcx
 1014d4f:	mov    0x28(%r15),%rdx
 1014d53:	lea    0x1(%rdx),%rsi
 1014d57:	mov    $0x3f,%r8d
 1014d5d:	cmp    $0x2,%rsi
 1014d61:	jb     1014d8b <index_commit+0x24b>
 1014d63:	mov    $0x40,%edi
 1014d68:	mov    %rsi,%r8
 1014d6b:	nopl   0x0(%rax,%rax,1)
 1014d70:	shr    $1,%r8
 1014d73:	dec    %edi
 1014d75:	cmp    $0x3,%rsi
 1014d79:	mov    %r8,%rsi
 1014d7c:	ja     1014d70 <index_commit+0x230>
 1014d7e:	cmp    $0x3f,%edi
 1014d81:	mov    $0x3f,%r8d
 1014d87:	cmovb  %edi,%r8d
 1014d8b:	mov    %rcx,0x78(%r9)
 1014d8f:	mov    %rdx,0x80(%r9)
 1014d96:	mov    %r14,0x88(%r9)
 1014d9d:	mov    %r8d,0x90(%r9)
 1014da4:	movl   $0x0,0x94(%r9)
 1014daf:	vmovups %xmm0,(%rax)
 1014db3:	mov    0x1608(%r13),%rax
 1014dba:	mov    %rax,-0x30(%rbp)
 1014dbe:	mov    0x30(%r15),%rax
 1014dc2:	test   %rax,%rax
 1014dc5:	je     1014e08 <index_commit+0x2c8>
 1014dc7:	mov    -0x30(%rbp),%r14
 1014dcb:	mov    0x98(%r14),%rsi
 1014dd2:	test   %rsi,%rsi
 1014dd5:	je     1014dee <index_commit+0x2ae>
 1014dd7:	mov    0xa0(%r14),%rdx
 1014dde:	shl    $0x4,%rdx
 1014de2:	mov    %r13,%rdi
 1014de5:	call   1012500 <myl_rc_meta_free>
 1014dea:	mov    0x30(%r15),%rax
 1014dee:	mov    %rax,0x98(%r14)
 1014df5:	mov    0x38(%r15),%rax
 1014df9:	mov    %rax,0xa0(%r14)
 1014e00:	movq   $0x0,0x30(%r15)
 1014e08:	mov    0x8(%rbx),%rax
 1014e0c:	test   %rax,%rax
 1014e0f:	je     1014ea1 <index_commit+0x361>
 1014e15:	mov    0x1608(%r13),%rcx
 1014e1c:	mov    0x38(%rcx),%rdx
 1014e20:	cmp    $0x10030a0,%rdx
 1014e27:	je     10151bc <index_commit+0x67c>
 1014e2d:	mov    0x40(%rcx),%rdi
 1014e31:	cmp    $0xffffffffffffffff,%rdi
 1014e35:	je     10151bc <index_commit+0x67c>
 1014e3b:	mov    0x48(%rcx),%rsi
 1014e3f:	lea    0x1(%rdi),%r8
 1014e43:	shr    $1,%r8
 1014e46:	cmp    %r8,%rsi
 1014e49:	ja     10151bc <index_commit+0x67c>
 1014e4f:	movzbl 0x50(%rcx),%r8d
 1014e54:	mov    %rax,%r9
 1014e57:	movabs $0x9e3779b97f4a7c15,%r10
 1014e61:	imul   %r10,%r9
 1014e65:	shrx   %r8,%r9,%r9
 1014e6a:	nopw   0x0(%rax,%rax,1)
 1014e70:	and    %rdi,%r9
 1014e73:	mov    %r9,%r8
 1014e76:	shl    $0x4,%r8
 1014e7a:	mov    (%rdx,%r8,1),%r10
 1014e7e:	test   %r10,%r10
 1014e81:	je     1014e8b <index_commit+0x34b>
 1014e83:	inc    %r9
 1014e86:	cmp    %rax,%r10
 1014e89:	jne    1014e70 <index_commit+0x330>
 1014e8b:	test   %r10,%r10
 1014e8e:	jne    1014ea1 <index_commit+0x361>
 1014e90:	add    %r8,%rdx
 1014e93:	mov    %rax,(%rdx)
 1014e96:	mov    %rbx,0x8(%rdx)
 1014e9a:	inc    %rsi
 1014e9d:	mov    %rsi,0x48(%rcx)
 1014ea1:	mov    0x20(%rbx),%rax
 1014ea5:	test   %rax,%rax
 1014ea8:	je     101500a <index_commit+0x4ca>
 1014eae:	xor    %ecx,%ecx
 1014eb0:	lea    -0x11e17(%rip),%rdx        # 10030a0 <myl_rc_map_sentinel>
 1014eb7:	jmp    1014ecc <index_commit+0x38c>
 1014eb9:	nopl   0x0(%rax)
 1014ec0:	inc    %rcx
 1014ec3:	cmp    %rax,%rcx
 1014ec6:	je     101500a <index_commit+0x4ca>
 1014ecc:	mov    0x38(%rbx),%rsi
 1014ed0:	test   %rsi,%rsi
 1014ed3:	je     1014ee0 <index_commit+0x3a0>
 1014ed5:	mov    0x8(%rsi),%rsi
 1014ed9:	mov    (%rsi,%rcx,8),%rdi
 1014edd:	jmp    1014eeb <index_commit+0x3ab>
 1014edf:	nop
 1014ee0:	mov    %rcx,%rdi
 1014ee3:	shl    $0x6,%rdi
 1014ee7:	add    0x10(%rbx),%rdi
 1014eeb:	mov    0x1608(%r13),%r8
 1014ef2:	mov    0x58(%r8),%r9
 1014ef6:	cmp    %rdx,%r9
 1014ef9:	je     10151bc <index_commit+0x67c>
 1014eff:	mov    0x60(%r8),%r11
 1014f03:	cmp    $0xffffffffffffffff,%r11
 1014f07:	je     10151bc <index_commit+0x67c>
 1014f0d:	mov    0x68(%r8),%r10
 1014f11:	lea    0x1(%r11),%rsi
 1014f15:	shr    $1,%rsi
 1014f18:	cmp    %rsi,%r10
 1014f1b:	ja     10151bc <index_commit+0x67c>
 1014f21:	lea    0x8(%rdi),%rsi
 1014f25:	movzbl 0x70(%r8),%r14d
 1014f2a:	mov    %rsi,%r15
 1014f2d:	movabs $0x9e3779b97f4a7c15,%r12
 1014f37:	imul   %r12,%r15
 1014f3b:	shrx   %r14,%r15,%r15
 1014f40:	and    %r11,%r15
 1014f43:	mov    %r15,%r14
 1014f46:	shl    $0x4,%r14
 1014f4a:	mov    (%r9,%r14,1),%r12
 1014f4e:	test   %r12,%r12
 1014f51:	je     1014f5b <index_commit+0x41b>
 1014f53:	inc    %r15
 1014f56:	cmp    %rsi,%r12
 1014f59:	jne    1014f40 <index_commit+0x400>
 1014f5b:	test   %r12,%r12
 1014f5e:	jne    1014f71 <index_commit+0x431>
 1014f60:	add    %r14,%r9
 1014f63:	mov    %rsi,(%r9)
 1014f66:	mov    %rsi,0x8(%r9)
 1014f6a:	inc    %r10
 1014f6d:	mov    %r10,0x68(%r8)
 1014f71:	mov    (%rdi),%rdi
 1014f74:	test   %rdi,%rdi
 1014f77:	je     1014ec0 <index_commit+0x380>
 1014f7d:	mov    0x1608(%r13),%r8
 1014f84:	mov    0x58(%r8),%r9
 1014f88:	cmp    %rdx,%r9
 1014f8b:	je     10151bc <index_commit+0x67c>
 1014f91:	mov    0x60(%r8),%r11
 1014f95:	cmp    $0xffffffffffffffff,%r11
 1014f99:	je     10151bc <index_commit+0x67c>
 1014f9f:	mov    0x68(%r8),%r10
 1014fa3:	lea    0x1(%r11),%r14
 1014fa7:	shr    $1,%r14
 1014faa:	cmp    %r14,%r10
 1014fad:	ja     10151bc <index_commit+0x67c>
 1014fb3:	movzbl 0x70(%r8),%r14d
 1014fb8:	mov    %rdi,%r15
 1014fbb:	movabs $0x9e3779b97f4a7c15,%r12
 1014fc5:	imul   %r12,%r15
 1014fc9:	shrx   %r14,%r15,%r15
 1014fce:	xchg   %ax,%ax
 1014fd0:	and    %r11,%r15
 1014fd3:	mov    %r15,%r14
 1014fd6:	shl    $0x4,%r14
 1014fda:	mov    (%r9,%r14,1),%r12
 1014fde:	test   %r12,%r12
 1014fe1:	je     1014feb <index_commit+0x4ab>
 1014fe3:	inc    %r15
 1014fe6:	cmp    %rdi,%r12
 1014fe9:	jne    1014fd0 <index_commit+0x490>
 1014feb:	test   %r12,%r12
 1014fee:	jne    1014ec0 <index_commit+0x380>
 1014ff4:	add    %r14,%r9
 1014ff7:	mov    %rdi,(%r9)
 1014ffa:	mov    %rsi,0x8(%r9)
 1014ffe:	inc    %r10
 1015001:	mov    %r10,0x68(%r8)
 1015005:	jmp    1014ec0 <index_commit+0x380>
 101500a:	mov    %r13,-0x48(%rbp)
 101500e:	mov    0x28(%rbx),%rax
 1015012:	test   %rax,%rax
 1015015:	je     10151ad <index_commit+0x66d>
 101501b:	mov    -0x30(%rbp),%rcx
 101501f:	add    0xa8(%rcx),%rax
 1015026:	lea    0x10(,%rax,4),%rax
 101502e:	mov    %rax,-0x38(%rbp)
 1015032:	xor    %r11d,%r11d
 1015035:	lea    -0x11f9c(%rip),%r10        # 10030a0 <myl_rc_map_sentinel>
 101503c:	xor    %r12d,%r12d
 101503f:	jmp    101507d <index_commit+0x53d>
 1015041:	shl    $0x4,%rcx
 1015045:	mov    0x38(%rbx),%rsi
 1015049:	test   %rsi,%rsi
 101504c:	cmove  %rsi,%r14
 1015050:	mov    %r14,(%rdx,%rcx,1)
 1015054:	mov    %rdi,0x8(%rdx,%rcx,1)
 1015059:	mov    -0x30(%rbp),%rcx
 101505d:	incq   0xa8(%rcx)
 1015064:	mov    %eax,%r11d
 1015067:	nopw   0x0(%rax,%rax,1)
 1015070:	inc    %r12
 1015073:	cmp    0x28(%rbx),%r12
 1015077:	jae    10151ad <index_commit+0x66d>
 101507d:	mov    0x18(%rbx),%rax
 1015081:	imul   $0xc8,%r12,%rcx
 1015088:	lea    (%rax,%rcx,1),%rdi
 101508c:	mov    (%rax,%rcx,1),%r14
 1015090:	mov    0x34(%r14),%eax
 1015094:	test   %eax,%eax
 1015096:	setne  %cl
 1015099:	cmp    %r11d,%eax
 101509c:	seta   %dl
 101509f:	and    %cl,%dl
 10150a1:	cmp    $0x1,%dl
 10150a4:	jne    10150f0 <index_commit+0x5b0>
 10150a6:	mov    %eax,%ecx
 10150a8:	cmp    %rcx,-0x38(%rbp)
 10150ac:	jbe    10150f0 <index_commit+0x5b0>
 10150ae:	mov    -0x30(%rbp),%rsi
 10150b2:	mov    0x98(%rsi),%rdx
 10150b9:	cmp    %rcx,0xa0(%rsi)
 10150c0:	jbe    1015041 <index_commit+0x501>
 10150c6:	mov    %rcx,%rsi
 10150c9:	shl    $0x4,%rsi
 10150cd:	cmpq   $0x0,(%rdx,%rsi,1)
 10150d2:	jne    10150f0 <index_commit+0x5b0>
 10150d4:	add    %rdx,%rsi
 10150d7:	cmpq   $0x0,0x8(%rsi)
 10150dc:	je     1015041 <index_commit+0x501>
 10150e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10150f0:	cmpq   $0x0,0x38(%rbx)
 10150f5:	jne    1015116 <index_commit+0x5d6>
 10150f7:	mov    %rbx,%r13
 10150fa:	mov    %r10,%rbx
 10150fd:	mov    %rdi,-0x40(%rbp)
 1015101:	mov    %r11,%r15
 1015104:	call   1012fd0 <flat_build>
 1015109:	mov    %r15,%r11
 101510c:	mov    -0x40(%rbp),%rdi
 1015110:	mov    %rbx,%r10
 1015113:	mov    %r13,%rbx
 1015116:	mov    -0x48(%rbp),%rax
 101511a:	mov    0x1608(%rax),%rax
 1015121:	mov    0x78(%rax),%rcx
 1015125:	cmp    %r10,%rcx
 1015128:	je     10151bc <index_commit+0x67c>
 101512e:	mov    0x80(%rax),%rsi
 1015135:	cmp    $0xffffffffffffffff,%rsi
 1015139:	je     10151bc <index_commit+0x67c>
 101513f:	mov    0x88(%rax),%rdx
 1015146:	lea    0x1(%rsi),%r8
 101514a:	shr    $1,%r8
 101514d:	cmp    %r8,%rdx
 1015150:	ja     10151bc <index_commit+0x67c>
 1015152:	movzbl 0x90(%rax),%r15d
 101515a:	mov    %r14,%r8
 101515d:	movabs $0x9e3779b97f4a7c15,%r9
 1015167:	imul   %r9,%r8
 101516b:	shrx   %r15,%r8,%r15
 1015170:	and    %rsi,%r15
 1015173:	mov    %r15,%r8
 1015176:	shl    $0x4,%r8
 101517a:	mov    (%rcx,%r8,1),%r9
 101517e:	test   %r9,%r9
 1015181:	je     101518b <index_commit+0x64b>
 1015183:	inc    %r15
 1015186:	cmp    %r14,%r9
 1015189:	jne    1015170 <index_commit+0x630>
 101518b:	test   %r9,%r9
 101518e:	jne    1015070 <index_commit+0x530>
 1015194:	add    %r8,%rcx
 1015197:	mov    %r14,(%rcx)
 101519a:	mov    %rdi,0x8(%rcx)
 101519e:	inc    %rdx
 10151a1:	mov    %rdx,0x88(%rax)
 10151a8:	jmp    1015070 <index_commit+0x530>
 10151ad:	add    $0x28,%rsp
 10151b1:	pop    %rbx
 10151b2:	pop    %r12
 10151b4:	pop    %r13
 10151b6:	pop    %r14
 10151b8:	pop    %r15
 10151ba:	pop    %rbp
 10151bb:	ret
 10151bc:	call   101246d <myl_rc_invariant_failed>
 10151c1:	int3
 10151c2:	int3
 10151c3:	int3
 10151c4:	int3
 10151c5:	int3
 10151c6:	int3
 10151c7:	int3
 10151c8:	int3
 10151c9:	int3
 10151ca:	int3
 10151cb:	int3
 10151cc:	int3
 10151cd:	int3
 10151ce:	int3
 10151cf:	int3

00000000010151d0 <myl_rc_descriptor_import>:
 10151d0:	push   %rbp
 10151d1:	mov    %rsp,%rbp
 10151d4:	push   %r15
 10151d6:	push   %r14
 10151d8:	push   %rbx
 10151d9:	sub    $0x58,%rsp
 10151dd:	test   %rdi,%rdi
 10151e0:	je     1015291 <myl_rc_descriptor_import+0xc1>
 10151e6:	test   %rsi,%rsi
 10151e9:	je     1015291 <myl_rc_descriptor_import+0xc1>
 10151ef:	mov    0x1608(%rdi),%rcx
 10151f6:	test   %rcx,%rcx
 10151f9:	je     1015291 <myl_rc_descriptor_import+0xc1>
 10151ff:	mov    (%rsi),%rax
 1015202:	test   %rax,%rax
 1015205:	je     1015291 <myl_rc_descriptor_import+0xc1>
 101520b:	mov    0x8(%rsi),%rdx
 101520f:	test   %rdx,%rdx
 1015212:	je     1015291 <myl_rc_descriptor_import+0xc1>
 1015214:	cmpq   $0x0,0xc0(%rcx)
 101521c:	jne    1015291 <myl_rc_descriptor_import+0xc1>
 101521e:	mov    (%rdx),%rdx
 1015221:	cmp    (%rax),%rdx
 1015224:	jne    1015291 <myl_rc_descriptor_import+0xc1>
 1015226:	mov    0x34(%rax),%edx
 1015229:	cmp    %rdx,0xa0(%rcx)
 1015230:	jbe    1015296 <myl_rc_descriptor_import+0xc6>
 1015232:	mov    0x98(%rcx),%rcx
 1015239:	shl    $0x4,%rdx
 101523d:	cmp    %rax,(%rcx,%rdx,1)
 1015241:	jne    1015296 <myl_rc_descriptor_import+0xc6>
 1015243:	add    %rdx,%rcx
 1015246:	mov    0x8(%rcx),%rax
 101524a:	test   %rax,%rax
 101524d:	je     10152a9 <myl_rc_descriptor_import+0xd9>
 101524f:	mov    0x10(%rax),%rcx
 1015253:	cmp    0x10(%rsi),%rcx
 1015257:	jne    1015291 <myl_rc_descriptor_import+0xc1>
 1015259:	mov    0x18(%rax),%rcx
 101525d:	cmp    0x18(%rsi),%rcx
 1015261:	jne    1015291 <myl_rc_descriptor_import+0xc1>
 1015263:	mov    0x20(%rax),%rcx
 1015267:	cmp    0x20(%rsi),%rcx
 101526b:	jne    1015291 <myl_rc_descriptor_import+0xc1>
 101526d:	mov    0x28(%rax),%rcx
 1015271:	cmp    0x28(%rsi),%rcx
 1015275:	jne    1015291 <myl_rc_descriptor_import+0xc1>
 1015277:	mov    0x30(%rax),%rcx
 101527b:	cmp    0x30(%rsi),%rcx
 101527f:	jne    1015291 <myl_rc_descriptor_import+0xc1>
 1015281:	mov    0x38(%rax),%rcx
 1015285:	xor    %eax,%eax
 1015287:	cmp    0x38(%rsi),%rcx
 101528b:	je     1015347 <myl_rc_descriptor_import+0x177>
 1015291:	call   101246d <myl_rc_invariant_failed>
 1015296:	mov    %rsi,%rcx
 1015299:	mov    %rax,%rsi
 101529c:	call   1012eea <myl_rc_binding_find_slow>
 10152a1:	mov    %rcx,%rsi
 10152a4:	test   %rax,%rax
 10152a7:	jne    101524f <myl_rc_descriptor_import+0x7f>
 10152a9:	mov    0x8(%rsi),%rax
 10152ad:	movl   $0x5,-0x70(%rbp)
 10152b4:	vxorps %xmm0,%xmm0,%xmm0
 10152b8:	vmovups %xmm0,-0x6c(%rbp)
 10152bd:	movl   $0x0,-0x5c(%rbp)
 10152c4:	mov    %rsi,-0x58(%rbp)
 10152c8:	movq   $0x1,-0x50(%rbp)
 10152d0:	vxorps %xmm0,%xmm0,%xmm0
 10152d4:	vmovups %ymm0,-0x40(%rbp)
 10152d9:	movq   $0x0,-0x20(%rbp)
 10152e1:	mov    %rdi,-0x48(%rbp)
 10152e5:	lea    -0x48(%rbp),%rdi
 10152e9:	mov    %rax,%rsi
 10152ec:	vzeroupper
 10152ef:	call   1013600 <builder_add>
 10152f4:	test   %eax,%eax
 10152f6:	je     101530d <myl_rc_descriptor_import+0x13d>
 10152f8:	lea    -0x48(%rbp),%rdi
 10152fc:	lea    -0x70(%rbp),%rsi
 1015300:	xor    %edx,%edx
 1015302:	xor    %ecx,%ecx
 1015304:	call   10138b0 <register_shapes>
 1015309:	mov    %eax,%ebx
 101530b:	jmp    1015312 <myl_rc_descriptor_import+0x142>
 101530d:	mov    $0x1,%ebx
 1015312:	mov    -0x48(%rbp),%r14
 1015316:	mov    -0x40(%rbp),%rsi
 101531a:	mov    -0x28(%rbp),%r15
 101531e:	lea    0x0(,%r15,8),%rax
 1015326:	lea    (%rax,%rax,4),%rdx
 101532a:	mov    %r14,%rdi
 101532d:	call   1012500 <myl_rc_meta_free>
 1015332:	mov    -0x38(%rbp),%rsi
 1015336:	shl    $0x4,%r15
 101533a:	mov    %r14,%rdi
 101533d:	mov    %r15,%rdx
 1015340:	call   1012500 <myl_rc_meta_free>
 1015345:	mov    %ebx,%eax
 1015347:	add    $0x58,%rsp
 101534b:	pop    %rbx
 101534c:	pop    %r14
 101534e:	pop    %r15
 1015350:	pop    %rbp
 1015351:	ret
 1015352:	int3
 1015353:	int3
 1015354:	int3
 1015355:	int3
 1015356:	int3
 1015357:	int3
 1015358:	int3
 1015359:	int3
 101535a:	int3
 101535b:	int3
 101535c:	int3
 101535d:	int3
 101535e:	int3
 101535f:	int3

0000000001015360 <flat_disjoint>:
 1015360:	mov    $0x1,%eax
 1015365:	test   %esi,%esi
 1015367:	je     101544a <flat_disjoint+0xea>
 101536d:	push   %rbp
 101536e:	mov    %rsp,%rbp
 1015371:	push   %r15
 1015373:	push   %r14
 1015375:	push   %r13
 1015377:	push   %r12
 1015379:	push   %rbx
 101537a:	mov    %esi,%ecx
 101537c:	lea    0x8(%rdi),%rdx
 1015380:	xor    %esi,%esi
 1015382:	mov    $0xffffffff,%r8d
 1015388:	lea    (%rsi,%rsi,2),%r9
 101538c:	lea    (%rdi,%r9,4),%r9
 1015390:	mov    %rdx,%r10
 1015393:	xor    %r11d,%r11d
 1015396:	jmp    10153b0 <flat_disjoint+0x50>
 1015398:	nopl   0x0(%rax,%rax,1)
 10153a0:	inc    %r11
 10153a3:	add    $0xc,%r10
 10153a7:	cmp    %r11,%rcx
 10153aa:	je     1015430 <flat_disjoint+0xd0>
 10153b0:	cmp    %r11,%rsi
 10153b3:	jae    10153ec <flat_disjoint+0x8c>
 10153b5:	mov    0x4(%r9),%ebx
 10153b9:	cmp    $0xffffffff,%ebx
 10153bc:	je     10153d0 <flat_disjoint+0x70>
 10153be:	cmp    -0x4(%r10),%ebx
 10153c2:	jne    10153d0 <flat_disjoint+0x70>
 10153c4:	mov    0x8(%r9),%ebx
 10153c8:	cmp    (%r10),%ebx
 10153cb:	jne    10153ec <flat_disjoint+0x8c>
 10153cd:	nopl   (%rax)
 10153d0:	mov    (%r9),%ebx
 10153d3:	mov    -0x8(%r10),%r14d
 10153d7:	mov    %ebx,%r15d
 10153da:	sub    %r14d,%r15d
 10153dd:	neg    %r15d
 10153e0:	sub    %r14d,%ebx
 10153e3:	cmovb  %r15,%rbx
 10153e7:	cmp    $0x8,%ebx
 10153ea:	jb     101543e <flat_disjoint+0xde>
 10153ec:	mov    -0x4(%r10),%ebx
 10153f0:	cmp    %r8,%rbx
 10153f3:	je     10153a0 <flat_disjoint+0x40>
 10153f5:	mov    (%r9),%r14d
 10153f8:	mov    %r14d,%r15d
 10153fb:	sub    %ebx,%r15d
 10153fe:	mov    %r15d,%r12d
 1015401:	neg    %r12d
 1015404:	xor    %r13d,%r13d
 1015407:	cmp    $0x8,%r12d
 101540b:	setae  %r13b
 101540f:	xor    %r12d,%r12d
 1015412:	cmp    $0x4,%r15d
 1015416:	setae  %r12b
 101541a:	cmp    %ebx,%r14d
 101541d:	cmovae %r12d,%r13d
 1015421:	cmp    $0x1,%r13b
 1015425:	je     10153a0 <flat_disjoint+0x40>
 101542b:	jmp    101543e <flat_disjoint+0xde>
 101542d:	nopl   (%rax)
 1015430:	inc    %rsi
 1015433:	cmp    %rcx,%rsi
 1015436:	jne    1015388 <flat_disjoint+0x28>
 101543c:	jmp    1015440 <flat_disjoint+0xe0>
 101543e:	xor    %eax,%eax
 1015440:	pop    %rbx
 1015441:	pop    %r12
 1015443:	pop    %r13
 1015445:	pop    %r14
 1015447:	pop    %r15
 1015449:	pop    %rbp
 101544a:	ret
 101544b:	int3
 101544c:	int3
 101544d:	int3
 101544e:	int3
 101544f:	int3

0000000001015450 <flat_masks>:
 1015450:	push   %rbp
 1015451:	mov    %rsp,%rbp
 1015454:	push   %r14
 1015456:	push   %rbx
 1015457:	mov    $0xffffffff,%ecx
 101545c:	test   %edx,%edx
 101545e:	je     10154bc <flat_masks+0x6c>
 1015460:	mov    %edx,%r9d
 1015463:	lea    0x8(%rsi),%r11
 1015467:	mov    $0xffffffff,%r14d
 101546d:	xor    %ebx,%ebx
 101546f:	xor    %r8d,%r8d
 1015472:	jmp    1015496 <flat_masks+0x46>
 1015474:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015480:	bts    %ebx,%r8d
 1015484:	mov    %r14d,%r10d
 1015487:	inc    %rbx
 101548a:	add    $0xc,%r11
 101548e:	mov    %r10d,%r14d
 1015491:	cmp    %rbx,%r9
 1015494:	je     10154c7 <flat_masks+0x77>
 1015496:	mov    -0x4(%r11),%r10d
 101549a:	cmp    $0xffffffff,%r10d
 101549e:	je     1015480 <flat_masks+0x30>
 10154a0:	xor    %eax,%eax
 10154a2:	cmp    $0xffffffff,%r14d
 10154a6:	je     10154b1 <flat_masks+0x61>
 10154a8:	cmp    %r10d,%r14d
 10154ab:	jne    10155be <flat_masks+0x16e>
 10154b1:	cmpl   $0x1f,(%r11)
 10154b5:	jbe    1015487 <flat_masks+0x37>
 10154b7:	jmp    10155be <flat_masks+0x16e>
 10154bc:	xor    %r8d,%r8d
 10154bf:	mov    $0xffffffff,%r10d
 10154c5:	jmp    10154f2 <flat_masks+0xa2>
 10154c7:	xor    %eax,%eax
 10154c9:	mov    %rsi,%r11
 10154cc:	xor    %ebx,%ebx
 10154ce:	xchg   %ax,%ax
 10154d0:	mov    (%r11),%r14d
 10154d3:	cmp    $0xfff7,%r14d
 10154da:	ja     10155be <flat_masks+0x16e>
 10154e0:	mov    %r14w,0x5c(%rdi,%rbx,2)
 10154e6:	inc    %rbx
 10154e9:	add    $0xc,%r11
 10154ed:	cmp    %rbx,%r9
 10154f0:	jne    10154d0 <flat_masks+0x80>
 10154f2:	shlx   %edx,%ecx,%eax
 10154f7:	not    %eax
 10154f9:	mov    %ax,0x18(%rdi)
 10154fd:	mov    %r10d,0x8(%rdi)
 1015501:	vmovd  %r8d,%xmm0
 1015506:	vpbroadcastw %xmm0,%ymm0
 101550b:	vmovdqu %ymm0,0x1a(%rdi)
 1015510:	vmovdqu %ymm0,0x3a(%rdi)
 1015515:	mov    %r8w,0x5a(%rdi)
 101551a:	mov    $0x1,%eax
 101551f:	test   %edx,%edx
 1015521:	je     10155be <flat_masks+0x16e>
 1015527:	cmp    $0x1,%edx
 101552a:	jne    1015530 <flat_masks+0xe0>
 101552c:	xor    %ecx,%ecx
 101552e:	jmp    1015598 <flat_masks+0x148>
 1015530:	mov    %edx,%edx
 1015532:	mov    %edx,%eax
 1015534:	and    $0xfffffffe,%eax
 1015537:	lea    0x14(%rsi),%r8
 101553b:	xor    %ecx,%ecx
 101553d:	mov    $0x1,%r9d
 1015543:	jmp    101555d <flat_masks+0x10d>
 1015545:	data16 cs nopw 0x0(%rax,%rax,1)
 1015550:	add    $0x2,%rcx
 1015554:	add    $0x18,%r8
 1015558:	cmp    %rcx,%rax
 101555b:	je     101558e <flat_masks+0x13e>
 101555d:	cmpl   $0xffffffff,-0x10(%r8)
 1015562:	je     1015573 <flat_masks+0x123>
 1015564:	shlx   %ecx,%r9d,%r10d
 1015569:	mov    -0xc(%r8),%r11d
 101556d:	or     %r10w,0x1c(%rdi,%r11,2)
 1015573:	cmpl   $0xffffffff,-0x4(%r8)
 1015578:	je     1015550 <flat_masks+0x100>
 101557a:	lea    0x1(%rcx),%r10d
 101557e:	shlx   %r10d,%r9d,%r10d
 1015583:	mov    (%r8),%r11d
 1015586:	or     %r10w,0x1c(%rdi,%r11,2)
 101558c:	jmp    1015550 <flat_masks+0x100>
 101558e:	mov    $0x1,%eax
 1015593:	test   $0x1,%dl
 1015596:	je     10155be <flat_masks+0x16e>
 1015598:	lea    (%rcx,%rcx,2),%rdx
 101559c:	cmpl   $0xffffffff,0x4(%rsi,%rdx,4)
 10155a1:	mov    $0x1,%eax
 10155a6:	je     10155be <flat_masks+0x16e>
 10155a8:	lea    (%rsi,%rdx,4),%rdx
 10155ac:	mov    $0x1,%eax
 10155b1:	shlx   %ecx,%eax,%ecx
 10155b6:	mov    0x8(%rdx),%edx
 10155b9:	or     %cx,0x1c(%rdi,%rdx,2)
 10155be:	pop    %rbx
 10155bf:	pop    %r14
 10155c1:	pop    %rbp
 10155c2:	vzeroupper
 10155c5:	ret
 10155c6:	int3
 10155c7:	int3
 10155c8:	int3
 10155c9:	int3
 10155ca:	int3
 10155cb:	int3
 10155cc:	int3
 10155cd:	int3
 10155ce:	int3
 10155cf:	int3

00000000010155d0 <map_prepare>:
 10155d0:	push   %rbp
 10155d1:	mov    %rsp,%rbp
 10155d4:	push   %r15
 10155d6:	push   %r14
 10155d8:	push   %r12
 10155da:	push   %rbx
 10155db:	vxorps %xmm0,%xmm0,%xmm0
 10155df:	vmovups %xmm0,(%rcx)
 10155e3:	mov    (%rsi),%rax
 10155e6:	xor    %ebx,%ebx
 10155e8:	cmp    $0x10030a0,%rax
 10155ef:	je     1015603 <map_prepare+0x33>
 10155f1:	mov    0x8(%rsi),%rax
 10155f5:	inc    %rax
 10155f8:	add    0x10(%rsi),%rdx
 10155fc:	jae    101560f <map_prepare+0x3f>
 10155fe:	jmp    1015769 <map_prepare+0x199>
 1015603:	xor    %eax,%eax
 1015605:	add    0x10(%rsi),%rdx
 1015609:	jb     1015769 <map_prepare+0x199>
 101560f:	mov    %rax,%r8
 1015612:	shr    $1,%r8
 1015615:	cmp    %r8,%rdx
 1015618:	jbe    1015764 <map_prepare+0x194>
 101561e:	test   %rax,%rax
 1015621:	mov    $0x20,%r14d
 1015627:	cmovne %rax,%r14
 101562b:	mov    %r14,%rax
 101562e:	shr    $1,%rax
 1015631:	cmp    %rax,%rdx
 1015634:	jbe    101565a <map_prepare+0x8a>
 1015636:	mov    %r14,%rax
 1015639:	nopl   0x0(%rax)
 1015640:	cmp    $0x7fffffff,%rax
 1015646:	ja     1015769 <map_prepare+0x199>
 101564c:	lea    (%rax,%rax,1),%r14
 1015650:	cmp    %rax,%rdx
 1015653:	mov    %r14,%rax
 1015656:	ja     1015640 <map_prepare+0x70>
 1015658:	jmp    1015667 <map_prepare+0x97>
 101565a:	mov    %r14,%rax
 101565d:	shr    $0x3c,%rax
 1015661:	jne    1015769 <map_prepare+0x199>
 1015667:	mov    %rsi,%r15
 101566a:	mov    %rcx,%r12
 101566d:	mov    %r14,%rsi
 1015670:	shl    $0x4,%rsi
 1015674:	call   1012480 <myl_rc_meta_alloc>
 1015679:	test   %rax,%rax
 101567c:	je     1015769 <map_prepare+0x199>
 1015682:	mov    $0x3f,%esi
 1015687:	cmp    $0x2,%r14
 101568b:	mov    %r12,%rcx
 101568e:	mov    %r15,%rdx
 1015691:	jb     10156b9 <map_prepare+0xe9>
 1015693:	mov    $0x40,%edi
 1015698:	mov    %r14,%r8
 101569b:	mov    %r14,%rsi
 101569e:	xchg   %ax,%ax
 10156a0:	shr    $1,%rsi
 10156a3:	dec    %edi
 10156a5:	cmp    $0x3,%r8
 10156a9:	mov    %rsi,%r8
 10156ac:	ja     10156a0 <map_prepare+0xd0>
 10156ae:	cmp    $0x3f,%edi
 10156b1:	mov    $0x3f,%esi
 10156b6:	cmovb  %edi,%esi
 10156b9:	mov    (%rdx),%rdi
 10156bc:	dec    %r14
 10156bf:	cmp    $0x10030a0,%rdi
 10156c6:	je     101575d <map_prepare+0x18d>
 10156cc:	xor    %r8d,%r8d
 10156cf:	lea    -0x12636(%rip),%r9        # 10030a0 <myl_rc_map_sentinel>
 10156d6:	movabs $0x9e3779b97f4a7c15,%r10
 10156e0:	jmp    1015707 <map_prepare+0x137>
 10156e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10156f0:	add    %rax,%r15
 10156f3:	vmovups (%rdi),%xmm0
 10156f7:	vmovups %xmm0,(%r15)
 10156fc:	mov    (%rdx),%rdi
 10156ff:	inc    %r8
 1015702:	cmp    %r9,%rdi
 1015705:	je     101575d <map_prepare+0x18d>
 1015707:	mov    0x8(%rdx),%r11
 101570b:	inc    %r11
 101570e:	cmp    %r11,%r8
 1015711:	jae    101575d <map_prepare+0x18d>
 1015713:	mov    %r8,%rbx
 1015716:	shl    $0x4,%rbx
 101571a:	mov    (%rdi,%rbx,1),%r11
 101571e:	test   %r11,%r11
 1015721:	je     10156ff <map_prepare+0x12f>
 1015723:	add    %rbx,%rdi
 1015726:	mov    %r11,%rbx
 1015729:	imul   %r10,%rbx
 101572d:	shrx   %rsi,%rbx,%rbx
 1015732:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015740:	and    %r14,%rbx
 1015743:	mov    %rbx,%r15
 1015746:	shl    $0x4,%r15
 101574a:	mov    (%rax,%r15,1),%r12
 101574e:	test   %r12,%r12
 1015751:	je     10156f0 <map_prepare+0x120>
 1015753:	inc    %rbx
 1015756:	cmp    %r11,%r12
 1015759:	jne    1015740 <map_prepare+0x170>
 101575b:	jmp    10156f0 <map_prepare+0x120>
 101575d:	mov    %rax,(%rcx)
 1015760:	mov    %r14,0x8(%rcx)
 1015764:	mov    $0x1,%ebx
 1015769:	mov    %ebx,%eax
 101576b:	pop    %rbx
 101576c:	pop    %r12
 101576e:	pop    %r14
 1015770:	pop    %r15
 1015772:	pop    %rbp
 1015773:	ret
 1015774:	int3
 1015775:	int3
 1015776:	int3
 1015777:	int3
 1015778:	int3
 1015779:	int3
 101577a:	int3
 101577b:	int3
 101577c:	int3
 101577d:	int3
 101577e:	int3
 101577f:	int3

0000000001015780 <walk>:
 1015780:	push   %rbp
 1015781:	mov    %rsp,%rbp
 1015784:	push   %r15
 1015786:	push   %r14
 1015788:	push   %r13
 101578a:	push   %r12
 101578c:	push   %rbx
 101578d:	push   %rax
 101578e:	mov    0x1608(%rdi),%rcx
 1015795:	mov    0xc0(%rcx),%rax
 101579c:	test   %rax,%rax
 101579f:	je     101597b <walk+0x1fb>
 10157a5:	mov    %esi,%ebx
 10157a7:	mov    %rdi,%r14
 10157aa:	lea    0xc0(%rcx),%rdx
 10157b1:	xor    %r15d,%r15d
 10157b4:	lea    -0x1270b(%rip),%r13        # 10030b0 <myl_rc_map_sentinel+0x10>
 10157bb:	mov    %esi,%r12d
 10157be:	or     $0x2,%r12d
 10157c2:	jmp    10157f4 <walk+0x74>
 10157c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10157d0:	dec    %rax
 10157d3:	mov    %rax,(%rdx)
 10157d6:	mov    0x1608(%r14),%rcx
 10157dd:	lea    0xc0(%rcx),%rdx
 10157e4:	mov    0xc0(%rcx),%rax
 10157eb:	test   %rax,%rax
 10157ee:	je     101597e <walk+0x1fe>
 10157f4:	mov    0xb0(%rcx),%rsi
 10157fb:	lea    (%rax,%rax,2),%r8
 10157ff:	mov    -0x18(%rsi,%r8,8),%rdi
 1015804:	mov    0x8(%rdi),%r9d
 1015808:	lea    -0x1(%r9),%r10d
 101580c:	cmp    $0x4,%r10d
 1015810:	ja     1015990 <walk+0x210>
 1015816:	lea    (%rsi,%r8,8),%rsi
 101581a:	movslq 0x0(%r13,%r10,4),%r8
 101581f:	add    %r13,%r8
 1015822:	jmp    *%r8
 1015825:	mov    -0x10(%rsi),%rdx
 1015829:	mov    (%rdx),%rsi
 101582c:	cmp    $0x2,%ebx
 101582f:	jne    101592f <walk+0x1af>
 1015835:	test   %rsi,%rsi
 1015838:	je     101585e <walk+0xde>
 101583a:	mov    -0x10(%rsi),%rdx
 101583e:	mov    %rdx,%rsi
 1015841:	shr    $0x28,%rsi
 1015845:	and    $0xfffff,%esi
 101584b:	cmp    %r15d,%esi
 101584e:	cmovbe %r15d,%esi
 1015852:	bt     $0x3e,%rdx
 1015857:	cmovae %r15d,%esi
 101585b:	mov    %esi,%r15d
 101585e:	dec    %rax
 1015861:	mov    %rax,0xc0(%rcx)
 1015868:	jmp    10157d6 <walk+0x56>
 101586d:	nopl   (%rax)
 1015870:	mov    -0x8(%rsi),%r10
 1015874:	cmp    0x18(%rdi),%r10
 1015878:	je     10157d0 <walk+0x50>
 101587e:	lea    (%r10,%r10,2),%r8
 1015882:	shl    $0x3,%r8
 1015886:	add    0x10(%rdi),%r8
 101588a:	inc    %r10
 101588d:	mov    %r10,-0x8(%rsi)
 1015891:	mov    -0x10(%rsi),%r10
 1015895:	cmp    $0x4,%r9d
 1015899:	jne    10158ad <walk+0x12d>
 101589b:	mov    0x20(%rdi),%rdi
 101589f:	mov    0x10(%r8),%r9d
 10158a3:	cmp    (%r10,%rdi,1),%r9d
 10158a7:	jne    10157d6 <walk+0x56>
 10158ad:	mov    0x8(%r8),%rdi
 10158b1:	cmpl   $0x0,0x8(%rdi)
 10158b5:	je     10157d6 <walk+0x56>
 10158bb:	cmp    0xb8(%rcx),%rax
 10158c2:	jae    1015990 <walk+0x210>
 10158c8:	add    (%r8),%r10
 10158cb:	inc    %rax
 10158ce:	mov    %rax,(%rdx)
 10158d1:	mov    %rdi,(%rsi)
 10158d4:	mov    %r10,0x8(%rsi)
 10158d8:	jmp    1015922 <walk+0x1a2>
 10158da:	mov    -0x8(%rsi),%r8
 10158de:	cmp    0x18(%rdi),%r8
 10158e2:	je     10157d0 <walk+0x50>
 10158e8:	lea    0x1(%r8),%r9
 10158ec:	mov    %r9,-0x8(%rsi)
 10158f0:	mov    0x10(%rdi),%r9
 10158f4:	cmpl   $0x0,0x8(%r9)
 10158f9:	je     10157d6 <walk+0x56>
 10158ff:	cmp    0xb8(%rcx),%rax
 1015906:	jae    1015990 <walk+0x210>
 101590c:	imul   0x20(%rdi),%r8
 1015911:	add    -0x10(%rsi),%r8
 1015915:	inc    %rax
 1015918:	mov    %rax,(%rdx)
 101591b:	mov    %r9,(%rsi)
 101591e:	mov    %r8,0x8(%rsi)
 1015922:	movq   $0x0,0x10(%rsi)
 101592a:	jmp    10157d6 <walk+0x56>
 101592f:	movq   $0x0,(%rdx)
 1015936:	mov    0x1608(%r14),%rax
 101593d:	decq   0xc0(%rax)
 1015944:	cmp    $0x3,%r12d
 1015948:	jne    10157d6 <walk+0x56>
 101594e:	cmp    $0x3,%ebx
 1015951:	je     1015966 <walk+0x1e6>
 1015953:	cmpl   $0x5,0x8(%rdi)
 1015957:	je     1015966 <walk+0x1e6>
 1015959:	mov    %r14,%rdi
 101595c:	call   10129a0 <myl_rc_edge_release>
 1015961:	jmp    10157d6 <walk+0x56>
 1015966:	mov    %rsi,-0x30(%rbp)
 101596a:	mov    %r14,%rdi
 101596d:	lea    -0x30(%rbp),%rsi
 1015971:	call   1012d10 <myl_rc_hold_release>
 1015976:	jmp    10157d6 <walk+0x56>
 101597b:	xor    %r15d,%r15d
 101597e:	mov    %r15d,%eax
 1015981:	add    $0x8,%rsp
 1015985:	pop    %rbx
 1015986:	pop    %r12
 1015988:	pop    %r13
 101598a:	pop    %r14
 101598c:	pop    %r15
 101598e:	pop    %rbp
 101598f:	ret
 1015990:	call   101246d <myl_rc_invariant_failed>
 1015995:	int3
 1015996:	int3
 1015997:	int3
 1015998:	int3
 1015999:	int3
 101599a:	int3
 101599b:	int3
 101599c:	int3
 101599d:	int3
 101599e:	int3
 101599f:	int3

00000000010159a0 <myl_rc_edges_release>:
 10159a0:	push   %rbp
 10159a1:	mov    %rsp,%rbp
 10159a4:	push   %r15
 10159a6:	push   %r14
 10159a8:	push   %r13
 10159aa:	push   %r12
 10159ac:	push   %rbx
 10159ad:	push   %rax
 10159ae:	test   %rdi,%rdi
 10159b1:	je     1015ba4 <myl_rc_edges_release+0x204>
 10159b7:	mov    %rcx,%rbx
 10159ba:	mov    %rdi,%r15
 10159bd:	mov    0x1608(%rdi),%rcx
 10159c4:	test   %rcx,%rcx
 10159c7:	je     1015ba4 <myl_rc_edges_release+0x204>
 10159cd:	cmpq   $0x0,0xc0(%rcx)
 10159d5:	jne    1015ba4 <myl_rc_edges_release+0x204>
 10159db:	mov    %rdx,%r14
 10159de:	mov    0x58(%rcx),%rax
 10159e2:	mov    0x60(%rcx),%rdx
 10159e6:	movzbl 0x70(%rcx),%ecx
 10159ea:	movabs $0x9e3779b97f4a7c15,%rdi
 10159f4:	imul   %rsi,%rdi
 10159f8:	shrx   %rcx,%rdi,%rcx
 10159fd:	nopl   (%rax)
 1015a00:	and    %rdx,%rcx
 1015a03:	mov    %rcx,%rdi
 1015a06:	shl    $0x4,%rdi
 1015a0a:	mov    (%rax,%rdi,1),%rdi
 1015a0e:	cmp    %rsi,%rdi
 1015a11:	je     1015a21 <myl_rc_edges_release+0x81>
 1015a13:	test   %rdi,%rdi
 1015a16:	je     1015ba4 <myl_rc_edges_release+0x204>
 1015a1c:	inc    %rcx
 1015a1f:	jmp    1015a00 <myl_rc_edges_release+0x60>
 1015a21:	shl    $0x4,%rcx
 1015a25:	mov    0x8(%rax,%rcx,1),%r12
 1015a2a:	test   %r12,%r12
 1015a2d:	je     1015ba4 <myl_rc_edges_release+0x204>
 1015a33:	mov    %rbx,%rax
 1015a36:	mulq   (%r12)
 1015a3a:	jo     1015ba4 <myl_rc_edges_release+0x204>
 1015a40:	test   %r14,%r14
 1015a43:	jne    1015a4e <myl_rc_edges_release+0xae>
 1015a45:	test   %rax,%rax
 1015a48:	jne    1015ba4 <myl_rc_edges_release+0x204>
 1015a4e:	mov    0x8(%r12),%eax
 1015a53:	test   %eax,%eax
 1015a55:	je     1015b95 <myl_rc_edges_release+0x1f5>
 1015a5b:	cmp    $0x1,%eax
 1015a5e:	jne    1015a7b <myl_rc_edges_release+0xdb>
 1015a60:	test   %rbx,%rbx
 1015a63:	je     1015b95 <myl_rc_edges_release+0x1f5>
 1015a69:	xor    %r12d,%r12d
 1015a6c:	movabs $0x4000000000000002,%r13
 1015a76:	jmp    1015b38 <myl_rc_edges_release+0x198>
 1015a7b:	test   %rbx,%rbx
 1015a7e:	je     1015b95 <myl_rc_edges_release+0x1f5>
 1015a84:	mov    0x28(%r12),%r13
 1015a89:	jmp    1015aad <myl_rc_edges_release+0x10d>
 1015a8b:	nopl   0x0(%rax,%rax,1)
 1015a90:	mov    %r15,%rdi
 1015a93:	mov    %r12,%rsi
 1015a96:	mov    %r14,%rdx
 1015a99:	xor    %ecx,%ecx
 1015a9b:	call   1015bb0 <shallow_release>
 1015aa0:	add    (%r12),%r14
 1015aa4:	dec    %rbx
 1015aa7:	je     1015b95 <myl_rc_edges_release+0x1f5>
 1015aad:	cmp    $0x2,%r13
 1015ab1:	jbe    1015a90 <myl_rc_edges_release+0xf0>
 1015ab3:	cmpl   $0x0,0x8(%r12)
 1015ab9:	je     1015afe <myl_rc_edges_release+0x15e>
 1015abb:	mov    0x1608(%r15),%rax
 1015ac2:	mov    0xc0(%rax),%rcx
 1015ac9:	cmp    0xb8(%rax),%rcx
 1015ad0:	jae    1015ba4 <myl_rc_edges_release+0x204>
 1015ad6:	mov    0xb0(%rax),%rdx
 1015add:	lea    0x1(%rcx),%rsi
 1015ae1:	mov    %rsi,0xc0(%rax)
 1015ae8:	lea    (%rcx,%rcx,2),%rax
 1015aec:	mov    %r12,(%rdx,%rax,8)
 1015af0:	mov    %r14,0x8(%rdx,%rax,8)
 1015af5:	movq   $0x0,0x10(%rdx,%rax,8)
 1015afe:	mov    %r15,%rdi
 1015b01:	mov    $0x1,%esi
 1015b06:	call   1015780 <walk>
 1015b0b:	jmp    1015aa0 <myl_rc_edges_release+0x100>
 1015b0d:	mov    0xc8(%rax),%rax
 1015b14:	mov    %rax,(%rsi)
 1015b17:	mov    0x1608(%r15),%rax
 1015b1e:	mov    %rsi,0xc8(%rax)
 1015b25:	data16 cs nopw 0x0(%rax,%rax,1)
 1015b30:	inc    %r12
 1015b33:	cmp    %r12,%rbx
 1015b36:	je     1015b95 <myl_rc_edges_release+0x1f5>
 1015b38:	mov    (%r14,%r12,8),%rax
 1015b3c:	movq   $0x0,(%r14,%r12,8)
 1015b44:	test   %rax,%rax
 1015b47:	je     1015b30 <myl_rc_edges_release+0x190>
 1015b49:	mov    -0x10(%rax),%rcx
 1015b4d:	test   %r13,%rcx
 1015b50:	jne    1015b30 <myl_rc_edges_release+0x190>
 1015b52:	test   $0x1,%cl
 1015b55:	jne    1015ba4 <myl_rc_edges_release+0x204>
 1015b57:	mov    -0x20(%rax),%rdx
 1015b5b:	test   %rdx,%rdx
 1015b5e:	je     1015ba4 <myl_rc_edges_release+0x204>
 1015b60:	lea    -0x20(%rax),%rsi
 1015b64:	dec    %rdx
 1015b67:	mov    %rdx,(%rsi)
 1015b6a:	jne    1015b30 <myl_rc_edges_release+0x190>
 1015b6c:	cmpq   $0x0,-0x18(%rax)
 1015b71:	jne    1015b30 <myl_rc_edges_release+0x190>
 1015b73:	or     $0x1,%rcx
 1015b77:	mov    %rcx,-0x10(%rax)
 1015b7b:	mov    0x1608(%r15),%rax
 1015b82:	cmpl   $0x0,0xd0(%rax)
 1015b89:	jne    1015b0d <myl_rc_edges_release+0x16d>
 1015b8b:	mov    %r15,%rdi
 1015b8e:	call   10128f0 <myl_rc_dead_outside>
 1015b93:	jmp    1015b30 <myl_rc_edges_release+0x190>
 1015b95:	add    $0x8,%rsp
 1015b99:	pop    %rbx
 1015b9a:	pop    %r12
 1015b9c:	pop    %r13
 1015b9e:	pop    %r14
 1015ba0:	pop    %r15
 1015ba2:	pop    %rbp
 1015ba3:	ret
 1015ba4:	call   101246d <myl_rc_invariant_failed>
 1015ba9:	int3
 1015baa:	int3
 1015bab:	int3
 1015bac:	int3
 1015bad:	int3
 1015bae:	int3
 1015baf:	int3

0000000001015bb0 <shallow_release>:
 1015bb0:	push   %rbp
 1015bb1:	mov    %rsp,%rbp
 1015bb4:	push   %r15
 1015bb6:	push   %r14
 1015bb8:	push   %r13
 1015bba:	push   %r12
 1015bbc:	push   %rbx
 1015bbd:	sub    $0x28,%rsp
 1015bc1:	mov    0x8(%rsi),%r10d
 1015bc5:	lea    -0x1(%r10),%eax
 1015bc9:	cmp    $0x4,%eax
 1015bcc:	ja     1015c25 <shallow_release+0x75>
 1015bce:	lea    -0x12b11(%rip),%r8        # 10030c4 <myl_rc_map_sentinel+0x24>
 1015bd5:	movslq (%r8,%rax,4),%rax
 1015bd9:	add    %r8,%rax
 1015bdc:	jmp    *%rax
 1015bde:	mov    $0x1,%r13d
 1015be4:	jmp    1015c28 <shallow_release+0x78>
 1015be6:	mov    0x10(%rsi),%r12
 1015bea:	mov    0x18(%rsi),%r13
 1015bee:	mov    0x20(%rsi),%rbx
 1015bf2:	add    %rdx,%rbx
 1015bf5:	mov    $0x4,%r10d
 1015bfb:	xor    %r11d,%r11d
 1015bfe:	jmp    1015c30 <shallow_release+0x80>
 1015c00:	mov    0x10(%rsi),%r12
 1015c04:	mov    0x18(%rsi),%r13
 1015c08:	mov    $0x2,%r10d
 1015c0e:	xor    %r11d,%r11d
 1015c11:	jmp    1015c2e <shallow_release+0x7e>
 1015c13:	mov    0x10(%rsi),%rax
 1015c17:	mov    0x18(%rsi),%r13
 1015c1b:	mov    0x20(%rsi),%r11
 1015c1f:	mov    0x8(%rax),%r10d
 1015c23:	jmp    1015c2b <shallow_release+0x7b>
 1015c25:	xor    %r13d,%r13d
 1015c28:	xor    %r11d,%r11d
 1015c2b:	xor    %r12d,%r12d
 1015c2e:	xor    %ebx,%ebx
 1015c30:	movabs $0x4000000000000002,%r9
 1015c3a:	mov    %r13,%r15
 1015c3d:	neg    %r15
 1015c40:	xor    %r14d,%r14d
 1015c43:	test   %r12,%r12
 1015c46:	je     1015cb0 <shallow_release+0x100>
 1015c48:	cmp    %r13,%r14
 1015c4b:	jae    1015e30 <shallow_release+0x280>
 1015c51:	lea    (%r14,%r14,2),%rax
 1015c55:	lea    0x10(%r12),%rsi
 1015c5a:	lea    (%rsi,%rax,8),%rax
 1015c5e:	inc    %r14
 1015c61:	jmp    1015c88 <shallow_release+0xd8>
 1015c63:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015c70:	add    $0x18,%rax
 1015c74:	lea    (%r15,%r14,1),%rsi
 1015c78:	inc    %rsi
 1015c7b:	inc    %r14
 1015c7e:	cmp    $0x1,%rsi
 1015c82:	je     1015e30 <shallow_release+0x280>
 1015c88:	mov    -0x8(%rax),%rsi
 1015c8c:	mov    0x8(%rsi),%r8d
 1015c90:	test   %r8d,%r8d
 1015c93:	je     1015c70 <shallow_release+0xc0>
 1015c95:	test   %rbx,%rbx
 1015c98:	je     1015ca0 <shallow_release+0xf0>
 1015c9a:	mov    (%rax),%esi
 1015c9c:	cmp    (%rbx),%esi
 1015c9e:	jne    1015c70 <shallow_release+0xc0>
 1015ca0:	mov    -0x10(%rax),%rax
 1015ca4:	jmp    1015cc6 <shallow_release+0x116>
 1015ca6:	cs nopw 0x0(%rax,%rax,1)
 1015cb0:	cmp    %r13,%r14
 1015cb3:	je     1015e30 <shallow_release+0x280>
 1015cb9:	mov    %r14,%rax
 1015cbc:	inc    %r14
 1015cbf:	imul   %r11,%rax
 1015cc3:	mov    %r10d,%r8d
 1015cc6:	mov    (%rdx,%rax,1),%rsi
 1015cca:	movq   $0x0,(%rdx,%rax,1)
 1015cd2:	test   %ecx,%ecx
 1015cd4:	jne    1015d70 <shallow_release+0x1c0>
 1015cda:	cmp    $0x5,%r8d
 1015cde:	je     1015d70 <shallow_release+0x1c0>
 1015ce4:	test   %rsi,%rsi
 1015ce7:	je     1015c43 <shallow_release+0x93>
 1015ced:	mov    -0x10(%rsi),%r8
 1015cf1:	test   %r9,%r8
 1015cf4:	jne    1015c43 <shallow_release+0x93>
 1015cfa:	test   $0x1,%r8b
 1015cfe:	jne    1015e3f <shallow_release+0x28f>
 1015d04:	mov    -0x20(%rsi),%r9
 1015d08:	test   %r9,%r9
 1015d0b:	je     1015e3f <shallow_release+0x28f>
 1015d11:	lea    -0x20(%rsi),%rax
 1015d15:	dec    %r9
 1015d18:	mov    %r9,(%rax)
 1015d1b:	movabs $0x4000000000000002,%r9
 1015d25:	jne    1015c43 <shallow_release+0x93>
 1015d2b:	cmpq   $0x0,-0x18(%rsi)
 1015d30:	jne    1015c43 <shallow_release+0x93>
 1015d36:	or     $0x1,%r8
 1015d3a:	mov    %r8,-0x10(%rsi)
 1015d3e:	mov    0x1608(%rdi),%rsi
 1015d45:	cmpl   $0x0,0xd0(%rsi)
 1015d4c:	je     1015def <shallow_release+0x23f>
 1015d52:	mov    0xc8(%rsi),%rsi
 1015d59:	mov    %rsi,(%rax)
 1015d5c:	mov    0x1608(%rdi),%rsi
 1015d63:	mov    %rax,0xc8(%rsi)
 1015d6a:	jmp    1015c43 <shallow_release+0x93>
 1015d6f:	nop
 1015d70:	test   %rsi,%rsi
 1015d73:	je     1015c43 <shallow_release+0x93>
 1015d79:	mov    -0x10(%rsi),%rax
 1015d7d:	test   %r9,%rax
 1015d80:	jne    1015c43 <shallow_release+0x93>
 1015d86:	test   $0x1,%al
 1015d88:	jne    1015e3f <shallow_release+0x28f>
 1015d8e:	mov    -0x18(%rsi),%r8
 1015d92:	test   %r8,%r8
 1015d95:	je     1015e3f <shallow_release+0x28f>
 1015d9b:	dec    %r8
 1015d9e:	mov    %r8,-0x18(%rsi)
 1015da2:	or     -0x20(%rsi),%r8
 1015da6:	jne    1015c43 <shallow_release+0x93>
 1015dac:	or     $0x1,%rax
 1015db0:	mov    %rax,-0x10(%rsi)
 1015db4:	add    $0xffffffffffffffe0,%rsi
 1015db8:	mov    0x1608(%rdi),%rax
 1015dbf:	cmpl   $0x0,0xd0(%rax)
 1015dc6:	je     1015de5 <shallow_release+0x235>
 1015dc8:	mov    0xc8(%rax),%rax
 1015dcf:	mov    %rax,(%rsi)
 1015dd2:	mov    0x1608(%rdi),%rax
 1015dd9:	mov    %rsi,0xc8(%rax)
 1015de0:	jmp    1015c43 <shallow_release+0x93>
 1015de5:	mov    %rdi,-0x38(%rbp)
 1015de9:	mov    -0x38(%rbp),%rdi
 1015ded:	jmp    1015dfa <shallow_release+0x24a>
 1015def:	mov    %rdi,-0x38(%rbp)
 1015df3:	mov    -0x38(%rbp),%rdi
 1015df7:	mov    %rax,%rsi
 1015dfa:	mov    %ecx,-0x2c(%rbp)
 1015dfd:	mov    %rdx,-0x50(%rbp)
 1015e01:	mov    %r10,-0x48(%rbp)
 1015e05:	mov    %r11,-0x40(%rbp)
 1015e09:	call   10128f0 <myl_rc_dead_outside>
 1015e0e:	movabs $0x4000000000000002,%r9
 1015e18:	mov    -0x40(%rbp),%r11
 1015e1c:	mov    -0x48(%rbp),%r10
 1015e20:	mov    -0x38(%rbp),%rdi
 1015e24:	mov    -0x50(%rbp),%rdx
 1015e28:	mov    -0x2c(%rbp),%ecx
 1015e2b:	jmp    1015c43 <shallow_release+0x93>
 1015e30:	add    $0x28,%rsp
 1015e34:	pop    %rbx
 1015e35:	pop    %r12
 1015e37:	pop    %r13
 1015e39:	pop    %r14
 1015e3b:	pop    %r15
 1015e3d:	pop    %rbp
 1015e3e:	ret
 1015e3f:	call   101246d <myl_rc_invariant_failed>
 1015e44:	int3
 1015e45:	int3
 1015e46:	int3
 1015e47:	int3
 1015e48:	int3
 1015e49:	int3
 1015e4a:	int3
 1015e4b:	int3
 1015e4c:	int3
 1015e4d:	int3
 1015e4e:	int3
 1015e4f:	int3

0000000001015e50 <myl_rc_flat_edges_release>:
 1015e50:	push   %rbp
 1015e51:	mov    %rsp,%rbp
 1015e54:	push   %r15
 1015e56:	push   %r14
 1015e58:	push   %r13
 1015e5a:	push   %r12
 1015e5c:	push   %rbx
 1015e5d:	sub    $0x18,%rsp
 1015e61:	test   %rdi,%rdi
 1015e64:	je     1015ffa <myl_rc_flat_edges_release+0x1aa>
 1015e6a:	mov    0x1608(%rdi),%rax
 1015e71:	test   %rax,%rax
 1015e74:	je     1015ffa <myl_rc_flat_edges_release+0x1aa>
 1015e7a:	cmpq   $0x0,0xc0(%rax)
 1015e82:	jne    1015ffa <myl_rc_flat_edges_release+0x1aa>
 1015e88:	mov    %rsi,%r15
 1015e8b:	mov    0x40(%rsi),%esi
 1015e8e:	cmp    $0x11,%esi
 1015e91:	jae    1015ffa <myl_rc_flat_edges_release+0x1aa>
 1015e97:	mov    %rdx,%r14
 1015e9a:	mov    0x50(%r15),%r8
 1015e9e:	mov    %r8,%rax
 1015ea1:	mul    %rcx
 1015ea4:	jo     1015ffa <myl_rc_flat_edges_release+0x1aa>
 1015eaa:	test   %rax,%rax
 1015ead:	sete   %al
 1015eb0:	test   %r14,%r14
 1015eb3:	setne  %dl
 1015eb6:	or     %al,%dl
 1015eb8:	je     1015ffa <myl_rc_flat_edges_release+0x1aa>
 1015ebe:	test   %esi,%esi
 1015ec0:	sete   %al
 1015ec3:	test   %rcx,%rcx
 1015ec6:	sete   %dl
 1015ec9:	or     %al,%dl
 1015ecb:	jne    1015feb <myl_rc_flat_edges_release+0x19b>
 1015ed1:	lea    0x5c(%r15),%r9
 1015ed5:	lea    0x5a(%r15),%r10
 1015ed9:	lea    0x58(%r15),%r11
 1015edd:	xor    %r13d,%r13d
 1015ee0:	movabs $0x4000000000000002,%rbx
 1015eea:	mov    %rcx,-0x38(%rbp)
 1015eee:	mov    %rdi,-0x30(%rbp)
 1015ef2:	jmp    1015f13 <myl_rc_flat_edges_release+0xc3>
 1015ef4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015f00:	mov    0x50(%r15),%r8
 1015f04:	add    %r8,%r14
 1015f07:	inc    %r13
 1015f0a:	cmp    %rcx,%r13
 1015f0d:	je     1015feb <myl_rc_flat_edges_release+0x19b>
 1015f13:	cmpb   $0x0,0x46(%r15)
 1015f18:	mov    %r11,%rax
 1015f1b:	je     1015f31 <myl_rc_flat_edges_release+0xe1>
 1015f1d:	mov    0x48(%r15),%eax
 1015f21:	mov    (%r14,%rax,1),%eax
 1015f25:	cmp    $0x20,%rax
 1015f29:	lea    (%r9,%rax,2),%rax
 1015f2d:	cmovae %r10,%rax
 1015f31:	movzwl (%rax),%r12d
 1015f35:	test   %r12d,%r12d
 1015f38:	jne    1015f67 <myl_rc_flat_edges_release+0x117>
 1015f3a:	jmp    1015f04 <myl_rc_flat_edges_release+0xb4>
 1015f3c:	mov    0xc8(%rax),%rax
 1015f43:	mov    %rax,(%rsi)
 1015f46:	mov    0x1608(%rdi),%rax
 1015f4d:	mov    %rsi,0xc8(%rax)
 1015f54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015f60:	blsr   %r12d,%r12d
 1015f65:	je     1015f00 <myl_rc_flat_edges_release+0xb0>
 1015f67:	tzcnt  %r12d,%eax
 1015f6c:	movzwl 0x9c(%r15,%rax,2),%edx
 1015f75:	mov    (%r14,%rdx,1),%rax
 1015f79:	movq   $0x0,(%r14,%rdx,1)
 1015f81:	test   %rax,%rax
 1015f84:	je     1015f60 <myl_rc_flat_edges_release+0x110>
 1015f86:	mov    -0x10(%rax),%r8
 1015f8a:	test   %rbx,%r8
 1015f8d:	jne    1015f60 <myl_rc_flat_edges_release+0x110>
 1015f8f:	test   $0x1,%r8b
 1015f93:	jne    1015ffa <myl_rc_flat_edges_release+0x1aa>
 1015f95:	mov    -0x20(%rax),%rdx
 1015f99:	test   %rdx,%rdx
 1015f9c:	je     1015ffa <myl_rc_flat_edges_release+0x1aa>
 1015f9e:	lea    -0x20(%rax),%rsi
 1015fa2:	dec    %rdx
 1015fa5:	mov    %rdx,(%rsi)
 1015fa8:	jne    1015f60 <myl_rc_flat_edges_release+0x110>
 1015faa:	cmpq   $0x0,-0x18(%rax)
 1015faf:	jne    1015f60 <myl_rc_flat_edges_release+0x110>
 1015fb1:	or     $0x1,%r8
 1015fb5:	mov    %r8,-0x10(%rax)
 1015fb9:	mov    0x1608(%rdi),%rax
 1015fc0:	cmpl   $0x0,0xd0(%rax)
 1015fc7:	jne    1015f3c <myl_rc_flat_edges_release+0xec>
 1015fcd:	call   10128f0 <myl_rc_dead_outside>
 1015fd2:	lea    0x58(%r15),%r11
 1015fd6:	lea    0x5a(%r15),%r10
 1015fda:	lea    0x5c(%r15),%r9
 1015fde:	mov    -0x30(%rbp),%rdi
 1015fe2:	mov    -0x38(%rbp),%rcx
 1015fe6:	jmp    1015f60 <myl_rc_flat_edges_release+0x110>
 1015feb:	add    $0x18,%rsp
 1015fef:	pop    %rbx
 1015ff0:	pop    %r12
 1015ff2:	pop    %r13
 1015ff4:	pop    %r14
 1015ff6:	pop    %r15
 1015ff8:	pop    %rbp
 1015ff9:	ret
 1015ffa:	call   101246d <myl_rc_invariant_failed>
 1015fff:	int3

0000000001016000 <myl_rc_drain>:
 1016000:	push   %rbp
 1016001:	mov    %rsp,%rbp
 1016004:	push   %r15
 1016006:	push   %r14
 1016008:	push   %r13
 101600a:	push   %r12
 101600c:	push   %rbx
 101600d:	sub    $0x48,%rsp
 1016011:	test   %rdi,%rdi
 1016014:	je     1016132 <myl_rc_drain+0x132>
 101601a:	mov    %rdi,%rbx
 101601d:	mov    0x1608(%rdi),%r13
 1016024:	test   %r13,%r13
 1016027:	je     1016132 <myl_rc_drain+0x132>
 101602d:	mov    0xc8(%r13),%rax
 1016034:	test   %rax,%rax
 1016037:	je     1016123 <myl_rc_drain+0x123>
 101603d:	cmpl   $0x0,0xd0(%r13)
 1016045:	jne    1016123 <myl_rc_drain+0x123>
 101604b:	cmpq   $0x0,0xc0(%r13)
 1016053:	jne    1016123 <myl_rc_drain+0x123>
 1016059:	movl   $0x1,0xd0(%r13)
 1016064:	mov    0x8(%r13),%rcx
 1016068:	xor    %r14d,%r14d
 101606b:	cmp    $0x101c340,%rcx
 1016072:	sete   %r14b
 1016076:	vxorps %xmm0,%xmm0,%xmm0
 101607a:	vmovups %ymm0,-0x48(%rbp)
 101607f:	vmovups %ymm0,-0x60(%rbp)
 1016084:	mov    %rax,-0x68(%rbp)
 1016088:	movq   $0xffffffffffffffff,-0x48(%rbp)
 1016090:	lea    -0x68(%rbp),%rsi
 1016094:	mov    %rbx,%rdi
 1016097:	mov    %r14d,%edx
 101609a:	vzeroupper
 101609d:	call   1016140 <drain_fast>
 10160a2:	test   %rax,%rax
 10160a5:	je     10160d9 <myl_rc_drain+0xd9>
 10160a7:	lea    -0x38(%rbp),%r15
 10160ab:	lea    -0x68(%rbp),%r12
 10160af:	nop
 10160b0:	mov    -0x68(%rbp),%rdx
 10160b4:	mov    %rbx,%rdi
 10160b7:	mov    %rax,%rsi
 10160ba:	mov    %r15,%rcx
 10160bd:	call   1016470 <drain_one>
 10160c2:	mov    %rax,-0x68(%rbp)
 10160c6:	mov    %rbx,%rdi
 10160c9:	mov    %r12,%rsi
 10160cc:	mov    %r14d,%edx
 10160cf:	call   1016140 <drain_fast>
 10160d4:	test   %rax,%rax
 10160d7:	jne    10160b0 <myl_rc_drain+0xb0>
 10160d9:	movq   $0x0,0xc8(%r13)
 10160e4:	mov    -0x38(%rbp),%rax
 10160e8:	test   %rax,%rax
 10160eb:	je     1016118 <myl_rc_drain+0x118>
 10160ed:	mov    0x40(%rbx),%rcx
 10160f1:	sub    %rax,%rcx
 10160f4:	jb     1016132 <myl_rc_drain+0x132>
 10160f6:	mov    %rcx,0x40(%rbx)
 10160fa:	add    0x50(%rbx),%rax
 10160fe:	mov    $0xffffffffffffffff,%rcx
 1016105:	cmovae %rax,%rcx
 1016109:	mov    %rcx,0x50(%rbx)
 101610d:	mov    -0x30(%rbp),%rax
 1016111:	add    %rax,0x1710(%rbx)
 1016118:	movl   $0x0,0xd0(%r13)
 1016123:	add    $0x48,%rsp
 1016127:	pop    %rbx
 1016128:	pop    %r12
 101612a:	pop    %r13
 101612c:	pop    %r14
 101612e:	pop    %r15
 1016130:	pop    %rbp
 1016131:	ret
 1016132:	call   101246d <myl_rc_invariant_failed>
 1016137:	int3
 1016138:	int3
 1016139:	int3
 101613a:	int3
 101613b:	int3
 101613c:	int3
 101613d:	int3
 101613e:	int3
 101613f:	int3

0000000001016140 <drain_fast>:
 1016140:	push   %rbp
 1016141:	mov    %rsp,%rbp
 1016144:	push   %r15
 1016146:	push   %r14
 1016148:	push   %r13
 101614a:	push   %r12
 101614c:	push   %rbx
 101614d:	sub    $0x48,%rsp
 1016151:	mov    %rsi,%rax
 1016154:	mov    (%rsi),%rsi
 1016157:	mov    0x8(%rax),%rcx
 101615b:	mov    %rcx,-0x40(%rbp)
 101615f:	mov    0x10(%rax),%r14
 1016163:	mov    0x18(%rax),%r11
 1016167:	mov    0x20(%rax),%r15
 101616b:	mov    0x28(%rax),%ebx
 101616e:	vmovdqu 0x30(%rax),%xmm1
 1016173:	test   %rsi,%rsi
 1016176:	je     1016433 <drain_fast+0x2f3>
 101617c:	mov    %edx,%r10d
 101617f:	mov    %rdi,%r12
 1016182:	mov    %rax,-0x48(%rbp)
 1016186:	vmovdqa -0x1333e(%rip),%xmm2        # 1002e50 <qbe_empty_registry+0xa8>
 101618e:	movabs $0x4000000000000003,%r13
 1016198:	mov    %rdi,-0x58(%rbp)
 101619c:	jmp    10161ec <drain_fast+0xac>
 101619e:	xchg   %ax,%ax
 10161a0:	vmovdqa %xmm1,-0x70(%rbp)
 10161a5:	mov    %r12,%rdi
 10161a8:	mov    %r14,%rcx
 10161ab:	lea    -0x70(%rbp),%r8
 10161af:	mov    %ebx,-0x4c(%rbp)
 10161b2:	mov    %r10d,%ebx
 10161b5:	mov    %r15,%r12
 10161b8:	mov    %r11,%r15
 10161bb:	call   1016e40 <drain_pairs>
 10161c0:	mov    %r15,%r11
 10161c3:	mov    %r12,%r15
 10161c6:	mov    -0x58(%rbp),%r12
 10161ca:	vmovdqa -0x13382(%rip),%xmm2        # 1002e50 <qbe_empty_registry+0xa8>
 10161d2:	mov    %ebx,%r10d
 10161d5:	mov    -0x4c(%rbp),%ebx
 10161d8:	mov    %rax,%rdx
 10161db:	vmovdqa -0x70(%rbp),%xmm1
 10161e0:	mov    %rdx,%rsi
 10161e3:	test   %rdx,%rdx
 10161e6:	je     1016429 <drain_fast+0x2e9>
 10161ec:	mov    (%rsi),%rdx
 10161ef:	mov    0x18(%rsi),%rcx
 10161f3:	cmp    -0x40(%rbp),%rcx
 10161f7:	je     10162e3 <drain_fast+0x1a3>
 10161fd:	mov    0x1608(%r12),%r8
 1016205:	mov    0xd8(%r8),%rax
 101620c:	cmp    %rcx,%rax
 101620f:	je     1016260 <drain_fast+0x120>
 1016211:	cmp    %rcx,0xe0(%r8)
 1016218:	je     1016269 <drain_fast+0x129>
 101621a:	mov    0x34(%rcx),%eax
 101621d:	cmp    %rax,0xa0(%r8)
 1016224:	jbe    10163f5 <drain_fast+0x2b5>
 101622a:	mov    0x98(%r8),%rdi
 1016231:	shl    $0x4,%rax
 1016235:	cmp    %rcx,(%rdi,%rax,1)
 1016239:	jne    10163f5 <drain_fast+0x2b5>
 101623f:	add    %rax,%rdi
 1016242:	mov    0x8(%rdi),%r14
 1016246:	test   %r14,%r14
 1016249:	je     1016424 <drain_fast+0x2e4>
 101624f:	add    $0x40,%r14
 1016253:	mov    0xd8(%r8),%rax
 101625a:	jmp    1016270 <drain_fast+0x130>
 101625c:	nopl   0x0(%rax)
 1016260:	mov    0xe8(%r8),%r14
 1016267:	jmp    1016293 <drain_fast+0x153>
 1016269:	mov    0xf0(%r8),%r14
 1016270:	mov    %rax,0xe0(%r8)
 1016277:	mov    0xe8(%r8),%rax
 101627e:	mov    %rax,0xf0(%r8)
 1016285:	mov    %rcx,0xd8(%r8)
 101628c:	mov    %r14,0xe8(%r8)
 1016293:	mov    (%r14),%eax
 1016296:	test   %eax,%eax
 1016298:	je     10162b0 <drain_fast+0x170>
 101629a:	movzwl 0x18(%r14),%ebx
 101629f:	movabs $0xcfffffffffffffff,%r11
 10162a9:	test   %r10d,%r10d
 10162ac:	jne    10162c1 <drain_fast+0x181>
 10162ae:	jmp    10162d8 <drain_fast+0x198>
 10162b0:	xor    %ebx,%ebx
 10162b2:	movabs $0xc000000000000003,%r11
 10162bc:	test   %r10d,%r10d
 10162bf:	je     10162d8 <drain_fast+0x198>
 10162c1:	cmp    $0x10,%eax
 10162c4:	ja     10162d8 <drain_fast+0x198>
 10162c6:	xor    %edi,%edi
 10162c8:	test   %eax,%eax
 10162ca:	setne  %al
 10162cd:	cmpb   $0x0,0x6(%r14)
 10162d2:	je     10163e5 <drain_fast+0x2a5>
 10162d8:	mov    $0xffffffffffffffff,%r15
 10162df:	mov    %rcx,-0x40(%rbp)
 10162e3:	mov    0x10(%rsi),%rax
 10162e7:	and    %r11,%rax
 10162ea:	cmp    %r15,%rax
 10162ed:	jne    101642d <drain_fast+0x2ed>
 10162f3:	cmp    $0x3,%ebx
 10162f6:	je     10161a0 <drain_fast+0x60>
 10162fc:	nopl   0x0(%rax)
 1016300:	test   %ebx,%ebx
 1016302:	je     1016380 <drain_fast+0x240>
 1016304:	mov    %ebx,%eax
 1016306:	jmp    1016321 <drain_fast+0x1e1>
 1016308:	nopl   0x0(%rax,%rax,1)
 1016310:	test   $0x1,%r9b
 1016314:	jne    1016424 <drain_fast+0x2e4>
 101631a:	blsr   %eax,%eax
 101631f:	je     1016380 <drain_fast+0x240>
 1016321:	tzcnt  %eax,%ecx
 1016325:	movzwl 0x5c(%r14,%rcx,2),%ecx
 101632b:	mov    0x20(%rsi,%rcx,1),%r8
 1016330:	test   %r8,%r8
 1016333:	je     101631a <drain_fast+0x1da>
 1016335:	mov    -0x10(%r8),%r9
 1016339:	test   %r13,%r9
 101633c:	jne    1016310 <drain_fast+0x1d0>
 101633e:	lea    -0x20(%r8),%rcx
 1016342:	mov    (%rcx),%rdi
 1016345:	cmp    $0x1,%rdi
 1016349:	je     1016355 <drain_fast+0x215>
 101634b:	test   %rdi,%rdi
 101634e:	jne    101635c <drain_fast+0x21c>
 1016350:	jmp    1016424 <drain_fast+0x2e4>
 1016355:	cmpq   $0x0,-0x18(%r8)
 101635a:	je     1016364 <drain_fast+0x224>
 101635c:	dec    %rdi
 101635f:	mov    %rdi,(%rcx)
 1016362:	jmp    101631a <drain_fast+0x1da>
 1016364:	or     $0x1,%r9
 1016368:	mov    %r9,-0x10(%r8)
 101636c:	mov    %rdx,%rdi
 101636f:	mov    %rcx,%rdx
 1016372:	jmp    101635f <drain_fast+0x21f>
 1016374:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016380:	mov    %rsi,%rax
 1016383:	and    $0xffffffffffff0000,%rax
 1016389:	mov    (%rax),%rcx
 101638c:	movq   $0x3,0x10(%rsi)
 1016394:	mov    0x1610(%r12,%rcx,8),%rdi
 101639c:	mov    %rdi,(%rsi)
 101639f:	mov    %rsi,0x1610(%r12,%rcx,8)
 10163a7:	vpinsrq $0x1,0x8(%rax),%xmm2,%xmm0
 10163ae:	vpaddq %xmm1,%xmm0,%xmm1
 10163b2:	test   %rdx,%rdx
 10163b5:	je     1016429 <drain_fast+0x2e9>
 10163b7:	mov    -0x40(%rbp),%rax
 10163bb:	cmp    %rax,0x18(%rdx)
 10163bf:	jne    10161e0 <drain_fast+0xa0>
 10163c5:	mov    0x10(%rdx),%rax
 10163c9:	and    %r11,%rax
 10163cc:	cmp    %r15,%rax
 10163cf:	jne    10161e0 <drain_fast+0xa0>
 10163d5:	mov    %rdx,%rsi
 10163d8:	mov    (%rdx),%rdx
 10163db:	test   %ebx,%ebx
 10163dd:	jne    1016304 <drain_fast+0x1c4>
 10163e3:	jmp    1016380 <drain_fast+0x240>
 10163e5:	mov    %al,%dil
 10163e8:	lea    0x1(,%rdi,4),%r15
 10163f0:	jmp    10162df <drain_fast+0x19f>
 10163f5:	mov    %r12,%rdi
 10163f8:	mov    %rsi,%r9
 10163fb:	mov    %rcx,%rsi
 10163fe:	vmovdqa %xmm1,-0x40(%rbp)
 1016403:	call   1012eea <myl_rc_binding_find_slow>
 1016408:	vmovdqa -0x135c0(%rip),%xmm2        # 1002e50 <qbe_empty_registry+0xa8>
 1016410:	vmovdqa -0x40(%rbp),%xmm1
 1016415:	mov    %r9,%rsi
 1016418:	mov    %rax,%r14
 101641b:	test   %r14,%r14
 101641e:	jne    101624f <drain_fast+0x10f>
 1016424:	call   101246d <myl_rc_invariant_failed>
 1016429:	xor    %esi,%esi
 101642b:	xor    %edx,%edx
 101642d:	mov    -0x48(%rbp),%rax
 1016431:	jmp    1016437 <drain_fast+0x2f7>
 1016433:	xor    %esi,%esi
 1016435:	xor    %edx,%edx
 1016437:	mov    %rdx,(%rax)
 101643a:	mov    -0x40(%rbp),%rcx
 101643e:	mov    %rcx,0x8(%rax)
 1016442:	mov    %r14,0x10(%rax)
 1016446:	mov    %r11,0x18(%rax)
 101644a:	mov    %r15,0x20(%rax)
 101644e:	mov    %ebx,0x28(%rax)
 1016451:	movl   $0x0,0x2c(%rax)
 1016458:	vmovdqu %xmm1,0x30(%rax)
 101645d:	mov    %rsi,%rax
 1016460:	add    $0x48,%rsp
 1016464:	pop    %rbx
 1016465:	pop    %r12
 1016467:	pop    %r13
 1016469:	pop    %r14
 101646b:	pop    %r15
 101646d:	pop    %rbp
 101646e:	ret
 101646f:	int3

0000000001016470 <drain_one>:
 1016470:	push   %rbp
 1016471:	mov    %rsp,%rbp
 1016474:	push   %r15
 1016476:	push   %r14
 1016478:	push   %r13
 101647a:	push   %r12
 101647c:	push   %rbx
 101647d:	push   %rax
 101647e:	mov    %rsi,%r14
 1016481:	mov    %rdi,%rbx
 1016484:	mov    0x1608(%rdi),%r8
 101648b:	mov    %rdx,0xc8(%r8)
 1016492:	mov    (%rcx),%rax
 1016495:	mov    %r8,%rdx
 1016498:	test   %rax,%rax
 101649b:	je     10164db <drain_one+0x6b>
 101649d:	mov    0x40(%rbx),%rdx
 10164a1:	sub    %rax,%rdx
 10164a4:	jb     10167f9 <drain_one+0x389>
 10164aa:	mov    %rdx,0x40(%rbx)
 10164ae:	add    0x50(%rbx),%rax
 10164b2:	mov    $0xffffffffffffffff,%rdx
 10164b9:	cmovae %rax,%rdx
 10164bd:	mov    %rdx,0x50(%rbx)
 10164c1:	mov    0x8(%rcx),%rax
 10164c5:	add    %rax,0x1710(%rbx)
 10164cc:	vxorps %xmm0,%xmm0,%xmm0
 10164d0:	vmovups %xmm0,(%rcx)
 10164d4:	mov    0x1608(%rbx),%rdx
 10164db:	mov    0x18(%r14),%rsi
 10164df:	mov    0xd8(%rdx),%rcx
 10164e6:	cmp    %rsi,%rcx
 10164e9:	je     1016536 <drain_one+0xc6>
 10164eb:	cmp    %rsi,0xe0(%rdx)
 10164f2:	je     101653f <drain_one+0xcf>
 10164f4:	mov    0x34(%rsi),%eax
 10164f7:	cmp    %rax,0xa0(%rdx)
 10164fe:	jbe    10167d2 <drain_one+0x362>
 1016504:	mov    0x98(%rdx),%rcx
 101650b:	shl    $0x4,%rax
 101650f:	cmp    %rsi,(%rcx,%rax,1)
 1016513:	jne    10167d2 <drain_one+0x362>
 1016519:	add    %rax,%rcx
 101651c:	mov    0x8(%rcx),%rax
 1016520:	test   %rax,%rax
 1016523:	je     10167f9 <drain_one+0x389>
 1016529:	add    $0x40,%rax
 101652d:	mov    0xd8(%rdx),%rcx
 1016534:	jmp    1016546 <drain_one+0xd6>
 1016536:	mov    0xe8(%rdx),%rax
 101653d:	jmp    1016569 <drain_one+0xf9>
 101653f:	mov    0xf0(%rdx),%rax
 1016546:	mov    %rcx,0xe0(%rdx)
 101654d:	mov    0xe8(%rdx),%rcx
 1016554:	mov    %rcx,0xf0(%rdx)
 101655b:	mov    %rsi,0xd8(%rdx)
 1016562:	mov    %rax,0xe8(%rdx)
 1016569:	mov    %r8,-0x30(%rbp)
 101656d:	movabs $0x4000000000000003,%r13
 1016577:	mov    0x10(%r14),%rcx
 101657b:	mov    %rcx,%rdx
 101657e:	and    %r13,%rdx
 1016581:	cmp    $0x1,%rdx
 1016585:	jne    10167f9 <drain_one+0x389>
 101658b:	lea    0x20(%r14),%r15
 101658f:	lea    -0x40(%rax),%rsi
 1016593:	mov    $0x3c,%edx
 1016598:	bzhi   %rdx,%rcx,%r12
 101659d:	shr    $0x2,%r12
 10165a1:	cmpl   $0x10,(%rax)
 10165a4:	ja     10165d7 <drain_one+0x167>
 10165a6:	cmp    $0x1,%r12
 10165aa:	jne    1016650 <drain_one+0x1e0>
 10165b0:	cmpb   $0x0,0x6(%rax)
 10165b4:	je     1016686 <drain_one+0x216>
 10165ba:	mov    0x8(%rax),%ecx
 10165bd:	mov    (%r15,%rcx,1),%ecx
 10165c1:	lea    0x1a(%rax),%rdx
 10165c5:	cmp    $0x20,%rcx
 10165c9:	lea    0x1c(%rax,%rcx,2),%rcx
 10165ce:	cmovae %rdx,%rcx
 10165d2:	jmp    101668a <drain_one+0x21a>
 10165d7:	mov    -0x28(%rax),%rax
 10165db:	test   %rax,%rax
 10165de:	je     1016628 <drain_one+0x1b8>
 10165e0:	mov    %rbx,%rdi
 10165e3:	mov    %r15,%rsi
 10165e6:	call   *%rax
 10165e8:	mov    0x18(%r14),%rsi
 10165ec:	mov    0x1608(%rbx),%rcx
 10165f3:	mov    0x34(%rsi),%eax
 10165f6:	cmp    %rax,0xa0(%rcx)
 10165fd:	jbe    10167e5 <drain_one+0x375>
 1016603:	mov    0x98(%rcx),%rcx
 101660a:	shl    $0x4,%rax
 101660e:	cmp    %rsi,(%rcx,%rax,1)
 1016612:	jne    10167e5 <drain_one+0x375>
 1016618:	add    %rax,%rcx
 101661b:	mov    0x8(%rcx),%rsi
 101661f:	test   %rsi,%rsi
 1016622:	je     10167f9 <drain_one+0x389>
 1016628:	mov    -0x30(%rbp),%rax
 101662c:	cmpq   $0x0,0xc0(%rax)
 1016634:	jne    10167f9 <drain_one+0x389>
 101663a:	mov    0x10(%rsi),%rax
 101663e:	test   %rax,%rax
 1016641:	je     1016660 <drain_one+0x1f0>
 1016643:	mov    %rbx,%rdi
 1016646:	mov    %r15,%rsi
 1016649:	mov    %r12,%rdx
 101664c:	call   *%rax
 101664e:	jmp    1016672 <drain_one+0x202>
 1016650:	mov    %rbx,%rdi
 1016653:	mov    %r15,%rdx
 1016656:	mov    %r12,%rcx
 1016659:	call   1015e50 <myl_rc_flat_edges_release>
 101665e:	jmp    1016672 <drain_one+0x202>
 1016660:	mov    0x8(%rsi),%rsi
 1016664:	mov    %rbx,%rdi
 1016667:	mov    %r15,%rdx
 101666a:	mov    %r12,%rcx
 101666d:	call   10159a0 <myl_rc_edges_release>
 1016672:	mov    -0x30(%rbp),%r12
 1016676:	cmpq   $0x0,0xc0(%r12)
 101667f:	je     10166b8 <drain_one+0x248>
 1016681:	jmp    10167f9 <drain_one+0x389>
 1016686:	lea    0x18(%rax),%rcx
 101668a:	mov    -0x30(%rbp),%r12
 101668e:	movzwl (%rcx),%edx
 1016691:	mov    0xc8(%r12),%rcx
 1016699:	test   %edx,%edx
 101669b:	jne    1016765 <drain_one+0x2f5>
 10166a1:	mov    %rcx,0xc8(%r12)
 10166a9:	cmpq   $0x0,0xc0(%r12)
 10166b2:	jne    10167f9 <drain_one+0x389>
 10166b8:	mov    0x10(%r14),%rax
 10166bc:	and    %rax,%r13
 10166bf:	cmp    $0x1,%r13
 10166c3:	jne    10167f9 <drain_one+0x389>
 10166c9:	test   %rax,%rax
 10166cc:	setns  %cl
 10166cf:	mov    0x1608(%rbx),%rax
 10166d6:	mov    0x8(%rax),%rax
 10166da:	cmp    $0x101c340,%rax
 10166e1:	sete   %dl
 10166e4:	and    %cl,%dl
 10166e6:	cmp    $0x1,%dl
 10166e9:	jne    10167b3 <drain_one+0x343>
 10166ef:	mov    0x40(%rbx),%rax
 10166f3:	test   %rax,%rax
 10166f6:	je     10167f9 <drain_one+0x389>
 10166fc:	mov    0x50(%rbx),%rcx
 1016700:	cmp    $0xffffffffffffffff,%rcx
 1016704:	je     101670d <drain_one+0x29d>
 1016706:	inc    %rcx
 1016709:	mov    %rcx,0x50(%rbx)
 101670d:	mov    %r14,%rcx
 1016710:	and    $0xffffffffffff0000,%rcx
 1016717:	dec    %rax
 101671a:	mov    %rax,0x40(%rbx)
 101671e:	movq   $0x3,0x10(%r14)
 1016726:	mov    (%rcx),%rax
 1016729:	mov    0x1610(%rbx,%rax,8),%rax
 1016731:	mov    %rax,(%r14)
 1016734:	mov    (%rcx),%rax
 1016737:	mov    %r14,0x1610(%rbx,%rax,8)
 101673f:	mov    0x8(%rcx),%rax
 1016743:	add    %rax,0x1710(%rbx)
 101674a:	jmp    10167bb <drain_one+0x34b>
 101674c:	nopl   0x0(%rax)
 1016750:	test   $0x1,%r9b
 1016754:	jne    10167f9 <drain_one+0x389>
 101675a:	blsr   %edx,%edx
 101675f:	je     10166a1 <drain_one+0x231>
 1016765:	tzcnt  %edx,%esi
 1016769:	movzwl 0x5c(%rax,%rsi,2),%esi
 101676e:	mov    (%r15,%rsi,1),%r8
 1016772:	test   %r8,%r8
 1016775:	je     101675a <drain_one+0x2ea>
 1016777:	mov    -0x10(%r8),%r9
 101677b:	test   %r13,%r9
 101677e:	jne    1016750 <drain_one+0x2e0>
 1016780:	lea    -0x20(%r8),%rsi
 1016784:	mov    (%rsi),%rdi
 1016787:	cmp    $0x1,%rdi
 101678b:	je     1016794 <drain_one+0x324>
 101678d:	test   %rdi,%rdi
 1016790:	jne    101679b <drain_one+0x32b>
 1016792:	jmp    10167f9 <drain_one+0x389>
 1016794:	cmpq   $0x0,-0x18(%r8)
 1016799:	je     10167a3 <drain_one+0x333>
 101679b:	dec    %rdi
 101679e:	mov    %rdi,(%rsi)
 10167a1:	jmp    101675a <drain_one+0x2ea>
 10167a3:	or     $0x1,%r9
 10167a7:	mov    %r9,-0x10(%r8)
 10167ab:	mov    %rcx,%rdi
 10167ae:	mov    %rsi,%rcx
 10167b1:	jmp    101679e <drain_one+0x32e>
 10167b3:	mov    %rbx,%rdi
 10167b6:	mov    %r15,%rsi
 10167b9:	call   *%rax
 10167bb:	mov    0xc8(%r12),%rax
 10167c3:	add    $0x8,%rsp
 10167c7:	pop    %rbx
 10167c8:	pop    %r12
 10167ca:	pop    %r13
 10167cc:	pop    %r14
 10167ce:	pop    %r15
 10167d0:	pop    %rbp
 10167d1:	ret
 10167d2:	mov    %rbx,%rdi
 10167d5:	call   1012eea <myl_rc_binding_find_slow>
 10167da:	test   %rax,%rax
 10167dd:	jne    1016529 <drain_one+0xb9>
 10167e3:	jmp    10167f9 <drain_one+0x389>
 10167e5:	mov    %rbx,%rdi
 10167e8:	call   1012eea <myl_rc_binding_find_slow>
 10167ed:	mov    %rax,%rsi
 10167f0:	test   %rsi,%rsi
 10167f3:	jne    1016628 <drain_one+0x1b8>
 10167f9:	call   101246d <myl_rc_invariant_failed>
 10167fe:	int3
 10167ff:	int3

0000000001016800 <myl_rc_native_has_unique>:
 1016800:	push   %rbp
 1016801:	mov    %rsp,%rbp
 1016804:	test   %rdi,%rdi
 1016807:	je     10169a8 <myl_rc_native_has_unique+0x1a8>
 101680d:	mov    0x1608(%rdi),%rdx
 1016814:	test   %rdx,%rdx
 1016817:	je     10169a8 <myl_rc_native_has_unique+0x1a8>
 101681d:	cmpq   $0x0,0xc0(%rdx)
 1016825:	jne    10169a8 <myl_rc_native_has_unique+0x1a8>
 101682b:	vxorps %xmm0,%xmm0,%xmm0
 101682f:	mov    $0x160,%ecx
 1016834:	movzwl 0x30(%rsi),%eax
 1016838:	cmp    $0x1,%ax
 101683c:	jne    101689b <myl_rc_native_has_unique+0x9b>
 101683e:	cmpw   $0x5,0x32(%rsi)
 1016843:	jne    10168e6 <myl_rc_native_has_unique+0xe6>
 1016849:	mov    0x38(%rsi),%rax
 101684d:	test   %rax,%rax
 1016850:	je     10168e6 <myl_rc_native_has_unique+0xe6>
 1016856:	mov    0x34(%rax),%r8d
 101685a:	cmp    %r8,0xa0(%rdx)
 1016861:	jbe    101698d <myl_rc_native_has_unique+0x18d>
 1016867:	mov    0x98(%rdx),%rdx
 101686e:	shl    $0x4,%r8
 1016872:	cmp    %rax,(%rdx,%r8,1)
 1016876:	jne    101698d <myl_rc_native_has_unique+0x18d>
 101687c:	add    %r8,%rdx
 101687f:	mov    0x8(%rdx),%rax
 1016883:	test   %rax,%rax
 1016886:	je     10169a8 <myl_rc_native_has_unique+0x1a8>
 101688c:	cmpq   $0x0,0x18(%rax)
 1016891:	jne    10169af <myl_rc_native_has_unique+0x1af>
 1016897:	movzwl 0x30(%rsi),%eax
 101689b:	movzwl %ax,%eax
 101689e:	lea    -0x2(%rax),%edx
 10168a1:	cmp    $0x3,%edx
 10168a4:	jae    1016979 <myl_rc_native_has_unique+0x179>
 10168aa:	mov    0x1608(%rdi),%rax
 10168b1:	mov    0xc0(%rax),%rdx
 10168b8:	cmp    0xb8(%rax),%rdx
 10168bf:	jae    10169a8 <myl_rc_native_has_unique+0x1a8>
 10168c5:	mov    0xb0(%rax),%r8
 10168cc:	lea    0x1(%rdx),%r9
 10168d0:	mov    %r9,0xc0(%rax)
 10168d7:	lea    (%rdx,%rdx,2),%rax
 10168db:	mov    %rsi,(%r8,%rax,8)
 10168df:	vmovups %xmm0,0x8(%r8,%rax,8)
 10168e6:	mov    0x1608(%rdi),%rdx
 10168ed:	mov    0xc0(%rdx),%rsi
 10168f4:	xor    %eax,%eax
 10168f6:	test   %rsi,%rsi
 10168f9:	je     10169ad <myl_rc_native_has_unique+0x1ad>
 10168ff:	mov    0xb0(%rdx),%r8
 1016906:	lea    (%rsi,%rsi,2),%r9
 101690a:	dec    %rsi
 101690d:	lea    (%r8,%r9,8),%r8
 1016911:	add    $0xfffffffffffffff8,%r8
 1016915:	data16 cs nopw 0x0(%rax,%rax,1)
 1016920:	mov    -0x10(%r8),%r9
 1016924:	cmpw   $0x3,0x30(%r9)
 101692a:	jne    1016940 <myl_rc_native_has_unique+0x140>
 101692c:	xor    %r10d,%r10d
 101692f:	cmpq   $0x0,0x20(%r9)
 1016934:	setne  %r10b
 1016938:	jmp    1016944 <myl_rc_native_has_unique+0x144>
 101693a:	nopw   0x0(%rax,%rax,1)
 1016940:	mov    0x18(%r9),%r10
 1016944:	mov    (%r8),%r11
 1016947:	cmp    %r10,%r11
 101694a:	jb     1016960 <myl_rc_native_has_unique+0x160>
 101694c:	mov    %rsi,0xc0(%rdx)
 1016953:	add    $0xffffffffffffffe8,%r8
 1016957:	add    $0xffffffffffffffff,%rsi
 101695b:	jb     1016920 <myl_rc_native_has_unique+0x120>
 101695d:	jmp    10169ad <myl_rc_native_has_unique+0x1ad>
 101695f:	nop
 1016960:	mov    0x10(%r9),%rax
 1016964:	lea    0x1(%r11),%rsi
 1016968:	mov    %rsi,(%r8)
 101696b:	lea    (%r11,%r11,2),%rsi
 101696f:	mov    0x8(%rax,%rsi,8),%rsi
 1016974:	jmp    1016834 <myl_rc_native_has_unique+0x34>
 1016979:	cmp    $0x8,%eax
 101697c:	ja     10168e6 <myl_rc_native_has_unique+0xe6>
 1016982:	bt     %eax,%ecx
 1016985:	jae    10168e6 <myl_rc_native_has_unique+0xe6>
 101698b:	jmp    10169af <myl_rc_native_has_unique+0x1af>
 101698d:	mov    %rsi,%rdx
 1016990:	mov    %rax,%rsi
 1016993:	call   1012eea <myl_rc_binding_find_slow>
 1016998:	vxorps %xmm0,%xmm0,%xmm0
 101699c:	mov    %rdx,%rsi
 101699f:	test   %rax,%rax
 10169a2:	jne    101688c <myl_rc_native_has_unique+0x8c>
 10169a8:	call   101246d <myl_rc_invariant_failed>
 10169ad:	pop    %rbp
 10169ae:	ret
 10169af:	mov    0x1608(%rdi),%rax
 10169b6:	movq   $0x0,0xc0(%rax)
 10169c1:	mov    $0x1,%eax
 10169c6:	pop    %rbp
 10169c7:	ret
 10169c8:	int3
 10169c9:	int3
 10169ca:	int3
 10169cb:	int3
 10169cc:	int3
 10169cd:	int3
 10169ce:	int3
 10169cf:	int3

00000000010169d0 <myl_rc_binding_has_unique>:
 10169d0:	push   %rbp
 10169d1:	mov    %rsp,%rbp
 10169d4:	push   %rbx
 10169d5:	push   %rax
 10169d6:	test   %rdi,%rdi
 10169d9:	je     1016a03 <myl_rc_binding_has_unique+0x33>
 10169db:	mov    0x1608(%rdi),%rax
 10169e2:	test   %rax,%rax
 10169e5:	je     1016a03 <myl_rc_binding_has_unique+0x33>
 10169e7:	test   %rsi,%rsi
 10169ea:	je     1016a03 <myl_rc_binding_has_unique+0x33>
 10169ec:	cmpq   $0x0,0xc0(%rax)
 10169f4:	jne    1016a03 <myl_rc_binding_has_unique+0x33>
 10169f6:	movzbl 0x45(%rsi),%ecx
 10169fa:	test   %ecx,%ecx
 10169fc:	je     1016a08 <myl_rc_binding_has_unique+0x38>
 10169fe:	cmp    $0x3,%cl
 1016a01:	jb     1016a24 <myl_rc_binding_has_unique+0x54>
 1016a03:	call   101246d <myl_rc_invariant_failed>
 1016a08:	mov    (%rsi),%rax
 1016a0b:	mov    %rsi,%rbx
 1016a0e:	mov    %rax,%rsi
 1016a11:	call   1016800 <myl_rc_native_has_unique>
 1016a16:	cmp    $0x1,%eax
 1016a19:	mov    $0x2,%ecx
 1016a1e:	sbb    $0x0,%ecx
 1016a21:	mov    %cl,0x45(%rbx)
 1016a24:	xor    %eax,%eax
 1016a26:	cmp    $0x2,%ecx
 1016a29:	sete   %al
 1016a2c:	add    $0x8,%rsp
 1016a30:	pop    %rbx
 1016a31:	pop    %rbp
 1016a32:	ret
 1016a33:	int3
 1016a34:	int3
 1016a35:	int3
 1016a36:	int3
 1016a37:	int3
 1016a38:	int3
 1016a39:	int3
 1016a3a:	int3
 1016a3b:	int3
 1016a3c:	int3
 1016a3d:	int3
 1016a3e:	int3
 1016a3f:	int3

0000000001016a40 <myl_rc_value_seed>:
 1016a40:	push   %rbp
 1016a41:	mov    %rsp,%rbp
 1016a44:	push   %r15
 1016a46:	push   %r14
 1016a48:	push   %r13
 1016a4a:	push   %r12
 1016a4c:	push   %rbx
 1016a4d:	push   %rax
 1016a4e:	mov    %r8,-0x30(%rbp)
 1016a52:	test   %rdi,%rdi
 1016a55:	je     1016cc0 <myl_rc_value_seed+0x280>
 1016a5b:	mov    %rdx,%r14
 1016a5e:	mov    %rdi,%r15
 1016a61:	mov    0x1608(%rdi),%rdx
 1016a68:	test   %rdx,%rdx
 1016a6b:	je     1016cc0 <myl_rc_value_seed+0x280>
 1016a71:	cmp    %rcx,%r14
 1016a74:	je     1016cc0 <myl_rc_value_seed+0x280>
 1016a7a:	cmpq   $0x0,0xc0(%rdx)
 1016a82:	jne    1016cc0 <myl_rc_value_seed+0x280>
 1016a88:	mov    0x58(%rdx),%rax
 1016a8c:	mov    0x60(%rdx),%rdi
 1016a90:	movzbl 0x70(%rdx),%edx
 1016a94:	movabs $0x9e3779b97f4a7c15,%r8
 1016a9e:	imul   %rsi,%r8
 1016aa2:	shrx   %rdx,%r8,%rdx
 1016aa7:	nopw   0x0(%rax,%rax,1)
 1016ab0:	and    %rdi,%rdx
 1016ab3:	mov    %rdx,%r8
 1016ab6:	shl    $0x4,%r8
 1016aba:	mov    (%rax,%r8,1),%r8
 1016abe:	cmp    %rsi,%r8
 1016ac1:	je     1016ad1 <myl_rc_value_seed+0x91>
 1016ac3:	test   %r8,%r8
 1016ac6:	je     1016cc0 <myl_rc_value_seed+0x280>
 1016acc:	inc    %rdx
 1016acf:	jmp    1016ab0 <myl_rc_value_seed+0x70>
 1016ad1:	shl    $0x4,%rdx
 1016ad5:	mov    0x8(%rax,%rdx,1),%r12
 1016ada:	test   %r12,%r12
 1016add:	je     1016cc0 <myl_rc_value_seed+0x280>
 1016ae3:	mov    -0x30(%rbp),%rax
 1016ae7:	mulq   (%r12)
 1016aeb:	jo     1016cc0 <myl_rc_value_seed+0x280>
 1016af1:	mov    0x8(%r12),%edx
 1016af6:	or     $0x4,%edx
 1016af9:	cmp    $0x5,%edx
 1016afc:	jne    1016b19 <myl_rc_value_seed+0xd9>
 1016afe:	mov    %r14,%rdi
 1016b01:	xor    %esi,%esi
 1016b03:	mov    %rax,%rdx
 1016b06:	add    $0x8,%rsp
 1016b0a:	pop    %rbx
 1016b0b:	pop    %r12
 1016b0d:	pop    %r13
 1016b0f:	pop    %r14
 1016b11:	pop    %r15
 1016b13:	pop    %rbp
 1016b14:	jmp    101e4a0 <compiler_rt.fastMemset>
 1016b19:	mov    %r14,%rdi
 1016b1c:	mov    %rcx,%rsi
 1016b1f:	mov    %rax,%rdx
 1016b22:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1016b27:	cmpl   $0x0,0x8(%r12)
 1016b2d:	je     1016cb1 <myl_rc_value_seed+0x271>
 1016b33:	cmpq   $0x0,-0x30(%rbp)
 1016b38:	je     1016cb1 <myl_rc_value_seed+0x271>
 1016b3e:	mov    0x28(%r12),%r13
 1016b43:	xor    %ebx,%ebx
 1016b45:	jmp    1016b6b <myl_rc_value_seed+0x12b>
 1016b47:	nopw   0x0(%rax,%rax,1)
 1016b50:	mov    %r15,%rdi
 1016b53:	xor    %esi,%esi
 1016b55:	call   1015780 <walk>
 1016b5a:	add    (%r12),%r14
 1016b5e:	inc    %rbx
 1016b61:	cmp    -0x30(%rbp),%rbx
 1016b65:	je     1016cb1 <myl_rc_value_seed+0x271>
 1016b6b:	mov    0x8(%r12),%eax
 1016b70:	cmp    $0x2,%r13
 1016b74:	jbe    1016bc0 <myl_rc_value_seed+0x180>
 1016b76:	test   %eax,%eax
 1016b78:	je     1016b50 <myl_rc_value_seed+0x110>
 1016b7a:	mov    0x1608(%r15),%rax
 1016b81:	mov    0xc0(%rax),%rcx
 1016b88:	cmp    0xb8(%rax),%rcx
 1016b8f:	jae    1016cc0 <myl_rc_value_seed+0x280>
 1016b95:	mov    0xb0(%rax),%rdx
 1016b9c:	lea    0x1(%rcx),%rsi
 1016ba0:	mov    %rsi,0xc0(%rax)
 1016ba7:	lea    (%rcx,%rcx,2),%rax
 1016bab:	mov    %r12,(%rdx,%rax,8)
 1016baf:	mov    %r14,0x8(%rdx,%rax,8)
 1016bb4:	movq   $0x0,0x10(%rdx,%rax,8)
 1016bbd:	jmp    1016b50 <myl_rc_value_seed+0x110>
 1016bbf:	nop
 1016bc0:	dec    %eax
 1016bc2:	cmp    $0x4,%eax
 1016bc5:	ja     1016c12 <myl_rc_value_seed+0x1d2>
 1016bc7:	lea    -0x13af6(%rip),%rcx        # 10030d8 <myl_rc_map_sentinel+0x38>
 1016bce:	movslq (%rcx,%rax,4),%rax
 1016bd2:	add    %rcx,%rax
 1016bd5:	jmp    *%rax
 1016bd7:	mov    $0x1,%eax
 1016bdc:	xor    %ecx,%ecx
 1016bde:	jmp    1016c16 <myl_rc_value_seed+0x1d6>
 1016be0:	mov    0x10(%r12),%rdx
 1016be5:	mov    0x18(%r12),%rax
 1016bea:	mov    0x20(%r12),%rsi
 1016bef:	add    %r14,%rsi
 1016bf2:	xor    %ecx,%ecx
 1016bf4:	jmp    1016c1a <myl_rc_value_seed+0x1da>
 1016bf6:	mov    0x10(%r12),%rdx
 1016bfb:	mov    0x18(%r12),%rax
 1016c00:	xor    %ecx,%ecx
 1016c02:	xor    %esi,%esi
 1016c04:	jmp    1016c1a <myl_rc_value_seed+0x1da>
 1016c06:	mov    0x18(%r12),%rax
 1016c0b:	mov    0x20(%r12),%rcx
 1016c10:	jmp    1016c16 <myl_rc_value_seed+0x1d6>
 1016c12:	xor    %ecx,%ecx
 1016c14:	xor    %eax,%eax
 1016c16:	xor    %esi,%esi
 1016c18:	xor    %edx,%edx
 1016c1a:	lea    0x10(%rdx),%rdi
 1016c1e:	mov    %rax,%r8
 1016c21:	neg    %r8
 1016c24:	xor    %r9d,%r9d
 1016c27:	test   %rdx,%rdx
 1016c2a:	je     1016c90 <myl_rc_value_seed+0x250>
 1016c2c:	cmp    %rax,%r9
 1016c2f:	jae    1016b5a <myl_rc_value_seed+0x11a>
 1016c35:	lea    (%r9,%r9,2),%r10
 1016c39:	lea    (%rdi,%r10,8),%r10
 1016c3d:	inc    %r9
 1016c40:	jmp    1016c68 <myl_rc_value_seed+0x228>
 1016c42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016c50:	add    $0x18,%r10
 1016c54:	lea    (%r8,%r9,1),%r11
 1016c58:	inc    %r11
 1016c5b:	inc    %r9
 1016c5e:	cmp    $0x1,%r11
 1016c62:	je     1016b5a <myl_rc_value_seed+0x11a>
 1016c68:	mov    -0x8(%r10),%r11
 1016c6c:	cmpl   $0x0,0x8(%r11)
 1016c71:	je     1016c50 <myl_rc_value_seed+0x210>
 1016c73:	test   %rsi,%rsi
 1016c76:	je     1016c80 <myl_rc_value_seed+0x240>
 1016c78:	mov    (%r10),%r11d
 1016c7b:	cmp    (%rsi),%r11d
 1016c7e:	jne    1016c50 <myl_rc_value_seed+0x210>
 1016c80:	mov    -0x10(%r10),%r10
 1016c84:	movq   $0x0,(%r14,%r10,1)
 1016c8c:	jmp    1016c27 <myl_rc_value_seed+0x1e7>
 1016c8e:	xchg   %ax,%ax
 1016c90:	cmp    %rax,%r9
 1016c93:	je     1016b5a <myl_rc_value_seed+0x11a>
 1016c99:	lea    0x1(%r9),%r10
 1016c9d:	imul   %rcx,%r9
 1016ca1:	movq   $0x0,(%r14,%r9,1)
 1016ca9:	mov    %r10,%r9
 1016cac:	jmp    1016c27 <myl_rc_value_seed+0x1e7>
 1016cb1:	add    $0x8,%rsp
 1016cb5:	pop    %rbx
 1016cb6:	pop    %r12
 1016cb8:	pop    %r13
 1016cba:	pop    %r14
 1016cbc:	pop    %r15
 1016cbe:	pop    %rbp
 1016cbf:	ret
 1016cc0:	call   101246d <myl_rc_invariant_failed>
 1016cc5:	int3
 1016cc6:	int3
 1016cc7:	int3
 1016cc8:	int3
 1016cc9:	int3
 1016cca:	int3
 1016ccb:	int3
 1016ccc:	int3
 1016ccd:	int3
 1016cce:	int3
 1016ccf:	int3

0000000001016cd0 <myl_rc_construction_abort>:
 1016cd0:	push   %rbp
 1016cd1:	mov    %rsp,%rbp
 1016cd4:	push   %r15
 1016cd6:	push   %r14
 1016cd8:	push   %rbx
 1016cd9:	push   %rax
 1016cda:	test   %rsi,%rsi
 1016cdd:	je     1016dc4 <myl_rc_construction_abort+0xf4>
 1016ce3:	mov    -0x10(%rsi),%rax
 1016ce7:	test   $0x2,%al
 1016ce9:	jne    1016e23 <myl_rc_construction_abort+0x153>
 1016cef:	bt     $0x3e,%rax
 1016cf4:	jb     1016d05 <myl_rc_construction_abort+0x35>
 1016cf6:	add    $0x8,%rsp
 1016cfa:	pop    %rbx
 1016cfb:	pop    %r14
 1016cfd:	pop    %r15
 1016cff:	pop    %rbp
 1016d00:	jmp    1012ac0 <myl_rc_owner_release>
 1016d05:	test   $0x1,%al
 1016d07:	jne    1016dc4 <myl_rc_construction_abort+0xf4>
 1016d0d:	or     $0x1,%rax
 1016d11:	mov    %rax,-0x10(%rsi)
 1016d15:	mov    -0x8(%rsi),%rax
 1016d19:	mov    0x1608(%rdi),%rdx
 1016d20:	mov    0x34(%rax),%ecx
 1016d23:	cmp    %rcx,0xa0(%rdx)
 1016d2a:	mov    %rdi,%rbx
 1016d2d:	mov    %rsi,%r14
 1016d30:	jbe    1016e0c <myl_rc_construction_abort+0x13c>
 1016d36:	mov    0x98(%rdx),%rdx
 1016d3d:	shl    $0x4,%rcx
 1016d41:	cmp    %rax,(%rdx,%rcx,1)
 1016d45:	jne    1016e0c <myl_rc_construction_abort+0x13c>
 1016d4b:	add    %rcx,%rdx
 1016d4e:	mov    0x8(%rdx),%rax
 1016d52:	test   %rax,%rax
 1016d55:	je     1016e23 <myl_rc_construction_abort+0x153>
 1016d5b:	mov    $0x28,%ecx
 1016d60:	bzhi   %rcx,-0x10(%rsi),%r15
 1016d66:	mov    0x18(%rax),%rax
 1016d6a:	test   %rax,%rax
 1016d6d:	je     1016d7d <myl_rc_construction_abort+0xad>
 1016d6f:	mov    %rbx,%rdi
 1016d72:	mov    %r14,%rsi
 1016d75:	call   *%rax
 1016d77:	mov    %r14,%rsi
 1016d7a:	mov    %rbx,%rdi
 1016d7d:	mov    -0x8(%rsi),%rax
 1016d81:	mov    0x1608(%rdi),%rdx
 1016d88:	mov    0x34(%rax),%ecx
 1016d8b:	cmp    %rcx,0xa0(%rdx)
 1016d92:	jbe    1016e28 <myl_rc_construction_abort+0x158>
 1016d98:	mov    0x98(%rdx),%rdx
 1016d9f:	shl    $0x4,%rcx
 1016da3:	cmp    %rax,(%rdx,%rcx,1)
 1016da7:	jne    1016e28 <myl_rc_construction_abort+0x158>
 1016da9:	add    %rcx,%rdx
 1016dac:	mov    0x8(%rdx),%rax
 1016db0:	shr    $0x2,%r15
 1016db4:	mov    0x10(%rax),%rcx
 1016db8:	test   %rcx,%rcx
 1016dbb:	je     1016dcf <myl_rc_construction_abort+0xff>
 1016dbd:	mov    %r15,%rdx
 1016dc0:	call   *%rcx
 1016dc2:	jmp    1016de1 <myl_rc_construction_abort+0x111>
 1016dc4:	add    $0x8,%rsp
 1016dc8:	pop    %rbx
 1016dc9:	pop    %r14
 1016dcb:	pop    %r15
 1016dcd:	pop    %rbp
 1016dce:	ret
 1016dcf:	mov    0x8(%rax),%rax
 1016dd3:	mov    %rsi,%rdx
 1016dd6:	mov    %rax,%rsi
 1016dd9:	mov    %r15,%rcx
 1016ddc:	call   10159a0 <myl_rc_edges_release>
 1016de1:	mov    -0x8(%r14),%rcx
 1016de5:	mov    %r15,%rax
 1016de8:	mulq   (%rcx)
 1016deb:	jo     1016e23 <myl_rc_construction_abort+0x153>
 1016ded:	mov    %r14,%rdi
 1016df0:	xor    %esi,%esi
 1016df2:	mov    %rax,%rdx
 1016df5:	call   101e4a0 <compiler_rt.fastMemset>
 1016dfa:	mov    %rbx,%rdi
 1016dfd:	add    $0x8,%rsp
 1016e01:	pop    %rbx
 1016e02:	pop    %r14
 1016e04:	pop    %r15
 1016e06:	pop    %rbp
 1016e07:	jmp    1016000 <myl_rc_drain>
 1016e0c:	mov    %rbx,%rdi
 1016e0f:	mov    %rax,%rsi
 1016e12:	call   1012eea <myl_rc_binding_find_slow>
 1016e17:	mov    %r14,%rsi
 1016e1a:	test   %rax,%rax
 1016e1d:	jne    1016d5b <myl_rc_construction_abort+0x8b>
 1016e23:	call   101246d <myl_rc_invariant_failed>
 1016e28:	mov    %rbx,%rdi
 1016e2b:	mov    %rax,%rsi
 1016e2e:	call   1012eea <myl_rc_binding_find_slow>
 1016e33:	mov    %r14,%rsi
 1016e36:	jmp    1016db0 <myl_rc_construction_abort+0xe0>
 1016e3b:	int3
 1016e3c:	int3
 1016e3d:	int3
 1016e3e:	int3
 1016e3f:	int3

0000000001016e40 <drain_pairs>:
 1016e40:	push   %rbp
 1016e41:	mov    %rsp,%rbp
 1016e44:	push   %r15
 1016e46:	push   %r14
 1016e48:	push   %r13
 1016e4a:	push   %r12
 1016e4c:	push   %rbx
 1016e4d:	sub    $0x18,%rsp
 1016e51:	mov    %r8,-0x40(%rbp)
 1016e55:	mov    %rdx,%rbx
 1016e58:	movabs $0x4000000000000003,%r10
 1016e62:	mov    0x18(%rsi),%r11
 1016e66:	mov    %rsi,%r9
 1016e69:	and    $0xffffffffffff0000,%r9
 1016e70:	mov    (%r9),%rax
 1016e73:	movzwl 0x5c(%rcx),%r14d
 1016e78:	movzwl 0x5e(%rcx),%r15d
 1016e7d:	mov    %rdi,-0x38(%rbp)
 1016e81:	mov    %rax,-0x30(%rbp)
 1016e85:	mov    0x1610(%rdi,%rax,8),%r13
 1016e8d:	mov    $0x1,%ecx
 1016e92:	movabs $0xcfffffffffffffff,%r12
 1016e9c:	nopl   0x0(%rax)
 1016ea0:	mov    0x20(%rsi,%r14,1),%r8
 1016ea5:	test   %r8,%r8
 1016ea8:	je     1016ee8 <drain_pairs+0xa8>
 1016eaa:	mov    -0x10(%r8),%rdi
 1016eae:	test   %r10,%rdi
 1016eb1:	je     1016ec0 <drain_pairs+0x80>
 1016eb3:	test   $0x1,%dil
 1016eb7:	je     1016ee8 <drain_pairs+0xa8>
 1016eb9:	jmp    1016fcc <drain_pairs+0x18c>
 1016ebe:	xchg   %ax,%ax
 1016ec0:	lea    -0x20(%r8),%rax
 1016ec4:	mov    (%rax),%rdx
 1016ec7:	cmp    $0x1,%rdx
 1016ecb:	je     1016ed7 <drain_pairs+0x97>
 1016ecd:	test   %rdx,%rdx
 1016ed0:	jne    1016ee2 <drain_pairs+0xa2>
 1016ed2:	jmp    1016fcc <drain_pairs+0x18c>
 1016ed7:	cmpq   $0x0,-0x18(%r8)
 1016edc:	je     1016f6b <drain_pairs+0x12b>
 1016ee2:	dec    %rdx
 1016ee5:	mov    %rdx,(%rax)
 1016ee8:	mov    0x20(%rsi,%r15,1),%rdi
 1016eed:	test   %rdi,%rdi
 1016ef0:	je     1016f34 <drain_pairs+0xf4>
 1016ef2:	mov    -0x10(%rdi),%r8
 1016ef6:	test   %r10,%r8
 1016ef9:	je     1016f10 <drain_pairs+0xd0>
 1016efb:	mov    %rbx,%rax
 1016efe:	test   $0x1,%r8b
 1016f02:	je     1016f37 <drain_pairs+0xf7>
 1016f04:	jmp    1016fcc <drain_pairs+0x18c>
 1016f09:	nopl   0x0(%rax)
 1016f10:	lea    -0x20(%rdi),%rax
 1016f14:	mov    (%rax),%rdx
 1016f17:	cmp    $0x1,%rdx
 1016f1b:	je     1016f27 <drain_pairs+0xe7>
 1016f1d:	test   %rdx,%rdx
 1016f20:	jne    1016f2e <drain_pairs+0xee>
 1016f22:	jmp    1016fcc <drain_pairs+0x18c>
 1016f27:	cmpq   $0x0,-0x18(%rdi)
 1016f2c:	je     1016f7e <drain_pairs+0x13e>
 1016f2e:	dec    %rdx
 1016f31:	mov    %rdx,(%rax)
 1016f34:	mov    %rbx,%rax
 1016f37:	movq   $0x3,0x10(%rsi)
 1016f3f:	mov    %r13,(%rsi)
 1016f42:	test   %rax,%rax
 1016f45:	je     1016f8e <drain_pairs+0x14e>
 1016f47:	cmp    %r11,0x18(%rax)
 1016f4b:	jne    1016f8e <drain_pairs+0x14e>
 1016f4d:	mov    0x10(%rax),%rdx
 1016f51:	and    %r12,%rdx
 1016f54:	cmp    $0x5,%rdx
 1016f58:	jne    1016f8e <drain_pairs+0x14e>
 1016f5a:	mov    (%rax),%rbx
 1016f5d:	inc    %rcx
 1016f60:	mov    %rsi,%r13
 1016f63:	mov    %rax,%rsi
 1016f66:	jmp    1016ea0 <drain_pairs+0x60>
 1016f6b:	or     $0x1,%rdi
 1016f6f:	mov    %rdi,-0x10(%r8)
 1016f73:	mov    %rbx,%rdx
 1016f76:	mov    %rax,%rbx
 1016f79:	jmp    1016ee5 <drain_pairs+0xa5>
 1016f7e:	or     $0x1,%r8
 1016f82:	mov    %r8,-0x10(%rdi)
 1016f86:	mov    %rbx,%rdx
 1016f89:	mov    %rax,%rbx
 1016f8c:	jmp    1016f31 <drain_pairs+0xf1>
 1016f8e:	mov    -0x38(%rbp),%rdx
 1016f92:	mov    -0x30(%rbp),%rdi
 1016f96:	mov    %rsi,0x1610(%rdx,%rdi,8)
 1016f9e:	vmovq  %rcx,%xmm0
 1016fa3:	imul   0x8(%r9),%rcx
 1016fa8:	vmovq  %rcx,%xmm1
 1016fad:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 1016fb1:	mov    -0x40(%rbp),%rcx
 1016fb5:	vpaddq (%rcx),%xmm0,%xmm0
 1016fb9:	vmovdqu %xmm0,(%rcx)
 1016fbd:	add    $0x18,%rsp
 1016fc1:	pop    %rbx
 1016fc2:	pop    %r12
 1016fc4:	pop    %r13
 1016fc6:	pop    %r14
 1016fc8:	pop    %r15
 1016fca:	pop    %rbp
 1016fcb:	ret
 1016fcc:	call   101246d <myl_rc_invariant_failed>
 1016fd1:	int3
 1016fd2:	int3
 1016fd3:	int3
 1016fd4:	int3
 1016fd5:	int3
 1016fd6:	int3
 1016fd7:	int3
 1016fd8:	int3
 1016fd9:	int3
 1016fda:	int3
 1016fdb:	int3
 1016fdc:	int3
 1016fdd:	int3
 1016fde:	int3
 1016fdf:	int3

0000000001016fe0 <myl_print_raw>:
 1016fe0:	test   %rdx,%rdx
 1016fe3:	je     1016ffe <myl_print_raw+0x1e>
 1016fe5:	cmpl   $0x0,0x18(%rdi)
 1016fe9:	jne    1016ffe <myl_print_raw+0x1e>
 1016feb:	mov    0x8(%rdi),%rcx
 1016fef:	mov    %rcx,%rax
 1016ff2:	add    %rdx,%rax
 1016ff5:	jae    1016fff <myl_print_raw+0x1f>
 1016ff7:	movl   $0x1,0x18(%rdi)
 1016ffe:	ret
 1016fff:	push   %rbp
 1017000:	mov    %rsp,%rbp
 1017003:	push   %r15
 1017005:	push   %r14
 1017007:	push   %r12
 1017009:	push   %rbx
 101700a:	mov    0x10(%rdi),%rax
 101700e:	mov    %rax,%r8
 1017011:	sub    %rcx,%r8
 1017014:	cmp    %r8,%rdx
 1017017:	jbe    1017045 <myl_print_raw+0x65>
 1017019:	test   %rax,%rax
 101701c:	mov    $0x40,%ebx
 1017021:	cmovne %rax,%rbx
 1017025:	data16 cs nopw 0x0(%rax,%rax,1)
 1017030:	mov    %rbx,%rax
 1017033:	sub    %rcx,%rax
 1017036:	cmp    %rdx,%rax
 1017039:	jae    101704d <myl_print_raw+0x6d>
 101703b:	test   %rbx,%rbx
 101703e:	js     101709c <myl_print_raw+0xbc>
 1017040:	add    %rbx,%rbx
 1017043:	jmp    1017030 <myl_print_raw+0x50>
 1017045:	mov    %rdi,%r14
 1017048:	mov    (%rdi),%rax
 101704b:	jmp    1017077 <myl_print_raw+0x97>
 101704d:	mov    %rsi,%r12
 1017050:	mov    %rdx,%r15
 1017053:	mov    %rdi,%r14
 1017056:	mov    (%rdi),%rdi
 1017059:	mov    %rbx,%rsi
 101705c:	call   101ef70 <realloc@plt>
 1017061:	test   %rax,%rax
 1017064:	je     1017092 <myl_print_raw+0xb2>
 1017066:	mov    %rax,(%r14)
 1017069:	mov    %rbx,0x10(%r14)
 101706d:	mov    0x8(%r14),%rcx
 1017071:	mov    %r15,%rdx
 1017074:	mov    %r12,%rsi
 1017077:	add    %rax,%rcx
 101707a:	mov    %rcx,%rdi
 101707d:	mov    %rdx,%rbx
 1017080:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1017085:	add    %rbx,0x8(%r14)
 1017089:	pop    %rbx
 101708a:	pop    %r12
 101708c:	pop    %r14
 101708e:	pop    %r15
 1017090:	pop    %rbp
 1017091:	ret
 1017092:	movl   $0x1,0x18(%r14)
 101709a:	jmp    1017089 <myl_print_raw+0xa9>
 101709c:	movl   $0x1,0x18(%rdi)
 10170a3:	jmp    1017089 <myl_print_raw+0xa9>
 10170a5:	int3
 10170a6:	int3
 10170a7:	int3
 10170a8:	int3
 10170a9:	int3
 10170aa:	int3
 10170ab:	int3
 10170ac:	int3
 10170ad:	int3
 10170ae:	int3
 10170af:	int3

00000000010170b0 <literal>:
 10170b0:	push   %rbp
 10170b1:	mov    %rsp,%rbp
 10170b4:	push   %r15
 10170b6:	push   %r14
 10170b8:	push   %r12
 10170ba:	push   %rbx
 10170bb:	mov    %rsi,%r14
 10170be:	mov    %rdi,%rbx
 10170c1:	mov    %rsi,%rdi
 10170c4:	call   101e450 <compiler_rt.strlen>
 10170c9:	test   %rax,%rax
 10170cc:	je     1017163 <literal+0xb3>
 10170d2:	cmpl   $0x0,0x18(%rbx)
 10170d6:	jne    1017163 <literal+0xb3>
 10170dc:	mov    0x8(%rbx),%rdi
 10170e0:	mov    %rdi,%rcx
 10170e3:	add    %rax,%rcx
 10170e6:	jae    10170f1 <literal+0x41>
 10170e8:	movl   $0x1,0x18(%rbx)
 10170ef:	jmp    1017163 <literal+0xb3>
 10170f1:	mov    0x10(%rbx),%rcx
 10170f5:	mov    %rcx,%rdx
 10170f8:	sub    %rdi,%rdx
 10170fb:	cmp    %rdx,%rax
 10170fe:	jbe    1017125 <literal+0x75>
 1017100:	test   %rcx,%rcx
 1017103:	mov    $0x40,%r15d
 1017109:	cmovne %rcx,%r15
 101710d:	nopl   (%rax)
 1017110:	mov    %r15,%rcx
 1017113:	sub    %rdi,%rcx
 1017116:	cmp    %rax,%rcx
 1017119:	jae    101712a <literal+0x7a>
 101711b:	test   %r15,%r15
 101711e:	js     10170e8 <literal+0x38>
 1017120:	add    %r15,%r15
 1017123:	jmp    1017110 <literal+0x60>
 1017125:	mov    (%rbx),%rcx
 1017128:	jmp    101714e <literal+0x9e>
 101712a:	mov    %rax,%r12
 101712d:	mov    (%rbx),%rdi
 1017130:	mov    %r15,%rsi
 1017133:	call   101ef70 <realloc@plt>
 1017138:	test   %rax,%rax
 101713b:	je     10170e8 <literal+0x38>
 101713d:	mov    %rax,%rcx
 1017140:	mov    %rax,(%rbx)
 1017143:	mov    %r15,0x10(%rbx)
 1017147:	mov    0x8(%rbx),%rdi
 101714b:	mov    %r12,%rax
 101714e:	add    %rcx,%rdi
 1017151:	mov    %r14,%rsi
 1017154:	mov    %rax,%rdx
 1017157:	mov    %rax,%r14
 101715a:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101715f:	add    %r14,0x8(%rbx)
 1017163:	pop    %rbx
 1017164:	pop    %r12
 1017166:	pop    %r14
 1017168:	pop    %r15
 101716a:	pop    %rbp
 101716b:	ret
 101716c:	int3
 101716d:	int3
 101716e:	int3
 101716f:	int3

0000000001017170 <myl_print_integer>:
 1017170:	push   %rbp
 1017171:	mov    %rsp,%rbp
 1017174:	push   %r15
 1017176:	push   %r14
 1017178:	push   %rbx
 1017179:	sub    $0x28,%rsp
 101717d:	mov    %rdi,%rbx
 1017180:	cmp    $0x19,%edx
 1017183:	jae    10171eb <myl_print_integer+0x7b>
 1017185:	mov    %r8d,%r15d
 1017188:	mov    %ecx,%r14d
 101718b:	movq   $0x0,-0x20(%rbp)
 1017193:	mov    %ecx,%edx
 1017195:	lea    -0x20(%rbp),%rdi
 1017199:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101719e:	lea    0x0(,%r14,8),%eax
 10171a6:	cmp    $0x8,%r14d
 10171aa:	mov    $0xffffffffffffffff,%rsi
 10171b1:	shlx   %rax,%rsi,%rdx
 10171b6:	mov    %rdx,%rcx
 10171b9:	not    %rcx
 10171bc:	cmovae %rsi,%rcx
 10171c0:	mov    -0x20(%rbp),%rsi
 10171c4:	and    %rsi,%rcx
 10171c7:	test   %r15d,%r15d
 10171ca:	je     1017204 <myl_print_integer+0x94>
 10171cc:	cmp    $0x7,%r14d
 10171d0:	ja     10171e2 <myl_print_integer+0x72>
 10171d2:	dec    %al
 10171d4:	movzbl %al,%eax
 10171d7:	or     %rdx,%rsi
 10171da:	bt     %rax,%rcx
 10171de:	cmovb  %rsi,%rcx
 10171e2:	lea    -0x15759(%rip),%rdx        # 1001a90 <__abi_tag+0x1794>
 10171e9:	jmp    101720b <myl_print_integer+0x9b>
 10171eb:	lea    -0x15421(%rip),%rsi        # 1001dd1 <__abi_tag+0x1ad5>
 10171f2:	mov    %rbx,%rdi
 10171f5:	add    $0x28,%rsp
 10171f9:	pop    %rbx
 10171fa:	pop    %r14
 10171fc:	pop    %r15
 10171fe:	pop    %rbp
 10171ff:	jmp    10170b0 <literal>
 1017204:	lea    -0x15a76(%rip),%rdx        # 1001795 <__abi_tag+0x1499>
 101720b:	lea    -0x40(%rbp),%rdi
 101720f:	mov    $0x18,%esi
 1017214:	xor    %eax,%eax
 1017216:	call   101ee50 <snprintf@plt>
 101721b:	test   %eax,%eax
 101721d:	jle    10172b8 <myl_print_integer+0x148>
 1017223:	cmpl   $0x0,0x18(%rbx)
 1017227:	jne    10172b8 <myl_print_integer+0x148>
 101722d:	mov    %eax,%r14d
 1017230:	mov    0x8(%rbx),%rdi
 1017234:	mov    %rdi,%rax
 1017237:	add    %r14,%rax
 101723a:	jae    1017245 <myl_print_integer+0xd5>
 101723c:	movl   $0x1,0x18(%rbx)
 1017243:	jmp    10172b8 <myl_print_integer+0x148>
 1017245:	mov    0x10(%rbx),%rax
 1017249:	mov    %rax,%rcx
 101724c:	sub    %rdi,%rcx
 101724f:	cmp    %r14,%rcx
 1017252:	jae    1017285 <myl_print_integer+0x115>
 1017254:	test   %rax,%rax
 1017257:	mov    $0x40,%r15d
 101725d:	cmovne %rax,%r15
 1017261:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1017270:	mov    %r15,%rax
 1017273:	sub    %rdi,%rax
 1017276:	cmp    %r14,%rax
 1017279:	jae    101728a <myl_print_integer+0x11a>
 101727b:	test   %r15,%r15
 101727e:	js     101723c <myl_print_integer+0xcc>
 1017280:	add    %r15,%r15
 1017283:	jmp    1017270 <myl_print_integer+0x100>
 1017285:	mov    (%rbx),%rax
 1017288:	jmp    10172a5 <myl_print_integer+0x135>
 101728a:	mov    (%rbx),%rdi
 101728d:	mov    %r15,%rsi
 1017290:	call   101ef70 <realloc@plt>
 1017295:	test   %rax,%rax
 1017298:	je     101723c <myl_print_integer+0xcc>
 101729a:	mov    %rax,(%rbx)
 101729d:	mov    %r15,0x10(%rbx)
 10172a1:	mov    0x8(%rbx),%rdi
 10172a5:	add    %rax,%rdi
 10172a8:	lea    -0x40(%rbp),%rsi
 10172ac:	mov    %r14,%rdx
 10172af:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 10172b4:	add    %r14,0x8(%rbx)
 10172b8:	add    $0x28,%rsp
 10172bc:	pop    %rbx
 10172bd:	pop    %r14
 10172bf:	pop    %r15
 10172c1:	pop    %rbp
 10172c2:	ret
 10172c3:	int3
 10172c4:	int3
 10172c5:	int3
 10172c6:	int3
 10172c7:	int3
 10172c8:	int3
 10172c9:	int3
 10172ca:	int3
 10172cb:	int3
 10172cc:	int3
 10172cd:	int3
 10172ce:	int3
 10172cf:	int3

00000000010172d0 <mylang_scoped_endpoint>:
 10172d0:	push   %rbp
 10172d1:	mov    %rsp,%rbp
 10172d4:	push   %r15
 10172d6:	push   %r14
 10172d8:	push   %r13
 10172da:	push   %r12
 10172dc:	push   %rbx
 10172dd:	sub    $0x58,%rsp
 10172e1:	mov    %rsi,%r15
 10172e4:	mov    %rdi,%r13
 10172e7:	mov    %rsi,%rdi
 10172ea:	call   101e450 <compiler_rt.strlen>
 10172ef:	mov    %rax,%r14
 10172f2:	add    $0xffffffffffffefff,%rax
 10172f8:	cmp    $0xfffffffffffff000,%rax
 10172fe:	jb     101730d <mylang_scoped_endpoint+0x3d>
 1017300:	mov    0x28e8(%r13),%rbx
 1017307:	cmp    $0x7,%rbx
 101730b:	jbe    101731e <mylang_scoped_endpoint+0x4e>
 101730d:	xor    %eax,%eax
 101730f:	add    $0x58,%rsp
 1017313:	pop    %rbx
 1017314:	pop    %r12
 1017316:	pop    %r13
 1017318:	pop    %r14
 101731a:	pop    %r15
 101731c:	pop    %rbp
 101731d:	ret
 101731e:	cmp    $0x1,%r14
 1017322:	jne    1017379 <mylang_scoped_endpoint+0xa9>
 1017324:	cmpb   $0x2a,(%r15)
 1017328:	jne    1017379 <mylang_scoped_endpoint+0xa9>
 101732a:	mov    %r13,-0x30(%rbp)
 101732e:	test   %rbx,%rbx
 1017331:	je     101742c <mylang_scoped_endpoint+0x15c>
 1017337:	mov    -0x30(%rbp),%rax
 101733b:	lea    0x2870(%rax),%r12
 1017342:	mov    %rbx,%r13
 1017345:	jmp    101735d <mylang_scoped_endpoint+0x8d>
 1017347:	nopw   0x0(%rax,%rax,1)
 1017350:	add    $0x10,%r12
 1017354:	dec    %r13
 1017357:	je     101742c <mylang_scoped_endpoint+0x15c>
 101735d:	cmp    %r14,(%r12)
 1017361:	jne    1017350 <mylang_scoped_endpoint+0x80>
 1017363:	mov    -0x8(%r12),%rdi
 1017368:	mov    %r15,%rsi
 101736b:	mov    %r14,%rdx
 101736e:	call   101e470 <bcmp>
 1017373:	test   %eax,%eax
 1017375:	jne    1017350 <mylang_scoped_endpoint+0x80>
 1017377:	jmp    101730d <mylang_scoped_endpoint+0x3d>
 1017379:	mov    %r15,%rdi
 101737c:	mov    $0x3a,%esi
 1017381:	call   101eff0 <strrchr@plt>
 1017386:	test   %rax,%rax
 1017389:	je     101730d <mylang_scoped_endpoint+0x3d>
 101738b:	mov    %rax,%r12
 101738e:	sub    %r15,%r12
 1017391:	je     101730d <mylang_scoped_endpoint+0x3d>
 1017397:	cmp    $0x3f,%r12
 101739b:	ja     101730d <mylang_scoped_endpoint+0x3d>
 10173a1:	lea    -0x80(%rbp),%rdi
 10173a5:	mov    %r15,%rsi
 10173a8:	mov    %r12,%rdx
 10173ab:	mov    %r13,%rbx
 10173ae:	mov    %rax,%r13
 10173b1:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 10173b6:	movb   $0x0,-0x80(%rbp,%r12,1)
 10173bc:	inc    %r13
 10173bf:	mov    %r13,%rdi
 10173c2:	mov    %rbx,%r13
 10173c5:	xor    %esi,%esi
 10173c7:	mov    $0xa,%edx
 10173cc:	call   101f000 <strtoul@plt>
 10173d1:	lea    -0x10000(%rax),%rcx
 10173d8:	cmp    $0xffffffffffff0001,%rcx
 10173df:	jb     101730d <mylang_scoped_endpoint+0x3d>
 10173e5:	lea    -0x3c(%rbp),%rdx
 10173e9:	movl   $0x0,-0x34(%rbp)
 10173f0:	movq   $0x0,-0x3c(%rbp)
 10173f8:	movw   $0x2,-0x40(%rbp)
 10173fe:	movbe  %ax,-0x3e(%rbp)
 1017404:	lea    -0x80(%rbp),%rsi
 1017408:	mov    $0x2,%edi
 101740d:	call   101f010 <inet_pton@plt>
 1017412:	cmp    $0x1,%eax
 1017415:	mov    $0x0,%eax
 101741a:	jne    101730f <mylang_scoped_endpoint+0x3f>
 1017420:	mov    0x28e8(%r13),%rbx
 1017427:	jmp    101732a <mylang_scoped_endpoint+0x5a>
 101742c:	mov    %r14,%rdi
 101742f:	inc    %rdi
 1017432:	call   101ee60 <malloc@plt>
 1017437:	mov    %rax,%r12
 101743a:	mov    $0x0,%eax
 101743f:	test   %r12,%r12
 1017442:	mov    -0x30(%rbp),%r13
 1017446:	je     101730f <mylang_scoped_endpoint+0x3f>
 101744c:	mov    %r12,%rdi
 101744f:	mov    %r15,%rsi
 1017452:	mov    %r14,%rdx
 1017455:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101745a:	movb   $0x0,(%r12,%r14,1)
 101745f:	mov    %rbx,%rax
 1017462:	shl    $0x4,%rax
 1017466:	mov    %r12,0x2868(%r13,%rax,1)
 101746e:	mov    %r14,0x2870(%r13,%rax,1)
 1017476:	inc    %rbx
 1017479:	mov    %rbx,0x28e8(%r13)
 1017480:	mov    $0x1,%eax
 1017485:	jmp    101730f <mylang_scoped_endpoint+0x3f>
 101748a:	int3
 101748b:	int3
 101748c:	int3
 101748d:	int3
 101748e:	int3
 101748f:	int3

0000000001017490 <mylang_scoped_network_provider>:
 1017490:	push   %rbp
 1017491:	mov    %rsp,%rbp
 1017494:	mov    %rdi,%rax
 1017497:	movq   $0x0,0x8(%rdi)
 101749f:	mov    %rsi,(%rdi)
 10174a2:	mov    %edx,0x8(%rdi)
 10174a5:	lea    0x34(%rip),%rcx        # 10174e0 <acquire_network>
 10174ac:	mov    %rcx,0x10(%rdi)
 10174b0:	lea    0x269(%rip),%rcx        # 1017720 <complete>
 10174b7:	mov    %rcx,0x18(%rdi)
 10174bb:	lea    0x2ce(%rip),%rcx        # 1017790 <release>
 10174c2:	mov    %rcx,0x20(%rdi)
 10174c6:	lea    0x323(%rip),%rcx        # 10177f0 <read_handle>
 10174cd:	mov    %rcx,0x28(%rdi)
 10174d1:	lea    0x458(%rip),%rcx        # 1017930 <write_handle>
 10174d8:	mov    %rcx,0x30(%rdi)
 10174dc:	pop    %rbp
 10174dd:	ret
 10174de:	int3
 10174df:	int3

00000000010174e0 <acquire_network>:
 10174e0:	push   %rbp
 10174e1:	mov    %rsp,%rbp
 10174e4:	push   %r15
 10174e6:	push   %r14
 10174e8:	push   %r13
 10174ea:	push   %r12
 10174ec:	push   %rbx
 10174ed:	sub    $0xe8,%rsp
 10174f4:	mov    0x28e8(%rdi),%r12
 10174fb:	test   %r12,%r12
 10174fe:	je     10176cd <acquire_network+0x1ed>
 1017504:	test   $0x3,%cl
 1017507:	je     10176d4 <acquire_network+0x1f4>
 101750d:	mov    %rdx,%r13
 1017510:	mov    $0x2,%eax
 1017515:	cmp    $0x7f,%rdx
 1017519:	ja     10176d9 <acquire_network+0x1f9>
 101751f:	mov    %rdi,%r14
 1017522:	lea    -0x110(%rbp),%rdi
 1017529:	mov    %r13,%rdx
 101752c:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1017531:	movb   $0x0,-0x110(%rbp,%r13,1)
 101753a:	lea    0x2868(%r14),%r15
 1017541:	xor    %ebx,%ebx
 1017543:	jmp    101755d <acquire_network+0x7d>
 1017545:	data16 cs nopw 0x0(%rax,%rax,1)
 1017550:	add    $0x10,%r15
 1017554:	dec    %r12
 1017557:	je     10176f3 <acquire_network+0x213>
 101755d:	mov    0x8(%r15),%rax
 1017561:	cmp    $0x1,%rax
 1017565:	jne    101756f <acquire_network+0x8f>
 1017567:	mov    (%r15),%rcx
 101756a:	cmpb   $0x2a,(%rcx)
 101756d:	je     101758a <acquire_network+0xaa>
 101756f:	cmp    %r13,%rax
 1017572:	jne    1017550 <acquire_network+0x70>
 1017574:	mov    (%r15),%rdi
 1017577:	lea    -0x110(%rbp),%rsi
 101757e:	mov    %r13,%rdx
 1017581:	call   101e470 <bcmp>
 1017586:	test   %eax,%eax
 1017588:	jne    1017550 <acquire_network+0x70>
 101758a:	add    $0x68,%r14
 101758e:	xor    %ebx,%ebx
 1017590:	mov    $0x2,%eax
 1017595:	jmp    10175b5 <acquire_network+0xd5>
 1017597:	nopw   0x0(%rax,%rax,1)
 10175a0:	add    $0x2,%rbx
 10175a4:	add    $0x50,%r14
 10175a8:	cmp    $0x100,%rbx
 10175af:	je     10176d9 <acquire_network+0x1f9>
 10175b5:	cmpl   $0x0,(%r14)
 10175b9:	jns    10175c2 <acquire_network+0xe2>
 10175bb:	cmpq   $0x0,0x8(%r14)
 10175c0:	je     10175d7 <acquire_network+0xf7>
 10175c2:	cmpl   $0x0,0x28(%r14)
 10175c7:	jns    10175a0 <acquire_network+0xc0>
 10175c9:	cmpq   $0x0,0x30(%r14)
 10175ce:	jne    10175a0 <acquire_network+0xc0>
 10175d0:	inc    %rbx
 10175d3:	add    $0x28,%r14
 10175d7:	lea    -0x110(%rbp),%r12
 10175de:	mov    %r12,%rdi
 10175e1:	mov    $0x3a,%esi
 10175e6:	call   101eff0 <strrchr@plt>
 10175eb:	mov    %rax,%r15
 10175ee:	sub    %r12,%r15
 10175f1:	sete   %cl
 10175f4:	test   %rax,%rax
 10175f7:	je     10176c6 <acquire_network+0x1e6>
 10175fd:	test   %cl,%cl
 10175ff:	jne    10176c6 <acquire_network+0x1e6>
 1017605:	cmp    $0x3f,%r15
 1017609:	ja     10176c6 <acquire_network+0x1e6>
 101760f:	lea    -0x90(%rbp),%rdi
 1017616:	lea    -0x110(%rbp),%rsi
 101761d:	mov    %r15,%rdx
 1017620:	mov    %rax,%r12
 1017623:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1017628:	movb   $0x0,-0x90(%rbp,%r15,1)
 1017631:	inc    %r12
 1017634:	mov    %r12,%rdi
 1017637:	xor    %esi,%esi
 1017639:	mov    $0xa,%edx
 101763e:	call   101f000 <strtoul@plt>
 1017643:	lea    -0x10000(%rax),%rcx
 101764a:	cmp    $0xffffffffffff0001,%rcx
 1017651:	jb     10176c6 <acquire_network+0x1e6>
 1017653:	lea    -0x34(%rbp),%rdx
 1017657:	movl   $0x0,-0x2c(%rbp)
 101765e:	movq   $0x0,-0x34(%rbp)
 1017666:	movw   $0x2,-0x38(%rbp)
 101766c:	movbe  %ax,-0x36(%rbp)
 1017672:	lea    -0x90(%rbp),%rsi
 1017679:	mov    $0x2,%edi
 101767e:	call   101f010 <inet_pton@plt>
 1017683:	cmp    $0x1,%eax
 1017686:	jne    10176c6 <acquire_network+0x1e6>
 1017688:	vmovups -0x38(%rbp),%xmm0
 101768d:	vmovaps %xmm0,-0x50(%rbp)
 1017692:	mov    $0x2,%edi
 1017697:	mov    $0x1,%esi
 101769c:	xor    %edx,%edx
 101769e:	call   101f020 <socket@plt>
 10176a3:	test   %eax,%eax
 10176a5:	js     10176c6 <acquire_network+0x1e6>
 10176a7:	mov    %eax,%r15d
 10176aa:	lea    -0x50(%rbp),%rsi
 10176ae:	mov    %eax,%edi
 10176b0:	mov    $0x10,%edx
 10176b5:	call   101f030 <connect@plt>
 10176ba:	test   %eax,%eax
 10176bc:	je     10176fa <acquire_network+0x21a>
 10176be:	mov    %r15d,%edi
 10176c1:	call   101f040 <close@plt>
 10176c6:	mov    $0x3,%eax
 10176cb:	jmp    10176d9 <acquire_network+0x1f9>
 10176cd:	mov    $0x1,%eax
 10176d2:	jmp    10176d9 <acquire_network+0x1f9>
 10176d4:	mov    $0x2,%eax
 10176d9:	xor    %ebx,%ebx
 10176db:	mov    %rbx,%rdx
 10176de:	add    $0xe8,%rsp
 10176e5:	pop    %rbx
 10176e6:	pop    %r12
 10176e8:	pop    %r13
 10176ea:	pop    %r14
 10176ec:	pop    %r15
 10176ee:	pop    %rbp
 10176ef:	vzeroupper
 10176f2:	ret
 10176f3:	mov    $0x2,%eax
 10176f8:	jmp    10176db <acquire_network+0x1fb>
 10176fa:	mov    %r15d,(%r14)
 10176fd:	vxorps %xmm0,%xmm0,%xmm0
 1017701:	vmovups %ymm0,0x4(%r14)
 1017707:	movl   $0x0,0x24(%r14)
 101770f:	xor    %eax,%eax
 1017711:	jmp    10176db <acquire_network+0x1fb>
 1017713:	int3
 1017714:	int3
 1017715:	int3
 1017716:	int3
 1017717:	int3
 1017718:	int3
 1017719:	int3
 101771a:	int3
 101771b:	int3
 101771c:	int3
 101771d:	int3
 101771e:	int3
 101771f:	int3

0000000001017720 <complete>:
 1017720:	mov    $0x3,%eax
 1017725:	cmp    $0xff,%rsi
 101772c:	ja     101777f <complete+0x5f>
 101772e:	push   %rbp
 101772f:	mov    %rsp,%rbp
 1017732:	push   %rbx
 1017733:	push   %rax
 1017734:	lea    (%rsi,%rsi,4),%rcx
 1017738:	lea    (%rdi,%rcx,8),%rbx
 101773c:	add    $0x68,%rbx
 1017740:	mov    0x68(%rdi,%rcx,8),%edi
 1017744:	test   %edi,%edi
 1017746:	js     1017753 <complete+0x33>
 1017748:	call   101f040 <close@plt>
 101774d:	mov    0x8(%rbx),%rdi
 1017751:	jmp    101775c <complete+0x3c>
 1017753:	mov    0x8(%rbx),%rdi
 1017757:	test   %rdi,%rdi
 101775a:	je     1017779 <complete+0x59>
 101775c:	call   101edc0 <free@plt>
 1017761:	movl   $0xffffffff,(%rbx)
 1017767:	vxorps %xmm0,%xmm0,%xmm0
 101776b:	vmovups %ymm0,0x4(%rbx)
 1017770:	movl   $0x0,0x24(%rbx)
 1017777:	xor    %eax,%eax
 1017779:	add    $0x8,%rsp
 101777d:	pop    %rbx
 101777e:	pop    %rbp
 101777f:	vzeroupper
 1017782:	ret
 1017783:	int3
 1017784:	int3
 1017785:	int3
 1017786:	int3
 1017787:	int3
 1017788:	int3
 1017789:	int3
 101778a:	int3
 101778b:	int3
 101778c:	int3
 101778d:	int3
 101778e:	int3
 101778f:	int3

0000000001017790 <release>:
 1017790:	push   %rbp
 1017791:	mov    %rsp,%rbp
 1017794:	push   %rbx
 1017795:	push   %rax
 1017796:	cmp    $0xff,%rsi
 101779d:	ja     10177e2 <release+0x52>
 101779f:	lea    (%rsi,%rsi,4),%rax
 10177a3:	lea    (%rdi,%rax,8),%rbx
 10177a7:	add    $0x68,%rbx
 10177ab:	mov    0x68(%rdi,%rax,8),%edi
 10177af:	test   %edi,%edi
 10177b1:	js     10177be <release+0x2e>
 10177b3:	call   101f040 <close@plt>
 10177b8:	mov    0x8(%rbx),%rdi
 10177bc:	jmp    10177c7 <release+0x37>
 10177be:	mov    0x8(%rbx),%rdi
 10177c2:	test   %rdi,%rdi
 10177c5:	je     10177e2 <release+0x52>
 10177c7:	call   101edc0 <free@plt>
 10177cc:	movl   $0xffffffff,(%rbx)
 10177d2:	vxorps %xmm0,%xmm0,%xmm0
 10177d6:	vmovups %ymm0,0x4(%rbx)
 10177db:	movl   $0x0,0x24(%rbx)
 10177e2:	add    $0x8,%rsp
 10177e6:	pop    %rbx
 10177e7:	pop    %rbp
 10177e8:	vzeroupper
 10177eb:	ret
 10177ec:	int3
 10177ed:	int3
 10177ee:	int3
 10177ef:	int3

00000000010177f0 <read_handle>:
 10177f0:	mov    %rdi,%rax
 10177f3:	vmovups -0x146d3(%rip),%xmm0        # 1003128 <myl_rc_map_sentinel+0x88>
 10177fb:	vmovups %xmm0,(%rdi)
 10177ff:	movq   $0x0,0x10(%rdi)
 1017807:	cmp    $0xff,%rdx
 101780e:	ja     101791c <read_handle+0x12c>
 1017814:	push   %rbp
 1017815:	mov    %rsp,%rbp
 1017818:	push   %r15
 101781a:	push   %r14
 101781c:	push   %rbx
 101781d:	push   %rax
 101781e:	lea    (%rdx,%rdx,4),%rdx
 1017822:	lea    (%rsi,%rdx,8),%r15
 1017826:	add    $0x68,%r15
 101782a:	mov    0x68(%rsi,%rdx,8),%edi
 101782e:	test   %edi,%edi
 1017830:	jns    101783d <read_handle+0x4d>
 1017832:	cmpq   $0x0,0x8(%r15)
 1017837:	je     1017912 <read_handle+0x122>
 101783d:	test   %r8,%r8
 1017840:	je     10178a6 <read_handle+0xb6>
 1017842:	mov    %rax,%r14
 1017845:	cmp    $0x10000,%r8
 101784c:	mov    $0x10000,%edx
 1017851:	cmovb  %r8,%rdx
 1017855:	mov    0x8(%r15),%rsi
 1017859:	test   %rsi,%rsi
 101785c:	je     10178ae <read_handle+0xbe>
 101785e:	mov    0x10(%r15),%rbx
 1017862:	mov    0x18(%r15),%rax
 1017866:	sub    %rax,%rbx
 1017869:	cmp    %rdx,%rbx
 101786c:	cmovae %rdx,%rbx
 1017870:	add    %rax,%rsi
 1017873:	mov    %rcx,%rdi
 1017876:	mov    %rbx,%rdx
 1017879:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101787e:	mov    0x18(%r15),%rcx
 1017882:	add    %rbx,%rcx
 1017885:	mov    %rcx,0x18(%r15)
 1017889:	mov    %r14,%rax
 101788c:	movl   $0x0,(%r14)
 1017893:	mov    %rbx,0x8(%r14)
 1017897:	xor    %edx,%edx
 1017899:	cmp    0x10(%r15),%rcx
 101789d:	sete   %dl
 10178a0:	mov    %edx,0x10(%r14)
 10178a4:	jmp    1017912 <read_handle+0x122>
 10178a6:	movl   $0x0,(%rax)
 10178ac:	jmp    1017912 <read_handle+0x122>
 10178ae:	cmpb   $0x61,0x20(%r15)
 10178b3:	jne    10178c1 <read_handle+0xd1>
 10178b5:	mov    %r14,%rax
 10178b8:	movl   $0x2,(%r14)
 10178bf:	jmp    1017912 <read_handle+0x122>
 10178c1:	mov    %rcx,%rsi
 10178c4:	call   101f050 <read@plt>
 10178c9:	test   %rax,%rax
 10178cc:	js     10178eb <read_handle+0xfb>
 10178ce:	mov    %rax,%rcx
 10178d1:	mov    %r14,%rax
 10178d4:	movl   $0x0,(%r14)
 10178db:	mov    %rcx,0x8(%r14)
 10178df:	sete   %cl
 10178e2:	movzbl %cl,%ecx
 10178e5:	mov    %ecx,0x10(%r14)
 10178e9:	jmp    1017912 <read_handle+0x122>
 10178eb:	call   101f060 <__errno_location@plt>
 10178f0:	mov    (%rax),%edx
 10178f2:	cmp    $0x28,%rdx
 10178f6:	mov    %r14,%rax
 10178f9:	ja     1017928 <read_handle+0x138>
 10178fb:	movabs $0x10000102002,%rcx
 1017905:	bt     %rdx,%rcx
 1017909:	jae    101791d <read_handle+0x12d>
 101790b:	mov    $0x2,%ecx
 1017910:	mov    %ecx,(%rax)
 1017912:	add    $0x8,%rsp
 1017916:	pop    %rbx
 1017917:	pop    %r14
 1017919:	pop    %r15
 101791b:	pop    %rbp
 101791c:	ret
 101791d:	mov    $0x4,%ecx
 1017922:	cmp    $0xc,%rdx
 1017926:	je     1017910 <read_handle+0x120>
 1017928:	mov    $0x3,%ecx
 101792d:	jmp    1017910 <read_handle+0x120>
 101792f:	int3

0000000001017930 <write_handle>:
 1017930:	mov    $0x3,%eax
 1017935:	cmp    $0xff,%rsi
 101793c:	jbe    1017941 <write_handle+0x11>
 101793e:	xor    %edx,%edx
 1017940:	ret
 1017941:	mov    %rdi,%r8
 1017944:	lea    (%rsi,%rsi,4),%rax
 1017948:	mov    0x68(%rdi,%rax,8),%edi
 101794c:	mov    0x70(%r8,%rax,8),%rsi
 1017951:	test   %edi,%edi
 1017953:	js     1017962 <write_handle+0x32>
 1017955:	test   %rsi,%rsi
 1017958:	je     1017971 <write_handle+0x41>
 101795a:	xor    %edx,%edx
 101795c:	mov    $0x2,%eax
 1017961:	ret
 1017962:	xor    %edx,%edx
 1017964:	cmp    $0x1,%rsi
 1017968:	mov    $0x0,%eax
 101796d:	adc    $0x2,%eax
 1017970:	ret
 1017971:	push   %rbp
 1017972:	mov    %rsp,%rbp
 1017975:	push   %r15
 1017977:	push   %r14
 1017979:	push   %rbx
 101797a:	push   %rax
 101797b:	lea    (%r8,%rax,8),%r15
 101797f:	add    $0x68,%r15
 1017983:	cmp    $0x10000,%rcx
 101798a:	mov    $0x10000,%ebx
 101798f:	cmovb  %rcx,%rbx
 1017993:	cmpb   $0x61,0x20(%r15)
 1017998:	jne    10179c1 <write_handle+0x91>
 101799a:	mov    %rdx,%r14
 101799d:	xor    %esi,%esi
 101799f:	mov    $0x2,%edx
 10179a4:	call   101f070 <lseek@plt>
 10179a9:	test   %rax,%rax
 10179ac:	js     10179fc <write_handle+0xcc>
 10179ae:	mov    (%r15),%edi
 10179b1:	mov    %r14,%rsi
 10179b4:	mov    %rbx,%rdx
 10179b7:	mov    %rax,%rcx
 10179ba:	call   101f080 <pwrite@plt>
 10179bf:	jmp    10179cc <write_handle+0x9c>
 10179c1:	mov    %rdx,%rsi
 10179c4:	mov    %rbx,%rdx
 10179c7:	call   101eeb0 <write@plt>
 10179cc:	mov    %rax,%rdx
 10179cf:	xor    %eax,%eax
 10179d1:	test   %rdx,%rdx
 10179d4:	jns    1017a36 <write_handle+0x106>
 10179d6:	call   101f060 <__errno_location@plt>
 10179db:	mov    (%rax),%eax
 10179dd:	cmp    $0x28,%rax
 10179e1:	ja     1017a2f <write_handle+0xff>
 10179e3:	movabs $0x10000102002,%rcx
 10179ed:	bt     %rax,%rcx
 10179f1:	jae    1017a20 <write_handle+0xf0>
 10179f3:	xor    %edx,%edx
 10179f5:	mov    $0x2,%eax
 10179fa:	jmp    1017a36 <write_handle+0x106>
 10179fc:	call   101f060 <__errno_location@plt>
 1017a01:	mov    (%rax),%eax
 1017a03:	cmp    $0x28,%rax
 1017a07:	ja     1017a2f <write_handle+0xff>
 1017a09:	movabs $0x10000102002,%rcx
 1017a13:	bt     %rax,%rcx
 1017a17:	jae    1017a20 <write_handle+0xf0>
 1017a19:	mov    $0x2,%eax
 1017a1e:	jmp    1017a2b <write_handle+0xfb>
 1017a20:	cmp    $0xc,%rax
 1017a24:	jne    1017a2f <write_handle+0xff>
 1017a26:	mov    $0x4,%eax
 1017a2b:	xor    %edx,%edx
 1017a2d:	jmp    1017a36 <write_handle+0x106>
 1017a2f:	xor    %edx,%edx
 1017a31:	mov    $0x3,%eax
 1017a36:	add    $0x8,%rsp
 1017a3a:	pop    %rbx
 1017a3b:	pop    %r14
 1017a3d:	pop    %r15
 1017a3f:	pop    %rbp
 1017a40:	ret
 1017a41:	int3
 1017a42:	int3
 1017a43:	int3
 1017a44:	int3
 1017a45:	int3
 1017a46:	int3
 1017a47:	int3
 1017a48:	int3
 1017a49:	int3
 1017a4a:	int3
 1017a4b:	int3
 1017a4c:	int3
 1017a4d:	int3
 1017a4e:	int3
 1017a4f:	int3

0000000001017a50 <mylang_scoped_init>:
 1017a50:	push   %rbp
 1017a51:	mov    %rsp,%rbp
 1017a54:	push   %rbx
 1017a55:	push   %rax
 1017a56:	mov    %rdi,%rbx
 1017a59:	mov    $0x28f0,%edx
 1017a5e:	xor    %esi,%esi
 1017a60:	call   101e4a0 <compiler_rt.fastMemset>
 1017a65:	mov    $0xe0,%eax
 1017a6a:	nopw   0x0(%rax,%rax,1)
 1017a70:	movl   $0xffffffff,-0x78(%rbx,%rax,1)
 1017a78:	movl   $0xffffffff,-0x50(%rbx,%rax,1)
 1017a80:	movl   $0xffffffff,-0x28(%rbx,%rax,1)
 1017a88:	movl   $0xffffffff,(%rbx,%rax,1)
 1017a8f:	add    $0xa0,%rax
 1017a95:	cmp    $0x28e0,%rax
 1017a9b:	jne    1017a70 <mylang_scoped_init+0x20>
 1017a9d:	add    $0x8,%rsp
 1017aa1:	pop    %rbx
 1017aa2:	pop    %rbp
 1017aa3:	ret
 1017aa4:	int3
 1017aa5:	int3
 1017aa6:	int3
 1017aa7:	int3
 1017aa8:	int3
 1017aa9:	int3
 1017aaa:	int3
 1017aab:	int3
 1017aac:	int3
 1017aad:	int3
 1017aae:	int3
 1017aaf:	int3

0000000001017ab0 <mylang_scoped_grant>:
 1017ab0:	push   %rbp
 1017ab1:	mov    %rsp,%rbp
 1017ab4:	push   %r15
 1017ab6:	push   %r14
 1017ab8:	push   %rbx
 1017ab9:	push   %rax
 1017aba:	xor    %r15d,%r15d
 1017abd:	cmpq   $0x7,0x60(%rdi)
 1017ac2:	ja     1017b07 <mylang_scoped_grant+0x57>
 1017ac4:	mov    %edx,%ebx
 1017ac6:	mov    %rdi,%r14
 1017ac9:	xor    %r15d,%r15d
 1017acc:	mov    %rsi,%rdi
 1017acf:	mov    $0x90000,%esi
 1017ad4:	xor    %eax,%eax
 1017ad6:	call   101f090 <open@plt>
 1017adb:	test   %eax,%eax
 1017add:	js     1017b07 <mylang_scoped_grant+0x57>
 1017adf:	mov    0x60(%r14),%rcx
 1017ae3:	lea    0x1(%rcx),%rdx
 1017ae7:	mov    %rdx,0x60(%r14)
 1017aeb:	lea    (%rcx,%rcx,2),%rcx
 1017aef:	mov    %eax,(%r14,%rcx,4)
 1017af3:	mov    %ebx,0x4(%r14,%rcx,4)
 1017af8:	movl   $0x0,0x8(%r14,%rcx,4)
 1017b01:	mov    $0x1,%r15d
 1017b07:	mov    %r15d,%eax
 1017b0a:	add    $0x8,%rsp
 1017b0e:	pop    %rbx
 1017b0f:	pop    %r14
 1017b11:	pop    %r15
 1017b13:	pop    %rbp
 1017b14:	ret
 1017b15:	int3
 1017b16:	int3
 1017b17:	int3
 1017b18:	int3
 1017b19:	int3
 1017b1a:	int3
 1017b1b:	int3
 1017b1c:	int3
 1017b1d:	int3
 1017b1e:	int3
 1017b1f:	int3

0000000001017b20 <mylang_scoped_working_directory>:
 1017b20:	push   %rbp
 1017b21:	mov    %rsp,%rbp
 1017b24:	push   %r14
 1017b26:	push   %rbx
 1017b27:	xor    %r14d,%r14d
 1017b2a:	cmpq   $0x7,0x60(%rdi)
 1017b2f:	ja     1017b76 <mylang_scoped_working_directory+0x56>
 1017b31:	mov    %rdi,%rbx
 1017b34:	lea    -0x15d68(%rip),%rdi        # 1001dd3 <__abi_tag+0x1ad7>
 1017b3b:	xor    %r14d,%r14d
 1017b3e:	mov    $0x90000,%esi
 1017b43:	xor    %eax,%eax
 1017b45:	call   101f090 <open@plt>
 1017b4a:	test   %eax,%eax
 1017b4c:	js     1017b76 <mylang_scoped_working_directory+0x56>
 1017b4e:	mov    0x60(%rbx),%rcx
 1017b52:	lea    0x1(%rcx),%rdx
 1017b56:	mov    %rdx,0x60(%rbx)
 1017b5a:	lea    (%rcx,%rcx,2),%rcx
 1017b5e:	mov    %eax,(%rbx,%rcx,4)
 1017b61:	movabs $0x100000001,%rax
 1017b6b:	mov    %rax,0x4(%rbx,%rcx,4)
 1017b70:	mov    $0x1,%r14d
 1017b76:	mov    %r14d,%eax
 1017b79:	pop    %rbx
 1017b7a:	pop    %r14
 1017b7c:	pop    %rbp
 1017b7d:	ret
 1017b7e:	int3
 1017b7f:	int3

0000000001017b80 <mylang_scoped_close>:
 1017b80:	push   %rbp
 1017b81:	mov    %rsp,%rbp
 1017b84:	push   %r15
 1017b86:	push   %r14
 1017b88:	push   %rbx
 1017b89:	push   %rax
 1017b8a:	mov    %rdi,%rbx
 1017b8d:	mov    $0x70,%r14d
 1017b93:	jmp    1017bde <mylang_scoped_close+0x5e>
 1017b95:	data16 cs nopw 0x0(%rax,%rax,1)
 1017ba0:	vzeroupper
 1017ba3:	call   101f040 <close@plt>
 1017ba8:	mov    (%rbx,%r14,1),%rdi
 1017bac:	vzeroupper
 1017baf:	call   101edc0 <free@plt>
 1017bb4:	movl   $0xffffffff,-0x8(%rbx,%r14,1)
 1017bbd:	vxorps %xmm0,%xmm0,%xmm0
 1017bc1:	vmovups %ymm0,-0x4(%rbx,%r14,1)
 1017bc8:	movl   $0x0,0x1c(%rbx,%r14,1)
 1017bd1:	add    $0x28,%r14
 1017bd5:	cmp    $0x2870,%r14
 1017bdc:	je     1017bf2 <mylang_scoped_close+0x72>
 1017bde:	mov    -0x8(%rbx,%r14,1),%edi
 1017be3:	test   %edi,%edi
 1017be5:	jns    1017ba0 <mylang_scoped_close+0x20>
 1017be7:	mov    (%rbx,%r14,1),%rdi
 1017beb:	test   %rdi,%rdi
 1017bee:	jne    1017bac <mylang_scoped_close+0x2c>
 1017bf0:	jmp    1017bd1 <mylang_scoped_close+0x51>
 1017bf2:	cmpq   $0x0,0x60(%rbx)
 1017bf7:	je     1017c18 <mylang_scoped_close+0x98>
 1017bf9:	xor    %r14d,%r14d
 1017bfc:	mov    %rbx,%r15
 1017bff:	nop
 1017c00:	mov    (%r15),%edi
 1017c03:	vzeroupper
 1017c06:	call   101f040 <close@plt>
 1017c0b:	inc    %r14
 1017c0e:	add    $0xc,%r15
 1017c12:	cmp    0x60(%rbx),%r14
 1017c16:	jb     1017c00 <mylang_scoped_close+0x80>
 1017c18:	movq   $0x0,0x60(%rbx)
 1017c20:	cmpq   $0x0,0x28e8(%rbx)
 1017c28:	je     1017c5b <mylang_scoped_close+0xdb>
 1017c2a:	lea    0x2868(%rbx),%r14
 1017c31:	xor    %r15d,%r15d
 1017c34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1017c40:	mov    (%r14),%rdi
 1017c43:	vzeroupper
 1017c46:	call   101edc0 <free@plt>
 1017c4b:	inc    %r15
 1017c4e:	add    $0x10,%r14
 1017c52:	cmp    0x28e8(%rbx),%r15
 1017c59:	jb     1017c40 <mylang_scoped_close+0xc0>
 1017c5b:	movq   $0x0,0x28e8(%rbx)
 1017c66:	add    $0x8,%rsp
 1017c6a:	pop    %rbx
 1017c6b:	pop    %r14
 1017c6d:	pop    %r15
 1017c6f:	pop    %rbp
 1017c70:	vzeroupper
 1017c73:	ret
 1017c74:	int3
 1017c75:	int3
 1017c76:	int3
 1017c77:	int3
 1017c78:	int3
 1017c79:	int3
 1017c7a:	int3
 1017c7b:	int3
 1017c7c:	int3
 1017c7d:	int3
 1017c7e:	int3
 1017c7f:	int3

0000000001017c80 <mylang_scoped_provider>:
 1017c80:	push   %rbp
 1017c81:	mov    %rsp,%rbp
 1017c84:	mov    %rdi,%rax
 1017c87:	movq   $0x0,0x8(%rdi)
 1017c8f:	mov    %rsi,(%rdi)
 1017c92:	mov    %edx,0x8(%rdi)
 1017c95:	lea    0x34(%rip),%rcx        # 1017cd0 <acquire>
 1017c9c:	mov    %rcx,0x10(%rdi)
 1017ca0:	lea    -0x587(%rip),%rcx        # 1017720 <complete>
 1017ca7:	mov    %rcx,0x18(%rdi)
 1017cab:	lea    -0x522(%rip),%rcx        # 1017790 <release>
 1017cb2:	mov    %rcx,0x20(%rdi)
 1017cb6:	lea    -0x4cd(%rip),%rcx        # 10177f0 <read_handle>
 1017cbd:	mov    %rcx,0x28(%rdi)
 1017cc1:	lea    -0x398(%rip),%rcx        # 1017930 <write_handle>
 1017cc8:	mov    %rcx,0x30(%rdi)
 1017ccc:	pop    %rbp
 1017ccd:	ret
 1017cce:	int3
 1017ccf:	int3

0000000001017cd0 <acquire>:
 1017cd0:	push   %rbp
 1017cd1:	mov    %rsp,%rbp
 1017cd4:	push   %r15
 1017cd6:	push   %r14
 1017cd8:	push   %r13
 1017cda:	push   %r12
 1017cdc:	push   %rbx
 1017cdd:	sub    $0x1138,%rsp
 1017ce4:	cmpq   $0x0,0x60(%rdi)
 1017ce9:	je     1017d3c <acquire+0x6c>
 1017ceb:	mov    %rdx,%r8
 1017cee:	lea    -0x1001(%rdx),%rax
 1017cf5:	mov    $0x2,%r9d
 1017cfb:	cmp    $0xfffffffffffff001,%rax
 1017d01:	jb     1017d42 <acquire+0x72>
 1017d03:	mov    %rsi,%r13
 1017d06:	cmpb   $0x3a,0x1(%rsi)
 1017d0a:	jne    1017d42 <acquire+0x72>
 1017d0c:	movzbl 0x0(%r13),%eax
 1017d11:	mov    %al,-0x2d(%rbp)
 1017d14:	movzbl %al,%eax
 1017d17:	xor    %ebx,%ebx
 1017d19:	lea    -0x61(%rax),%r12d
 1017d1d:	cmp    $0x17,%r12d
 1017d21:	ja     1017d44 <acquire+0x74>
 1017d23:	mov    %rax,-0xa8(%rbp)
 1017d2a:	mov    $0xc80405,%eax
 1017d2f:	bt     %r12d,%eax
 1017d33:	jae    1017d5c <acquire+0x8c>
 1017d35:	mov    $0x2,%eax
 1017d3a:	jmp    1017d6c <acquire+0x9c>
 1017d3c:	mov    $0x1,%r9d
 1017d42:	xor    %ebx,%ebx
 1017d44:	mov    %r9d,%eax
 1017d47:	mov    %rbx,%rdx
 1017d4a:	add    $0x1138,%rsp
 1017d51:	pop    %rbx
 1017d52:	pop    %r12
 1017d54:	pop    %r13
 1017d56:	pop    %r14
 1017d58:	pop    %r15
 1017d5a:	pop    %rbp
 1017d5b:	ret
 1017d5c:	mov    $0x1,%eax
 1017d61:	mov    $0x21800,%edx
 1017d66:	bt     %r12d,%edx
 1017d6a:	jae    1017d44 <acquire+0x74>
 1017d6c:	test   %ecx,%eax
 1017d6e:	je     1017d42 <acquire+0x72>
 1017d70:	add    $0x2,%r13
 1017d74:	lea    -0x2(%r8),%rdx
 1017d78:	mov    -0xa8(%rbp),%rax
 1017d7f:	mov    %eax,%ecx
 1017d81:	and    $0xfe,%cl
 1017d84:	mov    %cl,-0x51(%rbp)
 1017d87:	lea    0x68(%rdi),%rcx
 1017d8b:	mov    %rcx,-0xc8(%rbp)
 1017d92:	xor    %ecx,%ecx
 1017d94:	cmp    $0x72,%al
 1017d96:	setne  %cl
 1017d99:	mov    %ecx,-0x7c(%rbp)
 1017d9c:	dec    %r8
 1017d9f:	add    $0xffffff95,%eax
 1017da2:	mov    %rax,-0xc0(%rbp)
 1017da9:	mov    $0xc80405,%r15d
 1017daf:	xor    %ecx,%ecx
 1017db1:	mov    %r13,-0x70(%rbp)
 1017db5:	mov    %rdx,-0x38(%rbp)
 1017db9:	mov    %r8,-0x40(%rbp)
 1017dbd:	mov    %rdi,-0x68(%rbp)
 1017dc1:	mov    %r12d,-0x44(%rbp)
 1017dc5:	jmp    1017dee <acquire+0x11e>
 1017dc7:	nopw   0x0(%rax,%rax,1)
 1017dd0:	mov    $0x2,%r9d
 1017dd6:	mov    -0x44(%rbp),%r12d
 1017dda:	mov    -0xd0(%rbp),%rcx
 1017de1:	inc    %rcx
 1017de4:	cmp    0x60(%rdi),%rcx
 1017de8:	jae    1017d42 <acquire+0x72>
 1017dee:	cmp    $0x17,%r12d
 1017df2:	mov    %rcx,-0xd0(%rbp)
 1017df9:	ja     1017e0c <acquire+0x13c>
 1017dfb:	bt     %r12d,%r15d
 1017dff:	jae    1017e0c <acquire+0x13c>
 1017e01:	lea    (%rcx,%rcx,2),%rax
 1017e05:	cmpl   $0x0,0x4(%rdi,%rax,4)
 1017e0a:	je     1017dda <acquire+0x10a>
 1017e0c:	lea    (%rcx,%rcx,2),%rbx
 1017e10:	mov    0x8(%rdi,%rbx,4),%r10d
 1017e15:	test   %r10d,%r10d
 1017e18:	je     1017f40 <acquire+0x270>
 1017e1e:	lea    (%rdi,%rbx,4),%rax
 1017e22:	mov    (%rax),%eax
 1017e24:	mov    %eax,-0x48(%rbp)
 1017e27:	mov    -0xc8(%rbp),%r12
 1017e2e:	xor    %ebx,%ebx
 1017e30:	jmp    1017e55 <acquire+0x185>
 1017e32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1017e40:	add    $0x2,%rbx
 1017e44:	add    $0x50,%r12
 1017e48:	cmp    $0x100,%rbx
 1017e4f:	je     1017dd0 <acquire+0x100>
 1017e55:	cmpl   $0x0,(%r12)
 1017e5a:	jns    1017e64 <acquire+0x194>
 1017e5c:	cmpq   $0x0,0x8(%r12)
 1017e62:	je     1017e7b <acquire+0x1ab>
 1017e64:	cmpl   $0x0,0x28(%r12)
 1017e6a:	jns    1017e40 <acquire+0x170>
 1017e6c:	cmpq   $0x0,0x30(%r12)
 1017e72:	jne    1017e40 <acquire+0x170>
 1017e74:	inc    %rbx
 1017e77:	add    $0x28,%r12
 1017e7b:	mov    %r10d,-0x60(%rbp)
 1017e7f:	test   %rdx,%rdx
 1017e82:	je     1017fa9 <acquire+0x2d9>
 1017e88:	mov    $0x0,%r14d
 1017e8e:	mov    -0x48(%rbp),%eax
 1017e91:	mov    %eax,-0x2c(%rbp)
 1017e94:	cmpl   $0x0,-0x60(%rbp)
 1017e98:	jne    1017fb2 <acquire+0x2e2>
 1017e9e:	xor    %r15d,%r15d
 1017ea1:	mov    -0x48(%rbp),%eax
 1017ea4:	mov    %eax,-0x2c(%rbp)
 1017ea7:	xor    %r14d,%r14d
 1017eaa:	jmp    1017ed5 <acquire+0x205>
 1017eac:	nopl   0x0(%rax)
 1017eb0:	test   %r13d,%r13d
 1017eb3:	js     10180c3 <acquire+0x3f3>
 1017eb9:	lea    0x1(%r15),%r14
 1017ebd:	mov    %r13d,-0x2c(%rbp)
 1017ec1:	mov    -0x70(%rbp),%r13
 1017ec5:	mov    -0x38(%rbp),%rdx
 1017ec9:	inc    %r15
 1017ecc:	cmp    %r15,%rdx
 1017ecf:	je     1017fb2 <acquire+0x2e2>
 1017ed5:	cmpb   $0x2f,0x0(%r13,%r15,1)
 1017edb:	jne    1017ec9 <acquire+0x1f9>
 1017edd:	mov    %r15,%rdx
 1017ee0:	sub    %r14,%rdx
 1017ee3:	cmp    $0xffe,%rdx
 1017eea:	ja     10180a9 <acquire+0x3d9>
 1017ef0:	lea    (%r14,%r13,1),%rsi
 1017ef4:	lea    -0x1160(%rbp),%r13
 1017efb:	mov    %r13,%rdi
 1017efe:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1017f03:	mov    %r13,%rax
 1017f06:	sub    %r14,%rax
 1017f09:	movb   $0x0,(%rax,%r15,1)
 1017f0e:	mov    -0x2c(%rbp),%r14d
 1017f12:	mov    %r14d,%edi
 1017f15:	mov    %r13,%rsi
 1017f18:	mov    $0xb0000,%edx
 1017f1d:	xor    %eax,%eax
 1017f1f:	call   101f0a0 <openat@plt>
 1017f24:	mov    %eax,%r13d
 1017f27:	cmp    -0x48(%rbp),%r14d
 1017f2b:	je     1017eb0 <acquire+0x1e0>
 1017f2d:	mov    %r14d,%edi
 1017f30:	call   101f040 <close@plt>
 1017f35:	jmp    1017eb0 <acquire+0x1e0>
 1017f3a:	nopw   0x0(%rax,%rax,1)
 1017f40:	test   %rdx,%rdx
 1017f43:	je     1017f6a <acquire+0x29a>
 1017f45:	mov    %r10d,-0x60(%rbp)
 1017f49:	mov    %r9d,-0x50(%rbp)
 1017f4d:	mov    %r8,%r14
 1017f50:	mov    %r13,%rdi
 1017f53:	mov    $0x5c,%esi
 1017f58:	mov    %rdx,%r15
 1017f5b:	call   101ef80 <memchr@plt>
 1017f60:	test   %rax,%rax
 1017f63:	je     1017f79 <acquire+0x2a9>
 1017f65:	mov    %r15,%rdx
 1017f68:	jmp    1017f93 <acquire+0x2c3>
 1017f6a:	cmpb   $0x6c,-0x51(%rbp)
 1017f6e:	jne    1017dda <acquire+0x10a>
 1017f74:	jmp    1017e1e <acquire+0x14e>
 1017f79:	mov    %r13,%rdi
 1017f7c:	xor    %esi,%esi
 1017f7e:	mov    %r15,%rdx
 1017f81:	call   101ef80 <memchr@plt>
 1017f86:	test   %rax,%rax
 1017f89:	je     1018119 <acquire+0x449>
 1017f8f:	mov    -0x38(%rbp),%rdx
 1017f93:	mov    $0xc80405,%r15d
 1017f99:	mov    %r14,%r8
 1017f9c:	mov    -0x68(%rbp),%rdi
 1017fa0:	mov    -0x50(%rbp),%r9d
 1017fa4:	jmp    1017dda <acquire+0x10a>
 1017fa9:	xor    %r14d,%r14d
 1017fac:	mov    -0x48(%rbp),%eax
 1017faf:	mov    %eax,-0x2c(%rbp)
 1017fb2:	cmpl   $0x0,-0x2c(%rbp)
 1017fb6:	js     10180c7 <acquire+0x3f7>
 1017fbc:	mov    %rdx,%r13
 1017fbf:	sub    %r14,%r13
 1017fc2:	cmp    $0xfff,%r13
 1017fc9:	mov    -0x40(%rbp),%r8
 1017fcd:	mov    $0xc80405,%r15d
 1017fd3:	jb     101800c <acquire+0x33c>
 1017fd5:	mov    $0x2,%r9d
 1017fdb:	mov    -0x2c(%rbp),%edi
 1017fde:	cmp    -0x48(%rbp),%edi
 1017fe1:	mov    -0x68(%rbp),%r14
 1017fe5:	mov    -0x44(%rbp),%r12d
 1017fe9:	je     1018000 <acquire+0x330>
 1017feb:	mov    %r8,%rbx
 1017fee:	call   101f040 <close@plt>
 1017ff3:	mov    $0x2,%r9d
 1017ff9:	mov    %rbx,%r8
 1017ffc:	mov    -0x38(%rbp),%rdx
 1018000:	mov    -0x70(%rbp),%r13
 1018004:	mov    %r14,%rdi
 1018007:	jmp    1017dda <acquire+0x10a>
 101800c:	add    -0x70(%rbp),%r14
 1018010:	lea    -0x1160(%rbp),%rdi
 1018017:	mov    %r14,%rsi
 101801a:	mov    %r13,%rdx
 101801d:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1018022:	movb   $0x0,-0x1160(%rbp,%r13,1)
 101802b:	mov    -0xc0(%rbp),%rax
 1018032:	cmp    $0xd,%eax
 1018035:	ja     101848c <acquire+0x7bc>
 101803b:	lea    -0x14f56(%rip),%rcx        # 10030ec <myl_rc_map_sentinel+0x4c>
 1018042:	movslq (%rcx,%rax,4),%rax
 1018046:	add    %rcx,%rax
 1018049:	jmp    *%rax
 101804b:	movzbl -0x1160(%rbp),%eax
 1018052:	cmpb   $0x6d,-0x2d(%rbp)
 1018056:	mov    -0x2c(%rbp),%r14d
 101805a:	jne    10181a5 <acquire+0x4d5>
 1018060:	mov    %r14d,%edi
 1018063:	test   %al,%al
 1018065:	je     10184da <acquire+0x80a>
 101806b:	lea    -0x1160(%rbp),%rsi
 1018072:	lea    -0x160(%rbp),%rdx
 1018079:	mov    $0x100,%ecx
 101807e:	call   101f0b0 <fstatat@plt>
 1018083:	test   %eax,%eax
 1018085:	je     10184ee <acquire+0x81e>
 101808b:	call   101f060 <__errno_location@plt>
 1018090:	mov    (%rax),%eax
 1018092:	cmp    $0x28,%rax
 1018096:	mov    -0x38(%rbp),%rdx
 101809a:	mov    -0x40(%rbp),%r8
 101809e:	jbe    101862d <acquire+0x95d>
 10180a4:	jmp    101899c <acquire+0xccc>
 10180a9:	call   101f060 <__errno_location@plt>
 10180ae:	movl   $0x24,(%rax)
 10180b4:	mov    -0x2c(%rbp),%edi
 10180b7:	cmp    -0x48(%rbp),%edi
 10180ba:	je     10180c7 <acquire+0x3f7>
 10180bc:	call   101f040 <close@plt>
 10180c1:	jmp    10180c7 <acquire+0x3f7>
 10180c3:	mov    -0x70(%rbp),%r13
 10180c7:	call   101f060 <__errno_location@plt>
 10180cc:	mov    -0x38(%rbp),%rdx
 10180d0:	mov    (%rax),%eax
 10180d2:	cmp    $0x28,%rax
 10180d6:	mov    -0x40(%rbp),%r8
 10180da:	mov    -0x68(%rbp),%rdi
 10180de:	mov    -0x44(%rbp),%r12d
 10180e2:	mov    $0xc80405,%r15d
 10180e8:	ja     101810e <acquire+0x43e>
 10180ea:	mov    $0x2,%r9d
 10180f0:	movabs $0x10000102002,%rcx
 10180fa:	bt     %rax,%rcx
 10180fe:	jb     1017dda <acquire+0x10a>
 1018104:	cmp    $0xc,%rax
 1018108:	je     1018a6c <acquire+0xd9c>
 101810e:	mov    $0x3,%r9d
 1018114:	jmp    1017dda <acquire+0x10a>
 1018119:	xor    %eax,%eax
 101811b:	xor    %ecx,%ecx
 101811d:	mov    -0x38(%rbp),%rdx
 1018121:	mov    $0xc80405,%r15d
 1018127:	mov    %r14,%r8
 101812a:	mov    -0x68(%rbp),%rdi
 101812e:	mov    -0x50(%rbp),%r9d
 1018132:	mov    -0x60(%rbp),%r10d
 1018136:	jmp    1018150 <acquire+0x480>
 1018138:	nopl   0x0(%rax,%rax,1)
 1018140:	lea    0x1(%rax),%rcx
 1018144:	inc    %rax
 1018147:	cmp    %rax,%r8
 101814a:	je     1017e1e <acquire+0x14e>
 1018150:	cmp    %rax,%rdx
 1018153:	je     101815d <acquire+0x48d>
 1018155:	cmpb   $0x2f,0x0(%r13,%rax,1)
 101815b:	jne    1018144 <acquire+0x474>
 101815d:	mov    %rax,%rsi
 1018160:	sub    %rcx,%rsi
 1018163:	je     1017dda <acquire+0x10a>
 1018169:	cmp    $0x2,%rsi
 101816d:	je     1018190 <acquire+0x4c0>
 101816f:	cmp    $0x1,%rsi
 1018173:	jne    1018140 <acquire+0x470>
 1018175:	cmpb   $0x2e,0x0(%r13,%rcx,1)
 101817b:	jne    1018140 <acquire+0x470>
 101817d:	jmp    1017dda <acquire+0x10a>
 1018182:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018190:	cmpb   $0x2e,0x0(%r13,%rcx,1)
 1018196:	jne    1018140 <acquire+0x470>
 1018198:	cmpb   $0x2e,0x1(%r13,%rcx,1)
 101819e:	jne    1018140 <acquire+0x470>
 10181a0:	jmp    1017dda <acquire+0x10a>
 10181a5:	mov    $0x2,%r9d
 10181ab:	test   %al,%al
 10181ad:	mov    -0x38(%rbp),%rdx
 10181b1:	mov    -0x40(%rbp),%r8
 10181b5:	je     10189a2 <acquire+0xcd2>
 10181bb:	cmpb   $0x6b,-0x2d(%rbp)
 10181bf:	jne    1018544 <acquire+0x874>
 10181c5:	mov    %r14d,%edi
 10181c8:	lea    -0x1160(%rbp),%rsi
 10181cf:	mov    $0x1ff,%edx
 10181d4:	call   101f0c0 <mkdirat@plt>
 10181d9:	test   %eax,%eax
 10181db:	je     10185ed <acquire+0x91d>
 10181e1:	call   101f060 <__errno_location@plt>
 10181e6:	mov    (%rax),%eax
 10181e8:	cmp    $0x28,%rax
 10181ec:	mov    -0x38(%rbp),%rdx
 10181f0:	mov    -0x40(%rbp),%r8
 10181f4:	mov    -0x2c(%rbp),%r14d
 10181f8:	ja     101899c <acquire+0xccc>
 10181fe:	movabs $0x10000102002,%rcx
 1018208:	bt     %rax,%rcx
 101820c:	jb     101876a <acquire+0xa9a>
 1018212:	jmp    1018648 <acquire+0x978>
 1018217:	cmpb   $0x0,-0x1160(%rbp)
 101821e:	lea    -0x1160(%rbp),%rsi
 1018225:	lea    -0x16459(%rip),%rax        # 1001dd3 <__abi_tag+0x1ad7>
 101822c:	cmove  %rax,%rsi
 1018230:	mov    -0x2c(%rbp),%edi
 1018233:	mov    $0xb0000,%edx
 1018238:	xor    %eax,%eax
 101823a:	call   101f0a0 <openat@plt>
 101823f:	test   %eax,%eax
 1018241:	js     1018610 <acquire+0x940>
 1018247:	mov    %eax,%r14d
 101824a:	mov    %eax,%edi
 101824c:	call   101f0d0 <fdopendir@plt>
 1018251:	mov    %rax,-0x60(%rbp)
 1018255:	test   %rax,%rax
 1018258:	je     101877a <acquire+0xaaa>
 101825e:	mov    $0x400,%edi
 1018263:	call   101ee60 <malloc@plt>
 1018268:	test   %rax,%rax
 101826b:	je     101886e <acquire+0xb9e>
 1018271:	mov    %rax,%r13
 1018274:	movb   $0x1,(%rax)
 1018277:	call   101f060 <__errno_location@plt>
 101827c:	mov    %rax,%r14
 101827f:	movl   $0x0,(%rax)
 1018285:	mov    -0x60(%rbp),%rdi
 1018289:	call   101f0e0 <readdir@plt>
 101828e:	test   %rax,%rax
 1018291:	je     10188ec <acquire+0xc1c>
 1018297:	mov    %r14,-0x98(%rbp)
 101829e:	mov    $0x400,%ecx
 10182a3:	mov    %rcx,-0x88(%rbp)
 10182aa:	mov    $0x1,%r14d
 10182b0:	movq   $0x0,-0x90(%rbp)
 10182bb:	mov    %r14,-0x50(%rbp)
 10182bf:	mov    -0x98(%rbp),%r14
 10182c6:	jmp    10182e1 <acquire+0x611>
 10182c8:	movl   $0x0,(%r14)
 10182cf:	mov    -0x60(%rbp),%rdi
 10182d3:	call   101f0e0 <readdir@plt>
 10182d8:	test   %rax,%rax
 10182db:	je     1018942 <acquire+0xc72>
 10182e1:	cmpb   $0x2e,0x13(%rax)
 10182e5:	jne    10182fa <acquire+0x62a>
 10182e7:	movzbl 0x14(%rax),%ecx
 10182eb:	test   %ecx,%ecx
 10182ed:	je     10182c8 <acquire+0x5f8>
 10182ef:	cmp    $0x2e,%ecx
 10182f2:	jne    10182fa <acquire+0x62a>
 10182f4:	cmpb   $0x0,0x15(%rax)
 10182f8:	je     10182c8 <acquire+0x5f8>
 10182fa:	add    $0x13,%rax
 10182fe:	mov    %rax,-0x78(%rbp)
 1018302:	mov    %rax,%rdi
 1018305:	call   101e450 <compiler_rt.strlen>
 101830a:	mov    -0x50(%rbp),%rdx
 101830e:	cmp    $0x10000,%rdx
 1018315:	ja     1018a43 <acquire+0xd73>
 101831b:	cmpq   $0xff,-0x90(%rbp)
 1018326:	ja     1018a43 <acquire+0xd73>
 101832c:	mov    %rax,%rsi
 101832f:	add    $0xfffffffffffff001,%rax
 1018335:	cmp    $0xfffffffffffff002,%rax
 101833b:	jb     1018a43 <acquire+0xd73>
 1018341:	lea    0x3(%rsi),%rax
 1018345:	mov    $0x10000,%ecx
 101834a:	sub    %rdx,%rcx
 101834d:	cmp    %rcx,%rax
 1018350:	ja     1018a43 <acquire+0xd73>
 1018356:	lea    0x3(%rdx),%rax
 101835a:	mov    %rax,-0xb0(%rbp)
 1018361:	lea    (%rsi,%rdx,1),%rcx
 1018365:	add    $0x3,%rcx
 1018369:	mov    %r13,%rax
 101836c:	mov    -0x88(%rbp),%r14
 1018373:	mov    %rcx,-0xb8(%rbp)
 101837a:	mov    %rsi,-0xa0(%rbp)
 1018381:	cmp    %r14,%rcx
 1018384:	jbe    10183b1 <acquire+0x6e1>
 1018386:	add    %r14,%r14
 1018389:	mov    %rax,%r13
 101838c:	mov    %rax,%rdi
 101838f:	mov    %r14,%rsi
 1018392:	call   101ef70 <realloc@plt>
 1018397:	test   %rax,%rax
 101839a:	mov    -0x50(%rbp),%rcx
 101839e:	mov    -0xa0(%rbp),%rsi
 10183a5:	lea    0x3(%rsi,%rcx,1),%rcx
 10183aa:	jne    1018381 <acquire+0x6b1>
 10183ac:	jmp    1018963 <acquire+0xc93>
 10183b1:	mov    %r14,-0x88(%rbp)
 10183b8:	mov    %rax,%r13
 10183bb:	mov    -0x60(%rbp),%rdi
 10183bf:	call   101f0f0 <dirfd@plt>
 10183c4:	mov    %eax,%edi
 10183c6:	mov    -0x78(%rbp),%rsi
 10183ca:	lea    -0x160(%rbp),%rdx
 10183d1:	mov    $0x100,%ecx
 10183d6:	call   101f0b0 <fstatat@plt>
 10183db:	test   %eax,%eax
 10183dd:	je     101843c <acquire+0x76c>
 10183df:	xor    %eax,%eax
 10183e1:	mov    -0x78(%rbp),%rsi
 10183e5:	mov    %r13,%rcx
 10183e8:	mov    -0x50(%rbp),%rdi
 10183ec:	mov    %al,(%rcx,%rdi,1)
 10183ef:	mov    -0xa0(%rbp),%rdx
 10183f6:	mov    %dx,0x1(%rcx,%rdi,1)
 10183fb:	mov    -0xb0(%rbp),%rdi
 1018402:	add    %rcx,%rdi
 1018405:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101840a:	incq   -0x90(%rbp)
 1018411:	mov    -0x98(%rbp),%rax
 1018418:	movl   $0x0,(%rax)
 101841e:	mov    -0x60(%rbp),%rdi
 1018422:	call   101f0e0 <readdir@plt>
 1018427:	test   %rax,%rax
 101842a:	mov    -0xb8(%rbp),%r14
 1018431:	jne    10182bb <acquire+0x5eb>
 1018437:	jmp    1018946 <acquire+0xc76>
 101843c:	mov    -0x148(%rbp),%eax
 1018442:	mov    $0xf000,%ecx
 1018447:	and    %ecx,%eax
 1018449:	cmp    $0xa000,%eax
 101844e:	mov    -0x50(%rbp),%rdi
 1018452:	je     1018477 <acquire+0x7a7>
 1018454:	cmp    $0x8000,%eax
 1018459:	mov    -0x78(%rbp),%rsi
 101845d:	mov    %r13,%rcx
 1018460:	je     1018470 <acquire+0x7a0>
 1018462:	cmp    $0x4000,%eax
 1018467:	jne    1018485 <acquire+0x7b5>
 1018469:	mov    $0x2,%al
 101846b:	jmp    10183ec <acquire+0x71c>
 1018470:	mov    $0x1,%al
 1018472:	jmp    10183ec <acquire+0x71c>
 1018477:	mov    $0x3,%al
 1018479:	mov    -0x78(%rbp),%rsi
 101847d:	mov    %r13,%rcx
 1018480:	jmp    10183ec <acquire+0x71c>
 1018485:	xor    %eax,%eax
 1018487:	jmp    10183ec <acquire+0x71c>
 101848c:	xor    %edx,%edx
 101848e:	cmpl   $0x0,-0x60(%rbp)
 1018492:	sete   %dl
 1018495:	shl    $0xb,%edx
 1018498:	mov    -0xa8(%rbp),%rax
 101849f:	cmp    $0x61,%eax
 10184a2:	mov    -0x2c(%rbp),%r14d
 10184a6:	je     101865d <acquire+0x98d>
 10184ac:	cmp    $0x63,%eax
 10184af:	mov    -0x70(%rbp),%r13
 10184b3:	jne    101867f <acquire+0x9af>
 10184b9:	or     $0x800c1,%edx
 10184bf:	mov    %r14d,%edi
 10184c2:	lea    -0x1160(%rbp),%rsi
 10184c9:	mov    $0x1b6,%ecx
 10184ce:	xor    %eax,%eax
 10184d0:	call   101f0a0 <openat@plt>
 10184d5:	jmp    10186a4 <acquire+0x9d4>
 10184da:	lea    -0x160(%rbp),%rsi
 10184e1:	call   101f100 <fstat@plt>
 10184e6:	test   %eax,%eax
 10184e8:	jne    101808b <acquire+0x3bb>
 10184ee:	mov    $0xa,%edi
 10184f3:	call   101ee60 <malloc@plt>
 10184f8:	test   %rax,%rax
 10184fb:	je     1018856 <acquire+0xb86>
 1018501:	mov    %rax,%r13
 1018504:	movb   $0x1,(%rax)
 1018507:	mov    -0x148(%rbp),%eax
 101850d:	mov    $0xf000,%ecx
 1018512:	and    %ecx,%eax
 1018514:	cmp    $0xa000,%eax
 1018519:	je     10188f8 <acquire+0xc28>
 101851f:	cmp    $0x8000,%eax
 1018524:	mov    -0x38(%rbp),%rdx
 1018528:	mov    -0x40(%rbp),%r8
 101852c:	je     10188f4 <acquire+0xc24>
 1018532:	cmp    $0x4000,%eax
 1018537:	jne    1018904 <acquire+0xc34>
 101853d:	mov    $0x2,%al
 101853f:	jmp    1018906 <acquire+0xc36>
 1018544:	mov    %r14d,%edi
 1018547:	lea    -0x1160(%rbp),%rsi
 101854e:	xor    %edx,%edx
 1018550:	call   101f110 <unlinkat@plt>
 1018555:	test   %eax,%eax
 1018557:	je     10185ed <acquire+0x91d>
 101855d:	call   101f060 <__errno_location@plt>
 1018562:	mov    (%rax),%ecx
 1018564:	cmp    $0x28,%rcx
 1018568:	mov    -0x38(%rbp),%rdx
 101856c:	mov    -0x40(%rbp),%r8
 1018570:	mov    -0x2c(%rbp),%r14d
 1018574:	ja     101899c <acquire+0xccc>
 101857a:	movabs $0x10000102000,%rsi
 1018584:	bt     %rcx,%rsi
 1018588:	jb     101876a <acquire+0xa9a>
 101858e:	mov    $0x200002,%esi
 1018593:	bt     %rcx,%rsi
 1018597:	jae    1018992 <acquire+0xcc2>
 101859d:	mov    %r14d,%edi
 10185a0:	mov    %rax,%r14
 10185a3:	lea    -0x1160(%rbp),%rsi
 10185aa:	mov    $0x200,%edx
 10185af:	call   101f110 <unlinkat@plt>
 10185b4:	test   %eax,%eax
 10185b6:	je     10185ed <acquire+0x91d>
 10185b8:	mov    (%r14),%eax
 10185bb:	cmp    $0x28,%rax
 10185bf:	mov    -0x38(%rbp),%rdx
 10185c3:	mov    -0x40(%rbp),%r8
 10185c7:	mov    -0x2c(%rbp),%r14d
 10185cb:	ja     101899c <acquire+0xccc>
 10185d1:	movabs $0x10000102002,%rcx
 10185db:	bt     %rax,%rcx
 10185df:	mov    $0x2,%r9d
 10185e5:	jb     10189a2 <acquire+0xcd2>
 10185eb:	jmp    1018648 <acquire+0x978>
 10185ed:	mov    $0x1,%edi
 10185f2:	call   101ee60 <malloc@plt>
 10185f7:	test   %rax,%rax
 10185fa:	je     101887e <acquire+0xbae>
 1018600:	mov    %rax,%r13
 1018603:	movb   $0x1,(%rax)
 1018606:	mov    $0x1,%ecx
 101860b:	jmp    1018952 <acquire+0xc82>
 1018610:	call   101f060 <__errno_location@plt>
 1018615:	mov    (%rax),%eax
 1018617:	cmp    $0x28,%rax
 101861b:	mov    -0x38(%rbp),%rdx
 101861f:	mov    -0x40(%rbp),%r8
 1018623:	mov    -0x2c(%rbp),%r14d
 1018627:	ja     101899c <acquire+0xccc>
 101862d:	movabs $0x10000102002,%rcx
 1018637:	bt     %rax,%rcx
 101863b:	jae    1018648 <acquire+0x978>
 101863d:	mov    $0x2,%r9d
 1018643:	jmp    10189a2 <acquire+0xcd2>
 1018648:	cmp    $0xc,%rax
 101864c:	jne    101899c <acquire+0xccc>
 1018652:	mov    $0x4,%r9d
 1018658:	jmp    10189a2 <acquire+0xcd2>
 101865d:	or     $0x80041,%edx
 1018663:	mov    %r14d,%edi
 1018666:	lea    -0x1160(%rbp),%rsi
 101866d:	mov    $0x1b6,%ecx
 1018672:	xor    %eax,%eax
 1018674:	call   101f0a0 <openat@plt>
 1018679:	mov    -0x70(%rbp),%r13
 101867d:	jmp    10186a4 <acquire+0x9d4>
 101867f:	cmpl   $0x0,-0x60(%rbp)
 1018683:	mov    $0xa0800,%edx
 1018688:	mov    $0x80000,%eax
 101868d:	cmovne %eax,%edx
 1018690:	add    -0x7c(%rbp),%edx
 1018693:	mov    %r14d,%edi
 1018696:	lea    -0x1160(%rbp),%rsi
 101869d:	xor    %eax,%eax
 101869f:	call   101f0a0 <openat@plt>
 10186a4:	cmp    -0x48(%rbp),%r14d
 10186a8:	je     10186b8 <acquire+0x9e8>
 10186aa:	mov    %eax,-0x48(%rbp)
 10186ad:	mov    %r14d,%edi
 10186b0:	call   101f040 <close@plt>
 10186b5:	mov    -0x48(%rbp),%eax
 10186b8:	test   %eax,%eax
 10186ba:	lea    -0x160(%rbp),%rsi
 10186c1:	js     1018720 <acquire+0xa50>
 10186c3:	mov    %eax,%r14d
 10186c6:	mov    %eax,%edi
 10186c8:	mov    %rsi,%r15
 10186cb:	call   101f100 <fstat@plt>
 10186d0:	test   %eax,%eax
 10186d2:	je     10187b7 <acquire+0xae7>
 10186d8:	call   101f060 <__errno_location@plt>
 10186dd:	mov    (%rax),%eax
 10186df:	cmp    $0x28,%rax
 10186e3:	mov    -0x44(%rbp),%r12d
 10186e7:	mov    $0xc80405,%r15d
 10186ed:	ja     10188e2 <acquire+0xc12>
 10186f3:	movabs $0x10000102002,%rcx
 10186fd:	bt     %rax,%rcx
 1018701:	jae    10188d3 <acquire+0xc03>
 1018707:	mov    $0x2,%ecx
 101870c:	mov    %r14d,%edi
 101870f:	mov    %ecx,%ebx
 1018711:	call   101f040 <close@plt>
 1018716:	mov    %ebx,%r9d
 1018719:	xor    %ebx,%ebx
 101871b:	jmp    10188c6 <acquire+0xbf6>
 1018720:	call   101f060 <__errno_location@plt>
 1018725:	mov    (%rax),%eax
 1018727:	cmp    $0x28,%rax
 101872b:	mov    -0x44(%rbp),%r12d
 101872f:	mov    -0x38(%rbp),%rdx
 1018733:	mov    -0x40(%rbp),%r8
 1018737:	mov    -0x68(%rbp),%rdi
 101873b:	ja     101810e <acquire+0x43e>
 1018741:	mov    $0x2,%r9d
 1018747:	movabs $0x10000102002,%rcx
 1018751:	bt     %rax,%rcx
 1018755:	jb     1017dda <acquire+0x10a>
 101875b:	cmp    $0xc,%rax
 101875f:	jne    101810e <acquire+0x43e>
 1018765:	jmp    1018a6c <acquire+0xd9c>
 101876a:	xor    %ecx,%ecx
 101876c:	xor    %r13d,%r13d
 101876f:	mov    $0x2,%r9d
 1018775:	jmp    10189a7 <acquire+0xcd7>
 101877a:	call   101f060 <__errno_location@plt>
 101877f:	mov    (%rax),%eax
 1018781:	cmp    $0x28,%rax
 1018785:	ja     1018a39 <acquire+0xd69>
 101878b:	movabs $0x10000102002,%rcx
 1018795:	bt     %rax,%rcx
 1018799:	jae    1018a2a <acquire+0xd5a>
 101879f:	mov    $0x2,%ecx
 10187a4:	mov    %r14d,%edi
 10187a7:	mov    %ecx,%r14d
 10187aa:	call   101f040 <close@plt>
 10187af:	mov    %r14d,%r9d
 10187b2:	jmp    1018884 <acquire+0xbb4>
 10187b7:	mov    -0x60(%rbp),%edi
 10187ba:	mov    %r14d,%esi
 10187bd:	mov    %r15,%rdx
 10187c0:	call   1018a80 <usable>
 10187c5:	test   %eax,%eax
 10187c7:	je     1018922 <acquire+0xc52>
 10187cd:	cmpb   $0x74,-0x2d(%rbp)
 10187d1:	mov    $0xc80405,%r15d
 10187d7:	jne    101888e <acquire+0xbbe>
 10187dd:	mov    -0x148(%rbp),%eax
 10187e3:	mov    $0xf000,%ecx
 10187e8:	and    %ecx,%eax
 10187ea:	cmp    $0x8000,%eax
 10187ef:	jne    101888e <acquire+0xbbe>
 10187f5:	mov    %r14d,%edi
 10187f8:	xor    %esi,%esi
 10187fa:	call   101f120 <ftruncate@plt>
 10187ff:	test   %eax,%eax
 1018801:	je     101888e <acquire+0xbbe>
 1018807:	call   101f060 <__errno_location@plt>
 101880c:	mov    (%rax),%eax
 101880e:	cmp    $0x28,%rax
 1018812:	mov    -0x44(%rbp),%r12d
 1018816:	ja     1018a60 <acquire+0xd90>
 101881c:	movabs $0x10000102002,%rcx
 1018826:	bt     %rax,%rcx
 101882a:	jae    1018a4f <acquire+0xd7f>
 1018830:	movl   $0x2,-0x50(%rbp)
 1018837:	mov    %r14d,%edi
 101883a:	call   101f040 <close@plt>
 101883f:	xor    %ebx,%ebx
 1018841:	mov    -0x38(%rbp),%rdx
 1018845:	mov    -0x40(%rbp),%r8
 1018849:	mov    -0x68(%rbp),%rdi
 101884d:	mov    -0x50(%rbp),%r9d
 1018851:	jmp    1018a1b <acquire+0xd4b>
 1018856:	mov    $0x4,%r9d
 101885c:	xor    %ecx,%ecx
 101885e:	xor    %r13d,%r13d
 1018861:	mov    -0x38(%rbp),%rdx
 1018865:	mov    -0x40(%rbp),%r8
 1018869:	jmp    10189a7 <acquire+0xcd7>
 101886e:	movl   $0x4,-0x50(%rbp)
 1018875:	mov    -0x2c(%rbp),%r14d
 1018879:	jmp    1018976 <acquire+0xca6>
 101887e:	mov    $0x4,%r9d
 1018884:	xor    %ecx,%ecx
 1018886:	xor    %r13d,%r13d
 1018889:	jmp    1018955 <acquire+0xc85>
 101888e:	mov    %r14d,(%r12)
 1018892:	vxorps %xmm0,%xmm0,%xmm0
 1018896:	vmovups %xmm0,0x4(%r12)
 101889d:	vmovups %xmm0,0x10(%r12)
 10188a4:	movzbl -0x2d(%rbp),%eax
 10188a8:	mov    %al,0x20(%r12)
 10188ad:	movl   $0x0,0x21(%r12)
 10188b6:	movl   $0x0,0x24(%r12)
 10188bf:	xor    %r9d,%r9d
 10188c2:	mov    -0x44(%rbp),%r12d
 10188c6:	mov    -0x38(%rbp),%rdx
 10188ca:	mov    -0x40(%rbp),%r8
 10188ce:	jmp    1018a17 <acquire+0xd47>
 10188d3:	mov    $0x4,%ecx
 10188d8:	cmp    $0xc,%rax
 10188dc:	je     101870c <acquire+0xa3c>
 10188e2:	mov    $0x3,%ecx
 10188e7:	jmp    101870c <acquire+0xa3c>
 10188ec:	mov    $0x1,%r14d
 10188f2:	jmp    1018946 <acquire+0xc76>
 10188f4:	mov    $0x1,%al
 10188f6:	jmp    1018906 <acquire+0xc36>
 10188f8:	mov    $0x3,%al
 10188fa:	mov    -0x38(%rbp),%rdx
 10188fe:	mov    -0x40(%rbp),%r8
 1018902:	jmp    1018906 <acquire+0xc36>
 1018904:	xor    %eax,%eax
 1018906:	mov    %al,0x1(%r13)
 101890a:	mov    -0x130(%rbp),%rax
 1018911:	mov    %rax,0x2(%r13)
 1018915:	mov    $0xa,%ecx
 101891a:	xor    %r9d,%r9d
 101891d:	jmp    10189a7 <acquire+0xcd7>
 1018922:	mov    %r14d,%edi
 1018925:	call   101f040 <close@plt>
 101892a:	mov    $0x2,%r9d
 1018930:	xor    %ebx,%ebx
 1018932:	mov    -0x44(%rbp),%r12d
 1018936:	mov    -0x38(%rbp),%rdx
 101893a:	mov    $0xc80405,%r15d
 1018940:	jmp    10188ca <acquire+0xbfa>
 1018942:	mov    -0x50(%rbp),%r14
 1018946:	mov    -0x60(%rbp),%rdi
 101894a:	call   101f130 <closedir@plt>
 101894f:	mov    %r14,%rcx
 1018952:	xor    %r9d,%r9d
 1018955:	mov    -0x38(%rbp),%rdx
 1018959:	mov    -0x40(%rbp),%r8
 101895d:	mov    -0x2c(%rbp),%r14d
 1018961:	jmp    10189a7 <acquire+0xcd7>
 1018963:	movl   $0x4,-0x50(%rbp)
 101896a:	mov    -0x2c(%rbp),%r14d
 101896e:	mov    %r13,%rdi
 1018971:	call   101edc0 <free@plt>
 1018976:	mov    -0x60(%rbp),%rdi
 101897a:	call   101f130 <closedir@plt>
 101897f:	xor    %ecx,%ecx
 1018981:	xor    %r13d,%r13d
 1018984:	mov    -0x38(%rbp),%rdx
 1018988:	mov    -0x40(%rbp),%r8
 101898c:	mov    -0x50(%rbp),%r9d
 1018990:	jmp    10189a7 <acquire+0xcd7>
 1018992:	cmp    $0xc,%rcx
 1018996:	je     1018652 <acquire+0x982>
 101899c:	mov    $0x3,%r9d
 10189a2:	xor    %ecx,%ecx
 10189a4:	xor    %r13d,%r13d
 10189a7:	cmp    -0x48(%rbp),%r14d
 10189ab:	je     10189cf <acquire+0xcff>
 10189ad:	mov    %r14d,%edi
 10189b0:	mov    %r9d,%r14d
 10189b3:	mov    %rcx,%r15
 10189b6:	call   101f040 <close@plt>
 10189bb:	mov    %r15,%rcx
 10189be:	mov    $0xc80405,%r15d
 10189c4:	mov    %r14d,%r9d
 10189c7:	mov    -0x40(%rbp),%r8
 10189cb:	mov    -0x38(%rbp),%rdx
 10189cf:	test   %r13,%r13
 10189d2:	je     1018a0d <acquire+0xd3d>
 10189d4:	mov    $0xffffffff,%eax
 10189d9:	mov    %rax,(%r12)
 10189dd:	mov    %r13,0x8(%r12)
 10189e2:	mov    %rcx,0x10(%r12)
 10189e7:	movq   $0x0,0x18(%r12)
 10189f0:	movzbl -0x2d(%rbp),%eax
 10189f4:	mov    %al,0x20(%r12)
 10189f9:	movl   $0x0,0x21(%r12)
 1018a02:	movl   $0x0,0x24(%r12)
 1018a0b:	jmp    1018a0f <acquire+0xd3f>
 1018a0d:	xor    %ebx,%ebx
 1018a0f:	mov    -0x70(%rbp),%r13
 1018a13:	mov    -0x44(%rbp),%r12d
 1018a17:	mov    -0x68(%rbp),%rdi
 1018a1b:	test   $0x3,%r9b
 1018a1f:	jne    1017dda <acquire+0x10a>
 1018a25:	jmp    1017d44 <acquire+0x74>
 1018a2a:	mov    $0x4,%ecx
 1018a2f:	cmp    $0xc,%rax
 1018a33:	je     10187a4 <acquire+0xad4>
 1018a39:	mov    $0x3,%ecx
 1018a3e:	jmp    10187a4 <acquire+0xad4>
 1018a43:	movl   $0x2,-0x50(%rbp)
 1018a4a:	jmp    101896a <acquire+0xc9a>
 1018a4f:	movl   $0x4,-0x50(%rbp)
 1018a56:	cmp    $0xc,%rax
 1018a5a:	je     1018837 <acquire+0xb67>
 1018a60:	movl   $0x3,-0x50(%rbp)
 1018a67:	jmp    1018837 <acquire+0xb67>
 1018a6c:	mov    $0x4,%r9d
 1018a72:	jmp    1017d42 <acquire+0x72>
 1018a77:	int3
 1018a78:	int3
 1018a79:	int3
 1018a7a:	int3
 1018a7b:	int3
 1018a7c:	int3
 1018a7d:	int3
 1018a7e:	int3
 1018a7f:	int3

0000000001018a80 <usable>:
 1018a80:	mov    $0xf000,%eax
 1018a85:	and    0x18(%rdx),%eax
 1018a88:	test   %edi,%edi
 1018a8a:	je     1018a98 <usable+0x18>
 1018a8c:	cmp    $0x4000,%eax
 1018a91:	setne  %al
 1018a94:	movzbl %al,%eax
 1018a97:	ret
 1018a98:	cmp    $0x8000,%eax
 1018a9d:	jne    1018ad9 <usable+0x59>
 1018a9f:	push   %rbp
 1018aa0:	mov    %rsp,%rbp
 1018aa3:	push   %rbx
 1018aa4:	push   %rax
 1018aa5:	mov    %esi,%edi
 1018aa7:	mov    %esi,%ebx
 1018aa9:	mov    $0x3,%esi
 1018aae:	xor    %eax,%eax
 1018ab0:	call   101f140 <fcntl@plt>
 1018ab5:	and    $0xfffff7ff,%eax
 1018aba:	mov    %ebx,%edi
 1018abc:	mov    $0x4,%esi
 1018ac1:	mov    %eax,%edx
 1018ac3:	xor    %eax,%eax
 1018ac5:	call   101f140 <fcntl@plt>
 1018aca:	test   %eax,%eax
 1018acc:	sete   %al
 1018acf:	add    $0x8,%rsp
 1018ad3:	pop    %rbx
 1018ad4:	pop    %rbp
 1018ad5:	movzbl %al,%eax
 1018ad8:	ret
 1018ad9:	xor    %eax,%eax
 1018adb:	movzbl %al,%eax
 1018ade:	ret
 1018adf:	int3

0000000001018ae0 <myl_native_cow_take_depth_failure>:
 1018ae0:	push   %rbp
 1018ae1:	mov    %rsp,%rbp
 1018ae4:	data16 data16 data16 mov %fs:0x0,%rax
 1018af0:	mov    -0x4(%rax),%ecx
 1018af6:	movl   $0x0,-0x4(%rax)
 1018b00:	mov    %ecx,%eax
 1018b02:	pop    %rbp
 1018b03:	ret
 1018b04:	int3
 1018b05:	int3
 1018b06:	int3
 1018b07:	int3
 1018b08:	int3
 1018b09:	int3
 1018b0a:	int3
 1018b0b:	int3
 1018b0c:	int3
 1018b0d:	int3
 1018b0e:	int3
 1018b0f:	int3

0000000001018b10 <myl_rc_scope_spares_release>:
 1018b10:	push   %rbp
 1018b11:	mov    %rsp,%rbp
 1018b14:	push   %rbx
 1018b15:	push   %rax
 1018b16:	mov    %rdi,%rbx
 1018b19:	mov    0x1608(%rdi),%rax
 1018b20:	mov    0x100(%rax),%rdi
 1018b27:	test   %rdi,%rdi
 1018b2a:	je     1018b65 <myl_rc_scope_spares_release+0x55>
 1018b2c:	add    $0x100,%rax
 1018b32:	mov    %rax,%rcx
 1018b35:	data16 cs nopw 0x0(%rax,%rax,1)
 1018b40:	mov    (%rdi),%rax
 1018b43:	mov    %rax,(%rcx)
 1018b46:	call   101edc0 <free@plt>
 1018b4b:	mov    0x1608(%rbx),%rax
 1018b52:	lea    0x100(%rax),%rcx
 1018b59:	mov    0x100(%rax),%rdi
 1018b60:	test   %rdi,%rdi
 1018b63:	jne    1018b40 <myl_rc_scope_spares_release+0x30>
 1018b65:	movq   $0x0,0x108(%rax)
 1018b70:	add    $0x8,%rsp
 1018b74:	pop    %rbx
 1018b75:	pop    %rbp
 1018b76:	ret
 1018b77:	int3
 1018b78:	int3
 1018b79:	int3
 1018b7a:	int3
 1018b7b:	int3
 1018b7c:	int3
 1018b7d:	int3
 1018b7e:	int3
 1018b7f:	int3

0000000001018b80 <myl_rc_scopes_abandon>:
 1018b80:	push   %rbp
 1018b81:	mov    %rsp,%rbp
 1018b84:	push   %r15
 1018b86:	push   %r14
 1018b88:	push   %r12
 1018b8a:	push   %rbx
 1018b8b:	test   %rdi,%rdi
 1018b8e:	je     1018c74 <myl_rc_scopes_abandon+0xf4>
 1018b94:	mov    0x1608(%rdi),%rax
 1018b9b:	test   %rax,%rax
 1018b9e:	je     1018c74 <myl_rc_scopes_abandon+0xf4>
 1018ba4:	mov    0xf8(%rax),%r14
 1018bab:	movq   $0x0,0xf8(%rax)
 1018bb6:	test   %r14,%r14
 1018bb9:	je     1018c74 <myl_rc_scopes_abandon+0xf4>
 1018bbf:	vxorps %xmm0,%xmm0,%xmm0
 1018bc3:	jmp    1018bed <myl_rc_scopes_abandon+0x6d>
 1018bc5:	data16 cs nopw 0x0(%rax,%rax,1)
 1018bd0:	add    $0x8,%r14
 1018bd4:	vmovups %xmm0,(%r14)
 1018bd9:	movl   $0x0,0x10(%r14)
 1018be1:	mov    %r15,%r14
 1018be4:	test   %r15,%r15
 1018be7:	je     1018c74 <myl_rc_scopes_abandon+0xf4>
 1018bed:	mov    0x8(%r14),%r15
 1018bf1:	mov    0x10(%r14),%rsi
 1018bf5:	test   %rsi,%rsi
 1018bf8:	je     1018bd0 <myl_rc_scopes_abandon+0x50>
 1018bfa:	nopw   0x0(%rax,%rax,1)
 1018c00:	mov    (%rsi),%r12
 1018c03:	mov    0x1608(%rdi),%rax
 1018c0a:	mov    0x108(%rax),%rcx
 1018c11:	cmp    $0x20,%rcx
 1018c15:	je     1018c63 <myl_rc_scopes_abandon+0xe3>
 1018c17:	mov    0x18(%rdi),%rdx
 1018c1b:	cmp    $0x28,%rdx
 1018c1f:	jb     1018c7d <myl_rc_scopes_abandon+0xfd>
 1018c21:	mov    0x30(%rax),%r8
 1018c25:	cmp    $0x27,%r8
 1018c29:	jbe    1018c7d <myl_rc_scopes_abandon+0xfd>
 1018c2b:	add    $0xffffffffffffffd8,%rdx
 1018c2f:	mov    %rdx,0x18(%rdi)
 1018c33:	add    $0xffffffffffffffd8,%r8
 1018c37:	mov    %r8,0x30(%rax)
 1018c3b:	mov    0x100(%rax),%rdx
 1018c42:	mov    %rdx,(%rsi)
 1018c45:	mov    %rsi,0x100(%rax)
 1018c4c:	inc    %rcx
 1018c4f:	mov    %rcx,0x108(%rax)
 1018c56:	mov    %r12,%rsi
 1018c59:	test   %r12,%r12
 1018c5c:	jne    1018c00 <myl_rc_scopes_abandon+0x80>
 1018c5e:	jmp    1018bd0 <myl_rc_scopes_abandon+0x50>
 1018c63:	mov    %rdi,%rbx
 1018c66:	call   1019273 <entry_release>
 1018c6b:	vxorps %xmm0,%xmm0,%xmm0
 1018c6f:	mov    %rbx,%rdi
 1018c72:	jmp    1018c56 <myl_rc_scopes_abandon+0xd6>
 1018c74:	pop    %rbx
 1018c75:	pop    %r12
 1018c77:	pop    %r14
 1018c79:	pop    %r15
 1018c7b:	pop    %rbp
 1018c7c:	ret
 1018c7d:	call   101246d <myl_rc_invariant_failed>
 1018c82:	int3
 1018c83:	int3
 1018c84:	int3
 1018c85:	int3
 1018c86:	int3
 1018c87:	int3
 1018c88:	int3
 1018c89:	int3
 1018c8a:	int3
 1018c8b:	int3
 1018c8c:	int3
 1018c8d:	int3
 1018c8e:	int3
 1018c8f:	int3

0000000001018c90 <myl_rc_scopes_close_region>:
 1018c90:	push   %rbp
 1018c91:	mov    %rsp,%rbp
 1018c94:	mov    %esi,%eax
 1018c96:	mov    0x1608(%rdi),%rcx
 1018c9d:	mov    0xf8(%rcx),%rsi
 1018ca4:	test   %rsi,%rsi
 1018ca7:	je     1018cbe <myl_rc_scopes_close_region+0x2e>
 1018ca9:	nopl   0x0(%rax)
 1018cb0:	cmp    %eax,0x1c(%rsi)
 1018cb3:	jb     1018cc0 <myl_rc_scopes_close_region+0x30>
 1018cb5:	mov    0x8(%rsi),%rsi
 1018cb9:	test   %rsi,%rsi
 1018cbc:	jne    1018cb0 <myl_rc_scopes_close_region+0x20>
 1018cbe:	xor    %esi,%esi
 1018cc0:	pop    %rbp
 1018cc1:	jmp    1018cd0 <myl_rc_scope_unwind>
 1018cc6:	int3
 1018cc7:	int3
 1018cc8:	int3
 1018cc9:	int3
 1018cca:	int3
 1018ccb:	int3
 1018ccc:	int3
 1018ccd:	int3
 1018cce:	int3
 1018ccf:	int3

0000000001018cd0 <myl_rc_scope_unwind>:
 1018cd0:	push   %rbp
 1018cd1:	mov    %rsp,%rbp
 1018cd4:	push   %r15
 1018cd6:	push   %r14
 1018cd8:	push   %r13
 1018cda:	push   %r12
 1018cdc:	push   %rbx
 1018cdd:	push   %rax
 1018cde:	mov    %rsi,%rbx
 1018ce1:	test   %rdi,%rdi
 1018ce4:	je     1018d65 <myl_rc_scope_unwind+0x95>
 1018ce6:	mov    %rdi,%r12
 1018ce9:	mov    0x1608(%rdi),%rax
 1018cf0:	test   %rax,%rax
 1018cf3:	je     1018d65 <myl_rc_scope_unwind+0x95>
 1018cf5:	mov    0xf8(%rax),%rdi
 1018cfc:	cmp    %rbx,%rdi
 1018cff:	je     1018d6e <myl_rc_scope_unwind+0x9e>
 1018d01:	movabs $0xeffffffffffffffd,%r14
 1018d0b:	mov    %rdi,%rax
 1018d0e:	jmp    1018d19 <myl_rc_scope_unwind+0x49>
 1018d10:	mov    0x8(%rax),%rax
 1018d14:	cmp    %rbx,%rax
 1018d17:	je     1018d7d <myl_rc_scope_unwind+0xad>
 1018d19:	test   %rax,%rax
 1018d1c:	je     1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018d22:	mov    0x10(%rax),%rcx
 1018d26:	jmp    1018d3a <myl_rc_scope_unwind+0x6a>
 1018d28:	nopl   0x0(%rax,%rax,1)
 1018d30:	movl   $0x0,0x18(%rcx)
 1018d37:	mov    (%rcx),%rcx
 1018d3a:	test   %rcx,%rcx
 1018d3d:	je     1018d10 <myl_rc_scope_unwind+0x40>
 1018d3f:	cmpl   $0x0,0x18(%rcx)
 1018d43:	je     1018d30 <myl_rc_scope_unwind+0x60>
 1018d45:	mov    0x8(%rcx),%rdx
 1018d49:	test   %rdx,%rdx
 1018d4c:	je     1018d30 <myl_rc_scope_unwind+0x60>
 1018d4e:	mov    -0x10(%rdx),%rsi
 1018d52:	test   $0x2,%sil
 1018d56:	jne    1018d30 <myl_rc_scope_unwind+0x60>
 1018d58:	and    %r14,%rsi
 1018d5b:	or     0x10(%rcx),%rsi
 1018d5f:	mov    %rsi,-0x10(%rdx)
 1018d63:	jmp    1018d30 <myl_rc_scope_unwind+0x60>
 1018d65:	test   %rbx,%rbx
 1018d68:	jne    1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018d6e:	add    $0x8,%rsp
 1018d72:	pop    %rbx
 1018d73:	pop    %r12
 1018d75:	pop    %r13
 1018d77:	pop    %r14
 1018d79:	pop    %r15
 1018d7b:	pop    %rbp
 1018d7c:	ret
 1018d7d:	mov    %r12,-0x30(%rbp)
 1018d81:	jmp    1018da4 <myl_rc_scope_unwind+0xd4>
 1018d83:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018d90:	mov    0x1608(%r12),%rax
 1018d98:	mov    0xf8(%rax),%rdi
 1018d9f:	cmp    %rbx,%rdi
 1018da2:	je     1018d6e <myl_rc_scope_unwind+0x9e>
 1018da4:	test   %rdi,%rdi
 1018da7:	je     1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018dad:	cmpl   $0x0,0x18(%rdi)
 1018db1:	je     1018d90 <myl_rc_scope_unwind+0xc0>
 1018db3:	mov    (%rdi),%r15
 1018db6:	test   %r15,%r15
 1018db9:	je     1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018dbf:	mov    0x1608(%r15),%rax
 1018dc6:	test   %rax,%rax
 1018dc9:	je     1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018dcf:	cmp    %rdi,0xf8(%rax)
 1018dd6:	jne    1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018ddc:	mov    0x8(%rdi),%rcx
 1018de0:	mov    %rcx,0xf8(%rax)
 1018de7:	movl   $0x0,0x18(%rdi)
 1018dee:	movq   $0x0,0x8(%rdi)
 1018df6:	mov    0x10(%rdi),%rsi
 1018dfa:	test   %rsi,%rsi
 1018dfd:	je     1018f5d <myl_rc_scope_unwind+0x28d>
 1018e03:	cmpq   $0x0,(%rsi)
 1018e07:	jne    1018f7f <myl_rc_scope_unwind+0x2af>
 1018e0d:	cmpl   $0x0,0x18(%rsi)
 1018e11:	mov    0x8(%rsi),%r12
 1018e15:	je     1018e37 <myl_rc_scope_unwind+0x167>
 1018e17:	test   %r12,%r12
 1018e1a:	je     1018e34 <myl_rc_scope_unwind+0x164>
 1018e1c:	mov    -0x10(%r12),%rcx
 1018e21:	test   $0x2,%cl
 1018e24:	jne    1018e37 <myl_rc_scope_unwind+0x167>
 1018e26:	and    %r14,%rcx
 1018e29:	or     0x10(%rsi),%rcx
 1018e2d:	mov    %rcx,-0x10(%r12)
 1018e32:	jmp    1018e37 <myl_rc_scope_unwind+0x167>
 1018e34:	xor    %r12d,%r12d
 1018e37:	movq   $0x0,0x10(%rdi)
 1018e3f:	mov    0x20(%rsi),%r13
 1018e43:	mov    0x108(%rax),%rcx
 1018e4a:	cmp    $0x20,%rcx
 1018e4e:	je     1018f88 <myl_rc_scope_unwind+0x2b8>
 1018e54:	mov    0x18(%r15),%rdx
 1018e58:	cmp    $0x28,%rdx
 1018e5c:	jb     1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018e62:	mov    0x30(%rax),%rdi
 1018e66:	cmp    $0x27,%rdi
 1018e6a:	jbe    1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018e70:	add    $0xffffffffffffffd8,%rdx
 1018e74:	mov    %rdx,0x18(%r15)
 1018e78:	add    $0xffffffffffffffd8,%rdi
 1018e7c:	mov    %rdi,0x30(%rax)
 1018e80:	mov    0x100(%rax),%rdx
 1018e87:	mov    %rdx,(%rsi)
 1018e8a:	mov    %rsi,0x100(%rax)
 1018e91:	inc    %rcx
 1018e94:	mov    %rcx,0x108(%rax)
 1018e9b:	test   %r13,%r13
 1018e9e:	je     1018ef9 <myl_rc_scope_unwind+0x229>
 1018ea0:	mov    -0x10(%r13),%rcx
 1018ea4:	movabs $0x4000000000000002,%rax
 1018eae:	test   %rax,%rcx
 1018eb1:	jne    1018ee0 <myl_rc_scope_unwind+0x210>
 1018eb3:	mov    -0x18(%r13),%rax
 1018eb7:	test   %rax,%rax
 1018eba:	je     1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018ec0:	and    $0x1,%ecx
 1018ec3:	jne    1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018ec9:	dec    %rax
 1018ecc:	mov    %rax,-0x18(%r13)
 1018ed0:	jne    1018ee0 <myl_rc_scope_unwind+0x210>
 1018ed2:	cmpq   $0x0,-0x20(%r13)
 1018ed7:	je     1018f9e <myl_rc_scope_unwind+0x2ce>
 1018edd:	nopl   (%rax)
 1018ee0:	mov    0x1608(%r15),%rax
 1018ee7:	cmpq   $0x0,0xc8(%rax)
 1018eef:	je     1018ef9 <myl_rc_scope_unwind+0x229>
 1018ef1:	mov    %r15,%rdi
 1018ef4:	call   1016000 <myl_rc_drain>
 1018ef9:	test   %r12,%r12
 1018efc:	je     1018f40 <myl_rc_scope_unwind+0x270>
 1018efe:	mov    -0x10(%r12),%rcx
 1018f03:	movabs $0x4000000000000002,%rax
 1018f0d:	test   %rax,%rcx
 1018f10:	jne    1018f40 <myl_rc_scope_unwind+0x270>
 1018f12:	mov    -0x18(%r12),%rax
 1018f17:	test   %rax,%rax
 1018f1a:	je     1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018f20:	and    $0x1,%ecx
 1018f23:	jne    1018fc7 <myl_rc_scope_unwind+0x2f7>
 1018f29:	dec    %rax
 1018f2c:	mov    %rax,-0x18(%r12)
 1018f31:	jne    1018f40 <myl_rc_scope_unwind+0x270>
 1018f33:	cmpq   $0x0,-0x20(%r12)
 1018f39:	je     1018fb2 <myl_rc_scope_unwind+0x2e2>
 1018f3b:	nopl   0x0(%rax,%rax,1)
 1018f40:	mov    0x1608(%r15),%rax
 1018f47:	cmpq   $0x0,0xc8(%rax)
 1018f4f:	mov    -0x30(%rbp),%r12
 1018f53:	je     1018f5d <myl_rc_scope_unwind+0x28d>
 1018f55:	mov    %r15,%rdi
 1018f58:	call   1016000 <myl_rc_drain>
 1018f5d:	mov    0x1608(%r15),%rax
 1018f64:	cmpq   $0x0,0xc8(%rax)
 1018f6c:	je     1018d90 <myl_rc_scope_unwind+0xc0>
 1018f72:	mov    %r15,%rdi
 1018f75:	call   1016000 <myl_rc_drain>
 1018f7a:	jmp    1018d90 <myl_rc_scope_unwind+0xc0>
 1018f7f:	xor    %esi,%esi
 1018f81:	call   1019000 <unwind_many>
 1018f86:	jmp    1018f5d <myl_rc_scope_unwind+0x28d>
 1018f88:	mov    %r15,%rdi
 1018f8b:	call   1019273 <entry_release>
 1018f90:	test   %r13,%r13
 1018f93:	jne    1018ea0 <myl_rc_scope_unwind+0x1d0>
 1018f99:	jmp    1018ef9 <myl_rc_scope_unwind+0x229>
 1018f9e:	add    $0xffffffffffffffe0,%r13
 1018fa2:	mov    %r15,%rdi
 1018fa5:	mov    %r13,%rsi
 1018fa8:	call   10191fd <hold_death>
 1018fad:	jmp    1018ef9 <myl_rc_scope_unwind+0x229>
 1018fb2:	add    $0xffffffffffffffe0,%r12
 1018fb6:	mov    %r15,%rdi
 1018fb9:	mov    %r12,%rsi
 1018fbc:	call   10191fd <hold_death>
 1018fc1:	mov    -0x30(%rbp),%r12
 1018fc5:	jmp    1018f5d <myl_rc_scope_unwind+0x28d>
 1018fc7:	call   101246d <myl_rc_invariant_failed>
 1018fcc:	int3
 1018fcd:	int3
 1018fce:	int3
 1018fcf:	int3

0000000001018fd0 <myl_rc_scope_current>:
 1018fd0:	test   %rdi,%rdi
 1018fd3:	je     1018fee <myl_rc_scope_current+0x1e>
 1018fd5:	mov    0x1608(%rdi),%rax
 1018fdc:	test   %rax,%rax
 1018fdf:	je     1018fee <myl_rc_scope_current+0x1e>
 1018fe1:	push   %rbp
 1018fe2:	mov    %rsp,%rbp
 1018fe5:	mov    0xf8(%rax),%rax
 1018fec:	pop    %rbp
 1018fed:	ret
 1018fee:	xor    %eax,%eax
 1018ff0:	ret
 1018ff1:	int3
 1018ff2:	int3
 1018ff3:	int3
 1018ff4:	int3
 1018ff5:	int3
 1018ff6:	int3
 1018ff7:	int3
 1018ff8:	int3
 1018ff9:	int3
 1018ffa:	int3
 1018ffb:	int3
 1018ffc:	int3
 1018ffd:	int3
 1018ffe:	int3
 1018fff:	int3

0000000001019000 <unwind_many>:
 1019000:	push   %rbp
 1019001:	mov    %rsp,%rbp
 1019004:	push   %r15
 1019006:	push   %r14
 1019008:	push   %r13
 101900a:	push   %r12
 101900c:	push   %rbx
 101900d:	push   %rax
 101900e:	mov    %rsi,%rbx
 1019011:	mov    (%rdi),%r14
 1019014:	mov    0x10(%rdi),%r13
 1019018:	cmp    %rsi,%r13
 101901b:	je     101905e <unwind_many+0x5e>
 101901d:	movabs $0xeffffffffffffffd,%rax
 1019027:	mov    %r13,%rcx
 101902a:	jmp    1019038 <unwind_many+0x38>
 101902c:	nopl   0x0(%rax)
 1019030:	mov    (%rcx),%rcx
 1019033:	cmp    %rbx,%rcx
 1019036:	je     101905e <unwind_many+0x5e>
 1019038:	cmpl   $0x0,0x18(%rcx)
 101903c:	je     1019030 <unwind_many+0x30>
 101903e:	mov    0x8(%rcx),%rdx
 1019042:	test   %rdx,%rdx
 1019045:	je     1019030 <unwind_many+0x30>
 1019047:	mov    -0x10(%rdx),%rsi
 101904b:	test   $0x2,%sil
 101904f:	jne    1019030 <unwind_many+0x30>
 1019051:	and    %rax,%rsi
 1019054:	or     0x10(%rcx),%rsi
 1019058:	mov    %rsi,-0x10(%rdx)
 101905c:	jmp    1019030 <unwind_many+0x30>
 101905e:	mov    %rbx,0x10(%rdi)
 1019062:	jmp    1019089 <unwind_many+0x89>
 1019064:	add    $0xffffffffffffffe0,%r15
 1019068:	mov    %r14,%rdi
 101906b:	mov    %r15,%rsi
 101906e:	call   10191fd <hold_death>
 1019073:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019080:	cmp    %rbx,%r13
 1019083:	je     10191e9 <unwind_many+0x1e9>
 1019089:	mov    %r13,%rsi
 101908c:	mov    0x0(%r13),%r13
 1019090:	mov    0x8(%rsi),%r15
 1019094:	mov    0x20(%rsi),%r12
 1019098:	mov    0x1608(%r14),%rax
 101909f:	mov    0x108(%rax),%rcx
 10190a6:	cmp    $0x20,%rcx
 10190aa:	je     10191c2 <unwind_many+0x1c2>
 10190b0:	mov    0x18(%r14),%rdx
 10190b4:	cmp    $0x28,%rdx
 10190b8:	jb     10191f8 <unwind_many+0x1f8>
 10190be:	mov    0x30(%rax),%rdi
 10190c2:	cmp    $0x27,%rdi
 10190c6:	jbe    10191f8 <unwind_many+0x1f8>
 10190cc:	add    $0xffffffffffffffd8,%rdx
 10190d0:	mov    %rdx,0x18(%r14)
 10190d4:	add    $0xffffffffffffffd8,%rdi
 10190d8:	mov    %rdi,0x30(%rax)
 10190dc:	mov    0x100(%rax),%rdx
 10190e3:	mov    %rdx,(%rsi)
 10190e6:	mov    %rsi,0x100(%rax)
 10190ed:	inc    %rcx
 10190f0:	mov    %rcx,0x108(%rax)
 10190f7:	test   %r12,%r12
 10190fa:	je     1019159 <unwind_many+0x159>
 10190fc:	mov    -0x10(%r12),%rcx
 1019101:	movabs $0x4000000000000002,%rax
 101910b:	test   %rax,%rcx
 101910e:	jne    1019140 <unwind_many+0x140>
 1019110:	mov    -0x18(%r12),%rax
 1019115:	test   %rax,%rax
 1019118:	je     10191f8 <unwind_many+0x1f8>
 101911e:	and    $0x1,%ecx
 1019121:	jne    10191f8 <unwind_many+0x1f8>
 1019127:	dec    %rax
 101912a:	mov    %rax,-0x18(%r12)
 101912f:	jne    1019140 <unwind_many+0x140>
 1019131:	cmpq   $0x0,-0x20(%r12)
 1019137:	je     10191d5 <unwind_many+0x1d5>
 101913d:	nopl   (%rax)
 1019140:	mov    0x1608(%r14),%rax
 1019147:	cmpq   $0x0,0xc8(%rax)
 101914f:	je     1019159 <unwind_many+0x159>
 1019151:	mov    %r14,%rdi
 1019154:	call   1016000 <myl_rc_drain>
 1019159:	test   %r15,%r15
 101915c:	je     10191a0 <unwind_many+0x1a0>
 101915e:	mov    -0x10(%r15),%rcx
 1019162:	movabs $0x4000000000000002,%rax
 101916c:	test   %rax,%rcx
 101916f:	jne    10191a0 <unwind_many+0x1a0>
 1019171:	mov    -0x18(%r15),%rax
 1019175:	test   %rax,%rax
 1019178:	je     10191f8 <unwind_many+0x1f8>
 101917a:	and    $0x1,%ecx
 101917d:	jne    10191f8 <unwind_many+0x1f8>
 101917f:	dec    %rax
 1019182:	mov    %rax,-0x18(%r15)
 1019186:	jne    10191a0 <unwind_many+0x1a0>
 1019188:	cmpq   $0x0,-0x20(%r15)
 101918d:	je     1019064 <unwind_many+0x64>
 1019193:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10191a0:	mov    0x1608(%r14),%rax
 10191a7:	cmpq   $0x0,0xc8(%rax)
 10191af:	je     1019080 <unwind_many+0x80>
 10191b5:	mov    %r14,%rdi
 10191b8:	call   1016000 <myl_rc_drain>
 10191bd:	jmp    1019080 <unwind_many+0x80>
 10191c2:	mov    %r14,%rdi
 10191c5:	call   1019273 <entry_release>
 10191ca:	test   %r12,%r12
 10191cd:	jne    10190fc <unwind_many+0xfc>
 10191d3:	jmp    1019159 <unwind_many+0x159>
 10191d5:	add    $0xffffffffffffffe0,%r12
 10191d9:	mov    %r14,%rdi
 10191dc:	mov    %r12,%rsi
 10191df:	call   10191fd <hold_death>
 10191e4:	jmp    1019159 <unwind_many+0x159>
 10191e9:	add    $0x8,%rsp
 10191ed:	pop    %rbx
 10191ee:	pop    %r12
 10191f0:	pop    %r13
 10191f2:	pop    %r14
 10191f4:	pop    %r15
 10191f6:	pop    %rbp
 10191f7:	ret
 10191f8:	call   101246d <myl_rc_invariant_failed>

00000000010191fd <hold_death>:
 10191fd:	push   %rbp
 10191fe:	mov    %rsp,%rbp
 1019201:	push   %rbx
 1019202:	push   %rax
 1019203:	mov    0x10(%rsi),%rax
 1019207:	test   $0x1,%al
 1019209:	jne    101926e <hold_death+0x71>
 101920b:	mov    %rdi,%rbx
 101920e:	or     $0x1,%rax
 1019212:	mov    %rax,0x10(%rsi)
 1019216:	mov    0x1608(%rdi),%rax
 101921d:	cmpl   $0x0,0xd0(%rax)
 1019224:	je     1019240 <hold_death+0x43>
 1019226:	mov    0xc8(%rax),%rax
 101922d:	mov    %rax,(%rsi)
 1019230:	mov    0x1608(%rbx),%rax
 1019237:	mov    %rsi,0xc8(%rax)
 101923e:	jmp    1019259 <hold_death+0x5c>
 1019240:	mov    %rbx,%rdi
 1019243:	call   10128f0 <myl_rc_dead_outside>
 1019248:	mov    0x1608(%rbx),%rax
 101924f:	cmpq   $0x0,0xc8(%rax)
 1019257:	je     1019267 <hold_death+0x6a>
 1019259:	mov    %rbx,%rdi
 101925c:	add    $0x8,%rsp
 1019260:	pop    %rbx
 1019261:	pop    %rbp
 1019262:	jmp    1016000 <myl_rc_drain>
 1019267:	add    $0x8,%rsp
 101926b:	pop    %rbx
 101926c:	pop    %rbp
 101926d:	ret
 101926e:	call   101246d <myl_rc_invariant_failed>

0000000001019273 <entry_release>:
 1019273:	push   %rbp
 1019274:	mov    %rsp,%rbp
 1019277:	mov    $0x28,%edx
 101927c:	pop    %rbp
 101927d:	jmp    1012500 <myl_rc_meta_free>
 1019282:	int3
 1019283:	int3
 1019284:	int3
 1019285:	int3
 1019286:	int3
 1019287:	int3
 1019288:	int3
 1019289:	int3
 101928a:	int3
 101928b:	int3
 101928c:	int3
 101928d:	int3
 101928e:	int3
 101928f:	int3

0000000001019290 <transfer>:
 1019290:	push   %rbp
 1019291:	mov    %rsp,%rbp
 1019294:	push   %r15
 1019296:	push   %r14
 1019298:	push   %r13
 101929a:	push   %r12
 101929c:	push   %rbx
 101929d:	sub    $0x2b8,%rsp
 10192a4:	mov    %r9d,-0x50(%rbp)
 10192a8:	mov    %ecx,-0x2c(%rbp)
 10192ab:	test   %rdi,%rdi
 10192ae:	je     1019c9c <transfer+0xa0c>
 10192b4:	test   %rdx,%rdx
 10192b7:	je     1019c9c <transfer+0xa0c>
 10192bd:	mov    %rsi,%r15
 10192c0:	test   %rsi,%rsi
 10192c3:	je     1019c9c <transfer+0xa0c>
 10192c9:	mov    %r8d,%r14d
 10192cc:	mov    0x1608(%rdi),%r8
 10192d3:	test   %r8,%r8
 10192d6:	je     1019c9c <transfer+0xa0c>
 10192dc:	mov    0x8(%r15),%r12
 10192e0:	test   %r12,%r12
 10192e3:	je     1019c9c <transfer+0xa0c>
 10192e9:	mov    0x8(%rdx),%r13
 10192ed:	test   %r13,%r13
 10192f0:	je     1019c9c <transfer+0xa0c>
 10192f6:	movabs $0x9e3779b97f4a7c15,%rbx
 1019300:	mov    (%rdx),%r11
 1019303:	mov    0x58(%r8),%rax
 1019307:	mov    0x60(%r8),%rcx
 101930b:	mov    0x70(%r8),%r10d
 101930f:	mov    %r11,%r8
 1019312:	imul   %rbx,%r8
 1019316:	shrx   %r10,%r8,%r9
 101931b:	and    %rcx,%r9
 101931e:	mov    %r9,%r8
 1019321:	shl    $0x4,%r8
 1019325:	mov    (%rax,%r8,1),%r8
 1019329:	cmp    %r11,%r8
 101932c:	je     101934b <transfer+0xbb>
 101932e:	xor    %esi,%esi
 1019330:	test   %r8,%r8
 1019333:	je     1019354 <transfer+0xc4>
 1019335:	inc    %r9
 1019338:	and    %rcx,%r9
 101933b:	mov    %r9,%r8
 101933e:	shl    $0x4,%r8
 1019342:	mov    (%rax,%r8,1),%r8
 1019346:	cmp    %r11,%r8
 1019349:	jne    1019330 <transfer+0xa0>
 101934b:	shl    $0x4,%r9
 101934f:	mov    0x8(%rax,%r9,1),%rsi
 1019354:	mov    (%r15),%r11
 1019357:	mov    %r11,%r8
 101935a:	imul   %rbx,%r8
 101935e:	shrx   %r10,%r8,%r9
 1019363:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019370:	and    %rcx,%r9
 1019373:	mov    %r9,%r8
 1019376:	shl    $0x4,%r8
 101937a:	mov    (%rax,%r8,1),%r8
 101937e:	cmp    %r11,%r8
 1019381:	je     1019391 <transfer+0x101>
 1019383:	test   %r8,%r8
 1019386:	je     1019c9c <transfer+0xa0c>
 101938c:	inc    %r9
 101938f:	jmp    1019370 <transfer+0xe0>
 1019391:	test   %rsi,%rsi
 1019394:	je     1019c9c <transfer+0xa0c>
 101939a:	shl    $0x4,%r9
 101939e:	mov    0x8(%rax,%r9,1),%rax
 10193a3:	test   %rax,%rax
 10193a6:	je     1019c9c <transfer+0xa0c>
 10193ac:	mov    (%rsi),%rcx
 10193af:	cmp    (%rax),%rcx
 10193b2:	jne    1019c9c <transfer+0xa0c>
 10193b8:	cmp    %r12,%r13
 10193bb:	je     1019c9c <transfer+0xa0c>
 10193c1:	mov    %rdx,-0x98(%rbp)
 10193c8:	mov    0x18(%r15),%ecx
 10193cc:	mov    $0x3,%ebx
 10193d1:	cmp    0x70(%rdi),%ecx
 10193d4:	ja     1019a69 <transfer+0x7d9>
 10193da:	mov    -0x50(%rbp),%r9d
 10193de:	test   %r9d,%r9d
 10193e1:	mov    %rdi,-0x38(%rbp)
 10193e5:	mov    %rsi,-0x48(%rbp)
 10193e9:	je     1019404 <transfer+0x174>
 10193eb:	cmp    $0x1,%r9d
 10193ef:	setne  %al
 10193f2:	test   %r14d,%r14d
 10193f5:	setne  %dl
 10193f8:	or     %dl,%al
 10193fa:	je     1019441 <transfer+0x1b1>
 10193fc:	mov    %edx,-0x3c(%rbp)
 10193ff:	jmp    1019537 <transfer+0x2a7>
 1019404:	cmpl   $0x1,0x8(%rsi)
 1019408:	jne    1019433 <transfer+0x1a3>
 101940a:	mov    %r12,%rsi
 101940d:	mov    %r13,%rdx
 1019410:	mov    -0x2c(%rbp),%r8d
 1019414:	call   1019d50 <pointer_fast>
 1019419:	mov    -0x48(%rbp),%rsi
 101941d:	mov    -0x38(%rbp),%rdi
 1019421:	mov    %eax,%ebx
 1019423:	test   %eax,%eax
 1019425:	jns    1019a69 <transfer+0x7d9>
 101942b:	mov    0x18(%r15),%ecx
 101942f:	mov    -0x50(%rbp),%r9d
 1019433:	test   %r14d,%r14d
 1019436:	setne  %al
 1019439:	mov    %eax,-0x3c(%rbp)
 101943c:	jmp    1019537 <transfer+0x2a7>
 1019441:	cmpl   $0x1,0x8(%rsi)
 1019445:	jne    1019530 <transfer+0x2a0>
 101944b:	mov    0x0(%r13),%rbx
 101944f:	test   %rbx,%rbx
 1019452:	je     10194fd <transfer+0x26d>
 1019458:	mov    -0x10(%rbx),%rax
 101945c:	test   $0x2,%al
 101945e:	jne    10194fd <transfer+0x26d>
 1019464:	mov    %rax,%rdx
 1019467:	shr    $0x28,%rdx
 101946b:	and    $0xfffff,%edx
 1019471:	xor    %r8d,%r8d
 1019474:	bt     $0x3e,%rax
 1019479:	movl   $0x0,-0x3c(%rbp)
 1019480:	cmovae %r8d,%edx
 1019484:	bt     $0x3c,%rax
 1019489:	jb     1019537 <transfer+0x2a7>
 101948f:	cmp    %ecx,%edx
 1019491:	ja     1019537 <transfer+0x2a7>
 1019497:	movabs $0x4000000000000000,%rcx
 10194a1:	test   %rcx,%rax
 10194a4:	jne    10194d8 <transfer+0x248>
 10194a6:	or     -0x2c(%rbp),%edx
 10194a9:	jne    10194d8 <transfer+0x248>
 10194ab:	test   $0x1,%al
 10194ad:	jne    1019c9c <transfer+0xa0c>
 10194b3:	mov    -0x20(%rbx),%rcx
 10194b7:	cmp    $0xffffffffffffffff,%rcx
 10194bb:	je     1019c6b <transfer+0x9db>
 10194c1:	test   %rcx,%rcx
 10194c4:	jne    10194d1 <transfer+0x241>
 10194c6:	cmpq   $0x0,-0x18(%rbx)
 10194cb:	je     1019c9c <transfer+0xa0c>
 10194d1:	inc    %rcx
 10194d4:	mov    %rcx,-0x20(%rbx)
 10194d8:	bt     $0x3d,%rax
 10194dd:	jb     10194fd <transfer+0x26d>
 10194df:	mov    %rbx,%rdi
 10194e2:	call   101de80 <myl_rc_native_mutable>
 10194e7:	mov    -0x38(%rbp),%rdi
 10194eb:	test   %eax,%eax
 10194ed:	je     10194fd <transfer+0x26d>
 10194ef:	movabs $0x2000000000000000,%rax
 10194f9:	or     %rax,-0x10(%rbx)
 10194fd:	mov    %rbx,(%r12)
 1019501:	cmpl   $0x1,-0x2c(%rbp)
 1019505:	jne    101950f <transfer+0x27f>
 1019507:	movq   $0x0,0x0(%r13)
 101950f:	mov    0x1608(%rdi),%rax
 1019516:	xor    %ebx,%ebx
 1019518:	cmpq   $0x0,0xc8(%rax)
 1019520:	je     1019a69 <transfer+0x7d9>
 1019526:	call   1016000 <myl_rc_drain>
 101952b:	jmp    1019a69 <transfer+0x7d9>
 1019530:	movl   $0x0,-0x3c(%rbp)
 1019537:	vxorps %xmm0,%xmm0,%xmm0
 101953b:	vmovups %ymm0,-0x140(%rbp)
 1019543:	vmovups %ymm0,-0x160(%rbp)
 101954b:	vmovups %ymm0,-0x180(%rbp)
 1019553:	vmovups %ymm0,-0x1a0(%rbp)
 101955b:	vmovups %ymm0,-0x1c0(%rbp)
 1019563:	vmovups %ymm0,-0x1e0(%rbp)
 101956b:	movq   $0x0,-0x120(%rbp)
 1019576:	mov    %r14d,-0x138(%rbp)
 101957d:	mov    %r9d,-0x134(%rbp)
 1019584:	mov    %rdi,-0x88(%rbp)
 101958b:	lea    -0x2e0(%rbp),%rax
 1019592:	mov    %rax,-0x80(%rbp)
 1019596:	movq   $0x8,-0x78(%rbp)
 101959e:	movq   $0x0,-0x70(%rbp)
 10195a6:	mov    %ecx,-0x68(%rbp)
 10195a9:	mov    -0x2c(%rbp),%r12d
 10195ad:	mov    %r12d,-0x64(%rbp)
 10195b1:	lea    -0x1e0(%rbp),%rax
 10195b8:	mov    %rax,-0x60(%rbp)
 10195bc:	mov    0x28(%rsi),%rbx
 10195c0:	cmp    $0x9,%rbx
 10195c4:	jb     1019623 <transfer+0x393>
 10195c6:	mov    %rbx,%rax
 10195c9:	shr    $0x3b,%rax
 10195cd:	jne    1019c9c <transfer+0xa0c>
 10195d3:	mov    %rbx,%rsi
 10195d6:	shl    $0x5,%rsi
 10195da:	vzeroupper
 10195dd:	call   1012480 <myl_rc_meta_alloc>
 10195e2:	test   %rax,%rax
 10195e5:	je     1019a7d <transfer+0x7ed>
 10195eb:	mov    -0x78(%rbp),%rdx
 10195ef:	cmp    $0x9,%rdx
 10195f3:	jb     1019613 <transfer+0x383>
 10195f5:	mov    -0x88(%rbp),%rdi
 10195fc:	mov    -0x80(%rbp),%rsi
 1019600:	shl    $0x5,%rdx
 1019604:	mov    %rax,%r12
 1019607:	call   1012500 <myl_rc_meta_free>
 101960c:	mov    %r12,%rax
 101960f:	mov    -0x2c(%rbp),%r12d
 1019613:	mov    %rax,-0x80(%rbp)
 1019617:	mov    %rbx,-0x78(%rbp)
 101961b:	mov    -0x38(%rbp),%rdi
 101961f:	mov    -0x48(%rbp),%rsi
 1019623:	mov    0x8(%r15),%rax
 1019627:	mov    -0x98(%rbp),%rbx
 101962e:	mov    0x8(%rbx),%rcx
 1019632:	test   %r12d,%r12d
 1019635:	je     101964a <transfer+0x3ba>
 1019637:	mov    (%rsi),%rdx
 101963a:	mov    %rax,%rdi
 101963d:	mov    %rcx,%rsi
 1019640:	vzeroupper
 1019643:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 1019648:	jmp    101965b <transfer+0x3cb>
 101964a:	mov    $0x1,%r8d
 1019650:	mov    %rax,%rdx
 1019653:	vzeroupper
 1019656:	call   1016a40 <myl_rc_value_seed>
 101965b:	cmpl   $0x2,-0x50(%rbp)
 101965f:	mov    -0x48(%rbp),%rsi
 1019663:	jne    1019762 <transfer+0x4d2>
 1019669:	cmpl   $0x1,0x8(%rsi)
 101966d:	jne    1019762 <transfer+0x4d2>
 1019673:	mov    0x8(%r15),%rdx
 1019677:	mov    0x8(%rbx),%rax
 101967b:	mov    (%rax),%rsi
 101967e:	test   %rsi,%rsi
 1019681:	je     1019acb <transfer+0x83b>
 1019687:	mov    -0x10(%rsi),%rax
 101968b:	mov    %rax,%rcx
 101968e:	shr    $0x28,%rcx
 1019692:	and    $0xfffff,%ecx
 1019698:	xor    %edi,%edi
 101969a:	bt     $0x3e,%rax
 101969f:	cmovb  %ecx,%edi
 10196a2:	mov    $0x3,%ebx
 10196a7:	cmp    -0x68(%rbp),%edi
 10196aa:	mov    -0x38(%rbp),%r8
 10196ae:	ja     1019783 <transfer+0x4f3>
 10196b4:	mov    %edi,-0x54(%rbp)
 10196b7:	mov    -0x88(%rbp),%rdi
 10196be:	mov    %rsi,-0x90(%rbp)
 10196c5:	mov    -0x8(%rsi),%rsi
 10196c9:	mov    0x1608(%rdi),%rcx
 10196d0:	mov    0x34(%rsi),%eax
 10196d3:	cmp    %rax,0xa0(%rcx)
 10196da:	jbe    1019ca4 <transfer+0xa14>
 10196e0:	mov    0x98(%rcx),%rcx
 10196e7:	shl    $0x4,%rax
 10196eb:	cmp    %rsi,(%rcx,%rax,1)
 10196ef:	jne    1019ca4 <transfer+0xa14>
 10196f5:	add    %rax,%rcx
 10196f8:	mov    0x8(%rcx),%r12
 10196fc:	mov    %rdx,-0xa0(%rbp)
 1019703:	test   %r12,%r12
 1019706:	mov    -0x90(%rbp),%rax
 101970d:	mov    -0x54(%rbp),%ecx
 1019710:	je     1019c9c <transfer+0xa0c>
 1019716:	cmpq   $0x0,0x18(%r12)
 101971c:	jne    1019c9c <transfer+0xa0c>
 1019722:	mov    %rax,-0xc8(%rbp)
 1019729:	mov    %rax,-0xc0(%rbp)
 1019730:	mov    %r12,-0xb8(%rbp)
 1019737:	movq   $0x0,-0xb0(%rbp)
 1019742:	mov    %ecx,-0xa8(%rbp)
 1019748:	movl   $0x0,-0xa4(%rbp)
 1019752:	lea    0x19a7(%rip),%r13        # 101b100 <inspect_child>
 1019759:	mov    %r12,-0x50(%rbp)
 101975d:	jmp    101982f <transfer+0x59f>
 1019762:	mov    0x8(%r15),%rdx
 1019766:	mov    0x8(%rbx),%rcx
 101976a:	lea    0x121f(%rip),%r8        # 101a990 <transfer_pointer>
 1019771:	lea    -0x88(%rbp),%rdi
 1019778:	call   1019e60 <visit>
 101977d:	mov    %eax,%ebx
 101977f:	mov    -0x38(%rbp),%r8
 1019783:	test   %ebx,%ebx
 1019785:	je     1019798 <transfer+0x508>
 1019787:	mov    -0x60(%rbp),%rax
 101978b:	movq   $0x0,0xb8(%rax)
 1019796:	jmp    10197c1 <transfer+0x531>
 1019798:	lea    -0x88(%rbp),%rdi
 101979f:	call   101aaa0 <finish_clones>
 10197a4:	mov    %eax,%ebx
 10197a6:	mov    -0x60(%rbp),%rax
 10197aa:	test   %ebx,%ebx
 10197ac:	je     1019a84 <transfer+0x7f4>
 10197b2:	movq   $0x0,0xb8(%rax)
 10197bd:	mov    -0x38(%rbp),%r8
 10197c1:	mov    -0x48(%rbp),%rsi
 10197c5:	mov    0x8(%r15),%rdx
 10197c9:	test   %r12d,%r12d
 10197cc:	je     1019a3a <transfer+0x7aa>
 10197d2:	mov    -0x98(%rbp),%rax
 10197d9:	mov    0x8(%rax),%rcx
 10197dd:	lea    0x189c(%rip),%r8        # 101b080 <rollback_take>
 10197e4:	lea    -0x88(%rbp),%rdi
 10197eb:	mov    %rsi,%r14
 10197ee:	call   1019e60 <visit>
 10197f3:	jmp    1019a4a <transfer+0x7ba>
 10197f8:	mov    %r13,-0x80(%rbp)
 10197fc:	mov    %r14,-0x78(%rbp)
 1019800:	mov    %r12,%r13
 1019803:	mov    -0x50(%rbp),%r12
 1019807:	mov    -0xe8(%rbp),%rcx
 101980e:	lea    -0x88(%rbp),%rdi
 1019815:	mov    %rbx,%rsi
 1019818:	mov    %rcx,%rdx
 101981b:	mov    %r13,%r8
 101981e:	call   1019e60 <visit>
 1019823:	test   %eax,%eax
 1019825:	mov    -0x38(%rbp),%r8
 1019829:	jne    1019c4e <transfer+0x9be>
 101982f:	cmpq   $0x0,0x30(%r12)
 1019835:	movabs $0x9e3779b97f4a7c15,%rbx
 101983f:	je     1019ad9 <transfer+0x849>
 1019845:	mov    -0xc8(%rbp),%rsi
 101984c:	mov    -0xb8(%rbp),%rax
 1019853:	mov    0x30(%rax),%r10
 1019857:	test   %r10,%r10
 101985a:	je     101989a <transfer+0x60a>
 101985c:	mov    -0x88(%rbp),%rdi
 1019863:	mov    -0xc0(%rbp),%rdx
 101986a:	lea    -0xb0(%rbp),%rcx
 1019871:	lea    -0x110(%rbp),%r8
 1019878:	lea    -0xf0(%rbp),%r9
 101987f:	call   *%r10
 1019882:	mov    -0x38(%rbp),%r8
 1019886:	test   %eax,%eax
 1019888:	je     1019ad9 <transfer+0x849>
 101988e:	mov    -0xf0(%rbp),%rax
 1019895:	jmp    101994b <transfer+0x6bb>
 101989a:	mov    -0xb0(%rbp),%rcx
 10198a1:	mov    -0x10(%rsi),%rdx
 10198a5:	mov    %rdx,%rdi
 10198a8:	shr    $0x2,%rdi
 10198ac:	movabs $0x4000000000000000,%r9
 10198b6:	test   %r9,%rdx
 10198b9:	movabs $0x3fffffffff,%rdx
 10198c3:	movabs $0x3ffffffffffffff,%r9
 10198cd:	cmove  %r9,%rdx
 10198d1:	and    %rdi,%rdx
 10198d4:	cmp    %rdx,%rcx
 10198d7:	je     1019ad9 <transfer+0x849>
 10198dd:	mov    0x8(%rax),%rax
 10198e1:	lea    0x1(%rcx),%rdx
 10198e5:	mov    %rdx,-0xb0(%rbp)
 10198ec:	imul   (%rax),%rcx
 10198f0:	mov    -0xc0(%rbp),%rdx
 10198f7:	lea    (%rdx,%rcx,1),%rdi
 10198fb:	mov    -0xa8(%rbp),%r8d
 1019902:	mov    %rax,-0x110(%rbp)
 1019909:	mov    %rdi,-0x108(%rbp)
 1019910:	mov    %rdx,-0x100(%rbp)
 1019917:	mov    %r8d,-0xf8(%rbp)
 101991e:	movl   $0x0,-0xf4(%rbp)
 1019928:	add    %rsi,%rcx
 101992b:	mov    %rax,-0xf0(%rbp)
 1019932:	mov    %rcx,-0xe8(%rbp)
 1019939:	mov    %rsi,-0xe0(%rbp)
 1019940:	movq   $0x0,-0xd8(%rbp)
 101994b:	mov    -0x88(%rbp),%rdi
 1019952:	mov    0x1608(%rdi),%rsi
 1019959:	mov    0x58(%rsi),%rcx
 101995d:	mov    0x60(%rsi),%rdx
 1019961:	movzbl 0x70(%rsi),%esi
 1019965:	mov    %rax,%r8
 1019968:	imul   %rbx,%r8
 101996c:	shrx   %rsi,%r8,%rsi
 1019971:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019980:	and    %rdx,%rsi
 1019983:	mov    %rsi,%r8
 1019986:	shl    $0x4,%r8
 101998a:	mov    (%rcx,%r8,1),%r8
 101998e:	cmp    %rax,%r8
 1019991:	je     10199b0 <transfer+0x720>
 1019993:	test   %r8,%r8
 1019996:	je     1019c9c <transfer+0xa0c>
 101999c:	inc    %rsi
 101999f:	jmp    1019980 <transfer+0x6f0>
 10199a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10199b0:	shl    $0x4,%rsi
 10199b4:	mov    0x8(%rcx,%rsi,1),%rbx
 10199b9:	test   %rbx,%rbx
 10199bc:	je     1019c9c <transfer+0xa0c>
 10199c2:	mov    0x28(%rbx),%r14
 10199c6:	cmp    $0x2,%r14
 10199ca:	jb     1019807 <transfer+0x577>
 10199d0:	cmp    -0x78(%rbp),%r14
 10199d4:	jbe    1019807 <transfer+0x577>
 10199da:	cmpq   $0x0,-0x70(%rbp)
 10199df:	jne    1019c9c <transfer+0xa0c>
 10199e5:	movabs $0x7ffffffffffffff,%rax
 10199ef:	cmp    %rax,%r14
 10199f2:	ja     1019c9c <transfer+0xa0c>
 10199f8:	mov    %r13,%r12
 10199fb:	mov    %r14,%rsi
 10199fe:	shl    $0x5,%rsi
 1019a02:	call   1012480 <myl_rc_meta_alloc>
 1019a07:	test   %rax,%rax
 1019a0a:	je     1019c59 <transfer+0x9c9>
 1019a10:	mov    %rax,%r13
 1019a13:	mov    -0x78(%rbp),%rdx
 1019a17:	cmp    $0x9,%rdx
 1019a1b:	jb     10197f8 <transfer+0x568>
 1019a21:	mov    -0x88(%rbp),%rdi
 1019a28:	mov    -0x80(%rbp),%rsi
 1019a2c:	shl    $0x5,%rdx
 1019a30:	call   1012500 <myl_rc_meta_free>
 1019a35:	jmp    10197f8 <transfer+0x568>
 1019a3a:	mov    $0x1,%ecx
 1019a3f:	mov    %r8,%rdi
 1019a42:	mov    %rsi,%r14
 1019a45:	call   10159a0 <myl_rc_edges_release>
 1019a4a:	mov    0x8(%r15),%rdi
 1019a4e:	mov    (%r14),%rdx
 1019a51:	xor    %esi,%esi
 1019a53:	call   101e4a0 <compiler_rt.fastMemset>
 1019a58:	mov    $0x1,%esi
 1019a5d:	lea    -0x88(%rbp),%rdi
 1019a64:	call   101a170 <dispose_walk>
 1019a69:	mov    %ebx,%eax
 1019a6b:	add    $0x2b8,%rsp
 1019a72:	pop    %rbx
 1019a73:	pop    %r12
 1019a75:	pop    %r13
 1019a77:	pop    %r14
 1019a79:	pop    %r15
 1019a7b:	pop    %rbp
 1019a7c:	ret
 1019a7d:	mov    $0x1,%ebx
 1019a82:	jmp    1019a69 <transfer+0x7d9>
 1019a84:	mov    0xb8(%rax),%rdi
 1019a8b:	test   %rdi,%rdi
 1019a8e:	mov    -0x38(%rbp),%r10
 1019a92:	mov    -0x98(%rbp),%rbx
 1019a99:	mov    -0x48(%rbp),%rsi
 1019a9d:	je     1019bb0 <transfer+0x920>
 1019aa3:	movabs $0x2000000000000000,%rcx
 1019aad:	mov    0xb0(%rax),%r11
 1019ab4:	mov    %edi,%edx
 1019ab6:	and    $0x3,%edx
 1019ab9:	cmp    $0x4,%rdi
 1019abd:	jae    1019b58 <transfer+0x8c8>
 1019ac3:	xor    %r8d,%r8d
 1019ac6:	jmp    1019b91 <transfer+0x901>
 1019acb:	mov    -0x38(%rbp),%r8
 1019acf:	mov    %rsi,(%rdx)
 1019ad2:	xor    %ebx,%ebx
 1019ad4:	jmp    1019783 <transfer+0x4f3>
 1019ad9:	mov    -0x60(%rbp),%rax
 1019add:	mov    0xac(%rax),%ecx
 1019ae3:	mov    %ecx,%edx
 1019ae5:	and    $0xfffffffb,%edx
 1019ae8:	mov    %edx,0xac(%rax)
 1019aee:	test   $0x4,%cl
 1019af1:	jne    1019c0e <transfer+0x97e>
 1019af7:	cmpl   $0x0,-0x64(%rbp)
 1019afb:	mov    -0x2c(%rbp),%r12d
 1019aff:	mov    -0xa0(%rbp),%rdx
 1019b06:	mov    -0x90(%rbp),%rsi
 1019b0d:	jne    1019acf <transfer+0x83f>
 1019b0f:	mov    -0x10(%rsi),%rax
 1019b13:	movabs $0x4000000000000000,%rcx
 1019b1d:	add    $0x2,%rcx
 1019b21:	test   %rcx,%rax
 1019b24:	jne    1019acf <transfer+0x83f>
 1019b26:	test   $0x1,%al
 1019b28:	jne    1019c9c <transfer+0xa0c>
 1019b2e:	mov    -0x20(%rsi),%rax
 1019b32:	cmp    $0xffffffffffffffff,%rax
 1019b36:	je     1019c92 <transfer+0xa02>
 1019b3c:	test   %rax,%rax
 1019b3f:	jne    1019b4c <transfer+0x8bc>
 1019b41:	cmpq   $0x0,-0x18(%rsi)
 1019b46:	je     1019c9c <transfer+0xa0c>
 1019b4c:	inc    %rax
 1019b4f:	mov    %rax,-0x20(%rsi)
 1019b53:	jmp    1019acf <transfer+0x83f>
 1019b58:	and    $0xfffffffffffffffc,%rdi
 1019b5c:	xor    %r8d,%r8d
 1019b5f:	nop
 1019b60:	mov    (%r11,%r8,8),%r9
 1019b64:	or     %rcx,-0x10(%r9)
 1019b68:	mov    0x8(%r11,%r8,8),%r9
 1019b6d:	or     %rcx,-0x10(%r9)
 1019b71:	mov    0x10(%r11,%r8,8),%r9
 1019b76:	or     %rcx,-0x10(%r9)
 1019b7a:	mov    0x18(%r11,%r8,8),%r9
 1019b7f:	or     %rcx,-0x10(%r9)
 1019b83:	add    $0x4,%r8
 1019b87:	cmp    %r8,%rdi
 1019b8a:	jne    1019b60 <transfer+0x8d0>
 1019b8c:	test   %rdx,%rdx
 1019b8f:	je     1019bb0 <transfer+0x920>
 1019b91:	lea    (%r11,%r8,8),%r9
 1019b95:	xor    %edi,%edi
 1019b97:	nopw   0x0(%rax,%rax,1)
 1019ba0:	mov    (%r9,%rdi,8),%r8
 1019ba4:	or     %rcx,-0x10(%r8)
 1019ba8:	inc    %rdi
 1019bab:	cmp    %rdi,%rdx
 1019bae:	jne    1019ba0 <transfer+0x910>
 1019bb0:	movq   $0x0,0xb8(%rax)
 1019bbb:	cmp    $0x1,%r12d
 1019bbf:	jne    1019bf1 <transfer+0x961>
 1019bc1:	mov    0x8(%r15),%rdx
 1019bc5:	mov    0x8(%rbx),%rcx
 1019bc9:	lea    0x14f0(%rip),%r8        # 101b0c0 <commit_take>
 1019bd0:	lea    -0x88(%rbp),%rdi
 1019bd7:	mov    %rsi,%r14
 1019bda:	call   1019e60 <visit>
 1019bdf:	mov    0x8(%rbx),%rdi
 1019be3:	mov    (%r14),%rdx
 1019be6:	xor    %esi,%esi
 1019be8:	call   101e4a0 <compiler_rt.fastMemset>
 1019bed:	mov    -0x38(%rbp),%r10
 1019bf1:	xor    %ebx,%ebx
 1019bf3:	cmpb   $0x0,-0x3c(%rbp)
 1019bf7:	je     1019c07 <transfer+0x977>
 1019bf9:	mov    -0x148(%rbp),%rax
 1019c00:	add    %rax,0x88(%r10)
 1019c07:	xor    %esi,%esi
 1019c09:	jmp    1019a5d <transfer+0x7cd>
 1019c0e:	lea    -0x88(%rbp),%rdi
 1019c15:	lea    -0xd0(%rbp),%rcx
 1019c1c:	mov    -0x90(%rbp),%rsi
 1019c23:	mov    -0x54(%rbp),%edx
 1019c26:	call   101b130 <schedule_clone>
 1019c2b:	test   %eax,%eax
 1019c2d:	mov    -0x2c(%rbp),%r12d
 1019c31:	jne    101977d <transfer+0x4ed>
 1019c37:	mov    -0xd0(%rbp),%rsi
 1019c3e:	mov    -0x38(%rbp),%r8
 1019c42:	mov    -0xa0(%rbp),%rdx
 1019c49:	jmp    1019acf <transfer+0x83f>
 1019c4e:	mov    %eax,%ebx
 1019c50:	mov    -0x2c(%rbp),%r12d
 1019c54:	jmp    1019783 <transfer+0x4f3>
 1019c59:	mov    $0x1,%ebx
 1019c5e:	mov    -0x38(%rbp),%r8
 1019c62:	mov    -0x2c(%rbp),%r12d
 1019c66:	jmp    1019783 <transfer+0x4f3>
 1019c6b:	movq   $0x0,(%r12)
 1019c73:	mov    0x1608(%rdi),%rax
 1019c7a:	mov    $0x2,%ebx
 1019c7f:	cmpq   $0x0,0xc8(%rax)
 1019c87:	jne    1019526 <transfer+0x296>
 1019c8d:	jmp    1019a69 <transfer+0x7d9>
 1019c92:	mov    $0x2,%ebx
 1019c97:	jmp    1019783 <transfer+0x4f3>
 1019c9c:	vzeroupper
 1019c9f:	call   101246d <myl_rc_invariant_failed>
 1019ca4:	call   1012eea <myl_rc_binding_find_slow>
 1019ca9:	mov    -0x38(%rbp),%r8
 1019cad:	mov    %rax,%r12
 1019cb0:	jmp    10196fc <transfer+0x46c>
 1019cb5:	int3
 1019cb6:	int3
 1019cb7:	int3
 1019cb8:	int3
 1019cb9:	int3
 1019cba:	int3
 1019cbb:	int3
 1019cbc:	int3
 1019cbd:	int3
 1019cbe:	int3
 1019cbf:	int3

0000000001019cc0 <myl_rc_pointer_transfer>:
 1019cc0:	push   %rbp
 1019cc1:	mov    %rsp,%rbp
 1019cc4:	push   %r15
 1019cc6:	push   %r14
 1019cc8:	push   %r13
 1019cca:	push   %r12
 1019ccc:	push   %rbx
 1019ccd:	sub    $0x48,%rsp
 1019cd1:	mov    %r9d,%ebx
 1019cd4:	mov    %r8d,%r12d
 1019cd7:	mov    %rcx,%r15
 1019cda:	mov    %rdx,%r13
 1019cdd:	mov    %rsi,-0x30(%rbp)
 1019ce1:	mov    %rdi,%r14
 1019ce4:	mov    %rdx,%rsi
 1019ce7:	mov    %rcx,%rdx
 1019cea:	mov    %r8d,%ecx
 1019ced:	mov    %r9d,%r8d
 1019cf0:	call   1019d50 <pointer_fast>
 1019cf5:	test   %eax,%eax
 1019cf7:	jns    1019d41 <myl_rc_pointer_transfer+0x81>
 1019cf9:	mov    -0x30(%rbp),%rax
 1019cfd:	mov    %rax,-0x50(%rbp)
 1019d01:	mov    %r13,-0x48(%rbp)
 1019d05:	movq   $0x0,-0x40(%rbp)
 1019d0d:	mov    %r12d,-0x38(%rbp)
 1019d11:	movl   $0x0,-0x34(%rbp)
 1019d18:	mov    %rax,-0x70(%rbp)
 1019d1c:	mov    %r15,-0x68(%rbp)
 1019d20:	vxorps %xmm0,%xmm0,%xmm0
 1019d24:	vmovups %xmm0,-0x60(%rbp)
 1019d29:	lea    -0x50(%rbp),%rsi
 1019d2d:	lea    -0x70(%rbp),%rdx
 1019d31:	mov    %r14,%rdi
 1019d34:	mov    %ebx,%ecx
 1019d36:	xor    %r8d,%r8d
 1019d39:	xor    %r9d,%r9d
 1019d3c:	call   1019290 <transfer>
 1019d41:	add    $0x48,%rsp
 1019d45:	pop    %rbx
 1019d46:	pop    %r12
 1019d48:	pop    %r13
 1019d4a:	pop    %r14
 1019d4c:	pop    %r15
 1019d4e:	pop    %rbp
 1019d4f:	ret

0000000001019d50 <pointer_fast>:
 1019d50:	push   %rbp
 1019d51:	mov    %rsp,%rbp
 1019d54:	push   %r15
 1019d56:	push   %r14
 1019d58:	push   %rbx
 1019d59:	push   %rax
 1019d5a:	test   %rdi,%rdi
 1019d5d:	je     1019e59 <pointer_fast+0x109>
 1019d63:	cmp    %rdx,%rsi
 1019d66:	je     1019e59 <pointer_fast+0x109>
 1019d6c:	test   %rdx,%rdx
 1019d6f:	je     1019e59 <pointer_fast+0x109>
 1019d75:	test   %rsi,%rsi
 1019d78:	je     1019e59 <pointer_fast+0x109>
 1019d7e:	cmpq   $0x0,0x1608(%rdi)
 1019d86:	je     1019e59 <pointer_fast+0x109>
 1019d8c:	mov    $0x3,%eax
 1019d91:	cmp    0x70(%rdi),%ecx
 1019d94:	ja     1019e0c <pointer_fast+0xbc>
 1019d96:	mov    (%rdx),%rbx
 1019d99:	test   %rbx,%rbx
 1019d9c:	je     1019de0 <pointer_fast+0x90>
 1019d9e:	mov    -0x10(%rbx),%r9
 1019da2:	test   $0x2,%r9b
 1019da6:	jne    1019de0 <pointer_fast+0x90>
 1019da8:	mov    %r9,%rax
 1019dab:	shr    $0x28,%rax
 1019daf:	and    $0xfffff,%eax
 1019db4:	xor    %r10d,%r10d
 1019db7:	bt     $0x3e,%r9
 1019dbc:	cmovb  %eax,%r10d
 1019dc0:	cmp    %ecx,%r10d
 1019dc3:	seta   %cl
 1019dc6:	mov    %r9,%r11
 1019dc9:	shr    $0x3c,%r11
 1019dcd:	and    $0x1,%r11d
 1019dd1:	mov    $0xffffffff,%eax
 1019dd6:	or     %cl,%r11b
 1019dd9:	jne    1019e0c <pointer_fast+0xbc>
 1019ddb:	test   %r8d,%r8d
 1019dde:	je     1019e17 <pointer_fast+0xc7>
 1019de0:	mov    %rbx,(%rsi)
 1019de3:	xor    %eax,%eax
 1019de5:	cmp    $0x1,%r8d
 1019de9:	jne    1019df2 <pointer_fast+0xa2>
 1019deb:	movq   $0x0,(%rdx)
 1019df2:	mov    0x1608(%rdi),%rcx
 1019df9:	cmpq   $0x0,0xc8(%rcx)
 1019e01:	je     1019e0c <pointer_fast+0xbc>
 1019e03:	mov    %eax,%ebx
 1019e05:	call   1016000 <myl_rc_drain>
 1019e0a:	mov    %ebx,%eax
 1019e0c:	add    $0x8,%rsp
 1019e10:	pop    %rbx
 1019e11:	pop    %r14
 1019e13:	pop    %r15
 1019e15:	pop    %rbp
 1019e16:	ret
 1019e17:	test   %r10d,%r10d
 1019e1a:	je     1019e34 <pointer_fast+0xe4>
 1019e1c:	movabs $0x2000000000000000,%rax
 1019e26:	or     %rax,%r9
 1019e29:	mov    %r9,-0x10(%rbx)
 1019e2d:	mov    %rbx,(%rsi)
 1019e30:	xor    %eax,%eax
 1019e32:	jmp    1019df2 <pointer_fast+0xa2>
 1019e34:	mov    %rsi,%r15
 1019e37:	mov    %rdi,%r14
 1019e3a:	mov    %rbx,%rdi
 1019e3d:	call   1012420 <myl_rc_owner_take>
 1019e42:	test   %eax,%eax
 1019e44:	je     1019e4f <pointer_fast+0xff>
 1019e46:	movq   $0x0,(%r15)
 1019e4d:	jmp    1019e54 <pointer_fast+0x104>
 1019e4f:	mov    %rbx,(%r15)
 1019e52:	xor    %eax,%eax
 1019e54:	mov    %r14,%rdi
 1019e57:	jmp    1019df2 <pointer_fast+0xa2>
 1019e59:	call   101246d <myl_rc_invariant_failed>
 1019e5e:	int3
 1019e5f:	int3

0000000001019e60 <visit>:
 1019e60:	push   %rbp
 1019e61:	mov    %rsp,%rbp
 1019e64:	push   %r15
 1019e66:	push   %r14
 1019e68:	push   %r13
 1019e6a:	push   %r12
 1019e6c:	push   %rbx
 1019e6d:	sub    $0x38,%rsp
 1019e71:	mov    %rdi,%rbx
 1019e74:	movq   $0x0,0x18(%rdi)
 1019e7c:	mov    0x8(%rsi),%r13d
 1019e80:	mov    %r13d,%eax
 1019e83:	or     $0x4,%eax
 1019e86:	cmp    $0x5,%eax
 1019e89:	jne    1019ea8 <visit+0x48>
 1019e8b:	mov    %rbx,%rdi
 1019e8e:	mov    %rdx,%rsi
 1019e91:	mov    %rcx,%rdx
 1019e94:	mov    %r13d,%ecx
 1019e97:	add    $0x38,%rsp
 1019e9b:	pop    %rbx
 1019e9c:	pop    %r12
 1019e9e:	pop    %r13
 1019ea0:	pop    %r14
 1019ea2:	pop    %r15
 1019ea4:	pop    %rbp
 1019ea5:	jmp    *%r8
 1019ea8:	cmpq   $0x2,0x28(%rsi)
 1019ead:	mov    %r8,-0x38(%rbp)
 1019eb1:	jbe    101a011 <visit+0x1b1>
 1019eb7:	test   %r13d,%r13d
 1019eba:	je     101a14d <visit+0x2ed>
 1019ec0:	cmpq   $0x0,0x10(%rbx)
 1019ec5:	je     101a168 <visit+0x308>
 1019ecb:	mov    0x8(%rbx),%rax
 1019ecf:	movq   $0x1,0x18(%rbx)
 1019ed7:	mov    %rsi,(%rax)
 1019eda:	mov    %rdx,0x8(%rax)
 1019ede:	mov    %rcx,0x10(%rax)
 1019ee2:	movq   $0x0,0x18(%rax)
 1019eea:	mov    0x18(%rbx),%rax
 1019eee:	test   %rax,%rax
 1019ef1:	je     101a14d <visit+0x2ed>
 1019ef7:	mov    0x8(%rbx),%rcx
 1019efb:	mov    %rax,%rsi
 1019efe:	shl    $0x5,%rsi
 1019f02:	lea    (%rcx,%rsi,1),%rdx
 1019f06:	mov    -0x20(%rcx,%rsi,1),%rsi
 1019f0b:	mov    0x8(%rsi),%ecx
 1019f0e:	cmp    $0x5,%ecx
 1019f11:	je     1019f1d <visit+0xbd>
 1019f13:	cmp    $0x3,%ecx
 1019f16:	je     1019f50 <visit+0xf0>
 1019f18:	cmp    $0x1,%ecx
 1019f1b:	jne    1019f60 <visit+0x100>
 1019f1d:	mov    -0x18(%rdx),%rsi
 1019f21:	mov    -0x10(%rdx),%rdx
 1019f25:	mov    %rbx,%rdi
 1019f28:	call   *%r8
 1019f2b:	test   %eax,%eax
 1019f2d:	jne    101a15e <visit+0x2fe>
 1019f33:	mov    0x18(%rbx),%rax
 1019f37:	dec    %rax
 1019f3a:	mov    %rax,0x18(%rbx)
 1019f3e:	mov    -0x38(%rbp),%r8
 1019f42:	jmp    1019eee <visit+0x8e>
 1019f44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019f50:	mov    -0x8(%rdx),%rcx
 1019f54:	cmp    0x18(%rsi),%rcx
 1019f58:	je     1019f6a <visit+0x10a>
 1019f5a:	jmp    1019f76 <visit+0x116>
 1019f5c:	nopl   0x0(%rax)
 1019f60:	mov    -0x8(%rdx),%rdi
 1019f64:	cmp    0x18(%rsi),%rdi
 1019f68:	jne    1019fa2 <visit+0x142>
 1019f6a:	dec    %rax
 1019f6d:	mov    %rax,0x18(%rbx)
 1019f71:	jmp    1019eee <visit+0x8e>
 1019f76:	lea    0x1(%rcx),%rdi
 1019f7a:	mov    %rdi,-0x8(%rdx)
 1019f7e:	mov    0x10(%rsi),%r10
 1019f82:	cmpl   $0x0,0x8(%r10)
 1019f87:	je     1019eea <visit+0x8a>
 1019f8d:	cmp    0x10(%rbx),%rax
 1019f91:	jae    101a168 <visit+0x308>
 1019f97:	imul   0x20(%rsi),%rcx
 1019f9c:	mov    -0x10(%rdx),%rdi
 1019fa0:	jmp    1019feb <visit+0x18b>
 1019fa2:	lea    (%rdi,%rdi,2),%r9
 1019fa6:	shl    $0x3,%r9
 1019faa:	add    0x10(%rsi),%r9
 1019fae:	inc    %rdi
 1019fb1:	mov    %rdi,-0x8(%rdx)
 1019fb5:	mov    -0x10(%rdx),%rdi
 1019fb9:	cmp    $0x4,%ecx
 1019fbc:	jne    1019fcf <visit+0x16f>
 1019fbe:	mov    0x20(%rsi),%rcx
 1019fc2:	mov    (%rdi,%rcx,1),%ecx
 1019fc5:	cmp    0x10(%r9),%ecx
 1019fc9:	jne    1019eea <visit+0x8a>
 1019fcf:	mov    0x8(%r9),%r10
 1019fd3:	cmpl   $0x0,0x8(%r10)
 1019fd8:	je     1019eea <visit+0x8a>
 1019fde:	cmp    0x10(%rbx),%rax
 1019fe2:	jae    101a168 <visit+0x308>
 1019fe8:	mov    (%r9),%rcx
 1019feb:	add    %rcx,%rdi
 1019fee:	add    -0x18(%rdx),%rcx
 1019ff2:	inc    %rax
 1019ff5:	mov    %rax,0x18(%rbx)
 1019ff9:	mov    %r10,(%rdx)
 1019ffc:	mov    %rcx,0x8(%rdx)
 101a000:	mov    %rdi,0x10(%rdx)
 101a004:	movq   $0x0,0x18(%rdx)
 101a00c:	jmp    1019eea <visit+0x8a>
 101a011:	lea    -0x1(%r13),%eax
 101a015:	cmp    $0x3,%eax
 101a018:	mov    %rcx,-0x60(%rbp)
 101a01c:	mov    %rdx,-0x58(%rbp)
 101a020:	ja     101a086 <visit+0x226>
 101a022:	lea    -0x16ee9(%rip),%rdi        # 1003140 <myl_rc_map_sentinel+0xa0>
 101a029:	movslq (%rdi,%rax,4),%rax
 101a02d:	add    %rdi,%rax
 101a030:	jmp    *%rax
 101a032:	mov    $0x1,%edx
 101a037:	jmp    101a088 <visit+0x228>
 101a039:	mov    0x10(%rsi),%rax
 101a03d:	mov    0x18(%rsi),%rdx
 101a041:	mov    0x20(%rsi),%rcx
 101a045:	mov    %rcx,-0x30(%rbp)
 101a049:	mov    0x8(%rax),%r13d
 101a04d:	jmp    101a090 <visit+0x230>
 101a04f:	mov    0x10(%rsi),%rdi
 101a053:	mov    0x18(%rsi),%rdx
 101a057:	mov    0x20(%rsi),%r12
 101a05b:	add    %rcx,%r12
 101a05e:	mov    $0x4,%r13d
 101a064:	movq   $0x0,-0x30(%rbp)
 101a06c:	jmp    101a095 <visit+0x235>
 101a06e:	mov    0x10(%rsi),%rdi
 101a072:	mov    0x18(%rsi),%rdx
 101a076:	mov    $0x2,%r13d
 101a07c:	movq   $0x0,-0x30(%rbp)
 101a084:	jmp    101a092 <visit+0x232>
 101a086:	xor    %edx,%edx
 101a088:	movq   $0x0,-0x30(%rbp)
 101a090:	xor    %edi,%edi
 101a092:	xor    %r12d,%r12d
 101a095:	lea    0x10(%rdi),%rax
 101a099:	mov    %rax,-0x40(%rbp)
 101a09d:	mov    %rdx,%r15
 101a0a0:	neg    %r15
 101a0a3:	xor    %r14d,%r14d
 101a0a6:	mov    %rdx,-0x50(%rbp)
 101a0aa:	mov    %rdi,-0x48(%rbp)
 101a0ae:	test   %rdi,%rdi
 101a0b1:	je     101a112 <visit+0x2b2>
 101a0b3:	xor    %eax,%eax
 101a0b5:	cmp    %rdx,%r14
 101a0b8:	mov    -0x38(%rbp),%r8
 101a0bc:	jae    101a14f <visit+0x2ef>
 101a0c2:	lea    (%r14,%r14,2),%rcx
 101a0c6:	mov    -0x40(%rbp),%rdx
 101a0ca:	lea    (%rdx,%rcx,8),%rsi
 101a0ce:	inc    %r14
 101a0d1:	jmp    101a0f4 <visit+0x294>
 101a0d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a0e0:	add    $0x18,%rsi
 101a0e4:	lea    (%r15,%r14,1),%rcx
 101a0e8:	inc    %rcx
 101a0eb:	inc    %r14
 101a0ee:	cmp    $0x1,%rcx
 101a0f2:	je     101a14f <visit+0x2ef>
 101a0f4:	mov    -0x8(%rsi),%rcx
 101a0f8:	mov    0x8(%rcx),%ecx
 101a0fb:	test   %ecx,%ecx
 101a0fd:	je     101a0e0 <visit+0x280>
 101a0ff:	test   %r12,%r12
 101a102:	je     101a10c <visit+0x2ac>
 101a104:	mov    (%rsi),%edx
 101a106:	cmp    (%r12),%edx
 101a10a:	jne    101a0e0 <visit+0x280>
 101a10c:	mov    -0x10(%rsi),%rdx
 101a110:	jmp    101a129 <visit+0x2c9>
 101a112:	cmp    %rdx,%r14
 101a115:	mov    -0x38(%rbp),%r8
 101a119:	je     101a14d <visit+0x2ed>
 101a11b:	mov    %r14,%rdx
 101a11e:	inc    %r14
 101a121:	imul   -0x30(%rbp),%rdx
 101a126:	mov    %r13d,%ecx
 101a129:	mov    -0x58(%rbp),%rax
 101a12d:	lea    (%rax,%rdx,1),%rsi
 101a131:	add    -0x60(%rbp),%rdx
 101a135:	mov    %rbx,%rdi
 101a138:	call   *%r8
 101a13b:	test   %eax,%eax
 101a13d:	mov    -0x50(%rbp),%rdx
 101a141:	mov    -0x48(%rbp),%rdi
 101a145:	je     101a0ae <visit+0x24e>
 101a14b:	jmp    101a14f <visit+0x2ef>
 101a14d:	xor    %eax,%eax
 101a14f:	add    $0x38,%rsp
 101a153:	pop    %rbx
 101a154:	pop    %r12
 101a156:	pop    %r13
 101a158:	pop    %r14
 101a15a:	pop    %r15
 101a15c:	pop    %rbp
 101a15d:	ret
 101a15e:	movq   $0x0,0x18(%rbx)
 101a166:	jmp    101a14f <visit+0x2ef>
 101a168:	call   101246d <myl_rc_invariant_failed>
 101a16d:	int3
 101a16e:	int3
 101a16f:	int3

000000000101a170 <dispose_walk>:
 101a170:	push   %rbp
 101a171:	mov    %rsp,%rbp
 101a174:	push   %r15
 101a176:	push   %r14
 101a178:	push   %rbx
 101a179:	push   %rax
 101a17a:	mov    %rdi,%rbx
 101a17d:	mov    0x28(%rdi),%r14
 101a181:	test   %esi,%esi
 101a183:	je     101a1a9 <dispose_walk+0x39>
 101a185:	cmpq   $0x0,0x20(%r14)
 101a18a:	je     101a1a9 <dispose_walk+0x39>
 101a18c:	xor    %r15d,%r15d
 101a18f:	nop
 101a190:	mov    (%rbx),%rdi
 101a193:	mov    0x18(%r14),%rax
 101a197:	mov    (%rax,%r15,8),%rsi
 101a19b:	call   1016cd0 <myl_rc_construction_abort>
 101a1a0:	inc    %r15
 101a1a3:	cmp    0x20(%r14),%r15
 101a1a7:	jb     101a190 <dispose_walk+0x20>
 101a1a9:	mov    (%rbx),%rdi
 101a1ac:	mov    0xb0(%r14),%rsi
 101a1b3:	mov    0xc0(%r14),%rdx
 101a1ba:	shl    $0x3,%rdx
 101a1be:	call   1012500 <myl_rc_meta_free>
 101a1c3:	mov    (%rbx),%rdi
 101a1c6:	mov    0x18(%r14),%rsi
 101a1ca:	mov    0x28(%r14),%rdx
 101a1ce:	shl    $0x3,%rdx
 101a1d2:	call   1012500 <myl_rc_meta_free>
 101a1d7:	mov    (%rbx),%rdi
 101a1da:	mov    0x30(%r14),%rsi
 101a1de:	mov    0xa0(%r14),%rax
 101a1e5:	shl    $0x3,%rax
 101a1e9:	lea    (%rax,%rax,2),%rdx
 101a1ed:	call   1012500 <myl_rc_meta_free>
 101a1f2:	mov    (%rbx),%rdi
 101a1f5:	mov    (%r14),%rsi
 101a1f8:	mov    0x10(%r14),%rax
 101a1fc:	shl    $0x3,%rax
 101a200:	lea    (%rax,%rax,4),%rdx
 101a204:	call   1012500 <myl_rc_meta_free>
 101a209:	mov    0x10(%rbx),%rdx
 101a20d:	cmp    $0x9,%rdx
 101a211:	jb     101a223 <dispose_walk+0xb3>
 101a213:	mov    (%rbx),%rdi
 101a216:	mov    0x8(%rbx),%rsi
 101a21a:	shl    $0x5,%rdx
 101a21e:	call   1012500 <myl_rc_meta_free>
 101a223:	mov    (%rbx),%rdi
 101a226:	add    $0x8,%rsp
 101a22a:	pop    %rbx
 101a22b:	pop    %r14
 101a22d:	pop    %r15
 101a22f:	pop    %rbp
 101a230:	jmp    1016000 <myl_rc_drain>
 101a235:	int3
 101a236:	int3
 101a237:	int3
 101a238:	int3
 101a239:	int3
 101a23a:	int3
 101a23b:	int3
 101a23c:	int3
 101a23d:	int3
 101a23e:	int3
 101a23f:	int3

000000000101a240 <copy_many>:
 101a240:	push   %rbp
 101a241:	mov    %rsp,%rbp
 101a244:	push   %r15
 101a246:	push   %r14
 101a248:	push   %r13
 101a24a:	push   %r12
 101a24c:	push   %rbx
 101a24d:	sub    $0x228,%rsp
 101a254:	test   %rdi,%rdi
 101a257:	je     101a5bd <copy_many+0x37d>
 101a25d:	mov    %rdi,%r12
 101a260:	cmpq   $0x0,0x1608(%rdi)
 101a268:	je     101a5bd <copy_many+0x37d>
 101a26e:	mov    %rcx,%r15
 101a271:	mov    %rdx,%r9
 101a274:	mov    %rsi,%rbx
 101a277:	test   %rcx,%rcx
 101a27a:	je     101a28e <copy_many+0x4e>
 101a27c:	test   %rbx,%rbx
 101a27f:	je     101a5bd <copy_many+0x37d>
 101a285:	test   %r9,%r9
 101a288:	je     101a5bd <copy_many+0x37d>
 101a28e:	vxorps %xmm0,%xmm0,%xmm0
 101a292:	vmovups %ymm0,-0xb0(%rbp)
 101a29a:	vmovups %ymm0,-0xd0(%rbp)
 101a2a2:	vmovups %ymm0,-0xf0(%rbp)
 101a2aa:	vmovups %ymm0,-0x110(%rbp)
 101a2b2:	vmovups %ymm0,-0x130(%rbp)
 101a2ba:	vmovups %ymm0,-0x150(%rbp)
 101a2c2:	movq   $0x0,-0x90(%rbp)
 101a2cd:	mov    %r12,-0x78(%rbp)
 101a2d1:	lea    -0x250(%rbp),%rax
 101a2d8:	mov    %rax,-0x70(%rbp)
 101a2dc:	movq   $0x8,-0x68(%rbp)
 101a2e4:	vxorps %xmm0,%xmm0,%xmm0
 101a2e8:	vmovups %xmm0,-0x60(%rbp)
 101a2ed:	lea    -0x150(%rbp),%rax
 101a2f4:	mov    %rax,-0x50(%rbp)
 101a2f8:	test   %r15,%r15
 101a2fb:	je     101a518 <copy_many+0x2d8>
 101a301:	test   %r8d,%r8d
 101a304:	lea    0x685(%rip),%rax        # 101a990 <transfer_pointer>
 101a30b:	lea    0x18ae(%rip),%rcx        # 101bbc0 <retain_pointer>
 101a312:	cmove  %rax,%rcx
 101a316:	mov    %rcx,-0x88(%rbp)
 101a31d:	xor    %r13d,%r13d
 101a320:	mov    %r12,-0x30(%rbp)
 101a324:	mov    %r9,-0x80(%rbp)
 101a328:	nopl   0x0(%rax,%rax,1)
 101a330:	mov    %r13,%r14
 101a333:	shl    $0x5,%r14
 101a337:	mov    (%r9,%r14,1),%rsi
 101a33b:	mov    0x1608(%r12),%rdx
 101a343:	mov    0x58(%rdx),%rax
 101a347:	mov    0x60(%rdx),%rcx
 101a34b:	mov    0x70(%rdx),%edx
 101a34e:	mov    %rsi,%rdi
 101a351:	movabs $0x9e3779b97f4a7c15,%r8
 101a35b:	imul   %r8,%rdi
 101a35f:	shrx   %rdx,%rdi,%rdi
 101a364:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a370:	and    %rcx,%rdi
 101a373:	mov    %rdi,%r8
 101a376:	shl    $0x4,%r8
 101a37a:	mov    (%rax,%r8,1),%r8
 101a37e:	cmp    %rsi,%r8
 101a381:	je     101a390 <copy_many+0x150>
 101a383:	test   %r8,%r8
 101a386:	je     101a3a0 <copy_many+0x160>
 101a388:	inc    %rdi
 101a38b:	jmp    101a370 <copy_many+0x130>
 101a38d:	nopl   (%rax)
 101a390:	shl    $0x4,%rdi
 101a394:	mov    0x8(%rax,%rdi,1),%rsi
 101a399:	jmp    101a3a2 <copy_many+0x162>
 101a39b:	nopl   0x0(%rax,%rax,1)
 101a3a0:	xor    %esi,%esi
 101a3a2:	mov    (%rbx,%r14,1),%r10
 101a3a6:	mov    %r10,%rdi
 101a3a9:	movabs $0x9e3779b97f4a7c15,%r8
 101a3b3:	imul   %r8,%rdi
 101a3b7:	shrx   %rdx,%rdi,%rdx
 101a3bc:	nopl   0x0(%rax)
 101a3c0:	and    %rcx,%rdx
 101a3c3:	mov    %rdx,%rdi
 101a3c6:	shl    $0x4,%rdi
 101a3ca:	mov    (%rax,%rdi,1),%rdi
 101a3ce:	cmp    %r10,%rdi
 101a3d1:	je     101a3f0 <copy_many+0x1b0>
 101a3d3:	test   %rdi,%rdi
 101a3d6:	je     101a5bd <copy_many+0x37d>
 101a3dc:	inc    %rdx
 101a3df:	jmp    101a3c0 <copy_many+0x180>
 101a3e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a3f0:	test   %rsi,%rsi
 101a3f3:	je     101a5bd <copy_many+0x37d>
 101a3f9:	shl    $0x4,%rdx
 101a3fd:	mov    0x8(%rax,%rdx,1),%rax
 101a402:	test   %rax,%rax
 101a405:	je     101a5bd <copy_many+0x37d>
 101a40b:	mov    (%rsi),%rcx
 101a40e:	cmp    (%rax),%rcx
 101a411:	jne    101a5bd <copy_many+0x37d>
 101a417:	lea    (%r9,%r14,1),%rax
 101a41b:	add    %rbx,%r14
 101a41e:	mov    %rax,-0x48(%rbp)
 101a422:	mov    0x8(%rax),%rcx
 101a426:	mov    0x8(%r14),%rdx
 101a42a:	cmp    %rdx,%rcx
 101a42d:	je     101a5bd <copy_many+0x37d>
 101a433:	mov    0x18(%r14),%eax
 101a437:	cmp    0x70(%r12),%eax
 101a43c:	ja     101a526 <copy_many+0x2e6>
 101a442:	mov    %r13,-0x38(%rbp)
 101a446:	mov    0x28(%rsi),%r13
 101a44a:	cmp    $0x2,%r13
 101a44e:	mov    %rsi,-0x40(%rbp)
 101a452:	jb     101a4c8 <copy_many+0x288>
 101a454:	cmp    -0x68(%rbp),%r13
 101a458:	jbe    101a4c8 <copy_many+0x288>
 101a45a:	cmpq   $0x0,-0x60(%rbp)
 101a45f:	jne    101a5bd <copy_many+0x37d>
 101a465:	mov    %r13,%rax
 101a468:	shr    $0x3b,%rax
 101a46c:	jne    101a5bd <copy_many+0x37d>
 101a472:	mov    %r13,%rsi
 101a475:	shl    $0x5,%rsi
 101a479:	mov    -0x78(%rbp),%rdi
 101a47d:	vzeroupper
 101a480:	call   1012480 <myl_rc_meta_alloc>
 101a485:	test   %rax,%rax
 101a488:	je     101a5ab <copy_many+0x36b>
 101a48e:	mov    %rax,%r12
 101a491:	mov    -0x68(%rbp),%rdx
 101a495:	cmp    $0x9,%rdx
 101a499:	jb     101a4ac <copy_many+0x26c>
 101a49b:	mov    -0x78(%rbp),%rdi
 101a49f:	mov    -0x70(%rbp),%rsi
 101a4a3:	shl    $0x5,%rdx
 101a4a7:	call   1012500 <myl_rc_meta_free>
 101a4ac:	mov    %r12,-0x70(%rbp)
 101a4b0:	mov    %r13,-0x68(%rbp)
 101a4b4:	mov    0x8(%r14),%rdx
 101a4b8:	mov    -0x48(%rbp),%rax
 101a4bc:	mov    0x8(%rax),%rcx
 101a4c0:	mov    -0x30(%rbp),%r12
 101a4c4:	mov    -0x40(%rbp),%rsi
 101a4c8:	mov    $0x1,%r8d
 101a4ce:	mov    %r12,%rdi
 101a4d1:	vzeroupper
 101a4d4:	call   1016a40 <myl_rc_value_seed>
 101a4d9:	mov    -0x38(%rbp),%r13
 101a4dd:	inc    %r13
 101a4e0:	mov    0x18(%r14),%eax
 101a4e4:	mov    %eax,-0x58(%rbp)
 101a4e7:	mov    0x8(%r14),%rdx
 101a4eb:	mov    -0x48(%rbp),%rax
 101a4ef:	mov    0x8(%rax),%rcx
 101a4f3:	lea    -0x78(%rbp),%rdi
 101a4f7:	mov    -0x40(%rbp),%rsi
 101a4fb:	mov    -0x88(%rbp),%r8
 101a502:	call   1019e60 <visit>
 101a507:	test   %eax,%eax
 101a509:	jne    101a52b <copy_many+0x2eb>
 101a50b:	cmp    %r15,%r13
 101a50e:	mov    -0x80(%rbp),%r9
 101a512:	jne    101a330 <copy_many+0xf0>
 101a518:	lea    -0x78(%rbp),%rdi
 101a51c:	vzeroupper
 101a51f:	call   101aaa0 <finish_clones>
 101a524:	jmp    101a52e <copy_many+0x2ee>
 101a526:	mov    $0x3,%eax
 101a52b:	mov    %r13,%r15
 101a52e:	mov    %eax,%r14d
 101a531:	test   %eax,%eax
 101a533:	setne  %al
 101a536:	test   %r15,%r15
 101a539:	setne  %cl
 101a53c:	and    %al,%cl
 101a53e:	cmp    $0x1,%cl
 101a541:	jne    101a581 <copy_many+0x341>
 101a543:	add    $0x8,%rbx
 101a547:	nopw   0x0(%rax,%rax,1)
 101a550:	mov    -0x8(%rbx),%rsi
 101a554:	mov    (%rbx),%rdx
 101a557:	mov    $0x1,%ecx
 101a55c:	mov    %r12,%rdi
 101a55f:	vzeroupper
 101a562:	call   10159a0 <myl_rc_edges_release>
 101a567:	mov    -0x8(%rbx),%rax
 101a56b:	mov    (%rbx),%rdi
 101a56e:	mov    (%rax),%rdx
 101a571:	xor    %esi,%esi
 101a573:	call   101e4a0 <compiler_rt.fastMemset>
 101a578:	add    $0x20,%rbx
 101a57c:	dec    %r15
 101a57f:	jne    101a550 <copy_many+0x310>
 101a581:	xor    %esi,%esi
 101a583:	test   %r14d,%r14d
 101a586:	setne  %sil
 101a58a:	lea    -0x78(%rbp),%rdi
 101a58e:	vzeroupper
 101a591:	call   101a170 <dispose_walk>
 101a596:	mov    %r14d,%eax
 101a599:	add    $0x228,%rsp
 101a5a0:	pop    %rbx
 101a5a1:	pop    %r12
 101a5a3:	pop    %r13
 101a5a5:	pop    %r14
 101a5a7:	pop    %r15
 101a5a9:	pop    %rbp
 101a5aa:	ret
 101a5ab:	mov    $0x1,%eax
 101a5b0:	mov    -0x38(%rbp),%r15
 101a5b4:	mov    -0x30(%rbp),%r12
 101a5b8:	jmp    101a52e <copy_many+0x2ee>
 101a5bd:	vzeroupper
 101a5c0:	call   101246d <myl_rc_invariant_failed>
 101a5c5:	int3
 101a5c6:	int3
 101a5c7:	int3
 101a5c8:	int3
 101a5c9:	int3
 101a5ca:	int3
 101a5cb:	int3
 101a5cc:	int3
 101a5cd:	int3
 101a5ce:	int3
 101a5cf:	int3

000000000101a5d0 <myl_rc_value_retain_many>:
 101a5d0:	push   %rbp
 101a5d1:	mov    %rsp,%rbp
 101a5d4:	mov    $0x1,%r8d
 101a5da:	pop    %rbp
 101a5db:	jmp    101a240 <copy_many>

000000000101a5e0 <myl_rc_value_take>:
 101a5e0:	push   %rbp
 101a5e1:	mov    %rsp,%rbp
 101a5e4:	mov    $0x1,%ecx
 101a5e9:	xor    %r8d,%r8d
 101a5ec:	xor    %r9d,%r9d
 101a5ef:	pop    %rbp
 101a5f0:	jmp    1019290 <transfer>
 101a5f5:	int3
 101a5f6:	int3
 101a5f7:	int3
 101a5f8:	int3
 101a5f9:	int3
 101a5fa:	int3
 101a5fb:	int3
 101a5fc:	int3
 101a5fd:	int3
 101a5fe:	int3
 101a5ff:	int3

000000000101a600 <myl_rc_unique_owned>:
 101a600:	push   %rbp
 101a601:	mov    %rsp,%rbp
 101a604:	push   %r15
 101a606:	push   %r14
 101a608:	push   %rbx
 101a609:	push   %rax
 101a60a:	test   %rsi,%rsi
 101a60d:	je     101a68c <myl_rc_unique_owned+0x8c>
 101a60f:	mov    %rsi,%r14
 101a612:	mov    0x8(%rsi),%rax
 101a616:	test   %rax,%rax
 101a619:	je     101a68c <myl_rc_unique_owned+0x8c>
 101a61b:	mov    (%r14),%rcx
 101a61e:	test   %rcx,%rcx
 101a621:	je     101a68c <myl_rc_unique_owned+0x8c>
 101a623:	cmpl   $0x1,0x8(%rcx)
 101a627:	jne    101a68c <myl_rc_unique_owned+0x8c>
 101a629:	cmpq   $0x8,(%rcx)
 101a62d:	jne    101a68c <myl_rc_unique_owned+0x8c>
 101a62f:	mov    %rdi,%rbx
 101a632:	mov    (%rax),%r15
 101a635:	mov    %r15,%rsi
 101a638:	call   1012b00 <myl_rc_unique>
 101a63d:	mov    %eax,%ecx
 101a63f:	xor    %eax,%eax
 101a641:	test   %ecx,%ecx
 101a643:	jne    101a681 <myl_rc_unique_owned+0x81>
 101a645:	movq   $0x0,-0x20(%rbp)
 101a64d:	mov    0x18(%r14),%edx
 101a651:	lea    -0x20(%rbp),%rcx
 101a655:	mov    %rbx,%rdi
 101a658:	mov    %r15,%rsi
 101a65b:	xor    %r8d,%r8d
 101a65e:	call   101a6a0 <clone_payload>
 101a663:	test   %eax,%eax
 101a665:	jne    101a681 <myl_rc_unique_owned+0x81>
 101a667:	mov    0x8(%r14),%rcx
 101a66b:	mov    -0x20(%rbp),%rdx
 101a66f:	mov    %rdx,(%rcx)
 101a672:	mov    %rbx,%rdi
 101a675:	mov    %r15,%rsi
 101a678:	mov    %eax,%ebx
 101a67a:	call   1012ac0 <myl_rc_owner_release>
 101a67f:	mov    %ebx,%eax
 101a681:	add    $0x8,%rsp
 101a685:	pop    %rbx
 101a686:	pop    %r14
 101a688:	pop    %r15
 101a68a:	pop    %rbp
 101a68b:	ret
 101a68c:	call   101246d <myl_rc_invariant_failed>
 101a691:	int3
 101a692:	int3
 101a693:	int3
 101a694:	int3
 101a695:	int3
 101a696:	int3
 101a697:	int3
 101a698:	int3
 101a699:	int3
 101a69a:	int3
 101a69b:	int3
 101a69c:	int3
 101a69d:	int3
 101a69e:	int3
 101a69f:	int3

000000000101a6a0 <clone_payload>:
 101a6a0:	push   %rbp
 101a6a1:	mov    %rsp,%rbp
 101a6a4:	push   %r15
 101a6a6:	push   %r14
 101a6a8:	push   %r13
 101a6aa:	push   %r12
 101a6ac:	push   %rbx
 101a6ad:	sub    $0x208,%rsp
 101a6b4:	mov    %rcx,-0x30(%rbp)
 101a6b8:	mov    %rdi,%r14
 101a6bb:	vxorps %xmm0,%xmm0,%xmm0
 101a6bf:	vmovups %ymm0,-0x90(%rbp)
 101a6c7:	vmovups %ymm0,-0xb0(%rbp)
 101a6cf:	vmovups %ymm0,-0xd0(%rbp)
 101a6d7:	vmovups %ymm0,-0xf0(%rbp)
 101a6df:	vmovups %ymm0,-0x110(%rbp)
 101a6e7:	vmovups %ymm0,-0x130(%rbp)
 101a6ef:	movq   $0x0,-0x70(%rbp)
 101a6f7:	mov    $0x1,%ecx
 101a6fc:	test   %r8d,%r8d
 101a6ff:	jne    101a727 <clone_payload+0x87>
 101a701:	xor    %ecx,%ecx
 101a703:	testb  $0x20,-0x9(%rsi)
 101a707:	je     101a727 <clone_payload+0x87>
 101a709:	mov    %rsi,%rdi
 101a70c:	mov    %rsi,%rbx
 101a70f:	mov    %edx,%r15d
 101a712:	vzeroupper
 101a715:	call   101de80 <myl_rc_native_mutable>
 101a71a:	mov    %r15d,%edx
 101a71d:	mov    %rbx,%rsi
 101a720:	xor    %ecx,%ecx
 101a722:	test   %eax,%eax
 101a724:	setne  %cl
 101a727:	mov    %ecx,-0x84(%rbp)
 101a72d:	mov    -0x10(%rsi),%rax
 101a731:	mov    %rax,%r15
 101a734:	shr    $0x28,%r15
 101a738:	and    $0xfffff,%r15d
 101a73f:	cmp    %edx,%r15d
 101a742:	cmovae %edx,%r15d
 101a746:	xor    %ebx,%ebx
 101a748:	bt     $0x3e,%rax
 101a74d:	cmovae %ebx,%r15d
 101a751:	test   %ecx,%ecx
 101a753:	cmove  %edx,%r15d
 101a757:	mov    %r14,-0x68(%rbp)
 101a75b:	lea    -0x230(%rbp),%rax
 101a762:	mov    %rax,-0x60(%rbp)
 101a766:	movq   $0x8,-0x58(%rbp)
 101a76e:	movq   $0x0,-0x50(%rbp)
 101a776:	mov    %r15d,-0x48(%rbp)
 101a77a:	movl   $0x0,-0x44(%rbp)
 101a781:	lea    -0x130(%rbp),%r13
 101a788:	mov    %r13,-0x40(%rbp)
 101a78c:	lea    -0x68(%rbp),%rdi
 101a790:	lea    -0x38(%rbp),%rcx
 101a794:	mov    %r15d,%edx
 101a797:	vzeroupper
 101a79a:	call   101b130 <schedule_clone>
 101a79f:	test   %eax,%eax
 101a7a1:	je     101a7ab <clone_payload+0x10b>
 101a7a3:	mov    %eax,%r12d
 101a7a6:	jmp    101a850 <clone_payload+0x1b0>
 101a7ab:	lea    -0x68(%rbp),%rdi
 101a7af:	call   101aaa0 <finish_clones>
 101a7b4:	xor    %r12d,%r12d
 101a7b7:	mov    -0x40(%rbp),%r13
 101a7bb:	test   %eax,%eax
 101a7bd:	je     101a7c9 <clone_payload+0x129>
 101a7bf:	xor    %ebx,%ebx
 101a7c1:	mov    %eax,%r12d
 101a7c4:	jmp    101a850 <clone_payload+0x1b0>
 101a7c9:	mov    0xb8(%r13),%rsi
 101a7d0:	mov    $0x1,%bl
 101a7d2:	test   %rsi,%rsi
 101a7d5:	je     101a850 <clone_payload+0x1b0>
 101a7d7:	movabs $0x2000000000000000,%rax
 101a7e1:	mov    0xb0(%r13),%rdx
 101a7e8:	mov    %esi,%ecx
 101a7ea:	and    $0x3,%ecx
 101a7ed:	cmp    $0x4,%rsi
 101a7f1:	jae    101a7f7 <clone_payload+0x157>
 101a7f3:	xor    %edi,%edi
 101a7f5:	jmp    101a831 <clone_payload+0x191>
 101a7f7:	and    $0xfffffffffffffffc,%rsi
 101a7fb:	xor    %edi,%edi
 101a7fd:	nopl   (%rax)
 101a800:	mov    (%rdx,%rdi,8),%r8
 101a804:	or     %rax,-0x10(%r8)
 101a808:	mov    0x8(%rdx,%rdi,8),%r8
 101a80d:	or     %rax,-0x10(%r8)
 101a811:	mov    0x10(%rdx,%rdi,8),%r8
 101a816:	or     %rax,-0x10(%r8)
 101a81a:	mov    0x18(%rdx,%rdi,8),%r8
 101a81f:	or     %rax,-0x10(%r8)
 101a823:	add    $0x4,%rdi
 101a827:	cmp    %rdi,%rsi
 101a82a:	jne    101a800 <clone_payload+0x160>
 101a82c:	test   %rcx,%rcx
 101a82f:	je     101a8af <clone_payload+0x20f>
 101a831:	lea    (%rdx,%rdi,8),%rdx
 101a835:	xor    %r12d,%r12d
 101a838:	xor    %esi,%esi
 101a83a:	nopw   0x0(%rax,%rax,1)
 101a840:	mov    (%rdx,%rsi,8),%rdi
 101a844:	or     %rax,-0x10(%rdi)
 101a848:	inc    %rsi
 101a84b:	cmp    %rsi,%rcx
 101a84e:	jne    101a840 <clone_payload+0x1a0>
 101a850:	movq   $0x0,0xb8(%r13)
 101a85b:	mov    -0x38(%rbp),%r13
 101a85f:	test   %r15d,%r15d
 101a862:	jne    101a879 <clone_payload+0x1d9>
 101a864:	test   %r12d,%r12d
 101a867:	je     101a879 <clone_payload+0x1d9>
 101a869:	test   %r13,%r13
 101a86c:	je     101a879 <clone_payload+0x1d9>
 101a86e:	mov    %r14,%rdi
 101a871:	mov    %r13,%rsi
 101a874:	call   1012ac0 <myl_rc_owner_release>
 101a879:	xor    %esi,%esi
 101a87b:	test   %r12d,%r12d
 101a87e:	setne  %sil
 101a882:	lea    -0x68(%rbp),%rdi
 101a886:	call   101a170 <dispose_walk>
 101a88b:	xor    %eax,%eax
 101a88d:	test   %bl,%bl
 101a88f:	cmovne %r13,%rax
 101a893:	mov    -0x30(%rbp),%rcx
 101a897:	mov    %rax,(%rcx)
 101a89a:	mov    %r12d,%eax
 101a89d:	add    $0x208,%rsp
 101a8a4:	pop    %rbx
 101a8a5:	pop    %r12
 101a8a7:	pop    %r13
 101a8a9:	pop    %r14
 101a8ab:	pop    %r15
 101a8ad:	pop    %rbp
 101a8ae:	ret
 101a8af:	xor    %r12d,%r12d
 101a8b2:	jmp    101a850 <clone_payload+0x1b0>
 101a8b4:	int3
 101a8b5:	int3
 101a8b6:	int3
 101a8b7:	int3
 101a8b8:	int3
 101a8b9:	int3
 101a8ba:	int3
 101a8bb:	int3
 101a8bc:	int3
 101a8bd:	int3
 101a8be:	int3
 101a8bf:	int3

000000000101a8c0 <myl_rc_unique_borrow>:
 101a8c0:	push   %rbp
 101a8c1:	mov    %rsp,%rbp
 101a8c4:	push   %r15
 101a8c6:	push   %r14
 101a8c8:	push   %r12
 101a8ca:	push   %rbx
 101a8cb:	sub    $0x10,%rsp
 101a8cf:	test   %rcx,%rcx
 101a8d2:	je     101a97d <myl_rc_unique_borrow+0xbd>
 101a8d8:	mov    %rcx,%rbx
 101a8db:	cmpq   $0x0,(%rcx)
 101a8df:	jne    101a97d <myl_rc_unique_borrow+0xbd>
 101a8e5:	cmpl   $0x0,0x8(%rbx)
 101a8e9:	jne    101a97d <myl_rc_unique_borrow+0xbd>
 101a8ef:	mov    %rsi,%r15
 101a8f2:	mov    %rdi,%r14
 101a8f5:	test   %rdx,%rdx
 101a8f8:	je     101a905 <myl_rc_unique_borrow+0x45>
 101a8fa:	cmpl   $0x0,0x18(%rdx)
 101a8fe:	je     101a97d <myl_rc_unique_borrow+0xbd>
 101a900:	cmp    %r14,(%rdx)
 101a903:	jne    101a97d <myl_rc_unique_borrow+0xbd>
 101a905:	test   %r15,%r15
 101a908:	je     101a97d <myl_rc_unique_borrow+0xbd>
 101a90a:	mov    0x8(%r15),%rax
 101a90e:	test   %rax,%rax
 101a911:	je     101a97d <myl_rc_unique_borrow+0xbd>
 101a913:	mov    (%r15),%rcx
 101a916:	test   %rcx,%rcx
 101a919:	je     101a97d <myl_rc_unique_borrow+0xbd>
 101a91b:	cmpl   $0x1,0x8(%rcx)
 101a91f:	jne    101a97d <myl_rc_unique_borrow+0xbd>
 101a921:	cmpq   $0x8,(%rcx)
 101a925:	jne    101a97d <myl_rc_unique_borrow+0xbd>
 101a927:	mov    (%rax),%r12
 101a92a:	mov    %r14,%rdi
 101a92d:	mov    %r12,%rsi
 101a930:	call   1012b00 <myl_rc_unique>
 101a935:	test   %eax,%eax
 101a937:	je     101a940 <myl_rc_unique_borrow+0x80>
 101a939:	mov    %r12,(%rbx)
 101a93c:	xor    %eax,%eax
 101a93e:	jmp    101a970 <myl_rc_unique_borrow+0xb0>
 101a940:	movq   $0x0,-0x28(%rbp)
 101a948:	mov    0x18(%r15),%edx
 101a94c:	lea    -0x28(%rbp),%rcx
 101a950:	mov    %r14,%rdi
 101a953:	mov    %r12,%rsi
 101a956:	xor    %r8d,%r8d
 101a959:	call   101a6a0 <clone_payload>
 101a95e:	test   %eax,%eax
 101a960:	jne    101a970 <myl_rc_unique_borrow+0xb0>
 101a962:	mov    -0x28(%rbp),%rcx
 101a966:	mov    %rcx,(%rbx)
 101a969:	movl   $0x1,0x8(%rbx)
 101a970:	add    $0x10,%rsp
 101a974:	pop    %rbx
 101a975:	pop    %r12
 101a977:	pop    %r14
 101a979:	pop    %r15
 101a97b:	pop    %rbp
 101a97c:	ret
 101a97d:	call   101246d <myl_rc_invariant_failed>
 101a982:	int3
 101a983:	int3
 101a984:	int3
 101a985:	int3
 101a986:	int3
 101a987:	int3
 101a988:	int3
 101a989:	int3
 101a98a:	int3
 101a98b:	int3
 101a98c:	int3
 101a98d:	int3
 101a98e:	int3
 101a98f:	int3

000000000101a990 <transfer_pointer>:
 101a990:	mov    (%rdx),%rdx
 101a993:	cmp    $0x5,%ecx
 101a996:	je     101bae0 <transfer_hold>
 101a99c:	push   %rbp
 101a99d:	mov    %rsp,%rbp
 101a9a0:	push   %r15
 101a9a2:	push   %r14
 101a9a4:	push   %r12
 101a9a6:	push   %rbx
 101a9a7:	sub    $0x10,%rsp
 101a9ab:	test   %rdx,%rdx
 101a9ae:	je     101aa5a <transfer_pointer+0xca>
 101a9b4:	mov    -0x10(%rdx),%rcx
 101a9b8:	test   $0x2,%cl
 101a9bb:	jne    101aa5a <transfer_pointer+0xca>
 101a9c1:	bt     $0x3e,%rcx
 101a9c6:	mov    %rsi,%r14
 101a9c9:	jb     101a9d9 <transfer_pointer+0x49>
 101a9cb:	xor    %ebx,%ebx
 101a9cd:	bt     $0x3c,%rcx
 101a9d2:	jae    101aa0a <transfer_pointer+0x7a>
 101a9d4:	mov    0x20(%rdi),%eax
 101a9d7:	jmp    101aa33 <transfer_pointer+0xa3>
 101a9d9:	mov    %rcx,%rbx
 101a9dc:	shr    $0x28,%rbx
 101a9e0:	and    $0xfffff,%ebx
 101a9e6:	mov    0x20(%rdi),%eax
 101a9e9:	cmp    %eax,%ebx
 101a9eb:	jbe    101aa03 <transfer_pointer+0x73>
 101a9ed:	mov    0x28(%rdi),%rcx
 101a9f1:	cmpl   $0x0,0xa8(%rcx)
 101a9f8:	mov    %eax,%ebx
 101a9fa:	jne    101aa33 <transfer_pointer+0xa3>
 101a9fc:	mov    $0x3,%eax
 101aa01:	jmp    101aa5f <transfer_pointer+0xcf>
 101aa03:	bt     $0x3c,%rcx
 101aa08:	jb     101aa33 <transfer_pointer+0xa3>
 101aa0a:	mov    %rdi,%r12
 101aa0d:	mov    %rdx,%r15
 101aa10:	mov    %rdx,%rsi
 101aa13:	call   101b980 <queue_mark>
 101aa18:	mov    %eax,%ecx
 101aa1a:	mov    $0x1,%eax
 101aa1f:	test   %ecx,%ecx
 101aa21:	jne    101aa5f <transfer_pointer+0xcf>
 101aa23:	cmpl   $0x0,0x24(%r12)
 101aa29:	je     101aa6c <transfer_pointer+0xdc>
 101aa2b:	mov    %r14,%rsi
 101aa2e:	mov    %r15,%rdx
 101aa31:	jmp    101aa5a <transfer_pointer+0xca>
 101aa33:	mov    0x28(%rdi),%rcx
 101aa37:	cmpl   $0x0,0xac(%rcx)
 101aa3e:	cmove  %eax,%ebx
 101aa41:	lea    -0x28(%rbp),%rcx
 101aa45:	mov    %rdx,%rsi
 101aa48:	mov    %ebx,%edx
 101aa4a:	call   101b130 <schedule_clone>
 101aa4f:	test   %eax,%eax
 101aa51:	jne    101aa5f <transfer_pointer+0xcf>
 101aa53:	mov    -0x28(%rbp),%rdx
 101aa57:	mov    %r14,%rsi
 101aa5a:	mov    %rdx,(%rsi)
 101aa5d:	xor    %eax,%eax
 101aa5f:	add    $0x10,%rsp
 101aa63:	pop    %rbx
 101aa64:	pop    %r12
 101aa66:	pop    %r14
 101aa68:	pop    %r15
 101aa6a:	pop    %rbp
 101aa6b:	ret
 101aa6c:	test   %ebx,%ebx
 101aa6e:	mov    %r15,%rdx
 101aa71:	je     101aa8a <transfer_pointer+0xfa>
 101aa73:	mov    %r14,%rsi
 101aa76:	mov    0x28(%r12),%rax
 101aa7b:	cmpl   $0x0,0xac(%rax)
 101aa82:	jne    101aa5a <transfer_pointer+0xca>
 101aa84:	orb    $0x20,-0x9(%rdx)
 101aa88:	jmp    101aa5a <transfer_pointer+0xca>
 101aa8a:	mov    %rdx,%rdi
 101aa8d:	call   1012420 <myl_rc_owner_take>
 101aa92:	test   %eax,%eax
 101aa94:	jne    101aa5f <transfer_pointer+0xcf>
 101aa96:	jmp    101aa2b <transfer_pointer+0x9b>
 101aa98:	int3
 101aa99:	int3
 101aa9a:	int3
 101aa9b:	int3
 101aa9c:	int3
 101aa9d:	int3
 101aa9e:	int3
 101aa9f:	int3

000000000101aaa0 <finish_clones>:
 101aaa0:	push   %rbp
 101aaa1:	mov    %rsp,%rbp
 101aaa4:	push   %r15
 101aaa6:	push   %r14
 101aaa8:	push   %r13
 101aaaa:	push   %r12
 101aaac:	push   %rbx
 101aaad:	sub    $0xa8,%rsp
 101aab4:	mov    0x28(%rdi),%r14
 101aab8:	movl   $0x0,0x24(%rdi)
 101aabf:	mov    0x8(%r14),%rax
 101aac3:	test   %rax,%rax
 101aac6:	je     101b05a <finish_clones+0x5ba>
 101aacc:	mov    %rdi,%r12
 101aacf:	mov    %rdi,-0x40(%rbp)
 101aad3:	mov    %r14,-0x68(%rbp)
 101aad7:	jmp    101aaf9 <finish_clones+0x59>
 101aad9:	nopl   0x0(%rax)
 101aae0:	decq   0x8(%r14)
 101aae4:	mov    -0x40(%rbp),%r12
 101aae8:	mov    -0x68(%rbp),%r14
 101aaec:	mov    0x8(%r14),%rax
 101aaf0:	test   %rax,%rax
 101aaf3:	je     101b05a <finish_clones+0x5ba>
 101aaf9:	mov    (%r14),%rdx
 101aafc:	lea    (%rax,%rax,4),%rsi
 101ab00:	lea    (%rdx,%rsi,8),%rcx
 101ab04:	mov    -0x18(%rdx,%rsi,8),%rsi
 101ab09:	mov    0x38(%rsi),%r10
 101ab0d:	test   %r10,%r10
 101ab10:	je     101ae50 <finish_clones+0x3b0>
 101ab16:	movq   $0x0,-0x78(%rbp)
 101ab1e:	mov    (%r12),%rdi
 101ab22:	mov    -0x28(%rcx),%rsi
 101ab26:	mov    -0x20(%rcx),%rdx
 101ab2a:	add    $0xfffffffffffffff0,%rcx
 101ab2e:	lea    -0x78(%rbp),%rax
 101ab32:	mov    %rax,(%rsp)
 101ab36:	lea    -0x60(%rbp),%r8
 101ab3a:	lea    -0x98(%rbp),%r9
 101ab41:	call   *%r10
 101ab44:	test   %eax,%eax
 101ab46:	je     101aae0 <finish_clones+0x40>
 101ab48:	mov    -0x78(%rbp),%rax
 101ab4c:	mov    %rax,-0x70(%rbp)
 101ab50:	mov    (%r12),%rdi
 101ab54:	mov    -0x98(%rbp),%rcx
 101ab5b:	mov    0x1608(%rdi),%rsi
 101ab62:	mov    0x58(%rsi),%rax
 101ab66:	mov    0x60(%rsi),%rdx
 101ab6a:	movzbl 0x70(%rsi),%esi
 101ab6e:	mov    %rcx,%r8
 101ab71:	movabs $0x9e3779b97f4a7c15,%r9
 101ab7b:	imul   %r9,%r8
 101ab7f:	shrx   %rsi,%r8,%rsi
 101ab84:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101ab90:	and    %rdx,%rsi
 101ab93:	mov    %rsi,%r8
 101ab96:	shl    $0x4,%r8
 101ab9a:	mov    (%rax,%r8,1),%r8
 101ab9e:	cmp    %rcx,%r8
 101aba1:	je     101abc0 <finish_clones+0x120>
 101aba3:	test   %r8,%r8
 101aba6:	je     101b075 <finish_clones+0x5d5>
 101abac:	inc    %rsi
 101abaf:	jmp    101ab90 <finish_clones+0xf0>
 101abb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101abc0:	shl    $0x4,%rsi
 101abc4:	mov    0x8(%rax,%rsi,1),%rsi
 101abc9:	test   %rsi,%rsi
 101abcc:	je     101b075 <finish_clones+0x5d5>
 101abd2:	mov    -0x60(%rbp),%rax
 101abd6:	test   %rax,%rax
 101abd9:	je     101b075 <finish_clones+0x5d5>
 101abdf:	mov    (%rax),%rax
 101abe2:	cmp    (%rsi),%rax
 101abe5:	jne    101b075 <finish_clones+0x5d5>
 101abeb:	mov    0x28(%rsi),%r14
 101abef:	cmp    $0x2,%r14
 101abf3:	jb     101ac5e <finish_clones+0x1be>
 101abf5:	cmp    0x10(%r12),%r14
 101abfa:	jbe    101ac5e <finish_clones+0x1be>
 101abfc:	cmpq   $0x0,0x18(%r12)
 101ac02:	jne    101b075 <finish_clones+0x5d5>
 101ac08:	mov    %r14,%rax
 101ac0b:	shr    $0x3b,%rax
 101ac0f:	jne    101b075 <finish_clones+0x5d5>
 101ac15:	mov    %rsi,%rbx
 101ac18:	mov    %r14,%rsi
 101ac1b:	shl    $0x5,%rsi
 101ac1f:	call   1012480 <myl_rc_meta_alloc>
 101ac24:	test   %rax,%rax
 101ac27:	je     101b06e <finish_clones+0x5ce>
 101ac2d:	mov    %rax,%r15
 101ac30:	mov    0x10(%r12),%rdx
 101ac35:	cmp    $0x9,%rdx
 101ac39:	jb     101ac4d <finish_clones+0x1ad>
 101ac3b:	mov    (%r12),%rdi
 101ac3f:	mov    0x8(%r12),%rsi
 101ac44:	shl    $0x5,%rdx
 101ac48:	call   1012500 <myl_rc_meta_free>
 101ac4d:	mov    %r15,0x8(%r12)
 101ac52:	mov    %r14,0x10(%r12)
 101ac57:	mov    %rbx,%rsi
 101ac5a:	mov    0x28(%rbx),%r14
 101ac5e:	mov    -0x48(%rbp),%eax
 101ac61:	mov    %eax,0x20(%r12)
 101ac66:	cmpq   $0x0,-0x70(%rbp)
 101ac6b:	je     101aae4 <finish_clones+0x44>
 101ac71:	mov    -0x90(%rbp),%r15
 101ac78:	mov    -0x58(%rbp),%r12
 101ac7c:	xor    %edx,%edx
 101ac7e:	mov    %rsi,-0xa8(%rbp)
 101ac85:	mov    %r14,-0xa0(%rbp)
 101ac8c:	jmp    101acd9 <finish_clones+0x239>
 101ac8e:	xchg   %ax,%ax
 101ac90:	mov    -0x40(%rbp),%rdi
 101ac94:	mov    %r12,%rdx
 101ac97:	mov    %r15,%rcx
 101ac9a:	lea    -0x311(%rip),%r8        # 101a990 <transfer_pointer>
 101aca1:	call   1019e60 <visit>
 101aca6:	test   %eax,%eax
 101aca8:	jne    101b05c <finish_clones+0x5bc>
 101acae:	mov    -0xc8(%rbp),%rdx
 101acb5:	inc    %rdx
 101acb8:	mov    -0xa8(%rbp),%rsi
 101acbf:	mov    (%rsi),%rax
 101acc2:	add    %rax,%r12
 101acc5:	add    %rax,%r15
 101acc8:	cmp    -0x70(%rbp),%rdx
 101accc:	mov    -0xa0(%rbp),%r14
 101acd3:	je     101aae4 <finish_clones+0x44>
 101acd9:	cmp    $0x2,%r14
 101acdd:	mov    %rdx,-0xc8(%rbp)
 101ace4:	ja     101ac90 <finish_clones+0x1f0>
 101ace6:	mov    0x8(%rsi),%eax
 101ace9:	mov    %rax,-0x38(%rbp)
 101aced:	dec    %eax
 101acef:	cmp    $0x4,%eax
 101acf2:	ja     101ad61 <finish_clones+0x2c1>
 101acf4:	lea    -0x17bab(%rip),%rcx        # 1003150 <myl_rc_map_sentinel+0xb0>
 101acfb:	movslq (%rcx,%rax,4),%rax
 101acff:	add    %rcx,%rax
 101ad02:	jmp    *%rax
 101ad04:	mov    $0x1,%ecx
 101ad09:	jmp    101ad63 <finish_clones+0x2c3>
 101ad0b:	mov    0x10(%rsi),%rdx
 101ad0f:	mov    0x18(%rsi),%rcx
 101ad13:	mov    0x20(%rsi),%r14
 101ad17:	add    %r15,%r14
 101ad1a:	mov    $0x4,%eax
 101ad1f:	mov    %rax,-0x38(%rbp)
 101ad23:	movq   $0x0,-0x30(%rbp)
 101ad2b:	jmp    101ad70 <finish_clones+0x2d0>
 101ad2d:	mov    0x10(%rsi),%rdx
 101ad31:	mov    0x18(%rsi),%rcx
 101ad35:	mov    $0x2,%eax
 101ad3a:	mov    %rax,-0x38(%rbp)
 101ad3e:	movq   $0x0,-0x30(%rbp)
 101ad46:	jmp    101ad6d <finish_clones+0x2cd>
 101ad48:	mov    0x10(%rsi),%rax
 101ad4c:	mov    0x18(%rsi),%rcx
 101ad50:	mov    0x20(%rsi),%rdx
 101ad54:	mov    %rdx,-0x30(%rbp)
 101ad58:	mov    0x8(%rax),%eax
 101ad5b:	mov    %rax,-0x38(%rbp)
 101ad5f:	jmp    101ad6b <finish_clones+0x2cb>
 101ad61:	xor    %ecx,%ecx
 101ad63:	movq   $0x0,-0x30(%rbp)
 101ad6b:	xor    %edx,%edx
 101ad6d:	xor    %r14d,%r14d
 101ad70:	lea    0x10(%rdx),%rax
 101ad74:	mov    %rax,-0xb0(%rbp)
 101ad7b:	mov    %rcx,%r13
 101ad7e:	neg    %r13
 101ad81:	xor    %ebx,%ebx
 101ad83:	mov    %rcx,-0xc0(%rbp)
 101ad8a:	mov    %rdx,-0xb8(%rbp)
 101ad91:	test   %rdx,%rdx
 101ad94:	je     101ae00 <finish_clones+0x360>
 101ad96:	cmp    %rcx,%rbx
 101ad99:	jae    101acae <finish_clones+0x20e>
 101ad9f:	lea    (%rbx,%rbx,2),%rax
 101ada3:	mov    -0xb0(%rbp),%rcx
 101adaa:	lea    (%rcx,%rax,8),%rax
 101adae:	inc    %rbx
 101adb1:	jmp    101add8 <finish_clones+0x338>
 101adb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101adc0:	add    $0x18,%rax
 101adc4:	lea    (%rbx,%r13,1),%rcx
 101adc8:	inc    %rcx
 101adcb:	inc    %rbx
 101adce:	cmp    $0x1,%rcx
 101add2:	je     101acae <finish_clones+0x20e>
 101add8:	mov    -0x8(%rax),%rcx
 101addc:	mov    0x8(%rcx),%ecx
 101addf:	test   %ecx,%ecx
 101ade1:	je     101adc0 <finish_clones+0x320>
 101ade3:	test   %r14,%r14
 101ade6:	je     101adef <finish_clones+0x34f>
 101ade8:	mov    (%rax),%edx
 101adea:	cmp    (%r14),%edx
 101aded:	jne    101adc0 <finish_clones+0x320>
 101adef:	mov    -0x10(%rax),%rdx
 101adf3:	jmp    101ae1a <finish_clones+0x37a>
 101adf5:	data16 cs nopw 0x0(%rax,%rax,1)
 101ae00:	cmp    %rcx,%rbx
 101ae03:	je     101acae <finish_clones+0x20e>
 101ae09:	mov    %rbx,%rdx
 101ae0c:	inc    %rbx
 101ae0f:	imul   -0x30(%rbp),%rdx
 101ae14:	mov    -0x38(%rbp),%rax
 101ae18:	mov    %eax,%ecx
 101ae1a:	lea    (%r12,%rdx,1),%rsi
 101ae1e:	add    %r15,%rdx
 101ae21:	mov    -0x40(%rbp),%rdi
 101ae25:	call   101a990 <transfer_pointer>
 101ae2a:	test   %eax,%eax
 101ae2c:	mov    -0xc0(%rbp),%rcx
 101ae33:	mov    -0xb8(%rbp),%rdx
 101ae3a:	je     101ad91 <finish_clones+0x2f1>
 101ae40:	jmp    101b05c <finish_clones+0x5bc>
 101ae45:	data16 cs nopw 0x0(%rax,%rax,1)
 101ae50:	mov    0x30(%rsi),%r10
 101ae54:	test   %r10,%r10
 101ae57:	je     101ae8b <finish_clones+0x3eb>
 101ae59:	mov    (%r12),%rdi
 101ae5d:	mov    -0x28(%rcx),%rsi
 101ae61:	mov    -0x20(%rcx),%rdx
 101ae65:	add    $0xfffffffffffffff0,%rcx
 101ae69:	lea    -0x60(%rbp),%r8
 101ae6d:	lea    -0x98(%rbp),%r9
 101ae74:	call   *%r10
 101ae77:	test   %eax,%eax
 101ae79:	je     101b04a <finish_clones+0x5aa>
 101ae7f:	mov    -0x98(%rbp),%rax
 101ae86:	jmp    101af1e <finish_clones+0x47e>
 101ae8b:	mov    -0x28(%rcx),%rdi
 101ae8f:	mov    -0x10(%rcx),%rdx
 101ae93:	mov    -0x10(%rdi),%rdi
 101ae97:	mov    %rdi,%r8
 101ae9a:	shr    $0x2,%r8
 101ae9e:	bt     $0x3e,%rdi
 101aea3:	movabs $0x3fffffffff,%rdi
 101aead:	movabs $0x3ffffffffffffff,%r9
 101aeb7:	cmovae %r9,%rdi
 101aebb:	and    %r8,%rdi
 101aebe:	cmp    %rdi,%rdx
 101aec1:	je     101b04e <finish_clones+0x5ae>
 101aec7:	mov    0x8(%rsi),%rax
 101aecb:	lea    0x1(%rdx),%rsi
 101aecf:	mov    %rsi,-0x10(%rcx)
 101aed3:	imul   (%rax),%rdx
 101aed7:	mov    -0x20(%rcx),%rsi
 101aedb:	lea    (%rsi,%rdx,1),%rdi
 101aedf:	mov    -0x8(%rcx),%r8d
 101aee3:	mov    %rax,-0x60(%rbp)
 101aee7:	mov    %rdi,-0x58(%rbp)
 101aeeb:	mov    %rsi,-0x50(%rbp)
 101aeef:	mov    %r8d,-0x48(%rbp)
 101aef3:	movl   $0x0,-0x44(%rbp)
 101aefa:	mov    -0x28(%rcx),%rcx
 101aefe:	add    %rcx,%rdx
 101af01:	mov    %rax,-0x98(%rbp)
 101af08:	mov    %rdx,-0x90(%rbp)
 101af0f:	mov    %rcx,-0x88(%rbp)
 101af16:	movq   $0x0,-0x80(%rbp)
 101af1e:	mov    (%r12),%rdi
 101af22:	mov    0x1608(%rdi),%rsi
 101af29:	mov    0x58(%rsi),%rcx
 101af2d:	mov    0x60(%rsi),%rdx
 101af31:	movzbl 0x70(%rsi),%esi
 101af35:	mov    %rax,%r8
 101af38:	movabs $0x9e3779b97f4a7c15,%r9
 101af42:	imul   %r9,%r8
 101af46:	shrx   %rsi,%r8,%rsi
 101af4b:	nopl   0x0(%rax,%rax,1)
 101af50:	and    %rdx,%rsi
 101af53:	mov    %rsi,%r8
 101af56:	shl    $0x4,%r8
 101af5a:	mov    (%rcx,%r8,1),%r8
 101af5e:	cmp    %rax,%r8
 101af61:	je     101af80 <finish_clones+0x4e0>
 101af63:	test   %r8,%r8
 101af66:	je     101b075 <finish_clones+0x5d5>
 101af6c:	inc    %rsi
 101af6f:	jmp    101af50 <finish_clones+0x4b0>
 101af71:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101af80:	shl    $0x4,%rsi
 101af84:	mov    0x8(%rcx,%rsi,1),%rsi
 101af89:	test   %rsi,%rsi
 101af8c:	je     101b075 <finish_clones+0x5d5>
 101af92:	mov    -0x60(%rbp),%rax
 101af96:	test   %rax,%rax
 101af99:	je     101b075 <finish_clones+0x5d5>
 101af9f:	mov    (%rax),%rax
 101afa2:	cmp    (%rsi),%rax
 101afa5:	jne    101b075 <finish_clones+0x5d5>
 101afab:	mov    0x28(%rsi),%rbx
 101afaf:	cmp    $0x2,%rbx
 101afb3:	jb     101b01e <finish_clones+0x57e>
 101afb5:	cmp    0x10(%r12),%rbx
 101afba:	jbe    101b01e <finish_clones+0x57e>
 101afbc:	cmpq   $0x0,0x18(%r12)
 101afc2:	jne    101b075 <finish_clones+0x5d5>
 101afc8:	mov    %rbx,%rax
 101afcb:	shr    $0x3b,%rax
 101afcf:	jne    101b075 <finish_clones+0x5d5>
 101afd5:	mov    %rsi,%r14
 101afd8:	mov    %rbx,%rsi
 101afdb:	shl    $0x5,%rsi
 101afdf:	call   1012480 <myl_rc_meta_alloc>
 101afe4:	test   %rax,%rax
 101afe7:	je     101b06e <finish_clones+0x5ce>
 101afed:	mov    %rax,%r15
 101aff0:	mov    0x10(%r12),%rdx
 101aff5:	cmp    $0x9,%rdx
 101aff9:	jb     101b00d <finish_clones+0x56d>
 101affb:	mov    (%r12),%rdi
 101afff:	mov    0x8(%r12),%rsi
 101b004:	shl    $0x5,%rdx
 101b008:	call   1012500 <myl_rc_meta_free>
 101b00d:	mov    %r15,0x8(%r12)
 101b012:	mov    %rbx,0x10(%r12)
 101b017:	mov    %r14,%rsi
 101b01a:	mov    -0x68(%rbp),%r14
 101b01e:	mov    -0x48(%rbp),%eax
 101b021:	mov    %eax,0x20(%r12)
 101b026:	mov    -0x58(%rbp),%rdx
 101b02a:	mov    -0x90(%rbp),%rcx
 101b031:	mov    %r12,%rdi
 101b034:	lea    -0x6ab(%rip),%r8        # 101a990 <transfer_pointer>
 101b03b:	call   1019e60 <visit>
 101b040:	test   %eax,%eax
 101b042:	je     101aaec <finish_clones+0x4c>
 101b048:	jmp    101b05c <finish_clones+0x5bc>
 101b04a:	mov    0x8(%r14),%rax
 101b04e:	dec    %rax
 101b051:	mov    %rax,0x8(%r14)
 101b055:	jmp    101aaec <finish_clones+0x4c>
 101b05a:	xor    %eax,%eax
 101b05c:	add    $0xa8,%rsp
 101b063:	pop    %rbx
 101b064:	pop    %r12
 101b066:	pop    %r13
 101b068:	pop    %r14
 101b06a:	pop    %r15
 101b06c:	pop    %rbp
 101b06d:	ret
 101b06e:	mov    $0x1,%eax
 101b073:	jmp    101b05c <finish_clones+0x5bc>
 101b075:	call   101246d <myl_rc_invariant_failed>
 101b07a:	int3
 101b07b:	int3
 101b07c:	int3
 101b07d:	int3
 101b07e:	int3
 101b07f:	int3

000000000101b080 <rollback_take>:
 101b080:	mov    (%rsi),%rsi
 101b083:	cmp    %rsi,(%rdx)
 101b086:	je     101b0b1 <rollback_take+0x31>
 101b088:	push   %rbp
 101b089:	mov    %rsp,%rbp
 101b08c:	sub    $0x10,%rsp
 101b090:	mov    (%rdi),%rdi
 101b093:	cmp    $0x5,%ecx
 101b096:	jne    101b0a7 <rollback_take+0x27>
 101b098:	mov    %rsi,-0x8(%rbp)
 101b09c:	lea    -0x8(%rbp),%rsi
 101b0a0:	call   1012d10 <myl_rc_hold_release>
 101b0a5:	jmp    101b0ac <rollback_take+0x2c>
 101b0a7:	call   10129a0 <myl_rc_edge_release>
 101b0ac:	add    $0x10,%rsp
 101b0b0:	pop    %rbp
 101b0b1:	xor    %eax,%eax
 101b0b3:	ret
 101b0b4:	int3
 101b0b5:	int3
 101b0b6:	int3
 101b0b7:	int3
 101b0b8:	int3
 101b0b9:	int3
 101b0ba:	int3
 101b0bb:	int3
 101b0bc:	int3
 101b0bd:	int3
 101b0be:	int3
 101b0bf:	int3

000000000101b0c0 <commit_take>:
 101b0c0:	mov    %rsi,%rax
 101b0c3:	mov    (%rdx),%rsi
 101b0c6:	cmp    (%rax),%rsi
 101b0c9:	je     101b0f4 <commit_take+0x34>
 101b0cb:	push   %rbp
 101b0cc:	mov    %rsp,%rbp
 101b0cf:	sub    $0x10,%rsp
 101b0d3:	mov    (%rdi),%rdi
 101b0d6:	cmp    $0x5,%ecx
 101b0d9:	jne    101b0ea <commit_take+0x2a>
 101b0db:	mov    %rsi,-0x8(%rbp)
 101b0df:	lea    -0x8(%rbp),%rsi
 101b0e3:	call   1012d10 <myl_rc_hold_release>
 101b0e8:	jmp    101b0ef <commit_take+0x2f>
 101b0ea:	call   10129a0 <myl_rc_edge_release>
 101b0ef:	add    $0x10,%rsp
 101b0f3:	pop    %rbp
 101b0f4:	xor    %eax,%eax
 101b0f6:	ret
 101b0f7:	int3
 101b0f8:	int3
 101b0f9:	int3
 101b0fa:	int3
 101b0fb:	int3
 101b0fc:	int3
 101b0fd:	int3
 101b0fe:	int3
 101b0ff:	int3

000000000101b100 <inspect_child>:
 101b100:	push   %rbp
 101b101:	mov    %rsp,%rbp
 101b104:	cmp    $0x5,%ecx
 101b107:	je     101b128 <inspect_child+0x28>
 101b109:	mov    (%rdx),%rsi
 101b10c:	test   %rsi,%rsi
 101b10f:	je     101b128 <inspect_child+0x28>
 101b111:	testb  $0x10,-0x9(%rsi)
 101b115:	jne    101b11d <inspect_child+0x1d>
 101b117:	pop    %rbp
 101b118:	jmp    101b980 <queue_mark>
 101b11d:	mov    0x28(%rdi),%rax
 101b121:	orl    $0x4,0xac(%rax)
 101b128:	xor    %eax,%eax
 101b12a:	pop    %rbp
 101b12b:	ret
 101b12c:	int3
 101b12d:	int3
 101b12e:	int3
 101b12f:	int3

000000000101b130 <schedule_clone>:
 101b130:	push   %rbp
 101b131:	mov    %rsp,%rbp
 101b134:	push   %r15
 101b136:	push   %r14
 101b138:	push   %r13
 101b13a:	push   %r12
 101b13c:	push   %rbx
 101b13d:	sub    $0x68,%rsp
 101b141:	mov    %rcx,%rbx
 101b144:	mov    %edx,%r8d
 101b147:	mov    %rsi,%r15
 101b14a:	mov    %rdi,%r13
 101b14d:	movq   $0x0,(%rcx)
 101b154:	mov    0x28(%rdi),%r14
 101b158:	cmpl   $0x0,0xac(%r14)
 101b160:	mov    %r14,-0x58(%rbp)
 101b164:	je     101b180 <schedule_clone+0x50>
 101b166:	mov    %r15,%rdi
 101b169:	mov    %r8d,%r12d
 101b16c:	call   101de80 <myl_rc_native_mutable>
 101b171:	mov    %r12d,%r8d
 101b174:	test   %eax,%eax
 101b176:	je     101b180 <schedule_clone+0x50>
 101b178:	xor    %r9d,%r9d
 101b17b:	jmp    101b4a5 <schedule_clone+0x375>
 101b180:	mov    0xa0(%r14),%rcx
 101b187:	test   %rcx,%rcx
 101b18a:	je     101b24d <schedule_clone+0x11d>
 101b190:	mov    0x30(%r14),%rax
 101b194:	mov    %r15,%rdx
 101b197:	shr    $0x4,%rdx
 101b19b:	mov    %r8d,%esi
 101b19e:	movabs $0x9e3779b97f4a7c15,%rdi
 101b1a8:	imul   %rsi,%rdi
 101b1ac:	xor    %rdx,%rdi
 101b1af:	mov    %rdi,%rdx
 101b1b2:	shr    $0x1e,%rdx
 101b1b6:	xor    %rdi,%rdx
 101b1b9:	movabs $0xbf58476d1ce4e5b9,%rsi
 101b1c3:	imul   %rdx,%rsi
 101b1c7:	mov    %rsi,%rdx
 101b1ca:	shr    $0x1b,%rdx
 101b1ce:	xor    %rsi,%rdx
 101b1d1:	movabs $0x94d049bb133111eb,%rsi
 101b1db:	imul   %rdx,%rsi
 101b1df:	mov    %rsi,%rdx
 101b1e2:	shr    $0x1f,%rdx
 101b1e6:	xor    %rsi,%rdx
 101b1e9:	dec    %rcx
 101b1ec:	jmp    101b1f3 <schedule_clone+0xc3>
 101b1ee:	xchg   %ax,%ax
 101b1f0:	inc    %rdx
 101b1f3:	and    %rcx,%rdx
 101b1f6:	lea    (%rdx,%rdx,2),%rsi
 101b1fa:	mov    (%rax,%rsi,8),%rsi
 101b1fe:	test   %rsi,%rsi
 101b201:	je     101b213 <schedule_clone+0xe3>
 101b203:	cmp    %r15,%rsi
 101b206:	jne    101b1f0 <schedule_clone+0xc0>
 101b208:	lea    (%rdx,%rdx,2),%rsi
 101b20c:	cmp    %r8d,0x10(%rax,%rsi,8)
 101b211:	jne    101b1f0 <schedule_clone+0xc0>
 101b213:	lea    (%rdx,%rdx,2),%rcx
 101b217:	lea    (%rax,%rcx,8),%rax
 101b21b:	mov    0x8(%rax),%rax
 101b21f:	test   %rax,%rax
 101b222:	je     101b276 <schedule_clone+0x146>
 101b224:	mov    -0x10(%rax),%rcx
 101b228:	movabs $0x4000000000000000,%rdx
 101b232:	or     $0x2,%rdx
 101b236:	test   %rdx,%rcx
 101b239:	je     101b317 <schedule_clone+0x1e7>
 101b23f:	test   %r8d,%r8d
 101b242:	jne    101b34a <schedule_clone+0x21a>
 101b248:	jmp    101b94d <schedule_clone+0x81d>
 101b24d:	mov    0x98(%r14),%rcx
 101b254:	test   %rcx,%rcx
 101b257:	je     101b276 <schedule_clone+0x146>
 101b259:	lea    0x38(%r14),%rax
 101b25d:	jmp    101b269 <schedule_clone+0x139>
 101b25f:	nop
 101b260:	add    $0x18,%rax
 101b264:	dec    %rcx
 101b267:	je     101b276 <schedule_clone+0x146>
 101b269:	cmp    %r15,(%rax)
 101b26c:	jne    101b260 <schedule_clone+0x130>
 101b26e:	cmp    %r8d,0x10(%rax)
 101b272:	jne    101b260 <schedule_clone+0x130>
 101b274:	jmp    101b21b <schedule_clone+0xeb>
 101b276:	mov    0x28(%r13),%r14
 101b27a:	mov    0x98(%r14),%rcx
 101b281:	mov    0xa0(%r14),%rax
 101b288:	test   %rax,%rax
 101b28b:	je     101b2a0 <schedule_clone+0x170>
 101b28d:	mov    %rax,%rdx
 101b290:	shr    $1,%rdx
 101b293:	mov    $0x1,%r9b
 101b296:	cmp    %rdx,%rcx
 101b299:	jae    101b2ad <schedule_clone+0x17d>
 101b29b:	jmp    101b4a5 <schedule_clone+0x375>
 101b2a0:	mov    $0x1,%r9b
 101b2a3:	cmp    $0x4,%rcx
 101b2a7:	jb     101b4a5 <schedule_clone+0x375>
 101b2ad:	mov    %r13,-0x40(%rbp)
 101b2b1:	lea    (%rax,%rax,1),%rcx
 101b2b5:	test   %rax,%rax
 101b2b8:	mov    $0x20,%r13d
 101b2be:	cmovne %rcx,%r13
 101b2c2:	mov    $0x1,%r12d
 101b2c8:	cmp    %rax,%r13
 101b2cb:	jb     101b953 <schedule_clone+0x823>
 101b2d1:	mov    $0x18,%ecx
 101b2d6:	mov    %r13,%rax
 101b2d9:	mul    %rcx
 101b2dc:	jo     101b953 <schedule_clone+0x823>
 101b2e2:	mov    %r8d,-0x2c(%rbp)
 101b2e6:	mov    %rbx,-0x48(%rbp)
 101b2ea:	mov    -0x40(%rbp),%rcx
 101b2ee:	mov    (%rcx),%rdi
 101b2f1:	mov    %rax,%rsi
 101b2f4:	call   1012480 <myl_rc_meta_alloc>
 101b2f9:	test   %rax,%rax
 101b2fc:	je     101b953 <schedule_clone+0x823>
 101b302:	mov    %rax,%rbx
 101b305:	mov    0xa0(%r14),%rax
 101b30c:	test   %rax,%rax
 101b30f:	je     101b37c <schedule_clone+0x24c>
 101b311:	mov    0x30(%r14),%rcx
 101b315:	jmp    101b390 <schedule_clone+0x260>
 101b317:	test   $0x1,%cl
 101b31a:	jne    101b979 <schedule_clone+0x849>
 101b320:	mov    -0x20(%rax),%rdx
 101b324:	cmp    $0xffffffffffffffff,%rdx
 101b328:	je     101b371 <schedule_clone+0x241>
 101b32a:	test   %rdx,%rdx
 101b32d:	jne    101b33a <schedule_clone+0x20a>
 101b32f:	cmpq   $0x0,-0x18(%rax)
 101b334:	je     101b979 <schedule_clone+0x849>
 101b33a:	inc    %rdx
 101b33d:	mov    %rdx,-0x20(%rax)
 101b341:	test   %r8d,%r8d
 101b344:	je     101b94d <schedule_clone+0x81d>
 101b34a:	cmpl   $0x0,0xac(%r14)
 101b352:	jne    101b94d <schedule_clone+0x81d>
 101b358:	movabs $0x1fffffffffffffff,%rdx
 101b362:	inc    %rdx
 101b365:	or     %rdx,%rcx
 101b368:	mov    %rcx,-0x10(%rax)
 101b36c:	jmp    101b94d <schedule_clone+0x81d>
 101b371:	mov    $0x2,%r12d
 101b377:	jmp    101b953 <schedule_clone+0x823>
 101b37c:	mov    0x98(%r14),%rax
 101b383:	test   %rax,%rax
 101b386:	je     101b965 <schedule_clone+0x835>
 101b38c:	lea    0x38(%r14),%rcx
 101b390:	lea    -0x1(%r13),%r8
 101b394:	xor    %r9d,%r9d
 101b397:	movabs $0x9e3779b97f4a7c15,%rdi
 101b3a1:	jmp    101b3d3 <schedule_clone+0x2a3>
 101b3a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b3b0:	lea    (%rdx,%rdx,2),%rdx
 101b3b4:	mov    0x10(%r10),%rsi
 101b3b8:	mov    %rsi,0x10(%rbx,%rdx,8)
 101b3bd:	vmovups (%r10),%xmm0
 101b3c2:	vmovups %xmm0,(%rbx,%rdx,8)
 101b3c7:	inc    %r9
 101b3ca:	cmp    %rax,%r9
 101b3cd:	je     101b46c <schedule_clone+0x33c>
 101b3d3:	lea    (%r9,%r9,2),%rdx
 101b3d7:	mov    (%rcx,%rdx,8),%r11
 101b3db:	test   %r11,%r11
 101b3de:	je     101b3c7 <schedule_clone+0x297>
 101b3e0:	lea    (%rcx,%rdx,8),%r10
 101b3e4:	mov    0x10(%r10),%r12d
 101b3e8:	mov    %r11,%rdx
 101b3eb:	shr    $0x4,%rdx
 101b3ef:	mov    %r12,%rsi
 101b3f2:	imul   %rdi,%rsi
 101b3f6:	xor    %rdx,%rsi
 101b3f9:	mov    %rsi,%rdx
 101b3fc:	shr    $0x1e,%rdx
 101b400:	xor    %rsi,%rdx
 101b403:	movabs $0xbf58476d1ce4e5b9,%rsi
 101b40d:	imul   %rsi,%rdx
 101b411:	mov    %rdx,%rsi
 101b414:	shr    $0x1b,%rsi
 101b418:	xor    %rdx,%rsi
 101b41b:	movabs $0x94d049bb133111eb,%rdx
 101b425:	imul   %rdx,%rsi
 101b429:	mov    %rsi,%rdx
 101b42c:	shr    $0x1f,%rdx
 101b430:	xor    %rsi,%rdx
 101b433:	jmp    101b443 <schedule_clone+0x313>
 101b435:	data16 cs nopw 0x0(%rax,%rax,1)
 101b440:	inc    %rdx
 101b443:	and    %r8,%rdx
 101b446:	lea    (%rdx,%rdx,2),%rsi
 101b44a:	mov    (%rbx,%rsi,8),%rsi
 101b44e:	test   %rsi,%rsi
 101b451:	je     101b3b0 <schedule_clone+0x280>
 101b457:	cmp    %r11,%rsi
 101b45a:	jne    101b440 <schedule_clone+0x310>
 101b45c:	lea    (%rdx,%rdx,2),%rsi
 101b460:	cmp    %r12d,0x10(%rbx,%rsi,8)
 101b465:	jne    101b440 <schedule_clone+0x310>
 101b467:	jmp    101b3b0 <schedule_clone+0x280>
 101b46c:	mov    0xa0(%r14),%rax
 101b473:	shl    $0x3,%rax
 101b477:	lea    (%rax,%rax,2),%rdx
 101b47b:	mov    -0x40(%rbp),%r12
 101b47f:	mov    (%r12),%rdi
 101b483:	mov    0x30(%r14),%rsi
 101b487:	call   1012500 <myl_rc_meta_free>
 101b48c:	mov    %rbx,0x30(%r14)
 101b490:	mov    %r13,0xa0(%r14)
 101b497:	mov    %r12,%r13
 101b49a:	mov    $0x1,%r9b
 101b49d:	mov    -0x48(%rbp),%rbx
 101b4a1:	mov    -0x2c(%rbp),%r8d
 101b4a5:	mov    0x0(%r13),%rdi
 101b4a9:	mov    0x1608(%rdi),%rax
 101b4b0:	cmpb   $0x0,0x120(%rax)
 101b4b7:	jne    101b4ca <schedule_clone+0x39a>
 101b4b9:	mov    -0x8(%r15),%rcx
 101b4bd:	cmp    $0x1028f28,%rcx
 101b4c4:	je     101b750 <schedule_clone+0x620>
 101b4ca:	mov    %r13,-0x40(%rbp)
 101b4ce:	mov    -0x8(%r15),%rsi
 101b4d2:	mov    0x34(%rsi),%ecx
 101b4d5:	cmp    %rcx,0xa0(%rax)
 101b4dc:	jbe    101b96c <schedule_clone+0x83c>
 101b4e2:	mov    0x98(%rax),%rax
 101b4e9:	shl    $0x4,%rcx
 101b4ed:	cmp    %rsi,(%rax,%rcx,1)
 101b4f1:	jne    101b96c <schedule_clone+0x83c>
 101b4f7:	add    %rcx,%rax
 101b4fa:	mov    0x8(%rax),%r13
 101b4fe:	mov    -0x58(%rbp),%r14
 101b502:	test   %r13,%r13
 101b505:	je     101b979 <schedule_clone+0x849>
 101b50b:	cmpq   $0x0,0x18(%r13)
 101b510:	jne    101b979 <schedule_clone+0x849>
 101b516:	cmpq   $0x0,0x28(%r13)
 101b51b:	je     101b530 <schedule_clone+0x400>
 101b51d:	cmpq   $0x0,0x30(%r13)
 101b522:	jne    101b54c <schedule_clone+0x41c>
 101b524:	xor    %edx,%edx
 101b526:	test   %r8d,%r8d
 101b529:	jne    101b574 <schedule_clone+0x444>
 101b52b:	jmp    101b719 <schedule_clone+0x5e9>
 101b530:	cmpq   $0x0,0x10(%r13)
 101b535:	jne    101b979 <schedule_clone+0x849>
 101b53b:	cmpq   $0x0,0x30(%r13)
 101b540:	jne    101b54c <schedule_clone+0x41c>
 101b542:	mov    0x8(%r13),%rax
 101b546:	cmpl   $0x0,0x8(%rax)
 101b54a:	je     101b524 <schedule_clone+0x3f4>
 101b54c:	mov    %rbx,-0x48(%rbp)
 101b550:	mov    (%r14),%rsi
 101b553:	mov    0x8(%r14),%rbx
 101b557:	mov    0x10(%r14),%rax
 101b55b:	cmp    %rax,%rbx
 101b55e:	jae    101b5a4 <schedule_clone+0x474>
 101b560:	mov    $0x1,%dl
 101b562:	test   %rsi,%rsi
 101b565:	mov    -0x48(%rbp),%rbx
 101b569:	je     101b599 <schedule_clone+0x469>
 101b56b:	test   %r8d,%r8d
 101b56e:	je     101b719 <schedule_clone+0x5e9>
 101b574:	mov    0x18(%r14),%rsi
 101b578:	mov    %r14,%rax
 101b57b:	mov    0x20(%r14),%r14
 101b57f:	mov    0x28(%rax),%rax
 101b583:	cmp    %rax,%r14
 101b586:	jae    101b664 <schedule_clone+0x534>
 101b58c:	test   %rsi,%rsi
 101b58f:	mov    -0x58(%rbp),%r14
 101b593:	jne    101b719 <schedule_clone+0x5e9>
 101b599:	mov    $0x1,%r12d
 101b59f:	jmp    101b953 <schedule_clone+0x823>
 101b5a4:	lea    (%rax,%rax,1),%rcx
 101b5a8:	test   %rax,%rax
 101b5ab:	mov    $0x10,%r14d
 101b5b1:	cmovne %rcx,%r14
 101b5b5:	mov    $0x1,%r12d
 101b5bb:	cmp    %rax,%r14
 101b5be:	jb     101b953 <schedule_clone+0x823>
 101b5c4:	mov    $0x28,%ecx
 101b5c9:	mov    %r14,%rax
 101b5cc:	mul    %rcx
 101b5cf:	jo     101b953 <schedule_clone+0x823>
 101b5d5:	mov    %rsi,-0x60(%rbp)
 101b5d9:	mov    %r9d,-0x30(%rbp)
 101b5dd:	mov    %r8d,-0x2c(%rbp)
 101b5e1:	mov    -0x40(%rbp),%rcx
 101b5e5:	mov    (%rcx),%rdi
 101b5e8:	mov    %rdi,-0x68(%rbp)
 101b5ec:	mov    %rax,%rsi
 101b5ef:	call   1012480 <myl_rc_meta_alloc>
 101b5f4:	test   %rax,%rax
 101b5f7:	je     101b953 <schedule_clone+0x823>
 101b5fd:	test   %rbx,%rbx
 101b600:	mov    -0x60(%rbp),%r12
 101b604:	mov    %rax,-0x38(%rbp)
 101b608:	je     101b61e <schedule_clone+0x4ee>
 101b60a:	shl    $0x3,%rbx
 101b60e:	lea    (%rbx,%rbx,4),%rdx
 101b612:	mov    -0x38(%rbp),%rdi
 101b616:	mov    %r12,%rsi
 101b619:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101b61e:	mov    -0x58(%rbp),%rbx
 101b622:	mov    0x10(%rbx),%rax
 101b626:	shl    $0x3,%rax
 101b62a:	lea    (%rax,%rax,4),%rdx
 101b62e:	mov    -0x68(%rbp),%rdi
 101b632:	mov    %r12,%rsi
 101b635:	call   1012500 <myl_rc_meta_free>
 101b63a:	mov    %r14,0x10(%rbx)
 101b63e:	mov    %rbx,%r14
 101b641:	mov    -0x38(%rbp),%rax
 101b645:	mov    %rax,(%rbx)
 101b648:	mov    $0x1,%dl
 101b64a:	mov    -0x48(%rbp),%rbx
 101b64e:	mov    -0x2c(%rbp),%r8d
 101b652:	mov    -0x30(%rbp),%r9d
 101b656:	test   %r8d,%r8d
 101b659:	jne    101b574 <schedule_clone+0x444>
 101b65f:	jmp    101b719 <schedule_clone+0x5e9>
 101b664:	mov    %rbx,-0x48(%rbp)
 101b668:	lea    (%rax,%rax,1),%rcx
 101b66c:	test   %rax,%rax
 101b66f:	mov    $0x10,%ebx
 101b674:	cmovne %rcx,%rbx
 101b678:	cmp    %rax,%rbx
 101b67b:	setb   %al
 101b67e:	mov    %rbx,%rcx
 101b681:	shr    $0x3d,%rcx
 101b685:	setne  %cl
 101b688:	or     %al,%cl
 101b68a:	mov    $0x1,%r12d
 101b690:	jne    101b953 <schedule_clone+0x823>
 101b696:	mov    %rsi,-0x68(%rbp)
 101b69a:	mov    %edx,-0x38(%rbp)
 101b69d:	mov    %r9d,-0x30(%rbp)
 101b6a1:	mov    %r8d,-0x2c(%rbp)
 101b6a5:	mov    -0x40(%rbp),%rax
 101b6a9:	mov    (%rax),%rdi
 101b6ac:	lea    0x0(,%rbx,8),%rsi
 101b6b4:	mov    %rdi,-0x70(%rbp)
 101b6b8:	call   1012480 <myl_rc_meta_alloc>
 101b6bd:	test   %rax,%rax
 101b6c0:	je     101b953 <schedule_clone+0x823>
 101b6c6:	test   %r14,%r14
 101b6c9:	mov    -0x68(%rbp),%r12
 101b6cd:	mov    %rax,-0x60(%rbp)
 101b6d1:	je     101b6e6 <schedule_clone+0x5b6>
 101b6d3:	shl    $0x3,%r14
 101b6d7:	mov    -0x60(%rbp),%rdi
 101b6db:	mov    %r12,%rsi
 101b6de:	mov    %r14,%rdx
 101b6e1:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101b6e6:	mov    -0x58(%rbp),%r14
 101b6ea:	mov    0x28(%r14),%rdx
 101b6ee:	shl    $0x3,%rdx
 101b6f2:	mov    -0x70(%rbp),%rdi
 101b6f6:	mov    %r12,%rsi
 101b6f9:	call   1012500 <myl_rc_meta_free>
 101b6fe:	mov    %rbx,0x28(%r14)
 101b702:	mov    -0x60(%rbp),%rax
 101b706:	mov    %rax,0x18(%r14)
 101b70a:	mov    -0x48(%rbp),%rbx
 101b70e:	mov    -0x2c(%rbp),%r8d
 101b712:	mov    -0x30(%rbp),%r9d
 101b716:	mov    -0x38(%rbp),%edx
 101b719:	mov    %edx,-0x38(%rbp)
 101b71c:	mov    %r9d,-0x30(%rbp)
 101b720:	movq   $0x0,-0x50(%rbp)
 101b728:	mov    0x28(%r13),%rax
 101b72c:	test   %rax,%rax
 101b72f:	mov    %r8d,-0x2c(%rbp)
 101b733:	je     101b77e <schedule_clone+0x64e>
 101b735:	mov    -0x40(%rbp),%rcx
 101b739:	mov    (%rcx),%rdi
 101b73c:	lea    -0x50(%rbp),%rcx
 101b740:	mov    %r15,%rsi
 101b743:	mov    %r8d,%edx
 101b746:	call   *%rax
 101b748:	mov    %eax,%r12d
 101b74b:	jmp    101b7fc <schedule_clone+0x6cc>
 101b750:	mov    %r9d,-0x30(%rbp)
 101b754:	mov    %r8d,%r14d
 101b757:	call   1011900 <myl_rc_list_require>
 101b75c:	mov    %eax,%r12d
 101b75f:	test   %eax,%eax
 101b761:	jne    101b953 <schedule_clone+0x823>
 101b767:	mov    0x0(%r13),%rdi
 101b76b:	mov    0x1608(%rdi),%rax
 101b772:	mov    %r14d,%r8d
 101b775:	mov    -0x30(%rbp),%r9d
 101b779:	jmp    101b4ca <schedule_clone+0x39a>
 101b77e:	mov    -0x8(%r15),%rax
 101b782:	mov    %rax,-0x88(%rbp)
 101b789:	mov    -0x10(%r15),%rax
 101b78d:	mov    %rax,%rcx
 101b790:	shr    $0x2,%rcx
 101b794:	bt     $0x3e,%rax
 101b799:	movabs $0x3ffffffffffffff,%rax
 101b7a3:	movabs $0x3fffffffff,%rdx
 101b7ad:	cmovae %rax,%rdx
 101b7b1:	and    %rcx,%rdx
 101b7b4:	mov    %rdx,-0x80(%rbp)
 101b7b8:	mov    %r8d,-0x78(%rbp)
 101b7bc:	movl   $0x0,-0x74(%rbp)
 101b7c3:	mov    -0x40(%rbp),%rax
 101b7c7:	mov    (%rax),%rdi
 101b7ca:	lea    -0x88(%rbp),%rsi
 101b7d1:	lea    -0x50(%rbp),%rdx
 101b7d5:	call   1012820 <myl_rc_new>
 101b7da:	mov    %eax,%r12d
 101b7dd:	test   %eax,%eax
 101b7df:	jne    101b7fc <schedule_clone+0x6cc>
 101b7e1:	mov    -0x40(%rbp),%rax
 101b7e5:	mov    (%rax),%rdi
 101b7e8:	mov    0x8(%r13),%rsi
 101b7ec:	mov    -0x50(%rbp),%rdx
 101b7f0:	mov    -0x80(%rbp),%r8
 101b7f4:	mov    %r15,%rcx
 101b7f7:	call   1016a40 <myl_rc_value_seed>
 101b7fc:	test   %r12d,%r12d
 101b7ff:	mov    -0x30(%rbp),%ecx
 101b802:	jne    101b953 <schedule_clone+0x823>
 101b808:	mov    -0x50(%rbp),%rax
 101b80c:	test   %rax,%rax
 101b80f:	je     101b979 <schedule_clone+0x849>
 101b815:	test   %cl,%cl
 101b817:	mov    -0x2c(%rbp),%r9d
 101b81b:	je     101b8bd <schedule_clone+0x78d>
 101b821:	mov    0xa0(%r14),%rdx
 101b828:	test   %rdx,%rdx
 101b82b:	je     101b8c2 <schedule_clone+0x792>
 101b831:	mov    0x30(%r14),%rcx
 101b835:	mov    %r15,%rsi
 101b838:	shr    $0x4,%rsi
 101b83c:	mov    %r9d,%edi
 101b83f:	movabs $0x9e3779b97f4a7c15,%r8
 101b849:	imul   %rdi,%r8
 101b84d:	xor    %rsi,%r8
 101b850:	mov    %r8,%rsi
 101b853:	shr    $0x1e,%rsi
 101b857:	xor    %r8,%rsi
 101b85a:	movabs $0xbf58476d1ce4e5b9,%rdi
 101b864:	imul   %rsi,%rdi
 101b868:	mov    %rdi,%rsi
 101b86b:	shr    $0x1b,%rsi
 101b86f:	xor    %rdi,%rsi
 101b872:	movabs $0x94d049bb133111eb,%rdi
 101b87c:	imul   %rsi,%rdi
 101b880:	mov    %rdi,%rsi
 101b883:	shr    $0x1f,%rsi
 101b887:	xor    %rdi,%rsi
 101b88a:	dec    %rdx
 101b88d:	jmp    101b893 <schedule_clone+0x763>
 101b88f:	nop
 101b890:	inc    %rsi
 101b893:	and    %rdx,%rsi
 101b896:	lea    (%rsi,%rsi,2),%rdi
 101b89a:	mov    (%rcx,%rdi,8),%rdi
 101b89e:	test   %rdi,%rdi
 101b8a1:	je     101b8b3 <schedule_clone+0x783>
 101b8a3:	cmp    %r15,%rdi
 101b8a6:	jne    101b890 <schedule_clone+0x760>
 101b8a8:	lea    (%rsi,%rsi,2),%rdi
 101b8ac:	cmp    %r9d,0x10(%rcx,%rdi,8)
 101b8b1:	jne    101b890 <schedule_clone+0x760>
 101b8b3:	lea    (%rsi,%rsi,2),%rdx
 101b8b7:	lea    (%rcx,%rdx,8),%rcx
 101b8bb:	jmp    101b8d5 <schedule_clone+0x7a5>
 101b8bd:	mov    -0x38(%rbp),%edx
 101b8c0:	jmp    101b8f5 <schedule_clone+0x7c5>
 101b8c2:	mov    0x98(%r14),%rcx
 101b8c9:	lea    (%rcx,%rcx,2),%rcx
 101b8cd:	lea    (%r14,%rcx,8),%rcx
 101b8d1:	add    $0x38,%rcx
 101b8d5:	mov    -0x38(%rbp),%edx
 101b8d8:	mov    %r15,(%rcx)
 101b8db:	mov    %rax,0x8(%rcx)
 101b8df:	mov    %r9d,0x10(%rcx)
 101b8e3:	movl   $0x0,0x14(%rcx)
 101b8ea:	incq   0x98(%r14)
 101b8f1:	mov    -0x50(%rbp),%rax
 101b8f5:	test   %dl,%dl
 101b8f7:	je     101b934 <schedule_clone+0x804>
 101b8f9:	mov    (%r14),%rcx
 101b8fc:	mov    0x8(%r14),%rdx
 101b900:	lea    0x1(%rdx),%rsi
 101b904:	mov    %rsi,0x8(%r14)
 101b908:	lea    (%rdx,%rdx,4),%rdx
 101b90c:	mov    %r15,(%rcx,%rdx,8)
 101b910:	mov    %rax,0x8(%rcx,%rdx,8)
 101b915:	mov    %r13,0x10(%rcx,%rdx,8)
 101b91a:	movq   $0x0,0x18(%rcx,%rdx,8)
 101b923:	mov    %r9d,0x20(%rcx,%rdx,8)
 101b928:	movl   $0x0,0x24(%rcx,%rdx,8)
 101b930:	mov    -0x50(%rbp),%rax
 101b934:	test   %r9d,%r9d
 101b937:	je     101b94d <schedule_clone+0x81d>
 101b939:	mov    0x18(%r14),%rcx
 101b93d:	mov    0x20(%r14),%rdx
 101b941:	lea    0x1(%rdx),%rsi
 101b945:	mov    %rsi,0x20(%r14)
 101b949:	mov    %rax,(%rcx,%rdx,8)
 101b94d:	mov    %rax,(%rbx)
 101b950:	xor    %r12d,%r12d
 101b953:	mov    %r12d,%eax
 101b956:	add    $0x68,%rsp
 101b95a:	pop    %rbx
 101b95b:	pop    %r12
 101b95d:	pop    %r13
 101b95f:	pop    %r14
 101b961:	pop    %r15
 101b963:	pop    %rbp
 101b964:	ret
 101b965:	xor    %edx,%edx
 101b967:	jmp    101b47b <schedule_clone+0x34b>
 101b96c:	call   1012eea <myl_rc_binding_find_slow>
 101b971:	mov    %rax,%r13
 101b974:	jmp    101b4fe <schedule_clone+0x3ce>
 101b979:	call   101246d <myl_rc_invariant_failed>
 101b97e:	int3
 101b97f:	int3

000000000101b980 <queue_mark>:
 101b980:	push   %rbp
 101b981:	mov    %rsp,%rbp
 101b984:	push   %r15
 101b986:	push   %r14
 101b988:	push   %r13
 101b98a:	push   %r12
 101b98c:	push   %rbx
 101b98d:	sub    $0x18,%rsp
 101b991:	mov    0x28(%rdi),%rcx
 101b995:	xor    %eax,%eax
 101b997:	cmpl   $0x0,0xac(%rcx)
 101b99e:	je     101bac4 <queue_mark+0x144>
 101b9a4:	movabs $0x1fffffffffffffff,%r15
 101b9ae:	lea    0x3(%r15),%rcx
 101b9b2:	test   %rcx,-0x10(%rsi)
 101b9b6:	jne    101bac4 <queue_mark+0x144>
 101b9bc:	mov    %rdi,%rbx
 101b9bf:	mov    %rsi,%r12
 101b9c2:	mov    %rsi,%rdi
 101b9c5:	call   101de80 <myl_rc_native_mutable>
 101b9ca:	test   %eax,%eax
 101b9cc:	je     101bac2 <queue_mark+0x142>
 101b9d2:	testb  $0x10,-0x9(%r12)
 101b9d8:	jne    101bad3 <queue_mark+0x153>
 101b9de:	mov    %rbx,%rcx
 101b9e1:	mov    0x28(%rbx),%r13
 101b9e5:	mov    0xb0(%r13),%rsi
 101b9ec:	mov    0xb8(%r13),%rbx
 101b9f3:	mov    0xc0(%r13),%rdx
 101b9fa:	cmp    %rdx,%rbx
 101b9fd:	jae    101ba18 <queue_mark+0x98>
 101b9ff:	mov    %r12,%rax
 101ba02:	mov    %rsi,%r15
 101ba05:	test   %rsi,%rsi
 101ba08:	jne    101baac <queue_mark+0x12c>
 101ba0e:	mov    $0x1,%eax
 101ba13:	jmp    101bac4 <queue_mark+0x144>
 101ba18:	lea    (%rdx,%rdx,1),%rax
 101ba1c:	test   %rdx,%rdx
 101ba1f:	mov    $0x10,%r14d
 101ba25:	cmovne %rax,%r14
 101ba29:	cmp    %rdx,%r14
 101ba2c:	setb   %al
 101ba2f:	cmp    %r15,%r14
 101ba32:	seta   %dl
 101ba35:	or     %al,%dl
 101ba37:	mov    $0x1,%eax
 101ba3c:	jne    101bac4 <queue_mark+0x144>
 101ba42:	mov    %rsi,-0x30(%rbp)
 101ba46:	mov    (%rcx),%rdi
 101ba49:	lea    0x0(,%r14,8),%rsi
 101ba51:	mov    %rdi,-0x38(%rbp)
 101ba55:	call   1012480 <myl_rc_meta_alloc>
 101ba5a:	mov    %rax,%r15
 101ba5d:	mov    $0x1,%eax
 101ba62:	test   %r15,%r15
 101ba65:	je     101bac4 <queue_mark+0x144>
 101ba67:	test   %rbx,%rbx
 101ba6a:	mov    -0x30(%rbp),%rsi
 101ba6e:	je     101ba87 <queue_mark+0x107>
 101ba70:	shl    $0x3,%rbx
 101ba74:	mov    %r15,%rdi
 101ba77:	mov    -0x30(%rbp),%rsi
 101ba7b:	mov    %rbx,%rdx
 101ba7e:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101ba83:	mov    -0x30(%rbp),%rsi
 101ba87:	mov    0xc0(%r13),%rdx
 101ba8e:	shl    $0x3,%rdx
 101ba92:	mov    -0x38(%rbp),%rdi
 101ba96:	call   1012500 <myl_rc_meta_free>
 101ba9b:	mov    %r14,0xc0(%r13)
 101baa2:	mov    0xb8(%r13),%rbx
 101baa9:	mov    %r12,%rax
 101baac:	mov    %r15,0xb0(%r13)
 101bab3:	lea    0x1(%rbx),%rcx
 101bab7:	mov    %rcx,0xb8(%r13)
 101babe:	mov    %rax,(%r15,%rbx,8)
 101bac2:	xor    %eax,%eax
 101bac4:	add    $0x18,%rsp
 101bac8:	pop    %rbx
 101bac9:	pop    %r12
 101bacb:	pop    %r13
 101bacd:	pop    %r14
 101bacf:	pop    %r15
 101bad1:	pop    %rbp
 101bad2:	ret
 101bad3:	call   101246d <myl_rc_invariant_failed>
 101bad8:	int3
 101bad9:	int3
 101bada:	int3
 101badb:	int3
 101badc:	int3
 101badd:	int3
 101bade:	int3
 101badf:	int3

000000000101bae0 <transfer_hold>:
 101bae0:	push   %rbp
 101bae1:	mov    %rsp,%rbp
 101bae4:	push   %r15
 101bae6:	push   %r14
 101bae8:	push   %r12
 101baea:	push   %rbx
 101baeb:	sub    $0x10,%rsp
 101baef:	mov    %rsi,%rbx
 101baf2:	test   %rdx,%rdx
 101baf5:	je     101bb73 <transfer_hold+0x93>
 101baf7:	mov    -0x10(%rdx),%rcx
 101bafb:	bt     $0x3e,%rcx
 101bb00:	jae    101bb73 <transfer_hold+0x93>
 101bb02:	shr    $0x28,%rcx
 101bb06:	and    $0xfffff,%ecx
 101bb0c:	mov    0x20(%rdi),%eax
 101bb0f:	cmp    %eax,%ecx
 101bb11:	jbe    101bb73 <transfer_hold+0x93>
 101bb13:	mov    0x28(%rdi),%rcx
 101bb17:	cmpl   $0x0,0xa8(%rcx)
 101bb1e:	je     101bba6 <transfer_hold+0xc6>
 101bb24:	lea    -0x28(%rbp),%rcx
 101bb28:	mov    %rdi,%r14
 101bb2b:	mov    %rdx,%rsi
 101bb2e:	mov    %eax,%edx
 101bb30:	call   101b130 <schedule_clone>
 101bb35:	test   %eax,%eax
 101bb37:	jne    101bbab <transfer_hold+0xcb>
 101bb39:	movq   $0x0,-0x30(%rbp)
 101bb41:	mov    %r14,%r12
 101bb44:	mov    (%r14),%rdi
 101bb47:	mov    -0x28(%rbp),%r14
 101bb4b:	lea    -0x30(%rbp),%rdx
 101bb4f:	mov    %r14,%rsi
 101bb52:	call   1012b80 <myl_rc_hold_acquire>
 101bb57:	mov    %eax,%r15d
 101bb5a:	mov    (%r12),%rdi
 101bb5e:	mov    %r14,%rsi
 101bb61:	call   1012ac0 <myl_rc_owner_release>
 101bb66:	mov    %r14,%rdx
 101bb69:	test   %r15d,%r15d
 101bb6c:	je     101bb79 <transfer_hold+0x99>
 101bb6e:	mov    %r15d,%eax
 101bb71:	jmp    101bbab <transfer_hold+0xcb>
 101bb73:	cmpl   $0x0,0x24(%rdi)
 101bb77:	je     101bb80 <transfer_hold+0xa0>
 101bb79:	mov    %rdx,(%rbx)
 101bb7c:	xor    %eax,%eax
 101bb7e:	jmp    101bbab <transfer_hold+0xcb>
 101bb80:	movq   $0x0,-0x28(%rbp)
 101bb88:	mov    (%rdi),%rdi
 101bb8b:	lea    -0x28(%rbp),%rax
 101bb8f:	mov    %rdx,%rsi
 101bb92:	mov    %rdx,%r14
 101bb95:	mov    %rax,%rdx
 101bb98:	call   1012b80 <myl_rc_hold_acquire>
 101bb9d:	mov    %r14,%rdx
 101bba0:	test   %eax,%eax
 101bba2:	jne    101bbab <transfer_hold+0xcb>
 101bba4:	jmp    101bb79 <transfer_hold+0x99>
 101bba6:	mov    $0x3,%eax
 101bbab:	add    $0x10,%rsp
 101bbaf:	pop    %rbx
 101bbb0:	pop    %r12
 101bbb2:	pop    %r14
 101bbb4:	pop    %r15
 101bbb6:	pop    %rbp
 101bbb7:	ret
 101bbb8:	int3
 101bbb9:	int3
 101bbba:	int3
 101bbbb:	int3
 101bbbc:	int3
 101bbbd:	int3
 101bbbe:	int3
 101bbbf:	int3

000000000101bbc0 <retain_pointer>:
 101bbc0:	mov    (%rdx),%rdx
 101bbc3:	test   %rdx,%rdx
 101bbc6:	je     101bbed <retain_pointer+0x2d>
 101bbc8:	mov    -0x10(%rdx),%r8
 101bbcc:	bt     $0x3e,%r8
 101bbd1:	jae    101bbf7 <retain_pointer+0x37>
 101bbd3:	mov    %r8,%r9
 101bbd6:	shr    $0x28,%r9
 101bbda:	and    $0xfffff,%r9d
 101bbe1:	mov    $0x3,%eax
 101bbe6:	cmp    0x20(%rdi),%r9d
 101bbea:	jbe    101bbf7 <retain_pointer+0x37>
 101bbec:	ret
 101bbed:	cmp    $0x5,%ecx
 101bbf0:	jne    101bc36 <retain_pointer+0x76>
 101bbf2:	jmp    101bae0 <transfer_hold>
 101bbf7:	cmp    $0x5,%ecx
 101bbfa:	je     101bae0 <transfer_hold>
 101bc00:	movabs $0x4000000000000000,%rax
 101bc0a:	add    $0x2,%rax
 101bc0e:	test   %rax,%r8
 101bc11:	jne    101bc36 <retain_pointer+0x76>
 101bc13:	test   $0x1,%r8b
 101bc17:	jne    101bc42 <retain_pointer+0x82>
 101bc19:	mov    -0x20(%rdx),%rax
 101bc1d:	cmp    $0xffffffffffffffff,%rax
 101bc21:	je     101bc3c <retain_pointer+0x7c>
 101bc23:	test   %rax,%rax
 101bc26:	jne    101bc2f <retain_pointer+0x6f>
 101bc28:	cmpq   $0x0,-0x18(%rdx)
 101bc2d:	je     101bc42 <retain_pointer+0x82>
 101bc2f:	inc    %rax
 101bc32:	mov    %rax,-0x20(%rdx)
 101bc36:	mov    %rdx,(%rsi)
 101bc39:	xor    %eax,%eax
 101bc3b:	ret
 101bc3c:	mov    $0x2,%eax
 101bc41:	ret
 101bc42:	push   %rbp
 101bc43:	mov    %rsp,%rbp
 101bc46:	call   101246d <myl_rc_invariant_failed>
 101bc4b:	int3
 101bc4c:	int3
 101bc4d:	int3
 101bc4e:	int3
 101bc4f:	int3

000000000101bc50 <myl_rc_storage_alloc>:
 101bc50:	push   %rbp
 101bc51:	mov    %rsp,%rbp
 101bc54:	push   %r15
 101bc56:	push   %r14
 101bc58:	push   %r13
 101bc5a:	push   %r12
 101bc5c:	push   %rbx
 101bc5d:	sub    $0x28,%rsp
 101bc61:	test   %rdi,%rdi
 101bc64:	je     101bfdf <myl_rc_storage_alloc+0x38f>
 101bc6a:	mov    %rsi,%r14
 101bc6d:	test   %rsi,%rsi
 101bc70:	je     101bfdf <myl_rc_storage_alloc+0x38f>
 101bc76:	mov    %rdi,%rbx
 101bc79:	mov    0x1608(%rdi),%rax
 101bc80:	test   %rax,%rax
 101bc83:	je     101bfdf <myl_rc_storage_alloc+0x38f>
 101bc89:	mov    %ecx,%r12d
 101bc8c:	mov    %rdx,%r15
 101bc8f:	test   %ecx,%ecx
 101bc91:	setne  %cl
 101bc94:	cmp    $0x1,%rdx
 101bc98:	setne  %dl
 101bc9b:	or     %cl,%dl
 101bc9d:	jne    101bcab <myl_rc_storage_alloc+0x5b>
 101bc9f:	lea    0x34a(%rip),%rcx        # 101bff0 <allocate>
 101bca6:	cmp    %rcx,(%rax)
 101bca9:	je     101bd27 <myl_rc_storage_alloc+0xd7>
 101bcab:	cmp    %r14,0x110(%rax)
 101bcb2:	je     101bcc8 <myl_rc_storage_alloc+0x78>
 101bcb4:	mov    %rbx,%rdi
 101bcb7:	mov    %r14,%rsi
 101bcba:	call   101d5a0 <myl_rc_native_shape>
 101bcbf:	test   %rax,%rax
 101bcc2:	je     101bf9d <myl_rc_storage_alloc+0x34d>
 101bcc8:	test   %r12d,%r12d
 101bccb:	setne  %al
 101bcce:	cmp    $0x2,%r15
 101bcd2:	setb   %cl
 101bcd5:	or     %al,%cl
 101bcd7:	jne    101bf5e <myl_rc_storage_alloc+0x30e>
 101bcdd:	mov    (%r14),%r13
 101bce0:	test   %r13,%r13
 101bce3:	je     101bf5e <myl_rc_storage_alloc+0x30e>
 101bce9:	cmpq   $0x10,0x8(%r14)
 101bcee:	ja     101bf5e <myl_rc_storage_alloc+0x30e>
 101bcf4:	mov    0x1608(%rbx),%rax
 101bcfb:	lea    0x2ee(%rip),%rcx        # 101bff0 <allocate>
 101bd02:	cmp    %rcx,(%rax)
 101bd05:	jne    101bf5e <myl_rc_storage_alloc+0x30e>
 101bd0b:	cmp    $0x1fe0,%r13
 101bd12:	ja     101be6e <myl_rc_storage_alloc+0x21e>
 101bd18:	mov    $0x1fe0,%eax
 101bd1d:	xor    %edx,%edx
 101bd1f:	div    %r13d
 101bd22:	jmp    101be70 <myl_rc_storage_alloc+0x220>
 101bd27:	mov    0x20(%rax),%r13
 101bd2b:	cmp    %r14,0x210(%r13)
 101bd32:	je     101bd8a <myl_rc_storage_alloc+0x13a>
 101bd34:	mov    0x34(%r14),%ecx
 101bd38:	cmp    %rcx,0xa0(%rax)
 101bd3f:	jbe    101bf28 <myl_rc_storage_alloc+0x2d8>
 101bd45:	mov    0x98(%rax),%rax
 101bd4c:	shl    $0x4,%rcx
 101bd50:	cmp    %r14,(%rax,%rcx,1)
 101bd54:	jne    101bf28 <myl_rc_storage_alloc+0x2d8>
 101bd5a:	add    %rcx,%rax
 101bd5d:	mov    0x8(%rax),%rax
 101bd61:	test   %rax,%rax
 101bd64:	je     101bf3c <myl_rc_storage_alloc+0x2ec>
 101bd6a:	mov    0xc0(%rax),%esi
 101bd70:	test   %esi,%esi
 101bd72:	je     101bf3c <myl_rc_storage_alloc+0x2ec>
 101bd78:	dec    %esi
 101bd7a:	mov    %r14,0x210(%r13)
 101bd81:	mov    %rsi,0x218(%r13)
 101bd88:	jmp    101bd91 <myl_rc_storage_alloc+0x141>
 101bd8a:	mov    0x218(%r13),%rsi
 101bd91:	mov    0x1610(%rbx,%rsi,8),%r15
 101bd99:	test   %r15,%r15
 101bd9c:	je     101bdab <myl_rc_storage_alloc+0x15b>
 101bd9e:	mov    (%r15),%rax
 101bda1:	mov    %rax,0x1610(%rbx,%rsi,8)
 101bda9:	jmp    101bdbf <myl_rc_storage_alloc+0x16f>
 101bdab:	mov    %rbx,%rdi
 101bdae:	call   101cd90 <slab_refill>
 101bdb3:	mov    %rax,%r15
 101bdb6:	test   %rax,%rax
 101bdb9:	je     101bf17 <myl_rc_storage_alloc+0x2c7>
 101bdbf:	lea    0x20(%r15),%rax
 101bdc3:	mov    (%r14),%rdx
 101bdc6:	lea    0xf(%rdx),%rcx
 101bdca:	shr    $0x4,%rcx
 101bdce:	cmp    $0x8,%rcx
 101bdd2:	ja     101bebc <myl_rc_storage_alloc+0x26c>
 101bdd8:	lea    -0x18c7b(%rip),%rdx        # 1003164 <myl_rc_map_sentinel+0xc4>
 101bddf:	movslq (%rdx,%rcx,4),%rcx
 101bde3:	add    %rdx,%rcx
 101bde6:	jmp    *%rcx
 101bde8:	vxorps %xmm0,%xmm0,%xmm0
 101bdec:	vmovaps %xmm0,0x90(%r15)
 101bdf5:	vxorps %xmm0,%xmm0,%xmm0
 101bdf9:	vmovaps %xmm0,0x80(%r15)
 101be02:	vxorps %xmm0,%xmm0,%xmm0
 101be06:	vmovaps %xmm0,0x70(%r15)
 101be0c:	vxorps %xmm0,%xmm0,%xmm0
 101be10:	vmovaps %xmm0,0x60(%r15)
 101be16:	vxorps %xmm0,%xmm0,%xmm0
 101be1a:	vmovaps %xmm0,0x50(%r15)
 101be20:	vxorps %xmm0,%xmm0,%xmm0
 101be24:	vmovaps %xmm0,0x40(%r15)
 101be2a:	vxorps %xmm0,%xmm0,%xmm0
 101be2e:	vmovaps %xmm0,0x30(%r15)
 101be34:	vxorps %xmm0,%xmm0,%xmm0
 101be38:	vmovaps %xmm0,(%rax)
 101be3c:	movq   $0x1,(%r15)
 101be43:	movq   $0x0,0x8(%r15)
 101be4b:	movq   $0x4,0x10(%r15)
 101be53:	mov    %r14,0x18(%r15)
 101be57:	vmovdqu 0x40(%rbx),%xmm0
 101be5c:	vpcmpeqd %xmm1,%xmm1,%xmm1
 101be60:	vpsubq %xmm1,%xmm0,%xmm0
 101be64:	vmovdqu %xmm0,0x40(%rbx)
 101be69:	jmp    101bf9f <myl_rc_storage_alloc+0x34f>
 101be6e:	xor    %eax,%eax
 101be70:	cmp    %rax,%r15
 101be73:	ja     101bf5e <myl_rc_storage_alloc+0x30e>
 101be79:	imul   %r15,%r13
 101be7d:	lea    0x20(%r13),%rax
 101be81:	mov    $0x20,%esi
 101be86:	cmp    $0x2000,%rax
 101be8c:	ja     101bea1 <myl_rc_storage_alloc+0x251>
 101be8e:	lea    0x2f(%r13),%rax
 101be92:	shr    $0x4,%rax
 101be96:	lea    -0x18b5d(%rip),%rcx        # 1003340 <class_of>
 101be9d:	movzbl (%rax,%rcx,1),%esi
 101bea1:	mov    0x1610(%rbx,%rsi,8),%r12
 101bea9:	test   %r12,%r12
 101beac:	je     101bed1 <myl_rc_storage_alloc+0x281>
 101beae:	mov    (%r12),%rax
 101beb2:	mov    %rax,0x1610(%rbx,%rsi,8)
 101beba:	jmp    101bee1 <myl_rc_storage_alloc+0x291>
 101bebc:	mov    %rax,%rdi
 101bebf:	xor    %esi,%esi
 101bec1:	mov    %rax,%r12
 101bec4:	call   101e4a0 <compiler_rt.fastMemset>
 101bec9:	mov    %r12,%rax
 101becc:	jmp    101be3c <myl_rc_storage_alloc+0x1ec>
 101bed1:	mov    %rbx,%rdi
 101bed4:	call   101cd90 <slab_refill>
 101bed9:	mov    %rax,%r12
 101bedc:	test   %rax,%rax
 101bedf:	je     101bf17 <myl_rc_storage_alloc+0x2c7>
 101bee1:	lea    0x20(%r12),%rdi
 101bee6:	mov    %r13,%rsi
 101bee9:	call   101c2c0 <zero_payload>
 101beee:	lea    0x20(%r12),%rax
 101bef3:	movq   $0x1,(%r12)
 101befb:	movq   $0x0,0x8(%r12)
 101bf04:	shl    $0x2,%r15
 101bf08:	mov    %r15,0x10(%r12)
 101bf0d:	mov    %r14,0x18(%r12)
 101bf12:	jmp    101be57 <myl_rc_storage_alloc+0x207>
 101bf17:	mov    %rbx,%rdi
 101bf1a:	mov    $0x1,%esi
 101bf1f:	call   1012560 <myl_rc_record_failure>
 101bf24:	xor    %eax,%eax
 101bf26:	jmp    101bf9f <myl_rc_storage_alloc+0x34f>
 101bf28:	mov    %rbx,%rdi
 101bf2b:	mov    %r14,%rsi
 101bf2e:	call   1012eea <myl_rc_binding_find_slow>
 101bf33:	test   %rax,%rax
 101bf36:	jne    101bd6a <myl_rc_storage_alloc+0x11a>
 101bf3c:	mov    %rbx,%rdi
 101bf3f:	mov    %r14,%rsi
 101bf42:	call   101d5a0 <myl_rc_native_shape>
 101bf47:	test   %rax,%rax
 101bf4a:	je     101bf9d <myl_rc_storage_alloc+0x34d>
 101bf4c:	cmpq   $0x10,0x8(%r14)
 101bf51:	ja     101bf5e <myl_rc_storage_alloc+0x30e>
 101bf53:	mov    (%r14),%rax
 101bf56:	cmp    $0x1fe0,%rax
 101bf5c:	jbe    101bfae <myl_rc_storage_alloc+0x35e>
 101bf5e:	mov    %r14,-0x48(%rbp)
 101bf62:	mov    %r15,-0x40(%rbp)
 101bf66:	mov    %r12d,-0x38(%rbp)
 101bf6a:	movl   $0x0,-0x34(%rbp)
 101bf71:	movq   $0x0,-0x30(%rbp)
 101bf79:	lea    -0x48(%rbp),%rsi
 101bf7d:	lea    -0x30(%rbp),%rdx
 101bf81:	mov    %rbx,%rdi
 101bf84:	call   1012820 <myl_rc_new>
 101bf89:	test   %eax,%eax
 101bf8b:	je     101bf97 <myl_rc_storage_alloc+0x347>
 101bf8d:	mov    %rbx,%rdi
 101bf90:	mov    %eax,%esi
 101bf92:	call   1012560 <myl_rc_record_failure>
 101bf97:	mov    -0x30(%rbp),%rax
 101bf9b:	jmp    101bf9f <myl_rc_storage_alloc+0x34f>
 101bf9d:	xor    %eax,%eax
 101bf9f:	add    $0x28,%rsp
 101bfa3:	pop    %rbx
 101bfa4:	pop    %r12
 101bfa6:	pop    %r13
 101bfa8:	pop    %r14
 101bfaa:	pop    %r15
 101bfac:	pop    %rbp
 101bfad:	ret
 101bfae:	add    $0x2f,%rax
 101bfb2:	shr    $0x4,%rax
 101bfb6:	lea    -0x18c7d(%rip),%rcx        # 1003340 <class_of>
 101bfbd:	movzbl (%rax,%rcx,1),%r15d
 101bfc2:	mov    %rbx,%rdi
 101bfc5:	mov    %r14,%rsi
 101bfc8:	call   101c280 <myl_rc_binding_find>
 101bfcd:	mov    %r15,%rsi
 101bfd0:	mov    %esi,%ecx
 101bfd2:	inc    %ecx
 101bfd4:	mov    %ecx,0xc0(%rax)
 101bfda:	jmp    101bd7a <myl_rc_storage_alloc+0x12a>
 101bfdf:	call   101246d <myl_rc_invariant_failed>
 101bfe4:	int3
 101bfe5:	int3
 101bfe6:	int3
 101bfe7:	int3
 101bfe8:	int3
 101bfe9:	int3
 101bfea:	int3
 101bfeb:	int3
 101bfec:	int3
 101bfed:	int3
 101bfee:	int3
 101bfef:	int3

000000000101bff0 <allocate>:
 101bff0:	push   %rbp
 101bff1:	mov    %rsp,%rbp
 101bff4:	push   %r15
 101bff6:	push   %r14
 101bff8:	push   %r13
 101bffa:	push   %r12
 101bffc:	push   %rbx
 101bffd:	push   %rax
 101bffe:	mov    %rdx,%rbx
 101c001:	movq   $0x0,(%rdx)
 101c008:	mov    0x10(%rsi),%ecx
 101c00b:	mov    (%rsi),%r8
 101c00e:	test   %ecx,%ecx
 101c010:	je     101c03b <allocate+0x4b>
 101c012:	mov    0x8(%rsi),%rdx
 101c016:	mov    %r8,%rsi
 101c019:	call   1010450 <myl_native_arena_alloc>
 101c01e:	mov    %rax,%rcx
 101c021:	mov    %rax,(%rbx)
 101c024:	xor    %eax,%eax
 101c026:	test   %rcx,%rcx
 101c029:	sete   %al
 101c02c:	add    $0x8,%rsp
 101c030:	pop    %rbx
 101c031:	pop    %r12
 101c033:	pop    %r13
 101c035:	pop    %r14
 101c037:	pop    %r15
 101c039:	pop    %rbp
 101c03a:	ret
 101c03b:	mov    $0x1,%eax
 101c040:	test   %r8,%r8
 101c043:	je     101c02c <allocate+0x3c>
 101c045:	cmpq   $0x10,0x8(%r8)
 101c04a:	ja     101c02c <allocate+0x3c>
 101c04c:	mov    0x8(%rsi),%r9
 101c050:	mov    %r9,%rcx
 101c053:	shr    $0x3a,%rcx
 101c057:	jne    101c02c <allocate+0x3c>
 101c059:	mov    (%r8),%r14
 101c05c:	test   %r14,%r14
 101c05f:	je     101c07a <allocate+0x8a>
 101c061:	mov    $0xffffffffffffffdf,%rax
 101c068:	xor    %edx,%edx
 101c06a:	div    %r14
 101c06d:	mov    %rax,%rcx
 101c070:	mov    $0x1,%eax
 101c075:	cmp    %rcx,%r9
 101c078:	ja     101c02c <allocate+0x3c>
 101c07a:	test   %rdi,%rdi
 101c07d:	je     101c270 <allocate+0x280>
 101c083:	cmpq   $0x0,0x1608(%rdi)
 101c08b:	je     101c270 <allocate+0x280>
 101c091:	imul   %r9,%r14
 101c095:	lea    0x20(%r14),%r13
 101c099:	cmp    $0x2000,%r13
 101c0a0:	ja     101c0dc <allocate+0xec>
 101c0a2:	mov    %rsi,%r13
 101c0a5:	lea    0x2f(%r14),%rax
 101c0a9:	shr    $0x4,%rax
 101c0ad:	lea    -0x18d74(%rip),%rcx        # 1003340 <class_of>
 101c0b4:	movzbl (%rax,%rcx,1),%esi
 101c0b8:	mov    0x1610(%rdi,%rsi,8),%r15
 101c0c0:	test   %r15,%r15
 101c0c3:	je     101c15e <allocate+0x16e>
 101c0c9:	mov    (%r15),%rax
 101c0cc:	mov    %rdi,%r12
 101c0cf:	mov    %rax,0x1610(%rdi,%rsi,8)
 101c0d7:	jmp    101c177 <allocate+0x187>
 101c0dc:	cmp    $0xffffffffffffffcf,%r13
 101c0e0:	ja     101c02c <allocate+0x3c>
 101c0e6:	mov    %rsi,-0x30(%rbp)
 101c0ea:	add    $0x50,%r14
 101c0ee:	mov    0x18(%rdi),%rax
 101c0f2:	mov    %rax,%rcx
 101c0f5:	add    %r14,%rcx
 101c0f8:	jb     101c11a <allocate+0x12a>
 101c0fa:	mov    0x58(%rdi),%rcx
 101c0fe:	test   %rcx,%rcx
 101c101:	je     101c18d <allocate+0x19d>
 101c107:	sub    %rax,%rcx
 101c10a:	setb   %al
 101c10d:	cmp    %rcx,%r14
 101c110:	seta   %cl
 101c113:	or     %al,%cl
 101c115:	cmp    $0x1,%cl
 101c118:	jne    101c18d <allocate+0x19d>
 101c11a:	mov    %rdi,%r15
 101c11d:	call   101cb90 <trim_empty>
 101c122:	mov    %r15,%rdi
 101c125:	mov    0x18(%r15),%rax
 101c129:	mov    %rax,%rcx
 101c12c:	add    %r14,%rcx
 101c12f:	jb     101c14d <allocate+0x15d>
 101c131:	mov    0x58(%rdi),%rcx
 101c135:	test   %rcx,%rcx
 101c138:	je     101c18d <allocate+0x19d>
 101c13a:	sub    %rax,%rcx
 101c13d:	setb   %al
 101c140:	cmp    %rcx,%r14
 101c143:	seta   %cl
 101c146:	or     %al,%cl
 101c148:	cmp    $0x1,%cl
 101c14b:	jne    101c18d <allocate+0x19d>
 101c14d:	movl   $0x1,0x6c(%rdi)
 101c154:	mov    $0x1,%eax
 101c159:	jmp    101c02c <allocate+0x3c>
 101c15e:	mov    %rdi,%r12
 101c161:	call   101cd90 <slab_refill>
 101c166:	mov    %rax,%r15
 101c169:	mov    $0x1,%eax
 101c16e:	test   %r15,%r15
 101c171:	je     101c02c <allocate+0x3c>
 101c177:	lea    0x20(%r15),%rdi
 101c17b:	mov    %r14,%rsi
 101c17e:	call   101c2c0 <zero_payload>
 101c183:	xor    %ecx,%ecx
 101c185:	mov    %r13,%rax
 101c188:	jmp    101c227 <allocate+0x237>
 101c18d:	mov    %rdi,%r12
 101c190:	mov    %r14,%rdi
 101c193:	call   101cb10 <large_block>
 101c198:	test   %rax,%rax
 101c19b:	je     101c1a2 <allocate+0x1b2>
 101c19d:	mov    %rax,%r15
 101c1a0:	jmp    101c1c3 <allocate+0x1d3>
 101c1a2:	mov    %r12,%rdi
 101c1a5:	call   101cb90 <trim_empty>
 101c1aa:	mov    %r14,%rdi
 101c1ad:	call   101cb10 <large_block>
 101c1b2:	mov    %rax,%r15
 101c1b5:	test   %rax,%rax
 101c1b8:	mov    $0x1,%eax
 101c1bd:	je     101c02c <allocate+0x3c>
 101c1c3:	mov    0x1608(%r12),%rcx
 101c1cb:	test   %rcx,%rcx
 101c1ce:	mov    -0x30(%rbp),%rax
 101c1d2:	je     101c270 <allocate+0x280>
 101c1d8:	mov    0x20(%rcx),%rcx
 101c1dc:	mov    0x200(%rcx),%rdx
 101c1e3:	movq   $0x0,(%r15)
 101c1ea:	mov    %rdx,0x8(%r15)
 101c1ee:	mov    %r14,0x10(%r15)
 101c1f2:	mov    %r13,0x18(%r15)
 101c1f6:	movq   $0x0,0x28(%r15)
 101c1fe:	test   %rdx,%rdx
 101c201:	je     101c206 <allocate+0x216>
 101c203:	mov    %r15,(%rdx)
 101c206:	mov    %r15,0x200(%rcx)
 101c20d:	add    %r14,0x18(%r12)
 101c212:	add    %r14,0x208(%rcx)
 101c219:	add    $0x30,%r15
 101c21d:	movabs $0x8000000000000000,%rcx
 101c227:	mov    (%rax),%rdx
 101c22a:	mov    0x8(%rax),%rax
 101c22e:	movq   $0x1,(%r15)
 101c235:	movq   $0x0,0x8(%r15)
 101c23d:	shl    $0x2,%rax
 101c241:	or     %rcx,%rax
 101c244:	mov    %rax,0x10(%r15)
 101c248:	mov    %rdx,0x18(%r15)
 101c24c:	vmovdqu 0x40(%r12),%xmm0
 101c253:	vpcmpeqd %xmm1,%xmm1,%xmm1
 101c257:	vpsubq %xmm1,%xmm0,%xmm0
 101c25b:	vmovdqu %xmm0,0x40(%r12)
 101c262:	add    $0x20,%r15
 101c266:	mov    %r15,(%rbx)
 101c269:	xor    %eax,%eax
 101c26b:	jmp    101c02c <allocate+0x3c>
 101c270:	call   101246d <myl_rc_invariant_failed>
 101c275:	int3
 101c276:	int3
 101c277:	int3
 101c278:	int3
 101c279:	int3
 101c27a:	int3
 101c27b:	int3
 101c27c:	int3
 101c27d:	int3
 101c27e:	int3
 101c27f:	int3

000000000101c280 <myl_rc_binding_find>:
 101c280:	mov    0x1608(%rdi),%rcx
 101c287:	mov    0x34(%rsi),%eax
 101c28a:	cmp    %rax,0xa0(%rcx)
 101c291:	jbe    101c2ac <myl_rc_binding_find+0x2c>
 101c293:	mov    0x98(%rcx),%rcx
 101c29a:	shl    $0x4,%rax
 101c29e:	cmp    %rsi,(%rcx,%rax,1)
 101c2a2:	jne    101c2ac <myl_rc_binding_find+0x2c>
 101c2a4:	add    %rax,%rcx
 101c2a7:	mov    0x8(%rcx),%rax
 101c2ab:	ret
 101c2ac:	push   %rbp
 101c2ad:	mov    %rsp,%rbp
 101c2b0:	call   1012eea <myl_rc_binding_find_slow>
 101c2b5:	pop    %rbp
 101c2b6:	ret
 101c2b7:	int3
 101c2b8:	int3
 101c2b9:	int3
 101c2ba:	int3
 101c2bb:	int3
 101c2bc:	int3
 101c2bd:	int3
 101c2be:	int3
 101c2bf:	int3

000000000101c2c0 <zero_payload>:
 101c2c0:	push   %rbp
 101c2c1:	mov    %rsp,%rbp
 101c2c4:	lea    0xf(%rsi),%rax
 101c2c8:	shr    $0x4,%rax
 101c2cc:	cmp    $0x8,%rax
 101c2d0:	ja     101c32b <zero_payload+0x6b>
 101c2d2:	lea    -0x19151(%rip),%rcx        # 1003188 <myl_rc_map_sentinel+0xe8>
 101c2d9:	movslq (%rcx,%rax,4),%rax
 101c2dd:	add    %rcx,%rax
 101c2e0:	jmp    *%rax
 101c2e2:	vxorps %xmm0,%xmm0,%xmm0
 101c2e6:	vmovaps %xmm0,0x70(%rdi)
 101c2eb:	vxorps %xmm0,%xmm0,%xmm0
 101c2ef:	vmovaps %xmm0,0x60(%rdi)
 101c2f4:	vxorps %xmm0,%xmm0,%xmm0
 101c2f8:	vmovaps %xmm0,0x50(%rdi)
 101c2fd:	vxorps %xmm0,%xmm0,%xmm0
 101c301:	vmovaps %xmm0,0x40(%rdi)
 101c306:	vxorps %xmm0,%xmm0,%xmm0
 101c30a:	vmovaps %xmm0,0x30(%rdi)
 101c30f:	vxorps %xmm0,%xmm0,%xmm0
 101c313:	vmovaps %xmm0,0x20(%rdi)
 101c318:	vxorps %xmm0,%xmm0,%xmm0
 101c31c:	vmovaps %xmm0,0x10(%rdi)
 101c321:	vxorps %xmm0,%xmm0,%xmm0
 101c325:	vmovaps %xmm0,(%rdi)
 101c329:	pop    %rbp
 101c32a:	ret
 101c32b:	mov    %rsi,%rdx
 101c32e:	xor    %esi,%esi
 101c330:	pop    %rbp
 101c331:	jmp    101e4a0 <compiler_rt.fastMemset>
 101c336:	int3
 101c337:	int3
 101c338:	int3
 101c339:	int3
 101c33a:	int3
 101c33b:	int3
 101c33c:	int3
 101c33d:	int3
 101c33e:	int3
 101c33f:	int3

000000000101c340 <myl_rc_storage_retire>:
 101c340:	push   %rbp
 101c341:	mov    %rsp,%rbp
 101c344:	cmpq   $0x0,-0x10(%rsi)
 101c349:	js     101c3ad <myl_rc_storage_retire+0x6d>
 101c34b:	mov    0x40(%rdi),%rcx
 101c34f:	test   %rcx,%rcx
 101c352:	je     101c429 <myl_rc_storage_retire+0xe9>
 101c358:	lea    -0x20(%rsi),%rax
 101c35c:	mov    0x50(%rdi),%rdx
 101c360:	cmp    $0xffffffffffffffff,%rdx
 101c364:	je     101c36d <myl_rc_storage_retire+0x2d>
 101c366:	inc    %rdx
 101c369:	mov    %rdx,0x50(%rdi)
 101c36d:	mov    %rax,%rdx
 101c370:	and    $0xffffffffffff0000,%rdx
 101c377:	dec    %rcx
 101c37a:	mov    %rcx,0x40(%rdi)
 101c37e:	movq   $0x3,-0x10(%rsi)
 101c386:	mov    (%rdx),%rcx
 101c389:	mov    0x1610(%rdi,%rcx,8),%rcx
 101c391:	mov    %rcx,-0x20(%rsi)
 101c395:	mov    (%rdx),%rcx
 101c398:	mov    %rax,0x1610(%rdi,%rcx,8)
 101c3a0:	mov    0x8(%rdx),%rax
 101c3a4:	add    %rax,0x1710(%rdi)
 101c3ab:	pop    %rbp
 101c3ac:	ret
 101c3ad:	mov    0x50(%rdi),%rax
 101c3b1:	cmp    $0xffffffffffffffff,%rax
 101c3b5:	je     101c3be <myl_rc_storage_retire+0x7e>
 101c3b7:	inc    %rax
 101c3ba:	mov    %rax,0x50(%rdi)
 101c3be:	decq   0x40(%rdi)
 101c3c2:	mov    -0x50(%rsi),%rax
 101c3c6:	test   %rax,%rax
 101c3c9:	je     101c407 <myl_rc_storage_retire+0xc7>
 101c3cb:	mov    -0x48(%rsi),%rcx
 101c3cf:	mov    %rcx,0x8(%rax)
 101c3d3:	test   %rcx,%rcx
 101c3d6:	je     101c3db <myl_rc_storage_retire+0x9b>
 101c3d8:	mov    %rax,(%rcx)
 101c3db:	mov    -0x40(%rsi),%rax
 101c3df:	sub    %rax,0x18(%rdi)
 101c3e3:	mov    0x1608(%rdi),%rcx
 101c3ea:	test   %rcx,%rcx
 101c3ed:	je     101c429 <myl_rc_storage_retire+0xe9>
 101c3ef:	add    $0xffffffffffffffb0,%rsi
 101c3f3:	mov    0x20(%rcx),%rcx
 101c3f7:	sub    %rax,0x208(%rcx)
 101c3fe:	mov    %rsi,%rdi
 101c401:	pop    %rbp
 101c402:	jmp    101c430 <large_release>
 101c407:	mov    0x1608(%rdi),%rdx
 101c40e:	test   %rdx,%rdx
 101c411:	je     101c429 <myl_rc_storage_retire+0xe9>
 101c413:	mov    -0x48(%rsi),%rcx
 101c417:	mov    0x20(%rdx),%rdx
 101c41b:	mov    %rcx,0x200(%rdx)
 101c422:	test   %rcx,%rcx
 101c425:	jne    101c3d8 <myl_rc_storage_retire+0x98>
 101c427:	jmp    101c3db <myl_rc_storage_retire+0x9b>
 101c429:	call   101246d <myl_rc_invariant_failed>
 101c42e:	int3
 101c42f:	int3

000000000101c430 <large_release>:
 101c430:	push   %rbp
 101c431:	mov    %rsp,%rbp
 101c434:	mov    0x20(%rdi),%rsi
 101c438:	test   %rsi,%rsi
 101c43b:	je     101c443 <large_release+0x13>
 101c43d:	pop    %rbp
 101c43e:	jmp    101ef30 <munmap@plt>
 101c443:	pop    %rbp
 101c444:	jmp    101edc0 <free@plt>
 101c449:	int3
 101c44a:	int3
 101c44b:	int3
 101c44c:	int3
 101c44d:	int3
 101c44e:	int3
 101c44f:	int3

000000000101c450 <release_extents>:
 101c450:	push   %rbp
 101c451:	mov    %rsp,%rbp
 101c454:	push   %r15
 101c456:	push   %r14
 101c458:	push   %r13
 101c45a:	push   %r12
 101c45c:	push   %rbx
 101c45d:	push   %rax
 101c45e:	mov    0x1608(%rdi),%rax
 101c465:	cmpl   $0x0,0xd0(%rax)
 101c46c:	jne    101c5e6 <release_extents+0x196>
 101c472:	cmpq   $0x0,0xc0(%rax)
 101c47a:	jne    101c5e6 <release_extents+0x196>
 101c480:	mov    %rdi,%rbx
 101c483:	mov    0x20(%rax),%r14
 101c487:	xor    %eax,%eax
 101c489:	jmp    101c4a5 <release_extents+0x55>
 101c48b:	nopl   0x0(%rax,%rax,1)
 101c490:	movq   $0x0,0x1610(%rbx,%rax,8)
 101c49c:	inc    %rax
 101c49f:	cmp    $0x20,%rax
 101c4a3:	je     101c4d8 <release_extents+0x88>
 101c4a5:	mov    0x1610(%rbx,%rax,8),%rcx
 101c4ad:	test   %rcx,%rcx
 101c4b0:	je     101c490 <release_extents+0x40>
 101c4b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c4c0:	mov    %rcx,%rdx
 101c4c3:	and    $0xffffffffffff0000,%rdx
 101c4ca:	decq   0x38(%rdx)
 101c4ce:	mov    (%rcx),%rcx
 101c4d1:	test   %rcx,%rcx
 101c4d4:	jne    101c4c0 <release_extents+0x70>
 101c4d6:	jmp    101c490 <release_extents+0x40>
 101c4d8:	movq   $0x0,0x1710(%rbx)
 101c4e3:	mov    0x200(%r14),%rdi
 101c4ea:	xor    %r15d,%r15d
 101c4ed:	test   %rdi,%rdi
 101c4f0:	je     101c542 <release_extents+0xf2>
 101c4f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c500:	mov    0x8(%rdi),%rax
 101c504:	mov    %rax,0x200(%r14)
 101c50b:	mov    0x10(%rdi),%rax
 101c50f:	sub    %rax,0x18(%rbx)
 101c513:	mov    0x1608(%rbx),%rcx
 101c51a:	test   %rcx,%rcx
 101c51d:	je     101c5e6 <release_extents+0x196>
 101c523:	mov    0x20(%rcx),%rcx
 101c527:	sub    %rax,0x208(%rcx)
 101c52e:	call   101c430 <large_release>
 101c533:	inc    %r15
 101c536:	mov    0x200(%r14),%rdi
 101c53d:	test   %rdi,%rdi
 101c540:	jne    101c500 <release_extents+0xb0>
 101c542:	xor    %r12d,%r12d
 101c545:	jmp    101c559 <release_extents+0x109>
 101c547:	nopw   0x0(%rax,%rax,1)
 101c550:	inc    %r12
 101c553:	cmp    $0x20,%r12
 101c557:	je     101c58f <release_extents+0x13f>
 101c559:	mov    %r12,%r13
 101c55c:	shl    $0x4,%r13
 101c560:	mov    (%r14,%r13,1),%rsi
 101c564:	test   %rsi,%rsi
 101c567:	je     101c550 <release_extents+0x100>
 101c569:	add    %r14,%r13
 101c56c:	nopl   0x0(%rax)
 101c570:	add    0x38(%rsi),%r15
 101c574:	movq   $0x0,0x38(%rsi)
 101c57c:	mov    %rbx,%rdi
 101c57f:	call   101cc80 <slab_free>
 101c584:	mov    0x0(%r13),%rsi
 101c588:	test   %rsi,%rsi
 101c58b:	jne    101c570 <release_extents+0x120>
 101c58d:	jmp    101c550 <release_extents+0x100>
 101c58f:	mov    0x40(%rbx),%rax
 101c593:	sub    %r15,%rax
 101c596:	jb     101c5e6 <release_extents+0x196>
 101c598:	mov    0x440(%r14),%rcx
 101c59f:	lea    0x458(,%rcx,8),%rcx
 101c5a7:	cmp    %rcx,0x208(%r14)
 101c5ae:	jne    101c5e6 <release_extents+0x196>
 101c5b0:	mov    %rax,0x40(%rbx)
 101c5b4:	mov    0x1608(%rbx),%rax
 101c5bb:	movq   $0x0,0xc8(%rax)
 101c5c6:	mov    0x50(%rbx),%rax
 101c5ca:	cmp    $0xffffffffffffffff,%rax
 101c5ce:	je     101c5d7 <release_extents+0x187>
 101c5d0:	inc    %rax
 101c5d3:	mov    %rax,0x50(%rbx)
 101c5d7:	add    $0x8,%rsp
 101c5db:	pop    %rbx
 101c5dc:	pop    %r12
 101c5de:	pop    %r13
 101c5e0:	pop    %r14
 101c5e2:	pop    %r15
 101c5e4:	pop    %rbp
 101c5e5:	ret
 101c5e6:	call   101246d <myl_rc_invariant_failed>
 101c5eb:	int3
 101c5ec:	int3
 101c5ed:	int3
 101c5ee:	int3
 101c5ef:	int3

000000000101c5f0 <myl_rc_storage_init>:
 101c5f0:	push   %rbp
 101c5f1:	mov    %rsp,%rbp
 101c5f4:	push   %r15
 101c5f6:	push   %r14
 101c5f8:	push   %rbx
 101c5f9:	push   %rax
 101c5fa:	mov    %rdi,%rbx
 101c5fd:	mov    0x18(%rdi),%r15
 101c601:	cmp    $0xfffffffffffffba7,%r15
 101c608:	ja     101c628 <myl_rc_storage_init+0x38>
 101c60a:	mov    0x58(%rbx),%rax
 101c60e:	test   %rax,%rax
 101c611:	je     101c636 <myl_rc_storage_init+0x46>
 101c613:	sub    %r15,%rax
 101c616:	setb   %cl
 101c619:	cmp    $0x458,%rax
 101c61f:	setb   %al
 101c622:	or     %cl,%al
 101c624:	cmp    $0x1,%al
 101c626:	jne    101c636 <myl_rc_storage_init+0x46>
 101c628:	movl   $0x1,0x6c(%rbx)
 101c62f:	mov    $0x1,%eax
 101c634:	jmp    101c6b3 <myl_rc_storage_init+0xc3>
 101c636:	mov    $0x1,%edi
 101c63b:	mov    $0x458,%esi
 101c640:	call   101ed70 <calloc@plt>
 101c645:	test   %rax,%rax
 101c648:	je     101c68d <myl_rc_storage_init+0x9d>
 101c64a:	mov    %rax,%r14
 101c64d:	add    $0x458,%r15
 101c654:	mov    %r15,0x18(%rbx)
 101c658:	movq   $0x458,0x208(%rax)
 101c663:	lea    0xcac6(%rip),%rsi        # 1029130 <allocator>
 101c66a:	mov    %rbx,%rdi
 101c66d:	mov    %rax,%rdx
 101c670:	call   10125c0 <myl_rc_heap_init>
 101c675:	test   %eax,%eax
 101c677:	je     101c694 <myl_rc_storage_init+0xa4>
 101c679:	addq   $0xfffffffffffffba8,0x18(%rbx)
 101c681:	mov    %r14,%rdi
 101c684:	mov    %eax,%ebx
 101c686:	call   101edc0 <free@plt>
 101c68b:	jmp    101c6b1 <myl_rc_storage_init+0xc1>
 101c68d:	mov    $0x1,%eax
 101c692:	jmp    101c6b3 <myl_rc_storage_init+0xc3>
 101c694:	lea    0xcaf5(%rip),%rsi        # 1029190 <raw_module>
 101c69b:	mov    %rbx,%rdi
 101c69e:	call   1013410 <myl_rc_module_register>
 101c6a3:	test   %eax,%eax
 101c6a5:	je     101c6be <myl_rc_storage_init+0xce>
 101c6a7:	mov    %rbx,%rdi
 101c6aa:	mov    %eax,%ebx
 101c6ac:	call   1012690 <myl_rc_heap_destroy>
 101c6b1:	mov    %ebx,%eax
 101c6b3:	add    $0x8,%rsp
 101c6b7:	pop    %rbx
 101c6b8:	pop    %r14
 101c6ba:	pop    %r15
 101c6bc:	pop    %rbp
 101c6bd:	ret
 101c6be:	xor    %eax,%eax
 101c6c0:	jmp    101c6b3 <myl_rc_storage_init+0xc3>
 101c6c2:	int3
 101c6c3:	int3
 101c6c4:	int3
 101c6c5:	int3
 101c6c6:	int3
 101c6c7:	int3
 101c6c8:	int3
 101c6c9:	int3
 101c6ca:	int3
 101c6cb:	int3
 101c6cc:	int3
 101c6cd:	int3
 101c6ce:	int3
 101c6cf:	int3

000000000101c6d0 <myl_rc_storage_bytes>:
 101c6d0:	push   %rbp
 101c6d1:	mov    %rsp,%rbp
 101c6d4:	mov    $0x1,%ecx
 101c6d9:	pop    %rbp
 101c6da:	jmp    101c6e0 <raw_bytes>
 101c6df:	int3

000000000101c6e0 <raw_bytes>:
 101c6e0:	push   %rbp
 101c6e1:	mov    %rsp,%rbp
 101c6e4:	push   %r15
 101c6e6:	push   %r14
 101c6e8:	push   %rbx
 101c6e9:	sub    $0x28,%rsp
 101c6ed:	test   %rdi,%rdi
 101c6f0:	je     101c89d <raw_bytes+0x1bd>
 101c6f6:	mov    %rdi,%rbx
 101c6f9:	mov    0x1608(%rdi),%rax
 101c700:	test   %rax,%rax
 101c703:	je     101c89d <raw_bytes+0x1bd>
 101c709:	test   %edx,%edx
 101c70b:	je     101c75b <raw_bytes+0x7b>
 101c70d:	movq   $0x0,-0x20(%rbp)
 101c715:	lea    -0x191d4(%rip),%rax        # 1003548 <raw_type>
 101c71c:	mov    %rax,-0x38(%rbp)
 101c720:	mov    %rsi,-0x30(%rbp)
 101c724:	mov    %edx,-0x28(%rbp)
 101c727:	movl   $0x0,-0x24(%rbp)
 101c72e:	lea    -0x38(%rbp),%rsi
 101c732:	lea    -0x20(%rbp),%rdx
 101c736:	mov    %rbx,%rdi
 101c739:	call   1012820 <myl_rc_new>
 101c73e:	test   %eax,%eax
 101c740:	je     101c74c <raw_bytes+0x6c>
 101c742:	mov    %rbx,%rdi
 101c745:	mov    %eax,%esi
 101c747:	call   1012560 <myl_rc_record_failure>
 101c74c:	mov    -0x20(%rbp),%rax
 101c750:	add    $0x28,%rsp
 101c754:	pop    %rbx
 101c755:	pop    %r14
 101c757:	pop    %r15
 101c759:	pop    %rbp
 101c75a:	ret
 101c75b:	cmp    $0x1fe0,%rsi
 101c762:	ja     101c70d <raw_bytes+0x2d>
 101c764:	lea    -0x77b(%rip),%rdi        # 101bff0 <allocate>
 101c76b:	cmp    %rdi,(%rax)
 101c76e:	jne    101c70d <raw_bytes+0x2d>
 101c770:	lea    0x2f(%rsi),%rax
 101c774:	shr    $0x4,%rax
 101c778:	lea    -0x1943f(%rip),%rdx        # 1003340 <class_of>
 101c77f:	movzbl (%rax,%rdx,1),%edx
 101c783:	mov    0x1610(%rbx,%rdx,8),%rax
 101c78b:	test   %rax,%rax
 101c78e:	je     101c79d <raw_bytes+0xbd>
 101c790:	mov    (%rax),%rdi
 101c793:	mov    %rdi,0x1610(%rbx,%rdx,8)
 101c79b:	jmp    101c7bd <raw_bytes+0xdd>
 101c79d:	mov    %rbx,%rdi
 101c7a0:	mov    %rsi,%r14
 101c7a3:	mov    %rdx,%rsi
 101c7a6:	mov    %ecx,%r15d
 101c7a9:	call   101cd90 <slab_refill>
 101c7ae:	mov    %r15d,%ecx
 101c7b1:	mov    %r14,%rsi
 101c7b4:	test   %rax,%rax
 101c7b7:	je     101c871 <raw_bytes+0x191>
 101c7bd:	test   %ecx,%ecx
 101c7bf:	je     101c834 <raw_bytes+0x154>
 101c7c1:	lea    0x20(%rax),%rdi
 101c7c5:	lea    0xf(%rsi),%rcx
 101c7c9:	shr    $0x4,%rcx
 101c7cd:	cmp    $0x8,%rcx
 101c7d1:	ja     101c885 <raw_bytes+0x1a5>
 101c7d7:	lea    -0x19632(%rip),%rdx        # 10031ac <myl_rc_map_sentinel+0x10c>
 101c7de:	movslq (%rdx,%rcx,4),%rcx
 101c7e2:	add    %rdx,%rcx
 101c7e5:	jmp    *%rcx
 101c7e7:	vxorps %xmm0,%xmm0,%xmm0
 101c7eb:	vmovaps %xmm0,0x90(%rax)
 101c7f3:	vxorps %xmm0,%xmm0,%xmm0
 101c7f7:	vmovaps %xmm0,0x80(%rax)
 101c7ff:	vxorps %xmm0,%xmm0,%xmm0
 101c803:	vmovaps %xmm0,0x70(%rax)
 101c808:	vxorps %xmm0,%xmm0,%xmm0
 101c80c:	vmovaps %xmm0,0x60(%rax)
 101c811:	vxorps %xmm0,%xmm0,%xmm0
 101c815:	vmovaps %xmm0,0x50(%rax)
 101c81a:	vxorps %xmm0,%xmm0,%xmm0
 101c81e:	vmovaps %xmm0,0x40(%rax)
 101c823:	vxorps %xmm0,%xmm0,%xmm0
 101c827:	vmovaps %xmm0,0x30(%rax)
 101c82c:	vxorps %xmm0,%xmm0,%xmm0
 101c830:	vmovaps %xmm0,(%rdi)
 101c834:	movq   $0x1,(%rax)
 101c83b:	movq   $0x0,0x8(%rax)
 101c843:	shl    $0x2,%rsi
 101c847:	mov    %rsi,0x10(%rax)
 101c84b:	lea    -0x1930a(%rip),%rcx        # 1003548 <raw_type>
 101c852:	mov    %rcx,0x18(%rax)
 101c856:	vmovdqu 0x40(%rbx),%xmm0
 101c85b:	vpcmpeqd %xmm1,%xmm1,%xmm1
 101c85f:	vpsubq %xmm1,%xmm0,%xmm0
 101c863:	vmovdqu %xmm0,0x40(%rbx)
 101c868:	add    $0x20,%rax
 101c86c:	jmp    101c750 <raw_bytes+0x70>
 101c871:	mov    %rbx,%rdi
 101c874:	mov    $0x1,%esi
 101c879:	call   1012560 <myl_rc_record_failure>
 101c87e:	xor    %eax,%eax
 101c880:	jmp    101c750 <raw_bytes+0x70>
 101c885:	mov    %rsi,%r14
 101c888:	xor    %esi,%esi
 101c88a:	mov    %r14,%rdx
 101c88d:	mov    %rax,%r15
 101c890:	call   101e4a0 <compiler_rt.fastMemset>
 101c895:	mov    %r15,%rax
 101c898:	mov    %r14,%rsi
 101c89b:	jmp    101c834 <raw_bytes+0x154>
 101c89d:	call   101246d <myl_rc_invariant_failed>
 101c8a2:	int3
 101c8a3:	int3
 101c8a4:	int3
 101c8a5:	int3
 101c8a6:	int3
 101c8a7:	int3
 101c8a8:	int3
 101c8a9:	int3
 101c8aa:	int3
 101c8ab:	int3
 101c8ac:	int3
 101c8ad:	int3
 101c8ae:	int3
 101c8af:	int3

000000000101c8b0 <myl_rc_storage_block>:
 101c8b0:	push   %rbp
 101c8b1:	mov    %rsp,%rbp
 101c8b4:	xor    %ecx,%ecx
 101c8b6:	pop    %rbp
 101c8b7:	jmp    101c6e0 <raw_bytes>
 101c8bc:	int3
 101c8bd:	int3
 101c8be:	int3
 101c8bf:	int3

000000000101c8c0 <myl_rc_storage_extend>:
 101c8c0:	push   %rbp
 101c8c1:	mov    %rsp,%rbp
 101c8c4:	mov    $0x1,%ecx
 101c8c9:	pop    %rbp
 101c8ca:	jmp    101c8d0 <storage_extend>
 101c8cf:	int3

000000000101c8d0 <storage_extend>:
 101c8d0:	push   %rbp
 101c8d1:	mov    %rsp,%rbp
 101c8d4:	push   %r15
 101c8d6:	push   %r14
 101c8d8:	push   %r13
 101c8da:	push   %r12
 101c8dc:	push   %rbx
 101c8dd:	sub    $0x18,%rsp
 101c8e1:	test   %rsi,%rsi
 101c8e4:	je     101c9e3 <storage_extend+0x113>
 101c8ea:	mov    -0x10(%rsi),%rax
 101c8ee:	movabs $0xc000000000000003,%r8
 101c8f8:	and    %rax,%r8
 101c8fb:	neg    %r8
 101c8fe:	jno    101c9e3 <storage_extend+0x113>
 101c904:	cmpq   $0x1,-0x20(%rsi)
 101c909:	jne    101c9e3 <storage_extend+0x113>
 101c90f:	cmpq   $0x0,-0x18(%rsi)
 101c914:	jne    101c9e3 <storage_extend+0x113>
 101c91a:	movabs $0x1000000000000000,%r8
 101c924:	and    %r8,%rax
 101c927:	mov    %rdx,%r8
 101c92a:	shr    $0x3a,%r8
 101c92e:	or     %rax,%r8
 101c931:	jne    101c9e3 <storage_extend+0x113>
 101c937:	mov    -0x8(%rsi),%rax
 101c93b:	mov    (%rax),%rbx
 101c93e:	test   %rbx,%rbx
 101c941:	je     101c9e3 <storage_extend+0x113>
 101c947:	mov    $0xffffffffffffffaf,%rax
 101c94e:	mov    %rdx,%r13
 101c951:	xor    %edx,%edx
 101c953:	div    %rbx
 101c956:	mov    %rax,%rdx
 101c959:	xor    %eax,%eax
 101c95b:	cmp    %rdx,%r13
 101c95e:	ja     101c9e5 <storage_extend+0x115>
 101c964:	imul   %r13,%rbx
 101c968:	lea    0x20(%rbx),%r12
 101c96c:	cmp    -0x38(%rsi),%r12
 101c970:	jbe    101c9e3 <storage_extend+0x113>
 101c972:	mov    %ecx,-0x2c(%rbp)
 101c975:	add    $0x50,%rbx
 101c979:	mov    %rbx,%r14
 101c97c:	mov    %rsi,%r15
 101c97f:	sub    -0x40(%rsi),%r14
 101c983:	mov    %rdi,-0x38(%rbp)
 101c987:	mov    %r14,%rsi
 101c98a:	call   101ca90 <reserve>
 101c98f:	test   %eax,%eax
 101c991:	je     101c9e3 <storage_extend+0x113>
 101c993:	mov    %r15,%rdi
 101c996:	mov    -0x40(%r15),%r15
 101c99a:	add    $0xffffffffffffffb0,%rdi
 101c99e:	mov    %r15,%rsi
 101c9a1:	mov    %rbx,%rdx
 101c9a4:	call   101d4e0 <large_grow>
 101c9a9:	test   %rax,%rax
 101c9ac:	je     101c9e3 <storage_extend+0x113>
 101c9ae:	cmpl   $0x0,-0x2c(%rbp)
 101c9b2:	je     101c9d1 <storage_extend+0x101>
 101c9b4:	cmpq   $0x0,0x20(%rax)
 101c9b9:	jne    101c9d1 <storage_extend+0x101>
 101c9bb:	add    %rax,%r15
 101c9be:	mov    %r15,%rdi
 101c9c1:	xor    %esi,%esi
 101c9c3:	mov    %r14,%rdx
 101c9c6:	mov    %rax,%r15
 101c9c9:	call   101e4a0 <compiler_rt.fastMemset>
 101c9ce:	mov    %r15,%rax
 101c9d1:	mov    (%rax),%rcx
 101c9d4:	test   %rcx,%rcx
 101c9d7:	je     101c9f4 <storage_extend+0x124>
 101c9d9:	mov    %rax,0x8(%rcx)
 101c9dd:	mov    -0x38(%rbp),%rcx
 101c9e1:	jmp    101ca14 <storage_extend+0x144>
 101c9e3:	xor    %eax,%eax
 101c9e5:	add    $0x18,%rsp
 101c9e9:	pop    %rbx
 101c9ea:	pop    %r12
 101c9ec:	pop    %r13
 101c9ee:	pop    %r14
 101c9f0:	pop    %r15
 101c9f2:	pop    %rbp
 101c9f3:	ret
 101c9f4:	mov    -0x38(%rbp),%rcx
 101c9f8:	test   %rcx,%rcx
 101c9fb:	je     101ca73 <storage_extend+0x1a3>
 101c9fd:	mov    0x1608(%rcx),%rdx
 101ca04:	test   %rdx,%rdx
 101ca07:	je     101ca73 <storage_extend+0x1a3>
 101ca09:	mov    0x20(%rdx),%rdx
 101ca0d:	mov    %rax,0x200(%rdx)
 101ca14:	mov    0x8(%rax),%rdx
 101ca18:	test   %rdx,%rdx
 101ca1b:	je     101ca20 <storage_extend+0x150>
 101ca1d:	mov    %rax,(%rdx)
 101ca20:	mov    %rbx,0x10(%rax)
 101ca24:	mov    %r12,0x18(%rax)
 101ca28:	movabs $0xf000000000000003,%rdx
 101ca32:	and    0x40(%rax),%rdx
 101ca36:	lea    (%rdx,%r13,4),%rdx
 101ca3a:	mov    %rdx,0x40(%rax)
 101ca3e:	add    %r14,0x18(%rcx)
 101ca42:	mov    0x1608(%rcx),%rdx
 101ca49:	test   %rdx,%rdx
 101ca4c:	je     101ca73 <storage_extend+0x1a3>
 101ca4e:	mov    0x20(%rdx),%rdx
 101ca52:	add    %r14,0x208(%rdx)
 101ca59:	mov    0x50(%rcx),%rdx
 101ca5d:	cmp    $0xffffffffffffffff,%rdx
 101ca61:	je     101ca6a <storage_extend+0x19a>
 101ca63:	inc    %rdx
 101ca66:	mov    %rdx,0x50(%rcx)
 101ca6a:	add    $0x50,%rax
 101ca6e:	jmp    101c9e5 <storage_extend+0x115>
 101ca73:	call   101246d <myl_rc_invariant_failed>
 101ca78:	int3
 101ca79:	int3
 101ca7a:	int3
 101ca7b:	int3
 101ca7c:	int3
 101ca7d:	int3
 101ca7e:	int3
 101ca7f:	int3

000000000101ca80 <myl_rc_storage_extend_opaque>:
 101ca80:	push   %rbp
 101ca81:	mov    %rsp,%rbp
 101ca84:	xor    %ecx,%ecx
 101ca86:	pop    %rbp
 101ca87:	jmp    101c8d0 <storage_extend>
 101ca8c:	int3
 101ca8d:	int3
 101ca8e:	int3
 101ca8f:	int3

000000000101ca90 <reserve>:
 101ca90:	push   %rbp
 101ca91:	mov    %rsp,%rbp
 101ca94:	push   %r14
 101ca96:	push   %rbx
 101ca97:	mov    %rsi,%r14
 101ca9a:	mov    %rdi,%rbx
 101ca9d:	mov    0x18(%rdi),%rcx
 101caa1:	mov    %rcx,%rax
 101caa4:	add    %rsi,%rax
 101caa7:	jb     101caca <reserve+0x3a>
 101caa9:	mov    0x58(%rbx),%rdx
 101caad:	mov    $0x1,%eax
 101cab2:	test   %rdx,%rdx
 101cab5:	je     101cb08 <reserve+0x78>
 101cab7:	sub    %rcx,%rdx
 101caba:	setb   %cl
 101cabd:	cmp    %rdx,%r14
 101cac0:	seta   %dl
 101cac3:	or     %cl,%dl
 101cac5:	cmp    $0x1,%dl
 101cac8:	jne    101cb08 <reserve+0x78>
 101caca:	mov    %rbx,%rdi
 101cacd:	call   101cb90 <trim_empty>
 101cad2:	mov    0x18(%rbx),%rcx
 101cad6:	mov    %rcx,%rax
 101cad9:	add    %r14,%rax
 101cadc:	jb     101caff <reserve+0x6f>
 101cade:	mov    0x58(%rbx),%rdx
 101cae2:	mov    $0x1,%eax
 101cae7:	test   %rdx,%rdx
 101caea:	je     101cb08 <reserve+0x78>
 101caec:	sub    %rcx,%rdx
 101caef:	setb   %cl
 101caf2:	cmp    %rdx,%r14
 101caf5:	seta   %dl
 101caf8:	or     %cl,%dl
 101cafa:	cmp    $0x1,%dl
 101cafd:	jne    101cb08 <reserve+0x78>
 101caff:	movl   $0x1,0x6c(%rbx)
 101cb06:	xor    %eax,%eax
 101cb08:	pop    %rbx
 101cb09:	pop    %r14
 101cb0b:	pop    %rbp
 101cb0c:	ret
 101cb0d:	int3
 101cb0e:	int3
 101cb0f:	int3

000000000101cb10 <large_block>:
 101cb10:	push   %rbp
 101cb11:	mov    %rsp,%rbp
 101cb14:	push   %r14
 101cb16:	push   %rbx
 101cb17:	mov    %rdi,%rbx
 101cb1a:	cmp    $0x1ffff,%rdi
 101cb21:	ja     101cb34 <large_block+0x24>
 101cb23:	mov    $0x1,%edi
 101cb28:	mov    %rbx,%rsi
 101cb2b:	pop    %rbx
 101cb2c:	pop    %r14
 101cb2e:	pop    %rbp
 101cb2f:	jmp    101ed70 <calloc@plt>
 101cb34:	cmp    $0xffffffffffffefff,%rbx
 101cb3b:	jbe    101cb42 <large_block+0x32>
 101cb3d:	xor    %r14d,%r14d
 101cb40:	jmp    101cb7d <large_block+0x6d>
 101cb42:	add    $0xfff,%rbx
 101cb49:	and    $0xfffffffffffff000,%rbx
 101cb50:	xor    %r14d,%r14d
 101cb53:	xor    %edi,%edi
 101cb55:	mov    %rbx,%rsi
 101cb58:	mov    $0x3,%edx
 101cb5d:	mov    $0x22,%ecx
 101cb62:	mov    $0xffffffff,%r8d
 101cb68:	xor    %r9d,%r9d
 101cb6b:	call   101eee0 <mmap@plt>
 101cb70:	cmp    $0xffffffffffffffff,%rax
 101cb74:	je     101cb7d <large_block+0x6d>
 101cb76:	mov    %rbx,0x20(%rax)
 101cb7a:	mov    %rax,%r14
 101cb7d:	mov    %r14,%rax
 101cb80:	pop    %rbx
 101cb81:	pop    %r14
 101cb83:	pop    %rbp
 101cb84:	ret
 101cb85:	int3
 101cb86:	int3
 101cb87:	int3
 101cb88:	int3
 101cb89:	int3
 101cb8a:	int3
 101cb8b:	int3
 101cb8c:	int3
 101cb8d:	int3
 101cb8e:	int3
 101cb8f:	int3

000000000101cb90 <trim_empty>:
 101cb90:	push   %rbp
 101cb91:	mov    %rsp,%rbp
 101cb94:	push   %r15
 101cb96:	push   %r14
 101cb98:	push   %r12
 101cb9a:	push   %rbx
 101cb9b:	test   %rdi,%rdi
 101cb9e:	je     101cc7b <trim_empty+0xeb>
 101cba4:	mov    %rdi,%rbx
 101cba7:	xor    %r14d,%r14d
 101cbaa:	jmp    101cbbd <trim_empty+0x2d>
 101cbac:	nopl   0x0(%rax)
 101cbb0:	inc    %r14
 101cbb3:	cmp    $0x20,%r14
 101cbb7:	je     101cc67 <trim_empty+0xd7>
 101cbbd:	mov    0x1608(%rbx),%rax
 101cbc4:	test   %rax,%rax
 101cbc7:	je     101cc7b <trim_empty+0xeb>
 101cbcd:	mov    0x20(%rax),%r15
 101cbd1:	mov    0x1610(%rbx,%r14,8),%rax
 101cbd9:	movq   $0x0,0x1610(%rbx,%r14,8)
 101cbe5:	test   %rax,%rax
 101cbe8:	je     101cbb0 <trim_empty+0x20>
 101cbea:	mov    %r14,%rcx
 101cbed:	shl    $0x4,%rcx
 101cbf1:	add    %rcx,%r15
 101cbf4:	jmp    101cc08 <trim_empty+0x78>
 101cbf6:	cs nopw 0x0(%rax,%rax,1)
 101cc00:	mov    %r12,%rax
 101cc03:	test   %r12,%r12
 101cc06:	je     101cbb0 <trim_empty+0x20>
 101cc08:	mov    (%rax),%r12
 101cc0b:	mov    %rax,%rsi
 101cc0e:	and    $0xffffffffffff0000,%rsi
 101cc15:	mov    0x48(%rsi),%rcx
 101cc19:	test   %rcx,%rcx
 101cc1c:	jne    101cc50 <trim_empty+0xc0>
 101cc1e:	mov    0x30(%rsi),%rdx
 101cc22:	cmp    0x40(%rsi),%rdx
 101cc26:	jne    101cc50 <trim_empty+0xc0>
 101cc28:	mov    0x8(%r15),%rcx
 101cc2c:	movq   $0x0,0x20(%rsi)
 101cc34:	mov    %rcx,0x28(%rsi)
 101cc38:	mov    0x8(%r15),%rcx
 101cc3c:	test   %rcx,%rcx
 101cc3f:	je     101cc45 <trim_empty+0xb5>
 101cc41:	mov    %rsi,0x20(%rcx)
 101cc45:	mov    %rsi,0x8(%r15)
 101cc49:	mov    0x48(%rsi),%rcx
 101cc4d:	nopl   (%rax)
 101cc50:	mov    %rcx,(%rax)
 101cc53:	mov    %rax,0x48(%rsi)
 101cc57:	decq   0x38(%rsi)
 101cc5b:	jne    101cc00 <trim_empty+0x70>
 101cc5d:	mov    %rbx,%rdi
 101cc60:	call   101cc80 <slab_free>
 101cc65:	jmp    101cc00 <trim_empty+0x70>
 101cc67:	movq   $0x0,0x1710(%rbx)
 101cc72:	pop    %rbx
 101cc73:	pop    %r12
 101cc75:	pop    %r14
 101cc77:	pop    %r15
 101cc79:	pop    %rbp
 101cc7a:	ret
 101cc7b:	call   101246d <myl_rc_invariant_failed>

000000000101cc80 <slab_free>:
 101cc80:	push   %rbp
 101cc81:	mov    %rsp,%rbp
 101cc84:	push   %r14
 101cc86:	push   %rbx
 101cc87:	test   %rdi,%rdi
 101cc8a:	je     101cd80 <slab_free+0x100>
 101cc90:	mov    0x1608(%rdi),%rcx
 101cc97:	test   %rcx,%rcx
 101cc9a:	je     101cd80 <slab_free+0x100>
 101cca0:	mov    %rsi,%rbx
 101cca3:	mov    (%rsi),%rax
 101cca6:	shl    $0x4,%rax
 101ccaa:	add    0x20(%rcx),%rax
 101ccae:	cmpq   $0x0,0x48(%rsi)
 101ccb3:	jne    101ccbf <slab_free+0x3f>
 101ccb5:	mov    0x30(%rbx),%rcx
 101ccb9:	cmp    0x40(%rbx),%rcx
 101ccbd:	je     101cceb <slab_free+0x6b>
 101ccbf:	mov    0x20(%rbx),%rcx
 101ccc3:	mov    0x28(%rbx),%rdx
 101ccc7:	test   %rcx,%rcx
 101ccca:	je     101ccd2 <slab_free+0x52>
 101cccc:	mov    %rdx,0x28(%rcx)
 101ccd0:	jmp    101ccd6 <slab_free+0x56>
 101ccd2:	mov    %rdx,0x8(%rax)
 101ccd6:	lea    0x20(%rbx),%rsi
 101ccda:	test   %rdx,%rdx
 101ccdd:	je     101cce3 <slab_free+0x63>
 101ccdf:	mov    %rcx,0x20(%rdx)
 101cce3:	vxorps %xmm0,%xmm0,%xmm0
 101cce7:	vmovups %xmm0,(%rsi)
 101cceb:	mov    0x10(%rbx),%rdx
 101ccef:	mov    0x18(%rbx),%rcx
 101ccf3:	test   %rdx,%rdx
 101ccf6:	je     101cd76 <slab_free+0xf6>
 101ccf8:	mov    %rcx,0x18(%rdx)
 101ccfc:	test   %rcx,%rcx
 101ccff:	je     101cd09 <slab_free+0x89>
 101cd01:	mov    0x10(%rbx),%rax
 101cd05:	mov    %rax,0x10(%rcx)
 101cd09:	addq   $0xffffffffffff0000,0x18(%rdi)
 101cd11:	mov    0x1608(%rdi),%rax
 101cd18:	test   %rax,%rax
 101cd1b:	je     101cd80 <slab_free+0x100>
 101cd1d:	mov    0x20(%rax),%r14
 101cd21:	addq   $0xffffffffffff0000,0x208(%r14)
 101cd2c:	mov    0x450(%r14),%rax
 101cd33:	cmp    $0x10,%rax
 101cd37:	jb     101cd56 <slab_free+0xd6>
 101cd39:	lea    0x1000(%rbx),%rdi
 101cd40:	mov    $0xf000,%esi
 101cd45:	mov    $0x4,%edx
 101cd4a:	call   101f150 <madvise@plt>
 101cd4f:	mov    0x450(%r14),%rax
 101cd56:	mov    0x448(%r14),%rcx
 101cd5d:	mov    %rcx,(%rbx)
 101cd60:	mov    %rbx,0x448(%r14)
 101cd67:	inc    %rax
 101cd6a:	mov    %rax,0x450(%r14)
 101cd71:	pop    %rbx
 101cd72:	pop    %r14
 101cd74:	pop    %rbp
 101cd75:	ret
 101cd76:	mov    %rcx,(%rax)
 101cd79:	test   %rcx,%rcx
 101cd7c:	jne    101cd01 <slab_free+0x81>
 101cd7e:	jmp    101cd09 <slab_free+0x89>
 101cd80:	call   101246d <myl_rc_invariant_failed>
 101cd85:	int3
 101cd86:	int3
 101cd87:	int3
 101cd88:	int3
 101cd89:	int3
 101cd8a:	int3
 101cd8b:	int3
 101cd8c:	int3
 101cd8d:	int3
 101cd8e:	int3
 101cd8f:	int3

000000000101cd90 <slab_refill>:
 101cd90:	push   %rbp
 101cd91:	mov    %rsp,%rbp
 101cd94:	push   %r15
 101cd96:	push   %r14
 101cd98:	push   %r13
 101cd9a:	push   %r12
 101cd9c:	push   %rbx
 101cd9d:	sub    $0x38,%rsp
 101cda1:	test   %rdi,%rdi
 101cda4:	je     101d121 <slab_refill+0x391>
 101cdaa:	mov    %rdi,%rbx
 101cdad:	mov    0x1608(%rdi),%rax
 101cdb4:	test   %rax,%rax
 101cdb7:	je     101d121 <slab_refill+0x391>
 101cdbd:	mov    %rsi,%r12
 101cdc0:	mov    0x20(%rax),%r14
 101cdc4:	mov    %rsi,%r15
 101cdc7:	shl    $0x4,%r15
 101cdcb:	mov    0x8(%r14,%r15,1),%rcx
 101cdd0:	test   %rcx,%rcx
 101cdd3:	jne    101cf3b <slab_refill+0x1ab>
 101cdd9:	cmpq   $0x0,0x448(%r14)
 101cde1:	jne    101ce0a <slab_refill+0x7a>
 101cde3:	mov    0x1710(%rbx),%rax
 101cdea:	cmp    $0x100000,%rax
 101cdf0:	jb     101ce0a <slab_refill+0x7a>
 101cdf2:	mov    0x208(%r14),%rcx
 101cdf9:	shr    $0x2,%rcx
 101cdfd:	cmp    %rcx,%rax
 101ce00:	jb     101ce0a <slab_refill+0x7a>
 101ce02:	mov    %rbx,%rdi
 101ce05:	call   101cb90 <trim_empty>
 101ce0a:	mov    0x18(%rbx),%rax
 101ce0e:	cmp    $0xfffffffffffeffff,%rax
 101ce14:	ja     101ce36 <slab_refill+0xa6>
 101ce16:	mov    0x58(%rbx),%rcx
 101ce1a:	test   %rcx,%rcx
 101ce1d:	je     101ce78 <slab_refill+0xe8>
 101ce1f:	sub    %rax,%rcx
 101ce22:	setb   %al
 101ce25:	cmp    $0x10000,%rcx
 101ce2c:	setb   %cl
 101ce2f:	or     %al,%cl
 101ce31:	cmp    $0x1,%cl
 101ce34:	jne    101ce78 <slab_refill+0xe8>
 101ce36:	mov    %rbx,%rdi
 101ce39:	call   101cb90 <trim_empty>
 101ce3e:	mov    0x18(%rbx),%rax
 101ce42:	cmp    $0xfffffffffffeffff,%rax
 101ce48:	ja     101ce6a <slab_refill+0xda>
 101ce4a:	mov    0x58(%rbx),%rcx
 101ce4e:	test   %rcx,%rcx
 101ce51:	je     101ce78 <slab_refill+0xe8>
 101ce53:	sub    %rax,%rcx
 101ce56:	setb   %al
 101ce59:	cmp    $0x10000,%rcx
 101ce60:	setb   %cl
 101ce63:	or     %al,%cl
 101ce65:	cmp    $0x1,%cl
 101ce68:	jne    101ce78 <slab_refill+0xe8>
 101ce6a:	movl   $0x1,0x6c(%rbx)
 101ce71:	xor    %eax,%eax
 101ce73:	jmp    101d10b <slab_refill+0x37b>
 101ce78:	mov    %rbx,%rdi
 101ce7b:	call   101d130 <range_take>
 101ce80:	test   %rax,%rax
 101ce83:	jne    101ce9e <slab_refill+0x10e>
 101ce85:	mov    %rbx,%rdi
 101ce88:	call   101cb90 <trim_empty>
 101ce8d:	mov    %rbx,%rdi
 101ce90:	call   101d130 <range_take>
 101ce95:	test   %rax,%rax
 101ce98:	je     101d11d <slab_refill+0x38d>
 101ce9e:	mov    %rax,%rcx
 101cea1:	vxorps %xmm0,%xmm0,%xmm0
 101cea5:	vmovups %ymm0,0x30(%rax)
 101ceaa:	vmovups %ymm0,0x10(%rax)
 101ceaf:	lea    -0x19c76(%rip),%rax        # 1003240 <strides>
 101ceb6:	mov    (%rax,%r12,8),%rdi
 101ceba:	mov    %rdi,0x8(%rcx)
 101cebe:	mov    %r12,(%rcx)
 101cec1:	cmp    $0xffb0,%rdi
 101cec8:	ja     101ced5 <slab_refill+0x145>
 101ceca:	mov    $0xffb0,%eax
 101cecf:	xor    %edx,%edx
 101ced1:	div    %edi
 101ced3:	jmp    101ced7 <slab_refill+0x147>
 101ced5:	xor    %eax,%eax
 101ced7:	mov    %rax,0x40(%rcx)
 101cedb:	mov    0x1608(%rbx),%rax
 101cee2:	test   %rax,%rax
 101cee5:	je     101d121 <slab_refill+0x391>
 101ceeb:	mov    0x20(%rax),%rax
 101ceef:	lea    (%rax,%r15,1),%rdx
 101cef3:	mov    (%rax,%r15,1),%rdi
 101cef7:	mov    %rdi,0x18(%rcx)
 101cefb:	test   %rdi,%rdi
 101cefe:	je     101cf04 <slab_refill+0x174>
 101cf00:	mov    %rcx,0x10(%rdi)
 101cf04:	mov    %rcx,(%rdx)
 101cf07:	mov    0x8(%rdx),%rdi
 101cf0b:	movq   $0x0,0x20(%rcx)
 101cf13:	mov    %rdi,0x28(%rcx)
 101cf17:	mov    0x8(%rdx),%rdi
 101cf1b:	test   %rdi,%rdi
 101cf1e:	je     101cf24 <slab_refill+0x194>
 101cf20:	mov    %rcx,0x20(%rdi)
 101cf24:	mov    %rcx,0x8(%rdx)
 101cf28:	addq   $0x10000,0x18(%rbx)
 101cf30:	addq   $0x10000,0x208(%rax)
 101cf3b:	mov    0x48(%rcx),%rax
 101cf3f:	test   %rax,%rax
 101cf42:	je     101cf66 <slab_refill+0x1d6>
 101cf44:	movq   $0x0,0x48(%rcx)
 101cf4c:	mov    0x30(%rcx),%rdi
 101cf50:	mov    0x40(%rcx),%r9
 101cf54:	mov    %rdi,0x38(%rcx)
 101cf58:	cmp    %r9,%rdi
 101cf5b:	je     101d0d1 <slab_refill+0x341>
 101cf61:	jmp    101d100 <slab_refill+0x370>
 101cf66:	mov    0x8(%rcx),%r13
 101cf6a:	mov    0x30(%rcx),%rdi
 101cf6e:	mov    0x40(%rcx),%r9
 101cf72:	mov    %r9,%r8
 101cf75:	sub    %rdi,%r8
 101cf78:	cmp    $0x1000,%r13
 101cf7f:	ja     101cf8d <slab_refill+0x1fd>
 101cf81:	mov    $0x1000,%eax
 101cf86:	xor    %edx,%edx
 101cf88:	div    %r13d
 101cf8b:	jmp    101cf8f <slab_refill+0x1ff>
 101cf8d:	xor    %eax,%eax
 101cf8f:	cmp    $0x1001,%r13
 101cf96:	mov    $0x1,%edx
 101cf9b:	cmovb  %rax,%rdx
 101cf9f:	cmp    %r8,%rdx
 101cfa2:	cmovae %r8,%rdx
 101cfa6:	mov    %rdi,%r8
 101cfa9:	imul   %r13,%r8
 101cfad:	lea    (%rcx,%r8,1),%rax
 101cfb1:	add    $0x50,%rax
 101cfb5:	test   %rdx,%rdx
 101cfb8:	je     101d0c1 <slab_refill+0x331>
 101cfbe:	cmp    $0x1,%rdx
 101cfc2:	jne    101cfcc <slab_refill+0x23c>
 101cfc4:	xor    %r10d,%r10d
 101cfc7:	jmp    101d099 <slab_refill+0x309>
 101cfcc:	mov    %r9,-0x38(%rbp)
 101cfd0:	mov    %r12,-0x40(%rbp)
 101cfd4:	mov    %r15,-0x48(%rbp)
 101cfd8:	mov    %r14,-0x50(%rbp)
 101cfdc:	mov    %rbx,-0x58(%rbp)
 101cfe0:	lea    0x1(%rdi),%r10
 101cfe4:	imul   %r13,%r10
 101cfe8:	lea    (%rcx,%r10,1),%r11
 101cfec:	add    $0x50,%r11
 101cff0:	lea    0x0(,%r13,2),%r12
 101cff8:	lea    0x2(%rdi),%r10
 101cffc:	mov    %r13,-0x30(%rbp)
 101d000:	imul   %r13,%r10
 101d004:	lea    (%rcx,%r10,1),%r13
 101d008:	add    $0x50,%r13
 101d00c:	lea    (%r8,%rcx,1),%r14
 101d010:	add    $0x60,%r14
 101d014:	mov    %rdx,%r8
 101d017:	and    $0xfffffffffffffffe,%r8
 101d01b:	neg    %r8
 101d01e:	mov    $0x1,%r10d
 101d024:	xor    %r15d,%r15d
 101d027:	xor    %ebx,%ebx
 101d029:	nopl   0x0(%rax)
 101d030:	lea    (%r11,%rbx,1),%r9
 101d034:	cmp    %rdx,%r10
 101d037:	cmovae %r15,%r9
 101d03b:	mov    %r9,-0x10(%r14,%rbx,1)
 101d040:	movq   $0x3,(%r14,%rbx,1)
 101d048:	lea    0x1(%r10),%r9
 101d04c:	lea    (%rbx,%r13,1),%rsi
 101d050:	cmp    %rdx,%r9
 101d053:	cmovae %r15,%rsi
 101d057:	mov    %rsi,(%r11,%rbx,1)
 101d05b:	movq   $0x3,0x10(%r11,%rbx,1)
 101d064:	add    %r12,%rbx
 101d067:	lea    (%r8,%r10,1),%rsi
 101d06b:	add    $0x2,%rsi
 101d06f:	add    $0x2,%r10
 101d073:	cmp    $0x1,%rsi
 101d077:	jne    101d030 <slab_refill+0x2a0>
 101d079:	test   $0x1,%dl
 101d07c:	mov    -0x58(%rbp),%rbx
 101d080:	mov    -0x50(%rbp),%r14
 101d084:	mov    -0x48(%rbp),%r15
 101d088:	mov    -0x40(%rbp),%r12
 101d08c:	mov    -0x38(%rbp),%r9
 101d090:	mov    -0x30(%rbp),%r13
 101d094:	je     101d0c1 <slab_refill+0x331>
 101d096:	dec    %r10
 101d099:	mov    %r10,%rsi
 101d09c:	imul   %r13,%rsi
 101d0a0:	inc    %r10
 101d0a3:	imul   %r10,%r13
 101d0a7:	add    %rax,%r13
 101d0aa:	xor    %r8d,%r8d
 101d0ad:	cmp    %rdx,%r10
 101d0b0:	cmovb  %r13,%r8
 101d0b4:	mov    %r8,(%rax,%rsi,1)
 101d0b8:	movq   $0x3,0x10(%rax,%rsi,1)
 101d0c1:	add    %rdx,%rdi
 101d0c4:	mov    %rdi,0x30(%rcx)
 101d0c8:	add    %rdx,0x38(%rcx)
 101d0cc:	cmp    %r9,%rdi
 101d0cf:	jne    101d100 <slab_refill+0x370>
 101d0d1:	mov    0x20(%rcx),%rdx
 101d0d5:	mov    0x28(%rcx),%rdi
 101d0d9:	test   %rdx,%rdx
 101d0dc:	je     101d0e4 <slab_refill+0x354>
 101d0de:	mov    %rdi,0x28(%rdx)
 101d0e2:	jmp    101d0eb <slab_refill+0x35b>
 101d0e4:	add    %r15,%r14
 101d0e7:	mov    %rdi,0x8(%r14)
 101d0eb:	add    $0x20,%rcx
 101d0ef:	test   %rdi,%rdi
 101d0f2:	je     101d0f8 <slab_refill+0x368>
 101d0f4:	mov    %rdx,0x20(%rdi)
 101d0f8:	vxorps %xmm0,%xmm0,%xmm0
 101d0fc:	vmovups %xmm0,(%rcx)
 101d100:	mov    (%rax),%rcx
 101d103:	mov    %rcx,0x1610(%rbx,%r12,8)
 101d10b:	add    $0x38,%rsp
 101d10f:	pop    %rbx
 101d110:	pop    %r12
 101d112:	pop    %r13
 101d114:	pop    %r14
 101d116:	pop    %r15
 101d118:	pop    %rbp
 101d119:	vzeroupper
 101d11c:	ret
 101d11d:	xor    %eax,%eax
 101d11f:	jmp    101d10b <slab_refill+0x37b>
 101d121:	vzeroupper
 101d124:	call   101246d <myl_rc_invariant_failed>
 101d129:	int3
 101d12a:	int3
 101d12b:	int3
 101d12c:	int3
 101d12d:	int3
 101d12e:	int3
 101d12f:	int3

000000000101d130 <range_take>:
 101d130:	push   %rbp
 101d131:	mov    %rsp,%rbp
 101d134:	push   %r15
 101d136:	push   %r14
 101d138:	push   %rbx
 101d139:	push   %rax
 101d13a:	test   %rdi,%rdi
 101d13d:	je     101d320 <range_take+0x1f0>
 101d143:	mov    0x1608(%rdi),%rax
 101d14a:	test   %rax,%rax
 101d14d:	je     101d320 <range_take+0x1f0>
 101d153:	mov    0x20(%rax),%r15
 101d157:	mov    0x448(%r15),%rax
 101d15e:	test   %rax,%rax
 101d161:	je     101d179 <range_take+0x49>
 101d163:	mov    (%rax),%rcx
 101d166:	mov    %rcx,0x448(%r15)
 101d16d:	decq   0x450(%r15)
 101d174:	jmp    101d311 <range_take+0x1e1>
 101d179:	mov    0x220(%r15),%rax
 101d180:	cmp    0x228(%r15),%rax
 101d187:	jne    101d303 <range_take+0x1d3>
 101d18d:	mov    0x438(%r15),%rcx
 101d194:	cmp    $0x40,%rcx
 101d198:	jb     101d251 <range_take+0x121>
 101d19e:	add    $0xffffffffffffffc0,%rcx
 101d1a2:	cmp    0x440(%r15),%rcx
 101d1a9:	jne    101d251 <range_take+0x121>
 101d1af:	lea    (%rcx,%rcx,1),%rax
 101d1b3:	test   %rcx,%rcx
 101d1b6:	mov    $0x40,%ebx
 101d1bb:	cmovne %rax,%rbx
 101d1bf:	mov    %rbx,%rax
 101d1c2:	sub    %rcx,%rax
 101d1c5:	shl    $0x3,%rax
 101d1c9:	mov    0x18(%rdi),%rcx
 101d1cd:	mov    %rcx,%rdx
 101d1d0:	add    %rax,%rdx
 101d1d3:	jae    101d1e3 <range_take+0xb3>
 101d1d5:	movl   $0x1,0x6c(%rdi)
 101d1dc:	xor    %eax,%eax
 101d1de:	jmp    101d311 <range_take+0x1e1>
 101d1e3:	mov    0x58(%rdi),%rdx
 101d1e7:	test   %rdx,%rdx
 101d1ea:	je     101d1f6 <range_take+0xc6>
 101d1ec:	sub    %rcx,%rdx
 101d1ef:	jb     101d1d5 <range_take+0xa5>
 101d1f1:	cmp    %rdx,%rax
 101d1f4:	ja     101d1d5 <range_take+0xa5>
 101d1f6:	mov    %rdi,%r14
 101d1f9:	lea    0x0(,%rbx,8),%rsi
 101d201:	mov    0x430(%r15),%rdi
 101d208:	call   101ef70 <realloc@plt>
 101d20d:	test   %rax,%rax
 101d210:	je     101d31c <range_take+0x1ec>
 101d216:	mov    %rbx,%rcx
 101d219:	sub    0x440(%r15),%rcx
 101d220:	shl    $0x3,%rcx
 101d224:	add    %rcx,0x18(%r14)
 101d228:	mov    0x1608(%r14),%rdx
 101d22f:	test   %rdx,%rdx
 101d232:	je     101d320 <range_take+0x1f0>
 101d238:	mov    0x20(%rdx),%rdx
 101d23c:	add    %rcx,0x208(%rdx)
 101d243:	mov    %rax,0x430(%r15)
 101d24a:	mov    %rbx,0x440(%r15)
 101d251:	mov    $0x210000,%esi
 101d256:	xor    %edi,%edi
 101d258:	mov    $0x3,%edx
 101d25d:	mov    $0x22,%ecx
 101d262:	mov    $0xffffffff,%r8d
 101d268:	xor    %r9d,%r9d
 101d26b:	call   101eee0 <mmap@plt>
 101d270:	mov    %rax,%rbx
 101d273:	xor    %eax,%eax
 101d275:	cmp    $0xffffffffffffffff,%rbx
 101d279:	je     101d311 <range_take+0x1e1>
 101d27f:	lea    0xffff(%rbx),%rax
 101d286:	and    $0xffffffffffff0000,%rax
 101d28c:	cmp    %rax,%rbx
 101d28f:	je     101d2a5 <range_take+0x175>
 101d291:	mov    %rax,%rsi
 101d294:	sub    %rbx,%rsi
 101d297:	mov    %rbx,%rdi
 101d29a:	mov    %rax,%r14
 101d29d:	call   101ef30 <munmap@plt>
 101d2a2:	mov    %r14,%rax
 101d2a5:	lea    0x200000(%rax),%r14
 101d2ac:	add    $0x210000,%rbx
 101d2b3:	cmp    %rbx,%r14
 101d2b6:	je     101d2cc <range_take+0x19c>
 101d2b8:	sub    %r14,%rbx
 101d2bb:	mov    %r14,%rdi
 101d2be:	mov    %rbx,%rsi
 101d2c1:	mov    %rax,%rbx
 101d2c4:	call   101ef30 <munmap@plt>
 101d2c9:	mov    %rbx,%rax
 101d2cc:	mov    0x438(%r15),%rcx
 101d2d3:	cmp    $0x3f,%rcx
 101d2d7:	ja     101d2e3 <range_take+0x1b3>
 101d2d9:	mov    %rax,0x230(%r15,%rcx,8)
 101d2e1:	jmp    101d2f2 <range_take+0x1c2>
 101d2e3:	mov    0x430(%r15),%rdx
 101d2ea:	mov    %rax,-0x200(%rdx,%rcx,8)
 101d2f2:	inc    %rcx
 101d2f5:	mov    %rcx,0x438(%r15)
 101d2fc:	mov    %r14,0x228(%r15)
 101d303:	lea    0x10000(%rax),%rcx
 101d30a:	mov    %rcx,0x220(%r15)
 101d311:	add    $0x8,%rsp
 101d315:	pop    %rbx
 101d316:	pop    %r14
 101d318:	pop    %r15
 101d31a:	pop    %rbp
 101d31b:	ret
 101d31c:	xor    %eax,%eax
 101d31e:	jmp    101d311 <range_take+0x1e1>
 101d320:	call   101246d <myl_rc_invariant_failed>
 101d325:	int3
 101d326:	int3
 101d327:	int3
 101d328:	int3
 101d329:	int3
 101d32a:	int3
 101d32b:	int3
 101d32c:	int3
 101d32d:	int3
 101d32e:	int3
 101d32f:	int3

000000000101d330 <destroy>:
 101d330:	push   %rbp
 101d331:	mov    %rsp,%rbp
 101d334:	push   %r15
 101d336:	push   %r14
 101d338:	push   %r13
 101d33a:	push   %r12
 101d33c:	push   %rbx
 101d33d:	push   %rax
 101d33e:	test   %rdi,%rdi
 101d341:	je     101d4be <destroy+0x18e>
 101d347:	mov    %rdi,%rbx
 101d34a:	mov    0x1608(%rdi),%rax
 101d351:	test   %rax,%rax
 101d354:	je     101d4be <destroy+0x18e>
 101d35a:	mov    0x20(%rax),%r14
 101d35e:	xor    %eax,%eax
 101d360:	jmp    101d385 <destroy+0x55>
 101d362:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101d370:	movq   $0x0,0x1610(%rbx,%rax,8)
 101d37c:	inc    %rax
 101d37f:	cmp    $0x20,%rax
 101d383:	je     101d3b8 <destroy+0x88>
 101d385:	mov    0x1610(%rbx,%rax,8),%rcx
 101d38d:	test   %rcx,%rcx
 101d390:	je     101d370 <destroy+0x40>
 101d392:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101d3a0:	mov    %rcx,%rdx
 101d3a3:	and    $0xffffffffffff0000,%rdx
 101d3aa:	decq   0x38(%rdx)
 101d3ae:	mov    (%rcx),%rcx
 101d3b1:	test   %rcx,%rcx
 101d3b4:	jne    101d3a0 <destroy+0x70>
 101d3b6:	jmp    101d370 <destroy+0x40>
 101d3b8:	movq   $0x0,0x1710(%rbx)
 101d3c3:	xor    %r15d,%r15d
 101d3c6:	jmp    101d3d9 <destroy+0xa9>
 101d3c8:	nopl   0x0(%rax,%rax,1)
 101d3d0:	inc    %r15
 101d3d3:	cmp    $0x20,%r15
 101d3d7:	je     101d403 <destroy+0xd3>
 101d3d9:	mov    %r15,%r12
 101d3dc:	shl    $0x4,%r12
 101d3e0:	mov    (%r14,%r12,1),%rsi
 101d3e4:	test   %rsi,%rsi
 101d3e7:	je     101d3d0 <destroy+0xa0>
 101d3e9:	add    %r14,%r12
 101d3ec:	nopl   0x0(%rax)
 101d3f0:	mov    %rbx,%rdi
 101d3f3:	call   101cc80 <slab_free>
 101d3f8:	mov    (%r12),%rsi
 101d3fc:	test   %rsi,%rsi
 101d3ff:	jne    101d3f0 <destroy+0xc0>
 101d401:	jmp    101d3d0 <destroy+0xa0>
 101d403:	cmpq   $0x0,0x438(%r14)
 101d40b:	je     101d453 <destroy+0x123>
 101d40d:	lea    0x230(%r14),%r15
 101d414:	mov    $0xfffffffffffffe00,%r12
 101d41b:	xor    %r13d,%r13d
 101d41e:	jmp    101d447 <destroy+0x117>
 101d420:	mov    0x430(%r14),%rax
 101d427:	add    %r12,%rax
 101d42a:	mov    (%rax),%rdi
 101d42d:	mov    $0x200000,%esi
 101d432:	call   101ef30 <munmap@plt>
 101d437:	inc    %r13
 101d43a:	add    $0x8,%r12
 101d43e:	cmp    0x438(%r14),%r13
 101d445:	jae    101d453 <destroy+0x123>
 101d447:	cmp    $0x3f,%r13
 101d44b:	ja     101d420 <destroy+0xf0>
 101d44d:	lea    (%r15,%r13,8),%rax
 101d451:	jmp    101d42a <destroy+0xfa>
 101d453:	mov    0x440(%r14),%rax
 101d45a:	shl    $0x3,%rax
 101d45e:	sub    %rax,0x18(%rbx)
 101d462:	mov    0x1608(%rbx),%rcx
 101d469:	test   %rcx,%rcx
 101d46c:	je     101d4be <destroy+0x18e>
 101d46e:	mov    0x20(%rcx),%rcx
 101d472:	sub    %rax,0x208(%rcx)
 101d479:	mov    0x430(%r14),%rdi
 101d480:	call   101edc0 <free@plt>
 101d485:	addq   $0xfffffffffffffba8,0x18(%rbx)
 101d48d:	mov    0x1608(%rbx),%rax
 101d494:	test   %rax,%rax
 101d497:	je     101d4be <destroy+0x18e>
 101d499:	mov    0x20(%rax),%rax
 101d49d:	addq   $0xfffffffffffffba8,0x208(%rax)
 101d4a8:	mov    %r14,%rdi
 101d4ab:	add    $0x8,%rsp
 101d4af:	pop    %rbx
 101d4b0:	pop    %r12
 101d4b2:	pop    %r13
 101d4b4:	pop    %r14
 101d4b6:	pop    %r15
 101d4b8:	pop    %rbp
 101d4b9:	jmp    101edc0 <free@plt>
 101d4be:	call   101246d <myl_rc_invariant_failed>
 101d4c3:	int3
 101d4c4:	int3
 101d4c5:	int3
 101d4c6:	int3
 101d4c7:	int3
 101d4c8:	int3
 101d4c9:	int3
 101d4ca:	int3
 101d4cb:	int3
 101d4cc:	int3
 101d4cd:	int3
 101d4ce:	int3
 101d4cf:	int3

000000000101d4d0 <teardown>:
 101d4d0:	push   %rbp
 101d4d1:	mov    %rsp,%rbp
 101d4d4:	pop    %rbp
 101d4d5:	jmp    101c450 <release_extents>
 101d4da:	int3
 101d4db:	int3
 101d4dc:	int3
 101d4dd:	int3
 101d4de:	int3
 101d4df:	int3

000000000101d4e0 <large_grow>:
 101d4e0:	push   %rbp
 101d4e1:	mov    %rsp,%rbp
 101d4e4:	push   %r15
 101d4e6:	push   %r14
 101d4e8:	push   %rbx
 101d4e9:	push   %rax
 101d4ea:	mov    %rsi,%rbx
 101d4ed:	mov    0x20(%rdi),%rsi
 101d4f1:	test   %rsi,%rsi
 101d4f4:	setne  %cl
 101d4f7:	cmp    $0x20000,%rdx
 101d4fe:	setae  %r8b
 101d502:	or     %cl,%r8b
 101d505:	jne    101d519 <large_grow+0x39>
 101d507:	mov    %rdx,%rsi
 101d50a:	add    $0x8,%rsp
 101d50e:	pop    %rbx
 101d50f:	pop    %r14
 101d511:	pop    %r15
 101d513:	pop    %rbp
 101d514:	jmp    101ef70 <realloc@plt>
 101d519:	test   %rsi,%rsi
 101d51c:	je     101d558 <large_grow+0x78>
 101d51e:	cmp    $0xffffffffffffefff,%rdx
 101d525:	ja     101d58e <large_grow+0xae>
 101d527:	add    $0xfff,%rdx
 101d52e:	and    $0xfffffffffffff000,%rdx
 101d535:	cmp    %rsi,%rdx
 101d538:	jbe    101d590 <large_grow+0xb0>
 101d53a:	mov    %rdx,%rbx
 101d53d:	mov    $0x1,%ecx
 101d542:	xor    %eax,%eax
 101d544:	call   101f160 <mremap@plt>
 101d549:	cmp    $0xffffffffffffffff,%rax
 101d54d:	je     101d58e <large_grow+0xae>
 101d54f:	mov    %rax,%rdi
 101d552:	mov    %rbx,0x20(%rax)
 101d556:	jmp    101d590 <large_grow+0xb0>
 101d558:	mov    %rdi,%r14
 101d55b:	mov    %rdx,%rdi
 101d55e:	call   101cb10 <large_block>
 101d563:	test   %rax,%rax
 101d566:	je     101d58e <large_grow+0xae>
 101d568:	mov    0x20(%rax),%r15
 101d56c:	mov    %rax,%rdi
 101d56f:	mov    %r14,%rsi
 101d572:	mov    %rbx,%rdx
 101d575:	mov    %rax,%rbx
 101d578:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101d57d:	mov    %r15,0x20(%rbx)
 101d581:	mov    %r14,%rdi
 101d584:	call   101edc0 <free@plt>
 101d589:	mov    %rbx,%rdi
 101d58c:	jmp    101d590 <large_grow+0xb0>
 101d58e:	xor    %edi,%edi
 101d590:	mov    %rdi,%rax
 101d593:	add    $0x8,%rsp
 101d597:	pop    %rbx
 101d598:	pop    %r14
 101d59a:	pop    %r15
 101d59c:	pop    %rbp
 101d59d:	ret
 101d59e:	int3
 101d59f:	int3

000000000101d5a0 <myl_rc_native_shape>:
 101d5a0:	push   %rbp
 101d5a1:	mov    %rsp,%rbp
 101d5a4:	push   %r14
 101d5a6:	push   %rbx
 101d5a7:	sub    $0x70,%rsp
 101d5ab:	mov    %rsi,%rbx
 101d5ae:	mov    0x1608(%rdi),%rcx
 101d5b5:	mov    0x34(%rsi),%eax
 101d5b8:	cmp    %rax,0xa0(%rcx)
 101d5bf:	jbe    101d5e4 <myl_rc_native_shape+0x44>
 101d5c1:	mov    0x98(%rcx),%rcx
 101d5c8:	shl    $0x4,%rax
 101d5cc:	cmp    %rbx,(%rcx,%rax,1)
 101d5d0:	jne    101d5e4 <myl_rc_native_shape+0x44>
 101d5d2:	add    %rax,%rcx
 101d5d5:	mov    0x8(%rcx),%rax
 101d5d9:	test   %rax,%rax
 101d5dc:	je     101d5f1 <myl_rc_native_shape+0x51>
 101d5de:	mov    0x8(%rax),%rax
 101d5e2:	jmp    101d653 <myl_rc_native_shape+0xb3>
 101d5e4:	mov    %rbx,%rsi
 101d5e7:	call   1012eea <myl_rc_binding_find_slow>
 101d5ec:	test   %rax,%rax
 101d5ef:	jne    101d5de <myl_rc_native_shape+0x3e>
 101d5f1:	mov    (%rbx),%rax
 101d5f4:	mov    %rax,-0x38(%rbp)
 101d5f8:	vxorps %xmm0,%xmm0,%xmm0
 101d5fc:	vmovups %ymm0,-0x30(%rbp)
 101d601:	movzwl 0x30(%rbx),%eax
 101d605:	test   %eax,%eax
 101d607:	je     101d61e <myl_rc_native_shape+0x7e>
 101d609:	cmp    $0x7,%eax
 101d60c:	je     101d61e <myl_rc_native_shape+0x7e>
 101d60e:	cmp    $0x1,%eax
 101d611:	jne    101d69c <myl_rc_native_shape+0xfc>
 101d617:	movl   $0x1,-0x30(%rbp)
 101d61e:	vmovups %ymm0,-0x58(%rbp)
 101d623:	vmovups %ymm0,-0x68(%rbp)
 101d628:	mov    %rbx,-0x78(%rbp)
 101d62c:	lea    -0x38(%rbp),%rax
 101d630:	mov    %rax,-0x70(%rbp)
 101d634:	lea    -0x78(%rbp),%rsi
 101d638:	mov    %rdi,%r14
 101d63b:	vzeroupper
 101d63e:	call   10151d0 <myl_rc_descriptor_import>
 101d643:	test   %eax,%eax
 101d645:	je     101d65c <myl_rc_native_shape+0xbc>
 101d647:	mov    %r14,%rdi
 101d64a:	mov    %eax,%esi
 101d64c:	call   1012560 <myl_rc_record_failure>
 101d651:	xor    %eax,%eax
 101d653:	add    $0x70,%rsp
 101d657:	pop    %rbx
 101d658:	pop    %r14
 101d65a:	pop    %rbp
 101d65b:	ret
 101d65c:	mov    0x1608(%r14),%rcx
 101d663:	mov    0x34(%rbx),%eax
 101d666:	cmp    %rax,0xa0(%rcx)
 101d66d:	jbe    101d68c <myl_rc_native_shape+0xec>
 101d66f:	mov    0x98(%rcx),%rcx
 101d676:	shl    $0x4,%rax
 101d67a:	cmp    %rbx,(%rcx,%rax,1)
 101d67e:	jne    101d68c <myl_rc_native_shape+0xec>
 101d680:	add    %rax,%rcx
 101d683:	mov    0x8(%rcx),%rax
 101d687:	jmp    101d5de <myl_rc_native_shape+0x3e>
 101d68c:	mov    %r14,%rdi
 101d68f:	mov    %rbx,%rsi
 101d692:	call   1012eea <myl_rc_binding_find_slow>
 101d697:	jmp    101d5de <myl_rc_native_shape+0x3e>
 101d69c:	vzeroupper
 101d69f:	call   101efe0 <abort@plt>
 101d6a4:	int3
 101d6a5:	int3
 101d6a6:	int3
 101d6a7:	int3
 101d6a8:	int3
 101d6a9:	int3
 101d6aa:	int3
 101d6ab:	int3
 101d6ac:	int3
 101d6ad:	int3
 101d6ae:	int3
 101d6af:	int3

000000000101d6b0 <flat_transfer>:
 101d6b0:	push   %rbp
 101d6b1:	mov    %rsp,%rbp
 101d6b4:	push   %r15
 101d6b6:	push   %r14
 101d6b8:	push   %r13
 101d6ba:	push   %r12
 101d6bc:	push   %rbx
 101d6bd:	sub    $0x98,%rsp
 101d6c4:	mov    0x40(%rsi),%r10d
 101d6c8:	mov    $0xffffffff,%eax
 101d6cd:	cmp    $0x10,%r10
 101d6d1:	ja     101dbae <flat_transfer+0x4fe>
 101d6d7:	test   %rdi,%rdi
 101d6da:	je     101dbc3 <flat_transfer+0x513>
 101d6e0:	cmp    %rcx,%rdx
 101d6e3:	je     101dbc3 <flat_transfer+0x513>
 101d6e9:	test   %rcx,%rcx
 101d6ec:	je     101dbc3 <flat_transfer+0x513>
 101d6f2:	test   %rdx,%rdx
 101d6f5:	je     101dbc3 <flat_transfer+0x513>
 101d6fb:	cmpq   $0x0,0x1608(%rdi)
 101d703:	je     101dbc3 <flat_transfer+0x513>
 101d709:	mov    0x50(%rsi),%r12
 101d70d:	mov    %rdx,%r11
 101d710:	sub    %rcx,%r11
 101d713:	ja     101d71b <flat_transfer+0x6b>
 101d715:	mov    %rcx,%r11
 101d718:	sub    %rdx,%r11
 101d71b:	cmp    %r12,%r11
 101d71e:	jb     101dbae <flat_transfer+0x4fe>
 101d724:	mov    $0x3,%eax
 101d729:	cmp    0x70(%rdi),%r8d
 101d72d:	ja     101dbae <flat_transfer+0x4fe>
 101d733:	cmpb   $0x0,0x46(%rsi)
 101d737:	je     101d752 <flat_transfer+0xa2>
 101d739:	mov    0x48(%rsi),%eax
 101d73c:	mov    (%rcx,%rax,1),%eax
 101d73f:	lea    0x5a(%rsi),%r11
 101d743:	cmp    $0x20,%rax
 101d747:	lea    0x5c(%rsi,%rax,2),%rax
 101d74c:	cmovae %r11,%rax
 101d750:	jmp    101d756 <flat_transfer+0xa6>
 101d752:	lea    0x58(%rsi),%rax
 101d756:	movzwl (%rax),%r11d
 101d75a:	test   %r10,%r10
 101d75d:	je     101d9c3 <flat_transfer+0x313>
 101d763:	movabs $0x4000000000000000,%rbx
 101d76d:	xor    %r15d,%r15d
 101d770:	movabs $0x7ffffffffffffff0,%rax
 101d77a:	add    $0xc,%rax
 101d77e:	mov    %rax,-0x40(%rbp)
 101d782:	vmovd  -0x1a852(%rip),%xmm0        # 1002f38 <list_scan+0xc>
 101d78a:	jmp    101d7a8 <flat_transfer+0xf8>
 101d78c:	nopl   0x0(%rax)
 101d790:	movq   $0x0,-0xc0(%rbp,%r15,8)
 101d79c:	inc    %r15
 101d79f:	cmp    %r10,%r15
 101d7a2:	je     101d9c3 <flat_transfer+0x313>
 101d7a8:	bt     %r15d,%r11d
 101d7ac:	jae    101d790 <flat_transfer+0xe0>
 101d7ae:	movzwl 0x9c(%rsi,%r15,2),%eax
 101d7b7:	mov    (%rcx,%rax,1),%r13
 101d7bb:	mov    %r13,-0xc0(%rbp,%r15,8)
 101d7c3:	test   %r13,%r13
 101d7c6:	je     101d79c <flat_transfer+0xec>
 101d7c8:	mov    -0x10(%r13),%r14
 101d7cc:	test   $0x2,%r14b
 101d7d0:	jne    101d79c <flat_transfer+0xec>
 101d7d2:	mov    $0xffffffff,%eax
 101d7d7:	bt     $0x3c,%r14
 101d7dc:	jb     101dbae <flat_transfer+0x4fe>
 101d7e2:	test   %rbx,%r14
 101d7e5:	jne    101d82b <flat_transfer+0x17b>
 101d7e7:	test   $0x1,%r14b
 101d7eb:	jne    101dbc3 <flat_transfer+0x513>
 101d7f1:	mov    -0x20(%r13),%rax
 101d7f5:	test   %rax,%rax
 101d7f8:	jne    101d805 <flat_transfer+0x155>
 101d7fa:	cmpq   $0x0,-0x18(%r13)
 101d7ff:	je     101dbc3 <flat_transfer+0x513>
 101d805:	test   %r9d,%r9d
 101d808:	jne    101d79c <flat_transfer+0xec>
 101d80a:	test   %r15,%r15
 101d80d:	je     101d844 <flat_transfer+0x194>
 101d80f:	mov    %rax,-0x30(%rbp)
 101d813:	cmp    $0x4,%r15
 101d817:	mov    %r12,-0x38(%rbp)
 101d81b:	jae    101d859 <flat_transfer+0x1a9>
 101d81d:	mov    $0x1,%r14d
 101d823:	xor    %r12d,%r12d
 101d826:	jmp    101d970 <flat_transfer+0x2c0>
 101d82b:	shr    $0x28,%r14
 101d82f:	and    $0xfffff,%r14d
 101d836:	cmp    %r8d,%r14d
 101d839:	jbe    101d79c <flat_transfer+0xec>
 101d83f:	jmp    101dbae <flat_transfer+0x4fe>
 101d844:	mov    $0xfffffffffffffffe,%r14
 101d84b:	cmp    %r14,%rax
 101d84e:	jbe    101d79c <flat_transfer+0xec>
 101d854:	jmp    101d99c <flat_transfer+0x2ec>
 101d859:	vmovq  %r13,%xmm1
 101d85e:	cmp    $0x10,%r15
 101d862:	jae    101d872 <flat_transfer+0x1c2>
 101d864:	mov    $0x1,%r14d
 101d86a:	xor    %r12d,%r12d
 101d86d:	jmp    101d90f <flat_transfer+0x25f>
 101d872:	mov    %r15,%r14
 101d875:	and    $0xfffffffffffffff0,%r14
 101d879:	mov    %r15,%r12
 101d87c:	movabs $0x7ffffffffffffff0,%rax
 101d886:	and    %rax,%r12
 101d889:	vpbroadcastq %xmm1,%ymm3
 101d88e:	vpxor  %xmm2,%xmm2,%xmm2
 101d892:	xor    %eax,%eax
 101d894:	vmovdqa %ymm0,%ymm4
 101d898:	vpxor  %xmm5,%xmm5,%xmm5
 101d89c:	vpxor  %xmm6,%xmm6,%xmm6
 101d8a0:	vpcmpeqq -0xc0(%rbp,%rax,8),%ymm3,%ymm7
 101d8aa:	vpsubq %ymm7,%ymm4,%ymm4
 101d8ae:	vpcmpeqq -0xa0(%rbp,%rax,8),%ymm3,%ymm7
 101d8b8:	vpsubq %ymm7,%ymm2,%ymm2
 101d8bc:	vpcmpeqq -0x80(%rbp,%rax,8),%ymm3,%ymm7
 101d8c3:	vpcmpeqq -0x60(%rbp,%rax,8),%ymm3,%ymm8
 101d8ca:	vpsubq %ymm7,%ymm5,%ymm5
 101d8ce:	vpsubq %ymm8,%ymm6,%ymm6
 101d8d3:	add    $0x10,%rax
 101d8d7:	cmp    %rax,%r14
 101d8da:	jne    101d8a0 <flat_transfer+0x1f0>
 101d8dc:	vpaddq %ymm4,%ymm2,%ymm2
 101d8e0:	vpaddq %ymm5,%ymm6,%ymm3
 101d8e4:	vpaddq %ymm2,%ymm3,%ymm2
 101d8e8:	vextracti128 $0x1,%ymm2,%xmm3
 101d8ee:	vpaddq %xmm3,%xmm2,%xmm2
 101d8f2:	vpshufd $0xee,%xmm2,%xmm3
 101d8f7:	vpaddq %xmm3,%xmm2,%xmm2
 101d8fb:	vmovq  %xmm2,%r14
 101d900:	cmp    %r12,%r15
 101d903:	je     101d988 <flat_transfer+0x2d8>
 101d909:	test   $0xc,%r15b
 101d90d:	je     101d970 <flat_transfer+0x2c0>
 101d90f:	mov    %r12,%rax
 101d912:	mov    %r15,%rbx
 101d915:	and    $0xfffffffffffffffc,%rbx
 101d919:	mov    %r15,%r12
 101d91c:	and    -0x40(%rbp),%r12
 101d920:	vmovq  %r14,%xmm2
 101d925:	vpbroadcastq %xmm1,%ymm1
 101d92a:	nopw   0x0(%rax,%rax,1)
 101d930:	vpcmpeqq -0xc0(%rbp,%rax,8),%ymm1,%ymm3
 101d93a:	vpsubq %ymm3,%ymm2,%ymm2
 101d93e:	add    $0x4,%rax
 101d942:	cmp    %rax,%rbx
 101d945:	jne    101d930 <flat_transfer+0x280>
 101d947:	vextracti128 $0x1,%ymm2,%xmm1
 101d94d:	vpaddq %xmm1,%xmm2,%xmm1
 101d951:	vpshufd $0xee,%xmm1,%xmm2
 101d956:	vpaddq %xmm2,%xmm1,%xmm1
 101d95a:	vmovq  %xmm1,%r14
 101d95f:	cmp    %r12,%r15
 101d962:	movabs $0x4000000000000000,%rbx
 101d96c:	je     101d988 <flat_transfer+0x2d8>
 101d96e:	xchg   %ax,%ax
 101d970:	xor    %eax,%eax
 101d972:	cmp    %r13,-0xc0(%rbp,%r12,8)
 101d97a:	sete   %al
 101d97d:	add    %rax,%r14
 101d980:	inc    %r12
 101d983:	cmp    %r12,%r15
 101d986:	jne    101d970 <flat_transfer+0x2c0>
 101d988:	not    %r14
 101d98b:	mov    -0x38(%rbp),%r12
 101d98f:	mov    -0x30(%rbp),%rax
 101d993:	cmp    %r14,%rax
 101d996:	jbe    101d79c <flat_transfer+0xec>
 101d99c:	mov    %rdi,%rbx
 101d99f:	mov    %rdx,%rdi
 101d9a2:	xor    %esi,%esi
 101d9a4:	mov    %r12,%rdx
 101d9a7:	vzeroupper
 101d9aa:	call   101e4a0 <compiler_rt.fastMemset>
 101d9af:	mov    %rbx,%rdi
 101d9b2:	mov    0x1608(%rbx),%rcx
 101d9b9:	mov    $0x2,%eax
 101d9be:	jmp    101db98 <flat_transfer+0x4e8>
 101d9c3:	test   %r9d,%r9d
 101d9c6:	je     101da09 <flat_transfer+0x359>
 101d9c8:	cmp    $0x61,%r12
 101d9cc:	setb   %al
 101d9cf:	test   $0x7,%r12b
 101d9d3:	sete   %sil
 101d9d7:	test   %sil,%al
 101d9da:	jne    101da79 <flat_transfer+0x3c9>
 101d9e0:	mov    %rdi,%rbx
 101d9e3:	mov    %rdx,%rdi
 101d9e6:	mov    %rcx,%rsi
 101d9e9:	mov    %r12,%rdx
 101d9ec:	mov    %rcx,%r14
 101d9ef:	vzeroupper
 101d9f2:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101d9f7:	mov    %r14,%rdi
 101d9fa:	xor    %esi,%esi
 101d9fc:	mov    %r12,%rdx
 101d9ff:	call   101e4a0 <compiler_rt.fastMemset>
 101da04:	jmp    101db8c <flat_transfer+0x4dc>
 101da09:	test   %r11d,%r11d
 101da0c:	je     101da61 <flat_transfer+0x3b1>
 101da0e:	movabs $0x4000000000000000,%rax
 101da18:	movabs $0x2000000000000000,%rsi
 101da22:	jmp    101da37 <flat_transfer+0x387>
 101da24:	incq   -0x20(%r8)
 101da28:	nopl   0x0(%rax,%rax,1)
 101da30:	blsr   %r11d,%r11d
 101da35:	je     101da61 <flat_transfer+0x3b1>
 101da37:	tzcnt  %r11d,%r8d
 101da3c:	mov    -0xc0(%rbp,%r8,8),%r8
 101da44:	test   %r8,%r8
 101da47:	je     101da30 <flat_transfer+0x380>
 101da49:	mov    -0x10(%r8),%r10
 101da4d:	test   $0x2,%r10b
 101da51:	jne    101da30 <flat_transfer+0x380>
 101da53:	test   %rax,%r10
 101da56:	je     101da24 <flat_transfer+0x374>
 101da58:	or     %rsi,%r10
 101da5b:	mov    %r10,-0x10(%r8)
 101da5f:	jmp    101da30 <flat_transfer+0x380>
 101da61:	cmp    $0x61,%r12
 101da65:	setb   %al
 101da68:	test   $0x7,%r12b
 101da6c:	sete   %sil
 101da70:	test   %sil,%al
 101da73:	je     101db78 <flat_transfer+0x4c8>
 101da79:	shr    $0x3,%r12
 101da7d:	dec    %r12
 101da80:	cmp    $0xb,%r12
 101da84:	ja     101daf4 <flat_transfer+0x444>
 101da86:	lea    -0x1a4ad(%rip),%rax        # 10035e0 <raw_shape+0x28>
 101da8d:	movslq (%rax,%r12,4),%rsi
 101da91:	add    %rax,%rsi
 101da94:	jmp    *%rsi
 101da96:	mov    0x58(%rcx),%rax
 101da9a:	mov    %rax,0x58(%rdx)
 101da9e:	mov    0x50(%rcx),%rax
 101daa2:	mov    %rax,0x50(%rdx)
 101daa6:	mov    0x48(%rcx),%rax
 101daaa:	mov    %rax,0x48(%rdx)
 101daae:	mov    0x40(%rcx),%rax
 101dab2:	mov    %rax,0x40(%rdx)
 101dab6:	mov    0x38(%rcx),%rax
 101daba:	mov    %rax,0x38(%rdx)
 101dabe:	mov    0x30(%rcx),%rax
 101dac2:	mov    %rax,0x30(%rdx)
 101dac6:	mov    0x28(%rcx),%rax
 101daca:	mov    %rax,0x28(%rdx)
 101dace:	mov    0x20(%rcx),%rax
 101dad2:	mov    %rax,0x20(%rdx)
 101dad6:	mov    0x18(%rcx),%rax
 101dada:	mov    %rax,0x18(%rdx)
 101dade:	mov    0x10(%rcx),%rax
 101dae2:	mov    %rax,0x10(%rdx)
 101dae6:	mov    0x8(%rcx),%rax
 101daea:	mov    %rax,0x8(%rdx)
 101daee:	mov    (%rcx),%rax
 101daf1:	mov    %rax,(%rdx)
 101daf4:	test   %r9d,%r9d
 101daf7:	je     101db8f <flat_transfer+0x4df>
 101dafd:	cmp    $0xb,%r12
 101db01:	ja     101db8f <flat_transfer+0x4df>
 101db07:	lea    -0x1a4fe(%rip),%rax        # 1003610 <raw_shape+0x58>
 101db0e:	movslq (%rax,%r12,4),%rdx
 101db12:	add    %rax,%rdx
 101db15:	jmp    *%rdx
 101db17:	movq   $0x0,0x58(%rcx)
 101db1f:	movq   $0x0,0x50(%rcx)
 101db27:	movq   $0x0,0x48(%rcx)
 101db2f:	movq   $0x0,0x40(%rcx)
 101db37:	movq   $0x0,0x38(%rcx)
 101db3f:	movq   $0x0,0x30(%rcx)
 101db47:	movq   $0x0,0x28(%rcx)
 101db4f:	movq   $0x0,0x20(%rcx)
 101db57:	movq   $0x0,0x18(%rcx)
 101db5f:	movq   $0x0,0x10(%rcx)
 101db67:	movq   $0x0,0x8(%rcx)
 101db6f:	movq   $0x0,(%rcx)
 101db76:	jmp    101db8f <flat_transfer+0x4df>
 101db78:	mov    %rdi,%rbx
 101db7b:	mov    %rdx,%rdi
 101db7e:	mov    %rcx,%rsi
 101db81:	mov    %r12,%rdx
 101db84:	vzeroupper
 101db87:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101db8c:	mov    %rbx,%rdi
 101db8f:	mov    0x1608(%rdi),%rcx
 101db96:	xor    %eax,%eax
 101db98:	cmpq   $0x0,0xc8(%rcx)
 101dba0:	je     101dbae <flat_transfer+0x4fe>
 101dba2:	mov    %eax,%ebx
 101dba4:	vzeroupper
 101dba7:	call   1016000 <myl_rc_drain>
 101dbac:	mov    %ebx,%eax
 101dbae:	add    $0x98,%rsp
 101dbb5:	pop    %rbx
 101dbb6:	pop    %r12
 101dbb8:	pop    %r13
 101dbba:	pop    %r14
 101dbbc:	pop    %r15
 101dbbe:	pop    %rbp
 101dbbf:	vzeroupper
 101dbc2:	ret
 101dbc3:	vzeroupper
 101dbc6:	call   101246d <myl_rc_invariant_failed>
 101dbcb:	int3
 101dbcc:	int3
 101dbcd:	int3
 101dbce:	int3
 101dbcf:	int3

000000000101dbd0 <myl_rc_native_take>:
 101dbd0:	push   %rbp
 101dbd1:	mov    %rsp,%rbp
 101dbd4:	push   %r15
 101dbd6:	push   %r14
 101dbd8:	push   %r13
 101dbda:	push   %r12
 101dbdc:	push   %rbx
 101dbdd:	sub    $0xd8,%rsp
 101dbe4:	mov    %rcx,%r12
 101dbe7:	mov    %rdx,%r14
 101dbea:	mov    %rsi,%r15
 101dbed:	movzwl 0x30(%rsi),%eax
 101dbf1:	cmp    $0x7,%eax
 101dbf4:	je     101dbfa <myl_rc_native_take+0x2a>
 101dbf6:	test   %eax,%eax
 101dbf8:	jne    101dc29 <myl_rc_native_take+0x59>
 101dbfa:	mov    (%r15),%rdx
 101dbfd:	mov    %r14,%rdi
 101dc00:	mov    %r12,%rsi
 101dc03:	call   101e610 <compiler_rt.memmove.memmoveFast>
 101dc08:	mov    $0x1,%r13d
 101dc0e:	cmp    %r12,%r14
 101dc11:	je     101de55 <myl_rc_native_take+0x285>
 101dc17:	mov    (%r15),%rdx
 101dc1a:	mov    %r12,%rdi
 101dc1d:	xor    %esi,%esi
 101dc1f:	call   101e4a0 <compiler_rt.fastMemset>
 101dc24:	jmp    101de55 <myl_rc_native_take+0x285>
 101dc29:	mov    0x1608(%rdi),%rcx
 101dc30:	mov    0x34(%r15),%eax
 101dc34:	cmp    %rax,0xa0(%rcx)
 101dc3b:	jbe    101ddee <myl_rc_native_take+0x21e>
 101dc41:	mov    0x98(%rcx),%rcx
 101dc48:	shl    $0x4,%rax
 101dc4c:	cmp    %r15,(%rcx,%rax,1)
 101dc50:	jne    101ddee <myl_rc_native_take+0x21e>
 101dc56:	add    %rax,%rcx
 101dc59:	mov    0x8(%rcx),%rbx
 101dc5d:	test   %rbx,%rbx
 101dc60:	je     101de02 <myl_rc_native_take+0x232>
 101dc66:	mov    0x8(%rbx),%rsi
 101dc6a:	cmpl   $0x1,0x8(%rsi)
 101dc6e:	jne    101dca2 <myl_rc_native_take+0xd2>
 101dc70:	movq   $0x0,-0x100(%rbp)
 101dc7b:	lea    -0x100(%rbp),%rdx
 101dc82:	mov    $0x1,%r13d
 101dc88:	mov    %r12,%rcx
 101dc8b:	mov    %rdi,%rbx
 101dc8e:	mov    $0x1,%r9d
 101dc94:	call   1019cc0 <myl_rc_pointer_transfer>
 101dc99:	test   %eax,%eax
 101dc9b:	je     101dd18 <myl_rc_native_take+0x148>
 101dc9d:	mov    %rbx,%rdi
 101dca0:	jmp    101dcf4 <myl_rc_native_take+0x124>
 101dca2:	mov    %rsi,-0x40(%rbp)
 101dca6:	cmp    %r12,%r14
 101dca9:	mov    %rdi,-0x38(%rbp)
 101dcad:	je     101dd03 <myl_rc_native_take+0x133>
 101dcaf:	mov    0x1608(%rdi),%rax
 101dcb6:	cmpq   $0x0,0xc8(%rax)
 101dcbe:	jne    101dd03 <myl_rc_native_take+0x133>
 101dcc0:	mov    $0x1,%r13d
 101dcc6:	mov    %rbx,%rsi
 101dcc9:	mov    %r14,%rdx
 101dccc:	mov    %r12,%rcx
 101dccf:	mov    %r8d,-0x2c(%rbp)
 101dcd3:	mov    -0x2c(%rbp),%r8d
 101dcd7:	mov    $0x1,%r9d
 101dcdd:	call   101d6b0 <flat_transfer>
 101dce2:	mov    -0x38(%rbp),%rdi
 101dce6:	mov    -0x2c(%rbp),%r8d
 101dcea:	test   %eax,%eax
 101dcec:	js     101dd03 <myl_rc_native_take+0x133>
 101dcee:	je     101de55 <myl_rc_native_take+0x285>
 101dcf4:	mov    %eax,%esi
 101dcf6:	call   1012560 <myl_rc_record_failure>
 101dcfb:	xor    %r13d,%r13d
 101dcfe:	jmp    101de55 <myl_rc_native_take+0x285>
 101dd03:	mov    (%r15),%rsi
 101dd06:	cmp    $0x81,%rsi
 101dd0d:	jae    101dd27 <myl_rc_native_take+0x157>
 101dd0f:	lea    -0x100(%rbp),%rax
 101dd16:	jmp    101dd46 <myl_rc_native_take+0x176>
 101dd18:	mov    -0x100(%rbp),%rax
 101dd1f:	mov    %rax,(%r14)
 101dd22:	jmp    101de55 <myl_rc_native_take+0x285>
 101dd27:	xor    %r13d,%r13d
 101dd2a:	xor    %edx,%edx
 101dd2c:	mov    %r8d,-0x2c(%rbp)
 101dd30:	call   101c6d0 <myl_rc_storage_bytes>
 101dd35:	mov    -0x38(%rbp),%rdi
 101dd39:	mov    -0x2c(%rbp),%r8d
 101dd3d:	test   %rax,%rax
 101dd40:	je     101de55 <myl_rc_native_take+0x285>
 101dd46:	mov    -0x40(%rbp),%rcx
 101dd4a:	mov    %rcx,-0x80(%rbp)
 101dd4e:	mov    %rax,-0x78(%rbp)
 101dd52:	movq   $0x0,-0x70(%rbp)
 101dd5a:	mov    %r8d,-0x68(%rbp)
 101dd5e:	movl   $0x0,-0x64(%rbp)
 101dd65:	mov    %rcx,-0x60(%rbp)
 101dd69:	mov    %r12,-0x58(%rbp)
 101dd6d:	movq   $0x0,-0x50(%rbp)
 101dd75:	mov    %r8d,-0x48(%rbp)
 101dd79:	movl   $0x0,-0x44(%rbp)
 101dd80:	mov    %rbx,%rsi
 101dd83:	mov    %rax,%rbx
 101dd86:	mov    %rax,%rdx
 101dd89:	mov    %r12,%rcx
 101dd8c:	mov    $0x1,%r9d
 101dd92:	call   101d6b0 <flat_transfer>
 101dd97:	test   %eax,%eax
 101dd99:	jns    101ddac <myl_rc_native_take+0x1dc>
 101dd9b:	lea    -0x80(%rbp),%rsi
 101dd9f:	lea    -0x60(%rbp),%rdx
 101dda3:	mov    -0x38(%rbp),%rdi
 101dda7:	call   101a5e0 <myl_rc_value_take>
 101ddac:	test   %eax,%eax
 101ddae:	je     101ddc0 <myl_rc_native_take+0x1f0>
 101ddb0:	mov    -0x38(%rbp),%rdi
 101ddb4:	mov    %eax,%esi
 101ddb6:	call   1012560 <myl_rc_record_failure>
 101ddbb:	xor    %r13d,%r13d
 101ddbe:	jmp    101ddd4 <myl_rc_native_take+0x204>
 101ddc0:	mov    (%r15),%rdx
 101ddc3:	mov    %r14,%rdi
 101ddc6:	mov    %rbx,%rsi
 101ddc9:	call   101e610 <compiler_rt.memmove.memmoveFast>
 101ddce:	mov    $0x1,%r13d
 101ddd4:	lea    -0x100(%rbp),%rax
 101dddb:	cmp    %rax,%rbx
 101ddde:	je     101de55 <myl_rc_native_take+0x285>
 101dde0:	mov    -0x38(%rbp),%rdi
 101dde4:	mov    %rbx,%rsi
 101dde7:	call   1012ac0 <myl_rc_owner_release>
 101ddec:	jmp    101de55 <myl_rc_native_take+0x285>
 101ddee:	mov    %r15,%rsi
 101ddf1:	call   1012eea <myl_rc_binding_find_slow>
 101ddf6:	mov    %rax,%rbx
 101ddf9:	test   %rbx,%rbx
 101ddfc:	jne    101dc66 <myl_rc_native_take+0x96>
 101de02:	mov    %r8d,-0x2c(%rbp)
 101de06:	mov    %r15,%rsi
 101de09:	mov    %rdi,%rbx
 101de0c:	call   101d5a0 <myl_rc_native_shape>
 101de11:	xor    %r13d,%r13d
 101de14:	test   %rax,%rax
 101de17:	je     101de55 <myl_rc_native_take+0x285>
 101de19:	mov    0x1608(%rbx),%rcx
 101de20:	mov    0x34(%r15),%eax
 101de24:	cmp    %rax,0xa0(%rcx)
 101de2b:	mov    %rbx,%rdi
 101de2e:	jbe    101de6a <myl_rc_native_take+0x29a>
 101de30:	mov    0x98(%rcx),%rcx
 101de37:	shl    $0x4,%rax
 101de3b:	cmp    %r15,(%rcx,%rax,1)
 101de3f:	jne    101de6a <myl_rc_native_take+0x29a>
 101de41:	add    %rax,%rcx
 101de44:	mov    0x8(%rcx),%rbx
 101de48:	mov    -0x2c(%rbp),%r8d
 101de4c:	test   %rbx,%rbx
 101de4f:	jne    101dc66 <myl_rc_native_take+0x96>
 101de55:	mov    %r13d,%eax
 101de58:	add    $0xd8,%rsp
 101de5f:	pop    %rbx
 101de60:	pop    %r12
 101de62:	pop    %r13
 101de64:	pop    %r14
 101de66:	pop    %r15
 101de68:	pop    %rbp
 101de69:	ret
 101de6a:	mov    %r15,%rsi
 101de6d:	call   1012eea <myl_rc_binding_find_slow>
 101de72:	mov    %rax,%rbx
 101de75:	jmp    101de48 <myl_rc_native_take+0x278>
 101de77:	int3
 101de78:	int3
 101de79:	int3
 101de7a:	int3
 101de7b:	int3
 101de7c:	int3
 101de7d:	int3
 101de7e:	int3
 101de7f:	int3

000000000101de80 <myl_rc_native_mutable>:
 101de80:	push   %rbp
 101de81:	mov    %rsp,%rbp
 101de84:	push   %rbx
 101de85:	push   %rax
 101de86:	mov    %rdi,%rbx
 101de89:	call   10118e0 <myl_native_list_header>
 101de8e:	mov    %eax,%ecx
 101de90:	mov    $0x1,%eax
 101de95:	test   %ecx,%ecx
 101de97:	jne    101deaa <myl_rc_native_mutable+0x2a>
 101de99:	mov    %rbx,%rdi
 101de9c:	call   1012390 <myl_native_dictionary_header>
 101dea1:	mov    %eax,%ecx
 101dea3:	xor    %eax,%eax
 101dea5:	test   %ecx,%ecx
 101dea7:	setne  %al
 101deaa:	add    $0x8,%rsp
 101deae:	pop    %rbx
 101deaf:	pop    %rbp
 101deb0:	ret
 101deb1:	int3
 101deb2:	int3
 101deb3:	int3
 101deb4:	int3
 101deb5:	int3
 101deb6:	int3
 101deb7:	int3
 101deb8:	int3
 101deb9:	int3
 101deba:	int3
 101debb:	int3
 101debc:	int3
 101debd:	int3
 101debe:	int3
 101debf:	int3

000000000101dec0 <myl_rc_native_retain>:
 101dec0:	push   %rbp
 101dec1:	mov    %rsp,%rbp
 101dec4:	push   %r15
 101dec6:	push   %r14
 101dec8:	push   %r13
 101deca:	push   %r12
 101decc:	push   %rbx
 101decd:	sub    $0x48,%rsp
 101ded1:	mov    %rdx,%r14
 101ded4:	mov    %rsi,%r12
 101ded7:	mov    0x1608(%rdi),%rdx
 101dede:	mov    0x34(%rsi),%eax
 101dee1:	cmp    %rax,0xa0(%rdx)
 101dee8:	mov    %rdi,-0x30(%rbp)
 101deec:	jbe    101e2e5 <myl_rc_native_retain+0x425>
 101def2:	mov    0x98(%rdx),%rdx
 101def9:	shl    $0x4,%rax
 101defd:	cmp    %r12,(%rdx,%rax,1)
 101df01:	jne    101e2e5 <myl_rc_native_retain+0x425>
 101df07:	add    %rax,%rdx
 101df0a:	mov    0x8(%rdx),%rsi
 101df0e:	test   %rsi,%rsi
 101df11:	je     101e301 <myl_rc_native_retain+0x441>
 101df17:	cmpl   $0x0,0x40(%rsi)
 101df1b:	jne    101df32 <myl_rc_native_retain+0x72>
 101df1d:	mov    0x1608(%rdi),%rax
 101df24:	cmpq   $0x0,0xc8(%rax)
 101df2c:	je     101dfe9 <myl_rc_native_retain+0x129>
 101df32:	mov    0x50(%rsi),%r13
 101df36:	cmpb   $0x0,0x44(%rsi)
 101df3a:	setne  %al
 101df3d:	test   %r13,%r13
 101df40:	setne  %dl
 101df43:	and    %al,%dl
 101df45:	cmp    $0x1,%dl
 101df48:	jne    101df8d <myl_rc_native_retain+0xcd>
 101df4a:	mov    0x1608(%rdi),%rax
 101df51:	test   %rax,%rax
 101df54:	je     101e3c0 <myl_rc_native_retain+0x500>
 101df5a:	test   %rcx,%rcx
 101df5d:	je     101e3c0 <myl_rc_native_retain+0x500>
 101df63:	test   %r14,%r14
 101df66:	je     101e3c0 <myl_rc_native_retain+0x500>
 101df6c:	cmpq   $0x0,0xc0(%rax)
 101df74:	jne    101e3c0 <myl_rc_native_retain+0x500>
 101df7a:	mov    %r14,%rax
 101df7d:	sub    %rcx,%rax
 101df80:	ja     101df88 <myl_rc_native_retain+0xc8>
 101df82:	mov    %rcx,%rax
 101df85:	sub    %r14,%rax
 101df88:	cmp    %r13,%rax
 101df8b:	jae    101dfb2 <myl_rc_native_retain+0xf2>
 101df8d:	mov    0x8(%rsi),%r13
 101df91:	test   %r13,%r13
 101df94:	je     101e395 <myl_rc_native_retain+0x4d5>
 101df9a:	mov    %rcx,%rbx
 101df9d:	mov    %r8d,%r15d
 101dfa0:	call   10169d0 <myl_rc_binding_has_unique>
 101dfa5:	test   %eax,%eax
 101dfa7:	je     101e32f <myl_rc_native_retain+0x46f>
 101dfad:	jmp    101e3c0 <myl_rc_native_retain+0x500>
 101dfb2:	cmp    0x70(%rdi),%r8d
 101dfb6:	jbe    101e034 <myl_rc_native_retain+0x174>
 101dfb8:	mov    %r14,%rdi
 101dfbb:	xor    %esi,%esi
 101dfbd:	mov    %r13,%rdx
 101dfc0:	call   101e4a0 <compiler_rt.fastMemset>
 101dfc5:	mov    -0x30(%rbp),%rdi
 101dfc9:	mov    0x1608(%rdi),%rax
 101dfd0:	mov    $0x3,%r12d
 101dfd6:	cmpq   $0x0,0xc8(%rax)
 101dfde:	jne    101e20e <myl_rc_native_retain+0x34e>
 101dfe4:	jmp    101e224 <myl_rc_native_retain+0x364>
 101dfe9:	mov    (%r12),%rdx
 101dfed:	test   %rdx,%rdx
 101dff0:	je     101df32 <myl_rc_native_retain+0x72>
 101dff6:	mov    %r14,%rax
 101dff9:	sub    %rcx,%rax
 101dffc:	ja     101e004 <myl_rc_native_retain+0x144>
 101dffe:	mov    %rcx,%rax
 101e001:	sub    %r14,%rax
 101e004:	cmp    %rdx,%rax
 101e007:	jb     101df32 <myl_rc_native_retain+0x72>
 101e00d:	cmp    0x70(%rdi),%r8d
 101e011:	jbe    101e234 <myl_rc_native_retain+0x374>
 101e017:	xor    %r12d,%r12d
 101e01a:	mov    %rdi,%rbx
 101e01d:	mov    %r14,%rdi
 101e020:	xor    %esi,%esi
 101e022:	call   101e4a0 <compiler_rt.fastMemset>
 101e027:	mov    %rbx,%rdi
 101e02a:	mov    $0x3,%esi
 101e02f:	jmp    101e38e <myl_rc_native_retain+0x4ce>
 101e034:	cmp    $0x61,%r13
 101e038:	setae  %al
 101e03b:	test   $0x7,%r13b
 101e03f:	setne  %dl
 101e042:	or     %al,%dl
 101e044:	jne    101e0e7 <myl_rc_native_retain+0x227>
 101e04a:	mov    %r13,%rax
 101e04d:	shr    $0x3,%rax
 101e051:	dec    %rax
 101e054:	cmp    $0xb,%rax
 101e058:	ja     101e0c8 <myl_rc_native_retain+0x208>
 101e05a:	lea    -0x1a9f1(%rip),%rdx        # 1003670 <raw_shape+0xb8>
 101e061:	movslq (%rdx,%rax,4),%rax
 101e065:	add    %rdx,%rax
 101e068:	jmp    *%rax
 101e06a:	mov    0x58(%rcx),%rax
 101e06e:	mov    %rax,0x58(%r14)
 101e072:	mov    0x50(%rcx),%rax
 101e076:	mov    %rax,0x50(%r14)
 101e07a:	mov    0x48(%rcx),%rax
 101e07e:	mov    %rax,0x48(%r14)
 101e082:	mov    0x40(%rcx),%rax
 101e086:	mov    %rax,0x40(%r14)
 101e08a:	mov    0x38(%rcx),%rax
 101e08e:	mov    %rax,0x38(%r14)
 101e092:	mov    0x30(%rcx),%rax
 101e096:	mov    %rax,0x30(%r14)
 101e09a:	mov    0x28(%rcx),%rax
 101e09e:	mov    %rax,0x28(%r14)
 101e0a2:	mov    0x20(%rcx),%rax
 101e0a6:	mov    %rax,0x20(%r14)
 101e0aa:	mov    0x18(%rcx),%rax
 101e0ae:	mov    %rax,0x18(%r14)
 101e0b2:	mov    0x10(%rcx),%rax
 101e0b6:	mov    %rax,0x10(%r14)
 101e0ba:	mov    0x8(%rcx),%rax
 101e0be:	mov    %rax,0x8(%r14)
 101e0c2:	mov    (%rcx),%rax
 101e0c5:	mov    %rax,(%r14)
 101e0c8:	cmpb   $0x0,0x46(%rsi)
 101e0cc:	je     101e117 <myl_rc_native_retain+0x257>
 101e0ce:	mov    0x48(%rsi),%eax
 101e0d1:	mov    (%rcx,%rax,1),%eax
 101e0d4:	lea    0x5a(%rsi),%rdx
 101e0d8:	cmp    $0x20,%rax
 101e0dc:	lea    0x5c(%rsi,%rax,2),%rax
 101e0e1:	cmovae %rdx,%rax
 101e0e5:	jmp    101e11b <myl_rc_native_retain+0x25b>
 101e0e7:	mov    %r14,%rdi
 101e0ea:	mov    %rsi,%r12
 101e0ed:	mov    %rcx,%rsi
 101e0f0:	mov    %r13,%rdx
 101e0f3:	mov    %r14,%rbx
 101e0f6:	mov    %rcx,%r14
 101e0f9:	mov    %r8d,%r15d
 101e0fc:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101e101:	mov    -0x30(%rbp),%rdi
 101e105:	mov    %r15d,%r8d
 101e108:	mov    %r14,%rcx
 101e10b:	mov    %rbx,%r14
 101e10e:	mov    %r12,%rsi
 101e111:	cmpb   $0x0,0x46(%rsi)
 101e115:	jne    101e0ce <myl_rc_native_retain+0x20e>
 101e117:	lea    0x58(%rsi),%rax
 101e11b:	movzwl (%rax),%eax
 101e11e:	xor    %r12d,%r12d
 101e121:	test   %eax,%eax
 101e123:	je     101e1fd <myl_rc_native_retain+0x33d>
 101e129:	movabs $0x4000000000000000,%r11
 101e133:	lea    0x2(%r11),%rdx
 101e137:	jmp    101e156 <myl_rc_native_retain+0x296>
 101e139:	cmpq   $0x0,-0x18(%rdi)
 101e13e:	je     101e3c0 <myl_rc_native_retain+0x500>
 101e144:	inc    %r9
 101e147:	mov    %r9,-0x20(%rdi)
 101e14b:	blsr   %eax,%eax
 101e150:	je     101e1f9 <myl_rc_native_retain+0x339>
 101e156:	tzcnt  %eax,%edi
 101e15a:	movzwl 0x9c(%rsi,%rdi,2),%edi
 101e162:	mov    (%rcx,%rdi,1),%rdi
 101e166:	test   %rdi,%rdi
 101e169:	je     101e14b <myl_rc_native_retain+0x28b>
 101e16b:	mov    -0x10(%rdi),%r10
 101e16f:	test   %r11,%r10
 101e172:	je     101e187 <myl_rc_native_retain+0x2c7>
 101e174:	mov    %r10,%r9
 101e177:	shr    $0x28,%r9
 101e17b:	and    $0xfffff,%r9d
 101e182:	cmp    %r8d,%r9d
 101e185:	ja     101e1ad <myl_rc_native_retain+0x2ed>
 101e187:	test   %rdx,%r10
 101e18a:	jne    101e14b <myl_rc_native_retain+0x28b>
 101e18c:	test   $0x1,%r10b
 101e190:	jne    101e3c0 <myl_rc_native_retain+0x500>
 101e196:	mov    -0x20(%rdi),%r9
 101e19a:	test   %r9,%r9
 101e19d:	je     101e139 <myl_rc_native_retain+0x279>
 101e19f:	cmp    $0xffffffffffffffff,%r9
 101e1a3:	jne    101e144 <myl_rc_native_retain+0x284>
 101e1a5:	mov    $0x2,%r12d
 101e1ab:	jmp    101e1c0 <myl_rc_native_retain+0x300>
 101e1ad:	mov    $0x3,%r12d
 101e1b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101e1c0:	tzcnt  %eax,%ecx
 101e1c4:	movzwl 0x9c(%rsi,%rcx,2),%ecx
 101e1cc:	movq   $0x0,(%r14,%rcx,1)
 101e1d4:	blsr   %eax,%eax
 101e1d9:	jne    101e1c0 <myl_rc_native_retain+0x300>
 101e1db:	mov    $0x1,%ecx
 101e1e0:	mov    -0x30(%rbp),%rdi
 101e1e4:	mov    %r14,%rdx
 101e1e7:	call   1015e50 <myl_rc_flat_edges_release>
 101e1ec:	mov    %r14,%rdi
 101e1ef:	xor    %esi,%esi
 101e1f1:	mov    %r13,%rdx
 101e1f4:	call   101e4a0 <compiler_rt.fastMemset>
 101e1f9:	mov    -0x30(%rbp),%rdi
 101e1fd:	mov    0x1608(%rdi),%rax
 101e204:	cmpq   $0x0,0xc8(%rax)
 101e20c:	je     101e21b <myl_rc_native_retain+0x35b>
 101e20e:	mov    -0x30(%rbp),%rdi
 101e212:	call   1016000 <myl_rc_drain>
 101e217:	mov    -0x30(%rbp),%rdi
 101e21b:	test   %r12d,%r12d
 101e21e:	je     101e3a8 <myl_rc_native_retain+0x4e8>
 101e224:	mov    %r12d,%esi
 101e227:	call   1012560 <myl_rc_record_failure>
 101e22c:	xor    %r12d,%r12d
 101e22f:	jmp    101e3ae <myl_rc_native_retain+0x4ee>
 101e234:	cmp    $0x61,%rdx
 101e238:	setae  %al
 101e23b:	test   $0x7,%dl
 101e23e:	setne  %sil
 101e242:	or     %al,%sil
 101e245:	jne    101e2d5 <myl_rc_native_retain+0x415>
 101e24b:	shr    $0x3,%rdx
 101e24f:	mov    $0x1,%r12d
 101e255:	dec    %rdx
 101e258:	cmp    $0xb,%rdx
 101e25c:	ja     101e3ae <myl_rc_native_retain+0x4ee>
 101e262:	lea    -0x1ac29(%rip),%rax        # 1003640 <raw_shape+0x88>
 101e269:	movslq (%rax,%rdx,4),%rdx
 101e26d:	add    %rax,%rdx
 101e270:	jmp    *%rdx
 101e272:	mov    0x58(%rcx),%rax
 101e276:	mov    %rax,0x58(%r14)
 101e27a:	mov    0x50(%rcx),%rax
 101e27e:	mov    %rax,0x50(%r14)
 101e282:	mov    0x48(%rcx),%rax
 101e286:	mov    %rax,0x48(%r14)
 101e28a:	mov    0x40(%rcx),%rax
 101e28e:	mov    %rax,0x40(%r14)
 101e292:	mov    0x38(%rcx),%rax
 101e296:	mov    %rax,0x38(%r14)
 101e29a:	mov    0x30(%rcx),%rax
 101e29e:	mov    %rax,0x30(%r14)
 101e2a2:	mov    0x28(%rcx),%rax
 101e2a6:	mov    %rax,0x28(%r14)
 101e2aa:	mov    0x20(%rcx),%rax
 101e2ae:	mov    %rax,0x20(%r14)
 101e2b2:	mov    0x18(%rcx),%rax
 101e2b6:	mov    %rax,0x18(%r14)
 101e2ba:	mov    0x10(%rcx),%rax
 101e2be:	mov    %rax,0x10(%r14)
 101e2c2:	mov    0x8(%rcx),%rax
 101e2c6:	mov    %rax,0x8(%r14)
 101e2ca:	mov    (%rcx),%rax
 101e2cd:	mov    %rax,(%r14)
 101e2d0:	jmp    101e3ae <myl_rc_native_retain+0x4ee>
 101e2d5:	mov    %r14,%rdi
 101e2d8:	mov    %rcx,%rsi
 101e2db:	call   101e9a0 <compiler_rt.memcpy.memcpyFast>
 101e2e0:	jmp    101e3a8 <myl_rc_native_retain+0x4e8>
 101e2e5:	mov    -0x30(%rbp),%rdi
 101e2e9:	mov    %r12,%rsi
 101e2ec:	call   1012eea <myl_rc_binding_find_slow>
 101e2f1:	mov    -0x30(%rbp),%rdi
 101e2f5:	mov    %rax,%rsi
 101e2f8:	test   %rsi,%rsi
 101e2fb:	jne    101df17 <myl_rc_native_retain+0x57>
 101e301:	mov    %rcx,%rbx
 101e304:	mov    %r8d,%r15d
 101e307:	mov    -0x30(%rbp),%rdi
 101e30b:	mov    %r12,%rsi
 101e30e:	call   101d5a0 <myl_rc_native_shape>
 101e313:	mov    -0x30(%rbp),%rdi
 101e317:	test   %rax,%rax
 101e31a:	je     101e395 <myl_rc_native_retain+0x4d5>
 101e31c:	mov    %rax,%r13
 101e31f:	mov    %r12,%rsi
 101e322:	call   1016800 <myl_rc_native_has_unique>
 101e327:	test   %eax,%eax
 101e329:	jne    101e3c0 <myl_rc_native_retain+0x500>
 101e32f:	mov    (%r12),%rdx
 101e333:	xor    %r12d,%r12d
 101e336:	mov    %r14,%rdi
 101e339:	xor    %esi,%esi
 101e33b:	call   101e4a0 <compiler_rt.fastMemset>
 101e340:	mov    %r13,-0x50(%rbp)
 101e344:	mov    %r14,-0x48(%rbp)
 101e348:	movq   $0x0,-0x40(%rbp)
 101e350:	mov    %r15d,-0x38(%rbp)
 101e354:	movl   $0x0,-0x34(%rbp)
 101e35b:	mov    %r13,-0x70(%rbp)
 101e35f:	mov    %rbx,-0x68(%rbp)
 101e363:	vxorps %xmm0,%xmm0,%xmm0
 101e367:	vmovups %xmm0,-0x60(%rbp)
 101e36c:	lea    -0x50(%rbp),%rsi
 101e370:	lea    -0x70(%rbp),%rdx
 101e374:	mov    $0x1,%ecx
 101e379:	mov    -0x30(%rbp),%rbx
 101e37d:	mov    %rbx,%rdi
 101e380:	call   101a5d0 <myl_rc_value_retain_many>
 101e385:	test   %eax,%eax
 101e387:	je     101e3a8 <myl_rc_native_retain+0x4e8>
 101e389:	mov    %rbx,%rdi
 101e38c:	mov    %eax,%esi
 101e38e:	call   1012560 <myl_rc_record_failure>
 101e393:	jmp    101e3ae <myl_rc_native_retain+0x4ee>
 101e395:	mov    (%r12),%rdx
 101e399:	xor    %r12d,%r12d
 101e39c:	mov    %r14,%rdi
 101e39f:	xor    %esi,%esi
 101e3a1:	call   101e4a0 <compiler_rt.fastMemset>
 101e3a6:	jmp    101e3ae <myl_rc_native_retain+0x4ee>
 101e3a8:	mov    $0x1,%r12d
 101e3ae:	mov    %r12d,%eax
 101e3b1:	add    $0x48,%rsp
 101e3b5:	pop    %rbx
 101e3b6:	pop    %r12
 101e3b8:	pop    %r13
 101e3ba:	pop    %r14
 101e3bc:	pop    %r15
 101e3be:	pop    %rbp
 101e3bf:	ret
 101e3c0:	call   101246d <myl_rc_invariant_failed>
 101e3c5:	int3
 101e3c6:	int3
 101e3c7:	int3
 101e3c8:	int3
 101e3c9:	int3
 101e3ca:	int3
 101e3cb:	int3
 101e3cc:	int3
 101e3cd:	int3
 101e3ce:	int3
 101e3cf:	int3

000000000101e3d0 <myl_rc_native_storage>:
 101e3d0:	push   %rbp
 101e3d1:	mov    %rsp,%rbp
 101e3d4:	mov    %rdx,%r8
 101e3d7:	mov    (%rsi),%rsi
 101e3da:	test   %rsi,%rsi
 101e3dd:	je     101e3eb <myl_rc_native_storage+0x1b>
 101e3df:	mov    %rsi,%rax
 101e3e2:	mul    %r8
 101e3e5:	jno    101e3eb <myl_rc_native_storage+0x1b>
 101e3e7:	xor    %eax,%eax
 101e3e9:	pop    %rbp
 101e3ea:	ret
 101e3eb:	imul   %r8,%rsi
 101e3ef:	mov    %ecx,%edx
 101e3f1:	pop    %rbp
 101e3f2:	jmp    101c6d0 <myl_rc_storage_bytes>
 101e3f7:	int3
 101e3f8:	int3
 101e3f9:	int3
 101e3fa:	int3
 101e3fb:	int3
 101e3fc:	int3
 101e3fd:	int3
 101e3fe:	int3
 101e3ff:	int3

000000000101e400 <myl_rc_native_result>:
 101e400:	xor    %eax,%eax
 101e402:	test   %rsi,%rsi
 101e405:	je     101e408 <myl_rc_native_result+0x8>
 101e407:	ret
 101e408:	push   %rbp
 101e409:	mov    %rsp,%rbp
 101e40c:	push   %r14
 101e40e:	push   %rbx
 101e40f:	mov    %rdi,%rbx
 101e412:	call   1012590 <myl_rc_take_failure>
 101e417:	mov    %eax,%r14d
 101e41a:	cmp    $0x1,%eax
 101e41d:	adc    $0x0,%r14d
 101e421:	mov    %rbx,%rdi
 101e424:	mov    %r14d,%esi
 101e427:	call   1012560 <myl_rc_record_failure>
 101e42c:	mov    %r14d,%eax
 101e42f:	pop    %rbx
 101e430:	pop    %r14
 101e432:	pop    %rbp
 101e433:	ret
 101e434:	int3
 101e435:	int3
 101e436:	int3
 101e437:	int3
 101e438:	int3
 101e439:	int3
 101e43a:	int3
 101e43b:	int3
 101e43c:	int3
 101e43d:	int3
 101e43e:	int3
 101e43f:	int3

000000000101e440 <myl_rc_native_abort>:
 101e440:	push   %rbp
 101e441:	mov    %rsp,%rbp
 101e444:	pop    %rbp
 101e445:	jmp    1016cd0 <myl_rc_construction_abort>
 101e44a:	int3
 101e44b:	int3
 101e44c:	int3
 101e44d:	int3
 101e44e:	int3
 101e44f:	int3

000000000101e450 <compiler_rt.strlen>:
 101e450:	push   %rbp
 101e451:	mov    %rsp,%rbp
 101e454:	mov    $0xffffffffffffffff,%rax
 101e45b:	nopl   0x0(%rax,%rax,1)
 101e460:	cmpb   $0x0,0x1(%rdi,%rax,1)
 101e465:	lea    0x1(%rax),%rax
 101e469:	jne    101e460 <compiler_rt.strlen+0x10>
 101e46b:	pop    %rbp
 101e46c:	ret
 101e46d:	int3
 101e46e:	int3
 101e46f:	int3

000000000101e470 <bcmp>:
 101e470:	push   %rbp
 101e471:	mov    %rsp,%rbp
 101e474:	test   %rdx,%rdx
 101e477:	je     101e491 <bcmp+0x21>
 101e479:	xor    %eax,%eax
 101e47b:	nopl   0x0(%rax,%rax,1)
 101e480:	movzbl (%rdi,%rax,1),%ecx
 101e484:	cmp    (%rsi,%rax,1),%cl
 101e487:	jne    101e495 <bcmp+0x25>
 101e489:	inc    %rax
 101e48c:	cmp    %rax,%rdx
 101e48f:	jne    101e480 <bcmp+0x10>
 101e491:	xor    %eax,%eax
 101e493:	pop    %rbp
 101e494:	ret
 101e495:	mov    $0x1,%eax
 101e49a:	pop    %rbp
 101e49b:	ret
 101e49c:	int3
 101e49d:	int3
 101e49e:	int3
 101e49f:	int3

000000000101e4a0 <compiler_rt.fastMemset>:
 101e4a0:	mov    %rdi,%rax
 101e4a3:	cmp    $0x40,%rdx
 101e4a7:	jbe    101e4eb <compiler_rt.fastMemset+0x4b>
 101e4a9:	push   %rbp
 101e4aa:	mov    %rsp,%rbp
 101e4ad:	vmovd  %esi,%xmm0
 101e4b1:	vpbroadcastb %xmm0,%ymm0
 101e4b6:	vmovdqu %ymm0,(%rax)
 101e4ba:	mov    %rax,%rcx
 101e4bd:	and    $0xffffffffffffffe0,%rcx
 101e4c1:	lea    (%rax,%rdx,1),%rdi
 101e4c5:	sub    %rcx,%rdi
 101e4c8:	add    $0x20,%rcx
 101e4cc:	add    $0xffffffffffffffdf,%rdi
 101e4d0:	shr    $0x5,%rdi
 101e4d4:	lea    -0x1(%rdi),%r8
 101e4d8:	mov    %edi,%esi
 101e4da:	and    $0x7,%esi
 101e4dd:	cmp    $0x7,%r8
 101e4e1:	jae    101e52d <compiler_rt.fastMemset+0x8d>
 101e4e3:	xor    %r8d,%r8d
 101e4e6:	jmp    101e58d <compiler_rt.fastMemset+0xed>
 101e4eb:	test   %rdx,%rdx
 101e4ee:	je     101e5b5 <compiler_rt.fastMemset+0x115>
 101e4f4:	cmp    $0x9,%rdx
 101e4f8:	jb     101e5b9 <compiler_rt.fastMemset+0x119>
 101e4fe:	cmp    $0x11,%rdx
 101e502:	jb     101e5d6 <compiler_rt.fastMemset+0x136>
 101e508:	vmovd  %esi,%xmm0
 101e50c:	vpbroadcastb %xmm0,%xmm0
 101e511:	vmovdqu %xmm0,(%rax)
 101e515:	cmp    $0x21,%rdx
 101e519:	jb     101e526 <compiler_rt.fastMemset+0x86>
 101e51b:	vmovdqu %xmm0,0x10(%rax)
 101e520:	vmovdqu %xmm0,-0x20(%rax,%rdx,1)
 101e526:	vmovdqu %xmm0,-0x10(%rax,%rdx,1)
 101e52c:	ret
 101e52d:	and    $0xfffffffffffffff8,%rdi
 101e531:	lea    0xe0(%rcx),%r9
 101e538:	xor    %r8d,%r8d
 101e53b:	nopl   0x0(%rax,%rax,1)
 101e540:	vmovdqa %ymm0,-0xe0(%r9)
 101e549:	vmovdqa %ymm0,-0xc0(%r9)
 101e552:	vmovdqa %ymm0,-0xa0(%r9)
 101e55b:	vmovdqa %ymm0,-0x80(%r9)
 101e561:	vmovdqa %ymm0,-0x60(%r9)
 101e567:	vmovdqa %ymm0,-0x40(%r9)
 101e56d:	vmovdqa %ymm0,-0x20(%r9)
 101e573:	vmovdqa %ymm0,(%r9)
 101e578:	add    $0x8,%r8
 101e57c:	add    $0x100,%r9
 101e583:	cmp    %r8,%rdi
 101e586:	jne    101e540 <compiler_rt.fastMemset+0xa0>
 101e588:	test   %rsi,%rsi
 101e58b:	je     101e5ae <compiler_rt.fastMemset+0x10e>
 101e58d:	shl    $0x5,%r8
 101e591:	add    %r8,%rcx
 101e594:	shl    $0x5,%esi
 101e597:	xor    %edi,%edi
 101e599:	nopl   0x0(%rax)
 101e5a0:	vmovdqa %ymm0,(%rcx,%rdi,1)
 101e5a5:	add    $0x20,%rdi
 101e5a9:	cmp    %rdi,%rsi
 101e5ac:	jne    101e5a0 <compiler_rt.fastMemset+0x100>
 101e5ae:	vmovdqu %ymm0,-0x20(%rax,%rdx,1)
 101e5b4:	pop    %rbp
 101e5b5:	vzeroupper
 101e5b8:	ret
 101e5b9:	cmp    $0x3,%rdx
 101e5bd:	jb     101e5f1 <compiler_rt.fastMemset+0x151>
 101e5bf:	cmp    $0x5,%rdx
 101e5c3:	jb     101e5fa <compiler_rt.fastMemset+0x15a>
 101e5c5:	movzbl %sil,%ecx
 101e5c9:	imul   $0x1010101,%ecx,%ecx
 101e5cf:	mov    %ecx,(%rax)
 101e5d1:	mov    %ecx,-0x4(%rax,%rdx,1)
 101e5d5:	ret
 101e5d6:	movzbl %sil,%ecx
 101e5da:	movabs $0x101010101010101,%rsi
 101e5e4:	imul   %rcx,%rsi
 101e5e8:	mov    %rsi,(%rax)
 101e5eb:	mov    %rsi,-0x8(%rax,%rdx,1)
 101e5f0:	ret
 101e5f1:	mov    %sil,(%rax)
 101e5f4:	mov    %sil,-0x1(%rax,%rdx,1)
 101e5f9:	ret
 101e5fa:	movzbl %sil,%ecx
 101e5fe:	shl    $0x8,%esi
 101e601:	or     %ecx,%esi
 101e603:	mov    %si,(%rax)
 101e606:	mov    %si,-0x2(%rax,%rdx,1)
 101e60b:	ret
 101e60c:	int3
 101e60d:	int3
 101e60e:	int3
 101e60f:	int3

000000000101e610 <compiler_rt.memmove.memmoveFast>:
 101e610:	mov    %rdi,%rax
 101e613:	cmp    $0xf,%rdx
 101e617:	ja     101e64c <compiler_rt.memmove.memmoveFast+0x3c>
 101e619:	cmp    $0x3,%rdx
 101e61d:	ja     101e6bf <compiler_rt.memmove.memmoveFast+0xaf>
 101e623:	test   %rdx,%rdx
 101e626:	je     101e6eb <compiler_rt.memmove.memmoveFast+0xdb>
 101e62c:	mov    %rdx,%rcx
 101e62f:	shr    $1,%rcx
 101e632:	movzbl (%rsi),%edi
 101e635:	movzbl (%rsi,%rcx,1),%r8d
 101e63a:	movzbl -0x1(%rsi,%rdx,1),%esi
 101e63f:	mov    %dil,(%rax)
 101e642:	mov    %r8b,(%rax,%rcx,1)
 101e646:	mov    %sil,-0x1(%rax,%rdx,1)
 101e64b:	ret
 101e64c:	push   %rbp
 101e64d:	mov    %rsp,%rbp
 101e650:	push   %r14
 101e652:	push   %rbx
 101e653:	sub    $0x40,%rsp
 101e657:	cmp    $0x3f,%rdx
 101e65b:	ja     101e6ec <compiler_rt.memmove.memmoveFast+0xdc>
 101e661:	mov    %edx,%ecx
 101e663:	shr    $1,%ecx
 101e665:	and    $0x10,%ecx
 101e668:	lea    -0x10(%rdx),%rdi
 101e66c:	sub    %rcx,%rdi
 101e66f:	vmovups (%rsi),%xmm0
 101e673:	vmovaps %xmm0,-0x50(%rbp)
 101e678:	vmovups (%rsi,%rcx,1),%xmm1
 101e67d:	vmovaps %xmm1,-0x20(%rbp)
 101e682:	vmovups (%rsi,%rdi,1),%xmm1
 101e687:	vmovaps %xmm1,-0x30(%rbp)
 101e68c:	vmovups -0x10(%rsi,%rdx,1),%xmm1
 101e692:	vmovaps %xmm1,-0x40(%rbp)
 101e697:	vmovups %xmm0,(%rax)
 101e69b:	vmovaps -0x20(%rbp),%xmm0
 101e6a0:	vmovups %xmm0,(%rax,%rcx,1)
 101e6a5:	vmovaps -0x30(%rbp),%xmm0
 101e6aa:	vmovups %xmm0,(%rax,%rdi,1)
 101e6af:	vmovaps -0x40(%rbp),%xmm0
 101e6b4:	vmovups %xmm0,-0x10(%rax,%rdx,1)
 101e6ba:	jmp    101e98e <compiler_rt.memmove.memmoveFast+0x37e>
 101e6bf:	mov    %edx,%ecx
 101e6c1:	shr    $1,%ecx
 101e6c3:	and    $0x4,%ecx
 101e6c6:	lea    -0x4(%rdx),%rdi
 101e6ca:	sub    %rcx,%rdi
 101e6cd:	mov    (%rsi),%r8d
 101e6d0:	mov    (%rsi,%rcx,1),%r9d
 101e6d4:	mov    (%rsi,%rdi,1),%r10d
 101e6d8:	mov    -0x4(%rsi,%rdx,1),%esi
 101e6dc:	mov    %r8d,(%rax)
 101e6df:	mov    %r9d,(%rax,%rcx,1)
 101e6e3:	mov    %r10d,(%rax,%rdi,1)
 101e6e7:	mov    %esi,-0x4(%rax,%rdx,1)
 101e6eb:	ret
 101e6ec:	cmp    %rax,%rsi
 101e6ef:	jae    101e843 <compiler_rt.memmove.memmoveFast+0x233>
 101e6f5:	lea    -0x20(%rdx),%rcx
 101e6f9:	vmovups -0x20(%rsi,%rdx,1),%ymm0
 101e6ff:	vmovups %ymm0,-0x70(%rbp)
 101e704:	vmovups (%rsi),%ymm0
 101e708:	vmovups %ymm0,-0x90(%rbp)
 101e710:	add    %rax,%rdx
 101e713:	and    $0xffffffffffffffe0,%rdx
 101e717:	mov    %rdx,%r8
 101e71a:	sub    %rax,%r8
 101e71d:	mov    %r8,%r9
 101e720:	shr    $0x5,%r9
 101e724:	je     101e828 <compiler_rt.memmove.memmoveFast+0x218>
 101e72a:	mov    %r9d,%edi
 101e72d:	and    $0x7,%edi
 101e730:	mov    $0x1,%r10d
 101e736:	cmp    $0x100,%r8
 101e73d:	jb     101e7f7 <compiler_rt.memmove.memmoveFast+0x1e7>
 101e743:	lea    (%r8,%rsi,1),%r11
 101e747:	add    $0xffffffffffffffe0,%r11
 101e74b:	and    $0xfffffffffffffff8,%r9
 101e74f:	neg    %r9
 101e752:	mov    $0xffffffffffffffe0,%rbx
 101e759:	nopl   0x0(%rax)
 101e760:	vmovups 0x20(%r11,%rbx,1),%ymm0
 101e767:	vmovaps %ymm0,(%rdx,%rbx,1)
 101e76c:	vmovups (%r11,%rbx,1),%ymm0
 101e772:	vmovaps %ymm0,-0x20(%rdx,%rbx,1)
 101e778:	vmovups -0x20(%r11,%rbx,1),%ymm0
 101e77f:	vmovaps %ymm0,-0x40(%rdx,%rbx,1)
 101e785:	vmovups -0x40(%r11,%rbx,1),%ymm0
 101e78c:	vmovaps %ymm0,-0x60(%rdx,%rbx,1)
 101e792:	vmovups -0x60(%r11,%rbx,1),%ymm0
 101e799:	vmovaps %ymm0,-0x80(%rdx,%rbx,1)
 101e79f:	vmovups -0x80(%r11,%rbx,1),%ymm0
 101e7a6:	vmovaps %ymm0,-0xa0(%rdx,%rbx,1)
 101e7af:	vmovups -0xa0(%r11,%rbx,1),%ymm0
 101e7b9:	vmovaps %ymm0,-0xc0(%rdx,%rbx,1)
 101e7c2:	vmovups -0xc0(%r11,%rbx,1),%ymm0
 101e7cc:	vmovaps %ymm0,-0xe0(%rdx,%rbx,1)
 101e7d5:	add    $0xffffffffffffff00,%rbx
 101e7dc:	lea    (%r9,%r10,1),%r14
 101e7e0:	add    $0x8,%r14
 101e7e4:	add    $0x8,%r10
 101e7e8:	cmp    $0x1,%r14
 101e7ec:	jne    101e760 <compiler_rt.memmove.memmoveFast+0x150>
 101e7f2:	test   %rdi,%rdi
 101e7f5:	je     101e828 <compiler_rt.memmove.memmoveFast+0x218>
 101e7f7:	shl    $0x5,%r10
 101e7fb:	sub    %r10,%r8
 101e7fe:	add    %r8,%rsi
 101e801:	sub    %r10,%rdx
 101e804:	shl    $0x5,%edi
 101e807:	xor    %r8d,%r8d
 101e80a:	nopw   0x0(%rax,%rax,1)
 101e810:	vmovups (%rsi,%r8,1),%ymm0
 101e816:	vmovaps %ymm0,(%rdx,%r8,1)
 101e81c:	add    $0xffffffffffffffe0,%r8
 101e820:	mov    %rdi,%r9
 101e823:	add    %r8,%r9
 101e826:	jne    101e810 <compiler_rt.memmove.memmoveFast+0x200>
 101e828:	vmovups -0x90(%rbp),%ymm0
 101e830:	vmovups %ymm0,(%rax)
 101e834:	vmovups -0x70(%rbp),%ymm0
 101e839:	vmovups %ymm0,(%rax,%rcx,1)
 101e83e:	jmp    101e98e <compiler_rt.memmove.memmoveFast+0x37e>
 101e843:	vmovups (%rsi),%ymm0
 101e847:	vmovups %ymm0,-0xb0(%rbp)
 101e84f:	lea    -0x20(%rdx),%rcx
 101e853:	vmovups -0x20(%rsi,%rdx,1),%ymm0
 101e859:	vmovups %ymm0,-0xd0(%rbp)
 101e861:	mov    %esi,%edi
 101e863:	and    $0x1f,%edi
 101e866:	lea    (%rdx,%rdi,1),%r8
 101e86a:	add    $0xffffffffffffffe0,%r8
 101e86e:	shr    $0x5,%r8
 101e872:	lea    -0x1(%r8),%r9
 101e876:	mov    %r8d,%edx
 101e879:	and    $0x7,%edx
 101e87c:	cmp    $0x7,%r9
 101e880:	jae    101e88a <compiler_rt.memmove.memmoveFast+0x27a>
 101e882:	xor    %r9d,%r9d
 101e885:	jmp    101e939 <compiler_rt.memmove.memmoveFast+0x329>
 101e88a:	and    $0xfffffffffffffff8,%r8
 101e88e:	mov    $0x100,%r10d
 101e894:	sub    %rdi,%r10
 101e897:	xor    %r9d,%r9d
 101e89a:	nopw   0x0(%rax,%rax,1)
 101e8a0:	vmovaps -0xe0(%rsi,%r10,1),%ymm0
 101e8aa:	vmovups %ymm0,-0xe0(%rax,%r10,1)
 101e8b4:	vmovaps -0xc0(%rsi,%r10,1),%ymm0
 101e8be:	vmovups %ymm0,-0xc0(%rax,%r10,1)
 101e8c8:	vmovaps -0xa0(%rsi,%r10,1),%ymm0
 101e8d2:	vmovups %ymm0,-0xa0(%rax,%r10,1)
 101e8dc:	vmovaps -0x80(%rsi,%r10,1),%ymm0
 101e8e3:	vmovups %ymm0,-0x80(%rax,%r10,1)
 101e8ea:	vmovaps -0x60(%rsi,%r10,1),%ymm0
 101e8f1:	vmovups %ymm0,-0x60(%rax,%r10,1)
 101e8f8:	vmovaps -0x40(%rsi,%r10,1),%ymm0
 101e8ff:	vmovups %ymm0,-0x40(%rax,%r10,1)
 101e906:	vmovaps -0x20(%rsi,%r10,1),%ymm0
 101e90d:	vmovups %ymm0,-0x20(%rax,%r10,1)
 101e914:	vmovaps (%rsi,%r10,1),%ymm0
 101e91a:	vmovups %ymm0,(%rax,%r10,1)
 101e920:	add    $0x8,%r9
 101e924:	add    $0x100,%r10
 101e92b:	cmp    %r9,%r8
 101e92e:	jne    101e8a0 <compiler_rt.memmove.memmoveFast+0x290>
 101e934:	test   %rdx,%rdx
 101e937:	je     101e975 <compiler_rt.memmove.memmoveFast+0x365>
 101e939:	shl    $0x5,%r9
 101e93d:	sub    %rdi,%r9
 101e940:	add    %r9,%rsi
 101e943:	add    $0x20,%rsi
 101e947:	lea    (%rax,%r9,1),%rdi
 101e94b:	add    $0x20,%rdi
 101e94f:	shl    $0x5,%edx
 101e952:	xor    %r8d,%r8d
 101e955:	data16 cs nopw 0x0(%rax,%rax,1)
 101e960:	vmovaps (%rsi,%r8,1),%ymm0
 101e966:	vmovups %ymm0,(%rdi,%r8,1)
 101e96c:	add    $0x20,%r8
 101e970:	cmp    %r8,%rdx
 101e973:	jne    101e960 <compiler_rt.memmove.memmoveFast+0x350>
 101e975:	vmovups -0xd0(%rbp),%ymm0
 101e97d:	vmovups %ymm0,(%rax,%rcx,1)
 101e982:	vmovups -0xb0(%rbp),%ymm0
 101e98a:	vmovups %ymm0,(%rax)
 101e98e:	add    $0x40,%rsp
 101e992:	pop    %rbx
 101e993:	pop    %r14
 101e995:	pop    %rbp
 101e996:	vzeroupper
 101e999:	ret
 101e99a:	int3
 101e99b:	int3
 101e99c:	int3
 101e99d:	int3
 101e99e:	int3
 101e99f:	int3

000000000101e9a0 <compiler_rt.memcpy.memcpyFast>:
 101e9a0:	push   %rbp
 101e9a1:	mov    %rsp,%rbp
 101e9a4:	mov    %rdi,%rax
 101e9a7:	cmp    $0xf,%rdx
 101e9ab:	ja     101e9d6 <compiler_rt.memcpy.memcpyFast+0x36>
 101e9ad:	cmp    $0x3,%rdx
 101e9b1:	ja     101ea14 <compiler_rt.memcpy.memcpyFast+0x74>
 101e9b3:	test   %rdx,%rdx
 101e9b6:	je     101ea12 <compiler_rt.memcpy.memcpyFast+0x72>
 101e9b8:	movzbl (%rsi),%ecx
 101e9bb:	mov    %cl,(%rax)
 101e9bd:	mov    %rdx,%rcx
 101e9c0:	shr    $1,%rcx
 101e9c3:	movzbl (%rsi,%rcx,1),%edi
 101e9c7:	mov    %dil,(%rax,%rcx,1)
 101e9cb:	movzbl -0x1(%rsi,%rdx,1),%ecx
 101e9d0:	mov    %cl,-0x1(%rax,%rdx,1)
 101e9d4:	pop    %rbp
 101e9d5:	ret
 101e9d6:	cmp    $0x3f,%rdx
 101e9da:	ja     101ea40 <compiler_rt.memcpy.memcpyFast+0xa0>
 101e9dc:	mov    %edx,%ecx
 101e9de:	shr    $1,%ecx
 101e9e0:	and    $0x10,%ecx
 101e9e3:	lea    -0x10(%rdx),%rdi
 101e9e7:	sub    %rcx,%rdi
 101e9ea:	vmovups (%rsi),%xmm0
 101e9ee:	vmovups %xmm0,(%rax)
 101e9f2:	vmovups (%rsi,%rcx,1),%xmm0
 101e9f7:	vmovups %xmm0,(%rax,%rcx,1)
 101e9fc:	vmovups (%rsi,%rdi,1),%xmm0
 101ea01:	vmovups %xmm0,(%rax,%rdi,1)
 101ea06:	vmovups -0x10(%rsi,%rdx,1),%xmm0
 101ea0c:	vmovups %xmm0,-0x10(%rax,%rdx,1)
 101ea12:	pop    %rbp
 101ea13:	ret
 101ea14:	mov    %edx,%ecx
 101ea16:	shr    $1,%ecx
 101ea18:	and    $0x4,%ecx
 101ea1b:	lea    -0x4(%rdx),%rdi
 101ea1f:	sub    %rcx,%rdi
 101ea22:	mov    (%rsi),%r8d
 101ea25:	mov    %r8d,(%rax)
 101ea28:	mov    (%rsi,%rcx,1),%r8d
 101ea2c:	mov    %r8d,(%rax,%rcx,1)
 101ea30:	mov    (%rsi,%rdi,1),%ecx
 101ea33:	mov    %ecx,(%rax,%rdi,1)
 101ea36:	mov    -0x4(%rsi,%rdx,1),%ecx
 101ea3a:	mov    %ecx,-0x4(%rax,%rdx,1)
 101ea3e:	pop    %rbp
 101ea3f:	ret
 101ea40:	vmovups (%rsi),%ymm0
 101ea44:	vmovups %ymm0,(%rax)
 101ea48:	mov    %esi,%edi
 101ea4a:	and    $0x1f,%edi
 101ea4d:	lea    (%rdi,%rdx,1),%r8
 101ea51:	add    $0xffffffffffffffe0,%r8
 101ea55:	shr    $0x5,%r8
 101ea59:	lea    -0x1(%r8),%r9
 101ea5d:	mov    %r8d,%ecx
 101ea60:	and    $0x7,%ecx
 101ea63:	cmp    $0x7,%r9
 101ea67:	jae    101ea71 <compiler_rt.memcpy.memcpyFast+0xd1>
 101ea69:	xor    %r9d,%r9d
 101ea6c:	jmp    101eb29 <compiler_rt.memcpy.memcpyFast+0x189>
 101ea71:	and    $0xfffffffffffffff8,%r8
 101ea75:	mov    $0x100,%r10d
 101ea7b:	sub    %rdi,%r10
 101ea7e:	xor    %r9d,%r9d
 101ea81:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101ea90:	vmovaps -0xe0(%rsi,%r10,1),%ymm0
 101ea9a:	vmovups %ymm0,-0xe0(%rax,%r10,1)
 101eaa4:	vmovaps -0xc0(%rsi,%r10,1),%ymm0
 101eaae:	vmovups %ymm0,-0xc0(%rax,%r10,1)
 101eab8:	vmovaps -0xa0(%rsi,%r10,1),%ymm0
 101eac2:	vmovups %ymm0,-0xa0(%rax,%r10,1)
 101eacc:	vmovaps -0x80(%rsi,%r10,1),%ymm0
 101ead3:	vmovups %ymm0,-0x80(%rax,%r10,1)
 101eada:	vmovaps -0x60(%rsi,%r10,1),%ymm0
 101eae1:	vmovups %ymm0,-0x60(%rax,%r10,1)
 101eae8:	vmovaps -0x40(%rsi,%r10,1),%ymm0
 101eaef:	vmovups %ymm0,-0x40(%rax,%r10,1)
 101eaf6:	vmovaps -0x20(%rsi,%r10,1),%ymm0
 101eafd:	vmovups %ymm0,-0x20(%rax,%r10,1)
 101eb04:	vmovaps (%rsi,%r10,1),%ymm0
 101eb0a:	vmovups %ymm0,(%rax,%r10,1)
 101eb10:	add    $0x8,%r9
 101eb14:	add    $0x100,%r10
 101eb1b:	cmp    %r9,%r8
 101eb1e:	jne    101ea90 <compiler_rt.memcpy.memcpyFast+0xf0>
 101eb24:	test   %rcx,%rcx
 101eb27:	je     101eb65 <compiler_rt.memcpy.memcpyFast+0x1c5>
 101eb29:	shl    $0x5,%r9
 101eb2d:	sub    %rdi,%r9
 101eb30:	lea    (%rsi,%r9,1),%rdi
 101eb34:	add    $0x20,%rdi
 101eb38:	lea    (%rax,%r9,1),%r8
 101eb3c:	add    $0x20,%r8
 101eb40:	shl    $0x5,%ecx
 101eb43:	xor    %r9d,%r9d
 101eb46:	cs nopw 0x0(%rax,%rax,1)
 101eb50:	vmovaps (%rdi,%r9,1),%ymm0
 101eb56:	vmovups %ymm0,(%r8,%r9,1)
 101eb5c:	add    $0x20,%r9
 101eb60:	cmp    %r9,%rcx
 101eb63:	jne    101eb50 <compiler_rt.memcpy.memcpyFast+0x1b0>
 101eb65:	vmovups -0x20(%rsi,%rdx,1),%ymm0
 101eb6b:	vmovups %ymm0,-0x20(%rax,%rdx,1)
 101eb71:	pop    %rbp
 101eb72:	vzeroupper
 101eb75:	ret
 101eb76:	int3
 101eb77:	int3
 101eb78:	int3
 101eb79:	int3
 101eb7a:	int3
 101eb7b:	int3
 101eb7c:	int3
 101eb7d:	int3
 101eb7e:	int3
 101eb7f:	int3

000000000101eb80 <compiler_rt.sqrt.sqrt>:
 101eb80:	push   %rbp
 101eb81:	mov    %rsp,%rbp
 101eb84:	vmovq  %xmm0,%rax
 101eb89:	mov    %rax,%rcx
 101eb8c:	shr    $0x34,%rcx
 101eb90:	lea    -0x7ff(%rcx),%edx
 101eb96:	cmp    $0xfffff802,%edx
 101eb9c:	jb     101ecd7 <compiler_rt.sqrt.sqrt+0x157>
 101eba2:	movabs $0x8000000000000000,%rsi
 101ebac:	mov    %rax,%rdx
 101ebaf:	shl    $0xa,%rdx
 101ebb3:	lea    -0x400(%rsi),%r8
 101ebba:	and    %rdx,%r8
 101ebbd:	mov    %rax,%rdi
 101ebc0:	shl    $0xb,%rdi
 101ebc4:	or     %rsi,%rdi
 101ebc7:	test   $0x1,%cl
 101ebca:	cmovne %r8,%rdi
 101ebce:	shr    $0x2e,%rax
 101ebd2:	and    $0x7f,%eax
 101ebd5:	lea    -0x1b53c(%rip),%rdx        # 10036a0 <__anon_939530997>
 101ebdc:	movzwl (%rdx,%rax,2),%eax
 101ebe0:	shl    $0x10,%eax
 101ebe3:	mov    %rdi,%rdx
 101ebe6:	shr    $0x20,%rdx
 101ebea:	imul   %rax,%rdx
 101ebee:	shr    $0x20,%rdx
 101ebf2:	mov    %rdx,%r9
 101ebf5:	imul   %rax,%r9
 101ebf9:	shr    $0x20,%r9
 101ebfd:	mov    $0xc0000000,%r8d
 101ec03:	mov    $0xc0000000,%r10d
 101ec09:	sub    %r9d,%r10d
 101ec0c:	imul   %r10,%rax
 101ec10:	shr    $0x1f,%rax
 101ec14:	and    $0xfffffffe,%eax
 101ec17:	imul   %r10,%rdx
 101ec1b:	shr    $0x1f,%rdx
 101ec1f:	and    $0xfffffffe,%edx
 101ec22:	imul   %rax,%rdx
 101ec26:	shr    $0x20,%rdx
 101ec2a:	sub    %edx,%r8d
 101ec2d:	imul   %rax,%r8
 101ec31:	add    %r8,%r8
 101ec34:	movabs $0xfffffffe00000000,%rax
 101ec3e:	and    %r8,%rax
 101ec41:	mov    %rax,%rdx
 101ec44:	mulx   %rdi,%rdx,%rdx
 101ec49:	mulx   %rax,%rax,%rax
 101ec4e:	movabs $0xc000000000000000,%r8
 101ec58:	sub    %rax,%r8
 101ec5b:	mulx   %r8,%rax,%rax
 101ec60:	add    $0xfffffffffffffffe,%rax
 101ec64:	shr    $0x9,%rax
 101ec68:	shl    $0x2a,%rdi
 101ec6c:	mov    %rax,%rdx
 101ec6f:	imul   %rax,%rdx
 101ec73:	sub    %rdi,%rdx
 101ec76:	add    %rax,%rdx
 101ec79:	mov    %rdx,%rdi
 101ec7c:	shr    $0x3f,%rdi
 101ec80:	add    %rax,%rdi
 101ec83:	add    %rdx,%rax
 101ec86:	mov    $0x34,%r8b
 101ec89:	bzhi   %r8,%rdi,%rdi
 101ec8e:	shl    $0x33,%rcx
 101ec92:	movabs $0x1ff8000000000000,%r8
 101ec9c:	add    %rcx,%r8
 101ec9f:	movabs $0xfff0000000000000,%rcx
 101eca9:	and    %r8,%rcx
 101ecac:	or     %rdi,%rcx
 101ecaf:	vmovq  %rcx,%xmm0
 101ecb4:	inc    %rax
 101ecb7:	je     101ecd5 <compiler_rt.sqrt.sqrt+0x155>
 101ecb9:	xor    %rdx,%rax
 101ecbc:	and    %rsi,%rax
 101ecbf:	movabs $0x10000000000000,%rcx
 101ecc9:	or     %rax,%rcx
 101eccc:	vmovq  %rcx,%xmm1
 101ecd1:	vaddsd %xmm1,%xmm0,%xmm0
 101ecd5:	pop    %rbp
 101ecd6:	ret
 101ecd7:	vxorpd %xmm1,%xmm1,%xmm1
 101ecdb:	vucomisd %xmm1,%xmm0
 101ecdf:	setnp  %dl
 101ece2:	sete   %sil
 101ece6:	movabs $0x7ff0000000000000,%rcx
 101ecf0:	and    %dl,%sil
 101ecf3:	cmp    %rcx,%rax
 101ecf6:	sete   %dl
 101ecf9:	or     %sil,%dl
 101ecfc:	jne    101ecd5 <compiler_rt.sqrt.sqrt+0x155>
 101ecfe:	cmp    %rcx,%rax
 101ed01:	jbe    101ed0d <compiler_rt.sqrt.sqrt+0x18d>
 101ed03:	vsubsd %xmm0,%xmm0,%xmm0
 101ed07:	vdivsd %xmm1,%xmm0,%xmm0
 101ed0b:	pop    %rbp
 101ed0c:	ret
 101ed0d:	vmulsd -0x1bf0d(%rip),%xmm0,%xmm0        # 1002e08 <qbe_empty_registry+0x60>
 101ed15:	vmovq  %xmm0,%rax
 101ed1a:	mov    %rax,%rcx
 101ed1d:	shr    $0x34,%rcx
 101ed21:	add    $0xffffffffffffffcc,%rcx
 101ed25:	jmp    101eba2 <compiler_rt.sqrt.sqrt+0x22>

Disassembly of section .init:

000000000101ed2c <_init>:
 101ed2c:	endbr64
 101ed30:	sub    $0x8,%rsp
 101ed34:	mov    0xa615(%rip),%rax        # 1029350 <__gmon_start__>
 101ed3b:	test   %rax,%rax
 101ed3e:	je     101ed42 <_init+0x16>
 101ed40:	call   *%rax
 101ed42:	add    $0x8,%rsp
 101ed46:	ret

Disassembly of section .fini:

000000000101ed48 <_fini>:
 101ed48:	endbr64
 101ed4c:	sub    $0x8,%rsp
 101ed50:	add    $0x8,%rsp
 101ed54:	ret

Disassembly of section .plt:

000000000101ed60 <calloc@plt-0x10>:
 101ed60:	push   0xa632(%rip)        # 1029398 <_GLOBAL_OFFSET_TABLE_+0x8>
 101ed66:	jmp    *0xa634(%rip)        # 10293a0 <_GLOBAL_OFFSET_TABLE_+0x10>
 101ed6c:	nopl   0x0(%rax)

000000000101ed70 <calloc@plt>:
 101ed70:	jmp    *0xa632(%rip)        # 10293a8 <calloc@GLIBC_2.2.5>
 101ed76:	push   $0x0
 101ed7b:	jmp    101ed60 <_fini+0x18>

000000000101ed80 <longjmp@plt>:
 101ed80:	jmp    *0xa62a(%rip)        # 10293b0 <longjmp@GLIBC_2.2.5>
 101ed86:	push   $0x1
 101ed8b:	jmp    101ed60 <_fini+0x18>

000000000101ed90 <fwrite@plt>:
 101ed90:	jmp    *0xa622(%rip)        # 10293b8 <fwrite@GLIBC_2.2.5>
 101ed96:	push   $0x2
 101ed9b:	jmp    101ed60 <_fini+0x18>

000000000101eda0 <fprintf@plt>:
 101eda0:	jmp    *0xa61a(%rip)        # 10293c0 <fprintf@GLIBC_2.2.5>
 101eda6:	push   $0x3
 101edab:	jmp    101ed60 <_fini+0x18>

000000000101edb0 <fegetround@plt>:
 101edb0:	jmp    *0xa612(%rip)        # 10293c8 <fegetround@GLIBC_2.2.5>
 101edb6:	push   $0x4
 101edbb:	jmp    101ed60 <_fini+0x18>

000000000101edc0 <free@plt>:
 101edc0:	jmp    *0xa60a(%rip)        # 10293d0 <free@GLIBC_2.2.5>
 101edc6:	push   $0x5
 101edcb:	jmp    101ed60 <_fini+0x18>

000000000101edd0 <strncmp@plt>:
 101edd0:	jmp    *0xa602(%rip)        # 10293d8 <strncmp@GLIBC_2.2.5>
 101edd6:	push   $0x6
 101eddb:	jmp    101ed60 <_fini+0x18>

000000000101ede0 <strcmp@plt>:
 101ede0:	jmp    *0xa5fa(%rip)        # 10293e0 <strcmp@GLIBC_2.2.5>
 101ede6:	push   $0x7
 101edeb:	jmp    101ed60 <_fini+0x18>

000000000101edf0 <sigemptyset@plt>:
 101edf0:	jmp    *0xa5f2(%rip)        # 10293e8 <sigemptyset@GLIBC_2.2.5>
 101edf6:	push   $0x8
 101edfb:	jmp    101ed60 <_fini+0x18>

000000000101ee00 <sigaction@plt>:
 101ee00:	jmp    *0xa5ea(%rip)        # 10293f0 <sigaction@GLIBC_2.2.5>
 101ee06:	push   $0x9
 101ee0b:	jmp    101ed60 <_fini+0x18>

000000000101ee10 <timer_create@plt>:
 101ee10:	jmp    *0xa5e2(%rip)        # 10293f8 <timer_create@GLIBC_2.34>
 101ee16:	push   $0xa
 101ee1b:	jmp    101ed60 <_fini+0x18>

000000000101ee20 <timer_settime@plt>:
 101ee20:	jmp    *0xa5da(%rip)        # 1029400 <timer_settime@GLIBC_2.34>
 101ee26:	push   $0xb
 101ee2b:	jmp    101ed60 <_fini+0x18>

000000000101ee30 <printf@plt>:
 101ee30:	jmp    *0xa5d2(%rip)        # 1029408 <printf@GLIBC_2.2.5>
 101ee36:	push   $0xc
 101ee3b:	jmp    101ed60 <_fini+0x18>

000000000101ee40 <vsnprintf@plt>:
 101ee40:	jmp    *0xa5ca(%rip)        # 1029410 <vsnprintf@GLIBC_2.2.5>
 101ee46:	push   $0xd
 101ee4b:	jmp    101ed60 <_fini+0x18>

000000000101ee50 <snprintf@plt>:
 101ee50:	jmp    *0xa5c2(%rip)        # 1029418 <snprintf@GLIBC_2.2.5>
 101ee56:	push   $0xe
 101ee5b:	jmp    101ed60 <_fini+0x18>

000000000101ee60 <malloc@plt>:
 101ee60:	jmp    *0xa5ba(%rip)        # 1029420 <malloc@GLIBC_2.2.5>
 101ee66:	push   $0xf
 101ee6b:	jmp    101ed60 <_fini+0x18>

000000000101ee70 <fflush@plt>:
 101ee70:	jmp    *0xa5b2(%rip)        # 1029428 <fflush@GLIBC_2.2.5>
 101ee76:	push   $0x10
 101ee7b:	jmp    101ed60 <_fini+0x18>

000000000101ee80 <_Unwind_Backtrace@plt>:
 101ee80:	jmp    *0xa5aa(%rip)        # 1029430 <_Unwind_Backtrace>
 101ee86:	push   $0x11
 101ee8b:	jmp    101ed60 <_fini+0x18>

000000000101ee90 <_Unwind_GetIP@plt>:
 101ee90:	jmp    *0xa5a2(%rip)        # 1029438 <_Unwind_GetIP>
 101ee96:	push   $0x12
 101ee9b:	jmp    101ed60 <_fini+0x18>

000000000101eea0 <qsort@plt>:
 101eea0:	jmp    *0xa59a(%rip)        # 1029440 <qsort@GLIBC_2.2.5>
 101eea6:	push   $0x13
 101eeab:	jmp    101ed60 <_fini+0x18>

000000000101eeb0 <write@plt>:
 101eeb0:	jmp    *0xa592(%rip)        # 1029448 <write@GLIBC_2.2.5>
 101eeb6:	push   $0x14
 101eebb:	jmp    101ed60 <_fini+0x18>

000000000101eec0 <_exit@plt>:
 101eec0:	jmp    *0xa58a(%rip)        # 1029450 <_exit@GLIBC_2.2.5>
 101eec6:	push   $0x15
 101eecb:	jmp    101ed60 <_fini+0x18>

000000000101eed0 <sysconf@plt>:
 101eed0:	jmp    *0xa582(%rip)        # 1029458 <sysconf@GLIBC_2.2.5>
 101eed6:	push   $0x16
 101eedb:	jmp    101ed60 <_fini+0x18>

000000000101eee0 <mmap@plt>:
 101eee0:	jmp    *0xa57a(%rip)        # 1029460 <mmap@GLIBC_2.2.5>
 101eee6:	push   $0x17
 101eeeb:	jmp    101ed60 <_fini+0x18>

000000000101eef0 <mprotect@plt>:
 101eef0:	jmp    *0xa572(%rip)        # 1029468 <mprotect@GLIBC_2.2.5>
 101eef6:	push   $0x18
 101eefb:	jmp    101ed60 <_fini+0x18>

000000000101ef00 <getcontext@plt>:
 101ef00:	jmp    *0xa56a(%rip)        # 1029470 <getcontext@GLIBC_2.2.5>
 101ef06:	push   $0x19
 101ef0b:	jmp    101ed60 <_fini+0x18>

000000000101ef10 <makecontext@plt>:
 101ef10:	jmp    *0xa562(%rip)        # 1029478 <makecontext@GLIBC_2.2.5>
 101ef16:	push   $0x1a
 101ef1b:	jmp    101ed60 <_fini+0x18>

000000000101ef20 <swapcontext@plt>:
 101ef20:	jmp    *0xa55a(%rip)        # 1029480 <swapcontext@GLIBC_2.2.5>
 101ef26:	push   $0x1b
 101ef2b:	jmp    101ed60 <_fini+0x18>

000000000101ef30 <munmap@plt>:
 101ef30:	jmp    *0xa552(%rip)        # 1029488 <munmap@GLIBC_2.2.5>
 101ef36:	push   $0x1c
 101ef3b:	jmp    101ed60 <_fini+0x18>

000000000101ef40 <getrlimit@plt>:
 101ef40:	jmp    *0xa54a(%rip)        # 1029490 <getrlimit@GLIBC_2.2.5>
 101ef46:	push   $0x1d
 101ef4b:	jmp    101ed60 <_fini+0x18>

000000000101ef50 <_setjmp@plt>:
 101ef50:	jmp    *0xa542(%rip)        # 1029498 <_setjmp@GLIBC_2.2.5>
 101ef56:	push   $0x1e
 101ef5b:	jmp    101ed60 <_fini+0x18>

000000000101ef60 <strchr@plt>:
 101ef60:	jmp    *0xa53a(%rip)        # 10294a0 <strchr@GLIBC_2.2.5>
 101ef66:	push   $0x1f
 101ef6b:	jmp    101ed60 <_fini+0x18>

000000000101ef70 <realloc@plt>:
 101ef70:	jmp    *0xa532(%rip)        # 10294a8 <realloc@GLIBC_2.2.5>
 101ef76:	push   $0x20
 101ef7b:	jmp    101ed60 <_fini+0x18>

000000000101ef80 <memchr@plt>:
 101ef80:	jmp    *0xa52a(%rip)        # 10294b0 <memchr@GLIBC_2.2.5>
 101ef86:	push   $0x21
 101ef8b:	jmp    101ed60 <_fini+0x18>

000000000101ef90 <getenv@plt>:
 101ef90:	jmp    *0xa522(%rip)        # 10294b8 <getenv@GLIBC_2.2.5>
 101ef96:	push   $0x22
 101ef9b:	jmp    101ed60 <_fini+0x18>

000000000101efa0 <strtoull@plt>:
 101efa0:	jmp    *0xa51a(%rip)        # 10294c0 <strtoull@GLIBC_2.2.5>
 101efa6:	push   $0x23
 101efab:	jmp    101ed60 <_fini+0x18>

000000000101efb0 <clock_gettime@plt>:
 101efb0:	jmp    *0xa512(%rip)        # 10294c8 <clock_gettime@GLIBC_2.17>
 101efb6:	push   $0x24
 101efbb:	jmp    101ed60 <_fini+0x18>

000000000101efc0 <unsetenv@plt>:
 101efc0:	jmp    *0xa50a(%rip)        # 10294d0 <unsetenv@GLIBC_2.2.5>
 101efc6:	push   $0x25
 101efcb:	jmp    101ed60 <_fini+0x18>

000000000101efd0 <setrlimit@plt>:
 101efd0:	jmp    *0xa502(%rip)        # 10294d8 <setrlimit@GLIBC_2.2.5>
 101efd6:	push   $0x26
 101efdb:	jmp    101ed60 <_fini+0x18>

000000000101efe0 <abort@plt>:
 101efe0:	jmp    *0xa4fa(%rip)        # 10294e0 <abort@GLIBC_2.2.5>
 101efe6:	push   $0x27
 101efeb:	jmp    101ed60 <_fini+0x18>

000000000101eff0 <strrchr@plt>:
 101eff0:	jmp    *0xa4f2(%rip)        # 10294e8 <strrchr@GLIBC_2.2.5>
 101eff6:	push   $0x28
 101effb:	jmp    101ed60 <_fini+0x18>

000000000101f000 <strtoul@plt>:
 101f000:	jmp    *0xa4ea(%rip)        # 10294f0 <strtoul@GLIBC_2.2.5>
 101f006:	push   $0x29
 101f00b:	jmp    101ed60 <_fini+0x18>

000000000101f010 <inet_pton@plt>:
 101f010:	jmp    *0xa4e2(%rip)        # 10294f8 <inet_pton@GLIBC_2.2.5>
 101f016:	push   $0x2a
 101f01b:	jmp    101ed60 <_fini+0x18>

000000000101f020 <socket@plt>:
 101f020:	jmp    *0xa4da(%rip)        # 1029500 <socket@GLIBC_2.2.5>
 101f026:	push   $0x2b
 101f02b:	jmp    101ed60 <_fini+0x18>

000000000101f030 <connect@plt>:
 101f030:	jmp    *0xa4d2(%rip)        # 1029508 <connect@GLIBC_2.2.5>
 101f036:	push   $0x2c
 101f03b:	jmp    101ed60 <_fini+0x18>

000000000101f040 <close@plt>:
 101f040:	jmp    *0xa4ca(%rip)        # 1029510 <close@GLIBC_2.2.5>
 101f046:	push   $0x2d
 101f04b:	jmp    101ed60 <_fini+0x18>

000000000101f050 <read@plt>:
 101f050:	jmp    *0xa4c2(%rip)        # 1029518 <read@GLIBC_2.2.5>
 101f056:	push   $0x2e
 101f05b:	jmp    101ed60 <_fini+0x18>

000000000101f060 <__errno_location@plt>:
 101f060:	jmp    *0xa4ba(%rip)        # 1029520 <__errno_location@GLIBC_2.2.5>
 101f066:	push   $0x2f
 101f06b:	jmp    101ed60 <_fini+0x18>

000000000101f070 <lseek@plt>:
 101f070:	jmp    *0xa4b2(%rip)        # 1029528 <lseek@GLIBC_2.2.5>
 101f076:	push   $0x30
 101f07b:	jmp    101ed60 <_fini+0x18>

000000000101f080 <pwrite@plt>:
 101f080:	jmp    *0xa4aa(%rip)        # 1029530 <pwrite@GLIBC_2.2.5>
 101f086:	push   $0x31
 101f08b:	jmp    101ed60 <_fini+0x18>

000000000101f090 <open@plt>:
 101f090:	jmp    *0xa4a2(%rip)        # 1029538 <open@GLIBC_2.2.5>
 101f096:	push   $0x32
 101f09b:	jmp    101ed60 <_fini+0x18>

000000000101f0a0 <openat@plt>:
 101f0a0:	jmp    *0xa49a(%rip)        # 1029540 <openat@GLIBC_2.4>
 101f0a6:	push   $0x33
 101f0ab:	jmp    101ed60 <_fini+0x18>

000000000101f0b0 <fstatat@plt>:
 101f0b0:	jmp    *0xa492(%rip)        # 1029548 <fstatat@GLIBC_2.33>
 101f0b6:	push   $0x34
 101f0bb:	jmp    101ed60 <_fini+0x18>

000000000101f0c0 <mkdirat@plt>:
 101f0c0:	jmp    *0xa48a(%rip)        # 1029550 <mkdirat@GLIBC_2.4>
 101f0c6:	push   $0x35
 101f0cb:	jmp    101ed60 <_fini+0x18>

000000000101f0d0 <fdopendir@plt>:
 101f0d0:	jmp    *0xa482(%rip)        # 1029558 <fdopendir@GLIBC_2.4>
 101f0d6:	push   $0x36
 101f0db:	jmp    101ed60 <_fini+0x18>

000000000101f0e0 <readdir@plt>:
 101f0e0:	jmp    *0xa47a(%rip)        # 1029560 <readdir@GLIBC_2.2.5>
 101f0e6:	push   $0x37
 101f0eb:	jmp    101ed60 <_fini+0x18>

000000000101f0f0 <dirfd@plt>:
 101f0f0:	jmp    *0xa472(%rip)        # 1029568 <dirfd@GLIBC_2.2.5>
 101f0f6:	push   $0x38
 101f0fb:	jmp    101ed60 <_fini+0x18>

000000000101f100 <fstat@plt>:
 101f100:	jmp    *0xa46a(%rip)        # 1029570 <fstat@GLIBC_2.33>
 101f106:	push   $0x39
 101f10b:	jmp    101ed60 <_fini+0x18>

000000000101f110 <unlinkat@plt>:
 101f110:	jmp    *0xa462(%rip)        # 1029578 <unlinkat@GLIBC_2.4>
 101f116:	push   $0x3a
 101f11b:	jmp    101ed60 <_fini+0x18>

000000000101f120 <ftruncate@plt>:
 101f120:	jmp    *0xa45a(%rip)        # 1029580 <ftruncate@GLIBC_2.2.5>
 101f126:	push   $0x3b
 101f12b:	jmp    101ed60 <_fini+0x18>

000000000101f130 <closedir@plt>:
 101f130:	jmp    *0xa452(%rip)        # 1029588 <closedir@GLIBC_2.2.5>
 101f136:	push   $0x3c
 101f13b:	jmp    101ed60 <_fini+0x18>

000000000101f140 <fcntl@plt>:
 101f140:	jmp    *0xa44a(%rip)        # 1029590 <fcntl@GLIBC_2.2.5>
 101f146:	push   $0x3d
 101f14b:	jmp    101ed60 <_fini+0x18>

000000000101f150 <madvise@plt>:
 101f150:	jmp    *0xa442(%rip)        # 1029598 <madvise@GLIBC_2.2.5>
 101f156:	push   $0x3e
 101f15b:	jmp    101ed60 <_fini+0x18>

000000000101f160 <mremap@plt>:
 101f160:	jmp    *0xa43a(%rip)        # 10295a0 <mremap@GLIBC_2.2.5>
 101f166:	push   $0x3f
 101f16b:	jmp    101ed60 <_fini+0x18>
