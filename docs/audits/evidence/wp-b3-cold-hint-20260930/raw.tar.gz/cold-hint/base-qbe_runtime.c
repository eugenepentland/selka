#define _POSIX_C_SOURCE 200809L
/* Separately compiled scalar runtime. Keep it independent of declaration order. */
#include "qbe_runtime.h"
#include "native_collections.h"
#include "native_cow.h"
#include "native_text.h"
#if defined(MYL_NATIVE_RC_COUNTING) && MYL_NATIVE_RC_COUNTING
#include "native_rc_stats.h"
#endif
#include <inttypes.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <fenv.h>
#include <time.h>
#include <unistd.h>
#include <unwind.h>
#if defined(__FAST_MATH__) || FLT_RADIX != 2 || DBL_MANT_DIG != 53 || DBL_MAX_EXP != 1024
#error "mylang binary64 requires strict IEEE binary64 arithmetic"
#endif

typedef __int128 Wide;
typedef unsigned __int128 UnsignedWide;
typedef MylQbeContext Context;
/* Set only by an executable entry that runs one guest program and then returns
 * from `main` (see `myl_qbe_exit_without_sweep`). The exit sweep is a heap check
 * and a courtesy: no guest can observe the freed objects, so a process that is
 * about to release the whole address space skips it. */
static int exit_without_sweep;
void myl_qbe_exit_without_sweep(void) { exit_without_sweep = 1; }
/* RC-EXIT-SKIP-1: whether the program's normal exit may leave every remaining
 * object alone. Only a production RC artifact can (the counting runtime balances
 * every allocation and the checked runtime reports leaks, so both keep the full
 * release walk), only a process that is the whole program (`final`), never a
 * stress run (its exit release is a heap check), and only while no registered
 * file, socket or host handle is open, because releasing an owner is where such
 * a handle is flushed and closed. Objects have no other finalizer. */
#if defined(MYL_NATIVE_RC) && MYL_NATIVE_RC && !(defined(MYL_NATIVE_RC_COUNTING) && MYL_NATIVE_RC_COUNTING)
int myl_qbe_exit_skip(void *context) {
    const Context *ctx = context;
    return exit_without_sweep && !ctx->heap.stress && !ctx->resource_live[0] && !ctx->resource_live[1];
}
#else
int myl_qbe_exit_skip(void *context) { (void)context; return 0; }
#endif
static int execute_config_args(uint64_t (*entry)(void *), uint64_t steps, uint64_t frames, int stress, const struct MylangNativeProvidersTag *providers, void (*initialize)(void *), int guest_argc, char **guest_argv, MylQbeResult *result);
_Static_assert(offsetof(Context, steps) == 0, "QBE context steps ABI");
_Static_assert(offsetof(Context, frames) == 8, "QBE context frame count ABI");
_Static_assert(offsetof(Context, max_steps) == 16, "QBE context step limit ABI");
_Static_assert(offsetof(Context, trap) == 32, "QBE context trap ABI");
_Static_assert(offsetof(Context, active_frame) == 48, "QBE context active frame ABI");
_Static_assert(offsetof(Context, frame_limit) == 56, "QBE context frame limit ABI");
_Static_assert(offsetof(Context, frame_floor) == 64, "QBE context frame floor ABI");
_Static_assert(offsetof(MylQbeActiveFrame, function) == 8, "QBE frame function ABI");
_Static_assert(offsetof(MylQbeActiveFrame, position) == 16, "QBE frame position ABI");
/* Generated code now links the root chain itself, so this offset is an ABI:
   mirror any change here in `heap_roots_offset` in src/qbe.zig. */
_Static_assert(offsetof(myl_native_heap, roots) == 16, "QBE heap roots ABI");
/* A root record is four words, and generated code stores the value word at
   offset 24; mirror any change here in `pushRoot` and `allocateStorage`. */
_Static_assert(offsetof(myl_native_root, value) == 24, "QBE root value ABI");
_Static_assert(sizeof(myl_native_root) == 32, "QBE root record ABI");
/* Stable trap for a guest that outgrew its byte ceiling. It is a runtime trap
   like any other R_ code, so it exits 1 rather than reporting a host defect. */
static const char *const memory_budget_code = "R_MEMORY_BUDGET";
/* A budget trap tells the reader which flag imposes it, because a bounded run
   is a deliberate decision, not a program defect. */
static const char *describe(const char *code) {
    if (!strcmp(code, memory_budget_code)) return "memory budget exhausted";
    if (!strcmp(code, "R_STEP_LIMIT")) return "instruction budget exhausted; raise it with --max-steps=N";
    if (!strcmp(code, "R_NO_STEP_ACCOUNTING")) return "this build omits instruction-budget accounting";
    if (!strcmp(code, "R_NO_FRAME_ACCOUNTING")) return "this build omits call-depth accounting";
    if (!strcmp(code, "R_FRAME_LIMIT")) return "call-depth budget exhausted; raise it with --max-frames=N (each frame reserves 32 KiB of stack, so --max-memory must cover N x 32 KiB)";
    if (!strcmp(code, "R_REQUIRES")) return "precondition violated";
    if (!strcmp(code, "R_ENSURES")) return "postcondition violated";
    if (!strcmp(code, "R_INVARIANT")) return "invariant violated";
    return strncmp(code, "R_", 2) ? "QBE runtime failure" : "native execution failed";
}
/* Wall-clock guard for otherwise unbounded execution. The timer is monotonic,
   so a system clock change cannot move it; when it fires the handler writes a
   stable trap-like diagnostic and leaves via _exit, because only async-signal-
   safe calls are legal there. `--timeout=SECONDS` arms it; no flag leaves the
   program without an elapsed-time ceiling. */
static timer_t timeout_timer;
static void on_timeout(int signal_number) {
    (void)signal_number;
    static const char message[] = "R_TIMEOUT: wall-clock budget exhausted; raise it with --timeout=SECONDS\n";
    ssize_t ignored = write(STDERR_FILENO, message, sizeof message - 1);
    (void)ignored;
    _exit(1);
}
/* Arm the monotonic timer for `seconds`; zero (no flag) arms nothing. Returns 0
   when the process cannot install the handler or the timer. */
static int arm_timeout(uint64_t seconds) {
    if (!seconds) return 1;
    struct sigaction action = {0};
    action.sa_handler = on_timeout;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGALRM, &action, NULL)) return 0;
    struct sigevent event = {0};
    event.sigev_notify = SIGEV_SIGNAL;
    event.sigev_signo = SIGALRM;
    if (timer_create(CLOCK_MONOTONIC, &event, &timeout_timer)) return 0;
    struct itimerspec spec = {0};
    spec.it_value.tv_sec = (time_t)seconds;
    return timer_settime(timeout_timer, 0, &spec, NULL) == 0;
}
/* Append one formatted fragment; returns 0 when the bounded buffer would
   truncate. The caller keeps the buffer NUL terminated on success. */
static int append(char *out, size_t size, size_t *used, const char *format, ...) {
    va_list arguments;
    va_start(arguments, format);
    int written = vsnprintf(out + *used, size - *used, format, arguments);
    va_end(arguments);
    if (written < 0 || (size_t)written >= size - *used) return 0;
    *used += (size_t)written;
    return 1;
}
/* Human-readable suffix rendered from the same detail the JSON record carries.
   Writes nothing (0) when no reportable fields are present. */
static size_t detail_text(const MylQbeTrapDetail *detail, char *out, size_t size) {
    if (size == 0) return 0;
    size_t used = 0;
    out[0] = 0;
    if (!detail->version) return 0;
    uint32_t present = detail->present;
    if (present & MYL_QBE_TRAP_PRESENT_INDEX) {
        if (!append(out, size, &used, " (index %" PRId64, detail->index)) return 0;
        if ((present & MYL_QBE_TRAP_PRESENT_LENGTH) &&
            !append(out, size, &used, ", length %" PRIu64, detail->length)) return 0;
        if (!append(out, size, &used, ")")) return 0;
    } else if (present & MYL_QBE_TRAP_PRESENT_LENGTH) {
        if (!append(out, size, &used, " (length %" PRIu64 ")", detail->length)) return 0;
    } else if (present & (MYL_QBE_TRAP_PRESENT_LEFT | MYL_QBE_TRAP_PRESENT_RIGHT | MYL_QBE_TRAP_PRESENT_WIDTH)) {
        if (!append(out, size, &used, " (%s:", detail->operation ? detail->operation : "arithmetic")) return 0;
        if (present & MYL_QBE_TRAP_PRESENT_UNSIGNED) {
            if ((present & MYL_QBE_TRAP_PRESENT_LEFT) &&
                !append(out, size, &used, " left %" PRIu64, (uint64_t)detail->left)) return 0;
            if ((present & MYL_QBE_TRAP_PRESENT_RIGHT) &&
                !append(out, size, &used, ", right %" PRIu64, (uint64_t)detail->right)) return 0;
        } else {
            if ((present & MYL_QBE_TRAP_PRESENT_LEFT) &&
                !append(out, size, &used, " left %" PRId64, detail->left)) return 0;
            if ((present & MYL_QBE_TRAP_PRESENT_RIGHT) &&
                !append(out, size, &used, ", right %" PRId64, detail->right)) return 0;
        }
        if ((present & MYL_QBE_TRAP_PRESENT_WIDTH) &&
            !append(out, size, &used, ", width %" PRIu64, detail->width)) return 0;
        if (!append(out, size, &used, ")")) return 0;
    } else if (detail->operation && *detail->operation) {
        /* A message-only detail: `assert cond, "text"` records present=0 and the
           assertion text as `operation`, so the human line reads
           `R_ASSERT: text` without disturbing any numeric rendering above. */
        if (!append(out, size, &used, ": %s", detail->operation)) return 0;
    }
    return used;
}
/* Append a quoted JSON string for arbitrary text. An assertion message is guest
   data, so a quote, backslash or control byte is escaped rather than copied; the
   record stays one valid JSON line for every message. Returns 0 on truncation. */
static int append_json_string(char *out, size_t size, size_t *used, const char *value) {
    if (!append(out, size, used, "\"")) return 0;
    for (const unsigned char *byte = (const unsigned char *)value; *byte; ++byte) {
        if (*byte == '"' || *byte == '\\') {
            if (!append(out, size, used, "\\%c", *byte)) return 0;
        } else if (*byte < 0x20) {
            if (!append(out, size, used, "\\u%04x", *byte)) return 0;
        } else if (!append(out, size, used, "%c", *byte)) return 0;
    }
    return append(out, size, used, "\"");
}
/* One bounded line of JSON for the structured transport. Only present numeric
   fields are emitted, matching the downstream `trap_detail` object. */
static size_t detail_json(const MylQbeTrapDetail *detail, char *out, size_t size) {
    if (size == 0) return 0;
    size_t used = 0;
    out[0] = 0;
    if (!detail->version) return 0;
    uint32_t present = detail->present;
    if (!append(out, size, &used, "{\"version\":%u,\"operation\":", detail->version)) return 0;
    if (!append_json_string(out, size, &used, detail->operation ? detail->operation : "operation")) return 0;
    if ((present & MYL_QBE_TRAP_PRESENT_INDEX) &&
        !append(out, size, &used, ",\"index\":%" PRId64, detail->index)) return 0;
    if ((present & MYL_QBE_TRAP_PRESENT_LENGTH) &&
        !append(out, size, &used, ",\"length\":%" PRIu64, detail->length)) return 0;
    if (present & MYL_QBE_TRAP_PRESENT_UNSIGNED) {
        if (!append(out, size, &used, ",\"unsigned\":true")) return 0;
        if ((present & MYL_QBE_TRAP_PRESENT_LEFT) &&
            !append(out, size, &used, ",\"left\":%" PRIu64, (uint64_t)detail->left)) return 0;
        if ((present & MYL_QBE_TRAP_PRESENT_RIGHT) &&
            !append(out, size, &used, ",\"right\":%" PRIu64, (uint64_t)detail->right)) return 0;
    } else {
        if ((present & MYL_QBE_TRAP_PRESENT_LEFT) &&
            !append(out, size, &used, ",\"left\":%" PRId64, detail->left)) return 0;
        if ((present & MYL_QBE_TRAP_PRESENT_RIGHT) &&
            !append(out, size, &used, ",\"right\":%" PRId64, detail->right)) return 0;
    }
    if ((present & MYL_QBE_TRAP_PRESENT_WIDTH) &&
        !append(out, size, &used, ",\"width\":%" PRIu64, detail->width)) return 0;
    if (!append(out, size, &used, "}")) return 0;
    return used;
}
/* Deepest inline-splice nesting one trap walk descends before it stops trusting
   the table and reports the frame it has. A real chain is bounded by the
   inliner's callee size budget and the trace keeps only sixteen frames, so only
   a malformed table can reach this. */
#define MYL_QBE_INLINE_DEPTH 32
/* The inline splice of `function` whose caller pc range contains `position`, or
   NULL when the pc is the function's own instruction. Splices never overlap. */
static const MylQbeInlineFrame *inline_at(const MylQbeFunction *function, uint64_t position) {
    if (!function->inlines) return NULL;
    for (uint64_t i = 0; i < function->inline_count; ++i) {
        const MylQbeInlineFrame *candidate = &function->inlines[i];
        if (position >= candidate->start && position < candidate->end) return candidate;
    }
    return NULL;
}
/* Append one logical frame when the trace has room. `logical` counts every frame
   the un-inlined call chain would have produced, so `omitted_frames` reports the
   depth the pre-inlining compiler reported. */
static void trace_emit(Context *ctx, const MylQbeFunction *function, uint64_t position, uint64_t *logical) {
    ++*logical;
    if (!function || position >= function->count || ctx->trace_count >= 16) return;
    MylQbeLocation at = function->locations[position];
    ctx->trace[ctx->trace_count++] = (MylQbeTrace){function->name, at.path, at.line, at.column};
}
/* Emit the frames one native-stack record stands for, innermost first: when the
   record's pc falls inside an inlined callee, the callee's own chain comes first
   and this function follows at the pc holding the call site. The enclosing frame
   is reported directly rather than re-entered, so a splice whose callee body
   begins at the call pc cannot loop; `depth` bounds a malformed table. */
static void trace_frame(Context *ctx, const MylQbeFunction *function, uint64_t position, unsigned depth, uint64_t *logical) {
    if (!function || position >= function->count) {
        ++*logical;
        return;
    }
    const MylQbeInlineFrame *record = depth < MYL_QBE_INLINE_DEPTH ? inline_at(function, position) : NULL;
    if (!record || !record->callee) {
        trace_emit(ctx, function, position, logical);
        return;
    }
    trace_frame(ctx, record->callee, record->callee_start + (position - record->start), depth + 1, logical);
    trace_emit(ctx, function, record->call_position, logical);
}
/* QBE-FRAMEMAP-1. A fast executable links no frame record: every guest call is
   followed by a label the build recorded in the `mylang_frame_map` section
   (`src/qbe_frame_map.zig`). A call site owns one entry per logical frame,
   innermost first, each {return address, position word, metadata} with every
   field a 32-bit offset from itself; a site LLVM inlined through other guest
   functions carries one more entry per caller, marked with the caller bit. The
   linker defines the section bounds; a program lowered under any other
   protocol has no such section, so both are null. The guard bit marks an entry
   guard's call, whose frame was never entered. */
extern const int32_t __start_mylang_frame_map[] __attribute__((weak, visibility("hidden")));
extern const int32_t __stop_mylang_frame_map[] __attribute__((weak, visibility("hidden")));
#define MYL_QBE_FRAME_MAP_GUARD UINT32_C(0x80000000)
#define MYL_QBE_FRAME_MAP_CALLER UINT32_C(0x40000000)
#define MYL_QBE_FRAME_MAP_UNWIND UINT32_C(0x20000000)
#define MYL_QBE_FRAME_MAP_POSITION UINT32_C(0x1fffffff)
/* One call site: its return address and its run of raw entries. */
typedef struct { uintptr_t ret; const int32_t *first; size_t count; } FrameSite;
/* The call sites, sorted by return address the first time a trap needs them. A
   trap is fatal and runs once per execution, so this is built at most once per
   process; if the index cannot be allocated the raw table is scanned instead. */
static FrameSite *frame_sites;
static size_t frame_site_count;
static int frame_sites_ready;
static uintptr_t entry_address(const int32_t *field) {
    return (uintptr_t)field + (uintptr_t)(intptr_t)*field;
}
static size_t raw_entry_count(void) {
    if (!__start_mylang_frame_map || !__stop_mylang_frame_map || &__stop_mylang_frame_map[0] <= &__start_mylang_frame_map[0]) return 0;
    return (size_t)(__stop_mylang_frame_map - __start_mylang_frame_map) / 3;
}
/* The call site whose entries start at raw entry `index`, and how many there are. */
static FrameSite site_from(size_t index, size_t entries) {
    const int32_t *first = __start_mylang_frame_map + 3 * index;
    size_t count = 1;
    while (index + count < entries && ((uint32_t)first[3 * count + 1] & MYL_QBE_FRAME_MAP_CALLER)) ++count;
    return (FrameSite){ .ret = entry_address(first), .first = first, .count = count };
}
static int site_order(const void *left, const void *right) {
    uintptr_t a = ((const FrameSite *)left)->ret, b = ((const FrameSite *)right)->ret;
    return a < b ? -1 : a > b;
}
static void prepare_sites(void) {
    if (frame_sites_ready) return;
    frame_sites_ready = 1;
    size_t entries = raw_entry_count();
    if (!entries || entries > SIZE_MAX / sizeof(FrameSite)) return;
    frame_sites = malloc(entries * sizeof(FrameSite));
    if (!frame_sites) return;
    size_t count = 0;
    for (size_t index = 0; index < entries;) {
        frame_sites[count] = site_from(index, entries);
        index += frame_sites[count].count;
        ++count;
    }
    qsort(frame_sites, count, sizeof(FrameSite), site_order);
    frame_site_count = count;
}
/* The call site whose label is exactly `ret`, or 0 when `ret` returns into code
   with no recorded call site (the runtime, the entry wrapper, libc). */
static int find_site(uintptr_t ret, FrameSite *found) {
    prepare_sites();
    if (frame_sites) {
        size_t low = 0, high = frame_site_count;
        while (low < high) {
            size_t middle = low + (high - low) / 2;
            if (frame_sites[middle].ret < ret) low = middle + 1;
            else high = middle;
        }
        if (low < frame_site_count && frame_sites[low].ret == ret) { *found = frame_sites[low]; return 1; }
        return 0;
    }
    size_t entries = raw_entry_count();
    for (size_t index = 0; index < entries;) {
        FrameSite site = site_from(index, entries);
        if (site.ret == ret) { *found = site; return 1; }
        index += site.count;
    }
    return 0;
}
/* Report the frames one return address stands for: every entry of its call
   site, innermost first, except an entry guard's, which names a frame whose
   prologue failed before it was entered. Returns 0 once `visit` stops. */
typedef int (*FrameVisit)(Context *, const MylQbeFunction *, uint64_t position, void *state);
static int visit_return(Context *ctx, uintptr_t ret, FrameVisit visit, void *state) {
    FrameSite site;
    if (!find_site(ret, &site)) return 1;
    for (size_t i = 0; i < site.count; ++i) {
        const int32_t *entry = site.first + 3 * i;
        uint32_t word = (uint32_t)entry[1];
        if (word & MYL_QBE_FRAME_MAP_GUARD) continue;
        const MylQbeFunction *function = (const MylQbeFunction *)entry_address(&entry[2]);
        if (!visit(ctx, function, word & MYL_QBE_FRAME_MAP_POSITION, state)) return 0;
    }
    return 1;
}
/* LLVM keeps no frame pointer in guest code; it gives every guest function
   unwind tables instead, and the executable links libunwind, whose
   `_Unwind_Backtrace` reports each frame's return address. The declaration is
   weak so a program that never links it (QBE, or no frame map) still links. */
typedef struct { Context *ctx; FrameVisit visit; void *state; int stopped; } UnwindWalk;
extern _Unwind_Reason_Code _Unwind_Backtrace(_Unwind_Trace_Fn, void *) __attribute__((weak));
extern uintptr_t _Unwind_GetIP(struct _Unwind_Context *) __attribute__((weak));
static _Unwind_Reason_Code unwind_step(struct _Unwind_Context *context, void *argument) {
    UnwindWalk *walk = argument;
    if (!visit_return(walk->ctx, _Unwind_GetIP(context), walk->visit, walk->state)) {
        walk->stopped = 1;
        return _URC_END_OF_STACK;
    }
    return _URC_NO_REASON;
}
/* Visit every guest frame on the guest stack, innermost first. A return
   address with a recorded site is a guest frame at that site's position; any
   other is runtime or entry code and is passed over.
   - An LLVM program (its table entries carry the unwind bit) is unwound by its
     call-frame information.
   - A QBE program follows the frame-pointer chain from this function's own
     frame: QBE keeps a frame pointer in every function that calls, and so does
     every runtime unit that can reach `fail`, so each frame's return address
     is at `fp + 8` and its caller's frame pointer at `fp`. The walk stays
     inside the guest-stack mapping and stops at the first link that does not
     move outward, so a frame without a pointer ends the trace early rather
     than reading anything outside it.
   `visit` returns 0 to stop the walk. */
static __attribute__((noinline)) void walk_frames(Context *ctx, FrameVisit visit, void *state) {
    uintptr_t low = ctx->native_stack_bottom, high = ctx->native_stack_top;
    if (!low || high <= low || !raw_entry_count()) return;
    if ((uint32_t)__start_mylang_frame_map[1] & MYL_QBE_FRAME_MAP_UNWIND) {
        UnwindWalk walk = { .ctx = ctx, .visit = visit, .state = state };
        if (_Unwind_Backtrace && _Unwind_GetIP) _Unwind_Backtrace(unwind_step, &walk);
        return;
    }
    uintptr_t fp = (uintptr_t)__builtin_frame_address(0);
    while (fp >= low && fp <= high - 2 * sizeof(uintptr_t) && !(fp & (sizeof(uintptr_t) - 1))) {
        const uintptr_t *slot = (const uintptr_t *)fp;
        uintptr_t next = slot[0];
        if (!visit_return(ctx, slot[1], visit, state)) return;
        if (next <= fp) return;
        fp = next;
    }
}
static int trace_visit(Context *ctx, const MylQbeFunction *function, uint64_t position, void *state) {
    trace_frame(ctx, function, position, 0, state);
    return 1;
}
static __attribute__((noinline)) uint64_t fail(void *context, const char *code) {
    Context *ctx = context;
    if (!ctx->trap) {
        ctx->trap = code;
        /* Generated frames link through `prev` in the native stack, so the trace
           is the chain from the innermost active record. Each record expands to
           the callee frames the inliner spliced into it, innermost first. Frames
           without function metadata (the direct C entry points) are skipped, and
           only the first sixteen frames are kept; `omitted_frames` reports the
           logical depth beyond them. A frame-map program links no record, so
           its frames come from the return addresses on the guest stack. */
        uint64_t logical = 0;
        for (const MylQbeActiveFrame *frame = ctx->active_frame; frame; frame = frame->prev) {
            trace_frame(ctx, frame->function, frame->position, 0, &logical);
        }
        if (!ctx->active_frame) walk_frames(ctx, trace_visit, &logical);
        ctx->omitted_frames = logical > ctx->trace_count ? logical-ctx->trace_count : 0;
        /* The trace is complete, so leave. Generated code does not test the
           sticky flag after a call; the trampoline armed this jump while the
           entry ran. A context without one (the direct C entry points and
           budget parsing) keeps the sticky behavior. */
        if (ctx->unwind) {
            /* Traps are fatal: no guest frame runs again, so an RC heap keeps
               no per-frame cleanup journal. Only the scope records on the
               departing stack are detached here; the execution tears the heap
               down after the resource registry has closed every resource
               (myl_qbe_rc_finish). */
#if (defined(MYL_NATIVE_RC) && MYL_NATIVE_RC) || defined(MYL_RC_CONTRACT_LIBRARY)
            myl_qbe_rc_trap(ctx);
#endif
            longjmp(*(jmp_buf *)ctx->unwind, 1);
        }
    }
    return 0;
}
/* Synthetic operation codes for the value-producing helpers that do not carry a
   typed.BinaryOp ordinal. Kept outside the 0..6 binary range. */
#define MYL_QBE_OPERATION_CAST UINT64_C(100)
#define MYL_QBE_OPERATION_NEG  UINT64_C(101)
/* Map the operation that was already evaluated to a stable diagnostic name. */
static const char *operation_name(uint64_t op) {
    switch (op) {
        case 0: return "add";
        case 1: return "sub";
        case 2: return "mul";
        case 3: return "div";
        case 4: return "rem";
        case 5: return "floor_div";
        case 6: return "floor_rem";
        case MYL_QBE_OPERATION_CAST: return "cast";
        case MYL_QBE_OPERATION_NEG: return "neg";
        default: return "arithmetic";
    }
}
/* Record the typed detail only for the first trap; later failures leave the
   sticky first-trap detail untouched, exactly like the trap code itself. */
static uint64_t fail_detail(void *context, const char *code, const char *operation,
                            uint32_t present, int64_t index, uint64_t length,
                            int64_t left, int64_t right, uint64_t width) {
    Context *ctx = context;
    if (!ctx->trap) ctx->trap_detail = (MylQbeTrapDetail){
        .version = MYL_QBE_TRAP_DETAIL_VERSION,
        .present = present, .index = index, .length = length,
        .left = left, .right = right, .width = width,
        .operation = operation ? operation : "operation",
    };
    return fail(context, code);
}
void myl_qbe_fail(void *context, const char *code) { fail(context, code); }
void myl_qbe_fail_equality(void *context, int status) { fail(context, status == -2 ? "CapacityLimit" : "OutOfMemory"); }
uint64_t myl_qbe_failed(void *context) {
    return ((Context *)context)->trap != NULL;
}
void *myl_qbe_argv_list(void *context, const myl_native_type *element) {
    static const myl_native_type pointer_type = { .size=sizeof(void *), .alignment=_Alignof(void *), .kind=MYL_NATIVE_POINTER };
    Context *ctx = context;
    myl_native_list *list = myl_native_list_new(&ctx->heap, element, (size_t)ctx->guest_argc);
    if (!list) { myl_qbe_fail_allocation(context); return NULL; }
    /* Keep the growing list visible across each string allocation; appending the
       old backing copies the value before growing, but a stress collection can
       still run before the list itself is rooted by the append helper. */
    myl_native_root root;
    myl_native_root_push(&ctx->heap, &root, &list, &pointer_type);
    for (int i = 0; i < ctx->guest_argc; ++i) {
        const char *argument = ctx->guest_argv[i];
        myl_native_text *text = myl_native_text_from_utf8(&ctx->heap, (const unsigned char *)argument, strlen(argument));
        int appended = text && myl_native_list_append(&ctx->heap, list, &text);
        /* Append owns its stored edge. The fresh text token stays here, and
         * failure must abandon the partial list before fail can longjmp. */
        if (myl_rc_enabled(&ctx->heap)) myl_rc_owner_release(&ctx->heap, text);
        if (!appended) {
            myl_native_root_pop(&ctx->heap, &root);
            if (myl_rc_enabled(&ctx->heap)) myl_rc_owner_release(&ctx->heap, list);
            myl_qbe_fail_allocation(context);
            return NULL;
        }
    }
    myl_native_root_pop(&ctx->heap, &root);
    return list;
}
void *myl_qbe_root_mark(void *context) { return ((Context *)context)->heap.roots; }
void myl_qbe_root_restore(void *context, void *mark) { ((Context *)context)->heap.roots = mark; }
void myl_qbe_fail_capability(void *context) { fail(context, "R_CAPABILITY"); }
void myl_qbe_fail_missing_capability(void *context, const char *flag) {
    if (flag) fprintf(stderr, "mylang: --restrict is active and this command line did not grant a capability the entry point requests; pass %s, or drop --restrict to grant every capability\n", flag);
    else fputs("mylang: --restrict is active and this command line did not grant a capability the entry point requests; pass an --allow-* flag, or drop --restrict to grant every capability\n", stderr);
    Context *ctx = context;
    ctx->reported = 1;
    fail(context, "CapabilityUnavailable");
}
void myl_qbe_fail_slice(void *context) { fail(context, "R_SLICE_BOUNDS"); }
void myl_qbe_fail_slice_step(void *context) { fail(context, "R_SLICE_STEP"); }
void myl_qbe_fail_text_bounds(void *context) { fail(context, "R_TEXT_BOUNDS"); }
void myl_qbe_fail_missing_key(void *context) { fail(context, "R_MISSING_KEY"); }
void myl_qbe_fail_empty_separator(void *context) { fail(context, "R_EMPTY_SEPARATOR"); }
void myl_qbe_fail_buffer_bounds(void *context) { fail(context, "R_BUFFER_BOUNDS"); }
void myl_qbe_fail_list_bounds(void *context) { fail(context, "R_LIST_BOUNDS"); }
void myl_qbe_fail_list_capacity(void *context) { fail(context, "R_LIST_CAPACITY"); }
void myl_qbe_fail_list_value(void *context) { fail(context, "R_LIST_VALUE"); }
void myl_qbe_fail_substring(void *context) { fail(context, "R_SUBSTRING_NOT_FOUND"); }
/* A refused managed allocation names the budget when the heap declined it and
   the host only when the process itself could not produce the bytes. */
void myl_qbe_fail_allocation(void *context) {
#if defined(MYL_NATIVE_RC) && MYL_NATIVE_RC
    Context *ctx = context;
    if (ctx->heap.rc) {
        myl_rc_status status = myl_rc_take_failure(&ctx->heap);
        if (status != MYL_RC_OK) { (void)myl_qbe_rc_status(context, status); return; }
    }
#endif
    if (myl_native_cow_take_depth_failure()) { fail(context, "R_COW_DEPTH"); return; }
    fail(context, ((Context *)context)->heap.exhausted ? memory_budget_code : "OutOfMemory");
}
void myl_qbe_fail_iteration(void *context) { fail(context, "R_LIST_ITERATION_MUTATION"); }
/* A failed assertion reports the `assert cond, "text"` message the current pc's
   function metadata carries, as the trap's `operation`, so both the human stderr
   line and the structured record name the message. A pc without a message (or a
   frame whose function metadata predates messages) keeps the bare trap. */
typedef struct { const MylQbeFunction *function; uint64_t position; } InnermostFrame;
static int innermost_visit(Context *ctx, const MylQbeFunction *function, uint64_t position, void *state) {
    (void)ctx;
    *(InnermostFrame *)state = (InnermostFrame){function, position};
    return 0;
}
/* The generated call selects the trap kind. Message bytes are always literal,
   including an assert message beginning with a contract-looking prefix. */
static void fail_assertion(void *context, const char *code) {
    Context *ctx = context;
    InnermostFrame frame = {0};
    if (ctx->active_frame) frame = (InnermostFrame){ctx->active_frame->function, ctx->active_frame->position};
    else if (!ctx->trap) walk_frames(ctx, innermost_visit, &frame);
    if (frame.function && frame.function->messages && frame.position < frame.function->count) {
        const char *message = frame.function->messages[frame.position];
        if (message && *message) {
            fail_detail(context, code, message, 0, 0, 0, 0, 0, 0);
            return;
        }
    }
    fail(context, code);
}
void myl_qbe_fail_assert(void *context) { fail_assertion(context, "R_ASSERT"); }
void myl_qbe_fail_requires(void *context) { fail_assertion(context, "R_REQUIRES"); }
void myl_qbe_fail_ensures(void *context) { fail_assertion(context, "R_ENSURES"); }
void myl_qbe_fail_invariant(void *context) { fail_assertion(context, "R_INVARIANT"); }
void myl_qbe_fail_bounds(void *context) {
    fail(context, "R_INDEX_BOUNDS");
}
void myl_qbe_fail_index_bounds(void *context, int64_t index, uint64_t length) {
    fail_detail(context, "R_LIST_BOUNDS", "index",
        MYL_QBE_TRAP_PRESENT_INDEX | MYL_QBE_TRAP_PRESENT_LENGTH, index, length, 0, 0, 0);
}
void myl_qbe_fail_normalized_index_bounds(void *context, int64_t index, uint64_t length) {
    const int64_t original = index < 0 ? index - (int64_t)length : index;
    fail_detail(context, "R_LIST_BOUNDS", "index",
        MYL_QBE_TRAP_PRESENT_INDEX | MYL_QBE_TRAP_PRESENT_LENGTH, original, length, 0, 0, 0);
}
void myl_qbe_fail_pop_bounds(void *context, uint64_t length) {
    fail_detail(context, "R_LIST_BOUNDS", "pop",
        MYL_QBE_TRAP_PRESENT_LENGTH, 0, length, 0, 0, 0);
}
void myl_qbe_fail_pop_at_bounds(void *context, int64_t index, uint64_t length) {
    fail_detail(context, "R_LIST_BOUNDS", "pop",
        MYL_QBE_TRAP_PRESENT_INDEX | MYL_QBE_TRAP_PRESENT_LENGTH, index, length, 0, 0, 0);
}
void myl_qbe_fail_text_bounds_detail(void *context, int64_t index, uint64_t length) {
    fail_detail(context, "R_TEXT_BOUNDS", "index",
        MYL_QBE_TRAP_PRESENT_INDEX | MYL_QBE_TRAP_PRESENT_LENGTH, index, length, 0, 0, 0);
}
/* PY-ARRAY-NEGATIVE-1: a fixed array's index failure is a list's, code and detail. */
void myl_qbe_fail_array_bounds(void *context, int64_t index, uint64_t length) {
    fail_detail(context, "R_LIST_BOUNDS", "index",
        MYL_QBE_TRAP_PRESENT_INDEX | MYL_QBE_TRAP_PRESENT_LENGTH, index, length, 0, 0, 0);
}
/* The present bit a generated call site's MYL_QBE_UNSIGNED_OPERANDS flag asks for. */
static uint32_t operand_sign(uint64_t flagged) {
    return (flagged & MYL_QBE_UNSIGNED_OPERANDS) ? MYL_QBE_TRAP_PRESENT_UNSIGNED : 0;
}
void myl_qbe_fail_division(void *context, uint64_t binary_op, int64_t left, int64_t right) {
    fail_detail(context, "R_DIVISION_BY_ZERO", operation_name(binary_op & ~MYL_QBE_UNSIGNED_OPERANDS),
        MYL_QBE_TRAP_PRESENT_LEFT | MYL_QBE_TRAP_PRESENT_RIGHT | operand_sign(binary_op), 0, 0, left, right, 0);
}
void myl_qbe_fail_overflow_op(void *context, uint64_t binary_op, int64_t left, int64_t right, uint64_t width) {
    fail_detail(context, "R_OVERFLOW", operation_name(binary_op),
        MYL_QBE_TRAP_PRESENT_LEFT | MYL_QBE_TRAP_PRESENT_RIGHT | MYL_QBE_TRAP_PRESENT_WIDTH | operand_sign(width),
        0, 0, left, right, width & ~MYL_QBE_UNSIGNED_OPERANDS);
}
void myl_qbe_fail_cast(void *context, int64_t value, uint64_t width) {
    fail_detail(context, "R_OVERFLOW", "cast",
        MYL_QBE_TRAP_PRESENT_LEFT | MYL_QBE_TRAP_PRESENT_WIDTH | operand_sign(width), 0, 0, value, 0,
        width & ~MYL_QBE_UNSIGNED_OPERANDS);
}
myl_native_heap *myl_qbe_heap(void *context) {
    return &((Context *)context)->heap;
}
void myl_qbe_fail_step(void *context) {
    fail(context, "R_STEP_LIMIT");
}
void myl_qbe_fail_overflow(void *context) {
    fail(context, "R_OVERFLOW");
}
void myl_qbe_fail_frame(void *context) {
    fail(context, "R_FRAME_LIMIT");
}
static Wide decode(uint64_t value, uint64_t is_signed) {
    int64_t signed_value;
    memcpy(&signed_value, &value, sizeof signed_value);
    return is_signed ? (Wide)signed_value : (Wide)value;
}
/* The present bit that makes the detail render an unsigned operation's operands unsigned. */
static uint32_t unsigned_bit(uint64_t is_signed) {
    return is_signed ? 0 : MYL_QBE_TRAP_PRESENT_UNSIGNED;
}
/* Reinterpret already-evaluated bits as the operand the diagnostic shows; an
   unsigned operand keeps its bit pattern and is flagged by `unsigned_bit`. */
static int64_t as_i64(uint64_t value, uint64_t is_signed) {
    int64_t signed_value;
    memcpy(&signed_value, &value, sizeof signed_value);
    return is_signed ? signed_value : (int64_t)value;
}
static Wide modulus(void *context, uint64_t width) {
    if (!width || width > 64) return fail(context, "R_INTERNAL");
    return (Wide)1 << width;
}
static uint64_t checked(void *context, Wide value, uint64_t is_signed, uint64_t width,
                        uint64_t operation, uint32_t present, int64_t left, int64_t right) {
    Wide mod = modulus(context, width), maximum = (mod >> !!is_signed) - 1;
    Wide minimum = is_signed ? -(mod >> 1) : 0;
    if (value < minimum || value > maximum)
        return fail_detail(context, "R_OVERFLOW", operation_name(operation),
            present | MYL_QBE_TRAP_PRESENT_WIDTH, 0, 0, left, right, width);
    return (uint64_t)value;
}
uint64_t myl_qbe_int_cast(void *context, uint64_t from_signed, uint64_t to_signed, uint64_t width, uint64_t value) {
    return checked(context, decode(value, from_signed), to_signed, width,
        MYL_QBE_OPERATION_CAST, MYL_QBE_TRAP_PRESENT_LEFT | unsigned_bit(from_signed), as_i64(value, from_signed), 0);
}
uint64_t myl_qbe_int_neg(void *context, uint64_t is_signed, uint64_t width, uint64_t value) {
    return checked(context, -decode(value, is_signed), is_signed, width,
        MYL_QBE_OPERATION_NEG, MYL_QBE_TRAP_PRESENT_LEFT | unsigned_bit(is_signed), as_i64(value, is_signed), 0);
}
uint64_t myl_qbe_int_binary(void *context, uint64_t op, uint64_t is_signed, uint64_t width, uint64_t left, uint64_t right) {
    Wide a = decode(left, is_signed), b = decode(right, is_signed), result = 0;
    Wide mod = modulus(context, width), maximum = (mod >> !!is_signed) - 1;
    Wide minimum = is_signed ? -(mod >> 1) : 0;
    UnsignedWide mask = (UnsignedWide)mod - 1, x = (UnsignedWide)a & mask, y = (UnsignedWide)b & mask, raw = 0;
    switch (op) {
        case 0: result = a + b; break;
        case 1: result = a - b; break;
        case 2:
            if (__builtin_mul_overflow(a, b, &result))
                return fail_detail(context, "R_OVERFLOW", operation_name(op),
                    MYL_QBE_TRAP_PRESENT_LEFT | MYL_QBE_TRAP_PRESENT_RIGHT | MYL_QBE_TRAP_PRESENT_WIDTH | unsigned_bit(is_signed),
                    0, 0, (int64_t)a, (int64_t)b, width);
            break;
        case 3: case 4: case 5: case 6: {
            if (!b) return fail_detail(context, "R_DIVISION_BY_ZERO", operation_name(op),
                MYL_QBE_TRAP_PRESENT_LEFT | MYL_QBE_TRAP_PRESENT_RIGHT | unsigned_bit(is_signed), 0, 0, (int64_t)a, (int64_t)b, 0);
            Wide q = a / b, r = a % b;
            if (op >= 5 && r && ((r < 0) != (b < 0))) { --q; r += b; }
            result = (op == 3 || op == 5) ? q : r;
            break;
        }
        case 7: return !!a && !!b;
        case 8: return !!a || !!b;
        case 9: return a == b;
        case 10: return a != b;
        case 11: return a < b;
        case 12: return a <= b;
        case 13: return a > b;
        case 14: return a >= b;
        case 15: raw = x & y; goto wrapping;
        case 16: raw = x | y; goto wrapping;
        case 17: raw = x ^ y; goto wrapping;
        case 18: case 19:
            if (b < 0 || b >= (Wide)width) return fail(context, "R_INVALID_SHIFT");
            if (op == 18) { raw = x << (unsigned)b; goto wrapping; }
            result = a < 0 ? -1 - ((-1 - a) / ((Wide)1 << (unsigned)b)) : a / ((Wide)1 << (unsigned)b);
            break;
        case 20: raw = x + y; goto wrapping;
        case 21: raw = x - y; goto wrapping;
        case 22: raw = x * y; goto wrapping;
        case 23: case 24: case 25:
            if (op == 23) result = a + b;
            else if (op == 24) result = a - b;
            else if (__builtin_mul_overflow(a, b, &result)) return (uint64_t)maximum;
            return (uint64_t)(result < minimum ? minimum : result > maximum ? maximum : result);
        default: return fail(context, "R_INTERNAL");
    }
    return checked(context, result, is_signed, width, op,
        MYL_QBE_TRAP_PRESENT_LEFT | MYL_QBE_TRAP_PRESENT_RIGHT | unsigned_bit(is_signed), (int64_t)a, (int64_t)b);
wrapping:
    result = (Wide)(raw & mask);
    return (uint64_t)(is_signed && result > maximum ? result - mod : result);
}
static double float_value(uint64_t bits) {
    double value;
    memcpy(&value, &bits, sizeof value);
    return value;
}
/* FLOAT-NAN-OBSERVED-1: a result keeps the bits the operation produced, NaN
   payload and sign included; a NaN is canonicalized only where its bits can be
   observed (formatting, hashing, the host and wire boundaries). */
static uint64_t float_bits(double value) {
    uint64_t bits;
    memcpy(&bits, &value, sizeof bits);
    return bits;
}
static uint64_t float_environment(void *context) {
    if (fegetround() != FE_TONEAREST) return fail(context, "R_FLOAT_ENVIRONMENT");
    volatile double normal = DBL_MIN, half = 0.5;
    volatile double tiny = float_value(1), one = 1.0;
    if (float_bits(normal * half) != UINT64_C(0x0008000000000000) || float_bits(tiny * one) != 1) return fail(context, "R_FLOAT_ENVIRONMENT");
    return 1;
}
/* QBE-FLOAT-ENV-1: the environment is verified once at context start-up (see
   execute_config_args) and again after every C FFI boundary, so the value
   helpers below no longer re-check it on each call. */
void myl_qbe_float_check(void *context) {
    (void)float_environment(context);
}
uint64_t myl_qbe_float_binary(void *context, uint64_t op, uint64_t left, uint64_t right) {
    double a = float_value(left), b = float_value(right);
    switch (op) {
        case 26: return float_bits(a + b);
        case 27: return float_bits(a - b);
        case 28: return float_bits(a * b);
        case 29: return float_bits(a / b);
        case 30: return a == b;
        case 31: return a < b;
        case 32: return a <= b;
        default: return fail(context, "R_INTERNAL");
    }
}
uint64_t myl_qbe_float_unary(void *context, uint64_t op, uint64_t input) {
    double a = float_value(input);
    switch (op) {
        case 2: return float_bits(sqrt(a));
        case 3: return float_bits(floor(a));
        case 4: return float_bits(ceil(a));
        case 5: return float_bits(trunc(a));
        case 6: return float_bits(fabs(a));
        case 7: return float_bits(-a);
        case 8: return float_bits((double)input);
        case 9:
            a = trunc(a);
            if (!isfinite(a) || a < 0 || a >= 18446744073709551616.0) return fail(context, "R_FLOAT_CONVERSION");
            return (uint64_t)a;
        case 10: return float_bits((double)decode(input, 1));
        case 11:
            a = trunc(a);
            if (!isfinite(a) || a < -9223372036854775808.0 || a >= 9223372036854775808.0) return fail(context, "R_FLOAT_CONVERSION");
            return (uint64_t)(int64_t)a;
        default: return fail(context, "R_INTERNAL");
    }
}
/* Narrow conversions have a separate, statically selected entry point so adding
   widths does not change the dispatch of existing hot binary64 operations. */
uint64_t myl_qbe_float_integer(void *context, uint64_t op, uint64_t input) {
    if (op < 12 || op > 17) return fail(context, "R_INTERNAL");
    const unsigned bits = 8u << ((op - 12) % 3);
    const int is_signed = op < 15;
    const double upper = ldexp(1.0, bits - is_signed);
    const double lower = is_signed ? -upper : 0.0;
    const double a = trunc(float_value(input));
    if (!isfinite(a) || a < lower || a >= upper) return fail(context, "R_FLOAT_CONVERSION");
    return is_signed ? (uint64_t)(int64_t)a : (uint64_t)a;
}
typedef struct NativeFrameAllocation {
    struct NativeFrameAllocation *previous, *next;
    max_align_t alignment;
} NativeFrameAllocation;
void *myl_qbe_frame_try_allocate(void *context, uint64_t bytes) {
    Context *ctx=context;
    if (bytes>SIZE_MAX-sizeof(NativeFrameAllocation)) return NULL;
    NativeFrameAllocation *allocation=calloc(1,sizeof *allocation+(size_t)bytes);
    if (!allocation) return NULL;
    allocation->next=ctx->frame_allocations;
    if (allocation->next) allocation->next->previous=allocation;
    ctx->frame_allocations=allocation;
    return allocation+1;
}
void myl_qbe_fail_frame_allocation(void *context) { fail(context, "OutOfMemory"); }
void *myl_qbe_frame_allocate(void *context, uint64_t bytes) {
    void *payload = myl_qbe_frame_try_allocate(context, bytes);
    if (!payload) myl_qbe_fail_frame_allocation(context);
    return payload;
}
void myl_qbe_frame_release(void *context, void *payload) {
    if (!payload) return;
    Context *ctx=context;
    NativeFrameAllocation *allocation=(NativeFrameAllocation *)payload-1;
    if (allocation->previous) allocation->previous->next=allocation->next;
    else ctx->frame_allocations=allocation->next;
    if (allocation->next) allocation->next->previous=allocation->previous;
    free(allocation);
}
void myl_qbe_enter(void *context) {
    Context *ctx = context;
    /* The logical ceiling is independent of the execution stack guard. A
       context with unbounded frames still tracks at most `max_frames` slots for
       trace reporting; deeper frames share one scratch slot. */
    if (ctx->frames == ctx->frame_limit) { fail(context, "R_FRAME_LIMIT"); return; }
    if (ctx->frame_data) {
        ctx->active_frame = ctx->frames < ctx->max_frames ? &ctx->frame_data[ctx->frames] : &ctx->scratch_frame;
        *ctx->active_frame = (MylQbeActiveFrame){0};
    }
    ++ctx->frames;
}
void myl_qbe_leave(void *context) {
    Context *ctx = context;
    if (!ctx->frames) { fail(context, "R_INTERNAL"); return; }
    if (ctx->active_frame) ctx->native_stack_bytes -= ctx->active_frame->native_bytes;
    --ctx->frames;
    if (!ctx->frames || !ctx->frame_data) {
        ctx->active_frame = NULL;
        return;
    }
    ctx->active_frame = ctx->frames <= ctx->max_frames ? &ctx->frame_data[ctx->frames-1] : &ctx->scratch_frame;
}
void myl_qbe_step(void *context) {
    Context *ctx = context;
    if (ctx->steps == ctx->max_steps) { fail(context, "R_STEP_LIMIT"); return; }
    ++ctx->steps;
}
/* A build that omitted instruction-budget accounting cannot honor a runtime step
   ceiling. The generated entry point calls this once, before any guest
   instruction runs, so the mismatch is reported instead of silently ignored. */
void myl_qbe_require_step_accounting(void *context) {
    Context *ctx = context;
    if (ctx->max_steps == MYL_QBE_UNBOUNDED) return;
    fail_detail(ctx, "R_NO_STEP_ACCOUNTING", "run it under `mylang run --max-steps=N`, or rebuild it with --mode Debug", 0, 0, 0, 0, 0, 0);
}
/* A build that omitted call-depth accounting cannot honor a runtime frame
   ceiling. The generated entry point calls this once, before any guest
   instruction runs, so the mismatch is reported instead of silently ignored. */
void myl_qbe_require_frame_accounting(void *context) {
    Context *ctx = context;
    if (ctx->frame_limit == MYL_QBE_UNBOUNDED) return;
    fail_detail(ctx, "R_NO_FRAME_ACCOUNTING", "run it under `mylang run --max-frames=N`, or rebuild it with --mode Debug", 0, 0, 0, 0, 0, 0);
}
void myl_qbe_enter_at_sized(void *context, const MylQbeFunction *function, uint64_t bytes) {
    Context *ctx=context;
    uint64_t limit=ctx->native_stack_limit ? ctx->native_stack_limit:1048576;
    unsigned char position;
    if (ctx->native_stack_bottom && (uintptr_t)&position<ctx->native_stack_bottom+65536) { fail(context,"R_FRAME_LIMIT");return; }
    if (bytes>limit || ctx->native_stack_bytes>limit-bytes) { fail(context,"R_FRAME_LIMIT");return; }
    myl_qbe_enter_at(context,function);
    if (!ctx->trap) {
        ctx->native_stack_bytes+=bytes;
        if (ctx->active_frame) ctx->active_frame->native_bytes=bytes;
    }
}
void myl_qbe_enter_at(void *context, const MylQbeFunction *function) {
    myl_qbe_enter(context);
    Context *ctx = context;
    if (!ctx->trap && ctx->active_frame) ctx->active_frame->function = function;
}
void myl_qbe_step_at(void *context, uint64_t position) {
    Context *ctx = context;
    if (ctx->active_frame) ctx->active_frame->position = position;
    myl_qbe_step(context);
}
/* Parse one positive decimal budget; zero reports an empty, zero, non-numeric
   or overflowing value. */
static uint64_t budget(const char *text) {
    uint64_t value = 0;
    if (!*text) return 0;
    for (; *text; ++text) {
        if (*text < '0' || *text > '9' || value > (UINT64_MAX - (unsigned)(*text - '0')) / 10) return 0;
        value = value * 10 + (unsigned)(*text - '0');
    }
    return value;
}
/* Consume one budget control spelled `prefix` plus a value into `slot`. */
static int budget_control(MylQbeControls *controls, const char *option, const char *prefix, uint64_t *slot, int *seen) {
    size_t width = strlen(prefix);
    if (strncmp(option, prefix, width)) return 0;
    uint64_t value = budget(option + width);
    if (*seen || !value) controls->error = *seen ? "RepeatedRuntimeOption" : "InvalidBudget";
    *seen = 1;
    *slot = value;
    return 1;
}
/* Consume one switch control spelled exactly `name`. */
static int switch_control(MylQbeControls *controls, const char *option, const char *name, int *slot) {
    if (strcmp(option, name)) return 0;
    if (*slot) controls->error = "RepeatedRuntimeOption";
    *slot = 1;
    return 1;
}
/* The control error an RC program reports for `--gc-stress`; compared by
   address, so it is one object rather than a string literal. */
static const char stress_needs_gc[] = "GcStressNeedsGcRuntime";
int myl_qbe_control(MylQbeControls *controls, const char *option) {
    if (budget_control(controls, option, "--max-steps=", &controls->max_steps, &controls->seen_steps)) return 1;
    if (budget_control(controls, option, "--max-frames=", &controls->max_frames, &controls->seen_frames)) return 1;
    if (budget_control(controls, option, "--timeout=", &controls->timeout, &controls->seen_timeout)) return 1;
    if (switch_control(controls, option, "--gc-stress", &controls->stress)) {
#if defined(MYL_NATIVE_RC) && MYL_NATIVE_RC
        /* RC-DEFAULT-1: a reference-counted program has no collector to stress,
           so the switch is refused rather than silently doing nothing. */
        if (!controls->error) controls->error = stress_needs_gc;
#endif
        return 1;
    }
    return switch_control(controls, option, "--print-result", &controls->print);
}
int mylang_qbe_run_options(uint64_t (*entry)(void *), int argc, char **argv) {
    MylQbeControls controls = {0};
    for (int i = 1; i < argc; ++i) {
        if (myl_qbe_control(&controls, argv[i])) continue;
        fprintf(stderr, "mylang: %s is not a runtime option\n", argv[i]);
        return 2;
    }
    return mylang_qbe_run_process(entry, &controls, 0, NULL, NULL);
}
int mylang_qbe_run_process(uint64_t (*entry)(void *), const MylQbeControls *controls, int argc, char **argv, const struct MylangNativeProvidersTag *providers) {
    /* Unbounded by default: the memory ceiling contains a runaway allocation,
       and --timeout=SECONDS is the elapsed-time guard. */
    if (controls->error == stress_needs_gc) {
        fputs("mylang: --gc-stress needs a program built with --gc-runtime; this one uses reference counting\n", stderr);
        return 2;
    }
    if (controls->error) {
        fprintf(stderr, "%s: QBE runtime failure\n", controls->error);
        return 2;
    }
    uint64_t steps = controls->seen_steps ? controls->max_steps : MYL_QBE_UNBOUNDED;
    uint64_t frames = controls->seen_frames ? controls->max_frames : MYL_QBE_UNBOUNDED;
    if (!arm_timeout(controls->timeout)) {
        fputs("mylang: cannot arm the --timeout wall-clock guard\n", stderr);
        return 2;
    }
    /* The guest receives its arguments exactly as the process was given them:
       no runtime option is read from them, so `--gc-stress` or `--` is data. */
    for (int i = 0; i < argc; ++i) {
        if (!myl_native_text_valid_utf8((const unsigned char *)argv[i], strlen(argv[i]))) {
            fprintf(stderr, "mylang: guest argument is not valid UTF-8\n");
            return 2;
        }
    }
    MylQbeResult result;
    if (execute_config_args(entry, steps, frames, controls->stress, providers, NULL, argc, argv, &result)) {
        if (result.reported) return 2;
        char suffix[1024] = "";
        (void)detail_text(&result.trap_detail, suffix, sizeof suffix);
        /* A broken precondition is the caller's fault: name the call site,
           which is the next frame out, beside the clause. */
        if (!strcmp(result.code, "R_REQUIRES") && result.trace_count > 1) {
            size_t used = strlen(suffix);
            const MylQbeTrace *caller = &result.trace[1];
            (void)append(suffix, sizeof suffix, &used, "; broken by the caller %s at %s:%" PRIu64 ":%" PRIu64, caller->function, caller->path, caller->line, caller->column);
        }
        if (result.trace_count) {
            const MylQbeTrace *at=&result.trace[0];
            fprintf(stderr,"%s:%" PRIu64 ":%" PRIu64 ": error[%s]: %s%s\n",at->path,at->line,at->column,result.code,describe(result.code),suffix);
        } else fprintf(stderr, "%s: %s%s\n", result.code, describe(result.code), suffix);
        for (uint64_t i=0; i<result.trace_count; ++i) {
            MylQbeTrace frame = result.trace[i];
            fprintf(stderr, "  in %s at %s:%" PRIu64 ":%" PRIu64 "\n", frame.function, frame.path, frame.line, frame.column);
        }
        char record[1536];
        if (detail_json(&result.trap_detail, record, sizeof record) != 0)
            fprintf(stderr, "%s%s\n", MYL_QBE_TRAP_RECORD_MARKER, record);
        return strncmp(result.code,"R_",2) ? 2:1;
    }
    /* The entry point's integer result becomes the process exit status, the way
       a Python or Go program returns an exit code, truncated to the low 8 bits
       (POSIX `waitpid` semantics: status = value & 0xFF). `--print-result` is now
       orthogonal: it still prints the full value to stdout when asked, but the
       status reflects the value whether or not it was printed. A trap outranks the
       status and returns 1 above, because the program never reached its return. */
    int64_t value;
    memcpy(&value, &result.value, sizeof value);
    if (controls->print) printf("%" PRId64 "\n", value);
    return (int)((uint64_t)value & 0xFF);
}
int mylang_qbe_execute(uint64_t (*entry)(void *), uint64_t steps, uint64_t frames, MylQbeResult *result) {
    return mylang_qbe_execute_gc(entry, steps, frames, 0, result);
}
int mylang_qbe_execute_gc(uint64_t (*entry)(void *), uint64_t steps, uint64_t frames, int stress, MylQbeResult *result) {
    return mylang_qbe_execute_providers(entry, steps, frames, stress, NULL, result);
}
int mylang_qbe_execute_providers(uint64_t (*entry)(void *), uint64_t steps, uint64_t frames, int stress, const struct MylangNativeProvidersTag *providers, MylQbeResult *result) {
    return mylang_qbe_execute_config(entry,steps,frames,stress,providers,NULL,result);
}
static int execute_config_args(uint64_t (*entry)(void *), uint64_t steps, uint64_t frames, int stress, const struct MylangNativeProvidersTag *providers, void (*initialize)(void *), int guest_argc, char **guest_argv, MylQbeResult *result) {
    *result=(MylQbeResult){0};
    if (!steps || !frames) { result->code="InvalidBudget";return 1; }
    /* Unbounded frames still need a bounded native stack and trace buffer, so the
       logical ceiling and the slot capacity are separate values. */
    uint64_t capacity = frames == MYL_QBE_UNBOUNDED ? MYL_QBE_FRAME_CAPACITY : frames;
    if (capacity>SIZE_MAX/sizeof(MylQbeActiveFrame)) { result->code="OutOfMemory";return 1; }
    /* Read the ceiling and arm the kernel backstop before the first allocation,
       so a runtime defect cannot outgrow the budget the heap will enforce. */
    int budgeted=1;
    size_t budget=myl_native_budget_environment(&budgeted);
    if (!budgeted) { result->code="InvalidMemoryLimit";return 1; }
    myl_native_budget_guard(budget);
    Context *context=calloc(1,sizeof *context);
    if (!context) { result->code="OutOfMemory";return 1; }
    context->max_steps=steps;context->max_frames=capacity;context->frame_limit=frames;context->providers=providers;
    context->guest_argc=guest_argc;context->guest_argv=guest_argv;
    myl_native_heap_init(&context->heap, budget ? budget : SIZE_MAX);
    context->heap.stress = stress;
#if defined(MYL_NATIVE_RC) && MYL_NATIVE_RC
    (void)myl_qbe_rc_initialize(context);
#endif
    if (!context->trap) context->frame_data = calloc((size_t)capacity, sizeof(MylQbeActiveFrame));
    if (!context->trap && !context->frame_data) context->trap = "OutOfMemory";
    /* QBE-FLOAT-ENV-1: verify the process floating-point environment exactly
       once, before any guest or host code runs. The per-operation checks are
       gone, so this is what preserves R_FLOAT_ENVIRONMENT for a process that
       starts with a non-default rounding mode; a C FFI call re-checks after it
       returns (see qbe_c_abi.zig). The probe costs one fegetround plus two
       multiplies, so a build that never uses floats only pays it once. */
    if (!context->trap) (void)float_environment(context);
    if (!context->trap && initialize) initialize(context);
    if (!context->trap) result->value = myl_qbe_on_stack(entry,context);
    if (!context->trap && context->frames != 0) context->trap = "R_INTERNAL";
    result->steps = context->steps;
    result->code = context->trap;
    result->trace_count = context->trace_count;
    result->omitted_frames = context->omitted_frames;
    result->reported = context->reported;
    result->trap_detail = context->trap_detail;
    memcpy(result->trace, context->trace, sizeof result->trace);
    if (context->adapter_cleanup) context->adapter_cleanup(context);
    if (context->cleanup) context->cleanup(context);
    /* Stand-ins go after the resources, whose handles they may still own. */
    if (context->stand_in_cleanup) context->stand_in_cleanup(context);
#if defined(MYL_NATIVE_RC) && MYL_NATIVE_RC
    /* RC-EXIT-SKIP-1: a clean production exit leaves the caches and arenas to the process. */
    if (context->trap || !myl_qbe_exit_skip(context)) myl_qbe_rc_finish(context);
#endif
#if defined(MYL_NATIVE_RC_COUNTING) && MYL_NATIVE_RC_COUNTING
    myl_rc_stats_report(&context->heap);
#endif
#if defined(MYL_NATIVE_RC_SITES) && MYL_NATIVE_RC_SITES
    myl_qbe_rc_sites_report();
#endif
    while (context->frame_allocations) myl_qbe_frame_release(context,(NativeFrameAllocation *)context->frame_allocations+1);
    free(context->host_state);
    free(context->frame_data);
    if (!exit_without_sweep) myl_native_heap_destroy(&context->heap);
    int failed=context->trap != NULL;
    free(context);
    return failed;
}
int mylang_qbe_execute_config(uint64_t (*entry)(void *), uint64_t steps, uint64_t frames, int stress, const struct MylangNativeProvidersTag *providers, void (*initialize)(void *), MylQbeResult *result) {
    return execute_config_args(entry,steps,frames,stress,providers,initialize,0,NULL,result);
}
int mylang_qbe_run(uint64_t (*entry)(void *)) {
    return mylang_qbe_run_options(entry, 0, NULL);
}
/* ERROR-TRACE-1: the process-wide error return trace, written only on error
   paths, through the two recorders below: a new `Err` value restarts it and
   every later return or `?` that passes an `Err` on appends one site. Both are
   cold and never inlined, so an error branch stays one call wherever an
   optimizer weighs the code around it. Each has a `preserve_most` twin for
   LLVM-translated callers (ERROR-TRACE-6) that runs the same body. */
MylQbeErrorTrace myl_qbe_error_trace;
static inline __attribute__((always_inline)) void error_trace_record_origin(const MylQbeFunction *function, uint64_t site) {
    myl_qbe_error_trace.origin = (MylQbeErrorSite){ function, site };
    myl_qbe_error_trace.count = 0;
}
static inline __attribute__((always_inline)) void error_trace_record_append(const MylQbeFunction *function, uint64_t site) {
    uint64_t index = myl_qbe_error_trace.count++;
    myl_qbe_error_trace.ring[index % MYL_QBE_ERROR_TRACE_RING] = (MylQbeErrorSite){ function, site };
}
__attribute__((cold, noinline)) void myl_qbe_error_trace_origin(const MylQbeFunction *function, uint64_t site) {
    error_trace_record_origin(function, site);
}
__attribute__((cold, noinline)) void myl_qbe_error_trace_append(const MylQbeFunction *function, uint64_t site) {
    error_trace_record_append(function, site);
}
#if defined(__clang__) && defined(__x86_64__)
__attribute__((cold, noinline, preserve_most)) void myl_qbe_error_trace_origin_preserve_most(const MylQbeFunction *function, uint64_t site) {
    error_trace_record_origin(function, site);
}
__attribute__((cold, noinline, preserve_most)) void myl_qbe_error_trace_append_preserve_most(const MylQbeFunction *function, uint64_t site) {
    error_trace_record_append(function, site);
}
#endif
/* What one trace line says happened at its site; indexed by the site's kind. */
static const char *const error_trace_actions[] = {
    "Err(...) created", "Err produced by the runtime", "returned", "? propagated", "? converted to ",
};
/* One site resolved to the innermost function whose code it is: a site inside
   a splice the inliner made reports the callee at its own pc. */
typedef struct { const MylQbeFunction *function; uint64_t position; } ErrorTraceAt;
static ErrorTraceAt error_trace_at(MylQbeErrorSite site) {
    ErrorTraceAt at = { site.function, site.site & UINT64_C(0xffffffff) };
    for (unsigned depth = 0; at.function && depth < MYL_QBE_INLINE_DEPTH; ++depth) {
        const MylQbeInlineFrame *record = inline_at(at.function, at.position);
        if (!record || !record->callee) break;
        at = (ErrorTraceAt){ record->callee, record->callee_start + (at.position - record->start) };
    }
    return at;
}
/* The `path:line:column` of one site into `out`, or "?" when the tables lack it. */
static void error_trace_where(MylQbeErrorSite site, char *out, size_t size) {
    ErrorTraceAt at = error_trace_at(site);
    if (!at.function || at.position >= at.function->count) { snprintf(out, size, "?"); return; }
    MylQbeLocation where = at.function->locations[at.position];
    snprintf(out, size, "%s:%" PRIu64 ":%" PRIu64, where.path, where.line, where.column);
}
static const char *error_trace_function(MylQbeErrorSite site) {
    ErrorTraceAt at = error_trace_at(site);
    return at.function && at.function->name ? at.function->name : "?";
}
/* The union case a converting `?` wrapped its error in, which the compiler
   keeps in the site's message slot; "" for every other kind. */
static const char *error_trace_case(MylQbeErrorSite site) {
    if ((site.site >> 32) != MYL_QBE_ERROR_CONVERTED || !site.function) return "";
    uint64_t position = site.site & UINT64_C(0xffffffff);
    if (!site.function->messages || position >= site.function->count) return "";
    return site.function->messages[position];
}
/* ERROR-TRACE-2: a `returned` site on the line of the site before it, in the
   same function, says nothing new (`return Err(...)` in a function whose
   `@ensures` holds the value first, or `return Ok(v) if c else Err(e)`), so
   the report folds it into that line. */
static int error_trace_folds(MylQbeErrorSite previous, MylQbeErrorSite site) {
    if ((site.site >> 32) != MYL_QBE_ERROR_RETURNED) return 0;
    ErrorTraceAt before = error_trace_at(previous), at = error_trace_at(site);
    if (!at.function || at.function != before.function) return 0;
    if (at.position >= at.function->count || before.position >= before.function->count) return 0;
    return at.function->locations[at.position].line == before.function->locations[before.position].line;
}
/* The sites a report lists, oldest first: the origin when one was recorded,
   then the ring's surviving appends. `dropped` counts the appends the ring
   overwrote. */
typedef struct { MylQbeErrorSite sites[1 + MYL_QBE_ERROR_TRACE_RING]; size_t count, gap; uint64_t dropped; } ErrorTraceSites;
static ErrorTraceSites error_trace_sites(void) {
    ErrorTraceSites out = { .count = 0, .gap = 0, .dropped = 0 };
    const MylQbeErrorTrace *trace = &myl_qbe_error_trace;
    if (trace->origin.function) out.sites[out.count++] = trace->origin;
    out.gap = out.count;
    uint64_t kept = trace->count < MYL_QBE_ERROR_TRACE_RING ? trace->count : MYL_QBE_ERROR_TRACE_RING;
    out.dropped = trace->count - kept;
    for (uint64_t index = trace->count - kept; index < trace->count; ++index) {
        MylQbeErrorSite site = trace->ring[index % MYL_QBE_ERROR_TRACE_RING];
        if (out.count && error_trace_folds(out.sites[out.count - 1], site)) continue;
        out.sites[out.count++] = site;
    }
    return out;
}
/* Append one rendered line to `out` when it fits; `used` counts every byte, so
   a measuring call with no buffer learns the size it needs. */
static void error_trace_append(char *out, size_t size, size_t *used, const char *line, int length) {
    if (length <= 0) return;
    if (*used + (size_t)length < size) memcpy(out + *used, line, (size_t)length);
    *used += (size_t)length;
}
size_t myl_qbe_error_trace_render(char *out, size_t size) {
    ErrorTraceSites listed = error_trace_sites();
    char where[4096];
    int width = 0, name_width = 0;
    for (size_t i = 0; i < listed.count; ++i) {
        error_trace_where(listed.sites[i], where, sizeof where);
        int length = (int)strlen(where), name = (int)strlen(error_trace_function(listed.sites[i]));
        if (length > width) width = length;
        if (name > name_width) name_width = name;
    }
    size_t used = 0;
    char line[8192];
    for (size_t i = 0; i <= listed.count; ++i) {
        /* The overwritten appends sat between the origin and the ring's oldest survivor. */
        if (i == listed.gap && listed.dropped) {
            int length = snprintf(line, sizeof line, "  ... %" PRIu64 " more %s dropped ...\n", listed.dropped, listed.dropped == 1 ? "entry" : "entries");
            error_trace_append(out, size, &used, line, length);
        }
        if (i == listed.count) break;
        MylQbeErrorSite site = listed.sites[i];
        uint64_t kind = site.site >> 32;
        if (kind > MYL_QBE_ERROR_CONVERTED) kind = MYL_QBE_ERROR_RETURNED;
        error_trace_where(site, where, sizeof where);
        int length = snprintf(line, sizeof line, "  %-*s  %-*s  %s%s\n", width, where, name_width, error_trace_function(site), error_trace_actions[kind], error_trace_case(site));
        if (length >= (int)sizeof line) length = (int)sizeof line - 1;
        error_trace_append(out, size, &used, line, length);
    }
    if (size) out[used < size ? used : size - 1] = 0;
    return used;
}
void myl_qbe_error_trace_write(FILE *stream) {
    size_t needed = myl_qbe_error_trace_render(NULL, 0);
    if (!needed) return;
    char *text = malloc(needed + 1);
    if (!text) return;
    myl_qbe_error_trace_render(text, needed + 1);
    fwrite(text, 1, needed, stream);
    fflush(stream);
    free(text);
}
