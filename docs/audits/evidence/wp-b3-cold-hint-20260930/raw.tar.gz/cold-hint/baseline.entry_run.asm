
/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-cold-hint-20260930/.tmp/cold-hint/baseline.raytrace.llvm:     file format elf64-x86-64


Disassembly of section .text:

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
