
/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-cold-hint-20260930/.tmp/cold-hint/raytrace.llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000100f630 <_start>:
 100f630:	endbr64
 100f634:	xor    %ebp,%ebp
 100f636:	mov    %rdx,%r9
 100f639:	pop    %rsi
 100f63a:	mov    %rsp,%rdx
 100f63d:	and    $0xfffffffffffffff0,%rsp
 100f641:	push   %rax
 100f642:	push   %rsp
 100f643:	xor    %r8d,%r8d
 100f646:	xor    %ecx,%ecx
 100f648:	lea    0x91(%rip),%rdi        # 100f6e0 <main>
 100f64f:	call   *0x19533(%rip)        # 1028b88 <__libc_start_main@GLIBC_2.34>
 100f655:	hlt
 100f656:	cs nopw 0x0(%rax,%rax,1)

000000000100f660 <_dl_relocate_static_pie>:
 100f660:	endbr64
 100f664:	ret
 100f665:	int3
 100f666:	int3
 100f667:	int3
 100f668:	int3
 100f669:	int3
 100f66a:	int3
 100f66b:	int3
 100f66c:	int3
 100f66d:	int3
 100f66e:	int3
 100f66f:	int3

000000000100f670 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>:
 100f670:	mov    (%rsi),%rax
 100f673:	movq   $0x0,(%rsi)
 100f67a:	test   %rax,%rax
 100f67d:	je     100f68f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x1f>
 100f67f:	movabs $0x4000000000000002,%rcx
 100f689:	test   %rcx,-0x10(%rax)
 100f68d:	je     100f697 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x27>
 100f68f:	movq   $0x0,(%rsi)
 100f696:	ret
 100f697:	mov    -0x20(%rax),%rcx
 100f69b:	cmp    $0x1,%rcx
 100f69f:	jne    100f6a8 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x38>
 100f6a1:	cmpq   $0x0,-0x18(%rax)
 100f6a6:	je     100f6b7 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x47>
 100f6a8:	dec    %rcx
 100f6ab:	mov    %rcx,-0x20(%rax)
 100f6af:	movq   $0x0,(%rsi)
 100f6b6:	ret
 100f6b7:	push   %rbp
 100f6b8:	mov    %rsp,%rbp
 100f6bb:	push   %r14
 100f6bd:	push   %rbx
 100f6be:	mov    %rdi,%rbx
 100f6c1:	mov    %rsi,%r14
 100f6c4:	mov    %rax,%rsi
 100f6c7:	call   1018bc0 <myl_rc_edge_release>
 100f6cc:	movq   $0x0,(%r14)
 100f6d3:	mov    %rbx,%rdi
 100f6d6:	pop    %rbx
 100f6d7:	pop    %r14
 100f6d9:	pop    %rbp
 100f6da:	jmp    101bcb0 <myl_rc_drain>
 100f6df:	int3

000000000100f6e0 <main>:
 100f6e0:	push   %rbp
 100f6e1:	mov    %rsp,%rbp
 100f6e4:	push   %r15
 100f6e6:	push   %r14
 100f6e8:	push   %r13
 100f6ea:	push   %r12
 100f6ec:	push   %rbx
 100f6ed:	sub    $0x3778,%rsp
 100f6f4:	mov    %rsi,%r14
 100f6f7:	mov    %edi,-0x94(%rbp)
 100f6fd:	movb   $0x1,0x1c0ac(%rip)        # 102b7b0 <exit_without_sweep>
 100f704:	lea    -0x3790(%rbp),%r12
 100f70b:	mov    $0x29a0,%edx
 100f710:	mov    %r12,%rdi
 100f713:	xor    %esi,%esi
 100f715:	call   10274d0 <memset@plt>
 100f71a:	mov    $0x180,%eax
 100f71f:	nop
 100f720:	movl   $0xffffffff,-0x38a8(%rbp,%rax,1)
 100f72b:	movl   $0xffffffff,-0x3880(%rbp,%rax,1)
 100f736:	movl   $0xffffffff,-0x3858(%rbp,%rax,1)
 100f741:	movl   $0xffffffff,-0x3830(%rbp,%rax,1)
 100f74c:	movl   $0xffffffff,-0x3808(%rbp,%rax,1)
 100f757:	movl   $0xffffffff,-0x37e0(%rbp,%rax,1)
 100f762:	movl   $0xffffffff,-0x37b8(%rbp,%rax,1)
 100f76d:	movl   $0xffffffff,-0x3790(%rbp,%rax,1)
 100f778:	add    $0x140,%rax
 100f77e:	cmp    $0x2980,%rax
 100f784:	jne    100f720 <main+0x40>
 100f786:	movq   $0x1004f8b,-0xe00(%rbp)
 100f791:	mov    $0x1004371,%edi
 100f796:	call   10274e0 <getenv@plt>
 100f79b:	test   %rax,%rax
 100f79e:	mov    %r14,-0xa0(%rbp)
 100f7a5:	je     100f97d <main+0x29d>
 100f7ab:	mov    %rax,%r15
 100f7ae:	cmpb   $0x0,(%rax)
 100f7b1:	je     100f97d <main+0x29d>
 100f7b7:	mov    %r15,%rdi
 100f7ba:	call   10274f0 <strlen@plt>
 100f7bf:	mov    %rax,%rbx
 100f7c2:	lea    0x1(%rax),%r12
 100f7c6:	mov    %r12,%rdi
 100f7c9:	call   1027500 <malloc@plt>
 100f7ce:	mov    %rax,%r14
 100f7d1:	shr    $1,%rbx
 100f7d4:	inc    %rbx
 100f7d7:	mov    $0x8,%esi
 100f7dc:	mov    %rbx,%rdi
 100f7df:	call   1027510 <calloc@plt>
 100f7e4:	test   %r14,%r14
 100f7e7:	mov    %r14,-0x90(%rbp)
 100f7ee:	je     10115ad <main+0x1ecd>
 100f7f4:	test   %rax,%rax
 100f7f7:	je     10115ad <main+0x1ecd>
 100f7fd:	mov    %rax,-0x78(%rbp)
 100f801:	mov    %r14,%rdi
 100f804:	mov    %r15,%rsi
 100f807:	mov    %r12,%rdx
 100f80a:	call   1027520 <memcpy@plt>
 100f80f:	mov    -0x90(%rbp),%rdi
 100f816:	movzbl (%rdi),%esi
 100f819:	mov    $0x1,%r14b
 100f81c:	movq   $0xffffffffffffffff,-0x30(%rbp)
 100f824:	test   %sil,%sil
 100f827:	je     10101d0 <main+0xaf0>
 100f82d:	xor    %r12d,%r12d
 100f830:	movabs $0x100002600,%rax
 100f83a:	mov    %rdi,%rcx
 100f83d:	mov    %rdi,%rdx
 100f840:	cmp    $0x20,%sil
 100f844:	ja     100f879 <main+0x199>
 100f846:	cs nopw 0x0(%rax,%rax,1)
 100f850:	movzbl %sil,%esi
 100f854:	bt     %rsi,%rax
 100f858:	jae    100f870 <main+0x190>
 100f85a:	movzbl 0x1(%rdx),%esi
 100f85e:	inc    %rdx
 100f861:	cmp    $0x20,%sil
 100f865:	jbe    100f850 <main+0x170>
 100f867:	jmp    100f879 <main+0x199>
 100f869:	nopl   0x0(%rax)
 100f870:	test   %rsi,%rsi
 100f873:	je     100f929 <main+0x249>
 100f879:	mov    -0x78(%rbp),%rsi
 100f87d:	mov    %rcx,(%rsi,%r12,8)
 100f881:	movzbl (%rdx),%edi
 100f884:	test   %dil,%dil
 100f887:	je     100f906 <main+0x226>
 100f889:	xor    %esi,%esi
 100f88b:	jmp    100f89f <main+0x1bf>
 100f88d:	nopl   (%rax)
 100f890:	xor    $0x1,%esi
 100f893:	movzbl 0x1(%rdx),%edi
 100f897:	inc    %rdx
 100f89a:	test   %dil,%dil
 100f89d:	je     100f8fe <main+0x21e>
 100f89f:	movzbl %dil,%r8d
 100f8a3:	test   %esi,%esi
 100f8a5:	je     100f8c0 <main+0x1e0>
 100f8a7:	cmp    $0x5c,%dil
 100f8ab:	je     100f8e0 <main+0x200>
 100f8ad:	cmp    $0x22,%r8d
 100f8b1:	je     100f890 <main+0x1b0>
 100f8b3:	jmp    100f8ec <main+0x20c>
 100f8b5:	data16 cs nopw 0x0(%rax,%rax,1)
 100f8c0:	cmp    $0x22,%dil
 100f8c4:	ja     100f8ec <main+0x20c>
 100f8c6:	cmp    $0x22,%r8
 100f8ca:	je     100f890 <main+0x1b0>
 100f8cc:	bt     %r8,%rax
 100f8d0:	jae    100f8ec <main+0x20c>
 100f8d2:	jmp    100f90a <main+0x22a>
 100f8d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f8e0:	cmpb   $0x0,0x1(%rdx)
 100f8e4:	je     100f8e9 <main+0x209>
 100f8e6:	inc    %rdx
 100f8e9:	movzbl (%rdx),%edi
 100f8ec:	mov    %dil,(%rcx)
 100f8ef:	inc    %rcx
 100f8f2:	movzbl 0x1(%rdx),%edi
 100f8f6:	inc    %rdx
 100f8f9:	test   %dil,%dil
 100f8fc:	jne    100f89f <main+0x1bf>
 100f8fe:	test   %esi,%esi
 100f900:	jne    1011741 <main+0x2061>
 100f906:	xor    %esi,%esi
 100f908:	jmp    100f90f <main+0x22f>
 100f90a:	mov    $0x1,%esi
 100f90f:	inc    %r12
 100f912:	lea    (%rdx,%rsi,1),%rdi
 100f916:	movb   $0x0,(%rcx)
 100f919:	inc    %rcx
 100f91c:	movzbl (%rdx,%rsi,1),%esi
 100f920:	test   %sil,%sil
 100f923:	jne    100f83d <main+0x15d>
 100f929:	test   %r12d,%r12d
 100f92c:	js     1011741 <main+0x2061>
 100f932:	je     10101d0 <main+0xaf0>
 100f938:	and    $0x7fffffff,%r12d
 100f93f:	xor    %r13d,%r13d
 100f942:	xor    %edi,%edi
 100f944:	xor    %esi,%esi
 100f946:	movl   $0x0,-0x44(%rbp)
 100f94d:	movl   $0x0,-0x6c(%rbp)
 100f954:	movl   $0x0,-0x7c(%rbp)
 100f95b:	movl   $0x0,-0x5c(%rbp)
 100f962:	movl   $0x0,-0x80(%rbp)
 100f969:	xor    %ebx,%ebx
 100f96b:	xor    %ecx,%ecx
 100f96d:	mov    -0x78(%rbp),%r14
 100f971:	mov    %r12,-0x88(%rbp)
 100f978:	jmp    100fab8 <main+0x3d8>
 100f97d:	vpxor  %xmm0,%xmm0,%xmm0
 100f981:	vmovdqu %ymm0,-0xc8(%rbp)
 100f989:	vmovdqu %ymm0,-0xe0(%rbp)
 100f991:	vmovdqu %ymm0,-0x100(%rbp)
 100f999:	vmovdqu %ymm0,-0x120(%rbp)
 100f9a1:	vmovdqu %ymm0,-0x140(%rbp)
 100f9a9:	vmovdqu %ymm0,-0x160(%rbp)
 100f9b1:	vmovdqu %ymm0,-0x180(%rbp)
 100f9b9:	movq   $0xffffffffffffffff,-0x40(%rbp)
 100f9c1:	xor    %eax,%eax
 100f9c3:	movb   $0x1,-0x44(%rbp)
 100f9c7:	movq   $0x0,-0x58(%rbp)
 100f9cf:	movl   $0x0,-0x5c(%rbp)
 100f9d6:	movq   $0xffffffffffffffff,-0x30(%rbp)
 100f9de:	xor    %r13d,%r13d
 100f9e1:	mov    %rax,-0x90(%rbp)
 100f9e8:	mov    -0x3730(%rbp),%rbx
 100f9ef:	cmp    $0x7,%rbx
 100f9f3:	ja     1011710 <main+0x2030>
 100f9f9:	mov    $0x1004662,%edi
 100f9fe:	mov    $0x90000,%esi
 100fa03:	xor    %eax,%eax
 100fa05:	vzeroupper
 100fa08:	call   1027530 <open@plt>
 100fa0d:	test   %eax,%eax
 100fa0f:	js     1011710 <main+0x2030>
 100fa15:	lea    0x1(%rbx),%rcx
 100fa19:	mov    %rcx,-0x3730(%rbp)
 100fa20:	lea    (%rbx,%rbx,2),%rcx
 100fa24:	mov    %eax,-0x3790(%rbp,%rcx,4)
 100fa2b:	movabs $0x100000001,%rax
 100fa35:	mov    %rax,-0x378c(%rbp,%rcx,4)
 100fa3d:	cmpl   $0x0,-0xe0c(%rbp)
 100fa44:	sete   %al
 100fa47:	je     101036d <main+0xc8d>
 100fa4d:	mov    -0xe20(%rbp),%rdx
 100fa54:	mov    $0x5,%ecx
 100fa59:	test   %rdx,%rdx
 100fa5c:	je     1010372 <main+0xc92>
 100fa62:	lea    -0xe98(%rbp),%rsi
 100fa69:	nopl   0x0(%rax)
 100fa70:	cmpl   $0x0,(%rsi)
 100fa73:	jne    101036d <main+0xc8d>
 100fa79:	add    $0x10,%rsi
 100fa7d:	dec    %rdx
 100fa80:	jne    100fa70 <main+0x390>
 100fa82:	jmp    1010372 <main+0xc92>
 100fa87:	movl   $0x1,-0xe0c(%rbp)
 100fa91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100faa0:	mov    -0x30(%rbp),%rsi
 100faa4:	mov    -0x40(%rbp),%rdi
 100faa8:	mov    -0x38(%rbp),%rcx
 100faac:	inc    %rcx
 100faaf:	cmp    %r12,%rcx
 100fab2:	je     10101ec <main+0xb0c>
 100fab8:	mov    %rdi,-0x40(%rbp)
 100fabc:	mov    %rsi,-0x30(%rbp)
 100fac0:	mov    %rcx,-0x38(%rbp)
 100fac4:	mov    (%r14,%rcx,8),%r15
 100fac8:	mov    $0x1003d0c,%esi
 100facd:	mov    %r15,%rdi
 100fad0:	call   1027540 <strcmp@plt>
 100fad5:	test   %eax,%eax
 100fad7:	je     100fbe0 <main+0x500>
 100fadd:	mov    $0x10044ff,%esi
 100fae2:	mov    $0xd,%edx
 100fae7:	mov    %r15,%rdi
 100faea:	call   1027550 <strncmp@plt>
 100faef:	test   %eax,%eax
 100faf1:	je     100fc00 <main+0x520>
 100faf7:	mov    $0x10044f0,%esi
 100fafc:	mov    $0xe,%edx
 100fb01:	mov    %r15,%rdi
 100fb04:	call   1027550 <strncmp@plt>
 100fb09:	test   %eax,%eax
 100fb0b:	je     100fc65 <main+0x585>
 100fb11:	mov    $0x10044c3,%esi
 100fb16:	mov    $0x11,%edx
 100fb1b:	mov    %r15,%rdi
 100fb1e:	call   1027550 <strncmp@plt>
 100fb23:	test   %eax,%eax
 100fb25:	je     100fcdf <main+0x5ff>
 100fb2b:	mov    $0x1003f05,%esi
 100fb30:	mov    %r15,%rdi
 100fb33:	call   1027540 <strcmp@plt>
 100fb38:	test   %eax,%eax
 100fb3a:	je     100fd1b <main+0x63b>
 100fb40:	mov    $0x1003cc6,%esi
 100fb45:	mov    %r15,%rdi
 100fb48:	call   1027540 <strcmp@plt>
 100fb4d:	test   %eax,%eax
 100fb4f:	je     100fd6e <main+0x68e>
 100fb55:	mov    $0x1003ee6,%esi
 100fb5a:	mov    $0xe,%edx
 100fb5f:	mov    %r15,%rdi
 100fb62:	call   1027550 <strncmp@plt>
 100fb67:	test   %eax,%eax
 100fb69:	je     1010035 <main+0x955>
 100fb6f:	mov    $0x1003c2f,%esi
 100fb74:	mov    $0xb,%edx
 100fb79:	mov    %r15,%rdi
 100fb7c:	call   1027550 <strncmp@plt>
 100fb81:	test   %eax,%eax
 100fb83:	je     101006c <main+0x98c>
 100fb89:	mov    $0x1003ef9,%esi
 100fb8e:	mov    %r15,%rdi
 100fb91:	call   1027540 <strcmp@plt>
 100fb96:	test   %eax,%eax
 100fb98:	je     10100a3 <main+0x9c3>
 100fb9e:	mov    $0x1004664,%esi
 100fba3:	mov    $0x8,%edx
 100fba8:	mov    %r15,%rdi
 100fbab:	call   1027550 <strncmp@plt>
 100fbb0:	test   %eax,%eax
 100fbb2:	je     100fd80 <main+0x6a0>
 100fbb8:	mov    $0x1003d0c,%esi
 100fbbd:	mov    $0xa,%edx
 100fbc2:	mov    %r15,%rdi
 100fbc5:	call   1027550 <strncmp@plt>
 100fbca:	test   %eax,%eax
 100fbcc:	setne  %cl
 100fbcf:	mov    %ecx,%eax
 100fbd1:	jmp    100fd84 <main+0x6a4>
 100fbd6:	cs nopw 0x0(%rax,%rax,1)
 100fbe0:	cmpl   $0x0,-0xe0c(%rbp)
 100fbe7:	jne    100fd80 <main+0x6a0>
 100fbed:	jmp    100fa87 <main+0x3a7>
 100fbf2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100fc00:	cmpb   $0x0,0xd(%r15)
 100fc05:	je     100fd80 <main+0x6a0>
 100fc0b:	mov    %rbx,-0x58(%rbp)
 100fc0f:	mov    %r13,-0x68(%rbp)
 100fc13:	lea    0xd(%r15),%r12
 100fc17:	mov    -0xe20(%rbp),%r13
 100fc1e:	test   %r13,%r13
 100fc21:	je     100fcf6 <main+0x616>
 100fc27:	cmp    $0x8,%r13
 100fc2b:	je     100fcc3 <main+0x5e3>
 100fc31:	lea    -0xe98(%rbp),%r14
 100fc38:	mov    %r13,%rbx
 100fc3b:	jmp    100fc4d <main+0x56d>
 100fc3d:	nopl   (%rax)
 100fc40:	add    $0x10,%r14
 100fc44:	dec    %rbx
 100fc47:	je     100fcf6 <main+0x616>
 100fc4d:	mov    -0x8(%r14),%rdi
 100fc51:	mov    %r12,%rsi
 100fc54:	call   1027540 <strcmp@plt>
 100fc59:	test   %eax,%eax
 100fc5b:	jne    100fc40 <main+0x560>
 100fc5d:	cmpl   $0x0,(%r14)
 100fc61:	jne    100fc40 <main+0x560>
 100fc63:	jmp    100fcc3 <main+0x5e3>
 100fc65:	cmpb   $0x0,0xe(%r15)
 100fc6a:	je     100fd80 <main+0x6a0>
 100fc70:	mov    %rbx,-0x58(%rbp)
 100fc74:	mov    %r13,-0x68(%rbp)
 100fc78:	lea    0xe(%r15),%r12
 100fc7c:	mov    -0xe20(%rbp),%rbx
 100fc83:	test   %rbx,%rbx
 100fc86:	je     100fd33 <main+0x653>
 100fc8c:	cmp    $0x8,%rbx
 100fc90:	je     100fcc3 <main+0x5e3>
 100fc92:	lea    -0xe98(%rbp),%r14
 100fc99:	mov    %rbx,%r13
 100fc9c:	jmp    100fcad <main+0x5cd>
 100fc9e:	xchg   %ax,%ax
 100fca0:	add    $0x10,%r14
 100fca4:	dec    %r13
 100fca7:	je     100fd33 <main+0x653>
 100fcad:	mov    -0x8(%r14),%rdi
 100fcb1:	mov    %r12,%rsi
 100fcb4:	call   1027540 <strcmp@plt>
 100fcb9:	test   %eax,%eax
 100fcbb:	jne    100fca0 <main+0x5c0>
 100fcbd:	cmpl   $0x1,(%r14)
 100fcc1:	jne    100fca0 <main+0x5c0>
 100fcc3:	xor    %ecx,%ecx
 100fcc5:	xor    %eax,%eax
 100fcc7:	mov    -0x68(%rbp),%r13
 100fccb:	mov    -0x58(%rbp),%rbx
 100fccf:	mov    -0x78(%rbp),%r14
 100fcd3:	mov    -0x88(%rbp),%r12
 100fcda:	jmp    100fd84 <main+0x6a4>
 100fcdf:	lea    0x11(%r15),%rsi
 100fce3:	lea    -0x3790(%rbp),%rdi
 100fcea:	call   101cf00 <mylang_scoped_endpoint>
 100fcef:	xor    %ecx,%ecx
 100fcf1:	jmp    100fd84 <main+0x6a4>
 100fcf6:	lea    0x1(%r13),%rax
 100fcfa:	mov    %rax,-0xe20(%rbp)
 100fd01:	shl    $0x4,%r13
 100fd05:	lea    -0xea0(%rbp),%rax
 100fd0c:	mov    %r12,(%rax,%r13,1)
 100fd10:	movq   $0x0,0x8(%rax,%r13,1)
 100fd19:	jmp    100fd56 <main+0x676>
 100fd1b:	cmpl   $0x0,-0xe18(%rbp)
 100fd22:	jne    100fd80 <main+0x6a0>
 100fd24:	movl   $0x1,-0xe18(%rbp)
 100fd2e:	jmp    100faa0 <main+0x3c0>
 100fd33:	lea    0x1(%rbx),%rax
 100fd37:	mov    %rax,-0xe20(%rbp)
 100fd3e:	shl    $0x4,%rbx
 100fd42:	lea    -0xea0(%rbp),%rax
 100fd49:	mov    %r12,(%rax,%rbx,1)
 100fd4d:	movq   $0x1,0x8(%rax,%rbx,1)
 100fd56:	mov    -0x68(%rbp),%r13
 100fd5a:	mov    -0x58(%rbp),%rbx
 100fd5e:	mov    -0x78(%rbp),%r14
 100fd62:	mov    -0x88(%rbp),%r12
 100fd69:	jmp    100faa0 <main+0x3c0>
 100fd6e:	cmpl   $0x0,-0xe08(%rbp)
 100fd75:	je     101013e <main+0xa5e>
 100fd7b:	nopl   0x0(%rax,%rax,1)
 100fd80:	xor    %ecx,%ecx
 100fd82:	xor    %eax,%eax
 100fd84:	test   %cl,%cl
 100fd86:	jne    100fd90 <main+0x6b0>
 100fd88:	test   %al,%al
 100fd8a:	je     10118a3 <main+0x21c3>
 100fd90:	test   %cl,%cl
 100fd92:	je     100faa0 <main+0x3c0>
 100fd98:	mov    $0x10044d5,%esi
 100fd9d:	mov    $0xc,%edx
 100fda2:	mov    %r15,%rdi
 100fda5:	call   1027550 <strncmp@plt>
 100fdaa:	test   %eax,%eax
 100fdac:	je     100fe25 <main+0x745>
 100fdae:	mov    $0x10044e2,%esi
 100fdb3:	mov    $0xd,%edx
 100fdb8:	mov    %r15,%rdi
 100fdbb:	call   1027550 <strncmp@plt>
 100fdc0:	test   %eax,%eax
 100fdc2:	je     100fec6 <main+0x7e6>
 100fdc8:	mov    $0x10044b8,%esi
 100fdcd:	mov    $0xa,%edx
 100fdd2:	mov    %r15,%rdi
 100fdd5:	call   1027550 <strncmp@plt>
 100fdda:	test   %eax,%eax
 100fddc:	je     100ff66 <main+0x886>
 100fde2:	mov    $0x1003d31,%esi
 100fde7:	mov    %r15,%rdi
 100fdea:	call   1027540 <strcmp@plt>
 100fdef:	test   %eax,%eax
 100fdf1:	je     101000e <main+0x92e>
 100fdf7:	mov    $0x1003cd8,%esi
 100fdfc:	mov    %r15,%rdi
 100fdff:	call   1027540 <strcmp@plt>
 100fe04:	test   %eax,%eax
 100fe06:	jne    101251a <main+0x2e3a>
 100fe0c:	cmpl   $0x0,-0x80(%rbp)
 100fe10:	mov    $0x1003e2b,%eax
 100fe15:	cmovne %rax,%rbx
 100fe19:	movl   $0x1,-0x80(%rbp)
 100fe20:	jmp    100faa0 <main+0x3c0>
 100fe25:	movzbl 0xc(%r15),%eax
 100fe2a:	test   %al,%al
 100fe2c:	mov    -0x30(%rbp),%rsi
 100fe30:	je     100fe9d <main+0x7bd>
 100fe32:	add    $0xd,%r15
 100fe36:	xor    %edi,%edi
 100fe38:	nopl   0x0(%rax,%rax,1)
 100fe40:	lea    -0x3a(%rax),%ecx
 100fe43:	cmp    $0xf6,%cl
 100fe46:	jb     100fe9d <main+0x7bd>
 100fe48:	add    $0xd0,%al
 100fe4a:	movzbl %al,%eax
 100fe4d:	mov    %rax,%rdx
 100fe50:	not    %rdx
 100fe53:	movabs $0xcccccccccccccccd,%rcx
 100fe5d:	mulx   %rcx,%rcx,%rcx
 100fe62:	shr    $0x3,%rcx
 100fe66:	cmp    %rcx,%rdi
 100fe69:	ja     100fe9d <main+0x7bd>
 100fe6b:	lea    (%rdi,%rdi,4),%rcx
 100fe6f:	lea    (%rax,%rcx,2),%rdi
 100fe73:	movzbl (%r15),%eax
 100fe77:	inc    %r15
 100fe7a:	test   %al,%al
 100fe7c:	jne    100fe40 <main+0x760>
 100fe7e:	cmpl   $0x0,-0x44(%rbp)
 100fe82:	sete   %al
 100fe85:	mov    -0x38(%rbp),%rcx
 100fe89:	jne    100feaa <main+0x7ca>
 100fe8b:	movl   $0x1,-0x44(%rbp)
 100fe92:	test   %rdi,%rdi
 100fe95:	jne    100faac <main+0x3cc>
 100fe9b:	jmp    100feaa <main+0x7ca>
 100fe9d:	cmpl   $0x0,-0x44(%rbp)
 100fea1:	sete   %al
 100fea4:	xor    %edi,%edi
 100fea6:	mov    -0x38(%rbp),%rcx
 100feaa:	test   %al,%al
 100feac:	mov    $0x1003e2b,%ebx
 100feb1:	mov    $0x1003cfe,%eax
 100feb6:	cmovne %rax,%rbx
 100feba:	movl   $0x1,-0x44(%rbp)
 100fec1:	jmp    100faac <main+0x3cc>
 100fec6:	movzbl 0xd(%r15),%eax
 100fecb:	test   %al,%al
 100fecd:	mov    -0x40(%rbp),%rdi
 100fed1:	je     100ff3d <main+0x85d>
 100fed3:	add    $0xe,%r15
 100fed7:	xor    %esi,%esi
 100fed9:	nopl   0x0(%rax)
 100fee0:	lea    -0x3a(%rax),%ecx
 100fee3:	cmp    $0xf6,%cl
 100fee6:	jb     100ff3d <main+0x85d>
 100fee8:	add    $0xd0,%al
 100feea:	movzbl %al,%eax
 100feed:	mov    %rax,%rdx
 100fef0:	not    %rdx
 100fef3:	movabs $0xcccccccccccccccd,%rcx
 100fefd:	mulx   %rcx,%rcx,%rcx
 100ff02:	shr    $0x3,%rcx
 100ff06:	cmp    %rcx,%rsi
 100ff09:	ja     100ff3d <main+0x85d>
 100ff0b:	lea    (%rsi,%rsi,4),%rcx
 100ff0f:	lea    (%rax,%rcx,2),%rsi
 100ff13:	movzbl (%r15),%eax
 100ff17:	inc    %r15
 100ff1a:	test   %al,%al
 100ff1c:	jne    100fee0 <main+0x800>
 100ff1e:	cmpl   $0x0,-0x6c(%rbp)
 100ff22:	sete   %al
 100ff25:	mov    -0x38(%rbp),%rcx
 100ff29:	jne    100ff4a <main+0x86a>
 100ff2b:	movl   $0x1,-0x6c(%rbp)
 100ff32:	test   %rsi,%rsi
 100ff35:	jne    100faac <main+0x3cc>
 100ff3b:	jmp    100ff4a <main+0x86a>
 100ff3d:	cmpl   $0x0,-0x6c(%rbp)
 100ff41:	sete   %al
 100ff44:	xor    %esi,%esi
 100ff46:	mov    -0x38(%rbp),%rcx
 100ff4a:	test   %al,%al
 100ff4c:	mov    $0x1003e2b,%ebx
 100ff51:	mov    $0x1003cfe,%eax
 100ff56:	cmovne %rax,%rbx
 100ff5a:	movl   $0x1,-0x6c(%rbp)
 100ff61:	jmp    100faac <main+0x3cc>
 100ff66:	movzbl 0xa(%r15),%eax
 100ff6b:	test   %al,%al
 100ff6d:	mov    -0x30(%rbp),%rsi
 100ff71:	mov    -0x40(%rbp),%rdi
 100ff75:	je     100ffe4 <main+0x904>
 100ff77:	add    $0xb,%r15
 100ff7b:	xor    %r13d,%r13d
 100ff7e:	xchg   %ax,%ax
 100ff80:	lea    -0x3a(%rax),%ecx
 100ff83:	cmp    $0xf6,%cl
 100ff86:	jb     100ffe4 <main+0x904>
 100ff88:	add    $0xd0,%al
 100ff8a:	movzbl %al,%eax
 100ff8d:	mov    %rax,%rdx
 100ff90:	not    %rdx
 100ff93:	movabs $0xcccccccccccccccd,%rcx
 100ff9d:	mulx   %rcx,%rcx,%rcx
 100ffa2:	shr    $0x3,%rcx
 100ffa6:	cmp    %rcx,%r13
 100ffa9:	ja     100ffe4 <main+0x904>
 100ffab:	lea    0x0(,%r13,4),%rcx
 100ffb3:	add    %r13,%rcx
 100ffb6:	lea    (%rax,%rcx,2),%r13
 100ffba:	movzbl (%r15),%eax
 100ffbe:	inc    %r15
 100ffc1:	test   %al,%al
 100ffc3:	jne    100ff80 <main+0x8a0>
 100ffc5:	cmpl   $0x0,-0x7c(%rbp)
 100ffc9:	sete   %al
 100ffcc:	mov    -0x38(%rbp),%rcx
 100ffd0:	jne    100fff2 <main+0x912>
 100ffd2:	movl   $0x1,-0x7c(%rbp)
 100ffd9:	test   %r13,%r13
 100ffdc:	jne    100faac <main+0x3cc>
 100ffe2:	jmp    100fff2 <main+0x912>
 100ffe4:	cmpl   $0x0,-0x7c(%rbp)
 100ffe8:	sete   %al
 100ffeb:	xor    %r13d,%r13d
 100ffee:	mov    -0x38(%rbp),%rcx
 100fff2:	test   %al,%al
 100fff4:	mov    $0x1003e2b,%ebx
 100fff9:	mov    $0x1003cfe,%eax
 100fffe:	cmovne %rax,%rbx
 1010002:	movl   $0x1,-0x7c(%rbp)
 1010009:	jmp    100faac <main+0x3cc>
 101000e:	cmpl   $0x0,-0x5c(%rbp)
 1010012:	mov    -0x30(%rbp),%rsi
 1010016:	mov    -0x40(%rbp),%rdi
 101001a:	mov    -0x38(%rbp),%rcx
 101001e:	je     101014d <main+0xa6d>
 1010024:	movl   $0x1,-0x5c(%rbp)
 101002b:	mov    $0x1003e2b,%ebx
 1010030:	jmp    100faac <main+0x3cc>
 1010035:	movzbl 0xe(%r15),%eax
 101003a:	test   %eax,%eax
 101003c:	je     1010165 <main+0xa85>
 1010042:	cmp    $0x3d,%eax
 1010045:	jne    100fb6f <main+0x48f>
 101004b:	cmpb   $0x0,0xf(%r15)
 1010050:	je     100fb6f <main+0x48f>
 1010056:	cmpl   $0x0,-0xe14(%rbp)
 101005d:	jne    100fb6f <main+0x48f>
 1010063:	add    $0xf,%r15
 1010067:	jmp    1010178 <main+0xa98>
 101006c:	movzbl 0xb(%r15),%eax
 1010071:	test   %eax,%eax
 1010073:	je     10101a7 <main+0xac7>
 1010079:	cmp    $0x3d,%eax
 101007c:	jne    100fb89 <main+0x4a9>
 1010082:	cmpb   $0x0,0xc(%r15)
 1010087:	je     100fb89 <main+0x4a9>
 101008d:	cmpl   $0x0,-0xe10(%rbp)
 1010094:	jne    100fb89 <main+0x4a9>
 101009a:	add    $0xc,%r15
 101009e:	jmp    10101ba <main+0xada>
 10100a3:	vmovdqu -0xe18(%rbp),%xmm0
 10100ab:	vpinsrd $0x3,-0xe08(%rbp),%xmm0,%xmm0
 10100b5:	xor    %ecx,%ecx
 10100b7:	vptest %xmm0,%xmm0
 10100bc:	jne    100fd82 <main+0x6a2>
 10100c2:	cmpq   $0x0,-0xe20(%rbp)
 10100ca:	jne    100fd82 <main+0x6a2>
 10100d0:	cmpq   $0x0,-0xea8(%rbp)
 10100d8:	mov    $0x0,%eax
 10100dd:	jne    100fd84 <main+0x6a4>
 10100e3:	movl   $0x1,-0xe08(%rbp)
 10100ed:	movl   $0x1,-0xe10(%rbp)
 10100f7:	movabs $0x100000001,%rax
 1010101:	mov    %rax,-0xe18(%rbp)
 1010108:	movq   $0x1004f8b,-0xe00(%rbp)
 1010113:	movq   $0x1,-0xe20(%rbp)
 101011e:	movq   $0x1004662,-0xea0(%rbp)
 1010129:	movq   $0x1,-0xe98(%rbp)
 1010134:	mov    $0x100466d,%esi
 1010139:	jmp    100fce3 <main+0x603>
 101013e:	movl   $0x1,-0xe08(%rbp)
 1010148:	jmp    100faa0 <main+0x3c0>
 101014d:	test   %rbx,%rbx
 1010150:	mov    $0x100b2c0,%eax
 1010155:	cmove  %rax,%rbx
 1010159:	movl   $0x1,-0x5c(%rbp)
 1010160:	jmp    100faac <main+0x3cc>
 1010165:	cmpl   $0x0,-0xe14(%rbp)
 101016c:	jne    100fb6f <main+0x48f>
 1010172:	mov    $0x1004f8b,%r15d
 1010178:	movl   $0x1,-0xe14(%rbp)
 1010182:	cmpb   $0x0,(%r15)
 1010186:	je     100faa0 <main+0x3c0>
 101018c:	mov    %r15,%rdi
 101018f:	xor    %esi,%esi
 1010191:	mov    $0xa,%edx
 1010196:	call   1027560 <strtoull@plt>
 101019b:	mov    %rax,-0xdf8(%rbp)
 10101a2:	jmp    100faa0 <main+0x3c0>
 10101a7:	cmpl   $0x0,-0xe10(%rbp)
 10101ae:	jne    100fb89 <main+0x4a9>
 10101b4:	mov    $0x1004f8b,%r15d
 10101ba:	movl   $0x1,-0xe10(%rbp)
 10101c4:	mov    %r15,-0xe00(%rbp)
 10101cb:	jmp    100faa0 <main+0x3c0>
 10101d0:	xor    %r13d,%r13d
 10101d3:	movq   $0xffffffffffffffff,-0x40(%rbp)
 10101db:	movl   $0x0,-0x5c(%rbp)
 10101e2:	movq   $0x0,-0x58(%rbp)
 10101ea:	jmp    101021b <main+0xb3b>
 10101ec:	mov    %rbx,-0x58(%rbp)
 10101f0:	cmpl   $0x0,-0x80(%rbp)
 10101f4:	sete   %r14b
 10101f8:	xor    %ecx,%ecx
 10101fa:	cmpl   $0x1,-0x44(%rbp)
 10101fe:	mov    $0x0,%eax
 1010203:	sbb    %rax,%rax
 1010206:	or     %rdi,%rax
 1010209:	mov    %rax,-0x30(%rbp)
 101020d:	cmpl   $0x1,-0x6c(%rbp)
 1010211:	sbb    %rcx,%rcx
 1010214:	or     %rsi,%rcx
 1010217:	mov    %rcx,-0x40(%rbp)
 101021b:	mov    -0x78(%rbp),%rdi
 101021f:	call   1027570 <free@plt>
 1010224:	cmpl   $0x0,-0xe0c(%rbp)
 101022b:	vpxor  %xmm0,%xmm0,%xmm0
 101022f:	vmovdqu %ymm0,-0xc8(%rbp)
 1010237:	vmovdqu %ymm0,-0xe0(%rbp)
 101023f:	vmovdqu %ymm0,-0x100(%rbp)
 1010247:	vmovdqu %ymm0,-0x120(%rbp)
 101024f:	vmovdqu %ymm0,-0x140(%rbp)
 1010257:	vmovdqu %ymm0,-0x160(%rbp)
 101025f:	vmovdqu %ymm0,-0x180(%rbp)
 1010267:	mov    %r14b,-0x44(%rbp)
 101026b:	je     101031f <main+0xc3f>
 1010271:	mov    -0xe20(%rbp),%r15
 1010278:	mov    -0x3730(%rbp),%rbx
 101027f:	test   %r15,%r15
 1010282:	je     101034a <main+0xc6a>
 1010288:	mov    %r13,-0x68(%rbp)
 101028c:	lea    (%rbx,%rbx,2),%rax
 1010290:	lea    -0x3788(,%rax,4),%r12
 1010298:	add    %rbp,%r12
 101029b:	lea    -0xe98(%rbp),%r13
 10102a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10102b0:	cmp    $0x7,%rbx
 10102b4:	ja     1011709 <main+0x2029>
 10102ba:	mov    0x0(%r13),%r14d
 10102be:	mov    -0x8(%r13),%rdi
 10102c2:	mov    $0x90000,%esi
 10102c7:	xor    %eax,%eax
 10102c9:	vzeroupper
 10102cc:	call   1027530 <open@plt>
 10102d1:	test   %eax,%eax
 10102d3:	js     1011709 <main+0x2029>
 10102d9:	inc    %rbx
 10102dc:	mov    %rbx,-0x3730(%rbp)
 10102e3:	mov    %eax,-0x8(%r12)
 10102e8:	mov    %r14d,-0x4(%r12)
 10102ed:	movl   $0x0,(%r12)
 10102f5:	add    $0xc,%r12
 10102f9:	add    $0x10,%r13
 10102fd:	dec    %r15
 1010300:	jne    10102b0 <main+0xbd0>
 1010302:	lea    -0x3790(%rbp),%r12
 1010309:	mov    -0x68(%rbp),%r13
 101030d:	cmpl   $0x0,-0xe0c(%rbp)
 1010314:	sete   %al
 1010317:	jne    100fa4d <main+0x36d>
 101031d:	jmp    101036d <main+0xc8d>
 101031f:	mov    -0x90(%rbp),%rax
 1010326:	lea    -0x3790(%rbp),%r12
 101032d:	mov    %rax,-0x90(%rbp)
 1010334:	mov    -0x3730(%rbp),%rbx
 101033b:	cmp    $0x7,%rbx
 101033f:	jbe    100f9f9 <main+0x319>
 1010345:	jmp    1011710 <main+0x2030>
 101034a:	mov    -0xe0c(%rbp),%ecx
 1010350:	test   %ecx,%ecx
 1010352:	sete   %al
 1010355:	test   %rbx,%rbx
 1010358:	je     101049d <main+0xdbd>
 101035e:	test   %ecx,%ecx
 1010360:	lea    -0x3790(%rbp),%r12
 1010367:	jne    100fa4d <main+0x36d>
 101036d:	mov    $0x7,%ecx
 1010372:	movq   $0x0,-0x148(%rbp)
 101037d:	mov    %r12,-0x150(%rbp)
 1010384:	mov    %ecx,-0x148(%rbp)
 101038a:	movq   $0x101d640,-0x140(%rbp)
 1010395:	movq   $0x101d310,-0x138(%rbp)
 10103a0:	movq   $0x101d380,-0x130(%rbp)
 10103ab:	movq   $0x101d3e0,-0x128(%rbp)
 10103b6:	movq   $0x101d520,-0x120(%rbp)
 10103c1:	cmpq   $0x0,-0xea8(%rbp)
 10103c9:	je     10104c2 <main+0xde2>
 10103cf:	mov    %r12,-0x118(%rbp)
 10103d6:	movq   $0x7,-0x110(%rbp)
 10103e1:	movq   $0x101d0d0,-0x108(%rbp)
 10103ec:	movq   $0x101d310,-0x100(%rbp)
 10103f7:	movq   $0x101d380,-0xf8(%rbp)
 1010402:	movq   $0x101d3e0,-0xf0(%rbp)
 101040d:	movq   $0x101d520,-0xe8(%rbp)
 1010418:	test   %al,%al
 101041a:	je     10104de <main+0xdfe>
 1010420:	movq   $0x101ccf0,-0x178(%rbp)
 101042b:	vpxor  %xmm0,%xmm0,%xmm0
 101042f:	vmovdqa %xmm0,-0x170(%rbp)
 1010437:	cmpl   $0x0,-0xe14(%rbp)
 101043e:	jne    1010549 <main+0xe69>
 1010444:	xor    %ebx,%ebx
 1010446:	lea    -0x9f0(%rbp),%rsi
 101044d:	xor    %edi,%edi
 101044f:	vzeroupper
 1010452:	call   1027580 <clock_gettime@plt>
 1010457:	test   %eax,%eax
 1010459:	jne    1010542 <main+0xe62>
 101045f:	mov    -0x9f0(%rbp),%rcx
 1010466:	mov    -0x9e8(%rbp),%rax
 101046d:	movabs $0x7fffffffffffffff,%rdx
 1010477:	xor    %rax,%rdx
 101047a:	movabs $0x112e0be826d694b3,%rsi
 1010484:	mulx   %rsi,%rdx,%rdx
 1010489:	shr    $0x1a,%rdx
 101048d:	cmp    %rdx,%rcx
 1010490:	jle    1010538 <main+0xe58>
 1010496:	xor    %ebx,%ebx
 1010498:	jmp    1010542 <main+0xe62>
 101049d:	lea    -0x150(%rbp),%rcx
 10104a4:	vmovdqu %ymm0,0x18(%rcx)
 10104a9:	vmovdqu %ymm0,(%rcx)
 10104ad:	lea    -0x3790(%rbp),%r12
 10104b4:	cmpq   $0x0,-0xea8(%rbp)
 10104bc:	jne    10103cf <main+0xcef>
 10104c2:	lea    -0x118(%rbp),%rcx
 10104c9:	vpxor  %xmm0,%xmm0,%xmm0
 10104cd:	vmovdqu %ymm0,0x18(%rcx)
 10104d2:	vmovdqu %ymm0,(%rcx)
 10104d6:	test   %al,%al
 10104d8:	jne    1010420 <main+0xd40>
 10104de:	xor    %eax,%eax
 10104e0:	cmpl   $0x0,-0xe18(%rbp)
 10104e7:	mov    $0x101ccf0,%ecx
 10104ec:	cmovne %rcx,%rax
 10104f0:	mov    %rax,-0x178(%rbp)
 10104f7:	vpxor  %xmm0,%xmm0,%xmm0
 10104fb:	vmovdqa %xmm0,-0x170(%rbp)
 1010503:	cmpl   $0x0,-0xe14(%rbp)
 101050a:	je     1010525 <main+0xe45>
 101050c:	lea    -0xdf8(%rbp),%rax
 1010513:	mov    %rax,-0x170(%rbp)
 101051a:	movq   $0x101cd60,-0x168(%rbp)
 1010525:	vmovdqa %xmm0,-0x160(%rbp)
 101052d:	cmpl   $0x0,-0xe10(%rbp)
 1010534:	jne    1010562 <main+0xe82>
 1010536:	jmp    101057b <main+0xe9b>
 1010538:	imul   $0x3b9aca00,%rcx,%rbx
 101053f:	add    %rax,%rbx
 1010542:	mov    %rbx,-0xdf8(%rbp)
 1010549:	lea    -0xdf8(%rbp),%rax
 1010550:	mov    %rax,-0x170(%rbp)
 1010557:	movq   $0x101cd60,-0x168(%rbp)
 1010562:	mov    -0xe00(%rbp),%rax
 1010569:	mov    %rax,-0x160(%rbp)
 1010570:	movq   $0x101cdb0,-0x158(%rbp)
 101057b:	xor    %ebx,%ebx
 101057d:	mov    -0x94(%rbp),%eax
 1010583:	test   %eax,%eax
 1010585:	setg   %r15b
 1010589:	cmp    $0x2,%eax
 101058c:	mov    $0x1,%r14d
 1010592:	cmovge %eax,%r14d
 1010596:	mov    -0x58(%rbp),%rdx
 101059a:	cmp    $0x100b2c0,%rdx
 10105a1:	je     10109b5 <main+0x12d5>
 10105a7:	test   %rdx,%rdx
 10105aa:	jne    10109ce <main+0x12ee>
 10105b0:	test   %r13,%r13
 10105b3:	je     101068e <main+0xfae>
 10105b9:	lea    -0x9e8(%rbp),%rdi
 10105c0:	vpxor  %xmm0,%xmm0,%xmm0
 10105c4:	vmovdqu %ymm0,-0x978(%rbp)
 10105cc:	vmovdqu %ymm0,-0x988(%rbp)
 10105d4:	vmovdqu %ymm0,-0x9a8(%rbp)
 10105dc:	vmovdqu %ymm0,-0x9c8(%rbp)
 10105e4:	vmovdqu %ymm0,-0x9e8(%rbp)
 10105ec:	movq   $0x10152e0,-0x9f0(%rbp)
 10105f7:	vzeroupper
 10105fa:	call   1027590 <sigemptyset@plt>
 10105ff:	lea    -0x9f0(%rbp),%rsi
 1010606:	mov    $0xe,%edi
 101060b:	xor    %edx,%edx
 101060d:	call   10275a0 <sigaction@plt>
 1010612:	test   %eax,%eax
 1010614:	jne    101099c <main+0x12bc>
 101061a:	vpxor  %xmm0,%xmm0,%xmm0
 101061e:	vmovdqu %ymm0,-0xdf0(%rbp)
 1010626:	vmovdqu %ymm0,-0xdd0(%rbp)
 101062e:	movl   $0xe,-0xde8(%rbp)
 1010638:	lea    -0xdf0(%rbp),%rsi
 101063f:	mov    $0x102b7d0,%edx
 1010644:	mov    $0x1,%edi
 1010649:	vzeroupper
 101064c:	call   10275b0 <timer_create@plt>
 1010651:	test   %eax,%eax
 1010653:	jne    101099c <main+0x12bc>
 1010659:	vpxor  %xmm0,%xmm0,%xmm0
 101065d:	vmovdqu %ymm0,-0x3f0(%rbp)
 1010665:	mov    %r13,-0x3e0(%rbp)
 101066c:	mov    0x1b15d(%rip),%rdi        # 102b7d0 <timeout_timer>
 1010673:	lea    -0x3f0(%rbp),%rdx
 101067a:	xor    %esi,%esi
 101067c:	xor    %ecx,%ecx
 101067e:	vzeroupper
 1010681:	call   10275c0 <timer_settime@plt>
 1010686:	test   %eax,%eax
 1010688:	jne    101099c <main+0x12bc>
 101068e:	mov    %r15b,%bl
 1010691:	mov    -0xa0(%rbp),%rax
 1010698:	lea    (%rax,%rbx,8),%rax
 101069c:	mov    %rax,-0x38(%rbp)
 10106a0:	dec    %r14d
 10106a3:	mov    %r14d,-0x58(%rbp)
 10106a7:	je     101084e <main+0x116e>
 10106ad:	mov    -0x58(%rbp),%r15d
 10106b1:	xor    %r13d,%r13d
 10106b4:	jmp    10106cc <main+0xfec>
 10106b6:	cs nopw 0x0(%rax,%rax,1)
 10106c0:	inc    %r13
 10106c3:	cmp    %r15,%r13
 10106c6:	je     101084e <main+0x116e>
 10106cc:	mov    -0x38(%rbp),%rax
 10106d0:	mov    (%rax,%r13,8),%rbx
 10106d4:	mov    %rbx,%rdi
 10106d7:	vzeroupper
 10106da:	call   10274f0 <strlen@plt>
 10106df:	test   %rax,%rax
 10106e2:	je     10106c0 <main+0xfe0>
 10106e4:	mov    %rax,%r12
 10106e7:	xor    %ecx,%ecx
 10106e9:	jmp    1010702 <main+0x1022>
 10106eb:	nopl   0x0(%rax,%rax,1)
 10106f0:	dec    %edx
 10106f2:	lea    (%rcx,%rdx,1),%r9
 10106f6:	add    $0x2,%r9
 10106fa:	mov    %r9,%rcx
 10106fd:	cmp    %r12,%r9
 1010700:	je     10106c0 <main+0xfe0>
 1010702:	lea    0x1(%rcx),%r9
 1010706:	movzbl (%rbx,%rcx,1),%edi
 101070a:	test   %dil,%dil
 101070d:	jns    10106fa <main+0x101a>
 101070f:	lea    0x3e(%rdi),%r8d
 1010713:	cmp    $0x1e,%r8b
 1010717:	jae    101072b <main+0x104b>
 1010719:	mov    $0x80,%esi
 101071e:	mov    $0x1,%edx
 1010723:	mov    $0x1f,%r10d
 1010729:	jmp    1010766 <main+0x1086>
 101072b:	mov    %edi,%edx
 101072d:	and    $0xf0,%dl
 1010730:	cmp    $0xe0,%dl
 1010733:	jne    101074a <main+0x106a>
 1010735:	mov    $0x800,%esi
 101073a:	mov    $0x2,%edx
 101073f:	mov    $0x1,%r11b
 1010742:	mov    $0xf,%r10d
 1010748:	jmp    1010769 <main+0x1089>
 101074a:	lea    0x10(%rdi),%edx
 101074d:	cmp    $0x4,%dl
 1010750:	ja     1010819 <main+0x1139>
 1010756:	mov    $0x10000,%esi
 101075b:	mov    $0x3,%edx
 1010760:	mov    $0x7,%r10d
 1010766:	xor    %r11d,%r11d
 1010769:	mov    %edx,%r14d
 101076c:	mov    %r12,%rax
 101076f:	sub    %r9,%rax
 1010772:	cmp    %r14,%rax
 1010775:	jb     1010819 <main+0x1139>
 101077b:	movzbl 0x1(%rbx,%rcx,1),%r9d
 1010781:	mov    %r9d,%eax
 1010784:	and    $0xffffffc0,%eax
 1010787:	cmp    $0x80,%eax
 101078c:	jne    1010819 <main+0x1139>
 1010792:	and    %edi,%r10d
 1010795:	shl    $0x6,%r10d
 1010799:	and    $0x3f,%r9d
 101079d:	or     %r10d,%r9d
 10107a0:	cmp    $0x1e,%r8b
 10107a4:	jb     10107cc <main+0x10ec>
 10107a6:	movzbl 0x2(%rbx,%rcx,1),%edi
 10107ab:	mov    %edi,%eax
 10107ad:	and    $0xffffffc0,%eax
 10107b0:	cmp    $0x80,%eax
 10107b5:	jne    1010819 <main+0x1139>
 10107b7:	shl    $0x6,%r9d
 10107bb:	and    $0x3f,%edi
 10107be:	or     %r9d,%edi
 10107c1:	test   %r11b,%r11b
 10107c4:	je     10107f0 <main+0x1110>
 10107c6:	mov    %r9d,%r10d
 10107c9:	mov    %edi,%r9d
 10107cc:	cmp    $0x10ffff,%r10d
 10107d3:	ja     1010819 <main+0x1139>
 10107d5:	cmp    %esi,%r9d
 10107d8:	jb     1010819 <main+0x1139>
 10107da:	add    $0xffff2000,%r10d
 10107e1:	cmp    $0xfffff7ff,%r10d
 10107e8:	jbe    10106f0 <main+0x1010>
 10107ee:	jmp    1010819 <main+0x1139>
 10107f0:	movzbl 0x3(%rbx,%rcx,1),%r9d
 10107f6:	mov    %r9d,%eax
 10107f9:	and    $0xffffffc0,%eax
 10107fc:	cmp    $0x80,%eax
 1010801:	jne    1010819 <main+0x1139>
 1010803:	shl    $0x6,%edi
 1010806:	and    $0x3f,%r9d
 101080a:	or     %edi,%r9d
 101080d:	mov    %edi,%r10d
 1010810:	cmp    $0x10ffff,%r10d
 1010817:	jbe    10107d5 <main+0x10f5>
 1010819:	mov    0x18378(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1010820:	mov    (%rax),%rcx
 1010823:	mov    $0x1004f13,%edi
 1010828:	mov    $0x2a,%esi
 101082d:	mov    $0x1,%edx
 1010832:	call   10275d0 <fwrite@plt>
 1010837:	mov    $0x2,%r15d
 101083d:	mov    $0x70,%ebx
 1010842:	lea    -0x3790(%rbp),%r12
 1010849:	jmp    10125a8 <main+0x2ec8>
 101084e:	lea    -0x3f0(%rbp),%rdi
 1010855:	mov    $0x268,%edx
 101085a:	xor    %esi,%esi
 101085c:	vzeroupper
 101085f:	call   10274d0 <memset@plt>
 1010864:	mov    $0x1003cfe,%ecx
 1010869:	cmpq   $0x0,-0x30(%rbp)
 101086e:	je     10115f6 <main+0x1f16>
 1010874:	mov    -0x40(%rbp),%rdx
 1010878:	test   %rdx,%rdx
 101087b:	lea    -0x3790(%rbp),%r12
 1010882:	je     10115f6 <main+0x1f16>
 1010888:	cmp    $0xffffffffffffffff,%rdx
 101088c:	mov    $0x400,%eax
 1010891:	cmovne %rdx,%rax
 1010895:	mov    %rax,-0x68(%rbp)
 1010899:	shr    $0x3b,%rax
 101089d:	mov    $0x1003b92,%ecx
 10108a2:	jne    10115f6 <main+0x1f16>
 10108a8:	mov    $0x100431a,%edi
 10108ad:	call   10274e0 <getenv@plt>
 10108b2:	test   %rax,%rax
 10108b5:	je     1010981 <main+0x12a1>
 10108bb:	movzbl (%rax),%edx
 10108be:	test   %dl,%dl
 10108c0:	je     1010981 <main+0x12a1>
 10108c6:	lea    -0x30(%rdx),%esi
 10108c9:	mov    $0x1003ce7,%ecx
 10108ce:	cmp    $0x9,%sil
 10108d2:	ja     10115f6 <main+0x1f16>
 10108d8:	dec    %rax
 10108db:	xor    %esi,%esi
 10108dd:	movabs $0xcccccccccccccccd,%rdi
 10108e7:	nopw   0x0(%rax,%rax,1)
 10108f0:	add    $0xd0,%dl
 10108f3:	movzbl %dl,%r8d
 10108f7:	mov    %r8,%rdx
 10108fa:	not    %rdx
 10108fd:	mulx   %rdi,%rdx,%rdx
 1010902:	shr    $0x3,%rdx
 1010906:	cmp    %rdx,%rsi
 1010909:	ja     10115f6 <main+0x1f16>
 101090f:	lea    (%rsi,%rsi,4),%rdx
 1010913:	lea    (%r8,%rdx,2),%rsi
 1010917:	movzbl 0x2(%rax),%edx
 101091b:	lea    -0x30(%rdx),%r8d
 101091f:	inc    %rax
 1010922:	cmp    $0xa,%r8b
 1010926:	jb     10108f0 <main+0x1210>
 1010928:	movzbl %dl,%edx
 101092b:	lea    -0x47(%rdx),%edi
 101092e:	cmp    $0x26,%edi
 1010931:	ja     10115e8 <main+0x1f08>
 1010937:	movabs $0x100000001,%r8
 1010941:	bt     %rdi,%r8
 1010945:	jb     10109ec <main+0x130c>
 101094b:	mov    $0x400,%r14d
 1010951:	movabs $0x1000000010,%r8
 101095b:	bt     %rdi,%r8
 101095f:	jb     10109f2 <main+0x1312>
 1010965:	movabs $0x4000000040,%r8
 101096f:	bt     %rdi,%r8
 1010973:	jae    10115e8 <main+0x1f08>
 1010979:	mov    $0x100000,%r14d
 101097f:	jmp    10109f2 <main+0x1312>
 1010981:	xor    %r14d,%r14d
 1010984:	mov    $0x1004458,%edi
 1010989:	call   10274e0 <getenv@plt>
 101098e:	test   %rax,%rax
 1010991:	jne    1010a29 <main+0x1349>
 1010997:	jmp    1010a4c <main+0x136c>
 101099c:	mov    0x181f5(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10109a3:	mov    (%rax),%rcx
 10109a6:	mov    $0x1004ea2,%edi
 10109ab:	mov    $0x32,%esi
 10109b0:	jmp    1011724 <main+0x2044>
 10109b5:	mov    0x181dc(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10109bc:	mov    (%rax),%rcx
 10109bf:	mov    $0x100491f,%edi
 10109c4:	mov    $0x5e,%esi
 10109c9:	jmp    1011724 <main+0x2044>
 10109ce:	mov    0x181c3(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10109d5:	mov    (%rax),%rdi
 10109d8:	mov    $0x1004d99,%esi
 10109dd:	xor    %eax,%eax
 10109df:	vzeroupper
 10109e2:	call   10275e0 <fprintf@plt>
 10109e7:	jmp    1011731 <main+0x2051>
 10109ec:	mov    $0x40000000,%r14d
 10109f2:	cmpb   $0x0,0x2(%rax)
 10109f6:	jne    10115f6 <main+0x1f16>
 10109fc:	tzcnt  %r14,%rax
 1010a01:	mov    $0xffffffffffffffff,%rdx
 1010a08:	shrx   %rax,%rdx,%rax
 1010a0d:	cmp    %rax,%rsi
 1010a10:	ja     10115f6 <main+0x1f16>
 1010a16:	imul   %rsi,%r14
 1010a1a:	mov    $0x1004458,%edi
 1010a1f:	call   10274e0 <getenv@plt>
 1010a24:	test   %rax,%rax
 1010a27:	je     1010a4c <main+0x136c>
 1010a29:	movzbl (%rax),%edx
 1010a2c:	lea    -0x3a(%rdx),%ecx
 1010a2f:	cmp    $0xf6,%cl
 1010a32:	jae    1010bb2 <main+0x14d2>
 1010a38:	mov    $0x1004458,%edi
 1010a3d:	call   10275f0 <unsetenv@plt>
 1010a42:	mov    $0x10042dd,%edi
 1010a47:	call   10275f0 <unsetenv@plt>
 1010a4c:	lea    0x10000000(%r14),%rbx
 1010a53:	cmp    $0x10000001,%rbx
 1010a5a:	jb     1010ab4 <main+0x13d4>
 1010a5c:	lea    -0x9f0(%rbp),%rsi
 1010a63:	mov    $0x9,%edi
 1010a68:	call   1027600 <getrlimit@plt>
 1010a6d:	test   %eax,%eax
 1010a6f:	jne    1010ab4 <main+0x13d4>
 1010a71:	mov    -0x9f0(%rbp),%rcx
 1010a78:	mov    -0x9e8(%rbp),%rdx
 1010a7f:	cmp    %rdx,%rbx
 1010a82:	mov    %rdx,%rax
 1010a85:	cmovb  %rbx,%rax
 1010a89:	cmp    $0xffffffffffffffff,%rdx
 1010a8d:	cmove  %rbx,%rax
 1010a91:	cmp    $0xffffffffffffffff,%rcx
 1010a95:	je     1010a9c <main+0x13bc>
 1010a97:	cmp    %rax,%rcx
 1010a9a:	jbe    1010ab4 <main+0x13d4>
 1010a9c:	mov    %rax,-0x9f0(%rbp)
 1010aa3:	lea    -0x9f0(%rbp),%rsi
 1010aaa:	mov    $0x9,%edi
 1010aaf:	call   1027610 <setrlimit@plt>
 1010ab4:	mov    $0x1,%edi
 1010ab9:	mov    $0x3e88,%esi
 1010abe:	call   1027510 <calloc@plt>
 1010ac3:	mov    $0x1003b92,%ecx
 1010ac8:	test   %rax,%rax
 1010acb:	mov    -0x40(%rbp),%rdx
 1010acf:	je     10115f6 <main+0x1f16>
 1010ad5:	mov    %rax,%r15
 1010ad8:	mov    -0x30(%rbp),%rax
 1010adc:	mov    %rax,0x10(%r15)
 1010ae0:	mov    -0x68(%rbp),%rax
 1010ae4:	mov    %rax,0x18(%r15)
 1010ae8:	mov    %rdx,0x38(%r15)
 1010aec:	lea    -0x180(%rbp),%rax
 1010af3:	mov    %rax,0x3978(%r15)
 1010afa:	mov    -0x58(%rbp),%eax
 1010afd:	mov    %eax,0x39d0(%r15)
 1010b04:	mov    -0x38(%rbp),%rax
 1010b08:	mov    %rax,0x39d8(%r15)
 1010b0f:	lea    0x258(%r15),%r13
 1010b16:	xor    %ebx,%ebx
 1010b18:	cmp    $0x1,%r14
 1010b1c:	sbb    %rbx,%rbx
 1010b1f:	or     %r14,%rbx
 1010b22:	mov    $0x1718,%edx
 1010b27:	mov    %r13,%rdi
 1010b2a:	xor    %esi,%esi
 1010b2c:	call   10274d0 <memset@plt>
 1010b31:	mov    %rbx,0x2b0(%r15)
 1010b38:	movq   $0x1,0x290(%r15)
 1010b43:	movq   $0x100000,0x2b8(%r15)
 1010b4e:	cmp    $0x457,%rbx
 1010b55:	ja     1010b67 <main+0x1487>
 1010b57:	movl   $0x1,0x2c4(%r15)
 1010b62:	jmp    1010da9 <main+0x16c9>
 1010b67:	mov    $0x1,%edi
 1010b6c:	mov    $0x458,%esi
 1010b71:	call   1027510 <calloc@plt>
 1010b76:	test   %rax,%rax
 1010b79:	je     1010da9 <main+0x16c9>
 1010b7f:	movq   $0x458,0x270(%r15)
 1010b8a:	movq   $0x458,0x208(%rax)
 1010b95:	cmp    $0x57f,%rbx
 1010b9c:	ja     1010cec <main+0x160c>
 1010ba2:	movl   $0x1,0x2c4(%r15)
 1010bad:	jmp    1010d96 <main+0x16b6>
 1010bb2:	add    $0x2,%rax
 1010bb6:	xor    %r15d,%r15d
 1010bb9:	movabs $0xcccccccccccccccd,%rcx
 1010bc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010bd0:	add    $0xd0,%dl
 1010bd3:	movzbl %dl,%esi
 1010bd6:	mov    %rsi,%rdx
 1010bd9:	not    %rdx
 1010bdc:	mulx   %rcx,%rdx,%rdx
 1010be1:	shr    $0x3,%rdx
 1010be5:	cmp    %rdx,%r15
 1010be8:	ja     1010a38 <main+0x1358>
 1010bee:	lea    (%r15,%r15,4),%rdx
 1010bf2:	lea    (%rsi,%rdx,2),%r15
 1010bf6:	movzbl -0x1(%rax),%edx
 1010bfa:	lea    -0x30(%rdx),%esi
 1010bfd:	inc    %rax
 1010c00:	cmp    $0xa,%sil
 1010c04:	jb     1010bd0 <main+0x14f0>
 1010c06:	cmp    $0x3a,%dl
 1010c09:	jne    1010a38 <main+0x1358>
 1010c0f:	movzbl -0x1(%rax),%ebx
 1010c13:	lea    -0x3a(%rbx),%edx
 1010c16:	cmp    $0xf6,%dl
 1010c19:	jb     1010a38 <main+0x1358>
 1010c1f:	xor    %r13d,%r13d
 1010c22:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010c30:	add    $0xd0,%bl
 1010c33:	movzbl %bl,%esi
 1010c36:	mov    %rsi,%rdx
 1010c39:	not    %rdx
 1010c3c:	mulx   %rcx,%rdx,%rdx
 1010c41:	shr    $0x3,%rdx
 1010c45:	cmp    %rdx,%r13
 1010c48:	ja     1010a38 <main+0x1358>
 1010c4e:	lea    0x0(,%r13,4),%rdx
 1010c56:	add    %r13,%rdx
 1010c59:	lea    (%rsi,%rdx,2),%r13
 1010c5d:	movzbl (%rax),%ebx
 1010c60:	lea    -0x30(%rbx),%edx
 1010c63:	inc    %rax
 1010c66:	cmp    $0xa,%dl
 1010c69:	jb     1010c30 <main+0x1550>
 1010c6b:	mov    $0x1004458,%edi
 1010c70:	call   10275f0 <unsetenv@plt>
 1010c75:	mov    $0x10042dd,%edi
 1010c7a:	call   10275f0 <unsetenv@plt>
 1010c7f:	test   %bl,%bl
 1010c81:	jne    1010a4c <main+0x136c>
 1010c87:	lea    -0x9f0(%rbp),%rsi
 1010c8e:	mov    $0x9,%edi
 1010c93:	call   1027600 <getrlimit@plt>
 1010c98:	test   %eax,%eax
 1010c9a:	jne    1010a4c <main+0x136c>
 1010ca0:	cmp    %r15,-0x9f0(%rbp)
 1010ca7:	jne    1010a4c <main+0x136c>
 1010cad:	mov    -0x9e8(%rbp),%rcx
 1010cb4:	cmp    %rcx,%r13
 1010cb7:	mov    %rcx,%rax
 1010cba:	cmovb  %r13,%rax
 1010cbe:	cmp    $0xffffffffffffffff,%rcx
 1010cc2:	cmove  %r13,%rax
 1010cc6:	cmp    %r15,%rax
 1010cc9:	jbe    1010a4c <main+0x136c>
 1010ccf:	mov    %rax,-0x9f0(%rbp)
 1010cd6:	lea    -0x9f0(%rbp),%rsi
 1010cdd:	mov    $0x9,%edi
 1010ce2:	call   1027610 <setrlimit@plt>
 1010ce7:	jmp    1010a4c <main+0x136c>
 1010cec:	mov    $0x1,%edi
 1010cf1:	mov    $0x128,%esi
 1010cf6:	mov    %rax,%rbx
 1010cf9:	call   1027510 <calloc@plt>
 1010cfe:	mov    %rax,%rcx
 1010d01:	mov    %rbx,%rax
 1010d04:	test   %rcx,%rcx
 1010d07:	je     1010d96 <main+0x16b6>
 1010d0d:	vmovdqu -0x5515(%rip),%ymm0        # 100b800 <allocator>
 1010d15:	vmovdqu %ymm0,(%rcx)
 1010d19:	mov    %rax,0x20(%rcx)
 1010d1d:	movq   $0x128,0x30(%rcx)
 1010d25:	movq   $0x100b5f0,0x78(%rcx)
 1010d2d:	vpxor  %xmm0,%xmm0,%xmm0
 1010d31:	vmovdqu %xmm0,0x80(%rcx)
 1010d39:	movq   $0x3f,0x90(%rcx)
 1010d44:	vmovdqu 0x78(%rcx),%ymm1
 1010d49:	vmovdqu %ymm1,0x58(%rcx)
 1010d4e:	vmovdqu %ymm1,0x38(%rcx)
 1010d53:	vmovdqu %xmm0,0x98(%rcx)
 1010d5b:	movq   $0x0,0xa8(%rcx)
 1010d66:	movq   $0x580,0x270(%r15)
 1010d71:	mov    %rcx,0x1860(%r15)
 1010d78:	mov    $0x100ba68,%esi
 1010d7d:	mov    %r13,%rdi
 1010d80:	vzeroupper
 1010d83:	call   1019580 <myl_rc_module_register>
 1010d88:	test   %eax,%eax
 1010d8a:	je     1010db4 <main+0x16d4>
 1010d8c:	mov    %r13,%rdi
 1010d8f:	call   10188a0 <myl_rc_heap_destroy>
 1010d94:	jmp    1010da9 <main+0x16c9>
 1010d96:	movq   $0x0,0x270(%r15)
 1010da1:	mov    %rax,%rdi
 1010da4:	call   1027570 <free@plt>
 1010da9:	movl   $0x1,0x750(%r15)
 1010db4:	mov    -0x5c(%rbp),%eax
 1010db7:	mov    %eax,0x2c0(%r15)
 1010dbe:	mov    0x1860(%r15),%r8
 1010dc5:	test   %r8,%r8
 1010dc8:	je     10116f1 <main+0x2011>
 1010dce:	cmpq   $0x0,0xc0(%r8)
 1010dd6:	jne    10112a0 <main+0x1bc0>
 1010ddc:	mov    $0x1,%eax
 1010de1:	mov    $0xffffffffffffff40,%rcx
 1010de8:	nopl   0x0(%rax,%rax,1)
 1010df0:	mov    0x1003b58(%rcx),%rdx
 1010df7:	mov    (%rdx),%rsi
 1010dfa:	test   %rsi,%rsi
 1010dfd:	je     10112a0 <main+0x1bc0>
 1010e03:	cmp    0x1003448(%rcx),%rsi
 1010e0a:	jne    10112a0 <main+0x1bc0>
 1010e10:	mov    0x8(%rdx),%rdi
 1010e14:	cmp    (%rsi),%rdi
 1010e17:	jne    10112a0 <main+0x1bc0>
 1010e1d:	mov    0x38(%rdx),%rsi
 1010e21:	test   %rsi,%rsi
 1010e24:	je     10112a0 <main+0x1bc0>
 1010e2a:	cmp    $0x4,%rsi
 1010e2e:	ja     10112a0 <main+0x1bc0>
 1010e34:	cmp    %rsi,0x30(%rdx)
 1010e38:	ja     10112a0 <main+0x1bc0>
 1010e3e:	cmp    %rax,%rsi
 1010e41:	cmova  %rsi,%rax
 1010e45:	add    $0x8,%rcx
 1010e49:	jne    1010df0 <main+0x1710>
 1010e4b:	mov    %r8,-0x38(%rbp)
 1010e4f:	cmp    $0x4,%rax
 1010e53:	jne    10112a0 <main+0x1bc0>
 1010e59:	mov    $0x1009f7c,%eax
 1010e5e:	xor    %ecx,%ecx
 1010e60:	mov    $0xffff,%edx
 1010e65:	mov    $0x17fdddb,%esi
 1010e6a:	jmp    1010e92 <main+0x17b2>
 1010e6c:	nopl   0x0(%rax)
 1010e70:	movzbl 0x46(%rdi),%r8d
 1010e75:	or     0x44(%rdi),%r8b
 1010e79:	jne    10112a0 <main+0x1bc0>
 1010e7f:	inc    %rcx
 1010e82:	add    $0xc8,%rax
 1010e88:	cmp    $0x19,%rcx
 1010e8c:	je     10112a5 <main+0x1bc5>
 1010e92:	imul   $0xc8,%rcx,%rdi
 1010e99:	mov    0x1009ee8(%rdi),%r8
 1010ea0:	test   %r8,%r8
 1010ea3:	je     10112a0 <main+0x1bc0>
 1010ea9:	mov    0x1009ee0(%rdi),%r9
 1010eb0:	mov    %rcx,%r10
 1010eb3:	shl    $0x6,%r10
 1010eb7:	cmp    0x1003450(%r10),%r9
 1010ebe:	jne    10112a0 <main+0x1bc0>
 1010ec4:	mov    (%r9),%r10
 1010ec7:	cmp    (%r8),%r10
 1010eca:	jne    10112a0 <main+0x1bc0>
 1010ed0:	lea    0x1009ee0(%rdi),%rdi
 1010ed7:	cmp    %r10,0x50(%rdi)
 1010edb:	jne    10112a0 <main+0x1bc0>
 1010ee1:	cmp    $0x5,%rcx
 1010ee5:	je     1010e70 <main+0x1790>
 1010ee7:	cmp    $0x17,%rcx
 1010eeb:	je     1010e70 <main+0x1790>
 1010eed:	mov    0x40(%rdi),%r11d
 1010ef1:	movzwl 0x58(%rdi),%r8d
 1010ef6:	shrx   %r11d,%edx,%r9d
 1010efb:	shlx   %r11d,%r9d,%r9d
 1010f00:	xor    %r8d,%r9d
 1010f03:	cmp    $0xffff,%r9d
 1010f0a:	jne    10112a0 <main+0x1bc0>
 1010f10:	movzwl 0x5a(%rdi),%r9d
 1010f15:	andn   %r9d,%r8d,%ebx
 1010f1a:	jne    10112a0 <main+0x1bc0>
 1010f20:	bt     %rcx,%rsi
 1010f24:	jb     1010f56 <main+0x1876>
 1010f26:	sub    $0x8,%r10
 1010f2a:	jb     10112a0 <main+0x1bc0>
 1010f30:	xor    %ebx,%ebx
 1010f32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010f40:	movzwl (%rax,%rbx,2),%r14d
 1010f45:	cmp    %r14,%r10
 1010f48:	jb     10112a0 <main+0x1bc0>
 1010f4e:	inc    %rbx
 1010f51:	cmp    %rbx,%r11
 1010f54:	jne    1010f40 <main+0x1860>
 1010f56:	cmp    %r8w,%r9w
 1010f5a:	jne    10112a0 <main+0x1bc0>
 1010f60:	not    %r8d
 1010f63:	movzwl 0x5c(%rdi),%r10d
 1010f68:	test   %r8d,%r10d
 1010f6b:	jne    10112a0 <main+0x1bc0>
 1010f71:	and    %r9d,%r10d
 1010f74:	cmp    %r9d,%r10d
 1010f77:	jne    10112a0 <main+0x1bc0>
 1010f7d:	movzwl 0x5e(%rdi),%r10d
 1010f82:	test   %r8d,%r10d
 1010f85:	jne    10112a0 <main+0x1bc0>
 1010f8b:	and    %r9d,%r10d
 1010f8e:	cmp    %r9d,%r10d
 1010f91:	jne    10112a0 <main+0x1bc0>
 1010f97:	movzwl 0x60(%rdi),%r10d
 1010f9c:	test   %r8d,%r10d
 1010f9f:	jne    10112a0 <main+0x1bc0>
 1010fa5:	and    %r9d,%r10d
 1010fa8:	cmp    %r9d,%r10d
 1010fab:	jne    10112a0 <main+0x1bc0>
 1010fb1:	movzwl 0x62(%rdi),%r10d
 1010fb6:	test   %r8d,%r10d
 1010fb9:	jne    10112a0 <main+0x1bc0>
 1010fbf:	and    %r9d,%r10d
 1010fc2:	cmp    %r9d,%r10d
 1010fc5:	jne    10112a0 <main+0x1bc0>
 1010fcb:	movzwl 0x64(%rdi),%r10d
 1010fd0:	test   %r8d,%r10d
 1010fd3:	jne    10112a0 <main+0x1bc0>
 1010fd9:	and    %r9d,%r10d
 1010fdc:	cmp    %r9d,%r10d
 1010fdf:	jne    10112a0 <main+0x1bc0>
 1010fe5:	movzwl 0x66(%rdi),%r10d
 1010fea:	test   %r8d,%r10d
 1010fed:	jne    10112a0 <main+0x1bc0>
 1010ff3:	and    %r9d,%r10d
 1010ff6:	cmp    %r9d,%r10d
 1010ff9:	jne    10112a0 <main+0x1bc0>
 1010fff:	movzwl 0x68(%rdi),%r10d
 1011004:	test   %r8d,%r10d
 1011007:	jne    10112a0 <main+0x1bc0>
 101100d:	and    %r9d,%r10d
 1011010:	cmp    %r9d,%r10d
 1011013:	jne    10112a0 <main+0x1bc0>
 1011019:	movzwl 0x6a(%rdi),%r10d
 101101e:	test   %r8d,%r10d
 1011021:	jne    10112a0 <main+0x1bc0>
 1011027:	and    %r9d,%r10d
 101102a:	cmp    %r9d,%r10d
 101102d:	jne    10112a0 <main+0x1bc0>
 1011033:	movzwl 0x6c(%rdi),%r10d
 1011038:	test   %r8d,%r10d
 101103b:	jne    10112a0 <main+0x1bc0>
 1011041:	and    %r9d,%r10d
 1011044:	cmp    %r9d,%r10d
 1011047:	jne    10112a0 <main+0x1bc0>
 101104d:	movzwl 0x6e(%rdi),%r10d
 1011052:	test   %r8d,%r10d
 1011055:	jne    10112a0 <main+0x1bc0>
 101105b:	and    %r9d,%r10d
 101105e:	cmp    %r9d,%r10d
 1011061:	jne    10112a0 <main+0x1bc0>
 1011067:	movzwl 0x70(%rdi),%r10d
 101106c:	test   %r8d,%r10d
 101106f:	jne    10112a0 <main+0x1bc0>
 1011075:	and    %r9d,%r10d
 1011078:	cmp    %r9d,%r10d
 101107b:	jne    10112a0 <main+0x1bc0>
 1011081:	movzwl 0x72(%rdi),%r10d
 1011086:	test   %r8d,%r10d
 1011089:	jne    10112a0 <main+0x1bc0>
 101108f:	and    %r9d,%r10d
 1011092:	cmp    %r9d,%r10d
 1011095:	jne    10112a0 <main+0x1bc0>
 101109b:	movzwl 0x74(%rdi),%r10d
 10110a0:	test   %r8d,%r10d
 10110a3:	jne    10112a0 <main+0x1bc0>
 10110a9:	and    %r9d,%r10d
 10110ac:	cmp    %r9d,%r10d
 10110af:	jne    10112a0 <main+0x1bc0>
 10110b5:	movzwl 0x76(%rdi),%r10d
 10110ba:	test   %r8d,%r10d
 10110bd:	jne    10112a0 <main+0x1bc0>
 10110c3:	and    %r9d,%r10d
 10110c6:	cmp    %r9d,%r10d
 10110c9:	jne    10112a0 <main+0x1bc0>
 10110cf:	movzwl 0x78(%rdi),%r10d
 10110d4:	test   %r8d,%r10d
 10110d7:	jne    10112a0 <main+0x1bc0>
 10110dd:	and    %r9d,%r10d
 10110e0:	cmp    %r9d,%r10d
 10110e3:	jne    10112a0 <main+0x1bc0>
 10110e9:	movzwl 0x7a(%rdi),%r10d
 10110ee:	test   %r8d,%r10d
 10110f1:	jne    10112a0 <main+0x1bc0>
 10110f7:	and    %r9d,%r10d
 10110fa:	cmp    %r9d,%r10d
 10110fd:	jne    10112a0 <main+0x1bc0>
 1011103:	movzwl 0x7c(%rdi),%r10d
 1011108:	test   %r8d,%r10d
 101110b:	jne    10112a0 <main+0x1bc0>
 1011111:	and    %r9d,%r10d
 1011114:	cmp    %r9d,%r10d
 1011117:	jne    10112a0 <main+0x1bc0>
 101111d:	movzwl 0x7e(%rdi),%r10d
 1011122:	test   %r8d,%r10d
 1011125:	jne    10112a0 <main+0x1bc0>
 101112b:	and    %r9d,%r10d
 101112e:	cmp    %r9d,%r10d
 1011131:	jne    10112a0 <main+0x1bc0>
 1011137:	movzwl 0x80(%rdi),%r10d
 101113f:	test   %r8d,%r10d
 1011142:	jne    10112a0 <main+0x1bc0>
 1011148:	and    %r9d,%r10d
 101114b:	cmp    %r9d,%r10d
 101114e:	jne    10112a0 <main+0x1bc0>
 1011154:	movzwl 0x82(%rdi),%r10d
 101115c:	test   %r8d,%r10d
 101115f:	jne    10112a0 <main+0x1bc0>
 1011165:	and    %r9d,%r10d
 1011168:	cmp    %r9d,%r10d
 101116b:	jne    10112a0 <main+0x1bc0>
 1011171:	movzwl 0x84(%rdi),%r10d
 1011179:	test   %r8d,%r10d
 101117c:	jne    10112a0 <main+0x1bc0>
 1011182:	and    %r9d,%r10d
 1011185:	cmp    %r9d,%r10d
 1011188:	jne    10112a0 <main+0x1bc0>
 101118e:	movzwl 0x86(%rdi),%r10d
 1011196:	test   %r8d,%r10d
 1011199:	jne    10112a0 <main+0x1bc0>
 101119f:	and    %r9d,%r10d
 10111a2:	cmp    %r9d,%r10d
 10111a5:	jne    10112a0 <main+0x1bc0>
 10111ab:	movzwl 0x88(%rdi),%r10d
 10111b3:	test   %r8d,%r10d
 10111b6:	jne    10112a0 <main+0x1bc0>
 10111bc:	and    %r9d,%r10d
 10111bf:	cmp    %r9d,%r10d
 10111c2:	jne    10112a0 <main+0x1bc0>
 10111c8:	movzwl 0x8a(%rdi),%r10d
 10111d0:	test   %r8d,%r10d
 10111d3:	jne    10112a0 <main+0x1bc0>
 10111d9:	and    %r9d,%r10d
 10111dc:	cmp    %r9d,%r10d
 10111df:	jne    10112a0 <main+0x1bc0>
 10111e5:	movzwl 0x8c(%rdi),%r10d
 10111ed:	test   %r8d,%r10d
 10111f0:	jne    10112a0 <main+0x1bc0>
 10111f6:	and    %r9d,%r10d
 10111f9:	cmp    %r9d,%r10d
 10111fc:	jne    10112a0 <main+0x1bc0>
 1011202:	movzwl 0x8e(%rdi),%r10d
 101120a:	test   %r8d,%r10d
 101120d:	jne    10112a0 <main+0x1bc0>
 1011213:	and    %r9d,%r10d
 1011216:	cmp    %r9d,%r10d
 1011219:	jne    10112a0 <main+0x1bc0>
 101121f:	movzwl 0x90(%rdi),%r10d
 1011227:	test   %r8d,%r10d
 101122a:	jne    10112a0 <main+0x1bc0>
 101122c:	and    %r9d,%r10d
 101122f:	cmp    %r9d,%r10d
 1011232:	jne    10112a0 <main+0x1bc0>
 1011234:	movzwl 0x92(%rdi),%r10d
 101123c:	test   %r8d,%r10d
 101123f:	jne    10112a0 <main+0x1bc0>
 1011241:	and    %r9d,%r10d
 1011244:	cmp    %r9d,%r10d
 1011247:	jne    10112a0 <main+0x1bc0>
 1011249:	movzwl 0x94(%rdi),%r10d
 1011251:	test   %r8d,%r10d
 1011254:	jne    10112a0 <main+0x1bc0>
 1011256:	and    %r9d,%r10d
 1011259:	cmp    %r9d,%r10d
 101125c:	jne    10112a0 <main+0x1bc0>
 101125e:	movzwl 0x96(%rdi),%r10d
 1011266:	test   %r8d,%r10d
 1011269:	jne    10112a0 <main+0x1bc0>
 101126b:	and    %r9d,%r10d
 101126e:	cmp    %r9d,%r10d
 1011271:	jne    10112a0 <main+0x1bc0>
 1011273:	movzwl 0x98(%rdi),%r10d
 101127b:	test   %r8d,%r10d
 101127e:	jne    10112a0 <main+0x1bc0>
 1011280:	and    %r9d,%r10d
 1011283:	cmp    %r9d,%r10d
 1011286:	jne    10112a0 <main+0x1bc0>
 1011288:	movzwl 0x9a(%rdi),%edi
 101128f:	test   %r8d,%edi
 1011292:	jne    10112a0 <main+0x1bc0>
 1011294:	and    %r9d,%edi
 1011297:	cmp    %r9d,%edi
 101129a:	je     1010e7f <main+0x179f>
 10112a0:	call   10187d4 <myl_rc_invariant_failed>
 10112a5:	mov    -0x38(%rbp),%rcx
 10112a9:	mov    0x38(%rcx),%rax
 10112ad:	mov    0x40(%rcx),%rdx
 10112b1:	movzbl 0x50(%rcx),%ecx
 10112b5:	mov    $0x100b298,%esi
 10112ba:	movabs $0x9e3779b97f4a7c15,%rdi
 10112c4:	imul   %rsi,%rdi
 10112c8:	shrx   %rcx,%rdi,%rcx
 10112cd:	nopl   (%rax)
 10112d0:	and    %rdx,%rcx
 10112d3:	mov    %rcx,%rsi
 10112d6:	shl    $0x4,%rsi
 10112da:	mov    (%rax,%rsi,1),%rsi
 10112de:	cmp    $0x100b298,%rsi
 10112e5:	je     10112f1 <main+0x1c11>
 10112e7:	test   %rsi,%rsi
 10112ea:	je     1011301 <main+0x1c21>
 10112ec:	inc    %rcx
 10112ef:	jmp    10112d0 <main+0x1bf0>
 10112f1:	shl    $0x4,%rcx
 10112f5:	cmpq   $0x0,0x8(%rax,%rcx,1)
 10112fb:	jne    10114af <main+0x1dcf>
 1011301:	mov    $0x13c8,%ebx
 1011306:	add    0x270(%r15),%rbx
 101130d:	jb     10115d8 <main+0x1ef8>
 1011313:	mov    0x2b0(%r15),%r12
 101131a:	test   %r12,%r12
 101131d:	setne  %al
 1011320:	cmp    %r12,%rbx
 1011323:	seta   %cl
 1011326:	and    %al,%cl
 1011328:	cmp    $0x1,%cl
 101132b:	je     10115d8 <main+0x1ef8>
 1011331:	mov    $0x1,%edi
 1011336:	mov    $0x13c8,%esi
 101133b:	call   1027510 <calloc@plt>
 1011340:	test   %rax,%rax
 1011343:	je     101191f <main+0x223f>
 1011349:	mov    %rax,%r13
 101134c:	mov    %rbx,0x270(%r15)
 1011353:	mov    -0x38(%rbp),%r14
 1011357:	addq   $0x13c8,0x30(%r14)
 101135f:	movq   $0x100b298,0x8(%rax)
 1011367:	movq   $0x100b268,0x38(%rax)
 101136f:	movq   $0x19,0x20(%rax)
 1011377:	movq   $0x19,0x28(%rax)
 101137f:	movq   $0x13c8,0x30(%rax)
 1011387:	mov    %rax,%rdi
 101138a:	add    $0x40,%rdi
 101138e:	mov    %rdi,0x18(%rax)
 1011392:	mov    $0x1009ee0,%esi
 1011397:	mov    $0x1388,%edx
 101139c:	call   1027520 <memcpy@plt>
 10113a1:	movq   $0x0,-0x30(%rbp)
 10113a9:	cmpq   $0x3,0xb8(%r14)
 10113b1:	mov    $0x0,%r14d
 10113b7:	ja     1011415 <main+0x1d35>
 10113b9:	test   %r12,%r12
 10113bc:	setne  %al
 10113bf:	lea    0x60(%rbx),%rcx
 10113c3:	cmp    %r12,%rcx
 10113c6:	seta   %cl
 10113c9:	mov    %rbx,%r14
 10113cc:	add    $0x60,%r14
 10113d0:	jb     10118db <main+0x21fb>
 10113d6:	and    %cl,%al
 10113d8:	jne    10118db <main+0x21fb>
 10113de:	mov    $0x1,%edi
 10113e3:	mov    $0x60,%esi
 10113e8:	call   1027510 <calloc@plt>
 10113ed:	test   %rax,%rax
 10113f0:	je     10118e6 <main+0x2206>
 10113f6:	mov    %rax,%rcx
 10113f9:	mov    $0x60,%eax
 10113fe:	mov    %rax,-0x30(%rbp)
 1011402:	mov    %r14,0x270(%r15)
 1011409:	mov    -0x38(%rbp),%rax
 101140d:	addq   $0x60,0x30(%rax)
 1011412:	mov    %rcx,%r14
 1011415:	lea    -0x9f0(%rbp),%r8
 101141c:	mov    $0x1,%esi
 1011421:	mov    $0x32,%edx
 1011426:	lea    0x258(%r15),%rbx
 101142d:	mov    %rbx,%rdi
 1011430:	mov    %r13,%rcx
 1011433:	call   101a5f0 <index_prepare>
 1011438:	test   %eax,%eax
 101143a:	je     10117b2 <main+0x20d2>
 1011440:	lea    -0x9f0(%rbp),%rdx
 1011447:	mov    %rbx,%rdi
 101144a:	mov    %r13,%rsi
 101144d:	call   101a9a0 <index_commit>
 1011452:	mov    0x1860(%r15),%rax
 1011459:	test   %r14,%r14
 101145c:	lea    -0x3790(%rbp),%r12
 1011463:	je     101149c <main+0x1dbc>
 1011465:	mov    0xb0(%rax),%rsi
 101146c:	mov    0xb8(%rax),%rax
 1011473:	shl    $0x3,%rax
 1011477:	lea    (%rax,%rax,2),%rdx
 101147b:	mov    %rbx,%rdi
 101147e:	call   1018860 <myl_rc_meta_free>
 1011483:	mov    0x1860(%r15),%rax
 101148a:	mov    %r14,0xb0(%rax)
 1011491:	movq   $0x4,0xb8(%rax)
 101149c:	mov    0x28(%rax),%rcx
 10114a0:	mov    %rcx,0x0(%r13)
 10114a4:	mov    %r13,0x28(%rax)
 10114a8:	lea    0x258(%r15),%r13
 10114af:	mov    0x20(%r15),%rax
 10114b3:	test   %rax,%rax
 10114b6:	jne    1011956 <main+0x2276>
 10114bc:	mov    $0x20,%esi
 10114c1:	mov    -0x68(%rbp),%rdi
 10114c5:	call   1027510 <calloc@plt>
 10114ca:	mov    %rax,0x28(%r15)
 10114ce:	test   %rax,%rax
 10114d1:	je     101159f <main+0x1ebf>
 10114d7:	call   1027620 <fegetround@plt>
 10114dc:	test   %eax,%eax
 10114de:	jne    1011793 <main+0x20b3>
 10114e4:	movabs $0x10000000000000,%rax
 10114ee:	mov    %rax,-0x9f0(%rbp)
 10114f5:	movabs $0x3fe0000000000000,%rax
 10114ff:	mov    %rax,-0xdf0(%rbp)
 1011506:	movq   $0x1,-0x50(%rbp)
 101150e:	movabs $0x3ff0000000000000,%rax
 1011518:	mov    %rax,-0xa8(%rbp)
 101151f:	vmovsd -0x9f0(%rbp),%xmm0
 1011527:	vmulsd -0xdf0(%rbp),%xmm0,%xmm0
 101152f:	vmovq  %xmm0,%rax
 1011534:	movabs $0x8000000000000,%rcx
 101153e:	cmp    %rcx,%rax
 1011541:	jne    1011793 <main+0x20b3>
 1011547:	vmovsd -0x50(%rbp),%xmm0
 101154c:	vmulsd -0xa8(%rbp),%xmm0,%xmm0
 1011554:	vmovq  %xmm0,%rax
 1011559:	cmp    $0x1,%rax
 101155d:	jne    1011793 <main+0x20b3>
 1011563:	mov    0x20(%r15),%rax
 1011567:	test   %rax,%rax
 101156a:	jne    1011956 <main+0x2276>
 1011570:	mov    %r15,%rdi
 1011573:	call   1018370 <myl_qbe_on_stack>
 1011578:	mov    %rax,-0x3f0(%rbp)
 101157f:	mov    0x20(%r15),%rax
 1011583:	test   %rax,%rax
 1011586:	jne    1011956 <main+0x2276>
 101158c:	mov    $0x1004416,%eax
 1011591:	cmpq   $0x0,0x8(%r15)
 1011596:	jne    10115a4 <main+0x1ec4>
 1011598:	xor    %eax,%eax
 101159a:	jmp    1011956 <main+0x2276>
 101159f:	mov    $0x1003b92,%eax
 10115a4:	mov    %rax,0x20(%r15)
 10115a8:	jmp    1011956 <main+0x2276>
 10115ad:	mov    %rax,%rdi
 10115b0:	call   1027570 <free@plt>
 10115b5:	mov    0x175dc(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10115bc:	mov    (%rax),%rcx
 10115bf:	mov    $0x1004d77,%edi
 10115c4:	mov    $0x21,%esi
 10115c9:	mov    $0x1,%edx
 10115ce:	call   10275d0 <fwrite@plt>
 10115d3:	jmp    10118c4 <main+0x21e4>
 10115d8:	movl   $0x1,0x2c4(%r15)
 10115e3:	jmp    101191f <main+0x223f>
 10115e8:	mov    $0x1,%r14d
 10115ee:	test   %edx,%edx
 10115f0:	je     10109fc <main+0x131c>
 10115f6:	mov    %rcx,-0x3e0(%rbp)
 10115fd:	lea    -0xdf0(%rbp),%rdi
 1011604:	mov    $0x400,%edx
 1011609:	xor    %esi,%esi
 101160b:	call   10274d0 <memset@plt>
 1011610:	movq   $0x0,-0x9f0(%rbp)
 101161b:	movb   $0x0,-0xdf0(%rbp)
 1011622:	mov    -0x1c0(%rbp),%eax
 1011628:	mov    %eax,-0x38(%rbp)
 101162b:	test   %eax,%eax
 101162d:	je     10120ef <main+0x2a0f>
 1011633:	mov    -0x1bc(%rbp),%ebx
 1011639:	test   $0x1,%bl
 101163c:	jne    1011687 <main+0x1fa7>
 101163e:	test   $0x2,%bl
 1011641:	jne    1011768 <main+0x2088>
 1011647:	mov    -0x190(%rbp),%r8
 101164e:	test   $0x1c,%bl
 1011651:	jne    1011804 <main+0x2124>
 1011657:	test   %r8,%r8
 101165a:	je     10120ef <main+0x2a0f>
 1011660:	cmpb   $0x0,(%r8)
 1011664:	je     10120ef <main+0x2a0f>
 101166a:	lea    -0xdf0(%rbp),%rdi
 1011671:	lea    -0x9f0(%rbp),%rdx
 1011678:	mov    $0x400,%esi
 101167d:	mov    $0x1003d57,%ecx
 1011682:	jmp    1011787 <main+0x20a7>
 1011687:	mov    -0x1b8(%rbp),%r8
 101168e:	lea    -0xdf0(%rbp),%rdi
 1011695:	lea    -0x9f0(%rbp),%rdx
 101169c:	mov    $0x400,%esi
 10116a1:	mov    $0x1004113,%ecx
 10116a6:	xor    %eax,%eax
 10116a8:	call   1015310 <append>
 10116ad:	test   %eax,%eax
 10116af:	je     10120ef <main+0x2a0f>
 10116b5:	test   $0x2,%bl
 10116b8:	je     10120d0 <main+0x29f0>
 10116be:	mov    -0x1b0(%rbp),%r8
 10116c5:	lea    -0xdf0(%rbp),%rdi
 10116cc:	lea    -0x9f0(%rbp),%rdx
 10116d3:	mov    $0x400,%esi
 10116d8:	mov    $0x1003cad,%ecx
 10116dd:	xor    %eax,%eax
 10116df:	call   1015310 <append>
 10116e4:	test   %eax,%eax
 10116e6:	jne    10120d0 <main+0x29f0>
 10116ec:	jmp    10120ef <main+0x2a0f>
 10116f1:	mov    $0x1004361,%esi
 10116f6:	cmpl   $0x0,0x2c4(%r15)
 10116fe:	je     101193c <main+0x225c>
 1011704:	jmp    1011941 <main+0x2261>
 1011709:	lea    -0x3790(%rbp),%r12
 1011710:	mov    0x17481(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1011717:	mov    (%rax),%rcx
 101171a:	mov    $0x1004eda,%edi
 101171f:	mov    $0x38,%esi
 1011724:	mov    $0x1,%edx
 1011729:	vzeroupper
 101172c:	call   10275d0 <fwrite@plt>
 1011731:	mov    $0x2,%r15d
 1011737:	mov    $0x70,%ebx
 101173c:	jmp    10125a8 <main+0x2ec8>
 1011741:	mov    0x17450(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1011748:	mov    (%rax),%rcx
 101174b:	mov    $0x1004d45,%edi
 1011750:	mov    $0x31,%esi
 1011755:	mov    $0x1,%edx
 101175a:	call   10275d0 <fwrite@plt>
 101175f:	mov    -0x78(%rbp),%rdi
 1011763:	jmp    10118bf <main+0x21df>
 1011768:	mov    -0x1b0(%rbp),%r8
 101176f:	lea    -0xdf0(%rbp),%rdi
 1011776:	lea    -0x9f0(%rbp),%rdx
 101177d:	mov    $0x400,%esi
 1011782:	mov    $0x100466f,%ecx
 1011787:	xor    %eax,%eax
 1011789:	call   1015310 <append>
 101178e:	jmp    10120ef <main+0x2a0f>
 1011793:	mov    $0x10042fa,%esi
 1011798:	mov    %r15,%rdi
 101179b:	call   1014a6d <fail>
 10117a0:	mov    0x20(%r15),%rax
 10117a4:	test   %rax,%rax
 10117a7:	jne    1011956 <main+0x2276>
 10117ad:	jmp    1011570 <main+0x1e90>
 10117b2:	mov    0x270(%r15),%rbx
 10117b9:	test   %r14,%r14
 10117bc:	je     10117f2 <main+0x2112>
 10117be:	mov    -0x30(%rbp),%rdx
 10117c2:	sub    %rdx,%rbx
 10117c5:	jb     10112a0 <main+0x1bc0>
 10117cb:	mov    0x1860(%r15),%rax
 10117d2:	mov    0x30(%rax),%rcx
 10117d6:	sub    %rdx,%rcx
 10117d9:	jb     10112a0 <main+0x1bc0>
 10117df:	mov    %rbx,0x270(%r15)
 10117e6:	mov    %rcx,0x30(%rax)
 10117ea:	mov    %r14,%rdi
 10117ed:	call   1027570 <free@plt>
 10117f2:	cmp    $0x13c8,%rbx
 10117f9:	jae    10118e6 <main+0x2206>
 10117ff:	jmp    10112a0 <main+0x1bc0>
 1011804:	test   %r8,%r8
 1011807:	mov    $0x10042b6,%eax
 101180c:	cmovne %r8,%rax
 1011810:	lea    -0xdf0(%rbp),%rdi
 1011817:	lea    -0x9f0(%rbp),%rdx
 101181e:	mov    $0x400,%esi
 1011823:	mov    $0x100450d,%ecx
 1011828:	mov    %rax,%r8
 101182b:	xor    %eax,%eax
 101182d:	call   1015310 <append>
 1011832:	test   %eax,%eax
 1011834:	je     10120ef <main+0x2a0f>
 101183a:	test   $0x20,%bl
 101183d:	jne    1012043 <main+0x2963>
 1011843:	test   $0x4,%bl
 1011846:	je     1011876 <main+0x2196>
 1011848:	mov    -0x1a8(%rbp),%r8
 101184f:	lea    -0xdf0(%rbp),%rdi
 1011856:	lea    -0x9f0(%rbp),%rdx
 101185d:	mov    $0x400,%esi
 1011862:	mov    $0x100412b,%ecx
 1011867:	xor    %eax,%eax
 1011869:	call   1015310 <append>
 101186e:	test   %eax,%eax
 1011870:	je     10120ef <main+0x2a0f>
 1011876:	test   $0x8,%bl
 1011879:	je     10120a1 <main+0x29c1>
 101187f:	mov    -0x1a0(%rbp),%r8
 1011886:	lea    -0xdf0(%rbp),%rdi
 101188d:	lea    -0x9f0(%rbp),%rdx
 1011894:	mov    $0x400,%esi
 1011899:	mov    $0x100411f,%ecx
 101189e:	jmp    1012096 <main+0x29b6>
 10118a3:	mov    $0x1004766,%esi
 10118a8:	mov    0x172e9(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10118af:	mov    (%rax),%rdi
 10118b2:	mov    %r15,%rdx
 10118b5:	xor    %eax,%eax
 10118b7:	call   10275e0 <fprintf@plt>
 10118bc:	mov    %r14,%rdi
 10118bf:	call   1027570 <free@plt>
 10118c4:	mov    -0x90(%rbp),%rdi
 10118cb:	call   1027570 <free@plt>
 10118d0:	mov    $0x2,%r15d
 10118d6:	jmp    101263a <main+0x2f5a>
 10118db:	movl   $0x1,0x2c4(%r15)
 10118e6:	mov    0x1860(%r15),%rax
 10118ed:	mov    0x30(%rax),%rcx
 10118f1:	cmp    $0x13c7,%rcx
 10118f8:	jbe    10112a0 <main+0x1bc0>
 10118fe:	add    $0xffffffffffffec38,%rbx
 1011905:	mov    %rbx,0x270(%r15)
 101190c:	add    $0xffffffffffffec38,%rcx
 1011913:	mov    %rcx,0x30(%rax)
 1011917:	mov    %r13,%rdi
 101191a:	call   1027570 <free@plt>
 101191f:	mov    $0x1004361,%esi
 1011924:	cmpl   $0x0,0x2c4(%r15)
 101192c:	lea    -0x3790(%rbp),%r12
 1011933:	lea    0x258(%r15),%r13
 101193a:	jne    1011941 <main+0x2261>
 101193c:	mov    $0x1003b92,%esi
 1011941:	mov    %r15,%rdi
 1011944:	call   1014a6d <fail>
 1011949:	mov    0x20(%r15),%rax
 101194d:	test   %rax,%rax
 1011950:	je     10114bc <main+0x1ddc>
 1011956:	mov    (%r15),%rcx
 1011959:	mov    %rcx,-0x3e8(%rbp)
 1011960:	mov    %rax,-0x3e0(%rbp)
 1011967:	vmovups 0x248(%r15),%xmm0
 1011970:	vmovups %xmm0,-0x1d8(%rbp)
 1011978:	mov    0x39e0(%r15),%eax
 101197f:	mov    %eax,-0x1c8(%rbp)
 1011985:	vmovdqu 0x39e8(%r15),%ymm0
 101198e:	vmovdqu 0x3a00(%r15),%ymm1
 1011997:	vmovdqu %ymm0,-0x1c0(%rbp)
 101199f:	vmovdqu %ymm1,-0x1a8(%rbp)
 10119a7:	lea    -0x3d8(%rbp),%rdi
 10119ae:	lea    0x48(%r15),%rsi
 10119b2:	mov    $0x200,%edx
 10119b7:	vzeroupper
 10119ba:	call   1027520 <memcpy@plt>
 10119bf:	mov    0x3e80(%r15),%rax
 10119c6:	test   %rax,%rax
 10119c9:	je     10119d0 <main+0x22f0>
 10119cb:	mov    %r15,%rdi
 10119ce:	call   *%rax
 10119d0:	mov    0x39a0(%r15),%rax
 10119d7:	test   %rax,%rax
 10119da:	je     10119e1 <main+0x2301>
 10119dc:	mov    %r15,%rdi
 10119df:	call   *%rax
 10119e1:	mov    0x3e78(%r15),%rax
 10119e8:	test   %rax,%rax
 10119eb:	je     10119f2 <main+0x2312>
 10119ed:	mov    %r15,%rdi
 10119f0:	call   *%rax
 10119f2:	mov    0x20(%r15),%rax
 10119f6:	test   %rax,%rax
 10119f9:	je     1011a14 <main+0x2334>
 10119fb:	mov    0x1860(%r15),%r9
 1011a02:	test   %r9,%r9
 1011a05:	je     1011f34 <main+0x2854>
 1011a0b:	lea    0x2c8(%r15),%r14
 1011a12:	jmp    1011a56 <main+0x2376>
 1011a14:	cmpl   $0x0,0x2c0(%r15)
 1011a1c:	jne    1011a36 <main+0x2356>
 1011a1e:	cmpq   $0x0,0x3990(%r15)
 1011a26:	jne    1011a36 <main+0x2356>
 1011a28:	cmpq   $0x0,0x3998(%r15)
 1011a30:	je     1011f34 <main+0x2854>
 1011a36:	mov    0x1860(%r15),%r9
 1011a3d:	test   %r9,%r9
 1011a40:	je     1011f34 <main+0x2854>
 1011a46:	lea    0x2c8(%r15),%r14
 1011a4d:	test   %rax,%rax
 1011a50:	je     1011ead <main+0x27cd>
 1011a56:	mov    %r15,%rbx
 1011a59:	add    $0x328,%rbx
 1011a60:	mov    0xf8(%r9),%r12
 1011a67:	movq   $0x0,0xf8(%r9)
 1011a72:	test   %r12,%r12
 1011a75:	je     1011b69 <main+0x2489>
 1011a7b:	mov    %r14,-0x38(%rbp)
 1011a7f:	mov    %rbx,%r14
 1011a82:	vpxor  %xmm0,%xmm0,%xmm0
 1011a86:	jmp    1011aaf <main+0x23cf>
 1011a88:	nopl   0x0(%rax,%rax,1)
 1011a90:	add    $0x8,%r12
 1011a94:	vmovdqu %xmm0,(%r12)
 1011a9a:	movl   $0x0,0x10(%r12)
 1011aa3:	mov    %r13,%r12
 1011aa6:	test   %r13,%r13
 1011aa9:	je     1011b52 <main+0x2472>
 1011aaf:	mov    0x8(%r12),%r13
 1011ab4:	mov    0x10(%r12),%rsi
 1011ab9:	test   %rsi,%rsi
 1011abc:	je     1011a90 <main+0x23b0>
 1011abe:	xchg   %ax,%ax
 1011ac0:	mov    (%rsi),%rbx
 1011ac3:	mov    0x1860(%r15),%rax
 1011aca:	mov    0x108(%rax),%rcx
 1011ad1:	cmp    $0x20,%rcx
 1011ad5:	je     1011b31 <main+0x2451>
 1011ad7:	mov    0x270(%r15),%rdx
 1011ade:	cmp    $0x28,%rdx
 1011ae2:	jb     10112a0 <main+0x1bc0>
 1011ae8:	mov    0x30(%rax),%rdi
 1011aec:	cmp    $0x27,%rdi
 1011af0:	jbe    10112a0 <main+0x1bc0>
 1011af6:	add    $0xffffffffffffffd8,%rdx
 1011afa:	mov    %rdx,0x270(%r15)
 1011b01:	add    $0xffffffffffffffd8,%rdi
 1011b05:	mov    %rdi,0x30(%rax)
 1011b09:	mov    0x100(%rax),%rdx
 1011b10:	mov    %rdx,(%rsi)
 1011b13:	mov    %rsi,0x100(%rax)
 1011b1a:	inc    %rcx
 1011b1d:	mov    %rcx,0x108(%rax)
 1011b24:	mov    %rbx,%rsi
 1011b27:	test   %rbx,%rbx
 1011b2a:	jne    1011ac0 <main+0x23e0>
 1011b2c:	jmp    1011a90 <main+0x23b0>
 1011b31:	lea    0x258(%r15),%rdi
 1011b38:	call   101e38f <entry_release>
 1011b3d:	vpxor  %xmm0,%xmm0,%xmm0
 1011b41:	mov    %rbx,%rsi
 1011b44:	test   %rbx,%rbx
 1011b47:	jne    1011ac0 <main+0x23e0>
 1011b4d:	jmp    1011a90 <main+0x23b0>
 1011b52:	mov    0x1860(%r15),%r9
 1011b59:	test   %r9,%r9
 1011b5c:	mov    %r14,%rbx
 1011b5f:	mov    -0x38(%rbp),%r14
 1011b63:	je     10112a0 <main+0x1bc0>
 1011b69:	mov    0x13f8(%r15),%rax
 1011b70:	test   %rax,%rax
 1011b73:	je     1011b9f <main+0x24bf>
 1011b75:	mov    0x818(%r15),%rcx
 1011b7c:	sub    %rax,%rcx
 1011b7f:	add    $0xffffffffffffffb0,%rcx
 1011b83:	mov    %rcx,0x10(%rax)
 1011b87:	movq   $0x0,0x13f8(%r15)
 1011b92:	vpxor  %xmm0,%xmm0,%xmm0
 1011b96:	vmovdqu %xmm0,0x818(%r15)
 1011b9f:	mov    0x1440(%r15),%rsi
 1011ba6:	test   %rsi,%rsi
 1011ba9:	je     1011bcc <main+0x24ec>
 1011bab:	mov    0x730(%r15),%rax
 1011bb2:	test   $0x1,%sil
 1011bb6:	jne    1011bed <main+0x250d>
 1011bb8:	xor    %edx,%edx
 1011bba:	mov    %rsi,%rcx
 1011bbd:	mov    %rdx,%rdi
 1011bc0:	cmp    $0x1,%rsi
 1011bc4:	jne    1011fe0 <main+0x2900>
 1011bca:	jmp    1011c2e <main+0x254e>
 1011bcc:	movl   $0x0,(%r14)
 1011bd3:	mov    $0x400,%edx
 1011bd8:	mov    %rbx,%rdi
 1011bdb:	xor    %esi,%esi
 1011bdd:	mov    %r9,%rbx
 1011be0:	call   10274d0 <memset@plt>
 1011be5:	mov    %rbx,%r8
 1011be8:	jmp    1011d72 <main+0x2692>
 1011bed:	lea    -0x1(%rsi),%rcx
 1011bf1:	mov    -0x8(%rax,%rsi,8),%rdi
 1011bf6:	movq   $0x0,-0x8(%rax,%rsi,8)
 1011bff:	test   %rdi,%rdi
 1011c02:	je     1011fba <main+0x28da>
 1011c08:	xor    %r8d,%r8d
 1011c0b:	nopl   0x0(%rax,%rax,1)
 1011c10:	mov    %rdi,%rdx
 1011c13:	mov    (%rdi),%rdi
 1011c16:	mov    %r8,(%rdx)
 1011c19:	mov    %rdx,%r8
 1011c1c:	test   %rdi,%rdi
 1011c1f:	jne    1011c10 <main+0x2530>
 1011c21:	mov    %rdx,%rdi
 1011c24:	cmp    $0x1,%rsi
 1011c28:	jne    1011fe0 <main+0x2900>
 1011c2e:	movq   $0x0,0x1440(%r15)
 1011c39:	test   %rdi,%rdi
 1011c3c:	je     1011d46 <main+0x2666>
 1011c42:	mov    $0x200000,%r12d
 1011c48:	jmp    1011c68 <main+0x2588>
 1011c4a:	nopw   0x0(%rax,%rax,1)
 1011c50:	sub    %rcx,0x270(%r15)
 1011c57:	call   1027570 <free@plt>
 1011c5c:	mov    %r13,%rdi
 1011c5f:	test   %r13,%r13
 1011c62:	je     1011d3f <main+0x265f>
 1011c68:	mov    (%rdi),%r13
 1011c6b:	mov    0x18(%rdi),%rax
 1011c6f:	sub    %rax,0x298(%r15)
 1011c76:	mov    0x18(%rdi),%rax
 1011c7a:	add    %rax,0x2d8(%r15)
 1011c81:	vmovdqu 0x300(%r15),%xmm0
 1011c8a:	vmovdqa -0x103b2(%rip),%xmm1        # 10018e0 <__abi_tag+0x15e4>
 1011c92:	vpinsrq $0x1,0x8(%rdi),%xmm1,%xmm1
 1011c99:	vpsubq %xmm1,%xmm0,%xmm0
 1011c9d:	vmovdqu %xmm0,0x300(%r15)
 1011ca6:	mov    0x2b0(%r15),%rax
 1011cad:	cmp    $0x200000,%rax
 1011cb3:	mov    $0x200000,%ecx
 1011cb8:	cmovb  %rax,%rcx
 1011cbc:	test   %rax,%rax
 1011cbf:	mov    %rcx,%rax
 1011cc2:	cmove  %r12,%rax
 1011cc6:	cmpq   $0x0,0x1860(%r15)
 1011cce:	cmove  %rcx,%rax
 1011cd2:	mov    0x8(%rdi),%rcx
 1011cd6:	cmp    $0x100000,%rcx
 1011cdd:	ja     1011c50 <main+0x2570>
 1011ce3:	mov    0x318(%r15),%rdx
 1011cea:	cmp    $0x3,%rdx
 1011cee:	ja     1011c50 <main+0x2570>
 1011cf4:	mov    0x320(%r15),%rsi
 1011cfb:	sub    %rsi,%rax
 1011cfe:	jbe    1011c50 <main+0x2570>
 1011d04:	cmp    %rax,%rcx
 1011d07:	ja     1011c50 <main+0x2570>
 1011d0d:	mov    0x738(%r15),%rax
 1011d14:	mov    %rax,(%rdi)
 1011d17:	mov    %rdi,0x738(%r15)
 1011d1e:	inc    %rdx
 1011d21:	mov    %rdx,0x318(%r15)
 1011d28:	add    0x8(%rdi),%rsi
 1011d2c:	mov    %rsi,0x320(%r15)
 1011d33:	mov    %r13,%rdi
 1011d36:	test   %r13,%r13
 1011d39:	jne    1011c68 <main+0x2588>
 1011d3f:	mov    0x1860(%r15),%r9
 1011d46:	movl   $0x0,(%r14)
 1011d4d:	mov    $0x400,%edx
 1011d52:	mov    %rbx,%rdi
 1011d55:	xor    %esi,%esi
 1011d57:	mov    %r9,%rbx
 1011d5a:	call   10274d0 <memset@plt>
 1011d5f:	mov    %rbx,%r8
 1011d62:	test   %rbx,%rbx
 1011d65:	lea    -0x3790(%rbp),%r12
 1011d6c:	je     1011f34 <main+0x2854>
 1011d72:	mov    0xf8(%r8),%rbx
 1011d79:	movq   $0x0,0xf8(%r8)
 1011d84:	test   %rbx,%rbx
 1011d87:	je     1011e68 <main+0x2788>
 1011d8d:	vpxor  %xmm0,%xmm0,%xmm0
 1011d91:	jmp    1011dbb <main+0x26db>
 1011d93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011da0:	add    $0x8,%rbx
 1011da4:	vmovdqu %xmm0,(%rbx)
 1011da8:	movl   $0x0,0x10(%rbx)
 1011daf:	mov    %r12,%rbx
 1011db2:	test   %r12,%r12
 1011db5:	je     1011e68 <main+0x2788>
 1011dbb:	mov    0x8(%rbx),%r12
 1011dbf:	mov    0x10(%rbx),%rsi
 1011dc3:	test   %rsi,%rsi
 1011dc6:	je     1011da0 <main+0x26c0>
 1011dc8:	nopl   0x0(%rax,%rax,1)
 1011dd0:	mov    (%rsi),%r13
 1011dd3:	mov    0x1860(%r15),%rax
 1011dda:	mov    0x108(%rax),%rcx
 1011de1:	cmp    $0x20,%rcx
 1011de5:	je     1011e41 <main+0x2761>
 1011de7:	mov    0x270(%r15),%rdx
 1011dee:	cmp    $0x28,%rdx
 1011df2:	jb     10112a0 <main+0x1bc0>
 1011df8:	mov    0x30(%rax),%rdi
 1011dfc:	cmp    $0x27,%rdi
 1011e00:	jbe    10112a0 <main+0x1bc0>
 1011e06:	add    $0xffffffffffffffd8,%rdx
 1011e0a:	mov    %rdx,0x270(%r15)
 1011e11:	add    $0xffffffffffffffd8,%rdi
 1011e15:	mov    %rdi,0x30(%rax)
 1011e19:	mov    0x100(%rax),%rdx
 1011e20:	mov    %rdx,(%rsi)
 1011e23:	mov    %rsi,0x100(%rax)
 1011e2a:	inc    %rcx
 1011e2d:	mov    %rcx,0x108(%rax)
 1011e34:	mov    %r13,%rsi
 1011e37:	test   %r13,%r13
 1011e3a:	jne    1011dd0 <main+0x26f0>
 1011e3c:	jmp    1011da0 <main+0x26c0>
 1011e41:	lea    0x258(%r15),%rdi
 1011e48:	mov    %r8,%r14
 1011e4b:	call   101e38f <entry_release>
 1011e50:	vpxor  %xmm0,%xmm0,%xmm0
 1011e54:	mov    %r14,%r8
 1011e57:	mov    %r13,%rsi
 1011e5a:	test   %r13,%r13
 1011e5d:	jne    1011dd0 <main+0x26f0>
 1011e63:	jmp    1011da0 <main+0x26c0>
 1011e68:	movl   $0x0,0x124(%r8)
 1011e73:	vpxor  %xmm0,%xmm0,%xmm0
 1011e77:	vmovdqu %xmm0,0xc0(%r8)
 1011e80:	movl   $0x0,0xd0(%r8)
 1011e8b:	mov    0x18(%r8),%rax
 1011e8f:	test   %rax,%rax
 1011e92:	je     10112a0 <main+0x1bc0>
 1011e98:	lea    0x258(%r15),%rdi
 1011e9f:	call   *%rax
 1011ea1:	lea    -0x3790(%rbp),%r12
 1011ea8:	jmp    1011f34 <main+0x2854>
 1011ead:	xor    %ebx,%ebx
 1011eaf:	mov    %r13,%rdi
 1011eb2:	xor    %esi,%esi
 1011eb4:	call   101e3a0 <myl_rc_scope_unwind>
 1011eb9:	mov    %r13,%rdi
 1011ebc:	call   1017190 <myl_native_arena_release>
 1011ec1:	movl   $0x0,(%r14)
 1011ec8:	jmp    1011edc <main+0x27fc>
 1011eca:	nopw   0x0(%rax,%rax,1)
 1011ed0:	inc    %rbx
 1011ed3:	cmp    $0x80,%rbx
 1011eda:	je     1011f34 <main+0x2854>
 1011edc:	mov    0x328(%r15,%rbx,8),%rsi
 1011ee4:	movq   $0x0,0x328(%r15,%rbx,8)
 1011ef0:	mov    %r13,%rdi
 1011ef3:	call   1018bc0 <myl_rc_edge_release>
 1011ef8:	mov    0x1860(%r15),%rax
 1011eff:	test   %rax,%rax
 1011f02:	je     1011ed0 <main+0x27f0>
 1011f04:	cmpq   $0x0,0xc8(%rax)
 1011f0c:	je     1011ed0 <main+0x27f0>
 1011f0e:	mov    %r13,%rdi
 1011f11:	call   101bcb0 <myl_rc_drain>
 1011f16:	jmp    1011ed0 <main+0x27f0>
 1011f18:	nopl   0x0(%rax,%rax,1)
 1011f20:	mov    %rcx,0x39c8(%r15)
 1011f27:	test   %rcx,%rcx
 1011f2a:	je     1011f2f <main+0x284f>
 1011f2c:	mov    %rax,(%rcx)
 1011f2f:	call   1027570 <free@plt>
 1011f34:	mov    0x39c8(%r15),%rdi
 1011f3b:	test   %rdi,%rdi
 1011f3e:	je     1011f57 <main+0x2877>
 1011f40:	mov    (%rdi),%rax
 1011f43:	mov    0x8(%rdi),%rcx
 1011f47:	test   %rax,%rax
 1011f4a:	je     1011f20 <main+0x2840>
 1011f4c:	mov    %rcx,0x8(%rax)
 1011f50:	test   %rcx,%rcx
 1011f53:	jne    1011f2c <main+0x284c>
 1011f55:	jmp    1011f2f <main+0x284f>
 1011f57:	mov    0x39a8(%r15),%rdi
 1011f5e:	call   1027570 <free@plt>
 1011f63:	mov    0x28(%r15),%rdi
 1011f67:	call   1027570 <free@plt>
 1011f6c:	mov    0x20(%r15),%rbx
 1011f70:	mov    %r15,%rdi
 1011f73:	call   1027570 <free@plt>
 1011f78:	test   %rbx,%rbx
 1011f7b:	je     1011f95 <main+0x28b5>
 1011f7d:	mov    $0x2,%r15d
 1011f83:	cmpl   $0x0,-0x1c8(%rbp)
 1011f8a:	jne    1012558 <main+0x2e78>
 1011f90:	jmp    10115fd <main+0x1f1d>
 1011f95:	mov    -0x3f0(%rbp),%rbx
 1011f9c:	cmpb   $0x0,-0x44(%rbp)
 1011fa0:	jne    1011fb1 <main+0x28d1>
 1011fa2:	mov    $0x1004ed5,%edi
 1011fa7:	mov    %rbx,%rsi
 1011faa:	xor    %eax,%eax
 1011fac:	call   1027630 <printf@plt>
 1011fb1:	movzbl %bl,%r15d
 1011fb5:	jmp    1012558 <main+0x2e78>
 1011fba:	xor    %edx,%edx
 1011fbc:	mov    %rdx,%rdi
 1011fbf:	cmp    $0x1,%rsi
 1011fc3:	jne    1011fe0 <main+0x2900>
 1011fc5:	jmp    1011c2e <main+0x254e>
 1011fca:	nopw   0x0(%rax,%rax,1)
 1011fd0:	mov    %rdx,%rdi
 1011fd3:	mov    %rdi,%rdx
 1011fd6:	add    $0xfffffffffffffffe,%rcx
 1011fda:	je     1011c2e <main+0x254e>
 1011fe0:	mov    -0x8(%rax,%rcx,8),%rsi
 1011fe5:	movq   $0x0,-0x8(%rax,%rcx,8)
 1011fee:	test   %rsi,%rsi
 1011ff1:	je     1012011 <main+0x2931>
 1011ff3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1012000:	mov    (%rsi),%rdi
 1012003:	mov    %rdx,(%rsi)
 1012006:	mov    %rsi,%rdx
 1012009:	mov    %rdi,%rsi
 101200c:	test   %rdi,%rdi
 101200f:	jne    1012000 <main+0x2920>
 1012011:	mov    -0x10(%rax,%rcx,8),%rsi
 1012016:	movq   $0x0,-0x10(%rax,%rcx,8)
 101201f:	test   %rsi,%rsi
 1012022:	je     1011fd0 <main+0x28f0>
 1012024:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1012030:	mov    %rsi,%rdi
 1012033:	mov    (%rsi),%rsi
 1012036:	mov    %rdx,(%rdi)
 1012039:	mov    %rdi,%rdx
 101203c:	test   %rsi,%rsi
 101203f:	jne    1012030 <main+0x2950>
 1012041:	jmp    1011fd3 <main+0x28f3>
 1012043:	test   $0x4,%bl
 1012046:	je     1012072 <main+0x2992>
 1012048:	mov    -0x1a8(%rbp),%r8
 101204f:	lea    -0xdf0(%rbp),%rdi
 1012056:	lea    -0x9f0(%rbp),%rdx
 101205d:	mov    $0x400,%esi
 1012062:	mov    $0x1003ca3,%ecx
 1012067:	xor    %eax,%eax
 1012069:	call   1015310 <append>
 101206e:	test   %eax,%eax
 1012070:	je     10120ef <main+0x2a0f>
 1012072:	test   $0x8,%bl
 1012075:	je     10120a1 <main+0x29c1>
 1012077:	mov    -0x1a0(%rbp),%r8
 101207e:	lea    -0xdf0(%rbp),%rdi
 1012085:	lea    -0x9f0(%rbp),%rdx
 101208c:	mov    $0x400,%esi
 1012091:	mov    $0x1003c97,%ecx
 1012096:	xor    %eax,%eax
 1012098:	call   1015310 <append>
 101209d:	test   %eax,%eax
 101209f:	je     10120ef <main+0x2a0f>
 10120a1:	test   $0x10,%bl
 10120a4:	je     10120d0 <main+0x29f0>
 10120a6:	mov    -0x198(%rbp),%r8
 10120ad:	lea    -0xdf0(%rbp),%rdi
 10120b4:	lea    -0x9f0(%rbp),%rdx
 10120bb:	mov    $0x400,%esi
 10120c0:	mov    $0x1003cba,%ecx
 10120c5:	xor    %eax,%eax
 10120c7:	call   1015310 <append>
 10120cc:	test   %eax,%eax
 10120ce:	je     10120ef <main+0x2a0f>
 10120d0:	lea    -0xdf0(%rbp),%rdi
 10120d7:	lea    -0x9f0(%rbp),%rdx
 10120de:	mov    $0x400,%esi
 10120e3:	mov    $0x1004702,%ecx
 10120e8:	xor    %eax,%eax
 10120ea:	call   1015310 <append>
 10120ef:	mov    -0x3e0(%rbp),%r14
 10120f6:	mov    $0x100438a,%esi
 10120fb:	mov    %r14,%rdi
 10120fe:	call   1027540 <strcmp@plt>
 1012103:	test   %eax,%eax
 1012105:	sete   %al
 1012108:	mov    -0x1d8(%rbp),%r15
 101210f:	cmp    $0x2,%r15
 1012113:	setae  %cl
 1012116:	and    %al,%cl
 1012118:	cmp    $0x1,%cl
 101211b:	jne    101216b <main+0x2a8b>
 101211d:	lea    -0xdf0(%rbp),%r13
 1012124:	mov    %r13,%rdi
 1012127:	call   10274f0 <strlen@plt>
 101212c:	mov    %rax,-0x9f0(%rbp)
 1012133:	mov    -0x3b8(%rbp),%r8
 101213a:	mov    -0x3b0(%rbp),%r9
 1012141:	vmovdqu -0x3a8(%rbp),%xmm0
 1012149:	vmovdqu %xmm0,(%rsp)
 101214e:	lea    -0x9f0(%rbp),%rdx
 1012155:	mov    $0x400,%esi
 101215a:	mov    $0x1003c3b,%ecx
 101215f:	mov    %r13,%rdi
 1012162:	xor    %eax,%eax
 1012164:	call   1015310 <append>
 1012169:	jmp    10121a6 <main+0x2ac6>
 101216b:	test   %r15,%r15
 101216e:	jne    10121a6 <main+0x2ac6>
 1012170:	mov    0x16a21(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1012177:	mov    (%rax),%r12
 101217a:	mov    %r14,%rdi
 101217d:	call   10153d0 <describe>
 1012182:	lea    -0xdf0(%rbp),%r8
 1012189:	mov    $0x10048a4,%esi
 101218e:	mov    %r12,%rdi
 1012191:	mov    %r14,%rbx
 1012194:	mov    %r14,%rdx
 1012197:	mov    %rax,%rcx
 101219a:	xor    %eax,%eax
 101219c:	call   10275e0 <fprintf@plt>
 10121a1:	jmp    101223e <main+0x2b5e>
 10121a6:	mov    0x169eb(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10121ad:	mov    (%rax),%r13
 10121b0:	mov    -0x3d0(%rbp),%rax
 10121b7:	mov    %rax,-0x30(%rbp)
 10121bb:	mov    -0x3c8(%rbp),%rax
 10121c2:	mov    %rax,-0x40(%rbp)
 10121c6:	lea    -0x3c0(%rbp),%r12
 10121cd:	mov    -0x3c0(%rbp),%rbx
 10121d4:	mov    %r14,%rdi
 10121d7:	call   10153d0 <describe>
 10121dc:	lea    -0xdf0(%rbp),%rcx
 10121e3:	mov    %rcx,0x8(%rsp)
 10121e8:	mov    %rax,(%rsp)
 10121ec:	mov    $0x10048ae,%esi
 10121f1:	mov    %r13,%rdi
 10121f4:	mov    -0x30(%rbp),%rdx
 10121f8:	mov    -0x40(%rbp),%rcx
 10121fc:	mov    %rbx,%r8
 10121ff:	mov    %r14,%rbx
 1012202:	mov    %r14,%r9
 1012205:	mov    0x1698c(%rip),%r14        # 1028b98 <stderr@GLIBC_2.2.5>
 101220c:	xor    %eax,%eax
 101220e:	call   10275e0 <fprintf@plt>
 1012213:	mov    -0x18(%r12),%rdx
 1012218:	mov    -0x10(%r12),%rcx
 101221d:	mov    -0x8(%r12),%r8
 1012222:	mov    (%r12),%r9
 1012226:	mov    (%r14),%rdi
 1012229:	mov    $0x100474f,%esi
 101222e:	xor    %eax,%eax
 1012230:	call   10275e0 <fprintf@plt>
 1012235:	add    $0x20,%r12
 1012239:	dec    %r15
 101223c:	jne    1012213 <main+0x2b33>
 101223e:	movq   $0x0,-0x50(%rbp)
 1012246:	movb   $0x0,-0x9f0(%rbp)
 101224d:	mov    -0x38(%rbp),%r8d
 1012251:	test   %r8d,%r8d
 1012254:	je     10124f0 <main+0x2e10>
 101225a:	mov    -0x1bc(%rbp),%eax
 1012260:	mov    %eax,-0x30(%rbp)
 1012263:	lea    -0x9f0(%rbp),%rdi
 101226a:	lea    -0x50(%rbp),%rdx
 101226e:	mov    $0x600,%esi
 1012273:	mov    $0x1004513,%ecx
 1012278:	xor    %eax,%eax
 101227a:	call   1015310 <append>
 101227f:	test   %eax,%eax
 1012281:	je     10124f0 <main+0x2e10>
 1012287:	mov    -0x190(%rbp),%r14
 101228e:	lea    -0x9f0(%rbp),%rdi
 1012295:	lea    -0x50(%rbp),%rdx
 1012299:	mov    $0x600,%esi
 101229e:	mov    $0x1004704,%ecx
 10122a3:	xor    %eax,%eax
 10122a5:	call   1015310 <append>
 10122aa:	test   %eax,%eax
 10122ac:	je     10124f0 <main+0x2e10>
 10122b2:	test   %r14,%r14
 10122b5:	mov    $0x1003e6d,%r13d
 10122bb:	cmovne %r14,%r13
 10122bf:	movzbl 0x0(%r13),%eax
 10122c4:	test   %al,%al
 10122c6:	je     1012336 <main+0x2c56>
 10122c8:	inc    %r13
 10122cb:	lea    -0x9f0(%rbp),%r15
 10122d2:	lea    -0x50(%rbp),%r12
 10122d6:	cs nopw 0x0(%rax,%rax,1)
 10122e0:	movzbl %al,%r8d
 10122e4:	cmp    $0x5c,%r8b
 10122e8:	je     10122f0 <main+0x2c10>
 10122ea:	cmp    $0x22,%r8d
 10122ee:	jne    101231d <main+0x2c3d>
 10122f0:	mov    $0x600,%esi
 10122f5:	mov    $0x10042c1,%ecx
 10122fa:	mov    %r15,%rdi
 10122fd:	mov    %r12,%rdx
 1012300:	xor    %eax,%eax
 1012302:	call   1015310 <append>
 1012307:	test   %eax,%eax
 1012309:	je     10124f0 <main+0x2e10>
 101230f:	movzbl 0x0(%r13),%eax
 1012314:	inc    %r13
 1012317:	test   %al,%al
 1012319:	jne    10122e0 <main+0x2c00>
 101231b:	jmp    1012336 <main+0x2c56>
 101231d:	mov    $0x600,%esi
 1012322:	cmp    $0x1f,%r8b
 1012326:	ja     101232f <main+0x2c4f>
 1012328:	mov    $0x1003c28,%ecx
 101232d:	jmp    10122fa <main+0x2c1a>
 101232f:	mov    $0x10042c2,%ecx
 1012334:	jmp    10122fa <main+0x2c1a>
 1012336:	lea    -0x9f0(%rbp),%rdi
 101233d:	lea    -0x50(%rbp),%rdx
 1012341:	mov    $0x600,%esi
 1012346:	mov    $0x1004704,%ecx
 101234b:	xor    %eax,%eax
 101234d:	call   1015310 <append>
 1012352:	test   %eax,%eax
 1012354:	je     10124f0 <main+0x2e10>
 101235a:	testb  $0x1,-0x30(%rbp)
 101235e:	je     101238b <main+0x2cab>
 1012360:	mov    -0x1b8(%rbp),%r8
 1012367:	lea    -0x9f0(%rbp),%rdi
 101236e:	lea    -0x50(%rbp),%rdx
 1012372:	mov    $0x600,%esi
 1012377:	mov    $0x10040ed,%ecx
 101237c:	xor    %eax,%eax
 101237e:	call   1015310 <append>
 1012383:	test   %eax,%eax
 1012385:	je     10124f0 <main+0x2e10>
 101238b:	testb  $0x2,-0x30(%rbp)
 101238f:	je     10123bc <main+0x2cdc>
 1012391:	mov    -0x1b0(%rbp),%r8
 1012398:	lea    -0x9f0(%rbp),%rdi
 101239f:	lea    -0x50(%rbp),%rdx
 10123a3:	mov    $0x600,%esi
 10123a8:	mov    $0x1003c7c,%ecx
 10123ad:	xor    %eax,%eax
 10123af:	call   1015310 <append>
 10123b4:	test   %eax,%eax
 10123b6:	je     10124f0 <main+0x2e10>
 10123bc:	mov    -0x30(%rbp),%eax
 10123bf:	test   $0x20,%al
 10123c1:	jne    101241a <main+0x2d3a>
 10123c3:	test   $0x4,%al
 10123c5:	je     10123f2 <main+0x2d12>
 10123c7:	mov    -0x1a8(%rbp),%r8
 10123ce:	lea    -0x9f0(%rbp),%rdi
 10123d5:	lea    -0x50(%rbp),%rdx
 10123d9:	mov    $0x600,%esi
 10123de:	mov    $0x1004107,%ecx
 10123e3:	xor    %eax,%eax
 10123e5:	call   1015310 <append>
 10123ea:	test   %eax,%eax
 10123ec:	je     10124f0 <main+0x2e10>
 10123f2:	testb  $0x8,-0x30(%rbp)
 10123f6:	je     101249c <main+0x2dbc>
 10123fc:	mov    -0x1a0(%rbp),%r8
 1012403:	lea    -0x9f0(%rbp),%rdi
 101240a:	lea    -0x50(%rbp),%rdx
 101240e:	mov    $0x600,%esi
 1012413:	mov    $0x10040fa,%ecx
 1012418:	jmp    1012491 <main+0x2db1>
 101241a:	lea    -0x9f0(%rbp),%rdi
 1012421:	lea    -0x50(%rbp),%rdx
 1012425:	mov    $0x600,%esi
 101242a:	mov    $0x10040bd,%ecx
 101242f:	xor    %eax,%eax
 1012431:	call   1015310 <append>
 1012436:	test   %eax,%eax
 1012438:	je     10124f0 <main+0x2e10>
 101243e:	testb  $0x4,-0x30(%rbp)
 1012442:	je     101246f <main+0x2d8f>
 1012444:	mov    -0x1a8(%rbp),%r8
 101244b:	lea    -0x9f0(%rbp),%rdi
 1012452:	lea    -0x50(%rbp),%rdx
 1012456:	mov    $0x600,%esi
 101245b:	mov    $0x1003c70,%ecx
 1012460:	xor    %eax,%eax
 1012462:	call   1015310 <append>
 1012467:	test   %eax,%eax
 1012469:	je     10124f0 <main+0x2e10>
 101246f:	testb  $0x8,-0x30(%rbp)
 1012473:	je     101249c <main+0x2dbc>
 1012475:	mov    -0x1a0(%rbp),%r8
 101247c:	lea    -0x9f0(%rbp),%rdi
 1012483:	lea    -0x50(%rbp),%rdx
 1012487:	mov    $0x600,%esi
 101248c:	mov    $0x1003c63,%ecx
 1012491:	xor    %eax,%eax
 1012493:	call   1015310 <append>
 1012498:	test   %eax,%eax
 101249a:	je     10124f0 <main+0x2e10>
 101249c:	testb  $0x10,-0x30(%rbp)
 10124a0:	je     10124c9 <main+0x2de9>
 10124a2:	mov    -0x198(%rbp),%r8
 10124a9:	lea    -0x9f0(%rbp),%rdi
 10124b0:	lea    -0x50(%rbp),%rdx
 10124b4:	mov    $0x600,%esi
 10124b9:	mov    $0x1003c8a,%ecx
 10124be:	xor    %eax,%eax
 10124c0:	call   1015310 <append>
 10124c5:	test   %eax,%eax
 10124c7:	je     10124f0 <main+0x2e10>
 10124c9:	lea    -0x9f0(%rbp),%rdi
 10124d0:	lea    -0x50(%rbp),%rdx
 10124d4:	mov    $0x600,%esi
 10124d9:	mov    $0x1003b90,%ecx
 10124de:	xor    %eax,%eax
 10124e0:	call   1015310 <append>
 10124e5:	test   %eax,%eax
 10124e7:	je     10124f0 <main+0x2e10>
 10124e9:	cmpq   $0x0,-0x50(%rbp)
 10124ee:	jne    1012524 <main+0x2e44>
 10124f0:	mov    $0x2,%r15d
 10124f6:	cmpb   $0x52,(%rbx)
 10124f9:	lea    -0x3790(%rbp),%r12
 1012500:	jne    1012558 <main+0x2e78>
 1012502:	xor    %r15d,%r15d
 1012505:	cmpb   $0x5f,0x1(%rbx)
 1012509:	setne  %r15b
 101250d:	inc    %r15d
 1012510:	mov    $0x70,%ebx
 1012515:	jmp    10125a8 <main+0x2ec8>
 101251a:	mov    $0x10048df,%esi
 101251f:	jmp    10118a8 <main+0x21c8>
 1012524:	mov    0x1666d(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 101252b:	mov    (%rax),%rdi
 101252e:	lea    -0x9f0(%rbp),%rcx
 1012535:	mov    $0x10048c5,%esi
 101253a:	mov    $0x1004706,%edx
 101253f:	xor    %eax,%eax
 1012541:	call   10275e0 <fprintf@plt>
 1012546:	mov    $0x2,%r15d
 101254c:	cmpb   $0x52,(%rbx)
 101254f:	lea    -0x3790(%rbp),%r12
 1012556:	je     1012502 <main+0x2e22>
 1012558:	mov    $0x70,%ebx
 101255d:	jmp    10125a8 <main+0x2ec8>
 101255f:	nop
 1012560:	vzeroupper
 1012563:	call   1027640 <close@plt>
 1012568:	mov    -0x3790(%rbp,%rbx,1),%rdi
 1012570:	vzeroupper
 1012573:	call   1027570 <free@plt>
 1012578:	movl   $0xffffffff,-0x3798(%rbp,%rbx,1)
 1012583:	vpxor  %xmm0,%xmm0,%xmm0
 1012587:	vmovdqu %ymm0,-0x3794(%rbp,%rbx,1)
 1012590:	movl   $0x0,-0x3774(%rbp,%rbx,1)
 101259b:	add    $0x28,%rbx
 101259f:	cmp    $0x2870,%rbx
 10125a6:	je     10125c2 <main+0x2ee2>
 10125a8:	mov    -0x3798(%rbp,%rbx,1),%edi
 10125af:	test   %edi,%edi
 10125b1:	jns    1012560 <main+0x2e80>
 10125b3:	mov    -0x3790(%rbp,%rbx,1),%rdi
 10125bb:	test   %rdi,%rdi
 10125be:	jne    1012570 <main+0x2e90>
 10125c0:	jmp    101259b <main+0x2ebb>
 10125c2:	cmpq   $0x0,-0x3730(%rbp)
 10125ca:	je     10125ec <main+0x2f0c>
 10125cc:	xor    %ebx,%ebx
 10125ce:	xchg   %ax,%ax
 10125d0:	mov    (%r12),%edi
 10125d4:	vzeroupper
 10125d7:	call   1027640 <close@plt>
 10125dc:	inc    %rbx
 10125df:	add    $0xc,%r12
 10125e3:	cmp    -0x3730(%rbp),%rbx
 10125ea:	jb     10125d0 <main+0x2ef0>
 10125ec:	movq   $0x0,-0x3730(%rbp)
 10125f7:	cmpq   $0x0,-0xea8(%rbp)
 10125ff:	je     101262b <main+0x2f4b>
 1012601:	lea    -0xf28(%rbp),%rbx
 1012608:	xor    %r14d,%r14d
 101260b:	nopl   0x0(%rax,%rax,1)
 1012610:	mov    (%rbx),%rdi
 1012613:	vzeroupper
 1012616:	call   1027570 <free@plt>
 101261b:	inc    %r14
 101261e:	add    $0x10,%rbx
 1012622:	cmp    -0xea8(%rbp),%r14
 1012629:	jb     1012610 <main+0x2f30>
 101262b:	mov    -0x90(%rbp),%rdi
 1012632:	vzeroupper
 1012635:	call   1027570 <free@plt>
 101263a:	mov    %r15d,%eax
 101263d:	add    $0x3778,%rsp
 1012644:	pop    %rbx
 1012645:	pop    %r12
 1012647:	pop    %r13
 1012649:	pop    %r14
 101264b:	pop    %r15
 101264d:	pop    %rbp
 101264e:	ret
 101264f:	int3

0000000001012650 <entry_run>:
 1012650:	push   %rbp
 1012651:	mov    %rsp,%rbp
 1012654:	push   %r15
 1012656:	push   %r14
 1012658:	push   %r13
 101265a:	push   %r12
 101265c:	push   %rbx
 101265d:	sub    $0x408,%rsp
 1012664:	cmpq   $0x0,0x39a8(%rdi)
 101266c:	mov    %rdi,-0x30(%rbp)
 1012670:	je     1012682 <entry_run+0x32>
 1012672:	cmpq   $0x0,0x20(%rdi)
 1012677:	jne    1014488 <entry_run+0x1e38>
 101267d:	jmp    10127a5 <entry_run+0x155>
 1012682:	mov    $0x1,%edi
 1012687:	mov    $0x40,%esi
 101268c:	call   1027510 <calloc@plt>
 1012691:	test   %rax,%rax
 1012694:	je     1012778 <entry_run+0x128>
 101269a:	mov    -0x30(%rbp),%rcx
 101269e:	mov    %rax,0x39a8(%rcx)
 10126a5:	mov    0x3978(%rcx),%rcx
 10126ac:	lea    0xa0(%rcx),%rdx
 10126b3:	test   %rcx,%rcx
 10126b6:	mov    $0x1003b58,%ecx
 10126bb:	cmovne %rdx,%rcx
 10126bf:	mov    %rcx,(%rax)
 10126c2:	cmpq   $0x0,0x8(%rcx)
 10126c7:	je     10126d3 <entry_run+0x83>
 10126c9:	cmpq   $0x0,(%rcx)
 10126cd:	je     1012786 <entry_run+0x136>
 10126d3:	mov    0x10(%rcx),%rdx
 10126d7:	test   %rdx,%rdx
 10126da:	mov    $0x2710,%esi
 10126df:	cmovne %rdx,%rsi
 10126e3:	mov    %rsi,0x18(%rax)
 10126e7:	mov    0x18(%rcx),%rdx
 10126eb:	test   %rdx,%rdx
 10126ee:	mov    $0xf4240,%esi
 10126f3:	cmovne %rdx,%rsi
 10126f7:	mov    %rsi,0x10(%rax)
 10126fb:	mov    0x20(%rcx),%rdx
 10126ff:	test   %rdx,%rdx
 1012702:	mov    $0x10000,%edi
 1012707:	cmovne %rdx,%rdi
 101270b:	mov    %rdi,0x20(%rax)
 101270f:	mov    0x28(%rcx),%rsi
 1012713:	test   %rsi,%rsi
 1012716:	mov    $0x40,%edx
 101271b:	cmovne %rsi,%rdx
 101271f:	mov    %rdx,0x28(%rax)
 1012723:	mov    0x30(%rcx),%r8
 1012727:	test   %r8,%r8
 101272a:	mov    $0x100000,%esi
 101272f:	cmovne %r8,%rsi
 1012733:	mov    %rsi,0x30(%rax)
 1012737:	cmp    $0x186a0,%rdi
 101273e:	ja     1012771 <entry_run+0x121>
 1012740:	cmp    $0x80,%rdx
 1012747:	ja     1012771 <entry_run+0x121>
 1012749:	cmp    $0x4000001,%rsi
 1012750:	jae    1012771 <entry_run+0x121>
 1012752:	cmpq   $0x0,0x8(%rcx)
 1012757:	jne    101277f <entry_run+0x12f>
 1012759:	movl   $0x1,0x38(%rax)
 1012760:	mov    -0x30(%rbp),%rdi
 1012764:	cmpq   $0x0,0x20(%rdi)
 1012769:	jne    1014488 <entry_run+0x1e38>
 101276f:	jmp    10127a5 <entry_run+0x155>
 1012771:	mov    $0x1003cfa,%esi
 1012776:	jmp    101278b <entry_run+0x13b>
 1012778:	mov    $0x1003b92,%esi
 101277d:	jmp    101278b <entry_run+0x13b>
 101277f:	mov    $0x1003e41,%esi
 1012784:	jmp    101278b <entry_run+0x13b>
 1012786:	mov    $0x1003e55,%esi
 101278b:	mov    -0x30(%rbp),%rbx
 101278f:	mov    %rbx,%rdi
 1012792:	call   1014a6d <fail>
 1012797:	mov    %rbx,%rdi
 101279a:	cmpq   $0x0,0x20(%rdi)
 101279f:	jne    1014488 <entry_run+0x1e38>
 10127a5:	cmp    %rsp,0x40(%rdi)
 10127a9:	ja     10145a3 <entry_run+0x1f53>
 10127af:	movq   $0x0,-0x48(%rbp)
 10127b7:	movq   $0x0,-0x80(%rbp)
 10127bf:	mov    0x2c8(%rdi),%r15d
 10127c6:	movl   $0x0,-0x50(%rbp)
 10127cd:	cmpq   $0xffffffffffffffff,0x10(%rdi)
 10127d2:	jne    1013077 <entry_run+0xa27>
 10127d8:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 10127dd:	jne    10130c7 <entry_run+0xa77>
 10127e3:	cmpq   $0x0,0x1860(%rdi)
 10127eb:	mov    %rdi,%rbx
 10127ee:	je     101311d <entry_run+0xacd>
 10127f4:	lea    0x258(%rbx),%rdi
 10127fb:	mov    0x2c8(%rbx),%ecx
 1012801:	mov    $0x10022c8,%esi
 1012806:	mov    $0x6,%edx
 101280b:	mov    %rdi,-0x38(%rbp)
 101280f:	call   1017730 <rc_list_new>
 1012814:	test   %rax,%rax
 1012817:	je     101311d <entry_run+0xacd>
 101281d:	movabs $0x5000000000000000,%rcx
 1012827:	mov    %rax,-0x1c0(%rbp)
 101282e:	mov    %rax,-0x58(%rbp)
 1012832:	mov    -0x10(%rax),%rdx
 1012836:	lea    0x1(%rcx),%rsi
 101283a:	test   %rsi,%rdx
 101283d:	je     101297f <entry_run+0x32f>
 1012843:	test   %rcx,%rdx
 1012846:	je     1012953 <entry_run+0x303>
 101284c:	mov    0x1860(%rbx),%rdi
 1012853:	cmpq   $0x1a,0xa0(%rdi)
 101285b:	jb     10143f9 <entry_run+0x1da9>
 1012861:	mov    0x98(%rdi),%rax
 1012868:	cmpq   $0x1002338,0x190(%rax)
 1012873:	jne    10143f9 <entry_run+0x1da9>
 1012879:	mov    0x198(%rax),%r12
 1012880:	test   %r12,%r12
 1012883:	je     1014413 <entry_run+0x1dc3>
 1012889:	mov    0x8(%r12),%r14
 101288e:	cmpl   $0x1,0x8(%r14)
 1012893:	jne    101298c <entry_run+0x33c>
 1012899:	movq   $0x0,-0xf8(%rbp)
 10128a4:	mov    0x1860(%rbx),%rcx
 10128ab:	test   %rcx,%rcx
 10128ae:	je     10144fc <entry_run+0x1eac>
 10128b4:	mov    $0x3,%eax
 10128b9:	cmp    0x2c8(%rbx),%r15d
 10128c0:	ja     1012a1c <entry_run+0x3cc>
 10128c6:	mov    -0x58(%rbp),%rax
 10128ca:	test   %rax,%rax
 10128cd:	je     1012915 <entry_run+0x2c5>
 10128cf:	mov    -0x10(%rax),%rdx
 10128d3:	test   $0x2,%dl
 10128d6:	jne    1012915 <entry_run+0x2c5>
 10128d8:	movabs $0x4000000000000002,%rsi
 10128e2:	add    $0xfffffffffffffffe,%rsi
 10128e6:	test   %rsi,%rdx
 10128e9:	sete   %sil
 10128ed:	mov    %rdx,%rdi
 10128f0:	shr    $0x28,%rdi
 10128f4:	and    $0xfffff,%edi
 10128fa:	cmp    %r15d,%edi
 10128fd:	setbe  %dil
 1012901:	bt     $0x3c,%rdx
 1012906:	jb     1014300 <entry_run+0x1cb0>
 101290c:	or     %dil,%sil
 101290f:	je     1014300 <entry_run+0x1cb0>
 1012915:	mov    %rax,-0xf8(%rbp)
 101291c:	movq   $0x0,-0x58(%rbp)
 1012924:	cmpq   $0x0,0xc8(%rcx)
 101292c:	je     1012937 <entry_run+0x2e7>
 101292e:	mov    -0x38(%rbp),%rdi
 1012932:	call   101bcb0 <myl_rc_drain>
 1012937:	mov    -0xf8(%rbp),%rax
 101293e:	mov    %rax,-0x1c0(%rbp)
 1012945:	mov    $0x1,%edx
 101294a:	mov    -0x30(%rbp),%rbx
 101294e:	jmp    1012a2b <entry_run+0x3db>
 1012953:	lea    -0x58(%rbp),%rcx
 1012957:	lea    -0x1c0(%rbp),%rdx
 101295e:	mov    %rdx,%rsi
 1012961:	sub    %rcx,%rsi
 1012964:	sub    %rdx,%rcx
 1012967:	cmovb  %rsi,%rcx
 101296b:	mov    -0x30(%rbp),%rbx
 101296f:	test   %rcx,%rcx
 1012972:	je     101284c <entry_run+0x1fc>
 1012978:	mov    %rax,-0x1c0(%rbp)
 101297f:	movq   $0x0,-0x58(%rbp)
 1012987:	jmp    1012a33 <entry_run+0x3e3>
 101298c:	mov    0x1860(%rbx),%rax
 1012993:	cmpq   $0x0,0xc8(%rax)
 101299b:	je     1012ff7 <entry_run+0x9a7>
 10129a1:	mov    %r14,-0xf8(%rbp)
 10129a8:	lea    -0x260(%rbp),%rdx
 10129af:	mov    %rdx,-0xf0(%rbp)
 10129b6:	movq   $0x0,-0xe8(%rbp)
 10129c1:	mov    %r15d,-0xe0(%rbp)
 10129c8:	movl   $0x0,-0xdc(%rbp)
 10129d2:	lea    -0x58(%rbp),%rcx
 10129d6:	mov    -0x38(%rbp),%rdi
 10129da:	mov    %r12,%rsi
 10129dd:	mov    %r15d,%r8d
 10129e0:	call   1023650 <flat_transfer>
 10129e5:	test   %eax,%eax
 10129e7:	jns    1012a00 <entry_run+0x3b0>
 10129e9:	lea    -0xf8(%rbp),%rsi
 10129f0:	lea    -0x58(%rbp),%rcx
 10129f4:	mov    -0x38(%rbp),%rdi
 10129f8:	mov    %r14,%rdx
 10129fb:	call   101e980 <transfer>
 1012a00:	test   %eax,%eax
 1012a02:	mov    -0x30(%rbp),%rbx
 1012a06:	je     1013125 <entry_run+0xad5>
 1012a0c:	mov    0x1860(%rbx),%rcx
 1012a13:	test   %rcx,%rcx
 1012a16:	je     10144fc <entry_run+0x1eac>
 1012a1c:	xor    %edx,%edx
 1012a1e:	cmpl   $0x0,0x124(%rcx)
 1012a25:	je     1012fe4 <entry_run+0x994>
 1012a2b:	test   %edx,%edx
 1012a2d:	je     1014463 <entry_run+0x1e13>
 1012a33:	movabs $0x6000000000000002,%rbx
 1012a3d:	mov    -0x1c0(%rbp),%r12
 1012a44:	mov    %r12,-0x48(%rbp)
 1012a48:	movl   $0x1,-0x50(%rbp)
 1012a4f:	movq   $0x0,-0xf8(%rbp)
 1012a5a:	movabs $0xc08f400000000000,%rax
 1012a64:	mov    %rax,-0xf0(%rbp)
 1012a6b:	vmovapd -0x110b3(%rip),%ymm0        # 10019c0 <__abi_tag+0x16c4>
 1012a73:	vmovupd %ymm0,-0xe8(%rbp)
 1012a7b:	movabs $0x3fe0000000000000,%rax
 1012a85:	mov    %rax,-0xc8(%rbp)
 1012a8c:	test   %r12,%r12
 1012a8f:	je     1012acd <entry_run+0x47d>
 1012a91:	test   %rbx,-0x10(%r12)
 1012a96:	jne    1012aa0 <entry_run+0x450>
 1012a98:	cmpq   $0x2,-0x20(%r12)
 1012a9e:	jb     1012ac0 <entry_run+0x470>
 1012aa0:	lea    -0x48(%rbp),%rsi
 1012aa4:	lea    -0x50(%rbp),%rdx
 1012aa8:	mov    -0x30(%rbp),%rdi
 1012aac:	vzeroupper
 1012aaf:	call   1014750 <myl_qbe_rc_unique_local>
 1012ab4:	test   %eax,%eax
 1012ab6:	je     1014488 <entry_run+0x1e38>
 1012abc:	mov    -0x48(%rbp),%r12
 1012ac0:	mov    (%r12),%rdx
 1012ac4:	cmp    0x8(%r12),%rdx
 1012ac9:	jb     1012adb <entry_run+0x48b>
 1012acb:	jmp    1012aff <entry_run+0x4af>
 1012acd:	xor    %r12d,%r12d
 1012ad0:	mov    (%r12),%rdx
 1012ad4:	cmp    0x8(%r12),%rdx
 1012ad9:	jae    1012aff <entry_run+0x4af>
 1012adb:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012ae1:	je     1012aff <entry_run+0x4af>
 1012ae3:	mov    0x20(%r12),%rax
 1012ae8:	lea    -0xf8(%rbp),%rsi
 1012aef:	sub    %rax,%rsi
 1012af2:	imul   $0x38,%rdx,%rcx
 1012af6:	cmp    %rcx,%rsi
 1012af9:	jae    1012f8c <entry_run+0x93c>
 1012aff:	lea    -0xf8(%rbp),%rcx
 1012b06:	mov    -0x38(%rbp),%rdi
 1012b0a:	mov    %r12,%rsi
 1012b0d:	vzeroupper
 1012b10:	call   1017d90 <rc_list_insert_at>
 1012b15:	test   %eax,%eax
 1012b17:	je     10145a8 <entry_run+0x1f58>
 1012b1d:	mov    %r15d,-0x40(%rbp)
 1012b21:	vxorpd %xmm0,%xmm0,%xmm0
 1012b25:	vmovapd %xmm0,-0x380(%rbp)
 1012b2d:	movabs $0xc008000000000000,%rax
 1012b37:	mov    %rax,-0x370(%rbp)
 1012b3e:	vmovapd -0x111e6(%rip),%ymm0        # 1001960 <__abi_tag+0x1664>
 1012b46:	vmovupd %ymm0,-0x368(%rbp)
 1012b4e:	test   %r12,%r12
 1012b51:	je     1012b8f <entry_run+0x53f>
 1012b53:	test   %rbx,-0x10(%r12)
 1012b58:	jne    1012b62 <entry_run+0x512>
 1012b5a:	cmpq   $0x2,-0x20(%r12)
 1012b60:	jb     1012b82 <entry_run+0x532>
 1012b62:	lea    -0x48(%rbp),%rsi
 1012b66:	lea    -0x50(%rbp),%rdx
 1012b6a:	mov    -0x30(%rbp),%rdi
 1012b6e:	vzeroupper
 1012b71:	call   1014750 <myl_qbe_rc_unique_local>
 1012b76:	test   %eax,%eax
 1012b78:	je     1014488 <entry_run+0x1e38>
 1012b7e:	mov    -0x48(%rbp),%r12
 1012b82:	mov    (%r12),%rdx
 1012b86:	cmp    0x8(%r12),%rdx
 1012b8b:	jb     1012b9d <entry_run+0x54d>
 1012b8d:	jmp    1012bc1 <entry_run+0x571>
 1012b8f:	xor    %r12d,%r12d
 1012b92:	mov    (%r12),%rdx
 1012b96:	cmp    0x8(%r12),%rdx
 1012b9b:	jae    1012bc1 <entry_run+0x571>
 1012b9d:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012ba3:	je     1012bc1 <entry_run+0x571>
 1012ba5:	mov    0x20(%r12),%rax
 1012baa:	lea    -0x380(%rbp),%rsi
 1012bb1:	sub    %rax,%rsi
 1012bb4:	imul   $0x38,%rdx,%rcx
 1012bb8:	cmp    %rcx,%rsi
 1012bbb:	jae    1012fb8 <entry_run+0x968>
 1012bc1:	lea    -0x380(%rbp),%rcx
 1012bc8:	mov    -0x38(%rbp),%rdi
 1012bcc:	mov    %r12,%rsi
 1012bcf:	vzeroupper
 1012bd2:	call   1017d90 <rc_list_insert_at>
 1012bd7:	test   %eax,%eax
 1012bd9:	je     10145b1 <entry_run+0x1f61>
 1012bdf:	movabs $0xc010000000000000,%r15
 1012be9:	movabs $0xc000000000000000,%r13
 1012bf3:	mov    %r13,-0x340(%rbp)
 1012bfa:	movq   $0x0,-0x338(%rbp)
 1012c05:	mov    %r15,-0x330(%rbp)
 1012c0c:	vmovapd -0x112d4(%rip),%ymm0        # 1001940 <__abi_tag+0x1644>
 1012c14:	vmovupd %ymm0,-0x328(%rbp)
 1012c1c:	test   %r12,%r12
 1012c1f:	je     1012c5d <entry_run+0x60d>
 1012c21:	test   %rbx,-0x10(%r12)
 1012c26:	jne    1012c30 <entry_run+0x5e0>
 1012c28:	cmpq   $0x2,-0x20(%r12)
 1012c2e:	jb     1012c50 <entry_run+0x600>
 1012c30:	lea    -0x48(%rbp),%rsi
 1012c34:	lea    -0x50(%rbp),%rdx
 1012c38:	mov    -0x30(%rbp),%rdi
 1012c3c:	vzeroupper
 1012c3f:	call   1014750 <myl_qbe_rc_unique_local>
 1012c44:	test   %eax,%eax
 1012c46:	je     1014488 <entry_run+0x1e38>
 1012c4c:	mov    -0x48(%rbp),%r12
 1012c50:	mov    (%r12),%rdx
 1012c54:	cmp    0x8(%r12),%rdx
 1012c59:	jb     1012c6b <entry_run+0x61b>
 1012c5b:	jmp    1012c8f <entry_run+0x63f>
 1012c5d:	xor    %r12d,%r12d
 1012c60:	mov    (%r12),%rdx
 1012c64:	cmp    0x8(%r12),%rdx
 1012c69:	jae    1012c8f <entry_run+0x63f>
 1012c6b:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012c71:	je     1012c8f <entry_run+0x63f>
 1012c73:	mov    0x20(%r12),%rax
 1012c78:	lea    -0x340(%rbp),%rsi
 1012c7f:	sub    %rax,%rsi
 1012c82:	imul   $0x38,%rdx,%rcx
 1012c86:	cmp    %rcx,%rsi
 1012c89:	jae    101304b <entry_run+0x9fb>
 1012c8f:	lea    -0x340(%rbp),%rcx
 1012c96:	mov    -0x38(%rbp),%rdi
 1012c9a:	mov    %r12,%rsi
 1012c9d:	vzeroupper
 1012ca0:	call   1017d90 <rc_list_insert_at>
 1012ca5:	test   %eax,%eax
 1012ca7:	je     10145ba <entry_run+0x1f6a>
 1012cad:	movabs $0x4000000000000002,%rax
 1012cb7:	lea    -0x2(%rax),%r14
 1012cbb:	mov    %r14,-0x308(%rbp)
 1012cc2:	movq   $0x0,-0x300(%rbp)
 1012ccd:	mov    %r15,-0x2f8(%rbp)
 1012cd4:	vmovapd -0x1133c(%rip),%ymm0        # 10019a0 <__abi_tag+0x16a4>
 1012cdc:	vmovupd %ymm0,-0x2f0(%rbp)
 1012ce4:	test   %r12,%r12
 1012ce7:	je     1012d2f <entry_run+0x6df>
 1012ce9:	test   %rbx,-0x10(%r12)
 1012cee:	movabs $0x4000000000000002,%r15
 1012cf8:	jne    1012d02 <entry_run+0x6b2>
 1012cfa:	cmpq   $0x2,-0x20(%r12)
 1012d00:	jb     1012d22 <entry_run+0x6d2>
 1012d02:	lea    -0x48(%rbp),%rsi
 1012d06:	lea    -0x50(%rbp),%rdx
 1012d0a:	mov    -0x30(%rbp),%rdi
 1012d0e:	vzeroupper
 1012d11:	call   1014750 <myl_qbe_rc_unique_local>
 1012d16:	test   %eax,%eax
 1012d18:	je     1014488 <entry_run+0x1e38>
 1012d1e:	mov    -0x48(%rbp),%r12
 1012d22:	mov    (%r12),%rdx
 1012d26:	cmp    0x8(%r12),%rdx
 1012d2b:	jb     1012d47 <entry_run+0x6f7>
 1012d2d:	jmp    1012d6b <entry_run+0x71b>
 1012d2f:	xor    %r12d,%r12d
 1012d32:	movabs $0x4000000000000002,%r15
 1012d3c:	mov    (%r12),%rdx
 1012d40:	cmp    0x8(%r12),%rdx
 1012d45:	jae    1012d6b <entry_run+0x71b>
 1012d47:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012d4d:	je     1012d6b <entry_run+0x71b>
 1012d4f:	mov    0x20(%r12),%rax
 1012d54:	lea    -0x308(%rbp),%rsi
 1012d5b:	sub    %rax,%rsi
 1012d5e:	imul   $0x38,%rdx,%rcx
 1012d62:	cmp    %rcx,%rsi
 1012d65:	jae    1013145 <entry_run+0xaf5>
 1012d6b:	lea    -0x308(%rbp),%rcx
 1012d72:	mov    -0x38(%rbp),%rdi
 1012d76:	mov    %r12,%rsi
 1012d79:	vzeroupper
 1012d7c:	call   1017d90 <rc_list_insert_at>
 1012d81:	test   %eax,%eax
 1012d83:	je     10145c3 <entry_run+0x1f73>
 1012d89:	movq   $0x0,-0x2d0(%rbp)
 1012d94:	mov    %r14,-0x2c8(%rbp)
 1012d9b:	movabs $0xc018000000000000,%rax
 1012da5:	mov    %rax,-0x2c0(%rbp)
 1012dac:	vmovapd -0x113d4(%rip),%ymm0        # 10019e0 <__abi_tag+0x16e4>
 1012db4:	vmovupd %ymm0,-0x2b8(%rbp)
 1012dbc:	test   %r12,%r12
 1012dbf:	je     1012dfd <entry_run+0x7ad>
 1012dc1:	test   %rbx,-0x10(%r12)
 1012dc6:	jne    1012dd0 <entry_run+0x780>
 1012dc8:	cmpq   $0x2,-0x20(%r12)
 1012dce:	jb     1012df0 <entry_run+0x7a0>
 1012dd0:	lea    -0x48(%rbp),%rsi
 1012dd4:	lea    -0x50(%rbp),%rdx
 1012dd8:	mov    -0x30(%rbp),%rdi
 1012ddc:	vzeroupper
 1012ddf:	call   1014750 <myl_qbe_rc_unique_local>
 1012de4:	test   %eax,%eax
 1012de6:	je     1014488 <entry_run+0x1e38>
 1012dec:	mov    -0x48(%rbp),%r12
 1012df0:	mov    (%r12),%rdx
 1012df4:	cmp    0x8(%r12),%rdx
 1012df9:	jb     1012e0b <entry_run+0x7bb>
 1012dfb:	jmp    1012e2f <entry_run+0x7df>
 1012dfd:	xor    %r12d,%r12d
 1012e00:	mov    (%r12),%rdx
 1012e04:	cmp    0x8(%r12),%rdx
 1012e09:	jae    1012e2f <entry_run+0x7df>
 1012e0b:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012e11:	je     1012e2f <entry_run+0x7df>
 1012e13:	mov    0x20(%r12),%rax
 1012e18:	lea    -0x2d0(%rbp),%rsi
 1012e1f:	sub    %rax,%rsi
 1012e22:	imul   $0x38,%rdx,%rcx
 1012e26:	cmp    %rcx,%rsi
 1012e29:	jae    10131d5 <entry_run+0xb85>
 1012e2f:	lea    -0x2d0(%rbp),%rcx
 1012e36:	mov    -0x38(%rbp),%rdi
 1012e3a:	mov    %r12,%rsi
 1012e3d:	vzeroupper
 1012e40:	call   1017d90 <rc_list_insert_at>
 1012e45:	test   %eax,%eax
 1012e47:	je     10145cc <entry_run+0x1f7c>
 1012e4d:	movabs $0xbff8000000000000,%rax
 1012e57:	mov    %rax,-0x298(%rbp)
 1012e5e:	movabs $0xbfe0000000000000,%rax
 1012e68:	mov    %rax,-0x290(%rbp)
 1012e6f:	mov    %r13,-0x288(%rbp)
 1012e76:	vmovapd -0x114fe(%rip),%ymm0        # 1001980 <__abi_tag+0x1684>
 1012e7e:	vmovupd %ymm0,-0x280(%rbp)
 1012e86:	test   %r12,%r12
 1012e89:	je     1012ec7 <entry_run+0x877>
 1012e8b:	test   %rbx,-0x10(%r12)
 1012e90:	jne    1012e9a <entry_run+0x84a>
 1012e92:	cmpq   $0x2,-0x20(%r12)
 1012e98:	jb     1012eba <entry_run+0x86a>
 1012e9a:	lea    -0x48(%rbp),%rsi
 1012e9e:	lea    -0x50(%rbp),%rdx
 1012ea2:	mov    -0x30(%rbp),%rdi
 1012ea6:	vzeroupper
 1012ea9:	call   1014750 <myl_qbe_rc_unique_local>
 1012eae:	test   %eax,%eax
 1012eb0:	je     1014488 <entry_run+0x1e38>
 1012eb6:	mov    -0x48(%rbp),%r12
 1012eba:	mov    (%r12),%rdx
 1012ebe:	cmp    0x8(%r12),%rdx
 1012ec3:	jb     1012ed5 <entry_run+0x885>
 1012ec5:	jmp    1012ef9 <entry_run+0x8a9>
 1012ec7:	xor    %r12d,%r12d
 1012eca:	mov    (%r12),%rdx
 1012ece:	cmp    0x8(%r12),%rdx
 1012ed3:	jae    1012ef9 <entry_run+0x8a9>
 1012ed5:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012edb:	je     1012ef9 <entry_run+0x8a9>
 1012edd:	mov    0x20(%r12),%rax
 1012ee2:	lea    -0x298(%rbp),%rsi
 1012ee9:	sub    %rax,%rsi
 1012eec:	imul   $0x38,%rdx,%rcx
 1012ef0:	cmp    %rcx,%rsi
 1012ef3:	jae    1013201 <entry_run+0xbb1>
 1012ef9:	lea    -0x298(%rbp),%rcx
 1012f00:	mov    -0x38(%rbp),%rdi
 1012f04:	mov    %r12,%rsi
 1012f07:	vzeroupper
 1012f0a:	call   1017d90 <rc_list_insert_at>
 1012f0f:	test   %eax,%eax
 1012f11:	mov    -0x30(%rbp),%rdi
 1012f15:	je     10145dd <entry_run+0x1f8d>
 1012f1b:	mov    %r12,-0x58(%rbp)
 1012f1f:	test   %r12,%r12
 1012f22:	je     1013239 <entry_run+0xbe9>
 1012f28:	mov    -0x10(%r12),%rax
 1012f2d:	test   %r15,%rax
 1012f30:	je     1013171 <entry_run+0xb21>
 1012f36:	test   %r14,%rax
 1012f39:	je     1013184 <entry_run+0xb34>
 1012f3f:	lea    -0x1c0(%rbp),%rdx
 1012f46:	lea    -0x58(%rbp),%rcx
 1012f4a:	mov    $0x1002338,%esi
 1012f4f:	mov    -0x38(%rbp),%rdi
 1012f53:	mov    -0x40(%rbp),%r8d
 1012f57:	vzeroupper
 1012f5a:	call   1023970 <myl_rc_native_retain>
 1012f5f:	test   %eax,%eax
 1012f61:	je     10142d2 <entry_run+0x1c82>
 1012f67:	mov    -0x1c0(%rbp),%rax
 1012f6e:	mov    %rax,-0x80(%rbp)
 1012f72:	cmpl   $0x0,-0x50(%rbp)
 1012f76:	mov    -0x30(%rbp),%rdi
 1012f7a:	je     1013251 <entry_run+0xc01>
 1012f80:	movl   $0x0,-0x50(%rbp)
 1012f87:	jmp    10131a9 <entry_run+0xb59>
 1012f8c:	vmovupd -0xf8(%rbp),%ymm0
 1012f94:	vmovupd -0xe0(%rbp),%ymm1
 1012f9c:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1012fa2:	vmovupd %ymm0,(%rax,%rcx,1)
 1012fa7:	inc    %rdx
 1012faa:	mov    %rdx,(%r12)
 1012fae:	incq   0x10(%r12)
 1012fb3:	jmp    1012b1d <entry_run+0x4cd>
 1012fb8:	vmovupd -0x380(%rbp),%ymm0
 1012fc0:	vmovupd -0x368(%rbp),%ymm1
 1012fc8:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1012fce:	vmovupd %ymm0,(%rax,%rcx,1)
 1012fd3:	inc    %rdx
 1012fd6:	mov    %rdx,(%r12)
 1012fda:	incq   0x10(%r12)
 1012fdf:	jmp    1012bdf <entry_run+0x58f>
 1012fe4:	mov    %eax,0x124(%rcx)
 1012fea:	test   %edx,%edx
 1012fec:	jne    1012a33 <entry_run+0x3e3>
 1012ff2:	jmp    1014463 <entry_run+0x1e13>
 1012ff7:	lea    -0x1c0(%rbp),%rdx
 1012ffe:	lea    -0x58(%rbp),%rcx
 1013002:	mov    -0x38(%rbp),%rdi
 1013006:	mov    %r12,%rsi
 1013009:	mov    %r15d,%r8d
 101300c:	call   1023650 <flat_transfer>
 1013011:	test   %eax,%eax
 1013013:	js     10129a1 <entry_run+0x351>
 1013019:	mov    -0x30(%rbp),%rbx
 101301d:	je     1012a33 <entry_run+0x3e3>
 1013023:	mov    0x1860(%rbx),%rcx
 101302a:	test   %rcx,%rcx
 101302d:	je     10144fc <entry_run+0x1eac>
 1013033:	cmpl   $0x0,0x124(%rcx)
 101303a:	jne    1014463 <entry_run+0x1e13>
 1013040:	mov    %eax,0x124(%rcx)
 1013046:	jmp    1014463 <entry_run+0x1e13>
 101304b:	vmovupd -0x340(%rbp),%ymm0
 1013053:	vmovupd -0x328(%rbp),%ymm1
 101305b:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1013061:	vmovupd %ymm0,(%rax,%rcx,1)
 1013066:	inc    %rdx
 1013069:	mov    %rdx,(%r12)
 101306d:	incq   0x10(%r12)
 1013072:	jmp    1012cad <entry_run+0x65d>
 1013077:	cmpq   $0x0,0x20(%rdi)
 101307c:	jne    10130a7 <entry_run+0xa57>
 101307e:	movl   $0x1,0x39e8(%rdi)
 1013088:	vxorpd %xmm0,%xmm0,%xmm0
 101308c:	vmovupd %ymm0,0x39ec(%rdi)
 1013094:	vmovupd %ymm0,0x39f8(%rdi)
 101309c:	movq   $0x1003f61,0x3a18(%rdi)
 10130a7:	mov    $0x100442d,%esi
 10130ac:	mov    -0x30(%rbp),%rdi
 10130b0:	vzeroupper
 10130b3:	call   1014a6d <fail>
 10130b8:	mov    -0x30(%rbp),%rdi
 10130bc:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 10130c1:	je     10127e3 <entry_run+0x193>
 10130c7:	cmpq   $0x0,0x20(%rdi)
 10130cc:	jne    10130f7 <entry_run+0xaa7>
 10130ce:	movl   $0x1,0x39e8(%rdi)
 10130d8:	vxorpd %xmm0,%xmm0,%xmm0
 10130dc:	vmovupd %ymm0,0x39ec(%rdi)
 10130e4:	vmovupd %ymm0,0x39f8(%rdi)
 10130ec:	movq   $0x1003faa,0x3a18(%rdi)
 10130f7:	mov    $0x1004442,%esi
 10130fc:	mov    -0x30(%rbp),%rdi
 1013100:	vzeroupper
 1013103:	call   1014a6d <fail>
 1013108:	mov    -0x30(%rbp),%rdi
 101310c:	cmpq   $0x0,0x1860(%rdi)
 1013114:	mov    %rdi,%rbx
 1013117:	jne    10127f4 <entry_run+0x1a4>
 101311d:	mov    %rbx,%rdi
 1013120:	call   1015110 <myl_qbe_fail_allocation>
 1013125:	mov    -0x260(%rbp),%rax
 101312c:	mov    %rax,-0x1c0(%rbp)
 1013133:	mov    $0x1,%edx
 1013138:	test   %edx,%edx
 101313a:	jne    1012a33 <entry_run+0x3e3>
 1013140:	jmp    1014463 <entry_run+0x1e13>
 1013145:	vmovupd -0x308(%rbp),%ymm0
 101314d:	vmovupd -0x2f0(%rbp),%ymm1
 1013155:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 101315b:	vmovupd %ymm0,(%rax,%rcx,1)
 1013160:	inc    %rdx
 1013163:	mov    %rdx,(%r12)
 1013167:	incq   0x10(%r12)
 101316c:	jmp    1012d89 <entry_run+0x739>
 1013171:	mov    -0x20(%r12),%rax
 1013176:	inc    %rax
 1013179:	je     10143b1 <entry_run+0x1d61>
 101317f:	mov    %rax,-0x20(%r12)
 1013184:	mov    %r12,-0x1c0(%rbp)
 101318b:	mov    %r12,-0x80(%rbp)
 101318f:	cmpl   $0x0,-0x50(%rbp)
 1013193:	je     1013251 <entry_run+0xc01>
 1013199:	movl   $0x0,-0x50(%rbp)
 10131a0:	test   %r12,%r12
 10131a3:	je     1013251 <entry_run+0xc01>
 10131a9:	test   %r15,-0x10(%r12)
 10131ae:	jne    10131cb <entry_run+0xb7b>
 10131b0:	mov    -0x20(%r12),%rax
 10131b5:	dec    %rax
 10131b8:	jne    10131c6 <entry_run+0xb76>
 10131ba:	cmpq   $0x0,-0x18(%r12)
 10131c0:	je     10143c3 <entry_run+0x1d73>
 10131c6:	mov    %rax,-0x20(%r12)
 10131cb:	movq   $0x0,-0x48(%rbp)
 10131d3:	jmp    1013251 <entry_run+0xc01>
 10131d5:	vmovupd -0x2d0(%rbp),%ymm0
 10131dd:	vmovupd -0x2b8(%rbp),%ymm1
 10131e5:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10131eb:	vmovupd %ymm0,(%rax,%rcx,1)
 10131f0:	inc    %rdx
 10131f3:	mov    %rdx,(%r12)
 10131f7:	incq   0x10(%r12)
 10131fc:	jmp    1012e4d <entry_run+0x7fd>
 1013201:	vmovupd -0x298(%rbp),%ymm0
 1013209:	vmovupd -0x280(%rbp),%ymm1
 1013211:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1013217:	vmovupd %ymm0,(%rax,%rcx,1)
 101321c:	inc    %rdx
 101321f:	mov    %rdx,(%r12)
 1013223:	incq   0x10(%r12)
 1013228:	mov    -0x30(%rbp),%rdi
 101322c:	mov    %r12,-0x58(%rbp)
 1013230:	test   %r12,%r12
 1013233:	jne    1012f28 <entry_run+0x8d8>
 1013239:	mov    %r12,-0x1c0(%rbp)
 1013240:	mov    %r12,-0x80(%rbp)
 1013244:	mov    -0x50(%rbp),%eax
 1013247:	xor    %ecx,%ecx
 1013249:	test   %eax,%eax
 101324b:	cmove  %eax,%ecx
 101324e:	mov    %ecx,-0x50(%rbp)
 1013251:	movabs $0x3ff0000000000000,%rax
 101325b:	mov    %rax,-0x158(%rbp)
 1013262:	mov    %rax,-0x150(%rbp)
 1013269:	mov    %rax,-0x148(%rbp)
 1013270:	cmp    %rsp,0x40(%rdi)
 1013274:	ja     10145d5 <entry_run+0x1f85>
 101327a:	vmovsd -0x158(%rbp),%xmm2
 1013282:	vmovsd -0x150(%rbp),%xmm3
 101328a:	vmulsd %xmm2,%xmm2,%xmm0
 101328e:	vmulsd %xmm3,%xmm3,%xmm1
 1013292:	vaddsd %xmm1,%xmm0,%xmm0
 1013296:	vmovsd -0x148(%rbp),%xmm4
 101329e:	vmulsd %xmm4,%xmm4,%xmm1
 10132a2:	vaddsd %xmm1,%xmm0,%xmm0
 10132a6:	vxorpd %xmm5,%xmm5,%xmm5
 10132aa:	vucomisd %xmm5,%xmm0
 10132ae:	jb     10132b6 <entry_run+0xc66>
 10132b0:	vsqrtsd %xmm0,%xmm0,%xmm0
 10132b4:	jmp    10132e4 <entry_run+0xc94>
 10132b6:	vmovsd %xmm2,-0x40(%rbp)
 10132bb:	vmovsd %xmm3,-0x70(%rbp)
 10132c0:	vmovsd %xmm4,-0x78(%rbp)
 10132c5:	vzeroupper
 10132c8:	call   1027650 <sqrt@plt>
 10132cd:	vmovsd -0x78(%rbp),%xmm4
 10132d2:	vmovsd -0x70(%rbp),%xmm3
 10132d7:	vmovsd -0x40(%rbp),%xmm2
 10132dc:	vxorpd %xmm5,%xmm5,%xmm5
 10132e0:	mov    -0x30(%rbp),%rdi
 10132e4:	vmovsd -0x118cc(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 10132ec:	vdivsd %xmm0,%xmm1,%xmm0
 10132f0:	vmulsd %xmm0,%xmm2,%xmm1
 10132f4:	vmulsd %xmm0,%xmm3,%xmm2
 10132f8:	vmulsd %xmm0,%xmm4,%xmm0
 10132fc:	vmovsd %xmm1,-0xa8(%rbp)
 1013304:	vmovsd %xmm2,-0xa0(%rbp)
 101330c:	vmovsd %xmm0,-0x98(%rbp)
 1013314:	vxorpd %xmm0,%xmm0,%xmm0
 1013318:	vmovapd %xmm0,-0x110(%rbp)
 1013320:	movq   $0x0,-0x100(%rbp)
 101332b:	xor    %r13d,%r13d
 101332e:	mov    $0x3f,%bl
 1013330:	vmovsd -0x118d8(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013338:	xor    %eax,%eax
 101333a:	jmp    1013356 <entry_run+0xd06>
 101333c:	nopl   0x0(%rax)
 1013340:	mov    -0x118(%rbp),%rax
 1013347:	inc    %rax
 101334a:	cmp    $0x438,%rax
 1013350:	je     1013f05 <entry_run+0x18b5>
 1013356:	mov    %rax,-0x118(%rbp)
 101335d:	vcvtsi2sd %rax,%xmm15,%xmm0
 1013362:	vaddsd -0x1192a(%rip),%xmm0,%xmm0        # 1001a40 <__abi_tag+0x1744>
 101336a:	vaddsd %xmm0,%xmm0,%xmm0
 101336e:	vdivsd -0x11966(%rip),%xmm0,%xmm0        # 1001a10 <__abi_tag+0x1714>
 1013376:	vaddsd -0x1195e(%rip),%xmm0,%xmm0        # 1001a20 <__abi_tag+0x1724>
 101337e:	vmovsd %xmm0,-0x120(%rbp)
 1013386:	xor    %ecx,%ecx
 1013388:	nopl   0x0(%rax,%rax,1)
 1013390:	vcvtsi2sd %rcx,%xmm15,%xmm0
 1013395:	vaddsd -0x1195d(%rip),%xmm0,%xmm0        # 1001a40 <__abi_tag+0x1744>
 101339d:	vaddsd %xmm0,%xmm0,%xmm0
 10133a1:	vdivsd -0x11951(%rip),%xmm0,%xmm0        # 1001a58 <__abi_tag+0x175c>
 10133a9:	vaddsd -0x119b1(%rip),%xmm0,%xmm0        # 1001a00 <__abi_tag+0x1704>
 10133b1:	vmulsd -0x11989(%rip),%xmm0,%xmm0        # 1001a30 <__abi_tag+0x1734>
 10133b9:	vmovsd %xmm0,-0x140(%rbp)
 10133c1:	vmovsd -0x120(%rbp),%xmm0
 10133c9:	vmovsd %xmm0,-0x138(%rbp)
 10133d1:	movabs $0xbff8000000000000,%rax
 10133db:	mov    %rax,-0x130(%rbp)
 10133e2:	cmp    %rsp,0x40(%rdi)
 10133e6:	ja     1014516 <entry_run+0x1ec6>
 10133ec:	vmovsd -0x140(%rbp),%xmm2
 10133f4:	vmovsd -0x138(%rbp),%xmm3
 10133fc:	vmulsd %xmm2,%xmm2,%xmm0
 1013400:	vmulsd %xmm3,%xmm3,%xmm1
 1013404:	vaddsd %xmm1,%xmm0,%xmm0
 1013408:	vmovsd -0x130(%rbp),%xmm4
 1013410:	vmulsd %xmm4,%xmm4,%xmm1
 1013414:	vaddsd %xmm1,%xmm0,%xmm0
 1013418:	vucomisd %xmm5,%xmm0
 101341c:	mov    %rcx,-0x128(%rbp)
 1013423:	jb     1013430 <entry_run+0xde0>
 1013425:	vsqrtsd %xmm0,%xmm0,%xmm0
 1013429:	jmp    1013466 <entry_run+0xe16>
 101342b:	nopl   0x0(%rax,%rax,1)
 1013430:	vmovsd %xmm2,-0x40(%rbp)
 1013435:	vmovsd %xmm3,-0x70(%rbp)
 101343a:	vmovsd %xmm4,-0x78(%rbp)
 101343f:	vzeroupper
 1013442:	call   1027650 <sqrt@plt>
 1013447:	vmovsd -0x78(%rbp),%xmm4
 101344c:	vmovsd -0x70(%rbp),%xmm3
 1013451:	vmovsd -0x40(%rbp),%xmm2
 1013456:	vmovsd -0x119fe(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101345e:	vxorpd %xmm5,%xmm5,%xmm5
 1013462:	mov    -0x30(%rbp),%rdi
 1013466:	vmovsd -0x11a4e(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 101346e:	vdivsd %xmm0,%xmm1,%xmm0
 1013472:	vmulsd %xmm0,%xmm2,%xmm1
 1013476:	vmulsd %xmm0,%xmm3,%xmm2
 101347a:	vmulsd %xmm0,%xmm4,%xmm0
 101347e:	vmovsd %xmm1,-0xc0(%rbp)
 1013486:	vmovsd %xmm2,-0xb8(%rbp)
 101348e:	vmovsd %xmm0,-0xb0(%rbp)
 1013496:	mov    -0x80(%rbp),%r12
 101349a:	movq   $0x0,-0x410(%rbp)
 10134a5:	movq   $0x0,-0x3f0(%rbp)
 10134b0:	movq   $0x0,-0x3d0(%rbp)
 10134bb:	cmp    %rsp,0x40(%rdi)
 10134bf:	ja     101451e <entry_run+0x1ece>
 10134c5:	test   %r15,-0x10(%r12)
 10134ca:	jne    10134df <entry_run+0xe8f>
 10134cc:	mov    -0x18(%r12),%rax
 10134d1:	inc    %rax
 10134d4:	je     1013abc <entry_run+0x146c>
 10134da:	mov    %rax,-0x18(%r12)
 10134df:	mov    %r13,-0x90(%rbp)
 10134e6:	mov    (%r12),%r13
 10134ea:	test   %r13,%r13
 10134ed:	js     1014526 <entry_run+0x1ed6>
 10134f3:	je     10137c0 <entry_run+0x1170>
 10134f9:	mov    $0xffffffffffffffff,%r14
 1013500:	mov    $0x18,%r15d
 1013506:	xor    %ebx,%ebx
 1013508:	movabs $0xbff0000000000000,%rax
 1013512:	mov    %rax,-0x88(%rbp)
 1013519:	nopl   0x0(%rax)
 1013520:	cmp    %rsp,0x40(%rdi)
 1013524:	ja     10144f4 <entry_run+0x1ea4>
 101352a:	mov    0x20(%r12),%rax
 101352f:	vmovsd -0x110(%rbp),%xmm7
 1013537:	vmovsd -0x108(%rbp),%xmm0
 101353f:	vsubsd -0x18(%r15,%rax,1),%xmm7,%xmm1
 1013546:	vsubsd -0x10(%r15,%rax,1),%xmm0,%xmm0
 101354d:	vmovsd -0x100(%rbp),%xmm2
 1013555:	vsubsd -0x8(%r15,%rax,1),%xmm2,%xmm2
 101355c:	vmovsd %xmm1,-0x260(%rbp)
 1013564:	vmovsd %xmm0,-0x258(%rbp)
 101356c:	vmovsd %xmm2,-0x250(%rbp)
 1013574:	vmovsd -0xc0(%rbp),%xmm8
 101357c:	vmulsd %xmm1,%xmm8,%xmm3
 1013580:	vmulsd -0xb8(%rbp),%xmm0,%xmm4
 1013588:	vaddsd %xmm4,%xmm3,%xmm3
 101358c:	vmulsd -0xb0(%rbp),%xmm2,%xmm4
 1013594:	vaddsd %xmm4,%xmm3,%xmm3
 1013598:	vmulsd %xmm1,%xmm1,%xmm1
 101359c:	vmulsd %xmm0,%xmm0,%xmm0
 10135a0:	vaddsd %xmm0,%xmm1,%xmm0
 10135a4:	vmulsd %xmm2,%xmm2,%xmm1
 10135a8:	vaddsd %xmm1,%xmm0,%xmm0
 10135ac:	vmovsd (%r15,%rax,1),%xmm1
 10135b2:	vmulsd %xmm1,%xmm1,%xmm1
 10135b6:	vsubsd %xmm0,%xmm1,%xmm0
 10135ba:	vmulsd %xmm3,%xmm3,%xmm1
 10135be:	vaddsd %xmm0,%xmm1,%xmm0
 10135c2:	vucomisd %xmm0,%xmm5
 10135c6:	ja     1013680 <entry_run+0x1030>
 10135cc:	vucomisd %xmm5,%xmm0
 10135d0:	jb     10135f0 <entry_run+0xfa0>
 10135d2:	vsqrtsd %xmm0,%xmm0,%xmm0
 10135d6:	vsubsd %xmm3,%xmm5,%xmm2
 10135da:	vsubsd %xmm0,%xmm2,%xmm1
 10135de:	vucomisd %xmm6,%xmm1
 10135e2:	jbe    1013634 <entry_run+0xfe4>
 10135e4:	jmp    101363e <entry_run+0xfee>
 10135e6:	cs nopw 0x0(%rax,%rax,1)
 10135f0:	vmovsd %xmm7,-0x40(%rbp)
 10135f5:	vmovsd %xmm8,-0x70(%rbp)
 10135fa:	vmovsd %xmm3,-0x78(%rbp)
 10135ff:	vzeroupper
 1013602:	call   1027650 <sqrt@plt>
 1013607:	vmovsd -0x78(%rbp),%xmm3
 101360c:	vmovsd -0x70(%rbp),%xmm8
 1013611:	vmovsd -0x40(%rbp),%xmm7
 1013616:	vmovsd -0x11bbe(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101361e:	vxorpd %xmm5,%xmm5,%xmm5
 1013622:	mov    -0x30(%rbp),%rdi
 1013626:	vsubsd %xmm3,%xmm5,%xmm2
 101362a:	vsubsd %xmm0,%xmm2,%xmm1
 101362e:	vucomisd %xmm6,%xmm1
 1013632:	ja     101363e <entry_run+0xfee>
 1013634:	vaddsd %xmm0,%xmm2,%xmm1
 1013638:	vucomisd %xmm6,%xmm1
 101363c:	jbe    1013680 <entry_run+0x1030>
 101363e:	vucomisd %xmm5,%xmm1
 1013642:	jbe    1013680 <entry_run+0x1030>
 1013644:	test   %r14,%r14
 1013647:	setns  %al
 101364a:	mov    -0x88(%rbp),%rsi
 1013651:	vmovq  %rsi,%xmm0
 1013656:	vucomisd %xmm1,%xmm0
 101365a:	vmovq  %xmm1,%rcx
 101365f:	setbe  %dl
 1013662:	test   %dl,%al
 1013664:	cmove  %rcx,%rsi
 1013668:	mov    %rsi,-0x88(%rbp)
 101366f:	cmove  %rbx,%r14
 1013673:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013680:	cmp    %r13,(%r12)
 1013684:	jne    10144ec <entry_run+0x1e9c>
 101368a:	inc    %rbx
 101368d:	add    $0x38,%r15
 1013691:	cmp    %rbx,%r13
 1013694:	jne    1013520 <entry_run+0xed0>
 101369a:	test   %r14,%r14
 101369d:	movabs $0x4000000000000002,%r15
 10136a7:	js     10137c0 <entry_run+0x1170>
 10136ad:	cmp    %r13,%r14
 10136b0:	jae    1014582 <entry_run+0x1f32>
 10136b6:	mov    0x20(%r12),%rax
 10136bb:	imul   $0x38,%r14,%rcx
 10136bf:	vmovups 0x20(%rax,%rcx,1),%xmm0
 10136c5:	mov    0x30(%rax,%rcx,1),%rdx
 10136ca:	vmovups (%rax,%rcx,1),%ymm1
 10136cf:	vmovups %ymm1,-0x260(%rbp)
 10136d7:	mov    %rdx,-0x230(%rbp)
 10136de:	vmovaps %xmm0,-0x240(%rbp)
 10136e6:	vmovsd -0x88(%rbp),%xmm0
 10136ee:	vmulsd %xmm0,%xmm8,%xmm1
 10136f2:	vmulsd -0xb8(%rbp),%xmm0,%xmm2
 10136fa:	vmulsd -0xb0(%rbp),%xmm0,%xmm0
 1013702:	vmovsd %xmm1,-0x3b0(%rbp)
 101370a:	vmovsd %xmm2,-0x3a8(%rbp)
 1013712:	vmovsd %xmm0,-0x3a0(%rbp)
 101371a:	vaddsd %xmm1,%xmm7,%xmm1
 101371e:	vaddsd -0x108(%rbp),%xmm2,%xmm2
 1013726:	vaddsd -0x100(%rbp),%xmm0,%xmm0
 101372e:	vmovsd %xmm1,-0x170(%rbp)
 1013736:	vmovsd %xmm2,-0x168(%rbp)
 101373e:	vsubsd -0x260(%rbp),%xmm1,%xmm1
 1013746:	vsubsd -0x258(%rbp),%xmm2,%xmm2
 101374e:	vmovsd %xmm0,-0x160(%rbp)
 1013756:	vsubsd -0x250(%rbp),%xmm0,%xmm0
 101375e:	vmovsd %xmm1,-0x188(%rbp)
 1013766:	vmovsd %xmm2,-0x180(%rbp)
 101376e:	vmovsd %xmm0,-0x178(%rbp)
 1013776:	cmp    %rsp,0x40(%rdi)
 101377a:	ja     1014590 <entry_run+0x1f40>
 1013780:	vmovsd -0x188(%rbp),%xmm2
 1013788:	vmovsd -0x180(%rbp),%xmm3
 1013790:	vmulsd %xmm2,%xmm2,%xmm0
 1013794:	vmulsd %xmm3,%xmm3,%xmm1
 1013798:	vaddsd %xmm1,%xmm0,%xmm0
 101379c:	vmovsd -0x178(%rbp),%xmm4
 10137a4:	vmulsd %xmm4,%xmm4,%xmm1
 10137a8:	vaddsd %xmm1,%xmm0,%xmm0
 10137ac:	vucomisd %xmm5,%xmm0
 10137b0:	mov    -0x90(%rbp),%r13
 10137b7:	jb     10137fd <entry_run+0x11ad>
 10137b9:	vsqrtsd %xmm0,%xmm0,%xmm0
 10137bd:	jmp    1013833 <entry_run+0x11e3>
 10137bf:	nop
 10137c0:	mov    -0x3f0(%rbp),%eax
 10137c6:	or     -0x410(%rbp),%eax
 10137cc:	or     -0x3d0(%rbp),%eax
 10137d2:	mov    -0x90(%rbp),%r13
 10137d9:	mov    $0x3f,%bl
 10137db:	je     1013a30 <entry_run+0x13e0>
 10137e1:	mov    0x1860(%rdi),%rax
 10137e8:	test   %rax,%rax
 10137eb:	je     1013a12 <entry_run+0x13c2>
 10137f1:	mov    0xf8(%rax),%rsi
 10137f8:	jmp    1013a14 <entry_run+0x13c4>
 10137fd:	vmovsd %xmm2,-0x40(%rbp)
 1013802:	vmovsd %xmm3,-0x70(%rbp)
 1013807:	vmovsd %xmm4,-0x78(%rbp)
 101380c:	vzeroupper
 101380f:	call   1027650 <sqrt@plt>
 1013814:	vmovsd -0x78(%rbp),%xmm4
 1013819:	vmovsd -0x70(%rbp),%xmm3
 101381e:	vmovsd -0x40(%rbp),%xmm2
 1013823:	vmovsd -0x11dcb(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101382b:	vxorpd %xmm5,%xmm5,%xmm5
 101382f:	mov    -0x30(%rbp),%rdi
 1013833:	vmovsd -0x11e1b(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 101383b:	vdivsd %xmm0,%xmm1,%xmm0
 101383f:	vmulsd %xmm0,%xmm2,%xmm1
 1013843:	vmulsd %xmm0,%xmm3,%xmm2
 1013847:	vmulsd %xmm0,%xmm4,%xmm0
 101384b:	vmovsd %xmm1,-0x398(%rbp)
 1013853:	vmovsd %xmm2,-0x390(%rbp)
 101385b:	vmovsd %xmm0,-0x388(%rbp)
 1013863:	vmulsd -0xa8(%rbp),%xmm1,%xmm1
 101386b:	vmulsd -0xa0(%rbp),%xmm2,%xmm2
 1013873:	vaddsd %xmm2,%xmm1,%xmm1
 1013877:	vmulsd -0x98(%rbp),%xmm0,%xmm0
 101387f:	vaddsd %xmm0,%xmm1,%xmm7
 1013883:	vxorpd %xmm0,%xmm0,%xmm0
 1013887:	mov    $0x1,%bl
 1013889:	vucomisd %xmm7,%xmm0
 101388d:	jbe    1013897 <entry_run+0x1247>
 101388f:	xor    %r14d,%r14d
 1013892:	jmp    1013b00 <entry_run+0x14b0>
 1013897:	vucomisd %xmm5,%xmm7
 101389b:	jbe    1013a77 <entry_run+0x1427>
 10138a1:	test   %r15,-0x10(%r12)
 10138a6:	mov    $0x3f,%bl
 10138a8:	jne    10138bd <entry_run+0x126d>
 10138aa:	mov    -0x18(%r12),%rax
 10138af:	inc    %rax
 10138b2:	je     1013abc <entry_run+0x146c>
 10138b8:	mov    %rax,-0x18(%r12)
 10138bd:	mov    (%r12),%r14
 10138c1:	test   %r14,%r14
 10138c4:	js     1014598 <entry_run+0x1f48>
 10138ca:	je     1013a83 <entry_run+0x1433>
 10138d0:	mov    $0x18,%ebx
 10138d5:	mov    %r14,%r15
 10138d8:	vmovsd %xmm7,-0x70(%rbp)
 10138dd:	nopl   (%rax)
 10138e0:	cmp    %rsp,0x40(%rdi)
 10138e4:	ja     1014506 <entry_run+0x1eb6>
 10138ea:	mov    0x20(%r12),%rax
 10138ef:	vmovsd -0x170(%rbp),%xmm0
 10138f7:	vmovsd -0x168(%rbp),%xmm1
 10138ff:	vsubsd -0x18(%rbx,%rax,1),%xmm0,%xmm0
 1013905:	vsubsd -0x10(%rbx,%rax,1),%xmm1,%xmm1
 101390b:	vmovsd -0x160(%rbp),%xmm2
 1013913:	vsubsd -0x8(%rbx,%rax,1),%xmm2,%xmm2
 1013919:	vmovsd %xmm0,-0x3c8(%rbp)
 1013921:	vmovsd %xmm1,-0x3c0(%rbp)
 1013929:	vmovsd %xmm2,-0x3b8(%rbp)
 1013931:	vmulsd -0xa8(%rbp),%xmm0,%xmm3
 1013939:	vmulsd -0xa0(%rbp),%xmm1,%xmm4
 1013941:	vaddsd %xmm4,%xmm3,%xmm3
 1013945:	vmulsd -0x98(%rbp),%xmm2,%xmm4
 101394d:	vaddsd %xmm4,%xmm3,%xmm3
 1013951:	vmulsd %xmm0,%xmm0,%xmm0
 1013955:	vmulsd %xmm1,%xmm1,%xmm1
 1013959:	vaddsd %xmm1,%xmm0,%xmm0
 101395d:	vmulsd %xmm2,%xmm2,%xmm1
 1013961:	vaddsd %xmm1,%xmm0,%xmm0
 1013965:	vmovsd (%rbx,%rax,1),%xmm1
 101396a:	vmulsd %xmm1,%xmm1,%xmm1
 101396e:	vsubsd %xmm0,%xmm1,%xmm0
 1013972:	vmulsd %xmm3,%xmm3,%xmm1
 1013976:	vaddsd %xmm0,%xmm1,%xmm0
 101397a:	vucomisd %xmm0,%xmm5
 101397e:	ja     10139ed <entry_run+0x139d>
 1013980:	vucomisd %xmm5,%xmm0
 1013984:	jb     10139a0 <entry_run+0x1350>
 1013986:	vsqrtsd %xmm0,%xmm0,%xmm0
 101398a:	vsubsd %xmm3,%xmm5,%xmm2
 101398e:	vsubsd %xmm0,%xmm2,%xmm1
 1013992:	vucomisd %xmm6,%xmm1
 1013996:	jbe    10139d5 <entry_run+0x1385>
 1013998:	jmp    10139df <entry_run+0x138f>
 101399a:	nopw   0x0(%rax,%rax,1)
 10139a0:	vmovsd %xmm3,-0x40(%rbp)
 10139a5:	vzeroupper
 10139a8:	call   1027650 <sqrt@plt>
 10139ad:	vmovsd -0x40(%rbp),%xmm3
 10139b2:	vmovsd -0x70(%rbp),%xmm7
 10139b7:	vmovsd -0x11f5f(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 10139bf:	vxorpd %xmm5,%xmm5,%xmm5
 10139c3:	mov    -0x30(%rbp),%rdi
 10139c7:	vsubsd %xmm3,%xmm5,%xmm2
 10139cb:	vsubsd %xmm0,%xmm2,%xmm1
 10139cf:	vucomisd %xmm6,%xmm1
 10139d3:	ja     10139df <entry_run+0x138f>
 10139d5:	vaddsd %xmm0,%xmm2,%xmm1
 10139d9:	vucomisd %xmm6,%xmm1
 10139dd:	jbe    10139ed <entry_run+0x139d>
 10139df:	vxorpd %xmm0,%xmm0,%xmm0
 10139e3:	vucomisd %xmm0,%xmm1
 10139e7:	ja     1013aea <entry_run+0x149a>
 10139ed:	cmp    %r14,(%r12)
 10139f1:	jne    101450e <entry_run+0x1ebe>
 10139f7:	add    $0x38,%rbx
 10139fb:	dec    %r15
 10139fe:	jne    10138e0 <entry_run+0x1290>
 1013a04:	xor    %ebx,%ebx
 1013a06:	mov    %r12,%r14
 1013a09:	vmovapd %xmm7,%xmm0
 1013a0d:	jmp    1013aef <entry_run+0x149f>
 1013a12:	xor    %esi,%esi
 1013a14:	mov    -0x38(%rbp),%rdi
 1013a18:	vzeroupper
 1013a1b:	call   101e3a0 <myl_rc_scope_unwind>
 1013a20:	mov    -0x30(%rbp),%rdi
 1013a24:	vxorpd %xmm5,%xmm5,%xmm5
 1013a28:	vmovsd -0x11fd0(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013a30:	vmovsd -0x12020(%rip),%xmm2        # 1001a18 <__abi_tag+0x171c>
 1013a38:	vmovapd -0x12150(%rip),%xmm3        # 10018f0 <__abi_tag+0x15f4>
 1013a40:	test   %r15,-0x10(%r12)
 1013a45:	jne    1013c70 <entry_run+0x1620>
 1013a4b:	mov    -0x18(%r12),%rax
 1013a50:	dec    %rax
 1013a53:	jne    1013a5d <entry_run+0x140d>
 1013a55:	cmpq   $0x0,-0x20(%r12)
 1013a5b:	je     1013a8e <entry_run+0x143e>
 1013a5d:	mov    %rax,-0x18(%r12)
 1013a62:	vmovsd -0x12052(%rip),%xmm2        # 1001a18 <__abi_tag+0x171c>
 1013a6a:	vmovapd -0x12182(%rip),%xmm3        # 10018f0 <__abi_tag+0x15f4>
 1013a72:	jmp    1013c70 <entry_run+0x1620>
 1013a77:	xor    %r14d,%r14d
 1013a7a:	vmovapd %xmm7,%xmm0
 1013a7e:	jmp    1013b00 <entry_run+0x14b0>
 1013a83:	xor    %ebx,%ebx
 1013a85:	mov    %r12,%r14
 1013a88:	vmovapd %xmm7,%xmm0
 1013a8c:	jmp    1013b00 <entry_run+0x14b0>
 1013a8e:	mov    -0x38(%rbp),%rbx
 1013a92:	mov    %rbx,%rdi
 1013a95:	mov    %r12,%rsi
 1013a98:	vzeroupper
 1013a9b:	call   1018ce0 <myl_rc_hold_edge_release>
 1013aa0:	mov    %rbx,%rdi
 1013aa3:	mov    $0x3f,%bl
 1013aa5:	call   101bcb0 <myl_rc_drain>
 1013aaa:	vmovsd -0x12052(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ab2:	vxorpd %xmm5,%xmm5,%xmm5
 1013ab6:	mov    -0x30(%rbp),%rdi
 1013aba:	jmp    1013a62 <entry_run+0x1412>
 1013abc:	mov    $0x100432e,%esi
 1013ac1:	mov    -0x30(%rbp),%rdi
 1013ac5:	vzeroupper
 1013ac8:	call   1014a6d <fail>
 1013acd:	vmovsd -0x12075(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ad5:	vxorpd %xmm5,%xmm5,%xmm5
 1013ad9:	mov    -0x30(%rbp),%rdi
 1013add:	vxorpd %xmm3,%xmm3,%xmm3
 1013ae1:	vxorpd %xmm2,%xmm2,%xmm2
 1013ae5:	jmp    1013c70 <entry_run+0x1620>
 1013aea:	xor    %ebx,%ebx
 1013aec:	mov    %r12,%r14
 1013aef:	movabs $0x4000000000000002,%r15
 1013af9:	nopl   0x0(%rax)
 1013b00:	vmulsd -0x120c0(%rip),%xmm0,%xmm0        # 1001a48 <__abi_tag+0x174c>
 1013b08:	vaddsd -0x120d8(%rip),%xmm0,%xmm0        # 1001a38 <__abi_tag+0x173c>
 1013b10:	vmulsd -0x240(%rbp),%xmm0,%xmm2
 1013b18:	vmovddup %xmm0,%xmm0
 1013b1c:	vmulpd -0x238(%rbp),%xmm0,%xmm3
 1013b24:	mov    -0x3f0(%rbp),%eax
 1013b2a:	or     -0x410(%rbp),%eax
 1013b30:	or     -0x3d0(%rbp),%eax
 1013b36:	je     1013b7f <entry_run+0x152f>
 1013b38:	mov    0x1860(%rdi),%rax
 1013b3f:	test   %rax,%rax
 1013b42:	vmovsd %xmm2,-0x40(%rbp)
 1013b47:	vmovapd %xmm3,-0x70(%rbp)
 1013b4c:	je     1013b57 <entry_run+0x1507>
 1013b4e:	mov    0xf8(%rax),%rsi
 1013b55:	jmp    1013b59 <entry_run+0x1509>
 1013b57:	xor    %esi,%esi
 1013b59:	mov    -0x38(%rbp),%rdi
 1013b5d:	vzeroupper
 1013b60:	call   101e3a0 <myl_rc_scope_unwind>
 1013b65:	mov    -0x30(%rbp),%rdi
 1013b69:	vxorpd %xmm5,%xmm5,%xmm5
 1013b6d:	vmovsd -0x12115(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013b75:	vmovsd -0x40(%rbp),%xmm2
 1013b7a:	vmovapd -0x70(%rbp),%xmm3
 1013b7f:	test   %r14,%r14
 1013b82:	sete   %al
 1013b85:	or     %al,%bl
 1013b87:	mov    $0x3f,%bl
 1013b89:	jne    1013b91 <entry_run+0x1541>
 1013b8b:	test   %r15,-0x10(%r14)
 1013b8f:	je     1013bb8 <entry_run+0x1568>
 1013b91:	test   %r15,-0x10(%r12)
 1013b96:	jne    1013c70 <entry_run+0x1620>
 1013b9c:	mov    -0x18(%r12),%rax
 1013ba1:	dec    %rax
 1013ba4:	jne    1013bae <entry_run+0x155e>
 1013ba6:	cmpq   $0x0,-0x20(%r12)
 1013bac:	je     1013bd9 <entry_run+0x1589>
 1013bae:	mov    %rax,-0x18(%r12)
 1013bb3:	jmp    1013c70 <entry_run+0x1620>
 1013bb8:	mov    -0x18(%r14),%rax
 1013bbc:	dec    %rax
 1013bbf:	jne    1013bc8 <entry_run+0x1578>
 1013bc1:	cmpq   $0x0,-0x20(%r14)
 1013bc6:	je     1013c1b <entry_run+0x15cb>
 1013bc8:	mov    %rax,-0x18(%r14)
 1013bcc:	test   %r15,-0x10(%r12)
 1013bd1:	jne    1013c70 <entry_run+0x1620>
 1013bd7:	jmp    1013b9c <entry_run+0x154c>
 1013bd9:	mov    -0x38(%rbp),%rbx
 1013bdd:	mov    %rbx,%rdi
 1013be0:	mov    %r12,%rsi
 1013be3:	vmovsd %xmm2,-0x40(%rbp)
 1013be8:	vmovapd %xmm3,-0x70(%rbp)
 1013bed:	vzeroupper
 1013bf0:	call   1018ce0 <myl_rc_hold_edge_release>
 1013bf5:	mov    %rbx,%rdi
 1013bf8:	mov    $0x3f,%bl
 1013bfa:	call   101bcb0 <myl_rc_drain>
 1013bff:	vmovapd -0x70(%rbp),%xmm3
 1013c04:	vmovsd -0x40(%rbp),%xmm2
 1013c09:	vmovsd -0x121b1(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013c11:	vxorpd %xmm5,%xmm5,%xmm5
 1013c15:	mov    -0x30(%rbp),%rdi
 1013c19:	jmp    1013c70 <entry_run+0x1620>
 1013c1b:	mov    -0x38(%rbp),%rbx
 1013c1f:	mov    %rbx,%rdi
 1013c22:	mov    %r14,%rsi
 1013c25:	vmovsd %xmm2,-0x40(%rbp)
 1013c2a:	vmovapd %xmm3,-0x70(%rbp)
 1013c2f:	vzeroupper
 1013c32:	call   1018ce0 <myl_rc_hold_edge_release>
 1013c37:	mov    %rbx,%rdi
 1013c3a:	mov    $0x3f,%bl
 1013c3c:	call   101bcb0 <myl_rc_drain>
 1013c41:	vmovapd -0x70(%rbp),%xmm3
 1013c46:	vmovsd -0x40(%rbp),%xmm2
 1013c4b:	vmovsd -0x121f3(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013c53:	vxorpd %xmm5,%xmm5,%xmm5
 1013c57:	mov    -0x30(%rbp),%rdi
 1013c5b:	test   %r15,-0x10(%r12)
 1013c60:	je     1013b9c <entry_run+0x154c>
 1013c66:	cs nopw 0x0(%rax,%rax,1)
 1013c70:	vmovsd %xmm2,-0x1d8(%rbp)
 1013c78:	vmulsd -0x12218(%rip),%xmm2,%xmm0        # 1001a68 <__abi_tag+0x176c>
 1013c80:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 1013c86:	vmovsd -0x1226e(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 1013c8e:	vcmpltsd %xmm2,%xmm1,%xmm1
 1013c93:	vblendvpd %xmm1,-0x1239d(%rip),%xmm0,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013c9d:	vmovupd %xmm3,-0x1d0(%rbp)
 1013ca5:	vmovq  %xmm0,%rax
 1013caa:	bzhi   %rbx,%rax,%rax
 1013caf:	movabs $0x7fefffffffffffff,%rcx
 1013cb9:	cmp    %rcx,%rax
 1013cbc:	jg     1013e8b <entry_run+0x183b>
 1013cc2:	vmovsd -0x1227a(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013cca:	vucomisd %xmm0,%xmm1
 1013cce:	ja     1013e8b <entry_run+0x183b>
 1013cd4:	vucomisd -0x122b4(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013cdc:	jae    1013e8b <entry_run+0x183b>
 1013ce2:	vcvttsd2si %xmm0,%r14
 1013ce7:	vmovsd -0x1d0(%rbp),%xmm0
 1013cef:	vmulsd -0x1228f(%rip),%xmm0,%xmm1        # 1001a68 <__abi_tag+0x176c>
 1013cf7:	vroundsd $0xb,%xmm1,%xmm1,%xmm1
 1013cfd:	vmovsd -0x122e5(%rip),%xmm2        # 1001a20 <__abi_tag+0x1724>
 1013d05:	vcmpltsd %xmm0,%xmm2,%xmm0
 1013d0a:	vblendvpd %xmm0,-0x12414(%rip),%xmm1,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013d14:	vmovq  %xmm0,%rax
 1013d19:	bzhi   %rbx,%rax,%rax
 1013d1e:	movabs $0x7fefffffffffffff,%rcx
 1013d28:	cmp    %rcx,%rax
 1013d2b:	jg     1013eb4 <entry_run+0x1864>
 1013d31:	vmovsd -0x122e9(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013d39:	vucomisd %xmm0,%xmm1
 1013d3d:	ja     1013eb4 <entry_run+0x1864>
 1013d43:	vucomisd -0x12323(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013d4b:	jae    1013eb4 <entry_run+0x1864>
 1013d51:	vcvttsd2si %xmm0,%r12
 1013d56:	vmovsd -0x1c8(%rbp),%xmm0
 1013d5e:	vmulsd -0x122fe(%rip),%xmm0,%xmm1        # 1001a68 <__abi_tag+0x176c>
 1013d66:	vroundsd $0xb,%xmm1,%xmm1,%xmm1
 1013d6c:	vmovsd -0x12354(%rip),%xmm2        # 1001a20 <__abi_tag+0x1724>
 1013d74:	vcmpltsd %xmm0,%xmm2,%xmm0
 1013d79:	vblendvpd %xmm0,-0x12483(%rip),%xmm1,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013d83:	vmovq  %xmm0,%rax
 1013d88:	bzhi   %rbx,%rax,%rax
 1013d8d:	movabs $0x7fefffffffffffff,%rcx
 1013d97:	cmp    %rcx,%rax
 1013d9a:	jg     1013edd <entry_run+0x188d>
 1013da0:	vmovsd -0x12358(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013da8:	vucomisd %xmm0,%xmm1
 1013dac:	ja     1013edd <entry_run+0x188d>
 1013db2:	vucomisd -0x12392(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013dba:	jae    1013edd <entry_run+0x188d>
 1013dc0:	vcvttsd2si %xmm0,%rcx
 1013dc5:	movabs $0xffff800000000000,%rax
 1013dcf:	add    %r14,%rax
 1013dd2:	shr    $0x30,%rax
 1013dd6:	cmp    $0xfffe,%eax
 1013ddb:	jbe    1014531 <entry_run+0x1ee1>
 1013de1:	movabs $0xff80000000000000,%rax
 1013deb:	add    %r12,%rax
 1013dee:	shr    $0x38,%rax
 1013df2:	cmp    $0xfe,%eax
 1013df7:	jbe    1014546 <entry_run+0x1ef6>
 1013dfd:	shl    $0x10,%r14
 1013e01:	shl    $0x8,%r12
 1013e05:	mov    %r14,%rdx
 1013e08:	add    %r12,%rdx
 1013e0b:	jo     101455b <entry_run+0x1f0b>
 1013e11:	mov    %rdx,%rax
 1013e14:	add    %rcx,%rax
 1013e17:	jo     101456b <entry_run+0x1f1b>
 1013e1d:	mov    %r13,%rdx
 1013e20:	shl    $0x5,%rdx
 1013e24:	sub    %r13,%rdx
 1013e27:	mov    %rdx,%rcx
 1013e2a:	add    %rax,%rcx
 1013e2d:	jo     1014575 <entry_run+0x1f25>
 1013e33:	mov    %rcx,%rax
 1013e36:	movabs $0x89705f3112a28fe5,%rdx
 1013e40:	imul   %rdx
 1013e43:	add    %rcx,%rdx
 1013e46:	mov    %rdx,%rax
 1013e49:	shr    $0x3f,%rax
 1013e4d:	sar    $0x1d,%rdx
 1013e51:	add    %rax,%rdx
 1013e54:	imul   $0x3b9aca07,%rdx,%rax
 1013e5b:	sub    %rax,%rcx
 1013e5e:	mov    %rcx,%r13
 1013e61:	sar    $0x3f,%r13
 1013e65:	and    $0x3b9aca07,%r13d
 1013e6c:	add    %rcx,%r13
 1013e6f:	mov    -0x128(%rbp),%rcx
 1013e76:	inc    %rcx
 1013e79:	cmp    $0x780,%rcx
 1013e80:	jne    1013390 <entry_run+0xd40>
 1013e86:	jmp    1013340 <entry_run+0xcf0>
 1013e8b:	mov    $0x10043c9,%esi
 1013e90:	mov    -0x30(%rbp),%rdi
 1013e94:	vzeroupper
 1013e97:	call   1014a6d <fail>
 1013e9c:	vmovsd -0x12444(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ea4:	vxorpd %xmm5,%xmm5,%xmm5
 1013ea8:	mov    -0x30(%rbp),%rdi
 1013eac:	xor    %r14d,%r14d
 1013eaf:	jmp    1013ce7 <entry_run+0x1697>
 1013eb4:	mov    $0x10043c9,%esi
 1013eb9:	mov    -0x30(%rbp),%rdi
 1013ebd:	vzeroupper
 1013ec0:	call   1014a6d <fail>
 1013ec5:	vmovsd -0x1246d(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ecd:	vxorpd %xmm5,%xmm5,%xmm5
 1013ed1:	mov    -0x30(%rbp),%rdi
 1013ed5:	xor    %r12d,%r12d
 1013ed8:	jmp    1013d56 <entry_run+0x1706>
 1013edd:	mov    $0x10043c9,%esi
 1013ee2:	mov    -0x30(%rbp),%rdi
 1013ee6:	vzeroupper
 1013ee9:	call   1014a6d <fail>
 1013eee:	vmovsd -0x12496(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ef6:	vxorpd %xmm5,%xmm5,%xmm5
 1013efa:	mov    -0x30(%rbp),%rdi
 1013efe:	xor    %ecx,%ecx
 1013f00:	jmp    1013dc5 <entry_run+0x1775>
 1013f05:	mov    $0x1,%edi
 1013f0a:	mov    $0x20,%esi
 1013f0f:	vzeroupper
 1013f12:	call   1027510 <calloc@plt>
 1013f17:	mov    %rax,%r12
 1013f1a:	test   %rax,%rax
 1013f1d:	jne    1013f28 <entry_run+0x18d8>
 1013f1f:	mov    -0x30(%rbp),%rdi
 1013f23:	call   1015110 <myl_qbe_fail_allocation>
 1013f28:	lea    -0x260(%rbp),%rdi
 1013f2f:	mov    $0x18,%esi
 1013f34:	mov    $0x10040e8,%edx
 1013f39:	mov    %r13,%rcx
 1013f3c:	xor    %eax,%eax
 1013f3e:	call   1027660 <snprintf@plt>
 1013f43:	test   %eax,%eax
 1013f45:	jle    101415d <entry_run+0x1b0d>
 1013f4b:	mov    %eax,%r13d
 1013f4e:	mov    $0x40,%r15d
 1013f54:	cmp    $0x41,%eax
 1013f57:	jb     101410f <entry_run+0x1abf>
 1013f5d:	mov    $0x80,%r15d
 1013f63:	cmp    $0x81,%r13d
 1013f6a:	jb     101410f <entry_run+0x1abf>
 1013f70:	mov    $0x100,%r15d
 1013f76:	cmp    $0x101,%r13d
 1013f7d:	jb     101410f <entry_run+0x1abf>
 1013f83:	mov    $0x200,%r15d
 1013f89:	cmp    $0x201,%r13d
 1013f90:	jb     101410f <entry_run+0x1abf>
 1013f96:	mov    $0x400,%r15d
 1013f9c:	cmp    $0x401,%r13d
 1013fa3:	jb     101410f <entry_run+0x1abf>
 1013fa9:	mov    $0x800,%r15d
 1013faf:	cmp    $0x801,%r13d
 1013fb6:	jb     101410f <entry_run+0x1abf>
 1013fbc:	mov    $0x1000,%r15d
 1013fc2:	cmp    $0x1001,%r13d
 1013fc9:	jb     101410f <entry_run+0x1abf>
 1013fcf:	mov    $0x2000,%r15d
 1013fd5:	cmp    $0x2001,%r13d
 1013fdc:	jb     101410f <entry_run+0x1abf>
 1013fe2:	mov    $0x4000,%r15d
 1013fe8:	cmp    $0x4001,%r13d
 1013fef:	jb     101410f <entry_run+0x1abf>
 1013ff5:	mov    $0x8000,%r15d
 1013ffb:	cmp    $0x8001,%r13d
 1014002:	jb     101410f <entry_run+0x1abf>
 1014008:	mov    $0x10000,%r15d
 101400e:	cmp    $0x10001,%r13d
 1014015:	jb     101410f <entry_run+0x1abf>
 101401b:	mov    $0x20000,%r15d
 1014021:	cmp    $0x20001,%r13d
 1014028:	jb     101410f <entry_run+0x1abf>
 101402e:	mov    $0x40000,%r15d
 1014034:	cmp    $0x40001,%r13d
 101403b:	jb     101410f <entry_run+0x1abf>
 1014041:	mov    $0x80000,%r15d
 1014047:	cmp    $0x80001,%r13d
 101404e:	jb     101410f <entry_run+0x1abf>
 1014054:	mov    $0x100000,%r15d
 101405a:	cmp    $0x100001,%r13d
 1014061:	jb     101410f <entry_run+0x1abf>
 1014067:	mov    $0x200000,%r15d
 101406d:	cmp    $0x200001,%r13d
 1014074:	jb     101410f <entry_run+0x1abf>
 101407a:	mov    $0x400000,%r15d
 1014080:	cmp    $0x400001,%r13d
 1014087:	jb     101410f <entry_run+0x1abf>
 101408d:	mov    $0x800000,%r15d
 1014093:	cmp    $0x800001,%r13d
 101409a:	jb     101410f <entry_run+0x1abf>
 101409c:	mov    $0x1000000,%r15d
 10140a2:	cmp    $0x1000001,%r13d
 10140a9:	jb     101410f <entry_run+0x1abf>
 10140ab:	mov    $0x2000000,%r15d
 10140b1:	cmp    $0x2000001,%r13d
 10140b8:	jb     101410f <entry_run+0x1abf>
 10140ba:	mov    $0x4000000,%r15d
 10140c0:	cmp    $0x4000001,%r13d
 10140c7:	jb     101410f <entry_run+0x1abf>
 10140c9:	mov    $0x8000000,%r15d
 10140cf:	cmp    $0x8000001,%r13d
 10140d6:	jb     101410f <entry_run+0x1abf>
 10140d8:	mov    $0x10000000,%r15d
 10140de:	cmp    $0x10000001,%r13d
 10140e5:	jb     101410f <entry_run+0x1abf>
 10140e7:	mov    $0x20000000,%r15d
 10140ed:	cmp    $0x20000001,%r13d
 10140f4:	jb     101410f <entry_run+0x1abf>
 10140f6:	xor    %r15d,%r15d
 10140f9:	cmp    $0x40000001,%r13d
 1014100:	setae  %r15b
 1014104:	shl    $0x1e,%r15d
 1014108:	add    $0x40000000,%r15
 101410f:	mov    %r15,%rdi
 1014112:	call   1027500 <malloc@plt>
 1014117:	test   %rax,%rax
 101411a:	je     101418e <entry_run+0x1b3e>
 101411c:	mov    %r13d,%r14d
 101411f:	mov    %rax,(%r12)
 1014123:	mov    %r15,0x10(%r12)
 1014128:	lea    -0x260(%rbp),%rsi
 101412f:	mov    %rax,-0x40(%rbp)
 1014133:	mov    %rax,%rdi
 1014136:	mov    %r14,%rdx
 1014139:	call   1027520 <memcpy@plt>
 101413e:	lea    0x8(%r12),%r13
 1014143:	mov    %r14,0x8(%r12)
 1014148:	mov    %r12,%rbx
 101414b:	add    $0x18,%rbx
 101414f:	cmp    %r14,%r15
 1014152:	jne    10141a8 <entry_run+0x1b58>
 1014154:	add    %r15,%r15
 1014157:	mov    -0x40(%rbp),%rdi
 101415b:	jmp    1014171 <entry_run+0x1b21>
 101415d:	lea    0x18(%r12),%rbx
 1014162:	mov    %r12,%r13
 1014165:	add    $0x8,%r13
 1014169:	mov    $0x40,%r15d
 101416f:	xor    %edi,%edi
 1014171:	mov    %r15,%rsi
 1014174:	call   1027670 <realloc@plt>
 1014179:	test   %rax,%rax
 101417c:	je     10141a0 <entry_run+0x1b50>
 101417e:	mov    %rax,(%r12)
 1014182:	mov    %r15,0x10(%r12)
 1014187:	mov    0x8(%r12),%r14
 101418c:	jmp    10141ac <entry_run+0x1b5c>
 101418e:	mov    %r12,%rbx
 1014191:	add    $0x18,%rbx
 1014195:	movl   $0x1,0x18(%r12)
 101419e:	jmp    10141b5 <entry_run+0x1b65>
 10141a0:	movl   $0x1,(%rbx)
 10141a6:	jmp    10141b5 <entry_run+0x1b65>
 10141a8:	mov    -0x40(%rbp),%rax
 10141ac:	movb   $0xa,(%rax,%r14,1)
 10141b1:	incq   0x0(%r13)
 10141b5:	movabs $0x4000000000000002,%r14
 10141bf:	cmpl   $0x0,0x1c(%r12)
 10141c5:	jne    1014369 <entry_run+0x1d19>
 10141cb:	cmpl   $0x0,(%rbx)
 10141ce:	je     10141db <entry_run+0x1b8b>
 10141d0:	mov    -0x30(%rbp),%rdi
 10141d4:	call   1015110 <myl_qbe_fail_allocation>
 10141d9:	jmp    1014226 <entry_run+0x1bd6>
 10141db:	mov    0x149be(%rip),%rax        # 1028ba0 <stdout@GLIBC_2.2.5>
 10141e2:	mov    (%rax),%r14
 10141e5:	mov    0x8(%r12),%r15
 10141ea:	test   %r15,%r15
 10141ed:	je     101420c <entry_run+0x1bbc>
 10141ef:	mov    (%r12),%rdi
 10141f3:	mov    $0x1,%esi
 10141f8:	mov    %r15,%rdx
 10141fb:	mov    %r14,%rcx
 10141fe:	call   10275d0 <fwrite@plt>
 1014203:	cmp    %r15,%rax
 1014206:	jne    10143dc <entry_run+0x1d8c>
 101420c:	mov    %r14,%rdi
 101420f:	call   1027680 <fflush@plt>
 1014214:	test   %eax,%eax
 1014216:	movabs $0x4000000000000002,%r14
 1014220:	jne    101439e <entry_run+0x1d4e>
 1014226:	mov    (%r12),%rdi
 101422a:	call   1027570 <free@plt>
 101422f:	mov    %r12,%rdi
 1014232:	call   1027570 <free@plt>
 1014237:	cmpb   $0x1,0x17572(%rip)        # 102b7b0 <exit_without_sweep>
 101423e:	jne    101426d <entry_run+0x1c1d>
 1014240:	mov    -0x30(%rbp),%rax
 1014244:	cmpl   $0x0,0x2c0(%rax)
 101424b:	jne    101426d <entry_run+0x1c1d>
 101424d:	mov    -0x30(%rbp),%rax
 1014251:	cmpq   $0x0,0x3990(%rax)
 1014259:	jne    101426d <entry_run+0x1c1d>
 101425b:	mov    -0x30(%rbp),%rax
 101425f:	cmpq   $0x0,0x3998(%rax)
 1014267:	je     1014488 <entry_run+0x1e38>
 101426d:	mov    -0x80(%rbp),%rax
 1014271:	test   %rax,%rax
 1014274:	je     1014294 <entry_run+0x1c44>
 1014276:	test   %r14,-0x10(%rax)
 101427a:	jne    1014294 <entry_run+0x1c44>
 101427c:	mov    -0x20(%rax),%rcx
 1014280:	dec    %rcx
 1014283:	jne    1014290 <entry_run+0x1c40>
 1014285:	cmpq   $0x0,-0x18(%rax)
 101428a:	je     1014370 <entry_run+0x1d20>
 1014290:	mov    %rcx,-0x20(%rax)
 1014294:	cmpl   $0x0,-0x50(%rbp)
 1014298:	je     1014488 <entry_run+0x1e38>
 101429e:	mov    -0x48(%rbp),%rax
 10142a2:	test   %rax,%rax
 10142a5:	je     1014488 <entry_run+0x1e38>
 10142ab:	test   %r14,-0x10(%rax)
 10142af:	jne    1014488 <entry_run+0x1e38>
 10142b5:	mov    -0x20(%rax),%rcx
 10142b9:	dec    %rcx
 10142bc:	jne    10142c9 <entry_run+0x1c79>
 10142be:	cmpq   $0x0,-0x18(%rax)
 10142c3:	je     101438c <entry_run+0x1d3c>
 10142c9:	mov    %rcx,-0x20(%rax)
 10142cd:	jmp    1014488 <entry_run+0x1e38>
 10142d2:	mov    -0x30(%rbp),%rdi
 10142d6:	mov    0x1860(%rdi),%rax
 10142dd:	test   %rax,%rax
 10142e0:	je     10144fc <entry_run+0x1eac>
 10142e6:	mov    0x124(%rax),%esi
 10142ec:	movl   $0x0,0x124(%rax)
 10142f6:	call   10145f0 <myl_qbe_rc_status>
 10142fb:	jmp    1014488 <entry_run+0x1e38>
 1014300:	mov    %r14,-0x260(%rbp)
 1014307:	lea    -0xf8(%rbp),%rax
 101430e:	mov    %rax,-0x258(%rbp)
 1014315:	movq   $0x0,-0x250(%rbp)
 1014320:	mov    %r15d,-0x248(%rbp)
 1014327:	movl   $0x0,-0x244(%rbp)
 1014331:	lea    -0x260(%rbp),%rsi
 1014338:	lea    -0x58(%rbp),%rcx
 101433c:	mov    -0x38(%rbp),%rdi
 1014340:	mov    %r14,%rdx
 1014343:	call   101e980 <transfer>
 1014348:	test   %eax,%eax
 101434a:	je     1012937 <entry_run+0x2e7>
 1014350:	mov    -0x30(%rbp),%rbx
 1014354:	mov    0x1860(%rbx),%rcx
 101435b:	test   %rcx,%rcx
 101435e:	jne    1012a1c <entry_run+0x3cc>
 1014364:	jmp    10144fc <entry_run+0x1eac>
 1014369:	mov    $0x1003d5c,%esi
 101436e:	jmp    10143a3 <entry_run+0x1d53>
 1014370:	lea    -0x80(%rbp),%rsi
 1014374:	mov    -0x38(%rbp),%rdi
 1014378:	call   100f670 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 101437d:	cmpl   $0x0,-0x50(%rbp)
 1014381:	jne    101429e <entry_run+0x1c4e>
 1014387:	jmp    1014488 <entry_run+0x1e38>
 101438c:	lea    -0x48(%rbp),%rsi
 1014390:	mov    -0x38(%rbp),%rdi
 1014394:	call   100f670 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1014399:	jmp    1014488 <entry_run+0x1e38>
 101439e:	mov    $0x10042d4,%esi
 10143a3:	mov    -0x30(%rbp),%rdi
 10143a7:	call   1014a6d <fail>
 10143ac:	jmp    1014226 <entry_run+0x1bd6>
 10143b1:	mov    $0x100432e,%esi
 10143b6:	vzeroupper
 10143b9:	call   1014a6d <fail>
 10143be:	jmp    1014488 <entry_run+0x1e38>
 10143c3:	lea    -0x48(%rbp),%rsi
 10143c7:	mov    -0x38(%rbp),%rdi
 10143cb:	vzeroupper
 10143ce:	call   100f670 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10143d3:	mov    -0x30(%rbp),%rdi
 10143d7:	jmp    1013251 <entry_run+0xc01>
 10143dc:	mov    $0x10042d4,%esi
 10143e1:	mov    -0x30(%rbp),%rdi
 10143e5:	call   1014a6d <fail>
 10143ea:	movabs $0x4000000000000002,%r14
 10143f4:	jmp    1014226 <entry_run+0x1bd6>
 10143f9:	mov    $0x1002338,%esi
 10143fe:	call   1018df4 <myl_rc_binding_find_slow>
 1014403:	mov    -0x30(%rbp),%rbx
 1014407:	mov    %rax,%r12
 101440a:	test   %r12,%r12
 101440d:	jne    1012889 <entry_run+0x239>
 1014413:	mov    $0x1002338,%esi
 1014418:	mov    -0x38(%rbp),%rdi
 101441c:	call   1023330 <myl_rc_native_shape>
 1014421:	mov    -0x30(%rbp),%rbx
 1014425:	test   %rax,%rax
 1014428:	je     1014463 <entry_run+0x1e13>
 101442a:	mov    0x1860(%rbx),%rdi
 1014431:	cmpq   $0x1a,0xa0(%rdi)
 1014439:	jb     10144cd <entry_run+0x1e7d>
 101443f:	mov    0x98(%rdi),%rax
 1014446:	cmpq   $0x1002338,0x190(%rax)
 1014451:	jne    10144cd <entry_run+0x1e7d>
 1014453:	mov    0x198(%rax),%r12
 101445a:	test   %r12,%r12
 101445d:	jne    1012889 <entry_run+0x239>
 1014463:	mov    0x1860(%rbx),%rcx
 101446a:	test   %rcx,%rcx
 101446d:	je     10144fc <entry_run+0x1eac>
 1014473:	mov    0x124(%rcx),%eax
 1014479:	movl   $0x0,0x124(%rcx)
 1014483:	test   %rax,%rax
 1014486:	jne    101449c <entry_run+0x1e4c>
 1014488:	xor    %eax,%eax
 101448a:	add    $0x408,%rsp
 1014491:	pop    %rbx
 1014492:	pop    %r12
 1014494:	pop    %r13
 1014496:	pop    %r14
 1014498:	pop    %r15
 101449a:	pop    %rbp
 101449b:	ret
 101449c:	cmp    $0x1,%eax
 101449f:	jne    10144b5 <entry_run+0x1e65>
 10144a1:	mov    $0x1004361,%esi
 10144a6:	mov    -0x30(%rbp),%rcx
 10144aa:	cmpl   $0x0,0x2c4(%rcx)
 10144b1:	je     10144ba <entry_run+0x1e6a>
 10144b3:	jmp    10144c2 <entry_run+0x1e72>
 10144b5:	cmp    $0x4,%eax
 10144b8:	jae    1014501 <entry_run+0x1eb1>
 10144ba:	mov    0x100b5d0(,%rax,8),%rsi
 10144c2:	mov    -0x30(%rbp),%rdi
 10144c6:	call   1014a6d <fail>
 10144cb:	jmp    1014488 <entry_run+0x1e38>
 10144cd:	mov    $0x1002338,%esi
 10144d2:	call   1018df4 <myl_rc_binding_find_slow>
 10144d7:	mov    -0x30(%rbp),%rbx
 10144db:	mov    %rax,%r12
 10144de:	test   %r12,%r12
 10144e1:	jne    1012889 <entry_run+0x239>
 10144e7:	jmp    1014463 <entry_run+0x1e13>
 10144ec:	vzeroupper
 10144ef:	call   10151a0 <myl_qbe_fail_iteration>
 10144f4:	vzeroupper
 10144f7:	call   10152d0 <myl_qbe_fail_frame>
 10144fc:	call   10187d4 <myl_rc_invariant_failed>
 1014501:	call   1027690 <abort@plt>
 1014506:	vzeroupper
 1014509:	call   10152d0 <myl_qbe_fail_frame>
 101450e:	vzeroupper
 1014511:	call   10151a0 <myl_qbe_fail_iteration>
 1014516:	vzeroupper
 1014519:	call   10152d0 <myl_qbe_fail_frame>
 101451e:	vzeroupper
 1014521:	call   10152d0 <myl_qbe_fail_frame>
 1014526:	mov    %r13,%rsi
 1014529:	vzeroupper
 101452c:	call   1015270 <myl_qbe_fail_cast>
 1014531:	mov    $0x2,%esi
 1014536:	mov    $0x10000,%ecx
 101453b:	mov    %r14,%rdx
 101453e:	vzeroupper
 1014541:	call   1015210 <myl_qbe_fail_overflow_op>
 1014546:	mov    $0x2,%esi
 101454b:	mov    $0x100,%ecx
 1014550:	mov    %r12,%rdx
 1014553:	vzeroupper
 1014556:	call   1015210 <myl_qbe_fail_overflow_op>
 101455b:	xor    %esi,%esi
 101455d:	mov    %r14,%rdx
 1014560:	mov    %r12,%rcx
 1014563:	vzeroupper
 1014566:	call   1015210 <myl_qbe_fail_overflow_op>
 101456b:	xor    %esi,%esi
 101456d:	vzeroupper
 1014570:	call   1015210 <myl_qbe_fail_overflow_op>
 1014575:	xor    %esi,%esi
 1014577:	mov    %rax,%rcx
 101457a:	vzeroupper
 101457d:	call   1015210 <myl_qbe_fail_overflow_op>
 1014582:	mov    %r14,%rsi
 1014585:	mov    %r13,%rdx
 1014588:	vzeroupper
 101458b:	call   10151b0 <myl_qbe_fail_normalized_index_bounds>
 1014590:	vzeroupper
 1014593:	call   10152d0 <myl_qbe_fail_frame>
 1014598:	mov    %r14,%rsi
 101459b:	vzeroupper
 101459e:	call   1015270 <myl_qbe_fail_cast>
 10145a3:	call   10152d0 <myl_qbe_fail_frame>
 10145a8:	mov    -0x30(%rbp),%rdi
 10145ac:	call   1015110 <myl_qbe_fail_allocation>
 10145b1:	mov    -0x30(%rbp),%rdi
 10145b5:	call   1015110 <myl_qbe_fail_allocation>
 10145ba:	mov    -0x30(%rbp),%rdi
 10145be:	call   1015110 <myl_qbe_fail_allocation>
 10145c3:	mov    -0x30(%rbp),%rdi
 10145c7:	call   1015110 <myl_qbe_fail_allocation>
 10145cc:	mov    -0x30(%rbp),%rdi
 10145d0:	call   1015110 <myl_qbe_fail_allocation>
 10145d5:	vzeroupper
 10145d8:	call   10152d0 <myl_qbe_fail_frame>
 10145dd:	call   1015110 <myl_qbe_fail_allocation>
 10145e2:	int3
 10145e3:	int3
 10145e4:	int3
 10145e5:	int3
 10145e6:	int3
 10145e7:	int3
 10145e8:	int3
 10145e9:	int3
 10145ea:	int3
 10145eb:	int3
 10145ec:	int3
 10145ed:	int3
 10145ee:	int3
 10145ef:	int3

00000000010145f0 <myl_qbe_rc_status>:
 10145f0:	test   %esi,%esi
 10145f2:	jne    10145f5 <myl_qbe_rc_status+0x5>
 10145f4:	ret
 10145f5:	cmp    $0x1,%esi
 10145f8:	jne    1014610 <myl_qbe_rc_status+0x20>
 10145fa:	mov    $0x1004361,%eax
 10145ff:	cmpl   $0x0,0x2c4(%rdi)
 1014606:	je     1014615 <myl_qbe_rc_status+0x25>
 1014608:	mov    %rax,%rsi
 101460b:	jmp    1014a6d <fail>
 1014610:	cmp    $0x4,%esi
 1014613:	jae    1014627 <myl_qbe_rc_status+0x37>
 1014615:	mov    %esi,%eax
 1014617:	mov    0x100b5d0(,%rax,8),%rax
 101461f:	mov    %rax,%rsi
 1014622:	jmp    1014a6d <fail>
 1014627:	push   %rbp
 1014628:	mov    %rsp,%rbp
 101462b:	call   1027690 <abort@plt>

0000000001014630 <myl_qbe_rc_trap>:
 1014630:	push   %rbp
 1014631:	mov    %rsp,%rbp
 1014634:	push   %r15
 1014636:	push   %r14
 1014638:	push   %r13
 101463a:	push   %r12
 101463c:	push   %rbx
 101463d:	push   %rax
 101463e:	mov    0x1860(%rdi),%rax
 1014645:	test   %rax,%rax
 1014648:	je     101473c <myl_qbe_rc_trap+0x10c>
 101464e:	mov    0xf8(%rax),%r14
 1014655:	movq   $0x0,0xf8(%rax)
 1014660:	test   %r14,%r14
 1014663:	je     101473c <myl_qbe_rc_trap+0x10c>
 1014669:	vxorps %xmm0,%xmm0,%xmm0
 101466d:	lea    0x258(%rdi),%rbx
 1014674:	jmp    101469d <myl_qbe_rc_trap+0x6d>
 1014676:	cs nopw 0x0(%rax,%rax,1)
 1014680:	add    $0x8,%r14
 1014684:	vmovups %xmm0,(%r14)
 1014689:	movl   $0x0,0x10(%r14)
 1014691:	mov    %r15,%r14
 1014694:	test   %r15,%r15
 1014697:	je     101473c <myl_qbe_rc_trap+0x10c>
 101469d:	mov    0x8(%r14),%r15
 10146a1:	mov    0x10(%r14),%rsi
 10146a5:	test   %rsi,%rsi
 10146a8:	je     1014680 <myl_qbe_rc_trap+0x50>
 10146aa:	nopw   0x0(%rax,%rax,1)
 10146b0:	mov    (%rsi),%r12
 10146b3:	mov    0x1860(%rdi),%rax
 10146ba:	mov    0x108(%rax),%rcx
 10146c1:	cmp    $0x20,%rcx
 10146c5:	je     1014719 <myl_qbe_rc_trap+0xe9>
 10146c7:	mov    0x270(%rdi),%rdx
 10146ce:	cmp    $0x28,%rdx
 10146d2:	jb     101474b <myl_qbe_rc_trap+0x11b>
 10146d4:	mov    0x30(%rax),%r8
 10146d8:	cmp    $0x27,%r8
 10146dc:	jbe    101474b <myl_qbe_rc_trap+0x11b>
 10146de:	add    $0xffffffffffffffd8,%rdx
 10146e2:	mov    %rdx,0x270(%rdi)
 10146e9:	add    $0xffffffffffffffd8,%r8
 10146ed:	mov    %r8,0x30(%rax)
 10146f1:	mov    0x100(%rax),%rdx
 10146f8:	mov    %rdx,(%rsi)
 10146fb:	mov    %rsi,0x100(%rax)
 1014702:	inc    %rcx
 1014705:	mov    %rcx,0x108(%rax)
 101470c:	mov    %r12,%rsi
 101470f:	test   %r12,%r12
 1014712:	jne    10146b0 <myl_qbe_rc_trap+0x80>
 1014714:	jmp    1014680 <myl_qbe_rc_trap+0x50>
 1014719:	mov    %rdi,%r13
 101471c:	mov    %rbx,%rdi
 101471f:	call   101e38f <entry_release>
 1014724:	vxorps %xmm0,%xmm0,%xmm0
 1014728:	mov    %r13,%rdi
 101472b:	mov    %r12,%rsi
 101472e:	test   %r12,%r12
 1014731:	jne    10146b0 <myl_qbe_rc_trap+0x80>
 1014737:	jmp    1014680 <myl_qbe_rc_trap+0x50>
 101473c:	add    $0x8,%rsp
 1014740:	pop    %rbx
 1014741:	pop    %r12
 1014743:	pop    %r13
 1014745:	pop    %r14
 1014747:	pop    %r15
 1014749:	pop    %rbp
 101474a:	ret
 101474b:	call   10187d4 <myl_rc_invariant_failed>

0000000001014750 <myl_qbe_rc_unique_local>:
 1014750:	push   %rbp
 1014751:	mov    %rsp,%rbp
 1014754:	push   %r15
 1014756:	push   %r14
 1014758:	push   %r13
 101475a:	push   %r12
 101475c:	push   %rbx
 101475d:	push   %rax
 101475e:	mov    (%rsi),%rcx
 1014761:	mov    $0x1,%eax
 1014766:	test   %rcx,%rcx
 1014769:	je     1014a2a <myl_qbe_rc_unique_local+0x2da>
 101476f:	movabs $0x2000000000000002,%r9
 1014779:	mov    -0x10(%rcx),%r8
 101477d:	test   %r9,%r8
 1014780:	je     10148ae <myl_qbe_rc_unique_local+0x15e>
 1014786:	mov    0x1860(%rdi),%rcx
 101478d:	cmpq   $0x1a,0xa0(%rcx)
 1014795:	jb     1014a39 <myl_qbe_rc_unique_local+0x2e9>
 101479b:	mov    0x98(%rcx),%r8
 10147a2:	cmpq   $0x1002338,0x190(%r8)
 10147ad:	jne    1014a39 <myl_qbe_rc_unique_local+0x2e9>
 10147b3:	mov    0x198(%r8),%rcx
 10147ba:	test   %rcx,%rcx
 10147bd:	je     10149ce <myl_qbe_rc_unique_local+0x27e>
 10147c3:	mov    0x8(%rcx),%rcx
 10147c7:	cmpl   $0x1,0x8(%rcx)
 10147cb:	jne    10149ce <myl_qbe_rc_unique_local+0x27e>
 10147d1:	mov    (%rsi),%rbx
 10147d4:	test   %rbx,%rbx
 10147d7:	je     10148ea <myl_qbe_rc_unique_local+0x19a>
 10147dd:	mov    -0x10(%rbx),%r10
 10147e1:	mov    %r10,%r11
 10147e4:	shr    $0x28,%r11
 10147e8:	and    $0xfffff,%r11d
 10147ef:	xor    %r8d,%r8d
 10147f2:	bt     $0x3e,%r10
 10147f7:	cmovb  %r11d,%r8d
 10147fb:	lea    0x258(%rdi),%r14
 1014802:	cmpl   $0x0,(%rdx)
 1014805:	mov    (%rcx),%rcx
 1014808:	je     1014900 <myl_qbe_rc_unique_local+0x1b0>
 101480e:	cmp    $0x8,%rcx
 1014812:	jne    10149ce <myl_qbe_rc_unique_local+0x27e>
 1014818:	test   %rbx,%rbx
 101481b:	je     1014a2a <myl_qbe_rc_unique_local+0x2da>
 1014821:	mov    -0x10(%rbx),%rcx
 1014825:	movabs $0x6000000000000002,%rdx
 101482f:	test   %rdx,%rcx
 1014832:	jne    1014842 <myl_qbe_rc_unique_local+0xf2>
 1014834:	cmpq   $0x0,0x1860(%rdi)
 101483c:	je     10149ce <myl_qbe_rc_unique_local+0x27e>
 1014842:	test   %r9,%rcx
 1014845:	je     1014980 <myl_qbe_rc_unique_local+0x230>
 101484b:	mov    %rsi,%r12
 101484e:	mov    %rdi,%r15
 1014851:	movq   $0x0,-0x30(%rbp)
 1014859:	lea    -0x30(%rbp),%rcx
 101485d:	mov    %r14,%rdi
 1014860:	mov    %rbx,%rsi
 1014863:	mov    %r8d,%edx
 1014866:	call   1020bc0 <clone_payload>
 101486b:	test   %eax,%eax
 101486d:	jne    10149ef <myl_qbe_rc_unique_local+0x29f>
 1014873:	mov    -0x30(%rbp),%rax
 1014877:	mov    %rax,(%r12)
 101487b:	mov    %r14,%rdi
 101487e:	mov    %rbx,%rsi
 1014881:	call   1018bc0 <myl_rc_edge_release>
 1014886:	mov    0x1860(%r15),%rax
 101488d:	test   %rax,%rax
 1014890:	je     10148a4 <myl_qbe_rc_unique_local+0x154>
 1014892:	cmpq   $0x0,0xc8(%rax)
 101489a:	je     10148a4 <myl_qbe_rc_unique_local+0x154>
 101489c:	mov    %r14,%rdi
 101489f:	call   101bcb0 <myl_rc_drain>
 10148a4:	mov    $0x1,%eax
 10148a9:	jmp    1014a2a <myl_qbe_rc_unique_local+0x2da>
 10148ae:	bt     $0x3e,%r8
 10148b3:	jb     1014a2a <myl_qbe_rc_unique_local+0x2da>
 10148b9:	test   $0x1,%r8b
 10148bd:	jne    10149ce <myl_qbe_rc_unique_local+0x27e>
 10148c3:	mov    -0x20(%rcx),%r8
 10148c7:	cmp    $0x1,%r8
 10148cb:	je     1014a2a <myl_qbe_rc_unique_local+0x2da>
 10148d1:	test   %r8,%r8
 10148d4:	jne    1014786 <myl_qbe_rc_unique_local+0x36>
 10148da:	cmpq   $0x0,-0x18(%rcx)
 10148df:	jne    1014a2a <myl_qbe_rc_unique_local+0x2da>
 10148e5:	jmp    10149ce <myl_qbe_rc_unique_local+0x27e>
 10148ea:	xor    %r8d,%r8d
 10148ed:	lea    0x258(%rdi),%r14
 10148f4:	cmpl   $0x0,(%rdx)
 10148f7:	mov    (%rcx),%rcx
 10148fa:	jne    101480e <myl_qbe_rc_unique_local+0xbe>
 1014900:	cmp    $0x8,%rcx
 1014904:	jne    10149ce <myl_qbe_rc_unique_local+0x27e>
 101490a:	test   %rbx,%rbx
 101490d:	je     1014a2a <myl_qbe_rc_unique_local+0x2da>
 1014913:	mov    -0x10(%rbx),%rcx
 1014917:	movabs $0x6000000000000002,%r10
 1014921:	test   %r10,%rcx
 1014924:	jne    1014934 <myl_qbe_rc_unique_local+0x1e4>
 1014926:	cmpq   $0x0,0x1860(%rdi)
 101492e:	je     10149ce <myl_qbe_rc_unique_local+0x27e>
 1014934:	test   %r9,%rcx
 1014937:	je     10149a8 <myl_qbe_rc_unique_local+0x258>
 1014939:	mov    %rdx,%r12
 101493c:	mov    %rsi,%r13
 101493f:	mov    %rdi,%r15
 1014942:	movq   $0x0,-0x30(%rbp)
 101494a:	lea    -0x30(%rbp),%rcx
 101494e:	mov    %r14,%rdi
 1014951:	mov    %rbx,%rsi
 1014954:	mov    %r8d,%edx
 1014957:	call   1020bc0 <clone_payload>
 101495c:	mov    %eax,%ecx
 101495e:	xor    %edx,%edx
 1014960:	test   %eax,%eax
 1014962:	jne    1014968 <myl_qbe_rc_unique_local+0x218>
 1014964:	mov    -0x30(%rbp),%rdx
 1014968:	mov    $0x1,%eax
 101496d:	jne    10149d3 <myl_qbe_rc_unique_local+0x283>
 101496f:	mov    %rdx,0x0(%r13)
 1014973:	movl   $0x1,(%r12)
 101497b:	jmp    1014a2a <myl_qbe_rc_unique_local+0x2da>
 1014980:	bt     $0x3e,%rcx
 1014985:	jb     1014a2a <myl_qbe_rc_unique_local+0x2da>
 101498b:	test   $0x1,%cl
 101498e:	jne    10149ce <myl_qbe_rc_unique_local+0x27e>
 1014990:	mov    -0x20(%rbx),%rcx
 1014994:	cmp    $0x1,%rcx
 1014998:	je     1014a2a <myl_qbe_rc_unique_local+0x2da>
 101499e:	test   %rcx,%rcx
 10149a1:	je     10149c7 <myl_qbe_rc_unique_local+0x277>
 10149a3:	jmp    101484b <myl_qbe_rc_unique_local+0xfb>
 10149a8:	bt     $0x3e,%rcx
 10149ad:	jb     1014a2a <myl_qbe_rc_unique_local+0x2da>
 10149af:	test   $0x1,%cl
 10149b2:	jne    10149ce <myl_qbe_rc_unique_local+0x27e>
 10149b4:	mov    -0x20(%rbx),%rcx
 10149b8:	cmp    $0x1,%rcx
 10149bc:	je     1014a2a <myl_qbe_rc_unique_local+0x2da>
 10149be:	test   %rcx,%rcx
 10149c1:	jne    1014939 <myl_qbe_rc_unique_local+0x1e9>
 10149c7:	cmpq   $0x0,-0x18(%rbx)
 10149cc:	jne    1014a2a <myl_qbe_rc_unique_local+0x2da>
 10149ce:	call   10187d4 <myl_rc_invariant_failed>
 10149d3:	test   %ecx,%ecx
 10149d5:	je     1014a2a <myl_qbe_rc_unique_local+0x2da>
 10149d7:	mov    %r15,%rdi
 10149da:	cmp    $0x1,%ecx
 10149dd:	jne    1014a14 <myl_qbe_rc_unique_local+0x2c4>
 10149df:	mov    $0x1004361,%esi
 10149e4:	cmpl   $0x0,0x2c4(%rdi)
 10149eb:	je     1014a19 <myl_qbe_rc_unique_local+0x2c9>
 10149ed:	jmp    1014a23 <myl_qbe_rc_unique_local+0x2d3>
 10149ef:	cmp    $0x1,%eax
 10149f2:	jne    1014a08 <myl_qbe_rc_unique_local+0x2b8>
 10149f4:	mov    $0x1004361,%esi
 10149f9:	mov    %r15,%rdi
 10149fc:	cmpl   $0x0,0x2c4(%r15)
 1014a04:	je     1014a10 <myl_qbe_rc_unique_local+0x2c0>
 1014a06:	jmp    1014a23 <myl_qbe_rc_unique_local+0x2d3>
 1014a08:	cmp    $0x4,%eax
 1014a0b:	mov    %r15,%rdi
 1014a0e:	jae    1014a68 <myl_qbe_rc_unique_local+0x318>
 1014a10:	mov    %eax,%eax
 1014a12:	jmp    1014a1b <myl_qbe_rc_unique_local+0x2cb>
 1014a14:	cmp    $0x4,%ecx
 1014a17:	jae    1014a68 <myl_qbe_rc_unique_local+0x318>
 1014a19:	mov    %ecx,%eax
 1014a1b:	mov    0x100b5d0(,%rax,8),%rsi
 1014a23:	call   1014a6d <fail>
 1014a28:	xor    %eax,%eax
 1014a2a:	add    $0x8,%rsp
 1014a2e:	pop    %rbx
 1014a2f:	pop    %r12
 1014a31:	pop    %r13
 1014a33:	pop    %r14
 1014a35:	pop    %r15
 1014a37:	pop    %rbp
 1014a38:	ret
 1014a39:	mov    %rsi,%r8
 1014a3c:	mov    $0x1002338,%esi
 1014a41:	mov    %rdi,%r10
 1014a44:	mov    %rcx,%rdi
 1014a47:	call   1018df4 <myl_rc_binding_find_slow>
 1014a4c:	mov    %r8,%rsi
 1014a4f:	mov    %r10,%rdi
 1014a52:	mov    %rax,%rcx
 1014a55:	mov    $0x1,%eax
 1014a5a:	test   %rcx,%rcx
 1014a5d:	jne    10147c3 <myl_qbe_rc_unique_local+0x73>
 1014a63:	jmp    10149ce <myl_qbe_rc_unique_local+0x27e>
 1014a68:	call   1027690 <abort@plt>

0000000001014a6d <fail>:
 1014a6d:	push   %rbp
 1014a6e:	mov    %rsp,%rbp
 1014a71:	push   %r15
 1014a73:	push   %r14
 1014a75:	push   %rbx
 1014a76:	push   %rax
 1014a77:	cmpq   $0x0,0x20(%rdi)
 1014a7c:	jne    1014aec <fail+0x7f>
 1014a7e:	mov    %rdi,%rbx
 1014a81:	mov    %rsi,0x20(%rdi)
 1014a85:	movq   $0x0,-0x20(%rbp)
 1014a8d:	mov    0x30(%rdi),%r15
 1014a91:	test   %r15,%r15
 1014a94:	je     1014abe <fail+0x51>
 1014a96:	lea    -0x20(%rbp),%r14
 1014a9a:	mov    0x8(%r15),%rsi
 1014a9e:	mov    0x10(%r15),%rdx
 1014aa2:	mov    %rbx,%rdi
 1014aa5:	xor    %ecx,%ecx
 1014aa7:	mov    %r14,%r8
 1014aaa:	call   1014b10 <trace_frame>
 1014aaf:	mov    (%r15),%r15
 1014ab2:	test   %r15,%r15
 1014ab5:	jne    1014a9a <fail+0x2d>
 1014ab7:	cmpq   $0x0,0x30(%rbx)
 1014abc:	jne    1014aca <fail+0x5d>
 1014abe:	lea    -0x20(%rbp),%rsi
 1014ac2:	mov    %rbx,%rdi
 1014ac5:	call   1014c60 <walk_frames>
 1014aca:	mov    -0x20(%rbp),%rax
 1014ace:	xor    %ecx,%ecx
 1014ad0:	sub    0x248(%rbx),%rax
 1014ad7:	cmovae %rax,%rcx
 1014adb:	mov    %rcx,0x250(%rbx)
 1014ae2:	cmpq   $0x0,0x3e60(%rbx)
 1014aea:	jne    1014af7 <fail+0x8a>
 1014aec:	add    $0x8,%rsp
 1014af0:	pop    %rbx
 1014af1:	pop    %r14
 1014af3:	pop    %r15
 1014af5:	pop    %rbp
 1014af6:	ret
 1014af7:	mov    %rbx,%rdi
 1014afa:	call   1014630 <myl_qbe_rc_trap>
 1014aff:	mov    0x3e60(%rbx),%rdi
 1014b06:	mov    $0x1,%esi
 1014b0b:	call   10276a0 <longjmp@plt>

0000000001014b10 <trace_frame>:
 1014b10:	test   %rsi,%rsi
 1014b13:	je     1014c30 <trace_frame+0x120>
 1014b19:	cmp    0x10(%rsi),%rdx
 1014b1d:	jae    1014c30 <trace_frame+0x120>
 1014b23:	push   %rbp
 1014b24:	mov    %rsp,%rbp
 1014b27:	push   %r15
 1014b29:	push   %r14
 1014b2b:	push   %r12
 1014b2d:	push   %rbx
 1014b2e:	cmp    $0x1f,%ecx
 1014b31:	ja     1014b45 <trace_frame+0x35>
 1014b33:	mov    0x20(%rsi),%r15
 1014b37:	test   %r15,%r15
 1014b3a:	je     1014b45 <trace_frame+0x35>
 1014b3c:	mov    0x28(%rsi),%rax
 1014b40:	test   %rax,%rax
 1014b43:	jne    1014ba9 <trace_frame+0x99>
 1014b45:	incq   (%r8)
 1014b48:	cmp    0x10(%rsi),%rdx
 1014b4c:	jae    1014b8f <trace_frame+0x7f>
 1014b4e:	mov    0x248(%rdi),%rax
 1014b55:	cmp    $0xf,%rax
 1014b59:	ja     1014b8f <trace_frame+0x7f>
 1014b5b:	mov    (%rsi),%rcx
 1014b5e:	mov    0x8(%rsi),%rsi
 1014b62:	lea    (%rdx,%rdx,2),%rdx
 1014b66:	mov    (%rsi,%rdx,8),%r8
 1014b6a:	lea    0x1(%rax),%r9
 1014b6e:	shl    $0x5,%rax
 1014b72:	mov    %rcx,0x48(%rdi,%rax,1)
 1014b77:	mov    %r8,0x50(%rdi,%rax,1)
 1014b7c:	vmovups 0x8(%rsi,%rdx,8),%xmm0
 1014b82:	mov    %r9,0x248(%rdi)
 1014b89:	vmovups %xmm0,0x58(%rdi,%rax,1)
 1014b8f:	pop    %rbx
 1014b90:	pop    %r12
 1014b92:	pop    %r14
 1014b94:	pop    %r15
 1014b96:	pop    %rbp
 1014b97:	ret
 1014b98:	nopl   0x0(%rax,%rax,1)
 1014ba0:	add    $0x28,%r15
 1014ba4:	dec    %rax
 1014ba7:	je     1014b45 <trace_frame+0x35>
 1014ba9:	mov    0x8(%r15),%r9
 1014bad:	cmp    %r9,%rdx
 1014bb0:	jb     1014ba0 <trace_frame+0x90>
 1014bb2:	cmp    0x10(%r15),%rdx
 1014bb6:	jae    1014ba0 <trace_frame+0x90>
 1014bb8:	mov    (%r15),%rax
 1014bbb:	test   %rax,%rax
 1014bbe:	je     1014b45 <trace_frame+0x35>
 1014bc0:	add    0x18(%r15),%rdx
 1014bc4:	sub    %r9,%rdx
 1014bc7:	inc    %ecx
 1014bc9:	mov    %rdi,%rbx
 1014bcc:	mov    %rsi,%r12
 1014bcf:	mov    %rax,%rsi
 1014bd2:	mov    %r8,%r14
 1014bd5:	call   1014b10 <trace_frame>
 1014bda:	mov    0x20(%r15),%rdx
 1014bde:	incq   (%r14)
 1014be1:	cmp    0x10(%r12),%rdx
 1014be6:	jae    1014b8f <trace_frame+0x7f>
 1014be8:	mov    0x248(%rbx),%rax
 1014bef:	cmp    $0xf,%rax
 1014bf3:	ja     1014b8f <trace_frame+0x7f>
 1014bf5:	mov    (%r12),%rsi
 1014bf9:	mov    0x8(%r12),%rcx
 1014bfe:	lea    (%rdx,%rdx,2),%rdx
 1014c02:	mov    (%rcx,%rdx,8),%rdi
 1014c06:	lea    0x1(%rax),%r8
 1014c0a:	shl    $0x5,%rax
 1014c0e:	mov    %rsi,0x48(%rbx,%rax,1)
 1014c13:	mov    %rdi,0x50(%rbx,%rax,1)
 1014c18:	vmovups 0x8(%rcx,%rdx,8),%xmm0
 1014c1e:	mov    %r8,0x248(%rbx)
 1014c25:	vmovups %xmm0,0x58(%rbx,%rax,1)
 1014c2b:	jmp    1014b8f <trace_frame+0x7f>
 1014c30:	incq   (%r8)
 1014c33:	ret
 1014c34:	int3
 1014c35:	int3
 1014c36:	int3
 1014c37:	int3
 1014c38:	int3
 1014c39:	int3
 1014c3a:	int3
 1014c3b:	int3
 1014c3c:	int3
 1014c3d:	int3
 1014c3e:	int3
 1014c3f:	int3

0000000001014c40 <trace_visit>:
 1014c40:	push   %rbp
 1014c41:	mov    %rsp,%rbp
 1014c44:	mov    %rcx,%r8
 1014c47:	xor    %ecx,%ecx
 1014c49:	call   1014b10 <trace_frame>
 1014c4e:	mov    $0x1,%eax
 1014c53:	pop    %rbp
 1014c54:	ret
 1014c55:	int3
 1014c56:	int3
 1014c57:	int3
 1014c58:	int3
 1014c59:	int3
 1014c5a:	int3
 1014c5b:	int3
 1014c5c:	int3
 1014c5d:	int3
 1014c5e:	int3
 1014c5f:	int3

0000000001014c60 <walk_frames>:
 1014c60:	push   %rbp
 1014c61:	mov    %rsp,%rbp
 1014c64:	push   %r15
 1014c66:	push   %r14
 1014c68:	push   %r13
 1014c6a:	push   %r12
 1014c6c:	push   %rbx
 1014c6d:	sub    $0x28,%rsp
 1014c71:	mov    %rsi,-0x30(%rbp)
 1014c75:	mov    0x39c0(%rdi),%r15
 1014c7c:	mov    0x3e68(%rdi),%r12
 1014c83:	test   %r15,%r15
 1014c86:	setne  %al
 1014c89:	cmp    %r15,%r12
 1014c8c:	seta   %cl
 1014c8f:	and    %al,%cl
 1014c91:	cmp    $0x1,%cl
 1014c94:	jne    1014d83 <walk_frames+0x123>
 1014c9a:	lea    -0x83d5(%rip),%rax        # 100c8cc <__stop_mylang_frame_map>
 1014ca1:	mov    %rax,%rcx
 1014ca4:	sub    $0x100c374,%rcx
 1014cab:	cmp    $0x9,%rcx
 1014caf:	jb     1014d83 <walk_frames+0x123>
 1014cb5:	cmpq   $0x0,0x13eeb(%rip)        # 1028ba8 <_DYNAMIC+0x1b0>
 1014cbd:	je     1014d83 <walk_frames+0x123>
 1014cc3:	cmp    $0x100c374,%rax
 1014cca:	jbe    1014d83 <walk_frames+0x123>
 1014cd0:	mov    %rdi,%r14
 1014cd3:	lea    -0x8966(%rip),%rax        # 100c374 <__start_mylang_frame_map>
 1014cda:	testb  $0x20,0x7(%rax)
 1014cde:	jne    1014d3f <walk_frames+0xdf>
 1014ce0:	mov    %rbp,%r13
 1014ce3:	add    $0xfffffffffffffff0,%r12
 1014ce7:	nopw   0x0(%rax,%rax,1)
 1014cf0:	cmp    %r15,%r13
 1014cf3:	jb     1014d83 <walk_frames+0x123>
 1014cf9:	cmp    %r12,%r13
 1014cfc:	ja     1014d83 <walk_frames+0x123>
 1014d02:	mov    %r13d,%eax
 1014d05:	and    $0x7,%eax
 1014d08:	jne    1014d83 <walk_frames+0x123>
 1014d0a:	mov    0x0(%r13),%rbx
 1014d0e:	mov    0x8(%r13),%rsi
 1014d12:	mov    $0x1014c40,%edx
 1014d17:	mov    %r14,%rdi
 1014d1a:	mov    -0x30(%rbp),%rcx
 1014d1e:	call   1014df0 <visit_return>
 1014d23:	cmp    %r13,%rbx
 1014d26:	mov    %r13,%rcx
 1014d29:	cmova  %rbx,%rcx
 1014d2d:	test   %eax,%eax
 1014d2f:	cmove  %r13,%rcx
 1014d33:	je     1014d83 <walk_frames+0x123>
 1014d35:	cmp    %r13,%rbx
 1014d38:	mov    %rcx,%r13
 1014d3b:	ja     1014cf0 <walk_frames+0x90>
 1014d3d:	jmp    1014d83 <walk_frames+0x123>
 1014d3f:	mov    %r14,-0x50(%rbp)
 1014d43:	movq   $0x1014c40,-0x48(%rbp)
 1014d4b:	mov    -0x30(%rbp),%rax
 1014d4f:	mov    %rax,-0x40(%rbp)
 1014d53:	movq   $0x0,-0x38(%rbp)
 1014d5b:	cmpq   $0x0,0x13e15(%rip)        # 1028b78 <_DYNAMIC+0x180>
 1014d63:	sete   %al
 1014d66:	cmpq   $0x0,0x13e12(%rip)        # 1028b80 <_DYNAMIC+0x188>
 1014d6e:	sete   %cl
 1014d71:	or     %al,%cl
 1014d73:	jne    1014d83 <walk_frames+0x123>
 1014d75:	lea    -0x50(%rbp),%rsi
 1014d79:	mov    $0x1014da0,%edi
 1014d7e:	call   1027370 <_Unwind_Backtrace>
 1014d83:	add    $0x28,%rsp
 1014d87:	pop    %rbx
 1014d88:	pop    %r12
 1014d8a:	pop    %r13
 1014d8c:	pop    %r14
 1014d8e:	pop    %r15
 1014d90:	pop    %rbp
 1014d91:	ret
 1014d92:	int3
 1014d93:	int3
 1014d94:	int3
 1014d95:	int3
 1014d96:	int3
 1014d97:	int3
 1014d98:	int3
 1014d99:	int3
 1014d9a:	int3
 1014d9b:	int3
 1014d9c:	int3
 1014d9d:	int3
 1014d9e:	int3
 1014d9f:	int3

0000000001014da0 <unwind_step>:
 1014da0:	push   %rbp
 1014da1:	mov    %rsp,%rbp
 1014da4:	push   %r14
 1014da6:	push   %rbx
 1014da7:	mov    %rsi,%rbx
 1014daa:	mov    (%rsi),%r14
 1014dad:	call   1024160 <_Unwind_GetIP>
 1014db2:	mov    0x8(%rbx),%rdx
 1014db6:	mov    0x10(%rbx),%rcx
 1014dba:	mov    %r14,%rdi
 1014dbd:	mov    %rax,%rsi
 1014dc0:	call   1014df0 <visit_return>
 1014dc5:	mov    %eax,%ecx
 1014dc7:	xor    %eax,%eax
 1014dc9:	test   %ecx,%ecx
 1014dcb:	je     1014dd2 <unwind_step+0x32>
 1014dcd:	pop    %rbx
 1014dce:	pop    %r14
 1014dd0:	pop    %rbp
 1014dd1:	ret
 1014dd2:	movl   $0x1,0x18(%rbx)
 1014dd9:	mov    $0x5,%eax
 1014dde:	pop    %rbx
 1014ddf:	pop    %r14
 1014de1:	pop    %rbp
 1014de2:	ret
 1014de3:	int3
 1014de4:	int3
 1014de5:	int3
 1014de6:	int3
 1014de7:	int3
 1014de8:	int3
 1014de9:	int3
 1014dea:	int3
 1014deb:	int3
 1014dec:	int3
 1014ded:	int3
 1014dee:	int3
 1014def:	int3

0000000001014df0 <visit_return>:
 1014df0:	push   %rbp
 1014df1:	mov    %rsp,%rbp
 1014df4:	push   %r15
 1014df6:	push   %r14
 1014df8:	push   %r13
 1014dfa:	push   %r12
 1014dfc:	push   %rbx
 1014dfd:	sub    $0x18,%rsp
 1014e01:	mov    %rcx,-0x38(%rbp)
 1014e05:	mov    %rdx,%r14
 1014e08:	mov    %rdi,%r15
 1014e0b:	cmpb   $0x0,0x169b6(%rip)        # 102b7c8 <frame_sites_ready>
 1014e12:	jne    1014ecd <visit_return+0xdd>
 1014e18:	movb   $0x1,0x169a9(%rip)        # 102b7c8 <frame_sites_ready>
 1014e1f:	lea    -0x8ab2(%rip),%r13        # 100c374 <__start_mylang_frame_map>
 1014e26:	test   %r13,%r13
 1014e29:	sete   %al
 1014e2c:	lea    -0x8567(%rip),%r12        # 100c8cc <__stop_mylang_frame_map>
 1014e33:	cmp    %r13,%r12
 1014e36:	setbe  %cl
 1014e39:	or     %al,%cl
 1014e3b:	jne    1014ecd <visit_return+0xdd>
 1014e41:	sub    $0x100c374,%r12
 1014e48:	sar    $0x2,%r12
 1014e4c:	movabs $0xaaaaaaaaaaaaaaab,%rax
 1014e56:	mov    %r12,%rdx
 1014e59:	mulx   %rax,%rbx,%rbx
 1014e5e:	shr    $1,%rbx
 1014e61:	movabs $0xf555555555555555,%rax
 1014e6b:	lea    (%rbx,%rax,1),%rcx
 1014e6f:	inc    %rax
 1014e72:	cmp    %rax,%rcx
 1014e75:	jb     1014ecd <visit_return+0xdd>
 1014e77:	lea    0x0(,%rbx,8),%rax
 1014e7f:	lea    (%rax,%rax,2),%rdi
 1014e83:	mov    %rsi,-0x30(%rbp)
 1014e87:	call   1027500 <malloc@plt>
 1014e8c:	mov    -0x30(%rbp),%rsi
 1014e90:	mov    %rax,0x16921(%rip)        # 102b7b8 <frame_sites>
 1014e97:	test   %rax,%rax
 1014e9a:	je     1014f9b <visit_return+0x1ab>
 1014ea0:	cmp    $0x3,%r12
 1014ea4:	jae    1015067 <visit_return+0x277>
 1014eaa:	xor    %r12d,%r12d
 1014ead:	mov    $0x18,%edx
 1014eb2:	mov    $0x1015100,%ecx
 1014eb7:	mov    %rax,%rdi
 1014eba:	mov    %r12,%rsi
 1014ebd:	call   10276b0 <qsort@plt>
 1014ec2:	mov    %r12,0x168f7(%rip)        # 102b7c0 <frame_site_count>
 1014ec9:	mov    -0x30(%rbp),%rsi
 1014ecd:	mov    0x168e4(%rip),%rcx        # 102b7b8 <frame_sites>
 1014ed4:	test   %rcx,%rcx
 1014ed7:	je     1014f9b <visit_return+0x1ab>
 1014edd:	mov    0x168dc(%rip),%rdx        # 102b7c0 <frame_site_count>
 1014ee4:	xor    %edi,%edi
 1014ee6:	test   %rdx,%rdx
 1014ee9:	je     1014f1a <visit_return+0x12a>
 1014eeb:	mov    %rdx,%rax
 1014eee:	jmp    1014ef8 <visit_return+0x108>
 1014ef0:	mov    %r9,%rax
 1014ef3:	cmp    %rax,%rdi
 1014ef6:	jae    1014f1a <visit_return+0x12a>
 1014ef8:	mov    %rax,%r8
 1014efb:	sub    %rdi,%r8
 1014efe:	shr    $1,%r8
 1014f01:	lea    (%r8,%rdi,1),%r9
 1014f05:	lea    (%r9,%r9,2),%r10
 1014f09:	cmp    %rsi,(%rcx,%r10,8)
 1014f0d:	jae    1014ef0 <visit_return+0x100>
 1014f0f:	add    %r8,%rdi
 1014f12:	inc    %rdi
 1014f15:	cmp    %rax,%rdi
 1014f18:	jb     1014ef8 <visit_return+0x108>
 1014f1a:	mov    $0x1,%eax
 1014f1f:	cmp    %rdx,%rdi
 1014f22:	jae    1015058 <visit_return+0x268>
 1014f28:	lea    (%rdi,%rdi,2),%rdx
 1014f2c:	cmp    %rsi,(%rcx,%rdx,8)
 1014f30:	jne    1015058 <visit_return+0x268>
 1014f36:	lea    (%rcx,%rdx,8),%rcx
 1014f3a:	mov    0x10(%rcx),%r12
 1014f3e:	test   %r12,%r12
 1014f41:	je     1015058 <visit_return+0x268>
 1014f47:	mov    0x8(%rcx),%r13
 1014f4b:	add    $0x8,%r13
 1014f4f:	mov    %r13,%rbx
 1014f52:	jmp    1014f71 <visit_return+0x181>
 1014f54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1014f60:	add    $0xc,%r13
 1014f64:	add    $0xc,%rbx
 1014f68:	dec    %r12
 1014f6b:	je     1015053 <visit_return+0x263>
 1014f71:	mov    -0x4(%r13),%edx
 1014f75:	test   %edx,%edx
 1014f77:	js     1014f60 <visit_return+0x170>
 1014f79:	movslq 0x0(%r13),%rsi
 1014f7d:	add    %rbx,%rsi
 1014f80:	and    $0x1fffffff,%edx
 1014f86:	mov    %r15,%rdi
 1014f89:	mov    -0x38(%rbp),%rcx
 1014f8d:	call   *%r14
 1014f90:	test   %eax,%eax
 1014f92:	jne    1014f60 <visit_return+0x170>
 1014f94:	xor    %eax,%eax
 1014f96:	jmp    1015058 <visit_return+0x268>
 1014f9b:	lea    -0x8c2e(%rip),%rcx        # 100c374 <__start_mylang_frame_map>
 1014fa2:	test   %rcx,%rcx
 1014fa5:	sete   %al
 1014fa8:	lea    -0x86e3(%rip),%rdx        # 100c8cc <__stop_mylang_frame_map>
 1014faf:	cmp    %rcx,%rdx
 1014fb2:	setbe  %dil
 1014fb6:	or     %al,%dil
 1014fb9:	mov    $0x1,%eax
 1014fbe:	jne    1015058 <visit_return+0x268>
 1014fc4:	sub    $0x100c374,%rdx
 1014fcb:	sar    $0x2,%rdx
 1014fcf:	movabs $0xaaaaaaaaaaaaaaab,%rdi
 1014fd9:	mulx   %rdi,%rdi,%rdi
 1014fde:	cmp    $0x3,%rdx
 1014fe2:	jb     1015058 <visit_return+0x268>
 1014fe4:	shr    $1,%rdi
 1014fe7:	lea    -0x1(%rdi),%rdx
 1014feb:	xor    %r8d,%r8d
 1014fee:	xchg   %ax,%ax
 1014ff0:	lea    0x0(,%r8,4),%r9
 1014ff8:	lea    (%r9,%r9,2),%r13
 1014ffc:	mov    $0x1,%r12d
 1015002:	cmp    %rdx,%r8
 1015005:	jae    1015036 <visit_return+0x246>
 1015007:	mov    %rdi,%r9
 101500a:	sub    %r8,%r9
 101500d:	lea    (%rcx,%r13,1),%r10
 1015011:	add    $0x10,%r10
 1015015:	data16 cs nopw 0x0(%rax,%rax,1)
 1015020:	testb  $0x40,0x3(%r10)
 1015025:	je     1015036 <visit_return+0x246>
 1015027:	inc    %r12
 101502a:	add    $0xc,%r10
 101502e:	cmp    %r12,%r9
 1015031:	jne    1015020 <visit_return+0x230>
 1015033:	mov    %r9,%r12
 1015036:	add    %rcx,%r13
 1015039:	movslq 0x0(%r13),%r9
 101503d:	add    %r13,%r9
 1015040:	cmp    %rsi,%r9
 1015043:	je     1014f4b <visit_return+0x15b>
 1015049:	add    %r12,%r8
 101504c:	cmp    %rdi,%r8
 101504f:	jb     1014ff0 <visit_return+0x200>
 1015051:	jmp    1015058 <visit_return+0x268>
 1015053:	mov    $0x1,%eax
 1015058:	add    $0x18,%rsp
 101505c:	pop    %rbx
 101505d:	pop    %r12
 101505f:	pop    %r13
 1015061:	pop    %r14
 1015063:	pop    %r15
 1015065:	pop    %rbp
 1015066:	ret
 1015067:	lea    -0x1(%rbx),%rcx
 101506b:	xor    %r12d,%r12d
 101506e:	xor    %edx,%edx
 1015070:	jmp    10150ae <visit_return+0x2be>
 1015072:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015080:	mov    %r8,%rdi
 1015083:	lea    (%r12,%r12,2),%r8
 1015087:	lea    (%rax,%r8,8),%r8
 101508b:	add    %r13,%rsi
 101508e:	movslq (%rsi),%r9
 1015091:	add    %rsi,%r9
 1015094:	mov    %r9,(%r8)
 1015097:	mov    %rsi,0x8(%r8)
 101509b:	mov    %rdi,0x10(%r8)
 101509f:	add    %rdi,%rdx
 10150a2:	inc    %r12
 10150a5:	cmp    %rbx,%rdx
 10150a8:	jae    1014ead <visit_return+0xbd>
 10150ae:	lea    0x0(,%rdx,4),%rsi
 10150b6:	lea    (%rsi,%rsi,2),%rsi
 10150ba:	mov    $0x1,%edi
 10150bf:	cmp    %rcx,%rdx
 10150c2:	jae    1015083 <visit_return+0x293>
 10150c4:	mov    %rbx,%r8
 10150c7:	sub    %rdx,%r8
 10150ca:	lea    (%rsi,%r13,1),%r9
 10150ce:	add    $0x10,%r9
 10150d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10150e0:	testb  $0x40,0x3(%r9)
 10150e5:	je     1015083 <visit_return+0x293>
 10150e7:	inc    %rdi
 10150ea:	add    $0xc,%r9
 10150ee:	cmp    %rdi,%r8
 10150f1:	jne    10150e0 <visit_return+0x2f0>
 10150f3:	jmp    1015080 <visit_return+0x290>
 10150f5:	int3
 10150f6:	int3
 10150f7:	int3
 10150f8:	int3
 10150f9:	int3
 10150fa:	int3
 10150fb:	int3
 10150fc:	int3
 10150fd:	int3
 10150fe:	int3
 10150ff:	int3

0000000001015100 <site_order>:
 1015100:	mov    (%rdi),%rax
 1015103:	cmp    (%rsi),%rax
 1015106:	seta   %al
 1015109:	sbb    $0x0,%al
 101510b:	movsbl %al,%eax
 101510e:	ret
 101510f:	int3

0000000001015110 <myl_qbe_fail_allocation>:
 1015110:	mov    0x1860(%rdi),%rcx
 1015117:	test   %rcx,%rcx
 101511a:	je     1015149 <myl_qbe_fail_allocation+0x39>
 101511c:	mov    0x124(%rcx),%eax
 1015122:	movl   $0x0,0x124(%rcx)
 101512c:	test   %rax,%rax
 101512f:	je     1015149 <myl_qbe_fail_allocation+0x39>
 1015131:	cmp    $0x1,%eax
 1015134:	jne    1015183 <myl_qbe_fail_allocation+0x73>
 1015136:	mov    $0x1004361,%esi
 101513b:	cmpl   $0x0,0x2c4(%rdi)
 1015142:	je     1015188 <myl_qbe_fail_allocation+0x78>
 1015144:	jmp    1014a6d <fail>
 1015149:	cmpl   $0x0,%fs:0xfffffffffffffffc
 1015152:	movl   $0x0,%fs:0xfffffffffffffffc
 101515e:	mov    $0x1004421,%esi
 1015163:	jne    1014a6d <fail>
 1015169:	cmpl   $0x0,0x2c4(%rdi)
 1015170:	mov    $0x1003b92,%eax
 1015175:	mov    $0x1004361,%esi
 101517a:	cmove  %rax,%rsi
 101517e:	jmp    1014a6d <fail>
 1015183:	cmp    $0x4,%eax
 1015186:	jae    1015195 <myl_qbe_fail_allocation+0x85>
 1015188:	mov    0x100b5d0(,%rax,8),%rsi
 1015190:	jmp    1014a6d <fail>
 1015195:	push   %rbp
 1015196:	mov    %rsp,%rbp
 1015199:	call   1027690 <abort@plt>
 101519e:	int3
 101519f:	int3

00000000010151a0 <myl_qbe_fail_iteration>:
 10151a0:	mov    $0x10043af,%esi
 10151a5:	jmp    1014a6d <fail>
 10151aa:	int3
 10151ab:	int3
 10151ac:	int3
 10151ad:	int3
 10151ae:	int3
 10151af:	int3

00000000010151b0 <myl_qbe_fail_normalized_index_bounds>:
 10151b0:	cmpq   $0x0,0x20(%rdi)
 10151b5:	jne    1015205 <myl_qbe_fail_normalized_index_bounds+0x55>
 10151b7:	mov    %rsi,%rax
 10151ba:	sar    $0x3f,%rax
 10151be:	and    %rdx,%rax
 10151c1:	sub    %rax,%rsi
 10151c4:	movabs $0x300000001,%rax
 10151ce:	mov    %rax,0x39e8(%rdi)
 10151d5:	mov    %rsi,0x39f0(%rdi)
 10151dc:	mov    %rdx,0x39f8(%rdi)
 10151e3:	vxorps %xmm0,%xmm0,%xmm0
 10151e7:	vmovups %xmm0,0x3a00(%rdi)
 10151ef:	movq   $0x0,0x3a10(%rdi)
 10151fa:	movq   $0x1003c12,0x3a18(%rdi)
 1015205:	mov    $0x1004395,%esi
 101520a:	jmp    1014a6d <fail>
 101520f:	int3

0000000001015210 <myl_qbe_fail_overflow_op>:
 1015210:	cmpq   $0x0,0x20(%rdi)
 1015215:	jne    101525c <myl_qbe_fail_overflow_op+0x4c>
 1015217:	mov    0x100bb28(,%rsi,8),%rax
 101521f:	movabs $0x1c00000001,%rsi
 1015229:	mov    %rsi,0x39e8(%rdi)
 1015230:	vxorps %xmm0,%xmm0,%xmm0
 1015234:	vmovups %xmm0,0x39f0(%rdi)
 101523c:	mov    %rdx,0x3a00(%rdi)
 1015243:	mov    %rcx,0x3a08(%rdi)
 101524a:	movq   $0x40,0x3a10(%rdi)
 1015255:	mov    %rax,0x3a18(%rdi)
 101525c:	mov    $0x10042c9,%esi
 1015261:	jmp    1014a6d <fail>
 1015266:	int3
 1015267:	int3
 1015268:	int3
 1015269:	int3
 101526a:	int3
 101526b:	int3
 101526c:	int3
 101526d:	int3
 101526e:	int3
 101526f:	int3

0000000001015270 <myl_qbe_fail_cast>:
 1015270:	cmpq   $0x0,0x20(%rdi)
 1015275:	jne    10152bc <myl_qbe_fail_cast+0x4c>
 1015277:	movabs $0x3400000001,%rax
 1015281:	mov    %rax,0x39e8(%rdi)
 1015288:	vxorps %xmm0,%xmm0,%xmm0
 101528c:	vmovups %xmm0,0x39f0(%rdi)
 1015294:	mov    %rsi,0x3a00(%rdi)
 101529b:	movq   $0x0,0x3a08(%rdi)
 10152a6:	movq   $0x40,0x3a10(%rdi)
 10152b1:	movq   $0x1003cd3,0x3a18(%rdi)
 10152bc:	mov    $0x10042c9,%esi
 10152c1:	jmp    1014a6d <fail>
 10152c6:	int3
 10152c7:	int3
 10152c8:	int3
 10152c9:	int3
 10152ca:	int3
 10152cb:	int3
 10152cc:	int3
 10152cd:	int3
 10152ce:	int3
 10152cf:	int3

00000000010152d0 <myl_qbe_fail_frame>:
 10152d0:	mov    $0x1004353,%esi
 10152d5:	jmp    1014a6d <fail>
 10152da:	int3
 10152db:	int3
 10152dc:	int3
 10152dd:	int3
 10152de:	int3
 10152df:	int3

00000000010152e0 <on_timeout>:
 10152e0:	push   %rbp
 10152e1:	mov    %rsp,%rbp
 10152e4:	mov    $0x100b2e0,%esi
 10152e9:	mov    $0x48,%edx
 10152ee:	mov    $0x2,%edi
 10152f3:	call   10276c0 <write@plt>
 10152f8:	mov    $0x1,%edi
 10152fd:	call   10276d0 <_exit@plt>
 1015302:	int3
 1015303:	int3
 1015304:	int3
 1015305:	int3
 1015306:	int3
 1015307:	int3
 1015308:	int3
 1015309:	int3
 101530a:	int3
 101530b:	int3
 101530c:	int3
 101530d:	int3
 101530e:	int3
 101530f:	int3

0000000001015310 <append>:
 1015310:	push   %rbp
 1015311:	mov    %rsp,%rbp
 1015314:	push   %r14
 1015316:	push   %rbx
 1015317:	sub    $0xd0,%rsp
 101531e:	mov    %rdx,%rbx
 1015321:	mov    %rsi,%r14
 1015324:	mov    %r8,-0xc0(%rbp)
 101532b:	mov    %r9,-0xb8(%rbp)
 1015332:	test   %al,%al
 1015334:	je     1015367 <append+0x57>
 1015336:	vmovaps %xmm0,-0xb0(%rbp)
 101533e:	vmovaps %xmm1,-0xa0(%rbp)
 1015346:	vmovaps %xmm2,-0x90(%rbp)
 101534e:	vmovaps %xmm3,-0x80(%rbp)
 1015353:	vmovaps %xmm4,-0x70(%rbp)
 1015358:	vmovaps %xmm5,-0x60(%rbp)
 101535d:	vmovaps %xmm6,-0x50(%rbp)
 1015362:	vmovaps %xmm7,-0x40(%rbp)
 1015367:	lea    -0xe0(%rbp),%rax
 101536e:	mov    %rax,-0x20(%rbp)
 1015372:	lea    0x10(%rbp),%rax
 1015376:	mov    %rax,-0x28(%rbp)
 101537a:	movabs $0x3000000020,%rax
 1015384:	mov    %rax,-0x30(%rbp)
 1015388:	mov    (%rdx),%rax
 101538b:	add    %rax,%rdi
 101538e:	sub    %rax,%rsi
 1015391:	lea    -0x30(%rbp),%rax
 1015395:	mov    %rcx,%rdx
 1015398:	mov    %rax,%rcx
 101539b:	call   10276e0 <vsnprintf@plt>
 10153a0:	mov    %eax,%ecx
 10153a2:	xor    %eax,%eax
 10153a4:	test   %ecx,%ecx
 10153a6:	js     10153c0 <append+0xb0>
 10153a8:	mov    %ecx,%ecx
 10153aa:	mov    (%rbx),%rdx
 10153ad:	sub    %rdx,%r14
 10153b0:	cmp    %rcx,%r14
 10153b3:	jbe    10153c0 <append+0xb0>
 10153b5:	add    %rcx,%rdx
 10153b8:	mov    %rdx,(%rbx)
 10153bb:	mov    $0x1,%eax
 10153c0:	add    $0xd0,%rsp
 10153c7:	pop    %rbx
 10153c8:	pop    %r14
 10153ca:	pop    %rbp
 10153cb:	ret
 10153cc:	int3
 10153cd:	int3
 10153ce:	int3
 10153cf:	int3

00000000010153d0 <describe>:
 10153d0:	push   %rbp
 10153d1:	mov    %rsp,%rbp
 10153d4:	push   %rbx
 10153d5:	push   %rax
 10153d6:	mov    %rdi,%rbx
 10153d9:	mov    $0x1004361,%esi
 10153de:	call   1027540 <strcmp@plt>
 10153e3:	test   %eax,%eax
 10153e5:	je     1015490 <describe+0xc0>
 10153eb:	mov    $0x1004346,%esi
 10153f0:	mov    %rbx,%rdi
 10153f3:	call   1027540 <strcmp@plt>
 10153f8:	test   %eax,%eax
 10153fa:	je     101549c <describe+0xcc>
 1015400:	mov    $0x100442d,%esi
 1015405:	mov    %rbx,%rdi
 1015408:	call   1027540 <strcmp@plt>
 101540d:	test   %eax,%eax
 101540f:	je     10154a8 <describe+0xd8>
 1015415:	mov    $0x1004442,%esi
 101541a:	mov    %rbx,%rdi
 101541d:	call   1027540 <strcmp@plt>
 1015422:	test   %eax,%eax
 1015424:	je     10154b4 <describe+0xe4>
 101542a:	mov    $0x1004353,%esi
 101542f:	mov    %rbx,%rdi
 1015432:	call   1027540 <strcmp@plt>
 1015437:	test   %eax,%eax
 1015439:	je     10154c0 <describe+0xf0>
 101543f:	mov    $0x100438a,%esi
 1015444:	mov    %rbx,%rdi
 1015447:	call   1027540 <strcmp@plt>
 101544c:	test   %eax,%eax
 101544e:	je     10154cc <describe+0xfc>
 1015450:	mov    $0x1004380,%esi
 1015455:	mov    %rbx,%rdi
 1015458:	call   1027540 <strcmp@plt>
 101545d:	test   %eax,%eax
 101545f:	je     10154d8 <describe+0x108>
 1015461:	mov    $0x100430e,%esi
 1015466:	mov    %rbx,%rdi
 1015469:	call   1027540 <strcmp@plt>
 101546e:	test   %eax,%eax
 1015470:	je     10154e4 <describe+0x114>
 1015472:	mov    $0x10040ce,%eax
 1015477:	cmpb   $0x52,(%rbx)
 101547a:	jne    1015495 <describe+0xc5>
 101547c:	cmpb   $0x5f,0x1(%rbx)
 1015480:	mov    $0x100429a,%ecx
 1015485:	cmove  %rcx,%rax
 1015489:	add    $0x8,%rsp
 101548d:	pop    %rbx
 101548e:	pop    %rbp
 101548f:	ret
 1015490:	mov    $0x1004135,%eax
 1015495:	add    $0x8,%rsp
 1015499:	pop    %rbx
 101549a:	pop    %rbp
 101549b:	ret
 101549c:	mov    $0x10043dc,%eax
 10154a1:	add    $0x8,%rsp
 10154a5:	pop    %rbx
 10154a6:	pop    %rbp
 10154a7:	ret
 10154a8:	mov    $0x1003ff4,%eax
 10154ad:	add    $0x8,%rsp
 10154b1:	pop    %rbx
 10154b2:	pop    %rbp
 10154b3:	ret
 10154b4:	mov    $0x1004023,%eax
 10154b9:	add    $0x8,%rsp
 10154bd:	pop    %rbx
 10154be:	pop    %rbp
 10154bf:	ret
 10154c0:	mov    $0x100467d,%eax
 10154c5:	add    $0x8,%rsp
 10154c9:	pop    %rbx
 10154ca:	pop    %rbp
 10154cb:	ret
 10154cc:	mov    $0x100425c,%eax
 10154d1:	add    $0x8,%rsp
 10154d5:	pop    %rbx
 10154d6:	pop    %rbp
 10154d7:	ret
 10154d8:	mov    $0x1004245,%eax
 10154dd:	add    $0x8,%rsp
 10154e1:	pop    %rbx
 10154e2:	pop    %rbp
 10154e3:	ret
 10154e4:	mov    $0x1004232,%eax
 10154e9:	add    $0x8,%rsp
 10154ed:	pop    %rbx
 10154ee:	pop    %rbp
 10154ef:	ret

00000000010154f0 <myl_native_heap_collect>:
 10154f0:	push   %rbp
 10154f1:	mov    %rsp,%rbp
 10154f4:	test   %rdi,%rdi
 10154f7:	je     1015509 <myl_native_heap_collect+0x19>
 10154f9:	cmpq   $0x0,0x1608(%rdi)
 1015501:	je     101550b <myl_native_heap_collect+0x1b>
 1015503:	pop    %rbp
 1015504:	jmp    101bcb0 <myl_rc_drain>
 1015509:	xor    %edi,%edi
 101550b:	pop    %rbp
 101550c:	jmp    1015520 <collect>
 1015511:	int3
 1015512:	int3
 1015513:	int3
 1015514:	int3
 1015515:	int3
 1015516:	int3
 1015517:	int3
 1015518:	int3
 1015519:	int3
 101551a:	int3
 101551b:	int3
 101551c:	int3
 101551d:	int3
 101551e:	int3
 101551f:	int3

0000000001015520 <collect>:
 1015520:	push   %rbp
 1015521:	mov    %rsp,%rbp
 1015524:	push   %r15
 1015526:	push   %r14
 1015528:	push   %r13
 101552a:	push   %r12
 101552c:	push   %rbx
 101552d:	and    $0xffffffffffffffe0,%rsp
 1015531:	sub    $0x140,%rsp
 1015538:	cmpl   $0x0,0x74(%rdi)
 101553c:	jne    1016a8e <collect+0x156e>
 1015542:	mov    %rdi,%r15
 1015545:	incq   0x50(%rdi)
 1015549:	movq   $0x0,0x4e8(%rdi)
 1015554:	movl   $0x0,0x4f8(%rdi)
 101555e:	vpxor  %xmm0,%xmm0,%xmm0
 1015562:	vmovdqu %ymm0,0x500(%rdi)
 101556a:	vmovdqu %ymm0,0x520(%rdi)
 1015572:	vmovdqu %ymm0,0x540(%rdi)
 101557a:	vmovdqu %ymm0,0x560(%rdi)
 1015582:	vmovdqu %ymm0,0x580(%rdi)
 101558a:	vmovdqu %ymm0,0x5a0(%rdi)
 1015592:	vmovdqu %ymm0,0x5e0(%rdi)
 101559a:	movq   $0x0,0x600(%rdi)
 10155a5:	vmovdqu %ymm0,0x618(%rdi)
 10155ad:	movq   $0x0,0x638(%rdi)
 10155b8:	vmovdqu %ymm0,0x650(%rdi)
 10155c0:	movq   $0x0,0x670(%rdi)
 10155cb:	vmovdqu %ymm0,0x688(%rdi)
 10155d3:	movq   $0x0,0x6a8(%rdi)
 10155de:	vmovdqu %ymm0,0x6c0(%rdi)
 10155e6:	movq   $0x0,0x6e0(%rdi)
 10155f1:	vmovdqu %ymm0,0x6f8(%rdi)
 10155f9:	movq   $0x0,0x718(%rdi)
 1015604:	vmovdqu %ymm0,0x730(%rdi)
 101560c:	movq   $0x0,0x750(%rdi)
 1015617:	vmovdqu %ymm0,0x768(%rdi)
 101561f:	movq   $0x0,0x788(%rdi)
 101562a:	vmovdqu %ymm0,0x7a0(%rdi)
 1015632:	movq   $0x0,0x7c0(%rdi)
 101563d:	vmovdqu %ymm0,0x7d8(%rdi)
 1015645:	movq   $0x0,0x7f8(%rdi)
 1015650:	vmovdqu %ymm0,0x810(%rdi)
 1015658:	movq   $0x0,0x830(%rdi)
 1015663:	vmovdqu %ymm0,0x848(%rdi)
 101566b:	movq   $0x0,0x868(%rdi)
 1015676:	vmovdqu %ymm0,0x880(%rdi)
 101567e:	movq   $0x0,0x8a0(%rdi)
 1015689:	vmovdqu %ymm0,0x8b8(%rdi)
 1015691:	movq   $0x0,0x8d8(%rdi)
 101569c:	vmovdqu %ymm0,0x8f0(%rdi)
 10156a4:	movq   $0x0,0x910(%rdi)
 10156af:	vmovdqu %ymm0,0x928(%rdi)
 10156b7:	movq   $0x0,0x948(%rdi)
 10156c2:	vmovdqu %ymm0,0x960(%rdi)
 10156ca:	movq   $0x0,0x980(%rdi)
 10156d5:	vmovdqu %ymm0,0x998(%rdi)
 10156dd:	movq   $0x0,0x9b8(%rdi)
 10156e8:	vmovdqu %ymm0,0x9d0(%rdi)
 10156f0:	movq   $0x0,0x9f0(%rdi)
 10156fb:	vmovdqu %ymm0,0xa08(%rdi)
 1015703:	movq   $0x0,0xa28(%rdi)
 101570e:	vmovdqu %ymm0,0xa40(%rdi)
 1015716:	movq   $0x0,0xa60(%rdi)
 1015721:	vmovdqu %ymm0,0xa78(%rdi)
 1015729:	movq   $0x0,0xa98(%rdi)
 1015734:	vmovdqu %ymm0,0xab0(%rdi)
 101573c:	movq   $0x0,0xad0(%rdi)
 1015747:	vmovdqu %ymm0,0xae8(%rdi)
 101574f:	movq   $0x0,0xb08(%rdi)
 101575a:	vmovdqu %ymm0,0xb20(%rdi)
 1015762:	movq   $0x0,0xb40(%rdi)
 101576d:	vmovdqu %ymm0,0xb58(%rdi)
 1015775:	movq   $0x0,0xb78(%rdi)
 1015780:	vmovdqu %ymm0,0xb90(%rdi)
 1015788:	movq   $0x0,0xbb0(%rdi)
 1015793:	vmovdqu %ymm0,0xbc8(%rdi)
 101579b:	movq   $0x0,0xbe8(%rdi)
 10157a6:	vmovdqu %ymm0,0xc00(%rdi)
 10157ae:	movq   $0x0,0xc20(%rdi)
 10157b9:	vmovdqu %ymm0,0xc38(%rdi)
 10157c1:	movq   $0x0,0xc58(%rdi)
 10157cc:	vmovdqu %ymm0,0xc70(%rdi)
 10157d4:	movq   $0x0,0xc90(%rdi)
 10157df:	vmovdqu %ymm0,0xca8(%rdi)
 10157e7:	movq   $0x0,0xcc8(%rdi)
 10157f2:	vmovdqu %ymm0,0xce0(%rdi)
 10157fa:	movq   $0x0,0xd00(%rdi)
 1015805:	vmovdqu %ymm0,0xd18(%rdi)
 101580d:	movq   $0x0,0xd38(%rdi)
 1015818:	vmovdqu %ymm0,0xd50(%rdi)
 1015820:	movq   $0x0,0xd70(%rdi)
 101582b:	vmovdqu %ymm0,0xd88(%rdi)
 1015833:	movq   $0x0,0xda8(%rdi)
 101583e:	vmovdqu %ymm0,0xdc0(%rdi)
 1015846:	movq   $0x0,0xde0(%rdi)
 1015851:	vmovdqu %ymm0,0xdf8(%rdi)
 1015859:	movq   $0x0,0xe18(%rdi)
 1015864:	vmovdqu %ymm0,0xe30(%rdi)
 101586c:	movq   $0x0,0xe50(%rdi)
 1015877:	vmovdqu %ymm0,0xe68(%rdi)
 101587f:	movq   $0x0,0xe88(%rdi)
 101588a:	vmovdqu %ymm0,0xea0(%rdi)
 1015892:	movq   $0x0,0xec0(%rdi)
 101589d:	vmovdqu %ymm0,0xed8(%rdi)
 10158a5:	movq   $0x0,0xef8(%rdi)
 10158b0:	vmovdqu %ymm0,0xf10(%rdi)
 10158b8:	movq   $0x0,0xf30(%rdi)
 10158c3:	vmovdqu %ymm0,0xf48(%rdi)
 10158cb:	movq   $0x0,0xf68(%rdi)
 10158d6:	vmovdqu %ymm0,0xf80(%rdi)
 10158de:	movq   $0x0,0xfa0(%rdi)
 10158e9:	vmovdqu %ymm0,0xfb8(%rdi)
 10158f1:	movq   $0x0,0xfd8(%rdi)
 10158fc:	vmovdqu %ymm0,0xff0(%rdi)
 1015904:	movq   $0x0,0x1010(%rdi)
 101590f:	vmovdqu %ymm0,0x1028(%rdi)
 1015917:	movq   $0x0,0x1048(%rdi)
 1015922:	vmovdqu %ymm0,0x1060(%rdi)
 101592a:	movq   $0x0,0x1080(%rdi)
 1015935:	vmovdqu %ymm0,0x1098(%rdi)
 101593d:	movq   $0x0,0x10b8(%rdi)
 1015948:	vmovdqu %ymm0,0x10d0(%rdi)
 1015950:	movq   $0x0,0x10f0(%rdi)
 101595b:	vmovdqu %ymm0,0x1108(%rdi)
 1015963:	movq   $0x0,0x1128(%rdi)
 101596e:	mov    (%rdi),%r14
 1015971:	test   %r14,%r14
 1015974:	jne    101599f <collect+0x47f>
 1015976:	jmp    1015a27 <collect+0x507>
 101597b:	nopl   0x0(%rax,%rax,1)
 1015980:	lea    0x48(%r14),%rdi
 1015984:	mov    $0x400,%edx
 1015989:	xor    %esi,%esi
 101598b:	vzeroupper
 101598e:	call   10274d0 <memset@plt>
 1015993:	mov    (%r14),%r14
 1015996:	test   %r14,%r14
 1015999:	je     1015a27 <collect+0x507>
 101599f:	cmpq   $0x20,0x20(%r14)
 10159a4:	jb     1015980 <collect+0x460>
 10159a6:	mov    0x18(%r14),%rdx
 10159aa:	test   %rdx,%rdx
 10159ad:	je     1015a1b <collect+0x4fb>
 10159af:	mov    0x8(%r14),%rax
 10159b3:	mov    %edx,%ecx
 10159b5:	and    $0x3,%ecx
 10159b8:	cmp    $0x4,%rdx
 10159bc:	jae    10159c2 <collect+0x4a2>
 10159be:	xor    %esi,%esi
 10159c0:	jmp    1015a01 <collect+0x4e1>
 10159c2:	lea    0x470(%r14),%rdi
 10159c9:	and    $0xfffffffffffffffc,%rdx
 10159cd:	lea    (%rax,%rax,2),%r8
 10159d1:	lea    0x0(,%rax,4),%r9
 10159d9:	xor    %esi,%esi
 10159db:	nopl   0x0(%rax,%rax,1)
 10159e0:	andb   $0xfe,(%rdi)
 10159e3:	andb   $0xfe,(%rdi,%rax,1)
 10159e7:	andb   $0xfe,(%rdi,%rax,2)
 10159eb:	andb   $0xfe,(%rdi,%r8,1)
 10159f0:	add    $0x4,%rsi
 10159f4:	add    %r9,%rdi
 10159f7:	cmp    %rsi,%rdx
 10159fa:	jne    10159e0 <collect+0x4c0>
 10159fc:	test   %rcx,%rcx
 10159ff:	je     1015a1b <collect+0x4fb>
 1015a01:	imul   %rax,%rsi
 1015a05:	lea    (%r14,%rsi,1),%rdx
 1015a09:	add    $0x470,%rdx
 1015a10:	andb   $0xfe,(%rdx)
 1015a13:	add    %rax,%rdx
 1015a16:	dec    %rcx
 1015a19:	jne    1015a10 <collect+0x4f0>
 1015a1b:	mov    (%r14),%r14
 1015a1e:	test   %r14,%r14
 1015a21:	jne    101599f <collect+0x47f>
 1015a27:	movq   $0x0,0x1158(%r15)
 1015a32:	movq   $0x0,0x1140(%r15)
 1015a3d:	movl   $0x0,0x1170(%r15)
 1015a48:	incq   0x1180(%r15)
 1015a4f:	movb   $0x0,0x1174(%r15)
 1015a57:	mov    0x10(%r15),%rbx
 1015a5b:	test   %rbx,%rbx
 1015a5e:	je     1015a7b <collect+0x55b>
 1015a60:	mov    0x8(%rbx),%rdx
 1015a64:	mov    0x10(%rbx),%rsi
 1015a68:	mov    %r15,%rdi
 1015a6b:	vzeroupper
 1015a6e:	call   1016ad0 <trace>
 1015a73:	mov    (%rbx),%rbx
 1015a76:	test   %rbx,%rbx
 1015a79:	jne    1015a60 <collect+0x540>
 1015a7b:	lea    0x5d8(%r15),%rax
 1015a82:	mov    %rax,0x80(%rsp)
 1015a8a:	mov    $0x1a,%ebx
 1015a8f:	jmp    1015aac <collect+0x58c>
 1015a91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015aa0:	inc    %rbx
 1015aa3:	cmp    $0x9a,%rbx
 1015aaa:	je     1015ac2 <collect+0x5a2>
 1015aac:	mov    (%r15,%rbx,8),%rsi
 1015ab0:	test   %rsi,%rsi
 1015ab3:	je     1015aa0 <collect+0x580>
 1015ab5:	mov    %r15,%rdi
 1015ab8:	vzeroupper
 1015abb:	call   1016d20 <mark>
 1015ac0:	jmp    1015aa0 <collect+0x580>
 1015ac2:	cmpq   $0x0,(%r15)
 1015ac6:	mov    %r15,0x10(%rsp)
 1015acb:	je     1015c50 <collect+0x730>
 1015ad1:	mov    0x11a0(%r15),%rax
 1015ad8:	test   %rax,%rax
 1015adb:	je     1015b07 <collect+0x5e7>
 1015add:	mov    0x5c0(%r15),%rcx
 1015ae4:	sub    %rax,%rcx
 1015ae7:	add    $0xffffffffffffffb0,%rcx
 1015aeb:	mov    %rcx,0x10(%rax)
 1015aef:	movq   $0x0,0x11a0(%r15)
 1015afa:	vpxor  %xmm0,%xmm0,%xmm0
 1015afe:	vmovdqu %xmm0,0x5c0(%r15)
 1015b07:	mov    0x11e8(%r15),%rax
 1015b0e:	test   %rax,%rax
 1015b11:	je     1015c50 <collect+0x730>
 1015b17:	xor    %edx,%edx
 1015b19:	mov    $0x28,%esi
 1015b1e:	jmp    1015b45 <collect+0x625>
 1015b20:	mov    0x10(%rsp),%rax
 1015b25:	mov    0x11e8(%rax),%rax
 1015b2c:	mov    0xa0(%rsp),%rdx
 1015b34:	inc    %rdx
 1015b37:	cmp    %rax,%rdx
 1015b3a:	mov    0x10(%rsp),%r15
 1015b3f:	jae    1015c50 <collect+0x730>
 1015b45:	mov    0x4d8(%r15),%rcx
 1015b4c:	mov    %rdx,0xa0(%rsp)
 1015b54:	mov    (%rcx,%rdx,8),%rdi
 1015b58:	test   %rdi,%rdi
 1015b5b:	jne    1015b68 <collect+0x648>
 1015b5d:	jmp    1015b2c <collect+0x60c>
 1015b5f:	nop
 1015b60:	mov    (%rdi),%rdi
 1015b63:	test   %rdi,%rdi
 1015b66:	je     1015b20 <collect+0x600>
 1015b68:	mov    0x10(%rdi),%rax
 1015b6c:	test   %rax,%rax
 1015b6f:	je     1015b60 <collect+0x640>
 1015b71:	lea    0x50(%rdi),%r8
 1015b75:	xor    %r12d,%r12d
 1015b78:	mov    %rdi,0x40(%rsp)
 1015b7d:	mov    %r8,0x60(%rsp)
 1015b82:	jmp    1015ba0 <collect+0x680>
 1015b84:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015b90:	add    %r9,%r12
 1015b93:	add    $0x1f,%r12
 1015b97:	and    $0xfffffffffffffff0,%r12
 1015b9b:	cmp    %rax,%r12
 1015b9e:	jae    1015b60 <collect+0x640>
 1015ba0:	mov    0x8(%r8,%r12,1),%r14
 1015ba5:	bzhi   %rsi,(%r8,%r12,1),%r13
 1015bab:	shr    $0x2,%r13
 1015baf:	mov    (%r14),%r9
 1015bb2:	imul   %r13,%r9
 1015bb6:	cmp    $0x1,%r9
 1015bba:	adc    $0x0,%r9
 1015bbe:	cmpw   $0x0,0x30(%r14)
 1015bc4:	je     1015b90 <collect+0x670>
 1015bc6:	cmpl   $0x1,0x58(%r14)
 1015bcb:	setne  %cl
 1015bce:	test   %r13,%r13
 1015bd1:	setne  %dl
 1015bd4:	and    %cl,%dl
 1015bd6:	cmp    $0x1,%dl
 1015bd9:	jne    1015b90 <collect+0x670>
 1015bdb:	mov    %r9,0x18(%rsp)
 1015be0:	lea    (%r8,%r12,1),%rax
 1015be4:	add    $0x10,%rax
 1015be8:	mov    %rax,0x20(%rsp)
 1015bed:	xor    %ebx,%ebx
 1015bef:	mov    0x10(%rsp),%r15
 1015bf4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015c00:	mov    (%r14),%rdx
 1015c03:	imul   %rbx,%rdx
 1015c07:	add    0x20(%rsp),%rdx
 1015c0c:	mov    %r15,%rdi
 1015c0f:	mov    %r14,%rsi
 1015c12:	vzeroupper
 1015c15:	call   1016ad0 <trace>
 1015c1a:	inc    %rbx
 1015c1d:	cmp    %rbx,%r13
 1015c20:	jne    1015c00 <collect+0x6e0>
 1015c22:	mov    0x40(%rsp),%rdi
 1015c27:	mov    0x10(%rdi),%rax
 1015c2b:	mov    $0x28,%esi
 1015c30:	mov    0x60(%rsp),%r8
 1015c35:	mov    0x18(%rsp),%r9
 1015c3a:	jmp    1015b90 <collect+0x670>
 1015c3f:	movl   $0x1,0x1170(%r15)
 1015c4a:	nopw   0x0(%rax,%rax,1)
 1015c50:	mov    0x4e8(%r15),%rax
 1015c57:	test   %rax,%rax
 1015c5a:	je     1016072 <collect+0xb52>
 1015c60:	mov    0x8(%r15),%rcx
 1015c64:	lea    -0x1(%rax),%rdx
 1015c68:	mov    %rdx,0x4e8(%r15)
 1015c6f:	mov    -0x8(%rcx,%rax,8),%rax
 1015c74:	movb   $0x0,0x1175(%r15)
 1015c7c:	mov    %rax,0x20(%rsp)
 1015c81:	mov    0x8(%rax),%r13
 1015c85:	movzwl 0x30(%r13),%eax
 1015c8a:	test   %eax,%eax
 1015c8c:	je     1015cf0 <collect+0x7d0>
 1015c8e:	cmpl   $0x1,0x58(%r13)
 1015c93:	je     1015cf0 <collect+0x7d0>
 1015c95:	mov    0x20(%rsp),%rdx
 1015c9a:	lea    0x10(%rdx),%r12
 1015c9e:	mov    $0x3c,%ecx
 1015ca3:	bzhi   %rcx,(%rdx),%r14
 1015ca8:	shr    $0x2,%r14
 1015cac:	cmp    $0x6,%eax
 1015caf:	ja     1015dad <collect+0x88d>
 1015cb5:	mov    $0x62,%ecx
 1015cba:	bt     %eax,%ecx
 1015cbd:	jae    1015dad <collect+0x88d>
 1015cc3:	test   %r14,%r14
 1015cc6:	mov    0x10(%rsp),%r15
 1015ccb:	je     1015cf0 <collect+0x7d0>
 1015ccd:	nopl   (%rax)
 1015cd0:	mov    (%r12),%rsi
 1015cd4:	mov    %r15,%rdi
 1015cd7:	vzeroupper
 1015cda:	call   1016d20 <mark>
 1015cdf:	add    0x0(%r13),%r12
 1015ce3:	dec    %r14
 1015ce6:	jne    1015cd0 <collect+0x7b0>
 1015ce8:	nopl   0x0(%rax,%rax,1)
 1015cf0:	mov    0x20(%rsp),%r14
 1015cf5:	mov    (%r14),%rax
 1015cf8:	test   $0x1,%al
 1015cfa:	je     1015c50 <collect+0x730>
 1015d00:	mov    0x8(%r14),%rcx
 1015d04:	cmpw   $0x0,0x30(%rcx)
 1015d09:	je     1015c50 <collect+0x730>
 1015d0f:	cmpl   $0x1,0x58(%rcx)
 1015d13:	je     1015c50 <collect+0x730>
 1015d19:	cmpl   $0x0,0x5c(%rcx)
 1015d1d:	je     1015e6f <collect+0x94f>
 1015d23:	cmpb   $0x0,0x1175(%r15)
 1015d2b:	je     1015c50 <collect+0x730>
 1015d31:	mov    0x1158(%r15),%rcx
 1015d38:	cmp    0x1160(%r15),%rcx
 1015d3f:	jne    1015ead <collect+0x98d>
 1015d45:	lea    (%rcx,%rcx,1),%rbx
 1015d49:	test   %rcx,%rcx
 1015d4c:	mov    $0x100,%eax
 1015d51:	cmove  %rax,%rbx
 1015d55:	cmp    %rcx,%rbx
 1015d58:	setbe  %al
 1015d5b:	movabs $0x1fffffffffffffff,%rcx
 1015d65:	cmp    %rcx,%rbx
 1015d68:	seta   %cl
 1015d6b:	or     %al,%cl
 1015d6d:	jne    1015c3f <collect+0x71f>
 1015d73:	mov    0x1150(%r15),%rdi
 1015d7a:	lea    0x0(,%rbx,8),%rsi
 1015d82:	vzeroupper
 1015d85:	call   1027670 <realloc@plt>
 1015d8a:	test   %rax,%rax
 1015d8d:	je     1015c3f <collect+0x71f>
 1015d93:	mov    %rax,0x1150(%r15)
 1015d9a:	mov    %rbx,0x1160(%r15)
 1015da1:	mov    0x1158(%r15),%rcx
 1015da8:	jmp    1015eb4 <collect+0x994>
 1015dad:	mov    0x60(%r13),%rax
 1015db1:	mov    %rax,0x18(%rsp)
 1015db6:	test   %rax,%rax
 1015db9:	je     1015ec8 <collect+0x9a8>
 1015dbf:	mov    0x10(%rsp),%rax
 1015dc4:	cmpl   $0x0,0x68(%rax)
 1015dc8:	je     1015f06 <collect+0x9e6>
 1015dce:	lea    0xc0(%rsp),%rax
 1015dd6:	mov    %rax,0x88(%rsp)
 1015dde:	movq   $0x8,0x90(%rsp)
 1015dea:	movq   $0x0,0x98(%rsp)
 1015df6:	lea    0x88(%rsp),%rdi
 1015dfe:	mov    %r13,%rsi
 1015e01:	xor    %edx,%edx
 1015e03:	movabs $0xffffffff00000000,%rcx
 1015e0d:	xor    %r8d,%r8d
 1015e10:	vzeroupper
 1015e13:	call   1016f70 <flatten>
 1015e18:	test   %eax,%eax
 1015e1a:	je     1016aa0 <collect+0x1580>
 1015e20:	mov    0x98(%rsp),%rax
 1015e28:	cmp    0x68(%r13),%rax
 1015e2c:	jne    1016aa0 <collect+0x1580>
 1015e32:	test   %rax,%rax
 1015e35:	je     101604d <collect+0xb2d>
 1015e3b:	mov    0x60(%r13),%rsi
 1015e3f:	mov    %rax,0x40(%rsp)
 1015e44:	lea    0x0(,%rax,4),%rax
 1015e4c:	lea    (%rax,%rax,2),%rdx
 1015e50:	lea    0xc0(%rsp),%rdi
 1015e58:	call   10276f0 <bcmp@plt>
 1015e5d:	test   %eax,%eax
 1015e5f:	mov    0x10(%rsp),%r15
 1015e64:	je     1015f1d <collect+0x9fd>
 1015e6a:	jmp    1016aa0 <collect+0x1580>
 1015e6f:	mov    (%rcx),%rcx
 1015e72:	mov    $0x3c,%edx
 1015e77:	bzhi   %rdx,%rax,%rsi
 1015e7c:	shr    $0x2,%rsi
 1015e80:	test   %rcx,%rcx
 1015e83:	je     1015fb3 <collect+0xa93>
 1015e89:	cmp    $0x3fff0,%rcx
 1015e90:	ja     1015fa8 <collect+0xa88>
 1015e96:	mov    $0x3fff0,%eax
 1015e9b:	xor    %edx,%edx
 1015e9d:	div    %ecx
 1015e9f:	cmp    %rax,%rsi
 1015ea2:	ja     1015c50 <collect+0x730>
 1015ea8:	jmp    1015fb3 <collect+0xa93>
 1015ead:	mov    0x1150(%r15),%rax
 1015eb4:	lea    0x1(%rcx),%rdx
 1015eb8:	mov    %rdx,0x1158(%r15)
 1015ebf:	mov    %r14,(%rax,%rcx,8)
 1015ec3:	jmp    1015c50 <collect+0x730>
 1015ec8:	test   %r14,%r14
 1015ecb:	mov    0x10(%rsp),%r15
 1015ed0:	je     1015cf0 <collect+0x7d0>
 1015ed6:	xor    %ebx,%ebx
 1015ed8:	nopl   0x0(%rax,%rax,1)
 1015ee0:	mov    0x0(%r13),%rdx
 1015ee4:	imul   %rbx,%rdx
 1015ee8:	add    %r12,%rdx
 1015eeb:	mov    %r15,%rdi
 1015eee:	mov    %r13,%rsi
 1015ef1:	vzeroupper
 1015ef4:	call   1016ad0 <trace>
 1015ef9:	inc    %rbx
 1015efc:	cmp    %rbx,%r14
 1015eff:	jne    1015ee0 <collect+0x9c0>
 1015f01:	jmp    1015cf0 <collect+0x7d0>
 1015f06:	mov    0x68(%r13),%rax
 1015f0a:	mov    %rax,0x40(%rsp)
 1015f0f:	test   %rax,%rax
 1015f12:	mov    0x10(%rsp),%r15
 1015f17:	je     1015cf0 <collect+0x7d0>
 1015f1d:	test   %r14,%r14
 1015f20:	je     1015cf0 <collect+0x7d0>
 1015f26:	mov    0x0(%r13),%rax
 1015f2a:	mov    %rax,0x60(%rsp)
 1015f2f:	addq   $0x8,0x18(%rsp)
 1015f35:	xor    %ebx,%ebx
 1015f37:	jmp    1015f56 <collect+0xa36>
 1015f39:	nopl   0x0(%rax)
 1015f40:	inc    %rbx
 1015f43:	add    0x60(%rsp),%r12
 1015f48:	cmp    %r14,%rbx
 1015f4b:	mov    0x10(%rsp),%r15
 1015f50:	je     1015cf0 <collect+0x7d0>
 1015f56:	mov    0x18(%rsp),%r13
 1015f5b:	mov    0x40(%rsp),%r15
 1015f60:	jmp    1015f8e <collect+0xa6e>
 1015f62:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015f70:	mov    -0x8(%r13),%eax
 1015f74:	mov    (%r12,%rax,1),%rsi
 1015f78:	mov    0x10(%rsp),%rdi
 1015f7d:	vzeroupper
 1015f80:	call   1016d20 <mark>
 1015f85:	add    $0xc,%r13
 1015f89:	dec    %r15
 1015f8c:	je     1015f40 <collect+0xa20>
 1015f8e:	mov    -0x4(%r13),%eax
 1015f92:	mov    $0xffffffff,%ecx
 1015f97:	cmp    %rcx,%rax
 1015f9a:	je     1015f70 <collect+0xa50>
 1015f9c:	mov    (%r12,%rax,1),%eax
 1015fa0:	cmp    0x0(%r13),%eax
 1015fa4:	je     1015f70 <collect+0xa50>
 1015fa6:	jmp    1015f85 <collect+0xa65>
 1015fa8:	xor    %eax,%eax
 1015faa:	cmp    %rax,%rsi
 1015fad:	ja     1015c50 <collect+0x730>
 1015fb3:	imul   %rsi,%rcx
 1015fb7:	add    $0x1f,%rcx
 1015fbb:	cmp    $0xf,%rcx
 1015fbf:	setae  %al
 1015fc2:	and    $0xfffffffffffffff0,%rcx
 1015fc6:	cmp    $0x40001,%rcx
 1015fcd:	setae  %cl
 1015fd0:	test   %cl,%al
 1015fd2:	jne    1015c50 <collect+0x730>
 1015fd8:	mov    0x1140(%r15),%rcx
 1015fdf:	cmp    0x1148(%r15),%rcx
 1015fe6:	jne    1016057 <collect+0xb37>
 1015fe8:	lea    (%rcx,%rcx,1),%rbx
 1015fec:	test   %rcx,%rcx
 1015fef:	mov    $0x100,%eax
 1015ff4:	cmove  %rax,%rbx
 1015ff8:	cmp    %rcx,%rbx
 1015ffb:	setbe  %al
 1015ffe:	movabs $0x1fffffffffffffff,%rcx
 1016008:	cmp    %rcx,%rbx
 101600b:	seta   %cl
 101600e:	or     %al,%cl
 1016010:	jne    1015c3f <collect+0x71f>
 1016016:	mov    0x1138(%r15),%rdi
 101601d:	lea    0x0(,%rbx,8),%rsi
 1016025:	vzeroupper
 1016028:	call   1027670 <realloc@plt>
 101602d:	test   %rax,%rax
 1016030:	je     1015c3f <collect+0x71f>
 1016036:	mov    %rax,0x1138(%r15)
 101603d:	mov    %rbx,0x1148(%r15)
 1016044:	mov    0x1140(%r15),%rcx
 101604b:	jmp    101605e <collect+0xb3e>
 101604d:	mov    0x10(%rsp),%r15
 1016052:	jmp    1015cf0 <collect+0x7d0>
 1016057:	mov    0x1138(%r15),%rax
 101605e:	lea    0x1(%rcx),%rdx
 1016062:	mov    %rdx,0x1140(%r15)
 1016069:	mov    %r14,(%rax,%rcx,8)
 101606d:	jmp    1015c50 <collect+0x730>
 1016072:	movb   $0x0,0x1174(%r15)
 101607a:	cmpl   $0x0,0x4f8(%r15)
 1016082:	mov    (%r15),%r14
 1016085:	jne    10160d6 <collect+0xbb6>
 1016087:	test   %r14,%r14
 101608a:	je     101698d <collect+0x146d>
 1016090:	xor    %r13d,%r13d
 1016093:	vpbroadcastq -0x14694(%rip),%ymm0        # 1001a08 <__abi_tag+0x170c>
 101609c:	vmovdqa %ymm0,0xa0(%rsp)
 10160a5:	xor    %ebx,%ebx
 10160a7:	xor    %r11d,%r11d
 10160aa:	mov    %r15,%rdx
 10160ad:	jmp    10161ac <collect+0xc8c>
 10160b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10160c0:	lea    0x48(%r14),%rdi
 10160c4:	mov    $0x400,%edx
 10160c9:	xor    %esi,%esi
 10160cb:	vzeroupper
 10160ce:	call   10274d0 <memset@plt>
 10160d3:	mov    (%r14),%r14
 10160d6:	test   %r14,%r14
 10160d9:	je     1016167 <collect+0xc47>
 10160df:	cmpq   $0x20,0x20(%r14)
 10160e4:	jb     10160c0 <collect+0xba0>
 10160e6:	mov    0x18(%r14),%rdx
 10160ea:	test   %rdx,%rdx
 10160ed:	je     101615b <collect+0xc3b>
 10160ef:	mov    0x8(%r14),%rax
 10160f3:	mov    %edx,%ecx
 10160f5:	and    $0x3,%ecx
 10160f8:	cmp    $0x4,%rdx
 10160fc:	jae    1016102 <collect+0xbe2>
 10160fe:	xor    %esi,%esi
 1016100:	jmp    1016141 <collect+0xc21>
 1016102:	lea    0x470(%r14),%rdi
 1016109:	and    $0xfffffffffffffffc,%rdx
 101610d:	lea    (%rax,%rax,2),%r8
 1016111:	lea    0x0(,%rax,4),%r9
 1016119:	xor    %esi,%esi
 101611b:	nopl   0x0(%rax,%rax,1)
 1016120:	andb   $0xfe,(%rdi)
 1016123:	andb   $0xfe,(%rdi,%rax,1)
 1016127:	andb   $0xfe,(%rdi,%rax,2)
 101612b:	andb   $0xfe,(%rdi,%r8,1)
 1016130:	add    $0x4,%rsi
 1016134:	add    %r9,%rdi
 1016137:	cmp    %rsi,%rdx
 101613a:	jne    1016120 <collect+0xc00>
 101613c:	test   %rcx,%rcx
 101613f:	je     101615b <collect+0xc3b>
 1016141:	imul   %rax,%rsi
 1016145:	lea    (%r14,%rsi,1),%rdx
 1016149:	add    $0x470,%rdx
 1016150:	andb   $0xfe,(%rdx)
 1016153:	add    %rax,%rdx
 1016156:	dec    %rcx
 1016159:	jne    1016150 <collect+0xc30>
 101615b:	mov    (%r14),%r14
 101615e:	test   %r14,%r14
 1016161:	jne    10160df <collect+0xbbf>
 1016167:	movq   $0x0,0x4e8(%r15)
 1016172:	movl   $0x1,0x1170(%r15)
 101617d:	jmp    1016a8e <collect+0x156e>
 1016182:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016190:	add    0x8(%r14),%r13
 1016194:	inc    %rbx
 1016197:	mov    (%r14),%rax
 101619a:	mov    %r14,%rdx
 101619d:	mov    %r11,%r12
 10161a0:	mov    %rax,%r14
 10161a3:	test   %rax,%rax
 10161a6:	je     1016995 <collect+0x1475>
 10161ac:	mov    0x20(%r14),%rcx
 10161b0:	lea    0x470(%r14),%rdi
 10161b7:	cmp    $0x34,%rcx
 10161bb:	jb     10161e0 <collect+0xcc0>
 10161bd:	testb  $0x1,(%rdi)
 10161c0:	jne    1016190 <collect+0xc70>
 10161c2:	mov    (%r14),%rax
 10161c5:	mov    %rax,(%rdx)
 10161c8:	mov    %r14,%rdi
 10161cb:	mov    %rdx,%r14
 10161ce:	mov    %r11,%r12
 10161d1:	vzeroupper
 10161d4:	call   1027570 <free@plt>
 10161d9:	mov    %r12,%r11
 10161dc:	jmp    1016197 <collect+0xc77>
 10161de:	xchg   %ax,%ax
 10161e0:	mov    0x8(%r14),%rax
 10161e4:	mov    0x18(%r14),%r9
 10161e8:	imul   %rax,%r9
 10161ec:	lea    (%rdi,%r9,1),%r8
 10161f0:	cmp    $0x20,%rcx
 10161f4:	mov    %rdx,0x18(%rsp)
 10161f9:	jb     1016250 <collect+0xd30>
 10161fb:	test   %r9,%r9
 10161fe:	je     101637c <collect+0xe5c>
 1016204:	mov    %rdi,%r9
 1016207:	xor    %esi,%esi
 1016209:	xor    %r10d,%r10d
 101620c:	xor    %edx,%edx
 101620e:	jmp    1016229 <collect+0xd09>
 1016210:	mov    %r10,%rdi
 1016213:	mov    %rdi,%r10
 1016216:	lea    (%r9,%rax,1),%rdi
 101621a:	inc    %rsi
 101621d:	add    %rax,%r9
 1016220:	cmp    %r8,%r9
 1016223:	jae    1016340 <collect+0xe20>
 1016229:	testb  $0x1,(%r9)
 101622d:	je     101621d <collect+0xcfd>
 101622f:	cmp    %r9,%rdi
 1016232:	jae    1016210 <collect+0xcf0>
 1016234:	mov    %r9,(%rdi)
 1016237:	movq   $0x0,0x8(%rdi)
 101623f:	test   %r10,%r10
 1016242:	je     101624a <collect+0xd2a>
 1016244:	mov    %rdi,0x8(%r10)
 1016248:	jmp    1016213 <collect+0xcf3>
 101624a:	mov    %rdi,%rdx
 101624d:	jmp    1016213 <collect+0xcf3>
 101624f:	nop
 1016250:	mov    %r11,0x60(%rsp)
 1016255:	mov    %rbx,0x20(%rsp)
 101625a:	mov    %r13,0x40(%rsp)
 101625f:	add    $0x470,%r9
 1016266:	shr    $0x4,%r9
 101626a:	lea    0x3f(%r9),%r10
 101626e:	shr    $0x6,%r10
 1016272:	mov    $0x1,%r15d
 1016278:	xor    %edx,%edx
 101627a:	xor    %r12d,%r12d
 101627d:	xor    %esi,%esi
 101627f:	jmp    1016298 <collect+0xd78>
 1016281:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016290:	inc    %r15
 1016293:	cmp    %r10,%r15
 1016296:	je     1016310 <collect+0xdf0>
 1016298:	mov    0x48(%r14,%r15,8),%r13
 101629d:	test   %r13,%r13
 10162a0:	je     1016290 <collect+0xd70>
 10162a2:	mov    %r15,%r11
 10162a5:	shl    $0x6,%r11
 10162a9:	jmp    10162c6 <collect+0xda6>
 10162ab:	nopl   0x0(%rax,%rax,1)
 10162b0:	mov    %r12,%rdi
 10162b3:	add    %rax,%rbx
 10162b6:	inc    %rsi
 10162b9:	mov    %rdi,%r12
 10162bc:	mov    %rbx,%rdi
 10162bf:	blsr   %r13,%r13
 10162c4:	je     1016290 <collect+0xd70>
 10162c6:	tzcnt  %r13,%rbx
 10162cb:	or     %r11,%rbx
 10162ce:	cmp    $0x47,%rbx
 10162d2:	jb     10162bf <collect+0xd9f>
 10162d4:	cmp    %r9,%rbx
 10162d7:	jae    10162bf <collect+0xd9f>
 10162d9:	shl    $0x4,%rbx
 10162dd:	add    %r14,%rbx
 10162e0:	cmp    %rbx,%rdi
 10162e3:	jae    10162b0 <collect+0xd90>
 10162e5:	mov    %rbx,(%rdi)
 10162e8:	movq   $0x0,0x8(%rdi)
 10162f0:	test   %r12,%r12
 10162f3:	je     10162fc <collect+0xddc>
 10162f5:	mov    %rdi,0x8(%r12)
 10162fa:	jmp    10162b3 <collect+0xd93>
 10162fc:	mov    %rdi,%rdx
 10162ff:	jmp    10162b3 <collect+0xd93>
 1016301:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016310:	cmp    %r8,%rdi
 1016313:	jae    1016366 <collect+0xe46>
 1016315:	mov    %r8,(%rdi)
 1016318:	movq   $0x0,0x8(%rdi)
 1016320:	test   %r12,%r12
 1016323:	mov    0x10(%rsp),%r15
 1016328:	mov    0x40(%rsp),%r13
 101632d:	mov    0x20(%rsp),%rbx
 1016332:	mov    0x60(%rsp),%r11
 1016337:	je     1016388 <collect+0xe68>
 1016339:	mov    %rdi,0x8(%r12)
 101633e:	jmp    1016390 <collect+0xe70>
 1016340:	cmp    %r8,%rdi
 1016343:	jae    101686b <collect+0x134b>
 1016349:	mov    %r8,(%rdi)
 101634c:	movq   $0x0,0x8(%rdi)
 1016354:	test   %r10,%r10
 1016357:	je     1016868 <collect+0x1348>
 101635d:	mov    %rdi,0x8(%r10)
 1016361:	jmp    101686b <collect+0x134b>
 1016366:	mov    0x10(%rsp),%r15
 101636b:	mov    0x40(%rsp),%r13
 1016370:	mov    0x20(%rsp),%rbx
 1016375:	mov    0x60(%rsp),%r11
 101637a:	jmp    1016390 <collect+0xe70>
 101637c:	xor    %edx,%edx
 101637e:	xor    %r12d,%r12d
 1016381:	xor    %esi,%esi
 1016383:	jmp    101686e <collect+0x134e>
 1016388:	mov    %rdi,%rdx
 101638b:	nopl   0x0(%rax,%rax,1)
 1016390:	vmovdqu 0x48(%r14),%ymm1
 1016396:	vmovdqu 0x68(%r14),%ymm2
 101639c:	vmovdqu 0x88(%r14),%ymm3
 10163a5:	vmovdqu 0xa8(%r14),%ymm4
 10163ae:	vpand  0x248(%r14),%ymm1,%ymm5
 10163b7:	vpand  0x268(%r14),%ymm2,%ymm6
 10163c0:	vpand  0x288(%r14),%ymm3,%ymm7
 10163c9:	vpand  0x2a8(%r14),%ymm4,%ymm0
 10163d2:	vmovdqu %ymm5,0x248(%r14)
 10163db:	vmovdqu %ymm6,0x268(%r14)
 10163e4:	vmovdqu %ymm7,0x288(%r14)
 10163ed:	vmovdqu %ymm0,0x2a8(%r14)
 10163f6:	vpxor  %ymm1,%ymm5,%ymm1
 10163fa:	vpxor  %ymm2,%ymm6,%ymm2
 10163fe:	vpxor  %ymm3,%ymm7,%ymm3
 1016402:	vpxor  %ymm4,%ymm0,%ymm4
 1016406:	vmovdqu %ymm1,0x48(%r14)
 101640c:	vmovdqu %ymm2,0x68(%r14)
 1016412:	vmovdqu %ymm3,0x88(%r14)
 101641b:	vmovdqu %ymm4,0xa8(%r14)
 1016424:	vpbroadcastb -0x149b5(%rip),%ymm15        # 1001a78 <__abi_tag+0x177c>
 101642d:	vpand  %ymm5,%ymm15,%ymm1
 1016431:	vmovdqa -0x14b19(%rip),%ymm13        # 1001920 <__abi_tag+0x1624>
 1016439:	vpshufb %ymm1,%ymm13,%ymm1
 101643e:	vmovdqa 0xa0(%rsp),%ymm12
 1016447:	vgf2p8affineqb $0x0,%ymm12,%ymm5,%ymm2
 101644d:	vpshufb %ymm2,%ymm13,%ymm2
 1016452:	vpaddb %ymm1,%ymm2,%ymm1
 1016456:	vpxor  %xmm14,%xmm14,%xmm14
 101645b:	vpsadbw %ymm1,%ymm14,%ymm3
 101645f:	vpand  %ymm6,%ymm15,%ymm1
 1016463:	vpshufb %ymm1,%ymm13,%ymm1
 1016468:	vgf2p8affineqb $0x0,%ymm12,%ymm6,%ymm2
 101646e:	vpshufb %ymm2,%ymm13,%ymm2
 1016473:	vpaddb %ymm1,%ymm2,%ymm1
 1016477:	vpsadbw %ymm1,%ymm14,%ymm2
 101647b:	vpand  %ymm7,%ymm15,%ymm1
 101647f:	vpshufb %ymm1,%ymm13,%ymm1
 1016484:	vgf2p8affineqb $0x0,%ymm12,%ymm7,%ymm4
 101648a:	vpshufb %ymm4,%ymm13,%ymm4
 101648f:	vpaddb %ymm1,%ymm4,%ymm1
 1016493:	vpsadbw %ymm1,%ymm14,%ymm1
 1016497:	vpand  %ymm0,%ymm15,%ymm4
 101649b:	vpshufb %ymm4,%ymm13,%ymm4
 10164a0:	vgf2p8affineqb $0x0,%ymm12,%ymm0,%ymm0
 10164a6:	vpshufb %ymm0,%ymm13,%ymm0
 10164ab:	vpaddb %ymm4,%ymm0,%ymm0
 10164af:	vpsadbw %ymm0,%ymm14,%ymm0
 10164b3:	vmovdqu 0xc8(%r14),%ymm5
 10164bc:	vmovdqu 0xe8(%r14),%ymm6
 10164c5:	vmovdqu 0x108(%r14),%ymm7
 10164ce:	vmovdqu 0x128(%r14),%ymm8
 10164d7:	vpand  0x2c8(%r14),%ymm5,%ymm9
 10164e0:	vpand  0x2e8(%r14),%ymm6,%ymm10
 10164e9:	vpand  0x308(%r14),%ymm7,%ymm11
 10164f2:	vpand  0x328(%r14),%ymm8,%ymm4
 10164fb:	vmovdqu %ymm9,0x2c8(%r14)
 1016504:	vmovdqu %ymm10,0x2e8(%r14)
 101650d:	vmovdqu %ymm11,0x308(%r14)
 1016516:	vmovdqu %ymm4,0x328(%r14)
 101651f:	vpxor  %ymm5,%ymm9,%ymm5
 1016523:	vpxor  %ymm6,%ymm10,%ymm6
 1016527:	vpxor  %ymm7,%ymm11,%ymm7
 101652b:	vpxor  %ymm4,%ymm8,%ymm8
 101652f:	vmovdqu %ymm5,0xc8(%r14)
 1016538:	vmovdqu %ymm6,0xe8(%r14)
 1016541:	vmovdqu %ymm7,0x108(%r14)
 101654a:	vmovdqu %ymm8,0x128(%r14)
 1016553:	vpand  %ymm15,%ymm9,%ymm5
 1016558:	vpshufb %ymm5,%ymm13,%ymm5
 101655d:	vgf2p8affineqb $0x0,%ymm12,%ymm9,%ymm6
 1016563:	vpshufb %ymm6,%ymm13,%ymm6
 1016568:	vpaddb %ymm5,%ymm6,%ymm5
 101656c:	vpsadbw %ymm5,%ymm14,%ymm5
 1016570:	vpaddq %ymm3,%ymm5,%ymm3
 1016574:	vpand  %ymm15,%ymm10,%ymm5
 1016579:	vpshufb %ymm5,%ymm13,%ymm5
 101657e:	vgf2p8affineqb $0x0,%ymm12,%ymm10,%ymm6
 1016584:	vpshufb %ymm6,%ymm13,%ymm6
 1016589:	vpaddb %ymm5,%ymm6,%ymm5
 101658d:	vpsadbw %ymm5,%ymm14,%ymm5
 1016591:	vpaddq %ymm2,%ymm5,%ymm2
 1016595:	vmovdqa %ymm2,0x60(%rsp)
 101659b:	vpand  %ymm15,%ymm11,%ymm5
 10165a0:	vpshufb %ymm5,%ymm13,%ymm5
 10165a5:	vgf2p8affineqb $0x0,%ymm12,%ymm11,%ymm6
 10165ab:	vpshufb %ymm6,%ymm13,%ymm6
 10165b0:	vpaddb %ymm5,%ymm6,%ymm5
 10165b4:	vpsadbw %ymm5,%ymm14,%ymm5
 10165b8:	vpaddq %ymm1,%ymm5,%ymm1
 10165bc:	vmovdqa %ymm1,0x40(%rsp)
 10165c2:	vpand  %ymm4,%ymm15,%ymm5
 10165c6:	vmovdqa %ymm15,%ymm2
 10165ca:	vpshufb %ymm5,%ymm13,%ymm5
 10165cf:	vgf2p8affineqb $0x0,%ymm12,%ymm4,%ymm4
 10165d5:	vpshufb %ymm4,%ymm13,%ymm4
 10165da:	vpaddb %ymm5,%ymm4,%ymm4
 10165de:	vpsadbw %ymm4,%ymm14,%ymm4
 10165e2:	vpaddq %ymm0,%ymm4,%ymm0
 10165e6:	vmovdqa %ymm0,0x20(%rsp)
 10165ec:	vmovdqu 0x148(%r14),%ymm5
 10165f5:	vmovdqu 0x168(%r14),%ymm6
 10165fe:	vmovdqu 0x188(%r14),%ymm7
 1016607:	vmovdqu 0x1a8(%r14),%ymm8
 1016610:	vpand  0x348(%r14),%ymm5,%ymm9
 1016619:	vpand  0x368(%r14),%ymm6,%ymm10
 1016622:	vpand  0x388(%r14),%ymm7,%ymm11
 101662b:	vpand  0x3a8(%r14),%ymm8,%ymm4
 1016634:	vmovdqu %ymm9,0x348(%r14)
 101663d:	vmovdqu %ymm10,0x368(%r14)
 1016646:	vmovdqu %ymm11,0x388(%r14)
 101664f:	vmovdqu %ymm4,0x3a8(%r14)
 1016658:	vpxor  %ymm5,%ymm9,%ymm5
 101665c:	vpxor  %ymm6,%ymm10,%ymm6
 1016660:	vpxor  %ymm7,%ymm11,%ymm7
 1016664:	vpxor  %ymm4,%ymm8,%ymm8
 1016668:	vmovdqu %ymm5,0x148(%r14)
 1016671:	vmovdqu %ymm6,0x168(%r14)
 101667a:	vmovdqu %ymm7,0x188(%r14)
 1016683:	vmovdqu %ymm8,0x1a8(%r14)
 101668c:	vpand  %ymm15,%ymm9,%ymm5
 1016691:	vpshufb %ymm5,%ymm13,%ymm5
 1016696:	vgf2p8affineqb $0x0,%ymm12,%ymm9,%ymm6
 101669c:	vpshufb %ymm6,%ymm13,%ymm6
 10166a1:	vpaddb %ymm5,%ymm6,%ymm7
 10166a5:	vpand  %ymm15,%ymm10,%ymm5
 10166aa:	vpshufb %ymm5,%ymm13,%ymm5
 10166af:	vgf2p8affineqb $0x0,%ymm12,%ymm10,%ymm6
 10166b5:	vpshufb %ymm6,%ymm13,%ymm6
 10166ba:	vpaddb %ymm5,%ymm6,%ymm6
 10166be:	vpand  %ymm15,%ymm11,%ymm5
 10166c3:	vpshufb %ymm5,%ymm13,%ymm5
 10166c8:	vgf2p8affineqb $0x0,%ymm12,%ymm11,%ymm8
 10166ce:	vpshufb %ymm8,%ymm13,%ymm8
 10166d3:	vpaddb %ymm5,%ymm8,%ymm5
 10166d7:	vpand  %ymm4,%ymm15,%ymm8
 10166db:	vpshufb %ymm8,%ymm13,%ymm8
 10166e0:	vgf2p8affineqb $0x0,%ymm12,%ymm4,%ymm4
 10166e6:	vpshufb %ymm4,%ymm13,%ymm4
 10166eb:	vpaddb %ymm4,%ymm8,%ymm4
 10166ef:	vmovdqu 0x1c8(%r14),%ymm10
 10166f8:	vmovdqu 0x1e8(%r14),%ymm11
 1016701:	vmovdqu 0x208(%r14),%ymm0
 101670a:	vmovdqu 0x228(%r14),%ymm1
 1016713:	vpand  0x3c8(%r14),%ymm10,%ymm14
 101671c:	vpand  0x3e8(%r14),%ymm11,%ymm15
 1016725:	vpand  0x408(%r14),%ymm0,%ymm9
 101672e:	vpand  0x428(%r14),%ymm1,%ymm8
 1016737:	vmovdqu %ymm14,0x3c8(%r14)
 1016740:	vmovdqu %ymm15,0x3e8(%r14)
 1016749:	vmovdqu %ymm9,0x408(%r14)
 1016752:	vmovdqu %ymm8,0x428(%r14)
 101675b:	vpxor  %ymm10,%ymm14,%ymm10
 1016760:	vmovdqu %ymm10,0x1c8(%r14)
 1016769:	vpxor  %ymm11,%ymm15,%ymm10
 101676e:	vmovdqu %ymm10,0x1e8(%r14)
 1016777:	vpxor  %ymm0,%ymm9,%ymm10
 101677b:	vmovdqu %ymm10,0x208(%r14)
 1016784:	vpxor  %ymm1,%ymm8,%ymm10
 1016788:	vmovdqu %ymm10,0x228(%r14)
 1016791:	vpand  %ymm2,%ymm14,%ymm10
 1016795:	vpshufb %ymm10,%ymm13,%ymm10
 101679a:	vgf2p8affineqb $0x0,%ymm12,%ymm14,%ymm11
 10167a0:	vpshufb %ymm11,%ymm13,%ymm11
 10167a5:	vpaddb %ymm10,%ymm11,%ymm10
 10167aa:	vpxor  %xmm0,%xmm0,%xmm0
 10167ae:	vpsadbw %ymm0,%ymm7,%ymm7
 10167b2:	vpsadbw %ymm0,%ymm10,%ymm10
 10167b6:	vpaddq %ymm7,%ymm10,%ymm7
 10167ba:	vpaddq %ymm3,%ymm7,%ymm3
 10167be:	vpand  %ymm2,%ymm15,%ymm7
 10167c2:	vmovdqa %ymm2,%ymm11
 10167c6:	vpshufb %ymm7,%ymm13,%ymm7
 10167cb:	vgf2p8affineqb $0x0,%ymm12,%ymm15,%ymm10
 10167d1:	vpshufb %ymm10,%ymm13,%ymm10
 10167d6:	vpaddb %ymm7,%ymm10,%ymm7
 10167da:	vpsadbw %ymm0,%ymm6,%ymm6
 10167de:	vpsadbw %ymm0,%ymm7,%ymm7
 10167e2:	vpaddq %ymm6,%ymm7,%ymm6
 10167e6:	vpaddq 0x60(%rsp),%ymm6,%ymm2
 10167ec:	vpaddq %ymm3,%ymm2,%ymm2
 10167f0:	vpand  %ymm11,%ymm9,%ymm3
 10167f5:	vpshufb %ymm3,%ymm13,%ymm3
 10167fa:	vgf2p8affineqb $0x0,%ymm12,%ymm9,%ymm6
 1016800:	vpshufb %ymm6,%ymm13,%ymm6
 1016805:	vpaddb %ymm3,%ymm6,%ymm3
 1016809:	vpsadbw %ymm0,%ymm5,%ymm5
 101680d:	vpsadbw %ymm0,%ymm3,%ymm3
 1016811:	vpaddq %ymm5,%ymm3,%ymm3
 1016815:	vpaddq 0x40(%rsp),%ymm3,%ymm1
 101681b:	vpaddq %ymm2,%ymm1,%ymm1
 101681f:	vpand  %ymm11,%ymm8,%ymm2
 1016824:	vpshufb %ymm2,%ymm13,%ymm2
 1016829:	vgf2p8affineqb $0x0,%ymm12,%ymm8,%ymm3
 101682f:	vpshufb %ymm3,%ymm13,%ymm3
 1016834:	vpaddb %ymm2,%ymm3,%ymm2
 1016838:	vpsadbw %ymm0,%ymm4,%ymm3
 101683c:	vpsadbw %ymm0,%ymm2,%ymm2
 1016840:	vpaddq %ymm3,%ymm2,%ymm2
 1016844:	vpaddq 0x20(%rsp),%ymm2,%ymm0
 101684a:	vpaddq %ymm1,%ymm0,%ymm0
 101684e:	vextracti128 $0x1,%ymm0,%xmm1
 1016854:	vpaddq %xmm1,%xmm0,%xmm0
 1016858:	vpshufd $0xee,%xmm0,%xmm1
 101685d:	vpaddq %xmm1,%xmm0,%xmm0
 1016861:	vmovq  %xmm0,%r12
 1016866:	jmp    101686e <collect+0x134e>
 1016868:	mov    %rdi,%rdx
 101686b:	xor    %r12d,%r12d
 101686e:	mov    %rdx,0x28(%r14)
 1016872:	mov    %rsi,0x30(%r14)
 1016876:	test   %r12,%r12
 1016879:	setne  0x40(%r14)
 101687e:	imul   %rax,%r12
 1016882:	add    %r11,%r12
 1016885:	test   %rsi,%rsi
 1016888:	jne    1016950 <collect+0x1430>
 101688e:	cmp    $0x1f,%rcx
 1016892:	ja     1016950 <collect+0x1430>
 1016898:	imul   $0x38,%rcx,%rcx
 101689c:	mov    0x80(%rsp),%rsi
 10168a4:	cmp    %r14,(%rsi,%rcx,1)
 10168a8:	je     1016907 <collect+0x13e7>
 10168aa:	mov    0x11d8(%r15),%rcx
 10168b1:	cmp    0x11e0(%r15),%rcx
 10168b8:	jne    101690b <collect+0x13eb>
 10168ba:	mov    %rbx,0x20(%rsp)
 10168bf:	lea    (%rcx,%rcx,1),%rbx
 10168c3:	test   %rcx,%rcx
 10168c6:	mov    $0x40,%eax
 10168cb:	cmove  %rax,%rbx
 10168cf:	mov    0x11d0(%r15),%rdi
 10168d6:	lea    0x0(,%rbx,8),%rsi
 10168de:	vzeroupper
 10168e1:	call   1027670 <realloc@plt>
 10168e6:	test   %rax,%rax
 10168e9:	je     101693d <collect+0x141d>
 10168eb:	mov    %rax,0x11d0(%r15)
 10168f2:	mov    %rbx,0x11e0(%r15)
 10168f9:	mov    0x11d8(%r15),%rcx
 1016900:	mov    0x20(%rsp),%rbx
 1016905:	jmp    1016912 <collect+0x13f2>
 1016907:	xor    %esi,%esi
 1016909:	jmp    1016950 <collect+0x1430>
 101690b:	mov    0x11d0(%r15),%rax
 1016912:	lea    0x1(%rcx),%rdx
 1016916:	mov    %rdx,0x11d8(%r15)
 101691d:	mov    %r14,(%rax,%rcx,8)
 1016921:	mov    (%r14),%rax
 1016924:	mov    0x18(%rsp),%rdx
 1016929:	mov    %rax,(%rdx)
 101692c:	mov    %r12,%r11
 101692f:	mov    %rax,%r14
 1016932:	test   %rax,%rax
 1016935:	jne    10161ac <collect+0xc8c>
 101693b:	jmp    1016995 <collect+0x1475>
 101693d:	mov    0x30(%r14),%rsi
 1016941:	mov    0x8(%r14),%rax
 1016945:	mov    0x28(%r14),%rdx
 1016949:	mov    0x20(%rsp),%rbx
 101694e:	xchg   %ax,%ax
 1016950:	imul   %rsi,%rax
 1016954:	add    %rax,%r13
 1016957:	add    %rsi,%rbx
 101695a:	movq   $0x0,0x38(%r14)
 1016962:	test   %rdx,%rdx
 1016965:	setne  0x41(%r14)
 101696a:	je     1016985 <collect+0x1465>
 101696c:	imul   $0x38,0x20(%r14),%rax
 1016971:	mov    0x5e8(%r15,%rax,1),%rcx
 1016979:	mov    %rcx,0x38(%r14)
 101697d:	mov    %r14,0x5e8(%r15,%rax,1)
 1016985:	mov    %r12,%r11
 1016988:	jmp    1016197 <collect+0xc77>
 101698d:	xor    %r12d,%r12d
 1016990:	xor    %ebx,%ebx
 1016992:	xor    %r13d,%r13d
 1016995:	mov    0xb0(%r15),%rax
 101699c:	add    %r13,%rax
 101699f:	mov    %rax,0x18(%r15)
 10169a3:	mov    0x40(%r15),%rax
 10169a7:	add    %rbx,%rax
 10169aa:	sub    0x1198(%r15),%rax
 10169b1:	mov    %rax,0x40(%r15)
 10169b5:	mov    %rbx,0x1198(%r15)
 10169bc:	mov    %r12,0x1190(%r15)
 10169c3:	mov    0x1158(%r15),%rdx
 10169ca:	test   %rdx,%rdx
 10169cd:	je     1016a40 <collect+0x1520>
 10169cf:	mov    0x1150(%r15),%rcx
 10169d6:	mov    %edx,%eax
 10169d8:	and    $0x3,%eax
 10169db:	cmp    $0x4,%rdx
 10169df:	jae    10169e5 <collect+0x14c5>
 10169e1:	xor    %esi,%esi
 10169e3:	jmp    1016a21 <collect+0x1501>
 10169e5:	and    $0xfffffffffffffffc,%rdx
 10169e9:	xor    %esi,%esi
 10169eb:	nopl   0x0(%rax,%rax,1)
 10169f0:	mov    (%rcx,%rsi,8),%rdi
 10169f4:	andq   $0xfffffffffffffffe,(%rdi)
 10169f8:	mov    0x8(%rcx,%rsi,8),%rdi
 10169fd:	andq   $0xfffffffffffffffe,(%rdi)
 1016a01:	mov    0x10(%rcx,%rsi,8),%rdi
 1016a06:	andq   $0xfffffffffffffffe,(%rdi)
 1016a0a:	mov    0x18(%rcx,%rsi,8),%rdi
 1016a0f:	andq   $0xfffffffffffffffe,(%rdi)
 1016a13:	add    $0x4,%rsi
 1016a17:	cmp    %rsi,%rdx
 1016a1a:	jne    10169f0 <collect+0x14d0>
 1016a1c:	test   %rax,%rax
 1016a1f:	je     1016a40 <collect+0x1520>
 1016a21:	lea    (%rcx,%rsi,8),%rcx
 1016a25:	xor    %edx,%edx
 1016a27:	nopw   0x0(%rax,%rax,1)
 1016a30:	mov    (%rcx,%rdx,8),%rsi
 1016a34:	andq   $0xfffffffffffffffe,(%rsi)
 1016a38:	inc    %rdx
 1016a3b:	cmp    %rdx,%rax
 1016a3e:	jne    1016a30 <collect+0x1510>
 1016a40:	mov    %r13,%rax
 1016a43:	shr    $1,%rax
 1016a46:	cmp    $0x400001,%rax
 1016a4c:	mov    $0x400000,%ecx
 1016a51:	cmovae %rax,%rcx
 1016a55:	add    %r13,%rcx
 1016a58:	mov    $0xffffffffffffffff,%rax
 1016a5f:	cmovb  %rax,%rcx
 1016a63:	mov    %rcx,0x60(%r15)
 1016a67:	mov    %r13,%rcx
 1016a6a:	sub    %r12,%rcx
 1016a6d:	mov    %rcx,0x1188(%r15)
 1016a74:	test   %r13,%r13
 1016a77:	js     1016a87 <collect+0x1567>
 1016a79:	add    %r13,%r13
 1016a7c:	add    $0x400000,%r13
 1016a83:	cmovae %r13,%rax
 1016a87:	mov    %rax,0x1168(%r15)
 1016a8e:	lea    -0x28(%rbp),%rsp
 1016a92:	pop    %rbx
 1016a93:	pop    %r12
 1016a95:	pop    %r13
 1016a97:	pop    %r14
 1016a99:	pop    %r15
 1016a9b:	pop    %rbp
 1016a9c:	vzeroupper
 1016a9f:	ret
 1016aa0:	mov    0x120f1(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1016aa7:	mov    (%rax),%rcx
 1016aaa:	mov    $0x1004860,%edi
 1016aaf:	mov    $0x43,%esi
 1016ab4:	mov    $0x1,%edx
 1016ab9:	call   10275d0 <fwrite@plt>
 1016abe:	call   1027690 <abort@plt>
 1016ac3:	int3
 1016ac4:	int3
 1016ac5:	int3
 1016ac6:	int3
 1016ac7:	int3
 1016ac8:	int3
 1016ac9:	int3
 1016aca:	int3
 1016acb:	int3
 1016acc:	int3
 1016acd:	int3
 1016ace:	int3
 1016acf:	int3

0000000001016ad0 <trace>:
 1016ad0:	push   %rbp
 1016ad1:	mov    %rsp,%rbp
 1016ad4:	push   %r15
 1016ad6:	push   %r14
 1016ad8:	push   %r13
 1016ada:	push   %r12
 1016adc:	push   %rbx
 1016add:	sub    $0x88,%rsp
 1016ae4:	mov    0x58(%rsi),%eax
 1016ae7:	cmp    $0x1,%eax
 1016aea:	jne    1016afe <trace+0x2e>
 1016aec:	add    $0x88,%rsp
 1016af3:	pop    %rbx
 1016af4:	pop    %r12
 1016af6:	pop    %r13
 1016af8:	pop    %r14
 1016afa:	pop    %r15
 1016afc:	pop    %rbp
 1016afd:	ret
 1016afe:	mov    %rdx,%rbx
 1016b01:	mov    %rsi,%r15
 1016b04:	mov    %rdi,%r14
 1016b07:	movzwl 0x30(%rsi),%ecx
 1016b0b:	cmp    $0x6,%ecx
 1016b0e:	ja     1016b36 <trace+0x66>
 1016b10:	mov    $0x62,%edx
 1016b15:	bt     %ecx,%edx
 1016b18:	jae    1016b36 <trace+0x66>
 1016b1a:	mov    (%rbx),%rsi
 1016b1d:	mov    %r14,%rdi
 1016b20:	add    $0x88,%rsp
 1016b27:	pop    %rbx
 1016b28:	pop    %r12
 1016b2a:	pop    %r13
 1016b2c:	pop    %r14
 1016b2e:	pop    %r15
 1016b30:	pop    %rbp
 1016b31:	jmp    1016d20 <mark>
 1016b36:	mov    0x60(%r15),%r12
 1016b3a:	test   %r12,%r12
 1016b3d:	je     1016be2 <trace+0x112>
 1016b43:	cmpl   $0x0,0x68(%r14)
 1016b48:	je     1016c46 <trace+0x176>
 1016b4e:	lea    -0xb0(%rbp),%rax
 1016b55:	mov    %rax,-0x48(%rbp)
 1016b59:	movq   $0x8,-0x40(%rbp)
 1016b61:	movq   $0x0,-0x38(%rbp)
 1016b69:	lea    -0x48(%rbp),%rdi
 1016b6d:	movabs $0xffffffff00000000,%rcx
 1016b77:	mov    %r15,%rsi
 1016b7a:	xor    %edx,%edx
 1016b7c:	xor    %r8d,%r8d
 1016b7f:	call   1016f70 <flatten>
 1016b84:	test   %eax,%eax
 1016b86:	je     1016bbf <trace+0xef>
 1016b88:	mov    -0x38(%rbp),%r13
 1016b8c:	cmp    0x68(%r15),%r13
 1016b90:	jne    1016bbf <trace+0xef>
 1016b92:	test   %r13,%r13
 1016b95:	je     1016aec <trace+0x1c>
 1016b9b:	mov    0x60(%r15),%rsi
 1016b9f:	lea    0x0(,%r13,4),%rax
 1016ba7:	lea    (%rax,%rax,2),%rdx
 1016bab:	lea    -0xb0(%rbp),%rdi
 1016bb2:	call   10276f0 <bcmp@plt>
 1016bb7:	test   %eax,%eax
 1016bb9:	je     1016c53 <trace+0x183>
 1016bbf:	mov    0x11fd2(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1016bc6:	mov    (%rax),%rcx
 1016bc9:	mov    $0x1004860,%edi
 1016bce:	mov    $0x43,%esi
 1016bd3:	mov    $0x1,%edx
 1016bd8:	call   10275d0 <fwrite@plt>
 1016bdd:	call   1027690 <abort@plt>
 1016be2:	cmp    $0x2,%ecx
 1016be5:	je     1016c93 <trace+0x1c3>
 1016beb:	cmp    $0x4,%ecx
 1016bee:	je     1016c93 <trace+0x1c3>
 1016bf4:	cmp    $0x3,%ecx
 1016bf7:	jne    1016aec <trace+0x1c>
 1016bfd:	cmpq   $0x0,0x20(%r15)
 1016c02:	je     1016aec <trace+0x1c>
 1016c08:	lea    0x10(%r15),%rcx
 1016c0c:	lea    0x48(%r15),%rdx
 1016c10:	cmp    $0x2,%eax
 1016c13:	cmove  %rdx,%rcx
 1016c17:	mov    (%rcx),%r12
 1016c1a:	xor    %r13d,%r13d
 1016c1d:	nopl   (%rax)
 1016c20:	mov    0x8(%r12),%rsi
 1016c25:	mov    0x28(%r15),%rdx
 1016c29:	imul   %r13,%rdx
 1016c2d:	add    %rbx,%rdx
 1016c30:	mov    %r14,%rdi
 1016c33:	call   1016ad0 <trace>
 1016c38:	inc    %r13
 1016c3b:	cmp    0x20(%r15),%r13
 1016c3f:	jb     1016c20 <trace+0x150>
 1016c41:	jmp    1016aec <trace+0x1c>
 1016c46:	mov    0x68(%r15),%r13
 1016c4a:	test   %r13,%r13
 1016c4d:	je     1016aec <trace+0x1c>
 1016c53:	add    $0x8,%r12
 1016c57:	mov    $0xffffffff,%r15d
 1016c5d:	jmp    1016c7e <trace+0x1ae>
 1016c5f:	nop
 1016c60:	mov    -0x8(%r12),%eax
 1016c65:	mov    (%rbx,%rax,1),%rsi
 1016c69:	mov    %r14,%rdi
 1016c6c:	call   1016d20 <mark>
 1016c71:	add    $0xc,%r12
 1016c75:	dec    %r13
 1016c78:	je     1016aec <trace+0x1c>
 1016c7e:	mov    -0x4(%r12),%eax
 1016c83:	cmp    %r15,%rax
 1016c86:	je     1016c60 <trace+0x190>
 1016c88:	mov    (%rbx,%rax,1),%eax
 1016c8b:	cmp    (%r12),%eax
 1016c8f:	je     1016c60 <trace+0x190>
 1016c91:	jmp    1016c71 <trace+0x1a1>
 1016c93:	lea    0x10(%r15),%rdx
 1016c97:	lea    0x48(%r15),%rsi
 1016c9b:	lea    0x18(%r15),%rdi
 1016c9f:	lea    0x50(%r15),%r8
 1016ca3:	cmp    $0x2,%eax
 1016ca6:	cmove  %rsi,%rdx
 1016caa:	cmovne %rdi,%r8
 1016cae:	mov    (%r8),%r12
 1016cb1:	movl   $0x0,-0x2c(%rbp)
 1016cb8:	cmp    $0x4,%ecx
 1016cbb:	jne    1016cc2 <trace+0x1f2>
 1016cbd:	mov    (%rbx),%eax
 1016cbf:	mov    %eax,-0x2c(%rbp)
 1016cc2:	test   %r12,%r12
 1016cc5:	je     1016aec <trace+0x1c>
 1016ccb:	mov    (%rdx),%r13
 1016cce:	add    $0x10,%r13
 1016cd2:	jmp    1016d00 <trace+0x230>
 1016cd4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016ce0:	mov    -0x8(%r13),%rsi
 1016ce4:	mov    -0x10(%r13),%rdx
 1016ce8:	add    %rbx,%rdx
 1016ceb:	mov    %r14,%rdi
 1016cee:	call   1016ad0 <trace>
 1016cf3:	add    $0x18,%r13
 1016cf7:	dec    %r12
 1016cfa:	je     1016aec <trace+0x1c>
 1016d00:	cmpw   $0x2,0x30(%r15)
 1016d06:	je     1016ce0 <trace+0x210>
 1016d08:	mov    -0x2c(%rbp),%eax
 1016d0b:	cmp    0x0(%r13),%eax
 1016d0f:	je     1016ce0 <trace+0x210>
 1016d11:	jmp    1016cf3 <trace+0x223>
 1016d13:	int3
 1016d14:	int3
 1016d15:	int3
 1016d16:	int3
 1016d17:	int3
 1016d18:	int3
 1016d19:	int3
 1016d1a:	int3
 1016d1b:	int3
 1016d1c:	int3
 1016d1d:	int3
 1016d1e:	int3
 1016d1f:	int3

0000000001016d20 <mark>:
 1016d20:	test   %rsi,%rsi
 1016d23:	je     1016f6c <mark+0x24c>
 1016d29:	push   %rbp
 1016d2a:	mov    %rsp,%rbp
 1016d2d:	push   %r15
 1016d2f:	push   %r14
 1016d31:	push   %r13
 1016d33:	push   %r12
 1016d35:	push   %rbx
 1016d36:	push   %rax
 1016d37:	add    $0xfffffffffffffff0,%rsi
 1016d3b:	mov    %rsi,%rax
 1016d3e:	shr    $0x15,%rax
 1016d42:	mov    %eax,%ecx
 1016d44:	and    $0x7f,%ecx
 1016d47:	mov    %ecx,%edx
 1016d49:	cmp    %rax,0x1208(%rdi,%rdx,8)
 1016d51:	je     1016da1 <mark+0x81>
 1016d53:	mov    0x1200(%rdi),%rdx
 1016d5a:	test   %rdx,%rdx
 1016d5d:	je     1016dee <mark+0xce>
 1016d63:	mov    0x11f8(%rdi),%r8
 1016d6a:	dec    %rdx
 1016d6d:	movabs $0x9e3779b97f4a7c15,%r9
 1016d77:	imul   %rax,%r9
 1016d7b:	shr    $0x20,%r9
 1016d7f:	nop
 1016d80:	and    %rdx,%r9
 1016d83:	mov    (%r8,%r9,8),%r10
 1016d87:	test   %r10,%r10
 1016d8a:	je     1016d94 <mark+0x74>
 1016d8c:	inc    %r9
 1016d8f:	cmp    %rax,%r10
 1016d92:	jne    1016d80 <mark+0x60>
 1016d94:	cmp    %rax,%r10
 1016d97:	jne    1016dee <mark+0xce>
 1016d99:	mov    %rax,0x1208(%rdi,%rcx,8)
 1016da1:	mov    %rsi,%rbx
 1016da4:	and    $0xffffffffffff0000,%rbx
 1016dab:	mov    %esi,%eax
 1016dad:	shr    $0x4,%eax
 1016db0:	mov    %esi,%r14d
 1016db3:	shr    $0xa,%r14d
 1016db7:	and    $0x3f,%r14d
 1016dbb:	mov    $0x1,%ecx
 1016dc0:	shlx   %rax,%rcx,%r15
 1016dc5:	mov    0x48(%rbx,%r14,8),%rcx
 1016dca:	bt     %rax,%rcx
 1016dce:	jae    1016e71 <mark+0x151>
 1016dd4:	test   %r15,0x248(%rbx,%r14,8)
 1016ddc:	je     1016f5e <mark+0x23e>
 1016de2:	movb   $0x1,0x1175(%rdi)
 1016de9:	jmp    1016f5e <mark+0x23e>
 1016dee:	mov    (%rsi),%rbx
 1016df1:	movabs $0x4000000000000003,%rax
 1016dfb:	test   %rax,%rbx
 1016dfe:	jne    1016f5e <mark+0x23e>
 1016e04:	mov    0x4e8(%rdi),%rcx
 1016e0b:	cmp    0x4f0(%rdi),%rcx
 1016e12:	jne    1016f2a <mark+0x20a>
 1016e18:	lea    (%rcx,%rcx,1),%rax
 1016e1c:	test   %rcx,%rcx
 1016e1f:	mov    $0x400,%r14d
 1016e25:	cmovne %rax,%r14
 1016e29:	cmp    %rcx,%r14
 1016e2c:	jbe    1016ed5 <mark+0x1b5>
 1016e32:	mov    0x8(%rdi),%rax
 1016e36:	lea    0x0(,%r14,8),%rcx
 1016e3e:	mov    %rdi,%r15
 1016e41:	mov    %rax,%rdi
 1016e44:	mov    %rsi,%r12
 1016e47:	mov    %rcx,%rsi
 1016e4a:	call   1027670 <realloc@plt>
 1016e4f:	mov    %r15,%rdi
 1016e52:	test   %rax,%rax
 1016e55:	je     1016ed5 <mark+0x1b5>
 1016e57:	mov    %r12,%rsi
 1016e5a:	mov    %rax,0x8(%rdi)
 1016e5e:	mov    %r14,0x4f0(%rdi)
 1016e65:	mov    0x4e8(%rdi),%rcx
 1016e6c:	jmp    1016f2e <mark+0x20e>
 1016e71:	mov    0x4e8(%rdi),%rcx
 1016e78:	cmp    0x4f0(%rdi),%rcx
 1016e7f:	jne    1016ee1 <mark+0x1c1>
 1016e81:	lea    (%rcx,%rcx,1),%rax
 1016e85:	test   %rcx,%rcx
 1016e88:	mov    $0x400,%r12d
 1016e8e:	cmovne %rax,%r12
 1016e92:	cmp    %rcx,%r12
 1016e95:	jbe    1016ed5 <mark+0x1b5>
 1016e97:	mov    0x8(%rdi),%rax
 1016e9b:	lea    0x0(,%r12,8),%rcx
 1016ea3:	mov    %rdi,-0x30(%rbp)
 1016ea7:	mov    %rax,%rdi
 1016eaa:	mov    %rsi,%r13
 1016ead:	mov    %rcx,%rsi
 1016eb0:	call   1027670 <realloc@plt>
 1016eb5:	mov    -0x30(%rbp),%rdi
 1016eb9:	test   %rax,%rax
 1016ebc:	je     1016ed5 <mark+0x1b5>
 1016ebe:	mov    %r13,%rsi
 1016ec1:	mov    %rax,0x8(%rdi)
 1016ec5:	mov    %r12,0x4f0(%rdi)
 1016ecc:	mov    0x4e8(%rdi),%rcx
 1016ed3:	jmp    1016ee5 <mark+0x1c5>
 1016ed5:	movl   $0x1,0x4f8(%rdi)
 1016edf:	jmp    1016f5e <mark+0x23e>
 1016ee1:	mov    0x8(%rdi),%rax
 1016ee5:	lea    0x1(%rcx),%rdx
 1016ee9:	mov    %rdx,0x4e8(%rdi)
 1016ef0:	mov    %rsi,(%rax,%rcx,8)
 1016ef4:	or     %r15,0x48(%rbx,%r14,8)
 1016ef9:	movzbl 0x1174(%rdi),%eax
 1016f00:	test   %eax,%eax
 1016f02:	je     1016f5b <mark+0x23b>
 1016f04:	cmp    $0x1,%eax
 1016f07:	jne    1016f46 <mark+0x226>
 1016f09:	mov    0x248(%rbx,%r14,8),%rax
 1016f11:	test   %r15,%rax
 1016f14:	jne    1016f4e <mark+0x22e>
 1016f16:	or     %r15,%rax
 1016f19:	mov    %rax,0x248(%rbx,%r14,8)
 1016f21:	movb   $0x1,0x1175(%rdi)
 1016f28:	jmp    1016f5e <mark+0x23e>
 1016f2a:	mov    0x8(%rdi),%rax
 1016f2e:	lea    0x1(%rcx),%rdx
 1016f32:	mov    %rdx,0x4e8(%rdi)
 1016f39:	mov    %rsi,(%rax,%rcx,8)
 1016f3d:	or     $0x1,%rbx
 1016f41:	mov    %rbx,(%rsi)
 1016f44:	jmp    1016f5e <mark+0x23e>
 1016f46:	mov    0x248(%rbx,%r14,8),%rax
 1016f4e:	andn   %rax,%r15,%rax
 1016f53:	mov    %rax,0x248(%rbx,%r14,8)
 1016f5b:	orb    $0x1,(%rsi)
 1016f5e:	add    $0x8,%rsp
 1016f62:	pop    %rbx
 1016f63:	pop    %r12
 1016f65:	pop    %r13
 1016f67:	pop    %r14
 1016f69:	pop    %r15
 1016f6b:	pop    %rbp
 1016f6c:	ret
 1016f6d:	int3
 1016f6e:	int3
 1016f6f:	int3

0000000001016f70 <flatten>:
 1016f70:	mov    0x58(%rsi),%r9d
 1016f74:	cmp    $0x1,%r9d
 1016f78:	jne    1016f80 <flatten+0x10>
 1016f7a:	mov    $0x1,%eax
 1016f7f:	ret
 1016f80:	mov    $0xffffffff,%r10d
 1016f86:	sub    (%rsi),%r10
 1016f89:	xor    %eax,%eax
 1016f8b:	cmp    %r10,%rdx
 1016f8e:	jbe    1016f91 <flatten+0x21>
 1016f90:	ret
 1016f91:	push   %rbp
 1016f92:	mov    %rsp,%rbp
 1016f95:	push   %r15
 1016f97:	push   %r14
 1016f99:	push   %r13
 1016f9b:	push   %r12
 1016f9d:	push   %rbx
 1016f9e:	sub    $0x28,%rsp
 1016fa2:	mov    %rcx,%r15
 1016fa5:	shr    $0x20,%r15
 1016fa9:	movzwl 0x30(%rsi),%r10d
 1016fae:	cmp    $0x6,%r10d
 1016fb2:	ja     1016ffa <flatten+0x8a>
 1016fb4:	mov    $0x62,%r11d
 1016fba:	bt     %r10d,%r11d
 1016fbe:	jae    1016ffa <flatten+0x8a>
 1016fc0:	mov    0x10(%rdi),%rcx
 1016fc4:	cmp    0x8(%rdi),%rcx
 1016fc8:	je     1016feb <flatten+0x7b>
 1016fca:	mov    (%rdi),%rax
 1016fcd:	lea    0x1(%rcx),%rsi
 1016fd1:	mov    %rsi,0x10(%rdi)
 1016fd5:	lea    (%rcx,%rcx,2),%rcx
 1016fd9:	mov    %edx,(%rax,%rcx,4)
 1016fdc:	mov    %r15d,0x4(%rax,%rcx,4)
 1016fe1:	mov    %r8d,0x8(%rax,%rcx,4)
 1016fe6:	mov    $0x1,%eax
 1016feb:	add    $0x28,%rsp
 1016fef:	pop    %rbx
 1016ff0:	pop    %r12
 1016ff2:	pop    %r13
 1016ff4:	pop    %r14
 1016ff6:	pop    %r15
 1016ff8:	pop    %rbp
 1016ff9:	ret
 1016ffa:	lea    0x10(%rsi),%r11
 1016ffe:	lea    0x48(%rsi),%rbx
 1017002:	cmp    $0x2,%r9d
 1017006:	cmove  %rbx,%r11
 101700a:	mov    (%r11),%rbx
 101700d:	cmp    $0x2,%r10d
 1017011:	mov    %r8d,-0x2c(%rbp)
 1017015:	mov    %rdx,-0x40(%rbp)
 1017019:	mov    %rdi,%r13
 101701c:	mov    %rcx,%r14
 101701f:	mov    %rsi,-0x38(%rbp)
 1017023:	je     101707d <flatten+0x10d>
 1017025:	cmp    $0x4,%r10d
 1017029:	je     101707d <flatten+0x10d>
 101702b:	cmp    $0x3,%r10d
 101702f:	jne    1016fe6 <flatten+0x76>
 1017031:	cmpq   $0x0,0x20(%rsi)
 1017036:	je     1016fe6 <flatten+0x76>
 1017038:	xor    %r15d,%r15d
 101703b:	mov    0x8(%rbx),%rax
 101703f:	mov    0x28(%rsi),%r9
 1017043:	imul   %r15,%r9
 1017047:	add    %rdx,%r9
 101704a:	mov    %rax,%rsi
 101704d:	mov    %r9,%rdx
 1017050:	call   1016f70 <flatten>
 1017055:	test   %eax,%eax
 1017057:	je     1017114 <flatten+0x1a4>
 101705d:	inc    %r15
 1017060:	mov    -0x38(%rbp),%rsi
 1017064:	cmp    0x20(%rsi),%r15
 1017068:	mov    -0x2c(%rbp),%r8d
 101706c:	mov    -0x40(%rbp),%rdx
 1017070:	mov    %r13,%rdi
 1017073:	mov    %r14,%rcx
 1017076:	jb     101703b <flatten+0xcb>
 1017078:	jmp    1016fe6 <flatten+0x76>
 101707d:	lea    0x18(%rsi),%r11
 1017081:	lea    0x50(%rsi),%r12
 1017085:	cmp    $0x2,%r9d
 1017089:	cmove  %r12,%r11
 101708d:	cmp    $0x4,%r10d
 1017091:	sete   %r9b
 1017095:	mov    $0xffffffff,%r10d
 101709b:	cmp    %r10,%r15
 101709e:	setne  %r10b
 10170a2:	test   %r10b,%r9b
 10170a5:	jne    1016feb <flatten+0x7b>
 10170ab:	mov    (%r11),%r12
 10170ae:	test   %r12,%r12
 10170b1:	je     1016fe6 <flatten+0x76>
 10170b7:	mov    %edx,%eax
 10170b9:	mov    %rax,-0x48(%rbp)
 10170bd:	add    $0x10,%rbx
 10170c1:	cmpw   $0x4,0x30(%rsi)
 10170c6:	mov    %r15,%r9
 10170c9:	jne    10170d4 <flatten+0x164>
 10170cb:	mov    (%rbx),%r8d
 10170ce:	xor    %ecx,%ecx
 10170d0:	mov    -0x48(%rbp),%r9
 10170d4:	mov    -0x8(%rbx),%rsi
 10170d8:	mov    -0x10(%rbx),%rax
 10170dc:	add    %rdx,%rax
 10170df:	shl    $0x20,%r9
 10170e3:	mov    %ecx,%ecx
 10170e5:	or     %r9,%rcx
 10170e8:	mov    %rax,%rdx
 10170eb:	call   1016f70 <flatten>
 10170f0:	test   %eax,%eax
 10170f2:	je     1017114 <flatten+0x1a4>
 10170f4:	add    $0x18,%rbx
 10170f8:	dec    %r12
 10170fb:	mov    -0x2c(%rbp),%r8d
 10170ff:	mov    -0x40(%rbp),%rdx
 1017103:	mov    %r13,%rdi
 1017106:	mov    %r14,%rcx
 1017109:	mov    -0x38(%rbp),%rsi
 101710d:	jne    10170c1 <flatten+0x151>
 101710f:	jmp    1016fe6 <flatten+0x76>
 1017114:	xor    %eax,%eax
 1017116:	jmp    1016feb <flatten+0x7b>
 101711b:	int3
 101711c:	int3
 101711d:	int3
 101711e:	int3
 101711f:	int3

0000000001017120 <myl_native_arena_reclaim>:
 1017120:	push   %rbp
 1017121:	mov    %rsp,%rbp
 1017124:	push   %rbx
 1017125:	push   %rax
 1017126:	mov    %rdi,%rbx
 1017129:	mov    0x4e0(%rdi),%rdi
 1017130:	jmp    101714c <myl_native_arena_reclaim+0x2c>
 1017132:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1017140:	call   1027570 <free@plt>
 1017145:	mov    0x4e0(%rbx),%rdi
 101714c:	test   %rdi,%rdi
 101714f:	je     101716f <myl_native_arena_reclaim+0x4f>
 1017151:	mov    (%rdi),%rax
 1017154:	mov    %rax,0x4e0(%rbx)
 101715b:	cmpq   $0x0,0x1608(%rbx)
 1017163:	je     1017140 <myl_native_arena_reclaim+0x20>
 1017165:	mov    0x8(%rdi),%rax
 1017169:	sub    %rax,0x18(%rbx)
 101716d:	jmp    1017140 <myl_native_arena_reclaim+0x20>
 101716f:	vxorps %xmm0,%xmm0,%xmm0
 1017173:	vmovups %xmm0,0xc0(%rbx)
 101717b:	add    $0x8,%rsp
 101717f:	pop    %rbx
 1017180:	pop    %rbp
 1017181:	ret
 1017182:	int3
 1017183:	int3
 1017184:	int3
 1017185:	int3
 1017186:	int3
 1017187:	int3
 1017188:	int3
 1017189:	int3
 101718a:	int3
 101718b:	int3
 101718c:	int3
 101718d:	int3
 101718e:	int3
 101718f:	int3

0000000001017190 <myl_native_arena_release>:
 1017190:	push   %rbp
 1017191:	mov    %rsp,%rbp
 1017194:	push   %r15
 1017196:	push   %r14
 1017198:	push   %r13
 101719a:	push   %r12
 101719c:	push   %rbx
 101719d:	sub    $0x18,%rsp
 10171a1:	mov    %rdi,%rbx
 10171a4:	mov    0x11a0(%rdi),%rax
 10171ab:	test   %rax,%rax
 10171ae:	je     10171d9 <myl_native_arena_release+0x49>
 10171b0:	mov    0x5c0(%rbx),%rcx
 10171b7:	sub    %rax,%rcx
 10171ba:	add    $0xffffffffffffffb0,%rcx
 10171be:	mov    %rcx,0x10(%rax)
 10171c2:	movq   $0x0,0x11a0(%rbx)
 10171cd:	vpxor  %xmm0,%xmm0,%xmm0
 10171d1:	vmovdqu %xmm0,0x5c0(%rbx)
 10171d9:	cmpq   $0x0,0x1608(%rbx)
 10171e1:	mov    0x11e8(%rbx),%rdx
 10171e8:	je     1017218 <myl_native_arena_release+0x88>
 10171ea:	test   %rdx,%rdx
 10171ed:	je     1017359 <myl_native_arena_release+0x1c9>
 10171f3:	mov    0x4d8(%rbx),%rax
 10171fa:	test   $0x1,%dl
 10171fd:	jne    1017361 <myl_native_arena_release+0x1d1>
 1017203:	xor    %r14d,%r14d
 1017206:	mov    %rdx,%rcx
 1017209:	cmp    $0x1,%rdx
 101720d:	jne    10173b9 <myl_native_arena_release+0x229>
 1017213:	jmp    1017435 <myl_native_arena_release+0x2a5>
 1017218:	test   %rdx,%rdx
 101721b:	je     1017714 <myl_native_arena_release+0x584>
 1017221:	mov    $0x200000,%r14d
 1017227:	jmp    1017240 <myl_native_arena_release+0xb0>
 1017229:	nopl   0x0(%rax)
 1017230:	mov    0x11e8(%rbx),%rdx
 1017237:	test   %rdx,%rdx
 101723a:	je     1017714 <myl_native_arena_release+0x584>
 1017240:	lea    -0x1(%rdx),%rax
 1017244:	mov    %rax,0x11e8(%rbx)
 101724b:	mov    0x4d8(%rbx),%rcx
 1017252:	mov    -0x8(%rcx,%rdx,8),%rdi
 1017257:	movq   $0x0,-0x8(%rcx,%rdx,8)
 1017260:	mov    %rax,%rdx
 1017263:	test   %rdi,%rdi
 1017266:	jne    101727d <myl_native_arena_release+0xed>
 1017268:	jmp    1017237 <myl_native_arena_release+0xa7>
 101726a:	nopw   0x0(%rax,%rax,1)
 1017270:	call   1027570 <free@plt>
 1017275:	mov    %r15,%rdi
 1017278:	test   %r15,%r15
 101727b:	je     1017230 <myl_native_arena_release+0xa0>
 101727d:	mov    (%rdi),%r15
 1017280:	mov    0x8(%rdi),%rax
 1017284:	sub    %rax,0x18(%rbx)
 1017288:	mov    0x18(%rdi),%rax
 101728c:	sub    %rax,0x40(%rbx)
 1017290:	mov    0x18(%rdi),%rax
 1017294:	add    %rax,0x80(%rbx)
 101729b:	vmovdqu 0xa8(%rbx),%xmm0
 10172a3:	vmovdqa -0x159cb(%rip),%xmm1        # 10018e0 <__abi_tag+0x15e4>
 10172ab:	vpinsrq $0x1,0x8(%rdi),%xmm1,%xmm1
 10172b2:	vpsubq %xmm1,%xmm0,%xmm0
 10172b6:	vmovdqu %xmm0,0xa8(%rbx)
 10172be:	mov    0x58(%rbx),%rax
 10172c2:	cmp    $0x200000,%rax
 10172c8:	mov    $0x200000,%ecx
 10172cd:	cmovb  %rax,%rcx
 10172d1:	test   %rax,%rax
 10172d4:	mov    %rcx,%rax
 10172d7:	cmove  %r14,%rax
 10172db:	cmpq   $0x0,0x1608(%rbx)
 10172e3:	cmove  %rcx,%rax
 10172e7:	mov    0x8(%rdi),%rsi
 10172eb:	cmp    $0x100000,%rsi
 10172f2:	ja     1017270 <myl_native_arena_release+0xe0>
 10172f8:	mov    0xc0(%rbx),%rcx
 10172ff:	cmp    $0x3,%rcx
 1017303:	ja     1017270 <myl_native_arena_release+0xe0>
 1017309:	mov    0xc8(%rbx),%rdx
 1017310:	sub    %rdx,%rax
 1017313:	jbe    1017270 <myl_native_arena_release+0xe0>
 1017319:	cmp    %rax,%rsi
 101731c:	ja     1017270 <myl_native_arena_release+0xe0>
 1017322:	mov    0x4e0(%rbx),%rax
 1017329:	mov    %rax,(%rdi)
 101732c:	mov    %rdi,0x4e0(%rbx)
 1017333:	inc    %rcx
 1017336:	mov    %rcx,0xc0(%rbx)
 101733d:	add    0x8(%rdi),%rdx
 1017341:	mov    %rdx,0xc8(%rbx)
 1017348:	mov    %r15,%rdi
 101734b:	test   %r15,%r15
 101734e:	jne    101727d <myl_native_arena_release+0xed>
 1017354:	jmp    1017230 <myl_native_arena_release+0xa0>
 1017359:	xor    %r14d,%r14d
 101735c:	jmp    101743c <myl_native_arena_release+0x2ac>
 1017361:	lea    -0x1(%rdx),%rcx
 1017365:	mov    -0x8(%rax,%rdx,8),%rsi
 101736a:	movq   $0x0,-0x8(%rax,%rdx,8)
 1017373:	test   %rsi,%rsi
 1017376:	je     101739c <myl_native_arena_release+0x20c>
 1017378:	xor    %edi,%edi
 101737a:	nopw   0x0(%rax,%rax,1)
 1017380:	mov    %rsi,%r14
 1017383:	mov    (%rsi),%rsi
 1017386:	mov    %rdi,(%r14)
 1017389:	mov    %r14,%rdi
 101738c:	test   %rsi,%rsi
 101738f:	jne    1017380 <myl_native_arena_release+0x1f0>
 1017391:	cmp    $0x1,%rdx
 1017395:	jne    10173b9 <myl_native_arena_release+0x229>
 1017397:	jmp    1017435 <myl_native_arena_release+0x2a5>
 101739c:	xor    %r14d,%r14d
 101739f:	cmp    $0x1,%rdx
 10173a3:	jne    10173b9 <myl_native_arena_release+0x229>
 10173a5:	jmp    1017435 <myl_native_arena_release+0x2a5>
 10173aa:	nopw   0x0(%rax,%rax,1)
 10173b0:	mov    %rdx,%r14
 10173b3:	add    $0xfffffffffffffffe,%rcx
 10173b7:	je     1017433 <myl_native_arena_release+0x2a3>
 10173b9:	mov    -0x8(%rax,%rcx,8),%rsi
 10173be:	movq   $0x0,-0x8(%rax,%rcx,8)
 10173c7:	test   %rsi,%rsi
 10173ca:	je     1017400 <myl_native_arena_release+0x270>
 10173cc:	nopl   0x0(%rax)
 10173d0:	mov    (%rsi),%rdi
 10173d3:	mov    %r14,(%rsi)
 10173d6:	mov    %rsi,%rdx
 10173d9:	mov    %rsi,%r14
 10173dc:	mov    %rdi,%rsi
 10173df:	test   %rdi,%rdi
 10173e2:	jne    10173d0 <myl_native_arena_release+0x240>
 10173e4:	mov    -0x10(%rax,%rcx,8),%rsi
 10173e9:	movq   $0x0,-0x10(%rax,%rcx,8)
 10173f2:	test   %rsi,%rsi
 10173f5:	jne    1017420 <myl_native_arena_release+0x290>
 10173f7:	jmp    10173b0 <myl_native_arena_release+0x220>
 10173f9:	nopl   0x0(%rax)
 1017400:	mov    %r14,%rdx
 1017403:	mov    -0x10(%rax,%rcx,8),%rsi
 1017408:	movq   $0x0,-0x10(%rax,%rcx,8)
 1017411:	test   %rsi,%rsi
 1017414:	je     10173b0 <myl_native_arena_release+0x220>
 1017416:	cs nopw 0x0(%rax,%rax,1)
 1017420:	mov    %rsi,%r14
 1017423:	mov    (%rsi),%rsi
 1017426:	mov    %rdx,(%r14)
 1017429:	mov    %r14,%rdx
 101742c:	test   %rsi,%rsi
 101742f:	jne    1017420 <myl_native_arena_release+0x290>
 1017431:	jmp    10173b3 <myl_native_arena_release+0x223>
 1017433:	xor    %ecx,%ecx
 1017435:	mov    %rcx,0x11e8(%rbx)
 101743c:	mov    0x70(%rbx),%eax
 101743f:	mov    %eax,-0x34(%rbp)
 1017442:	movl   $0x0,0x70(%rbx)
 1017449:	mov    %rbx,%rdi
 101744c:	xor    %esi,%esi
 101744e:	call   101e3a0 <myl_rc_scope_unwind>
 1017453:	mov    %r14,-0x30(%rbp)
 1017457:	test   %r14,%r14
 101745a:	je     1017603 <myl_native_arena_release+0x473>
 1017460:	mov    $0x28,%edx
 1017465:	mov    -0x30(%rbp),%r13
 1017469:	jmp    101747d <myl_native_arena_release+0x2ed>
 101746b:	nopl   0x0(%rax,%rax,1)
 1017470:	mov    0x0(%r13),%r13
 1017474:	test   %r13,%r13
 1017477:	je     1017529 <myl_native_arena_release+0x399>
 101747d:	cmpq   $0x0,0x10(%r13)
 1017482:	je     1017470 <myl_native_arena_release+0x2e0>
 1017484:	lea    0x50(%r13),%r14
 1017488:	xor    %r12d,%r12d
 101748b:	jmp    10174a1 <myl_native_arena_release+0x311>
 101748d:	nopl   (%rax)
 1017490:	add    %r15,%r12
 1017493:	add    $0x1f,%r12
 1017497:	and    $0xfffffffffffffff0,%r12
 101749b:	cmp    0x10(%r13),%r12
 101749f:	jae    1017470 <myl_native_arena_release+0x2e0>
 10174a1:	mov    (%r14,%r12,1),%rax
 10174a5:	mov    0x8(%r14,%r12,1),%rsi
 10174aa:	bzhi   %rdx,%rax,%r15
 10174af:	shr    $0x2,%r15
 10174b3:	imul   (%rsi),%r15
 10174b7:	cmp    $0x1,%r15
 10174bb:	adc    $0x0,%r15
 10174bf:	test   $0x1,%al
 10174c1:	jne    1017490 <myl_native_arena_release+0x300>
 10174c3:	mov    0x1608(%rbx),%rdi
 10174ca:	mov    0x34(%rsi),%eax
 10174cd:	cmp    %rax,0xa0(%rdi)
 10174d4:	jbe    101751a <myl_native_arena_release+0x38a>
 10174d6:	mov    0x98(%rdi),%rcx
 10174dd:	shl    $0x4,%rax
 10174e1:	cmp    %rsi,(%rcx,%rax,1)
 10174e5:	jne    101751a <myl_native_arena_release+0x38a>
 10174e7:	add    %rax,%rcx
 10174ea:	mov    0x8(%rcx),%rax
 10174ee:	test   %rax,%rax
 10174f1:	je     1017723 <myl_native_arena_release+0x593>
 10174f7:	lea    (%r14,%r12,1),%rsi
 10174fb:	orb    $0x1,(%rsi)
 10174fe:	mov    0x18(%rax),%rax
 1017502:	test   %rax,%rax
 1017505:	je     1017490 <myl_native_arena_release+0x300>
 1017507:	add    $0x10,%rsi
 101750b:	mov    %rbx,%rdi
 101750e:	call   *%rax
 1017510:	mov    $0x28,%edx
 1017515:	jmp    1017490 <myl_native_arena_release+0x300>
 101751a:	call   1018df4 <myl_rc_binding_find_slow>
 101751f:	test   %rax,%rax
 1017522:	jne    10174f7 <myl_native_arena_release+0x367>
 1017524:	jmp    1017723 <myl_native_arena_release+0x593>
 1017529:	mov    -0x30(%rbp),%r15
 101752d:	jmp    101753c <myl_native_arena_release+0x3ac>
 101752f:	nop
 1017530:	mov    (%r15),%r15
 1017533:	test   %r15,%r15
 1017536:	je     1017603 <myl_native_arena_release+0x473>
 101753c:	cmpq   $0x0,0x10(%r15)
 1017541:	je     1017530 <myl_native_arena_release+0x3a0>
 1017543:	lea    0x50(%r15),%r9
 1017547:	xor    %r12d,%r12d
 101754a:	jmp    1017574 <myl_native_arena_release+0x3e4>
 101754c:	nopl   0x0(%rax)
 1017550:	mov    0x8(%rax),%rsi
 1017554:	add    $0x10,%rdx
 1017558:	mov    %rbx,%rdi
 101755b:	call   101b300 <myl_rc_edges_release>
 1017560:	add    %r13,%r12
 1017563:	add    $0x1f,%r12
 1017567:	and    $0xfffffffffffffff0,%r12
 101756b:	cmp    0x10(%r15),%r12
 101756f:	mov    %r14,%r9
 1017572:	jae    1017530 <myl_native_arena_release+0x3a0>
 1017574:	mov    $0x28,%eax
 1017579:	bzhi   %rax,(%r9,%r12,1),%rcx
 101757f:	shr    $0x2,%rcx
 1017583:	mov    0x8(%r9,%r12,1),%rsi
 1017588:	mov    (%rsi),%r13
 101758b:	imul   %rcx,%r13
 101758f:	cmp    $0x1,%r13
 1017593:	adc    $0x0,%r13
 1017597:	mov    0x1608(%rbx),%rdi
 101759e:	mov    0x34(%rsi),%eax
 10175a1:	cmp    %rax,0xa0(%rdi)
 10175a8:	jbe    10175f4 <myl_native_arena_release+0x464>
 10175aa:	mov    0x98(%rdi),%rdx
 10175b1:	shl    $0x4,%rax
 10175b5:	cmp    %rsi,(%rdx,%rax,1)
 10175b9:	jne    10175f4 <myl_native_arena_release+0x464>
 10175bb:	add    %rax,%rdx
 10175be:	mov    0x8(%rdx),%rax
 10175c2:	test   %rax,%rax
 10175c5:	je     1017723 <myl_native_arena_release+0x593>
 10175cb:	mov    %r9,%r14
 10175ce:	lea    (%r9,%r12,1),%rdx
 10175d2:	mov    0x10(%rax),%r8
 10175d6:	test   %r8,%r8
 10175d9:	je     1017550 <myl_native_arena_release+0x3c0>
 10175df:	add    $0x10,%rdx
 10175e3:	mov    %rbx,%rdi
 10175e6:	mov    %rdx,%rsi
 10175e9:	mov    %rcx,%rdx
 10175ec:	call   *%r8
 10175ef:	jmp    1017560 <myl_native_arena_release+0x3d0>
 10175f4:	call   1018df4 <myl_rc_binding_find_slow>
 10175f9:	test   %rax,%rax
 10175fc:	jne    10175cb <myl_native_arena_release+0x43b>
 10175fe:	jmp    1017723 <myl_native_arena_release+0x593>
 1017603:	mov    %rbx,%rdi
 1017606:	call   101bcb0 <myl_rc_drain>
 101760b:	cmpl   $0x0,0x70(%rbx)
 101760f:	jne    1017723 <myl_native_arena_release+0x593>
 1017615:	mov    -0x34(%rbp),%eax
 1017618:	mov    %eax,0x70(%rbx)
 101761b:	mov    -0x30(%rbp),%rdi
 101761f:	test   %rdi,%rdi
 1017622:	je     1017714 <myl_native_arena_release+0x584>
 1017628:	mov    $0x200000,%r15d
 101762e:	jmp    1017645 <myl_native_arena_release+0x4b5>
 1017630:	sub    %rcx,0x18(%rbx)
 1017634:	call   1027570 <free@plt>
 1017639:	mov    %r12,%rdi
 101763c:	test   %r12,%r12
 101763f:	je     1017714 <myl_native_arena_release+0x584>
 1017645:	mov    (%rdi),%r12
 1017648:	mov    0x18(%rdi),%rax
 101764c:	sub    %rax,0x40(%rbx)
 1017650:	mov    0x18(%rdi),%rax
 1017654:	add    %rax,0x80(%rbx)
 101765b:	vmovdqu 0xa8(%rbx),%xmm0
 1017663:	vmovdqa -0x15d8b(%rip),%xmm1        # 10018e0 <__abi_tag+0x15e4>
 101766b:	vpinsrq $0x1,0x8(%rdi),%xmm1,%xmm1
 1017672:	vpsubq %xmm1,%xmm0,%xmm0
 1017676:	vmovdqu %xmm0,0xa8(%rbx)
 101767e:	mov    0x58(%rbx),%rax
 1017682:	cmp    $0x200000,%rax
 1017688:	mov    $0x200000,%ecx
 101768d:	cmovb  %rax,%rcx
 1017691:	test   %rax,%rax
 1017694:	mov    %rcx,%rax
 1017697:	cmove  %r15,%rax
 101769b:	cmpq   $0x0,0x1608(%rbx)
 10176a3:	cmove  %rcx,%rax
 10176a7:	mov    0x8(%rdi),%rcx
 10176ab:	cmp    $0x100000,%rcx
 10176b2:	ja     1017630 <myl_native_arena_release+0x4a0>
 10176b8:	mov    0xc0(%rbx),%rdx
 10176bf:	cmp    $0x3,%rdx
 10176c3:	ja     1017630 <myl_native_arena_release+0x4a0>
 10176c9:	mov    0xc8(%rbx),%rsi
 10176d0:	sub    %rsi,%rax
 10176d3:	jbe    1017630 <myl_native_arena_release+0x4a0>
 10176d9:	cmp    %rax,%rcx
 10176dc:	ja     1017630 <myl_native_arena_release+0x4a0>
 10176e2:	mov    0x4e0(%rbx),%rax
 10176e9:	mov    %rax,(%rdi)
 10176ec:	mov    %rdi,0x4e0(%rbx)
 10176f3:	inc    %rdx
 10176f6:	mov    %rdx,0xc0(%rbx)
 10176fd:	add    0x8(%rdi),%rsi
 1017701:	mov    %rsi,0xc8(%rbx)
 1017708:	mov    %r12,%rdi
 101770b:	test   %r12,%r12
 101770e:	jne    1017645 <myl_native_arena_release+0x4b5>
 1017714:	add    $0x18,%rsp
 1017718:	pop    %rbx
 1017719:	pop    %r12
 101771b:	pop    %r13
 101771d:	pop    %r14
 101771f:	pop    %r15
 1017721:	pop    %rbp
 1017722:	ret
 1017723:	call   10187d4 <myl_rc_invariant_failed>
 1017728:	int3
 1017729:	int3
 101772a:	int3
 101772b:	int3
 101772c:	int3
 101772d:	int3
 101772e:	int3
 101772f:	int3

0000000001017730 <rc_list_new>:
 1017730:	push   %rbp
 1017731:	mov    %rsp,%rbp
 1017734:	push   %r15
 1017736:	push   %r14
 1017738:	push   %r13
 101773a:	push   %r12
 101773c:	push   %rbx
 101773d:	push   %rax
 101773e:	mov    %ecx,%r15d
 1017741:	mov    %rdx,%r14
 1017744:	mov    %rsi,%r12
 1017747:	mov    %rdi,%rbx
 101774a:	mov    0x1608(%rdi),%rax
 1017751:	cmp    %rsi,0x110(%rax)
 1017758:	je     1017775 <rc_list_new+0x45>
 101775a:	mov    %rbx,%rdi
 101775d:	mov    %r12,%rsi
 1017760:	call   1023330 <myl_rc_native_shape>
 1017765:	test   %rax,%rax
 1017768:	je     101782c <rc_list_new+0xfc>
 101776e:	mov    0x1608(%rbx),%rax
 1017775:	cmpb   $0x0,0x120(%rax)
 101777c:	je     10177c6 <rc_list_new+0x96>
 101777e:	mov    $0x100b618,%esi
 1017783:	mov    $0x1,%edx
 1017788:	mov    %rbx,%rdi
 101778b:	mov    %r15d,%ecx
 101778e:	call   1020e20 <myl_rc_storage_alloc>
 1017793:	test   %rax,%rax
 1017796:	je     101782c <rc_list_new+0xfc>
 101779c:	mov    %r12,0x18(%rax)
 10177a0:	test   %r14,%r14
 10177a3:	je     101781b <rc_list_new+0xeb>
 10177a5:	mov    %rax,%r13
 10177a8:	mov    (%r12),%rsi
 10177ac:	test   %rsi,%rsi
 10177af:	je     10177f8 <rc_list_new+0xc8>
 10177b1:	mov    %rsi,%rax
 10177b4:	mul    %r14
 10177b7:	jno    10177f8 <rc_list_new+0xc8>
 10177b9:	mov    %r13,%rax
 10177bc:	movq   $0x0,0x20(%r13)
 10177c4:	jmp    1017821 <rc_list_new+0xf1>
 10177c6:	mov    $0x100b3e0,%esi
 10177cb:	mov    %rbx,%rdi
 10177ce:	call   1019580 <myl_rc_module_register>
 10177d3:	mov    0x1608(%rbx),%rcx
 10177da:	test   %eax,%eax
 10177dc:	je     101783d <rc_list_new+0x10d>
 10177de:	test   %rcx,%rcx
 10177e1:	je     1017849 <rc_list_new+0x119>
 10177e3:	cmpl   $0x0,0x124(%rcx)
 10177ea:	jne    101782c <rc_list_new+0xfc>
 10177ec:	movl   $0x1,0x124(%rcx)
 10177f6:	jmp    101782c <rc_list_new+0xfc>
 10177f8:	imul   %r14,%rsi
 10177fc:	mov    %rbx,%rdi
 10177ff:	mov    %r15d,%edx
 1017802:	mov    $0x1,%ecx
 1017807:	call   1022df0 <raw_bytes>
 101780c:	mov    %rax,%rcx
 101780f:	mov    %r13,%rax
 1017812:	mov    %rcx,0x20(%r13)
 1017816:	test   %rcx,%rcx
 1017819:	je     1017821 <rc_list_new+0xf1>
 101781b:	mov    %r14,0x8(%rax)
 101781f:	jmp    101782e <rc_list_new+0xfe>
 1017821:	mov    %rbx,%rdi
 1017824:	mov    %rax,%rsi
 1017827:	call   101cb50 <myl_rc_construction_abort>
 101782c:	xor    %eax,%eax
 101782e:	add    $0x8,%rsp
 1017832:	pop    %rbx
 1017833:	pop    %r12
 1017835:	pop    %r13
 1017837:	pop    %r14
 1017839:	pop    %r15
 101783b:	pop    %rbp
 101783c:	ret
 101783d:	movb   $0x1,0x120(%rcx)
 1017844:	jmp    101777e <rc_list_new+0x4e>
 1017849:	call   10187d4 <myl_rc_invariant_failed>
 101784e:	int3
 101784f:	int3

0000000001017850 <rc_list_edges>:
 1017850:	push   %rbp
 1017851:	mov    %rsp,%rbp
 1017854:	push   %r14
 1017856:	push   %rbx
 1017857:	cmpq   $0x0,(%rsi)
 101785b:	je     1017949 <rc_list_edges+0xf9>
 1017861:	mov    0x18(%rsi),%rcx
 1017865:	mov    0x1608(%rdi),%rax
 101786c:	cmp    %rcx,0x110(%rax)
 1017873:	je     1017949 <rc_list_edges+0xf9>
 1017879:	mov    0x34(%rcx),%edx
 101787c:	cmp    %rdx,0xa0(%rax)
 1017883:	jbe    1017966 <rc_list_edges+0x116>
 1017889:	mov    0x98(%rax),%r8
 1017890:	shl    $0x4,%rdx
 1017894:	cmp    %rcx,(%r8,%rdx,1)
 1017898:	jne    1017966 <rc_list_edges+0x116>
 101789e:	add    %rdx,%r8
 10178a1:	mov    0x8(%r8),%rax
 10178a5:	test   %rax,%rax
 10178a8:	je     10178ba <rc_list_edges+0x6a>
 10178aa:	cmpl   $0x0,0x40(%rax)
 10178ae:	jne    10178ba <rc_list_edges+0x6a>
 10178b0:	cmpb   $0x0,0x45(%rax)
 10178b4:	je     1017956 <rc_list_edges+0x106>
 10178ba:	mov    (%rsi),%rcx
 10178bd:	mov    0x18(%rsi),%rax
 10178c1:	mov    0x20(%rsi),%rdx
 10178c5:	mov    0x1608(%rdi),%r8
 10178cc:	mov    0x34(%rax),%r9d
 10178d0:	cmp    %r9,0xa0(%r8)
 10178d7:	jbe    101798b <rc_list_edges+0x13b>
 10178dd:	mov    0x98(%r8),%r10
 10178e4:	shl    $0x4,%r9
 10178e8:	cmp    %rax,(%r10,%r9,1)
 10178ec:	jne    101798b <rc_list_edges+0x13b>
 10178f2:	add    %r9,%r10
 10178f5:	mov    0x8(%r10),%rax
 10178f9:	test   %rax,%rax
 10178fc:	je     10179ab <rc_list_edges+0x15b>
 1017902:	mov    0x40(%rax),%r8d
 1017906:	test   %r8d,%r8d
 1017909:	je     101791a <rc_list_edges+0xca>
 101790b:	cmp    $0x11,%r8d
 101790f:	jb     1017920 <rc_list_edges+0xd0>
 1017911:	mov    %rsi,%r14
 1017914:	mov    0x8(%rax),%rsi
 1017918:	jmp    101793b <rc_list_edges+0xeb>
 101791a:	cmpb   $0x0,0x45(%rax)
 101791e:	je     1017949 <rc_list_edges+0xf9>
 1017920:	mov    %rsi,%r14
 1017923:	mov    0x8(%rax),%rsi
 1017927:	cmpq   $0x3,0x28(%rsi)
 101792c:	jb     101793b <rc_list_edges+0xeb>
 101792e:	mov    %rdi,%rbx
 1017931:	mov    %rax,%rsi
 1017934:	call   101ba70 <myl_rc_flat_edges_release>
 1017939:	jmp    1017943 <rc_list_edges+0xf3>
 101793b:	mov    %rdi,%rbx
 101793e:	call   101b300 <myl_rc_edges_release>
 1017943:	mov    %rbx,%rdi
 1017946:	mov    %r14,%rsi
 1017949:	mov    0x20(%rsi),%rsi
 101794d:	pop    %rbx
 101794e:	pop    %r14
 1017950:	pop    %rbp
 1017951:	jmp    1018bc0 <myl_rc_edge_release>
 1017956:	mov    0x1608(%rdi),%rax
 101795d:	mov    %rcx,0x110(%rax)
 1017964:	jmp    1017949 <rc_list_edges+0xf9>
 1017966:	mov    %rdi,%rdx
 1017969:	mov    %rax,%rdi
 101796c:	mov    %rsi,%r8
 101796f:	mov    %rcx,%rsi
 1017972:	call   1018df4 <myl_rc_binding_find_slow>
 1017977:	mov    %r8,%rsi
 101797a:	mov    %rdx,%rdi
 101797d:	test   %rax,%rax
 1017980:	jne    10178aa <rc_list_edges+0x5a>
 1017986:	jmp    10178ba <rc_list_edges+0x6a>
 101798b:	mov    %rdi,%r9
 101798e:	mov    %r8,%rdi
 1017991:	mov    %rsi,%r8
 1017994:	mov    %rax,%rsi
 1017997:	call   1018df4 <myl_rc_binding_find_slow>
 101799c:	mov    %r8,%rsi
 101799f:	mov    %r9,%rdi
 10179a2:	test   %rax,%rax
 10179a5:	jne    1017902 <rc_list_edges+0xb2>
 10179ab:	call   1027690 <abort@plt>

00000000010179b0 <rc_list_clone_adapter>:
 10179b0:	push   %rbp
 10179b1:	mov    %rsp,%rbp
 10179b4:	push   %r15
 10179b6:	push   %r14
 10179b8:	push   %r13
 10179ba:	push   %r12
 10179bc:	push   %rbx
 10179bd:	push   %rax
 10179be:	mov    %rcx,%rbx
 10179c1:	mov    %edx,%ecx
 10179c3:	mov    %rsi,%r14
 10179c6:	mov    %rdi,%r12
 10179c9:	mov    0x18(%rsi),%r13
 10179cd:	mov    (%rsi),%rdx
 10179d0:	mov    0x8(%rsi),%rax
 10179d4:	cmp    %rdx,%rax
 10179d7:	cmova  %rax,%rdx
 10179db:	mov    %r13,%rsi
 10179de:	call   1017730 <rc_list_new>
 10179e3:	test   %rax,%rax
 10179e6:	je     1017aa7 <rc_list_clone_adapter+0xf7>
 10179ec:	mov    %rax,%r15
 10179ef:	mov    %rbx,-0x30(%rbp)
 10179f3:	mov    (%r14),%rax
 10179f6:	test   %rax,%rax
 10179f9:	je     1017b05 <rc_list_clone_adapter+0x155>
 10179ff:	mov    0x0(%r13),%rdx
 1017a03:	test   %rdx,%rdx
 1017a06:	je     1017a65 <rc_list_clone_adapter+0xb5>
 1017a08:	mov    0x1608(%r12),%rdi
 1017a10:	cmp    %r13,0x110(%rdi)
 1017a17:	je     1017aee <rc_list_clone_adapter+0x13e>
 1017a1d:	mov    0x34(%r13),%eax
 1017a21:	cmp    %rax,0xa0(%rdi)
 1017a28:	jbe    1017b25 <rc_list_clone_adapter+0x175>
 1017a2e:	mov    0x98(%rdi),%rcx
 1017a35:	shl    $0x4,%rax
 1017a39:	cmp    %r13,(%rcx,%rax,1)
 1017a3d:	jne    1017b25 <rc_list_clone_adapter+0x175>
 1017a43:	add    %rax,%rcx
 1017a46:	mov    0x8(%rcx),%rax
 1017a4a:	test   %rax,%rax
 1017a4d:	je     1017a5b <rc_list_clone_adapter+0xab>
 1017a4f:	cmpl   $0x0,0x40(%rax)
 1017a53:	jne    1017a5b <rc_list_clone_adapter+0xab>
 1017a55:	cmpb   $0x0,0x45(%rax)
 1017a59:	je     1017ad8 <rc_list_clone_adapter+0x128>
 1017a5b:	cmpq   $0x0,(%r14)
 1017a5f:	je     1017b05 <rc_list_clone_adapter+0x155>
 1017a65:	xor    %ebx,%ebx
 1017a67:	nopw   0x0(%rax,%rax,1)
 1017a70:	mov    0x0(%r13),%rcx
 1017a74:	imul   %rbx,%rcx
 1017a78:	add    0x20(%r14),%rcx
 1017a7c:	mov    (%r15),%rdx
 1017a7f:	mov    %r12,%rdi
 1017a82:	mov    %r15,%rsi
 1017a85:	call   1017d90 <rc_list_insert_at>
 1017a8a:	test   %eax,%eax
 1017a8c:	je     1017a98 <rc_list_clone_adapter+0xe8>
 1017a8e:	inc    %rbx
 1017a91:	cmp    (%r14),%rbx
 1017a94:	jb     1017a70 <rc_list_clone_adapter+0xc0>
 1017a96:	jmp    1017b05 <rc_list_clone_adapter+0x155>
 1017a98:	mov    %r12,%rdi
 1017a9b:	mov    %r15,%rsi
 1017a9e:	call   101cb50 <myl_rc_construction_abort>
 1017aa3:	mov    -0x30(%rbp),%rbx
 1017aa7:	movq   $0x0,(%rbx)
 1017aae:	test   %r12,%r12
 1017ab1:	je     1017b3b <rc_list_clone_adapter+0x18b>
 1017ab7:	mov    0x1608(%r12),%rcx
 1017abf:	test   %rcx,%rcx
 1017ac2:	je     1017b3b <rc_list_clone_adapter+0x18b>
 1017ac4:	mov    0x124(%rcx),%eax
 1017aca:	cmp    $0x1,%eax
 1017acd:	adc    $0x0,%eax
 1017ad0:	mov    %eax,0x124(%rcx)
 1017ad6:	jmp    1017b16 <rc_list_clone_adapter+0x166>
 1017ad8:	mov    0x1608(%r12),%rax
 1017ae0:	mov    %r13,0x110(%rax)
 1017ae7:	mov    (%r14),%rax
 1017aea:	mov    0x0(%r13),%rdx
 1017aee:	imul   %rax,%rdx
 1017af2:	mov    0x20(%r15),%rdi
 1017af6:	mov    0x20(%r14),%rsi
 1017afa:	call   1027520 <memcpy@plt>
 1017aff:	mov    (%r14),%rax
 1017b02:	mov    %rax,(%r15)
 1017b05:	movq   $0x0,0x10(%r15)
 1017b0d:	mov    -0x30(%rbp),%rax
 1017b11:	mov    %r15,(%rax)
 1017b14:	xor    %eax,%eax
 1017b16:	add    $0x8,%rsp
 1017b1a:	pop    %rbx
 1017b1b:	pop    %r12
 1017b1d:	pop    %r13
 1017b1f:	pop    %r14
 1017b21:	pop    %r15
 1017b23:	pop    %rbp
 1017b24:	ret
 1017b25:	mov    %r13,%rsi
 1017b28:	call   1018df4 <myl_rc_binding_find_slow>
 1017b2d:	test   %rax,%rax
 1017b30:	jne    1017a4f <rc_list_clone_adapter+0x9f>
 1017b36:	jmp    1017a5b <rc_list_clone_adapter+0xab>
 1017b3b:	call   10187d4 <myl_rc_invariant_failed>

0000000001017b40 <rc_list_shell>:
 1017b40:	push   %rbp
 1017b41:	mov    %rsp,%rbp
 1017b44:	push   %r15
 1017b46:	push   %r14
 1017b48:	push   %r12
 1017b4a:	push   %rbx
 1017b4b:	mov    %rcx,%r12
 1017b4e:	mov    %edx,%ecx
 1017b50:	mov    %rsi,%rbx
 1017b53:	mov    %rdi,%r14
 1017b56:	mov    (%rsi),%rdx
 1017b59:	mov    0x8(%rsi),%rax
 1017b5d:	cmp    %rdx,%rax
 1017b60:	cmova  %rax,%rdx
 1017b64:	mov    0x18(%rsi),%rsi
 1017b68:	call   1017730 <rc_list_new>
 1017b6d:	mov    %rax,(%r12)
 1017b71:	test   %rax,%rax
 1017b74:	je     1017bd1 <rc_list_shell+0x91>
 1017b76:	mov    %rax,%r15
 1017b79:	mov    0x18(%rbx),%rsi
 1017b7d:	mov    0x1608(%r14),%rdi
 1017b84:	mov    0x34(%rsi),%eax
 1017b87:	cmp    %rax,0xa0(%rdi)
 1017b8e:	jbe    1017c0b <rc_list_shell+0xcb>
 1017b90:	mov    0x98(%rdi),%rcx
 1017b97:	shl    $0x4,%rax
 1017b9b:	cmp    %rsi,(%rcx,%rax,1)
 1017b9f:	jne    1017c0b <rc_list_shell+0xcb>
 1017ba1:	add    %rax,%rcx
 1017ba4:	mov    0x8(%rcx),%rax
 1017ba8:	test   %rax,%rax
 1017bab:	je     1017c15 <rc_list_shell+0xd5>
 1017bad:	mov    (%rbx),%r8
 1017bb0:	xor    %r12d,%r12d
 1017bb3:	test   %r8,%r8
 1017bb6:	je     1017bfa <rc_list_shell+0xba>
 1017bb8:	mov    0x8(%rax),%rsi
 1017bbc:	mov    0x20(%r15),%rdx
 1017bc0:	mov    0x20(%rbx),%rcx
 1017bc4:	mov    %r14,%rdi
 1017bc7:	call   101c8c0 <myl_rc_value_seed>
 1017bcc:	mov    (%rbx),%rax
 1017bcf:	jmp    1017bfc <rc_list_shell+0xbc>
 1017bd1:	test   %r14,%r14
 1017bd4:	je     1017c1a <rc_list_shell+0xda>
 1017bd6:	mov    0x1608(%r14),%rax
 1017bdd:	test   %rax,%rax
 1017be0:	je     1017c1a <rc_list_shell+0xda>
 1017be2:	mov    0x124(%rax),%r12d
 1017be9:	cmp    $0x1,%r12d
 1017bed:	adc    $0x0,%r12d
 1017bf1:	mov    %r12d,0x124(%rax)
 1017bf8:	jmp    1017bff <rc_list_shell+0xbf>
 1017bfa:	xor    %eax,%eax
 1017bfc:	mov    %rax,(%r15)
 1017bff:	mov    %r12d,%eax
 1017c02:	pop    %rbx
 1017c03:	pop    %r12
 1017c05:	pop    %r14
 1017c07:	pop    %r15
 1017c09:	pop    %rbp
 1017c0a:	ret
 1017c0b:	call   1018df4 <myl_rc_binding_find_slow>
 1017c10:	test   %rax,%rax
 1017c13:	jne    1017bad <rc_list_shell+0x6d>
 1017c15:	call   1027690 <abort@plt>
 1017c1a:	call   10187d4 <myl_rc_invariant_failed>
 1017c1f:	int3

0000000001017c20 <rc_list_next>:
 1017c20:	push   %rbp
 1017c21:	mov    %rsp,%rbp
 1017c24:	push   %r14
 1017c26:	push   %rbx
 1017c27:	mov    0x18(%rsi),%rax
 1017c2b:	mov    0x1608(%rdi),%rdi
 1017c32:	mov    0x34(%rax),%r10d
 1017c36:	cmp    %r10,0xa0(%rdi)
 1017c3d:	jbe    1017d14 <rc_list_next+0xf4>
 1017c43:	mov    0x98(%rdi),%r11
 1017c4a:	shl    $0x4,%r10
 1017c4e:	cmp    %rax,(%r11,%r10,1)
 1017c52:	jne    1017d14 <rc_list_next+0xf4>
 1017c58:	add    %r10,%r11
 1017c5b:	mov    0x8(%r11),%rax
 1017c5f:	test   %rax,%rax
 1017c62:	je     1017d2b <rc_list_next+0x10b>
 1017c68:	mov    (%rcx),%r10
 1017c6b:	xor    %edi,%edi
 1017c6d:	cmp    (%rsi),%r10
 1017c70:	jae    1017d0d <rc_list_next+0xed>
 1017c76:	mov    0x8(%rax),%r11
 1017c7a:	cmpl   $0x0,0x8(%r11)
 1017c7f:	je     1017d0d <rc_list_next+0xed>
 1017c85:	lea    0x1(%r10),%rdi
 1017c89:	mov    %rdi,(%rcx)
 1017c8c:	mov    0x18(%rsi),%rcx
 1017c90:	imul   (%rcx),%r10
 1017c94:	mov    0x20(%rdx),%rcx
 1017c98:	add    %r10,%rcx
 1017c9b:	mov    -0x10(%rdx),%rdi
 1017c9f:	mov    %rdi,%rbx
 1017ca2:	shr    $0x28,%rbx
 1017ca6:	and    $0xfffff,%ebx
 1017cac:	xor    %r14d,%r14d
 1017caf:	bt     $0x3e,%rdi
 1017cb4:	cmovae %r14d,%ebx
 1017cb8:	mov    %r11,(%r8)
 1017cbb:	mov    %rcx,0x8(%r8)
 1017cbf:	mov    %rdx,0x10(%r8)
 1017cc3:	mov    %ebx,0x18(%r8)
 1017cc7:	movl   $0x0,0x1c(%r8)
 1017ccf:	mov    0x8(%rax),%rax
 1017cd3:	add    0x20(%rsi),%r10
 1017cd7:	mov    -0x10(%rsi),%rcx
 1017cdb:	mov    %rcx,%rdx
 1017cde:	shr    $0x28,%rdx
 1017ce2:	and    $0xfffff,%edx
 1017ce8:	bt     $0x3e,%rcx
 1017ced:	cmovae %r14d,%edx
 1017cf1:	mov    %rax,(%r9)
 1017cf4:	mov    %r10,0x8(%r9)
 1017cf8:	mov    %rsi,0x10(%r9)
 1017cfc:	mov    %edx,0x18(%r9)
 1017d00:	movl   $0x0,0x1c(%r9)
 1017d08:	mov    $0x1,%edi
 1017d0d:	mov    %edi,%eax
 1017d0f:	pop    %rbx
 1017d10:	pop    %r14
 1017d12:	pop    %rbp
 1017d13:	ret
 1017d14:	mov    %rsi,%r10
 1017d17:	mov    %rax,%rsi
 1017d1a:	call   1018df4 <myl_rc_binding_find_slow>
 1017d1f:	mov    %r10,%rsi
 1017d22:	test   %rax,%rax
 1017d25:	jne    1017c68 <rc_list_next+0x48>
 1017d2b:	call   1027690 <abort@plt>

0000000001017d30 <rc_list_span>:
 1017d30:	push   %rbp
 1017d31:	mov    %rsp,%rbp
 1017d34:	push   %r15
 1017d36:	push   %r14
 1017d38:	push   %rbx
 1017d39:	push   %rax
 1017d3a:	mov    %rcx,%rbx
 1017d3d:	mov    %rsi,%r14
 1017d40:	mov    (%rcx),%r15
 1017d43:	call   1017c20 <rc_list_next>
 1017d48:	test   %eax,%eax
 1017d4a:	je     1017d66 <rc_list_span+0x36>
 1017d4c:	mov    0x10(%rbp),%rax
 1017d50:	mov    (%r14),%rcx
 1017d53:	sub    %r15,%rcx
 1017d56:	mov    %rcx,(%rax)
 1017d59:	mov    (%r14),%rax
 1017d5c:	mov    %rax,(%rbx)
 1017d5f:	mov    $0x1,%eax
 1017d64:	jmp    1017d68 <rc_list_span+0x38>
 1017d66:	xor    %eax,%eax
 1017d68:	add    $0x8,%rsp
 1017d6c:	pop    %rbx
 1017d6d:	pop    %r14
 1017d6f:	pop    %r15
 1017d71:	pop    %rbp
 1017d72:	ret
 1017d73:	int3
 1017d74:	int3
 1017d75:	int3
 1017d76:	int3
 1017d77:	int3
 1017d78:	int3
 1017d79:	int3
 1017d7a:	int3
 1017d7b:	int3
 1017d7c:	int3
 1017d7d:	int3
 1017d7e:	int3
 1017d7f:	int3

0000000001017d80 <rc_storage_edges>:
 1017d80:	push   %rbp
 1017d81:	mov    %rsp,%rbp
 1017d84:	mov    0x20(%rsi),%rsi
 1017d88:	pop    %rbp
 1017d89:	jmp    1018bc0 <myl_rc_edge_release>
 1017d8e:	int3
 1017d8f:	int3

0000000001017d90 <rc_list_insert_at>:
 1017d90:	push   %rbp
 1017d91:	mov    %rsp,%rbp
 1017d94:	push   %r15
 1017d96:	push   %r14
 1017d98:	push   %r13
 1017d9a:	push   %r12
 1017d9c:	push   %rbx
 1017d9d:	sub    $0xa8,%rsp
 1017da4:	xor    %r12d,%r12d
 1017da7:	cmpq   $0xffffffffffffffff,0x10(%rsi)
 1017dac:	je     1018106 <rc_list_insert_at+0x376>
 1017db2:	mov    %rsi,%r14
 1017db5:	mov    (%rsi),%r15
 1017db8:	cmp    $0xffffffffffffffff,%r15
 1017dbc:	je     1018106 <rc_list_insert_at+0x376>
 1017dc2:	mov    0x18(%r14),%rax
 1017dc6:	mov    (%rax),%rsi
 1017dc9:	cmp    %r15,%rdx
 1017dcc:	mov    %rdx,-0x50(%rbp)
 1017dd0:	mov    %rdi,-0x38(%rbp)
 1017dd4:	jne    1017df0 <rc_list_insert_at+0x60>
 1017dd6:	test   %rsi,%rsi
 1017dd9:	je     1017e37 <rc_list_insert_at+0xa7>
 1017ddb:	mov    0x1608(%rdi),%rax
 1017de2:	cmpq   $0x0,0xc8(%rax)
 1017dea:	je     1017fa5 <rc_list_insert_at+0x215>
 1017df0:	cmp    $0x81,%rsi
 1017df7:	jae    1017e06 <rc_list_insert_at+0x76>
 1017df9:	lea    -0xd0(%rbp),%rax
 1017e00:	mov    %rax,-0x40(%rbp)
 1017e04:	jmp    1017e47 <rc_list_insert_at+0xb7>
 1017e06:	mov    %rcx,%rbx
 1017e09:	xor    %r12d,%r12d
 1017e0c:	mov    %rsi,%r13
 1017e0f:	xor    %edx,%edx
 1017e11:	mov    $0x1,%ecx
 1017e16:	call   1022df0 <raw_bytes>
 1017e1b:	test   %rax,%rax
 1017e1e:	je     1018106 <rc_list_insert_at+0x376>
 1017e24:	mov    %rax,-0x40(%rbp)
 1017e28:	mov    (%r14),%r15
 1017e2b:	mov    %rbx,%rcx
 1017e2e:	mov    -0x38(%rbp),%rdi
 1017e32:	mov    %r13,%rsi
 1017e35:	jmp    1017e47 <rc_list_insert_at+0xb7>
 1017e37:	lea    -0xd0(%rbp),%rax
 1017e3e:	mov    %rax,-0x40(%rbp)
 1017e42:	xor    %esi,%esi
 1017e44:	mov    %rdx,%r15
 1017e47:	mov    %rsi,-0x30(%rbp)
 1017e4b:	mov    -0x10(%r14),%rax
 1017e4f:	mov    0x20(%r14),%rdx
 1017e53:	mov    %rax,%rbx
 1017e56:	shr    $0x28,%rbx
 1017e5a:	and    $0xfffff,%ebx
 1017e60:	xor    %r12d,%r12d
 1017e63:	bt     $0x3e,%rax
 1017e68:	cmovae %r12d,%ebx
 1017e6c:	test   %rdx,%rdx
 1017e6f:	sete   %al
 1017e72:	mov    %rcx,-0x48(%rbp)
 1017e76:	mov    %rcx,%r13
 1017e79:	sub    %rdx,%r13
 1017e7c:	setb   %cl
 1017e7f:	or     %al,%cl
 1017e81:	je     1017e9a <rc_list_insert_at+0x10a>
 1017e83:	inc    %r15
 1017e86:	mov    %r14,%rsi
 1017e89:	mov    %r15,%rdx
 1017e8c:	call   1018130 <myl_rc_list_storage_reserve>
 1017e91:	test   %eax,%eax
 1017e93:	jne    1017ec0 <rc_list_insert_at+0x130>
 1017e95:	jmp    1017f4e <rc_list_insert_at+0x1be>
 1017e9a:	lea    0x1(%r15),%rdx
 1017e9e:	mov    %r14,%rsi
 1017ea1:	call   1018130 <myl_rc_list_storage_reserve>
 1017ea6:	test   %eax,%eax
 1017ea8:	je     1017f4e <rc_list_insert_at+0x1be>
 1017eae:	imul   -0x30(%rbp),%r15
 1017eb3:	cmp    %r15,%r13
 1017eb6:	jae    1017ec0 <rc_list_insert_at+0x130>
 1017eb8:	add    0x20(%r14),%r13
 1017ebc:	mov    %r13,-0x48(%rbp)
 1017ec0:	mov    0x18(%r14),%rsi
 1017ec4:	mov    -0x38(%rbp),%rdi
 1017ec8:	mov    -0x40(%rbp),%r15
 1017ecc:	mov    %r15,%rdx
 1017ecf:	mov    -0x48(%rbp),%rcx
 1017ed3:	mov    %ebx,%r8d
 1017ed6:	call   1023970 <myl_rc_native_retain>
 1017edb:	test   %eax,%eax
 1017edd:	je     1017f3d <rc_list_insert_at+0x1ad>
 1017edf:	mov    (%r14),%rdx
 1017ee2:	mov    0x20(%r14),%rbx
 1017ee6:	mov    -0x50(%rbp),%rax
 1017eea:	sub    %rax,%rdx
 1017eed:	jbe    1017f15 <rc_list_insert_at+0x185>
 1017eef:	lea    0x1(%rax),%rdi
 1017ef3:	mov    -0x30(%rbp),%rcx
 1017ef7:	imul   %rcx,%rdi
 1017efb:	add    %rbx,%rdi
 1017efe:	mov    %rcx,%rsi
 1017f01:	imul   %rax,%rsi
 1017f05:	add    %rbx,%rsi
 1017f08:	imul   %rcx,%rdx
 1017f0c:	call   1027700 <memmove@plt>
 1017f11:	mov    -0x50(%rbp),%rax
 1017f15:	mov    -0x30(%rbp),%rdx
 1017f19:	test   %rdx,%rdx
 1017f1c:	je     1017f30 <rc_list_insert_at+0x1a0>
 1017f1e:	imul   %rdx,%rax
 1017f22:	add    %rax,%rbx
 1017f25:	mov    %rbx,%rdi
 1017f28:	mov    %r15,%rsi
 1017f2b:	call   1027520 <memcpy@plt>
 1017f30:	incq   (%r14)
 1017f33:	incq   0x10(%r14)
 1017f37:	mov    $0x1,%r12d
 1017f3d:	lea    -0xd0(%rbp),%rax
 1017f44:	cmp    %rax,%r15
 1017f47:	jne    1017f62 <rc_list_insert_at+0x1d2>
 1017f49:	jmp    1018106 <rc_list_insert_at+0x376>
 1017f4e:	mov    -0x40(%rbp),%r15
 1017f52:	lea    -0xd0(%rbp),%rax
 1017f59:	cmp    %rax,%r15
 1017f5c:	je     1018106 <rc_list_insert_at+0x376>
 1017f62:	mov    -0x38(%rbp),%rbx
 1017f66:	mov    %rbx,%rdi
 1017f69:	mov    %r15,%rsi
 1017f6c:	call   1018bc0 <myl_rc_edge_release>
 1017f71:	test   %rbx,%rbx
 1017f74:	je     1018106 <rc_list_insert_at+0x376>
 1017f7a:	mov    0x1608(%rbx),%rax
 1017f81:	test   %rax,%rax
 1017f84:	je     1018106 <rc_list_insert_at+0x376>
 1017f8a:	cmpq   $0x0,0xc8(%rax)
 1017f92:	je     1018106 <rc_list_insert_at+0x376>
 1017f98:	mov    %rbx,%rdi
 1017f9b:	call   101bcb0 <myl_rc_drain>
 1017fa0:	jmp    1018106 <rc_list_insert_at+0x376>
 1017fa5:	mov    0x20(%r14),%rax
 1017fa9:	mov    %rsi,%rbx
 1017fac:	imul   %rdx,%rbx
 1017fb0:	test   %rax,%rax
 1017fb3:	sete   %r8b
 1017fb7:	mov    %rcx,%r13
 1017fba:	sub    %rax,%r13
 1017fbd:	setb   %al
 1017fc0:	or     %r8b,%al
 1017fc3:	je     1017fee <rc_list_insert_at+0x25e>
 1017fc5:	mov    %rsi,%r13
 1017fc8:	mov    %rcx,%r15
 1017fcb:	inc    %rdx
 1017fce:	mov    %r14,%rsi
 1017fd1:	call   1018130 <myl_rc_list_storage_reserve>
 1017fd6:	test   %eax,%eax
 1017fd8:	je     1018106 <rc_list_insert_at+0x376>
 1017fde:	mov    0x20(%r14),%rdx
 1017fe2:	mov    %r15,%rcx
 1017fe5:	mov    -0x38(%rbp),%r9
 1017fe9:	mov    %r13,%r10
 1017fec:	jmp    1018043 <rc_list_insert_at+0x2b3>
 1017fee:	cmp    %rbx,%r13
 1017ff1:	setb   %r8b
 1017ff5:	jb     1018008 <rc_list_insert_at+0x278>
 1017ff7:	mov    0x8(%r14),%rax
 1017ffb:	imul   %rsi,%rax
 1017fff:	cmp    %rax,%r13
 1018002:	jb     1017df0 <rc_list_insert_at+0x60>
 1018008:	mov    %r8d,%r15d
 101800b:	mov    %rsi,-0x30(%rbp)
 101800f:	mov    %rcx,-0x48(%rbp)
 1018013:	inc    %rdx
 1018016:	mov    %r14,%rsi
 1018019:	call   1018130 <myl_rc_list_storage_reserve>
 101801e:	test   %eax,%eax
 1018020:	je     1018106 <rc_list_insert_at+0x376>
 1018026:	mov    0x20(%r14),%rdx
 101802a:	test   %r15b,%r15b
 101802d:	je     1018037 <rc_list_insert_at+0x2a7>
 101802f:	add    %rdx,%r13
 1018032:	mov    %r13,%rcx
 1018035:	jmp    101803b <rc_list_insert_at+0x2ab>
 1018037:	mov    -0x48(%rbp),%rcx
 101803b:	mov    -0x38(%rbp),%r9
 101803f:	mov    -0x30(%rbp),%r10
 1018043:	add    %rbx,%rdx
 1018046:	lea    (%rcx,%r10,1),%rax
 101804a:	cmp    %rdx,%rax
 101804d:	jbe    101805c <rc_list_insert_at+0x2cc>
 101804f:	lea    (%r10,%rdx,1),%rax
 1018053:	cmp    %rcx,%rax
 1018056:	ja     101812b <rc_list_insert_at+0x39b>
 101805c:	mov    0x18(%r14),%rsi
 1018060:	mov    0x1608(%r9),%rdi
 1018067:	cmp    %rsi,0x110(%rdi)
 101806e:	je     10180eb <rc_list_insert_at+0x35b>
 1018070:	mov    0x34(%rsi),%eax
 1018073:	cmp    %rax,0xa0(%rdi)
 101807a:	jbe    101811b <rc_list_insert_at+0x38b>
 1018080:	mov    0x98(%rdi),%r8
 1018087:	shl    $0x4,%rax
 101808b:	cmp    %rsi,(%r8,%rax,1)
 101808f:	jne    101811b <rc_list_insert_at+0x38b>
 1018095:	add    %rax,%r8
 1018098:	mov    0x8(%r8),%rax
 101809c:	test   %rax,%rax
 101809f:	je     10180ad <rc_list_insert_at+0x31d>
 10180a1:	cmpl   $0x0,0x40(%rax)
 10180a5:	jne    10180ad <rc_list_insert_at+0x31d>
 10180a7:	cmpb   $0x0,0x45(%rax)
 10180ab:	je     10180dd <rc_list_insert_at+0x34d>
 10180ad:	mov    -0x10(%r14),%rax
 10180b1:	mov    0x18(%r14),%rsi
 10180b5:	mov    %rax,%r8
 10180b8:	shr    $0x28,%r8
 10180bc:	and    $0xfffff,%r8d
 10180c3:	xor    %r12d,%r12d
 10180c6:	bt     $0x3e,%rax
 10180cb:	cmovae %r12d,%r8d
 10180cf:	mov    %r9,%rdi
 10180d2:	call   1023970 <myl_rc_native_retain>
 10180d7:	test   %eax,%eax
 10180d9:	jne    10180f9 <rc_list_insert_at+0x369>
 10180db:	jmp    1018106 <rc_list_insert_at+0x376>
 10180dd:	mov    0x1608(%r9),%rax
 10180e4:	mov    %rsi,0x110(%rax)
 10180eb:	mov    %rdx,%rdi
 10180ee:	mov    %rcx,%rsi
 10180f1:	mov    %r10,%rdx
 10180f4:	call   1027520 <memcpy@plt>
 10180f9:	incq   (%r14)
 10180fc:	incq   0x10(%r14)
 1018100:	mov    $0x1,%r12d
 1018106:	mov    %r12d,%eax
 1018109:	add    $0xa8,%rsp
 1018110:	pop    %rbx
 1018111:	pop    %r12
 1018113:	pop    %r13
 1018115:	pop    %r14
 1018117:	pop    %r15
 1018119:	pop    %rbp
 101811a:	ret
 101811b:	call   1018df4 <myl_rc_binding_find_slow>
 1018120:	test   %rax,%rax
 1018123:	jne    10180a1 <rc_list_insert_at+0x311>
 1018129:	jmp    10180ad <rc_list_insert_at+0x31d>
 101812b:	call   10187d4 <myl_rc_invariant_failed>

0000000001018130 <myl_rc_list_storage_reserve>:
 1018130:	mov    0x8(%rsi),%rcx
 1018134:	mov    $0x1,%eax
 1018139:	cmp    %rcx,%rdx
 101813c:	jbe    10182b5 <myl_rc_list_storage_reserve+0x185>
 1018142:	push   %rbp
 1018143:	mov    %rsp,%rbp
 1018146:	push   %r15
 1018148:	push   %r14
 101814a:	push   %r13
 101814c:	push   %r12
 101814e:	push   %rbx
 101814f:	push   %rax
 1018150:	mov    %rsi,%rbx
 1018153:	cmp    $0x5,%rcx
 1018157:	mov    $0x4,%r13d
 101815d:	cmovae %rcx,%r13
 1018161:	cmp    $0x5,%rdx
 1018165:	jb     101817d <myl_rc_list_storage_reserve+0x4d>
 1018167:	nopw   0x0(%rax,%rax,1)
 1018170:	test   %r13,%r13
 1018173:	js     1018191 <myl_rc_list_storage_reserve+0x61>
 1018175:	add    %r13,%r13
 1018178:	cmp    %rdx,%r13
 101817b:	jb     1018170 <myl_rc_list_storage_reserve+0x40>
 101817d:	mov    0x18(%rbx),%rsi
 1018181:	mov    (%rsi),%rcx
 1018184:	test   %rcx,%rcx
 1018187:	je     1018198 <myl_rc_list_storage_reserve+0x68>
 1018189:	mov    %rcx,%rax
 101818c:	mul    %r13
 101818f:	jno    1018198 <myl_rc_list_storage_reserve+0x68>
 1018191:	xor    %eax,%eax
 1018193:	jmp    10182a7 <myl_rc_list_storage_reserve+0x177>
 1018198:	mov    0x20(%rbx),%r14
 101819c:	mov    0x1608(%rdi),%rax
 10181a3:	cmp    %rsi,0x110(%rax)
 10181aa:	je     101827e <myl_rc_list_storage_reserve+0x14e>
 10181b0:	mov    0x34(%rsi),%ecx
 10181b3:	cmp    %rcx,0xa0(%rax)
 10181ba:	jbe    1018346 <myl_rc_list_storage_reserve+0x216>
 10181c0:	mov    0x98(%rax),%rdx
 10181c7:	shl    $0x4,%rcx
 10181cb:	cmp    %rsi,(%rdx,%rcx,1)
 10181cf:	jne    1018346 <myl_rc_list_storage_reserve+0x216>
 10181d5:	add    %rcx,%rdx
 10181d8:	mov    0x8(%rdx),%rax
 10181dc:	test   %rax,%rax
 10181df:	je     10181ed <myl_rc_list_storage_reserve+0xbd>
 10181e1:	cmpl   $0x0,0x40(%rax)
 10181e5:	jne    10181ed <myl_rc_list_storage_reserve+0xbd>
 10181e7:	cmpb   $0x0,0x45(%rax)
 10181eb:	je     1018269 <myl_rc_list_storage_reserve+0x139>
 10181ed:	mov    0x18(%rbx),%rax
 10181f1:	mov    (%rax),%rdx
 10181f4:	imul   %r13,%rdx
 10181f8:	mov    %rdi,%r15
 10181fb:	mov    %r14,%rsi
 10181fe:	mov    $0x1,%ecx
 1018203:	call   1023040 <storage_extend>
 1018208:	test   %rax,%rax
 101820b:	jne    101829a <myl_rc_list_storage_reserve+0x16a>
 1018211:	mov    -0x10(%rbx),%rax
 1018215:	mov    0x18(%rbx),%rdx
 1018219:	mov    %rax,%rcx
 101821c:	shr    $0x28,%rcx
 1018220:	and    $0xfffff,%ecx
 1018226:	xor    %esi,%esi
 1018228:	bt     $0x3e,%rax
 101822d:	cmovae %esi,%ecx
 1018230:	mov    (%rdx),%rsi
 1018233:	test   %rsi,%rsi
 1018236:	je     1018245 <myl_rc_list_storage_reserve+0x115>
 1018238:	mov    %rsi,%rax
 101823b:	mul    %r13
 101823e:	mov    $0x0,%eax
 1018243:	jo     10182a7 <myl_rc_list_storage_reserve+0x177>
 1018245:	imul   %r13,%rsi
 1018249:	mov    %r15,%rdi
 101824c:	mov    %ecx,%edx
 101824e:	mov    $0x1,%ecx
 1018253:	call   1022df0 <raw_bytes>
 1018258:	mov    %rax,%r12
 101825b:	test   %rax,%rax
 101825e:	jne    10182f1 <myl_rc_list_storage_reserve+0x1c1>
 1018264:	jmp    1018191 <myl_rc_list_storage_reserve+0x61>
 1018269:	mov    0x1608(%rdi),%rax
 1018270:	mov    %rsi,0x110(%rax)
 1018277:	mov    0x18(%rbx),%rax
 101827b:	mov    (%rax),%rcx
 101827e:	imul   %r13,%rcx
 1018282:	xor    %r12d,%r12d
 1018285:	mov    %rdi,%r15
 1018288:	mov    %r14,%rsi
 101828b:	mov    %rcx,%rdx
 101828e:	xor    %ecx,%ecx
 1018290:	call   1023040 <storage_extend>
 1018295:	test   %rax,%rax
 1018298:	je     10182b6 <myl_rc_list_storage_reserve+0x186>
 101829a:	mov    %rax,0x20(%rbx)
 101829e:	mov    %r13,0x8(%rbx)
 10182a2:	mov    $0x1,%eax
 10182a7:	add    $0x8,%rsp
 10182ab:	pop    %rbx
 10182ac:	pop    %r12
 10182ae:	pop    %r13
 10182b0:	pop    %r14
 10182b2:	pop    %r15
 10182b4:	pop    %rbp
 10182b5:	ret
 10182b6:	mov    -0x10(%rbx),%rax
 10182ba:	mov    0x18(%rbx),%rcx
 10182be:	mov    (%rcx),%rsi
 10182c1:	imul   %r13,%rsi
 10182c5:	mov    %rax,%rdx
 10182c8:	shr    $0x28,%rdx
 10182cc:	and    $0xfffff,%edx
 10182d2:	bt     $0x3e,%rax
 10182d7:	cmovae %r12d,%edx
 10182db:	mov    %r15,%rdi
 10182de:	xor    %ecx,%ecx
 10182e0:	call   1022df0 <raw_bytes>
 10182e5:	mov    %rax,%r12
 10182e8:	test   %rax,%rax
 10182eb:	je     1018191 <myl_rc_list_storage_reserve+0x61>
 10182f1:	mov    (%rbx),%rdx
 10182f4:	test   %rdx,%rdx
 10182f7:	je     101830c <myl_rc_list_storage_reserve+0x1dc>
 10182f9:	mov    0x18(%rbx),%rax
 10182fd:	imul   (%rax),%rdx
 1018301:	mov    %r12,%rdi
 1018304:	mov    %r14,%rsi
 1018307:	call   1027520 <memcpy@plt>
 101830c:	mov    %r12,0x20(%rbx)
 1018310:	mov    %r15,%rdi
 1018313:	mov    %r14,%rsi
 1018316:	call   1018bc0 <myl_rc_edge_release>
 101831b:	mov    0x1608(%r15),%rax
 1018322:	test   %rax,%rax
 1018325:	je     101829e <myl_rc_list_storage_reserve+0x16e>
 101832b:	cmpq   $0x0,0xc8(%rax)
 1018333:	je     101829e <myl_rc_list_storage_reserve+0x16e>
 1018339:	mov    %r15,%rdi
 101833c:	call   101bcb0 <myl_rc_drain>
 1018341:	jmp    101829e <myl_rc_list_storage_reserve+0x16e>
 1018346:	mov    %rdi,%rcx
 1018349:	mov    %rax,%rdi
 101834c:	call   1018df4 <myl_rc_binding_find_slow>
 1018351:	mov    %rcx,%rdi
 1018354:	test   %rax,%rax
 1018357:	jne    10181e1 <myl_rc_list_storage_reserve+0xb1>
 101835d:	jmp    10181ed <myl_rc_list_storage_reserve+0xbd>
 1018362:	int3
 1018363:	int3
 1018364:	int3
 1018365:	int3
 1018366:	int3
 1018367:	int3
 1018368:	int3
 1018369:	int3
 101836a:	int3
 101836b:	int3
 101836c:	int3
 101836d:	int3
 101836e:	int3
 101836f:	int3

0000000001018370 <myl_qbe_on_stack>:
 1018370:	push   %rbp
 1018371:	mov    %rsp,%rbp
 1018374:	push   %r15
 1018376:	push   %r14
 1018378:	push   %r13
 101837a:	push   %r12
 101837c:	push   %rbx
 101837d:	sub    $0x878,%rsp
 1018384:	mov    %rdi,%rbx
 1018387:	mov    $0x1e,%edi
 101838c:	call   1027710 <sysconf@plt>
 1018391:	test   %rax,%rax
 1018394:	jle    10185c1 <myl_qbe_on_stack+0x251>
 101839a:	mov    %rax,%rcx
 101839d:	shr    $0x3e,%rcx
 10183a1:	jne    10183be <myl_qbe_on_stack+0x4e>
 10183a3:	lea    (%rax,%rax,1),%r14
 10183a7:	mov    0x18(%rbx),%rcx
 10183ab:	mov    $0xffffffffff7ffffe,%rdx
 10183b2:	sub    %r14,%rdx
 10183b5:	shr    $0xf,%rdx
 10183b9:	cmp    %rdx,%rcx
 10183bc:	jbe    10183e1 <myl_qbe_on_stack+0x71>
 10183be:	mov    $0xffffffffffffffff,%rsi
 10183c5:	mov    %rbx,%rdi
 10183c8:	call   10185f0 <stack_refused>
 10183cd:	xor    %eax,%eax
 10183cf:	add    $0x878,%rsp
 10183d6:	pop    %rbx
 10183d7:	pop    %r12
 10183d9:	pop    %r13
 10183db:	pop    %r14
 10183dd:	pop    %r15
 10183df:	pop    %rbp
 10183e0:	ret
 10183e1:	shl    $0xf,%rcx
 10183e5:	mov    %rcx,%rdx
 10183e8:	add    $0x800000,%rdx
 10183ef:	mov    %rax,%rcx
 10183f2:	neg    %rcx
 10183f5:	cmp    %rcx,%rdx
 10183f8:	ja     10185c1 <myl_qbe_on_stack+0x251>
 10183fe:	mov    %r14,%rcx
 1018401:	not    %rcx
 1018404:	lea    (%rdx,%rax,1),%r12
 1018408:	dec    %r12
 101840b:	mov    %r12,%rdx
 101840e:	or     %rax,%rdx
 1018411:	shr    $0x20,%rdx
 1018415:	je     10185a7 <myl_qbe_on_stack+0x237>
 101841b:	mov    %rax,%rsi
 101841e:	mov    %rax,%r13
 1018421:	xor    %eax,%eax
 1018423:	mov    %eax,%edx
 1018425:	mov    %r12,%rax
 1018428:	div    %rsi
 101842b:	mov    %rdx,%rax
 101842e:	sub    %rax,%r12
 1018431:	cmp    %rcx,%r12
 1018434:	ja     10185c1 <myl_qbe_on_stack+0x251>
 101843a:	add    %r12,%r14
 101843d:	xor    %eax,%eax
 101843f:	mov    %eax,%edi
 1018441:	mov    %r14,%rsi
 1018444:	xor    %edx,%edx
 1018446:	mov    $0x20022,%ecx
 101844b:	mov    $0xffffffff,%r8d
 1018451:	mov    %rdi,%r9
 1018454:	call   1027720 <mmap@plt>
 1018459:	cmp    $0xffffffffffffffff,%rax
 101845d:	je     10185d3 <myl_qbe_on_stack+0x263>
 1018463:	mov    %rax,%r15
 1018466:	add    %rax,%r13
 1018469:	vxorps %xmm0,%xmm0,%xmm0
 101846d:	vmovups %ymm0,-0x48(%rbp)
 1018472:	vmovups %ymm0,-0x58(%rbp)
 1018477:	vmovups %ymm0,-0x78(%rbp)
 101847c:	vmovups %ymm0,-0x98(%rbp)
 1018484:	vmovups %ymm0,-0xb8(%rbp)
 101848c:	vmovups %ymm0,-0xd8(%rbp)
 1018494:	vmovups %ymm0,-0xf8(%rbp)
 101849c:	movq   $0x1012650,-0x108(%rbp)
 10184a7:	mov    %rbx,-0x100(%rbp)
 10184ae:	mov    %r13,%rdi
 10184b1:	mov    %r12,%rsi
 10184b4:	mov    $0x3,%edx
 10184b9:	vzeroupper
 10184bc:	call   1027730 <mprotect@plt>
 10184c1:	test   %eax,%eax
 10184c3:	jne    10185de <myl_qbe_on_stack+0x26e>
 10184c9:	lea    -0x4d0(%rbp),%rdi
 10184d0:	call   1027740 <getcontext@plt>
 10184d5:	test   %eax,%eax
 10184d7:	jne    10185de <myl_qbe_on_stack+0x26e>
 10184dd:	lea    -0x800000(%r12),%rax
 10184e5:	mov    %rax,0x39b8(%rbx)
 10184ec:	mov    %r13,0x39c0(%rbx)
 10184f3:	lea    (%r12,%r13,1),%rax
 10184f7:	mov    %rax,0x3e68(%rbx)
 10184fe:	lea    0x10000(%r13),%rax
 1018505:	mov    %rax,0x40(%rbx)
 1018509:	mov    %r13,-0x4c0(%rbp)
 1018510:	mov    %r12,-0x4b0(%rbp)
 1018517:	movl   $0x0,-0x4b8(%rbp)
 1018521:	lea    -0x898(%rbp),%r12
 1018528:	mov    %r12,-0x4c8(%rbp)
 101852f:	lea    -0x108(%rbp),%rax
 1018536:	mov    %rax,%rdx
 1018539:	mov    %eax,%ecx
 101853b:	shr    $0x20,%rdx
 101853f:	mov    %edx,%r8d
 1018542:	mov    $0x1018760,%esi
 1018547:	xor    %eax,%eax
 1018549:	lea    -0x4d0(%rbp),%r13
 1018550:	mov    %r13,%rdi
 1018553:	mov    $0x2,%edx
 1018558:	call   1027750 <makecontext@plt>
 101855d:	mov    %r12,%rdi
 1018560:	mov    %r13,%rsi
 1018563:	call   1027760 <swapcontext@plt>
 1018568:	test   %eax,%eax
 101856a:	jne    10185de <myl_qbe_on_stack+0x26e>
 101856c:	mov    -0xf8(%rbp),%rax
 1018573:	mov    %rax,%r12
 1018576:	movq   $0x0,0x39c0(%rbx)
 1018581:	movq   $0x0,0x3e68(%rbx)
 101858c:	movq   $0x0,0x40(%rbx)
 1018594:	mov    %r15,%rdi
 1018597:	mov    %r14,%rsi
 101859a:	call   1027770 <munmap@plt>
 101859f:	mov    %r12,%rax
 10185a2:	jmp    10183cf <myl_qbe_on_stack+0x5f>
 10185a7:	mov    %rax,%r13
 10185aa:	mov    %eax,%esi
 10185ac:	mov    %r12d,%eax
 10185af:	xor    %edx,%edx
 10185b1:	div    %esi
 10185b3:	mov    %edx,%eax
 10185b5:	sub    %rax,%r12
 10185b8:	cmp    %rcx,%r12
 10185bb:	jbe    101843a <myl_qbe_on_stack+0xca>
 10185c1:	mov    $0x1003b92,%esi
 10185c6:	mov    %rbx,%rdi
 10185c9:	call   1014a6d <fail>
 10185ce:	jmp    10183cd <myl_qbe_on_stack+0x5d>
 10185d3:	mov    %rbx,%rdi
 10185d6:	mov    %r14,%rsi
 10185d9:	jmp    10183c8 <myl_qbe_on_stack+0x58>
 10185de:	mov    $0x1003b92,%esi
 10185e3:	mov    %rbx,%rdi
 10185e6:	call   1014a6d <fail>
 10185eb:	xor    %eax,%eax
 10185ed:	jmp    1018573 <myl_qbe_on_stack+0x203>
 10185ef:	int3

00000000010185f0 <stack_refused>:
 10185f0:	push   %rbp
 10185f1:	mov    %rsp,%rbp
 10185f4:	push   %r14
 10185f6:	push   %rbx
 10185f7:	sub    $0x80,%rsp
 10185fe:	mov    %rdi,%rbx
 1018601:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 1018606:	je     1018738 <stack_refused+0x148>
 101860c:	mov    %rsi,%r14
 101860f:	lea    -0x20(%rbp),%rsi
 1018613:	mov    $0x9,%edi
 1018618:	call   1027600 <getrlimit@plt>
 101861d:	test   %eax,%eax
 101861f:	jne    1018738 <stack_refused+0x148>
 1018625:	cmp    $0xffffffffffffffff,%r14
 1018629:	jne    1018697 <stack_refused+0xa7>
 101862b:	vmovupd -0x143c1(%rip),%ymm0        # 1004272 <qbe_empty_registry+0x71a>
 1018633:	vmovupd %ymm0,-0x50(%rbp)
 1018638:	movabs $0x64657373657264,%rax
 1018642:	mov    %rax,-0x30(%rbp)
 1018646:	mov    -0x20(%rbp),%rax
 101864a:	cmp    $0xffffffffffffffff,%rax
 101864e:	je     10186e0 <stack_refused+0xf0>
 1018654:	vmovq  %rax,%xmm0
 1018659:	vpunpckldq -0x16d91(%rip),%xmm0,%xmm0        # 10018d0 <__abi_tag+0x15d4>
 1018661:	vsubpd -0x16da9(%rip),%xmm0,%xmm0        # 10018c0 <__abi_tag+0x15c4>
 1018669:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 101866e:	vaddsd %xmm0,%xmm1,%xmm0
 1018672:	vmulsd -0x16c0a(%rip),%xmm0,%xmm0        # 1001a70 <__abi_tag+0x1774>
 101867a:	lea    -0x90(%rbp),%rdi
 1018681:	mov    $0x40,%esi
 1018686:	mov    $0x1004495,%edx
 101868b:	mov    $0x1,%al
 101868d:	vzeroupper
 1018690:	call   1027660 <snprintf@plt>
 1018695:	jmp    1018700 <stack_refused+0x110>
 1018697:	vmovq  %r14,%xmm0
 101869c:	vpunpckldq -0x16dd4(%rip),%xmm0,%xmm0        # 10018d0 <__abi_tag+0x15d4>
 10186a4:	vsubpd -0x16dec(%rip),%xmm0,%xmm0        # 10018c0 <__abi_tag+0x15c4>
 10186ac:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 10186b1:	vaddsd %xmm0,%xmm1,%xmm0
 10186b5:	vmulsd -0x16c4d(%rip),%xmm0,%xmm0        # 1001a70 <__abi_tag+0x1774>
 10186bd:	lea    -0x50(%rbp),%rdi
 10186c1:	mov    $0x30,%esi
 10186c6:	mov    $0x1003f13,%edx
 10186cb:	mov    $0x1,%al
 10186cd:	call   1027660 <snprintf@plt>
 10186d2:	mov    -0x20(%rbp),%rax
 10186d6:	cmp    $0xffffffffffffffff,%rax
 10186da:	jne    1018654 <stack_refused+0x64>
 10186e0:	vmovups -0x1468f(%rip),%xmm0        # 1004059 <qbe_empty_registry+0x501>
 10186e8:	vmovups %xmm0,-0x81(%rbp)
 10186f0:	vmovupd -0x146ae(%rip),%xmm0        # 100404a <qbe_empty_registry+0x4f2>
 10186f8:	vmovapd %xmm0,-0x90(%rbp)
 1018700:	mov    0x10491(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1018707:	mov    (%rax),%rdi
 101870a:	mov    0x18(%rbx),%rdx
 101870e:	lea    -0x50(%rbp),%rcx
 1018712:	lea    -0x90(%rbp),%r9
 1018719:	mov    $0x100479e,%esi
 101871e:	mov    $0x20,%r8d
 1018724:	xor    %eax,%eax
 1018726:	vzeroupper
 1018729:	call   10275e0 <fprintf@plt>
 101872e:	movl   $0x1,0x39e0(%rbx)
 1018738:	mov    $0x1003b92,%esi
 101873d:	mov    %rbx,%rdi
 1018740:	call   1014a6d <fail>
 1018745:	add    $0x80,%rsp
 101874c:	pop    %rbx
 101874d:	pop    %r14
 101874f:	pop    %rbp
 1018750:	ret
 1018751:	int3
 1018752:	int3
 1018753:	int3
 1018754:	int3
 1018755:	int3
 1018756:	int3
 1018757:	int3
 1018758:	int3
 1018759:	int3
 101875a:	int3
 101875b:	int3
 101875c:	int3
 101875d:	int3
 101875e:	int3
 101875f:	int3

0000000001018760 <launch>:
 1018760:	push   %rbp
 1018761:	mov    %rsp,%rbp
 1018764:	sub    $0x10,%rsp
 1018768:	mov    %edi,%edi
 101876a:	mov    %edi,%eax
 101876c:	mov    %esi,%ecx
 101876e:	shl    $0x20,%rcx
 1018772:	or     %rax,%rcx
 1018775:	mov    %rcx,-0x8(%rbp)
 1018779:	mov    -0x8(%rbp),%rdi
 101877d:	add    $0x18,%rdi
 1018781:	call   1027780 <_setjmp@plt>
 1018786:	mov    -0x8(%rbp),%rcx
 101878a:	test   %eax,%eax
 101878c:	je     1018792 <launch+0x32>
 101878e:	xor    %eax,%eax
 1018790:	jmp    10187b7 <launch+0x57>
 1018792:	add    $0x18,%rcx
 1018796:	mov    -0x8(%rbp),%rax
 101879a:	mov    0x8(%rax),%rax
 101879e:	mov    %rcx,0x3e60(%rax)
 10187a5:	mov    -0x8(%rbp),%rax
 10187a9:	mov    -0x8(%rbp),%rcx
 10187ad:	mov    0x8(%rcx),%rdi
 10187b1:	call   *(%rax)
 10187b3:	mov    -0x8(%rbp),%rcx
 10187b7:	mov    %rax,0x10(%rcx)
 10187bb:	mov    -0x8(%rbp),%rax
 10187bf:	mov    0x8(%rax),%rax
 10187c3:	movq   $0x0,0x3e60(%rax)
 10187ce:	add    $0x10,%rsp
 10187d2:	pop    %rbp
 10187d3:	ret

00000000010187d4 <myl_rc_invariant_failed>:
 10187d4:	push   %rbp
 10187d5:	mov    %rsp,%rbp
 10187d8:	call   1027690 <abort@plt>
 10187dd:	int3
 10187de:	int3
 10187df:	int3

00000000010187e0 <myl_rc_meta_alloc>:
 10187e0:	push   %rbp
 10187e1:	mov    %rsp,%rbp
 10187e4:	push   %r15
 10187e6:	push   %r14
 10187e8:	push   %r12
 10187ea:	push   %rbx
 10187eb:	test   %rdi,%rdi
 10187ee:	je     1018851 <myl_rc_meta_alloc+0x71>
 10187f0:	test   %rsi,%rsi
 10187f3:	je     1018851 <myl_rc_meta_alloc+0x71>
 10187f5:	mov    0x1608(%rdi),%rbx
 10187fc:	test   %rbx,%rbx
 10187ff:	je     1018851 <myl_rc_meta_alloc+0x71>
 1018801:	mov    0x18(%rdi),%r14
 1018805:	add    %rsi,%r14
 1018808:	jb     1018820 <myl_rc_meta_alloc+0x40>
 101880a:	mov    0x58(%rdi),%rax
 101880e:	test   %rax,%rax
 1018811:	setne  %cl
 1018814:	cmp    %rax,%r14
 1018817:	seta   %al
 101881a:	and    %cl,%al
 101881c:	cmp    $0x1,%al
 101881e:	jne    1018832 <myl_rc_meta_alloc+0x52>
 1018820:	movl   $0x1,0x6c(%rdi)
 1018827:	xor    %eax,%eax
 1018829:	pop    %rbx
 101882a:	pop    %r12
 101882c:	pop    %r14
 101882e:	pop    %r15
 1018830:	pop    %rbp
 1018831:	ret
 1018832:	mov    %rdi,%r15
 1018835:	mov    $0x1,%edi
 101883a:	mov    %rsi,%r12
 101883d:	call   1027510 <calloc@plt>
 1018842:	test   %rax,%rax
 1018845:	je     1018827 <myl_rc_meta_alloc+0x47>
 1018847:	mov    %r14,0x18(%r15)
 101884b:	add    %r12,0x30(%rbx)
 101884f:	jmp    1018829 <myl_rc_meta_alloc+0x49>
 1018851:	call   10187d4 <myl_rc_invariant_failed>
 1018856:	int3
 1018857:	int3
 1018858:	int3
 1018859:	int3
 101885a:	int3
 101885b:	int3
 101885c:	int3
 101885d:	int3
 101885e:	int3
 101885f:	int3

0000000001018860 <myl_rc_meta_free>:
 1018860:	test   %rsi,%rsi
 1018863:	je     101888e <myl_rc_meta_free+0x2e>
 1018865:	mov    0x18(%rdi),%rax
 1018869:	sub    %rdx,%rax
 101886c:	jb     101888f <myl_rc_meta_free+0x2f>
 101886e:	mov    0x1608(%rdi),%rcx
 1018875:	mov    0x30(%rcx),%r8
 1018879:	sub    %rdx,%r8
 101887c:	jb     101888f <myl_rc_meta_free+0x2f>
 101887e:	mov    %rax,0x18(%rdi)
 1018882:	mov    %r8,0x30(%rcx)
 1018886:	mov    %rsi,%rdi
 1018889:	jmp    1027570 <free@plt>
 101888e:	ret
 101888f:	push   %rbp
 1018890:	mov    %rsp,%rbp
 1018893:	call   10187d4 <myl_rc_invariant_failed>
 1018898:	int3
 1018899:	int3
 101889a:	int3
 101889b:	int3
 101889c:	int3
 101889d:	int3
 101889e:	int3
 101889f:	int3

00000000010188a0 <myl_rc_heap_destroy>:
 10188a0:	push   %rbp
 10188a1:	mov    %rsp,%rbp
 10188a4:	push   %r15
 10188a6:	push   %r14
 10188a8:	push   %rbx
 10188a9:	push   %rax
 10188aa:	cmpq   $0x0,0x1608(%rdi)
 10188b2:	je     1018ba2 <myl_rc_heap_destroy+0x302>
 10188b8:	mov    %rdi,%rbx
 10188bb:	call   101bcb0 <myl_rc_drain>
 10188c0:	mov    0x1608(%rbx),%r14
 10188c7:	cmpq   $0x0,0xf8(%r14)
 10188cf:	jne    1018bad <myl_rc_heap_destroy+0x30d>
 10188d5:	cmpq   $0x0,0xc0(%r14)
 10188dd:	jne    1018bad <myl_rc_heap_destroy+0x30d>
 10188e3:	cmpl   $0x0,0xd0(%r14)
 10188eb:	jne    1018bad <myl_rc_heap_destroy+0x30d>
 10188f1:	mov    0x100(%r14),%rdi
 10188f8:	mov    %r14,%rcx
 10188fb:	test   %rdi,%rdi
 10188fe:	je     1018935 <myl_rc_heap_destroy+0x95>
 1018900:	lea    0x100(%r14),%rax
 1018907:	nopw   0x0(%rax,%rax,1)
 1018910:	mov    (%rdi),%rcx
 1018913:	mov    %rcx,(%rax)
 1018916:	call   1027570 <free@plt>
 101891b:	mov    0x1608(%rbx),%rcx
 1018922:	lea    0x100(%rcx),%rax
 1018929:	mov    0x100(%rcx),%rdi
 1018930:	test   %rdi,%rdi
 1018933:	jne    1018910 <myl_rc_heap_destroy+0x70>
 1018935:	movq   $0x0,0x108(%rcx)
 1018940:	mov    0x10(%r14),%rax
 1018944:	test   %rax,%rax
 1018947:	je     1018989 <myl_rc_heap_destroy+0xe9>
 1018949:	mov    %rbx,%rdi
 101894c:	call   *%rax
 101894e:	jmp    1018989 <myl_rc_heap_destroy+0xe9>
 1018950:	mov    (%rdi),%rax
 1018953:	mov    %rax,0x28(%r14)
 1018957:	mov    0x30(%rdi),%rcx
 101895b:	mov    0x18(%rbx),%rax
 101895f:	sub    %rcx,%rax
 1018962:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018968:	mov    0x1608(%rbx),%rdx
 101896f:	mov    0x30(%rdx),%rsi
 1018973:	sub    %rcx,%rsi
 1018976:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 101897c:	mov    %rax,0x18(%rbx)
 1018980:	mov    %rsi,0x30(%rdx)
 1018984:	call   1027570 <free@plt>
 1018989:	mov    0x28(%r14),%rdi
 101898d:	test   %rdi,%rdi
 1018990:	jne    1018950 <myl_rc_heap_destroy+0xb0>
 1018992:	mov    0xb0(%r14),%rdi
 1018999:	test   %rdi,%rdi
 101899c:	je     10189db <myl_rc_heap_destroy+0x13b>
 101899e:	mov    0xb8(%r14),%rax
 10189a5:	shl    $0x3,%rax
 10189a9:	lea    (%rax,%rax,2),%rcx
 10189ad:	mov    0x18(%rbx),%rax
 10189b1:	sub    %rcx,%rax
 10189b4:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 10189ba:	mov    0x1608(%rbx),%rdx
 10189c1:	mov    0x30(%rdx),%rsi
 10189c5:	sub    %rcx,%rsi
 10189c8:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 10189ce:	mov    %rax,0x18(%rbx)
 10189d2:	mov    %rsi,0x30(%rdx)
 10189d6:	call   1027570 <free@plt>
 10189db:	mov    0x1608(%rbx),%r15
 10189e2:	mov    0x38(%r15),%rdi
 10189e6:	cmp    $0x100b5f0,%rdi
 10189ed:	je     1018a2d <myl_rc_heap_destroy+0x18d>
 10189ef:	mov    0x40(%r15),%rax
 10189f3:	cmp    $0xffffffffffffffff,%rax
 10189f7:	je     1018a2d <myl_rc_heap_destroy+0x18d>
 10189f9:	test   %rdi,%rdi
 10189fc:	je     1018a2d <myl_rc_heap_destroy+0x18d>
 10189fe:	shl    $0x4,%rax
 1018a02:	add    $0x10,%rax
 1018a06:	mov    0x18(%rbx),%rcx
 1018a0a:	sub    %rax,%rcx
 1018a0d:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018a13:	mov    0x30(%r15),%rdx
 1018a17:	sub    %rax,%rdx
 1018a1a:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018a20:	mov    %rcx,0x18(%rbx)
 1018a24:	mov    %rdx,0x30(%r15)
 1018a28:	call   1027570 <free@plt>
 1018a2d:	movq   $0x100b5f0,0x38(%r15)
 1018a35:	vxorps %xmm0,%xmm0,%xmm0
 1018a39:	vmovups %xmm0,0x40(%r15)
 1018a3f:	movq   $0x3f,0x50(%r15)
 1018a47:	mov    0x1608(%rbx),%r15
 1018a4e:	mov    0x58(%r15),%rdi
 1018a52:	cmp    $0x100b5f0,%rdi
 1018a59:	je     1018a9d <myl_rc_heap_destroy+0x1fd>
 1018a5b:	mov    0x60(%r15),%rax
 1018a5f:	cmp    $0xffffffffffffffff,%rax
 1018a63:	je     1018a9d <myl_rc_heap_destroy+0x1fd>
 1018a65:	test   %rdi,%rdi
 1018a68:	je     1018a9d <myl_rc_heap_destroy+0x1fd>
 1018a6a:	shl    $0x4,%rax
 1018a6e:	add    $0x10,%rax
 1018a72:	mov    0x18(%rbx),%rcx
 1018a76:	sub    %rax,%rcx
 1018a79:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018a7f:	mov    0x30(%r15),%rdx
 1018a83:	sub    %rax,%rdx
 1018a86:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018a8c:	mov    %rcx,0x18(%rbx)
 1018a90:	mov    %rdx,0x30(%r15)
 1018a94:	call   1027570 <free@plt>
 1018a99:	vxorps %xmm0,%xmm0,%xmm0
 1018a9d:	movq   $0x100b5f0,0x58(%r15)
 1018aa5:	vmovups %xmm0,0x60(%r15)
 1018aab:	movq   $0x3f,0x70(%r15)
 1018ab3:	mov    0x1608(%rbx),%r15
 1018aba:	mov    0x78(%r15),%rdi
 1018abe:	cmp    $0x100b5f0,%rdi
 1018ac5:	je     1018b08 <myl_rc_heap_destroy+0x268>
 1018ac7:	mov    0x80(%r15),%rax
 1018ace:	cmp    $0xffffffffffffffff,%rax
 1018ad2:	je     1018b08 <myl_rc_heap_destroy+0x268>
 1018ad4:	test   %rdi,%rdi
 1018ad7:	je     1018b08 <myl_rc_heap_destroy+0x268>
 1018ad9:	shl    $0x4,%rax
 1018add:	add    $0x10,%rax
 1018ae1:	mov    0x18(%rbx),%rcx
 1018ae5:	sub    %rax,%rcx
 1018ae8:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018aee:	mov    0x30(%r15),%rdx
 1018af2:	sub    %rax,%rdx
 1018af5:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018afb:	mov    %rcx,0x18(%rbx)
 1018aff:	mov    %rdx,0x30(%r15)
 1018b03:	call   1027570 <free@plt>
 1018b08:	movq   $0x100b5f0,0x78(%r15)
 1018b10:	vxorps %xmm0,%xmm0,%xmm0
 1018b14:	vmovups %xmm0,0x80(%r15)
 1018b1d:	movq   $0x3f,0x90(%r15)
 1018b28:	mov    0x1608(%rbx),%r15
 1018b2f:	mov    0x98(%r15),%rdi
 1018b36:	test   %rdi,%rdi
 1018b39:	je     1018b69 <myl_rc_heap_destroy+0x2c9>
 1018b3b:	mov    0xa0(%r15),%rcx
 1018b42:	shl    $0x4,%rcx
 1018b46:	mov    0x18(%rbx),%rax
 1018b4a:	sub    %rcx,%rax
 1018b4d:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018b4f:	mov    0x30(%r15),%rdx
 1018b53:	sub    %rcx,%rdx
 1018b56:	jb     1018bad <myl_rc_heap_destroy+0x30d>
 1018b58:	mov    %rax,0x18(%rbx)
 1018b5c:	mov    %rdx,0x30(%r15)
 1018b60:	call   1027570 <free@plt>
 1018b65:	vxorps %xmm0,%xmm0,%xmm0
 1018b69:	add    $0x98,%r15
 1018b70:	vmovups %xmm0,(%r15)
 1018b75:	movq   $0x0,0x10(%r15)
 1018b7d:	cmpq   $0x128,0x30(%r14)
 1018b85:	jne    1018bad <myl_rc_heap_destroy+0x30d>
 1018b87:	addq   $0xfffffffffffffed8,0x18(%rbx)
 1018b8f:	mov    %r14,%rdi
 1018b92:	call   1027570 <free@plt>
 1018b97:	movq   $0x0,0x1608(%rbx)
 1018ba2:	add    $0x8,%rsp
 1018ba6:	pop    %rbx
 1018ba7:	pop    %r14
 1018ba9:	pop    %r15
 1018bab:	pop    %rbp
 1018bac:	ret
 1018bad:	call   10187d4 <myl_rc_invariant_failed>
 1018bb2:	int3
 1018bb3:	int3
 1018bb4:	int3
 1018bb5:	int3
 1018bb6:	int3
 1018bb7:	int3
 1018bb8:	int3
 1018bb9:	int3
 1018bba:	int3
 1018bbb:	int3
 1018bbc:	int3
 1018bbd:	int3
 1018bbe:	int3
 1018bbf:	int3

0000000001018bc0 <myl_rc_edge_release>:
 1018bc0:	push   %rbp
 1018bc1:	mov    %rsp,%rbp
 1018bc4:	test   %rsi,%rsi
 1018bc7:	je     1018bdc <myl_rc_edge_release+0x1c>
 1018bc9:	movabs $0x4000000000000002,%rdx
 1018bd3:	mov    -0x10(%rsi),%r9
 1018bd7:	test   %rdx,%r9
 1018bda:	je     1018bde <myl_rc_edge_release+0x1e>
 1018bdc:	pop    %rbp
 1018bdd:	ret
 1018bde:	test   %rdi,%rdi
 1018be1:	je     1018cd1 <myl_rc_edge_release+0x111>
 1018be7:	cmpq   $0x0,0x1608(%rdi)
 1018bef:	je     1018cd1 <myl_rc_edge_release+0x111>
 1018bf5:	test   $0x1,%r9b
 1018bf9:	jne    1018cd1 <myl_rc_edge_release+0x111>
 1018bff:	mov    -0x20(%rsi),%rax
 1018c03:	test   %rax,%rax
 1018c06:	je     1018cd1 <myl_rc_edge_release+0x111>
 1018c0c:	lea    -0x20(%rsi),%r8
 1018c10:	dec    %rax
 1018c13:	mov    %rax,(%r8)
 1018c16:	jne    1018bdc <myl_rc_edge_release+0x1c>
 1018c18:	cmpq   $0x0,-0x18(%rsi)
 1018c1d:	jne    1018bdc <myl_rc_edge_release+0x1c>
 1018c1f:	or     $0x1,%r9
 1018c23:	mov    %r9,-0x10(%rsi)
 1018c27:	mov    0x1608(%rdi),%rax
 1018c2e:	cmpl   $0x0,0xd0(%rax)
 1018c35:	jne    1018c7b <myl_rc_edge_release+0xbb>
 1018c37:	mov    -0x8(%rsi),%rcx
 1018c3b:	cmp    %rcx,0x110(%rax)
 1018c42:	je     1018c99 <myl_rc_edge_release+0xd9>
 1018c44:	mov    0x34(%rcx),%r9d
 1018c48:	cmp    %r9,0xa0(%rax)
 1018c4f:	jbe    1018cb3 <myl_rc_edge_release+0xf3>
 1018c51:	mov    0x98(%rax),%r10
 1018c58:	shl    $0x4,%r9
 1018c5c:	cmp    %rcx,(%r10,%r9,1)
 1018c60:	jne    1018cb3 <myl_rc_edge_release+0xf3>
 1018c62:	add    %r9,%r10
 1018c65:	mov    0x8(%r10),%rax
 1018c69:	test   %rax,%rax
 1018c6c:	je     1018c74 <myl_rc_edge_release+0xb4>
 1018c6e:	cmpl   $0x0,0x40(%rax)
 1018c72:	je     1018c95 <myl_rc_edge_release+0xd5>
 1018c74:	mov    0x1608(%rdi),%rax
 1018c7b:	mov    0xc8(%rax),%rax
 1018c82:	mov    %rax,(%r8)
 1018c85:	mov    0x1608(%rdi),%rax
 1018c8c:	mov    %r8,0xc8(%rax)
 1018c93:	pop    %rbp
 1018c94:	ret
 1018c95:	mov    -0x10(%rsi),%r9
 1018c99:	inc    %rdx
 1018c9c:	and    %r9,%rdx
 1018c9f:	cmp    $0x1,%rdx
 1018ca3:	jne    1018cd1 <myl_rc_edge_release+0x111>
 1018ca5:	mov    0x1608(%rdi),%rax
 1018cac:	mov    0x8(%rax),%rax
 1018cb0:	pop    %rbp
 1018cb1:	jmp    *%rax
 1018cb3:	mov    %rdi,%r9
 1018cb6:	mov    %rax,%rdi
 1018cb9:	mov    %rsi,%r10
 1018cbc:	mov    %rcx,%rsi
 1018cbf:	call   1018df4 <myl_rc_binding_find_slow>
 1018cc4:	mov    %r10,%rsi
 1018cc7:	mov    %r9,%rdi
 1018cca:	test   %rax,%rax
 1018ccd:	jne    1018c6e <myl_rc_edge_release+0xae>
 1018ccf:	jmp    1018c74 <myl_rc_edge_release+0xb4>
 1018cd1:	call   10187d4 <myl_rc_invariant_failed>
 1018cd6:	int3
 1018cd7:	int3
 1018cd8:	int3
 1018cd9:	int3
 1018cda:	int3
 1018cdb:	int3
 1018cdc:	int3
 1018cdd:	int3
 1018cde:	int3
 1018cdf:	int3

0000000001018ce0 <myl_rc_hold_edge_release>:
 1018ce0:	push   %rbp
 1018ce1:	mov    %rsp,%rbp
 1018ce4:	test   %rsi,%rsi
 1018ce7:	je     1018cfc <myl_rc_hold_edge_release+0x1c>
 1018ce9:	movabs $0x4000000000000002,%rdx
 1018cf3:	mov    -0x10(%rsi),%r9
 1018cf7:	test   %rdx,%r9
 1018cfa:	je     1018cfe <myl_rc_hold_edge_release+0x1e>
 1018cfc:	pop    %rbp
 1018cfd:	ret
 1018cfe:	test   %rdi,%rdi
 1018d01:	je     1018def <myl_rc_hold_edge_release+0x10f>
 1018d07:	cmpq   $0x0,0x1608(%rdi)
 1018d0f:	je     1018def <myl_rc_hold_edge_release+0x10f>
 1018d15:	test   $0x1,%r9b
 1018d19:	jne    1018def <myl_rc_hold_edge_release+0x10f>
 1018d1f:	mov    -0x18(%rsi),%rax
 1018d23:	test   %rax,%rax
 1018d26:	je     1018def <myl_rc_hold_edge_release+0x10f>
 1018d2c:	dec    %rax
 1018d2f:	mov    %rax,-0x18(%rsi)
 1018d33:	or     -0x20(%rsi),%rax
 1018d37:	jne    1018cfc <myl_rc_hold_edge_release+0x1c>
 1018d39:	lea    -0x20(%rsi),%r8
 1018d3d:	or     $0x1,%r9
 1018d41:	mov    %r9,-0x10(%rsi)
 1018d45:	mov    0x1608(%rdi),%rax
 1018d4c:	cmpl   $0x0,0xd0(%rax)
 1018d53:	jne    1018d99 <myl_rc_hold_edge_release+0xb9>
 1018d55:	mov    -0x8(%rsi),%rcx
 1018d59:	cmp    %rcx,0x110(%rax)
 1018d60:	je     1018db7 <myl_rc_hold_edge_release+0xd7>
 1018d62:	mov    0x34(%rcx),%r9d
 1018d66:	cmp    %r9,0xa0(%rax)
 1018d6d:	jbe    1018dd1 <myl_rc_hold_edge_release+0xf1>
 1018d6f:	mov    0x98(%rax),%r10
 1018d76:	shl    $0x4,%r9
 1018d7a:	cmp    %rcx,(%r10,%r9,1)
 1018d7e:	jne    1018dd1 <myl_rc_hold_edge_release+0xf1>
 1018d80:	add    %r9,%r10
 1018d83:	mov    0x8(%r10),%rax
 1018d87:	test   %rax,%rax
 1018d8a:	je     1018d92 <myl_rc_hold_edge_release+0xb2>
 1018d8c:	cmpl   $0x0,0x40(%rax)
 1018d90:	je     1018db3 <myl_rc_hold_edge_release+0xd3>
 1018d92:	mov    0x1608(%rdi),%rax
 1018d99:	mov    0xc8(%rax),%rax
 1018da0:	mov    %rax,(%r8)
 1018da3:	mov    0x1608(%rdi),%rax
 1018daa:	mov    %r8,0xc8(%rax)
 1018db1:	pop    %rbp
 1018db2:	ret
 1018db3:	mov    -0x10(%rsi),%r9
 1018db7:	inc    %rdx
 1018dba:	and    %r9,%rdx
 1018dbd:	cmp    $0x1,%rdx
 1018dc1:	jne    1018def <myl_rc_hold_edge_release+0x10f>
 1018dc3:	mov    0x1608(%rdi),%rax
 1018dca:	mov    0x8(%rax),%rax
 1018dce:	pop    %rbp
 1018dcf:	jmp    *%rax
 1018dd1:	mov    %rdi,%r9
 1018dd4:	mov    %rax,%rdi
 1018dd7:	mov    %rsi,%r10
 1018dda:	mov    %rcx,%rsi
 1018ddd:	call   1018df4 <myl_rc_binding_find_slow>
 1018de2:	mov    %r10,%rsi
 1018de5:	mov    %r9,%rdi
 1018de8:	test   %rax,%rax
 1018deb:	jne    1018d8c <myl_rc_hold_edge_release+0xac>
 1018ded:	jmp    1018d92 <myl_rc_hold_edge_release+0xb2>
 1018def:	call   10187d4 <myl_rc_invariant_failed>

0000000001018df4 <myl_rc_binding_find_slow>:
 1018df4:	push   %rbp
 1018df5:	mov    %rsp,%rbp
 1018df8:	push   %r10
 1018dfa:	push   %r9
 1018dfc:	push   %r8
 1018dfe:	push   %rdi
 1018dff:	push   %rsi
 1018e00:	push   %rdx
 1018e01:	push   %rcx
 1018e02:	push   %r15
 1018e04:	push   %r14
 1018e06:	push   %rbx
 1018e07:	mov    %rsi,%rbx
 1018e0a:	mov    0x34(%rsi),%eax
 1018e0d:	cmp    %rax,0xa0(%rdi)
 1018e14:	jbe    1018e33 <myl_rc_binding_find_slow+0x3f>
 1018e16:	mov    0x98(%rdi),%r11
 1018e1d:	shl    $0x4,%rax
 1018e21:	lea    (%r11,%rax,1),%r15
 1018e25:	mov    (%r11,%rax,1),%rax
 1018e29:	cmp    %rbx,%rax
 1018e2c:	je     1018e94 <myl_rc_binding_find_slow+0xa0>
 1018e2e:	test   %rax,%rax
 1018e31:	je     1018eac <myl_rc_binding_find_slow+0xb8>
 1018e33:	mov    0x78(%rdi),%rax
 1018e37:	mov    0x80(%rdi),%rcx
 1018e3e:	mov    0x90(%rdi),%r11b
 1018e45:	movabs $0x9e3779b97f4a7c15,%rdx
 1018e4f:	imul   %rbx,%rdx
 1018e53:	shrx   %r11,%rdx,%r11
 1018e58:	and    %rcx,%r11
 1018e5b:	mov    %r11,%rdx
 1018e5e:	shl    $0x4,%rdx
 1018e62:	mov    (%rax,%rdx,1),%rdx
 1018e66:	cmp    %rbx,%rdx
 1018e69:	je     1018e89 <myl_rc_binding_find_slow+0x95>
 1018e6b:	xor    %r14d,%r14d
 1018e6e:	test   %rdx,%rdx
 1018e71:	je     1018e98 <myl_rc_binding_find_slow+0xa4>
 1018e73:	inc    %r11
 1018e76:	and    %rcx,%r11
 1018e79:	mov    %r11,%rdx
 1018e7c:	shl    $0x4,%rdx
 1018e80:	mov    (%rax,%rdx,1),%rdx
 1018e84:	cmp    %rbx,%rdx
 1018e87:	jne    1018e6e <myl_rc_binding_find_slow+0x7a>
 1018e89:	shl    $0x4,%r11
 1018e8d:	mov    0x8(%rax,%r11,1),%r14
 1018e92:	jmp    1018e98 <myl_rc_binding_find_slow+0xa4>
 1018e94:	mov    0x8(%r15),%r14
 1018e98:	mov    %r14,%rax
 1018e9b:	pop    %rbx
 1018e9c:	pop    %r14
 1018e9e:	pop    %r15
 1018ea0:	pop    %rcx
 1018ea1:	pop    %rdx
 1018ea2:	pop    %rsi
 1018ea3:	pop    %rdi
 1018ea4:	pop    %r8
 1018ea6:	pop    %r9
 1018ea8:	pop    %r10
 1018eaa:	pop    %rbp
 1018eab:	ret
 1018eac:	mov    0x8(%r15),%r14
 1018eb0:	test   %r14,%r14
 1018eb3:	je     1018e33 <myl_rc_binding_find_slow+0x3f>
 1018eb9:	cmp    %rbx,(%r14)
 1018ebc:	jne    1018e33 <myl_rc_binding_find_slow+0x3f>
 1018ec2:	mov    %r14,%rdi
 1018ec5:	call   1018ed0 <flat_build>
 1018eca:	mov    %rbx,(%r15)
 1018ecd:	jmp    1018e98 <myl_rc_binding_find_slow+0xa4>
 1018ecf:	int3

0000000001018ed0 <flat_build>:
 1018ed0:	push   %rbp
 1018ed1:	mov    %rsp,%rbp
 1018ed4:	push   %r15
 1018ed6:	push   %r14
 1018ed8:	push   %r13
 1018eda:	push   %r12
 1018edc:	push   %rbx
 1018edd:	sub    $0x368,%rsp
 1018ee4:	movl   $0x11,0x40(%rdi)
 1018eeb:	movw   $0x0,0x44(%rdi)
 1018ef1:	movb   $0x0,0x46(%rdi)
 1018ef5:	mov    (%rdi),%r14
 1018ef8:	mov    (%r14),%rax
 1018efb:	mov    %rax,0x50(%rdi)
 1018eff:	cmpq   $0x0,0x10(%rdi)
 1018f04:	jne    1018f29 <flat_build+0x59>
 1018f06:	cmpq   $0x0,0x18(%rdi)
 1018f0b:	jne    1018f29 <flat_build+0x59>
 1018f0d:	cmpq   $0x0,0x20(%rdi)
 1018f12:	jne    1018f29 <flat_build+0x59>
 1018f14:	cmpq   $0x0,0x28(%rdi)
 1018f19:	jne    1018f29 <flat_build+0x59>
 1018f1b:	cmpq   $0x0,0x30(%rdi)
 1018f20:	jne    1018f29 <flat_build+0x59>
 1018f22:	cmpq   $0x0,0x38(%rdi)
 1018f27:	je     1018f3b <flat_build+0x6b>
 1018f29:	add    $0x368,%rsp
 1018f30:	pop    %rbx
 1018f31:	pop    %r12
 1018f33:	pop    %r13
 1018f35:	pop    %r14
 1018f37:	pop    %r15
 1018f39:	pop    %rbp
 1018f3a:	ret
 1018f3b:	lea    0x40(%rdi),%rax
 1018f3f:	mov    %rax,-0x48(%rbp)
 1018f43:	lea    -0x380(%rbp),%rax
 1018f4a:	mov    $0x270,%edx
 1018f4f:	mov    %rdi,-0x38(%rbp)
 1018f53:	mov    %rax,%rdi
 1018f56:	xor    %esi,%esi
 1018f58:	call   10274d0 <memset@plt>
 1018f5d:	mov    %r14,-0x390(%rbp)
 1018f64:	mov    -0x38(%rbp),%rax
 1018f68:	mov    0x8(%rax),%rax
 1018f6c:	mov    %rax,-0x388(%rbp)
 1018f73:	movl   $0xffffffff,-0x370(%rbp)
 1018f7d:	mov    $0x1,%r12b
 1018f80:	mov    $0x1,%ecx
 1018f85:	mov    $0xc1,%esi
 1018f8a:	xor    %r14d,%r14d
 1018f8d:	xor    %ebx,%ebx
 1018f8f:	cmp    $0x9,%rcx
 1018f93:	movzbl %r12b,%r12d
 1018f97:	mov    $0x0,%eax
 1018f9c:	cmovae %eax,%r12d
 1018fa0:	dec    %rsi
 1018fa3:	je     1018f29 <flat_build+0x59>
 1018fa5:	lea    (%rcx,%rcx,4),%rax
 1018fa9:	mov    -0x3b8(%rbp,%rax,8),%r8
 1018fb1:	test   %r8,%r8
 1018fb4:	je     1018f29 <flat_build+0x59>
 1018fba:	mov    -0x3b0(%rbp,%rax,8),%r11
 1018fc2:	test   %r11,%r11
 1018fc5:	je     1018fd9 <flat_build+0x109>
 1018fc7:	mov    (%r8),%rdx
 1018fca:	cmp    (%r11),%rdx
 1018fcd:	jne    1018f29 <flat_build+0x59>
 1018fd3:	mov    0x8(%r11),%r13d
 1018fd7:	jmp    1018fdc <flat_build+0x10c>
 1018fd9:	xor    %r13d,%r13d
 1018fdc:	movzwl 0x30(%r8),%edx
 1018fe1:	cmp    $0x7,%edx
 1018fe4:	je     1018ffe <flat_build+0x12e>
 1018fe6:	lea    -0x390(,%rax,8),%rdi
 1018fee:	add    %rbp,%rdi
 1018ff1:	cmp    $0x1,%edx
 1018ff4:	je     1019008 <flat_build+0x138>
 1018ff6:	test   %edx,%edx
 1018ff8:	jne    1019080 <flat_build+0x1b0>
 1018ffe:	test   %r13d,%r13d
 1019001:	je     101906f <flat_build+0x19f>
 1019003:	jmp    1018f29 <flat_build+0x59>
 1019008:	cmpw   $0x5,0x32(%r8)
 101900e:	jne    1019022 <flat_build+0x152>
 1019010:	cmpq   $0x0,0x38(%r8)
 1019015:	movzbl %r12b,%r12d
 1019019:	mov    $0x0,%eax
 101901e:	cmovne %eax,%r12d
 1019022:	cmp    $0x1,%r13d
 1019026:	jne    1018f29 <flat_build+0x59>
 101902c:	cmpq   $0x8,(%r8)
 1019030:	jne    1018f29 <flat_build+0x59>
 1019036:	cmp    $0x10,%r14d
 101903a:	je     1018f29 <flat_build+0x59>
 1019040:	mov    -0x18(%rdi),%rax
 1019044:	mov    $0xfffffff7,%edx
 1019049:	cmp    %rdx,%rax
 101904c:	ja     1018f29 <flat_build+0x59>
 1019052:	mov    %r14d,%edx
 1019055:	inc    %r14d
 1019058:	lea    (%rdx,%rdx,2),%rdx
 101905c:	mov    %eax,-0x110(%rbp,%rdx,4)
 1019063:	mov    -0x8(%rdi),%rax
 1019067:	mov    %rax,-0x10c(%rbp,%rdx,4)
 101906f:	dec    %rcx
 1019072:	test   %rcx,%rcx
 1019075:	jne    1018f8f <flat_build+0xbf>
 101907b:	jmp    10192d4 <flat_build+0x404>
 1019080:	mov    -0x8(%rdi),%eax
 1019083:	mov    %rax,-0x30(%rbp)
 1019087:	mov    -0x4(%rdi),%r9d
 101908b:	cmp    $0x4,%edx
 101908e:	je     101919c <flat_build+0x2cc>
 1019094:	cmp    $0x3,%edx
 1019097:	je     1019113 <flat_build+0x243>
 1019099:	cmp    $0x2,%edx
 101909c:	jne    1018f29 <flat_build+0x59>
 10190a2:	test   $0xfffffffd,%r13d
 10190a9:	jne    1018f29 <flat_build+0x59>
 10190af:	mov    0x18(%r8),%rdx
 10190b3:	cmp    $0x2,%r13d
 10190b7:	jne    10190c3 <flat_build+0x1f3>
 10190b9:	cmp    0x18(%r11),%rdx
 10190bd:	jne    1018f29 <flat_build+0x59>
 10190c3:	mov    -0x10(%rdi),%rax
 10190c7:	cmp    %rdx,%rax
 10190ca:	je     101906f <flat_build+0x19f>
 10190cc:	mov    0x10(%r8),%r10
 10190d0:	test   %r10,%r10
 10190d3:	je     1018f29 <flat_build+0x59>
 10190d9:	lea    0x1(%rax),%rdx
 10190dd:	mov    %rdx,-0x10(%rdi)
 10190e1:	lea    (%rax,%rax,2),%rdx
 10190e5:	mov    (%r10,%rdx,8),%rax
 10190e9:	mov    0x8(%r10,%rdx,8),%r15
 10190ee:	cmp    $0x2,%r13d
 10190f2:	jne    1019251 <flat_build+0x381>
 10190f8:	mov    0x10(%r11),%r10
 10190fc:	cmp    (%r10,%rdx,8),%rax
 1019100:	jne    1018f29 <flat_build+0x59>
 1019106:	lea    (%r10,%rdx,8),%rdx
 101910a:	mov    0x8(%rdx),%rdx
 101910e:	jmp    101925b <flat_build+0x38b>
 1019113:	cmp    $0x3,%r13d
 1019117:	je     1019122 <flat_build+0x252>
 1019119:	test   %r13d,%r13d
 101911c:	jne    1018f29 <flat_build+0x59>
 1019122:	mov    0x20(%r8),%rdx
 1019126:	cmp    $0x3,%r13d
 101912a:	jne    1019144 <flat_build+0x274>
 101912c:	cmp    0x18(%r11),%rdx
 1019130:	jne    1018f29 <flat_build+0x59>
 1019136:	mov    0x28(%r8),%rax
 101913a:	cmp    0x20(%r11),%rax
 101913e:	jne    1018f29 <flat_build+0x59>
 1019144:	mov    -0x10(%rdi),%rax
 1019148:	cmp    %rdx,%rax
 101914b:	je     101906f <flat_build+0x19f>
 1019151:	mov    0x38(%r8),%r15
 1019155:	test   %r15,%r15
 1019158:	jne    1019177 <flat_build+0x2a7>
 101915a:	cmpq   $0x1,0x18(%r8)
 101915f:	jne    1019174 <flat_build+0x2a4>
 1019161:	mov    0x10(%r8),%rdx
 1019165:	test   %rdx,%rdx
 1019168:	je     1019174 <flat_build+0x2a4>
 101916a:	cmpq   $0x0,(%rdx)
 101916e:	je     10192b9 <flat_build+0x3e9>
 1019174:	xor    %r15d,%r15d
 1019177:	lea    0x1(%rax),%rdx
 101917b:	mov    %rdx,-0x10(%rdi)
 101917f:	mulq   0x28(%r8)
 1019183:	jo     1018f29 <flat_build+0x59>
 1019189:	cmp    $0x3,%r13d
 101918d:	jne    1019251 <flat_build+0x381>
 1019193:	mov    0x10(%r11),%rdx
 1019197:	jmp    101925b <flat_build+0x38b>
 101919c:	test   $0xfffffffb,%r13d
 10191a3:	jne    1018f29 <flat_build+0x59>
 10191a9:	mov    -0x10(%rdi),%rax
 10191ad:	mov    0x18(%r8),%r10
 10191b1:	cmp    %r10,%rax
 10191b4:	je     101906f <flat_build+0x19f>
 10191ba:	mov    0x10(%r8),%rdx
 10191be:	test   %rdx,%rdx
 10191c1:	je     1018f29 <flat_build+0x59>
 10191c7:	mov    %rbx,-0x40(%rbp)
 10191cb:	lea    0x1(%rax),%rbx
 10191cf:	mov    %rbx,-0x10(%rdi)
 10191d3:	lea    (%rax,%rax,2),%rbx
 10191d7:	mov    (%rdx,%rbx,8),%rax
 10191db:	mov    0x8(%rdx,%rbx,8),%r15
 10191e0:	cmp    $0x4,%r13d
 10191e4:	jne    1019255 <flat_build+0x385>
 10191e6:	cmp    0x18(%r11),%r10
 10191ea:	jne    1018f29 <flat_build+0x59>
 10191f0:	cmpl   $0xffffffff,-0x30(%rbp)
 10191f4:	jne    1018f29 <flat_build+0x59>
 10191fa:	lea    0x0(,%rbx,8),%r13
 1019202:	add    0x10(%r11),%r13
 1019206:	cmp    0x0(%r13),%rax
 101920a:	jne    1018f29 <flat_build+0x59>
 1019210:	lea    (%rdx,%rbx,8),%rdx
 1019214:	mov    0x10(%rdx),%edx
 1019217:	cmp    0x10(%r13),%edx
 101921b:	jne    1018f29 <flat_build+0x59>
 1019221:	mov    %edx,%r9d
 1019224:	mov    -0x18(%rdi),%rdx
 1019228:	add    0x20(%r11),%rdx
 101922c:	mov    %rdx,-0x30(%rbp)
 1019230:	jb     1018f29 <flat_build+0x59>
 1019236:	mov    $0xfffffff7,%edx
 101923b:	add    $0x4,%rdx
 101923f:	cmp    %rdx,-0x30(%rbp)
 1019243:	ja     1018f29 <flat_build+0x59>
 1019249:	mov    0x8(%r13),%rdx
 101924d:	mov    $0x1,%bl
 101924f:	jmp    101925b <flat_build+0x38b>
 1019251:	xor    %edx,%edx
 1019253:	jmp    101925b <flat_build+0x38b>
 1019255:	xor    %edx,%edx
 1019257:	mov    -0x40(%rbp),%rbx
 101925b:	cmp    $0x10,%rcx
 101925f:	je     1018f29 <flat_build+0x59>
 1019265:	test   %r15,%r15
 1019268:	je     1018f29 <flat_build+0x59>
 101926e:	mov    (%r8),%r8
 1019271:	sub    %rax,%r8
 1019274:	jb     1018f29 <flat_build+0x59>
 101927a:	cmp    %r8,(%r15)
 101927d:	ja     1018f29 <flat_build+0x59>
 1019283:	add    -0x18(%rdi),%rax
 1019287:	jb     1018f29 <flat_build+0x59>
 101928d:	inc    %rcx
 1019290:	mov    %r15,(%rdi)
 1019293:	mov    %rdx,0x8(%rdi)
 1019297:	mov    %rax,0x10(%rdi)
 101929b:	movq   $0x0,0x18(%rdi)
 10192a3:	mov    -0x30(%rbp),%rax
 10192a7:	mov    %eax,0x20(%rdi)
 10192aa:	mov    %r9d,0x24(%rdi)
 10192ae:	test   %rcx,%rcx
 10192b1:	jne    1018f8f <flat_build+0xbf>
 10192b7:	jmp    10192d4 <flat_build+0x404>
 10192b9:	mov    0x8(%rdx),%r15
 10192bd:	lea    0x1(%rax),%rdx
 10192c1:	mov    %rdx,-0x10(%rdi)
 10192c5:	mulq   0x28(%r8)
 10192c9:	jno    1019189 <flat_build+0x2b9>
 10192cf:	jmp    1018f29 <flat_build+0x59>
 10192d4:	lea    -0x110(%rbp),%rdi
 10192db:	mov    %r14d,%esi
 10192de:	call   1019320 <flat_disjoint>
 10192e3:	test   %eax,%eax
 10192e5:	je     1018f29 <flat_build+0x59>
 10192eb:	lea    -0x110(%rbp),%rsi
 10192f2:	mov    -0x48(%rbp),%rdi
 10192f6:	mov    %r14d,%edx
 10192f9:	call   1019410 <flat_masks>
 10192fe:	mov    -0x38(%rbp),%rcx
 1019302:	test   %eax,%eax
 1019304:	je     1018f29 <flat_build+0x59>
 101930a:	mov    %r14d,0x40(%rcx)
 101930e:	mov    %r12b,0x44(%rcx)
 1019312:	mov    %bl,0x46(%rcx)
 1019315:	jmp    1018f29 <flat_build+0x59>
 101931a:	int3
 101931b:	int3
 101931c:	int3
 101931d:	int3
 101931e:	int3
 101931f:	int3

0000000001019320 <flat_disjoint>:
 1019320:	mov    $0x1,%eax
 1019325:	test   %esi,%esi
 1019327:	je     101940a <flat_disjoint+0xea>
 101932d:	push   %rbp
 101932e:	mov    %rsp,%rbp
 1019331:	push   %r15
 1019333:	push   %r14
 1019335:	push   %r13
 1019337:	push   %r12
 1019339:	push   %rbx
 101933a:	mov    %esi,%ecx
 101933c:	lea    0x8(%rdi),%rdx
 1019340:	xor    %esi,%esi
 1019342:	mov    $0xffffffff,%r8d
 1019348:	lea    (%rsi,%rsi,2),%r9
 101934c:	lea    (%rdi,%r9,4),%r9
 1019350:	mov    %rdx,%r10
 1019353:	xor    %r11d,%r11d
 1019356:	jmp    1019370 <flat_disjoint+0x50>
 1019358:	nopl   0x0(%rax,%rax,1)
 1019360:	inc    %r11
 1019363:	add    $0xc,%r10
 1019367:	cmp    %r11,%rcx
 101936a:	je     10193f0 <flat_disjoint+0xd0>
 1019370:	cmp    %r11,%rsi
 1019373:	jae    10193ac <flat_disjoint+0x8c>
 1019375:	mov    0x4(%r9),%ebx
 1019379:	cmp    $0xffffffff,%ebx
 101937c:	je     1019390 <flat_disjoint+0x70>
 101937e:	cmp    -0x4(%r10),%ebx
 1019382:	jne    1019390 <flat_disjoint+0x70>
 1019384:	mov    0x8(%r9),%ebx
 1019388:	cmp    (%r10),%ebx
 101938b:	jne    10193ac <flat_disjoint+0x8c>
 101938d:	nopl   (%rax)
 1019390:	mov    (%r9),%ebx
 1019393:	mov    -0x8(%r10),%r14d
 1019397:	mov    %ebx,%r15d
 101939a:	sub    %r14d,%r15d
 101939d:	neg    %r15d
 10193a0:	sub    %r14d,%ebx
 10193a3:	cmovb  %r15,%rbx
 10193a7:	cmp    $0x8,%ebx
 10193aa:	jb     10193fe <flat_disjoint+0xde>
 10193ac:	mov    -0x4(%r10),%ebx
 10193b0:	cmp    %r8,%rbx
 10193b3:	je     1019360 <flat_disjoint+0x40>
 10193b5:	mov    (%r9),%r14d
 10193b8:	mov    %r14d,%r15d
 10193bb:	sub    %ebx,%r15d
 10193be:	mov    %r15d,%r12d
 10193c1:	neg    %r12d
 10193c4:	xor    %r13d,%r13d
 10193c7:	cmp    $0x8,%r12d
 10193cb:	setae  %r13b
 10193cf:	xor    %r12d,%r12d
 10193d2:	cmp    $0x4,%r15d
 10193d6:	setae  %r12b
 10193da:	cmp    %ebx,%r14d
 10193dd:	cmovae %r12d,%r13d
 10193e1:	cmp    $0x1,%r13b
 10193e5:	je     1019360 <flat_disjoint+0x40>
 10193eb:	jmp    10193fe <flat_disjoint+0xde>
 10193ed:	nopl   (%rax)
 10193f0:	inc    %rsi
 10193f3:	cmp    %rcx,%rsi
 10193f6:	jne    1019348 <flat_disjoint+0x28>
 10193fc:	jmp    1019400 <flat_disjoint+0xe0>
 10193fe:	xor    %eax,%eax
 1019400:	pop    %rbx
 1019401:	pop    %r12
 1019403:	pop    %r13
 1019405:	pop    %r14
 1019407:	pop    %r15
 1019409:	pop    %rbp
 101940a:	ret
 101940b:	int3
 101940c:	int3
 101940d:	int3
 101940e:	int3
 101940f:	int3

0000000001019410 <flat_masks>:
 1019410:	push   %rbp
 1019411:	mov    %rsp,%rbp
 1019414:	push   %r14
 1019416:	push   %rbx
 1019417:	mov    $0xffffffff,%ecx
 101941c:	test   %edx,%edx
 101941e:	je     101947b <flat_masks+0x6b>
 1019420:	mov    %edx,%r9d
 1019423:	lea    0x8(%rsi),%r11
 1019427:	mov    $0xffffffff,%r14d
 101942d:	xor    %ebx,%ebx
 101942f:	xor    %r8d,%r8d
 1019432:	jmp    1019456 <flat_masks+0x46>
 1019434:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019440:	bts    %ebx,%r8d
 1019444:	mov    %r14d,%r10d
 1019447:	inc    %rbx
 101944a:	add    $0xc,%r11
 101944e:	mov    %r10d,%r14d
 1019451:	cmp    %rbx,%r9
 1019454:	je     1019486 <flat_masks+0x76>
 1019456:	mov    -0x4(%r11),%r10d
 101945a:	cmp    $0xffffffff,%r10d
 101945e:	je     1019440 <flat_masks+0x30>
 1019460:	xor    %eax,%eax
 1019462:	cmp    $0xffffffff,%r14d
 1019466:	je     101946d <flat_masks+0x5d>
 1019468:	cmp    %r10d,%r14d
 101946b:	jne    1019473 <flat_masks+0x63>
 101946d:	cmpl   $0x1f,(%r11)
 1019471:	jbe    1019447 <flat_masks+0x37>
 1019473:	pop    %rbx
 1019474:	pop    %r14
 1019476:	pop    %rbp
 1019477:	vzeroupper
 101947a:	ret
 101947b:	xor    %r8d,%r8d
 101947e:	mov    $0xffffffff,%r10d
 1019484:	jmp    10194ae <flat_masks+0x9e>
 1019486:	xor    %eax,%eax
 1019488:	mov    %rsi,%r11
 101948b:	xor    %ebx,%ebx
 101948d:	nopl   (%rax)
 1019490:	mov    (%r11),%r14d
 1019493:	cmp    $0xfff7,%r14d
 101949a:	ja     1019473 <flat_masks+0x63>
 101949c:	mov    %r14w,0x5c(%rdi,%rbx,2)
 10194a2:	inc    %rbx
 10194a5:	add    $0xc,%r11
 10194a9:	cmp    %rbx,%r9
 10194ac:	jne    1019490 <flat_masks+0x80>
 10194ae:	shlx   %edx,%ecx,%eax
 10194b3:	not    %eax
 10194b5:	mov    %ax,0x18(%rdi)
 10194b9:	mov    %r10d,0x8(%rdi)
 10194bd:	vmovd  %r8d,%xmm0
 10194c2:	vpbroadcastw %xmm0,%ymm0
 10194c7:	vmovdqu %ymm0,0x1a(%rdi)
 10194cc:	vmovdqu %ymm0,0x3a(%rdi)
 10194d1:	mov    %r8w,0x5a(%rdi)
 10194d6:	mov    $0x1,%eax
 10194db:	test   %edx,%edx
 10194dd:	je     1019473 <flat_masks+0x63>
 10194df:	cmp    $0x1,%edx
 10194e2:	jne    10194e8 <flat_masks+0xd8>
 10194e4:	xor    %ecx,%ecx
 10194e6:	jmp    101954c <flat_masks+0x13c>
 10194e8:	mov    %edx,%edx
 10194ea:	mov    %edx,%eax
 10194ec:	and    $0xfffffffe,%eax
 10194ef:	lea    0x14(%rsi),%r8
 10194f3:	xor    %ecx,%ecx
 10194f5:	mov    $0x1,%r9d
 10194fb:	jmp    101950d <flat_masks+0xfd>
 10194fd:	nopl   (%rax)
 1019500:	add    $0x2,%rcx
 1019504:	add    $0x18,%r8
 1019508:	cmp    %rcx,%rax
 101950b:	je     101953e <flat_masks+0x12e>
 101950d:	cmpl   $0xffffffff,-0x10(%r8)
 1019512:	je     1019523 <flat_masks+0x113>
 1019514:	shlx   %ecx,%r9d,%r10d
 1019519:	mov    -0xc(%r8),%r11d
 101951d:	or     %r10w,0x1c(%rdi,%r11,2)
 1019523:	cmpl   $0xffffffff,-0x4(%r8)
 1019528:	je     1019500 <flat_masks+0xf0>
 101952a:	lea    0x1(%rcx),%r10d
 101952e:	shlx   %r10d,%r9d,%r10d
 1019533:	mov    (%r8),%r11d
 1019536:	or     %r10w,0x1c(%rdi,%r11,2)
 101953c:	jmp    1019500 <flat_masks+0xf0>
 101953e:	mov    $0x1,%eax
 1019543:	test   $0x1,%dl
 1019546:	je     1019473 <flat_masks+0x63>
 101954c:	lea    (%rcx,%rcx,2),%rdx
 1019550:	cmpl   $0xffffffff,0x4(%rsi,%rdx,4)
 1019555:	mov    $0x1,%eax
 101955a:	je     1019473 <flat_masks+0x63>
 1019560:	lea    (%rsi,%rdx,4),%rdx
 1019564:	mov    $0x1,%eax
 1019569:	shlx   %ecx,%eax,%ecx
 101956e:	mov    0x8(%rdx),%edx
 1019571:	or     %cx,0x1c(%rdi,%rdx,2)
 1019576:	pop    %rbx
 1019577:	pop    %r14
 1019579:	pop    %rbp
 101957a:	vzeroupper
 101957d:	ret
 101957e:	int3
 101957f:	int3

0000000001019580 <myl_rc_module_register>:
 1019580:	push   %rbp
 1019581:	mov    %rsp,%rbp
 1019584:	push   %r15
 1019586:	push   %r14
 1019588:	push   %r12
 101958a:	push   %rbx
 101958b:	sub    $0x30,%rsp
 101958f:	test   %rdi,%rdi
 1019592:	je     101979c <myl_rc_module_register+0x21c>
 1019598:	mov    %rsi,%rbx
 101959b:	test   %rsi,%rsi
 101959e:	je     101979c <myl_rc_module_register+0x21c>
 10195a4:	mov    0x1608(%rdi),%rcx
 10195ab:	test   %rcx,%rcx
 10195ae:	je     101979c <myl_rc_module_register+0x21c>
 10195b4:	cmpl   $0x5,(%rbx)
 10195b7:	jne    101979c <myl_rc_module_register+0x21c>
 10195bd:	cmpq   $0x0,0xc0(%rcx)
 10195c5:	jne    101979c <myl_rc_module_register+0x21c>
 10195cb:	mov    0x38(%rcx),%rax
 10195cf:	mov    0x40(%rcx),%rdx
 10195d3:	movzbl 0x50(%rcx),%ecx
 10195d7:	movabs $0x9e3779b97f4a7c15,%rsi
 10195e1:	imul   %rbx,%rsi
 10195e5:	shrx   %rcx,%rsi,%rcx
 10195ea:	nopw   0x0(%rax,%rax,1)
 10195f0:	and    %rdx,%rcx
 10195f3:	mov    %rcx,%rsi
 10195f6:	shl    $0x4,%rsi
 10195fa:	mov    (%rax,%rsi,1),%rsi
 10195fe:	cmp    %rbx,%rsi
 1019601:	je     101960d <myl_rc_module_register+0x8d>
 1019603:	test   %rsi,%rsi
 1019606:	je     1019620 <myl_rc_module_register+0xa0>
 1019608:	inc    %rcx
 101960b:	jmp    10195f0 <myl_rc_module_register+0x70>
 101960d:	shl    $0x4,%rcx
 1019611:	xor    %r14d,%r14d
 1019614:	cmpq   $0x0,0x8(%rax,%rcx,1)
 101961a:	jne    101978c <myl_rc_module_register+0x20c>
 1019620:	mov    0x10(%rbx),%rax
 1019624:	test   %rax,%rax
 1019627:	je     1019634 <myl_rc_module_register+0xb4>
 1019629:	cmpq   $0x0,0x8(%rbx)
 101962e:	je     101979c <myl_rc_module_register+0x21c>
 1019634:	mov    0x20(%rbx),%rcx
 1019638:	test   %rcx,%rcx
 101963b:	je     1019648 <myl_rc_module_register+0xc8>
 101963d:	cmpq   $0x0,0x18(%rbx)
 1019642:	je     101979c <myl_rc_module_register+0x21c>
 1019648:	vxorps %xmm0,%xmm0,%xmm0
 101964c:	vmovups %ymm0,-0x48(%rbp)
 1019651:	movq   $0x0,-0x28(%rbp)
 1019659:	mov    %rdi,-0x50(%rbp)
 101965d:	test   %rax,%rax
 1019660:	je     1019698 <myl_rc_module_register+0x118>
 1019662:	xor    %r15d,%r15d
 1019665:	lea    -0x50(%rbp),%r14
 1019669:	nopl   0x0(%rax)
 1019670:	mov    0x8(%rbx),%rax
 1019674:	mov    (%rax,%r15,8),%rsi
 1019678:	mov    %r14,%rdi
 101967b:	vzeroupper
 101967e:	call   10197b0 <builder_add>
 1019683:	test   %eax,%eax
 1019685:	je     1019710 <myl_rc_module_register+0x190>
 101968b:	inc    %r15
 101968e:	cmp    0x10(%rbx),%r15
 1019692:	jb     1019670 <myl_rc_module_register+0xf0>
 1019694:	mov    0x20(%rbx),%rcx
 1019698:	test   %rcx,%rcx
 101969b:	je     10196f7 <myl_rc_module_register+0x177>
 101969d:	mov    $0x8,%r15d
 10196a3:	xor    %r12d,%r12d
 10196a6:	lea    -0x50(%rbp),%r14
 10196aa:	nopw   0x0(%rax,%rax,1)
 10196b0:	mov    0x18(%rbx),%rcx
 10196b4:	mov    -0x8(%rcx,%r15,1),%rax
 10196b9:	test   %rax,%rax
 10196bc:	je     101979c <myl_rc_module_register+0x21c>
 10196c2:	mov    (%rcx,%r15,1),%rsi
 10196c6:	test   %rsi,%rsi
 10196c9:	je     101979c <myl_rc_module_register+0x21c>
 10196cf:	mov    (%rax),%rax
 10196d2:	cmp    (%rsi),%rax
 10196d5:	jne    101979c <myl_rc_module_register+0x21c>
 10196db:	mov    %r14,%rdi
 10196de:	vzeroupper
 10196e1:	call   10197b0 <builder_add>
 10196e6:	test   %eax,%eax
 10196e8:	je     1019710 <myl_rc_module_register+0x190>
 10196ea:	inc    %r12
 10196ed:	add    $0x40,%r15
 10196f1:	cmp    0x20(%rbx),%r12
 10196f5:	jb     10196b0 <myl_rc_module_register+0x130>
 10196f7:	lea    -0x50(%rbp),%rdi
 10196fb:	mov    %rbx,%rsi
 10196fe:	mov    $0x1,%edx
 1019703:	vzeroupper
 1019706:	call   1019bc0 <register_shapes>
 101970b:	mov    %eax,%r14d
 101970e:	jmp    1019716 <myl_rc_module_register+0x196>
 1019710:	mov    $0x1,%r14d
 1019716:	mov    -0x50(%rbp),%rbx
 101971a:	mov    -0x48(%rbp),%rdi
 101971e:	mov    -0x30(%rbp),%r15
 1019722:	test   %rdi,%rdi
 1019725:	je     1019759 <myl_rc_module_register+0x1d9>
 1019727:	lea    0x0(,%r15,8),%rax
 101972f:	lea    (%rax,%rax,4),%rcx
 1019733:	mov    0x18(%rbx),%rax
 1019737:	sub    %rcx,%rax
 101973a:	jb     101979c <myl_rc_module_register+0x21c>
 101973c:	mov    0x1608(%rbx),%rdx
 1019743:	mov    0x30(%rdx),%rsi
 1019747:	sub    %rcx,%rsi
 101974a:	jb     101979c <myl_rc_module_register+0x21c>
 101974c:	mov    %rax,0x18(%rbx)
 1019750:	mov    %rsi,0x30(%rdx)
 1019754:	call   1027570 <free@plt>
 1019759:	mov    -0x40(%rbp),%rdi
 101975d:	test   %rdi,%rdi
 1019760:	je     101978c <myl_rc_module_register+0x20c>
 1019762:	shl    $0x4,%r15
 1019766:	mov    0x18(%rbx),%rax
 101976a:	sub    %r15,%rax
 101976d:	jb     101979c <myl_rc_module_register+0x21c>
 101976f:	mov    0x1608(%rbx),%rcx
 1019776:	mov    0x30(%rcx),%rdx
 101977a:	sub    %r15,%rdx
 101977d:	jb     101979c <myl_rc_module_register+0x21c>
 101977f:	mov    %rax,0x18(%rbx)
 1019783:	mov    %rdx,0x30(%rcx)
 1019787:	call   1027570 <free@plt>
 101978c:	mov    %r14d,%eax
 101978f:	add    $0x30,%rsp
 1019793:	pop    %rbx
 1019794:	pop    %r12
 1019796:	pop    %r14
 1019798:	pop    %r15
 101979a:	pop    %rbp
 101979b:	ret
 101979c:	vzeroupper
 101979f:	call   10187d4 <myl_rc_invariant_failed>
 10197a4:	int3
 10197a5:	int3
 10197a6:	int3
 10197a7:	int3
 10197a8:	int3
 10197a9:	int3
 10197aa:	int3
 10197ab:	int3
 10197ac:	int3
 10197ad:	int3
 10197ae:	int3
 10197af:	int3

00000000010197b0 <builder_add>:
 10197b0:	push   %rbp
 10197b1:	mov    %rsp,%rbp
 10197b4:	push   %r15
 10197b6:	push   %r14
 10197b8:	push   %r13
 10197ba:	push   %r12
 10197bc:	push   %rbx
 10197bd:	sub    $0x48,%rsp
 10197c1:	test   %rsi,%rsi
 10197c4:	je     1019bb8 <builder_add+0x408>
 10197ca:	movabs $0xbf58476d1ce4e5b9,%r12
 10197d4:	mov    0x20(%rdi),%rbx
 10197d8:	test   %rbx,%rbx
 10197db:	je     101983e <builder_add+0x8e>
 10197dd:	mov    0x10(%rdi),%rax
 10197e1:	mov    %rsi,%rcx
 10197e4:	shr    $0x3,%rcx
 10197e8:	mov    %rsi,%rdx
 10197eb:	shr    $0x21,%rdx
 10197ef:	xor    %rcx,%rdx
 10197f2:	imul   %r12,%rdx
 10197f6:	mov    %rdx,%rcx
 10197f9:	shr    $0x1b,%rcx
 10197fd:	xor    %rdx,%rcx
 1019800:	lea    -0x1(,%rbx,2),%rdx
 1019808:	and    %rdx,%rcx
 101980b:	mov    (%rax,%rcx,8),%r9
 101980f:	test   %r9,%r9
 1019812:	je     101983e <builder_add+0x8e>
 1019814:	mov    0x8(%rdi),%r8
 1019818:	nopl   0x0(%rax,%rax,1)
 1019820:	lea    (%r9,%r9,4),%r9
 1019824:	cmp    %rsi,-0x28(%r8,%r9,8)
 1019829:	je     10198ed <builder_add+0x13d>
 101982f:	inc    %rcx
 1019832:	and    %rdx,%rcx
 1019835:	mov    (%rax,%rcx,8),%r9
 1019839:	test   %r9,%r9
 101983c:	jne    1019820 <builder_add+0x70>
 101983e:	mov    0x18(%rdi),%rax
 1019842:	cmp    %rbx,%rax
 1019845:	jne    1019878 <builder_add+0xc8>
 1019847:	lea    (%rbx,%rbx,1),%rax
 101984b:	test   %rbx,%rbx
 101984e:	mov    $0x10,%r15d
 1019854:	cmovne %rax,%r15
 1019858:	xor    %eax,%eax
 101985a:	cmp    %rbx,%r15
 101985d:	jb     10198f2 <builder_add+0x142>
 1019863:	mov    $0x28,%ecx
 1019868:	mov    %r15,%rax
 101986b:	mul    %rcx
 101986e:	jno    1019901 <builder_add+0x151>
 1019874:	xor    %eax,%eax
 1019876:	jmp    10198f2 <builder_add+0x142>
 1019878:	mov    0x8(%rdi),%rcx
 101987c:	mov    0x10(%rdi),%r14
 1019880:	mov    %rsi,%rdx
 1019883:	shr    $0x3,%rdx
 1019887:	mov    %rsi,%r8
 101988a:	shr    $0x21,%r8
 101988e:	xor    %rdx,%r8
 1019891:	imul   %r12,%r8
 1019895:	mov    %r8,%rdx
 1019898:	shr    $0x1b,%rdx
 101989c:	xor    %r8,%rdx
 101989f:	lea    -0x1(,%rbx,2),%r8
 10198a7:	and    %r8,%rdx
 10198aa:	mov    (%r14,%rdx,8),%r9
 10198ae:	test   %r9,%r9
 10198b1:	je     10198da <builder_add+0x12a>
 10198b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10198c0:	lea    (%r9,%r9,4),%r9
 10198c4:	cmp    %rsi,-0x28(%rcx,%r9,8)
 10198c9:	je     10198da <builder_add+0x12a>
 10198cb:	inc    %rdx
 10198ce:	and    %r8,%rdx
 10198d1:	mov    (%r14,%rdx,8),%r9
 10198d5:	test   %r9,%r9
 10198d8:	jne    10198c0 <builder_add+0x110>
 10198da:	lea    (%rax,%rax,4),%r8
 10198de:	mov    %rsi,(%rcx,%r8,8)
 10198e2:	inc    %rax
 10198e5:	mov    %rax,0x18(%rdi)
 10198e9:	mov    %rax,(%r14,%rdx,8)
 10198ed:	mov    $0x1,%eax
 10198f2:	add    $0x48,%rsp
 10198f6:	pop    %rbx
 10198f7:	pop    %r12
 10198f9:	pop    %r13
 10198fb:	pop    %r14
 10198fd:	pop    %r15
 10198ff:	pop    %rbp
 1019900:	ret
 1019901:	mov    (%rdi),%r12
 1019904:	test   %r12,%r12
 1019907:	je     1019bb8 <builder_add+0x408>
 101990d:	test   %rax,%rax
 1019910:	je     1019bb8 <builder_add+0x408>
 1019916:	mov    0x1608(%r12),%rcx
 101991e:	test   %rcx,%rcx
 1019921:	je     1019bb8 <builder_add+0x408>
 1019927:	mov    0x18(%r12),%rdx
 101992c:	mov    %rdx,%r13
 101992f:	add    %rax,%r13
 1019932:	jb     1019943 <builder_add+0x193>
 1019934:	mov    0x58(%r12),%r14
 1019939:	test   %r14,%r14
 101993c:	je     1019950 <builder_add+0x1a0>
 101993e:	cmp    %r14,%r13
 1019941:	jbe    1019950 <builder_add+0x1a0>
 1019943:	movl   $0x1,0x6c(%r12)
 101994c:	xor    %eax,%eax
 101994e:	jmp    10198f2 <builder_add+0x142>
 1019950:	mov    %rdx,-0x70(%rbp)
 1019954:	mov    %rcx,-0x58(%rbp)
 1019958:	mov    %rsi,-0x38(%rbp)
 101995c:	mov    %rdi,-0x40(%rbp)
 1019960:	mov    $0x1,%edi
 1019965:	mov    %rax,-0x30(%rbp)
 1019969:	mov    %rax,%rsi
 101996c:	call   1027510 <calloc@plt>
 1019971:	test   %rax,%rax
 1019974:	je     1019874 <builder_add+0xc4>
 101997a:	mov    %r13,0x18(%r12)
 101997f:	mov    -0x58(%rbp),%rdx
 1019983:	mov    0x30(%rdx),%r8
 1019987:	mov    -0x30(%rbp),%rcx
 101998b:	lea    (%r8,%rcx,1),%r9
 101998f:	mov    %r9,0x30(%rdx)
 1019993:	test   %r15,%r15
 1019996:	je     1019bb8 <builder_add+0x408>
 101999c:	mov    %r15,%rsi
 101999f:	shl    $0x4,%rsi
 10199a3:	mov    %r13,%rdi
 10199a6:	add    %rsi,%rdi
 10199a9:	jb     10199b5 <builder_add+0x205>
 10199ab:	test   %r14,%r14
 10199ae:	je     10199ea <builder_add+0x23a>
 10199b0:	cmp    %r14,%rdi
 10199b3:	jbe    10199ea <builder_add+0x23a>
 10199b5:	movl   $0x1,0x6c(%r12)
 10199be:	cmp    %rcx,%r13
 10199c1:	jb     1019bb8 <builder_add+0x408>
 10199c7:	cmp    %rcx,%r9
 10199ca:	jb     1019bb8 <builder_add+0x408>
 10199d0:	mov    -0x70(%rbp),%rcx
 10199d4:	mov    %rcx,0x18(%r12)
 10199d9:	mov    %r8,0x30(%rdx)
 10199dd:	mov    %rax,%rdi
 10199e0:	call   1027570 <free@plt>
 10199e5:	jmp    1019874 <builder_add+0xc4>
 10199ea:	mov    %rdi,-0x60(%rbp)
 10199ee:	mov    $0x1,%edi
 10199f3:	mov    %r9,-0x50(%rbp)
 10199f7:	mov    %rax,-0x48(%rbp)
 10199fb:	mov    %r8,%r14
 10199fe:	mov    %rsi,-0x68(%rbp)
 1019a02:	call   1027510 <calloc@plt>
 1019a07:	mov    %r14,%r8
 1019a0a:	mov    -0x50(%rbp),%r9
 1019a0e:	mov    -0x58(%rbp),%rdx
 1019a12:	mov    %rax,%r14
 1019a15:	mov    -0x30(%rbp),%rcx
 1019a19:	mov    -0x48(%rbp),%rax
 1019a1d:	test   %r14,%r14
 1019a20:	je     10199be <builder_add+0x20e>
 1019a22:	add    -0x68(%rbp),%r9
 1019a26:	mov    -0x60(%rbp),%rdi
 1019a2a:	mov    %rdi,0x18(%r12)
 1019a2f:	mov    %r9,-0x50(%rbp)
 1019a33:	mov    %r9,0x30(%rdx)
 1019a37:	mov    -0x40(%rbp),%rcx
 1019a3b:	mov    0x8(%rcx),%r8
 1019a3f:	test   %rbx,%rbx
 1019a42:	je     1019a6b <builder_add+0x2bb>
 1019a44:	lea    0x0(,%rbx,8),%rcx
 1019a4c:	lea    (%rcx,%rcx,4),%rdx
 1019a50:	mov    %rax,%rdi
 1019a53:	mov    %r8,%rsi
 1019a56:	mov    %r8,%r13
 1019a59:	mov    %rdx,-0x30(%rbp)
 1019a5d:	call   1027520 <memcpy@plt>
 1019a62:	mov    %r13,%r8
 1019a65:	mov    -0x60(%rbp),%rdi
 1019a69:	jmp    1019a73 <builder_add+0x2c3>
 1019a6b:	movq   $0x0,-0x30(%rbp)
 1019a73:	mov    -0x38(%rbp),%rsi
 1019a77:	test   %r8,%r8
 1019a7a:	je     1019abc <builder_add+0x30c>
 1019a7c:	mov    -0x30(%rbp),%rax
 1019a80:	sub    %rax,%rdi
 1019a83:	mov    -0x50(%rbp),%r13
 1019a87:	jb     1019bb8 <builder_add+0x408>
 1019a8d:	sub    %rax,%r13
 1019a90:	jb     1019bb8 <builder_add+0x408>
 1019a96:	mov    %rdi,0x18(%r12)
 1019a9b:	mov    -0x58(%rbp),%rax
 1019a9f:	mov    %r13,0x30(%rax)
 1019aa3:	mov    %r8,%rdi
 1019aa6:	call   1027570 <free@plt>
 1019aab:	mov    -0x40(%rbp),%rdi
 1019aaf:	mov    (%rdi),%r12
 1019ab2:	mov    0x20(%rdi),%rbx
 1019ab6:	mov    -0x38(%rbp),%rsi
 1019aba:	jmp    1019ac0 <builder_add+0x310>
 1019abc:	mov    -0x40(%rbp),%rdi
 1019ac0:	mov    0x10(%rdi),%rax
 1019ac4:	test   %rax,%rax
 1019ac7:	mov    -0x48(%rbp),%rcx
 1019acb:	je     1019b11 <builder_add+0x361>
 1019acd:	shl    $0x4,%rbx
 1019ad1:	mov    0x18(%r12),%rcx
 1019ad6:	sub    %rbx,%rcx
 1019ad9:	jb     1019bb8 <builder_add+0x408>
 1019adf:	mov    0x1608(%r12),%rdx
 1019ae7:	mov    0x30(%rdx),%rsi
 1019aeb:	sub    %rbx,%rsi
 1019aee:	jb     1019bb8 <builder_add+0x408>
 1019af4:	mov    %rcx,0x18(%r12)
 1019af9:	mov    %rsi,0x30(%rdx)
 1019afd:	mov    %rax,%rdi
 1019b00:	call   1027570 <free@plt>
 1019b05:	mov    -0x40(%rbp),%rdi
 1019b09:	mov    -0x38(%rbp),%rsi
 1019b0d:	mov    -0x48(%rbp),%rcx
 1019b11:	mov    %rcx,0x8(%rdi)
 1019b15:	mov    %r14,0x10(%rdi)
 1019b19:	mov    %r15,0x20(%rdi)
 1019b1d:	mov    0x18(%rdi),%rax
 1019b21:	test   %rax,%rax
 1019b24:	je     1019ba4 <builder_add+0x3f4>
 1019b26:	lea    -0x1(,%r15,2),%rdx
 1019b2e:	xor    %r8d,%r8d
 1019b31:	movabs $0xbf58476d1ce4e5b9,%r12
 1019b3b:	jmp    1019b49 <builder_add+0x399>
 1019b3d:	inc    %r8
 1019b40:	mov    %r8,(%r14,%r9,8)
 1019b44:	cmp    %rax,%r8
 1019b47:	je     1019b9c <builder_add+0x3ec>
 1019b49:	lea    (%r8,%r8,4),%r9
 1019b4d:	mov    (%rcx,%r9,8),%r10
 1019b51:	mov    %r10,%r9
 1019b54:	shr    $0x3,%r9
 1019b58:	mov    %r10,%r11
 1019b5b:	shr    $0x21,%r11
 1019b5f:	xor    %r9,%r11
 1019b62:	imul   %r12,%r11
 1019b66:	mov    %r11,%r9
 1019b69:	shr    $0x1b,%r9
 1019b6d:	xor    %r11,%r9
 1019b70:	and    %rdx,%r9
 1019b73:	mov    (%r14,%r9,8),%r11
 1019b77:	test   %r11,%r11
 1019b7a:	je     1019b3d <builder_add+0x38d>
 1019b7c:	nopl   0x0(%rax)
 1019b80:	lea    (%r11,%r11,4),%r11
 1019b84:	cmp    %r10,-0x28(%rcx,%r11,8)
 1019b89:	je     1019b3d <builder_add+0x38d>
 1019b8b:	inc    %r9
 1019b8e:	and    %rdx,%r9
 1019b91:	mov    (%r14,%r9,8),%r11
 1019b95:	test   %r11,%r11
 1019b98:	jne    1019b80 <builder_add+0x3d0>
 1019b9a:	jmp    1019b3d <builder_add+0x38d>
 1019b9c:	mov    %r15,%rbx
 1019b9f:	jmp    1019880 <builder_add+0xd0>
 1019ba4:	xor    %eax,%eax
 1019ba6:	mov    %r15,%rbx
 1019ba9:	movabs $0xbf58476d1ce4e5b9,%r12
 1019bb3:	jmp    1019880 <builder_add+0xd0>
 1019bb8:	call   10187d4 <myl_rc_invariant_failed>
 1019bbd:	int3
 1019bbe:	int3
 1019bbf:	int3

0000000001019bc0 <register_shapes>:
 1019bc0:	push   %rbp
 1019bc1:	mov    %rsp,%rbp
 1019bc4:	push   %r15
 1019bc6:	push   %r14
 1019bc8:	push   %r13
 1019bca:	push   %r12
 1019bcc:	push   %rbx
 1019bcd:	sub    $0x78,%rsp
 1019bd1:	mov    %edx,%r10d
 1019bd4:	mov    %rdi,%r15
 1019bd7:	mov    (%rdi),%r9
 1019bda:	mov    0x18(%rdi),%r8
 1019bde:	test   %r8,%r8
 1019be1:	mov    %rdi,-0x48(%rbp)
 1019be5:	je     1019e04 <register_shapes+0x244>
 1019beb:	xor    %ebx,%ebx
 1019bed:	jmp    1019c1c <register_shapes+0x5c>
 1019bef:	mov    -0x48(%rbp),%r15
 1019bf3:	mov    0x18(%r15),%r8
 1019bf7:	mov    -0x40(%rbp),%rsi
 1019bfb:	mov    -0x38(%rbp),%r9
 1019bff:	mov    -0x2c(%rbp),%r10d
 1019c03:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019c10:	inc    %rbx
 1019c13:	cmp    %r8,%rbx
 1019c16:	jae    1019da3 <register_shapes+0x1e3>
 1019c1c:	mov    0x8(%r15),%rax
 1019c20:	lea    (%rbx,%rbx,4),%rcx
 1019c24:	mov    (%rax,%rcx,8),%r14
 1019c28:	mov    0x8(%r14),%eax
 1019c2c:	cmp    $0x5,%rax
 1019c30:	ja     101a5e8 <register_shapes+0xa28>
 1019c36:	jmp    *0x1001a80(,%rax,8)
 1019c3d:	cmpq   $0x8,(%r14)
 1019c41:	jne    101a5e8 <register_shapes+0xa28>
 1019c47:	cmp    $0x2,%eax
 1019c4a:	je     1019c51 <register_shapes+0x91>
 1019c4c:	cmp    $0x4,%eax
 1019c4f:	jne    1019c10 <register_shapes+0x50>
 1019c51:	mov    0x10(%r14),%rcx
 1019c55:	xor    %r12d,%r12d
 1019c58:	jmp    1019c82 <register_shapes+0xc2>
 1019c5a:	nopw   0x0(%rax,%rax,1)
 1019c60:	mov    0x10(%r14),%rcx
 1019c64:	mov    0x18(%r14),%r12
 1019c68:	test   %r12,%r12
 1019c6b:	setne  %dl
 1019c6e:	test   %rcx,%rcx
 1019c71:	sete   %dil
 1019c75:	and    %dl,%dil
 1019c78:	cmp    $0x1,%dil
 1019c7c:	je     101a5e8 <register_shapes+0xa28>
 1019c82:	cmp    $0x4,%eax
 1019c85:	jne    1019c9e <register_shapes+0xde>
 1019c87:	mov    0x20(%r14),%rax
 1019c8b:	add    $0x4,%rax
 1019c8f:	jb     1019e31 <register_shapes+0x271>
 1019c95:	cmp    (%r14),%rax
 1019c98:	ja     101a5e8 <register_shapes+0xa28>
 1019c9e:	mov    $0x1,%eax
 1019ca3:	add    %r12,0x28(%r15)
 1019ca7:	jb     1019e36 <register_shapes+0x276>
 1019cad:	test   %r12,%r12
 1019cb0:	je     1019c10 <register_shapes+0x50>
 1019cb6:	add    $0x8,%rcx
 1019cba:	mov    %r12,%rdx
 1019cbd:	nopl   (%rax)
 1019cc0:	mov    (%rcx),%rdi
 1019cc3:	test   %rdi,%rdi
 1019cc6:	je     101a5e8 <register_shapes+0xa28>
 1019ccc:	mov    -0x8(%rcx),%r8
 1019cd0:	add    (%rdi),%r8
 1019cd3:	jb     1019e36 <register_shapes+0x276>
 1019cd9:	cmp    (%r14),%r8
 1019cdc:	ja     101a5e8 <register_shapes+0xa28>
 1019ce2:	add    $0x18,%rcx
 1019ce6:	dec    %rdx
 1019ce9:	jne    1019cc0 <register_shapes+0x100>
 1019ceb:	mov    %r10d,-0x2c(%rbp)
 1019cef:	mov    %r9,-0x38(%rbp)
 1019cf3:	mov    %rsi,-0x40(%rbp)
 1019cf7:	jmp    1019d5b <register_shapes+0x19b>
 1019cf9:	mov    0x18(%r14),%rax
 1019cfd:	test   %rax,%rax
 1019d00:	je     1019c10 <register_shapes+0x50>
 1019d06:	mov    0x10(%r14),%rdx
 1019d0a:	test   %rdx,%rdx
 1019d0d:	je     101a5e8 <register_shapes+0xa28>
 1019d13:	mov    0x20(%r14),%rcx
 1019d17:	mov    (%rdx),%rdi
 1019d1a:	cmp    %rdi,%rcx
 1019d1d:	jb     101a5e8 <register_shapes+0xa28>
 1019d23:	dec    %rax
 1019d26:	mul    %rcx
 1019d29:	mov    %rax,%rcx
 1019d2c:	mov    $0x1,%eax
 1019d31:	jo     1019e36 <register_shapes+0x276>
 1019d37:	add    %rdi,%rcx
 1019d3a:	jb     1019e36 <register_shapes+0x276>
 1019d40:	mov    %r10d,-0x2c(%rbp)
 1019d44:	mov    %r9,-0x38(%rbp)
 1019d48:	mov    %rsi,-0x40(%rbp)
 1019d4c:	mov    $0x1,%r12d
 1019d52:	cmp    (%r14),%rcx
 1019d55:	ja     101a5e8 <register_shapes+0xa28>
 1019d5b:	lea    0x10(%r14),%r13
 1019d5f:	mov    $0x8,%r15d
 1019d65:	data16 cs nopw 0x0(%rax,%rax,1)
 1019d70:	cmpl   $0x3,0x8(%r14)
 1019d75:	mov    %r13,%rax
 1019d78:	je     1019d81 <register_shapes+0x1c1>
 1019d7a:	mov    0x0(%r13),%rax
 1019d7e:	add    %r15,%rax
 1019d81:	mov    (%rax),%rsi
 1019d84:	mov    -0x48(%rbp),%rdi
 1019d88:	call   10197b0 <builder_add>
 1019d8d:	test   %eax,%eax
 1019d8f:	je     1019e31 <register_shapes+0x271>
 1019d95:	add    $0x18,%r15
 1019d99:	dec    %r12
 1019d9c:	jne    1019d70 <register_shapes+0x1b0>
 1019d9e:	jmp    1019bef <register_shapes+0x2f>
 1019da3:	mov    %r8,%rax
 1019da6:	shr    $0x3d,%rax
 1019daa:	mov    $0x1,%eax
 1019daf:	jne    1019e36 <register_shapes+0x276>
 1019db5:	test   %r8,%r8
 1019db8:	je     1019e04 <register_shapes+0x244>
 1019dba:	mov    %r10d,-0x2c(%rbp)
 1019dbe:	mov    %r9,-0x38(%rbp)
 1019dc2:	mov    %rsi,-0x40(%rbp)
 1019dc6:	shl    $0x3,%r8
 1019dca:	mov    (%r15),%rdi
 1019dcd:	mov    %r8,-0x58(%rbp)
 1019dd1:	mov    %r8,%rsi
 1019dd4:	call   10187e0 <myl_rc_meta_alloc>
 1019dd9:	test   %rax,%rax
 1019ddc:	je     1019e31 <register_shapes+0x271>
 1019dde:	mov    0x18(%r15),%rcx
 1019de2:	test   %rcx,%rcx
 1019de5:	je     101a588 <register_shapes+0x9c8>
 1019deb:	mov    0x8(%r15),%rdx
 1019def:	xor    %r12d,%r12d
 1019df2:	movabs $0x9e3779b97f4a7c15,%rbx
 1019dfc:	xor    %edi,%edi
 1019dfe:	mov    %rcx,-0x50(%rbp)
 1019e02:	jmp    1019e55 <register_shapes+0x295>
 1019e04:	xor    %edi,%edi
 1019e06:	xor    %r12d,%r12d
 1019e09:	mov    $0x18,%eax
 1019e0e:	mulq   0x28(%r15)
 1019e12:	mov    %rax,%r14
 1019e15:	mov    $0x1,%eax
 1019e1a:	jo     1019e36 <register_shapes+0x276>
 1019e1c:	mov    0x20(%rsi),%r8
 1019e20:	mov    $0xc8,%ecx
 1019e25:	mov    %r8,%rax
 1019e28:	mul    %rcx
 1019e2b:	jno    101a09b <register_shapes+0x4db>
 1019e31:	mov    $0x1,%eax
 1019e36:	add    $0x78,%rsp
 1019e3a:	pop    %rbx
 1019e3b:	pop    %r12
 1019e3d:	pop    %r13
 1019e3f:	pop    %r14
 1019e41:	pop    %r15
 1019e43:	pop    %rbp
 1019e44:	ret
 1019e45:	inc    %rdi
 1019e48:	mov    -0x50(%rbp),%rcx
 1019e4c:	cmp    %rcx,%rdi
 1019e4f:	jae    101a58b <register_shapes+0x9cb>
 1019e55:	lea    (%rdi,%rdi,4),%rcx
 1019e59:	cmpl   $0x2,0x20(%rdx,%rcx,8)
 1019e5e:	je     1019e45 <register_shapes+0x285>
 1019e60:	mov    %rdi,(%rax)
 1019e63:	mov    $0x1,%r8d
 1019e69:	jmp    1019e8b <register_shapes+0x2cb>
 1019e6b:	nopl   0x0(%rax,%rax,1)
 1019e70:	mov    -0x48(%rbp),%r15
 1019e74:	cmp    %r12,%r10
 1019e77:	cmova  %r10,%r12
 1019e7b:	movl   $0x2,0x20(%r9)
 1019e83:	dec    %r8
 1019e86:	test   %r8,%r8
 1019e89:	je     1019e45 <register_shapes+0x285>
 1019e8b:	mov    -0x8(%rax,%r8,8),%rcx
 1019e90:	lea    (%rcx,%rcx,4),%r10
 1019e94:	movl   $0x1,0x20(%rdx,%r10,8)
 1019e9d:	mov    (%rdx,%r10,8),%r11
 1019ea1:	mov    0x8(%r11),%ecx
 1019ea5:	cmp    $0x5,%rcx
 1019ea9:	ja     101a5e8 <register_shapes+0xa28>
 1019eaf:	lea    (%rdx,%r10,8),%r9
 1019eb3:	mov    0x8(%rdx,%r10,8),%r10
 1019eb8:	jmp    *0x1001ab0(,%rcx,8)
 1019ebf:	movq   $0x1,0x10(%r9)
 1019ec7:	jmp    1019fa0 <register_shapes+0x3e0>
 1019ecc:	nopl   0x0(%rax)
 1019ed0:	cmp    0x18(%r11),%r10
 1019ed4:	jae    1019f90 <register_shapes+0x3d0>
 1019eda:	add    $0x10,%r11
 1019ede:	cmp    $0x3,%ecx
 1019ee1:	je     1019f0c <register_shapes+0x34c>
 1019ee3:	mov    (%r11),%rcx
 1019ee6:	lea    (%r10,%r10,2),%r11
 1019eea:	lea    (%rcx,%r11,8),%r11
 1019eee:	add    $0x8,%r11
 1019ef2:	jmp    1019f0c <register_shapes+0x34c>
 1019ef4:	test   %r10,%r10
 1019ef7:	jne    1019f90 <register_shapes+0x3d0>
 1019efd:	cmpq   $0x0,0x18(%r11)
 1019f02:	je     1019f90 <register_shapes+0x3d0>
 1019f08:	add    $0x10,%r11
 1019f0c:	mov    (%r11),%r11
 1019f0f:	mov    0x10(%r15),%r14
 1019f13:	mov    0x20(%r15),%rcx
 1019f17:	mov    %r11,%rbx
 1019f1a:	shr    $0x3,%rbx
 1019f1e:	mov    %r11,%r13
 1019f21:	shr    $0x21,%r13
 1019f25:	xor    %rbx,%r13
 1019f28:	movabs $0xbf58476d1ce4e5b9,%rsi
 1019f32:	imul   %rsi,%r13
 1019f36:	mov    %r13,%r15
 1019f39:	shr    $0x1b,%r15
 1019f3d:	xor    %r13,%r15
 1019f40:	lea    -0x1(,%rcx,2),%rbx
 1019f48:	and    %rbx,%r15
 1019f4b:	mov    (%r14,%r15,8),%r13
 1019f4f:	mov    $0xffffffffffffffff,%rcx
 1019f56:	test   %r13,%r13
 1019f59:	je     101a035 <register_shapes+0x475>
 1019f5f:	nop
 1019f60:	lea    0x0(,%r13,4),%rsi
 1019f68:	add    %r13,%rsi
 1019f6b:	cmp    %r11,-0x28(%rdx,%rsi,8)
 1019f70:	je     101a02f <register_shapes+0x46f>
 1019f76:	inc    %r15
 1019f79:	and    %rbx,%r15
 1019f7c:	mov    (%r14,%r15,8),%r13
 1019f80:	test   %r13,%r13
 1019f83:	jne    1019f60 <register_shapes+0x3a0>
 1019f85:	jmp    101a035 <register_shapes+0x475>
 1019f8a:	nopw   0x0(%rax,%rax,1)
 1019f90:	mov    0x10(%r9),%rcx
 1019f94:	test   %rcx,%rcx
 1019f97:	je     1019fa0 <register_shapes+0x3e0>
 1019f99:	inc    %rcx
 1019f9c:	mov    %rcx,0x10(%r9)
 1019fa0:	mov    0x18(%r9),%r10
 1019fa4:	inc    %r10
 1019fa7:	mov    %r10,0x18(%r9)
 1019fab:	mov    (%r15),%rcx
 1019fae:	mov    0x1608(%rcx),%rcx
 1019fb5:	mov    0x58(%rcx),%r14
 1019fb9:	mov    0x60(%rcx),%r15
 1019fbd:	movzbl 0x70(%rcx),%ecx
 1019fc1:	mov    %r11,%rsi
 1019fc4:	imul   %rbx,%rsi
 1019fc8:	shrx   %rcx,%rsi,%r13
 1019fcd:	nopl   (%rax)
 1019fd0:	and    %r15,%r13
 1019fd3:	mov    %r13,%rcx
 1019fd6:	shl    $0x4,%rcx
 1019fda:	mov    (%r14,%rcx,1),%rcx
 1019fde:	cmp    %r11,%rcx
 1019fe1:	je     101a000 <register_shapes+0x440>
 1019fe3:	test   %rcx,%rcx
 1019fe6:	je     1019e70 <register_shapes+0x2b0>
 1019fec:	inc    %r13
 1019fef:	jmp    1019fd0 <register_shapes+0x410>
 1019ff1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a000:	shl    $0x4,%r13
 101a004:	mov    0x8(%r14,%r13,1),%rcx
 101a009:	test   %rcx,%rcx
 101a00c:	je     1019e70 <register_shapes+0x2b0>
 101a012:	mov    0x30(%rcx),%rcx
 101a016:	cmp    %r10,%rcx
 101a019:	mov    -0x48(%rbp),%r15
 101a01d:	jbe    1019e74 <register_shapes+0x2b4>
 101a023:	mov    %rcx,0x18(%r9)
 101a027:	mov    %rcx,%r10
 101a02a:	jmp    1019e74 <register_shapes+0x2b4>
 101a02f:	dec    %r13
 101a032:	mov    %r13,%rcx
 101a035:	lea    (%rcx,%rcx,4),%r11
 101a039:	mov    0x20(%rdx,%r11,8),%ebx
 101a03e:	test   %ebx,%ebx
 101a040:	mov    -0x48(%rbp),%r15
 101a044:	je     101a085 <register_shapes+0x4c5>
 101a046:	cmp    $0x1,%ebx
 101a049:	je     101a5e8 <register_shapes+0xa28>
 101a04f:	lea    (%rdx,%r11,8),%rcx
 101a053:	mov    0x10(%rcx),%r11
 101a057:	cmp    0x10(%r9),%r11
 101a05b:	jbe    101a061 <register_shapes+0x4a1>
 101a05d:	mov    %r11,0x10(%r9)
 101a061:	mov    0x18(%rcx),%rcx
 101a065:	cmp    0x18(%r9),%rcx
 101a069:	movabs $0x9e3779b97f4a7c15,%rbx
 101a073:	jbe    101a079 <register_shapes+0x4b9>
 101a075:	mov    %rcx,0x18(%r9)
 101a079:	inc    %r10
 101a07c:	mov    %r10,0x8(%r9)
 101a080:	jmp    1019e86 <register_shapes+0x2c6>
 101a085:	mov    %rcx,(%rax,%r8,8)
 101a089:	inc    %r8
 101a08c:	movabs $0x9e3779b97f4a7c15,%rbx
 101a096:	jmp    1019e86 <register_shapes+0x2c6>
 101a09b:	mov    %rax,%rcx
 101a09e:	mov    %rdi,%rbx
 101a0a1:	add    $0x40,%rbx
 101a0a5:	mov    $0x1,%eax
 101a0aa:	jb     1019e36 <register_shapes+0x276>
 101a0b0:	add    %r14,%rbx
 101a0b3:	jb     1019e36 <register_shapes+0x276>
 101a0b9:	add    %rcx,%rbx
 101a0bc:	jb     1019e36 <register_shapes+0x276>
 101a0c2:	mov    %r8,-0x60(%rbp)
 101a0c6:	mov    %rdi,-0x50(%rbp)
 101a0ca:	mov    %r10d,-0x2c(%rbp)
 101a0ce:	mov    %r9,-0x38(%rbp)
 101a0d2:	mov    %r15,%r13
 101a0d5:	mov    %rsi,%r15
 101a0d8:	mov    0x0(%r13),%rdi
 101a0dc:	mov    %rbx,%rsi
 101a0df:	call   10187e0 <myl_rc_meta_alloc>
 101a0e4:	test   %rax,%rax
 101a0e7:	je     1019e31 <register_shapes+0x271>
 101a0ed:	xor    %ecx,%ecx
 101a0ef:	mov    -0x2c(%rbp),%r10d
 101a0f3:	test   %r10d,%r10d
 101a0f6:	mov    %r15,-0x40(%rbp)
 101a0fa:	cmovne %r15,%rcx
 101a0fe:	mov    %rcx,0x8(%rax)
 101a102:	mov    0x18(%r13),%rsi
 101a106:	mov    %rsi,0x20(%rax)
 101a10a:	mov    -0x60(%rbp),%rcx
 101a10e:	mov    %rcx,0x28(%rax)
 101a112:	mov    %rbx,0x30(%rax)
 101a116:	lea    0x40(%rax),%rcx
 101a11a:	mov    %rcx,0x10(%rax)
 101a11e:	mov    -0x50(%rbp),%rcx
 101a122:	lea    (%rax,%rcx,1),%rdx
 101a126:	add    $0x40,%rdx
 101a12a:	add    %rdx,%r14
 101a12d:	mov    %r14,0x18(%rax)
 101a131:	test   %rsi,%rsi
 101a134:	mov    %r13,%r15
 101a137:	mov    %rax,%r14
 101a13a:	je     101a383 <register_shapes+0x7c3>
 101a140:	xor    %esi,%esi
 101a142:	jmp    101a169 <register_shapes+0x5a9>
 101a144:	mov    -0x58(%rbp),%rax
 101a148:	mov    %rdx,0x18(%rax)
 101a14c:	lea    (%r9,%r9,2),%rax
 101a150:	lea    (%rdx,%rax,8),%rdx
 101a154:	mov    -0x2c(%rbp),%r10d
 101a158:	mov    -0x50(%rbp),%rsi
 101a15c:	inc    %rsi
 101a15f:	cmp    0x18(%r15),%rsi
 101a163:	jae    101a383 <register_shapes+0x7c3>
 101a169:	lea    0x0(,%rsi,8),%rax
 101a171:	mov    0x10(%r14),%rcx
 101a175:	mov    %rsi,%rdi
 101a178:	shl    $0x6,%rdi
 101a17c:	lea    (%rcx,%rdi,1),%r13
 101a180:	test   %r10d,%r10d
 101a183:	mov    0x8(%r15),%r8
 101a187:	lea    (%rax,%rax,4),%rax
 101a18b:	mov    (%r8,%rax,1),%r8
 101a18f:	mov    $0x0,%r9d
 101a195:	cmovne %r8,%r9
 101a199:	mov    %r9,(%rcx,%rdi,1)
 101a19d:	vmovups (%r8),%ymm0
 101a1a2:	vmovups %ymm0,0x8(%rcx,%rdi,1)
 101a1a8:	mov    0x20(%r8),%r9
 101a1ac:	mov    %r9,0x28(%rcx,%rdi,1)
 101a1b1:	mov    0x8(%r15),%r9
 101a1b5:	vmovups 0x10(%r9,%rax,1),%xmm0
 101a1bc:	cmpq   $0x0,0x10(%r9,%rax,1)
 101a1c2:	vmovups %xmm0,0x30(%rcx,%rdi,1)
 101a1c8:	je     101a26e <register_shapes+0x6ae>
 101a1ce:	mov    0x8(%r8),%eax
 101a1d2:	cmp    $0x3,%eax
 101a1d5:	jne    101a283 <register_shapes+0x6c3>
 101a1db:	cmpq   $0x0,0x18(%r8)
 101a1e0:	je     101a15c <register_shapes+0x59c>
 101a1e6:	mov    0x10(%r8),%r10
 101a1ea:	mov    0x10(%r15),%r11
 101a1ee:	mov    0x20(%r15),%rax
 101a1f2:	mov    %r10,%rcx
 101a1f5:	shr    $0x3,%rcx
 101a1f9:	mov    %r10,%rdi
 101a1fc:	shr    $0x21,%rdi
 101a200:	xor    %rcx,%rdi
 101a203:	movabs $0xbf58476d1ce4e5b9,%rcx
 101a20d:	imul   %rcx,%rdi
 101a211:	mov    %rdi,%rbx
 101a214:	shr    $0x1b,%rbx
 101a218:	xor    %rdi,%rbx
 101a21b:	lea    -0x1(,%rax,2),%rax
 101a223:	and    %rax,%rbx
 101a226:	mov    (%r11,%rbx,8),%rdi
 101a22a:	test   %rdi,%rdi
 101a22d:	je     101a24a <register_shapes+0x68a>
 101a22f:	nop
 101a230:	lea    (%rdi,%rdi,4),%rcx
 101a234:	cmp    %r10,-0x28(%r9,%rcx,8)
 101a239:	je     101a24c <register_shapes+0x68c>
 101a23b:	inc    %rbx
 101a23e:	and    %rax,%rbx
 101a241:	mov    (%r11,%rbx,8),%rdi
 101a245:	test   %rdi,%rdi
 101a248:	jne    101a230 <register_shapes+0x670>
 101a24a:	xor    %edi,%edi
 101a24c:	mov    0x10(%r14),%rax
 101a250:	shl    $0x6,%rdi
 101a254:	add    %rdi,%rax
 101a257:	add    $0xffffffffffffffc8,%rax
 101a25b:	mov    %rax,0x18(%r13)
 101a25f:	mov    0x8(%r8),%eax
 101a263:	mov    -0x2c(%rbp),%r10d
 101a267:	cmp    $0x4,%eax
 101a26a:	jne    101a288 <register_shapes+0x6c8>
 101a26c:	jmp    101a291 <register_shapes+0x6d1>
 101a26e:	movl   $0x0,0x10(%r13)
 101a276:	mov    0x8(%r8),%eax
 101a27a:	cmp    $0x3,%eax
 101a27d:	je     101a1db <register_shapes+0x61b>
 101a283:	cmp    $0x4,%eax
 101a286:	je     101a291 <register_shapes+0x6d1>
 101a288:	cmp    $0x2,%eax
 101a28b:	jne    101a15c <register_shapes+0x59c>
 101a291:	mov    %r13,-0x58(%rbp)
 101a295:	mov    %rsi,-0x50(%rbp)
 101a299:	mov    0x18(%r8),%r9
 101a29d:	test   %r9,%r9
 101a2a0:	je     101a144 <register_shapes+0x584>
 101a2a6:	mov    0x10(%r8),%r8
 101a2aa:	xor    %r10d,%r10d
 101a2ad:	jmp    101a2db <register_shapes+0x71b>
 101a2af:	nop
 101a2b0:	xor    %eax,%eax
 101a2b2:	add    %rdx,%r11
 101a2b5:	mov    %rsi,%r14
 101a2b8:	mov    0x10(%rsi),%rcx
 101a2bc:	shl    $0x6,%rax
 101a2c0:	add    %rcx,%rax
 101a2c3:	add    $0xffffffffffffffc8,%rax
 101a2c7:	mov    %rax,0x8(%r11)
 101a2cb:	inc    %r10
 101a2ce:	cmp    %r9,%r10
 101a2d1:	mov    -0x48(%rbp),%r15
 101a2d5:	je     101a144 <register_shapes+0x584>
 101a2db:	mov    %r14,%rsi
 101a2de:	lea    0x0(,%r10,8),%rax
 101a2e6:	lea    (%rax,%rax,2),%r11
 101a2ea:	mov    0x10(%r8,%r11,1),%rax
 101a2ef:	mov    %rax,0x10(%rdx,%r11,1)
 101a2f4:	vmovups (%r8,%r11,1),%xmm0
 101a2fa:	vmovups %xmm0,(%rdx,%r11,1)
 101a300:	mov    0x8(%r8,%r11,1),%rbx
 101a305:	mov    0x10(%r15),%r14
 101a309:	mov    0x20(%r15),%rax
 101a30d:	mov    %rbx,%rcx
 101a310:	shr    $0x3,%rcx
 101a314:	mov    %rbx,%rdi
 101a317:	shr    $0x21,%rdi
 101a31b:	xor    %rcx,%rdi
 101a31e:	movabs $0xbf58476d1ce4e5b9,%rcx
 101a328:	imul   %rcx,%rdi
 101a32c:	mov    %r15,%rcx
 101a32f:	mov    %rdi,%r15
 101a332:	shr    $0x1b,%r15
 101a336:	xor    %rdi,%r15
 101a339:	lea    -0x1(,%rax,2),%rdi
 101a341:	and    %rdi,%r15
 101a344:	mov    (%r14,%r15,8),%rax
 101a348:	test   %rax,%rax
 101a34b:	je     101a2b0 <register_shapes+0x6f0>
 101a351:	mov    0x8(%rcx),%rcx
 101a355:	data16 cs nopw 0x0(%rax,%rax,1)
 101a360:	lea    (%rax,%rax,4),%r13
 101a364:	cmp    %rbx,-0x28(%rcx,%r13,8)
 101a369:	je     101a2b2 <register_shapes+0x6f2>
 101a36f:	inc    %r15
 101a372:	and    %rdi,%r15
 101a375:	mov    (%r14,%r15,8),%rax
 101a379:	test   %rax,%rax
 101a37c:	jne    101a360 <register_shapes+0x7a0>
 101a37e:	jmp    101a2b0 <register_shapes+0x6f0>
 101a383:	mov    -0x60(%rbp),%r13
 101a387:	test   %r13,%r13
 101a38a:	je     101a473 <register_shapes+0x8b3>
 101a390:	mov    0x18(%r14),%rax
 101a394:	mov    -0x40(%rbp),%rcx
 101a398:	mov    0x18(%rcx),%rsi
 101a39c:	xor    %edx,%edx
 101a39e:	jmp    101a3c7 <register_shapes+0x807>
 101a3a0:	xor    %r11d,%r11d
 101a3a3:	shl    $0x6,%r11
 101a3a7:	mov    0x10(%r14),%rcx
 101a3ab:	mov    0x18(%r14),%rax
 101a3af:	add    %r11,%rcx
 101a3b2:	add    $0xffffffffffffffc8,%rcx
 101a3b6:	mov    %rcx,0x8(%rax,%rdi,1)
 101a3bb:	inc    %rdx
 101a3be:	cmp    %r13,%rdx
 101a3c1:	je     101a473 <register_shapes+0x8b3>
 101a3c7:	imul   $0xc8,%rdx,%rdi
 101a3ce:	mov    %rdx,%rcx
 101a3d1:	shl    $0x6,%rcx
 101a3d5:	vmovups (%rsi,%rcx,1),%ymm0
 101a3da:	vmovups 0x20(%rsi,%rcx,1),%ymm1
 101a3e0:	vmovups %ymm1,0x20(%rax,%rdi,1)
 101a3e6:	vmovups %ymm0,(%rax,%rdi,1)
 101a3eb:	mov    -0x40(%rbp),%rax
 101a3ef:	mov    0x18(%rax),%rsi
 101a3f3:	mov    0x8(%rsi,%rcx,1),%r8
 101a3f8:	mov    0x10(%r15),%r9
 101a3fc:	mov    0x20(%r15),%rax
 101a400:	mov    %r8,%rcx
 101a403:	shr    $0x3,%rcx
 101a407:	mov    %r8,%r11
 101a40a:	shr    $0x21,%r11
 101a40e:	xor    %rcx,%r11
 101a411:	movabs $0xbf58476d1ce4e5b9,%rcx
 101a41b:	imul   %rcx,%r11
 101a41f:	mov    %r11,%r10
 101a422:	shr    $0x1b,%r10
 101a426:	xor    %r11,%r10
 101a429:	lea    -0x1(,%rax,2),%rax
 101a431:	and    %rax,%r10
 101a434:	mov    (%r9,%r10,8),%r11
 101a438:	test   %r11,%r11
 101a43b:	je     101a3a0 <register_shapes+0x7e0>
 101a441:	mov    0x8(%r15),%rcx
 101a445:	data16 cs nopw 0x0(%rax,%rax,1)
 101a450:	lea    (%r11,%r11,4),%rbx
 101a454:	cmp    %r8,-0x28(%rcx,%rbx,8)
 101a459:	je     101a3a3 <register_shapes+0x7e3>
 101a45f:	inc    %r10
 101a462:	and    %rax,%r10
 101a465:	mov    (%r9,%r10,8),%r11
 101a469:	test   %r11,%r11
 101a46c:	jne    101a450 <register_shapes+0x890>
 101a46e:	jmp    101a3a0 <register_shapes+0x7e0>
 101a473:	mov    -0x38(%rbp),%rdi
 101a477:	mov    0x1608(%rdi),%rax
 101a47e:	cmp    0xb8(%rax),%r12
 101a485:	jbe    101a4b7 <register_shapes+0x8f7>
 101a487:	mov    $0x18,%ecx
 101a48c:	mov    %r12,%rax
 101a48f:	mul    %rcx
 101a492:	jo     101a4ae <register_shapes+0x8ee>
 101a494:	mov    %rax,%rsi
 101a497:	vzeroupper
 101a49a:	call   10187e0 <myl_rc_meta_alloc>
 101a49f:	mov    -0x2c(%rbp),%ecx
 101a4a2:	mov    -0x38(%rbp),%rdi
 101a4a6:	mov    %rax,%rbx
 101a4a9:	test   %rax,%rax
 101a4ac:	jne    101a4bc <register_shapes+0x8fc>
 101a4ae:	mov    0x30(%r14),%rdx
 101a4b2:	jmp    101a578 <register_shapes+0x9b8>
 101a4b7:	xor    %ebx,%ebx
 101a4b9:	mov    -0x2c(%rbp),%ecx
 101a4bc:	cmp    $0x1,%ecx
 101a4bf:	mov    $0x2,%eax
 101a4c4:	sbb    $0x0,%rax
 101a4c8:	mulq   0x20(%r14)
 101a4cc:	jo     101a55b <register_shapes+0x99b>
 101a4d2:	mov    %ecx,%esi
 101a4d4:	lea    -0xa0(%rbp),%r8
 101a4db:	mov    %rax,%rdx
 101a4de:	mov    %r14,%rcx
 101a4e1:	vzeroupper
 101a4e4:	call   101a5f0 <index_prepare>
 101a4e9:	mov    -0x38(%rbp),%rdi
 101a4ed:	test   %eax,%eax
 101a4ef:	je     101a55b <register_shapes+0x99b>
 101a4f1:	lea    -0xa0(%rbp),%rdx
 101a4f8:	mov    %r14,%rsi
 101a4fb:	call   101a9a0 <index_commit>
 101a500:	mov    -0x38(%rbp),%rdi
 101a504:	mov    0x1608(%rdi),%rax
 101a50b:	test   %rbx,%rbx
 101a50e:	je     101a549 <register_shapes+0x989>
 101a510:	mov    0xb0(%rax),%rsi
 101a517:	mov    0xb8(%rax),%rax
 101a51e:	shl    $0x3,%rax
 101a522:	lea    (%rax,%rax,2),%rdx
 101a526:	mov    %r14,%r15
 101a529:	mov    %rdi,%r14
 101a52c:	call   1018860 <myl_rc_meta_free>
 101a531:	mov    0x1608(%r14),%rax
 101a538:	mov    %r15,%r14
 101a53b:	mov    %rbx,0xb0(%rax)
 101a542:	mov    %r12,0xb8(%rax)
 101a549:	mov    0x28(%rax),%rcx
 101a54d:	mov    %rcx,(%r14)
 101a550:	mov    %r14,0x28(%rax)
 101a554:	xor    %eax,%eax
 101a556:	jmp    1019e36 <register_shapes+0x276>
 101a55b:	shl    $0x3,%r12
 101a55f:	lea    (%r12,%r12,2),%rdx
 101a563:	mov    %rbx,%rsi
 101a566:	mov    %rdi,%rbx
 101a569:	vzeroupper
 101a56c:	call   1018860 <myl_rc_meta_free>
 101a571:	mov    0x30(%r14),%rdx
 101a575:	mov    %rbx,%rdi
 101a578:	mov    %r14,%rsi
 101a57b:	vzeroupper
 101a57e:	call   1018860 <myl_rc_meta_free>
 101a583:	jmp    1019e31 <register_shapes+0x271>
 101a588:	xor    %r12d,%r12d
 101a58b:	mov    %rcx,%rbx
 101a58e:	mov    (%r15),%rcx
 101a591:	mov    0x18(%rcx),%rdx
 101a595:	mov    -0x58(%rbp),%r8
 101a599:	sub    %r8,%rdx
 101a59c:	jb     101a5e8 <register_shapes+0xa28>
 101a59e:	mov    0x1608(%rcx),%rsi
 101a5a5:	mov    0x30(%rsi),%rdi
 101a5a9:	sub    %r8,%rdi
 101a5ac:	jb     101a5e8 <register_shapes+0xa28>
 101a5ae:	mov    %rdx,0x18(%rcx)
 101a5b2:	mov    %rdi,0x30(%rsi)
 101a5b6:	mov    %rax,%rdi
 101a5b9:	call   1027570 <free@plt>
 101a5be:	mov    %rbx,%rax
 101a5c1:	shr    $0x3a,%rax
 101a5c5:	mov    -0x40(%rbp),%rsi
 101a5c9:	mov    $0x1,%eax
 101a5ce:	mov    -0x38(%rbp),%r9
 101a5d2:	mov    -0x2c(%rbp),%r10d
 101a5d6:	jne    1019e36 <register_shapes+0x276>
 101a5dc:	mov    %rbx,%rdi
 101a5df:	shl    $0x6,%rdi
 101a5e3:	jmp    1019e09 <register_shapes+0x249>
 101a5e8:	call   10187d4 <myl_rc_invariant_failed>
 101a5ed:	int3
 101a5ee:	int3
 101a5ef:	int3

000000000101a5f0 <index_prepare>:
 101a5f0:	push   %rbp
 101a5f1:	mov    %rsp,%rbp
 101a5f4:	push   %r15
 101a5f6:	push   %r14
 101a5f8:	push   %r13
 101a5fa:	push   %r12
 101a5fc:	push   %rbx
 101a5fd:	sub    $0x38,%rsp
 101a601:	mov    %r8,%rbx
 101a604:	mov    %rdx,-0x58(%rbp)
 101a608:	mov    %rsi,%rdx
 101a60b:	mov    %rdi,%r14
 101a60e:	vxorps %xmm0,%xmm0,%xmm0
 101a612:	vmovups %ymm0,0x20(%r8)
 101a618:	vmovups %ymm0,(%r8)
 101a61d:	mov    0x1608(%rdi),%r15
 101a624:	mov    0x28(%rcx),%rax
 101a628:	xor    %edi,%edi
 101a62a:	test   %rax,%rax
 101a62d:	je     101a6f3 <index_prepare+0x103>
 101a633:	mov    %rdx,-0x40(%rbp)
 101a637:	mov    %r14,-0x48(%rbp)
 101a63b:	mov    0xa8(%r15),%rdx
 101a642:	add    %rax,%rdx
 101a645:	lea    0x10(,%rdx,4),%rdx
 101a64d:	mov    0xa0(%r15),%r13
 101a654:	mov    0x18(%rcx),%rsi
 101a658:	xor    %r12d,%r12d
 101a65b:	xor    %r8d,%r8d
 101a65e:	mov    %r13,%rcx
 101a661:	jmp    101a692 <index_prepare+0xa2>
 101a663:	mov    0x98(%r15),%r11
 101a66a:	mov    %r10,%r14
 101a66d:	shl    $0x4,%r14
 101a671:	cmpq   $0x0,(%r11,%r14,1)
 101a676:	je     101a6d8 <index_prepare+0xe8>
 101a678:	nopl   0x0(%rax,%rax,1)
 101a680:	inc    %r8
 101a683:	mov    %r8,%r12
 101a686:	add    $0xc8,%rsi
 101a68d:	dec    %rax
 101a690:	je     101a6e4 <index_prepare+0xf4>
 101a692:	mov    (%rsi),%r9
 101a695:	mov    0x34(%r9),%r9d
 101a699:	test   %r9d,%r9d
 101a69c:	setne  %r10b
 101a6a0:	cmp    %edi,%r9d
 101a6a3:	seta   %r11b
 101a6a7:	and    %r10b,%r11b
 101a6aa:	cmp    $0x1,%r11b
 101a6ae:	jne    101a680 <index_prepare+0x90>
 101a6b0:	mov    %r9d,%r10d
 101a6b3:	cmp    %r10,%rdx
 101a6b6:	jbe    101a680 <index_prepare+0x90>
 101a6b8:	cmp    %r10,%r13
 101a6bb:	ja     101a663 <index_prepare+0x73>
 101a6bd:	inc    %r10
 101a6c0:	cmp    %r10,%rcx
 101a6c3:	cmovbe %r10,%rcx
 101a6c7:	mov    %r9d,%edi
 101a6ca:	add    $0xc8,%rsi
 101a6d1:	dec    %rax
 101a6d4:	jne    101a692 <index_prepare+0xa2>
 101a6d6:	jmp    101a6e4 <index_prepare+0xf4>
 101a6d8:	add    %r14,%r11
 101a6db:	cmpq   $0x0,0x8(%r11)
 101a6e0:	jne    101a680 <index_prepare+0x90>
 101a6e2:	jmp    101a6bd <index_prepare+0xcd>
 101a6e4:	cmp    %r13,%rcx
 101a6e7:	jne    101a761 <index_prepare+0x171>
 101a6e9:	mov    -0x48(%rbp),%r14
 101a6ed:	mov    -0x40(%rbp),%rdx
 101a6f1:	jmp    101a6f6 <index_prepare+0x106>
 101a6f3:	xor    %r12d,%r12d
 101a6f6:	add    $0x38,%r15
 101a6fa:	mov    %r14,%rdi
 101a6fd:	mov    %r15,%rsi
 101a700:	mov    %rbx,%rcx
 101a703:	vzeroupper
 101a706:	call   101b100 <map_prepare>
 101a70b:	test   %eax,%eax
 101a70d:	je     101a7c6 <index_prepare+0x1d6>
 101a713:	mov    0x1608(%r14),%rsi
 101a71a:	add    $0x58,%rsi
 101a71e:	lea    0x10(%rbx),%rcx
 101a722:	mov    %r14,%rdi
 101a725:	mov    -0x58(%rbp),%rdx
 101a729:	call   101b100 <map_prepare>
 101a72e:	test   %eax,%eax
 101a730:	je     101a7c6 <index_prepare+0x1d6>
 101a736:	mov    0x1608(%r14),%rsi
 101a73d:	add    $0x78,%rsi
 101a741:	lea    0x20(%rbx),%rcx
 101a745:	mov    %r14,%rdi
 101a748:	mov    %r12,%rdx
 101a74b:	call   101b100 <map_prepare>
 101a750:	mov    %eax,%ecx
 101a752:	mov    $0x1,%eax
 101a757:	test   %ecx,%ecx
 101a759:	jne    101a908 <index_prepare+0x318>
 101a75f:	jmp    101a7c6 <index_prepare+0x1d6>
 101a761:	lea    0x0(,%r13,2),%rdx
 101a769:	cmp    %rdx,%rcx
 101a76c:	cmova  %rcx,%rdx
 101a770:	mov    %rdx,%rax
 101a773:	shr    $0x3c,%rax
 101a777:	mov    -0x48(%rbp),%r14
 101a77b:	jne    101a7c6 <index_prepare+0x1d6>
 101a77d:	test   %r14,%r14
 101a780:	je     101a98b <index_prepare+0x39b>
 101a786:	test   %rdx,%rdx
 101a789:	je     101a98b <index_prepare+0x39b>
 101a78f:	test   %r15,%r15
 101a792:	je     101a98b <index_prepare+0x39b>
 101a798:	mov    %rdx,%rcx
 101a79b:	shl    $0x4,%rcx
 101a79f:	mov    0x18(%r14),%rsi
 101a7a3:	add    %rcx,%rsi
 101a7a6:	jb     101a7be <index_prepare+0x1ce>
 101a7a8:	mov    0x58(%r14),%rax
 101a7ac:	test   %rax,%rax
 101a7af:	je     101a91a <index_prepare+0x32a>
 101a7b5:	cmp    %rax,%rsi
 101a7b8:	jbe    101a91a <index_prepare+0x32a>
 101a7be:	movl   $0x1,0x6c(%r14)
 101a7c6:	mov    (%rbx),%rdi
 101a7c9:	test   %rdi,%rdi
 101a7cc:	je     101a80b <index_prepare+0x21b>
 101a7ce:	mov    0x8(%rbx),%rax
 101a7d2:	shl    $0x4,%rax
 101a7d6:	add    $0x10,%rax
 101a7da:	mov    0x18(%r14),%rcx
 101a7de:	sub    %rax,%rcx
 101a7e1:	jb     101a98b <index_prepare+0x39b>
 101a7e7:	mov    0x1608(%r14),%rdx
 101a7ee:	mov    0x30(%rdx),%rsi
 101a7f2:	sub    %rax,%rsi
 101a7f5:	jb     101a98b <index_prepare+0x39b>
 101a7fb:	mov    %rcx,0x18(%r14)
 101a7ff:	mov    %rsi,0x30(%rdx)
 101a803:	vzeroupper
 101a806:	call   1027570 <free@plt>
 101a80b:	vxorps %xmm0,%xmm0,%xmm0
 101a80f:	vmovups %xmm0,(%rbx)
 101a813:	mov    0x10(%rbx),%rdi
 101a817:	test   %rdi,%rdi
 101a81a:	je     101a85d <index_prepare+0x26d>
 101a81c:	mov    0x18(%rbx),%rax
 101a820:	shl    $0x4,%rax
 101a824:	add    $0x10,%rax
 101a828:	mov    0x18(%r14),%rcx
 101a82c:	sub    %rax,%rcx
 101a82f:	jb     101a98b <index_prepare+0x39b>
 101a835:	mov    0x1608(%r14),%rdx
 101a83c:	mov    0x30(%rdx),%rsi
 101a840:	sub    %rax,%rsi
 101a843:	jb     101a98b <index_prepare+0x39b>
 101a849:	mov    %rcx,0x18(%r14)
 101a84d:	mov    %rsi,0x30(%rdx)
 101a851:	vzeroupper
 101a854:	call   1027570 <free@plt>
 101a859:	vxorps %xmm0,%xmm0,%xmm0
 101a85d:	lea    0x10(%rbx),%rax
 101a861:	vmovups %xmm0,(%rax)
 101a865:	mov    0x20(%rbx),%rdi
 101a869:	test   %rdi,%rdi
 101a86c:	je     101a8ab <index_prepare+0x2bb>
 101a86e:	mov    0x28(%rbx),%rax
 101a872:	shl    $0x4,%rax
 101a876:	add    $0x10,%rax
 101a87a:	mov    0x18(%r14),%rcx
 101a87e:	sub    %rax,%rcx
 101a881:	jb     101a98b <index_prepare+0x39b>
 101a887:	mov    0x1608(%r14),%rdx
 101a88e:	mov    0x30(%rdx),%rsi
 101a892:	sub    %rax,%rsi
 101a895:	jb     101a98b <index_prepare+0x39b>
 101a89b:	mov    %rcx,0x18(%r14)
 101a89f:	mov    %rsi,0x30(%rdx)
 101a8a3:	vzeroupper
 101a8a6:	call   1027570 <free@plt>
 101a8ab:	lea    0x20(%rbx),%rax
 101a8af:	vxorps %xmm0,%xmm0,%xmm0
 101a8b3:	vmovups %xmm0,(%rax)
 101a8b7:	mov    0x30(%rbx),%rdi
 101a8bb:	test   %rdi,%rdi
 101a8be:	je     101a8f9 <index_prepare+0x309>
 101a8c0:	mov    0x38(%rbx),%rcx
 101a8c4:	shl    $0x4,%rcx
 101a8c8:	mov    0x18(%r14),%rax
 101a8cc:	sub    %rcx,%rax
 101a8cf:	jb     101a98b <index_prepare+0x39b>
 101a8d5:	mov    0x1608(%r14),%rdx
 101a8dc:	mov    0x30(%rdx),%rsi
 101a8e0:	sub    %rcx,%rsi
 101a8e3:	jb     101a98b <index_prepare+0x39b>
 101a8e9:	mov    %rax,0x18(%r14)
 101a8ed:	mov    %rsi,0x30(%rdx)
 101a8f1:	vzeroupper
 101a8f4:	call   1027570 <free@plt>
 101a8f9:	vxorps %xmm0,%xmm0,%xmm0
 101a8fd:	vmovups %ymm0,0x20(%rbx)
 101a902:	vmovups %ymm0,(%rbx)
 101a906:	xor    %eax,%eax
 101a908:	add    $0x38,%rsp
 101a90c:	pop    %rbx
 101a90d:	pop    %r12
 101a90f:	pop    %r13
 101a911:	pop    %r14
 101a913:	pop    %r15
 101a915:	pop    %rbp
 101a916:	vzeroupper
 101a919:	ret
 101a91a:	mov    %rsi,-0x30(%rbp)
 101a91e:	mov    $0x1,%edi
 101a923:	mov    %rcx,%rsi
 101a926:	mov    %rcx,-0x50(%rbp)
 101a92a:	mov    %rdx,-0x38(%rbp)
 101a92e:	vzeroupper
 101a931:	call   1027510 <calloc@plt>
 101a936:	mov    -0x38(%rbp),%rcx
 101a93a:	test   %rax,%rax
 101a93d:	je     101a7c6 <index_prepare+0x1d6>
 101a943:	mov    %rax,%rdx
 101a946:	mov    -0x30(%rbp),%rax
 101a94a:	mov    %rax,0x18(%r14)
 101a94e:	mov    -0x50(%rbp),%rax
 101a952:	add    %rax,0x30(%r15)
 101a956:	test   %r13,%r13
 101a959:	je     101a97e <index_prepare+0x38e>
 101a95b:	mov    0x98(%r15),%rsi
 101a962:	shl    $0x4,%r13
 101a966:	mov    %rdx,-0x30(%rbp)
 101a96a:	mov    -0x30(%rbp),%rdi
 101a96e:	mov    %r13,%rdx
 101a971:	call   1027520 <memcpy@plt>
 101a976:	mov    -0x30(%rbp),%rdx
 101a97a:	mov    -0x38(%rbp),%rcx
 101a97e:	mov    %rdx,0x30(%rbx)
 101a982:	mov    %rcx,0x38(%rbx)
 101a986:	jmp    101a6ed <index_prepare+0xfd>
 101a98b:	vzeroupper
 101a98e:	call   10187d4 <myl_rc_invariant_failed>
 101a993:	int3
 101a994:	int3
 101a995:	int3
 101a996:	int3
 101a997:	int3
 101a998:	int3
 101a999:	int3
 101a99a:	int3
 101a99b:	int3
 101a99c:	int3
 101a99d:	int3
 101a99e:	int3
 101a99f:	int3

000000000101a9a0 <index_commit>:
 101a9a0:	push   %rbp
 101a9a1:	mov    %rsp,%rbp
 101a9a4:	push   %r15
 101a9a6:	push   %r14
 101a9a8:	push   %r13
 101a9aa:	push   %r12
 101a9ac:	push   %rbx
 101a9ad:	sub    $0x18,%rsp
 101a9b1:	mov    %rdx,%r15
 101a9b4:	mov    %rsi,%rbx
 101a9b7:	mov    %rdi,%r12
 101a9ba:	mov    0x1608(%rdi),%r13
 101a9c1:	cmpq   $0x0,(%rdx)
 101a9c5:	je     101aa9e <index_commit+0xfe>
 101a9cb:	mov    0x38(%r13),%rdi
 101a9cf:	mov    0x48(%r13),%r14
 101a9d3:	cmp    $0x100b5f0,%rdi
 101a9da:	je     101aa1c <index_commit+0x7c>
 101a9dc:	mov    0x40(%r13),%rax
 101a9e0:	cmp    $0xffffffffffffffff,%rax
 101a9e4:	je     101aa1c <index_commit+0x7c>
 101a9e6:	test   %rdi,%rdi
 101a9e9:	je     101aa1c <index_commit+0x7c>
 101a9eb:	shl    $0x4,%rax
 101a9ef:	add    $0x10,%rax
 101a9f3:	mov    0x18(%r12),%rcx
 101a9f8:	sub    %rax,%rcx
 101a9fb:	jb     101b0ec <index_commit+0x74c>
 101aa01:	mov    0x30(%r13),%rdx
 101aa05:	sub    %rax,%rdx
 101aa08:	jb     101b0ec <index_commit+0x74c>
 101aa0e:	mov    %rcx,0x18(%r12)
 101aa13:	mov    %rdx,0x30(%r13)
 101aa17:	call   1027570 <free@plt>
 101aa1c:	movq   $0x100b5f0,0x38(%r13)
 101aa24:	vxorps %xmm0,%xmm0,%xmm0
 101aa28:	vmovups %xmm0,0x40(%r13)
 101aa2e:	movl   $0x0,0x54(%r13)
 101aa36:	mov    (%r15),%rax
 101aa39:	mov    0x8(%r15),%rcx
 101aa3d:	lea    0x1(%rcx),%rdx
 101aa41:	mov    $0x3f,%edi
 101aa46:	cmp    $0x2,%rdx
 101aa4a:	jb     101aa79 <index_commit+0xd9>
 101aa4c:	mov    $0x40,%esi
 101aa51:	mov    %rdx,%rdi
 101aa54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101aa60:	shr    $1,%rdi
 101aa63:	dec    %esi
 101aa65:	cmp    $0x3,%rdx
 101aa69:	mov    %rdi,%rdx
 101aa6c:	ja     101aa60 <index_commit+0xc0>
 101aa6e:	cmp    $0x3f,%esi
 101aa71:	mov    $0x3f,%edi
 101aa76:	cmovb  %esi,%edi
 101aa79:	mov    %rax,0x38(%r13)
 101aa7d:	mov    %rcx,0x40(%r13)
 101aa81:	mov    %r14,0x48(%r13)
 101aa85:	mov    %edi,0x50(%r13)
 101aa89:	movl   $0x0,0x54(%r13)
 101aa91:	vmovups %xmm0,(%r15)
 101aa96:	mov    0x1608(%r12),%r13
 101aa9e:	cmpq   $0x0,0x10(%r15)
 101aaa3:	je     101ab7f <index_commit+0x1df>
 101aaa9:	mov    0x58(%r13),%rdi
 101aaad:	mov    0x68(%r13),%r14
 101aab1:	cmp    $0x100b5f0,%rdi
 101aab8:	je     101aafa <index_commit+0x15a>
 101aaba:	mov    0x60(%r13),%rax
 101aabe:	cmp    $0xffffffffffffffff,%rax
 101aac2:	je     101aafa <index_commit+0x15a>
 101aac4:	test   %rdi,%rdi
 101aac7:	je     101aafa <index_commit+0x15a>
 101aac9:	shl    $0x4,%rax
 101aacd:	add    $0x10,%rax
 101aad1:	mov    0x18(%r12),%rcx
 101aad6:	sub    %rax,%rcx
 101aad9:	jb     101b0ec <index_commit+0x74c>
 101aadf:	mov    0x30(%r13),%rdx
 101aae3:	sub    %rax,%rdx
 101aae6:	jb     101b0ec <index_commit+0x74c>
 101aaec:	mov    %rcx,0x18(%r12)
 101aaf1:	mov    %rdx,0x30(%r13)
 101aaf5:	call   1027570 <free@plt>
 101aafa:	lea    0x10(%r15),%rax
 101aafe:	movq   $0x100b5f0,0x58(%r13)
 101ab06:	vxorps %xmm0,%xmm0,%xmm0
 101ab0a:	vmovups %xmm0,0x60(%r13)
 101ab10:	movl   $0x0,0x74(%r13)
 101ab18:	mov    0x10(%r15),%rcx
 101ab1c:	mov    0x18(%r15),%rdx
 101ab20:	lea    0x1(%rdx),%rsi
 101ab24:	mov    $0x3f,%r8d
 101ab2a:	cmp    $0x2,%rsi
 101ab2e:	jb     101ab5b <index_commit+0x1bb>
 101ab30:	mov    $0x40,%edi
 101ab35:	mov    %rsi,%r8
 101ab38:	nopl   0x0(%rax,%rax,1)
 101ab40:	shr    $1,%r8
 101ab43:	dec    %edi
 101ab45:	cmp    $0x3,%rsi
 101ab49:	mov    %r8,%rsi
 101ab4c:	ja     101ab40 <index_commit+0x1a0>
 101ab4e:	cmp    $0x3f,%edi
 101ab51:	mov    $0x3f,%r8d
 101ab57:	cmovb  %edi,%r8d
 101ab5b:	mov    %rcx,0x58(%r13)
 101ab5f:	mov    %rdx,0x60(%r13)
 101ab63:	mov    %r14,0x68(%r13)
 101ab67:	mov    %r8d,0x70(%r13)
 101ab6b:	movl   $0x0,0x74(%r13)
 101ab73:	vmovups %xmm0,(%rax)
 101ab77:	mov    0x1608(%r12),%r13
 101ab7f:	cmpq   $0x0,0x20(%r15)
 101ab84:	je     101ac7b <index_commit+0x2db>
 101ab8a:	mov    0x78(%r13),%rdi
 101ab8e:	mov    0x88(%r13),%r14
 101ab95:	cmp    $0x100b5f0,%rdi
 101ab9c:	je     101abe1 <index_commit+0x241>
 101ab9e:	mov    0x80(%r13),%rax
 101aba5:	cmp    $0xffffffffffffffff,%rax
 101aba9:	je     101abe1 <index_commit+0x241>
 101abab:	test   %rdi,%rdi
 101abae:	je     101abe1 <index_commit+0x241>
 101abb0:	shl    $0x4,%rax
 101abb4:	add    $0x10,%rax
 101abb8:	mov    0x18(%r12),%rcx
 101abbd:	sub    %rax,%rcx
 101abc0:	jb     101b0ec <index_commit+0x74c>
 101abc6:	mov    0x30(%r13),%rdx
 101abca:	sub    %rax,%rdx
 101abcd:	jb     101b0ec <index_commit+0x74c>
 101abd3:	mov    %rcx,0x18(%r12)
 101abd8:	mov    %rdx,0x30(%r13)
 101abdc:	call   1027570 <free@plt>
 101abe1:	lea    0x20(%r15),%rax
 101abe5:	movq   $0x100b5f0,0x78(%r13)
 101abed:	vxorps %xmm0,%xmm0,%xmm0
 101abf1:	vmovups %xmm0,0x80(%r13)
 101abfa:	movl   $0x0,0x94(%r13)
 101ac05:	mov    0x20(%r15),%rcx
 101ac09:	mov    0x28(%r15),%rdx
 101ac0d:	lea    0x1(%rdx),%rsi
 101ac11:	mov    $0x3f,%r8d
 101ac17:	cmp    $0x2,%rsi
 101ac1b:	jb     101ac4b <index_commit+0x2ab>
 101ac1d:	mov    $0x40,%edi
 101ac22:	mov    %rsi,%r8
 101ac25:	data16 cs nopw 0x0(%rax,%rax,1)
 101ac30:	shr    $1,%r8
 101ac33:	dec    %edi
 101ac35:	cmp    $0x3,%rsi
 101ac39:	mov    %r8,%rsi
 101ac3c:	ja     101ac30 <index_commit+0x290>
 101ac3e:	cmp    $0x3f,%edi
 101ac41:	mov    $0x3f,%r8d
 101ac47:	cmovb  %edi,%r8d
 101ac4b:	mov    %rcx,0x78(%r13)
 101ac4f:	mov    %rdx,0x80(%r13)
 101ac56:	mov    %r14,0x88(%r13)
 101ac5d:	mov    %r8d,0x90(%r13)
 101ac64:	movl   $0x0,0x94(%r13)
 101ac6f:	vmovups %xmm0,(%rax)
 101ac73:	mov    0x1608(%r12),%r13
 101ac7b:	mov    0x30(%r15),%rax
 101ac7f:	test   %rax,%rax
 101ac82:	je     101ace2 <index_commit+0x342>
 101ac84:	mov    0x98(%r13),%rdi
 101ac8b:	test   %rdi,%rdi
 101ac8e:	je     101acc8 <index_commit+0x328>
 101ac90:	mov    0xa0(%r13),%rcx
 101ac97:	shl    $0x4,%rcx
 101ac9b:	mov    0x18(%r12),%rax
 101aca0:	sub    %rcx,%rax
 101aca3:	jb     101b0ec <index_commit+0x74c>
 101aca9:	mov    0x30(%r13),%rdx
 101acad:	sub    %rcx,%rdx
 101acb0:	jb     101b0ec <index_commit+0x74c>
 101acb6:	mov    %rax,0x18(%r12)
 101acbb:	mov    %rdx,0x30(%r13)
 101acbf:	call   1027570 <free@plt>
 101acc4:	mov    0x30(%r15),%rax
 101acc8:	mov    %rax,0x98(%r13)
 101accf:	mov    0x38(%r15),%rax
 101acd3:	mov    %rax,0xa0(%r13)
 101acda:	movq   $0x0,0x30(%r15)
 101ace2:	mov    0x8(%rbx),%rax
 101ace6:	test   %rax,%rax
 101ace9:	je     101ad74 <index_commit+0x3d4>
 101acef:	mov    0x1608(%r12),%rcx
 101acf7:	mov    0x38(%rcx),%rdx
 101acfb:	cmp    $0x100b5f0,%rdx
 101ad02:	je     101b0ec <index_commit+0x74c>
 101ad08:	mov    0x40(%rcx),%rdi
 101ad0c:	cmp    $0xffffffffffffffff,%rdi
 101ad10:	je     101b0ec <index_commit+0x74c>
 101ad16:	mov    0x48(%rcx),%rsi
 101ad1a:	lea    0x1(%rdi),%r8
 101ad1e:	shr    $1,%r8
 101ad21:	cmp    %r8,%rsi
 101ad24:	ja     101b0ec <index_commit+0x74c>
 101ad2a:	movzbl 0x50(%rcx),%r8d
 101ad2f:	mov    %rax,%r9
 101ad32:	movabs $0x9e3779b97f4a7c15,%r10
 101ad3c:	imul   %r10,%r9
 101ad40:	shrx   %r8,%r9,%r9
 101ad45:	data16 cs nopw 0x0(%rax,%rax,1)
 101ad50:	and    %rdi,%r9
 101ad53:	mov    %r9,%r8
 101ad56:	shl    $0x4,%r8
 101ad5a:	mov    (%rdx,%r8,1),%r10
 101ad5e:	test   %r10,%r10
 101ad61:	je     101ad6b <index_commit+0x3cb>
 101ad63:	inc    %r9
 101ad66:	cmp    %rax,%r10
 101ad69:	jne    101ad50 <index_commit+0x3b0>
 101ad6b:	test   %r10,%r10
 101ad6e:	je     101af2a <index_commit+0x58a>
 101ad74:	mov    0x20(%rbx),%rax
 101ad78:	test   %rax,%rax
 101ad7b:	je     101af48 <index_commit+0x5a8>
 101ad81:	xor    %ecx,%ecx
 101ad83:	jmp    101ad9c <index_commit+0x3fc>
 101ad85:	data16 cs nopw 0x0(%rax,%rax,1)
 101ad90:	inc    %rcx
 101ad93:	cmp    %rax,%rcx
 101ad96:	je     101af48 <index_commit+0x5a8>
 101ad9c:	mov    0x38(%rbx),%rdx
 101ada0:	test   %rdx,%rdx
 101ada3:	je     101add0 <index_commit+0x430>
 101ada5:	mov    0x8(%rdx),%rdx
 101ada9:	mov    (%rdx,%rcx,8),%rsi
 101adad:	mov    0x1608(%r12),%rdi
 101adb5:	mov    0x58(%rdi),%r8
 101adb9:	cmp    $0x100b5f0,%r8
 101adc0:	jne    101adf4 <index_commit+0x454>
 101adc2:	jmp    101b0ec <index_commit+0x74c>
 101adc7:	nopw   0x0(%rax,%rax,1)
 101add0:	mov    %rcx,%rsi
 101add3:	shl    $0x6,%rsi
 101add7:	add    0x10(%rbx),%rsi
 101addb:	mov    0x1608(%r12),%rdi
 101ade3:	mov    0x58(%rdi),%r8
 101ade7:	cmp    $0x100b5f0,%r8
 101adee:	je     101b0ec <index_commit+0x74c>
 101adf4:	mov    0x60(%rdi),%r10
 101adf8:	cmp    $0xffffffffffffffff,%r10
 101adfc:	je     101b0ec <index_commit+0x74c>
 101ae02:	mov    0x68(%rdi),%r9
 101ae06:	lea    0x1(%r10),%rdx
 101ae0a:	shr    $1,%rdx
 101ae0d:	cmp    %rdx,%r9
 101ae10:	ja     101b0ec <index_commit+0x74c>
 101ae16:	lea    0x8(%rsi),%rdx
 101ae1a:	movzbl 0x70(%rdi),%r11d
 101ae1f:	mov    %rdx,%r14
 101ae22:	movabs $0x9e3779b97f4a7c15,%r15
 101ae2c:	imul   %r15,%r14
 101ae30:	shrx   %r11,%r14,%r14
 101ae35:	data16 cs nopw 0x0(%rax,%rax,1)
 101ae40:	and    %r10,%r14
 101ae43:	mov    %r14,%r11
 101ae46:	shl    $0x4,%r11
 101ae4a:	mov    (%r8,%r11,1),%r15
 101ae4e:	test   %r15,%r15
 101ae51:	je     101ae5b <index_commit+0x4bb>
 101ae53:	inc    %r14
 101ae56:	cmp    %rdx,%r15
 101ae59:	jne    101ae40 <index_commit+0x4a0>
 101ae5b:	test   %r15,%r15
 101ae5e:	je     101ae70 <index_commit+0x4d0>
 101ae60:	mov    (%rsi),%rsi
 101ae63:	test   %rsi,%rsi
 101ae66:	jne    101ae8d <index_commit+0x4ed>
 101ae68:	jmp    101ad90 <index_commit+0x3f0>
 101ae6d:	nopl   (%rax)
 101ae70:	add    %r11,%r8
 101ae73:	mov    %rdx,(%r8)
 101ae76:	mov    %rdx,0x8(%r8)
 101ae7a:	inc    %r9
 101ae7d:	mov    %r9,0x68(%rdi)
 101ae81:	mov    (%rsi),%rsi
 101ae84:	test   %rsi,%rsi
 101ae87:	je     101ad90 <index_commit+0x3f0>
 101ae8d:	mov    0x1608(%r12),%rdi
 101ae95:	mov    0x58(%rdi),%r8
 101ae99:	cmp    $0x100b5f0,%r8
 101aea0:	je     101b0ec <index_commit+0x74c>
 101aea6:	mov    0x60(%rdi),%r10
 101aeaa:	cmp    $0xffffffffffffffff,%r10
 101aeae:	je     101b0ec <index_commit+0x74c>
 101aeb4:	mov    0x68(%rdi),%r9
 101aeb8:	lea    0x1(%r10),%r11
 101aebc:	shr    $1,%r11
 101aebf:	cmp    %r11,%r9
 101aec2:	ja     101b0ec <index_commit+0x74c>
 101aec8:	movzbl 0x70(%rdi),%r11d
 101aecd:	mov    %rsi,%r14
 101aed0:	movabs $0x9e3779b97f4a7c15,%r15
 101aeda:	imul   %r15,%r14
 101aede:	shrx   %r11,%r14,%r14
 101aee3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101aef0:	and    %r10,%r14
 101aef3:	mov    %r14,%r11
 101aef6:	shl    $0x4,%r11
 101aefa:	mov    (%r8,%r11,1),%r15
 101aefe:	test   %r15,%r15
 101af01:	je     101af0b <index_commit+0x56b>
 101af03:	inc    %r14
 101af06:	cmp    %rsi,%r15
 101af09:	jne    101aef0 <index_commit+0x550>
 101af0b:	test   %r15,%r15
 101af0e:	jne    101ad90 <index_commit+0x3f0>
 101af14:	add    %r11,%r8
 101af17:	mov    %rsi,(%r8)
 101af1a:	mov    %rdx,0x8(%r8)
 101af1e:	inc    %r9
 101af21:	mov    %r9,0x68(%rdi)
 101af25:	jmp    101ad90 <index_commit+0x3f0>
 101af2a:	add    %r8,%rdx
 101af2d:	mov    %rax,(%rdx)
 101af30:	mov    %rbx,0x8(%rdx)
 101af34:	inc    %rsi
 101af37:	mov    %rsi,0x48(%rcx)
 101af3b:	mov    0x20(%rbx),%rax
 101af3f:	test   %rax,%rax
 101af42:	jne    101ad81 <index_commit+0x3e1>
 101af48:	mov    %r13,-0x30(%rbp)
 101af4c:	mov    %r12,-0x40(%rbp)
 101af50:	mov    0x28(%rbx),%rax
 101af54:	test   %rax,%rax
 101af57:	je     101b0dd <index_commit+0x73d>
 101af5d:	mov    -0x30(%rbp),%rcx
 101af61:	add    0xa8(%rcx),%rax
 101af68:	lea    0x10(,%rax,4),%rax
 101af70:	mov    %rax,-0x38(%rbp)
 101af74:	xor    %r13d,%r13d
 101af77:	xor    %r12d,%r12d
 101af7a:	jmp    101afbd <index_commit+0x61d>
 101af7c:	shl    $0x4,%rcx
 101af80:	mov    0x38(%rbx),%rsi
 101af84:	test   %rsi,%rsi
 101af87:	cmove  %rsi,%r14
 101af8b:	mov    %r14,(%rdx,%rcx,1)
 101af8f:	mov    %r15,0x8(%rdx,%rcx,1)
 101af94:	mov    -0x30(%rbp),%rcx
 101af98:	incq   0xa8(%rcx)
 101af9f:	mov    %eax,%r13d
 101afa2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101afb0:	inc    %r12
 101afb3:	cmp    0x28(%rbx),%r12
 101afb7:	jae    101b0dd <index_commit+0x73d>
 101afbd:	mov    0x18(%rbx),%rax
 101afc1:	imul   $0xc8,%r12,%rcx
 101afc8:	lea    (%rax,%rcx,1),%r15
 101afcc:	mov    (%rax,%rcx,1),%r14
 101afd0:	mov    0x34(%r14),%eax
 101afd4:	test   %eax,%eax
 101afd6:	setne  %cl
 101afd9:	cmp    %r13d,%eax
 101afdc:	seta   %dl
 101afdf:	and    %cl,%dl
 101afe1:	cmp    $0x1,%dl
 101afe4:	jne    101b030 <index_commit+0x690>
 101afe6:	mov    %eax,%ecx
 101afe8:	cmp    %rcx,-0x38(%rbp)
 101afec:	jbe    101b030 <index_commit+0x690>
 101afee:	mov    -0x30(%rbp),%rsi
 101aff2:	mov    0x98(%rsi),%rdx
 101aff9:	cmp    %rcx,0xa0(%rsi)
 101b000:	jbe    101af7c <index_commit+0x5dc>
 101b006:	mov    %rcx,%rsi
 101b009:	shl    $0x4,%rsi
 101b00d:	cmpq   $0x0,(%rdx,%rsi,1)
 101b012:	jne    101b030 <index_commit+0x690>
 101b014:	add    %rdx,%rsi
 101b017:	cmpq   $0x0,0x8(%rsi)
 101b01c:	je     101af7c <index_commit+0x5dc>
 101b022:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b030:	cmpq   $0x0,0x38(%rbx)
 101b035:	jne    101b03f <index_commit+0x69f>
 101b037:	mov    %r15,%rdi
 101b03a:	call   1018ed0 <flat_build>
 101b03f:	mov    -0x40(%rbp),%rax
 101b043:	mov    0x1608(%rax),%rax
 101b04a:	mov    0x78(%rax),%rcx
 101b04e:	cmp    $0x100b5f0,%rcx
 101b055:	je     101b0ec <index_commit+0x74c>
 101b05b:	mov    0x80(%rax),%rsi
 101b062:	cmp    $0xffffffffffffffff,%rsi
 101b066:	je     101b0ec <index_commit+0x74c>
 101b06c:	mov    0x88(%rax),%rdx
 101b073:	lea    0x1(%rsi),%rdi
 101b077:	shr    $1,%rdi
 101b07a:	cmp    %rdi,%rdx
 101b07d:	ja     101b0ec <index_commit+0x74c>
 101b07f:	movzbl 0x90(%rax),%edi
 101b086:	mov    %r14,%r8
 101b089:	movabs $0x9e3779b97f4a7c15,%r9
 101b093:	imul   %r9,%r8
 101b097:	shrx   %rdi,%r8,%rdi
 101b09c:	nopl   0x0(%rax)
 101b0a0:	and    %rsi,%rdi
 101b0a3:	mov    %rdi,%r8
 101b0a6:	shl    $0x4,%r8
 101b0aa:	mov    (%rcx,%r8,1),%r9
 101b0ae:	test   %r9,%r9
 101b0b1:	je     101b0bb <index_commit+0x71b>
 101b0b3:	inc    %rdi
 101b0b6:	cmp    %r14,%r9
 101b0b9:	jne    101b0a0 <index_commit+0x700>
 101b0bb:	test   %r9,%r9
 101b0be:	jne    101afb0 <index_commit+0x610>
 101b0c4:	add    %r8,%rcx
 101b0c7:	mov    %r14,(%rcx)
 101b0ca:	mov    %r15,0x8(%rcx)
 101b0ce:	inc    %rdx
 101b0d1:	mov    %rdx,0x88(%rax)
 101b0d8:	jmp    101afb0 <index_commit+0x610>
 101b0dd:	add    $0x18,%rsp
 101b0e1:	pop    %rbx
 101b0e2:	pop    %r12
 101b0e4:	pop    %r13
 101b0e6:	pop    %r14
 101b0e8:	pop    %r15
 101b0ea:	pop    %rbp
 101b0eb:	ret
 101b0ec:	call   10187d4 <myl_rc_invariant_failed>
 101b0f1:	int3
 101b0f2:	int3
 101b0f3:	int3
 101b0f4:	int3
 101b0f5:	int3
 101b0f6:	int3
 101b0f7:	int3
 101b0f8:	int3
 101b0f9:	int3
 101b0fa:	int3
 101b0fb:	int3
 101b0fc:	int3
 101b0fd:	int3
 101b0fe:	int3
 101b0ff:	int3

000000000101b100 <map_prepare>:
 101b100:	push   %rbp
 101b101:	mov    %rsp,%rbp
 101b104:	push   %r15
 101b106:	push   %r14
 101b108:	push   %r13
 101b10a:	push   %r12
 101b10c:	push   %rbx
 101b10d:	sub    $0x18,%rsp
 101b111:	vxorps %xmm0,%xmm0,%xmm0
 101b115:	vmovups %xmm0,(%rcx)
 101b119:	mov    (%rsi),%r14
 101b11c:	xor    %eax,%eax
 101b11e:	cmp    $0x100b5f0,%r14
 101b125:	je     101b139 <map_prepare+0x39>
 101b127:	mov    0x8(%rsi),%r8
 101b12b:	inc    %r8
 101b12e:	add    0x10(%rsi),%rdx
 101b132:	jae    101b146 <map_prepare+0x46>
 101b134:	jmp    101b2e9 <map_prepare+0x1e9>
 101b139:	xor    %r8d,%r8d
 101b13c:	add    0x10(%rsi),%rdx
 101b140:	jb     101b2e9 <map_prepare+0x1e9>
 101b146:	mov    %r8,%r9
 101b149:	shr    $1,%r9
 101b14c:	cmp    %r9,%rdx
 101b14f:	jbe    101b2e4 <map_prepare+0x1e4>
 101b155:	test   %r8,%r8
 101b158:	mov    $0x20,%r15d
 101b15e:	cmovne %r8,%r15
 101b162:	mov    %r15,%r8
 101b165:	shr    $1,%r8
 101b168:	cmp    %r8,%rdx
 101b16b:	jbe    101b18b <map_prepare+0x8b>
 101b16d:	mov    %r15,%r8
 101b170:	cmp    $0x7fffffff,%r8
 101b177:	ja     101b2e9 <map_prepare+0x1e9>
 101b17d:	lea    (%r8,%r8,1),%r15
 101b181:	cmp    %r8,%rdx
 101b184:	mov    %r15,%r8
 101b187:	ja     101b170 <map_prepare+0x70>
 101b189:	jmp    101b198 <map_prepare+0x98>
 101b18b:	mov    %r15,%rdx
 101b18e:	shr    $0x3c,%rdx
 101b192:	jne    101b2e9 <map_prepare+0x1e9>
 101b198:	test   %rdi,%rdi
 101b19b:	je     101b2f8 <map_prepare+0x1f8>
 101b1a1:	test   %r15,%r15
 101b1a4:	je     101b2f8 <map_prepare+0x1f8>
 101b1aa:	mov    0x1608(%rdi),%r12
 101b1b1:	test   %r12,%r12
 101b1b4:	je     101b2f8 <map_prepare+0x1f8>
 101b1ba:	mov    %r15,%rbx
 101b1bd:	shl    $0x4,%rbx
 101b1c1:	mov    0x18(%rdi),%r13
 101b1c5:	add    %rbx,%r13
 101b1c8:	jb     101b1d8 <map_prepare+0xd8>
 101b1ca:	mov    0x58(%rdi),%rdx
 101b1ce:	test   %rdx,%rdx
 101b1d1:	je     101b1e4 <map_prepare+0xe4>
 101b1d3:	cmp    %rdx,%r13
 101b1d6:	jbe    101b1e4 <map_prepare+0xe4>
 101b1d8:	movl   $0x1,0x6c(%rdi)
 101b1df:	jmp    101b2e9 <map_prepare+0x1e9>
 101b1e4:	mov    %rdi,-0x30(%rbp)
 101b1e8:	mov    %rsi,-0x40(%rbp)
 101b1ec:	mov    %rcx,-0x38(%rbp)
 101b1f0:	mov    $0x1,%edi
 101b1f5:	mov    %rbx,%rsi
 101b1f8:	call   1027510 <calloc@plt>
 101b1fd:	mov    %rax,%rcx
 101b200:	xor    %eax,%eax
 101b202:	test   %rcx,%rcx
 101b205:	je     101b2e9 <map_prepare+0x1e9>
 101b20b:	mov    -0x30(%rbp),%rax
 101b20f:	mov    %r13,0x18(%rax)
 101b213:	add    %rbx,0x30(%r12)
 101b218:	mov    $0x3f,%edx
 101b21d:	cmp    $0x2,%r15
 101b221:	mov    -0x38(%rbp),%rax
 101b225:	mov    -0x40(%rbp),%rsi
 101b229:	jb     101b259 <map_prepare+0x159>
 101b22b:	mov    $0x40,%edi
 101b230:	mov    %r15,%r8
 101b233:	mov    %r15,%rdx
 101b236:	cs nopw 0x0(%rax,%rax,1)
 101b240:	shr    $1,%rdx
 101b243:	dec    %edi
 101b245:	cmp    $0x3,%r8
 101b249:	mov    %rdx,%r8
 101b24c:	ja     101b240 <map_prepare+0x140>
 101b24e:	cmp    $0x3f,%edi
 101b251:	mov    $0x3f,%edx
 101b256:	cmovb  %edi,%edx
 101b259:	dec    %r15
 101b25c:	cmp    $0x100b5f0,%r14
 101b263:	je     101b2dd <map_prepare+0x1dd>
 101b265:	mov    0x8(%rsi),%rsi
 101b269:	inc    %rsi
 101b26c:	xor    %edi,%edi
 101b26e:	movabs $0x9e3779b97f4a7c15,%r8
 101b278:	jmp    101b28f <map_prepare+0x18f>
 101b27a:	nopw   0x0(%rax,%rax,1)
 101b280:	add    %rcx,%rbx
 101b283:	vmovups (%r9),%xmm0
 101b288:	vmovups %xmm0,(%rbx)
 101b28c:	inc    %rdi
 101b28f:	cmp    %rsi,%rdi
 101b292:	je     101b2dd <map_prepare+0x1dd>
 101b294:	mov    %rdi,%r9
 101b297:	shl    $0x4,%r9
 101b29b:	mov    (%r14,%r9,1),%r10
 101b29f:	test   %r10,%r10
 101b2a2:	je     101b28c <map_prepare+0x18c>
 101b2a4:	add    %r14,%r9
 101b2a7:	mov    %r10,%r11
 101b2aa:	imul   %r8,%r11
 101b2ae:	shrx   %rdx,%r11,%r11
 101b2b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b2c0:	and    %r15,%r11
 101b2c3:	mov    %r11,%rbx
 101b2c6:	shl    $0x4,%rbx
 101b2ca:	mov    (%rcx,%rbx,1),%r12
 101b2ce:	test   %r12,%r12
 101b2d1:	je     101b280 <map_prepare+0x180>
 101b2d3:	inc    %r11
 101b2d6:	cmp    %r10,%r12
 101b2d9:	jne    101b2c0 <map_prepare+0x1c0>
 101b2db:	jmp    101b280 <map_prepare+0x180>
 101b2dd:	mov    %rcx,(%rax)
 101b2e0:	mov    %r15,0x8(%rax)
 101b2e4:	mov    $0x1,%eax
 101b2e9:	add    $0x18,%rsp
 101b2ed:	pop    %rbx
 101b2ee:	pop    %r12
 101b2f0:	pop    %r13
 101b2f2:	pop    %r14
 101b2f4:	pop    %r15
 101b2f6:	pop    %rbp
 101b2f7:	ret
 101b2f8:	call   10187d4 <myl_rc_invariant_failed>
 101b2fd:	int3
 101b2fe:	int3
 101b2ff:	int3

000000000101b300 <myl_rc_edges_release>:
 101b300:	push   %rbp
 101b301:	mov    %rsp,%rbp
 101b304:	push   %r15
 101b306:	push   %r14
 101b308:	push   %r13
 101b30a:	push   %r12
 101b30c:	push   %rbx
 101b30d:	sub    $0x48,%rsp
 101b311:	test   %rdi,%rdi
 101b314:	je     101b8b7 <myl_rc_edges_release+0x5b7>
 101b31a:	mov    %rdi,%r10
 101b31d:	mov    0x1608(%rdi),%rdi
 101b324:	test   %rdi,%rdi
 101b327:	je     101b8b7 <myl_rc_edges_release+0x5b7>
 101b32d:	cmpq   $0x0,0xc0(%rdi)
 101b335:	jne    101b8b7 <myl_rc_edges_release+0x5b7>
 101b33b:	mov    %rdx,%r14
 101b33e:	mov    0x58(%rdi),%rax
 101b342:	mov    0x60(%rdi),%rdx
 101b346:	movzbl 0x70(%rdi),%r8d
 101b34b:	movabs $0x9e3779b97f4a7c15,%rdi
 101b355:	imul   %rsi,%rdi
 101b359:	shrx   %r8,%rdi,%r8
 101b35e:	xchg   %ax,%ax
 101b360:	and    %rdx,%r8
 101b363:	mov    %r8,%rdi
 101b366:	shl    $0x4,%rdi
 101b36a:	mov    (%rax,%rdi,1),%rdi
 101b36e:	cmp    %rsi,%rdi
 101b371:	je     101b381 <myl_rc_edges_release+0x81>
 101b373:	test   %rdi,%rdi
 101b376:	je     101b8b7 <myl_rc_edges_release+0x5b7>
 101b37c:	inc    %r8
 101b37f:	jmp    101b360 <myl_rc_edges_release+0x60>
 101b381:	shl    $0x4,%r8
 101b385:	mov    0x8(%rax,%r8,1),%r11
 101b38a:	test   %r11,%r11
 101b38d:	je     101b8b7 <myl_rc_edges_release+0x5b7>
 101b393:	mov    %rcx,%rax
 101b396:	mulq   (%r11)
 101b399:	jo     101b8b7 <myl_rc_edges_release+0x5b7>
 101b39f:	test   %r14,%r14
 101b3a2:	jne    101b3ad <myl_rc_edges_release+0xad>
 101b3a4:	test   %rax,%rax
 101b3a7:	jne    101b8b7 <myl_rc_edges_release+0x5b7>
 101b3ad:	mov    0x8(%r11),%eax
 101b3b1:	test   %eax,%eax
 101b3b3:	je     101b8a8 <myl_rc_edges_release+0x5a8>
 101b3b9:	cmp    $0x1,%eax
 101b3bc:	mov    %r10,-0x50(%rbp)
 101b3c0:	jne    101b3e1 <myl_rc_edges_release+0xe1>
 101b3c2:	test   %rcx,%rcx
 101b3c5:	je     101b8a8 <myl_rc_edges_release+0x5a8>
 101b3cb:	movabs $0x4000000000000002,%rbx
 101b3d5:	xor    %r15d,%r15d
 101b3d8:	lea    0x1(%rbx),%r12
 101b3dc:	jmp    101b7bc <myl_rc_edges_release+0x4bc>
 101b3e1:	test   %rcx,%rcx
 101b3e4:	je     101b8a8 <myl_rc_edges_release+0x5a8>
 101b3ea:	mov    0x28(%r11),%rax
 101b3ee:	mov    %rax,-0x68(%rbp)
 101b3f2:	xor    %r15d,%r15d
 101b3f5:	jmp    101b451 <myl_rc_edges_release+0x151>
 101b3f7:	nopw   0x0(%rax,%rax,1)
 101b400:	mov    0xb0(%rax),%rdx
 101b407:	lea    0x1(%rcx),%rsi
 101b40b:	mov    %rsi,0xc0(%rax)
 101b412:	lea    (%rcx,%rcx,2),%rax
 101b416:	mov    %r11,(%rdx,%rax,8)
 101b41a:	mov    %r14,0x8(%rdx,%rax,8)
 101b41f:	movq   $0x0,0x10(%rdx,%rax,8)
 101b428:	mov    %r10,%rdi
 101b42b:	mov    $0x1,%esi
 101b430:	mov    %r11,%r12
 101b433:	call   101b8c0 <walk>
 101b438:	mov    %r12,%r11
 101b43b:	mov    -0x50(%rbp),%r10
 101b43f:	mov    %rbx,%rcx
 101b442:	add    (%r11),%r14
 101b445:	inc    %r15
 101b448:	cmp    %rcx,%r15
 101b44b:	je     101b8a8 <myl_rc_edges_release+0x5a8>
 101b451:	mov    0x8(%r11),%r8d
 101b455:	cmpq   $0x2,-0x68(%rbp)
 101b45a:	jbe    101b480 <myl_rc_edges_release+0x180>
 101b45c:	mov    %rcx,%rbx
 101b45f:	test   %r8d,%r8d
 101b462:	je     101b428 <myl_rc_edges_release+0x128>
 101b464:	mov    0x1608(%r10),%rax
 101b46b:	mov    0xc0(%rax),%rcx
 101b472:	cmp    0xb8(%rax),%rcx
 101b479:	jb     101b400 <myl_rc_edges_release+0x100>
 101b47b:	jmp    101b8b7 <myl_rc_edges_release+0x5b7>
 101b480:	lea    -0x1(%r8),%eax
 101b484:	cmp    $0x4,%eax
 101b487:	ja     101b4ec <myl_rc_edges_release+0x1ec>
 101b489:	jmp    *0x1001ae0(,%rax,8)
 101b490:	mov    $0x1,%edi
 101b495:	jmp    101b4ee <myl_rc_edges_release+0x1ee>
 101b497:	mov    0x10(%r11),%rax
 101b49b:	mov    %rax,-0x38(%rbp)
 101b49f:	mov    0x18(%r11),%rdi
 101b4a3:	mov    0x20(%r11),%r13
 101b4a7:	add    %r14,%r13
 101b4aa:	mov    $0x4,%r8d
 101b4b0:	movq   $0x0,-0x48(%rbp)
 101b4b8:	jmp    101b501 <myl_rc_edges_release+0x201>
 101b4ba:	mov    0x10(%r11),%rax
 101b4be:	mov    %rax,-0x38(%rbp)
 101b4c2:	mov    0x18(%r11),%rdi
 101b4c6:	mov    $0x2,%r8d
 101b4cc:	movq   $0x0,-0x48(%rbp)
 101b4d4:	jmp    101b4fe <myl_rc_edges_release+0x1fe>
 101b4d6:	mov    0x10(%r11),%rax
 101b4da:	mov    0x18(%r11),%rdi
 101b4de:	mov    0x20(%r11),%rdx
 101b4e2:	mov    %rdx,-0x48(%rbp)
 101b4e6:	mov    0x8(%rax),%r8d
 101b4ea:	jmp    101b4f6 <myl_rc_edges_release+0x1f6>
 101b4ec:	xor    %edi,%edi
 101b4ee:	movq   $0x0,-0x48(%rbp)
 101b4f6:	movq   $0x0,-0x38(%rbp)
 101b4fe:	xor    %r13d,%r13d
 101b501:	mov    %rdi,%r12
 101b504:	neg    %r12
 101b507:	xor    %ebx,%ebx
 101b509:	mov    %rdi,-0x30(%rbp)
 101b50d:	cmpq   $0x0,-0x38(%rbp)
 101b512:	je     101b5f0 <myl_rc_edges_release+0x2f0>
 101b518:	cmp    %rdi,%rbx
 101b51b:	jae    101b442 <myl_rc_edges_release+0x142>
 101b521:	lea    (%rbx,%rbx,2),%rax
 101b525:	mov    -0x38(%rbp),%rdx
 101b529:	lea    (%rdx,%rax,8),%rax
 101b52d:	inc    %rbx
 101b530:	jmp    101b558 <myl_rc_edges_release+0x258>
 101b532:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b540:	add    $0x18,%rax
 101b544:	lea    (%r12,%rbx,1),%rdx
 101b548:	inc    %rdx
 101b54b:	inc    %rbx
 101b54e:	cmp    $0x1,%rdx
 101b552:	je     101b442 <myl_rc_edges_release+0x142>
 101b558:	mov    0x8(%rax),%rdx
 101b55c:	mov    0x8(%rdx),%edi
 101b55f:	test   %edi,%edi
 101b561:	je     101b540 <myl_rc_edges_release+0x240>
 101b563:	test   %r13,%r13
 101b566:	je     101b571 <myl_rc_edges_release+0x271>
 101b568:	mov    0x10(%rax),%edx
 101b56b:	cmp    0x0(%r13),%edx
 101b56f:	jne    101b540 <myl_rc_edges_release+0x240>
 101b571:	mov    (%rax),%rax
 101b574:	mov    (%r14,%rax,1),%rsi
 101b578:	movq   $0x0,(%r14,%rax,1)
 101b580:	cmp    $0x5,%edi
 101b583:	je     101b61c <myl_rc_edges_release+0x31c>
 101b589:	test   %rsi,%rsi
 101b58c:	mov    -0x30(%rbp),%rdi
 101b590:	je     101b50d <myl_rc_edges_release+0x20d>
 101b596:	mov    -0x10(%rsi),%rdx
 101b59a:	movabs $0x4000000000000002,%rax
 101b5a4:	test   %rax,%rdx
 101b5a7:	jne    101b50d <myl_rc_edges_release+0x20d>
 101b5ad:	test   $0x1,%dl
 101b5b0:	jne    101b8b7 <myl_rc_edges_release+0x5b7>
 101b5b6:	mov    -0x20(%rsi),%rax
 101b5ba:	test   %rax,%rax
 101b5bd:	je     101b8b7 <myl_rc_edges_release+0x5b7>
 101b5c3:	lea    -0x20(%rsi),%r9
 101b5c7:	dec    %rax
 101b5ca:	mov    %rax,(%r9)
 101b5cd:	jne    101b50d <myl_rc_edges_release+0x20d>
 101b5d3:	cmpq   $0x0,-0x18(%rsi)
 101b5d8:	jne    101b50d <myl_rc_edges_release+0x20d>
 101b5de:	jmp    101b66b <myl_rc_edges_release+0x36b>
 101b5e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b5f0:	cmp    %rdi,%rbx
 101b5f3:	je     101b442 <myl_rc_edges_release+0x142>
 101b5f9:	mov    %rbx,%rax
 101b5fc:	inc    %rbx
 101b5ff:	imul   -0x48(%rbp),%rax
 101b604:	mov    %r8d,%edi
 101b607:	mov    (%r14,%rax,1),%rsi
 101b60b:	movq   $0x0,(%r14,%rax,1)
 101b613:	cmp    $0x5,%edi
 101b616:	jne    101b589 <myl_rc_edges_release+0x289>
 101b61c:	test   %rsi,%rsi
 101b61f:	mov    -0x30(%rbp),%rdi
 101b623:	je     101b50d <myl_rc_edges_release+0x20d>
 101b629:	mov    -0x10(%rsi),%rdx
 101b62d:	movabs $0x4000000000000002,%rax
 101b637:	test   %rax,%rdx
 101b63a:	jne    101b50d <myl_rc_edges_release+0x20d>
 101b640:	test   $0x1,%dl
 101b643:	jne    101b8b7 <myl_rc_edges_release+0x5b7>
 101b649:	mov    -0x18(%rsi),%rax
 101b64d:	test   %rax,%rax
 101b650:	je     101b8b7 <myl_rc_edges_release+0x5b7>
 101b656:	dec    %rax
 101b659:	mov    %rax,-0x18(%rsi)
 101b65d:	or     -0x20(%rsi),%rax
 101b661:	jne    101b50d <myl_rc_edges_release+0x20d>
 101b667:	lea    -0x20(%rsi),%r9
 101b66b:	or     $0x1,%rdx
 101b66f:	mov    %rdx,-0x10(%rsi)
 101b673:	mov    0x1608(%r10),%rdi
 101b67a:	cmpl   $0x0,0xd0(%rdi)
 101b681:	je     101b6a4 <myl_rc_edges_release+0x3a4>
 101b683:	mov    0xc8(%rdi),%rax
 101b68a:	mov    %rax,(%r9)
 101b68d:	mov    0x1608(%r10),%rax
 101b694:	mov    %r9,0xc8(%rax)
 101b69b:	mov    -0x30(%rbp),%rdi
 101b69f:	jmp    101b50d <myl_rc_edges_release+0x20d>
 101b6a4:	mov    -0x8(%rsi),%rax
 101b6a8:	cmp    %rax,0x110(%rdi)
 101b6af:	mov    %r8,-0x40(%rbp)
 101b6b3:	je     101b71c <myl_rc_edges_release+0x41c>
 101b6b5:	mov    0x34(%rax),%edx
 101b6b8:	cmp    %rdx,0xa0(%rdi)
 101b6bf:	jbe    101b764 <myl_rc_edges_release+0x464>
 101b6c5:	mov    0x98(%rdi),%r8
 101b6cc:	shl    $0x4,%rdx
 101b6d0:	cmp    %rax,(%r8,%rdx,1)
 101b6d4:	jne    101b764 <myl_rc_edges_release+0x464>
 101b6da:	add    %rdx,%r8
 101b6dd:	mov    0x8(%r8),%rax
 101b6e1:	mov    -0x30(%rbp),%rdi
 101b6e5:	test   %rax,%rax
 101b6e8:	mov    -0x40(%rbp),%r8
 101b6ec:	je     101b6f4 <myl_rc_edges_release+0x3f4>
 101b6ee:	cmpl   $0x0,0x40(%rax)
 101b6f2:	je     101b718 <myl_rc_edges_release+0x418>
 101b6f4:	mov    0x1608(%r10),%rax
 101b6fb:	mov    0xc8(%rax),%rax
 101b702:	mov    %rax,(%r9)
 101b705:	mov    0x1608(%r10),%rax
 101b70c:	mov    %r9,0xc8(%rax)
 101b713:	jmp    101b50d <myl_rc_edges_release+0x20d>
 101b718:	mov    -0x10(%rsi),%rdx
 101b71c:	mov    %r11,-0x58(%rbp)
 101b720:	mov    %rcx,-0x60(%rbp)
 101b724:	movabs $0x4000000000000002,%rax
 101b72e:	inc    %rax
 101b731:	and    %rdx,%rax
 101b734:	cmp    $0x1,%rax
 101b738:	jne    101b8b7 <myl_rc_edges_release+0x5b7>
 101b73e:	mov    0x1608(%r10),%rax
 101b745:	mov    %r10,%rdi
 101b748:	call   *0x8(%rax)
 101b74b:	mov    -0x50(%rbp),%r10
 101b74f:	mov    -0x60(%rbp),%rcx
 101b753:	mov    -0x58(%rbp),%r11
 101b757:	mov    -0x40(%rbp),%r8
 101b75b:	mov    -0x30(%rbp),%rdi
 101b75f:	jmp    101b50d <myl_rc_edges_release+0x20d>
 101b764:	mov    %rsi,%rdx
 101b767:	mov    %rax,%rsi
 101b76a:	mov    %r11,%r8
 101b76d:	call   1018df4 <myl_rc_binding_find_slow>
 101b772:	mov    %r8,%r11
 101b775:	mov    %rdx,%rsi
 101b778:	mov    -0x30(%rbp),%rdi
 101b77c:	test   %rax,%rax
 101b77f:	mov    -0x40(%rbp),%r8
 101b783:	jne    101b6ee <myl_rc_edges_release+0x3ee>
 101b789:	jmp    101b6f4 <myl_rc_edges_release+0x3f4>
 101b78e:	mov    0xc8(%rdi),%rax
 101b795:	mov    %rax,(%r9)
 101b798:	mov    0x1608(%r10),%rax
 101b79f:	mov    %r9,0xc8(%rax)
 101b7a6:	cs nopw 0x0(%rax,%rax,1)
 101b7b0:	inc    %r15
 101b7b3:	cmp    %r15,%rcx
 101b7b6:	je     101b8a8 <myl_rc_edges_release+0x5a8>
 101b7bc:	mov    (%r14,%r15,8),%rsi
 101b7c0:	movq   $0x0,(%r14,%r15,8)
 101b7c8:	test   %rsi,%rsi
 101b7cb:	je     101b7b0 <myl_rc_edges_release+0x4b0>
 101b7cd:	mov    -0x10(%rsi),%rdx
 101b7d1:	test   %rbx,%rdx
 101b7d4:	jne    101b7b0 <myl_rc_edges_release+0x4b0>
 101b7d6:	test   $0x1,%dl
 101b7d9:	jne    101b8b7 <myl_rc_edges_release+0x5b7>
 101b7df:	mov    -0x20(%rsi),%rax
 101b7e3:	test   %rax,%rax
 101b7e6:	je     101b8b7 <myl_rc_edges_release+0x5b7>
 101b7ec:	lea    -0x20(%rsi),%r9
 101b7f0:	dec    %rax
 101b7f3:	mov    %rax,(%r9)
 101b7f6:	jne    101b7b0 <myl_rc_edges_release+0x4b0>
 101b7f8:	cmpq   $0x0,-0x18(%rsi)
 101b7fd:	jne    101b7b0 <myl_rc_edges_release+0x4b0>
 101b7ff:	or     $0x1,%rdx
 101b803:	mov    %rdx,-0x10(%rsi)
 101b807:	mov    0x1608(%r10),%rdi
 101b80e:	cmpl   $0x0,0xd0(%rdi)
 101b815:	jne    101b78e <myl_rc_edges_release+0x48e>
 101b81b:	mov    -0x8(%rsi),%rax
 101b81f:	cmp    %rax,0x110(%rdi)
 101b826:	je     101b86e <myl_rc_edges_release+0x56e>
 101b828:	mov    0x34(%rax),%edx
 101b82b:	cmp    %rdx,0xa0(%rdi)
 101b832:	jbe    101b893 <myl_rc_edges_release+0x593>
 101b834:	mov    0x98(%rdi),%r8
 101b83b:	shl    $0x4,%rdx
 101b83f:	cmp    %rax,(%r8,%rdx,1)
 101b843:	jne    101b893 <myl_rc_edges_release+0x593>
 101b845:	add    %rdx,%r8
 101b848:	mov    0x8(%r8),%rax
 101b84c:	test   %rax,%rax
 101b84f:	je     101b857 <myl_rc_edges_release+0x557>
 101b851:	cmpl   $0x0,0x40(%rax)
 101b855:	je     101b86a <myl_rc_edges_release+0x56a>
 101b857:	mov    0x1608(%r10),%rax
 101b85e:	mov    0xc8(%rax),%rax
 101b865:	jmp    101b795 <myl_rc_edges_release+0x495>
 101b86a:	mov    -0x10(%rsi),%rdx
 101b86e:	and    %r12,%rdx
 101b871:	cmp    $0x1,%rdx
 101b875:	jne    101b8b7 <myl_rc_edges_release+0x5b7>
 101b877:	mov    %rcx,%r13
 101b87a:	mov    0x1608(%r10),%rax
 101b881:	mov    %r10,%rdi
 101b884:	call   *0x8(%rax)
 101b887:	mov    -0x50(%rbp),%r10
 101b88b:	mov    %r13,%rcx
 101b88e:	jmp    101b7b0 <myl_rc_edges_release+0x4b0>
 101b893:	mov    %rsi,%rdx
 101b896:	mov    %rax,%rsi
 101b899:	call   1018df4 <myl_rc_binding_find_slow>
 101b89e:	mov    %rdx,%rsi
 101b8a1:	test   %rax,%rax
 101b8a4:	jne    101b851 <myl_rc_edges_release+0x551>
 101b8a6:	jmp    101b857 <myl_rc_edges_release+0x557>
 101b8a8:	add    $0x48,%rsp
 101b8ac:	pop    %rbx
 101b8ad:	pop    %r12
 101b8af:	pop    %r13
 101b8b1:	pop    %r14
 101b8b3:	pop    %r15
 101b8b5:	pop    %rbp
 101b8b6:	ret
 101b8b7:	call   10187d4 <myl_rc_invariant_failed>
 101b8bc:	int3
 101b8bd:	int3
 101b8be:	int3
 101b8bf:	int3

000000000101b8c0 <walk>:
 101b8c0:	push   %rbp
 101b8c1:	mov    %rsp,%rbp
 101b8c4:	push   %r14
 101b8c6:	push   %rbx
 101b8c7:	mov    0x1608(%rdi),%rdx
 101b8ce:	mov    0xc0(%rdx),%rax
 101b8d5:	test   %rax,%rax
 101b8d8:	je     101ba64 <walk+0x1a4>
 101b8de:	mov    %esi,%ebx
 101b8e0:	mov    %rdi,%r14
 101b8e3:	lea    0xc0(%rdx),%rcx
 101b8ea:	jmp    101b914 <walk+0x54>
 101b8ec:	nopl   0x0(%rax)
 101b8f0:	dec    %rax
 101b8f3:	mov    %rax,(%rcx)
 101b8f6:	mov    0x1608(%r14),%rdx
 101b8fd:	lea    0xc0(%rdx),%rcx
 101b904:	mov    0xc0(%rdx),%rax
 101b90b:	test   %rax,%rax
 101b90e:	je     101ba64 <walk+0x1a4>
 101b914:	mov    0xb0(%rdx),%rsi
 101b91b:	lea    (%rax,%rax,2),%r8
 101b91f:	mov    -0x18(%rsi,%r8,8),%rdi
 101b924:	mov    0x8(%rdi),%r10d
 101b928:	lea    -0x1(%r10),%r9d
 101b92c:	cmp    $0x4,%r9d
 101b930:	ja     101ba69 <walk+0x1a9>
 101b936:	lea    (%rsi,%r8,8),%rsi
 101b93a:	jmp    *0x1001b08(,%r9,8)
 101b942:	mov    -0x10(%rsi),%rax
 101b946:	mov    (%rax),%rsi
 101b949:	movq   $0x0,(%rax)
 101b950:	mov    0x1608(%r14),%rax
 101b957:	decq   0xc0(%rax)
 101b95e:	test   %ebx,%ebx
 101b960:	je     101b8f6 <walk+0x36>
 101b962:	cmpl   $0x5,0x8(%rdi)
 101b966:	jne    101ba57 <walk+0x197>
 101b96c:	mov    %r14,%rdi
 101b96f:	call   1018ce0 <myl_rc_hold_edge_release>
 101b974:	mov    0x1608(%r14),%rax
 101b97b:	test   %rax,%rax
 101b97e:	je     101b8f6 <walk+0x36>
 101b984:	cmpq   $0x0,0xc8(%rax)
 101b98c:	je     101b8f6 <walk+0x36>
 101b992:	mov    %r14,%rdi
 101b995:	call   101bcb0 <myl_rc_drain>
 101b99a:	jmp    101b8f6 <walk+0x36>
 101b99f:	nop
 101b9a0:	mov    -0x8(%rsi),%r9
 101b9a4:	cmp    0x18(%rdi),%r9
 101b9a8:	je     101b8f0 <walk+0x30>
 101b9ae:	lea    (%r9,%r9,2),%r8
 101b9b2:	shl    $0x3,%r8
 101b9b6:	add    0x10(%rdi),%r8
 101b9ba:	inc    %r9
 101b9bd:	mov    %r9,-0x8(%rsi)
 101b9c1:	mov    -0x10(%rsi),%r9
 101b9c5:	cmp    $0x4,%r10d
 101b9c9:	jne    101b9dd <walk+0x11d>
 101b9cb:	mov    0x20(%rdi),%rdi
 101b9cf:	mov    0x10(%r8),%r10d
 101b9d3:	cmp    (%r9,%rdi,1),%r10d
 101b9d7:	jne    101b8f6 <walk+0x36>
 101b9dd:	mov    0x8(%r8),%rdi
 101b9e1:	cmpl   $0x0,0x8(%rdi)
 101b9e5:	je     101b8f6 <walk+0x36>
 101b9eb:	cmp    0xb8(%rdx),%rax
 101b9f2:	jae    101ba69 <walk+0x1a9>
 101b9f4:	add    (%r8),%r9
 101b9f7:	inc    %rax
 101b9fa:	mov    %rax,(%rcx)
 101b9fd:	mov    %rdi,(%rsi)
 101ba00:	mov    %r9,0x8(%rsi)
 101ba04:	jmp    101ba4a <walk+0x18a>
 101ba06:	mov    -0x8(%rsi),%r8
 101ba0a:	cmp    0x18(%rdi),%r8
 101ba0e:	je     101b8f0 <walk+0x30>
 101ba14:	lea    0x1(%r8),%r9
 101ba18:	mov    %r9,-0x8(%rsi)
 101ba1c:	mov    0x10(%rdi),%r9
 101ba20:	cmpl   $0x0,0x8(%r9)
 101ba25:	je     101b8f6 <walk+0x36>
 101ba2b:	cmp    0xb8(%rdx),%rax
 101ba32:	jae    101ba69 <walk+0x1a9>
 101ba34:	imul   0x20(%rdi),%r8
 101ba39:	add    -0x10(%rsi),%r8
 101ba3d:	inc    %rax
 101ba40:	mov    %rax,(%rcx)
 101ba43:	mov    %r9,(%rsi)
 101ba46:	mov    %r8,0x8(%rsi)
 101ba4a:	movq   $0x0,0x10(%rsi)
 101ba52:	jmp    101b8f6 <walk+0x36>
 101ba57:	mov    %r14,%rdi
 101ba5a:	call   1018bc0 <myl_rc_edge_release>
 101ba5f:	jmp    101b8f6 <walk+0x36>
 101ba64:	pop    %rbx
 101ba65:	pop    %r14
 101ba67:	pop    %rbp
 101ba68:	ret
 101ba69:	call   10187d4 <myl_rc_invariant_failed>
 101ba6e:	int3
 101ba6f:	int3

000000000101ba70 <myl_rc_flat_edges_release>:
 101ba70:	push   %rbp
 101ba71:	mov    %rsp,%rbp
 101ba74:	push   %r15
 101ba76:	push   %r14
 101ba78:	push   %r13
 101ba7a:	push   %r12
 101ba7c:	push   %rbx
 101ba7d:	sub    $0x18,%rsp
 101ba81:	test   %rdi,%rdi
 101ba84:	je     101bca8 <myl_rc_flat_edges_release+0x238>
 101ba8a:	mov    %rdi,%r10
 101ba8d:	mov    0x1608(%rdi),%rax
 101ba94:	test   %rax,%rax
 101ba97:	je     101bca8 <myl_rc_flat_edges_release+0x238>
 101ba9d:	cmpq   $0x0,0xc0(%rax)
 101baa5:	jne    101bca8 <myl_rc_flat_edges_release+0x238>
 101baab:	mov    %rsi,%r15
 101baae:	mov    0x40(%rsi),%esi
 101bab1:	cmp    $0x11,%esi
 101bab4:	jae    101bca8 <myl_rc_flat_edges_release+0x238>
 101baba:	mov    %rdx,%r14
 101babd:	mov    0x50(%r15),%rdi
 101bac1:	mov    %rdi,%rax
 101bac4:	mul    %rcx
 101bac7:	jo     101bca8 <myl_rc_flat_edges_release+0x238>
 101bacd:	test   %rax,%rax
 101bad0:	sete   %al
 101bad3:	test   %r14,%r14
 101bad6:	setne  %dl
 101bad9:	or     %al,%dl
 101badb:	je     101bca8 <myl_rc_flat_edges_release+0x238>
 101bae1:	test   %esi,%esi
 101bae3:	sete   %al
 101bae6:	test   %rcx,%rcx
 101bae9:	sete   %dl
 101baec:	or     %al,%dl
 101baee:	jne    101bc99 <myl_rc_flat_edges_release+0x229>
 101baf4:	movabs $0x4000000000000002,%r13
 101bafe:	lea    0x5c(%r15),%r11
 101bb02:	lea    0x5a(%r15),%r8
 101bb06:	xor    %ebx,%ebx
 101bb08:	mov    %rcx,-0x38(%rbp)
 101bb0c:	mov    %r10,-0x30(%rbp)
 101bb10:	jmp    101bb33 <myl_rc_flat_edges_release+0xc3>
 101bb12:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101bb20:	mov    0x50(%r15),%rdi
 101bb24:	add    %rdi,%r14
 101bb27:	inc    %rbx
 101bb2a:	cmp    %rcx,%rbx
 101bb2d:	je     101bc99 <myl_rc_flat_edges_release+0x229>
 101bb33:	cmpb   $0x0,0x46(%r15)
 101bb38:	lea    0x58(%r15),%rax
 101bb3c:	je     101bb52 <myl_rc_flat_edges_release+0xe2>
 101bb3e:	mov    0x48(%r15),%eax
 101bb42:	mov    (%r14,%rax,1),%eax
 101bb46:	cmp    $0x20,%rax
 101bb4a:	lea    (%r11,%rax,2),%rax
 101bb4e:	cmovae %r8,%rax
 101bb52:	movzwl (%rax),%r12d
 101bb56:	test   %r12d,%r12d
 101bb59:	jne    101bb87 <myl_rc_flat_edges_release+0x117>
 101bb5b:	jmp    101bb24 <myl_rc_flat_edges_release+0xb4>
 101bb5d:	mov    0xc8(%rdi),%rax
 101bb64:	mov    %rax,(%r9)
 101bb67:	mov    0x1608(%r10),%rax
 101bb6e:	mov    %r9,0xc8(%rax)
 101bb75:	data16 cs nopw 0x0(%rax,%rax,1)
 101bb80:	blsr   %r12d,%r12d
 101bb85:	je     101bb20 <myl_rc_flat_edges_release+0xb0>
 101bb87:	tzcnt  %r12d,%eax
 101bb8c:	movzwl 0x9c(%r15,%rax,2),%eax
 101bb95:	mov    (%r14,%rax,1),%rsi
 101bb99:	movq   $0x0,(%r14,%rax,1)
 101bba1:	test   %rsi,%rsi
 101bba4:	je     101bb80 <myl_rc_flat_edges_release+0x110>
 101bba6:	mov    -0x10(%rsi),%rdx
 101bbaa:	test   %r13,%rdx
 101bbad:	jne    101bb80 <myl_rc_flat_edges_release+0x110>
 101bbaf:	test   $0x1,%dl
 101bbb2:	jne    101bca8 <myl_rc_flat_edges_release+0x238>
 101bbb8:	mov    -0x20(%rsi),%rax
 101bbbc:	test   %rax,%rax
 101bbbf:	je     101bca8 <myl_rc_flat_edges_release+0x238>
 101bbc5:	lea    -0x20(%rsi),%r9
 101bbc9:	dec    %rax
 101bbcc:	mov    %rax,(%r9)
 101bbcf:	jne    101bb80 <myl_rc_flat_edges_release+0x110>
 101bbd1:	cmpq   $0x0,-0x18(%rsi)
 101bbd6:	jne    101bb80 <myl_rc_flat_edges_release+0x110>
 101bbd8:	or     $0x1,%rdx
 101bbdc:	mov    %rdx,-0x10(%rsi)
 101bbe0:	mov    0x1608(%r10),%rdi
 101bbe7:	cmpl   $0x0,0xd0(%rdi)
 101bbee:	jne    101bb5d <myl_rc_flat_edges_release+0xed>
 101bbf4:	mov    -0x8(%rsi),%rax
 101bbf8:	cmp    %rax,0x110(%rdi)
 101bbff:	je     101bc4b <myl_rc_flat_edges_release+0x1db>
 101bc01:	mov    0x34(%rax),%edx
 101bc04:	cmp    %rdx,0xa0(%rdi)
 101bc0b:	jbe    101bc7a <myl_rc_flat_edges_release+0x20a>
 101bc0d:	mov    0x98(%rdi),%r8
 101bc14:	shl    $0x4,%rdx
 101bc18:	cmp    %rax,(%r8,%rdx,1)
 101bc1c:	jne    101bc7a <myl_rc_flat_edges_release+0x20a>
 101bc1e:	add    %rdx,%r8
 101bc21:	mov    0x8(%r8),%rax
 101bc25:	test   %rax,%rax
 101bc28:	lea    0x5a(%r15),%r8
 101bc2c:	je     101bc34 <myl_rc_flat_edges_release+0x1c4>
 101bc2e:	cmpl   $0x0,0x40(%rax)
 101bc32:	je     101bc47 <myl_rc_flat_edges_release+0x1d7>
 101bc34:	mov    0x1608(%r10),%rax
 101bc3b:	mov    0xc8(%rax),%rax
 101bc42:	jmp    101bb64 <myl_rc_flat_edges_release+0xf4>
 101bc47:	mov    -0x10(%rsi),%rdx
 101bc4b:	lea    0x1(%r13),%rax
 101bc4f:	and    %rax,%rdx
 101bc52:	cmp    $0x1,%rdx
 101bc56:	jne    101bca8 <myl_rc_flat_edges_release+0x238>
 101bc58:	mov    0x1608(%r10),%rax
 101bc5f:	mov    %r10,%rdi
 101bc62:	call   *0x8(%rax)
 101bc65:	mov    -0x30(%rbp),%r10
 101bc69:	mov    -0x38(%rbp),%rcx
 101bc6d:	lea    0x5c(%r15),%r11
 101bc71:	lea    0x5a(%r15),%r8
 101bc75:	jmp    101bb80 <myl_rc_flat_edges_release+0x110>
 101bc7a:	mov    %rsi,%rdx
 101bc7d:	mov    %rax,%rsi
 101bc80:	mov    %r11,%r8
 101bc83:	call   1018df4 <myl_rc_binding_find_slow>
 101bc88:	mov    %r8,%r11
 101bc8b:	mov    %rdx,%rsi
 101bc8e:	test   %rax,%rax
 101bc91:	lea    0x5a(%r15),%r8
 101bc95:	jne    101bc2e <myl_rc_flat_edges_release+0x1be>
 101bc97:	jmp    101bc34 <myl_rc_flat_edges_release+0x1c4>
 101bc99:	add    $0x18,%rsp
 101bc9d:	pop    %rbx
 101bc9e:	pop    %r12
 101bca0:	pop    %r13
 101bca2:	pop    %r14
 101bca4:	pop    %r15
 101bca6:	pop    %rbp
 101bca7:	ret
 101bca8:	call   10187d4 <myl_rc_invariant_failed>
 101bcad:	int3
 101bcae:	int3
 101bcaf:	int3

000000000101bcb0 <myl_rc_drain>:
 101bcb0:	push   %rbp
 101bcb1:	mov    %rsp,%rbp
 101bcb4:	push   %r15
 101bcb6:	push   %r14
 101bcb8:	push   %r13
 101bcba:	push   %r12
 101bcbc:	push   %rbx
 101bcbd:	sub    $0x48,%rsp
 101bcc1:	test   %rdi,%rdi
 101bcc4:	je     101bde2 <myl_rc_drain+0x132>
 101bcca:	mov    %rdi,%rbx
 101bccd:	mov    0x1608(%rdi),%r13
 101bcd4:	test   %r13,%r13
 101bcd7:	je     101bde2 <myl_rc_drain+0x132>
 101bcdd:	mov    0xc8(%r13),%rax
 101bce4:	test   %rax,%rax
 101bce7:	je     101bdd3 <myl_rc_drain+0x123>
 101bced:	cmpl   $0x0,0xd0(%r13)
 101bcf5:	jne    101bdd3 <myl_rc_drain+0x123>
 101bcfb:	cmpq   $0x0,0xc0(%r13)
 101bd03:	jne    101bdd3 <myl_rc_drain+0x123>
 101bd09:	movl   $0x1,0xd0(%r13)
 101bd14:	xor    %r14d,%r14d
 101bd17:	cmpq   $0x1022730,0x8(%r13)
 101bd1f:	sete   %r14b
 101bd23:	vxorps %xmm0,%xmm0,%xmm0
 101bd27:	vmovups %ymm0,-0x48(%rbp)
 101bd2c:	vmovups %ymm0,-0x60(%rbp)
 101bd31:	mov    %rax,-0x68(%rbp)
 101bd35:	movq   $0xffffffffffffffff,-0x48(%rbp)
 101bd3d:	lea    -0x68(%rbp),%rsi
 101bd41:	mov    %rbx,%rdi
 101bd44:	mov    %r14d,%edx
 101bd47:	vzeroupper
 101bd4a:	call   101bdf0 <drain_fast>
 101bd4f:	test   %rax,%rax
 101bd52:	je     101bd89 <myl_rc_drain+0xd9>
 101bd54:	lea    -0x38(%rbp),%r15
 101bd58:	lea    -0x68(%rbp),%r12
 101bd5c:	nopl   0x0(%rax)
 101bd60:	mov    -0x68(%rbp),%rdx
 101bd64:	mov    %rbx,%rdi
 101bd67:	mov    %rax,%rsi
 101bd6a:	mov    %r15,%rcx
 101bd6d:	call   101c140 <drain_one>
 101bd72:	mov    %rax,-0x68(%rbp)
 101bd76:	mov    %rbx,%rdi
 101bd79:	mov    %r12,%rsi
 101bd7c:	mov    %r14d,%edx
 101bd7f:	call   101bdf0 <drain_fast>
 101bd84:	test   %rax,%rax
 101bd87:	jne    101bd60 <myl_rc_drain+0xb0>
 101bd89:	movq   $0x0,0xc8(%r13)
 101bd94:	mov    -0x38(%rbp),%rax
 101bd98:	test   %rax,%rax
 101bd9b:	je     101bdc8 <myl_rc_drain+0x118>
 101bd9d:	mov    0x40(%rbx),%rcx
 101bda1:	sub    %rax,%rcx
 101bda4:	jb     101bde2 <myl_rc_drain+0x132>
 101bda6:	mov    %rcx,0x40(%rbx)
 101bdaa:	add    0x50(%rbx),%rax
 101bdae:	mov    $0xffffffffffffffff,%rcx
 101bdb5:	cmovae %rax,%rcx
 101bdb9:	mov    %rcx,0x50(%rbx)
 101bdbd:	mov    -0x30(%rbp),%rax
 101bdc1:	add    %rax,0x1710(%rbx)
 101bdc8:	movl   $0x0,0xd0(%r13)
 101bdd3:	add    $0x48,%rsp
 101bdd7:	pop    %rbx
 101bdd8:	pop    %r12
 101bdda:	pop    %r13
 101bddc:	pop    %r14
 101bdde:	pop    %r15
 101bde0:	pop    %rbp
 101bde1:	ret
 101bde2:	call   10187d4 <myl_rc_invariant_failed>
 101bde7:	int3
 101bde8:	int3
 101bde9:	int3
 101bdea:	int3
 101bdeb:	int3
 101bdec:	int3
 101bded:	int3
 101bdee:	int3
 101bdef:	int3

000000000101bdf0 <drain_fast>:
 101bdf0:	push   %rbp
 101bdf1:	mov    %rsp,%rbp
 101bdf4:	push   %r15
 101bdf6:	push   %r14
 101bdf8:	push   %r13
 101bdfa:	push   %r12
 101bdfc:	push   %rbx
 101bdfd:	sub    $0x48,%rsp
 101be01:	mov    %rsi,%rax
 101be04:	mov    (%rsi),%rsi
 101be07:	mov    0x8(%rax),%rcx
 101be0b:	mov    %rcx,-0x40(%rbp)
 101be0f:	mov    0x10(%rax),%r14
 101be13:	mov    0x18(%rax),%r11
 101be17:	mov    0x20(%rax),%r15
 101be1b:	mov    0x28(%rax),%ebx
 101be1e:	vmovdqu 0x30(%rax),%xmm1
 101be23:	test   %rsi,%rsi
 101be26:	je     101c100 <drain_fast+0x310>
 101be2c:	mov    %edx,%r10d
 101be2f:	mov    %rdi,%r12
 101be32:	mov    %rax,-0x48(%rbp)
 101be36:	vmovdqa -0x1a55e(%rip),%xmm2        # 10018e0 <__abi_tag+0x15e4>
 101be3e:	movabs $0x4000000000000003,%r13
 101be48:	mov    %rdi,-0x58(%rbp)
 101be4c:	jmp    101bea2 <drain_fast+0xb2>
 101be4e:	xchg   %ax,%ax
 101be50:	vmovdqa %xmm1,-0x70(%rbp)
 101be55:	movzwl 0x5e(%r14),%r8d
 101be5a:	mov    0x5c(%r14),%ecx
 101be5e:	mov    %r12,%rdi
 101be61:	lea    -0x70(%rbp),%r9
 101be65:	mov    %ebx,-0x4c(%rbp)
 101be68:	mov    %r10d,%ebx
 101be6b:	mov    %r15,%r12
 101be6e:	mov    %r11,%r15
 101be71:	call   101c4f0 <drain_pairs>
 101be76:	mov    %r15,%r11
 101be79:	mov    %r12,%r15
 101be7c:	mov    -0x58(%rbp),%r12
 101be80:	vmovdqa -0x1a5a8(%rip),%xmm2        # 10018e0 <__abi_tag+0x15e4>
 101be88:	mov    %ebx,%r10d
 101be8b:	mov    -0x4c(%rbp),%ebx
 101be8e:	mov    %rax,%rdx
 101be91:	vmovdqa -0x70(%rbp),%xmm1
 101be96:	mov    %rdx,%rsi
 101be99:	test   %rdx,%rdx
 101be9c:	je     101c0f6 <drain_fast+0x306>
 101bea2:	mov    (%rsi),%rdx
 101bea5:	mov    0x18(%rsi),%rcx
 101bea9:	cmp    -0x40(%rbp),%rcx
 101bead:	je     101bfa8 <drain_fast+0x1b8>
 101beb3:	mov    0x1608(%r12),%rdi
 101bebb:	mov    0xd8(%rdi),%rax
 101bec2:	cmp    %rcx,%rax
 101bec5:	je     101bf20 <drain_fast+0x130>
 101bec7:	cmp    %rcx,0xe0(%rdi)
 101bece:	je     101bf41 <drain_fast+0x151>
 101bed0:	mov    0x34(%rcx),%eax
 101bed3:	cmp    %rax,0xa0(%rdi)
 101beda:	jbe    101c0c5 <drain_fast+0x2d5>
 101bee0:	mov    0x98(%rdi),%r8
 101bee7:	shl    $0x4,%rax
 101beeb:	cmp    %rcx,(%r8,%rax,1)
 101beef:	jne    101c0c5 <drain_fast+0x2d5>
 101bef5:	add    %rax,%r8
 101bef8:	mov    0x8(%r8),%r14
 101befc:	test   %r14,%r14
 101beff:	je     101c0f1 <drain_fast+0x301>
 101bf05:	add    $0x40,%r14
 101bf09:	mov    0xd8(%rdi),%rax
 101bf10:	jmp    101bf48 <drain_fast+0x158>
 101bf12:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101bf20:	mov    0xe8(%rdi),%r14
 101bf27:	mov    (%r14),%eax
 101bf2a:	test   %eax,%eax
 101bf2c:	jne    101bf72 <drain_fast+0x182>
 101bf2e:	xor    %ebx,%ebx
 101bf30:	movabs $0xc000000000000003,%r11
 101bf3a:	test   %r10d,%r10d
 101bf3d:	jne    101bf86 <drain_fast+0x196>
 101bf3f:	jmp    101bf9d <drain_fast+0x1ad>
 101bf41:	mov    0xf0(%rdi),%r14
 101bf48:	mov    %rax,0xe0(%rdi)
 101bf4f:	mov    0xe8(%rdi),%rax
 101bf56:	mov    %rax,0xf0(%rdi)
 101bf5d:	mov    %rcx,0xd8(%rdi)
 101bf64:	mov    %r14,0xe8(%rdi)
 101bf6b:	mov    (%r14),%eax
 101bf6e:	test   %eax,%eax
 101bf70:	je     101bf2e <drain_fast+0x13e>
 101bf72:	movzwl 0x18(%r14),%ebx
 101bf77:	movabs $0xcfffffffffffffff,%r11
 101bf81:	test   %r10d,%r10d
 101bf84:	je     101bf9d <drain_fast+0x1ad>
 101bf86:	cmp    $0x10,%eax
 101bf89:	ja     101bf9d <drain_fast+0x1ad>
 101bf8b:	xor    %edi,%edi
 101bf8d:	test   %eax,%eax
 101bf8f:	setne  %al
 101bf92:	cmpb   $0x0,0x6(%r14)
 101bf97:	je     101c0b5 <drain_fast+0x2c5>
 101bf9d:	mov    $0xffffffffffffffff,%r15
 101bfa4:	mov    %rcx,-0x40(%rbp)
 101bfa8:	mov    0x10(%rsi),%rax
 101bfac:	and    %r11,%rax
 101bfaf:	cmp    %r15,%rax
 101bfb2:	jne    101c0fa <drain_fast+0x30a>
 101bfb8:	cmp    $0x3,%ebx
 101bfbb:	je     101be50 <drain_fast+0x60>
 101bfc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101bfd0:	test   %ebx,%ebx
 101bfd2:	je     101c050 <drain_fast+0x260>
 101bfd4:	mov    %ebx,%eax
 101bfd6:	jmp    101bff1 <drain_fast+0x201>
 101bfd8:	nopl   0x0(%rax,%rax,1)
 101bfe0:	test   $0x1,%r9b
 101bfe4:	jne    101c0f1 <drain_fast+0x301>
 101bfea:	blsr   %eax,%eax
 101bfef:	je     101c050 <drain_fast+0x260>
 101bff1:	tzcnt  %eax,%ecx
 101bff5:	movzwl 0x5c(%r14,%rcx,2),%ecx
 101bffb:	mov    0x20(%rsi,%rcx,1),%r8
 101c000:	test   %r8,%r8
 101c003:	je     101bfea <drain_fast+0x1fa>
 101c005:	mov    -0x10(%r8),%r9
 101c009:	test   %r13,%r9
 101c00c:	jne    101bfe0 <drain_fast+0x1f0>
 101c00e:	lea    -0x20(%r8),%rcx
 101c012:	mov    (%rcx),%rdi
 101c015:	cmp    $0x1,%rdi
 101c019:	je     101c025 <drain_fast+0x235>
 101c01b:	test   %rdi,%rdi
 101c01e:	jne    101c02c <drain_fast+0x23c>
 101c020:	jmp    101c0f1 <drain_fast+0x301>
 101c025:	cmpq   $0x0,-0x18(%r8)
 101c02a:	je     101c034 <drain_fast+0x244>
 101c02c:	dec    %rdi
 101c02f:	mov    %rdi,(%rcx)
 101c032:	jmp    101bfea <drain_fast+0x1fa>
 101c034:	or     $0x1,%r9
 101c038:	mov    %r9,-0x10(%r8)
 101c03c:	mov    %rdx,%rdi
 101c03f:	mov    %rcx,%rdx
 101c042:	jmp    101c02f <drain_fast+0x23f>
 101c044:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c050:	mov    %rsi,%rax
 101c053:	and    $0xffffffffffff0000,%rax
 101c059:	mov    (%rax),%rcx
 101c05c:	movq   $0x3,0x10(%rsi)
 101c064:	mov    0x1610(%r12,%rcx,8),%rdi
 101c06c:	mov    %rdi,(%rsi)
 101c06f:	mov    %rsi,0x1610(%r12,%rcx,8)
 101c077:	vpinsrq $0x1,0x8(%rax),%xmm2,%xmm0
 101c07e:	vpaddq %xmm1,%xmm0,%xmm1
 101c082:	test   %rdx,%rdx
 101c085:	je     101c0f6 <drain_fast+0x306>
 101c087:	mov    -0x40(%rbp),%rax
 101c08b:	cmp    %rax,0x18(%rdx)
 101c08f:	jne    101be96 <drain_fast+0xa6>
 101c095:	mov    0x10(%rdx),%rax
 101c099:	and    %r11,%rax
 101c09c:	cmp    %r15,%rax
 101c09f:	jne    101be96 <drain_fast+0xa6>
 101c0a5:	mov    %rdx,%rsi
 101c0a8:	mov    (%rdx),%rdx
 101c0ab:	test   %ebx,%ebx
 101c0ad:	jne    101bfd4 <drain_fast+0x1e4>
 101c0b3:	jmp    101c050 <drain_fast+0x260>
 101c0b5:	mov    %al,%dil
 101c0b8:	lea    0x1(,%rdi,4),%r15
 101c0c0:	jmp    101bfa4 <drain_fast+0x1b4>
 101c0c5:	mov    %rsi,%r8
 101c0c8:	mov    %rcx,%rsi
 101c0cb:	vmovdqa %xmm1,-0x40(%rbp)
 101c0d0:	call   1018df4 <myl_rc_binding_find_slow>
 101c0d5:	vmovdqa -0x1a7fd(%rip),%xmm2        # 10018e0 <__abi_tag+0x15e4>
 101c0dd:	vmovdqa -0x40(%rbp),%xmm1
 101c0e2:	mov    %r8,%rsi
 101c0e5:	mov    %rax,%r14
 101c0e8:	test   %r14,%r14
 101c0eb:	jne    101bf05 <drain_fast+0x115>
 101c0f1:	call   10187d4 <myl_rc_invariant_failed>
 101c0f6:	xor    %esi,%esi
 101c0f8:	xor    %edx,%edx
 101c0fa:	mov    -0x48(%rbp),%rax
 101c0fe:	jmp    101c104 <drain_fast+0x314>
 101c100:	xor    %esi,%esi
 101c102:	xor    %edx,%edx
 101c104:	mov    %rdx,(%rax)
 101c107:	mov    -0x40(%rbp),%rcx
 101c10b:	mov    %rcx,0x8(%rax)
 101c10f:	mov    %r14,0x10(%rax)
 101c113:	mov    %r11,0x18(%rax)
 101c117:	mov    %r15,0x20(%rax)
 101c11b:	mov    %ebx,0x28(%rax)
 101c11e:	movl   $0x0,0x2c(%rax)
 101c125:	vmovdqu %xmm1,0x30(%rax)
 101c12a:	mov    %rsi,%rax
 101c12d:	add    $0x48,%rsp
 101c131:	pop    %rbx
 101c132:	pop    %r12
 101c134:	pop    %r13
 101c136:	pop    %r14
 101c138:	pop    %r15
 101c13a:	pop    %rbp
 101c13b:	ret
 101c13c:	int3
 101c13d:	int3
 101c13e:	int3
 101c13f:	int3

000000000101c140 <drain_one>:
 101c140:	push   %rbp
 101c141:	mov    %rsp,%rbp
 101c144:	push   %r15
 101c146:	push   %r14
 101c148:	push   %r13
 101c14a:	push   %r12
 101c14c:	push   %rbx
 101c14d:	push   %rax
 101c14e:	mov    %rsi,%r14
 101c151:	mov    %rdi,%rbx
 101c154:	mov    0x1608(%rdi),%r8
 101c15b:	mov    %rdx,0xc8(%r8)
 101c162:	mov    (%rcx),%rax
 101c165:	mov    %r8,%rdi
 101c168:	test   %rax,%rax
 101c16b:	je     101c1ab <drain_one+0x6b>
 101c16d:	mov    0x40(%rbx),%rdx
 101c171:	sub    %rax,%rdx
 101c174:	jb     101c4e3 <drain_one+0x3a3>
 101c17a:	mov    %rdx,0x40(%rbx)
 101c17e:	add    0x50(%rbx),%rax
 101c182:	mov    $0xffffffffffffffff,%rdx
 101c189:	cmovae %rax,%rdx
 101c18d:	mov    %rdx,0x50(%rbx)
 101c191:	mov    0x8(%rcx),%rax
 101c195:	add    %rax,0x1710(%rbx)
 101c19c:	vxorps %xmm0,%xmm0,%xmm0
 101c1a0:	vmovups %xmm0,(%rcx)
 101c1a4:	mov    0x1608(%rbx),%rdi
 101c1ab:	mov    0x18(%r14),%rsi
 101c1af:	mov    0xd8(%rdi),%rcx
 101c1b6:	cmp    %rsi,%rcx
 101c1b9:	je     101c206 <drain_one+0xc6>
 101c1bb:	cmp    %rsi,0xe0(%rdi)
 101c1c2:	je     101c20f <drain_one+0xcf>
 101c1c4:	mov    0x34(%rsi),%eax
 101c1c7:	cmp    %rax,0xa0(%rdi)
 101c1ce:	jbe    101c4c2 <drain_one+0x382>
 101c1d4:	mov    0x98(%rdi),%rcx
 101c1db:	shl    $0x4,%rax
 101c1df:	cmp    %rsi,(%rcx,%rax,1)
 101c1e3:	jne    101c4c2 <drain_one+0x382>
 101c1e9:	add    %rax,%rcx
 101c1ec:	mov    0x8(%rcx),%rax
 101c1f0:	test   %rax,%rax
 101c1f3:	je     101c4e3 <drain_one+0x3a3>
 101c1f9:	add    $0x40,%rax
 101c1fd:	mov    0xd8(%rdi),%rcx
 101c204:	jmp    101c216 <drain_one+0xd6>
 101c206:	mov    0xe8(%rdi),%rax
 101c20d:	jmp    101c239 <drain_one+0xf9>
 101c20f:	mov    0xf0(%rdi),%rax
 101c216:	mov    %rcx,0xe0(%rdi)
 101c21d:	mov    0xe8(%rdi),%rcx
 101c224:	mov    %rcx,0xf0(%rdi)
 101c22b:	mov    %rsi,0xd8(%rdi)
 101c232:	mov    %rax,0xe8(%rdi)
 101c239:	mov    %r8,-0x30(%rbp)
 101c23d:	movabs $0x4000000000000003,%r13
 101c247:	mov    0x10(%r14),%rcx
 101c24b:	mov    %rcx,%rdx
 101c24e:	and    %r13,%rdx
 101c251:	cmp    $0x1,%rdx
 101c255:	jne    101c4e3 <drain_one+0x3a3>
 101c25b:	lea    0x20(%r14),%r15
 101c25f:	lea    -0x40(%rax),%rsi
 101c263:	mov    $0x3c,%edx
 101c268:	bzhi   %rdx,%rcx,%r12
 101c26d:	shr    $0x2,%r12
 101c271:	cmpl   $0x10,(%rax)
 101c274:	ja     101c2a7 <drain_one+0x167>
 101c276:	cmp    $0x1,%r12
 101c27a:	jne    101c332 <drain_one+0x1f2>
 101c280:	cmpb   $0x0,0x6(%rax)
 101c284:	je     101c37a <drain_one+0x23a>
 101c28a:	mov    0x8(%rax),%ecx
 101c28d:	mov    (%r15,%rcx,1),%ecx
 101c291:	lea    0x1a(%rax),%rdx
 101c295:	cmp    $0x20,%rcx
 101c299:	lea    0x1c(%rax,%rcx,2),%rcx
 101c29e:	cmovae %rdx,%rcx
 101c2a2:	jmp    101c37e <drain_one+0x23e>
 101c2a7:	mov    -0x28(%rax),%rax
 101c2ab:	test   %rax,%rax
 101c2ae:	je     101c2f8 <drain_one+0x1b8>
 101c2b0:	mov    %rbx,%rdi
 101c2b3:	mov    %r15,%rsi
 101c2b6:	call   *%rax
 101c2b8:	mov    0x18(%r14),%rsi
 101c2bc:	mov    0x1608(%rbx),%rdi
 101c2c3:	mov    0x34(%rsi),%eax
 101c2c6:	cmp    %rax,0xa0(%rdi)
 101c2cd:	jbe    101c4d2 <drain_one+0x392>
 101c2d3:	mov    0x98(%rdi),%rcx
 101c2da:	shl    $0x4,%rax
 101c2de:	cmp    %rsi,(%rcx,%rax,1)
 101c2e2:	jne    101c4d2 <drain_one+0x392>
 101c2e8:	add    %rax,%rcx
 101c2eb:	mov    0x8(%rcx),%rsi
 101c2ef:	test   %rsi,%rsi
 101c2f2:	je     101c4e3 <drain_one+0x3a3>
 101c2f8:	mov    -0x30(%rbp),%rax
 101c2fc:	cmpq   $0x0,0xc0(%rax)
 101c304:	jne    101c4e3 <drain_one+0x3a3>
 101c30a:	mov    0x10(%rsi),%rax
 101c30e:	test   %rax,%rax
 101c311:	je     101c354 <drain_one+0x214>
 101c313:	mov    %rbx,%rdi
 101c316:	mov    %r15,%rsi
 101c319:	mov    %r12,%rdx
 101c31c:	call   *%rax
 101c31e:	mov    -0x30(%rbp),%r12
 101c322:	cmpq   $0x0,0xc0(%r12)
 101c32b:	je     101c3ac <drain_one+0x26c>
 101c32d:	jmp    101c4e3 <drain_one+0x3a3>
 101c332:	mov    %rbx,%rdi
 101c335:	mov    %r15,%rdx
 101c338:	mov    %r12,%rcx
 101c33b:	call   101ba70 <myl_rc_flat_edges_release>
 101c340:	mov    -0x30(%rbp),%r12
 101c344:	cmpq   $0x0,0xc0(%r12)
 101c34d:	je     101c3ac <drain_one+0x26c>
 101c34f:	jmp    101c4e3 <drain_one+0x3a3>
 101c354:	mov    0x8(%rsi),%rsi
 101c358:	mov    %rbx,%rdi
 101c35b:	mov    %r15,%rdx
 101c35e:	mov    %r12,%rcx
 101c361:	call   101b300 <myl_rc_edges_release>
 101c366:	mov    -0x30(%rbp),%r12
 101c36a:	cmpq   $0x0,0xc0(%r12)
 101c373:	je     101c3ac <drain_one+0x26c>
 101c375:	jmp    101c4e3 <drain_one+0x3a3>
 101c37a:	lea    0x18(%rax),%rcx
 101c37e:	mov    -0x30(%rbp),%r12
 101c382:	movzwl (%rcx),%edx
 101c385:	mov    0xc8(%r12),%rcx
 101c38d:	test   %edx,%edx
 101c38f:	jne    101c455 <drain_one+0x315>
 101c395:	mov    %rcx,0xc8(%r12)
 101c39d:	cmpq   $0x0,0xc0(%r12)
 101c3a6:	jne    101c4e3 <drain_one+0x3a3>
 101c3ac:	mov    0x10(%r14),%rax
 101c3b0:	and    %rax,%r13
 101c3b3:	cmp    $0x1,%r13
 101c3b7:	jne    101c4e3 <drain_one+0x3a3>
 101c3bd:	test   %rax,%rax
 101c3c0:	setns  %cl
 101c3c3:	mov    0x1608(%rbx),%rax
 101c3ca:	mov    0x8(%rax),%rax
 101c3ce:	cmp    $0x1022730,%rax
 101c3d5:	sete   %dl
 101c3d8:	and    %cl,%dl
 101c3da:	cmp    $0x1,%dl
 101c3dd:	jne    101c4a3 <drain_one+0x363>
 101c3e3:	mov    0x40(%rbx),%rax
 101c3e7:	test   %rax,%rax
 101c3ea:	je     101c4e3 <drain_one+0x3a3>
 101c3f0:	mov    0x50(%rbx),%rcx
 101c3f4:	cmp    $0xffffffffffffffff,%rcx
 101c3f8:	je     101c401 <drain_one+0x2c1>
 101c3fa:	inc    %rcx
 101c3fd:	mov    %rcx,0x50(%rbx)
 101c401:	mov    %r14,%rcx
 101c404:	and    $0xffffffffffff0000,%rcx
 101c40b:	dec    %rax
 101c40e:	mov    %rax,0x40(%rbx)
 101c412:	movq   $0x3,0x10(%r14)
 101c41a:	mov    (%rcx),%rax
 101c41d:	mov    0x1610(%rbx,%rax,8),%rax
 101c425:	mov    %rax,(%r14)
 101c428:	mov    (%rcx),%rax
 101c42b:	mov    %r14,0x1610(%rbx,%rax,8)
 101c433:	mov    0x8(%rcx),%rax
 101c437:	add    %rax,0x1710(%rbx)
 101c43e:	jmp    101c4ab <drain_one+0x36b>
 101c440:	test   $0x1,%r9b
 101c444:	jne    101c4e3 <drain_one+0x3a3>
 101c44a:	blsr   %edx,%edx
 101c44f:	je     101c395 <drain_one+0x255>
 101c455:	tzcnt  %edx,%esi
 101c459:	movzwl 0x5c(%rax,%rsi,2),%esi
 101c45e:	mov    (%r15,%rsi,1),%r8
 101c462:	test   %r8,%r8
 101c465:	je     101c44a <drain_one+0x30a>
 101c467:	mov    -0x10(%r8),%r9
 101c46b:	test   %r13,%r9
 101c46e:	jne    101c440 <drain_one+0x300>
 101c470:	lea    -0x20(%r8),%rsi
 101c474:	mov    (%rsi),%rdi
 101c477:	cmp    $0x1,%rdi
 101c47b:	je     101c484 <drain_one+0x344>
 101c47d:	test   %rdi,%rdi
 101c480:	jne    101c48b <drain_one+0x34b>
 101c482:	jmp    101c4e3 <drain_one+0x3a3>
 101c484:	cmpq   $0x0,-0x18(%r8)
 101c489:	je     101c493 <drain_one+0x353>
 101c48b:	dec    %rdi
 101c48e:	mov    %rdi,(%rsi)
 101c491:	jmp    101c44a <drain_one+0x30a>
 101c493:	or     $0x1,%r9
 101c497:	mov    %r9,-0x10(%r8)
 101c49b:	mov    %rcx,%rdi
 101c49e:	mov    %rsi,%rcx
 101c4a1:	jmp    101c48e <drain_one+0x34e>
 101c4a3:	mov    %rbx,%rdi
 101c4a6:	mov    %r15,%rsi
 101c4a9:	call   *%rax
 101c4ab:	mov    0xc8(%r12),%rax
 101c4b3:	add    $0x8,%rsp
 101c4b7:	pop    %rbx
 101c4b8:	pop    %r12
 101c4ba:	pop    %r13
 101c4bc:	pop    %r14
 101c4be:	pop    %r15
 101c4c0:	pop    %rbp
 101c4c1:	ret
 101c4c2:	call   1018df4 <myl_rc_binding_find_slow>
 101c4c7:	test   %rax,%rax
 101c4ca:	jne    101c1f9 <drain_one+0xb9>
 101c4d0:	jmp    101c4e3 <drain_one+0x3a3>
 101c4d2:	call   1018df4 <myl_rc_binding_find_slow>
 101c4d7:	mov    %rax,%rsi
 101c4da:	test   %rsi,%rsi
 101c4dd:	jne    101c2f8 <drain_one+0x1b8>
 101c4e3:	call   10187d4 <myl_rc_invariant_failed>
 101c4e8:	int3
 101c4e9:	int3
 101c4ea:	int3
 101c4eb:	int3
 101c4ec:	int3
 101c4ed:	int3
 101c4ee:	int3
 101c4ef:	int3

000000000101c4f0 <drain_pairs>:
 101c4f0:	push   %rbp
 101c4f1:	mov    %rsp,%rbp
 101c4f4:	push   %r15
 101c4f6:	push   %r14
 101c4f8:	push   %r13
 101c4fa:	push   %r12
 101c4fc:	push   %rbx
 101c4fd:	sub    $0x18,%rsp
 101c501:	mov    %r9,-0x40(%rbp)
 101c505:	mov    %rdx,%r11
 101c508:	movabs $0x4000000000000003,%rbx
 101c512:	mov    0x18(%rsi),%r14
 101c516:	mov    %rsi,%r10
 101c519:	and    $0xffffffffffff0000,%r10
 101c520:	mov    (%r10),%rax
 101c523:	movzwl %cx,%r15d
 101c527:	movzwl %r8w,%r8d
 101c52b:	mov    %rdi,-0x38(%rbp)
 101c52f:	mov    %rax,-0x30(%rbp)
 101c533:	mov    0x1610(%rdi,%rax,8),%r13
 101c53b:	mov    $0x1,%ecx
 101c540:	movabs $0xcfffffffffffffff,%r12
 101c54a:	mov    0x20(%rsi,%r15,1),%r9
 101c54f:	test   %r9,%r9
 101c552:	je     101c573 <drain_pairs+0x83>
 101c554:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c560:	mov    -0x10(%r9),%rdi
 101c564:	test   %rbx,%rdi
 101c567:	je     101c5b0 <drain_pairs+0xc0>
 101c569:	test   $0x1,%dil
 101c56d:	jne    101c6b2 <drain_pairs+0x1c2>
 101c573:	mov    0x20(%rsi,%r8,1),%rdi
 101c578:	test   %rdi,%rdi
 101c57b:	je     101c60d <drain_pairs+0x11d>
 101c581:	mov    -0x10(%rdi),%r9
 101c585:	test   %rbx,%r9
 101c588:	je     101c5d0 <drain_pairs+0xe0>
 101c58a:	mov    %r11,%rax
 101c58d:	test   $0x1,%r9b
 101c591:	jne    101c6b2 <drain_pairs+0x1c2>
 101c597:	movq   $0x3,0x10(%rsi)
 101c59f:	mov    %r13,(%rsi)
 101c5a2:	test   %rax,%rax
 101c5a5:	jne    101c620 <drain_pairs+0x130>
 101c5a7:	jmp    101c672 <drain_pairs+0x182>
 101c5ac:	nopl   0x0(%rax)
 101c5b0:	lea    -0x20(%r9),%rax
 101c5b4:	mov    (%rax),%rdx
 101c5b7:	cmp    $0x1,%rdx
 101c5bb:	je     101c5e7 <drain_pairs+0xf7>
 101c5bd:	test   %rdx,%rdx
 101c5c0:	jne    101c5ee <drain_pairs+0xfe>
 101c5c2:	jmp    101c6b2 <drain_pairs+0x1c2>
 101c5c7:	nopw   0x0(%rax,%rax,1)
 101c5d0:	lea    -0x20(%rdi),%rax
 101c5d4:	mov    (%rax),%rdx
 101c5d7:	cmp    $0x1,%rdx
 101c5db:	je     101c600 <drain_pairs+0x110>
 101c5dd:	test   %rdx,%rdx
 101c5e0:	jne    101c607 <drain_pairs+0x117>
 101c5e2:	jmp    101c6b2 <drain_pairs+0x1c2>
 101c5e7:	cmpq   $0x0,-0x18(%r9)
 101c5ec:	je     101c652 <drain_pairs+0x162>
 101c5ee:	dec    %rdx
 101c5f1:	mov    %rdx,(%rax)
 101c5f4:	mov    0x20(%rsi,%r8,1),%rdi
 101c5f9:	test   %rdi,%rdi
 101c5fc:	jne    101c581 <drain_pairs+0x91>
 101c5fe:	jmp    101c60d <drain_pairs+0x11d>
 101c600:	cmpq   $0x0,-0x18(%rdi)
 101c605:	je     101c662 <drain_pairs+0x172>
 101c607:	dec    %rdx
 101c60a:	mov    %rdx,(%rax)
 101c60d:	mov    %r11,%rax
 101c610:	movq   $0x3,0x10(%rsi)
 101c618:	mov    %r13,(%rsi)
 101c61b:	test   %rax,%rax
 101c61e:	je     101c672 <drain_pairs+0x182>
 101c620:	cmp    %r14,0x18(%rax)
 101c624:	jne    101c674 <drain_pairs+0x184>
 101c626:	mov    0x10(%rax),%rdx
 101c62a:	and    %r12,%rdx
 101c62d:	cmp    $0x5,%rdx
 101c631:	jne    101c674 <drain_pairs+0x184>
 101c633:	mov    (%rax),%r11
 101c636:	inc    %rcx
 101c639:	mov    %rsi,%r13
 101c63c:	mov    %rax,%rsi
 101c63f:	mov    0x20(%rsi,%r15,1),%r9
 101c644:	test   %r9,%r9
 101c647:	jne    101c560 <drain_pairs+0x70>
 101c64d:	jmp    101c573 <drain_pairs+0x83>
 101c652:	or     $0x1,%rdi
 101c656:	mov    %rdi,-0x10(%r9)
 101c65a:	mov    %r11,%rdx
 101c65d:	mov    %rax,%r11
 101c660:	jmp    101c5f1 <drain_pairs+0x101>
 101c662:	or     $0x1,%r9
 101c666:	mov    %r9,-0x10(%rdi)
 101c66a:	mov    %r11,%rdx
 101c66d:	mov    %rax,%r11
 101c670:	jmp    101c60a <drain_pairs+0x11a>
 101c672:	xor    %eax,%eax
 101c674:	mov    -0x38(%rbp),%rdx
 101c678:	mov    -0x30(%rbp),%rdi
 101c67c:	mov    %rsi,0x1610(%rdx,%rdi,8)
 101c684:	vmovq  %rcx,%xmm0
 101c689:	imul   0x8(%r10),%rcx
 101c68e:	vmovq  %rcx,%xmm1
 101c693:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 101c697:	mov    -0x40(%rbp),%rcx
 101c69b:	vpaddq (%rcx),%xmm0,%xmm0
 101c69f:	vmovdqu %xmm0,(%rcx)
 101c6a3:	add    $0x18,%rsp
 101c6a7:	pop    %rbx
 101c6a8:	pop    %r12
 101c6aa:	pop    %r13
 101c6ac:	pop    %r14
 101c6ae:	pop    %r15
 101c6b0:	pop    %rbp
 101c6b1:	ret
 101c6b2:	call   10187d4 <myl_rc_invariant_failed>
 101c6b7:	int3
 101c6b8:	int3
 101c6b9:	int3
 101c6ba:	int3
 101c6bb:	int3
 101c6bc:	int3
 101c6bd:	int3
 101c6be:	int3
 101c6bf:	int3

000000000101c6c0 <myl_rc_native_has_unique>:
 101c6c0:	push   %rbp
 101c6c1:	mov    %rsp,%rbp
 101c6c4:	test   %rdi,%rdi
 101c6c7:	je     101c898 <myl_rc_native_has_unique+0x1d8>
 101c6cd:	mov    0x1608(%rdi),%rcx
 101c6d4:	test   %rcx,%rcx
 101c6d7:	je     101c898 <myl_rc_native_has_unique+0x1d8>
 101c6dd:	cmpq   $0x0,0xc0(%rcx)
 101c6e5:	jne    101c898 <myl_rc_native_has_unique+0x1d8>
 101c6eb:	vxorps %xmm0,%xmm0,%xmm0
 101c6ef:	mov    $0x160,%edx
 101c6f4:	movzwl 0x30(%rsi),%eax
 101c6f8:	cmp    $0x1,%ax
 101c6fc:	jne    101c75b <myl_rc_native_has_unique+0x9b>
 101c6fe:	cmpw   $0x5,0x32(%rsi)
 101c703:	jne    101c7a6 <myl_rc_native_has_unique+0xe6>
 101c709:	mov    0x38(%rsi),%rax
 101c70d:	test   %rax,%rax
 101c710:	je     101c7a6 <myl_rc_native_has_unique+0xe6>
 101c716:	mov    0x34(%rax),%r8d
 101c71a:	cmp    %r8,0xa0(%rcx)
 101c721:	jbe    101c874 <myl_rc_native_has_unique+0x1b4>
 101c727:	mov    0x98(%rcx),%r9
 101c72e:	shl    $0x4,%r8
 101c732:	cmp    %rax,(%r9,%r8,1)
 101c736:	jne    101c874 <myl_rc_native_has_unique+0x1b4>
 101c73c:	add    %r8,%r9
 101c73f:	mov    0x8(%r9),%rax
 101c743:	test   %rax,%rax
 101c746:	je     101c898 <myl_rc_native_has_unique+0x1d8>
 101c74c:	cmpq   $0x0,0x18(%rax)
 101c751:	jne    101c89f <myl_rc_native_has_unique+0x1df>
 101c757:	movzwl 0x30(%rsi),%eax
 101c75b:	movzwl %ax,%eax
 101c75e:	lea    -0x2(%rax),%ecx
 101c761:	cmp    $0x3,%ecx
 101c764:	jae    101c860 <myl_rc_native_has_unique+0x1a0>
 101c76a:	mov    0x1608(%rdi),%rax
 101c771:	mov    0xc0(%rax),%rcx
 101c778:	cmp    0xb8(%rax),%rcx
 101c77f:	jae    101c898 <myl_rc_native_has_unique+0x1d8>
 101c785:	mov    0xb0(%rax),%r8
 101c78c:	lea    0x1(%rcx),%r9
 101c790:	mov    %r9,0xc0(%rax)
 101c797:	lea    (%rcx,%rcx,2),%rax
 101c79b:	mov    %rsi,(%r8,%rax,8)
 101c79f:	vmovups %xmm0,0x8(%r8,%rax,8)
 101c7a6:	mov    0x1608(%rdi),%rcx
 101c7ad:	mov    0xc0(%rcx),%rsi
 101c7b4:	xor    %eax,%eax
 101c7b6:	test   %rsi,%rsi
 101c7b9:	je     101c89d <myl_rc_native_has_unique+0x1dd>
 101c7bf:	lea    (%rsi,%rsi,2),%r8
 101c7c3:	dec    %rsi
 101c7c6:	shl    $0x3,%r8
 101c7ca:	add    0xb0(%rcx),%r8
 101c7d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c7e0:	mov    -0x18(%r8),%r9
 101c7e4:	cmpw   $0x3,0x30(%r9)
 101c7ea:	jne    101c810 <myl_rc_native_has_unique+0x150>
 101c7ec:	xor    %r10d,%r10d
 101c7ef:	cmpq   $0x0,0x20(%r9)
 101c7f4:	setne  %r10b
 101c7f8:	mov    -0x8(%r8),%r11
 101c7fc:	cmp    %r10,%r11
 101c7ff:	jae    101c81d <myl_rc_native_has_unique+0x15d>
 101c801:	jmp    101c830 <myl_rc_native_has_unique+0x170>
 101c803:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c810:	mov    0x18(%r9),%r10
 101c814:	mov    -0x8(%r8),%r11
 101c818:	cmp    %r10,%r11
 101c81b:	jb     101c830 <myl_rc_native_has_unique+0x170>
 101c81d:	mov    %rsi,0xc0(%rcx)
 101c824:	add    $0xffffffffffffffe8,%r8
 101c828:	add    $0xffffffffffffffff,%rsi
 101c82c:	jb     101c7e0 <myl_rc_native_has_unique+0x120>
 101c82e:	jmp    101c89d <myl_rc_native_has_unique+0x1dd>
 101c830:	mov    0x10(%r9),%rax
 101c834:	lea    0x1(%r11),%rsi
 101c838:	mov    %rsi,-0x8(%r8)
 101c83c:	lea    (%r11,%r11,2),%rsi
 101c840:	mov    0x8(%rax,%rsi,8),%rsi
 101c845:	movzwl 0x30(%rsi),%eax
 101c849:	cmp    $0x1,%ax
 101c84d:	je     101c6fe <myl_rc_native_has_unique+0x3e>
 101c853:	jmp    101c75b <myl_rc_native_has_unique+0x9b>
 101c858:	nopl   0x0(%rax,%rax,1)
 101c860:	cmp    $0x8,%eax
 101c863:	ja     101c7a6 <myl_rc_native_has_unique+0xe6>
 101c869:	bt     %eax,%edx
 101c86c:	jae    101c7a6 <myl_rc_native_has_unique+0xe6>
 101c872:	jmp    101c89f <myl_rc_native_has_unique+0x1df>
 101c874:	mov    %rdi,%r8
 101c877:	mov    %rcx,%rdi
 101c87a:	mov    %rsi,%rcx
 101c87d:	mov    %rax,%rsi
 101c880:	call   1018df4 <myl_rc_binding_find_slow>
 101c885:	vxorps %xmm0,%xmm0,%xmm0
 101c889:	mov    %rcx,%rsi
 101c88c:	mov    %r8,%rdi
 101c88f:	test   %rax,%rax
 101c892:	jne    101c74c <myl_rc_native_has_unique+0x8c>
 101c898:	call   10187d4 <myl_rc_invariant_failed>
 101c89d:	pop    %rbp
 101c89e:	ret
 101c89f:	mov    0x1608(%rdi),%rax
 101c8a6:	movq   $0x0,0xc0(%rax)
 101c8b1:	mov    $0x1,%eax
 101c8b6:	pop    %rbp
 101c8b7:	ret
 101c8b8:	int3
 101c8b9:	int3
 101c8ba:	int3
 101c8bb:	int3
 101c8bc:	int3
 101c8bd:	int3
 101c8be:	int3
 101c8bf:	int3

000000000101c8c0 <myl_rc_value_seed>:
 101c8c0:	push   %rbp
 101c8c1:	mov    %rsp,%rbp
 101c8c4:	push   %r15
 101c8c6:	push   %r14
 101c8c8:	push   %r13
 101c8ca:	push   %r12
 101c8cc:	push   %rbx
 101c8cd:	push   %rax
 101c8ce:	test   %rdi,%rdi
 101c8d1:	je     101cb40 <myl_rc_value_seed+0x280>
 101c8d7:	mov    %rdx,%r14
 101c8da:	mov    %rdi,%r15
 101c8dd:	mov    0x1608(%rdi),%rdx
 101c8e4:	test   %rdx,%rdx
 101c8e7:	je     101cb40 <myl_rc_value_seed+0x280>
 101c8ed:	cmp    %rcx,%r14
 101c8f0:	je     101cb40 <myl_rc_value_seed+0x280>
 101c8f6:	cmpq   $0x0,0xc0(%rdx)
 101c8fe:	jne    101cb40 <myl_rc_value_seed+0x280>
 101c904:	mov    0x58(%rdx),%rax
 101c908:	mov    0x60(%rdx),%rdi
 101c90c:	movzbl 0x70(%rdx),%edx
 101c910:	movabs $0x9e3779b97f4a7c15,%r9
 101c91a:	imul   %rsi,%r9
 101c91e:	shrx   %rdx,%r9,%rdx
 101c923:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c930:	and    %rdi,%rdx
 101c933:	mov    %rdx,%r9
 101c936:	shl    $0x4,%r9
 101c93a:	mov    (%rax,%r9,1),%r9
 101c93e:	cmp    %rsi,%r9
 101c941:	je     101c951 <myl_rc_value_seed+0x91>
 101c943:	test   %r9,%r9
 101c946:	je     101cb40 <myl_rc_value_seed+0x280>
 101c94c:	inc    %rdx
 101c94f:	jmp    101c930 <myl_rc_value_seed+0x70>
 101c951:	shl    $0x4,%rdx
 101c955:	mov    0x8(%rax,%rdx,1),%r12
 101c95a:	test   %r12,%r12
 101c95d:	je     101cb40 <myl_rc_value_seed+0x280>
 101c963:	mov    %r8,%rax
 101c966:	mulq   (%r12)
 101c96a:	jo     101cb40 <myl_rc_value_seed+0x280>
 101c970:	mov    0x8(%r12),%edx
 101c975:	or     $0x4,%edx
 101c978:	cmp    $0x5,%edx
 101c97b:	jne    101c998 <myl_rc_value_seed+0xd8>
 101c97d:	mov    %r14,%rdi
 101c980:	xor    %esi,%esi
 101c982:	mov    %rax,%rdx
 101c985:	add    $0x8,%rsp
 101c989:	pop    %rbx
 101c98a:	pop    %r12
 101c98c:	pop    %r13
 101c98e:	pop    %r14
 101c990:	pop    %r15
 101c992:	pop    %rbp
 101c993:	jmp    10274d0 <memset@plt>
 101c998:	mov    %r14,%rdi
 101c99b:	mov    %rcx,%rsi
 101c99e:	mov    %rax,%rdx
 101c9a1:	mov    %r8,-0x30(%rbp)
 101c9a5:	call   1027520 <memcpy@plt>
 101c9aa:	mov    -0x30(%rbp),%r11
 101c9ae:	cmpl   $0x0,0x8(%r12)
 101c9b4:	je     101cb31 <myl_rc_value_seed+0x271>
 101c9ba:	test   %r11,%r11
 101c9bd:	je     101cb31 <myl_rc_value_seed+0x271>
 101c9c3:	mov    0x28(%r12),%r13
 101c9c8:	xor    %ebx,%ebx
 101c9ca:	jmp    101c9ee <myl_rc_value_seed+0x12e>
 101c9cc:	nopl   0x0(%rax)
 101c9d0:	mov    %r15,%rdi
 101c9d3:	xor    %esi,%esi
 101c9d5:	call   101b8c0 <walk>
 101c9da:	mov    -0x30(%rbp),%r11
 101c9de:	add    (%r12),%r14
 101c9e2:	inc    %rbx
 101c9e5:	cmp    %r11,%rbx
 101c9e8:	je     101cb31 <myl_rc_value_seed+0x271>
 101c9ee:	mov    0x8(%r12),%eax
 101c9f3:	cmp    $0x2,%r13
 101c9f7:	jbe    101ca50 <myl_rc_value_seed+0x190>
 101c9f9:	test   %eax,%eax
 101c9fb:	je     101c9d0 <myl_rc_value_seed+0x110>
 101c9fd:	mov    0x1608(%r15),%rax
 101ca04:	mov    0xc0(%rax),%rcx
 101ca0b:	cmp    0xb8(%rax),%rcx
 101ca12:	jae    101cb40 <myl_rc_value_seed+0x280>
 101ca18:	mov    0xb0(%rax),%rdx
 101ca1f:	lea    0x1(%rcx),%rsi
 101ca23:	mov    %rsi,0xc0(%rax)
 101ca2a:	lea    (%rcx,%rcx,2),%rax
 101ca2e:	mov    %r12,(%rdx,%rax,8)
 101ca32:	mov    %r14,0x8(%rdx,%rax,8)
 101ca37:	movq   $0x0,0x10(%rdx,%rax,8)
 101ca40:	jmp    101c9d0 <myl_rc_value_seed+0x110>
 101ca42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101ca50:	dec    %eax
 101ca52:	cmp    $0x4,%eax
 101ca55:	ja     101ca99 <myl_rc_value_seed+0x1d9>
 101ca57:	jmp    *0x1001b30(,%rax,8)
 101ca5e:	mov    $0x1,%eax
 101ca63:	xor    %ecx,%ecx
 101ca65:	jmp    101ca9d <myl_rc_value_seed+0x1dd>
 101ca67:	mov    0x10(%r12),%rdx
 101ca6c:	mov    0x18(%r12),%rax
 101ca71:	mov    0x20(%r12),%rsi
 101ca76:	add    %r14,%rsi
 101ca79:	xor    %ecx,%ecx
 101ca7b:	jmp    101caa1 <myl_rc_value_seed+0x1e1>
 101ca7d:	mov    0x10(%r12),%rdx
 101ca82:	mov    0x18(%r12),%rax
 101ca87:	xor    %ecx,%ecx
 101ca89:	xor    %esi,%esi
 101ca8b:	jmp    101caa1 <myl_rc_value_seed+0x1e1>
 101ca8d:	mov    0x18(%r12),%rax
 101ca92:	mov    0x20(%r12),%rcx
 101ca97:	jmp    101ca9d <myl_rc_value_seed+0x1dd>
 101ca99:	xor    %ecx,%ecx
 101ca9b:	xor    %eax,%eax
 101ca9d:	xor    %esi,%esi
 101ca9f:	xor    %edx,%edx
 101caa1:	mov    %rax,%rdi
 101caa4:	neg    %rdi
 101caa7:	xor    %r8d,%r8d
 101caaa:	test   %rdx,%rdx
 101caad:	je     101cb10 <myl_rc_value_seed+0x250>
 101caaf:	cmp    %rax,%r8
 101cab2:	jae    101c9de <myl_rc_value_seed+0x11e>
 101cab8:	lea    (%r8,%r8,2),%r9
 101cabc:	lea    (%rdx,%r9,8),%r9
 101cac0:	inc    %r8
 101cac3:	jmp    101cae8 <myl_rc_value_seed+0x228>
 101cac5:	data16 cs nopw 0x0(%rax,%rax,1)
 101cad0:	add    $0x18,%r9
 101cad4:	lea    (%rdi,%r8,1),%r10
 101cad8:	inc    %r10
 101cadb:	inc    %r8
 101cade:	cmp    $0x1,%r10
 101cae2:	je     101c9de <myl_rc_value_seed+0x11e>
 101cae8:	mov    0x8(%r9),%r10
 101caec:	cmpl   $0x0,0x8(%r10)
 101caf1:	je     101cad0 <myl_rc_value_seed+0x210>
 101caf3:	test   %rsi,%rsi
 101caf6:	je     101cb01 <myl_rc_value_seed+0x241>
 101caf8:	mov    0x10(%r9),%r10d
 101cafc:	cmp    (%rsi),%r10d
 101caff:	jne    101cad0 <myl_rc_value_seed+0x210>
 101cb01:	mov    (%r9),%r9
 101cb04:	movq   $0x0,(%r14,%r9,1)
 101cb0c:	jmp    101caaa <myl_rc_value_seed+0x1ea>
 101cb0e:	xchg   %ax,%ax
 101cb10:	cmp    %rax,%r8
 101cb13:	je     101c9de <myl_rc_value_seed+0x11e>
 101cb19:	lea    0x1(%r8),%r9
 101cb1d:	imul   %rcx,%r8
 101cb21:	movq   $0x0,(%r14,%r8,1)
 101cb29:	mov    %r9,%r8
 101cb2c:	jmp    101caaa <myl_rc_value_seed+0x1ea>
 101cb31:	add    $0x8,%rsp
 101cb35:	pop    %rbx
 101cb36:	pop    %r12
 101cb38:	pop    %r13
 101cb3a:	pop    %r14
 101cb3c:	pop    %r15
 101cb3e:	pop    %rbp
 101cb3f:	ret
 101cb40:	call   10187d4 <myl_rc_invariant_failed>
 101cb45:	int3
 101cb46:	int3
 101cb47:	int3
 101cb48:	int3
 101cb49:	int3
 101cb4a:	int3
 101cb4b:	int3
 101cb4c:	int3
 101cb4d:	int3
 101cb4e:	int3
 101cb4f:	int3

000000000101cb50 <myl_rc_construction_abort>:
 101cb50:	push   %rbp
 101cb51:	mov    %rsp,%rbp
 101cb54:	push   %r15
 101cb56:	push   %r14
 101cb58:	push   %rbx
 101cb59:	push   %rax
 101cb5a:	test   %rsi,%rsi
 101cb5d:	je     101cc71 <myl_rc_construction_abort+0x121>
 101cb63:	mov    -0x10(%rsi),%rax
 101cb67:	test   $0x2,%al
 101cb69:	jne    101ccea <myl_rc_construction_abort+0x19a>
 101cb6f:	mov    %rdi,%rbx
 101cb72:	bt     $0x3e,%rax
 101cb77:	jb     101cbad <myl_rc_construction_abort+0x5d>
 101cb79:	mov    %rbx,%rdi
 101cb7c:	call   1018bc0 <myl_rc_edge_release>
 101cb81:	test   %rbx,%rbx
 101cb84:	je     101cc71 <myl_rc_construction_abort+0x121>
 101cb8a:	mov    0x1608(%rbx),%rax
 101cb91:	test   %rax,%rax
 101cb94:	je     101cc71 <myl_rc_construction_abort+0x121>
 101cb9a:	cmpq   $0x0,0xc8(%rax)
 101cba2:	jne    101ccd8 <myl_rc_construction_abort+0x188>
 101cba8:	jmp    101cc71 <myl_rc_construction_abort+0x121>
 101cbad:	test   $0x1,%al
 101cbaf:	jne    101cc71 <myl_rc_construction_abort+0x121>
 101cbb5:	or     $0x1,%rax
 101cbb9:	mov    %rax,-0x10(%rsi)
 101cbbd:	mov    -0x8(%rsi),%rax
 101cbc1:	mov    0x1608(%rbx),%rdi
 101cbc8:	mov    0x34(%rax),%ecx
 101cbcb:	cmp    %rcx,0xa0(%rdi)
 101cbd2:	mov    %rsi,%r14
 101cbd5:	jbe    101cc7c <myl_rc_construction_abort+0x12c>
 101cbdb:	mov    0x98(%rdi),%rdx
 101cbe2:	shl    $0x4,%rcx
 101cbe6:	cmp    %rax,(%rdx,%rcx,1)
 101cbea:	jne    101cc7c <myl_rc_construction_abort+0x12c>
 101cbf0:	add    %rcx,%rdx
 101cbf3:	mov    0x8(%rdx),%rax
 101cbf7:	test   %rax,%rax
 101cbfa:	je     101ccea <myl_rc_construction_abort+0x19a>
 101cc00:	mov    $0x28,%ecx
 101cc05:	bzhi   %rcx,-0x10(%rsi),%r15
 101cc0b:	mov    0x18(%rax),%rax
 101cc0f:	test   %rax,%rax
 101cc12:	je     101cc1f <myl_rc_construction_abort+0xcf>
 101cc14:	mov    %rbx,%rdi
 101cc17:	mov    %r14,%rsi
 101cc1a:	call   *%rax
 101cc1c:	mov    %r14,%rsi
 101cc1f:	mov    -0x8(%rsi),%rax
 101cc23:	mov    0x1608(%rbx),%rdi
 101cc2a:	mov    0x34(%rax),%ecx
 101cc2d:	cmp    %rcx,0xa0(%rdi)
 101cc34:	jbe    101cc92 <myl_rc_construction_abort+0x142>
 101cc36:	mov    0x98(%rdi),%rdx
 101cc3d:	shl    $0x4,%rcx
 101cc41:	cmp    %rax,(%rdx,%rcx,1)
 101cc45:	jne    101cc92 <myl_rc_construction_abort+0x142>
 101cc47:	add    %rcx,%rdx
 101cc4a:	mov    0x8(%rdx),%rax
 101cc4e:	shr    $0x2,%r15
 101cc52:	mov    0x10(%rax),%rcx
 101cc56:	test   %rcx,%rcx
 101cc59:	je     101ccaa <myl_rc_construction_abort+0x15a>
 101cc5b:	mov    %rbx,%rdi
 101cc5e:	mov    %r15,%rdx
 101cc61:	call   *%rcx
 101cc63:	mov    -0x8(%r14),%rcx
 101cc67:	mov    %r15,%rax
 101cc6a:	mulq   (%rcx)
 101cc6d:	jno    101cccb <myl_rc_construction_abort+0x17b>
 101cc6f:	jmp    101ccea <myl_rc_construction_abort+0x19a>
 101cc71:	add    $0x8,%rsp
 101cc75:	pop    %rbx
 101cc76:	pop    %r14
 101cc78:	pop    %r15
 101cc7a:	pop    %rbp
 101cc7b:	ret
 101cc7c:	mov    %rax,%rsi
 101cc7f:	call   1018df4 <myl_rc_binding_find_slow>
 101cc84:	mov    %r14,%rsi
 101cc87:	test   %rax,%rax
 101cc8a:	jne    101cc00 <myl_rc_construction_abort+0xb0>
 101cc90:	jmp    101ccea <myl_rc_construction_abort+0x19a>
 101cc92:	mov    %rax,%rsi
 101cc95:	call   1018df4 <myl_rc_binding_find_slow>
 101cc9a:	mov    %r14,%rsi
 101cc9d:	shr    $0x2,%r15
 101cca1:	mov    0x10(%rax),%rcx
 101cca5:	test   %rcx,%rcx
 101cca8:	jne    101cc5b <myl_rc_construction_abort+0x10b>
 101ccaa:	mov    0x8(%rax),%rax
 101ccae:	mov    %rbx,%rdi
 101ccb1:	mov    %rsi,%rdx
 101ccb4:	mov    %rax,%rsi
 101ccb7:	mov    %r15,%rcx
 101ccba:	call   101b300 <myl_rc_edges_release>
 101ccbf:	mov    -0x8(%r14),%rcx
 101ccc3:	mov    %r15,%rax
 101ccc6:	mulq   (%rcx)
 101ccc9:	jo     101ccea <myl_rc_construction_abort+0x19a>
 101cccb:	mov    %r14,%rdi
 101ccce:	xor    %esi,%esi
 101ccd0:	mov    %rax,%rdx
 101ccd3:	call   10274d0 <memset@plt>
 101ccd8:	mov    %rbx,%rdi
 101ccdb:	add    $0x8,%rsp
 101ccdf:	pop    %rbx
 101cce0:	pop    %r14
 101cce2:	pop    %r15
 101cce4:	pop    %rbp
 101cce5:	jmp    101bcb0 <myl_rc_drain>
 101ccea:	call   10187d4 <myl_rc_invariant_failed>
 101ccef:	int3

000000000101ccf0 <clock_now>:
 101ccf0:	push   %rbp
 101ccf1:	mov    %rsp,%rbp
 101ccf4:	push   %rbx
 101ccf5:	sub    $0x18,%rsp
 101ccf9:	xor    %ebx,%ebx
 101ccfb:	lea    -0x18(%rbp),%rsi
 101ccff:	xor    %edi,%edi
 101cd01:	call   1027580 <clock_gettime@plt>
 101cd06:	mov    %eax,%ecx
 101cd08:	mov    $0x3,%eax
 101cd0d:	test   %ecx,%ecx
 101cd0f:	jne    101cd4c <clock_now+0x5c>
 101cd11:	mov    -0x18(%rbp),%rsi
 101cd15:	mov    -0x10(%rbp),%rcx
 101cd19:	movabs $0x7fffffffffffffff,%rdx
 101cd23:	xor    %rcx,%rdx
 101cd26:	movabs $0x112e0be826d694b3,%rdi
 101cd30:	mulx   %rdi,%rdx,%rdx
 101cd35:	shr    $0x1a,%rdx
 101cd39:	xor    %ebx,%ebx
 101cd3b:	cmp    %rdx,%rsi
 101cd3e:	jg     101cd4c <clock_now+0x5c>
 101cd40:	imul   $0x3b9aca00,%rsi,%rbx
 101cd47:	add    %rcx,%rbx
 101cd4a:	xor    %eax,%eax
 101cd4c:	mov    %rbx,%rdx
 101cd4f:	add    $0x18,%rsp
 101cd53:	pop    %rbx
 101cd54:	pop    %rbp
 101cd55:	ret
 101cd56:	int3
 101cd57:	int3
 101cd58:	int3
 101cd59:	int3
 101cd5a:	int3
 101cd5b:	int3
 101cd5c:	int3
 101cd5d:	int3
 101cd5e:	int3
 101cd5f:	int3

000000000101cd60 <random_u64>:
 101cd60:	movabs $0x9e3779b97f4a7c15,%rax
 101cd6a:	add    (%rdi),%rax
 101cd6d:	mov    %rax,(%rdi)
 101cd70:	mov    %rax,%rcx
 101cd73:	shr    $0x1e,%rcx
 101cd77:	xor    %rax,%rcx
 101cd7a:	movabs $0xbf58476d1ce4e5b9,%rax
 101cd84:	imul   %rcx,%rax
 101cd88:	mov    %rax,%rcx
 101cd8b:	shr    $0x1b,%rcx
 101cd8f:	xor    %rax,%rcx
 101cd92:	movabs $0x94d049bb133111eb,%rax
 101cd9c:	imul   %rcx,%rax
 101cda0:	mov    %rax,%rdx
 101cda3:	shr    $0x1f,%rdx
 101cda7:	xor    %rax,%rdx
 101cdaa:	xor    %eax,%eax
 101cdac:	ret
 101cdad:	int3
 101cdae:	int3
 101cdaf:	int3

000000000101cdb0 <environment_get>:
 101cdb0:	push   %rbp
 101cdb1:	mov    %rsp,%rbp
 101cdb4:	push   %r15
 101cdb6:	push   %r14
 101cdb8:	push   %r13
 101cdba:	push   %r12
 101cdbc:	push   %rbx
 101cdbd:	sub    $0x118,%rsp
 101cdc4:	mov    %rdi,%rbx
 101cdc7:	vxorps %xmm0,%xmm0,%xmm0
 101cdcb:	vmovups %xmm0,(%rdi)
 101cdcf:	movq   $0x0,0x10(%rdi)
 101cdd7:	cmp    $0x100,%rcx
 101cdde:	jb     101cdfb <environment_get+0x4b>
 101cde0:	movl   $0x2,(%rbx)
 101cde6:	mov    %rbx,%rax
 101cde9:	add    $0x118,%rsp
 101cdf0:	pop    %rbx
 101cdf1:	pop    %r12
 101cdf3:	pop    %r13
 101cdf5:	pop    %r14
 101cdf7:	pop    %r15
 101cdf9:	pop    %rbp
 101cdfa:	ret
 101cdfb:	mov    %rcx,%r15
 101cdfe:	mov    %rsi,%r14
 101ce01:	mov    %r9,-0x38(%rbp)
 101ce05:	mov    %r8,-0x30(%rbp)
 101ce09:	lea    -0x140(%rbp),%rdi
 101ce10:	mov    %rdx,%rsi
 101ce13:	mov    %rcx,%rdx
 101ce16:	call   1027520 <memcpy@plt>
 101ce1b:	movb   $0x0,-0x140(%rbp,%r15,1)
 101ce24:	cmpb   $0x0,(%r14)
 101ce28:	je     101ceab <environment_get+0xfb>
 101ce2e:	lea    -0x140(%rbp),%r13
 101ce35:	jmp    101ce4f <environment_get+0x9f>
 101ce37:	nopw   0x0(%rax,%rax,1)
 101ce40:	mov    %r12,%rax
 101ce43:	inc    %r12
 101ce46:	cmpb   $0x0,0x1(%rax)
 101ce4a:	mov    %r12,%r14
 101ce4d:	je     101cde0 <environment_get+0x30>
 101ce4f:	mov    %r14,%rdi
 101ce52:	mov    $0x2c,%esi
 101ce57:	call   1027790 <strchr@plt>
 101ce5c:	test   %rax,%rax
 101ce5f:	je     101ce80 <environment_get+0xd0>
 101ce61:	mov    %rax,%r12
 101ce64:	sub    %r14,%rax
 101ce67:	cmp    %r15,%rax
 101ce6a:	jne    101ce40 <environment_get+0x90>
 101ce6c:	mov    %r14,%rdi
 101ce6f:	mov    %r13,%rsi
 101ce72:	mov    %r15,%rdx
 101ce75:	call   10276f0 <bcmp@plt>
 101ce7a:	test   %eax,%eax
 101ce7c:	jne    101ce40 <environment_get+0x90>
 101ce7e:	jmp    101ceab <environment_get+0xfb>
 101ce80:	mov    %r14,%rdi
 101ce83:	call   10274f0 <strlen@plt>
 101ce88:	cmp    %r15,%rax
 101ce8b:	jne    101cde0 <environment_get+0x30>
 101ce91:	lea    -0x140(%rbp),%rsi
 101ce98:	mov    %r14,%rdi
 101ce9b:	mov    %r15,%rdx
 101ce9e:	call   10276f0 <bcmp@plt>
 101cea3:	test   %eax,%eax
 101cea5:	jne    101cde0 <environment_get+0x30>
 101ceab:	lea    -0x140(%rbp),%rdi
 101ceb2:	call   10274e0 <getenv@plt>
 101ceb7:	test   %rax,%rax
 101ceba:	je     101cde6 <environment_get+0x36>
 101cec0:	mov    %rax,%r14
 101cec3:	mov    %rax,%rdi
 101cec6:	call   10274f0 <strlen@plt>
 101cecb:	cmp    -0x38(%rbp),%rax
 101cecf:	jbe    101cedc <environment_get+0x12c>
 101ced1:	movl   $0x5,(%rbx)
 101ced7:	jmp    101cde6 <environment_get+0x36>
 101cedc:	mov    -0x30(%rbp),%rdi
 101cee0:	mov    %r14,%rsi
 101cee3:	mov    %rax,%rdx
 101cee6:	mov    %rax,%r14
 101cee9:	call   1027520 <memcpy@plt>
 101ceee:	movl   $0x1,0x10(%rbx)
 101cef5:	mov    %r14,0x8(%rbx)
 101cef9:	jmp    101cde6 <environment_get+0x36>
 101cefe:	int3
 101ceff:	int3

000000000101cf00 <mylang_scoped_endpoint>:
 101cf00:	push   %rbp
 101cf01:	mov    %rsp,%rbp
 101cf04:	push   %r15
 101cf06:	push   %r14
 101cf08:	push   %r13
 101cf0a:	push   %r12
 101cf0c:	push   %rbx
 101cf0d:	sub    $0x58,%rsp
 101cf11:	mov    %rsi,%r15
 101cf14:	mov    %rdi,%r13
 101cf17:	mov    %rsi,%rdi
 101cf1a:	call   10274f0 <strlen@plt>
 101cf1f:	mov    %rax,%r14
 101cf22:	add    $0xffffffffffffefff,%rax
 101cf28:	cmp    $0xfffffffffffff000,%rax
 101cf2e:	jb     101cf3d <mylang_scoped_endpoint+0x3d>
 101cf30:	mov    0x28e8(%r13),%rbx
 101cf37:	cmp    $0x7,%rbx
 101cf3b:	jbe    101cf4e <mylang_scoped_endpoint+0x4e>
 101cf3d:	xor    %eax,%eax
 101cf3f:	add    $0x58,%rsp
 101cf43:	pop    %rbx
 101cf44:	pop    %r12
 101cf46:	pop    %r13
 101cf48:	pop    %r14
 101cf4a:	pop    %r15
 101cf4c:	pop    %rbp
 101cf4d:	ret
 101cf4e:	cmp    $0x1,%r14
 101cf52:	jne    101cfa9 <mylang_scoped_endpoint+0xa9>
 101cf54:	cmpb   $0x2a,(%r15)
 101cf58:	jne    101cfa9 <mylang_scoped_endpoint+0xa9>
 101cf5a:	mov    %r13,-0x30(%rbp)
 101cf5e:	test   %rbx,%rbx
 101cf61:	je     101d064 <mylang_scoped_endpoint+0x164>
 101cf67:	mov    -0x30(%rbp),%rax
 101cf6b:	lea    0x2870(%rax),%r12
 101cf72:	mov    %rbx,%r13
 101cf75:	jmp    101cf8d <mylang_scoped_endpoint+0x8d>
 101cf77:	nopw   0x0(%rax,%rax,1)
 101cf80:	add    $0x10,%r12
 101cf84:	dec    %r13
 101cf87:	je     101d064 <mylang_scoped_endpoint+0x164>
 101cf8d:	cmp    %r14,(%r12)
 101cf91:	jne    101cf80 <mylang_scoped_endpoint+0x80>
 101cf93:	mov    -0x8(%r12),%rdi
 101cf98:	mov    %r15,%rsi
 101cf9b:	mov    %r14,%rdx
 101cf9e:	call   10276f0 <bcmp@plt>
 101cfa3:	test   %eax,%eax
 101cfa5:	jne    101cf80 <mylang_scoped_endpoint+0x80>
 101cfa7:	jmp    101cf3d <mylang_scoped_endpoint+0x3d>
 101cfa9:	mov    %r15,%rdi
 101cfac:	mov    $0x3a,%esi
 101cfb1:	call   10277a0 <strrchr@plt>
 101cfb6:	test   %rax,%rax
 101cfb9:	je     101cf3d <mylang_scoped_endpoint+0x3d>
 101cfbb:	mov    %rax,%r12
 101cfbe:	sub    %r15,%r12
 101cfc1:	je     101cf3d <mylang_scoped_endpoint+0x3d>
 101cfc7:	cmp    $0x3f,%r12
 101cfcb:	ja     101cf3d <mylang_scoped_endpoint+0x3d>
 101cfd1:	lea    -0x80(%rbp),%rdi
 101cfd5:	mov    %r15,%rsi
 101cfd8:	mov    %r12,%rdx
 101cfdb:	mov    %r13,%rbx
 101cfde:	mov    %rax,%r13
 101cfe1:	call   1027520 <memcpy@plt>
 101cfe6:	movb   $0x0,-0x80(%rbp,%r12,1)
 101cfec:	inc    %r13
 101cfef:	mov    %r13,%rdi
 101cff2:	mov    %rbx,%r13
 101cff5:	xor    %esi,%esi
 101cff7:	mov    $0xa,%edx
 101cffc:	call   10277b0 <strtoul@plt>
 101d001:	lea    -0x10000(%rax),%rcx
 101d008:	cmp    $0xffffffffffff0001,%rcx
 101d00f:	jb     101cf3d <mylang_scoped_endpoint+0x3d>
 101d015:	lea    -0x3c(%rbp),%rdx
 101d019:	movl   $0x0,-0x34(%rbp)
 101d020:	movq   $0x0,-0x3c(%rbp)
 101d028:	movw   $0x2,-0x40(%rbp)
 101d02e:	movbe  %ax,-0x3e(%rbp)
 101d034:	lea    -0x80(%rbp),%rsi
 101d038:	mov    $0x2,%edi
 101d03d:	call   10277c0 <inet_pton@plt>
 101d042:	cmp    $0x1,%eax
 101d045:	mov    $0x0,%eax
 101d04a:	jne    101cf3f <mylang_scoped_endpoint+0x3f>
 101d050:	mov    0x28e8(%r13),%rbx
 101d057:	mov    %r13,-0x30(%rbp)
 101d05b:	test   %rbx,%rbx
 101d05e:	jne    101cf67 <mylang_scoped_endpoint+0x67>
 101d064:	mov    %r14,%rdi
 101d067:	inc    %rdi
 101d06a:	call   1027500 <malloc@plt>
 101d06f:	mov    %rax,%r12
 101d072:	mov    $0x0,%eax
 101d077:	test   %r12,%r12
 101d07a:	mov    -0x30(%rbp),%r13
 101d07e:	je     101cf3f <mylang_scoped_endpoint+0x3f>
 101d084:	mov    %r12,%rdi
 101d087:	mov    %r15,%rsi
 101d08a:	mov    %r14,%rdx
 101d08d:	call   1027520 <memcpy@plt>
 101d092:	movb   $0x0,(%r12,%r14,1)
 101d097:	mov    %rbx,%rax
 101d09a:	shl    $0x4,%rax
 101d09e:	mov    %r12,0x2868(%r13,%rax,1)
 101d0a6:	mov    %r14,0x2870(%r13,%rax,1)
 101d0ae:	inc    %rbx
 101d0b1:	mov    %rbx,0x28e8(%r13)
 101d0b8:	mov    $0x1,%eax
 101d0bd:	jmp    101cf3f <mylang_scoped_endpoint+0x3f>
 101d0c2:	int3
 101d0c3:	int3
 101d0c4:	int3
 101d0c5:	int3
 101d0c6:	int3
 101d0c7:	int3
 101d0c8:	int3
 101d0c9:	int3
 101d0ca:	int3
 101d0cb:	int3
 101d0cc:	int3
 101d0cd:	int3
 101d0ce:	int3
 101d0cf:	int3

000000000101d0d0 <acquire_network>:
 101d0d0:	push   %rbp
 101d0d1:	mov    %rsp,%rbp
 101d0d4:	push   %r15
 101d0d6:	push   %r14
 101d0d8:	push   %r13
 101d0da:	push   %r12
 101d0dc:	push   %rbx
 101d0dd:	sub    $0xe8,%rsp
 101d0e4:	mov    0x28e8(%rdi),%r12
 101d0eb:	test   %r12,%r12
 101d0ee:	je     101d2bd <acquire_network+0x1ed>
 101d0f4:	test   $0x3,%cl
 101d0f7:	je     101d2c4 <acquire_network+0x1f4>
 101d0fd:	mov    %rdx,%r13
 101d100:	mov    $0x2,%eax
 101d105:	cmp    $0x7f,%rdx
 101d109:	ja     101d2c9 <acquire_network+0x1f9>
 101d10f:	mov    %rdi,%r14
 101d112:	lea    -0x110(%rbp),%rdi
 101d119:	mov    %r13,%rdx
 101d11c:	call   1027520 <memcpy@plt>
 101d121:	movb   $0x0,-0x110(%rbp,%r13,1)
 101d12a:	lea    0x2868(%r14),%r15
 101d131:	xor    %ebx,%ebx
 101d133:	jmp    101d14d <acquire_network+0x7d>
 101d135:	data16 cs nopw 0x0(%rax,%rax,1)
 101d140:	add    $0x10,%r15
 101d144:	dec    %r12
 101d147:	je     101d2e3 <acquire_network+0x213>
 101d14d:	mov    0x8(%r15),%rax
 101d151:	cmp    $0x1,%rax
 101d155:	jne    101d15f <acquire_network+0x8f>
 101d157:	mov    (%r15),%rcx
 101d15a:	cmpb   $0x2a,(%rcx)
 101d15d:	je     101d17a <acquire_network+0xaa>
 101d15f:	cmp    %r13,%rax
 101d162:	jne    101d140 <acquire_network+0x70>
 101d164:	mov    (%r15),%rdi
 101d167:	lea    -0x110(%rbp),%rsi
 101d16e:	mov    %r13,%rdx
 101d171:	call   10276f0 <bcmp@plt>
 101d176:	test   %eax,%eax
 101d178:	jne    101d140 <acquire_network+0x70>
 101d17a:	add    $0x68,%r14
 101d17e:	xor    %ebx,%ebx
 101d180:	mov    $0x2,%eax
 101d185:	jmp    101d1a5 <acquire_network+0xd5>
 101d187:	nopw   0x0(%rax,%rax,1)
 101d190:	add    $0x2,%rbx
 101d194:	add    $0x50,%r14
 101d198:	cmp    $0x100,%rbx
 101d19f:	je     101d2c9 <acquire_network+0x1f9>
 101d1a5:	cmpl   $0x0,(%r14)
 101d1a9:	jns    101d1b2 <acquire_network+0xe2>
 101d1ab:	cmpq   $0x0,0x8(%r14)
 101d1b0:	je     101d1c7 <acquire_network+0xf7>
 101d1b2:	cmpl   $0x0,0x28(%r14)
 101d1b7:	jns    101d190 <acquire_network+0xc0>
 101d1b9:	cmpq   $0x0,0x30(%r14)
 101d1be:	jne    101d190 <acquire_network+0xc0>
 101d1c0:	inc    %rbx
 101d1c3:	add    $0x28,%r14
 101d1c7:	lea    -0x110(%rbp),%r12
 101d1ce:	mov    %r12,%rdi
 101d1d1:	mov    $0x3a,%esi
 101d1d6:	call   10277a0 <strrchr@plt>
 101d1db:	mov    %rax,%r15
 101d1de:	sub    %r12,%r15
 101d1e1:	sete   %cl
 101d1e4:	test   %rax,%rax
 101d1e7:	je     101d2b6 <acquire_network+0x1e6>
 101d1ed:	test   %cl,%cl
 101d1ef:	jne    101d2b6 <acquire_network+0x1e6>
 101d1f5:	cmp    $0x3f,%r15
 101d1f9:	ja     101d2b6 <acquire_network+0x1e6>
 101d1ff:	lea    -0x90(%rbp),%rdi
 101d206:	lea    -0x110(%rbp),%rsi
 101d20d:	mov    %r15,%rdx
 101d210:	mov    %rax,%r12
 101d213:	call   1027520 <memcpy@plt>
 101d218:	movb   $0x0,-0x90(%rbp,%r15,1)
 101d221:	inc    %r12
 101d224:	mov    %r12,%rdi
 101d227:	xor    %esi,%esi
 101d229:	mov    $0xa,%edx
 101d22e:	call   10277b0 <strtoul@plt>
 101d233:	lea    -0x10000(%rax),%rcx
 101d23a:	cmp    $0xffffffffffff0001,%rcx
 101d241:	jb     101d2b6 <acquire_network+0x1e6>
 101d243:	lea    -0x34(%rbp),%rdx
 101d247:	movl   $0x0,-0x2c(%rbp)
 101d24e:	movq   $0x0,-0x34(%rbp)
 101d256:	movw   $0x2,-0x38(%rbp)
 101d25c:	movbe  %ax,-0x36(%rbp)
 101d262:	lea    -0x90(%rbp),%rsi
 101d269:	mov    $0x2,%edi
 101d26e:	call   10277c0 <inet_pton@plt>
 101d273:	cmp    $0x1,%eax
 101d276:	jne    101d2b6 <acquire_network+0x1e6>
 101d278:	vmovups -0x38(%rbp),%xmm0
 101d27d:	vmovaps %xmm0,-0x50(%rbp)
 101d282:	mov    $0x2,%edi
 101d287:	mov    $0x1,%esi
 101d28c:	xor    %edx,%edx
 101d28e:	call   10277d0 <socket@plt>
 101d293:	test   %eax,%eax
 101d295:	js     101d2b6 <acquire_network+0x1e6>
 101d297:	mov    %eax,%r15d
 101d29a:	lea    -0x50(%rbp),%rsi
 101d29e:	mov    %eax,%edi
 101d2a0:	mov    $0x10,%edx
 101d2a5:	call   10277e0 <connect@plt>
 101d2aa:	test   %eax,%eax
 101d2ac:	je     101d2ea <acquire_network+0x21a>
 101d2ae:	mov    %r15d,%edi
 101d2b1:	call   1027640 <close@plt>
 101d2b6:	mov    $0x3,%eax
 101d2bb:	jmp    101d2c9 <acquire_network+0x1f9>
 101d2bd:	mov    $0x1,%eax
 101d2c2:	jmp    101d2c9 <acquire_network+0x1f9>
 101d2c4:	mov    $0x2,%eax
 101d2c9:	xor    %ebx,%ebx
 101d2cb:	mov    %rbx,%rdx
 101d2ce:	add    $0xe8,%rsp
 101d2d5:	pop    %rbx
 101d2d6:	pop    %r12
 101d2d8:	pop    %r13
 101d2da:	pop    %r14
 101d2dc:	pop    %r15
 101d2de:	pop    %rbp
 101d2df:	vzeroupper
 101d2e2:	ret
 101d2e3:	mov    $0x2,%eax
 101d2e8:	jmp    101d2cb <acquire_network+0x1fb>
 101d2ea:	mov    %r15d,(%r14)
 101d2ed:	vxorps %xmm0,%xmm0,%xmm0
 101d2f1:	vmovups %ymm0,0x4(%r14)
 101d2f7:	movl   $0x0,0x24(%r14)
 101d2ff:	xor    %eax,%eax
 101d301:	jmp    101d2cb <acquire_network+0x1fb>
 101d303:	int3
 101d304:	int3
 101d305:	int3
 101d306:	int3
 101d307:	int3
 101d308:	int3
 101d309:	int3
 101d30a:	int3
 101d30b:	int3
 101d30c:	int3
 101d30d:	int3
 101d30e:	int3
 101d30f:	int3

000000000101d310 <complete>:
 101d310:	mov    $0x3,%eax
 101d315:	cmp    $0xff,%rsi
 101d31c:	ja     101d36f <complete+0x5f>
 101d31e:	push   %rbp
 101d31f:	mov    %rsp,%rbp
 101d322:	push   %rbx
 101d323:	push   %rax
 101d324:	lea    (%rsi,%rsi,4),%rcx
 101d328:	lea    (%rdi,%rcx,8),%rbx
 101d32c:	add    $0x68,%rbx
 101d330:	mov    0x68(%rdi,%rcx,8),%edi
 101d334:	test   %edi,%edi
 101d336:	js     101d343 <complete+0x33>
 101d338:	call   1027640 <close@plt>
 101d33d:	mov    0x8(%rbx),%rdi
 101d341:	jmp    101d34c <complete+0x3c>
 101d343:	mov    0x8(%rbx),%rdi
 101d347:	test   %rdi,%rdi
 101d34a:	je     101d369 <complete+0x59>
 101d34c:	call   1027570 <free@plt>
 101d351:	movl   $0xffffffff,(%rbx)
 101d357:	vxorps %xmm0,%xmm0,%xmm0
 101d35b:	vmovups %ymm0,0x4(%rbx)
 101d360:	movl   $0x0,0x24(%rbx)
 101d367:	xor    %eax,%eax
 101d369:	add    $0x8,%rsp
 101d36d:	pop    %rbx
 101d36e:	pop    %rbp
 101d36f:	vzeroupper
 101d372:	ret
 101d373:	int3
 101d374:	int3
 101d375:	int3
 101d376:	int3
 101d377:	int3
 101d378:	int3
 101d379:	int3
 101d37a:	int3
 101d37b:	int3
 101d37c:	int3
 101d37d:	int3
 101d37e:	int3
 101d37f:	int3

000000000101d380 <release>:
 101d380:	push   %rbp
 101d381:	mov    %rsp,%rbp
 101d384:	push   %rbx
 101d385:	push   %rax
 101d386:	cmp    $0xff,%rsi
 101d38d:	ja     101d3d2 <release+0x52>
 101d38f:	lea    (%rsi,%rsi,4),%rax
 101d393:	lea    (%rdi,%rax,8),%rbx
 101d397:	add    $0x68,%rbx
 101d39b:	mov    0x68(%rdi,%rax,8),%edi
 101d39f:	test   %edi,%edi
 101d3a1:	js     101d3ae <release+0x2e>
 101d3a3:	call   1027640 <close@plt>
 101d3a8:	mov    0x8(%rbx),%rdi
 101d3ac:	jmp    101d3b7 <release+0x37>
 101d3ae:	mov    0x8(%rbx),%rdi
 101d3b2:	test   %rdi,%rdi
 101d3b5:	je     101d3d2 <release+0x52>
 101d3b7:	call   1027570 <free@plt>
 101d3bc:	movl   $0xffffffff,(%rbx)
 101d3c2:	vxorps %xmm0,%xmm0,%xmm0
 101d3c6:	vmovups %ymm0,0x4(%rbx)
 101d3cb:	movl   $0x0,0x24(%rbx)
 101d3d2:	add    $0x8,%rsp
 101d3d6:	pop    %rbx
 101d3d7:	pop    %rbp
 101d3d8:	vzeroupper
 101d3db:	ret
 101d3dc:	int3
 101d3dd:	int3
 101d3de:	int3
 101d3df:	int3

000000000101d3e0 <read_handle>:
 101d3e0:	mov    %rdi,%rax
 101d3e3:	vmovups -0x11deb(%rip),%xmm0        # 100b600 <myl_rc_map_sentinel+0x10>
 101d3eb:	vmovups %xmm0,(%rdi)
 101d3ef:	movq   $0x0,0x10(%rdi)
 101d3f7:	cmp    $0xff,%rdx
 101d3fe:	ja     101d50c <read_handle+0x12c>
 101d404:	push   %rbp
 101d405:	mov    %rsp,%rbp
 101d408:	push   %r15
 101d40a:	push   %r14
 101d40c:	push   %rbx
 101d40d:	push   %rax
 101d40e:	lea    (%rdx,%rdx,4),%rdx
 101d412:	lea    (%rsi,%rdx,8),%r15
 101d416:	add    $0x68,%r15
 101d41a:	mov    0x68(%rsi,%rdx,8),%edi
 101d41e:	test   %edi,%edi
 101d420:	jns    101d42d <read_handle+0x4d>
 101d422:	cmpq   $0x0,0x8(%r15)
 101d427:	je     101d502 <read_handle+0x122>
 101d42d:	test   %r8,%r8
 101d430:	je     101d496 <read_handle+0xb6>
 101d432:	mov    %rax,%r14
 101d435:	cmp    $0x10000,%r8
 101d43c:	mov    $0x10000,%edx
 101d441:	cmovb  %r8,%rdx
 101d445:	mov    0x8(%r15),%rsi
 101d449:	test   %rsi,%rsi
 101d44c:	je     101d49e <read_handle+0xbe>
 101d44e:	mov    0x10(%r15),%rbx
 101d452:	mov    0x18(%r15),%rax
 101d456:	sub    %rax,%rbx
 101d459:	cmp    %rdx,%rbx
 101d45c:	cmovae %rdx,%rbx
 101d460:	add    %rax,%rsi
 101d463:	mov    %rcx,%rdi
 101d466:	mov    %rbx,%rdx
 101d469:	call   1027520 <memcpy@plt>
 101d46e:	mov    0x18(%r15),%rcx
 101d472:	add    %rbx,%rcx
 101d475:	mov    %rcx,0x18(%r15)
 101d479:	mov    %r14,%rax
 101d47c:	movl   $0x0,(%r14)
 101d483:	mov    %rbx,0x8(%r14)
 101d487:	xor    %edx,%edx
 101d489:	cmp    0x10(%r15),%rcx
 101d48d:	sete   %dl
 101d490:	mov    %edx,0x10(%r14)
 101d494:	jmp    101d502 <read_handle+0x122>
 101d496:	movl   $0x0,(%rax)
 101d49c:	jmp    101d502 <read_handle+0x122>
 101d49e:	cmpb   $0x61,0x20(%r15)
 101d4a3:	jne    101d4b1 <read_handle+0xd1>
 101d4a5:	mov    %r14,%rax
 101d4a8:	movl   $0x2,(%r14)
 101d4af:	jmp    101d502 <read_handle+0x122>
 101d4b1:	mov    %rcx,%rsi
 101d4b4:	call   10277f0 <read@plt>
 101d4b9:	test   %rax,%rax
 101d4bc:	js     101d4db <read_handle+0xfb>
 101d4be:	mov    %rax,%rcx
 101d4c1:	mov    %r14,%rax
 101d4c4:	movl   $0x0,(%r14)
 101d4cb:	mov    %rcx,0x8(%r14)
 101d4cf:	sete   %cl
 101d4d2:	movzbl %cl,%ecx
 101d4d5:	mov    %ecx,0x10(%r14)
 101d4d9:	jmp    101d502 <read_handle+0x122>
 101d4db:	call   1027800 <__errno_location@plt>
 101d4e0:	mov    (%rax),%edx
 101d4e2:	cmp    $0x28,%rdx
 101d4e6:	mov    %r14,%rax
 101d4e9:	ja     101d518 <read_handle+0x138>
 101d4eb:	movabs $0x10000102002,%rcx
 101d4f5:	bt     %rdx,%rcx
 101d4f9:	jae    101d50d <read_handle+0x12d>
 101d4fb:	mov    $0x2,%ecx
 101d500:	mov    %ecx,(%rax)
 101d502:	add    $0x8,%rsp
 101d506:	pop    %rbx
 101d507:	pop    %r14
 101d509:	pop    %r15
 101d50b:	pop    %rbp
 101d50c:	ret
 101d50d:	mov    $0x4,%ecx
 101d512:	cmp    $0xc,%rdx
 101d516:	je     101d500 <read_handle+0x120>
 101d518:	mov    $0x3,%ecx
 101d51d:	jmp    101d500 <read_handle+0x120>
 101d51f:	int3

000000000101d520 <write_handle>:
 101d520:	mov    $0x3,%eax
 101d525:	cmp    $0xff,%rsi
 101d52c:	jbe    101d531 <write_handle+0x11>
 101d52e:	xor    %edx,%edx
 101d530:	ret
 101d531:	mov    %rdi,%r8
 101d534:	lea    (%rsi,%rsi,4),%rax
 101d538:	mov    0x68(%rdi,%rax,8),%edi
 101d53c:	mov    0x70(%r8,%rax,8),%rsi
 101d541:	test   %edi,%edi
 101d543:	js     101d552 <write_handle+0x32>
 101d545:	test   %rsi,%rsi
 101d548:	je     101d561 <write_handle+0x41>
 101d54a:	xor    %edx,%edx
 101d54c:	mov    $0x2,%eax
 101d551:	ret
 101d552:	xor    %edx,%edx
 101d554:	cmp    $0x1,%rsi
 101d558:	mov    $0x0,%eax
 101d55d:	adc    $0x2,%eax
 101d560:	ret
 101d561:	push   %rbp
 101d562:	mov    %rsp,%rbp
 101d565:	push   %r15
 101d567:	push   %r14
 101d569:	push   %rbx
 101d56a:	push   %rax
 101d56b:	lea    (%r8,%rax,8),%r15
 101d56f:	add    $0x68,%r15
 101d573:	cmp    $0x10000,%rcx
 101d57a:	mov    $0x10000,%ebx
 101d57f:	cmovb  %rcx,%rbx
 101d583:	cmpb   $0x61,0x20(%r15)
 101d588:	jne    101d5bb <write_handle+0x9b>
 101d58a:	mov    %rdx,%r14
 101d58d:	xor    %esi,%esi
 101d58f:	mov    $0x2,%edx
 101d594:	call   1027810 <lseek@plt>
 101d599:	test   %rax,%rax
 101d59c:	js     101d5f6 <write_handle+0xd6>
 101d59e:	mov    (%r15),%edi
 101d5a1:	mov    %r14,%rsi
 101d5a4:	mov    %rbx,%rdx
 101d5a7:	mov    %rax,%rcx
 101d5aa:	call   1027820 <pwrite@plt>
 101d5af:	mov    %rax,%rdx
 101d5b2:	xor    %eax,%eax
 101d5b4:	test   %rdx,%rdx
 101d5b7:	jns    101d630 <write_handle+0x110>
 101d5b9:	jmp    101d5d0 <write_handle+0xb0>
 101d5bb:	mov    %rdx,%rsi
 101d5be:	mov    %rbx,%rdx
 101d5c1:	call   10276c0 <write@plt>
 101d5c6:	mov    %rax,%rdx
 101d5c9:	xor    %eax,%eax
 101d5cb:	test   %rdx,%rdx
 101d5ce:	jns    101d630 <write_handle+0x110>
 101d5d0:	call   1027800 <__errno_location@plt>
 101d5d5:	mov    (%rax),%eax
 101d5d7:	cmp    $0x28,%rax
 101d5db:	ja     101d629 <write_handle+0x109>
 101d5dd:	movabs $0x10000102002,%rcx
 101d5e7:	bt     %rax,%rcx
 101d5eb:	jae    101d61a <write_handle+0xfa>
 101d5ed:	xor    %edx,%edx
 101d5ef:	mov    $0x2,%eax
 101d5f4:	jmp    101d630 <write_handle+0x110>
 101d5f6:	call   1027800 <__errno_location@plt>
 101d5fb:	mov    (%rax),%eax
 101d5fd:	cmp    $0x28,%rax
 101d601:	ja     101d629 <write_handle+0x109>
 101d603:	movabs $0x10000102002,%rcx
 101d60d:	bt     %rax,%rcx
 101d611:	jae    101d61a <write_handle+0xfa>
 101d613:	mov    $0x2,%eax
 101d618:	jmp    101d625 <write_handle+0x105>
 101d61a:	cmp    $0xc,%rax
 101d61e:	jne    101d629 <write_handle+0x109>
 101d620:	mov    $0x4,%eax
 101d625:	xor    %edx,%edx
 101d627:	jmp    101d630 <write_handle+0x110>
 101d629:	xor    %edx,%edx
 101d62b:	mov    $0x3,%eax
 101d630:	add    $0x8,%rsp
 101d634:	pop    %rbx
 101d635:	pop    %r14
 101d637:	pop    %r15
 101d639:	pop    %rbp
 101d63a:	ret
 101d63b:	int3
 101d63c:	int3
 101d63d:	int3
 101d63e:	int3
 101d63f:	int3

000000000101d640 <acquire>:
 101d640:	push   %rbp
 101d641:	mov    %rsp,%rbp
 101d644:	push   %r15
 101d646:	push   %r14
 101d648:	push   %r13
 101d64a:	push   %r12
 101d64c:	push   %rbx
 101d64d:	sub    $0x1148,%rsp
 101d654:	cmpq   $0x0,0x60(%rdi)
 101d659:	je     101d6af <acquire+0x6f>
 101d65b:	mov    %rdx,%r8
 101d65e:	lea    -0x1001(%rdx),%rax
 101d665:	mov    $0x2,%r9d
 101d66b:	cmp    $0xfffffffffffff001,%rax
 101d671:	jb     101d6b5 <acquire+0x75>
 101d673:	mov    %rsi,%r13
 101d676:	cmpb   $0x3a,0x1(%rsi)
 101d67a:	jne    101d6b5 <acquire+0x75>
 101d67c:	movzbl 0x0(%r13),%eax
 101d681:	mov    %al,-0x29(%rbp)
 101d684:	movzbl %al,%eax
 101d687:	xor    %ebx,%ebx
 101d689:	lea    -0x61(%rax),%r12d
 101d68d:	cmp    $0x17,%r12d
 101d691:	ja     101d6b7 <acquire+0x77>
 101d693:	mov    %rdi,%r14
 101d696:	mov    %rax,-0xb0(%rbp)
 101d69d:	mov    $0xc80405,%eax
 101d6a2:	bt     %r12d,%eax
 101d6a6:	jae    101d6cf <acquire+0x8f>
 101d6a8:	mov    $0x2,%eax
 101d6ad:	jmp    101d6df <acquire+0x9f>
 101d6af:	mov    $0x1,%r9d
 101d6b5:	xor    %ebx,%ebx
 101d6b7:	mov    %r9d,%eax
 101d6ba:	mov    %rbx,%rdx
 101d6bd:	add    $0x1148,%rsp
 101d6c4:	pop    %rbx
 101d6c5:	pop    %r12
 101d6c7:	pop    %r13
 101d6c9:	pop    %r14
 101d6cb:	pop    %r15
 101d6cd:	pop    %rbp
 101d6ce:	ret
 101d6cf:	mov    $0x1,%eax
 101d6d4:	mov    $0x21800,%edx
 101d6d9:	bt     %r12d,%edx
 101d6dd:	jae    101d6b7 <acquire+0x77>
 101d6df:	test   %ecx,%eax
 101d6e1:	je     101d6b5 <acquire+0x75>
 101d6e3:	add    $0x2,%r13
 101d6e7:	lea    -0x2(%r8),%rdx
 101d6eb:	mov    -0xb0(%rbp),%rax
 101d6f2:	mov    %eax,%ecx
 101d6f4:	and    $0xfe,%cl
 101d6f7:	mov    %cl,-0x61(%rbp)
 101d6fa:	lea    0x68(%r14),%rcx
 101d6fe:	mov    %rcx,-0xd8(%rbp)
 101d705:	xor    %ecx,%ecx
 101d707:	cmp    $0x72,%al
 101d709:	setne  %cl
 101d70c:	mov    %ecx,-0x94(%rbp)
 101d712:	dec    %r8
 101d715:	add    $0xffffff95,%eax
 101d718:	mov    %rax,-0xd0(%rbp)
 101d71f:	mov    $0xc80405,%r15d
 101d725:	xor    %ecx,%ecx
 101d727:	mov    %r13,-0x60(%rbp)
 101d72b:	mov    %rdx,-0x38(%rbp)
 101d72f:	mov    %r8,-0xc8(%rbp)
 101d736:	mov    %r14,-0x78(%rbp)
 101d73a:	mov    %r12d,-0x3c(%rbp)
 101d73e:	jmp    101d75e <acquire+0x11e>
 101d740:	mov    $0x2,%r9d
 101d746:	mov    -0x3c(%rbp),%r12d
 101d74a:	mov    -0xe0(%rbp),%rcx
 101d751:	inc    %rcx
 101d754:	cmp    0x60(%r14),%rcx
 101d758:	jae    101d6b5 <acquire+0x75>
 101d75e:	cmp    $0x17,%r12d
 101d762:	mov    %rcx,-0xe0(%rbp)
 101d769:	ja     101d77d <acquire+0x13d>
 101d76b:	bt     %r12d,%r15d
 101d76f:	jae    101d77d <acquire+0x13d>
 101d771:	lea    (%rcx,%rcx,2),%rax
 101d775:	cmpl   $0x0,0x4(%r14,%rax,4)
 101d77b:	je     101d74a <acquire+0x10a>
 101d77d:	lea    (%rcx,%rcx,2),%rbx
 101d781:	mov    0x8(%r14,%rbx,4),%eax
 101d786:	mov    %eax,-0x80(%rbp)
 101d789:	test   %eax,%eax
 101d78b:	je     101d8b0 <acquire+0x270>
 101d791:	lea    (%r14,%rbx,4),%rax
 101d795:	mov    (%rax),%eax
 101d797:	mov    %eax,-0x4c(%rbp)
 101d79a:	mov    -0xd8(%rbp),%r12
 101d7a1:	xor    %ebx,%ebx
 101d7a3:	jmp    101d7c5 <acquire+0x185>
 101d7a5:	data16 cs nopw 0x0(%rax,%rax,1)
 101d7b0:	add    $0x2,%rbx
 101d7b4:	add    $0x50,%r12
 101d7b8:	cmp    $0x100,%rbx
 101d7bf:	je     101d740 <acquire+0x100>
 101d7c5:	cmpl   $0x0,(%r12)
 101d7ca:	jns    101d7d4 <acquire+0x194>
 101d7cc:	cmpq   $0x0,0x8(%r12)
 101d7d2:	je     101d7eb <acquire+0x1ab>
 101d7d4:	cmpl   $0x0,0x28(%r12)
 101d7da:	jns    101d7b0 <acquire+0x170>
 101d7dc:	cmpq   $0x0,0x30(%r12)
 101d7e2:	jne    101d7b0 <acquire+0x170>
 101d7e4:	inc    %rbx
 101d7e7:	add    $0x28,%r12
 101d7eb:	test   %rdx,%rdx
 101d7ee:	je     101d91c <acquire+0x2dc>
 101d7f4:	mov    $0x0,%r14d
 101d7fa:	mov    -0x4c(%rbp),%eax
 101d7fd:	mov    %eax,-0x48(%rbp)
 101d800:	cmpl   $0x0,-0x80(%rbp)
 101d804:	jne    101d925 <acquire+0x2e5>
 101d80a:	xor    %r15d,%r15d
 101d80d:	mov    -0x4c(%rbp),%eax
 101d810:	mov    %eax,-0x48(%rbp)
 101d813:	xor    %r14d,%r14d
 101d816:	jmp    101d845 <acquire+0x205>
 101d818:	nopl   0x0(%rax,%rax,1)
 101d820:	test   %r13d,%r13d
 101d823:	js     101da30 <acquire+0x3f0>
 101d829:	lea    0x1(%r15),%r14
 101d82d:	mov    %r13d,-0x48(%rbp)
 101d831:	mov    -0x60(%rbp),%r13
 101d835:	mov    -0x38(%rbp),%rdx
 101d839:	inc    %r15
 101d83c:	cmp    %r15,%rdx
 101d83f:	je     101d925 <acquire+0x2e5>
 101d845:	cmpb   $0x2f,0x0(%r13,%r15,1)
 101d84b:	jne    101d839 <acquire+0x1f9>
 101d84d:	mov    %r15,%rdx
 101d850:	sub    %r14,%rdx
 101d853:	cmp    $0xffe,%rdx
 101d85a:	ja     101da16 <acquire+0x3d6>
 101d860:	lea    (%r14,%r13,1),%rsi
 101d864:	lea    -0x1170(%rbp),%r13
 101d86b:	mov    %r13,%rdi
 101d86e:	call   1027520 <memcpy@plt>
 101d873:	mov    %r13,%rax
 101d876:	sub    %r14,%rax
 101d879:	movb   $0x0,(%rax,%r15,1)
 101d87e:	mov    -0x48(%rbp),%r14d
 101d882:	mov    %r14d,%edi
 101d885:	mov    %r13,%rsi
 101d888:	mov    $0xb0000,%edx
 101d88d:	xor    %eax,%eax
 101d88f:	call   1027830 <openat@plt>
 101d894:	mov    %eax,%r13d
 101d897:	cmp    -0x4c(%rbp),%r14d
 101d89b:	je     101d820 <acquire+0x1e0>
 101d89d:	mov    %r14d,%edi
 101d8a0:	call   1027640 <close@plt>
 101d8a5:	jmp    101d820 <acquire+0x1e0>
 101d8aa:	nopw   0x0(%rax,%rax,1)
 101d8b0:	test   %rdx,%rdx
 101d8b3:	je     101d8e0 <acquire+0x2a0>
 101d8b5:	mov    %r9d,-0x58(%rbp)
 101d8b9:	mov    %r13,%rdi
 101d8bc:	mov    $0x5c,%esi
 101d8c1:	mov    %rdx,%r15
 101d8c4:	call   1027840 <memchr@plt>
 101d8c9:	test   %rax,%rax
 101d8cc:	je     101d8ef <acquire+0x2af>
 101d8ce:	mov    %r15,%rdx
 101d8d1:	mov    $0xc80405,%r15d
 101d8d7:	mov    -0x58(%rbp),%r9d
 101d8db:	jmp    101d74a <acquire+0x10a>
 101d8e0:	cmpb   $0x6c,-0x61(%rbp)
 101d8e4:	jne    101d74a <acquire+0x10a>
 101d8ea:	jmp    101d791 <acquire+0x151>
 101d8ef:	mov    %r13,%rdi
 101d8f2:	xor    %esi,%esi
 101d8f4:	mov    %r15,%rdx
 101d8f7:	call   1027840 <memchr@plt>
 101d8fc:	test   %rax,%rax
 101d8ff:	je     101da82 <acquire+0x442>
 101d905:	mov    -0x38(%rbp),%rdx
 101d909:	mov    $0xc80405,%r15d
 101d90f:	mov    -0x60(%rbp),%r13
 101d913:	mov    -0x58(%rbp),%r9d
 101d917:	jmp    101d74a <acquire+0x10a>
 101d91c:	xor    %r14d,%r14d
 101d91f:	mov    -0x4c(%rbp),%eax
 101d922:	mov    %eax,-0x48(%rbp)
 101d925:	cmpl   $0x0,-0x48(%rbp)
 101d929:	js     101da34 <acquire+0x3f4>
 101d92f:	mov    %rdx,%r13
 101d932:	sub    %r14,%r13
 101d935:	cmp    $0xfff,%r13
 101d93c:	mov    $0xc80405,%r15d
 101d942:	jb     101d972 <acquire+0x332>
 101d944:	mov    $0x2,%r9d
 101d94a:	mov    -0x48(%rbp),%edi
 101d94d:	cmp    -0x4c(%rbp),%edi
 101d950:	mov    -0x78(%rbp),%r14
 101d954:	mov    -0x3c(%rbp),%r12d
 101d958:	je     101d969 <acquire+0x329>
 101d95a:	call   1027640 <close@plt>
 101d95f:	mov    $0x2,%r9d
 101d965:	mov    -0x38(%rbp),%rdx
 101d969:	mov    -0x60(%rbp),%r13
 101d96d:	jmp    101d74a <acquire+0x10a>
 101d972:	add    -0x60(%rbp),%r14
 101d976:	lea    -0x1170(%rbp),%rdi
 101d97d:	mov    %r14,%rsi
 101d980:	mov    %r13,%rdx
 101d983:	call   1027520 <memcpy@plt>
 101d988:	movb   $0x0,-0x1170(%rbp,%r13,1)
 101d991:	mov    -0xd0(%rbp),%rax
 101d998:	cmp    $0xd,%eax
 101d99b:	ja     101dda2 <acquire+0x762>
 101d9a1:	jmp    *0x1001b58(,%rax,8)
 101d9a8:	movzbl -0x1170(%rbp),%eax
 101d9af:	cmpb   $0x6d,-0x29(%rbp)
 101d9b3:	jne    101db15 <acquire+0x4d5>
 101d9b9:	test   %al,%al
 101d9bb:	mov    -0x60(%rbp),%r13
 101d9bf:	je     101ddf0 <acquire+0x7b0>
 101d9c5:	mov    -0x48(%rbp),%edi
 101d9c8:	lea    -0x1170(%rbp),%rsi
 101d9cf:	lea    -0x170(%rbp),%rdx
 101d9d6:	mov    $0x100,%ecx
 101d9db:	call   1027850 <fstatat@plt>
 101d9e0:	test   %eax,%eax
 101d9e2:	je     101de07 <acquire+0x7c7>
 101d9e8:	call   1027800 <__errno_location@plt>
 101d9ed:	mov    (%rax),%eax
 101d9ef:	cmp    $0x28,%rax
 101d9f3:	mov    -0x38(%rbp),%rdx
 101d9f7:	ja     101e251 <acquire+0xc11>
 101d9fd:	movabs $0x10000102002,%rcx
 101da07:	bt     %rax,%rcx
 101da0b:	jb     101df3d <acquire+0x8fd>
 101da11:	jmp    101df48 <acquire+0x908>
 101da16:	call   1027800 <__errno_location@plt>
 101da1b:	movl   $0x24,(%rax)
 101da21:	mov    -0x48(%rbp),%edi
 101da24:	cmp    -0x4c(%rbp),%edi
 101da27:	je     101da34 <acquire+0x3f4>
 101da29:	call   1027640 <close@plt>
 101da2e:	jmp    101da34 <acquire+0x3f4>
 101da30:	mov    -0x60(%rbp),%r13
 101da34:	call   1027800 <__errno_location@plt>
 101da39:	mov    -0x38(%rbp),%rdx
 101da3d:	mov    (%rax),%eax
 101da3f:	cmp    $0x28,%rax
 101da43:	mov    -0x78(%rbp),%r14
 101da47:	mov    -0x3c(%rbp),%r12d
 101da4b:	mov    $0xc80405,%r15d
 101da51:	ja     101da77 <acquire+0x437>
 101da53:	mov    $0x2,%r9d
 101da59:	movabs $0x10000102002,%rcx
 101da63:	bt     %rax,%rcx
 101da67:	jb     101d74a <acquire+0x10a>
 101da6d:	cmp    $0xc,%rax
 101da71:	je     101e320 <acquire+0xce0>
 101da77:	mov    $0x3,%r9d
 101da7d:	jmp    101d74a <acquire+0x10a>
 101da82:	xor    %eax,%eax
 101da84:	xor    %ecx,%ecx
 101da86:	mov    -0x38(%rbp),%rdx
 101da8a:	mov    $0xc80405,%r15d
 101da90:	mov    -0xc8(%rbp),%r8
 101da97:	mov    -0x60(%rbp),%r13
 101da9b:	mov    -0x58(%rbp),%r9d
 101da9f:	jmp    101dac0 <acquire+0x480>
 101daa1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101dab0:	lea    0x1(%rax),%rcx
 101dab4:	inc    %rax
 101dab7:	cmp    %rax,%r8
 101daba:	je     101d791 <acquire+0x151>
 101dac0:	cmp    %rax,%rdx
 101dac3:	je     101dacd <acquire+0x48d>
 101dac5:	cmpb   $0x2f,0x0(%r13,%rax,1)
 101dacb:	jne    101dab4 <acquire+0x474>
 101dacd:	mov    %rax,%rsi
 101dad0:	sub    %rcx,%rsi
 101dad3:	je     101d74a <acquire+0x10a>
 101dad9:	cmp    $0x2,%rsi
 101dadd:	je     101db00 <acquire+0x4c0>
 101dadf:	cmp    $0x1,%rsi
 101dae3:	jne    101dab0 <acquire+0x470>
 101dae5:	cmpb   $0x2e,0x0(%r13,%rcx,1)
 101daeb:	jne    101dab0 <acquire+0x470>
 101daed:	jmp    101d74a <acquire+0x10a>
 101daf2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101db00:	cmpb   $0x2e,0x0(%r13,%rcx,1)
 101db06:	jne    101dab0 <acquire+0x470>
 101db08:	cmpb   $0x2e,0x1(%r13,%rcx,1)
 101db0e:	jne    101dab0 <acquire+0x470>
 101db10:	jmp    101d74a <acquire+0x10a>
 101db15:	mov    $0x2,%r9d
 101db1b:	test   %al,%al
 101db1d:	mov    -0x60(%rbp),%r13
 101db21:	mov    -0x38(%rbp),%rdx
 101db25:	je     101e257 <acquire+0xc17>
 101db2b:	cmpb   $0x6b,-0x29(%rbp)
 101db2f:	jne    101de59 <acquire+0x819>
 101db35:	mov    -0x48(%rbp),%edi
 101db38:	lea    -0x1170(%rbp),%rsi
 101db3f:	mov    $0x1ff,%edx
 101db44:	call   1027860 <mkdirat@plt>
 101db49:	test   %eax,%eax
 101db4b:	je     101def2 <acquire+0x8b2>
 101db51:	call   1027800 <__errno_location@plt>
 101db56:	mov    (%rax),%eax
 101db58:	cmp    $0x28,%rax
 101db5c:	mov    -0x38(%rbp),%rdx
 101db60:	ja     101e251 <acquire+0xc11>
 101db66:	movabs $0x10000102002,%rcx
 101db70:	bt     %rax,%rcx
 101db74:	jb     101e067 <acquire+0xa27>
 101db7a:	jmp    101df48 <acquire+0x908>
 101db7f:	cmpb   $0x0,-0x1170(%rbp)
 101db86:	lea    -0x1170(%rbp),%rsi
 101db8d:	mov    $0x1004662,%eax
 101db92:	cmove  %rax,%rsi
 101db96:	mov    -0x48(%rbp),%edi
 101db99:	mov    $0xb0000,%edx
 101db9e:	xor    %eax,%eax
 101dba0:	call   1027830 <openat@plt>
 101dba5:	test   %eax,%eax
 101dba7:	js     101df14 <acquire+0x8d4>
 101dbad:	mov    %eax,%r14d
 101dbb0:	mov    %eax,%edi
 101dbb2:	call   1027870 <fdopendir@plt>
 101dbb7:	mov    %rax,-0x80(%rbp)
 101dbbb:	test   %rax,%rax
 101dbbe:	mov    -0x60(%rbp),%r13
 101dbc2:	je     101e077 <acquire+0xa37>
 101dbc8:	mov    $0x400,%edi
 101dbcd:	call   1027500 <malloc@plt>
 101dbd2:	test   %rax,%rax
 101dbd5:	je     101e15a <acquire+0xb1a>
 101dbdb:	mov    %rax,%r14
 101dbde:	movb   $0x1,(%rax)
 101dbe1:	mov    $0x1,%r13d
 101dbe7:	mov    $0x400,%eax
 101dbec:	mov    %rax,-0xa0(%rbp)
 101dbf3:	call   1027800 <__errno_location@plt>
 101dbf8:	mov    %rax,-0x58(%rbp)
 101dbfc:	movq   $0x0,-0xa8(%rbp)
 101dc07:	mov    %r13,-0x90(%rbp)
 101dc0e:	mov    -0x60(%rbp),%r13
 101dc12:	mov    -0x58(%rbp),%rax
 101dc16:	movl   $0x0,(%rax)
 101dc1c:	mov    -0x80(%rbp),%rdi
 101dc20:	call   1027880 <readdir@plt>
 101dc25:	test   %rax,%rax
 101dc28:	je     101e163 <acquire+0xb23>
 101dc2e:	cmpb   $0x2e,0x13(%rax)
 101dc32:	jne    101dc47 <acquire+0x607>
 101dc34:	movzbl 0x14(%rax),%ecx
 101dc38:	test   %ecx,%ecx
 101dc3a:	je     101dc12 <acquire+0x5d2>
 101dc3c:	cmp    $0x2e,%ecx
 101dc3f:	jne    101dc47 <acquire+0x607>
 101dc41:	cmpb   $0x0,0x15(%rax)
 101dc45:	je     101dc12 <acquire+0x5d2>
 101dc47:	add    $0x13,%rax
 101dc4b:	mov    %rax,-0x88(%rbp)
 101dc52:	mov    %rax,%rdi
 101dc55:	call   10274f0 <strlen@plt>
 101dc5a:	mov    -0x90(%rbp),%rdx
 101dc61:	cmp    $0x10000,%rdx
 101dc68:	ja     101e2f7 <acquire+0xcb7>
 101dc6e:	cmpq   $0xff,-0xa8(%rbp)
 101dc79:	ja     101e2f7 <acquire+0xcb7>
 101dc7f:	lea    -0xfff(%rax),%rcx
 101dc86:	cmp    $0xfffffffffffff002,%rcx
 101dc8d:	jb     101e2f7 <acquire+0xcb7>
 101dc93:	lea    0x3(%rax),%rsi
 101dc97:	mov    $0x10000,%ecx
 101dc9c:	sub    %rdx,%rcx
 101dc9f:	cmp    %rcx,%rsi
 101dca2:	ja     101e2f7 <acquire+0xcb7>
 101dca8:	lea    0x3(%rdx),%rcx
 101dcac:	mov    %rcx,-0xb8(%rbp)
 101dcb3:	mov    %rax,-0xc0(%rbp)
 101dcba:	add    %rdx,%rax
 101dcbd:	add    $0x3,%rax
 101dcc1:	mov    %rax,-0x70(%rbp)
 101dcc5:	mov    %r14,%rax
 101dcc8:	mov    -0xa0(%rbp),%r13
 101dccf:	mov    %rax,%r14
 101dcd2:	cmp    %r13,-0x70(%rbp)
 101dcd6:	jbe    101dcf0 <acquire+0x6b0>
 101dcd8:	add    %r13,%r13
 101dcdb:	mov    %r14,%rdi
 101dcde:	mov    %r13,%rsi
 101dce1:	call   1027670 <realloc@plt>
 101dce6:	test   %rax,%rax
 101dce9:	jne    101dccf <acquire+0x68f>
 101dceb:	jmp    101e17f <acquire+0xb3f>
 101dcf0:	mov    %r13,-0xa0(%rbp)
 101dcf7:	mov    -0x80(%rbp),%rdi
 101dcfb:	call   1027890 <dirfd@plt>
 101dd00:	mov    %eax,%edi
 101dd02:	mov    -0x88(%rbp),%rsi
 101dd09:	lea    -0x170(%rbp),%rdx
 101dd10:	mov    $0x100,%ecx
 101dd15:	call   1027850 <fstatat@plt>
 101dd1a:	test   %eax,%eax
 101dd1c:	je     101dd5e <acquire+0x71e>
 101dd1e:	xor    %eax,%eax
 101dd20:	mov    -0x88(%rbp),%rsi
 101dd27:	mov    -0x70(%rbp),%r13
 101dd2b:	mov    -0x90(%rbp),%rcx
 101dd32:	mov    %al,(%r14,%rcx,1)
 101dd36:	mov    -0xc0(%rbp),%rdx
 101dd3d:	mov    %dx,0x1(%r14,%rcx,1)
 101dd43:	mov    -0xb8(%rbp),%rdi
 101dd4a:	add    %r14,%rdi
 101dd4d:	call   1027520 <memcpy@plt>
 101dd52:	incq   -0xa8(%rbp)
 101dd59:	jmp    101dc07 <acquire+0x5c7>
 101dd5e:	mov    -0x158(%rbp),%eax
 101dd64:	mov    $0xf000,%ecx
 101dd69:	and    %ecx,%eax
 101dd6b:	cmp    $0xa000,%eax
 101dd70:	mov    -0x70(%rbp),%r13
 101dd74:	je     101dd93 <acquire+0x753>
 101dd76:	cmp    $0x8000,%eax
 101dd7b:	mov    -0x88(%rbp),%rsi
 101dd82:	je     101dd8f <acquire+0x74f>
 101dd84:	cmp    $0x4000,%eax
 101dd89:	jne    101dd9e <acquire+0x75e>
 101dd8b:	mov    $0x2,%al
 101dd8d:	jmp    101dd2b <acquire+0x6eb>
 101dd8f:	mov    $0x1,%al
 101dd91:	jmp    101dd2b <acquire+0x6eb>
 101dd93:	mov    $0x3,%al
 101dd95:	mov    -0x88(%rbp),%rsi
 101dd9c:	jmp    101dd2b <acquire+0x6eb>
 101dd9e:	xor    %eax,%eax
 101dda0:	jmp    101dd2b <acquire+0x6eb>
 101dda2:	xor    %edx,%edx
 101dda4:	cmpl   $0x0,-0x80(%rbp)
 101dda8:	sete   %dl
 101ddab:	shl    $0xb,%edx
 101ddae:	mov    -0xb0(%rbp),%rax
 101ddb5:	cmp    $0x61,%eax
 101ddb8:	je     101df68 <acquire+0x928>
 101ddbe:	cmp    $0x63,%eax
 101ddc1:	mov    -0x60(%rbp),%r13
 101ddc5:	mov    -0x78(%rbp),%r14
 101ddc9:	jne    101df8e <acquire+0x94e>
 101ddcf:	or     $0x800c1,%edx
 101ddd5:	mov    -0x48(%rbp),%edi
 101ddd8:	lea    -0x1170(%rbp),%rsi
 101dddf:	mov    $0x1b6,%ecx
 101dde4:	xor    %eax,%eax
 101dde6:	call   1027830 <openat@plt>
 101ddeb:	jmp    101dfb6 <acquire+0x976>
 101ddf0:	mov    -0x48(%rbp),%edi
 101ddf3:	lea    -0x170(%rbp),%rsi
 101ddfa:	call   10278a0 <fstat@plt>
 101ddff:	test   %eax,%eax
 101de01:	jne    101d9e8 <acquire+0x3a8>
 101de07:	mov    $0xa,%edi
 101de0c:	call   1027500 <malloc@plt>
 101de11:	test   %rax,%rax
 101de14:	je     101df5d <acquire+0x91d>
 101de1a:	mov    %rax,%r14
 101de1d:	movb   $0x1,(%rax)
 101de20:	mov    -0x158(%rbp),%eax
 101de26:	mov    $0xf000,%ecx
 101de2b:	and    %ecx,%eax
 101de2d:	cmp    $0xa000,%eax
 101de32:	je     101e203 <acquire+0xbc3>
 101de38:	cmp    $0x8000,%eax
 101de3d:	mov    -0x38(%rbp),%rdx
 101de41:	je     101e1ff <acquire+0xbbf>
 101de47:	cmp    $0x4000,%eax
 101de4c:	jne    101e20b <acquire+0xbcb>
 101de52:	mov    $0x2,%al
 101de54:	jmp    101e20d <acquire+0xbcd>
 101de59:	mov    -0x48(%rbp),%edi
 101de5c:	lea    -0x1170(%rbp),%rsi
 101de63:	xor    %edx,%edx
 101de65:	call   10278b0 <unlinkat@plt>
 101de6a:	test   %eax,%eax
 101de6c:	je     101def2 <acquire+0x8b2>
 101de72:	call   1027800 <__errno_location@plt>
 101de77:	mov    (%rax),%ecx
 101de79:	cmp    $0x28,%rcx
 101de7d:	mov    -0x38(%rbp),%rdx
 101de81:	ja     101e251 <acquire+0xc11>
 101de87:	movabs $0x10000102000,%rsi
 101de91:	bt     %rcx,%rsi
 101de95:	jb     101e067 <acquire+0xa27>
 101de9b:	mov    $0x200002,%esi
 101dea0:	bt     %rcx,%rsi
 101dea4:	jae    101e247 <acquire+0xc07>
 101deaa:	mov    %rax,%r14
 101dead:	mov    -0x48(%rbp),%edi
 101deb0:	lea    -0x1170(%rbp),%rsi
 101deb7:	mov    $0x200,%edx
 101debc:	call   10278b0 <unlinkat@plt>
 101dec1:	test   %eax,%eax
 101dec3:	je     101def2 <acquire+0x8b2>
 101dec5:	mov    (%r14),%eax
 101dec8:	cmp    $0x28,%rax
 101decc:	mov    -0x38(%rbp),%rdx
 101ded0:	ja     101e251 <acquire+0xc11>
 101ded6:	movabs $0x10000102002,%rcx
 101dee0:	bt     %rax,%rcx
 101dee4:	mov    $0x2,%r9d
 101deea:	jb     101e257 <acquire+0xc17>
 101def0:	jmp    101df48 <acquire+0x908>
 101def2:	mov    $0x1,%edi
 101def7:	call   1027500 <malloc@plt>
 101defc:	test   %rax,%rax
 101deff:	je     101df5d <acquire+0x91d>
 101df01:	mov    %rax,%r14
 101df04:	movb   $0x1,(%rax)
 101df07:	mov    $0x1,%ecx
 101df0c:	xor    %r9d,%r9d
 101df0f:	jmp    101e0b4 <acquire+0xa74>
 101df14:	call   1027800 <__errno_location@plt>
 101df19:	mov    (%rax),%eax
 101df1b:	cmp    $0x28,%rax
 101df1f:	mov    -0x60(%rbp),%r13
 101df23:	mov    -0x38(%rbp),%rdx
 101df27:	ja     101e251 <acquire+0xc11>
 101df2d:	movabs $0x10000102002,%rcx
 101df37:	bt     %rax,%rcx
 101df3b:	jae    101df48 <acquire+0x908>
 101df3d:	mov    $0x2,%r9d
 101df43:	jmp    101e257 <acquire+0xc17>
 101df48:	cmp    $0xc,%rax
 101df4c:	jne    101e251 <acquire+0xc11>
 101df52:	mov    $0x4,%r9d
 101df58:	jmp    101e257 <acquire+0xc17>
 101df5d:	mov    $0x4,%r9d
 101df63:	jmp    101e0af <acquire+0xa6f>
 101df68:	or     $0x80041,%edx
 101df6e:	mov    -0x48(%rbp),%edi
 101df71:	lea    -0x1170(%rbp),%rsi
 101df78:	mov    $0x1b6,%ecx
 101df7d:	xor    %eax,%eax
 101df7f:	call   1027830 <openat@plt>
 101df84:	mov    -0x60(%rbp),%r13
 101df88:	mov    -0x78(%rbp),%r14
 101df8c:	jmp    101dfb6 <acquire+0x976>
 101df8e:	cmpl   $0x0,-0x80(%rbp)
 101df92:	mov    $0xa0800,%edx
 101df97:	mov    $0x80000,%eax
 101df9c:	cmovne %eax,%edx
 101df9f:	add    -0x94(%rbp),%edx
 101dfa5:	mov    -0x48(%rbp),%edi
 101dfa8:	lea    -0x1170(%rbp),%rsi
 101dfaf:	xor    %eax,%eax
 101dfb1:	call   1027830 <openat@plt>
 101dfb6:	mov    -0x48(%rbp),%edi
 101dfb9:	cmp    -0x4c(%rbp),%edi
 101dfbc:	mov    %eax,-0x70(%rbp)
 101dfbf:	je     101dfc9 <acquire+0x989>
 101dfc1:	call   1027640 <close@plt>
 101dfc6:	mov    -0x70(%rbp),%eax
 101dfc9:	test   %eax,%eax
 101dfcb:	js     101e025 <acquire+0x9e5>
 101dfcd:	mov    %eax,%edi
 101dfcf:	lea    -0x170(%rbp),%rsi
 101dfd6:	call   10278a0 <fstat@plt>
 101dfdb:	test   %eax,%eax
 101dfdd:	je     101e0bd <acquire+0xa7d>
 101dfe3:	call   1027800 <__errno_location@plt>
 101dfe8:	mov    (%rax),%eax
 101dfea:	cmp    $0x28,%rax
 101dfee:	mov    -0x3c(%rbp),%r12d
 101dff2:	mov    -0x70(%rbp),%edi
 101dff5:	ja     101e1f5 <acquire+0xbb5>
 101dffb:	movabs $0x10000102002,%rcx
 101e005:	bt     %rax,%rcx
 101e009:	jae    101e1e6 <acquire+0xba6>
 101e00f:	mov    $0x2,%ecx
 101e014:	mov    %ecx,%ebx
 101e016:	call   1027640 <close@plt>
 101e01b:	mov    %ebx,%r9d
 101e01e:	xor    %ebx,%ebx
 101e020:	jmp    101e23e <acquire+0xbfe>
 101e025:	call   1027800 <__errno_location@plt>
 101e02a:	mov    (%rax),%eax
 101e02c:	cmp    $0x28,%rax
 101e030:	mov    -0x3c(%rbp),%r12d
 101e034:	mov    -0x38(%rbp),%rdx
 101e038:	ja     101da77 <acquire+0x437>
 101e03e:	mov    $0x2,%r9d
 101e044:	movabs $0x10000102002,%rcx
 101e04e:	bt     %rax,%rcx
 101e052:	jb     101d74a <acquire+0x10a>
 101e058:	cmp    $0xc,%rax
 101e05c:	jne    101da77 <acquire+0x437>
 101e062:	jmp    101e320 <acquire+0xce0>
 101e067:	xor    %ecx,%ecx
 101e069:	xor    %r14d,%r14d
 101e06c:	mov    $0x2,%r9d
 101e072:	jmp    101e25c <acquire+0xc1c>
 101e077:	call   1027800 <__errno_location@plt>
 101e07c:	mov    (%rax),%eax
 101e07e:	cmp    $0x28,%rax
 101e082:	ja     101e2ed <acquire+0xcad>
 101e088:	movabs $0x10000102002,%rcx
 101e092:	bt     %rax,%rcx
 101e096:	jae    101e2de <acquire+0xc9e>
 101e09c:	mov    $0x2,%ecx
 101e0a1:	mov    %r14d,%edi
 101e0a4:	mov    %ecx,%r14d
 101e0a7:	call   1027640 <close@plt>
 101e0ac:	mov    %r14d,%r9d
 101e0af:	xor    %ecx,%ecx
 101e0b1:	xor    %r14d,%r14d
 101e0b4:	mov    -0x38(%rbp),%rdx
 101e0b8:	jmp    101e25c <acquire+0xc1c>
 101e0bd:	mov    -0x158(%rbp),%r14d
 101e0c4:	mov    -0x80(%rbp),%edi
 101e0c7:	mov    -0x70(%rbp),%esi
 101e0ca:	mov    %r14d,%edx
 101e0cd:	call   101e330 <usable>
 101e0d2:	test   %eax,%eax
 101e0d4:	je     101e226 <acquire+0xbe6>
 101e0da:	cmpb   $0x74,-0x29(%rbp)
 101e0de:	sete   %al
 101e0e1:	and    $0xf000,%r14d
 101e0e8:	cmp    $0x8000,%r14d
 101e0ef:	sete   %cl
 101e0f2:	and    %al,%cl
 101e0f4:	cmp    $0x1,%cl
 101e0f7:	jne    101e1ad <acquire+0xb6d>
 101e0fd:	mov    -0x70(%rbp),%edi
 101e100:	xor    %esi,%esi
 101e102:	call   10278c0 <ftruncate@plt>
 101e107:	test   %eax,%eax
 101e109:	je     101e1ad <acquire+0xb6d>
 101e10f:	call   1027800 <__errno_location@plt>
 101e114:	mov    (%rax),%eax
 101e116:	cmp    $0x28,%rax
 101e11a:	mov    -0x78(%rbp),%r14
 101e11e:	mov    -0x3c(%rbp),%r12d
 101e122:	mov    -0x70(%rbp),%edi
 101e125:	ja     101e314 <acquire+0xcd4>
 101e12b:	movabs $0x10000102002,%rcx
 101e135:	bt     %rax,%rcx
 101e139:	jae    101e303 <acquire+0xcc3>
 101e13f:	movl   $0x2,-0x58(%rbp)
 101e146:	call   1027640 <close@plt>
 101e14b:	xor    %ebx,%ebx
 101e14d:	mov    -0x38(%rbp),%rdx
 101e151:	mov    -0x58(%rbp),%r9d
 101e155:	jmp    101e2cf <acquire+0xc8f>
 101e15a:	movl   $0x4,-0x58(%rbp)
 101e161:	jmp    101e192 <acquire+0xb52>
 101e163:	mov    -0x80(%rbp),%rdi
 101e167:	call   10278d0 <closedir@plt>
 101e16c:	xor    %r9d,%r9d
 101e16f:	mov    -0x38(%rbp),%rdx
 101e173:	mov    -0x90(%rbp),%rcx
 101e17a:	jmp    101e25c <acquire+0xc1c>
 101e17f:	movl   $0x4,-0x58(%rbp)
 101e186:	mov    -0x60(%rbp),%r13
 101e18a:	mov    %r14,%rdi
 101e18d:	call   1027570 <free@plt>
 101e192:	mov    -0x80(%rbp),%rdi
 101e196:	call   10278d0 <closedir@plt>
 101e19b:	xor    %ecx,%ecx
 101e19d:	xor    %r14d,%r14d
 101e1a0:	mov    -0x38(%rbp),%rdx
 101e1a4:	mov    -0x58(%rbp),%r9d
 101e1a8:	jmp    101e25c <acquire+0xc1c>
 101e1ad:	mov    -0x70(%rbp),%eax
 101e1b0:	mov    %eax,(%r12)
 101e1b4:	vxorps %xmm0,%xmm0,%xmm0
 101e1b8:	vmovups %xmm0,0x4(%r12)
 101e1bf:	vmovups %xmm0,0x10(%r12)
 101e1c6:	movzbl -0x29(%rbp),%eax
 101e1ca:	mov    %al,0x20(%r12)
 101e1cf:	movl   $0x0,0x21(%r12)
 101e1d8:	movl   $0x0,0x24(%r12)
 101e1e1:	xor    %r9d,%r9d
 101e1e4:	jmp    101e236 <acquire+0xbf6>
 101e1e6:	mov    $0x4,%ecx
 101e1eb:	cmp    $0xc,%rax
 101e1ef:	je     101e014 <acquire+0x9d4>
 101e1f5:	mov    $0x3,%ecx
 101e1fa:	jmp    101e014 <acquire+0x9d4>
 101e1ff:	mov    $0x1,%al
 101e201:	jmp    101e20d <acquire+0xbcd>
 101e203:	mov    $0x3,%al
 101e205:	mov    -0x38(%rbp),%rdx
 101e209:	jmp    101e20d <acquire+0xbcd>
 101e20b:	xor    %eax,%eax
 101e20d:	mov    %al,0x1(%r14)
 101e211:	mov    -0x140(%rbp),%rax
 101e218:	mov    %rax,0x2(%r14)
 101e21c:	mov    $0xa,%ecx
 101e221:	xor    %r9d,%r9d
 101e224:	jmp    101e25c <acquire+0xc1c>
 101e226:	mov    -0x70(%rbp),%edi
 101e229:	call   1027640 <close@plt>
 101e22e:	mov    $0x2,%r9d
 101e234:	xor    %ebx,%ebx
 101e236:	mov    -0x78(%rbp),%r14
 101e23a:	mov    -0x3c(%rbp),%r12d
 101e23e:	mov    -0x38(%rbp),%rdx
 101e242:	jmp    101e2cf <acquire+0xc8f>
 101e247:	cmp    $0xc,%rcx
 101e24b:	je     101df52 <acquire+0x912>
 101e251:	mov    $0x3,%r9d
 101e257:	xor    %ecx,%ecx
 101e259:	xor    %r14d,%r14d
 101e25c:	mov    -0x48(%rbp),%edi
 101e25f:	cmp    -0x4c(%rbp),%edi
 101e262:	je     101e287 <acquire+0xc47>
 101e264:	mov    %r14,-0x48(%rbp)
 101e268:	mov    %r9d,%r14d
 101e26b:	mov    %rcx,%r15
 101e26e:	call   1027640 <close@plt>
 101e273:	mov    %r15,%rcx
 101e276:	mov    %r14d,%r9d
 101e279:	mov    -0x48(%rbp),%r14
 101e27d:	mov    $0xc80405,%r15d
 101e283:	mov    -0x38(%rbp),%rdx
 101e287:	test   %r14,%r14
 101e28a:	je     101e2c5 <acquire+0xc85>
 101e28c:	mov    $0xffffffff,%eax
 101e291:	mov    %rax,(%r12)
 101e295:	mov    %r14,0x8(%r12)
 101e29a:	mov    %rcx,0x10(%r12)
 101e29f:	movq   $0x0,0x18(%r12)
 101e2a8:	movzbl -0x29(%rbp),%eax
 101e2ac:	mov    %al,0x20(%r12)
 101e2b1:	movl   $0x0,0x21(%r12)
 101e2ba:	movl   $0x0,0x24(%r12)
 101e2c3:	jmp    101e2c7 <acquire+0xc87>
 101e2c5:	xor    %ebx,%ebx
 101e2c7:	mov    -0x78(%rbp),%r14
 101e2cb:	mov    -0x3c(%rbp),%r12d
 101e2cf:	test   $0x3,%r9b
 101e2d3:	jne    101d74a <acquire+0x10a>
 101e2d9:	jmp    101d6b7 <acquire+0x77>
 101e2de:	mov    $0x4,%ecx
 101e2e3:	cmp    $0xc,%rax
 101e2e7:	je     101e0a1 <acquire+0xa61>
 101e2ed:	mov    $0x3,%ecx
 101e2f2:	jmp    101e0a1 <acquire+0xa61>
 101e2f7:	movl   $0x2,-0x58(%rbp)
 101e2fe:	jmp    101e18a <acquire+0xb4a>
 101e303:	movl   $0x4,-0x58(%rbp)
 101e30a:	cmp    $0xc,%rax
 101e30e:	je     101e146 <acquire+0xb06>
 101e314:	movl   $0x3,-0x58(%rbp)
 101e31b:	jmp    101e146 <acquire+0xb06>
 101e320:	mov    $0x4,%r9d
 101e326:	jmp    101d6b5 <acquire+0x75>
 101e32b:	int3
 101e32c:	int3
 101e32d:	int3
 101e32e:	int3
 101e32f:	int3

000000000101e330 <usable>:
 101e330:	and    $0xf000,%edx
 101e336:	test   %edi,%edi
 101e338:	je     101e347 <usable+0x17>
 101e33a:	cmp    $0x4000,%edx
 101e340:	setne  %al
 101e343:	movzbl %al,%eax
 101e346:	ret
 101e347:	cmp    $0x8000,%edx
 101e34d:	jne    101e389 <usable+0x59>
 101e34f:	push   %rbp
 101e350:	mov    %rsp,%rbp
 101e353:	push   %rbx
 101e354:	push   %rax
 101e355:	mov    %esi,%edi
 101e357:	mov    %esi,%ebx
 101e359:	mov    $0x3,%esi
 101e35e:	xor    %eax,%eax
 101e360:	call   10278e0 <fcntl@plt>
 101e365:	and    $0xfffff7ff,%eax
 101e36a:	mov    %ebx,%edi
 101e36c:	mov    $0x4,%esi
 101e371:	mov    %eax,%edx
 101e373:	xor    %eax,%eax
 101e375:	call   10278e0 <fcntl@plt>
 101e37a:	test   %eax,%eax
 101e37c:	sete   %al
 101e37f:	add    $0x8,%rsp
 101e383:	pop    %rbx
 101e384:	pop    %rbp
 101e385:	movzbl %al,%eax
 101e388:	ret
 101e389:	xor    %eax,%eax
 101e38b:	movzbl %al,%eax
 101e38e:	ret

000000000101e38f <entry_release>:
 101e38f:	push   %rbp
 101e390:	mov    %rsp,%rbp
 101e393:	mov    $0x28,%edx
 101e398:	pop    %rbp
 101e399:	jmp    1018860 <myl_rc_meta_free>
 101e39e:	int3
 101e39f:	int3

000000000101e3a0 <myl_rc_scope_unwind>:
 101e3a0:	push   %rbp
 101e3a1:	mov    %rsp,%rbp
 101e3a4:	push   %r15
 101e3a6:	push   %r14
 101e3a8:	push   %r13
 101e3aa:	push   %r12
 101e3ac:	push   %rbx
 101e3ad:	push   %rax
 101e3ae:	mov    %rsi,%rbx
 101e3b1:	test   %rdi,%rdi
 101e3b4:	je     101e435 <myl_rc_scope_unwind+0x95>
 101e3b6:	mov    %rdi,%r12
 101e3b9:	mov    0x1608(%rdi),%rax
 101e3c0:	test   %rax,%rax
 101e3c3:	je     101e435 <myl_rc_scope_unwind+0x95>
 101e3c5:	mov    0xf8(%rax),%rdi
 101e3cc:	cmp    %rbx,%rdi
 101e3cf:	je     101e43e <myl_rc_scope_unwind+0x9e>
 101e3d1:	movabs $0xeffffffffffffffd,%r14
 101e3db:	mov    %rdi,%rax
 101e3de:	jmp    101e3e9 <myl_rc_scope_unwind+0x49>
 101e3e0:	mov    0x8(%rax),%rax
 101e3e4:	cmp    %rbx,%rax
 101e3e7:	je     101e44d <myl_rc_scope_unwind+0xad>
 101e3e9:	test   %rax,%rax
 101e3ec:	je     101e695 <myl_rc_scope_unwind+0x2f5>
 101e3f2:	mov    0x10(%rax),%rcx
 101e3f6:	jmp    101e40a <myl_rc_scope_unwind+0x6a>
 101e3f8:	nopl   0x0(%rax,%rax,1)
 101e400:	movl   $0x0,0x18(%rcx)
 101e407:	mov    (%rcx),%rcx
 101e40a:	test   %rcx,%rcx
 101e40d:	je     101e3e0 <myl_rc_scope_unwind+0x40>
 101e40f:	cmpl   $0x0,0x18(%rcx)
 101e413:	je     101e400 <myl_rc_scope_unwind+0x60>
 101e415:	mov    0x8(%rcx),%rdx
 101e419:	test   %rdx,%rdx
 101e41c:	je     101e400 <myl_rc_scope_unwind+0x60>
 101e41e:	mov    -0x10(%rdx),%rsi
 101e422:	test   $0x2,%sil
 101e426:	jne    101e400 <myl_rc_scope_unwind+0x60>
 101e428:	and    %r14,%rsi
 101e42b:	or     0x10(%rcx),%rsi
 101e42f:	mov    %rsi,-0x10(%rdx)
 101e433:	jmp    101e400 <myl_rc_scope_unwind+0x60>
 101e435:	test   %rbx,%rbx
 101e438:	jne    101e695 <myl_rc_scope_unwind+0x2f5>
 101e43e:	add    $0x8,%rsp
 101e442:	pop    %rbx
 101e443:	pop    %r12
 101e445:	pop    %r13
 101e447:	pop    %r14
 101e449:	pop    %r15
 101e44b:	pop    %rbp
 101e44c:	ret
 101e44d:	mov    %r12,-0x30(%rbp)
 101e451:	jmp    101e474 <myl_rc_scope_unwind+0xd4>
 101e453:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101e460:	mov    0x1608(%r12),%rax
 101e468:	mov    0xf8(%rax),%rdi
 101e46f:	cmp    %rbx,%rdi
 101e472:	je     101e43e <myl_rc_scope_unwind+0x9e>
 101e474:	test   %rdi,%rdi
 101e477:	je     101e695 <myl_rc_scope_unwind+0x2f5>
 101e47d:	cmpl   $0x0,0x18(%rdi)
 101e481:	je     101e460 <myl_rc_scope_unwind+0xc0>
 101e483:	mov    (%rdi),%r15
 101e486:	test   %r15,%r15
 101e489:	je     101e695 <myl_rc_scope_unwind+0x2f5>
 101e48f:	mov    0x1608(%r15),%rax
 101e496:	test   %rax,%rax
 101e499:	je     101e695 <myl_rc_scope_unwind+0x2f5>
 101e49f:	cmp    %rdi,0xf8(%rax)
 101e4a6:	jne    101e695 <myl_rc_scope_unwind+0x2f5>
 101e4ac:	mov    0x8(%rdi),%rcx
 101e4b0:	mov    %rcx,0xf8(%rax)
 101e4b7:	movl   $0x0,0x18(%rdi)
 101e4be:	movq   $0x0,0x8(%rdi)
 101e4c6:	mov    0x10(%rdi),%rsi
 101e4ca:	test   %rsi,%rsi
 101e4cd:	je     101e62d <myl_rc_scope_unwind+0x28d>
 101e4d3:	cmpq   $0x0,(%rsi)
 101e4d7:	jne    101e64f <myl_rc_scope_unwind+0x2af>
 101e4dd:	cmpl   $0x0,0x18(%rsi)
 101e4e1:	mov    0x8(%rsi),%r12
 101e4e5:	je     101e507 <myl_rc_scope_unwind+0x167>
 101e4e7:	test   %r12,%r12
 101e4ea:	je     101e504 <myl_rc_scope_unwind+0x164>
 101e4ec:	mov    -0x10(%r12),%rcx
 101e4f1:	test   $0x2,%cl
 101e4f4:	jne    101e507 <myl_rc_scope_unwind+0x167>
 101e4f6:	and    %r14,%rcx
 101e4f9:	or     0x10(%rsi),%rcx
 101e4fd:	mov    %rcx,-0x10(%r12)
 101e502:	jmp    101e507 <myl_rc_scope_unwind+0x167>
 101e504:	xor    %r12d,%r12d
 101e507:	movq   $0x0,0x10(%rdi)
 101e50f:	mov    0x20(%rsi),%r13
 101e513:	mov    0x108(%rax),%rcx
 101e51a:	cmp    $0x20,%rcx
 101e51e:	je     101e656 <myl_rc_scope_unwind+0x2b6>
 101e524:	mov    0x18(%r15),%rdx
 101e528:	cmp    $0x28,%rdx
 101e52c:	jb     101e695 <myl_rc_scope_unwind+0x2f5>
 101e532:	mov    0x30(%rax),%rdi
 101e536:	cmp    $0x27,%rdi
 101e53a:	jbe    101e695 <myl_rc_scope_unwind+0x2f5>
 101e540:	add    $0xffffffffffffffd8,%rdx
 101e544:	mov    %rdx,0x18(%r15)
 101e548:	add    $0xffffffffffffffd8,%rdi
 101e54c:	mov    %rdi,0x30(%rax)
 101e550:	mov    0x100(%rax),%rdx
 101e557:	mov    %rdx,(%rsi)
 101e55a:	mov    %rsi,0x100(%rax)
 101e561:	inc    %rcx
 101e564:	mov    %rcx,0x108(%rax)
 101e56b:	test   %r13,%r13
 101e56e:	je     101e5c9 <myl_rc_scope_unwind+0x229>
 101e570:	mov    -0x10(%r13),%rcx
 101e574:	movabs $0x4000000000000002,%rax
 101e57e:	test   %rax,%rcx
 101e581:	jne    101e5b0 <myl_rc_scope_unwind+0x210>
 101e583:	mov    -0x18(%r13),%rax
 101e587:	test   %rax,%rax
 101e58a:	je     101e695 <myl_rc_scope_unwind+0x2f5>
 101e590:	and    $0x1,%ecx
 101e593:	jne    101e695 <myl_rc_scope_unwind+0x2f5>
 101e599:	dec    %rax
 101e59c:	mov    %rax,-0x18(%r13)
 101e5a0:	jne    101e5b0 <myl_rc_scope_unwind+0x210>
 101e5a2:	cmpq   $0x0,-0x20(%r13)
 101e5a7:	je     101e66c <myl_rc_scope_unwind+0x2cc>
 101e5ad:	nopl   (%rax)
 101e5b0:	mov    0x1608(%r15),%rax
 101e5b7:	cmpq   $0x0,0xc8(%rax)
 101e5bf:	je     101e5c9 <myl_rc_scope_unwind+0x229>
 101e5c1:	mov    %r15,%rdi
 101e5c4:	call   101bcb0 <myl_rc_drain>
 101e5c9:	test   %r12,%r12
 101e5cc:	je     101e610 <myl_rc_scope_unwind+0x270>
 101e5ce:	mov    -0x10(%r12),%rcx
 101e5d3:	movabs $0x4000000000000002,%rax
 101e5dd:	test   %rax,%rcx
 101e5e0:	jne    101e610 <myl_rc_scope_unwind+0x270>
 101e5e2:	mov    -0x18(%r12),%rax
 101e5e7:	test   %rax,%rax
 101e5ea:	je     101e695 <myl_rc_scope_unwind+0x2f5>
 101e5f0:	and    $0x1,%ecx
 101e5f3:	jne    101e695 <myl_rc_scope_unwind+0x2f5>
 101e5f9:	dec    %rax
 101e5fc:	mov    %rax,-0x18(%r12)
 101e601:	jne    101e610 <myl_rc_scope_unwind+0x270>
 101e603:	cmpq   $0x0,-0x20(%r12)
 101e609:	je     101e680 <myl_rc_scope_unwind+0x2e0>
 101e60b:	nopl   0x0(%rax,%rax,1)
 101e610:	mov    0x1608(%r15),%rax
 101e617:	cmpq   $0x0,0xc8(%rax)
 101e61f:	mov    -0x30(%rbp),%r12
 101e623:	je     101e62d <myl_rc_scope_unwind+0x28d>
 101e625:	mov    %r15,%rdi
 101e628:	call   101bcb0 <myl_rc_drain>
 101e62d:	mov    0x1608(%r15),%rax
 101e634:	cmpq   $0x0,0xc8(%rax)
 101e63c:	je     101e460 <myl_rc_scope_unwind+0xc0>
 101e642:	mov    %r15,%rdi
 101e645:	call   101bcb0 <myl_rc_drain>
 101e64a:	jmp    101e460 <myl_rc_scope_unwind+0xc0>
 101e64f:	call   101e6a0 <unwind_many>
 101e654:	jmp    101e62d <myl_rc_scope_unwind+0x28d>
 101e656:	mov    %r15,%rdi
 101e659:	call   101e38f <entry_release>
 101e65e:	test   %r13,%r13
 101e661:	jne    101e570 <myl_rc_scope_unwind+0x1d0>
 101e667:	jmp    101e5c9 <myl_rc_scope_unwind+0x229>
 101e66c:	add    $0xffffffffffffffe0,%r13
 101e670:	mov    %r15,%rdi
 101e673:	mov    %r13,%rsi
 101e676:	call   101e88a <hold_death>
 101e67b:	jmp    101e5c9 <myl_rc_scope_unwind+0x229>
 101e680:	add    $0xffffffffffffffe0,%r12
 101e684:	mov    %r15,%rdi
 101e687:	mov    %r12,%rsi
 101e68a:	call   101e88a <hold_death>
 101e68f:	mov    -0x30(%rbp),%r12
 101e693:	jmp    101e62d <myl_rc_scope_unwind+0x28d>
 101e695:	call   10187d4 <myl_rc_invariant_failed>
 101e69a:	int3
 101e69b:	int3
 101e69c:	int3
 101e69d:	int3
 101e69e:	int3
 101e69f:	int3

000000000101e6a0 <unwind_many>:
 101e6a0:	push   %rbp
 101e6a1:	mov    %rsp,%rbp
 101e6a4:	push   %r15
 101e6a6:	push   %r14
 101e6a8:	push   %r13
 101e6aa:	push   %r12
 101e6ac:	push   %rbx
 101e6ad:	push   %rax
 101e6ae:	mov    (%rdi),%rbx
 101e6b1:	mov    0x10(%rdi),%r12
 101e6b5:	test   %r12,%r12
 101e6b8:	je     101e6fe <unwind_many+0x5e>
 101e6ba:	movabs $0xeffffffffffffffd,%rax
 101e6c4:	mov    %r12,%rcx
 101e6c7:	jmp    101e6d8 <unwind_many+0x38>
 101e6c9:	nopl   0x0(%rax)
 101e6d0:	mov    (%rcx),%rcx
 101e6d3:	test   %rcx,%rcx
 101e6d6:	je     101e6fe <unwind_many+0x5e>
 101e6d8:	cmpl   $0x0,0x18(%rcx)
 101e6dc:	je     101e6d0 <unwind_many+0x30>
 101e6de:	mov    0x8(%rcx),%rdx
 101e6e2:	test   %rdx,%rdx
 101e6e5:	je     101e6d0 <unwind_many+0x30>
 101e6e7:	mov    -0x10(%rdx),%rsi
 101e6eb:	test   $0x2,%sil
 101e6ef:	jne    101e6d0 <unwind_many+0x30>
 101e6f1:	and    %rax,%rsi
 101e6f4:	or     0x10(%rcx),%rsi
 101e6f8:	mov    %rsi,-0x10(%rdx)
 101e6fc:	jmp    101e6d0 <unwind_many+0x30>
 101e6fe:	movabs $0x4000000000000002,%r13
 101e708:	movq   $0x0,0x10(%rdi)
 101e710:	jmp    101e739 <unwind_many+0x99>
 101e712:	add    $0xffffffffffffffe0,%r14
 101e716:	mov    %rbx,%rdi
 101e719:	mov    %r14,%rsi
 101e71c:	call   101e88a <hold_death>
 101e721:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101e730:	test   %r12,%r12
 101e733:	je     101e876 <unwind_many+0x1d6>
 101e739:	mov    %r12,%rsi
 101e73c:	mov    (%r12),%r12
 101e740:	mov    0x8(%rsi),%r14
 101e744:	mov    0x20(%rsi),%r15
 101e748:	mov    0x1608(%rbx),%rax
 101e74f:	mov    0x108(%rax),%rcx
 101e756:	cmp    $0x20,%rcx
 101e75a:	je     101e852 <unwind_many+0x1b2>
 101e760:	mov    0x18(%rbx),%rdx
 101e764:	cmp    $0x28,%rdx
 101e768:	jb     101e885 <unwind_many+0x1e5>
 101e76e:	mov    0x30(%rax),%rdi
 101e772:	cmp    $0x27,%rdi
 101e776:	jbe    101e885 <unwind_many+0x1e5>
 101e77c:	add    $0xffffffffffffffd8,%rdx
 101e780:	mov    %rdx,0x18(%rbx)
 101e784:	add    $0xffffffffffffffd8,%rdi
 101e788:	mov    %rdi,0x30(%rax)
 101e78c:	mov    0x100(%rax),%rdx
 101e793:	mov    %rdx,(%rsi)
 101e796:	mov    %rsi,0x100(%rax)
 101e79d:	inc    %rcx
 101e7a0:	mov    %rcx,0x108(%rax)
 101e7a7:	test   %r15,%r15
 101e7aa:	je     101e7f9 <unwind_many+0x159>
 101e7ac:	mov    -0x10(%r15),%rcx
 101e7b0:	test   %r13,%rcx
 101e7b3:	jne    101e7e0 <unwind_many+0x140>
 101e7b5:	mov    -0x18(%r15),%rax
 101e7b9:	test   %rax,%rax
 101e7bc:	je     101e885 <unwind_many+0x1e5>
 101e7c2:	and    $0x1,%ecx
 101e7c5:	jne    101e885 <unwind_many+0x1e5>
 101e7cb:	dec    %rax
 101e7ce:	mov    %rax,-0x18(%r15)
 101e7d2:	jne    101e7e0 <unwind_many+0x140>
 101e7d4:	cmpq   $0x0,-0x20(%r15)
 101e7d9:	je     101e865 <unwind_many+0x1c5>
 101e7df:	nop
 101e7e0:	mov    0x1608(%rbx),%rax
 101e7e7:	cmpq   $0x0,0xc8(%rax)
 101e7ef:	je     101e7f9 <unwind_many+0x159>
 101e7f1:	mov    %rbx,%rdi
 101e7f4:	call   101bcb0 <myl_rc_drain>
 101e7f9:	test   %r14,%r14
 101e7fc:	je     101e830 <unwind_many+0x190>
 101e7fe:	mov    -0x10(%r14),%rcx
 101e802:	test   %r13,%rcx
 101e805:	jne    101e830 <unwind_many+0x190>
 101e807:	mov    -0x18(%r14),%rax
 101e80b:	test   %rax,%rax
 101e80e:	je     101e885 <unwind_many+0x1e5>
 101e810:	and    $0x1,%ecx
 101e813:	jne    101e885 <unwind_many+0x1e5>
 101e815:	dec    %rax
 101e818:	mov    %rax,-0x18(%r14)
 101e81c:	jne    101e830 <unwind_many+0x190>
 101e81e:	cmpq   $0x0,-0x20(%r14)
 101e823:	je     101e712 <unwind_many+0x72>
 101e829:	nopl   0x0(%rax)
 101e830:	mov    0x1608(%rbx),%rax
 101e837:	cmpq   $0x0,0xc8(%rax)
 101e83f:	je     101e730 <unwind_many+0x90>
 101e845:	mov    %rbx,%rdi
 101e848:	call   101bcb0 <myl_rc_drain>
 101e84d:	jmp    101e730 <unwind_many+0x90>
 101e852:	mov    %rbx,%rdi
 101e855:	call   101e38f <entry_release>
 101e85a:	test   %r15,%r15
 101e85d:	jne    101e7ac <unwind_many+0x10c>
 101e863:	jmp    101e7f9 <unwind_many+0x159>
 101e865:	add    $0xffffffffffffffe0,%r15
 101e869:	mov    %rbx,%rdi
 101e86c:	mov    %r15,%rsi
 101e86f:	call   101e88a <hold_death>
 101e874:	jmp    101e7f9 <unwind_many+0x159>
 101e876:	add    $0x8,%rsp
 101e87a:	pop    %rbx
 101e87b:	pop    %r12
 101e87d:	pop    %r13
 101e87f:	pop    %r14
 101e881:	pop    %r15
 101e883:	pop    %rbp
 101e884:	ret
 101e885:	call   10187d4 <myl_rc_invariant_failed>

000000000101e88a <hold_death>:
 101e88a:	push   %rbp
 101e88b:	mov    %rsp,%rbp
 101e88e:	push   %rbx
 101e88f:	push   %rax
 101e890:	mov    0x10(%rsi),%rax
 101e894:	test   $0x1,%al
 101e896:	jne    101e978 <hold_death+0xee>
 101e89c:	mov    %rsi,%rcx
 101e89f:	mov    %rdi,%rbx
 101e8a2:	or     $0x1,%rax
 101e8a6:	mov    %rax,0x10(%rsi)
 101e8aa:	mov    0x1608(%rdi),%rdi
 101e8b1:	cmpl   $0x0,0xd0(%rdi)
 101e8b8:	jne    101e905 <hold_death+0x7b>
 101e8ba:	mov    0x18(%rcx),%rsi
 101e8be:	cmp    %rsi,0x110(%rdi)
 101e8c5:	je     101e92f <hold_death+0xa5>
 101e8c7:	mov    0x34(%rsi),%eax
 101e8ca:	cmp    %rax,0xa0(%rdi)
 101e8d1:	jbe    101e96e <hold_death+0xe4>
 101e8d7:	mov    0x98(%rdi),%rdx
 101e8de:	shl    $0x4,%rax
 101e8e2:	cmp    %rsi,(%rdx,%rax,1)
 101e8e6:	jne    101e96e <hold_death+0xe4>
 101e8ec:	add    %rax,%rdx
 101e8ef:	mov    0x8(%rdx),%rax
 101e8f3:	test   %rax,%rax
 101e8f6:	je     101e8fe <hold_death+0x74>
 101e8f8:	cmpl   $0x0,0x40(%rax)
 101e8fc:	je     101e92b <hold_death+0xa1>
 101e8fe:	mov    0x1608(%rbx),%rdi
 101e905:	mov    0xc8(%rdi),%rax
 101e90c:	mov    %rax,(%rcx)
 101e90f:	mov    0x1608(%rbx),%rax
 101e916:	mov    %rcx,0xc8(%rax)
 101e91d:	mov    %rbx,%rdi
 101e920:	add    $0x8,%rsp
 101e924:	pop    %rbx
 101e925:	pop    %rbp
 101e926:	jmp    101bcb0 <myl_rc_drain>
 101e92b:	mov    0x10(%rcx),%rax
 101e92f:	movabs $0x4000000000000003,%rdx
 101e939:	and    %rax,%rdx
 101e93c:	cmp    $0x1,%rdx
 101e940:	jne    101e978 <hold_death+0xee>
 101e942:	mov    0x1608(%rbx),%rax
 101e949:	add    $0x20,%rcx
 101e94d:	mov    %rbx,%rdi
 101e950:	mov    %rcx,%rsi
 101e953:	call   *0x8(%rax)
 101e956:	mov    0x1608(%rbx),%rax
 101e95d:	cmpq   $0x0,0xc8(%rax)
 101e965:	jne    101e91d <hold_death+0x93>
 101e967:	add    $0x8,%rsp
 101e96b:	pop    %rbx
 101e96c:	pop    %rbp
 101e96d:	ret
 101e96e:	call   1018df4 <myl_rc_binding_find_slow>
 101e973:	jmp    101e8f3 <hold_death+0x69>
 101e978:	call   10187d4 <myl_rc_invariant_failed>
 101e97d:	int3
 101e97e:	int3
 101e97f:	int3

000000000101e980 <transfer>:
 101e980:	push   %rbp
 101e981:	mov    %rsp,%rbp
 101e984:	push   %r15
 101e986:	push   %r14
 101e988:	push   %r13
 101e98a:	push   %r12
 101e98c:	push   %rbx
 101e98d:	sub    $0x218,%rsp
 101e994:	test   %rdi,%rdi
 101e997:	je     101ed81 <transfer+0x401>
 101e99d:	mov    0x1608(%rdi),%r13
 101e9a4:	test   %r13,%r13
 101e9a7:	je     101ed81 <transfer+0x401>
 101e9ad:	mov    %rsi,%rbx
 101e9b0:	mov    0x8(%rsi),%r15
 101e9b4:	test   %r15,%r15
 101e9b7:	je     101ed81 <transfer+0x401>
 101e9bd:	test   %rcx,%rcx
 101e9c0:	je     101ed81 <transfer+0x401>
 101e9c6:	movabs $0x9e3779b97f4a7c15,%r8
 101e9d0:	mov    0x58(%r13),%rax
 101e9d4:	mov    0x60(%r13),%rsi
 101e9d8:	mov    0x70(%r13),%r9d
 101e9dc:	mov    %rdx,%r10
 101e9df:	imul   %r8,%r10
 101e9e3:	shrx   %r9,%r10,%r10
 101e9e8:	and    %rsi,%r10
 101e9eb:	mov    %r10,%r11
 101e9ee:	shl    $0x4,%r11
 101e9f2:	mov    (%rax,%r11,1),%r11
 101e9f6:	cmp    %rdx,%r11
 101e9f9:	je     101ea1b <transfer+0x9b>
 101e9fb:	xor    %r14d,%r14d
 101e9fe:	xchg   %ax,%ax
 101ea00:	test   %r11,%r11
 101ea03:	je     101ea24 <transfer+0xa4>
 101ea05:	inc    %r10
 101ea08:	and    %rsi,%r10
 101ea0b:	mov    %r10,%r11
 101ea0e:	shl    $0x4,%r11
 101ea12:	mov    (%rax,%r11,1),%r11
 101ea16:	cmp    %rdx,%r11
 101ea19:	jne    101ea00 <transfer+0x80>
 101ea1b:	shl    $0x4,%r10
 101ea1f:	mov    0x8(%rax,%r10,1),%r14
 101ea24:	mov    (%rbx),%r10
 101ea27:	imul   %r10,%r8
 101ea2b:	shrx   %r9,%r8,%rdx
 101ea30:	and    %rsi,%rdx
 101ea33:	mov    %rdx,%r8
 101ea36:	shl    $0x4,%r8
 101ea3a:	mov    (%rax,%r8,1),%r8
 101ea3e:	cmp    %r10,%r8
 101ea41:	je     101ea51 <transfer+0xd1>
 101ea43:	test   %r8,%r8
 101ea46:	je     101ed81 <transfer+0x401>
 101ea4c:	inc    %rdx
 101ea4f:	jmp    101ea30 <transfer+0xb0>
 101ea51:	test   %r14,%r14
 101ea54:	je     101ed81 <transfer+0x401>
 101ea5a:	shl    $0x4,%rdx
 101ea5e:	mov    0x8(%rax,%rdx,1),%rax
 101ea63:	test   %rax,%rax
 101ea66:	je     101ed81 <transfer+0x401>
 101ea6c:	mov    (%r14),%rdx
 101ea6f:	cmp    (%rax),%rdx
 101ea72:	jne    101ed81 <transfer+0x401>
 101ea78:	cmp    %r15,%rcx
 101ea7b:	je     101ed81 <transfer+0x401>
 101ea81:	mov    0x18(%rbx),%edx
 101ea84:	mov    $0x3,%eax
 101ea89:	cmp    0x70(%rdi),%edx
 101ea8c:	ja     101eca6 <transfer+0x326>
 101ea92:	cmpl   $0x1,0x8(%r14)
 101ea97:	jne    101eb02 <transfer+0x182>
 101ea99:	mov    (%rcx),%rax
 101ea9c:	test   %rax,%rax
 101ea9f:	je     101ead5 <transfer+0x155>
 101eaa1:	mov    -0x10(%rax),%rsi
 101eaa5:	test   $0x2,%sil
 101eaa9:	jne    101ead5 <transfer+0x155>
 101eaab:	bt     $0x3e,%rsi
 101eab0:	setae  %r8b
 101eab4:	mov    %rsi,%r9
 101eab7:	shr    $0x28,%r9
 101eabb:	and    $0xfffff,%r9d
 101eac2:	cmp    %edx,%r9d
 101eac5:	setbe  %r9b
 101eac9:	bt     $0x3c,%rsi
 101eace:	jb     101eb02 <transfer+0x182>
 101ead0:	or     %r9b,%r8b
 101ead3:	je     101eb02 <transfer+0x182>
 101ead5:	mov    %rax,(%r15)
 101ead8:	movq   $0x0,(%rcx)
 101eadf:	mov    0x1608(%rdi),%rcx
 101eae6:	xor    %eax,%eax
 101eae8:	cmpq   $0x0,0xc8(%rcx)
 101eaf0:	je     101eca6 <transfer+0x326>
 101eaf6:	call   101bcb0 <myl_rc_drain>
 101eafb:	xor    %eax,%eax
 101eafd:	jmp    101eca6 <transfer+0x326>
 101eb02:	vxorps %xmm0,%xmm0,%xmm0
 101eb06:	vmovups %ymm0,-0xa0(%rbp)
 101eb0e:	vmovups %ymm0,-0xc0(%rbp)
 101eb16:	vmovups %ymm0,-0xe0(%rbp)
 101eb1e:	vmovups %ymm0,-0x100(%rbp)
 101eb26:	vmovups %ymm0,-0x120(%rbp)
 101eb2e:	vmovups %ymm0,-0x140(%rbp)
 101eb36:	movq   $0x0,-0x80(%rbp)
 101eb3e:	mov    %rdi,-0x58(%rbp)
 101eb42:	lea    -0x240(%rbp),%rax
 101eb49:	mov    %rax,-0x50(%rbp)
 101eb4d:	movq   $0x8,-0x48(%rbp)
 101eb55:	movq   $0x0,-0x40(%rbp)
 101eb5d:	mov    %edx,-0x38(%rbp)
 101eb60:	movl   $0x1,-0x34(%rbp)
 101eb67:	lea    -0x140(%rbp),%rax
 101eb6e:	mov    %rax,-0x30(%rbp)
 101eb72:	mov    0x28(%r14),%r12
 101eb76:	cmp    $0x9,%r12
 101eb7a:	jb     101ec05 <transfer+0x285>
 101eb80:	mov    %rbx,-0x78(%rbp)
 101eb84:	mov    %r12,%rax
 101eb87:	shr    $0x3b,%rax
 101eb8b:	jne    101ed81 <transfer+0x401>
 101eb91:	mov    %r12,%rbx
 101eb94:	shl    $0x5,%rbx
 101eb98:	mov    0x18(%rdi),%rdx
 101eb9c:	add    %rbx,%rdx
 101eb9f:	jb     101ebaf <transfer+0x22f>
 101eba1:	mov    0x58(%rdi),%rax
 101eba5:	test   %rax,%rax
 101eba8:	je     101ebc0 <transfer+0x240>
 101ebaa:	cmp    %rax,%rdx
 101ebad:	jbe    101ebc0 <transfer+0x240>
 101ebaf:	movl   $0x1,0x6c(%rdi)
 101ebb6:	mov    $0x1,%eax
 101ebbb:	jmp    101eca6 <transfer+0x326>
 101ebc0:	mov    %rdx,-0x60(%rbp)
 101ebc4:	mov    %rdi,-0x68(%rbp)
 101ebc8:	mov    %rcx,-0x70(%rbp)
 101ebcc:	mov    $0x1,%edi
 101ebd1:	mov    %rbx,%rsi
 101ebd4:	vzeroupper
 101ebd7:	call   1027510 <calloc@plt>
 101ebdc:	test   %rax,%rax
 101ebdf:	je     101ecec <transfer+0x36c>
 101ebe5:	mov    -0x68(%rbp),%rcx
 101ebe9:	mov    -0x60(%rbp),%rdx
 101ebed:	mov    %rdx,0x18(%rcx)
 101ebf1:	add    %rbx,0x30(%r13)
 101ebf5:	mov    %rax,-0x50(%rbp)
 101ebf9:	mov    %r12,-0x48(%rbp)
 101ebfd:	mov    -0x70(%rbp),%rcx
 101ec01:	mov    -0x78(%rbp),%rbx
 101ec05:	mov    (%r14),%rdx
 101ec08:	mov    %r15,%rdi
 101ec0b:	mov    %rcx,%rsi
 101ec0e:	mov    %rcx,%r12
 101ec11:	vzeroupper
 101ec14:	call   1027520 <memcpy@plt>
 101ec19:	mov    0x8(%rbx),%rdx
 101ec1d:	lea    -0x58(%rbp),%rdi
 101ec21:	mov    $0x101fcb0,%r8d
 101ec27:	mov    %r14,%rsi
 101ec2a:	mov    %r12,%r15
 101ec2d:	mov    %r12,%rcx
 101ec30:	call   101ed90 <visit>
 101ec35:	test   %eax,%eax
 101ec37:	je     101ec4d <transfer+0x2cd>
 101ec39:	mov    %eax,%r12d
 101ec3c:	mov    -0x30(%rbp),%rax
 101ec40:	movq   $0x0,0xb8(%rax)
 101ec4b:	jmp    101ec6c <transfer+0x2ec>
 101ec4d:	lea    -0x58(%rbp),%rdi
 101ec51:	call   101ffd0 <finish_clones>
 101ec56:	mov    -0x30(%rbp),%rcx
 101ec5a:	test   %eax,%eax
 101ec5c:	je     101ecbb <transfer+0x33b>
 101ec5e:	mov    %eax,%r12d
 101ec61:	movq   $0x0,0xb8(%rcx)
 101ec6c:	mov    %r15,%rcx
 101ec6f:	mov    0x8(%rbx),%rdx
 101ec73:	lea    -0x58(%rbp),%rdi
 101ec77:	mov    $0x10206a0,%r8d
 101ec7d:	mov    %r14,%rsi
 101ec80:	call   101ed90 <visit>
 101ec85:	mov    0x8(%rbx),%rdi
 101ec89:	mov    $0x1,%ebx
 101ec8e:	mov    (%r14),%rdx
 101ec91:	xor    %esi,%esi
 101ec93:	call   10274d0 <memset@plt>
 101ec98:	lea    -0x58(%rbp),%rdi
 101ec9c:	mov    %ebx,%esi
 101ec9e:	call   1020760 <dispose_walk>
 101eca3:	mov    %r12d,%eax
 101eca6:	add    $0x218,%rsp
 101ecad:	pop    %rbx
 101ecae:	pop    %r12
 101ecb0:	pop    %r13
 101ecb2:	pop    %r14
 101ecb4:	pop    %r15
 101ecb6:	pop    %rbp
 101ecb7:	vzeroupper
 101ecba:	ret
 101ecbb:	mov    0xb8(%rcx),%rdi
 101ecc2:	test   %rdi,%rdi
 101ecc5:	je     101ed50 <transfer+0x3d0>
 101eccb:	movabs $0x2000000000000000,%rax
 101ecd5:	mov    0xb0(%rcx),%rsi
 101ecdc:	mov    %edi,%edx
 101ecde:	and    $0x3,%edx
 101ece1:	cmp    $0x4,%rdi
 101ece5:	jae    101ecf3 <transfer+0x373>
 101ece7:	xor    %r8d,%r8d
 101ecea:	jmp    101ed31 <transfer+0x3b1>
 101ecec:	mov    $0x1,%eax
 101ecf1:	jmp    101eca6 <transfer+0x326>
 101ecf3:	and    $0xfffffffffffffffc,%rdi
 101ecf7:	xor    %r8d,%r8d
 101ecfa:	nopw   0x0(%rax,%rax,1)
 101ed00:	mov    (%rsi,%r8,8),%r9
 101ed04:	or     %rax,-0x10(%r9)
 101ed08:	mov    0x8(%rsi,%r8,8),%r9
 101ed0d:	or     %rax,-0x10(%r9)
 101ed11:	mov    0x10(%rsi,%r8,8),%r9
 101ed16:	or     %rax,-0x10(%r9)
 101ed1a:	mov    0x18(%rsi,%r8,8),%r9
 101ed1f:	or     %rax,-0x10(%r9)
 101ed23:	add    $0x4,%r8
 101ed27:	cmp    %r8,%rdi
 101ed2a:	jne    101ed00 <transfer+0x380>
 101ed2c:	test   %rdx,%rdx
 101ed2f:	je     101ed50 <transfer+0x3d0>
 101ed31:	lea    (%rsi,%r8,8),%rsi
 101ed35:	xor    %edi,%edi
 101ed37:	nopw   0x0(%rax,%rax,1)
 101ed40:	mov    (%rsi,%rdi,8),%r8
 101ed44:	or     %rax,-0x10(%r8)
 101ed48:	inc    %rdi
 101ed4b:	cmp    %rdi,%rdx
 101ed4e:	jne    101ed40 <transfer+0x3c0>
 101ed50:	movq   $0x0,0xb8(%rcx)
 101ed5b:	mov    0x8(%rbx),%rdx
 101ed5f:	lea    -0x58(%rbp),%rdi
 101ed63:	mov    $0x1020700,%r8d
 101ed69:	mov    %r14,%rsi
 101ed6c:	mov    %r15,%rcx
 101ed6f:	call   101ed90 <visit>
 101ed74:	mov    %r15,%rdi
 101ed77:	xor    %r12d,%r12d
 101ed7a:	xor    %ebx,%ebx
 101ed7c:	jmp    101ec8e <transfer+0x30e>
 101ed81:	vzeroupper
 101ed84:	call   10187d4 <myl_rc_invariant_failed>
 101ed89:	int3
 101ed8a:	int3
 101ed8b:	int3
 101ed8c:	int3
 101ed8d:	int3
 101ed8e:	int3
 101ed8f:	int3

000000000101ed90 <visit>:
 101ed90:	push   %rbp
 101ed91:	mov    %rsp,%rbp
 101ed94:	push   %r15
 101ed96:	push   %r14
 101ed98:	push   %r13
 101ed9a:	push   %r12
 101ed9c:	push   %rbx
 101ed9d:	sub    $0x38,%rsp
 101eda1:	mov    %rdi,%rbx
 101eda4:	movq   $0x0,0x18(%rdi)
 101edac:	mov    0x8(%rsi),%r13d
 101edb0:	mov    %r13d,%eax
 101edb3:	or     $0x4,%eax
 101edb6:	cmp    $0x5,%eax
 101edb9:	jne    101edd8 <visit+0x48>
 101edbb:	mov    %rbx,%rdi
 101edbe:	mov    %rdx,%rsi
 101edc1:	mov    %rcx,%rdx
 101edc4:	mov    %r13d,%ecx
 101edc7:	add    $0x38,%rsp
 101edcb:	pop    %rbx
 101edcc:	pop    %r12
 101edce:	pop    %r13
 101edd0:	pop    %r14
 101edd2:	pop    %r15
 101edd4:	pop    %rbp
 101edd5:	jmp    *%r8
 101edd8:	cmpq   $0x2,0x28(%rsi)
 101eddd:	mov    %r8,-0x38(%rbp)
 101ede1:	jbe    101ef42 <visit+0x1b2>
 101ede7:	xor    %eax,%eax
 101ede9:	test   %r13d,%r13d
 101edec:	je     101f06f <visit+0x2df>
 101edf2:	cmpq   $0x0,0x10(%rbx)
 101edf7:	je     101f088 <visit+0x2f8>
 101edfd:	mov    0x8(%rbx),%rax
 101ee01:	movq   $0x1,0x18(%rbx)
 101ee09:	mov    %rsi,(%rax)
 101ee0c:	mov    %rdx,0x8(%rax)
 101ee10:	mov    %rcx,0x10(%rax)
 101ee14:	movq   $0x0,0x18(%rax)
 101ee1c:	mov    0x18(%rbx),%rax
 101ee20:	jmp    101ee37 <visit+0xa7>
 101ee22:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101ee30:	dec    %rax
 101ee33:	mov    %rax,0x18(%rbx)
 101ee37:	test   %rax,%rax
 101ee3a:	je     101f06d <visit+0x2dd>
 101ee40:	mov    0x8(%rbx),%rcx
 101ee44:	mov    %rax,%rsi
 101ee47:	shl    $0x5,%rsi
 101ee4b:	lea    (%rcx,%rsi,1),%rdx
 101ee4f:	mov    -0x20(%rcx,%rsi,1),%rsi
 101ee54:	mov    0x8(%rsi),%ecx
 101ee57:	cmp    $0x5,%ecx
 101ee5a:	je     101ee66 <visit+0xd6>
 101ee5c:	cmp    $0x3,%ecx
 101ee5f:	je     101ee90 <visit+0x100>
 101ee61:	cmp    $0x1,%ecx
 101ee64:	jne    101eeb0 <visit+0x120>
 101ee66:	mov    -0x18(%rdx),%rsi
 101ee6a:	mov    -0x10(%rdx),%rdx
 101ee6e:	mov    %rbx,%rdi
 101ee71:	call   *%r8
 101ee74:	test   %eax,%eax
 101ee76:	jne    101f07e <visit+0x2ee>
 101ee7c:	mov    0x18(%rbx),%rax
 101ee80:	dec    %rax
 101ee83:	mov    %rax,0x18(%rbx)
 101ee87:	mov    -0x38(%rbp),%r8
 101ee8b:	jmp    101ee37 <visit+0xa7>
 101ee8d:	nopl   (%rax)
 101ee90:	mov    -0x8(%rdx),%rcx
 101ee94:	cmp    0x18(%rsi),%rcx
 101ee98:	je     101ee30 <visit+0xa0>
 101ee9a:	lea    0x1(%rcx),%rdi
 101ee9e:	mov    %rdi,-0x8(%rdx)
 101eea2:	mov    0x10(%rsi),%r10
 101eea6:	cmpl   $0x0,0x8(%r10)
 101eeab:	jne    101ef09 <visit+0x179>
 101eead:	jmp    101ee37 <visit+0xa7>
 101eeaf:	nop
 101eeb0:	mov    -0x8(%rdx),%rdi
 101eeb4:	cmp    0x18(%rsi),%rdi
 101eeb8:	je     101ee30 <visit+0xa0>
 101eebe:	lea    (%rdi,%rdi,2),%r9
 101eec2:	shl    $0x3,%r9
 101eec6:	add    0x10(%rsi),%r9
 101eeca:	inc    %rdi
 101eecd:	mov    %rdi,-0x8(%rdx)
 101eed1:	mov    -0x10(%rdx),%rdi
 101eed5:	cmp    $0x4,%ecx
 101eed8:	jne    101eeeb <visit+0x15b>
 101eeda:	mov    0x20(%rsi),%rcx
 101eede:	mov    (%rdi,%rcx,1),%ecx
 101eee1:	cmp    0x10(%r9),%ecx
 101eee5:	jne    101ee37 <visit+0xa7>
 101eeeb:	mov    0x8(%r9),%r10
 101eeef:	cmpl   $0x0,0x8(%r10)
 101eef4:	je     101ee37 <visit+0xa7>
 101eefa:	cmp    0x10(%rbx),%rax
 101eefe:	jae    101f088 <visit+0x2f8>
 101ef04:	mov    (%r9),%rcx
 101ef07:	jmp    101ef1c <visit+0x18c>
 101ef09:	cmp    0x10(%rbx),%rax
 101ef0d:	jae    101f088 <visit+0x2f8>
 101ef13:	imul   0x20(%rsi),%rcx
 101ef18:	mov    -0x10(%rdx),%rdi
 101ef1c:	add    %rcx,%rdi
 101ef1f:	add    -0x18(%rdx),%rcx
 101ef23:	inc    %rax
 101ef26:	mov    %rax,0x18(%rbx)
 101ef2a:	mov    %r10,(%rdx)
 101ef2d:	mov    %rcx,0x8(%rdx)
 101ef31:	mov    %rdi,0x10(%rdx)
 101ef35:	movq   $0x0,0x18(%rdx)
 101ef3d:	jmp    101ee1c <visit+0x8c>
 101ef42:	lea    -0x1(%r13),%eax
 101ef46:	cmp    $0x3,%eax
 101ef49:	mov    %rcx,-0x58(%rbp)
 101ef4d:	mov    %rdx,-0x50(%rbp)
 101ef51:	ja     101efb4 <visit+0x224>
 101ef53:	jmp    *0x1001bc8(,%rax,8)
 101ef5a:	mov    $0x1,%r13d
 101ef60:	mov    $0x1,%edx
 101ef65:	jmp    101efb6 <visit+0x226>
 101ef67:	mov    0x10(%rsi),%rax
 101ef6b:	mov    0x18(%rsi),%rdx
 101ef6f:	mov    0x20(%rsi),%rcx
 101ef73:	mov    %rcx,-0x30(%rbp)
 101ef77:	mov    0x8(%rax),%r13d
 101ef7b:	jmp    101efbe <visit+0x22e>
 101ef7d:	mov    0x10(%rsi),%rdi
 101ef81:	mov    0x18(%rsi),%rdx
 101ef85:	mov    0x20(%rsi),%r12
 101ef89:	add    %rcx,%r12
 101ef8c:	mov    $0x4,%r13d
 101ef92:	movq   $0x0,-0x30(%rbp)
 101ef9a:	jmp    101efc3 <visit+0x233>
 101ef9c:	mov    0x10(%rsi),%rdi
 101efa0:	mov    0x18(%rsi),%rdx
 101efa4:	mov    $0x2,%r13d
 101efaa:	movq   $0x0,-0x30(%rbp)
 101efb2:	jmp    101efc0 <visit+0x230>
 101efb4:	xor    %edx,%edx
 101efb6:	movq   $0x0,-0x30(%rbp)
 101efbe:	xor    %edi,%edi
 101efc0:	xor    %r12d,%r12d
 101efc3:	mov    %rdx,%r15
 101efc6:	neg    %r15
 101efc9:	xor    %r14d,%r14d
 101efcc:	mov    %rdx,-0x48(%rbp)
 101efd0:	mov    %rdi,-0x40(%rbp)
 101efd4:	test   %rdi,%rdi
 101efd7:	je     101f032 <visit+0x2a2>
 101efd9:	xor    %eax,%eax
 101efdb:	cmp    %rdx,%r14
 101efde:	mov    -0x38(%rbp),%r8
 101efe2:	jae    101f06f <visit+0x2df>
 101efe8:	lea    (%r14,%r14,2),%rax
 101efec:	lea    (%rdi,%rax,8),%rax
 101eff0:	inc    %r14
 101eff3:	jmp    101f014 <visit+0x284>
 101eff5:	data16 cs nopw 0x0(%rax,%rax,1)
 101f000:	add    $0x18,%rax
 101f004:	lea    (%r15,%r14,1),%rcx
 101f008:	inc    %rcx
 101f00b:	inc    %r14
 101f00e:	cmp    $0x1,%rcx
 101f012:	je     101f06d <visit+0x2dd>
 101f014:	mov    0x8(%rax),%rcx
 101f018:	mov    0x8(%rcx),%ecx
 101f01b:	test   %ecx,%ecx
 101f01d:	je     101f000 <visit+0x270>
 101f01f:	test   %r12,%r12
 101f022:	je     101f02d <visit+0x29d>
 101f024:	mov    0x10(%rax),%edx
 101f027:	cmp    (%r12),%edx
 101f02b:	jne    101f000 <visit+0x270>
 101f02d:	mov    (%rax),%rdx
 101f030:	jmp    101f049 <visit+0x2b9>
 101f032:	cmp    %rdx,%r14
 101f035:	mov    -0x38(%rbp),%r8
 101f039:	je     101f06d <visit+0x2dd>
 101f03b:	mov    %r14,%rdx
 101f03e:	inc    %r14
 101f041:	imul   -0x30(%rbp),%rdx
 101f046:	mov    %r13d,%ecx
 101f049:	mov    -0x50(%rbp),%rax
 101f04d:	lea    (%rax,%rdx,1),%rsi
 101f051:	add    -0x58(%rbp),%rdx
 101f055:	mov    %rbx,%rdi
 101f058:	call   *%r8
 101f05b:	test   %eax,%eax
 101f05d:	mov    -0x48(%rbp),%rdx
 101f061:	mov    -0x40(%rbp),%rdi
 101f065:	je     101efd4 <visit+0x244>
 101f06b:	jmp    101f06f <visit+0x2df>
 101f06d:	xor    %eax,%eax
 101f06f:	add    $0x38,%rsp
 101f073:	pop    %rbx
 101f074:	pop    %r12
 101f076:	pop    %r13
 101f078:	pop    %r14
 101f07a:	pop    %r15
 101f07c:	pop    %rbp
 101f07d:	ret
 101f07e:	movq   $0x0,0x18(%rbx)
 101f086:	jmp    101f06f <visit+0x2df>
 101f088:	call   10187d4 <myl_rc_invariant_failed>
 101f08d:	int3
 101f08e:	int3
 101f08f:	int3

000000000101f090 <schedule_clone>:
 101f090:	push   %rbp
 101f091:	mov    %rsp,%rbp
 101f094:	push   %r15
 101f096:	push   %r14
 101f098:	push   %r13
 101f09a:	push   %r12
 101f09c:	push   %rbx
 101f09d:	sub    $0x68,%rsp
 101f0a1:	mov    %rcx,%r10
 101f0a4:	movq   $0x0,(%rcx)
 101f0ab:	mov    0x28(%rdi),%r12
 101f0af:	cmpl   $0x0,0xac(%r12)
 101f0b8:	je     101f109 <schedule_clone+0x79>
 101f0ba:	test   %rsi,%rsi
 101f0bd:	je     101f109 <schedule_clone+0x79>
 101f0bf:	mov    -0x8(%rsi),%rax
 101f0c3:	cmp    $0x100b618,%rax
 101f0ca:	sete   %cl
 101f0cd:	cmp    $0x100b510,%rax
 101f0d4:	sete   %r8b
 101f0d8:	or     %cl,%r8b
 101f0db:	cmp    $0x100b4a0,%rax
 101f0e2:	sete   %al
 101f0e5:	or     %r8b,%al
 101f0e8:	je     101f109 <schedule_clone+0x79>
 101f0ea:	xor    %r11d,%r11d
 101f0ed:	mov    (%rdi),%rbx
 101f0f0:	mov    0x1608(%rbx),%rax
 101f0f7:	cmpb   $0x0,0x120(%rax)
 101f0fe:	jne    101f598 <schedule_clone+0x508>
 101f104:	jmp    101f24f <schedule_clone+0x1bf>
 101f109:	mov    0xa0(%r12),%r13
 101f111:	test   %r13,%r13
 101f114:	je     101f1db <schedule_clone+0x14b>
 101f11a:	mov    0x30(%r12),%rax
 101f11f:	mov    %rsi,%rcx
 101f122:	shr    $0x4,%rcx
 101f126:	mov    %edx,%r8d
 101f129:	movabs $0x9e3779b97f4a7c15,%r9
 101f133:	imul   %r8,%r9
 101f137:	xor    %rcx,%r9
 101f13a:	mov    %r9,%rcx
 101f13d:	shr    $0x1e,%rcx
 101f141:	xor    %r9,%rcx
 101f144:	movabs $0xbf58476d1ce4e5b9,%r8
 101f14e:	imul   %rcx,%r8
 101f152:	mov    %r8,%rcx
 101f155:	shr    $0x1b,%rcx
 101f159:	xor    %r8,%rcx
 101f15c:	movabs $0x94d049bb133111eb,%r9
 101f166:	imul   %rcx,%r9
 101f16a:	mov    %r9,%r8
 101f16d:	shr    $0x1f,%r8
 101f171:	xor    %r9,%r8
 101f174:	lea    -0x1(%r13),%r9
 101f178:	jmp    101f183 <schedule_clone+0xf3>
 101f17a:	nopw   0x0(%rax,%rax,1)
 101f180:	inc    %r8
 101f183:	and    %r9,%r8
 101f186:	lea    (%r8,%r8,2),%rcx
 101f18a:	mov    (%rax,%rcx,8),%rcx
 101f18e:	test   %rcx,%rcx
 101f191:	je     101f1a2 <schedule_clone+0x112>
 101f193:	cmp    %rsi,%rcx
 101f196:	jne    101f180 <schedule_clone+0xf0>
 101f198:	lea    (%r8,%r8,2),%rcx
 101f19c:	cmp    %edx,0x10(%rax,%rcx,8)
 101f1a0:	jne    101f180 <schedule_clone+0xf0>
 101f1a2:	lea    (%r8,%r8,2),%rcx
 101f1a6:	lea    (%rax,%rcx,8),%rax
 101f1aa:	mov    0x8(%rax),%rax
 101f1ae:	test   %rax,%rax
 101f1b1:	je     101f215 <schedule_clone+0x185>
 101f1b3:	mov    -0x10(%rax),%rsi
 101f1b7:	movabs $0x4000000000000000,%rcx
 101f1c1:	or     $0x2,%rcx
 101f1c5:	test   %rcx,%rsi
 101f1c8:	je     101f2b8 <schedule_clone+0x228>
 101f1ce:	test   %edx,%edx
 101f1d0:	jne    101f2eb <schedule_clone+0x25b>
 101f1d6:	jmp    101f30a <schedule_clone+0x27a>
 101f1db:	mov    0x98(%r12),%r15
 101f1e3:	test   %r15,%r15
 101f1e6:	je     101f57e <schedule_clone+0x4ee>
 101f1ec:	lea    0x38(%r12),%rax
 101f1f1:	mov    %r15,%r8
 101f1f4:	jmp    101f209 <schedule_clone+0x179>
 101f1f6:	cs nopw 0x0(%rax,%rax,1)
 101f200:	add    $0x18,%rax
 101f204:	dec    %r8
 101f207:	je     101f21d <schedule_clone+0x18d>
 101f209:	cmp    %rsi,(%rax)
 101f20c:	jne    101f200 <schedule_clone+0x170>
 101f20e:	cmp    %edx,0x10(%rax)
 101f211:	jne    101f200 <schedule_clone+0x170>
 101f213:	jmp    101f1aa <schedule_clone+0x11a>
 101f215:	mov    0x98(%r12),%r15
 101f21d:	test   %r13,%r13
 101f220:	je     101f314 <schedule_clone+0x284>
 101f226:	mov    %r13,%rax
 101f229:	shr    $1,%rax
 101f22c:	mov    $0x1,%r11b
 101f22f:	cmp    %rax,%r15
 101f232:	jae    101f321 <schedule_clone+0x291>
 101f238:	mov    (%rdi),%rbx
 101f23b:	mov    0x1608(%rbx),%rax
 101f242:	cmpb   $0x0,0x120(%rax)
 101f249:	jne    101f598 <schedule_clone+0x508>
 101f24f:	cmpq   $0x100b618,-0x8(%rsi)
 101f257:	jne    101f598 <schedule_clone+0x508>
 101f25d:	mov    %r11d,-0x50(%rbp)
 101f261:	mov    %rdi,%r14
 101f264:	mov    %rsi,-0x40(%rbp)
 101f268:	mov    %edx,%r15d
 101f26b:	mov    %r10,%r13
 101f26e:	mov    $0x100b3e0,%esi
 101f273:	mov    %rbx,%rdi
 101f276:	call   1019580 <myl_rc_module_register>
 101f27b:	mov    %eax,%ecx
 101f27d:	mov    $0x1,%eax
 101f282:	test   %ecx,%ecx
 101f284:	jne    101f976 <schedule_clone+0x8e6>
 101f28a:	mov    0x1608(%rbx),%rax
 101f291:	movb   $0x1,0x120(%rax)
 101f298:	mov    %r14,%rdi
 101f29b:	mov    (%r14),%rax
 101f29e:	mov    0x1608(%rax),%rax
 101f2a5:	mov    %r13,%r10
 101f2a8:	mov    %r15d,%edx
 101f2ab:	mov    -0x40(%rbp),%rsi
 101f2af:	mov    -0x50(%rbp),%r11d
 101f2b3:	jmp    101f598 <schedule_clone+0x508>
 101f2b8:	test   $0x1,%sil
 101f2bc:	jne    101fca4 <schedule_clone+0xc14>
 101f2c2:	mov    -0x20(%rax),%rcx
 101f2c6:	cmp    $0xffffffffffffffff,%rcx
 101f2ca:	je     101f408 <schedule_clone+0x378>
 101f2d0:	test   %rcx,%rcx
 101f2d3:	jne    101f2e0 <schedule_clone+0x250>
 101f2d5:	cmpq   $0x0,-0x18(%rax)
 101f2da:	je     101fca4 <schedule_clone+0xc14>
 101f2e0:	inc    %rcx
 101f2e3:	mov    %rcx,-0x20(%rax)
 101f2e7:	test   %edx,%edx
 101f2e9:	je     101f30a <schedule_clone+0x27a>
 101f2eb:	cmpl   $0x0,0xac(%r12)
 101f2f4:	jne    101f30a <schedule_clone+0x27a>
 101f2f6:	movabs $0x1fffffffffffffff,%rcx
 101f300:	inc    %rcx
 101f303:	or     %rcx,%rsi
 101f306:	mov    %rsi,-0x10(%rax)
 101f30a:	mov    %rax,(%r10)
 101f30d:	xor    %eax,%eax
 101f30f:	jmp    101f976 <schedule_clone+0x8e6>
 101f314:	mov    $0x1,%r11b
 101f317:	cmp    $0x4,%r15
 101f31b:	jb     101f238 <schedule_clone+0x1a8>
 101f321:	lea    0x0(,%r13,2),%rax
 101f329:	test   %r13,%r13
 101f32c:	mov    $0x20,%r8d
 101f332:	cmovne %rax,%r8
 101f336:	mov    $0x1,%eax
 101f33b:	cmp    %r13,%r8
 101f33e:	jb     101f976 <schedule_clone+0x8e6>
 101f344:	mov    %edx,-0x2c(%rbp)
 101f347:	mov    $0x18,%ecx
 101f34c:	mov    %r8,%rax
 101f34f:	mul    %rcx
 101f352:	jo     101f6b3 <schedule_clone+0x623>
 101f358:	mov    (%rdi),%rdx
 101f35b:	test   %rdx,%rdx
 101f35e:	je     101fca4 <schedule_clone+0xc14>
 101f364:	test   %rax,%rax
 101f367:	je     101fca4 <schedule_clone+0xc14>
 101f36d:	mov    0x1608(%rdx),%r11
 101f374:	test   %r11,%r11
 101f377:	je     101fca4 <schedule_clone+0xc14>
 101f37d:	mov    0x18(%rdx),%rbx
 101f381:	mov    %rax,%r9
 101f384:	add    %rax,%rbx
 101f387:	mov    $0x1,%eax
 101f38c:	jb     101f96f <schedule_clone+0x8df>
 101f392:	mov    0x58(%rdx),%rcx
 101f396:	test   %rcx,%rcx
 101f399:	je     101f3a4 <schedule_clone+0x314>
 101f39b:	cmp    %rcx,%rbx
 101f39e:	ja     101f96f <schedule_clone+0x8df>
 101f3a4:	mov    %r11,-0x38(%rbp)
 101f3a8:	mov    %rdx,-0x58(%rbp)
 101f3ac:	mov    %r8,-0x70(%rbp)
 101f3b0:	mov    %rdi,-0x48(%rbp)
 101f3b4:	mov    %rsi,-0x40(%rbp)
 101f3b8:	mov    %r10,-0x60(%rbp)
 101f3bc:	mov    $0x1,%edi
 101f3c1:	mov    %r9,%rsi
 101f3c4:	mov    %r9,-0x50(%rbp)
 101f3c8:	call   1027510 <calloc@plt>
 101f3cd:	mov    %rax,%r14
 101f3d0:	mov    $0x1,%eax
 101f3d5:	test   %r14,%r14
 101f3d8:	je     101f976 <schedule_clone+0x8e6>
 101f3de:	mov    -0x58(%rbp),%r9
 101f3e2:	mov    %rbx,0x18(%r9)
 101f3e6:	mov    -0x38(%rbp),%rax
 101f3ea:	mov    -0x50(%rbp),%rcx
 101f3ee:	add    %rcx,0x30(%rax)
 101f3f2:	test   %r13,%r13
 101f3f5:	je     101f412 <schedule_clone+0x382>
 101f3f7:	mov    0x30(%r12),%rcx
 101f3fc:	mov    %r13,%r15
 101f3ff:	mov    -0x2c(%rbp),%edx
 101f402:	mov    -0x40(%rbp),%rsi
 101f406:	jmp    101f42b <schedule_clone+0x39b>
 101f408:	mov    $0x2,%eax
 101f40d:	jmp    101f976 <schedule_clone+0x8e6>
 101f412:	test   %r15,%r15
 101f415:	mov    -0x60(%rbp),%r10
 101f419:	mov    -0x2c(%rbp),%edx
 101f41c:	mov    -0x40(%rbp),%rsi
 101f420:	je     101fc61 <schedule_clone+0xbd1>
 101f426:	lea    0x38(%r12),%rcx
 101f42b:	mov    -0x70(%rbp),%rax
 101f42f:	lea    -0x1(%rax),%r11
 101f433:	xor    %r8d,%r8d
 101f436:	mov    -0x48(%rbp),%rdi
 101f43a:	mov    %rcx,-0x50(%rbp)
 101f43e:	jmp    101f46c <schedule_clone+0x3dc>
 101f440:	lea    (%rbx,%rbx,2),%rax
 101f444:	mov    -0x38(%rbp),%r9
 101f448:	mov    0x10(%r9),%rcx
 101f44c:	mov    %rcx,0x10(%r14,%rax,8)
 101f451:	vmovups (%r9),%xmm0
 101f456:	vmovups %xmm0,(%r14,%rax,8)
 101f45c:	mov    -0x50(%rbp),%rcx
 101f460:	inc    %r8
 101f463:	cmp    %r15,%r8
 101f466:	je     101f50c <schedule_clone+0x47c>
 101f46c:	lea    (%r8,%r8,2),%rax
 101f470:	mov    (%rcx,%rax,8),%r10
 101f474:	test   %r10,%r10
 101f477:	je     101f460 <schedule_clone+0x3d0>
 101f479:	lea    (%rcx,%rax,8),%rax
 101f47d:	mov    %rax,-0x38(%rbp)
 101f481:	mov    0x10(%rax),%eax
 101f484:	mov    %r10,%r9
 101f487:	shr    $0x4,%r9
 101f48b:	mov    %rax,%rbx
 101f48e:	movabs $0x9e3779b97f4a7c15,%rcx
 101f498:	imul   %rcx,%rbx
 101f49c:	xor    %r9,%rbx
 101f49f:	mov    %rbx,%r9
 101f4a2:	shr    $0x1e,%r9
 101f4a6:	xor    %rbx,%r9
 101f4a9:	movabs $0xbf58476d1ce4e5b9,%rcx
 101f4b3:	imul   %rcx,%r9
 101f4b7:	mov    %r9,%rcx
 101f4ba:	shr    $0x1b,%rcx
 101f4be:	xor    %r9,%rcx
 101f4c1:	movabs $0x94d049bb133111eb,%r9
 101f4cb:	imul   %r9,%rcx
 101f4cf:	mov    %rcx,%rbx
 101f4d2:	shr    $0x1f,%rbx
 101f4d6:	xor    %rcx,%rbx
 101f4d9:	jmp    101f4e3 <schedule_clone+0x453>
 101f4db:	nopl   0x0(%rax,%rax,1)
 101f4e0:	inc    %rbx
 101f4e3:	and    %r11,%rbx
 101f4e6:	lea    (%rbx,%rbx,2),%rcx
 101f4ea:	mov    (%r14,%rcx,8),%r9
 101f4ee:	test   %r9,%r9
 101f4f1:	je     101f440 <schedule_clone+0x3b0>
 101f4f7:	cmp    %r10,%r9
 101f4fa:	jne    101f4e0 <schedule_clone+0x450>
 101f4fc:	lea    (%rbx,%rbx,2),%rcx
 101f500:	cmp    %eax,0x10(%r14,%rcx,8)
 101f505:	jne    101f4e0 <schedule_clone+0x450>
 101f507:	jmp    101f440 <schedule_clone+0x3b0>
 101f50c:	shl    $0x3,%r13
 101f510:	lea    0x0(,%r13,2),%r8
 101f518:	add    %r13,%r8
 101f51b:	mov    -0x60(%rbp),%r10
 101f51f:	mov    -0x58(%rbp),%r9
 101f523:	mov    0x30(%r12),%rax
 101f528:	test   %rax,%rax
 101f52b:	je     101f56d <schedule_clone+0x4dd>
 101f52d:	mov    0x18(%r9),%rcx
 101f531:	sub    %r8,%rcx
 101f534:	jb     101fca4 <schedule_clone+0xc14>
 101f53a:	mov    0x1608(%r9),%rdx
 101f541:	mov    0x30(%rdx),%rsi
 101f545:	sub    %r8,%rsi
 101f548:	jb     101fca4 <schedule_clone+0xc14>
 101f54e:	mov    %rcx,0x18(%r9)
 101f552:	mov    %rsi,0x30(%rdx)
 101f556:	mov    %rax,%rdi
 101f559:	call   1027570 <free@plt>
 101f55e:	mov    -0x60(%rbp),%r10
 101f562:	mov    -0x2c(%rbp),%edx
 101f565:	mov    -0x40(%rbp),%rsi
 101f569:	mov    -0x48(%rbp),%rdi
 101f56d:	mov    %r14,0x30(%r12)
 101f572:	mov    -0x70(%rbp),%rax
 101f576:	mov    %rax,0xa0(%r12)
 101f57e:	mov    $0x1,%r11b
 101f581:	mov    (%rdi),%rbx
 101f584:	mov    0x1608(%rbx),%rax
 101f58b:	cmpb   $0x0,0x120(%rax)
 101f592:	je     101f24f <schedule_clone+0x1bf>
 101f598:	mov    -0x8(%rsi),%r8
 101f59c:	mov    0x34(%r8),%ecx
 101f5a0:	cmp    %rcx,0xa0(%rax)
 101f5a7:	jbe    101fc7b <schedule_clone+0xbeb>
 101f5ad:	mov    0x98(%rax),%r9
 101f5b4:	shl    $0x4,%rcx
 101f5b8:	cmp    %r8,(%r9,%rcx,1)
 101f5bc:	jne    101fc7b <schedule_clone+0xbeb>
 101f5c2:	add    %rcx,%r9
 101f5c5:	mov    0x8(%r9),%rbx
 101f5c9:	test   %rbx,%rbx
 101f5cc:	je     101fca4 <schedule_clone+0xc14>
 101f5d2:	cmpq   $0x0,0x18(%rbx)
 101f5d7:	jne    101fca4 <schedule_clone+0xc14>
 101f5dd:	cmpq   $0x0,0x28(%rbx)
 101f5e2:	je     101f5f4 <schedule_clone+0x564>
 101f5e4:	cmpq   $0x0,0x30(%rbx)
 101f5e9:	jne    101f610 <schedule_clone+0x580>
 101f5eb:	xor    %r8d,%r8d
 101f5ee:	test   %edx,%edx
 101f5f0:	jne    101f633 <schedule_clone+0x5a3>
 101f5f2:	jmp    101f64c <schedule_clone+0x5bc>
 101f5f4:	cmpq   $0x0,0x10(%rbx)
 101f5f9:	jne    101fca4 <schedule_clone+0xc14>
 101f5ff:	cmpq   $0x0,0x30(%rbx)
 101f604:	jne    101f610 <schedule_clone+0x580>
 101f606:	mov    0x8(%rbx),%rax
 101f60a:	cmpl   $0x0,0x8(%rax)
 101f60e:	je     101f5eb <schedule_clone+0x55b>
 101f610:	mov    (%r12),%r14
 101f614:	mov    0x8(%r12),%r13
 101f619:	mov    0x10(%r12),%rcx
 101f61e:	cmp    %rcx,%r13
 101f621:	jae    101f680 <schedule_clone+0x5f0>
 101f623:	mov    $0x1,%r8b
 101f626:	test   %r14,%r14
 101f629:	je     101f6b3 <schedule_clone+0x623>
 101f62f:	test   %edx,%edx
 101f631:	je     101f64c <schedule_clone+0x5bc>
 101f633:	mov    0x18(%r12),%r9
 101f638:	mov    0x20(%r12),%r15
 101f63d:	mov    0x28(%r12),%rax
 101f642:	cmp    %rax,%r15
 101f645:	jae    101f6bd <schedule_clone+0x62d>
 101f647:	test   %r9,%r9
 101f64a:	je     101f6b3 <schedule_clone+0x623>
 101f64c:	mov    %r8d,-0x38(%rbp)
 101f650:	mov    %r11d,%r15d
 101f653:	movq   $0x0,-0x68(%rbp)
 101f65b:	mov    0x28(%rbx),%r8
 101f65f:	test   %r8,%r8
 101f662:	mov    %edx,-0x2c(%rbp)
 101f665:	je     101f753 <schedule_clone+0x6c3>
 101f66b:	mov    (%rdi),%rdi
 101f66e:	lea    -0x68(%rbp),%rcx
 101f672:	mov    %rsi,%r14
 101f675:	mov    %r10,%r13
 101f678:	call   *%r8
 101f67b:	jmp    101f7e4 <schedule_clone+0x754>
 101f680:	lea    (%rcx,%rcx,1),%rax
 101f684:	test   %rcx,%rcx
 101f687:	mov    $0x10,%r15d
 101f68d:	cmovne %rax,%r15
 101f691:	mov    $0x1,%eax
 101f696:	cmp    %rcx,%r15
 101f699:	jb     101f976 <schedule_clone+0x8e6>
 101f69f:	mov    %edx,-0x2c(%rbp)
 101f6a2:	mov    $0x28,%ecx
 101f6a7:	mov    %r15,%rax
 101f6aa:	mul    %rcx
 101f6ad:	jno    101f91e <schedule_clone+0x88e>
 101f6b3:	mov    $0x1,%eax
 101f6b8:	jmp    101f976 <schedule_clone+0x8e6>
 101f6bd:	lea    (%rax,%rax,1),%rcx
 101f6c1:	test   %rax,%rax
 101f6c4:	mov    $0x10,%r13d
 101f6ca:	cmovne %rcx,%r13
 101f6ce:	cmp    %rax,%r13
 101f6d1:	setb   %al
 101f6d4:	mov    %r13,%rcx
 101f6d7:	shr    $0x3d,%rcx
 101f6db:	setne  %cl
 101f6de:	or     %al,%cl
 101f6e0:	mov    $0x1,%eax
 101f6e5:	jne    101f976 <schedule_clone+0x8e6>
 101f6eb:	mov    %r9,-0x58(%rbp)
 101f6ef:	mov    (%rdi),%rcx
 101f6f2:	test   %rcx,%rcx
 101f6f5:	je     101fca4 <schedule_clone+0xc14>
 101f6fb:	test   %r13,%r13
 101f6fe:	je     101fca4 <schedule_clone+0xc14>
 101f704:	mov    0x1608(%rcx),%r14
 101f70b:	mov    %r14,-0x70(%rbp)
 101f70f:	test   %r14,%r14
 101f712:	je     101fca4 <schedule_clone+0xc14>
 101f718:	mov    0x18(%rcx),%r9
 101f71c:	lea    0x0(,%r13,8),%r14
 101f724:	add    %r14,%r9
 101f727:	jb     101f747 <schedule_clone+0x6b7>
 101f729:	mov    %r9,%r14
 101f72c:	mov    0x58(%rcx),%r9
 101f730:	mov    %r9,-0x40(%rbp)
 101f734:	test   %r9,%r9
 101f737:	je     101faff <schedule_clone+0xa6f>
 101f73d:	cmp    -0x40(%rbp),%r14
 101f741:	jbe    101faff <schedule_clone+0xa6f>
 101f747:	movl   $0x1,0x6c(%rcx)
 101f74e:	jmp    101f976 <schedule_clone+0x8e6>
 101f753:	mov    %r10,%r13
 101f756:	movabs $0x3ffffffffffffff,%r8
 101f760:	movabs $0x3fffffffff,%r10
 101f76a:	mov    -0x8(%rsi),%r14
 101f76e:	mov    %r14,-0x90(%rbp)
 101f775:	mov    -0x10(%rsi),%rax
 101f779:	mov    %rax,%rcx
 101f77c:	shr    $0x2,%rcx
 101f780:	bt     $0x3e,%rax
 101f785:	mov    %r10,%r9
 101f788:	cmovae %r8,%r9
 101f78c:	and    %rcx,%r9
 101f78f:	mov    %r9,-0x88(%rbp)
 101f796:	mov    %edx,-0x80(%rbp)
 101f799:	movl   $0x0,-0x7c(%rbp)
 101f7a0:	mov    (%rdi),%r8
 101f7a3:	test   %r8,%r8
 101f7a6:	je     101fca4 <schedule_clone+0xc14>
 101f7ac:	mov    0x1608(%r8),%r11
 101f7b3:	test   %r11,%r11
 101f7b6:	je     101fca4 <schedule_clone+0xc14>
 101f7bc:	movq   $0x0,-0x68(%rbp)
 101f7c4:	test   %r14,%r14
 101f7c7:	je     101fca4 <schedule_clone+0xc14>
 101f7cd:	mov    %r9,%rax
 101f7d0:	mulq   (%r14)
 101f7d3:	mov    %rax,%rdx
 101f7d6:	mov    $0x1,%eax
 101f7db:	mov    %rsi,%r14
 101f7de:	jno    101f985 <schedule_clone+0x8f5>
 101f7e4:	test   %eax,%eax
 101f7e6:	jne    101f976 <schedule_clone+0x8e6>
 101f7ec:	mov    -0x68(%rbp),%rax
 101f7f0:	test   %rax,%rax
 101f7f3:	je     101fca4 <schedule_clone+0xc14>
 101f7f9:	test   %r15b,%r15b
 101f7fc:	mov    -0x2c(%rbp),%edx
 101f7ff:	mov    -0x38(%rbp),%r9d
 101f803:	je     101f8cb <schedule_clone+0x83b>
 101f809:	mov    0xa0(%r12),%rdi
 101f811:	test   %rdi,%rdi
 101f814:	je     101fae6 <schedule_clone+0xa56>
 101f81a:	mov    0x30(%r12),%rsi
 101f81f:	mov    %r14,%rcx
 101f822:	shr    $0x4,%rcx
 101f826:	mov    %edx,%r8d
 101f829:	movabs $0x9e3779b97f4a7c15,%r9
 101f833:	imul   %r8,%r9
 101f837:	xor    %rcx,%r9
 101f83a:	mov    %r9,%rcx
 101f83d:	shr    $0x1e,%rcx
 101f841:	xor    %r9,%rcx
 101f844:	movabs $0xbf58476d1ce4e5b9,%r8
 101f84e:	imul   %rcx,%r8
 101f852:	mov    %r8,%rcx
 101f855:	shr    $0x1b,%rcx
 101f859:	xor    %r8,%rcx
 101f85c:	movabs $0x94d049bb133111eb,%r9
 101f866:	imul   %rcx,%r9
 101f86a:	mov    %r9,%r8
 101f86d:	shr    $0x1f,%r8
 101f871:	xor    %r9,%r8
 101f874:	dec    %rdi
 101f877:	and    %rdi,%r8
 101f87a:	lea    (%r8,%r8,2),%rcx
 101f87e:	mov    (%rsi,%rcx,8),%rcx
 101f882:	test   %rcx,%rcx
 101f885:	je     101fbe5 <schedule_clone+0xb55>
 101f88b:	mov    -0x38(%rbp),%r9d
 101f88f:	jmp    101f8b7 <schedule_clone+0x827>
 101f891:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101f8a0:	inc    %r8
 101f8a3:	and    %rdi,%r8
 101f8a6:	lea    (%r8,%r8,2),%rcx
 101f8aa:	mov    (%rsi,%rcx,8),%rcx
 101f8ae:	test   %rcx,%rcx
 101f8b1:	je     101fbe9 <schedule_clone+0xb59>
 101f8b7:	cmp    %r14,%rcx
 101f8ba:	jne    101f8a0 <schedule_clone+0x810>
 101f8bc:	lea    (%r8,%r8,2),%rcx
 101f8c0:	cmp    %edx,0x10(%rsi,%rcx,8)
 101f8c4:	jne    101f8a0 <schedule_clone+0x810>
 101f8c6:	jmp    101fbe9 <schedule_clone+0xb59>
 101f8cb:	test   %r9b,%r9b
 101f8ce:	je     101fc17 <schedule_clone+0xb87>
 101f8d4:	mov    (%r12),%rcx
 101f8d8:	mov    0x8(%r12),%rsi
 101f8dd:	lea    0x1(%rsi),%rdi
 101f8e1:	mov    %rdi,0x8(%r12)
 101f8e6:	lea    (%rsi,%rsi,4),%rsi
 101f8ea:	mov    %r14,(%rcx,%rsi,8)
 101f8ee:	mov    %rax,0x8(%rcx,%rsi,8)
 101f8f3:	mov    %rbx,0x10(%rcx,%rsi,8)
 101f8f8:	movq   $0x0,0x18(%rcx,%rsi,8)
 101f901:	mov    %edx,0x20(%rcx,%rsi,8)
 101f905:	movl   $0x0,0x24(%rcx,%rsi,8)
 101f90d:	mov    -0x68(%rbp),%rax
 101f911:	test   %edx,%edx
 101f913:	jne    101fc1b <schedule_clone+0xb8b>
 101f919:	jmp    101fc32 <schedule_clone+0xba2>
 101f91e:	mov    (%rdi),%rdx
 101f921:	test   %rdx,%rdx
 101f924:	je     101fca4 <schedule_clone+0xc14>
 101f92a:	test   %rax,%rax
 101f92d:	je     101fca4 <schedule_clone+0xc14>
 101f933:	mov    0x1608(%rdx),%r9
 101f93a:	test   %r9,%r9
 101f93d:	je     101fca4 <schedule_clone+0xc14>
 101f943:	mov    0x18(%rdx),%rcx
 101f947:	mov    %rax,%r8
 101f94a:	add    %rax,%rcx
 101f94d:	mov    %rcx,-0x38(%rbp)
 101f951:	mov    $0x1,%eax
 101f956:	jb     101f96f <schedule_clone+0x8df>
 101f958:	mov    0x58(%rdx),%rcx
 101f95c:	test   %rcx,%rcx
 101f95f:	je     101f9f6 <schedule_clone+0x966>
 101f965:	cmp    %rcx,-0x38(%rbp)
 101f969:	jbe    101f9f6 <schedule_clone+0x966>
 101f96f:	movl   $0x1,0x6c(%rdx)
 101f976:	add    $0x68,%rsp
 101f97a:	pop    %rbx
 101f97b:	pop    %r12
 101f97d:	pop    %r13
 101f97f:	pop    %r14
 101f981:	pop    %r15
 101f983:	pop    %rbp
 101f984:	ret
 101f985:	xor    %ecx,%ecx
 101f987:	cmpl   $0x0,-0x2c(%rbp)
 101f98b:	movabs $0x3ffffffffffffff,%rsi
 101f995:	cmove  %rsi,%r10
 101f999:	sete   %cl
 101f99c:	shl    $0x4,%ecx
 101f99f:	add    $0x10,%rcx
 101f9a3:	add    %rcx,%rdx
 101f9a6:	jb     101f7e4 <schedule_clone+0x754>
 101f9ac:	cmp    %r10,%r9
 101f9af:	ja     101f7e4 <schedule_clone+0x754>
 101f9b5:	mov    $0x3,%eax
 101f9ba:	mov    -0x2c(%rbp),%ecx
 101f9bd:	cmp    0x70(%r8),%ecx
 101f9c1:	ja     101f7e4 <schedule_clone+0x754>
 101f9c7:	mov    %rdi,-0x48(%rbp)
 101f9cb:	lea    -0x90(%rbp),%rsi
 101f9d2:	lea    -0x68(%rbp),%rdx
 101f9d6:	mov    %r8,%rdi
 101f9d9:	call   *(%r11)
 101f9dc:	mov    -0x68(%rbp),%rdx
 101f9e0:	test   %eax,%eax
 101f9e2:	je     101fc3b <schedule_clone+0xbab>
 101f9e8:	test   %rdx,%rdx
 101f9eb:	je     101f7e4 <schedule_clone+0x754>
 101f9f1:	jmp    101fca4 <schedule_clone+0xc14>
 101f9f6:	mov    %r9,-0x70(%rbp)
 101f9fa:	mov    %rdx,-0x58(%rbp)
 101f9fe:	mov    %r11d,-0x50(%rbp)
 101fa02:	mov    %rdi,-0x48(%rbp)
 101fa06:	mov    %rsi,-0x40(%rbp)
 101fa0a:	mov    %r10,-0x60(%rbp)
 101fa0e:	mov    $0x1,%edi
 101fa13:	mov    %r8,%rsi
 101fa16:	mov    %r8,-0x78(%rbp)
 101fa1a:	call   1027510 <calloc@plt>
 101fa1f:	mov    %rax,%rcx
 101fa22:	mov    $0x1,%eax
 101fa27:	test   %rcx,%rcx
 101fa2a:	je     101f976 <schedule_clone+0x8e6>
 101fa30:	mov    -0x58(%rbp),%rdi
 101fa34:	mov    -0x38(%rbp),%rax
 101fa38:	mov    %rax,0x18(%rdi)
 101fa3c:	mov    -0x70(%rbp),%rax
 101fa40:	mov    -0x78(%rbp),%rdx
 101fa44:	add    %rdx,0x30(%rax)
 101fa48:	test   %r13,%r13
 101fa4b:	je     101fa71 <schedule_clone+0x9e1>
 101fa4d:	shl    $0x3,%r13
 101fa51:	lea    0x0(,%r13,4),%rdx
 101fa59:	add    %r13,%rdx
 101fa5c:	mov    %rcx,%rdi
 101fa5f:	mov    %r14,%rsi
 101fa62:	mov    %rcx,%r13
 101fa65:	call   1027520 <memcpy@plt>
 101fa6a:	mov    %r13,%rcx
 101fa6d:	mov    -0x58(%rbp),%rdi
 101fa71:	test   %r14,%r14
 101fa74:	je     101faba <schedule_clone+0xa2a>
 101fa76:	mov    %rcx,%r13
 101fa79:	mov    0x10(%r12),%rax
 101fa7e:	shl    $0x3,%rax
 101fa82:	lea    (%rax,%rax,4),%rcx
 101fa86:	mov    0x18(%rdi),%rax
 101fa8a:	sub    %rcx,%rax
 101fa8d:	jb     101fca4 <schedule_clone+0xc14>
 101fa93:	mov    0x1608(%rdi),%rdx
 101fa9a:	mov    0x30(%rdx),%rsi
 101fa9e:	sub    %rcx,%rsi
 101faa1:	jb     101fca4 <schedule_clone+0xc14>
 101faa7:	mov    %rax,0x18(%rdi)
 101faab:	mov    %rsi,0x30(%rdx)
 101faaf:	mov    %r14,%rdi
 101fab2:	call   1027570 <free@plt>
 101fab7:	mov    %r13,%rcx
 101faba:	mov    %r15,0x10(%r12)
 101fabf:	mov    %rcx,(%r12)
 101fac3:	mov    $0x1,%r8b
 101fac6:	mov    -0x60(%rbp),%r10
 101faca:	mov    -0x2c(%rbp),%edx
 101facd:	mov    -0x40(%rbp),%rsi
 101fad1:	mov    -0x48(%rbp),%rdi
 101fad5:	mov    -0x50(%rbp),%r11d
 101fad9:	test   %edx,%edx
 101fadb:	jne    101f633 <schedule_clone+0x5a3>
 101fae1:	jmp    101f64c <schedule_clone+0x5bc>
 101fae6:	mov    0x98(%r12),%rcx
 101faee:	lea    (%rcx,%rcx,2),%rcx
 101faf2:	lea    (%r12,%rcx,8),%rcx
 101faf6:	add    $0x38,%rcx
 101fafa:	jmp    101fbf1 <schedule_clone+0xb61>
 101faff:	mov    %rcx,-0x78(%rbp)
 101fb03:	mov    %r8d,-0x38(%rbp)
 101fb07:	mov    %r11d,-0x50(%rbp)
 101fb0b:	mov    %rdi,-0x48(%rbp)
 101fb0f:	mov    %rsi,-0x40(%rbp)
 101fb13:	mov    %edx,-0x2c(%rbp)
 101fb16:	mov    %r10,-0x60(%rbp)
 101fb1a:	mov    $0x1,%edi
 101fb1f:	lea    0x0(,%r13,8),%rsi
 101fb27:	call   1027510 <calloc@plt>
 101fb2c:	mov    %rax,%rcx
 101fb2f:	mov    $0x1,%eax
 101fb34:	test   %rcx,%rcx
 101fb37:	je     101f976 <schedule_clone+0x8e6>
 101fb3d:	mov    -0x78(%rbp),%rax
 101fb41:	mov    %r14,0x18(%rax)
 101fb45:	mov    -0x70(%rbp),%rax
 101fb49:	lea    0x0(,%r13,8),%rdx
 101fb51:	add    %rdx,0x30(%rax)
 101fb55:	test   %r15,%r15
 101fb58:	mov    -0x58(%rbp),%r14
 101fb5c:	je     101fb76 <schedule_clone+0xae6>
 101fb5e:	shl    $0x3,%r15
 101fb62:	mov    %rcx,%rdi
 101fb65:	mov    %r14,%rsi
 101fb68:	mov    %r15,%rdx
 101fb6b:	mov    %rcx,%r15
 101fb6e:	call   1027520 <memcpy@plt>
 101fb73:	mov    %r15,%rcx
 101fb76:	test   %r14,%r14
 101fb79:	je     101fbbf <schedule_clone+0xb2f>
 101fb7b:	mov    %r14,%rdi
 101fb7e:	mov    %rcx,%r14
 101fb81:	mov    0x28(%r12),%rcx
 101fb86:	shl    $0x3,%rcx
 101fb8a:	mov    -0x78(%rbp),%r8
 101fb8e:	mov    0x18(%r8),%rax
 101fb92:	sub    %rcx,%rax
 101fb95:	jb     101fca4 <schedule_clone+0xc14>
 101fb9b:	mov    0x1608(%r8),%rdx
 101fba2:	mov    0x30(%rdx),%rsi
 101fba6:	sub    %rcx,%rsi
 101fba9:	jb     101fca4 <schedule_clone+0xc14>
 101fbaf:	mov    %rax,0x18(%r8)
 101fbb3:	mov    %rsi,0x30(%rdx)
 101fbb7:	call   1027570 <free@plt>
 101fbbc:	mov    %r14,%rcx
 101fbbf:	mov    %r13,0x28(%r12)
 101fbc4:	mov    %rcx,0x18(%r12)
 101fbc9:	mov    -0x60(%rbp),%r10
 101fbcd:	mov    -0x2c(%rbp),%edx
 101fbd0:	mov    -0x40(%rbp),%rsi
 101fbd4:	mov    -0x48(%rbp),%rdi
 101fbd8:	mov    -0x50(%rbp),%r11d
 101fbdc:	mov    -0x38(%rbp),%r8d
 101fbe0:	jmp    101f64c <schedule_clone+0x5bc>
 101fbe5:	mov    -0x38(%rbp),%r9d
 101fbe9:	lea    (%r8,%r8,2),%rcx
 101fbed:	lea    (%rsi,%rcx,8),%rcx
 101fbf1:	mov    %r14,(%rcx)
 101fbf4:	mov    %rax,0x8(%rcx)
 101fbf8:	mov    %edx,0x10(%rcx)
 101fbfb:	movl   $0x0,0x14(%rcx)
 101fc02:	incq   0x98(%r12)
 101fc0a:	mov    -0x68(%rbp),%rax
 101fc0e:	test   %r9b,%r9b
 101fc11:	jne    101f8d4 <schedule_clone+0x844>
 101fc17:	test   %edx,%edx
 101fc19:	je     101fc32 <schedule_clone+0xba2>
 101fc1b:	mov    0x18(%r12),%rcx
 101fc20:	mov    0x20(%r12),%rdx
 101fc25:	lea    0x1(%rdx),%rsi
 101fc29:	mov    %rsi,0x20(%r12)
 101fc2e:	mov    %rax,(%rcx,%rdx,8)
 101fc32:	mov    %rax,0x0(%r13)
 101fc36:	jmp    101f30d <schedule_clone+0x27d>
 101fc3b:	test   %rdx,%rdx
 101fc3e:	mov    -0x48(%rbp),%rax
 101fc42:	je     101fca4 <schedule_clone+0xc14>
 101fc44:	mov    (%rax),%rdi
 101fc47:	mov    0x8(%rbx),%rsi
 101fc4b:	mov    -0x88(%rbp),%r8
 101fc52:	mov    %r14,%rcx
 101fc55:	call   101c8c0 <myl_rc_value_seed>
 101fc5a:	xor    %eax,%eax
 101fc5c:	jmp    101f7e4 <schedule_clone+0x754>
 101fc61:	xor    %r8d,%r8d
 101fc64:	mov    -0x48(%rbp),%rdi
 101fc68:	mov    0x30(%r12),%rax
 101fc6d:	test   %rax,%rax
 101fc70:	jne    101f52d <schedule_clone+0x49d>
 101fc76:	jmp    101f56d <schedule_clone+0x4dd>
 101fc7b:	mov    %rdi,%rcx
 101fc7e:	mov    %rax,%rdi
 101fc81:	mov    %rsi,%r9
 101fc84:	mov    %r8,%rsi
 101fc87:	mov    %r11d,%r8d
 101fc8a:	call   1018df4 <myl_rc_binding_find_slow>
 101fc8f:	mov    %r8d,%r11d
 101fc92:	mov    %rcx,%rdi
 101fc95:	mov    %r9,%rsi
 101fc98:	mov    %rax,%rbx
 101fc9b:	test   %rbx,%rbx
 101fc9e:	jne    101f5d2 <schedule_clone+0x542>
 101fca4:	call   10187d4 <myl_rc_invariant_failed>
 101fca9:	int3
 101fcaa:	int3
 101fcab:	int3
 101fcac:	int3
 101fcad:	int3
 101fcae:	int3
 101fcaf:	int3

000000000101fcb0 <transfer_pointer>:
 101fcb0:	push   %rbp
 101fcb1:	mov    %rsp,%rbp
 101fcb4:	push   %r15
 101fcb6:	push   %r14
 101fcb8:	push   %r13
 101fcba:	push   %r12
 101fcbc:	push   %rbx
 101fcbd:	sub    $0x48,%rsp
 101fcc1:	mov    (%rdx),%rdx
 101fcc4:	cmp    $0x5,%ecx
 101fcc7:	jne    101fcdc <transfer_pointer+0x2c>
 101fcc9:	add    $0x48,%rsp
 101fccd:	pop    %rbx
 101fcce:	pop    %r12
 101fcd0:	pop    %r13
 101fcd2:	pop    %r14
 101fcd4:	pop    %r15
 101fcd6:	pop    %rbp
 101fcd7:	jmp    1020910 <transfer_hold>
 101fcdc:	test   %rdx,%rdx
 101fcdf:	je     101fe37 <transfer_pointer+0x187>
 101fce5:	mov    -0x10(%rdx),%rcx
 101fce9:	test   $0x2,%cl
 101fcec:	jne    101fe37 <transfer_pointer+0x187>
 101fcf2:	bt     $0x3e,%rcx
 101fcf7:	jb     101fd0b <transfer_pointer+0x5b>
 101fcf9:	xor    %eax,%eax
 101fcfb:	bt     $0x3c,%rcx
 101fd00:	jae    101fd49 <transfer_pointer+0x99>
 101fd02:	mov    0x20(%rdi),%r8d
 101fd06:	jmp    101fe0c <transfer_pointer+0x15c>
 101fd0b:	mov    %rcx,%rax
 101fd0e:	shr    $0x28,%rax
 101fd12:	and    $0xfffff,%eax
 101fd17:	mov    0x20(%rdi),%r8d
 101fd1b:	cmp    %r8d,%eax
 101fd1e:	jbe    101fd3e <transfer_pointer+0x8e>
 101fd20:	mov    0x28(%rdi),%rax
 101fd24:	cmpl   $0x0,0xa8(%rax)
 101fd2b:	mov    %r8d,%eax
 101fd2e:	jne    101fe0c <transfer_pointer+0x15c>
 101fd34:	mov    $0x3,%eax
 101fd39:	jmp    101fe3c <transfer_pointer+0x18c>
 101fd3e:	bt     $0x3c,%rcx
 101fd43:	jb     101fe0c <transfer_pointer+0x15c>
 101fd49:	movabs $0x2000000000000000,%r11
 101fd53:	mov    0x28(%rdi),%r13
 101fd57:	cmpl   $0x0,0xac(%r13)
 101fd5f:	sete   %r8b
 101fd63:	mov    %rcx,%r9
 101fd66:	shr    $0x3d,%r9
 101fd6a:	and    $0x1,%r9d
 101fd6e:	or     %r8b,%r9b
 101fd71:	jne    101fdeb <transfer_pointer+0x13b>
 101fd73:	mov    -0x8(%rdx),%r8
 101fd77:	cmp    $0x100b618,%r8
 101fd7e:	setne  %r9b
 101fd82:	cmp    $0x100b510,%r8
 101fd89:	setne  %r10b
 101fd8d:	and    %r9b,%r10b
 101fd90:	cmp    $0x100b4a0,%r8
 101fd97:	setne  %r8b
 101fd9b:	test   %r8b,%r10b
 101fd9e:	jne    101fdeb <transfer_pointer+0x13b>
 101fda0:	bt     $0x3c,%rcx
 101fda5:	jb     101ffc6 <transfer_pointer+0x316>
 101fdab:	mov    0xb0(%r13),%rbx
 101fdb2:	mov    0xb8(%r13),%r15
 101fdb9:	mov    0xc0(%r13),%rcx
 101fdc0:	cmp    %rcx,%r15
 101fdc3:	jae    101fe4b <transfer_pointer+0x19b>
 101fdc9:	mov    %rbx,%r14
 101fdcc:	test   %rbx,%rbx
 101fdcf:	je     101febe <transfer_pointer+0x20e>
 101fdd5:	mov    %r14,0xb0(%r13)
 101fddc:	lea    0x1(%r15),%rcx
 101fde0:	mov    %rcx,0xb8(%r13)
 101fde7:	mov    %rdx,(%r14,%r15,8)
 101fdeb:	cmpl   $0x0,0x24(%rdi)
 101fdef:	jne    101fe37 <transfer_pointer+0x187>
 101fdf1:	test   %eax,%eax
 101fdf3:	je     101fec8 <transfer_pointer+0x218>
 101fdf9:	mov    0x28(%rdi),%rax
 101fdfd:	cmpl   $0x0,0xac(%rax)
 101fe04:	jne    101fe37 <transfer_pointer+0x187>
 101fe06:	or     %r11,-0x10(%rdx)
 101fe0a:	jmp    101fe37 <transfer_pointer+0x187>
 101fe0c:	mov    %rsi,%rbx
 101fe0f:	mov    0x28(%rdi),%rcx
 101fe13:	cmpl   $0x0,0xac(%rcx)
 101fe1a:	cmove  %r8d,%eax
 101fe1e:	lea    -0x70(%rbp),%rcx
 101fe22:	mov    %rdx,%rsi
 101fe25:	mov    %eax,%edx
 101fe27:	call   101f090 <schedule_clone>
 101fe2c:	test   %eax,%eax
 101fe2e:	jne    101fe3c <transfer_pointer+0x18c>
 101fe30:	mov    -0x70(%rbp),%rdx
 101fe34:	mov    %rbx,%rsi
 101fe37:	mov    %rdx,(%rsi)
 101fe3a:	xor    %eax,%eax
 101fe3c:	add    $0x48,%rsp
 101fe40:	pop    %rbx
 101fe41:	pop    %r12
 101fe43:	pop    %r13
 101fe45:	pop    %r14
 101fe47:	pop    %r15
 101fe49:	pop    %rbp
 101fe4a:	ret
 101fe4b:	lea    (%rcx,%rcx,1),%r8
 101fe4f:	test   %rcx,%rcx
 101fe52:	mov    $0x10,%r12d
 101fe58:	cmovne %r8,%r12
 101fe5c:	cmp    %rcx,%r12
 101fe5f:	setb   %cl
 101fe62:	lea    -0x1(%r11),%r8
 101fe66:	cmp    %r8,%r12
 101fe69:	seta   %r8b
 101fe6d:	or     %cl,%r8b
 101fe70:	jne    101febe <transfer_pointer+0x20e>
 101fe72:	mov    (%rdi),%r8
 101fe75:	test   %r8,%r8
 101fe78:	je     101ffc6 <transfer_pointer+0x316>
 101fe7e:	test   %r12,%r12
 101fe81:	je     101ffc6 <transfer_pointer+0x316>
 101fe87:	mov    0x1608(%r8),%r9
 101fe8e:	test   %r9,%r9
 101fe91:	je     101ffc6 <transfer_pointer+0x316>
 101fe97:	lea    0x0(,%r12,8),%r10
 101fe9f:	mov    0x18(%r8),%r11
 101fea3:	add    %r10,%r11
 101fea6:	jb     101feb6 <transfer_pointer+0x206>
 101fea8:	mov    0x58(%r8),%rcx
 101feac:	test   %rcx,%rcx
 101feaf:	je     101fee9 <transfer_pointer+0x239>
 101feb1:	cmp    %rcx,%r11
 101feb4:	jbe    101fee9 <transfer_pointer+0x239>
 101feb6:	movl   $0x1,0x6c(%r8)
 101febe:	mov    $0x1,%eax
 101fec3:	jmp    101fe3c <transfer_pointer+0x18c>
 101fec8:	mov    %rsi,%rbx
 101fecb:	mov    %rdx,%r14
 101fece:	mov    %rdx,%rdi
 101fed1:	call   1020ad0 <myl_rc_owner_take>
 101fed6:	test   %eax,%eax
 101fed8:	jne    101fe3c <transfer_pointer+0x18c>
 101fede:	mov    %rbx,%rsi
 101fee1:	mov    %r14,%rdx
 101fee4:	jmp    101fe37 <transfer_pointer+0x187>
 101fee9:	mov    %r11,-0x30(%rbp)
 101feed:	mov    %r9,-0x38(%rbp)
 101fef1:	mov    %r8,-0x40(%rbp)
 101fef5:	mov    %rax,-0x68(%rbp)
 101fef9:	mov    %rdi,-0x60(%rbp)
 101fefd:	mov    %rdx,-0x58(%rbp)
 101ff01:	mov    %rsi,-0x50(%rbp)
 101ff05:	mov    $0x1,%edi
 101ff0a:	mov    %r10,%rsi
 101ff0d:	call   1027510 <calloc@plt>
 101ff12:	mov    %rax,%r14
 101ff15:	test   %rax,%rax
 101ff18:	mov    $0x1,%eax
 101ff1d:	je     101fe3c <transfer_pointer+0x18c>
 101ff23:	mov    -0x40(%rbp),%rcx
 101ff27:	mov    -0x30(%rbp),%rsi
 101ff2b:	mov    %rsi,0x18(%rcx)
 101ff2f:	mov    -0x38(%rbp),%rdx
 101ff33:	lea    0x0(,%r12,8),%r8
 101ff3b:	add    0x30(%rdx),%r8
 101ff3f:	mov    %r8,0x30(%rdx)
 101ff43:	test   %r15,%r15
 101ff46:	je     101ff6f <transfer_pointer+0x2bf>
 101ff48:	lea    0x0(,%r15,8),%rdx
 101ff50:	mov    %r14,%rdi
 101ff53:	mov    %rbx,%rsi
 101ff56:	mov    %r8,-0x48(%rbp)
 101ff5a:	call   1027520 <memcpy@plt>
 101ff5f:	mov    -0x30(%rbp),%rsi
 101ff63:	mov    -0x48(%rbp),%r8
 101ff67:	mov    -0x38(%rbp),%rdx
 101ff6b:	mov    -0x40(%rbp),%rcx
 101ff6f:	test   %rbx,%rbx
 101ff72:	je     101ffa0 <transfer_pointer+0x2f0>
 101ff74:	mov    0xc0(%r13),%rax
 101ff7b:	shl    $0x3,%rax
 101ff7f:	sub    %rax,%rsi
 101ff82:	jb     101ffc6 <transfer_pointer+0x316>
 101ff84:	sub    %rax,%r8
 101ff87:	jb     101ffc6 <transfer_pointer+0x316>
 101ff89:	mov    %rsi,0x18(%rcx)
 101ff8d:	mov    %r8,0x30(%rdx)
 101ff91:	mov    %rbx,%rdi
 101ff94:	call   1027570 <free@plt>
 101ff99:	mov    0xb8(%r13),%r15
 101ffa0:	mov    %r12,0xc0(%r13)
 101ffa7:	mov    -0x50(%rbp),%rsi
 101ffab:	mov    -0x58(%rbp),%rdx
 101ffaf:	mov    -0x60(%rbp),%rdi
 101ffb3:	mov    -0x68(%rbp),%rax
 101ffb7:	movabs $0x2000000000000000,%r11
 101ffc1:	jmp    101fdd5 <transfer_pointer+0x125>
 101ffc6:	call   10187d4 <myl_rc_invariant_failed>
 101ffcb:	int3
 101ffcc:	int3
 101ffcd:	int3
 101ffce:	int3
 101ffcf:	int3

000000000101ffd0 <finish_clones>:
 101ffd0:	push   %rbp
 101ffd1:	mov    %rsp,%rbp
 101ffd4:	push   %r15
 101ffd6:	push   %r14
 101ffd8:	push   %r13
 101ffda:	push   %r12
 101ffdc:	push   %rbx
 101ffdd:	sub    $0xa8,%rsp
 101ffe4:	mov    0x28(%rdi),%rbx
 101ffe8:	movl   $0x0,0x24(%rdi)
 101ffef:	mov    0x8(%rbx),%rax
 101fff3:	test   %rax,%rax
 101fff6:	je     1020666 <finish_clones+0x696>
 101fffc:	mov    %rdi,%r14
 101ffff:	mov    %rdi,-0x30(%rbp)
 1020003:	mov    %rbx,-0x90(%rbp)
 102000a:	jmp    102002c <finish_clones+0x5c>
 102000c:	nopl   0x0(%rax)
 1020010:	decq   0x8(%rbx)
 1020014:	mov    -0x30(%rbp),%r14
 1020018:	mov    -0x90(%rbp),%rbx
 102001f:	mov    0x8(%rbx),%rax
 1020023:	test   %rax,%rax
 1020026:	je     1020666 <finish_clones+0x696>
 102002c:	mov    (%rbx),%rdx
 102002f:	lea    (%rax,%rax,4),%rsi
 1020033:	lea    (%rdx,%rsi,8),%rcx
 1020037:	mov    -0x18(%rdx,%rsi,8),%rsi
 102003c:	mov    0x38(%rsi),%r10
 1020040:	test   %r10,%r10
 1020043:	je     10203d0 <finish_clones+0x400>
 1020049:	movq   $0x0,-0xa0(%rbp)
 1020054:	mov    (%r14),%rdi
 1020057:	mov    -0x28(%rcx),%rsi
 102005b:	mov    -0x20(%rcx),%rdx
 102005f:	add    $0xfffffffffffffff0,%rcx
 1020063:	lea    -0xa0(%rbp),%rax
 102006a:	mov    %rax,(%rsp)
 102006e:	lea    -0x88(%rbp),%r8
 1020075:	lea    -0xc0(%rbp),%r9
 102007c:	call   *%r10
 102007f:	test   %eax,%eax
 1020081:	je     1020010 <finish_clones+0x40>
 1020083:	mov    -0xa0(%rbp),%rax
 102008a:	mov    %rax,-0x98(%rbp)
 1020091:	mov    (%r14),%rbx
 1020094:	mov    -0xc0(%rbp),%rcx
 102009b:	mov    0x1608(%rbx),%r15
 10200a2:	mov    0x58(%r15),%rax
 10200a6:	mov    0x60(%r15),%rdx
 10200aa:	movzbl 0x70(%r15),%esi
 10200af:	mov    %rcx,%rdi
 10200b2:	movabs $0x9e3779b97f4a7c15,%r8
 10200bc:	imul   %r8,%rdi
 10200c0:	shrx   %rsi,%rdi,%rsi
 10200c5:	data16 cs nopw 0x0(%rax,%rax,1)
 10200d0:	and    %rdx,%rsi
 10200d3:	mov    %rsi,%rdi
 10200d6:	shl    $0x4,%rdi
 10200da:	mov    (%rax,%rdi,1),%rdi
 10200de:	cmp    %rcx,%rdi
 10200e1:	je     1020100 <finish_clones+0x130>
 10200e3:	test   %rdi,%rdi
 10200e6:	je     1020697 <finish_clones+0x6c7>
 10200ec:	inc    %rsi
 10200ef:	jmp    10200d0 <finish_clones+0x100>
 10200f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1020100:	shl    $0x4,%rsi
 1020104:	mov    0x8(%rax,%rsi,1),%rsi
 1020109:	test   %rsi,%rsi
 102010c:	je     1020697 <finish_clones+0x6c7>
 1020112:	mov    -0x88(%rbp),%rax
 1020119:	test   %rax,%rax
 102011c:	je     1020697 <finish_clones+0x6c7>
 1020122:	mov    (%rax),%rax
 1020125:	cmp    (%rsi),%rax
 1020128:	jne    1020697 <finish_clones+0x6c7>
 102012e:	mov    0x28(%rsi),%rcx
 1020132:	cmp    $0x2,%rcx
 1020136:	mov    %rsi,-0x58(%rbp)
 102013a:	jb     1020227 <finish_clones+0x257>
 1020140:	mov    0x10(%r14),%r12
 1020144:	cmp    %r12,%rcx
 1020147:	jbe    1020227 <finish_clones+0x257>
 102014d:	cmpq   $0x0,0x18(%r14)
 1020152:	jne    1020697 <finish_clones+0x6c7>
 1020158:	mov    %rcx,%rax
 102015b:	shr    $0x3b,%rax
 102015f:	jne    1020697 <finish_clones+0x6c7>
 1020165:	test   %rbx,%rbx
 1020168:	je     1020697 <finish_clones+0x6c7>
 102016e:	test   %r15,%r15
 1020171:	je     1020697 <finish_clones+0x6c7>
 1020177:	mov    %rcx,%r14
 102017a:	shl    $0x5,%r14
 102017e:	mov    0x18(%rbx),%r13
 1020182:	add    %r14,%r13
 1020185:	jb     102067a <finish_clones+0x6aa>
 102018b:	mov    0x58(%rbx),%rax
 102018f:	test   %rax,%rax
 1020192:	je     102019d <finish_clones+0x1cd>
 1020194:	cmp    %rax,%r13
 1020197:	ja     102067a <finish_clones+0x6aa>
 102019d:	mov    %rcx,-0x48(%rbp)
 10201a1:	mov    $0x1,%edi
 10201a6:	mov    %r14,%rsi
 10201a9:	call   1027510 <calloc@plt>
 10201ae:	test   %rax,%rax
 10201b1:	je     1020690 <finish_clones+0x6c0>
 10201b7:	mov    %r13,0x18(%rbx)
 10201bb:	add    0x30(%r15),%r14
 10201bf:	mov    %r14,0x30(%r15)
 10201c3:	mov    -0x48(%rbp),%rdx
 10201c7:	mov    %rdx,%rcx
 10201ca:	cmp    $0x9,%r12
 10201ce:	jb     1020217 <finish_clones+0x247>
 10201d0:	mov    -0x30(%rbp),%rcx
 10201d4:	mov    0x8(%rcx),%rdi
 10201d8:	mov    %rdx,%rcx
 10201db:	test   %rdi,%rdi
 10201de:	je     1020217 <finish_clones+0x247>
 10201e0:	mov    %rax,-0x40(%rbp)
 10201e4:	shl    $0x5,%r12
 10201e8:	sub    %r12,%r13
 10201eb:	jb     1020697 <finish_clones+0x6c7>
 10201f1:	sub    %r12,%r14
 10201f4:	jb     1020697 <finish_clones+0x6c7>
 10201fa:	mov    %r13,0x18(%rbx)
 10201fe:	mov    %r14,0x30(%r15)
 1020202:	call   1027570 <free@plt>
 1020207:	mov    -0x58(%rbp),%rax
 102020b:	mov    0x28(%rax),%rcx
 102020f:	mov    -0x40(%rbp),%rax
 1020213:	mov    -0x48(%rbp),%rdx
 1020217:	mov    -0x30(%rbp),%r14
 102021b:	mov    %rax,0x8(%r14)
 102021f:	mov    %rdx,0x10(%r14)
 1020223:	mov    -0x58(%rbp),%rsi
 1020227:	mov    -0x70(%rbp),%eax
 102022a:	mov    %eax,0x20(%r14)
 102022e:	cmpq   $0x0,-0x98(%rbp)
 1020236:	je     1020014 <finish_clones+0x44>
 102023c:	mov    -0xb8(%rbp),%r13
 1020243:	mov    -0x80(%rbp),%r14
 1020247:	xor    %edx,%edx
 1020249:	mov    %rcx,-0x48(%rbp)
 102024d:	jmp    1020292 <finish_clones+0x2c2>
 102024f:	nop
 1020250:	mov    $0x101fcb0,%r8d
 1020256:	mov    -0x30(%rbp),%rdi
 102025a:	mov    %r14,%rdx
 102025d:	mov    %r13,%rcx
 1020260:	call   101ed90 <visit>
 1020265:	test   %eax,%eax
 1020267:	jne    1020668 <finish_clones+0x698>
 102026d:	mov    -0x40(%rbp),%rdx
 1020271:	inc    %rdx
 1020274:	mov    -0x58(%rbp),%rsi
 1020278:	mov    (%rsi),%rax
 102027b:	add    %rax,%r14
 102027e:	add    %rax,%r13
 1020281:	cmp    -0x98(%rbp),%rdx
 1020288:	mov    -0x48(%rbp),%rcx
 102028c:	je     1020014 <finish_clones+0x44>
 1020292:	cmp    $0x2,%rcx
 1020296:	mov    %rdx,-0x40(%rbp)
 102029a:	ja     1020250 <finish_clones+0x280>
 102029c:	mov    0x8(%rsi),%eax
 102029f:	mov    %rax,-0x50(%rbp)
 10202a3:	dec    %eax
 10202a5:	cmp    $0x4,%eax
 10202a8:	ja     102030e <finish_clones+0x33e>
 10202aa:	jmp    *0x1001be8(,%rax,8)
 10202b1:	mov    $0x1,%ecx
 10202b6:	jmp    1020310 <finish_clones+0x340>
 10202b8:	mov    0x10(%rsi),%rdx
 10202bc:	mov    0x18(%rsi),%rcx
 10202c0:	mov    0x20(%rsi),%r12
 10202c4:	add    %r13,%r12
 10202c7:	mov    $0x4,%eax
 10202cc:	mov    %rax,-0x50(%rbp)
 10202d0:	movq   $0x0,-0x38(%rbp)
 10202d8:	jmp    102031d <finish_clones+0x34d>
 10202da:	mov    0x10(%rsi),%rdx
 10202de:	mov    0x18(%rsi),%rcx
 10202e2:	mov    $0x2,%eax
 10202e7:	mov    %rax,-0x50(%rbp)
 10202eb:	movq   $0x0,-0x38(%rbp)
 10202f3:	jmp    102031a <finish_clones+0x34a>
 10202f5:	mov    0x10(%rsi),%rax
 10202f9:	mov    0x18(%rsi),%rcx
 10202fd:	mov    0x20(%rsi),%rdx
 1020301:	mov    %rdx,-0x38(%rbp)
 1020305:	mov    0x8(%rax),%eax
 1020308:	mov    %rax,-0x50(%rbp)
 102030c:	jmp    1020318 <finish_clones+0x348>
 102030e:	xor    %ecx,%ecx
 1020310:	movq   $0x0,-0x38(%rbp)
 1020318:	xor    %edx,%edx
 102031a:	xor    %r12d,%r12d
 102031d:	mov    %rcx,%r15
 1020320:	neg    %r15
 1020323:	xor    %ebx,%ebx
 1020325:	mov    %rcx,-0x68(%rbp)
 1020329:	mov    %rdx,-0x60(%rbp)
 102032d:	test   %rdx,%rdx
 1020330:	je     1020390 <finish_clones+0x3c0>
 1020332:	cmp    %rcx,%rbx
 1020335:	jae    102026d <finish_clones+0x29d>
 102033b:	lea    (%rbx,%rbx,2),%rax
 102033f:	lea    (%rdx,%rax,8),%rax
 1020343:	inc    %rbx
 1020346:	jmp    1020368 <finish_clones+0x398>
 1020348:	nopl   0x0(%rax,%rax,1)
 1020350:	add    $0x18,%rax
 1020354:	lea    (%r15,%rbx,1),%rcx
 1020358:	inc    %rcx
 102035b:	inc    %rbx
 102035e:	cmp    $0x1,%rcx
 1020362:	je     102026d <finish_clones+0x29d>
 1020368:	mov    0x8(%rax),%rcx
 102036c:	mov    0x8(%rcx),%ecx
 102036f:	test   %ecx,%ecx
 1020371:	je     1020350 <finish_clones+0x380>
 1020373:	test   %r12,%r12
 1020376:	je     1020381 <finish_clones+0x3b1>
 1020378:	mov    0x10(%rax),%edx
 102037b:	cmp    (%r12),%edx
 102037f:	jne    1020350 <finish_clones+0x380>
 1020381:	mov    (%rax),%rdx
 1020384:	jmp    10203aa <finish_clones+0x3da>
 1020386:	cs nopw 0x0(%rax,%rax,1)
 1020390:	cmp    %rcx,%rbx
 1020393:	je     102026d <finish_clones+0x29d>
 1020399:	mov    %rbx,%rdx
 102039c:	inc    %rbx
 102039f:	imul   -0x38(%rbp),%rdx
 10203a4:	mov    -0x50(%rbp),%rax
 10203a8:	mov    %eax,%ecx
 10203aa:	lea    (%r14,%rdx,1),%rsi
 10203ae:	add    %r13,%rdx
 10203b1:	mov    -0x30(%rbp),%rdi
 10203b5:	call   101fcb0 <transfer_pointer>
 10203ba:	test   %eax,%eax
 10203bc:	mov    -0x68(%rbp),%rcx
 10203c0:	mov    -0x60(%rbp),%rdx
 10203c4:	je     102032d <finish_clones+0x35d>
 10203ca:	jmp    1020668 <finish_clones+0x698>
 10203cf:	nop
 10203d0:	mov    0x30(%rsi),%r10
 10203d4:	test   %r10,%r10
 10203d7:	je     102040d <finish_clones+0x43d>
 10203d9:	mov    (%r14),%rdi
 10203dc:	mov    -0x28(%rcx),%rsi
 10203e0:	mov    -0x20(%rcx),%rdx
 10203e4:	add    $0xfffffffffffffff0,%rcx
 10203e8:	lea    -0x88(%rbp),%r8
 10203ef:	lea    -0xc0(%rbp),%r9
 10203f6:	call   *%r10
 10203f9:	test   %eax,%eax
 10203fb:	je     1020656 <finish_clones+0x686>
 1020401:	mov    -0xc0(%rbp),%rax
 1020408:	jmp    10204a6 <finish_clones+0x4d6>
 102040d:	mov    -0x28(%rcx),%rdi
 1020411:	mov    -0x10(%rcx),%rdx
 1020415:	mov    -0x10(%rdi),%rdi
 1020419:	mov    %rdi,%r8
 102041c:	shr    $0x2,%r8
 1020420:	bt     $0x3e,%rdi
 1020425:	movabs $0x3fffffffff,%rdi
 102042f:	movabs $0x3ffffffffffffff,%r9
 1020439:	cmovae %r9,%rdi
 102043d:	and    %r8,%rdi
 1020440:	cmp    %rdi,%rdx
 1020443:	je     102065a <finish_clones+0x68a>
 1020449:	mov    0x8(%rsi),%rax
 102044d:	lea    0x1(%rdx),%rsi
 1020451:	mov    %rsi,-0x10(%rcx)
 1020455:	imul   (%rax),%rdx
 1020459:	mov    -0x20(%rcx),%rsi
 102045d:	lea    (%rsi,%rdx,1),%rdi
 1020461:	mov    -0x8(%rcx),%r8d
 1020465:	mov    %rax,-0x88(%rbp)
 102046c:	mov    %rdi,-0x80(%rbp)
 1020470:	mov    %rsi,-0x78(%rbp)
 1020474:	mov    %r8d,-0x70(%rbp)
 1020478:	movl   $0x0,-0x6c(%rbp)
 102047f:	mov    -0x28(%rcx),%rcx
 1020483:	add    %rcx,%rdx
 1020486:	mov    %rax,-0xc0(%rbp)
 102048d:	mov    %rdx,-0xb8(%rbp)
 1020494:	mov    %rcx,-0xb0(%rbp)
 102049b:	movq   $0x0,-0xa8(%rbp)
 10204a6:	mov    (%r14),%r13
 10204a9:	mov    0x1608(%r13),%r15
 10204b0:	mov    0x58(%r15),%rcx
 10204b4:	mov    0x60(%r15),%rdx
 10204b8:	movzbl 0x70(%r15),%esi
 10204bd:	mov    %rax,%rdi
 10204c0:	movabs $0x9e3779b97f4a7c15,%r8
 10204ca:	imul   %r8,%rdi
 10204ce:	shrx   %rsi,%rdi,%rsi
 10204d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10204e0:	and    %rdx,%rsi
 10204e3:	mov    %rsi,%rdi
 10204e6:	shl    $0x4,%rdi
 10204ea:	mov    (%rcx,%rdi,1),%rdi
 10204ee:	cmp    %rax,%rdi
 10204f1:	je     1020510 <finish_clones+0x540>
 10204f3:	test   %rdi,%rdi
 10204f6:	je     1020697 <finish_clones+0x6c7>
 10204fc:	inc    %rsi
 10204ff:	jmp    10204e0 <finish_clones+0x510>
 1020501:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1020510:	shl    $0x4,%rsi
 1020514:	mov    0x8(%rcx,%rsi,1),%rsi
 1020519:	test   %rsi,%rsi
 102051c:	je     1020697 <finish_clones+0x6c7>
 1020522:	mov    -0x88(%rbp),%rax
 1020529:	test   %rax,%rax
 102052c:	je     1020697 <finish_clones+0x6c7>
 1020532:	mov    (%rax),%rax
 1020535:	cmp    (%rsi),%rax
 1020538:	jne    1020697 <finish_clones+0x6c7>
 102053e:	mov    0x28(%rsi),%r12
 1020542:	cmp    $0x2,%r12
 1020546:	jb     1020625 <finish_clones+0x655>
 102054c:	mov    0x10(%r14),%rcx
 1020550:	cmp    %rcx,%r12
 1020553:	jbe    1020625 <finish_clones+0x655>
 1020559:	cmpq   $0x0,0x18(%r14)
 102055e:	jne    1020697 <finish_clones+0x6c7>
 1020564:	mov    %r12,%rax
 1020567:	shr    $0x3b,%rax
 102056b:	jne    1020697 <finish_clones+0x6c7>
 1020571:	test   %r13,%r13
 1020574:	je     1020697 <finish_clones+0x6c7>
 102057a:	test   %r15,%r15
 102057d:	je     1020697 <finish_clones+0x6c7>
 1020583:	mov    %r12,%r14
 1020586:	shl    $0x5,%r14
 102058a:	mov    0x18(%r13),%rbx
 102058e:	add    %r14,%rbx
 1020591:	jb     1020688 <finish_clones+0x6b8>
 1020597:	mov    0x58(%r13),%rax
 102059b:	test   %rax,%rax
 102059e:	je     10205a9 <finish_clones+0x5d9>
 10205a0:	cmp    %rax,%rbx
 10205a3:	ja     1020688 <finish_clones+0x6b8>
 10205a9:	mov    %rcx,-0x40(%rbp)
 10205ad:	mov    %rsi,-0x68(%rbp)
 10205b1:	mov    $0x1,%edi
 10205b6:	mov    %r14,%rsi
 10205b9:	call   1027510 <calloc@plt>
 10205be:	test   %rax,%rax
 10205c1:	je     1020690 <finish_clones+0x6c0>
 10205c7:	mov    %rbx,0x18(%r13)
 10205cb:	add    0x30(%r15),%r14
 10205cf:	mov    %r14,0x30(%r15)
 10205d3:	mov    -0x40(%rbp),%rsi
 10205d7:	cmp    $0x9,%rsi
 10205db:	jb     1020615 <finish_clones+0x645>
 10205dd:	mov    -0x30(%rbp),%rcx
 10205e1:	mov    0x8(%rcx),%rdi
 10205e5:	test   %rdi,%rdi
 10205e8:	je     1020615 <finish_clones+0x645>
 10205ea:	mov    %rax,-0x60(%rbp)
 10205ee:	shl    $0x5,%rsi
 10205f2:	sub    %rsi,%rbx
 10205f5:	jb     1020697 <finish_clones+0x6c7>
 10205fb:	sub    %rsi,%r14
 10205fe:	jb     1020697 <finish_clones+0x6c7>
 1020604:	mov    %rbx,0x18(%r13)
 1020608:	mov    %r14,0x30(%r15)
 102060c:	call   1027570 <free@plt>
 1020611:	mov    -0x60(%rbp),%rax
 1020615:	mov    -0x30(%rbp),%r14
 1020619:	mov    %rax,0x8(%r14)
 102061d:	mov    %r12,0x10(%r14)
 1020621:	mov    -0x68(%rbp),%rsi
 1020625:	mov    -0x70(%rbp),%eax
 1020628:	mov    %eax,0x20(%r14)
 102062c:	mov    -0x80(%rbp),%rdx
 1020630:	mov    -0xb8(%rbp),%rcx
 1020637:	mov    $0x101fcb0,%r8d
 102063d:	mov    %r14,%rdi
 1020640:	call   101ed90 <visit>
 1020645:	test   %eax,%eax
 1020647:	mov    -0x90(%rbp),%rbx
 102064e:	je     102001f <finish_clones+0x4f>
 1020654:	jmp    1020668 <finish_clones+0x698>
 1020656:	mov    0x8(%rbx),%rax
 102065a:	dec    %rax
 102065d:	mov    %rax,0x8(%rbx)
 1020661:	jmp    102001f <finish_clones+0x4f>
 1020666:	xor    %eax,%eax
 1020668:	add    $0xa8,%rsp
 102066f:	pop    %rbx
 1020670:	pop    %r12
 1020672:	pop    %r13
 1020674:	pop    %r14
 1020676:	pop    %r15
 1020678:	pop    %rbp
 1020679:	ret
 102067a:	movl   $0x1,0x6c(%rbx)
 1020681:	mov    $0x1,%eax
 1020686:	jmp    1020668 <finish_clones+0x698>
 1020688:	movl   $0x1,0x6c(%r13)
 1020690:	mov    $0x1,%eax
 1020695:	jmp    1020668 <finish_clones+0x698>
 1020697:	call   10187d4 <myl_rc_invariant_failed>
 102069c:	int3
 102069d:	int3
 102069e:	int3
 102069f:	int3

00000000010206a0 <rollback_take>:
 10206a0:	mov    (%rsi),%rsi
 10206a3:	cmp    %rsi,(%rdx)
 10206a6:	je     10206f1 <rollback_take+0x51>
 10206a8:	push   %rbp
 10206a9:	mov    %rsp,%rbp
 10206ac:	push   %rbx
 10206ad:	push   %rax
 10206ae:	mov    (%rdi),%rbx
 10206b1:	cmp    $0x5,%ecx
 10206b4:	jne    10206e3 <rollback_take+0x43>
 10206b6:	mov    %rbx,%rdi
 10206b9:	call   1018ce0 <myl_rc_hold_edge_release>
 10206be:	test   %rbx,%rbx
 10206c1:	je     10206eb <rollback_take+0x4b>
 10206c3:	mov    0x1608(%rbx),%rax
 10206ca:	test   %rax,%rax
 10206cd:	je     10206eb <rollback_take+0x4b>
 10206cf:	cmpq   $0x0,0xc8(%rax)
 10206d7:	je     10206eb <rollback_take+0x4b>
 10206d9:	mov    %rbx,%rdi
 10206dc:	call   101bcb0 <myl_rc_drain>
 10206e1:	jmp    10206eb <rollback_take+0x4b>
 10206e3:	mov    %rbx,%rdi
 10206e6:	call   1018bc0 <myl_rc_edge_release>
 10206eb:	add    $0x8,%rsp
 10206ef:	pop    %rbx
 10206f0:	pop    %rbp
 10206f1:	xor    %eax,%eax
 10206f3:	ret
 10206f4:	int3
 10206f5:	int3
 10206f6:	int3
 10206f7:	int3
 10206f8:	int3
 10206f9:	int3
 10206fa:	int3
 10206fb:	int3
 10206fc:	int3
 10206fd:	int3
 10206fe:	int3
 10206ff:	int3

0000000001020700 <commit_take>:
 1020700:	mov    %rsi,%rax
 1020703:	mov    (%rdx),%rsi
 1020706:	cmp    (%rax),%rsi
 1020709:	je     1020754 <commit_take+0x54>
 102070b:	push   %rbp
 102070c:	mov    %rsp,%rbp
 102070f:	push   %rbx
 1020710:	push   %rax
 1020711:	mov    (%rdi),%rbx
 1020714:	cmp    $0x5,%ecx
 1020717:	jne    1020746 <commit_take+0x46>
 1020719:	mov    %rbx,%rdi
 102071c:	call   1018ce0 <myl_rc_hold_edge_release>
 1020721:	test   %rbx,%rbx
 1020724:	je     102074e <commit_take+0x4e>
 1020726:	mov    0x1608(%rbx),%rax
 102072d:	test   %rax,%rax
 1020730:	je     102074e <commit_take+0x4e>
 1020732:	cmpq   $0x0,0xc8(%rax)
 102073a:	je     102074e <commit_take+0x4e>
 102073c:	mov    %rbx,%rdi
 102073f:	call   101bcb0 <myl_rc_drain>
 1020744:	jmp    102074e <commit_take+0x4e>
 1020746:	mov    %rbx,%rdi
 1020749:	call   1018bc0 <myl_rc_edge_release>
 102074e:	add    $0x8,%rsp
 1020752:	pop    %rbx
 1020753:	pop    %rbp
 1020754:	xor    %eax,%eax
 1020756:	ret
 1020757:	int3
 1020758:	int3
 1020759:	int3
 102075a:	int3
 102075b:	int3
 102075c:	int3
 102075d:	int3
 102075e:	int3
 102075f:	int3

0000000001020760 <dispose_walk>:
 1020760:	push   %rbp
 1020761:	mov    %rsp,%rbp
 1020764:	push   %r15
 1020766:	push   %r14
 1020768:	push   %rbx
 1020769:	push   %rax
 102076a:	mov    %rdi,%rbx
 102076d:	mov    0x28(%rdi),%r14
 1020771:	test   %esi,%esi
 1020773:	je     1020799 <dispose_walk+0x39>
 1020775:	cmpq   $0x0,0x20(%r14)
 102077a:	je     1020799 <dispose_walk+0x39>
 102077c:	xor    %r15d,%r15d
 102077f:	nop
 1020780:	mov    (%rbx),%rdi
 1020783:	mov    0x18(%r14),%rax
 1020787:	mov    (%rax,%r15,8),%rsi
 102078b:	call   101cb50 <myl_rc_construction_abort>
 1020790:	inc    %r15
 1020793:	cmp    0x20(%r14),%r15
 1020797:	jb     1020780 <dispose_walk+0x20>
 1020799:	mov    (%rbx),%rdi
 102079c:	mov    0xb0(%r14),%rax
 10207a3:	test   %rax,%rax
 10207a6:	je     10207e7 <dispose_walk+0x87>
 10207a8:	mov    0xc0(%r14),%rdx
 10207af:	shl    $0x3,%rdx
 10207b3:	mov    0x18(%rdi),%rcx
 10207b7:	sub    %rdx,%rcx
 10207ba:	jb     102090a <dispose_walk+0x1aa>
 10207c0:	mov    0x1608(%rdi),%rsi
 10207c7:	mov    0x30(%rsi),%r8
 10207cb:	sub    %rdx,%r8
 10207ce:	jb     102090a <dispose_walk+0x1aa>
 10207d4:	mov    %rcx,0x18(%rdi)
 10207d8:	mov    %r8,0x30(%rsi)
 10207dc:	mov    %rax,%rdi
 10207df:	call   1027570 <free@plt>
 10207e4:	mov    (%rbx),%rdi
 10207e7:	mov    0x18(%r14),%rax
 10207eb:	test   %rax,%rax
 10207ee:	je     102082c <dispose_walk+0xcc>
 10207f0:	mov    0x28(%r14),%rdx
 10207f4:	shl    $0x3,%rdx
 10207f8:	mov    0x18(%rdi),%rcx
 10207fc:	sub    %rdx,%rcx
 10207ff:	jb     102090a <dispose_walk+0x1aa>
 1020805:	mov    0x1608(%rdi),%rsi
 102080c:	mov    0x30(%rsi),%r8
 1020810:	sub    %rdx,%r8
 1020813:	jb     102090a <dispose_walk+0x1aa>
 1020819:	mov    %rcx,0x18(%rdi)
 102081d:	mov    %r8,0x30(%rsi)
 1020821:	mov    %rax,%rdi
 1020824:	call   1027570 <free@plt>
 1020829:	mov    (%rbx),%rdi
 102082c:	mov    0x30(%r14),%rax
 1020830:	test   %rax,%rax
 1020833:	je     1020878 <dispose_walk+0x118>
 1020835:	mov    0xa0(%r14),%rcx
 102083c:	shl    $0x3,%rcx
 1020840:	lea    (%rcx,%rcx,2),%rdx
 1020844:	mov    0x18(%rdi),%rcx
 1020848:	sub    %rdx,%rcx
 102084b:	jb     102090a <dispose_walk+0x1aa>
 1020851:	mov    0x1608(%rdi),%rsi
 1020858:	mov    0x30(%rsi),%r8
 102085c:	sub    %rdx,%r8
 102085f:	jb     102090a <dispose_walk+0x1aa>
 1020865:	mov    %rcx,0x18(%rdi)
 1020869:	mov    %r8,0x30(%rsi)
 102086d:	mov    %rax,%rdi
 1020870:	call   1027570 <free@plt>
 1020875:	mov    (%rbx),%rdi
 1020878:	mov    (%r14),%rax
 102087b:	test   %rax,%rax
 102087e:	je     10208b8 <dispose_walk+0x158>
 1020880:	mov    0x10(%r14),%rcx
 1020884:	shl    $0x3,%rcx
 1020888:	lea    (%rcx,%rcx,4),%rdx
 102088c:	mov    0x18(%rdi),%rcx
 1020890:	sub    %rdx,%rcx
 1020893:	jb     102090a <dispose_walk+0x1aa>
 1020895:	mov    0x1608(%rdi),%rsi
 102089c:	mov    0x30(%rsi),%r8
 10208a0:	sub    %rdx,%r8
 10208a3:	jb     102090a <dispose_walk+0x1aa>
 10208a5:	mov    %rcx,0x18(%rdi)
 10208a9:	mov    %r8,0x30(%rsi)
 10208ad:	mov    %rax,%rdi
 10208b0:	call   1027570 <free@plt>
 10208b5:	mov    (%rbx),%rdi
 10208b8:	mov    0x10(%rbx),%rcx
 10208bc:	cmp    $0x9,%rcx
 10208c0:	jb     10208fb <dispose_walk+0x19b>
 10208c2:	mov    0x8(%rbx),%rax
 10208c6:	test   %rax,%rax
 10208c9:	je     10208fb <dispose_walk+0x19b>
 10208cb:	shl    $0x5,%rcx
 10208cf:	mov    0x18(%rdi),%rdx
 10208d3:	sub    %rcx,%rdx
 10208d6:	jb     102090a <dispose_walk+0x1aa>
 10208d8:	mov    0x1608(%rdi),%rsi
 10208df:	mov    0x30(%rsi),%r8
 10208e3:	sub    %rcx,%r8
 10208e6:	jb     102090a <dispose_walk+0x1aa>
 10208e8:	mov    %rdx,0x18(%rdi)
 10208ec:	mov    %r8,0x30(%rsi)
 10208f0:	mov    %rax,%rdi
 10208f3:	call   1027570 <free@plt>
 10208f8:	mov    (%rbx),%rdi
 10208fb:	add    $0x8,%rsp
 10208ff:	pop    %rbx
 1020900:	pop    %r14
 1020902:	pop    %r15
 1020904:	pop    %rbp
 1020905:	jmp    101bcb0 <myl_rc_drain>
 102090a:	call   10187d4 <myl_rc_invariant_failed>
 102090f:	int3

0000000001020910 <transfer_hold>:
 1020910:	push   %rbp
 1020911:	mov    %rsp,%rbp
 1020914:	push   %r15
 1020916:	push   %r14
 1020918:	push   %r12
 102091a:	push   %rbx
 102091b:	sub    $0x10,%rsp
 102091f:	test   %rdx,%rdx
 1020922:	je     1020a32 <transfer_hold+0x122>
 1020928:	movabs $0x4000000000000002,%r15
 1020932:	mov    -0x10(%rdx),%rcx
 1020936:	lea    -0x2(%r15),%rax
 102093a:	test   %rax,%rcx
 102093d:	je     1020a36 <transfer_hold+0x126>
 1020943:	mov    %rcx,%r8
 1020946:	shr    $0x28,%r8
 102094a:	and    $0xfffff,%r8d
 1020951:	mov    0x20(%rdi),%eax
 1020954:	cmp    %eax,%r8d
 1020957:	jbe    1020a36 <transfer_hold+0x126>
 102095d:	mov    0x28(%rdi),%rcx
 1020961:	cmpl   $0x0,0xa8(%rcx)
 1020968:	je     1020a74 <transfer_hold+0x164>
 102096e:	lea    -0x28(%rbp),%rcx
 1020972:	mov    %rdi,%rbx
 1020975:	mov    %rsi,%r14
 1020978:	mov    %rdx,%rsi
 102097b:	mov    %eax,%edx
 102097d:	call   101f090 <schedule_clone>
 1020982:	test   %eax,%eax
 1020984:	jne    1020a86 <transfer_hold+0x176>
 102098a:	mov    %rbx,%rax
 102098d:	mov    (%rbx),%rbx
 1020990:	mov    -0x28(%rbp),%rsi
 1020994:	test   %rsi,%rsi
 1020997:	je     10209e7 <transfer_hold+0xd7>
 1020999:	mov    -0x10(%rsi),%rcx
 102099d:	test   %r15,%rcx
 10209a0:	jne    10209e7 <transfer_hold+0xd7>
 10209a2:	test   %rbx,%rbx
 10209a5:	je     1020ac5 <transfer_hold+0x1b5>
 10209ab:	cmpq   $0x0,0x1608(%rbx)
 10209b3:	je     1020ac5 <transfer_hold+0x1b5>
 10209b9:	test   $0x1,%cl
 10209bc:	jne    1020ac5 <transfer_hold+0x1b5>
 10209c2:	mov    -0x18(%rsi),%rcx
 10209c6:	mov    -0x20(%rsi),%rdx
 10209ca:	or     %rcx,%rdx
 10209cd:	je     1020ac5 <transfer_hold+0x1b5>
 10209d3:	cmp    $0xffffffffffffffff,%rcx
 10209d7:	je     1020a9a <transfer_hold+0x18a>
 10209dd:	inc    %rcx
 10209e0:	mov    %rcx,-0x18(%rsi)
 10209e4:	mov    (%rax),%rbx
 10209e7:	mov    %rbx,%rdi
 10209ea:	mov    %rsi,%r15
 10209ed:	call   1018bc0 <myl_rc_edge_release>
 10209f2:	test   %rbx,%rbx
 10209f5:	je     1020a7b <transfer_hold+0x16b>
 10209fb:	mov    $0x1,%r12b
 10209fe:	xor    %eax,%eax
 1020a00:	mov    %r14,%rsi
 1020a03:	mov    0x1608(%rbx),%rcx
 1020a0a:	test   %rcx,%rcx
 1020a0d:	je     1020a28 <transfer_hold+0x118>
 1020a0f:	cmpq   $0x0,0xc8(%rcx)
 1020a17:	je     1020a28 <transfer_hold+0x118>
 1020a19:	mov    %rbx,%rdi
 1020a1c:	mov    %eax,%ebx
 1020a1e:	call   101bcb0 <myl_rc_drain>
 1020a23:	mov    %ebx,%eax
 1020a25:	mov    %r14,%rsi
 1020a28:	test   %r12b,%r12b
 1020a2b:	mov    %r15,%rdx
 1020a2e:	jne    1020a81 <transfer_hold+0x171>
 1020a30:	jmp    1020a86 <transfer_hold+0x176>
 1020a32:	xor    %edx,%edx
 1020a34:	jmp    1020a81 <transfer_hold+0x171>
 1020a36:	cmpl   $0x0,0x24(%rdi)
 1020a3a:	jne    1020a81 <transfer_hold+0x171>
 1020a3c:	test   %r15,%rcx
 1020a3f:	jne    1020a81 <transfer_hold+0x171>
 1020a41:	mov    (%rdi),%rax
 1020a44:	test   %rax,%rax
 1020a47:	je     1020ac5 <transfer_hold+0x1b5>
 1020a49:	cmpq   $0x0,0x1608(%rax)
 1020a51:	je     1020ac5 <transfer_hold+0x1b5>
 1020a53:	test   $0x1,%cl
 1020a56:	jne    1020ac5 <transfer_hold+0x1b5>
 1020a58:	mov    -0x18(%rdx),%rax
 1020a5c:	mov    -0x20(%rdx),%rcx
 1020a60:	or     %rax,%rcx
 1020a63:	je     1020ac5 <transfer_hold+0x1b5>
 1020a65:	cmp    $0xffffffffffffffff,%rax
 1020a69:	je     1020a93 <transfer_hold+0x183>
 1020a6b:	inc    %rax
 1020a6e:	mov    %rax,-0x18(%rdx)
 1020a72:	jmp    1020a81 <transfer_hold+0x171>
 1020a74:	mov    $0x3,%eax
 1020a79:	jmp    1020a86 <transfer_hold+0x176>
 1020a7b:	mov    %r14,%rsi
 1020a7e:	mov    %r15,%rdx
 1020a81:	mov    %rdx,(%rsi)
 1020a84:	xor    %eax,%eax
 1020a86:	add    $0x10,%rsp
 1020a8a:	pop    %rbx
 1020a8b:	pop    %r12
 1020a8d:	pop    %r14
 1020a8f:	pop    %r15
 1020a91:	pop    %rbp
 1020a92:	ret
 1020a93:	mov    $0x2,%eax
 1020a98:	jmp    1020a86 <transfer_hold+0x176>
 1020a9a:	mov    %rbx,%rdi
 1020a9d:	mov    %rsi,%r15
 1020aa0:	call   1018bc0 <myl_rc_edge_release>
 1020aa5:	mov    %r14,%rsi
 1020aa8:	mov    $0x2,%eax
 1020aad:	xor    %r12d,%r12d
 1020ab0:	mov    0x1608(%rbx),%rcx
 1020ab7:	test   %rcx,%rcx
 1020aba:	jne    1020a0f <transfer_hold+0xff>
 1020ac0:	jmp    1020a28 <transfer_hold+0x118>
 1020ac5:	call   10187d4 <myl_rc_invariant_failed>
 1020aca:	int3
 1020acb:	int3
 1020acc:	int3
 1020acd:	int3
 1020ace:	int3
 1020acf:	int3

0000000001020ad0 <myl_rc_owner_take>:
 1020ad0:	mov    -0x10(%rdi),%rcx
 1020ad4:	xor    %eax,%eax
 1020ad6:	movabs $0x4000000000000002,%rdx
 1020ae0:	test   %rdx,%rcx
 1020ae3:	je     1020ae6 <myl_rc_owner_take+0x16>
 1020ae5:	ret
 1020ae6:	test   $0x1,%cl
 1020ae9:	jne    1020b0f <myl_rc_owner_take+0x3f>
 1020aeb:	mov    -0x20(%rdi),%rcx
 1020aef:	cmp    $0xffffffffffffffff,%rcx
 1020af3:	je     1020b09 <myl_rc_owner_take+0x39>
 1020af5:	test   %rcx,%rcx
 1020af8:	jne    1020b01 <myl_rc_owner_take+0x31>
 1020afa:	cmpq   $0x0,-0x18(%rdi)
 1020aff:	je     1020b0f <myl_rc_owner_take+0x3f>
 1020b01:	inc    %rcx
 1020b04:	mov    %rcx,-0x20(%rdi)
 1020b08:	ret
 1020b09:	mov    $0x2,%eax
 1020b0e:	ret
 1020b0f:	push   %rbp
 1020b10:	mov    %rsp,%rbp
 1020b13:	call   10187d4 <myl_rc_invariant_failed>
 1020b18:	int3
 1020b19:	int3
 1020b1a:	int3
 1020b1b:	int3
 1020b1c:	int3
 1020b1d:	int3
 1020b1e:	int3
 1020b1f:	int3

0000000001020b20 <retain_pointer>:
 1020b20:	mov    (%rdx),%rdx
 1020b23:	test   %rdx,%rdx
 1020b26:	je     1020b4d <retain_pointer+0x2d>
 1020b28:	mov    -0x10(%rdx),%r8
 1020b2c:	bt     $0x3e,%r8
 1020b31:	jae    1020b5c <retain_pointer+0x3c>
 1020b33:	mov    %r8,%r9
 1020b36:	shr    $0x28,%r9
 1020b3a:	and    $0xfffff,%r9d
 1020b41:	mov    $0x3,%eax
 1020b46:	cmp    0x20(%rdi),%r9d
 1020b4a:	jbe    1020b5c <retain_pointer+0x3c>
 1020b4c:	ret
 1020b4d:	cmp    $0x5,%ecx
 1020b50:	jne    1020b79 <retain_pointer+0x59>
 1020b52:	movq   $0x0,(%rsi)
 1020b59:	xor    %eax,%eax
 1020b5b:	ret
 1020b5c:	cmp    $0x5,%ecx
 1020b5f:	jne    1020b66 <retain_pointer+0x46>
 1020b61:	jmp    1020910 <transfer_hold>
 1020b66:	movabs $0x4000000000000000,%rax
 1020b70:	add    $0x2,%rax
 1020b74:	test   %rax,%r8
 1020b77:	je     1020b7f <retain_pointer+0x5f>
 1020b79:	mov    %rdx,(%rsi)
 1020b7c:	xor    %eax,%eax
 1020b7e:	ret
 1020b7f:	test   $0x1,%r8b
 1020b83:	jne    1020bae <retain_pointer+0x8e>
 1020b85:	mov    -0x20(%rdx),%rax
 1020b89:	cmp    $0xffffffffffffffff,%rax
 1020b8d:	je     1020ba8 <retain_pointer+0x88>
 1020b8f:	test   %rax,%rax
 1020b92:	jne    1020b9b <retain_pointer+0x7b>
 1020b94:	cmpq   $0x0,-0x18(%rdx)
 1020b99:	je     1020bae <retain_pointer+0x8e>
 1020b9b:	inc    %rax
 1020b9e:	mov    %rax,-0x20(%rdx)
 1020ba2:	mov    %rdx,(%rsi)
 1020ba5:	xor    %eax,%eax
 1020ba7:	ret
 1020ba8:	mov    $0x2,%eax
 1020bad:	ret
 1020bae:	push   %rbp
 1020baf:	mov    %rsp,%rbp
 1020bb2:	call   10187d4 <myl_rc_invariant_failed>
 1020bb7:	int3
 1020bb8:	int3
 1020bb9:	int3
 1020bba:	int3
 1020bbb:	int3
 1020bbc:	int3
 1020bbd:	int3
 1020bbe:	int3
 1020bbf:	int3

0000000001020bc0 <clone_payload>:
 1020bc0:	push   %rbp
 1020bc1:	mov    %rsp,%rbp
 1020bc4:	push   %r15
 1020bc6:	push   %r14
 1020bc8:	push   %r13
 1020bca:	push   %r12
 1020bcc:	push   %rbx
 1020bcd:	sub    $0x208,%rsp
 1020bd4:	mov    %rcx,-0x30(%rbp)
 1020bd8:	mov    %rdi,%r14
 1020bdb:	vxorps %xmm0,%xmm0,%xmm0
 1020bdf:	vmovups %ymm0,-0x90(%rbp)
 1020be7:	vmovups %ymm0,-0xb0(%rbp)
 1020bef:	vmovups %ymm0,-0xd0(%rbp)
 1020bf7:	vmovups %ymm0,-0xf0(%rbp)
 1020bff:	vmovups %ymm0,-0x110(%rbp)
 1020c07:	vmovups %ymm0,-0x130(%rbp)
 1020c0f:	movq   $0x0,-0x70(%rbp)
 1020c17:	mov    -0x10(%rsi),%rax
 1020c1b:	xor    %ebx,%ebx
 1020c1d:	bt     $0x3d,%rax
 1020c22:	mov    $0x0,%ecx
 1020c27:	jae    1020c50 <clone_payload+0x90>
 1020c29:	mov    -0x8(%rsi),%rdi
 1020c2d:	mov    $0x1,%ecx
 1020c32:	cmp    $0x100b618,%rdi
 1020c39:	je     1020c50 <clone_payload+0x90>
 1020c3b:	cmp    $0x100b510,%rdi
 1020c42:	je     1020c50 <clone_payload+0x90>
 1020c44:	xor    %ecx,%ecx
 1020c46:	cmp    $0x100b4a0,%rdi
 1020c4d:	sete   %cl
 1020c50:	mov    %rax,%r15
 1020c53:	shr    $0x28,%r15
 1020c57:	and    $0xfffff,%r15d
 1020c5e:	cmp    %edx,%r15d
 1020c61:	cmovae %edx,%r15d
 1020c65:	mov    %ecx,-0x84(%rbp)
 1020c6b:	bt     $0x3e,%rax
 1020c70:	cmovae %ebx,%r15d
 1020c74:	test   %ecx,%ecx
 1020c76:	cmove  %edx,%r15d
 1020c7a:	mov    %r14,-0x68(%rbp)
 1020c7e:	lea    -0x230(%rbp),%rax
 1020c85:	mov    %rax,-0x60(%rbp)
 1020c89:	movq   $0x8,-0x58(%rbp)
 1020c91:	movq   $0x0,-0x50(%rbp)
 1020c99:	mov    %r15d,-0x48(%rbp)
 1020c9d:	movl   $0x0,-0x44(%rbp)
 1020ca4:	lea    -0x130(%rbp),%r13
 1020cab:	mov    %r13,-0x40(%rbp)
 1020caf:	lea    -0x68(%rbp),%rdi
 1020cb3:	lea    -0x38(%rbp),%rcx
 1020cb7:	mov    %r15d,%edx
 1020cba:	vzeroupper
 1020cbd:	call   101f090 <schedule_clone>
 1020cc2:	test   %eax,%eax
 1020cc4:	jne    1020cdc <clone_payload+0x11c>
 1020cc6:	lea    -0x68(%rbp),%rdi
 1020cca:	call   101ffd0 <finish_clones>
 1020ccf:	xor    %r12d,%r12d
 1020cd2:	mov    -0x40(%rbp),%r13
 1020cd6:	test   %eax,%eax
 1020cd8:	je     1020cfc <clone_payload+0x13c>
 1020cda:	xor    %ebx,%ebx
 1020cdc:	mov    %eax,%r12d
 1020cdf:	movq   $0x0,0xb8(%r13)
 1020cea:	mov    -0x38(%rbp),%r13
 1020cee:	test   %r15d,%r15d
 1020cf1:	je     1020d94 <clone_payload+0x1d4>
 1020cf7:	jmp    1020dcc <clone_payload+0x20c>
 1020cfc:	mov    0xb8(%r13),%rsi
 1020d03:	mov    $0x1,%bl
 1020d05:	test   %rsi,%rsi
 1020d08:	je     1020d80 <clone_payload+0x1c0>
 1020d0a:	movabs $0x2000000000000000,%rax
 1020d14:	mov    0xb0(%r13),%rdx
 1020d1b:	mov    %esi,%ecx
 1020d1d:	and    $0x3,%ecx
 1020d20:	cmp    $0x4,%rsi
 1020d24:	jae    1020d2a <clone_payload+0x16a>
 1020d26:	xor    %edi,%edi
 1020d28:	jmp    1020d65 <clone_payload+0x1a5>
 1020d2a:	and    $0xfffffffffffffffc,%rsi
 1020d2e:	xor    %edi,%edi
 1020d30:	mov    (%rdx,%rdi,8),%r8
 1020d34:	or     %rax,-0x10(%r8)
 1020d38:	mov    0x8(%rdx,%rdi,8),%r8
 1020d3d:	or     %rax,-0x10(%r8)
 1020d41:	mov    0x10(%rdx,%rdi,8),%r8
 1020d46:	or     %rax,-0x10(%r8)
 1020d4a:	mov    0x18(%rdx,%rdi,8),%r8
 1020d4f:	or     %rax,-0x10(%r8)
 1020d53:	add    $0x4,%rdi
 1020d57:	cmp    %rdi,%rsi
 1020d5a:	jne    1020d30 <clone_payload+0x170>
 1020d5c:	test   %rcx,%rcx
 1020d5f:	je     1020e02 <clone_payload+0x242>
 1020d65:	lea    (%rdx,%rdi,8),%rdx
 1020d69:	xor    %r12d,%r12d
 1020d6c:	xor    %esi,%esi
 1020d6e:	xchg   %ax,%ax
 1020d70:	mov    (%rdx,%rsi,8),%rdi
 1020d74:	or     %rax,-0x10(%rdi)
 1020d78:	inc    %rsi
 1020d7b:	cmp    %rsi,%rcx
 1020d7e:	jne    1020d70 <clone_payload+0x1b0>
 1020d80:	movq   $0x0,0xb8(%r13)
 1020d8b:	mov    -0x38(%rbp),%r13
 1020d8f:	test   %r15d,%r15d
 1020d92:	jne    1020dcc <clone_payload+0x20c>
 1020d94:	test   %r12d,%r12d
 1020d97:	je     1020dcc <clone_payload+0x20c>
 1020d99:	test   %r13,%r13
 1020d9c:	je     1020dcc <clone_payload+0x20c>
 1020d9e:	mov    %r14,%rdi
 1020da1:	mov    %r13,%rsi
 1020da4:	call   1018bc0 <myl_rc_edge_release>
 1020da9:	test   %r14,%r14
 1020dac:	je     1020dcc <clone_payload+0x20c>
 1020dae:	mov    0x1608(%r14),%rax
 1020db5:	test   %rax,%rax
 1020db8:	je     1020dcc <clone_payload+0x20c>
 1020dba:	cmpq   $0x0,0xc8(%rax)
 1020dc2:	je     1020dcc <clone_payload+0x20c>
 1020dc4:	mov    %r14,%rdi
 1020dc7:	call   101bcb0 <myl_rc_drain>
 1020dcc:	xor    %esi,%esi
 1020dce:	test   %r12d,%r12d
 1020dd1:	setne  %sil
 1020dd5:	lea    -0x68(%rbp),%rdi
 1020dd9:	call   1020760 <dispose_walk>
 1020dde:	xor    %eax,%eax
 1020de0:	test   %bl,%bl
 1020de2:	cmovne %r13,%rax
 1020de6:	mov    -0x30(%rbp),%rcx
 1020dea:	mov    %rax,(%rcx)
 1020ded:	mov    %r12d,%eax
 1020df0:	add    $0x208,%rsp
 1020df7:	pop    %rbx
 1020df8:	pop    %r12
 1020dfa:	pop    %r13
 1020dfc:	pop    %r14
 1020dfe:	pop    %r15
 1020e00:	pop    %rbp
 1020e01:	ret
 1020e02:	xor    %r12d,%r12d
 1020e05:	movq   $0x0,0xb8(%r13)
 1020e10:	mov    -0x38(%rbp),%r13
 1020e14:	test   %r15d,%r15d
 1020e17:	je     1020d94 <clone_payload+0x1d4>
 1020e1d:	jmp    1020dcc <clone_payload+0x20c>
 1020e1f:	int3

0000000001020e20 <myl_rc_storage_alloc>:
 1020e20:	push   %rbp
 1020e21:	mov    %rsp,%rbp
 1020e24:	push   %r15
 1020e26:	push   %r14
 1020e28:	push   %r13
 1020e2a:	push   %r12
 1020e2c:	push   %rbx
 1020e2d:	sub    $0x28,%rsp
 1020e31:	test   %rdi,%rdi
 1020e34:	je     10211ef <myl_rc_storage_alloc+0x3cf>
 1020e3a:	mov    %rsi,%r14
 1020e3d:	test   %rsi,%rsi
 1020e40:	je     10211ef <myl_rc_storage_alloc+0x3cf>
 1020e46:	mov    %rdi,%rbx
 1020e49:	mov    0x1608(%rdi),%rdi
 1020e50:	test   %rdi,%rdi
 1020e53:	je     10211ef <myl_rc_storage_alloc+0x3cf>
 1020e59:	mov    %ecx,%r12d
 1020e5c:	mov    %rdx,%r15
 1020e5f:	test   %ecx,%ecx
 1020e61:	setne  %al
 1020e64:	cmp    $0x1,%rdx
 1020e68:	setne  %cl
 1020e6b:	or     %al,%cl
 1020e6d:	jne    1020e78 <myl_rc_storage_alloc+0x58>
 1020e6f:	cmpq   $0x1021230,(%rdi)
 1020e76:	je     1020ef1 <myl_rc_storage_alloc+0xd1>
 1020e78:	cmp    %r14,0x110(%rdi)
 1020e7f:	je     1020e95 <myl_rc_storage_alloc+0x75>
 1020e81:	mov    %rbx,%rdi
 1020e84:	mov    %r14,%rsi
 1020e87:	call   1023330 <myl_rc_native_shape>
 1020e8c:	test   %rax,%rax
 1020e8f:	je     10211d9 <myl_rc_storage_alloc+0x3b9>
 1020e95:	test   %r12d,%r12d
 1020e98:	setne  %al
 1020e9b:	cmp    $0x2,%r15
 1020e9f:	setb   %cl
 1020ea2:	or     %al,%cl
 1020ea4:	jne    1021148 <myl_rc_storage_alloc+0x328>
 1020eaa:	mov    (%r14),%r13
 1020ead:	test   %r13,%r13
 1020eb0:	je     1021148 <myl_rc_storage_alloc+0x328>
 1020eb6:	cmpq   $0x10,0x8(%r14)
 1020ebb:	ja     1021148 <myl_rc_storage_alloc+0x328>
 1020ec1:	mov    0x1608(%rbx),%rax
 1020ec8:	cmpq   $0x1021230,(%rax)
 1020ecf:	jne    1021148 <myl_rc_storage_alloc+0x328>
 1020ed5:	cmp    $0x1fe0,%r13
 1020edc:	ja     1021064 <myl_rc_storage_alloc+0x244>
 1020ee2:	mov    $0x1fe0,%eax
 1020ee7:	xor    %edx,%edx
 1020ee9:	div    %r13d
 1020eec:	jmp    1021066 <myl_rc_storage_alloc+0x246>
 1020ef1:	mov    0x20(%rdi),%r13
 1020ef5:	cmp    %r14,0x210(%r13)
 1020efc:	je     1020f9f <myl_rc_storage_alloc+0x17f>
 1020f02:	mov    0x34(%r14),%eax
 1020f06:	cmp    %rax,0xa0(%rdi)
 1020f0d:	jbe    102110d <myl_rc_storage_alloc+0x2ed>
 1020f13:	mov    0x98(%rdi),%rcx
 1020f1a:	shl    $0x4,%rax
 1020f1e:	cmp    %r14,(%rcx,%rax,1)
 1020f22:	jne    102110d <myl_rc_storage_alloc+0x2ed>
 1020f28:	add    %rax,%rcx
 1020f2b:	mov    0x8(%rcx),%rax
 1020f2f:	test   %rax,%rax
 1020f32:	je     102111e <myl_rc_storage_alloc+0x2fe>
 1020f38:	mov    0xc0(%rax),%esi
 1020f3e:	test   %esi,%esi
 1020f40:	je     102111e <myl_rc_storage_alloc+0x2fe>
 1020f46:	dec    %esi
 1020f48:	mov    %r14,0x210(%r13)
 1020f4f:	mov    %rsi,0x218(%r13)
 1020f56:	mov    0x1610(%rbx,%rsi,8),%r15
 1020f5e:	test   %r15,%r15
 1020f61:	jne    1020fb3 <myl_rc_storage_alloc+0x193>
 1020f63:	mov    %rbx,%rdi
 1020f66:	call   1021eb0 <slab_refill>
 1020f6b:	mov    %rax,%r15
 1020f6e:	test   %rax,%rax
 1020f71:	jne    1020fbe <myl_rc_storage_alloc+0x19e>
 1020f73:	mov    0x1608(%rbx),%rax
 1020f7a:	test   %rax,%rax
 1020f7d:	je     10211ef <myl_rc_storage_alloc+0x3cf>
 1020f83:	cmpl   $0x0,0x124(%rax)
 1020f8a:	jne    10211d9 <myl_rc_storage_alloc+0x3b9>
 1020f90:	movl   $0x1,0x124(%rax)
 1020f9a:	jmp    10211d9 <myl_rc_storage_alloc+0x3b9>
 1020f9f:	mov    0x218(%r13),%rsi
 1020fa6:	mov    0x1610(%rbx,%rsi,8),%r15
 1020fae:	test   %r15,%r15
 1020fb1:	je     1020f63 <myl_rc_storage_alloc+0x143>
 1020fb3:	mov    (%r15),%rax
 1020fb6:	mov    %rax,0x1610(%rbx,%rsi,8)
 1020fbe:	lea    0x20(%r15),%rax
 1020fc2:	mov    (%r14),%rdx
 1020fc5:	lea    0xf(%rdx),%rcx
 1020fc9:	shr    $0x4,%rcx
 1020fcd:	cmp    $0x8,%rcx
 1020fd1:	ja     10210ae <myl_rc_storage_alloc+0x28e>
 1020fd7:	jmp    *0x1001c10(,%rcx,8)
 1020fde:	vxorps %xmm0,%xmm0,%xmm0
 1020fe2:	vmovaps %xmm0,0x90(%r15)
 1020feb:	vxorps %xmm0,%xmm0,%xmm0
 1020fef:	vmovaps %xmm0,0x80(%r15)
 1020ff8:	vxorps %xmm0,%xmm0,%xmm0
 1020ffc:	vmovaps %xmm0,0x70(%r15)
 1021002:	vxorps %xmm0,%xmm0,%xmm0
 1021006:	vmovaps %xmm0,0x60(%r15)
 102100c:	vxorps %xmm0,%xmm0,%xmm0
 1021010:	vmovaps %xmm0,0x50(%r15)
 1021016:	vxorps %xmm0,%xmm0,%xmm0
 102101a:	vmovaps %xmm0,0x40(%r15)
 1021020:	vxorps %xmm0,%xmm0,%xmm0
 1021024:	vmovaps %xmm0,0x30(%r15)
 102102a:	vxorps %xmm0,%xmm0,%xmm0
 102102e:	vmovaps %xmm0,(%rax)
 1021032:	movq   $0x1,(%r15)
 1021039:	movq   $0x0,0x8(%r15)
 1021041:	movq   $0x4,0x10(%r15)
 1021049:	mov    %r14,0x18(%r15)
 102104d:	vmovdqu 0x40(%rbx),%xmm0
 1021052:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1021056:	vpsubq %xmm1,%xmm0,%xmm0
 102105a:	vmovdqu %xmm0,0x40(%rbx)
 102105f:	jmp    10211db <myl_rc_storage_alloc+0x3bb>
 1021064:	xor    %eax,%eax
 1021066:	cmp    %rax,%r15
 1021069:	ja     1021148 <myl_rc_storage_alloc+0x328>
 102106f:	imul   %r15,%r13
 1021073:	lea    0x20(%r13),%rax
 1021077:	mov    $0x20,%esi
 102107c:	cmp    $0x2000,%rax
 1021082:	ja     1021093 <myl_rc_storage_alloc+0x273>
 1021084:	lea    0x2f(%r13),%rax
 1021088:	shr    $0x4,%rax
 102108c:	movzbl 0x100b820(%rax),%esi
 1021093:	mov    0x1610(%rbx,%rsi,8),%r12
 102109b:	test   %r12,%r12
 102109e:	je     10210c3 <myl_rc_storage_alloc+0x2a3>
 10210a0:	mov    (%r12),%rax
 10210a4:	mov    %rax,0x1610(%rbx,%rsi,8)
 10210ac:	jmp    10210d7 <myl_rc_storage_alloc+0x2b7>
 10210ae:	mov    %rax,%rdi
 10210b1:	xor    %esi,%esi
 10210b3:	mov    %rax,%r12
 10210b6:	call   10274d0 <memset@plt>
 10210bb:	mov    %r12,%rax
 10210be:	jmp    1021032 <myl_rc_storage_alloc+0x212>
 10210c3:	mov    %rbx,%rdi
 10210c6:	call   1021eb0 <slab_refill>
 10210cb:	mov    %rax,%r12
 10210ce:	test   %rax,%rax
 10210d1:	je     1020f73 <myl_rc_storage_alloc+0x153>
 10210d7:	lea    0x20(%r12),%rdi
 10210dc:	mov    %r13,%rsi
 10210df:	call   1022250 <zero_payload>
 10210e4:	lea    0x20(%r12),%rax
 10210e9:	movq   $0x1,(%r12)
 10210f1:	movq   $0x0,0x8(%r12)
 10210fa:	shl    $0x2,%r15
 10210fe:	mov    %r15,0x10(%r12)
 1021103:	mov    %r14,0x18(%r12)
 1021108:	jmp    102104d <myl_rc_storage_alloc+0x22d>
 102110d:	mov    %r14,%rsi
 1021110:	call   1018df4 <myl_rc_binding_find_slow>
 1021115:	test   %rax,%rax
 1021118:	jne    1020f38 <myl_rc_storage_alloc+0x118>
 102111e:	mov    %rbx,%rdi
 1021121:	mov    %r14,%rsi
 1021124:	call   1023330 <myl_rc_native_shape>
 1021129:	test   %rax,%rax
 102112c:	je     10211d9 <myl_rc_storage_alloc+0x3b9>
 1021132:	cmpq   $0x10,0x8(%r14)
 1021137:	ja     1021148 <myl_rc_storage_alloc+0x328>
 1021139:	mov    (%r14),%rax
 102113c:	cmp    $0x1fe0,%rax
 1021142:	jbe    10211f4 <myl_rc_storage_alloc+0x3d4>
 1021148:	mov    %r14,-0x48(%rbp)
 102114c:	mov    %r15,-0x40(%rbp)
 1021150:	mov    %r12d,-0x38(%rbp)
 1021154:	movl   $0x0,-0x34(%rbp)
 102115b:	mov    0x1608(%rbx),%r8
 1021162:	test   %r8,%r8
 1021165:	je     10211ef <myl_rc_storage_alloc+0x3cf>
 102116b:	movq   $0x0,-0x30(%rbp)
 1021173:	mov    %r15,%rax
 1021176:	mulq   (%r14)
 1021179:	mov    $0x1,%ecx
 102117e:	jo     10211c8 <myl_rc_storage_alloc+0x3a8>
 1021180:	xor    %edx,%edx
 1021182:	test   %r12d,%r12d
 1021185:	sete   %dl
 1021188:	shl    $0x4,%edx
 102118b:	add    $0x10,%rdx
 102118f:	add    %rdx,%rax
 1021192:	jb     10211c8 <myl_rc_storage_alloc+0x3a8>
 1021194:	mov    $0x3,%ecx
 1021199:	cmp    0x70(%rbx),%r12d
 102119d:	ja     10211c8 <myl_rc_storage_alloc+0x3a8>
 102119f:	lea    -0x48(%rbp),%rsi
 10211a3:	lea    -0x30(%rbp),%rdx
 10211a7:	mov    %rbx,%rdi
 10211aa:	call   *(%r8)
 10211ad:	mov    %eax,%ecx
 10211af:	mov    -0x30(%rbp),%rax
 10211b3:	test   %ecx,%ecx
 10211b5:	je     10211ea <myl_rc_storage_alloc+0x3ca>
 10211b7:	test   %rax,%rax
 10211ba:	jne    10211ef <myl_rc_storage_alloc+0x3cf>
 10211bc:	mov    0x1608(%rbx),%r8
 10211c3:	test   %r8,%r8
 10211c6:	je     10211ef <myl_rc_storage_alloc+0x3cf>
 10211c8:	cmpl   $0x0,0x124(%r8)
 10211d0:	jne    10211d9 <myl_rc_storage_alloc+0x3b9>
 10211d2:	mov    %ecx,0x124(%r8)
 10211d9:	xor    %eax,%eax
 10211db:	add    $0x28,%rsp
 10211df:	pop    %rbx
 10211e0:	pop    %r12
 10211e2:	pop    %r13
 10211e4:	pop    %r14
 10211e6:	pop    %r15
 10211e8:	pop    %rbp
 10211e9:	ret
 10211ea:	test   %rax,%rax
 10211ed:	jne    10211db <myl_rc_storage_alloc+0x3bb>
 10211ef:	call   10187d4 <myl_rc_invariant_failed>
 10211f4:	add    $0x2f,%rax
 10211f8:	shr    $0x4,%rax
 10211fc:	movzbl 0x100b820(%rax),%r15d
 1021204:	mov    0x1608(%rbx),%rdi
 102120b:	mov    %r14,%rsi
 102120e:	call   1021e80 <myl_rc_binding_find>
 1021213:	mov    %r15,%rsi
 1021216:	mov    %esi,%ecx
 1021218:	inc    %ecx
 102121a:	mov    %ecx,0xc0(%rax)
 1021220:	jmp    1020f48 <myl_rc_storage_alloc+0x128>
 1021225:	int3
 1021226:	int3
 1021227:	int3
 1021228:	int3
 1021229:	int3
 102122a:	int3
 102122b:	int3
 102122c:	int3
 102122d:	int3
 102122e:	int3
 102122f:	int3

0000000001021230 <allocate>:
 1021230:	push   %rbp
 1021231:	mov    %rsp,%rbp
 1021234:	push   %r15
 1021236:	push   %r14
 1021238:	push   %r13
 102123a:	push   %r12
 102123c:	push   %rbx
 102123d:	sub    $0x48,%rsp
 1021241:	mov    %rdi,%rbx
 1021244:	movq   $0x0,(%rdx)
 102124b:	mov    0x10(%rsi),%r15d
 102124f:	mov    (%rsi),%r13
 1021252:	test   %r15,%r15
 1021255:	je     102127e <allocate+0x4e>
 1021257:	mov    0x8(%rsi),%rsi
 102125b:	mov    %rsi,%rax
 102125e:	shr    $0x26,%rax
 1021262:	setne  %al
 1021265:	cmp    $0x100000,%r15d
 102126c:	setae  %cl
 102126f:	or     %al,%cl
 1021271:	je     1021336 <allocate+0x106>
 1021277:	xor    %ecx,%ecx
 1021279:	jmp    1021d5f <allocate+0xb2f>
 102127e:	mov    $0x1,%eax
 1021283:	test   %r13,%r13
 1021286:	je     1021d6a <allocate+0xb3a>
 102128c:	cmpq   $0x10,0x8(%r13)
 1021291:	ja     1021d6a <allocate+0xb3a>
 1021297:	mov    0x8(%rsi),%rdi
 102129b:	mov    %rdi,%rcx
 102129e:	shr    $0x3a,%rcx
 10212a2:	jne    1021d6a <allocate+0xb3a>
 10212a8:	mov    0x0(%r13),%r14
 10212ac:	test   %r14,%r14
 10212af:	je     10212d4 <allocate+0xa4>
 10212b1:	mov    $0xffffffffffffffdf,%rax
 10212b8:	mov    %rdx,%rcx
 10212bb:	xor    %edx,%edx
 10212bd:	div    %r14
 10212c0:	mov    %rcx,%rdx
 10212c3:	mov    %rax,%rcx
 10212c6:	mov    $0x1,%eax
 10212cb:	cmp    %rcx,%rdi
 10212ce:	ja     1021d6a <allocate+0xb3a>
 10212d4:	test   %rbx,%rbx
 10212d7:	je     1021e78 <allocate+0xc48>
 10212dd:	cmpq   $0x0,0x1608(%rbx)
 10212e5:	je     1021e78 <allocate+0xc48>
 10212eb:	imul   %rdi,%r14
 10212ef:	lea    0x20(%r14),%r12
 10212f3:	cmp    $0x2000,%r12
 10212fa:	ja     10217b8 <allocate+0x588>
 1021300:	mov    %rsi,%r12
 1021303:	mov    %rdx,%r13
 1021306:	lea    0x2f(%r14),%rax
 102130a:	shr    $0x4,%rax
 102130e:	movzbl 0x100b820(%rax),%esi
 1021315:	mov    0x1610(%rbx,%rsi,8),%r15
 102131d:	test   %r15,%r15
 1021320:	je     1021a4e <allocate+0x81e>
 1021326:	mov    (%r15),%rax
 1021329:	mov    %rax,0x1610(%rbx,%rsi,8)
 1021331:	jmp    1021a67 <allocate+0x837>
 1021336:	mov    %r15d,%r10d
 1021339:	mov    0x0(%r13),%r14
 102133d:	mov    %rsi,-0x70(%rbp)
 1021341:	imul   %rsi,%r14
 1021345:	cmp    $0x1,%r14
 1021349:	mov    %r14,%r11
 102134c:	adc    $0x0,%r11
 1021350:	cmpl   $0x0,0x68(%rbx)
 1021354:	je     1021360 <allocate+0x130>
 1021356:	cmpl   $0x0,0x74(%rbx)
 102135a:	je     1021437 <allocate+0x207>
 1021360:	mov    0x11a0(%rbx),%rax
 1021367:	test   %rax,%rax
 102136a:	je     1021479 <allocate+0x249>
 1021370:	mov    0x5c0(%rbx),%rcx
 1021377:	mov    0x5c8(%rbx),%rsi
 102137e:	mov    %rsi,%rdi
 1021381:	sub    %rcx,%rdi
 1021384:	sub    $0x10,%rdi
 1021388:	setb   %r8b
 102138c:	cmp    %r10d,0x20(%rax)
 1021390:	jne    1021410 <allocate+0x1e0>
 1021392:	test   %r8b,%r8b
 1021395:	jne    1021410 <allocate+0x1e0>
 1021397:	cmp    %rdi,%r11
 102139a:	ja     1021410 <allocate+0x1e0>
 102139c:	shl    $0x28,%r15
 10213a0:	mov    -0x70(%rbp),%rdi
 10213a4:	lea    (%r15,%rdi,4),%rdi
 10213a8:	movabs $0x4000000000000000,%r8
 10213b2:	or     %rdi,%r8
 10213b5:	mov    %r8,(%rcx)
 10213b8:	mov    %r13,0x8(%rcx)
 10213bc:	incq   0x18(%rax)
 10213c0:	lea    0x50(%rax),%rdi
 10213c4:	sub    %rdi,%r11
 10213c7:	lea    (%r11,%rcx,1),%rdi
 10213cb:	add    $0x1f,%rdi
 10213cf:	and    $0xfffffffffffffff0,%rdi
 10213d3:	mov    0x8(%rax),%r8
 10213d7:	add    $0xffffffffffffffb0,%r8
 10213db:	cmp    %r8,%rdi
 10213de:	lea    0x50(%rax,%rdi,1),%rax
 10213e3:	cmovb  %rax,%rsi
 10213e7:	mov    %rsi,0x5c0(%rbx)
 10213ee:	vmovdqu 0x40(%rbx),%xmm0
 10213f3:	vpcmpeqd %xmm1,%xmm1,%xmm1
 10213f7:	vpsubq %xmm1,%xmm0,%xmm0
 10213fb:	vmovdqu %xmm0,0x40(%rbx)
 1021400:	incq   0x90(%rbx)
 1021407:	add    $0x10,%rcx
 102140b:	jmp    1021d5f <allocate+0xb2f>
 1021410:	lea    0x5c0(%rbx),%rsi
 1021417:	sub    %rax,%rcx
 102141a:	add    $0xffffffffffffffb0,%rcx
 102141e:	mov    %rcx,0x10(%rax)
 1021422:	movq   $0x0,0x11a0(%rbx)
 102142d:	vpxor  %xmm0,%xmm0,%xmm0
 1021431:	vmovdqu %xmm0,(%rsi)
 1021435:	jmp    1021479 <allocate+0x249>
 1021437:	mov    %r11,-0x38(%rbp)
 102143b:	mov    %r10d,-0x2c(%rbp)
 102143f:	mov    %rdx,%r12
 1021442:	cmpq   $0x0,0x1608(%rbx)
 102144a:	je     1021456 <allocate+0x226>
 102144c:	mov    %rbx,%rdi
 102144f:	call   101bcb0 <myl_rc_drain>
 1021454:	jmp    102145e <allocate+0x22e>
 1021456:	mov    %rbx,%rdi
 1021459:	call   1015520 <collect>
 102145e:	mov    %r12,%rdx
 1021461:	mov    -0x2c(%rbp),%r10d
 1021465:	mov    -0x38(%rbp),%r11
 1021469:	mov    0x11a0(%rbx),%rax
 1021470:	test   %rax,%rax
 1021473:	jne    1021370 <allocate+0x140>
 1021479:	cmp    %r15,0x11e8(%rbx)
 1021480:	jbe    10214a4 <allocate+0x274>
 1021482:	mov    0x4d8(%rbx),%rax
 1021489:	mov    (%rax,%r15,8),%r12
 102148d:	test   %r12,%r12
 1021490:	je     10214a4 <allocate+0x274>
 1021492:	mov    0x10(%r12),%rax
 1021497:	cmp    $0xfffffffffffffff1,%rax
 102149b:	jb     10214b2 <allocate+0x282>
 102149d:	mov    0x8(%r12),%rcx
 10214a2:	jmp    10214e4 <allocate+0x2b4>
 10214a4:	xor    %eax,%eax
 10214a6:	cmp    $0xffffffffffffff90,%r14
 10214aa:	ja     1021277 <allocate+0x47>
 10214b0:	jmp    1021500 <allocate+0x2d0>
 10214b2:	add    $0xf,%rax
 10214b6:	and    $0xfffffffffffffff0,%rax
 10214ba:	mov    0x8(%r12),%rcx
 10214bf:	lea    -0x50(%rcx),%rsi
 10214c3:	sub    %rax,%rsi
 10214c6:	jb     10214e4 <allocate+0x2b4>
 10214c8:	sub    $0x10,%rsi
 10214cc:	setb   %dil
 10214d0:	cmp    %rsi,%r11
 10214d3:	seta   %sil
 10214d7:	or     %dil,%sil
 10214da:	cmp    $0x1,%sil
 10214de:	jne    1021c2d <allocate+0x9fd>
 10214e4:	cmp    $0x80000,%rcx
 10214eb:	mov    $0x80000,%eax
 10214f0:	cmovb  %rcx,%rax
 10214f4:	add    %eax,%eax
 10214f6:	cmp    $0xffffffffffffff90,%r14
 10214fa:	ja     1021277 <allocate+0x47>
 1021500:	mov    %r13,-0x58(%rbp)
 1021504:	lea    0x6f(%r11),%r12
 1021508:	and    $0xfffffffffffffff0,%r12
 102150c:	cmp    %r12,%rax
 102150f:	cmovbe %r12,%rax
 1021513:	cmp    $0x10001,%rax
 1021519:	mov    $0x10000,%r9d
 102151f:	cmovae %rax,%r9
 1021523:	mov    0x1608(%rbx),%r13
 102152a:	mov    0x11f0(%rbx),%rcx
 1021531:	test   %r13,%r13
 1021534:	mov    %r9,-0x48(%rbp)
 1021538:	je     10215b7 <allocate+0x387>
 102153a:	cmp    %r15,%rcx
 102153d:	jbe    10216ec <allocate+0x4bc>
 1021543:	mov    %rcx,-0x50(%rbp)
 1021547:	movq   $0x0,-0x68(%rbp)
 102154f:	mov    -0x58(%rbp),%r13
 1021553:	lea    0x4e0(%rbx),%r14
 102155a:	mov    0x4e0(%rbx),%rdi
 1021561:	test   %rdi,%rdi
 1021564:	mov    %r11,-0x38(%rbp)
 1021568:	je     1021799 <allocate+0x569>
 102156e:	xor    %eax,%eax
 1021570:	mov    %rdi,%r8
 1021573:	mov    %r14,%rcx
 1021576:	jmp    102158f <allocate+0x35f>
 1021578:	nopl   0x0(%rax,%rax,1)
 1021580:	mov    %rsi,%rax
 1021583:	mov    (%rcx),%r8
 1021586:	test   %r8,%r8
 1021589:	je     1021740 <allocate+0x510>
 102158f:	mov    %rcx,%rsi
 1021592:	mov    %r8,%rcx
 1021595:	mov    0x8(%r8),%r8
 1021599:	cmp    %r12,%r8
 102159c:	jb     1021583 <allocate+0x353>
 102159e:	cmp    %r9,%r8
 10215a1:	ja     1021583 <allocate+0x353>
 10215a3:	test   %rax,%rax
 10215a6:	je     1021580 <allocate+0x350>
 10215a8:	mov    (%rax),%r9
 10215ab:	cmp    0x8(%r9),%r8
 10215af:	mov    -0x48(%rbp),%r9
 10215b3:	ja     1021580 <allocate+0x350>
 10215b5:	jmp    1021583 <allocate+0x353>
 10215b7:	cmp    %r15,%rcx
 10215ba:	mov    %r10d,-0x2c(%rbp)
 10215be:	ja     1021641 <allocate+0x411>
 10215c4:	mov    %r11,-0x38(%rbp)
 10215c8:	mov    %rdx,-0x40(%rbp)
 10215cc:	test   %rcx,%rcx
 10215cf:	mov    $0x8,%eax
 10215d4:	cmovne %rcx,%rax
 10215d8:	nopl   0x0(%rax,%rax,1)
 10215e0:	mov    %rax,%r13
 10215e3:	add    %rax,%rax
 10215e6:	cmp    %r15,%r13
 10215e9:	jbe    10215e0 <allocate+0x3b0>
 10215eb:	mov    0x4d8(%rbx),%rdi
 10215f2:	lea    0x0(,%r13,8),%rsi
 10215fa:	call   1027670 <realloc@plt>
 10215ff:	test   %rax,%rax
 1021602:	je     1021a43 <allocate+0x813>
 1021608:	mov    0x11f0(%rbx),%rcx
 102160f:	lea    (%rax,%rcx,8),%rdi
 1021613:	mov    %r13,%rdx
 1021616:	sub    %rcx,%rdx
 1021619:	shl    $0x3,%rdx
 102161d:	xor    %esi,%esi
 102161f:	mov    %rax,%r14
 1021622:	call   10274d0 <memset@plt>
 1021627:	mov    %r14,0x4d8(%rbx)
 102162e:	mov    %r13,0x11f0(%rbx)
 1021635:	mov    -0x40(%rbp),%rdx
 1021639:	mov    -0x38(%rbp),%r11
 102163d:	mov    -0x48(%rbp),%r9
 1021641:	mov    0x18(%rbx),%rcx
 1021645:	mov    0x58(%rbx),%rax
 1021649:	mov    %rax,%rsi
 102164c:	sub    %rcx,%rsi
 102164f:	jb     1021656 <allocate+0x426>
 1021651:	cmp    %rsi,%r12
 1021654:	jbe    102167e <allocate+0x44e>
 1021656:	cmpl   $0x0,0x74(%rbx)
 102165a:	jne    102167e <allocate+0x44e>
 102165c:	mov    %rbx,%rdi
 102165f:	mov    %rdx,%r14
 1021662:	mov    %r11,-0x38(%rbp)
 1021666:	call   10154f0 <myl_native_heap_collect>
 102166b:	mov    -0x48(%rbp),%r9
 102166f:	mov    -0x38(%rbp),%r11
 1021673:	mov    %r14,%rdx
 1021676:	mov    0x18(%rbx),%rcx
 102167a:	mov    0x58(%rbx),%rax
 102167e:	xor    %esi,%esi
 1021680:	sub    %rcx,%rax
 1021683:	cmovae %rax,%rsi
 1021687:	cmp    %rsi,%r12
 102168a:	ja     1021732 <allocate+0x502>
 1021690:	mov    %rsi,%r14
 1021693:	and    $0xfffffffffffffff0,%r14
 1021697:	cmp    %rsi,%r9
 102169a:	cmovb  %r9,%r14
 102169e:	mov    0x4e0(%rbx),%rsi
 10216a5:	test   %rsi,%rsi
 10216a8:	je     102189f <allocate+0x66f>
 10216ae:	lea    0x4e0(%rbx),%rcx
 10216b5:	xor    %eax,%eax
 10216b7:	jmp    10216c8 <allocate+0x498>
 10216b9:	mov    %rdi,%rax
 10216bc:	mov    (%rcx),%rsi
 10216bf:	test   %rsi,%rsi
 10216c2:	je     1021846 <allocate+0x616>
 10216c8:	mov    %rcx,%rdi
 10216cb:	mov    %rsi,%rcx
 10216ce:	mov    0x8(%rsi),%rsi
 10216d2:	cmp    %r12,%rsi
 10216d5:	jb     10216bc <allocate+0x48c>
 10216d7:	cmp    %r14,%rsi
 10216da:	ja     10216bc <allocate+0x48c>
 10216dc:	test   %rax,%rax
 10216df:	je     10216b9 <allocate+0x489>
 10216e1:	mov    (%rax),%r8
 10216e4:	cmp    0x8(%r8),%rsi
 10216e8:	ja     10216b9 <allocate+0x489>
 10216ea:	jmp    10216bc <allocate+0x48c>
 10216ec:	test   %rcx,%rcx
 10216ef:	mov    $0x8,%eax
 10216f4:	cmovne %rcx,%rax
 10216f8:	nopl   0x0(%rax,%rax,1)
 1021700:	mov    %rax,%r14
 1021703:	add    %rax,%rax
 1021706:	cmp    %r15,%r14
 1021709:	jbe    1021700 <allocate+0x4d0>
 102170b:	lea    0x0(,%r14,8),%rsi
 1021713:	mov    0x18(%rbx),%rdi
 1021717:	add    %rsi,%rdi
 102171a:	jb     1021732 <allocate+0x502>
 102171c:	mov    0x58(%rbx),%rax
 1021720:	test   %rax,%rax
 1021723:	je     10219cf <allocate+0x79f>
 1021729:	cmp    %rax,%rdi
 102172c:	jbe    10219cf <allocate+0x79f>
 1021732:	movl   $0x1,0x6c(%rbx)
 1021739:	xor    %ecx,%ecx
 102173b:	jmp    1021d5f <allocate+0xb2f>
 1021740:	test   %rax,%rax
 1021743:	je     1021799 <allocate+0x569>
 1021745:	mov    (%rax),%r12
 1021748:	mov    (%r12),%rcx
 102174c:	mov    %rcx,(%rax)
 102174f:	decq   0xc0(%rbx)
 1021756:	mov    0x8(%r12),%rax
 102175b:	sub    %rax,0xc8(%rbx)
 1021762:	lea    0x50(%r12),%rdi
 1021767:	mov    0x10(%r12),%rax
 102176c:	xor    %esi,%esi
 102176e:	mov    %rdx,-0x40(%rbp)
 1021772:	mov    %rax,%rdx
 1021775:	mov    %r10d,%r14d
 1021778:	call   10274d0 <memset@plt>
 102177d:	mov    %r14d,%r10d
 1021780:	mov    -0x40(%rbp),%rdx
 1021784:	vpxor  %xmm0,%xmm0,%xmm0
 1021788:	vmovdqa %xmm0,0x10(%r12)
 102178f:	mov    $0xa0,%eax
 1021794:	jmp    1021b5a <allocate+0x92a>
 1021799:	mov    0x18(%rbx),%rsi
 102179d:	mov    0x58(%rbx),%rcx
 10217a1:	test   %rcx,%rcx
 10217a4:	je     102193a <allocate+0x70a>
 10217aa:	xor    %eax,%eax
 10217ac:	sub    %rsi,%rcx
 10217af:	cmovae %rcx,%rax
 10217b3:	jmp    1021940 <allocate+0x710>
 10217b8:	cmp    $0xffffffffffffffcf,%r12
 10217bc:	ja     1021d6a <allocate+0xb3a>
 10217c2:	mov    %rsi,-0x70(%rbp)
 10217c6:	mov    %rdx,%r13
 10217c9:	add    $0x50,%r14
 10217cd:	mov    0x18(%rbx),%rax
 10217d1:	mov    %rax,%rcx
 10217d4:	add    %r14,%rcx
 10217d7:	jb     10217fd <allocate+0x5cd>
 10217d9:	mov    0x58(%rbx),%rcx
 10217dd:	test   %rcx,%rcx
 10217e0:	je     1021a7d <allocate+0x84d>
 10217e6:	sub    %rax,%rcx
 10217e9:	setb   %al
 10217ec:	cmp    %rcx,%r14
 10217ef:	seta   %cl
 10217f2:	or     %al,%cl
 10217f4:	cmp    $0x1,%cl
 10217f7:	jne    1021a7d <allocate+0x84d>
 10217fd:	mov    %rbx,%rdi
 1021800:	call   10222c0 <trim_empty>
 1021805:	mov    0x18(%rbx),%rax
 1021809:	mov    %rax,%rcx
 102180c:	add    %r14,%rcx
 102180f:	jb     1021835 <allocate+0x605>
 1021811:	mov    0x58(%rbx),%rcx
 1021815:	test   %rcx,%rcx
 1021818:	je     1021a7d <allocate+0x84d>
 102181e:	sub    %rax,%rcx
 1021821:	setb   %al
 1021824:	cmp    %rcx,%r14
 1021827:	seta   %cl
 102182a:	or     %al,%cl
 102182c:	cmp    $0x1,%cl
 102182f:	jne    1021a7d <allocate+0x84d>
 1021835:	movl   $0x1,0x6c(%rbx)
 102183c:	mov    $0x1,%eax
 1021841:	jmp    1021d6a <allocate+0xb3a>
 1021846:	test   %rax,%rax
 1021849:	je     102189f <allocate+0x66f>
 102184b:	mov    %rdx,%r13
 102184e:	mov    (%rax),%r12
 1021851:	mov    (%r12),%rcx
 1021855:	mov    %rcx,(%rax)
 1021858:	decq   0xc0(%rbx)
 102185f:	mov    0x8(%r12),%rax
 1021864:	sub    %rax,0xc8(%rbx)
 102186b:	lea    0x50(%r12),%rdi
 1021870:	mov    0x10(%r12),%rdx
 1021875:	xor    %esi,%esi
 1021877:	mov    %r11,%r14
 102187a:	call   10274d0 <memset@plt>
 102187f:	mov    %r14,%r11
 1021882:	vpxor  %xmm0,%xmm0,%xmm0
 1021886:	vmovdqa %xmm0,0x10(%r12)
 102188d:	incq   0xa0(%rbx)
 1021894:	mov    0x8(%r12),%r14
 1021899:	mov    -0x2c(%rbp),%r10d
 102189d:	jmp    10218d2 <allocate+0x6a2>
 102189f:	mov    %r11,-0x38(%rbp)
 10218a3:	mov    %rdx,%r13
 10218a6:	mov    $0x1,%edi
 10218ab:	mov    %r14,%rsi
 10218ae:	call   1027510 <calloc@plt>
 10218b3:	test   %rax,%rax
 10218b6:	je     1021d32 <allocate+0xb02>
 10218bc:	mov    %rax,%r12
 10218bf:	mov    %r14,0x8(%rax)
 10218c3:	incq   0x98(%rbx)
 10218ca:	mov    -0x2c(%rbp),%r10d
 10218ce:	mov    -0x38(%rbp),%r11
 10218d2:	add    %r14,0x18(%rbx)
 10218d6:	mov    0x4d8(%rbx),%rax
 10218dd:	mov    (%rax,%r15,8),%rcx
 10218e1:	mov    %rcx,(%r12)
 10218e5:	mov    %r10d,0x20(%r12)
 10218ea:	mov    %r12,(%rax,%r15,8)
 10218ee:	cmp    %r15,0x11e8(%rbx)
 10218f5:	ja     1021902 <allocate+0x6d2>
 10218f7:	lea    0x1(%r15),%rax
 10218fb:	mov    %rax,0x11e8(%rbx)
 1021902:	incq   0xa8(%rbx)
 1021909:	mov    0xb0(%rbx),%rax
 1021910:	add    0x8(%r12),%rax
 1021915:	mov    %rax,0xb0(%rbx)
 102191c:	cmp    0xb8(%rbx),%rax
 1021923:	mov    %r13,%rdx
 1021926:	jbe    102192f <allocate+0x6ff>
 1021928:	mov    %rax,0xb8(%rbx)
 102192f:	xor    %eax,%eax
 1021931:	mov    -0x58(%rbp),%r13
 1021935:	jmp    1021c2d <allocate+0x9fd>
 102193a:	mov    %rsi,%rax
 102193d:	not    %rax
 1021940:	xor    %ecx,%ecx
 1021942:	cmp    %rax,%r12
 1021945:	cmovbe %rdi,%rcx
 1021949:	mov    %rcx,-0x60(%rbp)
 102194d:	test   %rdi,%rdi
 1021950:	mov    %r10d,-0x2c(%rbp)
 1021954:	je     1021aab <allocate+0x87b>
 102195a:	cmp    %rax,%r12
 102195d:	jbe    1021aab <allocate+0x87b>
 1021963:	mov    %rdx,%r13
 1021966:	jmp    102197d <allocate+0x74d>
 1021968:	nopl   0x0(%rax,%rax,1)
 1021970:	call   1027570 <free@plt>
 1021975:	mov    (%r14),%rdi
 1021978:	test   %rdi,%rdi
 102197b:	je     102199b <allocate+0x76b>
 102197d:	mov    (%rdi),%rax
 1021980:	mov    %rax,0x4e0(%rbx)
 1021987:	cmpq   $0x0,0x1608(%rbx)
 102198f:	je     1021970 <allocate+0x740>
 1021991:	mov    0x8(%rdi),%rax
 1021995:	sub    %rax,0x18(%rbx)
 1021999:	jmp    1021970 <allocate+0x740>
 102199b:	vpxor  %xmm0,%xmm0,%xmm0
 102199f:	vmovdqu %xmm0,0xc0(%rbx)
 10219a7:	mov    0x18(%rbx),%rsi
 10219ab:	mov    0x58(%rbx),%rax
 10219af:	test   %rax,%rax
 10219b2:	je     1021a96 <allocate+0x866>
 10219b8:	xor    %edx,%edx
 10219ba:	sub    %rsi,%rax
 10219bd:	mov    $0x0,%ecx
 10219c2:	mov    %rcx,-0x60(%rbp)
 10219c6:	cmovb  %rdx,%rax
 10219ca:	jmp    1021aa4 <allocate+0x874>
 10219cf:	mov    %rdi,-0x60(%rbp)
 10219d3:	mov    %rcx,-0x50(%rbp)
 10219d7:	mov    %r11,-0x38(%rbp)
 10219db:	mov    %r10d,-0x2c(%rbp)
 10219df:	mov    %rdx,-0x40(%rbp)
 10219e3:	mov    $0x1,%edi
 10219e8:	call   1027510 <calloc@plt>
 10219ed:	test   %rax,%rax
 10219f0:	je     1021a43 <allocate+0x813>
 10219f2:	mov    -0x60(%rbp),%rcx
 10219f6:	mov    %rcx,0x18(%rbx)
 10219fa:	lea    0x0(,%r14,8),%rcx
 1021a02:	add    %rcx,0x30(%r13)
 1021a06:	mov    -0x50(%rbp),%rdx
 1021a0a:	test   %rdx,%rdx
 1021a0d:	mov    %rax,-0x68(%rbp)
 1021a11:	je     1021a26 <allocate+0x7f6>
 1021a13:	mov    0x4d8(%rbx),%rsi
 1021a1a:	shl    $0x3,%rdx
 1021a1e:	mov    %rax,%rdi
 1021a21:	call   1027520 <memcpy@plt>
 1021a26:	mov    %r14,-0x50(%rbp)
 1021a2a:	mov    -0x40(%rbp),%rdx
 1021a2e:	mov    -0x58(%rbp),%r13
 1021a32:	mov    -0x2c(%rbp),%r10d
 1021a36:	mov    -0x38(%rbp),%r11
 1021a3a:	mov    -0x48(%rbp),%r9
 1021a3e:	jmp    1021553 <allocate+0x323>
 1021a43:	xor    %ecx,%ecx
 1021a45:	mov    -0x40(%rbp),%rdx
 1021a49:	jmp    1021d5f <allocate+0xb2f>
 1021a4e:	mov    %rbx,%rdi
 1021a51:	call   1021eb0 <slab_refill>
 1021a56:	mov    %rax,%r15
 1021a59:	mov    $0x1,%eax
 1021a5e:	test   %r15,%r15
 1021a61:	je     1021d6a <allocate+0xb3a>
 1021a67:	lea    0x20(%r15),%rdi
 1021a6b:	mov    %r14,%rsi
 1021a6e:	call   1022250 <zero_payload>
 1021a73:	xor    %ecx,%ecx
 1021a75:	mov    %r12,%rax
 1021a78:	jmp    1021e32 <allocate+0xc02>
 1021a7d:	mov    %r14,%rdi
 1021a80:	call   10226b0 <large_block>
 1021a85:	test   %rax,%rax
 1021a88:	je     1021db3 <allocate+0xb83>
 1021a8e:	mov    %rax,%r15
 1021a91:	jmp    1021dd0 <allocate+0xba0>
 1021a96:	mov    %rsi,%rax
 1021a99:	not    %rax
 1021a9c:	movq   $0x0,-0x60(%rbp)
 1021aa4:	mov    %r13,%rdx
 1021aa7:	mov    -0x48(%rbp),%r9
 1021aab:	cmp    %rax,%r12
 1021aae:	jbe    1021b07 <allocate+0x8d7>
 1021ab0:	movl   $0x1,0x6c(%rbx)
 1021ab7:	mov    -0x68(%rbp),%rdi
 1021abb:	test   %rdi,%rdi
 1021abe:	je     1021277 <allocate+0x47>
 1021ac4:	mov    -0x50(%rbp),%rsi
 1021ac8:	shl    $0x3,%rsi
 1021acc:	mov    0x18(%rbx),%rax
 1021ad0:	sub    %rsi,%rax
 1021ad3:	jb     1021e78 <allocate+0xc48>
 1021ad9:	mov    %rdx,%r14
 1021adc:	mov    0x1608(%rbx),%rcx
 1021ae3:	mov    0x30(%rcx),%rdx
 1021ae7:	sub    %rsi,%rdx
 1021aea:	jb     1021e78 <allocate+0xc48>
 1021af0:	mov    %rax,0x18(%rbx)
 1021af4:	mov    %rdx,0x30(%rcx)
 1021af8:	call   1027570 <free@plt>
 1021afd:	xor    %ecx,%ecx
 1021aff:	mov    %r14,%rdx
 1021b02:	jmp    1021d5f <allocate+0xb2f>
 1021b07:	mov    %r14,%r13
 1021b0a:	mov    %rsi,-0x48(%rbp)
 1021b0e:	mov    %rax,%r14
 1021b11:	and    $0xfffffffffffffff0,%r14
 1021b15:	cmp    %rax,%r9
 1021b18:	cmovb  %r9,%r14
 1021b1c:	mov    $0x1,%edi
 1021b21:	mov    %r14,%rsi
 1021b24:	mov    %rdx,-0x40(%rbp)
 1021b28:	call   1027510 <calloc@plt>
 1021b2d:	mov    -0x2c(%rbp),%r10d
 1021b31:	mov    -0x40(%rbp),%rdx
 1021b35:	mov    %rax,%r12
 1021b38:	test   %rax,%rax
 1021b3b:	je     1021cf4 <allocate+0xac4>
 1021b41:	mov    %r14,0x8(%r12)
 1021b46:	mov    -0x48(%rbp),%r13
 1021b4a:	add    %r14,%r13
 1021b4d:	mov    %r13,0x18(%rbx)
 1021b51:	mov    $0x98,%eax
 1021b56:	mov    -0x58(%rbp),%r13
 1021b5a:	incq   (%rbx,%rax,1)
 1021b5e:	mov    0x4d8(%rbx),%rdi
 1021b65:	cmpq   $0x0,-0x68(%rbp)
 1021b6a:	je     1021bd8 <allocate+0x9a8>
 1021b6c:	test   %rdi,%rdi
 1021b6f:	mov    -0x38(%rbp),%r11
 1021b73:	je     1021bc0 <allocate+0x990>
 1021b75:	mov    %r10d,-0x2c(%rbp)
 1021b79:	mov    0x11f0(%rbx),%rcx
 1021b80:	shl    $0x3,%rcx
 1021b84:	mov    0x18(%rbx),%rax
 1021b88:	sub    %rcx,%rax
 1021b8b:	jb     1021e78 <allocate+0xc48>
 1021b91:	mov    %rdx,%r14
 1021b94:	mov    0x1608(%rbx),%rdx
 1021b9b:	mov    0x30(%rdx),%rsi
 1021b9f:	sub    %rcx,%rsi
 1021ba2:	jb     1021e78 <allocate+0xc48>
 1021ba8:	mov    %rax,0x18(%rbx)
 1021bac:	mov    %rsi,0x30(%rdx)
 1021bb0:	call   1027570 <free@plt>
 1021bb5:	mov    %r14,%rdx
 1021bb8:	mov    -0x2c(%rbp),%r10d
 1021bbc:	mov    -0x38(%rbp),%r11
 1021bc0:	mov    -0x68(%rbp),%rdi
 1021bc4:	mov    %rdi,0x4d8(%rbx)
 1021bcb:	mov    -0x50(%rbp),%rax
 1021bcf:	mov    %rax,0x11f0(%rbx)
 1021bd6:	jmp    1021bdc <allocate+0x9ac>
 1021bd8:	mov    -0x38(%rbp),%r11
 1021bdc:	mov    (%rdi,%r15,8),%rax
 1021be0:	mov    %rax,(%r12)
 1021be4:	mov    %r10d,0x20(%r12)
 1021be9:	mov    %r12,(%rdi,%r15,8)
 1021bed:	cmp    %r15,0x11e8(%rbx)
 1021bf4:	ja     1021c01 <allocate+0x9d1>
 1021bf6:	lea    0x1(%r15),%rax
 1021bfa:	mov    %rax,0x11e8(%rbx)
 1021c01:	incq   0xa8(%rbx)
 1021c08:	mov    0xb0(%rbx),%rax
 1021c0f:	add    0x8(%r12),%rax
 1021c14:	mov    %rax,0xb0(%rbx)
 1021c1b:	cmp    0xb8(%rbx),%rax
 1021c22:	jbe    1021c2b <allocate+0x9fb>
 1021c24:	mov    %rax,0xb8(%rbx)
 1021c2b:	xor    %eax,%eax
 1021c2d:	movabs $0x4000000000000000,%rsi
 1021c37:	shl    $0x28,%r15
 1021c3b:	mov    -0x70(%rbp),%rcx
 1021c3f:	lea    (%r15,%rcx,4),%rcx
 1021c43:	or     %rsi,%rcx
 1021c46:	mov    %rcx,0x50(%r12,%rax,1)
 1021c4b:	mov    %r13,0x58(%r12,%rax,1)
 1021c50:	incq   0x18(%r12)
 1021c55:	lea    (%r11,%rax,1),%rcx
 1021c59:	add    $0x10,%rcx
 1021c5d:	mov    %rcx,0x10(%r12)
 1021c62:	vmovdqu 0x40(%rbx),%xmm0
 1021c67:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1021c6b:	vpsubq %xmm1,%xmm0,%xmm0
 1021c6f:	vmovdqu %xmm0,0x40(%rbx)
 1021c74:	incq   0x90(%rbx)
 1021c7b:	lea    (%r12,%rax,1),%rcx
 1021c7f:	add    $0x50,%rcx
 1021c83:	cmp    0x70(%rbx),%r10d
 1021c87:	jne    1021407 <allocate+0x1d7>
 1021c8d:	cmpl   $0x0,0x74(%rbx)
 1021c91:	jne    1021407 <allocate+0x1d7>
 1021c97:	cmpl   $0x0,0x68(%rbx)
 1021c9b:	jne    1021407 <allocate+0x1d7>
 1021ca1:	mov    0x8(%r12),%rax
 1021ca6:	mov    0x10(%r12),%rdi
 1021cab:	add    $0xf,%rdi
 1021caf:	and    $0xfffffffffffffff0,%rdi
 1021cb3:	lea    -0x50(%rax),%r8
 1021cb7:	cmp    %r8,%rdi
 1021cba:	jae    1021407 <allocate+0x1d7>
 1021cc0:	lea    0x50(%r12),%r8
 1021cc5:	add    %rdi,%r8
 1021cc8:	add    %r12,%rax
 1021ccb:	mov    %r8,0x5c0(%rbx)
 1021cd2:	mov    %rax,0x5c8(%rbx)
 1021cd9:	lea    (%rsi,%r15,1),%rax
 1021cdd:	add    $0x4,%rax
 1021ce1:	mov    %rax,0x5d0(%rbx)
 1021ce8:	mov    %r12,0x11a0(%rbx)
 1021cef:	jmp    1021407 <allocate+0x1d7>
 1021cf4:	mov    -0x60(%rbp),%rdi
 1021cf8:	test   %rdi,%rdi
 1021cfb:	je     1021ab7 <allocate+0x887>
 1021d01:	mov    %r14,%r12
 1021d04:	jmp    1021d14 <allocate+0xae4>
 1021d06:	call   1027570 <free@plt>
 1021d0b:	mov    0x0(%r13),%rdi
 1021d0f:	test   %rdi,%rdi
 1021d12:	je     1021d79 <allocate+0xb49>
 1021d14:	mov    (%rdi),%rax
 1021d17:	mov    %rax,0x4e0(%rbx)
 1021d1e:	cmpq   $0x0,0x1608(%rbx)
 1021d26:	je     1021d06 <allocate+0xad6>
 1021d28:	mov    0x8(%rdi),%rax
 1021d2c:	sub    %rax,0x18(%rbx)
 1021d30:	jmp    1021d06 <allocate+0xad6>
 1021d32:	cmpq   $0x0,0xc0(%rbx)
 1021d3a:	je     1021d5a <allocate+0xb2a>
 1021d3c:	mov    %rbx,%rdi
 1021d3f:	call   1017120 <myl_native_arena_reclaim>
 1021d44:	mov    $0x1,%edi
 1021d49:	mov    %r14,%rsi
 1021d4c:	call   1027510 <calloc@plt>
 1021d51:	test   %rax,%rax
 1021d54:	jne    10218bc <allocate+0x68c>
 1021d5a:	xor    %ecx,%ecx
 1021d5c:	mov    %r13,%rdx
 1021d5f:	mov    %rcx,(%rdx)
 1021d62:	xor    %eax,%eax
 1021d64:	test   %rcx,%rcx
 1021d67:	sete   %al
 1021d6a:	add    $0x48,%rsp
 1021d6e:	pop    %rbx
 1021d6f:	pop    %r12
 1021d71:	pop    %r13
 1021d73:	pop    %r14
 1021d75:	pop    %r15
 1021d77:	pop    %rbp
 1021d78:	ret
 1021d79:	vpxor  %xmm0,%xmm0,%xmm0
 1021d7d:	vmovdqu %xmm0,0xc0(%rbx)
 1021d85:	mov    $0x1,%edi
 1021d8a:	mov    %r12,%rsi
 1021d8d:	call   1027510 <calloc@plt>
 1021d92:	test   %rax,%rax
 1021d95:	mov    -0x40(%rbp),%rdx
 1021d99:	mov    -0x2c(%rbp),%r10d
 1021d9d:	je     1021ab7 <allocate+0x887>
 1021da3:	mov    %rax,%r12
 1021da6:	mov    0x18(%rbx),%rax
 1021daa:	mov    %rax,-0x48(%rbp)
 1021dae:	jmp    1021b41 <allocate+0x911>
 1021db3:	mov    %rbx,%rdi
 1021db6:	call   10222c0 <trim_empty>
 1021dbb:	mov    %r14,%rdi
 1021dbe:	call   10226b0 <large_block>
 1021dc3:	mov    %rax,%r15
 1021dc6:	test   %rax,%rax
 1021dc9:	mov    $0x1,%eax
 1021dce:	je     1021d6a <allocate+0xb3a>
 1021dd0:	mov    0x1608(%rbx),%rcx
 1021dd7:	test   %rcx,%rcx
 1021dda:	mov    -0x70(%rbp),%rax
 1021dde:	je     1021e78 <allocate+0xc48>
 1021de4:	mov    0x20(%rcx),%rcx
 1021de8:	mov    0x200(%rcx),%rdx
 1021def:	movq   $0x0,(%r15)
 1021df6:	mov    %rdx,0x8(%r15)
 1021dfa:	mov    %r14,0x10(%r15)
 1021dfe:	mov    %r12,0x18(%r15)
 1021e02:	movq   $0x0,0x28(%r15)
 1021e0a:	test   %rdx,%rdx
 1021e0d:	je     1021e12 <allocate+0xbe2>
 1021e0f:	mov    %r15,(%rdx)
 1021e12:	mov    %r15,0x200(%rcx)
 1021e19:	add    %r14,0x18(%rbx)
 1021e1d:	add    %r14,0x208(%rcx)
 1021e24:	add    $0x30,%r15
 1021e28:	movabs $0x8000000000000000,%rcx
 1021e32:	mov    (%rax),%rdx
 1021e35:	mov    0x8(%rax),%rax
 1021e39:	movq   $0x1,(%r15)
 1021e40:	movq   $0x0,0x8(%r15)
 1021e48:	shl    $0x2,%rax
 1021e4c:	or     %rcx,%rax
 1021e4f:	mov    %rax,0x10(%r15)
 1021e53:	mov    %rdx,0x18(%r15)
 1021e57:	vmovdqu 0x40(%rbx),%xmm0
 1021e5c:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1021e60:	vpsubq %xmm1,%xmm0,%xmm0
 1021e64:	vmovdqu %xmm0,0x40(%rbx)
 1021e69:	add    $0x20,%r15
 1021e6d:	mov    %r15,0x0(%r13)
 1021e71:	xor    %eax,%eax
 1021e73:	jmp    1021d6a <allocate+0xb3a>
 1021e78:	call   10187d4 <myl_rc_invariant_failed>
 1021e7d:	int3
 1021e7e:	int3
 1021e7f:	int3

0000000001021e80 <myl_rc_binding_find>:
 1021e80:	mov    0x34(%rsi),%eax
 1021e83:	cmp    %rax,0xa0(%rdi)
 1021e8a:	jbe    1021ea5 <myl_rc_binding_find+0x25>
 1021e8c:	mov    0x98(%rdi),%rcx
 1021e93:	shl    $0x4,%rax
 1021e97:	cmp    %rsi,(%rcx,%rax,1)
 1021e9b:	jne    1021ea5 <myl_rc_binding_find+0x25>
 1021e9d:	add    %rax,%rcx
 1021ea0:	mov    0x8(%rcx),%rax
 1021ea4:	ret
 1021ea5:	push   %rbp
 1021ea6:	mov    %rsp,%rbp
 1021ea9:	call   1018df4 <myl_rc_binding_find_slow>
 1021eae:	pop    %rbp
 1021eaf:	ret

0000000001021eb0 <slab_refill>:
 1021eb0:	push   %rbp
 1021eb1:	mov    %rsp,%rbp
 1021eb4:	push   %r15
 1021eb6:	push   %r14
 1021eb8:	push   %r13
 1021eba:	push   %r12
 1021ebc:	push   %rbx
 1021ebd:	sub    $0x38,%rsp
 1021ec1:	mov    0x1608(%rdi),%rax
 1021ec8:	test   %rax,%rax
 1021ecb:	je     1022244 <slab_refill+0x394>
 1021ed1:	mov    %rsi,%r12
 1021ed4:	mov    %rdi,%rbx
 1021ed7:	mov    0x20(%rax),%r14
 1021edb:	mov    %rsi,%r15
 1021ede:	shl    $0x4,%r15
 1021ee2:	mov    0x8(%r14,%r15,1),%rcx
 1021ee7:	test   %rcx,%rcx
 1021eea:	je     1021f1b <slab_refill+0x6b>
 1021eec:	mov    0x48(%rcx),%rax
 1021ef0:	test   %rax,%rax
 1021ef3:	je     1022087 <slab_refill+0x1d7>
 1021ef9:	movq   $0x0,0x48(%rcx)
 1021f01:	mov    0x30(%rcx),%r13
 1021f05:	mov    0x40(%rcx),%r11
 1021f09:	mov    %r13,0x38(%rcx)
 1021f0d:	cmp    %r11,%r13
 1021f10:	je     10221eb <slab_refill+0x33b>
 1021f16:	jmp    1022211 <slab_refill+0x361>
 1021f1b:	cmpq   $0x0,0x448(%r14)
 1021f23:	jne    1021f4c <slab_refill+0x9c>
 1021f25:	mov    0x1710(%rbx),%rax
 1021f2c:	cmp    $0x100000,%rax
 1021f32:	jb     1021f4c <slab_refill+0x9c>
 1021f34:	mov    0x208(%r14),%rcx
 1021f3b:	shr    $0x2,%rcx
 1021f3f:	cmp    %rcx,%rax
 1021f42:	jb     1021f4c <slab_refill+0x9c>
 1021f44:	mov    %rbx,%rdi
 1021f47:	call   10222c0 <trim_empty>
 1021f4c:	mov    0x18(%rbx),%rax
 1021f50:	cmp    $0xfffffffffffeffff,%rax
 1021f56:	ja     1021f78 <slab_refill+0xc8>
 1021f58:	mov    0x58(%rbx),%rcx
 1021f5c:	test   %rcx,%rcx
 1021f5f:	je     1021fba <slab_refill+0x10a>
 1021f61:	sub    %rax,%rcx
 1021f64:	setb   %al
 1021f67:	cmp    $0x10000,%rcx
 1021f6e:	setb   %cl
 1021f71:	or     %al,%cl
 1021f73:	cmp    $0x1,%cl
 1021f76:	jne    1021fba <slab_refill+0x10a>
 1021f78:	mov    %rbx,%rdi
 1021f7b:	call   10222c0 <trim_empty>
 1021f80:	mov    0x18(%rbx),%rax
 1021f84:	cmp    $0xfffffffffffeffff,%rax
 1021f8a:	ja     1021fac <slab_refill+0xfc>
 1021f8c:	mov    0x58(%rbx),%rcx
 1021f90:	test   %rcx,%rcx
 1021f93:	je     1021fba <slab_refill+0x10a>
 1021f95:	sub    %rax,%rcx
 1021f98:	setb   %al
 1021f9b:	cmp    $0x10000,%rcx
 1021fa2:	setb   %cl
 1021fa5:	or     %al,%cl
 1021fa7:	cmp    $0x1,%cl
 1021faa:	jne    1021fba <slab_refill+0x10a>
 1021fac:	movl   $0x1,0x6c(%rbx)
 1021fb3:	xor    %eax,%eax
 1021fb5:	jmp    102221c <slab_refill+0x36c>
 1021fba:	mov    %rbx,%rdi
 1021fbd:	call   10224c0 <range_take>
 1021fc2:	test   %rax,%rax
 1021fc5:	jne    1021fe0 <slab_refill+0x130>
 1021fc7:	mov    %rbx,%rdi
 1021fca:	call   10222c0 <trim_empty>
 1021fcf:	mov    %rbx,%rdi
 1021fd2:	call   10224c0 <range_take>
 1021fd7:	test   %rax,%rax
 1021fda:	je     1022240 <slab_refill+0x390>
 1021fe0:	mov    %rax,%rcx
 1021fe3:	vxorps %xmm0,%xmm0,%xmm0
 1021fe7:	vmovups %ymm0,0x30(%rax)
 1021fec:	vmovups %ymm0,0x10(%rax)
 1021ff1:	mov    0x100b700(,%r12,8),%rsi
 1021ff9:	mov    %rsi,0x8(%rax)
 1021ffd:	mov    %r12,(%rax)
 1022000:	cmp    $0xffb0,%rsi
 1022007:	ja     1022014 <slab_refill+0x164>
 1022009:	mov    $0xffb0,%eax
 102200e:	xor    %edx,%edx
 1022010:	div    %esi
 1022012:	jmp    1022016 <slab_refill+0x166>
 1022014:	xor    %eax,%eax
 1022016:	mov    %rax,0x40(%rcx)
 102201a:	mov    0x1608(%rbx),%rax
 1022021:	test   %rax,%rax
 1022024:	je     1022244 <slab_refill+0x394>
 102202a:	mov    0x20(%rax),%rax
 102202e:	lea    (%rax,%r15,1),%rdx
 1022032:	mov    (%rax,%r15,1),%rsi
 1022036:	mov    %rsi,0x18(%rcx)
 102203a:	test   %rsi,%rsi
 102203d:	je     1022043 <slab_refill+0x193>
 102203f:	mov    %rcx,0x10(%rsi)
 1022043:	mov    %rcx,(%rdx)
 1022046:	mov    0x8(%rdx),%rsi
 102204a:	movq   $0x0,0x20(%rcx)
 1022052:	mov    %rsi,0x28(%rcx)
 1022056:	mov    0x8(%rdx),%rsi
 102205a:	test   %rsi,%rsi
 102205d:	je     1022063 <slab_refill+0x1b3>
 102205f:	mov    %rcx,0x20(%rsi)
 1022063:	mov    %rcx,0x8(%rdx)
 1022067:	addq   $0x10000,0x18(%rbx)
 102206f:	addq   $0x10000,0x208(%rax)
 102207a:	mov    0x48(%rcx),%rax
 102207e:	test   %rax,%rax
 1022081:	jne    1021ef9 <slab_refill+0x49>
 1022087:	mov    0x8(%rcx),%rdi
 102208b:	mov    0x30(%rcx),%r13
 102208f:	mov    0x40(%rcx),%r11
 1022093:	mov    %r11,%r8
 1022096:	sub    %r13,%r8
 1022099:	cmp    $0x1000,%rdi
 10220a0:	ja     10220ad <slab_refill+0x1fd>
 10220a2:	mov    $0x1000,%eax
 10220a7:	xor    %edx,%edx
 10220a9:	div    %edi
 10220ab:	jmp    10220af <slab_refill+0x1ff>
 10220ad:	xor    %eax,%eax
 10220af:	cmp    $0x1001,%rdi
 10220b6:	mov    $0x1,%edx
 10220bb:	cmovb  %rax,%rdx
 10220bf:	cmp    %r8,%rdx
 10220c2:	cmovae %r8,%rdx
 10220c6:	mov    %r13,%r9
 10220c9:	imul   %rdi,%r9
 10220cd:	lea    (%rcx,%r9,1),%rax
 10220d1:	add    $0x50,%rax
 10220d5:	test   %rdx,%rdx
 10220d8:	je     10221db <slab_refill+0x32b>
 10220de:	cmp    $0x1,%rdx
 10220e2:	jne    10220ec <slab_refill+0x23c>
 10220e4:	xor    %r10d,%r10d
 10220e7:	jmp    10221b1 <slab_refill+0x301>
 10220ec:	mov    %r11,-0x38(%rbp)
 10220f0:	mov    %r12,-0x48(%rbp)
 10220f4:	mov    %r15,-0x50(%rbp)
 10220f8:	mov    %r14,-0x58(%rbp)
 10220fc:	mov    %rbx,-0x60(%rbp)
 1022100:	mov    %edx,%r11d
 1022103:	and    $0x1ffe,%r11d
 102210a:	lea    0x2(%r13),%r8
 102210e:	imul   %rdi,%r8
 1022112:	lea    (%rcx,%r8,1),%r12
 1022116:	add    $0x50,%r12
 102211a:	mov    %r13,%rsi
 102211d:	lea    (%rdi,%rdi,1),%r13
 1022121:	mov    %rsi,-0x40(%rbp)
 1022125:	lea    0x1(%rsi),%r8
 1022129:	mov    %rdi,-0x30(%rbp)
 102212d:	imul   %rdi,%r8
 1022131:	lea    (%rcx,%r8,1),%r14
 1022135:	add    $0x60,%r14
 1022139:	add    %rcx,%r8
 102213c:	add    $0x50,%r8
 1022140:	lea    (%r9,%rcx,1),%r15
 1022144:	add    $0x60,%r15
 1022148:	xor    %ebx,%ebx
 102214a:	xor    %r9d,%r9d
 102214d:	xor    %r10d,%r10d
 1022150:	lea    0x1(%r10),%rsi
 1022154:	lea    (%r8,%r9,1),%rdi
 1022158:	cmp    %rdx,%rsi
 102215b:	cmovae %rbx,%rdi
 102215f:	mov    %rdi,-0x10(%r15,%r9,1)
 1022164:	movq   $0x3,(%r15,%r9,1)
 102216c:	add    $0x2,%r10
 1022170:	lea    (%r12,%r9,1),%rsi
 1022174:	cmp    %rdx,%r10
 1022177:	cmovae %rbx,%rsi
 102217b:	mov    %rsi,-0x10(%r14,%r9,1)
 1022180:	movq   $0x3,(%r14,%r9,1)
 1022188:	add    %r13,%r9
 102218b:	cmp    %r10,%r11
 102218e:	jne    1022150 <slab_refill+0x2a0>
 1022190:	test   $0x1,%dl
 1022193:	mov    -0x60(%rbp),%rbx
 1022197:	mov    -0x58(%rbp),%r14
 102219b:	mov    -0x50(%rbp),%r15
 102219f:	mov    -0x48(%rbp),%r12
 10221a3:	mov    -0x40(%rbp),%r13
 10221a7:	mov    -0x38(%rbp),%r11
 10221ab:	mov    -0x30(%rbp),%rdi
 10221af:	je     10221db <slab_refill+0x32b>
 10221b1:	mov    %r10,%rsi
 10221b4:	imul   %rdi,%rsi
 10221b8:	inc    %r10
 10221bb:	imul   %r10,%rdi
 10221bf:	add    %rax,%rdi
 10221c2:	mov    %rdi,%r8
 10221c5:	xor    %edi,%edi
 10221c7:	cmp    %rdx,%r10
 10221ca:	cmovb  %r8,%rdi
 10221ce:	mov    %rdi,(%rax,%rsi,1)
 10221d2:	movq   $0x3,0x10(%rax,%rsi,1)
 10221db:	add    %rdx,%r13
 10221de:	mov    %r13,0x30(%rcx)
 10221e2:	add    %rdx,0x38(%rcx)
 10221e6:	cmp    %r11,%r13
 10221e9:	jne    1022211 <slab_refill+0x361>
 10221eb:	mov    0x20(%rcx),%rdx
 10221ef:	mov    0x28(%rcx),%rsi
 10221f3:	test   %rdx,%rdx
 10221f6:	je     102222e <slab_refill+0x37e>
 10221f8:	mov    %rsi,0x28(%rdx)
 10221fc:	add    $0x20,%rcx
 1022200:	test   %rsi,%rsi
 1022203:	je     1022209 <slab_refill+0x359>
 1022205:	mov    %rdx,0x20(%rsi)
 1022209:	vxorps %xmm0,%xmm0,%xmm0
 102220d:	vmovups %xmm0,(%rcx)
 1022211:	mov    (%rax),%rcx
 1022214:	mov    %rcx,0x1610(%rbx,%r12,8)
 102221c:	add    $0x38,%rsp
 1022220:	pop    %rbx
 1022221:	pop    %r12
 1022223:	pop    %r13
 1022225:	pop    %r14
 1022227:	pop    %r15
 1022229:	pop    %rbp
 102222a:	vzeroupper
 102222d:	ret
 102222e:	add    %r15,%r14
 1022231:	mov    %rsi,0x8(%r14)
 1022235:	add    $0x20,%rcx
 1022239:	test   %rsi,%rsi
 102223c:	jne    1022205 <slab_refill+0x355>
 102223e:	jmp    1022209 <slab_refill+0x359>
 1022240:	xor    %eax,%eax
 1022242:	jmp    102221c <slab_refill+0x36c>
 1022244:	vzeroupper
 1022247:	call   10187d4 <myl_rc_invariant_failed>
 102224c:	int3
 102224d:	int3
 102224e:	int3
 102224f:	int3

0000000001022250 <zero_payload>:
 1022250:	push   %rbp
 1022251:	mov    %rsp,%rbp
 1022254:	lea    0xf(%rsi),%rax
 1022258:	shr    $0x4,%rax
 102225c:	cmp    $0x8,%rax
 1022260:	ja     10222b2 <zero_payload+0x62>
 1022262:	jmp    *0x1001c58(,%rax,8)
 1022269:	vxorps %xmm0,%xmm0,%xmm0
 102226d:	vmovaps %xmm0,0x70(%rdi)
 1022272:	vxorps %xmm0,%xmm0,%xmm0
 1022276:	vmovaps %xmm0,0x60(%rdi)
 102227b:	vxorps %xmm0,%xmm0,%xmm0
 102227f:	vmovaps %xmm0,0x50(%rdi)
 1022284:	vxorps %xmm0,%xmm0,%xmm0
 1022288:	vmovaps %xmm0,0x40(%rdi)
 102228d:	vxorps %xmm0,%xmm0,%xmm0
 1022291:	vmovaps %xmm0,0x30(%rdi)
 1022296:	vxorps %xmm0,%xmm0,%xmm0
 102229a:	vmovaps %xmm0,0x20(%rdi)
 102229f:	vxorps %xmm0,%xmm0,%xmm0
 10222a3:	vmovaps %xmm0,0x10(%rdi)
 10222a8:	vxorps %xmm0,%xmm0,%xmm0
 10222ac:	vmovaps %xmm0,(%rdi)
 10222b0:	pop    %rbp
 10222b1:	ret
 10222b2:	mov    %rsi,%rdx
 10222b5:	xor    %esi,%esi
 10222b7:	pop    %rbp
 10222b8:	jmp    10274d0 <memset@plt>
 10222bd:	int3
 10222be:	int3
 10222bf:	int3

00000000010222c0 <trim_empty>:
 10222c0:	push   %rbp
 10222c1:	mov    %rsp,%rbp
 10222c4:	push   %r15
 10222c6:	push   %r14
 10222c8:	push   %r13
 10222ca:	push   %r12
 10222cc:	push   %rbx
 10222cd:	push   %rax
 10222ce:	test   %rdi,%rdi
 10222d1:	je     10224ad <trim_empty+0x1ed>
 10222d7:	mov    %rdi,%rbx
 10222da:	xor    %ecx,%ecx
 10222dc:	vxorps %xmm0,%xmm0,%xmm0
 10222e0:	jmp    1022301 <trim_empty+0x41>
 10222e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10222f0:	mov    -0x30(%rbp),%rcx
 10222f4:	inc    %rcx
 10222f7:	cmp    $0x20,%rcx
 10222fb:	je     1022493 <trim_empty+0x1d3>
 1022301:	mov    0x1608(%rbx),%rax
 1022308:	test   %rax,%rax
 102230b:	je     10224ad <trim_empty+0x1ed>
 1022311:	mov    0x20(%rax),%r15
 1022315:	mov    0x1610(%rbx,%rcx,8),%rax
 102231d:	mov    %rcx,-0x30(%rbp)
 1022321:	movq   $0x0,0x1610(%rbx,%rcx,8)
 102232d:	test   %rax,%rax
 1022330:	je     10222f0 <trim_empty+0x30>
 1022332:	mov    -0x30(%rbp),%rcx
 1022336:	shl    $0x4,%rcx
 102233a:	add    %rcx,%r15
 102233d:	jmp    1022364 <trim_empty+0xa4>
 102233f:	nop
 1022340:	mov    0x448(%r14),%rcx
 1022347:	mov    %rcx,0x0(%r13)
 102234b:	mov    %r13,0x448(%r14)
 1022352:	inc    %rax
 1022355:	mov    %rax,0x450(%r14)
 102235c:	mov    %r12,%rax
 102235f:	test   %r12,%r12
 1022362:	je     10222f0 <trim_empty+0x30>
 1022364:	mov    (%rax),%r12
 1022367:	mov    %rax,%r13
 102236a:	and    $0xffffffffffff0000,%r13
 1022371:	mov    0x48(%r13),%rcx
 1022375:	test   %rcx,%rcx
 1022378:	jne    10223b0 <trim_empty+0xf0>
 102237a:	mov    0x30(%r13),%rdx
 102237e:	cmp    0x40(%r13),%rdx
 1022382:	jne    10223b0 <trim_empty+0xf0>
 1022384:	mov    0x8(%r15),%rcx
 1022388:	movq   $0x0,0x20(%r13)
 1022390:	mov    %rcx,0x28(%r13)
 1022394:	mov    0x8(%r15),%rcx
 1022398:	test   %rcx,%rcx
 102239b:	je     10223a1 <trim_empty+0xe1>
 102239d:	mov    %r13,0x20(%rcx)
 10223a1:	mov    %r13,0x8(%r15)
 10223a5:	mov    0x48(%r13),%rcx
 10223a9:	nopl   0x0(%rax)
 10223b0:	mov    %rcx,(%rax)
 10223b3:	mov    %rax,0x48(%r13)
 10223b7:	decq   0x38(%r13)
 10223bb:	jne    102235c <trim_empty+0x9c>
 10223bd:	mov    0x1608(%rbx),%rdx
 10223c4:	test   %rdx,%rdx
 10223c7:	je     10224ad <trim_empty+0x1ed>
 10223cd:	mov    0x0(%r13),%rax
 10223d1:	mov    0x20(%r13),%rcx
 10223d5:	shl    $0x4,%rax
 10223d9:	add    0x20(%rdx),%rax
 10223dd:	mov    0x28(%r13),%rdx
 10223e1:	test   %rcx,%rcx
 10223e4:	je     1022477 <trim_empty+0x1b7>
 10223ea:	mov    %rdx,0x28(%rcx)
 10223ee:	test   %rdx,%rdx
 10223f1:	je     10223f7 <trim_empty+0x137>
 10223f3:	mov    %rcx,0x20(%rdx)
 10223f7:	lea    0x20(%r13),%rcx
 10223fb:	vmovaps %xmm0,(%rcx)
 10223ff:	mov    0x10(%r13),%rdx
 1022403:	mov    0x18(%r13),%rcx
 1022407:	test   %rdx,%rdx
 102240a:	je     1022489 <trim_empty+0x1c9>
 102240c:	mov    %rcx,0x18(%rdx)
 1022410:	test   %rcx,%rcx
 1022413:	je     102241d <trim_empty+0x15d>
 1022415:	mov    0x10(%r13),%rax
 1022419:	mov    %rax,0x10(%rcx)
 102241d:	addq   $0xffffffffffff0000,0x18(%rbx)
 1022425:	mov    0x1608(%rbx),%rax
 102242c:	test   %rax,%rax
 102242f:	je     10224ad <trim_empty+0x1ed>
 1022431:	mov    0x20(%rax),%r14
 1022435:	addq   $0xffffffffffff0000,0x208(%r14)
 1022440:	mov    0x450(%r14),%rax
 1022447:	cmp    $0x10,%rax
 102244b:	jb     1022340 <trim_empty+0x80>
 1022451:	lea    0x1000(%r13),%rdi
 1022458:	mov    $0xf000,%esi
 102245d:	mov    $0x4,%edx
 1022462:	call   10278f0 <madvise@plt>
 1022467:	vxorps %xmm0,%xmm0,%xmm0
 102246b:	mov    0x450(%r14),%rax
 1022472:	jmp    1022340 <trim_empty+0x80>
 1022477:	mov    %rdx,0x8(%rax)
 102247b:	test   %rdx,%rdx
 102247e:	jne    10223f3 <trim_empty+0x133>
 1022484:	jmp    10223f7 <trim_empty+0x137>
 1022489:	mov    %rcx,(%rax)
 102248c:	test   %rcx,%rcx
 102248f:	jne    1022415 <trim_empty+0x155>
 1022491:	jmp    102241d <trim_empty+0x15d>
 1022493:	movq   $0x0,0x1710(%rbx)
 102249e:	add    $0x8,%rsp
 10224a2:	pop    %rbx
 10224a3:	pop    %r12
 10224a5:	pop    %r13
 10224a7:	pop    %r14
 10224a9:	pop    %r15
 10224ab:	pop    %rbp
 10224ac:	ret
 10224ad:	call   10187d4 <myl_rc_invariant_failed>
 10224b2:	int3
 10224b3:	int3
 10224b4:	int3
 10224b5:	int3
 10224b6:	int3
 10224b7:	int3
 10224b8:	int3
 10224b9:	int3
 10224ba:	int3
 10224bb:	int3
 10224bc:	int3
 10224bd:	int3
 10224be:	int3
 10224bf:	int3

00000000010224c0 <range_take>:
 10224c0:	push   %rbp
 10224c1:	mov    %rsp,%rbp
 10224c4:	push   %r15
 10224c6:	push   %r14
 10224c8:	push   %rbx
 10224c9:	push   %rax
 10224ca:	mov    0x1608(%rdi),%rax
 10224d1:	test   %rax,%rax
 10224d4:	je     10226a7 <range_take+0x1e7>
 10224da:	mov    0x20(%rax),%r15
 10224de:	mov    0x448(%r15),%rax
 10224e5:	test   %rax,%rax
 10224e8:	je     1022500 <range_take+0x40>
 10224ea:	mov    (%rax),%rcx
 10224ed:	mov    %rcx,0x448(%r15)
 10224f4:	decq   0x450(%r15)
 10224fb:	jmp    1022698 <range_take+0x1d8>
 1022500:	mov    0x220(%r15),%rax
 1022507:	cmp    0x228(%r15),%rax
 102250e:	jne    102268a <range_take+0x1ca>
 1022514:	mov    0x438(%r15),%rcx
 102251b:	cmp    $0x40,%rcx
 102251f:	jb     10225d8 <range_take+0x118>
 1022525:	add    $0xffffffffffffffc0,%rcx
 1022529:	cmp    0x440(%r15),%rcx
 1022530:	jne    10225d8 <range_take+0x118>
 1022536:	lea    (%rcx,%rcx,1),%rax
 102253a:	test   %rcx,%rcx
 102253d:	mov    $0x40,%ebx
 1022542:	cmovne %rax,%rbx
 1022546:	mov    %rbx,%rax
 1022549:	sub    %rcx,%rax
 102254c:	shl    $0x3,%rax
 1022550:	mov    0x18(%rdi),%rcx
 1022554:	mov    %rcx,%rdx
 1022557:	add    %rax,%rdx
 102255a:	jae    102256a <range_take+0xaa>
 102255c:	movl   $0x1,0x6c(%rdi)
 1022563:	xor    %eax,%eax
 1022565:	jmp    1022698 <range_take+0x1d8>
 102256a:	mov    0x58(%rdi),%rdx
 102256e:	test   %rdx,%rdx
 1022571:	je     102257d <range_take+0xbd>
 1022573:	sub    %rcx,%rdx
 1022576:	jb     102255c <range_take+0x9c>
 1022578:	cmp    %rdx,%rax
 102257b:	ja     102255c <range_take+0x9c>
 102257d:	mov    %rdi,%r14
 1022580:	lea    0x0(,%rbx,8),%rsi
 1022588:	mov    0x430(%r15),%rdi
 102258f:	call   1027670 <realloc@plt>
 1022594:	test   %rax,%rax
 1022597:	je     10226a3 <range_take+0x1e3>
 102259d:	mov    %rbx,%rcx
 10225a0:	sub    0x440(%r15),%rcx
 10225a7:	shl    $0x3,%rcx
 10225ab:	add    %rcx,0x18(%r14)
 10225af:	mov    0x1608(%r14),%rdx
 10225b6:	test   %rdx,%rdx
 10225b9:	je     10226a7 <range_take+0x1e7>
 10225bf:	mov    0x20(%rdx),%rdx
 10225c3:	add    %rcx,0x208(%rdx)
 10225ca:	mov    %rax,0x430(%r15)
 10225d1:	mov    %rbx,0x440(%r15)
 10225d8:	mov    $0x210000,%esi
 10225dd:	xor    %edi,%edi
 10225df:	mov    $0x3,%edx
 10225e4:	mov    $0x22,%ecx
 10225e9:	mov    $0xffffffff,%r8d
 10225ef:	xor    %r9d,%r9d
 10225f2:	call   1027720 <mmap@plt>
 10225f7:	mov    %rax,%rbx
 10225fa:	xor    %eax,%eax
 10225fc:	cmp    $0xffffffffffffffff,%rbx
 1022600:	je     1022698 <range_take+0x1d8>
 1022606:	lea    0xffff(%rbx),%rax
 102260d:	and    $0xffffffffffff0000,%rax
 1022613:	cmp    %rax,%rbx
 1022616:	je     102262c <range_take+0x16c>
 1022618:	mov    %rax,%rsi
 102261b:	sub    %rbx,%rsi
 102261e:	mov    %rbx,%rdi
 1022621:	mov    %rax,%r14
 1022624:	call   1027770 <munmap@plt>
 1022629:	mov    %r14,%rax
 102262c:	lea    0x200000(%rax),%r14
 1022633:	add    $0x210000,%rbx
 102263a:	cmp    %rbx,%r14
 102263d:	je     1022653 <range_take+0x193>
 102263f:	sub    %r14,%rbx
 1022642:	mov    %r14,%rdi
 1022645:	mov    %rbx,%rsi
 1022648:	mov    %rax,%rbx
 102264b:	call   1027770 <munmap@plt>
 1022650:	mov    %rbx,%rax
 1022653:	mov    0x438(%r15),%rcx
 102265a:	cmp    $0x3f,%rcx
 102265e:	ja     102266a <range_take+0x1aa>
 1022660:	mov    %rax,0x230(%r15,%rcx,8)
 1022668:	jmp    1022679 <range_take+0x1b9>
 102266a:	mov    0x430(%r15),%rdx
 1022671:	mov    %rax,-0x200(%rdx,%rcx,8)
 1022679:	inc    %rcx
 102267c:	mov    %rcx,0x438(%r15)
 1022683:	mov    %r14,0x228(%r15)
 102268a:	lea    0x10000(%rax),%rcx
 1022691:	mov    %rcx,0x220(%r15)
 1022698:	add    $0x8,%rsp
 102269c:	pop    %rbx
 102269d:	pop    %r14
 102269f:	pop    %r15
 10226a1:	pop    %rbp
 10226a2:	ret
 10226a3:	xor    %eax,%eax
 10226a5:	jmp    1022698 <range_take+0x1d8>
 10226a7:	call   10187d4 <myl_rc_invariant_failed>
 10226ac:	int3
 10226ad:	int3
 10226ae:	int3
 10226af:	int3

00000000010226b0 <large_block>:
 10226b0:	push   %rbp
 10226b1:	mov    %rsp,%rbp
 10226b4:	push   %r14
 10226b6:	push   %rbx
 10226b7:	mov    %rdi,%rbx
 10226ba:	cmp    $0x1ffff,%rdi
 10226c1:	ja     10226d4 <large_block+0x24>
 10226c3:	mov    $0x1,%edi
 10226c8:	mov    %rbx,%rsi
 10226cb:	pop    %rbx
 10226cc:	pop    %r14
 10226ce:	pop    %rbp
 10226cf:	jmp    1027510 <calloc@plt>
 10226d4:	cmp    $0xffffffffffffefff,%rbx
 10226db:	jbe    10226e2 <large_block+0x32>
 10226dd:	xor    %r14d,%r14d
 10226e0:	jmp    102271d <large_block+0x6d>
 10226e2:	add    $0xfff,%rbx
 10226e9:	and    $0xfffffffffffff000,%rbx
 10226f0:	xor    %r14d,%r14d
 10226f3:	xor    %edi,%edi
 10226f5:	mov    %rbx,%rsi
 10226f8:	mov    $0x3,%edx
 10226fd:	mov    $0x22,%ecx
 1022702:	mov    $0xffffffff,%r8d
 1022708:	xor    %r9d,%r9d
 102270b:	call   1027720 <mmap@plt>
 1022710:	cmp    $0xffffffffffffffff,%rax
 1022714:	je     102271d <large_block+0x6d>
 1022716:	mov    %rbx,0x20(%rax)
 102271a:	mov    %rax,%r14
 102271d:	mov    %r14,%rax
 1022720:	pop    %rbx
 1022721:	pop    %r14
 1022723:	pop    %rbp
 1022724:	ret
 1022725:	int3
 1022726:	int3
 1022727:	int3
 1022728:	int3
 1022729:	int3
 102272a:	int3
 102272b:	int3
 102272c:	int3
 102272d:	int3
 102272e:	int3
 102272f:	int3

0000000001022730 <myl_rc_storage_retire>:
 1022730:	push   %rbp
 1022731:	mov    %rsp,%rbp
 1022734:	cmpq   $0x0,-0x10(%rsi)
 1022739:	js     102279d <myl_rc_storage_retire+0x6d>
 102273b:	mov    0x40(%rdi),%rcx
 102273f:	test   %rcx,%rcx
 1022742:	je     1022819 <myl_rc_storage_retire+0xe9>
 1022748:	lea    -0x20(%rsi),%rax
 102274c:	mov    0x50(%rdi),%rdx
 1022750:	cmp    $0xffffffffffffffff,%rdx
 1022754:	je     102275d <myl_rc_storage_retire+0x2d>
 1022756:	inc    %rdx
 1022759:	mov    %rdx,0x50(%rdi)
 102275d:	mov    %rax,%rdx
 1022760:	and    $0xffffffffffff0000,%rdx
 1022767:	dec    %rcx
 102276a:	mov    %rcx,0x40(%rdi)
 102276e:	movq   $0x3,-0x10(%rsi)
 1022776:	mov    (%rdx),%rcx
 1022779:	mov    0x1610(%rdi,%rcx,8),%rcx
 1022781:	mov    %rcx,-0x20(%rsi)
 1022785:	mov    (%rdx),%rcx
 1022788:	mov    %rax,0x1610(%rdi,%rcx,8)
 1022790:	mov    0x8(%rdx),%rax
 1022794:	add    %rax,0x1710(%rdi)
 102279b:	pop    %rbp
 102279c:	ret
 102279d:	mov    0x50(%rdi),%rax
 10227a1:	cmp    $0xffffffffffffffff,%rax
 10227a5:	je     10227ae <myl_rc_storage_retire+0x7e>
 10227a7:	inc    %rax
 10227aa:	mov    %rax,0x50(%rdi)
 10227ae:	decq   0x40(%rdi)
 10227b2:	mov    -0x50(%rsi),%rax
 10227b6:	test   %rax,%rax
 10227b9:	je     10227f7 <myl_rc_storage_retire+0xc7>
 10227bb:	mov    -0x48(%rsi),%rcx
 10227bf:	mov    %rcx,0x8(%rax)
 10227c3:	test   %rcx,%rcx
 10227c6:	je     10227cb <myl_rc_storage_retire+0x9b>
 10227c8:	mov    %rax,(%rcx)
 10227cb:	mov    -0x40(%rsi),%rax
 10227cf:	sub    %rax,0x18(%rdi)
 10227d3:	mov    0x1608(%rdi),%rcx
 10227da:	test   %rcx,%rcx
 10227dd:	je     1022819 <myl_rc_storage_retire+0xe9>
 10227df:	add    $0xffffffffffffffb0,%rsi
 10227e3:	mov    0x20(%rcx),%rcx
 10227e7:	sub    %rax,0x208(%rcx)
 10227ee:	mov    %rsi,%rdi
 10227f1:	pop    %rbp
 10227f2:	jmp    1022820 <large_release>
 10227f7:	mov    0x1608(%rdi),%rdx
 10227fe:	test   %rdx,%rdx
 1022801:	je     1022819 <myl_rc_storage_retire+0xe9>
 1022803:	mov    -0x48(%rsi),%rcx
 1022807:	mov    0x20(%rdx),%rdx
 102280b:	mov    %rcx,0x200(%rdx)
 1022812:	test   %rcx,%rcx
 1022815:	jne    10227c8 <myl_rc_storage_retire+0x98>
 1022817:	jmp    10227cb <myl_rc_storage_retire+0x9b>
 1022819:	call   10187d4 <myl_rc_invariant_failed>
 102281e:	int3
 102281f:	int3

0000000001022820 <large_release>:
 1022820:	push   %rbp
 1022821:	mov    %rsp,%rbp
 1022824:	mov    0x20(%rdi),%rsi
 1022828:	test   %rsi,%rsi
 102282b:	je     1022833 <large_release+0x13>
 102282d:	pop    %rbp
 102282e:	jmp    1027770 <munmap@plt>
 1022833:	pop    %rbp
 1022834:	jmp    1027570 <free@plt>
 1022839:	int3
 102283a:	int3
 102283b:	int3
 102283c:	int3
 102283d:	int3
 102283e:	int3
 102283f:	int3

0000000001022840 <destroy>:
 1022840:	push   %rbp
 1022841:	mov    %rsp,%rbp
 1022844:	push   %r15
 1022846:	push   %r14
 1022848:	push   %r13
 102284a:	push   %r12
 102284c:	push   %rbx
 102284d:	push   %rax
 102284e:	test   %rdi,%rdi
 1022851:	je     1022b0e <destroy+0x2ce>
 1022857:	mov    %rdi,%rbx
 102285a:	mov    0x1608(%rdi),%rax
 1022861:	test   %rax,%rax
 1022864:	je     1022b0e <destroy+0x2ce>
 102286a:	mov    0x20(%rax),%rax
 102286e:	mov    %rax,-0x30(%rbp)
 1022872:	xor    %eax,%eax
 1022874:	mov    0x1610(%rbx,%rax,8),%rcx
 102287c:	test   %rcx,%rcx
 102287f:	jne    10228c0 <destroy+0x80>
 1022881:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022890:	movq   $0x0,0x1610(%rbx,%rax,8)
 102289c:	inc    %rax
 102289f:	cmp    $0x20,%rax
 10228a3:	je     10228d8 <destroy+0x98>
 10228a5:	mov    0x1610(%rbx,%rax,8),%rcx
 10228ad:	test   %rcx,%rcx
 10228b0:	je     1022890 <destroy+0x50>
 10228b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10228c0:	mov    %rcx,%rdx
 10228c3:	and    $0xffffffffffff0000,%rdx
 10228ca:	decq   0x38(%rdx)
 10228ce:	mov    (%rcx),%rcx
 10228d1:	test   %rcx,%rcx
 10228d4:	jne    10228c0 <destroy+0x80>
 10228d6:	jmp    1022890 <destroy+0x50>
 10228d8:	movq   $0x0,0x1710(%rbx)
 10228e3:	xor    %r15d,%r15d
 10228e6:	jmp    10228fd <destroy+0xbd>
 10228e8:	nopl   0x0(%rax,%rax,1)
 10228f0:	inc    %r15
 10228f3:	cmp    $0x20,%r15
 10228f7:	je     1022a42 <destroy+0x202>
 10228fd:	mov    %r15,%r12
 1022900:	shl    $0x4,%r12
 1022904:	mov    -0x30(%rbp),%rax
 1022908:	mov    (%rax,%r12,1),%r13
 102290c:	test   %r13,%r13
 102290f:	je     10228f0 <destroy+0xb0>
 1022911:	add    -0x30(%rbp),%r12
 1022915:	jmp    1022945 <destroy+0x105>
 1022917:	nopw   0x0(%rax,%rax,1)
 1022920:	mov    0x448(%r14),%rcx
 1022927:	mov    %rcx,0x0(%r13)
 102292b:	mov    %r13,0x448(%r14)
 1022932:	inc    %rax
 1022935:	mov    %rax,0x450(%r14)
 102293c:	mov    (%r12),%r13
 1022940:	test   %r13,%r13
 1022943:	je     10228f0 <destroy+0xb0>
 1022945:	mov    0x1608(%rbx),%rcx
 102294c:	test   %rcx,%rcx
 102294f:	je     1022b0e <destroy+0x2ce>
 1022955:	mov    0x0(%r13),%rax
 1022959:	shl    $0x4,%rax
 102295d:	add    0x20(%rcx),%rax
 1022961:	cmpq   $0x0,0x48(%r13)
 1022966:	jne    1022972 <destroy+0x132>
 1022968:	mov    0x30(%r13),%rcx
 102296c:	cmp    0x40(%r13),%rcx
 1022970:	je     102299c <destroy+0x15c>
 1022972:	mov    0x20(%r13),%rcx
 1022976:	mov    0x28(%r13),%rdx
 102297a:	test   %rcx,%rcx
 102297d:	je     1022a30 <destroy+0x1f0>
 1022983:	mov    %rdx,0x28(%rcx)
 1022987:	test   %rdx,%rdx
 102298a:	je     1022990 <destroy+0x150>
 102298c:	mov    %rcx,0x20(%rdx)
 1022990:	lea    0x20(%r13),%rcx
 1022994:	vxorps %xmm0,%xmm0,%xmm0
 1022998:	vmovups %xmm0,(%rcx)
 102299c:	mov    0x10(%r13),%rdx
 10229a0:	mov    0x18(%r13),%rcx
 10229a4:	test   %rdx,%rdx
 10229a7:	je     1022a20 <destroy+0x1e0>
 10229a9:	mov    %rcx,0x18(%rdx)
 10229ad:	test   %rcx,%rcx
 10229b0:	je     10229ba <destroy+0x17a>
 10229b2:	mov    0x10(%r13),%rax
 10229b6:	mov    %rax,0x10(%rcx)
 10229ba:	addq   $0xffffffffffff0000,0x18(%rbx)
 10229c2:	mov    0x1608(%rbx),%rax
 10229c9:	test   %rax,%rax
 10229cc:	je     1022b0e <destroy+0x2ce>
 10229d2:	mov    0x20(%rax),%r14
 10229d6:	addq   $0xffffffffffff0000,0x208(%r14)
 10229e1:	mov    0x450(%r14),%rax
 10229e8:	cmp    $0x10,%rax
 10229ec:	jb     1022920 <destroy+0xe0>
 10229f2:	lea    0x1000(%r13),%rdi
 10229f9:	mov    $0xf000,%esi
 10229fe:	mov    $0x4,%edx
 1022a03:	call   10278f0 <madvise@plt>
 1022a08:	mov    0x450(%r14),%rax
 1022a0f:	jmp    1022920 <destroy+0xe0>
 1022a14:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022a20:	mov    %rcx,(%rax)
 1022a23:	test   %rcx,%rcx
 1022a26:	jne    10229b2 <destroy+0x172>
 1022a28:	jmp    10229ba <destroy+0x17a>
 1022a2a:	nopw   0x0(%rax,%rax,1)
 1022a30:	mov    %rdx,0x8(%rax)
 1022a34:	test   %rdx,%rdx
 1022a37:	jne    102298c <destroy+0x14c>
 1022a3d:	jmp    1022990 <destroy+0x150>
 1022a42:	mov    -0x30(%rbp),%r14
 1022a46:	cmpq   $0x0,0x438(%r14)
 1022a4e:	je     1022aa3 <destroy+0x263>
 1022a50:	lea    0x230(%r14),%r15
 1022a57:	mov    $0xfffffffffffffe00,%r12
 1022a5e:	xor    %r13d,%r13d
 1022a61:	jmp    1022a97 <destroy+0x257>
 1022a63:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022a70:	mov    0x430(%r14),%rax
 1022a77:	add    %r12,%rax
 1022a7a:	mov    (%rax),%rdi
 1022a7d:	mov    $0x200000,%esi
 1022a82:	call   1027770 <munmap@plt>
 1022a87:	inc    %r13
 1022a8a:	add    $0x8,%r12
 1022a8e:	cmp    0x438(%r14),%r13
 1022a95:	jae    1022aa3 <destroy+0x263>
 1022a97:	cmp    $0x3f,%r13
 1022a9b:	ja     1022a70 <destroy+0x230>
 1022a9d:	lea    (%r15,%r13,8),%rax
 1022aa1:	jmp    1022a7a <destroy+0x23a>
 1022aa3:	mov    0x440(%r14),%rax
 1022aaa:	shl    $0x3,%rax
 1022aae:	sub    %rax,0x18(%rbx)
 1022ab2:	mov    0x1608(%rbx),%rcx
 1022ab9:	test   %rcx,%rcx
 1022abc:	je     1022b0e <destroy+0x2ce>
 1022abe:	mov    0x20(%rcx),%rcx
 1022ac2:	sub    %rax,0x208(%rcx)
 1022ac9:	mov    0x430(%r14),%rdi
 1022ad0:	call   1027570 <free@plt>
 1022ad5:	addq   $0xfffffffffffffba8,0x18(%rbx)
 1022add:	mov    0x1608(%rbx),%rax
 1022ae4:	test   %rax,%rax
 1022ae7:	je     1022b0e <destroy+0x2ce>
 1022ae9:	mov    0x20(%rax),%rax
 1022aed:	addq   $0xfffffffffffffba8,0x208(%rax)
 1022af8:	mov    %r14,%rdi
 1022afb:	add    $0x8,%rsp
 1022aff:	pop    %rbx
 1022b00:	pop    %r12
 1022b02:	pop    %r13
 1022b04:	pop    %r14
 1022b06:	pop    %r15
 1022b08:	pop    %rbp
 1022b09:	jmp    1027570 <free@plt>
 1022b0e:	call   10187d4 <myl_rc_invariant_failed>
 1022b13:	int3
 1022b14:	int3
 1022b15:	int3
 1022b16:	int3
 1022b17:	int3
 1022b18:	int3
 1022b19:	int3
 1022b1a:	int3
 1022b1b:	int3
 1022b1c:	int3
 1022b1d:	int3
 1022b1e:	int3
 1022b1f:	int3

0000000001022b20 <teardown>:
 1022b20:	push   %rbp
 1022b21:	mov    %rsp,%rbp
 1022b24:	push   %r15
 1022b26:	push   %r14
 1022b28:	push   %r13
 1022b2a:	push   %r12
 1022b2c:	push   %rbx
 1022b2d:	sub    $0x18,%rsp
 1022b31:	mov    0x1608(%rdi),%rax
 1022b38:	cmpl   $0x0,0xd0(%rax)
 1022b3f:	jne    1022de9 <teardown+0x2c9>
 1022b45:	cmpq   $0x0,0xc0(%rax)
 1022b4d:	jne    1022de9 <teardown+0x2c9>
 1022b53:	mov    %rdi,%rbx
 1022b56:	mov    0x20(%rax),%r14
 1022b5a:	xor    %eax,%eax
 1022b5c:	mov    0x1610(%rbx,%rax,8),%rcx
 1022b64:	test   %rcx,%rcx
 1022b67:	jne    1022ba0 <teardown+0x80>
 1022b69:	nopl   0x0(%rax)
 1022b70:	movq   $0x0,0x1610(%rbx,%rax,8)
 1022b7c:	inc    %rax
 1022b7f:	cmp    $0x20,%rax
 1022b83:	je     1022bb8 <teardown+0x98>
 1022b85:	mov    0x1610(%rbx,%rax,8),%rcx
 1022b8d:	test   %rcx,%rcx
 1022b90:	je     1022b70 <teardown+0x50>
 1022b92:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022ba0:	mov    %rcx,%rdx
 1022ba3:	and    $0xffffffffffff0000,%rdx
 1022baa:	decq   0x38(%rdx)
 1022bae:	mov    (%rcx),%rcx
 1022bb1:	test   %rcx,%rcx
 1022bb4:	jne    1022ba0 <teardown+0x80>
 1022bb6:	jmp    1022b70 <teardown+0x50>
 1022bb8:	movq   $0x0,0x1710(%rbx)
 1022bc3:	mov    0x200(%r14),%rdi
 1022bca:	xor    %r15d,%r15d
 1022bcd:	test   %rdi,%rdi
 1022bd0:	je     1022c22 <teardown+0x102>
 1022bd2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022be0:	mov    0x8(%rdi),%rax
 1022be4:	mov    %rax,0x200(%r14)
 1022beb:	mov    0x10(%rdi),%rax
 1022bef:	sub    %rax,0x18(%rbx)
 1022bf3:	mov    0x1608(%rbx),%rcx
 1022bfa:	test   %rcx,%rcx
 1022bfd:	je     1022de9 <teardown+0x2c9>
 1022c03:	mov    0x20(%rcx),%rcx
 1022c07:	sub    %rax,0x208(%rcx)
 1022c0e:	call   1022820 <large_release>
 1022c13:	inc    %r15
 1022c16:	mov    0x200(%r14),%rdi
 1022c1d:	test   %rdi,%rdi
 1022c20:	jne    1022be0 <teardown+0xc0>
 1022c22:	xor    %r13d,%r13d
 1022c25:	mov    %r14,-0x30(%rbp)
 1022c29:	jmp    1022c45 <teardown+0x125>
 1022c2b:	nopl   0x0(%rax,%rax,1)
 1022c30:	mov    -0x38(%rbp),%r13
 1022c34:	inc    %r13
 1022c37:	cmp    $0x20,%r13
 1022c3b:	mov    -0x30(%rbp),%r14
 1022c3f:	je     1022d92 <teardown+0x272>
 1022c45:	mov    %r13,-0x38(%rbp)
 1022c49:	shl    $0x4,%r13
 1022c4d:	mov    %r14,%rax
 1022c50:	mov    (%r14,%r13,1),%r14
 1022c54:	test   %r14,%r14
 1022c57:	je     1022c30 <teardown+0x110>
 1022c59:	add    %rax,%r13
 1022c5c:	jmp    1022c87 <teardown+0x167>
 1022c5e:	xchg   %ax,%ax
 1022c60:	mov    0x448(%r12),%rcx
 1022c68:	mov    %rcx,(%r14)
 1022c6b:	mov    %r14,0x448(%r12)
 1022c73:	inc    %rax
 1022c76:	mov    %rax,0x450(%r12)
 1022c7e:	mov    0x0(%r13),%r14
 1022c82:	test   %r14,%r14
 1022c85:	je     1022c30 <teardown+0x110>
 1022c87:	add    0x38(%r14),%r15
 1022c8b:	movq   $0x0,0x38(%r14)
 1022c93:	test   %rbx,%rbx
 1022c96:	je     1022de9 <teardown+0x2c9>
 1022c9c:	mov    0x1608(%rbx),%rcx
 1022ca3:	test   %rcx,%rcx
 1022ca6:	je     1022de9 <teardown+0x2c9>
 1022cac:	mov    (%r14),%rax
 1022caf:	shl    $0x4,%rax
 1022cb3:	add    0x20(%rcx),%rax
 1022cb7:	cmpq   $0x0,0x48(%r14)
 1022cbc:	jne    1022cc8 <teardown+0x1a8>
 1022cbe:	mov    0x30(%r14),%rcx
 1022cc2:	cmp    0x40(%r14),%rcx
 1022cc6:	je     1022cf2 <teardown+0x1d2>
 1022cc8:	mov    0x20(%r14),%rcx
 1022ccc:	mov    0x28(%r14),%rdx
 1022cd0:	test   %rcx,%rcx
 1022cd3:	je     1022d80 <teardown+0x260>
 1022cd9:	mov    %rdx,0x28(%rcx)
 1022cdd:	test   %rdx,%rdx
 1022ce0:	je     1022ce6 <teardown+0x1c6>
 1022ce2:	mov    %rcx,0x20(%rdx)
 1022ce6:	lea    0x20(%r14),%rcx
 1022cea:	vxorps %xmm0,%xmm0,%xmm0
 1022cee:	vmovups %xmm0,(%rcx)
 1022cf2:	mov    0x10(%r14),%rdx
 1022cf6:	mov    0x18(%r14),%rcx
 1022cfa:	test   %rdx,%rdx
 1022cfd:	je     1022d70 <teardown+0x250>
 1022cff:	mov    %rcx,0x18(%rdx)
 1022d03:	test   %rcx,%rcx
 1022d06:	je     1022d10 <teardown+0x1f0>
 1022d08:	mov    0x10(%r14),%rax
 1022d0c:	mov    %rax,0x10(%rcx)
 1022d10:	addq   $0xffffffffffff0000,0x18(%rbx)
 1022d18:	mov    0x1608(%rbx),%rax
 1022d1f:	test   %rax,%rax
 1022d22:	je     1022de9 <teardown+0x2c9>
 1022d28:	mov    0x20(%rax),%r12
 1022d2c:	addq   $0xffffffffffff0000,0x208(%r12)
 1022d38:	mov    0x450(%r12),%rax
 1022d40:	cmp    $0x10,%rax
 1022d44:	jb     1022c60 <teardown+0x140>
 1022d4a:	lea    0x1000(%r14),%rdi
 1022d51:	mov    $0xf000,%esi
 1022d56:	mov    $0x4,%edx
 1022d5b:	call   10278f0 <madvise@plt>
 1022d60:	mov    0x450(%r12),%rax
 1022d68:	jmp    1022c60 <teardown+0x140>
 1022d6d:	nopl   (%rax)
 1022d70:	mov    %rcx,(%rax)
 1022d73:	test   %rcx,%rcx
 1022d76:	jne    1022d08 <teardown+0x1e8>
 1022d78:	jmp    1022d10 <teardown+0x1f0>
 1022d7a:	nopw   0x0(%rax,%rax,1)
 1022d80:	mov    %rdx,0x8(%rax)
 1022d84:	test   %rdx,%rdx
 1022d87:	jne    1022ce2 <teardown+0x1c2>
 1022d8d:	jmp    1022ce6 <teardown+0x1c6>
 1022d92:	mov    0x40(%rbx),%rax
 1022d96:	sub    %r15,%rax
 1022d99:	jb     1022de9 <teardown+0x2c9>
 1022d9b:	mov    0x440(%r14),%rcx
 1022da2:	lea    0x458(,%rcx,8),%rcx
 1022daa:	cmp    %rcx,0x208(%r14)
 1022db1:	jne    1022de9 <teardown+0x2c9>
 1022db3:	mov    %rax,0x40(%rbx)
 1022db7:	mov    0x1608(%rbx),%rax
 1022dbe:	movq   $0x0,0xc8(%rax)
 1022dc9:	mov    0x50(%rbx),%rax
 1022dcd:	cmp    $0xffffffffffffffff,%rax
 1022dd1:	je     1022dda <teardown+0x2ba>
 1022dd3:	inc    %rax
 1022dd6:	mov    %rax,0x50(%rbx)
 1022dda:	add    $0x18,%rsp
 1022dde:	pop    %rbx
 1022ddf:	pop    %r12
 1022de1:	pop    %r13
 1022de3:	pop    %r14
 1022de5:	pop    %r15
 1022de7:	pop    %rbp
 1022de8:	ret
 1022de9:	call   10187d4 <myl_rc_invariant_failed>
 1022dee:	int3
 1022def:	int3

0000000001022df0 <raw_bytes>:
 1022df0:	push   %rbp
 1022df1:	mov    %rsp,%rbp
 1022df4:	push   %r15
 1022df6:	push   %r14
 1022df8:	push   %rbx
 1022df9:	sub    $0x28,%rsp
 1022dfd:	test   %rdi,%rdi
 1022e00:	je     1023031 <raw_bytes+0x241>
 1022e06:	mov    0x1608(%rdi),%rax
 1022e0d:	test   %rax,%rax
 1022e10:	je     1023031 <raw_bytes+0x241>
 1022e16:	test   %edx,%edx
 1022e18:	je     1022ebd <raw_bytes+0xcd>
 1022e1e:	mov    $0x10,%r8d
 1022e24:	movabs $0x3fffffffff,%r9
 1022e2e:	movq   $0x100ba90,-0x38(%rbp)
 1022e36:	mov    %rsi,-0x30(%rbp)
 1022e3a:	mov    %edx,-0x28(%rbp)
 1022e3d:	movl   $0x0,-0x24(%rbp)
 1022e44:	movq   $0x0,-0x20(%rbp)
 1022e4c:	add    %rsi,%r8
 1022e4f:	setb   %cl
 1022e52:	cmp    %r9,%rsi
 1022e55:	seta   %sil
 1022e59:	or     %cl,%sil
 1022e5c:	mov    $0x1,%ecx
 1022e61:	jne    1022ea1 <raw_bytes+0xb1>
 1022e63:	mov    $0x3,%ecx
 1022e68:	cmp    0x70(%rdi),%edx
 1022e6b:	ja     1022ea1 <raw_bytes+0xb1>
 1022e6d:	lea    -0x38(%rbp),%rsi
 1022e71:	lea    -0x20(%rbp),%rdx
 1022e75:	mov    %rdi,%rbx
 1022e78:	call   *(%rax)
 1022e7a:	mov    %eax,%ecx
 1022e7c:	mov    -0x20(%rbp),%rax
 1022e80:	test   %ecx,%ecx
 1022e82:	je     1022f10 <raw_bytes+0x120>
 1022e88:	test   %rax,%rax
 1022e8b:	jne    1023031 <raw_bytes+0x241>
 1022e91:	mov    0x1608(%rbx),%rax
 1022e98:	test   %rax,%rax
 1022e9b:	je     1023031 <raw_bytes+0x241>
 1022ea1:	cmpl   $0x0,0x124(%rax)
 1022ea8:	jne    1022eb0 <raw_bytes+0xc0>
 1022eaa:	mov    %ecx,0x124(%rax)
 1022eb0:	xor    %eax,%eax
 1022eb2:	add    $0x28,%rsp
 1022eb6:	pop    %rbx
 1022eb7:	pop    %r14
 1022eb9:	pop    %r15
 1022ebb:	pop    %rbp
 1022ebc:	ret
 1022ebd:	mov    $0x20,%r8d
 1022ec3:	movabs $0x3ffffffffffffff,%r9
 1022ecd:	cmp    $0x1fe0,%rsi
 1022ed4:	ja     1022e2e <raw_bytes+0x3e>
 1022eda:	cmpq   $0x1021230,(%rax)
 1022ee1:	jne    1022e2e <raw_bytes+0x3e>
 1022ee7:	lea    0x2f(%rsi),%rax
 1022eeb:	shr    $0x4,%rax
 1022eef:	movzbl 0x100b820(%rax),%edx
 1022ef6:	mov    0x1610(%rdi,%rdx,8),%rax
 1022efe:	test   %rax,%rax
 1022f01:	je     1022f1a <raw_bytes+0x12a>
 1022f03:	mov    (%rax),%r8
 1022f06:	mov    %r8,0x1610(%rdi,%rdx,8)
 1022f0e:	jmp    1022f3d <raw_bytes+0x14d>
 1022f10:	test   %rax,%rax
 1022f13:	jne    1022eb2 <raw_bytes+0xc2>
 1022f15:	jmp    1023031 <raw_bytes+0x241>
 1022f1a:	mov    %rdi,%rbx
 1022f1d:	mov    %rsi,%r14
 1022f20:	mov    %rdx,%rsi
 1022f23:	mov    %ecx,%r15d
 1022f26:	call   1021eb0 <slab_refill>
 1022f2b:	mov    %r15d,%ecx
 1022f2e:	mov    %r14,%rsi
 1022f31:	mov    %rbx,%rdi
 1022f34:	test   %rax,%rax
 1022f37:	je     1022fe5 <raw_bytes+0x1f5>
 1022f3d:	test   %ecx,%ecx
 1022f3f:	je     1022fab <raw_bytes+0x1bb>
 1022f41:	lea    0x20(%rax),%rcx
 1022f45:	lea    0xf(%rsi),%rdx
 1022f49:	shr    $0x4,%rdx
 1022f4d:	cmp    $0x8,%rdx
 1022f51:	ja     102300d <raw_bytes+0x21d>
 1022f57:	jmp    *0x1001ca0(,%rdx,8)
 1022f5e:	vxorps %xmm0,%xmm0,%xmm0
 1022f62:	vmovaps %xmm0,0x90(%rax)
 1022f6a:	vxorps %xmm0,%xmm0,%xmm0
 1022f6e:	vmovaps %xmm0,0x80(%rax)
 1022f76:	vxorps %xmm0,%xmm0,%xmm0
 1022f7a:	vmovaps %xmm0,0x70(%rax)
 1022f7f:	vxorps %xmm0,%xmm0,%xmm0
 1022f83:	vmovaps %xmm0,0x60(%rax)
 1022f88:	vxorps %xmm0,%xmm0,%xmm0
 1022f8c:	vmovaps %xmm0,0x50(%rax)
 1022f91:	vxorps %xmm0,%xmm0,%xmm0
 1022f95:	vmovaps %xmm0,0x40(%rax)
 1022f9a:	vxorps %xmm0,%xmm0,%xmm0
 1022f9e:	vmovaps %xmm0,0x30(%rax)
 1022fa3:	vxorps %xmm0,%xmm0,%xmm0
 1022fa7:	vmovaps %xmm0,(%rcx)
 1022fab:	movq   $0x1,(%rax)
 1022fb2:	movq   $0x0,0x8(%rax)
 1022fba:	shl    $0x2,%rsi
 1022fbe:	mov    %rsi,0x10(%rax)
 1022fc2:	movq   $0x100ba90,0x18(%rax)
 1022fca:	vmovdqu 0x40(%rdi),%xmm0
 1022fcf:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1022fd3:	vpsubq %xmm1,%xmm0,%xmm0
 1022fd7:	vmovdqu %xmm0,0x40(%rdi)
 1022fdc:	add    $0x20,%rax
 1022fe0:	jmp    1022eb2 <raw_bytes+0xc2>
 1022fe5:	mov    0x1608(%rdi),%rax
 1022fec:	test   %rax,%rax
 1022fef:	je     1023031 <raw_bytes+0x241>
 1022ff1:	cmpl   $0x0,0x124(%rax)
 1022ff8:	jne    1022eb0 <raw_bytes+0xc0>
 1022ffe:	movl   $0x1,0x124(%rax)
 1023008:	jmp    1022eb0 <raw_bytes+0xc0>
 102300d:	mov    %rdi,%r14
 1023010:	mov    %rcx,%rdi
 1023013:	mov    %rsi,%rbx
 1023016:	xor    %esi,%esi
 1023018:	mov    %rbx,%rdx
 102301b:	mov    %rax,%r15
 102301e:	call   10274d0 <memset@plt>
 1023023:	mov    %r15,%rax
 1023026:	mov    %rbx,%rsi
 1023029:	mov    %r14,%rdi
 102302c:	jmp    1022fab <raw_bytes+0x1bb>
 1023031:	call   10187d4 <myl_rc_invariant_failed>
 1023036:	int3
 1023037:	int3
 1023038:	int3
 1023039:	int3
 102303a:	int3
 102303b:	int3
 102303c:	int3
 102303d:	int3
 102303e:	int3
 102303f:	int3

0000000001023040 <storage_extend>:
 1023040:	push   %rbp
 1023041:	mov    %rsp,%rbp
 1023044:	push   %r15
 1023046:	push   %r14
 1023048:	push   %r13
 102304a:	push   %r12
 102304c:	push   %rbx
 102304d:	sub    $0x18,%rsp
 1023051:	test   %rsi,%rsi
 1023054:	je     1023153 <storage_extend+0x113>
 102305a:	mov    -0x10(%rsi),%rax
 102305e:	movabs $0xc000000000000003,%r8
 1023068:	and    %rax,%r8
 102306b:	neg    %r8
 102306e:	jno    1023153 <storage_extend+0x113>
 1023074:	cmpq   $0x1,-0x20(%rsi)
 1023079:	jne    1023153 <storage_extend+0x113>
 102307f:	cmpq   $0x0,-0x18(%rsi)
 1023084:	jne    1023153 <storage_extend+0x113>
 102308a:	movabs $0x1000000000000000,%r8
 1023094:	and    %r8,%rax
 1023097:	mov    %rdx,%r8
 102309a:	shr    $0x3a,%r8
 102309e:	or     %rax,%r8
 10230a1:	jne    1023153 <storage_extend+0x113>
 10230a7:	mov    -0x8(%rsi),%rax
 10230ab:	mov    (%rax),%rbx
 10230ae:	test   %rbx,%rbx
 10230b1:	je     1023153 <storage_extend+0x113>
 10230b7:	mov    $0xffffffffffffffaf,%rax
 10230be:	mov    %rdx,%r13
 10230c1:	xor    %edx,%edx
 10230c3:	div    %rbx
 10230c6:	mov    %rax,%rdx
 10230c9:	xor    %eax,%eax
 10230cb:	cmp    %rdx,%r13
 10230ce:	ja     1023155 <storage_extend+0x115>
 10230d4:	imul   %r13,%rbx
 10230d8:	lea    0x20(%rbx),%r12
 10230dc:	cmp    -0x38(%rsi),%r12
 10230e0:	jbe    1023153 <storage_extend+0x113>
 10230e2:	mov    %ecx,-0x2c(%rbp)
 10230e5:	add    $0x50,%rbx
 10230e9:	mov    %rbx,%r14
 10230ec:	mov    %rsi,%r15
 10230ef:	sub    -0x40(%rsi),%r14
 10230f3:	mov    %rdi,-0x38(%rbp)
 10230f7:	mov    %r14,%rsi
 10230fa:	call   10231f0 <reserve>
 10230ff:	test   %eax,%eax
 1023101:	je     1023153 <storage_extend+0x113>
 1023103:	mov    %r15,%rdi
 1023106:	mov    -0x40(%r15),%r15
 102310a:	add    $0xffffffffffffffb0,%rdi
 102310e:	mov    %r15,%rsi
 1023111:	mov    %rbx,%rdx
 1023114:	call   1023270 <large_grow>
 1023119:	test   %rax,%rax
 102311c:	je     1023153 <storage_extend+0x113>
 102311e:	cmpl   $0x0,-0x2c(%rbp)
 1023122:	je     1023141 <storage_extend+0x101>
 1023124:	cmpq   $0x0,0x20(%rax)
 1023129:	jne    1023141 <storage_extend+0x101>
 102312b:	add    %rax,%r15
 102312e:	mov    %r15,%rdi
 1023131:	xor    %esi,%esi
 1023133:	mov    %r14,%rdx
 1023136:	mov    %rax,%r15
 1023139:	call   10274d0 <memset@plt>
 102313e:	mov    %r15,%rax
 1023141:	mov    (%rax),%rcx
 1023144:	test   %rcx,%rcx
 1023147:	je     1023164 <storage_extend+0x124>
 1023149:	mov    %rax,0x8(%rcx)
 102314d:	mov    -0x38(%rbp),%rcx
 1023151:	jmp    1023184 <storage_extend+0x144>
 1023153:	xor    %eax,%eax
 1023155:	add    $0x18,%rsp
 1023159:	pop    %rbx
 102315a:	pop    %r12
 102315c:	pop    %r13
 102315e:	pop    %r14
 1023160:	pop    %r15
 1023162:	pop    %rbp
 1023163:	ret
 1023164:	mov    -0x38(%rbp),%rcx
 1023168:	test   %rcx,%rcx
 102316b:	je     10231e3 <storage_extend+0x1a3>
 102316d:	mov    0x1608(%rcx),%rdx
 1023174:	test   %rdx,%rdx
 1023177:	je     10231e3 <storage_extend+0x1a3>
 1023179:	mov    0x20(%rdx),%rdx
 102317d:	mov    %rax,0x200(%rdx)
 1023184:	mov    0x8(%rax),%rdx
 1023188:	test   %rdx,%rdx
 102318b:	je     1023190 <storage_extend+0x150>
 102318d:	mov    %rax,(%rdx)
 1023190:	mov    %rbx,0x10(%rax)
 1023194:	mov    %r12,0x18(%rax)
 1023198:	movabs $0xf000000000000003,%rdx
 10231a2:	and    0x40(%rax),%rdx
 10231a6:	lea    (%rdx,%r13,4),%rdx
 10231aa:	mov    %rdx,0x40(%rax)
 10231ae:	add    %r14,0x18(%rcx)
 10231b2:	mov    0x1608(%rcx),%rdx
 10231b9:	test   %rdx,%rdx
 10231bc:	je     10231e3 <storage_extend+0x1a3>
 10231be:	mov    0x20(%rdx),%rdx
 10231c2:	add    %r14,0x208(%rdx)
 10231c9:	mov    0x50(%rcx),%rdx
 10231cd:	cmp    $0xffffffffffffffff,%rdx
 10231d1:	je     10231da <storage_extend+0x19a>
 10231d3:	inc    %rdx
 10231d6:	mov    %rdx,0x50(%rcx)
 10231da:	add    $0x50,%rax
 10231de:	jmp    1023155 <storage_extend+0x115>
 10231e3:	call   10187d4 <myl_rc_invariant_failed>
 10231e8:	int3
 10231e9:	int3
 10231ea:	int3
 10231eb:	int3
 10231ec:	int3
 10231ed:	int3
 10231ee:	int3
 10231ef:	int3

00000000010231f0 <reserve>:
 10231f0:	push   %rbp
 10231f1:	mov    %rsp,%rbp
 10231f4:	push   %r14
 10231f6:	push   %rbx
 10231f7:	mov    %rsi,%r14
 10231fa:	mov    %rdi,%rbx
 10231fd:	mov    0x18(%rdi),%rcx
 1023201:	mov    %rcx,%rax
 1023204:	add    %rsi,%rax
 1023207:	jb     102322a <reserve+0x3a>
 1023209:	mov    0x58(%rbx),%rdx
 102320d:	mov    $0x1,%eax
 1023212:	test   %rdx,%rdx
 1023215:	je     1023268 <reserve+0x78>
 1023217:	sub    %rcx,%rdx
 102321a:	setb   %cl
 102321d:	cmp    %rdx,%r14
 1023220:	seta   %dl
 1023223:	or     %cl,%dl
 1023225:	cmp    $0x1,%dl
 1023228:	jne    1023268 <reserve+0x78>
 102322a:	mov    %rbx,%rdi
 102322d:	call   10222c0 <trim_empty>
 1023232:	mov    0x18(%rbx),%rcx
 1023236:	mov    %rcx,%rax
 1023239:	add    %r14,%rax
 102323c:	jb     102325f <reserve+0x6f>
 102323e:	mov    0x58(%rbx),%rdx
 1023242:	mov    $0x1,%eax
 1023247:	test   %rdx,%rdx
 102324a:	je     1023268 <reserve+0x78>
 102324c:	sub    %rcx,%rdx
 102324f:	setb   %cl
 1023252:	cmp    %rdx,%r14
 1023255:	seta   %dl
 1023258:	or     %cl,%dl
 102325a:	cmp    $0x1,%dl
 102325d:	jne    1023268 <reserve+0x78>
 102325f:	movl   $0x1,0x6c(%rbx)
 1023266:	xor    %eax,%eax
 1023268:	pop    %rbx
 1023269:	pop    %r14
 102326b:	pop    %rbp
 102326c:	ret
 102326d:	int3
 102326e:	int3
 102326f:	int3

0000000001023270 <large_grow>:
 1023270:	push   %rbp
 1023271:	mov    %rsp,%rbp
 1023274:	push   %r15
 1023276:	push   %r14
 1023278:	push   %rbx
 1023279:	push   %rax
 102327a:	mov    %rsi,%rbx
 102327d:	mov    0x20(%rdi),%rsi
 1023281:	test   %rsi,%rsi
 1023284:	setne  %cl
 1023287:	cmp    $0x20000,%rdx
 102328e:	setae  %r8b
 1023292:	or     %cl,%r8b
 1023295:	jne    10232a9 <large_grow+0x39>
 1023297:	mov    %rdx,%rsi
 102329a:	add    $0x8,%rsp
 102329e:	pop    %rbx
 102329f:	pop    %r14
 10232a1:	pop    %r15
 10232a3:	pop    %rbp
 10232a4:	jmp    1027670 <realloc@plt>
 10232a9:	test   %rsi,%rsi
 10232ac:	je     10232e8 <large_grow+0x78>
 10232ae:	cmp    $0xffffffffffffefff,%rdx
 10232b5:	ja     102331e <large_grow+0xae>
 10232b7:	add    $0xfff,%rdx
 10232be:	and    $0xfffffffffffff000,%rdx
 10232c5:	cmp    %rsi,%rdx
 10232c8:	jbe    1023320 <large_grow+0xb0>
 10232ca:	mov    %rdx,%rbx
 10232cd:	mov    $0x1,%ecx
 10232d2:	xor    %eax,%eax
 10232d4:	call   1027900 <mremap@plt>
 10232d9:	cmp    $0xffffffffffffffff,%rax
 10232dd:	je     102331e <large_grow+0xae>
 10232df:	mov    %rax,%rdi
 10232e2:	mov    %rbx,0x20(%rax)
 10232e6:	jmp    1023320 <large_grow+0xb0>
 10232e8:	mov    %rdi,%r14
 10232eb:	mov    %rdx,%rdi
 10232ee:	call   10226b0 <large_block>
 10232f3:	test   %rax,%rax
 10232f6:	je     102331e <large_grow+0xae>
 10232f8:	mov    0x20(%rax),%r15
 10232fc:	mov    %rax,%rdi
 10232ff:	mov    %r14,%rsi
 1023302:	mov    %rbx,%rdx
 1023305:	mov    %rax,%rbx
 1023308:	call   1027520 <memcpy@plt>
 102330d:	mov    %r15,0x20(%rbx)
 1023311:	mov    %r14,%rdi
 1023314:	call   1027570 <free@plt>
 1023319:	mov    %rbx,%rdi
 102331c:	jmp    1023320 <large_grow+0xb0>
 102331e:	xor    %edi,%edi
 1023320:	mov    %rdi,%rax
 1023323:	add    $0x8,%rsp
 1023327:	pop    %rbx
 1023328:	pop    %r14
 102332a:	pop    %r15
 102332c:	pop    %rbp
 102332d:	ret
 102332e:	int3
 102332f:	int3

0000000001023330 <myl_rc_native_shape>:
 1023330:	push   %rbp
 1023331:	mov    %rsp,%rbp
 1023334:	push   %r15
 1023336:	push   %r14
 1023338:	push   %r13
 102333a:	push   %r12
 102333c:	push   %rbx
 102333d:	sub    $0xc8,%rsp
 1023344:	mov    %rsi,%rbx
 1023347:	mov    0x1608(%rdi),%rax
 102334e:	mov    0x34(%rsi),%ecx
 1023351:	cmp    %rcx,0xa0(%rax)
 1023358:	jbe    102347b <myl_rc_native_shape+0x14b>
 102335e:	mov    0x98(%rax),%rdx
 1023365:	shl    $0x4,%rcx
 1023369:	cmp    %rbx,(%rdx,%rcx,1)
 102336d:	jne    102347b <myl_rc_native_shape+0x14b>
 1023373:	add    %rcx,%rdx
 1023376:	mov    0x8(%rdx),%rax
 102337a:	test   %rax,%rax
 102337d:	jne    10235ef <myl_rc_native_shape+0x2bf>
 1023383:	mov    (%rbx),%rax
 1023386:	mov    %rax,-0xa8(%rbp)
 102338d:	vxorps %xmm0,%xmm0,%xmm0
 1023391:	vmovups %ymm0,-0xa0(%rbp)
 1023399:	movzwl 0x30(%rbx),%eax
 102339d:	test   %eax,%eax
 102339f:	je     10233b9 <myl_rc_native_shape+0x89>
 10233a1:	cmp    $0x7,%eax
 10233a4:	je     10233b9 <myl_rc_native_shape+0x89>
 10233a6:	cmp    $0x1,%eax
 10233a9:	jne    102363d <myl_rc_native_shape+0x30d>
 10233af:	movl   $0x1,-0xa0(%rbp)
 10233b9:	vmovups %ymm0,-0xc8(%rbp)
 10233c1:	vmovups %ymm0,-0xd8(%rbp)
 10233c9:	mov    %rbx,-0xe8(%rbp)
 10233d0:	lea    -0xa8(%rbp),%rax
 10233d7:	mov    %rax,-0xe0(%rbp)
 10233de:	mov    0x1608(%rdi),%rax
 10233e5:	test   %rax,%rax
 10233e8:	je     1023635 <myl_rc_native_shape+0x305>
 10233ee:	cmpq   $0x0,0xc0(%rax)
 10233f6:	jne    1023635 <myl_rc_native_shape+0x305>
 10233fc:	mov    0x34(%rbx),%ecx
 10233ff:	cmp    %rcx,0xa0(%rax)
 1023406:	jbe    102349a <myl_rc_native_shape+0x16a>
 102340c:	mov    0x98(%rax),%rdx
 1023413:	shl    $0x4,%rcx
 1023417:	cmp    %rbx,(%rdx,%rcx,1)
 102341b:	jne    102349a <myl_rc_native_shape+0x16a>
 102341d:	add    %rcx,%rdx
 1023420:	mov    0x8(%rdx),%rax
 1023424:	test   %rax,%rax
 1023427:	je     10234b7 <myl_rc_native_shape+0x187>
 102342d:	cmpq   $0x0,0x10(%rax)
 1023432:	jne    1023635 <myl_rc_native_shape+0x305>
 1023438:	cmpq   $0x0,0x18(%rax)
 102343d:	jne    1023635 <myl_rc_native_shape+0x305>
 1023443:	cmpq   $0x0,0x20(%rax)
 1023448:	jne    1023635 <myl_rc_native_shape+0x305>
 102344e:	cmpq   $0x0,0x28(%rax)
 1023453:	jne    1023635 <myl_rc_native_shape+0x305>
 1023459:	cmpq   $0x0,0x30(%rax)
 102345e:	jne    1023635 <myl_rc_native_shape+0x305>
 1023464:	cmpq   $0x0,0x38(%rax)
 1023469:	jne    1023635 <myl_rc_native_shape+0x305>
 102346f:	mov    0x1608(%rdi),%rdi
 1023476:	jmp    10235cb <myl_rc_native_shape+0x29b>
 102347b:	mov    %rdi,%rcx
 102347e:	mov    %rax,%rdi
 1023481:	mov    %rbx,%rsi
 1023484:	call   1018df4 <myl_rc_binding_find_slow>
 1023489:	mov    %rcx,%rdi
 102348c:	test   %rax,%rax
 102348f:	jne    10235ef <myl_rc_native_shape+0x2bf>
 1023495:	jmp    1023383 <myl_rc_native_shape+0x53>
 102349a:	mov    %rdi,%rcx
 102349d:	mov    %rax,%rdi
 10234a0:	mov    %rbx,%rsi
 10234a3:	vzeroupper
 10234a6:	call   1018df4 <myl_rc_binding_find_slow>
 10234ab:	mov    %rcx,%rdi
 10234ae:	test   %rax,%rax
 10234b1:	jne    102342d <myl_rc_native_shape+0xfd>
 10234b7:	movl   $0x5,-0x80(%rbp)
 10234be:	vxorps %xmm0,%xmm0,%xmm0
 10234c2:	vmovups %xmm0,-0x7c(%rbp)
 10234c7:	movl   $0x0,-0x6c(%rbp)
 10234ce:	lea    -0xe8(%rbp),%rax
 10234d5:	mov    %rax,-0x68(%rbp)
 10234d9:	movq   $0x1,-0x60(%rbp)
 10234e1:	vxorps %xmm0,%xmm0,%xmm0
 10234e5:	vmovups %ymm0,-0x50(%rbp)
 10234ea:	movq   $0x0,-0x30(%rbp)
 10234f2:	mov    %rdi,%r14
 10234f5:	mov    %rdi,-0x58(%rbp)
 10234f9:	lea    -0x58(%rbp),%rdi
 10234fd:	lea    -0xa8(%rbp),%rsi
 1023504:	vzeroupper
 1023507:	call   10197b0 <builder_add>
 102350c:	test   %eax,%eax
 102350e:	je     1023527 <myl_rc_native_shape+0x1f7>
 1023510:	lea    -0x58(%rbp),%rdi
 1023514:	lea    -0x80(%rbp),%rsi
 1023518:	xor    %edx,%edx
 102351a:	call   1019bc0 <register_shapes>
 102351f:	test   %eax,%eax
 1023521:	sete   %r15b
 1023525:	jmp    102352a <myl_rc_native_shape+0x1fa>
 1023527:	xor    %r15d,%r15d
 102352a:	mov    -0x58(%rbp),%r12
 102352e:	mov    -0x50(%rbp),%rdi
 1023532:	mov    -0x38(%rbp),%r13
 1023536:	test   %rdi,%rdi
 1023539:	mov    %r14,%rax
 102353c:	je     102357e <myl_rc_native_shape+0x24e>
 102353e:	lea    0x0(,%r13,8),%rax
 1023546:	lea    (%rax,%rax,4),%rcx
 102354a:	mov    0x18(%r12),%rax
 102354f:	sub    %rcx,%rax
 1023552:	jb     1023635 <myl_rc_native_shape+0x305>
 1023558:	mov    0x1608(%r12),%rdx
 1023560:	mov    0x30(%rdx),%rsi
 1023564:	sub    %rcx,%rsi
 1023567:	jb     1023635 <myl_rc_native_shape+0x305>
 102356d:	mov    %rax,0x18(%r12)
 1023572:	mov    %rsi,0x30(%rdx)
 1023576:	call   1027570 <free@plt>
 102357b:	mov    %r14,%rax
 102357e:	mov    -0x48(%rbp),%rdi
 1023582:	test   %rdi,%rdi
 1023585:	je     10235bf <myl_rc_native_shape+0x28f>
 1023587:	shl    $0x4,%r13
 102358b:	mov    0x18(%r12),%rax
 1023590:	sub    %r13,%rax
 1023593:	jb     1023635 <myl_rc_native_shape+0x305>
 1023599:	mov    0x1608(%r12),%rcx
 10235a1:	mov    0x30(%rcx),%rdx
 10235a5:	sub    %r13,%rdx
 10235a8:	jb     1023635 <myl_rc_native_shape+0x305>
 10235ae:	mov    %rax,0x18(%r12)
 10235b3:	mov    %rdx,0x30(%rcx)
 10235b7:	call   1027570 <free@plt>
 10235bc:	mov    %r14,%rax
 10235bf:	mov    0x1608(%rax),%rdi
 10235c6:	test   %r15b,%r15b
 10235c9:	je     1023608 <myl_rc_native_shape+0x2d8>
 10235cb:	mov    0x34(%rbx),%eax
 10235ce:	cmp    %rax,0xa0(%rdi)
 10235d5:	jbe    1023628 <myl_rc_native_shape+0x2f8>
 10235d7:	mov    0x98(%rdi),%rcx
 10235de:	shl    $0x4,%rax
 10235e2:	cmp    %rbx,(%rcx,%rax,1)
 10235e6:	jne    1023628 <myl_rc_native_shape+0x2f8>
 10235e8:	add    %rax,%rcx
 10235eb:	mov    0x8(%rcx),%rax
 10235ef:	mov    0x8(%rax),%rax
 10235f3:	add    $0xc8,%rsp
 10235fa:	pop    %rbx
 10235fb:	pop    %r12
 10235fd:	pop    %r13
 10235ff:	pop    %r14
 1023601:	pop    %r15
 1023603:	pop    %rbp
 1023604:	vzeroupper
 1023607:	ret
 1023608:	test   %rdi,%rdi
 102360b:	je     1023635 <myl_rc_native_shape+0x305>
 102360d:	cmpl   $0x0,0x124(%rdi)
 1023614:	je     102361a <myl_rc_native_shape+0x2ea>
 1023616:	xor    %eax,%eax
 1023618:	jmp    10235f3 <myl_rc_native_shape+0x2c3>
 102361a:	movl   $0x1,0x124(%rdi)
 1023624:	xor    %eax,%eax
 1023626:	jmp    10235f3 <myl_rc_native_shape+0x2c3>
 1023628:	mov    %rbx,%rsi
 102362b:	vzeroupper
 102362e:	call   1018df4 <myl_rc_binding_find_slow>
 1023633:	jmp    10235ef <myl_rc_native_shape+0x2bf>
 1023635:	vzeroupper
 1023638:	call   10187d4 <myl_rc_invariant_failed>
 102363d:	vzeroupper
 1023640:	call   1027690 <abort@plt>
 1023645:	int3
 1023646:	int3
 1023647:	int3
 1023648:	int3
 1023649:	int3
 102364a:	int3
 102364b:	int3
 102364c:	int3
 102364d:	int3
 102364e:	int3
 102364f:	int3

0000000001023650 <flat_transfer>:
 1023650:	push   %rbp
 1023651:	mov    %rsp,%rbp
 1023654:	push   %r15
 1023656:	push   %r14
 1023658:	push   %rbx
 1023659:	push   %rax
 102365a:	mov    0x40(%rsi),%r9d
 102365e:	cmp    $0x10,%r9
 1023662:	jbe    1023674 <flat_transfer+0x24>
 1023664:	mov    $0xffffffff,%eax
 1023669:	add    $0x8,%rsp
 102366d:	pop    %rbx
 102366e:	pop    %r14
 1023670:	pop    %r15
 1023672:	pop    %rbp
 1023673:	ret
 1023674:	test   %rdi,%rdi
 1023677:	je     1023770 <flat_transfer+0x120>
 102367d:	cmp    %rcx,%rdx
 1023680:	je     1023770 <flat_transfer+0x120>
 1023686:	test   %rcx,%rcx
 1023689:	je     1023770 <flat_transfer+0x120>
 102368f:	test   %rdx,%rdx
 1023692:	je     1023770 <flat_transfer+0x120>
 1023698:	cmpq   $0x0,0x1608(%rdi)
 10236a0:	je     1023770 <flat_transfer+0x120>
 10236a6:	mov    0x50(%rsi),%rbx
 10236aa:	mov    %rdx,%rax
 10236ad:	sub    %rcx,%rax
 10236b0:	jbe    10236b9 <flat_transfer+0x69>
 10236b2:	cmp    %rbx,%rax
 10236b5:	jb     1023664 <flat_transfer+0x14>
 10236b7:	jmp    10236c4 <flat_transfer+0x74>
 10236b9:	mov    %rcx,%rax
 10236bc:	sub    %rdx,%rax
 10236bf:	cmp    %rbx,%rax
 10236c2:	jb     1023664 <flat_transfer+0x14>
 10236c4:	mov    $0x3,%eax
 10236c9:	cmp    0x70(%rdi),%r8d
 10236cd:	ja     1023669 <flat_transfer+0x19>
 10236cf:	cmpb   $0x0,0x46(%rsi)
 10236d3:	je     10236f6 <flat_transfer+0xa6>
 10236d5:	mov    0x48(%rsi),%eax
 10236d8:	mov    (%rcx,%rax,1),%eax
 10236db:	lea    0x5a(%rsi),%r10
 10236df:	cmp    $0x20,%rax
 10236e3:	lea    0x5c(%rsi,%rax,2),%rax
 10236e8:	cmovae %r10,%rax
 10236ec:	test   %r9,%r9
 10236ef:	jne    10236ff <flat_transfer+0xaf>
 10236f1:	jmp    1023775 <flat_transfer+0x125>
 10236f6:	lea    0x58(%rsi),%rax
 10236fa:	test   %r9,%r9
 10236fd:	je     1023775 <flat_transfer+0x125>
 10236ff:	movzwl (%rax),%eax
 1023702:	xor    %r10d,%r10d
 1023705:	jmp    1023728 <flat_transfer+0xd8>
 1023707:	shr    $0x28,%r14
 102370b:	and    $0xfffff,%r14d
 1023712:	cmp    %r8d,%r14d
 1023715:	ja     1023664 <flat_transfer+0x14>
 102371b:	nopl   0x0(%rax,%rax,1)
 1023720:	inc    %r10
 1023723:	cmp    %r10,%r9
 1023726:	je     1023775 <flat_transfer+0x125>
 1023728:	bt     %r10d,%eax
 102372c:	jae    1023720 <flat_transfer+0xd0>
 102372e:	movzwl 0x9c(%rsi,%r10,2),%r11d
 1023737:	mov    (%rcx,%r11,1),%r11
 102373b:	test   %r11,%r11
 102373e:	je     1023720 <flat_transfer+0xd0>
 1023740:	mov    -0x10(%r11),%r14
 1023744:	test   $0x2,%r14b
 1023748:	jne    1023720 <flat_transfer+0xd0>
 102374a:	bt     $0x3c,%r14
 102374f:	jb     1023664 <flat_transfer+0x14>
 1023755:	bt     $0x3e,%r14
 102375a:	jb     1023707 <flat_transfer+0xb7>
 102375c:	test   $0x1,%r14b
 1023760:	jne    1023770 <flat_transfer+0x120>
 1023762:	cmpq   $0x0,-0x20(%r11)
 1023767:	jne    1023720 <flat_transfer+0xd0>
 1023769:	cmpq   $0x0,-0x18(%r11)
 102376e:	jne    1023720 <flat_transfer+0xd0>
 1023770:	call   10187d4 <myl_rc_invariant_failed>
 1023775:	cmp    $0x61,%rbx
 1023779:	setb   %al
 102377c:	test   $0x7,%bl
 102377f:	sete   %sil
 1023783:	test   %sil,%al
 1023786:	je     10237ab <flat_transfer+0x15b>
 1023788:	shr    $0x3,%rbx
 102378c:	dec    %rbx
 102378f:	cmp    $0xb,%rbx
 1023793:	ja     1023945 <flat_transfer+0x2f5>
 1023799:	jmp    *0x1001ce8(,%rbx,8)
 10237a0:	mov    (%rcx),%rax
 10237a3:	mov    %rax,(%rdx)
 10237a6:	jmp    102393e <flat_transfer+0x2ee>
 10237ab:	mov    %rdi,%r15
 10237ae:	mov    %rdx,%rdi
 10237b1:	mov    %rcx,%rsi
 10237b4:	mov    %rbx,%rdx
 10237b7:	mov    %rcx,%r14
 10237ba:	call   1027520 <memcpy@plt>
 10237bf:	mov    %r14,%rdi
 10237c2:	xor    %esi,%esi
 10237c4:	mov    %rbx,%rdx
 10237c7:	call   10274d0 <memset@plt>
 10237cc:	mov    %r15,%rdi
 10237cf:	jmp    1023945 <flat_transfer+0x2f5>
 10237d4:	mov    0x58(%rcx),%rax
 10237d8:	mov    %rax,0x58(%rdx)
 10237dc:	mov    0x50(%rcx),%rax
 10237e0:	mov    %rax,0x50(%rdx)
 10237e4:	mov    0x48(%rcx),%rax
 10237e8:	mov    %rax,0x48(%rdx)
 10237ec:	mov    0x40(%rcx),%rax
 10237f0:	mov    %rax,0x40(%rdx)
 10237f4:	mov    0x38(%rcx),%rax
 10237f8:	mov    %rax,0x38(%rdx)
 10237fc:	mov    0x30(%rcx),%rax
 1023800:	mov    %rax,0x30(%rdx)
 1023804:	mov    0x28(%rcx),%rax
 1023808:	mov    %rax,0x28(%rdx)
 102380c:	mov    0x20(%rcx),%rax
 1023810:	mov    %rax,0x20(%rdx)
 1023814:	mov    0x18(%rcx),%rax
 1023818:	mov    %rax,0x18(%rdx)
 102381c:	mov    0x10(%rcx),%rax
 1023820:	mov    %rax,0x10(%rdx)
 1023824:	mov    0x8(%rcx),%rax
 1023828:	mov    %rax,0x8(%rdx)
 102382c:	mov    (%rcx),%rax
 102382f:	mov    %rax,(%rdx)
 1023832:	cmp    $0xb,%rbx
 1023836:	ja     1023945 <flat_transfer+0x2f5>
 102383c:	jmp    *0x1001d48(,%rbx,8)
 1023843:	movq   $0x0,0x58(%rcx)
 102384b:	movq   $0x0,0x50(%rcx)
 1023853:	movq   $0x0,0x48(%rcx)
 102385b:	movq   $0x0,0x40(%rcx)
 1023863:	movq   $0x0,0x38(%rcx)
 102386b:	movq   $0x0,0x30(%rcx)
 1023873:	jmp    1023916 <flat_transfer+0x2c6>
 1023878:	mov    0x20(%rcx),%rax
 102387c:	mov    %rax,0x20(%rdx)
 1023880:	mov    0x18(%rcx),%rax
 1023884:	mov    %rax,0x18(%rdx)
 1023888:	mov    0x10(%rcx),%rax
 102388c:	mov    %rax,0x10(%rdx)
 1023890:	mov    0x8(%rcx),%rax
 1023894:	mov    %rax,0x8(%rdx)
 1023898:	mov    (%rcx),%rax
 102389b:	mov    %rax,(%rdx)
 102389e:	jmp    102391e <flat_transfer+0x2ce>
 10238a0:	mov    0x10(%rcx),%rax
 10238a4:	mov    %rax,0x10(%rdx)
 10238a8:	mov    0x8(%rcx),%rax
 10238ac:	mov    %rax,0x8(%rdx)
 10238b0:	mov    (%rcx),%rax
 10238b3:	mov    %rax,(%rdx)
 10238b6:	jmp    102392e <flat_transfer+0x2de>
 10238b8:	mov    0x18(%rcx),%rax
 10238bc:	mov    %rax,0x18(%rdx)
 10238c0:	mov    0x10(%rcx),%rax
 10238c4:	mov    %rax,0x10(%rdx)
 10238c8:	mov    0x8(%rcx),%rax
 10238cc:	mov    %rax,0x8(%rdx)
 10238d0:	mov    (%rcx),%rax
 10238d3:	mov    %rax,(%rdx)
 10238d6:	jmp    1023926 <flat_transfer+0x2d6>
 10238d8:	mov    0x8(%rcx),%rax
 10238dc:	mov    %rax,0x8(%rdx)
 10238e0:	mov    (%rcx),%rax
 10238e3:	mov    %rax,(%rdx)
 10238e6:	jmp    1023936 <flat_transfer+0x2e6>
 10238e8:	mov    0x28(%rcx),%rax
 10238ec:	mov    %rax,0x28(%rdx)
 10238f0:	mov    0x20(%rcx),%rax
 10238f4:	mov    %rax,0x20(%rdx)
 10238f8:	mov    0x18(%rcx),%rax
 10238fc:	mov    %rax,0x18(%rdx)
 1023900:	mov    0x10(%rcx),%rax
 1023904:	mov    %rax,0x10(%rdx)
 1023908:	mov    0x8(%rcx),%rax
 102390c:	mov    %rax,0x8(%rdx)
 1023910:	mov    (%rcx),%rax
 1023913:	mov    %rax,(%rdx)
 1023916:	movq   $0x0,0x28(%rcx)
 102391e:	movq   $0x0,0x20(%rcx)
 1023926:	movq   $0x0,0x18(%rcx)
 102392e:	movq   $0x0,0x10(%rcx)
 1023936:	movq   $0x0,0x8(%rcx)
 102393e:	movq   $0x0,(%rcx)
 1023945:	mov    0x1608(%rdi),%rcx
 102394c:	xor    %eax,%eax
 102394e:	cmpq   $0x0,0xc8(%rcx)
 1023956:	je     1023669 <flat_transfer+0x19>
 102395c:	call   101bcb0 <myl_rc_drain>
 1023961:	xor    %eax,%eax
 1023963:	jmp    1023669 <flat_transfer+0x19>
 1023968:	int3
 1023969:	int3
 102396a:	int3
 102396b:	int3
 102396c:	int3
 102396d:	int3
 102396e:	int3
 102396f:	int3

0000000001023970 <myl_rc_native_retain>:
 1023970:	push   %rbp
 1023971:	mov    %rsp,%rbp
 1023974:	push   %r15
 1023976:	push   %r14
 1023978:	push   %r13
 102397a:	push   %r12
 102397c:	push   %rbx
 102397d:	sub    $0x228,%rsp
 1023984:	mov    %r8d,-0x2c(%rbp)
 1023988:	mov    %rcx,%r9
 102398b:	mov    %rdx,%r14
 102398e:	mov    %rsi,%r15
 1023991:	mov    %rdi,%rbx
 1023994:	mov    0x1608(%rdi),%rdi
 102399b:	mov    0x34(%rsi),%eax
 102399e:	cmp    %rax,0xa0(%rdi)
 10239a5:	jbe    1023e2a <myl_rc_native_retain+0x4ba>
 10239ab:	mov    0x98(%rdi),%rcx
 10239b2:	shl    $0x4,%rax
 10239b6:	cmp    %r15,(%rcx,%rax,1)
 10239ba:	jne    1023e2a <myl_rc_native_retain+0x4ba>
 10239c0:	add    %rax,%rcx
 10239c3:	mov    0x8(%rcx),%r12
 10239c7:	test   %r12,%r12
 10239ca:	je     1023e3e <myl_rc_native_retain+0x4ce>
 10239d0:	cmpl   $0x0,0x40(%r12)
 10239d6:	jne    10239ed <myl_rc_native_retain+0x7d>
 10239d8:	mov    0x1608(%rbx),%rax
 10239df:	cmpq   $0x0,0xc8(%rax)
 10239e7:	je     1023afe <myl_rc_native_retain+0x18e>
 10239ed:	mov    0x50(%r12),%r13
 10239f2:	cmpb   $0x0,0x44(%r12)
 10239f8:	setne  %al
 10239fb:	test   %r13,%r13
 10239fe:	setne  %cl
 1023a01:	and    %al,%cl
 1023a03:	cmp    $0x1,%cl
 1023a06:	jne    1023a4b <myl_rc_native_retain+0xdb>
 1023a08:	mov    0x1608(%rbx),%rax
 1023a0f:	test   %rax,%rax
 1023a12:	je     102414c <myl_rc_native_retain+0x7dc>
 1023a18:	test   %r9,%r9
 1023a1b:	je     102414c <myl_rc_native_retain+0x7dc>
 1023a21:	test   %r14,%r14
 1023a24:	je     102414c <myl_rc_native_retain+0x7dc>
 1023a2a:	cmpq   $0x0,0xc0(%rax)
 1023a32:	jne    102414c <myl_rc_native_retain+0x7dc>
 1023a38:	mov    %r14,%rax
 1023a3b:	sub    %r9,%rax
 1023a3e:	ja     1023a46 <myl_rc_native_retain+0xd6>
 1023a40:	mov    %r9,%rax
 1023a43:	sub    %r14,%rax
 1023a46:	cmp    %r13,%rax
 1023a49:	jae    1023a9b <myl_rc_native_retain+0x12b>
 1023a4b:	mov    0x8(%r12),%r13
 1023a50:	test   %r13,%r13
 1023a53:	je     1024028 <myl_rc_native_retain+0x6b8>
 1023a59:	mov    0x1608(%rbx),%rax
 1023a60:	test   %rax,%rax
 1023a63:	je     102414c <myl_rc_native_retain+0x7dc>
 1023a69:	cmpq   $0x0,0xc0(%rax)
 1023a71:	jne    102414c <myl_rc_native_retain+0x7dc>
 1023a77:	mov    %r9,-0x38(%rbp)
 1023a7b:	movzbl 0x45(%r12),%eax
 1023a81:	test   %eax,%eax
 1023a83:	je     1023ad4 <myl_rc_native_retain+0x164>
 1023a85:	cmp    $0x3,%al
 1023a87:	jae    102414c <myl_rc_native_retain+0x7dc>
 1023a8d:	cmp    $0x2,%eax
 1023a90:	jne    1023e6c <myl_rc_native_retain+0x4fc>
 1023a96:	jmp    102414c <myl_rc_native_retain+0x7dc>
 1023a9b:	mov    -0x2c(%rbp),%eax
 1023a9e:	cmp    0x70(%rbx),%eax
 1023aa1:	jbe    1023b5b <myl_rc_native_retain+0x1eb>
 1023aa7:	mov    %r14,%rdi
 1023aaa:	xor    %esi,%esi
 1023aac:	mov    %r13,%rdx
 1023aaf:	call   10274d0 <memset@plt>
 1023ab4:	mov    0x1608(%rbx),%rcx
 1023abb:	mov    $0x3,%r14d
 1023ac1:	cmpq   $0x0,0xc8(%rcx)
 1023ac9:	jne    1023d2d <myl_rc_native_retain+0x3bd>
 1023acf:	jmp    1023d4a <myl_rc_native_retain+0x3da>
 1023ad4:	mov    (%r12),%rsi
 1023ad8:	mov    %rbx,%rdi
 1023adb:	call   101c6c0 <myl_rc_native_has_unique>
 1023ae0:	cmp    $0x1,%eax
 1023ae3:	mov    $0x2,%eax
 1023ae8:	sbb    $0x0,%eax
 1023aeb:	mov    %al,0x45(%r12)
 1023af0:	cmp    $0x2,%eax
 1023af3:	jne    1023e6c <myl_rc_native_retain+0x4fc>
 1023af9:	jmp    102414c <myl_rc_native_retain+0x7dc>
 1023afe:	mov    (%r15),%rdx
 1023b01:	test   %rdx,%rdx
 1023b04:	je     10239ed <myl_rc_native_retain+0x7d>
 1023b0a:	mov    %r14,%rax
 1023b0d:	sub    %r9,%rax
 1023b10:	ja     1023b18 <myl_rc_native_retain+0x1a8>
 1023b12:	mov    %r9,%rax
 1023b15:	sub    %r14,%rax
 1023b18:	cmp    %rdx,%rax
 1023b1b:	jb     10239ed <myl_rc_native_retain+0x7d>
 1023b21:	mov    -0x2c(%rbp),%eax
 1023b24:	cmp    0x70(%rbx),%eax
 1023b27:	jbe    1023d6f <myl_rc_native_retain+0x3ff>
 1023b2d:	mov    %r14,%rdi
 1023b30:	xor    %esi,%esi
 1023b32:	call   10274d0 <memset@plt>
 1023b37:	mov    0x1608(%rbx),%rax
 1023b3e:	test   %rax,%rax
 1023b41:	je     102414c <myl_rc_native_retain+0x7dc>
 1023b47:	cmpl   $0x0,0x124(%rax)
 1023b4e:	je     1023e19 <myl_rc_native_retain+0x4a9>
 1023b54:	xor    %eax,%eax
 1023b56:	jmp    102411c <myl_rc_native_retain+0x7ac>
 1023b5b:	cmp    $0x61,%r13
 1023b5f:	setae  %al
 1023b62:	test   $0x7,%r13b
 1023b66:	setne  %cl
 1023b69:	or     %al,%cl
 1023b6b:	jne    1023c1b <myl_rc_native_retain+0x2ab>
 1023b71:	mov    %r13,%rax
 1023b74:	shr    $0x3,%rax
 1023b78:	dec    %rax
 1023b7b:	cmp    $0xb,%rax
 1023b7f:	ja     1023be6 <myl_rc_native_retain+0x276>
 1023b81:	jmp    *0x1001e08(,%rax,8)
 1023b88:	mov    0x58(%r9),%rax
 1023b8c:	mov    %rax,0x58(%r14)
 1023b90:	mov    0x50(%r9),%rax
 1023b94:	mov    %rax,0x50(%r14)
 1023b98:	mov    0x48(%r9),%rax
 1023b9c:	mov    %rax,0x48(%r14)
 1023ba0:	mov    0x40(%r9),%rax
 1023ba4:	mov    %rax,0x40(%r14)
 1023ba8:	mov    0x38(%r9),%rax
 1023bac:	mov    %rax,0x38(%r14)
 1023bb0:	mov    0x30(%r9),%rax
 1023bb4:	mov    %rax,0x30(%r14)
 1023bb8:	mov    0x28(%r9),%rax
 1023bbc:	mov    %rax,0x28(%r14)
 1023bc0:	mov    0x20(%r9),%rax
 1023bc4:	mov    %rax,0x20(%r14)
 1023bc8:	mov    0x18(%r9),%rax
 1023bcc:	mov    %rax,0x18(%r14)
 1023bd0:	mov    0x10(%r9),%rax
 1023bd4:	mov    %rax,0x10(%r14)
 1023bd8:	mov    0x8(%r9),%rax
 1023bdc:	mov    %rax,0x8(%r14)
 1023be0:	mov    (%r9),%rax
 1023be3:	mov    %rax,(%r14)
 1023be6:	cmpb   $0x0,0x46(%r12)
 1023bec:	je     1023c37 <myl_rc_native_retain+0x2c7>
 1023bee:	mov    %r14,%r15
 1023bf1:	mov    0x48(%r12),%eax
 1023bf6:	mov    (%r9,%rax,1),%eax
 1023bfa:	lea    0x5a(%r12),%rcx
 1023bff:	cmp    $0x20,%rax
 1023c03:	lea    0x5c(%r12,%rax,2),%rax
 1023c08:	cmovae %rcx,%rax
 1023c0c:	movzwl (%rax),%eax
 1023c0f:	xor    %r14d,%r14d
 1023c12:	test   %eax,%eax
 1023c14:	jne    1023c4d <myl_rc_native_retain+0x2dd>
 1023c16:	jmp    1023d1c <myl_rc_native_retain+0x3ac>
 1023c1b:	mov    %r14,%rdi
 1023c1e:	mov    %r9,%rsi
 1023c21:	mov    %r13,%rdx
 1023c24:	mov    %r9,%r15
 1023c27:	call   1027520 <memcpy@plt>
 1023c2c:	mov    %r15,%r9
 1023c2f:	cmpb   $0x0,0x46(%r12)
 1023c35:	jne    1023bee <myl_rc_native_retain+0x27e>
 1023c37:	mov    %r14,%r15
 1023c3a:	lea    0x58(%r12),%rax
 1023c3f:	movzwl (%rax),%eax
 1023c42:	xor    %r14d,%r14d
 1023c45:	test   %eax,%eax
 1023c47:	je     1023d1c <myl_rc_native_retain+0x3ac>
 1023c4d:	movabs $0x4000000000000000,%rcx
 1023c57:	lea    0x2(%rcx),%rdx
 1023c5b:	jmp    1023c7a <myl_rc_native_retain+0x30a>
 1023c5d:	cmpq   $0x0,-0x18(%rsi)
 1023c62:	je     102414c <myl_rc_native_retain+0x7dc>
 1023c68:	inc    %rdi
 1023c6b:	mov    %rdi,-0x20(%rsi)
 1023c6f:	blsr   %eax,%eax
 1023c74:	je     1023d1c <myl_rc_native_retain+0x3ac>
 1023c7a:	tzcnt  %eax,%esi
 1023c7e:	movzwl 0x9c(%r12,%rsi,2),%esi
 1023c87:	mov    (%r9,%rsi,1),%rsi
 1023c8b:	test   %rsi,%rsi
 1023c8e:	je     1023c6f <myl_rc_native_retain+0x2ff>
 1023c90:	mov    -0x10(%rsi),%rdi
 1023c94:	test   %rcx,%rdi
 1023c97:	je     1023cad <myl_rc_native_retain+0x33d>
 1023c99:	mov    %rdi,%r8
 1023c9c:	shr    $0x28,%r8
 1023ca0:	and    $0xfffff,%r8d
 1023ca7:	cmp    -0x2c(%rbp),%r8d
 1023cab:	ja     1023cd3 <myl_rc_native_retain+0x363>
 1023cad:	test   %rdx,%rdi
 1023cb0:	jne    1023c6f <myl_rc_native_retain+0x2ff>
 1023cb2:	test   $0x1,%dil
 1023cb6:	jne    102414c <myl_rc_native_retain+0x7dc>
 1023cbc:	mov    -0x20(%rsi),%rdi
 1023cc0:	test   %rdi,%rdi
 1023cc3:	je     1023c5d <myl_rc_native_retain+0x2ed>
 1023cc5:	cmp    $0xffffffffffffffff,%rdi
 1023cc9:	jne    1023c68 <myl_rc_native_retain+0x2f8>
 1023ccb:	mov    $0x2,%r14d
 1023cd1:	jmp    1023ce0 <myl_rc_native_retain+0x370>
 1023cd3:	mov    $0x3,%r14d
 1023cd9:	nopl   0x0(%rax)
 1023ce0:	tzcnt  %eax,%ecx
 1023ce4:	movzwl 0x9c(%r12,%rcx,2),%ecx
 1023ced:	movq   $0x0,(%r15,%rcx,1)
 1023cf5:	blsr   %eax,%eax
 1023cfa:	jne    1023ce0 <myl_rc_native_retain+0x370>
 1023cfc:	mov    $0x1,%ecx
 1023d01:	mov    %rbx,%rdi
 1023d04:	mov    %r12,%rsi
 1023d07:	mov    %r15,%rdx
 1023d0a:	call   101ba70 <myl_rc_flat_edges_release>
 1023d0f:	mov    %r15,%rdi
 1023d12:	xor    %esi,%esi
 1023d14:	mov    %r13,%rdx
 1023d17:	call   10274d0 <memset@plt>
 1023d1c:	mov    0x1608(%rbx),%rax
 1023d23:	cmpq   $0x0,0xc8(%rax)
 1023d2b:	je     1023d35 <myl_rc_native_retain+0x3c5>
 1023d2d:	mov    %rbx,%rdi
 1023d30:	call   101bcb0 <myl_rc_drain>
 1023d35:	test   %r14d,%r14d
 1023d38:	je     1023d65 <myl_rc_native_retain+0x3f5>
 1023d3a:	mov    0x1608(%rbx),%rcx
 1023d41:	test   %rcx,%rcx
 1023d44:	je     102414c <myl_rc_native_retain+0x7dc>
 1023d4a:	xor    %eax,%eax
 1023d4c:	cmpl   $0x0,0x124(%rcx)
 1023d53:	jne    102411c <myl_rc_native_retain+0x7ac>
 1023d59:	mov    %r14d,0x124(%rcx)
 1023d60:	jmp    102411c <myl_rc_native_retain+0x7ac>
 1023d65:	mov    $0x1,%eax
 1023d6a:	jmp    102411c <myl_rc_native_retain+0x7ac>
 1023d6f:	cmp    $0x61,%rdx
 1023d73:	setae  %al
 1023d76:	test   $0x7,%dl
 1023d79:	setne  %cl
 1023d7c:	or     %al,%cl
 1023d7e:	jne    1023e04 <myl_rc_native_retain+0x494>
 1023d84:	shr    $0x3,%rdx
 1023d88:	mov    $0x1,%eax
 1023d8d:	dec    %rdx
 1023d90:	cmp    $0xb,%rdx
 1023d94:	ja     102411c <myl_rc_native_retain+0x7ac>
 1023d9a:	jmp    *0x1001da8(,%rdx,8)
 1023da1:	mov    0x58(%r9),%rcx
 1023da5:	mov    %rcx,0x58(%r14)
 1023da9:	mov    0x50(%r9),%rcx
 1023dad:	mov    %rcx,0x50(%r14)
 1023db1:	mov    0x48(%r9),%rcx
 1023db5:	mov    %rcx,0x48(%r14)
 1023db9:	mov    0x40(%r9),%rcx
 1023dbd:	mov    %rcx,0x40(%r14)
 1023dc1:	mov    0x38(%r9),%rcx
 1023dc5:	mov    %rcx,0x38(%r14)
 1023dc9:	mov    0x30(%r9),%rcx
 1023dcd:	mov    %rcx,0x30(%r14)
 1023dd1:	mov    0x28(%r9),%rcx
 1023dd5:	mov    %rcx,0x28(%r14)
 1023dd9:	mov    0x20(%r9),%rcx
 1023ddd:	mov    %rcx,0x20(%r14)
 1023de1:	mov    0x18(%r9),%rcx
 1023de5:	mov    %rcx,0x18(%r14)
 1023de9:	mov    0x10(%r9),%rcx
 1023ded:	mov    %rcx,0x10(%r14)
 1023df1:	mov    0x8(%r9),%rcx
 1023df5:	mov    %rcx,0x8(%r14)
 1023df9:	mov    (%r9),%rcx
 1023dfc:	mov    %rcx,(%r14)
 1023dff:	jmp    102411c <myl_rc_native_retain+0x7ac>
 1023e04:	mov    %r14,%rdi
 1023e07:	mov    %r9,%rsi
 1023e0a:	call   1027520 <memcpy@plt>
 1023e0f:	mov    $0x1,%eax
 1023e14:	jmp    102411c <myl_rc_native_retain+0x7ac>
 1023e19:	movl   $0x3,0x124(%rax)
 1023e23:	xor    %eax,%eax
 1023e25:	jmp    102411c <myl_rc_native_retain+0x7ac>
 1023e2a:	mov    %r15,%rsi
 1023e2d:	call   1018df4 <myl_rc_binding_find_slow>
 1023e32:	mov    %rax,%r12
 1023e35:	test   %r12,%r12
 1023e38:	jne    10239d0 <myl_rc_native_retain+0x60>
 1023e3e:	mov    %rbx,%rdi
 1023e41:	mov    %r15,%rsi
 1023e44:	mov    %r9,-0x38(%rbp)
 1023e48:	call   1023330 <myl_rc_native_shape>
 1023e4d:	test   %rax,%rax
 1023e50:	je     1024028 <myl_rc_native_retain+0x6b8>
 1023e56:	mov    %rax,%r13
 1023e59:	mov    %rbx,%rdi
 1023e5c:	mov    %r15,%rsi
 1023e5f:	call   101c6c0 <myl_rc_native_has_unique>
 1023e64:	test   %eax,%eax
 1023e66:	jne    102414c <myl_rc_native_retain+0x7dc>
 1023e6c:	mov    (%r15),%rdx
 1023e6f:	mov    %r14,-0x48(%rbp)
 1023e73:	mov    %r14,%rdi
 1023e76:	xor    %esi,%esi
 1023e78:	call   10274d0 <memset@plt>
 1023e7d:	mov    0x1608(%rbx),%r14
 1023e84:	test   %r14,%r14
 1023e87:	je     102414c <myl_rc_native_retain+0x7dc>
 1023e8d:	vxorps %xmm0,%xmm0,%xmm0
 1023e91:	vmovups %ymm0,-0xb0(%rbp)
 1023e99:	vmovups %ymm0,-0xd0(%rbp)
 1023ea1:	vmovups %ymm0,-0xf0(%rbp)
 1023ea9:	vmovups %ymm0,-0x110(%rbp)
 1023eb1:	vmovups %ymm0,-0x130(%rbp)
 1023eb9:	vmovups %ymm0,-0x150(%rbp)
 1023ec1:	movq   $0x0,-0x90(%rbp)
 1023ecc:	mov    %rbx,-0x80(%rbp)
 1023ed0:	lea    -0x250(%rbp),%rax
 1023ed7:	mov    %rax,-0x78(%rbp)
 1023edb:	movq   $0x8,-0x70(%rbp)
 1023ee3:	vxorps %xmm0,%xmm0,%xmm0
 1023ee7:	vmovups %xmm0,-0x68(%rbp)
 1023eec:	lea    -0x150(%rbp),%rax
 1023ef3:	mov    %rax,-0x58(%rbp)
 1023ef7:	mov    0x58(%r14),%rax
 1023efb:	mov    0x60(%r14),%rdx
 1023eff:	movzbl 0x70(%r14),%ecx
 1023f04:	movabs $0x9e3779b97f4a7c15,%rsi
 1023f0e:	imul   %r13,%rsi
 1023f12:	shrx   %rcx,%rsi,%r9
 1023f17:	and    %rdx,%r9
 1023f1a:	mov    %r9,%rsi
 1023f1d:	shl    $0x4,%rsi
 1023f21:	mov    (%rax,%rsi,1),%rsi
 1023f25:	mov    %r9,%rdi
 1023f28:	cmp    %r13,%rsi
 1023f2b:	mov    -0x38(%rbp),%rcx
 1023f2f:	je     1023f5b <myl_rc_native_retain+0x5eb>
 1023f31:	xor    %r15d,%r15d
 1023f34:	mov    %rsi,%r8
 1023f37:	mov    %r9,%rdi
 1023f3a:	nopw   0x0(%rax,%rax,1)
 1023f40:	test   %r8,%r8
 1023f43:	je     1023f8a <myl_rc_native_retain+0x61a>
 1023f45:	inc    %rdi
 1023f48:	and    %rdx,%rdi
 1023f4b:	mov    %rdi,%r8
 1023f4e:	shl    $0x4,%r8
 1023f52:	mov    (%rax,%r8,1),%r8
 1023f56:	cmp    %r13,%r8
 1023f59:	jne    1023f40 <myl_rc_native_retain+0x5d0>
 1023f5b:	shl    $0x4,%rdi
 1023f5f:	mov    0x8(%rax,%rdi,1),%r15
 1023f64:	jmp    1023f8a <myl_rc_native_retain+0x61a>
 1023f66:	cs nopw 0x0(%rax,%rax,1)
 1023f70:	test   %rsi,%rsi
 1023f73:	je     102414c <myl_rc_native_retain+0x7dc>
 1023f79:	inc    %r9
 1023f7c:	and    %rdx,%r9
 1023f7f:	mov    %r9,%rsi
 1023f82:	shl    $0x4,%rsi
 1023f86:	mov    (%rax,%rsi,1),%rsi
 1023f8a:	cmp    %r13,%rsi
 1023f8d:	jne    1023f70 <myl_rc_native_retain+0x600>
 1023f8f:	test   %r15,%r15
 1023f92:	je     102414c <myl_rc_native_retain+0x7dc>
 1023f98:	shl    $0x4,%r9
 1023f9c:	mov    0x8(%rax,%r9,1),%rax
 1023fa1:	test   %rax,%rax
 1023fa4:	je     102414c <myl_rc_native_retain+0x7dc>
 1023faa:	mov    (%r15),%rdx
 1023fad:	cmp    (%rax),%rdx
 1023fb0:	jne    102414c <myl_rc_native_retain+0x7dc>
 1023fb6:	cmp    -0x48(%rbp),%rcx
 1023fba:	je     102414c <myl_rc_native_retain+0x7dc>
 1023fc0:	mov    $0x3,%r12d
 1023fc6:	mov    -0x2c(%rbp),%eax
 1023fc9:	cmp    0x70(%rbx),%eax
 1023fcc:	ja     10240ed <myl_rc_native_retain+0x77d>
 1023fd2:	mov    0x28(%r15),%r12
 1023fd6:	cmp    $0x9,%r12
 1023fda:	jb     102407c <myl_rc_native_retain+0x70c>
 1023fe0:	mov    %rbx,-0x40(%rbp)
 1023fe4:	mov    %r12,%rax
 1023fe7:	shr    $0x3b,%rax
 1023feb:	jne    102414c <myl_rc_native_retain+0x7dc>
 1023ff1:	mov    %r12,%rbx
 1023ff4:	shl    $0x5,%rbx
 1023ff8:	mov    -0x40(%rbp),%rdx
 1023ffc:	mov    0x18(%rdx),%rsi
 1024000:	add    %rbx,%rsi
 1024003:	jb     1024013 <myl_rc_native_retain+0x6a3>
 1024005:	mov    0x58(%rdx),%rax
 1024009:	test   %rax,%rax
 102400c:	je     102403c <myl_rc_native_retain+0x6cc>
 102400e:	cmp    %rax,%rsi
 1024011:	jbe    102403c <myl_rc_native_retain+0x6cc>
 1024013:	movl   $0x1,0x6c(%rdx)
 102401a:	mov    $0x1,%r12d
 1024020:	mov    %rdx,%rbx
 1024023:	jmp    10240ed <myl_rc_native_retain+0x77d>
 1024028:	mov    (%r15),%rdx
 102402b:	mov    %r14,%rdi
 102402e:	xor    %esi,%esi
 1024030:	call   10274d0 <memset@plt>
 1024035:	xor    %eax,%eax
 1024037:	jmp    102411c <myl_rc_native_retain+0x7ac>
 102403c:	mov    %rsi,-0x50(%rbp)
 1024040:	mov    %rcx,-0x38(%rbp)
 1024044:	mov    $0x1,%edi
 1024049:	mov    %rbx,%rsi
 102404c:	vzeroupper
 102404f:	call   1027510 <calloc@plt>
 1024054:	test   %rax,%rax
 1024057:	je     1024140 <myl_rc_native_retain+0x7d0>
 102405d:	mov    -0x40(%rbp),%rcx
 1024061:	mov    -0x50(%rbp),%rdx
 1024065:	mov    %rdx,0x18(%rcx)
 1024069:	add    %rbx,0x30(%r14)
 102406d:	mov    %rcx,%rbx
 1024070:	mov    %rax,-0x78(%rbp)
 1024074:	mov    %r12,-0x70(%rbp)
 1024078:	mov    -0x38(%rbp),%rcx
 102407c:	mov    $0x1,%r8d
 1024082:	mov    %rbx,%rdi
 1024085:	mov    %r15,%rsi
 1024088:	mov    -0x48(%rbp),%r14
 102408c:	mov    %r14,%rdx
 102408f:	mov    %rcx,%r12
 1024092:	vzeroupper
 1024095:	call   101c8c0 <myl_rc_value_seed>
 102409a:	mov    -0x2c(%rbp),%eax
 102409d:	mov    %eax,-0x60(%rbp)
 10240a0:	lea    -0x80(%rbp),%rdi
 10240a4:	mov    $0x1020b20,%r8d
 10240aa:	mov    %r15,%rsi
 10240ad:	mov    %r14,%rdx
 10240b0:	mov    %r12,%rcx
 10240b3:	call   101ed90 <visit>
 10240b8:	test   %eax,%eax
 10240ba:	jne    10240c9 <myl_rc_native_retain+0x759>
 10240bc:	lea    -0x80(%rbp),%rdi
 10240c0:	call   101ffd0 <finish_clones>
 10240c5:	test   %eax,%eax
 10240c7:	je     102412e <myl_rc_native_retain+0x7be>
 10240c9:	mov    %eax,%r12d
 10240cc:	mov    $0x1,%ecx
 10240d1:	mov    %rbx,%rdi
 10240d4:	mov    %r13,%rsi
 10240d7:	mov    %r14,%rdx
 10240da:	call   101b300 <myl_rc_edges_release>
 10240df:	mov    0x0(%r13),%rdx
 10240e3:	mov    %r14,%rdi
 10240e6:	xor    %esi,%esi
 10240e8:	call   10274d0 <memset@plt>
 10240ed:	lea    -0x80(%rbp),%rdi
 10240f1:	mov    $0x1,%esi
 10240f6:	vzeroupper
 10240f9:	call   1020760 <dispose_walk>
 10240fe:	mov    0x1608(%rbx),%rcx
 1024105:	test   %rcx,%rcx
 1024108:	je     102414c <myl_rc_native_retain+0x7dc>
 102410a:	xor    %eax,%eax
 102410c:	cmpl   $0x0,0x124(%rcx)
 1024113:	jne    102411c <myl_rc_native_retain+0x7ac>
 1024115:	mov    %r12d,0x124(%rcx)
 102411c:	add    $0x228,%rsp
 1024123:	pop    %rbx
 1024124:	pop    %r12
 1024126:	pop    %r13
 1024128:	pop    %r14
 102412a:	pop    %r15
 102412c:	pop    %rbp
 102412d:	ret
 102412e:	lea    -0x80(%rbp),%rdi
 1024132:	xor    %esi,%esi
 1024134:	call   1020760 <dispose_walk>
 1024139:	mov    $0x1,%eax
 102413e:	jmp    102411c <myl_rc_native_retain+0x7ac>
 1024140:	mov    $0x1,%r12d
 1024146:	mov    -0x40(%rbp),%rbx
 102414a:	jmp    10240ed <myl_rc_native_retain+0x77d>
 102414c:	vzeroupper
 102414f:	call   10187d4 <myl_rc_invariant_failed>
 1024154:	int3
 1024155:	int3
 1024156:	int3
 1024157:	int3
 1024158:	int3
 1024159:	int3
 102415a:	int3
 102415b:	int3
 102415c:	int3
 102415d:	int3
 102415e:	int3
 102415f:	int3

0000000001024160 <_Unwind_GetIP>:
 1024160:	push   %rbp
 1024161:	mov    %rsp,%rbp
 1024164:	sub    $0x10,%rsp
 1024168:	lea    -0x8(%rbp),%rdx
 102416c:	mov    $0xffffffff,%esi
 1024171:	call   1024210 <__unw_get_reg>
 1024176:	mov    -0x8(%rbp),%rax
 102417a:	add    $0x10,%rsp
 102417e:	pop    %rbp
 102417f:	ret

0000000001024180 <__unw_init_local>:
 1024180:	push   %rbp
 1024181:	mov    %rsp,%rbp
 1024184:	lea    0x47f5(%rip),%rax        # 1028980 <_ZTVN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EEE+0x10>
 102418b:	mov    %rax,(%rdi)
 102418e:	lea    0x7643(%rip),%rax        # 102b7d8 <_ZN9libunwind17LocalAddressSpace17sThisAddressSpaceE>
 1024195:	mov    %rax,0x8(%rdi)
 1024199:	vmovups (%rsi),%ymm0
 102419d:	vmovups 0x20(%rsi),%ymm1
 10241a2:	vmovups 0x40(%rsi),%ymm2
 10241a7:	vmovups 0x60(%rsi),%ymm3
 10241ac:	vmovups %ymm0,0x10(%rdi)
 10241b1:	vmovups %ymm1,0x30(%rdi)
 10241b6:	vmovups %ymm2,0x50(%rdi)
 10241bb:	vmovups %ymm3,0x70(%rdi)
 10241c0:	vmovups 0x80(%rsi),%ymm0
 10241c8:	vmovups %ymm0,0x90(%rdi)
 10241d0:	mov    0xa0(%rsi),%rax
 10241d7:	mov    %rax,0xb0(%rdi)
 10241de:	vxorps %xmm0,%xmm0,%xmm0
 10241e2:	vmovups %ymm0,0xb8(%rdi)
 10241ea:	vmovups %ymm0,0xd8(%rdi)
 10241f2:	vmovups %ymm0,0xe2(%rdi)
 10241fa:	xor    %esi,%esi
 10241fc:	vzeroupper
 10241ff:	call   10249e0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb>
 1024204:	xor    %eax,%eax
 1024206:	pop    %rbp
 1024207:	ret
 1024208:	int3
 1024209:	int3
 102420a:	int3
 102420b:	int3
 102420c:	int3
 102420d:	int3
 102420e:	int3
 102420f:	int3

0000000001024210 <__unw_get_reg>:
 1024210:	push   %rbp
 1024211:	mov    %rsp,%rbp
 1024214:	push   %r15
 1024216:	push   %r14
 1024218:	push   %rbx
 1024219:	push   %rax
 102421a:	mov    %rdx,%rbx
 102421d:	mov    %esi,%r14d
 1024220:	mov    %rdi,%r15
 1024223:	mov    (%rdi),%rax
 1024226:	call   *0x10(%rax)
 1024229:	mov    %eax,%ecx
 102422b:	mov    $0xffffe672,%eax
 1024230:	test   %cl,%cl
 1024232:	je     1024245 <__unw_get_reg+0x35>
 1024234:	mov    (%r15),%rax
 1024237:	mov    %r15,%rdi
 102423a:	mov    %r14d,%esi
 102423d:	call   *0x18(%rax)
 1024240:	mov    %rax,(%rbx)
 1024243:	xor    %eax,%eax
 1024245:	add    $0x8,%rsp
 1024249:	pop    %rbx
 102424a:	pop    %r14
 102424c:	pop    %r15
 102424e:	pop    %rbp
 102424f:	ret

0000000001024250 <__unw_step>:
 1024250:	push   %rbp
 1024251:	mov    %rsp,%rbp
 1024254:	mov    (%rdi),%rax
 1024257:	mov    0x40(%rax),%rax
 102425b:	xor    %esi,%esi
 102425d:	pop    %rbp
 102425e:	jmp    *%rax

0000000001024260 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb>:
 1024260:	push   %rbp
 1024261:	mov    %rsp,%rbp
 1024264:	push   %r15
 1024266:	push   %r14
 1024268:	push   %r13
 102426a:	push   %r12
 102426c:	push   %rbx
 102426d:	sub    $0x28,%rsp
 1024271:	mov    %rcx,%r15
 1024274:	mov    %rdi,%r14
 1024277:	mov    (%rsi),%ebx
 1024279:	mov    $0xffffffff,%eax
 102427e:	cmp    %rax,%rbx
 1024281:	je     10242b9 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x59>
 1024283:	lea    0x4(%rsi),%r12
 1024287:	test   %rbx,%rbx
 102428a:	je     10242c6 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x66>
 102428c:	mov    (%r12),%eax
 1024290:	test   %rax,%rax
 1024293:	je     10242d2 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x72>
 1024295:	mov    %rsi,-0x50(%rbp)
 1024299:	mov    %rdx,-0x38(%rbp)
 102429d:	mov    %r12,%rsi
 10242a0:	sub    %rax,%rsi
 10242a3:	test   %r8b,%r8b
 10242a6:	je     10242de <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x7e>
 10242a8:	cmp    %rsi,(%r15)
 10242ab:	je     10242f2 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x92>
 10242ad:	lea    -0x2036c(%rip),%rax        # 1003f48 <qbe_empty_registry+0x3f0>
 10242b4:	jmp    10243eb <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x18b>
 10242b9:	mov    0x4(%rsi),%rbx
 10242bd:	lea    0xc(%rsi),%r12
 10242c1:	test   %rbx,%rbx
 10242c4:	jne    102428c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x2c>
 10242c6:	lea    -0x20399(%rip),%rax        # 1003f34 <qbe_empty_registry+0x3dc>
 10242cd:	jmp    10243eb <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x18b>
 10242d2:	lea    -0x1fe58(%rip),%rax        # 1004481 <qbe_empty_registry+0x929>
 10242d9:	jmp    10243eb <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x18b>
 10242de:	mov    %r14,%rdi
 10242e1:	mov    %r15,%rdx
 10242e4:	call   1024400 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE>
 10242e9:	test   %rax,%rax
 10242ec:	jne    10243eb <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x18b>
 10242f2:	add    %r12,%rbx
 10242f5:	add    $0x4,%r12
 10242f9:	mov    %r12,-0x30(%rbp)
 10242fd:	movzbl 0x18(%r15),%ecx
 1024302:	lea    -0x30(%rbp),%r12
 1024306:	mov    %r14,%rdi
 1024309:	mov    %r12,%rsi
 102430c:	mov    %rbx,%rdx
 102430f:	xor    %r8d,%r8d
 1024312:	xor    %r9d,%r9d
 1024315:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 102431a:	mov    %rax,-0x48(%rbp)
 102431e:	movzbl 0x18(%r15),%ecx
 1024323:	and    $0xf,%ecx
 1024326:	mov    %r14,%rdi
 1024329:	mov    %r12,%rsi
 102432c:	mov    %rbx,%rdx
 102432f:	xor    %r8d,%r8d
 1024332:	xor    %r9d,%r9d
 1024335:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 102433a:	mov    %rax,%r13
 102433d:	mov    -0x38(%rbp),%rcx
 1024341:	movq   $0x0,0x28(%rcx)
 1024349:	cmpb   $0x0,0x31(%r15)
 102434e:	je     10243be <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x15e>
 1024350:	lea    -0x30(%rbp),%rdi
 1024354:	mov    %rbx,%rsi
 1024357:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102435c:	mov    %rax,%r12
 102435f:	mov    -0x30(%rbp),%rcx
 1024363:	add    %rcx,%r12
 1024366:	movzbl 0x19(%r15),%eax
 102436b:	cmp    $0xff,%al
 102436d:	je     10243c4 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x164>
 102436f:	mov    %rcx,-0x40(%rbp)
 1024373:	and    $0xf,%al
 1024375:	movzbl %al,%ecx
 1024378:	lea    -0x30(%rbp),%rsi
 102437c:	mov    %r14,%rdi
 102437f:	mov    %rbx,%rdx
 1024382:	xor    %r8d,%r8d
 1024385:	xor    %r9d,%r9d
 1024388:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 102438d:	test   %rax,%rax
 1024390:	je     10243c4 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x164>
 1024392:	mov    -0x40(%rbp),%rax
 1024396:	mov    %rax,-0x30(%rbp)
 102439a:	movzbl 0x19(%r15),%ecx
 102439f:	lea    -0x30(%rbp),%rsi
 10243a3:	mov    %r14,%rdi
 10243a6:	mov    %rbx,%rdx
 10243a9:	xor    %r8d,%r8d
 10243ac:	xor    %r9d,%r9d
 10243af:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 10243b4:	mov    -0x38(%rbp),%rcx
 10243b8:	mov    %rax,0x28(%rcx)
 10243bc:	jmp    10243c8 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x168>
 10243be:	mov    -0x30(%rbp),%r12
 10243c2:	jmp    10243c8 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x168>
 10243c4:	mov    -0x38(%rbp),%rcx
 10243c8:	mov    -0x50(%rbp),%rax
 10243cc:	mov    %rax,(%rcx)
 10243cf:	sub    %rax,%rbx
 10243d2:	mov    %rbx,0x8(%rcx)
 10243d6:	mov    %r12,0x10(%rcx)
 10243da:	mov    -0x48(%rbp),%rax
 10243de:	mov    %rax,0x18(%rcx)
 10243e2:	add    %rax,%r13
 10243e5:	mov    %r13,0x20(%rcx)
 10243e9:	xor    %eax,%eax
 10243eb:	add    $0x28,%rsp
 10243ef:	pop    %rbx
 10243f0:	pop    %r12
 10243f2:	pop    %r13
 10243f4:	pop    %r14
 10243f6:	pop    %r15
 10243f8:	pop    %rbp
 10243f9:	ret
 10243fa:	int3
 10243fb:	int3
 10243fc:	int3
 10243fd:	int3
 10243fe:	int3
 10243ff:	int3

0000000001024400 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE>:
 1024400:	push   %rbp
 1024401:	mov    %rsp,%rbp
 1024404:	push   %r15
 1024406:	push   %r14
 1024408:	push   %r13
 102440a:	push   %r12
 102440c:	push   %rbx
 102440d:	sub    $0x18,%rsp
 1024411:	mov    %rdx,%rbx
 1024414:	mov    %rsi,%r14
 1024417:	mov    %rdi,-0x38(%rbp)
 102441b:	movl   $0xff00,0x18(%rdx)
 1024422:	vxorps %xmm0,%xmm0,%xmm0
 1024426:	vmovups %xmm0,0x20(%rdx)
 102442b:	movw   $0x0,0x30(%rdx)
 1024431:	mov    %rsi,(%rdx)
 1024434:	mov    (%rsi),%eax
 1024436:	mov    $0xffffffff,%ecx
 102443b:	cmp    %rcx,%rax
 102443e:	je     1024456 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x56>
 1024440:	lea    0x4(%r14),%r13
 1024444:	lea    (%r14,%rax,1),%r12
 1024448:	add    $0x4,%r12
 102444c:	test   %rax,%rax
 102444f:	jne    102446f <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x6f>
 1024451:	jmp    1024611 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x211>
 1024456:	mov    0x4(%r14),%rax
 102445a:	lea    0xc(%r14),%r13
 102445e:	lea    (%rax,%r14,1),%r12
 1024462:	add    $0xc,%r12
 1024466:	test   %rax,%rax
 1024469:	je     1024611 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x211>
 102446f:	cmpl   $0x0,0x0(%r13)
 1024474:	je     1024482 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x82>
 1024476:	lea    -0x20665(%rip),%rax        # 1003e18 <qbe_empty_registry+0x2c0>
 102447d:	jmp    1024613 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x213>
 1024482:	movzbl 0x4(%r13),%r15d
 1024487:	mov    %r15d,%eax
 102448a:	and    $0xfd,%al
 102448c:	cmp    $0x1,%al
 102448e:	jne    102453c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x13c>
 1024494:	add    $0x5,%r13
 1024498:	mov    %r13,%rax
 102449b:	nopl   0x0(%rax,%rax,1)
 10244a0:	cmpb   $0x0,(%rax)
 10244a3:	lea    0x1(%rax),%rax
 10244a7:	jne    10244a0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0xa0>
 10244a9:	mov    %rax,-0x30(%rbp)
 10244ad:	lea    -0x30(%rbp),%rdi
 10244b1:	mov    %r12,%rsi
 10244b4:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10244b9:	mov    %eax,0x28(%rbx)
 10244bc:	mov    -0x30(%rbp),%rax
 10244c0:	mov    $0xfffffffffffffff9,%rdi
 10244c7:	xor    %edx,%edx
 10244c9:	xor    %esi,%esi
 10244cb:	mov    %rax,%rcx
 10244ce:	xchg   %ax,%ax
 10244d0:	cmp    %r12,%rcx
 10244d3:	je     1024622 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x222>
 10244d9:	add    $0x7,%rdi
 10244dd:	movzbl (%rcx),%r9d
 10244e1:	inc    %rcx
 10244e4:	mov    %r9d,%r8d
 10244e7:	and    $0x7f,%r9d
 10244eb:	shlx   %rdi,%r9,%r9
 10244f0:	or     %r9,%rdx
 10244f3:	dec    %rsi
 10244f6:	test   %r8b,%r8b
 10244f9:	js     10244d0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0xd0>
 10244fb:	lea    0x7(%rdi),%r9d
 10244ff:	xor    %r10d,%r10d
 1024502:	cmp    $0x39,%rdi
 1024506:	mov    $0xffffffffffffffff,%rdi
 102450d:	shlx   %r9,%rdi,%rdi
 1024512:	cmovae %r10d,%edi
 1024516:	cmp    $0x40,%r8b
 102451a:	cmovb  %r10d,%edi
 102451e:	or     %edi,%edx
 1024520:	sub    %rsi,%rax
 1024523:	mov    %rax,-0x30(%rbp)
 1024527:	mov    %edx,0x2c(%rbx)
 102452a:	cmp    $0x1,%r15b
 102452e:	jne    1024548 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x148>
 1024530:	inc    %rax
 1024533:	mov    %rax,-0x30(%rbp)
 1024537:	movzbl (%rcx),%eax
 102453a:	jmp    1024554 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x154>
 102453c:	lea    -0x1ffb8(%rip),%rax        # 100458b <qbe_empty_registry+0xa33>
 1024543:	jmp    1024613 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x213>
 1024548:	lea    -0x30(%rbp),%rdi
 102454c:	mov    %r12,%rsi
 102454f:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1024554:	mov    %al,0x32(%rbx)
 1024557:	movq   $0x0,-0x40(%rbp)
 102455f:	cmpb   $0x7a,0x0(%r13)
 1024564:	jne    1024602 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x202>
 102456a:	lea    -0x30(%rbp),%rdi
 102456e:	mov    %r12,%rsi
 1024571:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1024576:	lea    -0x18a3d(%rip),%r15        # 100bb40 <raw_shape+0x40>
 102457d:	jmp    1024586 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x186>
 102457f:	movb   $0x1,0x30(%rbx)
 1024583:	inc    %r13
 1024586:	movzbl 0x0(%r13),%eax
 102458b:	lea    -0x4c(%rax),%ecx
 102458e:	cmp    $0x2e,%ecx
 1024591:	ja     10245fe <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x1fe>
 1024593:	movslq (%r15,%rcx,4),%rax
 1024597:	add    %r15,%rax
 102459a:	jmp    *%rax
 102459c:	mov    -0x30(%rbp),%rax
 10245a0:	movzbl (%rax),%ecx
 10245a3:	mov    %cl,0x19(%rbx)
 10245a6:	jmp    10245bb <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x1bb>
 10245a8:	movb   $0x1,0x31(%rbx)
 10245ac:	inc    %r13
 10245af:	jmp    1024586 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x186>
 10245b1:	mov    -0x30(%rbp),%rax
 10245b5:	movzbl (%rax),%ecx
 10245b8:	mov    %cl,0x18(%rbx)
 10245bb:	inc    %rax
 10245be:	mov    %rax,-0x30(%rbp)
 10245c2:	inc    %r13
 10245c5:	jmp    1024586 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x186>
 10245c7:	mov    -0x30(%rbp),%rax
 10245cb:	movzbl (%rax),%ecx
 10245ce:	mov    %cl,0x1a(%rbx)
 10245d1:	inc    %rax
 10245d4:	mov    %rax,-0x30(%rbp)
 10245d8:	sub    %r14d,%eax
 10245db:	mov    %al,0x1b(%rbx)
 10245de:	mov    -0x38(%rbp),%rdi
 10245e2:	lea    -0x30(%rbp),%rsi
 10245e6:	mov    %r12,%rdx
 10245e9:	xor    %r8d,%r8d
 10245ec:	lea    -0x40(%rbp),%r9
 10245f0:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 10245f5:	mov    %rax,0x20(%rbx)
 10245f9:	inc    %r13
 10245fc:	jmp    1024586 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x186>
 10245fe:	test   %eax,%eax
 1024600:	jne    1024583 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x183>
 1024602:	sub    (%rbx),%r12
 1024605:	mov    %r12,0x8(%rbx)
 1024609:	mov    -0x30(%rbp),%rax
 102460d:	mov    %rax,0x10(%rbx)
 1024611:	xor    %eax,%eax
 1024613:	add    $0x18,%rsp
 1024617:	pop    %rbx
 1024618:	pop    %r12
 102461a:	pop    %r13
 102461c:	pop    %r14
 102461e:	pop    %r15
 1024620:	pop    %rbp
 1024621:	ret
 1024622:	mov    0x456f(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1024629:	mov    (%rbx),%rdi
 102462c:	lea    -0x1fd68(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1024633:	lea    -0x200f1(%rip),%rdx        # 1004549 <qbe_empty_registry+0x9f1>
 102463a:	lea    -0x20790(%rip),%rcx        # 1003eb1 <qbe_empty_registry+0x359>
 1024641:	xor    %eax,%eax
 1024643:	call   10275e0 <fprintf@plt>
 1024648:	mov    (%rbx),%rdi
 102464b:	call   1027680 <fflush@plt>
 1024650:	call   1027690 <abort@plt>
 1024655:	int3
 1024656:	int3
 1024657:	int3
 1024658:	int3
 1024659:	int3
 102465a:	int3
 102465b:	int3
 102465c:	int3
 102465d:	int3
 102465e:	int3
 102465f:	int3

0000000001024660 <_ZN9libunwind20AbstractUnwindCursorD2Ev>:
 1024660:	push   %rbp
 1024661:	mov    %rsp,%rbp
 1024664:	pop    %rbp
 1024665:	ret
 1024666:	int3
 1024667:	int3
 1024668:	int3
 1024669:	int3
 102466a:	int3
 102466b:	int3
 102466c:	int3
 102466d:	int3
 102466e:	int3
 102466f:	int3

0000000001024670 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EED0Ev>:
 1024670:	push   %rbp
 1024671:	mov    %rsp,%rbp
 1024674:	pop    %rbp
 1024675:	ret
 1024676:	int3
 1024677:	int3
 1024678:	int3
 1024679:	int3
 102467a:	int3
 102467b:	int3
 102467c:	int3
 102467d:	int3
 102467e:	int3
 102467f:	int3

0000000001024680 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE8validRegEi>:
 1024680:	push   %rbp
 1024681:	mov    %rsp,%rbp
 1024684:	add    $0x2,%esi
 1024687:	cmp    $0x13,%esi
 102468a:	setb   %al
 102468d:	pop    %rbp
 102468e:	ret
 102468f:	int3

0000000001024690 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getRegEi>:
 1024690:	add    $0x2,%esi
 1024693:	cmp    $0x12,%esi
 1024696:	ja     102473a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getRegEi+0xaa>
 102469c:	lea    -0x18aa7(%rip),%rax        # 100bbfc <raw_shape+0xfc>
 10246a3:	movslq (%rax,%rsi,4),%rcx
 10246a7:	add    %rax,%rcx
 10246aa:	jmp    *%rcx
 10246ac:	add    $0x48,%rdi
 10246b0:	mov    (%rdi),%rax
 10246b3:	ret
 10246b4:	add    $0x90,%rdi
 10246bb:	mov    (%rdi),%rax
 10246be:	ret
 10246bf:	add    $0x78,%rdi
 10246c3:	mov    (%rdi),%rax
 10246c6:	ret
 10246c7:	add    $0x68,%rdi
 10246cb:	mov    (%rdi),%rax
 10246ce:	ret
 10246cf:	add    $0x50,%rdi
 10246d3:	mov    (%rdi),%rax
 10246d6:	ret
 10246d7:	add    $0x28,%rdi
 10246db:	mov    (%rdi),%rax
 10246de:	ret
 10246df:	add    $0x58,%rdi
 10246e3:	mov    (%rdi),%rax
 10246e6:	ret
 10246e7:	add    $0x40,%rdi
 10246eb:	mov    (%rdi),%rax
 10246ee:	ret
 10246ef:	add    $0x70,%rdi
 10246f3:	mov    (%rdi),%rax
 10246f6:	ret
 10246f7:	add    $0x10,%rdi
 10246fb:	mov    (%rdi),%rax
 10246fe:	ret
 10246ff:	add    $0x38,%rdi
 1024703:	mov    (%rdi),%rax
 1024706:	ret
 1024707:	sub    $0xffffffffffffff80,%rdi
 102470b:	mov    (%rdi),%rax
 102470e:	ret
 102470f:	add    $0x20,%rdi
 1024713:	mov    (%rdi),%rax
 1024716:	ret
 1024717:	add    $0x60,%rdi
 102471b:	mov    (%rdi),%rax
 102471e:	ret
 102471f:	add    $0x18,%rdi
 1024723:	mov    (%rdi),%rax
 1024726:	ret
 1024727:	add    $0x88,%rdi
 102472e:	mov    (%rdi),%rax
 1024731:	ret
 1024732:	add    $0x30,%rdi
 1024736:	mov    (%rdi),%rax
 1024739:	ret
 102473a:	push   %rbp
 102473b:	mov    %rsp,%rbp
 102473e:	push   %rbx
 102473f:	push   %rax
 1024740:	mov    0x4451(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1024747:	mov    (%rbx),%rdi
 102474a:	lea    -0x1fe86(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1024751:	lea    -0x2098b(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 1024758:	lea    -0x209ba(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 102475f:	xor    %eax,%eax
 1024761:	call   10275e0 <fprintf@plt>
 1024766:	mov    (%rbx),%rdi
 1024769:	call   1027680 <fflush@plt>
 102476e:	call   1027690 <abort@plt>
 1024773:	int3
 1024774:	int3
 1024775:	int3
 1024776:	int3
 1024777:	int3
 1024778:	int3
 1024779:	int3
 102477a:	int3
 102477b:	int3
 102477c:	int3
 102477d:	int3
 102477e:	int3
 102477f:	int3

0000000001024780 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6setRegEim>:
 1024780:	add    $0x2,%esi
 1024783:	cmp    $0x13,%esi
 1024786:	jae    102479a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6setRegEim+0x1a>
 1024788:	mov    %esi,%eax
 102478a:	lea    -0x18541(%rip),%rcx        # 100c250 <raw_shape+0x750>
 1024791:	mov    (%rcx,%rax,8),%rax
 1024795:	mov    %rdx,(%rdi,%rax,1)
 1024799:	ret
 102479a:	push   %rbp
 102479b:	mov    %rsp,%rbp
 102479e:	push   %rbx
 102479f:	push   %rax
 10247a0:	mov    0x43f1(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 10247a7:	mov    (%rbx),%rdi
 10247aa:	lea    -0x1fee6(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10247b1:	lea    -0x209f7(%rip),%rdx        # 1003dc1 <qbe_empty_registry+0x269>
 10247b8:	lea    -0x20a1a(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 10247bf:	xor    %eax,%eax
 10247c1:	call   10275e0 <fprintf@plt>
 10247c6:	mov    (%rbx),%rdi
 10247c9:	call   1027680 <fflush@plt>
 10247ce:	call   1027690 <abort@plt>
 10247d3:	int3
 10247d4:	int3
 10247d5:	int3
 10247d6:	int3
 10247d7:	int3
 10247d8:	int3
 10247d9:	int3
 10247da:	int3
 10247db:	int3
 10247dc:	int3
 10247dd:	int3
 10247de:	int3
 10247df:	int3

00000000010247e0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE13validFloatRegEi>:
 10247e0:	push   %rbp
 10247e1:	mov    %rsp,%rbp
 10247e4:	xor    %eax,%eax
 10247e6:	pop    %rbp
 10247e7:	ret
 10247e8:	int3
 10247e9:	int3
 10247ea:	int3
 10247eb:	int3
 10247ec:	int3
 10247ed:	int3
 10247ee:	int3
 10247ef:	int3

00000000010247f0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE11getFloatRegEi>:
 10247f0:	push   %rbp
 10247f1:	mov    %rsp,%rbp
 10247f4:	push   %rbx
 10247f5:	push   %rax
 10247f6:	mov    0x439b(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 10247fd:	mov    (%rbx),%rdi
 1024800:	lea    -0x1ff3c(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1024807:	lea    -0x20a24(%rip),%rdx        # 1003dea <qbe_empty_registry+0x292>
 102480e:	lea    -0x20ad8(%rip),%rcx        # 1003d3d <qbe_empty_registry+0x1e5>
 1024815:	xor    %eax,%eax
 1024817:	call   10275e0 <fprintf@plt>
 102481c:	mov    (%rbx),%rdi
 102481f:	call   1027680 <fflush@plt>
 1024824:	call   1027690 <abort@plt>
 1024829:	int3
 102482a:	int3
 102482b:	int3
 102482c:	int3
 102482d:	int3
 102482e:	int3
 102482f:	int3

0000000001024830 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE11setFloatRegEid>:
 1024830:	push   %rbp
 1024831:	mov    %rsp,%rbp
 1024834:	push   %rbx
 1024835:	push   %rax
 1024836:	mov    0x435b(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 102483d:	mov    (%rbx),%rdi
 1024840:	lea    -0x1ff7c(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1024847:	lea    -0x20a75(%rip),%rdx        # 1003dd9 <qbe_empty_registry+0x281>
 102484e:	lea    -0x20b18(%rip),%rcx        # 1003d3d <qbe_empty_registry+0x1e5>
 1024855:	xor    %eax,%eax
 1024857:	call   10275e0 <fprintf@plt>
 102485c:	mov    (%rbx),%rdi
 102485f:	call   1027680 <fflush@plt>
 1024864:	call   1027690 <abort@plt>
 1024869:	int3
 102486a:	int3
 102486b:	int3
 102486c:	int3
 102486d:	int3
 102486e:	int3
 102486f:	int3

0000000001024870 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE4stepEb>:
 1024870:	push   %rbp
 1024871:	mov    %rsp,%rbp
 1024874:	push   %r15
 1024876:	push   %r14
 1024878:	push   %rbx
 1024879:	push   %rax
 102487a:	xor    %ebx,%ebx
 102487c:	cmpb   $0x0,0x100(%rdi)
 1024883:	jne    10248e0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE4stepEb+0x70>
 1024885:	mov    %esi,%r15d
 1024888:	mov    %rdi,%r14
 102488b:	mov    (%rdi),%rax
 102488e:	mov    $0xffffffff,%esi
 1024893:	call   *0x18(%rax)
 1024896:	mov    %rax,-0x20(%rbp)
 102489a:	mov    0x8(%r14),%rdi
 102489e:	mov    0xf0(%r14),%rdx
 10248a5:	lea    0x10(%r14),%rcx
 10248a9:	lea    0x101(%r14),%r8
 10248b0:	movzbl %r15b,%r9d
 10248b4:	lea    -0x20(%rbp),%rsi
 10248b8:	call   1024ce0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb>
 10248bd:	mov    %eax,%r15d
 10248c0:	cmp    $0x1,%eax
 10248c3:	jne    10248dd <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE4stepEb+0x6d>
 10248c5:	mov    (%r14),%rax
 10248c8:	mov    %r14,%rdi
 10248cb:	mov    $0x1,%esi
 10248d0:	call   *0x68(%rax)
 10248d3:	cmpb   $0x0,0x100(%r14)
 10248db:	jne    10248e0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE4stepEb+0x70>
 10248dd:	mov    %r15d,%ebx
 10248e0:	mov    %ebx,%eax
 10248e2:	add    $0x8,%rsp
 10248e6:	pop    %rbx
 10248e7:	pop    %r14
 10248e9:	pop    %r15
 10248eb:	pop    %rbp
 10248ec:	ret
 10248ed:	int3
 10248ee:	int3
 10248ef:	int3

00000000010248f0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE7getInfoEP15unw_proc_info_t>:
 10248f0:	push   %rbp
 10248f1:	mov    %rsp,%rbp
 10248f4:	cmpb   $0x1,0x100(%rdi)
 10248fb:	jne    1024917 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE7getInfoEP15unw_proc_info_t+0x27>
 10248fd:	vxorps %xmm0,%xmm0,%xmm0
 1024901:	vmovups %ymm0,0x20(%rsi)
 1024906:	vmovups %ymm0,(%rsi)
 102490a:	movq   $0x0,0x40(%rsi)
 1024912:	pop    %rbp
 1024913:	vzeroupper
 1024916:	ret
 1024917:	mov    0xf8(%rdi),%rax
 102491e:	mov    %rax,0x40(%rsi)
 1024922:	vmovups 0xb8(%rdi),%ymm0
 102492a:	vmovups 0xd8(%rdi),%ymm1
 1024932:	vmovups %ymm1,0x20(%rsi)
 1024937:	vmovups %ymm0,(%rsi)
 102493b:	pop    %rbp
 102493c:	vzeroupper
 102493f:	ret

0000000001024940 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6jumptoEv>:
 1024940:	push   %rbp
 1024941:	mov    %rsp,%rbp
 1024944:	add    $0x10,%rdi
 1024948:	pop    %rbp
 1024949:	jmp    10273e0 <__libunwind_Registers_x86_64_jumpto>
 102494e:	int3
 102494f:	int3

0000000001024950 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE13isSignalFrameEv>:
 1024950:	push   %rbp
 1024951:	mov    %rsp,%rbp
 1024954:	movzbl 0x101(%rdi),%eax
 102495b:	pop    %rbp
 102495c:	ret
 102495d:	int3
 102495e:	int3
 102495f:	int3

0000000001024960 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE15getFunctionNameEPcmPm>:
 1024960:	push   %rbp
 1024961:	mov    %rsp,%rbp
 1024964:	push   %r15
 1024966:	push   %r14
 1024968:	push   %r13
 102496a:	push   %r12
 102496c:	push   %rbx
 102496d:	sub    $0x28,%rsp
 1024971:	mov    %rcx,%rbx
 1024974:	mov    %rdx,%r14
 1024977:	mov    %rsi,%r12
 102497a:	mov    (%rdi),%rax
 102497d:	mov    $0xffffffff,%esi
 1024982:	call   *0x18(%rax)
 1024985:	mov    %rax,%r15
 1024988:	lea    -0x48(%rbp),%rsi
 102498c:	mov    %rax,%rdi
 102498f:	call   1027930 <dladdr@plt>
 1024994:	test   %eax,%eax
 1024996:	setne  %al
 1024999:	mov    -0x38(%rbp),%rcx
 102499d:	test   %rcx,%rcx
 10249a0:	setne  %r13b
 10249a4:	and    %al,%r13b
 10249a7:	cmp    $0x1,%r13b
 10249ab:	jne    10249c8 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE15getFunctionNameEPcmPm+0x68>
 10249ad:	lea    -0x20c5b(%rip),%rdx        # 1003d59 <qbe_empty_registry+0x201>
 10249b4:	mov    %r12,%rdi
 10249b7:	mov    %r14,%rsi
 10249ba:	xor    %eax,%eax
 10249bc:	call   1027660 <snprintf@plt>
 10249c1:	sub    -0x30(%rbp),%r15
 10249c5:	mov    %r15,(%rbx)
 10249c8:	mov    %r13d,%eax
 10249cb:	add    $0x28,%rsp
 10249cf:	pop    %rbx
 10249d0:	pop    %r12
 10249d2:	pop    %r13
 10249d4:	pop    %r14
 10249d6:	pop    %r15
 10249d8:	pop    %rbp
 10249d9:	ret
 10249da:	int3
 10249db:	int3
 10249dc:	int3
 10249dd:	int3
 10249de:	int3
 10249df:	int3

00000000010249e0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb>:
 10249e0:	push   %rbp
 10249e1:	mov    %rsp,%rbp
 10249e4:	push   %r15
 10249e6:	push   %r14
 10249e8:	push   %rbx
 10249e9:	sub    $0x2c8,%rsp
 10249f0:	mov    %esi,%r14d
 10249f3:	mov    %rdi,%rbx
 10249f6:	mov    (%rdi),%rax
 10249f9:	mov    $0xffffffff,%esi
 10249fe:	call   *0x18(%rax)
 1024a01:	mov    %rax,-0x20(%rbp)
 1024a05:	test   %rax,%rax
 1024a08:	je     1024c94 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2b4>
 1024a0e:	test   %r14b,%r14b
 1024a11:	je     1024a1a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x3a>
 1024a13:	dec    %rax
 1024a16:	mov    %rax,-0x20(%rbp)
 1024a1a:	cmpb   $0x1,0x101(%rbx)
 1024a21:	jne    1024a2a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x4a>
 1024a23:	inc    %rax
 1024a26:	mov    %rax,-0x20(%rbp)
 1024a2a:	movq   $0x0,-0x50(%rbp)
 1024a32:	vxorps %xmm0,%xmm0,%xmm0
 1024a36:	vmovups %xmm0,-0x40(%rbp)
 1024a3b:	mov    0x8(%rbx),%r14
 1024a3f:	cmpb   $0x0,0x6da2(%rip)        # 102b7e8 <_ZZN9libunwind17LocalAddressSpace18findUnwindSectionsINS_16Registers_x86_64EEEbNT_23link_hardened_reg_arg_tERNS_18UnwindInfoSectionsEE19dlFindObjectChecked>
 1024a46:	je     1024a56 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x76>
 1024a48:	mov    0x6d91(%rip),%rcx        # 102b7e0 <_ZZN9libunwind17LocalAddressSpace18findUnwindSectionsINS_16Registers_x86_64EEEbNT_23link_hardened_reg_arg_tERNS_18UnwindInfoSectionsEE12dlFindObject>
 1024a4f:	test   %rcx,%rcx
 1024a52:	jne    1024a80 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xa0>
 1024a54:	jmp    1024a94 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xb4>
 1024a56:	lea    -0x20d3c(%rip),%rsi        # 1003d21 <qbe_empty_registry+0x1c9>
 1024a5d:	xor    %edi,%edi
 1024a5f:	mov    %rax,%r15
 1024a62:	call   1027940 <dlsym@plt>
 1024a67:	mov    %rax,%rcx
 1024a6a:	mov    %r15,%rax
 1024a6d:	mov    %rcx,0x6d6c(%rip)        # 102b7e0 <_ZZN9libunwind17LocalAddressSpace18findUnwindSectionsINS_16Registers_x86_64EEEbNT_23link_hardened_reg_arg_tERNS_18UnwindInfoSectionsEE12dlFindObject>
 1024a74:	movb   $0x1,0x6d6d(%rip)        # 102b7e8 <_ZZN9libunwind17LocalAddressSpace18findUnwindSectionsINS_16Registers_x86_64EEEbNT_23link_hardened_reg_arg_tERNS_18UnwindInfoSectionsEE19dlFindObjectChecked>
 1024a7b:	test   %rcx,%rcx
 1024a7e:	je     1024a94 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xb4>
 1024a80:	lea    -0x2e0(%rbp),%rsi
 1024a87:	mov    %rax,%rdi
 1024a8a:	call   *%rcx
 1024a8c:	test   %eax,%eax
 1024a8e:	je     1024aea <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x10a>
 1024a90:	mov    -0x20(%rbp),%rax
 1024a94:	mov    %r14,-0x88(%rbp)
 1024a9b:	lea    -0x50(%rbp),%rcx
 1024a9f:	mov    %rcx,-0x80(%rbp)
 1024aa3:	mov    %rax,-0x78(%rbp)
 1024aa7:	lea    0x23c2(%rip),%rdi        # 1026e70 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv>
 1024aae:	lea    -0x88(%rbp),%rsi
 1024ab5:	call   1027950 <dl_iterate_phdr@plt>
 1024aba:	test   %eax,%eax
 1024abc:	setne  %al
 1024abf:	test   %al,%al
 1024ac1:	je     1024b4a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x16a>
 1024ac7:	cmpq   $0x0,-0x40(%rbp)
 1024acc:	je     1024b4a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x16a>
 1024ace:	lea    -0x20(%rbp),%rsi
 1024ad2:	lea    -0x50(%rbp),%rdx
 1024ad6:	mov    %rbx,%rdi
 1024ad9:	xor    %ecx,%ecx
 1024adb:	call   1026a60 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj>
 1024ae0:	test   %al,%al
 1024ae2:	jne    1024c9b <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2bb>
 1024ae8:	jmp    1024b4a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x16a>
 1024aea:	mov    -0x2c0(%rbp),%rsi
 1024af1:	test   %rsi,%rsi
 1024af4:	je     1024b4a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x16a>
 1024af6:	mov    -0x2d8(%rbp),%rax
 1024afd:	mov    -0x2d0(%rbp),%rcx
 1024b04:	mov    %rax,-0x50(%rbp)
 1024b08:	sub    %rax,%rcx
 1024b0b:	mov    %rcx,-0x48(%rbp)
 1024b0f:	mov    %rsi,-0x30(%rbp)
 1024b13:	movq   $0xffffffffffffffff,-0x28(%rbp)
 1024b1b:	lea    -0x1(%rsi),%rdx
 1024b1f:	lea    -0x88(%rbp),%rcx
 1024b26:	mov    %r14,%rdi
 1024b29:	call   1026d70 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE>
 1024b2e:	test   %al,%al
 1024b30:	je     1024abf <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xdf>
 1024b32:	mov    -0x88(%rbp),%rcx
 1024b39:	mov    %rcx,-0x40(%rbp)
 1024b3d:	movq   $0xffffffffffffffff,-0x38(%rbp)
 1024b45:	jmp    1024abf <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xdf>
 1024b4a:	lea    0x6c9f(%rip),%rdi        # 102b7f0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1024b51:	call   1027960 <pthread_rwlock_rdlock@plt>
 1024b56:	mov    0x6c33(%rip),%rax        # 102b790 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE7_bufferE>
 1024b5d:	mov    0x6c34(%rip),%rcx        # 102b798 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE11_bufferUsedE>
 1024b64:	cmp    %rcx,%rax
 1024b67:	jae    1024c88 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2a8>
 1024b6d:	mov    -0x20(%rbp),%rdx
 1024b71:	jmp    1024b8d <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x1ad>
 1024b73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1024b80:	add    $0x20,%rax
 1024b84:	cmp    %rcx,%rax
 1024b87:	jae    1024c88 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2a8>
 1024b8d:	cmp    %rdx,0x8(%rax)
 1024b91:	ja     1024b80 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x1a0>
 1024b93:	cmp    0x10(%rax),%rdx
 1024b97:	jae    1024b80 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x1a0>
 1024b99:	mov    0x18(%rax),%r14
 1024b9d:	lea    0x6c4c(%rip),%rdi        # 102b7f0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1024ba4:	call   1027920 <pthread_rwlock_unlock@plt>
 1024ba9:	test   %r14,%r14
 1024bac:	je     1024c94 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2b4>
 1024bb2:	mov    0x8(%rbx),%rdi
 1024bb6:	lea    -0xb8(%rbp),%rdx
 1024bbd:	lea    -0x88(%rbp),%rcx
 1024bc4:	mov    %r14,%rsi
 1024bc7:	xor    %r8d,%r8d
 1024bca:	call   1024260 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb>
 1024bcf:	test   %rax,%rax
 1024bd2:	jne    1024c94 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2b4>
 1024bd8:	lea    -0x2e0(%rbp),%r14
 1024bdf:	mov    $0x228,%edx
 1024be4:	mov    %r14,%rdi
 1024be7:	xor    %esi,%esi
 1024be9:	call   10274d0 <memset@plt>
 1024bee:	mov    0x8(%rbx),%rdi
 1024bf2:	lea    -0xb8(%rbp),%rsi
 1024bf9:	lea    -0x88(%rbp),%rdx
 1024c00:	lea    -0x20(%rbp),%rcx
 1024c04:	mov    $0x1,%r8d
 1024c0a:	mov    %r14,%r9
 1024c0d:	call   1025110 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE>
 1024c12:	test   %al,%al
 1024c14:	je     1024c94 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2b4>
 1024c16:	vmovups -0xa0(%rbp),%xmm0
 1024c1e:	vmovups %xmm0,0xb8(%rbx)
 1024c26:	mov    -0x90(%rbp),%rax
 1024c2d:	mov    %rax,0xc8(%rbx)
 1024c34:	mov    -0x68(%rbp),%rax
 1024c38:	mov    %rax,0xd0(%rbx)
 1024c3f:	mov    -0x2d0(%rbp),%eax
 1024c45:	mov    %rax,0xd8(%rbx)
 1024c4c:	movq   $0x0,0xe0(%rbx)
 1024c57:	movl   $0x4000000,0xe8(%rbx)
 1024c61:	mov    -0xb8(%rbp),%rax
 1024c68:	mov    %rax,0xf0(%rbx)
 1024c6f:	mov    -0xb0(%rbp),%eax
 1024c75:	mov    %eax,0xec(%rbx)
 1024c7b:	movq   $0x0,0xf8(%rbx)
 1024c86:	jmp    1024c9b <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2bb>
 1024c88:	lea    0x6b61(%rip),%rdi        # 102b7f0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1024c8f:	call   1027920 <pthread_rwlock_unlock@plt>
 1024c94:	movb   $0x1,0x100(%rbx)
 1024c9b:	add    $0x2c8,%rsp
 1024ca2:	pop    %rbx
 1024ca3:	pop    %r14
 1024ca5:	pop    %r15
 1024ca7:	pop    %rbp
 1024ca8:	ret
 1024ca9:	int3
 1024caa:	int3
 1024cab:	int3
 1024cac:	int3
 1024cad:	int3
 1024cae:	int3
 1024caf:	int3

0000000001024cb0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE15getRegisterNameEi>:
 1024cb0:	push   %rbp
 1024cb1:	mov    %rsp,%rbp
 1024cb4:	add    $0x2,%esi
 1024cb7:	cmp    $0x22,%esi
 1024cba:	ja     1024cce <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE15getRegisterNameEi+0x1e>
 1024cbc:	mov    %esi,%eax
 1024cbe:	lea    -0x189dd(%rip),%rcx        # 100c2e8 <raw_shape+0x7e8>
 1024cc5:	movslq (%rcx,%rax,4),%rax
 1024cc9:	add    %rcx,%rax
 1024ccc:	pop    %rbp
 1024ccd:	ret
 1024cce:	lea    -0x20f41(%rip),%rax        # 1003d94 <qbe_empty_registry+0x23c>
 1024cd5:	pop    %rbp
 1024cd6:	ret
 1024cd7:	int3
 1024cd8:	int3
 1024cd9:	int3
 1024cda:	int3
 1024cdb:	int3
 1024cdc:	int3
 1024cdd:	int3
 1024cde:	int3
 1024cdf:	int3

0000000001024ce0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb>:
 1024ce0:	push   %rbp
 1024ce1:	mov    %rsp,%rbp
 1024ce4:	push   %r15
 1024ce6:	push   %r14
 1024ce8:	push   %r13
 1024cea:	push   %r12
 1024cec:	push   %rbx
 1024ced:	sub    $0x358,%rsp
 1024cf4:	mov    %r8,%r13
 1024cf7:	mov    %rcx,%rbx
 1024cfa:	mov    %rsi,%r14
 1024cfd:	mov    %rdi,%r15
 1024d00:	lea    -0x150(%rbp),%rax
 1024d07:	lea    -0xf8(%rbp),%rcx
 1024d0e:	mov    %rdx,%rsi
 1024d11:	mov    %rax,%rdx
 1024d14:	xor    %r8d,%r8d
 1024d17:	call   1024260 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb>
 1024d1c:	mov    %rax,%rcx
 1024d1f:	mov    $0xffffe66e,%eax
 1024d24:	test   %rcx,%rcx
 1024d27:	jne    10250c0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3e0>
 1024d2d:	lea    -0x378(%rbp),%r12
 1024d34:	mov    $0x228,%edx
 1024d39:	mov    %r12,%rdi
 1024d3c:	xor    %esi,%esi
 1024d3e:	call   10274d0 <memset@plt>
 1024d43:	lea    -0x150(%rbp),%rsi
 1024d4a:	lea    -0xf8(%rbp),%rdx
 1024d51:	mov    %r15,%rdi
 1024d54:	mov    %r14,%rcx
 1024d57:	mov    $0x1,%r8d
 1024d5d:	mov    %r12,%r9
 1024d60:	call   1025110 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE>
 1024d65:	mov    %eax,%ecx
 1024d67:	mov    $0xffffe66e,%eax
 1024d6c:	test   %cl,%cl
 1024d6e:	je     10250c0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3e0>
 1024d74:	mov    %r13,-0xc0(%rbp)
 1024d7b:	lea    -0x378(%rbp),%rsi
 1024d82:	mov    %r15,%rdi
 1024d85:	mov    %rbx,%rdx
 1024d88:	call   1025bd0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_>
 1024d8d:	mov    %rax,%r12
 1024d90:	mov    (%rbx),%rax
 1024d93:	mov    %rax,-0x58(%rbp)
 1024d97:	mov    0x8(%rbx),%rax
 1024d9b:	mov    %rax,-0x88(%rbp)
 1024da2:	mov    0x10(%rbx),%rax
 1024da6:	mov    %rax,-0x60(%rbp)
 1024daa:	mov    0x18(%rbx),%rax
 1024dae:	mov    %rax,-0x68(%rbp)
 1024db2:	mov    0x20(%rbx),%rax
 1024db6:	mov    %rax,-0x70(%rbp)
 1024dba:	mov    0x28(%rbx),%rax
 1024dbe:	mov    %rax,-0x78(%rbp)
 1024dc2:	mov    0x30(%rbx),%rax
 1024dc6:	mov    %rax,-0x80(%rbp)
 1024dca:	mov    0x40(%rbx),%rax
 1024dce:	mov    %rax,-0x90(%rbp)
 1024dd5:	mov    0x48(%rbx),%rax
 1024dd9:	mov    %rax,-0x98(%rbp)
 1024de0:	mov    0x50(%rbx),%rax
 1024de4:	mov    %rax,-0xa0(%rbp)
 1024deb:	mov    0x58(%rbx),%rax
 1024def:	mov    %rax,-0xa8(%rbp)
 1024df6:	mov    0x60(%rbx),%rax
 1024dfa:	mov    %rax,-0xb0(%rbp)
 1024e01:	vmovups 0x88(%rbx),%ymm0
 1024e09:	mov    0x68(%rbx),%rax
 1024e0d:	mov    %rax,-0x40(%rbp)
 1024e11:	mov    0x70(%rbx),%rax
 1024e15:	mov    %rax,-0x48(%rbp)
 1024e19:	mov    0x78(%rbx),%rax
 1024e1d:	mov    %rax,-0x50(%rbp)
 1024e21:	vmovups %ymm0,-0x120(%rbp)
 1024e29:	lea    0x88(%rbx),%rax
 1024e30:	mov    %rax,-0xb8(%rbp)
 1024e37:	lea    -0x360(%rbp),%r13
 1024e3e:	movq   $0x0,-0x30(%rbp)
 1024e46:	xor    %r14d,%r14d
 1024e49:	mov    %r12,-0x38(%rbp)
 1024e4d:	jmp    1024e79 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x199>
 1024e4f:	nop
 1024e50:	mov    %r15,%rdi
 1024e53:	mov    %rbx,%rsi
 1024e56:	mov    %r12,%rdx
 1024e59:	mov    %r13,%rcx
 1024e5c:	vzeroupper
 1024e5f:	call   1025cb0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE>
 1024e64:	mov    %rax,-0x30(%rbp)
 1024e68:	inc    %r14
 1024e6b:	add    $0x10,%r13
 1024e6f:	cmp    $0x21,%r14
 1024e73:	je     1024ff5 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x315>
 1024e79:	cmpl   $0x0,0x0(%r13)
 1024e7e:	movzbl -0xc6(%rbp),%eax
 1024e85:	je     1024ed0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x1f0>
 1024e87:	cmp    %rax,%r14
 1024e8a:	je     1024e50 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x170>
 1024e8c:	cmp    $0x10,%r14
 1024e90:	ja     10250bb <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3db>
 1024e96:	mov    %r15,%rdi
 1024e99:	mov    %rbx,%rsi
 1024e9c:	mov    %r12,%rdx
 1024e9f:	mov    %r13,%rcx
 1024ea2:	vzeroupper
 1024ea5:	call   1025cb0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE>
 1024eaa:	mov    %r14d,%ecx
 1024ead:	lea    -0x1926c(%rip),%rdx        # 100bc48 <raw_shape+0x148>
 1024eb4:	movslq (%rdx,%rcx,4),%rcx
 1024eb8:	add    %rdx,%rcx
 1024ebb:	jmp    *%rcx
 1024ebd:	mov    %rax,-0x58(%rbp)
 1024ec1:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024ec3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1024ed0:	cmp    %rax,%r14
 1024ed3:	jne    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024ed5:	cmp    $0x10,%al
 1024ed7:	ja     10250d5 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3f5>
 1024edd:	lea    -0x19258(%rip),%rdx        # 100bc8c <raw_shape+0x18c>
 1024ee4:	movslq (%rdx,%rax,4),%rcx
 1024ee8:	add    %rdx,%rcx
 1024eeb:	mov    %rbx,%rax
 1024eee:	jmp    *%rcx
 1024ef0:	lea    0x18(%rbx),%rax
 1024ef4:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024ef9:	mov    %rax,-0x50(%rbp)
 1024efd:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f02:	mov    %rax,-0x40(%rbp)
 1024f06:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f0b:	mov    %rax,-0xa0(%rbp)
 1024f12:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f17:	mov    %rax,-0x88(%rbp)
 1024f1e:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f23:	mov    %rax,-0xa8(%rbp)
 1024f2a:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f2f:	mov    %rax,-0x90(%rbp)
 1024f36:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f3b:	mov    %rax,-0x68(%rbp)
 1024f3f:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f44:	mov    %rax,-0x48(%rbp)
 1024f48:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f4d:	mov    %rax,-0x60(%rbp)
 1024f51:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f56:	mov    %rax,-0x80(%rbp)
 1024f5a:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f5f:	mov    %rax,-0x78(%rbp)
 1024f63:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f68:	mov    %rax,-0xb0(%rbp)
 1024f6f:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f74:	mov    %rax,-0x70(%rbp)
 1024f78:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f7d:	mov    %rax,-0x98(%rbp)
 1024f84:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f89:	mov    %rax,-0x38(%rbp)
 1024f8d:	jmp    1024e68 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1024f92:	lea    0x80(%rbx),%rax
 1024f99:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024f9b:	lea    0x70(%rbx),%rax
 1024f9f:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fa1:	lea    0x58(%rbx),%rax
 1024fa5:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fa7:	lea    0x28(%rbx),%rax
 1024fab:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fad:	lea    0x60(%rbx),%rax
 1024fb1:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fb3:	lea    0x48(%rbx),%rax
 1024fb7:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fb9:	lea    0x10(%rbx),%rax
 1024fbd:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fbf:	lea    0x78(%rbx),%rax
 1024fc3:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fc5:	lea    0x8(%rbx),%rax
 1024fc9:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fcb:	lea    0x38(%rbx),%rax
 1024fcf:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fd1:	lea    0x20(%rbx),%rax
 1024fd5:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fd7:	lea    0x68(%rbx),%rax
 1024fdb:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fdd:	lea    0x30(%rbx),%rax
 1024fe1:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fe3:	lea    0x50(%rbx),%rax
 1024fe7:	jmp    1024fed <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1024fe9:	lea    0x40(%rbx),%rax
 1024fed:	mov    (%rax),%rax
 1024ff0:	jmp    1024e64 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x184>
 1024ff5:	movzbl -0xc8(%rbp),%eax
 1024ffc:	mov    -0xc0(%rbp),%rcx
 1025003:	mov    %al,(%rcx)
 1025005:	mov    -0x58(%rbp),%rax
 1025009:	mov    %rax,(%rbx)
 102500c:	mov    -0x88(%rbp),%rax
 1025013:	mov    %rax,0x8(%rbx)
 1025017:	mov    -0x60(%rbp),%rax
 102501b:	mov    %rax,0x10(%rbx)
 102501f:	mov    -0x68(%rbp),%rax
 1025023:	mov    %rax,0x18(%rbx)
 1025027:	mov    -0x70(%rbp),%rax
 102502b:	mov    %rax,0x20(%rbx)
 102502f:	mov    -0x78(%rbp),%rax
 1025033:	mov    %rax,0x28(%rbx)
 1025037:	mov    -0x80(%rbp),%rax
 102503b:	mov    %rax,0x30(%rbx)
 102503f:	mov    -0x38(%rbp),%rax
 1025043:	mov    %rax,0x38(%rbx)
 1025047:	mov    -0x90(%rbp),%rax
 102504e:	mov    %rax,0x40(%rbx)
 1025052:	mov    -0x98(%rbp),%rax
 1025059:	mov    %rax,0x48(%rbx)
 102505d:	mov    -0xa0(%rbp),%rax
 1025064:	mov    %rax,0x50(%rbx)
 1025068:	mov    -0xa8(%rbp),%rax
 102506f:	mov    %rax,0x58(%rbx)
 1025073:	mov    -0xb0(%rbp),%rax
 102507a:	mov    %rax,0x60(%rbx)
 102507e:	mov    -0x40(%rbp),%rax
 1025082:	mov    %rax,0x68(%rbx)
 1025086:	mov    -0x48(%rbp),%rax
 102508a:	mov    %rax,0x70(%rbx)
 102508e:	mov    -0x50(%rbp),%rax
 1025092:	mov    %rax,0x78(%rbx)
 1025096:	mov    -0x30(%rbp),%rax
 102509a:	mov    %rax,0x80(%rbx)
 10250a1:	vmovups -0x120(%rbp),%ymm0
 10250a9:	mov    -0xb8(%rbp),%rax
 10250b0:	vmovups %ymm0,(%rax)
 10250b4:	mov    $0x1,%eax
 10250b9:	jmp    10250c0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3e0>
 10250bb:	mov    $0xffffe672,%eax
 10250c0:	add    $0x358,%rsp
 10250c7:	pop    %rbx
 10250c8:	pop    %r12
 10250ca:	pop    %r13
 10250cc:	pop    %r14
 10250ce:	pop    %r15
 10250d0:	pop    %rbp
 10250d1:	vzeroupper
 10250d4:	ret
 10250d5:	mov    0x3abc(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 10250dc:	mov    (%rbx),%rdi
 10250df:	lea    -0x2081b(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10250e6:	lea    -0x21320(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 10250ed:	lea    -0x2134f(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 10250f4:	xor    %eax,%eax
 10250f6:	vzeroupper
 10250f9:	call   10275e0 <fprintf@plt>
 10250fe:	mov    (%rbx),%rdi
 1025101:	call   1027680 <fflush@plt>
 1025106:	call   1027690 <abort@plt>
 102510b:	int3
 102510c:	int3
 102510d:	int3
 102510e:	int3
 102510f:	int3

0000000001025110 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE>:
 1025110:	push   %rbp
 1025111:	mov    %rsp,%rbp
 1025114:	push   %r15
 1025116:	push   %r14
 1025118:	push   %r13
 102511a:	push   %r12
 102511c:	push   %rbx
 102511d:	sub    $0x298,%rsp
 1025124:	mov    %rdx,%r14
 1025127:	mov    0x10(%rdx),%rax
 102512b:	mov    %rax,-0x90(%rbp)
 1025132:	mov    0x8(%rdx),%rax
 1025136:	add    (%rdx),%rax
 1025139:	mov    %rdi,-0x58(%rbp)
 102513d:	mov    %rax,-0x88(%rbp)
 1025144:	movq   $0xffffffffffffffff,-0x80(%rbp)
 102514c:	mov    0x10(%rsi),%rax
 1025150:	mov    %rax,-0x78(%rbp)
 1025154:	mov    0x8(%rsi),%rax
 1025158:	add    (%rsi),%rax
 102515b:	mov    %rax,-0x70(%rbp)
 102515f:	mov    (%rcx),%rax
 1025162:	sub    0x18(%rsi),%rax
 1025166:	mov    %rax,-0x68(%rbp)
 102516a:	mov    %r9,-0x40(%rbp)
 102516e:	lea    0x18(%r9),%r15
 1025172:	movq   $0x0,-0x48(%rbp)
 102517a:	xor    %eax,%eax
 102517c:	mov    %rdx,-0x50(%rbp)
 1025180:	mov    %r15,-0x38(%rbp)
 1025184:	jmp    10251a2 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x92>
 1025186:	cs nopw 0x0(%rax,%rax,1)
 1025190:	mov    -0x60(%rbp),%rax
 1025194:	add    $0x18,%rax
 1025198:	cmp    $0x30,%rax
 102519c:	je     10259c1 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8b1>
 10251a2:	mov    -0x90(%rbp,%rax,1),%rcx
 10251aa:	mov    -0x88(%rbp,%rax,1),%r13
 10251b2:	mov    %rcx,-0x30(%rbp)
 10251b6:	mov    %rax,-0x60(%rbp)
 10251ba:	mov    -0x80(%rbp,%rax,1),%rbx
 10251bf:	cmp    %r13,%rcx
 10251c2:	setae  %al
 10251c5:	test   %rbx,%rbx
 10251c8:	sete   %dl
 10251cb:	or     %al,%dl
 10251cd:	jne    1025190 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x80>
 10251cf:	xor    %r12d,%r12d
 10251d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10251e0:	movzbl (%rcx),%edx
 10251e3:	lea    0x1(%rcx),%rax
 10251e7:	mov    %rax,-0x30(%rbp)
 10251eb:	cmp    $0x2f,%rdx
 10251ef:	ja     10258eb <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x7db>
 10251f5:	lea    -0x1952c(%rip),%rdi        # 100bcd0 <raw_shape+0x1d0>
 10251fc:	movslq (%rdi,%rdx,4),%rsi
 1025200:	add    %rdi,%rsi
 1025203:	jmp    *%rsi
 1025205:	movzbl 0x18(%r14),%ecx
 102520a:	lea    -0x30(%rbp),%rsi
 102520e:	mov    -0x58(%rbp),%rdi
 1025212:	mov    %r13,%rdx
 1025215:	xor    %r8d,%r8d
 1025218:	xor    %r9d,%r9d
 102521b:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1025220:	mov    %rax,%r12
 1025223:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025228:	lea    -0x30(%rbp),%rdi
 102522c:	mov    %r13,%rsi
 102522f:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025234:	mov    -0x30(%rbp),%rsi
 1025238:	mov    $0xfffffffffffffff9,%rdx
 102523f:	xor    %ecx,%ecx
 1025241:	mov    %rsi,%rdi
 1025244:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025250:	cmp    %r13,%rsi
 1025253:	je     1025b91 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa81>
 1025259:	add    $0x7,%rdx
 102525d:	movzbl (%rsi),%r9d
 1025261:	inc    %rsi
 1025264:	mov    %r9d,%r8d
 1025267:	and    $0x7f,%r9d
 102526b:	shlx   %rdx,%r9,%r9
 1025270:	or     %r9,%rcx
 1025273:	inc    %rdi
 1025276:	test   %r8b,%r8b
 1025279:	js     1025250 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x140>
 102527b:	mov    %rdi,-0x30(%rbp)
 102527f:	cmp    $0x21,%rax
 1025283:	jae    1025b09 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x9f9>
 1025289:	lea    0x7(%rdx),%rsi
 102528d:	xor    %edi,%edi
 102528f:	cmp    $0x39,%rdx
 1025293:	mov    $0xffffffffffffffff,%rdx
 102529a:	shlx   %rsi,%rdx,%rdx
 102529f:	cmovae %edi,%edx
 10252a2:	cmp    $0x40,%r8b
 10252a6:	cmovb  %edi,%edx
 10252a9:	or     %edx,%ecx
 10252ab:	imul   0x2c(%r14),%ecx
 10252b0:	mov    -0x40(%rbp),%rdx
 10252b4:	mov    %eax,(%rdx)
 10252b6:	mov    %ecx,0x4(%rdx)
 10252b9:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10252be:	lea    -0x30(%rbp),%rdi
 10252c2:	mov    %r13,%rsi
 10252c5:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10252ca:	cmp    $0x21,%rax
 10252ce:	jae    1025af1 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x9e1>
 10252d4:	mov    -0x30(%rbp),%rdi
 10252d8:	mov    $0xfffffffffffffff9,%rsi
 10252df:	xor    %ecx,%ecx
 10252e1:	mov    %rdi,%rdx
 10252e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10252f0:	cmp    %r13,%rdi
 10252f3:	je     1025b91 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa81>
 10252f9:	add    $0x7,%rsi
 10252fd:	movzbl (%rdi),%r9d
 1025301:	inc    %rdi
 1025304:	mov    %r9d,%r8d
 1025307:	and    $0x7f,%r9d
 102530b:	shlx   %rsi,%r9,%r9
 1025310:	or     %r9,%rcx
 1025313:	inc    %rdx
 1025316:	test   %r8b,%r8b
 1025319:	js     10252f0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x1e0>
 102531b:	lea    0x7(%rsi),%edi
 102531e:	xor    %r9d,%r9d
 1025321:	cmp    $0x39,%rsi
 1025325:	mov    $0xffffffffffffffff,%rsi
 102532c:	shlx   %rdi,%rsi,%rsi
 1025331:	cmovae %r9,%rsi
 1025335:	cmp    $0x40,%r8b
 1025339:	cmovb  %r9,%rsi
 102533d:	mov    %rdx,-0x30(%rbp)
 1025341:	movslq 0x2c(%r14),%rdx
 1025345:	shl    $0x4,%rax
 1025349:	lea    (%r15,%rax,1),%rdi
 102534d:	cmpb   $0x0,0x4(%r15,%rax,1)
 1025353:	jne    102536a <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x25a>
 1025355:	vmovups (%rdi),%xmm0
 1025359:	lea    -0x2a0(%rbp),%r8
 1025360:	vmovups %xmm0,(%r8,%rax,1)
 1025366:	movb   $0x1,0x4(%rdi)
 102536a:	or     %rsi,%rcx
 102536d:	imul   %rdx,%rcx
 1025371:	movl   $0x4,(%rdi)
 1025377:	mov    %rcx,0x8(%rdi)
 102537b:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025380:	lea    -0x30(%rbp),%rdi
 1025384:	mov    %r13,%rsi
 1025387:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102538c:	cmp    $0x21,%rax
 1025390:	jae    1025a0c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8fc>
 1025396:	mov    -0x40(%rbp),%rcx
 102539a:	mov    %eax,(%rcx)
 102539c:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10253a1:	lea    -0x30(%rbp),%rdi
 10253a5:	mov    %r13,%rsi
 10253a8:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10253ad:	mov    -0x40(%rbp),%rcx
 10253b1:	mov    %eax,0x10(%rcx)
 10253b4:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10253b9:	mov    %rsp,%rdi
 10253bc:	lea    -0x230(%rdi),%r14
 10253c3:	mov    %r14,%rsp
 10253c6:	mov    -0x48(%rbp),%rax
 10253ca:	mov    %rax,-0x230(%rdi)
 10253d1:	add    $0xfffffffffffffdd8,%rdi
 10253d8:	mov    $0x228,%edx
 10253dd:	mov    -0x40(%rbp),%rsi
 10253e1:	call   1027520 <memcpy@plt>
 10253e6:	mov    %r14,-0x48(%rbp)
 10253ea:	mov    -0x50(%rbp),%r14
 10253ee:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10253f3:	movzbl 0x1(%rcx),%eax
 10253f7:	imul   0x28(%r14),%eax
 10253fc:	add    %rax,%r12
 10253ff:	add    $0x2,%rcx
 1025403:	mov    %rcx,-0x30(%rbp)
 1025407:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 102540c:	mov    0x28(%r14),%eax
 1025410:	imul   0x1(%rcx),%eax
 1025414:	add    %rax,%r12
 1025417:	add    $0x5,%rcx
 102541b:	mov    %rcx,-0x30(%rbp)
 102541f:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025424:	lea    -0x30(%rbp),%rdi
 1025428:	mov    %r13,%rsi
 102542b:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025430:	cmp    $0x21,%rax
 1025434:	jae    1025a73 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x963>
 102543a:	shl    $0x4,%rax
 102543e:	lea    (%r15,%rax,1),%rcx
 1025442:	cmpb   $0x0,0x4(%r15,%rax,1)
 1025448:	jne    102545e <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x34e>
 102544a:	vmovups (%rcx),%xmm0
 102544e:	lea    -0x2a0(%rbp),%rdx
 1025455:	vmovups %xmm0,(%rdx,%rax,1)
 102545a:	movb   $0x1,0x4(%rcx)
 102545e:	mov    -0x30(%rbp),%rax
 1025462:	movl   $0x7,(%rcx)
 1025468:	jmp    1025874 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x764>
 102546d:	lea    -0x30(%rbp),%r14
 1025471:	mov    %r14,%rdi
 1025474:	mov    %r13,%rsi
 1025477:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102547c:	mov    %rax,%r15
 102547f:	mov    %r14,%rdi
 1025482:	mov    %r13,%rsi
 1025485:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102548a:	cmp    $0x21,%r15
 102548e:	jae    1025ac1 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x9b1>
 1025494:	mov    -0x40(%rbp),%rcx
 1025498:	mov    %r15d,(%rcx)
 102549b:	mov    %eax,0x4(%rcx)
 102549e:	jmp    102571d <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x60d>
 10254a3:	mov    $0xfffffffffffffff9,%rdx
 10254aa:	xor    %ecx,%ecx
 10254ac:	mov    %rax,%rsi
 10254af:	nop
 10254b0:	cmp    %r13,%rsi
 10254b3:	je     1025b91 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa81>
 10254b9:	add    $0x7,%rdx
 10254bd:	movzbl (%rsi),%r8d
 10254c1:	inc    %rsi
 10254c4:	mov    %r8d,%edi
 10254c7:	and    $0x7f,%r8d
 10254cb:	shlx   %rdx,%r8,%r8
 10254d0:	or     %r8,%rcx
 10254d3:	inc    %rax
 10254d6:	test   %dil,%dil
 10254d9:	js     10254b0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x3a0>
 10254db:	lea    0x7(%rdx),%esi
 10254de:	xor    %r8d,%r8d
 10254e1:	cmp    $0x39,%rdx
 10254e5:	mov    $0xffffffffffffffff,%rdx
 10254ec:	shlx   %rsi,%rdx,%rdx
 10254f1:	cmovae %r8d,%edx
 10254f5:	cmp    $0x40,%dil
 10254f9:	cmovb  %r8d,%edx
 10254fd:	or     %edx,%ecx
 10254ff:	mov    %rax,-0x30(%rbp)
 1025503:	imul   0x2c(%r14),%ecx
 1025508:	mov    -0x40(%rbp),%rax
 102550c:	mov    %ecx,0x4(%rax)
 102550f:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025514:	lea    -0x30(%rbp),%r14
 1025518:	mov    %r14,%rdi
 102551b:	mov    %r13,%rsi
 102551e:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025523:	mov    %rax,%r15
 1025526:	mov    %r14,%rdi
 1025529:	mov    %r13,%rsi
 102552c:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025531:	cmp    $0x21,%r15
 1025535:	jae    10259db <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8cb>
 102553b:	mov    -0x50(%rbp),%r14
 102553f:	movslq 0x2c(%r14),%rcx
 1025543:	shl    $0x4,%r15
 1025547:	mov    -0x38(%rbp),%rsi
 102554b:	lea    (%rsi,%r15,1),%rdx
 102554f:	cmpb   $0x0,0x4(%rsi,%r15,1)
 1025555:	je     1025949 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x839>
 102555b:	jmp    102595e <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x84e>
 1025560:	cmpq   $0x0,-0x48(%rbp)
 1025565:	je     1025b50 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa40>
 102556b:	mov    -0x48(%rbp),%r15
 102556f:	lea    0x8(%r15),%rsi
 1025573:	mov    $0x228,%edx
 1025578:	mov    -0x40(%rbp),%rdi
 102557c:	call   1027520 <memcpy@plt>
 1025581:	mov    (%r15),%r15
 1025584:	mov    %r15,-0x48(%rbp)
 1025588:	jmp    102596c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x85c>
 102558d:	movzwl 0x1(%rcx),%eax
 1025591:	imul   0x28(%r14),%eax
 1025596:	add    %rax,%r12
 1025599:	add    $0x3,%rcx
 102559d:	mov    %rcx,-0x30(%rbp)
 10255a1:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10255a6:	lea    -0x30(%rbp),%rdi
 10255aa:	mov    %r13,%rsi
 10255ad:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10255b2:	cmp    $0x21,%rax
 10255b6:	jae    1025a58 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x948>
 10255bc:	mov    %rax,%r15
 10255bf:	lea    -0x30(%rbp),%rdi
 10255c3:	mov    %r13,%rsi
 10255c6:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10255cb:	movslq 0x2c(%r14),%rdx
 10255cf:	shl    $0x4,%r15
 10255d3:	mov    -0x38(%rbp),%rsi
 10255d7:	lea    (%rsi,%r15,1),%rcx
 10255db:	cmpb   $0x0,0x4(%rsi,%r15,1)
 10255e1:	jne    10255f8 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x4e8>
 10255e3:	vmovups (%rcx),%xmm0
 10255e7:	lea    -0x2a0(%rbp),%rsi
 10255ee:	vmovups %xmm0,(%rsi,%r15,1)
 10255f4:	movb   $0x1,0x4(%rcx)
 10255f8:	imul   %rdx,%rax
 10255fc:	neg    %rax
 10255ff:	movl   $0x2,(%rcx)
 1025605:	mov    %rax,0x8(%rcx)
 1025609:	jmp    102596c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x85c>
 102560e:	lea    -0x30(%rbp),%rdi
 1025612:	mov    %r13,%rsi
 1025615:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102561a:	cmp    $0x21,%rax
 102561e:	jae    10259c8 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8b8>
 1025624:	shl    $0x4,%rax
 1025628:	cmpb   $0x1,0x4(%r15,%rax,1)
 102562e:	jne    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025634:	lea    (%r15,%rax,1),%rcx
 1025638:	lea    -0x2a0(%rbp),%rdx
 102563f:	vmovups (%rdx,%rax,1),%xmm0
 1025644:	vmovups %xmm0,(%rcx)
 1025648:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 102564d:	lea    -0x30(%rbp),%rdi
 1025651:	mov    %r13,%rsi
 1025654:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025659:	cmp    $0x21,%rax
 102565d:	jae    10259f6 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8e6>
 1025663:	shl    $0x4,%rax
 1025667:	lea    (%r15,%rax,1),%rcx
 102566b:	cmpb   $0x0,0x4(%r15,%rax,1)
 1025671:	jne    1025687 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x577>
 1025673:	vmovups (%rcx),%xmm0
 1025677:	lea    -0x2a0(%rbp),%rdx
 102567e:	vmovups %xmm0,(%rdx,%rax,1)
 1025683:	movb   $0x1,0x4(%rcx)
 1025687:	movl   $0x1,(%rcx)
 102568d:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025692:	lea    -0x30(%rbp),%rdi
 1025696:	mov    %r13,%rsi
 1025699:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102569e:	mov    -0x40(%rbp),%rcx
 10256a2:	mov    %eax,0x4(%rcx)
 10256a5:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10256aa:	mov    -0x40(%rbp),%rcx
 10256ae:	movl   $0x0,(%rcx)
 10256b4:	jmp    1025874 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x764>
 10256b9:	lea    -0x30(%rbp),%r14
 10256bd:	mov    %r14,%rdi
 10256c0:	mov    %r13,%rsi
 10256c3:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10256c8:	mov    %rax,%r15
 10256cb:	mov    %r14,%rdi
 10256ce:	mov    %r13,%rsi
 10256d1:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10256d6:	cmp    $0x21,%r15
 10256da:	jae    1025aa9 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x999>
 10256e0:	cmp    $0x21,%rax
 10256e4:	jae    1025b21 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa11>
 10256ea:	shl    $0x4,%r15
 10256ee:	mov    -0x38(%rbp),%rdx
 10256f2:	lea    (%rdx,%r15,1),%rcx
 10256f6:	cmpb   $0x0,0x4(%rdx,%r15,1)
 10256fc:	jne    1025713 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x603>
 10256fe:	vmovups (%rcx),%xmm0
 1025702:	lea    -0x2a0(%rbp),%rdx
 1025709:	vmovups %xmm0,(%rdx,%r15,1)
 102570f:	movb   $0x1,0x4(%rcx)
 1025713:	movl   $0x5,(%rcx)
 1025719:	mov    %rax,0x8(%rcx)
 102571d:	mov    -0x50(%rbp),%r14
 1025721:	jmp    102596c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x85c>
 1025726:	lea    -0x30(%rbp),%rdi
 102572a:	mov    %r13,%rsi
 102572d:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025732:	cmp    $0x21,%rax
 1025736:	jae    1025a8e <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x97e>
 102573c:	shl    $0x4,%rax
 1025740:	lea    (%r15,%rax,1),%rcx
 1025744:	cmpb   $0x0,0x4(%r15,%rax,1)
 102574a:	jne    1025760 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x650>
 102574c:	vmovups (%rcx),%xmm0
 1025750:	lea    -0x2a0(%rbp),%rdx
 1025757:	vmovups %xmm0,(%rdx,%rax,1)
 102575c:	movb   $0x1,0x4(%rcx)
 1025760:	movl   $0x0,(%rcx)
 1025766:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 102576b:	lea    -0x30(%rbp),%rdi
 102576f:	mov    %r13,%rsi
 1025772:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025777:	cmp    $0x21,%rax
 102577b:	jae    1025a27 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x917>
 1025781:	mov    -0x30(%rbp),%rdi
 1025785:	mov    $0xfffffffffffffff9,%rsi
 102578c:	xor    %ecx,%ecx
 102578e:	mov    %rdi,%rdx
 1025791:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10257a0:	cmp    %r13,%rdi
 10257a3:	je     1025b91 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa81>
 10257a9:	add    $0x7,%rsi
 10257ad:	movzbl (%rdi),%r9d
 10257b1:	inc    %rdi
 10257b4:	mov    %r9d,%r8d
 10257b7:	and    $0x7f,%r9d
 10257bb:	shlx   %rsi,%r9,%r9
 10257c0:	or     %r9,%rcx
 10257c3:	inc    %rdx
 10257c6:	test   %r8b,%r8b
 10257c9:	js     10257a0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x690>
 10257cb:	lea    0x7(%rsi),%edi
 10257ce:	xor    %r9d,%r9d
 10257d1:	cmp    $0x39,%rsi
 10257d5:	mov    $0xffffffffffffffff,%rsi
 10257dc:	shlx   %rdi,%rsi,%rsi
 10257e1:	cmovae %r9,%rsi
 10257e5:	cmp    $0x40,%r8b
 10257e9:	cmovb  %r9,%rsi
 10257ed:	mov    %rdx,-0x30(%rbp)
 10257f1:	movslq 0x2c(%r14),%rdx
 10257f5:	shl    $0x4,%rax
 10257f9:	lea    (%r15,%rax,1),%rdi
 10257fd:	cmpb   $0x0,0x4(%r15,%rax,1)
 1025803:	jne    102581a <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x70a>
 1025805:	vmovups (%rdi),%xmm0
 1025809:	lea    -0x2a0(%rbp),%r8
 1025810:	vmovups %xmm0,(%r8,%rax,1)
 1025816:	movb   $0x1,0x4(%rdi)
 102581a:	or     %rsi,%rcx
 102581d:	imul   %rdx,%rcx
 1025821:	movl   $0x2,(%rdi)
 1025827:	mov    %rcx,0x8(%rdi)
 102582b:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025830:	lea    -0x30(%rbp),%rdi
 1025834:	mov    %r13,%rsi
 1025837:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102583c:	cmp    $0x21,%rax
 1025840:	jae    1025ad9 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x9c9>
 1025846:	shl    $0x4,%rax
 102584a:	lea    (%r15,%rax,1),%rcx
 102584e:	cmpb   $0x0,0x4(%r15,%rax,1)
 1025854:	jne    102586a <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x75a>
 1025856:	vmovups (%rcx),%xmm0
 102585a:	lea    -0x2a0(%rbp),%rdx
 1025861:	vmovups %xmm0,(%rdx,%rax,1)
 1025866:	movb   $0x1,0x4(%rcx)
 102586a:	mov    -0x30(%rbp),%rax
 102586e:	movl   $0x6,(%rcx)
 1025874:	mov    %rax,0x8(%rcx)
 1025878:	lea    -0x30(%rbp),%rdi
 102587c:	mov    %r13,%rsi
 102587f:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025884:	add    %rax,-0x30(%rbp)
 1025888:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 102588d:	lea    -0x30(%rbp),%rdi
 1025891:	mov    %r13,%rsi
 1025894:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025899:	mov    %rax,%r15
 102589c:	cmp    $0x21,%rax
 10258a0:	jae    1025a42 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x932>
 10258a6:	lea    -0x30(%rbp),%rdi
 10258aa:	mov    %r13,%rsi
 10258ad:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10258b2:	movslq 0x2c(%r14),%rcx
 10258b6:	shl    $0x4,%r15
 10258ba:	mov    -0x38(%rbp),%rsi
 10258be:	lea    (%rsi,%r15,1),%rdx
 10258c2:	cmpb   $0x0,0x4(%rsi,%r15,1)
 10258c8:	jne    10258df <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x7cf>
 10258ca:	vmovups (%rdx),%xmm0
 10258ce:	lea    -0x2a0(%rbp),%rsi
 10258d5:	vmovups %xmm0,(%rsi,%r15,1)
 10258db:	movb   $0x1,0x4(%rdx)
 10258df:	imul   %rcx,%rax
 10258e3:	movl   $0x4,(%rdx)
 10258e9:	jmp    1025968 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x858>
 10258eb:	mov    %edx,%r15d
 10258ee:	and    $0x3f,%r15d
 10258f2:	shr    $0x6,%dl
 10258f5:	movzbl %dl,%eax
 10258f8:	lea    -0x19b6f(%rip),%rcx        # 100bd90 <raw_shape+0x290>
 10258ff:	movslq (%rcx,%rax,4),%rax
 1025903:	add    %rcx,%rax
 1025906:	jmp    *%rax
 1025908:	movzbl %r15b,%eax
 102590c:	imul   0x28(%r14),%eax
 1025911:	add    %rax,%r12
 1025914:	jmp    102596c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x85c>
 1025916:	cmp    $0x21,%r15b
 102591a:	jae    1025b74 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa64>
 1025920:	lea    -0x30(%rbp),%rdi
 1025924:	mov    %r13,%rsi
 1025927:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102592c:	movslq 0x2c(%r14),%rcx
 1025930:	mov    %r15d,%esi
 1025933:	shl    $0x4,%esi
 1025936:	mov    -0x38(%rbp),%rdi
 102593a:	lea    (%rdi,%rsi,1),%rdx
 102593e:	cmpb   $0x0,0x4(%rdi,%rsi,1)
 1025943:	jne    102595e <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x84e>
 1025945:	shl    $0x4,%r15d
 1025949:	vmovups (%rdx),%xmm0
 102594d:	lea    -0x2a0(%rbp),%rsi
 1025954:	vmovups %xmm0,(%rsi,%r15,1)
 102595a:	movb   $0x1,0x4(%rdx)
 102595e:	imul   %rcx,%rax
 1025962:	movl   $0x2,(%rdx)
 1025968:	mov    %rax,0x8(%rdx)
 102596c:	mov    -0x38(%rbp),%r15
 1025970:	mov    -0x30(%rbp),%rcx
 1025974:	cmp    %r13,%rcx
 1025977:	jae    1025190 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x80>
 102597d:	cmp    %rbx,%r12
 1025980:	jb     10251e0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xd0>
 1025986:	jmp    1025190 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x80>
 102598b:	movzbl %r15b,%edx
 102598f:	cmp    $0x21,%dl
 1025992:	jae    1025b61 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa51>
 1025998:	mov    %edx,%eax
 102599a:	shl    $0x4,%eax
 102599d:	mov    -0x38(%rbp),%r15
 10259a1:	cmpb   $0x1,0x4(%r15,%rax,1)
 10259a7:	jne    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10259a9:	add    %r15,%rax
 10259ac:	shl    $0x4,%edx
 10259af:	lea    -0x2a0(%rbp),%rcx
 10259b6:	vmovups (%rcx,%rdx,1),%xmm0
 10259bb:	vmovups %xmm0,(%rax)
 10259bf:	jmp    1025970 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10259c1:	mov    $0x1,%al
 10259c3:	jmp    1025b52 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa42>
 10259c8:	mov    0x31c9(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10259cf:	mov    (%rax),%rcx
 10259d2:	lea    -0x20d5c(%rip),%rdi        # 1004c7d <qbe_empty_registry+0x1125>
 10259d9:	jmp    1025a1d <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x90d>
 10259db:	mov    0x31b6(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10259e2:	mov    (%rax),%rcx
 10259e5:	lea    -0x20db6(%rip),%rdi        # 1004c36 <qbe_empty_registry+0x10de>
 10259ec:	mov    $0x46,%esi
 10259f1:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 10259f6:	mov    0x319b(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 10259fd:	mov    (%rax),%rcx
 1025a00:	lea    -0x20e66(%rip),%rdi        # 1004ba1 <qbe_empty_registry+0x1049>
 1025a07:	jmp    1025b32 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa22>
 1025a0c:	mov    0x3185(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025a13:	mov    (%rax),%rcx
 1025a16:	lea    -0x2109f(%rip),%rdi        # 100497e <qbe_empty_registry+0xe26>
 1025a1d:	mov    $0x47,%esi
 1025a22:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025a27:	mov    0x316a(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025a2e:	mov    (%rax),%rcx
 1025a31:	lea    -0x20f65(%rip),%rdi        # 1004ad3 <qbe_empty_registry+0xf7b>
 1025a38:	mov    $0x49,%esi
 1025a3d:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025a42:	mov    0x314f(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025a49:	mov    (%rax),%rdi
 1025a4c:	lea    -0x20b15(%rip),%rsi        # 1004f3e <qbe_empty_registry+0x13e6>
 1025a53:	jmp    1025b85 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa75>
 1025a58:	mov    0x3139(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025a5f:	mov    (%rax),%rcx
 1025a62:	lea    -0x20e87(%rip),%rdi        # 1004be2 <qbe_empty_registry+0x108a>
 1025a69:	mov    $0x53,%esi
 1025a6e:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025a73:	mov    0x311e(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025a7a:	mov    (%rax),%rcx
 1025a7d:	lea    -0x2107e(%rip),%rdi        # 1004a06 <qbe_empty_registry+0xeae>
 1025a84:	mov    $0x45,%esi
 1025a89:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025a8e:	mov    0x3103(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025a95:	mov    (%rax),%rcx
 1025a98:	lea    -0x20f40(%rip),%rdi        # 1004b5f <qbe_empty_registry+0x1007>
 1025a9f:	mov    $0x41,%esi
 1025aa4:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025aa9:	mov    0x30e8(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025ab0:	mov    (%rax),%rcx
 1025ab3:	lea    -0x210f4(%rip),%rdi        # 10049c6 <qbe_empty_registry+0xe6e>
 1025aba:	mov    $0x3f,%esi
 1025abf:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025ac1:	mov    0x30d0(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025ac8:	mov    (%rax),%rcx
 1025acb:	lea    -0x20e0d(%rip),%rdi        # 1004cc5 <qbe_empty_registry+0x116d>
 1025ad2:	mov    $0x3e,%esi
 1025ad7:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025ad9:	mov    0x30b8(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025ae0:	mov    (%rax),%rcx
 1025ae3:	lea    -0x2109e(%rip),%rdi        # 1004a4c <qbe_empty_registry+0xef4>
 1025aea:	mov    $0x41,%esi
 1025aef:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025af1:	mov    0x30a0(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025af8:	mov    (%rax),%rcx
 1025afb:	lea    -0x21074(%rip),%rdi        # 1004a8e <qbe_empty_registry+0xf36>
 1025b02:	mov    $0x44,%esi
 1025b07:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025b09:	mov    0x3088(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025b10:	mov    (%rax),%rcx
 1025b13:	lea    -0x20ffd(%rip),%rdi        # 1004b1d <qbe_empty_registry+0xfc5>
 1025b1a:	mov    $0x41,%esi
 1025b1f:	jmp    1025b37 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025b21:	mov    0x3070(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025b28:	mov    (%rax),%rcx
 1025b2b:	lea    -0x20e2e(%rip),%rdi        # 1004d04 <qbe_empty_registry+0x11ac>
 1025b32:	mov    $0x40,%esi
 1025b37:	mov    $0x1,%edx
 1025b3c:	call   10275d0 <fwrite@plt>
 1025b41:	mov    0x3050(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025b48:	mov    (%rax),%rdi
 1025b4b:	call   1027680 <fflush@plt>
 1025b50:	xor    %eax,%eax
 1025b52:	lea    -0x28(%rbp),%rsp
 1025b56:	pop    %rbx
 1025b57:	pop    %r12
 1025b59:	pop    %r13
 1025b5b:	pop    %r14
 1025b5d:	pop    %r15
 1025b5f:	pop    %rbp
 1025b60:	ret
 1025b61:	mov    0x3030(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025b68:	mov    (%rax),%rdi
 1025b6b:	lea    -0x20d77(%rip),%rsi        # 1004dfb <qbe_empty_registry+0x12a3>
 1025b72:	jmp    1025b88 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa78>
 1025b74:	mov    0x301d(%rip),%rax        # 1028b98 <stderr@GLIBC_2.2.5>
 1025b7b:	mov    (%rax),%rdi
 1025b7e:	lea    -0x20dd3(%rip),%rsi        # 1004db2 <qbe_empty_registry+0x125a>
 1025b85:	mov    %r15,%rdx
 1025b88:	xor    %eax,%eax
 1025b8a:	call   10275e0 <fprintf@plt>
 1025b8f:	jmp    1025b41 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa31>
 1025b91:	mov    0x3000(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1025b98:	mov    (%rbx),%rdi
 1025b9b:	lea    -0x212d7(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025ba2:	lea    -0x21660(%rip),%rdx        # 1004549 <qbe_empty_registry+0x9f1>
 1025ba9:	lea    -0x21cff(%rip),%rcx        # 1003eb1 <qbe_empty_registry+0x359>
 1025bb0:	xor    %eax,%eax
 1025bb2:	call   10275e0 <fprintf@plt>
 1025bb7:	mov    (%rbx),%rdi
 1025bba:	call   1027680 <fflush@plt>
 1025bbf:	call   1027690 <abort@plt>
 1025bc4:	int3
 1025bc5:	int3
 1025bc6:	int3
 1025bc7:	int3
 1025bc8:	int3
 1025bc9:	int3
 1025bca:	int3
 1025bcb:	int3
 1025bcc:	int3
 1025bcd:	int3
 1025bce:	int3
 1025bcf:	int3

0000000001025bd0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_>:
 1025bd0:	mov    (%rsi),%eax
 1025bd2:	add    $0x2,%eax
 1025bd5:	cmp    $0x12,%eax
 1025bd8:	ja     1025c76 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0xa6>
 1025bde:	lea    -0x19e45(%rip),%rcx        # 100bda0 <raw_shape+0x2a0>
 1025be5:	movslq (%rcx,%rax,4),%rax
 1025be9:	add    %rcx,%rax
 1025bec:	jmp    *%rax
 1025bee:	mov    $0x38,%ecx
 1025bf3:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025bf5:	mov    $0x80,%ecx
 1025bfa:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025bfc:	mov    $0x68,%ecx
 1025c01:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c03:	mov    $0x58,%ecx
 1025c08:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c0a:	mov    $0x40,%ecx
 1025c0f:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c11:	mov    0x8(%rsi),%rax
 1025c15:	mov    %rdi,%rsi
 1025c18:	mov    %rax,%rdi
 1025c1b:	xor    %ecx,%ecx
 1025c1d:	jmp    1026230 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m>
 1025c22:	mov    $0x48,%ecx
 1025c27:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c29:	mov    $0x20,%ecx
 1025c2e:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c30:	mov    $0x60,%ecx
 1025c35:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c37:	mov    $0x8,%ecx
 1025c3c:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c3e:	mov    $0x70,%ecx
 1025c43:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c45:	mov    $0x18,%ecx
 1025c4a:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c4c:	mov    $0x50,%ecx
 1025c51:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c53:	mov    $0x10,%ecx
 1025c58:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c5a:	mov    $0x78,%ecx
 1025c5f:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c61:	mov    $0x30,%ecx
 1025c66:	jmp    1025c6d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025c68:	mov    $0x28,%ecx
 1025c6d:	movslq 0x4(%rsi),%rax
 1025c71:	add    (%rdx,%rcx,1),%rax
 1025c75:	ret
 1025c76:	push   %rbp
 1025c77:	mov    %rsp,%rbp
 1025c7a:	push   %rbx
 1025c7b:	push   %rax
 1025c7c:	mov    0x2f15(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1025c83:	mov    (%rbx),%rdi
 1025c86:	lea    -0x213c2(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025c8d:	lea    -0x21ec7(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 1025c94:	lea    -0x21ef6(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 1025c9b:	xor    %eax,%eax
 1025c9d:	call   10275e0 <fprintf@plt>
 1025ca2:	mov    (%rbx),%rdi
 1025ca5:	call   1027680 <fflush@plt>
 1025caa:	call   1027690 <abort@plt>
 1025caf:	int3

0000000001025cb0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE>:
 1025cb0:	push   %rbp
 1025cb1:	mov    %rsp,%rbp
 1025cb4:	push   %rbx
 1025cb5:	push   %rax
 1025cb6:	mov    %rdx,%rax
 1025cb9:	mov    %rsi,%rdx
 1025cbc:	mov    %rdi,%rsi
 1025cbf:	mov    (%rcx),%edi
 1025cc1:	dec    %edi
 1025cc3:	cmp    $0x6,%edi
 1025cc6:	ja     1025dd3 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x123>
 1025ccc:	lea    -0x19ee7(%rip),%r8        # 100bdec <raw_shape+0x2ec>
 1025cd3:	movslq (%r8,%rdi,4),%rdi
 1025cd7:	add    %r8,%rdi
 1025cda:	jmp    *%rdi
 1025cdc:	mov    0x8(%rcx),%rcx
 1025ce0:	mov    (%rcx,%rax,1),%rax
 1025ce4:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025ce6:	mov    0x8(%rcx),%rdi
 1025cea:	mov    %rax,%rcx
 1025ced:	call   1026230 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m>
 1025cf2:	mov    (%rax),%rax
 1025cf5:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025cf7:	mov    0x8(%rcx),%rdi
 1025cfb:	mov    %rax,%rcx
 1025cfe:	add    $0x8,%rsp
 1025d02:	pop    %rbx
 1025d03:	pop    %rbp
 1025d04:	jmp    1026230 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m>
 1025d09:	xor    %eax,%eax
 1025d0b:	add    $0x8,%rsp
 1025d0f:	pop    %rbx
 1025d10:	pop    %rbp
 1025d11:	ret
 1025d12:	mov    0x8(%rcx),%eax
 1025d15:	add    $0x2,%eax
 1025d18:	cmp    $0x12,%eax
 1025d1b:	ja     1025e06 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x156>
 1025d21:	lea    -0x19f20(%rip),%rcx        # 100be08 <raw_shape+0x308>
 1025d28:	movslq (%rcx,%rax,4),%rax
 1025d2c:	add    %rcx,%rax
 1025d2f:	jmp    *%rax
 1025d31:	add    $0x38,%rdx
 1025d35:	mov    (%rdx),%rax
 1025d38:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d3a:	sub    $0xffffffffffffff80,%rdx
 1025d3e:	mov    (%rdx),%rax
 1025d41:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d43:	add    $0x68,%rdx
 1025d47:	mov    (%rdx),%rax
 1025d4a:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d4c:	add    $0x58,%rdx
 1025d50:	mov    (%rdx),%rax
 1025d53:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d55:	add    $0x40,%rdx
 1025d59:	mov    (%rdx),%rax
 1025d5c:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d5e:	add    $0x18,%rdx
 1025d62:	mov    (%rdx),%rax
 1025d65:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d67:	add    $0x48,%rdx
 1025d6b:	mov    (%rdx),%rax
 1025d6e:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d70:	add    $0x30,%rdx
 1025d74:	mov    (%rdx),%rax
 1025d77:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d79:	add    $0x60,%rdx
 1025d7d:	mov    (%rdx),%rax
 1025d80:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d82:	add    $0x28,%rdx
 1025d86:	mov    (%rdx),%rax
 1025d89:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d8b:	add    $0x70,%rdx
 1025d8f:	mov    (%rdx),%rax
 1025d92:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025d97:	add    $0x10,%rdx
 1025d9b:	mov    (%rdx),%rax
 1025d9e:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025da3:	add    $0x50,%rdx
 1025da7:	mov    (%rdx),%rax
 1025daa:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025daf:	add    $0x8,%rdx
 1025db3:	mov    (%rdx),%rax
 1025db6:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025dbb:	add    $0x78,%rdx
 1025dbf:	mov    (%rdx),%rax
 1025dc2:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025dc7:	add    $0x20,%rdx
 1025dcb:	mov    (%rdx),%rax
 1025dce:	jmp    1025d0b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025dd3:	mov    0x2dbe(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1025dda:	mov    (%rbx),%rdi
 1025ddd:	lea    -0x21519(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025de4:	lea    -0x21ff0(%rip),%rdx        # 1003dfb <qbe_empty_registry+0x2a3>
 1025deb:	lea    -0x22088(%rip),%rcx        # 1003d6a <qbe_empty_registry+0x212>
 1025df2:	xor    %eax,%eax
 1025df4:	call   10275e0 <fprintf@plt>
 1025df9:	mov    (%rbx),%rdi
 1025dfc:	call   1027680 <fflush@plt>
 1025e01:	call   1027690 <abort@plt>
 1025e06:	mov    0x2d8b(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1025e0d:	mov    (%rbx),%rdi
 1025e10:	lea    -0x2154c(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025e17:	lea    -0x22051(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 1025e1e:	lea    -0x22080(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 1025e25:	jmp    1025df2 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x142>
 1025e27:	int3
 1025e28:	int3
 1025e29:	int3
 1025e2a:	int3
 1025e2b:	int3
 1025e2c:	int3
 1025e2d:	int3
 1025e2e:	int3
 1025e2f:	int3

0000000001025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>:
 1025e30:	push   %rbp
 1025e31:	mov    %rsp,%rbp
 1025e34:	push   %r15
 1025e36:	push   %r14
 1025e38:	push   %r12
 1025e3a:	push   %rbx
 1025e3b:	mov    %ecx,%eax
 1025e3d:	and    $0xf,%eax
 1025e40:	cmp    $0xc,%eax
 1025e43:	ja     1025fa9 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x179>
 1025e49:	mov    (%rsi),%rbx
 1025e4c:	lea    -0x19fff(%rip),%rdi        # 100be54 <raw_shape+0x354>
 1025e53:	movslq (%rdi,%rax,4),%rax
 1025e57:	add    %rdi,%rax
 1025e5a:	jmp    *%rax
 1025e5c:	mov    (%rbx),%rax
 1025e5f:	lea    0x8(%rbx),%rdx
 1025e63:	mov    %rdx,(%rsi)
 1025e66:	jmp    1025f24 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xf4>
 1025e6b:	movslq (%rbx),%rax
 1025e6e:	jmp    1025e77 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x47>
 1025e70:	movzwl (%rbx),%eax
 1025e73:	jmp    1025e87 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x57>
 1025e75:	mov    (%rbx),%eax
 1025e77:	lea    0x4(%rbx),%rdx
 1025e7b:	mov    %rdx,(%rsi)
 1025e7e:	jmp    1025f24 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xf4>
 1025e83:	movswq (%rbx),%rax
 1025e87:	lea    0x2(%rbx),%rdx
 1025e8b:	mov    %rdx,(%rsi)
 1025e8e:	jmp    1025f24 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xf4>
 1025e93:	mov    %rsi,%rdi
 1025e96:	mov    %rdx,%rsi
 1025e99:	mov    %r9,%r14
 1025e9c:	mov    %ecx,%r12d
 1025e9f:	mov    %r8,%r15
 1025ea2:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025ea7:	mov    %r15,%r8
 1025eaa:	mov    %r12d,%ecx
 1025ead:	mov    %r14,%r9
 1025eb0:	jmp    1025f24 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xf4>
 1025eb2:	mov    $0xfffffffffffffff9,%r10
 1025eb9:	xor    %eax,%eax
 1025ebb:	mov    %rbx,%rdi
 1025ebe:	mov    %rbx,%r11
 1025ec1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025ed0:	cmp    %rdx,%r11
 1025ed3:	je     1025f76 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x146>
 1025ed9:	add    $0x7,%r10
 1025edd:	movzbl (%r11),%r15d
 1025ee1:	inc    %r11
 1025ee4:	mov    %r15d,%r14d
 1025ee7:	and    $0x7f,%r15d
 1025eeb:	shlx   %r10,%r15,%r15
 1025ef0:	or     %r15,%rax
 1025ef3:	inc    %rdi
 1025ef6:	test   %r14b,%r14b
 1025ef9:	js     1025ed0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xa0>
 1025efb:	lea    0x7(%r10),%edx
 1025eff:	xor    %r11d,%r11d
 1025f02:	cmp    $0x39,%r10
 1025f06:	mov    $0xffffffffffffffff,%r10
 1025f0d:	shlx   %rdx,%r10,%rdx
 1025f12:	cmovae %r11,%rdx
 1025f16:	cmp    $0x40,%r14b
 1025f1a:	cmovb  %r11,%rdx
 1025f1e:	or     %rdx,%rax
 1025f21:	mov    %rdi,(%rsi)
 1025f24:	mov    %ecx,%edx
 1025f26:	shr    $0x4,%edx
 1025f29:	and    $0x7,%edx
 1025f2c:	cmp    $0x5,%edx
 1025f2f:	ja     1025fa9 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x179>
 1025f31:	lea    -0x1a0b0(%rip),%rsi        # 100be88 <raw_shape+0x388>
 1025f38:	movslq (%rsi,%rdx,4),%rdx
 1025f3c:	add    %rsi,%rdx
 1025f3f:	jmp    *%rdx
 1025f41:	add    %rbx,%rax
 1025f44:	test   %cl,%cl
 1025f46:	js     1025f62 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x132>
 1025f48:	test   %r9,%r9
 1025f4b:	je     1025f6d <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x13d>
 1025f4d:	mov    %rbx,(%r9)
 1025f50:	jmp    1025f6d <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x13d>
 1025f52:	test   %r8,%r8
 1025f55:	je     1026030 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x200>
 1025f5b:	add    %r8,%rax
 1025f5e:	test   %cl,%cl
 1025f60:	jns    1025f48 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x118>
 1025f62:	test   %r9,%r9
 1025f65:	je     1025f6a <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x13a>
 1025f67:	mov    %rax,(%r9)
 1025f6a:	mov    (%rax),%rax
 1025f6d:	pop    %rbx
 1025f6e:	pop    %r12
 1025f70:	pop    %r14
 1025f72:	pop    %r15
 1025f74:	pop    %rbp
 1025f75:	ret
 1025f76:	mov    0x2c1b(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1025f7d:	mov    (%rbx),%rdi
 1025f80:	lea    -0x216bc(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025f87:	lea    -0x21a45(%rip),%rdx        # 1004549 <qbe_empty_registry+0x9f1>
 1025f8e:	lea    -0x220e4(%rip),%rcx        # 1003eb1 <qbe_empty_registry+0x359>
 1025f95:	xor    %eax,%eax
 1025f97:	call   10275e0 <fprintf@plt>
 1025f9c:	mov    (%rbx),%rdi
 1025f9f:	call   1027680 <fflush@plt>
 1025fa4:	call   1027690 <abort@plt>
 1025fa9:	mov    0x2be8(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1025fb0:	mov    (%rbx),%rdi
 1025fb3:	lea    -0x216ef(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025fba:	lea    -0x21c1e(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 1025fc1:	lea    -0x21f5f(%rip),%rcx        # 1004069 <qbe_empty_registry+0x511>
 1025fc8:	jmp    1025f95 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 1025fca:	mov    0x2bc7(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1025fd1:	mov    (%rbx),%rdi
 1025fd4:	lea    -0x21710(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025fdb:	lea    -0x21c3f(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 1025fe2:	lea    -0x21e9c(%rip),%rcx        # 100414d <qbe_empty_registry+0x5f5>
 1025fe9:	jmp    1025f95 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 1025feb:	mov    0x2ba6(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1025ff2:	mov    (%rbx),%rdi
 1025ff5:	lea    -0x21731(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025ffc:	lea    -0x21c60(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 1026003:	lea    -0x21e5d(%rip),%rcx        # 10041ad <qbe_empty_registry+0x655>
 102600a:	jmp    1025f95 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 102600c:	mov    0x2b85(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1026013:	mov    (%rbx),%rdi
 1026016:	lea    -0x21752(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 102601d:	lea    -0x21c81(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 1026024:	lea    -0x21eae(%rip),%rcx        # 100417d <qbe_empty_registry+0x625>
 102602b:	jmp    1025f95 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 1026030:	mov    0x2b61(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1026037:	mov    (%rbx),%rdi
 102603a:	lea    -0x21776(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026041:	lea    -0x21ca5(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 1026048:	lea    -0x21a7d(%rip),%rcx        # 10045d2 <qbe_empty_registry+0xa7a>
 102604f:	jmp    1025f95 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 1026054:	int3
 1026055:	int3
 1026056:	int3
 1026057:	int3
 1026058:	int3
 1026059:	int3
 102605a:	int3
 102605b:	int3
 102605c:	int3
 102605d:	int3
 102605e:	int3
 102605f:	int3

0000000001026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>:
 1026060:	push   %rbp
 1026061:	mov    %rsp,%rbp
 1026064:	push   %rbx
 1026065:	push   %rax
 1026066:	mov    (%rdi),%rcx
 1026069:	cmp    %rsi,%rcx
 102606c:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 1026072:	movzbl (%rcx),%eax
 1026075:	mov    %eax,%r8d
 1026078:	and    $0x7f,%eax
 102607b:	lea    0x1(%rcx),%rdx
 102607f:	test   %r8b,%r8b
 1026082:	jns    10261a5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 1026088:	cmp    %rsi,%rdx
 102608b:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 1026091:	movzbl 0x1(%rcx),%edx
 1026095:	mov    %edx,%r8d
 1026098:	and    $0x7f,%edx
 102609b:	shl    $0x7,%edx
 102609e:	or     %rdx,%rax
 10260a1:	lea    0x2(%rcx),%rdx
 10260a5:	test   %r8b,%r8b
 10260a8:	jns    10261a5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 10260ae:	cmp    %rsi,%rdx
 10260b1:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 10260b7:	movzbl 0x2(%rcx),%edx
 10260bb:	mov    %edx,%r8d
 10260be:	and    $0x7f,%edx
 10260c1:	shl    $0xe,%edx
 10260c4:	or     %rdx,%rax
 10260c7:	lea    0x3(%rcx),%rdx
 10260cb:	test   %r8b,%r8b
 10260ce:	jns    10261a5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 10260d4:	cmp    %rsi,%rdx
 10260d7:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 10260dd:	movzbl 0x3(%rcx),%edx
 10260e1:	mov    %edx,%r8d
 10260e4:	and    $0x7f,%edx
 10260e7:	shl    $0x15,%edx
 10260ea:	or     %rdx,%rax
 10260ed:	lea    0x4(%rcx),%rdx
 10260f1:	test   %r8b,%r8b
 10260f4:	jns    10261a5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 10260fa:	cmp    %rsi,%rdx
 10260fd:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 1026103:	movzbl 0x4(%rcx),%edx
 1026107:	mov    %edx,%r8d
 102610a:	and    $0x7f,%edx
 102610d:	shl    $0x1c,%rdx
 1026111:	or     %rdx,%rax
 1026114:	lea    0x5(%rcx),%rdx
 1026118:	test   %r8b,%r8b
 102611b:	jns    10261a5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 1026121:	cmp    %rsi,%rdx
 1026124:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 102612a:	movzbl 0x5(%rcx),%edx
 102612e:	mov    %edx,%r8d
 1026131:	and    $0x7f,%edx
 1026134:	shl    $0x23,%rdx
 1026138:	or     %rdx,%rax
 102613b:	lea    0x6(%rcx),%rdx
 102613f:	test   %r8b,%r8b
 1026142:	jns    10261a5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 1026144:	cmp    %rsi,%rdx
 1026147:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 102614d:	movzbl 0x6(%rcx),%edx
 1026151:	mov    %edx,%r8d
 1026154:	and    $0x7f,%edx
 1026157:	shl    $0x2a,%rdx
 102615b:	or     %rdx,%rax
 102615e:	lea    0x7(%rcx),%rdx
 1026162:	test   %r8b,%r8b
 1026165:	jns    10261a5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 1026167:	cmp    %rsi,%rdx
 102616a:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 102616c:	movzbl 0x7(%rcx),%edx
 1026170:	mov    %edx,%r8d
 1026173:	and    $0x7f,%edx
 1026176:	shl    $0x31,%rdx
 102617a:	or     %rdx,%rax
 102617d:	lea    0x8(%rcx),%rdx
 1026181:	test   %r8b,%r8b
 1026184:	jns    10261a5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 1026186:	cmp    %rsi,%rdx
 1026189:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 102618b:	movzbl 0x8(%rcx),%edx
 102618f:	mov    %edx,%r8d
 1026192:	and    $0x7f,%edx
 1026195:	shl    $0x38,%rdx
 1026199:	or     %rdx,%rax
 102619c:	lea    0x9(%rcx),%rdx
 10261a0:	test   %r8b,%r8b
 10261a3:	js     10261b2 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x152>
 10261a5:	mov    %rdx,%rcx
 10261a8:	mov    %rcx,(%rdi)
 10261ab:	add    $0x8,%rsp
 10261af:	pop    %rbx
 10261b0:	pop    %rbp
 10261b1:	ret
 10261b2:	cmp    %rsi,%rdx
 10261b5:	je     10261d5 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 10261b7:	movzbl (%rdx),%edx
 10261ba:	test   $0x7e,%dl
 10261bd:	jne    1026208 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x1a8>
 10261bf:	add    $0xa,%rcx
 10261c3:	test   %dl,%dl
 10261c5:	js     10261d0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x170>
 10261c7:	shl    $0x3f,%rdx
 10261cb:	or     %rdx,%rax
 10261ce:	jmp    10261a8 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x148>
 10261d0:	cmp    %rsi,%rcx
 10261d3:	jne    1026208 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x1a8>
 10261d5:	mov    0x29bc(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 10261dc:	mov    (%rbx),%rdi
 10261df:	lea    -0x2191b(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10261e6:	lea    -0x21caf(%rip),%rdx        # 100453e <qbe_empty_registry+0x9e6>
 10261ed:	lea    -0x2237d(%rip),%rcx        # 1003e77 <qbe_empty_registry+0x31f>
 10261f4:	xor    %eax,%eax
 10261f6:	call   10275e0 <fprintf@plt>
 10261fb:	mov    (%rbx),%rdi
 10261fe:	call   1027680 <fflush@plt>
 1026203:	call   1027690 <abort@plt>
 1026208:	mov    0x2989(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 102620f:	mov    (%rbx),%rdi
 1026212:	lea    -0x2194e(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026219:	lea    -0x21ce2(%rip),%rdx        # 100453e <qbe_empty_registry+0x9e6>
 1026220:	lea    -0x22393(%rip),%rcx        # 1003e94 <qbe_empty_registry+0x33c>
 1026227:	jmp    10261f4 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x194>
 1026229:	int3
 102622a:	int3
 102622b:	int3
 102622c:	int3
 102622d:	int3
 102622e:	int3
 102622f:	int3

0000000001026230 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m>:
 1026230:	push   %rbp
 1026231:	mov    %rsp,%rbp
 1026234:	push   %r15
 1026236:	push   %r14
 1026238:	push   %r13
 102623a:	push   %r12
 102623c:	push   %rbx
 102623d:	sub    $0x328,%rsp
 1026244:	mov    %rcx,%r15
 1026247:	mov    %rdx,%rbx
 102624a:	mov    %rdi,-0x30(%rbp)
 102624e:	lea    0x14(%rdi),%rsi
 1026252:	lea    -0x30(%rbp),%rdi
 1026256:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102625b:	mov    %rax,%r14
 102625e:	mov    -0x30(%rbp),%rcx
 1026262:	add    %rcx,%r14
 1026265:	mov    %r15,-0x348(%rbp)
 102626c:	cmp    %r14,%rcx
 102626f:	jae    102695f <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x72f>
 1026275:	lea    -0x348(%rbp),%r13
 102627c:	lea    0x78(%rbx),%r10
 1026280:	lea    0x70(%rbx),%r11
 1026284:	lea    0x68(%rbx),%r15
 1026288:	lea    -0x1a3ef(%rip),%r12        # 100bea0 <raw_shape+0x3a0>
 102628f:	jmp    10262b5 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x85>
 1026291:	mov    0x1(%rcx),%rax
 1026295:	add    $0x9,%rcx
 1026299:	mov    %rcx,-0x30(%rbp)
 102629d:	nopl   (%rax)
 10262a0:	mov    %rax,0x8(%r13)
 10262a4:	add    $0x8,%r13
 10262a8:	mov    -0x30(%rbp),%rcx
 10262ac:	cmp    %r14,%rcx
 10262af:	jae    102695b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x72b>
 10262b5:	lea    0x1(%rcx),%rax
 10262b9:	mov    %rax,-0x30(%rbp)
 10262bd:	movzbl (%rcx),%edx
 10262c0:	lea    -0x3(%rdx),%esi
 10262c3:	cmp    $0x91,%esi
 10262c9:	ja     10269e9 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x7b9>
 10262cf:	movslq (%r12,%rsi,4),%rsi
 10262d3:	add    %r12,%rsi
 10262d6:	jmp    *%rsi
 10262d8:	add    $0xffffffd0,%edx
 10262db:	mov    %rdx,0x8(%r13)
 10262df:	jmp    10262a4 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x74>
 10262e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10262f0:	mov    $0xfffffffffffffff9,%rsi
 10262f7:	xor    %ecx,%ecx
 10262f9:	mov    %rax,%rdi
 10262fc:	nopl   0x0(%rax)
 1026300:	cmp    %r14,%rdi
 1026303:	je     1026974 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x744>
 1026309:	add    $0x7,%rsi
 102630d:	movzbl (%rdi),%r9d
 1026311:	inc    %rdi
 1026314:	mov    %r9d,%r8d
 1026317:	and    $0x7f,%r9d
 102631b:	shlx   %rsi,%r9,%r9
 1026320:	or     %r9,%rcx
 1026323:	inc    %rax
 1026326:	test   %r8b,%r8b
 1026329:	js     1026300 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0xd0>
 102632b:	lea    0x7(%rsi),%edi
 102632e:	xor    %r9d,%r9d
 1026331:	cmp    $0x39,%rsi
 1026335:	mov    $0xffffffffffffffff,%rsi
 102633c:	shlx   %rdi,%rsi,%rsi
 1026341:	cmovae %r9,%rsi
 1026345:	cmp    $0x40,%r8b
 1026349:	cmovb  %r9,%rsi
 102634d:	mov    %rax,-0x30(%rbp)
 1026351:	add    $0xffffff92,%edx
 1026354:	cmp    $0x12,%edx
 1026357:	ja     10269a7 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x777>
 102635d:	or     %rsi,%rcx
 1026360:	lea    -0x1a223(%rip),%rax        # 100c144 <raw_shape+0x644>
 1026367:	movslq (%rax,%rdx,4),%rdx
 102636b:	add    %rax,%rdx
 102636e:	mov    %rbx,%rax
 1026371:	jmp    *%rdx
 1026373:	lea    0x38(%rbx),%rax
 1026377:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 102637c:	nopl   0x0(%rax)
 1026380:	add    $0xffffffb0,%edx
 1026383:	cmp    $0x10,%edx
 1026386:	ja     10269a7 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x777>
 102638c:	lea    -0x1a1b7(%rip),%rax        # 100c1dc <raw_shape+0x6dc>
 1026393:	movslq (%rax,%rdx,4),%rcx
 1026397:	add    %rax,%rcx
 102639a:	mov    %rbx,%rax
 102639d:	jmp    *%rcx
 102639f:	lea    0x18(%rbx),%rax
 10263a3:	mov    (%rax),%rax
 10263a6:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10263ab:	mov    %r10,%r15
 10263ae:	lea    -0x30(%rbp),%rdi
 10263b2:	mov    %r14,%rsi
 10263b5:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10263ba:	mov    -0x30(%rbp),%rdi
 10263be:	mov    $0xfffffffffffffff9,%rsi
 10263c5:	xor    %ecx,%ecx
 10263c7:	mov    %rdi,%rdx
 10263ca:	nopw   0x0(%rax,%rax,1)
 10263d0:	cmp    %r14,%rdi
 10263d3:	je     1026974 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x744>
 10263d9:	add    $0x7,%rsi
 10263dd:	movzbl (%rdi),%r9d
 10263e1:	inc    %rdi
 10263e4:	mov    %r9d,%r8d
 10263e7:	and    $0x7f,%r9d
 10263eb:	shlx   %rsi,%r9,%r9
 10263f0:	or     %r9,%rcx
 10263f3:	inc    %rdx
 10263f6:	test   %r8b,%r8b
 10263f9:	js     10263d0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x1a0>
 10263fb:	lea    0x7(%rsi),%edi
 10263fe:	xor    %r9d,%r9d
 1026401:	cmp    $0x39,%rsi
 1026405:	mov    $0xffffffffffffffff,%rsi
 102640c:	shlx   %rdi,%rsi,%rsi
 1026411:	cmovae %r9,%rsi
 1026415:	cmp    $0x40,%r8b
 1026419:	cmovb  %r9,%rsi
 102641d:	mov    %rdx,-0x30(%rbp)
 1026421:	add    $0x2,%eax
 1026424:	cmp    $0x12,%eax
 1026427:	ja     10269a7 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x777>
 102642d:	mov    %r15,%r10
 1026430:	or     %rsi,%rcx
 1026433:	lea    -0x1a342(%rip),%rdx        # 100c0f8 <raw_shape+0x5f8>
 102643a:	movslq (%rdx,%rax,4),%rsi
 102643e:	add    %rdx,%rsi
 1026441:	mov    %rbx,%rax
 1026444:	lea    0x70(%rbx),%r11
 1026448:	lea    0x68(%rbx),%r15
 102644c:	jmp    *%rsi
 102644e:	lea    0x80(%rbx),%rax
 1026455:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026457:	mov    %r15,%rax
 102645a:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 102645c:	lea    0x58(%rbx),%rax
 1026460:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026462:	lea    0x40(%rbx),%rax
 1026466:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026468:	lea    0x48(%rbx),%rax
 102646c:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 102646e:	lea    0x20(%rbx),%rax
 1026472:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026474:	lea    0x60(%rbx),%rax
 1026478:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 102647a:	lea    0x8(%rbx),%rax
 102647e:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026480:	mov    %r11,%rax
 1026483:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026485:	lea    0x18(%rbx),%rax
 1026489:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 102648b:	lea    0x50(%rbx),%rax
 102648f:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026491:	lea    0x10(%rbx),%rax
 1026495:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026497:	mov    %r10,%rax
 102649a:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 102649c:	lea    0x30(%rbx),%rax
 10264a0:	jmp    10264b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10264a2:	lea    0x28(%rbx),%rax
 10264a6:	cs nopw 0x0(%rax,%rax,1)
 10264b0:	add    (%rax),%rcx
 10264b3:	mov    %rcx,0x8(%r13)
 10264b7:	jmp    10262a4 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x74>
 10264bc:	mov    -0x8(%r13),%rax
 10264c0:	xor    %ecx,%ecx
 10264c2:	cmp    0x0(%r13),%rax
 10264c6:	setb   %cl
 10264c9:	jmp    1026818 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 10264ce:	mov    -0x8(%r13),%rax
 10264d2:	xor    %ecx,%ecx
 10264d4:	cmp    0x0(%r13),%rax
 10264d8:	setbe  %cl
 10264db:	jmp    1026818 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 10264e0:	lea    -0x8(%r13),%rcx
 10264e4:	mov    -0x8(%r13),%rax
 10264e8:	mov    0x0(%r13),%rsi
 10264ec:	mov    %rax,%rdx
 10264ef:	or     %rsi,%rdx
 10264f2:	shr    $0x20,%rdx
 10264f6:	je     102691e <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x6ee>
 10264fc:	cqto
 10264fe:	idiv   %rsi
 1026501:	jmp    1026922 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x6f2>
 1026506:	mov    -0x8(%r13),%rax
 102650a:	xor    %ecx,%ecx
 102650c:	cmp    0x0(%r13),%rax
 1026510:	sete   %cl
 1026513:	jmp    1026818 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 1026518:	movswq 0x1(%rcx),%rax
 102651d:	add    $0x3,%rcx
 1026521:	jmp    1026299 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 1026526:	movswq 0x1(%rcx),%rax
 102652b:	add    $0x3,%rcx
 102652f:	mov    %rcx,-0x30(%rbp)
 1026533:	lea    -0x8(%r13),%rdx
 1026537:	cmpq   $0x0,0x0(%r13)
 102653c:	je     102692d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x6fd>
 1026542:	add    %rax,%rcx
 1026545:	mov    %rcx,-0x30(%rbp)
 1026549:	mov    %rdx,%r13
 102654c:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026551:	mov    -0x8(%r13),%rax
 1026555:	xor    %ecx,%ecx
 1026557:	cmp    0x0(%r13),%rax
 102655b:	setae  %cl
 102655e:	jmp    1026818 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 1026563:	mov    $0xfffffffffffffff9,%rdx
 102656a:	xor    %ecx,%ecx
 102656c:	mov    %rax,%rsi
 102656f:	nop
 1026570:	cmp    %r14,%rsi
 1026573:	je     1026974 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x744>
 1026579:	add    $0x7,%rdx
 102657d:	movzbl (%rsi),%r8d
 1026581:	inc    %rsi
 1026584:	mov    %r8d,%edi
 1026587:	and    $0x7f,%r8d
 102658b:	shlx   %rdx,%r8,%r8
 1026590:	or     %r8,%rcx
 1026593:	inc    %rax
 1026596:	test   %dil,%dil
 1026599:	js     1026570 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x340>
 102659b:	lea    0x7(%rdx),%esi
 102659e:	xor    %r8d,%r8d
 10265a1:	cmp    $0x39,%rdx
 10265a5:	mov    $0xffffffffffffffff,%rdx
 10265ac:	shlx   %rsi,%rdx,%rdx
 10265b1:	cmovae %r8,%rdx
 10265b5:	cmp    $0x40,%dil
 10265b9:	cmovb  %r8,%rdx
 10265bd:	or     %rdx,%rcx
 10265c0:	mov    %rax,-0x30(%rbp)
 10265c4:	jmp    10264b3 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x283>
 10265c9:	mov    0x0(%r13),%rax
 10265cd:	and    %rax,-0x8(%r13)
 10265d1:	add    $0xfffffffffffffff8,%r13
 10265d5:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10265da:	mov    -0x8(%r13),%rax
 10265de:	xor    %ecx,%ecx
 10265e0:	cmp    0x0(%r13),%rax
 10265e4:	seta   %cl
 10265e7:	jmp    1026818 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 10265ec:	movslq 0x1(%rcx),%rax
 10265f0:	add    $0x5,%rcx
 10265f4:	jmp    1026299 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 10265f9:	mov    0x0(%r13),%rax
 10265fd:	xor    %rax,-0x8(%r13)
 1026601:	add    $0xfffffffffffffff8,%r13
 1026605:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102660a:	mov    0x0(%r13),%rax
 102660e:	test   %rax,%rax
 1026611:	jns    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026617:	neg    %rax
 102661a:	mov    %rax,0x0(%r13)
 102661e:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026623:	movsbq 0x1(%rcx),%rax
 1026628:	jmp    1026662 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x432>
 102662a:	mov    0x0(%r13),%rax
 102662e:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026633:	lea    -0x30(%rbp),%rdi
 1026637:	mov    %r14,%rsi
 102663a:	mov    %r10,%r15
 102663d:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1026642:	mov    %r15,%r10
 1026645:	lea    0x68(%rbx),%r15
 1026649:	lea    0x70(%rbx),%r11
 102664d:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026652:	mov    0x1(%rcx),%eax
 1026655:	add    $0x5,%rcx
 1026659:	jmp    1026299 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 102665e:	movzbl 0x1(%rcx),%eax
 1026662:	add    $0x2,%rcx
 1026666:	jmp    1026299 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 102666b:	add    $0xfffffffffffffff8,%r13
 102666f:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026674:	movzwl 0x1(%rcx),%eax
 1026678:	add    $0x3,%rcx
 102667c:	jmp    1026299 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 1026681:	mov    0x0(%r13),%rax
 1026685:	mov    (%rax),%rax
 1026688:	mov    %rax,0x0(%r13)
 102668c:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026691:	mov    0x0(%r13),%rax
 1026695:	vmovups -0x10(%r13),%xmm0
 102669b:	vmovups %xmm0,-0x8(%r13)
 10266a1:	mov    %rax,-0x10(%r13)
 10266a5:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10266aa:	lea    -0x8(%r13),%rcx
 10266ae:	mov    -0x8(%r13),%rax
 10266b2:	mov    0x0(%r13),%rsi
 10266b6:	mov    %rax,%rdx
 10266b9:	or     %rsi,%rdx
 10266bc:	shr    $0x20,%rdx
 10266c0:	je     1026935 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x705>
 10266c6:	cqto
 10266c8:	idiv   %rsi
 10266cb:	jmp    1026939 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x709>
 10266d0:	mov    -0x8(%r13),%rax
 10266d4:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10266d9:	vpshufd $0x4e,-0x8(%r13),%xmm0
 10266e0:	vmovups %xmm0,-0x8(%r13)
 10266e6:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10266eb:	movzbl 0x1(%rcx),%eax
 10266ef:	add    $0x2,%rcx
 10266f3:	mov    %rcx,-0x30(%rbp)
 10266f7:	shl    $0x3,%eax
 10266fa:	mov    %r13,%rcx
 10266fd:	sub    %rax,%rcx
 1026700:	mov    (%rcx),%rax
 1026703:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026708:	notq   0x0(%r13)
 102670c:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026711:	movzbl 0x0(%r13),%ecx
 1026716:	shlq   %cl,-0x8(%r13)
 102671a:	add    $0xfffffffffffffff8,%r13
 102671e:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026723:	movzbl 0x0(%r13),%ecx
 1026728:	shrq   %cl,-0x8(%r13)
 102672c:	add    $0xfffffffffffffff8,%r13
 1026730:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026735:	mov    0x0(%r13),%rax
 1026739:	add    %rax,-0x8(%r13)
 102673d:	add    $0xfffffffffffffff8,%r13
 1026741:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026746:	mov    0x0(%r13),%rax
 102674a:	lea    0x2(%rcx),%rdx
 102674e:	mov    %rdx,-0x30(%rbp)
 1026752:	movzbl 0x1(%rcx),%ecx
 1026756:	popcnt %ecx,%edx
 102675a:	cmp    $0x1,%edx
 102675d:	jne    10269c8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x798>
 1026763:	tzcnt  %ecx,%ecx
 1026767:	cmp    $0x3,%ecx
 102676a:	ja     10269c8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x798>
 1026770:	lea    -0x1a68f(%rip),%rdx        # 100c0e8 <raw_shape+0x5e8>
 1026777:	movslq (%rdx,%rcx,4),%rcx
 102677b:	add    %rdx,%rcx
 102677e:	jmp    *%rcx
 1026780:	movzbl (%rax),%eax
 1026783:	mov    %rax,0x0(%r13)
 1026787:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102678c:	lea    -0x30(%rbp),%rdi
 1026790:	mov    %r14,%rsi
 1026793:	mov    %r10,%r15
 1026796:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102679b:	mov    %r15,%r10
 102679e:	lea    0x68(%rbx),%r15
 10267a2:	lea    0x70(%rbx),%r11
 10267a6:	add    %rax,0x0(%r13)
 10267aa:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10267af:	movzbl 0x0(%r13),%ecx
 10267b4:	sarq   %cl,-0x8(%r13)
 10267b8:	add    $0xfffffffffffffff8,%r13
 10267bc:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10267c1:	mov    0x0(%r13),%rax
 10267c5:	mov    (%rax),%rax
 10267c8:	jmp    10267d3 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5a3>
 10267ca:	mov    -0x8(%r13),%rax
 10267ce:	imul   0x0(%r13),%rax
 10267d3:	mov    %rax,-0x8(%r13)
 10267d7:	add    $0xfffffffffffffff8,%r13
 10267db:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10267e0:	mov    0x0(%r13),%rax
 10267e4:	sub    %rax,-0x8(%r13)
 10267e8:	add    $0xfffffffffffffff8,%r13
 10267ec:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10267f1:	mov    0x0(%r13),%rax
 10267f5:	or     %rax,-0x8(%r13)
 10267f9:	add    $0xfffffffffffffff8,%r13
 10267fd:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026802:	negq   0x0(%r13)
 1026806:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102680b:	mov    -0x8(%r13),%rax
 102680f:	xor    %ecx,%ecx
 1026811:	cmp    0x0(%r13),%rax
 1026815:	setne  %cl
 1026818:	mov    %rcx,-0x8(%r13)
 102681c:	add    $0xfffffffffffffff8,%r13
 1026820:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026825:	movswq 0x1(%rcx),%rax
 102682a:	add    %rcx,%rax
 102682d:	add    $0x3,%rax
 1026831:	mov    %rax,-0x30(%rbp)
 1026835:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102683a:	mov    %r10,%r15
 102683d:	lea    -0x30(%rbp),%rdi
 1026841:	mov    %r14,%rsi
 1026844:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1026849:	add    $0x2,%eax
 102684c:	cmp    $0x12,%eax
 102684f:	ja     10269a7 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x777>
 1026855:	lea    -0x1a6cc(%rip),%rcx        # 100c190 <raw_shape+0x690>
 102685c:	movslq (%rcx,%rax,4),%rdx
 1026860:	add    %rcx,%rdx
 1026863:	mov    %rbx,%rax
 1026866:	mov    %r15,%r10
 1026869:	lea    0x70(%rbx),%r11
 102686d:	lea    0x68(%rbx),%r15
 1026871:	jmp    *%rdx
 1026873:	lea    0x38(%rbx),%rax
 1026877:	mov    (%rax),%rax
 102687a:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 102687f:	lea    0x80(%rbx),%rax
 1026886:	mov    (%rax),%rax
 1026889:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 102688e:	mov    (%r11),%rax
 1026891:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026896:	lea    0x58(%rbx),%rax
 102689a:	mov    (%rax),%rax
 102689d:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268a2:	lea    0x28(%rbx),%rax
 10268a6:	mov    (%rax),%rax
 10268a9:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268ae:	lea    0x60(%rbx),%rax
 10268b2:	mov    (%rax),%rax
 10268b5:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268ba:	lea    0x48(%rbx),%rax
 10268be:	mov    (%rax),%rax
 10268c1:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268c6:	lea    0x10(%rbx),%rax
 10268ca:	mov    (%rax),%rax
 10268cd:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268d2:	mov    (%r10),%rax
 10268d5:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268da:	lea    0x8(%rbx),%rax
 10268de:	mov    (%rax),%rax
 10268e1:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268e6:	mov    (%r15),%rax
 10268e9:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268ee:	lea    0x20(%rbx),%rax
 10268f2:	mov    (%rax),%rax
 10268f5:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10268fa:	lea    0x30(%rbx),%rax
 10268fe:	mov    (%rax),%rax
 1026901:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026906:	lea    0x40(%rbx),%rax
 102690a:	mov    (%rax),%rax
 102690d:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026912:	lea    0x50(%rbx),%rax
 1026916:	mov    (%rax),%rax
 1026919:	jmp    10262a0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 102691e:	xor    %edx,%edx
 1026920:	div    %esi
 1026922:	mov    %rdx,(%rcx)
 1026925:	mov    %rcx,%r13
 1026928:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102692d:	mov    %rdx,%r13
 1026930:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026935:	xor    %edx,%edx
 1026937:	div    %esi
 1026939:	mov    %rax,(%rcx)
 102693c:	mov    %rcx,%r13
 102693f:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026944:	movzwl (%rax),%eax
 1026947:	mov    %rax,0x0(%r13)
 102694b:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026950:	mov    (%rax),%eax
 1026952:	mov    %rax,0x0(%r13)
 1026956:	jmp    10262a8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102695b:	mov    0x0(%r13),%r15
 102695f:	mov    %r15,%rax
 1026962:	add    $0x328,%rsp
 1026969:	pop    %rbx
 102696a:	pop    %r12
 102696c:	pop    %r13
 102696e:	pop    %r14
 1026970:	pop    %r15
 1026972:	pop    %rbp
 1026973:	ret
 1026974:	mov    0x221d(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 102697b:	mov    (%rbx),%rdi
 102697e:	lea    -0x220ba(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026985:	lea    -0x22443(%rip),%rdx        # 1004549 <qbe_empty_registry+0x9f1>
 102698c:	lea    -0x22ae2(%rip),%rcx        # 1003eb1 <qbe_empty_registry+0x359>
 1026993:	xor    %eax,%eax
 1026995:	call   10275e0 <fprintf@plt>
 102699a:	mov    (%rbx),%rdi
 102699d:	call   1027680 <fflush@plt>
 10269a2:	call   1027690 <abort@plt>
 10269a7:	mov    0x21ea(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 10269ae:	mov    (%rbx),%rdi
 10269b1:	lea    -0x220ed(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10269b8:	lea    -0x22bf2(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 10269bf:	lea    -0x22c21(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 10269c6:	jmp    1026993 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 10269c8:	mov    0x21c9(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 10269cf:	mov    (%rbx),%rdi
 10269d2:	lea    -0x2210e(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10269d9:	lea    -0x22b12(%rip),%rdx        # 1003ece <qbe_empty_registry+0x376>
 10269e0:	lea    -0x22965(%rip),%rcx        # 1004082 <qbe_empty_registry+0x52a>
 10269e7:	jmp    1026993 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 10269e9:	mov    0x21a8(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 10269f0:	mov    (%rbx),%rdi
 10269f3:	lea    -0x2212f(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10269fa:	lea    -0x22b33(%rip),%rdx        # 1003ece <qbe_empty_registry+0x376>
 1026a01:	lea    -0x2280f(%rip),%rcx        # 10041f9 <qbe_empty_registry+0x6a1>
 1026a08:	jmp    1026993 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 1026a0a:	mov    0x2187(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1026a11:	mov    (%rbx),%rdi
 1026a14:	lea    -0x22150(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026a1b:	lea    -0x22b54(%rip),%rdx        # 1003ece <qbe_empty_registry+0x376>
 1026a22:	lea    -0x22813(%rip),%rcx        # 1004216 <qbe_empty_registry+0x6be>
 1026a29:	jmp    1026993 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 1026a2e:	mov    0x2163(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1026a35:	mov    (%rbx),%rdi
 1026a38:	lea    -0x22174(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026a3f:	lea    -0x22b78(%rip),%rdx        # 1003ece <qbe_empty_registry+0x376>
 1026a46:	lea    -0x22870(%rip),%rcx        # 10041dd <qbe_empty_registry+0x685>
 1026a4d:	jmp    1026993 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 1026a52:	int3
 1026a53:	int3
 1026a54:	int3
 1026a55:	int3
 1026a56:	int3
 1026a57:	int3
 1026a58:	int3
 1026a59:	int3
 1026a5a:	int3
 1026a5b:	int3
 1026a5c:	int3
 1026a5d:	int3
 1026a5e:	int3
 1026a5f:	int3

0000000001026a60 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj>:
 1026a60:	push   %rbp
 1026a61:	mov    %rsp,%rbp
 1026a64:	push   %r15
 1026a66:	push   %r14
 1026a68:	push   %r13
 1026a6a:	push   %r12
 1026a6c:	push   %rbx
 1026a6d:	sub    $0x2b8,%rsp
 1026a74:	mov    %rdx,%rbx
 1026a77:	mov    %rsi,%r12
 1026a7a:	mov    %rdi,%r14
 1026a7d:	mov    %ecx,-0x30(%rbp)
 1026a80:	test   %ecx,%ecx
 1026a82:	je     1026ab9 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x59>
 1026a84:	mov    0x8(%r14),%rdi
 1026a88:	mov    0x10(%rbx),%rdx
 1026a8c:	mov    0x18(%rbx),%rcx
 1026a90:	mov    -0x30(%rbp),%r8d
 1026a94:	add    %rdx,%r8
 1026a97:	lea    -0xb0(%rbp),%rax
 1026a9e:	mov    %rax,(%rsp)
 1026aa2:	lea    -0x78(%rbp),%r9
 1026aa6:	mov    %r12,%rsi
 1026aa9:	call   1026f90 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE>
 1026aae:	mov    $0x1,%r15b
 1026ab1:	test   %al,%al
 1026ab3:	jne    1026bb4 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x154>
 1026ab9:	mov    0x20(%rbx),%rdx
 1026abd:	test   %rdx,%rdx
 1026ac0:	je     1026ae7 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x87>
 1026ac2:	mov    0x8(%r14),%rdi
 1026ac6:	mov    0x28(%rbx),%ecx
 1026ac9:	lea    -0x78(%rbp),%r8
 1026acd:	lea    -0xb0(%rbp),%r9
 1026ad4:	mov    %r12,%rsi
 1026ad7:	call   1027180 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE>
 1026adc:	mov    $0x1,%r15b
 1026adf:	test   %al,%al
 1026ae1:	jne    1026bb4 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x154>
 1026ae7:	mov    (%rbx),%r15
 1026aea:	lea    0x4cff(%rip),%rdi        # 102b7f0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026af1:	call   1027960 <pthread_rwlock_rdlock@plt>
 1026af6:	mov    0x4c93(%rip),%rax        # 102b790 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE7_bufferE>
 1026afd:	mov    0x4c94(%rip),%rcx        # 102b798 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE11_bufferUsedE>
 1026b04:	cmp    %rcx,%rax
 1026b07:	jae    1026b74 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x114>
 1026b09:	mov    (%r12),%rdx
 1026b0d:	jmp    1026b19 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xb9>
 1026b0f:	nop
 1026b10:	add    $0x20,%rax
 1026b14:	cmp    %rcx,%rax
 1026b17:	jae    1026b74 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x114>
 1026b19:	cmp    $0xffffffffffffffff,%r15
 1026b1d:	je     1026b24 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xc4>
 1026b1f:	cmp    (%rax),%r15
 1026b22:	jne    1026b10 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xb0>
 1026b24:	cmp    %rdx,0x8(%rax)
 1026b28:	ja     1026b10 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xb0>
 1026b2a:	cmp    0x10(%rax),%rdx
 1026b2e:	jae    1026b10 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xb0>
 1026b30:	mov    0x18(%rax),%r13
 1026b34:	lea    0x4cb5(%rip),%rdi        # 102b7f0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026b3b:	call   1027920 <pthread_rwlock_unlock@plt>
 1026b40:	test   %r13,%r13
 1026b43:	je     1026b80 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x120>
 1026b45:	mov    0x8(%r14),%rdi
 1026b49:	mov    0x10(%rbx),%rdx
 1026b4d:	mov    0x18(%rbx),%rcx
 1026b51:	lea    -0xb0(%rbp),%rax
 1026b58:	mov    %rax,(%rsp)
 1026b5c:	lea    -0x78(%rbp),%r9
 1026b60:	mov    %r12,%rsi
 1026b63:	mov    %r13,%r8
 1026b66:	call   1026f90 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE>
 1026b6b:	test   %al,%al
 1026b6d:	je     1026b80 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x120>
 1026b6f:	xor    %r15d,%r15d
 1026b72:	jmp    1026bb4 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x154>
 1026b74:	lea    0x4c75(%rip),%rdi        # 102b7f0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026b7b:	call   1027920 <pthread_rwlock_unlock@plt>
 1026b80:	mov    0x8(%r14),%rdi
 1026b84:	mov    0x10(%rbx),%rdx
 1026b88:	mov    0x18(%rbx),%rcx
 1026b8c:	lea    -0xb0(%rbp),%rax
 1026b93:	mov    %rax,(%rsp)
 1026b97:	xor    %r13d,%r13d
 1026b9a:	lea    -0x78(%rbp),%r9
 1026b9e:	mov    %r12,%rsi
 1026ba1:	xor    %r8d,%r8d
 1026ba4:	call   1026f90 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE>
 1026ba9:	mov    $0x1,%r15b
 1026bac:	test   %al,%al
 1026bae:	je     1026d51 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2f1>
 1026bb4:	mov    (%rbx),%rax
 1026bb7:	mov    %rax,-0x38(%rbp)
 1026bbb:	lea    -0x2d8(%rbp),%r13
 1026bc2:	mov    $0x228,%edx
 1026bc7:	mov    %r13,%rdi
 1026bca:	xor    %esi,%esi
 1026bcc:	call   10274d0 <memset@plt>
 1026bd1:	mov    0x8(%r14),%rdi
 1026bd5:	lea    -0x78(%rbp),%rsi
 1026bd9:	lea    -0xb0(%rbp),%rdx
 1026be0:	mov    %r12,%rcx
 1026be3:	mov    $0x1,%r8d
 1026be9:	mov    %r13,%r9
 1026bec:	call   1025110 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE>
 1026bf1:	test   %al,%al
 1026bf3:	je     1026d4e <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2ee>
 1026bf9:	cmpl   $0x0,-0x30(%rbp)
 1026bfd:	setne  %al
 1026c00:	mov    -0x60(%rbp),%rdx
 1026c04:	mov    %rdx,0xb8(%r14)
 1026c0b:	vmovups -0x58(%rbp),%xmm0
 1026c10:	mov    -0x58(%rbp),%rsi
 1026c14:	vmovups %xmm0,0xc0(%r14)
 1026c1d:	mov    -0x90(%rbp),%rcx
 1026c24:	mov    %rcx,0xd0(%r14)
 1026c2b:	mov    -0x2c8(%rbp),%ecx
 1026c31:	mov    %rcx,0xd8(%r14)
 1026c38:	movq   $0x0,0xe0(%r14)
 1026c43:	movl   $0x4000000,0xe8(%r14)
 1026c4e:	mov    -0x78(%rbp),%r12
 1026c52:	mov    %r12,0xf0(%r14)
 1026c59:	mov    -0x70(%rbp),%ecx
 1026c5c:	mov    %ecx,0xec(%r14)
 1026c63:	mov    -0x38(%rbp),%rcx
 1026c67:	mov    %rcx,0xf8(%r14)
 1026c6e:	xor    $0x1,%r15b
 1026c72:	mov    $0x1,%r13b
 1026c75:	or     %al,%r15b
 1026c78:	jne    1026d51 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2f1>
 1026c7e:	cmpq   $0x0,0x20(%rbx)
 1026c83:	jne    1026d51 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2f1>
 1026c89:	mov    %rsi,-0x38(%rbp)
 1026c8d:	mov    %rdx,-0x30(%rbp)
 1026c91:	mov    (%rbx),%r14
 1026c94:	lea    0x4b55(%rip),%rdi        # 102b7f0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026c9b:	call   1027910 <pthread_rwlock_wrlock@plt>
 1026ca0:	mov    0x4af1(%rip),%rax        # 102b798 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE11_bufferUsedE>
 1026ca7:	mov    0x4af2(%rip),%rbx        # 102b7a0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE10_bufferEndE>
 1026cae:	cmp    %rbx,%rax
 1026cb1:	jb     1026d1e <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2be>
 1026cb3:	mov    %r14,-0x48(%rbp)
 1026cb7:	mov    0x4ad2(%rip),%r15        # 102b790 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE7_bufferE>
 1026cbe:	sub    %r15,%rbx
 1026cc1:	mov    %rbx,%r14
 1026cc4:	sar    $0x3,%r14
 1026cc8:	lea    0x0(,%rbx,4),%rdi
 1026cd0:	call   1027500 <malloc@plt>
 1026cd5:	mov    %rax,-0x40(%rbp)
 1026cd9:	mov    %rax,%rdi
 1026cdc:	mov    %r15,%rsi
 1026cdf:	mov    %rbx,%rdx
 1026ce2:	call   1027520 <memcpy@plt>
 1026ce7:	lea    0x4b42(%rip),%rax        # 102b830 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE14_initialBufferE>
 1026cee:	cmp    %rax,%r15
 1026cf1:	je     1026cfb <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x29b>
 1026cf3:	mov    %r15,%rdi
 1026cf6:	call   1027570 <free@plt>
 1026cfb:	mov    -0x40(%rbp),%rax
 1026cff:	mov    %rax,0x4a8a(%rip)        # 102b790 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE7_bufferE>
 1026d06:	add    %rax,%rbx
 1026d09:	shl    $0x5,%r14
 1026d0d:	add    %rax,%r14
 1026d10:	mov    %r14,0x4a89(%rip)        # 102b7a0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE10_bufferEndE>
 1026d17:	mov    %rbx,%rax
 1026d1a:	mov    -0x48(%rbp),%r14
 1026d1e:	mov    %r14,(%rax)
 1026d21:	mov    -0x30(%rbp),%rcx
 1026d25:	mov    %rcx,0x8(%rax)
 1026d29:	mov    -0x38(%rbp),%rcx
 1026d2d:	mov    %rcx,0x10(%rax)
 1026d31:	mov    %r12,0x18(%rax)
 1026d35:	add    $0x20,%rax
 1026d39:	mov    %rax,0x4a58(%rip)        # 102b798 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE11_bufferUsedE>
 1026d40:	lea    0x4aa9(%rip),%rdi        # 102b7f0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026d47:	call   1027920 <pthread_rwlock_unlock@plt>
 1026d4c:	jmp    1026d51 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2f1>
 1026d4e:	xor    %r13d,%r13d
 1026d51:	mov    %r13d,%eax
 1026d54:	add    $0x2b8,%rsp
 1026d5b:	pop    %rbx
 1026d5c:	pop    %r12
 1026d5e:	pop    %r13
 1026d60:	pop    %r14
 1026d62:	pop    %r15
 1026d64:	pop    %rbp
 1026d65:	ret
 1026d66:	int3
 1026d67:	int3
 1026d68:	int3
 1026d69:	int3
 1026d6a:	int3
 1026d6b:	int3
 1026d6c:	int3
 1026d6d:	int3
 1026d6e:	int3
 1026d6f:	int3

0000000001026d70 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE>:
 1026d70:	push   %rbp
 1026d71:	mov    %rsp,%rbp
 1026d74:	push   %r15
 1026d76:	push   %r14
 1026d78:	push   %r13
 1026d7a:	push   %r12
 1026d7c:	push   %rbx
 1026d7d:	sub    $0x18,%rsp
 1026d81:	mov    %rcx,%r14
 1026d84:	mov    %rsi,%rbx
 1026d87:	mov    %rdx,%rcx
 1026d8a:	sub    %rsi,%rcx
 1026d8d:	cmp    $0x3,%rcx
 1026d91:	ja     1026da0 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0x30>
 1026d93:	cmp    %rbx,%rdx
 1026d96:	jne    1026e21 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xb1>
 1026d9c:	xor    %eax,%eax
 1026d9e:	jmp    1026e12 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xa2>
 1026da0:	movzbl (%rbx),%eax
 1026da3:	cmp    $0x1,%eax
 1026da6:	jne    1026e3e <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xce>
 1026dac:	movzbl 0x1(%rbx),%ecx
 1026db0:	movzbl 0x2(%rbx),%r12d
 1026db5:	lea    0x4(%rbx),%rax
 1026db9:	mov    %rax,-0x30(%rbp)
 1026dbd:	movzbl 0x3(%rbx),%eax
 1026dc1:	mov    %al,0x18(%r14)
 1026dc5:	xor    %r15d,%r15d
 1026dc8:	lea    -0x30(%rbp),%rsi
 1026dcc:	mov    %rdi,%r13
 1026dcf:	mov    %rdx,-0x38(%rbp)
 1026dd3:	mov    %rbx,%r8
 1026dd6:	xor    %r9d,%r9d
 1026dd9:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1026dde:	mov    %rax,(%r14)
 1026de1:	cmp    $0xff,%r12b
 1026de5:	je     1026e04 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0x94>
 1026de7:	movzbl %r12b,%ecx
 1026deb:	lea    -0x30(%rbp),%rsi
 1026def:	mov    %r13,%rdi
 1026df2:	mov    -0x38(%rbp),%rdx
 1026df6:	mov    %rbx,%r8
 1026df9:	xor    %r9d,%r9d
 1026dfc:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1026e01:	mov    %rax,%r15
 1026e04:	mov    %r15,0x8(%r14)
 1026e08:	mov    -0x30(%rbp),%rax
 1026e0c:	mov    %rax,0x10(%r14)
 1026e10:	mov    $0x1,%al
 1026e12:	add    $0x18,%rsp
 1026e16:	pop    %rbx
 1026e17:	pop    %r12
 1026e19:	pop    %r13
 1026e1b:	pop    %r14
 1026e1d:	pop    %r15
 1026e1f:	pop    %rbp
 1026e20:	ret
 1026e21:	mov    0x1d70(%rip),%r14        # 1028b98 <stderr@GLIBC_2.2.5>
 1026e28:	mov    (%r14),%rdi
 1026e2b:	lea    -0x21fed(%rip),%rsi        # 1004e45 <qbe_empty_registry+0x12ed>
 1026e32:	mov    %rbx,%rdx
 1026e35:	xor    %eax,%eax
 1026e37:	call   10275e0 <fprintf@plt>
 1026e3c:	jmp    1026e5b <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xeb>
 1026e3e:	mov    0x1d53(%rip),%r14        # 1028b98 <stderr@GLIBC_2.2.5>
 1026e45:	mov    (%r14),%rdi
 1026e48:	lea    -0x2273b(%rip),%rsi        # 1004714 <qbe_empty_registry+0xbbc>
 1026e4f:	mov    %eax,%edx
 1026e51:	mov    %rbx,%rcx
 1026e54:	xor    %eax,%eax
 1026e56:	call   10275e0 <fprintf@plt>
 1026e5b:	mov    (%r14),%rdi
 1026e5e:	call   1027680 <fflush@plt>
 1026e63:	xor    %eax,%eax
 1026e65:	jmp    1026e12 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xa2>
 1026e67:	int3
 1026e68:	int3
 1026e69:	int3
 1026e6a:	int3
 1026e6b:	int3
 1026e6c:	int3
 1026e6d:	int3
 1026e6e:	int3
 1026e6f:	int3

0000000001026e70 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv>:
 1026e70:	push   %rbp
 1026e71:	mov    %rsp,%rbp
 1026e74:	push   %r15
 1026e76:	push   %r14
 1026e78:	push   %r13
 1026e7a:	push   %r12
 1026e7c:	push   %rbx
 1026e7d:	sub    $0x28,%rsp
 1026e81:	movzwl 0x18(%rdi),%r12d
 1026e86:	xor    %eax,%eax
 1026e88:	test   %r12,%r12
 1026e8b:	je     1026f7c <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10c>
 1026e91:	mov    %rdx,%rbx
 1026e94:	mov    %rdi,%r14
 1026e97:	mov    0x10(%rdx),%rcx
 1026e9b:	mov    (%rdi),%r13
 1026e9e:	cmp    %r13,%rcx
 1026ea1:	jb     1026f7c <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10c>
 1026ea7:	mov    0x10(%r14),%rax
 1026eab:	imul   $0x38,%r12,%rdx
 1026eaf:	xor    %esi,%esi
 1026eb1:	jmp    1026ecd <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x5d>
 1026eb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1026ec0:	add    $0x38,%rsi
 1026ec4:	cmp    %rsi,%rdx
 1026ec7:	je     1026f7a <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10a>
 1026ecd:	cmpl   $0x1,(%rax,%rsi,1)
 1026ed1:	jne    1026ec0 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x50>
 1026ed3:	mov    0x10(%rax,%rsi,1),%rdi
 1026ed8:	add    %r13,%rdi
 1026edb:	cmp    %rdi,%rcx
 1026ede:	jb     1026ec0 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x50>
 1026ee0:	mov    0x28(%rax,%rsi,1),%r8
 1026ee5:	lea    (%r8,%rdi,1),%r9
 1026ee9:	cmp    %r9,%rcx
 1026eec:	jae    1026ec0 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x50>
 1026eee:	mov    0x8(%rbx),%rax
 1026ef2:	mov    %rdi,(%rax)
 1026ef5:	mov    %r8,0x8(%rax)
 1026ef9:	mov    $0xffffffff,%r15d
 1026eff:	add    %r12,%r15
 1026f02:	dec    %r12
 1026f05:	jmp    1026f1e <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0xae>
 1026f07:	nopw   0x0(%rax,%rax,1)
 1026f10:	mov    %r12d,%eax
 1026f13:	dec    %r15
 1026f16:	dec    %r12
 1026f19:	test   %ax,%ax
 1026f1c:	je     1026f7a <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10a>
 1026f1e:	mov    0x10(%r14),%rax
 1026f22:	mov    %r15d,%ecx
 1026f25:	imul   $0x38,%rcx,%rcx
 1026f29:	cmpl   $0x6474e550,(%rax,%rcx,1)
 1026f30:	jne    1026f10 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0xa0>
 1026f32:	add    %rcx,%rax
 1026f35:	mov    0x10(%rax),%rsi
 1026f39:	add    %r13,%rsi
 1026f3c:	mov    0x8(%rbx),%rcx
 1026f40:	mov    %rsi,0x20(%rcx)
 1026f44:	mov    0x28(%rax),%rdx
 1026f48:	mov    %rdx,0x28(%rcx)
 1026f4c:	mov    (%rbx),%rdi
 1026f4f:	add    %rsi,%rdx
 1026f52:	lea    -0x48(%rbp),%rcx
 1026f56:	call   1026d70 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE>
 1026f5b:	test   %al,%al
 1026f5d:	je     1026f10 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0xa0>
 1026f5f:	mov    -0x48(%rbp),%rax
 1026f63:	mov    0x8(%rbx),%rcx
 1026f67:	mov    %rax,0x10(%rcx)
 1026f6b:	movq   $0xffffffffffffffff,0x18(%rcx)
 1026f73:	mov    $0x1,%eax
 1026f78:	jmp    1026f7c <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10c>
 1026f7a:	xor    %eax,%eax
 1026f7c:	add    $0x28,%rsp
 1026f80:	pop    %rbx
 1026f81:	pop    %r12
 1026f83:	pop    %r13
 1026f85:	pop    %r14
 1026f87:	pop    %r15
 1026f89:	pop    %rbp
 1026f8a:	ret
 1026f8b:	int3
 1026f8c:	int3
 1026f8d:	int3
 1026f8e:	int3
 1026f8f:	int3

0000000001026f90 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE>:
 1026f90:	push   %rbp
 1026f91:	mov    %rsp,%rbp
 1026f94:	push   %r15
 1026f96:	push   %r14
 1026f98:	push   %r13
 1026f9a:	push   %r12
 1026f9c:	push   %rbx
 1026f9d:	sub    $0x28,%rsp
 1026fa1:	mov    %r8,%r14
 1026fa4:	mov    %rsi,-0x50(%rbp)
 1026fa8:	test   %r8,%r8
 1026fab:	cmove  %rdx,%r14
 1026faf:	mov    %r14,-0x30(%rbp)
 1026fb3:	lea    (%rcx,%rdx,1),%r15
 1026fb7:	cmp    $0xffffffffffffffff,%rcx
 1026fbb:	cmove  %rcx,%r15
 1026fbf:	cmp    %r15,%r14
 1026fc2:	jae    1027146 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1b6>
 1026fc8:	mov    %rdx,%r13
 1026fcb:	mov    %rdi,-0x48(%rbp)
 1026fcf:	mov    %r9,-0x38(%rbp)
 1026fd3:	mov    $0xffffffff,%edx
 1026fd8:	jmp    1026fed <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x5d>
 1026fda:	nopw   0x0(%rax,%rax,1)
 1026fe0:	mov    %r14,-0x30(%rbp)
 1026fe4:	cmp    %r15,%r14
 1026fe7:	jae    1027146 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1b6>
 1026fed:	mov    %r14,%rbx
 1026ff0:	mov    (%r14),%r14d
 1026ff3:	lea    0x4(%rbx),%rsi
 1026ff7:	mov    %rsi,-0x30(%rbp)
 1026ffb:	cmp    %rdx,%r14
 1026ffe:	jne    102700c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x7c>
 1027000:	mov    0x4(%rbx),%r14
 1027004:	lea    0xc(%rbx),%rsi
 1027008:	mov    %rsi,-0x30(%rbp)
 102700c:	test   %r14,%r14
 102700f:	je     1027146 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1b6>
 1027015:	mov    (%rsi),%eax
 1027017:	add    %rsi,%r14
 102701a:	test   %rax,%rax
 102701d:	je     1026fe0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 102701f:	sub    %rax,%rsi
 1027022:	cmp    %rsi,%r13
 1027025:	seta   %al
 1027028:	cmp    %r15,%rsi
 102702b:	setae  %cl
 102702e:	or     %al,%cl
 1027030:	jne    1026fe0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 1027032:	mov    -0x48(%rbp),%rdi
 1027036:	mov    0x10(%rbp),%rdx
 102703a:	call   1024400 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE>
 102703f:	mov    $0xffffffff,%edx
 1027044:	test   %rax,%rax
 1027047:	jne    1026fe0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 1027049:	addq   $0x4,-0x30(%rbp)
 102704e:	mov    0x10(%rbp),%rax
 1027052:	movzbl 0x18(%rax),%ecx
 1027056:	mov    -0x48(%rbp),%r12
 102705a:	mov    %r12,%rdi
 102705d:	lea    -0x30(%rbp),%rsi
 1027061:	mov    %r14,%rdx
 1027064:	xor    %r8d,%r8d
 1027067:	xor    %r9d,%r9d
 102706a:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 102706f:	mov    %rax,-0x40(%rbp)
 1027073:	mov    0x10(%rbp),%rax
 1027077:	movzbl 0x18(%rax),%ecx
 102707b:	and    $0xf,%ecx
 102707e:	mov    %r12,%rdi
 1027081:	lea    -0x30(%rbp),%rsi
 1027085:	mov    %r14,%rdx
 1027088:	xor    %r8d,%r8d
 102708b:	xor    %r9d,%r9d
 102708e:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1027093:	mov    -0x40(%rbp),%rcx
 1027097:	mov    $0xffffffff,%edx
 102709c:	mov    %rax,%r12
 102709f:	mov    -0x50(%rbp),%rax
 10270a3:	mov    (%rax),%rax
 10270a6:	cmp    %rax,%rcx
 10270a9:	ja     1026fe0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 10270af:	add    %rcx,%r12
 10270b2:	cmp    %r12,%rax
 10270b5:	jae    1026fe0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 10270bb:	mov    -0x38(%rbp),%rax
 10270bf:	movq   $0x0,0x28(%rax)
 10270c7:	mov    0x10(%rbp),%r15
 10270cb:	cmpb   $0x0,0x31(%r15)
 10270d0:	je     1027157 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1c7>
 10270d6:	lea    -0x30(%rbp),%rdi
 10270da:	mov    %r14,%rsi
 10270dd:	call   1026060 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10270e2:	mov    %rax,%r13
 10270e5:	mov    %r15,%rax
 10270e8:	mov    -0x30(%rbp),%r15
 10270ec:	add    %r15,%r13
 10270ef:	movzbl 0x19(%rax),%eax
 10270f3:	cmp    $0xff,%al
 10270f5:	je     102715d <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1cd>
 10270f7:	and    $0xf,%al
 10270f9:	movzbl %al,%ecx
 10270fc:	lea    -0x30(%rbp),%rsi
 1027100:	mov    -0x48(%rbp),%rdi
 1027104:	mov    %r14,%rdx
 1027107:	xor    %r8d,%r8d
 102710a:	xor    %r9d,%r9d
 102710d:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1027112:	test   %rax,%rax
 1027115:	je     102715d <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1cd>
 1027117:	mov    %r15,-0x30(%rbp)
 102711b:	mov    0x10(%rbp),%rax
 102711f:	movzbl 0x19(%rax),%ecx
 1027123:	lea    -0x30(%rbp),%rsi
 1027127:	mov    -0x48(%rbp),%rdi
 102712b:	mov    %r14,%rdx
 102712e:	xor    %r8d,%r8d
 1027131:	xor    %r9d,%r9d
 1027134:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1027139:	mov    -0x38(%rbp),%rcx
 102713d:	mov    %rax,0x28(%rcx)
 1027141:	mov    %rcx,%rax
 1027144:	jmp    1027161 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1d1>
 1027146:	xor    %eax,%eax
 1027148:	add    $0x28,%rsp
 102714c:	pop    %rbx
 102714d:	pop    %r12
 102714f:	pop    %r13
 1027151:	pop    %r14
 1027153:	pop    %r15
 1027155:	pop    %rbp
 1027156:	ret
 1027157:	mov    -0x30(%rbp),%r13
 102715b:	jmp    1027165 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1d5>
 102715d:	mov    -0x38(%rbp),%rax
 1027161:	mov    -0x40(%rbp),%rcx
 1027165:	mov    %rbx,(%rax)
 1027168:	sub    %rbx,%r14
 102716b:	mov    %r14,0x8(%rax)
 102716f:	mov    %r13,0x10(%rax)
 1027173:	mov    %rcx,0x18(%rax)
 1027177:	mov    %r12,0x20(%rax)
 102717b:	mov    $0x1,%al
 102717d:	jmp    1027148 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1b8>
 102717f:	int3

0000000001027180 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE>:
 1027180:	push   %rbp
 1027181:	mov    %rsp,%rbp
 1027184:	push   %r15
 1027186:	push   %r14
 1027188:	push   %r13
 102718a:	push   %r12
 102718c:	push   %rbx
 102718d:	sub    $0x68,%rsp
 1027191:	mov    %r9,%r14
 1027194:	mov    %r8,%rbx
 1027197:	mov    %rsi,-0x40(%rbp)
 102719b:	mov    %ecx,%eax
 102719d:	add    %rdx,%rax
 10271a0:	lea    -0x88(%rbp),%rcx
 10271a7:	mov    %rdi,-0x58(%rbp)
 10271ab:	mov    %rdx,-0x50(%rbp)
 10271af:	mov    %rdx,%rsi
 10271b2:	mov    %rax,-0x48(%rbp)
 10271b6:	mov    %rax,%rdx
 10271b9:	call   1026d70 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE>
 10271be:	test   %al,%al
 10271c0:	je     10272c8 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x148>
 10271c6:	cmpq   $0x0,-0x80(%rbp)
 10271cb:	je     10272c8 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x148>
 10271d1:	mov    %r14,-0x60(%rbp)
 10271d5:	mov    %rbx,-0x68(%rbp)
 10271d9:	movzbl -0x70(%rbp),%edi
 10271dd:	call   10272e0 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh>
 10271e2:	mov    %rax,-0x38(%rbp)
 10271e6:	xor    %r13d,%r13d
 10271e9:	mov    -0x80(%rbp),%r12
 10271ed:	nopl   (%rax)
 10271f0:	cmp    $0x1,%r12
 10271f4:	jbe    1027245 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0xc5>
 10271f6:	mov    %r12,%rbx
 10271f9:	shr    $1,%rbx
 10271fc:	lea    (%rbx,%r13,1),%r15
 1027200:	mov    %r15,%r14
 1027203:	imul   -0x38(%rbp),%r14
 1027208:	mov    -0x78(%rbp),%rax
 102720c:	add    %r14,%rax
 102720f:	mov    %rax,-0x30(%rbp)
 1027213:	movzbl -0x70(%rbp),%ecx
 1027217:	mov    -0x58(%rbp),%rdi
 102721b:	lea    -0x30(%rbp),%rsi
 102721f:	mov    -0x48(%rbp),%rdx
 1027223:	mov    -0x50(%rbp),%r8
 1027227:	xor    %r9d,%r9d
 102722a:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 102722f:	sub    %rbx,%r12
 1027232:	mov    -0x40(%rbp),%rcx
 1027236:	cmp    (%rcx),%rax
 1027239:	cmovb  %r15,%r13
 102723d:	cmovae %rbx,%r12
 1027241:	jne    10271f0 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x70>
 1027243:	jmp    102724d <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0xcd>
 1027245:	imul   -0x38(%rbp),%r13
 102724a:	mov    %r13,%r14
 102724d:	add    -0x78(%rbp),%r14
 1027251:	mov    %r14,-0x30(%rbp)
 1027255:	movzbl -0x70(%rbp),%ebx
 1027259:	lea    -0x30(%rbp),%r13
 102725d:	mov    -0x58(%rbp),%r14
 1027261:	mov    %r14,%rdi
 1027264:	mov    %r13,%rsi
 1027267:	mov    -0x48(%rbp),%r12
 102726b:	mov    %r12,%rdx
 102726e:	mov    %ebx,%ecx
 1027270:	mov    -0x50(%rbp),%r15
 1027274:	mov    %r15,%r8
 1027277:	xor    %r9d,%r9d
 102727a:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 102727f:	mov    %r14,%rdi
 1027282:	mov    %r13,%rsi
 1027285:	mov    %r12,%rdx
 1027288:	mov    %ebx,%ecx
 102728a:	mov    %r15,%r8
 102728d:	xor    %r9d,%r9d
 1027290:	call   1025e30 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1027295:	mov    %r14,%rdi
 1027298:	mov    %rax,%rsi
 102729b:	mov    -0x68(%rbp),%rbx
 102729f:	mov    %rbx,%rdx
 10272a2:	mov    -0x60(%rbp),%rcx
 10272a6:	xor    %r8d,%r8d
 10272a9:	call   1024260 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb>
 10272ae:	test   %rax,%rax
 10272b1:	jne    10272c8 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x148>
 10272b3:	mov    -0x40(%rbp),%rax
 10272b7:	mov    (%rax),%rcx
 10272ba:	cmp    0x18(%rbx),%rcx
 10272be:	jb     10272c8 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x148>
 10272c0:	mov    $0x1,%al
 10272c2:	cmp    0x20(%rbx),%rcx
 10272c6:	jb     10272ca <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x14a>
 10272c8:	xor    %eax,%eax
 10272ca:	add    $0x68,%rsp
 10272ce:	pop    %rbx
 10272cf:	pop    %r12
 10272d1:	pop    %r13
 10272d3:	pop    %r14
 10272d5:	pop    %r15
 10272d7:	pop    %rbp
 10272d8:	ret
 10272d9:	int3
 10272da:	int3
 10272db:	int3
 10272dc:	int3
 10272dd:	int3
 10272de:	int3
 10272df:	int3

00000000010272e0 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh>:
 10272e0:	push   %rbp
 10272e1:	mov    %rsp,%rbp
 10272e4:	push   %rbx
 10272e5:	push   %rax
 10272e6:	and    $0xf,%edi
 10272e9:	dec    %edi
 10272eb:	cmp    $0xb,%edi
 10272ee:	ja     102733b <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh+0x5b>
 10272f0:	lea    -0x1b0d7(%rip),%rax        # 100c220 <raw_shape+0x720>
 10272f7:	movslq (%rax,%rdi,4),%rcx
 10272fb:	add    %rax,%rcx
 10272fe:	jmp    *%rcx
 1027300:	mov    $0x4,%eax
 1027305:	jmp    1027313 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh+0x33>
 1027307:	mov    $0x10,%eax
 102730c:	jmp    1027313 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh+0x33>
 102730e:	mov    $0x8,%eax
 1027313:	add    $0x8,%rsp
 1027317:	pop    %rbx
 1027318:	pop    %rbp
 1027319:	ret
 102731a:	mov    0x1877(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1027321:	mov    (%rbx),%rdi
 1027324:	lea    -0x22a60(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 102732b:	lea    -0x23287(%rip),%rdx        # 10040ab <qbe_empty_registry+0x553>
 1027332:	lea    -0x22d0a(%rip),%rcx        # 100462f <qbe_empty_registry+0xad7>
 1027339:	jmp    102735a <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh+0x7a>
 102733b:	mov    0x1856(%rip),%rbx        # 1028b98 <stderr@GLIBC_2.2.5>
 1027342:	mov    (%rbx),%rdi
 1027345:	lea    -0x22a81(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 102734c:	lea    -0x232a8(%rip),%rdx        # 10040ab <qbe_empty_registry+0x553>
 1027353:	lea    -0x22d54(%rip),%rcx        # 1004606 <qbe_empty_registry+0xaae>
 102735a:	xor    %eax,%eax
 102735c:	call   10275e0 <fprintf@plt>
 1027361:	mov    (%rbx),%rdi
 1027364:	call   1027680 <fflush@plt>
 1027369:	call   1027690 <abort@plt>
 102736e:	int3
 102736f:	int3

0000000001027370 <_Unwind_Backtrace>:
 1027370:	push   %rbp
 1027371:	mov    %rsp,%rbp
 1027374:	push   %r15
 1027376:	push   %r14
 1027378:	push   %r12
 102737a:	push   %rbx
 102737b:	sub    $0x1b0,%rsp
 1027382:	mov    %rsi,%rbx
 1027385:	mov    %rdi,%r14
 1027388:	lea    -0xc8(%rbp),%r12
 102738f:	mov    %r12,%rdi
 1027392:	call   1027440 <__unw_getcontext>
 1027397:	lea    -0x1d0(%rbp),%r15
 102739e:	mov    %r15,%rdi
 10273a1:	mov    %r12,%rsi
 10273a4:	call   1024180 <__unw_init_local>
 10273a9:	nopl   0x0(%rax)
 10273b0:	mov    %r15,%rdi
 10273b3:	call   1024250 <__unw_step>
 10273b8:	test   %eax,%eax
 10273ba:	jle    10273cb <_Unwind_Backtrace+0x5b>
 10273bc:	mov    %r15,%rdi
 10273bf:	mov    %rbx,%rsi
 10273c2:	call   *%r14
 10273c5:	test   %eax,%eax
 10273c7:	je     10273b0 <_Unwind_Backtrace+0x40>
 10273c9:	jmp    10273d0 <_Unwind_Backtrace+0x60>
 10273cb:	mov    $0x5,%eax
 10273d0:	add    $0x1b0,%rsp
 10273d7:	pop    %rbx
 10273d8:	pop    %r12
 10273da:	pop    %r14
 10273dc:	pop    %r15
 10273de:	pop    %rbp
 10273df:	ret

00000000010273e0 <__libunwind_Registers_x86_64_jumpto>:
 10273e0:	mov    0x38(%rdi),%rax
 10273e4:	sub    $0x10,%rax
 10273e8:	mov    %rax,0x38(%rdi)
 10273ec:	mov    0x20(%rdi),%rbx
 10273f0:	mov    %rbx,(%rax)
 10273f3:	mov    0x80(%rdi),%rbx
 10273fa:	mov    %rbx,0x8(%rax)
 10273fe:	mov    (%rdi),%rax
 1027401:	mov    0x8(%rdi),%rbx
 1027405:	mov    0x10(%rdi),%rcx
 1027409:	mov    0x18(%rdi),%rdx
 102740d:	mov    0x28(%rdi),%rsi
 1027411:	mov    0x30(%rdi),%rbp
 1027415:	mov    0x40(%rdi),%r8
 1027419:	mov    0x48(%rdi),%r9
 102741d:	mov    0x50(%rdi),%r10
 1027421:	mov    0x58(%rdi),%r11
 1027425:	mov    0x60(%rdi),%r12
 1027429:	mov    0x68(%rdi),%r13
 102742d:	mov    0x70(%rdi),%r14
 1027431:	mov    0x78(%rdi),%r15
 1027435:	mov    0x38(%rdi),%rsp
 1027439:	pop    %rdi
 102743a:	pop    %rcx
 102743b:	jmp    *%rcx
 102743d:	int3
 102743e:	int3
 102743f:	int3

0000000001027440 <__unw_getcontext>:
 1027440:	mov    %rax,(%rdi)
 1027443:	mov    %rbx,0x8(%rdi)
 1027447:	mov    %rcx,0x10(%rdi)
 102744b:	mov    %rdx,0x18(%rdi)
 102744f:	mov    %rdi,0x20(%rdi)
 1027453:	mov    %rsi,0x28(%rdi)
 1027457:	mov    %rbp,0x30(%rdi)
 102745b:	mov    %rsp,0x38(%rdi)
 102745f:	addq   $0x8,0x38(%rdi)
 1027464:	mov    %r8,0x40(%rdi)
 1027468:	mov    %r9,0x48(%rdi)
 102746c:	mov    %r10,0x50(%rdi)
 1027470:	mov    %r11,0x58(%rdi)
 1027474:	mov    %r12,0x60(%rdi)
 1027478:	mov    %r13,0x68(%rdi)
 102747c:	mov    %r14,0x70(%rdi)
 1027480:	mov    %r15,0x78(%rdi)
 1027484:	mov    (%rsp),%rsi
 1027488:	mov    %rsi,0x80(%rdi)
 102748f:	xor    %eax,%eax
 1027491:	ret

Disassembly of section .init:

0000000001027494 <_init>:
 1027494:	endbr64
 1027498:	sub    $0x8,%rsp
 102749c:	mov    0x16ed(%rip),%rax        # 1028b90 <__gmon_start__>
 10274a3:	test   %rax,%rax
 10274a6:	je     10274aa <_init+0x16>
 10274a8:	call   *%rax
 10274aa:	add    $0x8,%rsp
 10274ae:	ret

Disassembly of section .fini:

00000000010274b0 <_fini>:
 10274b0:	endbr64
 10274b4:	sub    $0x8,%rsp
 10274b8:	add    $0x8,%rsp
 10274bc:	ret

Disassembly of section .plt:

00000000010274c0 <memset@plt-0x10>:
 10274c0:	push   0x16f2(%rip)        # 1028bb8 <_GLOBAL_OFFSET_TABLE_+0x8>
 10274c6:	jmp    *0x16f4(%rip)        # 1028bc0 <_GLOBAL_OFFSET_TABLE_+0x10>
 10274cc:	nopl   0x0(%rax)

00000000010274d0 <memset@plt>:
 10274d0:	jmp    *0x16f2(%rip)        # 1028bc8 <memset@GLIBC_2.2.5>
 10274d6:	push   $0x0
 10274db:	jmp    10274c0 <_fini+0x10>

00000000010274e0 <getenv@plt>:
 10274e0:	jmp    *0x16ea(%rip)        # 1028bd0 <getenv@GLIBC_2.2.5>
 10274e6:	push   $0x1
 10274eb:	jmp    10274c0 <_fini+0x10>

00000000010274f0 <strlen@plt>:
 10274f0:	jmp    *0x16e2(%rip)        # 1028bd8 <strlen@GLIBC_2.2.5>
 10274f6:	push   $0x2
 10274fb:	jmp    10274c0 <_fini+0x10>

0000000001027500 <malloc@plt>:
 1027500:	jmp    *0x16da(%rip)        # 1028be0 <malloc@GLIBC_2.2.5>
 1027506:	push   $0x3
 102750b:	jmp    10274c0 <_fini+0x10>

0000000001027510 <calloc@plt>:
 1027510:	jmp    *0x16d2(%rip)        # 1028be8 <calloc@GLIBC_2.2.5>
 1027516:	push   $0x4
 102751b:	jmp    10274c0 <_fini+0x10>

0000000001027520 <memcpy@plt>:
 1027520:	jmp    *0x16ca(%rip)        # 1028bf0 <memcpy@GLIBC_2.14>
 1027526:	push   $0x5
 102752b:	jmp    10274c0 <_fini+0x10>

0000000001027530 <open@plt>:
 1027530:	jmp    *0x16c2(%rip)        # 1028bf8 <open@GLIBC_2.2.5>
 1027536:	push   $0x6
 102753b:	jmp    10274c0 <_fini+0x10>

0000000001027540 <strcmp@plt>:
 1027540:	jmp    *0x16ba(%rip)        # 1028c00 <strcmp@GLIBC_2.2.5>
 1027546:	push   $0x7
 102754b:	jmp    10274c0 <_fini+0x10>

0000000001027550 <strncmp@plt>:
 1027550:	jmp    *0x16b2(%rip)        # 1028c08 <strncmp@GLIBC_2.2.5>
 1027556:	push   $0x8
 102755b:	jmp    10274c0 <_fini+0x10>

0000000001027560 <strtoull@plt>:
 1027560:	jmp    *0x16aa(%rip)        # 1028c10 <strtoull@GLIBC_2.2.5>
 1027566:	push   $0x9
 102756b:	jmp    10274c0 <_fini+0x10>

0000000001027570 <free@plt>:
 1027570:	jmp    *0x16a2(%rip)        # 1028c18 <free@GLIBC_2.2.5>
 1027576:	push   $0xa
 102757b:	jmp    10274c0 <_fini+0x10>

0000000001027580 <clock_gettime@plt>:
 1027580:	jmp    *0x169a(%rip)        # 1028c20 <clock_gettime@GLIBC_2.17>
 1027586:	push   $0xb
 102758b:	jmp    10274c0 <_fini+0x10>

0000000001027590 <sigemptyset@plt>:
 1027590:	jmp    *0x1692(%rip)        # 1028c28 <sigemptyset@GLIBC_2.2.5>
 1027596:	push   $0xc
 102759b:	jmp    10274c0 <_fini+0x10>

00000000010275a0 <sigaction@plt>:
 10275a0:	jmp    *0x168a(%rip)        # 1028c30 <sigaction@GLIBC_2.2.5>
 10275a6:	push   $0xd
 10275ab:	jmp    10274c0 <_fini+0x10>

00000000010275b0 <timer_create@plt>:
 10275b0:	jmp    *0x1682(%rip)        # 1028c38 <timer_create@GLIBC_2.34>
 10275b6:	push   $0xe
 10275bb:	jmp    10274c0 <_fini+0x10>

00000000010275c0 <timer_settime@plt>:
 10275c0:	jmp    *0x167a(%rip)        # 1028c40 <timer_settime@GLIBC_2.34>
 10275c6:	push   $0xf
 10275cb:	jmp    10274c0 <_fini+0x10>

00000000010275d0 <fwrite@plt>:
 10275d0:	jmp    *0x1672(%rip)        # 1028c48 <fwrite@GLIBC_2.2.5>
 10275d6:	push   $0x10
 10275db:	jmp    10274c0 <_fini+0x10>

00000000010275e0 <fprintf@plt>:
 10275e0:	jmp    *0x166a(%rip)        # 1028c50 <fprintf@GLIBC_2.2.5>
 10275e6:	push   $0x11
 10275eb:	jmp    10274c0 <_fini+0x10>

00000000010275f0 <unsetenv@plt>:
 10275f0:	jmp    *0x1662(%rip)        # 1028c58 <unsetenv@GLIBC_2.2.5>
 10275f6:	push   $0x12
 10275fb:	jmp    10274c0 <_fini+0x10>

0000000001027600 <getrlimit@plt>:
 1027600:	jmp    *0x165a(%rip)        # 1028c60 <getrlimit@GLIBC_2.2.5>
 1027606:	push   $0x13
 102760b:	jmp    10274c0 <_fini+0x10>

0000000001027610 <setrlimit@plt>:
 1027610:	jmp    *0x1652(%rip)        # 1028c68 <setrlimit@GLIBC_2.2.5>
 1027616:	push   $0x14
 102761b:	jmp    10274c0 <_fini+0x10>

0000000001027620 <fegetround@plt>:
 1027620:	jmp    *0x164a(%rip)        # 1028c70 <fegetround@GLIBC_2.2.5>
 1027626:	push   $0x15
 102762b:	jmp    10274c0 <_fini+0x10>

0000000001027630 <printf@plt>:
 1027630:	jmp    *0x1642(%rip)        # 1028c78 <printf@GLIBC_2.2.5>
 1027636:	push   $0x16
 102763b:	jmp    10274c0 <_fini+0x10>

0000000001027640 <close@plt>:
 1027640:	jmp    *0x163a(%rip)        # 1028c80 <close@GLIBC_2.2.5>
 1027646:	push   $0x17
 102764b:	jmp    10274c0 <_fini+0x10>

0000000001027650 <sqrt@plt>:
 1027650:	jmp    *0x1632(%rip)        # 1028c88 <sqrt@GLIBC_2.2.5>
 1027656:	push   $0x18
 102765b:	jmp    10274c0 <_fini+0x10>

0000000001027660 <snprintf@plt>:
 1027660:	jmp    *0x162a(%rip)        # 1028c90 <snprintf@GLIBC_2.2.5>
 1027666:	push   $0x19
 102766b:	jmp    10274c0 <_fini+0x10>

0000000001027670 <realloc@plt>:
 1027670:	jmp    *0x1622(%rip)        # 1028c98 <realloc@GLIBC_2.2.5>
 1027676:	push   $0x1a
 102767b:	jmp    10274c0 <_fini+0x10>

0000000001027680 <fflush@plt>:
 1027680:	jmp    *0x161a(%rip)        # 1028ca0 <fflush@GLIBC_2.2.5>
 1027686:	push   $0x1b
 102768b:	jmp    10274c0 <_fini+0x10>

0000000001027690 <abort@plt>:
 1027690:	jmp    *0x1612(%rip)        # 1028ca8 <abort@GLIBC_2.2.5>
 1027696:	push   $0x1c
 102769b:	jmp    10274c0 <_fini+0x10>

00000000010276a0 <longjmp@plt>:
 10276a0:	jmp    *0x160a(%rip)        # 1028cb0 <longjmp@GLIBC_2.2.5>
 10276a6:	push   $0x1d
 10276ab:	jmp    10274c0 <_fini+0x10>

00000000010276b0 <qsort@plt>:
 10276b0:	jmp    *0x1602(%rip)        # 1028cb8 <qsort@GLIBC_2.2.5>
 10276b6:	push   $0x1e
 10276bb:	jmp    10274c0 <_fini+0x10>

00000000010276c0 <write@plt>:
 10276c0:	jmp    *0x15fa(%rip)        # 1028cc0 <write@GLIBC_2.2.5>
 10276c6:	push   $0x1f
 10276cb:	jmp    10274c0 <_fini+0x10>

00000000010276d0 <_exit@plt>:
 10276d0:	jmp    *0x15f2(%rip)        # 1028cc8 <_exit@GLIBC_2.2.5>
 10276d6:	push   $0x20
 10276db:	jmp    10274c0 <_fini+0x10>

00000000010276e0 <vsnprintf@plt>:
 10276e0:	jmp    *0x15ea(%rip)        # 1028cd0 <vsnprintf@GLIBC_2.2.5>
 10276e6:	push   $0x21
 10276eb:	jmp    10274c0 <_fini+0x10>

00000000010276f0 <bcmp@plt>:
 10276f0:	jmp    *0x15e2(%rip)        # 1028cd8 <bcmp@GLIBC_2.2.5>
 10276f6:	push   $0x22
 10276fb:	jmp    10274c0 <_fini+0x10>

0000000001027700 <memmove@plt>:
 1027700:	jmp    *0x15da(%rip)        # 1028ce0 <memmove@GLIBC_2.2.5>
 1027706:	push   $0x23
 102770b:	jmp    10274c0 <_fini+0x10>

0000000001027710 <sysconf@plt>:
 1027710:	jmp    *0x15d2(%rip)        # 1028ce8 <sysconf@GLIBC_2.2.5>
 1027716:	push   $0x24
 102771b:	jmp    10274c0 <_fini+0x10>

0000000001027720 <mmap@plt>:
 1027720:	jmp    *0x15ca(%rip)        # 1028cf0 <mmap@GLIBC_2.2.5>
 1027726:	push   $0x25
 102772b:	jmp    10274c0 <_fini+0x10>

0000000001027730 <mprotect@plt>:
 1027730:	jmp    *0x15c2(%rip)        # 1028cf8 <mprotect@GLIBC_2.2.5>
 1027736:	push   $0x26
 102773b:	jmp    10274c0 <_fini+0x10>

0000000001027740 <getcontext@plt>:
 1027740:	jmp    *0x15ba(%rip)        # 1028d00 <getcontext@GLIBC_2.2.5>
 1027746:	push   $0x27
 102774b:	jmp    10274c0 <_fini+0x10>

0000000001027750 <makecontext@plt>:
 1027750:	jmp    *0x15b2(%rip)        # 1028d08 <makecontext@GLIBC_2.2.5>
 1027756:	push   $0x28
 102775b:	jmp    10274c0 <_fini+0x10>

0000000001027760 <swapcontext@plt>:
 1027760:	jmp    *0x15aa(%rip)        # 1028d10 <swapcontext@GLIBC_2.2.5>
 1027766:	push   $0x29
 102776b:	jmp    10274c0 <_fini+0x10>

0000000001027770 <munmap@plt>:
 1027770:	jmp    *0x15a2(%rip)        # 1028d18 <munmap@GLIBC_2.2.5>
 1027776:	push   $0x2a
 102777b:	jmp    10274c0 <_fini+0x10>

0000000001027780 <_setjmp@plt>:
 1027780:	jmp    *0x159a(%rip)        # 1028d20 <_setjmp@GLIBC_2.2.5>
 1027786:	push   $0x2b
 102778b:	jmp    10274c0 <_fini+0x10>

0000000001027790 <strchr@plt>:
 1027790:	jmp    *0x1592(%rip)        # 1028d28 <strchr@GLIBC_2.2.5>
 1027796:	push   $0x2c
 102779b:	jmp    10274c0 <_fini+0x10>

00000000010277a0 <strrchr@plt>:
 10277a0:	jmp    *0x158a(%rip)        # 1028d30 <strrchr@GLIBC_2.2.5>
 10277a6:	push   $0x2d
 10277ab:	jmp    10274c0 <_fini+0x10>

00000000010277b0 <strtoul@plt>:
 10277b0:	jmp    *0x1582(%rip)        # 1028d38 <strtoul@GLIBC_2.2.5>
 10277b6:	push   $0x2e
 10277bb:	jmp    10274c0 <_fini+0x10>

00000000010277c0 <inet_pton@plt>:
 10277c0:	jmp    *0x157a(%rip)        # 1028d40 <inet_pton@GLIBC_2.2.5>
 10277c6:	push   $0x2f
 10277cb:	jmp    10274c0 <_fini+0x10>

00000000010277d0 <socket@plt>:
 10277d0:	jmp    *0x1572(%rip)        # 1028d48 <socket@GLIBC_2.2.5>
 10277d6:	push   $0x30
 10277db:	jmp    10274c0 <_fini+0x10>

00000000010277e0 <connect@plt>:
 10277e0:	jmp    *0x156a(%rip)        # 1028d50 <connect@GLIBC_2.2.5>
 10277e6:	push   $0x31
 10277eb:	jmp    10274c0 <_fini+0x10>

00000000010277f0 <read@plt>:
 10277f0:	jmp    *0x1562(%rip)        # 1028d58 <read@GLIBC_2.2.5>
 10277f6:	push   $0x32
 10277fb:	jmp    10274c0 <_fini+0x10>

0000000001027800 <__errno_location@plt>:
 1027800:	jmp    *0x155a(%rip)        # 1028d60 <__errno_location@GLIBC_2.2.5>
 1027806:	push   $0x33
 102780b:	jmp    10274c0 <_fini+0x10>

0000000001027810 <lseek@plt>:
 1027810:	jmp    *0x1552(%rip)        # 1028d68 <lseek@GLIBC_2.2.5>
 1027816:	push   $0x34
 102781b:	jmp    10274c0 <_fini+0x10>

0000000001027820 <pwrite@plt>:
 1027820:	jmp    *0x154a(%rip)        # 1028d70 <pwrite@GLIBC_2.2.5>
 1027826:	push   $0x35
 102782b:	jmp    10274c0 <_fini+0x10>

0000000001027830 <openat@plt>:
 1027830:	jmp    *0x1542(%rip)        # 1028d78 <openat@GLIBC_2.4>
 1027836:	push   $0x36
 102783b:	jmp    10274c0 <_fini+0x10>

0000000001027840 <memchr@plt>:
 1027840:	jmp    *0x153a(%rip)        # 1028d80 <memchr@GLIBC_2.2.5>
 1027846:	push   $0x37
 102784b:	jmp    10274c0 <_fini+0x10>

0000000001027850 <fstatat@plt>:
 1027850:	jmp    *0x1532(%rip)        # 1028d88 <fstatat@GLIBC_2.33>
 1027856:	push   $0x38
 102785b:	jmp    10274c0 <_fini+0x10>

0000000001027860 <mkdirat@plt>:
 1027860:	jmp    *0x152a(%rip)        # 1028d90 <mkdirat@GLIBC_2.4>
 1027866:	push   $0x39
 102786b:	jmp    10274c0 <_fini+0x10>

0000000001027870 <fdopendir@plt>:
 1027870:	jmp    *0x1522(%rip)        # 1028d98 <fdopendir@GLIBC_2.4>
 1027876:	push   $0x3a
 102787b:	jmp    10274c0 <_fini+0x10>

0000000001027880 <readdir@plt>:
 1027880:	jmp    *0x151a(%rip)        # 1028da0 <readdir@GLIBC_2.2.5>
 1027886:	push   $0x3b
 102788b:	jmp    10274c0 <_fini+0x10>

0000000001027890 <dirfd@plt>:
 1027890:	jmp    *0x1512(%rip)        # 1028da8 <dirfd@GLIBC_2.2.5>
 1027896:	push   $0x3c
 102789b:	jmp    10274c0 <_fini+0x10>

00000000010278a0 <fstat@plt>:
 10278a0:	jmp    *0x150a(%rip)        # 1028db0 <fstat@GLIBC_2.33>
 10278a6:	push   $0x3d
 10278ab:	jmp    10274c0 <_fini+0x10>

00000000010278b0 <unlinkat@plt>:
 10278b0:	jmp    *0x1502(%rip)        # 1028db8 <unlinkat@GLIBC_2.4>
 10278b6:	push   $0x3e
 10278bb:	jmp    10274c0 <_fini+0x10>

00000000010278c0 <ftruncate@plt>:
 10278c0:	jmp    *0x14fa(%rip)        # 1028dc0 <ftruncate@GLIBC_2.2.5>
 10278c6:	push   $0x3f
 10278cb:	jmp    10274c0 <_fini+0x10>

00000000010278d0 <closedir@plt>:
 10278d0:	jmp    *0x14f2(%rip)        # 1028dc8 <closedir@GLIBC_2.2.5>
 10278d6:	push   $0x40
 10278db:	jmp    10274c0 <_fini+0x10>

00000000010278e0 <fcntl@plt>:
 10278e0:	jmp    *0x14ea(%rip)        # 1028dd0 <fcntl@GLIBC_2.2.5>
 10278e6:	push   $0x41
 10278eb:	jmp    10274c0 <_fini+0x10>

00000000010278f0 <madvise@plt>:
 10278f0:	jmp    *0x14e2(%rip)        # 1028dd8 <madvise@GLIBC_2.2.5>
 10278f6:	push   $0x42
 10278fb:	jmp    10274c0 <_fini+0x10>

0000000001027900 <mremap@plt>:
 1027900:	jmp    *0x14da(%rip)        # 1028de0 <mremap@GLIBC_2.2.5>
 1027906:	push   $0x43
 102790b:	jmp    10274c0 <_fini+0x10>

0000000001027910 <pthread_rwlock_wrlock@plt>:
 1027910:	jmp    *0x14d2(%rip)        # 1028de8 <pthread_rwlock_wrlock@GLIBC_2.34>
 1027916:	push   $0x44
 102791b:	jmp    10274c0 <_fini+0x10>

0000000001027920 <pthread_rwlock_unlock@plt>:
 1027920:	jmp    *0x14ca(%rip)        # 1028df0 <pthread_rwlock_unlock@GLIBC_2.34>
 1027926:	push   $0x45
 102792b:	jmp    10274c0 <_fini+0x10>

0000000001027930 <dladdr@plt>:
 1027930:	jmp    *0x14c2(%rip)        # 1028df8 <dladdr@GLIBC_2.34>
 1027936:	push   $0x46
 102793b:	jmp    10274c0 <_fini+0x10>

0000000001027940 <dlsym@plt>:
 1027940:	jmp    *0x14ba(%rip)        # 1028e00 <dlsym@GLIBC_2.34>
 1027946:	push   $0x47
 102794b:	jmp    10274c0 <_fini+0x10>

0000000001027950 <dl_iterate_phdr@plt>:
 1027950:	jmp    *0x14b2(%rip)        # 1028e08 <dl_iterate_phdr@GLIBC_2.2.5>
 1027956:	push   $0x48
 102795b:	jmp    10274c0 <_fini+0x10>

0000000001027960 <pthread_rwlock_rdlock@plt>:
 1027960:	jmp    *0x14aa(%rip)        # 1028e10 <pthread_rwlock_rdlock@GLIBC_2.34>
 1027966:	push   $0x49
 102796b:	jmp    10274c0 <_fini+0x10>
