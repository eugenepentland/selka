
.tmp/cold-hint/raytrace.llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001014a6d <fail>:
 1014a6d:	push   %rbp
 1014a6e:	mov    %rsp,%rbp
 1014a71:	push   %r15
 1014a73:	push   %r14
 1014a75:	push   %rbx
 1014a76:	push   %rax
 1014a77:	cmpq   $0x0,0x20(%rdi)
 1014a7c:	jne    1014aec <fail+0x7f>
 1014a7e:	mov    %rdi,%rbx
 1014a81:	mov    %rsi,0x20(%rdi)
 1014a85:	movq   $0x0,-0x20(%rbp)
 1014a8d:	mov    0x30(%rdi),%r15
 1014a91:	test   %r15,%r15
 1014a94:	je     1014abe <fail+0x51>
 1014a96:	lea    -0x20(%rbp),%r14
 1014a9a:	mov    0x8(%r15),%rsi
 1014a9e:	mov    0x10(%r15),%rdx
 1014aa2:	mov    %rbx,%rdi
 1014aa5:	xor    %ecx,%ecx
 1014aa7:	mov    %r14,%r8
 1014aaa:	call   1014b10 <trace_frame>
 1014aaf:	mov    (%r15),%r15
 1014ab2:	test   %r15,%r15
 1014ab5:	jne    1014a9a <fail+0x2d>
 1014ab7:	cmpq   $0x0,0x30(%rbx)
 1014abc:	jne    1014aca <fail+0x5d>
 1014abe:	lea    -0x20(%rbp),%rsi
 1014ac2:	mov    %rbx,%rdi
 1014ac5:	call   1014c60 <walk_frames>
 1014aca:	mov    -0x20(%rbp),%rax
 1014ace:	xor    %ecx,%ecx
 1014ad0:	sub    0x248(%rbx),%rax
 1014ad7:	cmovae %rax,%rcx
 1014adb:	mov    %rcx,0x250(%rbx)
 1014ae2:	cmpq   $0x0,0x3e60(%rbx)
 1014aea:	jne    1014af7 <fail+0x8a>
 1014aec:	add    $0x8,%rsp
 1014af0:	pop    %rbx
 1014af1:	pop    %r14
 1014af3:	pop    %r15
 1014af5:	pop    %rbp
 1014af6:	ret
 1014af7:	mov    %rbx,%rdi
 1014afa:	call   1014630 <myl_qbe_rc_trap>
 1014aff:	mov    0x3e60(%rbx),%rdi
 1014b06:	mov    $0x1,%esi
 1014b0b:	call   10276a0 <longjmp@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
