
.tmp/cold-hint/raytrace.llvm:     file format elf64-x86-64


Disassembly of section .text:

0000000001012650 <entry_run>:
 1012650:	push   %rbp
 1012651:	mov    %rsp,%rbp
 1012654:	push   %r15
 1012656:	push   %r14
 1012658:	push   %r13
 101265a:	push   %r12
 101265c:	push   %rbx
 101265d:	sub    $0x408,%rsp
 1012664:	cmpq   $0x0,0x39a8(%rdi)
 101266c:	mov    %rdi,-0x30(%rbp)
 1012670:	je     1012682 <entry_run+0x32>
 1012672:	cmpq   $0x0,0x20(%rdi)
 1012677:	jne    1014488 <entry_run+0x1e38>
 101267d:	jmp    10127a5 <entry_run+0x155>
 1012682:	mov    $0x1,%edi
 1012687:	mov    $0x40,%esi
 101268c:	call   1027510 <calloc@plt>
 1012691:	test   %rax,%rax
 1012694:	je     1012778 <entry_run+0x128>
 101269a:	mov    -0x30(%rbp),%rcx
 101269e:	mov    %rax,0x39a8(%rcx)
 10126a5:	mov    0x3978(%rcx),%rcx
 10126ac:	lea    0xa0(%rcx),%rdx
 10126b3:	test   %rcx,%rcx
 10126b6:	mov    $0x1003b58,%ecx
 10126bb:	cmovne %rdx,%rcx
 10126bf:	mov    %rcx,(%rax)
 10126c2:	cmpq   $0x0,0x8(%rcx)
 10126c7:	je     10126d3 <entry_run+0x83>
 10126c9:	cmpq   $0x0,(%rcx)
 10126cd:	je     1012786 <entry_run+0x136>
 10126d3:	mov    0x10(%rcx),%rdx
 10126d7:	test   %rdx,%rdx
 10126da:	mov    $0x2710,%esi
 10126df:	cmovne %rdx,%rsi
 10126e3:	mov    %rsi,0x18(%rax)
 10126e7:	mov    0x18(%rcx),%rdx
 10126eb:	test   %rdx,%rdx
 10126ee:	mov    $0xf4240,%esi
 10126f3:	cmovne %rdx,%rsi
 10126f7:	mov    %rsi,0x10(%rax)
 10126fb:	mov    0x20(%rcx),%rdx
 10126ff:	test   %rdx,%rdx
 1012702:	mov    $0x10000,%edi
 1012707:	cmovne %rdx,%rdi
 101270b:	mov    %rdi,0x20(%rax)
 101270f:	mov    0x28(%rcx),%rsi
 1012713:	test   %rsi,%rsi
 1012716:	mov    $0x40,%edx
 101271b:	cmovne %rsi,%rdx
 101271f:	mov    %rdx,0x28(%rax)
 1012723:	mov    0x30(%rcx),%r8
 1012727:	test   %r8,%r8
 101272a:	mov    $0x100000,%esi
 101272f:	cmovne %r8,%rsi
 1012733:	mov    %rsi,0x30(%rax)
 1012737:	cmp    $0x186a0,%rdi
 101273e:	ja     1012771 <entry_run+0x121>
 1012740:	cmp    $0x80,%rdx
 1012747:	ja     1012771 <entry_run+0x121>
 1012749:	cmp    $0x4000001,%rsi
 1012750:	jae    1012771 <entry_run+0x121>
 1012752:	cmpq   $0x0,0x8(%rcx)
 1012757:	jne    101277f <entry_run+0x12f>
 1012759:	movl   $0x1,0x38(%rax)
 1012760:	mov    -0x30(%rbp),%rdi
 1012764:	cmpq   $0x0,0x20(%rdi)
 1012769:	jne    1014488 <entry_run+0x1e38>
 101276f:	jmp    10127a5 <entry_run+0x155>
 1012771:	mov    $0x1003cfa,%esi
 1012776:	jmp    101278b <entry_run+0x13b>
 1012778:	mov    $0x1003b92,%esi
 101277d:	jmp    101278b <entry_run+0x13b>
 101277f:	mov    $0x1003e41,%esi
 1012784:	jmp    101278b <entry_run+0x13b>
 1012786:	mov    $0x1003e55,%esi
 101278b:	mov    -0x30(%rbp),%rbx
 101278f:	mov    %rbx,%rdi
 1012792:	call   1014a6d <fail>
 1012797:	mov    %rbx,%rdi
 101279a:	cmpq   $0x0,0x20(%rdi)
 101279f:	jne    1014488 <entry_run+0x1e38>
 10127a5:	cmp    %rsp,0x40(%rdi)
 10127a9:	ja     10145a3 <entry_run+0x1f53>
 10127af:	movq   $0x0,-0x48(%rbp)
 10127b7:	movq   $0x0,-0x80(%rbp)
 10127bf:	mov    0x2c8(%rdi),%r15d
 10127c6:	movl   $0x0,-0x50(%rbp)
 10127cd:	cmpq   $0xffffffffffffffff,0x10(%rdi)
 10127d2:	jne    1013077 <entry_run+0xa27>
 10127d8:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 10127dd:	jne    10130c7 <entry_run+0xa77>
 10127e3:	cmpq   $0x0,0x1860(%rdi)
 10127eb:	mov    %rdi,%rbx
 10127ee:	je     101311d <entry_run+0xacd>
 10127f4:	lea    0x258(%rbx),%rdi
 10127fb:	mov    0x2c8(%rbx),%ecx
 1012801:	mov    $0x10022c8,%esi
 1012806:	mov    $0x6,%edx
 101280b:	mov    %rdi,-0x38(%rbp)
 101280f:	call   1017730 <rc_list_new>
 1012814:	test   %rax,%rax
 1012817:	je     101311d <entry_run+0xacd>
 101281d:	movabs $0x5000000000000000,%rcx
 1012827:	mov    %rax,-0x1c0(%rbp)
 101282e:	mov    %rax,-0x58(%rbp)
 1012832:	mov    -0x10(%rax),%rdx
 1012836:	lea    0x1(%rcx),%rsi
 101283a:	test   %rsi,%rdx
 101283d:	je     101297f <entry_run+0x32f>
 1012843:	test   %rcx,%rdx
 1012846:	je     1012953 <entry_run+0x303>
 101284c:	mov    0x1860(%rbx),%rdi
 1012853:	cmpq   $0x1a,0xa0(%rdi)
 101285b:	jb     10143f9 <entry_run+0x1da9>
 1012861:	mov    0x98(%rdi),%rax
 1012868:	cmpq   $0x1002338,0x190(%rax)
 1012873:	jne    10143f9 <entry_run+0x1da9>
 1012879:	mov    0x198(%rax),%r12
 1012880:	test   %r12,%r12
 1012883:	je     1014413 <entry_run+0x1dc3>
 1012889:	mov    0x8(%r12),%r14
 101288e:	cmpl   $0x1,0x8(%r14)
 1012893:	jne    101298c <entry_run+0x33c>
 1012899:	movq   $0x0,-0xf8(%rbp)
 10128a4:	mov    0x1860(%rbx),%rcx
 10128ab:	test   %rcx,%rcx
 10128ae:	je     10144fc <entry_run+0x1eac>
 10128b4:	mov    $0x3,%eax
 10128b9:	cmp    0x2c8(%rbx),%r15d
 10128c0:	ja     1012a1c <entry_run+0x3cc>
 10128c6:	mov    -0x58(%rbp),%rax
 10128ca:	test   %rax,%rax
 10128cd:	je     1012915 <entry_run+0x2c5>
 10128cf:	mov    -0x10(%rax),%rdx
 10128d3:	test   $0x2,%dl
 10128d6:	jne    1012915 <entry_run+0x2c5>
 10128d8:	movabs $0x4000000000000002,%rsi
 10128e2:	add    $0xfffffffffffffffe,%rsi
 10128e6:	test   %rsi,%rdx
 10128e9:	sete   %sil
 10128ed:	mov    %rdx,%rdi
 10128f0:	shr    $0x28,%rdi
 10128f4:	and    $0xfffff,%edi
 10128fa:	cmp    %r15d,%edi
 10128fd:	setbe  %dil
 1012901:	bt     $0x3c,%rdx
 1012906:	jb     1014300 <entry_run+0x1cb0>
 101290c:	or     %dil,%sil
 101290f:	je     1014300 <entry_run+0x1cb0>
 1012915:	mov    %rax,-0xf8(%rbp)
 101291c:	movq   $0x0,-0x58(%rbp)
 1012924:	cmpq   $0x0,0xc8(%rcx)
 101292c:	je     1012937 <entry_run+0x2e7>
 101292e:	mov    -0x38(%rbp),%rdi
 1012932:	call   101bcb0 <myl_rc_drain>
 1012937:	mov    -0xf8(%rbp),%rax
 101293e:	mov    %rax,-0x1c0(%rbp)
 1012945:	mov    $0x1,%edx
 101294a:	mov    -0x30(%rbp),%rbx
 101294e:	jmp    1012a2b <entry_run+0x3db>
 1012953:	lea    -0x58(%rbp),%rcx
 1012957:	lea    -0x1c0(%rbp),%rdx
 101295e:	mov    %rdx,%rsi
 1012961:	sub    %rcx,%rsi
 1012964:	sub    %rdx,%rcx
 1012967:	cmovb  %rsi,%rcx
 101296b:	mov    -0x30(%rbp),%rbx
 101296f:	test   %rcx,%rcx
 1012972:	je     101284c <entry_run+0x1fc>
 1012978:	mov    %rax,-0x1c0(%rbp)
 101297f:	movq   $0x0,-0x58(%rbp)
 1012987:	jmp    1012a33 <entry_run+0x3e3>
 101298c:	mov    0x1860(%rbx),%rax
 1012993:	cmpq   $0x0,0xc8(%rax)
 101299b:	je     1012ff7 <entry_run+0x9a7>
 10129a1:	mov    %r14,-0xf8(%rbp)
 10129a8:	lea    -0x260(%rbp),%rdx
 10129af:	mov    %rdx,-0xf0(%rbp)
 10129b6:	movq   $0x0,-0xe8(%rbp)
 10129c1:	mov    %r15d,-0xe0(%rbp)
 10129c8:	movl   $0x0,-0xdc(%rbp)
 10129d2:	lea    -0x58(%rbp),%rcx
 10129d6:	mov    -0x38(%rbp),%rdi
 10129da:	mov    %r12,%rsi
 10129dd:	mov    %r15d,%r8d
 10129e0:	call   1023650 <flat_transfer>
 10129e5:	test   %eax,%eax
 10129e7:	jns    1012a00 <entry_run+0x3b0>
 10129e9:	lea    -0xf8(%rbp),%rsi
 10129f0:	lea    -0x58(%rbp),%rcx
 10129f4:	mov    -0x38(%rbp),%rdi
 10129f8:	mov    %r14,%rdx
 10129fb:	call   101e980 <transfer>
 1012a00:	test   %eax,%eax
 1012a02:	mov    -0x30(%rbp),%rbx
 1012a06:	je     1013125 <entry_run+0xad5>
 1012a0c:	mov    0x1860(%rbx),%rcx
 1012a13:	test   %rcx,%rcx
 1012a16:	je     10144fc <entry_run+0x1eac>
 1012a1c:	xor    %edx,%edx
 1012a1e:	cmpl   $0x0,0x124(%rcx)
 1012a25:	je     1012fe4 <entry_run+0x994>
 1012a2b:	test   %edx,%edx
 1012a2d:	je     1014463 <entry_run+0x1e13>
 1012a33:	movabs $0x6000000000000002,%rbx
 1012a3d:	mov    -0x1c0(%rbp),%r12
 1012a44:	mov    %r12,-0x48(%rbp)
 1012a48:	movl   $0x1,-0x50(%rbp)
 1012a4f:	movq   $0x0,-0xf8(%rbp)
 1012a5a:	movabs $0xc08f400000000000,%rax
 1012a64:	mov    %rax,-0xf0(%rbp)
 1012a6b:	vmovapd -0x110b3(%rip),%ymm0        # 10019c0 <__abi_tag+0x16c4>
 1012a73:	vmovupd %ymm0,-0xe8(%rbp)
 1012a7b:	movabs $0x3fe0000000000000,%rax
 1012a85:	mov    %rax,-0xc8(%rbp)
 1012a8c:	test   %r12,%r12
 1012a8f:	je     1012acd <entry_run+0x47d>
 1012a91:	test   %rbx,-0x10(%r12)
 1012a96:	jne    1012aa0 <entry_run+0x450>
 1012a98:	cmpq   $0x2,-0x20(%r12)
 1012a9e:	jb     1012ac0 <entry_run+0x470>
 1012aa0:	lea    -0x48(%rbp),%rsi
 1012aa4:	lea    -0x50(%rbp),%rdx
 1012aa8:	mov    -0x30(%rbp),%rdi
 1012aac:	vzeroupper
 1012aaf:	call   1014750 <myl_qbe_rc_unique_local>
 1012ab4:	test   %eax,%eax
 1012ab6:	je     1014488 <entry_run+0x1e38>
 1012abc:	mov    -0x48(%rbp),%r12
 1012ac0:	mov    (%r12),%rdx
 1012ac4:	cmp    0x8(%r12),%rdx
 1012ac9:	jb     1012adb <entry_run+0x48b>
 1012acb:	jmp    1012aff <entry_run+0x4af>
 1012acd:	xor    %r12d,%r12d
 1012ad0:	mov    (%r12),%rdx
 1012ad4:	cmp    0x8(%r12),%rdx
 1012ad9:	jae    1012aff <entry_run+0x4af>
 1012adb:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012ae1:	je     1012aff <entry_run+0x4af>
 1012ae3:	mov    0x20(%r12),%rax
 1012ae8:	lea    -0xf8(%rbp),%rsi
 1012aef:	sub    %rax,%rsi
 1012af2:	imul   $0x38,%rdx,%rcx
 1012af6:	cmp    %rcx,%rsi
 1012af9:	jae    1012f8c <entry_run+0x93c>
 1012aff:	lea    -0xf8(%rbp),%rcx
 1012b06:	mov    -0x38(%rbp),%rdi
 1012b0a:	mov    %r12,%rsi
 1012b0d:	vzeroupper
 1012b10:	call   1017d90 <rc_list_insert_at>
 1012b15:	test   %eax,%eax
 1012b17:	je     10145a8 <entry_run+0x1f58>
 1012b1d:	mov    %r15d,-0x40(%rbp)
 1012b21:	vxorpd %xmm0,%xmm0,%xmm0
 1012b25:	vmovapd %xmm0,-0x380(%rbp)
 1012b2d:	movabs $0xc008000000000000,%rax
 1012b37:	mov    %rax,-0x370(%rbp)
 1012b3e:	vmovapd -0x111e6(%rip),%ymm0        # 1001960 <__abi_tag+0x1664>
 1012b46:	vmovupd %ymm0,-0x368(%rbp)
 1012b4e:	test   %r12,%r12
 1012b51:	je     1012b8f <entry_run+0x53f>
 1012b53:	test   %rbx,-0x10(%r12)
 1012b58:	jne    1012b62 <entry_run+0x512>
 1012b5a:	cmpq   $0x2,-0x20(%r12)
 1012b60:	jb     1012b82 <entry_run+0x532>
 1012b62:	lea    -0x48(%rbp),%rsi
 1012b66:	lea    -0x50(%rbp),%rdx
 1012b6a:	mov    -0x30(%rbp),%rdi
 1012b6e:	vzeroupper
 1012b71:	call   1014750 <myl_qbe_rc_unique_local>
 1012b76:	test   %eax,%eax
 1012b78:	je     1014488 <entry_run+0x1e38>
 1012b7e:	mov    -0x48(%rbp),%r12
 1012b82:	mov    (%r12),%rdx
 1012b86:	cmp    0x8(%r12),%rdx
 1012b8b:	jb     1012b9d <entry_run+0x54d>
 1012b8d:	jmp    1012bc1 <entry_run+0x571>
 1012b8f:	xor    %r12d,%r12d
 1012b92:	mov    (%r12),%rdx
 1012b96:	cmp    0x8(%r12),%rdx
 1012b9b:	jae    1012bc1 <entry_run+0x571>
 1012b9d:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012ba3:	je     1012bc1 <entry_run+0x571>
 1012ba5:	mov    0x20(%r12),%rax
 1012baa:	lea    -0x380(%rbp),%rsi
 1012bb1:	sub    %rax,%rsi
 1012bb4:	imul   $0x38,%rdx,%rcx
 1012bb8:	cmp    %rcx,%rsi
 1012bbb:	jae    1012fb8 <entry_run+0x968>
 1012bc1:	lea    -0x380(%rbp),%rcx
 1012bc8:	mov    -0x38(%rbp),%rdi
 1012bcc:	mov    %r12,%rsi
 1012bcf:	vzeroupper
 1012bd2:	call   1017d90 <rc_list_insert_at>
 1012bd7:	test   %eax,%eax
 1012bd9:	je     10145b1 <entry_run+0x1f61>
 1012bdf:	movabs $0xc010000000000000,%r15
 1012be9:	movabs $0xc000000000000000,%r13
 1012bf3:	mov    %r13,-0x340(%rbp)
 1012bfa:	movq   $0x0,-0x338(%rbp)
 1012c05:	mov    %r15,-0x330(%rbp)
 1012c0c:	vmovapd -0x112d4(%rip),%ymm0        # 1001940 <__abi_tag+0x1644>
 1012c14:	vmovupd %ymm0,-0x328(%rbp)
 1012c1c:	test   %r12,%r12
 1012c1f:	je     1012c5d <entry_run+0x60d>
 1012c21:	test   %rbx,-0x10(%r12)
 1012c26:	jne    1012c30 <entry_run+0x5e0>
 1012c28:	cmpq   $0x2,-0x20(%r12)
 1012c2e:	jb     1012c50 <entry_run+0x600>
 1012c30:	lea    -0x48(%rbp),%rsi
 1012c34:	lea    -0x50(%rbp),%rdx
 1012c38:	mov    -0x30(%rbp),%rdi
 1012c3c:	vzeroupper
 1012c3f:	call   1014750 <myl_qbe_rc_unique_local>
 1012c44:	test   %eax,%eax
 1012c46:	je     1014488 <entry_run+0x1e38>
 1012c4c:	mov    -0x48(%rbp),%r12
 1012c50:	mov    (%r12),%rdx
 1012c54:	cmp    0x8(%r12),%rdx
 1012c59:	jb     1012c6b <entry_run+0x61b>
 1012c5b:	jmp    1012c8f <entry_run+0x63f>
 1012c5d:	xor    %r12d,%r12d
 1012c60:	mov    (%r12),%rdx
 1012c64:	cmp    0x8(%r12),%rdx
 1012c69:	jae    1012c8f <entry_run+0x63f>
 1012c6b:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012c71:	je     1012c8f <entry_run+0x63f>
 1012c73:	mov    0x20(%r12),%rax
 1012c78:	lea    -0x340(%rbp),%rsi
 1012c7f:	sub    %rax,%rsi
 1012c82:	imul   $0x38,%rdx,%rcx
 1012c86:	cmp    %rcx,%rsi
 1012c89:	jae    101304b <entry_run+0x9fb>
 1012c8f:	lea    -0x340(%rbp),%rcx
 1012c96:	mov    -0x38(%rbp),%rdi
 1012c9a:	mov    %r12,%rsi
 1012c9d:	vzeroupper
 1012ca0:	call   1017d90 <rc_list_insert_at>
 1012ca5:	test   %eax,%eax
 1012ca7:	je     10145ba <entry_run+0x1f6a>
 1012cad:	movabs $0x4000000000000002,%rax
 1012cb7:	lea    -0x2(%rax),%r14
 1012cbb:	mov    %r14,-0x308(%rbp)
 1012cc2:	movq   $0x0,-0x300(%rbp)
 1012ccd:	mov    %r15,-0x2f8(%rbp)
 1012cd4:	vmovapd -0x1133c(%rip),%ymm0        # 10019a0 <__abi_tag+0x16a4>
 1012cdc:	vmovupd %ymm0,-0x2f0(%rbp)
 1012ce4:	test   %r12,%r12
 1012ce7:	je     1012d2f <entry_run+0x6df>
 1012ce9:	test   %rbx,-0x10(%r12)
 1012cee:	movabs $0x4000000000000002,%r15
 1012cf8:	jne    1012d02 <entry_run+0x6b2>
 1012cfa:	cmpq   $0x2,-0x20(%r12)
 1012d00:	jb     1012d22 <entry_run+0x6d2>
 1012d02:	lea    -0x48(%rbp),%rsi
 1012d06:	lea    -0x50(%rbp),%rdx
 1012d0a:	mov    -0x30(%rbp),%rdi
 1012d0e:	vzeroupper
 1012d11:	call   1014750 <myl_qbe_rc_unique_local>
 1012d16:	test   %eax,%eax
 1012d18:	je     1014488 <entry_run+0x1e38>
 1012d1e:	mov    -0x48(%rbp),%r12
 1012d22:	mov    (%r12),%rdx
 1012d26:	cmp    0x8(%r12),%rdx
 1012d2b:	jb     1012d47 <entry_run+0x6f7>
 1012d2d:	jmp    1012d6b <entry_run+0x71b>
 1012d2f:	xor    %r12d,%r12d
 1012d32:	movabs $0x4000000000000002,%r15
 1012d3c:	mov    (%r12),%rdx
 1012d40:	cmp    0x8(%r12),%rdx
 1012d45:	jae    1012d6b <entry_run+0x71b>
 1012d47:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012d4d:	je     1012d6b <entry_run+0x71b>
 1012d4f:	mov    0x20(%r12),%rax
 1012d54:	lea    -0x308(%rbp),%rsi
 1012d5b:	sub    %rax,%rsi
 1012d5e:	imul   $0x38,%rdx,%rcx
 1012d62:	cmp    %rcx,%rsi
 1012d65:	jae    1013145 <entry_run+0xaf5>
 1012d6b:	lea    -0x308(%rbp),%rcx
 1012d72:	mov    -0x38(%rbp),%rdi
 1012d76:	mov    %r12,%rsi
 1012d79:	vzeroupper
 1012d7c:	call   1017d90 <rc_list_insert_at>
 1012d81:	test   %eax,%eax
 1012d83:	je     10145c3 <entry_run+0x1f73>
 1012d89:	movq   $0x0,-0x2d0(%rbp)
 1012d94:	mov    %r14,-0x2c8(%rbp)
 1012d9b:	movabs $0xc018000000000000,%rax
 1012da5:	mov    %rax,-0x2c0(%rbp)
 1012dac:	vmovapd -0x113d4(%rip),%ymm0        # 10019e0 <__abi_tag+0x16e4>
 1012db4:	vmovupd %ymm0,-0x2b8(%rbp)
 1012dbc:	test   %r12,%r12
 1012dbf:	je     1012dfd <entry_run+0x7ad>
 1012dc1:	test   %rbx,-0x10(%r12)
 1012dc6:	jne    1012dd0 <entry_run+0x780>
 1012dc8:	cmpq   $0x2,-0x20(%r12)
 1012dce:	jb     1012df0 <entry_run+0x7a0>
 1012dd0:	lea    -0x48(%rbp),%rsi
 1012dd4:	lea    -0x50(%rbp),%rdx
 1012dd8:	mov    -0x30(%rbp),%rdi
 1012ddc:	vzeroupper
 1012ddf:	call   1014750 <myl_qbe_rc_unique_local>
 1012de4:	test   %eax,%eax
 1012de6:	je     1014488 <entry_run+0x1e38>
 1012dec:	mov    -0x48(%rbp),%r12
 1012df0:	mov    (%r12),%rdx
 1012df4:	cmp    0x8(%r12),%rdx
 1012df9:	jb     1012e0b <entry_run+0x7bb>
 1012dfb:	jmp    1012e2f <entry_run+0x7df>
 1012dfd:	xor    %r12d,%r12d
 1012e00:	mov    (%r12),%rdx
 1012e04:	cmp    0x8(%r12),%rdx
 1012e09:	jae    1012e2f <entry_run+0x7df>
 1012e0b:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012e11:	je     1012e2f <entry_run+0x7df>
 1012e13:	mov    0x20(%r12),%rax
 1012e18:	lea    -0x2d0(%rbp),%rsi
 1012e1f:	sub    %rax,%rsi
 1012e22:	imul   $0x38,%rdx,%rcx
 1012e26:	cmp    %rcx,%rsi
 1012e29:	jae    10131d5 <entry_run+0xb85>
 1012e2f:	lea    -0x2d0(%rbp),%rcx
 1012e36:	mov    -0x38(%rbp),%rdi
 1012e3a:	mov    %r12,%rsi
 1012e3d:	vzeroupper
 1012e40:	call   1017d90 <rc_list_insert_at>
 1012e45:	test   %eax,%eax
 1012e47:	je     10145cc <entry_run+0x1f7c>
 1012e4d:	movabs $0xbff8000000000000,%rax
 1012e57:	mov    %rax,-0x298(%rbp)
 1012e5e:	movabs $0xbfe0000000000000,%rax
 1012e68:	mov    %rax,-0x290(%rbp)
 1012e6f:	mov    %r13,-0x288(%rbp)
 1012e76:	vmovapd -0x114fe(%rip),%ymm0        # 1001980 <__abi_tag+0x1684>
 1012e7e:	vmovupd %ymm0,-0x280(%rbp)
 1012e86:	test   %r12,%r12
 1012e89:	je     1012ec7 <entry_run+0x877>
 1012e8b:	test   %rbx,-0x10(%r12)
 1012e90:	jne    1012e9a <entry_run+0x84a>
 1012e92:	cmpq   $0x2,-0x20(%r12)
 1012e98:	jb     1012eba <entry_run+0x86a>
 1012e9a:	lea    -0x48(%rbp),%rsi
 1012e9e:	lea    -0x50(%rbp),%rdx
 1012ea2:	mov    -0x30(%rbp),%rdi
 1012ea6:	vzeroupper
 1012ea9:	call   1014750 <myl_qbe_rc_unique_local>
 1012eae:	test   %eax,%eax
 1012eb0:	je     1014488 <entry_run+0x1e38>
 1012eb6:	mov    -0x48(%rbp),%r12
 1012eba:	mov    (%r12),%rdx
 1012ebe:	cmp    0x8(%r12),%rdx
 1012ec3:	jb     1012ed5 <entry_run+0x885>
 1012ec5:	jmp    1012ef9 <entry_run+0x8a9>
 1012ec7:	xor    %r12d,%r12d
 1012eca:	mov    (%r12),%rdx
 1012ece:	cmp    0x8(%r12),%rdx
 1012ed3:	jae    1012ef9 <entry_run+0x8a9>
 1012ed5:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012edb:	je     1012ef9 <entry_run+0x8a9>
 1012edd:	mov    0x20(%r12),%rax
 1012ee2:	lea    -0x298(%rbp),%rsi
 1012ee9:	sub    %rax,%rsi
 1012eec:	imul   $0x38,%rdx,%rcx
 1012ef0:	cmp    %rcx,%rsi
 1012ef3:	jae    1013201 <entry_run+0xbb1>
 1012ef9:	lea    -0x298(%rbp),%rcx
 1012f00:	mov    -0x38(%rbp),%rdi
 1012f04:	mov    %r12,%rsi
 1012f07:	vzeroupper
 1012f0a:	call   1017d90 <rc_list_insert_at>
 1012f0f:	test   %eax,%eax
 1012f11:	mov    -0x30(%rbp),%rdi
 1012f15:	je     10145dd <entry_run+0x1f8d>
 1012f1b:	mov    %r12,-0x58(%rbp)
 1012f1f:	test   %r12,%r12
 1012f22:	je     1013239 <entry_run+0xbe9>
 1012f28:	mov    -0x10(%r12),%rax
 1012f2d:	test   %r15,%rax
 1012f30:	je     1013171 <entry_run+0xb21>
 1012f36:	test   %r14,%rax
 1012f39:	je     1013184 <entry_run+0xb34>
 1012f3f:	lea    -0x1c0(%rbp),%rdx
 1012f46:	lea    -0x58(%rbp),%rcx
 1012f4a:	mov    $0x1002338,%esi
 1012f4f:	mov    -0x38(%rbp),%rdi
 1012f53:	mov    -0x40(%rbp),%r8d
 1012f57:	vzeroupper
 1012f5a:	call   1023970 <myl_rc_native_retain>
 1012f5f:	test   %eax,%eax
 1012f61:	je     10142d2 <entry_run+0x1c82>
 1012f67:	mov    -0x1c0(%rbp),%rax
 1012f6e:	mov    %rax,-0x80(%rbp)
 1012f72:	cmpl   $0x0,-0x50(%rbp)
 1012f76:	mov    -0x30(%rbp),%rdi
 1012f7a:	je     1013251 <entry_run+0xc01>
 1012f80:	movl   $0x0,-0x50(%rbp)
 1012f87:	jmp    10131a9 <entry_run+0xb59>
 1012f8c:	vmovupd -0xf8(%rbp),%ymm0
 1012f94:	vmovupd -0xe0(%rbp),%ymm1
 1012f9c:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1012fa2:	vmovupd %ymm0,(%rax,%rcx,1)
 1012fa7:	inc    %rdx
 1012faa:	mov    %rdx,(%r12)
 1012fae:	incq   0x10(%r12)
 1012fb3:	jmp    1012b1d <entry_run+0x4cd>
 1012fb8:	vmovupd -0x380(%rbp),%ymm0
 1012fc0:	vmovupd -0x368(%rbp),%ymm1
 1012fc8:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1012fce:	vmovupd %ymm0,(%rax,%rcx,1)
 1012fd3:	inc    %rdx
 1012fd6:	mov    %rdx,(%r12)
 1012fda:	incq   0x10(%r12)
 1012fdf:	jmp    1012bdf <entry_run+0x58f>
 1012fe4:	mov    %eax,0x124(%rcx)
 1012fea:	test   %edx,%edx
 1012fec:	jne    1012a33 <entry_run+0x3e3>
 1012ff2:	jmp    1014463 <entry_run+0x1e13>
 1012ff7:	lea    -0x1c0(%rbp),%rdx
 1012ffe:	lea    -0x58(%rbp),%rcx
 1013002:	mov    -0x38(%rbp),%rdi
 1013006:	mov    %r12,%rsi
 1013009:	mov    %r15d,%r8d
 101300c:	call   1023650 <flat_transfer>
 1013011:	test   %eax,%eax
 1013013:	js     10129a1 <entry_run+0x351>
 1013019:	mov    -0x30(%rbp),%rbx
 101301d:	je     1012a33 <entry_run+0x3e3>
 1013023:	mov    0x1860(%rbx),%rcx
 101302a:	test   %rcx,%rcx
 101302d:	je     10144fc <entry_run+0x1eac>
 1013033:	cmpl   $0x0,0x124(%rcx)
 101303a:	jne    1014463 <entry_run+0x1e13>
 1013040:	mov    %eax,0x124(%rcx)
 1013046:	jmp    1014463 <entry_run+0x1e13>
 101304b:	vmovupd -0x340(%rbp),%ymm0
 1013053:	vmovupd -0x328(%rbp),%ymm1
 101305b:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1013061:	vmovupd %ymm0,(%rax,%rcx,1)
 1013066:	inc    %rdx
 1013069:	mov    %rdx,(%r12)
 101306d:	incq   0x10(%r12)
 1013072:	jmp    1012cad <entry_run+0x65d>
 1013077:	cmpq   $0x0,0x20(%rdi)
 101307c:	jne    10130a7 <entry_run+0xa57>
 101307e:	movl   $0x1,0x39e8(%rdi)
 1013088:	vxorpd %xmm0,%xmm0,%xmm0
 101308c:	vmovupd %ymm0,0x39ec(%rdi)
 1013094:	vmovupd %ymm0,0x39f8(%rdi)
 101309c:	movq   $0x1003f61,0x3a18(%rdi)
 10130a7:	mov    $0x100442d,%esi
 10130ac:	mov    -0x30(%rbp),%rdi
 10130b0:	vzeroupper
 10130b3:	call   1014a6d <fail>
 10130b8:	mov    -0x30(%rbp),%rdi
 10130bc:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 10130c1:	je     10127e3 <entry_run+0x193>
 10130c7:	cmpq   $0x0,0x20(%rdi)
 10130cc:	jne    10130f7 <entry_run+0xaa7>
 10130ce:	movl   $0x1,0x39e8(%rdi)
 10130d8:	vxorpd %xmm0,%xmm0,%xmm0
 10130dc:	vmovupd %ymm0,0x39ec(%rdi)
 10130e4:	vmovupd %ymm0,0x39f8(%rdi)
 10130ec:	movq   $0x1003faa,0x3a18(%rdi)
 10130f7:	mov    $0x1004442,%esi
 10130fc:	mov    -0x30(%rbp),%rdi
 1013100:	vzeroupper
 1013103:	call   1014a6d <fail>
 1013108:	mov    -0x30(%rbp),%rdi
 101310c:	cmpq   $0x0,0x1860(%rdi)
 1013114:	mov    %rdi,%rbx
 1013117:	jne    10127f4 <entry_run+0x1a4>
 101311d:	mov    %rbx,%rdi
 1013120:	call   1015110 <myl_qbe_fail_allocation>
 1013125:	mov    -0x260(%rbp),%rax
 101312c:	mov    %rax,-0x1c0(%rbp)
 1013133:	mov    $0x1,%edx
 1013138:	test   %edx,%edx
 101313a:	jne    1012a33 <entry_run+0x3e3>
 1013140:	jmp    1014463 <entry_run+0x1e13>
 1013145:	vmovupd -0x308(%rbp),%ymm0
 101314d:	vmovupd -0x2f0(%rbp),%ymm1
 1013155:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 101315b:	vmovupd %ymm0,(%rax,%rcx,1)
 1013160:	inc    %rdx
 1013163:	mov    %rdx,(%r12)
 1013167:	incq   0x10(%r12)
 101316c:	jmp    1012d89 <entry_run+0x739>
 1013171:	mov    -0x20(%r12),%rax
 1013176:	inc    %rax
 1013179:	je     10143b1 <entry_run+0x1d61>
 101317f:	mov    %rax,-0x20(%r12)
 1013184:	mov    %r12,-0x1c0(%rbp)
 101318b:	mov    %r12,-0x80(%rbp)
 101318f:	cmpl   $0x0,-0x50(%rbp)
 1013193:	je     1013251 <entry_run+0xc01>
 1013199:	movl   $0x0,-0x50(%rbp)
 10131a0:	test   %r12,%r12
 10131a3:	je     1013251 <entry_run+0xc01>
 10131a9:	test   %r15,-0x10(%r12)
 10131ae:	jne    10131cb <entry_run+0xb7b>
 10131b0:	mov    -0x20(%r12),%rax
 10131b5:	dec    %rax
 10131b8:	jne    10131c6 <entry_run+0xb76>
 10131ba:	cmpq   $0x0,-0x18(%r12)
 10131c0:	je     10143c3 <entry_run+0x1d73>
 10131c6:	mov    %rax,-0x20(%r12)
 10131cb:	movq   $0x0,-0x48(%rbp)
 10131d3:	jmp    1013251 <entry_run+0xc01>
 10131d5:	vmovupd -0x2d0(%rbp),%ymm0
 10131dd:	vmovupd -0x2b8(%rbp),%ymm1
 10131e5:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10131eb:	vmovupd %ymm0,(%rax,%rcx,1)
 10131f0:	inc    %rdx
 10131f3:	mov    %rdx,(%r12)
 10131f7:	incq   0x10(%r12)
 10131fc:	jmp    1012e4d <entry_run+0x7fd>
 1013201:	vmovupd -0x298(%rbp),%ymm0
 1013209:	vmovupd -0x280(%rbp),%ymm1
 1013211:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1013217:	vmovupd %ymm0,(%rax,%rcx,1)
 101321c:	inc    %rdx
 101321f:	mov    %rdx,(%r12)
 1013223:	incq   0x10(%r12)
 1013228:	mov    -0x30(%rbp),%rdi
 101322c:	mov    %r12,-0x58(%rbp)
 1013230:	test   %r12,%r12
 1013233:	jne    1012f28 <entry_run+0x8d8>
 1013239:	mov    %r12,-0x1c0(%rbp)
 1013240:	mov    %r12,-0x80(%rbp)
 1013244:	mov    -0x50(%rbp),%eax
 1013247:	xor    %ecx,%ecx
 1013249:	test   %eax,%eax
 101324b:	cmove  %eax,%ecx
 101324e:	mov    %ecx,-0x50(%rbp)
 1013251:	movabs $0x3ff0000000000000,%rax
 101325b:	mov    %rax,-0x158(%rbp)
 1013262:	mov    %rax,-0x150(%rbp)
 1013269:	mov    %rax,-0x148(%rbp)
 1013270:	cmp    %rsp,0x40(%rdi)
 1013274:	ja     10145d5 <entry_run+0x1f85>
 101327a:	vmovsd -0x158(%rbp),%xmm2
 1013282:	vmovsd -0x150(%rbp),%xmm3
 101328a:	vmulsd %xmm2,%xmm2,%xmm0
 101328e:	vmulsd %xmm3,%xmm3,%xmm1
 1013292:	vaddsd %xmm1,%xmm0,%xmm0
 1013296:	vmovsd -0x148(%rbp),%xmm4
 101329e:	vmulsd %xmm4,%xmm4,%xmm1
 10132a2:	vaddsd %xmm1,%xmm0,%xmm0
 10132a6:	vxorpd %xmm5,%xmm5,%xmm5
 10132aa:	vucomisd %xmm5,%xmm0
 10132ae:	jb     10132b6 <entry_run+0xc66>
 10132b0:	vsqrtsd %xmm0,%xmm0,%xmm0
 10132b4:	jmp    10132e4 <entry_run+0xc94>
 10132b6:	vmovsd %xmm2,-0x40(%rbp)
 10132bb:	vmovsd %xmm3,-0x70(%rbp)
 10132c0:	vmovsd %xmm4,-0x78(%rbp)
 10132c5:	vzeroupper
 10132c8:	call   1027650 <sqrt@plt>
 10132cd:	vmovsd -0x78(%rbp),%xmm4
 10132d2:	vmovsd -0x70(%rbp),%xmm3
 10132d7:	vmovsd -0x40(%rbp),%xmm2
 10132dc:	vxorpd %xmm5,%xmm5,%xmm5
 10132e0:	mov    -0x30(%rbp),%rdi
 10132e4:	vmovsd -0x118cc(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 10132ec:	vdivsd %xmm0,%xmm1,%xmm0
 10132f0:	vmulsd %xmm0,%xmm2,%xmm1
 10132f4:	vmulsd %xmm0,%xmm3,%xmm2
 10132f8:	vmulsd %xmm0,%xmm4,%xmm0
 10132fc:	vmovsd %xmm1,-0xa8(%rbp)
 1013304:	vmovsd %xmm2,-0xa0(%rbp)
 101330c:	vmovsd %xmm0,-0x98(%rbp)
 1013314:	vxorpd %xmm0,%xmm0,%xmm0
 1013318:	vmovapd %xmm0,-0x110(%rbp)
 1013320:	movq   $0x0,-0x100(%rbp)
 101332b:	xor    %r13d,%r13d
 101332e:	mov    $0x3f,%bl
 1013330:	vmovsd -0x118d8(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013338:	xor    %eax,%eax
 101333a:	jmp    1013356 <entry_run+0xd06>
 101333c:	nopl   0x0(%rax)
 1013340:	mov    -0x118(%rbp),%rax
 1013347:	inc    %rax
 101334a:	cmp    $0x438,%rax
 1013350:	je     1013f05 <entry_run+0x18b5>
 1013356:	mov    %rax,-0x118(%rbp)
 101335d:	vcvtsi2sd %rax,%xmm15,%xmm0
 1013362:	vaddsd -0x1192a(%rip),%xmm0,%xmm0        # 1001a40 <__abi_tag+0x1744>
 101336a:	vaddsd %xmm0,%xmm0,%xmm0
 101336e:	vdivsd -0x11966(%rip),%xmm0,%xmm0        # 1001a10 <__abi_tag+0x1714>
 1013376:	vaddsd -0x1195e(%rip),%xmm0,%xmm0        # 1001a20 <__abi_tag+0x1724>
 101337e:	vmovsd %xmm0,-0x120(%rbp)
 1013386:	xor    %ecx,%ecx
 1013388:	nopl   0x0(%rax,%rax,1)
 1013390:	vcvtsi2sd %rcx,%xmm15,%xmm0
 1013395:	vaddsd -0x1195d(%rip),%xmm0,%xmm0        # 1001a40 <__abi_tag+0x1744>
 101339d:	vaddsd %xmm0,%xmm0,%xmm0
 10133a1:	vdivsd -0x11951(%rip),%xmm0,%xmm0        # 1001a58 <__abi_tag+0x175c>
 10133a9:	vaddsd -0x119b1(%rip),%xmm0,%xmm0        # 1001a00 <__abi_tag+0x1704>
 10133b1:	vmulsd -0x11989(%rip),%xmm0,%xmm0        # 1001a30 <__abi_tag+0x1734>
 10133b9:	vmovsd %xmm0,-0x140(%rbp)
 10133c1:	vmovsd -0x120(%rbp),%xmm0
 10133c9:	vmovsd %xmm0,-0x138(%rbp)
 10133d1:	movabs $0xbff8000000000000,%rax
 10133db:	mov    %rax,-0x130(%rbp)
 10133e2:	cmp    %rsp,0x40(%rdi)
 10133e6:	ja     1014516 <entry_run+0x1ec6>
 10133ec:	vmovsd -0x140(%rbp),%xmm2
 10133f4:	vmovsd -0x138(%rbp),%xmm3
 10133fc:	vmulsd %xmm2,%xmm2,%xmm0
 1013400:	vmulsd %xmm3,%xmm3,%xmm1
 1013404:	vaddsd %xmm1,%xmm0,%xmm0
 1013408:	vmovsd -0x130(%rbp),%xmm4
 1013410:	vmulsd %xmm4,%xmm4,%xmm1
 1013414:	vaddsd %xmm1,%xmm0,%xmm0
 1013418:	vucomisd %xmm5,%xmm0
 101341c:	mov    %rcx,-0x128(%rbp)
 1013423:	jb     1013430 <entry_run+0xde0>
 1013425:	vsqrtsd %xmm0,%xmm0,%xmm0
 1013429:	jmp    1013466 <entry_run+0xe16>
 101342b:	nopl   0x0(%rax,%rax,1)
 1013430:	vmovsd %xmm2,-0x40(%rbp)
 1013435:	vmovsd %xmm3,-0x70(%rbp)
 101343a:	vmovsd %xmm4,-0x78(%rbp)
 101343f:	vzeroupper
 1013442:	call   1027650 <sqrt@plt>
 1013447:	vmovsd -0x78(%rbp),%xmm4
 101344c:	vmovsd -0x70(%rbp),%xmm3
 1013451:	vmovsd -0x40(%rbp),%xmm2
 1013456:	vmovsd -0x119fe(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101345e:	vxorpd %xmm5,%xmm5,%xmm5
 1013462:	mov    -0x30(%rbp),%rdi
 1013466:	vmovsd -0x11a4e(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 101346e:	vdivsd %xmm0,%xmm1,%xmm0
 1013472:	vmulsd %xmm0,%xmm2,%xmm1
 1013476:	vmulsd %xmm0,%xmm3,%xmm2
 101347a:	vmulsd %xmm0,%xmm4,%xmm0
 101347e:	vmovsd %xmm1,-0xc0(%rbp)
 1013486:	vmovsd %xmm2,-0xb8(%rbp)
 101348e:	vmovsd %xmm0,-0xb0(%rbp)
 1013496:	mov    -0x80(%rbp),%r12
 101349a:	movq   $0x0,-0x410(%rbp)
 10134a5:	movq   $0x0,-0x3f0(%rbp)
 10134b0:	movq   $0x0,-0x3d0(%rbp)
 10134bb:	cmp    %rsp,0x40(%rdi)
 10134bf:	ja     101451e <entry_run+0x1ece>
 10134c5:	test   %r15,-0x10(%r12)
 10134ca:	jne    10134df <entry_run+0xe8f>
 10134cc:	mov    -0x18(%r12),%rax
 10134d1:	inc    %rax
 10134d4:	je     1013abc <entry_run+0x146c>
 10134da:	mov    %rax,-0x18(%r12)
 10134df:	mov    %r13,-0x90(%rbp)
 10134e6:	mov    (%r12),%r13
 10134ea:	test   %r13,%r13
 10134ed:	js     1014526 <entry_run+0x1ed6>
 10134f3:	je     10137c0 <entry_run+0x1170>
 10134f9:	mov    $0xffffffffffffffff,%r14
 1013500:	mov    $0x18,%r15d
 1013506:	xor    %ebx,%ebx
 1013508:	movabs $0xbff0000000000000,%rax
 1013512:	mov    %rax,-0x88(%rbp)
 1013519:	nopl   0x0(%rax)
 1013520:	cmp    %rsp,0x40(%rdi)
 1013524:	ja     10144f4 <entry_run+0x1ea4>
 101352a:	mov    0x20(%r12),%rax
 101352f:	vmovsd -0x110(%rbp),%xmm7
 1013537:	vmovsd -0x108(%rbp),%xmm0
 101353f:	vsubsd -0x18(%r15,%rax,1),%xmm7,%xmm1
 1013546:	vsubsd -0x10(%r15,%rax,1),%xmm0,%xmm0
 101354d:	vmovsd -0x100(%rbp),%xmm2
 1013555:	vsubsd -0x8(%r15,%rax,1),%xmm2,%xmm2
 101355c:	vmovsd %xmm1,-0x260(%rbp)
 1013564:	vmovsd %xmm0,-0x258(%rbp)
 101356c:	vmovsd %xmm2,-0x250(%rbp)
 1013574:	vmovsd -0xc0(%rbp),%xmm8
 101357c:	vmulsd %xmm1,%xmm8,%xmm3
 1013580:	vmulsd -0xb8(%rbp),%xmm0,%xmm4
 1013588:	vaddsd %xmm4,%xmm3,%xmm3
 101358c:	vmulsd -0xb0(%rbp),%xmm2,%xmm4
 1013594:	vaddsd %xmm4,%xmm3,%xmm3
 1013598:	vmulsd %xmm1,%xmm1,%xmm1
 101359c:	vmulsd %xmm0,%xmm0,%xmm0
 10135a0:	vaddsd %xmm0,%xmm1,%xmm0
 10135a4:	vmulsd %xmm2,%xmm2,%xmm1
 10135a8:	vaddsd %xmm1,%xmm0,%xmm0
 10135ac:	vmovsd (%r15,%rax,1),%xmm1
 10135b2:	vmulsd %xmm1,%xmm1,%xmm1
 10135b6:	vsubsd %xmm0,%xmm1,%xmm0
 10135ba:	vmulsd %xmm3,%xmm3,%xmm1
 10135be:	vaddsd %xmm0,%xmm1,%xmm0
 10135c2:	vucomisd %xmm0,%xmm5
 10135c6:	ja     1013680 <entry_run+0x1030>
 10135cc:	vucomisd %xmm5,%xmm0
 10135d0:	jb     10135f0 <entry_run+0xfa0>
 10135d2:	vsqrtsd %xmm0,%xmm0,%xmm0
 10135d6:	vsubsd %xmm3,%xmm5,%xmm2
 10135da:	vsubsd %xmm0,%xmm2,%xmm1
 10135de:	vucomisd %xmm6,%xmm1
 10135e2:	jbe    1013634 <entry_run+0xfe4>
 10135e4:	jmp    101363e <entry_run+0xfee>
 10135e6:	cs nopw 0x0(%rax,%rax,1)
 10135f0:	vmovsd %xmm7,-0x40(%rbp)
 10135f5:	vmovsd %xmm8,-0x70(%rbp)
 10135fa:	vmovsd %xmm3,-0x78(%rbp)
 10135ff:	vzeroupper
 1013602:	call   1027650 <sqrt@plt>
 1013607:	vmovsd -0x78(%rbp),%xmm3
 101360c:	vmovsd -0x70(%rbp),%xmm8
 1013611:	vmovsd -0x40(%rbp),%xmm7
 1013616:	vmovsd -0x11bbe(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101361e:	vxorpd %xmm5,%xmm5,%xmm5
 1013622:	mov    -0x30(%rbp),%rdi
 1013626:	vsubsd %xmm3,%xmm5,%xmm2
 101362a:	vsubsd %xmm0,%xmm2,%xmm1
 101362e:	vucomisd %xmm6,%xmm1
 1013632:	ja     101363e <entry_run+0xfee>
 1013634:	vaddsd %xmm0,%xmm2,%xmm1
 1013638:	vucomisd %xmm6,%xmm1
 101363c:	jbe    1013680 <entry_run+0x1030>
 101363e:	vucomisd %xmm5,%xmm1
 1013642:	jbe    1013680 <entry_run+0x1030>
 1013644:	test   %r14,%r14
 1013647:	setns  %al
 101364a:	mov    -0x88(%rbp),%rsi
 1013651:	vmovq  %rsi,%xmm0
 1013656:	vucomisd %xmm1,%xmm0
 101365a:	vmovq  %xmm1,%rcx
 101365f:	setbe  %dl
 1013662:	test   %dl,%al
 1013664:	cmove  %rcx,%rsi
 1013668:	mov    %rsi,-0x88(%rbp)
 101366f:	cmove  %rbx,%r14
 1013673:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013680:	cmp    %r13,(%r12)
 1013684:	jne    10144ec <entry_run+0x1e9c>
 101368a:	inc    %rbx
 101368d:	add    $0x38,%r15
 1013691:	cmp    %rbx,%r13
 1013694:	jne    1013520 <entry_run+0xed0>
 101369a:	test   %r14,%r14
 101369d:	movabs $0x4000000000000002,%r15
 10136a7:	js     10137c0 <entry_run+0x1170>
 10136ad:	cmp    %r13,%r14
 10136b0:	jae    1014582 <entry_run+0x1f32>
 10136b6:	mov    0x20(%r12),%rax
 10136bb:	imul   $0x38,%r14,%rcx
 10136bf:	vmovups 0x20(%rax,%rcx,1),%xmm0
 10136c5:	mov    0x30(%rax,%rcx,1),%rdx
 10136ca:	vmovups (%rax,%rcx,1),%ymm1
 10136cf:	vmovups %ymm1,-0x260(%rbp)
 10136d7:	mov    %rdx,-0x230(%rbp)
 10136de:	vmovaps %xmm0,-0x240(%rbp)
 10136e6:	vmovsd -0x88(%rbp),%xmm0
 10136ee:	vmulsd %xmm0,%xmm8,%xmm1
 10136f2:	vmulsd -0xb8(%rbp),%xmm0,%xmm2
 10136fa:	vmulsd -0xb0(%rbp),%xmm0,%xmm0
 1013702:	vmovsd %xmm1,-0x3b0(%rbp)
 101370a:	vmovsd %xmm2,-0x3a8(%rbp)
 1013712:	vmovsd %xmm0,-0x3a0(%rbp)
 101371a:	vaddsd %xmm1,%xmm7,%xmm1
 101371e:	vaddsd -0x108(%rbp),%xmm2,%xmm2
 1013726:	vaddsd -0x100(%rbp),%xmm0,%xmm0
 101372e:	vmovsd %xmm1,-0x170(%rbp)
 1013736:	vmovsd %xmm2,-0x168(%rbp)
 101373e:	vsubsd -0x260(%rbp),%xmm1,%xmm1
 1013746:	vsubsd -0x258(%rbp),%xmm2,%xmm2
 101374e:	vmovsd %xmm0,-0x160(%rbp)
 1013756:	vsubsd -0x250(%rbp),%xmm0,%xmm0
 101375e:	vmovsd %xmm1,-0x188(%rbp)
 1013766:	vmovsd %xmm2,-0x180(%rbp)
 101376e:	vmovsd %xmm0,-0x178(%rbp)
 1013776:	cmp    %rsp,0x40(%rdi)
 101377a:	ja     1014590 <entry_run+0x1f40>
 1013780:	vmovsd -0x188(%rbp),%xmm2
 1013788:	vmovsd -0x180(%rbp),%xmm3
 1013790:	vmulsd %xmm2,%xmm2,%xmm0
 1013794:	vmulsd %xmm3,%xmm3,%xmm1
 1013798:	vaddsd %xmm1,%xmm0,%xmm0
 101379c:	vmovsd -0x178(%rbp),%xmm4
 10137a4:	vmulsd %xmm4,%xmm4,%xmm1
 10137a8:	vaddsd %xmm1,%xmm0,%xmm0
 10137ac:	vucomisd %xmm5,%xmm0
 10137b0:	mov    -0x90(%rbp),%r13
 10137b7:	jb     10137fd <entry_run+0x11ad>
 10137b9:	vsqrtsd %xmm0,%xmm0,%xmm0
 10137bd:	jmp    1013833 <entry_run+0x11e3>
 10137bf:	nop
 10137c0:	mov    -0x3f0(%rbp),%eax
 10137c6:	or     -0x410(%rbp),%eax
 10137cc:	or     -0x3d0(%rbp),%eax
 10137d2:	mov    -0x90(%rbp),%r13
 10137d9:	mov    $0x3f,%bl
 10137db:	je     1013a30 <entry_run+0x13e0>
 10137e1:	mov    0x1860(%rdi),%rax
 10137e8:	test   %rax,%rax
 10137eb:	je     1013a12 <entry_run+0x13c2>
 10137f1:	mov    0xf8(%rax),%rsi
 10137f8:	jmp    1013a14 <entry_run+0x13c4>
 10137fd:	vmovsd %xmm2,-0x40(%rbp)
 1013802:	vmovsd %xmm3,-0x70(%rbp)
 1013807:	vmovsd %xmm4,-0x78(%rbp)
 101380c:	vzeroupper
 101380f:	call   1027650 <sqrt@plt>
 1013814:	vmovsd -0x78(%rbp),%xmm4
 1013819:	vmovsd -0x70(%rbp),%xmm3
 101381e:	vmovsd -0x40(%rbp),%xmm2
 1013823:	vmovsd -0x11dcb(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101382b:	vxorpd %xmm5,%xmm5,%xmm5
 101382f:	mov    -0x30(%rbp),%rdi
 1013833:	vmovsd -0x11e1b(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 101383b:	vdivsd %xmm0,%xmm1,%xmm0
 101383f:	vmulsd %xmm0,%xmm2,%xmm1
 1013843:	vmulsd %xmm0,%xmm3,%xmm2
 1013847:	vmulsd %xmm0,%xmm4,%xmm0
 101384b:	vmovsd %xmm1,-0x398(%rbp)
 1013853:	vmovsd %xmm2,-0x390(%rbp)
 101385b:	vmovsd %xmm0,-0x388(%rbp)
 1013863:	vmulsd -0xa8(%rbp),%xmm1,%xmm1
 101386b:	vmulsd -0xa0(%rbp),%xmm2,%xmm2
 1013873:	vaddsd %xmm2,%xmm1,%xmm1
 1013877:	vmulsd -0x98(%rbp),%xmm0,%xmm0
 101387f:	vaddsd %xmm0,%xmm1,%xmm7
 1013883:	vxorpd %xmm0,%xmm0,%xmm0
 1013887:	mov    $0x1,%bl
 1013889:	vucomisd %xmm7,%xmm0
 101388d:	jbe    1013897 <entry_run+0x1247>
 101388f:	xor    %r14d,%r14d
 1013892:	jmp    1013b00 <entry_run+0x14b0>
 1013897:	vucomisd %xmm5,%xmm7
 101389b:	jbe    1013a77 <entry_run+0x1427>
 10138a1:	test   %r15,-0x10(%r12)
 10138a6:	mov    $0x3f,%bl
 10138a8:	jne    10138bd <entry_run+0x126d>
 10138aa:	mov    -0x18(%r12),%rax
 10138af:	inc    %rax
 10138b2:	je     1013abc <entry_run+0x146c>
 10138b8:	mov    %rax,-0x18(%r12)
 10138bd:	mov    (%r12),%r14
 10138c1:	test   %r14,%r14
 10138c4:	js     1014598 <entry_run+0x1f48>
 10138ca:	je     1013a83 <entry_run+0x1433>
 10138d0:	mov    $0x18,%ebx
 10138d5:	mov    %r14,%r15
 10138d8:	vmovsd %xmm7,-0x70(%rbp)
 10138dd:	nopl   (%rax)
 10138e0:	cmp    %rsp,0x40(%rdi)
 10138e4:	ja     1014506 <entry_run+0x1eb6>
 10138ea:	mov    0x20(%r12),%rax
 10138ef:	vmovsd -0x170(%rbp),%xmm0
 10138f7:	vmovsd -0x168(%rbp),%xmm1
 10138ff:	vsubsd -0x18(%rbx,%rax,1),%xmm0,%xmm0
 1013905:	vsubsd -0x10(%rbx,%rax,1),%xmm1,%xmm1
 101390b:	vmovsd -0x160(%rbp),%xmm2
 1013913:	vsubsd -0x8(%rbx,%rax,1),%xmm2,%xmm2
 1013919:	vmovsd %xmm0,-0x3c8(%rbp)
 1013921:	vmovsd %xmm1,-0x3c0(%rbp)
 1013929:	vmovsd %xmm2,-0x3b8(%rbp)
 1013931:	vmulsd -0xa8(%rbp),%xmm0,%xmm3
 1013939:	vmulsd -0xa0(%rbp),%xmm1,%xmm4
 1013941:	vaddsd %xmm4,%xmm3,%xmm3
 1013945:	vmulsd -0x98(%rbp),%xmm2,%xmm4
 101394d:	vaddsd %xmm4,%xmm3,%xmm3
 1013951:	vmulsd %xmm0,%xmm0,%xmm0
 1013955:	vmulsd %xmm1,%xmm1,%xmm1
 1013959:	vaddsd %xmm1,%xmm0,%xmm0
 101395d:	vmulsd %xmm2,%xmm2,%xmm1
 1013961:	vaddsd %xmm1,%xmm0,%xmm0
 1013965:	vmovsd (%rbx,%rax,1),%xmm1
 101396a:	vmulsd %xmm1,%xmm1,%xmm1
 101396e:	vsubsd %xmm0,%xmm1,%xmm0
 1013972:	vmulsd %xmm3,%xmm3,%xmm1
 1013976:	vaddsd %xmm0,%xmm1,%xmm0
 101397a:	vucomisd %xmm0,%xmm5
 101397e:	ja     10139ed <entry_run+0x139d>
 1013980:	vucomisd %xmm5,%xmm0
 1013984:	jb     10139a0 <entry_run+0x1350>
 1013986:	vsqrtsd %xmm0,%xmm0,%xmm0
 101398a:	vsubsd %xmm3,%xmm5,%xmm2
 101398e:	vsubsd %xmm0,%xmm2,%xmm1
 1013992:	vucomisd %xmm6,%xmm1
 1013996:	jbe    10139d5 <entry_run+0x1385>
 1013998:	jmp    10139df <entry_run+0x138f>
 101399a:	nopw   0x0(%rax,%rax,1)
 10139a0:	vmovsd %xmm3,-0x40(%rbp)
 10139a5:	vzeroupper
 10139a8:	call   1027650 <sqrt@plt>
 10139ad:	vmovsd -0x40(%rbp),%xmm3
 10139b2:	vmovsd -0x70(%rbp),%xmm7
 10139b7:	vmovsd -0x11f5f(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 10139bf:	vxorpd %xmm5,%xmm5,%xmm5
 10139c3:	mov    -0x30(%rbp),%rdi
 10139c7:	vsubsd %xmm3,%xmm5,%xmm2
 10139cb:	vsubsd %xmm0,%xmm2,%xmm1
 10139cf:	vucomisd %xmm6,%xmm1
 10139d3:	ja     10139df <entry_run+0x138f>
 10139d5:	vaddsd %xmm0,%xmm2,%xmm1
 10139d9:	vucomisd %xmm6,%xmm1
 10139dd:	jbe    10139ed <entry_run+0x139d>
 10139df:	vxorpd %xmm0,%xmm0,%xmm0
 10139e3:	vucomisd %xmm0,%xmm1
 10139e7:	ja     1013aea <entry_run+0x149a>
 10139ed:	cmp    %r14,(%r12)
 10139f1:	jne    101450e <entry_run+0x1ebe>
 10139f7:	add    $0x38,%rbx
 10139fb:	dec    %r15
 10139fe:	jne    10138e0 <entry_run+0x1290>
 1013a04:	xor    %ebx,%ebx
 1013a06:	mov    %r12,%r14
 1013a09:	vmovapd %xmm7,%xmm0
 1013a0d:	jmp    1013aef <entry_run+0x149f>
 1013a12:	xor    %esi,%esi
 1013a14:	mov    -0x38(%rbp),%rdi
 1013a18:	vzeroupper
 1013a1b:	call   101e3a0 <myl_rc_scope_unwind>
 1013a20:	mov    -0x30(%rbp),%rdi
 1013a24:	vxorpd %xmm5,%xmm5,%xmm5
 1013a28:	vmovsd -0x11fd0(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013a30:	vmovsd -0x12020(%rip),%xmm2        # 1001a18 <__abi_tag+0x171c>
 1013a38:	vmovapd -0x12150(%rip),%xmm3        # 10018f0 <__abi_tag+0x15f4>
 1013a40:	test   %r15,-0x10(%r12)
 1013a45:	jne    1013c70 <entry_run+0x1620>
 1013a4b:	mov    -0x18(%r12),%rax
 1013a50:	dec    %rax
 1013a53:	jne    1013a5d <entry_run+0x140d>
 1013a55:	cmpq   $0x0,-0x20(%r12)
 1013a5b:	je     1013a8e <entry_run+0x143e>
 1013a5d:	mov    %rax,-0x18(%r12)
 1013a62:	vmovsd -0x12052(%rip),%xmm2        # 1001a18 <__abi_tag+0x171c>
 1013a6a:	vmovapd -0x12182(%rip),%xmm3        # 10018f0 <__abi_tag+0x15f4>
 1013a72:	jmp    1013c70 <entry_run+0x1620>
 1013a77:	xor    %r14d,%r14d
 1013a7a:	vmovapd %xmm7,%xmm0
 1013a7e:	jmp    1013b00 <entry_run+0x14b0>
 1013a83:	xor    %ebx,%ebx
 1013a85:	mov    %r12,%r14
 1013a88:	vmovapd %xmm7,%xmm0
 1013a8c:	jmp    1013b00 <entry_run+0x14b0>
 1013a8e:	mov    -0x38(%rbp),%rbx
 1013a92:	mov    %rbx,%rdi
 1013a95:	mov    %r12,%rsi
 1013a98:	vzeroupper
 1013a9b:	call   1018ce0 <myl_rc_hold_edge_release>
 1013aa0:	mov    %rbx,%rdi
 1013aa3:	mov    $0x3f,%bl
 1013aa5:	call   101bcb0 <myl_rc_drain>
 1013aaa:	vmovsd -0x12052(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ab2:	vxorpd %xmm5,%xmm5,%xmm5
 1013ab6:	mov    -0x30(%rbp),%rdi
 1013aba:	jmp    1013a62 <entry_run+0x1412>
 1013abc:	mov    $0x100432e,%esi
 1013ac1:	mov    -0x30(%rbp),%rdi
 1013ac5:	vzeroupper
 1013ac8:	call   1014a6d <fail>
 1013acd:	vmovsd -0x12075(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ad5:	vxorpd %xmm5,%xmm5,%xmm5
 1013ad9:	mov    -0x30(%rbp),%rdi
 1013add:	vxorpd %xmm3,%xmm3,%xmm3
 1013ae1:	vxorpd %xmm2,%xmm2,%xmm2
 1013ae5:	jmp    1013c70 <entry_run+0x1620>
 1013aea:	xor    %ebx,%ebx
 1013aec:	mov    %r12,%r14
 1013aef:	movabs $0x4000000000000002,%r15
 1013af9:	nopl   0x0(%rax)
 1013b00:	vmulsd -0x120c0(%rip),%xmm0,%xmm0        # 1001a48 <__abi_tag+0x174c>
 1013b08:	vaddsd -0x120d8(%rip),%xmm0,%xmm0        # 1001a38 <__abi_tag+0x173c>
 1013b10:	vmulsd -0x240(%rbp),%xmm0,%xmm2
 1013b18:	vmovddup %xmm0,%xmm0
 1013b1c:	vmulpd -0x238(%rbp),%xmm0,%xmm3
 1013b24:	mov    -0x3f0(%rbp),%eax
 1013b2a:	or     -0x410(%rbp),%eax
 1013b30:	or     -0x3d0(%rbp),%eax
 1013b36:	je     1013b7f <entry_run+0x152f>
 1013b38:	mov    0x1860(%rdi),%rax
 1013b3f:	test   %rax,%rax
 1013b42:	vmovsd %xmm2,-0x40(%rbp)
 1013b47:	vmovapd %xmm3,-0x70(%rbp)
 1013b4c:	je     1013b57 <entry_run+0x1507>
 1013b4e:	mov    0xf8(%rax),%rsi
 1013b55:	jmp    1013b59 <entry_run+0x1509>
 1013b57:	xor    %esi,%esi
 1013b59:	mov    -0x38(%rbp),%rdi
 1013b5d:	vzeroupper
 1013b60:	call   101e3a0 <myl_rc_scope_unwind>
 1013b65:	mov    -0x30(%rbp),%rdi
 1013b69:	vxorpd %xmm5,%xmm5,%xmm5
 1013b6d:	vmovsd -0x12115(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013b75:	vmovsd -0x40(%rbp),%xmm2
 1013b7a:	vmovapd -0x70(%rbp),%xmm3
 1013b7f:	test   %r14,%r14
 1013b82:	sete   %al
 1013b85:	or     %al,%bl
 1013b87:	mov    $0x3f,%bl
 1013b89:	jne    1013b91 <entry_run+0x1541>
 1013b8b:	test   %r15,-0x10(%r14)
 1013b8f:	je     1013bb8 <entry_run+0x1568>
 1013b91:	test   %r15,-0x10(%r12)
 1013b96:	jne    1013c70 <entry_run+0x1620>
 1013b9c:	mov    -0x18(%r12),%rax
 1013ba1:	dec    %rax
 1013ba4:	jne    1013bae <entry_run+0x155e>
 1013ba6:	cmpq   $0x0,-0x20(%r12)
 1013bac:	je     1013bd9 <entry_run+0x1589>
 1013bae:	mov    %rax,-0x18(%r12)
 1013bb3:	jmp    1013c70 <entry_run+0x1620>
 1013bb8:	mov    -0x18(%r14),%rax
 1013bbc:	dec    %rax
 1013bbf:	jne    1013bc8 <entry_run+0x1578>
 1013bc1:	cmpq   $0x0,-0x20(%r14)
 1013bc6:	je     1013c1b <entry_run+0x15cb>
 1013bc8:	mov    %rax,-0x18(%r14)
 1013bcc:	test   %r15,-0x10(%r12)
 1013bd1:	jne    1013c70 <entry_run+0x1620>
 1013bd7:	jmp    1013b9c <entry_run+0x154c>
 1013bd9:	mov    -0x38(%rbp),%rbx
 1013bdd:	mov    %rbx,%rdi
 1013be0:	mov    %r12,%rsi
 1013be3:	vmovsd %xmm2,-0x40(%rbp)
 1013be8:	vmovapd %xmm3,-0x70(%rbp)
 1013bed:	vzeroupper
 1013bf0:	call   1018ce0 <myl_rc_hold_edge_release>
 1013bf5:	mov    %rbx,%rdi
 1013bf8:	mov    $0x3f,%bl
 1013bfa:	call   101bcb0 <myl_rc_drain>
 1013bff:	vmovapd -0x70(%rbp),%xmm3
 1013c04:	vmovsd -0x40(%rbp),%xmm2
 1013c09:	vmovsd -0x121b1(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013c11:	vxorpd %xmm5,%xmm5,%xmm5
 1013c15:	mov    -0x30(%rbp),%rdi
 1013c19:	jmp    1013c70 <entry_run+0x1620>
 1013c1b:	mov    -0x38(%rbp),%rbx
 1013c1f:	mov    %rbx,%rdi
 1013c22:	mov    %r14,%rsi
 1013c25:	vmovsd %xmm2,-0x40(%rbp)
 1013c2a:	vmovapd %xmm3,-0x70(%rbp)
 1013c2f:	vzeroupper
 1013c32:	call   1018ce0 <myl_rc_hold_edge_release>
 1013c37:	mov    %rbx,%rdi
 1013c3a:	mov    $0x3f,%bl
 1013c3c:	call   101bcb0 <myl_rc_drain>
 1013c41:	vmovapd -0x70(%rbp),%xmm3
 1013c46:	vmovsd -0x40(%rbp),%xmm2
 1013c4b:	vmovsd -0x121f3(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013c53:	vxorpd %xmm5,%xmm5,%xmm5
 1013c57:	mov    -0x30(%rbp),%rdi
 1013c5b:	test   %r15,-0x10(%r12)
 1013c60:	je     1013b9c <entry_run+0x154c>
 1013c66:	cs nopw 0x0(%rax,%rax,1)
 1013c70:	vmovsd %xmm2,-0x1d8(%rbp)
 1013c78:	vmulsd -0x12218(%rip),%xmm2,%xmm0        # 1001a68 <__abi_tag+0x176c>
 1013c80:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 1013c86:	vmovsd -0x1226e(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 1013c8e:	vcmpltsd %xmm2,%xmm1,%xmm1
 1013c93:	vblendvpd %xmm1,-0x1239d(%rip),%xmm0,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013c9d:	vmovupd %xmm3,-0x1d0(%rbp)
 1013ca5:	vmovq  %xmm0,%rax
 1013caa:	bzhi   %rbx,%rax,%rax
 1013caf:	movabs $0x7fefffffffffffff,%rcx
 1013cb9:	cmp    %rcx,%rax
 1013cbc:	jg     1013e8b <entry_run+0x183b>
 1013cc2:	vmovsd -0x1227a(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013cca:	vucomisd %xmm0,%xmm1
 1013cce:	ja     1013e8b <entry_run+0x183b>
 1013cd4:	vucomisd -0x122b4(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013cdc:	jae    1013e8b <entry_run+0x183b>
 1013ce2:	vcvttsd2si %xmm0,%r14
 1013ce7:	vmovsd -0x1d0(%rbp),%xmm0
 1013cef:	vmulsd -0x1228f(%rip),%xmm0,%xmm1        # 1001a68 <__abi_tag+0x176c>
 1013cf7:	vroundsd $0xb,%xmm1,%xmm1,%xmm1
 1013cfd:	vmovsd -0x122e5(%rip),%xmm2        # 1001a20 <__abi_tag+0x1724>
 1013d05:	vcmpltsd %xmm0,%xmm2,%xmm0
 1013d0a:	vblendvpd %xmm0,-0x12414(%rip),%xmm1,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013d14:	vmovq  %xmm0,%rax
 1013d19:	bzhi   %rbx,%rax,%rax
 1013d1e:	movabs $0x7fefffffffffffff,%rcx
 1013d28:	cmp    %rcx,%rax
 1013d2b:	jg     1013eb4 <entry_run+0x1864>
 1013d31:	vmovsd -0x122e9(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013d39:	vucomisd %xmm0,%xmm1
 1013d3d:	ja     1013eb4 <entry_run+0x1864>
 1013d43:	vucomisd -0x12323(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013d4b:	jae    1013eb4 <entry_run+0x1864>
 1013d51:	vcvttsd2si %xmm0,%r12
 1013d56:	vmovsd -0x1c8(%rbp),%xmm0
 1013d5e:	vmulsd -0x122fe(%rip),%xmm0,%xmm1        # 1001a68 <__abi_tag+0x176c>
 1013d66:	vroundsd $0xb,%xmm1,%xmm1,%xmm1
 1013d6c:	vmovsd -0x12354(%rip),%xmm2        # 1001a20 <__abi_tag+0x1724>
 1013d74:	vcmpltsd %xmm0,%xmm2,%xmm0
 1013d79:	vblendvpd %xmm0,-0x12483(%rip),%xmm1,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013d83:	vmovq  %xmm0,%rax
 1013d88:	bzhi   %rbx,%rax,%rax
 1013d8d:	movabs $0x7fefffffffffffff,%rcx
 1013d97:	cmp    %rcx,%rax
 1013d9a:	jg     1013edd <entry_run+0x188d>
 1013da0:	vmovsd -0x12358(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013da8:	vucomisd %xmm0,%xmm1
 1013dac:	ja     1013edd <entry_run+0x188d>
 1013db2:	vucomisd -0x12392(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013dba:	jae    1013edd <entry_run+0x188d>
 1013dc0:	vcvttsd2si %xmm0,%rcx
 1013dc5:	movabs $0xffff800000000000,%rax
 1013dcf:	add    %r14,%rax
 1013dd2:	shr    $0x30,%rax
 1013dd6:	cmp    $0xfffe,%eax
 1013ddb:	jbe    1014531 <entry_run+0x1ee1>
 1013de1:	movabs $0xff80000000000000,%rax
 1013deb:	add    %r12,%rax
 1013dee:	shr    $0x38,%rax
 1013df2:	cmp    $0xfe,%eax
 1013df7:	jbe    1014546 <entry_run+0x1ef6>
 1013dfd:	shl    $0x10,%r14
 1013e01:	shl    $0x8,%r12
 1013e05:	mov    %r14,%rdx
 1013e08:	add    %r12,%rdx
 1013e0b:	jo     101455b <entry_run+0x1f0b>
 1013e11:	mov    %rdx,%rax
 1013e14:	add    %rcx,%rax
 1013e17:	jo     101456b <entry_run+0x1f1b>
 1013e1d:	mov    %r13,%rdx
 1013e20:	shl    $0x5,%rdx
 1013e24:	sub    %r13,%rdx
 1013e27:	mov    %rdx,%rcx
 1013e2a:	add    %rax,%rcx
 1013e2d:	jo     1014575 <entry_run+0x1f25>
 1013e33:	mov    %rcx,%rax
 1013e36:	movabs $0x89705f3112a28fe5,%rdx
 1013e40:	imul   %rdx
 1013e43:	add    %rcx,%rdx
 1013e46:	mov    %rdx,%rax
 1013e49:	shr    $0x3f,%rax
 1013e4d:	sar    $0x1d,%rdx
 1013e51:	add    %rax,%rdx
 1013e54:	imul   $0x3b9aca07,%rdx,%rax
 1013e5b:	sub    %rax,%rcx
 1013e5e:	mov    %rcx,%r13
 1013e61:	sar    $0x3f,%r13
 1013e65:	and    $0x3b9aca07,%r13d
 1013e6c:	add    %rcx,%r13
 1013e6f:	mov    -0x128(%rbp),%rcx
 1013e76:	inc    %rcx
 1013e79:	cmp    $0x780,%rcx
 1013e80:	jne    1013390 <entry_run+0xd40>
 1013e86:	jmp    1013340 <entry_run+0xcf0>
 1013e8b:	mov    $0x10043c9,%esi
 1013e90:	mov    -0x30(%rbp),%rdi
 1013e94:	vzeroupper
 1013e97:	call   1014a6d <fail>
 1013e9c:	vmovsd -0x12444(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ea4:	vxorpd %xmm5,%xmm5,%xmm5
 1013ea8:	mov    -0x30(%rbp),%rdi
 1013eac:	xor    %r14d,%r14d
 1013eaf:	jmp    1013ce7 <entry_run+0x1697>
 1013eb4:	mov    $0x10043c9,%esi
 1013eb9:	mov    -0x30(%rbp),%rdi
 1013ebd:	vzeroupper
 1013ec0:	call   1014a6d <fail>
 1013ec5:	vmovsd -0x1246d(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ecd:	vxorpd %xmm5,%xmm5,%xmm5
 1013ed1:	mov    -0x30(%rbp),%rdi
 1013ed5:	xor    %r12d,%r12d
 1013ed8:	jmp    1013d56 <entry_run+0x1706>
 1013edd:	mov    $0x10043c9,%esi
 1013ee2:	mov    -0x30(%rbp),%rdi
 1013ee6:	vzeroupper
 1013ee9:	call   1014a6d <fail>
 1013eee:	vmovsd -0x12496(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013ef6:	vxorpd %xmm5,%xmm5,%xmm5
 1013efa:	mov    -0x30(%rbp),%rdi
 1013efe:	xor    %ecx,%ecx
 1013f00:	jmp    1013dc5 <entry_run+0x1775>
 1013f05:	mov    $0x1,%edi
 1013f0a:	mov    $0x20,%esi
 1013f0f:	vzeroupper
 1013f12:	call   1027510 <calloc@plt>
 1013f17:	mov    %rax,%r12
 1013f1a:	test   %rax,%rax
 1013f1d:	jne    1013f28 <entry_run+0x18d8>
 1013f1f:	mov    -0x30(%rbp),%rdi
 1013f23:	call   1015110 <myl_qbe_fail_allocation>
 1013f28:	lea    -0x260(%rbp),%rdi
 1013f2f:	mov    $0x18,%esi
 1013f34:	mov    $0x10040e8,%edx
 1013f39:	mov    %r13,%rcx
 1013f3c:	xor    %eax,%eax
 1013f3e:	call   1027660 <snprintf@plt>
 1013f43:	test   %eax,%eax
 1013f45:	jle    101415d <entry_run+0x1b0d>
 1013f4b:	mov    %eax,%r13d
 1013f4e:	mov    $0x40,%r15d
 1013f54:	cmp    $0x41,%eax
 1013f57:	jb     101410f <entry_run+0x1abf>
 1013f5d:	mov    $0x80,%r15d
 1013f63:	cmp    $0x81,%r13d
 1013f6a:	jb     101410f <entry_run+0x1abf>
 1013f70:	mov    $0x100,%r15d
 1013f76:	cmp    $0x101,%r13d
 1013f7d:	jb     101410f <entry_run+0x1abf>
 1013f83:	mov    $0x200,%r15d
 1013f89:	cmp    $0x201,%r13d
 1013f90:	jb     101410f <entry_run+0x1abf>
 1013f96:	mov    $0x400,%r15d
 1013f9c:	cmp    $0x401,%r13d
 1013fa3:	jb     101410f <entry_run+0x1abf>
 1013fa9:	mov    $0x800,%r15d
 1013faf:	cmp    $0x801,%r13d
 1013fb6:	jb     101410f <entry_run+0x1abf>
 1013fbc:	mov    $0x1000,%r15d
 1013fc2:	cmp    $0x1001,%r13d
 1013fc9:	jb     101410f <entry_run+0x1abf>
 1013fcf:	mov    $0x2000,%r15d
 1013fd5:	cmp    $0x2001,%r13d
 1013fdc:	jb     101410f <entry_run+0x1abf>
 1013fe2:	mov    $0x4000,%r15d
 1013fe8:	cmp    $0x4001,%r13d
 1013fef:	jb     101410f <entry_run+0x1abf>
 1013ff5:	mov    $0x8000,%r15d
 1013ffb:	cmp    $0x8001,%r13d
 1014002:	jb     101410f <entry_run+0x1abf>
 1014008:	mov    $0x10000,%r15d
 101400e:	cmp    $0x10001,%r13d
 1014015:	jb     101410f <entry_run+0x1abf>
 101401b:	mov    $0x20000,%r15d
 1014021:	cmp    $0x20001,%r13d
 1014028:	jb     101410f <entry_run+0x1abf>
 101402e:	mov    $0x40000,%r15d
 1014034:	cmp    $0x40001,%r13d
 101403b:	jb     101410f <entry_run+0x1abf>
 1014041:	mov    $0x80000,%r15d
 1014047:	cmp    $0x80001,%r13d
 101404e:	jb     101410f <entry_run+0x1abf>
 1014054:	mov    $0x100000,%r15d
 101405a:	cmp    $0x100001,%r13d
 1014061:	jb     101410f <entry_run+0x1abf>
 1014067:	mov    $0x200000,%r15d
 101406d:	cmp    $0x200001,%r13d
 1014074:	jb     101410f <entry_run+0x1abf>
 101407a:	mov    $0x400000,%r15d
 1014080:	cmp    $0x400001,%r13d
 1014087:	jb     101410f <entry_run+0x1abf>
 101408d:	mov    $0x800000,%r15d
 1014093:	cmp    $0x800001,%r13d
 101409a:	jb     101410f <entry_run+0x1abf>
 101409c:	mov    $0x1000000,%r15d
 10140a2:	cmp    $0x1000001,%r13d
 10140a9:	jb     101410f <entry_run+0x1abf>
 10140ab:	mov    $0x2000000,%r15d
 10140b1:	cmp    $0x2000001,%r13d
 10140b8:	jb     101410f <entry_run+0x1abf>
 10140ba:	mov    $0x4000000,%r15d
 10140c0:	cmp    $0x4000001,%r13d
 10140c7:	jb     101410f <entry_run+0x1abf>
 10140c9:	mov    $0x8000000,%r15d
 10140cf:	cmp    $0x8000001,%r13d
 10140d6:	jb     101410f <entry_run+0x1abf>
 10140d8:	mov    $0x10000000,%r15d
 10140de:	cmp    $0x10000001,%r13d
 10140e5:	jb     101410f <entry_run+0x1abf>
 10140e7:	mov    $0x20000000,%r15d
 10140ed:	cmp    $0x20000001,%r13d
 10140f4:	jb     101410f <entry_run+0x1abf>
 10140f6:	xor    %r15d,%r15d
 10140f9:	cmp    $0x40000001,%r13d
 1014100:	setae  %r15b
 1014104:	shl    $0x1e,%r15d
 1014108:	add    $0x40000000,%r15
 101410f:	mov    %r15,%rdi
 1014112:	call   1027500 <malloc@plt>
 1014117:	test   %rax,%rax
 101411a:	je     101418e <entry_run+0x1b3e>
 101411c:	mov    %r13d,%r14d
 101411f:	mov    %rax,(%r12)
 1014123:	mov    %r15,0x10(%r12)
 1014128:	lea    -0x260(%rbp),%rsi
 101412f:	mov    %rax,-0x40(%rbp)
 1014133:	mov    %rax,%rdi
 1014136:	mov    %r14,%rdx
 1014139:	call   1027520 <memcpy@plt>
 101413e:	lea    0x8(%r12),%r13
 1014143:	mov    %r14,0x8(%r12)
 1014148:	mov    %r12,%rbx
 101414b:	add    $0x18,%rbx
 101414f:	cmp    %r14,%r15
 1014152:	jne    10141a8 <entry_run+0x1b58>
 1014154:	add    %r15,%r15
 1014157:	mov    -0x40(%rbp),%rdi
 101415b:	jmp    1014171 <entry_run+0x1b21>
 101415d:	lea    0x18(%r12),%rbx
 1014162:	mov    %r12,%r13
 1014165:	add    $0x8,%r13
 1014169:	mov    $0x40,%r15d
 101416f:	xor    %edi,%edi
 1014171:	mov    %r15,%rsi
 1014174:	call   1027670 <realloc@plt>
 1014179:	test   %rax,%rax
 101417c:	je     10141a0 <entry_run+0x1b50>
 101417e:	mov    %rax,(%r12)
 1014182:	mov    %r15,0x10(%r12)
 1014187:	mov    0x8(%r12),%r14
 101418c:	jmp    10141ac <entry_run+0x1b5c>
 101418e:	mov    %r12,%rbx
 1014191:	add    $0x18,%rbx
 1014195:	movl   $0x1,0x18(%r12)
 101419e:	jmp    10141b5 <entry_run+0x1b65>
 10141a0:	movl   $0x1,(%rbx)
 10141a6:	jmp    10141b5 <entry_run+0x1b65>
 10141a8:	mov    -0x40(%rbp),%rax
 10141ac:	movb   $0xa,(%rax,%r14,1)
 10141b1:	incq   0x0(%r13)
 10141b5:	movabs $0x4000000000000002,%r14
 10141bf:	cmpl   $0x0,0x1c(%r12)
 10141c5:	jne    1014369 <entry_run+0x1d19>
 10141cb:	cmpl   $0x0,(%rbx)
 10141ce:	je     10141db <entry_run+0x1b8b>
 10141d0:	mov    -0x30(%rbp),%rdi
 10141d4:	call   1015110 <myl_qbe_fail_allocation>
 10141d9:	jmp    1014226 <entry_run+0x1bd6>
 10141db:	mov    0x149be(%rip),%rax        # 1028ba0 <stdout@GLIBC_2.2.5>
 10141e2:	mov    (%rax),%r14
 10141e5:	mov    0x8(%r12),%r15
 10141ea:	test   %r15,%r15
 10141ed:	je     101420c <entry_run+0x1bbc>
 10141ef:	mov    (%r12),%rdi
 10141f3:	mov    $0x1,%esi
 10141f8:	mov    %r15,%rdx
 10141fb:	mov    %r14,%rcx
 10141fe:	call   10275d0 <fwrite@plt>
 1014203:	cmp    %r15,%rax
 1014206:	jne    10143dc <entry_run+0x1d8c>
 101420c:	mov    %r14,%rdi
 101420f:	call   1027680 <fflush@plt>
 1014214:	test   %eax,%eax
 1014216:	movabs $0x4000000000000002,%r14
 1014220:	jne    101439e <entry_run+0x1d4e>
 1014226:	mov    (%r12),%rdi
 101422a:	call   1027570 <free@plt>
 101422f:	mov    %r12,%rdi
 1014232:	call   1027570 <free@plt>
 1014237:	cmpb   $0x1,0x17572(%rip)        # 102b7b0 <exit_without_sweep>
 101423e:	jne    101426d <entry_run+0x1c1d>
 1014240:	mov    -0x30(%rbp),%rax
 1014244:	cmpl   $0x0,0x2c0(%rax)
 101424b:	jne    101426d <entry_run+0x1c1d>
 101424d:	mov    -0x30(%rbp),%rax
 1014251:	cmpq   $0x0,0x3990(%rax)
 1014259:	jne    101426d <entry_run+0x1c1d>
 101425b:	mov    -0x30(%rbp),%rax
 101425f:	cmpq   $0x0,0x3998(%rax)
 1014267:	je     1014488 <entry_run+0x1e38>
 101426d:	mov    -0x80(%rbp),%rax
 1014271:	test   %rax,%rax
 1014274:	je     1014294 <entry_run+0x1c44>
 1014276:	test   %r14,-0x10(%rax)
 101427a:	jne    1014294 <entry_run+0x1c44>
 101427c:	mov    -0x20(%rax),%rcx
 1014280:	dec    %rcx
 1014283:	jne    1014290 <entry_run+0x1c40>
 1014285:	cmpq   $0x0,-0x18(%rax)
 101428a:	je     1014370 <entry_run+0x1d20>
 1014290:	mov    %rcx,-0x20(%rax)
 1014294:	cmpl   $0x0,-0x50(%rbp)
 1014298:	je     1014488 <entry_run+0x1e38>
 101429e:	mov    -0x48(%rbp),%rax
 10142a2:	test   %rax,%rax
 10142a5:	je     1014488 <entry_run+0x1e38>
 10142ab:	test   %r14,-0x10(%rax)
 10142af:	jne    1014488 <entry_run+0x1e38>
 10142b5:	mov    -0x20(%rax),%rcx
 10142b9:	dec    %rcx
 10142bc:	jne    10142c9 <entry_run+0x1c79>
 10142be:	cmpq   $0x0,-0x18(%rax)
 10142c3:	je     101438c <entry_run+0x1d3c>
 10142c9:	mov    %rcx,-0x20(%rax)
 10142cd:	jmp    1014488 <entry_run+0x1e38>
 10142d2:	mov    -0x30(%rbp),%rdi
 10142d6:	mov    0x1860(%rdi),%rax
 10142dd:	test   %rax,%rax
 10142e0:	je     10144fc <entry_run+0x1eac>
 10142e6:	mov    0x124(%rax),%esi
 10142ec:	movl   $0x0,0x124(%rax)
 10142f6:	call   10145f0 <myl_qbe_rc_status>
 10142fb:	jmp    1014488 <entry_run+0x1e38>
 1014300:	mov    %r14,-0x260(%rbp)
 1014307:	lea    -0xf8(%rbp),%rax
 101430e:	mov    %rax,-0x258(%rbp)
 1014315:	movq   $0x0,-0x250(%rbp)
 1014320:	mov    %r15d,-0x248(%rbp)
 1014327:	movl   $0x0,-0x244(%rbp)
 1014331:	lea    -0x260(%rbp),%rsi
 1014338:	lea    -0x58(%rbp),%rcx
 101433c:	mov    -0x38(%rbp),%rdi
 1014340:	mov    %r14,%rdx
 1014343:	call   101e980 <transfer>
 1014348:	test   %eax,%eax
 101434a:	je     1012937 <entry_run+0x2e7>
 1014350:	mov    -0x30(%rbp),%rbx
 1014354:	mov    0x1860(%rbx),%rcx
 101435b:	test   %rcx,%rcx
 101435e:	jne    1012a1c <entry_run+0x3cc>
 1014364:	jmp    10144fc <entry_run+0x1eac>
 1014369:	mov    $0x1003d5c,%esi
 101436e:	jmp    10143a3 <entry_run+0x1d53>
 1014370:	lea    -0x80(%rbp),%rsi
 1014374:	mov    -0x38(%rbp),%rdi
 1014378:	call   100f670 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 101437d:	cmpl   $0x0,-0x50(%rbp)
 1014381:	jne    101429e <entry_run+0x1c4e>
 1014387:	jmp    1014488 <entry_run+0x1e38>
 101438c:	lea    -0x48(%rbp),%rsi
 1014390:	mov    -0x38(%rbp),%rdi
 1014394:	call   100f670 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1014399:	jmp    1014488 <entry_run+0x1e38>
 101439e:	mov    $0x10042d4,%esi
 10143a3:	mov    -0x30(%rbp),%rdi
 10143a7:	call   1014a6d <fail>
 10143ac:	jmp    1014226 <entry_run+0x1bd6>
 10143b1:	mov    $0x100432e,%esi
 10143b6:	vzeroupper
 10143b9:	call   1014a6d <fail>
 10143be:	jmp    1014488 <entry_run+0x1e38>
 10143c3:	lea    -0x48(%rbp),%rsi
 10143c7:	mov    -0x38(%rbp),%rdi
 10143cb:	vzeroupper
 10143ce:	call   100f670 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10143d3:	mov    -0x30(%rbp),%rdi
 10143d7:	jmp    1013251 <entry_run+0xc01>
 10143dc:	mov    $0x10042d4,%esi
 10143e1:	mov    -0x30(%rbp),%rdi
 10143e5:	call   1014a6d <fail>
 10143ea:	movabs $0x4000000000000002,%r14
 10143f4:	jmp    1014226 <entry_run+0x1bd6>
 10143f9:	mov    $0x1002338,%esi
 10143fe:	call   1018df4 <myl_rc_binding_find_slow>
 1014403:	mov    -0x30(%rbp),%rbx
 1014407:	mov    %rax,%r12
 101440a:	test   %r12,%r12
 101440d:	jne    1012889 <entry_run+0x239>
 1014413:	mov    $0x1002338,%esi
 1014418:	mov    -0x38(%rbp),%rdi
 101441c:	call   1023330 <myl_rc_native_shape>
 1014421:	mov    -0x30(%rbp),%rbx
 1014425:	test   %rax,%rax
 1014428:	je     1014463 <entry_run+0x1e13>
 101442a:	mov    0x1860(%rbx),%rdi
 1014431:	cmpq   $0x1a,0xa0(%rdi)
 1014439:	jb     10144cd <entry_run+0x1e7d>
 101443f:	mov    0x98(%rdi),%rax
 1014446:	cmpq   $0x1002338,0x190(%rax)
 1014451:	jne    10144cd <entry_run+0x1e7d>
 1014453:	mov    0x198(%rax),%r12
 101445a:	test   %r12,%r12
 101445d:	jne    1012889 <entry_run+0x239>
 1014463:	mov    0x1860(%rbx),%rcx
 101446a:	test   %rcx,%rcx
 101446d:	je     10144fc <entry_run+0x1eac>
 1014473:	mov    0x124(%rcx),%eax
 1014479:	movl   $0x0,0x124(%rcx)
 1014483:	test   %rax,%rax
 1014486:	jne    101449c <entry_run+0x1e4c>
 1014488:	xor    %eax,%eax
 101448a:	add    $0x408,%rsp
 1014491:	pop    %rbx
 1014492:	pop    %r12
 1014494:	pop    %r13
 1014496:	pop    %r14
 1014498:	pop    %r15
 101449a:	pop    %rbp
 101449b:	ret
 101449c:	cmp    $0x1,%eax
 101449f:	jne    10144b5 <entry_run+0x1e65>
 10144a1:	mov    $0x1004361,%esi
 10144a6:	mov    -0x30(%rbp),%rcx
 10144aa:	cmpl   $0x0,0x2c4(%rcx)
 10144b1:	je     10144ba <entry_run+0x1e6a>
 10144b3:	jmp    10144c2 <entry_run+0x1e72>
 10144b5:	cmp    $0x4,%eax
 10144b8:	jae    1014501 <entry_run+0x1eb1>
 10144ba:	mov    0x100b5d0(,%rax,8),%rsi
 10144c2:	mov    -0x30(%rbp),%rdi
 10144c6:	call   1014a6d <fail>
 10144cb:	jmp    1014488 <entry_run+0x1e38>
 10144cd:	mov    $0x1002338,%esi
 10144d2:	call   1018df4 <myl_rc_binding_find_slow>
 10144d7:	mov    -0x30(%rbp),%rbx
 10144db:	mov    %rax,%r12
 10144de:	test   %r12,%r12
 10144e1:	jne    1012889 <entry_run+0x239>
 10144e7:	jmp    1014463 <entry_run+0x1e13>
 10144ec:	vzeroupper
 10144ef:	call   10151a0 <myl_qbe_fail_iteration>
 10144f4:	vzeroupper
 10144f7:	call   10152d0 <myl_qbe_fail_frame>
 10144fc:	call   10187d4 <myl_rc_invariant_failed>
 1014501:	call   1027690 <abort@plt>
 1014506:	vzeroupper
 1014509:	call   10152d0 <myl_qbe_fail_frame>
 101450e:	vzeroupper
 1014511:	call   10151a0 <myl_qbe_fail_iteration>
 1014516:	vzeroupper
 1014519:	call   10152d0 <myl_qbe_fail_frame>
 101451e:	vzeroupper
 1014521:	call   10152d0 <myl_qbe_fail_frame>
 1014526:	mov    %r13,%rsi
 1014529:	vzeroupper
 101452c:	call   1015270 <myl_qbe_fail_cast>
 1014531:	mov    $0x2,%esi
 1014536:	mov    $0x10000,%ecx
 101453b:	mov    %r14,%rdx
 101453e:	vzeroupper
 1014541:	call   1015210 <myl_qbe_fail_overflow_op>
 1014546:	mov    $0x2,%esi
 101454b:	mov    $0x100,%ecx
 1014550:	mov    %r12,%rdx
 1014553:	vzeroupper
 1014556:	call   1015210 <myl_qbe_fail_overflow_op>
 101455b:	xor    %esi,%esi
 101455d:	mov    %r14,%rdx
 1014560:	mov    %r12,%rcx
 1014563:	vzeroupper
 1014566:	call   1015210 <myl_qbe_fail_overflow_op>
 101456b:	xor    %esi,%esi
 101456d:	vzeroupper
 1014570:	call   1015210 <myl_qbe_fail_overflow_op>
 1014575:	xor    %esi,%esi
 1014577:	mov    %rax,%rcx
 101457a:	vzeroupper
 101457d:	call   1015210 <myl_qbe_fail_overflow_op>
 1014582:	mov    %r14,%rsi
 1014585:	mov    %r13,%rdx
 1014588:	vzeroupper
 101458b:	call   10151b0 <myl_qbe_fail_normalized_index_bounds>
 1014590:	vzeroupper
 1014593:	call   10152d0 <myl_qbe_fail_frame>
 1014598:	mov    %r14,%rsi
 101459b:	vzeroupper
 101459e:	call   1015270 <myl_qbe_fail_cast>
 10145a3:	call   10152d0 <myl_qbe_fail_frame>
 10145a8:	mov    -0x30(%rbp),%rdi
 10145ac:	call   1015110 <myl_qbe_fail_allocation>
 10145b1:	mov    -0x30(%rbp),%rdi
 10145b5:	call   1015110 <myl_qbe_fail_allocation>
 10145ba:	mov    -0x30(%rbp),%rdi
 10145be:	call   1015110 <myl_qbe_fail_allocation>
 10145c3:	mov    -0x30(%rbp),%rdi
 10145c7:	call   1015110 <myl_qbe_fail_allocation>
 10145cc:	mov    -0x30(%rbp),%rdi
 10145d0:	call   1015110 <myl_qbe_fail_allocation>
 10145d5:	vzeroupper
 10145d8:	call   10152d0 <myl_qbe_fail_frame>
 10145dd:	call   1015110 <myl_qbe_fail_allocation>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
