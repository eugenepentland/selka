from pathlib import Path
import subprocess,json,hashlib,os
root=Path.cwd();work=root/'.tmp/cold-hint';compiler=work/'compiler/bin/mylang';source=root/'bench/parity/suite/raytrace.my';expected=(root/'bench/parity/suite/raytrace.expected').read_bytes();rows=[]
for mode,flags in [('full',['--backend','llvm','--llvm-opt','3','--lto']),('thin',['--backend','llvm','--llvm-opt','3','--lto=thin']),('none',['--backend','llvm','--llvm-opt','3']),('qbe',['--backend','qbe'])]:
 binary=work/('raytrace.'+mode)
 if mode=='full':binary=work/'raytrace.llvm'
 else:
  command=[str(compiler),'build',str(source),'-o',str(binary),*flags,'--rc-runtime','--keep-symbols','--cache-dir',str(work/'guest-cache')]
  p=subprocess.run(command,capture_output=True);(work/(mode+'-build.stdout')).write_bytes(p.stdout);(work/(mode+'-build.stderr')).write_bytes(p.stderr)
  rows.append({'phase':'build','mode':mode,'command':command,'status':p.returncode});assert p.returncode==0,(mode,p.stderr.decode(errors='replace'))
 command=[str(binary)];p=subprocess.run(command,capture_output=True);(work/(mode+'.stdout')).write_bytes(p.stdout);(work/(mode+'.stderr')).write_bytes(p.stderr)
 rows.append({'phase':'execute','mode':mode,'command':command,'status':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'expected_output':p.stdout==expected,'stderr_empty':not p.stderr})
 assert p.returncode==0 and p.stdout==expected and not p.stderr,(mode,p.returncode,p.stdout,p.stderr)
 (work/('raytrace.'+mode+'.asm')).write_bytes(subprocess.check_output(['objdump','-d','--no-show-raw-insn',str(binary)]))
(work/'guest-receipt.json').write_text(json.dumps({'rows':rows,'expected_sha256':hashlib.sha256(expected).hexdigest(),'modes':4,'admission':'Entire serial build/execution runner admitted through build-slot; no parallel children','timing_claim':False},indent=2)+'\n')
print('Actual raytrace output: QBE and LLVM3 no-LTO/full/ThinLTO all passed; no timing samples')
