import gzip
import hashlib
import json
import pathlib

root = pathlib.Path('/home/epentland/.codex/worktrees/selka-constant-pilot/mylang')
base = pathlib.Path('/home/epentland/ai/canopy/.selka-agent-cache/constant-closure')
archive = root / 'docs/audits/evidence/selka-body-constants-20261011'
report = json.loads((base / 'producer-suites-bounded-lookup.json').read_text())
assert report['complete'] is True
assert report['failed'] == report['skipped'] == 0
assert report['total_per_mode'] == 532
assert len(report['selection']) == 88
assert len(report['records']) == 176
for mode in ('normal', 'release'):
    records = [r for r in report['records'] if r['mode'] == mode]
    assert len(records) == 88
    assert sum(r['expected'] for r in records) == 532
    assert all(r['status'] == 0 for r in records)
    assert {r['source'] for r in records} == {r['path'] for r in report['selection']}
for selected in report['selection']:
    assert hashlib.sha256(pathlib.Path(selected['path']).read_bytes()).hexdigest() == selected['source_sha256']
source = json.loads(gzip.decompress((archive / 'producer-source.json.gz').read_bytes()))
assert len(source) == 175
for name, record in source.items():
    actual = (root / 'selfhost/components/body_check' / name).read_bytes()
    assert actual.hex() == record['content_hex']
    assert hashlib.sha256(actual).hexdigest() == record['sha256']
receipt = json.loads((archive / 'receipt.json').read_text())
for path_key, hash_key in (('qualified_seed_path', 'qualified_seed_sha256'), ('host_path', 'host_sha256')):
    assert hashlib.sha256(pathlib.Path(receipt[path_key]).read_bytes()).hexdigest() == receipt[hash_key]
for component, package in receipt['packages'].items():
    deployment = base / 'components-lookup-final'
    assert json.loads((deployment / (component + '.json')).read_text()) == package
    assert hashlib.sha256((deployment / package['artifact']).read_bytes()).hexdigest() == package['sha256']
for name, expected in receipt['reports'].items():
    assert hashlib.sha256((archive / name).read_bytes()).hexdigest() == expected
for path, name in (
    (base / 'producer-suites-bounded-lookup.json', 'producer-suites-bounded-lookup.json.gz'),
    (base / 'pure-lookup-final.log', 'pure-lookup-final.log.gz'),
    (base / 'archive_pure.py', 'archive_pure.py.gz'),
):
    packed = gzip.compress(path.read_bytes(), mtime=0)
    (archive / name).write_bytes(packed)
    receipt['reports'][name] = hashlib.sha256(packed).hexdigest()
receipt['pure_suite'] = dict(status='complete', modules=88, tests_per_mode=532,
    normal_tests=532, release_tests=532, failed=0, skipped=0, session=83126,
    source_commit=receipt['source_commit'], source_files_verified=175)
(archive / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
audit = root / 'docs/audits/selka-constant-producer-2026-10-11.md'
pending = ('The bounded full producer\n'
    'suite selects 88 files with 532 exact public tests per normal/release mode;\n'
    'its gate is still pending. No broader completion is claimed.')
completed = ('The frozen bounded producer\n'
    'suite passed all 88 modules: 532 public tests in normal mode and 532 in\n'
    'release/facts/leak-check mode, with zero failures or skips. The final archive\n'
    'verifies all 175 producer source files against the installed body-package\n'
    'source receipt and retains every per-file command, public-count assertion,\n'
    'output and source hash. No broader completion is claimed.')
text = audit.read_text()
assert pending in text
audit.write_text(text.replace(pending, completed))
print('verified frozen175; archived pure532 normal +532 release; zero failures/skips')
