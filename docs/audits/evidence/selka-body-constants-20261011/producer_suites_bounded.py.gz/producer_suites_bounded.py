import pathlib, subprocess, json, sys, re, os, hashlib
sys.path.insert(0,'/home/epentland/.codex/worktrees/selka-constant-pilot/mylang/selfhost')
from test_pilots import require_guest
root=pathlib.Path('/home/epentland/.codex/worktrees/selka-constant-pilot/mylang')
base=pathlib.Path('/home/epentland/ai/canopy/.selka-agent-cache/constant-closure')
seed=pathlib.Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
assert hashlib.sha256(seed.read_bytes()).hexdigest()=='c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b'
roots=[(p,len(re.findall(r'^public func test_[A-Za-z0-9_]+\(',p.read_text(),re.M))) for p in sorted((root/'selfhost/components/body_check').glob('*tests.my'))]
roots=[(p,count) for p,count in roots if count]
report=dict(complete=False,selection=[dict(path=str(p),count=count,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p,count in roots],total_per_mode=sum(c for p,c in roots),records=[])
def save(): (base/'producer-suites-bounded-lookup.json').write_text(json.dumps(report,indent=2)+'\n')
save()
env={k:v for k,v in os.environ.items() if not k.startswith(('MYLANG_','PILOT_')) or k=='MYLANG_COMPONENT_CACHE'}
env.update(MYLANG_ZIG='/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig',MYL_CORE_LEAKCHECK='1',MYLANG_COMPONENT_DIR=str(base/'components-lookup-final'),MYLANG_LEXER_MODE='reference',MYLANG_PARSER_MODE='reference',MYLANG_DECLARATION_MODE='reference',MYLANG_BODY_CHECK_MODE='reference',MYLANG_TYPE_INTERFACE_MODE='reference',MYLANG_TEST_INDEX_MODE='reference',MYLANG_CACHE_PLAN_MODE='reference')
print('selected',len(roots),'files,',report['total_per_mode'],'tests per mode',flush=True)
for release in (False,True):
    mode='release' if release else 'normal'
    for source,count in roots:
        flags=['--release','--verify-facts'] if release else []
        budget=['--max-steps','500000000','--max-memory','1G'] if source.name in ('profile_tests.my','constant_eval_tests.my') else (['--max-steps','100000000'] if source.name in ('indexed_tests.my','record_index_tests.my') else [])
        command=[str(seed),'test',str(source),'--force','--no-cache',*flags,*budget]
        r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=600)
        report['records'].append(dict(mode=mode,source=str(source),expected=count,command=command,status=r.returncode,stdout=r.stdout,stderr=r.stderr));save()
        print(mode,source.name,r.returncode,count,flush=True)
        if r.returncode: raise RuntimeError('pure test command failed: '+source.name)
        require_guest(r.stdout,count)
for selected in report['selection']: assert hashlib.sha256(pathlib.Path(selected['path']).read_bytes()).hexdigest()==selected['source_sha256']
report.update(complete=True,failed=0,skipped=0);save()
print('pure suite passed',report['total_per_mode'],'tests per mode',flush=True)
