#!/usr/bin/env python3
"""Exact existing language suites; native controls never prove selected support."""
import argparse
import json
from pathlib import Path
import shutil
import sys

parser = argparse.ArgumentParser(description=__doc__)
for name in ('source-root', 'compiler', 'component-dir', 'zig', 'work'):
    parser.add_argument('--' + name, type=Path, required=True)
parser.add_argument('--builder', type=Path)
parser.add_argument('--native-controls', action='store_true')
parser.add_argument('--body-schema', type=int, required=True)
args = parser.parse_args()
for name, value in vars(args).items():
    if isinstance(value, Path):
        setattr(args, name, value.resolve())
sys.path.insert(0, str(args.source_root / 'selfhost/tests'))
import run_body_library_admission as L
D, F = L.D, L.F
ROOTS = ('array_writes.my', 'array_places.my', 'array_negative_index.my', 'python_arrays.my', 'tuples.my')
modes = ('reference',) if args.native_controls else ('reference', 'shadow', 'component')
args.work.mkdir(parents=True, exist_ok=False)
source = args.work / 'sources'; source.mkdir()
empty = args.work / 'empty-path'; empty.mkdir()
selection = {}
for name in ROOTS:
    original = args.source_root / 'tests/lang' / name
    shutil.copyfile(original, source / name)
    selection[name] = {'source_sha256': F.digest(original), 'tests': L.test_selection(original)}
F.require(sum(len(spec['tests']) for spec in selection.values()) == 62, 'structural language selection changed')

def identity():
    return {'compiler_sha256': F.digest(args.compiler),
            'packages': D.packages(args.component_dir, body_schema=args.body_schema),
            'sources': {name: F.digest(args.source_root / 'tests/lang' / name) for name in ROOTS}}

before = identity()
report = {'complete': False, 'selected_admission': 'pending', 'native_controls': args.native_controls,
          'scope': 'Five complete existing language suites, including generic tuple cases and array iteration',
          'selection': selection, 'body_schema': args.body_schema, 'modes': list(modes),
          'expected_operations': len(ROOTS) * 3 * len(modes),
          'expected_tests_per_mode': 124, 'records': [], 'errors': [], **before}

def save():
    (args.work / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

save()
if not args.native_controls:
    F.require(args.builder is not None and args.body_schema == D.SCHEMA, 'selected suites need current qualified seed verification')
    seed = F.execute([args.builder, '--root', args.source_root, '--zig', args.zig, '--seed-only'],
                     D.coordinator_environment(), args.source_root, 600)
    report['seed_verification'] = {'status': seed[0], 'stdout_hex': seed[1].hex(), 'stderr_hex': seed[2].hex()}
    save()
    paths = seed[1].decode().strip().splitlines()
    F.require(seed[0] == 0 and len(paths) == 1 and Path(paths[0]).is_file(), 'qualified seed receipt failed')
    report['qualified_seed_sha256'] = F.digest(Path(paths[0]))

def run(name, mode, phase, command):
    argv = [args.compiler, *command]
    result = F.execute(argv, D.environment(mode, args.component_dir, empty), args.work, 600)
    record = {'name': name, 'mode': mode, 'phase': phase, 'command': list(map(str, argv)),
              'source_sha256': selection[name]['source_sha256'], 'status': result[0],
              'stdout_hex': result[1].hex(), 'stderr_hex': result[2].hex()}
    report['records'].append(record)
    save()
    return result, record

for name, spec in selection.items():
    entry = source / name
    commands = [('check', ['check', entry, '--no-cache', '--diagnostics=json'])]
    for release in (False, True):
        flags = ['--release', '--verify-facts'] if release else []
        commands.append(('release' if release else 'normal', ['test', entry, '--json', '--force',
            '--no-cache', '--jobs=1', '--max-steps=100000000', '--zig=' + str(args.zig), *flags]))
    for phase, command in commands:
        native = None
        for mode in modes:
            result, record = run(name, mode, phase, command)
            if mode == 'reference':
                native = result
            try:
                if phase == 'check':
                    L.require_library_match(native, result)
                else:
                    record['tests'] = L.require_tests(result, spec['tests'])
            except (RuntimeError, ValueError, KeyError) as error:
                report['errors'].append({'name': name, 'mode': mode, 'phase': phase, 'message': str(error)})
            save()

F.require(identity() == before, 'structural suite inputs changed')
F.require(len(report['records']) == report['expected_operations'], 'incomplete structural suite operations')
report.update(complete=True, failed=len(report['errors']), skipped=0, operations=len(report['records']))
if not report['errors'] and not args.native_controls:
    report['selected_admission'] = 'passed'
save()
print(f"structural language suites: {report['operations']} operations; {report['failed']} failed; selected {report['selected_admission']}")
raise SystemExit(1 if report['errors'] else 0)
