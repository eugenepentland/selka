from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-lexer-pilot/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
check = json.loads((work / 'filesystem-original-promotion-check.json').read_text())
assert check['complete'] and check['failed'] == check['skipped'] == 0
log = (work / 'filesystem-original-promotion-check.log').read_text()
assert 'Ran 17 tests' in log and '\nOK\n' in log and '88 check(s) passed' in log
proof = json.loads((work / 'filesystem-capability-selected-qualification.json').read_text())
assert proof['complete'] and proof['failed'] == proof['skipped'] == 0
manifest = json.loads((root / 'selfhost/tests/fixtures/body_entry_candidate/manifest.json').read_text())
promoted = ['entry_text_profile.my', 'entry_write_profile.my']
records = [r for r in proof['records'] if r['name'] in promoted]
assert len(records) == 24
for name in promoted:
    spec = manifest['cases'][name]
    source = root / 'selfhost/tests/fixtures/body_entry_candidate' / spec['source']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == spec['source_sha256'] == proof['fixture_sha256'][name]
    assert spec['class'] == 'success' and spec['native_status'] == spec['selected_status'] == 0
    for phase in ['check', 'typed', 'runtime-normal', 'runtime-release']:
        rows = [r for r in records if r['name'] == name and r['phase'] == phase]
        assert {r['mode'] for r in rows} == {'reference', 'shadow', 'component'}
        assert all(r['status'] == (7 if phase.startswith('runtime') else 0) for r in rows)
evidence = root / 'docs/audits/evidence/selka-original-filesystem-promotion-20261011'
evidence.mkdir(parents=True, exist_ok=False)
files = ['selfhost/tests/fixtures/body_entry_candidate/manifest.json',
         'selfhost/tests/run_body_entry_qualification.py',
         'selfhost/tests/body_entry_qualification_test.py',
         'selfhost/tests/body_entry_hostile_test.py', 'selfhost/test_body_entries.py']
receipt = dict(format=1, source_base='98e09f26f761de18dacdc2229a133eaecd38f3c4',
    promoted=promoted, source_operations=24, python_tests=17, guardian=88,
    entry_workflows_before=349, entry_workflows_after=357, entry_cases=24,
    current_classes=dict(success=16, diagnostic=8, profile=0),
    implementation_evidence='../selka-filesystem-producer-20261011/receipt.json',
    source_sha256={name:hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files},
    scope='Original source admission proven; full joined B7 generation gate pending', artifacts=[])
for name in ['filesystem-original-promotion-check.json', 'filesystem-original-promotion-check.log',
             'filesystem-original-promotion-stale-class.json', 'filesystem-original-promotion-stale-class.log',
             'filesystem-original-promotion-commit.py']:
    data = (work / name).read_bytes(); archive = gzip.compress(data, mtime=0)
    (evidence / (name + '.gz')).write_bytes(archive)
    receipt['artifacts'].append(dict(name=name+'.gz', sha256=hashlib.sha256(data).hexdigest(),
        archive_sha256=hashlib.sha256(archive).hexdigest(), bytes=len(data), archive_bytes=len(archive)))
(evidence / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
doc = root / 'docs/audits/selka-original-filesystem-promotion-2026-10-11.md'
doc.write_text('''# Original B7 filesystem fixture promotion

The unchanged entry_text_profile and entry_write_profile sources now require
successful selected checking. The complete filesystem proof supplies 24 checks,
typed comparisons and normal/release runtime operations for these two original
inputs across reference, shadow and component modes. Every source SHA matches
the original B7 manifest. No source, diagnostic or descriptor-limit fixture is
removed or edited; proposal.json remains the historical inventory.

B7 keeps all 24 cases and now requires 16 successes, eight diagnostics and zero
profile refusals. The two promoted cases add selected build/runtime trials in
both shadow and component modes, raising each generation lane from 349 to 357
operations. All seven actual component entries, two generations, 35 captures and
15 resource-reply attacks remain required. The full joined generation gate must
run against the integrated compiler; these accounting changes do not claim it
has passed.

All 17 entry harness tests and 88 Guardian checks pass. An initial harness test
still compared promoted classifications directly with the historical proposal;
its failure is retained, and the corrected assertion names exactly these two
promotions while preserving every original source and diagnostic comparison.

[The receipt](evidence/selka-original-filesystem-promotion-20261011/receipt.json)
binds the accounting changes and validation logs to
[the installed filesystem proof](selka-filesystem-producer-2026-10-11.md).
''')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *files, str(evidence.relative_to(root)), str(doc.relative_to(root))], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Require selected success for original B7 text and write fixtures'], cwd=root, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
print(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), flush=True)
