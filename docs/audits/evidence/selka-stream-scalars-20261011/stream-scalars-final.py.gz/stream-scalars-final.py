from pathlib import Path
import json
import subprocess
import sys
import tempfile

root = Path('/home/epentland/.codex/worktrees/selka-structural-pilot/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
sys.path.insert(0, str(root / 'selfhost/tests'))
import run_body_check_qualification as D

prefix = Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/buffer-iteration-native-prefix')
host, builder = prefix / 'bin/mylang', prefix / 'tools/selka-components'
packages = prefix.parent / 'stream-scalars-components'
zig = Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
prior_path = work / 'stream-scalars-qualification-before-unit-fixture-fix.json'
prior = json.loads(prior_path.read_text())
assert [r['status'] for r in prior['records']] == [0, 0, 0, 0, 0, 1]
assert D.packages(packages) == prior['packages'] and D.F.digest(host) == prior['host_sha256']
for name, digest in prior['source_sha256'].items():
    assert D.F.digest(root / name) == digest, name
manifest = json.loads((D.FIXTURES / 'manifest.json').read_text())
report = dict(complete=False, prior_validation=str(prior_path), prior_validation_sha256=D.F.digest(prior_path),
              source_sha256=prior['source_sha256'], host_sha256=prior['host_sha256'], packages=prior['packages'],
              fixture_sha256={name: D.F.digest(D.FIXTURES / Path(name).with_suffix('.input')) for name in manifest}, records=[])

def save():
    (work / 'stream-scalars-final.json').write_text(json.dumps(report, indent=2) + '\n')

def run(name, command):
    log = work / ('stream-scalars-final-' + name + '.log')
    print(name, flush=True)
    with log.open('wb') as output:
        result = subprocess.run(list(map(str, command)), cwd=root, stdout=output, stderr=subprocess.STDOUT)
    report['records'].append(dict(name=name, status=result.returncode, command=list(map(str, command)), log=str(log)))
    save()
    if result.returncode:
        print(log.read_text()[-8000:], flush=True)
        raise SystemExit(result.returncode)

save()
with tempfile.TemporaryDirectory(prefix='stream-final-controls-', dir=work) as temporary:
    directory = Path(temporary)
    empty = directory / 'empty'
    empty.mkdir()
    for name, spec in manifest.items():
        if not (name.startswith('stream_') or name == 'profile_stream_aggregate.my'):
            continue
        source = directory / name
        source.write_bytes((D.FIXTURES / Path(name).with_suffix('.input')).read_bytes())
        result = D.F.execute([host, 'check-project', source, '--no-cache', '--diagnostics=json'],
                             D.environment('reference', packages, empty), directory, 120)
        report['records'].append(dict(name=name, status=result[0], expected_status=0 if spec['status'] == 2 else spec['status'],
                                      stdout_hex=result[1].hex(), stderr_hex=result[2].hex()))
        save()
        assert result[0] == report['records'][-1]['expected_status'], (name, result)
for release in (False, True):
    label = 'main-release' if release else 'main-normal'
    run(label, [sys.executable, root / 'selfhost/tests/run_body_check_qualification.py',
        '--compiler', host, '--builder', builder, '--zig', zig, '--component-dir', packages,
        '--report', work / ('stream-scalars-final-' + label + '.json'), *(['--release'] if release else [])])
run('guardian', ['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check', 'all', '.', '--gate', '--full'])
run('diff', ['git', 'diff', '--check'])
for name, digest in report['source_sha256'].items():
    assert D.F.digest(root / name) == digest, name
for name, digest in report['fixture_sha256'].items():
    assert D.F.digest(D.FIXTURES / Path(name).with_suffix('.input')) == digest, name
assert D.F.digest(host) == report['host_sha256'] and D.packages(packages) == report['packages']
report.update(complete=True, failed=0, skipped=0)
save()
print('complete: scalar Stream output installed qualification', flush=True)
