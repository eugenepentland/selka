from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile

root = Path('/home/epentland/.codex/worktrees/selka-structural-pilot/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
sys.path.insert(0, str(root / 'selfhost/tests'))
import run_body_check_qualification as D

seed = Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
prefix = Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/buffer-iteration-native-prefix')
host = prefix / 'bin/mylang'
builder = prefix / 'tools/selka-components'
packages = prefix.parent / 'stream-scalars-components'
zig = Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
prior = json.loads((work / 'stream-scalars-preflight-earlyoom.json').read_text())
for name, digest in prior['source_sha256'].items():
    assert D.F.digest(root / name) == digest, name
assert [row['status'] for row in prior['records']] == [0, 0, 0, -15]
report = dict(complete=False, prior_normal_proof='stream-scalars-preflight-earlyoom.json',
              prior_termination='stream-scalars-earlyoom.log', seed_sha256=D.F.digest(seed),
              host_sha256=D.F.digest(host), source_sha256=prior['source_sha256'], records=[])

def save():
    (work / 'stream-scalars-qualification.json').write_text(json.dumps(report, indent=2) + '\n')

def run(name, command, env=None):
    log = work / ('stream-scalars-' + name + '.log')
    print(name, flush=True)
    with log.open('wb') as output:
        result = subprocess.run(list(map(str, command)), cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT)
    report['records'].append(dict(name=name, status=result.returncode, command=list(map(str, command)), log=str(log)))
    save()
    if result.returncode:
        print(log.read_text()[-8000:], flush=True)
        raise SystemExit(result.returncode)

save()
for name in ['resource_engine_tests.my', 'resource_lower_tests.my']:
    env = os.environ.copy()
    env['MYL_CORE_LEAKCHECK'] = '1'
    run(name + '-release', [seed, 'test', root / 'selfhost/components/body_check' / name,
        '--no-cache', '--force', f'--zig={zig}', '--release', '--verify-facts'], env)
run('harness', [sys.executable, '-m', 'unittest', 'discover', '-s', 'selfhost/tests', '-p', 'body*test.py'])
run('format', [host, 'fmt', '--check', root / 'selfhost/components/body_check/engine.my'])
manifest = json.loads((D.FIXTURES / 'manifest.json').read_text())
report['fixture_sha256'] = {name: D.F.digest(D.FIXTURES / Path(name).with_suffix('.input')) for name in manifest}
run('install', [builder, '--root', root, '--zig', zig, '--cache-dir', '/home/epentland/.cache/mylang/components', '--install-dir', packages])
report['packages'] = D.packages(packages)
save()
for release in (False, True):
    label = 'main-release' if release else 'main-normal'
    run(label, [sys.executable, root / 'selfhost/tests/run_body_check_qualification.py',
        '--compiler', host, '--builder', builder, '--zig', zig, '--component-dir', packages,
        '--report', work / ('stream-scalars-' + label + '.json'), *(['--release'] if release else [])])
run('guardian', ['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check', 'all', '.', '--gate', '--full'])
run('diff', ['git', 'diff', '--check'])
for name, digest in report['source_sha256'].items():
    assert D.F.digest(root / name) == digest, name
for name, digest in report['fixture_sha256'].items():
    assert D.F.digest(D.FIXTURES / Path(name).with_suffix('.input')) == digest, name
assert D.F.digest(host) == report['host_sha256'] and D.packages(packages) == report['packages']
report['complete'] = True
report['failed'] = report['skipped'] = 0
save()
print('complete: scalar Stream output installed qualification', flush=True)
