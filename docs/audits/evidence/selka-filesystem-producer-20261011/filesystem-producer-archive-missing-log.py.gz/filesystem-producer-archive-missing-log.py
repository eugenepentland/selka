from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-lexer-pilot/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
def read(name):
    return json.loads((work / name).read_text())
def sha(data):
    return hashlib.sha256(data).hexdigest()
proof = read('filesystem-capability-installed-proof.json')
selected = read('filesystem-capability-selected-qualification.json')
producer = read('filesystem-capability-producer-install.json')
pure = read('filesystem-producer-preflight.json')
cap = read('filesystem-capability-producer-preflight.json')
native = read('filesystem-capability-native-debug-install.json')
for report in [proof, selected, producer, pure, cap]:
    assert report['complete'] and report['failed'] == report['skipped'] == 0
assert selected['operations'] == selected['expected_operations'] == len(selected['records']) == 372
assert selected['hostile_complete'] and len(selected['hostile_records']) == 478
assert len(selected['hostile_captures']) == 4
assert sum(len(c['mutations']) for c in selected['hostile_captures']) == 235
assert sum(r['name'] == 'authentic' for r in selected['hostile_records']) == 8
assert all(r['status'] == (0 if r['name'] == 'authentic' else 2) for r in selected['hostile_records'])
assert pure['passed'] == 52 and cap['passed'] == 28
assert native['complete'] and native['status'] == 0
assert selected['compiler_sha256'] == proof['compiler_sha256'] == native['compiler_sha256']
assert selected['packages'] == proof['packages'] == producer['packages']
assert selected['source_sha256'] == proof['source_sha256'] == producer['source_sha256'] == cap['source_sha256']
for name, digest in producer['source_sha256'].items():
    assert sha((root / name).read_bytes()) == digest, name
changed_since_pure = [name for name, digest in pure['source_sha256'].items()
                      if producer['source_sha256'].get(name) != digest]
assert set(changed_since_pure) == {'selfhost/components/body_check/record_types.my',
                                 'selfhost/components/body_check/record_type_tests.my'}
assert '88 check(s) passed' in (work / 'filesystem-capability-installed-guardian.log').read_text()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == pure['source_head']
evidence = root / 'docs/audits/evidence/selka-filesystem-producer-20261011'
evidence.mkdir(parents=True, exist_ok=False)
paths = {}
def add(path, name=None):
    assert path.is_file(), path
    key = name or path.name
    assert key not in paths or paths[key] == path, key
    paths[key] = path
for prefix in ['filesystem-producer-preflight', 'filesystem-capability-producer-preflight',
               'filesystem-capability-producer-install', 'filesystem-capability-installed-proof',
               'filesystem-capability-selected-qualification', 'filesystem-capability-native-debug-install']:
    for suffix in ['.json', '.log']:
        add(work / (prefix + suffix))
for name in ['filesystem-producer-preflight.py', 'filesystem-capability-producer-preflight.py',
             'filesystem-capability-producer-install.py', 'filesystem-capability-installed-proof.py',
             'filesystem-producer-archive-commit.py',
             'filesystem-producer-preflight-before-default-fix.json',
             'filesystem-producer-preflight-before-default-fix.log',
             'before-closeout-fixes-filesystem-installed-proof.json',
             'before-closeout-fixes-filesystem-installed-proof.log',
             'before-closeout-fixes-filesystem-selected-qualification.json',
             'before-closeout-fixes-filesystem-selected-qualification.log']:
    add(work / name)
for report in [pure, cap, proof]:
    for record in report['records']:
        if record.get('log'):
            add(Path(record['log']))
for capture in selected['hostile_captures']:
    for field in ['request', 'reply']:
        path = Path(capture[field + '_path'])
        assert sha(path.read_bytes()) == capture[field + '_sha256']
        add(path, capture['name'] + '-' + field + '.bin')
for record in selected['hostile_records']:
    path = Path(record['payload_path'])
    assert sha(path.read_bytes()) == record['payload_sha256']
    add(path, record['capture'] + '-' + record['name'] + '.bin')
harness = ['selfhost/tests/run_body_filesystem_admission.py',
           'selfhost/tests/run_body_filesystem_hostile.py',
           'selfhost/tests/body_filesystem_admission_test.py']
receipt = dict(format=1, source_base=pure['source_head'], native_source=native['source_head'],
    compiler_sha256=proof['compiler_sha256'], packages=proof['packages'],
    qualified_seed_sha256=selected['qualified_seed_sha256'],
    source_sha256=producer['source_sha256'],
    harness_sha256={name: sha((root / name).read_bytes()) for name in harness},
    earlier_pure_source_changes=changed_since_pure,
    pure_passes={'filesystem':52, 'capability_record_and_hash_policy':28},
    installed=dict(fixtures=59, source_operations=372, captures=4, mutations=235,
                   rejected_replies=470, authentic_replays=8, python_tests=5, guardian=88),
    scope='Debug native host; normal and release/facts/leak guest execution; joined root and full compiler bootstrap pending',
    artifacts=[])
for name, path in sorted(paths.items()):
    data = path.read_bytes()
    archive = gzip.compress(data, mtime=0)
    target = evidence / (name + '.gz')
    target.write_bytes(archive)
    assert gzip.decompress(target.read_bytes()) == data
    receipt['artifacts'].append(dict(name=target.name, source=str(path), bytes=len(data),
        sha256=sha(data), archive_bytes=len(archive), archive_sha256=sha(archive)))
(evidence / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
doc = root / 'docs/audits/selka-filesystem-producer-2026-10-11.md'
doc.write_text('''# Selected filesystem bodies and capability records

The producer now checks all nine primitive filesystem access operations and all
six scoped file methods, including text/binary read and write modes. It preserves
native argument checks, result shapes, scoped cleanup and single evaluation of
receiver expressions. Filesystem and Stream fields participate in ordinary
record closure; their structural hash-key policy remains unchanged.

The installed comparison passes 59 unchanged fixtures: 47 accepted and 12 exact
diagnostic cases. All 372 source operations pass across native, shadow and
component modes, including exact typed output and nine runtime fixtures in both
normal and release/facts/leak builds. Original B7 text/write inputs are copied
unchanged into this strict corpus. The field-receiver fixture that previously
stopped at operation 326 now passes checking, typed output and execution.

Four fresh authenticated exchanges cover every access/method family. Their 235
distinct altered outcomes are each rejected as ComponentProtocol in both selected
modes (470 rejections); eight unmodified replays succeed. The durable harness
retains frames, payloads and partial results and verifies deployment/source
identity before claiming completion. Five harness tests and all 88 Guardian
checks pass. Earlier failures remain in the evidence archive.

The filesystem pure suites passed 26 tests per mode before the capability-record
follow-up. That follow-up changed only record_types.my and record_type_tests.my;
its record/hash-policy suites passed 14 tests per mode. The receipt distinguishes
these source snapshots. The final source then rebuilt with the unchanged c4f1ea0b
qualified seed and passed the complete installed filesystem comparison.

The installed native host comes from 8987826f05f0cd4adf2d0523ddb8df4262024935;
the body artifact is e5881022e952a5775a636859e18ca0a94a360c26f94c269dbe1d5a7bd2ce529b
(schema 10). Integrate native prerequisites ed562913ecbe58a89f65a3baeb03a66a91a6e611
and 8987826f before this producer. The source base is 0ce4c813f; the later text,
sequence and schema-11 generic work requires coherent integration and a new full
root gate. This proof uses a Debug native host and both guest build modes. It
does not establish full compiler bootstrap or the 1.5-times performance target.

[The receipt](evidence/selka-filesystem-producer-20261011/receipt.json) binds exact
commands, source and deployment hashes, full logs and the captured reply trials.
''')
owned = ['selfhost/components/body_check/engine.my',
         'selfhost/components/body_check/record_types.my',
         'selfhost/components/body_check/record_type_tests.my',
         'selfhost/components/body_check/resource_engine_tests.my',
         'selfhost/components/body_check/resource_lower.my',
         'selfhost/components/body_check/resource_lower_tests.my',
         'selfhost/components/body_check/file_operations.my',
         'selfhost/components/body_check/file_operations_tests.my', *harness,
         'selfhost/tests/fixtures/body_filesystem_candidate',
         str(evidence.relative_to(root)), str(doc.relative_to(root))]
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *owned], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Qualify filesystem body checking and capability record receivers'], cwd=root, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
print(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), flush=True)
print('Archived', len(paths), 'artifacts with verified compressed and original digests', flush=True)
