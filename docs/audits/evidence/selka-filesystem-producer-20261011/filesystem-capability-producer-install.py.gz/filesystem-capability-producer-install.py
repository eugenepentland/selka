from pathlib import Path
import json,subprocess,sys
root=Path('/home/epentland/.codex/worktrees/selka-lexer-pilot/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
prior=json.loads((work/'filesystem-capability-producer-preflight.json').read_text())
assert prior['complete'] and prior['failed']==prior['skipped']==0
prefix=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/aggregate-output-native-prefix')
builder=prefix/'tools/selka-components'
packages=prefix.parent/'filesystem-capability-components'
zig='/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'
report=dict(complete=False,seed_sha256=prior['seed_sha256'],source_sha256=prior['source_sha256'],coordinator_sha256=D.F.digest(builder),records=[])
path=work/'filesystem-capability-producer-install.json'
def save():path.write_text(json.dumps(report,indent=2)+'\n')
for name,sha in prior['source_sha256'].items():assert D.F.digest(root/name)==sha,name
save()
cmd=list(map(str,[builder,'--root',root,'--zig',zig,'--cache-dir','/home/epentland/.cache/mylang/components','--install-dir',packages]))
r=subprocess.run(cmd,cwd=root)
report['records'].append(dict(command=cmd,status=r.returncode));save()
if r.returncode:raise SystemExit(r.returncode)
report['packages']=D.packages(packages)
for name,sha in prior['source_sha256'].items():assert D.F.digest(root/name)==sha,name
report.update(complete=True,failed=0,skipped=0);save()
