from pathlib import Path
import hashlib,json,subprocess,sys
root=Path('/home/epentland/.codex/worktrees/selka-lexer-pilot/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
native=json.loads((work/'filesystem-capability-native-debug-install.json').read_text())
producer=json.loads((work/'filesystem-capability-producer-install.json').read_text())
assert native['complete'] and native['status']==0 and producer['complete'] and producer['failed']==0
prefix=Path(native['prefix']);host=prefix/'bin/mylang';builder=prefix/'tools/selka-components'
packages=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/filesystem-capability-components')
zig='/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'
assert D.F.digest(host)==native['compiler_sha256'] and D.packages(packages)==producer['packages']
for name,sha in producer['source_sha256'].items():assert D.F.digest(root/name)==sha,name
report=dict(complete=False,source_sha256=producer['source_sha256'],packages=producer['packages'],compiler_sha256=native['compiler_sha256'],records=[])
path=work/'filesystem-capability-installed-proof.json'
def save():path.write_text(json.dumps(report,indent=2)+'\n')
def run(label,cmd):
 log=work/('filesystem-capability-'+label+'.log');print(label,flush=True)
 with log.open('wb') as out:r=subprocess.run(list(map(str,cmd)),cwd=root,stdout=out,stderr=subprocess.STDOUT)
 report['records'].append(dict(name=label,command=list(map(str,cmd)),status=r.returncode,log=str(log)));save()
 if r.returncode:print(log.read_text(errors='replace')[-12000:],flush=True);raise SystemExit(r.returncode)
save()
run('admission-selftests',[sys.executable,'-m','unittest','discover','-s','selfhost/tests','-p','body_filesystem_admission_test.py'])
run('selected-qualification',[sys.executable,root/'selfhost/tests/run_body_filesystem_admission.py','--compiler',host,'--builder',builder,'--zig',zig,'--component-dir',packages,'--source-root',root,'--report',work/'filesystem-capability-selected-qualification.json'])
run('installed-guardian',['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check','all','.','--gate','--full'])
for name,sha in report['source_sha256'].items():assert D.F.digest(root/name)==sha,name
assert D.F.digest(host)==report['compiler_sha256'] and D.packages(packages)==report['packages']
report.update(complete=True,failed=0,skipped=0);save()
