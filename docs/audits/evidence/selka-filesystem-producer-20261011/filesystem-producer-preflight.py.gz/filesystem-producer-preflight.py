from pathlib import Path
import json,os,subprocess,sys
root=Path('/home/epentland/.codex/worktrees/selka-lexer-pilot/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
seed=Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
report=dict(complete=False,seed_sha256=D.F.digest(seed),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),records=[])
assert report['seed_sha256']=='c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b'
empty=work/'filesystem-seed-empty';empty.mkdir(exist_ok=True)
env=D.environment('reference',empty,empty)
path=work/'filesystem-producer-preflight.json'
def save():path.write_text(json.dumps(report,indent=2)+'\n')
def run(label,command):
 log=work/('filesystem-producer-'+label+'.log');print(label,flush=True)
 with log.open('wb') as out:r=subprocess.run(list(map(str,command)),cwd=root,env=(os.environ.copy() if label in ['guardian','diff'] else env),stdout=out,stderr=subprocess.STDOUT)
 report['records'].append(dict(name=label,status=r.returncode,command=list(map(str,command)),log=str(log)));save()
 if r.returncode:print(log.read_text(errors='replace')[-16000:],flush=True);raise SystemExit(r.returncode)
for name in ['engine.my','file_operations.my','file_operations_tests.my','resource_lower.my','resource_lower_tests.my','resource_engine_tests.my']:
 p=root/'selfhost/components/body_check'/name;r=subprocess.run([str(seed),'fmt',str(p)],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 report['records'].append(dict(name='format-'+name,status=r.returncode,stderr_hex=r.stderr.hex(),source_before=D.F.digest(p)));save()
 if r.returncode:print(r.stderr.decode(errors='replace'),flush=True);raise SystemExit(r.returncode)
 p.write_bytes(r.stdout)
report['source_sha256']={str(p.relative_to(root)):D.F.digest(p) for p in sorted((root/'selfhost/components/body_check').glob('*.my'))};save()
run('seed-check',[seed,'check',root/'selfhost/components/body_check/main.my','--no-cache'])
for release in [False,True]:
 for module,count in [('file_operations_tests.my',3),('resource_lower_tests.my',6),('resource_engine_tests.my',17)]:
  label=module+('-release' if release else '-normal')
  run(label,[seed,'test',root/'selfhost/components/body_check'/module,'--no-cache','--force',f'--zig={zig}',*(['--release','--verify-facts'] if release else [])])
  text=(work/('filesystem-producer-'+label+'.log')).read_text()
  assert f'{count} passed, 0 cached, 0 failed, 0 skipped' in text,(label,text[-2500:])
run('guardian',['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check','all','.','--gate','--full'])
run('diff',['/usr/bin/git','diff','--check'])
for name,sha in report['source_sha256'].items():assert D.F.digest(root/name)==sha,name
assert D.F.digest(seed)==report['seed_sha256']
report.update(complete=True,passed=52,failed=0,skipped=0);save()
