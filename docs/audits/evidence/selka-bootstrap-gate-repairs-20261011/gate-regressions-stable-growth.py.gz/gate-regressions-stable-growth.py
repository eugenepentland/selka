from pathlib import Path
import hashlib,json,subprocess,os
root=Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
zig='/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'
seed='/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang'
report=dict(complete=False,records=[])
path=work/'gate-regressions-stable-growth.json'
def save():path.write_text(json.dumps(report,indent=2)+'\n')
def run(label,cmd):
 log=work/('gate-regressions-'+label+'.log')
 with log.open('wb') as out:r=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 report['records'].append(dict(name=label,command=cmd,status=r.returncode,log=str(log)));save();print(label,r.returncode,flush=True)
 if r.returncode: print(log.read_text(errors='replace')[-12000:],flush=True)
 return r.returncode
run('stable-growth-format',[zig,'fmt','build.zig','src/core/test_runner_graph_test.zig'])
report['source_sha256']={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['build.zig','selfhost/components/body_check/sequence_tests.my','src/core/test_runner_graph.zig','src/core/test_runner_graph_test.zig']};save()
for mode in ['Debug','ReleaseFast']:
 code=run('stable-growth-'+mode,[zig,'build','test-core','-Dtest-filter=graph metadata','-Doptimize='+mode,'-j1','--maxrss','8589934592','--summary','all'])
 if code:report.update(complete=True,status=code);save();raise SystemExit(code)
code=run('stable-growth-guardian',['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check','all','.','--gate','--full'])
if code:report.update(complete=True,status=code);save();raise SystemExit(code)
code=run('stable-growth-diff',['git','diff','--check'])
for name,sha in report['source_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
report.update(complete=True,status=code);save();raise SystemExit(code)
