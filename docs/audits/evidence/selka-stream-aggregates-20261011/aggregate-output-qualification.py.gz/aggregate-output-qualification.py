from pathlib import Path
import argparse,json,subprocess,sys
root=Path('/home/epentland/.codex/worktrees/selka-structural-pilot/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
parser=argparse.ArgumentParser();parser.add_argument('--host-mode',choices=['debug','release'],required=True);args=parser.parse_args()
label='aggregate-output-'+args.host_mode
native_name='output-native-debug-install.json' if args.host_mode=='debug' else 'output-native-install.json'
native=json.loads((work/native_name).read_text()); assert native['complete'] and native['status']==0,native
prior_path=work/'aggregate-output-preflight.json'; prior=json.loads(prior_path.read_text());assert prior['complete'] and prior['failed']==prior['skipped']==0
prefix=Path(native['prefix']);host,builder=prefix/'bin/mylang',prefix/'tools/selka-components'
packages=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/aggregate-output-components')
zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
assert D.F.digest(host)==native['compiler_sha256'] and D.F.digest(builder)==native['coordinator_sha256']
assert D.packages(packages)==prior['packages']
for name,sha in prior['source_sha256'].items(): assert D.F.digest(root/name)==sha,name
for name,sha in prior['fixture_sha256'].items(): assert D.F.digest(D.FIXTURES/Path(name).with_suffix('.input'))==sha,name
report=dict(complete=False,host_mode=args.host_mode,host_sha256=native['compiler_sha256'],coordinator_sha256=native['coordinator_sha256'],native_source_head=native['source_head'],prior_validation=str(prior_path),prior_validation_sha256=D.F.digest(prior_path),source_sha256=prior['source_sha256'],fixture_sha256=prior['fixture_sha256'],packages=prior['packages'],records=[])
def save(): (work/(label+'-qualification.json')).write_text(json.dumps(report,indent=2)+'\n')
def run(name,command):
 log=work/(label+'-'+name+'.log');print(name,flush=True)
 with log.open('wb') as out: result=subprocess.run(list(map(str,command)),cwd=root,stdout=out,stderr=subprocess.STDOUT)
 report['records'].append(dict(name=name,status=result.returncode,command=list(map(str,command)),log=str(log)));save()
 if result.returncode: print(log.read_text()[-12000:],flush=True);raise SystemExit(result.returncode)
save()
for release in (False,True):
 name='main-release' if release else 'main-normal';target=work/(label+'-'+name+'.json')
 run(name,[sys.executable,root/'selfhost/tests/run_body_check_qualification.py','--compiler',host,'--builder',builder,'--zig',zig,'--component-dir',packages,'--report',target,*(['--release'] if release else [])])
 proof=json.loads(target.read_text());assert proof['workflows']==530 and proof['comparisons']==1060 and proof['failed']==proof['skipped']==0,proof.keys()
run('guardian',['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check','all','.','--gate','--full'])
run('diff',['git','diff','--check'])
for name,sha in report['source_sha256'].items(): assert D.F.digest(root/name)==sha,name
for name,sha in report['fixture_sha256'].items(): assert D.F.digest(D.FIXTURES/Path(name).with_suffix('.input'))==sha,name
assert D.F.digest(host)==report['host_sha256'] and D.packages(packages)==report['packages']
report.update(complete=True,failed=0,skipped=0);save();print('complete: aggregate Stream output installed qualification',flush=True)
