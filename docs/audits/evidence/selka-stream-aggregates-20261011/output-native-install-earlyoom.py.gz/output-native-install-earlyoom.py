from pathlib import Path
import hashlib, json, subprocess
root=Path('/home/epentland/.codex/worktrees/selka-output-native/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
prefix=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/aggregate-output-native-prefix')
zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert not git('status','--porcelain')
report=dict(complete=False,source_head=git('rev-parse','HEAD'),prefix=str(prefix))
path=work/'output-native-install.json'
path.write_text(json.dumps(report,indent=2)+'\n')
command=[str(zig),'build','-Doptimize=ReleaseFast','--prefix',str(prefix),'-j1','--maxrss','8589934592','--summary','all']
report['command']=command
result=subprocess.run(command,cwd=root)
report.update(status=result.returncode,source_head_after=git('rev-parse','HEAD'),dirty_after=git('status','--porcelain'),complete=True)
if result.returncode==0:
    report['compiler_sha256']=digest(prefix/'bin/mylang')
    report['coordinator_sha256']=digest(prefix/'tools/selka-components')
    seed=Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
    report['qualified_seed_sha256']=digest(seed)
path.write_text(json.dumps(report,indent=2)+'\n')
assert report['source_head']==report['source_head_after'] and not report['dirty_after']
raise SystemExit(result.returncode)
