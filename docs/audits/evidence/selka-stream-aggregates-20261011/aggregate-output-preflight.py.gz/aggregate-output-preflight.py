from pathlib import Path
import json,os,subprocess,sys,tempfile
root=Path('/home/epentland/.codex/worktrees/selka-structural-pilot/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
seed=Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
prefix=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/buffer-iteration-native-prefix')
host,builder=prefix/'bin/mylang',prefix/'tools/selka-components'
packages=prefix.parent/'aggregate-output-components'
zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
report=dict(complete=False,seed_sha256=D.F.digest(seed),records=[])
assert report['seed_sha256']=='c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b'
def save(): (work/'aggregate-output-preflight.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,command,env=None):
 log=work/('aggregate-output-'+name+'.log'); print(name,flush=True)
 with log.open('wb') as out: result=subprocess.run(list(map(str,command)),cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 report['records'].append(dict(name=name,status=result.returncode,command=list(map(str,command)),log=str(log)));save()
 if result.returncode: print(log.read_text()[-10000:],flush=True);raise SystemExit(result.returncode)
def format_file(path):
 command=[str(seed),'fmt',str(path)]
 before=D.F.digest(path)
 result=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 record=dict(name='format-'+path.name,status=result.returncode,source_before=before,command=command,stderr_hex=result.stderr.hex())
 report['records'].append(record);save()
 if result.returncode: print(result.stderr.decode(),flush=True);raise SystemExit(result.returncode)
 path.write_bytes(result.stdout);record['source_after']=D.F.digest(path);save()
for name in ['engine.my','print_types.my','print_types_tests.my']:
 format_file(root/'selfhost/components/body_check'/name)
with tempfile.TemporaryDirectory(prefix='aggregate-format-',dir=work) as temp:
 paths=[]
 for candidate in sorted((work/'aggregate-output-candidates').glob('*.my')):
  target=Path(temp)/candidate.name;target.write_bytes((D.FIXTURES/candidate.with_suffix('.input').name).read_bytes()); paths.append(target)
 for path in paths: format_file(path)
 for path in paths: (D.FIXTURES/path.with_suffix('.input').name).write_bytes(path.read_bytes())
report['source_sha256']={str(p.relative_to(root)):D.F.digest(p) for p in sorted((root/'selfhost/components/body_check').glob('*.my'))}
manifest=json.loads((D.FIXTURES/'manifest.json').read_text())
report['fixture_sha256']={name:D.F.digest(D.FIXTURES/Path(name).with_suffix('.input')) for name in manifest}
save()
run('seed-check',[seed,'check',root/'selfhost/components/body_check/main.my','--no-cache'])
for release in (False,True):
 for name in ['print_types_tests.my','resource_engine_tests.my']:
  env=os.environ.copy()
  if release: env['MYL_CORE_LEAKCHECK']='1'
  run(name+('-release' if release else '-normal'),[seed,'test',root/'selfhost/components/body_check'/name,'--no-cache','--force',f'--zig={zig}',*(['--release','--verify-facts'] if release else [])],env)
run('harness',[sys.executable,'-m','unittest','discover','-s','selfhost/tests','-p','body*test.py'])
# Check and execute the corrected FixedArray source before installed qualification.
with tempfile.TemporaryDirectory(prefix='aggregate-fixed-',dir=work) as temp:
 directory=Path(temp); empty=directory/'empty';empty.mkdir();source=directory/'stream_fixed_arrays.my'
 source.write_bytes((D.FIXTURES/'stream_fixed_arrays.input').read_bytes())
 env=D.environment('reference',empty,empty)
 checked=D.F.execute([host,'check-project',source,'--no-cache','--diagnostics=json'],env,directory,120)
 runtime=D.F.execute([host,'run-project',source,'--print-result','--cache-dir',directory/'cache',f'--zig={zig}'],env,directory,120) if checked[0]==0 else None
 report['fixed_array_native']=dict(source_sha256=D.F.digest(source),check=[checked[0],checked[1].hex(),checked[2].hex()],runtime=[runtime[0],runtime[1].hex(),runtime[2].hex()] if runtime else None);save()
 assert checked==(0,b'',b'') and runtime==(7,b'[3, 4] [8, 4] []\n7\n',b'')
run('install',[builder,'--root',root,'--zig',zig,'--cache-dir','/home/epentland/.cache/mylang/components','--install-dir',packages])
report['packages']=D.packages(packages)
for name,sha in report['source_sha256'].items(): assert D.F.digest(root/name)==sha,name
for name,sha in report['fixture_sha256'].items(): assert D.F.digest(D.FIXTURES/Path(name).with_suffix('.input'))==sha,name
report.update(complete=True,failed=0,skipped=0);save();print('complete: aggregate producer preflight and installation',flush=True)
