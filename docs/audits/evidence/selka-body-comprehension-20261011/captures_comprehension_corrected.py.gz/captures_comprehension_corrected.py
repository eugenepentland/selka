import sys,shutil,json
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path('selfhost/tests').resolve()))
import run_body_check_qualification as D
cache=Path('/home/epentland/ai/canopy/.selka-agent-cache/loops')
args=SimpleNamespace(zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'),component_dir=cache/'comprehension-installed-direct')
host=cache/'nested-gather-native-prefix/bin/mylang'
base=D.packages; D.packages=lambda directory:base(directory,body_schema=10)
records=[]
for name in ('array_pairs','nested_array','generator_array_pairs','generator_float','generator_short_circuit_exact','generator_join','generator_mutation'):
 work=cache/('capture-comprehension-corrected-'+name);work.mkdir(exist_ok=True);empty=work/'empty';empty.mkdir(exist_ok=True)
 q=SimpleNamespace(work=work,source=work,empty_path=empty,compiler=host)
 shutil.copyfile('selfhost/tests/fixtures/body_comprehension_candidate/'+name+'.input',work/'main.my')
 private,real=D.private_fixture(args,q)
 result,request,reply=D.capture_exchange(args,q,private,real,'main.my')
 assert result==(0,b'',b''),(name,result)
 records.append({'name':name,'status':result[0],'request_bytes':len(request),'reply_bytes':len(reply),'request_sha256':D.F.hashlib.sha256(request).hexdigest(),'reply_sha256':D.F.hashlib.sha256(reply).hexdigest()})
 print(name,len(request),len(reply),flush=True)
(cache/'captures-comprehension-corrected.json').write_text(json.dumps(records,indent=2)+'\n')
