import hashlib,json,shutil,struct,sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0, '/home/epentland/.codex/worktrees/selka-compiler-probes/mylang/selfhost/tests')
import run_body_check_qualification as D
work=Path(__file__).resolve().parent
original=Path('/home/epentland/ai/canopy/.selka-agent-cache/lexer-b8/coherent-prefix')
prefix=work/'prefix'
expected='3d2691ca0798a1a8ecf9e8e8ae73d7e664a45868861cf3ef6831e8c5380d78d3'
D.F.require(D.F.digest(original/'bin/mylang')==expected,'original host changed; refuse snapshot')
if not prefix.exists(): shutil.copytree(original,prefix)
D.F.require(D.F.digest(prefix/'bin/mylang')==expected,'snapshot host differs')
source=work/'sources';empty=work/'empty-path';empty.mkdir(exist_ok=True)
args=SimpleNamespace(compiler=prefix/'bin/mylang',component_dir=prefix/'libexec/mylang/components',zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'))
q=SimpleNamespace(work=work,source=source,empty_path=empty,compiler=args.compiler)
packages=D.packages(args.component_dir,body_schema=8)
D.F.require(packages['body-check']['sha256']=='a64d7afd992bacc01ce87d7815c8e53a9c5178c2c2ddb9e692f6df856bf7d641','snapshot body differs')
private,real=D.private_fixture(args,q)
receipt={'complete':False,'schema':8,'purpose':'Additional language gap discovery, not stage qualification','producer_revision':'173a154a2','host_sha256':expected,'packages':packages,'cases':[]}
def save(): (work/'report.json').write_text(json.dumps(receipt,indent=2)+'\n')
save()
for stem in json.loads((work/'case-order.json').read_text()):
 name=stem+'.my';entry=source/name
 native=D.F.execute([args.compiler,'check-project',entry,'--diagnostics=json','--no-cache'],D.environment('reference',args.component_dir,empty),work)
 (work/(stem+'.reference.stderr')).write_bytes(native[2])
 row={'source':name,'source_sha256':D.F.digest(entry),'native_status':native[0]}
 if native[0]!=0:
  row['classification']='invalid source fixture';receipt['cases'].append(row);save();print(stem,'native refused',flush=True);continue
 captured,request,reply=D.capture_exchange(args,q,private,real,name)
 D.F.require(struct.unpack('<IIII',request[8:24])==(1,8,0,len(request)-64),'not genuine schema8 request')
 (work/(stem+'.request.bin')).write_bytes(request);(work/(stem+'.reply.bin')).write_bytes(reply)
 shadow=D.F.execute([args.compiler,'check-project',entry,'--diagnostics=json','--no-cache'],D.environment('shadow',args.component_dir,empty),work)
 (work/(stem+'.component.stderr')).write_bytes(captured[2]);(work/(stem+'.shadow.stderr')).write_bytes(shadow[2])
 row.update(component_status=captured[0],shadow_status=shadow[0],component_exact=captured==native,shadow_exact=shadow==native,request_sha256=hashlib.sha256(request).hexdigest(),reply_sha256=hashlib.sha256(reply).hexdigest())
 receipt['cases'].append(row);save();print(stem,native[0],captured[0],shadow[0],captured==native,shadow==native,flush=True)
D.F.require(D.F.digest(args.compiler)==expected and D.packages(args.component_dir,body_schema=8)==packages,'snapshot changed during run')
receipt['complete']=True;save()
