from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/epentland/.codex/worktrees/selka-output-native/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
zig='/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'
files=['src/body_check_resource_authority.zig','src/body_check_resource_validate.zig','src/body_check_resource_test.zig','SPEC.md']
report=dict(complete=False,source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),records=[])
path=work/'filesystem-native-focused.json'
def hashes(): return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
def save(): path.write_text(json.dumps(report,indent=2)+'\n')
def run(label,command):
 log=work/('filesystem-native-'+label+'.log')
 with log.open('wb') as out: r=subprocess.run(command,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 report['records'].append(dict(name=label,command=command,status=r.returncode,log=str(log)));save();print(label,r.returncode,flush=True)
 if r.returncode:
  print(log.read_text(errors='replace')[-12000:],flush=True);raise SystemExit(r.returncode)
run('format',[zig,'fmt',*files[:3]])
report['source_sha256']=hashes();save()
run('debug',[zig,'build','test-units','-Dtest-filter=body resources','-Doptimize=Debug','-j1','--maxrss','8589934592','--summary','all'])
run('guardian',['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check','all','.','--gate','--full'])
run('diff',['git','diff','--check'])
assert hashes()==report['source_sha256']
report.update(complete=True,failed=0,skipped=0);save()
