from pathlib import Path
import subprocess,hashlib,json,re,shutil
root=Path.cwd();lane=root/'.tmp/zero-review';origin=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-abi5-review-20260930/.tmp/qbe-zero-branch-review')
for name in ('fixtures.ssa','oracle.c','design.json','prepare.py'):shutil.copy2(origin/name,lane/name)
zig=Path('/home/epentland/zig-toolchains')/(root/'.zigversion').read_text().strip()/'zig'
text=(root/'build.zig').read_text().split('const qbe_sources = [_][]const u8{',1)[1].split('};',1)[0]
sources=[str(root/'vendor/qbe'/p) for p in re.findall(r'"([^"]+)"',text)]
qbe=lane/'qbe';rows=[]
def run(name,argv):
 p=subprocess.run(argv,cwd=root,capture_output=True,text=True,timeout=600)
 (lane/(name+'.stdout')).write_text(p.stdout);(lane/(name+'.stderr')).write_text(p.stderr)
 rows.append({'name':name,'argv':list(map(str,argv)),'status':p.returncode})
 print(name,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==0,(name,p.stderr)
run('qbe-source-build',[str(zig),'cc','-std=c99','-O3','-fno-sanitize=undefined','-I',str(root/'vendor/qbe'),*sources,'-o',str(qbe)])
for name,ssa,c in [('production',root/'tests/fixtures/qbe-zero-branch/probe.ssa',root/'tests/fixtures/qbe-zero-branch/probe.c'),('independent',lane/'fixtures.ssa',lane/'oracle.c')]:
 asm=lane/(name+'.s');binary=lane/name
 run(name+'-select',[str(qbe),'-o',str(asm),str(ssa)])
 run(name+'-link',[str(zig),'cc','-std=c11','-O2','-UNDEBUG','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),str(asm),'-o',str(binary)])
 run(name+'-execute',[str(binary)])
files=[root/'vendor/qbe/amd64/isel.c',root/'vendor/qbe/copy.c',lane/'fixtures.ssa',lane/'oracle.c',qbe,lane/'production.s',lane/'independent.s']
receipt={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'protocol':'Independent pinned Zig cc build from all committed QBE translation units; no compiler/cache reuse; UBSan unsigned C oracles, no timing claim','commands':rows,'sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(lane/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
