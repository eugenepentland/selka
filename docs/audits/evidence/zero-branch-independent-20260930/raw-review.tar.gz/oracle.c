/* Independent QBE ZF fold oracle: unsigned arithmetic, no timings. */
#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
__attribute__((noinline)) uint64_t review_flag_clobber(uint64_t x) {
 (void)x; uint64_t result; __asm__ volatile("xor %%eax,%%eax" : "=a"(result) : : "cc"); return result;
}
extern int add64_ne(uint64_t,uint64_t,uint64_t *);
extern int add64_eq(uint64_t,uint64_t,uint64_t *);
extern int add64_swap_ne(uint64_t,uint64_t,uint64_t *);
extern int sub64_eq(uint64_t,uint64_t,uint64_t *);
extern int sub64_ne(uint64_t,uint64_t,uint64_t *);
extern int add32_ne(uint64_t,uint64_t,uint64_t *);
extern int sub32_eq(uint64_t,uint64_t,uint64_t *);
extern int width_mismatch(uint64_t,uint64_t,uint64_t *);
extern int nonzero_comparand(uint64_t,uint64_t,uint64_t *);
extern int boolean_multiuser(uint64_t,uint64_t,uint64_t *);
extern int intervening_call(uint64_t,uint64_t,uint64_t *);
extern int intervening_arithmetic(uint64_t,uint64_t,uint64_t *);
extern int arithmetic_multiuser(uint64_t,uint64_t,uint64_t *);
extern int address_use(uint64_t *,uint64_t *);
extern uint64_t pressure(uint64_t,uint64_t,uint64_t *,uint64_t *);
static unsigned assertions, failures;
static void check(const char *name,uint64_t x,uint64_t y,uint64_t got,uint64_t expected) {
 assertions++; if(got!=expected) { failures++; fprintf(stderr,"FAIL %s x=%"PRIu64" y=%"PRIu64" got=%"PRIu64" expected=%"PRIu64"\n",name,x,y,got,expected); }
}
int main(void) {
 const uint64_t values[]={0,1,2,7,UINT64_MAX,UINT64_MAX-1,UINT32_MAX,UINT64_C(1)<<32,UINT64_C(1)<<48,UINT64_C(1)<<63,(UINT64_C(1)<<63)-1};
 uint64_t payload[24],total=0; for(unsigned i=0;i<24;i++) total+=(payload[i]=(UINT64_C(1)<<48)+i);
 for(unsigned i=0;i<sizeof(values)/sizeof(values[0]);i++) for(unsigned j=0;j<sizeof(values)/sizeof(values[0]);j++) {
  uint64_t x=values[i],y=values[j],out[2]; int got,expected;
  out[0]=out[1]=0; expected=((x+y)!=0); got=add64_ne(x,y,out);
  check("add64_ne",x,y,got,expected); check("add64_ne-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=((x+y)==0); got=add64_eq(x,y,out);
  check("add64_eq",x,y,got,expected); check("add64_eq-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=((x+y)!=0); got=add64_swap_ne(x,y,out);
  check("add64_swap_ne",x,y,got,expected); check("add64_swap_ne-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=((x-y)==0); got=sub64_eq(x,y,out);
  check("sub64_eq",x,y,got,expected); check("sub64_eq-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=((x-y)!=0); got=sub64_ne(x,y,out);
  check("sub64_ne",x,y,got,expected); check("sub64_ne-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=(((uint32_t)x+(uint32_t)y)!=0); got=add32_ne(x,y,out);
  check("add32_ne",x,y,got,expected); check("add32_ne-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=(((uint32_t)x-(uint32_t)y)==0); got=sub32_eq(x,y,out);
  check("sub32_eq",x,y,got,expected); check("sub32_eq-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=(((uint32_t)(x+y))==0); got=width_mismatch(x,y,out);
  check("width_mismatch",x,y,got,expected); check("width_mismatch-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=((x+y)==7); got=nonzero_comparand(x,y,out);
  check("nonzero_comparand",x,y,got,expected); check("nonzero_comparand-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=((x+y)!=0); got=boolean_multiuser(x,y,out);
  check("boolean_multiuser",x,y,got,expected); check("boolean_multiuser-branch",x,y,(uint32_t)out[0],expected?17:23);
  check("boolean_multiuser-other-user",x,y,(uint32_t)out[1],expected);
  out[0]=out[1]=0; expected=((x+y)!=0); got=intervening_call(x,y,out);
  check("intervening_call",x,y,got,expected); check("intervening_call-branch",x,y,(uint32_t)out[0],expected?17:23);
  out[0]=out[1]=0; expected=(x+y)!=0; got=intervening_arithmetic(x,y,out);
  check("intervening-arithmetic",x,y,got,expected); check("intervening-arithmetic-value",x,y,out[0],(x+y)&1); check("intervening-arithmetic-branch",x,y,(uint32_t)out[1],expected?17:23);
  out[0]=out[1]=0; expected=(x-y)==0; got=arithmetic_multiuser(x,y,out);
  check("arithmetic-multiuser",x,y,got,expected); check("arithmetic-multiuser-value",x,y,out[0],x-y); check("arithmetic-multiuser-branch",x,y,(uint32_t)out[1],expected?17:23);
  out[0]=out[1]=0; check("register-pressure",x,y,pressure(x,y,payload,out),total); check("register-pressure-branch",x,y,(uint32_t)out[0],(x+y)!=0?17:23);
 }
 uint64_t address_output[2]={0}; check("address-use",0,0,address_use(payload,address_output),1); check("address-value",0,0,address_output[0],payload[1]); check("address-branch",0,0,(uint32_t)address_output[1],17);
 printf("QBE zero-branch oracle: %u assertions passed, %u failed; 15 function fixtures, 121 arithmetic input pairs\n",assertions-failures,failures); return failures?1:0;
}
