.text
.balign 16
.globl add64_ne
add64_ne:
	endbr64
	movq %rdi, %rax
	addq %rsi, %rax
	jnz .Lbb2
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb3
.Lbb2:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb3:
	ret
.type add64_ne, @function
.size add64_ne, .-add64_ne
/* end function add64_ne */

.text
.balign 16
.globl add64_eq
add64_eq:
	endbr64
	movq %rdi, %rax
	addq %rsi, %rax
	jz .Lbb6
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb7
.Lbb6:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb7:
	ret
.type add64_eq, @function
.size add64_eq, .-add64_eq
/* end function add64_eq */

.text
.balign 16
.globl add64_swap_ne
add64_swap_ne:
	endbr64
	movq %rdi, %rax
	addq %rsi, %rax
	jnz .Lbb10
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb11
.Lbb10:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb11:
	ret
.type add64_swap_ne, @function
.size add64_swap_ne, .-add64_swap_ne
/* end function add64_swap_ne */

.text
.balign 16
.globl sub64_eq
sub64_eq:
	endbr64
	movq %rdi, %rax
	subq %rsi, %rax
	jz .Lbb14
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb15
.Lbb14:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb15:
	ret
.type sub64_eq, @function
.size sub64_eq, .-sub64_eq
/* end function sub64_eq */

.text
.balign 16
.globl sub64_ne
sub64_ne:
	endbr64
	movq %rdi, %rax
	subq %rsi, %rax
	jnz .Lbb18
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb19
.Lbb18:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb19:
	ret
.type sub64_ne, @function
.size sub64_ne, .-sub64_ne
/* end function sub64_ne */

.text
.balign 16
.globl add32_ne
add32_ne:
	endbr64
	movl %edi, %eax
	addl %esi, %eax
	jnz .Lbb22
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb23
.Lbb22:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb23:
	ret
.type add32_ne, @function
.size add32_ne, .-add32_ne
/* end function add32_ne */

.text
.balign 16
.globl sub32_eq
sub32_eq:
	endbr64
	movl %edi, %eax
	subl %esi, %eax
	jz .Lbb26
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb27
.Lbb26:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb27:
	ret
.type sub32_eq, @function
.size sub32_eq, .-sub32_eq
/* end function sub32_eq */

.text
.balign 16
.globl width_mismatch
width_mismatch:
	endbr64
	movq %rdi, %rax
	addq %rsi, %rax
	cmpl $0, %eax
	jz .Lbb30
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb31
.Lbb30:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb31:
	ret
.type width_mismatch, @function
.size width_mismatch, .-width_mismatch
/* end function width_mismatch */

.text
.balign 16
.globl nonzero_comparand
nonzero_comparand:
	endbr64
	movq %rdi, %rax
	addq %rsi, %rax
	cmpq $7, %rax
	jz .Lbb34
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb35
.Lbb34:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb35:
	ret
.type nonzero_comparand, @function
.size nonzero_comparand, .-nonzero_comparand
/* end function nonzero_comparand */

.text
.balign 16
.globl boolean_multiuser
boolean_multiuser:
	endbr64
	movq %rdi, %rax
	addq %rsi, %rax
	cmpq $0, %rax
	setnz %al
	movzbl %al, %eax
	movl %eax, 8(%rdx)
	cmpl $0, %eax
	jnz .Lbb38
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb39
.Lbb38:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb39:
	ret
.type boolean_multiuser, @function
.size boolean_multiuser, .-boolean_multiuser
/* end function boolean_multiuser */

.text
.balign 16
.globl intervening_call
intervening_call:
	endbr64
	pushq %rbp
	movq %rsp, %rbp
	pushq %rbx
	pushq %r12
	movq %rdx, %r12
	movq %rdi, %rbx
	addq %rsi, %rbx
	movq %rbx, %rdi
	callq review_flag_clobber
	movq %r12, %rdx
	cmpq $0, %rbx
	jnz .Lbb42
	movl $23, (%rdx)
	movl $0, %eax
	jmp .Lbb43
.Lbb42:
	movl $17, (%rdx)
	movl $1, %eax
.Lbb43:
	popq %r12
	popq %rbx
	leave
	ret
.type intervening_call, @function
.size intervening_call, .-intervening_call
/* end function intervening_call */

.text
.balign 16
.globl intervening_arithmetic
intervening_arithmetic:
	endbr64
	movq %rdi, %rax
	addq %rsi, %rax
	movq %rax, %rcx
	andq $1, %rcx
	movq %rcx, (%rdx)
	cmpq $0, %rax
	setnz %al
	movzbl %al, %eax
	cmpl $0, %eax
	jnz .Lbb46
	movl $23, 8(%rdx)
	movl $0, %eax
	jmp .Lbb47
.Lbb46:
	movl $17, 8(%rdx)
	movl $1, %eax
.Lbb47:
	ret
.type intervening_arithmetic, @function
.size intervening_arithmetic, .-intervening_arithmetic
/* end function intervening_arithmetic */

.text
.balign 16
.globl arithmetic_multiuser
arithmetic_multiuser:
	endbr64
	movq %rdi, %rax
	subq %rsi, %rax
	movq %rax, (%rdx)
	cmpq $0, %rax
	setz %al
	movzbl %al, %eax
	cmpl $0, %eax
	jnz .Lbb50
	movl $23, 8(%rdx)
	movl $0, %eax
	jmp .Lbb51
.Lbb50:
	movl $17, 8(%rdx)
	movl $1, %eax
.Lbb51:
	ret
.type arithmetic_multiuser, @function
.size arithmetic_multiuser, .-arithmetic_multiuser
/* end function arithmetic_multiuser */

.text
.balign 16
.globl address_use
address_use:
	endbr64
	movq %rdi, %rax
	addq $8, %rax
	movq 8(%rdi), %rcx
	movq %rcx, (%rsi)
	cmpq $0, %rax
	setnz %al
	movzbl %al, %eax
	cmpl $0, %eax
	jnz .Lbb54
	movl $23, 8(%rsi)
	movl $0, %eax
	jmp .Lbb55
.Lbb54:
	movl $17, 8(%rsi)
	movl $1, %eax
.Lbb55:
	ret
.type address_use, @function
.size address_use, .-address_use
/* end function address_use */

.text
.balign 16
.globl pressure
pressure:
	endbr64
	subq $192, %rsp
	pushq %rbx
	pushq %r12
	pushq %r13
	pushq %r14
	pushq %r15
	movq %rcx, %r12
	movq %rdx, %rax
	movq %rsi, %r13
	movq %rdi, %r14
	movq (%rax), %r11
	movq 8(%rax), %rbx
	movq 16(%rax), %r10
	movq 24(%rax), %r9
	movq 32(%rax), %r8
	movq 40(%rax), %rdi
	movq 48(%rax), %rsi
	movq 56(%rax), %rdx
	movq 64(%rax), %rcx
	movq 72(%rax), %r15
	movq %r15, 216(%rsp)
	movq 80(%rax), %r15
	movq %r15, 224(%rsp)
	movq 88(%rax), %r15
	movq %r15, 208(%rsp)
	movq 96(%rax), %r15
	movq %r15, 200(%rsp)
	movq 104(%rax), %r15
	movq %r15, 184(%rsp)
	movq 112(%rax), %r15
	movq %r15, 192(%rsp)
	movq 120(%rax), %r15
	movq %r15, 168(%rsp)
	movq 128(%rax), %r15
	movq %r15, 152(%rsp)
	movq 136(%rax), %r15
	movq %r15, 136(%rsp)
	movq 144(%rax), %r15
	movq %r15, 120(%rsp)
	movq 152(%rax), %r15
	movq %r15, 104(%rsp)
	movq 160(%rax), %r15
	movq %r15, 88(%rsp)
	movq 168(%rax), %r15
	movq %r15, 72(%rsp)
	movq 176(%rax), %r15
	movq %r15, 48(%rsp)
	movq 184(%rax), %rax
	movq %rax, 56(%rsp)
	movq 224(%rsp), %r15
	movq 216(%rsp), %rax
	addq %r14, %r13
	movq 208(%rsp), %r14
	movq 200(%rsp), %r13
	jnz .Lbb58
	movl $23, (%r12)
	jmp .Lbb59
.Lbb58:
	movl $17, (%r12)
.Lbb59:
	addq %rbx, %r11
	movq %r11, 176(%rsp)
	movq 192(%rsp), %rbx
	movq 184(%rsp), %r12
	addq 176(%rsp), %r10
	movq %r10, 160(%rsp)
	movq 168(%rsp), %r11
	addq 160(%rsp), %r9
	movq %r9, 144(%rsp)
	movq 152(%rsp), %r10
	addq 144(%rsp), %r8
	movq %r8, 128(%rsp)
	movq 136(%rsp), %r9
	addq 128(%rsp), %rdi
	movq %rdi, 112(%rsp)
	movq 120(%rsp), %r8
	addq 112(%rsp), %rsi
	movq %rsi, 96(%rsp)
	movq 104(%rsp), %rdi
	addq 96(%rsp), %rdx
	movq %rdx, 80(%rsp)
	movq 88(%rsp), %rsi
	addq 80(%rsp), %rcx
	movq %rcx, 64(%rsp)
	movq 72(%rsp), %rdx
	addq 64(%rsp), %rax
	movq %rax, 40(%rsp)
	movq 56(%rsp), %rax
	movq 48(%rsp), %rcx
	addq 40(%rsp), %r15
	addq %r15, %r14
	addq %r14, %r13
	addq %r13, %r12
	addq %r12, %rbx
	addq %rbx, %r11
	addq %r11, %r10
	addq %r10, %r9
	addq %r9, %r8
	addq %r8, %rdi
	addq %rdi, %rsi
	addq %rsi, %rdx
	addq %rdx, %rcx
	addq %rcx, %rax
	popq %r15
	popq %r14
	popq %r13
	popq %r12
	popq %rbx
	addq $192, %rsp
	ret
.type pressure, @function
.size pressure, .-pressure
/* end function pressure */

.section .note.GNU-stack,"",@progbits
