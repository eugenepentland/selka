from pathlib import Path
import subprocess,re,json,hashlib
root=Path.cwd();lane=root/'.tmp/zero-review';zig=Path('/home/epentland/zig-toolchains')/(root/'.zigversion').read_text().strip()/'zig'
text=(root/'build.zig').read_text().split('const qbe_sources = [_][]const u8{',1)[1].split('};',1)[0]
sources=[str(lane/'control-isel.c') if p=='amd64/isel.c' else str(root/'vendor/qbe'/p) for p in re.findall(r'"([^"]+)"',text)]
rows=[]
def run(name,argv,expected=0):
 p=subprocess.run(argv,cwd=root,capture_output=True,text=True,timeout=600)
 (lane/(name+'.stdout')).write_text(p.stdout);(lane/(name+'.stderr')).write_text(p.stderr)
 rows.append({'name':name,'argv':list(map(str,argv)),'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 print(name,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==expected,(name,p.stderr)
run('control-source-build',[str(zig),'cc','-std=c99','-O3','-fno-sanitize=undefined','-I',str(root/'vendor/qbe/amd64'),'-I',str(root/'vendor/qbe'),*sources,'-o',str(lane/'control-qbe')])
run('control-tail-select',[str(lane/'control-qbe'),'-o',str(lane/'trailing-address-control.s'),str(lane/'trailing-address-v4.ssa')])
run('control-tail-link',[str(zig),'cc','-O2','-fsanitize=undefined','-fno-sanitize-recover=all',str(lane/'trailing-address-v4.c'),str(lane/'trailing-address-control.s'),'-o',str(lane/'trailing-address-control')])
run('control-tail-execute',[str(lane/'trailing-address-control')])
# Exercise the frozen artifact installed by the owner too, to exclude an independent-build difference.
installed=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-zero-branch-20260930/.tmp/zero/bin/qbe')
run('installed-f4-tail-select',[str(installed),'-o',str(lane/'trailing-address-installed-f4.s'),str(lane/'trailing-address-v4.ssa')])
run('installed-f4-tail-link',[str(zig),'cc','-O2','-fsanitize=undefined','-fno-sanitize-recover=all',str(lane/'trailing-address-v4.c'),str(lane/'trailing-address-installed-f4.s'),'-o',str(lane/'trailing-address-installed-f4')])
run('installed-f4-tail-execute',[str(lane/'trailing-address-installed-f4')],1)
receipt={'candidate_source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'control_source':subprocess.check_output(['git','rev-parse','f4b6647d^'],text=True).strip(),'attribution':'Only vendor/qbe/amd64/isel.c differs in the QBE translation units; control uses git-show parent isel and identical other files/headers. Installed owner artifact reproduces failure too.',
 'commands':rows,'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [lane/'trailing-address-v4.ssa',lane/'trailing-address-v4.c',lane/'trailing-address-v4.s',lane/'trailing-address-control.s',lane/'trailing-address-installed-f4.s',lane/'control-qbe',installed]}}
(lane/'tail-regression-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
