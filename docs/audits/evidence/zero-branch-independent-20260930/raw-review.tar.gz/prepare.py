from pathlib import Path
import json

lane = Path(__file__).parent
ssa = []
cases = []

def simple(name, ops, cmp, extra='', multi=False):
    body = f'export function w ${name}(l %x, l %y, l %out) {{\n@start\n{ops}\n'
    if extra:
        body += extra + '\n'
    body += f' %cond =w {cmp}\n'
    if multi:
        body += ' %at =l add %out, 8\n storew %cond, %at\n'
    body += (' jnz %cond, @yes, @no\n@yes\n storew 17, %out\n ret 1\n'
             '@no\n storew 23, %out\n ret 0\n}\n')
    ssa.append(body)

specs = [
    ('add64_ne', 'add', 'l', 'cnel %sum, 0', 'x+y', False),
    ('add64_eq', 'add', 'l', 'ceql %sum, 0', 'x+y', True),
    ('add64_swap_ne', 'add', 'l', 'cnel 0, %sum', 'x+y', False),
    ('sub64_eq', 'sub', 'l', 'ceql %sum, 0', 'x-y', True),
    ('sub64_ne', 'sub', 'l', 'cnel %sum, 0', 'x-y', False),
    ('add32_ne', 'add', 'w', 'cnew %sum, 0', '(uint32_t)x+(uint32_t)y', False),
    ('sub32_eq', 'sub', 'w', 'ceqw 0, %sum', '(uint32_t)x-(uint32_t)y', True),
    ('width_mismatch', 'add', 'l', 'ceqw %sum, 0', '(uint32_t)(x+y)', True),
    ('nonzero_comparand', 'add', 'l', 'ceql %sum, 7', 'x+y', True),
]
for name, op, width, cmp, expr, eq in specs:
    simple(name, f' %sum ={width} {op} %x, %y', cmp)
    cases.append(dict(name=name, expression=expr, equals=7 if name=='nonzero_comparand' else 0,
                      is_equal=eq, multi=False))
simple('boolean_multiuser', ' %sum =l add %x, %y', 'cnel %sum, 0', multi=True)
cases.append(dict(name='boolean_multiuser', expression='x+y', equals=0, is_equal=False, multi=True))
simple('intervening_call', ' %sum =l add %x, %y', 'cnel %sum, 0',
       ' %unused =l call $review_flag_clobber(l %sum)')
cases.append(dict(name='intervening_call', expression='x+y', equals=0, is_equal=False, multi=False))

for name, arithmetic, condition, stored in [
    ('intervening_arithmetic', ' %sum =l add %x,%y\n %clobber =l and %sum,1',
     'cnel %sum,0', '%clobber'),
    ('arithmetic_multiuser', ' %sum =l sub %x,%y', 'ceql %sum,0', '%sum'),
]:
    ssa.append(f'''export function w ${name}(l %x,l %y,l %out) {{
@start
{arithmetic}
 storel {stored},%out
 %cond =w {condition}
 jnz %cond,@yes,@no
@yes
 %at1 =l add %out,8
 storew 17,%at1
 ret 1
@no
 %at2 =l add %out,8
 storew 23,%at2
 ret 0
}}
''')
ssa.append('''export function w $address_use(l %base,l %out) {
@start
 %at =l add %base,8
 %value =l loadl %at
 storel %value,%out
 %cond =w cnel %at,0
 jnz %cond,@yes,@no
@yes
 %out1 =l add %out,8
 storew 17,%out1
 ret 1
@no
 %out2 =l add %out,8
 storew 23,%out2
 ret 0
}
''')
p = ['export function l $pressure(l %x,l %y,l %values,l %out) {', '@start']
for i in range(24):
    p += [f' %a{i} =l add %values,{8*i}', f' %p{i} =l loadl %a{i}']
p += [' %sum =l add %x,%y', ' %cond =w cnel %sum,0', ' jnz %cond,@yes,@no',
      '@yes', ' storew 17,%out', ' jmp @join', '@no', ' storew 23,%out',
      ' jmp @join', '@join']
prior = '%p0'
for i in range(1,24):
    p += [f' %s{i} =l add {prior},%p{i}']
    prior = f'%s{i}'
p += [f' ret {prior}', '}']
ssa.append('\n'.join(p)+'\n')
(lane/'fixtures.ssa').write_text('\n'.join(ssa))

c = ['/* Independent QBE ZF fold oracle: unsigned arithmetic, no timings. */',
     '#include <stdint.h>', '#include <stdio.h>', '#include <inttypes.h>',
     '__attribute__((noinline)) uint64_t review_flag_clobber(uint64_t x) {',
     ' (void)x; uint64_t result; __asm__ volatile("xor %%eax,%%eax" : "=a"(result) : : "cc"); return result;',
     '}']
for case in cases:
    c.append(f"extern int {case['name']}(uint64_t,uint64_t,uint64_t *);")
for name in ['intervening_arithmetic', 'arithmetic_multiuser']:
    c.append(f'extern int {name}(uint64_t,uint64_t,uint64_t *);')
c += ['extern int address_use(uint64_t *,uint64_t *);',
      'extern uint64_t pressure(uint64_t,uint64_t,uint64_t *,uint64_t *);',
      'static unsigned assertions, failures;',
      'static void check(const char *name,uint64_t x,uint64_t y,uint64_t got,uint64_t expected) {',
      ' assertions++; if(got!=expected) { failures++; fprintf(stderr,"FAIL %s x=%"PRIu64" y=%"PRIu64" got=%"PRIu64" expected=%"PRIu64"\\n",name,x,y,got,expected); }',
      '}', 'int main(void) {',
      ' const uint64_t values[]={0,1,2,7,UINT64_MAX,UINT64_MAX-1,UINT32_MAX,UINT64_C(1)<<32,UINT64_C(1)<<48,UINT64_C(1)<<63,(UINT64_C(1)<<63)-1};',
      ' uint64_t payload[24],total=0; for(unsigned i=0;i<24;i++) total+=(payload[i]=(UINT64_C(1)<<48)+i);',
      ' for(unsigned i=0;i<sizeof(values)/sizeof(values[0]);i++) for(unsigned j=0;j<sizeof(values)/sizeof(values[0]);j++) {',
      '  uint64_t x=values[i],y=values[j],out[2]; int got,expected;']
for case in cases:
    name = case['name']
    op = '==' if case['is_equal'] else '!='
    c += [f"  out[0]=out[1]=0; expected=(({case['expression']}){op}{case['equals']}); got={name}(x,y,out);",
          f'  check("{name}",x,y,got,expected); check("{name}-branch",x,y,(uint32_t)out[0],expected?17:23);']
    if case['multi']:
        c.append(f'  check("{name}-other-user",x,y,(uint32_t)out[1],expected);')
c += ['  out[0]=out[1]=0; expected=(x+y)!=0; got=intervening_arithmetic(x,y,out);',
      '  check("intervening-arithmetic",x,y,got,expected); check("intervening-arithmetic-value",x,y,out[0],(x+y)&1); check("intervening-arithmetic-branch",x,y,(uint32_t)out[1],expected?17:23);',
      '  out[0]=out[1]=0; expected=(x-y)==0; got=arithmetic_multiuser(x,y,out);',
      '  check("arithmetic-multiuser",x,y,got,expected); check("arithmetic-multiuser-value",x,y,out[0],x-y); check("arithmetic-multiuser-branch",x,y,(uint32_t)out[1],expected?17:23);',
      '  out[0]=out[1]=0; check("register-pressure",x,y,pressure(x,y,payload,out),total); check("register-pressure-branch",x,y,(uint32_t)out[0],(x+y)!=0?17:23);',
      ' }', ' uint64_t address_output[2]={0}; check("address-use",0,0,address_use(payload,address_output),1); check("address-value",0,0,address_output[0],payload[1]); check("address-branch",0,0,(uint32_t)address_output[1],17);',
      ' printf("QBE zero-branch oracle: %u assertions passed, %u failed; 15 function fixtures, 121 arithmetic input pairs\\n",assertions-failures,failures); return failures?1:0;', '}']
(lane/'oracle.c').write_text('\n'.join(c)+'\n')
(lane/'design.json').write_text(json.dumps(dict(fixtures=15, arithmetic_pairs=121,
    positive=[x[0] for x in specs[:7]],
    negative_or_boundary=[x[0] for x in specs[7:]]+['boolean_multiuser','intervening_call',
        'intervening_arithmetic','arithmetic_multiuser','address_use','pressure'],
    oracle='Independent unsigned C arithmetic and branch side effects; pending frozen candidate.'), indent=2)+'\n')
print('Prepared15 fixtures,121 pairs, independent C oracle. No execution.')
