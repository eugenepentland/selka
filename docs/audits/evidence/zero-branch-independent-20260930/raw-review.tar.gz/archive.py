from pathlib import Path
import io,gzip,tarfile,json,hashlib,subprocess
root=Path.cwd();lane=root/'.tmp/zero-review';out=root/'docs/audits/evidence/zero-branch-independent-20260930';out.mkdir(parents=True,exist_ok=True)
paths={}
for p in sorted(lane.iterdir()):
 if p.is_file() and p.suffix in ('.py','.ssa','.c','.s','.json','.md','.log','.stdout','.stderr'):
  if p.name!='independent-review-manifest.json':paths[p.name]=p
for name in ('qbe','control-qbe','production','independent','trailing-address-v4','trailing-address-control','trailing-address-installed-f4'):
 paths['artifacts/'+name]=lane/name
paths['artifacts/owner-f4-qbe']=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-zero-branch-20260930/.tmp/zero/bin/qbe')
rows=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,p in sorted(paths.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.uid=info.gid=0;info.mode=0o755 if name.startswith('artifacts/') else 0o644
  tar.addfile(info,io.BytesIO(data));rows.append({'member':name,'original_path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
raw=gzip.compress(buf.getvalue(),mtime=0);(out/'raw-review.tar.gz').write_bytes(raw)
manifest={'candidate_source':subprocess.check_output(['git','rev-parse','f4b6647d'],text=True).strip(),'control_source':subprocess.check_output(['git','rev-parse','f4b6647d^'],text=True).strip(),'archive':'raw-review.tar.gz','archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'members':rows}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ('report.md','receipt.json','assembly-summary.json','tail-regression-receipt.json'):(out/name).write_bytes((lane/name).read_bytes())
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(raw)),mode='r:') as tar:
 for row in rows:
  data=tar.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(len(rows),'members',len(raw),'archive bytes',manifest['archive_sha256'])
