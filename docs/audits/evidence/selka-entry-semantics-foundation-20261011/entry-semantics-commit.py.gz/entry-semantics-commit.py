from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-output-native/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
report = json.loads((work / 'entry-semantics-preflight.json').read_text())
assert report['complete'] and report['failed'] == report['skipped'] == 0
assert all(row['status'] == 0 for row in report['records'])
for name, digest in report['source_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
assert '88 check(s) passed' in (work / 'entry-semantics-preflight-guardian.log').read_text()
files = ['selfhost/components/body_check/' + name for name in [
    'entry_types.my', 'entry_signature.my', 'entry_adapter.my', 'entry_fixtures.my',
    'entry_types_tests.my', 'entry_adapter_tests.my', 'entry_probe.my', 'entry_oracle.zig']]
files.append('selfhost/tests/run_entry_adapter_parity.py')
evidence = root / 'docs/audits/evidence/selka-entry-semantics-foundation-20261011'
evidence.mkdir(parents=True, exist_ok=False)
receipt = dict(format=1, source_base='dff9304b9cd7bc72e66f9feb20f1b05281d67333',
    scope='Selka entry algorithm source checks only; execution/parity and production selection pending',
    qualified_seed_sha256='c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b',
    checked_roots=['entry_types_tests', 'entry_adapter_tests', 'entry_signature', 'entry_probe'],
    guardian=88, required_pure_tests_per_mode=13, required_parity_cases_per_mode=30,
    source_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}, artifacts=[])
for path in sorted(work.glob('entry-semantics-*')):
    if path.suffix not in ('.json', '.log', '.py'):
        continue
    data = path.read_bytes()
    archived = gzip.compress(data, mtime=0)
    output = evidence / (path.name + '.gz')
    output.write_bytes(archived)
    assert gzip.decompress(output.read_bytes()) == data
    receipt['artifacts'].append(dict(name=output.name, sha256=hashlib.sha256(data).hexdigest(),
        archive_sha256=hashlib.sha256(archived).hexdigest(), bytes=len(data), archive_bytes=len(archived)))
(evidence / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
doc = root / 'docs/audits/selka-entry-semantics-foundation-2026-10-11.md'
doc.write_text('''# Selka entry semantics implementation foundation

The new Selka modules port the native entry signature rules and typed entry
adapter. This is an implementation foundation, not a claim of selected semantic
ownership. The installed schema-11 body route and native entry coordinator are
unchanged. Source checks pass; execution and native parity are still pending.

`entry_types` recognizes argv by managed list/string shape, accepts the native
capability kinds, separates out/err Streams, and preserves duplicate/name/type
messages. `entry_signature` selects a free main in the entry module, rejects
generic or nonguest entries, resolves parameters in source order and checks the
return contract. Missing-main remains a separate decision so the coordinator can
preserve prior generic-contract failure ordering. Its current type resolver is
the body checker; broader type coverage remains separately accountable.

`entry_adapter` leaves int entries untouched and appends the native Unit or
checked-result wrapper. It forwards parameters once, preserves their ownership
and origin metadata while resetting usage, retains the original callable
signature, and appends exact call/constant/match/return rows. Result tags come
from the supplied catalog. Int errors become exit statuses; other errors exit
one, and error output uses the error_report sink. Unit success exits zero. The
synthetic function has no source-body range, matching native cache ownership.

Thirteen pure controls cover those rules. A separate development probe and
native oracle require thirty complete typed-program comparisons per guest mode,
including zero/one/three parameters, nonzero entry IDs, unchanged helper bodies
and aliases, both result success types, int/bool error payloads and reversed
result tags. The native oracle canonicalizes the candidate and compares every
field, including local usage/ownership and signature defaults. A changed wrapper
name must fail in each mode. This harness does not register another production
component or change the existing wire schema.

The qualified c4f1ea0b seed accepts both test roots, the signature implementation
and the probe; formatting, whitespace checks and 88 Guardian checks also pass.
The earlier default-field, fallible assignment and local-shadowing source errors
are retained with their corrected preflight. Existing imported body modules
still emit their previously recorded unused-binding warnings.

Required next work is to run the thirteen pure tests and thirty native adapter
comparisons in both guest modes, add source-level signature/diagnostic parity,
then design and validate selected semantic publication with exact failure order.
Only after that can the native entry coordinator/adaptation be replaced on the
selected path. Other semantic passes, Core/LLVM/driver ownership, full bootstrap
and 1.5-times performance acceptance remain open.

[Source checks and identities](evidence/selka-entry-semantics-foundation-20261011/receipt.json)
retain successes and failures without treating source checking as execution proof.
''')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *files, str(evidence.relative_to(root)), str(doc.relative_to(root))], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Port entry signature rules and typed wrapper construction to Selka'], cwd=root, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
print(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), flush=True)
