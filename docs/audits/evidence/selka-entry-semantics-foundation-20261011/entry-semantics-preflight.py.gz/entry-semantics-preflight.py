from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-output-native/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
seed = Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
assert hashlib.sha256(seed.read_bytes()).hexdigest() == 'c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b'
sources = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted((root / 'selfhost/components/body_check').glob('*.my'))}
report = dict(complete=False, source_sha256=sources, records=[])
path = work / 'entry-semantics-preflight.json'
def save():
    path.write_text(json.dumps(report, indent=2) + '\n')
save()
for name in ['entry_types_tests', 'entry_adapter_tests', 'entry_signature', 'entry_probe']:
    command = [str(seed), 'check', 'selfhost/components/body_check/' + name + '.my', '--no-cache']
    log = work / ('entry-semantics-preflight-' + name + '.log')
    with log.open('wb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    report['records'].append(dict(name=name, command=command, status=result.returncode, log=str(log)))
    save()
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-6000:], flush=True)
        raise SystemExit(result.returncode)
for name, digest in sources.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
for name, command in [
    ('fmt', ['/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig', 'fmt', '--check', 'selfhost/components/body_check/entry_oracle.zig']),
    ('guardian', ['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check', 'all', '.', '--gate', '--full']),
    ('diff', ['git', 'diff', '--check']),
]:
    log = work / ('entry-semantics-preflight-' + name + '.log')
    with log.open('wb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    report['records'].append(dict(name=name, command=command, status=result.returncode, log=str(log)))
    save()
    print(name, result.returncode, flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-6000:], flush=True)
        raise SystemExit(result.returncode)
report.update(complete=True, failed=0, skipped=0)
save()
