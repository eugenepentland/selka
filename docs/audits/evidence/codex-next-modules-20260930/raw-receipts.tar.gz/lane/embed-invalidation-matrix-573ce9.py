import sys,json,hashlib,shutil,argparse
from pathlib import Path
sys.path.insert(0,str(Path('tests').resolve()))
from module_build_diff import Differential,report_of
root=Path('.tmp/b2/embed-matrix-573ce9').resolve();root.mkdir(exist_ok=False)
a=argparse.Namespace(mylang='.tmp/b2/key-noop-debug-final/bin/mylang',arg_sets=None,run_timeout=20,runtime='rc')
d=Differential(a,root);d.tree.mkdir()
(d.tree/'main.my').write_text('module main\nimport data\n\ndef main(out: Stream) -> int:\n    out.print(data.payload())\n    return 0\n')
(d.tree/'data.my').write_text('module data\n\npublic const PAYLOAD: bytes = embed_bytes("asset.bin")\n\npublic def payload() -> bytes:\n    return PAYLOAD\n')
asset=d.tree/'asset.bin';asset.write_bytes(b'A\x00bytes!')
config=d.tree/'mylang.json'
def budget(extra=8,individual=65536):
 total=sum(p.stat().st_size for p in d.tree.glob('*.my'))+extra
 config.write_text(json.dumps({'version':1,'budgets':{'max_file_bytes':individual,'max_total_bytes':total}}))
 return total
rows=[]
def step(label,accepted=True,warm=False):
 before=d.stats.copy();d.step(label);assert d.stats['mismatches']==0,d.rows[-1]
 assert d.stats['built']==before['built']+int(accepted) and d.stats['rejected']==before['rejected']+int(not accepted),d.rows[-1]
 row=d.rows[-1];row['asset_status']='missing' if not asset.exists() else hashlib.sha256(asset.read_bytes()).hexdigest();row['policy']=json.loads(config.read_text());row['runtime_flags']=d.runtime[:]
 if warm:assert row['module_build']['compiled']==0,row
 rows.append(row)

budget();step('exact source plus eight embed bytes');step('warm initial',warm=True)
asset.write_bytes(b'B\x00bytes!');step('embed-only content edit');assert rows[-1]['module_build']['compiled']==2,rows[-1]
step('warm edited embed',warm=True)
asset.write_bytes(b'');step('empty embed');asset.unlink();step('missing embed',False)
asset.write_bytes(b'A\x00bytes!');step('restore asset after missing refusal')
budget(7);step('tightened total refuses cached accepted payload',False)
budget();step('widen total recovers');step('warm recovered total',warm=True)
source=(d.tree/'data.my').read_text();(d.tree/'data.my').write_text(source+'\npublic const ALSO: bytes = embed_bytes("asset.bin")\n')
budget();step('same module literal deduplicates at exact cap')
other='module other\npublic const SAME: bytes = embed_bytes("asset.bin")\n'
(d.tree/'other.my').write_text(other)
main=(d.tree/'main.my').read_text().replace('import data','import data\nimport other').replace('    return 0','    out.print(other.SAME)\n    return 0')
(d.tree/'main.my').write_text(main)
budget(8);step('two semantic module identities cannot share one charge',False)
budget(16);step('two semantic identities accepted at source plus sixteen')
asset.write_bytes(b'X'*2049);budget(4098,individual=2048);step('embed individual cap refuses before allocation',False)
asset.write_bytes(b'A\x00bytes!');budget(16);step('restore after individual cap refusal')
for mode,flags in [('gc',['--gc-runtime']),('stats',['--rc-runtime=stats']),('sites',['--rc-runtime=sites']),('legacy-sharing',['--legacy-sharing']),('rc',['--rc-runtime'])]:
 d.runtime=flags;step('partition '+mode);step('warm partition '+mode,warm=True)
variants=[p for p in (root/'cache/modules').iterdir() if p.is_dir() and not p.name.startswith('standard-')]
assert len(variants)>=5,len(variants)
result={'source':'573ce9a4d14f1a515f0454961b70311c280bafdc','compiler_sha256':hashlib.sha256(Path(d.mylang).read_bytes()).hexdigest(),'totals':d.stats,'project_variants':len(variants),'rows':rows}
(root.parent/'embed-invalidation-matrix-573ce9.json').write_text(json.dumps(result,indent=1));print(json.dumps(d.stats))
