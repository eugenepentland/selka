import json,subprocess
from pathlib import Path
w=Path('.tmp/b2/cutoff-repro').resolve();w.mkdir(exist_ok=True)
s='module shapes\npublic record Pair:\n    left: int\n    right: int\npublic def total(pair: Pair) -> int:\n    return pair.left + pair.right\n'
u='module util\nimport shapes\npublic def score(n: int) -> int:\n    total = 0\n    for k in range(n):\n        total += shapes.total(shapes.Pair(left=k, right=2))\n    return total\n'
(w/'shapes.my').write_text(s);(w/'util.my').write_text(u);(w/'main.my').write_text('module main\nimport util\ndef main() -> int:\n    return util.score(4)\n')
m=str(Path('zig-out/focus/mylang').resolve());rows=[]
for stage in ['cold','warm','body','interface']:
 if stage=='body':(w/'util.my').write_text(u.replace('right=2','right=3'))
 if stage=='interface':(w/'shapes.my').write_text(s+'public def unused() -> int:\n    return 1\n')
 p=subprocess.run([m,'build',str(w/'main.my'),'--project','--report','-o',str(w/'prog'),'--cache-dir='+str(w/'cache')],capture_output=True)
 print(stage,p.returncode,p.stdout.decode(),p.stderr.decode());assert p.returncode==0
 rows.append({'stage':stage,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
Path('.tmp/b2/cutoff-repro.json').write_text(json.dumps(rows,indent=1))
