import json,subprocess
from pathlib import Path
rows=json.load(open('.tmp/b2/lang-negative-classification.json'))['rows']
compiler=str(Path('.tmp/b2/frozen-62c95-rf/bin/mylang').resolve())
entries=[row['entry'] for row in rows]
args=['python3','tests/module_compile_oracle.py',compiler,*entries,'--jobs','1','--runtime','rc','--no-run','--json','.tmp/b2/lang-helper-byte-62c95-all.json','--work','.tmp/b2/lang-helper-byte-62c95-all']
raise SystemExit(subprocess.call(args))
