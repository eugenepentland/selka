import sys,json,hashlib,shutil,argparse
from pathlib import Path
sys.path.insert(0,str(Path('tests').resolve()))
from module_build_diff import Differential
root=Path('.tmp/b2/rc-matrix-573ce9').resolve()
root.mkdir(exist_ok=False)
a=argparse.Namespace(mylang='.tmp/b2/key-noop-debug-final/bin/mylang',arg_sets=None,run_timeout=20,runtime='rc')
d=Differential(a,root)
shutil.copytree('tests/fixtures/module_rc',d.tree)
pristine={p.name:p.read_text().replace(' effects():',':') for p in d.tree.glob('*.my')}
for path,text in pristine.items():(d.tree/path).write_text(text)

def hashes():
 out={}
 for p in (root/'cache/modules').glob('*/state.json'):
  if p.parent.name.startswith('standard-'):continue
  state=json.load(p.open())
  for r in state['modules']:out[r['name']]=r['hashes']
 return out

def step(label):
 before=hashes(); n=d.stats['built'];d.step(label)
 assert d.stats['mismatches']==0 and d.stats['built']==n+1,d.rows[-1]
 after=hashes();d.rows[-1]['changed_hashes']={name:{k:{'before':before.get(name,{}).get(k),'after':v} for k,v in row.items() if before.get(name,{}).get(k)!=v} for name,row in after.items() if before.get(name)!=row}
 return d.rows[-1]

step('pristine')
assert step('warm pristine')['module_build']['compiled']==0
cases=[
 ('private transitive loop proof','leaf.my',pristine['leaf.my'].replace('index < len(values):','index < len(values) - 1:')),
 ('callee starts allocating and sharing','leaf.my',pristine['leaf.my'].replace('    total = 0\n    index = 0\n    while index < len(values):\n        total = total + values[index]\n        index = index + 1\n    return total','    copy = values\n    copy.append(99)\n    return len(copy)')),
 ('borrowed return becomes owned','lib.my',pristine['lib.my'].replace('return value','return value + "x"')),
 ('immortal return becomes allocated','lib.my',pristine['lib.my'].replace('return b"fixed"','return bytes([9, 8])')),
 ('mutable parameter loses original slot','lib.my',pristine['lib.my'].replace('    for k in range(len(values)):', '    values = [7, 8]\n    for k in range(len(values)):')),
]
for label,name,new in cases:
 for path,text in pristine.items():(d.tree/path).write_text(text)
 step('restore before '+label)
 assert new!=pristine[name]
 (d.tree/name).write_text(new)
 row=step(label)
 owner=Path(name).stem
 assert row['module_build']['compiled']>=2,row
 assert 'emission' in row['changed_hashes'].get(owner,{}),row
 assert step('warm '+label)['module_build']['compiled']==0
out={'source':'573ce9a4e97d4deb3e874dcaa35beb0eaacbfbb0','compiler_sha256':hashlib.sha256(Path(d.mylang).read_bytes()).hexdigest(),'totals':d.stats,'fixture':'module_rc with managed_allocation permitted bounds, so body-only allocation mutations remain accepted','source_sha256':{name:hashlib.sha256(text.encode()).hexdigest() for name,text in pristine.items()},'rows':d.rows}
(root.parent/'rc-invalidation-matrix-573ce9.json').write_text(json.dumps(out,indent=1))
print(json.dumps(d.stats))
