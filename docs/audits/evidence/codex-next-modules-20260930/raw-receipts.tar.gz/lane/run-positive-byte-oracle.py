import json,subprocess
from pathlib import Path
rows=json.load(open('.tmp/b2/lang-positive-entries.json'))['entries']
compiler=str(Path('.tmp/b2/frozen-62c95-rf/bin/mylang').resolve())
for start in range(0,len(rows),20):
 entries=[row['entry'] for row in rows[start:start+20]]
 result=Path(f'.tmp/b2/lang-byte-62c95-{start:03d}.json')
 args=['python3','tests/module_compile_oracle.py',compiler,*entries,'--jobs','1','--runtime','rc','--no-run','--json',str(result),'--work',f'.tmp/b2/lang-byte-62c95-{start:03d}']
 code=subprocess.call(args)
 print('completed batch',start,'status',code,flush=True)
 if code:raise SystemExit(code)
all_rows=[]
for start in range(0,len(rows),20):all_rows+=json.load(open(f'.tmp/b2/lang-byte-62c95-{start:03d}.json'))['results']
keys=['programs','equal','reference_failed','modules','units_compared','units_whole','specializations_shared','interfaces_compared','executables_identical']
totals={k:0 for k in keys}
for start in range(0,len(rows),20):
 p=json.load(open(f'.tmp/b2/lang-byte-62c95-{start:03d}.json'))
 for k in keys:totals[k]+=p['totals'][k]
assert totals['programs']==len(rows) and totals['equal']==len(rows) and totals['executables_identical']==len(rows) and totals['reference_failed']==0
Path('.tmp/b2/lang-byte-62c95-all.json').write_text(json.dumps({'source':'62c95a7d','totals':totals,'results':all_rows},indent=1))
print(json.dumps(totals),flush=True)
