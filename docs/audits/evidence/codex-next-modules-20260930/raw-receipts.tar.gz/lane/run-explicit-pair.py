import subprocess
from pathlib import Path
root=Path.cwd()
for mode in ('rc','gc','stats','sites'):
 args=['python3','tests/module_compile_oracle.py','zig-out/bin/mylang','tests/fixtures/module_compile/main.my','tests/fixtures/module_rc/main.my','--jobs','1','--runtime',mode,'--json',f'.tmp/b2/explicit-{mode}-final.json','--work',f'.tmp/b2/explicit-{mode}-final','--keep']
 with (root/f'.tmp/b2/explicit-{mode}-final.log').open('w') as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 print(mode, result.returncode, flush=True)
 if result.returncode: raise SystemExit(result.returncode)
