#!/usr/bin/env python3
import argparse, fcntl, hashlib, json, os, shutil, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('compiler');p.add_argument('work',type=Path);p.add_argument('--json',required=True,type=Path);args=p.parse_args()
compiler=str(Path(args.compiler).resolve());root=args.work.resolve();assert not root.exists();root.mkdir(parents=True)
tree=root/'src';tree.mkdir();cache=root/'cache';rows=[]
main='module main\nimport good\nimport bad\n\ndef main() -> int:\n    return good.read() + bad.read()\n'
good='module good\nimport math\nconst DATA: bytes = embed_bytes("payload.bin")\n\npublic def read() -> int:\n    return len(DATA)\n'
bad='module bad\n\npublic def read() -> int:\n    return 2\n'
for name,text in [('main.my',main),('good.my',good),('bad.my',bad)]: (tree/name).write_text(text)
(tree/'payload.bin').write_bytes(b'abc')
def states():
 return {str(x.relative_to(cache)):(hashlib.sha256(x.read_bytes()).hexdigest(),x.stat().st_mtime_ns,x.stat().st_ino) for x in cache.glob('modules/*/state.json')}
def results():
 return {str(x.relative_to(cache)):x.stat().st_mtime_ns for x in cache.glob('modules/*/out/*.result.json')}
def step(name,entry='main.my',reject=False,unchanged=False):
 before,rb=states(),results()
 common=[compiler,'check',str(tree/entry)]
 expected=subprocess.run(common+['--no-cache'],cwd=tree,capture_output=True,timeout=120)
 actual=subprocess.run(common+[f'--cache-dir={cache}'],cwd=tree,capture_output=True,timeout=120)
 after,ra=states(),results()
 row={'step':name,'entry':entry,'reference_status':expected.returncode,'module_status':actual.returncode,'rejection_expected':reject,'states_unchanged':before==after,'compiled_results':[x for x in ra if rb.get(x)!=ra[x]],'stdout_sha256':hashlib.sha256(actual.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(actual.stderr).hexdigest()};rows.append(row);args.json.write_text(json.dumps({'compiler_sha256':hashlib.sha256(Path(compiler).read_bytes()).hexdigest(),'results':rows},indent=1))
 assert (actual.returncode,actual.stdout,actual.stderr)==(expected.returncode,expected.stdout,expected.stderr),(name,actual.stderr,expected.stderr)
 assert (actual.returncode!=0)==reject,(name,actual.returncode)
 if unchanged: assert before==after and rb==ra,(name,'rewrote state/result')
 print(name,row['compiled_results'],flush=True)
 return row
step('cold');step('warm',unchanged=True)
os.utime(tree/'main.my',None);step('same bytes changed mtime',unchanged=True)
(tree/'payload.bin').write_bytes(b'abcd');step('changed embed');step('embed warm',unchanged=True)
(tree/'good.my').write_text(good.replace('len(DATA)','len(DATA) + 1'))
(tree/'bad.my').write_text(bad.replace('return 2','return True'))
step('partial failure preserves finished neighbor',reject=True)
good_before={x:v for x,v in results().items() if x.endswith('/good.result.json')}
assert good_before
(tree/'bad.my').write_text(bad.replace('return 2','return 3'));step('repair failed module')
assert good_before=={x:v for x,v in results().items() if x.endswith('/good.result.json')}
step('repair warm',unchanged=True)
(tree/'main.my').write_text('module main\nimport bad\n\ndef main() -> int:\n    return bad.read()\n')
step('remove unreachable import')
own=[json.loads(x.read_text()) for x in cache.glob('modules/*/state.json') if not x.parent.name.startswith('standard-')]
assert len(own)==1 and {m['name'] for m in own[0]['modules']}=={'main','bad'}
step('removed graph warm',unchanged=True)
(tree/'other.my').write_text(main.replace('module main','module other',1))
step('renamed root separate variant','other.my');step('other root warm','other.my',unchanged=True)
(tree/'mylang.json').write_text('{"version":1,"budgets":{"max_total_bytes":1}}')
step('tightened loader budget',reject=True)
(tree/'mylang.json').write_text('{"version":1,"budgets":{"max_total_bytes":1048576}}')
step('widened loader budget',unchanged=True)
project=next(x.parent for x in cache.glob('modules/*/state.json') if not x.parent.name.startswith('standard-') and any(m['name']=='main' for m in json.loads(x.read_text())['modules']))
with open(project/'.lock','rb') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);step('concurrent held project falls back safely',unchanged=True);fcntl.flock(lock,fcntl.LOCK_UN)
step('lock release warm',unchanged=True)
assert len(rows)==16
