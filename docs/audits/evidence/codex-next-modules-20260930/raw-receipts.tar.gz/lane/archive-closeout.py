from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile
root=Path.cwd(); output=root/'docs/audits/evidence/codex-next-modules-20260930';output.mkdir(parents=True,exist_ok=True)
hash_of=lambda data:hashlib.sha256(data).hexdigest()
files={}
def add(path,name):
 p=Path(path);assert p.is_file(),p
 assert name not in files,name
 files[name]=(p,p.read_bytes())
for p in sorted((root/'.tmp/b2').iterdir()):
 if p.is_file() and p.suffix in ('.log','.json','.txt','.py'):add(p,'lane/'+p.name)
for dirname in ('review-repro','a3-frozen-receipts'):
 for p in sorted((root/'.tmp/b2'/dirname).glob('*')):
  if p.is_file():add(p,'lane/'+dirname+'/'+p.name)
for dirname in ('fixes-978-final','fixes-a3-effects-final'):
 origin=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-review-20260930/.tmp/review')/dirname
 for p in sorted(origin.iterdir()):
  if p.is_file():add(p,'independent/'+dirname+'/'+p.name)
origin=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-abi5-review-20260930/.tmp/module-state-review')
for p in sorted(origin.iterdir()):
 if p.is_file():add(p,'independent/module-state-review/'+p.name)
add('/home/epentland/ai/canopy/mylang-worktrees/claude-rc-perf/.tmp-rc-quick/results-m14-dev.json','control/results-m14-dev.json')
for p in [root/'experiments/rc-fuzz/out/summary.json',root/'experiments/rc-fuzz/out/found/s19.my',root/'experiments/rc-fuzz/out/found/s87.my']:
 add(p,'fuzz-62c95/'+p.name)
for dirname,path in [('scale-200k',root/'.tmp/b2/scale-200k/mylang'),('lox-a3',root/'.tmp/b2/lox-a3fb19'),('lox-corpus',root/'.tmp/b2/quick/lox/benchmarks/lox/ports/mylang')]:
 for p in sorted(path.iterdir()):
  if p.is_file() and p.suffix in ('.my','.json'):add(p,'inputs/'+dirname+'/'+p.name)
for p in sorted((root/'tests/fixtures/module_rc').glob('*.my')):add(p,'inputs/module_rc/'+p.name)
for name in ('module_compile_oracle.py','module_build_diff.py','module_check_oracle.py'):
 add(root/'tests'/name,'harnesses/'+name)
for name in ('measure.py','check_pair.py','corpus_byte.py','corpus_programs.json'):
 add(root/'experiments/module-scale-20260929'/name,'harnesses/'+name)
manifest=[]
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as archive:
 for name,(p,data) in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.uid=info.gid=0;info.mode=0o644
  archive.addfile(info,io.BytesIO(data))
  manifest.append({'member':name,'original_path':str(p),'bytes':len(data),'sha256':hash_of(data)})
compressed=gzip.compress(buf.getvalue(),mtime=0)
(output/'raw-receipts.tar.gz').write_bytes(compressed)
(output/'raw-manifest.json').write_text(json.dumps({'archive':'raw-receipts.tar.gz','archive_sha256':hash_of(compressed),'archive_bytes':len(compressed),'members':manifest},indent=2)+'\n')
# Keep the raw mislabeled receipt untouched inside the archive. Correct only its display copy.
for name in ('corpus-byte-key-noop.json','rc-invalidation-matrix-573ce9.json','embed-invalidation-matrix-573ce9.json','check-state-matrix-fixed.json','scale-interleaved-final.json','scale-interleaved-a3fb19.json','lox-a3fb19-verified.json'):
 data=json.loads((root/'.tmp/b2'/name).read_text())
 if name=='embed-invalidation-matrix-573ce9.json':
  data['source_original']=data['source'];data['source']='573ce9a4e97d4deb3e874dcaa35beb0eaacbfbb0'
  data['source_binding']='Original source label accidentally retained the suffix of an earlier hash when its short prefix was replaced. Actual compiler SHA matches frozen 573 corpus/RC/state receipts. Raw original is preserved in raw-receipts.tar.gz.'
 (output/name).write_text(json.dumps(data,indent=2)+'\n')
source_final=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
source_same=subprocess.run(['git','diff','--exit-code','573ce9a4','HEAD','--','src','tests','SPEC.md'],capture_output=True,text=True)
assert source_same.returncode==0
identity={'implementation_tip':source_final,'final_compiler_source':'573ce9a4e97d4deb3e874dcaa35beb0eaacbfbb0','source_equality_proof':'git diff --exit-code 573ce9a4 d105943e -- src tests SPEC.md: exit 0; final changes only ReleaseFast reservation in build.zig',
 'runtime_abi':3,'final_debug':{'path':'.tmp/b2/key-noop-debug-final/bin/mylang','sha256':hash_of((root/'.tmp/b2/key-noop-debug-final/bin/mylang').read_bytes())},
 'final_releasefast':{'path':'.tmp/b2/frozen-final-rf/bin/mylang','sha256':hash_of((root/'.tmp/b2/frozen-final-rf/bin/mylang').read_bytes())},
 'approved_main_control':{'source':'80dd51906c97ae76bf208474ac48c9baac3a11cd','sha256':hash_of((root/'.tmp/b2/control-80dd-rf/bin/mylang').read_bytes())},
 'acceptance_boundaries':{'full_lane_gate':'a3fb19fcf8bbe59ee72266a7fce96093b52d8b84; all four required commands exit 0; QBE cached steps retained and labeled',
 'final_focused_and_corpus':'573ce9a4 compiler source, d105943e scheduler reservation; 29 programs / 664 units, RC17, embed25, state16, native246, check5',
 'fuzz_and_guest_perf':'62c95a7d, historical lane checkpoint; supplementary root final combined ABI5 gate/fuzz/performance still required',
 'independent_review':'8/8 malformed authority cases, 14/14 explicit effect follow-up at a3; frozen 573 state guard read-only inspection, not independently executed'},
 'corrections':[{'receipt':'embed-invalidation-matrix-573ce9.json','original_source_label':'573ce9a4d14f1a515f0454961b70311c280bafdc','corrected_source':'573ce9a4e97d4deb3e874dcaa35beb0eaacbfbb0','reason':'short-prefix label substitution; compiler SHA is actual verified source binding'},
 {'field':'totals.steps in RC/embed Differential receipts','interpretation':'Inherited counter remains zero. Actual stages are rows lengths: 17 and 25, with actual built/run counts 17 and 21.'}]}
(output/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
# Verify every archive member round-trips and matches its manifest before committing it.
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(compressed)),mode='r:') as archive:
 for row in manifest:
  payload=archive.extractfile(row['member']).read();assert len(payload)==row['bytes'] and hash_of(payload)==row['sha256']
print(json.dumps({'members':len(manifest),'archive_bytes':len(compressed),'sha256':hash_of(compressed),'identity':identity},indent=2))
