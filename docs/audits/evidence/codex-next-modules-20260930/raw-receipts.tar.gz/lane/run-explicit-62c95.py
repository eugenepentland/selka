import subprocess,json
from pathlib import Path
compiler=str(Path('.tmp/b2/frozen-62c95-rf/bin/mylang').resolve())
for mode in ('rc','gc','stats','sites'):
 args=['python3','tests/module_compile_oracle.py',compiler,'tests/fixtures/module_compile/main.my','tests/fixtures/module_rc/main.my','--jobs','1','--runtime',mode,'--json',f'.tmp/b2/explicit-{mode}-62c95.json','--work',f'.tmp/b2/explicit-{mode}-62c95']
 result=subprocess.call(args)
 print('explicit runtime',mode,'status',result,flush=True)
 if result:raise SystemExit(result)
