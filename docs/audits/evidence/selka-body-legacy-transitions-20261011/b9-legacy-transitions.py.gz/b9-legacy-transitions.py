from pathlib import Path
import hashlib
import json
import shutil
import sys
import tempfile

ROOT = Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
sys.path.insert(0, str(ROOT / 'selfhost/tests'))
import run_body_check_qualification as D

WORK = Path(__file__).resolve().parent
COMPILER = Path('/home/epentland/ai/canopy/.selka-agent-cache/numeric-b9/install-host-combined/focus/mylang')
COMPONENTS = Path('/home/epentland/ai/canopy/.selka-agent-cache/numeric-b9/components-merged-fixed')
ZIG = Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
NAMES = ('profile_division', 'profile_integer_suffix', 'optional_narrowing_profile', 'optional_methods_profile')
REPORT = WORK / 'b9-legacy-transitions.json'

def identity():
    return {'compiler_sha256': D.F.digest(COMPILER), 'packages': D.packages(COMPONENTS, body_schema=9)}

before = identity()
assert before['compiler_sha256'] == '02870ae6efcc13d8e7f5fcaaee712916ee9cc994688e3ffb860f52289f97fa18'
assert before['packages']['body-check']['key'] == '33207532888e2e6235d75ee82604196610385694f89e20313697c730ee37abc1'
report = {'complete': False, 'scope': 'Four historical profile transitions; no full gate or bootstrap claim', 'body_schema': 9, **before, 'records': []}

def save():
    REPORT.write_text(json.dumps(report, indent=2) + '\n')

save()
with tempfile.TemporaryDirectory(prefix='b9-legacy-', dir=WORK) as temporary:
    work = Path(temporary)
    empty = work / 'empty-path'
    empty.mkdir()
    for name in NAMES:
        source = ROOT / 'selfhost/tests/fixtures/body_check' / (name + '.input')
        entry = work / (name + '.my')
        shutil.copyfile(source, entry)
        phases = (
            ('check', ['check-project', entry, '--no-cache', '--diagnostics=json']),
            ('typed', ['dump-typed', entry]),
            ('runtime', ['run-project', entry, '--no-cache', '--release', '--verify-facts', '--print-result', '--cache-dir', work / 'cache', f'--zig={ZIG}']),
        )
        for phase, args in phases:
            reference = None
            for mode in ('reference', 'shadow', 'component'):
                command = [COMPILER, *args]
                result = D.F.execute(command, D.environment(mode, COMPONENTS, empty), work, 600)
                report['records'].append({'name': name, 'phase': phase, 'mode': mode, 'source_sha256': D.F.digest(source), 'command': list(map(str, command)), 'status': result[0], 'stdout_hex': result[1].hex(), 'stderr_hex': result[2].hex()})
                save()
                expected_status = 7 if phase == 'runtime' else 0
                assert result[0] == expected_status and result[2] == b'', (name, phase, mode, result)
                if phase == 'runtime':
                    assert result[1] == b'7\n'
                elif phase == 'check':
                    assert result[1] == b''
                else:
                    assert result[1]
                if reference is None:
                    reference = result
                else:
                    assert result == reference, (name, phase, mode)
assert identity() == before
assert len(report['records']) == 36
report.update(complete=True, operations=36, failed=0, skipped=0)
save()
print('Four legacy transitions: 36 exact source/typed/runtime operations passed; 0 failed, 0 skipped')
