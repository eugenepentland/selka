//! Temporary native oracle diagnostic; never installed or used as a producer.
const std = @import("std");
const value = @import("body_check_value.zig");
const wire = @import("body_check_wire_io.zig");
const protocol = @import("body_check_protocol.zig");
const graph = @import("project.zig");
const prefix = "/home/epentland/ai/canopy/.selka-agent-cache/constant-closure/dynamic-capture/";
var captured_input: value.Input = undefined;
var identity: [40]u8 = undefined;
var native_path: []const u8 = undefined;

pub fn verifyBodyInput(a: std.mem.Allocator, actual: value.Input) @import("body_check_component.zig").Error!void {
    const left = try wire.encode(a, value.Input, actual, "SLKBKI01");
    const right = try wire.encode(a, value.Input, captured_input, "SLKBKI01");
    if (!std.mem.eql(u8, left, right)) {
        std.testing.expectEqualDeep(captured_input, actual) catch {};
        return error.ComponentShadowMismatch;
    }
    std.debug.print("native Input exactly matches authentic captured Input\n", .{});
}

pub fn captureBody(step: anytype, functions: []@import("typed.zig").Function, names: ?*@import("module_names.zig").Names) @import("body_check_component.zig").Error!void {
    const expected: value.Outcome = .{ .success = .{
        .batch = .{ .nodes = step.checker.nodes.items, .statements = step.checker.statements.items, .functions = functions, .ranges = step.checker.spec_ranges.items },
        .import_used = try @import("body_check_projection.zig").importUsage(step.allocator, names),
        .diagnostics = &.{},
        .recipes = try @import("body_check_materialize.zig").added(step.allocator, step.checker.catalog, captured_input.catalog.base_count),
    } };
    const bytes = try protocol.response(step.allocator, expected, identity);
    std.Io.Dir.cwd().writeFile(std.testing.io, .{ .sub_path = native_path, .data = bytes }) catch return error.ComponentIo;
    std.debug.print("native body outcome saved: {s}\n", .{native_path});
}

fn readInput(context: ?*anyopaque, a: std.mem.Allocator, path: []const u8, limit: usize) graph.ReadError![]u8 {
    _ = context;
    for (captured_input.modules) |module| {
        if (!std.mem.eql(u8, path, module.context.path)) continue;
        if (module.context.source.len > limit) return error.TooLarge;
        return a.dupe(u8, module.context.source);
    }
    return error.NotFound;
}

fn replay(comptime stem: []const u8) !void {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const request = try std.Io.Dir.cwd().readFileAlloc(std.testing.io, stem ++ ".request.bin", a, .limited(67108864));
    var input = try wire.decode(a, value.Input, request[64..], "SLKBKI01");
    defer input.arena.deinit();
    captured_input = input.value;
    identity = request[24..64].*;
    native_path = stem ++ ".native.bin";
    var project = graph.Project.init(a);
    defer project.deinit();
    try project.load(.{ .context = null, .read = readInput }, input.value.modules[0].context.name, .{});
    var index = try @import("interfaces.zig").build(&project);
    var compilation = try @import("project_compile.zig").Compilation.init(&index);
    if (input.value.context.entry_required) try compilation.check() else try compilation.checkLibrary();
    const native = try std.Io.Dir.cwd().readFileAlloc(std.testing.io, native_path, a, .limited(67108864));
    var expected = try protocol.reply(a, native, identity, input.value);
    defer expected.deinit();
    const reply = try std.Io.Dir.cwd().readFileAlloc(std.testing.io, stem ++ ".reply.bin", a, .limited(67108864));
    var actual = try protocol.reply(a, reply, identity, input.value);
    defer actual.deinit();
    try std.testing.expectEqualDeep(expected.outcome, actual.outcome);
}

test "scratch native range dynamic" { try replay(prefix ++ "range_dynamic.my"); }
test "scratch native range descending" { try replay(prefix ++ "range_dynamic_descending.my"); }
test "scratch native range unsigned" { try replay(prefix ++ "range_unsigned_dynamic.my"); }
test "scratch native table copy" { try replay("/home/epentland/.codex/worktrees/selka-parser-pilot/mylang/.body-check-tmp/array-write-authentic/table_copy.check-project.component"); }
