const std = @import("std");
const value = @import("body_check_value.zig");
const wire = @import("body_check_wire_io.zig");
const validate = @import("body_check_validate.zig");

test "scratch captured buffer body reply validates" {
    const a = std.testing.allocator;
    const prefix = "/home/epentland/ai/canopy/.selka-agent-cache/loops/capture-buffer/capture-";
    const request = try std.Io.Dir.cwd().readFileAlloc(std.testing.io, prefix ++ "request-component.bin", a, .limited(67108864));
    defer a.free(request);
    const reply = try std.Io.Dir.cwd().readFileAlloc(std.testing.io, prefix ++ "reply-component.bin", a, .limited(67108864));
    defer a.free(reply);
    var input = try wire.decode(a, value.Input, request[64..], "SLKBKI01");
    defer input.arena.deinit();
    std.debug.print("request decoded\n", .{});
    var output = try wire.decode(a, value.Outcome, reply[64..], "SLKBKR01");
    defer output.arena.deinit();
    std.debug.print("reply decoded\n", .{});
    try validate.input(a, input.value);
    std.debug.print("request validated\n", .{});
    try validate.outcome(a, input.value, output.value);
}

test { _ = @import("body_check_buffer_test.zig"); }
