from pathlib import Path
import subprocess,re,json,hashlib
root=Path.cwd();lane=root/'.tmp/zero-review';zig=Path('/home/epentland/zig-toolchains')/(root/'.zigversion').read_text().strip()/'zig';source='279501d1'
changed=subprocess.check_output(['git','diff','--name-only','f4b6647d',source,'--','vendor/qbe'],text=True).splitlines();assert changed==['vendor/qbe/amd64/isel.c'],changed
for name,repo_path in [('fixed-isel.c','vendor/qbe/amd64/isel.c'),('fixed-probe.ssa','tests/fixtures/qbe-zero-branch/probe.ssa'),('fixed-probe.c','tests/fixtures/qbe-zero-branch/probe.c')]:
 (lane/name).write_bytes(subprocess.check_output(['git','show',source+':'+repo_path]))
text=(root/'build.zig').read_text().split('const qbe_sources = [_][]const u8{',1)[1].split('};',1)[0]
sources=[str(lane/'fixed-isel.c') if p=='amd64/isel.c' else str(root/'vendor/qbe'/p) for p in re.findall(r'"([^"]+)"',text)]
qbe=lane/'fixed-qbe';rows=[]
def run(name,argv,expected=0):
 p=subprocess.run(argv,cwd=root,capture_output=True,text=True,timeout=600)
 (lane/(name+'.stdout')).write_text(p.stdout);(lane/(name+'.stderr')).write_text(p.stderr)
 rows.append({'name':name,'argv':list(map(str,argv)),'status':p.returncode,'stdout':p.stdout})
 print(name,p.returncode,p.stdout.strip(),flush=True);assert p.returncode==expected,(name,p.stderr)
 return p
run('fixed-source-build',[str(zig),'cc','-std=c99','-O3','-fno-sanitize=undefined','-I',str(root/'vendor/qbe/amd64'),'-I',str(root/'vendor/qbe'),*sources,'-o',str(qbe)])
for name,ssa,c in [('fixed-production',lane/'fixed-probe.ssa',lane/'fixed-probe.c'),('fixed-independent',lane/'fixtures.ssa',lane/'oracle.c'),('fixed-tail',lane/'trailing-address-v4.ssa',lane/'trailing-address-v4.c')]:
 asm=lane/(name+'.s');binary=lane/name
 run(name+'-select',[str(qbe),'-o',str(asm),str(ssa)])
 run(name+'-link',[str(zig),'cc','-std=c11','-O2','-UNDEBUG','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),str(asm),'-o',str(binary)])
 p=run(name+'-execute',[str(binary)])
 expected={'fixed-production':'zero branch probes: 140 cases passed\n','fixed-independent':'QBE zero-branch oracle: 3754 assertions passed, 0 failed; 15 function fixtures, 121 arithmetic input pairs\n','fixed-tail':'zero result: payload=456 expected=456 branch=23 expected=23\n'}[name]
 assert p.stdout==expected,(name,p.stdout)
installed=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-zero-release-20260930/.tmp/release-fixed/bin/qbe')
assert hashlib.sha256(installed.read_bytes()).hexdigest()=='df60056d2cdbef23eb6c5dada5249fdaf232bb6e75d4b4799c1626fc67b30819'
run('installed-fixed-tail-select',[str(installed),'-o',str(lane/'installed-fixed-tail.s'),str(lane/'trailing-address-v4.ssa')])
run('installed-fixed-tail-link',[str(zig),'cc','-O2','-fsanitize=undefined','-fno-sanitize-recover=all',str(lane/'trailing-address-v4.c'),str(lane/'installed-fixed-tail.s'),'-o',str(lane/'installed-fixed-tail')])
run('installed-fixed-tail-execute',[str(lane/'installed-fixed-tail')])
s=(lane/'fixed-independent.s').read_text();summary={}
positive=['add64_ne','add64_eq','add64_swap_ne','sub64_eq','sub64_ne','add32_ne','sub32_eq','pressure']
negative=['width_mismatch','nonzero_comparand','boolean_multiuser','intervening_call','intervening_arithmetic','arithmetic_multiuser','address_use']
for name in positive+negative:
 body=s.split(name+':',1)[1].split('/* end function',1)[0]
 instructions=re.findall(r'^\s+([a-z][a-z0-9]*)\s',body,re.M)
 cmps=[i for i in instructions if i.startswith(('cmp','test'))];assert (not cmps)==(name in positive),(name,cmps)
 summary[name]={'comparisons':cmps,'stack_refs':len(re.findall(r'\(%(?:rsp|rbp)\)',body))}
 assert any(i.startswith(('add','sub')) for i in instructions),name
 if name=='pressure':assert summary[name]['stack_refs']>0
for name in ['fixed-tail','installed-fixed-tail']:
 asm=(lane/(name+'.s')).read_text();assert 'cmpq' in asm;summary[name]={'compare_restored':True}
files=[lane/'fixed-isel.c',lane/'fixed-probe.ssa',lane/'fixed-probe.c',qbe,lane/'fixed-production.s',lane/'fixed-independent.s',lane/'fixed-tail.s',installed,lane/'installed-fixed-tail.s']
receipt={'corrected_source':subprocess.check_output(['git','rev-parse',source],text=True).strip(),'base_review_source':subprocess.check_output(['git','rev-parse','f4b6647d'],text=True).strip(),'qbe_source_diff':changed,'protocol':'Independent pinned Zig cc build using committed corrected isel; all other QBE source/header files identical; UBSan140 and3754 suites plus exact prior failing tail; owner installed artifact confirms tail too; no timings','commands':rows,'assembly':summary,'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(lane/'fixed-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Corrected source/oracle/assembly checks PASS',flush=True)
