from pathlib import Path
import io,gzip,tarfile,json,hashlib,subprocess
root=Path.cwd();lane=root/'.tmp/zero-review';out=root/'docs/audits/evidence/zero-branch-independent-fixed-20260930'
paths={}
for p in sorted(lane.iterdir()):
 if p.is_file() and (p.name.startswith(('fixed','installed-fixed')) or p.name in ('fixtures.ssa','oracle.c','design.json','prepare.py','trailing-address-v4.ssa','trailing-address-v4.c','archive-fixed.py')):
  if p.suffix in ('.py','.ssa','.c','.s','.json','.log','.stdout','.stderr'):paths[p.name]=p
for name in ('fixed-qbe','fixed-production','fixed-independent','fixed-tail','installed-fixed-tail'):
 paths['artifacts/'+name]=lane/name
paths['artifacts/owner-fixed-qbe']=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-zero-release-20260930/.tmp/release-fixed/bin/qbe')
rows=[];buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,p in sorted(paths.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o755 if name.startswith('artifacts/') else 0o644
  tar.addfile(info,io.BytesIO(data));rows.append({'member':name,'original_path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
raw=gzip.compress(buf.getvalue(),mtime=0);(out/'raw-review.tar.gz').write_bytes(raw)
manifest={'corrected_source':subprocess.check_output(['git','rev-parse','279501d1'],text=True).strip(),'rejected_source':subprocess.check_output(['git','rev-parse','f4b6647d'],text=True).strip(),'archive':'raw-review.tar.gz','archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'members':rows}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'fixed-receipt.json').write_bytes((lane/'fixed-receipt.json').read_bytes())
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(raw)),mode='r:') as tar:
 for row in rows:
  data=tar.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print(len(rows),'members',len(raw),'compressed bytes',manifest['archive_sha256'])
