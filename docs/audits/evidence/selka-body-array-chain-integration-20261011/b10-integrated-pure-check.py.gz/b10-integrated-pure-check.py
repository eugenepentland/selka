from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
seed = Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
sys.path.insert(0, str(root / 'selfhost'))
from test_pilots import require_guest
assert hashlib.sha256(seed.read_bytes()).hexdigest() == 'c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b'
names = ['array_catalog_tests.my', 'array_engine_tests.my', 'array_places_tests.my',
         'tuple_engine_tests.my', 'chained_compare_tests.my', 'body_tests.my',
         'array_policy_tests.my', 'array_routing_tests.my']
base = root / 'selfhost/components/body_check'
selected = [{'path': str(base / name), 'tests': len(re.findall(r'^public func test_\w+\(', (base / name).read_text(), re.M)),
             'sha256': hashlib.sha256((base / name).read_bytes()).hexdigest()} for name in names]
closure = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(base.glob('*.my'))}
env = {k: v for k, v in os.environ.items() if not k.startswith(('MYLANG_', 'PILOT_'))}
env.update(MYLANG_ZIG='/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig',
           MYL_CORE_LEAKCHECK='1', MYLANG_COMPONENT_DIR='/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/4069-prefix/libexec/mylang/components')
for component in ['LEXER', 'PARSER', 'DECLARATION', 'TYPE_INTERFACE', 'BODY_CHECK', 'TEST_INDEX', 'CACHE_PLAN']:
    env['MYLANG_' + component + '_MODE'] = 'reference'
report = {'complete': False, 'selection': selected, 'source_closure': closure,
          'tests_per_mode': sum(s['tests'] for s in selected), 'records': []}
def save():
    (work / 'b10-integrated-pure-report.json').write_text(json.dumps(report, indent=2) + '\n')
def run(command, label):
    result = subprocess.run(list(map(str, command)), cwd=root, env=env, capture_output=True, text=True, timeout=600)
    report['records'].append({'label': label, 'command': list(map(str, command)), 'status': result.returncode,
                              'stdout': result.stdout, 'stderr': result.stderr})
    save()
    print(label, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout, result.stderr, flush=True)
        raise RuntimeError(label + ' failed')
    return result
save()
run([seed, 'check', base / 'main.my', '--no-cache'], 'integrated producer check')
run([sys.executable, '-m', 'unittest', 'discover', '-s', 'selfhost/tests', '-p', 'body*test.py'], 'body harness selftests')
run([seed, 'fmt-project', base / 'main.my', '--check'], 'producer closure formatting')
for name in names:
    run([seed, 'fmt', base / name, '--check'], 'format ' + name)
for release in (False, True):
    mode = 'release' if release else 'normal'
    for entry in selected:
        result = run([seed, 'test', entry['path'], '--force', '--no-cache',
                      *(['--release', '--verify-facts'] if release else [])], mode + ' ' + Path(entry['path']).name)
        require_guest(result.stdout, entry['tests'])
for relative, expected in closure.items():
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected
report.update(complete=True, failed=0, skipped=0)
save()
print('Integrated focused tests passed', report['tests_per_mode'], 'per mode', flush=True)
