#define MYL_RC_COLLECTIONS_LIBRARY 1
#include "../../tests/native_rc_registered_release_test.c"

enum { REVIEW_GROWTH_DEPTH = 64 };
typedef struct {
    myl_native_type types[REVIEW_GROWTH_DEPTH];
    myl_native_field native_fields[REVIEW_GROWTH_DEPTH - 1];
    myl_rc_shape sources[REVIEW_GROWTH_DEPTH];
    myl_rc_field source_fields[REVIEW_GROWTH_DEPTH - 1];
    const myl_rc_shape *roots[REVIEW_GROWTH_DEPTH];
    myl_rc_descriptor descriptors[REVIEW_GROWTH_DEPTH];
    myl_rc_module module;
    const myl_native_type *old_type;
    const myl_rc_binding *old_binding;
    const myl_rc_shape *old_shape;
    myl_native_list *old_list;
    void *old_child;
    myl_rc_frame *old_frames;
    size_t old_shape_mask, old_binding_mask;
    unsigned callbacks;
} ReviewGrowth;

static void review_prepare_growth(ReviewGrowth *data) {
    for (unsigned i = 0; i < REVIEW_GROWTH_DEPTH; ++i) {
        data->types[i] = (myl_native_type){.size=sizeof(void *),
            .alignment=_Alignof(void *), .kind=MYL_NATIVE_POINTER};
        data->sources[i] = (myl_rc_shape){.size=sizeof(void *),
            .kind=MYL_RC_SHAPE_POINTER};
        if (i) {
            data->native_fields[i-1] = (myl_native_field){.type=&data->types[i-1]};
            data->types[i].kind = MYL_NATIVE_RECORD;
            data->types[i].fields = &data->native_fields[i-1];
            data->types[i].field_count = 1;
            data->source_fields[i-1] = (myl_rc_field){.shape=&data->sources[i-1]};
            data->sources[i].kind = MYL_RC_SHAPE_RECORD;
            data->sources[i].as.record.fields = &data->source_fields[i-1];
            data->sources[i].as.record.count = 1;
        }
        data->roots[i] = &data->sources[i];
        data->descriptors[i] = (myl_rc_descriptor){.type=&data->types[i],
            .shape=&data->sources[i]};
    }
    data->module = (myl_rc_module){.abi=MYL_RC_ABI_VERSION,
        .shapes=data->roots, .shape_count=REVIEW_GROWTH_DEPTH,
        .descriptors=data->descriptors, .descriptor_count=REVIEW_GROWTH_DEPTH};
}

static void review_registering_finalize(myl_native_heap *heap, void *payload) {
    ReviewGrowth *data = *(ReviewGrowth **)payload;
    assert(!heap->rc->walk.depth && heap->rc->dead.active);
    assert(data->old_list->length == 2);
    assert(((myl_rc_object *)data->old_child-1)->owners == 1);
    assert(((myl_rc_object *)data->old_child-1)->holds == 2);
    assert(myl_rc_module_register(heap, &data->module) == MYL_RC_OK);
    assert(heap->rc->walk.capacity >= REVIEW_GROWTH_DEPTH);
    assert(heap->rc->walk.frames != data->old_frames);
    assert(heap->rc->metadata.shapes.mask > data->old_shape_mask);
    assert(heap->rc->metadata.bindings.mask > data->old_binding_mask);
    assert(myl_rc_binding_find(heap, data->old_type) == data->old_binding);
    assert(data->old_binding->descriptor.shape == data->old_shape);
    assert(myl_rc_shape_resolve(heap, data->old_shape) == data->old_shape);
    ++data->callbacks;
}

static void review_canonical_graph_survives_growth(int image) {
    ReleaseGraph graph;
    ReleaseRegistration registration;
    prepare(&graph, &registration, 1);
    myl_native_heap heap;
    start(&heap);
    assert((image ? myl_rc_module_register_image(&heap, &registration.module,
                    &registration.image) :
        myl_rc_module_register(&heap, &registration.module)) == MYL_RC_OK);
    ReviewGrowth growth = {0};
    review_prepare_growth(&growth);
    growth.old_type = &graph.types[3];
    growth.old_binding = myl_rc_binding_find(&heap, growth.old_type);
    growth.old_shape = growth.old_binding->descriptor.shape;
    const myl_rc_shape *children[4] = {growth.old_shape};
    for (unsigned i = 1; i < 4; ++i) {
        assert(children[i-1]->kind == MYL_RC_SHAPE_RECORD);
        children[i] = children[i-1]->as.record.fields[0].shape;
    }
    assert(children[3]->kind == MYL_RC_SHAPE_HOLD_POINTER);
    growth.old_child = myl_rc_storage_bytes(&heap, 8, 0);
    assert(growth.old_child);
    growth.old_list = myl_native_list_new(&heap, growth.old_type, 2);
    assert(growth.old_list);
    assert(myl_rc_list_append(&heap, growth.old_list, &growth.old_child));
    assert(myl_rc_list_append(&heap, growth.old_list, &growth.old_child));
    if (!image) {
        memset(graph.sources, 0, sizeof graph.sources);
        memset(graph.source_fields, 0, sizeof graph.source_fields);
    }

    const myl_native_type finalized = {.size=sizeof(void *),
        .alignment=_Alignof(void *), .kind=MYL_NATIVE_PLAIN};
    const myl_rc_shape none = {.size=sizeof(void *), .kind=MYL_RC_SHAPE_NONE};
    const myl_rc_descriptor descriptor = {.type=&finalized, .shape=&none,
        .finalize=review_registering_finalize};
    assert(myl_rc_descriptor_import(&heap, &descriptor) == MYL_RC_OK);
    ReviewGrowth **trigger = myl_native_heap_alloc(&heap, &finalized, 1);
    assert(trigger);
    *trigger = &growth;
    const myl_native_type pointer = {.size=sizeof(void *),
        .alignment=_Alignof(void *), .kind=MYL_NATIVE_POINTER};
    myl_native_list *trigger_list = myl_native_list_new(&heap, &pointer, 1);
    assert(trigger_list && myl_rc_list_append(&heap, trigger_list, &trigger));
    myl_rc_owner_release(&heap, trigger);
    growth.old_frames = heap.rc->walk.frames;
    growth.old_shape_mask = heap.rc->metadata.shapes.mask;
    growth.old_binding_mask = heap.rc->metadata.bindings.mask;
    assert(myl_rc_list_clear(&heap, trigger_list));
    assert(growth.callbacks == 1);

    const myl_rc_shape *cursor = growth.old_shape;
    for (unsigned i = 0; i < 4; ++i) {
        assert(cursor == children[i]);
        if (i < 3) cursor = cursor->as.record.fields[0].shape;
    }
    assert(myl_rc_list_clear(&heap, growth.old_list));
    assert(!growth.old_list->length && growth.old_list->generation == 3);
    assert(!((void **)growth.old_list->storage)[0]);
    assert(!((void **)growth.old_list->storage)[1]);
    assert(((myl_rc_object *)growth.old_child-1)->owners == 1);
    assert(!((myl_rc_object *)growth.old_child-1)->holds);
    assert(growth.old_binding->descriptor.shape == growth.old_shape);
    myl_rc_owner_release(&heap, growth.old_child);
    myl_rc_owner_release(&heap, growth.old_list);
    myl_rc_owner_release(&heap, trigger_list);
    finish(&heap);
}

int main(void) {
    assert(myl_rc_registered_release_verify() == 13);
    review_canonical_graph_survives_growth(0);
    review_canonical_graph_survives_growth(1);
    puts("independent registered release: 15 cases passed");
    return 0;
}
