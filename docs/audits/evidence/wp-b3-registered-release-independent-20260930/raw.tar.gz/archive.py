from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

root = Path(__file__).resolve().parents[2]
scratch = Path(__file__).resolve().parent
package = root / '.tmp/registered-release-independent-package'
raw = package / 'raw'
assert not package.exists(), 'Do not replace existing evidence'
raw.mkdir(parents=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(source, relative):
    target = raw / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


for f in sorted(scratch.rglob('*')):
    if f.is_file():
        copy(f, f.relative_to(scratch))

summary = json.loads((scratch / 'summary-receipt.json').read_text())
files = [
    f for f in (root / 'src').iterdir()
    if f.is_file() and (f.suffix == '.h' or
                       f.name in summary['source_proof']['runtime_sources'])
]
for f in sorted(files):
    copy(f, Path('frozen-sources/candidate/src') / f.name)
for relative in ['tests/native_rc_registered_release_test.c',
                 'src/native_rc_collections_test.zig', 'SPEC.md', 'build.zig',
                 'build_test_inputs.zig', 'scripts/test_native_memory.py',
                 'scripts/build-slot.sh']:
    copy(root / relative, Path('frozen-sources/candidate') / relative)

production = subprocess.run(['git', 'diff', '--exit-code', summary['frozen_source'],
                             '--', 'src', 'vendor', 'SPEC.md', 'build.zig',
                             'build_test_inputs.zig', 'scripts', 'tests'],
                            cwd=root, capture_output=True, check=True)
assert not production.stdout
manifest = {
    str(f.relative_to(raw)): {'bytes': f.stat().st_size, 'sha256': digest(f)}
    for f in sorted(raw.rglob('*')) if f.is_file()
}
(raw / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = package / 'raw.tar.gz'
with archive.open('wb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(mode='w', fileobj=compressed) as tar:
            for f in sorted(raw.rglob('*')):
                if not f.is_file():
                    continue
                data = f.read_bytes()
                entry = tarfile.TarInfo(str(f.relative_to(raw)))
                entry.size = len(data)
                entry.mode = 0o755 if f.stat().st_mode & 0o111 else 0o644
                entry.mtime = 0
                tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(manifest) + 1
    assert len({m.name for m in members}) == len(members)
    assert json.loads(tar.extractfile('manifest.json').read()) == manifest
    for relative, expected in manifest.items():
        data = tar.extractfile(relative).read()
        assert len(data) == expected['bytes'], relative
        assert hashlib.sha256(data).hexdigest() == expected['sha256'], relative
receipt = {'archive': str(archive), 'bytes': archive.stat().st_size,
           'sha256': digest(archive), 'manifest_sha256': digest(raw / 'manifest.json'),
           'raw_members': len(manifest), 'total_members': len(manifest)+1,
           'all_member_lengths_and_hashes_verified': True,
           'summary_receipt_sha256': digest(raw / 'summary-receipt.json'),
           'report_sha256': digest(raw / 'report.md')}
(package / 'package-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
