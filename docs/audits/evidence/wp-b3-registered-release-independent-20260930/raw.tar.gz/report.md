# Independent registered-shape release review

Frozen source: `c13be022aa4a5260d15b002c377de15c5abb4480`, reviewed in the
exclusive `codex-next-registered-release-review-20260930` worktree. The parent
runtime lane owns source integration and performance acceptance. This review
contains source and native behavioral evidence only; it makes no hardware,
corpus-performance or final-gate claim.

## Source finding

No actionable regression was found in the narrow patch. The production changes
are one collection caller, a private-header declaration/comment and extraction
of the old public release body. A programmatic comparison proves the new
`myl_rc_registered_edges_release` body is byte-identical to the old
`myl_rc_edges_release` body after removing its single shape registry lookup.
The public wrapper still checks heap/RC/traversal depth before its original
lookup, then delegates to the helper. The helper retains the same heap/depth,
nonnull-shape, extent-overflow and address checks and the complete old pointer,
shallow and generic O/H traversal, slot clearing and death order. The entire
`native_collections.c` file is equal to the baseline apart from the one
`rc_elements_release` call replacement. The observed pre-freeze production and
fixture hashes exactly match the committed freeze.

The helper's admitted internal input is a shape already held by a binding from
the same heap. An arbitrary raw shape passed directly to this private helper is
outside its internal contract. The public raw/source API retains its identity
lookup and refusal; no user-facing raw API is relaxed.

## Provenance and lifetime

Dynamic registration's `build_batch` copies the root and child shape graph and
rewrites both descriptor and child references into that retained batch. Dynamic
descriptor registration likewise resolves its shape before publication. Image
registration validates a closed immutable entry graph, copies mutable bindings
into a heap-owned batch, and borrows the image graph under its existing lifetime
contract. `index_commit` publishes canonical self identities. Registry growth
replaces index arrays, not the retained binding or graph allocations. Batches
are freed only during heap teardown; borrowed images remain immutable and alive
until their participating heaps are destroyed.

The changed collection caller obtains its binding through the existing type
lookup and already used that binding's registered shape for the preceding depth
test. Release-path queuing/draining is unchanged. `drain_one`, its registering
finalizer, its post-callback binding reacquisition and every other public/source
release caller remain untouched. This includes resource hooks and dynamic
child graphs. No new metadata field/cache, alias authority, unchecked counter or
static native ID is introduced.

## Independent execution

`growth-controls.c` includes the frozen 13-case owner fixture and adds two
independent cases. Each added case retains a depth-four H child graph, one
dynamic and one image-backed, while an unrelated dying object's finalizer
registers a new 64-deep graph and 64 descriptors. Assertions require actual
shape-map and binding-map growth and replacement of the traversal frame array.
They verify that the old binding/root/each child identity and O/H counts survive
that callback. The dynamic case erases the original root and source-field
metadata before the callback. Both then clear the original collection, require
both slots empty and H zero/O one, and finish with zero live objects, frames,
queued deaths and heap bytes.

The included owner fixture provides six dynamic/image O/H traversal cases, one
registering-finalizer case, and six expected SIGABRT refusals: public unknown
source identity, missing heap, missing address, extent overflow, active walker,
and null canonical shape. Assertions remain active with `-UNDEBUG`. Native
runtime code is compiled at `-O2 -DMYL_NATIVE_RC=1` with UBSan and
`-fno-sanitize-recover=all`.

The control is the unchanged `5535e5a3` runtime. A documented compile-only
macro maps the new private helper name in the candidate fixture to the old
public API; baseline production sources remain unchanged. Thus the same
behavioral fixture can execute on both implementations without inventing a
baseline helper. Each compiler/arm run is individually admitted through
`scripts/build-slot.sh build taskset -c 0`; the compile and native execution both
remain on CPU 0, outside the reserved timing pool. The receipt records exact
admission and compiler commands, versions, environment, source identities,
statuses, outputs and executable hashes. Per-arm receipts are the authority for
the completed results; the final summary requires all four arms to pass.

The initial invocation attempted a nonexistent standalone `clang` PATH command
and failed in the harness before C compilation. Both setup failures are retained
separately. The corrected Clang arm uses the installed pinned `zig cc` driver;
no production or fixture behavior changed. This setup failure is not classified
as a product/native test failure. Guardian was not exercised by the direct
native compiler runs.

## Completed result

All four admitted runs passed: Zig Clang/control, Zig Clang/candidate,
GCC/control and GCC/candidate each completed 15/15 cases with exact identical
stdout and empty stderr. That is 60 case executions: 36 positive executions
and 24 expected SIGABRT refusals, with zero UBSan diagnostics or native failures.
The candidate remains byte-identical to the frozen production source.
