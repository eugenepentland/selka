from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

root = Path(__file__).resolve().parents[2]
native = Path(__file__).resolve().parent
performance = root / '.tmp/registered-release-performance-review'
out = root / '.tmp/registered-release-independent-followup'
assert not out.exists()
raw = out / 'raw'
raw.mkdir(parents=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(source, relative):
    target = raw / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


for name in ['growth-controls.c', 'run.py', 'source-receipt.json',
             'growth-receipt.json', 'archive-followup.py']:
    copy(native / name, Path('native-growth') / name)
for compiler in ['clang', 'gcc']:
    for side in ['control', 'candidate']:
        directory = native / f'{compiler}-{side}-growth'
        for source in directory.iterdir():
            if source.is_file():
                copy(source, Path('native-growth') / directory.name / source.name)
for source in performance.rglob('*'):
    if source.is_file():
        copy(source, Path('performance-review') / source.relative_to(performance))

evidence = root / 'docs/audits/evidence/wp-b3-registered-release-independent-20260930'
for name in ['guardian-full.log', 'guardian-receipt.json']:
    copy(evidence / name, Path('guardian') / name)
manifest = {str(f.relative_to(raw)): {'bytes': f.stat().st_size, 'sha256': digest(f)}
            for f in sorted(raw.rglob('*')) if f.is_file()}
(raw / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = out / 'raw.tar.gz'
with archive.open('wb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for source in sorted(raw.rglob('*')):
                if not source.is_file():
                    continue
                data = source.read_bytes()
                entry = tarfile.TarInfo(str(source.relative_to(raw)))
                entry.mode = 0o755 if source.stat().st_mode & 0o111 else 0o644
                entry.size = len(data)
                entry.mtime = 0
                tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(manifest) + 1
    assert len({m.name for m in tar.getmembers()}) == len(manifest) + 1
    assert json.loads(tar.extractfile('manifest.json').read()) == manifest
    for relative, expected in manifest.items():
        data = tar.extractfile(relative).read()
        assert len(data) == expected['bytes'], relative
        assert hashlib.sha256(data).hexdigest() == expected['sha256'], relative
receipt = {'sha256': digest(archive), 'bytes': archive.stat().st_size,
           'raw_members': len(manifest), 'total_members': len(manifest)+1,
           'all_member_lengths_and_hashes_verified': True,
           'manifest_sha256': digest(raw / 'manifest.json'),
           'growth_receipt_sha256': digest(raw / 'native-growth/growth-receipt.json'),
           'performance_review_receipt_sha256': digest(raw / 'performance-review/receipt.json'),
           'previous_native_archive_sha256': 'c728d5834f40a51908eb1d7c2ac949edf21b21dfc14274b53637dcfba3ff7282'}
(out / 'package-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
