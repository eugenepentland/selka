from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--compiler', choices=['clang', 'gcc'], required=True)
parser.add_argument('--side', choices=['control', 'candidate'], required=True)
parser.add_argument('--growth-only', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parents[2]
scratch = Path(__file__).resolve().parent
out = scratch / (args.compiler + '-' + args.side + ('-growth' if args.growth_only else ''))
out.mkdir()
receipt = json.loads((scratch / 'source-receipt.json').read_text())
runtime = root / 'src' if args.side == 'candidate' else scratch / 'baseline-native'
compiler = ([shutil.which('zig'), 'cc'] if args.compiler == 'clang' else
            [shutil.which('gcc')])
assert compiler[0], 'Required installed C compiler missing'
command = compiler + ['-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
           '-UNDEBUG', '-fsanitize=undefined', '-fno-sanitize-recover=all',
           '-ffunction-sections', '-fdata-sections', '-Wl,--gc-sections',
           '-DMYL_NATIVE_RC=1', '-I', str(runtime)]
if args.side == 'control':
    command.append('-Dmyl_rc_registered_edges_release=myl_rc_edges_release')
if args.growth_only:
    command.append('-DMYL_REGISTERED_REVIEW_GROWTH_ONLY=1')
command += [str(runtime / source) for source in receipt['runtime_sources']]
command += [str(scratch / 'growth-controls.c'), '-lm', '-o', str(out / 'verify')]
environment = {key: value for key, value in os.environ.items()
               if not key.startswith('MYLANG_') and key != 'LD_PRELOAD'}
environment['ZIG_LOCAL_CACHE_DIR'] = str(root / '.zig-local-cache')
environment['ZIG_GLOBAL_CACHE_DIR'] = str(root / '.zig-global-cache')
environment['TMPDIR'] = str(root / '.tmp/native-review-tmp')
Path(environment['TMPDIR']).mkdir(exist_ok=True)
environment['UBSAN_OPTIONS'] = 'halt_on_error=1:print_stacktrace=1'
version = subprocess.check_output(compiler + ['--version'], text=True)
(out / 'compiler-version.txt').write_text(version)
start = time.monotonic()
build = subprocess.run(command, cwd=root, env=environment, capture_output=True)
(out / 'build.stdout').write_bytes(build.stdout)
(out / 'build.stderr').write_bytes(build.stderr)
results = {'side': args.side, 'compiler': args.compiler,
           'source': receipt['frozen_source'] if args.side == 'candidate' else receipt['baseline_source'],
           'build': {'command': command, 'status': build.returncode,
                     'elapsed_seconds': time.monotonic() - start},
           'environment': {key: environment[key] for key in
                           ['TMPDIR', 'ZIG_LOCAL_CACHE_DIR', 'ZIG_GLOBAL_CACHE_DIR', 'UBSAN_OPTIONS']},
           'scope': 'Independent focused UBSan behavioral comparison; no timing acceptance'}
if build.returncode == 0:
    run_command = [str(out / 'verify')]
    run = subprocess.run(run_command, cwd=root, env=environment, capture_output=True)
    (out / 'run.stdout').write_bytes(run.stdout)
    (out / 'run.stderr').write_bytes(run.stderr)
    expected = (b'independent registered release: 2 growth cases passed\n' if args.growth_only else
                b'independent registered release: 15 cases passed\n')
    results['run'] = {'command': run_command, 'status': run.returncode,
                      'output_exact': run.stdout == expected,
                      'expected_refusals': 0 if args.growth_only else 6,
                      'positive_cases': 2 if args.growth_only else 9,
                      'ubsan_diagnostic_absent': b'runtime error:' not in run.stderr,
                      'binary_sha256': hashlib.sha256((out / 'verify').read_bytes()).hexdigest()}
    passed = run.returncode == 0 and run.stdout == expected and b'runtime error:' not in run.stderr
else:
    passed = False
results['passed'] = passed
(out / 'receipt.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2), flush=True)
raise SystemExit(0 if passed else 1)
