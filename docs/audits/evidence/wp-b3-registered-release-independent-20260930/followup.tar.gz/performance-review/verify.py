from pathlib import Path
import hashlib
import json
import math
import shutil

own = Path(__file__).resolve().parents[2]
root = Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-closeout-20260929')
source = root / '.tmp/phase-b-registered-release-combined'
out = own / '.tmp/registered-release-performance-review'
assert not out.exists(), 'Preserve existing review evidence'
out.mkdir()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


comparison = json.loads((source / 'comparison.json').read_text())
measurement = json.loads((source / 'measurement-receipt.json').read_text())
identity = comparison['identity']
assert identity == measurement['identity']
assert digest(source / 'compiler/bin/mylang') == identity['compiler_sha256']
assert digest(source / 'compiler/bin/qbe') == identity['qbe_sha256']
assert len(comparison['candidate_binaries_sha256']) == 58
for name, expected in comparison['candidate_binaries_sha256'].items():
    binary = root / '.tmp-rc-quick/bin/phase-b-registered-release-combined' / name
    assert digest(binary) == expected, name
for relative, expected in measurement['sha256'].items():
    assert digest(root / relative) == expected, relative

hashes = {}


def capture(path, relative):
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    hashes[str(relative)] = digest(target)


for name in ['identity.json', 'comparison.json', 'measurement-receipt.json',
             'install.log', 'corpus-build.log', 'measure-dev.log',
             'measure-full.log', 'measure-smoke.log']:
    capture(source / name, Path('combined') / name)


def indexed(data):
    assert not data['failures']
    rows = {(r['arm'], r['id']): r for r in data['rows']}
    assert len(rows) == len(data['rows']) == 86
    assert all(sum(key[0] == arm for key in rows) == 43 for arm in ['qbe', 'llvm'])
    return rows


checks = {}
text_counts = []
common_keys = None
for size in ['dev', 'full', 'smoke']:
    paths = {
        'candidate': root / f'.tmp-rc-quick/results-phase-b-registered-release-combined-{size}.json',
        'approved': root / f'.tmp-rc-quick/results-m17-codex-{size}.json',
        'pinned': root / f'.tmp/phase-b-fresh-a5-pinned-control/results-{size}.json',
    }
    matrices = {}
    for name, path in paths.items():
        capture(path, Path(name) / f'results-{size}.json')
        matrices[name] = indexed(json.loads(path.read_text()))
    candidate = matrices['candidate']
    keys = set(candidate)
    assert keys == set(matrices['approved']) == set(matrices['pinned'])
    assert common_keys is None or keys == common_keys
    common_keys = keys
    rows = comparison['sizes'][size]['rows']
    assert len(rows) == 86 and {(r['arm'], r['id']) for r in rows} == keys
    cap_counts = {'qbe': 0, 'llvm': 0}
    bad = {'approved': [], 'pinned': []}
    new_caps = {'approved': [], 'pinned': []}
    for row in rows:
        key = (row['arm'], row['id'])
        actual = candidate[key]
        assert row['rc'] == actual['rc'] and row['gc'] == actual['gc']
        assert math.isclose(row['ratio'], actual['rc'] / actual['gc'], rel_tol=1e-12)
        assert row['ratio'] == actual['ratio']
        under_cap = 10 * actual['rc'] <= 13 * actual['gc']
        cap_counts[row['arm']] += under_cap
        for name, baseline_column, delta_column in [
            ('approved', 'approved_a5_rc', 'regression_percent'),
            ('pinned', 'fresh_a5_rc', 'fresh_control_regression_percent'),
        ]:
            base = matrices[name][key]
            assert base['gc'] == actual['gc']
            assert row[baseline_column] == base['rc']
            delta = (actual['rc'] / base['rc'] - 1) * 100
            assert math.isclose(delta, row[delta_column], abs_tol=1e-11)
            if actual['rc'] * 100 > base['rc'] * 101:
                bad[name].append(list(key))
            if not under_cap and base['rc'] * 10 <= base['gc'] * 13:
                new_caps[name].append(list(key))
    if size in ['dev', 'full']:
        assert cap_counts == {'qbe': 43, 'llvm': 43}
        assert not bad['approved'] and not bad['pinned']
    else:
        assert len(bad['approved']) == len(bad['pinned']) == 6
        assert not new_caps['approved'] and not new_caps['pinned']
        assert cap_counts == {'qbe': 39, 'llvm': 37}
    for arm in ['qbe', 'llvm']:
        assert cap_counts[arm] == comparison['sizes'][size]['summary'][arm]['within_1_3']
    assert comparison['sizes'][size]['matching_outputs'] == measurement['coverage'][size] == 86
    text = candidate[('llvm', 'parity/suite/text_ops')]
    text_counts.append(text['rc'])
    checks[size] = {'rows': 86, 'unique_rows_and_complete_keys': True,
                    'absolute_caps_within_1_3': cap_counts,
                    'regressions_over_1_percent': bad,
                    'new_cap_misses': new_caps,
                    'llvm_text_ops_instructions': text['rc']}

assert max(text_counts) - min(text_counts) == 56
receipt = {'scope': 'Read-only algebra and frozen file/binary identity verification; no samples executed',
           'identity': identity, 'results': checks,
           'measurement_receipt_member_hashes_verified': len(measurement['sha256']),
           'candidate_binaries_verified': 58,
           'raw_candidate_rows_equal_comparison_rows': True,
           'raw_approved_and_pinned_control_counts_equal_comparison_columns': True,
           'text_ops_three_size_instruction_range': 56,
           'no_sample_selection': 'Comparison uses exactly the single observation in each original size/row file',
           'recorded_output_matches': 258,
           'output_limit': 'Reviewer checked successful harness records and coverage; did not rerun guest outputs',
           'acceptance': 'Declared dev/full limits pass; smoke retains six diagnostics and existing absolute cap misses; final full gate remains required',
           'captured_files_sha256': hashes}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt_sha256': digest(out / 'receipt.json'), 'sizes': checks,
                  'verified_binaries': 58, 'text_ops_range': 56}, indent=2))
