import hashlib,json,shutil,subprocess,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path('selfhost/tests').resolve()))
import run_body_check_qualification as D
F=D.F;c=Path('/home/epentland/ai/canopy/.selka-agent-cache/loops');host=c/'text-methods-native-prefix/bin/mylang';components=c/'text-methods-installed';root='cce6c1e83c1ceea88f650276f8ceaa96365c67b9'
names=('profile_text_method','bytes_encode_profile','bytes_decode_profile');report={'complete':False,'root_commit':root,'host_sha256':F.digest(host),'packages':D.packages(components,body_schema=10),'sources':{},'records':[]};output=c/'original-text-promotion.json'
def save():output.write_text(json.dumps(report,indent=2)+'\n')
for name in names:
 p=Path('selfhost/tests/fixtures/body_check')/(name+'.input');data=p.read_bytes();original=subprocess.check_output(['git','show',root+':'+str(p)]);assert data==original
 report['sources'][name]={'sha256':hashlib.sha256(data).hexdigest(),'root_sha256':hashlib.sha256(original).hexdigest()}
save()
with tempfile.TemporaryDirectory(dir=c/'tmp',prefix='original-text-') as tmp:
 work=Path(tmp);empty=work/'empty';empty.mkdir()
 for name in names:
  entry=work/(name+'.my');shutil.copyfile(Path('selfhost/tests/fixtures/body_check')/(name+'.input'),entry)
  for phase,command in [('check',['check-project',entry,'--no-cache','--diagnostics=json']),('typed',['dump-typed',entry]),('normal',['run-project',entry,'--no-cache','--print-result','--cache-dir',work/'normal-cache','--zig=/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig']),('release',['run-project',entry,'--no-cache','--release','--verify-facts','--print-result','--cache-dir',work/'release-cache','--zig=/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'])]:
   native=None
   for mode in ('reference','shadow','component'):
    argv=[host,*command];r=F.execute(argv,D.environment(mode,components,empty),work,600);report['records'].append({'name':name,'phase':phase,'mode':mode,'command':list(map(str,argv)),'status':r[0],'stdout_hex':r[1].hex(),'stderr_hex':r[2].hex()});save()
    if mode=='reference':native=r
    assert r==native,(name,phase,mode,r)
    if phase=='check':assert r==(0,b'',b'')
    elif phase=='typed':assert r[0]==0 and r[1] and not r[2]
    else:assert r==(7,b'7\n',b'')
assert F.digest(host)==report['host_sha256'] and D.packages(components,body_schema=10)==report['packages'];report.update(complete=True,operations=36,failed=0,skipped=0);save();print('original text promotion: 36 passed, 0 failed, 0 skipped')
