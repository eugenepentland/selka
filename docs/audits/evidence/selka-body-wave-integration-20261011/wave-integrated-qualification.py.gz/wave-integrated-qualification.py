import json,os,subprocess,sys
from pathlib import Path
root=Path('/home/epentland/.codex/worktrees/selka-structural-pilot/mylang')
work=Path("/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp")
prefix=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/buffer-iteration-native-prefix')
install=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/wave-integrated-components')
zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
report={'complete':False,'records':[]}
dest=work/'wave-integrated-qualification.json'
def run(name,args,timeout=2400):
 path=work/('wave-integrated-'+name+'.log')
 print('START',name,flush=True)
 with path.open('wb') as log:
  result=subprocess.run(list(map(str,args)),cwd=root,env=os.environ,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 report['records'].append({'name':name,'command':list(map(str,args)),'status':result.returncode,'log':str(path)})
 dest.write_text(json.dumps(report,indent=2)+'\n')
 print('STATUS',name,result.returncode,flush=True)
 if result.returncode:raise RuntimeError(name+' failed; see '+str(path))
run('install',[prefix/'tools/selka-components','--root',root,'--zig',zig,'--cache-dir','/home/epentland/.cache/mylang/components','--install-dir',install],1800)
packages=D.packages(install,body_schema=10)
report['packages']=packages
report['host_sha256']=D.F.digest(prefix/'bin/mylang')
dest.write_text(json.dumps(report,indent=2)+'\n')
common=['--compiler',prefix/'bin/mylang','--builder',prefix/'tools/selka-components','--source-root',root,'--zig',zig,'--component-dir',install]
run('harness-selftests',[sys.executable,'-m','unittest','discover','-s','selfhost/tests','-p','body*test.py'],600)
for mode in ['normal','release']:
 run('constants-'+mode,[sys.executable,root/'selfhost/tests/run_body_constant_admission.py',*common,'--report',work/('wave-integrated-constants-'+mode+'.json'),*(['--release'] if mode=='release' else [])])
for name in ['structural','iteration','chained']:
 run(name,[sys.executable,root/('selfhost/tests/run_body_'+name+'_admission.py'),*common,'--release','--report',work/('wave-integrated-'+name+'.json')])
run('hostile',[sys.executable,root/'selfhost/tests/run_body_structural_hostile.py','--compiler',prefix/'bin/mylang','--zig',zig,'--component-dir',install,'--report',work/'wave-integrated-hostile.json','--evidence-dir',work/'wave-integrated-hostile-capture'])
body_common=['--compiler',prefix/'bin/mylang','--builder',prefix/'tools/selka-components','--zig',zig,'--component-dir',install]
for mode in ['normal','release']:
 run('main-body-'+mode,[sys.executable,root/'selfhost/tests/run_body_check_qualification.py',*body_common,'--report',work/('wave-integrated-main-body-'+mode+'.json'),*(['--release'] if mode=='release' else [])],3600)
assert packages==D.packages(install,body_schema=10),'deployment changed'
report.update(complete=True,failed=0,skipped=0)
dest.write_text(json.dumps(report,indent=2)+'\n')
print('WAVE QUALIFICATION PASSED',flush=True)
