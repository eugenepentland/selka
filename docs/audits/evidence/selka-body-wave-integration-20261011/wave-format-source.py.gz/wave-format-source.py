import hashlib,json,subprocess,sys
from pathlib import Path
root=Path("/home/epentland/.codex/worktrees/selka-structural-pilot/mylang")
work=Path("/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp")
sys.path.insert(0,str(root/'scripts'))
from check_my_format import select_sources
compiler=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/buffer-iteration-native-prefix/bin/mylang')
changed=set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root,text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
selected,_=select_sources(root)
sources=sorted(changed & set(selected))
archive=work/'wave-pre-format-source'
for name in sources:
 p=root/name
 before=p.read_bytes()
 result=subprocess.run([compiler,'fmt',p],cwd=root,capture_output=True)
 if result.returncode:
  print(name,result.stderr.decode(),flush=True);raise SystemExit(result.returncode)
 if not result.stdout:raise RuntimeError('empty formatter output '+name)
 if before!=result.stdout:
  copy=archive/name
  copy.parent.mkdir(parents=True,exist_ok=True)
  copy.write_bytes(before)
  p.write_bytes(result.stdout)
  print('formatted',name,flush=True)
print('format-selected',len(sources),flush=True)
