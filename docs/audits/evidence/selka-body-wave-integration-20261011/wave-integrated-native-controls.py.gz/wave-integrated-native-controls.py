import gzip, hashlib, json, os, subprocess, sys
from pathlib import Path
root=Path("/home/epentland/.codex/worktrees/selka-structural-pilot/mylang")
work=Path("/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp")
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
prefix=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/buffer-iteration-native-prefix')
compiler=prefix/'bin/mylang'
empty=work/'wave-control-empty-path'
empty.mkdir(exist_ok=True)
env=D.environment('reference',prefix/'libexec/mylang/components',empty)
fixtures=root/'selfhost/tests/fixtures/body_constant_candidate'
names=["range_array_implicit.my","range_array_positive_step.my","range_array_descending.my","range_array_dynamic.my","range_array_rebound.my","range_array_outer_counter.my","range_array_u64_stride.my","chain_constant.my","chain_constant_float.my","chain_dead_arithmetic.my","error_chain_dead_dependency.my","error_chain_dead_name.my","error_array_constant_type.my","error_fixed_array_constant_type.my","error_source_array_parameter.my","error_source_fixed_array_parameter.my","error_source_buffer_parameter.my","error_source_filesystem_parameter.my","error_source_stream_parameter.my","error_shadow_filesystem_constant.my","error_table_constant_type.my","error_source_table_parameter.my"]
report={'complete':False,'compiler_sha256':D.F.digest(compiler),'records':[]}
dest=work/'wave-integrated-native-controls.json'
for name in names:
    result=D.F.execute([compiler,'check-project',fixtures/name,'--no-cache','--diagnostics=json'],env,root,600)
    record={'name':name,'status':result[0],'stdout_hex':result[1].hex(),'stderr_hex':result[2].hex(),'source_sha256':D.F.digest(fixtures/name)}
    report['records'].append(record)
    dest.write_text(json.dumps(report,indent=2)+'\n')
    print(name,result[0],result[2].decode()[:800],flush=True)
report['complete']=True
dest.write_text(json.dumps(report,indent=2)+'\n')
gate=work/'b10-full-gate-2a1.log'
archive=work/'b10-full-gate-2a1-terminal.log.gz'
with archive.open('wb') as out:
    with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as zipped:
        zipped.write(gate.read_bytes())
receipt={'source_head':'2a1f92edc1c962bc03d628bb132e0d93aa475187','session':74488,'terminal_status':1,'source_log_sha256':D.F.digest(gate),'archive_sha256':D.F.digest(archive),'summary':next(x for x in gate.read_text().splitlines() if x.startswith('Build Summary:')),'acceptance':'failed','failures':['CLI shard peak 3181240320 exceeds declared2684354560 bytes','live MY comparisons.my formatting','Core compile killed by earlyoom SIGTERM (journal separately retained)','three record_type_tests synthetic catalog rows lack array field']}
(work/'b10-full-gate-2a1-terminal.json').write_text(json.dumps(receipt,indent=2)+'\n')
