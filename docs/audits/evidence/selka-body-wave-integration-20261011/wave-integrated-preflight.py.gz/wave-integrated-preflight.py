import hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
root=Path("/home/epentland/.codex/worktrees/selka-structural-pilot/mylang")
work=Path("/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp")
prefix=Path('/home/epentland/ai/canopy/.selka-agent-cache/body-structural-b10/buffer-iteration-native-prefix')
seed=Path('/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang')
zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
sys.path.insert(0,str(root/'selfhost'))
from test_pilots import require_guest
env=dict(os.environ)
env.update(MYLANG_ZIG=str(zig),MYLANG_COMPONENT_DIR=str(prefix/'libexec/mylang/components'),MYL_CORE_LEAKCHECK='1')
for name in ['LEXER','PARSER','DECLARATION','TYPE_INTERFACE','BODY_CHECK','TEST_INDEX','CACHE_PLAN']:env['MYLANG_'+name+'_MODE']='reference'
sources={str(p.relative_to(root)):D.F.digest(p) for p in sorted((root/'selfhost/components').rglob('*.my'))}
report={'complete':False,'seed_sha256':D.F.digest(seed),'source_sha256':sources,'records':[]}
assert report['seed_sha256']=='c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b'
dest=work/'wave-integrated-preflight.json'
def execute(name,cmd,timeout=600):
 print('START',name,flush=True)
 result=subprocess.run(list(map(str,cmd)),cwd=root,env=env,capture_output=True,timeout=timeout)
 report['records'].append({'name':name,'command':list(map(str,cmd)),'status':result.returncode,'stdout_hex':result.stdout.hex(),'stderr_hex':result.stderr.hex()})
 dest.write_text(json.dumps(report,indent=2)+'\n')
 print(result.stdout.decode(errors='replace'),end='',flush=True)
 print(result.stderr.decode(errors='replace'),end='',flush=True)
 print('STATUS',name,result.returncode,flush=True)
 if result.returncode:raise RuntimeError('preflight failed '+name)
 return result.stdout.decode()
execute('main-check',[seed,'check',root/'selfhost/components/body_check/main.my','--no-cache'])
execute('full-live-my-format',[sys.executable,root/'scripts/check_my_format.py','--compiler',prefix/'bin/mylang','--root',root])
roots=['body_tests.my','constant_eval_tests.my','constant_integer_tests.my','constant_float_tests.my','array_index_tests.my','array_write_tests.my','sequence_iteration_tests.my','range_tests.my','chained_compare_tests.my','record_type_tests.my']
total=0
for release in (False,True):
 for name in roots:
  path=root/'selfhost/components/body_check'/name
  count=len(re.findall(r'^public func test_[A-Za-z0-9_]+\(',path.read_text(),re.M))
  flags=['--release','--verify-facts'] if release else []
  if name=='constant_eval_tests.my':flags+=['--max-steps','500000000','--max-memory','1G']
  out=execute(name+('-release' if release else '-normal'),[seed,'test',path,'--force','--no-cache',*flags])
  require_guest(out,count)
  total+=count
assert sources=={str(p.relative_to(root)):D.F.digest(p) for p in sorted((root/'selfhost/components').rglob('*.my'))},'producer sources changed during preflight'
report.update(complete=True,pure_tests=total,failed=0,skipped=0)
dest.write_text(json.dumps(report,indent=2)+'\n')
print('PREFLIGHT PASSED',total,'tests',flush=True)
