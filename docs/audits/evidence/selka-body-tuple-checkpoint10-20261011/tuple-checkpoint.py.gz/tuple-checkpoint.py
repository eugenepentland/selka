#!/usr/bin/env python3
"""Explicit eight-source tuple checkpoint, not the strict 30-source B10 gate."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys
from types import SimpleNamespace

ap = argparse.ArgumentParser(description=__doc__)
for name in ('source-root', 'compiler', 'component-dir', 'builder', 'zig', 'work'):
    ap.add_argument('--' + name, type=Path, required=True)
args = ap.parse_args()
for name, value in vars(args).items():
    setattr(args, name, value.resolve())
sys.path.insert(0, str(args.source_root / 'selfhost/tests'))
import run_body_structural_admission as S
D, F = S.D, S.F
NAMES = (
    'dictionary_generator_pairs.my', 'tuple_context.my', 'tuple_list.my',
    'tuple_literal.my', 'tuple_nested.my', 'tuple_swap.my',
    'error_tuple_arity.my', 'error_tuple_element.my',
)
manifest, inventory = S.selection()
selected = {name: manifest[name] for name in NAMES}
F.require(len(selected) == 8 and sum(s['status'] == 0 for s in selected.values()) == 6,
          'explicit tuple checkpoint selection changed')
args.work.mkdir(parents=True, exist_ok=False)
source = args.work / 'sources'; source.mkdir()
empty = args.work / 'empty-path'; empty.mkdir()
for name in inventory['donors']:
    shutil.copyfile(S.FIXTURES / name, source / name)
for name in NAMES:
    shutil.copyfile(S.FIXTURES / Path(name).with_suffix('.input'), source / name)

def identity():
    return {'compiler_sha256': F.digest(args.compiler),
            'packages': D.packages(args.component_dir, body_schema=10)}

before = identity()
report = {'complete': False, 'selected_admission': 'pending', 'schema': 10,
          'scope': 'Explicit eight-source tuple checkpoint; strict 30-source B10 gate remains pending',
          'source_cases': selected, 'expected_operations': 60, 'expected_captures': 8,
          'modes': list(S.MODES), 'records': [], 'captures': [], **before,
          'runtime_flags': ['--release', '--verify-facts', 'MYL_CORE_LEAKCHECK=1']}

def save():
    (args.work / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

save()
seed = F.execute([args.builder, '--root', args.source_root, '--zig', args.zig, '--seed-only'],
                 D.coordinator_environment(), args.source_root, 600)
report['seed_verification'] = {'status': seed[0], 'stdout_hex': seed[1].hex(), 'stderr_hex': seed[2].hex()}
save()
lines = seed[1].decode().strip().splitlines()
F.require(seed[0] == 0 and len(lines) == 1 and Path(lines[0]).is_file(), 'missing qualified seed receipt')
report['qualified_seed_sha256'] = F.digest(Path(lines[0]))
F.require(report['qualified_seed_sha256'] ==
          'c4f1ea0b6618cb7b146bbb8e035220eb36b99ff078d4a959d8bf0948d0c6d98b', 'qualified seed changed')
save()

def run(name, mode, phase, command):
    argv = [args.compiler, *command]
    result = F.execute(argv, D.environment(mode, args.component_dir, empty), args.work, 600)
    report['records'].append({'name': name, 'mode': mode, 'phase': phase,
        'command': list(map(str, argv)), 'source_sha256': manifest[name]['source_sha256'],
        'status': result[0], 'stdout_hex': result[1].hex(), 'stderr_hex': result[2].hex()})
    save()
    return result

for name, spec in selected.items():
    entry = source / name
    command = S.check_command(entry)
    native = run(name, 'reference', 'check', command)
    S.native_contract(native, spec)
    for mode in S.MODES[1:]:
        S.require_match(native, run(name, mode, 'check', command))
    capture_work = args.work / 'captures' / Path(name).stem
    capture_work.mkdir(parents=True)
    q = SimpleNamespace(work=capture_work, source=source, empty_path=empty, compiler=args.compiler)
    private, real = D.private_fixture(args, q)
    result, request, reply = D.capture_exchange(args, q, private, real, name)
    report['captures'].append({'name': name, 'status': result[0], 'stdout_hex': result[1].hex(),
        'stderr_hex': result[2].hex(), 'source_sha256': spec['source_sha256'],
        'request_sha256': hashlib.sha256(request).hexdigest(),
        'reply_sha256': hashlib.sha256(reply).hexdigest(),
        'request_path': str(capture_work / 'capture-request-component.bin'),
        'reply_path': str(capture_work / 'capture-reply-component.bin')})
    save()
    F.require(result == native, 'authentic tuple capture differs from native: ' + name)
    F.require(request[:8] == reply[:8] == b'SLKBCK01' and len(request) >= 64 and len(reply) >= 64
              and struct.unpack_from('<IIII', request, 8) == (1, 10, 0, len(request)-64)
              and struct.unpack_from('<IIII', reply, 8) == (1, 10, 1, len(reply)-64)
              and request[24:32] == reply[24:32]
              and hashlib.sha256(request[64:]).digest() == reply[32:64], 'tuple frame correlation failed')
    if spec['status'] != 0:
        continue
    command = ['dump-typed', entry]
    native = run(name, 'reference', 'typed', command)
    F.require(native[0] == 0 and native[1] and not native[2], 'missing native typed output')
    for mode in S.MODES[1:]:
        S.require_match(native, run(name, mode, 'typed', command))
    command = ['run-project', entry, '--no-cache', '--release', '--verify-facts', '--print-result',
               '--cache-dir', args.work / 'guest-cache', '--zig=' + str(args.zig)]
    for mode in S.MODES:
        F.require(run(name, mode, 'runtime', command) == (7, b'7\n', b''),
                  'tuple release/facts/leaks behavior differs')

F.require(identity() == before, 'tuple checkpoint deployment changed')
F.require(len(report['records']) == 60 and len(report['captures']) == 8, 'incomplete tuple checkpoint')
report.update(complete=True, selected_admission='passed', operations=60, failed=0, skipped=0)
save()
print('Explicit tuple checkpoint: 8 fixtures, 60 operations, 8 genuine captures passed; strict B10 pending')
