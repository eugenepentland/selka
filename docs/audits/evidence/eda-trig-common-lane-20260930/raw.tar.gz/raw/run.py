import hashlib, json, os, pathlib, re, shutil, subprocess, time
r=pathlib.Path.cwd(); raw=r/'.tmp/trig-qualified-extras'; raw.mkdir(parents=True,exist_ok=True)
pin=pathlib.Path('/home/epentland/ai/canopy/eda-bench-wt/mylang-e88fcf3c/bin/mylang')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(pin)=='6259edca26ea90f93b85037a17b5fc2692505a4e6f4cdd05cca23554b1bb0bcc'
source='e88fcf3c98d6f0e0090e0719472e1081fb81f119'
subprocess.run(['git','diff','--exit-code',source,'HEAD','--','src','build.zig','build_test_inputs.zig','.zigversion'],check=True)
loxsrc=pathlib.Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-closeout-20260929/.tmp-rc-quick/lox/benchmarks/lox/ports/mylang')
lox=raw/'lox-port'
assert not lox.exists()
shutil.copytree(loxsrc,lox,ignore=shutil.ignore_patterns('.mylang-cache','.zig-cache','.zig-global-cache','.tmp','.git','__pycache__'))
inputs=[]
for p in sorted(lox.rglob('*')):
 if p.is_file(): inputs.append({'path':str(p.relative_to(lox)),'bytes':p.stat().st_size,'sha256':sha(p)})
(raw/'lox-inputs.json').write_text(json.dumps({'source_root':str(loxsrc),'owned_root':str(lox),'files':inputs},indent=2)+'\n')
env=dict(os.environ,TMPDIR=str(r/'.tmp'),ZIG_GLOBAL_CACHE_DIR=str(r/'.zig-global-cache'),ZIG_LOCAL_CACHE_DIR=str(r/'.zig-cache'),MYLANG_TIMING_CPUS='2,3,10,11')
env.pop('MYLANG_RUNTIME',None)
for p in ['TMPDIR','ZIG_GLOBAL_CACHE_DIR','ZIG_LOCAL_CACHE_DIR']: pathlib.Path(env[p]).mkdir(parents=True,exist_ok=True)
slot=str(r/'scripts/build-slot.sh'); probe=str(raw/'admitted.py')
tasks=[('native-heap',r,['zig','build','test-native-heap','--summary','all'])]
for mode,flags in [('rc',[]),('gc',['--gc-runtime'])]:
 cache=str(raw/('lox-cache-'+mode))
 tasks += [('lox-build-'+mode,lox,[str(pin),'build','main.my','--project','-o',str(raw/('lox-'+mode)),'--cache-dir',cache]+flags),('lox-tests-'+mode,lox,[str(pin),'test','.','--force','--jobs','4','--max-steps=100000000','--cache-dir',cache]+flags),('lox-driver-'+mode,lox,[str(pin),'test','driver_tests.my','--cases','driver_cases.json','--force','--jobs','4','--max-steps=100000000','--cache-dir',cache]+flags)]
for mode,flags in [('release',['--release']),('stats',['--rc-runtime=stats'])]:
 tasks += [('lang-'+mode,r,[str(pin),'test','tests/lang','--force','--jobs','4','--cache-dir',str(r/'.mylang-cache'/('trig-extra-'+mode))]+flags)]
tasks += [('rc-fuzz-100',r,['zig','build','test-rc-fuzz','-Dfuzz-seeds=100','--summary','all','--','--compiler',str(pin),'--jobs','2','--out',str(raw/'fuzz')])]
receipt={'source':source,'report_head_at_start':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler':str(pin),'compiler_sha256':sha(pin),'reserved_cpus':[2,3,10,11],'source_difference_from_frozen':False,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'steps':[]}
def save(): (raw/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save()
for name,cwd,cmd in tasks:
 full=[slot,'build','python3',probe]+cmd
 row={'name':name,'cwd':str(cwd),'command':cmd,'admission_command':full,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 (raw/'inflight.json').write_text(json.dumps(row,indent=2)+'\n')
 print('START '+name,flush=True);t=time.perf_counter()
 log=raw/(name+'.log')
 with log.open('wb') as f: p=subprocess.run(full,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row.update(exit=p.returncode,wall_s=time.perf_counter()-t,log_sha256=sha(log),log_bytes=log.stat().st_size)
 text=log.read_text(errors='replace')
 row['guest_summaries']=re.findall(r'\d+ passed, \d+ cached, \d+ failed, \d+ skipped, \d+ dropped across \d+ programs',text)
 row['build_summaries']=re.findall(r'Build Summary:[^\n]+',text)
 lines=[x for x in text.splitlines() if x.startswith('admission_identity: ')]
 row['admission']=json.loads(lines[0].split(': ',1)[1]) if lines else None
 receipt['steps'].append(row);save();print('END '+json.dumps(row),flush=True)
receipt['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()); receipt['all_zero']=all(x['exit']==0 for x in receipt['steps']);save()
(raw/'inflight.json').unlink()
raise SystemExit(0 if receipt['all_zero'] else 1)
