import json, os, sys, time
print('admission_identity: '+json.dumps({'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'cpus':sorted(os.sched_getaffinity(0)),'cwd':os.getcwd(),'TMPDIR':os.environ['TMPDIR'],'ZIG_GLOBAL_CACHE_DIR':os.environ['ZIG_GLOBAL_CACHE_DIR'],'command':sys.argv[1:]}),file=sys.stderr,flush=True)
os.execvp(sys.argv[1],sys.argv[1:])
