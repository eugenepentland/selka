import subprocess,os,json,time,pathlib,hashlib
r=pathlib.Path.cwd();raw=r/'.tmp/trig-qualified';e=dict(os.environ,TMPDIR=str(r/'.tmp'),ZIG_GLOBAL_CACHE_DIR=str(r/'.zig-global-cache'));rows=[]
for target in ['test','test-qbe','test-qbe-build','fmt-check']:
 cmd=['zig','build',target,'--summary','all'];t=time.perf_counter()
 with (raw/(target+'.log')).open('wb') as f:p=subprocess.run(cmd,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT)
 row={'target':target,'command':cmd,'exit':p.returncode,'wall_s':time.perf_counter()-t,'log_sha256':hashlib.sha256((raw/(target+'.log')).read_bytes()).hexdigest()};rows.append(row);(raw/'receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if p.returncode:break
