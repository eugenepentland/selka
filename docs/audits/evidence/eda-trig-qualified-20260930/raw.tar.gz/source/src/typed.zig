//! Checked nodes use declaration identities, concrete types, and local slots.
const effect_set = @import("effect_set.zig");
const std = @import("std");
const provider_contracts = @import("provider_contracts.zig");
const external_resources = @import("external_resources.zig");
const values = @import("value.zig");
const Span = @import("source.zig").Span;
/// Index of a checked expression in Program.nodes.
pub const NodeId = enum(usize) { _ };
/// Index of a checked statement in Program.statements.
pub const StatementId = enum(usize) { _ };
/// Index of a resolved function in Program.functions.
pub const FunctionId = enum(usize) { _ };
/// Index of a function-local value slot.
pub const LocalId = enum(usize) { _ };
pub const Type = values.Type;
pub const Value = values.Value;
/// Checked arithmetic, logical, and comparison operation categories.
pub const BinaryOp = enum {
    add,
    sub,
    mul,
    div,
    rem,
    floor_div,
    floor_rem,
    logical_and,
    logical_or,
    eq,
    ne,
    lt,
    le,
    gt,
    ge,
    bit_and,
    bit_or,
    bit_xor,
    shift_left,
    shift_right,
    wrapping_add,
    wrapping_sub,
    wrapping_mul,
    saturating_add,
    saturating_sub,
    saturating_mul,
    f64_add,
    f64_sub,
    f64_mul,
    f64_div,
    f64_eq,
    f64_lt,
    f64_le,
};
/// Checked numeric negation and Boolean inversion operations.
pub const UnaryOp = enum { neg, not, f64_sqrt, f64_floor, f64_ceil, f64_trunc, f64_abs, f64_neg, f64_from_u64, f64_to_u64, f64_from_i64, f64_to_i64, f64_to_i8, f64_to_i16, f64_to_i32, f64_to_u8, f64_to_u16, f64_to_u32, f64_sin, f64_cos };
/// Typed expression with resolved operands and source location.
pub const Node = struct {
    ty: Type,
    span: Span,
    data: union(enum) {
        integer: i128,
        boolean: bool,
        unit,
        block_value: struct { body: StatementId, value: NodeId },
        function_value: FunctionId,
        invoke: struct { callee: NodeId, arguments: []const NodeId },
        local: LocalId,
        propagate: struct { value: NodeId, output: Type },
        buffer_operation: struct { kind: @import("buffer_operations.zig").Kind, owner: LocalId, arguments: []const NodeId },
        acquire_resource: struct { capability: NodeId, request: NodeId },
        complete_resource: NodeId,
        resource_io: struct { kind: external_resources.IoKind, owner: LocalId, value: ?NodeId },
        restrict_resource: struct { permissions: external_resources.Permissions, value: NodeId },
        dir_resource: struct { capability: NodeId, path: NodeId },
        host_resource: struct { capability: NodeId, name: NodeId },
        environment_get: struct { capability: NodeId, name: NodeId },
        environment_only: struct { capability: NodeId, names: NodeId },
        environment_names: NodeId,
        external_read: struct { kind: @import("external_capabilities.zig").Kind, capability: NodeId },
        stand_in: struct { kind: @import("external_capabilities.zig").StandIn, first: NodeId, second: ?NodeId },
        acquire_buffer: struct { capacity: NodeId },
        print: Print,
        stream_write: StreamWrite,
        file_access: FileAccess,
        file_method: FileMethod,
        arena_escape: NodeId,
        cast: NodeId,
        wrap: NodeId,
        variant: struct { tag: usize, value: ?NodeId },
        unwrap: NodeId,
        array: []const NodeId,
        /// A file `embed_bytes`/`embed_str` read at load time, as `bytes` or
        /// `str` static data with no per-byte nodes (`EMBED-1`).
        blob: Blob,
        /// `from_end` asks a fixed array to count a negative index back from its
        /// end first (`PY-ARRAY-NEGATIVE-1`); it is false where the checker proved
        /// the index non-negative, and managed receivers ignore it.
        index: struct { base: NodeId, index: NodeId, from_end: bool = false },
        replace: struct { base: NodeId, index: NodeId, value: NodeId, from_end: bool = false },
        length: NodeId,
        record: []const FieldInit,
        update: struct { base: NodeId, fields: []const FieldInit },
        field: struct { base: NodeId, index: usize },
        call: struct { evaluation: ?struct { body: StatementId, cleanup: []const LocalId } = null, function: FunctionId, arguments: []const NodeId },
        unary: struct { op: UnaryOp, operand: NodeId, op_span: Span },
        binary: struct { op: BinaryOp, left: NodeId, right: NodeId, op_span: Span },
    },
};
/// An embedded file (`EMBED-1`) as checked code names it: the content digest
/// that identifies its static object and the payload length. The bytes stay with
/// the loaded source, so a checked tree carries no per-byte data.
pub const Blob = struct { digest: [32]u8, length: usize };
/// Whole-path file helper: its operands begin with the `Filesystem` capability.
pub const FileAccess = struct { kind: @import("file_operations.zig").Access, mode: u8, text: bool, arguments: []const NodeId, shapes: FileShapes };
/// Method call on an open `with` binding, addressed by its local slot.
pub const FileMethod = struct { kind: @import("file_operations.zig").Method, owner: LocalId, text: bool, argument: ?NodeId, shapes: FileShapes };
/// Nominal payload schemas a file operation needs to build its result.
pub const FileShapes = struct { text: Type, bytes: Type, list: Type };
/// Which standard stream an ambient `print` writes to when no receiver is given.
/// `error_report` is standard error as the entry wrapper reports `main`'s `Err`:
/// the line opens with `error: ` and the error return trace follows it.
pub const Sink = enum { stdout, stderr, error_report };
/// Rendered arguments and the optional `sep=`/`end=` text of one output call.
/// A `stream` receiver selects the fd at runtime; a `debug` call writes to stderr
/// and contributes no effect.
pub const Print = struct { sink: Sink = .stdout, arguments: []const NodeId, separator: ?NodeId, terminator: ?NodeId, stream: ?NodeId = null, debug: bool = false };
/// `stream.write(text)`: the receiver stream value and the text to write.
pub const StreamWrite = struct { stream: NodeId, text: NodeId };
/// Resolved aggregate field index and the expression supplying its value.
pub const FieldInit = struct { index: usize, value: NodeId };
/// Named aggregate field with its declaration location and resolved type.
/// `default_value` is the backing node id of a declared record-field default.
/// `boxed` marks a field that closes a recursive value type: it stores a
/// pointer to an immutable managed box, while `ty` stays the value's own type
/// everywhere the checker looks (RECURSIVE-VALUES-2).
pub const Field = struct { name: []const u8, declaration: Span, ty: Type, default_value: ?usize = null, boxed: bool = false };
/// Named closed variant case and its optional resolved payload type.
/// `fielded` marks a parenthesized case whose payload is one synthesized record
/// of named fields, so construction and patterns bind one name per field.
/// `boxed` marks a payload that closes a recursive value type and is stored
/// behind an immutable managed box (RECURSIVE-VALUES-2).
pub const Variant = struct { name: []const u8, declaration: Span, payload: ?Type, fielded: bool = false, boxed: bool = false };
/// Closed case set distinguishing enums, unions, and fallible results.
pub const Variants = struct { fallible: bool = false, is_union: bool, cases: []const Variant };
/// Fixed element count and type, with an optional enum key for tables.
pub const Array = struct { element: Type, length: usize, key: ?Type = null };
// Aggregate schemas retain nominal record identities and intern structural arrays.
/// Declared domain wire type and resolved decoder/encoder function identities.
pub const Codec = struct { wire: Type, decode: FunctionId, encode: FunctionId };
/// Nominal aggregate schema and associated array, domain, collection, or variant metadata.
pub const Record = struct {
    collection: @import("runtime_values.zig").CollectionShape = .{},
    managed: bool = false,
    id: Type,
    name: []const u8,
    declaration: Span,
    fields: []const Field,
    shape: RecordShape = .{},
    contract: RecordContract = .{},
    /// Return the enum key type for a table, or null for other aggregates.
    pub fn tableKey(self: Record) ?Type {
        return if (self.shape.array) |a| a.key else null;
    }
    /// Identify a plain record rather than a specialized aggregate schema.
    pub fn isRecord(self: Record) bool {
        return !self.shape.hasRuntimeIdentity() and !self.shape.hasValueRepresentation();
    }
    /// The builtin Cell is the managed record with a closed one-field content policy.
    pub fn isCell(self: Record) bool {
        return self.managed and self.isRecord() and self.shape.builtin == .cell;
    }
    /// A managed nominal record: the builtin Cell or a user `class` declaration.
    /// Managed records carry reference identity, so assignment and calls share them.
    pub fn isManagedRecord(self: Record) bool {
        return self.managed and self.isRecord();
    }
    /// Managed collection operations require an element buffer, unlike Cell fields.
    pub fn isCollection(self: Record) bool {
        return self.managed and self.shape.buffer != null;
    }
    /// Identify a payload-free enum schema.
    pub fn isEnum(self: Record) bool {
        return if (self.shape.variants) |v| !v.is_union else false;
    }
    /// Return the number of statically addressable aggregate elements.
    pub fn count(self: Record) usize {
        return if (self.shape.array) |a| a.length else if (self.shape.domain != null) 1 else self.fields.len;
    }
    /// Resolve a field or array element type by its checked index.
    pub fn elementType(self: Record, index: usize) Type {
        return if (self.shape.array) |a| a.element else self.shape.domain orelse self.fields[index].ty;
    }
};
/// Optional specialized representations; bytecode validation rejects incompatible combinations.
pub const RecordShape = struct {
    array: ?Array = null,
    domain: ?Type = null,
    variants: ?Variants = null,
    buffer: ?Type = null,
    resource: ?external_resources.Kind = null,
    /// Declaration identity for builtin records with special transfer policies.
    builtin: enum { none, cell, live_view } = .none,
    /// An anonymous tuple: positional fields no source can name, taken apart by
    /// destructuring only. It keeps the plain record representation, so
    /// construction, field reads, equality and layout are the record ones.
    tuple: bool = false,
    /// Identify representations carrying a managed collection or resource identity.
    pub fn hasRuntimeIdentity(self: RecordShape) bool {
        return self.buffer != null or self.resource != null;
    }
    fn hasValueRepresentation(self: RecordShape) bool {
        return self.array != null or self.domain != null or self.variants != null;
    }
};
/// Sound upper bound on the inputs a returned value may alias.
/// `fresh` requires proof; `unknown` is the conservative default and is never
/// treated as `fresh` or as `params(empty)`.
pub const ReturnOrigin = union(enum) {
    fresh,
    params: []const u16,
    unknown,

    /// Compare two return-origin bounds by exact normalized content.
    pub fn eql(a: ReturnOrigin, b: ReturnOrigin) bool {
        return switch (a) {
            .fresh => switch (b) {
                .fresh => true,
                else => false,
            },
            .unknown => switch (b) {
                .unknown => true,
                else => false,
            },
            .params => |left| switch (b) {
                .params => |right| std.mem.eql(u16, left, right),
                else => false,
            },
        };
    }
};
/// Checked obligations, type-argument visibility and an optional explicit domain wire contract.
/// Exact value parameter/result types, declared effect ceiling and mutation contract.
pub const Callable = struct {
    parameters: []const Type,
    return_type: Type,
    effects: effect_set.Mask,
    mutates: []const u16 = &.{},
    return_origin: ReturnOrigin = .unknown,
    /// Every callback parameter is an ordinary operand-stack value.
    pub fn valueCount(self: Callable) usize {
        return self.parameters.len;
    }
};
/// Ownership and public schema policy for each concrete type.
pub const RecordContract = struct {
    callback: ?Callable = null,
    public_arguments: bool = true,
    codec: ?Codec = null,
    codec_declared: bool = false,
    move_only: bool = false,
    storable: bool = true,
    requires_handling: bool = false,
};
/// The already-interned tuple record for a concrete element list, or null when
/// the catalog has not materialized that list yet. The spelling path and the
/// value path both ask here first, so one element list is one record.
pub fn internedTuple(records: []const Record, elements: []const Type) ?Type {
    for (records, 0..) |schema, index| {
        if (!schema.shape.tuple or schema.fields.len != elements.len) continue;
        var same = true;
        for (schema.fields, elements) |field, element| if (field.ty != element) {
            same = false;
            break;
        };
        if (same) return @fromBackingInt(Type.record_base + index);
    }
    return null;
}
/// The positional field name of one tuple element. The `$` makes every tuple
/// field unnameable from source, so no program can reach an element except by
/// destructuring and no declared field can collide with one.
pub fn positionalFieldName(allocator: std.mem.Allocator, index: usize) std.mem.Allocator.Error![]const u8 {
    return std.fmt.allocPrint(allocator, "${d}", .{index});
}
/// Payload types and case tags of a checked ok/err result schema.
pub const ResultShape = struct { ok_type: Type, error_type: Type, ok_tag: usize, error_tag: usize };
/// Recognize a valid fallible result and return its payload types and tags.
pub fn resultShape(ty: Type, records: []const Record) ?ResultShape {
    if (!ty.isAggregate() or ty.recordIndex() >= records.len) return null;
    const variants = records[ty.recordIndex()].shape.variants orelse return null;
    if (!variants.fallible or !variants.is_union) return null;
    if (variants.cases.len != 2) return null;
    var ok: ?usize = null;
    var err: ?usize = null;
    for (variants.cases, 0..) |case, tag| {
        if (case.payload == null) return null;
        if (std.mem.eql(u8, case.name, "ok")) ok = tag;
        if (std.mem.eql(u8, case.name, "err")) err = tag;
    }
    return .{ .ok_type = variants.cases[ok orelse return null].payload.?, .error_type = variants.cases[err orelse return null].payload.?, .ok_tag = ok.?, .error_tag = err.? };
}
/// The case of the union `container` whose payload is exactly `payload`, if any.
pub fn wrappingCase(records: []const Record, container: Type, payload: Type) ?usize {
    if (!container.isAggregate() or container.recordIndex() >= records.len) return null;
    const variants = records[container.recordIndex()].shape.variants orelse return null;
    if (!variants.is_union) return null;
    for (variants.cases, 0..) |case, tag| {
        if (case.payload) |declared| if (declared == payload) return tag;
    }
    return null;
}
/// Equality supported by concrete expressions and generic equality requirements.
/// Scalars, enums and domains compare directly; records, fixed arrays, unions,
/// results and options compare structurally; a managed `class` compares by
/// reference. A type that reaches a callback, a Cell or a resource does not
/// support equality and neither does one that nests such a field. The visited
/// stack bounds reference recursion, and it is sound to accept a type already on
/// it: the runtime traverses references with cycle-safe identity.
pub fn supportsEquality(ty: Type, records: []const Record) bool {
    var visited: [64]usize = undefined;
    return equalitySupport(ty, records, &visited, 0);
}

fn equalitySupport(ty: Type, records: []const Record, visited: *[64]usize, depth: usize) bool {
    if (ty.isInteger() or ty == .bool) return true;
    if (!ty.isAggregate()) return false;
    const index = ty.recordIndex();
    if (index >= records.len) return false;
    for (visited[0..depth]) |seen| if (seen == index) return true;
    const record = records[index];
    if (record.contract.callback != null) return false;
    if (record.shape.builtin == .cell or record.shape.resource != null) return false;
    if (record.isEnum() or record.shape.domain != null) return true;
    if (depth == visited.len) return false;
    visited[depth] = index;
    const next = depth + 1;
    if (record.isCollection()) {
        if (record.collection.kind == .string or record.collection.kind == .bytes) return true;
        // A set's values are unit, which compare trivially: only its elements matter.
        if (!record.collection.set) if (record.shape.buffer) |element| if (!equalitySupport(element, records, visited, next)) return false;
        if (record.collection.key) |key| if (!equalitySupport(key, records, visited, next)) return false;
        return true;
    }
    if (record.shape.array) |array| return equalitySupport(array.element, records, visited, next);
    if (record.shape.variants) |variants| {
        for (variants.cases) |case| {
            if (case.payload) |payload| if (!equalitySupport(payload, records, visited, next)) return false;
        }
        return true;
    }
    for (record.fields) |field| if (!equalitySupport(field.ty, records, visited, next)) return false;
    return true;
}
/// Determine whether a type carries ownership that forbids implicit copying.
pub fn moveOnly(ty: Type, records: []const Record) bool {
    return ty.isAggregate() and records[ty.recordIndex()].contract.move_only;
}
/// Values whose destruction requires neither result handling nor external provider effects.
pub fn storable(ty: Type, records: []const Record) bool {
    return !ty.isAggregate() or records[ty.recordIndex()].contract.storable;
}
/// Determine whether a value contains an unacknowledged fallible result obligation.
pub fn requiresHandling(ty: Type, records: []const Record) bool {
    return ty.isAggregate() and records[ty.recordIndex()].contract.requires_handling;
}
/// Return the scalar spelling or borrowed nominal schema name of a type.
pub fn typeName(ty: Type, records: []const Record) []const u8 {
    return if (ty.isAggregate()) records[ty.recordIndex()].name else @tagName(ty);
}
/// Whether a parameter of this type can be written through at all. `list`,
/// `dict`, `class`, `Cell`, `[N]T`, `byte_buffer` and any record, union, option
/// or result holding one carry mutable managed storage; scalars, `str`, `bytes`
/// and records built only from those do not, so `mut` on them would promise a
/// write that cannot reach the caller.
pub fn carriesWritableStorage(records: []const Record, ty: Type) bool {
    return writableDepth(records, ty, 0);
}

/// Whether a `mut` parameter of this type crosses the call as the caller's own
/// storage: a fixed array `[N]T` or enum table `[Kind]T`. Every other writable
/// parameter is a reference already, so only these value types need the
/// callee to write through the caller's address for an element write to reach
/// the caller.
pub fn referenceArray(records: []const Record, ty: Type) bool {
    return ty.isAggregate() and ty.recordIndex() < records.len and records[ty.recordIndex()].shape.array != null;
}

/// A plain value `record` or tuple crosses a `mut` position as the caller's
/// own storage (`inout`) in either value mode. A field assignment, a nested
/// write or a rebinding of the parameter therefore reaches the caller.
pub fn referenceRecord(records: []const Record, ty: Type) bool {
    if (!ty.isAggregate() or ty.recordIndex() >= records.len) return false;
    const record = records[ty.recordIndex()];
    return !record.managed and record.isRecord() and record.contract.callback == null;
}

/// Whether a `mut` parameter of this type receives the caller's address: a
/// fixed array, or under value semantics a plain record (`referenceRecord`).
pub fn referenceMut(records: []const Record, ty: Type) bool {
    return referenceArray(records, ty) or referenceRecord(records, ty);
}

/// Whether a schema is a `set[T]`: a dictionary-kind collection from its
/// elements to unit that answers the set vocabulary instead of the mapping one.
pub fn isSet(record: Record) bool {
    return record.managed and record.collection.kind == .dictionary and record.collection.set;
}

/// The schema of a set type, or null for any other type.
pub fn setRecord(records: []const Record, ty: Type) ?Record {
    if (!ty.isAggregate() or ty.recordIndex() >= records.len) return null;
    return if (isSet(records[ty.recordIndex()])) records[ty.recordIndex()] else null;
}

/// Whether a managed byte-kind schema is the immutable byte string rather than
/// the mutable octet buffer. The two share one collection kind, so the builtin
/// name -- repeated here rather than imported, because the template index that
/// declares it depends on this module -- is what tells them apart.
fn isImmutableBytes(record: Record) bool {
    if (record.collection.kind == .string) return true;
    return isByteString(record);
}

/// Whether a managed schema is the immutable `bytes` byte string rather than the
/// mutable `byte_buffer` or the separate `str` kind. The distinction is nominal,
/// like `isImmutableBytes`, because both byte kinds share one collection kind.
pub fn isByteString(record: Record) bool {
    return record.managed and record.collection.kind == .bytes and !std.mem.eql(u8, record.name, "byte_buffer");
}

fn writableDepth(records: []const Record, ty: Type, depth: usize) bool {
    if (!ty.isAggregate() or ty.recordIndex() >= records.len or depth == 64) return false;
    const record = records[ty.recordIndex()];
    if (record.managed) {
        // `str`, `bytes` and a byte kind that is not the octet buffer are
        // immutable; every other managed schema -- a collection, `byte_buffer`,
        // `Cell`, or a user `class` -- keeps writable storage.
        return !isImmutableBytes(record);
    }
    if (record.shape.array) |array| if (writableDepth(records, array.element, depth + 1)) return true;
    // A boxed value is immutable: a write through it copies the path to it into
    // the holder's own storage, so it adds no storage a callee could write.
    if (record.shape.variants) |variants| for (variants.cases) |case| {
        if (case.boxed) continue;
        if (case.payload) |payload| if (writableDepth(records, payload, depth + 1)) return true;
    };
    for (record.fields) |field| if (!field.boxed and writableDepth(records, field.ty, depth + 1)) return true;
    return false;
}

/// Render a type the way source spells it, for user-facing diagnostics.
pub fn surfaceTypeName(allocator: std.mem.Allocator, ty: Type, records: []const Record) std.mem.Allocator.Error![]const u8 {
    return surfaceTypeText(allocator, typeName(ty, records));
}
/// Rewrite an internal type or signature spelling into the source surface spelling.
pub fn surfaceTypeText(allocator: std.mem.Allocator, raw: []const u8) std.mem.Allocator.Error![]const u8 {
    var out: std.ArrayList(u8) = .empty;
    defer out.deinit(allocator);
    var index: usize = 0;
    while (index < raw.len) {
        const ch = raw[index];
        if (ch == '-' and index + 1 < raw.len and raw[index + 1] == '>') {
            try out.appendSlice(allocator, "->");
            index += 2;
            continue;
        }
        if (ch == ':' and index + 1 < raw.len and raw[index + 1] == ':') {
            try out.append(allocator, '.');
            index += 2;
            continue;
        }
        if (ch == '<') {
            try out.append(allocator, '[');
            index += 1;
            continue;
        }
        if (ch == '>') {
            try out.append(allocator, ']');
            index += 1;
            continue;
        }
        if (ch == ',') {
            try out.appendSlice(allocator, ", ");
            index += 1;
            while (index < raw.len and raw[index] == ' ') index += 1;
            continue;
        }
        if (std.ascii.isAlphanumeric(ch) or ch == '_') {
            var end = index;
            while (end < raw.len and (std.ascii.isAlphanumeric(raw[end]) or raw[end] == '_')) end += 1;
            const word = raw[index..end];
            if (std.mem.eql(u8, word, "i64")) {
                try out.appendSlice(allocator, "int");
            } else if (std.mem.eql(u8, word, "f64")) {
                try out.appendSlice(allocator, "float");
            } else {
                try out.appendSlice(allocator, word);
            }
            index = end;
            continue;
        }
        try out.append(allocator, ch);
        index += 1;
    }
    const rendered = try out.toOwnedSlice(allocator);
    // `List` is the compiler-internal spelling; source always writes `list`.
    // Lowercase every standalone `List[` so nested lists read `list[...]` too.
    var cursor: usize = 0;
    while (std.mem.indexOfPos(u8, rendered, cursor, "List[")) |at| {
        const standalone = at == 0 or !(std.ascii.isAlphanumeric(rendered[at - 1]) or rendered[at - 1] == '_');
        if (standalone) rendered[at] = 'l';
        cursor = at + 5;
    }
    return rendered;
}
/// Return the segment after the final `::` or `.` of a qualified name.
pub fn localSegment(name: []const u8) []const u8 {
    var start: usize = 0;
    for (name, 0..) |ch, index| if (ch == ':' or ch == '.') {
        start = index + 1;
    };
    return name[start..];
}
/// Bounded Levenshtein distance; returns `limit + 1` when the distance exceeds it.
pub fn editDistanceAtMost(a: []const u8, b: []const u8, limit: usize) usize {
    if (a.len > b.len + limit or b.len > a.len + limit) return limit + 1;
    if (a.len > 256 or b.len > 256) return limit + 1;
    var previous: [257]usize = undefined;
    var current: [257]usize = undefined;
    for (0..b.len + 1) |j| previous[j] = j;
    for (a, 0..) |left, i| {
        current[0] = i + 1;
        for (b, 0..) |right, j| {
            const substitution = previous[j] + @as(usize, @intFromBool(left != right));
            const deletion = previous[j + 1] + 1;
            const insertion = current[j] + 1;
            current[j + 1] = @min(@min(substitution, deletion), insertion);
        }
        @memcpy(previous[0 .. b.len + 1], current[0 .. b.len + 1]);
    }
    return previous[b.len];
}
/// Render the `; did you mean ...?` clause naming declared keys within edit
/// distance two of `target`, or an empty slice when no close candidate exists.
pub fn suggestionClause(allocator: std.mem.Allocator, map: anytype, target: []const u8) std.mem.Allocator.Error![]const u8 {
    var candidates: std.ArrayList([]const u8) = .empty;
    defer candidates.deinit(allocator);
    var iterator = map.iterator();
    while (iterator.next()) |entry| {
        const name = localSegment(entry.key_ptr.*);
        if (std.mem.eql(u8, name, target)) continue;
        if (editDistanceAtMost(name, target, 2) > 2) continue;
        try candidates.append(allocator, name);
    }
    if (candidates.items.len == 0) return "";
    std.mem.sort([]const u8, candidates.items, {}, nameLessThan);
    var unique: usize = 0;
    for (candidates.items, 0..) |name, index| {
        if (index != 0 and std.mem.eql(u8, candidates.items[unique - 1], name)) continue;
        candidates.items[unique] = name;
        unique += 1;
    }
    const shown = candidates.items[0..@min(unique, 3)];
    var joined: std.ArrayList(u8) = .empty;
    defer joined.deinit(allocator);
    for (shown, 0..) |name, index| {
        if (index != 0) try joined.appendSlice(allocator, "`, `");
        try joined.appendSlice(allocator, name);
    }
    return std.fmt.allocPrint(allocator, "; did you mean {s}`{s}`?", .{ if (shown.len == 1) "" else "one of: ", joined.items });
}
fn nameLessThan(_: void, left: []const u8, right: []const u8) bool {
    return std.mem.lessThan(u8, left, right);
}
/// Resolved local assignment target and the expression being stored.
/// `element` marks the store an element write such as `a[i] = v` lowers to:
/// the value rebuilds the local from its own current value with one element
/// changed, so the write is a mutation of the binding rather than a rebinding.
pub const Store = struct { slot: LocalId, value: NodeId, element: bool = false };
/// Checked control flow, ownership operations, and expression statements.
pub const Statement = struct {
    span: Span,
    terminates: bool,
    owned_cleanup: []const LocalId = &.{},
    data: union(enum) {
        with_scope: struct { slot: LocalId, resource: ?NodeId, body: StatementId },
        block: []const StatementId,
        assertion: Assertion,
        ret: NodeId,
        discard: NodeId,
        branch: struct { condition: NodeId, then_body: StatementId, else_body: ?StatementId },
        match: struct { value: NodeId, arms: []const MatchArm, borrowed: bool = false },
        loop: struct { id: usize = 0, condition: NodeId, body: StatementId, step: ?StatementId = null },
        loop_exit: struct { target: usize, continuing: bool, arenas: []const LocalId = &.{} },
        initialize: Store,
        assign: Store,
    },
};
/// Checked condition with its static message and optional rendered message
/// expression, which is evaluated only when the condition is false. `kind`
/// names the clause the checker placed it for: an `assert` statement, or one
/// `@requires`, `@ensures` or `@invariant` contract clause.
pub const Assertion = struct { condition: NodeId, message: []const u8, message_value: ?NodeId = null, kind: AssertionKind = .statement };
/// The clause one checked assertion enforces.
pub const AssertionKind = enum { statement, requires, ensures, invariant };
/// Resolved case tag, optional payload local, and checked arm body.
pub const MatchArm = struct { tag: usize, slot: ?LocalId, body: StatementId };
/// Local type, declaration, usage counts, and tracked ownership/borrow state.
pub const Local = struct {
    ownership: LocalOwnership = .{},
    usage: LocalUsage = .{},
    name: []const u8,
    declaration: Span,
    ty: Type,
    mutable: bool,
    /// Where this binding's value came from, for copy-semantics diagnostics.
    origin: LocalOrigin = .local,
};
/// Compile-time ownership availability, definite-assignment, and arena confinement.
pub const LocalOwnership = struct { transfer_span: ?Span = null, initialized: bool = false, arena_confined: bool = false, transfer_available: bool = false };
/// Static binding reads and writes used by quality diagnostics.
pub const LocalUsage = struct {
    temporary: bool = false,
    reads: usize = 0,
    writes: usize = 0,
    /// Read count immediately after the most recent candidate field write.
    dead_write_reads: usize = 0,
    /// Span of the most recent candidate field write; null when none happened.
    dead_write_span: ?Span = null,
};
/// Source of a local's value when differing copy semantics matter.
/// `contract_old` is the hidden local an `@ensures` clause's `old(...)`
/// value is captured in at entry, whose initializer must be effect-free;
/// `contract_value` holds the value a contract clause is checked against
/// (`result`, or an invariant's `self`).
pub const LocalOrigin = enum { local, parameter, iteration, collection_copy, contract_old, contract_value };

/// Checked function signature, local/reference metadata, effects, and body identity.
pub const Function = struct {
    policy: FunctionPolicy = .{},
    /// Concrete specialization arguments; empty for an ordinary source function.
    type_arguments: []const Type = &.{},
    signature: FunctionSignature = .{},
    scope: FunctionScope,
    id: FunctionId,
    name: []const u8,
    declaration: Span,
};
/// Declared visibility and effect policy, with its inferred execution effects.
pub const FunctionPolicy = struct {
    c_abi: bool = false,
    host: ?Span = null,
    effect_bound: ?effect_set.Bound = null,
    effects: effect_set.Mask = 0,
    owner: ?Type = null,
    restricted: bool = false,
    conversion: bool = false,
};
/// Checked write and physical-result facts used after body inference.
pub const InferredFacts = struct {
    /// Any managed receiver write in the body.
    writes: bool = false,
    /// A write not proven to target definitely fresh local storage.
    external: bool = false,
    /// Backing a result may retain even when value semantics make it logically
    /// independent of its source.
    borrow_origin: ReturnOrigin = .unknown,
};
/// Resolved value result and parameter count of a checked function.
pub const FunctionSignature = struct {
    constant_arguments: []const ?usize = &.{},
    return_type: Type = .i64,
    parameter_count: usize = 0,
    /// Inferred parameter positions this function may write, normalized and sorted.
    mutates: []const u16 = &.{},
    /// Inferred upper bound on inputs returned values may alias.
    return_origin: ReturnOrigin = .unknown,
    /// Declared `mutates(...)` footprint; empty also spells an omitted clause.
    declared_mutates: []const u16 = &.{},
    /// Write facts kept separate so a fresh-local write can stay unenforced.
    inferred: InferredFacts = .{},
};
/// Checked function body and its lexical local table.
pub const FunctionScope = struct {
    body: StatementId,
    locals: []const Local = &.{},
};
/// Borrowed checked expression, statement, function, and nominal schema tables.
/// Checked transparent name and its canonical target, retained for public interfaces.
pub const TypeAlias = struct { name: []const u8, target: Type, declaration: Span };
/// Checked semantic graph with arena-owned type and alias identities.
pub const Program = struct { aliases: []const TypeAlias = &.{}, nodes: []const Node, statements: []const Statement, functions: []const Function, main: FunctionId, records: []const Record = &.{} };

/// Identify the external provider family associated with a type.
pub fn resourceKind(ty: Type, records: []const Record) ?external_resources.Kind {
    if (!ty.isAggregate() or ty.recordIndex() >= records.len) return null;
    return records[ty.recordIndex()].shape.resource;
}
/// Check whether a type has the byte-array representation required by provider requests.
pub fn byteRequest(ty: Type, records: []const Record) bool {
    if (!ty.isAggregate() or ty.recordIndex() >= records.len) return false;
    const array = records[ty.recordIndex()].shape.array orelse return false;
    return array.element == .u8 and array.key == null;
}
/// Acquisition accepts an ordinary fixed byte array without an enum key.
pub fn acquisitionBytes(ty: Type, records: []const Record) bool {
    return byteRequest(ty, records);
}
/// Result schema and fields needed to preserve a resource on failed completion.
pub const CompletionShape = struct { result: ResultShape, resource_type: Type, resource_field: usize, code_field: usize };
/// Recognize the resource-preserving completion result layout.
pub fn completionShape(ty: Type, records: []const Record) ?CompletionShape {
    const result = resultShape(ty, records) orelse return null;
    if (result.ok_type != .bool or !result.error_type.isAggregate() or result.error_type.recordIndex() >= records.len) return null;
    const schema = records[result.error_type.recordIndex()];
    const slots = providerFields(schema, records, .completion) orelse return null;
    return .{ .result = result, .resource_type = schema.fields[slots[0]].ty, .resource_field = slots[0], .code_field = slots[1] };
}

/// Result payload layout containing bytes, a length, and a status flag.
pub const ByteResultShape = struct { result: ResultShape, bytes_type: Type, bytes_field: usize, length_field: usize, flag_field: usize };
/// Recognize the required environment lookup result layout.
pub fn environmentShape(ty: Type, records: []const Record) ?ByteResultShape {
    return byteResultShape(ty, records, .environment);
}
/// Recognize the required fixed-buffer resource read result layout.
pub fn resourceReadShape(ty: Type, records: []const Record) ?ByteResultShape {
    return byteResultShape(ty, records, .read);
}
fn byteResultShape(ty: Type, records: []const Record, operation: provider_contracts.Operation) ?ByteResultShape {
    const result = resultShape(ty, records) orelse return null;
    if (result.error_type != .i64 or !result.ok_type.isAggregate() or result.ok_type.recordIndex() >= records.len) return null;
    const schema = records[result.ok_type.recordIndex()];
    const slots = providerFields(schema, records, operation) orelse return null;
    return .{ .result = result, .bytes_type = schema.fields[slots[0]].ty, .bytes_field = slots[0], .length_field = slots[1], .flag_field = slots[2] };
}

fn providerFields(schema: Record, records: []const Record, operation: provider_contracts.Operation) ?[3]usize {
    const required = provider_contracts.fields(operation);
    if (!schema.isRecord() or schema.fields.len != required.len) return null;
    var slots: [3]usize = @splat(0);
    for (required, 0..) |rule, slot| {
        var found = false;
        for (schema.fields, 0..) |field, index| {
            if (!std.mem.eql(u8, field.name, rule.name)) continue;
            const matches = switch (rule.requirement) {
                .i64 => field.ty == .i64,
                .u64 => field.ty == .u64,
                .boolean => field.ty == .bool,
                .bytes => byteRequest(field.ty, records),
                .resource => resourceKind(field.ty, records) != null,
            };
            if (!matches) return null;
            slots[slot] = index;
            found = true;
        }
        if (!found) return null;
    }
    return slots;
}
