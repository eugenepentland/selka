<entry_run>:
 1012680:	push   %rbp
 1012681:	mov    %rsp,%rbp
 1012684:	push   %r15
 1012686:	push   %r14
 1012688:	push   %r13
 101268a:	push   %r12
 101268c:	push   %rbx
 101268d:	sub    $0x408,%rsp
 1012694:	mov    %rdi,%r9
 1012697:	cmpq   $0x0,0x39a8(%rdi)
 101269f:	mov    %rdi,-0x30(%rbp)
 10126a3:	je     10126b5 <entry_run+0x35>
 10126a5:	cmpq   $0x0,0x20(%r9)
 10126aa:	jne    10144b0 <entry_run+0x1e30>
 10126b0:	jmp    10127cd <entry_run+0x14d>
 10126b5:	mov    $0x1,%edi
 10126ba:	mov    $0x40,%esi
 10126bf:	call   1027690 <calloc@plt>
 10126c4:	test   %rax,%rax
 10126c7:	je     1012798 <entry_run+0x118>
 10126cd:	mov    -0x30(%rbp),%r9
 10126d1:	mov    %rax,0x39a8(%r9)
 10126d8:	mov    0x3978(%r9),%rcx
 10126df:	lea    0xa0(%rcx),%rdx
 10126e6:	test   %rcx,%rcx
 10126e9:	mov    $0x1003b58,%ecx
 10126ee:	cmovne %rdx,%rcx
 10126f2:	mov    %rcx,(%rax)
 10126f5:	cmpq   $0x0,0x8(%rcx)
 10126fa:	je     1012706 <entry_run+0x86>
 10126fc:	cmpq   $0x0,(%rcx)
 1012700:	je     10127a3 <entry_run+0x123>
 1012706:	mov    0x10(%rcx),%rdx
 101270a:	test   %rdx,%rdx
 101270d:	mov    $0x2710,%esi
 1012712:	cmovne %rdx,%rsi
 1012716:	mov    %rsi,0x18(%rax)
 101271a:	mov    0x18(%rcx),%rdx
 101271e:	test   %rdx,%rdx
 1012721:	mov    $0xf4240,%esi
 1012726:	cmovne %rdx,%rsi
 101272a:	mov    %rsi,0x10(%rax)
 101272e:	mov    0x20(%rcx),%rdx
 1012732:	test   %rdx,%rdx
 1012735:	mov    $0x10000,%edi
 101273a:	cmovne %rdx,%rdi
 101273e:	mov    %rdi,0x20(%rax)
 1012742:	mov    0x28(%rcx),%rsi
 1012746:	test   %rsi,%rsi
 1012749:	mov    $0x40,%edx
 101274e:	cmovne %rsi,%rdx
 1012752:	mov    %rdx,0x28(%rax)
 1012756:	mov    0x30(%rcx),%r8
 101275a:	test   %r8,%r8
 101275d:	mov    $0x100000,%esi
 1012762:	cmovne %r8,%rsi
 1012766:	mov    %rsi,0x30(%rax)
 101276a:	cmp    $0x186a0,%rdi
 1012771:	ja     1012791 <entry_run+0x111>
 1012773:	cmp    $0x81,%rdx
 101277a:	setae  %dl
 101277d:	cmp    $0x4000001,%rsi
 1012784:	setae  %sil
 1012788:	or     %dl,%sil
 101278b:	cmp    $0x1,%sil
 101278f:	jne    10127aa <entry_run+0x12a>
 1012791:	mov    $0x1003cfa,%esi
 1012796:	jmp    10127ba <entry_run+0x13a>
 1012798:	mov    $0x1003b92,%esi
 101279d:	mov    -0x30(%rbp),%r9
 10127a1:	jmp    10127ba <entry_run+0x13a>
 10127a3:	mov    $0x1003e55,%esi
 10127a8:	jmp    10127ba <entry_run+0x13a>
 10127aa:	cmpq   $0x0,0x8(%rcx)
 10127af:	je     1013177 <entry_run+0xaf7>
 10127b5:	mov    $0x1003e41,%esi
 10127ba:	mov    %r9,%rdi
 10127bd:	call   1014ab0 <fail>
 10127c2:	cmpq   $0x0,0x20(%r9)
 10127c7:	jne    10144b0 <entry_run+0x1e30>
 10127cd:	cmp    %rsp,0x40(%r9)
 10127d1:	ja     10145ce <entry_run+0x1f4e>
 10127d7:	movq   $0x0,-0x48(%rbp)
 10127df:	movq   $0x0,-0x80(%rbp)
 10127e7:	mov    0x2c8(%r9),%ebx
 10127ee:	movl   $0x0,-0x50(%rbp)
 10127f5:	cmpq   $0xffffffffffffffff,0x10(%r9)
 10127fa:	je     101283c <entry_run+0x1bc>
 10127fc:	cmpq   $0x0,0x20(%r9)
 1012801:	jne    101282f <entry_run+0x1af>
 1012803:	movl   $0x1,0x39e8(%r9)
 101280e:	vxorpd %xmm0,%xmm0,%xmm0
 1012812:	vmovupd %ymm0,0x39ec(%r9)
 101281b:	vmovupd %ymm0,0x39f8(%r9)
 1012824:	movq   $0x1003f61,0x3a18(%r9)
 101282f:	mov    $0x100442d,%esi
 1012834:	mov    %r9,%rdi
 1012837:	call   1014ab0 <fail>
 101283c:	cmpq   $0xffffffffffffffff,0x38(%r9)
 1012841:	je     1012883 <entry_run+0x203>
 1012843:	cmpq   $0x0,0x20(%r9)
 1012848:	jne    1012876 <entry_run+0x1f6>
 101284a:	movl   $0x1,0x39e8(%r9)
 1012855:	vxorpd %xmm0,%xmm0,%xmm0
 1012859:	vmovupd %ymm0,0x39ec(%r9)
 1012862:	vmovupd %ymm0,0x39f8(%r9)
 101286b:	movq   $0x1003faa,0x3a18(%r9)
 1012876:	mov    $0x1004442,%esi
 101287b:	mov    %r9,%rdi
 101287e:	call   1014ab0 <fail>
 1012883:	cmpq   $0x0,0x1860(%r9)
 101288b:	je     10145c3 <entry_run+0x1f43>
 1012891:	lea    0x258(%r9),%rdi
 1012898:	mov    0x2c8(%r9),%ecx
 101289f:	mov    $0x10022c8,%esi
 10128a4:	mov    $0x6,%edx
 10128a9:	mov    %rdi,-0x38(%rbp)
 10128ad:	vzeroupper
 10128b0:	call   10178c0 <rc_list_new>
 10128b5:	mov    -0x30(%rbp),%r9
 10128b9:	test   %rax,%rax
 10128bc:	je     10145c3 <entry_run+0x1f43>
 10128c2:	movabs $0x5000000000000000,%rcx
 10128cc:	mov    %rax,-0x1c0(%rbp)
 10128d3:	mov    %rax,-0x58(%rbp)
 10128d7:	mov    -0x10(%rax),%rdx
 10128db:	lea    0x1(%rcx),%rsi
 10128df:	test   %rsi,%rdx
 10128e2:	je     1012a13 <entry_run+0x393>
 10128e8:	test   %rcx,%rdx
 10128eb:	je     10129eb <entry_run+0x36b>
 10128f1:	mov    0x1860(%r9),%rdi
 10128f8:	cmpq   $0x1a,0xa0(%rdi)
 1012900:	jb     10143f6 <entry_run+0x1d76>
 1012906:	mov    0x98(%rdi),%rax
 101290d:	cmpq   $0x1002338,0x190(%rax)
 1012918:	jne    10143f6 <entry_run+0x1d76>
 101291e:	mov    0x198(%rax),%r12
 1012925:	test   %r12,%r12
 1012928:	je     101440c <entry_run+0x1d8c>
 101292e:	mov    0x8(%r12),%r14
 1012933:	cmpl   $0x1,0x8(%r14)
 1012938:	jne    1012a20 <entry_run+0x3a0>
 101293e:	movq   $0x0,-0xf8(%rbp)
 1012949:	mov    0x1860(%r9),%rcx
 1012950:	test   %rcx,%rcx
 1012953:	je     10144f8 <entry_run+0x1e78>
 1012959:	mov    $0x3,%eax
 101295e:	cmp    0x2c8(%r9),%ebx
 1012965:	ja     1012aab <entry_run+0x42b>
 101296b:	mov    -0x58(%rbp),%rax
 101296f:	test   %rax,%rax
 1012972:	je     10129b9 <entry_run+0x339>
 1012974:	mov    -0x10(%rax),%rdx
 1012978:	test   $0x2,%dl
 101297b:	jne    10129b9 <entry_run+0x339>
 101297d:	movabs $0x4000000000000002,%rsi
 1012987:	add    $0xfffffffffffffffe,%rsi
 101298b:	test   %rsi,%rdx
 101298e:	sete   %sil
 1012992:	mov    %rdx,%rdi
 1012995:	shr    $0x28,%rdi
 1012999:	and    $0xfffff,%edi
 101299f:	cmp    %ebx,%edi
 10129a1:	setbe  %dil
 10129a5:	bt     $0x3c,%rdx
 10129aa:	jb     101433a <entry_run+0x1cba>
 10129b0:	or     %dil,%sil
 10129b3:	je     101433a <entry_run+0x1cba>
 10129b9:	mov    %rax,-0xf8(%rbp)
 10129c0:	movq   $0x0,-0x58(%rbp)
 10129c8:	cmpq   $0x0,0xc8(%rcx)
 10129d0:	je     10129df <entry_run+0x35f>
 10129d2:	mov    -0x38(%rbp),%rdi
 10129d6:	call   101be30 <myl_rc_drain>
 10129db:	mov    -0x30(%rbp),%r9
 10129df:	mov    -0xf8(%rbp),%rax
 10129e6:	jmp    1012b15 <entry_run+0x495>
 10129eb:	lea    -0x58(%rbp),%rcx
 10129ef:	lea    -0x1c0(%rbp),%rdx
 10129f6:	mov    %rdx,%rsi
 10129f9:	sub    %rcx,%rsi
 10129fc:	sub    %rdx,%rcx
 10129ff:	cmovb  %rsi,%rcx
 1012a03:	test   %rcx,%rcx
 1012a06:	je     10128f1 <entry_run+0x271>
 1012a0c:	mov    %rax,-0x1c0(%rbp)
 1012a13:	movq   $0x0,-0x58(%rbp)
 1012a1b:	jmp    1012b29 <entry_run+0x4a9>
 1012a20:	mov    0x1860(%r9),%rax
 1012a27:	cmpq   $0x0,0xc8(%rax)
 1012a2f:	je     1012abe <entry_run+0x43e>
 1012a35:	mov    %r14,-0xf8(%rbp)
 1012a3c:	lea    -0x260(%rbp),%rdx
 1012a43:	mov    %rdx,-0xf0(%rbp)
 1012a4a:	movq   $0x0,-0xe8(%rbp)
 1012a55:	mov    %ebx,-0xe0(%rbp)
 1012a5b:	movl   $0x0,-0xdc(%rbp)
 1012a65:	lea    -0x58(%rbp),%rcx
 1012a69:	mov    -0x38(%rbp),%rdi
 1012a6d:	mov    %r12,%rsi
 1012a70:	mov    %ebx,%r8d
 1012a73:	call   10237d0 <flat_transfer>
 1012a78:	test   %eax,%eax
 1012a7a:	jns    1012a93 <entry_run+0x413>
 1012a7c:	lea    -0xf8(%rbp),%rsi
 1012a83:	lea    -0x58(%rbp),%rcx
 1012a87:	mov    -0x38(%rbp),%rdi
 1012a8b:	mov    %r14,%rdx
 1012a8e:	call   101eb00 <transfer>
 1012a93:	test   %eax,%eax
 1012a95:	mov    -0x30(%rbp),%r9
 1012a99:	je     1012b0e <entry_run+0x48e>
 1012a9b:	mov    0x1860(%r9),%rcx
 1012aa2:	test   %rcx,%rcx
 1012aa5:	je     10144f8 <entry_run+0x1e78>
 1012aab:	xor    %edx,%edx
 1012aad:	cmpl   $0x0,0x124(%rcx)
 1012ab4:	jne    1012b21 <entry_run+0x4a1>
 1012ab6:	mov    %eax,0x124(%rcx)
 1012abc:	jmp    1012b21 <entry_run+0x4a1>
 1012abe:	lea    -0x1c0(%rbp),%rdx
 1012ac5:	lea    -0x58(%rbp),%rcx
 1012ac9:	mov    -0x38(%rbp),%rdi
 1012acd:	mov    %r12,%rsi
 1012ad0:	mov    %ebx,%r8d
 1012ad3:	call   10237d0 <flat_transfer>
 1012ad8:	test   %eax,%eax
 1012ada:	js     1012a35 <entry_run+0x3b5>
 1012ae0:	mov    -0x30(%rbp),%r9
 1012ae4:	je     1012b29 <entry_run+0x4a9>
 1012ae6:	mov    0x1860(%r9),%rcx
 1012aed:	test   %rcx,%rcx
 1012af0:	je     10144f8 <entry_run+0x1e78>
 1012af6:	cmpl   $0x0,0x124(%rcx)
 1012afd:	jne    101445c <entry_run+0x1ddc>
 1012b03:	mov    %eax,0x124(%rcx)
 1012b09:	jmp    101445c <entry_run+0x1ddc>
 1012b0e:	mov    -0x260(%rbp),%rax
 1012b15:	mov    %rax,-0x1c0(%rbp)
 1012b1c:	mov    $0x1,%edx
 1012b21:	test   %edx,%edx
 1012b23:	je     101445c <entry_run+0x1ddc>
 1012b29:	mov    %ebx,-0x40(%rbp)
 1012b2c:	movabs $0x6000000000000002,%rbx
 1012b36:	mov    -0x1c0(%rbp),%r12
 1012b3d:	mov    %r12,-0x48(%rbp)
 1012b41:	movl   $0x1,-0x50(%rbp)
 1012b48:	movq   $0x0,-0xf8(%rbp)
 1012b53:	movabs $0xc08f400000000000,%rax
 1012b5d:	mov    %rax,-0xf0(%rbp)
 1012b64:	vmovapd -0x111ac(%rip),%ymm0        # 10019c0 <__abi_tag+0x16c4>
 1012b6c:	vmovupd %ymm0,-0xe8(%rbp)
 1012b74:	movabs $0x3fe0000000000000,%rax
 1012b7e:	mov    %rax,-0xc8(%rbp)
 1012b85:	test   %r12,%r12
 1012b88:	je     1012bc9 <entry_run+0x549>
 1012b8a:	test   %rbx,-0x10(%r12)
 1012b8f:	jne    1012b99 <entry_run+0x519>
 1012b91:	cmpq   $0x2,-0x20(%r12)
 1012b97:	jb     1012bbc <entry_run+0x53c>
 1012b99:	lea    -0x48(%rbp),%rsi
 1012b9d:	lea    -0x50(%rbp),%rdx
 1012ba1:	mov    %r9,%rdi
 1012ba4:	vzeroupper
 1012ba7:	call   1014780 <myl_qbe_rc_unique_local>
 1012bac:	test   %eax,%eax
 1012bae:	je     10144b0 <entry_run+0x1e30>
 1012bb4:	mov    -0x48(%rbp),%r12
 1012bb8:	mov    -0x30(%rbp),%r9
 1012bbc:	mov    (%r12),%rdx
 1012bc0:	cmp    0x8(%r12),%rdx
 1012bc5:	jb     1012bd7 <entry_run+0x557>
 1012bc7:	jmp    1012bfb <entry_run+0x57b>
 1012bc9:	xor    %r12d,%r12d
 1012bcc:	mov    (%r12),%rdx
 1012bd0:	cmp    0x8(%r12),%rdx
 1012bd5:	jae    1012bfb <entry_run+0x57b>
 1012bd7:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012bdd:	je     1012bfb <entry_run+0x57b>
 1012bdf:	mov    0x20(%r12),%rax
 1012be4:	lea    -0xf8(%rbp),%rsi
 1012beb:	sub    %rax,%rsi
 1012bee:	imul   $0x38,%rdx,%rcx
 1012bf2:	cmp    %rcx,%rsi
 1012bf5:	jae    10130a7 <entry_run+0xa27>
 1012bfb:	lea    -0xf8(%rbp),%rcx
 1012c02:	mov    -0x38(%rbp),%rdi
 1012c06:	mov    %r12,%rsi
 1012c09:	vzeroupper
 1012c0c:	call   1017f20 <rc_list_insert_at>
 1012c11:	mov    -0x30(%rbp),%r9
 1012c15:	test   %eax,%eax
 1012c17:	je     10145d9 <entry_run+0x1f59>
 1012c1d:	vxorpd %xmm0,%xmm0,%xmm0
 1012c21:	vmovapd %xmm0,-0x380(%rbp)
 1012c29:	movabs $0xc008000000000000,%rax
 1012c33:	mov    %rax,-0x370(%rbp)
 1012c3a:	vmovapd -0x112e2(%rip),%ymm0        # 1001960 <__abi_tag+0x1664>
 1012c42:	vmovupd %ymm0,-0x368(%rbp)
 1012c4a:	test   %r12,%r12
 1012c4d:	je     1012c8e <entry_run+0x60e>
 1012c4f:	test   %rbx,-0x10(%r12)
 1012c54:	jne    1012c5e <entry_run+0x5de>
 1012c56:	cmpq   $0x2,-0x20(%r12)
 1012c5c:	jb     1012c81 <entry_run+0x601>
 1012c5e:	lea    -0x48(%rbp),%rsi
 1012c62:	lea    -0x50(%rbp),%rdx
 1012c66:	mov    %r9,%rdi
 1012c69:	vzeroupper
 1012c6c:	call   1014780 <myl_qbe_rc_unique_local>
 1012c71:	test   %eax,%eax
 1012c73:	je     10144b0 <entry_run+0x1e30>
 1012c79:	mov    -0x48(%rbp),%r12
 1012c7d:	mov    -0x30(%rbp),%r9
 1012c81:	mov    (%r12),%rdx
 1012c85:	cmp    0x8(%r12),%rdx
 1012c8a:	jb     1012c9c <entry_run+0x61c>
 1012c8c:	jmp    1012cc0 <entry_run+0x640>
 1012c8e:	xor    %r12d,%r12d
 1012c91:	mov    (%r12),%rdx
 1012c95:	cmp    0x8(%r12),%rdx
 1012c9a:	jae    1012cc0 <entry_run+0x640>
 1012c9c:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012ca2:	je     1012cc0 <entry_run+0x640>
 1012ca4:	mov    0x20(%r12),%rax
 1012ca9:	lea    -0x380(%rbp),%rsi
 1012cb0:	sub    %rax,%rsi
 1012cb3:	imul   $0x38,%rdx,%rcx
 1012cb7:	cmp    %rcx,%rsi
 1012cba:	jae    10130d3 <entry_run+0xa53>
 1012cc0:	lea    -0x380(%rbp),%rcx
 1012cc7:	mov    -0x38(%rbp),%rdi
 1012ccb:	mov    %r12,%rsi
 1012cce:	vzeroupper
 1012cd1:	call   1017f20 <rc_list_insert_at>
 1012cd6:	mov    -0x30(%rbp),%r9
 1012cda:	test   %eax,%eax
 1012cdc:	je     10145e1 <entry_run+0x1f61>
 1012ce2:	movabs $0xc010000000000000,%r15
 1012cec:	movabs $0xc000000000000000,%r13
 1012cf6:	mov    %r13,-0x340(%rbp)
 1012cfd:	movq   $0x0,-0x338(%rbp)
 1012d08:	mov    %r15,-0x330(%rbp)
 1012d0f:	vmovapd -0x113d7(%rip),%ymm0        # 1001940 <__abi_tag+0x1644>
 1012d17:	vmovupd %ymm0,-0x328(%rbp)
 1012d1f:	test   %r12,%r12
 1012d22:	je     1012d63 <entry_run+0x6e3>
 1012d24:	test   %rbx,-0x10(%r12)
 1012d29:	jne    1012d33 <entry_run+0x6b3>
 1012d2b:	cmpq   $0x2,-0x20(%r12)
 1012d31:	jb     1012d56 <entry_run+0x6d6>
 1012d33:	lea    -0x48(%rbp),%rsi
 1012d37:	lea    -0x50(%rbp),%rdx
 1012d3b:	mov    %r9,%rdi
 1012d3e:	vzeroupper
 1012d41:	call   1014780 <myl_qbe_rc_unique_local>
 1012d46:	test   %eax,%eax
 1012d48:	je     10144b0 <entry_run+0x1e30>
 1012d4e:	mov    -0x48(%rbp),%r12
 1012d52:	mov    -0x30(%rbp),%r9
 1012d56:	mov    (%r12),%rdx
 1012d5a:	cmp    0x8(%r12),%rdx
 1012d5f:	jb     1012d71 <entry_run+0x6f1>
 1012d61:	jmp    1012d95 <entry_run+0x715>
 1012d63:	xor    %r12d,%r12d
 1012d66:	mov    (%r12),%rdx
 1012d6a:	cmp    0x8(%r12),%rdx
 1012d6f:	jae    1012d95 <entry_run+0x715>
 1012d71:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012d77:	je     1012d95 <entry_run+0x715>
 1012d79:	mov    0x20(%r12),%rax
 1012d7e:	lea    -0x340(%rbp),%rsi
 1012d85:	sub    %rax,%rsi
 1012d88:	imul   $0x38,%rdx,%rcx
 1012d8c:	cmp    %rcx,%rsi
 1012d8f:	jae    10130ff <entry_run+0xa7f>
 1012d95:	lea    -0x340(%rbp),%rcx
 1012d9c:	mov    -0x38(%rbp),%rdi
 1012da0:	mov    %r12,%rsi
 1012da3:	vzeroupper
 1012da6:	call   1017f20 <rc_list_insert_at>
 1012dab:	mov    -0x30(%rbp),%r9
 1012daf:	test   %eax,%eax
 1012db1:	je     10145e9 <entry_run+0x1f69>
 1012db7:	movabs $0x4000000000000002,%rax
 1012dc1:	lea    -0x2(%rax),%r14
 1012dc5:	mov    %r14,-0x308(%rbp)
 1012dcc:	movq   $0x0,-0x300(%rbp)
 1012dd7:	mov    %r15,-0x2f8(%rbp)
 1012dde:	vmovapd -0x11446(%rip),%ymm0        # 10019a0 <__abi_tag+0x16a4>
 1012de6:	vmovupd %ymm0,-0x2f0(%rbp)
 1012dee:	test   %r12,%r12
 1012df1:	je     1012e3c <entry_run+0x7bc>
 1012df3:	test   %rbx,-0x10(%r12)
 1012df8:	movabs $0x4000000000000002,%r15
 1012e02:	jne    1012e0c <entry_run+0x78c>
 1012e04:	cmpq   $0x2,-0x20(%r12)
 1012e0a:	jb     1012e2f <entry_run+0x7af>
 1012e0c:	lea    -0x48(%rbp),%rsi
 1012e10:	lea    -0x50(%rbp),%rdx
 1012e14:	mov    %r9,%rdi
 1012e17:	vzeroupper
 1012e1a:	call   1014780 <myl_qbe_rc_unique_local>
 1012e1f:	test   %eax,%eax
 1012e21:	je     10144b0 <entry_run+0x1e30>
 1012e27:	mov    -0x48(%rbp),%r12
 1012e2b:	mov    -0x30(%rbp),%r9
 1012e2f:	mov    (%r12),%rdx
 1012e33:	cmp    0x8(%r12),%rdx
 1012e38:	jb     1012e54 <entry_run+0x7d4>
 1012e3a:	jmp    1012e78 <entry_run+0x7f8>
 1012e3c:	xor    %r12d,%r12d
 1012e3f:	movabs $0x4000000000000002,%r15
 1012e49:	mov    (%r12),%rdx
 1012e4d:	cmp    0x8(%r12),%rdx
 1012e52:	jae    1012e78 <entry_run+0x7f8>
 1012e54:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012e5a:	je     1012e78 <entry_run+0x7f8>
 1012e5c:	mov    0x20(%r12),%rax
 1012e61:	lea    -0x308(%rbp),%rsi
 1012e68:	sub    %rax,%rsi
 1012e6b:	imul   $0x38,%rdx,%rcx
 1012e6f:	cmp    %rcx,%rsi
 1012e72:	jae    101312b <entry_run+0xaab>
 1012e78:	lea    -0x308(%rbp),%rcx
 1012e7f:	mov    -0x38(%rbp),%rdi
 1012e83:	mov    %r12,%rsi
 1012e86:	vzeroupper
 1012e89:	call   1017f20 <rc_list_insert_at>
 1012e8e:	mov    -0x30(%rbp),%r9
 1012e92:	test   %eax,%eax
 1012e94:	je     10145f1 <entry_run+0x1f71>
 1012e9a:	movq   $0x0,-0x2d0(%rbp)
 1012ea5:	mov    %r14,-0x2c8(%rbp)
 1012eac:	movabs $0xc018000000000000,%rax
 1012eb6:	mov    %rax,-0x2c0(%rbp)
 1012ebd:	vmovapd -0x114e5(%rip),%ymm0        # 10019e0 <__abi_tag+0x16e4>
 1012ec5:	vmovupd %ymm0,-0x2b8(%rbp)
 1012ecd:	test   %r12,%r12
 1012ed0:	je     1012f11 <entry_run+0x891>
 1012ed2:	test   %rbx,-0x10(%r12)
 1012ed7:	jne    1012ee1 <entry_run+0x861>
 1012ed9:	cmpq   $0x2,-0x20(%r12)
 1012edf:	jb     1012f04 <entry_run+0x884>
 1012ee1:	lea    -0x48(%rbp),%rsi
 1012ee5:	lea    -0x50(%rbp),%rdx
 1012ee9:	mov    %r9,%rdi
 1012eec:	vzeroupper
 1012eef:	call   1014780 <myl_qbe_rc_unique_local>
 1012ef4:	test   %eax,%eax
 1012ef6:	je     10144b0 <entry_run+0x1e30>
 1012efc:	mov    -0x48(%rbp),%r12
 1012f00:	mov    -0x30(%rbp),%r9
 1012f04:	mov    (%r12),%rdx
 1012f08:	cmp    0x8(%r12),%rdx
 1012f0d:	jb     1012f1f <entry_run+0x89f>
 1012f0f:	jmp    1012f43 <entry_run+0x8c3>
 1012f11:	xor    %r12d,%r12d
 1012f14:	mov    (%r12),%rdx
 1012f18:	cmp    0x8(%r12),%rdx
 1012f1d:	jae    1012f43 <entry_run+0x8c3>
 1012f1f:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012f25:	je     1012f43 <entry_run+0x8c3>
 1012f27:	mov    0x20(%r12),%rax
 1012f2c:	lea    -0x2d0(%rbp),%rsi
 1012f33:	sub    %rax,%rsi
 1012f36:	imul   $0x38,%rdx,%rcx
 1012f3a:	cmp    %rcx,%rsi
 1012f3d:	jae    101318e <entry_run+0xb0e>
 1012f43:	lea    -0x2d0(%rbp),%rcx
 1012f4a:	mov    -0x38(%rbp),%rdi
 1012f4e:	mov    %r12,%rsi
 1012f51:	vzeroupper
 1012f54:	call   1017f20 <rc_list_insert_at>
 1012f59:	mov    -0x30(%rbp),%r9
 1012f5d:	test   %eax,%eax
 1012f5f:	je     10145f9 <entry_run+0x1f79>
 1012f65:	movabs $0xbff8000000000000,%rax
 1012f6f:	mov    %rax,-0x298(%rbp)
 1012f76:	movabs $0xbfe0000000000000,%rax
 1012f80:	mov    %rax,-0x290(%rbp)
 1012f87:	mov    %r13,-0x288(%rbp)
 1012f8e:	vmovapd -0x11616(%rip),%ymm0        # 1001980 <__abi_tag+0x1684>
 1012f96:	vmovupd %ymm0,-0x280(%rbp)
 1012f9e:	test   %r12,%r12
 1012fa1:	je     1012fe2 <entry_run+0x962>
 1012fa3:	test   %rbx,-0x10(%r12)
 1012fa8:	jne    1012fb2 <entry_run+0x932>
 1012faa:	cmpq   $0x2,-0x20(%r12)
 1012fb0:	jb     1012fd5 <entry_run+0x955>
 1012fb2:	lea    -0x48(%rbp),%rsi
 1012fb6:	lea    -0x50(%rbp),%rdx
 1012fba:	mov    %r9,%rdi
 1012fbd:	vzeroupper
 1012fc0:	call   1014780 <myl_qbe_rc_unique_local>
 1012fc5:	test   %eax,%eax
 1012fc7:	je     10144b0 <entry_run+0x1e30>
 1012fcd:	mov    -0x48(%rbp),%r12
 1012fd1:	mov    -0x30(%rbp),%r9
 1012fd5:	mov    (%r12),%rdx
 1012fd9:	cmp    0x8(%r12),%rdx
 1012fde:	jb     1012ff0 <entry_run+0x970>
 1012fe0:	jmp    1013014 <entry_run+0x994>
 1012fe2:	xor    %r12d,%r12d
 1012fe5:	mov    (%r12),%rdx
 1012fe9:	cmp    0x8(%r12),%rdx
 1012fee:	jae    1013014 <entry_run+0x994>
 1012ff0:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012ff6:	je     1013014 <entry_run+0x994>
 1012ff8:	mov    0x20(%r12),%rax
 1012ffd:	lea    -0x298(%rbp),%rsi
 1013004:	sub    %rax,%rsi
 1013007:	imul   $0x38,%rdx,%rcx
 101300b:	cmp    %rcx,%rsi
 101300e:	jae    10131ba <entry_run+0xb3a>
 1013014:	lea    -0x298(%rbp),%rcx
 101301b:	mov    -0x38(%rbp),%rdi
 101301f:	mov    %r12,%rsi
 1013022:	vzeroupper
 1013025:	call   1017f20 <rc_list_insert_at>
 101302a:	mov    -0x30(%rbp),%r9
 101302e:	test   %eax,%eax
 1013030:	mov    -0x40(%rbp),%r8d
 1013034:	je     1014601 <entry_run+0x1f81>
 101303a:	mov    %r12,-0x58(%rbp)
 101303e:	test   %r12,%r12
 1013041:	je     10131f2 <entry_run+0xb72>
 1013047:	mov    -0x10(%r12),%rax
 101304c:	test   %r15,%rax
 101304f:	je     1013157 <entry_run+0xad7>
 1013055:	test   %r14,%rax
 1013058:	je     1013211 <entry_run+0xb91>
 101305e:	lea    -0x1c0(%rbp),%rdx
 1013065:	lea    -0x58(%rbp),%rcx
 1013069:	mov    $0x1002338,%esi
 101306e:	mov    -0x38(%rbp),%rdi
 1013072:	vzeroupper
 1013075:	call   1023af0 <myl_rc_native_retain>
 101307a:	test   %eax,%eax
 101307c:	je     101430c <entry_run+0x1c8c>
 1013082:	mov    -0x1c0(%rbp),%rax
 1013089:	mov    %rax,-0x80(%rbp)
 101308d:	cmpl   $0x0,-0x50(%rbp)
 1013091:	mov    -0x30(%rbp),%r9
 1013095:	je     1013258 <entry_run+0xbd8>
 101309b:	movl   $0x0,-0x50(%rbp)
 10130a2:	jmp    101322e <entry_run+0xbae>
 10130a7:	vmovupd -0xf8(%rbp),%ymm0
 10130af:	vmovupd -0xe0(%rbp),%ymm1
 10130b7:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10130bd:	vmovupd %ymm0,(%rax,%rcx,1)
 10130c2:	inc    %rdx
 10130c5:	mov    %rdx,(%r12)
 10130c9:	incq   0x10(%r12)
 10130ce:	jmp    1012c1d <entry_run+0x59d>
 10130d3:	vmovupd -0x380(%rbp),%ymm0
 10130db:	vmovupd -0x368(%rbp),%ymm1
 10130e3:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10130e9:	vmovupd %ymm0,(%rax,%rcx,1)
 10130ee:	inc    %rdx
 10130f1:	mov    %rdx,(%r12)
 10130f5:	incq   0x10(%r12)
 10130fa:	jmp    1012ce2 <entry_run+0x662>
 10130ff:	vmovupd -0x340(%rbp),%ymm0
 1013107:	vmovupd -0x328(%rbp),%ymm1
 101310f:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1013115:	vmovupd %ymm0,(%rax,%rcx,1)
 101311a:	inc    %rdx
 101311d:	mov    %rdx,(%r12)
 1013121:	incq   0x10(%r12)
 1013126:	jmp    1012db7 <entry_run+0x737>
 101312b:	vmovupd -0x308(%rbp),%ymm0
 1013133:	vmovupd -0x2f0(%rbp),%ymm1
 101313b:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1013141:	vmovupd %ymm0,(%rax,%rcx,1)
 1013146:	inc    %rdx
 1013149:	mov    %rdx,(%r12)
 101314d:	incq   0x10(%r12)
 1013152:	jmp    1012e9a <entry_run+0x81a>
 1013157:	mov    -0x20(%r12),%rax
 101315c:	inc    %rax
 101315f:	jne    101320c <entry_run+0xb8c>
 1013165:	mov    $0x100432e,%esi
 101316a:	mov    %r9,%rdi
 101316d:	call   1014ab0 <fail>
 1013172:	jmp    10144b0 <entry_run+0x1e30>
 1013177:	movl   $0x1,0x38(%rax)
 101317e:	cmpq   $0x0,0x20(%r9)
 1013183:	jne    10144b0 <entry_run+0x1e30>
 1013189:	jmp    10127cd <entry_run+0x14d>
 101318e:	vmovupd -0x2d0(%rbp),%ymm0
 1013196:	vmovupd -0x2b8(%rbp),%ymm1
 101319e:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10131a4:	vmovupd %ymm0,(%rax,%rcx,1)
 10131a9:	inc    %rdx
 10131ac:	mov    %rdx,(%r12)
 10131b0:	incq   0x10(%r12)
 10131b5:	jmp    1012f65 <entry_run+0x8e5>
 10131ba:	vmovupd -0x298(%rbp),%ymm0
 10131c2:	vmovupd -0x280(%rbp),%ymm1
 10131ca:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10131d0:	vmovupd %ymm0,(%rax,%rcx,1)
 10131d5:	inc    %rdx
 10131d8:	mov    %rdx,(%r12)
 10131dc:	incq   0x10(%r12)
 10131e1:	mov    -0x40(%rbp),%r8d
 10131e5:	mov    %r12,-0x58(%rbp)
 10131e9:	test   %r12,%r12
 10131ec:	jne    1013047 <entry_run+0x9c7>
 10131f2:	mov    %r12,-0x1c0(%rbp)
 10131f9:	mov    %r12,-0x80(%rbp)
 10131fd:	mov    -0x50(%rbp),%eax
 1013200:	xor    %ecx,%ecx
 1013202:	test   %eax,%eax
 1013204:	cmove  %eax,%ecx
 1013207:	mov    %ecx,-0x50(%rbp)
 101320a:	jmp    1013258 <entry_run+0xbd8>
 101320c:	mov    %rax,-0x20(%r12)
 1013211:	mov    %r12,-0x1c0(%rbp)
 1013218:	mov    %r12,-0x80(%rbp)
 101321c:	cmpl   $0x0,-0x50(%rbp)
 1013220:	je     1013258 <entry_run+0xbd8>
 1013222:	movl   $0x0,-0x50(%rbp)
 1013229:	test   %r12,%r12
 101322c:	je     1013258 <entry_run+0xbd8>
 101322e:	test   %r15,-0x10(%r12)
 1013233:	jne    1013250 <entry_run+0xbd0>
 1013235:	mov    -0x20(%r12),%rax
 101323a:	dec    %rax
 101323d:	jne    101324b <entry_run+0xbcb>
 101323f:	cmpq   $0x0,-0x18(%r12)
 1013245:	je     10143dd <entry_run+0x1d5d>
 101324b:	mov    %rax,-0x20(%r12)
 1013250:	movq   $0x0,-0x48(%rbp)
 1013258:	movabs $0x3ff0000000000000,%rax
 1013262:	mov    %rax,-0x158(%rbp)
 1013269:	mov    %rax,-0x150(%rbp)
 1013270:	mov    %rax,-0x148(%rbp)
 1013277:	cmp    %rsp,0x40(%r9)
 101327b:	ja     1014609 <entry_run+0x1f89>
 1013281:	vmovsd -0x158(%rbp),%xmm2
 1013289:	vmovsd -0x150(%rbp),%xmm3
 1013291:	vmulsd %xmm2,%xmm2,%xmm0
 1013295:	vmulsd %xmm3,%xmm3,%xmm1
 1013299:	vaddsd %xmm1,%xmm0,%xmm0
 101329d:	vmovsd -0x148(%rbp),%xmm4
 10132a5:	vmulsd %xmm4,%xmm4,%xmm1
 10132a9:	vaddsd %xmm1,%xmm0,%xmm0
 10132ad:	vxorpd %xmm5,%xmm5,%xmm5
 10132b1:	vucomisd %xmm5,%xmm0
 10132b5:	jb     10132bd <entry_run+0xc3d>
 10132b7:	vsqrtsd %xmm0,%xmm0,%xmm0
 10132bb:	jmp    10132eb <entry_run+0xc6b>
 10132bd:	vmovsd %xmm2,-0x40(%rbp)
 10132c2:	vmovsd %xmm3,-0x70(%rbp)
 10132c7:	vmovsd %xmm4,-0x78(%rbp)
 10132cc:	vzeroupper
 10132cf:	call   10277d0 <sqrt@plt>
 10132d4:	vmovsd -0x78(%rbp),%xmm4
 10132d9:	vmovsd -0x70(%rbp),%xmm3
 10132de:	vmovsd -0x40(%rbp),%xmm2
 10132e3:	vxorpd %xmm5,%xmm5,%xmm5
 10132e7:	mov    -0x30(%rbp),%r9
 10132eb:	vmovsd -0x118d3(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 10132f3:	vdivsd %xmm0,%xmm1,%xmm0
 10132f7:	vmulsd %xmm0,%xmm2,%xmm1
 10132fb:	vmulsd %xmm0,%xmm3,%xmm2
 10132ff:	vmulsd %xmm0,%xmm4,%xmm0
 1013303:	vmovsd %xmm1,-0xa8(%rbp)
 101330b:	vmovsd %xmm2,-0xa0(%rbp)
 1013313:	vmovsd %xmm0,-0x98(%rbp)
 101331b:	vxorpd %xmm0,%xmm0,%xmm0
 101331f:	vmovapd %xmm0,-0x110(%rbp)
 1013327:	movq   $0x0,-0x100(%rbp)
 1013332:	xor    %r13d,%r13d
 1013335:	mov    $0x3f,%r14b
 1013338:	movabs $0x7fefffffffffffff,%rbx
 1013342:	vmovsd -0x118ea(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101334a:	xor    %eax,%eax
 101334c:	jmp    1013366 <entry_run+0xce6>
 101334e:	xchg   %ax,%ax
 1013350:	mov    -0x118(%rbp),%rax
 1013357:	inc    %rax
 101335a:	cmp    $0x438,%rax
 1013360:	je     1013f1c <entry_run+0x189c>
 1013366:	mov    %rax,-0x118(%rbp)
 101336d:	vcvtsi2sd %rax,%xmm15,%xmm0
 1013372:	vaddsd -0x1193a(%rip),%xmm0,%xmm0        # 1001a40 <__abi_tag+0x1744>
 101337a:	vaddsd %xmm0,%xmm0,%xmm0
 101337e:	vdivsd -0x11976(%rip),%xmm0,%xmm0        # 1001a10 <__abi_tag+0x1714>
 1013386:	vaddsd -0x1196e(%rip),%xmm0,%xmm0        # 1001a20 <__abi_tag+0x1724>
 101338e:	vmovsd %xmm0,-0x120(%rbp)
 1013396:	xor    %ecx,%ecx
 1013398:	nopl   0x0(%rax,%rax,1)
 10133a0:	vcvtsi2sd %rcx,%xmm15,%xmm0
 10133a5:	vaddsd -0x1196d(%rip),%xmm0,%xmm0        # 1001a40 <__abi_tag+0x1744>
 10133ad:	vaddsd %xmm0,%xmm0,%xmm0
 10133b1:	vdivsd -0x11961(%rip),%xmm0,%xmm0        # 1001a58 <__abi_tag+0x175c>
 10133b9:	vaddsd -0x119c1(%rip),%xmm0,%xmm0        # 1001a00 <__abi_tag+0x1704>
 10133c1:	vmulsd -0x11999(%rip),%xmm0,%xmm0        # 1001a30 <__abi_tag+0x1734>
 10133c9:	vmovsd %xmm0,-0x140(%rbp)
 10133d1:	vmovsd -0x120(%rbp),%xmm0
 10133d9:	vmovsd %xmm0,-0x138(%rbp)
 10133e1:	movabs $0xbff8000000000000,%rax
 10133eb:	mov    %rax,-0x130(%rbp)
 10133f2:	cmp    %rsp,0x40(%r9)
 10133f6:	ja     1014502 <entry_run+0x1e82>
 10133fc:	vmovsd -0x140(%rbp),%xmm2
 1013404:	vmovsd -0x138(%rbp),%xmm3
 101340c:	vmulsd %xmm2,%xmm2,%xmm0
 1013410:	vmulsd %xmm3,%xmm3,%xmm1
 1013414:	vaddsd %xmm1,%xmm0,%xmm0
 1013418:	vmovsd -0x130(%rbp),%xmm4
 1013420:	vmulsd %xmm4,%xmm4,%xmm1
 1013424:	vaddsd %xmm1,%xmm0,%xmm0
 1013428:	vucomisd %xmm5,%xmm0
 101342c:	mov    %rcx,-0x128(%rbp)
 1013433:	jb     1013440 <entry_run+0xdc0>
 1013435:	vsqrtsd %xmm0,%xmm0,%xmm0
 1013439:	jmp    1013476 <entry_run+0xdf6>
 101343b:	nopl   0x0(%rax,%rax,1)
 1013440:	vmovsd %xmm2,-0x40(%rbp)
 1013445:	vmovsd %xmm3,-0x70(%rbp)
 101344a:	vmovsd %xmm4,-0x78(%rbp)
 101344f:	vzeroupper
 1013452:	call   10277d0 <sqrt@plt>
 1013457:	vmovsd -0x78(%rbp),%xmm4
 101345c:	vmovsd -0x70(%rbp),%xmm3
 1013461:	vmovsd -0x40(%rbp),%xmm2
 1013466:	vmovsd -0x11a0e(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101346e:	vxorpd %xmm5,%xmm5,%xmm5
 1013472:	mov    -0x30(%rbp),%r9
 1013476:	vmovsd -0x11a5e(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 101347e:	vdivsd %xmm0,%xmm1,%xmm0
 1013482:	vmulsd %xmm0,%xmm2,%xmm1
 1013486:	vmulsd %xmm0,%xmm3,%xmm2
 101348a:	vmulsd %xmm0,%xmm4,%xmm0
 101348e:	vmovsd %xmm1,-0xc0(%rbp)
 1013496:	vmovsd %xmm2,-0xb8(%rbp)
 101349e:	vmovsd %xmm0,-0xb0(%rbp)
 10134a6:	mov    -0x80(%rbp),%r12
 10134aa:	movq   $0x0,-0x410(%rbp)
 10134b5:	movq   $0x0,-0x3f0(%rbp)
 10134c0:	movq   $0x0,-0x3d0(%rbp)
 10134cb:	cmp    %rsp,0x40(%r9)
 10134cf:	ja     101450d <entry_run+0x1e8d>
 10134d5:	test   %r15,-0x10(%r12)
 10134da:	je     1013820 <entry_run+0x11a0>
 10134e0:	mov    %r13,-0x90(%rbp)
 10134e7:	mov    (%r12),%r13
 10134eb:	test   %r13,%r13
 10134ee:	js     101458b <entry_run+0x1f0b>
 10134f4:	je     10137d0 <entry_run+0x1150>
 10134fa:	mov    $0xffffffffffffffff,%r14
 1013501:	mov    $0x18,%r15d
 1013507:	xor    %ebx,%ebx
 1013509:	movabs $0xbff0000000000000,%rax
 1013513:	mov    %rax,-0x88(%rbp)
 101351a:	nopw   0x0(%rax,%rax,1)
 1013520:	cmp    %rsp,0x40(%r9)
 1013524:	ja     10144ed <entry_run+0x1e6d>
 101352a:	mov    0x20(%r12),%rax
 101352f:	vmovsd -0x110(%rbp),%xmm7
 1013537:	vmovsd -0x108(%rbp),%xmm0
 101353f:	vsubsd -0x18(%r15,%rax,1),%xmm7,%xmm1
 1013546:	vsubsd -0x10(%r15,%rax,1),%xmm0,%xmm0
 101354d:	vmovsd -0x100(%rbp),%xmm2
 1013555:	vsubsd -0x8(%r15,%rax,1),%xmm2,%xmm2
 101355c:	vmovsd %xmm1,-0x260(%rbp)
 1013564:	vmovsd %xmm0,-0x258(%rbp)
 101356c:	vmovsd %xmm2,-0x250(%rbp)
 1013574:	vmovsd -0xc0(%rbp),%xmm8
 101357c:	vmulsd %xmm1,%xmm8,%xmm3
 1013580:	vmulsd -0xb8(%rbp),%xmm0,%xmm4
 1013588:	vaddsd %xmm4,%xmm3,%xmm3
 101358c:	vmulsd -0xb0(%rbp),%xmm2,%xmm4
 1013594:	vaddsd %xmm4,%xmm3,%xmm3
 1013598:	vmulsd %xmm1,%xmm1,%xmm1
 101359c:	vmulsd %xmm0,%xmm0,%xmm0
 10135a0:	vaddsd %xmm0,%xmm1,%xmm0
 10135a4:	vmulsd %xmm2,%xmm2,%xmm1
 10135a8:	vaddsd %xmm1,%xmm0,%xmm0
 10135ac:	vmovsd (%r15,%rax,1),%xmm1
 10135b2:	vmulsd %xmm1,%xmm1,%xmm1
 10135b6:	vsubsd %xmm0,%xmm1,%xmm0
 10135ba:	vmulsd %xmm3,%xmm3,%xmm1
 10135be:	vaddsd %xmm0,%xmm1,%xmm0
 10135c2:	vucomisd %xmm0,%xmm5
 10135c6:	ja     1013680 <entry_run+0x1000>
 10135cc:	vucomisd %xmm5,%xmm0
 10135d0:	jb     10135f0 <entry_run+0xf70>
 10135d2:	vsqrtsd %xmm0,%xmm0,%xmm0
 10135d6:	vsubsd %xmm3,%xmm5,%xmm2
 10135da:	vsubsd %xmm0,%xmm2,%xmm1
 10135de:	vucomisd %xmm6,%xmm1
 10135e2:	jbe    1013634 <entry_run+0xfb4>
 10135e4:	jmp    101363e <entry_run+0xfbe>
 10135e6:	cs nopw 0x0(%rax,%rax,1)
 10135f0:	vmovsd %xmm7,-0x40(%rbp)
 10135f5:	vmovsd %xmm8,-0x70(%rbp)
 10135fa:	vmovsd %xmm3,-0x78(%rbp)
 10135ff:	vzeroupper
 1013602:	call   10277d0 <sqrt@plt>
 1013607:	vmovsd -0x78(%rbp),%xmm3
 101360c:	vmovsd -0x70(%rbp),%xmm8
 1013611:	vmovsd -0x40(%rbp),%xmm7
 1013616:	vmovsd -0x11bbe(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101361e:	vxorpd %xmm5,%xmm5,%xmm5
 1013622:	mov    -0x30(%rbp),%r9
 1013626:	vsubsd %xmm3,%xmm5,%xmm2
 101362a:	vsubsd %xmm0,%xmm2,%xmm1
 101362e:	vucomisd %xmm6,%xmm1
 1013632:	ja     101363e <entry_run+0xfbe>
 1013634:	vaddsd %xmm0,%xmm2,%xmm1
 1013638:	vucomisd %xmm6,%xmm1
 101363c:	jbe    1013680 <entry_run+0x1000>
 101363e:	vucomisd %xmm5,%xmm1
 1013642:	jbe    1013680 <entry_run+0x1000>
 1013644:	test   %r14,%r14
 1013647:	setns  %al
 101364a:	mov    -0x88(%rbp),%rsi
 1013651:	vmovq  %rsi,%xmm0
 1013656:	vucomisd %xmm1,%xmm0
 101365a:	vmovq  %xmm1,%rcx
 101365f:	setbe  %dl
 1013662:	test   %dl,%al
 1013664:	cmove  %rcx,%rsi
 1013668:	mov    %rsi,-0x88(%rbp)
 101366f:	cmove  %rbx,%r14
 1013673:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013680:	cmp    %r13,(%r12)
 1013684:	jne    10144e2 <entry_run+0x1e62>
 101368a:	inc    %rbx
 101368d:	add    $0x38,%r15
 1013691:	cmp    %rbx,%r13
 1013694:	jne    1013520 <entry_run+0xea0>
 101369a:	test   %r14,%r14
 101369d:	movabs $0x4000000000000002,%r15
 10136a7:	js     10137d0 <entry_run+0x1150>
 10136ad:	cmp    %r13,%r14
 10136b0:	jae    1014599 <entry_run+0x1f19>
 10136b6:	mov    0x20(%r12),%rax
 10136bb:	imul   $0x38,%r14,%rcx
 10136bf:	vmovups 0x20(%rax,%rcx,1),%xmm0
 10136c5:	mov    0x30(%rax,%rcx,1),%rdx
 10136ca:	vmovups (%rax,%rcx,1),%ymm1
 10136cf:	vmovups %ymm1,-0x260(%rbp)
 10136d7:	mov    %rdx,-0x230(%rbp)
 10136de:	vmovaps %xmm0,-0x240(%rbp)
 10136e6:	vmovsd -0x88(%rbp),%xmm0
 10136ee:	vmulsd %xmm0,%xmm8,%xmm1
 10136f2:	vmulsd -0xb8(%rbp),%xmm0,%xmm2
 10136fa:	vmulsd -0xb0(%rbp),%xmm0,%xmm0
 1013702:	vmovsd %xmm1,-0x3b0(%rbp)
 101370a:	vmovsd %xmm2,-0x3a8(%rbp)
 1013712:	vmovsd %xmm0,-0x3a0(%rbp)
 101371a:	vaddsd %xmm1,%xmm7,%xmm1
 101371e:	vaddsd -0x108(%rbp),%xmm2,%xmm2
 1013726:	vaddsd -0x100(%rbp),%xmm0,%xmm0
 101372e:	vmovsd %xmm1,-0x170(%rbp)
 1013736:	vmovsd %xmm2,-0x168(%rbp)
 101373e:	vsubsd -0x260(%rbp),%xmm1,%xmm1
 1013746:	vsubsd -0x258(%rbp),%xmm2,%xmm2
 101374e:	vmovsd %xmm0,-0x160(%rbp)
 1013756:	vsubsd -0x250(%rbp),%xmm0,%xmm0
 101375e:	vmovsd %xmm1,-0x188(%rbp)
 1013766:	vmovsd %xmm2,-0x180(%rbp)
 101376e:	vmovsd %xmm0,-0x178(%rbp)
 1013776:	cmp    %rsp,0x40(%r9)
 101377a:	ja     10145aa <entry_run+0x1f2a>
 1013780:	vmovsd -0x188(%rbp),%xmm2
 1013788:	vmovsd -0x180(%rbp),%xmm3
 1013790:	vmulsd %xmm2,%xmm2,%xmm0
 1013794:	vmulsd %xmm3,%xmm3,%xmm1
 1013798:	vaddsd %xmm1,%xmm0,%xmm0
 101379c:	vmovsd -0x178(%rbp),%xmm4
 10137a4:	vmulsd %xmm4,%xmm4,%xmm1
 10137a8:	vaddsd %xmm1,%xmm0,%xmm0
 10137ac:	vucomisd %xmm5,%xmm0
 10137b0:	mov    -0x90(%rbp),%r13
 10137b7:	jb     1013862 <entry_run+0x11e2>
 10137bd:	vsqrtsd %xmm0,%xmm0,%xmm0
 10137c1:	jmp    1013898 <entry_run+0x1218>
 10137c6:	cs nopw 0x0(%rax,%rax,1)
 10137d0:	mov    -0x3f0(%rbp),%eax
 10137d6:	or     -0x410(%rbp),%eax
 10137dc:	or     -0x3d0(%rbp),%eax
 10137e2:	mov    -0x90(%rbp),%r13
 10137e9:	mov    $0x3f,%r14b
 10137ec:	movabs $0x7fefffffffffffff,%rbx
 10137f6:	je     1013a90 <entry_run+0x1410>
 10137fc:	mov    0x1860(%r9),%rax
 1013803:	test   %rax,%rax
 1013806:	je     1013a72 <entry_run+0x13f2>
 101380c:	mov    0xf8(%rax),%rsi
 1013813:	jmp    1013a74 <entry_run+0x13f4>
 1013818:	nopl   0x0(%rax,%rax,1)
 1013820:	mov    -0x18(%r12),%rax
 1013825:	inc    %rax
 1013828:	jne    1013844 <entry_run+0x11c4>
 101382a:	mov    $0x100432e,%esi
 101382f:	mov    %r9,%rdi
 1013832:	call   1014ab0 <fail>
 1013837:	vxorpd %xmm3,%xmm3,%xmm3
 101383b:	vxorpd %xmm2,%xmm2,%xmm2
 101383f:	jmp    1013c50 <entry_run+0x15d0>
 1013844:	mov    %rax,-0x18(%r12)
 1013849:	mov    %r13,-0x90(%rbp)
 1013850:	mov    (%r12),%r13
 1013854:	test   %r13,%r13
 1013857:	jns    10134f4 <entry_run+0xe74>
 101385d:	jmp    101458b <entry_run+0x1f0b>
 1013862:	vmovsd %xmm2,-0x40(%rbp)
 1013867:	vmovsd %xmm3,-0x70(%rbp)
 101386c:	vmovsd %xmm4,-0x78(%rbp)
 1013871:	vzeroupper
 1013874:	call   10277d0 <sqrt@plt>
 1013879:	vmovsd -0x78(%rbp),%xmm4
 101387e:	vmovsd -0x70(%rbp),%xmm3
 1013883:	vmovsd -0x40(%rbp),%xmm2
 1013888:	vmovsd -0x11e30(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013890:	vxorpd %xmm5,%xmm5,%xmm5
 1013894:	mov    -0x30(%rbp),%r9
 1013898:	vmovsd -0x11e80(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 10138a0:	vdivsd %xmm0,%xmm1,%xmm0
 10138a4:	vmulsd %xmm0,%xmm2,%xmm1
 10138a8:	vmulsd %xmm0,%xmm3,%xmm2
 10138ac:	vmulsd %xmm0,%xmm4,%xmm0
 10138b0:	vmovsd %xmm1,-0x398(%rbp)
 10138b8:	vmovsd %xmm2,-0x390(%rbp)
 10138c0:	vmovsd %xmm0,-0x388(%rbp)
 10138c8:	vmulsd -0xa8(%rbp),%xmm1,%xmm1
 10138d0:	vmulsd -0xa0(%rbp),%xmm2,%xmm2
 10138d8:	vaddsd %xmm2,%xmm1,%xmm1
 10138dc:	vmulsd -0x98(%rbp),%xmm0,%xmm0
 10138e4:	vaddsd %xmm0,%xmm1,%xmm7
 10138e8:	vxorpd %xmm0,%xmm0,%xmm0
 10138ec:	mov    $0x1,%bl
 10138ee:	vucomisd %xmm7,%xmm0
 10138f2:	jbe    10138fc <entry_run+0x127c>
 10138f4:	xor    %r14d,%r14d
 10138f7:	jmp    1013b60 <entry_run+0x14e0>
 10138fc:	vucomisd %xmm5,%xmm7
 1013900:	jbe    1013ad7 <entry_run+0x1457>
 1013906:	test   %r15,-0x10(%r12)
 101390b:	movabs $0x7fefffffffffffff,%rbx
 1013915:	je     1013ae3 <entry_run+0x1463>
 101391b:	mov    (%r12),%r14
 101391f:	test   %r14,%r14
 1013922:	js     10145b5 <entry_run+0x1f35>
 1013928:	je     1013b41 <entry_run+0x14c1>
 101392e:	mov    $0x18,%ebx
 1013933:	mov    %r14,%r15
 1013936:	vmovsd %xmm7,-0x70(%rbp)
 101393b:	nopl   0x0(%rax,%rax,1)
 1013940:	cmp    %rsp,0x40(%r9)
 1013944:	ja     1014575 <entry_run+0x1ef5>
 101394a:	mov    0x20(%r12),%rax
 101394f:	vmovsd -0x170(%rbp),%xmm0
 1013957:	vmovsd -0x168(%rbp),%xmm1
 101395f:	vsubsd -0x18(%rbx,%rax,1),%xmm0,%xmm0
 1013965:	vsubsd -0x10(%rbx,%rax,1),%xmm1,%xmm1
 101396b:	vmovsd -0x160(%rbp),%xmm2
 1013973:	vsubsd -0x8(%rbx,%rax,1),%xmm2,%xmm2
 1013979:	vmovsd %xmm0,-0x3c8(%rbp)
 1013981:	vmovsd %xmm1,-0x3c0(%rbp)
 1013989:	vmovsd %xmm2,-0x3b8(%rbp)
 1013991:	vmulsd -0xa8(%rbp),%xmm0,%xmm3
 1013999:	vmulsd -0xa0(%rbp),%xmm1,%xmm4
 10139a1:	vaddsd %xmm4,%xmm3,%xmm3
 10139a5:	vmulsd -0x98(%rbp),%xmm2,%xmm4
 10139ad:	vaddsd %xmm4,%xmm3,%xmm3
 10139b1:	vmulsd %xmm0,%xmm0,%xmm0
 10139b5:	vmulsd %xmm1,%xmm1,%xmm1
 10139b9:	vaddsd %xmm1,%xmm0,%xmm0
 10139bd:	vmulsd %xmm2,%xmm2,%xmm1
 10139c1:	vaddsd %xmm1,%xmm0,%xmm0
 10139c5:	vmovsd (%rbx,%rax,1),%xmm1
 10139ca:	vmulsd %xmm1,%xmm1,%xmm1
 10139ce:	vsubsd %xmm0,%xmm1,%xmm0
 10139d2:	vmulsd %xmm3,%xmm3,%xmm1
 10139d6:	vaddsd %xmm0,%xmm1,%xmm0
 10139da:	vucomisd %xmm0,%xmm5
 10139de:	ja     1013a4d <entry_run+0x13cd>
 10139e0:	vucomisd %xmm5,%xmm0
 10139e4:	jb     1013a00 <entry_run+0x1380>
 10139e6:	vsqrtsd %xmm0,%xmm0,%xmm0
 10139ea:	vsubsd %xmm3,%xmm5,%xmm2
 10139ee:	vsubsd %xmm0,%xmm2,%xmm1
 10139f2:	vucomisd %xmm6,%xmm1
 10139f6:	jbe    1013a35 <entry_run+0x13b5>
 10139f8:	jmp    1013a3f <entry_run+0x13bf>
 10139fa:	nopw   0x0(%rax,%rax,1)
 1013a00:	vmovsd %xmm3,-0x40(%rbp)
 1013a05:	vzeroupper
 1013a08:	call   10277d0 <sqrt@plt>
 1013a0d:	vmovsd -0x40(%rbp),%xmm3
 1013a12:	vmovsd -0x70(%rbp),%xmm7
 1013a17:	vmovsd -0x11fbf(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013a1f:	vxorpd %xmm5,%xmm5,%xmm5
 1013a23:	mov    -0x30(%rbp),%r9
 1013a27:	vsubsd %xmm3,%xmm5,%xmm2
 1013a2b:	vsubsd %xmm0,%xmm2,%xmm1
 1013a2f:	vucomisd %xmm6,%xmm1
 1013a33:	ja     1013a3f <entry_run+0x13bf>
 1013a35:	vaddsd %xmm0,%xmm2,%xmm1
 1013a39:	vucomisd %xmm6,%xmm1
 1013a3d:	jbe    1013a4d <entry_run+0x13cd>
 1013a3f:	vxorpd %xmm0,%xmm0,%xmm0
 1013a43:	vucomisd %xmm0,%xmm1
 1013a47:	ja     1013b4c <entry_run+0x14cc>
 1013a4d:	cmp    %r14,(%r12)
 1013a51:	jne    1014580 <entry_run+0x1f00>
 1013a57:	add    $0x38,%rbx
 1013a5b:	dec    %r15
 1013a5e:	jne    1013940 <entry_run+0x12c0>
 1013a64:	xor    %ebx,%ebx
 1013a66:	mov    %r12,%r14
 1013a69:	vmovapd %xmm7,%xmm0
 1013a6d:	jmp    1013b51 <entry_run+0x14d1>
 1013a72:	xor    %esi,%esi
 1013a74:	mov    -0x38(%rbp),%rdi
 1013a78:	vzeroupper
 1013a7b:	call   101e520 <myl_rc_scope_unwind>
 1013a80:	mov    -0x30(%rbp),%r9
 1013a84:	vxorpd %xmm5,%xmm5,%xmm5
 1013a88:	vmovsd -0x12030(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013a90:	vmovsd -0x12080(%rip),%xmm2        # 1001a18 <__abi_tag+0x171c>
 1013a98:	vmovapd -0x121b0(%rip),%xmm3        # 10018f0 <__abi_tag+0x15f4>
 1013aa0:	test   %r15,-0x10(%r12)
 1013aa5:	jne    1013c50 <entry_run+0x15d0>
 1013aab:	mov    -0x18(%r12),%rax
 1013ab0:	dec    %rax
 1013ab3:	jne    1013abd <entry_run+0x143d>
 1013ab5:	cmpq   $0x0,-0x20(%r12)
 1013abb:	je     1013b0b <entry_run+0x148b>
 1013abd:	mov    %rax,-0x18(%r12)
 1013ac2:	vmovsd -0x120b2(%rip),%xmm2        # 1001a18 <__abi_tag+0x171c>
 1013aca:	vmovapd -0x121e2(%rip),%xmm3        # 10018f0 <__abi_tag+0x15f4>
 1013ad2:	jmp    1013c50 <entry_run+0x15d0>
 1013ad7:	xor    %r14d,%r14d
 1013ada:	vmovapd %xmm7,%xmm0
 1013ade:	jmp    1013b60 <entry_run+0x14e0>
 1013ae3:	mov    -0x18(%r12),%rax
 1013ae8:	inc    %rax
 1013aeb:	mov    $0x3f,%r14b
 1013aee:	je     101382a <entry_run+0x11aa>
 1013af4:	mov    %rax,-0x18(%r12)
 1013af9:	mov    (%r12),%r14
 1013afd:	test   %r14,%r14
 1013b00:	jns    1013928 <entry_run+0x12a8>
 1013b06:	jmp    10145b5 <entry_run+0x1f35>
 1013b0b:	mov    -0x38(%rbp),%rbx
 1013b0f:	mov    %rbx,%rdi
 1013b12:	mov    %r12,%rsi
 1013b15:	vzeroupper
 1013b18:	call   1018e60 <myl_rc_hold_edge_release>
 1013b1d:	mov    %rbx,%rdi
 1013b20:	movabs $0x7fefffffffffffff,%rbx
 1013b2a:	call   101be30 <myl_rc_drain>
 1013b2f:	vmovsd -0x120d7(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013b37:	vxorpd %xmm5,%xmm5,%xmm5
 1013b3b:	mov    -0x30(%rbp),%r9
 1013b3f:	jmp    1013ac2 <entry_run+0x1442>
 1013b41:	xor    %ebx,%ebx
 1013b43:	mov    %r12,%r14
 1013b46:	vmovapd %xmm7,%xmm0
 1013b4a:	jmp    1013b60 <entry_run+0x14e0>
 1013b4c:	xor    %ebx,%ebx
 1013b4e:	mov    %r12,%r14
 1013b51:	movabs $0x4000000000000002,%r15
 1013b5b:	nopl   0x0(%rax,%rax,1)
 1013b60:	vmulsd -0x12120(%rip),%xmm0,%xmm0        # 1001a48 <__abi_tag+0x174c>
 1013b68:	vaddsd -0x12138(%rip),%xmm0,%xmm0        # 1001a38 <__abi_tag+0x173c>
 1013b70:	vmulsd -0x240(%rbp),%xmm0,%xmm2
 1013b78:	vmovddup %xmm0,%xmm0
 1013b7c:	vmulpd -0x238(%rbp),%xmm0,%xmm3
 1013b84:	mov    -0x3f0(%rbp),%eax
 1013b8a:	or     -0x410(%rbp),%eax
 1013b90:	or     -0x3d0(%rbp),%eax
 1013b96:	je     1013bdf <entry_run+0x155f>
 1013b98:	mov    0x1860(%r9),%rax
 1013b9f:	test   %rax,%rax
 1013ba2:	vmovsd %xmm2,-0x40(%rbp)
 1013ba7:	vmovapd %xmm3,-0x70(%rbp)
 1013bac:	je     1013bb7 <entry_run+0x1537>
 1013bae:	mov    0xf8(%rax),%rsi
 1013bb5:	jmp    1013bb9 <entry_run+0x1539>
 1013bb7:	xor    %esi,%esi
 1013bb9:	mov    -0x38(%rbp),%rdi
 1013bbd:	vzeroupper
 1013bc0:	call   101e520 <myl_rc_scope_unwind>
 1013bc5:	mov    -0x30(%rbp),%r9
 1013bc9:	vxorpd %xmm5,%xmm5,%xmm5
 1013bcd:	vmovsd -0x12175(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013bd5:	vmovsd -0x40(%rbp),%xmm2
 1013bda:	vmovapd -0x70(%rbp),%xmm3
 1013bdf:	test   %r14,%r14
 1013be2:	sete   %al
 1013be5:	or     %al,%bl
 1013be7:	movabs $0x7fefffffffffffff,%rbx
 1013bf1:	jne    1013bf9 <entry_run+0x1579>
 1013bf3:	test   %r15,-0x10(%r14)
 1013bf7:	je     1013c05 <entry_run+0x1585>
 1013bf9:	test   %r15,-0x10(%r12)
 1013bfe:	je     1013c24 <entry_run+0x15a4>
 1013c00:	mov    $0x3f,%r14b
 1013c03:	jmp    1013c50 <entry_run+0x15d0>
 1013c05:	mov    -0x18(%r14),%rax
 1013c09:	dec    %rax
 1013c0c:	jne    1013c19 <entry_run+0x1599>
 1013c0e:	cmpq   $0x0,-0x20(%r14)
 1013c13:	je     1013ec4 <entry_run+0x1844>
 1013c19:	mov    %rax,-0x18(%r14)
 1013c1d:	test   %r15,-0x10(%r12)
 1013c22:	jne    1013c00 <entry_run+0x1580>
 1013c24:	mov    -0x18(%r12),%rax
 1013c29:	dec    %rax
 1013c2c:	mov    $0x3f,%r14b
 1013c2f:	jne    1013c3d <entry_run+0x15bd>
 1013c31:	cmpq   $0x0,-0x20(%r12)
 1013c37:	je     1013e77 <entry_run+0x17f7>
 1013c3d:	mov    %rax,-0x18(%r12)
 1013c42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013c50:	vmovsd %xmm2,-0x1d8(%rbp)
 1013c58:	vmulsd -0x121f8(%rip),%xmm2,%xmm0        # 1001a68 <__abi_tag+0x176c>
 1013c60:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 1013c66:	vmovsd -0x1224e(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 1013c6e:	vcmpltsd %xmm2,%xmm1,%xmm1
 1013c73:	vblendvpd %xmm1,-0x1237d(%rip),%xmm0,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013c7d:	vmovupd %xmm3,-0x1d0(%rbp)
 1013c85:	vmovq  %xmm0,%rax
 1013c8a:	bzhi   %r14,%rax,%rax
 1013c8f:	cmp    %rbx,%rax
 1013c92:	jg     1013cc0 <entry_run+0x1640>
 1013c94:	vmovsd -0x1224c(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013c9c:	vucomisd %xmm0,%xmm1
 1013ca0:	ja     1013cc0 <entry_run+0x1640>
 1013ca2:	vucomisd -0x12282(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013caa:	jae    1013cc0 <entry_run+0x1640>
 1013cac:	vcvttsd2si %xmm0,%rdx
 1013cb1:	jmp    1013ccf <entry_run+0x164f>
 1013cb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013cc0:	mov    $0x10043c9,%esi
 1013cc5:	mov    %r9,%rdi
 1013cc8:	call   1014ab0 <fail>
 1013ccd:	xor    %edx,%edx
 1013ccf:	vmovsd -0x1d0(%rbp),%xmm0
 1013cd7:	vmulsd -0x12277(%rip),%xmm0,%xmm1        # 1001a68 <__abi_tag+0x176c>
 1013cdf:	vroundsd $0xb,%xmm1,%xmm1,%xmm1
 1013ce5:	vmovsd -0x122cd(%rip),%xmm2        # 1001a20 <__abi_tag+0x1724>
 1013ced:	vcmpltsd %xmm0,%xmm2,%xmm0
 1013cf2:	vblendvpd %xmm0,-0x123fc(%rip),%xmm1,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013cfc:	vmovq  %xmm0,%rax
 1013d01:	bzhi   %r14,%rax,%rax
 1013d06:	cmp    %rbx,%rax
 1013d09:	jg     1013d30 <entry_run+0x16b0>
 1013d0b:	vmovsd -0x122c3(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013d13:	vucomisd %xmm0,%xmm1
 1013d17:	ja     1013d30 <entry_run+0x16b0>
 1013d19:	vucomisd -0x122f9(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013d21:	jae    1013d30 <entry_run+0x16b0>
 1013d23:	vcvttsd2si %xmm0,%rax
 1013d28:	jmp    1013d3f <entry_run+0x16bf>
 1013d2a:	nopw   0x0(%rax,%rax,1)
 1013d30:	mov    $0x10043c9,%esi
 1013d35:	mov    %r9,%rdi
 1013d38:	call   1014ab0 <fail>
 1013d3d:	xor    %eax,%eax
 1013d3f:	vmovsd -0x1c8(%rbp),%xmm0
 1013d47:	vmulsd -0x122e7(%rip),%xmm0,%xmm1        # 1001a68 <__abi_tag+0x176c>
 1013d4f:	vroundsd $0xb,%xmm1,%xmm1,%xmm1
 1013d55:	vmovsd -0x1233d(%rip),%xmm2        # 1001a20 <__abi_tag+0x1724>
 1013d5d:	vcmpltsd %xmm0,%xmm2,%xmm0
 1013d62:	vblendvpd %xmm0,-0x1246c(%rip),%xmm1,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013d6c:	vmovq  %xmm0,%rcx
 1013d71:	bzhi   %r14,%rcx,%rcx
 1013d76:	cmp    %rbx,%rcx
 1013d79:	jg     1013da0 <entry_run+0x1720>
 1013d7b:	vmovsd -0x12333(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013d83:	vucomisd %xmm0,%xmm1
 1013d87:	ja     1013da0 <entry_run+0x1720>
 1013d89:	vucomisd -0x12369(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013d91:	jae    1013da0 <entry_run+0x1720>
 1013d93:	vcvttsd2si %xmm0,%rcx
 1013d98:	jmp    1013daf <entry_run+0x172f>
 1013d9a:	nopw   0x0(%rax,%rax,1)
 1013da0:	mov    $0x10043c9,%esi
 1013da5:	mov    %r9,%rdi
 1013da8:	call   1014ab0 <fail>
 1013dad:	xor    %ecx,%ecx
 1013daf:	movabs $0xffff800000000000,%rsi
 1013db9:	add    %rdx,%rsi
 1013dbc:	shr    $0x30,%rsi
 1013dc0:	cmp    $0xfffe,%esi
 1013dc6:	jbe    1014518 <entry_run+0x1e98>
 1013dcc:	movabs $0xff80000000000000,%rsi
 1013dd6:	add    %rax,%rsi
 1013dd9:	shr    $0x38,%rsi
 1013ddd:	cmp    $0xfe,%esi
 1013de3:	jbe    101452d <entry_run+0x1ead>
 1013de9:	shl    $0x10,%rdx
 1013ded:	shl    $0x8,%rax
 1013df1:	mov    %rdx,%r8
 1013df4:	add    %rax,%r8
 1013df7:	jo     1014545 <entry_run+0x1ec5>
 1013dfd:	mov    %r8,%rax
 1013e00:	add    %rcx,%rax
 1013e03:	jo     1014555 <entry_run+0x1ed5>
 1013e09:	mov    %r13,%rdx
 1013e0c:	shl    $0x5,%rdx
 1013e10:	sub    %r13,%rdx
 1013e13:	mov    %rdx,%rcx
 1013e16:	add    %rax,%rcx
 1013e19:	jo     1014565 <entry_run+0x1ee5>
 1013e1f:	mov    %rcx,%rax
 1013e22:	movabs $0x89705f3112a28fe5,%rdx
 1013e2c:	imul   %rdx
 1013e2f:	add    %rcx,%rdx
 1013e32:	mov    %rdx,%rax
 1013e35:	shr    $0x3f,%rax
 1013e39:	sar    $0x1d,%rdx
 1013e3d:	add    %rax,%rdx
 1013e40:	imul   $0x3b9aca07,%rdx,%rax
 1013e47:	sub    %rax,%rcx
 1013e4a:	mov    %rcx,%r13
 1013e4d:	sar    $0x3f,%r13
 1013e51:	and    $0x3b9aca07,%r13d
 1013e58:	add    %rcx,%r13
 1013e5b:	mov    -0x128(%rbp),%rcx
 1013e62:	inc    %rcx
 1013e65:	cmp    $0x780,%rcx
 1013e6c:	jne    10133a0 <entry_run+0xd20>
 1013e72:	jmp    1013350 <entry_run+0xcd0>
 1013e77:	mov    -0x38(%rbp),%rbx
 1013e7b:	mov    %rbx,%rdi
 1013e7e:	mov    %r12,%rsi
 1013e81:	vmovsd %xmm2,-0x40(%rbp)
 1013e86:	vmovapd %xmm3,-0x70(%rbp)
 1013e8b:	vzeroupper
 1013e8e:	call   1018e60 <myl_rc_hold_edge_release>
 1013e93:	mov    %rbx,%rdi
 1013e96:	movabs $0x7fefffffffffffff,%rbx
 1013ea0:	call   101be30 <myl_rc_drain>
 1013ea5:	vmovapd -0x70(%rbp),%xmm3
 1013eaa:	vmovsd -0x40(%rbp),%xmm2
 1013eaf:	vmovsd -0x12457(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013eb7:	vxorpd %xmm5,%xmm5,%xmm5
 1013ebb:	mov    -0x30(%rbp),%r9
 1013ebf:	jmp    1013c50 <entry_run+0x15d0>
 1013ec4:	mov    -0x38(%rbp),%rbx
 1013ec8:	mov    %rbx,%rdi
 1013ecb:	mov    %r14,%rsi
 1013ece:	vmovsd %xmm2,-0x40(%rbp)
 1013ed3:	vmovapd %xmm3,-0x70(%rbp)
 1013ed8:	vzeroupper
 1013edb:	call   1018e60 <myl_rc_hold_edge_release>
 1013ee0:	mov    %rbx,%rdi
 1013ee3:	movabs $0x7fefffffffffffff,%rbx
 1013eed:	call   101be30 <myl_rc_drain>
 1013ef2:	vmovapd -0x70(%rbp),%xmm3
 1013ef7:	vmovsd -0x40(%rbp),%xmm2
 1013efc:	vmovsd -0x124a4(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013f04:	vxorpd %xmm5,%xmm5,%xmm5
 1013f08:	mov    -0x30(%rbp),%r9
 1013f0c:	test   %r15,-0x10(%r12)
 1013f11:	jne    1013c00 <entry_run+0x1580>
 1013f17:	jmp    1013c24 <entry_run+0x15a4>
 1013f1c:	mov    $0x1,%edi
 1013f21:	mov    $0x20,%esi
 1013f26:	vzeroupper
 1013f29:	call   1027690 <calloc@plt>
 1013f2e:	mov    %rax,%r12
 1013f31:	test   %rax,%rax
 1013f34:	jne    1013f3f <entry_run+0x18bf>
 1013f36:	mov    -0x30(%rbp),%rdi
 1013f3a:	call   1015290 <myl_qbe_fail_allocation>
 1013f3f:	lea    -0x260(%rbp),%rdi
 1013f46:	mov    $0x18,%esi
 1013f4b:	mov    $0x10040e8,%edx
 1013f50:	mov    %r13,%rcx
 1013f53:	xor    %eax,%eax
 1013f55:	call   10277e0 <snprintf@plt>
 1013f5a:	test   %eax,%eax
 1013f5c:	jle    1014174 <entry_run+0x1af4>
 1013f62:	mov    %eax,%r13d
 1013f65:	mov    $0x40,%r15d
 1013f6b:	cmp    $0x41,%eax
 1013f6e:	jb     1014126 <entry_run+0x1aa6>
 1013f74:	mov    $0x80,%r15d
 1013f7a:	cmp    $0x81,%r13d
 1013f81:	jb     1014126 <entry_run+0x1aa6>
 1013f87:	mov    $0x100,%r15d
 1013f8d:	cmp    $0x101,%r13d
 1013f94:	jb     1014126 <entry_run+0x1aa6>
 1013f9a:	mov    $0x200,%r15d
 1013fa0:	cmp    $0x201,%r13d
 1013fa7:	jb     1014126 <entry_run+0x1aa6>
 1013fad:	mov    $0x400,%r15d
 1013fb3:	cmp    $0x401,%r13d
 1013fba:	jb     1014126 <entry_run+0x1aa6>
 1013fc0:	mov    $0x800,%r15d
 1013fc6:	cmp    $0x801,%r13d
 1013fcd:	jb     1014126 <entry_run+0x1aa6>
 1013fd3:	mov    $0x1000,%r15d
 1013fd9:	cmp    $0x1001,%r13d
 1013fe0:	jb     1014126 <entry_run+0x1aa6>
 1013fe6:	mov    $0x2000,%r15d
 1013fec:	cmp    $0x2001,%r13d
 1013ff3:	jb     1014126 <entry_run+0x1aa6>
 1013ff9:	mov    $0x4000,%r15d
 1013fff:	cmp    $0x4001,%r13d
 1014006:	jb     1014126 <entry_run+0x1aa6>
 101400c:	mov    $0x8000,%r15d
 1014012:	cmp    $0x8001,%r13d
 1014019:	jb     1014126 <entry_run+0x1aa6>
 101401f:	mov    $0x10000,%r15d
 1014025:	cmp    $0x10001,%r13d
 101402c:	jb     1014126 <entry_run+0x1aa6>
 1014032:	mov    $0x20000,%r15d
 1014038:	cmp    $0x20001,%r13d
 101403f:	jb     1014126 <entry_run+0x1aa6>
 1014045:	mov    $0x40000,%r15d
 101404b:	cmp    $0x40001,%r13d
 1014052:	jb     1014126 <entry_run+0x1aa6>
 1014058:	mov    $0x80000,%r15d
 101405e:	cmp    $0x80001,%r13d
 1014065:	jb     1014126 <entry_run+0x1aa6>
 101406b:	mov    $0x100000,%r15d
 1014071:	cmp    $0x100001,%r13d
 1014078:	jb     1014126 <entry_run+0x1aa6>
 101407e:	mov    $0x200000,%r15d
 1014084:	cmp    $0x200001,%r13d
 101408b:	jb     1014126 <entry_run+0x1aa6>
 1014091:	mov    $0x400000,%r15d
 1014097:	cmp    $0x400001,%r13d
 101409e:	jb     1014126 <entry_run+0x1aa6>
 10140a4:	mov    $0x800000,%r15d
 10140aa:	cmp    $0x800001,%r13d
 10140b1:	jb     1014126 <entry_run+0x1aa6>
 10140b3:	mov    $0x1000000,%r15d
 10140b9:	cmp    $0x1000001,%r13d
 10140c0:	jb     1014126 <entry_run+0x1aa6>
 10140c2:	mov    $0x2000000,%r15d
 10140c8:	cmp    $0x2000001,%r13d
 10140cf:	jb     1014126 <entry_run+0x1aa6>
 10140d1:	mov    $0x4000000,%r15d
 10140d7:	cmp    $0x4000001,%r13d
 10140de:	jb     1014126 <entry_run+0x1aa6>
 10140e0:	mov    $0x8000000,%r15d
 10140e6:	cmp    $0x8000001,%r13d
 10140ed:	jb     1014126 <entry_run+0x1aa6>
 10140ef:	mov    $0x10000000,%r15d
 10140f5:	cmp    $0x10000001,%r13d
 10140fc:	jb     1014126 <entry_run+0x1aa6>
 10140fe:	mov    $0x20000000,%r15d
 1014104:	cmp    $0x20000001,%r13d
 101410b:	jb     1014126 <entry_run+0x1aa6>
 101410d:	xor    %r15d,%r15d
 1014110:	cmp    $0x40000001,%r13d
 1014117:	setae  %r15b
 101411b:	shl    $0x1e,%r15d
 101411f:	add    $0x40000000,%r15
 1014126:	mov    %r15,%rdi
 1014129:	call   1027680 <malloc@plt>
 101412e:	test   %rax,%rax
 1014131:	je     10141a5 <entry_run+0x1b25>
 1014133:	mov    %r13d,%r14d
 1014136:	mov    %rax,(%r12)
 101413a:	mov    %r15,0x10(%r12)
 101413f:	lea    -0x260(%rbp),%rsi
 1014146:	mov    %rax,-0x40(%rbp)
 101414a:	mov    %rax,%rdi
 101414d:	mov    %r14,%rdx
 1014150:	call   10276a0 <memcpy@plt>
 1014155:	lea    0x8(%r12),%r13
 101415a:	mov    %r14,0x8(%r12)
 101415f:	mov    %r12,%rbx
 1014162:	add    $0x18,%rbx
 1014166:	cmp    %r14,%r15
 1014169:	jne    10141c7 <entry_run+0x1b47>
 101416b:	add    %r15,%r15
 101416e:	mov    -0x40(%rbp),%rdi
 1014172:	jmp    1014188 <entry_run+0x1b08>
 1014174:	lea    0x18(%r12),%rbx
 1014179:	mov    %r12,%r13
 101417c:	add    $0x8,%r13
 1014180:	mov    $0x40,%r15d
 1014186:	xor    %edi,%edi
 1014188:	mov    %r15,%rsi
 101418b:	call   10277f0 <realloc@plt>
 1014190:	test   %rax,%rax
 1014193:	je     10141bb <entry_run+0x1b3b>
 1014195:	mov    %rax,(%r12)
 1014199:	mov    %r15,0x10(%r12)
 101419e:	mov    0x8(%r12),%r14
 10141a3:	jmp    10141cb <entry_run+0x1b4b>
 10141a5:	mov    %r12,%rbx
 10141a8:	add    $0x18,%rbx
 10141ac:	movl   $0x1,0x18(%r12)
 10141b5:	mov    -0x30(%rbp),%rdi
 10141b9:	jmp    10141d8 <entry_run+0x1b58>
 10141bb:	movl   $0x1,(%rbx)
 10141c1:	mov    -0x30(%rbp),%rdi
 10141c5:	jmp    10141d8 <entry_run+0x1b58>
 10141c7:	mov    -0x40(%rbp),%rax
 10141cb:	mov    -0x30(%rbp),%rdi
 10141cf:	movb   $0xa,(%rax,%r14,1)
 10141d4:	incq   0x0(%r13)
 10141d8:	movabs $0x4000000000000002,%r14
 10141e2:	cmpl   $0x0,0x1c(%r12)
 10141e8:	je     10141f6 <entry_run+0x1b76>
 10141ea:	mov    $0x1003d5c,%esi
 10141ef:	call   1014ab0 <fail>
 10141f4:	jmp    1014204 <entry_run+0x1b84>
 10141f6:	cmpl   $0x0,(%rbx)
 10141f9:	je     10142b3 <entry_run+0x1c33>
 10141ff:	call   1015290 <myl_qbe_fail_allocation>
 1014204:	mov    (%r12),%rdi
 1014208:	vzeroupper
 101420b:	call   10276f0 <free@plt>
 1014210:	mov    %r12,%rdi
 1014213:	call   10276f0 <free@plt>
 1014218:	cmpb   $0x1,0x17711(%rip)        # 102b930 <exit_without_sweep>
 101421f:	jne    101424e <entry_run+0x1bce>
 1014221:	mov    -0x30(%rbp),%rax
 1014225:	cmpl   $0x0,0x2c0(%rax)
 101422c:	jne    101424e <entry_run+0x1bce>
 101422e:	mov    -0x30(%rbp),%rax
 1014232:	cmpq   $0x0,0x3990(%rax)
 101423a:	jne    101424e <entry_run+0x1bce>
 101423c:	mov    -0x30(%rbp),%rax
 1014240:	cmpq   $0x0,0x3998(%rax)
 1014248:	je     10144b0 <entry_run+0x1e30>
 101424e:	mov    -0x80(%rbp),%rax
 1014252:	test   %rax,%rax
 1014255:	je     1014275 <entry_run+0x1bf5>
 1014257:	test   %r14,-0x10(%rax)
 101425b:	jne    1014275 <entry_run+0x1bf5>
 101425d:	mov    -0x20(%rax),%rcx
 1014261:	dec    %rcx
 1014264:	jne    1014271 <entry_run+0x1bf1>
 1014266:	cmpq   $0x0,-0x18(%rax)
 101426b:	je     10143af <entry_run+0x1d2f>
 1014271:	mov    %rcx,-0x20(%rax)
 1014275:	cmpl   $0x0,-0x50(%rbp)
 1014279:	je     10144b0 <entry_run+0x1e30>
 101427f:	mov    -0x48(%rbp),%rax
 1014283:	test   %rax,%rax
 1014286:	je     10144b0 <entry_run+0x1e30>
 101428c:	test   %r14,-0x10(%rax)
 1014290:	jne    10144b0 <entry_run+0x1e30>
 1014296:	mov    -0x20(%rax),%rcx
 101429a:	dec    %rcx
 101429d:	jne    10142aa <entry_run+0x1c2a>
 101429f:	cmpq   $0x0,-0x18(%rax)
 10142a4:	je     10143cb <entry_run+0x1d4b>
 10142aa:	mov    %rcx,-0x20(%rax)
 10142ae:	jmp    10144b0 <entry_run+0x1e30>
 10142b3:	mov    0x14a66(%rip),%rax        # 1028d20 <stdout@GLIBC_2.2.5>
 10142ba:	mov    (%rax),%r14
 10142bd:	mov    0x8(%r12),%r15
 10142c2:	test   %r15,%r15
 10142c5:	je     10142e4 <entry_run+0x1c64>
 10142c7:	mov    (%r12),%rdi
 10142cb:	mov    $0x1,%esi
 10142d0:	mov    %r15,%rdx
 10142d3:	mov    %r14,%rcx
 10142d6:	call   1027750 <fwrite@plt>
 10142db:	cmp    %r15,%rax
 10142de:	jne    1014392 <entry_run+0x1d12>
 10142e4:	mov    %r14,%rdi
 10142e7:	call   1027800 <fflush@plt>
 10142ec:	test   %eax,%eax
 10142ee:	movabs $0x4000000000000002,%r14
 10142f8:	je     1014204 <entry_run+0x1b84>
 10142fe:	mov    $0x10042d4,%esi
 1014303:	mov    -0x30(%rbp),%rdi
 1014307:	jmp    10141ef <entry_run+0x1b6f>
 101430c:	mov    -0x30(%rbp),%rdi
 1014310:	mov    0x1860(%rdi),%rax
 1014317:	test   %rax,%rax
 101431a:	je     10144f8 <entry_run+0x1e78>
 1014320:	mov    0x124(%rax),%esi
 1014326:	movl   $0x0,0x124(%rax)
 1014330:	call   1014620 <myl_qbe_rc_status>
 1014335:	jmp    10144b0 <entry_run+0x1e30>
 101433a:	mov    %r14,-0x260(%rbp)
 1014341:	lea    -0xf8(%rbp),%rax
 1014348:	mov    %rax,-0x258(%rbp)
 101434f:	movq   $0x0,-0x250(%rbp)
 101435a:	mov    %ebx,-0x248(%rbp)
 1014360:	movl   $0x0,-0x244(%rbp)
 101436a:	lea    -0x260(%rbp),%rsi
 1014371:	lea    -0x58(%rbp),%rcx
 1014375:	mov    -0x38(%rbp),%rdi
 1014379:	mov    %r14,%rdx
 101437c:	call   101eb00 <transfer>
 1014381:	mov    -0x30(%rbp),%r9
 1014385:	test   %eax,%eax
 1014387:	jne    1012a9b <entry_run+0x41b>
 101438d:	jmp    10129df <entry_run+0x35f>
 1014392:	mov    $0x10042d4,%esi
 1014397:	mov    -0x30(%rbp),%rdi
 101439b:	call   1014ab0 <fail>
 10143a0:	movabs $0x4000000000000002,%r14
 10143aa:	jmp    1014204 <entry_run+0x1b84>
 10143af:	lea    -0x80(%rbp),%rsi
 10143b3:	mov    -0x38(%rbp),%rdi
 10143b7:	call   100f700 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10143bc:	cmpl   $0x0,-0x50(%rbp)
 10143c0:	jne    101427f <entry_run+0x1bff>
 10143c6:	jmp    10144b0 <entry_run+0x1e30>
 10143cb:	lea    -0x48(%rbp),%rsi
 10143cf:	mov    -0x38(%rbp),%rdi
 10143d3:	call   100f700 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10143d8:	jmp    10144b0 <entry_run+0x1e30>
 10143dd:	lea    -0x48(%rbp),%rsi
 10143e1:	mov    -0x38(%rbp),%rdi
 10143e5:	vzeroupper
 10143e8:	call   100f700 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10143ed:	mov    -0x30(%rbp),%r9
 10143f1:	jmp    1013258 <entry_run+0xbd8>
 10143f6:	mov    $0x1002338,%esi
 10143fb:	call   1018f74 <myl_rc_binding_find_slow>
 1014400:	mov    %rax,%r12
 1014403:	test   %r12,%r12
 1014406:	jne    101292e <entry_run+0x2ae>
 101440c:	mov    $0x1002338,%esi
 1014411:	mov    -0x38(%rbp),%rdi
 1014415:	call   10234b0 <myl_rc_native_shape>
 101441a:	mov    -0x30(%rbp),%r9
 101441e:	test   %rax,%rax
 1014421:	je     101445c <entry_run+0x1ddc>
 1014423:	mov    0x1860(%r9),%rdi
 101442a:	cmpq   $0x1a,0xa0(%rdi)
 1014432:	jb     10144c7 <entry_run+0x1e47>
 1014438:	mov    0x98(%rdi),%rax
 101443f:	cmpq   $0x1002338,0x190(%rax)
 101444a:	jne    10144c7 <entry_run+0x1e47>
 101444c:	mov    0x198(%rax),%r12
 1014453:	test   %r12,%r12
 1014456:	jne    101292e <entry_run+0x2ae>
 101445c:	mov    0x1860(%r9),%rcx
 1014463:	test   %rcx,%rcx
 1014466:	je     10144f8 <entry_run+0x1e78>
 101446c:	mov    0x124(%rcx),%eax
 1014472:	movl   $0x0,0x124(%rcx)
 101447c:	test   %rax,%rax
 101447f:	je     10144b0 <entry_run+0x1e30>
 1014481:	cmp    $0x1,%eax
 1014484:	jne    101449a <entry_run+0x1e1a>
 1014486:	mov    $0x1004361,%esi
 101448b:	mov    -0x30(%rbp),%rdi
 101448f:	cmpl   $0x0,0x2c4(%rdi)
 1014496:	jne    10144ab <entry_run+0x1e2b>
 1014498:	jmp    10144a3 <entry_run+0x1e23>
 101449a:	cmp    $0x4,%eax
 101449d:	mov    -0x30(%rbp),%rdi
 10144a1:	jae    10144fd <entry_run+0x1e7d>
 10144a3:	mov    0x100b5d0(,%rax,8),%rsi
 10144ab:	call   1014ab0 <fail>
 10144b0:	xor    %eax,%eax
 10144b2:	add    $0x408,%rsp
 10144b9:	pop    %rbx
 10144ba:	pop    %r12
 10144bc:	pop    %r13
 10144be:	pop    %r14
 10144c0:	pop    %r15
 10144c2:	pop    %rbp
 10144c3:	vzeroupper
 10144c6:	ret
 10144c7:	mov    $0x1002338,%esi
 10144cc:	call   1018f74 <myl_rc_binding_find_slow>
 10144d1:	mov    %rax,%r12
 10144d4:	test   %r12,%r12
 10144d7:	jne    101292e <entry_run+0x2ae>
 10144dd:	jmp    101445c <entry_run+0x1ddc>
 10144e2:	mov    %r9,%rdi
 10144e5:	vzeroupper
 10144e8:	call   1015320 <myl_qbe_fail_iteration>
 10144ed:	mov    %r9,%rdi
 10144f0:	vzeroupper
 10144f3:	call   1015460 <myl_qbe_fail_frame>
 10144f8:	call   1018954 <myl_rc_invariant_failed>
 10144fd:	call   1027810 <abort@plt>
 1014502:	mov    %r9,%rdi
 1014505:	vzeroupper
 1014508:	call   1015460 <myl_qbe_fail_frame>
 101450d:	mov    %r9,%rdi
 1014510:	vzeroupper
 1014513:	call   1015460 <myl_qbe_fail_frame>
 1014518:	mov    $0x2,%esi
 101451d:	mov    $0x10000,%ecx
 1014522:	mov    %r9,%rdi
 1014525:	vzeroupper
 1014528:	call   10153a0 <myl_qbe_fail_overflow_op>
 101452d:	mov    $0x2,%esi
 1014532:	mov    $0x100,%ecx
 1014537:	mov    %r9,%rdi
 101453a:	mov    %rax,%rdx
 101453d:	vzeroupper
 1014540:	call   10153a0 <myl_qbe_fail_overflow_op>
 1014545:	mov    %r9,%rdi
 1014548:	xor    %esi,%esi
 101454a:	mov    %rax,%rcx
 101454d:	vzeroupper
 1014550:	call   10153a0 <myl_qbe_fail_overflow_op>
 1014555:	mov    %r9,%rdi
 1014558:	xor    %esi,%esi
 101455a:	mov    %r8,%rdx
 101455d:	vzeroupper
 1014560:	call   10153a0 <myl_qbe_fail_overflow_op>
 1014565:	mov    %r9,%rdi
 1014568:	xor    %esi,%esi
 101456a:	mov    %rax,%rcx
 101456d:	vzeroupper
 1014570:	call   10153a0 <myl_qbe_fail_overflow_op>
 1014575:	mov    %r9,%rdi
 1014578:	vzeroupper
 101457b:	call   1015460 <myl_qbe_fail_frame>
 1014580:	mov    %r9,%rdi
 1014583:	vzeroupper
 1014586:	call   1015320 <myl_qbe_fail_iteration>
 101458b:	mov    %r9,%rdi
 101458e:	mov    %r13,%rsi
 1014591:	vzeroupper
 1014594:	call   1015400 <myl_qbe_fail_cast>
 1014599:	mov    %r9,%rdi
 101459c:	mov    %r14,%rsi
 101459f:	mov    %r13,%rdx
 10145a2:	vzeroupper
 10145a5:	call   1015330 <myl_qbe_fail_normalized_index_bounds>
 10145aa:	mov    %r9,%rdi
 10145ad:	vzeroupper
 10145b0:	call   1015460 <myl_qbe_fail_frame>
 10145b5:	mov    %r9,%rdi
 10145b8:	mov    %r14,%rsi
 10145bb:	vzeroupper
 10145be:	call   1015400 <myl_qbe_fail_cast>
 10145c3:	mov    %r9,%rdi
 10145c6:	vzeroupper
 10145c9:	call   1015290 <myl_qbe_fail_allocation>
 10145ce:	mov    %r9,%rdi
 10145d1:	vzeroupper
 10145d4:	call   1015460 <myl_qbe_fail_frame>
 10145d9:	mov    %r9,%rdi
 10145dc:	call   1015290 <myl_qbe_fail_allocation>
 10145e1:	mov    %r9,%rdi
 10145e4:	call   1015290 <myl_qbe_fail_allocation>
 10145e9:	mov    %r9,%rdi
 10145ec:	call   1015290 <myl_qbe_fail_allocation>
 10145f1:	mov    %r9,%rdi
 10145f4:	call   1015290 <myl_qbe_fail_allocation>
 10145f9:	mov    %r9,%rdi
 10145fc:	call   1015290 <myl_qbe_fail_allocation>
 1014601:	mov    %r9,%rdi
 1014604:	call   1015290 <myl_qbe_fail_allocation>
 1014609:	mov    %r9,%rdi
 101460c:	vzeroupper
 101460f:	call   1015460 <myl_qbe_fail_frame>
 1014614:	int3
 1014615:	int3
 1014616:	int3
 1014617:	int3
 1014618:	int3
 1014619:	int3
 101461a:	int3
 101461b:	int3
 101461c:	int3
 101461d:	int3
 101461e:	int3
 101461f:	int3
