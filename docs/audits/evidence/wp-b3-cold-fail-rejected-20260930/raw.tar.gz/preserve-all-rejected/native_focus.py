from pathlib import Path
import importlib.util,subprocess,os,json
root=Path.cwd();directory=root/'.tmp/cold-fail/native';directory.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('suite',root/'scripts/test_native_memory.py');suite=importlib.util.module_from_spec(spec);spec.loader.exec_module(suite)
flags=['-O3','-std=c11','-Wall','-Wextra','-Werror','-UNDEBUG','-fsanitize=undefined','-ffunction-sections','-fdata-sections','-Wl,--gc-sections']
sources=dict(suite.SUITES)['native_rc_execution']
rows=[]
for side,compiler in [('clang',['zig','cc']),('gcc',['cc'])]:
    out=directory/side;out.mkdir(exist_ok=True)
    suite.run_suite(root,compiler+flags,out,'native_rc_execution',list(sources))
    rows.append({'compiler':compiler,'suite':'native_rc_execution','modes':['success','trap','fast'],'sticky_return_before_each_mode':True,'UBSan':True,'status':0})
(directory/'receipt.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Native cold failure: Clang + GCC, 3 actual execution modes each, sticky first-trap returns and armed longjmp/RC traffic checks all passed')
