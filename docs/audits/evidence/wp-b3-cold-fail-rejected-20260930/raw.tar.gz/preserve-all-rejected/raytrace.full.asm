
/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-cold-fail-20260930/.tmp/cold-fail/raytrace.llvm:     file format elf64-x86-64


Disassembly of section .text:

000000000100f6c0 <_start>:
 100f6c0:	endbr64
 100f6c4:	xor    %ebp,%ebp
 100f6c6:	mov    %rdx,%r9
 100f6c9:	pop    %rsi
 100f6ca:	mov    %rsp,%rdx
 100f6cd:	and    $0xfffffffffffffff0,%rsp
 100f6d1:	push   %rax
 100f6d2:	push   %rsp
 100f6d3:	xor    %r8d,%r8d
 100f6d6:	xor    %ecx,%ecx
 100f6d8:	lea    0x91(%rip),%rdi        # 100f770 <main>
 100f6df:	call   *0x19623(%rip)        # 1028d08 <__libc_start_main@GLIBC_2.34>
 100f6e5:	hlt
 100f6e6:	cs nopw 0x0(%rax,%rax,1)

000000000100f6f0 <_dl_relocate_static_pie>:
 100f6f0:	endbr64
 100f6f4:	ret
 100f6f5:	int3
 100f6f6:	int3
 100f6f7:	int3
 100f6f8:	int3
 100f6f9:	int3
 100f6fa:	int3
 100f6fb:	int3
 100f6fc:	int3
 100f6fd:	int3
 100f6fe:	int3
 100f6ff:	int3

000000000100f700 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>:
 100f700:	mov    (%rsi),%rax
 100f703:	movq   $0x0,(%rsi)
 100f70a:	test   %rax,%rax
 100f70d:	je     100f71f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x1f>
 100f70f:	movabs $0x4000000000000002,%rcx
 100f719:	test   %rcx,-0x10(%rax)
 100f71d:	je     100f727 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x27>
 100f71f:	movq   $0x0,(%rsi)
 100f726:	ret
 100f727:	mov    -0x20(%rax),%rcx
 100f72b:	cmp    $0x1,%rcx
 100f72f:	jne    100f738 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x38>
 100f731:	cmpq   $0x0,-0x18(%rax)
 100f736:	je     100f747 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x47>
 100f738:	dec    %rcx
 100f73b:	mov    %rcx,-0x20(%rax)
 100f73f:	movq   $0x0,(%rsi)
 100f746:	ret
 100f747:	push   %rbp
 100f748:	mov    %rsp,%rbp
 100f74b:	push   %r14
 100f74d:	push   %rbx
 100f74e:	mov    %rdi,%rbx
 100f751:	mov    %rsi,%r14
 100f754:	mov    %rax,%rsi
 100f757:	call   1018d40 <myl_rc_edge_release>
 100f75c:	movq   $0x0,(%r14)
 100f763:	mov    %rbx,%rdi
 100f766:	pop    %rbx
 100f767:	pop    %r14
 100f769:	pop    %rbp
 100f76a:	jmp    101be30 <myl_rc_drain>
 100f76f:	int3

000000000100f770 <main>:
 100f770:	push   %rbp
 100f771:	mov    %rsp,%rbp
 100f774:	push   %r15
 100f776:	push   %r14
 100f778:	push   %r13
 100f77a:	push   %r12
 100f77c:	push   %rbx
 100f77d:	sub    $0x3778,%rsp
 100f784:	mov    %rsi,-0xa0(%rbp)
 100f78b:	mov    %edi,-0x94(%rbp)
 100f791:	movb   $0x1,0x1c198(%rip)        # 102b930 <exit_without_sweep>
 100f798:	lea    -0x3790(%rbp),%r14
 100f79f:	mov    $0x29a0,%edx
 100f7a4:	mov    %r14,%rdi
 100f7a7:	xor    %esi,%esi
 100f7a9:	call   1027650 <memset@plt>
 100f7ae:	mov    $0x180,%eax
 100f7b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f7c0:	movl   $0xffffffff,-0x38a8(%rbp,%rax,1)
 100f7cb:	movl   $0xffffffff,-0x3880(%rbp,%rax,1)
 100f7d6:	movl   $0xffffffff,-0x3858(%rbp,%rax,1)
 100f7e1:	movl   $0xffffffff,-0x3830(%rbp,%rax,1)
 100f7ec:	movl   $0xffffffff,-0x3808(%rbp,%rax,1)
 100f7f7:	movl   $0xffffffff,-0x37e0(%rbp,%rax,1)
 100f802:	movl   $0xffffffff,-0x37b8(%rbp,%rax,1)
 100f80d:	movl   $0xffffffff,-0x3790(%rbp,%rax,1)
 100f818:	add    $0x140,%rax
 100f81e:	cmp    $0x2980,%rax
 100f824:	jne    100f7c0 <main+0x50>
 100f826:	movq   $0x1004f8b,-0xe00(%rbp)
 100f831:	mov    $0x1004371,%edi
 100f836:	call   1027660 <getenv@plt>
 100f83b:	test   %rax,%rax
 100f83e:	je     100fa10 <main+0x2a0>
 100f844:	mov    %rax,%r15
 100f847:	cmpb   $0x0,(%rax)
 100f84a:	je     100fa10 <main+0x2a0>
 100f850:	mov    %r15,%rdi
 100f853:	call   1027670 <strlen@plt>
 100f858:	mov    %rax,%rbx
 100f85b:	lea    0x1(%rax),%r12
 100f85f:	mov    %r12,%rdi
 100f862:	call   1027680 <malloc@plt>
 100f867:	mov    %rax,%r14
 100f86a:	shr    $1,%rbx
 100f86d:	inc    %rbx
 100f870:	mov    $0x8,%esi
 100f875:	mov    %rbx,%rdi
 100f878:	call   1027690 <calloc@plt>
 100f87d:	mov    %r14,%rdi
 100f880:	mov    %rax,%r14
 100f883:	test   %rdi,%rdi
 100f886:	mov    %rdi,-0x90(%rbp)
 100f88d:	je     1011cca <main+0x255a>
 100f893:	test   %r14,%r14
 100f896:	je     1011cca <main+0x255a>
 100f89c:	mov    %r15,%rsi
 100f89f:	mov    %r12,%rdx
 100f8a2:	call   10276a0 <memcpy@plt>
 100f8a7:	mov    -0x90(%rbp),%rdi
 100f8ae:	movzbl (%rdi),%esi
 100f8b1:	mov    $0x1,%bl
 100f8b3:	test   %sil,%sil
 100f8b6:	je     101025b <main+0xaeb>
 100f8bc:	xor    %r9d,%r9d
 100f8bf:	movabs $0x100002600,%rax
 100f8c9:	mov    %rdi,%rcx
 100f8cc:	mov    %rdi,%rdx
 100f8cf:	cmp    $0x20,%sil
 100f8d3:	ja     100f909 <main+0x199>
 100f8d5:	data16 cs nopw 0x0(%rax,%rax,1)
 100f8e0:	movzbl %sil,%esi
 100f8e4:	bt     %rsi,%rax
 100f8e8:	jae    100f900 <main+0x190>
 100f8ea:	movzbl 0x1(%rdx),%esi
 100f8ee:	inc    %rdx
 100f8f1:	cmp    $0x20,%sil
 100f8f5:	jbe    100f8e0 <main+0x170>
 100f8f7:	jmp    100f909 <main+0x199>
 100f8f9:	nopl   0x0(%rax)
 100f900:	test   %rsi,%rsi
 100f903:	je     100f9b9 <main+0x249>
 100f909:	mov    %rcx,(%r14,%r9,8)
 100f90d:	movzbl (%rdx),%edi
 100f910:	test   %dil,%dil
 100f913:	je     100f996 <main+0x226>
 100f919:	xor    %esi,%esi
 100f91b:	jmp    100f92f <main+0x1bf>
 100f91d:	nopl   (%rax)
 100f920:	xor    $0x1,%esi
 100f923:	movzbl 0x1(%rdx),%edi
 100f927:	inc    %rdx
 100f92a:	test   %dil,%dil
 100f92d:	je     100f98e <main+0x21e>
 100f92f:	movzbl %dil,%r8d
 100f933:	test   %esi,%esi
 100f935:	je     100f950 <main+0x1e0>
 100f937:	cmp    $0x5c,%dil
 100f93b:	je     100f970 <main+0x200>
 100f93d:	cmp    $0x22,%r8d
 100f941:	je     100f920 <main+0x1b0>
 100f943:	jmp    100f97c <main+0x20c>
 100f945:	data16 cs nopw 0x0(%rax,%rax,1)
 100f950:	cmp    $0x22,%dil
 100f954:	ja     100f97c <main+0x20c>
 100f956:	cmp    $0x22,%r8
 100f95a:	je     100f920 <main+0x1b0>
 100f95c:	bt     %r8,%rax
 100f960:	jae    100f97c <main+0x20c>
 100f962:	jmp    100f99a <main+0x22a>
 100f964:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f970:	cmpb   $0x0,0x1(%rdx)
 100f974:	je     100f979 <main+0x209>
 100f976:	inc    %rdx
 100f979:	movzbl (%rdx),%edi
 100f97c:	mov    %dil,(%rcx)
 100f97f:	inc    %rcx
 100f982:	movzbl 0x1(%rdx),%edi
 100f986:	inc    %rdx
 100f989:	test   %dil,%dil
 100f98c:	jne    100f92f <main+0x1bf>
 100f98e:	test   %esi,%esi
 100f990:	jne    1011ec4 <main+0x2754>
 100f996:	xor    %esi,%esi
 100f998:	jmp    100f99f <main+0x22f>
 100f99a:	mov    $0x1,%esi
 100f99f:	inc    %r9
 100f9a2:	lea    (%rdx,%rsi,1),%rdi
 100f9a6:	movb   $0x0,(%rcx)
 100f9a9:	inc    %rcx
 100f9ac:	movzbl (%rdx,%rsi,1),%esi
 100f9b0:	test   %sil,%sil
 100f9b3:	jne    100f8cc <main+0x15c>
 100f9b9:	test   %r9d,%r9d
 100f9bc:	js     1011ec4 <main+0x2754>
 100f9c2:	je     101025b <main+0xaeb>
 100f9c8:	mov    %r9,%rbx
 100f9cb:	and    $0x7fffffff,%ebx
 100f9d1:	xor    %r12d,%r12d
 100f9d4:	xor    %edi,%edi
 100f9d6:	xor    %esi,%esi
 100f9d8:	movl   $0x0,-0x68(%rbp)
 100f9df:	movl   $0x0,-0x5c(%rbp)
 100f9e6:	movl   $0x0,-0x7c(%rbp)
 100f9ed:	movl   $0x0,-0x4c(%rbp)
 100f9f4:	movl   $0x0,-0x80(%rbp)
 100f9fb:	xor    %r13d,%r13d
 100f9fe:	xor    %ecx,%ecx
 100fa00:	mov    %r14,-0x70(%rbp)
 100fa04:	mov    %rbx,-0x88(%rbp)
 100fa0b:	jmp    100fb48 <main+0x3d8>
 100fa10:	vpxor  %xmm0,%xmm0,%xmm0
 100fa14:	vmovdqu %ymm0,-0xc8(%rbp)
 100fa1c:	vmovdqu %ymm0,-0xe0(%rbp)
 100fa24:	vmovdqu %ymm0,-0x100(%rbp)
 100fa2c:	vmovdqu %ymm0,-0x120(%rbp)
 100fa34:	vmovdqu %ymm0,-0x140(%rbp)
 100fa3c:	vmovdqu %ymm0,-0x160(%rbp)
 100fa44:	vmovdqu %ymm0,-0x180(%rbp)
 100fa4c:	movq   $0xffffffffffffffff,-0x30(%rbp)
 100fa54:	xor    %eax,%eax
 100fa56:	movb   $0x1,-0x70(%rbp)
 100fa5a:	xor    %r13d,%r13d
 100fa5d:	movl   $0x0,-0x4c(%rbp)
 100fa64:	movq   $0xffffffffffffffff,-0x68(%rbp)
 100fa6c:	xor    %r12d,%r12d
 100fa6f:	mov    %rax,-0x90(%rbp)
 100fa76:	mov    -0x3730(%rbp),%rbx
 100fa7d:	cmp    $0x7,%rbx
 100fa81:	ja     1011e93 <main+0x2723>
 100fa87:	mov    $0x1004662,%edi
 100fa8c:	mov    $0x90000,%esi
 100fa91:	xor    %eax,%eax
 100fa93:	vzeroupper
 100fa96:	call   10276b0 <open@plt>
 100fa9b:	test   %eax,%eax
 100fa9d:	js     1011e93 <main+0x2723>
 100faa3:	lea    0x1(%rbx),%rcx
 100faa7:	mov    %rcx,-0x3730(%rbp)
 100faae:	lea    (%rbx,%rbx,2),%rcx
 100fab2:	mov    %eax,-0x3790(%rbp,%rcx,4)
 100fab9:	movabs $0x100000001,%rax
 100fac3:	mov    %rax,-0x378c(%rbp,%rcx,4)
 100facb:	cmpl   $0x0,-0xe0c(%rbp)
 100fad2:	sete   %al
 100fad5:	je     10103f1 <main+0xc81>
 100fadb:	mov    -0xe20(%rbp),%rdx
 100fae2:	mov    $0x5,%ecx
 100fae7:	test   %rdx,%rdx
 100faea:	je     10103f6 <main+0xc86>
 100faf0:	lea    -0xe98(%rbp),%rsi
 100faf7:	nopw   0x0(%rax,%rax,1)
 100fb00:	cmpl   $0x0,(%rsi)
 100fb03:	jne    10103f1 <main+0xc81>
 100fb09:	add    $0x10,%rsi
 100fb0d:	dec    %rdx
 100fb10:	jne    100fb00 <main+0x390>
 100fb12:	jmp    10103f6 <main+0xc86>
 100fb17:	movl   $0x1,-0xe0c(%rbp)
 100fb21:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100fb30:	mov    -0x30(%rbp),%rsi
 100fb34:	mov    -0x40(%rbp),%rdi
 100fb38:	mov    -0x38(%rbp),%rcx
 100fb3c:	inc    %rcx
 100fb3f:	cmp    %rbx,%rcx
 100fb42:	je     101027a <main+0xb0a>
 100fb48:	mov    %rdi,-0x40(%rbp)
 100fb4c:	mov    %rsi,-0x30(%rbp)
 100fb50:	mov    %rcx,-0x38(%rbp)
 100fb54:	mov    (%r14,%rcx,8),%r15
 100fb58:	mov    $0x1003d0c,%esi
 100fb5d:	mov    %r15,%rdi
 100fb60:	call   10276c0 <strcmp@plt>
 100fb65:	test   %eax,%eax
 100fb67:	je     100fc70 <main+0x500>
 100fb6d:	mov    $0x10044ff,%esi
 100fb72:	mov    $0xd,%edx
 100fb77:	mov    %r15,%rdi
 100fb7a:	call   10276d0 <strncmp@plt>
 100fb7f:	test   %eax,%eax
 100fb81:	je     100fc90 <main+0x520>
 100fb87:	mov    $0x10044f0,%esi
 100fb8c:	mov    $0xe,%edx
 100fb91:	mov    %r15,%rdi
 100fb94:	call   10276d0 <strncmp@plt>
 100fb99:	test   %eax,%eax
 100fb9b:	je     100fcf5 <main+0x585>
 100fba1:	mov    $0x10044c3,%esi
 100fba6:	mov    $0x11,%edx
 100fbab:	mov    %r15,%rdi
 100fbae:	call   10276d0 <strncmp@plt>
 100fbb3:	test   %eax,%eax
 100fbb5:	je     100fd6f <main+0x5ff>
 100fbbb:	mov    $0x1003f05,%esi
 100fbc0:	mov    %r15,%rdi
 100fbc3:	call   10276c0 <strcmp@plt>
 100fbc8:	test   %eax,%eax
 100fbca:	je     100fdab <main+0x63b>
 100fbd0:	mov    $0x1003cc6,%esi
 100fbd5:	mov    %r15,%rdi
 100fbd8:	call   10276c0 <strcmp@plt>
 100fbdd:	test   %eax,%eax
 100fbdf:	je     100fdfe <main+0x68e>
 100fbe5:	mov    $0x1003ee6,%esi
 100fbea:	mov    $0xe,%edx
 100fbef:	mov    %r15,%rdi
 100fbf2:	call   10276d0 <strncmp@plt>
 100fbf7:	test   %eax,%eax
 100fbf9:	je     10100c0 <main+0x950>
 100fbff:	mov    $0x1003c2f,%esi
 100fc04:	mov    $0xb,%edx
 100fc09:	mov    %r15,%rdi
 100fc0c:	call   10276d0 <strncmp@plt>
 100fc11:	test   %eax,%eax
 100fc13:	je     10100f7 <main+0x987>
 100fc19:	mov    $0x1003ef9,%esi
 100fc1e:	mov    %r15,%rdi
 100fc21:	call   10276c0 <strcmp@plt>
 100fc26:	test   %eax,%eax
 100fc28:	je     101012e <main+0x9be>
 100fc2e:	mov    $0x1004664,%esi
 100fc33:	mov    $0x8,%edx
 100fc38:	mov    %r15,%rdi
 100fc3b:	call   10276d0 <strncmp@plt>
 100fc40:	test   %eax,%eax
 100fc42:	je     100fe10 <main+0x6a0>
 100fc48:	mov    $0x1003d0c,%esi
 100fc4d:	mov    $0xa,%edx
 100fc52:	mov    %r15,%rdi
 100fc55:	call   10276d0 <strncmp@plt>
 100fc5a:	test   %eax,%eax
 100fc5c:	setne  %cl
 100fc5f:	mov    %ecx,%eax
 100fc61:	jmp    100fe14 <main+0x6a4>
 100fc66:	cs nopw 0x0(%rax,%rax,1)
 100fc70:	cmpl   $0x0,-0xe0c(%rbp)
 100fc77:	jne    100fe10 <main+0x6a0>
 100fc7d:	jmp    100fb17 <main+0x3a7>
 100fc82:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100fc90:	cmpb   $0x0,0xd(%r15)
 100fc95:	je     100fe10 <main+0x6a0>
 100fc9b:	mov    %r13,-0x78(%rbp)
 100fc9f:	mov    %r12,-0x58(%rbp)
 100fca3:	lea    0xd(%r15),%r12
 100fca7:	mov    -0xe20(%rbp),%r13
 100fcae:	test   %r13,%r13
 100fcb1:	je     100fd86 <main+0x616>
 100fcb7:	cmp    $0x8,%r13
 100fcbb:	je     100fd53 <main+0x5e3>
 100fcc1:	lea    -0xe98(%rbp),%r14
 100fcc8:	mov    %r13,%rbx
 100fccb:	jmp    100fcdd <main+0x56d>
 100fccd:	nopl   (%rax)
 100fcd0:	add    $0x10,%r14
 100fcd4:	dec    %rbx
 100fcd7:	je     100fd86 <main+0x616>
 100fcdd:	mov    -0x8(%r14),%rdi
 100fce1:	mov    %r12,%rsi
 100fce4:	call   10276c0 <strcmp@plt>
 100fce9:	test   %eax,%eax
 100fceb:	jne    100fcd0 <main+0x560>
 100fced:	cmpl   $0x0,(%r14)
 100fcf1:	jne    100fcd0 <main+0x560>
 100fcf3:	jmp    100fd53 <main+0x5e3>
 100fcf5:	cmpb   $0x0,0xe(%r15)
 100fcfa:	je     100fe10 <main+0x6a0>
 100fd00:	mov    %r13,-0x78(%rbp)
 100fd04:	mov    %r12,-0x58(%rbp)
 100fd08:	lea    0xe(%r15),%r12
 100fd0c:	mov    -0xe20(%rbp),%rbx
 100fd13:	test   %rbx,%rbx
 100fd16:	je     100fdc3 <main+0x653>
 100fd1c:	cmp    $0x8,%rbx
 100fd20:	je     100fd53 <main+0x5e3>
 100fd22:	lea    -0xe98(%rbp),%r14
 100fd29:	mov    %rbx,%r13
 100fd2c:	jmp    100fd3d <main+0x5cd>
 100fd2e:	xchg   %ax,%ax
 100fd30:	add    $0x10,%r14
 100fd34:	dec    %r13
 100fd37:	je     100fdc3 <main+0x653>
 100fd3d:	mov    -0x8(%r14),%rdi
 100fd41:	mov    %r12,%rsi
 100fd44:	call   10276c0 <strcmp@plt>
 100fd49:	test   %eax,%eax
 100fd4b:	jne    100fd30 <main+0x5c0>
 100fd4d:	cmpl   $0x1,(%r14)
 100fd51:	jne    100fd30 <main+0x5c0>
 100fd53:	xor    %ecx,%ecx
 100fd55:	xor    %eax,%eax
 100fd57:	mov    -0x58(%rbp),%r12
 100fd5b:	mov    -0x78(%rbp),%r13
 100fd5f:	mov    -0x70(%rbp),%r14
 100fd63:	mov    -0x88(%rbp),%rbx
 100fd6a:	jmp    100fe14 <main+0x6a4>
 100fd6f:	lea    0x11(%r15),%rsi
 100fd73:	lea    -0x3790(%rbp),%rdi
 100fd7a:	call   101d080 <mylang_scoped_endpoint>
 100fd7f:	xor    %ecx,%ecx
 100fd81:	jmp    100fe14 <main+0x6a4>
 100fd86:	lea    0x1(%r13),%rax
 100fd8a:	mov    %rax,-0xe20(%rbp)
 100fd91:	shl    $0x4,%r13
 100fd95:	lea    -0xea0(%rbp),%rax
 100fd9c:	mov    %r12,(%rax,%r13,1)
 100fda0:	movq   $0x0,0x8(%rax,%r13,1)
 100fda9:	jmp    100fde6 <main+0x676>
 100fdab:	cmpl   $0x0,-0xe18(%rbp)
 100fdb2:	jne    100fe10 <main+0x6a0>
 100fdb4:	movl   $0x1,-0xe18(%rbp)
 100fdbe:	jmp    100fb30 <main+0x3c0>
 100fdc3:	lea    0x1(%rbx),%rax
 100fdc7:	mov    %rax,-0xe20(%rbp)
 100fdce:	shl    $0x4,%rbx
 100fdd2:	lea    -0xea0(%rbp),%rax
 100fdd9:	mov    %r12,(%rax,%rbx,1)
 100fddd:	movq   $0x1,0x8(%rax,%rbx,1)
 100fde6:	mov    -0x58(%rbp),%r12
 100fdea:	mov    -0x78(%rbp),%r13
 100fdee:	mov    -0x70(%rbp),%r14
 100fdf2:	mov    -0x88(%rbp),%rbx
 100fdf9:	jmp    100fb30 <main+0x3c0>
 100fdfe:	cmpl   $0x0,-0xe08(%rbp)
 100fe05:	je     10101c9 <main+0xa59>
 100fe0b:	nopl   0x0(%rax,%rax,1)
 100fe10:	xor    %ecx,%ecx
 100fe12:	xor    %eax,%eax
 100fe14:	test   %cl,%cl
 100fe16:	jne    100fe20 <main+0x6b0>
 100fe18:	test   %al,%al
 100fe1a:	je     1011fb1 <main+0x2841>
 100fe20:	test   %cl,%cl
 100fe22:	je     100fb30 <main+0x3c0>
 100fe28:	mov    $0x10044d5,%esi
 100fe2d:	mov    $0xc,%edx
 100fe32:	mov    %r15,%rdi
 100fe35:	call   10276d0 <strncmp@plt>
 100fe3a:	test   %eax,%eax
 100fe3c:	je     100feb5 <main+0x745>
 100fe3e:	mov    $0x10044e2,%esi
 100fe43:	mov    $0xd,%edx
 100fe48:	mov    %r15,%rdi
 100fe4b:	call   10276d0 <strncmp@plt>
 100fe50:	test   %eax,%eax
 100fe52:	je     100ff57 <main+0x7e7>
 100fe58:	mov    $0x10044b8,%esi
 100fe5d:	mov    $0xa,%edx
 100fe62:	mov    %r15,%rdi
 100fe65:	call   10276d0 <strncmp@plt>
 100fe6a:	test   %eax,%eax
 100fe6c:	je     100fff7 <main+0x887>
 100fe72:	mov    $0x1003d31,%esi
 100fe77:	mov    %r15,%rdi
 100fe7a:	call   10276c0 <strcmp@plt>
 100fe7f:	test   %eax,%eax
 100fe81:	je     1010098 <main+0x928>
 100fe87:	mov    $0x1003cd8,%esi
 100fe8c:	mov    %r15,%rdi
 100fe8f:	call   10276c0 <strcmp@plt>
 100fe94:	test   %eax,%eax
 100fe96:	jne    101254a <main+0x2dda>
 100fe9c:	cmpl   $0x0,-0x80(%rbp)
 100fea0:	mov    $0x1003e2b,%eax
 100fea5:	cmovne %rax,%r13
 100fea9:	movl   $0x1,-0x80(%rbp)
 100feb0:	jmp    100fb30 <main+0x3c0>
 100feb5:	movzbl 0xc(%r15),%eax
 100feba:	test   %al,%al
 100febc:	mov    -0x30(%rbp),%rsi
 100fec0:	je     100ff2d <main+0x7bd>
 100fec2:	add    $0xd,%r15
 100fec6:	xor    %edi,%edi
 100fec8:	nopl   0x0(%rax,%rax,1)
 100fed0:	lea    -0x3a(%rax),%ecx
 100fed3:	cmp    $0xf6,%cl
 100fed6:	jb     100ff2d <main+0x7bd>
 100fed8:	add    $0xd0,%al
 100feda:	movzbl %al,%eax
 100fedd:	mov    %rax,%rdx
 100fee0:	not    %rdx
 100fee3:	movabs $0xcccccccccccccccd,%rcx
 100feed:	mulx   %rcx,%rcx,%rcx
 100fef2:	shr    $0x3,%rcx
 100fef6:	cmp    %rcx,%rdi
 100fef9:	ja     100ff2d <main+0x7bd>
 100fefb:	lea    (%rdi,%rdi,4),%rcx
 100feff:	lea    (%rax,%rcx,2),%rdi
 100ff03:	movzbl (%r15),%eax
 100ff07:	inc    %r15
 100ff0a:	test   %al,%al
 100ff0c:	jne    100fed0 <main+0x760>
 100ff0e:	cmpl   $0x0,-0x68(%rbp)
 100ff12:	sete   %al
 100ff15:	mov    -0x38(%rbp),%rcx
 100ff19:	jne    100ff3a <main+0x7ca>
 100ff1b:	movl   $0x1,-0x68(%rbp)
 100ff22:	test   %rdi,%rdi
 100ff25:	jne    100fb3c <main+0x3cc>
 100ff2b:	jmp    100ff3a <main+0x7ca>
 100ff2d:	cmpl   $0x0,-0x68(%rbp)
 100ff31:	sete   %al
 100ff34:	xor    %edi,%edi
 100ff36:	mov    -0x38(%rbp),%rcx
 100ff3a:	test   %al,%al
 100ff3c:	mov    $0x1003e2b,%r13d
 100ff42:	mov    $0x1003cfe,%eax
 100ff47:	cmovne %rax,%r13
 100ff4b:	movl   $0x1,-0x68(%rbp)
 100ff52:	jmp    100fb3c <main+0x3cc>
 100ff57:	movzbl 0xd(%r15),%eax
 100ff5c:	test   %al,%al
 100ff5e:	mov    -0x40(%rbp),%rdi
 100ff62:	je     100ffcd <main+0x85d>
 100ff64:	add    $0xe,%r15
 100ff68:	xor    %esi,%esi
 100ff6a:	nopw   0x0(%rax,%rax,1)
 100ff70:	lea    -0x3a(%rax),%ecx
 100ff73:	cmp    $0xf6,%cl
 100ff76:	jb     100ffcd <main+0x85d>
 100ff78:	add    $0xd0,%al
 100ff7a:	movzbl %al,%eax
 100ff7d:	mov    %rax,%rdx
 100ff80:	not    %rdx
 100ff83:	movabs $0xcccccccccccccccd,%rcx
 100ff8d:	mulx   %rcx,%rcx,%rcx
 100ff92:	shr    $0x3,%rcx
 100ff96:	cmp    %rcx,%rsi
 100ff99:	ja     100ffcd <main+0x85d>
 100ff9b:	lea    (%rsi,%rsi,4),%rcx
 100ff9f:	lea    (%rax,%rcx,2),%rsi
 100ffa3:	movzbl (%r15),%eax
 100ffa7:	inc    %r15
 100ffaa:	test   %al,%al
 100ffac:	jne    100ff70 <main+0x800>
 100ffae:	cmpl   $0x0,-0x5c(%rbp)
 100ffb2:	sete   %al
 100ffb5:	mov    -0x38(%rbp),%rcx
 100ffb9:	jne    100ffda <main+0x86a>
 100ffbb:	movl   $0x1,-0x5c(%rbp)
 100ffc2:	test   %rsi,%rsi
 100ffc5:	jne    100fb3c <main+0x3cc>
 100ffcb:	jmp    100ffda <main+0x86a>
 100ffcd:	cmpl   $0x0,-0x5c(%rbp)
 100ffd1:	sete   %al
 100ffd4:	xor    %esi,%esi
 100ffd6:	mov    -0x38(%rbp),%rcx
 100ffda:	test   %al,%al
 100ffdc:	mov    $0x1003e2b,%r13d
 100ffe2:	mov    $0x1003cfe,%eax
 100ffe7:	cmovne %rax,%r13
 100ffeb:	movl   $0x1,-0x5c(%rbp)
 100fff2:	jmp    100fb3c <main+0x3cc>
 100fff7:	movzbl 0xa(%r15),%eax
 100fffc:	test   %al,%al
 100fffe:	mov    -0x30(%rbp),%rsi
 1010002:	mov    -0x40(%rbp),%rdi
 1010006:	je     101006d <main+0x8fd>
 1010008:	add    $0xb,%r15
 101000c:	xor    %r12d,%r12d
 101000f:	nop
 1010010:	lea    -0x3a(%rax),%ecx
 1010013:	cmp    $0xf6,%cl
 1010016:	jb     101006d <main+0x8fd>
 1010018:	add    $0xd0,%al
 101001a:	movzbl %al,%eax
 101001d:	mov    %rax,%rdx
 1010020:	not    %rdx
 1010023:	movabs $0xcccccccccccccccd,%rcx
 101002d:	mulx   %rcx,%rcx,%rcx
 1010032:	shr    $0x3,%rcx
 1010036:	cmp    %rcx,%r12
 1010039:	ja     101006d <main+0x8fd>
 101003b:	lea    (%r12,%r12,4),%rcx
 101003f:	lea    (%rax,%rcx,2),%r12
 1010043:	movzbl (%r15),%eax
 1010047:	inc    %r15
 101004a:	test   %al,%al
 101004c:	jne    1010010 <main+0x8a0>
 101004e:	cmpl   $0x0,-0x7c(%rbp)
 1010052:	sete   %al
 1010055:	mov    -0x38(%rbp),%rcx
 1010059:	jne    101007b <main+0x90b>
 101005b:	movl   $0x1,-0x7c(%rbp)
 1010062:	test   %r12,%r12
 1010065:	jne    100fb3c <main+0x3cc>
 101006b:	jmp    101007b <main+0x90b>
 101006d:	cmpl   $0x0,-0x7c(%rbp)
 1010071:	sete   %al
 1010074:	xor    %r12d,%r12d
 1010077:	mov    -0x38(%rbp),%rcx
 101007b:	test   %al,%al
 101007d:	mov    $0x1003e2b,%r13d
 1010083:	mov    $0x1003cfe,%eax
 1010088:	cmovne %rax,%r13
 101008c:	movl   $0x1,-0x7c(%rbp)
 1010093:	jmp    100fb3c <main+0x3cc>
 1010098:	cmpl   $0x0,-0x4c(%rbp)
 101009c:	mov    -0x30(%rbp),%rsi
 10100a0:	mov    -0x40(%rbp),%rdi
 10100a4:	mov    -0x38(%rbp),%rcx
 10100a8:	je     10101d8 <main+0xa68>
 10100ae:	movl   $0x1,-0x4c(%rbp)
 10100b5:	mov    $0x1003e2b,%r13d
 10100bb:	jmp    100fb3c <main+0x3cc>
 10100c0:	movzbl 0xe(%r15),%eax
 10100c5:	test   %eax,%eax
 10100c7:	je     10101f0 <main+0xa80>
 10100cd:	cmp    $0x3d,%eax
 10100d0:	jne    100fbff <main+0x48f>
 10100d6:	cmpb   $0x0,0xf(%r15)
 10100db:	je     100fbff <main+0x48f>
 10100e1:	cmpl   $0x0,-0xe14(%rbp)
 10100e8:	jne    100fbff <main+0x48f>
 10100ee:	add    $0xf,%r15
 10100f2:	jmp    1010203 <main+0xa93>
 10100f7:	movzbl 0xb(%r15),%eax
 10100fc:	test   %eax,%eax
 10100fe:	je     1010232 <main+0xac2>
 1010104:	cmp    $0x3d,%eax
 1010107:	jne    100fc19 <main+0x4a9>
 101010d:	cmpb   $0x0,0xc(%r15)
 1010112:	je     100fc19 <main+0x4a9>
 1010118:	cmpl   $0x0,-0xe10(%rbp)
 101011f:	jne    100fc19 <main+0x4a9>
 1010125:	add    $0xc,%r15
 1010129:	jmp    1010245 <main+0xad5>
 101012e:	vmovdqu -0xe18(%rbp),%xmm0
 1010136:	vpinsrd $0x3,-0xe08(%rbp),%xmm0,%xmm0
 1010140:	xor    %ecx,%ecx
 1010142:	vptest %xmm0,%xmm0
 1010147:	jne    100fe12 <main+0x6a2>
 101014d:	cmpq   $0x0,-0xe20(%rbp)
 1010155:	jne    100fe12 <main+0x6a2>
 101015b:	cmpq   $0x0,-0xea8(%rbp)
 1010163:	mov    $0x0,%eax
 1010168:	jne    100fe14 <main+0x6a4>
 101016e:	movl   $0x1,-0xe08(%rbp)
 1010178:	movl   $0x1,-0xe10(%rbp)
 1010182:	movabs $0x100000001,%rax
 101018c:	mov    %rax,-0xe18(%rbp)
 1010193:	movq   $0x1004f8b,-0xe00(%rbp)
 101019e:	movq   $0x1,-0xe20(%rbp)
 10101a9:	movq   $0x1004662,-0xea0(%rbp)
 10101b4:	movq   $0x1,-0xe98(%rbp)
 10101bf:	mov    $0x100466d,%esi
 10101c4:	jmp    100fd73 <main+0x603>
 10101c9:	movl   $0x1,-0xe08(%rbp)
 10101d3:	jmp    100fb30 <main+0x3c0>
 10101d8:	test   %r13,%r13
 10101db:	mov    $0x100b2c0,%eax
 10101e0:	cmove  %rax,%r13
 10101e4:	movl   $0x1,-0x4c(%rbp)
 10101eb:	jmp    100fb3c <main+0x3cc>
 10101f0:	cmpl   $0x0,-0xe14(%rbp)
 10101f7:	jne    100fbff <main+0x48f>
 10101fd:	mov    $0x1004f8b,%r15d
 1010203:	movl   $0x1,-0xe14(%rbp)
 101020d:	cmpb   $0x0,(%r15)
 1010211:	je     100fb30 <main+0x3c0>
 1010217:	mov    %r15,%rdi
 101021a:	xor    %esi,%esi
 101021c:	mov    $0xa,%edx
 1010221:	call   10276e0 <strtoull@plt>
 1010226:	mov    %rax,-0xdf8(%rbp)
 101022d:	jmp    100fb30 <main+0x3c0>
 1010232:	cmpl   $0x0,-0xe10(%rbp)
 1010239:	jne    100fc19 <main+0x4a9>
 101023f:	mov    $0x1004f8b,%r15d
 1010245:	movl   $0x1,-0xe10(%rbp)
 101024f:	mov    %r15,-0xe00(%rbp)
 1010256:	jmp    100fb30 <main+0x3c0>
 101025b:	movq   $0xffffffffffffffff,-0x68(%rbp)
 1010263:	xor    %r12d,%r12d
 1010266:	movq   $0xffffffffffffffff,-0x30(%rbp)
 101026e:	movl   $0x0,-0x4c(%rbp)
 1010275:	xor    %r13d,%r13d
 1010278:	jmp    10102a4 <main+0xb34>
 101027a:	cmpl   $0x0,-0x80(%rbp)
 101027e:	sete   %bl
 1010281:	xor    %ecx,%ecx
 1010283:	cmpl   $0x1,-0x68(%rbp)
 1010287:	mov    $0x0,%eax
 101028c:	sbb    %rax,%rax
 101028f:	or     %rdi,%rax
 1010292:	mov    %rax,-0x68(%rbp)
 1010296:	cmpl   $0x1,-0x5c(%rbp)
 101029a:	sbb    %rcx,%rcx
 101029d:	or     %rsi,%rcx
 10102a0:	mov    %rcx,-0x30(%rbp)
 10102a4:	mov    %r14,%rdi
 10102a7:	call   10276f0 <free@plt>
 10102ac:	cmpl   $0x0,-0xe0c(%rbp)
 10102b3:	vpxor  %xmm0,%xmm0,%xmm0
 10102b7:	vmovdqu %ymm0,-0xc8(%rbp)
 10102bf:	vmovdqu %ymm0,-0xe0(%rbp)
 10102c7:	vmovdqu %ymm0,-0x100(%rbp)
 10102cf:	vmovdqu %ymm0,-0x120(%rbp)
 10102d7:	vmovdqu %ymm0,-0x140(%rbp)
 10102df:	vmovdqu %ymm0,-0x160(%rbp)
 10102e7:	vmovdqu %ymm0,-0x180(%rbp)
 10102ef:	mov    %bl,-0x70(%rbp)
 10102f2:	je     10103a3 <main+0xc33>
 10102f8:	mov    -0xe20(%rbp),%r15
 10102ff:	mov    -0x3730(%rbp),%rbx
 1010306:	test   %r15,%r15
 1010309:	je     10103ce <main+0xc5e>
 101030f:	mov    %r13,-0x78(%rbp)
 1010313:	mov    %r12,-0x58(%rbp)
 1010317:	lea    (%rbx,%rbx,2),%rax
 101031b:	lea    -0x3788(,%rax,4),%r12
 1010323:	add    %rbp,%r12
 1010326:	lea    -0xe98(%rbp),%r13
 101032d:	nopl   (%rax)
 1010330:	cmp    $0x7,%rbx
 1010334:	ja     1011e8c <main+0x271c>
 101033a:	mov    0x0(%r13),%r14d
 101033e:	mov    -0x8(%r13),%rdi
 1010342:	mov    $0x90000,%esi
 1010347:	xor    %eax,%eax
 1010349:	vzeroupper
 101034c:	call   10276b0 <open@plt>
 1010351:	test   %eax,%eax
 1010353:	js     1011e8c <main+0x271c>
 1010359:	inc    %rbx
 101035c:	mov    %rbx,-0x3730(%rbp)
 1010363:	mov    %eax,-0x8(%r12)
 1010368:	mov    %r14d,-0x4(%r12)
 101036d:	movl   $0x0,(%r12)
 1010375:	add    $0xc,%r12
 1010379:	add    $0x10,%r13
 101037d:	dec    %r15
 1010380:	jne    1010330 <main+0xbc0>
 1010382:	lea    -0x3790(%rbp),%r14
 1010389:	mov    -0x58(%rbp),%r12
 101038d:	mov    -0x78(%rbp),%r13
 1010391:	cmpl   $0x0,-0xe0c(%rbp)
 1010398:	sete   %al
 101039b:	jne    100fadb <main+0x36b>
 10103a1:	jmp    10103f1 <main+0xc81>
 10103a3:	mov    -0x90(%rbp),%rax
 10103aa:	lea    -0x3790(%rbp),%r14
 10103b1:	mov    %rax,-0x90(%rbp)
 10103b8:	mov    -0x3730(%rbp),%rbx
 10103bf:	cmp    $0x7,%rbx
 10103c3:	jbe    100fa87 <main+0x317>
 10103c9:	jmp    1011e93 <main+0x2723>
 10103ce:	mov    -0xe0c(%rbp),%ecx
 10103d4:	test   %ecx,%ecx
 10103d6:	sete   %al
 10103d9:	test   %rbx,%rbx
 10103dc:	je     1010521 <main+0xdb1>
 10103e2:	test   %ecx,%ecx
 10103e4:	lea    -0x3790(%rbp),%r14
 10103eb:	jne    100fadb <main+0x36b>
 10103f1:	mov    $0x7,%ecx
 10103f6:	movq   $0x0,-0x148(%rbp)
 1010401:	mov    %r14,-0x150(%rbp)
 1010408:	mov    %ecx,-0x148(%rbp)
 101040e:	movq   $0x101d7c0,-0x140(%rbp)
 1010419:	movq   $0x101d490,-0x138(%rbp)
 1010424:	movq   $0x101d500,-0x130(%rbp)
 101042f:	movq   $0x101d560,-0x128(%rbp)
 101043a:	movq   $0x101d6a0,-0x120(%rbp)
 1010445:	cmpq   $0x0,-0xea8(%rbp)
 101044d:	je     1010546 <main+0xdd6>
 1010453:	mov    %r14,-0x118(%rbp)
 101045a:	movq   $0x7,-0x110(%rbp)
 1010465:	movq   $0x101d250,-0x108(%rbp)
 1010470:	movq   $0x101d490,-0x100(%rbp)
 101047b:	movq   $0x101d500,-0xf8(%rbp)
 1010486:	movq   $0x101d560,-0xf0(%rbp)
 1010491:	movq   $0x101d6a0,-0xe8(%rbp)
 101049c:	test   %al,%al
 101049e:	je     1010562 <main+0xdf2>
 10104a4:	movq   $0x101ce70,-0x178(%rbp)
 10104af:	vpxor  %xmm0,%xmm0,%xmm0
 10104b3:	vmovdqa %xmm0,-0x170(%rbp)
 10104bb:	cmpl   $0x0,-0xe14(%rbp)
 10104c2:	jne    10105cd <main+0xe5d>
 10104c8:	xor    %ebx,%ebx
 10104ca:	lea    -0x9f0(%rbp),%rsi
 10104d1:	xor    %edi,%edi
 10104d3:	vzeroupper
 10104d6:	call   1027700 <clock_gettime@plt>
 10104db:	test   %eax,%eax
 10104dd:	jne    10105c6 <main+0xe56>
 10104e3:	mov    -0x9f0(%rbp),%rcx
 10104ea:	mov    -0x9e8(%rbp),%rax
 10104f1:	movabs $0x7fffffffffffffff,%rdx
 10104fb:	xor    %rax,%rdx
 10104fe:	movabs $0x112e0be826d694b3,%rsi
 1010508:	mulx   %rsi,%rdx,%rdx
 101050d:	shr    $0x1a,%rdx
 1010511:	cmp    %rdx,%rcx
 1010514:	jle    10105bc <main+0xe4c>
 101051a:	xor    %ebx,%ebx
 101051c:	jmp    10105c6 <main+0xe56>
 1010521:	lea    -0x150(%rbp),%rcx
 1010528:	vmovdqu %ymm0,0x18(%rcx)
 101052d:	vmovdqu %ymm0,(%rcx)
 1010531:	lea    -0x3790(%rbp),%r14
 1010538:	cmpq   $0x0,-0xea8(%rbp)
 1010540:	jne    1010453 <main+0xce3>
 1010546:	lea    -0x118(%rbp),%rcx
 101054d:	vpxor  %xmm0,%xmm0,%xmm0
 1010551:	vmovdqu %ymm0,0x18(%rcx)
 1010556:	vmovdqu %ymm0,(%rcx)
 101055a:	test   %al,%al
 101055c:	jne    10104a4 <main+0xd34>
 1010562:	xor    %eax,%eax
 1010564:	cmpl   $0x0,-0xe18(%rbp)
 101056b:	mov    $0x101ce70,%ecx
 1010570:	cmovne %rcx,%rax
 1010574:	mov    %rax,-0x178(%rbp)
 101057b:	vpxor  %xmm0,%xmm0,%xmm0
 101057f:	vmovdqa %xmm0,-0x170(%rbp)
 1010587:	cmpl   $0x0,-0xe14(%rbp)
 101058e:	je     10105a9 <main+0xe39>
 1010590:	lea    -0xdf8(%rbp),%rax
 1010597:	mov    %rax,-0x170(%rbp)
 101059e:	movq   $0x101cee0,-0x168(%rbp)
 10105a9:	vmovdqa %xmm0,-0x160(%rbp)
 10105b1:	cmpl   $0x0,-0xe10(%rbp)
 10105b8:	jne    10105e6 <main+0xe76>
 10105ba:	jmp    10105ff <main+0xe8f>
 10105bc:	imul   $0x3b9aca00,%rcx,%rbx
 10105c3:	add    %rax,%rbx
 10105c6:	mov    %rbx,-0xdf8(%rbp)
 10105cd:	lea    -0xdf8(%rbp),%rax
 10105d4:	mov    %rax,-0x170(%rbp)
 10105db:	movq   $0x101cee0,-0x168(%rbp)
 10105e6:	mov    -0xe00(%rbp),%rax
 10105ed:	mov    %rax,-0x160(%rbp)
 10105f4:	movq   $0x101cf30,-0x158(%rbp)
 10105ff:	xor    %ebx,%ebx
 1010601:	mov    -0x94(%rbp),%eax
 1010607:	test   %eax,%eax
 1010609:	setg   %r15b
 101060d:	cmp    $0x2,%eax
 1010610:	mov    $0x1,%ecx
 1010615:	cmovge %eax,%ecx
 1010618:	cmp    $0x100b2c0,%r13
 101061f:	je     1010a34 <main+0x12c4>
 1010625:	test   %r13,%r13
 1010628:	jne    1010a4d <main+0x12dd>
 101062e:	test   %r12,%r12
 1010631:	je     1010712 <main+0xfa2>
 1010637:	mov    %ecx,%r13d
 101063a:	lea    -0x9e8(%rbp),%rdi
 1010641:	vpxor  %xmm0,%xmm0,%xmm0
 1010645:	vmovdqu %ymm0,-0x978(%rbp)
 101064d:	vmovdqu %ymm0,-0x988(%rbp)
 1010655:	vmovdqu %ymm0,-0x9a8(%rbp)
 101065d:	vmovdqu %ymm0,-0x9c8(%rbp)
 1010665:	vmovdqu %ymm0,-0x9e8(%rbp)
 101066d:	movq   $0x1015470,-0x9f0(%rbp)
 1010678:	vzeroupper
 101067b:	call   1027710 <sigemptyset@plt>
 1010680:	lea    -0x9f0(%rbp),%rsi
 1010687:	mov    $0xe,%edi
 101068c:	xor    %edx,%edx
 101068e:	call   1027720 <sigaction@plt>
 1010693:	test   %eax,%eax
 1010695:	jne    1010a1b <main+0x12ab>
 101069b:	vpxor  %xmm0,%xmm0,%xmm0
 101069f:	vmovdqu %ymm0,-0xdf0(%rbp)
 10106a7:	vmovdqu %ymm0,-0xdd0(%rbp)
 10106af:	movl   $0xe,-0xde8(%rbp)
 10106b9:	lea    -0xdf0(%rbp),%rsi
 10106c0:	mov    $0x102b950,%edx
 10106c5:	mov    $0x1,%edi
 10106ca:	vzeroupper
 10106cd:	call   1027730 <timer_create@plt>
 10106d2:	test   %eax,%eax
 10106d4:	jne    1010a1b <main+0x12ab>
 10106da:	vpxor  %xmm0,%xmm0,%xmm0
 10106de:	vmovdqu %ymm0,-0x3f0(%rbp)
 10106e6:	mov    %r12,-0x3e0(%rbp)
 10106ed:	mov    0x1b25c(%rip),%rdi        # 102b950 <timeout_timer>
 10106f4:	lea    -0x3f0(%rbp),%rdx
 10106fb:	xor    %esi,%esi
 10106fd:	xor    %ecx,%ecx
 10106ff:	vzeroupper
 1010702:	call   1027740 <timer_settime@plt>
 1010707:	test   %eax,%eax
 1010709:	mov    %r13d,%ecx
 101070c:	jne    1010a1b <main+0x12ab>
 1010712:	mov    %r15b,%bl
 1010715:	mov    -0xa0(%rbp),%rax
 101071c:	lea    (%rax,%rbx,8),%rax
 1010720:	mov    %rax,-0x38(%rbp)
 1010724:	dec    %ecx
 1010726:	mov    %ecx,-0x40(%rbp)
 1010729:	je     10108ce <main+0x115e>
 101072f:	mov    -0x40(%rbp),%r15d
 1010733:	xor    %r13d,%r13d
 1010736:	jmp    101074c <main+0xfdc>
 1010738:	nopl   0x0(%rax,%rax,1)
 1010740:	inc    %r13
 1010743:	cmp    %r15,%r13
 1010746:	je     10108ce <main+0x115e>
 101074c:	mov    -0x38(%rbp),%rax
 1010750:	mov    (%rax,%r13,8),%rbx
 1010754:	mov    %rbx,%rdi
 1010757:	vzeroupper
 101075a:	call   1027670 <strlen@plt>
 101075f:	test   %rax,%rax
 1010762:	je     1010740 <main+0xfd0>
 1010764:	mov    %rax,%r12
 1010767:	xor    %ecx,%ecx
 1010769:	jmp    1010782 <main+0x1012>
 101076b:	nopl   0x0(%rax,%rax,1)
 1010770:	dec    %edx
 1010772:	lea    (%rcx,%rdx,1),%r9
 1010776:	add    $0x2,%r9
 101077a:	mov    %r9,%rcx
 101077d:	cmp    %r12,%r9
 1010780:	je     1010740 <main+0xfd0>
 1010782:	lea    0x1(%rcx),%r9
 1010786:	movzbl (%rbx,%rcx,1),%edi
 101078a:	test   %dil,%dil
 101078d:	jns    101077a <main+0x100a>
 101078f:	lea    0x3e(%rdi),%r8d
 1010793:	cmp    $0x1e,%r8b
 1010797:	jae    10107ab <main+0x103b>
 1010799:	mov    $0x80,%esi
 101079e:	mov    $0x1,%edx
 10107a3:	mov    $0x1f,%r10d
 10107a9:	jmp    10107e6 <main+0x1076>
 10107ab:	mov    %edi,%edx
 10107ad:	and    $0xf0,%dl
 10107b0:	cmp    $0xe0,%dl
 10107b3:	jne    10107ca <main+0x105a>
 10107b5:	mov    $0x800,%esi
 10107ba:	mov    $0x2,%edx
 10107bf:	mov    $0x1,%r11b
 10107c2:	mov    $0xf,%r10d
 10107c8:	jmp    10107e9 <main+0x1079>
 10107ca:	lea    0x10(%rdi),%edx
 10107cd:	cmp    $0x4,%dl
 10107d0:	ja     1010899 <main+0x1129>
 10107d6:	mov    $0x10000,%esi
 10107db:	mov    $0x3,%edx
 10107e0:	mov    $0x7,%r10d
 10107e6:	xor    %r11d,%r11d
 10107e9:	mov    %edx,%r14d
 10107ec:	mov    %r12,%rax
 10107ef:	sub    %r9,%rax
 10107f2:	cmp    %r14,%rax
 10107f5:	jb     1010899 <main+0x1129>
 10107fb:	movzbl 0x1(%rbx,%rcx,1),%r9d
 1010801:	mov    %r9d,%eax
 1010804:	and    $0xffffffc0,%eax
 1010807:	cmp    $0x80,%eax
 101080c:	jne    1010899 <main+0x1129>
 1010812:	and    %edi,%r10d
 1010815:	shl    $0x6,%r10d
 1010819:	and    $0x3f,%r9d
 101081d:	or     %r10d,%r9d
 1010820:	cmp    $0x1e,%r8b
 1010824:	jb     101084c <main+0x10dc>
 1010826:	movzbl 0x2(%rbx,%rcx,1),%edi
 101082b:	mov    %edi,%eax
 101082d:	and    $0xffffffc0,%eax
 1010830:	cmp    $0x80,%eax
 1010835:	jne    1010899 <main+0x1129>
 1010837:	shl    $0x6,%r9d
 101083b:	and    $0x3f,%edi
 101083e:	or     %r9d,%edi
 1010841:	test   %r11b,%r11b
 1010844:	je     1010870 <main+0x1100>
 1010846:	mov    %r9d,%r10d
 1010849:	mov    %edi,%r9d
 101084c:	cmp    $0x10ffff,%r10d
 1010853:	ja     1010899 <main+0x1129>
 1010855:	cmp    %esi,%r9d
 1010858:	jb     1010899 <main+0x1129>
 101085a:	add    $0xffff2000,%r10d
 1010861:	cmp    $0xfffff7ff,%r10d
 1010868:	jbe    1010770 <main+0x1000>
 101086e:	jmp    1010899 <main+0x1129>
 1010870:	movzbl 0x3(%rbx,%rcx,1),%r9d
 1010876:	mov    %r9d,%eax
 1010879:	and    $0xffffffc0,%eax
 101087c:	cmp    $0x80,%eax
 1010881:	jne    1010899 <main+0x1129>
 1010883:	shl    $0x6,%edi
 1010886:	and    $0x3f,%r9d
 101088a:	or     %edi,%r9d
 101088d:	mov    %edi,%r10d
 1010890:	cmp    $0x10ffff,%r10d
 1010897:	jbe    1010855 <main+0x10e5>
 1010899:	mov    0x18478(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 10108a0:	mov    (%rax),%rcx
 10108a3:	mov    $0x1004f13,%edi
 10108a8:	mov    $0x2a,%esi
 10108ad:	mov    $0x1,%edx
 10108b2:	call   1027750 <fwrite@plt>
 10108b7:	mov    $0x2,%r15d
 10108bd:	mov    $0x70,%ebx
 10108c2:	lea    -0x3790(%rbp),%r14
 10108c9:	jmp    10125d8 <main+0x2e68>
 10108ce:	lea    -0x3f0(%rbp),%rdi
 10108d5:	mov    $0x268,%edx
 10108da:	xor    %esi,%esi
 10108dc:	vzeroupper
 10108df:	call   1027650 <memset@plt>
 10108e4:	mov    $0x1003cfe,%ecx
 10108e9:	mov    -0x68(%rbp),%r14
 10108ed:	test   %r14,%r14
 10108f0:	je     1011d91 <main+0x2621>
 10108f6:	mov    -0x30(%rbp),%rax
 10108fa:	test   %rax,%rax
 10108fd:	je     1011d91 <main+0x2621>
 1010903:	cmp    $0xffffffffffffffff,%rax
 1010907:	mov    $0x400,%r12d
 101090d:	cmovne %rax,%r12
 1010911:	mov    %r12,%rax
 1010914:	shr    $0x3b,%rax
 1010918:	mov    $0x1003b92,%ecx
 101091d:	jne    1011d91 <main+0x2621>
 1010923:	mov    $0x100431a,%edi
 1010928:	call   1027660 <getenv@plt>
 101092d:	test   %rax,%rax
 1010930:	je     1010a01 <main+0x1291>
 1010936:	movzbl (%rax),%edx
 1010939:	test   %dl,%dl
 101093b:	je     1010a01 <main+0x1291>
 1010941:	lea    -0x30(%rdx),%esi
 1010944:	mov    $0x1003ce7,%ecx
 1010949:	cmp    $0x9,%sil
 101094d:	ja     1011d91 <main+0x2621>
 1010953:	dec    %rax
 1010956:	xor    %esi,%esi
 1010958:	movabs $0xcccccccccccccccd,%rdi
 1010962:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010970:	add    $0xd0,%dl
 1010973:	movzbl %dl,%r8d
 1010977:	mov    %r8,%rdx
 101097a:	not    %rdx
 101097d:	mulx   %rdi,%rdx,%rdx
 1010982:	shr    $0x3,%rdx
 1010986:	cmp    %rdx,%rsi
 1010989:	ja     1011d91 <main+0x2621>
 101098f:	lea    (%rsi,%rsi,4),%rdx
 1010993:	lea    (%r8,%rdx,2),%rsi
 1010997:	movzbl 0x2(%rax),%edx
 101099b:	lea    -0x30(%rdx),%r8d
 101099f:	inc    %rax
 10109a2:	cmp    $0xa,%r8b
 10109a6:	jb     1010970 <main+0x1200>
 10109a8:	movzbl %dl,%edx
 10109ab:	lea    -0x47(%rdx),%edi
 10109ae:	cmp    $0x26,%edi
 10109b1:	ja     1011d83 <main+0x2613>
 10109b7:	movabs $0x100000001,%r8
 10109c1:	bt     %rdi,%r8
 10109c5:	jb     1010a6e <main+0x12fe>
 10109cb:	mov    $0x400,%r9d
 10109d1:	movabs $0x1000000010,%r8
 10109db:	bt     %rdi,%r8
 10109df:	jb     1010a74 <main+0x1304>
 10109e5:	movabs $0x4000000040,%r8
 10109ef:	bt     %rdi,%r8
 10109f3:	jae    1011d83 <main+0x2613>
 10109f9:	mov    $0x100000,%r9d
 10109ff:	jmp    1010a74 <main+0x1304>
 1010a01:	xor    %ebx,%ebx
 1010a03:	mov    $0x1004458,%edi
 1010a08:	call   1027660 <getenv@plt>
 1010a0d:	test   %rax,%rax
 1010a10:	jne    1010aae <main+0x133e>
 1010a16:	jmp    1010ad9 <main+0x1369>
 1010a1b:	mov    0x182f6(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1010a22:	mov    (%rax),%rcx
 1010a25:	mov    $0x1004ea2,%edi
 1010a2a:	mov    $0x32,%esi
 1010a2f:	jmp    1011ea7 <main+0x2737>
 1010a34:	mov    0x182dd(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1010a3b:	mov    (%rax),%rcx
 1010a3e:	mov    $0x100491f,%edi
 1010a43:	mov    $0x5e,%esi
 1010a48:	jmp    1011ea7 <main+0x2737>
 1010a4d:	mov    0x182c4(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1010a54:	mov    (%rax),%rdi
 1010a57:	mov    $0x1004d99,%esi
 1010a5c:	mov    %r13,%rdx
 1010a5f:	xor    %eax,%eax
 1010a61:	vzeroupper
 1010a64:	call   1027760 <fprintf@plt>
 1010a69:	jmp    1011eb4 <main+0x2744>
 1010a6e:	mov    $0x40000000,%r9d
 1010a74:	cmpb   $0x0,0x2(%rax)
 1010a78:	jne    1011d91 <main+0x2621>
 1010a7e:	tzcnt  %r9,%rax
 1010a83:	mov    $0xffffffffffffffff,%rdx
 1010a8a:	shrx   %rax,%rdx,%rax
 1010a8f:	cmp    %rax,%rsi
 1010a92:	ja     1011d91 <main+0x2621>
 1010a98:	mov    %r9,%rbx
 1010a9b:	imul   %rsi,%rbx
 1010a9f:	mov    $0x1004458,%edi
 1010aa4:	call   1027660 <getenv@plt>
 1010aa9:	test   %rax,%rax
 1010aac:	je     1010ad9 <main+0x1369>
 1010aae:	mov    %rbx,-0x58(%rbp)
 1010ab2:	movzbl (%rax),%edx
 1010ab5:	lea    -0x3a(%rdx),%ecx
 1010ab8:	cmp    $0xf6,%cl
 1010abb:	jae    1010c3d <main+0x14cd>
 1010ac1:	mov    $0x1004458,%edi
 1010ac6:	call   1027770 <unsetenv@plt>
 1010acb:	mov    $0x10042dd,%edi
 1010ad0:	call   1027770 <unsetenv@plt>
 1010ad5:	mov    -0x58(%rbp),%rbx
 1010ad9:	mov    %rbx,%r13
 1010adc:	add    $0x10000000,%rbx
 1010ae3:	cmp    $0x10000001,%rbx
 1010aea:	jb     1010b44 <main+0x13d4>
 1010aec:	lea    -0x9f0(%rbp),%rsi
 1010af3:	mov    $0x9,%edi
 1010af8:	call   1027780 <getrlimit@plt>
 1010afd:	test   %eax,%eax
 1010aff:	jne    1010b44 <main+0x13d4>
 1010b01:	mov    -0x9f0(%rbp),%rcx
 1010b08:	mov    -0x9e8(%rbp),%rdx
 1010b0f:	cmp    %rdx,%rbx
 1010b12:	mov    %rdx,%rax
 1010b15:	cmovb  %rbx,%rax
 1010b19:	cmp    $0xffffffffffffffff,%rdx
 1010b1d:	cmove  %rbx,%rax
 1010b21:	cmp    $0xffffffffffffffff,%rcx
 1010b25:	je     1010b2c <main+0x13bc>
 1010b27:	cmp    %rax,%rcx
 1010b2a:	jbe    1010b44 <main+0x13d4>
 1010b2c:	mov    %rax,-0x9f0(%rbp)
 1010b33:	lea    -0x9f0(%rbp),%rsi
 1010b3a:	mov    $0x9,%edi
 1010b3f:	call   1027790 <setrlimit@plt>
 1010b44:	mov    $0x1,%edi
 1010b49:	mov    $0x3e88,%esi
 1010b4e:	call   1027690 <calloc@plt>
 1010b53:	mov    %rax,%r15
 1010b56:	mov    $0x1003b92,%ecx
 1010b5b:	test   %rax,%rax
 1010b5e:	mov    -0x30(%rbp),%rax
 1010b62:	je     1011d91 <main+0x2621>
 1010b68:	mov    %r14,0x10(%r15)
 1010b6c:	mov    %r12,0x18(%r15)
 1010b70:	mov    %rax,0x38(%r15)
 1010b74:	lea    -0x180(%rbp),%rax
 1010b7b:	mov    %rax,0x3978(%r15)
 1010b82:	mov    -0x40(%rbp),%eax
 1010b85:	mov    %eax,0x39d0(%r15)
 1010b8c:	mov    -0x38(%rbp),%rax
 1010b90:	mov    %rax,0x39d8(%r15)
 1010b97:	lea    0x258(%r15),%rax
 1010b9e:	xor    %ebx,%ebx
 1010ba0:	cmp    $0x1,%r13
 1010ba4:	sbb    %rbx,%rbx
 1010ba7:	or     %r13,%rbx
 1010baa:	mov    %rax,%r13
 1010bad:	mov    $0x1718,%edx
 1010bb2:	mov    %rax,%rdi
 1010bb5:	xor    %esi,%esi
 1010bb7:	call   1027650 <memset@plt>
 1010bbc:	mov    %rbx,0x2b0(%r15)
 1010bc3:	movq   $0x1,0x290(%r15)
 1010bce:	movq   $0x100000,0x2b8(%r15)
 1010bd9:	cmp    $0x457,%rbx
 1010be0:	ja     1010bf2 <main+0x1482>
 1010be2:	movl   $0x1,0x2c4(%r15)
 1010bed:	jmp    1010e2d <main+0x16bd>
 1010bf2:	mov    $0x1,%edi
 1010bf7:	mov    $0x458,%esi
 1010bfc:	call   1027690 <calloc@plt>
 1010c01:	test   %rax,%rax
 1010c04:	je     1010e2d <main+0x16bd>
 1010c0a:	movq   $0x458,0x270(%r15)
 1010c15:	movq   $0x458,0x208(%rax)
 1010c20:	cmp    $0x57f,%rbx
 1010c27:	ja     1010d70 <main+0x1600>
 1010c2d:	movl   $0x1,0x2c4(%r15)
 1010c38:	jmp    1010e1a <main+0x16aa>
 1010c3d:	add    $0x2,%rax
 1010c41:	xor    %r15d,%r15d
 1010c44:	movabs $0xcccccccccccccccd,%rcx
 1010c4e:	xchg   %ax,%ax
 1010c50:	add    $0xd0,%dl
 1010c53:	movzbl %dl,%esi
 1010c56:	mov    %rsi,%rdx
 1010c59:	not    %rdx
 1010c5c:	mulx   %rcx,%rdx,%rdx
 1010c61:	shr    $0x3,%rdx
 1010c65:	cmp    %rdx,%r15
 1010c68:	ja     1010ac1 <main+0x1351>
 1010c6e:	lea    (%r15,%r15,4),%rdx
 1010c72:	lea    (%rsi,%rdx,2),%r15
 1010c76:	movzbl -0x1(%rax),%edx
 1010c7a:	lea    -0x30(%rdx),%esi
 1010c7d:	inc    %rax
 1010c80:	cmp    $0xa,%sil
 1010c84:	jb     1010c50 <main+0x14e0>
 1010c86:	cmp    $0x3a,%dl
 1010c89:	jne    1010ac1 <main+0x1351>
 1010c8f:	movzbl -0x1(%rax),%ebx
 1010c93:	lea    -0x3a(%rbx),%edx
 1010c96:	cmp    $0xf6,%dl
 1010c99:	jb     1010ac1 <main+0x1351>
 1010c9f:	xor    %r13d,%r13d
 1010ca2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010cb0:	add    $0xd0,%bl
 1010cb3:	movzbl %bl,%esi
 1010cb6:	mov    %rsi,%rdx
 1010cb9:	not    %rdx
 1010cbc:	mulx   %rcx,%rdx,%rdx
 1010cc1:	shr    $0x3,%rdx
 1010cc5:	cmp    %rdx,%r13
 1010cc8:	ja     1010ac1 <main+0x1351>
 1010cce:	lea    0x0(,%r13,4),%rdx
 1010cd6:	add    %r13,%rdx
 1010cd9:	lea    (%rsi,%rdx,2),%r13
 1010cdd:	movzbl (%rax),%ebx
 1010ce0:	lea    -0x30(%rbx),%edx
 1010ce3:	inc    %rax
 1010ce6:	cmp    $0xa,%dl
 1010ce9:	jb     1010cb0 <main+0x1540>
 1010ceb:	mov    $0x1004458,%edi
 1010cf0:	call   1027770 <unsetenv@plt>
 1010cf5:	mov    $0x10042dd,%edi
 1010cfa:	call   1027770 <unsetenv@plt>
 1010cff:	test   %bl,%bl
 1010d01:	mov    -0x58(%rbp),%rbx
 1010d05:	jne    1010ad9 <main+0x1369>
 1010d0b:	lea    -0x9f0(%rbp),%rsi
 1010d12:	mov    $0x9,%edi
 1010d17:	call   1027780 <getrlimit@plt>
 1010d1c:	test   %eax,%eax
 1010d1e:	jne    1010ad9 <main+0x1369>
 1010d24:	cmp    %r15,-0x9f0(%rbp)
 1010d2b:	jne    1010ad9 <main+0x1369>
 1010d31:	mov    -0x9e8(%rbp),%rcx
 1010d38:	cmp    %rcx,%r13
 1010d3b:	mov    %rcx,%rax
 1010d3e:	cmovb  %r13,%rax
 1010d42:	cmp    $0xffffffffffffffff,%rcx
 1010d46:	cmove  %r13,%rax
 1010d4a:	cmp    %r15,%rax
 1010d4d:	jbe    1010ad9 <main+0x1369>
 1010d53:	mov    %rax,-0x9f0(%rbp)
 1010d5a:	lea    -0x9f0(%rbp),%rsi
 1010d61:	mov    $0x9,%edi
 1010d66:	call   1027790 <setrlimit@plt>
 1010d6b:	jmp    1010ad9 <main+0x1369>
 1010d70:	mov    $0x1,%edi
 1010d75:	mov    $0x128,%esi
 1010d7a:	mov    %rax,%rbx
 1010d7d:	call   1027690 <calloc@plt>
 1010d82:	mov    %rax,%rcx
 1010d85:	mov    %rbx,%rax
 1010d88:	test   %rcx,%rcx
 1010d8b:	je     1010e1a <main+0x16aa>
 1010d91:	vmovdqu -0x5599(%rip),%ymm0        # 100b800 <allocator>
 1010d99:	vmovdqu %ymm0,(%rcx)
 1010d9d:	mov    %rax,0x20(%rcx)
 1010da1:	movq   $0x128,0x30(%rcx)
 1010da9:	movq   $0x100b5f0,0x78(%rcx)
 1010db1:	vpxor  %xmm0,%xmm0,%xmm0
 1010db5:	vmovdqu %xmm0,0x80(%rcx)
 1010dbd:	movq   $0x3f,0x90(%rcx)
 1010dc8:	vmovdqu 0x78(%rcx),%ymm1
 1010dcd:	vmovdqu %ymm1,0x58(%rcx)
 1010dd2:	vmovdqu %ymm1,0x38(%rcx)
 1010dd7:	vmovdqu %xmm0,0x98(%rcx)
 1010ddf:	movq   $0x0,0xa8(%rcx)
 1010dea:	movq   $0x580,0x270(%r15)
 1010df5:	mov    %rcx,0x1860(%r15)
 1010dfc:	mov    $0x100ba68,%esi
 1010e01:	mov    %r13,%rdi
 1010e04:	vzeroupper
 1010e07:	call   1019700 <myl_rc_module_register>
 1010e0c:	test   %eax,%eax
 1010e0e:	je     1010e38 <main+0x16c8>
 1010e10:	mov    %r13,%rdi
 1010e13:	call   1018a20 <myl_rc_heap_destroy>
 1010e18:	jmp    1010e2d <main+0x16bd>
 1010e1a:	movq   $0x0,0x270(%r15)
 1010e25:	mov    %rax,%rdi
 1010e28:	call   10276f0 <free@plt>
 1010e2d:	movl   $0x1,0x750(%r15)
 1010e38:	mov    %r12,-0x38(%rbp)
 1010e3c:	mov    -0x4c(%rbp),%eax
 1010e3f:	mov    %eax,0x2c0(%r15)
 1010e46:	mov    0x1860(%r15),%r12
 1010e4d:	test   %r12,%r12
 1010e50:	je     10113db <main+0x1c6b>
 1010e56:	cmpq   $0x0,0xc0(%r12)
 1010e5f:	jne    1011330 <main+0x1bc0>
 1010e65:	mov    $0x1,%eax
 1010e6a:	mov    $0xffffffffffffff40,%rcx
 1010e71:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010e80:	mov    0x1003b58(%rcx),%rdx
 1010e87:	mov    (%rdx),%rsi
 1010e8a:	test   %rsi,%rsi
 1010e8d:	je     1011330 <main+0x1bc0>
 1010e93:	cmp    0x1003448(%rcx),%rsi
 1010e9a:	jne    1011330 <main+0x1bc0>
 1010ea0:	mov    0x8(%rdx),%rdi
 1010ea4:	cmp    (%rsi),%rdi
 1010ea7:	jne    1011330 <main+0x1bc0>
 1010ead:	mov    0x38(%rdx),%rsi
 1010eb1:	test   %rsi,%rsi
 1010eb4:	je     1011330 <main+0x1bc0>
 1010eba:	cmp    $0x4,%rsi
 1010ebe:	ja     1011330 <main+0x1bc0>
 1010ec4:	cmp    %rsi,0x30(%rdx)
 1010ec8:	ja     1011330 <main+0x1bc0>
 1010ece:	cmp    %rax,%rsi
 1010ed1:	cmova  %rsi,%rax
 1010ed5:	add    $0x8,%rcx
 1010ed9:	jne    1010e80 <main+0x1710>
 1010edb:	cmp    $0x4,%rax
 1010edf:	jne    1011330 <main+0x1bc0>
 1010ee5:	mov    $0x1009f7c,%eax
 1010eea:	xor    %ecx,%ecx
 1010eec:	mov    $0xffff,%edx
 1010ef1:	mov    $0x17fdddb,%esi
 1010ef6:	jmp    1010f22 <main+0x17b2>
 1010ef8:	nopl   0x0(%rax,%rax,1)
 1010f00:	movzbl 0x46(%rdi),%r8d
 1010f05:	or     0x44(%rdi),%r8b
 1010f09:	jne    1011330 <main+0x1bc0>
 1010f0f:	inc    %rcx
 1010f12:	add    $0xc8,%rax
 1010f18:	cmp    $0x19,%rcx
 1010f1c:	je     1011335 <main+0x1bc5>
 1010f22:	imul   $0xc8,%rcx,%rdi
 1010f29:	mov    0x1009ee8(%rdi),%r8
 1010f30:	test   %r8,%r8
 1010f33:	je     1011330 <main+0x1bc0>
 1010f39:	mov    0x1009ee0(%rdi),%r9
 1010f40:	mov    %rcx,%r10
 1010f43:	shl    $0x6,%r10
 1010f47:	cmp    0x1003450(%r10),%r9
 1010f4e:	jne    1011330 <main+0x1bc0>
 1010f54:	mov    (%r9),%r10
 1010f57:	cmp    (%r8),%r10
 1010f5a:	jne    1011330 <main+0x1bc0>
 1010f60:	lea    0x1009ee0(%rdi),%rdi
 1010f67:	cmp    %r10,0x50(%rdi)
 1010f6b:	jne    1011330 <main+0x1bc0>
 1010f71:	cmp    $0x5,%rcx
 1010f75:	je     1010f00 <main+0x1790>
 1010f77:	cmp    $0x17,%rcx
 1010f7b:	je     1010f00 <main+0x1790>
 1010f7d:	mov    0x40(%rdi),%r11d
 1010f81:	movzwl 0x58(%rdi),%r8d
 1010f86:	shrx   %r11d,%edx,%r9d
 1010f8b:	shlx   %r11d,%r9d,%r9d
 1010f90:	xor    %r8d,%r9d
 1010f93:	cmp    $0xffff,%r9d
 1010f9a:	jne    1011330 <main+0x1bc0>
 1010fa0:	movzwl 0x5a(%rdi),%r9d
 1010fa5:	andn   %r9d,%r8d,%ebx
 1010faa:	jne    1011330 <main+0x1bc0>
 1010fb0:	bt     %rcx,%rsi
 1010fb4:	jb     1010fe6 <main+0x1876>
 1010fb6:	sub    $0x8,%r10
 1010fba:	jb     1011330 <main+0x1bc0>
 1010fc0:	xor    %ebx,%ebx
 1010fc2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010fd0:	movzwl (%rax,%rbx,2),%r14d
 1010fd5:	cmp    %r14,%r10
 1010fd8:	jb     1011330 <main+0x1bc0>
 1010fde:	inc    %rbx
 1010fe1:	cmp    %rbx,%r11
 1010fe4:	jne    1010fd0 <main+0x1860>
 1010fe6:	cmp    %r8w,%r9w
 1010fea:	jne    1011330 <main+0x1bc0>
 1010ff0:	not    %r8d
 1010ff3:	movzwl 0x5c(%rdi),%r10d
 1010ff8:	test   %r8d,%r10d
 1010ffb:	jne    1011330 <main+0x1bc0>
 1011001:	and    %r9d,%r10d
 1011004:	cmp    %r9d,%r10d
 1011007:	jne    1011330 <main+0x1bc0>
 101100d:	movzwl 0x5e(%rdi),%r10d
 1011012:	test   %r8d,%r10d
 1011015:	jne    1011330 <main+0x1bc0>
 101101b:	and    %r9d,%r10d
 101101e:	cmp    %r9d,%r10d
 1011021:	jne    1011330 <main+0x1bc0>
 1011027:	movzwl 0x60(%rdi),%r10d
 101102c:	test   %r8d,%r10d
 101102f:	jne    1011330 <main+0x1bc0>
 1011035:	and    %r9d,%r10d
 1011038:	cmp    %r9d,%r10d
 101103b:	jne    1011330 <main+0x1bc0>
 1011041:	movzwl 0x62(%rdi),%r10d
 1011046:	test   %r8d,%r10d
 1011049:	jne    1011330 <main+0x1bc0>
 101104f:	and    %r9d,%r10d
 1011052:	cmp    %r9d,%r10d
 1011055:	jne    1011330 <main+0x1bc0>
 101105b:	movzwl 0x64(%rdi),%r10d
 1011060:	test   %r8d,%r10d
 1011063:	jne    1011330 <main+0x1bc0>
 1011069:	and    %r9d,%r10d
 101106c:	cmp    %r9d,%r10d
 101106f:	jne    1011330 <main+0x1bc0>
 1011075:	movzwl 0x66(%rdi),%r10d
 101107a:	test   %r8d,%r10d
 101107d:	jne    1011330 <main+0x1bc0>
 1011083:	and    %r9d,%r10d
 1011086:	cmp    %r9d,%r10d
 1011089:	jne    1011330 <main+0x1bc0>
 101108f:	movzwl 0x68(%rdi),%r10d
 1011094:	test   %r8d,%r10d
 1011097:	jne    1011330 <main+0x1bc0>
 101109d:	and    %r9d,%r10d
 10110a0:	cmp    %r9d,%r10d
 10110a3:	jne    1011330 <main+0x1bc0>
 10110a9:	movzwl 0x6a(%rdi),%r10d
 10110ae:	test   %r8d,%r10d
 10110b1:	jne    1011330 <main+0x1bc0>
 10110b7:	and    %r9d,%r10d
 10110ba:	cmp    %r9d,%r10d
 10110bd:	jne    1011330 <main+0x1bc0>
 10110c3:	movzwl 0x6c(%rdi),%r10d
 10110c8:	test   %r8d,%r10d
 10110cb:	jne    1011330 <main+0x1bc0>
 10110d1:	and    %r9d,%r10d
 10110d4:	cmp    %r9d,%r10d
 10110d7:	jne    1011330 <main+0x1bc0>
 10110dd:	movzwl 0x6e(%rdi),%r10d
 10110e2:	test   %r8d,%r10d
 10110e5:	jne    1011330 <main+0x1bc0>
 10110eb:	and    %r9d,%r10d
 10110ee:	cmp    %r9d,%r10d
 10110f1:	jne    1011330 <main+0x1bc0>
 10110f7:	movzwl 0x70(%rdi),%r10d
 10110fc:	test   %r8d,%r10d
 10110ff:	jne    1011330 <main+0x1bc0>
 1011105:	and    %r9d,%r10d
 1011108:	cmp    %r9d,%r10d
 101110b:	jne    1011330 <main+0x1bc0>
 1011111:	movzwl 0x72(%rdi),%r10d
 1011116:	test   %r8d,%r10d
 1011119:	jne    1011330 <main+0x1bc0>
 101111f:	and    %r9d,%r10d
 1011122:	cmp    %r9d,%r10d
 1011125:	jne    1011330 <main+0x1bc0>
 101112b:	movzwl 0x74(%rdi),%r10d
 1011130:	test   %r8d,%r10d
 1011133:	jne    1011330 <main+0x1bc0>
 1011139:	and    %r9d,%r10d
 101113c:	cmp    %r9d,%r10d
 101113f:	jne    1011330 <main+0x1bc0>
 1011145:	movzwl 0x76(%rdi),%r10d
 101114a:	test   %r8d,%r10d
 101114d:	jne    1011330 <main+0x1bc0>
 1011153:	and    %r9d,%r10d
 1011156:	cmp    %r9d,%r10d
 1011159:	jne    1011330 <main+0x1bc0>
 101115f:	movzwl 0x78(%rdi),%r10d
 1011164:	test   %r8d,%r10d
 1011167:	jne    1011330 <main+0x1bc0>
 101116d:	and    %r9d,%r10d
 1011170:	cmp    %r9d,%r10d
 1011173:	jne    1011330 <main+0x1bc0>
 1011179:	movzwl 0x7a(%rdi),%r10d
 101117e:	test   %r8d,%r10d
 1011181:	jne    1011330 <main+0x1bc0>
 1011187:	and    %r9d,%r10d
 101118a:	cmp    %r9d,%r10d
 101118d:	jne    1011330 <main+0x1bc0>
 1011193:	movzwl 0x7c(%rdi),%r10d
 1011198:	test   %r8d,%r10d
 101119b:	jne    1011330 <main+0x1bc0>
 10111a1:	and    %r9d,%r10d
 10111a4:	cmp    %r9d,%r10d
 10111a7:	jne    1011330 <main+0x1bc0>
 10111ad:	movzwl 0x7e(%rdi),%r10d
 10111b2:	test   %r8d,%r10d
 10111b5:	jne    1011330 <main+0x1bc0>
 10111bb:	and    %r9d,%r10d
 10111be:	cmp    %r9d,%r10d
 10111c1:	jne    1011330 <main+0x1bc0>
 10111c7:	movzwl 0x80(%rdi),%r10d
 10111cf:	test   %r8d,%r10d
 10111d2:	jne    1011330 <main+0x1bc0>
 10111d8:	and    %r9d,%r10d
 10111db:	cmp    %r9d,%r10d
 10111de:	jne    1011330 <main+0x1bc0>
 10111e4:	movzwl 0x82(%rdi),%r10d
 10111ec:	test   %r8d,%r10d
 10111ef:	jne    1011330 <main+0x1bc0>
 10111f5:	and    %r9d,%r10d
 10111f8:	cmp    %r9d,%r10d
 10111fb:	jne    1011330 <main+0x1bc0>
 1011201:	movzwl 0x84(%rdi),%r10d
 1011209:	test   %r8d,%r10d
 101120c:	jne    1011330 <main+0x1bc0>
 1011212:	and    %r9d,%r10d
 1011215:	cmp    %r9d,%r10d
 1011218:	jne    1011330 <main+0x1bc0>
 101121e:	movzwl 0x86(%rdi),%r10d
 1011226:	test   %r8d,%r10d
 1011229:	jne    1011330 <main+0x1bc0>
 101122f:	and    %r9d,%r10d
 1011232:	cmp    %r9d,%r10d
 1011235:	jne    1011330 <main+0x1bc0>
 101123b:	movzwl 0x88(%rdi),%r10d
 1011243:	test   %r8d,%r10d
 1011246:	jne    1011330 <main+0x1bc0>
 101124c:	and    %r9d,%r10d
 101124f:	cmp    %r9d,%r10d
 1011252:	jne    1011330 <main+0x1bc0>
 1011258:	movzwl 0x8a(%rdi),%r10d
 1011260:	test   %r8d,%r10d
 1011263:	jne    1011330 <main+0x1bc0>
 1011269:	and    %r9d,%r10d
 101126c:	cmp    %r9d,%r10d
 101126f:	jne    1011330 <main+0x1bc0>
 1011275:	movzwl 0x8c(%rdi),%r10d
 101127d:	test   %r8d,%r10d
 1011280:	jne    1011330 <main+0x1bc0>
 1011286:	and    %r9d,%r10d
 1011289:	cmp    %r9d,%r10d
 101128c:	jne    1011330 <main+0x1bc0>
 1011292:	movzwl 0x8e(%rdi),%r10d
 101129a:	test   %r8d,%r10d
 101129d:	jne    1011330 <main+0x1bc0>
 10112a3:	and    %r9d,%r10d
 10112a6:	cmp    %r9d,%r10d
 10112a9:	jne    1011330 <main+0x1bc0>
 10112af:	movzwl 0x90(%rdi),%r10d
 10112b7:	test   %r8d,%r10d
 10112ba:	jne    1011330 <main+0x1bc0>
 10112bc:	and    %r9d,%r10d
 10112bf:	cmp    %r9d,%r10d
 10112c2:	jne    1011330 <main+0x1bc0>
 10112c4:	movzwl 0x92(%rdi),%r10d
 10112cc:	test   %r8d,%r10d
 10112cf:	jne    1011330 <main+0x1bc0>
 10112d1:	and    %r9d,%r10d
 10112d4:	cmp    %r9d,%r10d
 10112d7:	jne    1011330 <main+0x1bc0>
 10112d9:	movzwl 0x94(%rdi),%r10d
 10112e1:	test   %r8d,%r10d
 10112e4:	jne    1011330 <main+0x1bc0>
 10112e6:	and    %r9d,%r10d
 10112e9:	cmp    %r9d,%r10d
 10112ec:	jne    1011330 <main+0x1bc0>
 10112ee:	movzwl 0x96(%rdi),%r10d
 10112f6:	test   %r8d,%r10d
 10112f9:	jne    1011330 <main+0x1bc0>
 10112fb:	and    %r9d,%r10d
 10112fe:	cmp    %r9d,%r10d
 1011301:	jne    1011330 <main+0x1bc0>
 1011303:	movzwl 0x98(%rdi),%r10d
 101130b:	test   %r8d,%r10d
 101130e:	jne    1011330 <main+0x1bc0>
 1011310:	and    %r9d,%r10d
 1011313:	cmp    %r9d,%r10d
 1011316:	jne    1011330 <main+0x1bc0>
 1011318:	movzwl 0x9a(%rdi),%edi
 101131f:	test   %r8d,%edi
 1011322:	jne    1011330 <main+0x1bc0>
 1011324:	and    %r9d,%edi
 1011327:	cmp    %r9d,%edi
 101132a:	je     1010f0f <main+0x179f>
 1011330:	call   1018954 <myl_rc_invariant_failed>
 1011335:	mov    0x38(%r12),%rax
 101133a:	mov    0x40(%r12),%rdx
 101133f:	movzbl 0x50(%r12),%ecx
 1011345:	mov    $0x100b298,%esi
 101134a:	movabs $0x9e3779b97f4a7c15,%rdi
 1011354:	imul   %rsi,%rdi
 1011358:	shrx   %rcx,%rdi,%rcx
 101135d:	nopl   (%rax)
 1011360:	and    %rdx,%rcx
 1011363:	mov    %rcx,%rsi
 1011366:	shl    $0x4,%rsi
 101136a:	mov    (%rax,%rsi,1),%rsi
 101136e:	cmp    $0x100b298,%rsi
 1011375:	je     1011381 <main+0x1c11>
 1011377:	test   %rsi,%rsi
 101137a:	je     101138d <main+0x1c1d>
 101137c:	inc    %rcx
 101137f:	jmp    1011360 <main+0x1bf0>
 1011381:	shl    $0x4,%rcx
 1011385:	cmpq   $0x0,0x8(%rax,%rcx,1)
 101138b:	jne    10113f7 <main+0x1c87>
 101138d:	mov    $0x13c8,%ebx
 1011392:	add    0x270(%r15),%rbx
 1011399:	jb     10113b8 <main+0x1c48>
 101139b:	mov    0x2b0(%r15),%rax
 10113a2:	test   %rax,%rax
 10113a5:	setne  %cl
 10113a8:	cmp    %rax,%rbx
 10113ab:	seta   %al
 10113ae:	and    %cl,%al
 10113b0:	cmp    $0x1,%al
 10113b2:	jne    1011a6d <main+0x22fd>
 10113b8:	movl   $0x1,0x2c4(%r15)
 10113c3:	mov    $0x1004361,%esi
 10113c8:	cmpl   $0x0,0x2c4(%r15)
 10113d0:	lea    0x258(%r15),%r13
 10113d7:	jne    10113ef <main+0x1c7f>
 10113d9:	jmp    10113ea <main+0x1c7a>
 10113db:	mov    $0x1004361,%esi
 10113e0:	cmpl   $0x0,0x2c4(%r15)
 10113e8:	jne    10113ef <main+0x1c7f>
 10113ea:	mov    $0x1003b92,%esi
 10113ef:	mov    %r15,%rdi
 10113f2:	call   1014ab0 <fail>
 10113f7:	mov    0x20(%r15),%rax
 10113fb:	test   %rax,%rax
 10113fe:	lea    -0x3790(%rbp),%r14
 1011405:	jne    10114f3 <main+0x1d83>
 101140b:	mov    $0x20,%esi
 1011410:	mov    -0x38(%rbp),%rdi
 1011414:	vzeroupper
 1011417:	call   1027690 <calloc@plt>
 101141c:	mov    %rax,0x28(%r15)
 1011420:	test   %rax,%rax
 1011423:	je     10114ea <main+0x1d7a>
 1011429:	call   10277a0 <fegetround@plt>
 101142e:	test   %eax,%eax
 1011430:	jne    10114a9 <main+0x1d39>
 1011432:	movabs $0x10000000000000,%rax
 101143c:	mov    %rax,-0x9f0(%rbp)
 1011443:	movabs $0x3fe0000000000000,%rax
 101144d:	mov    %rax,-0xdf0(%rbp)
 1011454:	movq   $0x1,-0x48(%rbp)
 101145c:	movabs $0x3ff0000000000000,%rax
 1011466:	mov    %rax,-0xa8(%rbp)
 101146d:	vmovsd -0x9f0(%rbp),%xmm0
 1011475:	vmulsd -0xdf0(%rbp),%xmm0,%xmm0
 101147d:	vmovq  %xmm0,%rax
 1011482:	movabs $0x8000000000000,%rcx
 101148c:	cmp    %rcx,%rax
 101148f:	jne    10114a9 <main+0x1d39>
 1011491:	vmovsd -0x48(%rbp),%xmm0
 1011496:	vmulsd -0xa8(%rbp),%xmm0,%xmm0
 101149e:	vmovq  %xmm0,%rax
 10114a3:	cmp    $0x1,%rax
 10114a7:	je     10114b6 <main+0x1d46>
 10114a9:	mov    $0x10042fa,%esi
 10114ae:	mov    %r15,%rdi
 10114b1:	call   1014ab0 <fail>
 10114b6:	mov    0x20(%r15),%rax
 10114ba:	test   %rax,%rax
 10114bd:	jne    10114f3 <main+0x1d83>
 10114bf:	mov    %r15,%rdi
 10114c2:	vzeroupper
 10114c5:	call   1018500 <myl_qbe_on_stack>
 10114ca:	mov    %rax,-0x3f0(%rbp)
 10114d1:	mov    0x20(%r15),%rax
 10114d5:	test   %rax,%rax
 10114d8:	jne    10114f3 <main+0x1d83>
 10114da:	mov    $0x1004416,%eax
 10114df:	cmpq   $0x0,0x8(%r15)
 10114e4:	jne    10114ef <main+0x1d7f>
 10114e6:	xor    %eax,%eax
 10114e8:	jmp    10114f3 <main+0x1d83>
 10114ea:	mov    $0x1003b92,%eax
 10114ef:	mov    %rax,0x20(%r15)
 10114f3:	mov    (%r15),%rcx
 10114f6:	mov    %rcx,-0x3e8(%rbp)
 10114fd:	mov    %rax,-0x3e0(%rbp)
 1011504:	vmovups 0x248(%r15),%xmm0
 101150d:	vmovups %xmm0,-0x1d8(%rbp)
 1011515:	mov    0x39e0(%r15),%eax
 101151c:	mov    %eax,-0x1c8(%rbp)
 1011522:	vmovdqu 0x39e8(%r15),%ymm0
 101152b:	vmovdqu 0x3a00(%r15),%ymm1
 1011534:	vmovdqu %ymm0,-0x1c0(%rbp)
 101153c:	vmovdqu %ymm1,-0x1a8(%rbp)
 1011544:	lea    -0x3d8(%rbp),%rdi
 101154b:	lea    0x48(%r15),%rsi
 101154f:	mov    $0x200,%edx
 1011554:	vzeroupper
 1011557:	call   10276a0 <memcpy@plt>
 101155c:	mov    0x3e80(%r15),%rax
 1011563:	test   %rax,%rax
 1011566:	je     101156d <main+0x1dfd>
 1011568:	mov    %r15,%rdi
 101156b:	call   *%rax
 101156d:	mov    0x39a0(%r15),%rax
 1011574:	test   %rax,%rax
 1011577:	je     101157e <main+0x1e0e>
 1011579:	mov    %r15,%rdi
 101157c:	call   *%rax
 101157e:	mov    0x3e78(%r15),%rax
 1011585:	test   %rax,%rax
 1011588:	je     101158f <main+0x1e1f>
 101158a:	mov    %r15,%rdi
 101158d:	call   *%rax
 101158f:	mov    0x20(%r15),%rax
 1011593:	test   %rax,%rax
 1011596:	je     10115d5 <main+0x1e65>
 1011598:	mov    0x1860(%r15),%r9
 101159f:	test   %r9,%r9
 10115a2:	je     1011c44 <main+0x24d4>
 10115a8:	lea    0x2c8(%r15),%r14
 10115af:	mov    %r15,%rbx
 10115b2:	add    $0x328,%rbx
 10115b9:	mov    0xf8(%r9),%r12
 10115c0:	movq   $0x0,0xf8(%r9)
 10115cb:	test   %r12,%r12
 10115ce:	jne    101163f <main+0x1ecf>
 10115d0:	jmp    1011729 <main+0x1fb9>
 10115d5:	cmpl   $0x0,0x2c0(%r15)
 10115dd:	jne    10115f7 <main+0x1e87>
 10115df:	cmpq   $0x0,0x3990(%r15)
 10115e7:	jne    10115f7 <main+0x1e87>
 10115e9:	cmpq   $0x0,0x3998(%r15)
 10115f1:	je     1011c44 <main+0x24d4>
 10115f7:	mov    0x1860(%r15),%r9
 10115fe:	test   %r9,%r9
 1011601:	je     1011c44 <main+0x24d4>
 1011607:	lea    0x2c8(%r15),%r12
 101160e:	test   %rax,%rax
 1011611:	je     1011bbb <main+0x244b>
 1011617:	mov    %r15,%rbx
 101161a:	add    $0x328,%rbx
 1011621:	mov    %r12,%r14
 1011624:	mov    0xf8(%r9),%r12
 101162b:	movq   $0x0,0xf8(%r9)
 1011636:	test   %r12,%r12
 1011639:	je     1011729 <main+0x1fb9>
 101163f:	mov    %r14,-0x38(%rbp)
 1011643:	mov    %rbx,%r14
 1011646:	vpxor  %xmm0,%xmm0,%xmm0
 101164a:	jmp    101166f <main+0x1eff>
 101164c:	nopl   0x0(%rax)
 1011650:	add    $0x8,%r12
 1011654:	vmovdqu %xmm0,(%r12)
 101165a:	movl   $0x0,0x10(%r12)
 1011663:	mov    %r13,%r12
 1011666:	test   %r13,%r13
 1011669:	je     1011712 <main+0x1fa2>
 101166f:	mov    0x8(%r12),%r13
 1011674:	mov    0x10(%r12),%rsi
 1011679:	test   %rsi,%rsi
 101167c:	je     1011650 <main+0x1ee0>
 101167e:	xchg   %ax,%ax
 1011680:	mov    (%rsi),%rbx
 1011683:	mov    0x1860(%r15),%rax
 101168a:	mov    0x108(%rax),%rcx
 1011691:	cmp    $0x20,%rcx
 1011695:	je     10116f1 <main+0x1f81>
 1011697:	mov    0x270(%r15),%rdx
 101169e:	cmp    $0x28,%rdx
 10116a2:	jb     1011330 <main+0x1bc0>
 10116a8:	mov    0x30(%rax),%rdi
 10116ac:	cmp    $0x27,%rdi
 10116b0:	jbe    1011330 <main+0x1bc0>
 10116b6:	add    $0xffffffffffffffd8,%rdx
 10116ba:	mov    %rdx,0x270(%r15)
 10116c1:	add    $0xffffffffffffffd8,%rdi
 10116c5:	mov    %rdi,0x30(%rax)
 10116c9:	mov    0x100(%rax),%rdx
 10116d0:	mov    %rdx,(%rsi)
 10116d3:	mov    %rsi,0x100(%rax)
 10116da:	inc    %rcx
 10116dd:	mov    %rcx,0x108(%rax)
 10116e4:	mov    %rbx,%rsi
 10116e7:	test   %rbx,%rbx
 10116ea:	jne    1011680 <main+0x1f10>
 10116ec:	jmp    1011650 <main+0x1ee0>
 10116f1:	lea    0x258(%r15),%rdi
 10116f8:	call   101e50f <entry_release>
 10116fd:	vpxor  %xmm0,%xmm0,%xmm0
 1011701:	mov    %rbx,%rsi
 1011704:	test   %rbx,%rbx
 1011707:	jne    1011680 <main+0x1f10>
 101170d:	jmp    1011650 <main+0x1ee0>
 1011712:	mov    0x1860(%r15),%r9
 1011719:	test   %r9,%r9
 101171c:	mov    %r14,%rbx
 101171f:	mov    -0x38(%rbp),%r14
 1011723:	je     1011330 <main+0x1bc0>
 1011729:	mov    0x13f8(%r15),%rax
 1011730:	test   %rax,%rax
 1011733:	je     101175f <main+0x1fef>
 1011735:	mov    0x818(%r15),%rcx
 101173c:	sub    %rax,%rcx
 101173f:	add    $0xffffffffffffffb0,%rcx
 1011743:	mov    %rcx,0x10(%rax)
 1011747:	movq   $0x0,0x13f8(%r15)
 1011752:	vpxor  %xmm0,%xmm0,%xmm0
 1011756:	vmovdqu %xmm0,0x818(%r15)
 101175f:	mov    0x1440(%r15),%rsi
 1011766:	test   %rsi,%rsi
 1011769:	je     101178c <main+0x201c>
 101176b:	mov    0x730(%r15),%rax
 1011772:	test   $0x1,%sil
 1011776:	jne    10117ad <main+0x203d>
 1011778:	xor    %edx,%edx
 101177a:	mov    %rsi,%rcx
 101177d:	mov    %rdx,%rdi
 1011780:	cmp    $0x1,%rsi
 1011784:	jne    1011d20 <main+0x25b0>
 101178a:	jmp    10117ee <main+0x207e>
 101178c:	movl   $0x0,(%r14)
 1011793:	mov    $0x400,%edx
 1011798:	mov    %rbx,%rdi
 101179b:	xor    %esi,%esi
 101179d:	mov    %r9,%rbx
 10117a0:	call   1027650 <memset@plt>
 10117a5:	mov    %rbx,%r8
 10117a8:	jmp    1011932 <main+0x21c2>
 10117ad:	lea    -0x1(%rsi),%rcx
 10117b1:	mov    -0x8(%rax,%rsi,8),%rdi
 10117b6:	movq   $0x0,-0x8(%rax,%rsi,8)
 10117bf:	test   %rdi,%rdi
 10117c2:	je     1011cf5 <main+0x2585>
 10117c8:	xor    %r8d,%r8d
 10117cb:	nopl   0x0(%rax,%rax,1)
 10117d0:	mov    %rdi,%rdx
 10117d3:	mov    (%rdi),%rdi
 10117d6:	mov    %r8,(%rdx)
 10117d9:	mov    %rdx,%r8
 10117dc:	test   %rdi,%rdi
 10117df:	jne    10117d0 <main+0x2060>
 10117e1:	mov    %rdx,%rdi
 10117e4:	cmp    $0x1,%rsi
 10117e8:	jne    1011d20 <main+0x25b0>
 10117ee:	movq   $0x0,0x1440(%r15)
 10117f9:	test   %rdi,%rdi
 10117fc:	je     1011906 <main+0x2196>
 1011802:	mov    $0x200000,%r12d
 1011808:	jmp    1011828 <main+0x20b8>
 101180a:	nopw   0x0(%rax,%rax,1)
 1011810:	sub    %rcx,0x270(%r15)
 1011817:	call   10276f0 <free@plt>
 101181c:	mov    %r13,%rdi
 101181f:	test   %r13,%r13
 1011822:	je     10118ff <main+0x218f>
 1011828:	mov    (%rdi),%r13
 101182b:	mov    0x18(%rdi),%rax
 101182f:	sub    %rax,0x298(%r15)
 1011836:	mov    0x18(%rdi),%rax
 101183a:	add    %rax,0x2d8(%r15)
 1011841:	vmovdqu 0x300(%r15),%xmm0
 101184a:	vmovdqa -0xff72(%rip),%xmm1        # 10018e0 <__abi_tag+0x15e4>
 1011852:	vpinsrq $0x1,0x8(%rdi),%xmm1,%xmm1
 1011859:	vpsubq %xmm1,%xmm0,%xmm0
 101185d:	vmovdqu %xmm0,0x300(%r15)
 1011866:	mov    0x2b0(%r15),%rax
 101186d:	cmp    $0x200000,%rax
 1011873:	mov    $0x200000,%ecx
 1011878:	cmovb  %rax,%rcx
 101187c:	test   %rax,%rax
 101187f:	mov    %rcx,%rax
 1011882:	cmove  %r12,%rax
 1011886:	cmpq   $0x0,0x1860(%r15)
 101188e:	cmove  %rcx,%rax
 1011892:	mov    0x8(%rdi),%rcx
 1011896:	cmp    $0x100000,%rcx
 101189d:	ja     1011810 <main+0x20a0>
 10118a3:	mov    0x318(%r15),%rdx
 10118aa:	cmp    $0x3,%rdx
 10118ae:	ja     1011810 <main+0x20a0>
 10118b4:	mov    0x320(%r15),%rsi
 10118bb:	sub    %rsi,%rax
 10118be:	jbe    1011810 <main+0x20a0>
 10118c4:	cmp    %rax,%rcx
 10118c7:	ja     1011810 <main+0x20a0>
 10118cd:	mov    0x738(%r15),%rax
 10118d4:	mov    %rax,(%rdi)
 10118d7:	mov    %rdi,0x738(%r15)
 10118de:	inc    %rdx
 10118e1:	mov    %rdx,0x318(%r15)
 10118e8:	add    0x8(%rdi),%rsi
 10118ec:	mov    %rsi,0x320(%r15)
 10118f3:	mov    %r13,%rdi
 10118f6:	test   %r13,%r13
 10118f9:	jne    1011828 <main+0x20b8>
 10118ff:	mov    0x1860(%r15),%r9
 1011906:	movl   $0x0,(%r14)
 101190d:	mov    $0x400,%edx
 1011912:	mov    %rbx,%rdi
 1011915:	xor    %esi,%esi
 1011917:	mov    %r9,%rbx
 101191a:	call   1027650 <memset@plt>
 101191f:	mov    %rbx,%r8
 1011922:	test   %rbx,%rbx
 1011925:	lea    -0x3790(%rbp),%r14
 101192c:	je     1011c44 <main+0x24d4>
 1011932:	mov    0xf8(%r8),%rbx
 1011939:	movq   $0x0,0xf8(%r8)
 1011944:	test   %rbx,%rbx
 1011947:	je     1011a28 <main+0x22b8>
 101194d:	vpxor  %xmm0,%xmm0,%xmm0
 1011951:	jmp    101197b <main+0x220b>
 1011953:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011960:	add    $0x8,%rbx
 1011964:	vmovdqu %xmm0,(%rbx)
 1011968:	movl   $0x0,0x10(%rbx)
 101196f:	mov    %r12,%rbx
 1011972:	test   %r12,%r12
 1011975:	je     1011a28 <main+0x22b8>
 101197b:	mov    0x8(%rbx),%r12
 101197f:	mov    0x10(%rbx),%rsi
 1011983:	test   %rsi,%rsi
 1011986:	je     1011960 <main+0x21f0>
 1011988:	nopl   0x0(%rax,%rax,1)
 1011990:	mov    (%rsi),%r13
 1011993:	mov    0x1860(%r15),%rax
 101199a:	mov    0x108(%rax),%rcx
 10119a1:	cmp    $0x20,%rcx
 10119a5:	je     1011a01 <main+0x2291>
 10119a7:	mov    0x270(%r15),%rdx
 10119ae:	cmp    $0x28,%rdx
 10119b2:	jb     1011330 <main+0x1bc0>
 10119b8:	mov    0x30(%rax),%rdi
 10119bc:	cmp    $0x27,%rdi
 10119c0:	jbe    1011330 <main+0x1bc0>
 10119c6:	add    $0xffffffffffffffd8,%rdx
 10119ca:	mov    %rdx,0x270(%r15)
 10119d1:	add    $0xffffffffffffffd8,%rdi
 10119d5:	mov    %rdi,0x30(%rax)
 10119d9:	mov    0x100(%rax),%rdx
 10119e0:	mov    %rdx,(%rsi)
 10119e3:	mov    %rsi,0x100(%rax)
 10119ea:	inc    %rcx
 10119ed:	mov    %rcx,0x108(%rax)
 10119f4:	mov    %r13,%rsi
 10119f7:	test   %r13,%r13
 10119fa:	jne    1011990 <main+0x2220>
 10119fc:	jmp    1011960 <main+0x21f0>
 1011a01:	lea    0x258(%r15),%rdi
 1011a08:	mov    %r8,%r14
 1011a0b:	call   101e50f <entry_release>
 1011a10:	vpxor  %xmm0,%xmm0,%xmm0
 1011a14:	mov    %r14,%r8
 1011a17:	mov    %r13,%rsi
 1011a1a:	test   %r13,%r13
 1011a1d:	jne    1011990 <main+0x2220>
 1011a23:	jmp    1011960 <main+0x21f0>
 1011a28:	movl   $0x0,0x124(%r8)
 1011a33:	vpxor  %xmm0,%xmm0,%xmm0
 1011a37:	vmovdqu %xmm0,0xc0(%r8)
 1011a40:	movl   $0x0,0xd0(%r8)
 1011a4b:	mov    0x18(%r8),%rax
 1011a4f:	test   %rax,%rax
 1011a52:	je     1011330 <main+0x1bc0>
 1011a58:	lea    0x258(%r15),%rdi
 1011a5f:	call   *%rax
 1011a61:	lea    -0x3790(%rbp),%r14
 1011a68:	jmp    1011c44 <main+0x24d4>
 1011a6d:	mov    $0x1,%edi
 1011a72:	mov    $0x13c8,%esi
 1011a77:	call   1027690 <calloc@plt>
 1011a7c:	test   %rax,%rax
 1011a7f:	je     10113c3 <main+0x1c53>
 1011a85:	mov    %rax,%r13
 1011a88:	mov    %rbx,0x270(%r15)
 1011a8f:	addq   $0x13c8,0x30(%r12)
 1011a98:	movq   $0x100b298,0x8(%rax)
 1011aa0:	movq   $0x100b268,0x38(%rax)
 1011aa8:	movq   $0x19,0x20(%rax)
 1011ab0:	movq   $0x19,0x28(%rax)
 1011ab8:	movq   $0x13c8,0x30(%rax)
 1011ac0:	mov    %rax,%rdi
 1011ac3:	add    $0x40,%rdi
 1011ac7:	mov    %rdi,0x18(%rax)
 1011acb:	mov    $0x1009ee0,%esi
 1011ad0:	mov    $0x1388,%edx
 1011ad5:	call   10276a0 <memcpy@plt>
 1011ada:	xor    %ebx,%ebx
 1011adc:	cmpq   $0x3,0xb8(%r12)
 1011ae5:	mov    $0x0,%r12d
 1011aeb:	ja     1011b0f <main+0x239f>
 1011aed:	mov    $0x60,%ebx
 1011af2:	mov    $0x60,%esi
 1011af7:	lea    0x258(%r15),%rdi
 1011afe:	call   1018960 <myl_rc_meta_alloc>
 1011b03:	mov    %rax,%r12
 1011b06:	test   %rax,%rax
 1011b09:	je     101202a <main+0x28ba>
 1011b0f:	lea    -0x9f0(%rbp),%r8
 1011b16:	mov    $0x1,%esi
 1011b1b:	mov    $0x32,%edx
 1011b20:	lea    0x258(%r15),%r14
 1011b27:	mov    %r14,%rdi
 1011b2a:	mov    %r13,%rcx
 1011b2d:	call   101a770 <index_prepare>
 1011b32:	test   %eax,%eax
 1011b34:	je     1011fe9 <main+0x2879>
 1011b3a:	lea    -0x9f0(%rbp),%rdx
 1011b41:	mov    %r14,%rdi
 1011b44:	mov    %r13,%rsi
 1011b47:	call   101ab20 <index_commit>
 1011b4c:	mov    0x1860(%r15),%rax
 1011b53:	test   %r12,%r12
 1011b56:	je     1011b8f <main+0x241f>
 1011b58:	mov    0xb0(%rax),%rsi
 1011b5f:	mov    0xb8(%rax),%rax
 1011b66:	shl    $0x3,%rax
 1011b6a:	lea    (%rax,%rax,2),%rdx
 1011b6e:	mov    %r14,%rdi
 1011b71:	call   10189e0 <myl_rc_meta_free>
 1011b76:	mov    0x1860(%r15),%rax
 1011b7d:	mov    %r12,0xb0(%rax)
 1011b84:	movq   $0x4,0xb8(%rax)
 1011b8f:	mov    0x28(%rax),%rcx
 1011b93:	mov    %rcx,0x0(%r13)
 1011b97:	mov    %r13,0x28(%rax)
 1011b9b:	lea    0x258(%r15),%r13
 1011ba2:	mov    0x20(%r15),%rax
 1011ba6:	test   %rax,%rax
 1011ba9:	lea    -0x3790(%rbp),%r14
 1011bb0:	jne    10114f3 <main+0x1d83>
 1011bb6:	jmp    101140b <main+0x1c9b>
 1011bbb:	xor    %ebx,%ebx
 1011bbd:	mov    %r13,%rdi
 1011bc0:	xor    %esi,%esi
 1011bc2:	call   101e520 <myl_rc_scope_unwind>
 1011bc7:	mov    %r13,%rdi
 1011bca:	call   1017320 <myl_native_arena_release>
 1011bcf:	movl   $0x0,(%r12)
 1011bd7:	jmp    1011bec <main+0x247c>
 1011bd9:	nopl   0x0(%rax)
 1011be0:	inc    %rbx
 1011be3:	cmp    $0x80,%rbx
 1011bea:	je     1011c44 <main+0x24d4>
 1011bec:	mov    0x328(%r15,%rbx,8),%rsi
 1011bf4:	movq   $0x0,0x328(%r15,%rbx,8)
 1011c00:	mov    %r13,%rdi
 1011c03:	call   1018d40 <myl_rc_edge_release>
 1011c08:	mov    0x1860(%r15),%rax
 1011c0f:	test   %rax,%rax
 1011c12:	je     1011be0 <main+0x2470>
 1011c14:	cmpq   $0x0,0xc8(%rax)
 1011c1c:	je     1011be0 <main+0x2470>
 1011c1e:	mov    %r13,%rdi
 1011c21:	call   101be30 <myl_rc_drain>
 1011c26:	jmp    1011be0 <main+0x2470>
 1011c28:	nopl   0x0(%rax,%rax,1)
 1011c30:	mov    %rcx,0x39c8(%r15)
 1011c37:	test   %rcx,%rcx
 1011c3a:	je     1011c3f <main+0x24cf>
 1011c3c:	mov    %rax,(%rcx)
 1011c3f:	call   10276f0 <free@plt>
 1011c44:	mov    0x39c8(%r15),%rdi
 1011c4b:	test   %rdi,%rdi
 1011c4e:	je     1011c67 <main+0x24f7>
 1011c50:	mov    (%rdi),%rax
 1011c53:	mov    0x8(%rdi),%rcx
 1011c57:	test   %rax,%rax
 1011c5a:	je     1011c30 <main+0x24c0>
 1011c5c:	mov    %rcx,0x8(%rax)
 1011c60:	test   %rcx,%rcx
 1011c63:	jne    1011c3c <main+0x24cc>
 1011c65:	jmp    1011c3f <main+0x24cf>
 1011c67:	mov    0x39a8(%r15),%rdi
 1011c6e:	call   10276f0 <free@plt>
 1011c73:	mov    0x28(%r15),%rdi
 1011c77:	call   10276f0 <free@plt>
 1011c7c:	mov    0x20(%r15),%rbx
 1011c80:	mov    %r15,%rdi
 1011c83:	call   10276f0 <free@plt>
 1011c88:	test   %rbx,%rbx
 1011c8b:	je     1011ca5 <main+0x2535>
 1011c8d:	mov    $0x2,%r15d
 1011c93:	cmpl   $0x0,-0x1c8(%rbp)
 1011c9a:	jne    1012588 <main+0x2e18>
 1011ca0:	jmp    1011d98 <main+0x2628>
 1011ca5:	mov    -0x3f0(%rbp),%rbx
 1011cac:	cmpb   $0x0,-0x70(%rbp)
 1011cb0:	jne    1011cc1 <main+0x2551>
 1011cb2:	mov    $0x1004ed5,%edi
 1011cb7:	mov    %rbx,%rsi
 1011cba:	xor    %eax,%eax
 1011cbc:	call   10277b0 <printf@plt>
 1011cc1:	movzbl %bl,%r15d
 1011cc5:	jmp    1012588 <main+0x2e18>
 1011cca:	mov    %r14,%rdi
 1011ccd:	call   10276f0 <free@plt>
 1011cd2:	mov    0x1703f(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1011cd9:	mov    (%rax),%rcx
 1011cdc:	mov    $0x1004d77,%edi
 1011ce1:	mov    $0x21,%esi
 1011ce6:	mov    $0x1,%edx
 1011ceb:	call   1027750 <fwrite@plt>
 1011cf0:	jmp    1011fd2 <main+0x2862>
 1011cf5:	xor    %edx,%edx
 1011cf7:	mov    %rdx,%rdi
 1011cfa:	cmp    $0x1,%rsi
 1011cfe:	jne    1011d20 <main+0x25b0>
 1011d00:	jmp    10117ee <main+0x207e>
 1011d05:	data16 cs nopw 0x0(%rax,%rax,1)
 1011d10:	mov    %rdx,%rdi
 1011d13:	mov    %rdi,%rdx
 1011d16:	add    $0xfffffffffffffffe,%rcx
 1011d1a:	je     10117ee <main+0x207e>
 1011d20:	mov    -0x8(%rax,%rcx,8),%rsi
 1011d25:	movq   $0x0,-0x8(%rax,%rcx,8)
 1011d2e:	test   %rsi,%rsi
 1011d31:	je     1011d51 <main+0x25e1>
 1011d33:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011d40:	mov    (%rsi),%rdi
 1011d43:	mov    %rdx,(%rsi)
 1011d46:	mov    %rsi,%rdx
 1011d49:	mov    %rdi,%rsi
 1011d4c:	test   %rdi,%rdi
 1011d4f:	jne    1011d40 <main+0x25d0>
 1011d51:	mov    -0x10(%rax,%rcx,8),%rsi
 1011d56:	movq   $0x0,-0x10(%rax,%rcx,8)
 1011d5f:	test   %rsi,%rsi
 1011d62:	je     1011d10 <main+0x25a0>
 1011d64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011d70:	mov    %rsi,%rdi
 1011d73:	mov    (%rsi),%rsi
 1011d76:	mov    %rdx,(%rdi)
 1011d79:	mov    %rdi,%rdx
 1011d7c:	test   %rsi,%rsi
 1011d7f:	jne    1011d70 <main+0x2600>
 1011d81:	jmp    1011d13 <main+0x25a3>
 1011d83:	mov    $0x1,%r9d
 1011d89:	test   %edx,%edx
 1011d8b:	je     1010a7e <main+0x130e>
 1011d91:	mov    %rcx,-0x3e0(%rbp)
 1011d98:	lea    -0xdf0(%rbp),%rdi
 1011d9f:	mov    $0x400,%edx
 1011da4:	xor    %esi,%esi
 1011da6:	call   1027650 <memset@plt>
 1011dab:	movq   $0x0,-0x9f0(%rbp)
 1011db6:	movb   $0x0,-0xdf0(%rbp)
 1011dbd:	mov    -0x1c0(%rbp),%eax
 1011dc3:	mov    %eax,-0x38(%rbp)
 1011dc6:	test   %eax,%eax
 1011dc8:	je     1012128 <main+0x29b8>
 1011dce:	mov    -0x1bc(%rbp),%ebx
 1011dd4:	test   $0x1,%bl
 1011dd7:	jne    1011e22 <main+0x26b2>
 1011dd9:	test   $0x2,%bl
 1011ddc:	jne    1011ee7 <main+0x2777>
 1011de2:	mov    -0x190(%rbp),%r8
 1011de9:	test   $0x1c,%bl
 1011dec:	jne    1011f12 <main+0x27a2>
 1011df2:	test   %r8,%r8
 1011df5:	je     1012128 <main+0x29b8>
 1011dfb:	cmpb   $0x0,(%r8)
 1011dff:	je     1012128 <main+0x29b8>
 1011e05:	lea    -0xdf0(%rbp),%rdi
 1011e0c:	lea    -0x9f0(%rbp),%rdx
 1011e13:	mov    $0x400,%esi
 1011e18:	mov    $0x1003d57,%ecx
 1011e1d:	jmp    1011f06 <main+0x2796>
 1011e22:	mov    -0x1b8(%rbp),%r8
 1011e29:	lea    -0xdf0(%rbp),%rdi
 1011e30:	lea    -0x9f0(%rbp),%rdx
 1011e37:	mov    $0x400,%esi
 1011e3c:	mov    $0x1004113,%ecx
 1011e41:	xor    %eax,%eax
 1011e43:	call   10154a0 <append>
 1011e48:	test   %eax,%eax
 1011e4a:	je     1012128 <main+0x29b8>
 1011e50:	test   $0x2,%bl
 1011e53:	je     1012109 <main+0x2999>
 1011e59:	mov    -0x1b0(%rbp),%r8
 1011e60:	lea    -0xdf0(%rbp),%rdi
 1011e67:	lea    -0x9f0(%rbp),%rdx
 1011e6e:	mov    $0x400,%esi
 1011e73:	mov    $0x1003cad,%ecx
 1011e78:	xor    %eax,%eax
 1011e7a:	call   10154a0 <append>
 1011e7f:	test   %eax,%eax
 1011e81:	jne    1012109 <main+0x2999>
 1011e87:	jmp    1012128 <main+0x29b8>
 1011e8c:	lea    -0x3790(%rbp),%r14
 1011e93:	mov    0x16e7e(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1011e9a:	mov    (%rax),%rcx
 1011e9d:	mov    $0x1004eda,%edi
 1011ea2:	mov    $0x38,%esi
 1011ea7:	mov    $0x1,%edx
 1011eac:	vzeroupper
 1011eaf:	call   1027750 <fwrite@plt>
 1011eb4:	mov    $0x2,%r15d
 1011eba:	mov    $0x70,%ebx
 1011ebf:	jmp    10125d8 <main+0x2e68>
 1011ec4:	mov    0x16e4d(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1011ecb:	mov    (%rax),%rcx
 1011ece:	mov    $0x1004d45,%edi
 1011ed3:	mov    $0x31,%esi
 1011ed8:	mov    $0x1,%edx
 1011edd:	call   1027750 <fwrite@plt>
 1011ee2:	jmp    1011fca <main+0x285a>
 1011ee7:	mov    -0x1b0(%rbp),%r8
 1011eee:	lea    -0xdf0(%rbp),%rdi
 1011ef5:	lea    -0x9f0(%rbp),%rdx
 1011efc:	mov    $0x400,%esi
 1011f01:	mov    $0x100466f,%ecx
 1011f06:	xor    %eax,%eax
 1011f08:	call   10154a0 <append>
 1011f0d:	jmp    1012128 <main+0x29b8>
 1011f12:	test   %r8,%r8
 1011f15:	mov    $0x10042b6,%eax
 1011f1a:	cmovne %r8,%rax
 1011f1e:	lea    -0xdf0(%rbp),%rdi
 1011f25:	lea    -0x9f0(%rbp),%rdx
 1011f2c:	mov    $0x400,%esi
 1011f31:	mov    $0x100450d,%ecx
 1011f36:	mov    %rax,%r8
 1011f39:	xor    %eax,%eax
 1011f3b:	call   10154a0 <append>
 1011f40:	test   %eax,%eax
 1011f42:	je     1012128 <main+0x29b8>
 1011f48:	test   $0x20,%bl
 1011f4b:	jne    101207c <main+0x290c>
 1011f51:	test   $0x4,%bl
 1011f54:	je     1011f84 <main+0x2814>
 1011f56:	mov    -0x1a8(%rbp),%r8
 1011f5d:	lea    -0xdf0(%rbp),%rdi
 1011f64:	lea    -0x9f0(%rbp),%rdx
 1011f6b:	mov    $0x400,%esi
 1011f70:	mov    $0x100412b,%ecx
 1011f75:	xor    %eax,%eax
 1011f77:	call   10154a0 <append>
 1011f7c:	test   %eax,%eax
 1011f7e:	je     1012128 <main+0x29b8>
 1011f84:	test   $0x8,%bl
 1011f87:	je     10120da <main+0x296a>
 1011f8d:	mov    -0x1a0(%rbp),%r8
 1011f94:	lea    -0xdf0(%rbp),%rdi
 1011f9b:	lea    -0x9f0(%rbp),%rdx
 1011fa2:	mov    $0x400,%esi
 1011fa7:	mov    $0x100411f,%ecx
 1011fac:	jmp    10120cf <main+0x295f>
 1011fb1:	mov    $0x1004766,%esi
 1011fb6:	mov    0x16d5b(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1011fbd:	mov    (%rax),%rdi
 1011fc0:	mov    %r15,%rdx
 1011fc3:	xor    %eax,%eax
 1011fc5:	call   1027760 <fprintf@plt>
 1011fca:	mov    %r14,%rdi
 1011fcd:	call   10276f0 <free@plt>
 1011fd2:	mov    -0x90(%rbp),%rdi
 1011fd9:	call   10276f0 <free@plt>
 1011fde:	mov    $0x2,%r15d
 1011fe4:	jmp    101266a <main+0x2efa>
 1011fe9:	mov    %r12,%rax
 1011fec:	mov    0x270(%r15),%r12
 1011ff3:	test   %rax,%rax
 1011ff6:	je     1012031 <main+0x28c1>
 1011ff8:	sub    %rbx,%r12
 1011ffb:	jb     1011330 <main+0x1bc0>
 1012001:	mov    %rax,%rdi
 1012004:	mov    0x1860(%r15),%rax
 101200b:	mov    0x30(%rax),%rcx
 101200f:	sub    %rbx,%rcx
 1012012:	jb     1011330 <main+0x1bc0>
 1012018:	mov    %r12,0x270(%r15)
 101201f:	mov    %rcx,0x30(%rax)
 1012023:	call   10276f0 <free@plt>
 1012028:	jmp    1012031 <main+0x28c1>
 101202a:	mov    0x270(%r15),%r12
 1012031:	cmp    $0x13c8,%r12
 1012038:	jb     1011330 <main+0x1bc0>
 101203e:	mov    0x1860(%r15),%rax
 1012045:	mov    0x30(%rax),%rcx
 1012049:	cmp    $0x13c7,%rcx
 1012050:	jbe    1011330 <main+0x1bc0>
 1012056:	add    $0xffffffffffffec38,%r12
 101205d:	mov    %r12,0x270(%r15)
 1012064:	add    $0xffffffffffffec38,%rcx
 101206b:	mov    %rcx,0x30(%rax)
 101206f:	mov    %r13,%rdi
 1012072:	call   10276f0 <free@plt>
 1012077:	jmp    10113c3 <main+0x1c53>
 101207c:	test   $0x4,%bl
 101207f:	je     10120ab <main+0x293b>
 1012081:	mov    -0x1a8(%rbp),%r8
 1012088:	lea    -0xdf0(%rbp),%rdi
 101208f:	lea    -0x9f0(%rbp),%rdx
 1012096:	mov    $0x400,%esi
 101209b:	mov    $0x1003ca3,%ecx
 10120a0:	xor    %eax,%eax
 10120a2:	call   10154a0 <append>
 10120a7:	test   %eax,%eax
 10120a9:	je     1012128 <main+0x29b8>
 10120ab:	test   $0x8,%bl
 10120ae:	je     10120da <main+0x296a>
 10120b0:	mov    -0x1a0(%rbp),%r8
 10120b7:	lea    -0xdf0(%rbp),%rdi
 10120be:	lea    -0x9f0(%rbp),%rdx
 10120c5:	mov    $0x400,%esi
 10120ca:	mov    $0x1003c97,%ecx
 10120cf:	xor    %eax,%eax
 10120d1:	call   10154a0 <append>
 10120d6:	test   %eax,%eax
 10120d8:	je     1012128 <main+0x29b8>
 10120da:	test   $0x10,%bl
 10120dd:	je     1012109 <main+0x2999>
 10120df:	mov    -0x198(%rbp),%r8
 10120e6:	lea    -0xdf0(%rbp),%rdi
 10120ed:	lea    -0x9f0(%rbp),%rdx
 10120f4:	mov    $0x400,%esi
 10120f9:	mov    $0x1003cba,%ecx
 10120fe:	xor    %eax,%eax
 1012100:	call   10154a0 <append>
 1012105:	test   %eax,%eax
 1012107:	je     1012128 <main+0x29b8>
 1012109:	lea    -0xdf0(%rbp),%rdi
 1012110:	lea    -0x9f0(%rbp),%rdx
 1012117:	mov    $0x400,%esi
 101211c:	mov    $0x1004702,%ecx
 1012121:	xor    %eax,%eax
 1012123:	call   10154a0 <append>
 1012128:	mov    -0x3e0(%rbp),%r14
 101212f:	mov    $0x100438a,%esi
 1012134:	mov    %r14,%rdi
 1012137:	call   10276c0 <strcmp@plt>
 101213c:	test   %eax,%eax
 101213e:	sete   %al
 1012141:	mov    -0x1d8(%rbp),%r15
 1012148:	cmp    $0x2,%r15
 101214c:	setae  %cl
 101214f:	and    %al,%cl
 1012151:	cmp    $0x1,%cl
 1012154:	jne    10121a4 <main+0x2a34>
 1012156:	lea    -0xdf0(%rbp),%r13
 101215d:	mov    %r13,%rdi
 1012160:	call   1027670 <strlen@plt>
 1012165:	mov    %rax,-0x9f0(%rbp)
 101216c:	mov    -0x3b8(%rbp),%r8
 1012173:	mov    -0x3b0(%rbp),%r9
 101217a:	vmovdqu -0x3a8(%rbp),%xmm0
 1012182:	vmovdqu %xmm0,(%rsp)
 1012187:	lea    -0x9f0(%rbp),%rdx
 101218e:	mov    $0x400,%esi
 1012193:	mov    $0x1003c3b,%ecx
 1012198:	mov    %r13,%rdi
 101219b:	xor    %eax,%eax
 101219d:	call   10154a0 <append>
 10121a2:	jmp    10121df <main+0x2a6f>
 10121a4:	test   %r15,%r15
 10121a7:	jne    10121df <main+0x2a6f>
 10121a9:	mov    0x16b68(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 10121b0:	mov    (%rax),%r12
 10121b3:	mov    %r14,%rdi
 10121b6:	call   1015560 <describe>
 10121bb:	lea    -0xdf0(%rbp),%r8
 10121c2:	mov    $0x10048a4,%esi
 10121c7:	mov    %r12,%rdi
 10121ca:	mov    %r14,%rbx
 10121cd:	mov    %r14,%rdx
 10121d0:	mov    %rax,%rcx
 10121d3:	xor    %eax,%eax
 10121d5:	call   1027760 <fprintf@plt>
 10121da:	jmp    1012277 <main+0x2b07>
 10121df:	mov    0x16b32(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 10121e6:	mov    (%rax),%r13
 10121e9:	mov    -0x3d0(%rbp),%rax
 10121f0:	mov    %rax,-0x30(%rbp)
 10121f4:	mov    -0x3c8(%rbp),%rax
 10121fb:	mov    %rax,-0x40(%rbp)
 10121ff:	lea    -0x3c0(%rbp),%r12
 1012206:	mov    -0x3c0(%rbp),%rbx
 101220d:	mov    %r14,%rdi
 1012210:	call   1015560 <describe>
 1012215:	lea    -0xdf0(%rbp),%rcx
 101221c:	mov    %rcx,0x8(%rsp)
 1012221:	mov    %rax,(%rsp)
 1012225:	mov    $0x10048ae,%esi
 101222a:	mov    %r13,%rdi
 101222d:	mov    -0x30(%rbp),%rdx
 1012231:	mov    -0x40(%rbp),%rcx
 1012235:	mov    %rbx,%r8
 1012238:	mov    %r14,%rbx
 101223b:	mov    %r14,%r9
 101223e:	mov    0x16ad3(%rip),%r14        # 1028d18 <stderr@GLIBC_2.2.5>
 1012245:	xor    %eax,%eax
 1012247:	call   1027760 <fprintf@plt>
 101224c:	mov    -0x18(%r12),%rdx
 1012251:	mov    -0x10(%r12),%rcx
 1012256:	mov    -0x8(%r12),%r8
 101225b:	mov    (%r12),%r9
 101225f:	mov    (%r14),%rdi
 1012262:	mov    $0x100474f,%esi
 1012267:	xor    %eax,%eax
 1012269:	call   1027760 <fprintf@plt>
 101226e:	add    $0x20,%r12
 1012272:	dec    %r15
 1012275:	jne    101224c <main+0x2adc>
 1012277:	movq   $0x0,-0x48(%rbp)
 101227f:	movb   $0x0,-0x9f0(%rbp)
 1012286:	mov    -0x38(%rbp),%r8d
 101228a:	test   %r8d,%r8d
 101228d:	je     1012520 <main+0x2db0>
 1012293:	mov    -0x1bc(%rbp),%eax
 1012299:	mov    %eax,-0x30(%rbp)
 101229c:	lea    -0x9f0(%rbp),%rdi
 10122a3:	lea    -0x48(%rbp),%rdx
 10122a7:	mov    $0x600,%esi
 10122ac:	mov    $0x1004513,%ecx
 10122b1:	xor    %eax,%eax
 10122b3:	call   10154a0 <append>
 10122b8:	test   %eax,%eax
 10122ba:	je     1012520 <main+0x2db0>
 10122c0:	mov    -0x190(%rbp),%r14
 10122c7:	lea    -0x9f0(%rbp),%rdi
 10122ce:	lea    -0x48(%rbp),%rdx
 10122d2:	mov    $0x600,%esi
 10122d7:	mov    $0x1004704,%ecx
 10122dc:	xor    %eax,%eax
 10122de:	call   10154a0 <append>
 10122e3:	test   %eax,%eax
 10122e5:	je     1012520 <main+0x2db0>
 10122eb:	test   %r14,%r14
 10122ee:	mov    $0x1003e6d,%r13d
 10122f4:	cmovne %r14,%r13
 10122f8:	movzbl 0x0(%r13),%eax
 10122fd:	test   %al,%al
 10122ff:	je     1012366 <main+0x2bf6>
 1012301:	inc    %r13
 1012304:	lea    -0x9f0(%rbp),%r15
 101230b:	lea    -0x48(%rbp),%r12
 101230f:	nop
 1012310:	movzbl %al,%r8d
 1012314:	cmp    $0x5c,%r8b
 1012318:	je     1012320 <main+0x2bb0>
 101231a:	cmp    $0x22,%r8d
 101231e:	jne    101234d <main+0x2bdd>
 1012320:	mov    $0x600,%esi
 1012325:	mov    $0x10042c1,%ecx
 101232a:	mov    %r15,%rdi
 101232d:	mov    %r12,%rdx
 1012330:	xor    %eax,%eax
 1012332:	call   10154a0 <append>
 1012337:	test   %eax,%eax
 1012339:	je     1012520 <main+0x2db0>
 101233f:	movzbl 0x0(%r13),%eax
 1012344:	inc    %r13
 1012347:	test   %al,%al
 1012349:	jne    1012310 <main+0x2ba0>
 101234b:	jmp    1012366 <main+0x2bf6>
 101234d:	mov    $0x600,%esi
 1012352:	cmp    $0x1f,%r8b
 1012356:	ja     101235f <main+0x2bef>
 1012358:	mov    $0x1003c28,%ecx
 101235d:	jmp    101232a <main+0x2bba>
 101235f:	mov    $0x10042c2,%ecx
 1012364:	jmp    101232a <main+0x2bba>
 1012366:	lea    -0x9f0(%rbp),%rdi
 101236d:	lea    -0x48(%rbp),%rdx
 1012371:	mov    $0x600,%esi
 1012376:	mov    $0x1004704,%ecx
 101237b:	xor    %eax,%eax
 101237d:	call   10154a0 <append>
 1012382:	test   %eax,%eax
 1012384:	je     1012520 <main+0x2db0>
 101238a:	testb  $0x1,-0x30(%rbp)
 101238e:	je     10123bb <main+0x2c4b>
 1012390:	mov    -0x1b8(%rbp),%r8
 1012397:	lea    -0x9f0(%rbp),%rdi
 101239e:	lea    -0x48(%rbp),%rdx
 10123a2:	mov    $0x600,%esi
 10123a7:	mov    $0x10040ed,%ecx
 10123ac:	xor    %eax,%eax
 10123ae:	call   10154a0 <append>
 10123b3:	test   %eax,%eax
 10123b5:	je     1012520 <main+0x2db0>
 10123bb:	testb  $0x2,-0x30(%rbp)
 10123bf:	je     10123ec <main+0x2c7c>
 10123c1:	mov    -0x1b0(%rbp),%r8
 10123c8:	lea    -0x9f0(%rbp),%rdi
 10123cf:	lea    -0x48(%rbp),%rdx
 10123d3:	mov    $0x600,%esi
 10123d8:	mov    $0x1003c7c,%ecx
 10123dd:	xor    %eax,%eax
 10123df:	call   10154a0 <append>
 10123e4:	test   %eax,%eax
 10123e6:	je     1012520 <main+0x2db0>
 10123ec:	mov    -0x30(%rbp),%eax
 10123ef:	test   $0x20,%al
 10123f1:	jne    101244a <main+0x2cda>
 10123f3:	test   $0x4,%al
 10123f5:	je     1012422 <main+0x2cb2>
 10123f7:	mov    -0x1a8(%rbp),%r8
 10123fe:	lea    -0x9f0(%rbp),%rdi
 1012405:	lea    -0x48(%rbp),%rdx
 1012409:	mov    $0x600,%esi
 101240e:	mov    $0x1004107,%ecx
 1012413:	xor    %eax,%eax
 1012415:	call   10154a0 <append>
 101241a:	test   %eax,%eax
 101241c:	je     1012520 <main+0x2db0>
 1012422:	testb  $0x8,-0x30(%rbp)
 1012426:	je     10124cc <main+0x2d5c>
 101242c:	mov    -0x1a0(%rbp),%r8
 1012433:	lea    -0x9f0(%rbp),%rdi
 101243a:	lea    -0x48(%rbp),%rdx
 101243e:	mov    $0x600,%esi
 1012443:	mov    $0x10040fa,%ecx
 1012448:	jmp    10124c1 <main+0x2d51>
 101244a:	lea    -0x9f0(%rbp),%rdi
 1012451:	lea    -0x48(%rbp),%rdx
 1012455:	mov    $0x600,%esi
 101245a:	mov    $0x10040bd,%ecx
 101245f:	xor    %eax,%eax
 1012461:	call   10154a0 <append>
 1012466:	test   %eax,%eax
 1012468:	je     1012520 <main+0x2db0>
 101246e:	testb  $0x4,-0x30(%rbp)
 1012472:	je     101249f <main+0x2d2f>
 1012474:	mov    -0x1a8(%rbp),%r8
 101247b:	lea    -0x9f0(%rbp),%rdi
 1012482:	lea    -0x48(%rbp),%rdx
 1012486:	mov    $0x600,%esi
 101248b:	mov    $0x1003c70,%ecx
 1012490:	xor    %eax,%eax
 1012492:	call   10154a0 <append>
 1012497:	test   %eax,%eax
 1012499:	je     1012520 <main+0x2db0>
 101249f:	testb  $0x8,-0x30(%rbp)
 10124a3:	je     10124cc <main+0x2d5c>
 10124a5:	mov    -0x1a0(%rbp),%r8
 10124ac:	lea    -0x9f0(%rbp),%rdi
 10124b3:	lea    -0x48(%rbp),%rdx
 10124b7:	mov    $0x600,%esi
 10124bc:	mov    $0x1003c63,%ecx
 10124c1:	xor    %eax,%eax
 10124c3:	call   10154a0 <append>
 10124c8:	test   %eax,%eax
 10124ca:	je     1012520 <main+0x2db0>
 10124cc:	testb  $0x10,-0x30(%rbp)
 10124d0:	je     10124f9 <main+0x2d89>
 10124d2:	mov    -0x198(%rbp),%r8
 10124d9:	lea    -0x9f0(%rbp),%rdi
 10124e0:	lea    -0x48(%rbp),%rdx
 10124e4:	mov    $0x600,%esi
 10124e9:	mov    $0x1003c8a,%ecx
 10124ee:	xor    %eax,%eax
 10124f0:	call   10154a0 <append>
 10124f5:	test   %eax,%eax
 10124f7:	je     1012520 <main+0x2db0>
 10124f9:	lea    -0x9f0(%rbp),%rdi
 1012500:	lea    -0x48(%rbp),%rdx
 1012504:	mov    $0x600,%esi
 1012509:	mov    $0x1003b90,%ecx
 101250e:	xor    %eax,%eax
 1012510:	call   10154a0 <append>
 1012515:	test   %eax,%eax
 1012517:	je     1012520 <main+0x2db0>
 1012519:	cmpq   $0x0,-0x48(%rbp)
 101251e:	jne    1012554 <main+0x2de4>
 1012520:	mov    $0x2,%r15d
 1012526:	cmpb   $0x52,(%rbx)
 1012529:	lea    -0x3790(%rbp),%r14
 1012530:	jne    1012588 <main+0x2e18>
 1012532:	xor    %r15d,%r15d
 1012535:	cmpb   $0x5f,0x1(%rbx)
 1012539:	setne  %r15b
 101253d:	inc    %r15d
 1012540:	mov    $0x70,%ebx
 1012545:	jmp    10125d8 <main+0x2e68>
 101254a:	mov    $0x10048df,%esi
 101254f:	jmp    1011fb6 <main+0x2846>
 1012554:	mov    0x167bd(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 101255b:	mov    (%rax),%rdi
 101255e:	lea    -0x9f0(%rbp),%rcx
 1012565:	mov    $0x10048c5,%esi
 101256a:	mov    $0x1004706,%edx
 101256f:	xor    %eax,%eax
 1012571:	call   1027760 <fprintf@plt>
 1012576:	mov    $0x2,%r15d
 101257c:	cmpb   $0x52,(%rbx)
 101257f:	lea    -0x3790(%rbp),%r14
 1012586:	je     1012532 <main+0x2dc2>
 1012588:	mov    $0x70,%ebx
 101258d:	jmp    10125d8 <main+0x2e68>
 101258f:	nop
 1012590:	vzeroupper
 1012593:	call   10277c0 <close@plt>
 1012598:	mov    -0x3790(%rbp,%rbx,1),%rdi
 10125a0:	vzeroupper
 10125a3:	call   10276f0 <free@plt>
 10125a8:	movl   $0xffffffff,-0x3798(%rbp,%rbx,1)
 10125b3:	vpxor  %xmm0,%xmm0,%xmm0
 10125b7:	vmovdqu %ymm0,-0x3794(%rbp,%rbx,1)
 10125c0:	movl   $0x0,-0x3774(%rbp,%rbx,1)
 10125cb:	add    $0x28,%rbx
 10125cf:	cmp    $0x2870,%rbx
 10125d6:	je     10125f2 <main+0x2e82>
 10125d8:	mov    -0x3798(%rbp,%rbx,1),%edi
 10125df:	test   %edi,%edi
 10125e1:	jns    1012590 <main+0x2e20>
 10125e3:	mov    -0x3790(%rbp,%rbx,1),%rdi
 10125eb:	test   %rdi,%rdi
 10125ee:	jne    10125a0 <main+0x2e30>
 10125f0:	jmp    10125cb <main+0x2e5b>
 10125f2:	cmpq   $0x0,-0x3730(%rbp)
 10125fa:	je     101261b <main+0x2eab>
 10125fc:	xor    %ebx,%ebx
 10125fe:	xchg   %ax,%ax
 1012600:	mov    (%r14),%edi
 1012603:	vzeroupper
 1012606:	call   10277c0 <close@plt>
 101260b:	inc    %rbx
 101260e:	add    $0xc,%r14
 1012612:	cmp    -0x3730(%rbp),%rbx
 1012619:	jb     1012600 <main+0x2e90>
 101261b:	movq   $0x0,-0x3730(%rbp)
 1012626:	cmpq   $0x0,-0xea8(%rbp)
 101262e:	je     101265b <main+0x2eeb>
 1012630:	lea    -0xf28(%rbp),%rbx
 1012637:	xor    %r14d,%r14d
 101263a:	nopw   0x0(%rax,%rax,1)
 1012640:	mov    (%rbx),%rdi
 1012643:	vzeroupper
 1012646:	call   10276f0 <free@plt>
 101264b:	inc    %r14
 101264e:	add    $0x10,%rbx
 1012652:	cmp    -0xea8(%rbp),%r14
 1012659:	jb     1012640 <main+0x2ed0>
 101265b:	mov    -0x90(%rbp),%rdi
 1012662:	vzeroupper
 1012665:	call   10276f0 <free@plt>
 101266a:	mov    %r15d,%eax
 101266d:	add    $0x3778,%rsp
 1012674:	pop    %rbx
 1012675:	pop    %r12
 1012677:	pop    %r13
 1012679:	pop    %r14
 101267b:	pop    %r15
 101267d:	pop    %rbp
 101267e:	ret
 101267f:	int3

0000000001012680 <entry_run>:
 1012680:	push   %rbp
 1012681:	mov    %rsp,%rbp
 1012684:	push   %r15
 1012686:	push   %r14
 1012688:	push   %r13
 101268a:	push   %r12
 101268c:	push   %rbx
 101268d:	sub    $0x408,%rsp
 1012694:	mov    %rdi,%r9
 1012697:	cmpq   $0x0,0x39a8(%rdi)
 101269f:	mov    %rdi,-0x30(%rbp)
 10126a3:	je     10126b5 <entry_run+0x35>
 10126a5:	cmpq   $0x0,0x20(%r9)
 10126aa:	jne    10144b0 <entry_run+0x1e30>
 10126b0:	jmp    10127cd <entry_run+0x14d>
 10126b5:	mov    $0x1,%edi
 10126ba:	mov    $0x40,%esi
 10126bf:	call   1027690 <calloc@plt>
 10126c4:	test   %rax,%rax
 10126c7:	je     1012798 <entry_run+0x118>
 10126cd:	mov    -0x30(%rbp),%r9
 10126d1:	mov    %rax,0x39a8(%r9)
 10126d8:	mov    0x3978(%r9),%rcx
 10126df:	lea    0xa0(%rcx),%rdx
 10126e6:	test   %rcx,%rcx
 10126e9:	mov    $0x1003b58,%ecx
 10126ee:	cmovne %rdx,%rcx
 10126f2:	mov    %rcx,(%rax)
 10126f5:	cmpq   $0x0,0x8(%rcx)
 10126fa:	je     1012706 <entry_run+0x86>
 10126fc:	cmpq   $0x0,(%rcx)
 1012700:	je     10127a3 <entry_run+0x123>
 1012706:	mov    0x10(%rcx),%rdx
 101270a:	test   %rdx,%rdx
 101270d:	mov    $0x2710,%esi
 1012712:	cmovne %rdx,%rsi
 1012716:	mov    %rsi,0x18(%rax)
 101271a:	mov    0x18(%rcx),%rdx
 101271e:	test   %rdx,%rdx
 1012721:	mov    $0xf4240,%esi
 1012726:	cmovne %rdx,%rsi
 101272a:	mov    %rsi,0x10(%rax)
 101272e:	mov    0x20(%rcx),%rdx
 1012732:	test   %rdx,%rdx
 1012735:	mov    $0x10000,%edi
 101273a:	cmovne %rdx,%rdi
 101273e:	mov    %rdi,0x20(%rax)
 1012742:	mov    0x28(%rcx),%rsi
 1012746:	test   %rsi,%rsi
 1012749:	mov    $0x40,%edx
 101274e:	cmovne %rsi,%rdx
 1012752:	mov    %rdx,0x28(%rax)
 1012756:	mov    0x30(%rcx),%r8
 101275a:	test   %r8,%r8
 101275d:	mov    $0x100000,%esi
 1012762:	cmovne %r8,%rsi
 1012766:	mov    %rsi,0x30(%rax)
 101276a:	cmp    $0x186a0,%rdi
 1012771:	ja     1012791 <entry_run+0x111>
 1012773:	cmp    $0x81,%rdx
 101277a:	setae  %dl
 101277d:	cmp    $0x4000001,%rsi
 1012784:	setae  %sil
 1012788:	or     %dl,%sil
 101278b:	cmp    $0x1,%sil
 101278f:	jne    10127aa <entry_run+0x12a>
 1012791:	mov    $0x1003cfa,%esi
 1012796:	jmp    10127ba <entry_run+0x13a>
 1012798:	mov    $0x1003b92,%esi
 101279d:	mov    -0x30(%rbp),%r9
 10127a1:	jmp    10127ba <entry_run+0x13a>
 10127a3:	mov    $0x1003e55,%esi
 10127a8:	jmp    10127ba <entry_run+0x13a>
 10127aa:	cmpq   $0x0,0x8(%rcx)
 10127af:	je     1013177 <entry_run+0xaf7>
 10127b5:	mov    $0x1003e41,%esi
 10127ba:	mov    %r9,%rdi
 10127bd:	call   1014ab0 <fail>
 10127c2:	cmpq   $0x0,0x20(%r9)
 10127c7:	jne    10144b0 <entry_run+0x1e30>
 10127cd:	cmp    %rsp,0x40(%r9)
 10127d1:	ja     10145ce <entry_run+0x1f4e>
 10127d7:	movq   $0x0,-0x48(%rbp)
 10127df:	movq   $0x0,-0x80(%rbp)
 10127e7:	mov    0x2c8(%r9),%ebx
 10127ee:	movl   $0x0,-0x50(%rbp)
 10127f5:	cmpq   $0xffffffffffffffff,0x10(%r9)
 10127fa:	je     101283c <entry_run+0x1bc>
 10127fc:	cmpq   $0x0,0x20(%r9)
 1012801:	jne    101282f <entry_run+0x1af>
 1012803:	movl   $0x1,0x39e8(%r9)
 101280e:	vxorpd %xmm0,%xmm0,%xmm0
 1012812:	vmovupd %ymm0,0x39ec(%r9)
 101281b:	vmovupd %ymm0,0x39f8(%r9)
 1012824:	movq   $0x1003f61,0x3a18(%r9)
 101282f:	mov    $0x100442d,%esi
 1012834:	mov    %r9,%rdi
 1012837:	call   1014ab0 <fail>
 101283c:	cmpq   $0xffffffffffffffff,0x38(%r9)
 1012841:	je     1012883 <entry_run+0x203>
 1012843:	cmpq   $0x0,0x20(%r9)
 1012848:	jne    1012876 <entry_run+0x1f6>
 101284a:	movl   $0x1,0x39e8(%r9)
 1012855:	vxorpd %xmm0,%xmm0,%xmm0
 1012859:	vmovupd %ymm0,0x39ec(%r9)
 1012862:	vmovupd %ymm0,0x39f8(%r9)
 101286b:	movq   $0x1003faa,0x3a18(%r9)
 1012876:	mov    $0x1004442,%esi
 101287b:	mov    %r9,%rdi
 101287e:	call   1014ab0 <fail>
 1012883:	cmpq   $0x0,0x1860(%r9)
 101288b:	je     10145c3 <entry_run+0x1f43>
 1012891:	lea    0x258(%r9),%rdi
 1012898:	mov    0x2c8(%r9),%ecx
 101289f:	mov    $0x10022c8,%esi
 10128a4:	mov    $0x6,%edx
 10128a9:	mov    %rdi,-0x38(%rbp)
 10128ad:	vzeroupper
 10128b0:	call   10178c0 <rc_list_new>
 10128b5:	mov    -0x30(%rbp),%r9
 10128b9:	test   %rax,%rax
 10128bc:	je     10145c3 <entry_run+0x1f43>
 10128c2:	movabs $0x5000000000000000,%rcx
 10128cc:	mov    %rax,-0x1c0(%rbp)
 10128d3:	mov    %rax,-0x58(%rbp)
 10128d7:	mov    -0x10(%rax),%rdx
 10128db:	lea    0x1(%rcx),%rsi
 10128df:	test   %rsi,%rdx
 10128e2:	je     1012a13 <entry_run+0x393>
 10128e8:	test   %rcx,%rdx
 10128eb:	je     10129eb <entry_run+0x36b>
 10128f1:	mov    0x1860(%r9),%rdi
 10128f8:	cmpq   $0x1a,0xa0(%rdi)
 1012900:	jb     10143f6 <entry_run+0x1d76>
 1012906:	mov    0x98(%rdi),%rax
 101290d:	cmpq   $0x1002338,0x190(%rax)
 1012918:	jne    10143f6 <entry_run+0x1d76>
 101291e:	mov    0x198(%rax),%r12
 1012925:	test   %r12,%r12
 1012928:	je     101440c <entry_run+0x1d8c>
 101292e:	mov    0x8(%r12),%r14
 1012933:	cmpl   $0x1,0x8(%r14)
 1012938:	jne    1012a20 <entry_run+0x3a0>
 101293e:	movq   $0x0,-0xf8(%rbp)
 1012949:	mov    0x1860(%r9),%rcx
 1012950:	test   %rcx,%rcx
 1012953:	je     10144f8 <entry_run+0x1e78>
 1012959:	mov    $0x3,%eax
 101295e:	cmp    0x2c8(%r9),%ebx
 1012965:	ja     1012aab <entry_run+0x42b>
 101296b:	mov    -0x58(%rbp),%rax
 101296f:	test   %rax,%rax
 1012972:	je     10129b9 <entry_run+0x339>
 1012974:	mov    -0x10(%rax),%rdx
 1012978:	test   $0x2,%dl
 101297b:	jne    10129b9 <entry_run+0x339>
 101297d:	movabs $0x4000000000000002,%rsi
 1012987:	add    $0xfffffffffffffffe,%rsi
 101298b:	test   %rsi,%rdx
 101298e:	sete   %sil
 1012992:	mov    %rdx,%rdi
 1012995:	shr    $0x28,%rdi
 1012999:	and    $0xfffff,%edi
 101299f:	cmp    %ebx,%edi
 10129a1:	setbe  %dil
 10129a5:	bt     $0x3c,%rdx
 10129aa:	jb     101433a <entry_run+0x1cba>
 10129b0:	or     %dil,%sil
 10129b3:	je     101433a <entry_run+0x1cba>
 10129b9:	mov    %rax,-0xf8(%rbp)
 10129c0:	movq   $0x0,-0x58(%rbp)
 10129c8:	cmpq   $0x0,0xc8(%rcx)
 10129d0:	je     10129df <entry_run+0x35f>
 10129d2:	mov    -0x38(%rbp),%rdi
 10129d6:	call   101be30 <myl_rc_drain>
 10129db:	mov    -0x30(%rbp),%r9
 10129df:	mov    -0xf8(%rbp),%rax
 10129e6:	jmp    1012b15 <entry_run+0x495>
 10129eb:	lea    -0x58(%rbp),%rcx
 10129ef:	lea    -0x1c0(%rbp),%rdx
 10129f6:	mov    %rdx,%rsi
 10129f9:	sub    %rcx,%rsi
 10129fc:	sub    %rdx,%rcx
 10129ff:	cmovb  %rsi,%rcx
 1012a03:	test   %rcx,%rcx
 1012a06:	je     10128f1 <entry_run+0x271>
 1012a0c:	mov    %rax,-0x1c0(%rbp)
 1012a13:	movq   $0x0,-0x58(%rbp)
 1012a1b:	jmp    1012b29 <entry_run+0x4a9>
 1012a20:	mov    0x1860(%r9),%rax
 1012a27:	cmpq   $0x0,0xc8(%rax)
 1012a2f:	je     1012abe <entry_run+0x43e>
 1012a35:	mov    %r14,-0xf8(%rbp)
 1012a3c:	lea    -0x260(%rbp),%rdx
 1012a43:	mov    %rdx,-0xf0(%rbp)
 1012a4a:	movq   $0x0,-0xe8(%rbp)
 1012a55:	mov    %ebx,-0xe0(%rbp)
 1012a5b:	movl   $0x0,-0xdc(%rbp)
 1012a65:	lea    -0x58(%rbp),%rcx
 1012a69:	mov    -0x38(%rbp),%rdi
 1012a6d:	mov    %r12,%rsi
 1012a70:	mov    %ebx,%r8d
 1012a73:	call   10237d0 <flat_transfer>
 1012a78:	test   %eax,%eax
 1012a7a:	jns    1012a93 <entry_run+0x413>
 1012a7c:	lea    -0xf8(%rbp),%rsi
 1012a83:	lea    -0x58(%rbp),%rcx
 1012a87:	mov    -0x38(%rbp),%rdi
 1012a8b:	mov    %r14,%rdx
 1012a8e:	call   101eb00 <transfer>
 1012a93:	test   %eax,%eax
 1012a95:	mov    -0x30(%rbp),%r9
 1012a99:	je     1012b0e <entry_run+0x48e>
 1012a9b:	mov    0x1860(%r9),%rcx
 1012aa2:	test   %rcx,%rcx
 1012aa5:	je     10144f8 <entry_run+0x1e78>
 1012aab:	xor    %edx,%edx
 1012aad:	cmpl   $0x0,0x124(%rcx)
 1012ab4:	jne    1012b21 <entry_run+0x4a1>
 1012ab6:	mov    %eax,0x124(%rcx)
 1012abc:	jmp    1012b21 <entry_run+0x4a1>
 1012abe:	lea    -0x1c0(%rbp),%rdx
 1012ac5:	lea    -0x58(%rbp),%rcx
 1012ac9:	mov    -0x38(%rbp),%rdi
 1012acd:	mov    %r12,%rsi
 1012ad0:	mov    %ebx,%r8d
 1012ad3:	call   10237d0 <flat_transfer>
 1012ad8:	test   %eax,%eax
 1012ada:	js     1012a35 <entry_run+0x3b5>
 1012ae0:	mov    -0x30(%rbp),%r9
 1012ae4:	je     1012b29 <entry_run+0x4a9>
 1012ae6:	mov    0x1860(%r9),%rcx
 1012aed:	test   %rcx,%rcx
 1012af0:	je     10144f8 <entry_run+0x1e78>
 1012af6:	cmpl   $0x0,0x124(%rcx)
 1012afd:	jne    101445c <entry_run+0x1ddc>
 1012b03:	mov    %eax,0x124(%rcx)
 1012b09:	jmp    101445c <entry_run+0x1ddc>
 1012b0e:	mov    -0x260(%rbp),%rax
 1012b15:	mov    %rax,-0x1c0(%rbp)
 1012b1c:	mov    $0x1,%edx
 1012b21:	test   %edx,%edx
 1012b23:	je     101445c <entry_run+0x1ddc>
 1012b29:	mov    %ebx,-0x40(%rbp)
 1012b2c:	movabs $0x6000000000000002,%rbx
 1012b36:	mov    -0x1c0(%rbp),%r12
 1012b3d:	mov    %r12,-0x48(%rbp)
 1012b41:	movl   $0x1,-0x50(%rbp)
 1012b48:	movq   $0x0,-0xf8(%rbp)
 1012b53:	movabs $0xc08f400000000000,%rax
 1012b5d:	mov    %rax,-0xf0(%rbp)
 1012b64:	vmovapd -0x111ac(%rip),%ymm0        # 10019c0 <__abi_tag+0x16c4>
 1012b6c:	vmovupd %ymm0,-0xe8(%rbp)
 1012b74:	movabs $0x3fe0000000000000,%rax
 1012b7e:	mov    %rax,-0xc8(%rbp)
 1012b85:	test   %r12,%r12
 1012b88:	je     1012bc9 <entry_run+0x549>
 1012b8a:	test   %rbx,-0x10(%r12)
 1012b8f:	jne    1012b99 <entry_run+0x519>
 1012b91:	cmpq   $0x2,-0x20(%r12)
 1012b97:	jb     1012bbc <entry_run+0x53c>
 1012b99:	lea    -0x48(%rbp),%rsi
 1012b9d:	lea    -0x50(%rbp),%rdx
 1012ba1:	mov    %r9,%rdi
 1012ba4:	vzeroupper
 1012ba7:	call   1014780 <myl_qbe_rc_unique_local>
 1012bac:	test   %eax,%eax
 1012bae:	je     10144b0 <entry_run+0x1e30>
 1012bb4:	mov    -0x48(%rbp),%r12
 1012bb8:	mov    -0x30(%rbp),%r9
 1012bbc:	mov    (%r12),%rdx
 1012bc0:	cmp    0x8(%r12),%rdx
 1012bc5:	jb     1012bd7 <entry_run+0x557>
 1012bc7:	jmp    1012bfb <entry_run+0x57b>
 1012bc9:	xor    %r12d,%r12d
 1012bcc:	mov    (%r12),%rdx
 1012bd0:	cmp    0x8(%r12),%rdx
 1012bd5:	jae    1012bfb <entry_run+0x57b>
 1012bd7:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012bdd:	je     1012bfb <entry_run+0x57b>
 1012bdf:	mov    0x20(%r12),%rax
 1012be4:	lea    -0xf8(%rbp),%rsi
 1012beb:	sub    %rax,%rsi
 1012bee:	imul   $0x38,%rdx,%rcx
 1012bf2:	cmp    %rcx,%rsi
 1012bf5:	jae    10130a7 <entry_run+0xa27>
 1012bfb:	lea    -0xf8(%rbp),%rcx
 1012c02:	mov    -0x38(%rbp),%rdi
 1012c06:	mov    %r12,%rsi
 1012c09:	vzeroupper
 1012c0c:	call   1017f20 <rc_list_insert_at>
 1012c11:	mov    -0x30(%rbp),%r9
 1012c15:	test   %eax,%eax
 1012c17:	je     10145d9 <entry_run+0x1f59>
 1012c1d:	vxorpd %xmm0,%xmm0,%xmm0
 1012c21:	vmovapd %xmm0,-0x380(%rbp)
 1012c29:	movabs $0xc008000000000000,%rax
 1012c33:	mov    %rax,-0x370(%rbp)
 1012c3a:	vmovapd -0x112e2(%rip),%ymm0        # 1001960 <__abi_tag+0x1664>
 1012c42:	vmovupd %ymm0,-0x368(%rbp)
 1012c4a:	test   %r12,%r12
 1012c4d:	je     1012c8e <entry_run+0x60e>
 1012c4f:	test   %rbx,-0x10(%r12)
 1012c54:	jne    1012c5e <entry_run+0x5de>
 1012c56:	cmpq   $0x2,-0x20(%r12)
 1012c5c:	jb     1012c81 <entry_run+0x601>
 1012c5e:	lea    -0x48(%rbp),%rsi
 1012c62:	lea    -0x50(%rbp),%rdx
 1012c66:	mov    %r9,%rdi
 1012c69:	vzeroupper
 1012c6c:	call   1014780 <myl_qbe_rc_unique_local>
 1012c71:	test   %eax,%eax
 1012c73:	je     10144b0 <entry_run+0x1e30>
 1012c79:	mov    -0x48(%rbp),%r12
 1012c7d:	mov    -0x30(%rbp),%r9
 1012c81:	mov    (%r12),%rdx
 1012c85:	cmp    0x8(%r12),%rdx
 1012c8a:	jb     1012c9c <entry_run+0x61c>
 1012c8c:	jmp    1012cc0 <entry_run+0x640>
 1012c8e:	xor    %r12d,%r12d
 1012c91:	mov    (%r12),%rdx
 1012c95:	cmp    0x8(%r12),%rdx
 1012c9a:	jae    1012cc0 <entry_run+0x640>
 1012c9c:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012ca2:	je     1012cc0 <entry_run+0x640>
 1012ca4:	mov    0x20(%r12),%rax
 1012ca9:	lea    -0x380(%rbp),%rsi
 1012cb0:	sub    %rax,%rsi
 1012cb3:	imul   $0x38,%rdx,%rcx
 1012cb7:	cmp    %rcx,%rsi
 1012cba:	jae    10130d3 <entry_run+0xa53>
 1012cc0:	lea    -0x380(%rbp),%rcx
 1012cc7:	mov    -0x38(%rbp),%rdi
 1012ccb:	mov    %r12,%rsi
 1012cce:	vzeroupper
 1012cd1:	call   1017f20 <rc_list_insert_at>
 1012cd6:	mov    -0x30(%rbp),%r9
 1012cda:	test   %eax,%eax
 1012cdc:	je     10145e1 <entry_run+0x1f61>
 1012ce2:	movabs $0xc010000000000000,%r15
 1012cec:	movabs $0xc000000000000000,%r13
 1012cf6:	mov    %r13,-0x340(%rbp)
 1012cfd:	movq   $0x0,-0x338(%rbp)
 1012d08:	mov    %r15,-0x330(%rbp)
 1012d0f:	vmovapd -0x113d7(%rip),%ymm0        # 1001940 <__abi_tag+0x1644>
 1012d17:	vmovupd %ymm0,-0x328(%rbp)
 1012d1f:	test   %r12,%r12
 1012d22:	je     1012d63 <entry_run+0x6e3>
 1012d24:	test   %rbx,-0x10(%r12)
 1012d29:	jne    1012d33 <entry_run+0x6b3>
 1012d2b:	cmpq   $0x2,-0x20(%r12)
 1012d31:	jb     1012d56 <entry_run+0x6d6>
 1012d33:	lea    -0x48(%rbp),%rsi
 1012d37:	lea    -0x50(%rbp),%rdx
 1012d3b:	mov    %r9,%rdi
 1012d3e:	vzeroupper
 1012d41:	call   1014780 <myl_qbe_rc_unique_local>
 1012d46:	test   %eax,%eax
 1012d48:	je     10144b0 <entry_run+0x1e30>
 1012d4e:	mov    -0x48(%rbp),%r12
 1012d52:	mov    -0x30(%rbp),%r9
 1012d56:	mov    (%r12),%rdx
 1012d5a:	cmp    0x8(%r12),%rdx
 1012d5f:	jb     1012d71 <entry_run+0x6f1>
 1012d61:	jmp    1012d95 <entry_run+0x715>
 1012d63:	xor    %r12d,%r12d
 1012d66:	mov    (%r12),%rdx
 1012d6a:	cmp    0x8(%r12),%rdx
 1012d6f:	jae    1012d95 <entry_run+0x715>
 1012d71:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012d77:	je     1012d95 <entry_run+0x715>
 1012d79:	mov    0x20(%r12),%rax
 1012d7e:	lea    -0x340(%rbp),%rsi
 1012d85:	sub    %rax,%rsi
 1012d88:	imul   $0x38,%rdx,%rcx
 1012d8c:	cmp    %rcx,%rsi
 1012d8f:	jae    10130ff <entry_run+0xa7f>
 1012d95:	lea    -0x340(%rbp),%rcx
 1012d9c:	mov    -0x38(%rbp),%rdi
 1012da0:	mov    %r12,%rsi
 1012da3:	vzeroupper
 1012da6:	call   1017f20 <rc_list_insert_at>
 1012dab:	mov    -0x30(%rbp),%r9
 1012daf:	test   %eax,%eax
 1012db1:	je     10145e9 <entry_run+0x1f69>
 1012db7:	movabs $0x4000000000000002,%rax
 1012dc1:	lea    -0x2(%rax),%r14
 1012dc5:	mov    %r14,-0x308(%rbp)
 1012dcc:	movq   $0x0,-0x300(%rbp)
 1012dd7:	mov    %r15,-0x2f8(%rbp)
 1012dde:	vmovapd -0x11446(%rip),%ymm0        # 10019a0 <__abi_tag+0x16a4>
 1012de6:	vmovupd %ymm0,-0x2f0(%rbp)
 1012dee:	test   %r12,%r12
 1012df1:	je     1012e3c <entry_run+0x7bc>
 1012df3:	test   %rbx,-0x10(%r12)
 1012df8:	movabs $0x4000000000000002,%r15
 1012e02:	jne    1012e0c <entry_run+0x78c>
 1012e04:	cmpq   $0x2,-0x20(%r12)
 1012e0a:	jb     1012e2f <entry_run+0x7af>
 1012e0c:	lea    -0x48(%rbp),%rsi
 1012e10:	lea    -0x50(%rbp),%rdx
 1012e14:	mov    %r9,%rdi
 1012e17:	vzeroupper
 1012e1a:	call   1014780 <myl_qbe_rc_unique_local>
 1012e1f:	test   %eax,%eax
 1012e21:	je     10144b0 <entry_run+0x1e30>
 1012e27:	mov    -0x48(%rbp),%r12
 1012e2b:	mov    -0x30(%rbp),%r9
 1012e2f:	mov    (%r12),%rdx
 1012e33:	cmp    0x8(%r12),%rdx
 1012e38:	jb     1012e54 <entry_run+0x7d4>
 1012e3a:	jmp    1012e78 <entry_run+0x7f8>
 1012e3c:	xor    %r12d,%r12d
 1012e3f:	movabs $0x4000000000000002,%r15
 1012e49:	mov    (%r12),%rdx
 1012e4d:	cmp    0x8(%r12),%rdx
 1012e52:	jae    1012e78 <entry_run+0x7f8>
 1012e54:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012e5a:	je     1012e78 <entry_run+0x7f8>
 1012e5c:	mov    0x20(%r12),%rax
 1012e61:	lea    -0x308(%rbp),%rsi
 1012e68:	sub    %rax,%rsi
 1012e6b:	imul   $0x38,%rdx,%rcx
 1012e6f:	cmp    %rcx,%rsi
 1012e72:	jae    101312b <entry_run+0xaab>
 1012e78:	lea    -0x308(%rbp),%rcx
 1012e7f:	mov    -0x38(%rbp),%rdi
 1012e83:	mov    %r12,%rsi
 1012e86:	vzeroupper
 1012e89:	call   1017f20 <rc_list_insert_at>
 1012e8e:	mov    -0x30(%rbp),%r9
 1012e92:	test   %eax,%eax
 1012e94:	je     10145f1 <entry_run+0x1f71>
 1012e9a:	movq   $0x0,-0x2d0(%rbp)
 1012ea5:	mov    %r14,-0x2c8(%rbp)
 1012eac:	movabs $0xc018000000000000,%rax
 1012eb6:	mov    %rax,-0x2c0(%rbp)
 1012ebd:	vmovapd -0x114e5(%rip),%ymm0        # 10019e0 <__abi_tag+0x16e4>
 1012ec5:	vmovupd %ymm0,-0x2b8(%rbp)
 1012ecd:	test   %r12,%r12
 1012ed0:	je     1012f11 <entry_run+0x891>
 1012ed2:	test   %rbx,-0x10(%r12)
 1012ed7:	jne    1012ee1 <entry_run+0x861>
 1012ed9:	cmpq   $0x2,-0x20(%r12)
 1012edf:	jb     1012f04 <entry_run+0x884>
 1012ee1:	lea    -0x48(%rbp),%rsi
 1012ee5:	lea    -0x50(%rbp),%rdx
 1012ee9:	mov    %r9,%rdi
 1012eec:	vzeroupper
 1012eef:	call   1014780 <myl_qbe_rc_unique_local>
 1012ef4:	test   %eax,%eax
 1012ef6:	je     10144b0 <entry_run+0x1e30>
 1012efc:	mov    -0x48(%rbp),%r12
 1012f00:	mov    -0x30(%rbp),%r9
 1012f04:	mov    (%r12),%rdx
 1012f08:	cmp    0x8(%r12),%rdx
 1012f0d:	jb     1012f1f <entry_run+0x89f>
 1012f0f:	jmp    1012f43 <entry_run+0x8c3>
 1012f11:	xor    %r12d,%r12d
 1012f14:	mov    (%r12),%rdx
 1012f18:	cmp    0x8(%r12),%rdx
 1012f1d:	jae    1012f43 <entry_run+0x8c3>
 1012f1f:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012f25:	je     1012f43 <entry_run+0x8c3>
 1012f27:	mov    0x20(%r12),%rax
 1012f2c:	lea    -0x2d0(%rbp),%rsi
 1012f33:	sub    %rax,%rsi
 1012f36:	imul   $0x38,%rdx,%rcx
 1012f3a:	cmp    %rcx,%rsi
 1012f3d:	jae    101318e <entry_run+0xb0e>
 1012f43:	lea    -0x2d0(%rbp),%rcx
 1012f4a:	mov    -0x38(%rbp),%rdi
 1012f4e:	mov    %r12,%rsi
 1012f51:	vzeroupper
 1012f54:	call   1017f20 <rc_list_insert_at>
 1012f59:	mov    -0x30(%rbp),%r9
 1012f5d:	test   %eax,%eax
 1012f5f:	je     10145f9 <entry_run+0x1f79>
 1012f65:	movabs $0xbff8000000000000,%rax
 1012f6f:	mov    %rax,-0x298(%rbp)
 1012f76:	movabs $0xbfe0000000000000,%rax
 1012f80:	mov    %rax,-0x290(%rbp)
 1012f87:	mov    %r13,-0x288(%rbp)
 1012f8e:	vmovapd -0x11616(%rip),%ymm0        # 1001980 <__abi_tag+0x1684>
 1012f96:	vmovupd %ymm0,-0x280(%rbp)
 1012f9e:	test   %r12,%r12
 1012fa1:	je     1012fe2 <entry_run+0x962>
 1012fa3:	test   %rbx,-0x10(%r12)
 1012fa8:	jne    1012fb2 <entry_run+0x932>
 1012faa:	cmpq   $0x2,-0x20(%r12)
 1012fb0:	jb     1012fd5 <entry_run+0x955>
 1012fb2:	lea    -0x48(%rbp),%rsi
 1012fb6:	lea    -0x50(%rbp),%rdx
 1012fba:	mov    %r9,%rdi
 1012fbd:	vzeroupper
 1012fc0:	call   1014780 <myl_qbe_rc_unique_local>
 1012fc5:	test   %eax,%eax
 1012fc7:	je     10144b0 <entry_run+0x1e30>
 1012fcd:	mov    -0x48(%rbp),%r12
 1012fd1:	mov    -0x30(%rbp),%r9
 1012fd5:	mov    (%r12),%rdx
 1012fd9:	cmp    0x8(%r12),%rdx
 1012fde:	jb     1012ff0 <entry_run+0x970>
 1012fe0:	jmp    1013014 <entry_run+0x994>
 1012fe2:	xor    %r12d,%r12d
 1012fe5:	mov    (%r12),%rdx
 1012fe9:	cmp    0x8(%r12),%rdx
 1012fee:	jae    1013014 <entry_run+0x994>
 1012ff0:	cmpq   $0xffffffffffffffff,0x10(%r12)
 1012ff6:	je     1013014 <entry_run+0x994>
 1012ff8:	mov    0x20(%r12),%rax
 1012ffd:	lea    -0x298(%rbp),%rsi
 1013004:	sub    %rax,%rsi
 1013007:	imul   $0x38,%rdx,%rcx
 101300b:	cmp    %rcx,%rsi
 101300e:	jae    10131ba <entry_run+0xb3a>
 1013014:	lea    -0x298(%rbp),%rcx
 101301b:	mov    -0x38(%rbp),%rdi
 101301f:	mov    %r12,%rsi
 1013022:	vzeroupper
 1013025:	call   1017f20 <rc_list_insert_at>
 101302a:	mov    -0x30(%rbp),%r9
 101302e:	test   %eax,%eax
 1013030:	mov    -0x40(%rbp),%r8d
 1013034:	je     1014601 <entry_run+0x1f81>
 101303a:	mov    %r12,-0x58(%rbp)
 101303e:	test   %r12,%r12
 1013041:	je     10131f2 <entry_run+0xb72>
 1013047:	mov    -0x10(%r12),%rax
 101304c:	test   %r15,%rax
 101304f:	je     1013157 <entry_run+0xad7>
 1013055:	test   %r14,%rax
 1013058:	je     1013211 <entry_run+0xb91>
 101305e:	lea    -0x1c0(%rbp),%rdx
 1013065:	lea    -0x58(%rbp),%rcx
 1013069:	mov    $0x1002338,%esi
 101306e:	mov    -0x38(%rbp),%rdi
 1013072:	vzeroupper
 1013075:	call   1023af0 <myl_rc_native_retain>
 101307a:	test   %eax,%eax
 101307c:	je     101430c <entry_run+0x1c8c>
 1013082:	mov    -0x1c0(%rbp),%rax
 1013089:	mov    %rax,-0x80(%rbp)
 101308d:	cmpl   $0x0,-0x50(%rbp)
 1013091:	mov    -0x30(%rbp),%r9
 1013095:	je     1013258 <entry_run+0xbd8>
 101309b:	movl   $0x0,-0x50(%rbp)
 10130a2:	jmp    101322e <entry_run+0xbae>
 10130a7:	vmovupd -0xf8(%rbp),%ymm0
 10130af:	vmovupd -0xe0(%rbp),%ymm1
 10130b7:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10130bd:	vmovupd %ymm0,(%rax,%rcx,1)
 10130c2:	inc    %rdx
 10130c5:	mov    %rdx,(%r12)
 10130c9:	incq   0x10(%r12)
 10130ce:	jmp    1012c1d <entry_run+0x59d>
 10130d3:	vmovupd -0x380(%rbp),%ymm0
 10130db:	vmovupd -0x368(%rbp),%ymm1
 10130e3:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10130e9:	vmovupd %ymm0,(%rax,%rcx,1)
 10130ee:	inc    %rdx
 10130f1:	mov    %rdx,(%r12)
 10130f5:	incq   0x10(%r12)
 10130fa:	jmp    1012ce2 <entry_run+0x662>
 10130ff:	vmovupd -0x340(%rbp),%ymm0
 1013107:	vmovupd -0x328(%rbp),%ymm1
 101310f:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1013115:	vmovupd %ymm0,(%rax,%rcx,1)
 101311a:	inc    %rdx
 101311d:	mov    %rdx,(%r12)
 1013121:	incq   0x10(%r12)
 1013126:	jmp    1012db7 <entry_run+0x737>
 101312b:	vmovupd -0x308(%rbp),%ymm0
 1013133:	vmovupd -0x2f0(%rbp),%ymm1
 101313b:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 1013141:	vmovupd %ymm0,(%rax,%rcx,1)
 1013146:	inc    %rdx
 1013149:	mov    %rdx,(%r12)
 101314d:	incq   0x10(%r12)
 1013152:	jmp    1012e9a <entry_run+0x81a>
 1013157:	mov    -0x20(%r12),%rax
 101315c:	inc    %rax
 101315f:	jne    101320c <entry_run+0xb8c>
 1013165:	mov    $0x100432e,%esi
 101316a:	mov    %r9,%rdi
 101316d:	call   1014ab0 <fail>
 1013172:	jmp    10144b0 <entry_run+0x1e30>
 1013177:	movl   $0x1,0x38(%rax)
 101317e:	cmpq   $0x0,0x20(%r9)
 1013183:	jne    10144b0 <entry_run+0x1e30>
 1013189:	jmp    10127cd <entry_run+0x14d>
 101318e:	vmovupd -0x2d0(%rbp),%ymm0
 1013196:	vmovupd -0x2b8(%rbp),%ymm1
 101319e:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10131a4:	vmovupd %ymm0,(%rax,%rcx,1)
 10131a9:	inc    %rdx
 10131ac:	mov    %rdx,(%r12)
 10131b0:	incq   0x10(%r12)
 10131b5:	jmp    1012f65 <entry_run+0x8e5>
 10131ba:	vmovupd -0x298(%rbp),%ymm0
 10131c2:	vmovupd -0x280(%rbp),%ymm1
 10131ca:	vmovupd %ymm1,0x18(%rax,%rcx,1)
 10131d0:	vmovupd %ymm0,(%rax,%rcx,1)
 10131d5:	inc    %rdx
 10131d8:	mov    %rdx,(%r12)
 10131dc:	incq   0x10(%r12)
 10131e1:	mov    -0x40(%rbp),%r8d
 10131e5:	mov    %r12,-0x58(%rbp)
 10131e9:	test   %r12,%r12
 10131ec:	jne    1013047 <entry_run+0x9c7>
 10131f2:	mov    %r12,-0x1c0(%rbp)
 10131f9:	mov    %r12,-0x80(%rbp)
 10131fd:	mov    -0x50(%rbp),%eax
 1013200:	xor    %ecx,%ecx
 1013202:	test   %eax,%eax
 1013204:	cmove  %eax,%ecx
 1013207:	mov    %ecx,-0x50(%rbp)
 101320a:	jmp    1013258 <entry_run+0xbd8>
 101320c:	mov    %rax,-0x20(%r12)
 1013211:	mov    %r12,-0x1c0(%rbp)
 1013218:	mov    %r12,-0x80(%rbp)
 101321c:	cmpl   $0x0,-0x50(%rbp)
 1013220:	je     1013258 <entry_run+0xbd8>
 1013222:	movl   $0x0,-0x50(%rbp)
 1013229:	test   %r12,%r12
 101322c:	je     1013258 <entry_run+0xbd8>
 101322e:	test   %r15,-0x10(%r12)
 1013233:	jne    1013250 <entry_run+0xbd0>
 1013235:	mov    -0x20(%r12),%rax
 101323a:	dec    %rax
 101323d:	jne    101324b <entry_run+0xbcb>
 101323f:	cmpq   $0x0,-0x18(%r12)
 1013245:	je     10143dd <entry_run+0x1d5d>
 101324b:	mov    %rax,-0x20(%r12)
 1013250:	movq   $0x0,-0x48(%rbp)
 1013258:	movabs $0x3ff0000000000000,%rax
 1013262:	mov    %rax,-0x158(%rbp)
 1013269:	mov    %rax,-0x150(%rbp)
 1013270:	mov    %rax,-0x148(%rbp)
 1013277:	cmp    %rsp,0x40(%r9)
 101327b:	ja     1014609 <entry_run+0x1f89>
 1013281:	vmovsd -0x158(%rbp),%xmm2
 1013289:	vmovsd -0x150(%rbp),%xmm3
 1013291:	vmulsd %xmm2,%xmm2,%xmm0
 1013295:	vmulsd %xmm3,%xmm3,%xmm1
 1013299:	vaddsd %xmm1,%xmm0,%xmm0
 101329d:	vmovsd -0x148(%rbp),%xmm4
 10132a5:	vmulsd %xmm4,%xmm4,%xmm1
 10132a9:	vaddsd %xmm1,%xmm0,%xmm0
 10132ad:	vxorpd %xmm5,%xmm5,%xmm5
 10132b1:	vucomisd %xmm5,%xmm0
 10132b5:	jb     10132bd <entry_run+0xc3d>
 10132b7:	vsqrtsd %xmm0,%xmm0,%xmm0
 10132bb:	jmp    10132eb <entry_run+0xc6b>
 10132bd:	vmovsd %xmm2,-0x40(%rbp)
 10132c2:	vmovsd %xmm3,-0x70(%rbp)
 10132c7:	vmovsd %xmm4,-0x78(%rbp)
 10132cc:	vzeroupper
 10132cf:	call   10277d0 <sqrt@plt>
 10132d4:	vmovsd -0x78(%rbp),%xmm4
 10132d9:	vmovsd -0x70(%rbp),%xmm3
 10132de:	vmovsd -0x40(%rbp),%xmm2
 10132e3:	vxorpd %xmm5,%xmm5,%xmm5
 10132e7:	mov    -0x30(%rbp),%r9
 10132eb:	vmovsd -0x118d3(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 10132f3:	vdivsd %xmm0,%xmm1,%xmm0
 10132f7:	vmulsd %xmm0,%xmm2,%xmm1
 10132fb:	vmulsd %xmm0,%xmm3,%xmm2
 10132ff:	vmulsd %xmm0,%xmm4,%xmm0
 1013303:	vmovsd %xmm1,-0xa8(%rbp)
 101330b:	vmovsd %xmm2,-0xa0(%rbp)
 1013313:	vmovsd %xmm0,-0x98(%rbp)
 101331b:	vxorpd %xmm0,%xmm0,%xmm0
 101331f:	vmovapd %xmm0,-0x110(%rbp)
 1013327:	movq   $0x0,-0x100(%rbp)
 1013332:	xor    %r13d,%r13d
 1013335:	mov    $0x3f,%r14b
 1013338:	movabs $0x7fefffffffffffff,%rbx
 1013342:	vmovsd -0x118ea(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101334a:	xor    %eax,%eax
 101334c:	jmp    1013366 <entry_run+0xce6>
 101334e:	xchg   %ax,%ax
 1013350:	mov    -0x118(%rbp),%rax
 1013357:	inc    %rax
 101335a:	cmp    $0x438,%rax
 1013360:	je     1013f1c <entry_run+0x189c>
 1013366:	mov    %rax,-0x118(%rbp)
 101336d:	vcvtsi2sd %rax,%xmm15,%xmm0
 1013372:	vaddsd -0x1193a(%rip),%xmm0,%xmm0        # 1001a40 <__abi_tag+0x1744>
 101337a:	vaddsd %xmm0,%xmm0,%xmm0
 101337e:	vdivsd -0x11976(%rip),%xmm0,%xmm0        # 1001a10 <__abi_tag+0x1714>
 1013386:	vaddsd -0x1196e(%rip),%xmm0,%xmm0        # 1001a20 <__abi_tag+0x1724>
 101338e:	vmovsd %xmm0,-0x120(%rbp)
 1013396:	xor    %ecx,%ecx
 1013398:	nopl   0x0(%rax,%rax,1)
 10133a0:	vcvtsi2sd %rcx,%xmm15,%xmm0
 10133a5:	vaddsd -0x1196d(%rip),%xmm0,%xmm0        # 1001a40 <__abi_tag+0x1744>
 10133ad:	vaddsd %xmm0,%xmm0,%xmm0
 10133b1:	vdivsd -0x11961(%rip),%xmm0,%xmm0        # 1001a58 <__abi_tag+0x175c>
 10133b9:	vaddsd -0x119c1(%rip),%xmm0,%xmm0        # 1001a00 <__abi_tag+0x1704>
 10133c1:	vmulsd -0x11999(%rip),%xmm0,%xmm0        # 1001a30 <__abi_tag+0x1734>
 10133c9:	vmovsd %xmm0,-0x140(%rbp)
 10133d1:	vmovsd -0x120(%rbp),%xmm0
 10133d9:	vmovsd %xmm0,-0x138(%rbp)
 10133e1:	movabs $0xbff8000000000000,%rax
 10133eb:	mov    %rax,-0x130(%rbp)
 10133f2:	cmp    %rsp,0x40(%r9)
 10133f6:	ja     1014502 <entry_run+0x1e82>
 10133fc:	vmovsd -0x140(%rbp),%xmm2
 1013404:	vmovsd -0x138(%rbp),%xmm3
 101340c:	vmulsd %xmm2,%xmm2,%xmm0
 1013410:	vmulsd %xmm3,%xmm3,%xmm1
 1013414:	vaddsd %xmm1,%xmm0,%xmm0
 1013418:	vmovsd -0x130(%rbp),%xmm4
 1013420:	vmulsd %xmm4,%xmm4,%xmm1
 1013424:	vaddsd %xmm1,%xmm0,%xmm0
 1013428:	vucomisd %xmm5,%xmm0
 101342c:	mov    %rcx,-0x128(%rbp)
 1013433:	jb     1013440 <entry_run+0xdc0>
 1013435:	vsqrtsd %xmm0,%xmm0,%xmm0
 1013439:	jmp    1013476 <entry_run+0xdf6>
 101343b:	nopl   0x0(%rax,%rax,1)
 1013440:	vmovsd %xmm2,-0x40(%rbp)
 1013445:	vmovsd %xmm3,-0x70(%rbp)
 101344a:	vmovsd %xmm4,-0x78(%rbp)
 101344f:	vzeroupper
 1013452:	call   10277d0 <sqrt@plt>
 1013457:	vmovsd -0x78(%rbp),%xmm4
 101345c:	vmovsd -0x70(%rbp),%xmm3
 1013461:	vmovsd -0x40(%rbp),%xmm2
 1013466:	vmovsd -0x11a0e(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101346e:	vxorpd %xmm5,%xmm5,%xmm5
 1013472:	mov    -0x30(%rbp),%r9
 1013476:	vmovsd -0x11a5e(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 101347e:	vdivsd %xmm0,%xmm1,%xmm0
 1013482:	vmulsd %xmm0,%xmm2,%xmm1
 1013486:	vmulsd %xmm0,%xmm3,%xmm2
 101348a:	vmulsd %xmm0,%xmm4,%xmm0
 101348e:	vmovsd %xmm1,-0xc0(%rbp)
 1013496:	vmovsd %xmm2,-0xb8(%rbp)
 101349e:	vmovsd %xmm0,-0xb0(%rbp)
 10134a6:	mov    -0x80(%rbp),%r12
 10134aa:	movq   $0x0,-0x410(%rbp)
 10134b5:	movq   $0x0,-0x3f0(%rbp)
 10134c0:	movq   $0x0,-0x3d0(%rbp)
 10134cb:	cmp    %rsp,0x40(%r9)
 10134cf:	ja     101450d <entry_run+0x1e8d>
 10134d5:	test   %r15,-0x10(%r12)
 10134da:	je     1013820 <entry_run+0x11a0>
 10134e0:	mov    %r13,-0x90(%rbp)
 10134e7:	mov    (%r12),%r13
 10134eb:	test   %r13,%r13
 10134ee:	js     101458b <entry_run+0x1f0b>
 10134f4:	je     10137d0 <entry_run+0x1150>
 10134fa:	mov    $0xffffffffffffffff,%r14
 1013501:	mov    $0x18,%r15d
 1013507:	xor    %ebx,%ebx
 1013509:	movabs $0xbff0000000000000,%rax
 1013513:	mov    %rax,-0x88(%rbp)
 101351a:	nopw   0x0(%rax,%rax,1)
 1013520:	cmp    %rsp,0x40(%r9)
 1013524:	ja     10144ed <entry_run+0x1e6d>
 101352a:	mov    0x20(%r12),%rax
 101352f:	vmovsd -0x110(%rbp),%xmm7
 1013537:	vmovsd -0x108(%rbp),%xmm0
 101353f:	vsubsd -0x18(%r15,%rax,1),%xmm7,%xmm1
 1013546:	vsubsd -0x10(%r15,%rax,1),%xmm0,%xmm0
 101354d:	vmovsd -0x100(%rbp),%xmm2
 1013555:	vsubsd -0x8(%r15,%rax,1),%xmm2,%xmm2
 101355c:	vmovsd %xmm1,-0x260(%rbp)
 1013564:	vmovsd %xmm0,-0x258(%rbp)
 101356c:	vmovsd %xmm2,-0x250(%rbp)
 1013574:	vmovsd -0xc0(%rbp),%xmm8
 101357c:	vmulsd %xmm1,%xmm8,%xmm3
 1013580:	vmulsd -0xb8(%rbp),%xmm0,%xmm4
 1013588:	vaddsd %xmm4,%xmm3,%xmm3
 101358c:	vmulsd -0xb0(%rbp),%xmm2,%xmm4
 1013594:	vaddsd %xmm4,%xmm3,%xmm3
 1013598:	vmulsd %xmm1,%xmm1,%xmm1
 101359c:	vmulsd %xmm0,%xmm0,%xmm0
 10135a0:	vaddsd %xmm0,%xmm1,%xmm0
 10135a4:	vmulsd %xmm2,%xmm2,%xmm1
 10135a8:	vaddsd %xmm1,%xmm0,%xmm0
 10135ac:	vmovsd (%r15,%rax,1),%xmm1
 10135b2:	vmulsd %xmm1,%xmm1,%xmm1
 10135b6:	vsubsd %xmm0,%xmm1,%xmm0
 10135ba:	vmulsd %xmm3,%xmm3,%xmm1
 10135be:	vaddsd %xmm0,%xmm1,%xmm0
 10135c2:	vucomisd %xmm0,%xmm5
 10135c6:	ja     1013680 <entry_run+0x1000>
 10135cc:	vucomisd %xmm5,%xmm0
 10135d0:	jb     10135f0 <entry_run+0xf70>
 10135d2:	vsqrtsd %xmm0,%xmm0,%xmm0
 10135d6:	vsubsd %xmm3,%xmm5,%xmm2
 10135da:	vsubsd %xmm0,%xmm2,%xmm1
 10135de:	vucomisd %xmm6,%xmm1
 10135e2:	jbe    1013634 <entry_run+0xfb4>
 10135e4:	jmp    101363e <entry_run+0xfbe>
 10135e6:	cs nopw 0x0(%rax,%rax,1)
 10135f0:	vmovsd %xmm7,-0x40(%rbp)
 10135f5:	vmovsd %xmm8,-0x70(%rbp)
 10135fa:	vmovsd %xmm3,-0x78(%rbp)
 10135ff:	vzeroupper
 1013602:	call   10277d0 <sqrt@plt>
 1013607:	vmovsd -0x78(%rbp),%xmm3
 101360c:	vmovsd -0x70(%rbp),%xmm8
 1013611:	vmovsd -0x40(%rbp),%xmm7
 1013616:	vmovsd -0x11bbe(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 101361e:	vxorpd %xmm5,%xmm5,%xmm5
 1013622:	mov    -0x30(%rbp),%r9
 1013626:	vsubsd %xmm3,%xmm5,%xmm2
 101362a:	vsubsd %xmm0,%xmm2,%xmm1
 101362e:	vucomisd %xmm6,%xmm1
 1013632:	ja     101363e <entry_run+0xfbe>
 1013634:	vaddsd %xmm0,%xmm2,%xmm1
 1013638:	vucomisd %xmm6,%xmm1
 101363c:	jbe    1013680 <entry_run+0x1000>
 101363e:	vucomisd %xmm5,%xmm1
 1013642:	jbe    1013680 <entry_run+0x1000>
 1013644:	test   %r14,%r14
 1013647:	setns  %al
 101364a:	mov    -0x88(%rbp),%rsi
 1013651:	vmovq  %rsi,%xmm0
 1013656:	vucomisd %xmm1,%xmm0
 101365a:	vmovq  %xmm1,%rcx
 101365f:	setbe  %dl
 1013662:	test   %dl,%al
 1013664:	cmove  %rcx,%rsi
 1013668:	mov    %rsi,-0x88(%rbp)
 101366f:	cmove  %rbx,%r14
 1013673:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013680:	cmp    %r13,(%r12)
 1013684:	jne    10144e2 <entry_run+0x1e62>
 101368a:	inc    %rbx
 101368d:	add    $0x38,%r15
 1013691:	cmp    %rbx,%r13
 1013694:	jne    1013520 <entry_run+0xea0>
 101369a:	test   %r14,%r14
 101369d:	movabs $0x4000000000000002,%r15
 10136a7:	js     10137d0 <entry_run+0x1150>
 10136ad:	cmp    %r13,%r14
 10136b0:	jae    1014599 <entry_run+0x1f19>
 10136b6:	mov    0x20(%r12),%rax
 10136bb:	imul   $0x38,%r14,%rcx
 10136bf:	vmovups 0x20(%rax,%rcx,1),%xmm0
 10136c5:	mov    0x30(%rax,%rcx,1),%rdx
 10136ca:	vmovups (%rax,%rcx,1),%ymm1
 10136cf:	vmovups %ymm1,-0x260(%rbp)
 10136d7:	mov    %rdx,-0x230(%rbp)
 10136de:	vmovaps %xmm0,-0x240(%rbp)
 10136e6:	vmovsd -0x88(%rbp),%xmm0
 10136ee:	vmulsd %xmm0,%xmm8,%xmm1
 10136f2:	vmulsd -0xb8(%rbp),%xmm0,%xmm2
 10136fa:	vmulsd -0xb0(%rbp),%xmm0,%xmm0
 1013702:	vmovsd %xmm1,-0x3b0(%rbp)
 101370a:	vmovsd %xmm2,-0x3a8(%rbp)
 1013712:	vmovsd %xmm0,-0x3a0(%rbp)
 101371a:	vaddsd %xmm1,%xmm7,%xmm1
 101371e:	vaddsd -0x108(%rbp),%xmm2,%xmm2
 1013726:	vaddsd -0x100(%rbp),%xmm0,%xmm0
 101372e:	vmovsd %xmm1,-0x170(%rbp)
 1013736:	vmovsd %xmm2,-0x168(%rbp)
 101373e:	vsubsd -0x260(%rbp),%xmm1,%xmm1
 1013746:	vsubsd -0x258(%rbp),%xmm2,%xmm2
 101374e:	vmovsd %xmm0,-0x160(%rbp)
 1013756:	vsubsd -0x250(%rbp),%xmm0,%xmm0
 101375e:	vmovsd %xmm1,-0x188(%rbp)
 1013766:	vmovsd %xmm2,-0x180(%rbp)
 101376e:	vmovsd %xmm0,-0x178(%rbp)
 1013776:	cmp    %rsp,0x40(%r9)
 101377a:	ja     10145aa <entry_run+0x1f2a>
 1013780:	vmovsd -0x188(%rbp),%xmm2
 1013788:	vmovsd -0x180(%rbp),%xmm3
 1013790:	vmulsd %xmm2,%xmm2,%xmm0
 1013794:	vmulsd %xmm3,%xmm3,%xmm1
 1013798:	vaddsd %xmm1,%xmm0,%xmm0
 101379c:	vmovsd -0x178(%rbp),%xmm4
 10137a4:	vmulsd %xmm4,%xmm4,%xmm1
 10137a8:	vaddsd %xmm1,%xmm0,%xmm0
 10137ac:	vucomisd %xmm5,%xmm0
 10137b0:	mov    -0x90(%rbp),%r13
 10137b7:	jb     1013862 <entry_run+0x11e2>
 10137bd:	vsqrtsd %xmm0,%xmm0,%xmm0
 10137c1:	jmp    1013898 <entry_run+0x1218>
 10137c6:	cs nopw 0x0(%rax,%rax,1)
 10137d0:	mov    -0x3f0(%rbp),%eax
 10137d6:	or     -0x410(%rbp),%eax
 10137dc:	or     -0x3d0(%rbp),%eax
 10137e2:	mov    -0x90(%rbp),%r13
 10137e9:	mov    $0x3f,%r14b
 10137ec:	movabs $0x7fefffffffffffff,%rbx
 10137f6:	je     1013a90 <entry_run+0x1410>
 10137fc:	mov    0x1860(%r9),%rax
 1013803:	test   %rax,%rax
 1013806:	je     1013a72 <entry_run+0x13f2>
 101380c:	mov    0xf8(%rax),%rsi
 1013813:	jmp    1013a74 <entry_run+0x13f4>
 1013818:	nopl   0x0(%rax,%rax,1)
 1013820:	mov    -0x18(%r12),%rax
 1013825:	inc    %rax
 1013828:	jne    1013844 <entry_run+0x11c4>
 101382a:	mov    $0x100432e,%esi
 101382f:	mov    %r9,%rdi
 1013832:	call   1014ab0 <fail>
 1013837:	vxorpd %xmm3,%xmm3,%xmm3
 101383b:	vxorpd %xmm2,%xmm2,%xmm2
 101383f:	jmp    1013c50 <entry_run+0x15d0>
 1013844:	mov    %rax,-0x18(%r12)
 1013849:	mov    %r13,-0x90(%rbp)
 1013850:	mov    (%r12),%r13
 1013854:	test   %r13,%r13
 1013857:	jns    10134f4 <entry_run+0xe74>
 101385d:	jmp    101458b <entry_run+0x1f0b>
 1013862:	vmovsd %xmm2,-0x40(%rbp)
 1013867:	vmovsd %xmm3,-0x70(%rbp)
 101386c:	vmovsd %xmm4,-0x78(%rbp)
 1013871:	vzeroupper
 1013874:	call   10277d0 <sqrt@plt>
 1013879:	vmovsd -0x78(%rbp),%xmm4
 101387e:	vmovsd -0x70(%rbp),%xmm3
 1013883:	vmovsd -0x40(%rbp),%xmm2
 1013888:	vmovsd -0x11e30(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013890:	vxorpd %xmm5,%xmm5,%xmm5
 1013894:	mov    -0x30(%rbp),%r9
 1013898:	vmovsd -0x11e80(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 10138a0:	vdivsd %xmm0,%xmm1,%xmm0
 10138a4:	vmulsd %xmm0,%xmm2,%xmm1
 10138a8:	vmulsd %xmm0,%xmm3,%xmm2
 10138ac:	vmulsd %xmm0,%xmm4,%xmm0
 10138b0:	vmovsd %xmm1,-0x398(%rbp)
 10138b8:	vmovsd %xmm2,-0x390(%rbp)
 10138c0:	vmovsd %xmm0,-0x388(%rbp)
 10138c8:	vmulsd -0xa8(%rbp),%xmm1,%xmm1
 10138d0:	vmulsd -0xa0(%rbp),%xmm2,%xmm2
 10138d8:	vaddsd %xmm2,%xmm1,%xmm1
 10138dc:	vmulsd -0x98(%rbp),%xmm0,%xmm0
 10138e4:	vaddsd %xmm0,%xmm1,%xmm7
 10138e8:	vxorpd %xmm0,%xmm0,%xmm0
 10138ec:	mov    $0x1,%bl
 10138ee:	vucomisd %xmm7,%xmm0
 10138f2:	jbe    10138fc <entry_run+0x127c>
 10138f4:	xor    %r14d,%r14d
 10138f7:	jmp    1013b60 <entry_run+0x14e0>
 10138fc:	vucomisd %xmm5,%xmm7
 1013900:	jbe    1013ad7 <entry_run+0x1457>
 1013906:	test   %r15,-0x10(%r12)
 101390b:	movabs $0x7fefffffffffffff,%rbx
 1013915:	je     1013ae3 <entry_run+0x1463>
 101391b:	mov    (%r12),%r14
 101391f:	test   %r14,%r14
 1013922:	js     10145b5 <entry_run+0x1f35>
 1013928:	je     1013b41 <entry_run+0x14c1>
 101392e:	mov    $0x18,%ebx
 1013933:	mov    %r14,%r15
 1013936:	vmovsd %xmm7,-0x70(%rbp)
 101393b:	nopl   0x0(%rax,%rax,1)
 1013940:	cmp    %rsp,0x40(%r9)
 1013944:	ja     1014575 <entry_run+0x1ef5>
 101394a:	mov    0x20(%r12),%rax
 101394f:	vmovsd -0x170(%rbp),%xmm0
 1013957:	vmovsd -0x168(%rbp),%xmm1
 101395f:	vsubsd -0x18(%rbx,%rax,1),%xmm0,%xmm0
 1013965:	vsubsd -0x10(%rbx,%rax,1),%xmm1,%xmm1
 101396b:	vmovsd -0x160(%rbp),%xmm2
 1013973:	vsubsd -0x8(%rbx,%rax,1),%xmm2,%xmm2
 1013979:	vmovsd %xmm0,-0x3c8(%rbp)
 1013981:	vmovsd %xmm1,-0x3c0(%rbp)
 1013989:	vmovsd %xmm2,-0x3b8(%rbp)
 1013991:	vmulsd -0xa8(%rbp),%xmm0,%xmm3
 1013999:	vmulsd -0xa0(%rbp),%xmm1,%xmm4
 10139a1:	vaddsd %xmm4,%xmm3,%xmm3
 10139a5:	vmulsd -0x98(%rbp),%xmm2,%xmm4
 10139ad:	vaddsd %xmm4,%xmm3,%xmm3
 10139b1:	vmulsd %xmm0,%xmm0,%xmm0
 10139b5:	vmulsd %xmm1,%xmm1,%xmm1
 10139b9:	vaddsd %xmm1,%xmm0,%xmm0
 10139bd:	vmulsd %xmm2,%xmm2,%xmm1
 10139c1:	vaddsd %xmm1,%xmm0,%xmm0
 10139c5:	vmovsd (%rbx,%rax,1),%xmm1
 10139ca:	vmulsd %xmm1,%xmm1,%xmm1
 10139ce:	vsubsd %xmm0,%xmm1,%xmm0
 10139d2:	vmulsd %xmm3,%xmm3,%xmm1
 10139d6:	vaddsd %xmm0,%xmm1,%xmm0
 10139da:	vucomisd %xmm0,%xmm5
 10139de:	ja     1013a4d <entry_run+0x13cd>
 10139e0:	vucomisd %xmm5,%xmm0
 10139e4:	jb     1013a00 <entry_run+0x1380>
 10139e6:	vsqrtsd %xmm0,%xmm0,%xmm0
 10139ea:	vsubsd %xmm3,%xmm5,%xmm2
 10139ee:	vsubsd %xmm0,%xmm2,%xmm1
 10139f2:	vucomisd %xmm6,%xmm1
 10139f6:	jbe    1013a35 <entry_run+0x13b5>
 10139f8:	jmp    1013a3f <entry_run+0x13bf>
 10139fa:	nopw   0x0(%rax,%rax,1)
 1013a00:	vmovsd %xmm3,-0x40(%rbp)
 1013a05:	vzeroupper
 1013a08:	call   10277d0 <sqrt@plt>
 1013a0d:	vmovsd -0x40(%rbp),%xmm3
 1013a12:	vmovsd -0x70(%rbp),%xmm7
 1013a17:	vmovsd -0x11fbf(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013a1f:	vxorpd %xmm5,%xmm5,%xmm5
 1013a23:	mov    -0x30(%rbp),%r9
 1013a27:	vsubsd %xmm3,%xmm5,%xmm2
 1013a2b:	vsubsd %xmm0,%xmm2,%xmm1
 1013a2f:	vucomisd %xmm6,%xmm1
 1013a33:	ja     1013a3f <entry_run+0x13bf>
 1013a35:	vaddsd %xmm0,%xmm2,%xmm1
 1013a39:	vucomisd %xmm6,%xmm1
 1013a3d:	jbe    1013a4d <entry_run+0x13cd>
 1013a3f:	vxorpd %xmm0,%xmm0,%xmm0
 1013a43:	vucomisd %xmm0,%xmm1
 1013a47:	ja     1013b4c <entry_run+0x14cc>
 1013a4d:	cmp    %r14,(%r12)
 1013a51:	jne    1014580 <entry_run+0x1f00>
 1013a57:	add    $0x38,%rbx
 1013a5b:	dec    %r15
 1013a5e:	jne    1013940 <entry_run+0x12c0>
 1013a64:	xor    %ebx,%ebx
 1013a66:	mov    %r12,%r14
 1013a69:	vmovapd %xmm7,%xmm0
 1013a6d:	jmp    1013b51 <entry_run+0x14d1>
 1013a72:	xor    %esi,%esi
 1013a74:	mov    -0x38(%rbp),%rdi
 1013a78:	vzeroupper
 1013a7b:	call   101e520 <myl_rc_scope_unwind>
 1013a80:	mov    -0x30(%rbp),%r9
 1013a84:	vxorpd %xmm5,%xmm5,%xmm5
 1013a88:	vmovsd -0x12030(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013a90:	vmovsd -0x12080(%rip),%xmm2        # 1001a18 <__abi_tag+0x171c>
 1013a98:	vmovapd -0x121b0(%rip),%xmm3        # 10018f0 <__abi_tag+0x15f4>
 1013aa0:	test   %r15,-0x10(%r12)
 1013aa5:	jne    1013c50 <entry_run+0x15d0>
 1013aab:	mov    -0x18(%r12),%rax
 1013ab0:	dec    %rax
 1013ab3:	jne    1013abd <entry_run+0x143d>
 1013ab5:	cmpq   $0x0,-0x20(%r12)
 1013abb:	je     1013b0b <entry_run+0x148b>
 1013abd:	mov    %rax,-0x18(%r12)
 1013ac2:	vmovsd -0x120b2(%rip),%xmm2        # 1001a18 <__abi_tag+0x171c>
 1013aca:	vmovapd -0x121e2(%rip),%xmm3        # 10018f0 <__abi_tag+0x15f4>
 1013ad2:	jmp    1013c50 <entry_run+0x15d0>
 1013ad7:	xor    %r14d,%r14d
 1013ada:	vmovapd %xmm7,%xmm0
 1013ade:	jmp    1013b60 <entry_run+0x14e0>
 1013ae3:	mov    -0x18(%r12),%rax
 1013ae8:	inc    %rax
 1013aeb:	mov    $0x3f,%r14b
 1013aee:	je     101382a <entry_run+0x11aa>
 1013af4:	mov    %rax,-0x18(%r12)
 1013af9:	mov    (%r12),%r14
 1013afd:	test   %r14,%r14
 1013b00:	jns    1013928 <entry_run+0x12a8>
 1013b06:	jmp    10145b5 <entry_run+0x1f35>
 1013b0b:	mov    -0x38(%rbp),%rbx
 1013b0f:	mov    %rbx,%rdi
 1013b12:	mov    %r12,%rsi
 1013b15:	vzeroupper
 1013b18:	call   1018e60 <myl_rc_hold_edge_release>
 1013b1d:	mov    %rbx,%rdi
 1013b20:	movabs $0x7fefffffffffffff,%rbx
 1013b2a:	call   101be30 <myl_rc_drain>
 1013b2f:	vmovsd -0x120d7(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013b37:	vxorpd %xmm5,%xmm5,%xmm5
 1013b3b:	mov    -0x30(%rbp),%r9
 1013b3f:	jmp    1013ac2 <entry_run+0x1442>
 1013b41:	xor    %ebx,%ebx
 1013b43:	mov    %r12,%r14
 1013b46:	vmovapd %xmm7,%xmm0
 1013b4a:	jmp    1013b60 <entry_run+0x14e0>
 1013b4c:	xor    %ebx,%ebx
 1013b4e:	mov    %r12,%r14
 1013b51:	movabs $0x4000000000000002,%r15
 1013b5b:	nopl   0x0(%rax,%rax,1)
 1013b60:	vmulsd -0x12120(%rip),%xmm0,%xmm0        # 1001a48 <__abi_tag+0x174c>
 1013b68:	vaddsd -0x12138(%rip),%xmm0,%xmm0        # 1001a38 <__abi_tag+0x173c>
 1013b70:	vmulsd -0x240(%rbp),%xmm0,%xmm2
 1013b78:	vmovddup %xmm0,%xmm0
 1013b7c:	vmulpd -0x238(%rbp),%xmm0,%xmm3
 1013b84:	mov    -0x3f0(%rbp),%eax
 1013b8a:	or     -0x410(%rbp),%eax
 1013b90:	or     -0x3d0(%rbp),%eax
 1013b96:	je     1013bdf <entry_run+0x155f>
 1013b98:	mov    0x1860(%r9),%rax
 1013b9f:	test   %rax,%rax
 1013ba2:	vmovsd %xmm2,-0x40(%rbp)
 1013ba7:	vmovapd %xmm3,-0x70(%rbp)
 1013bac:	je     1013bb7 <entry_run+0x1537>
 1013bae:	mov    0xf8(%rax),%rsi
 1013bb5:	jmp    1013bb9 <entry_run+0x1539>
 1013bb7:	xor    %esi,%esi
 1013bb9:	mov    -0x38(%rbp),%rdi
 1013bbd:	vzeroupper
 1013bc0:	call   101e520 <myl_rc_scope_unwind>
 1013bc5:	mov    -0x30(%rbp),%r9
 1013bc9:	vxorpd %xmm5,%xmm5,%xmm5
 1013bcd:	vmovsd -0x12175(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013bd5:	vmovsd -0x40(%rbp),%xmm2
 1013bda:	vmovapd -0x70(%rbp),%xmm3
 1013bdf:	test   %r14,%r14
 1013be2:	sete   %al
 1013be5:	or     %al,%bl
 1013be7:	movabs $0x7fefffffffffffff,%rbx
 1013bf1:	jne    1013bf9 <entry_run+0x1579>
 1013bf3:	test   %r15,-0x10(%r14)
 1013bf7:	je     1013c05 <entry_run+0x1585>
 1013bf9:	test   %r15,-0x10(%r12)
 1013bfe:	je     1013c24 <entry_run+0x15a4>
 1013c00:	mov    $0x3f,%r14b
 1013c03:	jmp    1013c50 <entry_run+0x15d0>
 1013c05:	mov    -0x18(%r14),%rax
 1013c09:	dec    %rax
 1013c0c:	jne    1013c19 <entry_run+0x1599>
 1013c0e:	cmpq   $0x0,-0x20(%r14)
 1013c13:	je     1013ec4 <entry_run+0x1844>
 1013c19:	mov    %rax,-0x18(%r14)
 1013c1d:	test   %r15,-0x10(%r12)
 1013c22:	jne    1013c00 <entry_run+0x1580>
 1013c24:	mov    -0x18(%r12),%rax
 1013c29:	dec    %rax
 1013c2c:	mov    $0x3f,%r14b
 1013c2f:	jne    1013c3d <entry_run+0x15bd>
 1013c31:	cmpq   $0x0,-0x20(%r12)
 1013c37:	je     1013e77 <entry_run+0x17f7>
 1013c3d:	mov    %rax,-0x18(%r12)
 1013c42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013c50:	vmovsd %xmm2,-0x1d8(%rbp)
 1013c58:	vmulsd -0x121f8(%rip),%xmm2,%xmm0        # 1001a68 <__abi_tag+0x176c>
 1013c60:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 1013c66:	vmovsd -0x1224e(%rip),%xmm1        # 1001a20 <__abi_tag+0x1724>
 1013c6e:	vcmpltsd %xmm2,%xmm1,%xmm1
 1013c73:	vblendvpd %xmm1,-0x1237d(%rip),%xmm0,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013c7d:	vmovupd %xmm3,-0x1d0(%rbp)
 1013c85:	vmovq  %xmm0,%rax
 1013c8a:	bzhi   %r14,%rax,%rax
 1013c8f:	cmp    %rbx,%rax
 1013c92:	jg     1013cc0 <entry_run+0x1640>
 1013c94:	vmovsd -0x1224c(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013c9c:	vucomisd %xmm0,%xmm1
 1013ca0:	ja     1013cc0 <entry_run+0x1640>
 1013ca2:	vucomisd -0x12282(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013caa:	jae    1013cc0 <entry_run+0x1640>
 1013cac:	vcvttsd2si %xmm0,%rdx
 1013cb1:	jmp    1013ccf <entry_run+0x164f>
 1013cb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013cc0:	mov    $0x10043c9,%esi
 1013cc5:	mov    %r9,%rdi
 1013cc8:	call   1014ab0 <fail>
 1013ccd:	xor    %edx,%edx
 1013ccf:	vmovsd -0x1d0(%rbp),%xmm0
 1013cd7:	vmulsd -0x12277(%rip),%xmm0,%xmm1        # 1001a68 <__abi_tag+0x176c>
 1013cdf:	vroundsd $0xb,%xmm1,%xmm1,%xmm1
 1013ce5:	vmovsd -0x122cd(%rip),%xmm2        # 1001a20 <__abi_tag+0x1724>
 1013ced:	vcmpltsd %xmm0,%xmm2,%xmm0
 1013cf2:	vblendvpd %xmm0,-0x123fc(%rip),%xmm1,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013cfc:	vmovq  %xmm0,%rax
 1013d01:	bzhi   %r14,%rax,%rax
 1013d06:	cmp    %rbx,%rax
 1013d09:	jg     1013d30 <entry_run+0x16b0>
 1013d0b:	vmovsd -0x122c3(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013d13:	vucomisd %xmm0,%xmm1
 1013d17:	ja     1013d30 <entry_run+0x16b0>
 1013d19:	vucomisd -0x122f9(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013d21:	jae    1013d30 <entry_run+0x16b0>
 1013d23:	vcvttsd2si %xmm0,%rax
 1013d28:	jmp    1013d3f <entry_run+0x16bf>
 1013d2a:	nopw   0x0(%rax,%rax,1)
 1013d30:	mov    $0x10043c9,%esi
 1013d35:	mov    %r9,%rdi
 1013d38:	call   1014ab0 <fail>
 1013d3d:	xor    %eax,%eax
 1013d3f:	vmovsd -0x1c8(%rbp),%xmm0
 1013d47:	vmulsd -0x122e7(%rip),%xmm0,%xmm1        # 1001a68 <__abi_tag+0x176c>
 1013d4f:	vroundsd $0xb,%xmm1,%xmm1,%xmm1
 1013d55:	vmovsd -0x1233d(%rip),%xmm2        # 1001a20 <__abi_tag+0x1724>
 1013d5d:	vcmpltsd %xmm0,%xmm2,%xmm0
 1013d62:	vblendvpd %xmm0,-0x1246c(%rip),%xmm1,%xmm0        # 1001900 <__abi_tag+0x1604>
 1013d6c:	vmovq  %xmm0,%rcx
 1013d71:	bzhi   %r14,%rcx,%rcx
 1013d76:	cmp    %rbx,%rcx
 1013d79:	jg     1013da0 <entry_run+0x1720>
 1013d7b:	vmovsd -0x12333(%rip),%xmm1        # 1001a50 <__abi_tag+0x1754>
 1013d83:	vucomisd %xmm0,%xmm1
 1013d87:	ja     1013da0 <entry_run+0x1720>
 1013d89:	vucomisd -0x12369(%rip),%xmm0        # 1001a28 <__abi_tag+0x172c>
 1013d91:	jae    1013da0 <entry_run+0x1720>
 1013d93:	vcvttsd2si %xmm0,%rcx
 1013d98:	jmp    1013daf <entry_run+0x172f>
 1013d9a:	nopw   0x0(%rax,%rax,1)
 1013da0:	mov    $0x10043c9,%esi
 1013da5:	mov    %r9,%rdi
 1013da8:	call   1014ab0 <fail>
 1013dad:	xor    %ecx,%ecx
 1013daf:	movabs $0xffff800000000000,%rsi
 1013db9:	add    %rdx,%rsi
 1013dbc:	shr    $0x30,%rsi
 1013dc0:	cmp    $0xfffe,%esi
 1013dc6:	jbe    1014518 <entry_run+0x1e98>
 1013dcc:	movabs $0xff80000000000000,%rsi
 1013dd6:	add    %rax,%rsi
 1013dd9:	shr    $0x38,%rsi
 1013ddd:	cmp    $0xfe,%esi
 1013de3:	jbe    101452d <entry_run+0x1ead>
 1013de9:	shl    $0x10,%rdx
 1013ded:	shl    $0x8,%rax
 1013df1:	mov    %rdx,%r8
 1013df4:	add    %rax,%r8
 1013df7:	jo     1014545 <entry_run+0x1ec5>
 1013dfd:	mov    %r8,%rax
 1013e00:	add    %rcx,%rax
 1013e03:	jo     1014555 <entry_run+0x1ed5>
 1013e09:	mov    %r13,%rdx
 1013e0c:	shl    $0x5,%rdx
 1013e10:	sub    %r13,%rdx
 1013e13:	mov    %rdx,%rcx
 1013e16:	add    %rax,%rcx
 1013e19:	jo     1014565 <entry_run+0x1ee5>
 1013e1f:	mov    %rcx,%rax
 1013e22:	movabs $0x89705f3112a28fe5,%rdx
 1013e2c:	imul   %rdx
 1013e2f:	add    %rcx,%rdx
 1013e32:	mov    %rdx,%rax
 1013e35:	shr    $0x3f,%rax
 1013e39:	sar    $0x1d,%rdx
 1013e3d:	add    %rax,%rdx
 1013e40:	imul   $0x3b9aca07,%rdx,%rax
 1013e47:	sub    %rax,%rcx
 1013e4a:	mov    %rcx,%r13
 1013e4d:	sar    $0x3f,%r13
 1013e51:	and    $0x3b9aca07,%r13d
 1013e58:	add    %rcx,%r13
 1013e5b:	mov    -0x128(%rbp),%rcx
 1013e62:	inc    %rcx
 1013e65:	cmp    $0x780,%rcx
 1013e6c:	jne    10133a0 <entry_run+0xd20>
 1013e72:	jmp    1013350 <entry_run+0xcd0>
 1013e77:	mov    -0x38(%rbp),%rbx
 1013e7b:	mov    %rbx,%rdi
 1013e7e:	mov    %r12,%rsi
 1013e81:	vmovsd %xmm2,-0x40(%rbp)
 1013e86:	vmovapd %xmm3,-0x70(%rbp)
 1013e8b:	vzeroupper
 1013e8e:	call   1018e60 <myl_rc_hold_edge_release>
 1013e93:	mov    %rbx,%rdi
 1013e96:	movabs $0x7fefffffffffffff,%rbx
 1013ea0:	call   101be30 <myl_rc_drain>
 1013ea5:	vmovapd -0x70(%rbp),%xmm3
 1013eaa:	vmovsd -0x40(%rbp),%xmm2
 1013eaf:	vmovsd -0x12457(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013eb7:	vxorpd %xmm5,%xmm5,%xmm5
 1013ebb:	mov    -0x30(%rbp),%r9
 1013ebf:	jmp    1013c50 <entry_run+0x15d0>
 1013ec4:	mov    -0x38(%rbp),%rbx
 1013ec8:	mov    %rbx,%rdi
 1013ecb:	mov    %r14,%rsi
 1013ece:	vmovsd %xmm2,-0x40(%rbp)
 1013ed3:	vmovapd %xmm3,-0x70(%rbp)
 1013ed8:	vzeroupper
 1013edb:	call   1018e60 <myl_rc_hold_edge_release>
 1013ee0:	mov    %rbx,%rdi
 1013ee3:	movabs $0x7fefffffffffffff,%rbx
 1013eed:	call   101be30 <myl_rc_drain>
 1013ef2:	vmovapd -0x70(%rbp),%xmm3
 1013ef7:	vmovsd -0x40(%rbp),%xmm2
 1013efc:	vmovsd -0x124a4(%rip),%xmm6        # 1001a60 <__abi_tag+0x1764>
 1013f04:	vxorpd %xmm5,%xmm5,%xmm5
 1013f08:	mov    -0x30(%rbp),%r9
 1013f0c:	test   %r15,-0x10(%r12)
 1013f11:	jne    1013c00 <entry_run+0x1580>
 1013f17:	jmp    1013c24 <entry_run+0x15a4>
 1013f1c:	mov    $0x1,%edi
 1013f21:	mov    $0x20,%esi
 1013f26:	vzeroupper
 1013f29:	call   1027690 <calloc@plt>
 1013f2e:	mov    %rax,%r12
 1013f31:	test   %rax,%rax
 1013f34:	jne    1013f3f <entry_run+0x18bf>
 1013f36:	mov    -0x30(%rbp),%rdi
 1013f3a:	call   1015290 <myl_qbe_fail_allocation>
 1013f3f:	lea    -0x260(%rbp),%rdi
 1013f46:	mov    $0x18,%esi
 1013f4b:	mov    $0x10040e8,%edx
 1013f50:	mov    %r13,%rcx
 1013f53:	xor    %eax,%eax
 1013f55:	call   10277e0 <snprintf@plt>
 1013f5a:	test   %eax,%eax
 1013f5c:	jle    1014174 <entry_run+0x1af4>
 1013f62:	mov    %eax,%r13d
 1013f65:	mov    $0x40,%r15d
 1013f6b:	cmp    $0x41,%eax
 1013f6e:	jb     1014126 <entry_run+0x1aa6>
 1013f74:	mov    $0x80,%r15d
 1013f7a:	cmp    $0x81,%r13d
 1013f81:	jb     1014126 <entry_run+0x1aa6>
 1013f87:	mov    $0x100,%r15d
 1013f8d:	cmp    $0x101,%r13d
 1013f94:	jb     1014126 <entry_run+0x1aa6>
 1013f9a:	mov    $0x200,%r15d
 1013fa0:	cmp    $0x201,%r13d
 1013fa7:	jb     1014126 <entry_run+0x1aa6>
 1013fad:	mov    $0x400,%r15d
 1013fb3:	cmp    $0x401,%r13d
 1013fba:	jb     1014126 <entry_run+0x1aa6>
 1013fc0:	mov    $0x800,%r15d
 1013fc6:	cmp    $0x801,%r13d
 1013fcd:	jb     1014126 <entry_run+0x1aa6>
 1013fd3:	mov    $0x1000,%r15d
 1013fd9:	cmp    $0x1001,%r13d
 1013fe0:	jb     1014126 <entry_run+0x1aa6>
 1013fe6:	mov    $0x2000,%r15d
 1013fec:	cmp    $0x2001,%r13d
 1013ff3:	jb     1014126 <entry_run+0x1aa6>
 1013ff9:	mov    $0x4000,%r15d
 1013fff:	cmp    $0x4001,%r13d
 1014006:	jb     1014126 <entry_run+0x1aa6>
 101400c:	mov    $0x8000,%r15d
 1014012:	cmp    $0x8001,%r13d
 1014019:	jb     1014126 <entry_run+0x1aa6>
 101401f:	mov    $0x10000,%r15d
 1014025:	cmp    $0x10001,%r13d
 101402c:	jb     1014126 <entry_run+0x1aa6>
 1014032:	mov    $0x20000,%r15d
 1014038:	cmp    $0x20001,%r13d
 101403f:	jb     1014126 <entry_run+0x1aa6>
 1014045:	mov    $0x40000,%r15d
 101404b:	cmp    $0x40001,%r13d
 1014052:	jb     1014126 <entry_run+0x1aa6>
 1014058:	mov    $0x80000,%r15d
 101405e:	cmp    $0x80001,%r13d
 1014065:	jb     1014126 <entry_run+0x1aa6>
 101406b:	mov    $0x100000,%r15d
 1014071:	cmp    $0x100001,%r13d
 1014078:	jb     1014126 <entry_run+0x1aa6>
 101407e:	mov    $0x200000,%r15d
 1014084:	cmp    $0x200001,%r13d
 101408b:	jb     1014126 <entry_run+0x1aa6>
 1014091:	mov    $0x400000,%r15d
 1014097:	cmp    $0x400001,%r13d
 101409e:	jb     1014126 <entry_run+0x1aa6>
 10140a4:	mov    $0x800000,%r15d
 10140aa:	cmp    $0x800001,%r13d
 10140b1:	jb     1014126 <entry_run+0x1aa6>
 10140b3:	mov    $0x1000000,%r15d
 10140b9:	cmp    $0x1000001,%r13d
 10140c0:	jb     1014126 <entry_run+0x1aa6>
 10140c2:	mov    $0x2000000,%r15d
 10140c8:	cmp    $0x2000001,%r13d
 10140cf:	jb     1014126 <entry_run+0x1aa6>
 10140d1:	mov    $0x4000000,%r15d
 10140d7:	cmp    $0x4000001,%r13d
 10140de:	jb     1014126 <entry_run+0x1aa6>
 10140e0:	mov    $0x8000000,%r15d
 10140e6:	cmp    $0x8000001,%r13d
 10140ed:	jb     1014126 <entry_run+0x1aa6>
 10140ef:	mov    $0x10000000,%r15d
 10140f5:	cmp    $0x10000001,%r13d
 10140fc:	jb     1014126 <entry_run+0x1aa6>
 10140fe:	mov    $0x20000000,%r15d
 1014104:	cmp    $0x20000001,%r13d
 101410b:	jb     1014126 <entry_run+0x1aa6>
 101410d:	xor    %r15d,%r15d
 1014110:	cmp    $0x40000001,%r13d
 1014117:	setae  %r15b
 101411b:	shl    $0x1e,%r15d
 101411f:	add    $0x40000000,%r15
 1014126:	mov    %r15,%rdi
 1014129:	call   1027680 <malloc@plt>
 101412e:	test   %rax,%rax
 1014131:	je     10141a5 <entry_run+0x1b25>
 1014133:	mov    %r13d,%r14d
 1014136:	mov    %rax,(%r12)
 101413a:	mov    %r15,0x10(%r12)
 101413f:	lea    -0x260(%rbp),%rsi
 1014146:	mov    %rax,-0x40(%rbp)
 101414a:	mov    %rax,%rdi
 101414d:	mov    %r14,%rdx
 1014150:	call   10276a0 <memcpy@plt>
 1014155:	lea    0x8(%r12),%r13
 101415a:	mov    %r14,0x8(%r12)
 101415f:	mov    %r12,%rbx
 1014162:	add    $0x18,%rbx
 1014166:	cmp    %r14,%r15
 1014169:	jne    10141c7 <entry_run+0x1b47>
 101416b:	add    %r15,%r15
 101416e:	mov    -0x40(%rbp),%rdi
 1014172:	jmp    1014188 <entry_run+0x1b08>
 1014174:	lea    0x18(%r12),%rbx
 1014179:	mov    %r12,%r13
 101417c:	add    $0x8,%r13
 1014180:	mov    $0x40,%r15d
 1014186:	xor    %edi,%edi
 1014188:	mov    %r15,%rsi
 101418b:	call   10277f0 <realloc@plt>
 1014190:	test   %rax,%rax
 1014193:	je     10141bb <entry_run+0x1b3b>
 1014195:	mov    %rax,(%r12)
 1014199:	mov    %r15,0x10(%r12)
 101419e:	mov    0x8(%r12),%r14
 10141a3:	jmp    10141cb <entry_run+0x1b4b>
 10141a5:	mov    %r12,%rbx
 10141a8:	add    $0x18,%rbx
 10141ac:	movl   $0x1,0x18(%r12)
 10141b5:	mov    -0x30(%rbp),%rdi
 10141b9:	jmp    10141d8 <entry_run+0x1b58>
 10141bb:	movl   $0x1,(%rbx)
 10141c1:	mov    -0x30(%rbp),%rdi
 10141c5:	jmp    10141d8 <entry_run+0x1b58>
 10141c7:	mov    -0x40(%rbp),%rax
 10141cb:	mov    -0x30(%rbp),%rdi
 10141cf:	movb   $0xa,(%rax,%r14,1)
 10141d4:	incq   0x0(%r13)
 10141d8:	movabs $0x4000000000000002,%r14
 10141e2:	cmpl   $0x0,0x1c(%r12)
 10141e8:	je     10141f6 <entry_run+0x1b76>
 10141ea:	mov    $0x1003d5c,%esi
 10141ef:	call   1014ab0 <fail>
 10141f4:	jmp    1014204 <entry_run+0x1b84>
 10141f6:	cmpl   $0x0,(%rbx)
 10141f9:	je     10142b3 <entry_run+0x1c33>
 10141ff:	call   1015290 <myl_qbe_fail_allocation>
 1014204:	mov    (%r12),%rdi
 1014208:	vzeroupper
 101420b:	call   10276f0 <free@plt>
 1014210:	mov    %r12,%rdi
 1014213:	call   10276f0 <free@plt>
 1014218:	cmpb   $0x1,0x17711(%rip)        # 102b930 <exit_without_sweep>
 101421f:	jne    101424e <entry_run+0x1bce>
 1014221:	mov    -0x30(%rbp),%rax
 1014225:	cmpl   $0x0,0x2c0(%rax)
 101422c:	jne    101424e <entry_run+0x1bce>
 101422e:	mov    -0x30(%rbp),%rax
 1014232:	cmpq   $0x0,0x3990(%rax)
 101423a:	jne    101424e <entry_run+0x1bce>
 101423c:	mov    -0x30(%rbp),%rax
 1014240:	cmpq   $0x0,0x3998(%rax)
 1014248:	je     10144b0 <entry_run+0x1e30>
 101424e:	mov    -0x80(%rbp),%rax
 1014252:	test   %rax,%rax
 1014255:	je     1014275 <entry_run+0x1bf5>
 1014257:	test   %r14,-0x10(%rax)
 101425b:	jne    1014275 <entry_run+0x1bf5>
 101425d:	mov    -0x20(%rax),%rcx
 1014261:	dec    %rcx
 1014264:	jne    1014271 <entry_run+0x1bf1>
 1014266:	cmpq   $0x0,-0x18(%rax)
 101426b:	je     10143af <entry_run+0x1d2f>
 1014271:	mov    %rcx,-0x20(%rax)
 1014275:	cmpl   $0x0,-0x50(%rbp)
 1014279:	je     10144b0 <entry_run+0x1e30>
 101427f:	mov    -0x48(%rbp),%rax
 1014283:	test   %rax,%rax
 1014286:	je     10144b0 <entry_run+0x1e30>
 101428c:	test   %r14,-0x10(%rax)
 1014290:	jne    10144b0 <entry_run+0x1e30>
 1014296:	mov    -0x20(%rax),%rcx
 101429a:	dec    %rcx
 101429d:	jne    10142aa <entry_run+0x1c2a>
 101429f:	cmpq   $0x0,-0x18(%rax)
 10142a4:	je     10143cb <entry_run+0x1d4b>
 10142aa:	mov    %rcx,-0x20(%rax)
 10142ae:	jmp    10144b0 <entry_run+0x1e30>
 10142b3:	mov    0x14a66(%rip),%rax        # 1028d20 <stdout@GLIBC_2.2.5>
 10142ba:	mov    (%rax),%r14
 10142bd:	mov    0x8(%r12),%r15
 10142c2:	test   %r15,%r15
 10142c5:	je     10142e4 <entry_run+0x1c64>
 10142c7:	mov    (%r12),%rdi
 10142cb:	mov    $0x1,%esi
 10142d0:	mov    %r15,%rdx
 10142d3:	mov    %r14,%rcx
 10142d6:	call   1027750 <fwrite@plt>
 10142db:	cmp    %r15,%rax
 10142de:	jne    1014392 <entry_run+0x1d12>
 10142e4:	mov    %r14,%rdi
 10142e7:	call   1027800 <fflush@plt>
 10142ec:	test   %eax,%eax
 10142ee:	movabs $0x4000000000000002,%r14
 10142f8:	je     1014204 <entry_run+0x1b84>
 10142fe:	mov    $0x10042d4,%esi
 1014303:	mov    -0x30(%rbp),%rdi
 1014307:	jmp    10141ef <entry_run+0x1b6f>
 101430c:	mov    -0x30(%rbp),%rdi
 1014310:	mov    0x1860(%rdi),%rax
 1014317:	test   %rax,%rax
 101431a:	je     10144f8 <entry_run+0x1e78>
 1014320:	mov    0x124(%rax),%esi
 1014326:	movl   $0x0,0x124(%rax)
 1014330:	call   1014620 <myl_qbe_rc_status>
 1014335:	jmp    10144b0 <entry_run+0x1e30>
 101433a:	mov    %r14,-0x260(%rbp)
 1014341:	lea    -0xf8(%rbp),%rax
 1014348:	mov    %rax,-0x258(%rbp)
 101434f:	movq   $0x0,-0x250(%rbp)
 101435a:	mov    %ebx,-0x248(%rbp)
 1014360:	movl   $0x0,-0x244(%rbp)
 101436a:	lea    -0x260(%rbp),%rsi
 1014371:	lea    -0x58(%rbp),%rcx
 1014375:	mov    -0x38(%rbp),%rdi
 1014379:	mov    %r14,%rdx
 101437c:	call   101eb00 <transfer>
 1014381:	mov    -0x30(%rbp),%r9
 1014385:	test   %eax,%eax
 1014387:	jne    1012a9b <entry_run+0x41b>
 101438d:	jmp    10129df <entry_run+0x35f>
 1014392:	mov    $0x10042d4,%esi
 1014397:	mov    -0x30(%rbp),%rdi
 101439b:	call   1014ab0 <fail>
 10143a0:	movabs $0x4000000000000002,%r14
 10143aa:	jmp    1014204 <entry_run+0x1b84>
 10143af:	lea    -0x80(%rbp),%rsi
 10143b3:	mov    -0x38(%rbp),%rdi
 10143b7:	call   100f700 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10143bc:	cmpl   $0x0,-0x50(%rbp)
 10143c0:	jne    101427f <entry_run+0x1bff>
 10143c6:	jmp    10144b0 <entry_run+0x1e30>
 10143cb:	lea    -0x48(%rbp),%rsi
 10143cf:	mov    -0x38(%rbp),%rdi
 10143d3:	call   100f700 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10143d8:	jmp    10144b0 <entry_run+0x1e30>
 10143dd:	lea    -0x48(%rbp),%rsi
 10143e1:	mov    -0x38(%rbp),%rdi
 10143e5:	vzeroupper
 10143e8:	call   100f700 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10143ed:	mov    -0x30(%rbp),%r9
 10143f1:	jmp    1013258 <entry_run+0xbd8>
 10143f6:	mov    $0x1002338,%esi
 10143fb:	call   1018f74 <myl_rc_binding_find_slow>
 1014400:	mov    %rax,%r12
 1014403:	test   %r12,%r12
 1014406:	jne    101292e <entry_run+0x2ae>
 101440c:	mov    $0x1002338,%esi
 1014411:	mov    -0x38(%rbp),%rdi
 1014415:	call   10234b0 <myl_rc_native_shape>
 101441a:	mov    -0x30(%rbp),%r9
 101441e:	test   %rax,%rax
 1014421:	je     101445c <entry_run+0x1ddc>
 1014423:	mov    0x1860(%r9),%rdi
 101442a:	cmpq   $0x1a,0xa0(%rdi)
 1014432:	jb     10144c7 <entry_run+0x1e47>
 1014438:	mov    0x98(%rdi),%rax
 101443f:	cmpq   $0x1002338,0x190(%rax)
 101444a:	jne    10144c7 <entry_run+0x1e47>
 101444c:	mov    0x198(%rax),%r12
 1014453:	test   %r12,%r12
 1014456:	jne    101292e <entry_run+0x2ae>
 101445c:	mov    0x1860(%r9),%rcx
 1014463:	test   %rcx,%rcx
 1014466:	je     10144f8 <entry_run+0x1e78>
 101446c:	mov    0x124(%rcx),%eax
 1014472:	movl   $0x0,0x124(%rcx)
 101447c:	test   %rax,%rax
 101447f:	je     10144b0 <entry_run+0x1e30>
 1014481:	cmp    $0x1,%eax
 1014484:	jne    101449a <entry_run+0x1e1a>
 1014486:	mov    $0x1004361,%esi
 101448b:	mov    -0x30(%rbp),%rdi
 101448f:	cmpl   $0x0,0x2c4(%rdi)
 1014496:	jne    10144ab <entry_run+0x1e2b>
 1014498:	jmp    10144a3 <entry_run+0x1e23>
 101449a:	cmp    $0x4,%eax
 101449d:	mov    -0x30(%rbp),%rdi
 10144a1:	jae    10144fd <entry_run+0x1e7d>
 10144a3:	mov    0x100b5d0(,%rax,8),%rsi
 10144ab:	call   1014ab0 <fail>
 10144b0:	xor    %eax,%eax
 10144b2:	add    $0x408,%rsp
 10144b9:	pop    %rbx
 10144ba:	pop    %r12
 10144bc:	pop    %r13
 10144be:	pop    %r14
 10144c0:	pop    %r15
 10144c2:	pop    %rbp
 10144c3:	vzeroupper
 10144c6:	ret
 10144c7:	mov    $0x1002338,%esi
 10144cc:	call   1018f74 <myl_rc_binding_find_slow>
 10144d1:	mov    %rax,%r12
 10144d4:	test   %r12,%r12
 10144d7:	jne    101292e <entry_run+0x2ae>
 10144dd:	jmp    101445c <entry_run+0x1ddc>
 10144e2:	mov    %r9,%rdi
 10144e5:	vzeroupper
 10144e8:	call   1015320 <myl_qbe_fail_iteration>
 10144ed:	mov    %r9,%rdi
 10144f0:	vzeroupper
 10144f3:	call   1015460 <myl_qbe_fail_frame>
 10144f8:	call   1018954 <myl_rc_invariant_failed>
 10144fd:	call   1027810 <abort@plt>
 1014502:	mov    %r9,%rdi
 1014505:	vzeroupper
 1014508:	call   1015460 <myl_qbe_fail_frame>
 101450d:	mov    %r9,%rdi
 1014510:	vzeroupper
 1014513:	call   1015460 <myl_qbe_fail_frame>
 1014518:	mov    $0x2,%esi
 101451d:	mov    $0x10000,%ecx
 1014522:	mov    %r9,%rdi
 1014525:	vzeroupper
 1014528:	call   10153a0 <myl_qbe_fail_overflow_op>
 101452d:	mov    $0x2,%esi
 1014532:	mov    $0x100,%ecx
 1014537:	mov    %r9,%rdi
 101453a:	mov    %rax,%rdx
 101453d:	vzeroupper
 1014540:	call   10153a0 <myl_qbe_fail_overflow_op>
 1014545:	mov    %r9,%rdi
 1014548:	xor    %esi,%esi
 101454a:	mov    %rax,%rcx
 101454d:	vzeroupper
 1014550:	call   10153a0 <myl_qbe_fail_overflow_op>
 1014555:	mov    %r9,%rdi
 1014558:	xor    %esi,%esi
 101455a:	mov    %r8,%rdx
 101455d:	vzeroupper
 1014560:	call   10153a0 <myl_qbe_fail_overflow_op>
 1014565:	mov    %r9,%rdi
 1014568:	xor    %esi,%esi
 101456a:	mov    %rax,%rcx
 101456d:	vzeroupper
 1014570:	call   10153a0 <myl_qbe_fail_overflow_op>
 1014575:	mov    %r9,%rdi
 1014578:	vzeroupper
 101457b:	call   1015460 <myl_qbe_fail_frame>
 1014580:	mov    %r9,%rdi
 1014583:	vzeroupper
 1014586:	call   1015320 <myl_qbe_fail_iteration>
 101458b:	mov    %r9,%rdi
 101458e:	mov    %r13,%rsi
 1014591:	vzeroupper
 1014594:	call   1015400 <myl_qbe_fail_cast>
 1014599:	mov    %r9,%rdi
 101459c:	mov    %r14,%rsi
 101459f:	mov    %r13,%rdx
 10145a2:	vzeroupper
 10145a5:	call   1015330 <myl_qbe_fail_normalized_index_bounds>
 10145aa:	mov    %r9,%rdi
 10145ad:	vzeroupper
 10145b0:	call   1015460 <myl_qbe_fail_frame>
 10145b5:	mov    %r9,%rdi
 10145b8:	mov    %r14,%rsi
 10145bb:	vzeroupper
 10145be:	call   1015400 <myl_qbe_fail_cast>
 10145c3:	mov    %r9,%rdi
 10145c6:	vzeroupper
 10145c9:	call   1015290 <myl_qbe_fail_allocation>
 10145ce:	mov    %r9,%rdi
 10145d1:	vzeroupper
 10145d4:	call   1015460 <myl_qbe_fail_frame>
 10145d9:	mov    %r9,%rdi
 10145dc:	call   1015290 <myl_qbe_fail_allocation>
 10145e1:	mov    %r9,%rdi
 10145e4:	call   1015290 <myl_qbe_fail_allocation>
 10145e9:	mov    %r9,%rdi
 10145ec:	call   1015290 <myl_qbe_fail_allocation>
 10145f1:	mov    %r9,%rdi
 10145f4:	call   1015290 <myl_qbe_fail_allocation>
 10145f9:	mov    %r9,%rdi
 10145fc:	call   1015290 <myl_qbe_fail_allocation>
 1014601:	mov    %r9,%rdi
 1014604:	call   1015290 <myl_qbe_fail_allocation>
 1014609:	mov    %r9,%rdi
 101460c:	vzeroupper
 101460f:	call   1015460 <myl_qbe_fail_frame>
 1014614:	int3
 1014615:	int3
 1014616:	int3
 1014617:	int3
 1014618:	int3
 1014619:	int3
 101461a:	int3
 101461b:	int3
 101461c:	int3
 101461d:	int3
 101461e:	int3
 101461f:	int3

0000000001014620 <myl_qbe_rc_status>:
 1014620:	push   %rbp
 1014621:	mov    %rsp,%rbp
 1014624:	test   %esi,%esi
 1014626:	je     1014654 <myl_qbe_rc_status+0x34>
 1014628:	cmp    $0x1,%esi
 101462b:	jne    101463d <myl_qbe_rc_status+0x1d>
 101462d:	mov    $0x1004361,%eax
 1014632:	cmpl   $0x0,0x2c4(%rdi)
 1014639:	jne    101464c <myl_qbe_rc_status+0x2c>
 101463b:	jmp    1014642 <myl_qbe_rc_status+0x22>
 101463d:	cmp    $0x4,%esi
 1014640:	jae    1014656 <myl_qbe_rc_status+0x36>
 1014642:	mov    %esi,%eax
 1014644:	mov    0x100b5d0(,%rax,8),%rax
 101464c:	mov    %rax,%rsi
 101464f:	call   1014ab0 <fail>
 1014654:	pop    %rbp
 1014655:	ret
 1014656:	call   1027810 <abort@plt>
 101465b:	int3
 101465c:	int3
 101465d:	int3
 101465e:	int3
 101465f:	int3

0000000001014660 <myl_qbe_rc_trap>:
 1014660:	push   %rbp
 1014661:	mov    %rsp,%rbp
 1014664:	push   %r15
 1014666:	push   %r14
 1014668:	push   %r13
 101466a:	push   %r12
 101466c:	push   %rbx
 101466d:	push   %rax
 101466e:	mov    0x1860(%rdi),%rax
 1014675:	test   %rax,%rax
 1014678:	je     101476c <myl_qbe_rc_trap+0x10c>
 101467e:	mov    0xf8(%rax),%r14
 1014685:	movq   $0x0,0xf8(%rax)
 1014690:	test   %r14,%r14
 1014693:	je     101476c <myl_qbe_rc_trap+0x10c>
 1014699:	vxorps %xmm0,%xmm0,%xmm0
 101469d:	lea    0x258(%rdi),%rbx
 10146a4:	jmp    10146cd <myl_qbe_rc_trap+0x6d>
 10146a6:	cs nopw 0x0(%rax,%rax,1)
 10146b0:	add    $0x8,%r14
 10146b4:	vmovups %xmm0,(%r14)
 10146b9:	movl   $0x0,0x10(%r14)
 10146c1:	mov    %r15,%r14
 10146c4:	test   %r15,%r15
 10146c7:	je     101476c <myl_qbe_rc_trap+0x10c>
 10146cd:	mov    0x8(%r14),%r15
 10146d1:	mov    0x10(%r14),%rsi
 10146d5:	test   %rsi,%rsi
 10146d8:	je     10146b0 <myl_qbe_rc_trap+0x50>
 10146da:	nopw   0x0(%rax,%rax,1)
 10146e0:	mov    (%rsi),%r12
 10146e3:	mov    0x1860(%rdi),%rax
 10146ea:	mov    0x108(%rax),%rcx
 10146f1:	cmp    $0x20,%rcx
 10146f5:	je     1014749 <myl_qbe_rc_trap+0xe9>
 10146f7:	mov    0x270(%rdi),%rdx
 10146fe:	cmp    $0x28,%rdx
 1014702:	jb     101477b <myl_qbe_rc_trap+0x11b>
 1014704:	mov    0x30(%rax),%r8
 1014708:	cmp    $0x27,%r8
 101470c:	jbe    101477b <myl_qbe_rc_trap+0x11b>
 101470e:	add    $0xffffffffffffffd8,%rdx
 1014712:	mov    %rdx,0x270(%rdi)
 1014719:	add    $0xffffffffffffffd8,%r8
 101471d:	mov    %r8,0x30(%rax)
 1014721:	mov    0x100(%rax),%rdx
 1014728:	mov    %rdx,(%rsi)
 101472b:	mov    %rsi,0x100(%rax)
 1014732:	inc    %rcx
 1014735:	mov    %rcx,0x108(%rax)
 101473c:	mov    %r12,%rsi
 101473f:	test   %r12,%r12
 1014742:	jne    10146e0 <myl_qbe_rc_trap+0x80>
 1014744:	jmp    10146b0 <myl_qbe_rc_trap+0x50>
 1014749:	mov    %rdi,%r13
 101474c:	mov    %rbx,%rdi
 101474f:	call   101e50f <entry_release>
 1014754:	vxorps %xmm0,%xmm0,%xmm0
 1014758:	mov    %r13,%rdi
 101475b:	mov    %r12,%rsi
 101475e:	test   %r12,%r12
 1014761:	jne    10146e0 <myl_qbe_rc_trap+0x80>
 1014767:	jmp    10146b0 <myl_qbe_rc_trap+0x50>
 101476c:	add    $0x8,%rsp
 1014770:	pop    %rbx
 1014771:	pop    %r12
 1014773:	pop    %r13
 1014775:	pop    %r14
 1014777:	pop    %r15
 1014779:	pop    %rbp
 101477a:	ret
 101477b:	call   1018954 <myl_rc_invariant_failed>

0000000001014780 <myl_qbe_rc_unique_local>:
 1014780:	push   %rbp
 1014781:	mov    %rsp,%rbp
 1014784:	push   %r15
 1014786:	push   %r14
 1014788:	push   %r13
 101478a:	push   %r12
 101478c:	push   %rbx
 101478d:	push   %rax
 101478e:	mov    (%rsi),%rcx
 1014791:	mov    $0x1,%eax
 1014796:	test   %rcx,%rcx
 1014799:	je     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 101479f:	movabs $0x2000000000000002,%r9
 10147a9:	mov    -0x10(%rcx),%r8
 10147ad:	test   %r9,%r8
 10147b0:	je     10148c7 <myl_qbe_rc_unique_local+0x147>
 10147b6:	mov    0x1860(%rdi),%rcx
 10147bd:	cmpq   $0x1a,0xa0(%rcx)
 10147c5:	jb     1014a79 <myl_qbe_rc_unique_local+0x2f9>
 10147cb:	mov    0x98(%rcx),%r8
 10147d2:	cmpq   $0x1002338,0x190(%r8)
 10147dd:	jne    1014a79 <myl_qbe_rc_unique_local+0x2f9>
 10147e3:	mov    0x198(%r8),%rcx
 10147ea:	test   %rcx,%rcx
 10147ed:	je     1014a27 <myl_qbe_rc_unique_local+0x2a7>
 10147f3:	mov    0x8(%rcx),%rcx
 10147f7:	cmpl   $0x1,0x8(%rcx)
 10147fb:	jne    1014a27 <myl_qbe_rc_unique_local+0x2a7>
 1014801:	mov    (%rsi),%rbx
 1014804:	test   %rbx,%rbx
 1014807:	je     1014903 <myl_qbe_rc_unique_local+0x183>
 101480d:	mov    -0x10(%rbx),%r10
 1014811:	mov    %r10,%r11
 1014814:	shr    $0x28,%r11
 1014818:	and    $0xfffff,%r11d
 101481f:	xor    %r8d,%r8d
 1014822:	bt     $0x3e,%r10
 1014827:	cmovb  %r11d,%r8d
 101482b:	lea    0x258(%rdi),%r14
 1014832:	cmpl   $0x0,(%rdx)
 1014835:	mov    (%rcx),%rcx
 1014838:	je     1014919 <myl_qbe_rc_unique_local+0x199>
 101483e:	cmp    $0x8,%rcx
 1014842:	jne    1014a27 <myl_qbe_rc_unique_local+0x2a7>
 1014848:	test   %rbx,%rbx
 101484b:	je     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 1014851:	mov    -0x10(%rbx),%rcx
 1014855:	movabs $0x6000000000000002,%rdx
 101485f:	test   %rdx,%rcx
 1014862:	jne    1014872 <myl_qbe_rc_unique_local+0xf2>
 1014864:	cmpq   $0x0,0x1860(%rdi)
 101486c:	je     1014a27 <myl_qbe_rc_unique_local+0x2a7>
 1014872:	test   %r9,%rcx
 1014875:	je     10149a1 <myl_qbe_rc_unique_local+0x221>
 101487b:	mov    %rsi,%r12
 101487e:	mov    %rdi,%r15
 1014881:	movq   $0x0,-0x30(%rbp)
 1014889:	lea    -0x30(%rbp),%rcx
 101488d:	mov    %r14,%rdi
 1014890:	mov    %rbx,%rsi
 1014893:	mov    %r8d,%edx
 1014896:	call   1020d40 <clone_payload>
 101489b:	test   %eax,%eax
 101489d:	je     10149c9 <myl_qbe_rc_unique_local+0x249>
 10148a3:	cmp    $0x1,%eax
 10148a6:	jne    1014a2c <myl_qbe_rc_unique_local+0x2ac>
 10148ac:	mov    $0x1004361,%esi
 10148b1:	mov    %r15,%rdi
 10148b4:	cmpl   $0x0,0x2c4(%r15)
 10148bc:	jne    1014a63 <myl_qbe_rc_unique_local+0x2e3>
 10148c2:	jmp    1014a34 <myl_qbe_rc_unique_local+0x2b4>
 10148c7:	bt     $0x3e,%r8
 10148cc:	jb     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 10148d2:	test   $0x1,%r8b
 10148d6:	jne    1014a27 <myl_qbe_rc_unique_local+0x2a7>
 10148dc:	mov    -0x20(%rcx),%r8
 10148e0:	cmp    $0x1,%r8
 10148e4:	je     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 10148ea:	test   %r8,%r8
 10148ed:	jne    10147b6 <myl_qbe_rc_unique_local+0x36>
 10148f3:	cmpq   $0x0,-0x18(%rcx)
 10148f8:	jne    1014a6a <myl_qbe_rc_unique_local+0x2ea>
 10148fe:	jmp    1014a27 <myl_qbe_rc_unique_local+0x2a7>
 1014903:	xor    %r8d,%r8d
 1014906:	lea    0x258(%rdi),%r14
 101490d:	cmpl   $0x0,(%rdx)
 1014910:	mov    (%rcx),%rcx
 1014913:	jne    101483e <myl_qbe_rc_unique_local+0xbe>
 1014919:	cmp    $0x8,%rcx
 101491d:	jne    1014a27 <myl_qbe_rc_unique_local+0x2a7>
 1014923:	test   %rbx,%rbx
 1014926:	je     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 101492c:	mov    -0x10(%rbx),%rcx
 1014930:	movabs $0x6000000000000002,%r10
 101493a:	test   %r10,%rcx
 101493d:	jne    101494d <myl_qbe_rc_unique_local+0x1cd>
 101493f:	cmpq   $0x0,0x1860(%rdi)
 1014947:	je     1014a27 <myl_qbe_rc_unique_local+0x2a7>
 101494d:	test   %r9,%rcx
 1014950:	je     1014a01 <myl_qbe_rc_unique_local+0x281>
 1014956:	mov    %rdx,%r12
 1014959:	mov    %rsi,%r13
 101495c:	mov    %rdi,%r15
 101495f:	movq   $0x0,-0x30(%rbp)
 1014967:	lea    -0x30(%rbp),%rcx
 101496b:	mov    %r14,%rdi
 101496e:	mov    %rbx,%rsi
 1014971:	mov    %r8d,%edx
 1014974:	call   1020d40 <clone_payload>
 1014979:	mov    %eax,%ecx
 101497b:	xor    %edx,%edx
 101497d:	test   %eax,%eax
 101497f:	jne    1014985 <myl_qbe_rc_unique_local+0x205>
 1014981:	mov    -0x30(%rbp),%rdx
 1014985:	mov    $0x1,%eax
 101498a:	jne    1014a38 <myl_qbe_rc_unique_local+0x2b8>
 1014990:	mov    %rdx,0x0(%r13)
 1014994:	movl   $0x1,(%r12)
 101499c:	jmp    1014a6a <myl_qbe_rc_unique_local+0x2ea>
 10149a1:	bt     $0x3e,%rcx
 10149a6:	jb     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 10149ac:	test   $0x1,%cl
 10149af:	jne    1014a27 <myl_qbe_rc_unique_local+0x2a7>
 10149b1:	mov    -0x20(%rbx),%rcx
 10149b5:	cmp    $0x1,%rcx
 10149b9:	je     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 10149bf:	test   %rcx,%rcx
 10149c2:	je     1014a20 <myl_qbe_rc_unique_local+0x2a0>
 10149c4:	jmp    101487b <myl_qbe_rc_unique_local+0xfb>
 10149c9:	mov    -0x30(%rbp),%rax
 10149cd:	mov    %rax,(%r12)
 10149d1:	mov    %r14,%rdi
 10149d4:	mov    %rbx,%rsi
 10149d7:	call   1018d40 <myl_rc_edge_release>
 10149dc:	mov    0x1860(%r15),%rax
 10149e3:	test   %rax,%rax
 10149e6:	je     10149fa <myl_qbe_rc_unique_local+0x27a>
 10149e8:	cmpq   $0x0,0xc8(%rax)
 10149f0:	je     10149fa <myl_qbe_rc_unique_local+0x27a>
 10149f2:	mov    %r14,%rdi
 10149f5:	call   101be30 <myl_rc_drain>
 10149fa:	mov    $0x1,%eax
 10149ff:	jmp    1014a6a <myl_qbe_rc_unique_local+0x2ea>
 1014a01:	bt     $0x3e,%rcx
 1014a06:	jb     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 1014a08:	test   $0x1,%cl
 1014a0b:	jne    1014a27 <myl_qbe_rc_unique_local+0x2a7>
 1014a0d:	mov    -0x20(%rbx),%rcx
 1014a11:	cmp    $0x1,%rcx
 1014a15:	je     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 1014a17:	test   %rcx,%rcx
 1014a1a:	jne    1014956 <myl_qbe_rc_unique_local+0x1d6>
 1014a20:	cmpq   $0x0,-0x18(%rbx)
 1014a25:	jne    1014a6a <myl_qbe_rc_unique_local+0x2ea>
 1014a27:	call   1018954 <myl_rc_invariant_failed>
 1014a2c:	cmp    $0x4,%eax
 1014a2f:	mov    %r15,%rdi
 1014a32:	jae    1014aa5 <myl_qbe_rc_unique_local+0x325>
 1014a34:	mov    %eax,%eax
 1014a36:	jmp    1014a5b <myl_qbe_rc_unique_local+0x2db>
 1014a38:	test   %ecx,%ecx
 1014a3a:	je     1014a6a <myl_qbe_rc_unique_local+0x2ea>
 1014a3c:	mov    %r15,%rdi
 1014a3f:	cmp    $0x1,%ecx
 1014a42:	jne    1014a54 <myl_qbe_rc_unique_local+0x2d4>
 1014a44:	mov    $0x1004361,%esi
 1014a49:	cmpl   $0x0,0x2c4(%rdi)
 1014a50:	jne    1014a63 <myl_qbe_rc_unique_local+0x2e3>
 1014a52:	jmp    1014a59 <myl_qbe_rc_unique_local+0x2d9>
 1014a54:	cmp    $0x4,%ecx
 1014a57:	jae    1014aa5 <myl_qbe_rc_unique_local+0x325>
 1014a59:	mov    %ecx,%eax
 1014a5b:	mov    0x100b5d0(,%rax,8),%rsi
 1014a63:	call   1014ab0 <fail>
 1014a68:	xor    %eax,%eax
 1014a6a:	add    $0x8,%rsp
 1014a6e:	pop    %rbx
 1014a6f:	pop    %r12
 1014a71:	pop    %r13
 1014a73:	pop    %r14
 1014a75:	pop    %r15
 1014a77:	pop    %rbp
 1014a78:	ret
 1014a79:	mov    %rsi,%r8
 1014a7c:	mov    $0x1002338,%esi
 1014a81:	mov    %rdi,%r10
 1014a84:	mov    %rcx,%rdi
 1014a87:	call   1018f74 <myl_rc_binding_find_slow>
 1014a8c:	mov    %r8,%rsi
 1014a8f:	mov    %r10,%rdi
 1014a92:	mov    %rax,%rcx
 1014a95:	mov    $0x1,%eax
 1014a9a:	test   %rcx,%rcx
 1014a9d:	jne    10147f3 <myl_qbe_rc_unique_local+0x73>
 1014aa3:	jmp    1014a27 <myl_qbe_rc_unique_local+0x2a7>
 1014aa5:	call   1027810 <abort@plt>
 1014aaa:	int3
 1014aab:	int3
 1014aac:	int3
 1014aad:	int3
 1014aae:	int3
 1014aaf:	int3

0000000001014ab0 <fail>:
 1014ab0:	push   %rbp
 1014ab1:	mov    %rsp,%rbp
 1014ab4:	push   %r10
 1014ab6:	push   %r9
 1014ab8:	push   %r8
 1014aba:	push   %rdi
 1014abb:	push   %rsi
 1014abc:	push   %rdx
 1014abd:	push   %rcx
 1014abe:	push   %rax
 1014abf:	push   %r15
 1014ac1:	push   %r14
 1014ac3:	push   %rbx
 1014ac4:	and    $0xffffffffffffffe0,%rsp
 1014ac8:	sub    $0x240,%rsp
 1014acf:	vmovups %ymm15,-0x90(%rbp)
 1014ad7:	vmovups %ymm14,-0xb0(%rbp)
 1014adf:	vmovups %ymm13,-0xd0(%rbp)
 1014ae7:	vmovups %ymm12,-0xf0(%rbp)
 1014aef:	vmovups %ymm11,-0x110(%rbp)
 1014af7:	vmovups %ymm10,-0x130(%rbp)
 1014aff:	vmovups %ymm9,-0x150(%rbp)
 1014b07:	vmovups %ymm8,-0x170(%rbp)
 1014b0f:	vmovups %ymm7,-0x190(%rbp)
 1014b17:	vmovups %ymm6,-0x1b0(%rbp)
 1014b1f:	vmovups %ymm5,-0x1d0(%rbp)
 1014b27:	vmovups %ymm4,-0x1f0(%rbp)
 1014b2f:	vmovups %ymm3,-0x210(%rbp)
 1014b37:	vmovups %ymm2,-0x230(%rbp)
 1014b3f:	vmovups %ymm1,-0x250(%rbp)
 1014b47:	vmovups %ymm0,-0x270(%rbp)
 1014b4f:	cmpq   $0x0,0x20(%rdi)
 1014b54:	jne    1014bde <fail+0x12e>
 1014b5a:	mov    %rdi,%rbx
 1014b5d:	mov    %rsi,0x20(%rdi)
 1014b61:	movq   $0x0,0x18(%rsp)
 1014b6a:	mov    0x30(%rdi),%r15
 1014b6e:	test   %r15,%r15
 1014b71:	je     1014ba7 <fail+0xf7>
 1014b73:	lea    0x18(%rsp),%r14
 1014b78:	nopl   0x0(%rax,%rax,1)
 1014b80:	mov    0x8(%r15),%rsi
 1014b84:	mov    0x10(%r15),%rdx
 1014b88:	mov    %rbx,%rdi
 1014b8b:	xor    %ecx,%ecx
 1014b8d:	mov    %r14,%r8
 1014b90:	vzeroupper
 1014b93:	call   1014c90 <trace_frame>
 1014b98:	mov    (%r15),%r15
 1014b9b:	test   %r15,%r15
 1014b9e:	jne    1014b80 <fail+0xd0>
 1014ba0:	cmpq   $0x0,0x30(%rbx)
 1014ba5:	jne    1014bb7 <fail+0x107>
 1014ba7:	lea    0x18(%rsp),%rsi
 1014bac:	mov    %rbx,%rdi
 1014baf:	vzeroupper
 1014bb2:	call   1014de0 <walk_frames>
 1014bb7:	mov    0x18(%rsp),%r11
 1014bbc:	xor    %eax,%eax
 1014bbe:	sub    0x248(%rbx),%r11
 1014bc5:	cmovae %r11,%rax
 1014bc9:	mov    %rax,0x250(%rbx)
 1014bd0:	cmpq   $0x0,0x3e60(%rbx)
 1014bd8:	jne    1014c77 <fail+0x1c7>
 1014bde:	vmovups -0x270(%rbp),%ymm0
 1014be6:	vmovups -0x250(%rbp),%ymm1
 1014bee:	vmovups -0x230(%rbp),%ymm2
 1014bf6:	vmovups -0x210(%rbp),%ymm3
 1014bfe:	vmovups -0x1f0(%rbp),%ymm4
 1014c06:	vmovups -0x1d0(%rbp),%ymm5
 1014c0e:	vmovups -0x1b0(%rbp),%ymm6
 1014c16:	vmovups -0x190(%rbp),%ymm7
 1014c1e:	vmovups -0x170(%rbp),%ymm8
 1014c26:	vmovups -0x150(%rbp),%ymm9
 1014c2e:	vmovups -0x130(%rbp),%ymm10
 1014c36:	vmovups -0x110(%rbp),%ymm11
 1014c3e:	vmovups -0xf0(%rbp),%ymm12
 1014c46:	vmovups -0xd0(%rbp),%ymm13
 1014c4e:	vmovups -0xb0(%rbp),%ymm14
 1014c56:	vmovups -0x90(%rbp),%ymm15
 1014c5e:	lea    -0x58(%rbp),%rsp
 1014c62:	pop    %rbx
 1014c63:	pop    %r14
 1014c65:	pop    %r15
 1014c67:	pop    %rax
 1014c68:	pop    %rcx
 1014c69:	pop    %rdx
 1014c6a:	pop    %rsi
 1014c6b:	pop    %rdi
 1014c6c:	pop    %r8
 1014c6e:	pop    %r9
 1014c70:	pop    %r10
 1014c72:	pop    %rbp
 1014c73:	vzeroupper
 1014c76:	ret
 1014c77:	mov    %rbx,%rdi
 1014c7a:	call   1014660 <myl_qbe_rc_trap>
 1014c7f:	mov    0x3e60(%rbx),%rdi
 1014c86:	mov    $0x1,%esi
 1014c8b:	call   1027820 <longjmp@plt>

0000000001014c90 <trace_frame>:
 1014c90:	test   %rsi,%rsi
 1014c93:	je     1014db0 <trace_frame+0x120>
 1014c99:	cmp    0x10(%rsi),%rdx
 1014c9d:	jae    1014db0 <trace_frame+0x120>
 1014ca3:	push   %rbp
 1014ca4:	mov    %rsp,%rbp
 1014ca7:	push   %r15
 1014ca9:	push   %r14
 1014cab:	push   %r12
 1014cad:	push   %rbx
 1014cae:	cmp    $0x1f,%ecx
 1014cb1:	ja     1014cc5 <trace_frame+0x35>
 1014cb3:	mov    0x20(%rsi),%r15
 1014cb7:	test   %r15,%r15
 1014cba:	je     1014cc5 <trace_frame+0x35>
 1014cbc:	mov    0x28(%rsi),%rax
 1014cc0:	test   %rax,%rax
 1014cc3:	jne    1014d29 <trace_frame+0x99>
 1014cc5:	incq   (%r8)
 1014cc8:	cmp    0x10(%rsi),%rdx
 1014ccc:	jae    1014d0f <trace_frame+0x7f>
 1014cce:	mov    0x248(%rdi),%rax
 1014cd5:	cmp    $0xf,%rax
 1014cd9:	ja     1014d0f <trace_frame+0x7f>
 1014cdb:	mov    (%rsi),%rcx
 1014cde:	mov    0x8(%rsi),%rsi
 1014ce2:	lea    (%rdx,%rdx,2),%rdx
 1014ce6:	mov    (%rsi,%rdx,8),%r8
 1014cea:	lea    0x1(%rax),%r9
 1014cee:	shl    $0x5,%rax
 1014cf2:	mov    %rcx,0x48(%rdi,%rax,1)
 1014cf7:	mov    %r8,0x50(%rdi,%rax,1)
 1014cfc:	vmovups 0x8(%rsi,%rdx,8),%xmm0
 1014d02:	mov    %r9,0x248(%rdi)
 1014d09:	vmovups %xmm0,0x58(%rdi,%rax,1)
 1014d0f:	pop    %rbx
 1014d10:	pop    %r12
 1014d12:	pop    %r14
 1014d14:	pop    %r15
 1014d16:	pop    %rbp
 1014d17:	ret
 1014d18:	nopl   0x0(%rax,%rax,1)
 1014d20:	add    $0x28,%r15
 1014d24:	dec    %rax
 1014d27:	je     1014cc5 <trace_frame+0x35>
 1014d29:	mov    0x8(%r15),%r9
 1014d2d:	cmp    %r9,%rdx
 1014d30:	jb     1014d20 <trace_frame+0x90>
 1014d32:	cmp    0x10(%r15),%rdx
 1014d36:	jae    1014d20 <trace_frame+0x90>
 1014d38:	mov    (%r15),%rax
 1014d3b:	test   %rax,%rax
 1014d3e:	je     1014cc5 <trace_frame+0x35>
 1014d40:	add    0x18(%r15),%rdx
 1014d44:	sub    %r9,%rdx
 1014d47:	inc    %ecx
 1014d49:	mov    %rdi,%rbx
 1014d4c:	mov    %rsi,%r12
 1014d4f:	mov    %rax,%rsi
 1014d52:	mov    %r8,%r14
 1014d55:	call   1014c90 <trace_frame>
 1014d5a:	mov    0x20(%r15),%rdx
 1014d5e:	incq   (%r14)
 1014d61:	cmp    0x10(%r12),%rdx
 1014d66:	jae    1014d0f <trace_frame+0x7f>
 1014d68:	mov    0x248(%rbx),%rax
 1014d6f:	cmp    $0xf,%rax
 1014d73:	ja     1014d0f <trace_frame+0x7f>
 1014d75:	mov    (%r12),%rsi
 1014d79:	mov    0x8(%r12),%rcx
 1014d7e:	lea    (%rdx,%rdx,2),%rdx
 1014d82:	mov    (%rcx,%rdx,8),%rdi
 1014d86:	lea    0x1(%rax),%r8
 1014d8a:	shl    $0x5,%rax
 1014d8e:	mov    %rsi,0x48(%rbx,%rax,1)
 1014d93:	mov    %rdi,0x50(%rbx,%rax,1)
 1014d98:	vmovups 0x8(%rcx,%rdx,8),%xmm0
 1014d9e:	mov    %r8,0x248(%rbx)
 1014da5:	vmovups %xmm0,0x58(%rbx,%rax,1)
 1014dab:	jmp    1014d0f <trace_frame+0x7f>
 1014db0:	incq   (%r8)
 1014db3:	ret
 1014db4:	int3
 1014db5:	int3
 1014db6:	int3
 1014db7:	int3
 1014db8:	int3
 1014db9:	int3
 1014dba:	int3
 1014dbb:	int3
 1014dbc:	int3
 1014dbd:	int3
 1014dbe:	int3
 1014dbf:	int3

0000000001014dc0 <trace_visit>:
 1014dc0:	push   %rbp
 1014dc1:	mov    %rsp,%rbp
 1014dc4:	mov    %rcx,%r8
 1014dc7:	xor    %ecx,%ecx
 1014dc9:	call   1014c90 <trace_frame>
 1014dce:	mov    $0x1,%eax
 1014dd3:	pop    %rbp
 1014dd4:	ret
 1014dd5:	int3
 1014dd6:	int3
 1014dd7:	int3
 1014dd8:	int3
 1014dd9:	int3
 1014dda:	int3
 1014ddb:	int3
 1014ddc:	int3
 1014ddd:	int3
 1014dde:	int3
 1014ddf:	int3

0000000001014de0 <walk_frames>:
 1014de0:	push   %rbp
 1014de1:	mov    %rsp,%rbp
 1014de4:	push   %r15
 1014de6:	push   %r14
 1014de8:	push   %r13
 1014dea:	push   %r12
 1014dec:	push   %rbx
 1014ded:	sub    $0x28,%rsp
 1014df1:	mov    %rsi,-0x30(%rbp)
 1014df5:	mov    0x39c0(%rdi),%r15
 1014dfc:	mov    0x3e68(%rdi),%r12
 1014e03:	test   %r15,%r15
 1014e06:	setne  %al
 1014e09:	cmp    %r15,%r12
 1014e0c:	seta   %cl
 1014e0f:	and    %al,%cl
 1014e11:	cmp    $0x1,%cl
 1014e14:	jne    1014f03 <walk_frames+0x123>
 1014e1a:	lea    -0x8555(%rip),%rax        # 100c8cc <__stop_mylang_frame_map>
 1014e21:	mov    %rax,%rcx
 1014e24:	sub    $0x100c374,%rcx
 1014e2b:	cmp    $0x9,%rcx
 1014e2f:	jb     1014f03 <walk_frames+0x123>
 1014e35:	cmpq   $0x0,0x13eeb(%rip)        # 1028d28 <_DYNAMIC+0x1b0>
 1014e3d:	je     1014f03 <walk_frames+0x123>
 1014e43:	cmp    $0x100c374,%rax
 1014e4a:	jbe    1014f03 <walk_frames+0x123>
 1014e50:	mov    %rdi,%r14
 1014e53:	lea    -0x8ae6(%rip),%rax        # 100c374 <__start_mylang_frame_map>
 1014e5a:	testb  $0x20,0x7(%rax)
 1014e5e:	jne    1014ebf <walk_frames+0xdf>
 1014e60:	mov    %rbp,%r13
 1014e63:	add    $0xfffffffffffffff0,%r12
 1014e67:	nopw   0x0(%rax,%rax,1)
 1014e70:	cmp    %r15,%r13
 1014e73:	jb     1014f03 <walk_frames+0x123>
 1014e79:	cmp    %r12,%r13
 1014e7c:	ja     1014f03 <walk_frames+0x123>
 1014e82:	mov    %r13d,%eax
 1014e85:	and    $0x7,%eax
 1014e88:	jne    1014f03 <walk_frames+0x123>
 1014e8a:	mov    0x0(%r13),%rbx
 1014e8e:	mov    0x8(%r13),%rsi
 1014e92:	mov    $0x1014dc0,%edx
 1014e97:	mov    %r14,%rdi
 1014e9a:	mov    -0x30(%rbp),%rcx
 1014e9e:	call   1014f70 <visit_return>
 1014ea3:	cmp    %r13,%rbx
 1014ea6:	mov    %r13,%rcx
 1014ea9:	cmova  %rbx,%rcx
 1014ead:	test   %eax,%eax
 1014eaf:	cmove  %r13,%rcx
 1014eb3:	je     1014f03 <walk_frames+0x123>
 1014eb5:	cmp    %r13,%rbx
 1014eb8:	mov    %rcx,%r13
 1014ebb:	ja     1014e70 <walk_frames+0x90>
 1014ebd:	jmp    1014f03 <walk_frames+0x123>
 1014ebf:	mov    %r14,-0x50(%rbp)
 1014ec3:	movq   $0x1014dc0,-0x48(%rbp)
 1014ecb:	mov    -0x30(%rbp),%rax
 1014ecf:	mov    %rax,-0x40(%rbp)
 1014ed3:	movq   $0x0,-0x38(%rbp)
 1014edb:	cmpq   $0x0,0x13e15(%rip)        # 1028cf8 <_DYNAMIC+0x180>
 1014ee3:	sete   %al
 1014ee6:	cmpq   $0x0,0x13e12(%rip)        # 1028d00 <_DYNAMIC+0x188>
 1014eee:	sete   %cl
 1014ef1:	or     %al,%cl
 1014ef3:	jne    1014f03 <walk_frames+0x123>
 1014ef5:	lea    -0x50(%rbp),%rsi
 1014ef9:	mov    $0x1014f20,%edi
 1014efe:	call   10274f0 <_Unwind_Backtrace>
 1014f03:	add    $0x28,%rsp
 1014f07:	pop    %rbx
 1014f08:	pop    %r12
 1014f0a:	pop    %r13
 1014f0c:	pop    %r14
 1014f0e:	pop    %r15
 1014f10:	pop    %rbp
 1014f11:	ret
 1014f12:	int3
 1014f13:	int3
 1014f14:	int3
 1014f15:	int3
 1014f16:	int3
 1014f17:	int3
 1014f18:	int3
 1014f19:	int3
 1014f1a:	int3
 1014f1b:	int3
 1014f1c:	int3
 1014f1d:	int3
 1014f1e:	int3
 1014f1f:	int3

0000000001014f20 <unwind_step>:
 1014f20:	push   %rbp
 1014f21:	mov    %rsp,%rbp
 1014f24:	push   %r14
 1014f26:	push   %rbx
 1014f27:	mov    %rsi,%rbx
 1014f2a:	mov    (%rsi),%r14
 1014f2d:	call   10242e0 <_Unwind_GetIP>
 1014f32:	mov    0x8(%rbx),%rdx
 1014f36:	mov    0x10(%rbx),%rcx
 1014f3a:	mov    %r14,%rdi
 1014f3d:	mov    %rax,%rsi
 1014f40:	call   1014f70 <visit_return>
 1014f45:	mov    %eax,%ecx
 1014f47:	xor    %eax,%eax
 1014f49:	test   %ecx,%ecx
 1014f4b:	je     1014f52 <unwind_step+0x32>
 1014f4d:	pop    %rbx
 1014f4e:	pop    %r14
 1014f50:	pop    %rbp
 1014f51:	ret
 1014f52:	movl   $0x1,0x18(%rbx)
 1014f59:	mov    $0x5,%eax
 1014f5e:	pop    %rbx
 1014f5f:	pop    %r14
 1014f61:	pop    %rbp
 1014f62:	ret
 1014f63:	int3
 1014f64:	int3
 1014f65:	int3
 1014f66:	int3
 1014f67:	int3
 1014f68:	int3
 1014f69:	int3
 1014f6a:	int3
 1014f6b:	int3
 1014f6c:	int3
 1014f6d:	int3
 1014f6e:	int3
 1014f6f:	int3

0000000001014f70 <visit_return>:
 1014f70:	push   %rbp
 1014f71:	mov    %rsp,%rbp
 1014f74:	push   %r15
 1014f76:	push   %r14
 1014f78:	push   %r13
 1014f7a:	push   %r12
 1014f7c:	push   %rbx
 1014f7d:	sub    $0x18,%rsp
 1014f81:	mov    %rcx,-0x38(%rbp)
 1014f85:	mov    %rdx,%r14
 1014f88:	mov    %rdi,%r15
 1014f8b:	cmpb   $0x0,0x169b6(%rip)        # 102b948 <frame_sites_ready>
 1014f92:	jne    101504d <visit_return+0xdd>
 1014f98:	movb   $0x1,0x169a9(%rip)        # 102b948 <frame_sites_ready>
 1014f9f:	lea    -0x8c32(%rip),%r13        # 100c374 <__start_mylang_frame_map>
 1014fa6:	test   %r13,%r13
 1014fa9:	sete   %al
 1014fac:	lea    -0x86e7(%rip),%r12        # 100c8cc <__stop_mylang_frame_map>
 1014fb3:	cmp    %r13,%r12
 1014fb6:	setbe  %cl
 1014fb9:	or     %al,%cl
 1014fbb:	jne    101504d <visit_return+0xdd>
 1014fc1:	sub    $0x100c374,%r12
 1014fc8:	sar    $0x2,%r12
 1014fcc:	movabs $0xaaaaaaaaaaaaaaab,%rax
 1014fd6:	mov    %r12,%rdx
 1014fd9:	mulx   %rax,%rbx,%rbx
 1014fde:	shr    $1,%rbx
 1014fe1:	movabs $0xf555555555555555,%rax
 1014feb:	lea    (%rbx,%rax,1),%rcx
 1014fef:	inc    %rax
 1014ff2:	cmp    %rax,%rcx
 1014ff5:	jb     101504d <visit_return+0xdd>
 1014ff7:	lea    0x0(,%rbx,8),%rax
 1014fff:	lea    (%rax,%rax,2),%rdi
 1015003:	mov    %rsi,-0x30(%rbp)
 1015007:	call   1027680 <malloc@plt>
 101500c:	mov    -0x30(%rbp),%rsi
 1015010:	mov    %rax,0x16921(%rip)        # 102b938 <frame_sites>
 1015017:	test   %rax,%rax
 101501a:	je     101511b <visit_return+0x1ab>
 1015020:	cmp    $0x3,%r12
 1015024:	jae    10151e7 <visit_return+0x277>
 101502a:	xor    %r12d,%r12d
 101502d:	mov    $0x18,%edx
 1015032:	mov    $0x1015280,%ecx
 1015037:	mov    %rax,%rdi
 101503a:	mov    %r12,%rsi
 101503d:	call   1027830 <qsort@plt>
 1015042:	mov    %r12,0x168f7(%rip)        # 102b940 <frame_site_count>
 1015049:	mov    -0x30(%rbp),%rsi
 101504d:	mov    0x168e4(%rip),%rcx        # 102b938 <frame_sites>
 1015054:	test   %rcx,%rcx
 1015057:	je     101511b <visit_return+0x1ab>
 101505d:	mov    0x168dc(%rip),%rdx        # 102b940 <frame_site_count>
 1015064:	xor    %edi,%edi
 1015066:	test   %rdx,%rdx
 1015069:	je     101509a <visit_return+0x12a>
 101506b:	mov    %rdx,%rax
 101506e:	jmp    1015078 <visit_return+0x108>
 1015070:	mov    %r9,%rax
 1015073:	cmp    %rax,%rdi
 1015076:	jae    101509a <visit_return+0x12a>
 1015078:	mov    %rax,%r8
 101507b:	sub    %rdi,%r8
 101507e:	shr    $1,%r8
 1015081:	lea    (%r8,%rdi,1),%r9
 1015085:	lea    (%r9,%r9,2),%r10
 1015089:	cmp    %rsi,(%rcx,%r10,8)
 101508d:	jae    1015070 <visit_return+0x100>
 101508f:	add    %r8,%rdi
 1015092:	inc    %rdi
 1015095:	cmp    %rax,%rdi
 1015098:	jb     1015078 <visit_return+0x108>
 101509a:	mov    $0x1,%eax
 101509f:	cmp    %rdx,%rdi
 10150a2:	jae    10151d8 <visit_return+0x268>
 10150a8:	lea    (%rdi,%rdi,2),%rdx
 10150ac:	cmp    %rsi,(%rcx,%rdx,8)
 10150b0:	jne    10151d8 <visit_return+0x268>
 10150b6:	lea    (%rcx,%rdx,8),%rcx
 10150ba:	mov    0x10(%rcx),%r12
 10150be:	test   %r12,%r12
 10150c1:	je     10151d8 <visit_return+0x268>
 10150c7:	mov    0x8(%rcx),%r13
 10150cb:	add    $0x8,%r13
 10150cf:	mov    %r13,%rbx
 10150d2:	jmp    10150f1 <visit_return+0x181>
 10150d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10150e0:	add    $0xc,%r13
 10150e4:	add    $0xc,%rbx
 10150e8:	dec    %r12
 10150eb:	je     10151d3 <visit_return+0x263>
 10150f1:	mov    -0x4(%r13),%edx
 10150f5:	test   %edx,%edx
 10150f7:	js     10150e0 <visit_return+0x170>
 10150f9:	movslq 0x0(%r13),%rsi
 10150fd:	add    %rbx,%rsi
 1015100:	and    $0x1fffffff,%edx
 1015106:	mov    %r15,%rdi
 1015109:	mov    -0x38(%rbp),%rcx
 101510d:	call   *%r14
 1015110:	test   %eax,%eax
 1015112:	jne    10150e0 <visit_return+0x170>
 1015114:	xor    %eax,%eax
 1015116:	jmp    10151d8 <visit_return+0x268>
 101511b:	lea    -0x8dae(%rip),%rcx        # 100c374 <__start_mylang_frame_map>
 1015122:	test   %rcx,%rcx
 1015125:	sete   %al
 1015128:	lea    -0x8863(%rip),%rdx        # 100c8cc <__stop_mylang_frame_map>
 101512f:	cmp    %rcx,%rdx
 1015132:	setbe  %dil
 1015136:	or     %al,%dil
 1015139:	mov    $0x1,%eax
 101513e:	jne    10151d8 <visit_return+0x268>
 1015144:	sub    $0x100c374,%rdx
 101514b:	sar    $0x2,%rdx
 101514f:	movabs $0xaaaaaaaaaaaaaaab,%rdi
 1015159:	mulx   %rdi,%rdi,%rdi
 101515e:	cmp    $0x3,%rdx
 1015162:	jb     10151d8 <visit_return+0x268>
 1015164:	shr    $1,%rdi
 1015167:	lea    -0x1(%rdi),%rdx
 101516b:	xor    %r8d,%r8d
 101516e:	xchg   %ax,%ax
 1015170:	lea    0x0(,%r8,4),%r9
 1015178:	lea    (%r9,%r9,2),%r13
 101517c:	mov    $0x1,%r12d
 1015182:	cmp    %rdx,%r8
 1015185:	jae    10151b6 <visit_return+0x246>
 1015187:	mov    %rdi,%r9
 101518a:	sub    %r8,%r9
 101518d:	lea    (%rcx,%r13,1),%r10
 1015191:	add    $0x10,%r10
 1015195:	data16 cs nopw 0x0(%rax,%rax,1)
 10151a0:	testb  $0x40,0x3(%r10)
 10151a5:	je     10151b6 <visit_return+0x246>
 10151a7:	inc    %r12
 10151aa:	add    $0xc,%r10
 10151ae:	cmp    %r12,%r9
 10151b1:	jne    10151a0 <visit_return+0x230>
 10151b3:	mov    %r9,%r12
 10151b6:	add    %rcx,%r13
 10151b9:	movslq 0x0(%r13),%r9
 10151bd:	add    %r13,%r9
 10151c0:	cmp    %rsi,%r9
 10151c3:	je     10150cb <visit_return+0x15b>
 10151c9:	add    %r12,%r8
 10151cc:	cmp    %rdi,%r8
 10151cf:	jb     1015170 <visit_return+0x200>
 10151d1:	jmp    10151d8 <visit_return+0x268>
 10151d3:	mov    $0x1,%eax
 10151d8:	add    $0x18,%rsp
 10151dc:	pop    %rbx
 10151dd:	pop    %r12
 10151df:	pop    %r13
 10151e1:	pop    %r14
 10151e3:	pop    %r15
 10151e5:	pop    %rbp
 10151e6:	ret
 10151e7:	lea    -0x1(%rbx),%rcx
 10151eb:	xor    %r12d,%r12d
 10151ee:	xor    %edx,%edx
 10151f0:	jmp    101522e <visit_return+0x2be>
 10151f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015200:	mov    %r8,%rdi
 1015203:	lea    (%r12,%r12,2),%r8
 1015207:	lea    (%rax,%r8,8),%r8
 101520b:	add    %r13,%rsi
 101520e:	movslq (%rsi),%r9
 1015211:	add    %rsi,%r9
 1015214:	mov    %r9,(%r8)
 1015217:	mov    %rsi,0x8(%r8)
 101521b:	mov    %rdi,0x10(%r8)
 101521f:	add    %rdi,%rdx
 1015222:	inc    %r12
 1015225:	cmp    %rbx,%rdx
 1015228:	jae    101502d <visit_return+0xbd>
 101522e:	lea    0x0(,%rdx,4),%rsi
 1015236:	lea    (%rsi,%rsi,2),%rsi
 101523a:	mov    $0x1,%edi
 101523f:	cmp    %rcx,%rdx
 1015242:	jae    1015203 <visit_return+0x293>
 1015244:	mov    %rbx,%r8
 1015247:	sub    %rdx,%r8
 101524a:	lea    (%rsi,%r13,1),%r9
 101524e:	add    $0x10,%r9
 1015252:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015260:	testb  $0x40,0x3(%r9)
 1015265:	je     1015203 <visit_return+0x293>
 1015267:	inc    %rdi
 101526a:	add    $0xc,%r9
 101526e:	cmp    %rdi,%r8
 1015271:	jne    1015260 <visit_return+0x2f0>
 1015273:	jmp    1015200 <visit_return+0x290>
 1015275:	int3
 1015276:	int3
 1015277:	int3
 1015278:	int3
 1015279:	int3
 101527a:	int3
 101527b:	int3
 101527c:	int3
 101527d:	int3
 101527e:	int3
 101527f:	int3

0000000001015280 <site_order>:
 1015280:	mov    (%rdi),%rax
 1015283:	cmp    (%rsi),%rax
 1015286:	seta   %al
 1015289:	sbb    $0x0,%al
 101528b:	movsbl %al,%eax
 101528e:	ret
 101528f:	int3

0000000001015290 <myl_qbe_fail_allocation>:
 1015290:	push   %rbp
 1015291:	mov    %rsp,%rbp
 1015294:	mov    0x1860(%rdi),%rcx
 101529b:	test   %rcx,%rcx
 101529e:	je     10152cf <myl_qbe_fail_allocation+0x3f>
 10152a0:	mov    0x124(%rcx),%eax
 10152a6:	movl   $0x0,0x124(%rcx)
 10152b0:	test   %rax,%rax
 10152b3:	je     10152cf <myl_qbe_fail_allocation+0x3f>
 10152b5:	cmp    $0x1,%eax
 10152b8:	jne    1015307 <myl_qbe_fail_allocation+0x77>
 10152ba:	mov    $0x1004361,%esi
 10152bf:	cmpl   $0x0,0x2c4(%rdi)
 10152c6:	je     101530c <myl_qbe_fail_allocation+0x7c>
 10152c8:	call   1014ab0 <fail>
 10152cd:	pop    %rbp
 10152ce:	ret
 10152cf:	cmpl   $0x0,%fs:0xfffffffffffffffc
 10152d8:	movl   $0x0,%fs:0xfffffffffffffffc
 10152e4:	mov    $0x1004421,%esi
 10152e9:	jne    10152c8 <myl_qbe_fail_allocation+0x38>
 10152eb:	cmpl   $0x0,0x2c4(%rdi)
 10152f2:	mov    $0x1003b92,%eax
 10152f7:	mov    $0x1004361,%esi
 10152fc:	cmove  %rax,%rsi
 1015300:	call   1014ab0 <fail>
 1015305:	pop    %rbp
 1015306:	ret
 1015307:	cmp    $0x4,%eax
 101530a:	jae    101531b <myl_qbe_fail_allocation+0x8b>
 101530c:	mov    0x100b5d0(,%rax,8),%rsi
 1015314:	call   1014ab0 <fail>
 1015319:	pop    %rbp
 101531a:	ret
 101531b:	call   1027810 <abort@plt>

0000000001015320 <myl_qbe_fail_iteration>:
 1015320:	push   %rbp
 1015321:	mov    %rsp,%rbp
 1015324:	mov    $0x10043af,%esi
 1015329:	call   1014ab0 <fail>
 101532e:	pop    %rbp
 101532f:	ret

0000000001015330 <myl_qbe_fail_normalized_index_bounds>:
 1015330:	cmpq   $0x0,0x20(%rdi)
 1015335:	jne    1015385 <myl_qbe_fail_normalized_index_bounds+0x55>
 1015337:	mov    %rsi,%rax
 101533a:	sar    $0x3f,%rax
 101533e:	and    %rdx,%rax
 1015341:	sub    %rax,%rsi
 1015344:	movabs $0x300000001,%rax
 101534e:	mov    %rax,0x39e8(%rdi)
 1015355:	mov    %rsi,0x39f0(%rdi)
 101535c:	mov    %rdx,0x39f8(%rdi)
 1015363:	vxorps %xmm0,%xmm0,%xmm0
 1015367:	vmovups %xmm0,0x3a00(%rdi)
 101536f:	movq   $0x0,0x3a10(%rdi)
 101537a:	movq   $0x1003c12,0x3a18(%rdi)
 1015385:	push   %rbp
 1015386:	mov    %rsp,%rbp
 1015389:	mov    $0x1004395,%esi
 101538e:	call   1014ab0 <fail>
 1015393:	pop    %rbp
 1015394:	ret
 1015395:	int3
 1015396:	int3
 1015397:	int3
 1015398:	int3
 1015399:	int3
 101539a:	int3
 101539b:	int3
 101539c:	int3
 101539d:	int3
 101539e:	int3
 101539f:	int3

00000000010153a0 <myl_qbe_fail_overflow_op>:
 10153a0:	cmpq   $0x0,0x20(%rdi)
 10153a5:	jne    10153ec <myl_qbe_fail_overflow_op+0x4c>
 10153a7:	mov    0x100bb28(,%rsi,8),%rax
 10153af:	movabs $0x1c00000001,%rsi
 10153b9:	mov    %rsi,0x39e8(%rdi)
 10153c0:	vxorps %xmm0,%xmm0,%xmm0
 10153c4:	vmovups %xmm0,0x39f0(%rdi)
 10153cc:	mov    %rdx,0x3a00(%rdi)
 10153d3:	mov    %rcx,0x3a08(%rdi)
 10153da:	movq   $0x40,0x3a10(%rdi)
 10153e5:	mov    %rax,0x3a18(%rdi)
 10153ec:	push   %rbp
 10153ed:	mov    %rsp,%rbp
 10153f0:	mov    $0x10042c9,%esi
 10153f5:	call   1014ab0 <fail>
 10153fa:	pop    %rbp
 10153fb:	ret
 10153fc:	int3
 10153fd:	int3
 10153fe:	int3
 10153ff:	int3

0000000001015400 <myl_qbe_fail_cast>:
 1015400:	cmpq   $0x0,0x20(%rdi)
 1015405:	jne    101544c <myl_qbe_fail_cast+0x4c>
 1015407:	movabs $0x3400000001,%rax
 1015411:	mov    %rax,0x39e8(%rdi)
 1015418:	vxorps %xmm0,%xmm0,%xmm0
 101541c:	vmovups %xmm0,0x39f0(%rdi)
 1015424:	mov    %rsi,0x3a00(%rdi)
 101542b:	movq   $0x0,0x3a08(%rdi)
 1015436:	movq   $0x40,0x3a10(%rdi)
 1015441:	movq   $0x1003cd3,0x3a18(%rdi)
 101544c:	push   %rbp
 101544d:	mov    %rsp,%rbp
 1015450:	mov    $0x10042c9,%esi
 1015455:	call   1014ab0 <fail>
 101545a:	pop    %rbp
 101545b:	ret
 101545c:	int3
 101545d:	int3
 101545e:	int3
 101545f:	int3

0000000001015460 <myl_qbe_fail_frame>:
 1015460:	push   %rbp
 1015461:	mov    %rsp,%rbp
 1015464:	mov    $0x1004353,%esi
 1015469:	call   1014ab0 <fail>
 101546e:	pop    %rbp
 101546f:	ret

0000000001015470 <on_timeout>:
 1015470:	push   %rbp
 1015471:	mov    %rsp,%rbp
 1015474:	mov    $0x100b2e0,%esi
 1015479:	mov    $0x48,%edx
 101547e:	mov    $0x2,%edi
 1015483:	call   1027840 <write@plt>
 1015488:	mov    $0x1,%edi
 101548d:	call   1027850 <_exit@plt>
 1015492:	int3
 1015493:	int3
 1015494:	int3
 1015495:	int3
 1015496:	int3
 1015497:	int3
 1015498:	int3
 1015499:	int3
 101549a:	int3
 101549b:	int3
 101549c:	int3
 101549d:	int3
 101549e:	int3
 101549f:	int3

00000000010154a0 <append>:
 10154a0:	push   %rbp
 10154a1:	mov    %rsp,%rbp
 10154a4:	push   %r14
 10154a6:	push   %rbx
 10154a7:	sub    $0xd0,%rsp
 10154ae:	mov    %rdx,%rbx
 10154b1:	mov    %rsi,%r14
 10154b4:	mov    %r8,-0xc0(%rbp)
 10154bb:	mov    %r9,-0xb8(%rbp)
 10154c2:	test   %al,%al
 10154c4:	je     10154f7 <append+0x57>
 10154c6:	vmovaps %xmm0,-0xb0(%rbp)
 10154ce:	vmovaps %xmm1,-0xa0(%rbp)
 10154d6:	vmovaps %xmm2,-0x90(%rbp)
 10154de:	vmovaps %xmm3,-0x80(%rbp)
 10154e3:	vmovaps %xmm4,-0x70(%rbp)
 10154e8:	vmovaps %xmm5,-0x60(%rbp)
 10154ed:	vmovaps %xmm6,-0x50(%rbp)
 10154f2:	vmovaps %xmm7,-0x40(%rbp)
 10154f7:	lea    -0xe0(%rbp),%rax
 10154fe:	mov    %rax,-0x20(%rbp)
 1015502:	lea    0x10(%rbp),%rax
 1015506:	mov    %rax,-0x28(%rbp)
 101550a:	movabs $0x3000000020,%rax
 1015514:	mov    %rax,-0x30(%rbp)
 1015518:	mov    (%rdx),%rax
 101551b:	add    %rax,%rdi
 101551e:	sub    %rax,%rsi
 1015521:	lea    -0x30(%rbp),%rax
 1015525:	mov    %rcx,%rdx
 1015528:	mov    %rax,%rcx
 101552b:	call   1027860 <vsnprintf@plt>
 1015530:	mov    %eax,%ecx
 1015532:	xor    %eax,%eax
 1015534:	test   %ecx,%ecx
 1015536:	js     1015550 <append+0xb0>
 1015538:	mov    %ecx,%ecx
 101553a:	mov    (%rbx),%rdx
 101553d:	sub    %rdx,%r14
 1015540:	cmp    %rcx,%r14
 1015543:	jbe    1015550 <append+0xb0>
 1015545:	add    %rcx,%rdx
 1015548:	mov    %rdx,(%rbx)
 101554b:	mov    $0x1,%eax
 1015550:	add    $0xd0,%rsp
 1015557:	pop    %rbx
 1015558:	pop    %r14
 101555a:	pop    %rbp
 101555b:	ret
 101555c:	int3
 101555d:	int3
 101555e:	int3
 101555f:	int3

0000000001015560 <describe>:
 1015560:	push   %rbp
 1015561:	mov    %rsp,%rbp
 1015564:	push   %rbx
 1015565:	push   %rax
 1015566:	mov    %rdi,%rbx
 1015569:	mov    $0x1004361,%esi
 101556e:	call   10276c0 <strcmp@plt>
 1015573:	test   %eax,%eax
 1015575:	je     1015620 <describe+0xc0>
 101557b:	mov    $0x1004346,%esi
 1015580:	mov    %rbx,%rdi
 1015583:	call   10276c0 <strcmp@plt>
 1015588:	test   %eax,%eax
 101558a:	je     101562c <describe+0xcc>
 1015590:	mov    $0x100442d,%esi
 1015595:	mov    %rbx,%rdi
 1015598:	call   10276c0 <strcmp@plt>
 101559d:	test   %eax,%eax
 101559f:	je     1015638 <describe+0xd8>
 10155a5:	mov    $0x1004442,%esi
 10155aa:	mov    %rbx,%rdi
 10155ad:	call   10276c0 <strcmp@plt>
 10155b2:	test   %eax,%eax
 10155b4:	je     1015644 <describe+0xe4>
 10155ba:	mov    $0x1004353,%esi
 10155bf:	mov    %rbx,%rdi
 10155c2:	call   10276c0 <strcmp@plt>
 10155c7:	test   %eax,%eax
 10155c9:	je     1015650 <describe+0xf0>
 10155cf:	mov    $0x100438a,%esi
 10155d4:	mov    %rbx,%rdi
 10155d7:	call   10276c0 <strcmp@plt>
 10155dc:	test   %eax,%eax
 10155de:	je     101565c <describe+0xfc>
 10155e0:	mov    $0x1004380,%esi
 10155e5:	mov    %rbx,%rdi
 10155e8:	call   10276c0 <strcmp@plt>
 10155ed:	test   %eax,%eax
 10155ef:	je     1015668 <describe+0x108>
 10155f1:	mov    $0x100430e,%esi
 10155f6:	mov    %rbx,%rdi
 10155f9:	call   10276c0 <strcmp@plt>
 10155fe:	test   %eax,%eax
 1015600:	je     1015674 <describe+0x114>
 1015602:	mov    $0x10040ce,%eax
 1015607:	cmpb   $0x52,(%rbx)
 101560a:	jne    1015625 <describe+0xc5>
 101560c:	cmpb   $0x5f,0x1(%rbx)
 1015610:	mov    $0x100429a,%ecx
 1015615:	cmove  %rcx,%rax
 1015619:	add    $0x8,%rsp
 101561d:	pop    %rbx
 101561e:	pop    %rbp
 101561f:	ret
 1015620:	mov    $0x1004135,%eax
 1015625:	add    $0x8,%rsp
 1015629:	pop    %rbx
 101562a:	pop    %rbp
 101562b:	ret
 101562c:	mov    $0x10043dc,%eax
 1015631:	add    $0x8,%rsp
 1015635:	pop    %rbx
 1015636:	pop    %rbp
 1015637:	ret
 1015638:	mov    $0x1003ff4,%eax
 101563d:	add    $0x8,%rsp
 1015641:	pop    %rbx
 1015642:	pop    %rbp
 1015643:	ret
 1015644:	mov    $0x1004023,%eax
 1015649:	add    $0x8,%rsp
 101564d:	pop    %rbx
 101564e:	pop    %rbp
 101564f:	ret
 1015650:	mov    $0x100467d,%eax
 1015655:	add    $0x8,%rsp
 1015659:	pop    %rbx
 101565a:	pop    %rbp
 101565b:	ret
 101565c:	mov    $0x100425c,%eax
 1015661:	add    $0x8,%rsp
 1015665:	pop    %rbx
 1015666:	pop    %rbp
 1015667:	ret
 1015668:	mov    $0x1004245,%eax
 101566d:	add    $0x8,%rsp
 1015671:	pop    %rbx
 1015672:	pop    %rbp
 1015673:	ret
 1015674:	mov    $0x1004232,%eax
 1015679:	add    $0x8,%rsp
 101567d:	pop    %rbx
 101567e:	pop    %rbp
 101567f:	ret

0000000001015680 <myl_native_heap_collect>:
 1015680:	push   %rbp
 1015681:	mov    %rsp,%rbp
 1015684:	test   %rdi,%rdi
 1015687:	je     1015699 <myl_native_heap_collect+0x19>
 1015689:	cmpq   $0x0,0x1608(%rdi)
 1015691:	je     101569b <myl_native_heap_collect+0x1b>
 1015693:	pop    %rbp
 1015694:	jmp    101be30 <myl_rc_drain>
 1015699:	xor    %edi,%edi
 101569b:	pop    %rbp
 101569c:	jmp    10156b0 <collect>
 10156a1:	int3
 10156a2:	int3
 10156a3:	int3
 10156a4:	int3
 10156a5:	int3
 10156a6:	int3
 10156a7:	int3
 10156a8:	int3
 10156a9:	int3
 10156aa:	int3
 10156ab:	int3
 10156ac:	int3
 10156ad:	int3
 10156ae:	int3
 10156af:	int3

00000000010156b0 <collect>:
 10156b0:	push   %rbp
 10156b1:	mov    %rsp,%rbp
 10156b4:	push   %r15
 10156b6:	push   %r14
 10156b8:	push   %r13
 10156ba:	push   %r12
 10156bc:	push   %rbx
 10156bd:	and    $0xffffffffffffffe0,%rsp
 10156c1:	sub    $0x140,%rsp
 10156c8:	cmpl   $0x0,0x74(%rdi)
 10156cc:	jne    1016c1e <collect+0x156e>
 10156d2:	mov    %rdi,%r15
 10156d5:	incq   0x50(%rdi)
 10156d9:	movq   $0x0,0x4e8(%rdi)
 10156e4:	movl   $0x0,0x4f8(%rdi)
 10156ee:	vpxor  %xmm0,%xmm0,%xmm0
 10156f2:	vmovdqu %ymm0,0x500(%rdi)
 10156fa:	vmovdqu %ymm0,0x520(%rdi)
 1015702:	vmovdqu %ymm0,0x540(%rdi)
 101570a:	vmovdqu %ymm0,0x560(%rdi)
 1015712:	vmovdqu %ymm0,0x580(%rdi)
 101571a:	vmovdqu %ymm0,0x5a0(%rdi)
 1015722:	vmovdqu %ymm0,0x5e0(%rdi)
 101572a:	movq   $0x0,0x600(%rdi)
 1015735:	vmovdqu %ymm0,0x618(%rdi)
 101573d:	movq   $0x0,0x638(%rdi)
 1015748:	vmovdqu %ymm0,0x650(%rdi)
 1015750:	movq   $0x0,0x670(%rdi)
 101575b:	vmovdqu %ymm0,0x688(%rdi)
 1015763:	movq   $0x0,0x6a8(%rdi)
 101576e:	vmovdqu %ymm0,0x6c0(%rdi)
 1015776:	movq   $0x0,0x6e0(%rdi)
 1015781:	vmovdqu %ymm0,0x6f8(%rdi)
 1015789:	movq   $0x0,0x718(%rdi)
 1015794:	vmovdqu %ymm0,0x730(%rdi)
 101579c:	movq   $0x0,0x750(%rdi)
 10157a7:	vmovdqu %ymm0,0x768(%rdi)
 10157af:	movq   $0x0,0x788(%rdi)
 10157ba:	vmovdqu %ymm0,0x7a0(%rdi)
 10157c2:	movq   $0x0,0x7c0(%rdi)
 10157cd:	vmovdqu %ymm0,0x7d8(%rdi)
 10157d5:	movq   $0x0,0x7f8(%rdi)
 10157e0:	vmovdqu %ymm0,0x810(%rdi)
 10157e8:	movq   $0x0,0x830(%rdi)
 10157f3:	vmovdqu %ymm0,0x848(%rdi)
 10157fb:	movq   $0x0,0x868(%rdi)
 1015806:	vmovdqu %ymm0,0x880(%rdi)
 101580e:	movq   $0x0,0x8a0(%rdi)
 1015819:	vmovdqu %ymm0,0x8b8(%rdi)
 1015821:	movq   $0x0,0x8d8(%rdi)
 101582c:	vmovdqu %ymm0,0x8f0(%rdi)
 1015834:	movq   $0x0,0x910(%rdi)
 101583f:	vmovdqu %ymm0,0x928(%rdi)
 1015847:	movq   $0x0,0x948(%rdi)
 1015852:	vmovdqu %ymm0,0x960(%rdi)
 101585a:	movq   $0x0,0x980(%rdi)
 1015865:	vmovdqu %ymm0,0x998(%rdi)
 101586d:	movq   $0x0,0x9b8(%rdi)
 1015878:	vmovdqu %ymm0,0x9d0(%rdi)
 1015880:	movq   $0x0,0x9f0(%rdi)
 101588b:	vmovdqu %ymm0,0xa08(%rdi)
 1015893:	movq   $0x0,0xa28(%rdi)
 101589e:	vmovdqu %ymm0,0xa40(%rdi)
 10158a6:	movq   $0x0,0xa60(%rdi)
 10158b1:	vmovdqu %ymm0,0xa78(%rdi)
 10158b9:	movq   $0x0,0xa98(%rdi)
 10158c4:	vmovdqu %ymm0,0xab0(%rdi)
 10158cc:	movq   $0x0,0xad0(%rdi)
 10158d7:	vmovdqu %ymm0,0xae8(%rdi)
 10158df:	movq   $0x0,0xb08(%rdi)
 10158ea:	vmovdqu %ymm0,0xb20(%rdi)
 10158f2:	movq   $0x0,0xb40(%rdi)
 10158fd:	vmovdqu %ymm0,0xb58(%rdi)
 1015905:	movq   $0x0,0xb78(%rdi)
 1015910:	vmovdqu %ymm0,0xb90(%rdi)
 1015918:	movq   $0x0,0xbb0(%rdi)
 1015923:	vmovdqu %ymm0,0xbc8(%rdi)
 101592b:	movq   $0x0,0xbe8(%rdi)
 1015936:	vmovdqu %ymm0,0xc00(%rdi)
 101593e:	movq   $0x0,0xc20(%rdi)
 1015949:	vmovdqu %ymm0,0xc38(%rdi)
 1015951:	movq   $0x0,0xc58(%rdi)
 101595c:	vmovdqu %ymm0,0xc70(%rdi)
 1015964:	movq   $0x0,0xc90(%rdi)
 101596f:	vmovdqu %ymm0,0xca8(%rdi)
 1015977:	movq   $0x0,0xcc8(%rdi)
 1015982:	vmovdqu %ymm0,0xce0(%rdi)
 101598a:	movq   $0x0,0xd00(%rdi)
 1015995:	vmovdqu %ymm0,0xd18(%rdi)
 101599d:	movq   $0x0,0xd38(%rdi)
 10159a8:	vmovdqu %ymm0,0xd50(%rdi)
 10159b0:	movq   $0x0,0xd70(%rdi)
 10159bb:	vmovdqu %ymm0,0xd88(%rdi)
 10159c3:	movq   $0x0,0xda8(%rdi)
 10159ce:	vmovdqu %ymm0,0xdc0(%rdi)
 10159d6:	movq   $0x0,0xde0(%rdi)
 10159e1:	vmovdqu %ymm0,0xdf8(%rdi)
 10159e9:	movq   $0x0,0xe18(%rdi)
 10159f4:	vmovdqu %ymm0,0xe30(%rdi)
 10159fc:	movq   $0x0,0xe50(%rdi)
 1015a07:	vmovdqu %ymm0,0xe68(%rdi)
 1015a0f:	movq   $0x0,0xe88(%rdi)
 1015a1a:	vmovdqu %ymm0,0xea0(%rdi)
 1015a22:	movq   $0x0,0xec0(%rdi)
 1015a2d:	vmovdqu %ymm0,0xed8(%rdi)
 1015a35:	movq   $0x0,0xef8(%rdi)
 1015a40:	vmovdqu %ymm0,0xf10(%rdi)
 1015a48:	movq   $0x0,0xf30(%rdi)
 1015a53:	vmovdqu %ymm0,0xf48(%rdi)
 1015a5b:	movq   $0x0,0xf68(%rdi)
 1015a66:	vmovdqu %ymm0,0xf80(%rdi)
 1015a6e:	movq   $0x0,0xfa0(%rdi)
 1015a79:	vmovdqu %ymm0,0xfb8(%rdi)
 1015a81:	movq   $0x0,0xfd8(%rdi)
 1015a8c:	vmovdqu %ymm0,0xff0(%rdi)
 1015a94:	movq   $0x0,0x1010(%rdi)
 1015a9f:	vmovdqu %ymm0,0x1028(%rdi)
 1015aa7:	movq   $0x0,0x1048(%rdi)
 1015ab2:	vmovdqu %ymm0,0x1060(%rdi)
 1015aba:	movq   $0x0,0x1080(%rdi)
 1015ac5:	vmovdqu %ymm0,0x1098(%rdi)
 1015acd:	movq   $0x0,0x10b8(%rdi)
 1015ad8:	vmovdqu %ymm0,0x10d0(%rdi)
 1015ae0:	movq   $0x0,0x10f0(%rdi)
 1015aeb:	vmovdqu %ymm0,0x1108(%rdi)
 1015af3:	movq   $0x0,0x1128(%rdi)
 1015afe:	mov    (%rdi),%r14
 1015b01:	test   %r14,%r14
 1015b04:	jne    1015b2f <collect+0x47f>
 1015b06:	jmp    1015bb7 <collect+0x507>
 1015b0b:	nopl   0x0(%rax,%rax,1)
 1015b10:	lea    0x48(%r14),%rdi
 1015b14:	mov    $0x400,%edx
 1015b19:	xor    %esi,%esi
 1015b1b:	vzeroupper
 1015b1e:	call   1027650 <memset@plt>
 1015b23:	mov    (%r14),%r14
 1015b26:	test   %r14,%r14
 1015b29:	je     1015bb7 <collect+0x507>
 1015b2f:	cmpq   $0x20,0x20(%r14)
 1015b34:	jb     1015b10 <collect+0x460>
 1015b36:	mov    0x18(%r14),%rdx
 1015b3a:	test   %rdx,%rdx
 1015b3d:	je     1015bab <collect+0x4fb>
 1015b3f:	mov    0x8(%r14),%rax
 1015b43:	mov    %edx,%ecx
 1015b45:	and    $0x3,%ecx
 1015b48:	cmp    $0x4,%rdx
 1015b4c:	jae    1015b52 <collect+0x4a2>
 1015b4e:	xor    %esi,%esi
 1015b50:	jmp    1015b91 <collect+0x4e1>
 1015b52:	lea    0x470(%r14),%rdi
 1015b59:	and    $0xfffffffffffffffc,%rdx
 1015b5d:	lea    (%rax,%rax,2),%r8
 1015b61:	lea    0x0(,%rax,4),%r9
 1015b69:	xor    %esi,%esi
 1015b6b:	nopl   0x0(%rax,%rax,1)
 1015b70:	andb   $0xfe,(%rdi)
 1015b73:	andb   $0xfe,(%rdi,%rax,1)
 1015b77:	andb   $0xfe,(%rdi,%rax,2)
 1015b7b:	andb   $0xfe,(%rdi,%r8,1)
 1015b80:	add    $0x4,%rsi
 1015b84:	add    %r9,%rdi
 1015b87:	cmp    %rsi,%rdx
 1015b8a:	jne    1015b70 <collect+0x4c0>
 1015b8c:	test   %rcx,%rcx
 1015b8f:	je     1015bab <collect+0x4fb>
 1015b91:	imul   %rax,%rsi
 1015b95:	lea    (%r14,%rsi,1),%rdx
 1015b99:	add    $0x470,%rdx
 1015ba0:	andb   $0xfe,(%rdx)
 1015ba3:	add    %rax,%rdx
 1015ba6:	dec    %rcx
 1015ba9:	jne    1015ba0 <collect+0x4f0>
 1015bab:	mov    (%r14),%r14
 1015bae:	test   %r14,%r14
 1015bb1:	jne    1015b2f <collect+0x47f>
 1015bb7:	movq   $0x0,0x1158(%r15)
 1015bc2:	movq   $0x0,0x1140(%r15)
 1015bcd:	movl   $0x0,0x1170(%r15)
 1015bd8:	incq   0x1180(%r15)
 1015bdf:	movb   $0x0,0x1174(%r15)
 1015be7:	mov    0x10(%r15),%rbx
 1015beb:	test   %rbx,%rbx
 1015bee:	je     1015c0b <collect+0x55b>
 1015bf0:	mov    0x8(%rbx),%rdx
 1015bf4:	mov    0x10(%rbx),%rsi
 1015bf8:	mov    %r15,%rdi
 1015bfb:	vzeroupper
 1015bfe:	call   1016c60 <trace>
 1015c03:	mov    (%rbx),%rbx
 1015c06:	test   %rbx,%rbx
 1015c09:	jne    1015bf0 <collect+0x540>
 1015c0b:	lea    0x5d8(%r15),%rax
 1015c12:	mov    %rax,0x80(%rsp)
 1015c1a:	mov    $0x1a,%ebx
 1015c1f:	jmp    1015c3c <collect+0x58c>
 1015c21:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015c30:	inc    %rbx
 1015c33:	cmp    $0x9a,%rbx
 1015c3a:	je     1015c52 <collect+0x5a2>
 1015c3c:	mov    (%r15,%rbx,8),%rsi
 1015c40:	test   %rsi,%rsi
 1015c43:	je     1015c30 <collect+0x580>
 1015c45:	mov    %r15,%rdi
 1015c48:	vzeroupper
 1015c4b:	call   1016eb0 <mark>
 1015c50:	jmp    1015c30 <collect+0x580>
 1015c52:	cmpq   $0x0,(%r15)
 1015c56:	mov    %r15,0x10(%rsp)
 1015c5b:	je     1015de0 <collect+0x730>
 1015c61:	mov    0x11a0(%r15),%rax
 1015c68:	test   %rax,%rax
 1015c6b:	je     1015c97 <collect+0x5e7>
 1015c6d:	mov    0x5c0(%r15),%rcx
 1015c74:	sub    %rax,%rcx
 1015c77:	add    $0xffffffffffffffb0,%rcx
 1015c7b:	mov    %rcx,0x10(%rax)
 1015c7f:	movq   $0x0,0x11a0(%r15)
 1015c8a:	vpxor  %xmm0,%xmm0,%xmm0
 1015c8e:	vmovdqu %xmm0,0x5c0(%r15)
 1015c97:	mov    0x11e8(%r15),%rax
 1015c9e:	test   %rax,%rax
 1015ca1:	je     1015de0 <collect+0x730>
 1015ca7:	xor    %edx,%edx
 1015ca9:	mov    $0x28,%esi
 1015cae:	jmp    1015cd5 <collect+0x625>
 1015cb0:	mov    0x10(%rsp),%rax
 1015cb5:	mov    0x11e8(%rax),%rax
 1015cbc:	mov    0xa0(%rsp),%rdx
 1015cc4:	inc    %rdx
 1015cc7:	cmp    %rax,%rdx
 1015cca:	mov    0x10(%rsp),%r15
 1015ccf:	jae    1015de0 <collect+0x730>
 1015cd5:	mov    0x4d8(%r15),%rcx
 1015cdc:	mov    %rdx,0xa0(%rsp)
 1015ce4:	mov    (%rcx,%rdx,8),%rdi
 1015ce8:	test   %rdi,%rdi
 1015ceb:	jne    1015cf8 <collect+0x648>
 1015ced:	jmp    1015cbc <collect+0x60c>
 1015cef:	nop
 1015cf0:	mov    (%rdi),%rdi
 1015cf3:	test   %rdi,%rdi
 1015cf6:	je     1015cb0 <collect+0x600>
 1015cf8:	mov    0x10(%rdi),%rax
 1015cfc:	test   %rax,%rax
 1015cff:	je     1015cf0 <collect+0x640>
 1015d01:	lea    0x50(%rdi),%r8
 1015d05:	xor    %r12d,%r12d
 1015d08:	mov    %rdi,0x40(%rsp)
 1015d0d:	mov    %r8,0x60(%rsp)
 1015d12:	jmp    1015d30 <collect+0x680>
 1015d14:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015d20:	add    %r9,%r12
 1015d23:	add    $0x1f,%r12
 1015d27:	and    $0xfffffffffffffff0,%r12
 1015d2b:	cmp    %rax,%r12
 1015d2e:	jae    1015cf0 <collect+0x640>
 1015d30:	mov    0x8(%r8,%r12,1),%r14
 1015d35:	bzhi   %rsi,(%r8,%r12,1),%r13
 1015d3b:	shr    $0x2,%r13
 1015d3f:	mov    (%r14),%r9
 1015d42:	imul   %r13,%r9
 1015d46:	cmp    $0x1,%r9
 1015d4a:	adc    $0x0,%r9
 1015d4e:	cmpw   $0x0,0x30(%r14)
 1015d54:	je     1015d20 <collect+0x670>
 1015d56:	cmpl   $0x1,0x58(%r14)
 1015d5b:	setne  %cl
 1015d5e:	test   %r13,%r13
 1015d61:	setne  %dl
 1015d64:	and    %cl,%dl
 1015d66:	cmp    $0x1,%dl
 1015d69:	jne    1015d20 <collect+0x670>
 1015d6b:	mov    %r9,0x18(%rsp)
 1015d70:	lea    (%r8,%r12,1),%rax
 1015d74:	add    $0x10,%rax
 1015d78:	mov    %rax,0x20(%rsp)
 1015d7d:	xor    %ebx,%ebx
 1015d7f:	mov    0x10(%rsp),%r15
 1015d84:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015d90:	mov    (%r14),%rdx
 1015d93:	imul   %rbx,%rdx
 1015d97:	add    0x20(%rsp),%rdx
 1015d9c:	mov    %r15,%rdi
 1015d9f:	mov    %r14,%rsi
 1015da2:	vzeroupper
 1015da5:	call   1016c60 <trace>
 1015daa:	inc    %rbx
 1015dad:	cmp    %rbx,%r13
 1015db0:	jne    1015d90 <collect+0x6e0>
 1015db2:	mov    0x40(%rsp),%rdi
 1015db7:	mov    0x10(%rdi),%rax
 1015dbb:	mov    $0x28,%esi
 1015dc0:	mov    0x60(%rsp),%r8
 1015dc5:	mov    0x18(%rsp),%r9
 1015dca:	jmp    1015d20 <collect+0x670>
 1015dcf:	movl   $0x1,0x1170(%r15)
 1015dda:	nopw   0x0(%rax,%rax,1)
 1015de0:	mov    0x4e8(%r15),%rax
 1015de7:	test   %rax,%rax
 1015dea:	je     1016202 <collect+0xb52>
 1015df0:	mov    0x8(%r15),%rcx
 1015df4:	lea    -0x1(%rax),%rdx
 1015df8:	mov    %rdx,0x4e8(%r15)
 1015dff:	mov    -0x8(%rcx,%rax,8),%rax
 1015e04:	movb   $0x0,0x1175(%r15)
 1015e0c:	mov    %rax,0x20(%rsp)
 1015e11:	mov    0x8(%rax),%r13
 1015e15:	movzwl 0x30(%r13),%eax
 1015e1a:	test   %eax,%eax
 1015e1c:	je     1015e80 <collect+0x7d0>
 1015e1e:	cmpl   $0x1,0x58(%r13)
 1015e23:	je     1015e80 <collect+0x7d0>
 1015e25:	mov    0x20(%rsp),%rdx
 1015e2a:	lea    0x10(%rdx),%r12
 1015e2e:	mov    $0x3c,%ecx
 1015e33:	bzhi   %rcx,(%rdx),%r14
 1015e38:	shr    $0x2,%r14
 1015e3c:	cmp    $0x6,%eax
 1015e3f:	ja     1015f3d <collect+0x88d>
 1015e45:	mov    $0x62,%ecx
 1015e4a:	bt     %eax,%ecx
 1015e4d:	jae    1015f3d <collect+0x88d>
 1015e53:	test   %r14,%r14
 1015e56:	mov    0x10(%rsp),%r15
 1015e5b:	je     1015e80 <collect+0x7d0>
 1015e5d:	nopl   (%rax)
 1015e60:	mov    (%r12),%rsi
 1015e64:	mov    %r15,%rdi
 1015e67:	vzeroupper
 1015e6a:	call   1016eb0 <mark>
 1015e6f:	add    0x0(%r13),%r12
 1015e73:	dec    %r14
 1015e76:	jne    1015e60 <collect+0x7b0>
 1015e78:	nopl   0x0(%rax,%rax,1)
 1015e80:	mov    0x20(%rsp),%r14
 1015e85:	mov    (%r14),%rax
 1015e88:	test   $0x1,%al
 1015e8a:	je     1015de0 <collect+0x730>
 1015e90:	mov    0x8(%r14),%rcx
 1015e94:	cmpw   $0x0,0x30(%rcx)
 1015e99:	je     1015de0 <collect+0x730>
 1015e9f:	cmpl   $0x1,0x58(%rcx)
 1015ea3:	je     1015de0 <collect+0x730>
 1015ea9:	cmpl   $0x0,0x5c(%rcx)
 1015ead:	je     1015fff <collect+0x94f>
 1015eb3:	cmpb   $0x0,0x1175(%r15)
 1015ebb:	je     1015de0 <collect+0x730>
 1015ec1:	mov    0x1158(%r15),%rcx
 1015ec8:	cmp    0x1160(%r15),%rcx
 1015ecf:	jne    101603d <collect+0x98d>
 1015ed5:	lea    (%rcx,%rcx,1),%rbx
 1015ed9:	test   %rcx,%rcx
 1015edc:	mov    $0x100,%eax
 1015ee1:	cmove  %rax,%rbx
 1015ee5:	cmp    %rcx,%rbx
 1015ee8:	setbe  %al
 1015eeb:	movabs $0x1fffffffffffffff,%rcx
 1015ef5:	cmp    %rcx,%rbx
 1015ef8:	seta   %cl
 1015efb:	or     %al,%cl
 1015efd:	jne    1015dcf <collect+0x71f>
 1015f03:	mov    0x1150(%r15),%rdi
 1015f0a:	lea    0x0(,%rbx,8),%rsi
 1015f12:	vzeroupper
 1015f15:	call   10277f0 <realloc@plt>
 1015f1a:	test   %rax,%rax
 1015f1d:	je     1015dcf <collect+0x71f>
 1015f23:	mov    %rax,0x1150(%r15)
 1015f2a:	mov    %rbx,0x1160(%r15)
 1015f31:	mov    0x1158(%r15),%rcx
 1015f38:	jmp    1016044 <collect+0x994>
 1015f3d:	mov    0x60(%r13),%rax
 1015f41:	mov    %rax,0x18(%rsp)
 1015f46:	test   %rax,%rax
 1015f49:	je     1016058 <collect+0x9a8>
 1015f4f:	mov    0x10(%rsp),%rax
 1015f54:	cmpl   $0x0,0x68(%rax)
 1015f58:	je     1016096 <collect+0x9e6>
 1015f5e:	lea    0xc0(%rsp),%rax
 1015f66:	mov    %rax,0x88(%rsp)
 1015f6e:	movq   $0x8,0x90(%rsp)
 1015f7a:	movq   $0x0,0x98(%rsp)
 1015f86:	lea    0x88(%rsp),%rdi
 1015f8e:	mov    %r13,%rsi
 1015f91:	xor    %edx,%edx
 1015f93:	movabs $0xffffffff00000000,%rcx
 1015f9d:	xor    %r8d,%r8d
 1015fa0:	vzeroupper
 1015fa3:	call   1017100 <flatten>
 1015fa8:	test   %eax,%eax
 1015faa:	je     1016c30 <collect+0x1580>
 1015fb0:	mov    0x98(%rsp),%rax
 1015fb8:	cmp    0x68(%r13),%rax
 1015fbc:	jne    1016c30 <collect+0x1580>
 1015fc2:	test   %rax,%rax
 1015fc5:	je     10161dd <collect+0xb2d>
 1015fcb:	mov    0x60(%r13),%rsi
 1015fcf:	mov    %rax,0x40(%rsp)
 1015fd4:	lea    0x0(,%rax,4),%rax
 1015fdc:	lea    (%rax,%rax,2),%rdx
 1015fe0:	lea    0xc0(%rsp),%rdi
 1015fe8:	call   1027870 <bcmp@plt>
 1015fed:	test   %eax,%eax
 1015fef:	mov    0x10(%rsp),%r15
 1015ff4:	je     10160ad <collect+0x9fd>
 1015ffa:	jmp    1016c30 <collect+0x1580>
 1015fff:	mov    (%rcx),%rcx
 1016002:	mov    $0x3c,%edx
 1016007:	bzhi   %rdx,%rax,%rsi
 101600c:	shr    $0x2,%rsi
 1016010:	test   %rcx,%rcx
 1016013:	je     1016143 <collect+0xa93>
 1016019:	cmp    $0x3fff0,%rcx
 1016020:	ja     1016138 <collect+0xa88>
 1016026:	mov    $0x3fff0,%eax
 101602b:	xor    %edx,%edx
 101602d:	div    %ecx
 101602f:	cmp    %rax,%rsi
 1016032:	ja     1015de0 <collect+0x730>
 1016038:	jmp    1016143 <collect+0xa93>
 101603d:	mov    0x1150(%r15),%rax
 1016044:	lea    0x1(%rcx),%rdx
 1016048:	mov    %rdx,0x1158(%r15)
 101604f:	mov    %r14,(%rax,%rcx,8)
 1016053:	jmp    1015de0 <collect+0x730>
 1016058:	test   %r14,%r14
 101605b:	mov    0x10(%rsp),%r15
 1016060:	je     1015e80 <collect+0x7d0>
 1016066:	xor    %ebx,%ebx
 1016068:	nopl   0x0(%rax,%rax,1)
 1016070:	mov    0x0(%r13),%rdx
 1016074:	imul   %rbx,%rdx
 1016078:	add    %r12,%rdx
 101607b:	mov    %r15,%rdi
 101607e:	mov    %r13,%rsi
 1016081:	vzeroupper
 1016084:	call   1016c60 <trace>
 1016089:	inc    %rbx
 101608c:	cmp    %rbx,%r14
 101608f:	jne    1016070 <collect+0x9c0>
 1016091:	jmp    1015e80 <collect+0x7d0>
 1016096:	mov    0x68(%r13),%rax
 101609a:	mov    %rax,0x40(%rsp)
 101609f:	test   %rax,%rax
 10160a2:	mov    0x10(%rsp),%r15
 10160a7:	je     1015e80 <collect+0x7d0>
 10160ad:	test   %r14,%r14
 10160b0:	je     1015e80 <collect+0x7d0>
 10160b6:	mov    0x0(%r13),%rax
 10160ba:	mov    %rax,0x60(%rsp)
 10160bf:	addq   $0x8,0x18(%rsp)
 10160c5:	xor    %ebx,%ebx
 10160c7:	jmp    10160e6 <collect+0xa36>
 10160c9:	nopl   0x0(%rax)
 10160d0:	inc    %rbx
 10160d3:	add    0x60(%rsp),%r12
 10160d8:	cmp    %r14,%rbx
 10160db:	mov    0x10(%rsp),%r15
 10160e0:	je     1015e80 <collect+0x7d0>
 10160e6:	mov    0x18(%rsp),%r13
 10160eb:	mov    0x40(%rsp),%r15
 10160f0:	jmp    101611e <collect+0xa6e>
 10160f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016100:	mov    -0x8(%r13),%eax
 1016104:	mov    (%r12,%rax,1),%rsi
 1016108:	mov    0x10(%rsp),%rdi
 101610d:	vzeroupper
 1016110:	call   1016eb0 <mark>
 1016115:	add    $0xc,%r13
 1016119:	dec    %r15
 101611c:	je     10160d0 <collect+0xa20>
 101611e:	mov    -0x4(%r13),%eax
 1016122:	mov    $0xffffffff,%ecx
 1016127:	cmp    %rcx,%rax
 101612a:	je     1016100 <collect+0xa50>
 101612c:	mov    (%r12,%rax,1),%eax
 1016130:	cmp    0x0(%r13),%eax
 1016134:	je     1016100 <collect+0xa50>
 1016136:	jmp    1016115 <collect+0xa65>
 1016138:	xor    %eax,%eax
 101613a:	cmp    %rax,%rsi
 101613d:	ja     1015de0 <collect+0x730>
 1016143:	imul   %rsi,%rcx
 1016147:	add    $0x1f,%rcx
 101614b:	cmp    $0xf,%rcx
 101614f:	setae  %al
 1016152:	and    $0xfffffffffffffff0,%rcx
 1016156:	cmp    $0x40001,%rcx
 101615d:	setae  %cl
 1016160:	test   %cl,%al
 1016162:	jne    1015de0 <collect+0x730>
 1016168:	mov    0x1140(%r15),%rcx
 101616f:	cmp    0x1148(%r15),%rcx
 1016176:	jne    10161e7 <collect+0xb37>
 1016178:	lea    (%rcx,%rcx,1),%rbx
 101617c:	test   %rcx,%rcx
 101617f:	mov    $0x100,%eax
 1016184:	cmove  %rax,%rbx
 1016188:	cmp    %rcx,%rbx
 101618b:	setbe  %al
 101618e:	movabs $0x1fffffffffffffff,%rcx
 1016198:	cmp    %rcx,%rbx
 101619b:	seta   %cl
 101619e:	or     %al,%cl
 10161a0:	jne    1015dcf <collect+0x71f>
 10161a6:	mov    0x1138(%r15),%rdi
 10161ad:	lea    0x0(,%rbx,8),%rsi
 10161b5:	vzeroupper
 10161b8:	call   10277f0 <realloc@plt>
 10161bd:	test   %rax,%rax
 10161c0:	je     1015dcf <collect+0x71f>
 10161c6:	mov    %rax,0x1138(%r15)
 10161cd:	mov    %rbx,0x1148(%r15)
 10161d4:	mov    0x1140(%r15),%rcx
 10161db:	jmp    10161ee <collect+0xb3e>
 10161dd:	mov    0x10(%rsp),%r15
 10161e2:	jmp    1015e80 <collect+0x7d0>
 10161e7:	mov    0x1138(%r15),%rax
 10161ee:	lea    0x1(%rcx),%rdx
 10161f2:	mov    %rdx,0x1140(%r15)
 10161f9:	mov    %r14,(%rax,%rcx,8)
 10161fd:	jmp    1015de0 <collect+0x730>
 1016202:	movb   $0x0,0x1174(%r15)
 101620a:	cmpl   $0x0,0x4f8(%r15)
 1016212:	mov    (%r15),%r14
 1016215:	jne    1016266 <collect+0xbb6>
 1016217:	test   %r14,%r14
 101621a:	je     1016b1d <collect+0x146d>
 1016220:	xor    %r13d,%r13d
 1016223:	vpbroadcastq -0x14824(%rip),%ymm0        # 1001a08 <__abi_tag+0x170c>
 101622c:	vmovdqa %ymm0,0xa0(%rsp)
 1016235:	xor    %ebx,%ebx
 1016237:	xor    %r11d,%r11d
 101623a:	mov    %r15,%rdx
 101623d:	jmp    101633c <collect+0xc8c>
 1016242:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016250:	lea    0x48(%r14),%rdi
 1016254:	mov    $0x400,%edx
 1016259:	xor    %esi,%esi
 101625b:	vzeroupper
 101625e:	call   1027650 <memset@plt>
 1016263:	mov    (%r14),%r14
 1016266:	test   %r14,%r14
 1016269:	je     10162f7 <collect+0xc47>
 101626f:	cmpq   $0x20,0x20(%r14)
 1016274:	jb     1016250 <collect+0xba0>
 1016276:	mov    0x18(%r14),%rdx
 101627a:	test   %rdx,%rdx
 101627d:	je     10162eb <collect+0xc3b>
 101627f:	mov    0x8(%r14),%rax
 1016283:	mov    %edx,%ecx
 1016285:	and    $0x3,%ecx
 1016288:	cmp    $0x4,%rdx
 101628c:	jae    1016292 <collect+0xbe2>
 101628e:	xor    %esi,%esi
 1016290:	jmp    10162d1 <collect+0xc21>
 1016292:	lea    0x470(%r14),%rdi
 1016299:	and    $0xfffffffffffffffc,%rdx
 101629d:	lea    (%rax,%rax,2),%r8
 10162a1:	lea    0x0(,%rax,4),%r9
 10162a9:	xor    %esi,%esi
 10162ab:	nopl   0x0(%rax,%rax,1)
 10162b0:	andb   $0xfe,(%rdi)
 10162b3:	andb   $0xfe,(%rdi,%rax,1)
 10162b7:	andb   $0xfe,(%rdi,%rax,2)
 10162bb:	andb   $0xfe,(%rdi,%r8,1)
 10162c0:	add    $0x4,%rsi
 10162c4:	add    %r9,%rdi
 10162c7:	cmp    %rsi,%rdx
 10162ca:	jne    10162b0 <collect+0xc00>
 10162cc:	test   %rcx,%rcx
 10162cf:	je     10162eb <collect+0xc3b>
 10162d1:	imul   %rax,%rsi
 10162d5:	lea    (%r14,%rsi,1),%rdx
 10162d9:	add    $0x470,%rdx
 10162e0:	andb   $0xfe,(%rdx)
 10162e3:	add    %rax,%rdx
 10162e6:	dec    %rcx
 10162e9:	jne    10162e0 <collect+0xc30>
 10162eb:	mov    (%r14),%r14
 10162ee:	test   %r14,%r14
 10162f1:	jne    101626f <collect+0xbbf>
 10162f7:	movq   $0x0,0x4e8(%r15)
 1016302:	movl   $0x1,0x1170(%r15)
 101630d:	jmp    1016c1e <collect+0x156e>
 1016312:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016320:	add    0x8(%r14),%r13
 1016324:	inc    %rbx
 1016327:	mov    (%r14),%rax
 101632a:	mov    %r14,%rdx
 101632d:	mov    %r11,%r12
 1016330:	mov    %rax,%r14
 1016333:	test   %rax,%rax
 1016336:	je     1016b25 <collect+0x1475>
 101633c:	mov    0x20(%r14),%rcx
 1016340:	lea    0x470(%r14),%rdi
 1016347:	cmp    $0x34,%rcx
 101634b:	jb     1016370 <collect+0xcc0>
 101634d:	testb  $0x1,(%rdi)
 1016350:	jne    1016320 <collect+0xc70>
 1016352:	mov    (%r14),%rax
 1016355:	mov    %rax,(%rdx)
 1016358:	mov    %r14,%rdi
 101635b:	mov    %rdx,%r14
 101635e:	mov    %r11,%r12
 1016361:	vzeroupper
 1016364:	call   10276f0 <free@plt>
 1016369:	mov    %r12,%r11
 101636c:	jmp    1016327 <collect+0xc77>
 101636e:	xchg   %ax,%ax
 1016370:	mov    0x8(%r14),%rax
 1016374:	mov    0x18(%r14),%r9
 1016378:	imul   %rax,%r9
 101637c:	lea    (%rdi,%r9,1),%r8
 1016380:	cmp    $0x20,%rcx
 1016384:	mov    %rdx,0x18(%rsp)
 1016389:	jb     10163e0 <collect+0xd30>
 101638b:	test   %r9,%r9
 101638e:	je     101650c <collect+0xe5c>
 1016394:	mov    %rdi,%r9
 1016397:	xor    %esi,%esi
 1016399:	xor    %r10d,%r10d
 101639c:	xor    %edx,%edx
 101639e:	jmp    10163b9 <collect+0xd09>
 10163a0:	mov    %r10,%rdi
 10163a3:	mov    %rdi,%r10
 10163a6:	lea    (%r9,%rax,1),%rdi
 10163aa:	inc    %rsi
 10163ad:	add    %rax,%r9
 10163b0:	cmp    %r8,%r9
 10163b3:	jae    10164d0 <collect+0xe20>
 10163b9:	testb  $0x1,(%r9)
 10163bd:	je     10163ad <collect+0xcfd>
 10163bf:	cmp    %r9,%rdi
 10163c2:	jae    10163a0 <collect+0xcf0>
 10163c4:	mov    %r9,(%rdi)
 10163c7:	movq   $0x0,0x8(%rdi)
 10163cf:	test   %r10,%r10
 10163d2:	je     10163da <collect+0xd2a>
 10163d4:	mov    %rdi,0x8(%r10)
 10163d8:	jmp    10163a3 <collect+0xcf3>
 10163da:	mov    %rdi,%rdx
 10163dd:	jmp    10163a3 <collect+0xcf3>
 10163df:	nop
 10163e0:	mov    %r11,0x60(%rsp)
 10163e5:	mov    %rbx,0x20(%rsp)
 10163ea:	mov    %r13,0x40(%rsp)
 10163ef:	add    $0x470,%r9
 10163f6:	shr    $0x4,%r9
 10163fa:	lea    0x3f(%r9),%r10
 10163fe:	shr    $0x6,%r10
 1016402:	mov    $0x1,%r15d
 1016408:	xor    %edx,%edx
 101640a:	xor    %r12d,%r12d
 101640d:	xor    %esi,%esi
 101640f:	jmp    1016428 <collect+0xd78>
 1016411:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016420:	inc    %r15
 1016423:	cmp    %r10,%r15
 1016426:	je     10164a0 <collect+0xdf0>
 1016428:	mov    0x48(%r14,%r15,8),%r13
 101642d:	test   %r13,%r13
 1016430:	je     1016420 <collect+0xd70>
 1016432:	mov    %r15,%r11
 1016435:	shl    $0x6,%r11
 1016439:	jmp    1016456 <collect+0xda6>
 101643b:	nopl   0x0(%rax,%rax,1)
 1016440:	mov    %r12,%rdi
 1016443:	add    %rax,%rbx
 1016446:	inc    %rsi
 1016449:	mov    %rdi,%r12
 101644c:	mov    %rbx,%rdi
 101644f:	blsr   %r13,%r13
 1016454:	je     1016420 <collect+0xd70>
 1016456:	tzcnt  %r13,%rbx
 101645b:	or     %r11,%rbx
 101645e:	cmp    $0x47,%rbx
 1016462:	jb     101644f <collect+0xd9f>
 1016464:	cmp    %r9,%rbx
 1016467:	jae    101644f <collect+0xd9f>
 1016469:	shl    $0x4,%rbx
 101646d:	add    %r14,%rbx
 1016470:	cmp    %rbx,%rdi
 1016473:	jae    1016440 <collect+0xd90>
 1016475:	mov    %rbx,(%rdi)
 1016478:	movq   $0x0,0x8(%rdi)
 1016480:	test   %r12,%r12
 1016483:	je     101648c <collect+0xddc>
 1016485:	mov    %rdi,0x8(%r12)
 101648a:	jmp    1016443 <collect+0xd93>
 101648c:	mov    %rdi,%rdx
 101648f:	jmp    1016443 <collect+0xd93>
 1016491:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10164a0:	cmp    %r8,%rdi
 10164a3:	jae    10164f6 <collect+0xe46>
 10164a5:	mov    %r8,(%rdi)
 10164a8:	movq   $0x0,0x8(%rdi)
 10164b0:	test   %r12,%r12
 10164b3:	mov    0x10(%rsp),%r15
 10164b8:	mov    0x40(%rsp),%r13
 10164bd:	mov    0x20(%rsp),%rbx
 10164c2:	mov    0x60(%rsp),%r11
 10164c7:	je     1016518 <collect+0xe68>
 10164c9:	mov    %rdi,0x8(%r12)
 10164ce:	jmp    1016520 <collect+0xe70>
 10164d0:	cmp    %r8,%rdi
 10164d3:	jae    10169fb <collect+0x134b>
 10164d9:	mov    %r8,(%rdi)
 10164dc:	movq   $0x0,0x8(%rdi)
 10164e4:	test   %r10,%r10
 10164e7:	je     10169f8 <collect+0x1348>
 10164ed:	mov    %rdi,0x8(%r10)
 10164f1:	jmp    10169fb <collect+0x134b>
 10164f6:	mov    0x10(%rsp),%r15
 10164fb:	mov    0x40(%rsp),%r13
 1016500:	mov    0x20(%rsp),%rbx
 1016505:	mov    0x60(%rsp),%r11
 101650a:	jmp    1016520 <collect+0xe70>
 101650c:	xor    %edx,%edx
 101650e:	xor    %r12d,%r12d
 1016511:	xor    %esi,%esi
 1016513:	jmp    10169fe <collect+0x134e>
 1016518:	mov    %rdi,%rdx
 101651b:	nopl   0x0(%rax,%rax,1)
 1016520:	vmovdqu 0x48(%r14),%ymm1
 1016526:	vmovdqu 0x68(%r14),%ymm2
 101652c:	vmovdqu 0x88(%r14),%ymm3
 1016535:	vmovdqu 0xa8(%r14),%ymm4
 101653e:	vpand  0x248(%r14),%ymm1,%ymm5
 1016547:	vpand  0x268(%r14),%ymm2,%ymm6
 1016550:	vpand  0x288(%r14),%ymm3,%ymm7
 1016559:	vpand  0x2a8(%r14),%ymm4,%ymm0
 1016562:	vmovdqu %ymm5,0x248(%r14)
 101656b:	vmovdqu %ymm6,0x268(%r14)
 1016574:	vmovdqu %ymm7,0x288(%r14)
 101657d:	vmovdqu %ymm0,0x2a8(%r14)
 1016586:	vpxor  %ymm1,%ymm5,%ymm1
 101658a:	vpxor  %ymm2,%ymm6,%ymm2
 101658e:	vpxor  %ymm3,%ymm7,%ymm3
 1016592:	vpxor  %ymm4,%ymm0,%ymm4
 1016596:	vmovdqu %ymm1,0x48(%r14)
 101659c:	vmovdqu %ymm2,0x68(%r14)
 10165a2:	vmovdqu %ymm3,0x88(%r14)
 10165ab:	vmovdqu %ymm4,0xa8(%r14)
 10165b4:	vpbroadcastb -0x14b45(%rip),%ymm15        # 1001a78 <__abi_tag+0x177c>
 10165bd:	vpand  %ymm5,%ymm15,%ymm1
 10165c1:	vmovdqa -0x14ca9(%rip),%ymm13        # 1001920 <__abi_tag+0x1624>
 10165c9:	vpshufb %ymm1,%ymm13,%ymm1
 10165ce:	vmovdqa 0xa0(%rsp),%ymm12
 10165d7:	vgf2p8affineqb $0x0,%ymm12,%ymm5,%ymm2
 10165dd:	vpshufb %ymm2,%ymm13,%ymm2
 10165e2:	vpaddb %ymm1,%ymm2,%ymm1
 10165e6:	vpxor  %xmm14,%xmm14,%xmm14
 10165eb:	vpsadbw %ymm1,%ymm14,%ymm3
 10165ef:	vpand  %ymm6,%ymm15,%ymm1
 10165f3:	vpshufb %ymm1,%ymm13,%ymm1
 10165f8:	vgf2p8affineqb $0x0,%ymm12,%ymm6,%ymm2
 10165fe:	vpshufb %ymm2,%ymm13,%ymm2
 1016603:	vpaddb %ymm1,%ymm2,%ymm1
 1016607:	vpsadbw %ymm1,%ymm14,%ymm2
 101660b:	vpand  %ymm7,%ymm15,%ymm1
 101660f:	vpshufb %ymm1,%ymm13,%ymm1
 1016614:	vgf2p8affineqb $0x0,%ymm12,%ymm7,%ymm4
 101661a:	vpshufb %ymm4,%ymm13,%ymm4
 101661f:	vpaddb %ymm1,%ymm4,%ymm1
 1016623:	vpsadbw %ymm1,%ymm14,%ymm1
 1016627:	vpand  %ymm0,%ymm15,%ymm4
 101662b:	vpshufb %ymm4,%ymm13,%ymm4
 1016630:	vgf2p8affineqb $0x0,%ymm12,%ymm0,%ymm0
 1016636:	vpshufb %ymm0,%ymm13,%ymm0
 101663b:	vpaddb %ymm4,%ymm0,%ymm0
 101663f:	vpsadbw %ymm0,%ymm14,%ymm0
 1016643:	vmovdqu 0xc8(%r14),%ymm5
 101664c:	vmovdqu 0xe8(%r14),%ymm6
 1016655:	vmovdqu 0x108(%r14),%ymm7
 101665e:	vmovdqu 0x128(%r14),%ymm8
 1016667:	vpand  0x2c8(%r14),%ymm5,%ymm9
 1016670:	vpand  0x2e8(%r14),%ymm6,%ymm10
 1016679:	vpand  0x308(%r14),%ymm7,%ymm11
 1016682:	vpand  0x328(%r14),%ymm8,%ymm4
 101668b:	vmovdqu %ymm9,0x2c8(%r14)
 1016694:	vmovdqu %ymm10,0x2e8(%r14)
 101669d:	vmovdqu %ymm11,0x308(%r14)
 10166a6:	vmovdqu %ymm4,0x328(%r14)
 10166af:	vpxor  %ymm5,%ymm9,%ymm5
 10166b3:	vpxor  %ymm6,%ymm10,%ymm6
 10166b7:	vpxor  %ymm7,%ymm11,%ymm7
 10166bb:	vpxor  %ymm4,%ymm8,%ymm8
 10166bf:	vmovdqu %ymm5,0xc8(%r14)
 10166c8:	vmovdqu %ymm6,0xe8(%r14)
 10166d1:	vmovdqu %ymm7,0x108(%r14)
 10166da:	vmovdqu %ymm8,0x128(%r14)
 10166e3:	vpand  %ymm15,%ymm9,%ymm5
 10166e8:	vpshufb %ymm5,%ymm13,%ymm5
 10166ed:	vgf2p8affineqb $0x0,%ymm12,%ymm9,%ymm6
 10166f3:	vpshufb %ymm6,%ymm13,%ymm6
 10166f8:	vpaddb %ymm5,%ymm6,%ymm5
 10166fc:	vpsadbw %ymm5,%ymm14,%ymm5
 1016700:	vpaddq %ymm3,%ymm5,%ymm3
 1016704:	vpand  %ymm15,%ymm10,%ymm5
 1016709:	vpshufb %ymm5,%ymm13,%ymm5
 101670e:	vgf2p8affineqb $0x0,%ymm12,%ymm10,%ymm6
 1016714:	vpshufb %ymm6,%ymm13,%ymm6
 1016719:	vpaddb %ymm5,%ymm6,%ymm5
 101671d:	vpsadbw %ymm5,%ymm14,%ymm5
 1016721:	vpaddq %ymm2,%ymm5,%ymm2
 1016725:	vmovdqa %ymm2,0x60(%rsp)
 101672b:	vpand  %ymm15,%ymm11,%ymm5
 1016730:	vpshufb %ymm5,%ymm13,%ymm5
 1016735:	vgf2p8affineqb $0x0,%ymm12,%ymm11,%ymm6
 101673b:	vpshufb %ymm6,%ymm13,%ymm6
 1016740:	vpaddb %ymm5,%ymm6,%ymm5
 1016744:	vpsadbw %ymm5,%ymm14,%ymm5
 1016748:	vpaddq %ymm1,%ymm5,%ymm1
 101674c:	vmovdqa %ymm1,0x40(%rsp)
 1016752:	vpand  %ymm4,%ymm15,%ymm5
 1016756:	vmovdqa %ymm15,%ymm2
 101675a:	vpshufb %ymm5,%ymm13,%ymm5
 101675f:	vgf2p8affineqb $0x0,%ymm12,%ymm4,%ymm4
 1016765:	vpshufb %ymm4,%ymm13,%ymm4
 101676a:	vpaddb %ymm5,%ymm4,%ymm4
 101676e:	vpsadbw %ymm4,%ymm14,%ymm4
 1016772:	vpaddq %ymm0,%ymm4,%ymm0
 1016776:	vmovdqa %ymm0,0x20(%rsp)
 101677c:	vmovdqu 0x148(%r14),%ymm5
 1016785:	vmovdqu 0x168(%r14),%ymm6
 101678e:	vmovdqu 0x188(%r14),%ymm7
 1016797:	vmovdqu 0x1a8(%r14),%ymm8
 10167a0:	vpand  0x348(%r14),%ymm5,%ymm9
 10167a9:	vpand  0x368(%r14),%ymm6,%ymm10
 10167b2:	vpand  0x388(%r14),%ymm7,%ymm11
 10167bb:	vpand  0x3a8(%r14),%ymm8,%ymm4
 10167c4:	vmovdqu %ymm9,0x348(%r14)
 10167cd:	vmovdqu %ymm10,0x368(%r14)
 10167d6:	vmovdqu %ymm11,0x388(%r14)
 10167df:	vmovdqu %ymm4,0x3a8(%r14)
 10167e8:	vpxor  %ymm5,%ymm9,%ymm5
 10167ec:	vpxor  %ymm6,%ymm10,%ymm6
 10167f0:	vpxor  %ymm7,%ymm11,%ymm7
 10167f4:	vpxor  %ymm4,%ymm8,%ymm8
 10167f8:	vmovdqu %ymm5,0x148(%r14)
 1016801:	vmovdqu %ymm6,0x168(%r14)
 101680a:	vmovdqu %ymm7,0x188(%r14)
 1016813:	vmovdqu %ymm8,0x1a8(%r14)
 101681c:	vpand  %ymm15,%ymm9,%ymm5
 1016821:	vpshufb %ymm5,%ymm13,%ymm5
 1016826:	vgf2p8affineqb $0x0,%ymm12,%ymm9,%ymm6
 101682c:	vpshufb %ymm6,%ymm13,%ymm6
 1016831:	vpaddb %ymm5,%ymm6,%ymm7
 1016835:	vpand  %ymm15,%ymm10,%ymm5
 101683a:	vpshufb %ymm5,%ymm13,%ymm5
 101683f:	vgf2p8affineqb $0x0,%ymm12,%ymm10,%ymm6
 1016845:	vpshufb %ymm6,%ymm13,%ymm6
 101684a:	vpaddb %ymm5,%ymm6,%ymm6
 101684e:	vpand  %ymm15,%ymm11,%ymm5
 1016853:	vpshufb %ymm5,%ymm13,%ymm5
 1016858:	vgf2p8affineqb $0x0,%ymm12,%ymm11,%ymm8
 101685e:	vpshufb %ymm8,%ymm13,%ymm8
 1016863:	vpaddb %ymm5,%ymm8,%ymm5
 1016867:	vpand  %ymm4,%ymm15,%ymm8
 101686b:	vpshufb %ymm8,%ymm13,%ymm8
 1016870:	vgf2p8affineqb $0x0,%ymm12,%ymm4,%ymm4
 1016876:	vpshufb %ymm4,%ymm13,%ymm4
 101687b:	vpaddb %ymm4,%ymm8,%ymm4
 101687f:	vmovdqu 0x1c8(%r14),%ymm10
 1016888:	vmovdqu 0x1e8(%r14),%ymm11
 1016891:	vmovdqu 0x208(%r14),%ymm0
 101689a:	vmovdqu 0x228(%r14),%ymm1
 10168a3:	vpand  0x3c8(%r14),%ymm10,%ymm14
 10168ac:	vpand  0x3e8(%r14),%ymm11,%ymm15
 10168b5:	vpand  0x408(%r14),%ymm0,%ymm9
 10168be:	vpand  0x428(%r14),%ymm1,%ymm8
 10168c7:	vmovdqu %ymm14,0x3c8(%r14)
 10168d0:	vmovdqu %ymm15,0x3e8(%r14)
 10168d9:	vmovdqu %ymm9,0x408(%r14)
 10168e2:	vmovdqu %ymm8,0x428(%r14)
 10168eb:	vpxor  %ymm10,%ymm14,%ymm10
 10168f0:	vmovdqu %ymm10,0x1c8(%r14)
 10168f9:	vpxor  %ymm11,%ymm15,%ymm10
 10168fe:	vmovdqu %ymm10,0x1e8(%r14)
 1016907:	vpxor  %ymm0,%ymm9,%ymm10
 101690b:	vmovdqu %ymm10,0x208(%r14)
 1016914:	vpxor  %ymm1,%ymm8,%ymm10
 1016918:	vmovdqu %ymm10,0x228(%r14)
 1016921:	vpand  %ymm2,%ymm14,%ymm10
 1016925:	vpshufb %ymm10,%ymm13,%ymm10
 101692a:	vgf2p8affineqb $0x0,%ymm12,%ymm14,%ymm11
 1016930:	vpshufb %ymm11,%ymm13,%ymm11
 1016935:	vpaddb %ymm10,%ymm11,%ymm10
 101693a:	vpxor  %xmm0,%xmm0,%xmm0
 101693e:	vpsadbw %ymm0,%ymm7,%ymm7
 1016942:	vpsadbw %ymm0,%ymm10,%ymm10
 1016946:	vpaddq %ymm7,%ymm10,%ymm7
 101694a:	vpaddq %ymm3,%ymm7,%ymm3
 101694e:	vpand  %ymm2,%ymm15,%ymm7
 1016952:	vmovdqa %ymm2,%ymm11
 1016956:	vpshufb %ymm7,%ymm13,%ymm7
 101695b:	vgf2p8affineqb $0x0,%ymm12,%ymm15,%ymm10
 1016961:	vpshufb %ymm10,%ymm13,%ymm10
 1016966:	vpaddb %ymm7,%ymm10,%ymm7
 101696a:	vpsadbw %ymm0,%ymm6,%ymm6
 101696e:	vpsadbw %ymm0,%ymm7,%ymm7
 1016972:	vpaddq %ymm6,%ymm7,%ymm6
 1016976:	vpaddq 0x60(%rsp),%ymm6,%ymm2
 101697c:	vpaddq %ymm3,%ymm2,%ymm2
 1016980:	vpand  %ymm11,%ymm9,%ymm3
 1016985:	vpshufb %ymm3,%ymm13,%ymm3
 101698a:	vgf2p8affineqb $0x0,%ymm12,%ymm9,%ymm6
 1016990:	vpshufb %ymm6,%ymm13,%ymm6
 1016995:	vpaddb %ymm3,%ymm6,%ymm3
 1016999:	vpsadbw %ymm0,%ymm5,%ymm5
 101699d:	vpsadbw %ymm0,%ymm3,%ymm3
 10169a1:	vpaddq %ymm5,%ymm3,%ymm3
 10169a5:	vpaddq 0x40(%rsp),%ymm3,%ymm1
 10169ab:	vpaddq %ymm2,%ymm1,%ymm1
 10169af:	vpand  %ymm11,%ymm8,%ymm2
 10169b4:	vpshufb %ymm2,%ymm13,%ymm2
 10169b9:	vgf2p8affineqb $0x0,%ymm12,%ymm8,%ymm3
 10169bf:	vpshufb %ymm3,%ymm13,%ymm3
 10169c4:	vpaddb %ymm2,%ymm3,%ymm2
 10169c8:	vpsadbw %ymm0,%ymm4,%ymm3
 10169cc:	vpsadbw %ymm0,%ymm2,%ymm2
 10169d0:	vpaddq %ymm3,%ymm2,%ymm2
 10169d4:	vpaddq 0x20(%rsp),%ymm2,%ymm0
 10169da:	vpaddq %ymm1,%ymm0,%ymm0
 10169de:	vextracti128 $0x1,%ymm0,%xmm1
 10169e4:	vpaddq %xmm1,%xmm0,%xmm0
 10169e8:	vpshufd $0xee,%xmm0,%xmm1
 10169ed:	vpaddq %xmm1,%xmm0,%xmm0
 10169f1:	vmovq  %xmm0,%r12
 10169f6:	jmp    10169fe <collect+0x134e>
 10169f8:	mov    %rdi,%rdx
 10169fb:	xor    %r12d,%r12d
 10169fe:	mov    %rdx,0x28(%r14)
 1016a02:	mov    %rsi,0x30(%r14)
 1016a06:	test   %r12,%r12
 1016a09:	setne  0x40(%r14)
 1016a0e:	imul   %rax,%r12
 1016a12:	add    %r11,%r12
 1016a15:	test   %rsi,%rsi
 1016a18:	jne    1016ae0 <collect+0x1430>
 1016a1e:	cmp    $0x1f,%rcx
 1016a22:	ja     1016ae0 <collect+0x1430>
 1016a28:	imul   $0x38,%rcx,%rcx
 1016a2c:	mov    0x80(%rsp),%rsi
 1016a34:	cmp    %r14,(%rsi,%rcx,1)
 1016a38:	je     1016a97 <collect+0x13e7>
 1016a3a:	mov    0x11d8(%r15),%rcx
 1016a41:	cmp    0x11e0(%r15),%rcx
 1016a48:	jne    1016a9b <collect+0x13eb>
 1016a4a:	mov    %rbx,0x20(%rsp)
 1016a4f:	lea    (%rcx,%rcx,1),%rbx
 1016a53:	test   %rcx,%rcx
 1016a56:	mov    $0x40,%eax
 1016a5b:	cmove  %rax,%rbx
 1016a5f:	mov    0x11d0(%r15),%rdi
 1016a66:	lea    0x0(,%rbx,8),%rsi
 1016a6e:	vzeroupper
 1016a71:	call   10277f0 <realloc@plt>
 1016a76:	test   %rax,%rax
 1016a79:	je     1016acd <collect+0x141d>
 1016a7b:	mov    %rax,0x11d0(%r15)
 1016a82:	mov    %rbx,0x11e0(%r15)
 1016a89:	mov    0x11d8(%r15),%rcx
 1016a90:	mov    0x20(%rsp),%rbx
 1016a95:	jmp    1016aa2 <collect+0x13f2>
 1016a97:	xor    %esi,%esi
 1016a99:	jmp    1016ae0 <collect+0x1430>
 1016a9b:	mov    0x11d0(%r15),%rax
 1016aa2:	lea    0x1(%rcx),%rdx
 1016aa6:	mov    %rdx,0x11d8(%r15)
 1016aad:	mov    %r14,(%rax,%rcx,8)
 1016ab1:	mov    (%r14),%rax
 1016ab4:	mov    0x18(%rsp),%rdx
 1016ab9:	mov    %rax,(%rdx)
 1016abc:	mov    %r12,%r11
 1016abf:	mov    %rax,%r14
 1016ac2:	test   %rax,%rax
 1016ac5:	jne    101633c <collect+0xc8c>
 1016acb:	jmp    1016b25 <collect+0x1475>
 1016acd:	mov    0x30(%r14),%rsi
 1016ad1:	mov    0x8(%r14),%rax
 1016ad5:	mov    0x28(%r14),%rdx
 1016ad9:	mov    0x20(%rsp),%rbx
 1016ade:	xchg   %ax,%ax
 1016ae0:	imul   %rsi,%rax
 1016ae4:	add    %rax,%r13
 1016ae7:	add    %rsi,%rbx
 1016aea:	movq   $0x0,0x38(%r14)
 1016af2:	test   %rdx,%rdx
 1016af5:	setne  0x41(%r14)
 1016afa:	je     1016b15 <collect+0x1465>
 1016afc:	imul   $0x38,0x20(%r14),%rax
 1016b01:	mov    0x5e8(%r15,%rax,1),%rcx
 1016b09:	mov    %rcx,0x38(%r14)
 1016b0d:	mov    %r14,0x5e8(%r15,%rax,1)
 1016b15:	mov    %r12,%r11
 1016b18:	jmp    1016327 <collect+0xc77>
 1016b1d:	xor    %r12d,%r12d
 1016b20:	xor    %ebx,%ebx
 1016b22:	xor    %r13d,%r13d
 1016b25:	mov    0xb0(%r15),%rax
 1016b2c:	add    %r13,%rax
 1016b2f:	mov    %rax,0x18(%r15)
 1016b33:	mov    0x40(%r15),%rax
 1016b37:	add    %rbx,%rax
 1016b3a:	sub    0x1198(%r15),%rax
 1016b41:	mov    %rax,0x40(%r15)
 1016b45:	mov    %rbx,0x1198(%r15)
 1016b4c:	mov    %r12,0x1190(%r15)
 1016b53:	mov    0x1158(%r15),%rdx
 1016b5a:	test   %rdx,%rdx
 1016b5d:	je     1016bd0 <collect+0x1520>
 1016b5f:	mov    0x1150(%r15),%rcx
 1016b66:	mov    %edx,%eax
 1016b68:	and    $0x3,%eax
 1016b6b:	cmp    $0x4,%rdx
 1016b6f:	jae    1016b75 <collect+0x14c5>
 1016b71:	xor    %esi,%esi
 1016b73:	jmp    1016bb1 <collect+0x1501>
 1016b75:	and    $0xfffffffffffffffc,%rdx
 1016b79:	xor    %esi,%esi
 1016b7b:	nopl   0x0(%rax,%rax,1)
 1016b80:	mov    (%rcx,%rsi,8),%rdi
 1016b84:	andq   $0xfffffffffffffffe,(%rdi)
 1016b88:	mov    0x8(%rcx,%rsi,8),%rdi
 1016b8d:	andq   $0xfffffffffffffffe,(%rdi)
 1016b91:	mov    0x10(%rcx,%rsi,8),%rdi
 1016b96:	andq   $0xfffffffffffffffe,(%rdi)
 1016b9a:	mov    0x18(%rcx,%rsi,8),%rdi
 1016b9f:	andq   $0xfffffffffffffffe,(%rdi)
 1016ba3:	add    $0x4,%rsi
 1016ba7:	cmp    %rsi,%rdx
 1016baa:	jne    1016b80 <collect+0x14d0>
 1016bac:	test   %rax,%rax
 1016baf:	je     1016bd0 <collect+0x1520>
 1016bb1:	lea    (%rcx,%rsi,8),%rcx
 1016bb5:	xor    %edx,%edx
 1016bb7:	nopw   0x0(%rax,%rax,1)
 1016bc0:	mov    (%rcx,%rdx,8),%rsi
 1016bc4:	andq   $0xfffffffffffffffe,(%rsi)
 1016bc8:	inc    %rdx
 1016bcb:	cmp    %rdx,%rax
 1016bce:	jne    1016bc0 <collect+0x1510>
 1016bd0:	mov    %r13,%rax
 1016bd3:	shr    $1,%rax
 1016bd6:	cmp    $0x400001,%rax
 1016bdc:	mov    $0x400000,%ecx
 1016be1:	cmovae %rax,%rcx
 1016be5:	add    %r13,%rcx
 1016be8:	mov    $0xffffffffffffffff,%rax
 1016bef:	cmovb  %rax,%rcx
 1016bf3:	mov    %rcx,0x60(%r15)
 1016bf7:	mov    %r13,%rcx
 1016bfa:	sub    %r12,%rcx
 1016bfd:	mov    %rcx,0x1188(%r15)
 1016c04:	test   %r13,%r13
 1016c07:	js     1016c17 <collect+0x1567>
 1016c09:	add    %r13,%r13
 1016c0c:	add    $0x400000,%r13
 1016c13:	cmovae %r13,%rax
 1016c17:	mov    %rax,0x1168(%r15)
 1016c1e:	lea    -0x28(%rbp),%rsp
 1016c22:	pop    %rbx
 1016c23:	pop    %r12
 1016c25:	pop    %r13
 1016c27:	pop    %r14
 1016c29:	pop    %r15
 1016c2b:	pop    %rbp
 1016c2c:	vzeroupper
 1016c2f:	ret
 1016c30:	mov    0x120e1(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1016c37:	mov    (%rax),%rcx
 1016c3a:	mov    $0x1004860,%edi
 1016c3f:	mov    $0x43,%esi
 1016c44:	mov    $0x1,%edx
 1016c49:	call   1027750 <fwrite@plt>
 1016c4e:	call   1027810 <abort@plt>
 1016c53:	int3
 1016c54:	int3
 1016c55:	int3
 1016c56:	int3
 1016c57:	int3
 1016c58:	int3
 1016c59:	int3
 1016c5a:	int3
 1016c5b:	int3
 1016c5c:	int3
 1016c5d:	int3
 1016c5e:	int3
 1016c5f:	int3

0000000001016c60 <trace>:
 1016c60:	push   %rbp
 1016c61:	mov    %rsp,%rbp
 1016c64:	push   %r15
 1016c66:	push   %r14
 1016c68:	push   %r13
 1016c6a:	push   %r12
 1016c6c:	push   %rbx
 1016c6d:	sub    $0x88,%rsp
 1016c74:	mov    0x58(%rsi),%eax
 1016c77:	cmp    $0x1,%eax
 1016c7a:	jne    1016c8e <trace+0x2e>
 1016c7c:	add    $0x88,%rsp
 1016c83:	pop    %rbx
 1016c84:	pop    %r12
 1016c86:	pop    %r13
 1016c88:	pop    %r14
 1016c8a:	pop    %r15
 1016c8c:	pop    %rbp
 1016c8d:	ret
 1016c8e:	mov    %rdx,%rbx
 1016c91:	mov    %rsi,%r15
 1016c94:	mov    %rdi,%r14
 1016c97:	movzwl 0x30(%rsi),%ecx
 1016c9b:	cmp    $0x6,%ecx
 1016c9e:	ja     1016cc6 <trace+0x66>
 1016ca0:	mov    $0x62,%edx
 1016ca5:	bt     %ecx,%edx
 1016ca8:	jae    1016cc6 <trace+0x66>
 1016caa:	mov    (%rbx),%rsi
 1016cad:	mov    %r14,%rdi
 1016cb0:	add    $0x88,%rsp
 1016cb7:	pop    %rbx
 1016cb8:	pop    %r12
 1016cba:	pop    %r13
 1016cbc:	pop    %r14
 1016cbe:	pop    %r15
 1016cc0:	pop    %rbp
 1016cc1:	jmp    1016eb0 <mark>
 1016cc6:	mov    0x60(%r15),%r12
 1016cca:	test   %r12,%r12
 1016ccd:	je     1016d72 <trace+0x112>
 1016cd3:	cmpl   $0x0,0x68(%r14)
 1016cd8:	je     1016dd6 <trace+0x176>
 1016cde:	lea    -0xb0(%rbp),%rax
 1016ce5:	mov    %rax,-0x48(%rbp)
 1016ce9:	movq   $0x8,-0x40(%rbp)
 1016cf1:	movq   $0x0,-0x38(%rbp)
 1016cf9:	lea    -0x48(%rbp),%rdi
 1016cfd:	movabs $0xffffffff00000000,%rcx
 1016d07:	mov    %r15,%rsi
 1016d0a:	xor    %edx,%edx
 1016d0c:	xor    %r8d,%r8d
 1016d0f:	call   1017100 <flatten>
 1016d14:	test   %eax,%eax
 1016d16:	je     1016d4f <trace+0xef>
 1016d18:	mov    -0x38(%rbp),%r13
 1016d1c:	cmp    0x68(%r15),%r13
 1016d20:	jne    1016d4f <trace+0xef>
 1016d22:	test   %r13,%r13
 1016d25:	je     1016c7c <trace+0x1c>
 1016d2b:	mov    0x60(%r15),%rsi
 1016d2f:	lea    0x0(,%r13,4),%rax
 1016d37:	lea    (%rax,%rax,2),%rdx
 1016d3b:	lea    -0xb0(%rbp),%rdi
 1016d42:	call   1027870 <bcmp@plt>
 1016d47:	test   %eax,%eax
 1016d49:	je     1016de3 <trace+0x183>
 1016d4f:	mov    0x11fc2(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1016d56:	mov    (%rax),%rcx
 1016d59:	mov    $0x1004860,%edi
 1016d5e:	mov    $0x43,%esi
 1016d63:	mov    $0x1,%edx
 1016d68:	call   1027750 <fwrite@plt>
 1016d6d:	call   1027810 <abort@plt>
 1016d72:	cmp    $0x2,%ecx
 1016d75:	je     1016e23 <trace+0x1c3>
 1016d7b:	cmp    $0x4,%ecx
 1016d7e:	je     1016e23 <trace+0x1c3>
 1016d84:	cmp    $0x3,%ecx
 1016d87:	jne    1016c7c <trace+0x1c>
 1016d8d:	cmpq   $0x0,0x20(%r15)
 1016d92:	je     1016c7c <trace+0x1c>
 1016d98:	lea    0x10(%r15),%rcx
 1016d9c:	lea    0x48(%r15),%rdx
 1016da0:	cmp    $0x2,%eax
 1016da3:	cmove  %rdx,%rcx
 1016da7:	mov    (%rcx),%r12
 1016daa:	xor    %r13d,%r13d
 1016dad:	nopl   (%rax)
 1016db0:	mov    0x8(%r12),%rsi
 1016db5:	mov    0x28(%r15),%rdx
 1016db9:	imul   %r13,%rdx
 1016dbd:	add    %rbx,%rdx
 1016dc0:	mov    %r14,%rdi
 1016dc3:	call   1016c60 <trace>
 1016dc8:	inc    %r13
 1016dcb:	cmp    0x20(%r15),%r13
 1016dcf:	jb     1016db0 <trace+0x150>
 1016dd1:	jmp    1016c7c <trace+0x1c>
 1016dd6:	mov    0x68(%r15),%r13
 1016dda:	test   %r13,%r13
 1016ddd:	je     1016c7c <trace+0x1c>
 1016de3:	add    $0x8,%r12
 1016de7:	mov    $0xffffffff,%r15d
 1016ded:	jmp    1016e0e <trace+0x1ae>
 1016def:	nop
 1016df0:	mov    -0x8(%r12),%eax
 1016df5:	mov    (%rbx,%rax,1),%rsi
 1016df9:	mov    %r14,%rdi
 1016dfc:	call   1016eb0 <mark>
 1016e01:	add    $0xc,%r12
 1016e05:	dec    %r13
 1016e08:	je     1016c7c <trace+0x1c>
 1016e0e:	mov    -0x4(%r12),%eax
 1016e13:	cmp    %r15,%rax
 1016e16:	je     1016df0 <trace+0x190>
 1016e18:	mov    (%rbx,%rax,1),%eax
 1016e1b:	cmp    (%r12),%eax
 1016e1f:	je     1016df0 <trace+0x190>
 1016e21:	jmp    1016e01 <trace+0x1a1>
 1016e23:	lea    0x10(%r15),%rdx
 1016e27:	lea    0x48(%r15),%rsi
 1016e2b:	lea    0x18(%r15),%rdi
 1016e2f:	lea    0x50(%r15),%r8
 1016e33:	cmp    $0x2,%eax
 1016e36:	cmove  %rsi,%rdx
 1016e3a:	cmovne %rdi,%r8
 1016e3e:	mov    (%r8),%r12
 1016e41:	movl   $0x0,-0x2c(%rbp)
 1016e48:	cmp    $0x4,%ecx
 1016e4b:	jne    1016e52 <trace+0x1f2>
 1016e4d:	mov    (%rbx),%eax
 1016e4f:	mov    %eax,-0x2c(%rbp)
 1016e52:	test   %r12,%r12
 1016e55:	je     1016c7c <trace+0x1c>
 1016e5b:	mov    (%rdx),%r13
 1016e5e:	add    $0x10,%r13
 1016e62:	jmp    1016e90 <trace+0x230>
 1016e64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016e70:	mov    -0x8(%r13),%rsi
 1016e74:	mov    -0x10(%r13),%rdx
 1016e78:	add    %rbx,%rdx
 1016e7b:	mov    %r14,%rdi
 1016e7e:	call   1016c60 <trace>
 1016e83:	add    $0x18,%r13
 1016e87:	dec    %r12
 1016e8a:	je     1016c7c <trace+0x1c>
 1016e90:	cmpw   $0x2,0x30(%r15)
 1016e96:	je     1016e70 <trace+0x210>
 1016e98:	mov    -0x2c(%rbp),%eax
 1016e9b:	cmp    0x0(%r13),%eax
 1016e9f:	je     1016e70 <trace+0x210>
 1016ea1:	jmp    1016e83 <trace+0x223>
 1016ea3:	int3
 1016ea4:	int3
 1016ea5:	int3
 1016ea6:	int3
 1016ea7:	int3
 1016ea8:	int3
 1016ea9:	int3
 1016eaa:	int3
 1016eab:	int3
 1016eac:	int3
 1016ead:	int3
 1016eae:	int3
 1016eaf:	int3

0000000001016eb0 <mark>:
 1016eb0:	test   %rsi,%rsi
 1016eb3:	je     10170fc <mark+0x24c>
 1016eb9:	push   %rbp
 1016eba:	mov    %rsp,%rbp
 1016ebd:	push   %r15
 1016ebf:	push   %r14
 1016ec1:	push   %r13
 1016ec3:	push   %r12
 1016ec5:	push   %rbx
 1016ec6:	push   %rax
 1016ec7:	add    $0xfffffffffffffff0,%rsi
 1016ecb:	mov    %rsi,%rax
 1016ece:	shr    $0x15,%rax
 1016ed2:	mov    %eax,%ecx
 1016ed4:	and    $0x7f,%ecx
 1016ed7:	mov    %ecx,%edx
 1016ed9:	cmp    %rax,0x1208(%rdi,%rdx,8)
 1016ee1:	je     1016f31 <mark+0x81>
 1016ee3:	mov    0x1200(%rdi),%rdx
 1016eea:	test   %rdx,%rdx
 1016eed:	je     1016f7e <mark+0xce>
 1016ef3:	mov    0x11f8(%rdi),%r8
 1016efa:	dec    %rdx
 1016efd:	movabs $0x9e3779b97f4a7c15,%r9
 1016f07:	imul   %rax,%r9
 1016f0b:	shr    $0x20,%r9
 1016f0f:	nop
 1016f10:	and    %rdx,%r9
 1016f13:	mov    (%r8,%r9,8),%r10
 1016f17:	test   %r10,%r10
 1016f1a:	je     1016f24 <mark+0x74>
 1016f1c:	inc    %r9
 1016f1f:	cmp    %rax,%r10
 1016f22:	jne    1016f10 <mark+0x60>
 1016f24:	cmp    %rax,%r10
 1016f27:	jne    1016f7e <mark+0xce>
 1016f29:	mov    %rax,0x1208(%rdi,%rcx,8)
 1016f31:	mov    %rsi,%rbx
 1016f34:	and    $0xffffffffffff0000,%rbx
 1016f3b:	mov    %esi,%eax
 1016f3d:	shr    $0x4,%eax
 1016f40:	mov    %esi,%r14d
 1016f43:	shr    $0xa,%r14d
 1016f47:	and    $0x3f,%r14d
 1016f4b:	mov    $0x1,%ecx
 1016f50:	shlx   %rax,%rcx,%r15
 1016f55:	mov    0x48(%rbx,%r14,8),%rcx
 1016f5a:	bt     %rax,%rcx
 1016f5e:	jae    1017001 <mark+0x151>
 1016f64:	test   %r15,0x248(%rbx,%r14,8)
 1016f6c:	je     10170ee <mark+0x23e>
 1016f72:	movb   $0x1,0x1175(%rdi)
 1016f79:	jmp    10170ee <mark+0x23e>
 1016f7e:	mov    (%rsi),%rbx
 1016f81:	movabs $0x4000000000000003,%rax
 1016f8b:	test   %rax,%rbx
 1016f8e:	jne    10170ee <mark+0x23e>
 1016f94:	mov    0x4e8(%rdi),%rcx
 1016f9b:	cmp    0x4f0(%rdi),%rcx
 1016fa2:	jne    10170ba <mark+0x20a>
 1016fa8:	lea    (%rcx,%rcx,1),%rax
 1016fac:	test   %rcx,%rcx
 1016faf:	mov    $0x400,%r14d
 1016fb5:	cmovne %rax,%r14
 1016fb9:	cmp    %rcx,%r14
 1016fbc:	jbe    1017065 <mark+0x1b5>
 1016fc2:	mov    0x8(%rdi),%rax
 1016fc6:	lea    0x0(,%r14,8),%rcx
 1016fce:	mov    %rdi,%r15
 1016fd1:	mov    %rax,%rdi
 1016fd4:	mov    %rsi,%r12
 1016fd7:	mov    %rcx,%rsi
 1016fda:	call   10277f0 <realloc@plt>
 1016fdf:	mov    %r15,%rdi
 1016fe2:	test   %rax,%rax
 1016fe5:	je     1017065 <mark+0x1b5>
 1016fe7:	mov    %r12,%rsi
 1016fea:	mov    %rax,0x8(%rdi)
 1016fee:	mov    %r14,0x4f0(%rdi)
 1016ff5:	mov    0x4e8(%rdi),%rcx
 1016ffc:	jmp    10170be <mark+0x20e>
 1017001:	mov    0x4e8(%rdi),%rcx
 1017008:	cmp    0x4f0(%rdi),%rcx
 101700f:	jne    1017071 <mark+0x1c1>
 1017011:	lea    (%rcx,%rcx,1),%rax
 1017015:	test   %rcx,%rcx
 1017018:	mov    $0x400,%r12d
 101701e:	cmovne %rax,%r12
 1017022:	cmp    %rcx,%r12
 1017025:	jbe    1017065 <mark+0x1b5>
 1017027:	mov    0x8(%rdi),%rax
 101702b:	lea    0x0(,%r12,8),%rcx
 1017033:	mov    %rdi,-0x30(%rbp)
 1017037:	mov    %rax,%rdi
 101703a:	mov    %rsi,%r13
 101703d:	mov    %rcx,%rsi
 1017040:	call   10277f0 <realloc@plt>
 1017045:	mov    -0x30(%rbp),%rdi
 1017049:	test   %rax,%rax
 101704c:	je     1017065 <mark+0x1b5>
 101704e:	mov    %r13,%rsi
 1017051:	mov    %rax,0x8(%rdi)
 1017055:	mov    %r12,0x4f0(%rdi)
 101705c:	mov    0x4e8(%rdi),%rcx
 1017063:	jmp    1017075 <mark+0x1c5>
 1017065:	movl   $0x1,0x4f8(%rdi)
 101706f:	jmp    10170ee <mark+0x23e>
 1017071:	mov    0x8(%rdi),%rax
 1017075:	lea    0x1(%rcx),%rdx
 1017079:	mov    %rdx,0x4e8(%rdi)
 1017080:	mov    %rsi,(%rax,%rcx,8)
 1017084:	or     %r15,0x48(%rbx,%r14,8)
 1017089:	movzbl 0x1174(%rdi),%eax
 1017090:	test   %eax,%eax
 1017092:	je     10170eb <mark+0x23b>
 1017094:	cmp    $0x1,%eax
 1017097:	jne    10170d6 <mark+0x226>
 1017099:	mov    0x248(%rbx,%r14,8),%rax
 10170a1:	test   %r15,%rax
 10170a4:	jne    10170de <mark+0x22e>
 10170a6:	or     %r15,%rax
 10170a9:	mov    %rax,0x248(%rbx,%r14,8)
 10170b1:	movb   $0x1,0x1175(%rdi)
 10170b8:	jmp    10170ee <mark+0x23e>
 10170ba:	mov    0x8(%rdi),%rax
 10170be:	lea    0x1(%rcx),%rdx
 10170c2:	mov    %rdx,0x4e8(%rdi)
 10170c9:	mov    %rsi,(%rax,%rcx,8)
 10170cd:	or     $0x1,%rbx
 10170d1:	mov    %rbx,(%rsi)
 10170d4:	jmp    10170ee <mark+0x23e>
 10170d6:	mov    0x248(%rbx,%r14,8),%rax
 10170de:	andn   %rax,%r15,%rax
 10170e3:	mov    %rax,0x248(%rbx,%r14,8)
 10170eb:	orb    $0x1,(%rsi)
 10170ee:	add    $0x8,%rsp
 10170f2:	pop    %rbx
 10170f3:	pop    %r12
 10170f5:	pop    %r13
 10170f7:	pop    %r14
 10170f9:	pop    %r15
 10170fb:	pop    %rbp
 10170fc:	ret
 10170fd:	int3
 10170fe:	int3
 10170ff:	int3

0000000001017100 <flatten>:
 1017100:	mov    0x58(%rsi),%r9d
 1017104:	cmp    $0x1,%r9d
 1017108:	jne    1017110 <flatten+0x10>
 101710a:	mov    $0x1,%eax
 101710f:	ret
 1017110:	mov    $0xffffffff,%r10d
 1017116:	sub    (%rsi),%r10
 1017119:	xor    %eax,%eax
 101711b:	cmp    %r10,%rdx
 101711e:	jbe    1017121 <flatten+0x21>
 1017120:	ret
 1017121:	push   %rbp
 1017122:	mov    %rsp,%rbp
 1017125:	push   %r15
 1017127:	push   %r14
 1017129:	push   %r13
 101712b:	push   %r12
 101712d:	push   %rbx
 101712e:	sub    $0x28,%rsp
 1017132:	mov    %rcx,%r15
 1017135:	shr    $0x20,%r15
 1017139:	movzwl 0x30(%rsi),%r10d
 101713e:	cmp    $0x6,%r10d
 1017142:	ja     101718a <flatten+0x8a>
 1017144:	mov    $0x62,%r11d
 101714a:	bt     %r10d,%r11d
 101714e:	jae    101718a <flatten+0x8a>
 1017150:	mov    0x10(%rdi),%rcx
 1017154:	cmp    0x8(%rdi),%rcx
 1017158:	je     101717b <flatten+0x7b>
 101715a:	mov    (%rdi),%rax
 101715d:	lea    0x1(%rcx),%rsi
 1017161:	mov    %rsi,0x10(%rdi)
 1017165:	lea    (%rcx,%rcx,2),%rcx
 1017169:	mov    %edx,(%rax,%rcx,4)
 101716c:	mov    %r15d,0x4(%rax,%rcx,4)
 1017171:	mov    %r8d,0x8(%rax,%rcx,4)
 1017176:	mov    $0x1,%eax
 101717b:	add    $0x28,%rsp
 101717f:	pop    %rbx
 1017180:	pop    %r12
 1017182:	pop    %r13
 1017184:	pop    %r14
 1017186:	pop    %r15
 1017188:	pop    %rbp
 1017189:	ret
 101718a:	lea    0x10(%rsi),%r11
 101718e:	lea    0x48(%rsi),%rbx
 1017192:	cmp    $0x2,%r9d
 1017196:	cmove  %rbx,%r11
 101719a:	mov    (%r11),%rbx
 101719d:	cmp    $0x2,%r10d
 10171a1:	mov    %r8d,-0x2c(%rbp)
 10171a5:	mov    %rdx,-0x40(%rbp)
 10171a9:	mov    %rdi,%r13
 10171ac:	mov    %rcx,%r14
 10171af:	mov    %rsi,-0x38(%rbp)
 10171b3:	je     101720d <flatten+0x10d>
 10171b5:	cmp    $0x4,%r10d
 10171b9:	je     101720d <flatten+0x10d>
 10171bb:	cmp    $0x3,%r10d
 10171bf:	jne    1017176 <flatten+0x76>
 10171c1:	cmpq   $0x0,0x20(%rsi)
 10171c6:	je     1017176 <flatten+0x76>
 10171c8:	xor    %r15d,%r15d
 10171cb:	mov    0x8(%rbx),%rax
 10171cf:	mov    0x28(%rsi),%r9
 10171d3:	imul   %r15,%r9
 10171d7:	add    %rdx,%r9
 10171da:	mov    %rax,%rsi
 10171dd:	mov    %r9,%rdx
 10171e0:	call   1017100 <flatten>
 10171e5:	test   %eax,%eax
 10171e7:	je     10172a4 <flatten+0x1a4>
 10171ed:	inc    %r15
 10171f0:	mov    -0x38(%rbp),%rsi
 10171f4:	cmp    0x20(%rsi),%r15
 10171f8:	mov    -0x2c(%rbp),%r8d
 10171fc:	mov    -0x40(%rbp),%rdx
 1017200:	mov    %r13,%rdi
 1017203:	mov    %r14,%rcx
 1017206:	jb     10171cb <flatten+0xcb>
 1017208:	jmp    1017176 <flatten+0x76>
 101720d:	lea    0x18(%rsi),%r11
 1017211:	lea    0x50(%rsi),%r12
 1017215:	cmp    $0x2,%r9d
 1017219:	cmove  %r12,%r11
 101721d:	cmp    $0x4,%r10d
 1017221:	sete   %r9b
 1017225:	mov    $0xffffffff,%r10d
 101722b:	cmp    %r10,%r15
 101722e:	setne  %r10b
 1017232:	test   %r10b,%r9b
 1017235:	jne    101717b <flatten+0x7b>
 101723b:	mov    (%r11),%r12
 101723e:	test   %r12,%r12
 1017241:	je     1017176 <flatten+0x76>
 1017247:	mov    %edx,%eax
 1017249:	mov    %rax,-0x48(%rbp)
 101724d:	add    $0x10,%rbx
 1017251:	cmpw   $0x4,0x30(%rsi)
 1017256:	mov    %r15,%r9
 1017259:	jne    1017264 <flatten+0x164>
 101725b:	mov    (%rbx),%r8d
 101725e:	xor    %ecx,%ecx
 1017260:	mov    -0x48(%rbp),%r9
 1017264:	mov    -0x8(%rbx),%rsi
 1017268:	mov    -0x10(%rbx),%rax
 101726c:	add    %rdx,%rax
 101726f:	shl    $0x20,%r9
 1017273:	mov    %ecx,%ecx
 1017275:	or     %r9,%rcx
 1017278:	mov    %rax,%rdx
 101727b:	call   1017100 <flatten>
 1017280:	test   %eax,%eax
 1017282:	je     10172a4 <flatten+0x1a4>
 1017284:	add    $0x18,%rbx
 1017288:	dec    %r12
 101728b:	mov    -0x2c(%rbp),%r8d
 101728f:	mov    -0x40(%rbp),%rdx
 1017293:	mov    %r13,%rdi
 1017296:	mov    %r14,%rcx
 1017299:	mov    -0x38(%rbp),%rsi
 101729d:	jne    1017251 <flatten+0x151>
 101729f:	jmp    1017176 <flatten+0x76>
 10172a4:	xor    %eax,%eax
 10172a6:	jmp    101717b <flatten+0x7b>
 10172ab:	int3
 10172ac:	int3
 10172ad:	int3
 10172ae:	int3
 10172af:	int3

00000000010172b0 <myl_native_arena_reclaim>:
 10172b0:	push   %rbp
 10172b1:	mov    %rsp,%rbp
 10172b4:	push   %rbx
 10172b5:	push   %rax
 10172b6:	mov    %rdi,%rbx
 10172b9:	mov    0x4e0(%rdi),%rdi
 10172c0:	jmp    10172dc <myl_native_arena_reclaim+0x2c>
 10172c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10172d0:	call   10276f0 <free@plt>
 10172d5:	mov    0x4e0(%rbx),%rdi
 10172dc:	test   %rdi,%rdi
 10172df:	je     10172ff <myl_native_arena_reclaim+0x4f>
 10172e1:	mov    (%rdi),%rax
 10172e4:	mov    %rax,0x4e0(%rbx)
 10172eb:	cmpq   $0x0,0x1608(%rbx)
 10172f3:	je     10172d0 <myl_native_arena_reclaim+0x20>
 10172f5:	mov    0x8(%rdi),%rax
 10172f9:	sub    %rax,0x18(%rbx)
 10172fd:	jmp    10172d0 <myl_native_arena_reclaim+0x20>
 10172ff:	vxorps %xmm0,%xmm0,%xmm0
 1017303:	vmovups %xmm0,0xc0(%rbx)
 101730b:	add    $0x8,%rsp
 101730f:	pop    %rbx
 1017310:	pop    %rbp
 1017311:	ret
 1017312:	int3
 1017313:	int3
 1017314:	int3
 1017315:	int3
 1017316:	int3
 1017317:	int3
 1017318:	int3
 1017319:	int3
 101731a:	int3
 101731b:	int3
 101731c:	int3
 101731d:	int3
 101731e:	int3
 101731f:	int3

0000000001017320 <myl_native_arena_release>:
 1017320:	push   %rbp
 1017321:	mov    %rsp,%rbp
 1017324:	push   %r15
 1017326:	push   %r14
 1017328:	push   %r13
 101732a:	push   %r12
 101732c:	push   %rbx
 101732d:	sub    $0x18,%rsp
 1017331:	mov    %rdi,%rbx
 1017334:	mov    0x11a0(%rdi),%rax
 101733b:	test   %rax,%rax
 101733e:	je     1017369 <myl_native_arena_release+0x49>
 1017340:	mov    0x5c0(%rbx),%rcx
 1017347:	sub    %rax,%rcx
 101734a:	add    $0xffffffffffffffb0,%rcx
 101734e:	mov    %rcx,0x10(%rax)
 1017352:	movq   $0x0,0x11a0(%rbx)
 101735d:	vpxor  %xmm0,%xmm0,%xmm0
 1017361:	vmovdqu %xmm0,0x5c0(%rbx)
 1017369:	cmpq   $0x0,0x1608(%rbx)
 1017371:	mov    0x11e8(%rbx),%rdx
 1017378:	je     10173a8 <myl_native_arena_release+0x88>
 101737a:	test   %rdx,%rdx
 101737d:	je     10174e9 <myl_native_arena_release+0x1c9>
 1017383:	mov    0x4d8(%rbx),%rax
 101738a:	test   $0x1,%dl
 101738d:	jne    10174f1 <myl_native_arena_release+0x1d1>
 1017393:	xor    %r14d,%r14d
 1017396:	mov    %rdx,%rcx
 1017399:	cmp    $0x1,%rdx
 101739d:	jne    1017549 <myl_native_arena_release+0x229>
 10173a3:	jmp    10175c5 <myl_native_arena_release+0x2a5>
 10173a8:	test   %rdx,%rdx
 10173ab:	je     10178a4 <myl_native_arena_release+0x584>
 10173b1:	mov    $0x200000,%r14d
 10173b7:	jmp    10173d0 <myl_native_arena_release+0xb0>
 10173b9:	nopl   0x0(%rax)
 10173c0:	mov    0x11e8(%rbx),%rdx
 10173c7:	test   %rdx,%rdx
 10173ca:	je     10178a4 <myl_native_arena_release+0x584>
 10173d0:	lea    -0x1(%rdx),%rax
 10173d4:	mov    %rax,0x11e8(%rbx)
 10173db:	mov    0x4d8(%rbx),%rcx
 10173e2:	mov    -0x8(%rcx,%rdx,8),%rdi
 10173e7:	movq   $0x0,-0x8(%rcx,%rdx,8)
 10173f0:	mov    %rax,%rdx
 10173f3:	test   %rdi,%rdi
 10173f6:	jne    101740d <myl_native_arena_release+0xed>
 10173f8:	jmp    10173c7 <myl_native_arena_release+0xa7>
 10173fa:	nopw   0x0(%rax,%rax,1)
 1017400:	call   10276f0 <free@plt>
 1017405:	mov    %r15,%rdi
 1017408:	test   %r15,%r15
 101740b:	je     10173c0 <myl_native_arena_release+0xa0>
 101740d:	mov    (%rdi),%r15
 1017410:	mov    0x8(%rdi),%rax
 1017414:	sub    %rax,0x18(%rbx)
 1017418:	mov    0x18(%rdi),%rax
 101741c:	sub    %rax,0x40(%rbx)
 1017420:	mov    0x18(%rdi),%rax
 1017424:	add    %rax,0x80(%rbx)
 101742b:	vmovdqu 0xa8(%rbx),%xmm0
 1017433:	vmovdqa -0x15b5b(%rip),%xmm1        # 10018e0 <__abi_tag+0x15e4>
 101743b:	vpinsrq $0x1,0x8(%rdi),%xmm1,%xmm1
 1017442:	vpsubq %xmm1,%xmm0,%xmm0
 1017446:	vmovdqu %xmm0,0xa8(%rbx)
 101744e:	mov    0x58(%rbx),%rax
 1017452:	cmp    $0x200000,%rax
 1017458:	mov    $0x200000,%ecx
 101745d:	cmovb  %rax,%rcx
 1017461:	test   %rax,%rax
 1017464:	mov    %rcx,%rax
 1017467:	cmove  %r14,%rax
 101746b:	cmpq   $0x0,0x1608(%rbx)
 1017473:	cmove  %rcx,%rax
 1017477:	mov    0x8(%rdi),%rsi
 101747b:	cmp    $0x100000,%rsi
 1017482:	ja     1017400 <myl_native_arena_release+0xe0>
 1017488:	mov    0xc0(%rbx),%rcx
 101748f:	cmp    $0x3,%rcx
 1017493:	ja     1017400 <myl_native_arena_release+0xe0>
 1017499:	mov    0xc8(%rbx),%rdx
 10174a0:	sub    %rdx,%rax
 10174a3:	jbe    1017400 <myl_native_arena_release+0xe0>
 10174a9:	cmp    %rax,%rsi
 10174ac:	ja     1017400 <myl_native_arena_release+0xe0>
 10174b2:	mov    0x4e0(%rbx),%rax
 10174b9:	mov    %rax,(%rdi)
 10174bc:	mov    %rdi,0x4e0(%rbx)
 10174c3:	inc    %rcx
 10174c6:	mov    %rcx,0xc0(%rbx)
 10174cd:	add    0x8(%rdi),%rdx
 10174d1:	mov    %rdx,0xc8(%rbx)
 10174d8:	mov    %r15,%rdi
 10174db:	test   %r15,%r15
 10174de:	jne    101740d <myl_native_arena_release+0xed>
 10174e4:	jmp    10173c0 <myl_native_arena_release+0xa0>
 10174e9:	xor    %r14d,%r14d
 10174ec:	jmp    10175cc <myl_native_arena_release+0x2ac>
 10174f1:	lea    -0x1(%rdx),%rcx
 10174f5:	mov    -0x8(%rax,%rdx,8),%rsi
 10174fa:	movq   $0x0,-0x8(%rax,%rdx,8)
 1017503:	test   %rsi,%rsi
 1017506:	je     101752c <myl_native_arena_release+0x20c>
 1017508:	xor    %edi,%edi
 101750a:	nopw   0x0(%rax,%rax,1)
 1017510:	mov    %rsi,%r14
 1017513:	mov    (%rsi),%rsi
 1017516:	mov    %rdi,(%r14)
 1017519:	mov    %r14,%rdi
 101751c:	test   %rsi,%rsi
 101751f:	jne    1017510 <myl_native_arena_release+0x1f0>
 1017521:	cmp    $0x1,%rdx
 1017525:	jne    1017549 <myl_native_arena_release+0x229>
 1017527:	jmp    10175c5 <myl_native_arena_release+0x2a5>
 101752c:	xor    %r14d,%r14d
 101752f:	cmp    $0x1,%rdx
 1017533:	jne    1017549 <myl_native_arena_release+0x229>
 1017535:	jmp    10175c5 <myl_native_arena_release+0x2a5>
 101753a:	nopw   0x0(%rax,%rax,1)
 1017540:	mov    %rdx,%r14
 1017543:	add    $0xfffffffffffffffe,%rcx
 1017547:	je     10175c3 <myl_native_arena_release+0x2a3>
 1017549:	mov    -0x8(%rax,%rcx,8),%rsi
 101754e:	movq   $0x0,-0x8(%rax,%rcx,8)
 1017557:	test   %rsi,%rsi
 101755a:	je     1017590 <myl_native_arena_release+0x270>
 101755c:	nopl   0x0(%rax)
 1017560:	mov    (%rsi),%rdi
 1017563:	mov    %r14,(%rsi)
 1017566:	mov    %rsi,%rdx
 1017569:	mov    %rsi,%r14
 101756c:	mov    %rdi,%rsi
 101756f:	test   %rdi,%rdi
 1017572:	jne    1017560 <myl_native_arena_release+0x240>
 1017574:	mov    -0x10(%rax,%rcx,8),%rsi
 1017579:	movq   $0x0,-0x10(%rax,%rcx,8)
 1017582:	test   %rsi,%rsi
 1017585:	jne    10175b0 <myl_native_arena_release+0x290>
 1017587:	jmp    1017540 <myl_native_arena_release+0x220>
 1017589:	nopl   0x0(%rax)
 1017590:	mov    %r14,%rdx
 1017593:	mov    -0x10(%rax,%rcx,8),%rsi
 1017598:	movq   $0x0,-0x10(%rax,%rcx,8)
 10175a1:	test   %rsi,%rsi
 10175a4:	je     1017540 <myl_native_arena_release+0x220>
 10175a6:	cs nopw 0x0(%rax,%rax,1)
 10175b0:	mov    %rsi,%r14
 10175b3:	mov    (%rsi),%rsi
 10175b6:	mov    %rdx,(%r14)
 10175b9:	mov    %r14,%rdx
 10175bc:	test   %rsi,%rsi
 10175bf:	jne    10175b0 <myl_native_arena_release+0x290>
 10175c1:	jmp    1017543 <myl_native_arena_release+0x223>
 10175c3:	xor    %ecx,%ecx
 10175c5:	mov    %rcx,0x11e8(%rbx)
 10175cc:	mov    0x70(%rbx),%eax
 10175cf:	mov    %eax,-0x34(%rbp)
 10175d2:	movl   $0x0,0x70(%rbx)
 10175d9:	mov    %rbx,%rdi
 10175dc:	xor    %esi,%esi
 10175de:	call   101e520 <myl_rc_scope_unwind>
 10175e3:	mov    %r14,-0x30(%rbp)
 10175e7:	test   %r14,%r14
 10175ea:	je     1017793 <myl_native_arena_release+0x473>
 10175f0:	mov    $0x28,%edx
 10175f5:	mov    -0x30(%rbp),%r13
 10175f9:	jmp    101760d <myl_native_arena_release+0x2ed>
 10175fb:	nopl   0x0(%rax,%rax,1)
 1017600:	mov    0x0(%r13),%r13
 1017604:	test   %r13,%r13
 1017607:	je     10176b9 <myl_native_arena_release+0x399>
 101760d:	cmpq   $0x0,0x10(%r13)
 1017612:	je     1017600 <myl_native_arena_release+0x2e0>
 1017614:	lea    0x50(%r13),%r14
 1017618:	xor    %r12d,%r12d
 101761b:	jmp    1017631 <myl_native_arena_release+0x311>
 101761d:	nopl   (%rax)
 1017620:	add    %r15,%r12
 1017623:	add    $0x1f,%r12
 1017627:	and    $0xfffffffffffffff0,%r12
 101762b:	cmp    0x10(%r13),%r12
 101762f:	jae    1017600 <myl_native_arena_release+0x2e0>
 1017631:	mov    (%r14,%r12,1),%rax
 1017635:	mov    0x8(%r14,%r12,1),%rsi
 101763a:	bzhi   %rdx,%rax,%r15
 101763f:	shr    $0x2,%r15
 1017643:	imul   (%rsi),%r15
 1017647:	cmp    $0x1,%r15
 101764b:	adc    $0x0,%r15
 101764f:	test   $0x1,%al
 1017651:	jne    1017620 <myl_native_arena_release+0x300>
 1017653:	mov    0x1608(%rbx),%rdi
 101765a:	mov    0x34(%rsi),%eax
 101765d:	cmp    %rax,0xa0(%rdi)
 1017664:	jbe    10176aa <myl_native_arena_release+0x38a>
 1017666:	mov    0x98(%rdi),%rcx
 101766d:	shl    $0x4,%rax
 1017671:	cmp    %rsi,(%rcx,%rax,1)
 1017675:	jne    10176aa <myl_native_arena_release+0x38a>
 1017677:	add    %rax,%rcx
 101767a:	mov    0x8(%rcx),%rax
 101767e:	test   %rax,%rax
 1017681:	je     10178b3 <myl_native_arena_release+0x593>
 1017687:	lea    (%r14,%r12,1),%rsi
 101768b:	orb    $0x1,(%rsi)
 101768e:	mov    0x18(%rax),%rax
 1017692:	test   %rax,%rax
 1017695:	je     1017620 <myl_native_arena_release+0x300>
 1017697:	add    $0x10,%rsi
 101769b:	mov    %rbx,%rdi
 101769e:	call   *%rax
 10176a0:	mov    $0x28,%edx
 10176a5:	jmp    1017620 <myl_native_arena_release+0x300>
 10176aa:	call   1018f74 <myl_rc_binding_find_slow>
 10176af:	test   %rax,%rax
 10176b2:	jne    1017687 <myl_native_arena_release+0x367>
 10176b4:	jmp    10178b3 <myl_native_arena_release+0x593>
 10176b9:	mov    -0x30(%rbp),%r15
 10176bd:	jmp    10176cc <myl_native_arena_release+0x3ac>
 10176bf:	nop
 10176c0:	mov    (%r15),%r15
 10176c3:	test   %r15,%r15
 10176c6:	je     1017793 <myl_native_arena_release+0x473>
 10176cc:	cmpq   $0x0,0x10(%r15)
 10176d1:	je     10176c0 <myl_native_arena_release+0x3a0>
 10176d3:	lea    0x50(%r15),%r9
 10176d7:	xor    %r12d,%r12d
 10176da:	jmp    1017704 <myl_native_arena_release+0x3e4>
 10176dc:	nopl   0x0(%rax)
 10176e0:	mov    0x8(%rax),%rsi
 10176e4:	add    $0x10,%rdx
 10176e8:	mov    %rbx,%rdi
 10176eb:	call   101b480 <myl_rc_edges_release>
 10176f0:	add    %r13,%r12
 10176f3:	add    $0x1f,%r12
 10176f7:	and    $0xfffffffffffffff0,%r12
 10176fb:	cmp    0x10(%r15),%r12
 10176ff:	mov    %r14,%r9
 1017702:	jae    10176c0 <myl_native_arena_release+0x3a0>
 1017704:	mov    $0x28,%eax
 1017709:	bzhi   %rax,(%r9,%r12,1),%rcx
 101770f:	shr    $0x2,%rcx
 1017713:	mov    0x8(%r9,%r12,1),%rsi
 1017718:	mov    (%rsi),%r13
 101771b:	imul   %rcx,%r13
 101771f:	cmp    $0x1,%r13
 1017723:	adc    $0x0,%r13
 1017727:	mov    0x1608(%rbx),%rdi
 101772e:	mov    0x34(%rsi),%eax
 1017731:	cmp    %rax,0xa0(%rdi)
 1017738:	jbe    1017784 <myl_native_arena_release+0x464>
 101773a:	mov    0x98(%rdi),%rdx
 1017741:	shl    $0x4,%rax
 1017745:	cmp    %rsi,(%rdx,%rax,1)
 1017749:	jne    1017784 <myl_native_arena_release+0x464>
 101774b:	add    %rax,%rdx
 101774e:	mov    0x8(%rdx),%rax
 1017752:	test   %rax,%rax
 1017755:	je     10178b3 <myl_native_arena_release+0x593>
 101775b:	mov    %r9,%r14
 101775e:	lea    (%r9,%r12,1),%rdx
 1017762:	mov    0x10(%rax),%r8
 1017766:	test   %r8,%r8
 1017769:	je     10176e0 <myl_native_arena_release+0x3c0>
 101776f:	add    $0x10,%rdx
 1017773:	mov    %rbx,%rdi
 1017776:	mov    %rdx,%rsi
 1017779:	mov    %rcx,%rdx
 101777c:	call   *%r8
 101777f:	jmp    10176f0 <myl_native_arena_release+0x3d0>
 1017784:	call   1018f74 <myl_rc_binding_find_slow>
 1017789:	test   %rax,%rax
 101778c:	jne    101775b <myl_native_arena_release+0x43b>
 101778e:	jmp    10178b3 <myl_native_arena_release+0x593>
 1017793:	mov    %rbx,%rdi
 1017796:	call   101be30 <myl_rc_drain>
 101779b:	cmpl   $0x0,0x70(%rbx)
 101779f:	jne    10178b3 <myl_native_arena_release+0x593>
 10177a5:	mov    -0x34(%rbp),%eax
 10177a8:	mov    %eax,0x70(%rbx)
 10177ab:	mov    -0x30(%rbp),%rdi
 10177af:	test   %rdi,%rdi
 10177b2:	je     10178a4 <myl_native_arena_release+0x584>
 10177b8:	mov    $0x200000,%r15d
 10177be:	jmp    10177d5 <myl_native_arena_release+0x4b5>
 10177c0:	sub    %rcx,0x18(%rbx)
 10177c4:	call   10276f0 <free@plt>
 10177c9:	mov    %r12,%rdi
 10177cc:	test   %r12,%r12
 10177cf:	je     10178a4 <myl_native_arena_release+0x584>
 10177d5:	mov    (%rdi),%r12
 10177d8:	mov    0x18(%rdi),%rax
 10177dc:	sub    %rax,0x40(%rbx)
 10177e0:	mov    0x18(%rdi),%rax
 10177e4:	add    %rax,0x80(%rbx)
 10177eb:	vmovdqu 0xa8(%rbx),%xmm0
 10177f3:	vmovdqa -0x15f1b(%rip),%xmm1        # 10018e0 <__abi_tag+0x15e4>
 10177fb:	vpinsrq $0x1,0x8(%rdi),%xmm1,%xmm1
 1017802:	vpsubq %xmm1,%xmm0,%xmm0
 1017806:	vmovdqu %xmm0,0xa8(%rbx)
 101780e:	mov    0x58(%rbx),%rax
 1017812:	cmp    $0x200000,%rax
 1017818:	mov    $0x200000,%ecx
 101781d:	cmovb  %rax,%rcx
 1017821:	test   %rax,%rax
 1017824:	mov    %rcx,%rax
 1017827:	cmove  %r15,%rax
 101782b:	cmpq   $0x0,0x1608(%rbx)
 1017833:	cmove  %rcx,%rax
 1017837:	mov    0x8(%rdi),%rcx
 101783b:	cmp    $0x100000,%rcx
 1017842:	ja     10177c0 <myl_native_arena_release+0x4a0>
 1017848:	mov    0xc0(%rbx),%rdx
 101784f:	cmp    $0x3,%rdx
 1017853:	ja     10177c0 <myl_native_arena_release+0x4a0>
 1017859:	mov    0xc8(%rbx),%rsi
 1017860:	sub    %rsi,%rax
 1017863:	jbe    10177c0 <myl_native_arena_release+0x4a0>
 1017869:	cmp    %rax,%rcx
 101786c:	ja     10177c0 <myl_native_arena_release+0x4a0>
 1017872:	mov    0x4e0(%rbx),%rax
 1017879:	mov    %rax,(%rdi)
 101787c:	mov    %rdi,0x4e0(%rbx)
 1017883:	inc    %rdx
 1017886:	mov    %rdx,0xc0(%rbx)
 101788d:	add    0x8(%rdi),%rsi
 1017891:	mov    %rsi,0xc8(%rbx)
 1017898:	mov    %r12,%rdi
 101789b:	test   %r12,%r12
 101789e:	jne    10177d5 <myl_native_arena_release+0x4b5>
 10178a4:	add    $0x18,%rsp
 10178a8:	pop    %rbx
 10178a9:	pop    %r12
 10178ab:	pop    %r13
 10178ad:	pop    %r14
 10178af:	pop    %r15
 10178b1:	pop    %rbp
 10178b2:	ret
 10178b3:	call   1018954 <myl_rc_invariant_failed>
 10178b8:	int3
 10178b9:	int3
 10178ba:	int3
 10178bb:	int3
 10178bc:	int3
 10178bd:	int3
 10178be:	int3
 10178bf:	int3

00000000010178c0 <rc_list_new>:
 10178c0:	push   %rbp
 10178c1:	mov    %rsp,%rbp
 10178c4:	push   %r15
 10178c6:	push   %r14
 10178c8:	push   %r13
 10178ca:	push   %r12
 10178cc:	push   %rbx
 10178cd:	push   %rax
 10178ce:	mov    %ecx,%r15d
 10178d1:	mov    %rdx,%r14
 10178d4:	mov    %rsi,%r12
 10178d7:	mov    %rdi,%rbx
 10178da:	mov    0x1608(%rdi),%rax
 10178e1:	cmp    %rsi,0x110(%rax)
 10178e8:	je     1017905 <rc_list_new+0x45>
 10178ea:	mov    %rbx,%rdi
 10178ed:	mov    %r12,%rsi
 10178f0:	call   10234b0 <myl_rc_native_shape>
 10178f5:	test   %rax,%rax
 10178f8:	je     10179bc <rc_list_new+0xfc>
 10178fe:	mov    0x1608(%rbx),%rax
 1017905:	cmpb   $0x0,0x120(%rax)
 101790c:	je     1017956 <rc_list_new+0x96>
 101790e:	mov    $0x100b618,%esi
 1017913:	mov    $0x1,%edx
 1017918:	mov    %rbx,%rdi
 101791b:	mov    %r15d,%ecx
 101791e:	call   1020fa0 <myl_rc_storage_alloc>
 1017923:	test   %rax,%rax
 1017926:	je     10179bc <rc_list_new+0xfc>
 101792c:	mov    %r12,0x18(%rax)
 1017930:	test   %r14,%r14
 1017933:	je     10179ab <rc_list_new+0xeb>
 1017935:	mov    %rax,%r13
 1017938:	mov    (%r12),%rsi
 101793c:	test   %rsi,%rsi
 101793f:	je     1017988 <rc_list_new+0xc8>
 1017941:	mov    %rsi,%rax
 1017944:	mul    %r14
 1017947:	jno    1017988 <rc_list_new+0xc8>
 1017949:	mov    %r13,%rax
 101794c:	movq   $0x0,0x20(%r13)
 1017954:	jmp    10179b1 <rc_list_new+0xf1>
 1017956:	mov    $0x100b3e0,%esi
 101795b:	mov    %rbx,%rdi
 101795e:	call   1019700 <myl_rc_module_register>
 1017963:	mov    0x1608(%rbx),%rcx
 101796a:	test   %eax,%eax
 101796c:	je     10179cd <rc_list_new+0x10d>
 101796e:	test   %rcx,%rcx
 1017971:	je     10179d9 <rc_list_new+0x119>
 1017973:	cmpl   $0x0,0x124(%rcx)
 101797a:	jne    10179bc <rc_list_new+0xfc>
 101797c:	movl   $0x1,0x124(%rcx)
 1017986:	jmp    10179bc <rc_list_new+0xfc>
 1017988:	imul   %r14,%rsi
 101798c:	mov    %rbx,%rdi
 101798f:	mov    %r15d,%edx
 1017992:	mov    $0x1,%ecx
 1017997:	call   1022f70 <raw_bytes>
 101799c:	mov    %rax,%rcx
 101799f:	mov    %r13,%rax
 10179a2:	mov    %rcx,0x20(%r13)
 10179a6:	test   %rcx,%rcx
 10179a9:	je     10179b1 <rc_list_new+0xf1>
 10179ab:	mov    %r14,0x8(%rax)
 10179af:	jmp    10179be <rc_list_new+0xfe>
 10179b1:	mov    %rbx,%rdi
 10179b4:	mov    %rax,%rsi
 10179b7:	call   101ccd0 <myl_rc_construction_abort>
 10179bc:	xor    %eax,%eax
 10179be:	add    $0x8,%rsp
 10179c2:	pop    %rbx
 10179c3:	pop    %r12
 10179c5:	pop    %r13
 10179c7:	pop    %r14
 10179c9:	pop    %r15
 10179cb:	pop    %rbp
 10179cc:	ret
 10179cd:	movb   $0x1,0x120(%rcx)
 10179d4:	jmp    101790e <rc_list_new+0x4e>
 10179d9:	call   1018954 <myl_rc_invariant_failed>
 10179de:	int3
 10179df:	int3

00000000010179e0 <rc_list_edges>:
 10179e0:	push   %rbp
 10179e1:	mov    %rsp,%rbp
 10179e4:	push   %r14
 10179e6:	push   %rbx
 10179e7:	cmpq   $0x0,(%rsi)
 10179eb:	je     1017ad9 <rc_list_edges+0xf9>
 10179f1:	mov    0x18(%rsi),%rcx
 10179f5:	mov    0x1608(%rdi),%rax
 10179fc:	cmp    %rcx,0x110(%rax)
 1017a03:	je     1017ad9 <rc_list_edges+0xf9>
 1017a09:	mov    0x34(%rcx),%edx
 1017a0c:	cmp    %rdx,0xa0(%rax)
 1017a13:	jbe    1017af6 <rc_list_edges+0x116>
 1017a19:	mov    0x98(%rax),%r8
 1017a20:	shl    $0x4,%rdx
 1017a24:	cmp    %rcx,(%r8,%rdx,1)
 1017a28:	jne    1017af6 <rc_list_edges+0x116>
 1017a2e:	add    %rdx,%r8
 1017a31:	mov    0x8(%r8),%rax
 1017a35:	test   %rax,%rax
 1017a38:	je     1017a4a <rc_list_edges+0x6a>
 1017a3a:	cmpl   $0x0,0x40(%rax)
 1017a3e:	jne    1017a4a <rc_list_edges+0x6a>
 1017a40:	cmpb   $0x0,0x45(%rax)
 1017a44:	je     1017ae6 <rc_list_edges+0x106>
 1017a4a:	mov    (%rsi),%rcx
 1017a4d:	mov    0x18(%rsi),%rax
 1017a51:	mov    0x20(%rsi),%rdx
 1017a55:	mov    0x1608(%rdi),%r8
 1017a5c:	mov    0x34(%rax),%r9d
 1017a60:	cmp    %r9,0xa0(%r8)
 1017a67:	jbe    1017b1b <rc_list_edges+0x13b>
 1017a6d:	mov    0x98(%r8),%r10
 1017a74:	shl    $0x4,%r9
 1017a78:	cmp    %rax,(%r10,%r9,1)
 1017a7c:	jne    1017b1b <rc_list_edges+0x13b>
 1017a82:	add    %r9,%r10
 1017a85:	mov    0x8(%r10),%rax
 1017a89:	test   %rax,%rax
 1017a8c:	je     1017b3b <rc_list_edges+0x15b>
 1017a92:	mov    0x40(%rax),%r8d
 1017a96:	test   %r8d,%r8d
 1017a99:	je     1017aaa <rc_list_edges+0xca>
 1017a9b:	cmp    $0x11,%r8d
 1017a9f:	jb     1017ab0 <rc_list_edges+0xd0>
 1017aa1:	mov    %rsi,%r14
 1017aa4:	mov    0x8(%rax),%rsi
 1017aa8:	jmp    1017acb <rc_list_edges+0xeb>
 1017aaa:	cmpb   $0x0,0x45(%rax)
 1017aae:	je     1017ad9 <rc_list_edges+0xf9>
 1017ab0:	mov    %rsi,%r14
 1017ab3:	mov    0x8(%rax),%rsi
 1017ab7:	cmpq   $0x3,0x28(%rsi)
 1017abc:	jb     1017acb <rc_list_edges+0xeb>
 1017abe:	mov    %rdi,%rbx
 1017ac1:	mov    %rax,%rsi
 1017ac4:	call   101bbf0 <myl_rc_flat_edges_release>
 1017ac9:	jmp    1017ad3 <rc_list_edges+0xf3>
 1017acb:	mov    %rdi,%rbx
 1017ace:	call   101b480 <myl_rc_edges_release>
 1017ad3:	mov    %rbx,%rdi
 1017ad6:	mov    %r14,%rsi
 1017ad9:	mov    0x20(%rsi),%rsi
 1017add:	pop    %rbx
 1017ade:	pop    %r14
 1017ae0:	pop    %rbp
 1017ae1:	jmp    1018d40 <myl_rc_edge_release>
 1017ae6:	mov    0x1608(%rdi),%rax
 1017aed:	mov    %rcx,0x110(%rax)
 1017af4:	jmp    1017ad9 <rc_list_edges+0xf9>
 1017af6:	mov    %rdi,%rdx
 1017af9:	mov    %rax,%rdi
 1017afc:	mov    %rsi,%r8
 1017aff:	mov    %rcx,%rsi
 1017b02:	call   1018f74 <myl_rc_binding_find_slow>
 1017b07:	mov    %r8,%rsi
 1017b0a:	mov    %rdx,%rdi
 1017b0d:	test   %rax,%rax
 1017b10:	jne    1017a3a <rc_list_edges+0x5a>
 1017b16:	jmp    1017a4a <rc_list_edges+0x6a>
 1017b1b:	mov    %rdi,%r9
 1017b1e:	mov    %r8,%rdi
 1017b21:	mov    %rsi,%r8
 1017b24:	mov    %rax,%rsi
 1017b27:	call   1018f74 <myl_rc_binding_find_slow>
 1017b2c:	mov    %r8,%rsi
 1017b2f:	mov    %r9,%rdi
 1017b32:	test   %rax,%rax
 1017b35:	jne    1017a92 <rc_list_edges+0xb2>
 1017b3b:	call   1027810 <abort@plt>

0000000001017b40 <rc_list_clone_adapter>:
 1017b40:	push   %rbp
 1017b41:	mov    %rsp,%rbp
 1017b44:	push   %r15
 1017b46:	push   %r14
 1017b48:	push   %r13
 1017b4a:	push   %r12
 1017b4c:	push   %rbx
 1017b4d:	push   %rax
 1017b4e:	mov    %rcx,%rbx
 1017b51:	mov    %edx,%ecx
 1017b53:	mov    %rsi,%r14
 1017b56:	mov    %rdi,%r12
 1017b59:	mov    0x18(%rsi),%r13
 1017b5d:	mov    (%rsi),%rdx
 1017b60:	mov    0x8(%rsi),%rax
 1017b64:	cmp    %rdx,%rax
 1017b67:	cmova  %rax,%rdx
 1017b6b:	mov    %r13,%rsi
 1017b6e:	call   10178c0 <rc_list_new>
 1017b73:	test   %rax,%rax
 1017b76:	je     1017c37 <rc_list_clone_adapter+0xf7>
 1017b7c:	mov    %rax,%r15
 1017b7f:	mov    %rbx,-0x30(%rbp)
 1017b83:	mov    (%r14),%rax
 1017b86:	test   %rax,%rax
 1017b89:	je     1017c95 <rc_list_clone_adapter+0x155>
 1017b8f:	mov    0x0(%r13),%rdx
 1017b93:	test   %rdx,%rdx
 1017b96:	je     1017bf5 <rc_list_clone_adapter+0xb5>
 1017b98:	mov    0x1608(%r12),%rdi
 1017ba0:	cmp    %r13,0x110(%rdi)
 1017ba7:	je     1017c7e <rc_list_clone_adapter+0x13e>
 1017bad:	mov    0x34(%r13),%eax
 1017bb1:	cmp    %rax,0xa0(%rdi)
 1017bb8:	jbe    1017cb5 <rc_list_clone_adapter+0x175>
 1017bbe:	mov    0x98(%rdi),%rcx
 1017bc5:	shl    $0x4,%rax
 1017bc9:	cmp    %r13,(%rcx,%rax,1)
 1017bcd:	jne    1017cb5 <rc_list_clone_adapter+0x175>
 1017bd3:	add    %rax,%rcx
 1017bd6:	mov    0x8(%rcx),%rax
 1017bda:	test   %rax,%rax
 1017bdd:	je     1017beb <rc_list_clone_adapter+0xab>
 1017bdf:	cmpl   $0x0,0x40(%rax)
 1017be3:	jne    1017beb <rc_list_clone_adapter+0xab>
 1017be5:	cmpb   $0x0,0x45(%rax)
 1017be9:	je     1017c68 <rc_list_clone_adapter+0x128>
 1017beb:	cmpq   $0x0,(%r14)
 1017bef:	je     1017c95 <rc_list_clone_adapter+0x155>
 1017bf5:	xor    %ebx,%ebx
 1017bf7:	nopw   0x0(%rax,%rax,1)
 1017c00:	mov    0x0(%r13),%rcx
 1017c04:	imul   %rbx,%rcx
 1017c08:	add    0x20(%r14),%rcx
 1017c0c:	mov    (%r15),%rdx
 1017c0f:	mov    %r12,%rdi
 1017c12:	mov    %r15,%rsi
 1017c15:	call   1017f20 <rc_list_insert_at>
 1017c1a:	test   %eax,%eax
 1017c1c:	je     1017c28 <rc_list_clone_adapter+0xe8>
 1017c1e:	inc    %rbx
 1017c21:	cmp    (%r14),%rbx
 1017c24:	jb     1017c00 <rc_list_clone_adapter+0xc0>
 1017c26:	jmp    1017c95 <rc_list_clone_adapter+0x155>
 1017c28:	mov    %r12,%rdi
 1017c2b:	mov    %r15,%rsi
 1017c2e:	call   101ccd0 <myl_rc_construction_abort>
 1017c33:	mov    -0x30(%rbp),%rbx
 1017c37:	movq   $0x0,(%rbx)
 1017c3e:	test   %r12,%r12
 1017c41:	je     1017ccb <rc_list_clone_adapter+0x18b>
 1017c47:	mov    0x1608(%r12),%rcx
 1017c4f:	test   %rcx,%rcx
 1017c52:	je     1017ccb <rc_list_clone_adapter+0x18b>
 1017c54:	mov    0x124(%rcx),%eax
 1017c5a:	cmp    $0x1,%eax
 1017c5d:	adc    $0x0,%eax
 1017c60:	mov    %eax,0x124(%rcx)
 1017c66:	jmp    1017ca6 <rc_list_clone_adapter+0x166>
 1017c68:	mov    0x1608(%r12),%rax
 1017c70:	mov    %r13,0x110(%rax)
 1017c77:	mov    (%r14),%rax
 1017c7a:	mov    0x0(%r13),%rdx
 1017c7e:	imul   %rax,%rdx
 1017c82:	mov    0x20(%r15),%rdi
 1017c86:	mov    0x20(%r14),%rsi
 1017c8a:	call   10276a0 <memcpy@plt>
 1017c8f:	mov    (%r14),%rax
 1017c92:	mov    %rax,(%r15)
 1017c95:	movq   $0x0,0x10(%r15)
 1017c9d:	mov    -0x30(%rbp),%rax
 1017ca1:	mov    %r15,(%rax)
 1017ca4:	xor    %eax,%eax
 1017ca6:	add    $0x8,%rsp
 1017caa:	pop    %rbx
 1017cab:	pop    %r12
 1017cad:	pop    %r13
 1017caf:	pop    %r14
 1017cb1:	pop    %r15
 1017cb3:	pop    %rbp
 1017cb4:	ret
 1017cb5:	mov    %r13,%rsi
 1017cb8:	call   1018f74 <myl_rc_binding_find_slow>
 1017cbd:	test   %rax,%rax
 1017cc0:	jne    1017bdf <rc_list_clone_adapter+0x9f>
 1017cc6:	jmp    1017beb <rc_list_clone_adapter+0xab>
 1017ccb:	call   1018954 <myl_rc_invariant_failed>

0000000001017cd0 <rc_list_shell>:
 1017cd0:	push   %rbp
 1017cd1:	mov    %rsp,%rbp
 1017cd4:	push   %r15
 1017cd6:	push   %r14
 1017cd8:	push   %r12
 1017cda:	push   %rbx
 1017cdb:	mov    %rcx,%r12
 1017cde:	mov    %edx,%ecx
 1017ce0:	mov    %rsi,%rbx
 1017ce3:	mov    %rdi,%r14
 1017ce6:	mov    (%rsi),%rdx
 1017ce9:	mov    0x8(%rsi),%rax
 1017ced:	cmp    %rdx,%rax
 1017cf0:	cmova  %rax,%rdx
 1017cf4:	mov    0x18(%rsi),%rsi
 1017cf8:	call   10178c0 <rc_list_new>
 1017cfd:	mov    %rax,(%r12)
 1017d01:	test   %rax,%rax
 1017d04:	je     1017d61 <rc_list_shell+0x91>
 1017d06:	mov    %rax,%r15
 1017d09:	mov    0x18(%rbx),%rsi
 1017d0d:	mov    0x1608(%r14),%rdi
 1017d14:	mov    0x34(%rsi),%eax
 1017d17:	cmp    %rax,0xa0(%rdi)
 1017d1e:	jbe    1017d9b <rc_list_shell+0xcb>
 1017d20:	mov    0x98(%rdi),%rcx
 1017d27:	shl    $0x4,%rax
 1017d2b:	cmp    %rsi,(%rcx,%rax,1)
 1017d2f:	jne    1017d9b <rc_list_shell+0xcb>
 1017d31:	add    %rax,%rcx
 1017d34:	mov    0x8(%rcx),%rax
 1017d38:	test   %rax,%rax
 1017d3b:	je     1017da5 <rc_list_shell+0xd5>
 1017d3d:	mov    (%rbx),%r8
 1017d40:	xor    %r12d,%r12d
 1017d43:	test   %r8,%r8
 1017d46:	je     1017d8a <rc_list_shell+0xba>
 1017d48:	mov    0x8(%rax),%rsi
 1017d4c:	mov    0x20(%r15),%rdx
 1017d50:	mov    0x20(%rbx),%rcx
 1017d54:	mov    %r14,%rdi
 1017d57:	call   101ca40 <myl_rc_value_seed>
 1017d5c:	mov    (%rbx),%rax
 1017d5f:	jmp    1017d8c <rc_list_shell+0xbc>
 1017d61:	test   %r14,%r14
 1017d64:	je     1017daa <rc_list_shell+0xda>
 1017d66:	mov    0x1608(%r14),%rax
 1017d6d:	test   %rax,%rax
 1017d70:	je     1017daa <rc_list_shell+0xda>
 1017d72:	mov    0x124(%rax),%r12d
 1017d79:	cmp    $0x1,%r12d
 1017d7d:	adc    $0x0,%r12d
 1017d81:	mov    %r12d,0x124(%rax)
 1017d88:	jmp    1017d8f <rc_list_shell+0xbf>
 1017d8a:	xor    %eax,%eax
 1017d8c:	mov    %rax,(%r15)
 1017d8f:	mov    %r12d,%eax
 1017d92:	pop    %rbx
 1017d93:	pop    %r12
 1017d95:	pop    %r14
 1017d97:	pop    %r15
 1017d99:	pop    %rbp
 1017d9a:	ret
 1017d9b:	call   1018f74 <myl_rc_binding_find_slow>
 1017da0:	test   %rax,%rax
 1017da3:	jne    1017d3d <rc_list_shell+0x6d>
 1017da5:	call   1027810 <abort@plt>
 1017daa:	call   1018954 <myl_rc_invariant_failed>
 1017daf:	int3

0000000001017db0 <rc_list_next>:
 1017db0:	push   %rbp
 1017db1:	mov    %rsp,%rbp
 1017db4:	push   %r14
 1017db6:	push   %rbx
 1017db7:	mov    0x18(%rsi),%rax
 1017dbb:	mov    0x1608(%rdi),%rdi
 1017dc2:	mov    0x34(%rax),%r10d
 1017dc6:	cmp    %r10,0xa0(%rdi)
 1017dcd:	jbe    1017ea4 <rc_list_next+0xf4>
 1017dd3:	mov    0x98(%rdi),%r11
 1017dda:	shl    $0x4,%r10
 1017dde:	cmp    %rax,(%r11,%r10,1)
 1017de2:	jne    1017ea4 <rc_list_next+0xf4>
 1017de8:	add    %r10,%r11
 1017deb:	mov    0x8(%r11),%rax
 1017def:	test   %rax,%rax
 1017df2:	je     1017ebb <rc_list_next+0x10b>
 1017df8:	mov    (%rcx),%r10
 1017dfb:	xor    %edi,%edi
 1017dfd:	cmp    (%rsi),%r10
 1017e00:	jae    1017e9d <rc_list_next+0xed>
 1017e06:	mov    0x8(%rax),%r11
 1017e0a:	cmpl   $0x0,0x8(%r11)
 1017e0f:	je     1017e9d <rc_list_next+0xed>
 1017e15:	lea    0x1(%r10),%rdi
 1017e19:	mov    %rdi,(%rcx)
 1017e1c:	mov    0x18(%rsi),%rcx
 1017e20:	imul   (%rcx),%r10
 1017e24:	mov    0x20(%rdx),%rcx
 1017e28:	add    %r10,%rcx
 1017e2b:	mov    -0x10(%rdx),%rdi
 1017e2f:	mov    %rdi,%rbx
 1017e32:	shr    $0x28,%rbx
 1017e36:	and    $0xfffff,%ebx
 1017e3c:	xor    %r14d,%r14d
 1017e3f:	bt     $0x3e,%rdi
 1017e44:	cmovae %r14d,%ebx
 1017e48:	mov    %r11,(%r8)
 1017e4b:	mov    %rcx,0x8(%r8)
 1017e4f:	mov    %rdx,0x10(%r8)
 1017e53:	mov    %ebx,0x18(%r8)
 1017e57:	movl   $0x0,0x1c(%r8)
 1017e5f:	mov    0x8(%rax),%rax
 1017e63:	add    0x20(%rsi),%r10
 1017e67:	mov    -0x10(%rsi),%rcx
 1017e6b:	mov    %rcx,%rdx
 1017e6e:	shr    $0x28,%rdx
 1017e72:	and    $0xfffff,%edx
 1017e78:	bt     $0x3e,%rcx
 1017e7d:	cmovae %r14d,%edx
 1017e81:	mov    %rax,(%r9)
 1017e84:	mov    %r10,0x8(%r9)
 1017e88:	mov    %rsi,0x10(%r9)
 1017e8c:	mov    %edx,0x18(%r9)
 1017e90:	movl   $0x0,0x1c(%r9)
 1017e98:	mov    $0x1,%edi
 1017e9d:	mov    %edi,%eax
 1017e9f:	pop    %rbx
 1017ea0:	pop    %r14
 1017ea2:	pop    %rbp
 1017ea3:	ret
 1017ea4:	mov    %rsi,%r10
 1017ea7:	mov    %rax,%rsi
 1017eaa:	call   1018f74 <myl_rc_binding_find_slow>
 1017eaf:	mov    %r10,%rsi
 1017eb2:	test   %rax,%rax
 1017eb5:	jne    1017df8 <rc_list_next+0x48>
 1017ebb:	call   1027810 <abort@plt>

0000000001017ec0 <rc_list_span>:
 1017ec0:	push   %rbp
 1017ec1:	mov    %rsp,%rbp
 1017ec4:	push   %r15
 1017ec6:	push   %r14
 1017ec8:	push   %rbx
 1017ec9:	push   %rax
 1017eca:	mov    %rcx,%rbx
 1017ecd:	mov    %rsi,%r14
 1017ed0:	mov    (%rcx),%r15
 1017ed3:	call   1017db0 <rc_list_next>
 1017ed8:	test   %eax,%eax
 1017eda:	je     1017ef6 <rc_list_span+0x36>
 1017edc:	mov    0x10(%rbp),%rax
 1017ee0:	mov    (%r14),%rcx
 1017ee3:	sub    %r15,%rcx
 1017ee6:	mov    %rcx,(%rax)
 1017ee9:	mov    (%r14),%rax
 1017eec:	mov    %rax,(%rbx)
 1017eef:	mov    $0x1,%eax
 1017ef4:	jmp    1017ef8 <rc_list_span+0x38>
 1017ef6:	xor    %eax,%eax
 1017ef8:	add    $0x8,%rsp
 1017efc:	pop    %rbx
 1017efd:	pop    %r14
 1017eff:	pop    %r15
 1017f01:	pop    %rbp
 1017f02:	ret
 1017f03:	int3
 1017f04:	int3
 1017f05:	int3
 1017f06:	int3
 1017f07:	int3
 1017f08:	int3
 1017f09:	int3
 1017f0a:	int3
 1017f0b:	int3
 1017f0c:	int3
 1017f0d:	int3
 1017f0e:	int3
 1017f0f:	int3

0000000001017f10 <rc_storage_edges>:
 1017f10:	push   %rbp
 1017f11:	mov    %rsp,%rbp
 1017f14:	mov    0x20(%rsi),%rsi
 1017f18:	pop    %rbp
 1017f19:	jmp    1018d40 <myl_rc_edge_release>
 1017f1e:	int3
 1017f1f:	int3

0000000001017f20 <rc_list_insert_at>:
 1017f20:	push   %rbp
 1017f21:	mov    %rsp,%rbp
 1017f24:	push   %r15
 1017f26:	push   %r14
 1017f28:	push   %r13
 1017f2a:	push   %r12
 1017f2c:	push   %rbx
 1017f2d:	sub    $0xa8,%rsp
 1017f34:	xor    %r12d,%r12d
 1017f37:	cmpq   $0xffffffffffffffff,0x10(%rsi)
 1017f3c:	je     1018296 <rc_list_insert_at+0x376>
 1017f42:	mov    %rsi,%r14
 1017f45:	mov    (%rsi),%r15
 1017f48:	cmp    $0xffffffffffffffff,%r15
 1017f4c:	je     1018296 <rc_list_insert_at+0x376>
 1017f52:	mov    0x18(%r14),%rax
 1017f56:	mov    (%rax),%rsi
 1017f59:	cmp    %r15,%rdx
 1017f5c:	mov    %rdx,-0x50(%rbp)
 1017f60:	mov    %rdi,-0x38(%rbp)
 1017f64:	jne    1017f80 <rc_list_insert_at+0x60>
 1017f66:	test   %rsi,%rsi
 1017f69:	je     1017fc7 <rc_list_insert_at+0xa7>
 1017f6b:	mov    0x1608(%rdi),%rax
 1017f72:	cmpq   $0x0,0xc8(%rax)
 1017f7a:	je     1018135 <rc_list_insert_at+0x215>
 1017f80:	cmp    $0x81,%rsi
 1017f87:	jae    1017f96 <rc_list_insert_at+0x76>
 1017f89:	lea    -0xd0(%rbp),%rax
 1017f90:	mov    %rax,-0x40(%rbp)
 1017f94:	jmp    1017fd7 <rc_list_insert_at+0xb7>
 1017f96:	mov    %rcx,%rbx
 1017f99:	xor    %r12d,%r12d
 1017f9c:	mov    %rsi,%r13
 1017f9f:	xor    %edx,%edx
 1017fa1:	mov    $0x1,%ecx
 1017fa6:	call   1022f70 <raw_bytes>
 1017fab:	test   %rax,%rax
 1017fae:	je     1018296 <rc_list_insert_at+0x376>
 1017fb4:	mov    %rax,-0x40(%rbp)
 1017fb8:	mov    (%r14),%r15
 1017fbb:	mov    %rbx,%rcx
 1017fbe:	mov    -0x38(%rbp),%rdi
 1017fc2:	mov    %r13,%rsi
 1017fc5:	jmp    1017fd7 <rc_list_insert_at+0xb7>
 1017fc7:	lea    -0xd0(%rbp),%rax
 1017fce:	mov    %rax,-0x40(%rbp)
 1017fd2:	xor    %esi,%esi
 1017fd4:	mov    %rdx,%r15
 1017fd7:	mov    %rsi,-0x30(%rbp)
 1017fdb:	mov    -0x10(%r14),%rax
 1017fdf:	mov    0x20(%r14),%rdx
 1017fe3:	mov    %rax,%rbx
 1017fe6:	shr    $0x28,%rbx
 1017fea:	and    $0xfffff,%ebx
 1017ff0:	xor    %r12d,%r12d
 1017ff3:	bt     $0x3e,%rax
 1017ff8:	cmovae %r12d,%ebx
 1017ffc:	test   %rdx,%rdx
 1017fff:	sete   %al
 1018002:	mov    %rcx,-0x48(%rbp)
 1018006:	mov    %rcx,%r13
 1018009:	sub    %rdx,%r13
 101800c:	setb   %cl
 101800f:	or     %al,%cl
 1018011:	je     101802a <rc_list_insert_at+0x10a>
 1018013:	inc    %r15
 1018016:	mov    %r14,%rsi
 1018019:	mov    %r15,%rdx
 101801c:	call   10182c0 <myl_rc_list_storage_reserve>
 1018021:	test   %eax,%eax
 1018023:	jne    1018050 <rc_list_insert_at+0x130>
 1018025:	jmp    10180de <rc_list_insert_at+0x1be>
 101802a:	lea    0x1(%r15),%rdx
 101802e:	mov    %r14,%rsi
 1018031:	call   10182c0 <myl_rc_list_storage_reserve>
 1018036:	test   %eax,%eax
 1018038:	je     10180de <rc_list_insert_at+0x1be>
 101803e:	imul   -0x30(%rbp),%r15
 1018043:	cmp    %r15,%r13
 1018046:	jae    1018050 <rc_list_insert_at+0x130>
 1018048:	add    0x20(%r14),%r13
 101804c:	mov    %r13,-0x48(%rbp)
 1018050:	mov    0x18(%r14),%rsi
 1018054:	mov    -0x38(%rbp),%rdi
 1018058:	mov    -0x40(%rbp),%r15
 101805c:	mov    %r15,%rdx
 101805f:	mov    -0x48(%rbp),%rcx
 1018063:	mov    %ebx,%r8d
 1018066:	call   1023af0 <myl_rc_native_retain>
 101806b:	test   %eax,%eax
 101806d:	je     10180cd <rc_list_insert_at+0x1ad>
 101806f:	mov    (%r14),%rdx
 1018072:	mov    0x20(%r14),%rbx
 1018076:	mov    -0x50(%rbp),%rax
 101807a:	sub    %rax,%rdx
 101807d:	jbe    10180a5 <rc_list_insert_at+0x185>
 101807f:	lea    0x1(%rax),%rdi
 1018083:	mov    -0x30(%rbp),%rcx
 1018087:	imul   %rcx,%rdi
 101808b:	add    %rbx,%rdi
 101808e:	mov    %rcx,%rsi
 1018091:	imul   %rax,%rsi
 1018095:	add    %rbx,%rsi
 1018098:	imul   %rcx,%rdx
 101809c:	call   1027880 <memmove@plt>
 10180a1:	mov    -0x50(%rbp),%rax
 10180a5:	mov    -0x30(%rbp),%rdx
 10180a9:	test   %rdx,%rdx
 10180ac:	je     10180c0 <rc_list_insert_at+0x1a0>
 10180ae:	imul   %rdx,%rax
 10180b2:	add    %rax,%rbx
 10180b5:	mov    %rbx,%rdi
 10180b8:	mov    %r15,%rsi
 10180bb:	call   10276a0 <memcpy@plt>
 10180c0:	incq   (%r14)
 10180c3:	incq   0x10(%r14)
 10180c7:	mov    $0x1,%r12d
 10180cd:	lea    -0xd0(%rbp),%rax
 10180d4:	cmp    %rax,%r15
 10180d7:	jne    10180f2 <rc_list_insert_at+0x1d2>
 10180d9:	jmp    1018296 <rc_list_insert_at+0x376>
 10180de:	mov    -0x40(%rbp),%r15
 10180e2:	lea    -0xd0(%rbp),%rax
 10180e9:	cmp    %rax,%r15
 10180ec:	je     1018296 <rc_list_insert_at+0x376>
 10180f2:	mov    -0x38(%rbp),%rbx
 10180f6:	mov    %rbx,%rdi
 10180f9:	mov    %r15,%rsi
 10180fc:	call   1018d40 <myl_rc_edge_release>
 1018101:	test   %rbx,%rbx
 1018104:	je     1018296 <rc_list_insert_at+0x376>
 101810a:	mov    0x1608(%rbx),%rax
 1018111:	test   %rax,%rax
 1018114:	je     1018296 <rc_list_insert_at+0x376>
 101811a:	cmpq   $0x0,0xc8(%rax)
 1018122:	je     1018296 <rc_list_insert_at+0x376>
 1018128:	mov    %rbx,%rdi
 101812b:	call   101be30 <myl_rc_drain>
 1018130:	jmp    1018296 <rc_list_insert_at+0x376>
 1018135:	mov    0x20(%r14),%rax
 1018139:	mov    %rsi,%rbx
 101813c:	imul   %rdx,%rbx
 1018140:	test   %rax,%rax
 1018143:	sete   %r8b
 1018147:	mov    %rcx,%r13
 101814a:	sub    %rax,%r13
 101814d:	setb   %al
 1018150:	or     %r8b,%al
 1018153:	je     101817e <rc_list_insert_at+0x25e>
 1018155:	mov    %rsi,%r13
 1018158:	mov    %rcx,%r15
 101815b:	inc    %rdx
 101815e:	mov    %r14,%rsi
 1018161:	call   10182c0 <myl_rc_list_storage_reserve>
 1018166:	test   %eax,%eax
 1018168:	je     1018296 <rc_list_insert_at+0x376>
 101816e:	mov    0x20(%r14),%rdx
 1018172:	mov    %r15,%rcx
 1018175:	mov    -0x38(%rbp),%r9
 1018179:	mov    %r13,%r10
 101817c:	jmp    10181d3 <rc_list_insert_at+0x2b3>
 101817e:	cmp    %rbx,%r13
 1018181:	setb   %r8b
 1018185:	jb     1018198 <rc_list_insert_at+0x278>
 1018187:	mov    0x8(%r14),%rax
 101818b:	imul   %rsi,%rax
 101818f:	cmp    %rax,%r13
 1018192:	jb     1017f80 <rc_list_insert_at+0x60>
 1018198:	mov    %r8d,%r15d
 101819b:	mov    %rsi,-0x30(%rbp)
 101819f:	mov    %rcx,-0x48(%rbp)
 10181a3:	inc    %rdx
 10181a6:	mov    %r14,%rsi
 10181a9:	call   10182c0 <myl_rc_list_storage_reserve>
 10181ae:	test   %eax,%eax
 10181b0:	je     1018296 <rc_list_insert_at+0x376>
 10181b6:	mov    0x20(%r14),%rdx
 10181ba:	test   %r15b,%r15b
 10181bd:	je     10181c7 <rc_list_insert_at+0x2a7>
 10181bf:	add    %rdx,%r13
 10181c2:	mov    %r13,%rcx
 10181c5:	jmp    10181cb <rc_list_insert_at+0x2ab>
 10181c7:	mov    -0x48(%rbp),%rcx
 10181cb:	mov    -0x38(%rbp),%r9
 10181cf:	mov    -0x30(%rbp),%r10
 10181d3:	add    %rbx,%rdx
 10181d6:	lea    (%rcx,%r10,1),%rax
 10181da:	cmp    %rdx,%rax
 10181dd:	jbe    10181ec <rc_list_insert_at+0x2cc>
 10181df:	lea    (%r10,%rdx,1),%rax
 10181e3:	cmp    %rcx,%rax
 10181e6:	ja     10182bb <rc_list_insert_at+0x39b>
 10181ec:	mov    0x18(%r14),%rsi
 10181f0:	mov    0x1608(%r9),%rdi
 10181f7:	cmp    %rsi,0x110(%rdi)
 10181fe:	je     101827b <rc_list_insert_at+0x35b>
 1018200:	mov    0x34(%rsi),%eax
 1018203:	cmp    %rax,0xa0(%rdi)
 101820a:	jbe    10182ab <rc_list_insert_at+0x38b>
 1018210:	mov    0x98(%rdi),%r8
 1018217:	shl    $0x4,%rax
 101821b:	cmp    %rsi,(%r8,%rax,1)
 101821f:	jne    10182ab <rc_list_insert_at+0x38b>
 1018225:	add    %rax,%r8
 1018228:	mov    0x8(%r8),%rax
 101822c:	test   %rax,%rax
 101822f:	je     101823d <rc_list_insert_at+0x31d>
 1018231:	cmpl   $0x0,0x40(%rax)
 1018235:	jne    101823d <rc_list_insert_at+0x31d>
 1018237:	cmpb   $0x0,0x45(%rax)
 101823b:	je     101826d <rc_list_insert_at+0x34d>
 101823d:	mov    -0x10(%r14),%rax
 1018241:	mov    0x18(%r14),%rsi
 1018245:	mov    %rax,%r8
 1018248:	shr    $0x28,%r8
 101824c:	and    $0xfffff,%r8d
 1018253:	xor    %r12d,%r12d
 1018256:	bt     $0x3e,%rax
 101825b:	cmovae %r12d,%r8d
 101825f:	mov    %r9,%rdi
 1018262:	call   1023af0 <myl_rc_native_retain>
 1018267:	test   %eax,%eax
 1018269:	jne    1018289 <rc_list_insert_at+0x369>
 101826b:	jmp    1018296 <rc_list_insert_at+0x376>
 101826d:	mov    0x1608(%r9),%rax
 1018274:	mov    %rsi,0x110(%rax)
 101827b:	mov    %rdx,%rdi
 101827e:	mov    %rcx,%rsi
 1018281:	mov    %r10,%rdx
 1018284:	call   10276a0 <memcpy@plt>
 1018289:	incq   (%r14)
 101828c:	incq   0x10(%r14)
 1018290:	mov    $0x1,%r12d
 1018296:	mov    %r12d,%eax
 1018299:	add    $0xa8,%rsp
 10182a0:	pop    %rbx
 10182a1:	pop    %r12
 10182a3:	pop    %r13
 10182a5:	pop    %r14
 10182a7:	pop    %r15
 10182a9:	pop    %rbp
 10182aa:	ret
 10182ab:	call   1018f74 <myl_rc_binding_find_slow>
 10182b0:	test   %rax,%rax
 10182b3:	jne    1018231 <rc_list_insert_at+0x311>
 10182b9:	jmp    101823d <rc_list_insert_at+0x31d>
 10182bb:	call   1018954 <myl_rc_invariant_failed>

00000000010182c0 <myl_rc_list_storage_reserve>:
 10182c0:	mov    0x8(%rsi),%rcx
 10182c4:	mov    $0x1,%eax
 10182c9:	cmp    %rcx,%rdx
 10182cc:	jbe    1018445 <myl_rc_list_storage_reserve+0x185>
 10182d2:	push   %rbp
 10182d3:	mov    %rsp,%rbp
 10182d6:	push   %r15
 10182d8:	push   %r14
 10182da:	push   %r13
 10182dc:	push   %r12
 10182de:	push   %rbx
 10182df:	push   %rax
 10182e0:	mov    %rsi,%rbx
 10182e3:	cmp    $0x5,%rcx
 10182e7:	mov    $0x4,%r13d
 10182ed:	cmovae %rcx,%r13
 10182f1:	cmp    $0x5,%rdx
 10182f5:	jb     101830d <myl_rc_list_storage_reserve+0x4d>
 10182f7:	nopw   0x0(%rax,%rax,1)
 1018300:	test   %r13,%r13
 1018303:	js     1018321 <myl_rc_list_storage_reserve+0x61>
 1018305:	add    %r13,%r13
 1018308:	cmp    %rdx,%r13
 101830b:	jb     1018300 <myl_rc_list_storage_reserve+0x40>
 101830d:	mov    0x18(%rbx),%rsi
 1018311:	mov    (%rsi),%rcx
 1018314:	test   %rcx,%rcx
 1018317:	je     1018328 <myl_rc_list_storage_reserve+0x68>
 1018319:	mov    %rcx,%rax
 101831c:	mul    %r13
 101831f:	jno    1018328 <myl_rc_list_storage_reserve+0x68>
 1018321:	xor    %eax,%eax
 1018323:	jmp    1018437 <myl_rc_list_storage_reserve+0x177>
 1018328:	mov    0x20(%rbx),%r14
 101832c:	mov    0x1608(%rdi),%rax
 1018333:	cmp    %rsi,0x110(%rax)
 101833a:	je     101840e <myl_rc_list_storage_reserve+0x14e>
 1018340:	mov    0x34(%rsi),%ecx
 1018343:	cmp    %rcx,0xa0(%rax)
 101834a:	jbe    10184d6 <myl_rc_list_storage_reserve+0x216>
 1018350:	mov    0x98(%rax),%rdx
 1018357:	shl    $0x4,%rcx
 101835b:	cmp    %rsi,(%rdx,%rcx,1)
 101835f:	jne    10184d6 <myl_rc_list_storage_reserve+0x216>
 1018365:	add    %rcx,%rdx
 1018368:	mov    0x8(%rdx),%rax
 101836c:	test   %rax,%rax
 101836f:	je     101837d <myl_rc_list_storage_reserve+0xbd>
 1018371:	cmpl   $0x0,0x40(%rax)
 1018375:	jne    101837d <myl_rc_list_storage_reserve+0xbd>
 1018377:	cmpb   $0x0,0x45(%rax)
 101837b:	je     10183f9 <myl_rc_list_storage_reserve+0x139>
 101837d:	mov    0x18(%rbx),%rax
 1018381:	mov    (%rax),%rdx
 1018384:	imul   %r13,%rdx
 1018388:	mov    %rdi,%r15
 101838b:	mov    %r14,%rsi
 101838e:	mov    $0x1,%ecx
 1018393:	call   10231c0 <storage_extend>
 1018398:	test   %rax,%rax
 101839b:	jne    101842a <myl_rc_list_storage_reserve+0x16a>
 10183a1:	mov    -0x10(%rbx),%rax
 10183a5:	mov    0x18(%rbx),%rdx
 10183a9:	mov    %rax,%rcx
 10183ac:	shr    $0x28,%rcx
 10183b0:	and    $0xfffff,%ecx
 10183b6:	xor    %esi,%esi
 10183b8:	bt     $0x3e,%rax
 10183bd:	cmovae %esi,%ecx
 10183c0:	mov    (%rdx),%rsi
 10183c3:	test   %rsi,%rsi
 10183c6:	je     10183d5 <myl_rc_list_storage_reserve+0x115>
 10183c8:	mov    %rsi,%rax
 10183cb:	mul    %r13
 10183ce:	mov    $0x0,%eax
 10183d3:	jo     1018437 <myl_rc_list_storage_reserve+0x177>
 10183d5:	imul   %r13,%rsi
 10183d9:	mov    %r15,%rdi
 10183dc:	mov    %ecx,%edx
 10183de:	mov    $0x1,%ecx
 10183e3:	call   1022f70 <raw_bytes>
 10183e8:	mov    %rax,%r12
 10183eb:	test   %rax,%rax
 10183ee:	jne    1018481 <myl_rc_list_storage_reserve+0x1c1>
 10183f4:	jmp    1018321 <myl_rc_list_storage_reserve+0x61>
 10183f9:	mov    0x1608(%rdi),%rax
 1018400:	mov    %rsi,0x110(%rax)
 1018407:	mov    0x18(%rbx),%rax
 101840b:	mov    (%rax),%rcx
 101840e:	imul   %r13,%rcx
 1018412:	xor    %r12d,%r12d
 1018415:	mov    %rdi,%r15
 1018418:	mov    %r14,%rsi
 101841b:	mov    %rcx,%rdx
 101841e:	xor    %ecx,%ecx
 1018420:	call   10231c0 <storage_extend>
 1018425:	test   %rax,%rax
 1018428:	je     1018446 <myl_rc_list_storage_reserve+0x186>
 101842a:	mov    %rax,0x20(%rbx)
 101842e:	mov    %r13,0x8(%rbx)
 1018432:	mov    $0x1,%eax
 1018437:	add    $0x8,%rsp
 101843b:	pop    %rbx
 101843c:	pop    %r12
 101843e:	pop    %r13
 1018440:	pop    %r14
 1018442:	pop    %r15
 1018444:	pop    %rbp
 1018445:	ret
 1018446:	mov    -0x10(%rbx),%rax
 101844a:	mov    0x18(%rbx),%rcx
 101844e:	mov    (%rcx),%rsi
 1018451:	imul   %r13,%rsi
 1018455:	mov    %rax,%rdx
 1018458:	shr    $0x28,%rdx
 101845c:	and    $0xfffff,%edx
 1018462:	bt     $0x3e,%rax
 1018467:	cmovae %r12d,%edx
 101846b:	mov    %r15,%rdi
 101846e:	xor    %ecx,%ecx
 1018470:	call   1022f70 <raw_bytes>
 1018475:	mov    %rax,%r12
 1018478:	test   %rax,%rax
 101847b:	je     1018321 <myl_rc_list_storage_reserve+0x61>
 1018481:	mov    (%rbx),%rdx
 1018484:	test   %rdx,%rdx
 1018487:	je     101849c <myl_rc_list_storage_reserve+0x1dc>
 1018489:	mov    0x18(%rbx),%rax
 101848d:	imul   (%rax),%rdx
 1018491:	mov    %r12,%rdi
 1018494:	mov    %r14,%rsi
 1018497:	call   10276a0 <memcpy@plt>
 101849c:	mov    %r12,0x20(%rbx)
 10184a0:	mov    %r15,%rdi
 10184a3:	mov    %r14,%rsi
 10184a6:	call   1018d40 <myl_rc_edge_release>
 10184ab:	mov    0x1608(%r15),%rax
 10184b2:	test   %rax,%rax
 10184b5:	je     101842e <myl_rc_list_storage_reserve+0x16e>
 10184bb:	cmpq   $0x0,0xc8(%rax)
 10184c3:	je     101842e <myl_rc_list_storage_reserve+0x16e>
 10184c9:	mov    %r15,%rdi
 10184cc:	call   101be30 <myl_rc_drain>
 10184d1:	jmp    101842e <myl_rc_list_storage_reserve+0x16e>
 10184d6:	mov    %rdi,%rcx
 10184d9:	mov    %rax,%rdi
 10184dc:	call   1018f74 <myl_rc_binding_find_slow>
 10184e1:	mov    %rcx,%rdi
 10184e4:	test   %rax,%rax
 10184e7:	jne    1018371 <myl_rc_list_storage_reserve+0xb1>
 10184ed:	jmp    101837d <myl_rc_list_storage_reserve+0xbd>
 10184f2:	int3
 10184f3:	int3
 10184f4:	int3
 10184f5:	int3
 10184f6:	int3
 10184f7:	int3
 10184f8:	int3
 10184f9:	int3
 10184fa:	int3
 10184fb:	int3
 10184fc:	int3
 10184fd:	int3
 10184fe:	int3
 10184ff:	int3

0000000001018500 <myl_qbe_on_stack>:
 1018500:	push   %rbp
 1018501:	mov    %rsp,%rbp
 1018504:	push   %r15
 1018506:	push   %r14
 1018508:	push   %r13
 101850a:	push   %r12
 101850c:	push   %rbx
 101850d:	sub    $0x878,%rsp
 1018514:	mov    %rdi,%rbx
 1018517:	mov    $0x1e,%edi
 101851c:	call   1027890 <sysconf@plt>
 1018521:	test   %rax,%rax
 1018524:	jle    10185ac <myl_qbe_on_stack+0xac>
 101852a:	mov    %rax,%rcx
 101852d:	shr    $0x3e,%rcx
 1018531:	jne    101854e <myl_qbe_on_stack+0x4e>
 1018533:	lea    (%rax,%rax,1),%r14
 1018537:	mov    0x18(%rbx),%rcx
 101853b:	mov    $0xffffffffff7ffffe,%rdx
 1018542:	sub    %r14,%rdx
 1018545:	shr    $0xf,%rdx
 1018549:	cmp    %rdx,%rcx
 101854c:	jbe    101855f <myl_qbe_on_stack+0x5f>
 101854e:	mov    $0xffffffffffffffff,%rsi
 1018555:	mov    %rbx,%rdi
 1018558:	call   1018780 <stack_refused>
 101855d:	jmp    10185b9 <myl_qbe_on_stack+0xb9>
 101855f:	shl    $0xf,%rcx
 1018563:	mov    %rcx,%rdx
 1018566:	add    $0x800000,%rdx
 101856d:	mov    %rax,%rcx
 1018570:	neg    %rcx
 1018573:	cmp    %rcx,%rdx
 1018576:	ja     10185ac <myl_qbe_on_stack+0xac>
 1018578:	mov    %r14,%rcx
 101857b:	not    %rcx
 101857e:	lea    (%rdx,%rax,1),%r12
 1018582:	dec    %r12
 1018585:	mov    %r12,%rdx
 1018588:	or     %rax,%rdx
 101858b:	shr    $0x20,%rdx
 101858f:	je     10185d0 <myl_qbe_on_stack+0xd0>
 1018591:	mov    %rax,%rsi
 1018594:	mov    %rax,%r13
 1018597:	xor    %eax,%eax
 1018599:	mov    %eax,%edx
 101859b:	mov    %r12,%rax
 101859e:	div    %rsi
 10185a1:	mov    %rdx,%rax
 10185a4:	sub    %rax,%r12
 10185a7:	cmp    %rcx,%r12
 10185aa:	jbe    10185e6 <myl_qbe_on_stack+0xe6>
 10185ac:	mov    $0x1003b92,%esi
 10185b1:	mov    %rbx,%rdi
 10185b4:	call   1014ab0 <fail>
 10185b9:	xor    %eax,%eax
 10185bb:	add    $0x878,%rsp
 10185c2:	pop    %rbx
 10185c3:	pop    %r12
 10185c5:	pop    %r13
 10185c7:	pop    %r14
 10185c9:	pop    %r15
 10185cb:	pop    %rbp
 10185cc:	vzeroupper
 10185cf:	ret
 10185d0:	mov    %rax,%r13
 10185d3:	mov    %eax,%esi
 10185d5:	mov    %r12d,%eax
 10185d8:	xor    %edx,%edx
 10185da:	div    %esi
 10185dc:	mov    %edx,%eax
 10185de:	sub    %rax,%r12
 10185e1:	cmp    %rcx,%r12
 10185e4:	ja     10185ac <myl_qbe_on_stack+0xac>
 10185e6:	add    %r12,%r14
 10185e9:	xor    %eax,%eax
 10185eb:	mov    %eax,%edi
 10185ed:	mov    %r14,%rsi
 10185f0:	xor    %edx,%edx
 10185f2:	mov    $0x20022,%ecx
 10185f7:	mov    $0xffffffff,%r8d
 10185fd:	mov    %rdi,%r9
 1018600:	call   10278a0 <mmap@plt>
 1018605:	cmp    $0xffffffffffffffff,%rax
 1018609:	je     101875e <myl_qbe_on_stack+0x25e>
 101860f:	mov    %rax,%r15
 1018612:	add    %rax,%r13
 1018615:	vxorps %xmm0,%xmm0,%xmm0
 1018619:	vmovups %ymm0,-0x48(%rbp)
 101861e:	vmovups %ymm0,-0x58(%rbp)
 1018623:	vmovups %ymm0,-0x78(%rbp)
 1018628:	vmovups %ymm0,-0x98(%rbp)
 1018630:	vmovups %ymm0,-0xb8(%rbp)
 1018638:	vmovups %ymm0,-0xd8(%rbp)
 1018640:	vmovups %ymm0,-0xf8(%rbp)
 1018648:	movq   $0x1012680,-0x108(%rbp)
 1018653:	mov    %rbx,-0x100(%rbp)
 101865a:	mov    %r13,%rdi
 101865d:	mov    %r12,%rsi
 1018660:	mov    $0x3,%edx
 1018665:	vzeroupper
 1018668:	call   10278b0 <mprotect@plt>
 101866d:	test   %eax,%eax
 101866f:	jne    1018718 <myl_qbe_on_stack+0x218>
 1018675:	lea    -0x4d0(%rbp),%rdi
 101867c:	call   10278c0 <getcontext@plt>
 1018681:	test   %eax,%eax
 1018683:	jne    1018718 <myl_qbe_on_stack+0x218>
 1018689:	lea    -0x800000(%r12),%rax
 1018691:	mov    %rax,0x39b8(%rbx)
 1018698:	mov    %r13,0x39c0(%rbx)
 101869f:	lea    (%r12,%r13,1),%rax
 10186a3:	mov    %rax,0x3e68(%rbx)
 10186aa:	lea    0x10000(%r13),%rax
 10186b1:	mov    %rax,0x40(%rbx)
 10186b5:	mov    %r13,-0x4c0(%rbp)
 10186bc:	mov    %r12,-0x4b0(%rbp)
 10186c3:	movl   $0x0,-0x4b8(%rbp)
 10186cd:	lea    -0x898(%rbp),%r12
 10186d4:	mov    %r12,-0x4c8(%rbp)
 10186db:	lea    -0x108(%rbp),%rax
 10186e2:	mov    %rax,%rdx
 10186e5:	mov    %eax,%ecx
 10186e7:	shr    $0x20,%rdx
 10186eb:	mov    %edx,%r8d
 10186ee:	mov    $0x10188e0,%esi
 10186f3:	xor    %eax,%eax
 10186f5:	lea    -0x4d0(%rbp),%r13
 10186fc:	mov    %r13,%rdi
 10186ff:	mov    $0x2,%edx
 1018704:	call   10278d0 <makecontext@plt>
 1018709:	mov    %r12,%rdi
 101870c:	mov    %r13,%rsi
 101870f:	call   10278e0 <swapcontext@plt>
 1018714:	test   %eax,%eax
 1018716:	je     1018769 <myl_qbe_on_stack+0x269>
 1018718:	mov    $0x1003b92,%esi
 101871d:	mov    %rbx,%rdi
 1018720:	call   1014ab0 <fail>
 1018725:	xor    %eax,%eax
 1018727:	mov    %rax,%r12
 101872a:	movq   $0x0,0x39c0(%rbx)
 1018735:	movq   $0x0,0x3e68(%rbx)
 1018740:	movq   $0x0,0x40(%rbx)
 1018748:	mov    %r15,%rdi
 101874b:	mov    %r14,%rsi
 101874e:	vzeroupper
 1018751:	call   10278f0 <munmap@plt>
 1018756:	mov    %r12,%rax
 1018759:	jmp    10185bb <myl_qbe_on_stack+0xbb>
 101875e:	mov    %rbx,%rdi
 1018761:	mov    %r14,%rsi
 1018764:	jmp    1018558 <myl_qbe_on_stack+0x58>
 1018769:	mov    -0xf8(%rbp),%rax
 1018770:	jmp    1018727 <myl_qbe_on_stack+0x227>
 1018772:	int3
 1018773:	int3
 1018774:	int3
 1018775:	int3
 1018776:	int3
 1018777:	int3
 1018778:	int3
 1018779:	int3
 101877a:	int3
 101877b:	int3
 101877c:	int3
 101877d:	int3
 101877e:	int3
 101877f:	int3

0000000001018780 <stack_refused>:
 1018780:	push   %rbp
 1018781:	mov    %rsp,%rbp
 1018784:	push   %r14
 1018786:	push   %rbx
 1018787:	sub    $0x80,%rsp
 101878e:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 1018793:	je     10187b0 <stack_refused+0x30>
 1018795:	mov    %rsi,%rbx
 1018798:	lea    -0x20(%rbp),%rsi
 101879c:	mov    %rdi,%r14
 101879f:	mov    $0x9,%edi
 10187a4:	call   1027780 <getrlimit@plt>
 10187a9:	mov    %r14,%rdi
 10187ac:	test   %eax,%eax
 10187ae:	je     10187c9 <stack_refused+0x49>
 10187b0:	mov    $0x1003b92,%esi
 10187b5:	call   1014ab0 <fail>
 10187ba:	add    $0x80,%rsp
 10187c1:	pop    %rbx
 10187c2:	pop    %r14
 10187c4:	pop    %rbp
 10187c5:	vzeroupper
 10187c8:	ret
 10187c9:	cmp    $0xffffffffffffffff,%rbx
 10187cd:	jne    10187ec <stack_refused+0x6c>
 10187cf:	vmovupd -0x14565(%rip),%ymm0        # 1004272 <qbe_empty_registry+0x71a>
 10187d7:	vmovupd %ymm0,-0x50(%rbp)
 10187dc:	movabs $0x64657373657264,%rax
 10187e6:	mov    %rax,-0x30(%rbp)
 10187ea:	jmp    1018827 <stack_refused+0xa7>
 10187ec:	vmovq  %rbx,%xmm0
 10187f1:	vpunpckldq -0x16f29(%rip),%xmm0,%xmm0        # 10018d0 <__abi_tag+0x15d4>
 10187f9:	vsubpd -0x16f41(%rip),%xmm0,%xmm0        # 10018c0 <__abi_tag+0x15c4>
 1018801:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 1018806:	vaddsd %xmm0,%xmm1,%xmm0
 101880a:	vmulsd -0x16da2(%rip),%xmm0,%xmm0        # 1001a70 <__abi_tag+0x1774>
 1018812:	lea    -0x50(%rbp),%rdi
 1018816:	mov    $0x30,%esi
 101881b:	mov    $0x1003f13,%edx
 1018820:	mov    $0x1,%al
 1018822:	call   10277e0 <snprintf@plt>
 1018827:	mov    -0x20(%rbp),%rax
 101882b:	cmp    $0xffffffffffffffff,%rax
 101882f:	jne    1018853 <stack_refused+0xd3>
 1018831:	vmovups -0x147e0(%rip),%xmm0        # 1004059 <qbe_empty_registry+0x501>
 1018839:	vmovups %xmm0,-0x81(%rbp)
 1018841:	vmovupd -0x147ff(%rip),%xmm0        # 100404a <qbe_empty_registry+0x4f2>
 1018849:	vmovapd %xmm0,-0x90(%rbp)
 1018851:	jmp    1018894 <stack_refused+0x114>
 1018853:	vmovq  %rax,%xmm0
 1018858:	vpunpckldq -0x16f90(%rip),%xmm0,%xmm0        # 10018d0 <__abi_tag+0x15d4>
 1018860:	vsubpd -0x16fa8(%rip),%xmm0,%xmm0        # 10018c0 <__abi_tag+0x15c4>
 1018868:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 101886d:	vaddsd %xmm0,%xmm1,%xmm0
 1018871:	vmulsd -0x16e09(%rip),%xmm0,%xmm0        # 1001a70 <__abi_tag+0x1774>
 1018879:	lea    -0x90(%rbp),%rdi
 1018880:	mov    $0x40,%esi
 1018885:	mov    $0x1004495,%edx
 101888a:	mov    $0x1,%al
 101888c:	vzeroupper
 101888f:	call   10277e0 <snprintf@plt>
 1018894:	mov    0x1047d(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 101889b:	mov    (%rax),%rdi
 101889e:	mov    0x18(%r14),%rdx
 10188a2:	lea    -0x50(%rbp),%rcx
 10188a6:	lea    -0x90(%rbp),%r9
 10188ad:	mov    $0x100479e,%esi
 10188b2:	mov    $0x20,%r8d
 10188b8:	xor    %eax,%eax
 10188ba:	vzeroupper
 10188bd:	call   1027760 <fprintf@plt>
 10188c2:	movl   $0x1,0x39e0(%r14)
 10188cd:	mov    $0x1003b92,%esi
 10188d2:	mov    %r14,%rdi
 10188d5:	jmp    10187b5 <stack_refused+0x35>
 10188da:	int3
 10188db:	int3
 10188dc:	int3
 10188dd:	int3
 10188de:	int3
 10188df:	int3

00000000010188e0 <launch>:
 10188e0:	push   %rbp
 10188e1:	mov    %rsp,%rbp
 10188e4:	sub    $0x10,%rsp
 10188e8:	mov    %edi,%edi
 10188ea:	mov    %edi,%eax
 10188ec:	mov    %esi,%ecx
 10188ee:	shl    $0x20,%rcx
 10188f2:	or     %rax,%rcx
 10188f5:	mov    %rcx,-0x8(%rbp)
 10188f9:	mov    -0x8(%rbp),%rdi
 10188fd:	add    $0x18,%rdi
 1018901:	call   1027900 <_setjmp@plt>
 1018906:	mov    -0x8(%rbp),%rcx
 101890a:	test   %eax,%eax
 101890c:	je     1018912 <launch+0x32>
 101890e:	xor    %eax,%eax
 1018910:	jmp    1018937 <launch+0x57>
 1018912:	add    $0x18,%rcx
 1018916:	mov    -0x8(%rbp),%rax
 101891a:	mov    0x8(%rax),%rax
 101891e:	mov    %rcx,0x3e60(%rax)
 1018925:	mov    -0x8(%rbp),%rax
 1018929:	mov    -0x8(%rbp),%rcx
 101892d:	mov    0x8(%rcx),%rdi
 1018931:	call   *(%rax)
 1018933:	mov    -0x8(%rbp),%rcx
 1018937:	mov    %rax,0x10(%rcx)
 101893b:	mov    -0x8(%rbp),%rax
 101893f:	mov    0x8(%rax),%rax
 1018943:	movq   $0x0,0x3e60(%rax)
 101894e:	add    $0x10,%rsp
 1018952:	pop    %rbp
 1018953:	ret

0000000001018954 <myl_rc_invariant_failed>:
 1018954:	push   %rbp
 1018955:	mov    %rsp,%rbp
 1018958:	call   1027810 <abort@plt>
 101895d:	int3
 101895e:	int3
 101895f:	int3

0000000001018960 <myl_rc_meta_alloc>:
 1018960:	push   %rbp
 1018961:	mov    %rsp,%rbp
 1018964:	push   %r15
 1018966:	push   %r14
 1018968:	push   %r12
 101896a:	push   %rbx
 101896b:	test   %rdi,%rdi
 101896e:	je     10189d1 <myl_rc_meta_alloc+0x71>
 1018970:	test   %rsi,%rsi
 1018973:	je     10189d1 <myl_rc_meta_alloc+0x71>
 1018975:	mov    0x1608(%rdi),%rbx
 101897c:	test   %rbx,%rbx
 101897f:	je     10189d1 <myl_rc_meta_alloc+0x71>
 1018981:	mov    0x18(%rdi),%r14
 1018985:	add    %rsi,%r14
 1018988:	jb     10189a0 <myl_rc_meta_alloc+0x40>
 101898a:	mov    0x58(%rdi),%rax
 101898e:	test   %rax,%rax
 1018991:	setne  %cl
 1018994:	cmp    %rax,%r14
 1018997:	seta   %al
 101899a:	and    %cl,%al
 101899c:	cmp    $0x1,%al
 101899e:	jne    10189b2 <myl_rc_meta_alloc+0x52>
 10189a0:	movl   $0x1,0x6c(%rdi)
 10189a7:	xor    %eax,%eax
 10189a9:	pop    %rbx
 10189aa:	pop    %r12
 10189ac:	pop    %r14
 10189ae:	pop    %r15
 10189b0:	pop    %rbp
 10189b1:	ret
 10189b2:	mov    %rdi,%r15
 10189b5:	mov    $0x1,%edi
 10189ba:	mov    %rsi,%r12
 10189bd:	call   1027690 <calloc@plt>
 10189c2:	test   %rax,%rax
 10189c5:	je     10189a7 <myl_rc_meta_alloc+0x47>
 10189c7:	mov    %r14,0x18(%r15)
 10189cb:	add    %r12,0x30(%rbx)
 10189cf:	jmp    10189a9 <myl_rc_meta_alloc+0x49>
 10189d1:	call   1018954 <myl_rc_invariant_failed>
 10189d6:	int3
 10189d7:	int3
 10189d8:	int3
 10189d9:	int3
 10189da:	int3
 10189db:	int3
 10189dc:	int3
 10189dd:	int3
 10189de:	int3
 10189df:	int3

00000000010189e0 <myl_rc_meta_free>:
 10189e0:	test   %rsi,%rsi
 10189e3:	je     1018a0e <myl_rc_meta_free+0x2e>
 10189e5:	mov    0x18(%rdi),%rax
 10189e9:	sub    %rdx,%rax
 10189ec:	jb     1018a0f <myl_rc_meta_free+0x2f>
 10189ee:	mov    0x1608(%rdi),%rcx
 10189f5:	mov    0x30(%rcx),%r8
 10189f9:	sub    %rdx,%r8
 10189fc:	jb     1018a0f <myl_rc_meta_free+0x2f>
 10189fe:	mov    %rax,0x18(%rdi)
 1018a02:	mov    %r8,0x30(%rcx)
 1018a06:	mov    %rsi,%rdi
 1018a09:	jmp    10276f0 <free@plt>
 1018a0e:	ret
 1018a0f:	push   %rbp
 1018a10:	mov    %rsp,%rbp
 1018a13:	call   1018954 <myl_rc_invariant_failed>
 1018a18:	int3
 1018a19:	int3
 1018a1a:	int3
 1018a1b:	int3
 1018a1c:	int3
 1018a1d:	int3
 1018a1e:	int3
 1018a1f:	int3

0000000001018a20 <myl_rc_heap_destroy>:
 1018a20:	push   %rbp
 1018a21:	mov    %rsp,%rbp
 1018a24:	push   %r15
 1018a26:	push   %r14
 1018a28:	push   %rbx
 1018a29:	push   %rax
 1018a2a:	cmpq   $0x0,0x1608(%rdi)
 1018a32:	je     1018d22 <myl_rc_heap_destroy+0x302>
 1018a38:	mov    %rdi,%rbx
 1018a3b:	call   101be30 <myl_rc_drain>
 1018a40:	mov    0x1608(%rbx),%r14
 1018a47:	cmpq   $0x0,0xf8(%r14)
 1018a4f:	jne    1018d2d <myl_rc_heap_destroy+0x30d>
 1018a55:	cmpq   $0x0,0xc0(%r14)
 1018a5d:	jne    1018d2d <myl_rc_heap_destroy+0x30d>
 1018a63:	cmpl   $0x0,0xd0(%r14)
 1018a6b:	jne    1018d2d <myl_rc_heap_destroy+0x30d>
 1018a71:	mov    0x100(%r14),%rdi
 1018a78:	mov    %r14,%rcx
 1018a7b:	test   %rdi,%rdi
 1018a7e:	je     1018ab5 <myl_rc_heap_destroy+0x95>
 1018a80:	lea    0x100(%r14),%rax
 1018a87:	nopw   0x0(%rax,%rax,1)
 1018a90:	mov    (%rdi),%rcx
 1018a93:	mov    %rcx,(%rax)
 1018a96:	call   10276f0 <free@plt>
 1018a9b:	mov    0x1608(%rbx),%rcx
 1018aa2:	lea    0x100(%rcx),%rax
 1018aa9:	mov    0x100(%rcx),%rdi
 1018ab0:	test   %rdi,%rdi
 1018ab3:	jne    1018a90 <myl_rc_heap_destroy+0x70>
 1018ab5:	movq   $0x0,0x108(%rcx)
 1018ac0:	mov    0x10(%r14),%rax
 1018ac4:	test   %rax,%rax
 1018ac7:	je     1018b09 <myl_rc_heap_destroy+0xe9>
 1018ac9:	mov    %rbx,%rdi
 1018acc:	call   *%rax
 1018ace:	jmp    1018b09 <myl_rc_heap_destroy+0xe9>
 1018ad0:	mov    (%rdi),%rax
 1018ad3:	mov    %rax,0x28(%r14)
 1018ad7:	mov    0x30(%rdi),%rcx
 1018adb:	mov    0x18(%rbx),%rax
 1018adf:	sub    %rcx,%rax
 1018ae2:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018ae8:	mov    0x1608(%rbx),%rdx
 1018aef:	mov    0x30(%rdx),%rsi
 1018af3:	sub    %rcx,%rsi
 1018af6:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018afc:	mov    %rax,0x18(%rbx)
 1018b00:	mov    %rsi,0x30(%rdx)
 1018b04:	call   10276f0 <free@plt>
 1018b09:	mov    0x28(%r14),%rdi
 1018b0d:	test   %rdi,%rdi
 1018b10:	jne    1018ad0 <myl_rc_heap_destroy+0xb0>
 1018b12:	mov    0xb0(%r14),%rdi
 1018b19:	test   %rdi,%rdi
 1018b1c:	je     1018b5b <myl_rc_heap_destroy+0x13b>
 1018b1e:	mov    0xb8(%r14),%rax
 1018b25:	shl    $0x3,%rax
 1018b29:	lea    (%rax,%rax,2),%rcx
 1018b2d:	mov    0x18(%rbx),%rax
 1018b31:	sub    %rcx,%rax
 1018b34:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018b3a:	mov    0x1608(%rbx),%rdx
 1018b41:	mov    0x30(%rdx),%rsi
 1018b45:	sub    %rcx,%rsi
 1018b48:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018b4e:	mov    %rax,0x18(%rbx)
 1018b52:	mov    %rsi,0x30(%rdx)
 1018b56:	call   10276f0 <free@plt>
 1018b5b:	mov    0x1608(%rbx),%r15
 1018b62:	mov    0x38(%r15),%rdi
 1018b66:	cmp    $0x100b5f0,%rdi
 1018b6d:	je     1018bad <myl_rc_heap_destroy+0x18d>
 1018b6f:	mov    0x40(%r15),%rax
 1018b73:	cmp    $0xffffffffffffffff,%rax
 1018b77:	je     1018bad <myl_rc_heap_destroy+0x18d>
 1018b79:	test   %rdi,%rdi
 1018b7c:	je     1018bad <myl_rc_heap_destroy+0x18d>
 1018b7e:	shl    $0x4,%rax
 1018b82:	add    $0x10,%rax
 1018b86:	mov    0x18(%rbx),%rcx
 1018b8a:	sub    %rax,%rcx
 1018b8d:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018b93:	mov    0x30(%r15),%rdx
 1018b97:	sub    %rax,%rdx
 1018b9a:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018ba0:	mov    %rcx,0x18(%rbx)
 1018ba4:	mov    %rdx,0x30(%r15)
 1018ba8:	call   10276f0 <free@plt>
 1018bad:	movq   $0x100b5f0,0x38(%r15)
 1018bb5:	vxorps %xmm0,%xmm0,%xmm0
 1018bb9:	vmovups %xmm0,0x40(%r15)
 1018bbf:	movq   $0x3f,0x50(%r15)
 1018bc7:	mov    0x1608(%rbx),%r15
 1018bce:	mov    0x58(%r15),%rdi
 1018bd2:	cmp    $0x100b5f0,%rdi
 1018bd9:	je     1018c1d <myl_rc_heap_destroy+0x1fd>
 1018bdb:	mov    0x60(%r15),%rax
 1018bdf:	cmp    $0xffffffffffffffff,%rax
 1018be3:	je     1018c1d <myl_rc_heap_destroy+0x1fd>
 1018be5:	test   %rdi,%rdi
 1018be8:	je     1018c1d <myl_rc_heap_destroy+0x1fd>
 1018bea:	shl    $0x4,%rax
 1018bee:	add    $0x10,%rax
 1018bf2:	mov    0x18(%rbx),%rcx
 1018bf6:	sub    %rax,%rcx
 1018bf9:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018bff:	mov    0x30(%r15),%rdx
 1018c03:	sub    %rax,%rdx
 1018c06:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018c0c:	mov    %rcx,0x18(%rbx)
 1018c10:	mov    %rdx,0x30(%r15)
 1018c14:	call   10276f0 <free@plt>
 1018c19:	vxorps %xmm0,%xmm0,%xmm0
 1018c1d:	movq   $0x100b5f0,0x58(%r15)
 1018c25:	vmovups %xmm0,0x60(%r15)
 1018c2b:	movq   $0x3f,0x70(%r15)
 1018c33:	mov    0x1608(%rbx),%r15
 1018c3a:	mov    0x78(%r15),%rdi
 1018c3e:	cmp    $0x100b5f0,%rdi
 1018c45:	je     1018c88 <myl_rc_heap_destroy+0x268>
 1018c47:	mov    0x80(%r15),%rax
 1018c4e:	cmp    $0xffffffffffffffff,%rax
 1018c52:	je     1018c88 <myl_rc_heap_destroy+0x268>
 1018c54:	test   %rdi,%rdi
 1018c57:	je     1018c88 <myl_rc_heap_destroy+0x268>
 1018c59:	shl    $0x4,%rax
 1018c5d:	add    $0x10,%rax
 1018c61:	mov    0x18(%rbx),%rcx
 1018c65:	sub    %rax,%rcx
 1018c68:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018c6e:	mov    0x30(%r15),%rdx
 1018c72:	sub    %rax,%rdx
 1018c75:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018c7b:	mov    %rcx,0x18(%rbx)
 1018c7f:	mov    %rdx,0x30(%r15)
 1018c83:	call   10276f0 <free@plt>
 1018c88:	movq   $0x100b5f0,0x78(%r15)
 1018c90:	vxorps %xmm0,%xmm0,%xmm0
 1018c94:	vmovups %xmm0,0x80(%r15)
 1018c9d:	movq   $0x3f,0x90(%r15)
 1018ca8:	mov    0x1608(%rbx),%r15
 1018caf:	mov    0x98(%r15),%rdi
 1018cb6:	test   %rdi,%rdi
 1018cb9:	je     1018ce9 <myl_rc_heap_destroy+0x2c9>
 1018cbb:	mov    0xa0(%r15),%rcx
 1018cc2:	shl    $0x4,%rcx
 1018cc6:	mov    0x18(%rbx),%rax
 1018cca:	sub    %rcx,%rax
 1018ccd:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018ccf:	mov    0x30(%r15),%rdx
 1018cd3:	sub    %rcx,%rdx
 1018cd6:	jb     1018d2d <myl_rc_heap_destroy+0x30d>
 1018cd8:	mov    %rax,0x18(%rbx)
 1018cdc:	mov    %rdx,0x30(%r15)
 1018ce0:	call   10276f0 <free@plt>
 1018ce5:	vxorps %xmm0,%xmm0,%xmm0
 1018ce9:	add    $0x98,%r15
 1018cf0:	vmovups %xmm0,(%r15)
 1018cf5:	movq   $0x0,0x10(%r15)
 1018cfd:	cmpq   $0x128,0x30(%r14)
 1018d05:	jne    1018d2d <myl_rc_heap_destroy+0x30d>
 1018d07:	addq   $0xfffffffffffffed8,0x18(%rbx)
 1018d0f:	mov    %r14,%rdi
 1018d12:	call   10276f0 <free@plt>
 1018d17:	movq   $0x0,0x1608(%rbx)
 1018d22:	add    $0x8,%rsp
 1018d26:	pop    %rbx
 1018d27:	pop    %r14
 1018d29:	pop    %r15
 1018d2b:	pop    %rbp
 1018d2c:	ret
 1018d2d:	call   1018954 <myl_rc_invariant_failed>
 1018d32:	int3
 1018d33:	int3
 1018d34:	int3
 1018d35:	int3
 1018d36:	int3
 1018d37:	int3
 1018d38:	int3
 1018d39:	int3
 1018d3a:	int3
 1018d3b:	int3
 1018d3c:	int3
 1018d3d:	int3
 1018d3e:	int3
 1018d3f:	int3

0000000001018d40 <myl_rc_edge_release>:
 1018d40:	push   %rbp
 1018d41:	mov    %rsp,%rbp
 1018d44:	test   %rsi,%rsi
 1018d47:	je     1018d5c <myl_rc_edge_release+0x1c>
 1018d49:	movabs $0x4000000000000002,%rdx
 1018d53:	mov    -0x10(%rsi),%r9
 1018d57:	test   %rdx,%r9
 1018d5a:	je     1018d5e <myl_rc_edge_release+0x1e>
 1018d5c:	pop    %rbp
 1018d5d:	ret
 1018d5e:	test   %rdi,%rdi
 1018d61:	je     1018e51 <myl_rc_edge_release+0x111>
 1018d67:	cmpq   $0x0,0x1608(%rdi)
 1018d6f:	je     1018e51 <myl_rc_edge_release+0x111>
 1018d75:	test   $0x1,%r9b
 1018d79:	jne    1018e51 <myl_rc_edge_release+0x111>
 1018d7f:	mov    -0x20(%rsi),%rax
 1018d83:	test   %rax,%rax
 1018d86:	je     1018e51 <myl_rc_edge_release+0x111>
 1018d8c:	lea    -0x20(%rsi),%r8
 1018d90:	dec    %rax
 1018d93:	mov    %rax,(%r8)
 1018d96:	jne    1018d5c <myl_rc_edge_release+0x1c>
 1018d98:	cmpq   $0x0,-0x18(%rsi)
 1018d9d:	jne    1018d5c <myl_rc_edge_release+0x1c>
 1018d9f:	or     $0x1,%r9
 1018da3:	mov    %r9,-0x10(%rsi)
 1018da7:	mov    0x1608(%rdi),%rax
 1018dae:	cmpl   $0x0,0xd0(%rax)
 1018db5:	jne    1018dfb <myl_rc_edge_release+0xbb>
 1018db7:	mov    -0x8(%rsi),%rcx
 1018dbb:	cmp    %rcx,0x110(%rax)
 1018dc2:	je     1018e19 <myl_rc_edge_release+0xd9>
 1018dc4:	mov    0x34(%rcx),%r9d
 1018dc8:	cmp    %r9,0xa0(%rax)
 1018dcf:	jbe    1018e33 <myl_rc_edge_release+0xf3>
 1018dd1:	mov    0x98(%rax),%r10
 1018dd8:	shl    $0x4,%r9
 1018ddc:	cmp    %rcx,(%r10,%r9,1)
 1018de0:	jne    1018e33 <myl_rc_edge_release+0xf3>
 1018de2:	add    %r9,%r10
 1018de5:	mov    0x8(%r10),%rax
 1018de9:	test   %rax,%rax
 1018dec:	je     1018df4 <myl_rc_edge_release+0xb4>
 1018dee:	cmpl   $0x0,0x40(%rax)
 1018df2:	je     1018e15 <myl_rc_edge_release+0xd5>
 1018df4:	mov    0x1608(%rdi),%rax
 1018dfb:	mov    0xc8(%rax),%rax
 1018e02:	mov    %rax,(%r8)
 1018e05:	mov    0x1608(%rdi),%rax
 1018e0c:	mov    %r8,0xc8(%rax)
 1018e13:	pop    %rbp
 1018e14:	ret
 1018e15:	mov    -0x10(%rsi),%r9
 1018e19:	inc    %rdx
 1018e1c:	and    %r9,%rdx
 1018e1f:	cmp    $0x1,%rdx
 1018e23:	jne    1018e51 <myl_rc_edge_release+0x111>
 1018e25:	mov    0x1608(%rdi),%rax
 1018e2c:	mov    0x8(%rax),%rax
 1018e30:	pop    %rbp
 1018e31:	jmp    *%rax
 1018e33:	mov    %rdi,%r9
 1018e36:	mov    %rax,%rdi
 1018e39:	mov    %rsi,%r10
 1018e3c:	mov    %rcx,%rsi
 1018e3f:	call   1018f74 <myl_rc_binding_find_slow>
 1018e44:	mov    %r10,%rsi
 1018e47:	mov    %r9,%rdi
 1018e4a:	test   %rax,%rax
 1018e4d:	jne    1018dee <myl_rc_edge_release+0xae>
 1018e4f:	jmp    1018df4 <myl_rc_edge_release+0xb4>
 1018e51:	call   1018954 <myl_rc_invariant_failed>
 1018e56:	int3
 1018e57:	int3
 1018e58:	int3
 1018e59:	int3
 1018e5a:	int3
 1018e5b:	int3
 1018e5c:	int3
 1018e5d:	int3
 1018e5e:	int3
 1018e5f:	int3

0000000001018e60 <myl_rc_hold_edge_release>:
 1018e60:	push   %rbp
 1018e61:	mov    %rsp,%rbp
 1018e64:	test   %rsi,%rsi
 1018e67:	je     1018e7c <myl_rc_hold_edge_release+0x1c>
 1018e69:	movabs $0x4000000000000002,%rdx
 1018e73:	mov    -0x10(%rsi),%r9
 1018e77:	test   %rdx,%r9
 1018e7a:	je     1018e7e <myl_rc_hold_edge_release+0x1e>
 1018e7c:	pop    %rbp
 1018e7d:	ret
 1018e7e:	test   %rdi,%rdi
 1018e81:	je     1018f6f <myl_rc_hold_edge_release+0x10f>
 1018e87:	cmpq   $0x0,0x1608(%rdi)
 1018e8f:	je     1018f6f <myl_rc_hold_edge_release+0x10f>
 1018e95:	test   $0x1,%r9b
 1018e99:	jne    1018f6f <myl_rc_hold_edge_release+0x10f>
 1018e9f:	mov    -0x18(%rsi),%rax
 1018ea3:	test   %rax,%rax
 1018ea6:	je     1018f6f <myl_rc_hold_edge_release+0x10f>
 1018eac:	dec    %rax
 1018eaf:	mov    %rax,-0x18(%rsi)
 1018eb3:	or     -0x20(%rsi),%rax
 1018eb7:	jne    1018e7c <myl_rc_hold_edge_release+0x1c>
 1018eb9:	lea    -0x20(%rsi),%r8
 1018ebd:	or     $0x1,%r9
 1018ec1:	mov    %r9,-0x10(%rsi)
 1018ec5:	mov    0x1608(%rdi),%rax
 1018ecc:	cmpl   $0x0,0xd0(%rax)
 1018ed3:	jne    1018f19 <myl_rc_hold_edge_release+0xb9>
 1018ed5:	mov    -0x8(%rsi),%rcx
 1018ed9:	cmp    %rcx,0x110(%rax)
 1018ee0:	je     1018f37 <myl_rc_hold_edge_release+0xd7>
 1018ee2:	mov    0x34(%rcx),%r9d
 1018ee6:	cmp    %r9,0xa0(%rax)
 1018eed:	jbe    1018f51 <myl_rc_hold_edge_release+0xf1>
 1018eef:	mov    0x98(%rax),%r10
 1018ef6:	shl    $0x4,%r9
 1018efa:	cmp    %rcx,(%r10,%r9,1)
 1018efe:	jne    1018f51 <myl_rc_hold_edge_release+0xf1>
 1018f00:	add    %r9,%r10
 1018f03:	mov    0x8(%r10),%rax
 1018f07:	test   %rax,%rax
 1018f0a:	je     1018f12 <myl_rc_hold_edge_release+0xb2>
 1018f0c:	cmpl   $0x0,0x40(%rax)
 1018f10:	je     1018f33 <myl_rc_hold_edge_release+0xd3>
 1018f12:	mov    0x1608(%rdi),%rax
 1018f19:	mov    0xc8(%rax),%rax
 1018f20:	mov    %rax,(%r8)
 1018f23:	mov    0x1608(%rdi),%rax
 1018f2a:	mov    %r8,0xc8(%rax)
 1018f31:	pop    %rbp
 1018f32:	ret
 1018f33:	mov    -0x10(%rsi),%r9
 1018f37:	inc    %rdx
 1018f3a:	and    %r9,%rdx
 1018f3d:	cmp    $0x1,%rdx
 1018f41:	jne    1018f6f <myl_rc_hold_edge_release+0x10f>
 1018f43:	mov    0x1608(%rdi),%rax
 1018f4a:	mov    0x8(%rax),%rax
 1018f4e:	pop    %rbp
 1018f4f:	jmp    *%rax
 1018f51:	mov    %rdi,%r9
 1018f54:	mov    %rax,%rdi
 1018f57:	mov    %rsi,%r10
 1018f5a:	mov    %rcx,%rsi
 1018f5d:	call   1018f74 <myl_rc_binding_find_slow>
 1018f62:	mov    %r10,%rsi
 1018f65:	mov    %r9,%rdi
 1018f68:	test   %rax,%rax
 1018f6b:	jne    1018f0c <myl_rc_hold_edge_release+0xac>
 1018f6d:	jmp    1018f12 <myl_rc_hold_edge_release+0xb2>
 1018f6f:	call   1018954 <myl_rc_invariant_failed>

0000000001018f74 <myl_rc_binding_find_slow>:
 1018f74:	push   %rbp
 1018f75:	mov    %rsp,%rbp
 1018f78:	push   %r10
 1018f7a:	push   %r9
 1018f7c:	push   %r8
 1018f7e:	push   %rdi
 1018f7f:	push   %rsi
 1018f80:	push   %rdx
 1018f81:	push   %rcx
 1018f82:	push   %r15
 1018f84:	push   %r14
 1018f86:	push   %rbx
 1018f87:	mov    %rsi,%rbx
 1018f8a:	mov    0x34(%rsi),%eax
 1018f8d:	cmp    %rax,0xa0(%rdi)
 1018f94:	jbe    1018fb3 <myl_rc_binding_find_slow+0x3f>
 1018f96:	mov    0x98(%rdi),%r11
 1018f9d:	shl    $0x4,%rax
 1018fa1:	lea    (%r11,%rax,1),%r15
 1018fa5:	mov    (%r11,%rax,1),%rax
 1018fa9:	cmp    %rbx,%rax
 1018fac:	je     1019014 <myl_rc_binding_find_slow+0xa0>
 1018fae:	test   %rax,%rax
 1018fb1:	je     101902c <myl_rc_binding_find_slow+0xb8>
 1018fb3:	mov    0x78(%rdi),%rax
 1018fb7:	mov    0x80(%rdi),%rcx
 1018fbe:	mov    0x90(%rdi),%r11b
 1018fc5:	movabs $0x9e3779b97f4a7c15,%rdx
 1018fcf:	imul   %rbx,%rdx
 1018fd3:	shrx   %r11,%rdx,%r11
 1018fd8:	and    %rcx,%r11
 1018fdb:	mov    %r11,%rdx
 1018fde:	shl    $0x4,%rdx
 1018fe2:	mov    (%rax,%rdx,1),%rdx
 1018fe6:	cmp    %rbx,%rdx
 1018fe9:	je     1019009 <myl_rc_binding_find_slow+0x95>
 1018feb:	xor    %r14d,%r14d
 1018fee:	test   %rdx,%rdx
 1018ff1:	je     1019018 <myl_rc_binding_find_slow+0xa4>
 1018ff3:	inc    %r11
 1018ff6:	and    %rcx,%r11
 1018ff9:	mov    %r11,%rdx
 1018ffc:	shl    $0x4,%rdx
 1019000:	mov    (%rax,%rdx,1),%rdx
 1019004:	cmp    %rbx,%rdx
 1019007:	jne    1018fee <myl_rc_binding_find_slow+0x7a>
 1019009:	shl    $0x4,%r11
 101900d:	mov    0x8(%rax,%r11,1),%r14
 1019012:	jmp    1019018 <myl_rc_binding_find_slow+0xa4>
 1019014:	mov    0x8(%r15),%r14
 1019018:	mov    %r14,%rax
 101901b:	pop    %rbx
 101901c:	pop    %r14
 101901e:	pop    %r15
 1019020:	pop    %rcx
 1019021:	pop    %rdx
 1019022:	pop    %rsi
 1019023:	pop    %rdi
 1019024:	pop    %r8
 1019026:	pop    %r9
 1019028:	pop    %r10
 101902a:	pop    %rbp
 101902b:	ret
 101902c:	mov    0x8(%r15),%r14
 1019030:	test   %r14,%r14
 1019033:	je     1018fb3 <myl_rc_binding_find_slow+0x3f>
 1019039:	cmp    %rbx,(%r14)
 101903c:	jne    1018fb3 <myl_rc_binding_find_slow+0x3f>
 1019042:	mov    %r14,%rdi
 1019045:	call   1019050 <flat_build>
 101904a:	mov    %rbx,(%r15)
 101904d:	jmp    1019018 <myl_rc_binding_find_slow+0xa4>
 101904f:	int3

0000000001019050 <flat_build>:
 1019050:	push   %rbp
 1019051:	mov    %rsp,%rbp
 1019054:	push   %r15
 1019056:	push   %r14
 1019058:	push   %r13
 101905a:	push   %r12
 101905c:	push   %rbx
 101905d:	sub    $0x368,%rsp
 1019064:	movl   $0x11,0x40(%rdi)
 101906b:	movw   $0x0,0x44(%rdi)
 1019071:	movb   $0x0,0x46(%rdi)
 1019075:	mov    (%rdi),%r14
 1019078:	mov    (%r14),%rax
 101907b:	mov    %rax,0x50(%rdi)
 101907f:	cmpq   $0x0,0x10(%rdi)
 1019084:	jne    10190a9 <flat_build+0x59>
 1019086:	cmpq   $0x0,0x18(%rdi)
 101908b:	jne    10190a9 <flat_build+0x59>
 101908d:	cmpq   $0x0,0x20(%rdi)
 1019092:	jne    10190a9 <flat_build+0x59>
 1019094:	cmpq   $0x0,0x28(%rdi)
 1019099:	jne    10190a9 <flat_build+0x59>
 101909b:	cmpq   $0x0,0x30(%rdi)
 10190a0:	jne    10190a9 <flat_build+0x59>
 10190a2:	cmpq   $0x0,0x38(%rdi)
 10190a7:	je     10190bb <flat_build+0x6b>
 10190a9:	add    $0x368,%rsp
 10190b0:	pop    %rbx
 10190b1:	pop    %r12
 10190b3:	pop    %r13
 10190b5:	pop    %r14
 10190b7:	pop    %r15
 10190b9:	pop    %rbp
 10190ba:	ret
 10190bb:	lea    0x40(%rdi),%rax
 10190bf:	mov    %rax,-0x48(%rbp)
 10190c3:	lea    -0x380(%rbp),%rax
 10190ca:	mov    $0x270,%edx
 10190cf:	mov    %rdi,-0x38(%rbp)
 10190d3:	mov    %rax,%rdi
 10190d6:	xor    %esi,%esi
 10190d8:	call   1027650 <memset@plt>
 10190dd:	mov    %r14,-0x390(%rbp)
 10190e4:	mov    -0x38(%rbp),%rax
 10190e8:	mov    0x8(%rax),%rax
 10190ec:	mov    %rax,-0x388(%rbp)
 10190f3:	movl   $0xffffffff,-0x370(%rbp)
 10190fd:	mov    $0x1,%r12b
 1019100:	mov    $0x1,%ecx
 1019105:	mov    $0xc1,%esi
 101910a:	xor    %r14d,%r14d
 101910d:	xor    %ebx,%ebx
 101910f:	cmp    $0x9,%rcx
 1019113:	movzbl %r12b,%r12d
 1019117:	mov    $0x0,%eax
 101911c:	cmovae %eax,%r12d
 1019120:	dec    %rsi
 1019123:	je     10190a9 <flat_build+0x59>
 1019125:	lea    (%rcx,%rcx,4),%rax
 1019129:	mov    -0x3b8(%rbp,%rax,8),%r8
 1019131:	test   %r8,%r8
 1019134:	je     10190a9 <flat_build+0x59>
 101913a:	mov    -0x3b0(%rbp,%rax,8),%r11
 1019142:	test   %r11,%r11
 1019145:	je     1019159 <flat_build+0x109>
 1019147:	mov    (%r8),%rdx
 101914a:	cmp    (%r11),%rdx
 101914d:	jne    10190a9 <flat_build+0x59>
 1019153:	mov    0x8(%r11),%r13d
 1019157:	jmp    101915c <flat_build+0x10c>
 1019159:	xor    %r13d,%r13d
 101915c:	movzwl 0x30(%r8),%edx
 1019161:	cmp    $0x7,%edx
 1019164:	je     101917e <flat_build+0x12e>
 1019166:	lea    -0x390(,%rax,8),%rdi
 101916e:	add    %rbp,%rdi
 1019171:	cmp    $0x1,%edx
 1019174:	je     1019188 <flat_build+0x138>
 1019176:	test   %edx,%edx
 1019178:	jne    1019200 <flat_build+0x1b0>
 101917e:	test   %r13d,%r13d
 1019181:	je     10191ef <flat_build+0x19f>
 1019183:	jmp    10190a9 <flat_build+0x59>
 1019188:	cmpw   $0x5,0x32(%r8)
 101918e:	jne    10191a2 <flat_build+0x152>
 1019190:	cmpq   $0x0,0x38(%r8)
 1019195:	movzbl %r12b,%r12d
 1019199:	mov    $0x0,%eax
 101919e:	cmovne %eax,%r12d
 10191a2:	cmp    $0x1,%r13d
 10191a6:	jne    10190a9 <flat_build+0x59>
 10191ac:	cmpq   $0x8,(%r8)
 10191b0:	jne    10190a9 <flat_build+0x59>
 10191b6:	cmp    $0x10,%r14d
 10191ba:	je     10190a9 <flat_build+0x59>
 10191c0:	mov    -0x18(%rdi),%rax
 10191c4:	mov    $0xfffffff7,%edx
 10191c9:	cmp    %rdx,%rax
 10191cc:	ja     10190a9 <flat_build+0x59>
 10191d2:	mov    %r14d,%edx
 10191d5:	inc    %r14d
 10191d8:	lea    (%rdx,%rdx,2),%rdx
 10191dc:	mov    %eax,-0x110(%rbp,%rdx,4)
 10191e3:	mov    -0x8(%rdi),%rax
 10191e7:	mov    %rax,-0x10c(%rbp,%rdx,4)
 10191ef:	dec    %rcx
 10191f2:	test   %rcx,%rcx
 10191f5:	jne    101910f <flat_build+0xbf>
 10191fb:	jmp    1019454 <flat_build+0x404>
 1019200:	mov    -0x8(%rdi),%eax
 1019203:	mov    %rax,-0x30(%rbp)
 1019207:	mov    -0x4(%rdi),%r9d
 101920b:	cmp    $0x4,%edx
 101920e:	je     101931c <flat_build+0x2cc>
 1019214:	cmp    $0x3,%edx
 1019217:	je     1019293 <flat_build+0x243>
 1019219:	cmp    $0x2,%edx
 101921c:	jne    10190a9 <flat_build+0x59>
 1019222:	test   $0xfffffffd,%r13d
 1019229:	jne    10190a9 <flat_build+0x59>
 101922f:	mov    0x18(%r8),%rdx
 1019233:	cmp    $0x2,%r13d
 1019237:	jne    1019243 <flat_build+0x1f3>
 1019239:	cmp    0x18(%r11),%rdx
 101923d:	jne    10190a9 <flat_build+0x59>
 1019243:	mov    -0x10(%rdi),%rax
 1019247:	cmp    %rdx,%rax
 101924a:	je     10191ef <flat_build+0x19f>
 101924c:	mov    0x10(%r8),%r10
 1019250:	test   %r10,%r10
 1019253:	je     10190a9 <flat_build+0x59>
 1019259:	lea    0x1(%rax),%rdx
 101925d:	mov    %rdx,-0x10(%rdi)
 1019261:	lea    (%rax,%rax,2),%rdx
 1019265:	mov    (%r10,%rdx,8),%rax
 1019269:	mov    0x8(%r10,%rdx,8),%r15
 101926e:	cmp    $0x2,%r13d
 1019272:	jne    10193d1 <flat_build+0x381>
 1019278:	mov    0x10(%r11),%r10
 101927c:	cmp    (%r10,%rdx,8),%rax
 1019280:	jne    10190a9 <flat_build+0x59>
 1019286:	lea    (%r10,%rdx,8),%rdx
 101928a:	mov    0x8(%rdx),%rdx
 101928e:	jmp    10193db <flat_build+0x38b>
 1019293:	cmp    $0x3,%r13d
 1019297:	je     10192a2 <flat_build+0x252>
 1019299:	test   %r13d,%r13d
 101929c:	jne    10190a9 <flat_build+0x59>
 10192a2:	mov    0x20(%r8),%rdx
 10192a6:	cmp    $0x3,%r13d
 10192aa:	jne    10192c4 <flat_build+0x274>
 10192ac:	cmp    0x18(%r11),%rdx
 10192b0:	jne    10190a9 <flat_build+0x59>
 10192b6:	mov    0x28(%r8),%rax
 10192ba:	cmp    0x20(%r11),%rax
 10192be:	jne    10190a9 <flat_build+0x59>
 10192c4:	mov    -0x10(%rdi),%rax
 10192c8:	cmp    %rdx,%rax
 10192cb:	je     10191ef <flat_build+0x19f>
 10192d1:	mov    0x38(%r8),%r15
 10192d5:	test   %r15,%r15
 10192d8:	jne    10192f7 <flat_build+0x2a7>
 10192da:	cmpq   $0x1,0x18(%r8)
 10192df:	jne    10192f4 <flat_build+0x2a4>
 10192e1:	mov    0x10(%r8),%rdx
 10192e5:	test   %rdx,%rdx
 10192e8:	je     10192f4 <flat_build+0x2a4>
 10192ea:	cmpq   $0x0,(%rdx)
 10192ee:	je     1019439 <flat_build+0x3e9>
 10192f4:	xor    %r15d,%r15d
 10192f7:	lea    0x1(%rax),%rdx
 10192fb:	mov    %rdx,-0x10(%rdi)
 10192ff:	mulq   0x28(%r8)
 1019303:	jo     10190a9 <flat_build+0x59>
 1019309:	cmp    $0x3,%r13d
 101930d:	jne    10193d1 <flat_build+0x381>
 1019313:	mov    0x10(%r11),%rdx
 1019317:	jmp    10193db <flat_build+0x38b>
 101931c:	test   $0xfffffffb,%r13d
 1019323:	jne    10190a9 <flat_build+0x59>
 1019329:	mov    -0x10(%rdi),%rax
 101932d:	mov    0x18(%r8),%r10
 1019331:	cmp    %r10,%rax
 1019334:	je     10191ef <flat_build+0x19f>
 101933a:	mov    0x10(%r8),%rdx
 101933e:	test   %rdx,%rdx
 1019341:	je     10190a9 <flat_build+0x59>
 1019347:	mov    %rbx,-0x40(%rbp)
 101934b:	lea    0x1(%rax),%rbx
 101934f:	mov    %rbx,-0x10(%rdi)
 1019353:	lea    (%rax,%rax,2),%rbx
 1019357:	mov    (%rdx,%rbx,8),%rax
 101935b:	mov    0x8(%rdx,%rbx,8),%r15
 1019360:	cmp    $0x4,%r13d
 1019364:	jne    10193d5 <flat_build+0x385>
 1019366:	cmp    0x18(%r11),%r10
 101936a:	jne    10190a9 <flat_build+0x59>
 1019370:	cmpl   $0xffffffff,-0x30(%rbp)
 1019374:	jne    10190a9 <flat_build+0x59>
 101937a:	lea    0x0(,%rbx,8),%r13
 1019382:	add    0x10(%r11),%r13
 1019386:	cmp    0x0(%r13),%rax
 101938a:	jne    10190a9 <flat_build+0x59>
 1019390:	lea    (%rdx,%rbx,8),%rdx
 1019394:	mov    0x10(%rdx),%edx
 1019397:	cmp    0x10(%r13),%edx
 101939b:	jne    10190a9 <flat_build+0x59>
 10193a1:	mov    %edx,%r9d
 10193a4:	mov    -0x18(%rdi),%rdx
 10193a8:	add    0x20(%r11),%rdx
 10193ac:	mov    %rdx,-0x30(%rbp)
 10193b0:	jb     10190a9 <flat_build+0x59>
 10193b6:	mov    $0xfffffff7,%edx
 10193bb:	add    $0x4,%rdx
 10193bf:	cmp    %rdx,-0x30(%rbp)
 10193c3:	ja     10190a9 <flat_build+0x59>
 10193c9:	mov    0x8(%r13),%rdx
 10193cd:	mov    $0x1,%bl
 10193cf:	jmp    10193db <flat_build+0x38b>
 10193d1:	xor    %edx,%edx
 10193d3:	jmp    10193db <flat_build+0x38b>
 10193d5:	xor    %edx,%edx
 10193d7:	mov    -0x40(%rbp),%rbx
 10193db:	cmp    $0x10,%rcx
 10193df:	je     10190a9 <flat_build+0x59>
 10193e5:	test   %r15,%r15
 10193e8:	je     10190a9 <flat_build+0x59>
 10193ee:	mov    (%r8),%r8
 10193f1:	sub    %rax,%r8
 10193f4:	jb     10190a9 <flat_build+0x59>
 10193fa:	cmp    %r8,(%r15)
 10193fd:	ja     10190a9 <flat_build+0x59>
 1019403:	add    -0x18(%rdi),%rax
 1019407:	jb     10190a9 <flat_build+0x59>
 101940d:	inc    %rcx
 1019410:	mov    %r15,(%rdi)
 1019413:	mov    %rdx,0x8(%rdi)
 1019417:	mov    %rax,0x10(%rdi)
 101941b:	movq   $0x0,0x18(%rdi)
 1019423:	mov    -0x30(%rbp),%rax
 1019427:	mov    %eax,0x20(%rdi)
 101942a:	mov    %r9d,0x24(%rdi)
 101942e:	test   %rcx,%rcx
 1019431:	jne    101910f <flat_build+0xbf>
 1019437:	jmp    1019454 <flat_build+0x404>
 1019439:	mov    0x8(%rdx),%r15
 101943d:	lea    0x1(%rax),%rdx
 1019441:	mov    %rdx,-0x10(%rdi)
 1019445:	mulq   0x28(%r8)
 1019449:	jno    1019309 <flat_build+0x2b9>
 101944f:	jmp    10190a9 <flat_build+0x59>
 1019454:	lea    -0x110(%rbp),%rdi
 101945b:	mov    %r14d,%esi
 101945e:	call   10194a0 <flat_disjoint>
 1019463:	test   %eax,%eax
 1019465:	je     10190a9 <flat_build+0x59>
 101946b:	lea    -0x110(%rbp),%rsi
 1019472:	mov    -0x48(%rbp),%rdi
 1019476:	mov    %r14d,%edx
 1019479:	call   1019590 <flat_masks>
 101947e:	mov    -0x38(%rbp),%rcx
 1019482:	test   %eax,%eax
 1019484:	je     10190a9 <flat_build+0x59>
 101948a:	mov    %r14d,0x40(%rcx)
 101948e:	mov    %r12b,0x44(%rcx)
 1019492:	mov    %bl,0x46(%rcx)
 1019495:	jmp    10190a9 <flat_build+0x59>
 101949a:	int3
 101949b:	int3
 101949c:	int3
 101949d:	int3
 101949e:	int3
 101949f:	int3

00000000010194a0 <flat_disjoint>:
 10194a0:	mov    $0x1,%eax
 10194a5:	test   %esi,%esi
 10194a7:	je     101958a <flat_disjoint+0xea>
 10194ad:	push   %rbp
 10194ae:	mov    %rsp,%rbp
 10194b1:	push   %r15
 10194b3:	push   %r14
 10194b5:	push   %r13
 10194b7:	push   %r12
 10194b9:	push   %rbx
 10194ba:	mov    %esi,%ecx
 10194bc:	lea    0x8(%rdi),%rdx
 10194c0:	xor    %esi,%esi
 10194c2:	mov    $0xffffffff,%r8d
 10194c8:	lea    (%rsi,%rsi,2),%r9
 10194cc:	lea    (%rdi,%r9,4),%r9
 10194d0:	mov    %rdx,%r10
 10194d3:	xor    %r11d,%r11d
 10194d6:	jmp    10194f0 <flat_disjoint+0x50>
 10194d8:	nopl   0x0(%rax,%rax,1)
 10194e0:	inc    %r11
 10194e3:	add    $0xc,%r10
 10194e7:	cmp    %r11,%rcx
 10194ea:	je     1019570 <flat_disjoint+0xd0>
 10194f0:	cmp    %r11,%rsi
 10194f3:	jae    101952c <flat_disjoint+0x8c>
 10194f5:	mov    0x4(%r9),%ebx
 10194f9:	cmp    $0xffffffff,%ebx
 10194fc:	je     1019510 <flat_disjoint+0x70>
 10194fe:	cmp    -0x4(%r10),%ebx
 1019502:	jne    1019510 <flat_disjoint+0x70>
 1019504:	mov    0x8(%r9),%ebx
 1019508:	cmp    (%r10),%ebx
 101950b:	jne    101952c <flat_disjoint+0x8c>
 101950d:	nopl   (%rax)
 1019510:	mov    (%r9),%ebx
 1019513:	mov    -0x8(%r10),%r14d
 1019517:	mov    %ebx,%r15d
 101951a:	sub    %r14d,%r15d
 101951d:	neg    %r15d
 1019520:	sub    %r14d,%ebx
 1019523:	cmovb  %r15,%rbx
 1019527:	cmp    $0x8,%ebx
 101952a:	jb     101957e <flat_disjoint+0xde>
 101952c:	mov    -0x4(%r10),%ebx
 1019530:	cmp    %r8,%rbx
 1019533:	je     10194e0 <flat_disjoint+0x40>
 1019535:	mov    (%r9),%r14d
 1019538:	mov    %r14d,%r15d
 101953b:	sub    %ebx,%r15d
 101953e:	mov    %r15d,%r12d
 1019541:	neg    %r12d
 1019544:	xor    %r13d,%r13d
 1019547:	cmp    $0x8,%r12d
 101954b:	setae  %r13b
 101954f:	xor    %r12d,%r12d
 1019552:	cmp    $0x4,%r15d
 1019556:	setae  %r12b
 101955a:	cmp    %ebx,%r14d
 101955d:	cmovae %r12d,%r13d
 1019561:	cmp    $0x1,%r13b
 1019565:	je     10194e0 <flat_disjoint+0x40>
 101956b:	jmp    101957e <flat_disjoint+0xde>
 101956d:	nopl   (%rax)
 1019570:	inc    %rsi
 1019573:	cmp    %rcx,%rsi
 1019576:	jne    10194c8 <flat_disjoint+0x28>
 101957c:	jmp    1019580 <flat_disjoint+0xe0>
 101957e:	xor    %eax,%eax
 1019580:	pop    %rbx
 1019581:	pop    %r12
 1019583:	pop    %r13
 1019585:	pop    %r14
 1019587:	pop    %r15
 1019589:	pop    %rbp
 101958a:	ret
 101958b:	int3
 101958c:	int3
 101958d:	int3
 101958e:	int3
 101958f:	int3

0000000001019590 <flat_masks>:
 1019590:	push   %rbp
 1019591:	mov    %rsp,%rbp
 1019594:	push   %r14
 1019596:	push   %rbx
 1019597:	mov    $0xffffffff,%ecx
 101959c:	test   %edx,%edx
 101959e:	je     10195fb <flat_masks+0x6b>
 10195a0:	mov    %edx,%r9d
 10195a3:	lea    0x8(%rsi),%r11
 10195a7:	mov    $0xffffffff,%r14d
 10195ad:	xor    %ebx,%ebx
 10195af:	xor    %r8d,%r8d
 10195b2:	jmp    10195d6 <flat_masks+0x46>
 10195b4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10195c0:	bts    %ebx,%r8d
 10195c4:	mov    %r14d,%r10d
 10195c7:	inc    %rbx
 10195ca:	add    $0xc,%r11
 10195ce:	mov    %r10d,%r14d
 10195d1:	cmp    %rbx,%r9
 10195d4:	je     1019606 <flat_masks+0x76>
 10195d6:	mov    -0x4(%r11),%r10d
 10195da:	cmp    $0xffffffff,%r10d
 10195de:	je     10195c0 <flat_masks+0x30>
 10195e0:	xor    %eax,%eax
 10195e2:	cmp    $0xffffffff,%r14d
 10195e6:	je     10195ed <flat_masks+0x5d>
 10195e8:	cmp    %r10d,%r14d
 10195eb:	jne    10195f3 <flat_masks+0x63>
 10195ed:	cmpl   $0x1f,(%r11)
 10195f1:	jbe    10195c7 <flat_masks+0x37>
 10195f3:	pop    %rbx
 10195f4:	pop    %r14
 10195f6:	pop    %rbp
 10195f7:	vzeroupper
 10195fa:	ret
 10195fb:	xor    %r8d,%r8d
 10195fe:	mov    $0xffffffff,%r10d
 1019604:	jmp    101962e <flat_masks+0x9e>
 1019606:	xor    %eax,%eax
 1019608:	mov    %rsi,%r11
 101960b:	xor    %ebx,%ebx
 101960d:	nopl   (%rax)
 1019610:	mov    (%r11),%r14d
 1019613:	cmp    $0xfff7,%r14d
 101961a:	ja     10195f3 <flat_masks+0x63>
 101961c:	mov    %r14w,0x5c(%rdi,%rbx,2)
 1019622:	inc    %rbx
 1019625:	add    $0xc,%r11
 1019629:	cmp    %rbx,%r9
 101962c:	jne    1019610 <flat_masks+0x80>
 101962e:	shlx   %edx,%ecx,%eax
 1019633:	not    %eax
 1019635:	mov    %ax,0x18(%rdi)
 1019639:	mov    %r10d,0x8(%rdi)
 101963d:	vmovd  %r8d,%xmm0
 1019642:	vpbroadcastw %xmm0,%ymm0
 1019647:	vmovdqu %ymm0,0x1a(%rdi)
 101964c:	vmovdqu %ymm0,0x3a(%rdi)
 1019651:	mov    %r8w,0x5a(%rdi)
 1019656:	mov    $0x1,%eax
 101965b:	test   %edx,%edx
 101965d:	je     10195f3 <flat_masks+0x63>
 101965f:	cmp    $0x1,%edx
 1019662:	jne    1019668 <flat_masks+0xd8>
 1019664:	xor    %ecx,%ecx
 1019666:	jmp    10196cc <flat_masks+0x13c>
 1019668:	mov    %edx,%edx
 101966a:	mov    %edx,%eax
 101966c:	and    $0xfffffffe,%eax
 101966f:	lea    0x14(%rsi),%r8
 1019673:	xor    %ecx,%ecx
 1019675:	mov    $0x1,%r9d
 101967b:	jmp    101968d <flat_masks+0xfd>
 101967d:	nopl   (%rax)
 1019680:	add    $0x2,%rcx
 1019684:	add    $0x18,%r8
 1019688:	cmp    %rcx,%rax
 101968b:	je     10196be <flat_masks+0x12e>
 101968d:	cmpl   $0xffffffff,-0x10(%r8)
 1019692:	je     10196a3 <flat_masks+0x113>
 1019694:	shlx   %ecx,%r9d,%r10d
 1019699:	mov    -0xc(%r8),%r11d
 101969d:	or     %r10w,0x1c(%rdi,%r11,2)
 10196a3:	cmpl   $0xffffffff,-0x4(%r8)
 10196a8:	je     1019680 <flat_masks+0xf0>
 10196aa:	lea    0x1(%rcx),%r10d
 10196ae:	shlx   %r10d,%r9d,%r10d
 10196b3:	mov    (%r8),%r11d
 10196b6:	or     %r10w,0x1c(%rdi,%r11,2)
 10196bc:	jmp    1019680 <flat_masks+0xf0>
 10196be:	mov    $0x1,%eax
 10196c3:	test   $0x1,%dl
 10196c6:	je     10195f3 <flat_masks+0x63>
 10196cc:	lea    (%rcx,%rcx,2),%rdx
 10196d0:	cmpl   $0xffffffff,0x4(%rsi,%rdx,4)
 10196d5:	mov    $0x1,%eax
 10196da:	je     10195f3 <flat_masks+0x63>
 10196e0:	lea    (%rsi,%rdx,4),%rdx
 10196e4:	mov    $0x1,%eax
 10196e9:	shlx   %ecx,%eax,%ecx
 10196ee:	mov    0x8(%rdx),%edx
 10196f1:	or     %cx,0x1c(%rdi,%rdx,2)
 10196f6:	pop    %rbx
 10196f7:	pop    %r14
 10196f9:	pop    %rbp
 10196fa:	vzeroupper
 10196fd:	ret
 10196fe:	int3
 10196ff:	int3

0000000001019700 <myl_rc_module_register>:
 1019700:	push   %rbp
 1019701:	mov    %rsp,%rbp
 1019704:	push   %r15
 1019706:	push   %r14
 1019708:	push   %r12
 101970a:	push   %rbx
 101970b:	sub    $0x30,%rsp
 101970f:	test   %rdi,%rdi
 1019712:	je     101991c <myl_rc_module_register+0x21c>
 1019718:	mov    %rsi,%rbx
 101971b:	test   %rsi,%rsi
 101971e:	je     101991c <myl_rc_module_register+0x21c>
 1019724:	mov    0x1608(%rdi),%rcx
 101972b:	test   %rcx,%rcx
 101972e:	je     101991c <myl_rc_module_register+0x21c>
 1019734:	cmpl   $0x5,(%rbx)
 1019737:	jne    101991c <myl_rc_module_register+0x21c>
 101973d:	cmpq   $0x0,0xc0(%rcx)
 1019745:	jne    101991c <myl_rc_module_register+0x21c>
 101974b:	mov    0x38(%rcx),%rax
 101974f:	mov    0x40(%rcx),%rdx
 1019753:	movzbl 0x50(%rcx),%ecx
 1019757:	movabs $0x9e3779b97f4a7c15,%rsi
 1019761:	imul   %rbx,%rsi
 1019765:	shrx   %rcx,%rsi,%rcx
 101976a:	nopw   0x0(%rax,%rax,1)
 1019770:	and    %rdx,%rcx
 1019773:	mov    %rcx,%rsi
 1019776:	shl    $0x4,%rsi
 101977a:	mov    (%rax,%rsi,1),%rsi
 101977e:	cmp    %rbx,%rsi
 1019781:	je     101978d <myl_rc_module_register+0x8d>
 1019783:	test   %rsi,%rsi
 1019786:	je     10197a0 <myl_rc_module_register+0xa0>
 1019788:	inc    %rcx
 101978b:	jmp    1019770 <myl_rc_module_register+0x70>
 101978d:	shl    $0x4,%rcx
 1019791:	xor    %r14d,%r14d
 1019794:	cmpq   $0x0,0x8(%rax,%rcx,1)
 101979a:	jne    101990c <myl_rc_module_register+0x20c>
 10197a0:	mov    0x10(%rbx),%rax
 10197a4:	test   %rax,%rax
 10197a7:	je     10197b4 <myl_rc_module_register+0xb4>
 10197a9:	cmpq   $0x0,0x8(%rbx)
 10197ae:	je     101991c <myl_rc_module_register+0x21c>
 10197b4:	mov    0x20(%rbx),%rcx
 10197b8:	test   %rcx,%rcx
 10197bb:	je     10197c8 <myl_rc_module_register+0xc8>
 10197bd:	cmpq   $0x0,0x18(%rbx)
 10197c2:	je     101991c <myl_rc_module_register+0x21c>
 10197c8:	vxorps %xmm0,%xmm0,%xmm0
 10197cc:	vmovups %ymm0,-0x48(%rbp)
 10197d1:	movq   $0x0,-0x28(%rbp)
 10197d9:	mov    %rdi,-0x50(%rbp)
 10197dd:	test   %rax,%rax
 10197e0:	je     1019818 <myl_rc_module_register+0x118>
 10197e2:	xor    %r15d,%r15d
 10197e5:	lea    -0x50(%rbp),%r14
 10197e9:	nopl   0x0(%rax)
 10197f0:	mov    0x8(%rbx),%rax
 10197f4:	mov    (%rax,%r15,8),%rsi
 10197f8:	mov    %r14,%rdi
 10197fb:	vzeroupper
 10197fe:	call   1019930 <builder_add>
 1019803:	test   %eax,%eax
 1019805:	je     1019890 <myl_rc_module_register+0x190>
 101980b:	inc    %r15
 101980e:	cmp    0x10(%rbx),%r15
 1019812:	jb     10197f0 <myl_rc_module_register+0xf0>
 1019814:	mov    0x20(%rbx),%rcx
 1019818:	test   %rcx,%rcx
 101981b:	je     1019877 <myl_rc_module_register+0x177>
 101981d:	mov    $0x8,%r15d
 1019823:	xor    %r12d,%r12d
 1019826:	lea    -0x50(%rbp),%r14
 101982a:	nopw   0x0(%rax,%rax,1)
 1019830:	mov    0x18(%rbx),%rcx
 1019834:	mov    -0x8(%rcx,%r15,1),%rax
 1019839:	test   %rax,%rax
 101983c:	je     101991c <myl_rc_module_register+0x21c>
 1019842:	mov    (%rcx,%r15,1),%rsi
 1019846:	test   %rsi,%rsi
 1019849:	je     101991c <myl_rc_module_register+0x21c>
 101984f:	mov    (%rax),%rax
 1019852:	cmp    (%rsi),%rax
 1019855:	jne    101991c <myl_rc_module_register+0x21c>
 101985b:	mov    %r14,%rdi
 101985e:	vzeroupper
 1019861:	call   1019930 <builder_add>
 1019866:	test   %eax,%eax
 1019868:	je     1019890 <myl_rc_module_register+0x190>
 101986a:	inc    %r12
 101986d:	add    $0x40,%r15
 1019871:	cmp    0x20(%rbx),%r12
 1019875:	jb     1019830 <myl_rc_module_register+0x130>
 1019877:	lea    -0x50(%rbp),%rdi
 101987b:	mov    %rbx,%rsi
 101987e:	mov    $0x1,%edx
 1019883:	vzeroupper
 1019886:	call   1019d40 <register_shapes>
 101988b:	mov    %eax,%r14d
 101988e:	jmp    1019896 <myl_rc_module_register+0x196>
 1019890:	mov    $0x1,%r14d
 1019896:	mov    -0x50(%rbp),%rbx
 101989a:	mov    -0x48(%rbp),%rdi
 101989e:	mov    -0x30(%rbp),%r15
 10198a2:	test   %rdi,%rdi
 10198a5:	je     10198d9 <myl_rc_module_register+0x1d9>
 10198a7:	lea    0x0(,%r15,8),%rax
 10198af:	lea    (%rax,%rax,4),%rcx
 10198b3:	mov    0x18(%rbx),%rax
 10198b7:	sub    %rcx,%rax
 10198ba:	jb     101991c <myl_rc_module_register+0x21c>
 10198bc:	mov    0x1608(%rbx),%rdx
 10198c3:	mov    0x30(%rdx),%rsi
 10198c7:	sub    %rcx,%rsi
 10198ca:	jb     101991c <myl_rc_module_register+0x21c>
 10198cc:	mov    %rax,0x18(%rbx)
 10198d0:	mov    %rsi,0x30(%rdx)
 10198d4:	call   10276f0 <free@plt>
 10198d9:	mov    -0x40(%rbp),%rdi
 10198dd:	test   %rdi,%rdi
 10198e0:	je     101990c <myl_rc_module_register+0x20c>
 10198e2:	shl    $0x4,%r15
 10198e6:	mov    0x18(%rbx),%rax
 10198ea:	sub    %r15,%rax
 10198ed:	jb     101991c <myl_rc_module_register+0x21c>
 10198ef:	mov    0x1608(%rbx),%rcx
 10198f6:	mov    0x30(%rcx),%rdx
 10198fa:	sub    %r15,%rdx
 10198fd:	jb     101991c <myl_rc_module_register+0x21c>
 10198ff:	mov    %rax,0x18(%rbx)
 1019903:	mov    %rdx,0x30(%rcx)
 1019907:	call   10276f0 <free@plt>
 101990c:	mov    %r14d,%eax
 101990f:	add    $0x30,%rsp
 1019913:	pop    %rbx
 1019914:	pop    %r12
 1019916:	pop    %r14
 1019918:	pop    %r15
 101991a:	pop    %rbp
 101991b:	ret
 101991c:	vzeroupper
 101991f:	call   1018954 <myl_rc_invariant_failed>
 1019924:	int3
 1019925:	int3
 1019926:	int3
 1019927:	int3
 1019928:	int3
 1019929:	int3
 101992a:	int3
 101992b:	int3
 101992c:	int3
 101992d:	int3
 101992e:	int3
 101992f:	int3

0000000001019930 <builder_add>:
 1019930:	push   %rbp
 1019931:	mov    %rsp,%rbp
 1019934:	push   %r15
 1019936:	push   %r14
 1019938:	push   %r13
 101993a:	push   %r12
 101993c:	push   %rbx
 101993d:	sub    $0x48,%rsp
 1019941:	test   %rsi,%rsi
 1019944:	je     1019d38 <builder_add+0x408>
 101994a:	movabs $0xbf58476d1ce4e5b9,%r12
 1019954:	mov    0x20(%rdi),%rbx
 1019958:	test   %rbx,%rbx
 101995b:	je     10199be <builder_add+0x8e>
 101995d:	mov    0x10(%rdi),%rax
 1019961:	mov    %rsi,%rcx
 1019964:	shr    $0x3,%rcx
 1019968:	mov    %rsi,%rdx
 101996b:	shr    $0x21,%rdx
 101996f:	xor    %rcx,%rdx
 1019972:	imul   %r12,%rdx
 1019976:	mov    %rdx,%rcx
 1019979:	shr    $0x1b,%rcx
 101997d:	xor    %rdx,%rcx
 1019980:	lea    -0x1(,%rbx,2),%rdx
 1019988:	and    %rdx,%rcx
 101998b:	mov    (%rax,%rcx,8),%r9
 101998f:	test   %r9,%r9
 1019992:	je     10199be <builder_add+0x8e>
 1019994:	mov    0x8(%rdi),%r8
 1019998:	nopl   0x0(%rax,%rax,1)
 10199a0:	lea    (%r9,%r9,4),%r9
 10199a4:	cmp    %rsi,-0x28(%r8,%r9,8)
 10199a9:	je     1019a6d <builder_add+0x13d>
 10199af:	inc    %rcx
 10199b2:	and    %rdx,%rcx
 10199b5:	mov    (%rax,%rcx,8),%r9
 10199b9:	test   %r9,%r9
 10199bc:	jne    10199a0 <builder_add+0x70>
 10199be:	mov    0x18(%rdi),%rax
 10199c2:	cmp    %rbx,%rax
 10199c5:	jne    10199f8 <builder_add+0xc8>
 10199c7:	lea    (%rbx,%rbx,1),%rax
 10199cb:	test   %rbx,%rbx
 10199ce:	mov    $0x10,%r15d
 10199d4:	cmovne %rax,%r15
 10199d8:	xor    %eax,%eax
 10199da:	cmp    %rbx,%r15
 10199dd:	jb     1019a72 <builder_add+0x142>
 10199e3:	mov    $0x28,%ecx
 10199e8:	mov    %r15,%rax
 10199eb:	mul    %rcx
 10199ee:	jno    1019a81 <builder_add+0x151>
 10199f4:	xor    %eax,%eax
 10199f6:	jmp    1019a72 <builder_add+0x142>
 10199f8:	mov    0x8(%rdi),%rcx
 10199fc:	mov    0x10(%rdi),%r14
 1019a00:	mov    %rsi,%rdx
 1019a03:	shr    $0x3,%rdx
 1019a07:	mov    %rsi,%r8
 1019a0a:	shr    $0x21,%r8
 1019a0e:	xor    %rdx,%r8
 1019a11:	imul   %r12,%r8
 1019a15:	mov    %r8,%rdx
 1019a18:	shr    $0x1b,%rdx
 1019a1c:	xor    %r8,%rdx
 1019a1f:	lea    -0x1(,%rbx,2),%r8
 1019a27:	and    %r8,%rdx
 1019a2a:	mov    (%r14,%rdx,8),%r9
 1019a2e:	test   %r9,%r9
 1019a31:	je     1019a5a <builder_add+0x12a>
 1019a33:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019a40:	lea    (%r9,%r9,4),%r9
 1019a44:	cmp    %rsi,-0x28(%rcx,%r9,8)
 1019a49:	je     1019a5a <builder_add+0x12a>
 1019a4b:	inc    %rdx
 1019a4e:	and    %r8,%rdx
 1019a51:	mov    (%r14,%rdx,8),%r9
 1019a55:	test   %r9,%r9
 1019a58:	jne    1019a40 <builder_add+0x110>
 1019a5a:	lea    (%rax,%rax,4),%r8
 1019a5e:	mov    %rsi,(%rcx,%r8,8)
 1019a62:	inc    %rax
 1019a65:	mov    %rax,0x18(%rdi)
 1019a69:	mov    %rax,(%r14,%rdx,8)
 1019a6d:	mov    $0x1,%eax
 1019a72:	add    $0x48,%rsp
 1019a76:	pop    %rbx
 1019a77:	pop    %r12
 1019a79:	pop    %r13
 1019a7b:	pop    %r14
 1019a7d:	pop    %r15
 1019a7f:	pop    %rbp
 1019a80:	ret
 1019a81:	mov    (%rdi),%r12
 1019a84:	test   %r12,%r12
 1019a87:	je     1019d38 <builder_add+0x408>
 1019a8d:	test   %rax,%rax
 1019a90:	je     1019d38 <builder_add+0x408>
 1019a96:	mov    0x1608(%r12),%rcx
 1019a9e:	test   %rcx,%rcx
 1019aa1:	je     1019d38 <builder_add+0x408>
 1019aa7:	mov    0x18(%r12),%rdx
 1019aac:	mov    %rdx,%r13
 1019aaf:	add    %rax,%r13
 1019ab2:	jb     1019ac3 <builder_add+0x193>
 1019ab4:	mov    0x58(%r12),%r14
 1019ab9:	test   %r14,%r14
 1019abc:	je     1019ad0 <builder_add+0x1a0>
 1019abe:	cmp    %r14,%r13
 1019ac1:	jbe    1019ad0 <builder_add+0x1a0>
 1019ac3:	movl   $0x1,0x6c(%r12)
 1019acc:	xor    %eax,%eax
 1019ace:	jmp    1019a72 <builder_add+0x142>
 1019ad0:	mov    %rdx,-0x70(%rbp)
 1019ad4:	mov    %rcx,-0x58(%rbp)
 1019ad8:	mov    %rsi,-0x38(%rbp)
 1019adc:	mov    %rdi,-0x40(%rbp)
 1019ae0:	mov    $0x1,%edi
 1019ae5:	mov    %rax,-0x30(%rbp)
 1019ae9:	mov    %rax,%rsi
 1019aec:	call   1027690 <calloc@plt>
 1019af1:	test   %rax,%rax
 1019af4:	je     10199f4 <builder_add+0xc4>
 1019afa:	mov    %r13,0x18(%r12)
 1019aff:	mov    -0x58(%rbp),%rdx
 1019b03:	mov    0x30(%rdx),%r8
 1019b07:	mov    -0x30(%rbp),%rcx
 1019b0b:	lea    (%r8,%rcx,1),%r9
 1019b0f:	mov    %r9,0x30(%rdx)
 1019b13:	test   %r15,%r15
 1019b16:	je     1019d38 <builder_add+0x408>
 1019b1c:	mov    %r15,%rsi
 1019b1f:	shl    $0x4,%rsi
 1019b23:	mov    %r13,%rdi
 1019b26:	add    %rsi,%rdi
 1019b29:	jb     1019b35 <builder_add+0x205>
 1019b2b:	test   %r14,%r14
 1019b2e:	je     1019b6a <builder_add+0x23a>
 1019b30:	cmp    %r14,%rdi
 1019b33:	jbe    1019b6a <builder_add+0x23a>
 1019b35:	movl   $0x1,0x6c(%r12)
 1019b3e:	cmp    %rcx,%r13
 1019b41:	jb     1019d38 <builder_add+0x408>
 1019b47:	cmp    %rcx,%r9
 1019b4a:	jb     1019d38 <builder_add+0x408>
 1019b50:	mov    -0x70(%rbp),%rcx
 1019b54:	mov    %rcx,0x18(%r12)
 1019b59:	mov    %r8,0x30(%rdx)
 1019b5d:	mov    %rax,%rdi
 1019b60:	call   10276f0 <free@plt>
 1019b65:	jmp    10199f4 <builder_add+0xc4>
 1019b6a:	mov    %rdi,-0x60(%rbp)
 1019b6e:	mov    $0x1,%edi
 1019b73:	mov    %r9,-0x50(%rbp)
 1019b77:	mov    %rax,-0x48(%rbp)
 1019b7b:	mov    %r8,%r14
 1019b7e:	mov    %rsi,-0x68(%rbp)
 1019b82:	call   1027690 <calloc@plt>
 1019b87:	mov    %r14,%r8
 1019b8a:	mov    -0x50(%rbp),%r9
 1019b8e:	mov    -0x58(%rbp),%rdx
 1019b92:	mov    %rax,%r14
 1019b95:	mov    -0x30(%rbp),%rcx
 1019b99:	mov    -0x48(%rbp),%rax
 1019b9d:	test   %r14,%r14
 1019ba0:	je     1019b3e <builder_add+0x20e>
 1019ba2:	add    -0x68(%rbp),%r9
 1019ba6:	mov    -0x60(%rbp),%rdi
 1019baa:	mov    %rdi,0x18(%r12)
 1019baf:	mov    %r9,-0x50(%rbp)
 1019bb3:	mov    %r9,0x30(%rdx)
 1019bb7:	mov    -0x40(%rbp),%rcx
 1019bbb:	mov    0x8(%rcx),%r8
 1019bbf:	test   %rbx,%rbx
 1019bc2:	je     1019beb <builder_add+0x2bb>
 1019bc4:	lea    0x0(,%rbx,8),%rcx
 1019bcc:	lea    (%rcx,%rcx,4),%rdx
 1019bd0:	mov    %rax,%rdi
 1019bd3:	mov    %r8,%rsi
 1019bd6:	mov    %r8,%r13
 1019bd9:	mov    %rdx,-0x30(%rbp)
 1019bdd:	call   10276a0 <memcpy@plt>
 1019be2:	mov    %r13,%r8
 1019be5:	mov    -0x60(%rbp),%rdi
 1019be9:	jmp    1019bf3 <builder_add+0x2c3>
 1019beb:	movq   $0x0,-0x30(%rbp)
 1019bf3:	mov    -0x38(%rbp),%rsi
 1019bf7:	test   %r8,%r8
 1019bfa:	je     1019c3c <builder_add+0x30c>
 1019bfc:	mov    -0x30(%rbp),%rax
 1019c00:	sub    %rax,%rdi
 1019c03:	mov    -0x50(%rbp),%r13
 1019c07:	jb     1019d38 <builder_add+0x408>
 1019c0d:	sub    %rax,%r13
 1019c10:	jb     1019d38 <builder_add+0x408>
 1019c16:	mov    %rdi,0x18(%r12)
 1019c1b:	mov    -0x58(%rbp),%rax
 1019c1f:	mov    %r13,0x30(%rax)
 1019c23:	mov    %r8,%rdi
 1019c26:	call   10276f0 <free@plt>
 1019c2b:	mov    -0x40(%rbp),%rdi
 1019c2f:	mov    (%rdi),%r12
 1019c32:	mov    0x20(%rdi),%rbx
 1019c36:	mov    -0x38(%rbp),%rsi
 1019c3a:	jmp    1019c40 <builder_add+0x310>
 1019c3c:	mov    -0x40(%rbp),%rdi
 1019c40:	mov    0x10(%rdi),%rax
 1019c44:	test   %rax,%rax
 1019c47:	mov    -0x48(%rbp),%rcx
 1019c4b:	je     1019c91 <builder_add+0x361>
 1019c4d:	shl    $0x4,%rbx
 1019c51:	mov    0x18(%r12),%rcx
 1019c56:	sub    %rbx,%rcx
 1019c59:	jb     1019d38 <builder_add+0x408>
 1019c5f:	mov    0x1608(%r12),%rdx
 1019c67:	mov    0x30(%rdx),%rsi
 1019c6b:	sub    %rbx,%rsi
 1019c6e:	jb     1019d38 <builder_add+0x408>
 1019c74:	mov    %rcx,0x18(%r12)
 1019c79:	mov    %rsi,0x30(%rdx)
 1019c7d:	mov    %rax,%rdi
 1019c80:	call   10276f0 <free@plt>
 1019c85:	mov    -0x40(%rbp),%rdi
 1019c89:	mov    -0x38(%rbp),%rsi
 1019c8d:	mov    -0x48(%rbp),%rcx
 1019c91:	mov    %rcx,0x8(%rdi)
 1019c95:	mov    %r14,0x10(%rdi)
 1019c99:	mov    %r15,0x20(%rdi)
 1019c9d:	mov    0x18(%rdi),%rax
 1019ca1:	test   %rax,%rax
 1019ca4:	je     1019d24 <builder_add+0x3f4>
 1019ca6:	lea    -0x1(,%r15,2),%rdx
 1019cae:	xor    %r8d,%r8d
 1019cb1:	movabs $0xbf58476d1ce4e5b9,%r12
 1019cbb:	jmp    1019cc9 <builder_add+0x399>
 1019cbd:	inc    %r8
 1019cc0:	mov    %r8,(%r14,%r9,8)
 1019cc4:	cmp    %rax,%r8
 1019cc7:	je     1019d1c <builder_add+0x3ec>
 1019cc9:	lea    (%r8,%r8,4),%r9
 1019ccd:	mov    (%rcx,%r9,8),%r10
 1019cd1:	mov    %r10,%r9
 1019cd4:	shr    $0x3,%r9
 1019cd8:	mov    %r10,%r11
 1019cdb:	shr    $0x21,%r11
 1019cdf:	xor    %r9,%r11
 1019ce2:	imul   %r12,%r11
 1019ce6:	mov    %r11,%r9
 1019ce9:	shr    $0x1b,%r9
 1019ced:	xor    %r11,%r9
 1019cf0:	and    %rdx,%r9
 1019cf3:	mov    (%r14,%r9,8),%r11
 1019cf7:	test   %r11,%r11
 1019cfa:	je     1019cbd <builder_add+0x38d>
 1019cfc:	nopl   0x0(%rax)
 1019d00:	lea    (%r11,%r11,4),%r11
 1019d04:	cmp    %r10,-0x28(%rcx,%r11,8)
 1019d09:	je     1019cbd <builder_add+0x38d>
 1019d0b:	inc    %r9
 1019d0e:	and    %rdx,%r9
 1019d11:	mov    (%r14,%r9,8),%r11
 1019d15:	test   %r11,%r11
 1019d18:	jne    1019d00 <builder_add+0x3d0>
 1019d1a:	jmp    1019cbd <builder_add+0x38d>
 1019d1c:	mov    %r15,%rbx
 1019d1f:	jmp    1019a00 <builder_add+0xd0>
 1019d24:	xor    %eax,%eax
 1019d26:	mov    %r15,%rbx
 1019d29:	movabs $0xbf58476d1ce4e5b9,%r12
 1019d33:	jmp    1019a00 <builder_add+0xd0>
 1019d38:	call   1018954 <myl_rc_invariant_failed>
 1019d3d:	int3
 1019d3e:	int3
 1019d3f:	int3

0000000001019d40 <register_shapes>:
 1019d40:	push   %rbp
 1019d41:	mov    %rsp,%rbp
 1019d44:	push   %r15
 1019d46:	push   %r14
 1019d48:	push   %r13
 1019d4a:	push   %r12
 1019d4c:	push   %rbx
 1019d4d:	sub    $0x78,%rsp
 1019d51:	mov    %edx,%r10d
 1019d54:	mov    %rdi,%r15
 1019d57:	mov    (%rdi),%r9
 1019d5a:	mov    0x18(%rdi),%r8
 1019d5e:	test   %r8,%r8
 1019d61:	mov    %rdi,-0x48(%rbp)
 1019d65:	je     1019f84 <register_shapes+0x244>
 1019d6b:	xor    %ebx,%ebx
 1019d6d:	jmp    1019d9c <register_shapes+0x5c>
 1019d6f:	mov    -0x48(%rbp),%r15
 1019d73:	mov    0x18(%r15),%r8
 1019d77:	mov    -0x40(%rbp),%rsi
 1019d7b:	mov    -0x38(%rbp),%r9
 1019d7f:	mov    -0x2c(%rbp),%r10d
 1019d83:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019d90:	inc    %rbx
 1019d93:	cmp    %r8,%rbx
 1019d96:	jae    1019f23 <register_shapes+0x1e3>
 1019d9c:	mov    0x8(%r15),%rax
 1019da0:	lea    (%rbx,%rbx,4),%rcx
 1019da4:	mov    (%rax,%rcx,8),%r14
 1019da8:	mov    0x8(%r14),%eax
 1019dac:	cmp    $0x5,%rax
 1019db0:	ja     101a768 <register_shapes+0xa28>
 1019db6:	jmp    *0x1001a80(,%rax,8)
 1019dbd:	cmpq   $0x8,(%r14)
 1019dc1:	jne    101a768 <register_shapes+0xa28>
 1019dc7:	cmp    $0x2,%eax
 1019dca:	je     1019dd1 <register_shapes+0x91>
 1019dcc:	cmp    $0x4,%eax
 1019dcf:	jne    1019d90 <register_shapes+0x50>
 1019dd1:	mov    0x10(%r14),%rcx
 1019dd5:	xor    %r12d,%r12d
 1019dd8:	jmp    1019e02 <register_shapes+0xc2>
 1019dda:	nopw   0x0(%rax,%rax,1)
 1019de0:	mov    0x10(%r14),%rcx
 1019de4:	mov    0x18(%r14),%r12
 1019de8:	test   %r12,%r12
 1019deb:	setne  %dl
 1019dee:	test   %rcx,%rcx
 1019df1:	sete   %dil
 1019df5:	and    %dl,%dil
 1019df8:	cmp    $0x1,%dil
 1019dfc:	je     101a768 <register_shapes+0xa28>
 1019e02:	cmp    $0x4,%eax
 1019e05:	jne    1019e1e <register_shapes+0xde>
 1019e07:	mov    0x20(%r14),%rax
 1019e0b:	add    $0x4,%rax
 1019e0f:	jb     1019fb1 <register_shapes+0x271>
 1019e15:	cmp    (%r14),%rax
 1019e18:	ja     101a768 <register_shapes+0xa28>
 1019e1e:	mov    $0x1,%eax
 1019e23:	add    %r12,0x28(%r15)
 1019e27:	jb     1019fb6 <register_shapes+0x276>
 1019e2d:	test   %r12,%r12
 1019e30:	je     1019d90 <register_shapes+0x50>
 1019e36:	add    $0x8,%rcx
 1019e3a:	mov    %r12,%rdx
 1019e3d:	nopl   (%rax)
 1019e40:	mov    (%rcx),%rdi
 1019e43:	test   %rdi,%rdi
 1019e46:	je     101a768 <register_shapes+0xa28>
 1019e4c:	mov    -0x8(%rcx),%r8
 1019e50:	add    (%rdi),%r8
 1019e53:	jb     1019fb6 <register_shapes+0x276>
 1019e59:	cmp    (%r14),%r8
 1019e5c:	ja     101a768 <register_shapes+0xa28>
 1019e62:	add    $0x18,%rcx
 1019e66:	dec    %rdx
 1019e69:	jne    1019e40 <register_shapes+0x100>
 1019e6b:	mov    %r10d,-0x2c(%rbp)
 1019e6f:	mov    %r9,-0x38(%rbp)
 1019e73:	mov    %rsi,-0x40(%rbp)
 1019e77:	jmp    1019edb <register_shapes+0x19b>
 1019e79:	mov    0x18(%r14),%rax
 1019e7d:	test   %rax,%rax
 1019e80:	je     1019d90 <register_shapes+0x50>
 1019e86:	mov    0x10(%r14),%rdx
 1019e8a:	test   %rdx,%rdx
 1019e8d:	je     101a768 <register_shapes+0xa28>
 1019e93:	mov    0x20(%r14),%rcx
 1019e97:	mov    (%rdx),%rdi
 1019e9a:	cmp    %rdi,%rcx
 1019e9d:	jb     101a768 <register_shapes+0xa28>
 1019ea3:	dec    %rax
 1019ea6:	mul    %rcx
 1019ea9:	mov    %rax,%rcx
 1019eac:	mov    $0x1,%eax
 1019eb1:	jo     1019fb6 <register_shapes+0x276>
 1019eb7:	add    %rdi,%rcx
 1019eba:	jb     1019fb6 <register_shapes+0x276>
 1019ec0:	mov    %r10d,-0x2c(%rbp)
 1019ec4:	mov    %r9,-0x38(%rbp)
 1019ec8:	mov    %rsi,-0x40(%rbp)
 1019ecc:	mov    $0x1,%r12d
 1019ed2:	cmp    (%r14),%rcx
 1019ed5:	ja     101a768 <register_shapes+0xa28>
 1019edb:	lea    0x10(%r14),%r13
 1019edf:	mov    $0x8,%r15d
 1019ee5:	data16 cs nopw 0x0(%rax,%rax,1)
 1019ef0:	cmpl   $0x3,0x8(%r14)
 1019ef5:	mov    %r13,%rax
 1019ef8:	je     1019f01 <register_shapes+0x1c1>
 1019efa:	mov    0x0(%r13),%rax
 1019efe:	add    %r15,%rax
 1019f01:	mov    (%rax),%rsi
 1019f04:	mov    -0x48(%rbp),%rdi
 1019f08:	call   1019930 <builder_add>
 1019f0d:	test   %eax,%eax
 1019f0f:	je     1019fb1 <register_shapes+0x271>
 1019f15:	add    $0x18,%r15
 1019f19:	dec    %r12
 1019f1c:	jne    1019ef0 <register_shapes+0x1b0>
 1019f1e:	jmp    1019d6f <register_shapes+0x2f>
 1019f23:	mov    %r8,%rax
 1019f26:	shr    $0x3d,%rax
 1019f2a:	mov    $0x1,%eax
 1019f2f:	jne    1019fb6 <register_shapes+0x276>
 1019f35:	test   %r8,%r8
 1019f38:	je     1019f84 <register_shapes+0x244>
 1019f3a:	mov    %r10d,-0x2c(%rbp)
 1019f3e:	mov    %r9,-0x38(%rbp)
 1019f42:	mov    %rsi,-0x40(%rbp)
 1019f46:	shl    $0x3,%r8
 1019f4a:	mov    (%r15),%rdi
 1019f4d:	mov    %r8,-0x58(%rbp)
 1019f51:	mov    %r8,%rsi
 1019f54:	call   1018960 <myl_rc_meta_alloc>
 1019f59:	test   %rax,%rax
 1019f5c:	je     1019fb1 <register_shapes+0x271>
 1019f5e:	mov    0x18(%r15),%rcx
 1019f62:	test   %rcx,%rcx
 1019f65:	je     101a708 <register_shapes+0x9c8>
 1019f6b:	mov    0x8(%r15),%rdx
 1019f6f:	xor    %r12d,%r12d
 1019f72:	movabs $0x9e3779b97f4a7c15,%rbx
 1019f7c:	xor    %edi,%edi
 1019f7e:	mov    %rcx,-0x50(%rbp)
 1019f82:	jmp    1019fd5 <register_shapes+0x295>
 1019f84:	xor    %edi,%edi
 1019f86:	xor    %r12d,%r12d
 1019f89:	mov    $0x18,%eax
 1019f8e:	mulq   0x28(%r15)
 1019f92:	mov    %rax,%r14
 1019f95:	mov    $0x1,%eax
 1019f9a:	jo     1019fb6 <register_shapes+0x276>
 1019f9c:	mov    0x20(%rsi),%r8
 1019fa0:	mov    $0xc8,%ecx
 1019fa5:	mov    %r8,%rax
 1019fa8:	mul    %rcx
 1019fab:	jno    101a21b <register_shapes+0x4db>
 1019fb1:	mov    $0x1,%eax
 1019fb6:	add    $0x78,%rsp
 1019fba:	pop    %rbx
 1019fbb:	pop    %r12
 1019fbd:	pop    %r13
 1019fbf:	pop    %r14
 1019fc1:	pop    %r15
 1019fc3:	pop    %rbp
 1019fc4:	ret
 1019fc5:	inc    %rdi
 1019fc8:	mov    -0x50(%rbp),%rcx
 1019fcc:	cmp    %rcx,%rdi
 1019fcf:	jae    101a70b <register_shapes+0x9cb>
 1019fd5:	lea    (%rdi,%rdi,4),%rcx
 1019fd9:	cmpl   $0x2,0x20(%rdx,%rcx,8)
 1019fde:	je     1019fc5 <register_shapes+0x285>
 1019fe0:	mov    %rdi,(%rax)
 1019fe3:	mov    $0x1,%r8d
 1019fe9:	jmp    101a00b <register_shapes+0x2cb>
 1019feb:	nopl   0x0(%rax,%rax,1)
 1019ff0:	mov    -0x48(%rbp),%r15
 1019ff4:	cmp    %r12,%r10
 1019ff7:	cmova  %r10,%r12
 1019ffb:	movl   $0x2,0x20(%r9)
 101a003:	dec    %r8
 101a006:	test   %r8,%r8
 101a009:	je     1019fc5 <register_shapes+0x285>
 101a00b:	mov    -0x8(%rax,%r8,8),%rcx
 101a010:	lea    (%rcx,%rcx,4),%r10
 101a014:	movl   $0x1,0x20(%rdx,%r10,8)
 101a01d:	mov    (%rdx,%r10,8),%r11
 101a021:	mov    0x8(%r11),%ecx
 101a025:	cmp    $0x5,%rcx
 101a029:	ja     101a768 <register_shapes+0xa28>
 101a02f:	lea    (%rdx,%r10,8),%r9
 101a033:	mov    0x8(%rdx,%r10,8),%r10
 101a038:	jmp    *0x1001ab0(,%rcx,8)
 101a03f:	movq   $0x1,0x10(%r9)
 101a047:	jmp    101a120 <register_shapes+0x3e0>
 101a04c:	nopl   0x0(%rax)
 101a050:	cmp    0x18(%r11),%r10
 101a054:	jae    101a110 <register_shapes+0x3d0>
 101a05a:	add    $0x10,%r11
 101a05e:	cmp    $0x3,%ecx
 101a061:	je     101a08c <register_shapes+0x34c>
 101a063:	mov    (%r11),%rcx
 101a066:	lea    (%r10,%r10,2),%r11
 101a06a:	lea    (%rcx,%r11,8),%r11
 101a06e:	add    $0x8,%r11
 101a072:	jmp    101a08c <register_shapes+0x34c>
 101a074:	test   %r10,%r10
 101a077:	jne    101a110 <register_shapes+0x3d0>
 101a07d:	cmpq   $0x0,0x18(%r11)
 101a082:	je     101a110 <register_shapes+0x3d0>
 101a088:	add    $0x10,%r11
 101a08c:	mov    (%r11),%r11
 101a08f:	mov    0x10(%r15),%r14
 101a093:	mov    0x20(%r15),%rcx
 101a097:	mov    %r11,%rbx
 101a09a:	shr    $0x3,%rbx
 101a09e:	mov    %r11,%r13
 101a0a1:	shr    $0x21,%r13
 101a0a5:	xor    %rbx,%r13
 101a0a8:	movabs $0xbf58476d1ce4e5b9,%rsi
 101a0b2:	imul   %rsi,%r13
 101a0b6:	mov    %r13,%r15
 101a0b9:	shr    $0x1b,%r15
 101a0bd:	xor    %r13,%r15
 101a0c0:	lea    -0x1(,%rcx,2),%rbx
 101a0c8:	and    %rbx,%r15
 101a0cb:	mov    (%r14,%r15,8),%r13
 101a0cf:	mov    $0xffffffffffffffff,%rcx
 101a0d6:	test   %r13,%r13
 101a0d9:	je     101a1b5 <register_shapes+0x475>
 101a0df:	nop
 101a0e0:	lea    0x0(,%r13,4),%rsi
 101a0e8:	add    %r13,%rsi
 101a0eb:	cmp    %r11,-0x28(%rdx,%rsi,8)
 101a0f0:	je     101a1af <register_shapes+0x46f>
 101a0f6:	inc    %r15
 101a0f9:	and    %rbx,%r15
 101a0fc:	mov    (%r14,%r15,8),%r13
 101a100:	test   %r13,%r13
 101a103:	jne    101a0e0 <register_shapes+0x3a0>
 101a105:	jmp    101a1b5 <register_shapes+0x475>
 101a10a:	nopw   0x0(%rax,%rax,1)
 101a110:	mov    0x10(%r9),%rcx
 101a114:	test   %rcx,%rcx
 101a117:	je     101a120 <register_shapes+0x3e0>
 101a119:	inc    %rcx
 101a11c:	mov    %rcx,0x10(%r9)
 101a120:	mov    0x18(%r9),%r10
 101a124:	inc    %r10
 101a127:	mov    %r10,0x18(%r9)
 101a12b:	mov    (%r15),%rcx
 101a12e:	mov    0x1608(%rcx),%rcx
 101a135:	mov    0x58(%rcx),%r14
 101a139:	mov    0x60(%rcx),%r15
 101a13d:	movzbl 0x70(%rcx),%ecx
 101a141:	mov    %r11,%rsi
 101a144:	imul   %rbx,%rsi
 101a148:	shrx   %rcx,%rsi,%r13
 101a14d:	nopl   (%rax)
 101a150:	and    %r15,%r13
 101a153:	mov    %r13,%rcx
 101a156:	shl    $0x4,%rcx
 101a15a:	mov    (%r14,%rcx,1),%rcx
 101a15e:	cmp    %r11,%rcx
 101a161:	je     101a180 <register_shapes+0x440>
 101a163:	test   %rcx,%rcx
 101a166:	je     1019ff0 <register_shapes+0x2b0>
 101a16c:	inc    %r13
 101a16f:	jmp    101a150 <register_shapes+0x410>
 101a171:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a180:	shl    $0x4,%r13
 101a184:	mov    0x8(%r14,%r13,1),%rcx
 101a189:	test   %rcx,%rcx
 101a18c:	je     1019ff0 <register_shapes+0x2b0>
 101a192:	mov    0x30(%rcx),%rcx
 101a196:	cmp    %r10,%rcx
 101a199:	mov    -0x48(%rbp),%r15
 101a19d:	jbe    1019ff4 <register_shapes+0x2b4>
 101a1a3:	mov    %rcx,0x18(%r9)
 101a1a7:	mov    %rcx,%r10
 101a1aa:	jmp    1019ff4 <register_shapes+0x2b4>
 101a1af:	dec    %r13
 101a1b2:	mov    %r13,%rcx
 101a1b5:	lea    (%rcx,%rcx,4),%r11
 101a1b9:	mov    0x20(%rdx,%r11,8),%ebx
 101a1be:	test   %ebx,%ebx
 101a1c0:	mov    -0x48(%rbp),%r15
 101a1c4:	je     101a205 <register_shapes+0x4c5>
 101a1c6:	cmp    $0x1,%ebx
 101a1c9:	je     101a768 <register_shapes+0xa28>
 101a1cf:	lea    (%rdx,%r11,8),%rcx
 101a1d3:	mov    0x10(%rcx),%r11
 101a1d7:	cmp    0x10(%r9),%r11
 101a1db:	jbe    101a1e1 <register_shapes+0x4a1>
 101a1dd:	mov    %r11,0x10(%r9)
 101a1e1:	mov    0x18(%rcx),%rcx
 101a1e5:	cmp    0x18(%r9),%rcx
 101a1e9:	movabs $0x9e3779b97f4a7c15,%rbx
 101a1f3:	jbe    101a1f9 <register_shapes+0x4b9>
 101a1f5:	mov    %rcx,0x18(%r9)
 101a1f9:	inc    %r10
 101a1fc:	mov    %r10,0x8(%r9)
 101a200:	jmp    101a006 <register_shapes+0x2c6>
 101a205:	mov    %rcx,(%rax,%r8,8)
 101a209:	inc    %r8
 101a20c:	movabs $0x9e3779b97f4a7c15,%rbx
 101a216:	jmp    101a006 <register_shapes+0x2c6>
 101a21b:	mov    %rax,%rcx
 101a21e:	mov    %rdi,%rbx
 101a221:	add    $0x40,%rbx
 101a225:	mov    $0x1,%eax
 101a22a:	jb     1019fb6 <register_shapes+0x276>
 101a230:	add    %r14,%rbx
 101a233:	jb     1019fb6 <register_shapes+0x276>
 101a239:	add    %rcx,%rbx
 101a23c:	jb     1019fb6 <register_shapes+0x276>
 101a242:	mov    %r8,-0x60(%rbp)
 101a246:	mov    %rdi,-0x50(%rbp)
 101a24a:	mov    %r10d,-0x2c(%rbp)
 101a24e:	mov    %r9,-0x38(%rbp)
 101a252:	mov    %r15,%r13
 101a255:	mov    %rsi,%r15
 101a258:	mov    0x0(%r13),%rdi
 101a25c:	mov    %rbx,%rsi
 101a25f:	call   1018960 <myl_rc_meta_alloc>
 101a264:	test   %rax,%rax
 101a267:	je     1019fb1 <register_shapes+0x271>
 101a26d:	xor    %ecx,%ecx
 101a26f:	mov    -0x2c(%rbp),%r10d
 101a273:	test   %r10d,%r10d
 101a276:	mov    %r15,-0x40(%rbp)
 101a27a:	cmovne %r15,%rcx
 101a27e:	mov    %rcx,0x8(%rax)
 101a282:	mov    0x18(%r13),%rsi
 101a286:	mov    %rsi,0x20(%rax)
 101a28a:	mov    -0x60(%rbp),%rcx
 101a28e:	mov    %rcx,0x28(%rax)
 101a292:	mov    %rbx,0x30(%rax)
 101a296:	lea    0x40(%rax),%rcx
 101a29a:	mov    %rcx,0x10(%rax)
 101a29e:	mov    -0x50(%rbp),%rcx
 101a2a2:	lea    (%rax,%rcx,1),%rdx
 101a2a6:	add    $0x40,%rdx
 101a2aa:	add    %rdx,%r14
 101a2ad:	mov    %r14,0x18(%rax)
 101a2b1:	test   %rsi,%rsi
 101a2b4:	mov    %r13,%r15
 101a2b7:	mov    %rax,%r14
 101a2ba:	je     101a503 <register_shapes+0x7c3>
 101a2c0:	xor    %esi,%esi
 101a2c2:	jmp    101a2e9 <register_shapes+0x5a9>
 101a2c4:	mov    -0x58(%rbp),%rax
 101a2c8:	mov    %rdx,0x18(%rax)
 101a2cc:	lea    (%r9,%r9,2),%rax
 101a2d0:	lea    (%rdx,%rax,8),%rdx
 101a2d4:	mov    -0x2c(%rbp),%r10d
 101a2d8:	mov    -0x50(%rbp),%rsi
 101a2dc:	inc    %rsi
 101a2df:	cmp    0x18(%r15),%rsi
 101a2e3:	jae    101a503 <register_shapes+0x7c3>
 101a2e9:	lea    0x0(,%rsi,8),%rax
 101a2f1:	mov    0x10(%r14),%rcx
 101a2f5:	mov    %rsi,%rdi
 101a2f8:	shl    $0x6,%rdi
 101a2fc:	lea    (%rcx,%rdi,1),%r13
 101a300:	test   %r10d,%r10d
 101a303:	mov    0x8(%r15),%r8
 101a307:	lea    (%rax,%rax,4),%rax
 101a30b:	mov    (%r8,%rax,1),%r8
 101a30f:	mov    $0x0,%r9d
 101a315:	cmovne %r8,%r9
 101a319:	mov    %r9,(%rcx,%rdi,1)
 101a31d:	vmovups (%r8),%ymm0
 101a322:	vmovups %ymm0,0x8(%rcx,%rdi,1)
 101a328:	mov    0x20(%r8),%r9
 101a32c:	mov    %r9,0x28(%rcx,%rdi,1)
 101a331:	mov    0x8(%r15),%r9
 101a335:	vmovups 0x10(%r9,%rax,1),%xmm0
 101a33c:	cmpq   $0x0,0x10(%r9,%rax,1)
 101a342:	vmovups %xmm0,0x30(%rcx,%rdi,1)
 101a348:	je     101a3ee <register_shapes+0x6ae>
 101a34e:	mov    0x8(%r8),%eax
 101a352:	cmp    $0x3,%eax
 101a355:	jne    101a403 <register_shapes+0x6c3>
 101a35b:	cmpq   $0x0,0x18(%r8)
 101a360:	je     101a2dc <register_shapes+0x59c>
 101a366:	mov    0x10(%r8),%r10
 101a36a:	mov    0x10(%r15),%r11
 101a36e:	mov    0x20(%r15),%rax
 101a372:	mov    %r10,%rcx
 101a375:	shr    $0x3,%rcx
 101a379:	mov    %r10,%rdi
 101a37c:	shr    $0x21,%rdi
 101a380:	xor    %rcx,%rdi
 101a383:	movabs $0xbf58476d1ce4e5b9,%rcx
 101a38d:	imul   %rcx,%rdi
 101a391:	mov    %rdi,%rbx
 101a394:	shr    $0x1b,%rbx
 101a398:	xor    %rdi,%rbx
 101a39b:	lea    -0x1(,%rax,2),%rax
 101a3a3:	and    %rax,%rbx
 101a3a6:	mov    (%r11,%rbx,8),%rdi
 101a3aa:	test   %rdi,%rdi
 101a3ad:	je     101a3ca <register_shapes+0x68a>
 101a3af:	nop
 101a3b0:	lea    (%rdi,%rdi,4),%rcx
 101a3b4:	cmp    %r10,-0x28(%r9,%rcx,8)
 101a3b9:	je     101a3cc <register_shapes+0x68c>
 101a3bb:	inc    %rbx
 101a3be:	and    %rax,%rbx
 101a3c1:	mov    (%r11,%rbx,8),%rdi
 101a3c5:	test   %rdi,%rdi
 101a3c8:	jne    101a3b0 <register_shapes+0x670>
 101a3ca:	xor    %edi,%edi
 101a3cc:	mov    0x10(%r14),%rax
 101a3d0:	shl    $0x6,%rdi
 101a3d4:	add    %rdi,%rax
 101a3d7:	add    $0xffffffffffffffc8,%rax
 101a3db:	mov    %rax,0x18(%r13)
 101a3df:	mov    0x8(%r8),%eax
 101a3e3:	mov    -0x2c(%rbp),%r10d
 101a3e7:	cmp    $0x4,%eax
 101a3ea:	jne    101a408 <register_shapes+0x6c8>
 101a3ec:	jmp    101a411 <register_shapes+0x6d1>
 101a3ee:	movl   $0x0,0x10(%r13)
 101a3f6:	mov    0x8(%r8),%eax
 101a3fa:	cmp    $0x3,%eax
 101a3fd:	je     101a35b <register_shapes+0x61b>
 101a403:	cmp    $0x4,%eax
 101a406:	je     101a411 <register_shapes+0x6d1>
 101a408:	cmp    $0x2,%eax
 101a40b:	jne    101a2dc <register_shapes+0x59c>
 101a411:	mov    %r13,-0x58(%rbp)
 101a415:	mov    %rsi,-0x50(%rbp)
 101a419:	mov    0x18(%r8),%r9
 101a41d:	test   %r9,%r9
 101a420:	je     101a2c4 <register_shapes+0x584>
 101a426:	mov    0x10(%r8),%r8
 101a42a:	xor    %r10d,%r10d
 101a42d:	jmp    101a45b <register_shapes+0x71b>
 101a42f:	nop
 101a430:	xor    %eax,%eax
 101a432:	add    %rdx,%r11
 101a435:	mov    %rsi,%r14
 101a438:	mov    0x10(%rsi),%rcx
 101a43c:	shl    $0x6,%rax
 101a440:	add    %rcx,%rax
 101a443:	add    $0xffffffffffffffc8,%rax
 101a447:	mov    %rax,0x8(%r11)
 101a44b:	inc    %r10
 101a44e:	cmp    %r9,%r10
 101a451:	mov    -0x48(%rbp),%r15
 101a455:	je     101a2c4 <register_shapes+0x584>
 101a45b:	mov    %r14,%rsi
 101a45e:	lea    0x0(,%r10,8),%rax
 101a466:	lea    (%rax,%rax,2),%r11
 101a46a:	mov    0x10(%r8,%r11,1),%rax
 101a46f:	mov    %rax,0x10(%rdx,%r11,1)
 101a474:	vmovups (%r8,%r11,1),%xmm0
 101a47a:	vmovups %xmm0,(%rdx,%r11,1)
 101a480:	mov    0x8(%r8,%r11,1),%rbx
 101a485:	mov    0x10(%r15),%r14
 101a489:	mov    0x20(%r15),%rax
 101a48d:	mov    %rbx,%rcx
 101a490:	shr    $0x3,%rcx
 101a494:	mov    %rbx,%rdi
 101a497:	shr    $0x21,%rdi
 101a49b:	xor    %rcx,%rdi
 101a49e:	movabs $0xbf58476d1ce4e5b9,%rcx
 101a4a8:	imul   %rcx,%rdi
 101a4ac:	mov    %r15,%rcx
 101a4af:	mov    %rdi,%r15
 101a4b2:	shr    $0x1b,%r15
 101a4b6:	xor    %rdi,%r15
 101a4b9:	lea    -0x1(,%rax,2),%rdi
 101a4c1:	and    %rdi,%r15
 101a4c4:	mov    (%r14,%r15,8),%rax
 101a4c8:	test   %rax,%rax
 101a4cb:	je     101a430 <register_shapes+0x6f0>
 101a4d1:	mov    0x8(%rcx),%rcx
 101a4d5:	data16 cs nopw 0x0(%rax,%rax,1)
 101a4e0:	lea    (%rax,%rax,4),%r13
 101a4e4:	cmp    %rbx,-0x28(%rcx,%r13,8)
 101a4e9:	je     101a432 <register_shapes+0x6f2>
 101a4ef:	inc    %r15
 101a4f2:	and    %rdi,%r15
 101a4f5:	mov    (%r14,%r15,8),%rax
 101a4f9:	test   %rax,%rax
 101a4fc:	jne    101a4e0 <register_shapes+0x7a0>
 101a4fe:	jmp    101a430 <register_shapes+0x6f0>
 101a503:	mov    -0x60(%rbp),%r13
 101a507:	test   %r13,%r13
 101a50a:	je     101a5f3 <register_shapes+0x8b3>
 101a510:	mov    0x18(%r14),%rax
 101a514:	mov    -0x40(%rbp),%rcx
 101a518:	mov    0x18(%rcx),%rsi
 101a51c:	xor    %edx,%edx
 101a51e:	jmp    101a547 <register_shapes+0x807>
 101a520:	xor    %r11d,%r11d
 101a523:	shl    $0x6,%r11
 101a527:	mov    0x10(%r14),%rcx
 101a52b:	mov    0x18(%r14),%rax
 101a52f:	add    %r11,%rcx
 101a532:	add    $0xffffffffffffffc8,%rcx
 101a536:	mov    %rcx,0x8(%rax,%rdi,1)
 101a53b:	inc    %rdx
 101a53e:	cmp    %r13,%rdx
 101a541:	je     101a5f3 <register_shapes+0x8b3>
 101a547:	imul   $0xc8,%rdx,%rdi
 101a54e:	mov    %rdx,%rcx
 101a551:	shl    $0x6,%rcx
 101a555:	vmovups (%rsi,%rcx,1),%ymm0
 101a55a:	vmovups 0x20(%rsi,%rcx,1),%ymm1
 101a560:	vmovups %ymm1,0x20(%rax,%rdi,1)
 101a566:	vmovups %ymm0,(%rax,%rdi,1)
 101a56b:	mov    -0x40(%rbp),%rax
 101a56f:	mov    0x18(%rax),%rsi
 101a573:	mov    0x8(%rsi,%rcx,1),%r8
 101a578:	mov    0x10(%r15),%r9
 101a57c:	mov    0x20(%r15),%rax
 101a580:	mov    %r8,%rcx
 101a583:	shr    $0x3,%rcx
 101a587:	mov    %r8,%r11
 101a58a:	shr    $0x21,%r11
 101a58e:	xor    %rcx,%r11
 101a591:	movabs $0xbf58476d1ce4e5b9,%rcx
 101a59b:	imul   %rcx,%r11
 101a59f:	mov    %r11,%r10
 101a5a2:	shr    $0x1b,%r10
 101a5a6:	xor    %r11,%r10
 101a5a9:	lea    -0x1(,%rax,2),%rax
 101a5b1:	and    %rax,%r10
 101a5b4:	mov    (%r9,%r10,8),%r11
 101a5b8:	test   %r11,%r11
 101a5bb:	je     101a520 <register_shapes+0x7e0>
 101a5c1:	mov    0x8(%r15),%rcx
 101a5c5:	data16 cs nopw 0x0(%rax,%rax,1)
 101a5d0:	lea    (%r11,%r11,4),%rbx
 101a5d4:	cmp    %r8,-0x28(%rcx,%rbx,8)
 101a5d9:	je     101a523 <register_shapes+0x7e3>
 101a5df:	inc    %r10
 101a5e2:	and    %rax,%r10
 101a5e5:	mov    (%r9,%r10,8),%r11
 101a5e9:	test   %r11,%r11
 101a5ec:	jne    101a5d0 <register_shapes+0x890>
 101a5ee:	jmp    101a520 <register_shapes+0x7e0>
 101a5f3:	mov    -0x38(%rbp),%rdi
 101a5f7:	mov    0x1608(%rdi),%rax
 101a5fe:	cmp    0xb8(%rax),%r12
 101a605:	jbe    101a637 <register_shapes+0x8f7>
 101a607:	mov    $0x18,%ecx
 101a60c:	mov    %r12,%rax
 101a60f:	mul    %rcx
 101a612:	jo     101a62e <register_shapes+0x8ee>
 101a614:	mov    %rax,%rsi
 101a617:	vzeroupper
 101a61a:	call   1018960 <myl_rc_meta_alloc>
 101a61f:	mov    -0x2c(%rbp),%ecx
 101a622:	mov    -0x38(%rbp),%rdi
 101a626:	mov    %rax,%rbx
 101a629:	test   %rax,%rax
 101a62c:	jne    101a63c <register_shapes+0x8fc>
 101a62e:	mov    0x30(%r14),%rdx
 101a632:	jmp    101a6f8 <register_shapes+0x9b8>
 101a637:	xor    %ebx,%ebx
 101a639:	mov    -0x2c(%rbp),%ecx
 101a63c:	cmp    $0x1,%ecx
 101a63f:	mov    $0x2,%eax
 101a644:	sbb    $0x0,%rax
 101a648:	mulq   0x20(%r14)
 101a64c:	jo     101a6db <register_shapes+0x99b>
 101a652:	mov    %ecx,%esi
 101a654:	lea    -0xa0(%rbp),%r8
 101a65b:	mov    %rax,%rdx
 101a65e:	mov    %r14,%rcx
 101a661:	vzeroupper
 101a664:	call   101a770 <index_prepare>
 101a669:	mov    -0x38(%rbp),%rdi
 101a66d:	test   %eax,%eax
 101a66f:	je     101a6db <register_shapes+0x99b>
 101a671:	lea    -0xa0(%rbp),%rdx
 101a678:	mov    %r14,%rsi
 101a67b:	call   101ab20 <index_commit>
 101a680:	mov    -0x38(%rbp),%rdi
 101a684:	mov    0x1608(%rdi),%rax
 101a68b:	test   %rbx,%rbx
 101a68e:	je     101a6c9 <register_shapes+0x989>
 101a690:	mov    0xb0(%rax),%rsi
 101a697:	mov    0xb8(%rax),%rax
 101a69e:	shl    $0x3,%rax
 101a6a2:	lea    (%rax,%rax,2),%rdx
 101a6a6:	mov    %r14,%r15
 101a6a9:	mov    %rdi,%r14
 101a6ac:	call   10189e0 <myl_rc_meta_free>
 101a6b1:	mov    0x1608(%r14),%rax
 101a6b8:	mov    %r15,%r14
 101a6bb:	mov    %rbx,0xb0(%rax)
 101a6c2:	mov    %r12,0xb8(%rax)
 101a6c9:	mov    0x28(%rax),%rcx
 101a6cd:	mov    %rcx,(%r14)
 101a6d0:	mov    %r14,0x28(%rax)
 101a6d4:	xor    %eax,%eax
 101a6d6:	jmp    1019fb6 <register_shapes+0x276>
 101a6db:	shl    $0x3,%r12
 101a6df:	lea    (%r12,%r12,2),%rdx
 101a6e3:	mov    %rbx,%rsi
 101a6e6:	mov    %rdi,%rbx
 101a6e9:	vzeroupper
 101a6ec:	call   10189e0 <myl_rc_meta_free>
 101a6f1:	mov    0x30(%r14),%rdx
 101a6f5:	mov    %rbx,%rdi
 101a6f8:	mov    %r14,%rsi
 101a6fb:	vzeroupper
 101a6fe:	call   10189e0 <myl_rc_meta_free>
 101a703:	jmp    1019fb1 <register_shapes+0x271>
 101a708:	xor    %r12d,%r12d
 101a70b:	mov    %rcx,%rbx
 101a70e:	mov    (%r15),%rcx
 101a711:	mov    0x18(%rcx),%rdx
 101a715:	mov    -0x58(%rbp),%r8
 101a719:	sub    %r8,%rdx
 101a71c:	jb     101a768 <register_shapes+0xa28>
 101a71e:	mov    0x1608(%rcx),%rsi
 101a725:	mov    0x30(%rsi),%rdi
 101a729:	sub    %r8,%rdi
 101a72c:	jb     101a768 <register_shapes+0xa28>
 101a72e:	mov    %rdx,0x18(%rcx)
 101a732:	mov    %rdi,0x30(%rsi)
 101a736:	mov    %rax,%rdi
 101a739:	call   10276f0 <free@plt>
 101a73e:	mov    %rbx,%rax
 101a741:	shr    $0x3a,%rax
 101a745:	mov    -0x40(%rbp),%rsi
 101a749:	mov    $0x1,%eax
 101a74e:	mov    -0x38(%rbp),%r9
 101a752:	mov    -0x2c(%rbp),%r10d
 101a756:	jne    1019fb6 <register_shapes+0x276>
 101a75c:	mov    %rbx,%rdi
 101a75f:	shl    $0x6,%rdi
 101a763:	jmp    1019f89 <register_shapes+0x249>
 101a768:	call   1018954 <myl_rc_invariant_failed>
 101a76d:	int3
 101a76e:	int3
 101a76f:	int3

000000000101a770 <index_prepare>:
 101a770:	push   %rbp
 101a771:	mov    %rsp,%rbp
 101a774:	push   %r15
 101a776:	push   %r14
 101a778:	push   %r13
 101a77a:	push   %r12
 101a77c:	push   %rbx
 101a77d:	sub    $0x38,%rsp
 101a781:	mov    %r8,%rbx
 101a784:	mov    %rdx,-0x58(%rbp)
 101a788:	mov    %rsi,%rdx
 101a78b:	mov    %rdi,%r14
 101a78e:	vxorps %xmm0,%xmm0,%xmm0
 101a792:	vmovups %ymm0,0x20(%r8)
 101a798:	vmovups %ymm0,(%r8)
 101a79d:	mov    0x1608(%rdi),%r15
 101a7a4:	mov    0x28(%rcx),%rax
 101a7a8:	xor    %edi,%edi
 101a7aa:	test   %rax,%rax
 101a7ad:	je     101a873 <index_prepare+0x103>
 101a7b3:	mov    %rdx,-0x40(%rbp)
 101a7b7:	mov    %r14,-0x48(%rbp)
 101a7bb:	mov    0xa8(%r15),%rdx
 101a7c2:	add    %rax,%rdx
 101a7c5:	lea    0x10(,%rdx,4),%rdx
 101a7cd:	mov    0xa0(%r15),%r13
 101a7d4:	mov    0x18(%rcx),%rsi
 101a7d8:	xor    %r12d,%r12d
 101a7db:	xor    %r8d,%r8d
 101a7de:	mov    %r13,%rcx
 101a7e1:	jmp    101a812 <index_prepare+0xa2>
 101a7e3:	mov    0x98(%r15),%r11
 101a7ea:	mov    %r10,%r14
 101a7ed:	shl    $0x4,%r14
 101a7f1:	cmpq   $0x0,(%r11,%r14,1)
 101a7f6:	je     101a858 <index_prepare+0xe8>
 101a7f8:	nopl   0x0(%rax,%rax,1)
 101a800:	inc    %r8
 101a803:	mov    %r8,%r12
 101a806:	add    $0xc8,%rsi
 101a80d:	dec    %rax
 101a810:	je     101a864 <index_prepare+0xf4>
 101a812:	mov    (%rsi),%r9
 101a815:	mov    0x34(%r9),%r9d
 101a819:	test   %r9d,%r9d
 101a81c:	setne  %r10b
 101a820:	cmp    %edi,%r9d
 101a823:	seta   %r11b
 101a827:	and    %r10b,%r11b
 101a82a:	cmp    $0x1,%r11b
 101a82e:	jne    101a800 <index_prepare+0x90>
 101a830:	mov    %r9d,%r10d
 101a833:	cmp    %r10,%rdx
 101a836:	jbe    101a800 <index_prepare+0x90>
 101a838:	cmp    %r10,%r13
 101a83b:	ja     101a7e3 <index_prepare+0x73>
 101a83d:	inc    %r10
 101a840:	cmp    %r10,%rcx
 101a843:	cmovbe %r10,%rcx
 101a847:	mov    %r9d,%edi
 101a84a:	add    $0xc8,%rsi
 101a851:	dec    %rax
 101a854:	jne    101a812 <index_prepare+0xa2>
 101a856:	jmp    101a864 <index_prepare+0xf4>
 101a858:	add    %r14,%r11
 101a85b:	cmpq   $0x0,0x8(%r11)
 101a860:	jne    101a800 <index_prepare+0x90>
 101a862:	jmp    101a83d <index_prepare+0xcd>
 101a864:	cmp    %r13,%rcx
 101a867:	jne    101a8e1 <index_prepare+0x171>
 101a869:	mov    -0x48(%rbp),%r14
 101a86d:	mov    -0x40(%rbp),%rdx
 101a871:	jmp    101a876 <index_prepare+0x106>
 101a873:	xor    %r12d,%r12d
 101a876:	add    $0x38,%r15
 101a87a:	mov    %r14,%rdi
 101a87d:	mov    %r15,%rsi
 101a880:	mov    %rbx,%rcx
 101a883:	vzeroupper
 101a886:	call   101b280 <map_prepare>
 101a88b:	test   %eax,%eax
 101a88d:	je     101a946 <index_prepare+0x1d6>
 101a893:	mov    0x1608(%r14),%rsi
 101a89a:	add    $0x58,%rsi
 101a89e:	lea    0x10(%rbx),%rcx
 101a8a2:	mov    %r14,%rdi
 101a8a5:	mov    -0x58(%rbp),%rdx
 101a8a9:	call   101b280 <map_prepare>
 101a8ae:	test   %eax,%eax
 101a8b0:	je     101a946 <index_prepare+0x1d6>
 101a8b6:	mov    0x1608(%r14),%rsi
 101a8bd:	add    $0x78,%rsi
 101a8c1:	lea    0x20(%rbx),%rcx
 101a8c5:	mov    %r14,%rdi
 101a8c8:	mov    %r12,%rdx
 101a8cb:	call   101b280 <map_prepare>
 101a8d0:	mov    %eax,%ecx
 101a8d2:	mov    $0x1,%eax
 101a8d7:	test   %ecx,%ecx
 101a8d9:	jne    101aa88 <index_prepare+0x318>
 101a8df:	jmp    101a946 <index_prepare+0x1d6>
 101a8e1:	lea    0x0(,%r13,2),%rdx
 101a8e9:	cmp    %rdx,%rcx
 101a8ec:	cmova  %rcx,%rdx
 101a8f0:	mov    %rdx,%rax
 101a8f3:	shr    $0x3c,%rax
 101a8f7:	mov    -0x48(%rbp),%r14
 101a8fb:	jne    101a946 <index_prepare+0x1d6>
 101a8fd:	test   %r14,%r14
 101a900:	je     101ab0b <index_prepare+0x39b>
 101a906:	test   %rdx,%rdx
 101a909:	je     101ab0b <index_prepare+0x39b>
 101a90f:	test   %r15,%r15
 101a912:	je     101ab0b <index_prepare+0x39b>
 101a918:	mov    %rdx,%rcx
 101a91b:	shl    $0x4,%rcx
 101a91f:	mov    0x18(%r14),%rsi
 101a923:	add    %rcx,%rsi
 101a926:	jb     101a93e <index_prepare+0x1ce>
 101a928:	mov    0x58(%r14),%rax
 101a92c:	test   %rax,%rax
 101a92f:	je     101aa9a <index_prepare+0x32a>
 101a935:	cmp    %rax,%rsi
 101a938:	jbe    101aa9a <index_prepare+0x32a>
 101a93e:	movl   $0x1,0x6c(%r14)
 101a946:	mov    (%rbx),%rdi
 101a949:	test   %rdi,%rdi
 101a94c:	je     101a98b <index_prepare+0x21b>
 101a94e:	mov    0x8(%rbx),%rax
 101a952:	shl    $0x4,%rax
 101a956:	add    $0x10,%rax
 101a95a:	mov    0x18(%r14),%rcx
 101a95e:	sub    %rax,%rcx
 101a961:	jb     101ab0b <index_prepare+0x39b>
 101a967:	mov    0x1608(%r14),%rdx
 101a96e:	mov    0x30(%rdx),%rsi
 101a972:	sub    %rax,%rsi
 101a975:	jb     101ab0b <index_prepare+0x39b>
 101a97b:	mov    %rcx,0x18(%r14)
 101a97f:	mov    %rsi,0x30(%rdx)
 101a983:	vzeroupper
 101a986:	call   10276f0 <free@plt>
 101a98b:	vxorps %xmm0,%xmm0,%xmm0
 101a98f:	vmovups %xmm0,(%rbx)
 101a993:	mov    0x10(%rbx),%rdi
 101a997:	test   %rdi,%rdi
 101a99a:	je     101a9dd <index_prepare+0x26d>
 101a99c:	mov    0x18(%rbx),%rax
 101a9a0:	shl    $0x4,%rax
 101a9a4:	add    $0x10,%rax
 101a9a8:	mov    0x18(%r14),%rcx
 101a9ac:	sub    %rax,%rcx
 101a9af:	jb     101ab0b <index_prepare+0x39b>
 101a9b5:	mov    0x1608(%r14),%rdx
 101a9bc:	mov    0x30(%rdx),%rsi
 101a9c0:	sub    %rax,%rsi
 101a9c3:	jb     101ab0b <index_prepare+0x39b>
 101a9c9:	mov    %rcx,0x18(%r14)
 101a9cd:	mov    %rsi,0x30(%rdx)
 101a9d1:	vzeroupper
 101a9d4:	call   10276f0 <free@plt>
 101a9d9:	vxorps %xmm0,%xmm0,%xmm0
 101a9dd:	lea    0x10(%rbx),%rax
 101a9e1:	vmovups %xmm0,(%rax)
 101a9e5:	mov    0x20(%rbx),%rdi
 101a9e9:	test   %rdi,%rdi
 101a9ec:	je     101aa2b <index_prepare+0x2bb>
 101a9ee:	mov    0x28(%rbx),%rax
 101a9f2:	shl    $0x4,%rax
 101a9f6:	add    $0x10,%rax
 101a9fa:	mov    0x18(%r14),%rcx
 101a9fe:	sub    %rax,%rcx
 101aa01:	jb     101ab0b <index_prepare+0x39b>
 101aa07:	mov    0x1608(%r14),%rdx
 101aa0e:	mov    0x30(%rdx),%rsi
 101aa12:	sub    %rax,%rsi
 101aa15:	jb     101ab0b <index_prepare+0x39b>
 101aa1b:	mov    %rcx,0x18(%r14)
 101aa1f:	mov    %rsi,0x30(%rdx)
 101aa23:	vzeroupper
 101aa26:	call   10276f0 <free@plt>
 101aa2b:	lea    0x20(%rbx),%rax
 101aa2f:	vxorps %xmm0,%xmm0,%xmm0
 101aa33:	vmovups %xmm0,(%rax)
 101aa37:	mov    0x30(%rbx),%rdi
 101aa3b:	test   %rdi,%rdi
 101aa3e:	je     101aa79 <index_prepare+0x309>
 101aa40:	mov    0x38(%rbx),%rcx
 101aa44:	shl    $0x4,%rcx
 101aa48:	mov    0x18(%r14),%rax
 101aa4c:	sub    %rcx,%rax
 101aa4f:	jb     101ab0b <index_prepare+0x39b>
 101aa55:	mov    0x1608(%r14),%rdx
 101aa5c:	mov    0x30(%rdx),%rsi
 101aa60:	sub    %rcx,%rsi
 101aa63:	jb     101ab0b <index_prepare+0x39b>
 101aa69:	mov    %rax,0x18(%r14)
 101aa6d:	mov    %rsi,0x30(%rdx)
 101aa71:	vzeroupper
 101aa74:	call   10276f0 <free@plt>
 101aa79:	vxorps %xmm0,%xmm0,%xmm0
 101aa7d:	vmovups %ymm0,0x20(%rbx)
 101aa82:	vmovups %ymm0,(%rbx)
 101aa86:	xor    %eax,%eax
 101aa88:	add    $0x38,%rsp
 101aa8c:	pop    %rbx
 101aa8d:	pop    %r12
 101aa8f:	pop    %r13
 101aa91:	pop    %r14
 101aa93:	pop    %r15
 101aa95:	pop    %rbp
 101aa96:	vzeroupper
 101aa99:	ret
 101aa9a:	mov    %rsi,-0x30(%rbp)
 101aa9e:	mov    $0x1,%edi
 101aaa3:	mov    %rcx,%rsi
 101aaa6:	mov    %rcx,-0x50(%rbp)
 101aaaa:	mov    %rdx,-0x38(%rbp)
 101aaae:	vzeroupper
 101aab1:	call   1027690 <calloc@plt>
 101aab6:	mov    -0x38(%rbp),%rcx
 101aaba:	test   %rax,%rax
 101aabd:	je     101a946 <index_prepare+0x1d6>
 101aac3:	mov    %rax,%rdx
 101aac6:	mov    -0x30(%rbp),%rax
 101aaca:	mov    %rax,0x18(%r14)
 101aace:	mov    -0x50(%rbp),%rax
 101aad2:	add    %rax,0x30(%r15)
 101aad6:	test   %r13,%r13
 101aad9:	je     101aafe <index_prepare+0x38e>
 101aadb:	mov    0x98(%r15),%rsi
 101aae2:	shl    $0x4,%r13
 101aae6:	mov    %rdx,-0x30(%rbp)
 101aaea:	mov    -0x30(%rbp),%rdi
 101aaee:	mov    %r13,%rdx
 101aaf1:	call   10276a0 <memcpy@plt>
 101aaf6:	mov    -0x30(%rbp),%rdx
 101aafa:	mov    -0x38(%rbp),%rcx
 101aafe:	mov    %rdx,0x30(%rbx)
 101ab02:	mov    %rcx,0x38(%rbx)
 101ab06:	jmp    101a86d <index_prepare+0xfd>
 101ab0b:	vzeroupper
 101ab0e:	call   1018954 <myl_rc_invariant_failed>
 101ab13:	int3
 101ab14:	int3
 101ab15:	int3
 101ab16:	int3
 101ab17:	int3
 101ab18:	int3
 101ab19:	int3
 101ab1a:	int3
 101ab1b:	int3
 101ab1c:	int3
 101ab1d:	int3
 101ab1e:	int3
 101ab1f:	int3

000000000101ab20 <index_commit>:
 101ab20:	push   %rbp
 101ab21:	mov    %rsp,%rbp
 101ab24:	push   %r15
 101ab26:	push   %r14
 101ab28:	push   %r13
 101ab2a:	push   %r12
 101ab2c:	push   %rbx
 101ab2d:	sub    $0x18,%rsp
 101ab31:	mov    %rdx,%r15
 101ab34:	mov    %rsi,%rbx
 101ab37:	mov    %rdi,%r12
 101ab3a:	mov    0x1608(%rdi),%r13
 101ab41:	cmpq   $0x0,(%rdx)
 101ab45:	je     101ac1e <index_commit+0xfe>
 101ab4b:	mov    0x38(%r13),%rdi
 101ab4f:	mov    0x48(%r13),%r14
 101ab53:	cmp    $0x100b5f0,%rdi
 101ab5a:	je     101ab9c <index_commit+0x7c>
 101ab5c:	mov    0x40(%r13),%rax
 101ab60:	cmp    $0xffffffffffffffff,%rax
 101ab64:	je     101ab9c <index_commit+0x7c>
 101ab66:	test   %rdi,%rdi
 101ab69:	je     101ab9c <index_commit+0x7c>
 101ab6b:	shl    $0x4,%rax
 101ab6f:	add    $0x10,%rax
 101ab73:	mov    0x18(%r12),%rcx
 101ab78:	sub    %rax,%rcx
 101ab7b:	jb     101b26c <index_commit+0x74c>
 101ab81:	mov    0x30(%r13),%rdx
 101ab85:	sub    %rax,%rdx
 101ab88:	jb     101b26c <index_commit+0x74c>
 101ab8e:	mov    %rcx,0x18(%r12)
 101ab93:	mov    %rdx,0x30(%r13)
 101ab97:	call   10276f0 <free@plt>
 101ab9c:	movq   $0x100b5f0,0x38(%r13)
 101aba4:	vxorps %xmm0,%xmm0,%xmm0
 101aba8:	vmovups %xmm0,0x40(%r13)
 101abae:	movl   $0x0,0x54(%r13)
 101abb6:	mov    (%r15),%rax
 101abb9:	mov    0x8(%r15),%rcx
 101abbd:	lea    0x1(%rcx),%rdx
 101abc1:	mov    $0x3f,%edi
 101abc6:	cmp    $0x2,%rdx
 101abca:	jb     101abf9 <index_commit+0xd9>
 101abcc:	mov    $0x40,%esi
 101abd1:	mov    %rdx,%rdi
 101abd4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101abe0:	shr    $1,%rdi
 101abe3:	dec    %esi
 101abe5:	cmp    $0x3,%rdx
 101abe9:	mov    %rdi,%rdx
 101abec:	ja     101abe0 <index_commit+0xc0>
 101abee:	cmp    $0x3f,%esi
 101abf1:	mov    $0x3f,%edi
 101abf6:	cmovb  %esi,%edi
 101abf9:	mov    %rax,0x38(%r13)
 101abfd:	mov    %rcx,0x40(%r13)
 101ac01:	mov    %r14,0x48(%r13)
 101ac05:	mov    %edi,0x50(%r13)
 101ac09:	movl   $0x0,0x54(%r13)
 101ac11:	vmovups %xmm0,(%r15)
 101ac16:	mov    0x1608(%r12),%r13
 101ac1e:	cmpq   $0x0,0x10(%r15)
 101ac23:	je     101acff <index_commit+0x1df>
 101ac29:	mov    0x58(%r13),%rdi
 101ac2d:	mov    0x68(%r13),%r14
 101ac31:	cmp    $0x100b5f0,%rdi
 101ac38:	je     101ac7a <index_commit+0x15a>
 101ac3a:	mov    0x60(%r13),%rax
 101ac3e:	cmp    $0xffffffffffffffff,%rax
 101ac42:	je     101ac7a <index_commit+0x15a>
 101ac44:	test   %rdi,%rdi
 101ac47:	je     101ac7a <index_commit+0x15a>
 101ac49:	shl    $0x4,%rax
 101ac4d:	add    $0x10,%rax
 101ac51:	mov    0x18(%r12),%rcx
 101ac56:	sub    %rax,%rcx
 101ac59:	jb     101b26c <index_commit+0x74c>
 101ac5f:	mov    0x30(%r13),%rdx
 101ac63:	sub    %rax,%rdx
 101ac66:	jb     101b26c <index_commit+0x74c>
 101ac6c:	mov    %rcx,0x18(%r12)
 101ac71:	mov    %rdx,0x30(%r13)
 101ac75:	call   10276f0 <free@plt>
 101ac7a:	lea    0x10(%r15),%rax
 101ac7e:	movq   $0x100b5f0,0x58(%r13)
 101ac86:	vxorps %xmm0,%xmm0,%xmm0
 101ac8a:	vmovups %xmm0,0x60(%r13)
 101ac90:	movl   $0x0,0x74(%r13)
 101ac98:	mov    0x10(%r15),%rcx
 101ac9c:	mov    0x18(%r15),%rdx
 101aca0:	lea    0x1(%rdx),%rsi
 101aca4:	mov    $0x3f,%r8d
 101acaa:	cmp    $0x2,%rsi
 101acae:	jb     101acdb <index_commit+0x1bb>
 101acb0:	mov    $0x40,%edi
 101acb5:	mov    %rsi,%r8
 101acb8:	nopl   0x0(%rax,%rax,1)
 101acc0:	shr    $1,%r8
 101acc3:	dec    %edi
 101acc5:	cmp    $0x3,%rsi
 101acc9:	mov    %r8,%rsi
 101accc:	ja     101acc0 <index_commit+0x1a0>
 101acce:	cmp    $0x3f,%edi
 101acd1:	mov    $0x3f,%r8d
 101acd7:	cmovb  %edi,%r8d
 101acdb:	mov    %rcx,0x58(%r13)
 101acdf:	mov    %rdx,0x60(%r13)
 101ace3:	mov    %r14,0x68(%r13)
 101ace7:	mov    %r8d,0x70(%r13)
 101aceb:	movl   $0x0,0x74(%r13)
 101acf3:	vmovups %xmm0,(%rax)
 101acf7:	mov    0x1608(%r12),%r13
 101acff:	cmpq   $0x0,0x20(%r15)
 101ad04:	je     101adfb <index_commit+0x2db>
 101ad0a:	mov    0x78(%r13),%rdi
 101ad0e:	mov    0x88(%r13),%r14
 101ad15:	cmp    $0x100b5f0,%rdi
 101ad1c:	je     101ad61 <index_commit+0x241>
 101ad1e:	mov    0x80(%r13),%rax
 101ad25:	cmp    $0xffffffffffffffff,%rax
 101ad29:	je     101ad61 <index_commit+0x241>
 101ad2b:	test   %rdi,%rdi
 101ad2e:	je     101ad61 <index_commit+0x241>
 101ad30:	shl    $0x4,%rax
 101ad34:	add    $0x10,%rax
 101ad38:	mov    0x18(%r12),%rcx
 101ad3d:	sub    %rax,%rcx
 101ad40:	jb     101b26c <index_commit+0x74c>
 101ad46:	mov    0x30(%r13),%rdx
 101ad4a:	sub    %rax,%rdx
 101ad4d:	jb     101b26c <index_commit+0x74c>
 101ad53:	mov    %rcx,0x18(%r12)
 101ad58:	mov    %rdx,0x30(%r13)
 101ad5c:	call   10276f0 <free@plt>
 101ad61:	lea    0x20(%r15),%rax
 101ad65:	movq   $0x100b5f0,0x78(%r13)
 101ad6d:	vxorps %xmm0,%xmm0,%xmm0
 101ad71:	vmovups %xmm0,0x80(%r13)
 101ad7a:	movl   $0x0,0x94(%r13)
 101ad85:	mov    0x20(%r15),%rcx
 101ad89:	mov    0x28(%r15),%rdx
 101ad8d:	lea    0x1(%rdx),%rsi
 101ad91:	mov    $0x3f,%r8d
 101ad97:	cmp    $0x2,%rsi
 101ad9b:	jb     101adcb <index_commit+0x2ab>
 101ad9d:	mov    $0x40,%edi
 101ada2:	mov    %rsi,%r8
 101ada5:	data16 cs nopw 0x0(%rax,%rax,1)
 101adb0:	shr    $1,%r8
 101adb3:	dec    %edi
 101adb5:	cmp    $0x3,%rsi
 101adb9:	mov    %r8,%rsi
 101adbc:	ja     101adb0 <index_commit+0x290>
 101adbe:	cmp    $0x3f,%edi
 101adc1:	mov    $0x3f,%r8d
 101adc7:	cmovb  %edi,%r8d
 101adcb:	mov    %rcx,0x78(%r13)
 101adcf:	mov    %rdx,0x80(%r13)
 101add6:	mov    %r14,0x88(%r13)
 101addd:	mov    %r8d,0x90(%r13)
 101ade4:	movl   $0x0,0x94(%r13)
 101adef:	vmovups %xmm0,(%rax)
 101adf3:	mov    0x1608(%r12),%r13
 101adfb:	mov    0x30(%r15),%rax
 101adff:	test   %rax,%rax
 101ae02:	je     101ae62 <index_commit+0x342>
 101ae04:	mov    0x98(%r13),%rdi
 101ae0b:	test   %rdi,%rdi
 101ae0e:	je     101ae48 <index_commit+0x328>
 101ae10:	mov    0xa0(%r13),%rcx
 101ae17:	shl    $0x4,%rcx
 101ae1b:	mov    0x18(%r12),%rax
 101ae20:	sub    %rcx,%rax
 101ae23:	jb     101b26c <index_commit+0x74c>
 101ae29:	mov    0x30(%r13),%rdx
 101ae2d:	sub    %rcx,%rdx
 101ae30:	jb     101b26c <index_commit+0x74c>
 101ae36:	mov    %rax,0x18(%r12)
 101ae3b:	mov    %rdx,0x30(%r13)
 101ae3f:	call   10276f0 <free@plt>
 101ae44:	mov    0x30(%r15),%rax
 101ae48:	mov    %rax,0x98(%r13)
 101ae4f:	mov    0x38(%r15),%rax
 101ae53:	mov    %rax,0xa0(%r13)
 101ae5a:	movq   $0x0,0x30(%r15)
 101ae62:	mov    0x8(%rbx),%rax
 101ae66:	test   %rax,%rax
 101ae69:	je     101aef4 <index_commit+0x3d4>
 101ae6f:	mov    0x1608(%r12),%rcx
 101ae77:	mov    0x38(%rcx),%rdx
 101ae7b:	cmp    $0x100b5f0,%rdx
 101ae82:	je     101b26c <index_commit+0x74c>
 101ae88:	mov    0x40(%rcx),%rdi
 101ae8c:	cmp    $0xffffffffffffffff,%rdi
 101ae90:	je     101b26c <index_commit+0x74c>
 101ae96:	mov    0x48(%rcx),%rsi
 101ae9a:	lea    0x1(%rdi),%r8
 101ae9e:	shr    $1,%r8
 101aea1:	cmp    %r8,%rsi
 101aea4:	ja     101b26c <index_commit+0x74c>
 101aeaa:	movzbl 0x50(%rcx),%r8d
 101aeaf:	mov    %rax,%r9
 101aeb2:	movabs $0x9e3779b97f4a7c15,%r10
 101aebc:	imul   %r10,%r9
 101aec0:	shrx   %r8,%r9,%r9
 101aec5:	data16 cs nopw 0x0(%rax,%rax,1)
 101aed0:	and    %rdi,%r9
 101aed3:	mov    %r9,%r8
 101aed6:	shl    $0x4,%r8
 101aeda:	mov    (%rdx,%r8,1),%r10
 101aede:	test   %r10,%r10
 101aee1:	je     101aeeb <index_commit+0x3cb>
 101aee3:	inc    %r9
 101aee6:	cmp    %rax,%r10
 101aee9:	jne    101aed0 <index_commit+0x3b0>
 101aeeb:	test   %r10,%r10
 101aeee:	je     101b0aa <index_commit+0x58a>
 101aef4:	mov    0x20(%rbx),%rax
 101aef8:	test   %rax,%rax
 101aefb:	je     101b0c8 <index_commit+0x5a8>
 101af01:	xor    %ecx,%ecx
 101af03:	jmp    101af1c <index_commit+0x3fc>
 101af05:	data16 cs nopw 0x0(%rax,%rax,1)
 101af10:	inc    %rcx
 101af13:	cmp    %rax,%rcx
 101af16:	je     101b0c8 <index_commit+0x5a8>
 101af1c:	mov    0x38(%rbx),%rdx
 101af20:	test   %rdx,%rdx
 101af23:	je     101af50 <index_commit+0x430>
 101af25:	mov    0x8(%rdx),%rdx
 101af29:	mov    (%rdx,%rcx,8),%rsi
 101af2d:	mov    0x1608(%r12),%rdi
 101af35:	mov    0x58(%rdi),%r8
 101af39:	cmp    $0x100b5f0,%r8
 101af40:	jne    101af74 <index_commit+0x454>
 101af42:	jmp    101b26c <index_commit+0x74c>
 101af47:	nopw   0x0(%rax,%rax,1)
 101af50:	mov    %rcx,%rsi
 101af53:	shl    $0x6,%rsi
 101af57:	add    0x10(%rbx),%rsi
 101af5b:	mov    0x1608(%r12),%rdi
 101af63:	mov    0x58(%rdi),%r8
 101af67:	cmp    $0x100b5f0,%r8
 101af6e:	je     101b26c <index_commit+0x74c>
 101af74:	mov    0x60(%rdi),%r10
 101af78:	cmp    $0xffffffffffffffff,%r10
 101af7c:	je     101b26c <index_commit+0x74c>
 101af82:	mov    0x68(%rdi),%r9
 101af86:	lea    0x1(%r10),%rdx
 101af8a:	shr    $1,%rdx
 101af8d:	cmp    %rdx,%r9
 101af90:	ja     101b26c <index_commit+0x74c>
 101af96:	lea    0x8(%rsi),%rdx
 101af9a:	movzbl 0x70(%rdi),%r11d
 101af9f:	mov    %rdx,%r14
 101afa2:	movabs $0x9e3779b97f4a7c15,%r15
 101afac:	imul   %r15,%r14
 101afb0:	shrx   %r11,%r14,%r14
 101afb5:	data16 cs nopw 0x0(%rax,%rax,1)
 101afc0:	and    %r10,%r14
 101afc3:	mov    %r14,%r11
 101afc6:	shl    $0x4,%r11
 101afca:	mov    (%r8,%r11,1),%r15
 101afce:	test   %r15,%r15
 101afd1:	je     101afdb <index_commit+0x4bb>
 101afd3:	inc    %r14
 101afd6:	cmp    %rdx,%r15
 101afd9:	jne    101afc0 <index_commit+0x4a0>
 101afdb:	test   %r15,%r15
 101afde:	je     101aff0 <index_commit+0x4d0>
 101afe0:	mov    (%rsi),%rsi
 101afe3:	test   %rsi,%rsi
 101afe6:	jne    101b00d <index_commit+0x4ed>
 101afe8:	jmp    101af10 <index_commit+0x3f0>
 101afed:	nopl   (%rax)
 101aff0:	add    %r11,%r8
 101aff3:	mov    %rdx,(%r8)
 101aff6:	mov    %rdx,0x8(%r8)
 101affa:	inc    %r9
 101affd:	mov    %r9,0x68(%rdi)
 101b001:	mov    (%rsi),%rsi
 101b004:	test   %rsi,%rsi
 101b007:	je     101af10 <index_commit+0x3f0>
 101b00d:	mov    0x1608(%r12),%rdi
 101b015:	mov    0x58(%rdi),%r8
 101b019:	cmp    $0x100b5f0,%r8
 101b020:	je     101b26c <index_commit+0x74c>
 101b026:	mov    0x60(%rdi),%r10
 101b02a:	cmp    $0xffffffffffffffff,%r10
 101b02e:	je     101b26c <index_commit+0x74c>
 101b034:	mov    0x68(%rdi),%r9
 101b038:	lea    0x1(%r10),%r11
 101b03c:	shr    $1,%r11
 101b03f:	cmp    %r11,%r9
 101b042:	ja     101b26c <index_commit+0x74c>
 101b048:	movzbl 0x70(%rdi),%r11d
 101b04d:	mov    %rsi,%r14
 101b050:	movabs $0x9e3779b97f4a7c15,%r15
 101b05a:	imul   %r15,%r14
 101b05e:	shrx   %r11,%r14,%r14
 101b063:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b070:	and    %r10,%r14
 101b073:	mov    %r14,%r11
 101b076:	shl    $0x4,%r11
 101b07a:	mov    (%r8,%r11,1),%r15
 101b07e:	test   %r15,%r15
 101b081:	je     101b08b <index_commit+0x56b>
 101b083:	inc    %r14
 101b086:	cmp    %rsi,%r15
 101b089:	jne    101b070 <index_commit+0x550>
 101b08b:	test   %r15,%r15
 101b08e:	jne    101af10 <index_commit+0x3f0>
 101b094:	add    %r11,%r8
 101b097:	mov    %rsi,(%r8)
 101b09a:	mov    %rdx,0x8(%r8)
 101b09e:	inc    %r9
 101b0a1:	mov    %r9,0x68(%rdi)
 101b0a5:	jmp    101af10 <index_commit+0x3f0>
 101b0aa:	add    %r8,%rdx
 101b0ad:	mov    %rax,(%rdx)
 101b0b0:	mov    %rbx,0x8(%rdx)
 101b0b4:	inc    %rsi
 101b0b7:	mov    %rsi,0x48(%rcx)
 101b0bb:	mov    0x20(%rbx),%rax
 101b0bf:	test   %rax,%rax
 101b0c2:	jne    101af01 <index_commit+0x3e1>
 101b0c8:	mov    %r13,-0x30(%rbp)
 101b0cc:	mov    %r12,-0x40(%rbp)
 101b0d0:	mov    0x28(%rbx),%rax
 101b0d4:	test   %rax,%rax
 101b0d7:	je     101b25d <index_commit+0x73d>
 101b0dd:	mov    -0x30(%rbp),%rcx
 101b0e1:	add    0xa8(%rcx),%rax
 101b0e8:	lea    0x10(,%rax,4),%rax
 101b0f0:	mov    %rax,-0x38(%rbp)
 101b0f4:	xor    %r13d,%r13d
 101b0f7:	xor    %r12d,%r12d
 101b0fa:	jmp    101b13d <index_commit+0x61d>
 101b0fc:	shl    $0x4,%rcx
 101b100:	mov    0x38(%rbx),%rsi
 101b104:	test   %rsi,%rsi
 101b107:	cmove  %rsi,%r14
 101b10b:	mov    %r14,(%rdx,%rcx,1)
 101b10f:	mov    %r15,0x8(%rdx,%rcx,1)
 101b114:	mov    -0x30(%rbp),%rcx
 101b118:	incq   0xa8(%rcx)
 101b11f:	mov    %eax,%r13d
 101b122:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b130:	inc    %r12
 101b133:	cmp    0x28(%rbx),%r12
 101b137:	jae    101b25d <index_commit+0x73d>
 101b13d:	mov    0x18(%rbx),%rax
 101b141:	imul   $0xc8,%r12,%rcx
 101b148:	lea    (%rax,%rcx,1),%r15
 101b14c:	mov    (%rax,%rcx,1),%r14
 101b150:	mov    0x34(%r14),%eax
 101b154:	test   %eax,%eax
 101b156:	setne  %cl
 101b159:	cmp    %r13d,%eax
 101b15c:	seta   %dl
 101b15f:	and    %cl,%dl
 101b161:	cmp    $0x1,%dl
 101b164:	jne    101b1b0 <index_commit+0x690>
 101b166:	mov    %eax,%ecx
 101b168:	cmp    %rcx,-0x38(%rbp)
 101b16c:	jbe    101b1b0 <index_commit+0x690>
 101b16e:	mov    -0x30(%rbp),%rsi
 101b172:	mov    0x98(%rsi),%rdx
 101b179:	cmp    %rcx,0xa0(%rsi)
 101b180:	jbe    101b0fc <index_commit+0x5dc>
 101b186:	mov    %rcx,%rsi
 101b189:	shl    $0x4,%rsi
 101b18d:	cmpq   $0x0,(%rdx,%rsi,1)
 101b192:	jne    101b1b0 <index_commit+0x690>
 101b194:	add    %rdx,%rsi
 101b197:	cmpq   $0x0,0x8(%rsi)
 101b19c:	je     101b0fc <index_commit+0x5dc>
 101b1a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b1b0:	cmpq   $0x0,0x38(%rbx)
 101b1b5:	jne    101b1bf <index_commit+0x69f>
 101b1b7:	mov    %r15,%rdi
 101b1ba:	call   1019050 <flat_build>
 101b1bf:	mov    -0x40(%rbp),%rax
 101b1c3:	mov    0x1608(%rax),%rax
 101b1ca:	mov    0x78(%rax),%rcx
 101b1ce:	cmp    $0x100b5f0,%rcx
 101b1d5:	je     101b26c <index_commit+0x74c>
 101b1db:	mov    0x80(%rax),%rsi
 101b1e2:	cmp    $0xffffffffffffffff,%rsi
 101b1e6:	je     101b26c <index_commit+0x74c>
 101b1ec:	mov    0x88(%rax),%rdx
 101b1f3:	lea    0x1(%rsi),%rdi
 101b1f7:	shr    $1,%rdi
 101b1fa:	cmp    %rdi,%rdx
 101b1fd:	ja     101b26c <index_commit+0x74c>
 101b1ff:	movzbl 0x90(%rax),%edi
 101b206:	mov    %r14,%r8
 101b209:	movabs $0x9e3779b97f4a7c15,%r9
 101b213:	imul   %r9,%r8
 101b217:	shrx   %rdi,%r8,%rdi
 101b21c:	nopl   0x0(%rax)
 101b220:	and    %rsi,%rdi
 101b223:	mov    %rdi,%r8
 101b226:	shl    $0x4,%r8
 101b22a:	mov    (%rcx,%r8,1),%r9
 101b22e:	test   %r9,%r9
 101b231:	je     101b23b <index_commit+0x71b>
 101b233:	inc    %rdi
 101b236:	cmp    %r14,%r9
 101b239:	jne    101b220 <index_commit+0x700>
 101b23b:	test   %r9,%r9
 101b23e:	jne    101b130 <index_commit+0x610>
 101b244:	add    %r8,%rcx
 101b247:	mov    %r14,(%rcx)
 101b24a:	mov    %r15,0x8(%rcx)
 101b24e:	inc    %rdx
 101b251:	mov    %rdx,0x88(%rax)
 101b258:	jmp    101b130 <index_commit+0x610>
 101b25d:	add    $0x18,%rsp
 101b261:	pop    %rbx
 101b262:	pop    %r12
 101b264:	pop    %r13
 101b266:	pop    %r14
 101b268:	pop    %r15
 101b26a:	pop    %rbp
 101b26b:	ret
 101b26c:	call   1018954 <myl_rc_invariant_failed>
 101b271:	int3
 101b272:	int3
 101b273:	int3
 101b274:	int3
 101b275:	int3
 101b276:	int3
 101b277:	int3
 101b278:	int3
 101b279:	int3
 101b27a:	int3
 101b27b:	int3
 101b27c:	int3
 101b27d:	int3
 101b27e:	int3
 101b27f:	int3

000000000101b280 <map_prepare>:
 101b280:	push   %rbp
 101b281:	mov    %rsp,%rbp
 101b284:	push   %r15
 101b286:	push   %r14
 101b288:	push   %r13
 101b28a:	push   %r12
 101b28c:	push   %rbx
 101b28d:	sub    $0x18,%rsp
 101b291:	vxorps %xmm0,%xmm0,%xmm0
 101b295:	vmovups %xmm0,(%rcx)
 101b299:	mov    (%rsi),%r14
 101b29c:	xor    %eax,%eax
 101b29e:	cmp    $0x100b5f0,%r14
 101b2a5:	je     101b2b9 <map_prepare+0x39>
 101b2a7:	mov    0x8(%rsi),%r8
 101b2ab:	inc    %r8
 101b2ae:	add    0x10(%rsi),%rdx
 101b2b2:	jae    101b2c6 <map_prepare+0x46>
 101b2b4:	jmp    101b469 <map_prepare+0x1e9>
 101b2b9:	xor    %r8d,%r8d
 101b2bc:	add    0x10(%rsi),%rdx
 101b2c0:	jb     101b469 <map_prepare+0x1e9>
 101b2c6:	mov    %r8,%r9
 101b2c9:	shr    $1,%r9
 101b2cc:	cmp    %r9,%rdx
 101b2cf:	jbe    101b464 <map_prepare+0x1e4>
 101b2d5:	test   %r8,%r8
 101b2d8:	mov    $0x20,%r15d
 101b2de:	cmovne %r8,%r15
 101b2e2:	mov    %r15,%r8
 101b2e5:	shr    $1,%r8
 101b2e8:	cmp    %r8,%rdx
 101b2eb:	jbe    101b30b <map_prepare+0x8b>
 101b2ed:	mov    %r15,%r8
 101b2f0:	cmp    $0x7fffffff,%r8
 101b2f7:	ja     101b469 <map_prepare+0x1e9>
 101b2fd:	lea    (%r8,%r8,1),%r15
 101b301:	cmp    %r8,%rdx
 101b304:	mov    %r15,%r8
 101b307:	ja     101b2f0 <map_prepare+0x70>
 101b309:	jmp    101b318 <map_prepare+0x98>
 101b30b:	mov    %r15,%rdx
 101b30e:	shr    $0x3c,%rdx
 101b312:	jne    101b469 <map_prepare+0x1e9>
 101b318:	test   %rdi,%rdi
 101b31b:	je     101b478 <map_prepare+0x1f8>
 101b321:	test   %r15,%r15
 101b324:	je     101b478 <map_prepare+0x1f8>
 101b32a:	mov    0x1608(%rdi),%r12
 101b331:	test   %r12,%r12
 101b334:	je     101b478 <map_prepare+0x1f8>
 101b33a:	mov    %r15,%rbx
 101b33d:	shl    $0x4,%rbx
 101b341:	mov    0x18(%rdi),%r13
 101b345:	add    %rbx,%r13
 101b348:	jb     101b358 <map_prepare+0xd8>
 101b34a:	mov    0x58(%rdi),%rdx
 101b34e:	test   %rdx,%rdx
 101b351:	je     101b364 <map_prepare+0xe4>
 101b353:	cmp    %rdx,%r13
 101b356:	jbe    101b364 <map_prepare+0xe4>
 101b358:	movl   $0x1,0x6c(%rdi)
 101b35f:	jmp    101b469 <map_prepare+0x1e9>
 101b364:	mov    %rdi,-0x30(%rbp)
 101b368:	mov    %rsi,-0x40(%rbp)
 101b36c:	mov    %rcx,-0x38(%rbp)
 101b370:	mov    $0x1,%edi
 101b375:	mov    %rbx,%rsi
 101b378:	call   1027690 <calloc@plt>
 101b37d:	mov    %rax,%rcx
 101b380:	xor    %eax,%eax
 101b382:	test   %rcx,%rcx
 101b385:	je     101b469 <map_prepare+0x1e9>
 101b38b:	mov    -0x30(%rbp),%rax
 101b38f:	mov    %r13,0x18(%rax)
 101b393:	add    %rbx,0x30(%r12)
 101b398:	mov    $0x3f,%edx
 101b39d:	cmp    $0x2,%r15
 101b3a1:	mov    -0x38(%rbp),%rax
 101b3a5:	mov    -0x40(%rbp),%rsi
 101b3a9:	jb     101b3d9 <map_prepare+0x159>
 101b3ab:	mov    $0x40,%edi
 101b3b0:	mov    %r15,%r8
 101b3b3:	mov    %r15,%rdx
 101b3b6:	cs nopw 0x0(%rax,%rax,1)
 101b3c0:	shr    $1,%rdx
 101b3c3:	dec    %edi
 101b3c5:	cmp    $0x3,%r8
 101b3c9:	mov    %rdx,%r8
 101b3cc:	ja     101b3c0 <map_prepare+0x140>
 101b3ce:	cmp    $0x3f,%edi
 101b3d1:	mov    $0x3f,%edx
 101b3d6:	cmovb  %edi,%edx
 101b3d9:	dec    %r15
 101b3dc:	cmp    $0x100b5f0,%r14
 101b3e3:	je     101b45d <map_prepare+0x1dd>
 101b3e5:	mov    0x8(%rsi),%rsi
 101b3e9:	inc    %rsi
 101b3ec:	xor    %edi,%edi
 101b3ee:	movabs $0x9e3779b97f4a7c15,%r8
 101b3f8:	jmp    101b40f <map_prepare+0x18f>
 101b3fa:	nopw   0x0(%rax,%rax,1)
 101b400:	add    %rcx,%rbx
 101b403:	vmovups (%r9),%xmm0
 101b408:	vmovups %xmm0,(%rbx)
 101b40c:	inc    %rdi
 101b40f:	cmp    %rsi,%rdi
 101b412:	je     101b45d <map_prepare+0x1dd>
 101b414:	mov    %rdi,%r9
 101b417:	shl    $0x4,%r9
 101b41b:	mov    (%r14,%r9,1),%r10
 101b41f:	test   %r10,%r10
 101b422:	je     101b40c <map_prepare+0x18c>
 101b424:	add    %r14,%r9
 101b427:	mov    %r10,%r11
 101b42a:	imul   %r8,%r11
 101b42e:	shrx   %rdx,%r11,%r11
 101b433:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b440:	and    %r15,%r11
 101b443:	mov    %r11,%rbx
 101b446:	shl    $0x4,%rbx
 101b44a:	mov    (%rcx,%rbx,1),%r12
 101b44e:	test   %r12,%r12
 101b451:	je     101b400 <map_prepare+0x180>
 101b453:	inc    %r11
 101b456:	cmp    %r10,%r12
 101b459:	jne    101b440 <map_prepare+0x1c0>
 101b45b:	jmp    101b400 <map_prepare+0x180>
 101b45d:	mov    %rcx,(%rax)
 101b460:	mov    %r15,0x8(%rax)
 101b464:	mov    $0x1,%eax
 101b469:	add    $0x18,%rsp
 101b46d:	pop    %rbx
 101b46e:	pop    %r12
 101b470:	pop    %r13
 101b472:	pop    %r14
 101b474:	pop    %r15
 101b476:	pop    %rbp
 101b477:	ret
 101b478:	call   1018954 <myl_rc_invariant_failed>
 101b47d:	int3
 101b47e:	int3
 101b47f:	int3

000000000101b480 <myl_rc_edges_release>:
 101b480:	push   %rbp
 101b481:	mov    %rsp,%rbp
 101b484:	push   %r15
 101b486:	push   %r14
 101b488:	push   %r13
 101b48a:	push   %r12
 101b48c:	push   %rbx
 101b48d:	sub    $0x48,%rsp
 101b491:	test   %rdi,%rdi
 101b494:	je     101ba37 <myl_rc_edges_release+0x5b7>
 101b49a:	mov    %rdi,%r10
 101b49d:	mov    0x1608(%rdi),%rdi
 101b4a4:	test   %rdi,%rdi
 101b4a7:	je     101ba37 <myl_rc_edges_release+0x5b7>
 101b4ad:	cmpq   $0x0,0xc0(%rdi)
 101b4b5:	jne    101ba37 <myl_rc_edges_release+0x5b7>
 101b4bb:	mov    %rdx,%r14
 101b4be:	mov    0x58(%rdi),%rax
 101b4c2:	mov    0x60(%rdi),%rdx
 101b4c6:	movzbl 0x70(%rdi),%r8d
 101b4cb:	movabs $0x9e3779b97f4a7c15,%rdi
 101b4d5:	imul   %rsi,%rdi
 101b4d9:	shrx   %r8,%rdi,%r8
 101b4de:	xchg   %ax,%ax
 101b4e0:	and    %rdx,%r8
 101b4e3:	mov    %r8,%rdi
 101b4e6:	shl    $0x4,%rdi
 101b4ea:	mov    (%rax,%rdi,1),%rdi
 101b4ee:	cmp    %rsi,%rdi
 101b4f1:	je     101b501 <myl_rc_edges_release+0x81>
 101b4f3:	test   %rdi,%rdi
 101b4f6:	je     101ba37 <myl_rc_edges_release+0x5b7>
 101b4fc:	inc    %r8
 101b4ff:	jmp    101b4e0 <myl_rc_edges_release+0x60>
 101b501:	shl    $0x4,%r8
 101b505:	mov    0x8(%rax,%r8,1),%r11
 101b50a:	test   %r11,%r11
 101b50d:	je     101ba37 <myl_rc_edges_release+0x5b7>
 101b513:	mov    %rcx,%rax
 101b516:	mulq   (%r11)
 101b519:	jo     101ba37 <myl_rc_edges_release+0x5b7>
 101b51f:	test   %r14,%r14
 101b522:	jne    101b52d <myl_rc_edges_release+0xad>
 101b524:	test   %rax,%rax
 101b527:	jne    101ba37 <myl_rc_edges_release+0x5b7>
 101b52d:	mov    0x8(%r11),%eax
 101b531:	test   %eax,%eax
 101b533:	je     101ba28 <myl_rc_edges_release+0x5a8>
 101b539:	cmp    $0x1,%eax
 101b53c:	mov    %r10,-0x50(%rbp)
 101b540:	jne    101b561 <myl_rc_edges_release+0xe1>
 101b542:	test   %rcx,%rcx
 101b545:	je     101ba28 <myl_rc_edges_release+0x5a8>
 101b54b:	movabs $0x4000000000000002,%rbx
 101b555:	xor    %r15d,%r15d
 101b558:	lea    0x1(%rbx),%r12
 101b55c:	jmp    101b93c <myl_rc_edges_release+0x4bc>
 101b561:	test   %rcx,%rcx
 101b564:	je     101ba28 <myl_rc_edges_release+0x5a8>
 101b56a:	mov    0x28(%r11),%rax
 101b56e:	mov    %rax,-0x68(%rbp)
 101b572:	xor    %r15d,%r15d
 101b575:	jmp    101b5d1 <myl_rc_edges_release+0x151>
 101b577:	nopw   0x0(%rax,%rax,1)
 101b580:	mov    0xb0(%rax),%rdx
 101b587:	lea    0x1(%rcx),%rsi
 101b58b:	mov    %rsi,0xc0(%rax)
 101b592:	lea    (%rcx,%rcx,2),%rax
 101b596:	mov    %r11,(%rdx,%rax,8)
 101b59a:	mov    %r14,0x8(%rdx,%rax,8)
 101b59f:	movq   $0x0,0x10(%rdx,%rax,8)
 101b5a8:	mov    %r10,%rdi
 101b5ab:	mov    $0x1,%esi
 101b5b0:	mov    %r11,%r12
 101b5b3:	call   101ba40 <walk>
 101b5b8:	mov    %r12,%r11
 101b5bb:	mov    -0x50(%rbp),%r10
 101b5bf:	mov    %rbx,%rcx
 101b5c2:	add    (%r11),%r14
 101b5c5:	inc    %r15
 101b5c8:	cmp    %rcx,%r15
 101b5cb:	je     101ba28 <myl_rc_edges_release+0x5a8>
 101b5d1:	mov    0x8(%r11),%r8d
 101b5d5:	cmpq   $0x2,-0x68(%rbp)
 101b5da:	jbe    101b600 <myl_rc_edges_release+0x180>
 101b5dc:	mov    %rcx,%rbx
 101b5df:	test   %r8d,%r8d
 101b5e2:	je     101b5a8 <myl_rc_edges_release+0x128>
 101b5e4:	mov    0x1608(%r10),%rax
 101b5eb:	mov    0xc0(%rax),%rcx
 101b5f2:	cmp    0xb8(%rax),%rcx
 101b5f9:	jb     101b580 <myl_rc_edges_release+0x100>
 101b5fb:	jmp    101ba37 <myl_rc_edges_release+0x5b7>
 101b600:	lea    -0x1(%r8),%eax
 101b604:	cmp    $0x4,%eax
 101b607:	ja     101b66c <myl_rc_edges_release+0x1ec>
 101b609:	jmp    *0x1001ae0(,%rax,8)
 101b610:	mov    $0x1,%edi
 101b615:	jmp    101b66e <myl_rc_edges_release+0x1ee>
 101b617:	mov    0x10(%r11),%rax
 101b61b:	mov    %rax,-0x38(%rbp)
 101b61f:	mov    0x18(%r11),%rdi
 101b623:	mov    0x20(%r11),%r13
 101b627:	add    %r14,%r13
 101b62a:	mov    $0x4,%r8d
 101b630:	movq   $0x0,-0x48(%rbp)
 101b638:	jmp    101b681 <myl_rc_edges_release+0x201>
 101b63a:	mov    0x10(%r11),%rax
 101b63e:	mov    %rax,-0x38(%rbp)
 101b642:	mov    0x18(%r11),%rdi
 101b646:	mov    $0x2,%r8d
 101b64c:	movq   $0x0,-0x48(%rbp)
 101b654:	jmp    101b67e <myl_rc_edges_release+0x1fe>
 101b656:	mov    0x10(%r11),%rax
 101b65a:	mov    0x18(%r11),%rdi
 101b65e:	mov    0x20(%r11),%rdx
 101b662:	mov    %rdx,-0x48(%rbp)
 101b666:	mov    0x8(%rax),%r8d
 101b66a:	jmp    101b676 <myl_rc_edges_release+0x1f6>
 101b66c:	xor    %edi,%edi
 101b66e:	movq   $0x0,-0x48(%rbp)
 101b676:	movq   $0x0,-0x38(%rbp)
 101b67e:	xor    %r13d,%r13d
 101b681:	mov    %rdi,%r12
 101b684:	neg    %r12
 101b687:	xor    %ebx,%ebx
 101b689:	mov    %rdi,-0x30(%rbp)
 101b68d:	cmpq   $0x0,-0x38(%rbp)
 101b692:	je     101b770 <myl_rc_edges_release+0x2f0>
 101b698:	cmp    %rdi,%rbx
 101b69b:	jae    101b5c2 <myl_rc_edges_release+0x142>
 101b6a1:	lea    (%rbx,%rbx,2),%rax
 101b6a5:	mov    -0x38(%rbp),%rdx
 101b6a9:	lea    (%rdx,%rax,8),%rax
 101b6ad:	inc    %rbx
 101b6b0:	jmp    101b6d8 <myl_rc_edges_release+0x258>
 101b6b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b6c0:	add    $0x18,%rax
 101b6c4:	lea    (%r12,%rbx,1),%rdx
 101b6c8:	inc    %rdx
 101b6cb:	inc    %rbx
 101b6ce:	cmp    $0x1,%rdx
 101b6d2:	je     101b5c2 <myl_rc_edges_release+0x142>
 101b6d8:	mov    0x8(%rax),%rdx
 101b6dc:	mov    0x8(%rdx),%edi
 101b6df:	test   %edi,%edi
 101b6e1:	je     101b6c0 <myl_rc_edges_release+0x240>
 101b6e3:	test   %r13,%r13
 101b6e6:	je     101b6f1 <myl_rc_edges_release+0x271>
 101b6e8:	mov    0x10(%rax),%edx
 101b6eb:	cmp    0x0(%r13),%edx
 101b6ef:	jne    101b6c0 <myl_rc_edges_release+0x240>
 101b6f1:	mov    (%rax),%rax
 101b6f4:	mov    (%r14,%rax,1),%rsi
 101b6f8:	movq   $0x0,(%r14,%rax,1)
 101b700:	cmp    $0x5,%edi
 101b703:	je     101b79c <myl_rc_edges_release+0x31c>
 101b709:	test   %rsi,%rsi
 101b70c:	mov    -0x30(%rbp),%rdi
 101b710:	je     101b68d <myl_rc_edges_release+0x20d>
 101b716:	mov    -0x10(%rsi),%rdx
 101b71a:	movabs $0x4000000000000002,%rax
 101b724:	test   %rax,%rdx
 101b727:	jne    101b68d <myl_rc_edges_release+0x20d>
 101b72d:	test   $0x1,%dl
 101b730:	jne    101ba37 <myl_rc_edges_release+0x5b7>
 101b736:	mov    -0x20(%rsi),%rax
 101b73a:	test   %rax,%rax
 101b73d:	je     101ba37 <myl_rc_edges_release+0x5b7>
 101b743:	lea    -0x20(%rsi),%r9
 101b747:	dec    %rax
 101b74a:	mov    %rax,(%r9)
 101b74d:	jne    101b68d <myl_rc_edges_release+0x20d>
 101b753:	cmpq   $0x0,-0x18(%rsi)
 101b758:	jne    101b68d <myl_rc_edges_release+0x20d>
 101b75e:	jmp    101b7eb <myl_rc_edges_release+0x36b>
 101b763:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b770:	cmp    %rdi,%rbx
 101b773:	je     101b5c2 <myl_rc_edges_release+0x142>
 101b779:	mov    %rbx,%rax
 101b77c:	inc    %rbx
 101b77f:	imul   -0x48(%rbp),%rax
 101b784:	mov    %r8d,%edi
 101b787:	mov    (%r14,%rax,1),%rsi
 101b78b:	movq   $0x0,(%r14,%rax,1)
 101b793:	cmp    $0x5,%edi
 101b796:	jne    101b709 <myl_rc_edges_release+0x289>
 101b79c:	test   %rsi,%rsi
 101b79f:	mov    -0x30(%rbp),%rdi
 101b7a3:	je     101b68d <myl_rc_edges_release+0x20d>
 101b7a9:	mov    -0x10(%rsi),%rdx
 101b7ad:	movabs $0x4000000000000002,%rax
 101b7b7:	test   %rax,%rdx
 101b7ba:	jne    101b68d <myl_rc_edges_release+0x20d>
 101b7c0:	test   $0x1,%dl
 101b7c3:	jne    101ba37 <myl_rc_edges_release+0x5b7>
 101b7c9:	mov    -0x18(%rsi),%rax
 101b7cd:	test   %rax,%rax
 101b7d0:	je     101ba37 <myl_rc_edges_release+0x5b7>
 101b7d6:	dec    %rax
 101b7d9:	mov    %rax,-0x18(%rsi)
 101b7dd:	or     -0x20(%rsi),%rax
 101b7e1:	jne    101b68d <myl_rc_edges_release+0x20d>
 101b7e7:	lea    -0x20(%rsi),%r9
 101b7eb:	or     $0x1,%rdx
 101b7ef:	mov    %rdx,-0x10(%rsi)
 101b7f3:	mov    0x1608(%r10),%rdi
 101b7fa:	cmpl   $0x0,0xd0(%rdi)
 101b801:	je     101b824 <myl_rc_edges_release+0x3a4>
 101b803:	mov    0xc8(%rdi),%rax
 101b80a:	mov    %rax,(%r9)
 101b80d:	mov    0x1608(%r10),%rax
 101b814:	mov    %r9,0xc8(%rax)
 101b81b:	mov    -0x30(%rbp),%rdi
 101b81f:	jmp    101b68d <myl_rc_edges_release+0x20d>
 101b824:	mov    -0x8(%rsi),%rax
 101b828:	cmp    %rax,0x110(%rdi)
 101b82f:	mov    %r8,-0x40(%rbp)
 101b833:	je     101b89c <myl_rc_edges_release+0x41c>
 101b835:	mov    0x34(%rax),%edx
 101b838:	cmp    %rdx,0xa0(%rdi)
 101b83f:	jbe    101b8e4 <myl_rc_edges_release+0x464>
 101b845:	mov    0x98(%rdi),%r8
 101b84c:	shl    $0x4,%rdx
 101b850:	cmp    %rax,(%r8,%rdx,1)
 101b854:	jne    101b8e4 <myl_rc_edges_release+0x464>
 101b85a:	add    %rdx,%r8
 101b85d:	mov    0x8(%r8),%rax
 101b861:	mov    -0x30(%rbp),%rdi
 101b865:	test   %rax,%rax
 101b868:	mov    -0x40(%rbp),%r8
 101b86c:	je     101b874 <myl_rc_edges_release+0x3f4>
 101b86e:	cmpl   $0x0,0x40(%rax)
 101b872:	je     101b898 <myl_rc_edges_release+0x418>
 101b874:	mov    0x1608(%r10),%rax
 101b87b:	mov    0xc8(%rax),%rax
 101b882:	mov    %rax,(%r9)
 101b885:	mov    0x1608(%r10),%rax
 101b88c:	mov    %r9,0xc8(%rax)
 101b893:	jmp    101b68d <myl_rc_edges_release+0x20d>
 101b898:	mov    -0x10(%rsi),%rdx
 101b89c:	mov    %r11,-0x58(%rbp)
 101b8a0:	mov    %rcx,-0x60(%rbp)
 101b8a4:	movabs $0x4000000000000002,%rax
 101b8ae:	inc    %rax
 101b8b1:	and    %rdx,%rax
 101b8b4:	cmp    $0x1,%rax
 101b8b8:	jne    101ba37 <myl_rc_edges_release+0x5b7>
 101b8be:	mov    0x1608(%r10),%rax
 101b8c5:	mov    %r10,%rdi
 101b8c8:	call   *0x8(%rax)
 101b8cb:	mov    -0x50(%rbp),%r10
 101b8cf:	mov    -0x60(%rbp),%rcx
 101b8d3:	mov    -0x58(%rbp),%r11
 101b8d7:	mov    -0x40(%rbp),%r8
 101b8db:	mov    -0x30(%rbp),%rdi
 101b8df:	jmp    101b68d <myl_rc_edges_release+0x20d>
 101b8e4:	mov    %rsi,%rdx
 101b8e7:	mov    %rax,%rsi
 101b8ea:	mov    %r11,%r8
 101b8ed:	call   1018f74 <myl_rc_binding_find_slow>
 101b8f2:	mov    %r8,%r11
 101b8f5:	mov    %rdx,%rsi
 101b8f8:	mov    -0x30(%rbp),%rdi
 101b8fc:	test   %rax,%rax
 101b8ff:	mov    -0x40(%rbp),%r8
 101b903:	jne    101b86e <myl_rc_edges_release+0x3ee>
 101b909:	jmp    101b874 <myl_rc_edges_release+0x3f4>
 101b90e:	mov    0xc8(%rdi),%rax
 101b915:	mov    %rax,(%r9)
 101b918:	mov    0x1608(%r10),%rax
 101b91f:	mov    %r9,0xc8(%rax)
 101b926:	cs nopw 0x0(%rax,%rax,1)
 101b930:	inc    %r15
 101b933:	cmp    %r15,%rcx
 101b936:	je     101ba28 <myl_rc_edges_release+0x5a8>
 101b93c:	mov    (%r14,%r15,8),%rsi
 101b940:	movq   $0x0,(%r14,%r15,8)
 101b948:	test   %rsi,%rsi
 101b94b:	je     101b930 <myl_rc_edges_release+0x4b0>
 101b94d:	mov    -0x10(%rsi),%rdx
 101b951:	test   %rbx,%rdx
 101b954:	jne    101b930 <myl_rc_edges_release+0x4b0>
 101b956:	test   $0x1,%dl
 101b959:	jne    101ba37 <myl_rc_edges_release+0x5b7>
 101b95f:	mov    -0x20(%rsi),%rax
 101b963:	test   %rax,%rax
 101b966:	je     101ba37 <myl_rc_edges_release+0x5b7>
 101b96c:	lea    -0x20(%rsi),%r9
 101b970:	dec    %rax
 101b973:	mov    %rax,(%r9)
 101b976:	jne    101b930 <myl_rc_edges_release+0x4b0>
 101b978:	cmpq   $0x0,-0x18(%rsi)
 101b97d:	jne    101b930 <myl_rc_edges_release+0x4b0>
 101b97f:	or     $0x1,%rdx
 101b983:	mov    %rdx,-0x10(%rsi)
 101b987:	mov    0x1608(%r10),%rdi
 101b98e:	cmpl   $0x0,0xd0(%rdi)
 101b995:	jne    101b90e <myl_rc_edges_release+0x48e>
 101b99b:	mov    -0x8(%rsi),%rax
 101b99f:	cmp    %rax,0x110(%rdi)
 101b9a6:	je     101b9ee <myl_rc_edges_release+0x56e>
 101b9a8:	mov    0x34(%rax),%edx
 101b9ab:	cmp    %rdx,0xa0(%rdi)
 101b9b2:	jbe    101ba13 <myl_rc_edges_release+0x593>
 101b9b4:	mov    0x98(%rdi),%r8
 101b9bb:	shl    $0x4,%rdx
 101b9bf:	cmp    %rax,(%r8,%rdx,1)
 101b9c3:	jne    101ba13 <myl_rc_edges_release+0x593>
 101b9c5:	add    %rdx,%r8
 101b9c8:	mov    0x8(%r8),%rax
 101b9cc:	test   %rax,%rax
 101b9cf:	je     101b9d7 <myl_rc_edges_release+0x557>
 101b9d1:	cmpl   $0x0,0x40(%rax)
 101b9d5:	je     101b9ea <myl_rc_edges_release+0x56a>
 101b9d7:	mov    0x1608(%r10),%rax
 101b9de:	mov    0xc8(%rax),%rax
 101b9e5:	jmp    101b915 <myl_rc_edges_release+0x495>
 101b9ea:	mov    -0x10(%rsi),%rdx
 101b9ee:	and    %r12,%rdx
 101b9f1:	cmp    $0x1,%rdx
 101b9f5:	jne    101ba37 <myl_rc_edges_release+0x5b7>
 101b9f7:	mov    %rcx,%r13
 101b9fa:	mov    0x1608(%r10),%rax
 101ba01:	mov    %r10,%rdi
 101ba04:	call   *0x8(%rax)
 101ba07:	mov    -0x50(%rbp),%r10
 101ba0b:	mov    %r13,%rcx
 101ba0e:	jmp    101b930 <myl_rc_edges_release+0x4b0>
 101ba13:	mov    %rsi,%rdx
 101ba16:	mov    %rax,%rsi
 101ba19:	call   1018f74 <myl_rc_binding_find_slow>
 101ba1e:	mov    %rdx,%rsi
 101ba21:	test   %rax,%rax
 101ba24:	jne    101b9d1 <myl_rc_edges_release+0x551>
 101ba26:	jmp    101b9d7 <myl_rc_edges_release+0x557>
 101ba28:	add    $0x48,%rsp
 101ba2c:	pop    %rbx
 101ba2d:	pop    %r12
 101ba2f:	pop    %r13
 101ba31:	pop    %r14
 101ba33:	pop    %r15
 101ba35:	pop    %rbp
 101ba36:	ret
 101ba37:	call   1018954 <myl_rc_invariant_failed>
 101ba3c:	int3
 101ba3d:	int3
 101ba3e:	int3
 101ba3f:	int3

000000000101ba40 <walk>:
 101ba40:	push   %rbp
 101ba41:	mov    %rsp,%rbp
 101ba44:	push   %r14
 101ba46:	push   %rbx
 101ba47:	mov    0x1608(%rdi),%rdx
 101ba4e:	mov    0xc0(%rdx),%rax
 101ba55:	test   %rax,%rax
 101ba58:	je     101bbe4 <walk+0x1a4>
 101ba5e:	mov    %esi,%ebx
 101ba60:	mov    %rdi,%r14
 101ba63:	lea    0xc0(%rdx),%rcx
 101ba6a:	jmp    101ba94 <walk+0x54>
 101ba6c:	nopl   0x0(%rax)
 101ba70:	dec    %rax
 101ba73:	mov    %rax,(%rcx)
 101ba76:	mov    0x1608(%r14),%rdx
 101ba7d:	lea    0xc0(%rdx),%rcx
 101ba84:	mov    0xc0(%rdx),%rax
 101ba8b:	test   %rax,%rax
 101ba8e:	je     101bbe4 <walk+0x1a4>
 101ba94:	mov    0xb0(%rdx),%rsi
 101ba9b:	lea    (%rax,%rax,2),%r8
 101ba9f:	mov    -0x18(%rsi,%r8,8),%rdi
 101baa4:	mov    0x8(%rdi),%r10d
 101baa8:	lea    -0x1(%r10),%r9d
 101baac:	cmp    $0x4,%r9d
 101bab0:	ja     101bbe9 <walk+0x1a9>
 101bab6:	lea    (%rsi,%r8,8),%rsi
 101baba:	jmp    *0x1001b08(,%r9,8)
 101bac2:	mov    -0x10(%rsi),%rax
 101bac6:	mov    (%rax),%rsi
 101bac9:	movq   $0x0,(%rax)
 101bad0:	mov    0x1608(%r14),%rax
 101bad7:	decq   0xc0(%rax)
 101bade:	test   %ebx,%ebx
 101bae0:	je     101ba76 <walk+0x36>
 101bae2:	cmpl   $0x5,0x8(%rdi)
 101bae6:	jne    101bbd7 <walk+0x197>
 101baec:	mov    %r14,%rdi
 101baef:	call   1018e60 <myl_rc_hold_edge_release>
 101baf4:	mov    0x1608(%r14),%rax
 101bafb:	test   %rax,%rax
 101bafe:	je     101ba76 <walk+0x36>
 101bb04:	cmpq   $0x0,0xc8(%rax)
 101bb0c:	je     101ba76 <walk+0x36>
 101bb12:	mov    %r14,%rdi
 101bb15:	call   101be30 <myl_rc_drain>
 101bb1a:	jmp    101ba76 <walk+0x36>
 101bb1f:	nop
 101bb20:	mov    -0x8(%rsi),%r9
 101bb24:	cmp    0x18(%rdi),%r9
 101bb28:	je     101ba70 <walk+0x30>
 101bb2e:	lea    (%r9,%r9,2),%r8
 101bb32:	shl    $0x3,%r8
 101bb36:	add    0x10(%rdi),%r8
 101bb3a:	inc    %r9
 101bb3d:	mov    %r9,-0x8(%rsi)
 101bb41:	mov    -0x10(%rsi),%r9
 101bb45:	cmp    $0x4,%r10d
 101bb49:	jne    101bb5d <walk+0x11d>
 101bb4b:	mov    0x20(%rdi),%rdi
 101bb4f:	mov    0x10(%r8),%r10d
 101bb53:	cmp    (%r9,%rdi,1),%r10d
 101bb57:	jne    101ba76 <walk+0x36>
 101bb5d:	mov    0x8(%r8),%rdi
 101bb61:	cmpl   $0x0,0x8(%rdi)
 101bb65:	je     101ba76 <walk+0x36>
 101bb6b:	cmp    0xb8(%rdx),%rax
 101bb72:	jae    101bbe9 <walk+0x1a9>
 101bb74:	add    (%r8),%r9
 101bb77:	inc    %rax
 101bb7a:	mov    %rax,(%rcx)
 101bb7d:	mov    %rdi,(%rsi)
 101bb80:	mov    %r9,0x8(%rsi)
 101bb84:	jmp    101bbca <walk+0x18a>
 101bb86:	mov    -0x8(%rsi),%r8
 101bb8a:	cmp    0x18(%rdi),%r8
 101bb8e:	je     101ba70 <walk+0x30>
 101bb94:	lea    0x1(%r8),%r9
 101bb98:	mov    %r9,-0x8(%rsi)
 101bb9c:	mov    0x10(%rdi),%r9
 101bba0:	cmpl   $0x0,0x8(%r9)
 101bba5:	je     101ba76 <walk+0x36>
 101bbab:	cmp    0xb8(%rdx),%rax
 101bbb2:	jae    101bbe9 <walk+0x1a9>
 101bbb4:	imul   0x20(%rdi),%r8
 101bbb9:	add    -0x10(%rsi),%r8
 101bbbd:	inc    %rax
 101bbc0:	mov    %rax,(%rcx)
 101bbc3:	mov    %r9,(%rsi)
 101bbc6:	mov    %r8,0x8(%rsi)
 101bbca:	movq   $0x0,0x10(%rsi)
 101bbd2:	jmp    101ba76 <walk+0x36>
 101bbd7:	mov    %r14,%rdi
 101bbda:	call   1018d40 <myl_rc_edge_release>
 101bbdf:	jmp    101ba76 <walk+0x36>
 101bbe4:	pop    %rbx
 101bbe5:	pop    %r14
 101bbe7:	pop    %rbp
 101bbe8:	ret
 101bbe9:	call   1018954 <myl_rc_invariant_failed>
 101bbee:	int3
 101bbef:	int3

000000000101bbf0 <myl_rc_flat_edges_release>:
 101bbf0:	push   %rbp
 101bbf1:	mov    %rsp,%rbp
 101bbf4:	push   %r15
 101bbf6:	push   %r14
 101bbf8:	push   %r13
 101bbfa:	push   %r12
 101bbfc:	push   %rbx
 101bbfd:	sub    $0x18,%rsp
 101bc01:	test   %rdi,%rdi
 101bc04:	je     101be28 <myl_rc_flat_edges_release+0x238>
 101bc0a:	mov    %rdi,%r10
 101bc0d:	mov    0x1608(%rdi),%rax
 101bc14:	test   %rax,%rax
 101bc17:	je     101be28 <myl_rc_flat_edges_release+0x238>
 101bc1d:	cmpq   $0x0,0xc0(%rax)
 101bc25:	jne    101be28 <myl_rc_flat_edges_release+0x238>
 101bc2b:	mov    %rsi,%r15
 101bc2e:	mov    0x40(%rsi),%esi
 101bc31:	cmp    $0x11,%esi
 101bc34:	jae    101be28 <myl_rc_flat_edges_release+0x238>
 101bc3a:	mov    %rdx,%r14
 101bc3d:	mov    0x50(%r15),%rdi
 101bc41:	mov    %rdi,%rax
 101bc44:	mul    %rcx
 101bc47:	jo     101be28 <myl_rc_flat_edges_release+0x238>
 101bc4d:	test   %rax,%rax
 101bc50:	sete   %al
 101bc53:	test   %r14,%r14
 101bc56:	setne  %dl
 101bc59:	or     %al,%dl
 101bc5b:	je     101be28 <myl_rc_flat_edges_release+0x238>
 101bc61:	test   %esi,%esi
 101bc63:	sete   %al
 101bc66:	test   %rcx,%rcx
 101bc69:	sete   %dl
 101bc6c:	or     %al,%dl
 101bc6e:	jne    101be19 <myl_rc_flat_edges_release+0x229>
 101bc74:	movabs $0x4000000000000002,%r13
 101bc7e:	lea    0x5c(%r15),%r11
 101bc82:	lea    0x5a(%r15),%r8
 101bc86:	xor    %ebx,%ebx
 101bc88:	mov    %rcx,-0x38(%rbp)
 101bc8c:	mov    %r10,-0x30(%rbp)
 101bc90:	jmp    101bcb3 <myl_rc_flat_edges_release+0xc3>
 101bc92:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101bca0:	mov    0x50(%r15),%rdi
 101bca4:	add    %rdi,%r14
 101bca7:	inc    %rbx
 101bcaa:	cmp    %rcx,%rbx
 101bcad:	je     101be19 <myl_rc_flat_edges_release+0x229>
 101bcb3:	cmpb   $0x0,0x46(%r15)
 101bcb8:	lea    0x58(%r15),%rax
 101bcbc:	je     101bcd2 <myl_rc_flat_edges_release+0xe2>
 101bcbe:	mov    0x48(%r15),%eax
 101bcc2:	mov    (%r14,%rax,1),%eax
 101bcc6:	cmp    $0x20,%rax
 101bcca:	lea    (%r11,%rax,2),%rax
 101bcce:	cmovae %r8,%rax
 101bcd2:	movzwl (%rax),%r12d
 101bcd6:	test   %r12d,%r12d
 101bcd9:	jne    101bd07 <myl_rc_flat_edges_release+0x117>
 101bcdb:	jmp    101bca4 <myl_rc_flat_edges_release+0xb4>
 101bcdd:	mov    0xc8(%rdi),%rax
 101bce4:	mov    %rax,(%r9)
 101bce7:	mov    0x1608(%r10),%rax
 101bcee:	mov    %r9,0xc8(%rax)
 101bcf5:	data16 cs nopw 0x0(%rax,%rax,1)
 101bd00:	blsr   %r12d,%r12d
 101bd05:	je     101bca0 <myl_rc_flat_edges_release+0xb0>
 101bd07:	tzcnt  %r12d,%eax
 101bd0c:	movzwl 0x9c(%r15,%rax,2),%eax
 101bd15:	mov    (%r14,%rax,1),%rsi
 101bd19:	movq   $0x0,(%r14,%rax,1)
 101bd21:	test   %rsi,%rsi
 101bd24:	je     101bd00 <myl_rc_flat_edges_release+0x110>
 101bd26:	mov    -0x10(%rsi),%rdx
 101bd2a:	test   %r13,%rdx
 101bd2d:	jne    101bd00 <myl_rc_flat_edges_release+0x110>
 101bd2f:	test   $0x1,%dl
 101bd32:	jne    101be28 <myl_rc_flat_edges_release+0x238>
 101bd38:	mov    -0x20(%rsi),%rax
 101bd3c:	test   %rax,%rax
 101bd3f:	je     101be28 <myl_rc_flat_edges_release+0x238>
 101bd45:	lea    -0x20(%rsi),%r9
 101bd49:	dec    %rax
 101bd4c:	mov    %rax,(%r9)
 101bd4f:	jne    101bd00 <myl_rc_flat_edges_release+0x110>
 101bd51:	cmpq   $0x0,-0x18(%rsi)
 101bd56:	jne    101bd00 <myl_rc_flat_edges_release+0x110>
 101bd58:	or     $0x1,%rdx
 101bd5c:	mov    %rdx,-0x10(%rsi)
 101bd60:	mov    0x1608(%r10),%rdi
 101bd67:	cmpl   $0x0,0xd0(%rdi)
 101bd6e:	jne    101bcdd <myl_rc_flat_edges_release+0xed>
 101bd74:	mov    -0x8(%rsi),%rax
 101bd78:	cmp    %rax,0x110(%rdi)
 101bd7f:	je     101bdcb <myl_rc_flat_edges_release+0x1db>
 101bd81:	mov    0x34(%rax),%edx
 101bd84:	cmp    %rdx,0xa0(%rdi)
 101bd8b:	jbe    101bdfa <myl_rc_flat_edges_release+0x20a>
 101bd8d:	mov    0x98(%rdi),%r8
 101bd94:	shl    $0x4,%rdx
 101bd98:	cmp    %rax,(%r8,%rdx,1)
 101bd9c:	jne    101bdfa <myl_rc_flat_edges_release+0x20a>
 101bd9e:	add    %rdx,%r8
 101bda1:	mov    0x8(%r8),%rax
 101bda5:	test   %rax,%rax
 101bda8:	lea    0x5a(%r15),%r8
 101bdac:	je     101bdb4 <myl_rc_flat_edges_release+0x1c4>
 101bdae:	cmpl   $0x0,0x40(%rax)
 101bdb2:	je     101bdc7 <myl_rc_flat_edges_release+0x1d7>
 101bdb4:	mov    0x1608(%r10),%rax
 101bdbb:	mov    0xc8(%rax),%rax
 101bdc2:	jmp    101bce4 <myl_rc_flat_edges_release+0xf4>
 101bdc7:	mov    -0x10(%rsi),%rdx
 101bdcb:	lea    0x1(%r13),%rax
 101bdcf:	and    %rax,%rdx
 101bdd2:	cmp    $0x1,%rdx
 101bdd6:	jne    101be28 <myl_rc_flat_edges_release+0x238>
 101bdd8:	mov    0x1608(%r10),%rax
 101bddf:	mov    %r10,%rdi
 101bde2:	call   *0x8(%rax)
 101bde5:	mov    -0x30(%rbp),%r10
 101bde9:	mov    -0x38(%rbp),%rcx
 101bded:	lea    0x5c(%r15),%r11
 101bdf1:	lea    0x5a(%r15),%r8
 101bdf5:	jmp    101bd00 <myl_rc_flat_edges_release+0x110>
 101bdfa:	mov    %rsi,%rdx
 101bdfd:	mov    %rax,%rsi
 101be00:	mov    %r11,%r8
 101be03:	call   1018f74 <myl_rc_binding_find_slow>
 101be08:	mov    %r8,%r11
 101be0b:	mov    %rdx,%rsi
 101be0e:	test   %rax,%rax
 101be11:	lea    0x5a(%r15),%r8
 101be15:	jne    101bdae <myl_rc_flat_edges_release+0x1be>
 101be17:	jmp    101bdb4 <myl_rc_flat_edges_release+0x1c4>
 101be19:	add    $0x18,%rsp
 101be1d:	pop    %rbx
 101be1e:	pop    %r12
 101be20:	pop    %r13
 101be22:	pop    %r14
 101be24:	pop    %r15
 101be26:	pop    %rbp
 101be27:	ret
 101be28:	call   1018954 <myl_rc_invariant_failed>
 101be2d:	int3
 101be2e:	int3
 101be2f:	int3

000000000101be30 <myl_rc_drain>:
 101be30:	push   %rbp
 101be31:	mov    %rsp,%rbp
 101be34:	push   %r15
 101be36:	push   %r14
 101be38:	push   %r13
 101be3a:	push   %r12
 101be3c:	push   %rbx
 101be3d:	sub    $0x48,%rsp
 101be41:	test   %rdi,%rdi
 101be44:	je     101bf62 <myl_rc_drain+0x132>
 101be4a:	mov    %rdi,%rbx
 101be4d:	mov    0x1608(%rdi),%r13
 101be54:	test   %r13,%r13
 101be57:	je     101bf62 <myl_rc_drain+0x132>
 101be5d:	mov    0xc8(%r13),%rax
 101be64:	test   %rax,%rax
 101be67:	je     101bf53 <myl_rc_drain+0x123>
 101be6d:	cmpl   $0x0,0xd0(%r13)
 101be75:	jne    101bf53 <myl_rc_drain+0x123>
 101be7b:	cmpq   $0x0,0xc0(%r13)
 101be83:	jne    101bf53 <myl_rc_drain+0x123>
 101be89:	movl   $0x1,0xd0(%r13)
 101be94:	xor    %r14d,%r14d
 101be97:	cmpq   $0x10228b0,0x8(%r13)
 101be9f:	sete   %r14b
 101bea3:	vxorps %xmm0,%xmm0,%xmm0
 101bea7:	vmovups %ymm0,-0x48(%rbp)
 101beac:	vmovups %ymm0,-0x60(%rbp)
 101beb1:	mov    %rax,-0x68(%rbp)
 101beb5:	movq   $0xffffffffffffffff,-0x48(%rbp)
 101bebd:	lea    -0x68(%rbp),%rsi
 101bec1:	mov    %rbx,%rdi
 101bec4:	mov    %r14d,%edx
 101bec7:	vzeroupper
 101beca:	call   101bf70 <drain_fast>
 101becf:	test   %rax,%rax
 101bed2:	je     101bf09 <myl_rc_drain+0xd9>
 101bed4:	lea    -0x38(%rbp),%r15
 101bed8:	lea    -0x68(%rbp),%r12
 101bedc:	nopl   0x0(%rax)
 101bee0:	mov    -0x68(%rbp),%rdx
 101bee4:	mov    %rbx,%rdi
 101bee7:	mov    %rax,%rsi
 101beea:	mov    %r15,%rcx
 101beed:	call   101c2c0 <drain_one>
 101bef2:	mov    %rax,-0x68(%rbp)
 101bef6:	mov    %rbx,%rdi
 101bef9:	mov    %r12,%rsi
 101befc:	mov    %r14d,%edx
 101beff:	call   101bf70 <drain_fast>
 101bf04:	test   %rax,%rax
 101bf07:	jne    101bee0 <myl_rc_drain+0xb0>
 101bf09:	movq   $0x0,0xc8(%r13)
 101bf14:	mov    -0x38(%rbp),%rax
 101bf18:	test   %rax,%rax
 101bf1b:	je     101bf48 <myl_rc_drain+0x118>
 101bf1d:	mov    0x40(%rbx),%rcx
 101bf21:	sub    %rax,%rcx
 101bf24:	jb     101bf62 <myl_rc_drain+0x132>
 101bf26:	mov    %rcx,0x40(%rbx)
 101bf2a:	add    0x50(%rbx),%rax
 101bf2e:	mov    $0xffffffffffffffff,%rcx
 101bf35:	cmovae %rax,%rcx
 101bf39:	mov    %rcx,0x50(%rbx)
 101bf3d:	mov    -0x30(%rbp),%rax
 101bf41:	add    %rax,0x1710(%rbx)
 101bf48:	movl   $0x0,0xd0(%r13)
 101bf53:	add    $0x48,%rsp
 101bf57:	pop    %rbx
 101bf58:	pop    %r12
 101bf5a:	pop    %r13
 101bf5c:	pop    %r14
 101bf5e:	pop    %r15
 101bf60:	pop    %rbp
 101bf61:	ret
 101bf62:	call   1018954 <myl_rc_invariant_failed>
 101bf67:	int3
 101bf68:	int3
 101bf69:	int3
 101bf6a:	int3
 101bf6b:	int3
 101bf6c:	int3
 101bf6d:	int3
 101bf6e:	int3
 101bf6f:	int3

000000000101bf70 <drain_fast>:
 101bf70:	push   %rbp
 101bf71:	mov    %rsp,%rbp
 101bf74:	push   %r15
 101bf76:	push   %r14
 101bf78:	push   %r13
 101bf7a:	push   %r12
 101bf7c:	push   %rbx
 101bf7d:	sub    $0x48,%rsp
 101bf81:	mov    %rsi,%rax
 101bf84:	mov    (%rsi),%rsi
 101bf87:	mov    0x8(%rax),%rcx
 101bf8b:	mov    %rcx,-0x40(%rbp)
 101bf8f:	mov    0x10(%rax),%r14
 101bf93:	mov    0x18(%rax),%r11
 101bf97:	mov    0x20(%rax),%r15
 101bf9b:	mov    0x28(%rax),%ebx
 101bf9e:	vmovdqu 0x30(%rax),%xmm1
 101bfa3:	test   %rsi,%rsi
 101bfa6:	je     101c280 <drain_fast+0x310>
 101bfac:	mov    %edx,%r10d
 101bfaf:	mov    %rdi,%r12
 101bfb2:	mov    %rax,-0x48(%rbp)
 101bfb6:	vmovdqa -0x1a6de(%rip),%xmm2        # 10018e0 <__abi_tag+0x15e4>
 101bfbe:	movabs $0x4000000000000003,%r13
 101bfc8:	mov    %rdi,-0x58(%rbp)
 101bfcc:	jmp    101c022 <drain_fast+0xb2>
 101bfce:	xchg   %ax,%ax
 101bfd0:	vmovdqa %xmm1,-0x70(%rbp)
 101bfd5:	movzwl 0x5e(%r14),%r8d
 101bfda:	mov    0x5c(%r14),%ecx
 101bfde:	mov    %r12,%rdi
 101bfe1:	lea    -0x70(%rbp),%r9
 101bfe5:	mov    %ebx,-0x4c(%rbp)
 101bfe8:	mov    %r10d,%ebx
 101bfeb:	mov    %r15,%r12
 101bfee:	mov    %r11,%r15
 101bff1:	call   101c670 <drain_pairs>
 101bff6:	mov    %r15,%r11
 101bff9:	mov    %r12,%r15
 101bffc:	mov    -0x58(%rbp),%r12
 101c000:	vmovdqa -0x1a728(%rip),%xmm2        # 10018e0 <__abi_tag+0x15e4>
 101c008:	mov    %ebx,%r10d
 101c00b:	mov    -0x4c(%rbp),%ebx
 101c00e:	mov    %rax,%rdx
 101c011:	vmovdqa -0x70(%rbp),%xmm1
 101c016:	mov    %rdx,%rsi
 101c019:	test   %rdx,%rdx
 101c01c:	je     101c276 <drain_fast+0x306>
 101c022:	mov    (%rsi),%rdx
 101c025:	mov    0x18(%rsi),%rcx
 101c029:	cmp    -0x40(%rbp),%rcx
 101c02d:	je     101c128 <drain_fast+0x1b8>
 101c033:	mov    0x1608(%r12),%rdi
 101c03b:	mov    0xd8(%rdi),%rax
 101c042:	cmp    %rcx,%rax
 101c045:	je     101c0a0 <drain_fast+0x130>
 101c047:	cmp    %rcx,0xe0(%rdi)
 101c04e:	je     101c0c1 <drain_fast+0x151>
 101c050:	mov    0x34(%rcx),%eax
 101c053:	cmp    %rax,0xa0(%rdi)
 101c05a:	jbe    101c245 <drain_fast+0x2d5>
 101c060:	mov    0x98(%rdi),%r8
 101c067:	shl    $0x4,%rax
 101c06b:	cmp    %rcx,(%r8,%rax,1)
 101c06f:	jne    101c245 <drain_fast+0x2d5>
 101c075:	add    %rax,%r8
 101c078:	mov    0x8(%r8),%r14
 101c07c:	test   %r14,%r14
 101c07f:	je     101c271 <drain_fast+0x301>
 101c085:	add    $0x40,%r14
 101c089:	mov    0xd8(%rdi),%rax
 101c090:	jmp    101c0c8 <drain_fast+0x158>
 101c092:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c0a0:	mov    0xe8(%rdi),%r14
 101c0a7:	mov    (%r14),%eax
 101c0aa:	test   %eax,%eax
 101c0ac:	jne    101c0f2 <drain_fast+0x182>
 101c0ae:	xor    %ebx,%ebx
 101c0b0:	movabs $0xc000000000000003,%r11
 101c0ba:	test   %r10d,%r10d
 101c0bd:	jne    101c106 <drain_fast+0x196>
 101c0bf:	jmp    101c11d <drain_fast+0x1ad>
 101c0c1:	mov    0xf0(%rdi),%r14
 101c0c8:	mov    %rax,0xe0(%rdi)
 101c0cf:	mov    0xe8(%rdi),%rax
 101c0d6:	mov    %rax,0xf0(%rdi)
 101c0dd:	mov    %rcx,0xd8(%rdi)
 101c0e4:	mov    %r14,0xe8(%rdi)
 101c0eb:	mov    (%r14),%eax
 101c0ee:	test   %eax,%eax
 101c0f0:	je     101c0ae <drain_fast+0x13e>
 101c0f2:	movzwl 0x18(%r14),%ebx
 101c0f7:	movabs $0xcfffffffffffffff,%r11
 101c101:	test   %r10d,%r10d
 101c104:	je     101c11d <drain_fast+0x1ad>
 101c106:	cmp    $0x10,%eax
 101c109:	ja     101c11d <drain_fast+0x1ad>
 101c10b:	xor    %edi,%edi
 101c10d:	test   %eax,%eax
 101c10f:	setne  %al
 101c112:	cmpb   $0x0,0x6(%r14)
 101c117:	je     101c235 <drain_fast+0x2c5>
 101c11d:	mov    $0xffffffffffffffff,%r15
 101c124:	mov    %rcx,-0x40(%rbp)
 101c128:	mov    0x10(%rsi),%rax
 101c12c:	and    %r11,%rax
 101c12f:	cmp    %r15,%rax
 101c132:	jne    101c27a <drain_fast+0x30a>
 101c138:	cmp    $0x3,%ebx
 101c13b:	je     101bfd0 <drain_fast+0x60>
 101c141:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c150:	test   %ebx,%ebx
 101c152:	je     101c1d0 <drain_fast+0x260>
 101c154:	mov    %ebx,%eax
 101c156:	jmp    101c171 <drain_fast+0x201>
 101c158:	nopl   0x0(%rax,%rax,1)
 101c160:	test   $0x1,%r9b
 101c164:	jne    101c271 <drain_fast+0x301>
 101c16a:	blsr   %eax,%eax
 101c16f:	je     101c1d0 <drain_fast+0x260>
 101c171:	tzcnt  %eax,%ecx
 101c175:	movzwl 0x5c(%r14,%rcx,2),%ecx
 101c17b:	mov    0x20(%rsi,%rcx,1),%r8
 101c180:	test   %r8,%r8
 101c183:	je     101c16a <drain_fast+0x1fa>
 101c185:	mov    -0x10(%r8),%r9
 101c189:	test   %r13,%r9
 101c18c:	jne    101c160 <drain_fast+0x1f0>
 101c18e:	lea    -0x20(%r8),%rcx
 101c192:	mov    (%rcx),%rdi
 101c195:	cmp    $0x1,%rdi
 101c199:	je     101c1a5 <drain_fast+0x235>
 101c19b:	test   %rdi,%rdi
 101c19e:	jne    101c1ac <drain_fast+0x23c>
 101c1a0:	jmp    101c271 <drain_fast+0x301>
 101c1a5:	cmpq   $0x0,-0x18(%r8)
 101c1aa:	je     101c1b4 <drain_fast+0x244>
 101c1ac:	dec    %rdi
 101c1af:	mov    %rdi,(%rcx)
 101c1b2:	jmp    101c16a <drain_fast+0x1fa>
 101c1b4:	or     $0x1,%r9
 101c1b8:	mov    %r9,-0x10(%r8)
 101c1bc:	mov    %rdx,%rdi
 101c1bf:	mov    %rcx,%rdx
 101c1c2:	jmp    101c1af <drain_fast+0x23f>
 101c1c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c1d0:	mov    %rsi,%rax
 101c1d3:	and    $0xffffffffffff0000,%rax
 101c1d9:	mov    (%rax),%rcx
 101c1dc:	movq   $0x3,0x10(%rsi)
 101c1e4:	mov    0x1610(%r12,%rcx,8),%rdi
 101c1ec:	mov    %rdi,(%rsi)
 101c1ef:	mov    %rsi,0x1610(%r12,%rcx,8)
 101c1f7:	vpinsrq $0x1,0x8(%rax),%xmm2,%xmm0
 101c1fe:	vpaddq %xmm1,%xmm0,%xmm1
 101c202:	test   %rdx,%rdx
 101c205:	je     101c276 <drain_fast+0x306>
 101c207:	mov    -0x40(%rbp),%rax
 101c20b:	cmp    %rax,0x18(%rdx)
 101c20f:	jne    101c016 <drain_fast+0xa6>
 101c215:	mov    0x10(%rdx),%rax
 101c219:	and    %r11,%rax
 101c21c:	cmp    %r15,%rax
 101c21f:	jne    101c016 <drain_fast+0xa6>
 101c225:	mov    %rdx,%rsi
 101c228:	mov    (%rdx),%rdx
 101c22b:	test   %ebx,%ebx
 101c22d:	jne    101c154 <drain_fast+0x1e4>
 101c233:	jmp    101c1d0 <drain_fast+0x260>
 101c235:	mov    %al,%dil
 101c238:	lea    0x1(,%rdi,4),%r15
 101c240:	jmp    101c124 <drain_fast+0x1b4>
 101c245:	mov    %rsi,%r8
 101c248:	mov    %rcx,%rsi
 101c24b:	vmovdqa %xmm1,-0x40(%rbp)
 101c250:	call   1018f74 <myl_rc_binding_find_slow>
 101c255:	vmovdqa -0x1a97d(%rip),%xmm2        # 10018e0 <__abi_tag+0x15e4>
 101c25d:	vmovdqa -0x40(%rbp),%xmm1
 101c262:	mov    %r8,%rsi
 101c265:	mov    %rax,%r14
 101c268:	test   %r14,%r14
 101c26b:	jne    101c085 <drain_fast+0x115>
 101c271:	call   1018954 <myl_rc_invariant_failed>
 101c276:	xor    %esi,%esi
 101c278:	xor    %edx,%edx
 101c27a:	mov    -0x48(%rbp),%rax
 101c27e:	jmp    101c284 <drain_fast+0x314>
 101c280:	xor    %esi,%esi
 101c282:	xor    %edx,%edx
 101c284:	mov    %rdx,(%rax)
 101c287:	mov    -0x40(%rbp),%rcx
 101c28b:	mov    %rcx,0x8(%rax)
 101c28f:	mov    %r14,0x10(%rax)
 101c293:	mov    %r11,0x18(%rax)
 101c297:	mov    %r15,0x20(%rax)
 101c29b:	mov    %ebx,0x28(%rax)
 101c29e:	movl   $0x0,0x2c(%rax)
 101c2a5:	vmovdqu %xmm1,0x30(%rax)
 101c2aa:	mov    %rsi,%rax
 101c2ad:	add    $0x48,%rsp
 101c2b1:	pop    %rbx
 101c2b2:	pop    %r12
 101c2b4:	pop    %r13
 101c2b6:	pop    %r14
 101c2b8:	pop    %r15
 101c2ba:	pop    %rbp
 101c2bb:	ret
 101c2bc:	int3
 101c2bd:	int3
 101c2be:	int3
 101c2bf:	int3

000000000101c2c0 <drain_one>:
 101c2c0:	push   %rbp
 101c2c1:	mov    %rsp,%rbp
 101c2c4:	push   %r15
 101c2c6:	push   %r14
 101c2c8:	push   %r13
 101c2ca:	push   %r12
 101c2cc:	push   %rbx
 101c2cd:	push   %rax
 101c2ce:	mov    %rsi,%r14
 101c2d1:	mov    %rdi,%rbx
 101c2d4:	mov    0x1608(%rdi),%r8
 101c2db:	mov    %rdx,0xc8(%r8)
 101c2e2:	mov    (%rcx),%rax
 101c2e5:	mov    %r8,%rdi
 101c2e8:	test   %rax,%rax
 101c2eb:	je     101c32b <drain_one+0x6b>
 101c2ed:	mov    0x40(%rbx),%rdx
 101c2f1:	sub    %rax,%rdx
 101c2f4:	jb     101c663 <drain_one+0x3a3>
 101c2fa:	mov    %rdx,0x40(%rbx)
 101c2fe:	add    0x50(%rbx),%rax
 101c302:	mov    $0xffffffffffffffff,%rdx
 101c309:	cmovae %rax,%rdx
 101c30d:	mov    %rdx,0x50(%rbx)
 101c311:	mov    0x8(%rcx),%rax
 101c315:	add    %rax,0x1710(%rbx)
 101c31c:	vxorps %xmm0,%xmm0,%xmm0
 101c320:	vmovups %xmm0,(%rcx)
 101c324:	mov    0x1608(%rbx),%rdi
 101c32b:	mov    0x18(%r14),%rsi
 101c32f:	mov    0xd8(%rdi),%rcx
 101c336:	cmp    %rsi,%rcx
 101c339:	je     101c386 <drain_one+0xc6>
 101c33b:	cmp    %rsi,0xe0(%rdi)
 101c342:	je     101c38f <drain_one+0xcf>
 101c344:	mov    0x34(%rsi),%eax
 101c347:	cmp    %rax,0xa0(%rdi)
 101c34e:	jbe    101c642 <drain_one+0x382>
 101c354:	mov    0x98(%rdi),%rcx
 101c35b:	shl    $0x4,%rax
 101c35f:	cmp    %rsi,(%rcx,%rax,1)
 101c363:	jne    101c642 <drain_one+0x382>
 101c369:	add    %rax,%rcx
 101c36c:	mov    0x8(%rcx),%rax
 101c370:	test   %rax,%rax
 101c373:	je     101c663 <drain_one+0x3a3>
 101c379:	add    $0x40,%rax
 101c37d:	mov    0xd8(%rdi),%rcx
 101c384:	jmp    101c396 <drain_one+0xd6>
 101c386:	mov    0xe8(%rdi),%rax
 101c38d:	jmp    101c3b9 <drain_one+0xf9>
 101c38f:	mov    0xf0(%rdi),%rax
 101c396:	mov    %rcx,0xe0(%rdi)
 101c39d:	mov    0xe8(%rdi),%rcx
 101c3a4:	mov    %rcx,0xf0(%rdi)
 101c3ab:	mov    %rsi,0xd8(%rdi)
 101c3b2:	mov    %rax,0xe8(%rdi)
 101c3b9:	mov    %r8,-0x30(%rbp)
 101c3bd:	movabs $0x4000000000000003,%r13
 101c3c7:	mov    0x10(%r14),%rcx
 101c3cb:	mov    %rcx,%rdx
 101c3ce:	and    %r13,%rdx
 101c3d1:	cmp    $0x1,%rdx
 101c3d5:	jne    101c663 <drain_one+0x3a3>
 101c3db:	lea    0x20(%r14),%r15
 101c3df:	lea    -0x40(%rax),%rsi
 101c3e3:	mov    $0x3c,%edx
 101c3e8:	bzhi   %rdx,%rcx,%r12
 101c3ed:	shr    $0x2,%r12
 101c3f1:	cmpl   $0x10,(%rax)
 101c3f4:	ja     101c427 <drain_one+0x167>
 101c3f6:	cmp    $0x1,%r12
 101c3fa:	jne    101c4b2 <drain_one+0x1f2>
 101c400:	cmpb   $0x0,0x6(%rax)
 101c404:	je     101c4fa <drain_one+0x23a>
 101c40a:	mov    0x8(%rax),%ecx
 101c40d:	mov    (%r15,%rcx,1),%ecx
 101c411:	lea    0x1a(%rax),%rdx
 101c415:	cmp    $0x20,%rcx
 101c419:	lea    0x1c(%rax,%rcx,2),%rcx
 101c41e:	cmovae %rdx,%rcx
 101c422:	jmp    101c4fe <drain_one+0x23e>
 101c427:	mov    -0x28(%rax),%rax
 101c42b:	test   %rax,%rax
 101c42e:	je     101c478 <drain_one+0x1b8>
 101c430:	mov    %rbx,%rdi
 101c433:	mov    %r15,%rsi
 101c436:	call   *%rax
 101c438:	mov    0x18(%r14),%rsi
 101c43c:	mov    0x1608(%rbx),%rdi
 101c443:	mov    0x34(%rsi),%eax
 101c446:	cmp    %rax,0xa0(%rdi)
 101c44d:	jbe    101c652 <drain_one+0x392>
 101c453:	mov    0x98(%rdi),%rcx
 101c45a:	shl    $0x4,%rax
 101c45e:	cmp    %rsi,(%rcx,%rax,1)
 101c462:	jne    101c652 <drain_one+0x392>
 101c468:	add    %rax,%rcx
 101c46b:	mov    0x8(%rcx),%rsi
 101c46f:	test   %rsi,%rsi
 101c472:	je     101c663 <drain_one+0x3a3>
 101c478:	mov    -0x30(%rbp),%rax
 101c47c:	cmpq   $0x0,0xc0(%rax)
 101c484:	jne    101c663 <drain_one+0x3a3>
 101c48a:	mov    0x10(%rsi),%rax
 101c48e:	test   %rax,%rax
 101c491:	je     101c4d4 <drain_one+0x214>
 101c493:	mov    %rbx,%rdi
 101c496:	mov    %r15,%rsi
 101c499:	mov    %r12,%rdx
 101c49c:	call   *%rax
 101c49e:	mov    -0x30(%rbp),%r12
 101c4a2:	cmpq   $0x0,0xc0(%r12)
 101c4ab:	je     101c52c <drain_one+0x26c>
 101c4ad:	jmp    101c663 <drain_one+0x3a3>
 101c4b2:	mov    %rbx,%rdi
 101c4b5:	mov    %r15,%rdx
 101c4b8:	mov    %r12,%rcx
 101c4bb:	call   101bbf0 <myl_rc_flat_edges_release>
 101c4c0:	mov    -0x30(%rbp),%r12
 101c4c4:	cmpq   $0x0,0xc0(%r12)
 101c4cd:	je     101c52c <drain_one+0x26c>
 101c4cf:	jmp    101c663 <drain_one+0x3a3>
 101c4d4:	mov    0x8(%rsi),%rsi
 101c4d8:	mov    %rbx,%rdi
 101c4db:	mov    %r15,%rdx
 101c4de:	mov    %r12,%rcx
 101c4e1:	call   101b480 <myl_rc_edges_release>
 101c4e6:	mov    -0x30(%rbp),%r12
 101c4ea:	cmpq   $0x0,0xc0(%r12)
 101c4f3:	je     101c52c <drain_one+0x26c>
 101c4f5:	jmp    101c663 <drain_one+0x3a3>
 101c4fa:	lea    0x18(%rax),%rcx
 101c4fe:	mov    -0x30(%rbp),%r12
 101c502:	movzwl (%rcx),%edx
 101c505:	mov    0xc8(%r12),%rcx
 101c50d:	test   %edx,%edx
 101c50f:	jne    101c5d5 <drain_one+0x315>
 101c515:	mov    %rcx,0xc8(%r12)
 101c51d:	cmpq   $0x0,0xc0(%r12)
 101c526:	jne    101c663 <drain_one+0x3a3>
 101c52c:	mov    0x10(%r14),%rax
 101c530:	and    %rax,%r13
 101c533:	cmp    $0x1,%r13
 101c537:	jne    101c663 <drain_one+0x3a3>
 101c53d:	test   %rax,%rax
 101c540:	setns  %cl
 101c543:	mov    0x1608(%rbx),%rax
 101c54a:	mov    0x8(%rax),%rax
 101c54e:	cmp    $0x10228b0,%rax
 101c555:	sete   %dl
 101c558:	and    %cl,%dl
 101c55a:	cmp    $0x1,%dl
 101c55d:	jne    101c623 <drain_one+0x363>
 101c563:	mov    0x40(%rbx),%rax
 101c567:	test   %rax,%rax
 101c56a:	je     101c663 <drain_one+0x3a3>
 101c570:	mov    0x50(%rbx),%rcx
 101c574:	cmp    $0xffffffffffffffff,%rcx
 101c578:	je     101c581 <drain_one+0x2c1>
 101c57a:	inc    %rcx
 101c57d:	mov    %rcx,0x50(%rbx)
 101c581:	mov    %r14,%rcx
 101c584:	and    $0xffffffffffff0000,%rcx
 101c58b:	dec    %rax
 101c58e:	mov    %rax,0x40(%rbx)
 101c592:	movq   $0x3,0x10(%r14)
 101c59a:	mov    (%rcx),%rax
 101c59d:	mov    0x1610(%rbx,%rax,8),%rax
 101c5a5:	mov    %rax,(%r14)
 101c5a8:	mov    (%rcx),%rax
 101c5ab:	mov    %r14,0x1610(%rbx,%rax,8)
 101c5b3:	mov    0x8(%rcx),%rax
 101c5b7:	add    %rax,0x1710(%rbx)
 101c5be:	jmp    101c62b <drain_one+0x36b>
 101c5c0:	test   $0x1,%r9b
 101c5c4:	jne    101c663 <drain_one+0x3a3>
 101c5ca:	blsr   %edx,%edx
 101c5cf:	je     101c515 <drain_one+0x255>
 101c5d5:	tzcnt  %edx,%esi
 101c5d9:	movzwl 0x5c(%rax,%rsi,2),%esi
 101c5de:	mov    (%r15,%rsi,1),%r8
 101c5e2:	test   %r8,%r8
 101c5e5:	je     101c5ca <drain_one+0x30a>
 101c5e7:	mov    -0x10(%r8),%r9
 101c5eb:	test   %r13,%r9
 101c5ee:	jne    101c5c0 <drain_one+0x300>
 101c5f0:	lea    -0x20(%r8),%rsi
 101c5f4:	mov    (%rsi),%rdi
 101c5f7:	cmp    $0x1,%rdi
 101c5fb:	je     101c604 <drain_one+0x344>
 101c5fd:	test   %rdi,%rdi
 101c600:	jne    101c60b <drain_one+0x34b>
 101c602:	jmp    101c663 <drain_one+0x3a3>
 101c604:	cmpq   $0x0,-0x18(%r8)
 101c609:	je     101c613 <drain_one+0x353>
 101c60b:	dec    %rdi
 101c60e:	mov    %rdi,(%rsi)
 101c611:	jmp    101c5ca <drain_one+0x30a>
 101c613:	or     $0x1,%r9
 101c617:	mov    %r9,-0x10(%r8)
 101c61b:	mov    %rcx,%rdi
 101c61e:	mov    %rsi,%rcx
 101c621:	jmp    101c60e <drain_one+0x34e>
 101c623:	mov    %rbx,%rdi
 101c626:	mov    %r15,%rsi
 101c629:	call   *%rax
 101c62b:	mov    0xc8(%r12),%rax
 101c633:	add    $0x8,%rsp
 101c637:	pop    %rbx
 101c638:	pop    %r12
 101c63a:	pop    %r13
 101c63c:	pop    %r14
 101c63e:	pop    %r15
 101c640:	pop    %rbp
 101c641:	ret
 101c642:	call   1018f74 <myl_rc_binding_find_slow>
 101c647:	test   %rax,%rax
 101c64a:	jne    101c379 <drain_one+0xb9>
 101c650:	jmp    101c663 <drain_one+0x3a3>
 101c652:	call   1018f74 <myl_rc_binding_find_slow>
 101c657:	mov    %rax,%rsi
 101c65a:	test   %rsi,%rsi
 101c65d:	jne    101c478 <drain_one+0x1b8>
 101c663:	call   1018954 <myl_rc_invariant_failed>
 101c668:	int3
 101c669:	int3
 101c66a:	int3
 101c66b:	int3
 101c66c:	int3
 101c66d:	int3
 101c66e:	int3
 101c66f:	int3

000000000101c670 <drain_pairs>:
 101c670:	push   %rbp
 101c671:	mov    %rsp,%rbp
 101c674:	push   %r15
 101c676:	push   %r14
 101c678:	push   %r13
 101c67a:	push   %r12
 101c67c:	push   %rbx
 101c67d:	sub    $0x18,%rsp
 101c681:	mov    %r9,-0x40(%rbp)
 101c685:	mov    %rdx,%r11
 101c688:	movabs $0x4000000000000003,%rbx
 101c692:	mov    0x18(%rsi),%r14
 101c696:	mov    %rsi,%r10
 101c699:	and    $0xffffffffffff0000,%r10
 101c6a0:	mov    (%r10),%rax
 101c6a3:	movzwl %cx,%r15d
 101c6a7:	movzwl %r8w,%r8d
 101c6ab:	mov    %rdi,-0x38(%rbp)
 101c6af:	mov    %rax,-0x30(%rbp)
 101c6b3:	mov    0x1610(%rdi,%rax,8),%r13
 101c6bb:	mov    $0x1,%ecx
 101c6c0:	movabs $0xcfffffffffffffff,%r12
 101c6ca:	mov    0x20(%rsi,%r15,1),%r9
 101c6cf:	test   %r9,%r9
 101c6d2:	je     101c6f3 <drain_pairs+0x83>
 101c6d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c6e0:	mov    -0x10(%r9),%rdi
 101c6e4:	test   %rbx,%rdi
 101c6e7:	je     101c730 <drain_pairs+0xc0>
 101c6e9:	test   $0x1,%dil
 101c6ed:	jne    101c832 <drain_pairs+0x1c2>
 101c6f3:	mov    0x20(%rsi,%r8,1),%rdi
 101c6f8:	test   %rdi,%rdi
 101c6fb:	je     101c78d <drain_pairs+0x11d>
 101c701:	mov    -0x10(%rdi),%r9
 101c705:	test   %rbx,%r9
 101c708:	je     101c750 <drain_pairs+0xe0>
 101c70a:	mov    %r11,%rax
 101c70d:	test   $0x1,%r9b
 101c711:	jne    101c832 <drain_pairs+0x1c2>
 101c717:	movq   $0x3,0x10(%rsi)
 101c71f:	mov    %r13,(%rsi)
 101c722:	test   %rax,%rax
 101c725:	jne    101c7a0 <drain_pairs+0x130>
 101c727:	jmp    101c7f2 <drain_pairs+0x182>
 101c72c:	nopl   0x0(%rax)
 101c730:	lea    -0x20(%r9),%rax
 101c734:	mov    (%rax),%rdx
 101c737:	cmp    $0x1,%rdx
 101c73b:	je     101c767 <drain_pairs+0xf7>
 101c73d:	test   %rdx,%rdx
 101c740:	jne    101c76e <drain_pairs+0xfe>
 101c742:	jmp    101c832 <drain_pairs+0x1c2>
 101c747:	nopw   0x0(%rax,%rax,1)
 101c750:	lea    -0x20(%rdi),%rax
 101c754:	mov    (%rax),%rdx
 101c757:	cmp    $0x1,%rdx
 101c75b:	je     101c780 <drain_pairs+0x110>
 101c75d:	test   %rdx,%rdx
 101c760:	jne    101c787 <drain_pairs+0x117>
 101c762:	jmp    101c832 <drain_pairs+0x1c2>
 101c767:	cmpq   $0x0,-0x18(%r9)
 101c76c:	je     101c7d2 <drain_pairs+0x162>
 101c76e:	dec    %rdx
 101c771:	mov    %rdx,(%rax)
 101c774:	mov    0x20(%rsi,%r8,1),%rdi
 101c779:	test   %rdi,%rdi
 101c77c:	jne    101c701 <drain_pairs+0x91>
 101c77e:	jmp    101c78d <drain_pairs+0x11d>
 101c780:	cmpq   $0x0,-0x18(%rdi)
 101c785:	je     101c7e2 <drain_pairs+0x172>
 101c787:	dec    %rdx
 101c78a:	mov    %rdx,(%rax)
 101c78d:	mov    %r11,%rax
 101c790:	movq   $0x3,0x10(%rsi)
 101c798:	mov    %r13,(%rsi)
 101c79b:	test   %rax,%rax
 101c79e:	je     101c7f2 <drain_pairs+0x182>
 101c7a0:	cmp    %r14,0x18(%rax)
 101c7a4:	jne    101c7f4 <drain_pairs+0x184>
 101c7a6:	mov    0x10(%rax),%rdx
 101c7aa:	and    %r12,%rdx
 101c7ad:	cmp    $0x5,%rdx
 101c7b1:	jne    101c7f4 <drain_pairs+0x184>
 101c7b3:	mov    (%rax),%r11
 101c7b6:	inc    %rcx
 101c7b9:	mov    %rsi,%r13
 101c7bc:	mov    %rax,%rsi
 101c7bf:	mov    0x20(%rsi,%r15,1),%r9
 101c7c4:	test   %r9,%r9
 101c7c7:	jne    101c6e0 <drain_pairs+0x70>
 101c7cd:	jmp    101c6f3 <drain_pairs+0x83>
 101c7d2:	or     $0x1,%rdi
 101c7d6:	mov    %rdi,-0x10(%r9)
 101c7da:	mov    %r11,%rdx
 101c7dd:	mov    %rax,%r11
 101c7e0:	jmp    101c771 <drain_pairs+0x101>
 101c7e2:	or     $0x1,%r9
 101c7e6:	mov    %r9,-0x10(%rdi)
 101c7ea:	mov    %r11,%rdx
 101c7ed:	mov    %rax,%r11
 101c7f0:	jmp    101c78a <drain_pairs+0x11a>
 101c7f2:	xor    %eax,%eax
 101c7f4:	mov    -0x38(%rbp),%rdx
 101c7f8:	mov    -0x30(%rbp),%rdi
 101c7fc:	mov    %rsi,0x1610(%rdx,%rdi,8)
 101c804:	vmovq  %rcx,%xmm0
 101c809:	imul   0x8(%r10),%rcx
 101c80e:	vmovq  %rcx,%xmm1
 101c813:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 101c817:	mov    -0x40(%rbp),%rcx
 101c81b:	vpaddq (%rcx),%xmm0,%xmm0
 101c81f:	vmovdqu %xmm0,(%rcx)
 101c823:	add    $0x18,%rsp
 101c827:	pop    %rbx
 101c828:	pop    %r12
 101c82a:	pop    %r13
 101c82c:	pop    %r14
 101c82e:	pop    %r15
 101c830:	pop    %rbp
 101c831:	ret
 101c832:	call   1018954 <myl_rc_invariant_failed>
 101c837:	int3
 101c838:	int3
 101c839:	int3
 101c83a:	int3
 101c83b:	int3
 101c83c:	int3
 101c83d:	int3
 101c83e:	int3
 101c83f:	int3

000000000101c840 <myl_rc_native_has_unique>:
 101c840:	push   %rbp
 101c841:	mov    %rsp,%rbp
 101c844:	test   %rdi,%rdi
 101c847:	je     101ca18 <myl_rc_native_has_unique+0x1d8>
 101c84d:	mov    0x1608(%rdi),%rcx
 101c854:	test   %rcx,%rcx
 101c857:	je     101ca18 <myl_rc_native_has_unique+0x1d8>
 101c85d:	cmpq   $0x0,0xc0(%rcx)
 101c865:	jne    101ca18 <myl_rc_native_has_unique+0x1d8>
 101c86b:	vxorps %xmm0,%xmm0,%xmm0
 101c86f:	mov    $0x160,%edx
 101c874:	movzwl 0x30(%rsi),%eax
 101c878:	cmp    $0x1,%ax
 101c87c:	jne    101c8db <myl_rc_native_has_unique+0x9b>
 101c87e:	cmpw   $0x5,0x32(%rsi)
 101c883:	jne    101c926 <myl_rc_native_has_unique+0xe6>
 101c889:	mov    0x38(%rsi),%rax
 101c88d:	test   %rax,%rax
 101c890:	je     101c926 <myl_rc_native_has_unique+0xe6>
 101c896:	mov    0x34(%rax),%r8d
 101c89a:	cmp    %r8,0xa0(%rcx)
 101c8a1:	jbe    101c9f4 <myl_rc_native_has_unique+0x1b4>
 101c8a7:	mov    0x98(%rcx),%r9
 101c8ae:	shl    $0x4,%r8
 101c8b2:	cmp    %rax,(%r9,%r8,1)
 101c8b6:	jne    101c9f4 <myl_rc_native_has_unique+0x1b4>
 101c8bc:	add    %r8,%r9
 101c8bf:	mov    0x8(%r9),%rax
 101c8c3:	test   %rax,%rax
 101c8c6:	je     101ca18 <myl_rc_native_has_unique+0x1d8>
 101c8cc:	cmpq   $0x0,0x18(%rax)
 101c8d1:	jne    101ca1f <myl_rc_native_has_unique+0x1df>
 101c8d7:	movzwl 0x30(%rsi),%eax
 101c8db:	movzwl %ax,%eax
 101c8de:	lea    -0x2(%rax),%ecx
 101c8e1:	cmp    $0x3,%ecx
 101c8e4:	jae    101c9e0 <myl_rc_native_has_unique+0x1a0>
 101c8ea:	mov    0x1608(%rdi),%rax
 101c8f1:	mov    0xc0(%rax),%rcx
 101c8f8:	cmp    0xb8(%rax),%rcx
 101c8ff:	jae    101ca18 <myl_rc_native_has_unique+0x1d8>
 101c905:	mov    0xb0(%rax),%r8
 101c90c:	lea    0x1(%rcx),%r9
 101c910:	mov    %r9,0xc0(%rax)
 101c917:	lea    (%rcx,%rcx,2),%rax
 101c91b:	mov    %rsi,(%r8,%rax,8)
 101c91f:	vmovups %xmm0,0x8(%r8,%rax,8)
 101c926:	mov    0x1608(%rdi),%rcx
 101c92d:	mov    0xc0(%rcx),%rsi
 101c934:	xor    %eax,%eax
 101c936:	test   %rsi,%rsi
 101c939:	je     101ca1d <myl_rc_native_has_unique+0x1dd>
 101c93f:	lea    (%rsi,%rsi,2),%r8
 101c943:	dec    %rsi
 101c946:	shl    $0x3,%r8
 101c94a:	add    0xb0(%rcx),%r8
 101c951:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c960:	mov    -0x18(%r8),%r9
 101c964:	cmpw   $0x3,0x30(%r9)
 101c96a:	jne    101c990 <myl_rc_native_has_unique+0x150>
 101c96c:	xor    %r10d,%r10d
 101c96f:	cmpq   $0x0,0x20(%r9)
 101c974:	setne  %r10b
 101c978:	mov    -0x8(%r8),%r11
 101c97c:	cmp    %r10,%r11
 101c97f:	jae    101c99d <myl_rc_native_has_unique+0x15d>
 101c981:	jmp    101c9b0 <myl_rc_native_has_unique+0x170>
 101c983:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c990:	mov    0x18(%r9),%r10
 101c994:	mov    -0x8(%r8),%r11
 101c998:	cmp    %r10,%r11
 101c99b:	jb     101c9b0 <myl_rc_native_has_unique+0x170>
 101c99d:	mov    %rsi,0xc0(%rcx)
 101c9a4:	add    $0xffffffffffffffe8,%r8
 101c9a8:	add    $0xffffffffffffffff,%rsi
 101c9ac:	jb     101c960 <myl_rc_native_has_unique+0x120>
 101c9ae:	jmp    101ca1d <myl_rc_native_has_unique+0x1dd>
 101c9b0:	mov    0x10(%r9),%rax
 101c9b4:	lea    0x1(%r11),%rsi
 101c9b8:	mov    %rsi,-0x8(%r8)
 101c9bc:	lea    (%r11,%r11,2),%rsi
 101c9c0:	mov    0x8(%rax,%rsi,8),%rsi
 101c9c5:	movzwl 0x30(%rsi),%eax
 101c9c9:	cmp    $0x1,%ax
 101c9cd:	je     101c87e <myl_rc_native_has_unique+0x3e>
 101c9d3:	jmp    101c8db <myl_rc_native_has_unique+0x9b>
 101c9d8:	nopl   0x0(%rax,%rax,1)
 101c9e0:	cmp    $0x8,%eax
 101c9e3:	ja     101c926 <myl_rc_native_has_unique+0xe6>
 101c9e9:	bt     %eax,%edx
 101c9ec:	jae    101c926 <myl_rc_native_has_unique+0xe6>
 101c9f2:	jmp    101ca1f <myl_rc_native_has_unique+0x1df>
 101c9f4:	mov    %rdi,%r8
 101c9f7:	mov    %rcx,%rdi
 101c9fa:	mov    %rsi,%rcx
 101c9fd:	mov    %rax,%rsi
 101ca00:	call   1018f74 <myl_rc_binding_find_slow>
 101ca05:	vxorps %xmm0,%xmm0,%xmm0
 101ca09:	mov    %rcx,%rsi
 101ca0c:	mov    %r8,%rdi
 101ca0f:	test   %rax,%rax
 101ca12:	jne    101c8cc <myl_rc_native_has_unique+0x8c>
 101ca18:	call   1018954 <myl_rc_invariant_failed>
 101ca1d:	pop    %rbp
 101ca1e:	ret
 101ca1f:	mov    0x1608(%rdi),%rax
 101ca26:	movq   $0x0,0xc0(%rax)
 101ca31:	mov    $0x1,%eax
 101ca36:	pop    %rbp
 101ca37:	ret
 101ca38:	int3
 101ca39:	int3
 101ca3a:	int3
 101ca3b:	int3
 101ca3c:	int3
 101ca3d:	int3
 101ca3e:	int3
 101ca3f:	int3

000000000101ca40 <myl_rc_value_seed>:
 101ca40:	push   %rbp
 101ca41:	mov    %rsp,%rbp
 101ca44:	push   %r15
 101ca46:	push   %r14
 101ca48:	push   %r13
 101ca4a:	push   %r12
 101ca4c:	push   %rbx
 101ca4d:	push   %rax
 101ca4e:	test   %rdi,%rdi
 101ca51:	je     101ccc0 <myl_rc_value_seed+0x280>
 101ca57:	mov    %rdx,%r14
 101ca5a:	mov    %rdi,%r15
 101ca5d:	mov    0x1608(%rdi),%rdx
 101ca64:	test   %rdx,%rdx
 101ca67:	je     101ccc0 <myl_rc_value_seed+0x280>
 101ca6d:	cmp    %rcx,%r14
 101ca70:	je     101ccc0 <myl_rc_value_seed+0x280>
 101ca76:	cmpq   $0x0,0xc0(%rdx)
 101ca7e:	jne    101ccc0 <myl_rc_value_seed+0x280>
 101ca84:	mov    0x58(%rdx),%rax
 101ca88:	mov    0x60(%rdx),%rdi
 101ca8c:	movzbl 0x70(%rdx),%edx
 101ca90:	movabs $0x9e3779b97f4a7c15,%r9
 101ca9a:	imul   %rsi,%r9
 101ca9e:	shrx   %rdx,%r9,%rdx
 101caa3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101cab0:	and    %rdi,%rdx
 101cab3:	mov    %rdx,%r9
 101cab6:	shl    $0x4,%r9
 101caba:	mov    (%rax,%r9,1),%r9
 101cabe:	cmp    %rsi,%r9
 101cac1:	je     101cad1 <myl_rc_value_seed+0x91>
 101cac3:	test   %r9,%r9
 101cac6:	je     101ccc0 <myl_rc_value_seed+0x280>
 101cacc:	inc    %rdx
 101cacf:	jmp    101cab0 <myl_rc_value_seed+0x70>
 101cad1:	shl    $0x4,%rdx
 101cad5:	mov    0x8(%rax,%rdx,1),%r12
 101cada:	test   %r12,%r12
 101cadd:	je     101ccc0 <myl_rc_value_seed+0x280>
 101cae3:	mov    %r8,%rax
 101cae6:	mulq   (%r12)
 101caea:	jo     101ccc0 <myl_rc_value_seed+0x280>
 101caf0:	mov    0x8(%r12),%edx
 101caf5:	or     $0x4,%edx
 101caf8:	cmp    $0x5,%edx
 101cafb:	jne    101cb18 <myl_rc_value_seed+0xd8>
 101cafd:	mov    %r14,%rdi
 101cb00:	xor    %esi,%esi
 101cb02:	mov    %rax,%rdx
 101cb05:	add    $0x8,%rsp
 101cb09:	pop    %rbx
 101cb0a:	pop    %r12
 101cb0c:	pop    %r13
 101cb0e:	pop    %r14
 101cb10:	pop    %r15
 101cb12:	pop    %rbp
 101cb13:	jmp    1027650 <memset@plt>
 101cb18:	mov    %r14,%rdi
 101cb1b:	mov    %rcx,%rsi
 101cb1e:	mov    %rax,%rdx
 101cb21:	mov    %r8,-0x30(%rbp)
 101cb25:	call   10276a0 <memcpy@plt>
 101cb2a:	mov    -0x30(%rbp),%r11
 101cb2e:	cmpl   $0x0,0x8(%r12)
 101cb34:	je     101ccb1 <myl_rc_value_seed+0x271>
 101cb3a:	test   %r11,%r11
 101cb3d:	je     101ccb1 <myl_rc_value_seed+0x271>
 101cb43:	mov    0x28(%r12),%r13
 101cb48:	xor    %ebx,%ebx
 101cb4a:	jmp    101cb6e <myl_rc_value_seed+0x12e>
 101cb4c:	nopl   0x0(%rax)
 101cb50:	mov    %r15,%rdi
 101cb53:	xor    %esi,%esi
 101cb55:	call   101ba40 <walk>
 101cb5a:	mov    -0x30(%rbp),%r11
 101cb5e:	add    (%r12),%r14
 101cb62:	inc    %rbx
 101cb65:	cmp    %r11,%rbx
 101cb68:	je     101ccb1 <myl_rc_value_seed+0x271>
 101cb6e:	mov    0x8(%r12),%eax
 101cb73:	cmp    $0x2,%r13
 101cb77:	jbe    101cbd0 <myl_rc_value_seed+0x190>
 101cb79:	test   %eax,%eax
 101cb7b:	je     101cb50 <myl_rc_value_seed+0x110>
 101cb7d:	mov    0x1608(%r15),%rax
 101cb84:	mov    0xc0(%rax),%rcx
 101cb8b:	cmp    0xb8(%rax),%rcx
 101cb92:	jae    101ccc0 <myl_rc_value_seed+0x280>
 101cb98:	mov    0xb0(%rax),%rdx
 101cb9f:	lea    0x1(%rcx),%rsi
 101cba3:	mov    %rsi,0xc0(%rax)
 101cbaa:	lea    (%rcx,%rcx,2),%rax
 101cbae:	mov    %r12,(%rdx,%rax,8)
 101cbb2:	mov    %r14,0x8(%rdx,%rax,8)
 101cbb7:	movq   $0x0,0x10(%rdx,%rax,8)
 101cbc0:	jmp    101cb50 <myl_rc_value_seed+0x110>
 101cbc2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101cbd0:	dec    %eax
 101cbd2:	cmp    $0x4,%eax
 101cbd5:	ja     101cc19 <myl_rc_value_seed+0x1d9>
 101cbd7:	jmp    *0x1001b30(,%rax,8)
 101cbde:	mov    $0x1,%eax
 101cbe3:	xor    %ecx,%ecx
 101cbe5:	jmp    101cc1d <myl_rc_value_seed+0x1dd>
 101cbe7:	mov    0x10(%r12),%rdx
 101cbec:	mov    0x18(%r12),%rax
 101cbf1:	mov    0x20(%r12),%rsi
 101cbf6:	add    %r14,%rsi
 101cbf9:	xor    %ecx,%ecx
 101cbfb:	jmp    101cc21 <myl_rc_value_seed+0x1e1>
 101cbfd:	mov    0x10(%r12),%rdx
 101cc02:	mov    0x18(%r12),%rax
 101cc07:	xor    %ecx,%ecx
 101cc09:	xor    %esi,%esi
 101cc0b:	jmp    101cc21 <myl_rc_value_seed+0x1e1>
 101cc0d:	mov    0x18(%r12),%rax
 101cc12:	mov    0x20(%r12),%rcx
 101cc17:	jmp    101cc1d <myl_rc_value_seed+0x1dd>
 101cc19:	xor    %ecx,%ecx
 101cc1b:	xor    %eax,%eax
 101cc1d:	xor    %esi,%esi
 101cc1f:	xor    %edx,%edx
 101cc21:	mov    %rax,%rdi
 101cc24:	neg    %rdi
 101cc27:	xor    %r8d,%r8d
 101cc2a:	test   %rdx,%rdx
 101cc2d:	je     101cc90 <myl_rc_value_seed+0x250>
 101cc2f:	cmp    %rax,%r8
 101cc32:	jae    101cb5e <myl_rc_value_seed+0x11e>
 101cc38:	lea    (%r8,%r8,2),%r9
 101cc3c:	lea    (%rdx,%r9,8),%r9
 101cc40:	inc    %r8
 101cc43:	jmp    101cc68 <myl_rc_value_seed+0x228>
 101cc45:	data16 cs nopw 0x0(%rax,%rax,1)
 101cc50:	add    $0x18,%r9
 101cc54:	lea    (%rdi,%r8,1),%r10
 101cc58:	inc    %r10
 101cc5b:	inc    %r8
 101cc5e:	cmp    $0x1,%r10
 101cc62:	je     101cb5e <myl_rc_value_seed+0x11e>
 101cc68:	mov    0x8(%r9),%r10
 101cc6c:	cmpl   $0x0,0x8(%r10)
 101cc71:	je     101cc50 <myl_rc_value_seed+0x210>
 101cc73:	test   %rsi,%rsi
 101cc76:	je     101cc81 <myl_rc_value_seed+0x241>
 101cc78:	mov    0x10(%r9),%r10d
 101cc7c:	cmp    (%rsi),%r10d
 101cc7f:	jne    101cc50 <myl_rc_value_seed+0x210>
 101cc81:	mov    (%r9),%r9
 101cc84:	movq   $0x0,(%r14,%r9,1)
 101cc8c:	jmp    101cc2a <myl_rc_value_seed+0x1ea>
 101cc8e:	xchg   %ax,%ax
 101cc90:	cmp    %rax,%r8
 101cc93:	je     101cb5e <myl_rc_value_seed+0x11e>
 101cc99:	lea    0x1(%r8),%r9
 101cc9d:	imul   %rcx,%r8
 101cca1:	movq   $0x0,(%r14,%r8,1)
 101cca9:	mov    %r9,%r8
 101ccac:	jmp    101cc2a <myl_rc_value_seed+0x1ea>
 101ccb1:	add    $0x8,%rsp
 101ccb5:	pop    %rbx
 101ccb6:	pop    %r12
 101ccb8:	pop    %r13
 101ccba:	pop    %r14
 101ccbc:	pop    %r15
 101ccbe:	pop    %rbp
 101ccbf:	ret
 101ccc0:	call   1018954 <myl_rc_invariant_failed>
 101ccc5:	int3
 101ccc6:	int3
 101ccc7:	int3
 101ccc8:	int3
 101ccc9:	int3
 101ccca:	int3
 101cccb:	int3
 101cccc:	int3
 101cccd:	int3
 101ccce:	int3
 101cccf:	int3

000000000101ccd0 <myl_rc_construction_abort>:
 101ccd0:	push   %rbp
 101ccd1:	mov    %rsp,%rbp
 101ccd4:	push   %r15
 101ccd6:	push   %r14
 101ccd8:	push   %rbx
 101ccd9:	push   %rax
 101ccda:	test   %rsi,%rsi
 101ccdd:	je     101cdf1 <myl_rc_construction_abort+0x121>
 101cce3:	mov    -0x10(%rsi),%rax
 101cce7:	test   $0x2,%al
 101cce9:	jne    101ce6a <myl_rc_construction_abort+0x19a>
 101ccef:	mov    %rdi,%rbx
 101ccf2:	bt     $0x3e,%rax
 101ccf7:	jb     101cd2d <myl_rc_construction_abort+0x5d>
 101ccf9:	mov    %rbx,%rdi
 101ccfc:	call   1018d40 <myl_rc_edge_release>
 101cd01:	test   %rbx,%rbx
 101cd04:	je     101cdf1 <myl_rc_construction_abort+0x121>
 101cd0a:	mov    0x1608(%rbx),%rax
 101cd11:	test   %rax,%rax
 101cd14:	je     101cdf1 <myl_rc_construction_abort+0x121>
 101cd1a:	cmpq   $0x0,0xc8(%rax)
 101cd22:	jne    101ce58 <myl_rc_construction_abort+0x188>
 101cd28:	jmp    101cdf1 <myl_rc_construction_abort+0x121>
 101cd2d:	test   $0x1,%al
 101cd2f:	jne    101cdf1 <myl_rc_construction_abort+0x121>
 101cd35:	or     $0x1,%rax
 101cd39:	mov    %rax,-0x10(%rsi)
 101cd3d:	mov    -0x8(%rsi),%rax
 101cd41:	mov    0x1608(%rbx),%rdi
 101cd48:	mov    0x34(%rax),%ecx
 101cd4b:	cmp    %rcx,0xa0(%rdi)
 101cd52:	mov    %rsi,%r14
 101cd55:	jbe    101cdfc <myl_rc_construction_abort+0x12c>
 101cd5b:	mov    0x98(%rdi),%rdx
 101cd62:	shl    $0x4,%rcx
 101cd66:	cmp    %rax,(%rdx,%rcx,1)
 101cd6a:	jne    101cdfc <myl_rc_construction_abort+0x12c>
 101cd70:	add    %rcx,%rdx
 101cd73:	mov    0x8(%rdx),%rax
 101cd77:	test   %rax,%rax
 101cd7a:	je     101ce6a <myl_rc_construction_abort+0x19a>
 101cd80:	mov    $0x28,%ecx
 101cd85:	bzhi   %rcx,-0x10(%rsi),%r15
 101cd8b:	mov    0x18(%rax),%rax
 101cd8f:	test   %rax,%rax
 101cd92:	je     101cd9f <myl_rc_construction_abort+0xcf>
 101cd94:	mov    %rbx,%rdi
 101cd97:	mov    %r14,%rsi
 101cd9a:	call   *%rax
 101cd9c:	mov    %r14,%rsi
 101cd9f:	mov    -0x8(%rsi),%rax
 101cda3:	mov    0x1608(%rbx),%rdi
 101cdaa:	mov    0x34(%rax),%ecx
 101cdad:	cmp    %rcx,0xa0(%rdi)
 101cdb4:	jbe    101ce12 <myl_rc_construction_abort+0x142>
 101cdb6:	mov    0x98(%rdi),%rdx
 101cdbd:	shl    $0x4,%rcx
 101cdc1:	cmp    %rax,(%rdx,%rcx,1)
 101cdc5:	jne    101ce12 <myl_rc_construction_abort+0x142>
 101cdc7:	add    %rcx,%rdx
 101cdca:	mov    0x8(%rdx),%rax
 101cdce:	shr    $0x2,%r15
 101cdd2:	mov    0x10(%rax),%rcx
 101cdd6:	test   %rcx,%rcx
 101cdd9:	je     101ce2a <myl_rc_construction_abort+0x15a>
 101cddb:	mov    %rbx,%rdi
 101cdde:	mov    %r15,%rdx
 101cde1:	call   *%rcx
 101cde3:	mov    -0x8(%r14),%rcx
 101cde7:	mov    %r15,%rax
 101cdea:	mulq   (%rcx)
 101cded:	jno    101ce4b <myl_rc_construction_abort+0x17b>
 101cdef:	jmp    101ce6a <myl_rc_construction_abort+0x19a>
 101cdf1:	add    $0x8,%rsp
 101cdf5:	pop    %rbx
 101cdf6:	pop    %r14
 101cdf8:	pop    %r15
 101cdfa:	pop    %rbp
 101cdfb:	ret
 101cdfc:	mov    %rax,%rsi
 101cdff:	call   1018f74 <myl_rc_binding_find_slow>
 101ce04:	mov    %r14,%rsi
 101ce07:	test   %rax,%rax
 101ce0a:	jne    101cd80 <myl_rc_construction_abort+0xb0>
 101ce10:	jmp    101ce6a <myl_rc_construction_abort+0x19a>
 101ce12:	mov    %rax,%rsi
 101ce15:	call   1018f74 <myl_rc_binding_find_slow>
 101ce1a:	mov    %r14,%rsi
 101ce1d:	shr    $0x2,%r15
 101ce21:	mov    0x10(%rax),%rcx
 101ce25:	test   %rcx,%rcx
 101ce28:	jne    101cddb <myl_rc_construction_abort+0x10b>
 101ce2a:	mov    0x8(%rax),%rax
 101ce2e:	mov    %rbx,%rdi
 101ce31:	mov    %rsi,%rdx
 101ce34:	mov    %rax,%rsi
 101ce37:	mov    %r15,%rcx
 101ce3a:	call   101b480 <myl_rc_edges_release>
 101ce3f:	mov    -0x8(%r14),%rcx
 101ce43:	mov    %r15,%rax
 101ce46:	mulq   (%rcx)
 101ce49:	jo     101ce6a <myl_rc_construction_abort+0x19a>
 101ce4b:	mov    %r14,%rdi
 101ce4e:	xor    %esi,%esi
 101ce50:	mov    %rax,%rdx
 101ce53:	call   1027650 <memset@plt>
 101ce58:	mov    %rbx,%rdi
 101ce5b:	add    $0x8,%rsp
 101ce5f:	pop    %rbx
 101ce60:	pop    %r14
 101ce62:	pop    %r15
 101ce64:	pop    %rbp
 101ce65:	jmp    101be30 <myl_rc_drain>
 101ce6a:	call   1018954 <myl_rc_invariant_failed>
 101ce6f:	int3

000000000101ce70 <clock_now>:
 101ce70:	push   %rbp
 101ce71:	mov    %rsp,%rbp
 101ce74:	push   %rbx
 101ce75:	sub    $0x18,%rsp
 101ce79:	xor    %ebx,%ebx
 101ce7b:	lea    -0x18(%rbp),%rsi
 101ce7f:	xor    %edi,%edi
 101ce81:	call   1027700 <clock_gettime@plt>
 101ce86:	mov    %eax,%ecx
 101ce88:	mov    $0x3,%eax
 101ce8d:	test   %ecx,%ecx
 101ce8f:	jne    101cecc <clock_now+0x5c>
 101ce91:	mov    -0x18(%rbp),%rsi
 101ce95:	mov    -0x10(%rbp),%rcx
 101ce99:	movabs $0x7fffffffffffffff,%rdx
 101cea3:	xor    %rcx,%rdx
 101cea6:	movabs $0x112e0be826d694b3,%rdi
 101ceb0:	mulx   %rdi,%rdx,%rdx
 101ceb5:	shr    $0x1a,%rdx
 101ceb9:	xor    %ebx,%ebx
 101cebb:	cmp    %rdx,%rsi
 101cebe:	jg     101cecc <clock_now+0x5c>
 101cec0:	imul   $0x3b9aca00,%rsi,%rbx
 101cec7:	add    %rcx,%rbx
 101ceca:	xor    %eax,%eax
 101cecc:	mov    %rbx,%rdx
 101cecf:	add    $0x18,%rsp
 101ced3:	pop    %rbx
 101ced4:	pop    %rbp
 101ced5:	ret
 101ced6:	int3
 101ced7:	int3
 101ced8:	int3
 101ced9:	int3
 101ceda:	int3
 101cedb:	int3
 101cedc:	int3
 101cedd:	int3
 101cede:	int3
 101cedf:	int3

000000000101cee0 <random_u64>:
 101cee0:	movabs $0x9e3779b97f4a7c15,%rax
 101ceea:	add    (%rdi),%rax
 101ceed:	mov    %rax,(%rdi)
 101cef0:	mov    %rax,%rcx
 101cef3:	shr    $0x1e,%rcx
 101cef7:	xor    %rax,%rcx
 101cefa:	movabs $0xbf58476d1ce4e5b9,%rax
 101cf04:	imul   %rcx,%rax
 101cf08:	mov    %rax,%rcx
 101cf0b:	shr    $0x1b,%rcx
 101cf0f:	xor    %rax,%rcx
 101cf12:	movabs $0x94d049bb133111eb,%rax
 101cf1c:	imul   %rcx,%rax
 101cf20:	mov    %rax,%rdx
 101cf23:	shr    $0x1f,%rdx
 101cf27:	xor    %rax,%rdx
 101cf2a:	xor    %eax,%eax
 101cf2c:	ret
 101cf2d:	int3
 101cf2e:	int3
 101cf2f:	int3

000000000101cf30 <environment_get>:
 101cf30:	push   %rbp
 101cf31:	mov    %rsp,%rbp
 101cf34:	push   %r15
 101cf36:	push   %r14
 101cf38:	push   %r13
 101cf3a:	push   %r12
 101cf3c:	push   %rbx
 101cf3d:	sub    $0x118,%rsp
 101cf44:	mov    %rdi,%rbx
 101cf47:	vxorps %xmm0,%xmm0,%xmm0
 101cf4b:	vmovups %xmm0,(%rdi)
 101cf4f:	movq   $0x0,0x10(%rdi)
 101cf57:	cmp    $0x100,%rcx
 101cf5e:	jb     101cf7b <environment_get+0x4b>
 101cf60:	movl   $0x2,(%rbx)
 101cf66:	mov    %rbx,%rax
 101cf69:	add    $0x118,%rsp
 101cf70:	pop    %rbx
 101cf71:	pop    %r12
 101cf73:	pop    %r13
 101cf75:	pop    %r14
 101cf77:	pop    %r15
 101cf79:	pop    %rbp
 101cf7a:	ret
 101cf7b:	mov    %rcx,%r15
 101cf7e:	mov    %rsi,%r14
 101cf81:	mov    %r9,-0x38(%rbp)
 101cf85:	mov    %r8,-0x30(%rbp)
 101cf89:	lea    -0x140(%rbp),%rdi
 101cf90:	mov    %rdx,%rsi
 101cf93:	mov    %rcx,%rdx
 101cf96:	call   10276a0 <memcpy@plt>
 101cf9b:	movb   $0x0,-0x140(%rbp,%r15,1)
 101cfa4:	cmpb   $0x0,(%r14)
 101cfa8:	je     101d02b <environment_get+0xfb>
 101cfae:	lea    -0x140(%rbp),%r13
 101cfb5:	jmp    101cfcf <environment_get+0x9f>
 101cfb7:	nopw   0x0(%rax,%rax,1)
 101cfc0:	mov    %r12,%rax
 101cfc3:	inc    %r12
 101cfc6:	cmpb   $0x0,0x1(%rax)
 101cfca:	mov    %r12,%r14
 101cfcd:	je     101cf60 <environment_get+0x30>
 101cfcf:	mov    %r14,%rdi
 101cfd2:	mov    $0x2c,%esi
 101cfd7:	call   1027910 <strchr@plt>
 101cfdc:	test   %rax,%rax
 101cfdf:	je     101d000 <environment_get+0xd0>
 101cfe1:	mov    %rax,%r12
 101cfe4:	sub    %r14,%rax
 101cfe7:	cmp    %r15,%rax
 101cfea:	jne    101cfc0 <environment_get+0x90>
 101cfec:	mov    %r14,%rdi
 101cfef:	mov    %r13,%rsi
 101cff2:	mov    %r15,%rdx
 101cff5:	call   1027870 <bcmp@plt>
 101cffa:	test   %eax,%eax
 101cffc:	jne    101cfc0 <environment_get+0x90>
 101cffe:	jmp    101d02b <environment_get+0xfb>
 101d000:	mov    %r14,%rdi
 101d003:	call   1027670 <strlen@plt>
 101d008:	cmp    %r15,%rax
 101d00b:	jne    101cf60 <environment_get+0x30>
 101d011:	lea    -0x140(%rbp),%rsi
 101d018:	mov    %r14,%rdi
 101d01b:	mov    %r15,%rdx
 101d01e:	call   1027870 <bcmp@plt>
 101d023:	test   %eax,%eax
 101d025:	jne    101cf60 <environment_get+0x30>
 101d02b:	lea    -0x140(%rbp),%rdi
 101d032:	call   1027660 <getenv@plt>
 101d037:	test   %rax,%rax
 101d03a:	je     101cf66 <environment_get+0x36>
 101d040:	mov    %rax,%r14
 101d043:	mov    %rax,%rdi
 101d046:	call   1027670 <strlen@plt>
 101d04b:	cmp    -0x38(%rbp),%rax
 101d04f:	jbe    101d05c <environment_get+0x12c>
 101d051:	movl   $0x5,(%rbx)
 101d057:	jmp    101cf66 <environment_get+0x36>
 101d05c:	mov    -0x30(%rbp),%rdi
 101d060:	mov    %r14,%rsi
 101d063:	mov    %rax,%rdx
 101d066:	mov    %rax,%r14
 101d069:	call   10276a0 <memcpy@plt>
 101d06e:	movl   $0x1,0x10(%rbx)
 101d075:	mov    %r14,0x8(%rbx)
 101d079:	jmp    101cf66 <environment_get+0x36>
 101d07e:	int3
 101d07f:	int3

000000000101d080 <mylang_scoped_endpoint>:
 101d080:	push   %rbp
 101d081:	mov    %rsp,%rbp
 101d084:	push   %r15
 101d086:	push   %r14
 101d088:	push   %r13
 101d08a:	push   %r12
 101d08c:	push   %rbx
 101d08d:	sub    $0x58,%rsp
 101d091:	mov    %rsi,%r15
 101d094:	mov    %rdi,%r13
 101d097:	mov    %rsi,%rdi
 101d09a:	call   1027670 <strlen@plt>
 101d09f:	mov    %rax,%r14
 101d0a2:	add    $0xffffffffffffefff,%rax
 101d0a8:	cmp    $0xfffffffffffff000,%rax
 101d0ae:	jb     101d0bd <mylang_scoped_endpoint+0x3d>
 101d0b0:	mov    0x28e8(%r13),%rbx
 101d0b7:	cmp    $0x7,%rbx
 101d0bb:	jbe    101d0ce <mylang_scoped_endpoint+0x4e>
 101d0bd:	xor    %eax,%eax
 101d0bf:	add    $0x58,%rsp
 101d0c3:	pop    %rbx
 101d0c4:	pop    %r12
 101d0c6:	pop    %r13
 101d0c8:	pop    %r14
 101d0ca:	pop    %r15
 101d0cc:	pop    %rbp
 101d0cd:	ret
 101d0ce:	cmp    $0x1,%r14
 101d0d2:	jne    101d129 <mylang_scoped_endpoint+0xa9>
 101d0d4:	cmpb   $0x2a,(%r15)
 101d0d8:	jne    101d129 <mylang_scoped_endpoint+0xa9>
 101d0da:	mov    %r13,-0x30(%rbp)
 101d0de:	test   %rbx,%rbx
 101d0e1:	je     101d1e4 <mylang_scoped_endpoint+0x164>
 101d0e7:	mov    -0x30(%rbp),%rax
 101d0eb:	lea    0x2870(%rax),%r12
 101d0f2:	mov    %rbx,%r13
 101d0f5:	jmp    101d10d <mylang_scoped_endpoint+0x8d>
 101d0f7:	nopw   0x0(%rax,%rax,1)
 101d100:	add    $0x10,%r12
 101d104:	dec    %r13
 101d107:	je     101d1e4 <mylang_scoped_endpoint+0x164>
 101d10d:	cmp    %r14,(%r12)
 101d111:	jne    101d100 <mylang_scoped_endpoint+0x80>
 101d113:	mov    -0x8(%r12),%rdi
 101d118:	mov    %r15,%rsi
 101d11b:	mov    %r14,%rdx
 101d11e:	call   1027870 <bcmp@plt>
 101d123:	test   %eax,%eax
 101d125:	jne    101d100 <mylang_scoped_endpoint+0x80>
 101d127:	jmp    101d0bd <mylang_scoped_endpoint+0x3d>
 101d129:	mov    %r15,%rdi
 101d12c:	mov    $0x3a,%esi
 101d131:	call   1027920 <strrchr@plt>
 101d136:	test   %rax,%rax
 101d139:	je     101d0bd <mylang_scoped_endpoint+0x3d>
 101d13b:	mov    %rax,%r12
 101d13e:	sub    %r15,%r12
 101d141:	je     101d0bd <mylang_scoped_endpoint+0x3d>
 101d147:	cmp    $0x3f,%r12
 101d14b:	ja     101d0bd <mylang_scoped_endpoint+0x3d>
 101d151:	lea    -0x80(%rbp),%rdi
 101d155:	mov    %r15,%rsi
 101d158:	mov    %r12,%rdx
 101d15b:	mov    %r13,%rbx
 101d15e:	mov    %rax,%r13
 101d161:	call   10276a0 <memcpy@plt>
 101d166:	movb   $0x0,-0x80(%rbp,%r12,1)
 101d16c:	inc    %r13
 101d16f:	mov    %r13,%rdi
 101d172:	mov    %rbx,%r13
 101d175:	xor    %esi,%esi
 101d177:	mov    $0xa,%edx
 101d17c:	call   1027930 <strtoul@plt>
 101d181:	lea    -0x10000(%rax),%rcx
 101d188:	cmp    $0xffffffffffff0001,%rcx
 101d18f:	jb     101d0bd <mylang_scoped_endpoint+0x3d>
 101d195:	lea    -0x3c(%rbp),%rdx
 101d199:	movl   $0x0,-0x34(%rbp)
 101d1a0:	movq   $0x0,-0x3c(%rbp)
 101d1a8:	movw   $0x2,-0x40(%rbp)
 101d1ae:	movbe  %ax,-0x3e(%rbp)
 101d1b4:	lea    -0x80(%rbp),%rsi
 101d1b8:	mov    $0x2,%edi
 101d1bd:	call   1027940 <inet_pton@plt>
 101d1c2:	cmp    $0x1,%eax
 101d1c5:	mov    $0x0,%eax
 101d1ca:	jne    101d0bf <mylang_scoped_endpoint+0x3f>
 101d1d0:	mov    0x28e8(%r13),%rbx
 101d1d7:	mov    %r13,-0x30(%rbp)
 101d1db:	test   %rbx,%rbx
 101d1de:	jne    101d0e7 <mylang_scoped_endpoint+0x67>
 101d1e4:	mov    %r14,%rdi
 101d1e7:	inc    %rdi
 101d1ea:	call   1027680 <malloc@plt>
 101d1ef:	mov    %rax,%r12
 101d1f2:	mov    $0x0,%eax
 101d1f7:	test   %r12,%r12
 101d1fa:	mov    -0x30(%rbp),%r13
 101d1fe:	je     101d0bf <mylang_scoped_endpoint+0x3f>
 101d204:	mov    %r12,%rdi
 101d207:	mov    %r15,%rsi
 101d20a:	mov    %r14,%rdx
 101d20d:	call   10276a0 <memcpy@plt>
 101d212:	movb   $0x0,(%r12,%r14,1)
 101d217:	mov    %rbx,%rax
 101d21a:	shl    $0x4,%rax
 101d21e:	mov    %r12,0x2868(%r13,%rax,1)
 101d226:	mov    %r14,0x2870(%r13,%rax,1)
 101d22e:	inc    %rbx
 101d231:	mov    %rbx,0x28e8(%r13)
 101d238:	mov    $0x1,%eax
 101d23d:	jmp    101d0bf <mylang_scoped_endpoint+0x3f>
 101d242:	int3
 101d243:	int3
 101d244:	int3
 101d245:	int3
 101d246:	int3
 101d247:	int3
 101d248:	int3
 101d249:	int3
 101d24a:	int3
 101d24b:	int3
 101d24c:	int3
 101d24d:	int3
 101d24e:	int3
 101d24f:	int3

000000000101d250 <acquire_network>:
 101d250:	push   %rbp
 101d251:	mov    %rsp,%rbp
 101d254:	push   %r15
 101d256:	push   %r14
 101d258:	push   %r13
 101d25a:	push   %r12
 101d25c:	push   %rbx
 101d25d:	sub    $0xe8,%rsp
 101d264:	mov    0x28e8(%rdi),%r12
 101d26b:	test   %r12,%r12
 101d26e:	je     101d43d <acquire_network+0x1ed>
 101d274:	test   $0x3,%cl
 101d277:	je     101d444 <acquire_network+0x1f4>
 101d27d:	mov    %rdx,%r13
 101d280:	mov    $0x2,%eax
 101d285:	cmp    $0x7f,%rdx
 101d289:	ja     101d449 <acquire_network+0x1f9>
 101d28f:	mov    %rdi,%r14
 101d292:	lea    -0x110(%rbp),%rdi
 101d299:	mov    %r13,%rdx
 101d29c:	call   10276a0 <memcpy@plt>
 101d2a1:	movb   $0x0,-0x110(%rbp,%r13,1)
 101d2aa:	lea    0x2868(%r14),%r15
 101d2b1:	xor    %ebx,%ebx
 101d2b3:	jmp    101d2cd <acquire_network+0x7d>
 101d2b5:	data16 cs nopw 0x0(%rax,%rax,1)
 101d2c0:	add    $0x10,%r15
 101d2c4:	dec    %r12
 101d2c7:	je     101d463 <acquire_network+0x213>
 101d2cd:	mov    0x8(%r15),%rax
 101d2d1:	cmp    $0x1,%rax
 101d2d5:	jne    101d2df <acquire_network+0x8f>
 101d2d7:	mov    (%r15),%rcx
 101d2da:	cmpb   $0x2a,(%rcx)
 101d2dd:	je     101d2fa <acquire_network+0xaa>
 101d2df:	cmp    %r13,%rax
 101d2e2:	jne    101d2c0 <acquire_network+0x70>
 101d2e4:	mov    (%r15),%rdi
 101d2e7:	lea    -0x110(%rbp),%rsi
 101d2ee:	mov    %r13,%rdx
 101d2f1:	call   1027870 <bcmp@plt>
 101d2f6:	test   %eax,%eax
 101d2f8:	jne    101d2c0 <acquire_network+0x70>
 101d2fa:	add    $0x68,%r14
 101d2fe:	xor    %ebx,%ebx
 101d300:	mov    $0x2,%eax
 101d305:	jmp    101d325 <acquire_network+0xd5>
 101d307:	nopw   0x0(%rax,%rax,1)
 101d310:	add    $0x2,%rbx
 101d314:	add    $0x50,%r14
 101d318:	cmp    $0x100,%rbx
 101d31f:	je     101d449 <acquire_network+0x1f9>
 101d325:	cmpl   $0x0,(%r14)
 101d329:	jns    101d332 <acquire_network+0xe2>
 101d32b:	cmpq   $0x0,0x8(%r14)
 101d330:	je     101d347 <acquire_network+0xf7>
 101d332:	cmpl   $0x0,0x28(%r14)
 101d337:	jns    101d310 <acquire_network+0xc0>
 101d339:	cmpq   $0x0,0x30(%r14)
 101d33e:	jne    101d310 <acquire_network+0xc0>
 101d340:	inc    %rbx
 101d343:	add    $0x28,%r14
 101d347:	lea    -0x110(%rbp),%r12
 101d34e:	mov    %r12,%rdi
 101d351:	mov    $0x3a,%esi
 101d356:	call   1027920 <strrchr@plt>
 101d35b:	mov    %rax,%r15
 101d35e:	sub    %r12,%r15
 101d361:	sete   %cl
 101d364:	test   %rax,%rax
 101d367:	je     101d436 <acquire_network+0x1e6>
 101d36d:	test   %cl,%cl
 101d36f:	jne    101d436 <acquire_network+0x1e6>
 101d375:	cmp    $0x3f,%r15
 101d379:	ja     101d436 <acquire_network+0x1e6>
 101d37f:	lea    -0x90(%rbp),%rdi
 101d386:	lea    -0x110(%rbp),%rsi
 101d38d:	mov    %r15,%rdx
 101d390:	mov    %rax,%r12
 101d393:	call   10276a0 <memcpy@plt>
 101d398:	movb   $0x0,-0x90(%rbp,%r15,1)
 101d3a1:	inc    %r12
 101d3a4:	mov    %r12,%rdi
 101d3a7:	xor    %esi,%esi
 101d3a9:	mov    $0xa,%edx
 101d3ae:	call   1027930 <strtoul@plt>
 101d3b3:	lea    -0x10000(%rax),%rcx
 101d3ba:	cmp    $0xffffffffffff0001,%rcx
 101d3c1:	jb     101d436 <acquire_network+0x1e6>
 101d3c3:	lea    -0x34(%rbp),%rdx
 101d3c7:	movl   $0x0,-0x2c(%rbp)
 101d3ce:	movq   $0x0,-0x34(%rbp)
 101d3d6:	movw   $0x2,-0x38(%rbp)
 101d3dc:	movbe  %ax,-0x36(%rbp)
 101d3e2:	lea    -0x90(%rbp),%rsi
 101d3e9:	mov    $0x2,%edi
 101d3ee:	call   1027940 <inet_pton@plt>
 101d3f3:	cmp    $0x1,%eax
 101d3f6:	jne    101d436 <acquire_network+0x1e6>
 101d3f8:	vmovups -0x38(%rbp),%xmm0
 101d3fd:	vmovaps %xmm0,-0x50(%rbp)
 101d402:	mov    $0x2,%edi
 101d407:	mov    $0x1,%esi
 101d40c:	xor    %edx,%edx
 101d40e:	call   1027950 <socket@plt>
 101d413:	test   %eax,%eax
 101d415:	js     101d436 <acquire_network+0x1e6>
 101d417:	mov    %eax,%r15d
 101d41a:	lea    -0x50(%rbp),%rsi
 101d41e:	mov    %eax,%edi
 101d420:	mov    $0x10,%edx
 101d425:	call   1027960 <connect@plt>
 101d42a:	test   %eax,%eax
 101d42c:	je     101d46a <acquire_network+0x21a>
 101d42e:	mov    %r15d,%edi
 101d431:	call   10277c0 <close@plt>
 101d436:	mov    $0x3,%eax
 101d43b:	jmp    101d449 <acquire_network+0x1f9>
 101d43d:	mov    $0x1,%eax
 101d442:	jmp    101d449 <acquire_network+0x1f9>
 101d444:	mov    $0x2,%eax
 101d449:	xor    %ebx,%ebx
 101d44b:	mov    %rbx,%rdx
 101d44e:	add    $0xe8,%rsp
 101d455:	pop    %rbx
 101d456:	pop    %r12
 101d458:	pop    %r13
 101d45a:	pop    %r14
 101d45c:	pop    %r15
 101d45e:	pop    %rbp
 101d45f:	vzeroupper
 101d462:	ret
 101d463:	mov    $0x2,%eax
 101d468:	jmp    101d44b <acquire_network+0x1fb>
 101d46a:	mov    %r15d,(%r14)
 101d46d:	vxorps %xmm0,%xmm0,%xmm0
 101d471:	vmovups %ymm0,0x4(%r14)
 101d477:	movl   $0x0,0x24(%r14)
 101d47f:	xor    %eax,%eax
 101d481:	jmp    101d44b <acquire_network+0x1fb>
 101d483:	int3
 101d484:	int3
 101d485:	int3
 101d486:	int3
 101d487:	int3
 101d488:	int3
 101d489:	int3
 101d48a:	int3
 101d48b:	int3
 101d48c:	int3
 101d48d:	int3
 101d48e:	int3
 101d48f:	int3

000000000101d490 <complete>:
 101d490:	mov    $0x3,%eax
 101d495:	cmp    $0xff,%rsi
 101d49c:	ja     101d4ef <complete+0x5f>
 101d49e:	push   %rbp
 101d49f:	mov    %rsp,%rbp
 101d4a2:	push   %rbx
 101d4a3:	push   %rax
 101d4a4:	lea    (%rsi,%rsi,4),%rcx
 101d4a8:	lea    (%rdi,%rcx,8),%rbx
 101d4ac:	add    $0x68,%rbx
 101d4b0:	mov    0x68(%rdi,%rcx,8),%edi
 101d4b4:	test   %edi,%edi
 101d4b6:	js     101d4c3 <complete+0x33>
 101d4b8:	call   10277c0 <close@plt>
 101d4bd:	mov    0x8(%rbx),%rdi
 101d4c1:	jmp    101d4cc <complete+0x3c>
 101d4c3:	mov    0x8(%rbx),%rdi
 101d4c7:	test   %rdi,%rdi
 101d4ca:	je     101d4e9 <complete+0x59>
 101d4cc:	call   10276f0 <free@plt>
 101d4d1:	movl   $0xffffffff,(%rbx)
 101d4d7:	vxorps %xmm0,%xmm0,%xmm0
 101d4db:	vmovups %ymm0,0x4(%rbx)
 101d4e0:	movl   $0x0,0x24(%rbx)
 101d4e7:	xor    %eax,%eax
 101d4e9:	add    $0x8,%rsp
 101d4ed:	pop    %rbx
 101d4ee:	pop    %rbp
 101d4ef:	vzeroupper
 101d4f2:	ret
 101d4f3:	int3
 101d4f4:	int3
 101d4f5:	int3
 101d4f6:	int3
 101d4f7:	int3
 101d4f8:	int3
 101d4f9:	int3
 101d4fa:	int3
 101d4fb:	int3
 101d4fc:	int3
 101d4fd:	int3
 101d4fe:	int3
 101d4ff:	int3

000000000101d500 <release>:
 101d500:	push   %rbp
 101d501:	mov    %rsp,%rbp
 101d504:	push   %rbx
 101d505:	push   %rax
 101d506:	cmp    $0xff,%rsi
 101d50d:	ja     101d552 <release+0x52>
 101d50f:	lea    (%rsi,%rsi,4),%rax
 101d513:	lea    (%rdi,%rax,8),%rbx
 101d517:	add    $0x68,%rbx
 101d51b:	mov    0x68(%rdi,%rax,8),%edi
 101d51f:	test   %edi,%edi
 101d521:	js     101d52e <release+0x2e>
 101d523:	call   10277c0 <close@plt>
 101d528:	mov    0x8(%rbx),%rdi
 101d52c:	jmp    101d537 <release+0x37>
 101d52e:	mov    0x8(%rbx),%rdi
 101d532:	test   %rdi,%rdi
 101d535:	je     101d552 <release+0x52>
 101d537:	call   10276f0 <free@plt>
 101d53c:	movl   $0xffffffff,(%rbx)
 101d542:	vxorps %xmm0,%xmm0,%xmm0
 101d546:	vmovups %ymm0,0x4(%rbx)
 101d54b:	movl   $0x0,0x24(%rbx)
 101d552:	add    $0x8,%rsp
 101d556:	pop    %rbx
 101d557:	pop    %rbp
 101d558:	vzeroupper
 101d55b:	ret
 101d55c:	int3
 101d55d:	int3
 101d55e:	int3
 101d55f:	int3

000000000101d560 <read_handle>:
 101d560:	mov    %rdi,%rax
 101d563:	vmovups -0x11f6b(%rip),%xmm0        # 100b600 <myl_rc_map_sentinel+0x10>
 101d56b:	vmovups %xmm0,(%rdi)
 101d56f:	movq   $0x0,0x10(%rdi)
 101d577:	cmp    $0xff,%rdx
 101d57e:	ja     101d68c <read_handle+0x12c>
 101d584:	push   %rbp
 101d585:	mov    %rsp,%rbp
 101d588:	push   %r15
 101d58a:	push   %r14
 101d58c:	push   %rbx
 101d58d:	push   %rax
 101d58e:	lea    (%rdx,%rdx,4),%rdx
 101d592:	lea    (%rsi,%rdx,8),%r15
 101d596:	add    $0x68,%r15
 101d59a:	mov    0x68(%rsi,%rdx,8),%edi
 101d59e:	test   %edi,%edi
 101d5a0:	jns    101d5ad <read_handle+0x4d>
 101d5a2:	cmpq   $0x0,0x8(%r15)
 101d5a7:	je     101d682 <read_handle+0x122>
 101d5ad:	test   %r8,%r8
 101d5b0:	je     101d616 <read_handle+0xb6>
 101d5b2:	mov    %rax,%r14
 101d5b5:	cmp    $0x10000,%r8
 101d5bc:	mov    $0x10000,%edx
 101d5c1:	cmovb  %r8,%rdx
 101d5c5:	mov    0x8(%r15),%rsi
 101d5c9:	test   %rsi,%rsi
 101d5cc:	je     101d61e <read_handle+0xbe>
 101d5ce:	mov    0x10(%r15),%rbx
 101d5d2:	mov    0x18(%r15),%rax
 101d5d6:	sub    %rax,%rbx
 101d5d9:	cmp    %rdx,%rbx
 101d5dc:	cmovae %rdx,%rbx
 101d5e0:	add    %rax,%rsi
 101d5e3:	mov    %rcx,%rdi
 101d5e6:	mov    %rbx,%rdx
 101d5e9:	call   10276a0 <memcpy@plt>
 101d5ee:	mov    0x18(%r15),%rcx
 101d5f2:	add    %rbx,%rcx
 101d5f5:	mov    %rcx,0x18(%r15)
 101d5f9:	mov    %r14,%rax
 101d5fc:	movl   $0x0,(%r14)
 101d603:	mov    %rbx,0x8(%r14)
 101d607:	xor    %edx,%edx
 101d609:	cmp    0x10(%r15),%rcx
 101d60d:	sete   %dl
 101d610:	mov    %edx,0x10(%r14)
 101d614:	jmp    101d682 <read_handle+0x122>
 101d616:	movl   $0x0,(%rax)
 101d61c:	jmp    101d682 <read_handle+0x122>
 101d61e:	cmpb   $0x61,0x20(%r15)
 101d623:	jne    101d631 <read_handle+0xd1>
 101d625:	mov    %r14,%rax
 101d628:	movl   $0x2,(%r14)
 101d62f:	jmp    101d682 <read_handle+0x122>
 101d631:	mov    %rcx,%rsi
 101d634:	call   1027970 <read@plt>
 101d639:	test   %rax,%rax
 101d63c:	js     101d65b <read_handle+0xfb>
 101d63e:	mov    %rax,%rcx
 101d641:	mov    %r14,%rax
 101d644:	movl   $0x0,(%r14)
 101d64b:	mov    %rcx,0x8(%r14)
 101d64f:	sete   %cl
 101d652:	movzbl %cl,%ecx
 101d655:	mov    %ecx,0x10(%r14)
 101d659:	jmp    101d682 <read_handle+0x122>
 101d65b:	call   1027980 <__errno_location@plt>
 101d660:	mov    (%rax),%edx
 101d662:	cmp    $0x28,%rdx
 101d666:	mov    %r14,%rax
 101d669:	ja     101d698 <read_handle+0x138>
 101d66b:	movabs $0x10000102002,%rcx
 101d675:	bt     %rdx,%rcx
 101d679:	jae    101d68d <read_handle+0x12d>
 101d67b:	mov    $0x2,%ecx
 101d680:	mov    %ecx,(%rax)
 101d682:	add    $0x8,%rsp
 101d686:	pop    %rbx
 101d687:	pop    %r14
 101d689:	pop    %r15
 101d68b:	pop    %rbp
 101d68c:	ret
 101d68d:	mov    $0x4,%ecx
 101d692:	cmp    $0xc,%rdx
 101d696:	je     101d680 <read_handle+0x120>
 101d698:	mov    $0x3,%ecx
 101d69d:	jmp    101d680 <read_handle+0x120>
 101d69f:	int3

000000000101d6a0 <write_handle>:
 101d6a0:	mov    $0x3,%eax
 101d6a5:	cmp    $0xff,%rsi
 101d6ac:	jbe    101d6b1 <write_handle+0x11>
 101d6ae:	xor    %edx,%edx
 101d6b0:	ret
 101d6b1:	mov    %rdi,%r8
 101d6b4:	lea    (%rsi,%rsi,4),%rax
 101d6b8:	mov    0x68(%rdi,%rax,8),%edi
 101d6bc:	mov    0x70(%r8,%rax,8),%rsi
 101d6c1:	test   %edi,%edi
 101d6c3:	js     101d6d2 <write_handle+0x32>
 101d6c5:	test   %rsi,%rsi
 101d6c8:	je     101d6e1 <write_handle+0x41>
 101d6ca:	xor    %edx,%edx
 101d6cc:	mov    $0x2,%eax
 101d6d1:	ret
 101d6d2:	xor    %edx,%edx
 101d6d4:	cmp    $0x1,%rsi
 101d6d8:	mov    $0x0,%eax
 101d6dd:	adc    $0x2,%eax
 101d6e0:	ret
 101d6e1:	push   %rbp
 101d6e2:	mov    %rsp,%rbp
 101d6e5:	push   %r15
 101d6e7:	push   %r14
 101d6e9:	push   %rbx
 101d6ea:	push   %rax
 101d6eb:	lea    (%r8,%rax,8),%r15
 101d6ef:	add    $0x68,%r15
 101d6f3:	cmp    $0x10000,%rcx
 101d6fa:	mov    $0x10000,%ebx
 101d6ff:	cmovb  %rcx,%rbx
 101d703:	cmpb   $0x61,0x20(%r15)
 101d708:	jne    101d73b <write_handle+0x9b>
 101d70a:	mov    %rdx,%r14
 101d70d:	xor    %esi,%esi
 101d70f:	mov    $0x2,%edx
 101d714:	call   1027990 <lseek@plt>
 101d719:	test   %rax,%rax
 101d71c:	js     101d776 <write_handle+0xd6>
 101d71e:	mov    (%r15),%edi
 101d721:	mov    %r14,%rsi
 101d724:	mov    %rbx,%rdx
 101d727:	mov    %rax,%rcx
 101d72a:	call   10279a0 <pwrite@plt>
 101d72f:	mov    %rax,%rdx
 101d732:	xor    %eax,%eax
 101d734:	test   %rdx,%rdx
 101d737:	jns    101d7b0 <write_handle+0x110>
 101d739:	jmp    101d750 <write_handle+0xb0>
 101d73b:	mov    %rdx,%rsi
 101d73e:	mov    %rbx,%rdx
 101d741:	call   1027840 <write@plt>
 101d746:	mov    %rax,%rdx
 101d749:	xor    %eax,%eax
 101d74b:	test   %rdx,%rdx
 101d74e:	jns    101d7b0 <write_handle+0x110>
 101d750:	call   1027980 <__errno_location@plt>
 101d755:	mov    (%rax),%eax
 101d757:	cmp    $0x28,%rax
 101d75b:	ja     101d7a9 <write_handle+0x109>
 101d75d:	movabs $0x10000102002,%rcx
 101d767:	bt     %rax,%rcx
 101d76b:	jae    101d79a <write_handle+0xfa>
 101d76d:	xor    %edx,%edx
 101d76f:	mov    $0x2,%eax
 101d774:	jmp    101d7b0 <write_handle+0x110>
 101d776:	call   1027980 <__errno_location@plt>
 101d77b:	mov    (%rax),%eax
 101d77d:	cmp    $0x28,%rax
 101d781:	ja     101d7a9 <write_handle+0x109>
 101d783:	movabs $0x10000102002,%rcx
 101d78d:	bt     %rax,%rcx
 101d791:	jae    101d79a <write_handle+0xfa>
 101d793:	mov    $0x2,%eax
 101d798:	jmp    101d7a5 <write_handle+0x105>
 101d79a:	cmp    $0xc,%rax
 101d79e:	jne    101d7a9 <write_handle+0x109>
 101d7a0:	mov    $0x4,%eax
 101d7a5:	xor    %edx,%edx
 101d7a7:	jmp    101d7b0 <write_handle+0x110>
 101d7a9:	xor    %edx,%edx
 101d7ab:	mov    $0x3,%eax
 101d7b0:	add    $0x8,%rsp
 101d7b4:	pop    %rbx
 101d7b5:	pop    %r14
 101d7b7:	pop    %r15
 101d7b9:	pop    %rbp
 101d7ba:	ret
 101d7bb:	int3
 101d7bc:	int3
 101d7bd:	int3
 101d7be:	int3
 101d7bf:	int3

000000000101d7c0 <acquire>:
 101d7c0:	push   %rbp
 101d7c1:	mov    %rsp,%rbp
 101d7c4:	push   %r15
 101d7c6:	push   %r14
 101d7c8:	push   %r13
 101d7ca:	push   %r12
 101d7cc:	push   %rbx
 101d7cd:	sub    $0x1148,%rsp
 101d7d4:	cmpq   $0x0,0x60(%rdi)
 101d7d9:	je     101d82f <acquire+0x6f>
 101d7db:	mov    %rdx,%r8
 101d7de:	lea    -0x1001(%rdx),%rax
 101d7e5:	mov    $0x2,%r9d
 101d7eb:	cmp    $0xfffffffffffff001,%rax
 101d7f1:	jb     101d835 <acquire+0x75>
 101d7f3:	mov    %rsi,%r13
 101d7f6:	cmpb   $0x3a,0x1(%rsi)
 101d7fa:	jne    101d835 <acquire+0x75>
 101d7fc:	movzbl 0x0(%r13),%eax
 101d801:	mov    %al,-0x29(%rbp)
 101d804:	movzbl %al,%eax
 101d807:	xor    %ebx,%ebx
 101d809:	lea    -0x61(%rax),%r12d
 101d80d:	cmp    $0x17,%r12d
 101d811:	ja     101d837 <acquire+0x77>
 101d813:	mov    %rdi,%r14
 101d816:	mov    %rax,-0xb0(%rbp)
 101d81d:	mov    $0xc80405,%eax
 101d822:	bt     %r12d,%eax
 101d826:	jae    101d84f <acquire+0x8f>
 101d828:	mov    $0x2,%eax
 101d82d:	jmp    101d85f <acquire+0x9f>
 101d82f:	mov    $0x1,%r9d
 101d835:	xor    %ebx,%ebx
 101d837:	mov    %r9d,%eax
 101d83a:	mov    %rbx,%rdx
 101d83d:	add    $0x1148,%rsp
 101d844:	pop    %rbx
 101d845:	pop    %r12
 101d847:	pop    %r13
 101d849:	pop    %r14
 101d84b:	pop    %r15
 101d84d:	pop    %rbp
 101d84e:	ret
 101d84f:	mov    $0x1,%eax
 101d854:	mov    $0x21800,%edx
 101d859:	bt     %r12d,%edx
 101d85d:	jae    101d837 <acquire+0x77>
 101d85f:	test   %ecx,%eax
 101d861:	je     101d835 <acquire+0x75>
 101d863:	add    $0x2,%r13
 101d867:	lea    -0x2(%r8),%rdx
 101d86b:	mov    -0xb0(%rbp),%rax
 101d872:	mov    %eax,%ecx
 101d874:	and    $0xfe,%cl
 101d877:	mov    %cl,-0x61(%rbp)
 101d87a:	lea    0x68(%r14),%rcx
 101d87e:	mov    %rcx,-0xd8(%rbp)
 101d885:	xor    %ecx,%ecx
 101d887:	cmp    $0x72,%al
 101d889:	setne  %cl
 101d88c:	mov    %ecx,-0x94(%rbp)
 101d892:	dec    %r8
 101d895:	add    $0xffffff95,%eax
 101d898:	mov    %rax,-0xd0(%rbp)
 101d89f:	mov    $0xc80405,%r15d
 101d8a5:	xor    %ecx,%ecx
 101d8a7:	mov    %r13,-0x60(%rbp)
 101d8ab:	mov    %rdx,-0x38(%rbp)
 101d8af:	mov    %r8,-0xc8(%rbp)
 101d8b6:	mov    %r14,-0x78(%rbp)
 101d8ba:	mov    %r12d,-0x3c(%rbp)
 101d8be:	jmp    101d8de <acquire+0x11e>
 101d8c0:	mov    $0x2,%r9d
 101d8c6:	mov    -0x3c(%rbp),%r12d
 101d8ca:	mov    -0xe0(%rbp),%rcx
 101d8d1:	inc    %rcx
 101d8d4:	cmp    0x60(%r14),%rcx
 101d8d8:	jae    101d835 <acquire+0x75>
 101d8de:	cmp    $0x17,%r12d
 101d8e2:	mov    %rcx,-0xe0(%rbp)
 101d8e9:	ja     101d8fd <acquire+0x13d>
 101d8eb:	bt     %r12d,%r15d
 101d8ef:	jae    101d8fd <acquire+0x13d>
 101d8f1:	lea    (%rcx,%rcx,2),%rax
 101d8f5:	cmpl   $0x0,0x4(%r14,%rax,4)
 101d8fb:	je     101d8ca <acquire+0x10a>
 101d8fd:	lea    (%rcx,%rcx,2),%rbx
 101d901:	mov    0x8(%r14,%rbx,4),%eax
 101d906:	mov    %eax,-0x80(%rbp)
 101d909:	test   %eax,%eax
 101d90b:	je     101da30 <acquire+0x270>
 101d911:	lea    (%r14,%rbx,4),%rax
 101d915:	mov    (%rax),%eax
 101d917:	mov    %eax,-0x4c(%rbp)
 101d91a:	mov    -0xd8(%rbp),%r12
 101d921:	xor    %ebx,%ebx
 101d923:	jmp    101d945 <acquire+0x185>
 101d925:	data16 cs nopw 0x0(%rax,%rax,1)
 101d930:	add    $0x2,%rbx
 101d934:	add    $0x50,%r12
 101d938:	cmp    $0x100,%rbx
 101d93f:	je     101d8c0 <acquire+0x100>
 101d945:	cmpl   $0x0,(%r12)
 101d94a:	jns    101d954 <acquire+0x194>
 101d94c:	cmpq   $0x0,0x8(%r12)
 101d952:	je     101d96b <acquire+0x1ab>
 101d954:	cmpl   $0x0,0x28(%r12)
 101d95a:	jns    101d930 <acquire+0x170>
 101d95c:	cmpq   $0x0,0x30(%r12)
 101d962:	jne    101d930 <acquire+0x170>
 101d964:	inc    %rbx
 101d967:	add    $0x28,%r12
 101d96b:	test   %rdx,%rdx
 101d96e:	je     101da9c <acquire+0x2dc>
 101d974:	mov    $0x0,%r14d
 101d97a:	mov    -0x4c(%rbp),%eax
 101d97d:	mov    %eax,-0x48(%rbp)
 101d980:	cmpl   $0x0,-0x80(%rbp)
 101d984:	jne    101daa5 <acquire+0x2e5>
 101d98a:	xor    %r15d,%r15d
 101d98d:	mov    -0x4c(%rbp),%eax
 101d990:	mov    %eax,-0x48(%rbp)
 101d993:	xor    %r14d,%r14d
 101d996:	jmp    101d9c5 <acquire+0x205>
 101d998:	nopl   0x0(%rax,%rax,1)
 101d9a0:	test   %r13d,%r13d
 101d9a3:	js     101dbb0 <acquire+0x3f0>
 101d9a9:	lea    0x1(%r15),%r14
 101d9ad:	mov    %r13d,-0x48(%rbp)
 101d9b1:	mov    -0x60(%rbp),%r13
 101d9b5:	mov    -0x38(%rbp),%rdx
 101d9b9:	inc    %r15
 101d9bc:	cmp    %r15,%rdx
 101d9bf:	je     101daa5 <acquire+0x2e5>
 101d9c5:	cmpb   $0x2f,0x0(%r13,%r15,1)
 101d9cb:	jne    101d9b9 <acquire+0x1f9>
 101d9cd:	mov    %r15,%rdx
 101d9d0:	sub    %r14,%rdx
 101d9d3:	cmp    $0xffe,%rdx
 101d9da:	ja     101db96 <acquire+0x3d6>
 101d9e0:	lea    (%r14,%r13,1),%rsi
 101d9e4:	lea    -0x1170(%rbp),%r13
 101d9eb:	mov    %r13,%rdi
 101d9ee:	call   10276a0 <memcpy@plt>
 101d9f3:	mov    %r13,%rax
 101d9f6:	sub    %r14,%rax
 101d9f9:	movb   $0x0,(%rax,%r15,1)
 101d9fe:	mov    -0x48(%rbp),%r14d
 101da02:	mov    %r14d,%edi
 101da05:	mov    %r13,%rsi
 101da08:	mov    $0xb0000,%edx
 101da0d:	xor    %eax,%eax
 101da0f:	call   10279b0 <openat@plt>
 101da14:	mov    %eax,%r13d
 101da17:	cmp    -0x4c(%rbp),%r14d
 101da1b:	je     101d9a0 <acquire+0x1e0>
 101da1d:	mov    %r14d,%edi
 101da20:	call   10277c0 <close@plt>
 101da25:	jmp    101d9a0 <acquire+0x1e0>
 101da2a:	nopw   0x0(%rax,%rax,1)
 101da30:	test   %rdx,%rdx
 101da33:	je     101da60 <acquire+0x2a0>
 101da35:	mov    %r9d,-0x58(%rbp)
 101da39:	mov    %r13,%rdi
 101da3c:	mov    $0x5c,%esi
 101da41:	mov    %rdx,%r15
 101da44:	call   10279c0 <memchr@plt>
 101da49:	test   %rax,%rax
 101da4c:	je     101da6f <acquire+0x2af>
 101da4e:	mov    %r15,%rdx
 101da51:	mov    $0xc80405,%r15d
 101da57:	mov    -0x58(%rbp),%r9d
 101da5b:	jmp    101d8ca <acquire+0x10a>
 101da60:	cmpb   $0x6c,-0x61(%rbp)
 101da64:	jne    101d8ca <acquire+0x10a>
 101da6a:	jmp    101d911 <acquire+0x151>
 101da6f:	mov    %r13,%rdi
 101da72:	xor    %esi,%esi
 101da74:	mov    %r15,%rdx
 101da77:	call   10279c0 <memchr@plt>
 101da7c:	test   %rax,%rax
 101da7f:	je     101dc02 <acquire+0x442>
 101da85:	mov    -0x38(%rbp),%rdx
 101da89:	mov    $0xc80405,%r15d
 101da8f:	mov    -0x60(%rbp),%r13
 101da93:	mov    -0x58(%rbp),%r9d
 101da97:	jmp    101d8ca <acquire+0x10a>
 101da9c:	xor    %r14d,%r14d
 101da9f:	mov    -0x4c(%rbp),%eax
 101daa2:	mov    %eax,-0x48(%rbp)
 101daa5:	cmpl   $0x0,-0x48(%rbp)
 101daa9:	js     101dbb4 <acquire+0x3f4>
 101daaf:	mov    %rdx,%r13
 101dab2:	sub    %r14,%r13
 101dab5:	cmp    $0xfff,%r13
 101dabc:	mov    $0xc80405,%r15d
 101dac2:	jb     101daf2 <acquire+0x332>
 101dac4:	mov    $0x2,%r9d
 101daca:	mov    -0x48(%rbp),%edi
 101dacd:	cmp    -0x4c(%rbp),%edi
 101dad0:	mov    -0x78(%rbp),%r14
 101dad4:	mov    -0x3c(%rbp),%r12d
 101dad8:	je     101dae9 <acquire+0x329>
 101dada:	call   10277c0 <close@plt>
 101dadf:	mov    $0x2,%r9d
 101dae5:	mov    -0x38(%rbp),%rdx
 101dae9:	mov    -0x60(%rbp),%r13
 101daed:	jmp    101d8ca <acquire+0x10a>
 101daf2:	add    -0x60(%rbp),%r14
 101daf6:	lea    -0x1170(%rbp),%rdi
 101dafd:	mov    %r14,%rsi
 101db00:	mov    %r13,%rdx
 101db03:	call   10276a0 <memcpy@plt>
 101db08:	movb   $0x0,-0x1170(%rbp,%r13,1)
 101db11:	mov    -0xd0(%rbp),%rax
 101db18:	cmp    $0xd,%eax
 101db1b:	ja     101df22 <acquire+0x762>
 101db21:	jmp    *0x1001b58(,%rax,8)
 101db28:	movzbl -0x1170(%rbp),%eax
 101db2f:	cmpb   $0x6d,-0x29(%rbp)
 101db33:	jne    101dc95 <acquire+0x4d5>
 101db39:	test   %al,%al
 101db3b:	mov    -0x60(%rbp),%r13
 101db3f:	je     101df70 <acquire+0x7b0>
 101db45:	mov    -0x48(%rbp),%edi
 101db48:	lea    -0x1170(%rbp),%rsi
 101db4f:	lea    -0x170(%rbp),%rdx
 101db56:	mov    $0x100,%ecx
 101db5b:	call   10279d0 <fstatat@plt>
 101db60:	test   %eax,%eax
 101db62:	je     101df87 <acquire+0x7c7>
 101db68:	call   1027980 <__errno_location@plt>
 101db6d:	mov    (%rax),%eax
 101db6f:	cmp    $0x28,%rax
 101db73:	mov    -0x38(%rbp),%rdx
 101db77:	ja     101e3d1 <acquire+0xc11>
 101db7d:	movabs $0x10000102002,%rcx
 101db87:	bt     %rax,%rcx
 101db8b:	jb     101e0bd <acquire+0x8fd>
 101db91:	jmp    101e0c8 <acquire+0x908>
 101db96:	call   1027980 <__errno_location@plt>
 101db9b:	movl   $0x24,(%rax)
 101dba1:	mov    -0x48(%rbp),%edi
 101dba4:	cmp    -0x4c(%rbp),%edi
 101dba7:	je     101dbb4 <acquire+0x3f4>
 101dba9:	call   10277c0 <close@plt>
 101dbae:	jmp    101dbb4 <acquire+0x3f4>
 101dbb0:	mov    -0x60(%rbp),%r13
 101dbb4:	call   1027980 <__errno_location@plt>
 101dbb9:	mov    -0x38(%rbp),%rdx
 101dbbd:	mov    (%rax),%eax
 101dbbf:	cmp    $0x28,%rax
 101dbc3:	mov    -0x78(%rbp),%r14
 101dbc7:	mov    -0x3c(%rbp),%r12d
 101dbcb:	mov    $0xc80405,%r15d
 101dbd1:	ja     101dbf7 <acquire+0x437>
 101dbd3:	mov    $0x2,%r9d
 101dbd9:	movabs $0x10000102002,%rcx
 101dbe3:	bt     %rax,%rcx
 101dbe7:	jb     101d8ca <acquire+0x10a>
 101dbed:	cmp    $0xc,%rax
 101dbf1:	je     101e4a0 <acquire+0xce0>
 101dbf7:	mov    $0x3,%r9d
 101dbfd:	jmp    101d8ca <acquire+0x10a>
 101dc02:	xor    %eax,%eax
 101dc04:	xor    %ecx,%ecx
 101dc06:	mov    -0x38(%rbp),%rdx
 101dc0a:	mov    $0xc80405,%r15d
 101dc10:	mov    -0xc8(%rbp),%r8
 101dc17:	mov    -0x60(%rbp),%r13
 101dc1b:	mov    -0x58(%rbp),%r9d
 101dc1f:	jmp    101dc40 <acquire+0x480>
 101dc21:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101dc30:	lea    0x1(%rax),%rcx
 101dc34:	inc    %rax
 101dc37:	cmp    %rax,%r8
 101dc3a:	je     101d911 <acquire+0x151>
 101dc40:	cmp    %rax,%rdx
 101dc43:	je     101dc4d <acquire+0x48d>
 101dc45:	cmpb   $0x2f,0x0(%r13,%rax,1)
 101dc4b:	jne    101dc34 <acquire+0x474>
 101dc4d:	mov    %rax,%rsi
 101dc50:	sub    %rcx,%rsi
 101dc53:	je     101d8ca <acquire+0x10a>
 101dc59:	cmp    $0x2,%rsi
 101dc5d:	je     101dc80 <acquire+0x4c0>
 101dc5f:	cmp    $0x1,%rsi
 101dc63:	jne    101dc30 <acquire+0x470>
 101dc65:	cmpb   $0x2e,0x0(%r13,%rcx,1)
 101dc6b:	jne    101dc30 <acquire+0x470>
 101dc6d:	jmp    101d8ca <acquire+0x10a>
 101dc72:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101dc80:	cmpb   $0x2e,0x0(%r13,%rcx,1)
 101dc86:	jne    101dc30 <acquire+0x470>
 101dc88:	cmpb   $0x2e,0x1(%r13,%rcx,1)
 101dc8e:	jne    101dc30 <acquire+0x470>
 101dc90:	jmp    101d8ca <acquire+0x10a>
 101dc95:	mov    $0x2,%r9d
 101dc9b:	test   %al,%al
 101dc9d:	mov    -0x60(%rbp),%r13
 101dca1:	mov    -0x38(%rbp),%rdx
 101dca5:	je     101e3d7 <acquire+0xc17>
 101dcab:	cmpb   $0x6b,-0x29(%rbp)
 101dcaf:	jne    101dfd9 <acquire+0x819>
 101dcb5:	mov    -0x48(%rbp),%edi
 101dcb8:	lea    -0x1170(%rbp),%rsi
 101dcbf:	mov    $0x1ff,%edx
 101dcc4:	call   10279e0 <mkdirat@plt>
 101dcc9:	test   %eax,%eax
 101dccb:	je     101e072 <acquire+0x8b2>
 101dcd1:	call   1027980 <__errno_location@plt>
 101dcd6:	mov    (%rax),%eax
 101dcd8:	cmp    $0x28,%rax
 101dcdc:	mov    -0x38(%rbp),%rdx
 101dce0:	ja     101e3d1 <acquire+0xc11>
 101dce6:	movabs $0x10000102002,%rcx
 101dcf0:	bt     %rax,%rcx
 101dcf4:	jb     101e1e7 <acquire+0xa27>
 101dcfa:	jmp    101e0c8 <acquire+0x908>
 101dcff:	cmpb   $0x0,-0x1170(%rbp)
 101dd06:	lea    -0x1170(%rbp),%rsi
 101dd0d:	mov    $0x1004662,%eax
 101dd12:	cmove  %rax,%rsi
 101dd16:	mov    -0x48(%rbp),%edi
 101dd19:	mov    $0xb0000,%edx
 101dd1e:	xor    %eax,%eax
 101dd20:	call   10279b0 <openat@plt>
 101dd25:	test   %eax,%eax
 101dd27:	js     101e094 <acquire+0x8d4>
 101dd2d:	mov    %eax,%r14d
 101dd30:	mov    %eax,%edi
 101dd32:	call   10279f0 <fdopendir@plt>
 101dd37:	mov    %rax,-0x80(%rbp)
 101dd3b:	test   %rax,%rax
 101dd3e:	mov    -0x60(%rbp),%r13
 101dd42:	je     101e1f7 <acquire+0xa37>
 101dd48:	mov    $0x400,%edi
 101dd4d:	call   1027680 <malloc@plt>
 101dd52:	test   %rax,%rax
 101dd55:	je     101e2da <acquire+0xb1a>
 101dd5b:	mov    %rax,%r14
 101dd5e:	movb   $0x1,(%rax)
 101dd61:	mov    $0x1,%r13d
 101dd67:	mov    $0x400,%eax
 101dd6c:	mov    %rax,-0xa0(%rbp)
 101dd73:	call   1027980 <__errno_location@plt>
 101dd78:	mov    %rax,-0x58(%rbp)
 101dd7c:	movq   $0x0,-0xa8(%rbp)
 101dd87:	mov    %r13,-0x90(%rbp)
 101dd8e:	mov    -0x60(%rbp),%r13
 101dd92:	mov    -0x58(%rbp),%rax
 101dd96:	movl   $0x0,(%rax)
 101dd9c:	mov    -0x80(%rbp),%rdi
 101dda0:	call   1027a00 <readdir@plt>
 101dda5:	test   %rax,%rax
 101dda8:	je     101e2e3 <acquire+0xb23>
 101ddae:	cmpb   $0x2e,0x13(%rax)
 101ddb2:	jne    101ddc7 <acquire+0x607>
 101ddb4:	movzbl 0x14(%rax),%ecx
 101ddb8:	test   %ecx,%ecx
 101ddba:	je     101dd92 <acquire+0x5d2>
 101ddbc:	cmp    $0x2e,%ecx
 101ddbf:	jne    101ddc7 <acquire+0x607>
 101ddc1:	cmpb   $0x0,0x15(%rax)
 101ddc5:	je     101dd92 <acquire+0x5d2>
 101ddc7:	add    $0x13,%rax
 101ddcb:	mov    %rax,-0x88(%rbp)
 101ddd2:	mov    %rax,%rdi
 101ddd5:	call   1027670 <strlen@plt>
 101ddda:	mov    -0x90(%rbp),%rdx
 101dde1:	cmp    $0x10000,%rdx
 101dde8:	ja     101e477 <acquire+0xcb7>
 101ddee:	cmpq   $0xff,-0xa8(%rbp)
 101ddf9:	ja     101e477 <acquire+0xcb7>
 101ddff:	lea    -0xfff(%rax),%rcx
 101de06:	cmp    $0xfffffffffffff002,%rcx
 101de0d:	jb     101e477 <acquire+0xcb7>
 101de13:	lea    0x3(%rax),%rsi
 101de17:	mov    $0x10000,%ecx
 101de1c:	sub    %rdx,%rcx
 101de1f:	cmp    %rcx,%rsi
 101de22:	ja     101e477 <acquire+0xcb7>
 101de28:	lea    0x3(%rdx),%rcx
 101de2c:	mov    %rcx,-0xb8(%rbp)
 101de33:	mov    %rax,-0xc0(%rbp)
 101de3a:	add    %rdx,%rax
 101de3d:	add    $0x3,%rax
 101de41:	mov    %rax,-0x70(%rbp)
 101de45:	mov    %r14,%rax
 101de48:	mov    -0xa0(%rbp),%r13
 101de4f:	mov    %rax,%r14
 101de52:	cmp    %r13,-0x70(%rbp)
 101de56:	jbe    101de70 <acquire+0x6b0>
 101de58:	add    %r13,%r13
 101de5b:	mov    %r14,%rdi
 101de5e:	mov    %r13,%rsi
 101de61:	call   10277f0 <realloc@plt>
 101de66:	test   %rax,%rax
 101de69:	jne    101de4f <acquire+0x68f>
 101de6b:	jmp    101e2ff <acquire+0xb3f>
 101de70:	mov    %r13,-0xa0(%rbp)
 101de77:	mov    -0x80(%rbp),%rdi
 101de7b:	call   1027a10 <dirfd@plt>
 101de80:	mov    %eax,%edi
 101de82:	mov    -0x88(%rbp),%rsi
 101de89:	lea    -0x170(%rbp),%rdx
 101de90:	mov    $0x100,%ecx
 101de95:	call   10279d0 <fstatat@plt>
 101de9a:	test   %eax,%eax
 101de9c:	je     101dede <acquire+0x71e>
 101de9e:	xor    %eax,%eax
 101dea0:	mov    -0x88(%rbp),%rsi
 101dea7:	mov    -0x70(%rbp),%r13
 101deab:	mov    -0x90(%rbp),%rcx
 101deb2:	mov    %al,(%r14,%rcx,1)
 101deb6:	mov    -0xc0(%rbp),%rdx
 101debd:	mov    %dx,0x1(%r14,%rcx,1)
 101dec3:	mov    -0xb8(%rbp),%rdi
 101deca:	add    %r14,%rdi
 101decd:	call   10276a0 <memcpy@plt>
 101ded2:	incq   -0xa8(%rbp)
 101ded9:	jmp    101dd87 <acquire+0x5c7>
 101dede:	mov    -0x158(%rbp),%eax
 101dee4:	mov    $0xf000,%ecx
 101dee9:	and    %ecx,%eax
 101deeb:	cmp    $0xa000,%eax
 101def0:	mov    -0x70(%rbp),%r13
 101def4:	je     101df13 <acquire+0x753>
 101def6:	cmp    $0x8000,%eax
 101defb:	mov    -0x88(%rbp),%rsi
 101df02:	je     101df0f <acquire+0x74f>
 101df04:	cmp    $0x4000,%eax
 101df09:	jne    101df1e <acquire+0x75e>
 101df0b:	mov    $0x2,%al
 101df0d:	jmp    101deab <acquire+0x6eb>
 101df0f:	mov    $0x1,%al
 101df11:	jmp    101deab <acquire+0x6eb>
 101df13:	mov    $0x3,%al
 101df15:	mov    -0x88(%rbp),%rsi
 101df1c:	jmp    101deab <acquire+0x6eb>
 101df1e:	xor    %eax,%eax
 101df20:	jmp    101deab <acquire+0x6eb>
 101df22:	xor    %edx,%edx
 101df24:	cmpl   $0x0,-0x80(%rbp)
 101df28:	sete   %dl
 101df2b:	shl    $0xb,%edx
 101df2e:	mov    -0xb0(%rbp),%rax
 101df35:	cmp    $0x61,%eax
 101df38:	je     101e0e8 <acquire+0x928>
 101df3e:	cmp    $0x63,%eax
 101df41:	mov    -0x60(%rbp),%r13
 101df45:	mov    -0x78(%rbp),%r14
 101df49:	jne    101e10e <acquire+0x94e>
 101df4f:	or     $0x800c1,%edx
 101df55:	mov    -0x48(%rbp),%edi
 101df58:	lea    -0x1170(%rbp),%rsi
 101df5f:	mov    $0x1b6,%ecx
 101df64:	xor    %eax,%eax
 101df66:	call   10279b0 <openat@plt>
 101df6b:	jmp    101e136 <acquire+0x976>
 101df70:	mov    -0x48(%rbp),%edi
 101df73:	lea    -0x170(%rbp),%rsi
 101df7a:	call   1027a20 <fstat@plt>
 101df7f:	test   %eax,%eax
 101df81:	jne    101db68 <acquire+0x3a8>
 101df87:	mov    $0xa,%edi
 101df8c:	call   1027680 <malloc@plt>
 101df91:	test   %rax,%rax
 101df94:	je     101e0dd <acquire+0x91d>
 101df9a:	mov    %rax,%r14
 101df9d:	movb   $0x1,(%rax)
 101dfa0:	mov    -0x158(%rbp),%eax
 101dfa6:	mov    $0xf000,%ecx
 101dfab:	and    %ecx,%eax
 101dfad:	cmp    $0xa000,%eax
 101dfb2:	je     101e383 <acquire+0xbc3>
 101dfb8:	cmp    $0x8000,%eax
 101dfbd:	mov    -0x38(%rbp),%rdx
 101dfc1:	je     101e37f <acquire+0xbbf>
 101dfc7:	cmp    $0x4000,%eax
 101dfcc:	jne    101e38b <acquire+0xbcb>
 101dfd2:	mov    $0x2,%al
 101dfd4:	jmp    101e38d <acquire+0xbcd>
 101dfd9:	mov    -0x48(%rbp),%edi
 101dfdc:	lea    -0x1170(%rbp),%rsi
 101dfe3:	xor    %edx,%edx
 101dfe5:	call   1027a30 <unlinkat@plt>
 101dfea:	test   %eax,%eax
 101dfec:	je     101e072 <acquire+0x8b2>
 101dff2:	call   1027980 <__errno_location@plt>
 101dff7:	mov    (%rax),%ecx
 101dff9:	cmp    $0x28,%rcx
 101dffd:	mov    -0x38(%rbp),%rdx
 101e001:	ja     101e3d1 <acquire+0xc11>
 101e007:	movabs $0x10000102000,%rsi
 101e011:	bt     %rcx,%rsi
 101e015:	jb     101e1e7 <acquire+0xa27>
 101e01b:	mov    $0x200002,%esi
 101e020:	bt     %rcx,%rsi
 101e024:	jae    101e3c7 <acquire+0xc07>
 101e02a:	mov    %rax,%r14
 101e02d:	mov    -0x48(%rbp),%edi
 101e030:	lea    -0x1170(%rbp),%rsi
 101e037:	mov    $0x200,%edx
 101e03c:	call   1027a30 <unlinkat@plt>
 101e041:	test   %eax,%eax
 101e043:	je     101e072 <acquire+0x8b2>
 101e045:	mov    (%r14),%eax
 101e048:	cmp    $0x28,%rax
 101e04c:	mov    -0x38(%rbp),%rdx
 101e050:	ja     101e3d1 <acquire+0xc11>
 101e056:	movabs $0x10000102002,%rcx
 101e060:	bt     %rax,%rcx
 101e064:	mov    $0x2,%r9d
 101e06a:	jb     101e3d7 <acquire+0xc17>
 101e070:	jmp    101e0c8 <acquire+0x908>
 101e072:	mov    $0x1,%edi
 101e077:	call   1027680 <malloc@plt>
 101e07c:	test   %rax,%rax
 101e07f:	je     101e0dd <acquire+0x91d>
 101e081:	mov    %rax,%r14
 101e084:	movb   $0x1,(%rax)
 101e087:	mov    $0x1,%ecx
 101e08c:	xor    %r9d,%r9d
 101e08f:	jmp    101e234 <acquire+0xa74>
 101e094:	call   1027980 <__errno_location@plt>
 101e099:	mov    (%rax),%eax
 101e09b:	cmp    $0x28,%rax
 101e09f:	mov    -0x60(%rbp),%r13
 101e0a3:	mov    -0x38(%rbp),%rdx
 101e0a7:	ja     101e3d1 <acquire+0xc11>
 101e0ad:	movabs $0x10000102002,%rcx
 101e0b7:	bt     %rax,%rcx
 101e0bb:	jae    101e0c8 <acquire+0x908>
 101e0bd:	mov    $0x2,%r9d
 101e0c3:	jmp    101e3d7 <acquire+0xc17>
 101e0c8:	cmp    $0xc,%rax
 101e0cc:	jne    101e3d1 <acquire+0xc11>
 101e0d2:	mov    $0x4,%r9d
 101e0d8:	jmp    101e3d7 <acquire+0xc17>
 101e0dd:	mov    $0x4,%r9d
 101e0e3:	jmp    101e22f <acquire+0xa6f>
 101e0e8:	or     $0x80041,%edx
 101e0ee:	mov    -0x48(%rbp),%edi
 101e0f1:	lea    -0x1170(%rbp),%rsi
 101e0f8:	mov    $0x1b6,%ecx
 101e0fd:	xor    %eax,%eax
 101e0ff:	call   10279b0 <openat@plt>
 101e104:	mov    -0x60(%rbp),%r13
 101e108:	mov    -0x78(%rbp),%r14
 101e10c:	jmp    101e136 <acquire+0x976>
 101e10e:	cmpl   $0x0,-0x80(%rbp)
 101e112:	mov    $0xa0800,%edx
 101e117:	mov    $0x80000,%eax
 101e11c:	cmovne %eax,%edx
 101e11f:	add    -0x94(%rbp),%edx
 101e125:	mov    -0x48(%rbp),%edi
 101e128:	lea    -0x1170(%rbp),%rsi
 101e12f:	xor    %eax,%eax
 101e131:	call   10279b0 <openat@plt>
 101e136:	mov    -0x48(%rbp),%edi
 101e139:	cmp    -0x4c(%rbp),%edi
 101e13c:	mov    %eax,-0x70(%rbp)
 101e13f:	je     101e149 <acquire+0x989>
 101e141:	call   10277c0 <close@plt>
 101e146:	mov    -0x70(%rbp),%eax
 101e149:	test   %eax,%eax
 101e14b:	js     101e1a5 <acquire+0x9e5>
 101e14d:	mov    %eax,%edi
 101e14f:	lea    -0x170(%rbp),%rsi
 101e156:	call   1027a20 <fstat@plt>
 101e15b:	test   %eax,%eax
 101e15d:	je     101e23d <acquire+0xa7d>
 101e163:	call   1027980 <__errno_location@plt>
 101e168:	mov    (%rax),%eax
 101e16a:	cmp    $0x28,%rax
 101e16e:	mov    -0x3c(%rbp),%r12d
 101e172:	mov    -0x70(%rbp),%edi
 101e175:	ja     101e375 <acquire+0xbb5>
 101e17b:	movabs $0x10000102002,%rcx
 101e185:	bt     %rax,%rcx
 101e189:	jae    101e366 <acquire+0xba6>
 101e18f:	mov    $0x2,%ecx
 101e194:	mov    %ecx,%ebx
 101e196:	call   10277c0 <close@plt>
 101e19b:	mov    %ebx,%r9d
 101e19e:	xor    %ebx,%ebx
 101e1a0:	jmp    101e3be <acquire+0xbfe>
 101e1a5:	call   1027980 <__errno_location@plt>
 101e1aa:	mov    (%rax),%eax
 101e1ac:	cmp    $0x28,%rax
 101e1b0:	mov    -0x3c(%rbp),%r12d
 101e1b4:	mov    -0x38(%rbp),%rdx
 101e1b8:	ja     101dbf7 <acquire+0x437>
 101e1be:	mov    $0x2,%r9d
 101e1c4:	movabs $0x10000102002,%rcx
 101e1ce:	bt     %rax,%rcx
 101e1d2:	jb     101d8ca <acquire+0x10a>
 101e1d8:	cmp    $0xc,%rax
 101e1dc:	jne    101dbf7 <acquire+0x437>
 101e1e2:	jmp    101e4a0 <acquire+0xce0>
 101e1e7:	xor    %ecx,%ecx
 101e1e9:	xor    %r14d,%r14d
 101e1ec:	mov    $0x2,%r9d
 101e1f2:	jmp    101e3dc <acquire+0xc1c>
 101e1f7:	call   1027980 <__errno_location@plt>
 101e1fc:	mov    (%rax),%eax
 101e1fe:	cmp    $0x28,%rax
 101e202:	ja     101e46d <acquire+0xcad>
 101e208:	movabs $0x10000102002,%rcx
 101e212:	bt     %rax,%rcx
 101e216:	jae    101e45e <acquire+0xc9e>
 101e21c:	mov    $0x2,%ecx
 101e221:	mov    %r14d,%edi
 101e224:	mov    %ecx,%r14d
 101e227:	call   10277c0 <close@plt>
 101e22c:	mov    %r14d,%r9d
 101e22f:	xor    %ecx,%ecx
 101e231:	xor    %r14d,%r14d
 101e234:	mov    -0x38(%rbp),%rdx
 101e238:	jmp    101e3dc <acquire+0xc1c>
 101e23d:	mov    -0x158(%rbp),%r14d
 101e244:	mov    -0x80(%rbp),%edi
 101e247:	mov    -0x70(%rbp),%esi
 101e24a:	mov    %r14d,%edx
 101e24d:	call   101e4b0 <usable>
 101e252:	test   %eax,%eax
 101e254:	je     101e3a6 <acquire+0xbe6>
 101e25a:	cmpb   $0x74,-0x29(%rbp)
 101e25e:	sete   %al
 101e261:	and    $0xf000,%r14d
 101e268:	cmp    $0x8000,%r14d
 101e26f:	sete   %cl
 101e272:	and    %al,%cl
 101e274:	cmp    $0x1,%cl
 101e277:	jne    101e32d <acquire+0xb6d>
 101e27d:	mov    -0x70(%rbp),%edi
 101e280:	xor    %esi,%esi
 101e282:	call   1027a40 <ftruncate@plt>
 101e287:	test   %eax,%eax
 101e289:	je     101e32d <acquire+0xb6d>
 101e28f:	call   1027980 <__errno_location@plt>
 101e294:	mov    (%rax),%eax
 101e296:	cmp    $0x28,%rax
 101e29a:	mov    -0x78(%rbp),%r14
 101e29e:	mov    -0x3c(%rbp),%r12d
 101e2a2:	mov    -0x70(%rbp),%edi
 101e2a5:	ja     101e494 <acquire+0xcd4>
 101e2ab:	movabs $0x10000102002,%rcx
 101e2b5:	bt     %rax,%rcx
 101e2b9:	jae    101e483 <acquire+0xcc3>
 101e2bf:	movl   $0x2,-0x58(%rbp)
 101e2c6:	call   10277c0 <close@plt>
 101e2cb:	xor    %ebx,%ebx
 101e2cd:	mov    -0x38(%rbp),%rdx
 101e2d1:	mov    -0x58(%rbp),%r9d
 101e2d5:	jmp    101e44f <acquire+0xc8f>
 101e2da:	movl   $0x4,-0x58(%rbp)
 101e2e1:	jmp    101e312 <acquire+0xb52>
 101e2e3:	mov    -0x80(%rbp),%rdi
 101e2e7:	call   1027a50 <closedir@plt>
 101e2ec:	xor    %r9d,%r9d
 101e2ef:	mov    -0x38(%rbp),%rdx
 101e2f3:	mov    -0x90(%rbp),%rcx
 101e2fa:	jmp    101e3dc <acquire+0xc1c>
 101e2ff:	movl   $0x4,-0x58(%rbp)
 101e306:	mov    -0x60(%rbp),%r13
 101e30a:	mov    %r14,%rdi
 101e30d:	call   10276f0 <free@plt>
 101e312:	mov    -0x80(%rbp),%rdi
 101e316:	call   1027a50 <closedir@plt>
 101e31b:	xor    %ecx,%ecx
 101e31d:	xor    %r14d,%r14d
 101e320:	mov    -0x38(%rbp),%rdx
 101e324:	mov    -0x58(%rbp),%r9d
 101e328:	jmp    101e3dc <acquire+0xc1c>
 101e32d:	mov    -0x70(%rbp),%eax
 101e330:	mov    %eax,(%r12)
 101e334:	vxorps %xmm0,%xmm0,%xmm0
 101e338:	vmovups %xmm0,0x4(%r12)
 101e33f:	vmovups %xmm0,0x10(%r12)
 101e346:	movzbl -0x29(%rbp),%eax
 101e34a:	mov    %al,0x20(%r12)
 101e34f:	movl   $0x0,0x21(%r12)
 101e358:	movl   $0x0,0x24(%r12)
 101e361:	xor    %r9d,%r9d
 101e364:	jmp    101e3b6 <acquire+0xbf6>
 101e366:	mov    $0x4,%ecx
 101e36b:	cmp    $0xc,%rax
 101e36f:	je     101e194 <acquire+0x9d4>
 101e375:	mov    $0x3,%ecx
 101e37a:	jmp    101e194 <acquire+0x9d4>
 101e37f:	mov    $0x1,%al
 101e381:	jmp    101e38d <acquire+0xbcd>
 101e383:	mov    $0x3,%al
 101e385:	mov    -0x38(%rbp),%rdx
 101e389:	jmp    101e38d <acquire+0xbcd>
 101e38b:	xor    %eax,%eax
 101e38d:	mov    %al,0x1(%r14)
 101e391:	mov    -0x140(%rbp),%rax
 101e398:	mov    %rax,0x2(%r14)
 101e39c:	mov    $0xa,%ecx
 101e3a1:	xor    %r9d,%r9d
 101e3a4:	jmp    101e3dc <acquire+0xc1c>
 101e3a6:	mov    -0x70(%rbp),%edi
 101e3a9:	call   10277c0 <close@plt>
 101e3ae:	mov    $0x2,%r9d
 101e3b4:	xor    %ebx,%ebx
 101e3b6:	mov    -0x78(%rbp),%r14
 101e3ba:	mov    -0x3c(%rbp),%r12d
 101e3be:	mov    -0x38(%rbp),%rdx
 101e3c2:	jmp    101e44f <acquire+0xc8f>
 101e3c7:	cmp    $0xc,%rcx
 101e3cb:	je     101e0d2 <acquire+0x912>
 101e3d1:	mov    $0x3,%r9d
 101e3d7:	xor    %ecx,%ecx
 101e3d9:	xor    %r14d,%r14d
 101e3dc:	mov    -0x48(%rbp),%edi
 101e3df:	cmp    -0x4c(%rbp),%edi
 101e3e2:	je     101e407 <acquire+0xc47>
 101e3e4:	mov    %r14,-0x48(%rbp)
 101e3e8:	mov    %r9d,%r14d
 101e3eb:	mov    %rcx,%r15
 101e3ee:	call   10277c0 <close@plt>
 101e3f3:	mov    %r15,%rcx
 101e3f6:	mov    %r14d,%r9d
 101e3f9:	mov    -0x48(%rbp),%r14
 101e3fd:	mov    $0xc80405,%r15d
 101e403:	mov    -0x38(%rbp),%rdx
 101e407:	test   %r14,%r14
 101e40a:	je     101e445 <acquire+0xc85>
 101e40c:	mov    $0xffffffff,%eax
 101e411:	mov    %rax,(%r12)
 101e415:	mov    %r14,0x8(%r12)
 101e41a:	mov    %rcx,0x10(%r12)
 101e41f:	movq   $0x0,0x18(%r12)
 101e428:	movzbl -0x29(%rbp),%eax
 101e42c:	mov    %al,0x20(%r12)
 101e431:	movl   $0x0,0x21(%r12)
 101e43a:	movl   $0x0,0x24(%r12)
 101e443:	jmp    101e447 <acquire+0xc87>
 101e445:	xor    %ebx,%ebx
 101e447:	mov    -0x78(%rbp),%r14
 101e44b:	mov    -0x3c(%rbp),%r12d
 101e44f:	test   $0x3,%r9b
 101e453:	jne    101d8ca <acquire+0x10a>
 101e459:	jmp    101d837 <acquire+0x77>
 101e45e:	mov    $0x4,%ecx
 101e463:	cmp    $0xc,%rax
 101e467:	je     101e221 <acquire+0xa61>
 101e46d:	mov    $0x3,%ecx
 101e472:	jmp    101e221 <acquire+0xa61>
 101e477:	movl   $0x2,-0x58(%rbp)
 101e47e:	jmp    101e30a <acquire+0xb4a>
 101e483:	movl   $0x4,-0x58(%rbp)
 101e48a:	cmp    $0xc,%rax
 101e48e:	je     101e2c6 <acquire+0xb06>
 101e494:	movl   $0x3,-0x58(%rbp)
 101e49b:	jmp    101e2c6 <acquire+0xb06>
 101e4a0:	mov    $0x4,%r9d
 101e4a6:	jmp    101d835 <acquire+0x75>
 101e4ab:	int3
 101e4ac:	int3
 101e4ad:	int3
 101e4ae:	int3
 101e4af:	int3

000000000101e4b0 <usable>:
 101e4b0:	and    $0xf000,%edx
 101e4b6:	test   %edi,%edi
 101e4b8:	je     101e4c7 <usable+0x17>
 101e4ba:	cmp    $0x4000,%edx
 101e4c0:	setne  %al
 101e4c3:	movzbl %al,%eax
 101e4c6:	ret
 101e4c7:	cmp    $0x8000,%edx
 101e4cd:	jne    101e509 <usable+0x59>
 101e4cf:	push   %rbp
 101e4d0:	mov    %rsp,%rbp
 101e4d3:	push   %rbx
 101e4d4:	push   %rax
 101e4d5:	mov    %esi,%edi
 101e4d7:	mov    %esi,%ebx
 101e4d9:	mov    $0x3,%esi
 101e4de:	xor    %eax,%eax
 101e4e0:	call   1027a60 <fcntl@plt>
 101e4e5:	and    $0xfffff7ff,%eax
 101e4ea:	mov    %ebx,%edi
 101e4ec:	mov    $0x4,%esi
 101e4f1:	mov    %eax,%edx
 101e4f3:	xor    %eax,%eax
 101e4f5:	call   1027a60 <fcntl@plt>
 101e4fa:	test   %eax,%eax
 101e4fc:	sete   %al
 101e4ff:	add    $0x8,%rsp
 101e503:	pop    %rbx
 101e504:	pop    %rbp
 101e505:	movzbl %al,%eax
 101e508:	ret
 101e509:	xor    %eax,%eax
 101e50b:	movzbl %al,%eax
 101e50e:	ret

000000000101e50f <entry_release>:
 101e50f:	push   %rbp
 101e510:	mov    %rsp,%rbp
 101e513:	mov    $0x28,%edx
 101e518:	pop    %rbp
 101e519:	jmp    10189e0 <myl_rc_meta_free>
 101e51e:	int3
 101e51f:	int3

000000000101e520 <myl_rc_scope_unwind>:
 101e520:	push   %rbp
 101e521:	mov    %rsp,%rbp
 101e524:	push   %r15
 101e526:	push   %r14
 101e528:	push   %r13
 101e52a:	push   %r12
 101e52c:	push   %rbx
 101e52d:	push   %rax
 101e52e:	mov    %rsi,%rbx
 101e531:	test   %rdi,%rdi
 101e534:	je     101e5b5 <myl_rc_scope_unwind+0x95>
 101e536:	mov    %rdi,%r12
 101e539:	mov    0x1608(%rdi),%rax
 101e540:	test   %rax,%rax
 101e543:	je     101e5b5 <myl_rc_scope_unwind+0x95>
 101e545:	mov    0xf8(%rax),%rdi
 101e54c:	cmp    %rbx,%rdi
 101e54f:	je     101e5be <myl_rc_scope_unwind+0x9e>
 101e551:	movabs $0xeffffffffffffffd,%r14
 101e55b:	mov    %rdi,%rax
 101e55e:	jmp    101e569 <myl_rc_scope_unwind+0x49>
 101e560:	mov    0x8(%rax),%rax
 101e564:	cmp    %rbx,%rax
 101e567:	je     101e5cd <myl_rc_scope_unwind+0xad>
 101e569:	test   %rax,%rax
 101e56c:	je     101e815 <myl_rc_scope_unwind+0x2f5>
 101e572:	mov    0x10(%rax),%rcx
 101e576:	jmp    101e58a <myl_rc_scope_unwind+0x6a>
 101e578:	nopl   0x0(%rax,%rax,1)
 101e580:	movl   $0x0,0x18(%rcx)
 101e587:	mov    (%rcx),%rcx
 101e58a:	test   %rcx,%rcx
 101e58d:	je     101e560 <myl_rc_scope_unwind+0x40>
 101e58f:	cmpl   $0x0,0x18(%rcx)
 101e593:	je     101e580 <myl_rc_scope_unwind+0x60>
 101e595:	mov    0x8(%rcx),%rdx
 101e599:	test   %rdx,%rdx
 101e59c:	je     101e580 <myl_rc_scope_unwind+0x60>
 101e59e:	mov    -0x10(%rdx),%rsi
 101e5a2:	test   $0x2,%sil
 101e5a6:	jne    101e580 <myl_rc_scope_unwind+0x60>
 101e5a8:	and    %r14,%rsi
 101e5ab:	or     0x10(%rcx),%rsi
 101e5af:	mov    %rsi,-0x10(%rdx)
 101e5b3:	jmp    101e580 <myl_rc_scope_unwind+0x60>
 101e5b5:	test   %rbx,%rbx
 101e5b8:	jne    101e815 <myl_rc_scope_unwind+0x2f5>
 101e5be:	add    $0x8,%rsp
 101e5c2:	pop    %rbx
 101e5c3:	pop    %r12
 101e5c5:	pop    %r13
 101e5c7:	pop    %r14
 101e5c9:	pop    %r15
 101e5cb:	pop    %rbp
 101e5cc:	ret
 101e5cd:	mov    %r12,-0x30(%rbp)
 101e5d1:	jmp    101e5f4 <myl_rc_scope_unwind+0xd4>
 101e5d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101e5e0:	mov    0x1608(%r12),%rax
 101e5e8:	mov    0xf8(%rax),%rdi
 101e5ef:	cmp    %rbx,%rdi
 101e5f2:	je     101e5be <myl_rc_scope_unwind+0x9e>
 101e5f4:	test   %rdi,%rdi
 101e5f7:	je     101e815 <myl_rc_scope_unwind+0x2f5>
 101e5fd:	cmpl   $0x0,0x18(%rdi)
 101e601:	je     101e5e0 <myl_rc_scope_unwind+0xc0>
 101e603:	mov    (%rdi),%r15
 101e606:	test   %r15,%r15
 101e609:	je     101e815 <myl_rc_scope_unwind+0x2f5>
 101e60f:	mov    0x1608(%r15),%rax
 101e616:	test   %rax,%rax
 101e619:	je     101e815 <myl_rc_scope_unwind+0x2f5>
 101e61f:	cmp    %rdi,0xf8(%rax)
 101e626:	jne    101e815 <myl_rc_scope_unwind+0x2f5>
 101e62c:	mov    0x8(%rdi),%rcx
 101e630:	mov    %rcx,0xf8(%rax)
 101e637:	movl   $0x0,0x18(%rdi)
 101e63e:	movq   $0x0,0x8(%rdi)
 101e646:	mov    0x10(%rdi),%rsi
 101e64a:	test   %rsi,%rsi
 101e64d:	je     101e7ad <myl_rc_scope_unwind+0x28d>
 101e653:	cmpq   $0x0,(%rsi)
 101e657:	jne    101e7cf <myl_rc_scope_unwind+0x2af>
 101e65d:	cmpl   $0x0,0x18(%rsi)
 101e661:	mov    0x8(%rsi),%r12
 101e665:	je     101e687 <myl_rc_scope_unwind+0x167>
 101e667:	test   %r12,%r12
 101e66a:	je     101e684 <myl_rc_scope_unwind+0x164>
 101e66c:	mov    -0x10(%r12),%rcx
 101e671:	test   $0x2,%cl
 101e674:	jne    101e687 <myl_rc_scope_unwind+0x167>
 101e676:	and    %r14,%rcx
 101e679:	or     0x10(%rsi),%rcx
 101e67d:	mov    %rcx,-0x10(%r12)
 101e682:	jmp    101e687 <myl_rc_scope_unwind+0x167>
 101e684:	xor    %r12d,%r12d
 101e687:	movq   $0x0,0x10(%rdi)
 101e68f:	mov    0x20(%rsi),%r13
 101e693:	mov    0x108(%rax),%rcx
 101e69a:	cmp    $0x20,%rcx
 101e69e:	je     101e7d6 <myl_rc_scope_unwind+0x2b6>
 101e6a4:	mov    0x18(%r15),%rdx
 101e6a8:	cmp    $0x28,%rdx
 101e6ac:	jb     101e815 <myl_rc_scope_unwind+0x2f5>
 101e6b2:	mov    0x30(%rax),%rdi
 101e6b6:	cmp    $0x27,%rdi
 101e6ba:	jbe    101e815 <myl_rc_scope_unwind+0x2f5>
 101e6c0:	add    $0xffffffffffffffd8,%rdx
 101e6c4:	mov    %rdx,0x18(%r15)
 101e6c8:	add    $0xffffffffffffffd8,%rdi
 101e6cc:	mov    %rdi,0x30(%rax)
 101e6d0:	mov    0x100(%rax),%rdx
 101e6d7:	mov    %rdx,(%rsi)
 101e6da:	mov    %rsi,0x100(%rax)
 101e6e1:	inc    %rcx
 101e6e4:	mov    %rcx,0x108(%rax)
 101e6eb:	test   %r13,%r13
 101e6ee:	je     101e749 <myl_rc_scope_unwind+0x229>
 101e6f0:	mov    -0x10(%r13),%rcx
 101e6f4:	movabs $0x4000000000000002,%rax
 101e6fe:	test   %rax,%rcx
 101e701:	jne    101e730 <myl_rc_scope_unwind+0x210>
 101e703:	mov    -0x18(%r13),%rax
 101e707:	test   %rax,%rax
 101e70a:	je     101e815 <myl_rc_scope_unwind+0x2f5>
 101e710:	and    $0x1,%ecx
 101e713:	jne    101e815 <myl_rc_scope_unwind+0x2f5>
 101e719:	dec    %rax
 101e71c:	mov    %rax,-0x18(%r13)
 101e720:	jne    101e730 <myl_rc_scope_unwind+0x210>
 101e722:	cmpq   $0x0,-0x20(%r13)
 101e727:	je     101e7ec <myl_rc_scope_unwind+0x2cc>
 101e72d:	nopl   (%rax)
 101e730:	mov    0x1608(%r15),%rax
 101e737:	cmpq   $0x0,0xc8(%rax)
 101e73f:	je     101e749 <myl_rc_scope_unwind+0x229>
 101e741:	mov    %r15,%rdi
 101e744:	call   101be30 <myl_rc_drain>
 101e749:	test   %r12,%r12
 101e74c:	je     101e790 <myl_rc_scope_unwind+0x270>
 101e74e:	mov    -0x10(%r12),%rcx
 101e753:	movabs $0x4000000000000002,%rax
 101e75d:	test   %rax,%rcx
 101e760:	jne    101e790 <myl_rc_scope_unwind+0x270>
 101e762:	mov    -0x18(%r12),%rax
 101e767:	test   %rax,%rax
 101e76a:	je     101e815 <myl_rc_scope_unwind+0x2f5>
 101e770:	and    $0x1,%ecx
 101e773:	jne    101e815 <myl_rc_scope_unwind+0x2f5>
 101e779:	dec    %rax
 101e77c:	mov    %rax,-0x18(%r12)
 101e781:	jne    101e790 <myl_rc_scope_unwind+0x270>
 101e783:	cmpq   $0x0,-0x20(%r12)
 101e789:	je     101e800 <myl_rc_scope_unwind+0x2e0>
 101e78b:	nopl   0x0(%rax,%rax,1)
 101e790:	mov    0x1608(%r15),%rax
 101e797:	cmpq   $0x0,0xc8(%rax)
 101e79f:	mov    -0x30(%rbp),%r12
 101e7a3:	je     101e7ad <myl_rc_scope_unwind+0x28d>
 101e7a5:	mov    %r15,%rdi
 101e7a8:	call   101be30 <myl_rc_drain>
 101e7ad:	mov    0x1608(%r15),%rax
 101e7b4:	cmpq   $0x0,0xc8(%rax)
 101e7bc:	je     101e5e0 <myl_rc_scope_unwind+0xc0>
 101e7c2:	mov    %r15,%rdi
 101e7c5:	call   101be30 <myl_rc_drain>
 101e7ca:	jmp    101e5e0 <myl_rc_scope_unwind+0xc0>
 101e7cf:	call   101e820 <unwind_many>
 101e7d4:	jmp    101e7ad <myl_rc_scope_unwind+0x28d>
 101e7d6:	mov    %r15,%rdi
 101e7d9:	call   101e50f <entry_release>
 101e7de:	test   %r13,%r13
 101e7e1:	jne    101e6f0 <myl_rc_scope_unwind+0x1d0>
 101e7e7:	jmp    101e749 <myl_rc_scope_unwind+0x229>
 101e7ec:	add    $0xffffffffffffffe0,%r13
 101e7f0:	mov    %r15,%rdi
 101e7f3:	mov    %r13,%rsi
 101e7f6:	call   101ea0a <hold_death>
 101e7fb:	jmp    101e749 <myl_rc_scope_unwind+0x229>
 101e800:	add    $0xffffffffffffffe0,%r12
 101e804:	mov    %r15,%rdi
 101e807:	mov    %r12,%rsi
 101e80a:	call   101ea0a <hold_death>
 101e80f:	mov    -0x30(%rbp),%r12
 101e813:	jmp    101e7ad <myl_rc_scope_unwind+0x28d>
 101e815:	call   1018954 <myl_rc_invariant_failed>
 101e81a:	int3
 101e81b:	int3
 101e81c:	int3
 101e81d:	int3
 101e81e:	int3
 101e81f:	int3

000000000101e820 <unwind_many>:
 101e820:	push   %rbp
 101e821:	mov    %rsp,%rbp
 101e824:	push   %r15
 101e826:	push   %r14
 101e828:	push   %r13
 101e82a:	push   %r12
 101e82c:	push   %rbx
 101e82d:	push   %rax
 101e82e:	mov    (%rdi),%rbx
 101e831:	mov    0x10(%rdi),%r12
 101e835:	test   %r12,%r12
 101e838:	je     101e87e <unwind_many+0x5e>
 101e83a:	movabs $0xeffffffffffffffd,%rax
 101e844:	mov    %r12,%rcx
 101e847:	jmp    101e858 <unwind_many+0x38>
 101e849:	nopl   0x0(%rax)
 101e850:	mov    (%rcx),%rcx
 101e853:	test   %rcx,%rcx
 101e856:	je     101e87e <unwind_many+0x5e>
 101e858:	cmpl   $0x0,0x18(%rcx)
 101e85c:	je     101e850 <unwind_many+0x30>
 101e85e:	mov    0x8(%rcx),%rdx
 101e862:	test   %rdx,%rdx
 101e865:	je     101e850 <unwind_many+0x30>
 101e867:	mov    -0x10(%rdx),%rsi
 101e86b:	test   $0x2,%sil
 101e86f:	jne    101e850 <unwind_many+0x30>
 101e871:	and    %rax,%rsi
 101e874:	or     0x10(%rcx),%rsi
 101e878:	mov    %rsi,-0x10(%rdx)
 101e87c:	jmp    101e850 <unwind_many+0x30>
 101e87e:	movabs $0x4000000000000002,%r13
 101e888:	movq   $0x0,0x10(%rdi)
 101e890:	jmp    101e8b9 <unwind_many+0x99>
 101e892:	add    $0xffffffffffffffe0,%r14
 101e896:	mov    %rbx,%rdi
 101e899:	mov    %r14,%rsi
 101e89c:	call   101ea0a <hold_death>
 101e8a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101e8b0:	test   %r12,%r12
 101e8b3:	je     101e9f6 <unwind_many+0x1d6>
 101e8b9:	mov    %r12,%rsi
 101e8bc:	mov    (%r12),%r12
 101e8c0:	mov    0x8(%rsi),%r14
 101e8c4:	mov    0x20(%rsi),%r15
 101e8c8:	mov    0x1608(%rbx),%rax
 101e8cf:	mov    0x108(%rax),%rcx
 101e8d6:	cmp    $0x20,%rcx
 101e8da:	je     101e9d2 <unwind_many+0x1b2>
 101e8e0:	mov    0x18(%rbx),%rdx
 101e8e4:	cmp    $0x28,%rdx
 101e8e8:	jb     101ea05 <unwind_many+0x1e5>
 101e8ee:	mov    0x30(%rax),%rdi
 101e8f2:	cmp    $0x27,%rdi
 101e8f6:	jbe    101ea05 <unwind_many+0x1e5>
 101e8fc:	add    $0xffffffffffffffd8,%rdx
 101e900:	mov    %rdx,0x18(%rbx)
 101e904:	add    $0xffffffffffffffd8,%rdi
 101e908:	mov    %rdi,0x30(%rax)
 101e90c:	mov    0x100(%rax),%rdx
 101e913:	mov    %rdx,(%rsi)
 101e916:	mov    %rsi,0x100(%rax)
 101e91d:	inc    %rcx
 101e920:	mov    %rcx,0x108(%rax)
 101e927:	test   %r15,%r15
 101e92a:	je     101e979 <unwind_many+0x159>
 101e92c:	mov    -0x10(%r15),%rcx
 101e930:	test   %r13,%rcx
 101e933:	jne    101e960 <unwind_many+0x140>
 101e935:	mov    -0x18(%r15),%rax
 101e939:	test   %rax,%rax
 101e93c:	je     101ea05 <unwind_many+0x1e5>
 101e942:	and    $0x1,%ecx
 101e945:	jne    101ea05 <unwind_many+0x1e5>
 101e94b:	dec    %rax
 101e94e:	mov    %rax,-0x18(%r15)
 101e952:	jne    101e960 <unwind_many+0x140>
 101e954:	cmpq   $0x0,-0x20(%r15)
 101e959:	je     101e9e5 <unwind_many+0x1c5>
 101e95f:	nop
 101e960:	mov    0x1608(%rbx),%rax
 101e967:	cmpq   $0x0,0xc8(%rax)
 101e96f:	je     101e979 <unwind_many+0x159>
 101e971:	mov    %rbx,%rdi
 101e974:	call   101be30 <myl_rc_drain>
 101e979:	test   %r14,%r14
 101e97c:	je     101e9b0 <unwind_many+0x190>
 101e97e:	mov    -0x10(%r14),%rcx
 101e982:	test   %r13,%rcx
 101e985:	jne    101e9b0 <unwind_many+0x190>
 101e987:	mov    -0x18(%r14),%rax
 101e98b:	test   %rax,%rax
 101e98e:	je     101ea05 <unwind_many+0x1e5>
 101e990:	and    $0x1,%ecx
 101e993:	jne    101ea05 <unwind_many+0x1e5>
 101e995:	dec    %rax
 101e998:	mov    %rax,-0x18(%r14)
 101e99c:	jne    101e9b0 <unwind_many+0x190>
 101e99e:	cmpq   $0x0,-0x20(%r14)
 101e9a3:	je     101e892 <unwind_many+0x72>
 101e9a9:	nopl   0x0(%rax)
 101e9b0:	mov    0x1608(%rbx),%rax
 101e9b7:	cmpq   $0x0,0xc8(%rax)
 101e9bf:	je     101e8b0 <unwind_many+0x90>
 101e9c5:	mov    %rbx,%rdi
 101e9c8:	call   101be30 <myl_rc_drain>
 101e9cd:	jmp    101e8b0 <unwind_many+0x90>
 101e9d2:	mov    %rbx,%rdi
 101e9d5:	call   101e50f <entry_release>
 101e9da:	test   %r15,%r15
 101e9dd:	jne    101e92c <unwind_many+0x10c>
 101e9e3:	jmp    101e979 <unwind_many+0x159>
 101e9e5:	add    $0xffffffffffffffe0,%r15
 101e9e9:	mov    %rbx,%rdi
 101e9ec:	mov    %r15,%rsi
 101e9ef:	call   101ea0a <hold_death>
 101e9f4:	jmp    101e979 <unwind_many+0x159>
 101e9f6:	add    $0x8,%rsp
 101e9fa:	pop    %rbx
 101e9fb:	pop    %r12
 101e9fd:	pop    %r13
 101e9ff:	pop    %r14
 101ea01:	pop    %r15
 101ea03:	pop    %rbp
 101ea04:	ret
 101ea05:	call   1018954 <myl_rc_invariant_failed>

000000000101ea0a <hold_death>:
 101ea0a:	push   %rbp
 101ea0b:	mov    %rsp,%rbp
 101ea0e:	push   %rbx
 101ea0f:	push   %rax
 101ea10:	mov    0x10(%rsi),%rax
 101ea14:	test   $0x1,%al
 101ea16:	jne    101eaf8 <hold_death+0xee>
 101ea1c:	mov    %rsi,%rcx
 101ea1f:	mov    %rdi,%rbx
 101ea22:	or     $0x1,%rax
 101ea26:	mov    %rax,0x10(%rsi)
 101ea2a:	mov    0x1608(%rdi),%rdi
 101ea31:	cmpl   $0x0,0xd0(%rdi)
 101ea38:	jne    101ea85 <hold_death+0x7b>
 101ea3a:	mov    0x18(%rcx),%rsi
 101ea3e:	cmp    %rsi,0x110(%rdi)
 101ea45:	je     101eaaf <hold_death+0xa5>
 101ea47:	mov    0x34(%rsi),%eax
 101ea4a:	cmp    %rax,0xa0(%rdi)
 101ea51:	jbe    101eaee <hold_death+0xe4>
 101ea57:	mov    0x98(%rdi),%rdx
 101ea5e:	shl    $0x4,%rax
 101ea62:	cmp    %rsi,(%rdx,%rax,1)
 101ea66:	jne    101eaee <hold_death+0xe4>
 101ea6c:	add    %rax,%rdx
 101ea6f:	mov    0x8(%rdx),%rax
 101ea73:	test   %rax,%rax
 101ea76:	je     101ea7e <hold_death+0x74>
 101ea78:	cmpl   $0x0,0x40(%rax)
 101ea7c:	je     101eaab <hold_death+0xa1>
 101ea7e:	mov    0x1608(%rbx),%rdi
 101ea85:	mov    0xc8(%rdi),%rax
 101ea8c:	mov    %rax,(%rcx)
 101ea8f:	mov    0x1608(%rbx),%rax
 101ea96:	mov    %rcx,0xc8(%rax)
 101ea9d:	mov    %rbx,%rdi
 101eaa0:	add    $0x8,%rsp
 101eaa4:	pop    %rbx
 101eaa5:	pop    %rbp
 101eaa6:	jmp    101be30 <myl_rc_drain>
 101eaab:	mov    0x10(%rcx),%rax
 101eaaf:	movabs $0x4000000000000003,%rdx
 101eab9:	and    %rax,%rdx
 101eabc:	cmp    $0x1,%rdx
 101eac0:	jne    101eaf8 <hold_death+0xee>
 101eac2:	mov    0x1608(%rbx),%rax
 101eac9:	add    $0x20,%rcx
 101eacd:	mov    %rbx,%rdi
 101ead0:	mov    %rcx,%rsi
 101ead3:	call   *0x8(%rax)
 101ead6:	mov    0x1608(%rbx),%rax
 101eadd:	cmpq   $0x0,0xc8(%rax)
 101eae5:	jne    101ea9d <hold_death+0x93>
 101eae7:	add    $0x8,%rsp
 101eaeb:	pop    %rbx
 101eaec:	pop    %rbp
 101eaed:	ret
 101eaee:	call   1018f74 <myl_rc_binding_find_slow>
 101eaf3:	jmp    101ea73 <hold_death+0x69>
 101eaf8:	call   1018954 <myl_rc_invariant_failed>
 101eafd:	int3
 101eafe:	int3
 101eaff:	int3

000000000101eb00 <transfer>:
 101eb00:	push   %rbp
 101eb01:	mov    %rsp,%rbp
 101eb04:	push   %r15
 101eb06:	push   %r14
 101eb08:	push   %r13
 101eb0a:	push   %r12
 101eb0c:	push   %rbx
 101eb0d:	sub    $0x218,%rsp
 101eb14:	test   %rdi,%rdi
 101eb17:	je     101ef01 <transfer+0x401>
 101eb1d:	mov    0x1608(%rdi),%r13
 101eb24:	test   %r13,%r13
 101eb27:	je     101ef01 <transfer+0x401>
 101eb2d:	mov    %rsi,%rbx
 101eb30:	mov    0x8(%rsi),%r15
 101eb34:	test   %r15,%r15
 101eb37:	je     101ef01 <transfer+0x401>
 101eb3d:	test   %rcx,%rcx
 101eb40:	je     101ef01 <transfer+0x401>
 101eb46:	movabs $0x9e3779b97f4a7c15,%r8
 101eb50:	mov    0x58(%r13),%rax
 101eb54:	mov    0x60(%r13),%rsi
 101eb58:	mov    0x70(%r13),%r9d
 101eb5c:	mov    %rdx,%r10
 101eb5f:	imul   %r8,%r10
 101eb63:	shrx   %r9,%r10,%r10
 101eb68:	and    %rsi,%r10
 101eb6b:	mov    %r10,%r11
 101eb6e:	shl    $0x4,%r11
 101eb72:	mov    (%rax,%r11,1),%r11
 101eb76:	cmp    %rdx,%r11
 101eb79:	je     101eb9b <transfer+0x9b>
 101eb7b:	xor    %r14d,%r14d
 101eb7e:	xchg   %ax,%ax
 101eb80:	test   %r11,%r11
 101eb83:	je     101eba4 <transfer+0xa4>
 101eb85:	inc    %r10
 101eb88:	and    %rsi,%r10
 101eb8b:	mov    %r10,%r11
 101eb8e:	shl    $0x4,%r11
 101eb92:	mov    (%rax,%r11,1),%r11
 101eb96:	cmp    %rdx,%r11
 101eb99:	jne    101eb80 <transfer+0x80>
 101eb9b:	shl    $0x4,%r10
 101eb9f:	mov    0x8(%rax,%r10,1),%r14
 101eba4:	mov    (%rbx),%r10
 101eba7:	imul   %r10,%r8
 101ebab:	shrx   %r9,%r8,%rdx
 101ebb0:	and    %rsi,%rdx
 101ebb3:	mov    %rdx,%r8
 101ebb6:	shl    $0x4,%r8
 101ebba:	mov    (%rax,%r8,1),%r8
 101ebbe:	cmp    %r10,%r8
 101ebc1:	je     101ebd1 <transfer+0xd1>
 101ebc3:	test   %r8,%r8
 101ebc6:	je     101ef01 <transfer+0x401>
 101ebcc:	inc    %rdx
 101ebcf:	jmp    101ebb0 <transfer+0xb0>
 101ebd1:	test   %r14,%r14
 101ebd4:	je     101ef01 <transfer+0x401>
 101ebda:	shl    $0x4,%rdx
 101ebde:	mov    0x8(%rax,%rdx,1),%rax
 101ebe3:	test   %rax,%rax
 101ebe6:	je     101ef01 <transfer+0x401>
 101ebec:	mov    (%r14),%rdx
 101ebef:	cmp    (%rax),%rdx
 101ebf2:	jne    101ef01 <transfer+0x401>
 101ebf8:	cmp    %r15,%rcx
 101ebfb:	je     101ef01 <transfer+0x401>
 101ec01:	mov    0x18(%rbx),%edx
 101ec04:	mov    $0x3,%eax
 101ec09:	cmp    0x70(%rdi),%edx
 101ec0c:	ja     101ee26 <transfer+0x326>
 101ec12:	cmpl   $0x1,0x8(%r14)
 101ec17:	jne    101ec82 <transfer+0x182>
 101ec19:	mov    (%rcx),%rax
 101ec1c:	test   %rax,%rax
 101ec1f:	je     101ec55 <transfer+0x155>
 101ec21:	mov    -0x10(%rax),%rsi
 101ec25:	test   $0x2,%sil
 101ec29:	jne    101ec55 <transfer+0x155>
 101ec2b:	bt     $0x3e,%rsi
 101ec30:	setae  %r8b
 101ec34:	mov    %rsi,%r9
 101ec37:	shr    $0x28,%r9
 101ec3b:	and    $0xfffff,%r9d
 101ec42:	cmp    %edx,%r9d
 101ec45:	setbe  %r9b
 101ec49:	bt     $0x3c,%rsi
 101ec4e:	jb     101ec82 <transfer+0x182>
 101ec50:	or     %r9b,%r8b
 101ec53:	je     101ec82 <transfer+0x182>
 101ec55:	mov    %rax,(%r15)
 101ec58:	movq   $0x0,(%rcx)
 101ec5f:	mov    0x1608(%rdi),%rcx
 101ec66:	xor    %eax,%eax
 101ec68:	cmpq   $0x0,0xc8(%rcx)
 101ec70:	je     101ee26 <transfer+0x326>
 101ec76:	call   101be30 <myl_rc_drain>
 101ec7b:	xor    %eax,%eax
 101ec7d:	jmp    101ee26 <transfer+0x326>
 101ec82:	vxorps %xmm0,%xmm0,%xmm0
 101ec86:	vmovups %ymm0,-0xa0(%rbp)
 101ec8e:	vmovups %ymm0,-0xc0(%rbp)
 101ec96:	vmovups %ymm0,-0xe0(%rbp)
 101ec9e:	vmovups %ymm0,-0x100(%rbp)
 101eca6:	vmovups %ymm0,-0x120(%rbp)
 101ecae:	vmovups %ymm0,-0x140(%rbp)
 101ecb6:	movq   $0x0,-0x80(%rbp)
 101ecbe:	mov    %rdi,-0x58(%rbp)
 101ecc2:	lea    -0x240(%rbp),%rax
 101ecc9:	mov    %rax,-0x50(%rbp)
 101eccd:	movq   $0x8,-0x48(%rbp)
 101ecd5:	movq   $0x0,-0x40(%rbp)
 101ecdd:	mov    %edx,-0x38(%rbp)
 101ece0:	movl   $0x1,-0x34(%rbp)
 101ece7:	lea    -0x140(%rbp),%rax
 101ecee:	mov    %rax,-0x30(%rbp)
 101ecf2:	mov    0x28(%r14),%r12
 101ecf6:	cmp    $0x9,%r12
 101ecfa:	jb     101ed85 <transfer+0x285>
 101ed00:	mov    %rbx,-0x78(%rbp)
 101ed04:	mov    %r12,%rax
 101ed07:	shr    $0x3b,%rax
 101ed0b:	jne    101ef01 <transfer+0x401>
 101ed11:	mov    %r12,%rbx
 101ed14:	shl    $0x5,%rbx
 101ed18:	mov    0x18(%rdi),%rdx
 101ed1c:	add    %rbx,%rdx
 101ed1f:	jb     101ed2f <transfer+0x22f>
 101ed21:	mov    0x58(%rdi),%rax
 101ed25:	test   %rax,%rax
 101ed28:	je     101ed40 <transfer+0x240>
 101ed2a:	cmp    %rax,%rdx
 101ed2d:	jbe    101ed40 <transfer+0x240>
 101ed2f:	movl   $0x1,0x6c(%rdi)
 101ed36:	mov    $0x1,%eax
 101ed3b:	jmp    101ee26 <transfer+0x326>
 101ed40:	mov    %rdx,-0x60(%rbp)
 101ed44:	mov    %rdi,-0x68(%rbp)
 101ed48:	mov    %rcx,-0x70(%rbp)
 101ed4c:	mov    $0x1,%edi
 101ed51:	mov    %rbx,%rsi
 101ed54:	vzeroupper
 101ed57:	call   1027690 <calloc@plt>
 101ed5c:	test   %rax,%rax
 101ed5f:	je     101ee6c <transfer+0x36c>
 101ed65:	mov    -0x68(%rbp),%rcx
 101ed69:	mov    -0x60(%rbp),%rdx
 101ed6d:	mov    %rdx,0x18(%rcx)
 101ed71:	add    %rbx,0x30(%r13)
 101ed75:	mov    %rax,-0x50(%rbp)
 101ed79:	mov    %r12,-0x48(%rbp)
 101ed7d:	mov    -0x70(%rbp),%rcx
 101ed81:	mov    -0x78(%rbp),%rbx
 101ed85:	mov    (%r14),%rdx
 101ed88:	mov    %r15,%rdi
 101ed8b:	mov    %rcx,%rsi
 101ed8e:	mov    %rcx,%r12
 101ed91:	vzeroupper
 101ed94:	call   10276a0 <memcpy@plt>
 101ed99:	mov    0x8(%rbx),%rdx
 101ed9d:	lea    -0x58(%rbp),%rdi
 101eda1:	mov    $0x101fe30,%r8d
 101eda7:	mov    %r14,%rsi
 101edaa:	mov    %r12,%r15
 101edad:	mov    %r12,%rcx
 101edb0:	call   101ef10 <visit>
 101edb5:	test   %eax,%eax
 101edb7:	je     101edcd <transfer+0x2cd>
 101edb9:	mov    %eax,%r12d
 101edbc:	mov    -0x30(%rbp),%rax
 101edc0:	movq   $0x0,0xb8(%rax)
 101edcb:	jmp    101edec <transfer+0x2ec>
 101edcd:	lea    -0x58(%rbp),%rdi
 101edd1:	call   1020150 <finish_clones>
 101edd6:	mov    -0x30(%rbp),%rcx
 101edda:	test   %eax,%eax
 101eddc:	je     101ee3b <transfer+0x33b>
 101edde:	mov    %eax,%r12d
 101ede1:	movq   $0x0,0xb8(%rcx)
 101edec:	mov    %r15,%rcx
 101edef:	mov    0x8(%rbx),%rdx
 101edf3:	lea    -0x58(%rbp),%rdi
 101edf7:	mov    $0x1020820,%r8d
 101edfd:	mov    %r14,%rsi
 101ee00:	call   101ef10 <visit>
 101ee05:	mov    0x8(%rbx),%rdi
 101ee09:	mov    $0x1,%ebx
 101ee0e:	mov    (%r14),%rdx
 101ee11:	xor    %esi,%esi
 101ee13:	call   1027650 <memset@plt>
 101ee18:	lea    -0x58(%rbp),%rdi
 101ee1c:	mov    %ebx,%esi
 101ee1e:	call   10208e0 <dispose_walk>
 101ee23:	mov    %r12d,%eax
 101ee26:	add    $0x218,%rsp
 101ee2d:	pop    %rbx
 101ee2e:	pop    %r12
 101ee30:	pop    %r13
 101ee32:	pop    %r14
 101ee34:	pop    %r15
 101ee36:	pop    %rbp
 101ee37:	vzeroupper
 101ee3a:	ret
 101ee3b:	mov    0xb8(%rcx),%rdi
 101ee42:	test   %rdi,%rdi
 101ee45:	je     101eed0 <transfer+0x3d0>
 101ee4b:	movabs $0x2000000000000000,%rax
 101ee55:	mov    0xb0(%rcx),%rsi
 101ee5c:	mov    %edi,%edx
 101ee5e:	and    $0x3,%edx
 101ee61:	cmp    $0x4,%rdi
 101ee65:	jae    101ee73 <transfer+0x373>
 101ee67:	xor    %r8d,%r8d
 101ee6a:	jmp    101eeb1 <transfer+0x3b1>
 101ee6c:	mov    $0x1,%eax
 101ee71:	jmp    101ee26 <transfer+0x326>
 101ee73:	and    $0xfffffffffffffffc,%rdi
 101ee77:	xor    %r8d,%r8d
 101ee7a:	nopw   0x0(%rax,%rax,1)
 101ee80:	mov    (%rsi,%r8,8),%r9
 101ee84:	or     %rax,-0x10(%r9)
 101ee88:	mov    0x8(%rsi,%r8,8),%r9
 101ee8d:	or     %rax,-0x10(%r9)
 101ee91:	mov    0x10(%rsi,%r8,8),%r9
 101ee96:	or     %rax,-0x10(%r9)
 101ee9a:	mov    0x18(%rsi,%r8,8),%r9
 101ee9f:	or     %rax,-0x10(%r9)
 101eea3:	add    $0x4,%r8
 101eea7:	cmp    %r8,%rdi
 101eeaa:	jne    101ee80 <transfer+0x380>
 101eeac:	test   %rdx,%rdx
 101eeaf:	je     101eed0 <transfer+0x3d0>
 101eeb1:	lea    (%rsi,%r8,8),%rsi
 101eeb5:	xor    %edi,%edi
 101eeb7:	nopw   0x0(%rax,%rax,1)
 101eec0:	mov    (%rsi,%rdi,8),%r8
 101eec4:	or     %rax,-0x10(%r8)
 101eec8:	inc    %rdi
 101eecb:	cmp    %rdi,%rdx
 101eece:	jne    101eec0 <transfer+0x3c0>
 101eed0:	movq   $0x0,0xb8(%rcx)
 101eedb:	mov    0x8(%rbx),%rdx
 101eedf:	lea    -0x58(%rbp),%rdi
 101eee3:	mov    $0x1020880,%r8d
 101eee9:	mov    %r14,%rsi
 101eeec:	mov    %r15,%rcx
 101eeef:	call   101ef10 <visit>
 101eef4:	mov    %r15,%rdi
 101eef7:	xor    %r12d,%r12d
 101eefa:	xor    %ebx,%ebx
 101eefc:	jmp    101ee0e <transfer+0x30e>
 101ef01:	vzeroupper
 101ef04:	call   1018954 <myl_rc_invariant_failed>
 101ef09:	int3
 101ef0a:	int3
 101ef0b:	int3
 101ef0c:	int3
 101ef0d:	int3
 101ef0e:	int3
 101ef0f:	int3

000000000101ef10 <visit>:
 101ef10:	push   %rbp
 101ef11:	mov    %rsp,%rbp
 101ef14:	push   %r15
 101ef16:	push   %r14
 101ef18:	push   %r13
 101ef1a:	push   %r12
 101ef1c:	push   %rbx
 101ef1d:	sub    $0x38,%rsp
 101ef21:	mov    %rdi,%rbx
 101ef24:	movq   $0x0,0x18(%rdi)
 101ef2c:	mov    0x8(%rsi),%r13d
 101ef30:	mov    %r13d,%eax
 101ef33:	or     $0x4,%eax
 101ef36:	cmp    $0x5,%eax
 101ef39:	jne    101ef58 <visit+0x48>
 101ef3b:	mov    %rbx,%rdi
 101ef3e:	mov    %rdx,%rsi
 101ef41:	mov    %rcx,%rdx
 101ef44:	mov    %r13d,%ecx
 101ef47:	add    $0x38,%rsp
 101ef4b:	pop    %rbx
 101ef4c:	pop    %r12
 101ef4e:	pop    %r13
 101ef50:	pop    %r14
 101ef52:	pop    %r15
 101ef54:	pop    %rbp
 101ef55:	jmp    *%r8
 101ef58:	cmpq   $0x2,0x28(%rsi)
 101ef5d:	mov    %r8,-0x38(%rbp)
 101ef61:	jbe    101f0c2 <visit+0x1b2>
 101ef67:	xor    %eax,%eax
 101ef69:	test   %r13d,%r13d
 101ef6c:	je     101f1ef <visit+0x2df>
 101ef72:	cmpq   $0x0,0x10(%rbx)
 101ef77:	je     101f208 <visit+0x2f8>
 101ef7d:	mov    0x8(%rbx),%rax
 101ef81:	movq   $0x1,0x18(%rbx)
 101ef89:	mov    %rsi,(%rax)
 101ef8c:	mov    %rdx,0x8(%rax)
 101ef90:	mov    %rcx,0x10(%rax)
 101ef94:	movq   $0x0,0x18(%rax)
 101ef9c:	mov    0x18(%rbx),%rax
 101efa0:	jmp    101efb7 <visit+0xa7>
 101efa2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101efb0:	dec    %rax
 101efb3:	mov    %rax,0x18(%rbx)
 101efb7:	test   %rax,%rax
 101efba:	je     101f1ed <visit+0x2dd>
 101efc0:	mov    0x8(%rbx),%rcx
 101efc4:	mov    %rax,%rsi
 101efc7:	shl    $0x5,%rsi
 101efcb:	lea    (%rcx,%rsi,1),%rdx
 101efcf:	mov    -0x20(%rcx,%rsi,1),%rsi
 101efd4:	mov    0x8(%rsi),%ecx
 101efd7:	cmp    $0x5,%ecx
 101efda:	je     101efe6 <visit+0xd6>
 101efdc:	cmp    $0x3,%ecx
 101efdf:	je     101f010 <visit+0x100>
 101efe1:	cmp    $0x1,%ecx
 101efe4:	jne    101f030 <visit+0x120>
 101efe6:	mov    -0x18(%rdx),%rsi
 101efea:	mov    -0x10(%rdx),%rdx
 101efee:	mov    %rbx,%rdi
 101eff1:	call   *%r8
 101eff4:	test   %eax,%eax
 101eff6:	jne    101f1fe <visit+0x2ee>
 101effc:	mov    0x18(%rbx),%rax
 101f000:	dec    %rax
 101f003:	mov    %rax,0x18(%rbx)
 101f007:	mov    -0x38(%rbp),%r8
 101f00b:	jmp    101efb7 <visit+0xa7>
 101f00d:	nopl   (%rax)
 101f010:	mov    -0x8(%rdx),%rcx
 101f014:	cmp    0x18(%rsi),%rcx
 101f018:	je     101efb0 <visit+0xa0>
 101f01a:	lea    0x1(%rcx),%rdi
 101f01e:	mov    %rdi,-0x8(%rdx)
 101f022:	mov    0x10(%rsi),%r10
 101f026:	cmpl   $0x0,0x8(%r10)
 101f02b:	jne    101f089 <visit+0x179>
 101f02d:	jmp    101efb7 <visit+0xa7>
 101f02f:	nop
 101f030:	mov    -0x8(%rdx),%rdi
 101f034:	cmp    0x18(%rsi),%rdi
 101f038:	je     101efb0 <visit+0xa0>
 101f03e:	lea    (%rdi,%rdi,2),%r9
 101f042:	shl    $0x3,%r9
 101f046:	add    0x10(%rsi),%r9
 101f04a:	inc    %rdi
 101f04d:	mov    %rdi,-0x8(%rdx)
 101f051:	mov    -0x10(%rdx),%rdi
 101f055:	cmp    $0x4,%ecx
 101f058:	jne    101f06b <visit+0x15b>
 101f05a:	mov    0x20(%rsi),%rcx
 101f05e:	mov    (%rdi,%rcx,1),%ecx
 101f061:	cmp    0x10(%r9),%ecx
 101f065:	jne    101efb7 <visit+0xa7>
 101f06b:	mov    0x8(%r9),%r10
 101f06f:	cmpl   $0x0,0x8(%r10)
 101f074:	je     101efb7 <visit+0xa7>
 101f07a:	cmp    0x10(%rbx),%rax
 101f07e:	jae    101f208 <visit+0x2f8>
 101f084:	mov    (%r9),%rcx
 101f087:	jmp    101f09c <visit+0x18c>
 101f089:	cmp    0x10(%rbx),%rax
 101f08d:	jae    101f208 <visit+0x2f8>
 101f093:	imul   0x20(%rsi),%rcx
 101f098:	mov    -0x10(%rdx),%rdi
 101f09c:	add    %rcx,%rdi
 101f09f:	add    -0x18(%rdx),%rcx
 101f0a3:	inc    %rax
 101f0a6:	mov    %rax,0x18(%rbx)
 101f0aa:	mov    %r10,(%rdx)
 101f0ad:	mov    %rcx,0x8(%rdx)
 101f0b1:	mov    %rdi,0x10(%rdx)
 101f0b5:	movq   $0x0,0x18(%rdx)
 101f0bd:	jmp    101ef9c <visit+0x8c>
 101f0c2:	lea    -0x1(%r13),%eax
 101f0c6:	cmp    $0x3,%eax
 101f0c9:	mov    %rcx,-0x58(%rbp)
 101f0cd:	mov    %rdx,-0x50(%rbp)
 101f0d1:	ja     101f134 <visit+0x224>
 101f0d3:	jmp    *0x1001bc8(,%rax,8)
 101f0da:	mov    $0x1,%r13d
 101f0e0:	mov    $0x1,%edx
 101f0e5:	jmp    101f136 <visit+0x226>
 101f0e7:	mov    0x10(%rsi),%rax
 101f0eb:	mov    0x18(%rsi),%rdx
 101f0ef:	mov    0x20(%rsi),%rcx
 101f0f3:	mov    %rcx,-0x30(%rbp)
 101f0f7:	mov    0x8(%rax),%r13d
 101f0fb:	jmp    101f13e <visit+0x22e>
 101f0fd:	mov    0x10(%rsi),%rdi
 101f101:	mov    0x18(%rsi),%rdx
 101f105:	mov    0x20(%rsi),%r12
 101f109:	add    %rcx,%r12
 101f10c:	mov    $0x4,%r13d
 101f112:	movq   $0x0,-0x30(%rbp)
 101f11a:	jmp    101f143 <visit+0x233>
 101f11c:	mov    0x10(%rsi),%rdi
 101f120:	mov    0x18(%rsi),%rdx
 101f124:	mov    $0x2,%r13d
 101f12a:	movq   $0x0,-0x30(%rbp)
 101f132:	jmp    101f140 <visit+0x230>
 101f134:	xor    %edx,%edx
 101f136:	movq   $0x0,-0x30(%rbp)
 101f13e:	xor    %edi,%edi
 101f140:	xor    %r12d,%r12d
 101f143:	mov    %rdx,%r15
 101f146:	neg    %r15
 101f149:	xor    %r14d,%r14d
 101f14c:	mov    %rdx,-0x48(%rbp)
 101f150:	mov    %rdi,-0x40(%rbp)
 101f154:	test   %rdi,%rdi
 101f157:	je     101f1b2 <visit+0x2a2>
 101f159:	xor    %eax,%eax
 101f15b:	cmp    %rdx,%r14
 101f15e:	mov    -0x38(%rbp),%r8
 101f162:	jae    101f1ef <visit+0x2df>
 101f168:	lea    (%r14,%r14,2),%rax
 101f16c:	lea    (%rdi,%rax,8),%rax
 101f170:	inc    %r14
 101f173:	jmp    101f194 <visit+0x284>
 101f175:	data16 cs nopw 0x0(%rax,%rax,1)
 101f180:	add    $0x18,%rax
 101f184:	lea    (%r15,%r14,1),%rcx
 101f188:	inc    %rcx
 101f18b:	inc    %r14
 101f18e:	cmp    $0x1,%rcx
 101f192:	je     101f1ed <visit+0x2dd>
 101f194:	mov    0x8(%rax),%rcx
 101f198:	mov    0x8(%rcx),%ecx
 101f19b:	test   %ecx,%ecx
 101f19d:	je     101f180 <visit+0x270>
 101f19f:	test   %r12,%r12
 101f1a2:	je     101f1ad <visit+0x29d>
 101f1a4:	mov    0x10(%rax),%edx
 101f1a7:	cmp    (%r12),%edx
 101f1ab:	jne    101f180 <visit+0x270>
 101f1ad:	mov    (%rax),%rdx
 101f1b0:	jmp    101f1c9 <visit+0x2b9>
 101f1b2:	cmp    %rdx,%r14
 101f1b5:	mov    -0x38(%rbp),%r8
 101f1b9:	je     101f1ed <visit+0x2dd>
 101f1bb:	mov    %r14,%rdx
 101f1be:	inc    %r14
 101f1c1:	imul   -0x30(%rbp),%rdx
 101f1c6:	mov    %r13d,%ecx
 101f1c9:	mov    -0x50(%rbp),%rax
 101f1cd:	lea    (%rax,%rdx,1),%rsi
 101f1d1:	add    -0x58(%rbp),%rdx
 101f1d5:	mov    %rbx,%rdi
 101f1d8:	call   *%r8
 101f1db:	test   %eax,%eax
 101f1dd:	mov    -0x48(%rbp),%rdx
 101f1e1:	mov    -0x40(%rbp),%rdi
 101f1e5:	je     101f154 <visit+0x244>
 101f1eb:	jmp    101f1ef <visit+0x2df>
 101f1ed:	xor    %eax,%eax
 101f1ef:	add    $0x38,%rsp
 101f1f3:	pop    %rbx
 101f1f4:	pop    %r12
 101f1f6:	pop    %r13
 101f1f8:	pop    %r14
 101f1fa:	pop    %r15
 101f1fc:	pop    %rbp
 101f1fd:	ret
 101f1fe:	movq   $0x0,0x18(%rbx)
 101f206:	jmp    101f1ef <visit+0x2df>
 101f208:	call   1018954 <myl_rc_invariant_failed>
 101f20d:	int3
 101f20e:	int3
 101f20f:	int3

000000000101f210 <schedule_clone>:
 101f210:	push   %rbp
 101f211:	mov    %rsp,%rbp
 101f214:	push   %r15
 101f216:	push   %r14
 101f218:	push   %r13
 101f21a:	push   %r12
 101f21c:	push   %rbx
 101f21d:	sub    $0x68,%rsp
 101f221:	mov    %rcx,%r10
 101f224:	movq   $0x0,(%rcx)
 101f22b:	mov    0x28(%rdi),%r12
 101f22f:	cmpl   $0x0,0xac(%r12)
 101f238:	je     101f289 <schedule_clone+0x79>
 101f23a:	test   %rsi,%rsi
 101f23d:	je     101f289 <schedule_clone+0x79>
 101f23f:	mov    -0x8(%rsi),%rax
 101f243:	cmp    $0x100b618,%rax
 101f24a:	sete   %cl
 101f24d:	cmp    $0x100b510,%rax
 101f254:	sete   %r8b
 101f258:	or     %cl,%r8b
 101f25b:	cmp    $0x100b4a0,%rax
 101f262:	sete   %al
 101f265:	or     %r8b,%al
 101f268:	je     101f289 <schedule_clone+0x79>
 101f26a:	xor    %r11d,%r11d
 101f26d:	mov    (%rdi),%rbx
 101f270:	mov    0x1608(%rbx),%rax
 101f277:	cmpb   $0x0,0x120(%rax)
 101f27e:	jne    101f718 <schedule_clone+0x508>
 101f284:	jmp    101f3cf <schedule_clone+0x1bf>
 101f289:	mov    0xa0(%r12),%r13
 101f291:	test   %r13,%r13
 101f294:	je     101f35b <schedule_clone+0x14b>
 101f29a:	mov    0x30(%r12),%rax
 101f29f:	mov    %rsi,%rcx
 101f2a2:	shr    $0x4,%rcx
 101f2a6:	mov    %edx,%r8d
 101f2a9:	movabs $0x9e3779b97f4a7c15,%r9
 101f2b3:	imul   %r8,%r9
 101f2b7:	xor    %rcx,%r9
 101f2ba:	mov    %r9,%rcx
 101f2bd:	shr    $0x1e,%rcx
 101f2c1:	xor    %r9,%rcx
 101f2c4:	movabs $0xbf58476d1ce4e5b9,%r8
 101f2ce:	imul   %rcx,%r8
 101f2d2:	mov    %r8,%rcx
 101f2d5:	shr    $0x1b,%rcx
 101f2d9:	xor    %r8,%rcx
 101f2dc:	movabs $0x94d049bb133111eb,%r9
 101f2e6:	imul   %rcx,%r9
 101f2ea:	mov    %r9,%r8
 101f2ed:	shr    $0x1f,%r8
 101f2f1:	xor    %r9,%r8
 101f2f4:	lea    -0x1(%r13),%r9
 101f2f8:	jmp    101f303 <schedule_clone+0xf3>
 101f2fa:	nopw   0x0(%rax,%rax,1)
 101f300:	inc    %r8
 101f303:	and    %r9,%r8
 101f306:	lea    (%r8,%r8,2),%rcx
 101f30a:	mov    (%rax,%rcx,8),%rcx
 101f30e:	test   %rcx,%rcx
 101f311:	je     101f322 <schedule_clone+0x112>
 101f313:	cmp    %rsi,%rcx
 101f316:	jne    101f300 <schedule_clone+0xf0>
 101f318:	lea    (%r8,%r8,2),%rcx
 101f31c:	cmp    %edx,0x10(%rax,%rcx,8)
 101f320:	jne    101f300 <schedule_clone+0xf0>
 101f322:	lea    (%r8,%r8,2),%rcx
 101f326:	lea    (%rax,%rcx,8),%rax
 101f32a:	mov    0x8(%rax),%rax
 101f32e:	test   %rax,%rax
 101f331:	je     101f395 <schedule_clone+0x185>
 101f333:	mov    -0x10(%rax),%rsi
 101f337:	movabs $0x4000000000000000,%rcx
 101f341:	or     $0x2,%rcx
 101f345:	test   %rcx,%rsi
 101f348:	je     101f438 <schedule_clone+0x228>
 101f34e:	test   %edx,%edx
 101f350:	jne    101f46b <schedule_clone+0x25b>
 101f356:	jmp    101f48a <schedule_clone+0x27a>
 101f35b:	mov    0x98(%r12),%r15
 101f363:	test   %r15,%r15
 101f366:	je     101f6fe <schedule_clone+0x4ee>
 101f36c:	lea    0x38(%r12),%rax
 101f371:	mov    %r15,%r8
 101f374:	jmp    101f389 <schedule_clone+0x179>
 101f376:	cs nopw 0x0(%rax,%rax,1)
 101f380:	add    $0x18,%rax
 101f384:	dec    %r8
 101f387:	je     101f39d <schedule_clone+0x18d>
 101f389:	cmp    %rsi,(%rax)
 101f38c:	jne    101f380 <schedule_clone+0x170>
 101f38e:	cmp    %edx,0x10(%rax)
 101f391:	jne    101f380 <schedule_clone+0x170>
 101f393:	jmp    101f32a <schedule_clone+0x11a>
 101f395:	mov    0x98(%r12),%r15
 101f39d:	test   %r13,%r13
 101f3a0:	je     101f494 <schedule_clone+0x284>
 101f3a6:	mov    %r13,%rax
 101f3a9:	shr    $1,%rax
 101f3ac:	mov    $0x1,%r11b
 101f3af:	cmp    %rax,%r15
 101f3b2:	jae    101f4a1 <schedule_clone+0x291>
 101f3b8:	mov    (%rdi),%rbx
 101f3bb:	mov    0x1608(%rbx),%rax
 101f3c2:	cmpb   $0x0,0x120(%rax)
 101f3c9:	jne    101f718 <schedule_clone+0x508>
 101f3cf:	cmpq   $0x100b618,-0x8(%rsi)
 101f3d7:	jne    101f718 <schedule_clone+0x508>
 101f3dd:	mov    %r11d,-0x50(%rbp)
 101f3e1:	mov    %rdi,%r14
 101f3e4:	mov    %rsi,-0x40(%rbp)
 101f3e8:	mov    %edx,%r15d
 101f3eb:	mov    %r10,%r13
 101f3ee:	mov    $0x100b3e0,%esi
 101f3f3:	mov    %rbx,%rdi
 101f3f6:	call   1019700 <myl_rc_module_register>
 101f3fb:	mov    %eax,%ecx
 101f3fd:	mov    $0x1,%eax
 101f402:	test   %ecx,%ecx
 101f404:	jne    101faf6 <schedule_clone+0x8e6>
 101f40a:	mov    0x1608(%rbx),%rax
 101f411:	movb   $0x1,0x120(%rax)
 101f418:	mov    %r14,%rdi
 101f41b:	mov    (%r14),%rax
 101f41e:	mov    0x1608(%rax),%rax
 101f425:	mov    %r13,%r10
 101f428:	mov    %r15d,%edx
 101f42b:	mov    -0x40(%rbp),%rsi
 101f42f:	mov    -0x50(%rbp),%r11d
 101f433:	jmp    101f718 <schedule_clone+0x508>
 101f438:	test   $0x1,%sil
 101f43c:	jne    101fe24 <schedule_clone+0xc14>
 101f442:	mov    -0x20(%rax),%rcx
 101f446:	cmp    $0xffffffffffffffff,%rcx
 101f44a:	je     101f588 <schedule_clone+0x378>
 101f450:	test   %rcx,%rcx
 101f453:	jne    101f460 <schedule_clone+0x250>
 101f455:	cmpq   $0x0,-0x18(%rax)
 101f45a:	je     101fe24 <schedule_clone+0xc14>
 101f460:	inc    %rcx
 101f463:	mov    %rcx,-0x20(%rax)
 101f467:	test   %edx,%edx
 101f469:	je     101f48a <schedule_clone+0x27a>
 101f46b:	cmpl   $0x0,0xac(%r12)
 101f474:	jne    101f48a <schedule_clone+0x27a>
 101f476:	movabs $0x1fffffffffffffff,%rcx
 101f480:	inc    %rcx
 101f483:	or     %rcx,%rsi
 101f486:	mov    %rsi,-0x10(%rax)
 101f48a:	mov    %rax,(%r10)
 101f48d:	xor    %eax,%eax
 101f48f:	jmp    101faf6 <schedule_clone+0x8e6>
 101f494:	mov    $0x1,%r11b
 101f497:	cmp    $0x4,%r15
 101f49b:	jb     101f3b8 <schedule_clone+0x1a8>
 101f4a1:	lea    0x0(,%r13,2),%rax
 101f4a9:	test   %r13,%r13
 101f4ac:	mov    $0x20,%r8d
 101f4b2:	cmovne %rax,%r8
 101f4b6:	mov    $0x1,%eax
 101f4bb:	cmp    %r13,%r8
 101f4be:	jb     101faf6 <schedule_clone+0x8e6>
 101f4c4:	mov    %edx,-0x2c(%rbp)
 101f4c7:	mov    $0x18,%ecx
 101f4cc:	mov    %r8,%rax
 101f4cf:	mul    %rcx
 101f4d2:	jo     101f833 <schedule_clone+0x623>
 101f4d8:	mov    (%rdi),%rdx
 101f4db:	test   %rdx,%rdx
 101f4de:	je     101fe24 <schedule_clone+0xc14>
 101f4e4:	test   %rax,%rax
 101f4e7:	je     101fe24 <schedule_clone+0xc14>
 101f4ed:	mov    0x1608(%rdx),%r11
 101f4f4:	test   %r11,%r11
 101f4f7:	je     101fe24 <schedule_clone+0xc14>
 101f4fd:	mov    0x18(%rdx),%rbx
 101f501:	mov    %rax,%r9
 101f504:	add    %rax,%rbx
 101f507:	mov    $0x1,%eax
 101f50c:	jb     101faef <schedule_clone+0x8df>
 101f512:	mov    0x58(%rdx),%rcx
 101f516:	test   %rcx,%rcx
 101f519:	je     101f524 <schedule_clone+0x314>
 101f51b:	cmp    %rcx,%rbx
 101f51e:	ja     101faef <schedule_clone+0x8df>
 101f524:	mov    %r11,-0x38(%rbp)
 101f528:	mov    %rdx,-0x58(%rbp)
 101f52c:	mov    %r8,-0x70(%rbp)
 101f530:	mov    %rdi,-0x48(%rbp)
 101f534:	mov    %rsi,-0x40(%rbp)
 101f538:	mov    %r10,-0x60(%rbp)
 101f53c:	mov    $0x1,%edi
 101f541:	mov    %r9,%rsi
 101f544:	mov    %r9,-0x50(%rbp)
 101f548:	call   1027690 <calloc@plt>
 101f54d:	mov    %rax,%r14
 101f550:	mov    $0x1,%eax
 101f555:	test   %r14,%r14
 101f558:	je     101faf6 <schedule_clone+0x8e6>
 101f55e:	mov    -0x58(%rbp),%r9
 101f562:	mov    %rbx,0x18(%r9)
 101f566:	mov    -0x38(%rbp),%rax
 101f56a:	mov    -0x50(%rbp),%rcx
 101f56e:	add    %rcx,0x30(%rax)
 101f572:	test   %r13,%r13
 101f575:	je     101f592 <schedule_clone+0x382>
 101f577:	mov    0x30(%r12),%rcx
 101f57c:	mov    %r13,%r15
 101f57f:	mov    -0x2c(%rbp),%edx
 101f582:	mov    -0x40(%rbp),%rsi
 101f586:	jmp    101f5ab <schedule_clone+0x39b>
 101f588:	mov    $0x2,%eax
 101f58d:	jmp    101faf6 <schedule_clone+0x8e6>
 101f592:	test   %r15,%r15
 101f595:	mov    -0x60(%rbp),%r10
 101f599:	mov    -0x2c(%rbp),%edx
 101f59c:	mov    -0x40(%rbp),%rsi
 101f5a0:	je     101fde1 <schedule_clone+0xbd1>
 101f5a6:	lea    0x38(%r12),%rcx
 101f5ab:	mov    -0x70(%rbp),%rax
 101f5af:	lea    -0x1(%rax),%r11
 101f5b3:	xor    %r8d,%r8d
 101f5b6:	mov    -0x48(%rbp),%rdi
 101f5ba:	mov    %rcx,-0x50(%rbp)
 101f5be:	jmp    101f5ec <schedule_clone+0x3dc>
 101f5c0:	lea    (%rbx,%rbx,2),%rax
 101f5c4:	mov    -0x38(%rbp),%r9
 101f5c8:	mov    0x10(%r9),%rcx
 101f5cc:	mov    %rcx,0x10(%r14,%rax,8)
 101f5d1:	vmovups (%r9),%xmm0
 101f5d6:	vmovups %xmm0,(%r14,%rax,8)
 101f5dc:	mov    -0x50(%rbp),%rcx
 101f5e0:	inc    %r8
 101f5e3:	cmp    %r15,%r8
 101f5e6:	je     101f68c <schedule_clone+0x47c>
 101f5ec:	lea    (%r8,%r8,2),%rax
 101f5f0:	mov    (%rcx,%rax,8),%r10
 101f5f4:	test   %r10,%r10
 101f5f7:	je     101f5e0 <schedule_clone+0x3d0>
 101f5f9:	lea    (%rcx,%rax,8),%rax
 101f5fd:	mov    %rax,-0x38(%rbp)
 101f601:	mov    0x10(%rax),%eax
 101f604:	mov    %r10,%r9
 101f607:	shr    $0x4,%r9
 101f60b:	mov    %rax,%rbx
 101f60e:	movabs $0x9e3779b97f4a7c15,%rcx
 101f618:	imul   %rcx,%rbx
 101f61c:	xor    %r9,%rbx
 101f61f:	mov    %rbx,%r9
 101f622:	shr    $0x1e,%r9
 101f626:	xor    %rbx,%r9
 101f629:	movabs $0xbf58476d1ce4e5b9,%rcx
 101f633:	imul   %rcx,%r9
 101f637:	mov    %r9,%rcx
 101f63a:	shr    $0x1b,%rcx
 101f63e:	xor    %r9,%rcx
 101f641:	movabs $0x94d049bb133111eb,%r9
 101f64b:	imul   %r9,%rcx
 101f64f:	mov    %rcx,%rbx
 101f652:	shr    $0x1f,%rbx
 101f656:	xor    %rcx,%rbx
 101f659:	jmp    101f663 <schedule_clone+0x453>
 101f65b:	nopl   0x0(%rax,%rax,1)
 101f660:	inc    %rbx
 101f663:	and    %r11,%rbx
 101f666:	lea    (%rbx,%rbx,2),%rcx
 101f66a:	mov    (%r14,%rcx,8),%r9
 101f66e:	test   %r9,%r9
 101f671:	je     101f5c0 <schedule_clone+0x3b0>
 101f677:	cmp    %r10,%r9
 101f67a:	jne    101f660 <schedule_clone+0x450>
 101f67c:	lea    (%rbx,%rbx,2),%rcx
 101f680:	cmp    %eax,0x10(%r14,%rcx,8)
 101f685:	jne    101f660 <schedule_clone+0x450>
 101f687:	jmp    101f5c0 <schedule_clone+0x3b0>
 101f68c:	shl    $0x3,%r13
 101f690:	lea    0x0(,%r13,2),%r8
 101f698:	add    %r13,%r8
 101f69b:	mov    -0x60(%rbp),%r10
 101f69f:	mov    -0x58(%rbp),%r9
 101f6a3:	mov    0x30(%r12),%rax
 101f6a8:	test   %rax,%rax
 101f6ab:	je     101f6ed <schedule_clone+0x4dd>
 101f6ad:	mov    0x18(%r9),%rcx
 101f6b1:	sub    %r8,%rcx
 101f6b4:	jb     101fe24 <schedule_clone+0xc14>
 101f6ba:	mov    0x1608(%r9),%rdx
 101f6c1:	mov    0x30(%rdx),%rsi
 101f6c5:	sub    %r8,%rsi
 101f6c8:	jb     101fe24 <schedule_clone+0xc14>
 101f6ce:	mov    %rcx,0x18(%r9)
 101f6d2:	mov    %rsi,0x30(%rdx)
 101f6d6:	mov    %rax,%rdi
 101f6d9:	call   10276f0 <free@plt>
 101f6de:	mov    -0x60(%rbp),%r10
 101f6e2:	mov    -0x2c(%rbp),%edx
 101f6e5:	mov    -0x40(%rbp),%rsi
 101f6e9:	mov    -0x48(%rbp),%rdi
 101f6ed:	mov    %r14,0x30(%r12)
 101f6f2:	mov    -0x70(%rbp),%rax
 101f6f6:	mov    %rax,0xa0(%r12)
 101f6fe:	mov    $0x1,%r11b
 101f701:	mov    (%rdi),%rbx
 101f704:	mov    0x1608(%rbx),%rax
 101f70b:	cmpb   $0x0,0x120(%rax)
 101f712:	je     101f3cf <schedule_clone+0x1bf>
 101f718:	mov    -0x8(%rsi),%r8
 101f71c:	mov    0x34(%r8),%ecx
 101f720:	cmp    %rcx,0xa0(%rax)
 101f727:	jbe    101fdfb <schedule_clone+0xbeb>
 101f72d:	mov    0x98(%rax),%r9
 101f734:	shl    $0x4,%rcx
 101f738:	cmp    %r8,(%r9,%rcx,1)
 101f73c:	jne    101fdfb <schedule_clone+0xbeb>
 101f742:	add    %rcx,%r9
 101f745:	mov    0x8(%r9),%rbx
 101f749:	test   %rbx,%rbx
 101f74c:	je     101fe24 <schedule_clone+0xc14>
 101f752:	cmpq   $0x0,0x18(%rbx)
 101f757:	jne    101fe24 <schedule_clone+0xc14>
 101f75d:	cmpq   $0x0,0x28(%rbx)
 101f762:	je     101f774 <schedule_clone+0x564>
 101f764:	cmpq   $0x0,0x30(%rbx)
 101f769:	jne    101f790 <schedule_clone+0x580>
 101f76b:	xor    %r8d,%r8d
 101f76e:	test   %edx,%edx
 101f770:	jne    101f7b3 <schedule_clone+0x5a3>
 101f772:	jmp    101f7cc <schedule_clone+0x5bc>
 101f774:	cmpq   $0x0,0x10(%rbx)
 101f779:	jne    101fe24 <schedule_clone+0xc14>
 101f77f:	cmpq   $0x0,0x30(%rbx)
 101f784:	jne    101f790 <schedule_clone+0x580>
 101f786:	mov    0x8(%rbx),%rax
 101f78a:	cmpl   $0x0,0x8(%rax)
 101f78e:	je     101f76b <schedule_clone+0x55b>
 101f790:	mov    (%r12),%r14
 101f794:	mov    0x8(%r12),%r13
 101f799:	mov    0x10(%r12),%rcx
 101f79e:	cmp    %rcx,%r13
 101f7a1:	jae    101f800 <schedule_clone+0x5f0>
 101f7a3:	mov    $0x1,%r8b
 101f7a6:	test   %r14,%r14
 101f7a9:	je     101f833 <schedule_clone+0x623>
 101f7af:	test   %edx,%edx
 101f7b1:	je     101f7cc <schedule_clone+0x5bc>
 101f7b3:	mov    0x18(%r12),%r9
 101f7b8:	mov    0x20(%r12),%r15
 101f7bd:	mov    0x28(%r12),%rax
 101f7c2:	cmp    %rax,%r15
 101f7c5:	jae    101f83d <schedule_clone+0x62d>
 101f7c7:	test   %r9,%r9
 101f7ca:	je     101f833 <schedule_clone+0x623>
 101f7cc:	mov    %r8d,-0x38(%rbp)
 101f7d0:	mov    %r11d,%r15d
 101f7d3:	movq   $0x0,-0x68(%rbp)
 101f7db:	mov    0x28(%rbx),%r8
 101f7df:	test   %r8,%r8
 101f7e2:	mov    %edx,-0x2c(%rbp)
 101f7e5:	je     101f8d3 <schedule_clone+0x6c3>
 101f7eb:	mov    (%rdi),%rdi
 101f7ee:	lea    -0x68(%rbp),%rcx
 101f7f2:	mov    %rsi,%r14
 101f7f5:	mov    %r10,%r13
 101f7f8:	call   *%r8
 101f7fb:	jmp    101f964 <schedule_clone+0x754>
 101f800:	lea    (%rcx,%rcx,1),%rax
 101f804:	test   %rcx,%rcx
 101f807:	mov    $0x10,%r15d
 101f80d:	cmovne %rax,%r15
 101f811:	mov    $0x1,%eax
 101f816:	cmp    %rcx,%r15
 101f819:	jb     101faf6 <schedule_clone+0x8e6>
 101f81f:	mov    %edx,-0x2c(%rbp)
 101f822:	mov    $0x28,%ecx
 101f827:	mov    %r15,%rax
 101f82a:	mul    %rcx
 101f82d:	jno    101fa9e <schedule_clone+0x88e>
 101f833:	mov    $0x1,%eax
 101f838:	jmp    101faf6 <schedule_clone+0x8e6>
 101f83d:	lea    (%rax,%rax,1),%rcx
 101f841:	test   %rax,%rax
 101f844:	mov    $0x10,%r13d
 101f84a:	cmovne %rcx,%r13
 101f84e:	cmp    %rax,%r13
 101f851:	setb   %al
 101f854:	mov    %r13,%rcx
 101f857:	shr    $0x3d,%rcx
 101f85b:	setne  %cl
 101f85e:	or     %al,%cl
 101f860:	mov    $0x1,%eax
 101f865:	jne    101faf6 <schedule_clone+0x8e6>
 101f86b:	mov    %r9,-0x58(%rbp)
 101f86f:	mov    (%rdi),%rcx
 101f872:	test   %rcx,%rcx
 101f875:	je     101fe24 <schedule_clone+0xc14>
 101f87b:	test   %r13,%r13
 101f87e:	je     101fe24 <schedule_clone+0xc14>
 101f884:	mov    0x1608(%rcx),%r14
 101f88b:	mov    %r14,-0x70(%rbp)
 101f88f:	test   %r14,%r14
 101f892:	je     101fe24 <schedule_clone+0xc14>
 101f898:	mov    0x18(%rcx),%r9
 101f89c:	lea    0x0(,%r13,8),%r14
 101f8a4:	add    %r14,%r9
 101f8a7:	jb     101f8c7 <schedule_clone+0x6b7>
 101f8a9:	mov    %r9,%r14
 101f8ac:	mov    0x58(%rcx),%r9
 101f8b0:	mov    %r9,-0x40(%rbp)
 101f8b4:	test   %r9,%r9
 101f8b7:	je     101fc7f <schedule_clone+0xa6f>
 101f8bd:	cmp    -0x40(%rbp),%r14
 101f8c1:	jbe    101fc7f <schedule_clone+0xa6f>
 101f8c7:	movl   $0x1,0x6c(%rcx)
 101f8ce:	jmp    101faf6 <schedule_clone+0x8e6>
 101f8d3:	mov    %r10,%r13
 101f8d6:	movabs $0x3ffffffffffffff,%r8
 101f8e0:	movabs $0x3fffffffff,%r10
 101f8ea:	mov    -0x8(%rsi),%r14
 101f8ee:	mov    %r14,-0x90(%rbp)
 101f8f5:	mov    -0x10(%rsi),%rax
 101f8f9:	mov    %rax,%rcx
 101f8fc:	shr    $0x2,%rcx
 101f900:	bt     $0x3e,%rax
 101f905:	mov    %r10,%r9
 101f908:	cmovae %r8,%r9
 101f90c:	and    %rcx,%r9
 101f90f:	mov    %r9,-0x88(%rbp)
 101f916:	mov    %edx,-0x80(%rbp)
 101f919:	movl   $0x0,-0x7c(%rbp)
 101f920:	mov    (%rdi),%r8
 101f923:	test   %r8,%r8
 101f926:	je     101fe24 <schedule_clone+0xc14>
 101f92c:	mov    0x1608(%r8),%r11
 101f933:	test   %r11,%r11
 101f936:	je     101fe24 <schedule_clone+0xc14>
 101f93c:	movq   $0x0,-0x68(%rbp)
 101f944:	test   %r14,%r14
 101f947:	je     101fe24 <schedule_clone+0xc14>
 101f94d:	mov    %r9,%rax
 101f950:	mulq   (%r14)
 101f953:	mov    %rax,%rdx
 101f956:	mov    $0x1,%eax
 101f95b:	mov    %rsi,%r14
 101f95e:	jno    101fb05 <schedule_clone+0x8f5>
 101f964:	test   %eax,%eax
 101f966:	jne    101faf6 <schedule_clone+0x8e6>
 101f96c:	mov    -0x68(%rbp),%rax
 101f970:	test   %rax,%rax
 101f973:	je     101fe24 <schedule_clone+0xc14>
 101f979:	test   %r15b,%r15b
 101f97c:	mov    -0x2c(%rbp),%edx
 101f97f:	mov    -0x38(%rbp),%r9d
 101f983:	je     101fa4b <schedule_clone+0x83b>
 101f989:	mov    0xa0(%r12),%rdi
 101f991:	test   %rdi,%rdi
 101f994:	je     101fc66 <schedule_clone+0xa56>
 101f99a:	mov    0x30(%r12),%rsi
 101f99f:	mov    %r14,%rcx
 101f9a2:	shr    $0x4,%rcx
 101f9a6:	mov    %edx,%r8d
 101f9a9:	movabs $0x9e3779b97f4a7c15,%r9
 101f9b3:	imul   %r8,%r9
 101f9b7:	xor    %rcx,%r9
 101f9ba:	mov    %r9,%rcx
 101f9bd:	shr    $0x1e,%rcx
 101f9c1:	xor    %r9,%rcx
 101f9c4:	movabs $0xbf58476d1ce4e5b9,%r8
 101f9ce:	imul   %rcx,%r8
 101f9d2:	mov    %r8,%rcx
 101f9d5:	shr    $0x1b,%rcx
 101f9d9:	xor    %r8,%rcx
 101f9dc:	movabs $0x94d049bb133111eb,%r9
 101f9e6:	imul   %rcx,%r9
 101f9ea:	mov    %r9,%r8
 101f9ed:	shr    $0x1f,%r8
 101f9f1:	xor    %r9,%r8
 101f9f4:	dec    %rdi
 101f9f7:	and    %rdi,%r8
 101f9fa:	lea    (%r8,%r8,2),%rcx
 101f9fe:	mov    (%rsi,%rcx,8),%rcx
 101fa02:	test   %rcx,%rcx
 101fa05:	je     101fd65 <schedule_clone+0xb55>
 101fa0b:	mov    -0x38(%rbp),%r9d
 101fa0f:	jmp    101fa37 <schedule_clone+0x827>
 101fa11:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101fa20:	inc    %r8
 101fa23:	and    %rdi,%r8
 101fa26:	lea    (%r8,%r8,2),%rcx
 101fa2a:	mov    (%rsi,%rcx,8),%rcx
 101fa2e:	test   %rcx,%rcx
 101fa31:	je     101fd69 <schedule_clone+0xb59>
 101fa37:	cmp    %r14,%rcx
 101fa3a:	jne    101fa20 <schedule_clone+0x810>
 101fa3c:	lea    (%r8,%r8,2),%rcx
 101fa40:	cmp    %edx,0x10(%rsi,%rcx,8)
 101fa44:	jne    101fa20 <schedule_clone+0x810>
 101fa46:	jmp    101fd69 <schedule_clone+0xb59>
 101fa4b:	test   %r9b,%r9b
 101fa4e:	je     101fd97 <schedule_clone+0xb87>
 101fa54:	mov    (%r12),%rcx
 101fa58:	mov    0x8(%r12),%rsi
 101fa5d:	lea    0x1(%rsi),%rdi
 101fa61:	mov    %rdi,0x8(%r12)
 101fa66:	lea    (%rsi,%rsi,4),%rsi
 101fa6a:	mov    %r14,(%rcx,%rsi,8)
 101fa6e:	mov    %rax,0x8(%rcx,%rsi,8)
 101fa73:	mov    %rbx,0x10(%rcx,%rsi,8)
 101fa78:	movq   $0x0,0x18(%rcx,%rsi,8)
 101fa81:	mov    %edx,0x20(%rcx,%rsi,8)
 101fa85:	movl   $0x0,0x24(%rcx,%rsi,8)
 101fa8d:	mov    -0x68(%rbp),%rax
 101fa91:	test   %edx,%edx
 101fa93:	jne    101fd9b <schedule_clone+0xb8b>
 101fa99:	jmp    101fdb2 <schedule_clone+0xba2>
 101fa9e:	mov    (%rdi),%rdx
 101faa1:	test   %rdx,%rdx
 101faa4:	je     101fe24 <schedule_clone+0xc14>
 101faaa:	test   %rax,%rax
 101faad:	je     101fe24 <schedule_clone+0xc14>
 101fab3:	mov    0x1608(%rdx),%r9
 101faba:	test   %r9,%r9
 101fabd:	je     101fe24 <schedule_clone+0xc14>
 101fac3:	mov    0x18(%rdx),%rcx
 101fac7:	mov    %rax,%r8
 101faca:	add    %rax,%rcx
 101facd:	mov    %rcx,-0x38(%rbp)
 101fad1:	mov    $0x1,%eax
 101fad6:	jb     101faef <schedule_clone+0x8df>
 101fad8:	mov    0x58(%rdx),%rcx
 101fadc:	test   %rcx,%rcx
 101fadf:	je     101fb76 <schedule_clone+0x966>
 101fae5:	cmp    %rcx,-0x38(%rbp)
 101fae9:	jbe    101fb76 <schedule_clone+0x966>
 101faef:	movl   $0x1,0x6c(%rdx)
 101faf6:	add    $0x68,%rsp
 101fafa:	pop    %rbx
 101fafb:	pop    %r12
 101fafd:	pop    %r13
 101faff:	pop    %r14
 101fb01:	pop    %r15
 101fb03:	pop    %rbp
 101fb04:	ret
 101fb05:	xor    %ecx,%ecx
 101fb07:	cmpl   $0x0,-0x2c(%rbp)
 101fb0b:	movabs $0x3ffffffffffffff,%rsi
 101fb15:	cmove  %rsi,%r10
 101fb19:	sete   %cl
 101fb1c:	shl    $0x4,%ecx
 101fb1f:	add    $0x10,%rcx
 101fb23:	add    %rcx,%rdx
 101fb26:	jb     101f964 <schedule_clone+0x754>
 101fb2c:	cmp    %r10,%r9
 101fb2f:	ja     101f964 <schedule_clone+0x754>
 101fb35:	mov    $0x3,%eax
 101fb3a:	mov    -0x2c(%rbp),%ecx
 101fb3d:	cmp    0x70(%r8),%ecx
 101fb41:	ja     101f964 <schedule_clone+0x754>
 101fb47:	mov    %rdi,-0x48(%rbp)
 101fb4b:	lea    -0x90(%rbp),%rsi
 101fb52:	lea    -0x68(%rbp),%rdx
 101fb56:	mov    %r8,%rdi
 101fb59:	call   *(%r11)
 101fb5c:	mov    -0x68(%rbp),%rdx
 101fb60:	test   %eax,%eax
 101fb62:	je     101fdbb <schedule_clone+0xbab>
 101fb68:	test   %rdx,%rdx
 101fb6b:	je     101f964 <schedule_clone+0x754>
 101fb71:	jmp    101fe24 <schedule_clone+0xc14>
 101fb76:	mov    %r9,-0x70(%rbp)
 101fb7a:	mov    %rdx,-0x58(%rbp)
 101fb7e:	mov    %r11d,-0x50(%rbp)
 101fb82:	mov    %rdi,-0x48(%rbp)
 101fb86:	mov    %rsi,-0x40(%rbp)
 101fb8a:	mov    %r10,-0x60(%rbp)
 101fb8e:	mov    $0x1,%edi
 101fb93:	mov    %r8,%rsi
 101fb96:	mov    %r8,-0x78(%rbp)
 101fb9a:	call   1027690 <calloc@plt>
 101fb9f:	mov    %rax,%rcx
 101fba2:	mov    $0x1,%eax
 101fba7:	test   %rcx,%rcx
 101fbaa:	je     101faf6 <schedule_clone+0x8e6>
 101fbb0:	mov    -0x58(%rbp),%rdi
 101fbb4:	mov    -0x38(%rbp),%rax
 101fbb8:	mov    %rax,0x18(%rdi)
 101fbbc:	mov    -0x70(%rbp),%rax
 101fbc0:	mov    -0x78(%rbp),%rdx
 101fbc4:	add    %rdx,0x30(%rax)
 101fbc8:	test   %r13,%r13
 101fbcb:	je     101fbf1 <schedule_clone+0x9e1>
 101fbcd:	shl    $0x3,%r13
 101fbd1:	lea    0x0(,%r13,4),%rdx
 101fbd9:	add    %r13,%rdx
 101fbdc:	mov    %rcx,%rdi
 101fbdf:	mov    %r14,%rsi
 101fbe2:	mov    %rcx,%r13
 101fbe5:	call   10276a0 <memcpy@plt>
 101fbea:	mov    %r13,%rcx
 101fbed:	mov    -0x58(%rbp),%rdi
 101fbf1:	test   %r14,%r14
 101fbf4:	je     101fc3a <schedule_clone+0xa2a>
 101fbf6:	mov    %rcx,%r13
 101fbf9:	mov    0x10(%r12),%rax
 101fbfe:	shl    $0x3,%rax
 101fc02:	lea    (%rax,%rax,4),%rcx
 101fc06:	mov    0x18(%rdi),%rax
 101fc0a:	sub    %rcx,%rax
 101fc0d:	jb     101fe24 <schedule_clone+0xc14>
 101fc13:	mov    0x1608(%rdi),%rdx
 101fc1a:	mov    0x30(%rdx),%rsi
 101fc1e:	sub    %rcx,%rsi
 101fc21:	jb     101fe24 <schedule_clone+0xc14>
 101fc27:	mov    %rax,0x18(%rdi)
 101fc2b:	mov    %rsi,0x30(%rdx)
 101fc2f:	mov    %r14,%rdi
 101fc32:	call   10276f0 <free@plt>
 101fc37:	mov    %r13,%rcx
 101fc3a:	mov    %r15,0x10(%r12)
 101fc3f:	mov    %rcx,(%r12)
 101fc43:	mov    $0x1,%r8b
 101fc46:	mov    -0x60(%rbp),%r10
 101fc4a:	mov    -0x2c(%rbp),%edx
 101fc4d:	mov    -0x40(%rbp),%rsi
 101fc51:	mov    -0x48(%rbp),%rdi
 101fc55:	mov    -0x50(%rbp),%r11d
 101fc59:	test   %edx,%edx
 101fc5b:	jne    101f7b3 <schedule_clone+0x5a3>
 101fc61:	jmp    101f7cc <schedule_clone+0x5bc>
 101fc66:	mov    0x98(%r12),%rcx
 101fc6e:	lea    (%rcx,%rcx,2),%rcx
 101fc72:	lea    (%r12,%rcx,8),%rcx
 101fc76:	add    $0x38,%rcx
 101fc7a:	jmp    101fd71 <schedule_clone+0xb61>
 101fc7f:	mov    %rcx,-0x78(%rbp)
 101fc83:	mov    %r8d,-0x38(%rbp)
 101fc87:	mov    %r11d,-0x50(%rbp)
 101fc8b:	mov    %rdi,-0x48(%rbp)
 101fc8f:	mov    %rsi,-0x40(%rbp)
 101fc93:	mov    %edx,-0x2c(%rbp)
 101fc96:	mov    %r10,-0x60(%rbp)
 101fc9a:	mov    $0x1,%edi
 101fc9f:	lea    0x0(,%r13,8),%rsi
 101fca7:	call   1027690 <calloc@plt>
 101fcac:	mov    %rax,%rcx
 101fcaf:	mov    $0x1,%eax
 101fcb4:	test   %rcx,%rcx
 101fcb7:	je     101faf6 <schedule_clone+0x8e6>
 101fcbd:	mov    -0x78(%rbp),%rax
 101fcc1:	mov    %r14,0x18(%rax)
 101fcc5:	mov    -0x70(%rbp),%rax
 101fcc9:	lea    0x0(,%r13,8),%rdx
 101fcd1:	add    %rdx,0x30(%rax)
 101fcd5:	test   %r15,%r15
 101fcd8:	mov    -0x58(%rbp),%r14
 101fcdc:	je     101fcf6 <schedule_clone+0xae6>
 101fcde:	shl    $0x3,%r15
 101fce2:	mov    %rcx,%rdi
 101fce5:	mov    %r14,%rsi
 101fce8:	mov    %r15,%rdx
 101fceb:	mov    %rcx,%r15
 101fcee:	call   10276a0 <memcpy@plt>
 101fcf3:	mov    %r15,%rcx
 101fcf6:	test   %r14,%r14
 101fcf9:	je     101fd3f <schedule_clone+0xb2f>
 101fcfb:	mov    %r14,%rdi
 101fcfe:	mov    %rcx,%r14
 101fd01:	mov    0x28(%r12),%rcx
 101fd06:	shl    $0x3,%rcx
 101fd0a:	mov    -0x78(%rbp),%r8
 101fd0e:	mov    0x18(%r8),%rax
 101fd12:	sub    %rcx,%rax
 101fd15:	jb     101fe24 <schedule_clone+0xc14>
 101fd1b:	mov    0x1608(%r8),%rdx
 101fd22:	mov    0x30(%rdx),%rsi
 101fd26:	sub    %rcx,%rsi
 101fd29:	jb     101fe24 <schedule_clone+0xc14>
 101fd2f:	mov    %rax,0x18(%r8)
 101fd33:	mov    %rsi,0x30(%rdx)
 101fd37:	call   10276f0 <free@plt>
 101fd3c:	mov    %r14,%rcx
 101fd3f:	mov    %r13,0x28(%r12)
 101fd44:	mov    %rcx,0x18(%r12)
 101fd49:	mov    -0x60(%rbp),%r10
 101fd4d:	mov    -0x2c(%rbp),%edx
 101fd50:	mov    -0x40(%rbp),%rsi
 101fd54:	mov    -0x48(%rbp),%rdi
 101fd58:	mov    -0x50(%rbp),%r11d
 101fd5c:	mov    -0x38(%rbp),%r8d
 101fd60:	jmp    101f7cc <schedule_clone+0x5bc>
 101fd65:	mov    -0x38(%rbp),%r9d
 101fd69:	lea    (%r8,%r8,2),%rcx
 101fd6d:	lea    (%rsi,%rcx,8),%rcx
 101fd71:	mov    %r14,(%rcx)
 101fd74:	mov    %rax,0x8(%rcx)
 101fd78:	mov    %edx,0x10(%rcx)
 101fd7b:	movl   $0x0,0x14(%rcx)
 101fd82:	incq   0x98(%r12)
 101fd8a:	mov    -0x68(%rbp),%rax
 101fd8e:	test   %r9b,%r9b
 101fd91:	jne    101fa54 <schedule_clone+0x844>
 101fd97:	test   %edx,%edx
 101fd99:	je     101fdb2 <schedule_clone+0xba2>
 101fd9b:	mov    0x18(%r12),%rcx
 101fda0:	mov    0x20(%r12),%rdx
 101fda5:	lea    0x1(%rdx),%rsi
 101fda9:	mov    %rsi,0x20(%r12)
 101fdae:	mov    %rax,(%rcx,%rdx,8)
 101fdb2:	mov    %rax,0x0(%r13)
 101fdb6:	jmp    101f48d <schedule_clone+0x27d>
 101fdbb:	test   %rdx,%rdx
 101fdbe:	mov    -0x48(%rbp),%rax
 101fdc2:	je     101fe24 <schedule_clone+0xc14>
 101fdc4:	mov    (%rax),%rdi
 101fdc7:	mov    0x8(%rbx),%rsi
 101fdcb:	mov    -0x88(%rbp),%r8
 101fdd2:	mov    %r14,%rcx
 101fdd5:	call   101ca40 <myl_rc_value_seed>
 101fdda:	xor    %eax,%eax
 101fddc:	jmp    101f964 <schedule_clone+0x754>
 101fde1:	xor    %r8d,%r8d
 101fde4:	mov    -0x48(%rbp),%rdi
 101fde8:	mov    0x30(%r12),%rax
 101fded:	test   %rax,%rax
 101fdf0:	jne    101f6ad <schedule_clone+0x49d>
 101fdf6:	jmp    101f6ed <schedule_clone+0x4dd>
 101fdfb:	mov    %rdi,%rcx
 101fdfe:	mov    %rax,%rdi
 101fe01:	mov    %rsi,%r9
 101fe04:	mov    %r8,%rsi
 101fe07:	mov    %r11d,%r8d
 101fe0a:	call   1018f74 <myl_rc_binding_find_slow>
 101fe0f:	mov    %r8d,%r11d
 101fe12:	mov    %rcx,%rdi
 101fe15:	mov    %r9,%rsi
 101fe18:	mov    %rax,%rbx
 101fe1b:	test   %rbx,%rbx
 101fe1e:	jne    101f752 <schedule_clone+0x542>
 101fe24:	call   1018954 <myl_rc_invariant_failed>
 101fe29:	int3
 101fe2a:	int3
 101fe2b:	int3
 101fe2c:	int3
 101fe2d:	int3
 101fe2e:	int3
 101fe2f:	int3

000000000101fe30 <transfer_pointer>:
 101fe30:	push   %rbp
 101fe31:	mov    %rsp,%rbp
 101fe34:	push   %r15
 101fe36:	push   %r14
 101fe38:	push   %r13
 101fe3a:	push   %r12
 101fe3c:	push   %rbx
 101fe3d:	sub    $0x48,%rsp
 101fe41:	mov    (%rdx),%rdx
 101fe44:	cmp    $0x5,%ecx
 101fe47:	jne    101fe5c <transfer_pointer+0x2c>
 101fe49:	add    $0x48,%rsp
 101fe4d:	pop    %rbx
 101fe4e:	pop    %r12
 101fe50:	pop    %r13
 101fe52:	pop    %r14
 101fe54:	pop    %r15
 101fe56:	pop    %rbp
 101fe57:	jmp    1020a90 <transfer_hold>
 101fe5c:	test   %rdx,%rdx
 101fe5f:	je     101ffb7 <transfer_pointer+0x187>
 101fe65:	mov    -0x10(%rdx),%rcx
 101fe69:	test   $0x2,%cl
 101fe6c:	jne    101ffb7 <transfer_pointer+0x187>
 101fe72:	bt     $0x3e,%rcx
 101fe77:	jb     101fe8b <transfer_pointer+0x5b>
 101fe79:	xor    %eax,%eax
 101fe7b:	bt     $0x3c,%rcx
 101fe80:	jae    101fec9 <transfer_pointer+0x99>
 101fe82:	mov    0x20(%rdi),%r8d
 101fe86:	jmp    101ff8c <transfer_pointer+0x15c>
 101fe8b:	mov    %rcx,%rax
 101fe8e:	shr    $0x28,%rax
 101fe92:	and    $0xfffff,%eax
 101fe97:	mov    0x20(%rdi),%r8d
 101fe9b:	cmp    %r8d,%eax
 101fe9e:	jbe    101febe <transfer_pointer+0x8e>
 101fea0:	mov    0x28(%rdi),%rax
 101fea4:	cmpl   $0x0,0xa8(%rax)
 101feab:	mov    %r8d,%eax
 101feae:	jne    101ff8c <transfer_pointer+0x15c>
 101feb4:	mov    $0x3,%eax
 101feb9:	jmp    101ffbc <transfer_pointer+0x18c>
 101febe:	bt     $0x3c,%rcx
 101fec3:	jb     101ff8c <transfer_pointer+0x15c>
 101fec9:	movabs $0x2000000000000000,%r11
 101fed3:	mov    0x28(%rdi),%r13
 101fed7:	cmpl   $0x0,0xac(%r13)
 101fedf:	sete   %r8b
 101fee3:	mov    %rcx,%r9
 101fee6:	shr    $0x3d,%r9
 101feea:	and    $0x1,%r9d
 101feee:	or     %r8b,%r9b
 101fef1:	jne    101ff6b <transfer_pointer+0x13b>
 101fef3:	mov    -0x8(%rdx),%r8
 101fef7:	cmp    $0x100b618,%r8
 101fefe:	setne  %r9b
 101ff02:	cmp    $0x100b510,%r8
 101ff09:	setne  %r10b
 101ff0d:	and    %r9b,%r10b
 101ff10:	cmp    $0x100b4a0,%r8
 101ff17:	setne  %r8b
 101ff1b:	test   %r8b,%r10b
 101ff1e:	jne    101ff6b <transfer_pointer+0x13b>
 101ff20:	bt     $0x3c,%rcx
 101ff25:	jb     1020146 <transfer_pointer+0x316>
 101ff2b:	mov    0xb0(%r13),%rbx
 101ff32:	mov    0xb8(%r13),%r15
 101ff39:	mov    0xc0(%r13),%rcx
 101ff40:	cmp    %rcx,%r15
 101ff43:	jae    101ffcb <transfer_pointer+0x19b>
 101ff49:	mov    %rbx,%r14
 101ff4c:	test   %rbx,%rbx
 101ff4f:	je     102003e <transfer_pointer+0x20e>
 101ff55:	mov    %r14,0xb0(%r13)
 101ff5c:	lea    0x1(%r15),%rcx
 101ff60:	mov    %rcx,0xb8(%r13)
 101ff67:	mov    %rdx,(%r14,%r15,8)
 101ff6b:	cmpl   $0x0,0x24(%rdi)
 101ff6f:	jne    101ffb7 <transfer_pointer+0x187>
 101ff71:	test   %eax,%eax
 101ff73:	je     1020048 <transfer_pointer+0x218>
 101ff79:	mov    0x28(%rdi),%rax
 101ff7d:	cmpl   $0x0,0xac(%rax)
 101ff84:	jne    101ffb7 <transfer_pointer+0x187>
 101ff86:	or     %r11,-0x10(%rdx)
 101ff8a:	jmp    101ffb7 <transfer_pointer+0x187>
 101ff8c:	mov    %rsi,%rbx
 101ff8f:	mov    0x28(%rdi),%rcx
 101ff93:	cmpl   $0x0,0xac(%rcx)
 101ff9a:	cmove  %r8d,%eax
 101ff9e:	lea    -0x70(%rbp),%rcx
 101ffa2:	mov    %rdx,%rsi
 101ffa5:	mov    %eax,%edx
 101ffa7:	call   101f210 <schedule_clone>
 101ffac:	test   %eax,%eax
 101ffae:	jne    101ffbc <transfer_pointer+0x18c>
 101ffb0:	mov    -0x70(%rbp),%rdx
 101ffb4:	mov    %rbx,%rsi
 101ffb7:	mov    %rdx,(%rsi)
 101ffba:	xor    %eax,%eax
 101ffbc:	add    $0x48,%rsp
 101ffc0:	pop    %rbx
 101ffc1:	pop    %r12
 101ffc3:	pop    %r13
 101ffc5:	pop    %r14
 101ffc7:	pop    %r15
 101ffc9:	pop    %rbp
 101ffca:	ret
 101ffcb:	lea    (%rcx,%rcx,1),%r8
 101ffcf:	test   %rcx,%rcx
 101ffd2:	mov    $0x10,%r12d
 101ffd8:	cmovne %r8,%r12
 101ffdc:	cmp    %rcx,%r12
 101ffdf:	setb   %cl
 101ffe2:	lea    -0x1(%r11),%r8
 101ffe6:	cmp    %r8,%r12
 101ffe9:	seta   %r8b
 101ffed:	or     %cl,%r8b
 101fff0:	jne    102003e <transfer_pointer+0x20e>
 101fff2:	mov    (%rdi),%r8
 101fff5:	test   %r8,%r8
 101fff8:	je     1020146 <transfer_pointer+0x316>
 101fffe:	test   %r12,%r12
 1020001:	je     1020146 <transfer_pointer+0x316>
 1020007:	mov    0x1608(%r8),%r9
 102000e:	test   %r9,%r9
 1020011:	je     1020146 <transfer_pointer+0x316>
 1020017:	lea    0x0(,%r12,8),%r10
 102001f:	mov    0x18(%r8),%r11
 1020023:	add    %r10,%r11
 1020026:	jb     1020036 <transfer_pointer+0x206>
 1020028:	mov    0x58(%r8),%rcx
 102002c:	test   %rcx,%rcx
 102002f:	je     1020069 <transfer_pointer+0x239>
 1020031:	cmp    %rcx,%r11
 1020034:	jbe    1020069 <transfer_pointer+0x239>
 1020036:	movl   $0x1,0x6c(%r8)
 102003e:	mov    $0x1,%eax
 1020043:	jmp    101ffbc <transfer_pointer+0x18c>
 1020048:	mov    %rsi,%rbx
 102004b:	mov    %rdx,%r14
 102004e:	mov    %rdx,%rdi
 1020051:	call   1020c50 <myl_rc_owner_take>
 1020056:	test   %eax,%eax
 1020058:	jne    101ffbc <transfer_pointer+0x18c>
 102005e:	mov    %rbx,%rsi
 1020061:	mov    %r14,%rdx
 1020064:	jmp    101ffb7 <transfer_pointer+0x187>
 1020069:	mov    %r11,-0x30(%rbp)
 102006d:	mov    %r9,-0x38(%rbp)
 1020071:	mov    %r8,-0x40(%rbp)
 1020075:	mov    %rax,-0x68(%rbp)
 1020079:	mov    %rdi,-0x60(%rbp)
 102007d:	mov    %rdx,-0x58(%rbp)
 1020081:	mov    %rsi,-0x50(%rbp)
 1020085:	mov    $0x1,%edi
 102008a:	mov    %r10,%rsi
 102008d:	call   1027690 <calloc@plt>
 1020092:	mov    %rax,%r14
 1020095:	test   %rax,%rax
 1020098:	mov    $0x1,%eax
 102009d:	je     101ffbc <transfer_pointer+0x18c>
 10200a3:	mov    -0x40(%rbp),%rcx
 10200a7:	mov    -0x30(%rbp),%rsi
 10200ab:	mov    %rsi,0x18(%rcx)
 10200af:	mov    -0x38(%rbp),%rdx
 10200b3:	lea    0x0(,%r12,8),%r8
 10200bb:	add    0x30(%rdx),%r8
 10200bf:	mov    %r8,0x30(%rdx)
 10200c3:	test   %r15,%r15
 10200c6:	je     10200ef <transfer_pointer+0x2bf>
 10200c8:	lea    0x0(,%r15,8),%rdx
 10200d0:	mov    %r14,%rdi
 10200d3:	mov    %rbx,%rsi
 10200d6:	mov    %r8,-0x48(%rbp)
 10200da:	call   10276a0 <memcpy@plt>
 10200df:	mov    -0x30(%rbp),%rsi
 10200e3:	mov    -0x48(%rbp),%r8
 10200e7:	mov    -0x38(%rbp),%rdx
 10200eb:	mov    -0x40(%rbp),%rcx
 10200ef:	test   %rbx,%rbx
 10200f2:	je     1020120 <transfer_pointer+0x2f0>
 10200f4:	mov    0xc0(%r13),%rax
 10200fb:	shl    $0x3,%rax
 10200ff:	sub    %rax,%rsi
 1020102:	jb     1020146 <transfer_pointer+0x316>
 1020104:	sub    %rax,%r8
 1020107:	jb     1020146 <transfer_pointer+0x316>
 1020109:	mov    %rsi,0x18(%rcx)
 102010d:	mov    %r8,0x30(%rdx)
 1020111:	mov    %rbx,%rdi
 1020114:	call   10276f0 <free@plt>
 1020119:	mov    0xb8(%r13),%r15
 1020120:	mov    %r12,0xc0(%r13)
 1020127:	mov    -0x50(%rbp),%rsi
 102012b:	mov    -0x58(%rbp),%rdx
 102012f:	mov    -0x60(%rbp),%rdi
 1020133:	mov    -0x68(%rbp),%rax
 1020137:	movabs $0x2000000000000000,%r11
 1020141:	jmp    101ff55 <transfer_pointer+0x125>
 1020146:	call   1018954 <myl_rc_invariant_failed>
 102014b:	int3
 102014c:	int3
 102014d:	int3
 102014e:	int3
 102014f:	int3

0000000001020150 <finish_clones>:
 1020150:	push   %rbp
 1020151:	mov    %rsp,%rbp
 1020154:	push   %r15
 1020156:	push   %r14
 1020158:	push   %r13
 102015a:	push   %r12
 102015c:	push   %rbx
 102015d:	sub    $0xa8,%rsp
 1020164:	mov    0x28(%rdi),%rbx
 1020168:	movl   $0x0,0x24(%rdi)
 102016f:	mov    0x8(%rbx),%rax
 1020173:	test   %rax,%rax
 1020176:	je     10207e6 <finish_clones+0x696>
 102017c:	mov    %rdi,%r14
 102017f:	mov    %rdi,-0x30(%rbp)
 1020183:	mov    %rbx,-0x90(%rbp)
 102018a:	jmp    10201ac <finish_clones+0x5c>
 102018c:	nopl   0x0(%rax)
 1020190:	decq   0x8(%rbx)
 1020194:	mov    -0x30(%rbp),%r14
 1020198:	mov    -0x90(%rbp),%rbx
 102019f:	mov    0x8(%rbx),%rax
 10201a3:	test   %rax,%rax
 10201a6:	je     10207e6 <finish_clones+0x696>
 10201ac:	mov    (%rbx),%rdx
 10201af:	lea    (%rax,%rax,4),%rsi
 10201b3:	lea    (%rdx,%rsi,8),%rcx
 10201b7:	mov    -0x18(%rdx,%rsi,8),%rsi
 10201bc:	mov    0x38(%rsi),%r10
 10201c0:	test   %r10,%r10
 10201c3:	je     1020550 <finish_clones+0x400>
 10201c9:	movq   $0x0,-0xa0(%rbp)
 10201d4:	mov    (%r14),%rdi
 10201d7:	mov    -0x28(%rcx),%rsi
 10201db:	mov    -0x20(%rcx),%rdx
 10201df:	add    $0xfffffffffffffff0,%rcx
 10201e3:	lea    -0xa0(%rbp),%rax
 10201ea:	mov    %rax,(%rsp)
 10201ee:	lea    -0x88(%rbp),%r8
 10201f5:	lea    -0xc0(%rbp),%r9
 10201fc:	call   *%r10
 10201ff:	test   %eax,%eax
 1020201:	je     1020190 <finish_clones+0x40>
 1020203:	mov    -0xa0(%rbp),%rax
 102020a:	mov    %rax,-0x98(%rbp)
 1020211:	mov    (%r14),%rbx
 1020214:	mov    -0xc0(%rbp),%rcx
 102021b:	mov    0x1608(%rbx),%r15
 1020222:	mov    0x58(%r15),%rax
 1020226:	mov    0x60(%r15),%rdx
 102022a:	movzbl 0x70(%r15),%esi
 102022f:	mov    %rcx,%rdi
 1020232:	movabs $0x9e3779b97f4a7c15,%r8
 102023c:	imul   %r8,%rdi
 1020240:	shrx   %rsi,%rdi,%rsi
 1020245:	data16 cs nopw 0x0(%rax,%rax,1)
 1020250:	and    %rdx,%rsi
 1020253:	mov    %rsi,%rdi
 1020256:	shl    $0x4,%rdi
 102025a:	mov    (%rax,%rdi,1),%rdi
 102025e:	cmp    %rcx,%rdi
 1020261:	je     1020280 <finish_clones+0x130>
 1020263:	test   %rdi,%rdi
 1020266:	je     1020817 <finish_clones+0x6c7>
 102026c:	inc    %rsi
 102026f:	jmp    1020250 <finish_clones+0x100>
 1020271:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1020280:	shl    $0x4,%rsi
 1020284:	mov    0x8(%rax,%rsi,1),%rsi
 1020289:	test   %rsi,%rsi
 102028c:	je     1020817 <finish_clones+0x6c7>
 1020292:	mov    -0x88(%rbp),%rax
 1020299:	test   %rax,%rax
 102029c:	je     1020817 <finish_clones+0x6c7>
 10202a2:	mov    (%rax),%rax
 10202a5:	cmp    (%rsi),%rax
 10202a8:	jne    1020817 <finish_clones+0x6c7>
 10202ae:	mov    0x28(%rsi),%rcx
 10202b2:	cmp    $0x2,%rcx
 10202b6:	mov    %rsi,-0x58(%rbp)
 10202ba:	jb     10203a7 <finish_clones+0x257>
 10202c0:	mov    0x10(%r14),%r12
 10202c4:	cmp    %r12,%rcx
 10202c7:	jbe    10203a7 <finish_clones+0x257>
 10202cd:	cmpq   $0x0,0x18(%r14)
 10202d2:	jne    1020817 <finish_clones+0x6c7>
 10202d8:	mov    %rcx,%rax
 10202db:	shr    $0x3b,%rax
 10202df:	jne    1020817 <finish_clones+0x6c7>
 10202e5:	test   %rbx,%rbx
 10202e8:	je     1020817 <finish_clones+0x6c7>
 10202ee:	test   %r15,%r15
 10202f1:	je     1020817 <finish_clones+0x6c7>
 10202f7:	mov    %rcx,%r14
 10202fa:	shl    $0x5,%r14
 10202fe:	mov    0x18(%rbx),%r13
 1020302:	add    %r14,%r13
 1020305:	jb     10207fa <finish_clones+0x6aa>
 102030b:	mov    0x58(%rbx),%rax
 102030f:	test   %rax,%rax
 1020312:	je     102031d <finish_clones+0x1cd>
 1020314:	cmp    %rax,%r13
 1020317:	ja     10207fa <finish_clones+0x6aa>
 102031d:	mov    %rcx,-0x48(%rbp)
 1020321:	mov    $0x1,%edi
 1020326:	mov    %r14,%rsi
 1020329:	call   1027690 <calloc@plt>
 102032e:	test   %rax,%rax
 1020331:	je     1020810 <finish_clones+0x6c0>
 1020337:	mov    %r13,0x18(%rbx)
 102033b:	add    0x30(%r15),%r14
 102033f:	mov    %r14,0x30(%r15)
 1020343:	mov    -0x48(%rbp),%rdx
 1020347:	mov    %rdx,%rcx
 102034a:	cmp    $0x9,%r12
 102034e:	jb     1020397 <finish_clones+0x247>
 1020350:	mov    -0x30(%rbp),%rcx
 1020354:	mov    0x8(%rcx),%rdi
 1020358:	mov    %rdx,%rcx
 102035b:	test   %rdi,%rdi
 102035e:	je     1020397 <finish_clones+0x247>
 1020360:	mov    %rax,-0x40(%rbp)
 1020364:	shl    $0x5,%r12
 1020368:	sub    %r12,%r13
 102036b:	jb     1020817 <finish_clones+0x6c7>
 1020371:	sub    %r12,%r14
 1020374:	jb     1020817 <finish_clones+0x6c7>
 102037a:	mov    %r13,0x18(%rbx)
 102037e:	mov    %r14,0x30(%r15)
 1020382:	call   10276f0 <free@plt>
 1020387:	mov    -0x58(%rbp),%rax
 102038b:	mov    0x28(%rax),%rcx
 102038f:	mov    -0x40(%rbp),%rax
 1020393:	mov    -0x48(%rbp),%rdx
 1020397:	mov    -0x30(%rbp),%r14
 102039b:	mov    %rax,0x8(%r14)
 102039f:	mov    %rdx,0x10(%r14)
 10203a3:	mov    -0x58(%rbp),%rsi
 10203a7:	mov    -0x70(%rbp),%eax
 10203aa:	mov    %eax,0x20(%r14)
 10203ae:	cmpq   $0x0,-0x98(%rbp)
 10203b6:	je     1020194 <finish_clones+0x44>
 10203bc:	mov    -0xb8(%rbp),%r13
 10203c3:	mov    -0x80(%rbp),%r14
 10203c7:	xor    %edx,%edx
 10203c9:	mov    %rcx,-0x48(%rbp)
 10203cd:	jmp    1020412 <finish_clones+0x2c2>
 10203cf:	nop
 10203d0:	mov    $0x101fe30,%r8d
 10203d6:	mov    -0x30(%rbp),%rdi
 10203da:	mov    %r14,%rdx
 10203dd:	mov    %r13,%rcx
 10203e0:	call   101ef10 <visit>
 10203e5:	test   %eax,%eax
 10203e7:	jne    10207e8 <finish_clones+0x698>
 10203ed:	mov    -0x40(%rbp),%rdx
 10203f1:	inc    %rdx
 10203f4:	mov    -0x58(%rbp),%rsi
 10203f8:	mov    (%rsi),%rax
 10203fb:	add    %rax,%r14
 10203fe:	add    %rax,%r13
 1020401:	cmp    -0x98(%rbp),%rdx
 1020408:	mov    -0x48(%rbp),%rcx
 102040c:	je     1020194 <finish_clones+0x44>
 1020412:	cmp    $0x2,%rcx
 1020416:	mov    %rdx,-0x40(%rbp)
 102041a:	ja     10203d0 <finish_clones+0x280>
 102041c:	mov    0x8(%rsi),%eax
 102041f:	mov    %rax,-0x50(%rbp)
 1020423:	dec    %eax
 1020425:	cmp    $0x4,%eax
 1020428:	ja     102048e <finish_clones+0x33e>
 102042a:	jmp    *0x1001be8(,%rax,8)
 1020431:	mov    $0x1,%ecx
 1020436:	jmp    1020490 <finish_clones+0x340>
 1020438:	mov    0x10(%rsi),%rdx
 102043c:	mov    0x18(%rsi),%rcx
 1020440:	mov    0x20(%rsi),%r12
 1020444:	add    %r13,%r12
 1020447:	mov    $0x4,%eax
 102044c:	mov    %rax,-0x50(%rbp)
 1020450:	movq   $0x0,-0x38(%rbp)
 1020458:	jmp    102049d <finish_clones+0x34d>
 102045a:	mov    0x10(%rsi),%rdx
 102045e:	mov    0x18(%rsi),%rcx
 1020462:	mov    $0x2,%eax
 1020467:	mov    %rax,-0x50(%rbp)
 102046b:	movq   $0x0,-0x38(%rbp)
 1020473:	jmp    102049a <finish_clones+0x34a>
 1020475:	mov    0x10(%rsi),%rax
 1020479:	mov    0x18(%rsi),%rcx
 102047d:	mov    0x20(%rsi),%rdx
 1020481:	mov    %rdx,-0x38(%rbp)
 1020485:	mov    0x8(%rax),%eax
 1020488:	mov    %rax,-0x50(%rbp)
 102048c:	jmp    1020498 <finish_clones+0x348>
 102048e:	xor    %ecx,%ecx
 1020490:	movq   $0x0,-0x38(%rbp)
 1020498:	xor    %edx,%edx
 102049a:	xor    %r12d,%r12d
 102049d:	mov    %rcx,%r15
 10204a0:	neg    %r15
 10204a3:	xor    %ebx,%ebx
 10204a5:	mov    %rcx,-0x68(%rbp)
 10204a9:	mov    %rdx,-0x60(%rbp)
 10204ad:	test   %rdx,%rdx
 10204b0:	je     1020510 <finish_clones+0x3c0>
 10204b2:	cmp    %rcx,%rbx
 10204b5:	jae    10203ed <finish_clones+0x29d>
 10204bb:	lea    (%rbx,%rbx,2),%rax
 10204bf:	lea    (%rdx,%rax,8),%rax
 10204c3:	inc    %rbx
 10204c6:	jmp    10204e8 <finish_clones+0x398>
 10204c8:	nopl   0x0(%rax,%rax,1)
 10204d0:	add    $0x18,%rax
 10204d4:	lea    (%r15,%rbx,1),%rcx
 10204d8:	inc    %rcx
 10204db:	inc    %rbx
 10204de:	cmp    $0x1,%rcx
 10204e2:	je     10203ed <finish_clones+0x29d>
 10204e8:	mov    0x8(%rax),%rcx
 10204ec:	mov    0x8(%rcx),%ecx
 10204ef:	test   %ecx,%ecx
 10204f1:	je     10204d0 <finish_clones+0x380>
 10204f3:	test   %r12,%r12
 10204f6:	je     1020501 <finish_clones+0x3b1>
 10204f8:	mov    0x10(%rax),%edx
 10204fb:	cmp    (%r12),%edx
 10204ff:	jne    10204d0 <finish_clones+0x380>
 1020501:	mov    (%rax),%rdx
 1020504:	jmp    102052a <finish_clones+0x3da>
 1020506:	cs nopw 0x0(%rax,%rax,1)
 1020510:	cmp    %rcx,%rbx
 1020513:	je     10203ed <finish_clones+0x29d>
 1020519:	mov    %rbx,%rdx
 102051c:	inc    %rbx
 102051f:	imul   -0x38(%rbp),%rdx
 1020524:	mov    -0x50(%rbp),%rax
 1020528:	mov    %eax,%ecx
 102052a:	lea    (%r14,%rdx,1),%rsi
 102052e:	add    %r13,%rdx
 1020531:	mov    -0x30(%rbp),%rdi
 1020535:	call   101fe30 <transfer_pointer>
 102053a:	test   %eax,%eax
 102053c:	mov    -0x68(%rbp),%rcx
 1020540:	mov    -0x60(%rbp),%rdx
 1020544:	je     10204ad <finish_clones+0x35d>
 102054a:	jmp    10207e8 <finish_clones+0x698>
 102054f:	nop
 1020550:	mov    0x30(%rsi),%r10
 1020554:	test   %r10,%r10
 1020557:	je     102058d <finish_clones+0x43d>
 1020559:	mov    (%r14),%rdi
 102055c:	mov    -0x28(%rcx),%rsi
 1020560:	mov    -0x20(%rcx),%rdx
 1020564:	add    $0xfffffffffffffff0,%rcx
 1020568:	lea    -0x88(%rbp),%r8
 102056f:	lea    -0xc0(%rbp),%r9
 1020576:	call   *%r10
 1020579:	test   %eax,%eax
 102057b:	je     10207d6 <finish_clones+0x686>
 1020581:	mov    -0xc0(%rbp),%rax
 1020588:	jmp    1020626 <finish_clones+0x4d6>
 102058d:	mov    -0x28(%rcx),%rdi
 1020591:	mov    -0x10(%rcx),%rdx
 1020595:	mov    -0x10(%rdi),%rdi
 1020599:	mov    %rdi,%r8
 102059c:	shr    $0x2,%r8
 10205a0:	bt     $0x3e,%rdi
 10205a5:	movabs $0x3fffffffff,%rdi
 10205af:	movabs $0x3ffffffffffffff,%r9
 10205b9:	cmovae %r9,%rdi
 10205bd:	and    %r8,%rdi
 10205c0:	cmp    %rdi,%rdx
 10205c3:	je     10207da <finish_clones+0x68a>
 10205c9:	mov    0x8(%rsi),%rax
 10205cd:	lea    0x1(%rdx),%rsi
 10205d1:	mov    %rsi,-0x10(%rcx)
 10205d5:	imul   (%rax),%rdx
 10205d9:	mov    -0x20(%rcx),%rsi
 10205dd:	lea    (%rsi,%rdx,1),%rdi
 10205e1:	mov    -0x8(%rcx),%r8d
 10205e5:	mov    %rax,-0x88(%rbp)
 10205ec:	mov    %rdi,-0x80(%rbp)
 10205f0:	mov    %rsi,-0x78(%rbp)
 10205f4:	mov    %r8d,-0x70(%rbp)
 10205f8:	movl   $0x0,-0x6c(%rbp)
 10205ff:	mov    -0x28(%rcx),%rcx
 1020603:	add    %rcx,%rdx
 1020606:	mov    %rax,-0xc0(%rbp)
 102060d:	mov    %rdx,-0xb8(%rbp)
 1020614:	mov    %rcx,-0xb0(%rbp)
 102061b:	movq   $0x0,-0xa8(%rbp)
 1020626:	mov    (%r14),%r13
 1020629:	mov    0x1608(%r13),%r15
 1020630:	mov    0x58(%r15),%rcx
 1020634:	mov    0x60(%r15),%rdx
 1020638:	movzbl 0x70(%r15),%esi
 102063d:	mov    %rax,%rdi
 1020640:	movabs $0x9e3779b97f4a7c15,%r8
 102064a:	imul   %r8,%rdi
 102064e:	shrx   %rsi,%rdi,%rsi
 1020653:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1020660:	and    %rdx,%rsi
 1020663:	mov    %rsi,%rdi
 1020666:	shl    $0x4,%rdi
 102066a:	mov    (%rcx,%rdi,1),%rdi
 102066e:	cmp    %rax,%rdi
 1020671:	je     1020690 <finish_clones+0x540>
 1020673:	test   %rdi,%rdi
 1020676:	je     1020817 <finish_clones+0x6c7>
 102067c:	inc    %rsi
 102067f:	jmp    1020660 <finish_clones+0x510>
 1020681:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1020690:	shl    $0x4,%rsi
 1020694:	mov    0x8(%rcx,%rsi,1),%rsi
 1020699:	test   %rsi,%rsi
 102069c:	je     1020817 <finish_clones+0x6c7>
 10206a2:	mov    -0x88(%rbp),%rax
 10206a9:	test   %rax,%rax
 10206ac:	je     1020817 <finish_clones+0x6c7>
 10206b2:	mov    (%rax),%rax
 10206b5:	cmp    (%rsi),%rax
 10206b8:	jne    1020817 <finish_clones+0x6c7>
 10206be:	mov    0x28(%rsi),%r12
 10206c2:	cmp    $0x2,%r12
 10206c6:	jb     10207a5 <finish_clones+0x655>
 10206cc:	mov    0x10(%r14),%rcx
 10206d0:	cmp    %rcx,%r12
 10206d3:	jbe    10207a5 <finish_clones+0x655>
 10206d9:	cmpq   $0x0,0x18(%r14)
 10206de:	jne    1020817 <finish_clones+0x6c7>
 10206e4:	mov    %r12,%rax
 10206e7:	shr    $0x3b,%rax
 10206eb:	jne    1020817 <finish_clones+0x6c7>
 10206f1:	test   %r13,%r13
 10206f4:	je     1020817 <finish_clones+0x6c7>
 10206fa:	test   %r15,%r15
 10206fd:	je     1020817 <finish_clones+0x6c7>
 1020703:	mov    %r12,%r14
 1020706:	shl    $0x5,%r14
 102070a:	mov    0x18(%r13),%rbx
 102070e:	add    %r14,%rbx
 1020711:	jb     1020808 <finish_clones+0x6b8>
 1020717:	mov    0x58(%r13),%rax
 102071b:	test   %rax,%rax
 102071e:	je     1020729 <finish_clones+0x5d9>
 1020720:	cmp    %rax,%rbx
 1020723:	ja     1020808 <finish_clones+0x6b8>
 1020729:	mov    %rcx,-0x40(%rbp)
 102072d:	mov    %rsi,-0x68(%rbp)
 1020731:	mov    $0x1,%edi
 1020736:	mov    %r14,%rsi
 1020739:	call   1027690 <calloc@plt>
 102073e:	test   %rax,%rax
 1020741:	je     1020810 <finish_clones+0x6c0>
 1020747:	mov    %rbx,0x18(%r13)
 102074b:	add    0x30(%r15),%r14
 102074f:	mov    %r14,0x30(%r15)
 1020753:	mov    -0x40(%rbp),%rsi
 1020757:	cmp    $0x9,%rsi
 102075b:	jb     1020795 <finish_clones+0x645>
 102075d:	mov    -0x30(%rbp),%rcx
 1020761:	mov    0x8(%rcx),%rdi
 1020765:	test   %rdi,%rdi
 1020768:	je     1020795 <finish_clones+0x645>
 102076a:	mov    %rax,-0x60(%rbp)
 102076e:	shl    $0x5,%rsi
 1020772:	sub    %rsi,%rbx
 1020775:	jb     1020817 <finish_clones+0x6c7>
 102077b:	sub    %rsi,%r14
 102077e:	jb     1020817 <finish_clones+0x6c7>
 1020784:	mov    %rbx,0x18(%r13)
 1020788:	mov    %r14,0x30(%r15)
 102078c:	call   10276f0 <free@plt>
 1020791:	mov    -0x60(%rbp),%rax
 1020795:	mov    -0x30(%rbp),%r14
 1020799:	mov    %rax,0x8(%r14)
 102079d:	mov    %r12,0x10(%r14)
 10207a1:	mov    -0x68(%rbp),%rsi
 10207a5:	mov    -0x70(%rbp),%eax
 10207a8:	mov    %eax,0x20(%r14)
 10207ac:	mov    -0x80(%rbp),%rdx
 10207b0:	mov    -0xb8(%rbp),%rcx
 10207b7:	mov    $0x101fe30,%r8d
 10207bd:	mov    %r14,%rdi
 10207c0:	call   101ef10 <visit>
 10207c5:	test   %eax,%eax
 10207c7:	mov    -0x90(%rbp),%rbx
 10207ce:	je     102019f <finish_clones+0x4f>
 10207d4:	jmp    10207e8 <finish_clones+0x698>
 10207d6:	mov    0x8(%rbx),%rax
 10207da:	dec    %rax
 10207dd:	mov    %rax,0x8(%rbx)
 10207e1:	jmp    102019f <finish_clones+0x4f>
 10207e6:	xor    %eax,%eax
 10207e8:	add    $0xa8,%rsp
 10207ef:	pop    %rbx
 10207f0:	pop    %r12
 10207f2:	pop    %r13
 10207f4:	pop    %r14
 10207f6:	pop    %r15
 10207f8:	pop    %rbp
 10207f9:	ret
 10207fa:	movl   $0x1,0x6c(%rbx)
 1020801:	mov    $0x1,%eax
 1020806:	jmp    10207e8 <finish_clones+0x698>
 1020808:	movl   $0x1,0x6c(%r13)
 1020810:	mov    $0x1,%eax
 1020815:	jmp    10207e8 <finish_clones+0x698>
 1020817:	call   1018954 <myl_rc_invariant_failed>
 102081c:	int3
 102081d:	int3
 102081e:	int3
 102081f:	int3

0000000001020820 <rollback_take>:
 1020820:	mov    (%rsi),%rsi
 1020823:	cmp    %rsi,(%rdx)
 1020826:	je     1020871 <rollback_take+0x51>
 1020828:	push   %rbp
 1020829:	mov    %rsp,%rbp
 102082c:	push   %rbx
 102082d:	push   %rax
 102082e:	mov    (%rdi),%rbx
 1020831:	cmp    $0x5,%ecx
 1020834:	jne    1020863 <rollback_take+0x43>
 1020836:	mov    %rbx,%rdi
 1020839:	call   1018e60 <myl_rc_hold_edge_release>
 102083e:	test   %rbx,%rbx
 1020841:	je     102086b <rollback_take+0x4b>
 1020843:	mov    0x1608(%rbx),%rax
 102084a:	test   %rax,%rax
 102084d:	je     102086b <rollback_take+0x4b>
 102084f:	cmpq   $0x0,0xc8(%rax)
 1020857:	je     102086b <rollback_take+0x4b>
 1020859:	mov    %rbx,%rdi
 102085c:	call   101be30 <myl_rc_drain>
 1020861:	jmp    102086b <rollback_take+0x4b>
 1020863:	mov    %rbx,%rdi
 1020866:	call   1018d40 <myl_rc_edge_release>
 102086b:	add    $0x8,%rsp
 102086f:	pop    %rbx
 1020870:	pop    %rbp
 1020871:	xor    %eax,%eax
 1020873:	ret
 1020874:	int3
 1020875:	int3
 1020876:	int3
 1020877:	int3
 1020878:	int3
 1020879:	int3
 102087a:	int3
 102087b:	int3
 102087c:	int3
 102087d:	int3
 102087e:	int3
 102087f:	int3

0000000001020880 <commit_take>:
 1020880:	mov    %rsi,%rax
 1020883:	mov    (%rdx),%rsi
 1020886:	cmp    (%rax),%rsi
 1020889:	je     10208d4 <commit_take+0x54>
 102088b:	push   %rbp
 102088c:	mov    %rsp,%rbp
 102088f:	push   %rbx
 1020890:	push   %rax
 1020891:	mov    (%rdi),%rbx
 1020894:	cmp    $0x5,%ecx
 1020897:	jne    10208c6 <commit_take+0x46>
 1020899:	mov    %rbx,%rdi
 102089c:	call   1018e60 <myl_rc_hold_edge_release>
 10208a1:	test   %rbx,%rbx
 10208a4:	je     10208ce <commit_take+0x4e>
 10208a6:	mov    0x1608(%rbx),%rax
 10208ad:	test   %rax,%rax
 10208b0:	je     10208ce <commit_take+0x4e>
 10208b2:	cmpq   $0x0,0xc8(%rax)
 10208ba:	je     10208ce <commit_take+0x4e>
 10208bc:	mov    %rbx,%rdi
 10208bf:	call   101be30 <myl_rc_drain>
 10208c4:	jmp    10208ce <commit_take+0x4e>
 10208c6:	mov    %rbx,%rdi
 10208c9:	call   1018d40 <myl_rc_edge_release>
 10208ce:	add    $0x8,%rsp
 10208d2:	pop    %rbx
 10208d3:	pop    %rbp
 10208d4:	xor    %eax,%eax
 10208d6:	ret
 10208d7:	int3
 10208d8:	int3
 10208d9:	int3
 10208da:	int3
 10208db:	int3
 10208dc:	int3
 10208dd:	int3
 10208de:	int3
 10208df:	int3

00000000010208e0 <dispose_walk>:
 10208e0:	push   %rbp
 10208e1:	mov    %rsp,%rbp
 10208e4:	push   %r15
 10208e6:	push   %r14
 10208e8:	push   %rbx
 10208e9:	push   %rax
 10208ea:	mov    %rdi,%rbx
 10208ed:	mov    0x28(%rdi),%r14
 10208f1:	test   %esi,%esi
 10208f3:	je     1020919 <dispose_walk+0x39>
 10208f5:	cmpq   $0x0,0x20(%r14)
 10208fa:	je     1020919 <dispose_walk+0x39>
 10208fc:	xor    %r15d,%r15d
 10208ff:	nop
 1020900:	mov    (%rbx),%rdi
 1020903:	mov    0x18(%r14),%rax
 1020907:	mov    (%rax,%r15,8),%rsi
 102090b:	call   101ccd0 <myl_rc_construction_abort>
 1020910:	inc    %r15
 1020913:	cmp    0x20(%r14),%r15
 1020917:	jb     1020900 <dispose_walk+0x20>
 1020919:	mov    (%rbx),%rdi
 102091c:	mov    0xb0(%r14),%rax
 1020923:	test   %rax,%rax
 1020926:	je     1020967 <dispose_walk+0x87>
 1020928:	mov    0xc0(%r14),%rdx
 102092f:	shl    $0x3,%rdx
 1020933:	mov    0x18(%rdi),%rcx
 1020937:	sub    %rdx,%rcx
 102093a:	jb     1020a8a <dispose_walk+0x1aa>
 1020940:	mov    0x1608(%rdi),%rsi
 1020947:	mov    0x30(%rsi),%r8
 102094b:	sub    %rdx,%r8
 102094e:	jb     1020a8a <dispose_walk+0x1aa>
 1020954:	mov    %rcx,0x18(%rdi)
 1020958:	mov    %r8,0x30(%rsi)
 102095c:	mov    %rax,%rdi
 102095f:	call   10276f0 <free@plt>
 1020964:	mov    (%rbx),%rdi
 1020967:	mov    0x18(%r14),%rax
 102096b:	test   %rax,%rax
 102096e:	je     10209ac <dispose_walk+0xcc>
 1020970:	mov    0x28(%r14),%rdx
 1020974:	shl    $0x3,%rdx
 1020978:	mov    0x18(%rdi),%rcx
 102097c:	sub    %rdx,%rcx
 102097f:	jb     1020a8a <dispose_walk+0x1aa>
 1020985:	mov    0x1608(%rdi),%rsi
 102098c:	mov    0x30(%rsi),%r8
 1020990:	sub    %rdx,%r8
 1020993:	jb     1020a8a <dispose_walk+0x1aa>
 1020999:	mov    %rcx,0x18(%rdi)
 102099d:	mov    %r8,0x30(%rsi)
 10209a1:	mov    %rax,%rdi
 10209a4:	call   10276f0 <free@plt>
 10209a9:	mov    (%rbx),%rdi
 10209ac:	mov    0x30(%r14),%rax
 10209b0:	test   %rax,%rax
 10209b3:	je     10209f8 <dispose_walk+0x118>
 10209b5:	mov    0xa0(%r14),%rcx
 10209bc:	shl    $0x3,%rcx
 10209c0:	lea    (%rcx,%rcx,2),%rdx
 10209c4:	mov    0x18(%rdi),%rcx
 10209c8:	sub    %rdx,%rcx
 10209cb:	jb     1020a8a <dispose_walk+0x1aa>
 10209d1:	mov    0x1608(%rdi),%rsi
 10209d8:	mov    0x30(%rsi),%r8
 10209dc:	sub    %rdx,%r8
 10209df:	jb     1020a8a <dispose_walk+0x1aa>
 10209e5:	mov    %rcx,0x18(%rdi)
 10209e9:	mov    %r8,0x30(%rsi)
 10209ed:	mov    %rax,%rdi
 10209f0:	call   10276f0 <free@plt>
 10209f5:	mov    (%rbx),%rdi
 10209f8:	mov    (%r14),%rax
 10209fb:	test   %rax,%rax
 10209fe:	je     1020a38 <dispose_walk+0x158>
 1020a00:	mov    0x10(%r14),%rcx
 1020a04:	shl    $0x3,%rcx
 1020a08:	lea    (%rcx,%rcx,4),%rdx
 1020a0c:	mov    0x18(%rdi),%rcx
 1020a10:	sub    %rdx,%rcx
 1020a13:	jb     1020a8a <dispose_walk+0x1aa>
 1020a15:	mov    0x1608(%rdi),%rsi
 1020a1c:	mov    0x30(%rsi),%r8
 1020a20:	sub    %rdx,%r8
 1020a23:	jb     1020a8a <dispose_walk+0x1aa>
 1020a25:	mov    %rcx,0x18(%rdi)
 1020a29:	mov    %r8,0x30(%rsi)
 1020a2d:	mov    %rax,%rdi
 1020a30:	call   10276f0 <free@plt>
 1020a35:	mov    (%rbx),%rdi
 1020a38:	mov    0x10(%rbx),%rcx
 1020a3c:	cmp    $0x9,%rcx
 1020a40:	jb     1020a7b <dispose_walk+0x19b>
 1020a42:	mov    0x8(%rbx),%rax
 1020a46:	test   %rax,%rax
 1020a49:	je     1020a7b <dispose_walk+0x19b>
 1020a4b:	shl    $0x5,%rcx
 1020a4f:	mov    0x18(%rdi),%rdx
 1020a53:	sub    %rcx,%rdx
 1020a56:	jb     1020a8a <dispose_walk+0x1aa>
 1020a58:	mov    0x1608(%rdi),%rsi
 1020a5f:	mov    0x30(%rsi),%r8
 1020a63:	sub    %rcx,%r8
 1020a66:	jb     1020a8a <dispose_walk+0x1aa>
 1020a68:	mov    %rdx,0x18(%rdi)
 1020a6c:	mov    %r8,0x30(%rsi)
 1020a70:	mov    %rax,%rdi
 1020a73:	call   10276f0 <free@plt>
 1020a78:	mov    (%rbx),%rdi
 1020a7b:	add    $0x8,%rsp
 1020a7f:	pop    %rbx
 1020a80:	pop    %r14
 1020a82:	pop    %r15
 1020a84:	pop    %rbp
 1020a85:	jmp    101be30 <myl_rc_drain>
 1020a8a:	call   1018954 <myl_rc_invariant_failed>
 1020a8f:	int3

0000000001020a90 <transfer_hold>:
 1020a90:	push   %rbp
 1020a91:	mov    %rsp,%rbp
 1020a94:	push   %r15
 1020a96:	push   %r14
 1020a98:	push   %r12
 1020a9a:	push   %rbx
 1020a9b:	sub    $0x10,%rsp
 1020a9f:	test   %rdx,%rdx
 1020aa2:	je     1020bb2 <transfer_hold+0x122>
 1020aa8:	movabs $0x4000000000000002,%r15
 1020ab2:	mov    -0x10(%rdx),%rcx
 1020ab6:	lea    -0x2(%r15),%rax
 1020aba:	test   %rax,%rcx
 1020abd:	je     1020bb6 <transfer_hold+0x126>
 1020ac3:	mov    %rcx,%r8
 1020ac6:	shr    $0x28,%r8
 1020aca:	and    $0xfffff,%r8d
 1020ad1:	mov    0x20(%rdi),%eax
 1020ad4:	cmp    %eax,%r8d
 1020ad7:	jbe    1020bb6 <transfer_hold+0x126>
 1020add:	mov    0x28(%rdi),%rcx
 1020ae1:	cmpl   $0x0,0xa8(%rcx)
 1020ae8:	je     1020bf4 <transfer_hold+0x164>
 1020aee:	lea    -0x28(%rbp),%rcx
 1020af2:	mov    %rdi,%rbx
 1020af5:	mov    %rsi,%r14
 1020af8:	mov    %rdx,%rsi
 1020afb:	mov    %eax,%edx
 1020afd:	call   101f210 <schedule_clone>
 1020b02:	test   %eax,%eax
 1020b04:	jne    1020c06 <transfer_hold+0x176>
 1020b0a:	mov    %rbx,%rax
 1020b0d:	mov    (%rbx),%rbx
 1020b10:	mov    -0x28(%rbp),%rsi
 1020b14:	test   %rsi,%rsi
 1020b17:	je     1020b67 <transfer_hold+0xd7>
 1020b19:	mov    -0x10(%rsi),%rcx
 1020b1d:	test   %r15,%rcx
 1020b20:	jne    1020b67 <transfer_hold+0xd7>
 1020b22:	test   %rbx,%rbx
 1020b25:	je     1020c45 <transfer_hold+0x1b5>
 1020b2b:	cmpq   $0x0,0x1608(%rbx)
 1020b33:	je     1020c45 <transfer_hold+0x1b5>
 1020b39:	test   $0x1,%cl
 1020b3c:	jne    1020c45 <transfer_hold+0x1b5>
 1020b42:	mov    -0x18(%rsi),%rcx
 1020b46:	mov    -0x20(%rsi),%rdx
 1020b4a:	or     %rcx,%rdx
 1020b4d:	je     1020c45 <transfer_hold+0x1b5>
 1020b53:	cmp    $0xffffffffffffffff,%rcx
 1020b57:	je     1020c1a <transfer_hold+0x18a>
 1020b5d:	inc    %rcx
 1020b60:	mov    %rcx,-0x18(%rsi)
 1020b64:	mov    (%rax),%rbx
 1020b67:	mov    %rbx,%rdi
 1020b6a:	mov    %rsi,%r15
 1020b6d:	call   1018d40 <myl_rc_edge_release>
 1020b72:	test   %rbx,%rbx
 1020b75:	je     1020bfb <transfer_hold+0x16b>
 1020b7b:	mov    $0x1,%r12b
 1020b7e:	xor    %eax,%eax
 1020b80:	mov    %r14,%rsi
 1020b83:	mov    0x1608(%rbx),%rcx
 1020b8a:	test   %rcx,%rcx
 1020b8d:	je     1020ba8 <transfer_hold+0x118>
 1020b8f:	cmpq   $0x0,0xc8(%rcx)
 1020b97:	je     1020ba8 <transfer_hold+0x118>
 1020b99:	mov    %rbx,%rdi
 1020b9c:	mov    %eax,%ebx
 1020b9e:	call   101be30 <myl_rc_drain>
 1020ba3:	mov    %ebx,%eax
 1020ba5:	mov    %r14,%rsi
 1020ba8:	test   %r12b,%r12b
 1020bab:	mov    %r15,%rdx
 1020bae:	jne    1020c01 <transfer_hold+0x171>
 1020bb0:	jmp    1020c06 <transfer_hold+0x176>
 1020bb2:	xor    %edx,%edx
 1020bb4:	jmp    1020c01 <transfer_hold+0x171>
 1020bb6:	cmpl   $0x0,0x24(%rdi)
 1020bba:	jne    1020c01 <transfer_hold+0x171>
 1020bbc:	test   %r15,%rcx
 1020bbf:	jne    1020c01 <transfer_hold+0x171>
 1020bc1:	mov    (%rdi),%rax
 1020bc4:	test   %rax,%rax
 1020bc7:	je     1020c45 <transfer_hold+0x1b5>
 1020bc9:	cmpq   $0x0,0x1608(%rax)
 1020bd1:	je     1020c45 <transfer_hold+0x1b5>
 1020bd3:	test   $0x1,%cl
 1020bd6:	jne    1020c45 <transfer_hold+0x1b5>
 1020bd8:	mov    -0x18(%rdx),%rax
 1020bdc:	mov    -0x20(%rdx),%rcx
 1020be0:	or     %rax,%rcx
 1020be3:	je     1020c45 <transfer_hold+0x1b5>
 1020be5:	cmp    $0xffffffffffffffff,%rax
 1020be9:	je     1020c13 <transfer_hold+0x183>
 1020beb:	inc    %rax
 1020bee:	mov    %rax,-0x18(%rdx)
 1020bf2:	jmp    1020c01 <transfer_hold+0x171>
 1020bf4:	mov    $0x3,%eax
 1020bf9:	jmp    1020c06 <transfer_hold+0x176>
 1020bfb:	mov    %r14,%rsi
 1020bfe:	mov    %r15,%rdx
 1020c01:	mov    %rdx,(%rsi)
 1020c04:	xor    %eax,%eax
 1020c06:	add    $0x10,%rsp
 1020c0a:	pop    %rbx
 1020c0b:	pop    %r12
 1020c0d:	pop    %r14
 1020c0f:	pop    %r15
 1020c11:	pop    %rbp
 1020c12:	ret
 1020c13:	mov    $0x2,%eax
 1020c18:	jmp    1020c06 <transfer_hold+0x176>
 1020c1a:	mov    %rbx,%rdi
 1020c1d:	mov    %rsi,%r15
 1020c20:	call   1018d40 <myl_rc_edge_release>
 1020c25:	mov    %r14,%rsi
 1020c28:	mov    $0x2,%eax
 1020c2d:	xor    %r12d,%r12d
 1020c30:	mov    0x1608(%rbx),%rcx
 1020c37:	test   %rcx,%rcx
 1020c3a:	jne    1020b8f <transfer_hold+0xff>
 1020c40:	jmp    1020ba8 <transfer_hold+0x118>
 1020c45:	call   1018954 <myl_rc_invariant_failed>
 1020c4a:	int3
 1020c4b:	int3
 1020c4c:	int3
 1020c4d:	int3
 1020c4e:	int3
 1020c4f:	int3

0000000001020c50 <myl_rc_owner_take>:
 1020c50:	mov    -0x10(%rdi),%rcx
 1020c54:	xor    %eax,%eax
 1020c56:	movabs $0x4000000000000002,%rdx
 1020c60:	test   %rdx,%rcx
 1020c63:	je     1020c66 <myl_rc_owner_take+0x16>
 1020c65:	ret
 1020c66:	test   $0x1,%cl
 1020c69:	jne    1020c8f <myl_rc_owner_take+0x3f>
 1020c6b:	mov    -0x20(%rdi),%rcx
 1020c6f:	cmp    $0xffffffffffffffff,%rcx
 1020c73:	je     1020c89 <myl_rc_owner_take+0x39>
 1020c75:	test   %rcx,%rcx
 1020c78:	jne    1020c81 <myl_rc_owner_take+0x31>
 1020c7a:	cmpq   $0x0,-0x18(%rdi)
 1020c7f:	je     1020c8f <myl_rc_owner_take+0x3f>
 1020c81:	inc    %rcx
 1020c84:	mov    %rcx,-0x20(%rdi)
 1020c88:	ret
 1020c89:	mov    $0x2,%eax
 1020c8e:	ret
 1020c8f:	push   %rbp
 1020c90:	mov    %rsp,%rbp
 1020c93:	call   1018954 <myl_rc_invariant_failed>
 1020c98:	int3
 1020c99:	int3
 1020c9a:	int3
 1020c9b:	int3
 1020c9c:	int3
 1020c9d:	int3
 1020c9e:	int3
 1020c9f:	int3

0000000001020ca0 <retain_pointer>:
 1020ca0:	mov    (%rdx),%rdx
 1020ca3:	test   %rdx,%rdx
 1020ca6:	je     1020ccd <retain_pointer+0x2d>
 1020ca8:	mov    -0x10(%rdx),%r8
 1020cac:	bt     $0x3e,%r8
 1020cb1:	jae    1020cdc <retain_pointer+0x3c>
 1020cb3:	mov    %r8,%r9
 1020cb6:	shr    $0x28,%r9
 1020cba:	and    $0xfffff,%r9d
 1020cc1:	mov    $0x3,%eax
 1020cc6:	cmp    0x20(%rdi),%r9d
 1020cca:	jbe    1020cdc <retain_pointer+0x3c>
 1020ccc:	ret
 1020ccd:	cmp    $0x5,%ecx
 1020cd0:	jne    1020cf9 <retain_pointer+0x59>
 1020cd2:	movq   $0x0,(%rsi)
 1020cd9:	xor    %eax,%eax
 1020cdb:	ret
 1020cdc:	cmp    $0x5,%ecx
 1020cdf:	jne    1020ce6 <retain_pointer+0x46>
 1020ce1:	jmp    1020a90 <transfer_hold>
 1020ce6:	movabs $0x4000000000000000,%rax
 1020cf0:	add    $0x2,%rax
 1020cf4:	test   %rax,%r8
 1020cf7:	je     1020cff <retain_pointer+0x5f>
 1020cf9:	mov    %rdx,(%rsi)
 1020cfc:	xor    %eax,%eax
 1020cfe:	ret
 1020cff:	test   $0x1,%r8b
 1020d03:	jne    1020d2e <retain_pointer+0x8e>
 1020d05:	mov    -0x20(%rdx),%rax
 1020d09:	cmp    $0xffffffffffffffff,%rax
 1020d0d:	je     1020d28 <retain_pointer+0x88>
 1020d0f:	test   %rax,%rax
 1020d12:	jne    1020d1b <retain_pointer+0x7b>
 1020d14:	cmpq   $0x0,-0x18(%rdx)
 1020d19:	je     1020d2e <retain_pointer+0x8e>
 1020d1b:	inc    %rax
 1020d1e:	mov    %rax,-0x20(%rdx)
 1020d22:	mov    %rdx,(%rsi)
 1020d25:	xor    %eax,%eax
 1020d27:	ret
 1020d28:	mov    $0x2,%eax
 1020d2d:	ret
 1020d2e:	push   %rbp
 1020d2f:	mov    %rsp,%rbp
 1020d32:	call   1018954 <myl_rc_invariant_failed>
 1020d37:	int3
 1020d38:	int3
 1020d39:	int3
 1020d3a:	int3
 1020d3b:	int3
 1020d3c:	int3
 1020d3d:	int3
 1020d3e:	int3
 1020d3f:	int3

0000000001020d40 <clone_payload>:
 1020d40:	push   %rbp
 1020d41:	mov    %rsp,%rbp
 1020d44:	push   %r15
 1020d46:	push   %r14
 1020d48:	push   %r13
 1020d4a:	push   %r12
 1020d4c:	push   %rbx
 1020d4d:	sub    $0x208,%rsp
 1020d54:	mov    %rcx,-0x30(%rbp)
 1020d58:	mov    %rdi,%r14
 1020d5b:	vxorps %xmm0,%xmm0,%xmm0
 1020d5f:	vmovups %ymm0,-0x90(%rbp)
 1020d67:	vmovups %ymm0,-0xb0(%rbp)
 1020d6f:	vmovups %ymm0,-0xd0(%rbp)
 1020d77:	vmovups %ymm0,-0xf0(%rbp)
 1020d7f:	vmovups %ymm0,-0x110(%rbp)
 1020d87:	vmovups %ymm0,-0x130(%rbp)
 1020d8f:	movq   $0x0,-0x70(%rbp)
 1020d97:	mov    -0x10(%rsi),%rax
 1020d9b:	xor    %ebx,%ebx
 1020d9d:	bt     $0x3d,%rax
 1020da2:	mov    $0x0,%ecx
 1020da7:	jae    1020dd0 <clone_payload+0x90>
 1020da9:	mov    -0x8(%rsi),%rdi
 1020dad:	mov    $0x1,%ecx
 1020db2:	cmp    $0x100b618,%rdi
 1020db9:	je     1020dd0 <clone_payload+0x90>
 1020dbb:	cmp    $0x100b510,%rdi
 1020dc2:	je     1020dd0 <clone_payload+0x90>
 1020dc4:	xor    %ecx,%ecx
 1020dc6:	cmp    $0x100b4a0,%rdi
 1020dcd:	sete   %cl
 1020dd0:	mov    %rax,%r15
 1020dd3:	shr    $0x28,%r15
 1020dd7:	and    $0xfffff,%r15d
 1020dde:	cmp    %edx,%r15d
 1020de1:	cmovae %edx,%r15d
 1020de5:	mov    %ecx,-0x84(%rbp)
 1020deb:	bt     $0x3e,%rax
 1020df0:	cmovae %ebx,%r15d
 1020df4:	test   %ecx,%ecx
 1020df6:	cmove  %edx,%r15d
 1020dfa:	mov    %r14,-0x68(%rbp)
 1020dfe:	lea    -0x230(%rbp),%rax
 1020e05:	mov    %rax,-0x60(%rbp)
 1020e09:	movq   $0x8,-0x58(%rbp)
 1020e11:	movq   $0x0,-0x50(%rbp)
 1020e19:	mov    %r15d,-0x48(%rbp)
 1020e1d:	movl   $0x0,-0x44(%rbp)
 1020e24:	lea    -0x130(%rbp),%r13
 1020e2b:	mov    %r13,-0x40(%rbp)
 1020e2f:	lea    -0x68(%rbp),%rdi
 1020e33:	lea    -0x38(%rbp),%rcx
 1020e37:	mov    %r15d,%edx
 1020e3a:	vzeroupper
 1020e3d:	call   101f210 <schedule_clone>
 1020e42:	test   %eax,%eax
 1020e44:	jne    1020e5c <clone_payload+0x11c>
 1020e46:	lea    -0x68(%rbp),%rdi
 1020e4a:	call   1020150 <finish_clones>
 1020e4f:	xor    %r12d,%r12d
 1020e52:	mov    -0x40(%rbp),%r13
 1020e56:	test   %eax,%eax
 1020e58:	je     1020e7c <clone_payload+0x13c>
 1020e5a:	xor    %ebx,%ebx
 1020e5c:	mov    %eax,%r12d
 1020e5f:	movq   $0x0,0xb8(%r13)
 1020e6a:	mov    -0x38(%rbp),%r13
 1020e6e:	test   %r15d,%r15d
 1020e71:	je     1020f14 <clone_payload+0x1d4>
 1020e77:	jmp    1020f4c <clone_payload+0x20c>
 1020e7c:	mov    0xb8(%r13),%rsi
 1020e83:	mov    $0x1,%bl
 1020e85:	test   %rsi,%rsi
 1020e88:	je     1020f00 <clone_payload+0x1c0>
 1020e8a:	movabs $0x2000000000000000,%rax
 1020e94:	mov    0xb0(%r13),%rdx
 1020e9b:	mov    %esi,%ecx
 1020e9d:	and    $0x3,%ecx
 1020ea0:	cmp    $0x4,%rsi
 1020ea4:	jae    1020eaa <clone_payload+0x16a>
 1020ea6:	xor    %edi,%edi
 1020ea8:	jmp    1020ee5 <clone_payload+0x1a5>
 1020eaa:	and    $0xfffffffffffffffc,%rsi
 1020eae:	xor    %edi,%edi
 1020eb0:	mov    (%rdx,%rdi,8),%r8
 1020eb4:	or     %rax,-0x10(%r8)
 1020eb8:	mov    0x8(%rdx,%rdi,8),%r8
 1020ebd:	or     %rax,-0x10(%r8)
 1020ec1:	mov    0x10(%rdx,%rdi,8),%r8
 1020ec6:	or     %rax,-0x10(%r8)
 1020eca:	mov    0x18(%rdx,%rdi,8),%r8
 1020ecf:	or     %rax,-0x10(%r8)
 1020ed3:	add    $0x4,%rdi
 1020ed7:	cmp    %rdi,%rsi
 1020eda:	jne    1020eb0 <clone_payload+0x170>
 1020edc:	test   %rcx,%rcx
 1020edf:	je     1020f82 <clone_payload+0x242>
 1020ee5:	lea    (%rdx,%rdi,8),%rdx
 1020ee9:	xor    %r12d,%r12d
 1020eec:	xor    %esi,%esi
 1020eee:	xchg   %ax,%ax
 1020ef0:	mov    (%rdx,%rsi,8),%rdi
 1020ef4:	or     %rax,-0x10(%rdi)
 1020ef8:	inc    %rsi
 1020efb:	cmp    %rsi,%rcx
 1020efe:	jne    1020ef0 <clone_payload+0x1b0>
 1020f00:	movq   $0x0,0xb8(%r13)
 1020f0b:	mov    -0x38(%rbp),%r13
 1020f0f:	test   %r15d,%r15d
 1020f12:	jne    1020f4c <clone_payload+0x20c>
 1020f14:	test   %r12d,%r12d
 1020f17:	je     1020f4c <clone_payload+0x20c>
 1020f19:	test   %r13,%r13
 1020f1c:	je     1020f4c <clone_payload+0x20c>
 1020f1e:	mov    %r14,%rdi
 1020f21:	mov    %r13,%rsi
 1020f24:	call   1018d40 <myl_rc_edge_release>
 1020f29:	test   %r14,%r14
 1020f2c:	je     1020f4c <clone_payload+0x20c>
 1020f2e:	mov    0x1608(%r14),%rax
 1020f35:	test   %rax,%rax
 1020f38:	je     1020f4c <clone_payload+0x20c>
 1020f3a:	cmpq   $0x0,0xc8(%rax)
 1020f42:	je     1020f4c <clone_payload+0x20c>
 1020f44:	mov    %r14,%rdi
 1020f47:	call   101be30 <myl_rc_drain>
 1020f4c:	xor    %esi,%esi
 1020f4e:	test   %r12d,%r12d
 1020f51:	setne  %sil
 1020f55:	lea    -0x68(%rbp),%rdi
 1020f59:	call   10208e0 <dispose_walk>
 1020f5e:	xor    %eax,%eax
 1020f60:	test   %bl,%bl
 1020f62:	cmovne %r13,%rax
 1020f66:	mov    -0x30(%rbp),%rcx
 1020f6a:	mov    %rax,(%rcx)
 1020f6d:	mov    %r12d,%eax
 1020f70:	add    $0x208,%rsp
 1020f77:	pop    %rbx
 1020f78:	pop    %r12
 1020f7a:	pop    %r13
 1020f7c:	pop    %r14
 1020f7e:	pop    %r15
 1020f80:	pop    %rbp
 1020f81:	ret
 1020f82:	xor    %r12d,%r12d
 1020f85:	movq   $0x0,0xb8(%r13)
 1020f90:	mov    -0x38(%rbp),%r13
 1020f94:	test   %r15d,%r15d
 1020f97:	je     1020f14 <clone_payload+0x1d4>
 1020f9d:	jmp    1020f4c <clone_payload+0x20c>
 1020f9f:	int3

0000000001020fa0 <myl_rc_storage_alloc>:
 1020fa0:	push   %rbp
 1020fa1:	mov    %rsp,%rbp
 1020fa4:	push   %r15
 1020fa6:	push   %r14
 1020fa8:	push   %r13
 1020faa:	push   %r12
 1020fac:	push   %rbx
 1020fad:	sub    $0x28,%rsp
 1020fb1:	test   %rdi,%rdi
 1020fb4:	je     102136f <myl_rc_storage_alloc+0x3cf>
 1020fba:	mov    %rsi,%r14
 1020fbd:	test   %rsi,%rsi
 1020fc0:	je     102136f <myl_rc_storage_alloc+0x3cf>
 1020fc6:	mov    %rdi,%rbx
 1020fc9:	mov    0x1608(%rdi),%rdi
 1020fd0:	test   %rdi,%rdi
 1020fd3:	je     102136f <myl_rc_storage_alloc+0x3cf>
 1020fd9:	mov    %ecx,%r12d
 1020fdc:	mov    %rdx,%r15
 1020fdf:	test   %ecx,%ecx
 1020fe1:	setne  %al
 1020fe4:	cmp    $0x1,%rdx
 1020fe8:	setne  %cl
 1020feb:	or     %al,%cl
 1020fed:	jne    1020ff8 <myl_rc_storage_alloc+0x58>
 1020fef:	cmpq   $0x10213b0,(%rdi)
 1020ff6:	je     1021071 <myl_rc_storage_alloc+0xd1>
 1020ff8:	cmp    %r14,0x110(%rdi)
 1020fff:	je     1021015 <myl_rc_storage_alloc+0x75>
 1021001:	mov    %rbx,%rdi
 1021004:	mov    %r14,%rsi
 1021007:	call   10234b0 <myl_rc_native_shape>
 102100c:	test   %rax,%rax
 102100f:	je     1021359 <myl_rc_storage_alloc+0x3b9>
 1021015:	test   %r12d,%r12d
 1021018:	setne  %al
 102101b:	cmp    $0x2,%r15
 102101f:	setb   %cl
 1021022:	or     %al,%cl
 1021024:	jne    10212c8 <myl_rc_storage_alloc+0x328>
 102102a:	mov    (%r14),%r13
 102102d:	test   %r13,%r13
 1021030:	je     10212c8 <myl_rc_storage_alloc+0x328>
 1021036:	cmpq   $0x10,0x8(%r14)
 102103b:	ja     10212c8 <myl_rc_storage_alloc+0x328>
 1021041:	mov    0x1608(%rbx),%rax
 1021048:	cmpq   $0x10213b0,(%rax)
 102104f:	jne    10212c8 <myl_rc_storage_alloc+0x328>
 1021055:	cmp    $0x1fe0,%r13
 102105c:	ja     10211e4 <myl_rc_storage_alloc+0x244>
 1021062:	mov    $0x1fe0,%eax
 1021067:	xor    %edx,%edx
 1021069:	div    %r13d
 102106c:	jmp    10211e6 <myl_rc_storage_alloc+0x246>
 1021071:	mov    0x20(%rdi),%r13
 1021075:	cmp    %r14,0x210(%r13)
 102107c:	je     102111f <myl_rc_storage_alloc+0x17f>
 1021082:	mov    0x34(%r14),%eax
 1021086:	cmp    %rax,0xa0(%rdi)
 102108d:	jbe    102128d <myl_rc_storage_alloc+0x2ed>
 1021093:	mov    0x98(%rdi),%rcx
 102109a:	shl    $0x4,%rax
 102109e:	cmp    %r14,(%rcx,%rax,1)
 10210a2:	jne    102128d <myl_rc_storage_alloc+0x2ed>
 10210a8:	add    %rax,%rcx
 10210ab:	mov    0x8(%rcx),%rax
 10210af:	test   %rax,%rax
 10210b2:	je     102129e <myl_rc_storage_alloc+0x2fe>
 10210b8:	mov    0xc0(%rax),%esi
 10210be:	test   %esi,%esi
 10210c0:	je     102129e <myl_rc_storage_alloc+0x2fe>
 10210c6:	dec    %esi
 10210c8:	mov    %r14,0x210(%r13)
 10210cf:	mov    %rsi,0x218(%r13)
 10210d6:	mov    0x1610(%rbx,%rsi,8),%r15
 10210de:	test   %r15,%r15
 10210e1:	jne    1021133 <myl_rc_storage_alloc+0x193>
 10210e3:	mov    %rbx,%rdi
 10210e6:	call   1022030 <slab_refill>
 10210eb:	mov    %rax,%r15
 10210ee:	test   %rax,%rax
 10210f1:	jne    102113e <myl_rc_storage_alloc+0x19e>
 10210f3:	mov    0x1608(%rbx),%rax
 10210fa:	test   %rax,%rax
 10210fd:	je     102136f <myl_rc_storage_alloc+0x3cf>
 1021103:	cmpl   $0x0,0x124(%rax)
 102110a:	jne    1021359 <myl_rc_storage_alloc+0x3b9>
 1021110:	movl   $0x1,0x124(%rax)
 102111a:	jmp    1021359 <myl_rc_storage_alloc+0x3b9>
 102111f:	mov    0x218(%r13),%rsi
 1021126:	mov    0x1610(%rbx,%rsi,8),%r15
 102112e:	test   %r15,%r15
 1021131:	je     10210e3 <myl_rc_storage_alloc+0x143>
 1021133:	mov    (%r15),%rax
 1021136:	mov    %rax,0x1610(%rbx,%rsi,8)
 102113e:	lea    0x20(%r15),%rax
 1021142:	mov    (%r14),%rdx
 1021145:	lea    0xf(%rdx),%rcx
 1021149:	shr    $0x4,%rcx
 102114d:	cmp    $0x8,%rcx
 1021151:	ja     102122e <myl_rc_storage_alloc+0x28e>
 1021157:	jmp    *0x1001c10(,%rcx,8)
 102115e:	vxorps %xmm0,%xmm0,%xmm0
 1021162:	vmovaps %xmm0,0x90(%r15)
 102116b:	vxorps %xmm0,%xmm0,%xmm0
 102116f:	vmovaps %xmm0,0x80(%r15)
 1021178:	vxorps %xmm0,%xmm0,%xmm0
 102117c:	vmovaps %xmm0,0x70(%r15)
 1021182:	vxorps %xmm0,%xmm0,%xmm0
 1021186:	vmovaps %xmm0,0x60(%r15)
 102118c:	vxorps %xmm0,%xmm0,%xmm0
 1021190:	vmovaps %xmm0,0x50(%r15)
 1021196:	vxorps %xmm0,%xmm0,%xmm0
 102119a:	vmovaps %xmm0,0x40(%r15)
 10211a0:	vxorps %xmm0,%xmm0,%xmm0
 10211a4:	vmovaps %xmm0,0x30(%r15)
 10211aa:	vxorps %xmm0,%xmm0,%xmm0
 10211ae:	vmovaps %xmm0,(%rax)
 10211b2:	movq   $0x1,(%r15)
 10211b9:	movq   $0x0,0x8(%r15)
 10211c1:	movq   $0x4,0x10(%r15)
 10211c9:	mov    %r14,0x18(%r15)
 10211cd:	vmovdqu 0x40(%rbx),%xmm0
 10211d2:	vpcmpeqd %xmm1,%xmm1,%xmm1
 10211d6:	vpsubq %xmm1,%xmm0,%xmm0
 10211da:	vmovdqu %xmm0,0x40(%rbx)
 10211df:	jmp    102135b <myl_rc_storage_alloc+0x3bb>
 10211e4:	xor    %eax,%eax
 10211e6:	cmp    %rax,%r15
 10211e9:	ja     10212c8 <myl_rc_storage_alloc+0x328>
 10211ef:	imul   %r15,%r13
 10211f3:	lea    0x20(%r13),%rax
 10211f7:	mov    $0x20,%esi
 10211fc:	cmp    $0x2000,%rax
 1021202:	ja     1021213 <myl_rc_storage_alloc+0x273>
 1021204:	lea    0x2f(%r13),%rax
 1021208:	shr    $0x4,%rax
 102120c:	movzbl 0x100b820(%rax),%esi
 1021213:	mov    0x1610(%rbx,%rsi,8),%r12
 102121b:	test   %r12,%r12
 102121e:	je     1021243 <myl_rc_storage_alloc+0x2a3>
 1021220:	mov    (%r12),%rax
 1021224:	mov    %rax,0x1610(%rbx,%rsi,8)
 102122c:	jmp    1021257 <myl_rc_storage_alloc+0x2b7>
 102122e:	mov    %rax,%rdi
 1021231:	xor    %esi,%esi
 1021233:	mov    %rax,%r12
 1021236:	call   1027650 <memset@plt>
 102123b:	mov    %r12,%rax
 102123e:	jmp    10211b2 <myl_rc_storage_alloc+0x212>
 1021243:	mov    %rbx,%rdi
 1021246:	call   1022030 <slab_refill>
 102124b:	mov    %rax,%r12
 102124e:	test   %rax,%rax
 1021251:	je     10210f3 <myl_rc_storage_alloc+0x153>
 1021257:	lea    0x20(%r12),%rdi
 102125c:	mov    %r13,%rsi
 102125f:	call   10223d0 <zero_payload>
 1021264:	lea    0x20(%r12),%rax
 1021269:	movq   $0x1,(%r12)
 1021271:	movq   $0x0,0x8(%r12)
 102127a:	shl    $0x2,%r15
 102127e:	mov    %r15,0x10(%r12)
 1021283:	mov    %r14,0x18(%r12)
 1021288:	jmp    10211cd <myl_rc_storage_alloc+0x22d>
 102128d:	mov    %r14,%rsi
 1021290:	call   1018f74 <myl_rc_binding_find_slow>
 1021295:	test   %rax,%rax
 1021298:	jne    10210b8 <myl_rc_storage_alloc+0x118>
 102129e:	mov    %rbx,%rdi
 10212a1:	mov    %r14,%rsi
 10212a4:	call   10234b0 <myl_rc_native_shape>
 10212a9:	test   %rax,%rax
 10212ac:	je     1021359 <myl_rc_storage_alloc+0x3b9>
 10212b2:	cmpq   $0x10,0x8(%r14)
 10212b7:	ja     10212c8 <myl_rc_storage_alloc+0x328>
 10212b9:	mov    (%r14),%rax
 10212bc:	cmp    $0x1fe0,%rax
 10212c2:	jbe    1021374 <myl_rc_storage_alloc+0x3d4>
 10212c8:	mov    %r14,-0x48(%rbp)
 10212cc:	mov    %r15,-0x40(%rbp)
 10212d0:	mov    %r12d,-0x38(%rbp)
 10212d4:	movl   $0x0,-0x34(%rbp)
 10212db:	mov    0x1608(%rbx),%r8
 10212e2:	test   %r8,%r8
 10212e5:	je     102136f <myl_rc_storage_alloc+0x3cf>
 10212eb:	movq   $0x0,-0x30(%rbp)
 10212f3:	mov    %r15,%rax
 10212f6:	mulq   (%r14)
 10212f9:	mov    $0x1,%ecx
 10212fe:	jo     1021348 <myl_rc_storage_alloc+0x3a8>
 1021300:	xor    %edx,%edx
 1021302:	test   %r12d,%r12d
 1021305:	sete   %dl
 1021308:	shl    $0x4,%edx
 102130b:	add    $0x10,%rdx
 102130f:	add    %rdx,%rax
 1021312:	jb     1021348 <myl_rc_storage_alloc+0x3a8>
 1021314:	mov    $0x3,%ecx
 1021319:	cmp    0x70(%rbx),%r12d
 102131d:	ja     1021348 <myl_rc_storage_alloc+0x3a8>
 102131f:	lea    -0x48(%rbp),%rsi
 1021323:	lea    -0x30(%rbp),%rdx
 1021327:	mov    %rbx,%rdi
 102132a:	call   *(%r8)
 102132d:	mov    %eax,%ecx
 102132f:	mov    -0x30(%rbp),%rax
 1021333:	test   %ecx,%ecx
 1021335:	je     102136a <myl_rc_storage_alloc+0x3ca>
 1021337:	test   %rax,%rax
 102133a:	jne    102136f <myl_rc_storage_alloc+0x3cf>
 102133c:	mov    0x1608(%rbx),%r8
 1021343:	test   %r8,%r8
 1021346:	je     102136f <myl_rc_storage_alloc+0x3cf>
 1021348:	cmpl   $0x0,0x124(%r8)
 1021350:	jne    1021359 <myl_rc_storage_alloc+0x3b9>
 1021352:	mov    %ecx,0x124(%r8)
 1021359:	xor    %eax,%eax
 102135b:	add    $0x28,%rsp
 102135f:	pop    %rbx
 1021360:	pop    %r12
 1021362:	pop    %r13
 1021364:	pop    %r14
 1021366:	pop    %r15
 1021368:	pop    %rbp
 1021369:	ret
 102136a:	test   %rax,%rax
 102136d:	jne    102135b <myl_rc_storage_alloc+0x3bb>
 102136f:	call   1018954 <myl_rc_invariant_failed>
 1021374:	add    $0x2f,%rax
 1021378:	shr    $0x4,%rax
 102137c:	movzbl 0x100b820(%rax),%r15d
 1021384:	mov    0x1608(%rbx),%rdi
 102138b:	mov    %r14,%rsi
 102138e:	call   1022000 <myl_rc_binding_find>
 1021393:	mov    %r15,%rsi
 1021396:	mov    %esi,%ecx
 1021398:	inc    %ecx
 102139a:	mov    %ecx,0xc0(%rax)
 10213a0:	jmp    10210c8 <myl_rc_storage_alloc+0x128>
 10213a5:	int3
 10213a6:	int3
 10213a7:	int3
 10213a8:	int3
 10213a9:	int3
 10213aa:	int3
 10213ab:	int3
 10213ac:	int3
 10213ad:	int3
 10213ae:	int3
 10213af:	int3

00000000010213b0 <allocate>:
 10213b0:	push   %rbp
 10213b1:	mov    %rsp,%rbp
 10213b4:	push   %r15
 10213b6:	push   %r14
 10213b8:	push   %r13
 10213ba:	push   %r12
 10213bc:	push   %rbx
 10213bd:	sub    $0x48,%rsp
 10213c1:	mov    %rdi,%rbx
 10213c4:	movq   $0x0,(%rdx)
 10213cb:	mov    0x10(%rsi),%r15d
 10213cf:	mov    (%rsi),%r13
 10213d2:	test   %r15,%r15
 10213d5:	je     10213fe <allocate+0x4e>
 10213d7:	mov    0x8(%rsi),%rsi
 10213db:	mov    %rsi,%rax
 10213de:	shr    $0x26,%rax
 10213e2:	setne  %al
 10213e5:	cmp    $0x100000,%r15d
 10213ec:	setae  %cl
 10213ef:	or     %al,%cl
 10213f1:	je     10214b6 <allocate+0x106>
 10213f7:	xor    %ecx,%ecx
 10213f9:	jmp    1021edf <allocate+0xb2f>
 10213fe:	mov    $0x1,%eax
 1021403:	test   %r13,%r13
 1021406:	je     1021eea <allocate+0xb3a>
 102140c:	cmpq   $0x10,0x8(%r13)
 1021411:	ja     1021eea <allocate+0xb3a>
 1021417:	mov    0x8(%rsi),%rdi
 102141b:	mov    %rdi,%rcx
 102141e:	shr    $0x3a,%rcx
 1021422:	jne    1021eea <allocate+0xb3a>
 1021428:	mov    0x0(%r13),%r14
 102142c:	test   %r14,%r14
 102142f:	je     1021454 <allocate+0xa4>
 1021431:	mov    $0xffffffffffffffdf,%rax
 1021438:	mov    %rdx,%rcx
 102143b:	xor    %edx,%edx
 102143d:	div    %r14
 1021440:	mov    %rcx,%rdx
 1021443:	mov    %rax,%rcx
 1021446:	mov    $0x1,%eax
 102144b:	cmp    %rcx,%rdi
 102144e:	ja     1021eea <allocate+0xb3a>
 1021454:	test   %rbx,%rbx
 1021457:	je     1021ff8 <allocate+0xc48>
 102145d:	cmpq   $0x0,0x1608(%rbx)
 1021465:	je     1021ff8 <allocate+0xc48>
 102146b:	imul   %rdi,%r14
 102146f:	lea    0x20(%r14),%r12
 1021473:	cmp    $0x2000,%r12
 102147a:	ja     1021938 <allocate+0x588>
 1021480:	mov    %rsi,%r12
 1021483:	mov    %rdx,%r13
 1021486:	lea    0x2f(%r14),%rax
 102148a:	shr    $0x4,%rax
 102148e:	movzbl 0x100b820(%rax),%esi
 1021495:	mov    0x1610(%rbx,%rsi,8),%r15
 102149d:	test   %r15,%r15
 10214a0:	je     1021bce <allocate+0x81e>
 10214a6:	mov    (%r15),%rax
 10214a9:	mov    %rax,0x1610(%rbx,%rsi,8)
 10214b1:	jmp    1021be7 <allocate+0x837>
 10214b6:	mov    %r15d,%r10d
 10214b9:	mov    0x0(%r13),%r14
 10214bd:	mov    %rsi,-0x70(%rbp)
 10214c1:	imul   %rsi,%r14
 10214c5:	cmp    $0x1,%r14
 10214c9:	mov    %r14,%r11
 10214cc:	adc    $0x0,%r11
 10214d0:	cmpl   $0x0,0x68(%rbx)
 10214d4:	je     10214e0 <allocate+0x130>
 10214d6:	cmpl   $0x0,0x74(%rbx)
 10214da:	je     10215b7 <allocate+0x207>
 10214e0:	mov    0x11a0(%rbx),%rax
 10214e7:	test   %rax,%rax
 10214ea:	je     10215f9 <allocate+0x249>
 10214f0:	mov    0x5c0(%rbx),%rcx
 10214f7:	mov    0x5c8(%rbx),%rsi
 10214fe:	mov    %rsi,%rdi
 1021501:	sub    %rcx,%rdi
 1021504:	sub    $0x10,%rdi
 1021508:	setb   %r8b
 102150c:	cmp    %r10d,0x20(%rax)
 1021510:	jne    1021590 <allocate+0x1e0>
 1021512:	test   %r8b,%r8b
 1021515:	jne    1021590 <allocate+0x1e0>
 1021517:	cmp    %rdi,%r11
 102151a:	ja     1021590 <allocate+0x1e0>
 102151c:	shl    $0x28,%r15
 1021520:	mov    -0x70(%rbp),%rdi
 1021524:	lea    (%r15,%rdi,4),%rdi
 1021528:	movabs $0x4000000000000000,%r8
 1021532:	or     %rdi,%r8
 1021535:	mov    %r8,(%rcx)
 1021538:	mov    %r13,0x8(%rcx)
 102153c:	incq   0x18(%rax)
 1021540:	lea    0x50(%rax),%rdi
 1021544:	sub    %rdi,%r11
 1021547:	lea    (%r11,%rcx,1),%rdi
 102154b:	add    $0x1f,%rdi
 102154f:	and    $0xfffffffffffffff0,%rdi
 1021553:	mov    0x8(%rax),%r8
 1021557:	add    $0xffffffffffffffb0,%r8
 102155b:	cmp    %r8,%rdi
 102155e:	lea    0x50(%rax,%rdi,1),%rax
 1021563:	cmovb  %rax,%rsi
 1021567:	mov    %rsi,0x5c0(%rbx)
 102156e:	vmovdqu 0x40(%rbx),%xmm0
 1021573:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1021577:	vpsubq %xmm1,%xmm0,%xmm0
 102157b:	vmovdqu %xmm0,0x40(%rbx)
 1021580:	incq   0x90(%rbx)
 1021587:	add    $0x10,%rcx
 102158b:	jmp    1021edf <allocate+0xb2f>
 1021590:	lea    0x5c0(%rbx),%rsi
 1021597:	sub    %rax,%rcx
 102159a:	add    $0xffffffffffffffb0,%rcx
 102159e:	mov    %rcx,0x10(%rax)
 10215a2:	movq   $0x0,0x11a0(%rbx)
 10215ad:	vpxor  %xmm0,%xmm0,%xmm0
 10215b1:	vmovdqu %xmm0,(%rsi)
 10215b5:	jmp    10215f9 <allocate+0x249>
 10215b7:	mov    %r11,-0x38(%rbp)
 10215bb:	mov    %r10d,-0x2c(%rbp)
 10215bf:	mov    %rdx,%r12
 10215c2:	cmpq   $0x0,0x1608(%rbx)
 10215ca:	je     10215d6 <allocate+0x226>
 10215cc:	mov    %rbx,%rdi
 10215cf:	call   101be30 <myl_rc_drain>
 10215d4:	jmp    10215de <allocate+0x22e>
 10215d6:	mov    %rbx,%rdi
 10215d9:	call   10156b0 <collect>
 10215de:	mov    %r12,%rdx
 10215e1:	mov    -0x2c(%rbp),%r10d
 10215e5:	mov    -0x38(%rbp),%r11
 10215e9:	mov    0x11a0(%rbx),%rax
 10215f0:	test   %rax,%rax
 10215f3:	jne    10214f0 <allocate+0x140>
 10215f9:	cmp    %r15,0x11e8(%rbx)
 1021600:	jbe    1021624 <allocate+0x274>
 1021602:	mov    0x4d8(%rbx),%rax
 1021609:	mov    (%rax,%r15,8),%r12
 102160d:	test   %r12,%r12
 1021610:	je     1021624 <allocate+0x274>
 1021612:	mov    0x10(%r12),%rax
 1021617:	cmp    $0xfffffffffffffff1,%rax
 102161b:	jb     1021632 <allocate+0x282>
 102161d:	mov    0x8(%r12),%rcx
 1021622:	jmp    1021664 <allocate+0x2b4>
 1021624:	xor    %eax,%eax
 1021626:	cmp    $0xffffffffffffff90,%r14
 102162a:	ja     10213f7 <allocate+0x47>
 1021630:	jmp    1021680 <allocate+0x2d0>
 1021632:	add    $0xf,%rax
 1021636:	and    $0xfffffffffffffff0,%rax
 102163a:	mov    0x8(%r12),%rcx
 102163f:	lea    -0x50(%rcx),%rsi
 1021643:	sub    %rax,%rsi
 1021646:	jb     1021664 <allocate+0x2b4>
 1021648:	sub    $0x10,%rsi
 102164c:	setb   %dil
 1021650:	cmp    %rsi,%r11
 1021653:	seta   %sil
 1021657:	or     %dil,%sil
 102165a:	cmp    $0x1,%sil
 102165e:	jne    1021dad <allocate+0x9fd>
 1021664:	cmp    $0x80000,%rcx
 102166b:	mov    $0x80000,%eax
 1021670:	cmovb  %rcx,%rax
 1021674:	add    %eax,%eax
 1021676:	cmp    $0xffffffffffffff90,%r14
 102167a:	ja     10213f7 <allocate+0x47>
 1021680:	mov    %r13,-0x58(%rbp)
 1021684:	lea    0x6f(%r11),%r12
 1021688:	and    $0xfffffffffffffff0,%r12
 102168c:	cmp    %r12,%rax
 102168f:	cmovbe %r12,%rax
 1021693:	cmp    $0x10001,%rax
 1021699:	mov    $0x10000,%r9d
 102169f:	cmovae %rax,%r9
 10216a3:	mov    0x1608(%rbx),%r13
 10216aa:	mov    0x11f0(%rbx),%rcx
 10216b1:	test   %r13,%r13
 10216b4:	mov    %r9,-0x48(%rbp)
 10216b8:	je     1021737 <allocate+0x387>
 10216ba:	cmp    %r15,%rcx
 10216bd:	jbe    102186c <allocate+0x4bc>
 10216c3:	mov    %rcx,-0x50(%rbp)
 10216c7:	movq   $0x0,-0x68(%rbp)
 10216cf:	mov    -0x58(%rbp),%r13
 10216d3:	lea    0x4e0(%rbx),%r14
 10216da:	mov    0x4e0(%rbx),%rdi
 10216e1:	test   %rdi,%rdi
 10216e4:	mov    %r11,-0x38(%rbp)
 10216e8:	je     1021919 <allocate+0x569>
 10216ee:	xor    %eax,%eax
 10216f0:	mov    %rdi,%r8
 10216f3:	mov    %r14,%rcx
 10216f6:	jmp    102170f <allocate+0x35f>
 10216f8:	nopl   0x0(%rax,%rax,1)
 1021700:	mov    %rsi,%rax
 1021703:	mov    (%rcx),%r8
 1021706:	test   %r8,%r8
 1021709:	je     10218c0 <allocate+0x510>
 102170f:	mov    %rcx,%rsi
 1021712:	mov    %r8,%rcx
 1021715:	mov    0x8(%r8),%r8
 1021719:	cmp    %r12,%r8
 102171c:	jb     1021703 <allocate+0x353>
 102171e:	cmp    %r9,%r8
 1021721:	ja     1021703 <allocate+0x353>
 1021723:	test   %rax,%rax
 1021726:	je     1021700 <allocate+0x350>
 1021728:	mov    (%rax),%r9
 102172b:	cmp    0x8(%r9),%r8
 102172f:	mov    -0x48(%rbp),%r9
 1021733:	ja     1021700 <allocate+0x350>
 1021735:	jmp    1021703 <allocate+0x353>
 1021737:	cmp    %r15,%rcx
 102173a:	mov    %r10d,-0x2c(%rbp)
 102173e:	ja     10217c1 <allocate+0x411>
 1021744:	mov    %r11,-0x38(%rbp)
 1021748:	mov    %rdx,-0x40(%rbp)
 102174c:	test   %rcx,%rcx
 102174f:	mov    $0x8,%eax
 1021754:	cmovne %rcx,%rax
 1021758:	nopl   0x0(%rax,%rax,1)
 1021760:	mov    %rax,%r13
 1021763:	add    %rax,%rax
 1021766:	cmp    %r15,%r13
 1021769:	jbe    1021760 <allocate+0x3b0>
 102176b:	mov    0x4d8(%rbx),%rdi
 1021772:	lea    0x0(,%r13,8),%rsi
 102177a:	call   10277f0 <realloc@plt>
 102177f:	test   %rax,%rax
 1021782:	je     1021bc3 <allocate+0x813>
 1021788:	mov    0x11f0(%rbx),%rcx
 102178f:	lea    (%rax,%rcx,8),%rdi
 1021793:	mov    %r13,%rdx
 1021796:	sub    %rcx,%rdx
 1021799:	shl    $0x3,%rdx
 102179d:	xor    %esi,%esi
 102179f:	mov    %rax,%r14
 10217a2:	call   1027650 <memset@plt>
 10217a7:	mov    %r14,0x4d8(%rbx)
 10217ae:	mov    %r13,0x11f0(%rbx)
 10217b5:	mov    -0x40(%rbp),%rdx
 10217b9:	mov    -0x38(%rbp),%r11
 10217bd:	mov    -0x48(%rbp),%r9
 10217c1:	mov    0x18(%rbx),%rcx
 10217c5:	mov    0x58(%rbx),%rax
 10217c9:	mov    %rax,%rsi
 10217cc:	sub    %rcx,%rsi
 10217cf:	jb     10217d6 <allocate+0x426>
 10217d1:	cmp    %rsi,%r12
 10217d4:	jbe    10217fe <allocate+0x44e>
 10217d6:	cmpl   $0x0,0x74(%rbx)
 10217da:	jne    10217fe <allocate+0x44e>
 10217dc:	mov    %rbx,%rdi
 10217df:	mov    %rdx,%r14
 10217e2:	mov    %r11,-0x38(%rbp)
 10217e6:	call   1015680 <myl_native_heap_collect>
 10217eb:	mov    -0x48(%rbp),%r9
 10217ef:	mov    -0x38(%rbp),%r11
 10217f3:	mov    %r14,%rdx
 10217f6:	mov    0x18(%rbx),%rcx
 10217fa:	mov    0x58(%rbx),%rax
 10217fe:	xor    %esi,%esi
 1021800:	sub    %rcx,%rax
 1021803:	cmovae %rax,%rsi
 1021807:	cmp    %rsi,%r12
 102180a:	ja     10218b2 <allocate+0x502>
 1021810:	mov    %rsi,%r14
 1021813:	and    $0xfffffffffffffff0,%r14
 1021817:	cmp    %rsi,%r9
 102181a:	cmovb  %r9,%r14
 102181e:	mov    0x4e0(%rbx),%rsi
 1021825:	test   %rsi,%rsi
 1021828:	je     1021a1f <allocate+0x66f>
 102182e:	lea    0x4e0(%rbx),%rcx
 1021835:	xor    %eax,%eax
 1021837:	jmp    1021848 <allocate+0x498>
 1021839:	mov    %rdi,%rax
 102183c:	mov    (%rcx),%rsi
 102183f:	test   %rsi,%rsi
 1021842:	je     10219c6 <allocate+0x616>
 1021848:	mov    %rcx,%rdi
 102184b:	mov    %rsi,%rcx
 102184e:	mov    0x8(%rsi),%rsi
 1021852:	cmp    %r12,%rsi
 1021855:	jb     102183c <allocate+0x48c>
 1021857:	cmp    %r14,%rsi
 102185a:	ja     102183c <allocate+0x48c>
 102185c:	test   %rax,%rax
 102185f:	je     1021839 <allocate+0x489>
 1021861:	mov    (%rax),%r8
 1021864:	cmp    0x8(%r8),%rsi
 1021868:	ja     1021839 <allocate+0x489>
 102186a:	jmp    102183c <allocate+0x48c>
 102186c:	test   %rcx,%rcx
 102186f:	mov    $0x8,%eax
 1021874:	cmovne %rcx,%rax
 1021878:	nopl   0x0(%rax,%rax,1)
 1021880:	mov    %rax,%r14
 1021883:	add    %rax,%rax
 1021886:	cmp    %r15,%r14
 1021889:	jbe    1021880 <allocate+0x4d0>
 102188b:	lea    0x0(,%r14,8),%rsi
 1021893:	mov    0x18(%rbx),%rdi
 1021897:	add    %rsi,%rdi
 102189a:	jb     10218b2 <allocate+0x502>
 102189c:	mov    0x58(%rbx),%rax
 10218a0:	test   %rax,%rax
 10218a3:	je     1021b4f <allocate+0x79f>
 10218a9:	cmp    %rax,%rdi
 10218ac:	jbe    1021b4f <allocate+0x79f>
 10218b2:	movl   $0x1,0x6c(%rbx)
 10218b9:	xor    %ecx,%ecx
 10218bb:	jmp    1021edf <allocate+0xb2f>
 10218c0:	test   %rax,%rax
 10218c3:	je     1021919 <allocate+0x569>
 10218c5:	mov    (%rax),%r12
 10218c8:	mov    (%r12),%rcx
 10218cc:	mov    %rcx,(%rax)
 10218cf:	decq   0xc0(%rbx)
 10218d6:	mov    0x8(%r12),%rax
 10218db:	sub    %rax,0xc8(%rbx)
 10218e2:	lea    0x50(%r12),%rdi
 10218e7:	mov    0x10(%r12),%rax
 10218ec:	xor    %esi,%esi
 10218ee:	mov    %rdx,-0x40(%rbp)
 10218f2:	mov    %rax,%rdx
 10218f5:	mov    %r10d,%r14d
 10218f8:	call   1027650 <memset@plt>
 10218fd:	mov    %r14d,%r10d
 1021900:	mov    -0x40(%rbp),%rdx
 1021904:	vpxor  %xmm0,%xmm0,%xmm0
 1021908:	vmovdqa %xmm0,0x10(%r12)
 102190f:	mov    $0xa0,%eax
 1021914:	jmp    1021cda <allocate+0x92a>
 1021919:	mov    0x18(%rbx),%rsi
 102191d:	mov    0x58(%rbx),%rcx
 1021921:	test   %rcx,%rcx
 1021924:	je     1021aba <allocate+0x70a>
 102192a:	xor    %eax,%eax
 102192c:	sub    %rsi,%rcx
 102192f:	cmovae %rcx,%rax
 1021933:	jmp    1021ac0 <allocate+0x710>
 1021938:	cmp    $0xffffffffffffffcf,%r12
 102193c:	ja     1021eea <allocate+0xb3a>
 1021942:	mov    %rsi,-0x70(%rbp)
 1021946:	mov    %rdx,%r13
 1021949:	add    $0x50,%r14
 102194d:	mov    0x18(%rbx),%rax
 1021951:	mov    %rax,%rcx
 1021954:	add    %r14,%rcx
 1021957:	jb     102197d <allocate+0x5cd>
 1021959:	mov    0x58(%rbx),%rcx
 102195d:	test   %rcx,%rcx
 1021960:	je     1021bfd <allocate+0x84d>
 1021966:	sub    %rax,%rcx
 1021969:	setb   %al
 102196c:	cmp    %rcx,%r14
 102196f:	seta   %cl
 1021972:	or     %al,%cl
 1021974:	cmp    $0x1,%cl
 1021977:	jne    1021bfd <allocate+0x84d>
 102197d:	mov    %rbx,%rdi
 1021980:	call   1022440 <trim_empty>
 1021985:	mov    0x18(%rbx),%rax
 1021989:	mov    %rax,%rcx
 102198c:	add    %r14,%rcx
 102198f:	jb     10219b5 <allocate+0x605>
 1021991:	mov    0x58(%rbx),%rcx
 1021995:	test   %rcx,%rcx
 1021998:	je     1021bfd <allocate+0x84d>
 102199e:	sub    %rax,%rcx
 10219a1:	setb   %al
 10219a4:	cmp    %rcx,%r14
 10219a7:	seta   %cl
 10219aa:	or     %al,%cl
 10219ac:	cmp    $0x1,%cl
 10219af:	jne    1021bfd <allocate+0x84d>
 10219b5:	movl   $0x1,0x6c(%rbx)
 10219bc:	mov    $0x1,%eax
 10219c1:	jmp    1021eea <allocate+0xb3a>
 10219c6:	test   %rax,%rax
 10219c9:	je     1021a1f <allocate+0x66f>
 10219cb:	mov    %rdx,%r13
 10219ce:	mov    (%rax),%r12
 10219d1:	mov    (%r12),%rcx
 10219d5:	mov    %rcx,(%rax)
 10219d8:	decq   0xc0(%rbx)
 10219df:	mov    0x8(%r12),%rax
 10219e4:	sub    %rax,0xc8(%rbx)
 10219eb:	lea    0x50(%r12),%rdi
 10219f0:	mov    0x10(%r12),%rdx
 10219f5:	xor    %esi,%esi
 10219f7:	mov    %r11,%r14
 10219fa:	call   1027650 <memset@plt>
 10219ff:	mov    %r14,%r11
 1021a02:	vpxor  %xmm0,%xmm0,%xmm0
 1021a06:	vmovdqa %xmm0,0x10(%r12)
 1021a0d:	incq   0xa0(%rbx)
 1021a14:	mov    0x8(%r12),%r14
 1021a19:	mov    -0x2c(%rbp),%r10d
 1021a1d:	jmp    1021a52 <allocate+0x6a2>
 1021a1f:	mov    %r11,-0x38(%rbp)
 1021a23:	mov    %rdx,%r13
 1021a26:	mov    $0x1,%edi
 1021a2b:	mov    %r14,%rsi
 1021a2e:	call   1027690 <calloc@plt>
 1021a33:	test   %rax,%rax
 1021a36:	je     1021eb2 <allocate+0xb02>
 1021a3c:	mov    %rax,%r12
 1021a3f:	mov    %r14,0x8(%rax)
 1021a43:	incq   0x98(%rbx)
 1021a4a:	mov    -0x2c(%rbp),%r10d
 1021a4e:	mov    -0x38(%rbp),%r11
 1021a52:	add    %r14,0x18(%rbx)
 1021a56:	mov    0x4d8(%rbx),%rax
 1021a5d:	mov    (%rax,%r15,8),%rcx
 1021a61:	mov    %rcx,(%r12)
 1021a65:	mov    %r10d,0x20(%r12)
 1021a6a:	mov    %r12,(%rax,%r15,8)
 1021a6e:	cmp    %r15,0x11e8(%rbx)
 1021a75:	ja     1021a82 <allocate+0x6d2>
 1021a77:	lea    0x1(%r15),%rax
 1021a7b:	mov    %rax,0x11e8(%rbx)
 1021a82:	incq   0xa8(%rbx)
 1021a89:	mov    0xb0(%rbx),%rax
 1021a90:	add    0x8(%r12),%rax
 1021a95:	mov    %rax,0xb0(%rbx)
 1021a9c:	cmp    0xb8(%rbx),%rax
 1021aa3:	mov    %r13,%rdx
 1021aa6:	jbe    1021aaf <allocate+0x6ff>
 1021aa8:	mov    %rax,0xb8(%rbx)
 1021aaf:	xor    %eax,%eax
 1021ab1:	mov    -0x58(%rbp),%r13
 1021ab5:	jmp    1021dad <allocate+0x9fd>
 1021aba:	mov    %rsi,%rax
 1021abd:	not    %rax
 1021ac0:	xor    %ecx,%ecx
 1021ac2:	cmp    %rax,%r12
 1021ac5:	cmovbe %rdi,%rcx
 1021ac9:	mov    %rcx,-0x60(%rbp)
 1021acd:	test   %rdi,%rdi
 1021ad0:	mov    %r10d,-0x2c(%rbp)
 1021ad4:	je     1021c2b <allocate+0x87b>
 1021ada:	cmp    %rax,%r12
 1021add:	jbe    1021c2b <allocate+0x87b>
 1021ae3:	mov    %rdx,%r13
 1021ae6:	jmp    1021afd <allocate+0x74d>
 1021ae8:	nopl   0x0(%rax,%rax,1)
 1021af0:	call   10276f0 <free@plt>
 1021af5:	mov    (%r14),%rdi
 1021af8:	test   %rdi,%rdi
 1021afb:	je     1021b1b <allocate+0x76b>
 1021afd:	mov    (%rdi),%rax
 1021b00:	mov    %rax,0x4e0(%rbx)
 1021b07:	cmpq   $0x0,0x1608(%rbx)
 1021b0f:	je     1021af0 <allocate+0x740>
 1021b11:	mov    0x8(%rdi),%rax
 1021b15:	sub    %rax,0x18(%rbx)
 1021b19:	jmp    1021af0 <allocate+0x740>
 1021b1b:	vpxor  %xmm0,%xmm0,%xmm0
 1021b1f:	vmovdqu %xmm0,0xc0(%rbx)
 1021b27:	mov    0x18(%rbx),%rsi
 1021b2b:	mov    0x58(%rbx),%rax
 1021b2f:	test   %rax,%rax
 1021b32:	je     1021c16 <allocate+0x866>
 1021b38:	xor    %edx,%edx
 1021b3a:	sub    %rsi,%rax
 1021b3d:	mov    $0x0,%ecx
 1021b42:	mov    %rcx,-0x60(%rbp)
 1021b46:	cmovb  %rdx,%rax
 1021b4a:	jmp    1021c24 <allocate+0x874>
 1021b4f:	mov    %rdi,-0x60(%rbp)
 1021b53:	mov    %rcx,-0x50(%rbp)
 1021b57:	mov    %r11,-0x38(%rbp)
 1021b5b:	mov    %r10d,-0x2c(%rbp)
 1021b5f:	mov    %rdx,-0x40(%rbp)
 1021b63:	mov    $0x1,%edi
 1021b68:	call   1027690 <calloc@plt>
 1021b6d:	test   %rax,%rax
 1021b70:	je     1021bc3 <allocate+0x813>
 1021b72:	mov    -0x60(%rbp),%rcx
 1021b76:	mov    %rcx,0x18(%rbx)
 1021b7a:	lea    0x0(,%r14,8),%rcx
 1021b82:	add    %rcx,0x30(%r13)
 1021b86:	mov    -0x50(%rbp),%rdx
 1021b8a:	test   %rdx,%rdx
 1021b8d:	mov    %rax,-0x68(%rbp)
 1021b91:	je     1021ba6 <allocate+0x7f6>
 1021b93:	mov    0x4d8(%rbx),%rsi
 1021b9a:	shl    $0x3,%rdx
 1021b9e:	mov    %rax,%rdi
 1021ba1:	call   10276a0 <memcpy@plt>
 1021ba6:	mov    %r14,-0x50(%rbp)
 1021baa:	mov    -0x40(%rbp),%rdx
 1021bae:	mov    -0x58(%rbp),%r13
 1021bb2:	mov    -0x2c(%rbp),%r10d
 1021bb6:	mov    -0x38(%rbp),%r11
 1021bba:	mov    -0x48(%rbp),%r9
 1021bbe:	jmp    10216d3 <allocate+0x323>
 1021bc3:	xor    %ecx,%ecx
 1021bc5:	mov    -0x40(%rbp),%rdx
 1021bc9:	jmp    1021edf <allocate+0xb2f>
 1021bce:	mov    %rbx,%rdi
 1021bd1:	call   1022030 <slab_refill>
 1021bd6:	mov    %rax,%r15
 1021bd9:	mov    $0x1,%eax
 1021bde:	test   %r15,%r15
 1021be1:	je     1021eea <allocate+0xb3a>
 1021be7:	lea    0x20(%r15),%rdi
 1021beb:	mov    %r14,%rsi
 1021bee:	call   10223d0 <zero_payload>
 1021bf3:	xor    %ecx,%ecx
 1021bf5:	mov    %r12,%rax
 1021bf8:	jmp    1021fb2 <allocate+0xc02>
 1021bfd:	mov    %r14,%rdi
 1021c00:	call   1022830 <large_block>
 1021c05:	test   %rax,%rax
 1021c08:	je     1021f33 <allocate+0xb83>
 1021c0e:	mov    %rax,%r15
 1021c11:	jmp    1021f50 <allocate+0xba0>
 1021c16:	mov    %rsi,%rax
 1021c19:	not    %rax
 1021c1c:	movq   $0x0,-0x60(%rbp)
 1021c24:	mov    %r13,%rdx
 1021c27:	mov    -0x48(%rbp),%r9
 1021c2b:	cmp    %rax,%r12
 1021c2e:	jbe    1021c87 <allocate+0x8d7>
 1021c30:	movl   $0x1,0x6c(%rbx)
 1021c37:	mov    -0x68(%rbp),%rdi
 1021c3b:	test   %rdi,%rdi
 1021c3e:	je     10213f7 <allocate+0x47>
 1021c44:	mov    -0x50(%rbp),%rsi
 1021c48:	shl    $0x3,%rsi
 1021c4c:	mov    0x18(%rbx),%rax
 1021c50:	sub    %rsi,%rax
 1021c53:	jb     1021ff8 <allocate+0xc48>
 1021c59:	mov    %rdx,%r14
 1021c5c:	mov    0x1608(%rbx),%rcx
 1021c63:	mov    0x30(%rcx),%rdx
 1021c67:	sub    %rsi,%rdx
 1021c6a:	jb     1021ff8 <allocate+0xc48>
 1021c70:	mov    %rax,0x18(%rbx)
 1021c74:	mov    %rdx,0x30(%rcx)
 1021c78:	call   10276f0 <free@plt>
 1021c7d:	xor    %ecx,%ecx
 1021c7f:	mov    %r14,%rdx
 1021c82:	jmp    1021edf <allocate+0xb2f>
 1021c87:	mov    %r14,%r13
 1021c8a:	mov    %rsi,-0x48(%rbp)
 1021c8e:	mov    %rax,%r14
 1021c91:	and    $0xfffffffffffffff0,%r14
 1021c95:	cmp    %rax,%r9
 1021c98:	cmovb  %r9,%r14
 1021c9c:	mov    $0x1,%edi
 1021ca1:	mov    %r14,%rsi
 1021ca4:	mov    %rdx,-0x40(%rbp)
 1021ca8:	call   1027690 <calloc@plt>
 1021cad:	mov    -0x2c(%rbp),%r10d
 1021cb1:	mov    -0x40(%rbp),%rdx
 1021cb5:	mov    %rax,%r12
 1021cb8:	test   %rax,%rax
 1021cbb:	je     1021e74 <allocate+0xac4>
 1021cc1:	mov    %r14,0x8(%r12)
 1021cc6:	mov    -0x48(%rbp),%r13
 1021cca:	add    %r14,%r13
 1021ccd:	mov    %r13,0x18(%rbx)
 1021cd1:	mov    $0x98,%eax
 1021cd6:	mov    -0x58(%rbp),%r13
 1021cda:	incq   (%rbx,%rax,1)
 1021cde:	mov    0x4d8(%rbx),%rdi
 1021ce5:	cmpq   $0x0,-0x68(%rbp)
 1021cea:	je     1021d58 <allocate+0x9a8>
 1021cec:	test   %rdi,%rdi
 1021cef:	mov    -0x38(%rbp),%r11
 1021cf3:	je     1021d40 <allocate+0x990>
 1021cf5:	mov    %r10d,-0x2c(%rbp)
 1021cf9:	mov    0x11f0(%rbx),%rcx
 1021d00:	shl    $0x3,%rcx
 1021d04:	mov    0x18(%rbx),%rax
 1021d08:	sub    %rcx,%rax
 1021d0b:	jb     1021ff8 <allocate+0xc48>
 1021d11:	mov    %rdx,%r14
 1021d14:	mov    0x1608(%rbx),%rdx
 1021d1b:	mov    0x30(%rdx),%rsi
 1021d1f:	sub    %rcx,%rsi
 1021d22:	jb     1021ff8 <allocate+0xc48>
 1021d28:	mov    %rax,0x18(%rbx)
 1021d2c:	mov    %rsi,0x30(%rdx)
 1021d30:	call   10276f0 <free@plt>
 1021d35:	mov    %r14,%rdx
 1021d38:	mov    -0x2c(%rbp),%r10d
 1021d3c:	mov    -0x38(%rbp),%r11
 1021d40:	mov    -0x68(%rbp),%rdi
 1021d44:	mov    %rdi,0x4d8(%rbx)
 1021d4b:	mov    -0x50(%rbp),%rax
 1021d4f:	mov    %rax,0x11f0(%rbx)
 1021d56:	jmp    1021d5c <allocate+0x9ac>
 1021d58:	mov    -0x38(%rbp),%r11
 1021d5c:	mov    (%rdi,%r15,8),%rax
 1021d60:	mov    %rax,(%r12)
 1021d64:	mov    %r10d,0x20(%r12)
 1021d69:	mov    %r12,(%rdi,%r15,8)
 1021d6d:	cmp    %r15,0x11e8(%rbx)
 1021d74:	ja     1021d81 <allocate+0x9d1>
 1021d76:	lea    0x1(%r15),%rax
 1021d7a:	mov    %rax,0x11e8(%rbx)
 1021d81:	incq   0xa8(%rbx)
 1021d88:	mov    0xb0(%rbx),%rax
 1021d8f:	add    0x8(%r12),%rax
 1021d94:	mov    %rax,0xb0(%rbx)
 1021d9b:	cmp    0xb8(%rbx),%rax
 1021da2:	jbe    1021dab <allocate+0x9fb>
 1021da4:	mov    %rax,0xb8(%rbx)
 1021dab:	xor    %eax,%eax
 1021dad:	movabs $0x4000000000000000,%rsi
 1021db7:	shl    $0x28,%r15
 1021dbb:	mov    -0x70(%rbp),%rcx
 1021dbf:	lea    (%r15,%rcx,4),%rcx
 1021dc3:	or     %rsi,%rcx
 1021dc6:	mov    %rcx,0x50(%r12,%rax,1)
 1021dcb:	mov    %r13,0x58(%r12,%rax,1)
 1021dd0:	incq   0x18(%r12)
 1021dd5:	lea    (%r11,%rax,1),%rcx
 1021dd9:	add    $0x10,%rcx
 1021ddd:	mov    %rcx,0x10(%r12)
 1021de2:	vmovdqu 0x40(%rbx),%xmm0
 1021de7:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1021deb:	vpsubq %xmm1,%xmm0,%xmm0
 1021def:	vmovdqu %xmm0,0x40(%rbx)
 1021df4:	incq   0x90(%rbx)
 1021dfb:	lea    (%r12,%rax,1),%rcx
 1021dff:	add    $0x50,%rcx
 1021e03:	cmp    0x70(%rbx),%r10d
 1021e07:	jne    1021587 <allocate+0x1d7>
 1021e0d:	cmpl   $0x0,0x74(%rbx)
 1021e11:	jne    1021587 <allocate+0x1d7>
 1021e17:	cmpl   $0x0,0x68(%rbx)
 1021e1b:	jne    1021587 <allocate+0x1d7>
 1021e21:	mov    0x8(%r12),%rax
 1021e26:	mov    0x10(%r12),%rdi
 1021e2b:	add    $0xf,%rdi
 1021e2f:	and    $0xfffffffffffffff0,%rdi
 1021e33:	lea    -0x50(%rax),%r8
 1021e37:	cmp    %r8,%rdi
 1021e3a:	jae    1021587 <allocate+0x1d7>
 1021e40:	lea    0x50(%r12),%r8
 1021e45:	add    %rdi,%r8
 1021e48:	add    %r12,%rax
 1021e4b:	mov    %r8,0x5c0(%rbx)
 1021e52:	mov    %rax,0x5c8(%rbx)
 1021e59:	lea    (%rsi,%r15,1),%rax
 1021e5d:	add    $0x4,%rax
 1021e61:	mov    %rax,0x5d0(%rbx)
 1021e68:	mov    %r12,0x11a0(%rbx)
 1021e6f:	jmp    1021587 <allocate+0x1d7>
 1021e74:	mov    -0x60(%rbp),%rdi
 1021e78:	test   %rdi,%rdi
 1021e7b:	je     1021c37 <allocate+0x887>
 1021e81:	mov    %r14,%r12
 1021e84:	jmp    1021e94 <allocate+0xae4>
 1021e86:	call   10276f0 <free@plt>
 1021e8b:	mov    0x0(%r13),%rdi
 1021e8f:	test   %rdi,%rdi
 1021e92:	je     1021ef9 <allocate+0xb49>
 1021e94:	mov    (%rdi),%rax
 1021e97:	mov    %rax,0x4e0(%rbx)
 1021e9e:	cmpq   $0x0,0x1608(%rbx)
 1021ea6:	je     1021e86 <allocate+0xad6>
 1021ea8:	mov    0x8(%rdi),%rax
 1021eac:	sub    %rax,0x18(%rbx)
 1021eb0:	jmp    1021e86 <allocate+0xad6>
 1021eb2:	cmpq   $0x0,0xc0(%rbx)
 1021eba:	je     1021eda <allocate+0xb2a>
 1021ebc:	mov    %rbx,%rdi
 1021ebf:	call   10172b0 <myl_native_arena_reclaim>
 1021ec4:	mov    $0x1,%edi
 1021ec9:	mov    %r14,%rsi
 1021ecc:	call   1027690 <calloc@plt>
 1021ed1:	test   %rax,%rax
 1021ed4:	jne    1021a3c <allocate+0x68c>
 1021eda:	xor    %ecx,%ecx
 1021edc:	mov    %r13,%rdx
 1021edf:	mov    %rcx,(%rdx)
 1021ee2:	xor    %eax,%eax
 1021ee4:	test   %rcx,%rcx
 1021ee7:	sete   %al
 1021eea:	add    $0x48,%rsp
 1021eee:	pop    %rbx
 1021eef:	pop    %r12
 1021ef1:	pop    %r13
 1021ef3:	pop    %r14
 1021ef5:	pop    %r15
 1021ef7:	pop    %rbp
 1021ef8:	ret
 1021ef9:	vpxor  %xmm0,%xmm0,%xmm0
 1021efd:	vmovdqu %xmm0,0xc0(%rbx)
 1021f05:	mov    $0x1,%edi
 1021f0a:	mov    %r12,%rsi
 1021f0d:	call   1027690 <calloc@plt>
 1021f12:	test   %rax,%rax
 1021f15:	mov    -0x40(%rbp),%rdx
 1021f19:	mov    -0x2c(%rbp),%r10d
 1021f1d:	je     1021c37 <allocate+0x887>
 1021f23:	mov    %rax,%r12
 1021f26:	mov    0x18(%rbx),%rax
 1021f2a:	mov    %rax,-0x48(%rbp)
 1021f2e:	jmp    1021cc1 <allocate+0x911>
 1021f33:	mov    %rbx,%rdi
 1021f36:	call   1022440 <trim_empty>
 1021f3b:	mov    %r14,%rdi
 1021f3e:	call   1022830 <large_block>
 1021f43:	mov    %rax,%r15
 1021f46:	test   %rax,%rax
 1021f49:	mov    $0x1,%eax
 1021f4e:	je     1021eea <allocate+0xb3a>
 1021f50:	mov    0x1608(%rbx),%rcx
 1021f57:	test   %rcx,%rcx
 1021f5a:	mov    -0x70(%rbp),%rax
 1021f5e:	je     1021ff8 <allocate+0xc48>
 1021f64:	mov    0x20(%rcx),%rcx
 1021f68:	mov    0x200(%rcx),%rdx
 1021f6f:	movq   $0x0,(%r15)
 1021f76:	mov    %rdx,0x8(%r15)
 1021f7a:	mov    %r14,0x10(%r15)
 1021f7e:	mov    %r12,0x18(%r15)
 1021f82:	movq   $0x0,0x28(%r15)
 1021f8a:	test   %rdx,%rdx
 1021f8d:	je     1021f92 <allocate+0xbe2>
 1021f8f:	mov    %r15,(%rdx)
 1021f92:	mov    %r15,0x200(%rcx)
 1021f99:	add    %r14,0x18(%rbx)
 1021f9d:	add    %r14,0x208(%rcx)
 1021fa4:	add    $0x30,%r15
 1021fa8:	movabs $0x8000000000000000,%rcx
 1021fb2:	mov    (%rax),%rdx
 1021fb5:	mov    0x8(%rax),%rax
 1021fb9:	movq   $0x1,(%r15)
 1021fc0:	movq   $0x0,0x8(%r15)
 1021fc8:	shl    $0x2,%rax
 1021fcc:	or     %rcx,%rax
 1021fcf:	mov    %rax,0x10(%r15)
 1021fd3:	mov    %rdx,0x18(%r15)
 1021fd7:	vmovdqu 0x40(%rbx),%xmm0
 1021fdc:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1021fe0:	vpsubq %xmm1,%xmm0,%xmm0
 1021fe4:	vmovdqu %xmm0,0x40(%rbx)
 1021fe9:	add    $0x20,%r15
 1021fed:	mov    %r15,0x0(%r13)
 1021ff1:	xor    %eax,%eax
 1021ff3:	jmp    1021eea <allocate+0xb3a>
 1021ff8:	call   1018954 <myl_rc_invariant_failed>
 1021ffd:	int3
 1021ffe:	int3
 1021fff:	int3

0000000001022000 <myl_rc_binding_find>:
 1022000:	mov    0x34(%rsi),%eax
 1022003:	cmp    %rax,0xa0(%rdi)
 102200a:	jbe    1022025 <myl_rc_binding_find+0x25>
 102200c:	mov    0x98(%rdi),%rcx
 1022013:	shl    $0x4,%rax
 1022017:	cmp    %rsi,(%rcx,%rax,1)
 102201b:	jne    1022025 <myl_rc_binding_find+0x25>
 102201d:	add    %rax,%rcx
 1022020:	mov    0x8(%rcx),%rax
 1022024:	ret
 1022025:	push   %rbp
 1022026:	mov    %rsp,%rbp
 1022029:	call   1018f74 <myl_rc_binding_find_slow>
 102202e:	pop    %rbp
 102202f:	ret

0000000001022030 <slab_refill>:
 1022030:	push   %rbp
 1022031:	mov    %rsp,%rbp
 1022034:	push   %r15
 1022036:	push   %r14
 1022038:	push   %r13
 102203a:	push   %r12
 102203c:	push   %rbx
 102203d:	sub    $0x38,%rsp
 1022041:	mov    0x1608(%rdi),%rax
 1022048:	test   %rax,%rax
 102204b:	je     10223c4 <slab_refill+0x394>
 1022051:	mov    %rsi,%r12
 1022054:	mov    %rdi,%rbx
 1022057:	mov    0x20(%rax),%r14
 102205b:	mov    %rsi,%r15
 102205e:	shl    $0x4,%r15
 1022062:	mov    0x8(%r14,%r15,1),%rcx
 1022067:	test   %rcx,%rcx
 102206a:	je     102209b <slab_refill+0x6b>
 102206c:	mov    0x48(%rcx),%rax
 1022070:	test   %rax,%rax
 1022073:	je     1022207 <slab_refill+0x1d7>
 1022079:	movq   $0x0,0x48(%rcx)
 1022081:	mov    0x30(%rcx),%r13
 1022085:	mov    0x40(%rcx),%r11
 1022089:	mov    %r13,0x38(%rcx)
 102208d:	cmp    %r11,%r13
 1022090:	je     102236b <slab_refill+0x33b>
 1022096:	jmp    1022391 <slab_refill+0x361>
 102209b:	cmpq   $0x0,0x448(%r14)
 10220a3:	jne    10220cc <slab_refill+0x9c>
 10220a5:	mov    0x1710(%rbx),%rax
 10220ac:	cmp    $0x100000,%rax
 10220b2:	jb     10220cc <slab_refill+0x9c>
 10220b4:	mov    0x208(%r14),%rcx
 10220bb:	shr    $0x2,%rcx
 10220bf:	cmp    %rcx,%rax
 10220c2:	jb     10220cc <slab_refill+0x9c>
 10220c4:	mov    %rbx,%rdi
 10220c7:	call   1022440 <trim_empty>
 10220cc:	mov    0x18(%rbx),%rax
 10220d0:	cmp    $0xfffffffffffeffff,%rax
 10220d6:	ja     10220f8 <slab_refill+0xc8>
 10220d8:	mov    0x58(%rbx),%rcx
 10220dc:	test   %rcx,%rcx
 10220df:	je     102213a <slab_refill+0x10a>
 10220e1:	sub    %rax,%rcx
 10220e4:	setb   %al
 10220e7:	cmp    $0x10000,%rcx
 10220ee:	setb   %cl
 10220f1:	or     %al,%cl
 10220f3:	cmp    $0x1,%cl
 10220f6:	jne    102213a <slab_refill+0x10a>
 10220f8:	mov    %rbx,%rdi
 10220fb:	call   1022440 <trim_empty>
 1022100:	mov    0x18(%rbx),%rax
 1022104:	cmp    $0xfffffffffffeffff,%rax
 102210a:	ja     102212c <slab_refill+0xfc>
 102210c:	mov    0x58(%rbx),%rcx
 1022110:	test   %rcx,%rcx
 1022113:	je     102213a <slab_refill+0x10a>
 1022115:	sub    %rax,%rcx
 1022118:	setb   %al
 102211b:	cmp    $0x10000,%rcx
 1022122:	setb   %cl
 1022125:	or     %al,%cl
 1022127:	cmp    $0x1,%cl
 102212a:	jne    102213a <slab_refill+0x10a>
 102212c:	movl   $0x1,0x6c(%rbx)
 1022133:	xor    %eax,%eax
 1022135:	jmp    102239c <slab_refill+0x36c>
 102213a:	mov    %rbx,%rdi
 102213d:	call   1022640 <range_take>
 1022142:	test   %rax,%rax
 1022145:	jne    1022160 <slab_refill+0x130>
 1022147:	mov    %rbx,%rdi
 102214a:	call   1022440 <trim_empty>
 102214f:	mov    %rbx,%rdi
 1022152:	call   1022640 <range_take>
 1022157:	test   %rax,%rax
 102215a:	je     10223c0 <slab_refill+0x390>
 1022160:	mov    %rax,%rcx
 1022163:	vxorps %xmm0,%xmm0,%xmm0
 1022167:	vmovups %ymm0,0x30(%rax)
 102216c:	vmovups %ymm0,0x10(%rax)
 1022171:	mov    0x100b700(,%r12,8),%rsi
 1022179:	mov    %rsi,0x8(%rax)
 102217d:	mov    %r12,(%rax)
 1022180:	cmp    $0xffb0,%rsi
 1022187:	ja     1022194 <slab_refill+0x164>
 1022189:	mov    $0xffb0,%eax
 102218e:	xor    %edx,%edx
 1022190:	div    %esi
 1022192:	jmp    1022196 <slab_refill+0x166>
 1022194:	xor    %eax,%eax
 1022196:	mov    %rax,0x40(%rcx)
 102219a:	mov    0x1608(%rbx),%rax
 10221a1:	test   %rax,%rax
 10221a4:	je     10223c4 <slab_refill+0x394>
 10221aa:	mov    0x20(%rax),%rax
 10221ae:	lea    (%rax,%r15,1),%rdx
 10221b2:	mov    (%rax,%r15,1),%rsi
 10221b6:	mov    %rsi,0x18(%rcx)
 10221ba:	test   %rsi,%rsi
 10221bd:	je     10221c3 <slab_refill+0x193>
 10221bf:	mov    %rcx,0x10(%rsi)
 10221c3:	mov    %rcx,(%rdx)
 10221c6:	mov    0x8(%rdx),%rsi
 10221ca:	movq   $0x0,0x20(%rcx)
 10221d2:	mov    %rsi,0x28(%rcx)
 10221d6:	mov    0x8(%rdx),%rsi
 10221da:	test   %rsi,%rsi
 10221dd:	je     10221e3 <slab_refill+0x1b3>
 10221df:	mov    %rcx,0x20(%rsi)
 10221e3:	mov    %rcx,0x8(%rdx)
 10221e7:	addq   $0x10000,0x18(%rbx)
 10221ef:	addq   $0x10000,0x208(%rax)
 10221fa:	mov    0x48(%rcx),%rax
 10221fe:	test   %rax,%rax
 1022201:	jne    1022079 <slab_refill+0x49>
 1022207:	mov    0x8(%rcx),%rdi
 102220b:	mov    0x30(%rcx),%r13
 102220f:	mov    0x40(%rcx),%r11
 1022213:	mov    %r11,%r8
 1022216:	sub    %r13,%r8
 1022219:	cmp    $0x1000,%rdi
 1022220:	ja     102222d <slab_refill+0x1fd>
 1022222:	mov    $0x1000,%eax
 1022227:	xor    %edx,%edx
 1022229:	div    %edi
 102222b:	jmp    102222f <slab_refill+0x1ff>
 102222d:	xor    %eax,%eax
 102222f:	cmp    $0x1001,%rdi
 1022236:	mov    $0x1,%edx
 102223b:	cmovb  %rax,%rdx
 102223f:	cmp    %r8,%rdx
 1022242:	cmovae %r8,%rdx
 1022246:	mov    %r13,%r9
 1022249:	imul   %rdi,%r9
 102224d:	lea    (%rcx,%r9,1),%rax
 1022251:	add    $0x50,%rax
 1022255:	test   %rdx,%rdx
 1022258:	je     102235b <slab_refill+0x32b>
 102225e:	cmp    $0x1,%rdx
 1022262:	jne    102226c <slab_refill+0x23c>
 1022264:	xor    %r10d,%r10d
 1022267:	jmp    1022331 <slab_refill+0x301>
 102226c:	mov    %r11,-0x38(%rbp)
 1022270:	mov    %r12,-0x48(%rbp)
 1022274:	mov    %r15,-0x50(%rbp)
 1022278:	mov    %r14,-0x58(%rbp)
 102227c:	mov    %rbx,-0x60(%rbp)
 1022280:	mov    %edx,%r11d
 1022283:	and    $0x1ffe,%r11d
 102228a:	lea    0x2(%r13),%r8
 102228e:	imul   %rdi,%r8
 1022292:	lea    (%rcx,%r8,1),%r12
 1022296:	add    $0x50,%r12
 102229a:	mov    %r13,%rsi
 102229d:	lea    (%rdi,%rdi,1),%r13
 10222a1:	mov    %rsi,-0x40(%rbp)
 10222a5:	lea    0x1(%rsi),%r8
 10222a9:	mov    %rdi,-0x30(%rbp)
 10222ad:	imul   %rdi,%r8
 10222b1:	lea    (%rcx,%r8,1),%r14
 10222b5:	add    $0x60,%r14
 10222b9:	add    %rcx,%r8
 10222bc:	add    $0x50,%r8
 10222c0:	lea    (%r9,%rcx,1),%r15
 10222c4:	add    $0x60,%r15
 10222c8:	xor    %ebx,%ebx
 10222ca:	xor    %r9d,%r9d
 10222cd:	xor    %r10d,%r10d
 10222d0:	lea    0x1(%r10),%rsi
 10222d4:	lea    (%r8,%r9,1),%rdi
 10222d8:	cmp    %rdx,%rsi
 10222db:	cmovae %rbx,%rdi
 10222df:	mov    %rdi,-0x10(%r15,%r9,1)
 10222e4:	movq   $0x3,(%r15,%r9,1)
 10222ec:	add    $0x2,%r10
 10222f0:	lea    (%r12,%r9,1),%rsi
 10222f4:	cmp    %rdx,%r10
 10222f7:	cmovae %rbx,%rsi
 10222fb:	mov    %rsi,-0x10(%r14,%r9,1)
 1022300:	movq   $0x3,(%r14,%r9,1)
 1022308:	add    %r13,%r9
 102230b:	cmp    %r10,%r11
 102230e:	jne    10222d0 <slab_refill+0x2a0>
 1022310:	test   $0x1,%dl
 1022313:	mov    -0x60(%rbp),%rbx
 1022317:	mov    -0x58(%rbp),%r14
 102231b:	mov    -0x50(%rbp),%r15
 102231f:	mov    -0x48(%rbp),%r12
 1022323:	mov    -0x40(%rbp),%r13
 1022327:	mov    -0x38(%rbp),%r11
 102232b:	mov    -0x30(%rbp),%rdi
 102232f:	je     102235b <slab_refill+0x32b>
 1022331:	mov    %r10,%rsi
 1022334:	imul   %rdi,%rsi
 1022338:	inc    %r10
 102233b:	imul   %r10,%rdi
 102233f:	add    %rax,%rdi
 1022342:	mov    %rdi,%r8
 1022345:	xor    %edi,%edi
 1022347:	cmp    %rdx,%r10
 102234a:	cmovb  %r8,%rdi
 102234e:	mov    %rdi,(%rax,%rsi,1)
 1022352:	movq   $0x3,0x10(%rax,%rsi,1)
 102235b:	add    %rdx,%r13
 102235e:	mov    %r13,0x30(%rcx)
 1022362:	add    %rdx,0x38(%rcx)
 1022366:	cmp    %r11,%r13
 1022369:	jne    1022391 <slab_refill+0x361>
 102236b:	mov    0x20(%rcx),%rdx
 102236f:	mov    0x28(%rcx),%rsi
 1022373:	test   %rdx,%rdx
 1022376:	je     10223ae <slab_refill+0x37e>
 1022378:	mov    %rsi,0x28(%rdx)
 102237c:	add    $0x20,%rcx
 1022380:	test   %rsi,%rsi
 1022383:	je     1022389 <slab_refill+0x359>
 1022385:	mov    %rdx,0x20(%rsi)
 1022389:	vxorps %xmm0,%xmm0,%xmm0
 102238d:	vmovups %xmm0,(%rcx)
 1022391:	mov    (%rax),%rcx
 1022394:	mov    %rcx,0x1610(%rbx,%r12,8)
 102239c:	add    $0x38,%rsp
 10223a0:	pop    %rbx
 10223a1:	pop    %r12
 10223a3:	pop    %r13
 10223a5:	pop    %r14
 10223a7:	pop    %r15
 10223a9:	pop    %rbp
 10223aa:	vzeroupper
 10223ad:	ret
 10223ae:	add    %r15,%r14
 10223b1:	mov    %rsi,0x8(%r14)
 10223b5:	add    $0x20,%rcx
 10223b9:	test   %rsi,%rsi
 10223bc:	jne    1022385 <slab_refill+0x355>
 10223be:	jmp    1022389 <slab_refill+0x359>
 10223c0:	xor    %eax,%eax
 10223c2:	jmp    102239c <slab_refill+0x36c>
 10223c4:	vzeroupper
 10223c7:	call   1018954 <myl_rc_invariant_failed>
 10223cc:	int3
 10223cd:	int3
 10223ce:	int3
 10223cf:	int3

00000000010223d0 <zero_payload>:
 10223d0:	push   %rbp
 10223d1:	mov    %rsp,%rbp
 10223d4:	lea    0xf(%rsi),%rax
 10223d8:	shr    $0x4,%rax
 10223dc:	cmp    $0x8,%rax
 10223e0:	ja     1022432 <zero_payload+0x62>
 10223e2:	jmp    *0x1001c58(,%rax,8)
 10223e9:	vxorps %xmm0,%xmm0,%xmm0
 10223ed:	vmovaps %xmm0,0x70(%rdi)
 10223f2:	vxorps %xmm0,%xmm0,%xmm0
 10223f6:	vmovaps %xmm0,0x60(%rdi)
 10223fb:	vxorps %xmm0,%xmm0,%xmm0
 10223ff:	vmovaps %xmm0,0x50(%rdi)
 1022404:	vxorps %xmm0,%xmm0,%xmm0
 1022408:	vmovaps %xmm0,0x40(%rdi)
 102240d:	vxorps %xmm0,%xmm0,%xmm0
 1022411:	vmovaps %xmm0,0x30(%rdi)
 1022416:	vxorps %xmm0,%xmm0,%xmm0
 102241a:	vmovaps %xmm0,0x20(%rdi)
 102241f:	vxorps %xmm0,%xmm0,%xmm0
 1022423:	vmovaps %xmm0,0x10(%rdi)
 1022428:	vxorps %xmm0,%xmm0,%xmm0
 102242c:	vmovaps %xmm0,(%rdi)
 1022430:	pop    %rbp
 1022431:	ret
 1022432:	mov    %rsi,%rdx
 1022435:	xor    %esi,%esi
 1022437:	pop    %rbp
 1022438:	jmp    1027650 <memset@plt>
 102243d:	int3
 102243e:	int3
 102243f:	int3

0000000001022440 <trim_empty>:
 1022440:	push   %rbp
 1022441:	mov    %rsp,%rbp
 1022444:	push   %r15
 1022446:	push   %r14
 1022448:	push   %r13
 102244a:	push   %r12
 102244c:	push   %rbx
 102244d:	push   %rax
 102244e:	test   %rdi,%rdi
 1022451:	je     102262d <trim_empty+0x1ed>
 1022457:	mov    %rdi,%rbx
 102245a:	xor    %ecx,%ecx
 102245c:	vxorps %xmm0,%xmm0,%xmm0
 1022460:	jmp    1022481 <trim_empty+0x41>
 1022462:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022470:	mov    -0x30(%rbp),%rcx
 1022474:	inc    %rcx
 1022477:	cmp    $0x20,%rcx
 102247b:	je     1022613 <trim_empty+0x1d3>
 1022481:	mov    0x1608(%rbx),%rax
 1022488:	test   %rax,%rax
 102248b:	je     102262d <trim_empty+0x1ed>
 1022491:	mov    0x20(%rax),%r15
 1022495:	mov    0x1610(%rbx,%rcx,8),%rax
 102249d:	mov    %rcx,-0x30(%rbp)
 10224a1:	movq   $0x0,0x1610(%rbx,%rcx,8)
 10224ad:	test   %rax,%rax
 10224b0:	je     1022470 <trim_empty+0x30>
 10224b2:	mov    -0x30(%rbp),%rcx
 10224b6:	shl    $0x4,%rcx
 10224ba:	add    %rcx,%r15
 10224bd:	jmp    10224e4 <trim_empty+0xa4>
 10224bf:	nop
 10224c0:	mov    0x448(%r14),%rcx
 10224c7:	mov    %rcx,0x0(%r13)
 10224cb:	mov    %r13,0x448(%r14)
 10224d2:	inc    %rax
 10224d5:	mov    %rax,0x450(%r14)
 10224dc:	mov    %r12,%rax
 10224df:	test   %r12,%r12
 10224e2:	je     1022470 <trim_empty+0x30>
 10224e4:	mov    (%rax),%r12
 10224e7:	mov    %rax,%r13
 10224ea:	and    $0xffffffffffff0000,%r13
 10224f1:	mov    0x48(%r13),%rcx
 10224f5:	test   %rcx,%rcx
 10224f8:	jne    1022530 <trim_empty+0xf0>
 10224fa:	mov    0x30(%r13),%rdx
 10224fe:	cmp    0x40(%r13),%rdx
 1022502:	jne    1022530 <trim_empty+0xf0>
 1022504:	mov    0x8(%r15),%rcx
 1022508:	movq   $0x0,0x20(%r13)
 1022510:	mov    %rcx,0x28(%r13)
 1022514:	mov    0x8(%r15),%rcx
 1022518:	test   %rcx,%rcx
 102251b:	je     1022521 <trim_empty+0xe1>
 102251d:	mov    %r13,0x20(%rcx)
 1022521:	mov    %r13,0x8(%r15)
 1022525:	mov    0x48(%r13),%rcx
 1022529:	nopl   0x0(%rax)
 1022530:	mov    %rcx,(%rax)
 1022533:	mov    %rax,0x48(%r13)
 1022537:	decq   0x38(%r13)
 102253b:	jne    10224dc <trim_empty+0x9c>
 102253d:	mov    0x1608(%rbx),%rdx
 1022544:	test   %rdx,%rdx
 1022547:	je     102262d <trim_empty+0x1ed>
 102254d:	mov    0x0(%r13),%rax
 1022551:	mov    0x20(%r13),%rcx
 1022555:	shl    $0x4,%rax
 1022559:	add    0x20(%rdx),%rax
 102255d:	mov    0x28(%r13),%rdx
 1022561:	test   %rcx,%rcx
 1022564:	je     10225f7 <trim_empty+0x1b7>
 102256a:	mov    %rdx,0x28(%rcx)
 102256e:	test   %rdx,%rdx
 1022571:	je     1022577 <trim_empty+0x137>
 1022573:	mov    %rcx,0x20(%rdx)
 1022577:	lea    0x20(%r13),%rcx
 102257b:	vmovaps %xmm0,(%rcx)
 102257f:	mov    0x10(%r13),%rdx
 1022583:	mov    0x18(%r13),%rcx
 1022587:	test   %rdx,%rdx
 102258a:	je     1022609 <trim_empty+0x1c9>
 102258c:	mov    %rcx,0x18(%rdx)
 1022590:	test   %rcx,%rcx
 1022593:	je     102259d <trim_empty+0x15d>
 1022595:	mov    0x10(%r13),%rax
 1022599:	mov    %rax,0x10(%rcx)
 102259d:	addq   $0xffffffffffff0000,0x18(%rbx)
 10225a5:	mov    0x1608(%rbx),%rax
 10225ac:	test   %rax,%rax
 10225af:	je     102262d <trim_empty+0x1ed>
 10225b1:	mov    0x20(%rax),%r14
 10225b5:	addq   $0xffffffffffff0000,0x208(%r14)
 10225c0:	mov    0x450(%r14),%rax
 10225c7:	cmp    $0x10,%rax
 10225cb:	jb     10224c0 <trim_empty+0x80>
 10225d1:	lea    0x1000(%r13),%rdi
 10225d8:	mov    $0xf000,%esi
 10225dd:	mov    $0x4,%edx
 10225e2:	call   1027a70 <madvise@plt>
 10225e7:	vxorps %xmm0,%xmm0,%xmm0
 10225eb:	mov    0x450(%r14),%rax
 10225f2:	jmp    10224c0 <trim_empty+0x80>
 10225f7:	mov    %rdx,0x8(%rax)
 10225fb:	test   %rdx,%rdx
 10225fe:	jne    1022573 <trim_empty+0x133>
 1022604:	jmp    1022577 <trim_empty+0x137>
 1022609:	mov    %rcx,(%rax)
 102260c:	test   %rcx,%rcx
 102260f:	jne    1022595 <trim_empty+0x155>
 1022611:	jmp    102259d <trim_empty+0x15d>
 1022613:	movq   $0x0,0x1710(%rbx)
 102261e:	add    $0x8,%rsp
 1022622:	pop    %rbx
 1022623:	pop    %r12
 1022625:	pop    %r13
 1022627:	pop    %r14
 1022629:	pop    %r15
 102262b:	pop    %rbp
 102262c:	ret
 102262d:	call   1018954 <myl_rc_invariant_failed>
 1022632:	int3
 1022633:	int3
 1022634:	int3
 1022635:	int3
 1022636:	int3
 1022637:	int3
 1022638:	int3
 1022639:	int3
 102263a:	int3
 102263b:	int3
 102263c:	int3
 102263d:	int3
 102263e:	int3
 102263f:	int3

0000000001022640 <range_take>:
 1022640:	push   %rbp
 1022641:	mov    %rsp,%rbp
 1022644:	push   %r15
 1022646:	push   %r14
 1022648:	push   %rbx
 1022649:	push   %rax
 102264a:	mov    0x1608(%rdi),%rax
 1022651:	test   %rax,%rax
 1022654:	je     1022827 <range_take+0x1e7>
 102265a:	mov    0x20(%rax),%r15
 102265e:	mov    0x448(%r15),%rax
 1022665:	test   %rax,%rax
 1022668:	je     1022680 <range_take+0x40>
 102266a:	mov    (%rax),%rcx
 102266d:	mov    %rcx,0x448(%r15)
 1022674:	decq   0x450(%r15)
 102267b:	jmp    1022818 <range_take+0x1d8>
 1022680:	mov    0x220(%r15),%rax
 1022687:	cmp    0x228(%r15),%rax
 102268e:	jne    102280a <range_take+0x1ca>
 1022694:	mov    0x438(%r15),%rcx
 102269b:	cmp    $0x40,%rcx
 102269f:	jb     1022758 <range_take+0x118>
 10226a5:	add    $0xffffffffffffffc0,%rcx
 10226a9:	cmp    0x440(%r15),%rcx
 10226b0:	jne    1022758 <range_take+0x118>
 10226b6:	lea    (%rcx,%rcx,1),%rax
 10226ba:	test   %rcx,%rcx
 10226bd:	mov    $0x40,%ebx
 10226c2:	cmovne %rax,%rbx
 10226c6:	mov    %rbx,%rax
 10226c9:	sub    %rcx,%rax
 10226cc:	shl    $0x3,%rax
 10226d0:	mov    0x18(%rdi),%rcx
 10226d4:	mov    %rcx,%rdx
 10226d7:	add    %rax,%rdx
 10226da:	jae    10226ea <range_take+0xaa>
 10226dc:	movl   $0x1,0x6c(%rdi)
 10226e3:	xor    %eax,%eax
 10226e5:	jmp    1022818 <range_take+0x1d8>
 10226ea:	mov    0x58(%rdi),%rdx
 10226ee:	test   %rdx,%rdx
 10226f1:	je     10226fd <range_take+0xbd>
 10226f3:	sub    %rcx,%rdx
 10226f6:	jb     10226dc <range_take+0x9c>
 10226f8:	cmp    %rdx,%rax
 10226fb:	ja     10226dc <range_take+0x9c>
 10226fd:	mov    %rdi,%r14
 1022700:	lea    0x0(,%rbx,8),%rsi
 1022708:	mov    0x430(%r15),%rdi
 102270f:	call   10277f0 <realloc@plt>
 1022714:	test   %rax,%rax
 1022717:	je     1022823 <range_take+0x1e3>
 102271d:	mov    %rbx,%rcx
 1022720:	sub    0x440(%r15),%rcx
 1022727:	shl    $0x3,%rcx
 102272b:	add    %rcx,0x18(%r14)
 102272f:	mov    0x1608(%r14),%rdx
 1022736:	test   %rdx,%rdx
 1022739:	je     1022827 <range_take+0x1e7>
 102273f:	mov    0x20(%rdx),%rdx
 1022743:	add    %rcx,0x208(%rdx)
 102274a:	mov    %rax,0x430(%r15)
 1022751:	mov    %rbx,0x440(%r15)
 1022758:	mov    $0x210000,%esi
 102275d:	xor    %edi,%edi
 102275f:	mov    $0x3,%edx
 1022764:	mov    $0x22,%ecx
 1022769:	mov    $0xffffffff,%r8d
 102276f:	xor    %r9d,%r9d
 1022772:	call   10278a0 <mmap@plt>
 1022777:	mov    %rax,%rbx
 102277a:	xor    %eax,%eax
 102277c:	cmp    $0xffffffffffffffff,%rbx
 1022780:	je     1022818 <range_take+0x1d8>
 1022786:	lea    0xffff(%rbx),%rax
 102278d:	and    $0xffffffffffff0000,%rax
 1022793:	cmp    %rax,%rbx
 1022796:	je     10227ac <range_take+0x16c>
 1022798:	mov    %rax,%rsi
 102279b:	sub    %rbx,%rsi
 102279e:	mov    %rbx,%rdi
 10227a1:	mov    %rax,%r14
 10227a4:	call   10278f0 <munmap@plt>
 10227a9:	mov    %r14,%rax
 10227ac:	lea    0x200000(%rax),%r14
 10227b3:	add    $0x210000,%rbx
 10227ba:	cmp    %rbx,%r14
 10227bd:	je     10227d3 <range_take+0x193>
 10227bf:	sub    %r14,%rbx
 10227c2:	mov    %r14,%rdi
 10227c5:	mov    %rbx,%rsi
 10227c8:	mov    %rax,%rbx
 10227cb:	call   10278f0 <munmap@plt>
 10227d0:	mov    %rbx,%rax
 10227d3:	mov    0x438(%r15),%rcx
 10227da:	cmp    $0x3f,%rcx
 10227de:	ja     10227ea <range_take+0x1aa>
 10227e0:	mov    %rax,0x230(%r15,%rcx,8)
 10227e8:	jmp    10227f9 <range_take+0x1b9>
 10227ea:	mov    0x430(%r15),%rdx
 10227f1:	mov    %rax,-0x200(%rdx,%rcx,8)
 10227f9:	inc    %rcx
 10227fc:	mov    %rcx,0x438(%r15)
 1022803:	mov    %r14,0x228(%r15)
 102280a:	lea    0x10000(%rax),%rcx
 1022811:	mov    %rcx,0x220(%r15)
 1022818:	add    $0x8,%rsp
 102281c:	pop    %rbx
 102281d:	pop    %r14
 102281f:	pop    %r15
 1022821:	pop    %rbp
 1022822:	ret
 1022823:	xor    %eax,%eax
 1022825:	jmp    1022818 <range_take+0x1d8>
 1022827:	call   1018954 <myl_rc_invariant_failed>
 102282c:	int3
 102282d:	int3
 102282e:	int3
 102282f:	int3

0000000001022830 <large_block>:
 1022830:	push   %rbp
 1022831:	mov    %rsp,%rbp
 1022834:	push   %r14
 1022836:	push   %rbx
 1022837:	mov    %rdi,%rbx
 102283a:	cmp    $0x1ffff,%rdi
 1022841:	ja     1022854 <large_block+0x24>
 1022843:	mov    $0x1,%edi
 1022848:	mov    %rbx,%rsi
 102284b:	pop    %rbx
 102284c:	pop    %r14
 102284e:	pop    %rbp
 102284f:	jmp    1027690 <calloc@plt>
 1022854:	cmp    $0xffffffffffffefff,%rbx
 102285b:	jbe    1022862 <large_block+0x32>
 102285d:	xor    %r14d,%r14d
 1022860:	jmp    102289d <large_block+0x6d>
 1022862:	add    $0xfff,%rbx
 1022869:	and    $0xfffffffffffff000,%rbx
 1022870:	xor    %r14d,%r14d
 1022873:	xor    %edi,%edi
 1022875:	mov    %rbx,%rsi
 1022878:	mov    $0x3,%edx
 102287d:	mov    $0x22,%ecx
 1022882:	mov    $0xffffffff,%r8d
 1022888:	xor    %r9d,%r9d
 102288b:	call   10278a0 <mmap@plt>
 1022890:	cmp    $0xffffffffffffffff,%rax
 1022894:	je     102289d <large_block+0x6d>
 1022896:	mov    %rbx,0x20(%rax)
 102289a:	mov    %rax,%r14
 102289d:	mov    %r14,%rax
 10228a0:	pop    %rbx
 10228a1:	pop    %r14
 10228a3:	pop    %rbp
 10228a4:	ret
 10228a5:	int3
 10228a6:	int3
 10228a7:	int3
 10228a8:	int3
 10228a9:	int3
 10228aa:	int3
 10228ab:	int3
 10228ac:	int3
 10228ad:	int3
 10228ae:	int3
 10228af:	int3

00000000010228b0 <myl_rc_storage_retire>:
 10228b0:	push   %rbp
 10228b1:	mov    %rsp,%rbp
 10228b4:	cmpq   $0x0,-0x10(%rsi)
 10228b9:	js     102291d <myl_rc_storage_retire+0x6d>
 10228bb:	mov    0x40(%rdi),%rcx
 10228bf:	test   %rcx,%rcx
 10228c2:	je     1022999 <myl_rc_storage_retire+0xe9>
 10228c8:	lea    -0x20(%rsi),%rax
 10228cc:	mov    0x50(%rdi),%rdx
 10228d0:	cmp    $0xffffffffffffffff,%rdx
 10228d4:	je     10228dd <myl_rc_storage_retire+0x2d>
 10228d6:	inc    %rdx
 10228d9:	mov    %rdx,0x50(%rdi)
 10228dd:	mov    %rax,%rdx
 10228e0:	and    $0xffffffffffff0000,%rdx
 10228e7:	dec    %rcx
 10228ea:	mov    %rcx,0x40(%rdi)
 10228ee:	movq   $0x3,-0x10(%rsi)
 10228f6:	mov    (%rdx),%rcx
 10228f9:	mov    0x1610(%rdi,%rcx,8),%rcx
 1022901:	mov    %rcx,-0x20(%rsi)
 1022905:	mov    (%rdx),%rcx
 1022908:	mov    %rax,0x1610(%rdi,%rcx,8)
 1022910:	mov    0x8(%rdx),%rax
 1022914:	add    %rax,0x1710(%rdi)
 102291b:	pop    %rbp
 102291c:	ret
 102291d:	mov    0x50(%rdi),%rax
 1022921:	cmp    $0xffffffffffffffff,%rax
 1022925:	je     102292e <myl_rc_storage_retire+0x7e>
 1022927:	inc    %rax
 102292a:	mov    %rax,0x50(%rdi)
 102292e:	decq   0x40(%rdi)
 1022932:	mov    -0x50(%rsi),%rax
 1022936:	test   %rax,%rax
 1022939:	je     1022977 <myl_rc_storage_retire+0xc7>
 102293b:	mov    -0x48(%rsi),%rcx
 102293f:	mov    %rcx,0x8(%rax)
 1022943:	test   %rcx,%rcx
 1022946:	je     102294b <myl_rc_storage_retire+0x9b>
 1022948:	mov    %rax,(%rcx)
 102294b:	mov    -0x40(%rsi),%rax
 102294f:	sub    %rax,0x18(%rdi)
 1022953:	mov    0x1608(%rdi),%rcx
 102295a:	test   %rcx,%rcx
 102295d:	je     1022999 <myl_rc_storage_retire+0xe9>
 102295f:	add    $0xffffffffffffffb0,%rsi
 1022963:	mov    0x20(%rcx),%rcx
 1022967:	sub    %rax,0x208(%rcx)
 102296e:	mov    %rsi,%rdi
 1022971:	pop    %rbp
 1022972:	jmp    10229a0 <large_release>
 1022977:	mov    0x1608(%rdi),%rdx
 102297e:	test   %rdx,%rdx
 1022981:	je     1022999 <myl_rc_storage_retire+0xe9>
 1022983:	mov    -0x48(%rsi),%rcx
 1022987:	mov    0x20(%rdx),%rdx
 102298b:	mov    %rcx,0x200(%rdx)
 1022992:	test   %rcx,%rcx
 1022995:	jne    1022948 <myl_rc_storage_retire+0x98>
 1022997:	jmp    102294b <myl_rc_storage_retire+0x9b>
 1022999:	call   1018954 <myl_rc_invariant_failed>
 102299e:	int3
 102299f:	int3

00000000010229a0 <large_release>:
 10229a0:	push   %rbp
 10229a1:	mov    %rsp,%rbp
 10229a4:	mov    0x20(%rdi),%rsi
 10229a8:	test   %rsi,%rsi
 10229ab:	je     10229b3 <large_release+0x13>
 10229ad:	pop    %rbp
 10229ae:	jmp    10278f0 <munmap@plt>
 10229b3:	pop    %rbp
 10229b4:	jmp    10276f0 <free@plt>
 10229b9:	int3
 10229ba:	int3
 10229bb:	int3
 10229bc:	int3
 10229bd:	int3
 10229be:	int3
 10229bf:	int3

00000000010229c0 <destroy>:
 10229c0:	push   %rbp
 10229c1:	mov    %rsp,%rbp
 10229c4:	push   %r15
 10229c6:	push   %r14
 10229c8:	push   %r13
 10229ca:	push   %r12
 10229cc:	push   %rbx
 10229cd:	push   %rax
 10229ce:	test   %rdi,%rdi
 10229d1:	je     1022c8e <destroy+0x2ce>
 10229d7:	mov    %rdi,%rbx
 10229da:	mov    0x1608(%rdi),%rax
 10229e1:	test   %rax,%rax
 10229e4:	je     1022c8e <destroy+0x2ce>
 10229ea:	mov    0x20(%rax),%rax
 10229ee:	mov    %rax,-0x30(%rbp)
 10229f2:	xor    %eax,%eax
 10229f4:	mov    0x1610(%rbx,%rax,8),%rcx
 10229fc:	test   %rcx,%rcx
 10229ff:	jne    1022a40 <destroy+0x80>
 1022a01:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022a10:	movq   $0x0,0x1610(%rbx,%rax,8)
 1022a1c:	inc    %rax
 1022a1f:	cmp    $0x20,%rax
 1022a23:	je     1022a58 <destroy+0x98>
 1022a25:	mov    0x1610(%rbx,%rax,8),%rcx
 1022a2d:	test   %rcx,%rcx
 1022a30:	je     1022a10 <destroy+0x50>
 1022a32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022a40:	mov    %rcx,%rdx
 1022a43:	and    $0xffffffffffff0000,%rdx
 1022a4a:	decq   0x38(%rdx)
 1022a4e:	mov    (%rcx),%rcx
 1022a51:	test   %rcx,%rcx
 1022a54:	jne    1022a40 <destroy+0x80>
 1022a56:	jmp    1022a10 <destroy+0x50>
 1022a58:	movq   $0x0,0x1710(%rbx)
 1022a63:	xor    %r15d,%r15d
 1022a66:	jmp    1022a7d <destroy+0xbd>
 1022a68:	nopl   0x0(%rax,%rax,1)
 1022a70:	inc    %r15
 1022a73:	cmp    $0x20,%r15
 1022a77:	je     1022bc2 <destroy+0x202>
 1022a7d:	mov    %r15,%r12
 1022a80:	shl    $0x4,%r12
 1022a84:	mov    -0x30(%rbp),%rax
 1022a88:	mov    (%rax,%r12,1),%r13
 1022a8c:	test   %r13,%r13
 1022a8f:	je     1022a70 <destroy+0xb0>
 1022a91:	add    -0x30(%rbp),%r12
 1022a95:	jmp    1022ac5 <destroy+0x105>
 1022a97:	nopw   0x0(%rax,%rax,1)
 1022aa0:	mov    0x448(%r14),%rcx
 1022aa7:	mov    %rcx,0x0(%r13)
 1022aab:	mov    %r13,0x448(%r14)
 1022ab2:	inc    %rax
 1022ab5:	mov    %rax,0x450(%r14)
 1022abc:	mov    (%r12),%r13
 1022ac0:	test   %r13,%r13
 1022ac3:	je     1022a70 <destroy+0xb0>
 1022ac5:	mov    0x1608(%rbx),%rcx
 1022acc:	test   %rcx,%rcx
 1022acf:	je     1022c8e <destroy+0x2ce>
 1022ad5:	mov    0x0(%r13),%rax
 1022ad9:	shl    $0x4,%rax
 1022add:	add    0x20(%rcx),%rax
 1022ae1:	cmpq   $0x0,0x48(%r13)
 1022ae6:	jne    1022af2 <destroy+0x132>
 1022ae8:	mov    0x30(%r13),%rcx
 1022aec:	cmp    0x40(%r13),%rcx
 1022af0:	je     1022b1c <destroy+0x15c>
 1022af2:	mov    0x20(%r13),%rcx
 1022af6:	mov    0x28(%r13),%rdx
 1022afa:	test   %rcx,%rcx
 1022afd:	je     1022bb0 <destroy+0x1f0>
 1022b03:	mov    %rdx,0x28(%rcx)
 1022b07:	test   %rdx,%rdx
 1022b0a:	je     1022b10 <destroy+0x150>
 1022b0c:	mov    %rcx,0x20(%rdx)
 1022b10:	lea    0x20(%r13),%rcx
 1022b14:	vxorps %xmm0,%xmm0,%xmm0
 1022b18:	vmovups %xmm0,(%rcx)
 1022b1c:	mov    0x10(%r13),%rdx
 1022b20:	mov    0x18(%r13),%rcx
 1022b24:	test   %rdx,%rdx
 1022b27:	je     1022ba0 <destroy+0x1e0>
 1022b29:	mov    %rcx,0x18(%rdx)
 1022b2d:	test   %rcx,%rcx
 1022b30:	je     1022b3a <destroy+0x17a>
 1022b32:	mov    0x10(%r13),%rax
 1022b36:	mov    %rax,0x10(%rcx)
 1022b3a:	addq   $0xffffffffffff0000,0x18(%rbx)
 1022b42:	mov    0x1608(%rbx),%rax
 1022b49:	test   %rax,%rax
 1022b4c:	je     1022c8e <destroy+0x2ce>
 1022b52:	mov    0x20(%rax),%r14
 1022b56:	addq   $0xffffffffffff0000,0x208(%r14)
 1022b61:	mov    0x450(%r14),%rax
 1022b68:	cmp    $0x10,%rax
 1022b6c:	jb     1022aa0 <destroy+0xe0>
 1022b72:	lea    0x1000(%r13),%rdi
 1022b79:	mov    $0xf000,%esi
 1022b7e:	mov    $0x4,%edx
 1022b83:	call   1027a70 <madvise@plt>
 1022b88:	mov    0x450(%r14),%rax
 1022b8f:	jmp    1022aa0 <destroy+0xe0>
 1022b94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022ba0:	mov    %rcx,(%rax)
 1022ba3:	test   %rcx,%rcx
 1022ba6:	jne    1022b32 <destroy+0x172>
 1022ba8:	jmp    1022b3a <destroy+0x17a>
 1022baa:	nopw   0x0(%rax,%rax,1)
 1022bb0:	mov    %rdx,0x8(%rax)
 1022bb4:	test   %rdx,%rdx
 1022bb7:	jne    1022b0c <destroy+0x14c>
 1022bbd:	jmp    1022b10 <destroy+0x150>
 1022bc2:	mov    -0x30(%rbp),%r14
 1022bc6:	cmpq   $0x0,0x438(%r14)
 1022bce:	je     1022c23 <destroy+0x263>
 1022bd0:	lea    0x230(%r14),%r15
 1022bd7:	mov    $0xfffffffffffffe00,%r12
 1022bde:	xor    %r13d,%r13d
 1022be1:	jmp    1022c17 <destroy+0x257>
 1022be3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022bf0:	mov    0x430(%r14),%rax
 1022bf7:	add    %r12,%rax
 1022bfa:	mov    (%rax),%rdi
 1022bfd:	mov    $0x200000,%esi
 1022c02:	call   10278f0 <munmap@plt>
 1022c07:	inc    %r13
 1022c0a:	add    $0x8,%r12
 1022c0e:	cmp    0x438(%r14),%r13
 1022c15:	jae    1022c23 <destroy+0x263>
 1022c17:	cmp    $0x3f,%r13
 1022c1b:	ja     1022bf0 <destroy+0x230>
 1022c1d:	lea    (%r15,%r13,8),%rax
 1022c21:	jmp    1022bfa <destroy+0x23a>
 1022c23:	mov    0x440(%r14),%rax
 1022c2a:	shl    $0x3,%rax
 1022c2e:	sub    %rax,0x18(%rbx)
 1022c32:	mov    0x1608(%rbx),%rcx
 1022c39:	test   %rcx,%rcx
 1022c3c:	je     1022c8e <destroy+0x2ce>
 1022c3e:	mov    0x20(%rcx),%rcx
 1022c42:	sub    %rax,0x208(%rcx)
 1022c49:	mov    0x430(%r14),%rdi
 1022c50:	call   10276f0 <free@plt>
 1022c55:	addq   $0xfffffffffffffba8,0x18(%rbx)
 1022c5d:	mov    0x1608(%rbx),%rax
 1022c64:	test   %rax,%rax
 1022c67:	je     1022c8e <destroy+0x2ce>
 1022c69:	mov    0x20(%rax),%rax
 1022c6d:	addq   $0xfffffffffffffba8,0x208(%rax)
 1022c78:	mov    %r14,%rdi
 1022c7b:	add    $0x8,%rsp
 1022c7f:	pop    %rbx
 1022c80:	pop    %r12
 1022c82:	pop    %r13
 1022c84:	pop    %r14
 1022c86:	pop    %r15
 1022c88:	pop    %rbp
 1022c89:	jmp    10276f0 <free@plt>
 1022c8e:	call   1018954 <myl_rc_invariant_failed>
 1022c93:	int3
 1022c94:	int3
 1022c95:	int3
 1022c96:	int3
 1022c97:	int3
 1022c98:	int3
 1022c99:	int3
 1022c9a:	int3
 1022c9b:	int3
 1022c9c:	int3
 1022c9d:	int3
 1022c9e:	int3
 1022c9f:	int3

0000000001022ca0 <teardown>:
 1022ca0:	push   %rbp
 1022ca1:	mov    %rsp,%rbp
 1022ca4:	push   %r15
 1022ca6:	push   %r14
 1022ca8:	push   %r13
 1022caa:	push   %r12
 1022cac:	push   %rbx
 1022cad:	sub    $0x18,%rsp
 1022cb1:	mov    0x1608(%rdi),%rax
 1022cb8:	cmpl   $0x0,0xd0(%rax)
 1022cbf:	jne    1022f69 <teardown+0x2c9>
 1022cc5:	cmpq   $0x0,0xc0(%rax)
 1022ccd:	jne    1022f69 <teardown+0x2c9>
 1022cd3:	mov    %rdi,%rbx
 1022cd6:	mov    0x20(%rax),%r14
 1022cda:	xor    %eax,%eax
 1022cdc:	mov    0x1610(%rbx,%rax,8),%rcx
 1022ce4:	test   %rcx,%rcx
 1022ce7:	jne    1022d20 <teardown+0x80>
 1022ce9:	nopl   0x0(%rax)
 1022cf0:	movq   $0x0,0x1610(%rbx,%rax,8)
 1022cfc:	inc    %rax
 1022cff:	cmp    $0x20,%rax
 1022d03:	je     1022d38 <teardown+0x98>
 1022d05:	mov    0x1610(%rbx,%rax,8),%rcx
 1022d0d:	test   %rcx,%rcx
 1022d10:	je     1022cf0 <teardown+0x50>
 1022d12:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022d20:	mov    %rcx,%rdx
 1022d23:	and    $0xffffffffffff0000,%rdx
 1022d2a:	decq   0x38(%rdx)
 1022d2e:	mov    (%rcx),%rcx
 1022d31:	test   %rcx,%rcx
 1022d34:	jne    1022d20 <teardown+0x80>
 1022d36:	jmp    1022cf0 <teardown+0x50>
 1022d38:	movq   $0x0,0x1710(%rbx)
 1022d43:	mov    0x200(%r14),%rdi
 1022d4a:	xor    %r15d,%r15d
 1022d4d:	test   %rdi,%rdi
 1022d50:	je     1022da2 <teardown+0x102>
 1022d52:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022d60:	mov    0x8(%rdi),%rax
 1022d64:	mov    %rax,0x200(%r14)
 1022d6b:	mov    0x10(%rdi),%rax
 1022d6f:	sub    %rax,0x18(%rbx)
 1022d73:	mov    0x1608(%rbx),%rcx
 1022d7a:	test   %rcx,%rcx
 1022d7d:	je     1022f69 <teardown+0x2c9>
 1022d83:	mov    0x20(%rcx),%rcx
 1022d87:	sub    %rax,0x208(%rcx)
 1022d8e:	call   10229a0 <large_release>
 1022d93:	inc    %r15
 1022d96:	mov    0x200(%r14),%rdi
 1022d9d:	test   %rdi,%rdi
 1022da0:	jne    1022d60 <teardown+0xc0>
 1022da2:	xor    %r13d,%r13d
 1022da5:	mov    %r14,-0x30(%rbp)
 1022da9:	jmp    1022dc5 <teardown+0x125>
 1022dab:	nopl   0x0(%rax,%rax,1)
 1022db0:	mov    -0x38(%rbp),%r13
 1022db4:	inc    %r13
 1022db7:	cmp    $0x20,%r13
 1022dbb:	mov    -0x30(%rbp),%r14
 1022dbf:	je     1022f12 <teardown+0x272>
 1022dc5:	mov    %r13,-0x38(%rbp)
 1022dc9:	shl    $0x4,%r13
 1022dcd:	mov    %r14,%rax
 1022dd0:	mov    (%r14,%r13,1),%r14
 1022dd4:	test   %r14,%r14
 1022dd7:	je     1022db0 <teardown+0x110>
 1022dd9:	add    %rax,%r13
 1022ddc:	jmp    1022e07 <teardown+0x167>
 1022dde:	xchg   %ax,%ax
 1022de0:	mov    0x448(%r12),%rcx
 1022de8:	mov    %rcx,(%r14)
 1022deb:	mov    %r14,0x448(%r12)
 1022df3:	inc    %rax
 1022df6:	mov    %rax,0x450(%r12)
 1022dfe:	mov    0x0(%r13),%r14
 1022e02:	test   %r14,%r14
 1022e05:	je     1022db0 <teardown+0x110>
 1022e07:	add    0x38(%r14),%r15
 1022e0b:	movq   $0x0,0x38(%r14)
 1022e13:	test   %rbx,%rbx
 1022e16:	je     1022f69 <teardown+0x2c9>
 1022e1c:	mov    0x1608(%rbx),%rcx
 1022e23:	test   %rcx,%rcx
 1022e26:	je     1022f69 <teardown+0x2c9>
 1022e2c:	mov    (%r14),%rax
 1022e2f:	shl    $0x4,%rax
 1022e33:	add    0x20(%rcx),%rax
 1022e37:	cmpq   $0x0,0x48(%r14)
 1022e3c:	jne    1022e48 <teardown+0x1a8>
 1022e3e:	mov    0x30(%r14),%rcx
 1022e42:	cmp    0x40(%r14),%rcx
 1022e46:	je     1022e72 <teardown+0x1d2>
 1022e48:	mov    0x20(%r14),%rcx
 1022e4c:	mov    0x28(%r14),%rdx
 1022e50:	test   %rcx,%rcx
 1022e53:	je     1022f00 <teardown+0x260>
 1022e59:	mov    %rdx,0x28(%rcx)
 1022e5d:	test   %rdx,%rdx
 1022e60:	je     1022e66 <teardown+0x1c6>
 1022e62:	mov    %rcx,0x20(%rdx)
 1022e66:	lea    0x20(%r14),%rcx
 1022e6a:	vxorps %xmm0,%xmm0,%xmm0
 1022e6e:	vmovups %xmm0,(%rcx)
 1022e72:	mov    0x10(%r14),%rdx
 1022e76:	mov    0x18(%r14),%rcx
 1022e7a:	test   %rdx,%rdx
 1022e7d:	je     1022ef0 <teardown+0x250>
 1022e7f:	mov    %rcx,0x18(%rdx)
 1022e83:	test   %rcx,%rcx
 1022e86:	je     1022e90 <teardown+0x1f0>
 1022e88:	mov    0x10(%r14),%rax
 1022e8c:	mov    %rax,0x10(%rcx)
 1022e90:	addq   $0xffffffffffff0000,0x18(%rbx)
 1022e98:	mov    0x1608(%rbx),%rax
 1022e9f:	test   %rax,%rax
 1022ea2:	je     1022f69 <teardown+0x2c9>
 1022ea8:	mov    0x20(%rax),%r12
 1022eac:	addq   $0xffffffffffff0000,0x208(%r12)
 1022eb8:	mov    0x450(%r12),%rax
 1022ec0:	cmp    $0x10,%rax
 1022ec4:	jb     1022de0 <teardown+0x140>
 1022eca:	lea    0x1000(%r14),%rdi
 1022ed1:	mov    $0xf000,%esi
 1022ed6:	mov    $0x4,%edx
 1022edb:	call   1027a70 <madvise@plt>
 1022ee0:	mov    0x450(%r12),%rax
 1022ee8:	jmp    1022de0 <teardown+0x140>
 1022eed:	nopl   (%rax)
 1022ef0:	mov    %rcx,(%rax)
 1022ef3:	test   %rcx,%rcx
 1022ef6:	jne    1022e88 <teardown+0x1e8>
 1022ef8:	jmp    1022e90 <teardown+0x1f0>
 1022efa:	nopw   0x0(%rax,%rax,1)
 1022f00:	mov    %rdx,0x8(%rax)
 1022f04:	test   %rdx,%rdx
 1022f07:	jne    1022e62 <teardown+0x1c2>
 1022f0d:	jmp    1022e66 <teardown+0x1c6>
 1022f12:	mov    0x40(%rbx),%rax
 1022f16:	sub    %r15,%rax
 1022f19:	jb     1022f69 <teardown+0x2c9>
 1022f1b:	mov    0x440(%r14),%rcx
 1022f22:	lea    0x458(,%rcx,8),%rcx
 1022f2a:	cmp    %rcx,0x208(%r14)
 1022f31:	jne    1022f69 <teardown+0x2c9>
 1022f33:	mov    %rax,0x40(%rbx)
 1022f37:	mov    0x1608(%rbx),%rax
 1022f3e:	movq   $0x0,0xc8(%rax)
 1022f49:	mov    0x50(%rbx),%rax
 1022f4d:	cmp    $0xffffffffffffffff,%rax
 1022f51:	je     1022f5a <teardown+0x2ba>
 1022f53:	inc    %rax
 1022f56:	mov    %rax,0x50(%rbx)
 1022f5a:	add    $0x18,%rsp
 1022f5e:	pop    %rbx
 1022f5f:	pop    %r12
 1022f61:	pop    %r13
 1022f63:	pop    %r14
 1022f65:	pop    %r15
 1022f67:	pop    %rbp
 1022f68:	ret
 1022f69:	call   1018954 <myl_rc_invariant_failed>
 1022f6e:	int3
 1022f6f:	int3

0000000001022f70 <raw_bytes>:
 1022f70:	push   %rbp
 1022f71:	mov    %rsp,%rbp
 1022f74:	push   %r15
 1022f76:	push   %r14
 1022f78:	push   %rbx
 1022f79:	sub    $0x28,%rsp
 1022f7d:	test   %rdi,%rdi
 1022f80:	je     10231b1 <raw_bytes+0x241>
 1022f86:	mov    0x1608(%rdi),%rax
 1022f8d:	test   %rax,%rax
 1022f90:	je     10231b1 <raw_bytes+0x241>
 1022f96:	test   %edx,%edx
 1022f98:	je     102303d <raw_bytes+0xcd>
 1022f9e:	mov    $0x10,%r8d
 1022fa4:	movabs $0x3fffffffff,%r9
 1022fae:	movq   $0x100ba90,-0x38(%rbp)
 1022fb6:	mov    %rsi,-0x30(%rbp)
 1022fba:	mov    %edx,-0x28(%rbp)
 1022fbd:	movl   $0x0,-0x24(%rbp)
 1022fc4:	movq   $0x0,-0x20(%rbp)
 1022fcc:	add    %rsi,%r8
 1022fcf:	setb   %cl
 1022fd2:	cmp    %r9,%rsi
 1022fd5:	seta   %sil
 1022fd9:	or     %cl,%sil
 1022fdc:	mov    $0x1,%ecx
 1022fe1:	jne    1023021 <raw_bytes+0xb1>
 1022fe3:	mov    $0x3,%ecx
 1022fe8:	cmp    0x70(%rdi),%edx
 1022feb:	ja     1023021 <raw_bytes+0xb1>
 1022fed:	lea    -0x38(%rbp),%rsi
 1022ff1:	lea    -0x20(%rbp),%rdx
 1022ff5:	mov    %rdi,%rbx
 1022ff8:	call   *(%rax)
 1022ffa:	mov    %eax,%ecx
 1022ffc:	mov    -0x20(%rbp),%rax
 1023000:	test   %ecx,%ecx
 1023002:	je     1023090 <raw_bytes+0x120>
 1023008:	test   %rax,%rax
 102300b:	jne    10231b1 <raw_bytes+0x241>
 1023011:	mov    0x1608(%rbx),%rax
 1023018:	test   %rax,%rax
 102301b:	je     10231b1 <raw_bytes+0x241>
 1023021:	cmpl   $0x0,0x124(%rax)
 1023028:	jne    1023030 <raw_bytes+0xc0>
 102302a:	mov    %ecx,0x124(%rax)
 1023030:	xor    %eax,%eax
 1023032:	add    $0x28,%rsp
 1023036:	pop    %rbx
 1023037:	pop    %r14
 1023039:	pop    %r15
 102303b:	pop    %rbp
 102303c:	ret
 102303d:	mov    $0x20,%r8d
 1023043:	movabs $0x3ffffffffffffff,%r9
 102304d:	cmp    $0x1fe0,%rsi
 1023054:	ja     1022fae <raw_bytes+0x3e>
 102305a:	cmpq   $0x10213b0,(%rax)
 1023061:	jne    1022fae <raw_bytes+0x3e>
 1023067:	lea    0x2f(%rsi),%rax
 102306b:	shr    $0x4,%rax
 102306f:	movzbl 0x100b820(%rax),%edx
 1023076:	mov    0x1610(%rdi,%rdx,8),%rax
 102307e:	test   %rax,%rax
 1023081:	je     102309a <raw_bytes+0x12a>
 1023083:	mov    (%rax),%r8
 1023086:	mov    %r8,0x1610(%rdi,%rdx,8)
 102308e:	jmp    10230bd <raw_bytes+0x14d>
 1023090:	test   %rax,%rax
 1023093:	jne    1023032 <raw_bytes+0xc2>
 1023095:	jmp    10231b1 <raw_bytes+0x241>
 102309a:	mov    %rdi,%rbx
 102309d:	mov    %rsi,%r14
 10230a0:	mov    %rdx,%rsi
 10230a3:	mov    %ecx,%r15d
 10230a6:	call   1022030 <slab_refill>
 10230ab:	mov    %r15d,%ecx
 10230ae:	mov    %r14,%rsi
 10230b1:	mov    %rbx,%rdi
 10230b4:	test   %rax,%rax
 10230b7:	je     1023165 <raw_bytes+0x1f5>
 10230bd:	test   %ecx,%ecx
 10230bf:	je     102312b <raw_bytes+0x1bb>
 10230c1:	lea    0x20(%rax),%rcx
 10230c5:	lea    0xf(%rsi),%rdx
 10230c9:	shr    $0x4,%rdx
 10230cd:	cmp    $0x8,%rdx
 10230d1:	ja     102318d <raw_bytes+0x21d>
 10230d7:	jmp    *0x1001ca0(,%rdx,8)
 10230de:	vxorps %xmm0,%xmm0,%xmm0
 10230e2:	vmovaps %xmm0,0x90(%rax)
 10230ea:	vxorps %xmm0,%xmm0,%xmm0
 10230ee:	vmovaps %xmm0,0x80(%rax)
 10230f6:	vxorps %xmm0,%xmm0,%xmm0
 10230fa:	vmovaps %xmm0,0x70(%rax)
 10230ff:	vxorps %xmm0,%xmm0,%xmm0
 1023103:	vmovaps %xmm0,0x60(%rax)
 1023108:	vxorps %xmm0,%xmm0,%xmm0
 102310c:	vmovaps %xmm0,0x50(%rax)
 1023111:	vxorps %xmm0,%xmm0,%xmm0
 1023115:	vmovaps %xmm0,0x40(%rax)
 102311a:	vxorps %xmm0,%xmm0,%xmm0
 102311e:	vmovaps %xmm0,0x30(%rax)
 1023123:	vxorps %xmm0,%xmm0,%xmm0
 1023127:	vmovaps %xmm0,(%rcx)
 102312b:	movq   $0x1,(%rax)
 1023132:	movq   $0x0,0x8(%rax)
 102313a:	shl    $0x2,%rsi
 102313e:	mov    %rsi,0x10(%rax)
 1023142:	movq   $0x100ba90,0x18(%rax)
 102314a:	vmovdqu 0x40(%rdi),%xmm0
 102314f:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1023153:	vpsubq %xmm1,%xmm0,%xmm0
 1023157:	vmovdqu %xmm0,0x40(%rdi)
 102315c:	add    $0x20,%rax
 1023160:	jmp    1023032 <raw_bytes+0xc2>
 1023165:	mov    0x1608(%rdi),%rax
 102316c:	test   %rax,%rax
 102316f:	je     10231b1 <raw_bytes+0x241>
 1023171:	cmpl   $0x0,0x124(%rax)
 1023178:	jne    1023030 <raw_bytes+0xc0>
 102317e:	movl   $0x1,0x124(%rax)
 1023188:	jmp    1023030 <raw_bytes+0xc0>
 102318d:	mov    %rdi,%r14
 1023190:	mov    %rcx,%rdi
 1023193:	mov    %rsi,%rbx
 1023196:	xor    %esi,%esi
 1023198:	mov    %rbx,%rdx
 102319b:	mov    %rax,%r15
 102319e:	call   1027650 <memset@plt>
 10231a3:	mov    %r15,%rax
 10231a6:	mov    %rbx,%rsi
 10231a9:	mov    %r14,%rdi
 10231ac:	jmp    102312b <raw_bytes+0x1bb>
 10231b1:	call   1018954 <myl_rc_invariant_failed>
 10231b6:	int3
 10231b7:	int3
 10231b8:	int3
 10231b9:	int3
 10231ba:	int3
 10231bb:	int3
 10231bc:	int3
 10231bd:	int3
 10231be:	int3
 10231bf:	int3

00000000010231c0 <storage_extend>:
 10231c0:	push   %rbp
 10231c1:	mov    %rsp,%rbp
 10231c4:	push   %r15
 10231c6:	push   %r14
 10231c8:	push   %r13
 10231ca:	push   %r12
 10231cc:	push   %rbx
 10231cd:	sub    $0x18,%rsp
 10231d1:	test   %rsi,%rsi
 10231d4:	je     10232d3 <storage_extend+0x113>
 10231da:	mov    -0x10(%rsi),%rax
 10231de:	movabs $0xc000000000000003,%r8
 10231e8:	and    %rax,%r8
 10231eb:	neg    %r8
 10231ee:	jno    10232d3 <storage_extend+0x113>
 10231f4:	cmpq   $0x1,-0x20(%rsi)
 10231f9:	jne    10232d3 <storage_extend+0x113>
 10231ff:	cmpq   $0x0,-0x18(%rsi)
 1023204:	jne    10232d3 <storage_extend+0x113>
 102320a:	movabs $0x1000000000000000,%r8
 1023214:	and    %r8,%rax
 1023217:	mov    %rdx,%r8
 102321a:	shr    $0x3a,%r8
 102321e:	or     %rax,%r8
 1023221:	jne    10232d3 <storage_extend+0x113>
 1023227:	mov    -0x8(%rsi),%rax
 102322b:	mov    (%rax),%rbx
 102322e:	test   %rbx,%rbx
 1023231:	je     10232d3 <storage_extend+0x113>
 1023237:	mov    $0xffffffffffffffaf,%rax
 102323e:	mov    %rdx,%r13
 1023241:	xor    %edx,%edx
 1023243:	div    %rbx
 1023246:	mov    %rax,%rdx
 1023249:	xor    %eax,%eax
 102324b:	cmp    %rdx,%r13
 102324e:	ja     10232d5 <storage_extend+0x115>
 1023254:	imul   %r13,%rbx
 1023258:	lea    0x20(%rbx),%r12
 102325c:	cmp    -0x38(%rsi),%r12
 1023260:	jbe    10232d3 <storage_extend+0x113>
 1023262:	mov    %ecx,-0x2c(%rbp)
 1023265:	add    $0x50,%rbx
 1023269:	mov    %rbx,%r14
 102326c:	mov    %rsi,%r15
 102326f:	sub    -0x40(%rsi),%r14
 1023273:	mov    %rdi,-0x38(%rbp)
 1023277:	mov    %r14,%rsi
 102327a:	call   1023370 <reserve>
 102327f:	test   %eax,%eax
 1023281:	je     10232d3 <storage_extend+0x113>
 1023283:	mov    %r15,%rdi
 1023286:	mov    -0x40(%r15),%r15
 102328a:	add    $0xffffffffffffffb0,%rdi
 102328e:	mov    %r15,%rsi
 1023291:	mov    %rbx,%rdx
 1023294:	call   10233f0 <large_grow>
 1023299:	test   %rax,%rax
 102329c:	je     10232d3 <storage_extend+0x113>
 102329e:	cmpl   $0x0,-0x2c(%rbp)
 10232a2:	je     10232c1 <storage_extend+0x101>
 10232a4:	cmpq   $0x0,0x20(%rax)
 10232a9:	jne    10232c1 <storage_extend+0x101>
 10232ab:	add    %rax,%r15
 10232ae:	mov    %r15,%rdi
 10232b1:	xor    %esi,%esi
 10232b3:	mov    %r14,%rdx
 10232b6:	mov    %rax,%r15
 10232b9:	call   1027650 <memset@plt>
 10232be:	mov    %r15,%rax
 10232c1:	mov    (%rax),%rcx
 10232c4:	test   %rcx,%rcx
 10232c7:	je     10232e4 <storage_extend+0x124>
 10232c9:	mov    %rax,0x8(%rcx)
 10232cd:	mov    -0x38(%rbp),%rcx
 10232d1:	jmp    1023304 <storage_extend+0x144>
 10232d3:	xor    %eax,%eax
 10232d5:	add    $0x18,%rsp
 10232d9:	pop    %rbx
 10232da:	pop    %r12
 10232dc:	pop    %r13
 10232de:	pop    %r14
 10232e0:	pop    %r15
 10232e2:	pop    %rbp
 10232e3:	ret
 10232e4:	mov    -0x38(%rbp),%rcx
 10232e8:	test   %rcx,%rcx
 10232eb:	je     1023363 <storage_extend+0x1a3>
 10232ed:	mov    0x1608(%rcx),%rdx
 10232f4:	test   %rdx,%rdx
 10232f7:	je     1023363 <storage_extend+0x1a3>
 10232f9:	mov    0x20(%rdx),%rdx
 10232fd:	mov    %rax,0x200(%rdx)
 1023304:	mov    0x8(%rax),%rdx
 1023308:	test   %rdx,%rdx
 102330b:	je     1023310 <storage_extend+0x150>
 102330d:	mov    %rax,(%rdx)
 1023310:	mov    %rbx,0x10(%rax)
 1023314:	mov    %r12,0x18(%rax)
 1023318:	movabs $0xf000000000000003,%rdx
 1023322:	and    0x40(%rax),%rdx
 1023326:	lea    (%rdx,%r13,4),%rdx
 102332a:	mov    %rdx,0x40(%rax)
 102332e:	add    %r14,0x18(%rcx)
 1023332:	mov    0x1608(%rcx),%rdx
 1023339:	test   %rdx,%rdx
 102333c:	je     1023363 <storage_extend+0x1a3>
 102333e:	mov    0x20(%rdx),%rdx
 1023342:	add    %r14,0x208(%rdx)
 1023349:	mov    0x50(%rcx),%rdx
 102334d:	cmp    $0xffffffffffffffff,%rdx
 1023351:	je     102335a <storage_extend+0x19a>
 1023353:	inc    %rdx
 1023356:	mov    %rdx,0x50(%rcx)
 102335a:	add    $0x50,%rax
 102335e:	jmp    10232d5 <storage_extend+0x115>
 1023363:	call   1018954 <myl_rc_invariant_failed>
 1023368:	int3
 1023369:	int3
 102336a:	int3
 102336b:	int3
 102336c:	int3
 102336d:	int3
 102336e:	int3
 102336f:	int3

0000000001023370 <reserve>:
 1023370:	push   %rbp
 1023371:	mov    %rsp,%rbp
 1023374:	push   %r14
 1023376:	push   %rbx
 1023377:	mov    %rsi,%r14
 102337a:	mov    %rdi,%rbx
 102337d:	mov    0x18(%rdi),%rcx
 1023381:	mov    %rcx,%rax
 1023384:	add    %rsi,%rax
 1023387:	jb     10233aa <reserve+0x3a>
 1023389:	mov    0x58(%rbx),%rdx
 102338d:	mov    $0x1,%eax
 1023392:	test   %rdx,%rdx
 1023395:	je     10233e8 <reserve+0x78>
 1023397:	sub    %rcx,%rdx
 102339a:	setb   %cl
 102339d:	cmp    %rdx,%r14
 10233a0:	seta   %dl
 10233a3:	or     %cl,%dl
 10233a5:	cmp    $0x1,%dl
 10233a8:	jne    10233e8 <reserve+0x78>
 10233aa:	mov    %rbx,%rdi
 10233ad:	call   1022440 <trim_empty>
 10233b2:	mov    0x18(%rbx),%rcx
 10233b6:	mov    %rcx,%rax
 10233b9:	add    %r14,%rax
 10233bc:	jb     10233df <reserve+0x6f>
 10233be:	mov    0x58(%rbx),%rdx
 10233c2:	mov    $0x1,%eax
 10233c7:	test   %rdx,%rdx
 10233ca:	je     10233e8 <reserve+0x78>
 10233cc:	sub    %rcx,%rdx
 10233cf:	setb   %cl
 10233d2:	cmp    %rdx,%r14
 10233d5:	seta   %dl
 10233d8:	or     %cl,%dl
 10233da:	cmp    $0x1,%dl
 10233dd:	jne    10233e8 <reserve+0x78>
 10233df:	movl   $0x1,0x6c(%rbx)
 10233e6:	xor    %eax,%eax
 10233e8:	pop    %rbx
 10233e9:	pop    %r14
 10233eb:	pop    %rbp
 10233ec:	ret
 10233ed:	int3
 10233ee:	int3
 10233ef:	int3

00000000010233f0 <large_grow>:
 10233f0:	push   %rbp
 10233f1:	mov    %rsp,%rbp
 10233f4:	push   %r15
 10233f6:	push   %r14
 10233f8:	push   %rbx
 10233f9:	push   %rax
 10233fa:	mov    %rsi,%rbx
 10233fd:	mov    0x20(%rdi),%rsi
 1023401:	test   %rsi,%rsi
 1023404:	setne  %cl
 1023407:	cmp    $0x20000,%rdx
 102340e:	setae  %r8b
 1023412:	or     %cl,%r8b
 1023415:	jne    1023429 <large_grow+0x39>
 1023417:	mov    %rdx,%rsi
 102341a:	add    $0x8,%rsp
 102341e:	pop    %rbx
 102341f:	pop    %r14
 1023421:	pop    %r15
 1023423:	pop    %rbp
 1023424:	jmp    10277f0 <realloc@plt>
 1023429:	test   %rsi,%rsi
 102342c:	je     1023468 <large_grow+0x78>
 102342e:	cmp    $0xffffffffffffefff,%rdx
 1023435:	ja     102349e <large_grow+0xae>
 1023437:	add    $0xfff,%rdx
 102343e:	and    $0xfffffffffffff000,%rdx
 1023445:	cmp    %rsi,%rdx
 1023448:	jbe    10234a0 <large_grow+0xb0>
 102344a:	mov    %rdx,%rbx
 102344d:	mov    $0x1,%ecx
 1023452:	xor    %eax,%eax
 1023454:	call   1027a80 <mremap@plt>
 1023459:	cmp    $0xffffffffffffffff,%rax
 102345d:	je     102349e <large_grow+0xae>
 102345f:	mov    %rax,%rdi
 1023462:	mov    %rbx,0x20(%rax)
 1023466:	jmp    10234a0 <large_grow+0xb0>
 1023468:	mov    %rdi,%r14
 102346b:	mov    %rdx,%rdi
 102346e:	call   1022830 <large_block>
 1023473:	test   %rax,%rax
 1023476:	je     102349e <large_grow+0xae>
 1023478:	mov    0x20(%rax),%r15
 102347c:	mov    %rax,%rdi
 102347f:	mov    %r14,%rsi
 1023482:	mov    %rbx,%rdx
 1023485:	mov    %rax,%rbx
 1023488:	call   10276a0 <memcpy@plt>
 102348d:	mov    %r15,0x20(%rbx)
 1023491:	mov    %r14,%rdi
 1023494:	call   10276f0 <free@plt>
 1023499:	mov    %rbx,%rdi
 102349c:	jmp    10234a0 <large_grow+0xb0>
 102349e:	xor    %edi,%edi
 10234a0:	mov    %rdi,%rax
 10234a3:	add    $0x8,%rsp
 10234a7:	pop    %rbx
 10234a8:	pop    %r14
 10234aa:	pop    %r15
 10234ac:	pop    %rbp
 10234ad:	ret
 10234ae:	int3
 10234af:	int3

00000000010234b0 <myl_rc_native_shape>:
 10234b0:	push   %rbp
 10234b1:	mov    %rsp,%rbp
 10234b4:	push   %r15
 10234b6:	push   %r14
 10234b8:	push   %r13
 10234ba:	push   %r12
 10234bc:	push   %rbx
 10234bd:	sub    $0xc8,%rsp
 10234c4:	mov    %rsi,%rbx
 10234c7:	mov    0x1608(%rdi),%rax
 10234ce:	mov    0x34(%rsi),%ecx
 10234d1:	cmp    %rcx,0xa0(%rax)
 10234d8:	jbe    10235fb <myl_rc_native_shape+0x14b>
 10234de:	mov    0x98(%rax),%rdx
 10234e5:	shl    $0x4,%rcx
 10234e9:	cmp    %rbx,(%rdx,%rcx,1)
 10234ed:	jne    10235fb <myl_rc_native_shape+0x14b>
 10234f3:	add    %rcx,%rdx
 10234f6:	mov    0x8(%rdx),%rax
 10234fa:	test   %rax,%rax
 10234fd:	jne    102376f <myl_rc_native_shape+0x2bf>
 1023503:	mov    (%rbx),%rax
 1023506:	mov    %rax,-0xa8(%rbp)
 102350d:	vxorps %xmm0,%xmm0,%xmm0
 1023511:	vmovups %ymm0,-0xa0(%rbp)
 1023519:	movzwl 0x30(%rbx),%eax
 102351d:	test   %eax,%eax
 102351f:	je     1023539 <myl_rc_native_shape+0x89>
 1023521:	cmp    $0x7,%eax
 1023524:	je     1023539 <myl_rc_native_shape+0x89>
 1023526:	cmp    $0x1,%eax
 1023529:	jne    10237bd <myl_rc_native_shape+0x30d>
 102352f:	movl   $0x1,-0xa0(%rbp)
 1023539:	vmovups %ymm0,-0xc8(%rbp)
 1023541:	vmovups %ymm0,-0xd8(%rbp)
 1023549:	mov    %rbx,-0xe8(%rbp)
 1023550:	lea    -0xa8(%rbp),%rax
 1023557:	mov    %rax,-0xe0(%rbp)
 102355e:	mov    0x1608(%rdi),%rax
 1023565:	test   %rax,%rax
 1023568:	je     10237b5 <myl_rc_native_shape+0x305>
 102356e:	cmpq   $0x0,0xc0(%rax)
 1023576:	jne    10237b5 <myl_rc_native_shape+0x305>
 102357c:	mov    0x34(%rbx),%ecx
 102357f:	cmp    %rcx,0xa0(%rax)
 1023586:	jbe    102361a <myl_rc_native_shape+0x16a>
 102358c:	mov    0x98(%rax),%rdx
 1023593:	shl    $0x4,%rcx
 1023597:	cmp    %rbx,(%rdx,%rcx,1)
 102359b:	jne    102361a <myl_rc_native_shape+0x16a>
 102359d:	add    %rcx,%rdx
 10235a0:	mov    0x8(%rdx),%rax
 10235a4:	test   %rax,%rax
 10235a7:	je     1023637 <myl_rc_native_shape+0x187>
 10235ad:	cmpq   $0x0,0x10(%rax)
 10235b2:	jne    10237b5 <myl_rc_native_shape+0x305>
 10235b8:	cmpq   $0x0,0x18(%rax)
 10235bd:	jne    10237b5 <myl_rc_native_shape+0x305>
 10235c3:	cmpq   $0x0,0x20(%rax)
 10235c8:	jne    10237b5 <myl_rc_native_shape+0x305>
 10235ce:	cmpq   $0x0,0x28(%rax)
 10235d3:	jne    10237b5 <myl_rc_native_shape+0x305>
 10235d9:	cmpq   $0x0,0x30(%rax)
 10235de:	jne    10237b5 <myl_rc_native_shape+0x305>
 10235e4:	cmpq   $0x0,0x38(%rax)
 10235e9:	jne    10237b5 <myl_rc_native_shape+0x305>
 10235ef:	mov    0x1608(%rdi),%rdi
 10235f6:	jmp    102374b <myl_rc_native_shape+0x29b>
 10235fb:	mov    %rdi,%rcx
 10235fe:	mov    %rax,%rdi
 1023601:	mov    %rbx,%rsi
 1023604:	call   1018f74 <myl_rc_binding_find_slow>
 1023609:	mov    %rcx,%rdi
 102360c:	test   %rax,%rax
 102360f:	jne    102376f <myl_rc_native_shape+0x2bf>
 1023615:	jmp    1023503 <myl_rc_native_shape+0x53>
 102361a:	mov    %rdi,%rcx
 102361d:	mov    %rax,%rdi
 1023620:	mov    %rbx,%rsi
 1023623:	vzeroupper
 1023626:	call   1018f74 <myl_rc_binding_find_slow>
 102362b:	mov    %rcx,%rdi
 102362e:	test   %rax,%rax
 1023631:	jne    10235ad <myl_rc_native_shape+0xfd>
 1023637:	movl   $0x5,-0x80(%rbp)
 102363e:	vxorps %xmm0,%xmm0,%xmm0
 1023642:	vmovups %xmm0,-0x7c(%rbp)
 1023647:	movl   $0x0,-0x6c(%rbp)
 102364e:	lea    -0xe8(%rbp),%rax
 1023655:	mov    %rax,-0x68(%rbp)
 1023659:	movq   $0x1,-0x60(%rbp)
 1023661:	vxorps %xmm0,%xmm0,%xmm0
 1023665:	vmovups %ymm0,-0x50(%rbp)
 102366a:	movq   $0x0,-0x30(%rbp)
 1023672:	mov    %rdi,%r14
 1023675:	mov    %rdi,-0x58(%rbp)
 1023679:	lea    -0x58(%rbp),%rdi
 102367d:	lea    -0xa8(%rbp),%rsi
 1023684:	vzeroupper
 1023687:	call   1019930 <builder_add>
 102368c:	test   %eax,%eax
 102368e:	je     10236a7 <myl_rc_native_shape+0x1f7>
 1023690:	lea    -0x58(%rbp),%rdi
 1023694:	lea    -0x80(%rbp),%rsi
 1023698:	xor    %edx,%edx
 102369a:	call   1019d40 <register_shapes>
 102369f:	test   %eax,%eax
 10236a1:	sete   %r15b
 10236a5:	jmp    10236aa <myl_rc_native_shape+0x1fa>
 10236a7:	xor    %r15d,%r15d
 10236aa:	mov    -0x58(%rbp),%r12
 10236ae:	mov    -0x50(%rbp),%rdi
 10236b2:	mov    -0x38(%rbp),%r13
 10236b6:	test   %rdi,%rdi
 10236b9:	mov    %r14,%rax
 10236bc:	je     10236fe <myl_rc_native_shape+0x24e>
 10236be:	lea    0x0(,%r13,8),%rax
 10236c6:	lea    (%rax,%rax,4),%rcx
 10236ca:	mov    0x18(%r12),%rax
 10236cf:	sub    %rcx,%rax
 10236d2:	jb     10237b5 <myl_rc_native_shape+0x305>
 10236d8:	mov    0x1608(%r12),%rdx
 10236e0:	mov    0x30(%rdx),%rsi
 10236e4:	sub    %rcx,%rsi
 10236e7:	jb     10237b5 <myl_rc_native_shape+0x305>
 10236ed:	mov    %rax,0x18(%r12)
 10236f2:	mov    %rsi,0x30(%rdx)
 10236f6:	call   10276f0 <free@plt>
 10236fb:	mov    %r14,%rax
 10236fe:	mov    -0x48(%rbp),%rdi
 1023702:	test   %rdi,%rdi
 1023705:	je     102373f <myl_rc_native_shape+0x28f>
 1023707:	shl    $0x4,%r13
 102370b:	mov    0x18(%r12),%rax
 1023710:	sub    %r13,%rax
 1023713:	jb     10237b5 <myl_rc_native_shape+0x305>
 1023719:	mov    0x1608(%r12),%rcx
 1023721:	mov    0x30(%rcx),%rdx
 1023725:	sub    %r13,%rdx
 1023728:	jb     10237b5 <myl_rc_native_shape+0x305>
 102372e:	mov    %rax,0x18(%r12)
 1023733:	mov    %rdx,0x30(%rcx)
 1023737:	call   10276f0 <free@plt>
 102373c:	mov    %r14,%rax
 102373f:	mov    0x1608(%rax),%rdi
 1023746:	test   %r15b,%r15b
 1023749:	je     1023788 <myl_rc_native_shape+0x2d8>
 102374b:	mov    0x34(%rbx),%eax
 102374e:	cmp    %rax,0xa0(%rdi)
 1023755:	jbe    10237a8 <myl_rc_native_shape+0x2f8>
 1023757:	mov    0x98(%rdi),%rcx
 102375e:	shl    $0x4,%rax
 1023762:	cmp    %rbx,(%rcx,%rax,1)
 1023766:	jne    10237a8 <myl_rc_native_shape+0x2f8>
 1023768:	add    %rax,%rcx
 102376b:	mov    0x8(%rcx),%rax
 102376f:	mov    0x8(%rax),%rax
 1023773:	add    $0xc8,%rsp
 102377a:	pop    %rbx
 102377b:	pop    %r12
 102377d:	pop    %r13
 102377f:	pop    %r14
 1023781:	pop    %r15
 1023783:	pop    %rbp
 1023784:	vzeroupper
 1023787:	ret
 1023788:	test   %rdi,%rdi
 102378b:	je     10237b5 <myl_rc_native_shape+0x305>
 102378d:	cmpl   $0x0,0x124(%rdi)
 1023794:	je     102379a <myl_rc_native_shape+0x2ea>
 1023796:	xor    %eax,%eax
 1023798:	jmp    1023773 <myl_rc_native_shape+0x2c3>
 102379a:	movl   $0x1,0x124(%rdi)
 10237a4:	xor    %eax,%eax
 10237a6:	jmp    1023773 <myl_rc_native_shape+0x2c3>
 10237a8:	mov    %rbx,%rsi
 10237ab:	vzeroupper
 10237ae:	call   1018f74 <myl_rc_binding_find_slow>
 10237b3:	jmp    102376f <myl_rc_native_shape+0x2bf>
 10237b5:	vzeroupper
 10237b8:	call   1018954 <myl_rc_invariant_failed>
 10237bd:	vzeroupper
 10237c0:	call   1027810 <abort@plt>
 10237c5:	int3
 10237c6:	int3
 10237c7:	int3
 10237c8:	int3
 10237c9:	int3
 10237ca:	int3
 10237cb:	int3
 10237cc:	int3
 10237cd:	int3
 10237ce:	int3
 10237cf:	int3

00000000010237d0 <flat_transfer>:
 10237d0:	push   %rbp
 10237d1:	mov    %rsp,%rbp
 10237d4:	push   %r15
 10237d6:	push   %r14
 10237d8:	push   %rbx
 10237d9:	push   %rax
 10237da:	mov    0x40(%rsi),%r9d
 10237de:	cmp    $0x10,%r9
 10237e2:	jbe    10237f4 <flat_transfer+0x24>
 10237e4:	mov    $0xffffffff,%eax
 10237e9:	add    $0x8,%rsp
 10237ed:	pop    %rbx
 10237ee:	pop    %r14
 10237f0:	pop    %r15
 10237f2:	pop    %rbp
 10237f3:	ret
 10237f4:	test   %rdi,%rdi
 10237f7:	je     10238f0 <flat_transfer+0x120>
 10237fd:	cmp    %rcx,%rdx
 1023800:	je     10238f0 <flat_transfer+0x120>
 1023806:	test   %rcx,%rcx
 1023809:	je     10238f0 <flat_transfer+0x120>
 102380f:	test   %rdx,%rdx
 1023812:	je     10238f0 <flat_transfer+0x120>
 1023818:	cmpq   $0x0,0x1608(%rdi)
 1023820:	je     10238f0 <flat_transfer+0x120>
 1023826:	mov    0x50(%rsi),%rbx
 102382a:	mov    %rdx,%rax
 102382d:	sub    %rcx,%rax
 1023830:	jbe    1023839 <flat_transfer+0x69>
 1023832:	cmp    %rbx,%rax
 1023835:	jb     10237e4 <flat_transfer+0x14>
 1023837:	jmp    1023844 <flat_transfer+0x74>
 1023839:	mov    %rcx,%rax
 102383c:	sub    %rdx,%rax
 102383f:	cmp    %rbx,%rax
 1023842:	jb     10237e4 <flat_transfer+0x14>
 1023844:	mov    $0x3,%eax
 1023849:	cmp    0x70(%rdi),%r8d
 102384d:	ja     10237e9 <flat_transfer+0x19>
 102384f:	cmpb   $0x0,0x46(%rsi)
 1023853:	je     1023876 <flat_transfer+0xa6>
 1023855:	mov    0x48(%rsi),%eax
 1023858:	mov    (%rcx,%rax,1),%eax
 102385b:	lea    0x5a(%rsi),%r10
 102385f:	cmp    $0x20,%rax
 1023863:	lea    0x5c(%rsi,%rax,2),%rax
 1023868:	cmovae %r10,%rax
 102386c:	test   %r9,%r9
 102386f:	jne    102387f <flat_transfer+0xaf>
 1023871:	jmp    10238f5 <flat_transfer+0x125>
 1023876:	lea    0x58(%rsi),%rax
 102387a:	test   %r9,%r9
 102387d:	je     10238f5 <flat_transfer+0x125>
 102387f:	movzwl (%rax),%eax
 1023882:	xor    %r10d,%r10d
 1023885:	jmp    10238a8 <flat_transfer+0xd8>
 1023887:	shr    $0x28,%r14
 102388b:	and    $0xfffff,%r14d
 1023892:	cmp    %r8d,%r14d
 1023895:	ja     10237e4 <flat_transfer+0x14>
 102389b:	nopl   0x0(%rax,%rax,1)
 10238a0:	inc    %r10
 10238a3:	cmp    %r10,%r9
 10238a6:	je     10238f5 <flat_transfer+0x125>
 10238a8:	bt     %r10d,%eax
 10238ac:	jae    10238a0 <flat_transfer+0xd0>
 10238ae:	movzwl 0x9c(%rsi,%r10,2),%r11d
 10238b7:	mov    (%rcx,%r11,1),%r11
 10238bb:	test   %r11,%r11
 10238be:	je     10238a0 <flat_transfer+0xd0>
 10238c0:	mov    -0x10(%r11),%r14
 10238c4:	test   $0x2,%r14b
 10238c8:	jne    10238a0 <flat_transfer+0xd0>
 10238ca:	bt     $0x3c,%r14
 10238cf:	jb     10237e4 <flat_transfer+0x14>
 10238d5:	bt     $0x3e,%r14
 10238da:	jb     1023887 <flat_transfer+0xb7>
 10238dc:	test   $0x1,%r14b
 10238e0:	jne    10238f0 <flat_transfer+0x120>
 10238e2:	cmpq   $0x0,-0x20(%r11)
 10238e7:	jne    10238a0 <flat_transfer+0xd0>
 10238e9:	cmpq   $0x0,-0x18(%r11)
 10238ee:	jne    10238a0 <flat_transfer+0xd0>
 10238f0:	call   1018954 <myl_rc_invariant_failed>
 10238f5:	cmp    $0x61,%rbx
 10238f9:	setb   %al
 10238fc:	test   $0x7,%bl
 10238ff:	sete   %sil
 1023903:	test   %sil,%al
 1023906:	je     102392b <flat_transfer+0x15b>
 1023908:	shr    $0x3,%rbx
 102390c:	dec    %rbx
 102390f:	cmp    $0xb,%rbx
 1023913:	ja     1023ac5 <flat_transfer+0x2f5>
 1023919:	jmp    *0x1001ce8(,%rbx,8)
 1023920:	mov    (%rcx),%rax
 1023923:	mov    %rax,(%rdx)
 1023926:	jmp    1023abe <flat_transfer+0x2ee>
 102392b:	mov    %rdi,%r15
 102392e:	mov    %rdx,%rdi
 1023931:	mov    %rcx,%rsi
 1023934:	mov    %rbx,%rdx
 1023937:	mov    %rcx,%r14
 102393a:	call   10276a0 <memcpy@plt>
 102393f:	mov    %r14,%rdi
 1023942:	xor    %esi,%esi
 1023944:	mov    %rbx,%rdx
 1023947:	call   1027650 <memset@plt>
 102394c:	mov    %r15,%rdi
 102394f:	jmp    1023ac5 <flat_transfer+0x2f5>
 1023954:	mov    0x58(%rcx),%rax
 1023958:	mov    %rax,0x58(%rdx)
 102395c:	mov    0x50(%rcx),%rax
 1023960:	mov    %rax,0x50(%rdx)
 1023964:	mov    0x48(%rcx),%rax
 1023968:	mov    %rax,0x48(%rdx)
 102396c:	mov    0x40(%rcx),%rax
 1023970:	mov    %rax,0x40(%rdx)
 1023974:	mov    0x38(%rcx),%rax
 1023978:	mov    %rax,0x38(%rdx)
 102397c:	mov    0x30(%rcx),%rax
 1023980:	mov    %rax,0x30(%rdx)
 1023984:	mov    0x28(%rcx),%rax
 1023988:	mov    %rax,0x28(%rdx)
 102398c:	mov    0x20(%rcx),%rax
 1023990:	mov    %rax,0x20(%rdx)
 1023994:	mov    0x18(%rcx),%rax
 1023998:	mov    %rax,0x18(%rdx)
 102399c:	mov    0x10(%rcx),%rax
 10239a0:	mov    %rax,0x10(%rdx)
 10239a4:	mov    0x8(%rcx),%rax
 10239a8:	mov    %rax,0x8(%rdx)
 10239ac:	mov    (%rcx),%rax
 10239af:	mov    %rax,(%rdx)
 10239b2:	cmp    $0xb,%rbx
 10239b6:	ja     1023ac5 <flat_transfer+0x2f5>
 10239bc:	jmp    *0x1001d48(,%rbx,8)
 10239c3:	movq   $0x0,0x58(%rcx)
 10239cb:	movq   $0x0,0x50(%rcx)
 10239d3:	movq   $0x0,0x48(%rcx)
 10239db:	movq   $0x0,0x40(%rcx)
 10239e3:	movq   $0x0,0x38(%rcx)
 10239eb:	movq   $0x0,0x30(%rcx)
 10239f3:	jmp    1023a96 <flat_transfer+0x2c6>
 10239f8:	mov    0x20(%rcx),%rax
 10239fc:	mov    %rax,0x20(%rdx)
 1023a00:	mov    0x18(%rcx),%rax
 1023a04:	mov    %rax,0x18(%rdx)
 1023a08:	mov    0x10(%rcx),%rax
 1023a0c:	mov    %rax,0x10(%rdx)
 1023a10:	mov    0x8(%rcx),%rax
 1023a14:	mov    %rax,0x8(%rdx)
 1023a18:	mov    (%rcx),%rax
 1023a1b:	mov    %rax,(%rdx)
 1023a1e:	jmp    1023a9e <flat_transfer+0x2ce>
 1023a20:	mov    0x10(%rcx),%rax
 1023a24:	mov    %rax,0x10(%rdx)
 1023a28:	mov    0x8(%rcx),%rax
 1023a2c:	mov    %rax,0x8(%rdx)
 1023a30:	mov    (%rcx),%rax
 1023a33:	mov    %rax,(%rdx)
 1023a36:	jmp    1023aae <flat_transfer+0x2de>
 1023a38:	mov    0x18(%rcx),%rax
 1023a3c:	mov    %rax,0x18(%rdx)
 1023a40:	mov    0x10(%rcx),%rax
 1023a44:	mov    %rax,0x10(%rdx)
 1023a48:	mov    0x8(%rcx),%rax
 1023a4c:	mov    %rax,0x8(%rdx)
 1023a50:	mov    (%rcx),%rax
 1023a53:	mov    %rax,(%rdx)
 1023a56:	jmp    1023aa6 <flat_transfer+0x2d6>
 1023a58:	mov    0x8(%rcx),%rax
 1023a5c:	mov    %rax,0x8(%rdx)
 1023a60:	mov    (%rcx),%rax
 1023a63:	mov    %rax,(%rdx)
 1023a66:	jmp    1023ab6 <flat_transfer+0x2e6>
 1023a68:	mov    0x28(%rcx),%rax
 1023a6c:	mov    %rax,0x28(%rdx)
 1023a70:	mov    0x20(%rcx),%rax
 1023a74:	mov    %rax,0x20(%rdx)
 1023a78:	mov    0x18(%rcx),%rax
 1023a7c:	mov    %rax,0x18(%rdx)
 1023a80:	mov    0x10(%rcx),%rax
 1023a84:	mov    %rax,0x10(%rdx)
 1023a88:	mov    0x8(%rcx),%rax
 1023a8c:	mov    %rax,0x8(%rdx)
 1023a90:	mov    (%rcx),%rax
 1023a93:	mov    %rax,(%rdx)
 1023a96:	movq   $0x0,0x28(%rcx)
 1023a9e:	movq   $0x0,0x20(%rcx)
 1023aa6:	movq   $0x0,0x18(%rcx)
 1023aae:	movq   $0x0,0x10(%rcx)
 1023ab6:	movq   $0x0,0x8(%rcx)
 1023abe:	movq   $0x0,(%rcx)
 1023ac5:	mov    0x1608(%rdi),%rcx
 1023acc:	xor    %eax,%eax
 1023ace:	cmpq   $0x0,0xc8(%rcx)
 1023ad6:	je     10237e9 <flat_transfer+0x19>
 1023adc:	call   101be30 <myl_rc_drain>
 1023ae1:	xor    %eax,%eax
 1023ae3:	jmp    10237e9 <flat_transfer+0x19>
 1023ae8:	int3
 1023ae9:	int3
 1023aea:	int3
 1023aeb:	int3
 1023aec:	int3
 1023aed:	int3
 1023aee:	int3
 1023aef:	int3

0000000001023af0 <myl_rc_native_retain>:
 1023af0:	push   %rbp
 1023af1:	mov    %rsp,%rbp
 1023af4:	push   %r15
 1023af6:	push   %r14
 1023af8:	push   %r13
 1023afa:	push   %r12
 1023afc:	push   %rbx
 1023afd:	sub    $0x228,%rsp
 1023b04:	mov    %r8d,-0x2c(%rbp)
 1023b08:	mov    %rcx,%r9
 1023b0b:	mov    %rdx,%r14
 1023b0e:	mov    %rsi,%r15
 1023b11:	mov    %rdi,%rbx
 1023b14:	mov    0x1608(%rdi),%rdi
 1023b1b:	mov    0x34(%rsi),%eax
 1023b1e:	cmp    %rax,0xa0(%rdi)
 1023b25:	jbe    1023faa <myl_rc_native_retain+0x4ba>
 1023b2b:	mov    0x98(%rdi),%rcx
 1023b32:	shl    $0x4,%rax
 1023b36:	cmp    %r15,(%rcx,%rax,1)
 1023b3a:	jne    1023faa <myl_rc_native_retain+0x4ba>
 1023b40:	add    %rax,%rcx
 1023b43:	mov    0x8(%rcx),%r12
 1023b47:	test   %r12,%r12
 1023b4a:	je     1023fbe <myl_rc_native_retain+0x4ce>
 1023b50:	cmpl   $0x0,0x40(%r12)
 1023b56:	jne    1023b6d <myl_rc_native_retain+0x7d>
 1023b58:	mov    0x1608(%rbx),%rax
 1023b5f:	cmpq   $0x0,0xc8(%rax)
 1023b67:	je     1023c7e <myl_rc_native_retain+0x18e>
 1023b6d:	mov    0x50(%r12),%r13
 1023b72:	cmpb   $0x0,0x44(%r12)
 1023b78:	setne  %al
 1023b7b:	test   %r13,%r13
 1023b7e:	setne  %cl
 1023b81:	and    %al,%cl
 1023b83:	cmp    $0x1,%cl
 1023b86:	jne    1023bcb <myl_rc_native_retain+0xdb>
 1023b88:	mov    0x1608(%rbx),%rax
 1023b8f:	test   %rax,%rax
 1023b92:	je     10242cc <myl_rc_native_retain+0x7dc>
 1023b98:	test   %r9,%r9
 1023b9b:	je     10242cc <myl_rc_native_retain+0x7dc>
 1023ba1:	test   %r14,%r14
 1023ba4:	je     10242cc <myl_rc_native_retain+0x7dc>
 1023baa:	cmpq   $0x0,0xc0(%rax)
 1023bb2:	jne    10242cc <myl_rc_native_retain+0x7dc>
 1023bb8:	mov    %r14,%rax
 1023bbb:	sub    %r9,%rax
 1023bbe:	ja     1023bc6 <myl_rc_native_retain+0xd6>
 1023bc0:	mov    %r9,%rax
 1023bc3:	sub    %r14,%rax
 1023bc6:	cmp    %r13,%rax
 1023bc9:	jae    1023c1b <myl_rc_native_retain+0x12b>
 1023bcb:	mov    0x8(%r12),%r13
 1023bd0:	test   %r13,%r13
 1023bd3:	je     10241a8 <myl_rc_native_retain+0x6b8>
 1023bd9:	mov    0x1608(%rbx),%rax
 1023be0:	test   %rax,%rax
 1023be3:	je     10242cc <myl_rc_native_retain+0x7dc>
 1023be9:	cmpq   $0x0,0xc0(%rax)
 1023bf1:	jne    10242cc <myl_rc_native_retain+0x7dc>
 1023bf7:	mov    %r9,-0x38(%rbp)
 1023bfb:	movzbl 0x45(%r12),%eax
 1023c01:	test   %eax,%eax
 1023c03:	je     1023c54 <myl_rc_native_retain+0x164>
 1023c05:	cmp    $0x3,%al
 1023c07:	jae    10242cc <myl_rc_native_retain+0x7dc>
 1023c0d:	cmp    $0x2,%eax
 1023c10:	jne    1023fec <myl_rc_native_retain+0x4fc>
 1023c16:	jmp    10242cc <myl_rc_native_retain+0x7dc>
 1023c1b:	mov    -0x2c(%rbp),%eax
 1023c1e:	cmp    0x70(%rbx),%eax
 1023c21:	jbe    1023cdb <myl_rc_native_retain+0x1eb>
 1023c27:	mov    %r14,%rdi
 1023c2a:	xor    %esi,%esi
 1023c2c:	mov    %r13,%rdx
 1023c2f:	call   1027650 <memset@plt>
 1023c34:	mov    0x1608(%rbx),%rcx
 1023c3b:	mov    $0x3,%r14d
 1023c41:	cmpq   $0x0,0xc8(%rcx)
 1023c49:	jne    1023ead <myl_rc_native_retain+0x3bd>
 1023c4f:	jmp    1023eca <myl_rc_native_retain+0x3da>
 1023c54:	mov    (%r12),%rsi
 1023c58:	mov    %rbx,%rdi
 1023c5b:	call   101c840 <myl_rc_native_has_unique>
 1023c60:	cmp    $0x1,%eax
 1023c63:	mov    $0x2,%eax
 1023c68:	sbb    $0x0,%eax
 1023c6b:	mov    %al,0x45(%r12)
 1023c70:	cmp    $0x2,%eax
 1023c73:	jne    1023fec <myl_rc_native_retain+0x4fc>
 1023c79:	jmp    10242cc <myl_rc_native_retain+0x7dc>
 1023c7e:	mov    (%r15),%rdx
 1023c81:	test   %rdx,%rdx
 1023c84:	je     1023b6d <myl_rc_native_retain+0x7d>
 1023c8a:	mov    %r14,%rax
 1023c8d:	sub    %r9,%rax
 1023c90:	ja     1023c98 <myl_rc_native_retain+0x1a8>
 1023c92:	mov    %r9,%rax
 1023c95:	sub    %r14,%rax
 1023c98:	cmp    %rdx,%rax
 1023c9b:	jb     1023b6d <myl_rc_native_retain+0x7d>
 1023ca1:	mov    -0x2c(%rbp),%eax
 1023ca4:	cmp    0x70(%rbx),%eax
 1023ca7:	jbe    1023eef <myl_rc_native_retain+0x3ff>
 1023cad:	mov    %r14,%rdi
 1023cb0:	xor    %esi,%esi
 1023cb2:	call   1027650 <memset@plt>
 1023cb7:	mov    0x1608(%rbx),%rax
 1023cbe:	test   %rax,%rax
 1023cc1:	je     10242cc <myl_rc_native_retain+0x7dc>
 1023cc7:	cmpl   $0x0,0x124(%rax)
 1023cce:	je     1023f99 <myl_rc_native_retain+0x4a9>
 1023cd4:	xor    %eax,%eax
 1023cd6:	jmp    102429c <myl_rc_native_retain+0x7ac>
 1023cdb:	cmp    $0x61,%r13
 1023cdf:	setae  %al
 1023ce2:	test   $0x7,%r13b
 1023ce6:	setne  %cl
 1023ce9:	or     %al,%cl
 1023ceb:	jne    1023d9b <myl_rc_native_retain+0x2ab>
 1023cf1:	mov    %r13,%rax
 1023cf4:	shr    $0x3,%rax
 1023cf8:	dec    %rax
 1023cfb:	cmp    $0xb,%rax
 1023cff:	ja     1023d66 <myl_rc_native_retain+0x276>
 1023d01:	jmp    *0x1001e08(,%rax,8)
 1023d08:	mov    0x58(%r9),%rax
 1023d0c:	mov    %rax,0x58(%r14)
 1023d10:	mov    0x50(%r9),%rax
 1023d14:	mov    %rax,0x50(%r14)
 1023d18:	mov    0x48(%r9),%rax
 1023d1c:	mov    %rax,0x48(%r14)
 1023d20:	mov    0x40(%r9),%rax
 1023d24:	mov    %rax,0x40(%r14)
 1023d28:	mov    0x38(%r9),%rax
 1023d2c:	mov    %rax,0x38(%r14)
 1023d30:	mov    0x30(%r9),%rax
 1023d34:	mov    %rax,0x30(%r14)
 1023d38:	mov    0x28(%r9),%rax
 1023d3c:	mov    %rax,0x28(%r14)
 1023d40:	mov    0x20(%r9),%rax
 1023d44:	mov    %rax,0x20(%r14)
 1023d48:	mov    0x18(%r9),%rax
 1023d4c:	mov    %rax,0x18(%r14)
 1023d50:	mov    0x10(%r9),%rax
 1023d54:	mov    %rax,0x10(%r14)
 1023d58:	mov    0x8(%r9),%rax
 1023d5c:	mov    %rax,0x8(%r14)
 1023d60:	mov    (%r9),%rax
 1023d63:	mov    %rax,(%r14)
 1023d66:	cmpb   $0x0,0x46(%r12)
 1023d6c:	je     1023db7 <myl_rc_native_retain+0x2c7>
 1023d6e:	mov    %r14,%r15
 1023d71:	mov    0x48(%r12),%eax
 1023d76:	mov    (%r9,%rax,1),%eax
 1023d7a:	lea    0x5a(%r12),%rcx
 1023d7f:	cmp    $0x20,%rax
 1023d83:	lea    0x5c(%r12,%rax,2),%rax
 1023d88:	cmovae %rcx,%rax
 1023d8c:	movzwl (%rax),%eax
 1023d8f:	xor    %r14d,%r14d
 1023d92:	test   %eax,%eax
 1023d94:	jne    1023dcd <myl_rc_native_retain+0x2dd>
 1023d96:	jmp    1023e9c <myl_rc_native_retain+0x3ac>
 1023d9b:	mov    %r14,%rdi
 1023d9e:	mov    %r9,%rsi
 1023da1:	mov    %r13,%rdx
 1023da4:	mov    %r9,%r15
 1023da7:	call   10276a0 <memcpy@plt>
 1023dac:	mov    %r15,%r9
 1023daf:	cmpb   $0x0,0x46(%r12)
 1023db5:	jne    1023d6e <myl_rc_native_retain+0x27e>
 1023db7:	mov    %r14,%r15
 1023dba:	lea    0x58(%r12),%rax
 1023dbf:	movzwl (%rax),%eax
 1023dc2:	xor    %r14d,%r14d
 1023dc5:	test   %eax,%eax
 1023dc7:	je     1023e9c <myl_rc_native_retain+0x3ac>
 1023dcd:	movabs $0x4000000000000000,%rcx
 1023dd7:	lea    0x2(%rcx),%rdx
 1023ddb:	jmp    1023dfa <myl_rc_native_retain+0x30a>
 1023ddd:	cmpq   $0x0,-0x18(%rsi)
 1023de2:	je     10242cc <myl_rc_native_retain+0x7dc>
 1023de8:	inc    %rdi
 1023deb:	mov    %rdi,-0x20(%rsi)
 1023def:	blsr   %eax,%eax
 1023df4:	je     1023e9c <myl_rc_native_retain+0x3ac>
 1023dfa:	tzcnt  %eax,%esi
 1023dfe:	movzwl 0x9c(%r12,%rsi,2),%esi
 1023e07:	mov    (%r9,%rsi,1),%rsi
 1023e0b:	test   %rsi,%rsi
 1023e0e:	je     1023def <myl_rc_native_retain+0x2ff>
 1023e10:	mov    -0x10(%rsi),%rdi
 1023e14:	test   %rcx,%rdi
 1023e17:	je     1023e2d <myl_rc_native_retain+0x33d>
 1023e19:	mov    %rdi,%r8
 1023e1c:	shr    $0x28,%r8
 1023e20:	and    $0xfffff,%r8d
 1023e27:	cmp    -0x2c(%rbp),%r8d
 1023e2b:	ja     1023e53 <myl_rc_native_retain+0x363>
 1023e2d:	test   %rdx,%rdi
 1023e30:	jne    1023def <myl_rc_native_retain+0x2ff>
 1023e32:	test   $0x1,%dil
 1023e36:	jne    10242cc <myl_rc_native_retain+0x7dc>
 1023e3c:	mov    -0x20(%rsi),%rdi
 1023e40:	test   %rdi,%rdi
 1023e43:	je     1023ddd <myl_rc_native_retain+0x2ed>
 1023e45:	cmp    $0xffffffffffffffff,%rdi
 1023e49:	jne    1023de8 <myl_rc_native_retain+0x2f8>
 1023e4b:	mov    $0x2,%r14d
 1023e51:	jmp    1023e60 <myl_rc_native_retain+0x370>
 1023e53:	mov    $0x3,%r14d
 1023e59:	nopl   0x0(%rax)
 1023e60:	tzcnt  %eax,%ecx
 1023e64:	movzwl 0x9c(%r12,%rcx,2),%ecx
 1023e6d:	movq   $0x0,(%r15,%rcx,1)
 1023e75:	blsr   %eax,%eax
 1023e7a:	jne    1023e60 <myl_rc_native_retain+0x370>
 1023e7c:	mov    $0x1,%ecx
 1023e81:	mov    %rbx,%rdi
 1023e84:	mov    %r12,%rsi
 1023e87:	mov    %r15,%rdx
 1023e8a:	call   101bbf0 <myl_rc_flat_edges_release>
 1023e8f:	mov    %r15,%rdi
 1023e92:	xor    %esi,%esi
 1023e94:	mov    %r13,%rdx
 1023e97:	call   1027650 <memset@plt>
 1023e9c:	mov    0x1608(%rbx),%rax
 1023ea3:	cmpq   $0x0,0xc8(%rax)
 1023eab:	je     1023eb5 <myl_rc_native_retain+0x3c5>
 1023ead:	mov    %rbx,%rdi
 1023eb0:	call   101be30 <myl_rc_drain>
 1023eb5:	test   %r14d,%r14d
 1023eb8:	je     1023ee5 <myl_rc_native_retain+0x3f5>
 1023eba:	mov    0x1608(%rbx),%rcx
 1023ec1:	test   %rcx,%rcx
 1023ec4:	je     10242cc <myl_rc_native_retain+0x7dc>
 1023eca:	xor    %eax,%eax
 1023ecc:	cmpl   $0x0,0x124(%rcx)
 1023ed3:	jne    102429c <myl_rc_native_retain+0x7ac>
 1023ed9:	mov    %r14d,0x124(%rcx)
 1023ee0:	jmp    102429c <myl_rc_native_retain+0x7ac>
 1023ee5:	mov    $0x1,%eax
 1023eea:	jmp    102429c <myl_rc_native_retain+0x7ac>
 1023eef:	cmp    $0x61,%rdx
 1023ef3:	setae  %al
 1023ef6:	test   $0x7,%dl
 1023ef9:	setne  %cl
 1023efc:	or     %al,%cl
 1023efe:	jne    1023f84 <myl_rc_native_retain+0x494>
 1023f04:	shr    $0x3,%rdx
 1023f08:	mov    $0x1,%eax
 1023f0d:	dec    %rdx
 1023f10:	cmp    $0xb,%rdx
 1023f14:	ja     102429c <myl_rc_native_retain+0x7ac>
 1023f1a:	jmp    *0x1001da8(,%rdx,8)
 1023f21:	mov    0x58(%r9),%rcx
 1023f25:	mov    %rcx,0x58(%r14)
 1023f29:	mov    0x50(%r9),%rcx
 1023f2d:	mov    %rcx,0x50(%r14)
 1023f31:	mov    0x48(%r9),%rcx
 1023f35:	mov    %rcx,0x48(%r14)
 1023f39:	mov    0x40(%r9),%rcx
 1023f3d:	mov    %rcx,0x40(%r14)
 1023f41:	mov    0x38(%r9),%rcx
 1023f45:	mov    %rcx,0x38(%r14)
 1023f49:	mov    0x30(%r9),%rcx
 1023f4d:	mov    %rcx,0x30(%r14)
 1023f51:	mov    0x28(%r9),%rcx
 1023f55:	mov    %rcx,0x28(%r14)
 1023f59:	mov    0x20(%r9),%rcx
 1023f5d:	mov    %rcx,0x20(%r14)
 1023f61:	mov    0x18(%r9),%rcx
 1023f65:	mov    %rcx,0x18(%r14)
 1023f69:	mov    0x10(%r9),%rcx
 1023f6d:	mov    %rcx,0x10(%r14)
 1023f71:	mov    0x8(%r9),%rcx
 1023f75:	mov    %rcx,0x8(%r14)
 1023f79:	mov    (%r9),%rcx
 1023f7c:	mov    %rcx,(%r14)
 1023f7f:	jmp    102429c <myl_rc_native_retain+0x7ac>
 1023f84:	mov    %r14,%rdi
 1023f87:	mov    %r9,%rsi
 1023f8a:	call   10276a0 <memcpy@plt>
 1023f8f:	mov    $0x1,%eax
 1023f94:	jmp    102429c <myl_rc_native_retain+0x7ac>
 1023f99:	movl   $0x3,0x124(%rax)
 1023fa3:	xor    %eax,%eax
 1023fa5:	jmp    102429c <myl_rc_native_retain+0x7ac>
 1023faa:	mov    %r15,%rsi
 1023fad:	call   1018f74 <myl_rc_binding_find_slow>
 1023fb2:	mov    %rax,%r12
 1023fb5:	test   %r12,%r12
 1023fb8:	jne    1023b50 <myl_rc_native_retain+0x60>
 1023fbe:	mov    %rbx,%rdi
 1023fc1:	mov    %r15,%rsi
 1023fc4:	mov    %r9,-0x38(%rbp)
 1023fc8:	call   10234b0 <myl_rc_native_shape>
 1023fcd:	test   %rax,%rax
 1023fd0:	je     10241a8 <myl_rc_native_retain+0x6b8>
 1023fd6:	mov    %rax,%r13
 1023fd9:	mov    %rbx,%rdi
 1023fdc:	mov    %r15,%rsi
 1023fdf:	call   101c840 <myl_rc_native_has_unique>
 1023fe4:	test   %eax,%eax
 1023fe6:	jne    10242cc <myl_rc_native_retain+0x7dc>
 1023fec:	mov    (%r15),%rdx
 1023fef:	mov    %r14,-0x48(%rbp)
 1023ff3:	mov    %r14,%rdi
 1023ff6:	xor    %esi,%esi
 1023ff8:	call   1027650 <memset@plt>
 1023ffd:	mov    0x1608(%rbx),%r14
 1024004:	test   %r14,%r14
 1024007:	je     10242cc <myl_rc_native_retain+0x7dc>
 102400d:	vxorps %xmm0,%xmm0,%xmm0
 1024011:	vmovups %ymm0,-0xb0(%rbp)
 1024019:	vmovups %ymm0,-0xd0(%rbp)
 1024021:	vmovups %ymm0,-0xf0(%rbp)
 1024029:	vmovups %ymm0,-0x110(%rbp)
 1024031:	vmovups %ymm0,-0x130(%rbp)
 1024039:	vmovups %ymm0,-0x150(%rbp)
 1024041:	movq   $0x0,-0x90(%rbp)
 102404c:	mov    %rbx,-0x80(%rbp)
 1024050:	lea    -0x250(%rbp),%rax
 1024057:	mov    %rax,-0x78(%rbp)
 102405b:	movq   $0x8,-0x70(%rbp)
 1024063:	vxorps %xmm0,%xmm0,%xmm0
 1024067:	vmovups %xmm0,-0x68(%rbp)
 102406c:	lea    -0x150(%rbp),%rax
 1024073:	mov    %rax,-0x58(%rbp)
 1024077:	mov    0x58(%r14),%rax
 102407b:	mov    0x60(%r14),%rdx
 102407f:	movzbl 0x70(%r14),%ecx
 1024084:	movabs $0x9e3779b97f4a7c15,%rsi
 102408e:	imul   %r13,%rsi
 1024092:	shrx   %rcx,%rsi,%r9
 1024097:	and    %rdx,%r9
 102409a:	mov    %r9,%rsi
 102409d:	shl    $0x4,%rsi
 10240a1:	mov    (%rax,%rsi,1),%rsi
 10240a5:	mov    %r9,%rdi
 10240a8:	cmp    %r13,%rsi
 10240ab:	mov    -0x38(%rbp),%rcx
 10240af:	je     10240db <myl_rc_native_retain+0x5eb>
 10240b1:	xor    %r15d,%r15d
 10240b4:	mov    %rsi,%r8
 10240b7:	mov    %r9,%rdi
 10240ba:	nopw   0x0(%rax,%rax,1)
 10240c0:	test   %r8,%r8
 10240c3:	je     102410a <myl_rc_native_retain+0x61a>
 10240c5:	inc    %rdi
 10240c8:	and    %rdx,%rdi
 10240cb:	mov    %rdi,%r8
 10240ce:	shl    $0x4,%r8
 10240d2:	mov    (%rax,%r8,1),%r8
 10240d6:	cmp    %r13,%r8
 10240d9:	jne    10240c0 <myl_rc_native_retain+0x5d0>
 10240db:	shl    $0x4,%rdi
 10240df:	mov    0x8(%rax,%rdi,1),%r15
 10240e4:	jmp    102410a <myl_rc_native_retain+0x61a>
 10240e6:	cs nopw 0x0(%rax,%rax,1)
 10240f0:	test   %rsi,%rsi
 10240f3:	je     10242cc <myl_rc_native_retain+0x7dc>
 10240f9:	inc    %r9
 10240fc:	and    %rdx,%r9
 10240ff:	mov    %r9,%rsi
 1024102:	shl    $0x4,%rsi
 1024106:	mov    (%rax,%rsi,1),%rsi
 102410a:	cmp    %r13,%rsi
 102410d:	jne    10240f0 <myl_rc_native_retain+0x600>
 102410f:	test   %r15,%r15
 1024112:	je     10242cc <myl_rc_native_retain+0x7dc>
 1024118:	shl    $0x4,%r9
 102411c:	mov    0x8(%rax,%r9,1),%rax
 1024121:	test   %rax,%rax
 1024124:	je     10242cc <myl_rc_native_retain+0x7dc>
 102412a:	mov    (%r15),%rdx
 102412d:	cmp    (%rax),%rdx
 1024130:	jne    10242cc <myl_rc_native_retain+0x7dc>
 1024136:	cmp    -0x48(%rbp),%rcx
 102413a:	je     10242cc <myl_rc_native_retain+0x7dc>
 1024140:	mov    $0x3,%r12d
 1024146:	mov    -0x2c(%rbp),%eax
 1024149:	cmp    0x70(%rbx),%eax
 102414c:	ja     102426d <myl_rc_native_retain+0x77d>
 1024152:	mov    0x28(%r15),%r12
 1024156:	cmp    $0x9,%r12
 102415a:	jb     10241fc <myl_rc_native_retain+0x70c>
 1024160:	mov    %rbx,-0x40(%rbp)
 1024164:	mov    %r12,%rax
 1024167:	shr    $0x3b,%rax
 102416b:	jne    10242cc <myl_rc_native_retain+0x7dc>
 1024171:	mov    %r12,%rbx
 1024174:	shl    $0x5,%rbx
 1024178:	mov    -0x40(%rbp),%rdx
 102417c:	mov    0x18(%rdx),%rsi
 1024180:	add    %rbx,%rsi
 1024183:	jb     1024193 <myl_rc_native_retain+0x6a3>
 1024185:	mov    0x58(%rdx),%rax
 1024189:	test   %rax,%rax
 102418c:	je     10241bc <myl_rc_native_retain+0x6cc>
 102418e:	cmp    %rax,%rsi
 1024191:	jbe    10241bc <myl_rc_native_retain+0x6cc>
 1024193:	movl   $0x1,0x6c(%rdx)
 102419a:	mov    $0x1,%r12d
 10241a0:	mov    %rdx,%rbx
 10241a3:	jmp    102426d <myl_rc_native_retain+0x77d>
 10241a8:	mov    (%r15),%rdx
 10241ab:	mov    %r14,%rdi
 10241ae:	xor    %esi,%esi
 10241b0:	call   1027650 <memset@plt>
 10241b5:	xor    %eax,%eax
 10241b7:	jmp    102429c <myl_rc_native_retain+0x7ac>
 10241bc:	mov    %rsi,-0x50(%rbp)
 10241c0:	mov    %rcx,-0x38(%rbp)
 10241c4:	mov    $0x1,%edi
 10241c9:	mov    %rbx,%rsi
 10241cc:	vzeroupper
 10241cf:	call   1027690 <calloc@plt>
 10241d4:	test   %rax,%rax
 10241d7:	je     10242c0 <myl_rc_native_retain+0x7d0>
 10241dd:	mov    -0x40(%rbp),%rcx
 10241e1:	mov    -0x50(%rbp),%rdx
 10241e5:	mov    %rdx,0x18(%rcx)
 10241e9:	add    %rbx,0x30(%r14)
 10241ed:	mov    %rcx,%rbx
 10241f0:	mov    %rax,-0x78(%rbp)
 10241f4:	mov    %r12,-0x70(%rbp)
 10241f8:	mov    -0x38(%rbp),%rcx
 10241fc:	mov    $0x1,%r8d
 1024202:	mov    %rbx,%rdi
 1024205:	mov    %r15,%rsi
 1024208:	mov    -0x48(%rbp),%r14
 102420c:	mov    %r14,%rdx
 102420f:	mov    %rcx,%r12
 1024212:	vzeroupper
 1024215:	call   101ca40 <myl_rc_value_seed>
 102421a:	mov    -0x2c(%rbp),%eax
 102421d:	mov    %eax,-0x60(%rbp)
 1024220:	lea    -0x80(%rbp),%rdi
 1024224:	mov    $0x1020ca0,%r8d
 102422a:	mov    %r15,%rsi
 102422d:	mov    %r14,%rdx
 1024230:	mov    %r12,%rcx
 1024233:	call   101ef10 <visit>
 1024238:	test   %eax,%eax
 102423a:	jne    1024249 <myl_rc_native_retain+0x759>
 102423c:	lea    -0x80(%rbp),%rdi
 1024240:	call   1020150 <finish_clones>
 1024245:	test   %eax,%eax
 1024247:	je     10242ae <myl_rc_native_retain+0x7be>
 1024249:	mov    %eax,%r12d
 102424c:	mov    $0x1,%ecx
 1024251:	mov    %rbx,%rdi
 1024254:	mov    %r13,%rsi
 1024257:	mov    %r14,%rdx
 102425a:	call   101b480 <myl_rc_edges_release>
 102425f:	mov    0x0(%r13),%rdx
 1024263:	mov    %r14,%rdi
 1024266:	xor    %esi,%esi
 1024268:	call   1027650 <memset@plt>
 102426d:	lea    -0x80(%rbp),%rdi
 1024271:	mov    $0x1,%esi
 1024276:	vzeroupper
 1024279:	call   10208e0 <dispose_walk>
 102427e:	mov    0x1608(%rbx),%rcx
 1024285:	test   %rcx,%rcx
 1024288:	je     10242cc <myl_rc_native_retain+0x7dc>
 102428a:	xor    %eax,%eax
 102428c:	cmpl   $0x0,0x124(%rcx)
 1024293:	jne    102429c <myl_rc_native_retain+0x7ac>
 1024295:	mov    %r12d,0x124(%rcx)
 102429c:	add    $0x228,%rsp
 10242a3:	pop    %rbx
 10242a4:	pop    %r12
 10242a6:	pop    %r13
 10242a8:	pop    %r14
 10242aa:	pop    %r15
 10242ac:	pop    %rbp
 10242ad:	ret
 10242ae:	lea    -0x80(%rbp),%rdi
 10242b2:	xor    %esi,%esi
 10242b4:	call   10208e0 <dispose_walk>
 10242b9:	mov    $0x1,%eax
 10242be:	jmp    102429c <myl_rc_native_retain+0x7ac>
 10242c0:	mov    $0x1,%r12d
 10242c6:	mov    -0x40(%rbp),%rbx
 10242ca:	jmp    102426d <myl_rc_native_retain+0x77d>
 10242cc:	vzeroupper
 10242cf:	call   1018954 <myl_rc_invariant_failed>
 10242d4:	int3
 10242d5:	int3
 10242d6:	int3
 10242d7:	int3
 10242d8:	int3
 10242d9:	int3
 10242da:	int3
 10242db:	int3
 10242dc:	int3
 10242dd:	int3
 10242de:	int3
 10242df:	int3

00000000010242e0 <_Unwind_GetIP>:
 10242e0:	push   %rbp
 10242e1:	mov    %rsp,%rbp
 10242e4:	sub    $0x10,%rsp
 10242e8:	lea    -0x8(%rbp),%rdx
 10242ec:	mov    $0xffffffff,%esi
 10242f1:	call   1024390 <__unw_get_reg>
 10242f6:	mov    -0x8(%rbp),%rax
 10242fa:	add    $0x10,%rsp
 10242fe:	pop    %rbp
 10242ff:	ret

0000000001024300 <__unw_init_local>:
 1024300:	push   %rbp
 1024301:	mov    %rsp,%rbp
 1024304:	lea    0x47f5(%rip),%rax        # 1028b00 <_ZTVN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EEE+0x10>
 102430b:	mov    %rax,(%rdi)
 102430e:	lea    0x7643(%rip),%rax        # 102b958 <_ZN9libunwind17LocalAddressSpace17sThisAddressSpaceE>
 1024315:	mov    %rax,0x8(%rdi)
 1024319:	vmovups (%rsi),%ymm0
 102431d:	vmovups 0x20(%rsi),%ymm1
 1024322:	vmovups 0x40(%rsi),%ymm2
 1024327:	vmovups 0x60(%rsi),%ymm3
 102432c:	vmovups %ymm0,0x10(%rdi)
 1024331:	vmovups %ymm1,0x30(%rdi)
 1024336:	vmovups %ymm2,0x50(%rdi)
 102433b:	vmovups %ymm3,0x70(%rdi)
 1024340:	vmovups 0x80(%rsi),%ymm0
 1024348:	vmovups %ymm0,0x90(%rdi)
 1024350:	mov    0xa0(%rsi),%rax
 1024357:	mov    %rax,0xb0(%rdi)
 102435e:	vxorps %xmm0,%xmm0,%xmm0
 1024362:	vmovups %ymm0,0xb8(%rdi)
 102436a:	vmovups %ymm0,0xd8(%rdi)
 1024372:	vmovups %ymm0,0xe2(%rdi)
 102437a:	xor    %esi,%esi
 102437c:	vzeroupper
 102437f:	call   1024b60 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb>
 1024384:	xor    %eax,%eax
 1024386:	pop    %rbp
 1024387:	ret
 1024388:	int3
 1024389:	int3
 102438a:	int3
 102438b:	int3
 102438c:	int3
 102438d:	int3
 102438e:	int3
 102438f:	int3

0000000001024390 <__unw_get_reg>:
 1024390:	push   %rbp
 1024391:	mov    %rsp,%rbp
 1024394:	push   %r15
 1024396:	push   %r14
 1024398:	push   %rbx
 1024399:	push   %rax
 102439a:	mov    %rdx,%rbx
 102439d:	mov    %esi,%r14d
 10243a0:	mov    %rdi,%r15
 10243a3:	mov    (%rdi),%rax
 10243a6:	call   *0x10(%rax)
 10243a9:	mov    %eax,%ecx
 10243ab:	mov    $0xffffe672,%eax
 10243b0:	test   %cl,%cl
 10243b2:	je     10243c5 <__unw_get_reg+0x35>
 10243b4:	mov    (%r15),%rax
 10243b7:	mov    %r15,%rdi
 10243ba:	mov    %r14d,%esi
 10243bd:	call   *0x18(%rax)
 10243c0:	mov    %rax,(%rbx)
 10243c3:	xor    %eax,%eax
 10243c5:	add    $0x8,%rsp
 10243c9:	pop    %rbx
 10243ca:	pop    %r14
 10243cc:	pop    %r15
 10243ce:	pop    %rbp
 10243cf:	ret

00000000010243d0 <__unw_step>:
 10243d0:	push   %rbp
 10243d1:	mov    %rsp,%rbp
 10243d4:	mov    (%rdi),%rax
 10243d7:	mov    0x40(%rax),%rax
 10243db:	xor    %esi,%esi
 10243dd:	pop    %rbp
 10243de:	jmp    *%rax

00000000010243e0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb>:
 10243e0:	push   %rbp
 10243e1:	mov    %rsp,%rbp
 10243e4:	push   %r15
 10243e6:	push   %r14
 10243e8:	push   %r13
 10243ea:	push   %r12
 10243ec:	push   %rbx
 10243ed:	sub    $0x28,%rsp
 10243f1:	mov    %rcx,%r15
 10243f4:	mov    %rdi,%r14
 10243f7:	mov    (%rsi),%ebx
 10243f9:	mov    $0xffffffff,%eax
 10243fe:	cmp    %rax,%rbx
 1024401:	je     1024439 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x59>
 1024403:	lea    0x4(%rsi),%r12
 1024407:	test   %rbx,%rbx
 102440a:	je     1024446 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x66>
 102440c:	mov    (%r12),%eax
 1024410:	test   %rax,%rax
 1024413:	je     1024452 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x72>
 1024415:	mov    %rsi,-0x50(%rbp)
 1024419:	mov    %rdx,-0x38(%rbp)
 102441d:	mov    %r12,%rsi
 1024420:	sub    %rax,%rsi
 1024423:	test   %r8b,%r8b
 1024426:	je     102445e <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x7e>
 1024428:	cmp    %rsi,(%r15)
 102442b:	je     1024472 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x92>
 102442d:	lea    -0x204ec(%rip),%rax        # 1003f48 <qbe_empty_registry+0x3f0>
 1024434:	jmp    102456b <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x18b>
 1024439:	mov    0x4(%rsi),%rbx
 102443d:	lea    0xc(%rsi),%r12
 1024441:	test   %rbx,%rbx
 1024444:	jne    102440c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x2c>
 1024446:	lea    -0x20519(%rip),%rax        # 1003f34 <qbe_empty_registry+0x3dc>
 102444d:	jmp    102456b <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x18b>
 1024452:	lea    -0x1ffd8(%rip),%rax        # 1004481 <qbe_empty_registry+0x929>
 1024459:	jmp    102456b <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x18b>
 102445e:	mov    %r14,%rdi
 1024461:	mov    %r15,%rdx
 1024464:	call   1024580 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE>
 1024469:	test   %rax,%rax
 102446c:	jne    102456b <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x18b>
 1024472:	add    %r12,%rbx
 1024475:	add    $0x4,%r12
 1024479:	mov    %r12,-0x30(%rbp)
 102447d:	movzbl 0x18(%r15),%ecx
 1024482:	lea    -0x30(%rbp),%r12
 1024486:	mov    %r14,%rdi
 1024489:	mov    %r12,%rsi
 102448c:	mov    %rbx,%rdx
 102448f:	xor    %r8d,%r8d
 1024492:	xor    %r9d,%r9d
 1024495:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 102449a:	mov    %rax,-0x48(%rbp)
 102449e:	movzbl 0x18(%r15),%ecx
 10244a3:	and    $0xf,%ecx
 10244a6:	mov    %r14,%rdi
 10244a9:	mov    %r12,%rsi
 10244ac:	mov    %rbx,%rdx
 10244af:	xor    %r8d,%r8d
 10244b2:	xor    %r9d,%r9d
 10244b5:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 10244ba:	mov    %rax,%r13
 10244bd:	mov    -0x38(%rbp),%rcx
 10244c1:	movq   $0x0,0x28(%rcx)
 10244c9:	cmpb   $0x0,0x31(%r15)
 10244ce:	je     102453e <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x15e>
 10244d0:	lea    -0x30(%rbp),%rdi
 10244d4:	mov    %rbx,%rsi
 10244d7:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10244dc:	mov    %rax,%r12
 10244df:	mov    -0x30(%rbp),%rcx
 10244e3:	add    %rcx,%r12
 10244e6:	movzbl 0x19(%r15),%eax
 10244eb:	cmp    $0xff,%al
 10244ed:	je     1024544 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x164>
 10244ef:	mov    %rcx,-0x40(%rbp)
 10244f3:	and    $0xf,%al
 10244f5:	movzbl %al,%ecx
 10244f8:	lea    -0x30(%rbp),%rsi
 10244fc:	mov    %r14,%rdi
 10244ff:	mov    %rbx,%rdx
 1024502:	xor    %r8d,%r8d
 1024505:	xor    %r9d,%r9d
 1024508:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 102450d:	test   %rax,%rax
 1024510:	je     1024544 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x164>
 1024512:	mov    -0x40(%rbp),%rax
 1024516:	mov    %rax,-0x30(%rbp)
 102451a:	movzbl 0x19(%r15),%ecx
 102451f:	lea    -0x30(%rbp),%rsi
 1024523:	mov    %r14,%rdi
 1024526:	mov    %rbx,%rdx
 1024529:	xor    %r8d,%r8d
 102452c:	xor    %r9d,%r9d
 102452f:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1024534:	mov    -0x38(%rbp),%rcx
 1024538:	mov    %rax,0x28(%rcx)
 102453c:	jmp    1024548 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x168>
 102453e:	mov    -0x30(%rbp),%r12
 1024542:	jmp    1024548 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb+0x168>
 1024544:	mov    -0x38(%rbp),%rcx
 1024548:	mov    -0x50(%rbp),%rax
 102454c:	mov    %rax,(%rcx)
 102454f:	sub    %rax,%rbx
 1024552:	mov    %rbx,0x8(%rcx)
 1024556:	mov    %r12,0x10(%rcx)
 102455a:	mov    -0x48(%rbp),%rax
 102455e:	mov    %rax,0x18(%rcx)
 1024562:	add    %rax,%r13
 1024565:	mov    %r13,0x20(%rcx)
 1024569:	xor    %eax,%eax
 102456b:	add    $0x28,%rsp
 102456f:	pop    %rbx
 1024570:	pop    %r12
 1024572:	pop    %r13
 1024574:	pop    %r14
 1024576:	pop    %r15
 1024578:	pop    %rbp
 1024579:	ret
 102457a:	int3
 102457b:	int3
 102457c:	int3
 102457d:	int3
 102457e:	int3
 102457f:	int3

0000000001024580 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE>:
 1024580:	push   %rbp
 1024581:	mov    %rsp,%rbp
 1024584:	push   %r15
 1024586:	push   %r14
 1024588:	push   %r13
 102458a:	push   %r12
 102458c:	push   %rbx
 102458d:	sub    $0x18,%rsp
 1024591:	mov    %rdx,%rbx
 1024594:	mov    %rsi,%r14
 1024597:	mov    %rdi,-0x38(%rbp)
 102459b:	movl   $0xff00,0x18(%rdx)
 10245a2:	vxorps %xmm0,%xmm0,%xmm0
 10245a6:	vmovups %xmm0,0x20(%rdx)
 10245ab:	movw   $0x0,0x30(%rdx)
 10245b1:	mov    %rsi,(%rdx)
 10245b4:	mov    (%rsi),%eax
 10245b6:	mov    $0xffffffff,%ecx
 10245bb:	cmp    %rcx,%rax
 10245be:	je     10245d6 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x56>
 10245c0:	lea    0x4(%r14),%r13
 10245c4:	lea    (%r14,%rax,1),%r12
 10245c8:	add    $0x4,%r12
 10245cc:	test   %rax,%rax
 10245cf:	jne    10245ef <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x6f>
 10245d1:	jmp    1024791 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x211>
 10245d6:	mov    0x4(%r14),%rax
 10245da:	lea    0xc(%r14),%r13
 10245de:	lea    (%rax,%r14,1),%r12
 10245e2:	add    $0xc,%r12
 10245e6:	test   %rax,%rax
 10245e9:	je     1024791 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x211>
 10245ef:	cmpl   $0x0,0x0(%r13)
 10245f4:	je     1024602 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x82>
 10245f6:	lea    -0x207e5(%rip),%rax        # 1003e18 <qbe_empty_registry+0x2c0>
 10245fd:	jmp    1024793 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x213>
 1024602:	movzbl 0x4(%r13),%r15d
 1024607:	mov    %r15d,%eax
 102460a:	and    $0xfd,%al
 102460c:	cmp    $0x1,%al
 102460e:	jne    10246bc <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x13c>
 1024614:	add    $0x5,%r13
 1024618:	mov    %r13,%rax
 102461b:	nopl   0x0(%rax,%rax,1)
 1024620:	cmpb   $0x0,(%rax)
 1024623:	lea    0x1(%rax),%rax
 1024627:	jne    1024620 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0xa0>
 1024629:	mov    %rax,-0x30(%rbp)
 102462d:	lea    -0x30(%rbp),%rdi
 1024631:	mov    %r12,%rsi
 1024634:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1024639:	mov    %eax,0x28(%rbx)
 102463c:	mov    -0x30(%rbp),%rax
 1024640:	mov    $0xfffffffffffffff9,%rdi
 1024647:	xor    %edx,%edx
 1024649:	xor    %esi,%esi
 102464b:	mov    %rax,%rcx
 102464e:	xchg   %ax,%ax
 1024650:	cmp    %r12,%rcx
 1024653:	je     10247a2 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x222>
 1024659:	add    $0x7,%rdi
 102465d:	movzbl (%rcx),%r9d
 1024661:	inc    %rcx
 1024664:	mov    %r9d,%r8d
 1024667:	and    $0x7f,%r9d
 102466b:	shlx   %rdi,%r9,%r9
 1024670:	or     %r9,%rdx
 1024673:	dec    %rsi
 1024676:	test   %r8b,%r8b
 1024679:	js     1024650 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0xd0>
 102467b:	lea    0x7(%rdi),%r9d
 102467f:	xor    %r10d,%r10d
 1024682:	cmp    $0x39,%rdi
 1024686:	mov    $0xffffffffffffffff,%rdi
 102468d:	shlx   %r9,%rdi,%rdi
 1024692:	cmovae %r10d,%edi
 1024696:	cmp    $0x40,%r8b
 102469a:	cmovb  %r10d,%edi
 102469e:	or     %edi,%edx
 10246a0:	sub    %rsi,%rax
 10246a3:	mov    %rax,-0x30(%rbp)
 10246a7:	mov    %edx,0x2c(%rbx)
 10246aa:	cmp    $0x1,%r15b
 10246ae:	jne    10246c8 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x148>
 10246b0:	inc    %rax
 10246b3:	mov    %rax,-0x30(%rbp)
 10246b7:	movzbl (%rcx),%eax
 10246ba:	jmp    10246d4 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x154>
 10246bc:	lea    -0x20138(%rip),%rax        # 100458b <qbe_empty_registry+0xa33>
 10246c3:	jmp    1024793 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x213>
 10246c8:	lea    -0x30(%rbp),%rdi
 10246cc:	mov    %r12,%rsi
 10246cf:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10246d4:	mov    %al,0x32(%rbx)
 10246d7:	movq   $0x0,-0x40(%rbp)
 10246df:	cmpb   $0x7a,0x0(%r13)
 10246e4:	jne    1024782 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x202>
 10246ea:	lea    -0x30(%rbp),%rdi
 10246ee:	mov    %r12,%rsi
 10246f1:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10246f6:	lea    -0x18bbd(%rip),%r15        # 100bb40 <raw_shape+0x40>
 10246fd:	jmp    1024706 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x186>
 10246ff:	movb   $0x1,0x30(%rbx)
 1024703:	inc    %r13
 1024706:	movzbl 0x0(%r13),%eax
 102470b:	lea    -0x4c(%rax),%ecx
 102470e:	cmp    $0x2e,%ecx
 1024711:	ja     102477e <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x1fe>
 1024713:	movslq (%r15,%rcx,4),%rax
 1024717:	add    %r15,%rax
 102471a:	jmp    *%rax
 102471c:	mov    -0x30(%rbp),%rax
 1024720:	movzbl (%rax),%ecx
 1024723:	mov    %cl,0x19(%rbx)
 1024726:	jmp    102473b <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x1bb>
 1024728:	movb   $0x1,0x31(%rbx)
 102472c:	inc    %r13
 102472f:	jmp    1024706 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x186>
 1024731:	mov    -0x30(%rbp),%rax
 1024735:	movzbl (%rax),%ecx
 1024738:	mov    %cl,0x18(%rbx)
 102473b:	inc    %rax
 102473e:	mov    %rax,-0x30(%rbp)
 1024742:	inc    %r13
 1024745:	jmp    1024706 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x186>
 1024747:	mov    -0x30(%rbp),%rax
 102474b:	movzbl (%rax),%ecx
 102474e:	mov    %cl,0x1a(%rbx)
 1024751:	inc    %rax
 1024754:	mov    %rax,-0x30(%rbp)
 1024758:	sub    %r14d,%eax
 102475b:	mov    %al,0x1b(%rbx)
 102475e:	mov    -0x38(%rbp),%rdi
 1024762:	lea    -0x30(%rbp),%rsi
 1024766:	mov    %r12,%rdx
 1024769:	xor    %r8d,%r8d
 102476c:	lea    -0x40(%rbp),%r9
 1024770:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1024775:	mov    %rax,0x20(%rbx)
 1024779:	inc    %r13
 102477c:	jmp    1024706 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x186>
 102477e:	test   %eax,%eax
 1024780:	jne    1024703 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE+0x183>
 1024782:	sub    (%rbx),%r12
 1024785:	mov    %r12,0x8(%rbx)
 1024789:	mov    -0x30(%rbp),%rax
 102478d:	mov    %rax,0x10(%rbx)
 1024791:	xor    %eax,%eax
 1024793:	add    $0x18,%rsp
 1024797:	pop    %rbx
 1024798:	pop    %r12
 102479a:	pop    %r13
 102479c:	pop    %r14
 102479e:	pop    %r15
 10247a0:	pop    %rbp
 10247a1:	ret
 10247a2:	mov    0x456f(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 10247a9:	mov    (%rbx),%rdi
 10247ac:	lea    -0x1fee8(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10247b3:	lea    -0x20271(%rip),%rdx        # 1004549 <qbe_empty_registry+0x9f1>
 10247ba:	lea    -0x20910(%rip),%rcx        # 1003eb1 <qbe_empty_registry+0x359>
 10247c1:	xor    %eax,%eax
 10247c3:	call   1027760 <fprintf@plt>
 10247c8:	mov    (%rbx),%rdi
 10247cb:	call   1027800 <fflush@plt>
 10247d0:	call   1027810 <abort@plt>
 10247d5:	int3
 10247d6:	int3
 10247d7:	int3
 10247d8:	int3
 10247d9:	int3
 10247da:	int3
 10247db:	int3
 10247dc:	int3
 10247dd:	int3
 10247de:	int3
 10247df:	int3

00000000010247e0 <_ZN9libunwind20AbstractUnwindCursorD2Ev>:
 10247e0:	push   %rbp
 10247e1:	mov    %rsp,%rbp
 10247e4:	pop    %rbp
 10247e5:	ret
 10247e6:	int3
 10247e7:	int3
 10247e8:	int3
 10247e9:	int3
 10247ea:	int3
 10247eb:	int3
 10247ec:	int3
 10247ed:	int3
 10247ee:	int3
 10247ef:	int3

00000000010247f0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EED0Ev>:
 10247f0:	push   %rbp
 10247f1:	mov    %rsp,%rbp
 10247f4:	pop    %rbp
 10247f5:	ret
 10247f6:	int3
 10247f7:	int3
 10247f8:	int3
 10247f9:	int3
 10247fa:	int3
 10247fb:	int3
 10247fc:	int3
 10247fd:	int3
 10247fe:	int3
 10247ff:	int3

0000000001024800 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE8validRegEi>:
 1024800:	push   %rbp
 1024801:	mov    %rsp,%rbp
 1024804:	add    $0x2,%esi
 1024807:	cmp    $0x13,%esi
 102480a:	setb   %al
 102480d:	pop    %rbp
 102480e:	ret
 102480f:	int3

0000000001024810 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getRegEi>:
 1024810:	add    $0x2,%esi
 1024813:	cmp    $0x12,%esi
 1024816:	ja     10248ba <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getRegEi+0xaa>
 102481c:	lea    -0x18c27(%rip),%rax        # 100bbfc <raw_shape+0xfc>
 1024823:	movslq (%rax,%rsi,4),%rcx
 1024827:	add    %rax,%rcx
 102482a:	jmp    *%rcx
 102482c:	add    $0x48,%rdi
 1024830:	mov    (%rdi),%rax
 1024833:	ret
 1024834:	add    $0x90,%rdi
 102483b:	mov    (%rdi),%rax
 102483e:	ret
 102483f:	add    $0x78,%rdi
 1024843:	mov    (%rdi),%rax
 1024846:	ret
 1024847:	add    $0x68,%rdi
 102484b:	mov    (%rdi),%rax
 102484e:	ret
 102484f:	add    $0x50,%rdi
 1024853:	mov    (%rdi),%rax
 1024856:	ret
 1024857:	add    $0x28,%rdi
 102485b:	mov    (%rdi),%rax
 102485e:	ret
 102485f:	add    $0x58,%rdi
 1024863:	mov    (%rdi),%rax
 1024866:	ret
 1024867:	add    $0x40,%rdi
 102486b:	mov    (%rdi),%rax
 102486e:	ret
 102486f:	add    $0x70,%rdi
 1024873:	mov    (%rdi),%rax
 1024876:	ret
 1024877:	add    $0x10,%rdi
 102487b:	mov    (%rdi),%rax
 102487e:	ret
 102487f:	add    $0x38,%rdi
 1024883:	mov    (%rdi),%rax
 1024886:	ret
 1024887:	sub    $0xffffffffffffff80,%rdi
 102488b:	mov    (%rdi),%rax
 102488e:	ret
 102488f:	add    $0x20,%rdi
 1024893:	mov    (%rdi),%rax
 1024896:	ret
 1024897:	add    $0x60,%rdi
 102489b:	mov    (%rdi),%rax
 102489e:	ret
 102489f:	add    $0x18,%rdi
 10248a3:	mov    (%rdi),%rax
 10248a6:	ret
 10248a7:	add    $0x88,%rdi
 10248ae:	mov    (%rdi),%rax
 10248b1:	ret
 10248b2:	add    $0x30,%rdi
 10248b6:	mov    (%rdi),%rax
 10248b9:	ret
 10248ba:	push   %rbp
 10248bb:	mov    %rsp,%rbp
 10248be:	push   %rbx
 10248bf:	push   %rax
 10248c0:	mov    0x4451(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 10248c7:	mov    (%rbx),%rdi
 10248ca:	lea    -0x20006(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10248d1:	lea    -0x20b0b(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 10248d8:	lea    -0x20b3a(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 10248df:	xor    %eax,%eax
 10248e1:	call   1027760 <fprintf@plt>
 10248e6:	mov    (%rbx),%rdi
 10248e9:	call   1027800 <fflush@plt>
 10248ee:	call   1027810 <abort@plt>
 10248f3:	int3
 10248f4:	int3
 10248f5:	int3
 10248f6:	int3
 10248f7:	int3
 10248f8:	int3
 10248f9:	int3
 10248fa:	int3
 10248fb:	int3
 10248fc:	int3
 10248fd:	int3
 10248fe:	int3
 10248ff:	int3

0000000001024900 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6setRegEim>:
 1024900:	add    $0x2,%esi
 1024903:	cmp    $0x13,%esi
 1024906:	jae    102491a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6setRegEim+0x1a>
 1024908:	mov    %esi,%eax
 102490a:	lea    -0x186c1(%rip),%rcx        # 100c250 <raw_shape+0x750>
 1024911:	mov    (%rcx,%rax,8),%rax
 1024915:	mov    %rdx,(%rdi,%rax,1)
 1024919:	ret
 102491a:	push   %rbp
 102491b:	mov    %rsp,%rbp
 102491e:	push   %rbx
 102491f:	push   %rax
 1024920:	mov    0x43f1(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1024927:	mov    (%rbx),%rdi
 102492a:	lea    -0x20066(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1024931:	lea    -0x20b77(%rip),%rdx        # 1003dc1 <qbe_empty_registry+0x269>
 1024938:	lea    -0x20b9a(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 102493f:	xor    %eax,%eax
 1024941:	call   1027760 <fprintf@plt>
 1024946:	mov    (%rbx),%rdi
 1024949:	call   1027800 <fflush@plt>
 102494e:	call   1027810 <abort@plt>
 1024953:	int3
 1024954:	int3
 1024955:	int3
 1024956:	int3
 1024957:	int3
 1024958:	int3
 1024959:	int3
 102495a:	int3
 102495b:	int3
 102495c:	int3
 102495d:	int3
 102495e:	int3
 102495f:	int3

0000000001024960 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE13validFloatRegEi>:
 1024960:	push   %rbp
 1024961:	mov    %rsp,%rbp
 1024964:	xor    %eax,%eax
 1024966:	pop    %rbp
 1024967:	ret
 1024968:	int3
 1024969:	int3
 102496a:	int3
 102496b:	int3
 102496c:	int3
 102496d:	int3
 102496e:	int3
 102496f:	int3

0000000001024970 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE11getFloatRegEi>:
 1024970:	push   %rbp
 1024971:	mov    %rsp,%rbp
 1024974:	push   %rbx
 1024975:	push   %rax
 1024976:	mov    0x439b(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 102497d:	mov    (%rbx),%rdi
 1024980:	lea    -0x200bc(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1024987:	lea    -0x20ba4(%rip),%rdx        # 1003dea <qbe_empty_registry+0x292>
 102498e:	lea    -0x20c58(%rip),%rcx        # 1003d3d <qbe_empty_registry+0x1e5>
 1024995:	xor    %eax,%eax
 1024997:	call   1027760 <fprintf@plt>
 102499c:	mov    (%rbx),%rdi
 102499f:	call   1027800 <fflush@plt>
 10249a4:	call   1027810 <abort@plt>
 10249a9:	int3
 10249aa:	int3
 10249ab:	int3
 10249ac:	int3
 10249ad:	int3
 10249ae:	int3
 10249af:	int3

00000000010249b0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE11setFloatRegEid>:
 10249b0:	push   %rbp
 10249b1:	mov    %rsp,%rbp
 10249b4:	push   %rbx
 10249b5:	push   %rax
 10249b6:	mov    0x435b(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 10249bd:	mov    (%rbx),%rdi
 10249c0:	lea    -0x200fc(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10249c7:	lea    -0x20bf5(%rip),%rdx        # 1003dd9 <qbe_empty_registry+0x281>
 10249ce:	lea    -0x20c98(%rip),%rcx        # 1003d3d <qbe_empty_registry+0x1e5>
 10249d5:	xor    %eax,%eax
 10249d7:	call   1027760 <fprintf@plt>
 10249dc:	mov    (%rbx),%rdi
 10249df:	call   1027800 <fflush@plt>
 10249e4:	call   1027810 <abort@plt>
 10249e9:	int3
 10249ea:	int3
 10249eb:	int3
 10249ec:	int3
 10249ed:	int3
 10249ee:	int3
 10249ef:	int3

00000000010249f0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE4stepEb>:
 10249f0:	push   %rbp
 10249f1:	mov    %rsp,%rbp
 10249f4:	push   %r15
 10249f6:	push   %r14
 10249f8:	push   %rbx
 10249f9:	push   %rax
 10249fa:	xor    %ebx,%ebx
 10249fc:	cmpb   $0x0,0x100(%rdi)
 1024a03:	jne    1024a60 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE4stepEb+0x70>
 1024a05:	mov    %esi,%r15d
 1024a08:	mov    %rdi,%r14
 1024a0b:	mov    (%rdi),%rax
 1024a0e:	mov    $0xffffffff,%esi
 1024a13:	call   *0x18(%rax)
 1024a16:	mov    %rax,-0x20(%rbp)
 1024a1a:	mov    0x8(%r14),%rdi
 1024a1e:	mov    0xf0(%r14),%rdx
 1024a25:	lea    0x10(%r14),%rcx
 1024a29:	lea    0x101(%r14),%r8
 1024a30:	movzbl %r15b,%r9d
 1024a34:	lea    -0x20(%rbp),%rsi
 1024a38:	call   1024e60 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb>
 1024a3d:	mov    %eax,%r15d
 1024a40:	cmp    $0x1,%eax
 1024a43:	jne    1024a5d <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE4stepEb+0x6d>
 1024a45:	mov    (%r14),%rax
 1024a48:	mov    %r14,%rdi
 1024a4b:	mov    $0x1,%esi
 1024a50:	call   *0x68(%rax)
 1024a53:	cmpb   $0x0,0x100(%r14)
 1024a5b:	jne    1024a60 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE4stepEb+0x70>
 1024a5d:	mov    %r15d,%ebx
 1024a60:	mov    %ebx,%eax
 1024a62:	add    $0x8,%rsp
 1024a66:	pop    %rbx
 1024a67:	pop    %r14
 1024a69:	pop    %r15
 1024a6b:	pop    %rbp
 1024a6c:	ret
 1024a6d:	int3
 1024a6e:	int3
 1024a6f:	int3

0000000001024a70 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE7getInfoEP15unw_proc_info_t>:
 1024a70:	push   %rbp
 1024a71:	mov    %rsp,%rbp
 1024a74:	cmpb   $0x1,0x100(%rdi)
 1024a7b:	jne    1024a97 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE7getInfoEP15unw_proc_info_t+0x27>
 1024a7d:	vxorps %xmm0,%xmm0,%xmm0
 1024a81:	vmovups %ymm0,0x20(%rsi)
 1024a86:	vmovups %ymm0,(%rsi)
 1024a8a:	movq   $0x0,0x40(%rsi)
 1024a92:	pop    %rbp
 1024a93:	vzeroupper
 1024a96:	ret
 1024a97:	mov    0xf8(%rdi),%rax
 1024a9e:	mov    %rax,0x40(%rsi)
 1024aa2:	vmovups 0xb8(%rdi),%ymm0
 1024aaa:	vmovups 0xd8(%rdi),%ymm1
 1024ab2:	vmovups %ymm1,0x20(%rsi)
 1024ab7:	vmovups %ymm0,(%rsi)
 1024abb:	pop    %rbp
 1024abc:	vzeroupper
 1024abf:	ret

0000000001024ac0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE6jumptoEv>:
 1024ac0:	push   %rbp
 1024ac1:	mov    %rsp,%rbp
 1024ac4:	add    $0x10,%rdi
 1024ac8:	pop    %rbp
 1024ac9:	jmp    1027560 <__libunwind_Registers_x86_64_jumpto>
 1024ace:	int3
 1024acf:	int3

0000000001024ad0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE13isSignalFrameEv>:
 1024ad0:	push   %rbp
 1024ad1:	mov    %rsp,%rbp
 1024ad4:	movzbl 0x101(%rdi),%eax
 1024adb:	pop    %rbp
 1024adc:	ret
 1024add:	int3
 1024ade:	int3
 1024adf:	int3

0000000001024ae0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE15getFunctionNameEPcmPm>:
 1024ae0:	push   %rbp
 1024ae1:	mov    %rsp,%rbp
 1024ae4:	push   %r15
 1024ae6:	push   %r14
 1024ae8:	push   %r13
 1024aea:	push   %r12
 1024aec:	push   %rbx
 1024aed:	sub    $0x28,%rsp
 1024af1:	mov    %rcx,%rbx
 1024af4:	mov    %rdx,%r14
 1024af7:	mov    %rsi,%r12
 1024afa:	mov    (%rdi),%rax
 1024afd:	mov    $0xffffffff,%esi
 1024b02:	call   *0x18(%rax)
 1024b05:	mov    %rax,%r15
 1024b08:	lea    -0x48(%rbp),%rsi
 1024b0c:	mov    %rax,%rdi
 1024b0f:	call   1027ab0 <dladdr@plt>
 1024b14:	test   %eax,%eax
 1024b16:	setne  %al
 1024b19:	mov    -0x38(%rbp),%rcx
 1024b1d:	test   %rcx,%rcx
 1024b20:	setne  %r13b
 1024b24:	and    %al,%r13b
 1024b27:	cmp    $0x1,%r13b
 1024b2b:	jne    1024b48 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE15getFunctionNameEPcmPm+0x68>
 1024b2d:	lea    -0x20ddb(%rip),%rdx        # 1003d59 <qbe_empty_registry+0x201>
 1024b34:	mov    %r12,%rdi
 1024b37:	mov    %r14,%rsi
 1024b3a:	xor    %eax,%eax
 1024b3c:	call   10277e0 <snprintf@plt>
 1024b41:	sub    -0x30(%rbp),%r15
 1024b45:	mov    %r15,(%rbx)
 1024b48:	mov    %r13d,%eax
 1024b4b:	add    $0x28,%rsp
 1024b4f:	pop    %rbx
 1024b50:	pop    %r12
 1024b52:	pop    %r13
 1024b54:	pop    %r14
 1024b56:	pop    %r15
 1024b58:	pop    %rbp
 1024b59:	ret
 1024b5a:	int3
 1024b5b:	int3
 1024b5c:	int3
 1024b5d:	int3
 1024b5e:	int3
 1024b5f:	int3

0000000001024b60 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb>:
 1024b60:	push   %rbp
 1024b61:	mov    %rsp,%rbp
 1024b64:	push   %r15
 1024b66:	push   %r14
 1024b68:	push   %rbx
 1024b69:	sub    $0x2c8,%rsp
 1024b70:	mov    %esi,%r14d
 1024b73:	mov    %rdi,%rbx
 1024b76:	mov    (%rdi),%rax
 1024b79:	mov    $0xffffffff,%esi
 1024b7e:	call   *0x18(%rax)
 1024b81:	mov    %rax,-0x20(%rbp)
 1024b85:	test   %rax,%rax
 1024b88:	je     1024e14 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2b4>
 1024b8e:	test   %r14b,%r14b
 1024b91:	je     1024b9a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x3a>
 1024b93:	dec    %rax
 1024b96:	mov    %rax,-0x20(%rbp)
 1024b9a:	cmpb   $0x1,0x101(%rbx)
 1024ba1:	jne    1024baa <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x4a>
 1024ba3:	inc    %rax
 1024ba6:	mov    %rax,-0x20(%rbp)
 1024baa:	movq   $0x0,-0x50(%rbp)
 1024bb2:	vxorps %xmm0,%xmm0,%xmm0
 1024bb6:	vmovups %xmm0,-0x40(%rbp)
 1024bbb:	mov    0x8(%rbx),%r14
 1024bbf:	cmpb   $0x0,0x6da2(%rip)        # 102b968 <_ZZN9libunwind17LocalAddressSpace18findUnwindSectionsINS_16Registers_x86_64EEEbNT_23link_hardened_reg_arg_tERNS_18UnwindInfoSectionsEE19dlFindObjectChecked>
 1024bc6:	je     1024bd6 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x76>
 1024bc8:	mov    0x6d91(%rip),%rcx        # 102b960 <_ZZN9libunwind17LocalAddressSpace18findUnwindSectionsINS_16Registers_x86_64EEEbNT_23link_hardened_reg_arg_tERNS_18UnwindInfoSectionsEE12dlFindObject>
 1024bcf:	test   %rcx,%rcx
 1024bd2:	jne    1024c00 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xa0>
 1024bd4:	jmp    1024c14 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xb4>
 1024bd6:	lea    -0x20ebc(%rip),%rsi        # 1003d21 <qbe_empty_registry+0x1c9>
 1024bdd:	xor    %edi,%edi
 1024bdf:	mov    %rax,%r15
 1024be2:	call   1027ac0 <dlsym@plt>
 1024be7:	mov    %rax,%rcx
 1024bea:	mov    %r15,%rax
 1024bed:	mov    %rcx,0x6d6c(%rip)        # 102b960 <_ZZN9libunwind17LocalAddressSpace18findUnwindSectionsINS_16Registers_x86_64EEEbNT_23link_hardened_reg_arg_tERNS_18UnwindInfoSectionsEE12dlFindObject>
 1024bf4:	movb   $0x1,0x6d6d(%rip)        # 102b968 <_ZZN9libunwind17LocalAddressSpace18findUnwindSectionsINS_16Registers_x86_64EEEbNT_23link_hardened_reg_arg_tERNS_18UnwindInfoSectionsEE19dlFindObjectChecked>
 1024bfb:	test   %rcx,%rcx
 1024bfe:	je     1024c14 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xb4>
 1024c00:	lea    -0x2e0(%rbp),%rsi
 1024c07:	mov    %rax,%rdi
 1024c0a:	call   *%rcx
 1024c0c:	test   %eax,%eax
 1024c0e:	je     1024c6a <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x10a>
 1024c10:	mov    -0x20(%rbp),%rax
 1024c14:	mov    %r14,-0x88(%rbp)
 1024c1b:	lea    -0x50(%rbp),%rcx
 1024c1f:	mov    %rcx,-0x80(%rbp)
 1024c23:	mov    %rax,-0x78(%rbp)
 1024c27:	lea    0x23c2(%rip),%rdi        # 1026ff0 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv>
 1024c2e:	lea    -0x88(%rbp),%rsi
 1024c35:	call   1027ad0 <dl_iterate_phdr@plt>
 1024c3a:	test   %eax,%eax
 1024c3c:	setne  %al
 1024c3f:	test   %al,%al
 1024c41:	je     1024cca <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x16a>
 1024c47:	cmpq   $0x0,-0x40(%rbp)
 1024c4c:	je     1024cca <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x16a>
 1024c4e:	lea    -0x20(%rbp),%rsi
 1024c52:	lea    -0x50(%rbp),%rdx
 1024c56:	mov    %rbx,%rdi
 1024c59:	xor    %ecx,%ecx
 1024c5b:	call   1026be0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj>
 1024c60:	test   %al,%al
 1024c62:	jne    1024e1b <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2bb>
 1024c68:	jmp    1024cca <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x16a>
 1024c6a:	mov    -0x2c0(%rbp),%rsi
 1024c71:	test   %rsi,%rsi
 1024c74:	je     1024cca <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x16a>
 1024c76:	mov    -0x2d8(%rbp),%rax
 1024c7d:	mov    -0x2d0(%rbp),%rcx
 1024c84:	mov    %rax,-0x50(%rbp)
 1024c88:	sub    %rax,%rcx
 1024c8b:	mov    %rcx,-0x48(%rbp)
 1024c8f:	mov    %rsi,-0x30(%rbp)
 1024c93:	movq   $0xffffffffffffffff,-0x28(%rbp)
 1024c9b:	lea    -0x1(%rsi),%rdx
 1024c9f:	lea    -0x88(%rbp),%rcx
 1024ca6:	mov    %r14,%rdi
 1024ca9:	call   1026ef0 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE>
 1024cae:	test   %al,%al
 1024cb0:	je     1024c3f <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xdf>
 1024cb2:	mov    -0x88(%rbp),%rcx
 1024cb9:	mov    %rcx,-0x40(%rbp)
 1024cbd:	movq   $0xffffffffffffffff,-0x38(%rbp)
 1024cc5:	jmp    1024c3f <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0xdf>
 1024cca:	lea    0x6c9f(%rip),%rdi        # 102b970 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1024cd1:	call   1027ae0 <pthread_rwlock_rdlock@plt>
 1024cd6:	mov    0x6c33(%rip),%rax        # 102b910 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE7_bufferE>
 1024cdd:	mov    0x6c34(%rip),%rcx        # 102b918 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE11_bufferUsedE>
 1024ce4:	cmp    %rcx,%rax
 1024ce7:	jae    1024e08 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2a8>
 1024ced:	mov    -0x20(%rbp),%rdx
 1024cf1:	jmp    1024d0d <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x1ad>
 1024cf3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1024d00:	add    $0x20,%rax
 1024d04:	cmp    %rcx,%rax
 1024d07:	jae    1024e08 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2a8>
 1024d0d:	cmp    %rdx,0x8(%rax)
 1024d11:	ja     1024d00 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x1a0>
 1024d13:	cmp    0x10(%rax),%rdx
 1024d17:	jae    1024d00 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x1a0>
 1024d19:	mov    0x18(%rax),%r14
 1024d1d:	lea    0x6c4c(%rip),%rdi        # 102b970 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1024d24:	call   1027aa0 <pthread_rwlock_unlock@plt>
 1024d29:	test   %r14,%r14
 1024d2c:	je     1024e14 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2b4>
 1024d32:	mov    0x8(%rbx),%rdi
 1024d36:	lea    -0xb8(%rbp),%rdx
 1024d3d:	lea    -0x88(%rbp),%rcx
 1024d44:	mov    %r14,%rsi
 1024d47:	xor    %r8d,%r8d
 1024d4a:	call   10243e0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb>
 1024d4f:	test   %rax,%rax
 1024d52:	jne    1024e14 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2b4>
 1024d58:	lea    -0x2e0(%rbp),%r14
 1024d5f:	mov    $0x228,%edx
 1024d64:	mov    %r14,%rdi
 1024d67:	xor    %esi,%esi
 1024d69:	call   1027650 <memset@plt>
 1024d6e:	mov    0x8(%rbx),%rdi
 1024d72:	lea    -0xb8(%rbp),%rsi
 1024d79:	lea    -0x88(%rbp),%rdx
 1024d80:	lea    -0x20(%rbp),%rcx
 1024d84:	mov    $0x1,%r8d
 1024d8a:	mov    %r14,%r9
 1024d8d:	call   1025290 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE>
 1024d92:	test   %al,%al
 1024d94:	je     1024e14 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2b4>
 1024d96:	vmovups -0xa0(%rbp),%xmm0
 1024d9e:	vmovups %xmm0,0xb8(%rbx)
 1024da6:	mov    -0x90(%rbp),%rax
 1024dad:	mov    %rax,0xc8(%rbx)
 1024db4:	mov    -0x68(%rbp),%rax
 1024db8:	mov    %rax,0xd0(%rbx)
 1024dbf:	mov    -0x2d0(%rbp),%eax
 1024dc5:	mov    %rax,0xd8(%rbx)
 1024dcc:	movq   $0x0,0xe0(%rbx)
 1024dd7:	movl   $0x4000000,0xe8(%rbx)
 1024de1:	mov    -0xb8(%rbp),%rax
 1024de8:	mov    %rax,0xf0(%rbx)
 1024def:	mov    -0xb0(%rbp),%eax
 1024df5:	mov    %eax,0xec(%rbx)
 1024dfb:	movq   $0x0,0xf8(%rbx)
 1024e06:	jmp    1024e1b <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE24setInfoBasedOnIPRegisterEb+0x2bb>
 1024e08:	lea    0x6b61(%rip),%rdi        # 102b970 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1024e0f:	call   1027aa0 <pthread_rwlock_unlock@plt>
 1024e14:	movb   $0x1,0x100(%rbx)
 1024e1b:	add    $0x2c8,%rsp
 1024e22:	pop    %rbx
 1024e23:	pop    %r14
 1024e25:	pop    %r15
 1024e27:	pop    %rbp
 1024e28:	ret
 1024e29:	int3
 1024e2a:	int3
 1024e2b:	int3
 1024e2c:	int3
 1024e2d:	int3
 1024e2e:	int3
 1024e2f:	int3

0000000001024e30 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE15getRegisterNameEi>:
 1024e30:	push   %rbp
 1024e31:	mov    %rsp,%rbp
 1024e34:	add    $0x2,%esi
 1024e37:	cmp    $0x22,%esi
 1024e3a:	ja     1024e4e <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE15getRegisterNameEi+0x1e>
 1024e3c:	mov    %esi,%eax
 1024e3e:	lea    -0x18b5d(%rip),%rcx        # 100c2e8 <raw_shape+0x7e8>
 1024e45:	movslq (%rcx,%rax,4),%rax
 1024e49:	add    %rcx,%rax
 1024e4c:	pop    %rbp
 1024e4d:	ret
 1024e4e:	lea    -0x210c1(%rip),%rax        # 1003d94 <qbe_empty_registry+0x23c>
 1024e55:	pop    %rbp
 1024e56:	ret
 1024e57:	int3
 1024e58:	int3
 1024e59:	int3
 1024e5a:	int3
 1024e5b:	int3
 1024e5c:	int3
 1024e5d:	int3
 1024e5e:	int3
 1024e5f:	int3

0000000001024e60 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb>:
 1024e60:	push   %rbp
 1024e61:	mov    %rsp,%rbp
 1024e64:	push   %r15
 1024e66:	push   %r14
 1024e68:	push   %r13
 1024e6a:	push   %r12
 1024e6c:	push   %rbx
 1024e6d:	sub    $0x358,%rsp
 1024e74:	mov    %r8,%r13
 1024e77:	mov    %rcx,%rbx
 1024e7a:	mov    %rsi,%r14
 1024e7d:	mov    %rdi,%r15
 1024e80:	lea    -0x150(%rbp),%rax
 1024e87:	lea    -0xf8(%rbp),%rcx
 1024e8e:	mov    %rdx,%rsi
 1024e91:	mov    %rax,%rdx
 1024e94:	xor    %r8d,%r8d
 1024e97:	call   10243e0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb>
 1024e9c:	mov    %rax,%rcx
 1024e9f:	mov    $0xffffe66e,%eax
 1024ea4:	test   %rcx,%rcx
 1024ea7:	jne    1025240 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3e0>
 1024ead:	lea    -0x378(%rbp),%r12
 1024eb4:	mov    $0x228,%edx
 1024eb9:	mov    %r12,%rdi
 1024ebc:	xor    %esi,%esi
 1024ebe:	call   1027650 <memset@plt>
 1024ec3:	lea    -0x150(%rbp),%rsi
 1024eca:	lea    -0xf8(%rbp),%rdx
 1024ed1:	mov    %r15,%rdi
 1024ed4:	mov    %r14,%rcx
 1024ed7:	mov    $0x1,%r8d
 1024edd:	mov    %r12,%r9
 1024ee0:	call   1025290 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE>
 1024ee5:	mov    %eax,%ecx
 1024ee7:	mov    $0xffffe66e,%eax
 1024eec:	test   %cl,%cl
 1024eee:	je     1025240 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3e0>
 1024ef4:	mov    %r13,-0xc0(%rbp)
 1024efb:	lea    -0x378(%rbp),%rsi
 1024f02:	mov    %r15,%rdi
 1024f05:	mov    %rbx,%rdx
 1024f08:	call   1025d50 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_>
 1024f0d:	mov    %rax,%r12
 1024f10:	mov    (%rbx),%rax
 1024f13:	mov    %rax,-0x58(%rbp)
 1024f17:	mov    0x8(%rbx),%rax
 1024f1b:	mov    %rax,-0x88(%rbp)
 1024f22:	mov    0x10(%rbx),%rax
 1024f26:	mov    %rax,-0x60(%rbp)
 1024f2a:	mov    0x18(%rbx),%rax
 1024f2e:	mov    %rax,-0x68(%rbp)
 1024f32:	mov    0x20(%rbx),%rax
 1024f36:	mov    %rax,-0x70(%rbp)
 1024f3a:	mov    0x28(%rbx),%rax
 1024f3e:	mov    %rax,-0x78(%rbp)
 1024f42:	mov    0x30(%rbx),%rax
 1024f46:	mov    %rax,-0x80(%rbp)
 1024f4a:	mov    0x40(%rbx),%rax
 1024f4e:	mov    %rax,-0x90(%rbp)
 1024f55:	mov    0x48(%rbx),%rax
 1024f59:	mov    %rax,-0x98(%rbp)
 1024f60:	mov    0x50(%rbx),%rax
 1024f64:	mov    %rax,-0xa0(%rbp)
 1024f6b:	mov    0x58(%rbx),%rax
 1024f6f:	mov    %rax,-0xa8(%rbp)
 1024f76:	mov    0x60(%rbx),%rax
 1024f7a:	mov    %rax,-0xb0(%rbp)
 1024f81:	vmovups 0x88(%rbx),%ymm0
 1024f89:	mov    0x68(%rbx),%rax
 1024f8d:	mov    %rax,-0x40(%rbp)
 1024f91:	mov    0x70(%rbx),%rax
 1024f95:	mov    %rax,-0x48(%rbp)
 1024f99:	mov    0x78(%rbx),%rax
 1024f9d:	mov    %rax,-0x50(%rbp)
 1024fa1:	vmovups %ymm0,-0x120(%rbp)
 1024fa9:	lea    0x88(%rbx),%rax
 1024fb0:	mov    %rax,-0xb8(%rbp)
 1024fb7:	lea    -0x360(%rbp),%r13
 1024fbe:	movq   $0x0,-0x30(%rbp)
 1024fc6:	xor    %r14d,%r14d
 1024fc9:	mov    %r12,-0x38(%rbp)
 1024fcd:	jmp    1024ff9 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x199>
 1024fcf:	nop
 1024fd0:	mov    %r15,%rdi
 1024fd3:	mov    %rbx,%rsi
 1024fd6:	mov    %r12,%rdx
 1024fd9:	mov    %r13,%rcx
 1024fdc:	vzeroupper
 1024fdf:	call   1025e30 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE>
 1024fe4:	mov    %rax,-0x30(%rbp)
 1024fe8:	inc    %r14
 1024feb:	add    $0x10,%r13
 1024fef:	cmp    $0x21,%r14
 1024ff3:	je     1025175 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x315>
 1024ff9:	cmpl   $0x0,0x0(%r13)
 1024ffe:	movzbl -0xc6(%rbp),%eax
 1025005:	je     1025050 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x1f0>
 1025007:	cmp    %rax,%r14
 102500a:	je     1024fd0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x170>
 102500c:	cmp    $0x10,%r14
 1025010:	ja     102523b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3db>
 1025016:	mov    %r15,%rdi
 1025019:	mov    %rbx,%rsi
 102501c:	mov    %r12,%rdx
 102501f:	mov    %r13,%rcx
 1025022:	vzeroupper
 1025025:	call   1025e30 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE>
 102502a:	mov    %r14d,%ecx
 102502d:	lea    -0x193ec(%rip),%rdx        # 100bc48 <raw_shape+0x148>
 1025034:	movslq (%rdx,%rcx,4),%rcx
 1025038:	add    %rdx,%rcx
 102503b:	jmp    *%rcx
 102503d:	mov    %rax,-0x58(%rbp)
 1025041:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1025043:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025050:	cmp    %rax,%r14
 1025053:	jne    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1025055:	cmp    $0x10,%al
 1025057:	ja     1025255 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3f5>
 102505d:	lea    -0x193d8(%rip),%rdx        # 100bc8c <raw_shape+0x18c>
 1025064:	movslq (%rdx,%rax,4),%rcx
 1025068:	add    %rdx,%rcx
 102506b:	mov    %rbx,%rax
 102506e:	jmp    *%rcx
 1025070:	lea    0x18(%rbx),%rax
 1025074:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025079:	mov    %rax,-0x50(%rbp)
 102507d:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1025082:	mov    %rax,-0x40(%rbp)
 1025086:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 102508b:	mov    %rax,-0xa0(%rbp)
 1025092:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1025097:	mov    %rax,-0x88(%rbp)
 102509e:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250a3:	mov    %rax,-0xa8(%rbp)
 10250aa:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250af:	mov    %rax,-0x90(%rbp)
 10250b6:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250bb:	mov    %rax,-0x68(%rbp)
 10250bf:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250c4:	mov    %rax,-0x48(%rbp)
 10250c8:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250cd:	mov    %rax,-0x60(%rbp)
 10250d1:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250d6:	mov    %rax,-0x80(%rbp)
 10250da:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250df:	mov    %rax,-0x78(%rbp)
 10250e3:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250e8:	mov    %rax,-0xb0(%rbp)
 10250ef:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250f4:	mov    %rax,-0x70(%rbp)
 10250f8:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 10250fd:	mov    %rax,-0x98(%rbp)
 1025104:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1025109:	mov    %rax,-0x38(%rbp)
 102510d:	jmp    1024fe8 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x188>
 1025112:	lea    0x80(%rbx),%rax
 1025119:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 102511b:	lea    0x70(%rbx),%rax
 102511f:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025121:	lea    0x58(%rbx),%rax
 1025125:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025127:	lea    0x28(%rbx),%rax
 102512b:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 102512d:	lea    0x60(%rbx),%rax
 1025131:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025133:	lea    0x48(%rbx),%rax
 1025137:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025139:	lea    0x10(%rbx),%rax
 102513d:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 102513f:	lea    0x78(%rbx),%rax
 1025143:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025145:	lea    0x8(%rbx),%rax
 1025149:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 102514b:	lea    0x38(%rbx),%rax
 102514f:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025151:	lea    0x20(%rbx),%rax
 1025155:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025157:	lea    0x68(%rbx),%rax
 102515b:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 102515d:	lea    0x30(%rbx),%rax
 1025161:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025163:	lea    0x50(%rbx),%rax
 1025167:	jmp    102516d <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x30d>
 1025169:	lea    0x40(%rbx),%rax
 102516d:	mov    (%rax),%rax
 1025170:	jmp    1024fe4 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x184>
 1025175:	movzbl -0xc8(%rbp),%eax
 102517c:	mov    -0xc0(%rbp),%rcx
 1025183:	mov    %al,(%rcx)
 1025185:	mov    -0x58(%rbp),%rax
 1025189:	mov    %rax,(%rbx)
 102518c:	mov    -0x88(%rbp),%rax
 1025193:	mov    %rax,0x8(%rbx)
 1025197:	mov    -0x60(%rbp),%rax
 102519b:	mov    %rax,0x10(%rbx)
 102519f:	mov    -0x68(%rbp),%rax
 10251a3:	mov    %rax,0x18(%rbx)
 10251a7:	mov    -0x70(%rbp),%rax
 10251ab:	mov    %rax,0x20(%rbx)
 10251af:	mov    -0x78(%rbp),%rax
 10251b3:	mov    %rax,0x28(%rbx)
 10251b7:	mov    -0x80(%rbp),%rax
 10251bb:	mov    %rax,0x30(%rbx)
 10251bf:	mov    -0x38(%rbp),%rax
 10251c3:	mov    %rax,0x38(%rbx)
 10251c7:	mov    -0x90(%rbp),%rax
 10251ce:	mov    %rax,0x40(%rbx)
 10251d2:	mov    -0x98(%rbp),%rax
 10251d9:	mov    %rax,0x48(%rbx)
 10251dd:	mov    -0xa0(%rbp),%rax
 10251e4:	mov    %rax,0x50(%rbx)
 10251e8:	mov    -0xa8(%rbp),%rax
 10251ef:	mov    %rax,0x58(%rbx)
 10251f3:	mov    -0xb0(%rbp),%rax
 10251fa:	mov    %rax,0x60(%rbx)
 10251fe:	mov    -0x40(%rbp),%rax
 1025202:	mov    %rax,0x68(%rbx)
 1025206:	mov    -0x48(%rbp),%rax
 102520a:	mov    %rax,0x70(%rbx)
 102520e:	mov    -0x50(%rbp),%rax
 1025212:	mov    %rax,0x78(%rbx)
 1025216:	mov    -0x30(%rbp),%rax
 102521a:	mov    %rax,0x80(%rbx)
 1025221:	vmovups -0x120(%rbp),%ymm0
 1025229:	mov    -0xb8(%rbp),%rax
 1025230:	vmovups %ymm0,(%rax)
 1025234:	mov    $0x1,%eax
 1025239:	jmp    1025240 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE13stepWithDwarfERS1_RKmmRS2_Rbb+0x3e0>
 102523b:	mov    $0xffffe672,%eax
 1025240:	add    $0x358,%rsp
 1025247:	pop    %rbx
 1025248:	pop    %r12
 102524a:	pop    %r13
 102524c:	pop    %r14
 102524e:	pop    %r15
 1025250:	pop    %rbp
 1025251:	vzeroupper
 1025254:	ret
 1025255:	mov    0x3abc(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 102525c:	mov    (%rbx),%rdi
 102525f:	lea    -0x2099b(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025266:	lea    -0x214a0(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 102526d:	lea    -0x214cf(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 1025274:	xor    %eax,%eax
 1025276:	vzeroupper
 1025279:	call   1027760 <fprintf@plt>
 102527e:	mov    (%rbx),%rdi
 1025281:	call   1027800 <fflush@plt>
 1025286:	call   1027810 <abort@plt>
 102528b:	int3
 102528c:	int3
 102528d:	int3
 102528e:	int3
 102528f:	int3

0000000001025290 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE>:
 1025290:	push   %rbp
 1025291:	mov    %rsp,%rbp
 1025294:	push   %r15
 1025296:	push   %r14
 1025298:	push   %r13
 102529a:	push   %r12
 102529c:	push   %rbx
 102529d:	sub    $0x298,%rsp
 10252a4:	mov    %rdx,%r14
 10252a7:	mov    0x10(%rdx),%rax
 10252ab:	mov    %rax,-0x90(%rbp)
 10252b2:	mov    0x8(%rdx),%rax
 10252b6:	add    (%rdx),%rax
 10252b9:	mov    %rdi,-0x58(%rbp)
 10252bd:	mov    %rax,-0x88(%rbp)
 10252c4:	movq   $0xffffffffffffffff,-0x80(%rbp)
 10252cc:	mov    0x10(%rsi),%rax
 10252d0:	mov    %rax,-0x78(%rbp)
 10252d4:	mov    0x8(%rsi),%rax
 10252d8:	add    (%rsi),%rax
 10252db:	mov    %rax,-0x70(%rbp)
 10252df:	mov    (%rcx),%rax
 10252e2:	sub    0x18(%rsi),%rax
 10252e6:	mov    %rax,-0x68(%rbp)
 10252ea:	mov    %r9,-0x40(%rbp)
 10252ee:	lea    0x18(%r9),%r15
 10252f2:	movq   $0x0,-0x48(%rbp)
 10252fa:	xor    %eax,%eax
 10252fc:	mov    %rdx,-0x50(%rbp)
 1025300:	mov    %r15,-0x38(%rbp)
 1025304:	jmp    1025322 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x92>
 1025306:	cs nopw 0x0(%rax,%rax,1)
 1025310:	mov    -0x60(%rbp),%rax
 1025314:	add    $0x18,%rax
 1025318:	cmp    $0x30,%rax
 102531c:	je     1025b41 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8b1>
 1025322:	mov    -0x90(%rbp,%rax,1),%rcx
 102532a:	mov    -0x88(%rbp,%rax,1),%r13
 1025332:	mov    %rcx,-0x30(%rbp)
 1025336:	mov    %rax,-0x60(%rbp)
 102533a:	mov    -0x80(%rbp,%rax,1),%rbx
 102533f:	cmp    %r13,%rcx
 1025342:	setae  %al
 1025345:	test   %rbx,%rbx
 1025348:	sete   %dl
 102534b:	or     %al,%dl
 102534d:	jne    1025310 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x80>
 102534f:	xor    %r12d,%r12d
 1025352:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025360:	movzbl (%rcx),%edx
 1025363:	lea    0x1(%rcx),%rax
 1025367:	mov    %rax,-0x30(%rbp)
 102536b:	cmp    $0x2f,%rdx
 102536f:	ja     1025a6b <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x7db>
 1025375:	lea    -0x196ac(%rip),%rdi        # 100bcd0 <raw_shape+0x1d0>
 102537c:	movslq (%rdi,%rdx,4),%rsi
 1025380:	add    %rdi,%rsi
 1025383:	jmp    *%rsi
 1025385:	movzbl 0x18(%r14),%ecx
 102538a:	lea    -0x30(%rbp),%rsi
 102538e:	mov    -0x58(%rbp),%rdi
 1025392:	mov    %r13,%rdx
 1025395:	xor    %r8d,%r8d
 1025398:	xor    %r9d,%r9d
 102539b:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 10253a0:	mov    %rax,%r12
 10253a3:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10253a8:	lea    -0x30(%rbp),%rdi
 10253ac:	mov    %r13,%rsi
 10253af:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10253b4:	mov    -0x30(%rbp),%rsi
 10253b8:	mov    $0xfffffffffffffff9,%rdx
 10253bf:	xor    %ecx,%ecx
 10253c1:	mov    %rsi,%rdi
 10253c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10253d0:	cmp    %r13,%rsi
 10253d3:	je     1025d11 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa81>
 10253d9:	add    $0x7,%rdx
 10253dd:	movzbl (%rsi),%r9d
 10253e1:	inc    %rsi
 10253e4:	mov    %r9d,%r8d
 10253e7:	and    $0x7f,%r9d
 10253eb:	shlx   %rdx,%r9,%r9
 10253f0:	or     %r9,%rcx
 10253f3:	inc    %rdi
 10253f6:	test   %r8b,%r8b
 10253f9:	js     10253d0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x140>
 10253fb:	mov    %rdi,-0x30(%rbp)
 10253ff:	cmp    $0x21,%rax
 1025403:	jae    1025c89 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x9f9>
 1025409:	lea    0x7(%rdx),%rsi
 102540d:	xor    %edi,%edi
 102540f:	cmp    $0x39,%rdx
 1025413:	mov    $0xffffffffffffffff,%rdx
 102541a:	shlx   %rsi,%rdx,%rdx
 102541f:	cmovae %edi,%edx
 1025422:	cmp    $0x40,%r8b
 1025426:	cmovb  %edi,%edx
 1025429:	or     %edx,%ecx
 102542b:	imul   0x2c(%r14),%ecx
 1025430:	mov    -0x40(%rbp),%rdx
 1025434:	mov    %eax,(%rdx)
 1025436:	mov    %ecx,0x4(%rdx)
 1025439:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 102543e:	lea    -0x30(%rbp),%rdi
 1025442:	mov    %r13,%rsi
 1025445:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102544a:	cmp    $0x21,%rax
 102544e:	jae    1025c71 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x9e1>
 1025454:	mov    -0x30(%rbp),%rdi
 1025458:	mov    $0xfffffffffffffff9,%rsi
 102545f:	xor    %ecx,%ecx
 1025461:	mov    %rdi,%rdx
 1025464:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025470:	cmp    %r13,%rdi
 1025473:	je     1025d11 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa81>
 1025479:	add    $0x7,%rsi
 102547d:	movzbl (%rdi),%r9d
 1025481:	inc    %rdi
 1025484:	mov    %r9d,%r8d
 1025487:	and    $0x7f,%r9d
 102548b:	shlx   %rsi,%r9,%r9
 1025490:	or     %r9,%rcx
 1025493:	inc    %rdx
 1025496:	test   %r8b,%r8b
 1025499:	js     1025470 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x1e0>
 102549b:	lea    0x7(%rsi),%edi
 102549e:	xor    %r9d,%r9d
 10254a1:	cmp    $0x39,%rsi
 10254a5:	mov    $0xffffffffffffffff,%rsi
 10254ac:	shlx   %rdi,%rsi,%rsi
 10254b1:	cmovae %r9,%rsi
 10254b5:	cmp    $0x40,%r8b
 10254b9:	cmovb  %r9,%rsi
 10254bd:	mov    %rdx,-0x30(%rbp)
 10254c1:	movslq 0x2c(%r14),%rdx
 10254c5:	shl    $0x4,%rax
 10254c9:	lea    (%r15,%rax,1),%rdi
 10254cd:	cmpb   $0x0,0x4(%r15,%rax,1)
 10254d3:	jne    10254ea <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x25a>
 10254d5:	vmovups (%rdi),%xmm0
 10254d9:	lea    -0x2a0(%rbp),%r8
 10254e0:	vmovups %xmm0,(%r8,%rax,1)
 10254e6:	movb   $0x1,0x4(%rdi)
 10254ea:	or     %rsi,%rcx
 10254ed:	imul   %rdx,%rcx
 10254f1:	movl   $0x4,(%rdi)
 10254f7:	mov    %rcx,0x8(%rdi)
 10254fb:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025500:	lea    -0x30(%rbp),%rdi
 1025504:	mov    %r13,%rsi
 1025507:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102550c:	cmp    $0x21,%rax
 1025510:	jae    1025b8c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8fc>
 1025516:	mov    -0x40(%rbp),%rcx
 102551a:	mov    %eax,(%rcx)
 102551c:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025521:	lea    -0x30(%rbp),%rdi
 1025525:	mov    %r13,%rsi
 1025528:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102552d:	mov    -0x40(%rbp),%rcx
 1025531:	mov    %eax,0x10(%rcx)
 1025534:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025539:	mov    %rsp,%rdi
 102553c:	lea    -0x230(%rdi),%r14
 1025543:	mov    %r14,%rsp
 1025546:	mov    -0x48(%rbp),%rax
 102554a:	mov    %rax,-0x230(%rdi)
 1025551:	add    $0xfffffffffffffdd8,%rdi
 1025558:	mov    $0x228,%edx
 102555d:	mov    -0x40(%rbp),%rsi
 1025561:	call   10276a0 <memcpy@plt>
 1025566:	mov    %r14,-0x48(%rbp)
 102556a:	mov    -0x50(%rbp),%r14
 102556e:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025573:	movzbl 0x1(%rcx),%eax
 1025577:	imul   0x28(%r14),%eax
 102557c:	add    %rax,%r12
 102557f:	add    $0x2,%rcx
 1025583:	mov    %rcx,-0x30(%rbp)
 1025587:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 102558c:	mov    0x28(%r14),%eax
 1025590:	imul   0x1(%rcx),%eax
 1025594:	add    %rax,%r12
 1025597:	add    $0x5,%rcx
 102559b:	mov    %rcx,-0x30(%rbp)
 102559f:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10255a4:	lea    -0x30(%rbp),%rdi
 10255a8:	mov    %r13,%rsi
 10255ab:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10255b0:	cmp    $0x21,%rax
 10255b4:	jae    1025bf3 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x963>
 10255ba:	shl    $0x4,%rax
 10255be:	lea    (%r15,%rax,1),%rcx
 10255c2:	cmpb   $0x0,0x4(%r15,%rax,1)
 10255c8:	jne    10255de <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x34e>
 10255ca:	vmovups (%rcx),%xmm0
 10255ce:	lea    -0x2a0(%rbp),%rdx
 10255d5:	vmovups %xmm0,(%rdx,%rax,1)
 10255da:	movb   $0x1,0x4(%rcx)
 10255de:	mov    -0x30(%rbp),%rax
 10255e2:	movl   $0x7,(%rcx)
 10255e8:	jmp    10259f4 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x764>
 10255ed:	lea    -0x30(%rbp),%r14
 10255f1:	mov    %r14,%rdi
 10255f4:	mov    %r13,%rsi
 10255f7:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10255fc:	mov    %rax,%r15
 10255ff:	mov    %r14,%rdi
 1025602:	mov    %r13,%rsi
 1025605:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102560a:	cmp    $0x21,%r15
 102560e:	jae    1025c41 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x9b1>
 1025614:	mov    -0x40(%rbp),%rcx
 1025618:	mov    %r15d,(%rcx)
 102561b:	mov    %eax,0x4(%rcx)
 102561e:	jmp    102589d <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x60d>
 1025623:	mov    $0xfffffffffffffff9,%rdx
 102562a:	xor    %ecx,%ecx
 102562c:	mov    %rax,%rsi
 102562f:	nop
 1025630:	cmp    %r13,%rsi
 1025633:	je     1025d11 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa81>
 1025639:	add    $0x7,%rdx
 102563d:	movzbl (%rsi),%r8d
 1025641:	inc    %rsi
 1025644:	mov    %r8d,%edi
 1025647:	and    $0x7f,%r8d
 102564b:	shlx   %rdx,%r8,%r8
 1025650:	or     %r8,%rcx
 1025653:	inc    %rax
 1025656:	test   %dil,%dil
 1025659:	js     1025630 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x3a0>
 102565b:	lea    0x7(%rdx),%esi
 102565e:	xor    %r8d,%r8d
 1025661:	cmp    $0x39,%rdx
 1025665:	mov    $0xffffffffffffffff,%rdx
 102566c:	shlx   %rsi,%rdx,%rdx
 1025671:	cmovae %r8d,%edx
 1025675:	cmp    $0x40,%dil
 1025679:	cmovb  %r8d,%edx
 102567d:	or     %edx,%ecx
 102567f:	mov    %rax,-0x30(%rbp)
 1025683:	imul   0x2c(%r14),%ecx
 1025688:	mov    -0x40(%rbp),%rax
 102568c:	mov    %ecx,0x4(%rax)
 102568f:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025694:	lea    -0x30(%rbp),%r14
 1025698:	mov    %r14,%rdi
 102569b:	mov    %r13,%rsi
 102569e:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10256a3:	mov    %rax,%r15
 10256a6:	mov    %r14,%rdi
 10256a9:	mov    %r13,%rsi
 10256ac:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10256b1:	cmp    $0x21,%r15
 10256b5:	jae    1025b5b <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8cb>
 10256bb:	mov    -0x50(%rbp),%r14
 10256bf:	movslq 0x2c(%r14),%rcx
 10256c3:	shl    $0x4,%r15
 10256c7:	mov    -0x38(%rbp),%rsi
 10256cb:	lea    (%rsi,%r15,1),%rdx
 10256cf:	cmpb   $0x0,0x4(%rsi,%r15,1)
 10256d5:	je     1025ac9 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x839>
 10256db:	jmp    1025ade <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x84e>
 10256e0:	cmpq   $0x0,-0x48(%rbp)
 10256e5:	je     1025cd0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa40>
 10256eb:	mov    -0x48(%rbp),%r15
 10256ef:	lea    0x8(%r15),%rsi
 10256f3:	mov    $0x228,%edx
 10256f8:	mov    -0x40(%rbp),%rdi
 10256fc:	call   10276a0 <memcpy@plt>
 1025701:	mov    (%r15),%r15
 1025704:	mov    %r15,-0x48(%rbp)
 1025708:	jmp    1025aec <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x85c>
 102570d:	movzwl 0x1(%rcx),%eax
 1025711:	imul   0x28(%r14),%eax
 1025716:	add    %rax,%r12
 1025719:	add    $0x3,%rcx
 102571d:	mov    %rcx,-0x30(%rbp)
 1025721:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025726:	lea    -0x30(%rbp),%rdi
 102572a:	mov    %r13,%rsi
 102572d:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025732:	cmp    $0x21,%rax
 1025736:	jae    1025bd8 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x948>
 102573c:	mov    %rax,%r15
 102573f:	lea    -0x30(%rbp),%rdi
 1025743:	mov    %r13,%rsi
 1025746:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102574b:	movslq 0x2c(%r14),%rdx
 102574f:	shl    $0x4,%r15
 1025753:	mov    -0x38(%rbp),%rsi
 1025757:	lea    (%rsi,%r15,1),%rcx
 102575b:	cmpb   $0x0,0x4(%rsi,%r15,1)
 1025761:	jne    1025778 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x4e8>
 1025763:	vmovups (%rcx),%xmm0
 1025767:	lea    -0x2a0(%rbp),%rsi
 102576e:	vmovups %xmm0,(%rsi,%r15,1)
 1025774:	movb   $0x1,0x4(%rcx)
 1025778:	imul   %rdx,%rax
 102577c:	neg    %rax
 102577f:	movl   $0x2,(%rcx)
 1025785:	mov    %rax,0x8(%rcx)
 1025789:	jmp    1025aec <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x85c>
 102578e:	lea    -0x30(%rbp),%rdi
 1025792:	mov    %r13,%rsi
 1025795:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102579a:	cmp    $0x21,%rax
 102579e:	jae    1025b48 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8b8>
 10257a4:	shl    $0x4,%rax
 10257a8:	cmpb   $0x1,0x4(%r15,%rax,1)
 10257ae:	jne    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10257b4:	lea    (%r15,%rax,1),%rcx
 10257b8:	lea    -0x2a0(%rbp),%rdx
 10257bf:	vmovups (%rdx,%rax,1),%xmm0
 10257c4:	vmovups %xmm0,(%rcx)
 10257c8:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10257cd:	lea    -0x30(%rbp),%rdi
 10257d1:	mov    %r13,%rsi
 10257d4:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10257d9:	cmp    $0x21,%rax
 10257dd:	jae    1025b76 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x8e6>
 10257e3:	shl    $0x4,%rax
 10257e7:	lea    (%r15,%rax,1),%rcx
 10257eb:	cmpb   $0x0,0x4(%r15,%rax,1)
 10257f1:	jne    1025807 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x577>
 10257f3:	vmovups (%rcx),%xmm0
 10257f7:	lea    -0x2a0(%rbp),%rdx
 10257fe:	vmovups %xmm0,(%rdx,%rax,1)
 1025803:	movb   $0x1,0x4(%rcx)
 1025807:	movl   $0x1,(%rcx)
 102580d:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025812:	lea    -0x30(%rbp),%rdi
 1025816:	mov    %r13,%rsi
 1025819:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102581e:	mov    -0x40(%rbp),%rcx
 1025822:	mov    %eax,0x4(%rcx)
 1025825:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 102582a:	mov    -0x40(%rbp),%rcx
 102582e:	movl   $0x0,(%rcx)
 1025834:	jmp    10259f4 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x764>
 1025839:	lea    -0x30(%rbp),%r14
 102583d:	mov    %r14,%rdi
 1025840:	mov    %r13,%rsi
 1025843:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025848:	mov    %rax,%r15
 102584b:	mov    %r14,%rdi
 102584e:	mov    %r13,%rsi
 1025851:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025856:	cmp    $0x21,%r15
 102585a:	jae    1025c29 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x999>
 1025860:	cmp    $0x21,%rax
 1025864:	jae    1025ca1 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa11>
 102586a:	shl    $0x4,%r15
 102586e:	mov    -0x38(%rbp),%rdx
 1025872:	lea    (%rdx,%r15,1),%rcx
 1025876:	cmpb   $0x0,0x4(%rdx,%r15,1)
 102587c:	jne    1025893 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x603>
 102587e:	vmovups (%rcx),%xmm0
 1025882:	lea    -0x2a0(%rbp),%rdx
 1025889:	vmovups %xmm0,(%rdx,%r15,1)
 102588f:	movb   $0x1,0x4(%rcx)
 1025893:	movl   $0x5,(%rcx)
 1025899:	mov    %rax,0x8(%rcx)
 102589d:	mov    -0x50(%rbp),%r14
 10258a1:	jmp    1025aec <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x85c>
 10258a6:	lea    -0x30(%rbp),%rdi
 10258aa:	mov    %r13,%rsi
 10258ad:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10258b2:	cmp    $0x21,%rax
 10258b6:	jae    1025c0e <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x97e>
 10258bc:	shl    $0x4,%rax
 10258c0:	lea    (%r15,%rax,1),%rcx
 10258c4:	cmpb   $0x0,0x4(%r15,%rax,1)
 10258ca:	jne    10258e0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x650>
 10258cc:	vmovups (%rcx),%xmm0
 10258d0:	lea    -0x2a0(%rbp),%rdx
 10258d7:	vmovups %xmm0,(%rdx,%rax,1)
 10258dc:	movb   $0x1,0x4(%rcx)
 10258e0:	movl   $0x0,(%rcx)
 10258e6:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10258eb:	lea    -0x30(%rbp),%rdi
 10258ef:	mov    %r13,%rsi
 10258f2:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10258f7:	cmp    $0x21,%rax
 10258fb:	jae    1025ba7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x917>
 1025901:	mov    -0x30(%rbp),%rdi
 1025905:	mov    $0xfffffffffffffff9,%rsi
 102590c:	xor    %ecx,%ecx
 102590e:	mov    %rdi,%rdx
 1025911:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1025920:	cmp    %r13,%rdi
 1025923:	je     1025d11 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa81>
 1025929:	add    $0x7,%rsi
 102592d:	movzbl (%rdi),%r9d
 1025931:	inc    %rdi
 1025934:	mov    %r9d,%r8d
 1025937:	and    $0x7f,%r9d
 102593b:	shlx   %rsi,%r9,%r9
 1025940:	or     %r9,%rcx
 1025943:	inc    %rdx
 1025946:	test   %r8b,%r8b
 1025949:	js     1025920 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x690>
 102594b:	lea    0x7(%rsi),%edi
 102594e:	xor    %r9d,%r9d
 1025951:	cmp    $0x39,%rsi
 1025955:	mov    $0xffffffffffffffff,%rsi
 102595c:	shlx   %rdi,%rsi,%rsi
 1025961:	cmovae %r9,%rsi
 1025965:	cmp    $0x40,%r8b
 1025969:	cmovb  %r9,%rsi
 102596d:	mov    %rdx,-0x30(%rbp)
 1025971:	movslq 0x2c(%r14),%rdx
 1025975:	shl    $0x4,%rax
 1025979:	lea    (%r15,%rax,1),%rdi
 102597d:	cmpb   $0x0,0x4(%r15,%rax,1)
 1025983:	jne    102599a <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x70a>
 1025985:	vmovups (%rdi),%xmm0
 1025989:	lea    -0x2a0(%rbp),%r8
 1025990:	vmovups %xmm0,(%r8,%rax,1)
 1025996:	movb   $0x1,0x4(%rdi)
 102599a:	or     %rsi,%rcx
 102599d:	imul   %rdx,%rcx
 10259a1:	movl   $0x2,(%rdi)
 10259a7:	mov    %rcx,0x8(%rdi)
 10259ab:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 10259b0:	lea    -0x30(%rbp),%rdi
 10259b4:	mov    %r13,%rsi
 10259b7:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10259bc:	cmp    $0x21,%rax
 10259c0:	jae    1025c59 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x9c9>
 10259c6:	shl    $0x4,%rax
 10259ca:	lea    (%r15,%rax,1),%rcx
 10259ce:	cmpb   $0x0,0x4(%r15,%rax,1)
 10259d4:	jne    10259ea <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x75a>
 10259d6:	vmovups (%rcx),%xmm0
 10259da:	lea    -0x2a0(%rbp),%rdx
 10259e1:	vmovups %xmm0,(%rdx,%rax,1)
 10259e6:	movb   $0x1,0x4(%rcx)
 10259ea:	mov    -0x30(%rbp),%rax
 10259ee:	movl   $0x6,(%rcx)
 10259f4:	mov    %rax,0x8(%rcx)
 10259f8:	lea    -0x30(%rbp),%rdi
 10259fc:	mov    %r13,%rsi
 10259ff:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025a04:	add    %rax,-0x30(%rbp)
 1025a08:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025a0d:	lea    -0x30(%rbp),%rdi
 1025a11:	mov    %r13,%rsi
 1025a14:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025a19:	mov    %rax,%r15
 1025a1c:	cmp    $0x21,%rax
 1025a20:	jae    1025bc2 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x932>
 1025a26:	lea    -0x30(%rbp),%rdi
 1025a2a:	mov    %r13,%rsi
 1025a2d:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025a32:	movslq 0x2c(%r14),%rcx
 1025a36:	shl    $0x4,%r15
 1025a3a:	mov    -0x38(%rbp),%rsi
 1025a3e:	lea    (%rsi,%r15,1),%rdx
 1025a42:	cmpb   $0x0,0x4(%rsi,%r15,1)
 1025a48:	jne    1025a5f <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x7cf>
 1025a4a:	vmovups (%rdx),%xmm0
 1025a4e:	lea    -0x2a0(%rbp),%rsi
 1025a55:	vmovups %xmm0,(%rsi,%r15,1)
 1025a5b:	movb   $0x1,0x4(%rdx)
 1025a5f:	imul   %rcx,%rax
 1025a63:	movl   $0x4,(%rdx)
 1025a69:	jmp    1025ae8 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x858>
 1025a6b:	mov    %edx,%r15d
 1025a6e:	and    $0x3f,%r15d
 1025a72:	shr    $0x6,%dl
 1025a75:	movzbl %dl,%eax
 1025a78:	lea    -0x19cef(%rip),%rcx        # 100bd90 <raw_shape+0x290>
 1025a7f:	movslq (%rcx,%rax,4),%rax
 1025a83:	add    %rcx,%rax
 1025a86:	jmp    *%rax
 1025a88:	movzbl %r15b,%eax
 1025a8c:	imul   0x28(%r14),%eax
 1025a91:	add    %rax,%r12
 1025a94:	jmp    1025aec <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x85c>
 1025a96:	cmp    $0x21,%r15b
 1025a9a:	jae    1025cf4 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa64>
 1025aa0:	lea    -0x30(%rbp),%rdi
 1025aa4:	mov    %r13,%rsi
 1025aa7:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1025aac:	movslq 0x2c(%r14),%rcx
 1025ab0:	mov    %r15d,%esi
 1025ab3:	shl    $0x4,%esi
 1025ab6:	mov    -0x38(%rbp),%rdi
 1025aba:	lea    (%rdi,%rsi,1),%rdx
 1025abe:	cmpb   $0x0,0x4(%rdi,%rsi,1)
 1025ac3:	jne    1025ade <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x84e>
 1025ac5:	shl    $0x4,%r15d
 1025ac9:	vmovups (%rdx),%xmm0
 1025acd:	lea    -0x2a0(%rbp),%rsi
 1025ad4:	vmovups %xmm0,(%rsi,%r15,1)
 1025ada:	movb   $0x1,0x4(%rdx)
 1025ade:	imul   %rcx,%rax
 1025ae2:	movl   $0x2,(%rdx)
 1025ae8:	mov    %rax,0x8(%rdx)
 1025aec:	mov    -0x38(%rbp),%r15
 1025af0:	mov    -0x30(%rbp),%rcx
 1025af4:	cmp    %r13,%rcx
 1025af7:	jae    1025310 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x80>
 1025afd:	cmp    %rbx,%r12
 1025b00:	jb     1025360 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xd0>
 1025b06:	jmp    1025310 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x80>
 1025b0b:	movzbl %r15b,%edx
 1025b0f:	cmp    $0x21,%dl
 1025b12:	jae    1025ce1 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa51>
 1025b18:	mov    %edx,%eax
 1025b1a:	shl    $0x4,%eax
 1025b1d:	mov    -0x38(%rbp),%r15
 1025b21:	cmpb   $0x1,0x4(%r15,%rax,1)
 1025b27:	jne    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025b29:	add    %r15,%rax
 1025b2c:	shl    $0x4,%edx
 1025b2f:	lea    -0x2a0(%rbp),%rcx
 1025b36:	vmovups (%rcx,%rdx,1),%xmm0
 1025b3b:	vmovups %xmm0,(%rax)
 1025b3f:	jmp    1025af0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x860>
 1025b41:	mov    $0x1,%al
 1025b43:	jmp    1025cd2 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa42>
 1025b48:	mov    0x31c9(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025b4f:	mov    (%rax),%rcx
 1025b52:	lea    -0x20edc(%rip),%rdi        # 1004c7d <qbe_empty_registry+0x1125>
 1025b59:	jmp    1025b9d <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0x90d>
 1025b5b:	mov    0x31b6(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025b62:	mov    (%rax),%rcx
 1025b65:	lea    -0x20f36(%rip),%rdi        # 1004c36 <qbe_empty_registry+0x10de>
 1025b6c:	mov    $0x46,%esi
 1025b71:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025b76:	mov    0x319b(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025b7d:	mov    (%rax),%rcx
 1025b80:	lea    -0x20fe6(%rip),%rdi        # 1004ba1 <qbe_empty_registry+0x1049>
 1025b87:	jmp    1025cb2 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa22>
 1025b8c:	mov    0x3185(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025b93:	mov    (%rax),%rcx
 1025b96:	lea    -0x2121f(%rip),%rdi        # 100497e <qbe_empty_registry+0xe26>
 1025b9d:	mov    $0x47,%esi
 1025ba2:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025ba7:	mov    0x316a(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025bae:	mov    (%rax),%rcx
 1025bb1:	lea    -0x210e5(%rip),%rdi        # 1004ad3 <qbe_empty_registry+0xf7b>
 1025bb8:	mov    $0x49,%esi
 1025bbd:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025bc2:	mov    0x314f(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025bc9:	mov    (%rax),%rdi
 1025bcc:	lea    -0x20c95(%rip),%rsi        # 1004f3e <qbe_empty_registry+0x13e6>
 1025bd3:	jmp    1025d05 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa75>
 1025bd8:	mov    0x3139(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025bdf:	mov    (%rax),%rcx
 1025be2:	lea    -0x21007(%rip),%rdi        # 1004be2 <qbe_empty_registry+0x108a>
 1025be9:	mov    $0x53,%esi
 1025bee:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025bf3:	mov    0x311e(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025bfa:	mov    (%rax),%rcx
 1025bfd:	lea    -0x211fe(%rip),%rdi        # 1004a06 <qbe_empty_registry+0xeae>
 1025c04:	mov    $0x45,%esi
 1025c09:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025c0e:	mov    0x3103(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025c15:	mov    (%rax),%rcx
 1025c18:	lea    -0x210c0(%rip),%rdi        # 1004b5f <qbe_empty_registry+0x1007>
 1025c1f:	mov    $0x41,%esi
 1025c24:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025c29:	mov    0x30e8(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025c30:	mov    (%rax),%rcx
 1025c33:	lea    -0x21274(%rip),%rdi        # 10049c6 <qbe_empty_registry+0xe6e>
 1025c3a:	mov    $0x3f,%esi
 1025c3f:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025c41:	mov    0x30d0(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025c48:	mov    (%rax),%rcx
 1025c4b:	lea    -0x20f8d(%rip),%rdi        # 1004cc5 <qbe_empty_registry+0x116d>
 1025c52:	mov    $0x3e,%esi
 1025c57:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025c59:	mov    0x30b8(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025c60:	mov    (%rax),%rcx
 1025c63:	lea    -0x2121e(%rip),%rdi        # 1004a4c <qbe_empty_registry+0xef4>
 1025c6a:	mov    $0x41,%esi
 1025c6f:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025c71:	mov    0x30a0(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025c78:	mov    (%rax),%rcx
 1025c7b:	lea    -0x211f4(%rip),%rdi        # 1004a8e <qbe_empty_registry+0xf36>
 1025c82:	mov    $0x44,%esi
 1025c87:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025c89:	mov    0x3088(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025c90:	mov    (%rax),%rcx
 1025c93:	lea    -0x2117d(%rip),%rdi        # 1004b1d <qbe_empty_registry+0xfc5>
 1025c9a:	mov    $0x41,%esi
 1025c9f:	jmp    1025cb7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa27>
 1025ca1:	mov    0x3070(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025ca8:	mov    (%rax),%rcx
 1025cab:	lea    -0x20fae(%rip),%rdi        # 1004d04 <qbe_empty_registry+0x11ac>
 1025cb2:	mov    $0x40,%esi
 1025cb7:	mov    $0x1,%edx
 1025cbc:	call   1027750 <fwrite@plt>
 1025cc1:	mov    0x3050(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025cc8:	mov    (%rax),%rdi
 1025ccb:	call   1027800 <fflush@plt>
 1025cd0:	xor    %eax,%eax
 1025cd2:	lea    -0x28(%rbp),%rsp
 1025cd6:	pop    %rbx
 1025cd7:	pop    %r12
 1025cd9:	pop    %r13
 1025cdb:	pop    %r14
 1025cdd:	pop    %r15
 1025cdf:	pop    %rbp
 1025ce0:	ret
 1025ce1:	mov    0x3030(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025ce8:	mov    (%rax),%rdi
 1025ceb:	lea    -0x20ef7(%rip),%rsi        # 1004dfb <qbe_empty_registry+0x12a3>
 1025cf2:	jmp    1025d08 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa78>
 1025cf4:	mov    0x301d(%rip),%rax        # 1028d18 <stderr@GLIBC_2.2.5>
 1025cfb:	mov    (%rax),%rdi
 1025cfe:	lea    -0x20f53(%rip),%rsi        # 1004db2 <qbe_empty_registry+0x125a>
 1025d05:	mov    %r15,%rdx
 1025d08:	xor    %eax,%eax
 1025d0a:	call   1027760 <fprintf@plt>
 1025d0f:	jmp    1025cc1 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE+0xa31>
 1025d11:	mov    0x3000(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1025d18:	mov    (%rbx),%rdi
 1025d1b:	lea    -0x21457(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025d22:	lea    -0x217e0(%rip),%rdx        # 1004549 <qbe_empty_registry+0x9f1>
 1025d29:	lea    -0x21e7f(%rip),%rcx        # 1003eb1 <qbe_empty_registry+0x359>
 1025d30:	xor    %eax,%eax
 1025d32:	call   1027760 <fprintf@plt>
 1025d37:	mov    (%rbx),%rdi
 1025d3a:	call   1027800 <fflush@plt>
 1025d3f:	call   1027810 <abort@plt>
 1025d44:	int3
 1025d45:	int3
 1025d46:	int3
 1025d47:	int3
 1025d48:	int3
 1025d49:	int3
 1025d4a:	int3
 1025d4b:	int3
 1025d4c:	int3
 1025d4d:	int3
 1025d4e:	int3
 1025d4f:	int3

0000000001025d50 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_>:
 1025d50:	mov    (%rsi),%eax
 1025d52:	add    $0x2,%eax
 1025d55:	cmp    $0x12,%eax
 1025d58:	ja     1025df6 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0xa6>
 1025d5e:	lea    -0x19fc5(%rip),%rcx        # 100bda0 <raw_shape+0x2a0>
 1025d65:	movslq (%rcx,%rax,4),%rax
 1025d69:	add    %rcx,%rax
 1025d6c:	jmp    *%rax
 1025d6e:	mov    $0x38,%ecx
 1025d73:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025d75:	mov    $0x80,%ecx
 1025d7a:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025d7c:	mov    $0x68,%ecx
 1025d81:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025d83:	mov    $0x58,%ecx
 1025d88:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025d8a:	mov    $0x40,%ecx
 1025d8f:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025d91:	mov    0x8(%rsi),%rax
 1025d95:	mov    %rdi,%rsi
 1025d98:	mov    %rax,%rdi
 1025d9b:	xor    %ecx,%ecx
 1025d9d:	jmp    10263b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m>
 1025da2:	mov    $0x48,%ecx
 1025da7:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025da9:	mov    $0x20,%ecx
 1025dae:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025db0:	mov    $0x60,%ecx
 1025db5:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025db7:	mov    $0x8,%ecx
 1025dbc:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025dbe:	mov    $0x70,%ecx
 1025dc3:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025dc5:	mov    $0x18,%ecx
 1025dca:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025dcc:	mov    $0x50,%ecx
 1025dd1:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025dd3:	mov    $0x10,%ecx
 1025dd8:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025dda:	mov    $0x78,%ecx
 1025ddf:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025de1:	mov    $0x30,%ecx
 1025de6:	jmp    1025ded <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE6getCFAERS1_RKNS_10CFI_ParserIS1_E10PrologInfoERKS2_+0x9d>
 1025de8:	mov    $0x28,%ecx
 1025ded:	movslq 0x4(%rsi),%rax
 1025df1:	add    (%rdx,%rcx,1),%rax
 1025df5:	ret
 1025df6:	push   %rbp
 1025df7:	mov    %rsp,%rbp
 1025dfa:	push   %rbx
 1025dfb:	push   %rax
 1025dfc:	mov    0x2f15(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1025e03:	mov    (%rbx),%rdi
 1025e06:	lea    -0x21542(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025e0d:	lea    -0x22047(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 1025e14:	lea    -0x22076(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 1025e1b:	xor    %eax,%eax
 1025e1d:	call   1027760 <fprintf@plt>
 1025e22:	mov    (%rbx),%rdi
 1025e25:	call   1027800 <fflush@plt>
 1025e2a:	call   1027810 <abort@plt>
 1025e2f:	int3

0000000001025e30 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE>:
 1025e30:	push   %rbp
 1025e31:	mov    %rsp,%rbp
 1025e34:	push   %rbx
 1025e35:	push   %rax
 1025e36:	mov    %rdx,%rax
 1025e39:	mov    %rsi,%rdx
 1025e3c:	mov    %rdi,%rsi
 1025e3f:	mov    (%rcx),%edi
 1025e41:	dec    %edi
 1025e43:	cmp    $0x6,%edi
 1025e46:	ja     1025f53 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x123>
 1025e4c:	lea    -0x1a067(%rip),%r8        # 100bdec <raw_shape+0x2ec>
 1025e53:	movslq (%r8,%rdi,4),%rdi
 1025e57:	add    %r8,%rdi
 1025e5a:	jmp    *%rdi
 1025e5c:	mov    0x8(%rcx),%rcx
 1025e60:	mov    (%rcx,%rax,1),%rax
 1025e64:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025e66:	mov    0x8(%rcx),%rdi
 1025e6a:	mov    %rax,%rcx
 1025e6d:	call   10263b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m>
 1025e72:	mov    (%rax),%rax
 1025e75:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025e77:	mov    0x8(%rcx),%rdi
 1025e7b:	mov    %rax,%rcx
 1025e7e:	add    $0x8,%rsp
 1025e82:	pop    %rbx
 1025e83:	pop    %rbp
 1025e84:	jmp    10263b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m>
 1025e89:	xor    %eax,%eax
 1025e8b:	add    $0x8,%rsp
 1025e8f:	pop    %rbx
 1025e90:	pop    %rbp
 1025e91:	ret
 1025e92:	mov    0x8(%rcx),%eax
 1025e95:	add    $0x2,%eax
 1025e98:	cmp    $0x12,%eax
 1025e9b:	ja     1025f86 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x156>
 1025ea1:	lea    -0x1a0a0(%rip),%rcx        # 100be08 <raw_shape+0x308>
 1025ea8:	movslq (%rcx,%rax,4),%rax
 1025eac:	add    %rcx,%rax
 1025eaf:	jmp    *%rax
 1025eb1:	add    $0x38,%rdx
 1025eb5:	mov    (%rdx),%rax
 1025eb8:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025eba:	sub    $0xffffffffffffff80,%rdx
 1025ebe:	mov    (%rdx),%rax
 1025ec1:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025ec3:	add    $0x68,%rdx
 1025ec7:	mov    (%rdx),%rax
 1025eca:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025ecc:	add    $0x58,%rdx
 1025ed0:	mov    (%rdx),%rax
 1025ed3:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025ed5:	add    $0x40,%rdx
 1025ed9:	mov    (%rdx),%rax
 1025edc:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025ede:	add    $0x18,%rdx
 1025ee2:	mov    (%rdx),%rax
 1025ee5:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025ee7:	add    $0x48,%rdx
 1025eeb:	mov    (%rdx),%rax
 1025eee:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025ef0:	add    $0x30,%rdx
 1025ef4:	mov    (%rdx),%rax
 1025ef7:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025ef9:	add    $0x60,%rdx
 1025efd:	mov    (%rdx),%rax
 1025f00:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025f02:	add    $0x28,%rdx
 1025f06:	mov    (%rdx),%rax
 1025f09:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025f0b:	add    $0x70,%rdx
 1025f0f:	mov    (%rdx),%rax
 1025f12:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025f17:	add    $0x10,%rdx
 1025f1b:	mov    (%rdx),%rax
 1025f1e:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025f23:	add    $0x50,%rdx
 1025f27:	mov    (%rdx),%rax
 1025f2a:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025f2f:	add    $0x8,%rdx
 1025f33:	mov    (%rdx),%rax
 1025f36:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025f3b:	add    $0x78,%rdx
 1025f3f:	mov    (%rdx),%rax
 1025f42:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025f47:	add    $0x20,%rdx
 1025f4b:	mov    (%rdx),%rax
 1025f4e:	jmp    1025e8b <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x5b>
 1025f53:	mov    0x2dbe(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1025f5a:	mov    (%rbx),%rdi
 1025f5d:	lea    -0x21699(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025f64:	lea    -0x22170(%rip),%rdx        # 1003dfb <qbe_empty_registry+0x2a3>
 1025f6b:	lea    -0x22208(%rip),%rcx        # 1003d6a <qbe_empty_registry+0x212>
 1025f72:	xor    %eax,%eax
 1025f74:	call   1027760 <fprintf@plt>
 1025f79:	mov    (%rbx),%rdi
 1025f7c:	call   1027800 <fflush@plt>
 1025f81:	call   1027810 <abort@plt>
 1025f86:	mov    0x2d8b(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1025f8d:	mov    (%rbx),%rdi
 1025f90:	lea    -0x216cc(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1025f97:	lea    -0x221d1(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 1025f9e:	lea    -0x22200(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 1025fa5:	jmp    1025f72 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE16getSavedRegisterERS1_RKS2_mRKNS_10CFI_ParserIS1_E16RegisterLocationE+0x142>
 1025fa7:	int3
 1025fa8:	int3
 1025fa9:	int3
 1025faa:	int3
 1025fab:	int3
 1025fac:	int3
 1025fad:	int3
 1025fae:	int3
 1025faf:	int3

0000000001025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>:
 1025fb0:	push   %rbp
 1025fb1:	mov    %rsp,%rbp
 1025fb4:	push   %r15
 1025fb6:	push   %r14
 1025fb8:	push   %r12
 1025fba:	push   %rbx
 1025fbb:	mov    %ecx,%eax
 1025fbd:	and    $0xf,%eax
 1025fc0:	cmp    $0xc,%eax
 1025fc3:	ja     1026129 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x179>
 1025fc9:	mov    (%rsi),%rbx
 1025fcc:	lea    -0x1a17f(%rip),%rdi        # 100be54 <raw_shape+0x354>
 1025fd3:	movslq (%rdi,%rax,4),%rax
 1025fd7:	add    %rdi,%rax
 1025fda:	jmp    *%rax
 1025fdc:	mov    (%rbx),%rax
 1025fdf:	lea    0x8(%rbx),%rdx
 1025fe3:	mov    %rdx,(%rsi)
 1025fe6:	jmp    10260a4 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xf4>
 1025feb:	movslq (%rbx),%rax
 1025fee:	jmp    1025ff7 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x47>
 1025ff0:	movzwl (%rbx),%eax
 1025ff3:	jmp    1026007 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x57>
 1025ff5:	mov    (%rbx),%eax
 1025ff7:	lea    0x4(%rbx),%rdx
 1025ffb:	mov    %rdx,(%rsi)
 1025ffe:	jmp    10260a4 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xf4>
 1026003:	movswq (%rbx),%rax
 1026007:	lea    0x2(%rbx),%rdx
 102600b:	mov    %rdx,(%rsi)
 102600e:	jmp    10260a4 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xf4>
 1026013:	mov    %rsi,%rdi
 1026016:	mov    %rdx,%rsi
 1026019:	mov    %r9,%r14
 102601c:	mov    %ecx,%r12d
 102601f:	mov    %r8,%r15
 1026022:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1026027:	mov    %r15,%r8
 102602a:	mov    %r12d,%ecx
 102602d:	mov    %r14,%r9
 1026030:	jmp    10260a4 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xf4>
 1026032:	mov    $0xfffffffffffffff9,%r10
 1026039:	xor    %eax,%eax
 102603b:	mov    %rbx,%rdi
 102603e:	mov    %rbx,%r11
 1026041:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1026050:	cmp    %rdx,%r11
 1026053:	je     10260f6 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x146>
 1026059:	add    $0x7,%r10
 102605d:	movzbl (%r11),%r15d
 1026061:	inc    %r11
 1026064:	mov    %r15d,%r14d
 1026067:	and    $0x7f,%r15d
 102606b:	shlx   %r10,%r15,%r15
 1026070:	or     %r15,%rax
 1026073:	inc    %rdi
 1026076:	test   %r14b,%r14b
 1026079:	js     1026050 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0xa0>
 102607b:	lea    0x7(%r10),%edx
 102607f:	xor    %r11d,%r11d
 1026082:	cmp    $0x39,%r10
 1026086:	mov    $0xffffffffffffffff,%r10
 102608d:	shlx   %rdx,%r10,%rdx
 1026092:	cmovae %r11,%rdx
 1026096:	cmp    $0x40,%r14b
 102609a:	cmovb  %r11,%rdx
 102609e:	or     %rdx,%rax
 10260a1:	mov    %rdi,(%rsi)
 10260a4:	mov    %ecx,%edx
 10260a6:	shr    $0x4,%edx
 10260a9:	and    $0x7,%edx
 10260ac:	cmp    $0x5,%edx
 10260af:	ja     1026129 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x179>
 10260b1:	lea    -0x1a230(%rip),%rsi        # 100be88 <raw_shape+0x388>
 10260b8:	movslq (%rsi,%rdx,4),%rdx
 10260bc:	add    %rsi,%rdx
 10260bf:	jmp    *%rdx
 10260c1:	add    %rbx,%rax
 10260c4:	test   %cl,%cl
 10260c6:	js     10260e2 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x132>
 10260c8:	test   %r9,%r9
 10260cb:	je     10260ed <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x13d>
 10260cd:	mov    %rbx,(%r9)
 10260d0:	jmp    10260ed <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x13d>
 10260d2:	test   %r8,%r8
 10260d5:	je     10261b0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x200>
 10260db:	add    %r8,%rax
 10260de:	test   %cl,%cl
 10260e0:	jns    10260c8 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x118>
 10260e2:	test   %r9,%r9
 10260e5:	je     10260ea <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x13a>
 10260e7:	mov    %rax,(%r9)
 10260ea:	mov    (%rax),%rax
 10260ed:	pop    %rbx
 10260ee:	pop    %r12
 10260f0:	pop    %r14
 10260f2:	pop    %r15
 10260f4:	pop    %rbp
 10260f5:	ret
 10260f6:	mov    0x2c1b(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 10260fd:	mov    (%rbx),%rdi
 1026100:	lea    -0x2183c(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026107:	lea    -0x21bc5(%rip),%rdx        # 1004549 <qbe_empty_registry+0x9f1>
 102610e:	lea    -0x22264(%rip),%rcx        # 1003eb1 <qbe_empty_registry+0x359>
 1026115:	xor    %eax,%eax
 1026117:	call   1027760 <fprintf@plt>
 102611c:	mov    (%rbx),%rdi
 102611f:	call   1027800 <fflush@plt>
 1026124:	call   1027810 <abort@plt>
 1026129:	mov    0x2be8(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026130:	mov    (%rbx),%rdi
 1026133:	lea    -0x2186f(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 102613a:	lea    -0x21d9e(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 1026141:	lea    -0x220df(%rip),%rcx        # 1004069 <qbe_empty_registry+0x511>
 1026148:	jmp    1026115 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 102614a:	mov    0x2bc7(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026151:	mov    (%rbx),%rdi
 1026154:	lea    -0x21890(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 102615b:	lea    -0x21dbf(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 1026162:	lea    -0x2201c(%rip),%rcx        # 100414d <qbe_empty_registry+0x5f5>
 1026169:	jmp    1026115 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 102616b:	mov    0x2ba6(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026172:	mov    (%rbx),%rdi
 1026175:	lea    -0x218b1(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 102617c:	lea    -0x21de0(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 1026183:	lea    -0x21fdd(%rip),%rcx        # 10041ad <qbe_empty_registry+0x655>
 102618a:	jmp    1026115 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 102618c:	mov    0x2b85(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026193:	mov    (%rbx),%rdi
 1026196:	lea    -0x218d2(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 102619d:	lea    -0x21e01(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 10261a4:	lea    -0x2202e(%rip),%rcx        # 100417d <qbe_empty_registry+0x625>
 10261ab:	jmp    1026115 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 10261b0:	mov    0x2b61(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 10261b7:	mov    (%rbx),%rdi
 10261ba:	lea    -0x218f6(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10261c1:	lea    -0x21e25(%rip),%rdx        # 10043a3 <qbe_empty_registry+0x84b>
 10261c8:	lea    -0x21bfd(%rip),%rcx        # 10045d2 <qbe_empty_registry+0xa7a>
 10261cf:	jmp    1026115 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm+0x165>
 10261d4:	int3
 10261d5:	int3
 10261d6:	int3
 10261d7:	int3
 10261d8:	int3
 10261d9:	int3
 10261da:	int3
 10261db:	int3
 10261dc:	int3
 10261dd:	int3
 10261de:	int3
 10261df:	int3

00000000010261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>:
 10261e0:	push   %rbp
 10261e1:	mov    %rsp,%rbp
 10261e4:	push   %rbx
 10261e5:	push   %rax
 10261e6:	mov    (%rdi),%rcx
 10261e9:	cmp    %rsi,%rcx
 10261ec:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 10261f2:	movzbl (%rcx),%eax
 10261f5:	mov    %eax,%r8d
 10261f8:	and    $0x7f,%eax
 10261fb:	lea    0x1(%rcx),%rdx
 10261ff:	test   %r8b,%r8b
 1026202:	jns    1026325 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 1026208:	cmp    %rsi,%rdx
 102620b:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 1026211:	movzbl 0x1(%rcx),%edx
 1026215:	mov    %edx,%r8d
 1026218:	and    $0x7f,%edx
 102621b:	shl    $0x7,%edx
 102621e:	or     %rdx,%rax
 1026221:	lea    0x2(%rcx),%rdx
 1026225:	test   %r8b,%r8b
 1026228:	jns    1026325 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 102622e:	cmp    %rsi,%rdx
 1026231:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 1026237:	movzbl 0x2(%rcx),%edx
 102623b:	mov    %edx,%r8d
 102623e:	and    $0x7f,%edx
 1026241:	shl    $0xe,%edx
 1026244:	or     %rdx,%rax
 1026247:	lea    0x3(%rcx),%rdx
 102624b:	test   %r8b,%r8b
 102624e:	jns    1026325 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 1026254:	cmp    %rsi,%rdx
 1026257:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 102625d:	movzbl 0x3(%rcx),%edx
 1026261:	mov    %edx,%r8d
 1026264:	and    $0x7f,%edx
 1026267:	shl    $0x15,%edx
 102626a:	or     %rdx,%rax
 102626d:	lea    0x4(%rcx),%rdx
 1026271:	test   %r8b,%r8b
 1026274:	jns    1026325 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 102627a:	cmp    %rsi,%rdx
 102627d:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 1026283:	movzbl 0x4(%rcx),%edx
 1026287:	mov    %edx,%r8d
 102628a:	and    $0x7f,%edx
 102628d:	shl    $0x1c,%rdx
 1026291:	or     %rdx,%rax
 1026294:	lea    0x5(%rcx),%rdx
 1026298:	test   %r8b,%r8b
 102629b:	jns    1026325 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 10262a1:	cmp    %rsi,%rdx
 10262a4:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 10262aa:	movzbl 0x5(%rcx),%edx
 10262ae:	mov    %edx,%r8d
 10262b1:	and    $0x7f,%edx
 10262b4:	shl    $0x23,%rdx
 10262b8:	or     %rdx,%rax
 10262bb:	lea    0x6(%rcx),%rdx
 10262bf:	test   %r8b,%r8b
 10262c2:	jns    1026325 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 10262c4:	cmp    %rsi,%rdx
 10262c7:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 10262cd:	movzbl 0x6(%rcx),%edx
 10262d1:	mov    %edx,%r8d
 10262d4:	and    $0x7f,%edx
 10262d7:	shl    $0x2a,%rdx
 10262db:	or     %rdx,%rax
 10262de:	lea    0x7(%rcx),%rdx
 10262e2:	test   %r8b,%r8b
 10262e5:	jns    1026325 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 10262e7:	cmp    %rsi,%rdx
 10262ea:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 10262ec:	movzbl 0x7(%rcx),%edx
 10262f0:	mov    %edx,%r8d
 10262f3:	and    $0x7f,%edx
 10262f6:	shl    $0x31,%rdx
 10262fa:	or     %rdx,%rax
 10262fd:	lea    0x8(%rcx),%rdx
 1026301:	test   %r8b,%r8b
 1026304:	jns    1026325 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x145>
 1026306:	cmp    %rsi,%rdx
 1026309:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 102630b:	movzbl 0x8(%rcx),%edx
 102630f:	mov    %edx,%r8d
 1026312:	and    $0x7f,%edx
 1026315:	shl    $0x38,%rdx
 1026319:	or     %rdx,%rax
 102631c:	lea    0x9(%rcx),%rdx
 1026320:	test   %r8b,%r8b
 1026323:	js     1026332 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x152>
 1026325:	mov    %rdx,%rcx
 1026328:	mov    %rcx,(%rdi)
 102632b:	add    $0x8,%rsp
 102632f:	pop    %rbx
 1026330:	pop    %rbp
 1026331:	ret
 1026332:	cmp    %rsi,%rdx
 1026335:	je     1026355 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x175>
 1026337:	movzbl (%rdx),%edx
 102633a:	test   $0x7e,%dl
 102633d:	jne    1026388 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x1a8>
 102633f:	add    $0xa,%rcx
 1026343:	test   %dl,%dl
 1026345:	js     1026350 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x170>
 1026347:	shl    $0x3f,%rdx
 102634b:	or     %rdx,%rax
 102634e:	jmp    1026328 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x148>
 1026350:	cmp    %rsi,%rcx
 1026353:	jne    1026388 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x1a8>
 1026355:	mov    0x29bc(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 102635c:	mov    (%rbx),%rdi
 102635f:	lea    -0x21a9b(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026366:	lea    -0x21e2f(%rip),%rdx        # 100453e <qbe_empty_registry+0x9e6>
 102636d:	lea    -0x224fd(%rip),%rcx        # 1003e77 <qbe_empty_registry+0x31f>
 1026374:	xor    %eax,%eax
 1026376:	call   1027760 <fprintf@plt>
 102637b:	mov    (%rbx),%rdi
 102637e:	call   1027800 <fflush@plt>
 1026383:	call   1027810 <abort@plt>
 1026388:	mov    0x2989(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 102638f:	mov    (%rbx),%rdi
 1026392:	lea    -0x21ace(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026399:	lea    -0x21e62(%rip),%rdx        # 100453e <qbe_empty_registry+0x9e6>
 10263a0:	lea    -0x22513(%rip),%rcx        # 1003e94 <qbe_empty_registry+0x33c>
 10263a7:	jmp    1026374 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm+0x194>
 10263a9:	int3
 10263aa:	int3
 10263ab:	int3
 10263ac:	int3
 10263ad:	int3
 10263ae:	int3
 10263af:	int3

00000000010263b0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m>:
 10263b0:	push   %rbp
 10263b1:	mov    %rsp,%rbp
 10263b4:	push   %r15
 10263b6:	push   %r14
 10263b8:	push   %r13
 10263ba:	push   %r12
 10263bc:	push   %rbx
 10263bd:	sub    $0x328,%rsp
 10263c4:	mov    %rcx,%r15
 10263c7:	mov    %rdx,%rbx
 10263ca:	mov    %rdi,-0x30(%rbp)
 10263ce:	lea    0x14(%rdi),%rsi
 10263d2:	lea    -0x30(%rbp),%rdi
 10263d6:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10263db:	mov    %rax,%r14
 10263de:	mov    -0x30(%rbp),%rcx
 10263e2:	add    %rcx,%r14
 10263e5:	mov    %r15,-0x348(%rbp)
 10263ec:	cmp    %r14,%rcx
 10263ef:	jae    1026adf <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x72f>
 10263f5:	lea    -0x348(%rbp),%r13
 10263fc:	lea    0x78(%rbx),%r10
 1026400:	lea    0x70(%rbx),%r11
 1026404:	lea    0x68(%rbx),%r15
 1026408:	lea    -0x1a56f(%rip),%r12        # 100bea0 <raw_shape+0x3a0>
 102640f:	jmp    1026435 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x85>
 1026411:	mov    0x1(%rcx),%rax
 1026415:	add    $0x9,%rcx
 1026419:	mov    %rcx,-0x30(%rbp)
 102641d:	nopl   (%rax)
 1026420:	mov    %rax,0x8(%r13)
 1026424:	add    $0x8,%r13
 1026428:	mov    -0x30(%rbp),%rcx
 102642c:	cmp    %r14,%rcx
 102642f:	jae    1026adb <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x72b>
 1026435:	lea    0x1(%rcx),%rax
 1026439:	mov    %rax,-0x30(%rbp)
 102643d:	movzbl (%rcx),%edx
 1026440:	lea    -0x3(%rdx),%esi
 1026443:	cmp    $0x91,%esi
 1026449:	ja     1026b69 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x7b9>
 102644f:	movslq (%r12,%rsi,4),%rsi
 1026453:	add    %r12,%rsi
 1026456:	jmp    *%rsi
 1026458:	add    $0xffffffd0,%edx
 102645b:	mov    %rdx,0x8(%r13)
 102645f:	jmp    1026424 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x74>
 1026461:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1026470:	mov    $0xfffffffffffffff9,%rsi
 1026477:	xor    %ecx,%ecx
 1026479:	mov    %rax,%rdi
 102647c:	nopl   0x0(%rax)
 1026480:	cmp    %r14,%rdi
 1026483:	je     1026af4 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x744>
 1026489:	add    $0x7,%rsi
 102648d:	movzbl (%rdi),%r9d
 1026491:	inc    %rdi
 1026494:	mov    %r9d,%r8d
 1026497:	and    $0x7f,%r9d
 102649b:	shlx   %rsi,%r9,%r9
 10264a0:	or     %r9,%rcx
 10264a3:	inc    %rax
 10264a6:	test   %r8b,%r8b
 10264a9:	js     1026480 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0xd0>
 10264ab:	lea    0x7(%rsi),%edi
 10264ae:	xor    %r9d,%r9d
 10264b1:	cmp    $0x39,%rsi
 10264b5:	mov    $0xffffffffffffffff,%rsi
 10264bc:	shlx   %rdi,%rsi,%rsi
 10264c1:	cmovae %r9,%rsi
 10264c5:	cmp    $0x40,%r8b
 10264c9:	cmovb  %r9,%rsi
 10264cd:	mov    %rax,-0x30(%rbp)
 10264d1:	add    $0xffffff92,%edx
 10264d4:	cmp    $0x12,%edx
 10264d7:	ja     1026b27 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x777>
 10264dd:	or     %rsi,%rcx
 10264e0:	lea    -0x1a3a3(%rip),%rax        # 100c144 <raw_shape+0x644>
 10264e7:	movslq (%rax,%rdx,4),%rdx
 10264eb:	add    %rax,%rdx
 10264ee:	mov    %rbx,%rax
 10264f1:	jmp    *%rdx
 10264f3:	lea    0x38(%rbx),%rax
 10264f7:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10264fc:	nopl   0x0(%rax)
 1026500:	add    $0xffffffb0,%edx
 1026503:	cmp    $0x10,%edx
 1026506:	ja     1026b27 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x777>
 102650c:	lea    -0x1a337(%rip),%rax        # 100c1dc <raw_shape+0x6dc>
 1026513:	movslq (%rax,%rdx,4),%rcx
 1026517:	add    %rax,%rcx
 102651a:	mov    %rbx,%rax
 102651d:	jmp    *%rcx
 102651f:	lea    0x18(%rbx),%rax
 1026523:	mov    (%rax),%rax
 1026526:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 102652b:	mov    %r10,%r15
 102652e:	lea    -0x30(%rbp),%rdi
 1026532:	mov    %r14,%rsi
 1026535:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102653a:	mov    -0x30(%rbp),%rdi
 102653e:	mov    $0xfffffffffffffff9,%rsi
 1026545:	xor    %ecx,%ecx
 1026547:	mov    %rdi,%rdx
 102654a:	nopw   0x0(%rax,%rax,1)
 1026550:	cmp    %r14,%rdi
 1026553:	je     1026af4 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x744>
 1026559:	add    $0x7,%rsi
 102655d:	movzbl (%rdi),%r9d
 1026561:	inc    %rdi
 1026564:	mov    %r9d,%r8d
 1026567:	and    $0x7f,%r9d
 102656b:	shlx   %rsi,%r9,%r9
 1026570:	or     %r9,%rcx
 1026573:	inc    %rdx
 1026576:	test   %r8b,%r8b
 1026579:	js     1026550 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x1a0>
 102657b:	lea    0x7(%rsi),%edi
 102657e:	xor    %r9d,%r9d
 1026581:	cmp    $0x39,%rsi
 1026585:	mov    $0xffffffffffffffff,%rsi
 102658c:	shlx   %rdi,%rsi,%rsi
 1026591:	cmovae %r9,%rsi
 1026595:	cmp    $0x40,%r8b
 1026599:	cmovb  %r9,%rsi
 102659d:	mov    %rdx,-0x30(%rbp)
 10265a1:	add    $0x2,%eax
 10265a4:	cmp    $0x12,%eax
 10265a7:	ja     1026b27 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x777>
 10265ad:	mov    %r15,%r10
 10265b0:	or     %rsi,%rcx
 10265b3:	lea    -0x1a4c2(%rip),%rdx        # 100c0f8 <raw_shape+0x5f8>
 10265ba:	movslq (%rdx,%rax,4),%rsi
 10265be:	add    %rdx,%rsi
 10265c1:	mov    %rbx,%rax
 10265c4:	lea    0x70(%rbx),%r11
 10265c8:	lea    0x68(%rbx),%r15
 10265cc:	jmp    *%rsi
 10265ce:	lea    0x80(%rbx),%rax
 10265d5:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10265d7:	mov    %r15,%rax
 10265da:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10265dc:	lea    0x58(%rbx),%rax
 10265e0:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10265e2:	lea    0x40(%rbx),%rax
 10265e6:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10265e8:	lea    0x48(%rbx),%rax
 10265ec:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10265ee:	lea    0x20(%rbx),%rax
 10265f2:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10265f4:	lea    0x60(%rbx),%rax
 10265f8:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 10265fa:	lea    0x8(%rbx),%rax
 10265fe:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026600:	mov    %r11,%rax
 1026603:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026605:	lea    0x18(%rbx),%rax
 1026609:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 102660b:	lea    0x50(%rbx),%rax
 102660f:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026611:	lea    0x10(%rbx),%rax
 1026615:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026617:	mov    %r10,%rax
 102661a:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 102661c:	lea    0x30(%rbx),%rax
 1026620:	jmp    1026630 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x280>
 1026622:	lea    0x28(%rbx),%rax
 1026626:	cs nopw 0x0(%rax,%rax,1)
 1026630:	add    (%rax),%rcx
 1026633:	mov    %rcx,0x8(%r13)
 1026637:	jmp    1026424 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x74>
 102663c:	mov    -0x8(%r13),%rax
 1026640:	xor    %ecx,%ecx
 1026642:	cmp    0x0(%r13),%rax
 1026646:	setb   %cl
 1026649:	jmp    1026998 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 102664e:	mov    -0x8(%r13),%rax
 1026652:	xor    %ecx,%ecx
 1026654:	cmp    0x0(%r13),%rax
 1026658:	setbe  %cl
 102665b:	jmp    1026998 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 1026660:	lea    -0x8(%r13),%rcx
 1026664:	mov    -0x8(%r13),%rax
 1026668:	mov    0x0(%r13),%rsi
 102666c:	mov    %rax,%rdx
 102666f:	or     %rsi,%rdx
 1026672:	shr    $0x20,%rdx
 1026676:	je     1026a9e <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x6ee>
 102667c:	cqto
 102667e:	idiv   %rsi
 1026681:	jmp    1026aa2 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x6f2>
 1026686:	mov    -0x8(%r13),%rax
 102668a:	xor    %ecx,%ecx
 102668c:	cmp    0x0(%r13),%rax
 1026690:	sete   %cl
 1026693:	jmp    1026998 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 1026698:	movswq 0x1(%rcx),%rax
 102669d:	add    $0x3,%rcx
 10266a1:	jmp    1026419 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 10266a6:	movswq 0x1(%rcx),%rax
 10266ab:	add    $0x3,%rcx
 10266af:	mov    %rcx,-0x30(%rbp)
 10266b3:	lea    -0x8(%r13),%rdx
 10266b7:	cmpq   $0x0,0x0(%r13)
 10266bc:	je     1026aad <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x6fd>
 10266c2:	add    %rax,%rcx
 10266c5:	mov    %rcx,-0x30(%rbp)
 10266c9:	mov    %rdx,%r13
 10266cc:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10266d1:	mov    -0x8(%r13),%rax
 10266d5:	xor    %ecx,%ecx
 10266d7:	cmp    0x0(%r13),%rax
 10266db:	setae  %cl
 10266de:	jmp    1026998 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 10266e3:	mov    $0xfffffffffffffff9,%rdx
 10266ea:	xor    %ecx,%ecx
 10266ec:	mov    %rax,%rsi
 10266ef:	nop
 10266f0:	cmp    %r14,%rsi
 10266f3:	je     1026af4 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x744>
 10266f9:	add    $0x7,%rdx
 10266fd:	movzbl (%rsi),%r8d
 1026701:	inc    %rsi
 1026704:	mov    %r8d,%edi
 1026707:	and    $0x7f,%r8d
 102670b:	shlx   %rdx,%r8,%r8
 1026710:	or     %r8,%rcx
 1026713:	inc    %rax
 1026716:	test   %dil,%dil
 1026719:	js     10266f0 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x340>
 102671b:	lea    0x7(%rdx),%esi
 102671e:	xor    %r8d,%r8d
 1026721:	cmp    $0x39,%rdx
 1026725:	mov    $0xffffffffffffffff,%rdx
 102672c:	shlx   %rsi,%rdx,%rdx
 1026731:	cmovae %r8,%rdx
 1026735:	cmp    $0x40,%dil
 1026739:	cmovb  %r8,%rdx
 102673d:	or     %rdx,%rcx
 1026740:	mov    %rax,-0x30(%rbp)
 1026744:	jmp    1026633 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x283>
 1026749:	mov    0x0(%r13),%rax
 102674d:	and    %rax,-0x8(%r13)
 1026751:	add    $0xfffffffffffffff8,%r13
 1026755:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102675a:	mov    -0x8(%r13),%rax
 102675e:	xor    %ecx,%ecx
 1026760:	cmp    0x0(%r13),%rax
 1026764:	seta   %cl
 1026767:	jmp    1026998 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5e8>
 102676c:	movslq 0x1(%rcx),%rax
 1026770:	add    $0x5,%rcx
 1026774:	jmp    1026419 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 1026779:	mov    0x0(%r13),%rax
 102677d:	xor    %rax,-0x8(%r13)
 1026781:	add    $0xfffffffffffffff8,%r13
 1026785:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102678a:	mov    0x0(%r13),%rax
 102678e:	test   %rax,%rax
 1026791:	jns    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026797:	neg    %rax
 102679a:	mov    %rax,0x0(%r13)
 102679e:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10267a3:	movsbq 0x1(%rcx),%rax
 10267a8:	jmp    10267e2 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x432>
 10267aa:	mov    0x0(%r13),%rax
 10267ae:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10267b3:	lea    -0x30(%rbp),%rdi
 10267b7:	mov    %r14,%rsi
 10267ba:	mov    %r10,%r15
 10267bd:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10267c2:	mov    %r15,%r10
 10267c5:	lea    0x68(%rbx),%r15
 10267c9:	lea    0x70(%rbx),%r11
 10267cd:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10267d2:	mov    0x1(%rcx),%eax
 10267d5:	add    $0x5,%rcx
 10267d9:	jmp    1026419 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 10267de:	movzbl 0x1(%rcx),%eax
 10267e2:	add    $0x2,%rcx
 10267e6:	jmp    1026419 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 10267eb:	add    $0xfffffffffffffff8,%r13
 10267ef:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10267f4:	movzwl 0x1(%rcx),%eax
 10267f8:	add    $0x3,%rcx
 10267fc:	jmp    1026419 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x69>
 1026801:	mov    0x0(%r13),%rax
 1026805:	mov    (%rax),%rax
 1026808:	mov    %rax,0x0(%r13)
 102680c:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026811:	mov    0x0(%r13),%rax
 1026815:	vmovups -0x10(%r13),%xmm0
 102681b:	vmovups %xmm0,-0x8(%r13)
 1026821:	mov    %rax,-0x10(%r13)
 1026825:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102682a:	lea    -0x8(%r13),%rcx
 102682e:	mov    -0x8(%r13),%rax
 1026832:	mov    0x0(%r13),%rsi
 1026836:	mov    %rax,%rdx
 1026839:	or     %rsi,%rdx
 102683c:	shr    $0x20,%rdx
 1026840:	je     1026ab5 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x705>
 1026846:	cqto
 1026848:	idiv   %rsi
 102684b:	jmp    1026ab9 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x709>
 1026850:	mov    -0x8(%r13),%rax
 1026854:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026859:	vpshufd $0x4e,-0x8(%r13),%xmm0
 1026860:	vmovups %xmm0,-0x8(%r13)
 1026866:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102686b:	movzbl 0x1(%rcx),%eax
 102686f:	add    $0x2,%rcx
 1026873:	mov    %rcx,-0x30(%rbp)
 1026877:	shl    $0x3,%eax
 102687a:	mov    %r13,%rcx
 102687d:	sub    %rax,%rcx
 1026880:	mov    (%rcx),%rax
 1026883:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026888:	notq   0x0(%r13)
 102688c:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026891:	movzbl 0x0(%r13),%ecx
 1026896:	shlq   %cl,-0x8(%r13)
 102689a:	add    $0xfffffffffffffff8,%r13
 102689e:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10268a3:	movzbl 0x0(%r13),%ecx
 10268a8:	shrq   %cl,-0x8(%r13)
 10268ac:	add    $0xfffffffffffffff8,%r13
 10268b0:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10268b5:	mov    0x0(%r13),%rax
 10268b9:	add    %rax,-0x8(%r13)
 10268bd:	add    $0xfffffffffffffff8,%r13
 10268c1:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10268c6:	mov    0x0(%r13),%rax
 10268ca:	lea    0x2(%rcx),%rdx
 10268ce:	mov    %rdx,-0x30(%rbp)
 10268d2:	movzbl 0x1(%rcx),%ecx
 10268d6:	popcnt %ecx,%edx
 10268da:	cmp    $0x1,%edx
 10268dd:	jne    1026b48 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x798>
 10268e3:	tzcnt  %ecx,%ecx
 10268e7:	cmp    $0x3,%ecx
 10268ea:	ja     1026b48 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x798>
 10268f0:	lea    -0x1a80f(%rip),%rdx        # 100c0e8 <raw_shape+0x5e8>
 10268f7:	movslq (%rdx,%rcx,4),%rcx
 10268fb:	add    %rdx,%rcx
 10268fe:	jmp    *%rcx
 1026900:	movzbl (%rax),%eax
 1026903:	mov    %rax,0x0(%r13)
 1026907:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102690c:	lea    -0x30(%rbp),%rdi
 1026910:	mov    %r14,%rsi
 1026913:	mov    %r10,%r15
 1026916:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 102691b:	mov    %r15,%r10
 102691e:	lea    0x68(%rbx),%r15
 1026922:	lea    0x70(%rbx),%r11
 1026926:	add    %rax,0x0(%r13)
 102692a:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102692f:	movzbl 0x0(%r13),%ecx
 1026934:	sarq   %cl,-0x8(%r13)
 1026938:	add    $0xfffffffffffffff8,%r13
 102693c:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026941:	mov    0x0(%r13),%rax
 1026945:	mov    (%rax),%rax
 1026948:	jmp    1026953 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x5a3>
 102694a:	mov    -0x8(%r13),%rax
 102694e:	imul   0x0(%r13),%rax
 1026953:	mov    %rax,-0x8(%r13)
 1026957:	add    $0xfffffffffffffff8,%r13
 102695b:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026960:	mov    0x0(%r13),%rax
 1026964:	sub    %rax,-0x8(%r13)
 1026968:	add    $0xfffffffffffffff8,%r13
 102696c:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026971:	mov    0x0(%r13),%rax
 1026975:	or     %rax,-0x8(%r13)
 1026979:	add    $0xfffffffffffffff8,%r13
 102697d:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026982:	negq   0x0(%r13)
 1026986:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 102698b:	mov    -0x8(%r13),%rax
 102698f:	xor    %ecx,%ecx
 1026991:	cmp    0x0(%r13),%rax
 1026995:	setne  %cl
 1026998:	mov    %rcx,-0x8(%r13)
 102699c:	add    $0xfffffffffffffff8,%r13
 10269a0:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10269a5:	movswq 0x1(%rcx),%rax
 10269aa:	add    %rcx,%rax
 10269ad:	add    $0x3,%rax
 10269b1:	mov    %rax,-0x30(%rbp)
 10269b5:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 10269ba:	mov    %r10,%r15
 10269bd:	lea    -0x30(%rbp),%rdi
 10269c1:	mov    %r14,%rsi
 10269c4:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 10269c9:	add    $0x2,%eax
 10269cc:	cmp    $0x12,%eax
 10269cf:	ja     1026b27 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x777>
 10269d5:	lea    -0x1a84c(%rip),%rcx        # 100c190 <raw_shape+0x690>
 10269dc:	movslq (%rcx,%rax,4),%rdx
 10269e0:	add    %rcx,%rdx
 10269e3:	mov    %rbx,%rax
 10269e6:	mov    %r15,%r10
 10269e9:	lea    0x70(%rbx),%r11
 10269ed:	lea    0x68(%rbx),%r15
 10269f1:	jmp    *%rdx
 10269f3:	lea    0x38(%rbx),%rax
 10269f7:	mov    (%rax),%rax
 10269fa:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 10269ff:	lea    0x80(%rbx),%rax
 1026a06:	mov    (%rax),%rax
 1026a09:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a0e:	mov    (%r11),%rax
 1026a11:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a16:	lea    0x58(%rbx),%rax
 1026a1a:	mov    (%rax),%rax
 1026a1d:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a22:	lea    0x28(%rbx),%rax
 1026a26:	mov    (%rax),%rax
 1026a29:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a2e:	lea    0x60(%rbx),%rax
 1026a32:	mov    (%rax),%rax
 1026a35:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a3a:	lea    0x48(%rbx),%rax
 1026a3e:	mov    (%rax),%rax
 1026a41:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a46:	lea    0x10(%rbx),%rax
 1026a4a:	mov    (%rax),%rax
 1026a4d:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a52:	mov    (%r10),%rax
 1026a55:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a5a:	lea    0x8(%rbx),%rax
 1026a5e:	mov    (%rax),%rax
 1026a61:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a66:	mov    (%r15),%rax
 1026a69:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a6e:	lea    0x20(%rbx),%rax
 1026a72:	mov    (%rax),%rax
 1026a75:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a7a:	lea    0x30(%rbx),%rax
 1026a7e:	mov    (%rax),%rax
 1026a81:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a86:	lea    0x40(%rbx),%rax
 1026a8a:	mov    (%rax),%rax
 1026a8d:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a92:	lea    0x50(%rbx),%rax
 1026a96:	mov    (%rax),%rax
 1026a99:	jmp    1026420 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x70>
 1026a9e:	xor    %edx,%edx
 1026aa0:	div    %esi
 1026aa2:	mov    %rdx,(%rcx)
 1026aa5:	mov    %rcx,%r13
 1026aa8:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026aad:	mov    %rdx,%r13
 1026ab0:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026ab5:	xor    %edx,%edx
 1026ab7:	div    %esi
 1026ab9:	mov    %rax,(%rcx)
 1026abc:	mov    %rcx,%r13
 1026abf:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026ac4:	movzwl (%rax),%eax
 1026ac7:	mov    %rax,0x0(%r13)
 1026acb:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026ad0:	mov    (%rax),%eax
 1026ad2:	mov    %rax,0x0(%r13)
 1026ad6:	jmp    1026428 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x78>
 1026adb:	mov    0x0(%r13),%r15
 1026adf:	mov    %r15,%rax
 1026ae2:	add    $0x328,%rsp
 1026ae9:	pop    %rbx
 1026aea:	pop    %r12
 1026aec:	pop    %r13
 1026aee:	pop    %r14
 1026af0:	pop    %r15
 1026af2:	pop    %rbp
 1026af3:	ret
 1026af4:	mov    0x221d(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026afb:	mov    (%rbx),%rdi
 1026afe:	lea    -0x2223a(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026b05:	lea    -0x225c3(%rip),%rdx        # 1004549 <qbe_empty_registry+0x9f1>
 1026b0c:	lea    -0x22c62(%rip),%rcx        # 1003eb1 <qbe_empty_registry+0x359>
 1026b13:	xor    %eax,%eax
 1026b15:	call   1027760 <fprintf@plt>
 1026b1a:	mov    (%rbx),%rdi
 1026b1d:	call   1027800 <fflush@plt>
 1026b22:	call   1027810 <abort@plt>
 1026b27:	mov    0x21ea(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026b2e:	mov    (%rbx),%rdi
 1026b31:	lea    -0x2226d(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026b38:	lea    -0x22d72(%rip),%rdx        # 1003dcd <qbe_empty_registry+0x275>
 1026b3f:	lea    -0x22da1(%rip),%rcx        # 1003da5 <qbe_empty_registry+0x24d>
 1026b46:	jmp    1026b13 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 1026b48:	mov    0x21c9(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026b4f:	mov    (%rbx),%rdi
 1026b52:	lea    -0x2228e(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026b59:	lea    -0x22c92(%rip),%rdx        # 1003ece <qbe_empty_registry+0x376>
 1026b60:	lea    -0x22ae5(%rip),%rcx        # 1004082 <qbe_empty_registry+0x52a>
 1026b67:	jmp    1026b13 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 1026b69:	mov    0x21a8(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026b70:	mov    (%rbx),%rdi
 1026b73:	lea    -0x222af(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026b7a:	lea    -0x22cb3(%rip),%rdx        # 1003ece <qbe_empty_registry+0x376>
 1026b81:	lea    -0x2298f(%rip),%rcx        # 10041f9 <qbe_empty_registry+0x6a1>
 1026b88:	jmp    1026b13 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 1026b8a:	mov    0x2187(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026b91:	mov    (%rbx),%rdi
 1026b94:	lea    -0x222d0(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026b9b:	lea    -0x22cd4(%rip),%rdx        # 1003ece <qbe_empty_registry+0x376>
 1026ba2:	lea    -0x22993(%rip),%rcx        # 1004216 <qbe_empty_registry+0x6be>
 1026ba9:	jmp    1026b13 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 1026bae:	mov    0x2163(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 1026bb5:	mov    (%rbx),%rdi
 1026bb8:	lea    -0x222f4(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 1026bbf:	lea    -0x22cf8(%rip),%rdx        # 1003ece <qbe_empty_registry+0x376>
 1026bc6:	lea    -0x229f0(%rip),%rcx        # 10041dd <qbe_empty_registry+0x685>
 1026bcd:	jmp    1026b13 <_ZN9libunwind17DwarfInstructionsINS_17LocalAddressSpaceENS_16Registers_x86_64EE18evaluateExpressionEmRS1_RKS2_m+0x763>
 1026bd2:	int3
 1026bd3:	int3
 1026bd4:	int3
 1026bd5:	int3
 1026bd6:	int3
 1026bd7:	int3
 1026bd8:	int3
 1026bd9:	int3
 1026bda:	int3
 1026bdb:	int3
 1026bdc:	int3
 1026bdd:	int3
 1026bde:	int3
 1026bdf:	int3

0000000001026be0 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj>:
 1026be0:	push   %rbp
 1026be1:	mov    %rsp,%rbp
 1026be4:	push   %r15
 1026be6:	push   %r14
 1026be8:	push   %r13
 1026bea:	push   %r12
 1026bec:	push   %rbx
 1026bed:	sub    $0x2b8,%rsp
 1026bf4:	mov    %rdx,%rbx
 1026bf7:	mov    %rsi,%r12
 1026bfa:	mov    %rdi,%r14
 1026bfd:	mov    %ecx,-0x30(%rbp)
 1026c00:	test   %ecx,%ecx
 1026c02:	je     1026c39 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x59>
 1026c04:	mov    0x8(%r14),%rdi
 1026c08:	mov    0x10(%rbx),%rdx
 1026c0c:	mov    0x18(%rbx),%rcx
 1026c10:	mov    -0x30(%rbp),%r8d
 1026c14:	add    %rdx,%r8
 1026c17:	lea    -0xb0(%rbp),%rax
 1026c1e:	mov    %rax,(%rsp)
 1026c22:	lea    -0x78(%rbp),%r9
 1026c26:	mov    %r12,%rsi
 1026c29:	call   1027110 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE>
 1026c2e:	mov    $0x1,%r15b
 1026c31:	test   %al,%al
 1026c33:	jne    1026d34 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x154>
 1026c39:	mov    0x20(%rbx),%rdx
 1026c3d:	test   %rdx,%rdx
 1026c40:	je     1026c67 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x87>
 1026c42:	mov    0x8(%r14),%rdi
 1026c46:	mov    0x28(%rbx),%ecx
 1026c49:	lea    -0x78(%rbp),%r8
 1026c4d:	lea    -0xb0(%rbp),%r9
 1026c54:	mov    %r12,%rsi
 1026c57:	call   1027300 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE>
 1026c5c:	mov    $0x1,%r15b
 1026c5f:	test   %al,%al
 1026c61:	jne    1026d34 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x154>
 1026c67:	mov    (%rbx),%r15
 1026c6a:	lea    0x4cff(%rip),%rdi        # 102b970 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026c71:	call   1027ae0 <pthread_rwlock_rdlock@plt>
 1026c76:	mov    0x4c93(%rip),%rax        # 102b910 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE7_bufferE>
 1026c7d:	mov    0x4c94(%rip),%rcx        # 102b918 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE11_bufferUsedE>
 1026c84:	cmp    %rcx,%rax
 1026c87:	jae    1026cf4 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x114>
 1026c89:	mov    (%r12),%rdx
 1026c8d:	jmp    1026c99 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xb9>
 1026c8f:	nop
 1026c90:	add    $0x20,%rax
 1026c94:	cmp    %rcx,%rax
 1026c97:	jae    1026cf4 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x114>
 1026c99:	cmp    $0xffffffffffffffff,%r15
 1026c9d:	je     1026ca4 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xc4>
 1026c9f:	cmp    (%rax),%r15
 1026ca2:	jne    1026c90 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xb0>
 1026ca4:	cmp    %rdx,0x8(%rax)
 1026ca8:	ja     1026c90 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xb0>
 1026caa:	cmp    0x10(%rax),%rdx
 1026cae:	jae    1026c90 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0xb0>
 1026cb0:	mov    0x18(%rax),%r13
 1026cb4:	lea    0x4cb5(%rip),%rdi        # 102b970 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026cbb:	call   1027aa0 <pthread_rwlock_unlock@plt>
 1026cc0:	test   %r13,%r13
 1026cc3:	je     1026d00 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x120>
 1026cc5:	mov    0x8(%r14),%rdi
 1026cc9:	mov    0x10(%rbx),%rdx
 1026ccd:	mov    0x18(%rbx),%rcx
 1026cd1:	lea    -0xb0(%rbp),%rax
 1026cd8:	mov    %rax,(%rsp)
 1026cdc:	lea    -0x78(%rbp),%r9
 1026ce0:	mov    %r12,%rsi
 1026ce3:	mov    %r13,%r8
 1026ce6:	call   1027110 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE>
 1026ceb:	test   %al,%al
 1026ced:	je     1026d00 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x120>
 1026cef:	xor    %r15d,%r15d
 1026cf2:	jmp    1026d34 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x154>
 1026cf4:	lea    0x4c75(%rip),%rdi        # 102b970 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026cfb:	call   1027aa0 <pthread_rwlock_unlock@plt>
 1026d00:	mov    0x8(%r14),%rdi
 1026d04:	mov    0x10(%rbx),%rdx
 1026d08:	mov    0x18(%rbx),%rcx
 1026d0c:	lea    -0xb0(%rbp),%rax
 1026d13:	mov    %rax,(%rsp)
 1026d17:	xor    %r13d,%r13d
 1026d1a:	lea    -0x78(%rbp),%r9
 1026d1e:	mov    %r12,%rsi
 1026d21:	xor    %r8d,%r8d
 1026d24:	call   1027110 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE>
 1026d29:	mov    $0x1,%r15b
 1026d2c:	test   %al,%al
 1026d2e:	je     1026ed1 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2f1>
 1026d34:	mov    (%rbx),%rax
 1026d37:	mov    %rax,-0x38(%rbp)
 1026d3b:	lea    -0x2d8(%rbp),%r13
 1026d42:	mov    $0x228,%edx
 1026d47:	mov    %r13,%rdi
 1026d4a:	xor    %esi,%esi
 1026d4c:	call   1027650 <memset@plt>
 1026d51:	mov    0x8(%r14),%rdi
 1026d55:	lea    -0x78(%rbp),%rsi
 1026d59:	lea    -0xb0(%rbp),%rdx
 1026d60:	mov    %r12,%rcx
 1026d63:	mov    $0x1,%r8d
 1026d69:	mov    %r13,%r9
 1026d6c:	call   1025290 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE20parseFDEInstructionsINS_16Registers_x86_64EEEbRS1_RKNS2_8FDE_InfoERKNS2_8CIE_InfoENT_23link_hardened_reg_arg_tEiPNS2_10PrologInfoE>
 1026d71:	test   %al,%al
 1026d73:	je     1026ece <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2ee>
 1026d79:	cmpl   $0x0,-0x30(%rbp)
 1026d7d:	setne  %al
 1026d80:	mov    -0x60(%rbp),%rdx
 1026d84:	mov    %rdx,0xb8(%r14)
 1026d8b:	vmovups -0x58(%rbp),%xmm0
 1026d90:	mov    -0x58(%rbp),%rsi
 1026d94:	vmovups %xmm0,0xc0(%r14)
 1026d9d:	mov    -0x90(%rbp),%rcx
 1026da4:	mov    %rcx,0xd0(%r14)
 1026dab:	mov    -0x2c8(%rbp),%ecx
 1026db1:	mov    %rcx,0xd8(%r14)
 1026db8:	movq   $0x0,0xe0(%r14)
 1026dc3:	movl   $0x4000000,0xe8(%r14)
 1026dce:	mov    -0x78(%rbp),%r12
 1026dd2:	mov    %r12,0xf0(%r14)
 1026dd9:	mov    -0x70(%rbp),%ecx
 1026ddc:	mov    %ecx,0xec(%r14)
 1026de3:	mov    -0x38(%rbp),%rcx
 1026de7:	mov    %rcx,0xf8(%r14)
 1026dee:	xor    $0x1,%r15b
 1026df2:	mov    $0x1,%r13b
 1026df5:	or     %al,%r15b
 1026df8:	jne    1026ed1 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2f1>
 1026dfe:	cmpq   $0x0,0x20(%rbx)
 1026e03:	jne    1026ed1 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2f1>
 1026e09:	mov    %rsi,-0x38(%rbp)
 1026e0d:	mov    %rdx,-0x30(%rbp)
 1026e11:	mov    (%rbx),%r14
 1026e14:	lea    0x4b55(%rip),%rdi        # 102b970 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026e1b:	call   1027a90 <pthread_rwlock_wrlock@plt>
 1026e20:	mov    0x4af1(%rip),%rax        # 102b918 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE11_bufferUsedE>
 1026e27:	mov    0x4af2(%rip),%rbx        # 102b920 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE10_bufferEndE>
 1026e2e:	cmp    %rbx,%rax
 1026e31:	jb     1026e9e <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2be>
 1026e33:	mov    %r14,-0x48(%rbp)
 1026e37:	mov    0x4ad2(%rip),%r15        # 102b910 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE7_bufferE>
 1026e3e:	sub    %r15,%rbx
 1026e41:	mov    %rbx,%r14
 1026e44:	sar    $0x3,%r14
 1026e48:	lea    0x0(,%rbx,4),%rdi
 1026e50:	call   1027680 <malloc@plt>
 1026e55:	mov    %rax,-0x40(%rbp)
 1026e59:	mov    %rax,%rdi
 1026e5c:	mov    %r15,%rsi
 1026e5f:	mov    %rbx,%rdx
 1026e62:	call   10276a0 <memcpy@plt>
 1026e67:	lea    0x4b42(%rip),%rax        # 102b9b0 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE14_initialBufferE>
 1026e6e:	cmp    %rax,%r15
 1026e71:	je     1026e7b <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x29b>
 1026e73:	mov    %r15,%rdi
 1026e76:	call   10276f0 <free@plt>
 1026e7b:	mov    -0x40(%rbp),%rax
 1026e7f:	mov    %rax,0x4a8a(%rip)        # 102b910 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE7_bufferE>
 1026e86:	add    %rax,%rbx
 1026e89:	shl    $0x5,%r14
 1026e8d:	add    %rax,%r14
 1026e90:	mov    %r14,0x4a89(%rip)        # 102b920 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE10_bufferEndE>
 1026e97:	mov    %rbx,%rax
 1026e9a:	mov    -0x48(%rbp),%r14
 1026e9e:	mov    %r14,(%rax)
 1026ea1:	mov    -0x30(%rbp),%rcx
 1026ea5:	mov    %rcx,0x8(%rax)
 1026ea9:	mov    -0x38(%rbp),%rcx
 1026ead:	mov    %rcx,0x10(%rax)
 1026eb1:	mov    %r12,0x18(%rax)
 1026eb5:	add    $0x20,%rax
 1026eb9:	mov    %rax,0x4a58(%rip)        # 102b918 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE11_bufferUsedE>
 1026ec0:	lea    0x4aa9(%rip),%rdi        # 102b970 <_ZN9libunwind13DwarfFDECacheINS_17LocalAddressSpaceEE5_lockE>
 1026ec7:	call   1027aa0 <pthread_rwlock_unlock@plt>
 1026ecc:	jmp    1026ed1 <_ZN9libunwind12UnwindCursorINS_17LocalAddressSpaceENS_16Registers_x86_64EE23getInfoFromDwarfSectionERKmRKNS_18UnwindInfoSectionsEj+0x2f1>
 1026ece:	xor    %r13d,%r13d
 1026ed1:	mov    %r13d,%eax
 1026ed4:	add    $0x2b8,%rsp
 1026edb:	pop    %rbx
 1026edc:	pop    %r12
 1026ede:	pop    %r13
 1026ee0:	pop    %r14
 1026ee2:	pop    %r15
 1026ee4:	pop    %rbp
 1026ee5:	ret
 1026ee6:	int3
 1026ee7:	int3
 1026ee8:	int3
 1026ee9:	int3
 1026eea:	int3
 1026eeb:	int3
 1026eec:	int3
 1026eed:	int3
 1026eee:	int3
 1026eef:	int3

0000000001026ef0 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE>:
 1026ef0:	push   %rbp
 1026ef1:	mov    %rsp,%rbp
 1026ef4:	push   %r15
 1026ef6:	push   %r14
 1026ef8:	push   %r13
 1026efa:	push   %r12
 1026efc:	push   %rbx
 1026efd:	sub    $0x18,%rsp
 1026f01:	mov    %rcx,%r14
 1026f04:	mov    %rsi,%rbx
 1026f07:	mov    %rdx,%rcx
 1026f0a:	sub    %rsi,%rcx
 1026f0d:	cmp    $0x3,%rcx
 1026f11:	ja     1026f20 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0x30>
 1026f13:	cmp    %rbx,%rdx
 1026f16:	jne    1026fa1 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xb1>
 1026f1c:	xor    %eax,%eax
 1026f1e:	jmp    1026f92 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xa2>
 1026f20:	movzbl (%rbx),%eax
 1026f23:	cmp    $0x1,%eax
 1026f26:	jne    1026fbe <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xce>
 1026f2c:	movzbl 0x1(%rbx),%ecx
 1026f30:	movzbl 0x2(%rbx),%r12d
 1026f35:	lea    0x4(%rbx),%rax
 1026f39:	mov    %rax,-0x30(%rbp)
 1026f3d:	movzbl 0x3(%rbx),%eax
 1026f41:	mov    %al,0x18(%r14)
 1026f45:	xor    %r15d,%r15d
 1026f48:	lea    -0x30(%rbp),%rsi
 1026f4c:	mov    %rdi,%r13
 1026f4f:	mov    %rdx,-0x38(%rbp)
 1026f53:	mov    %rbx,%r8
 1026f56:	xor    %r9d,%r9d
 1026f59:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1026f5e:	mov    %rax,(%r14)
 1026f61:	cmp    $0xff,%r12b
 1026f65:	je     1026f84 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0x94>
 1026f67:	movzbl %r12b,%ecx
 1026f6b:	lea    -0x30(%rbp),%rsi
 1026f6f:	mov    %r13,%rdi
 1026f72:	mov    -0x38(%rbp),%rdx
 1026f76:	mov    %rbx,%r8
 1026f79:	xor    %r9d,%r9d
 1026f7c:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1026f81:	mov    %rax,%r15
 1026f84:	mov    %r15,0x8(%r14)
 1026f88:	mov    -0x30(%rbp),%rax
 1026f8c:	mov    %rax,0x10(%r14)
 1026f90:	mov    $0x1,%al
 1026f92:	add    $0x18,%rsp
 1026f96:	pop    %rbx
 1026f97:	pop    %r12
 1026f99:	pop    %r13
 1026f9b:	pop    %r14
 1026f9d:	pop    %r15
 1026f9f:	pop    %rbp
 1026fa0:	ret
 1026fa1:	mov    0x1d70(%rip),%r14        # 1028d18 <stderr@GLIBC_2.2.5>
 1026fa8:	mov    (%r14),%rdi
 1026fab:	lea    -0x2216d(%rip),%rsi        # 1004e45 <qbe_empty_registry+0x12ed>
 1026fb2:	mov    %rbx,%rdx
 1026fb5:	xor    %eax,%eax
 1026fb7:	call   1027760 <fprintf@plt>
 1026fbc:	jmp    1026fdb <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xeb>
 1026fbe:	mov    0x1d53(%rip),%r14        # 1028d18 <stderr@GLIBC_2.2.5>
 1026fc5:	mov    (%r14),%rdi
 1026fc8:	lea    -0x228bb(%rip),%rsi        # 1004714 <qbe_empty_registry+0xbbc>
 1026fcf:	mov    %eax,%edx
 1026fd1:	mov    %rbx,%rcx
 1026fd4:	xor    %eax,%eax
 1026fd6:	call   1027760 <fprintf@plt>
 1026fdb:	mov    (%r14),%rdi
 1026fde:	call   1027800 <fflush@plt>
 1026fe3:	xor    %eax,%eax
 1026fe5:	jmp    1026f92 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE+0xa2>
 1026fe7:	int3
 1026fe8:	int3
 1026fe9:	int3
 1026fea:	int3
 1026feb:	int3
 1026fec:	int3
 1026fed:	int3
 1026fee:	int3
 1026fef:	int3

0000000001026ff0 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv>:
 1026ff0:	push   %rbp
 1026ff1:	mov    %rsp,%rbp
 1026ff4:	push   %r15
 1026ff6:	push   %r14
 1026ff8:	push   %r13
 1026ffa:	push   %r12
 1026ffc:	push   %rbx
 1026ffd:	sub    $0x28,%rsp
 1027001:	movzwl 0x18(%rdi),%r12d
 1027006:	xor    %eax,%eax
 1027008:	test   %r12,%r12
 102700b:	je     10270fc <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10c>
 1027011:	mov    %rdx,%rbx
 1027014:	mov    %rdi,%r14
 1027017:	mov    0x10(%rdx),%rcx
 102701b:	mov    (%rdi),%r13
 102701e:	cmp    %r13,%rcx
 1027021:	jb     10270fc <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10c>
 1027027:	mov    0x10(%r14),%rax
 102702b:	imul   $0x38,%r12,%rdx
 102702f:	xor    %esi,%esi
 1027031:	jmp    102704d <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x5d>
 1027033:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1027040:	add    $0x38,%rsi
 1027044:	cmp    %rsi,%rdx
 1027047:	je     10270fa <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10a>
 102704d:	cmpl   $0x1,(%rax,%rsi,1)
 1027051:	jne    1027040 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x50>
 1027053:	mov    0x10(%rax,%rsi,1),%rdi
 1027058:	add    %r13,%rdi
 102705b:	cmp    %rdi,%rcx
 102705e:	jb     1027040 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x50>
 1027060:	mov    0x28(%rax,%rsi,1),%r8
 1027065:	lea    (%r8,%rdi,1),%r9
 1027069:	cmp    %r9,%rcx
 102706c:	jae    1027040 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x50>
 102706e:	mov    0x8(%rbx),%rax
 1027072:	mov    %rdi,(%rax)
 1027075:	mov    %r8,0x8(%rax)
 1027079:	mov    $0xffffffff,%r15d
 102707f:	add    %r12,%r15
 1027082:	dec    %r12
 1027085:	jmp    102709e <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0xae>
 1027087:	nopw   0x0(%rax,%rax,1)
 1027090:	mov    %r12d,%eax
 1027093:	dec    %r15
 1027096:	dec    %r12
 1027099:	test   %ax,%ax
 102709c:	je     10270fa <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10a>
 102709e:	mov    0x10(%r14),%rax
 10270a2:	mov    %r15d,%ecx
 10270a5:	imul   $0x38,%rcx,%rcx
 10270a9:	cmpl   $0x6474e550,(%rax,%rcx,1)
 10270b0:	jne    1027090 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0xa0>
 10270b2:	add    %rcx,%rax
 10270b5:	mov    0x10(%rax),%rsi
 10270b9:	add    %r13,%rsi
 10270bc:	mov    0x8(%rbx),%rcx
 10270c0:	mov    %rsi,0x20(%rcx)
 10270c4:	mov    0x28(%rax),%rdx
 10270c8:	mov    %rdx,0x28(%rcx)
 10270cc:	mov    (%rbx),%rdi
 10270cf:	add    %rsi,%rdx
 10270d2:	lea    -0x48(%rbp),%rcx
 10270d6:	call   1026ef0 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE>
 10270db:	test   %al,%al
 10270dd:	je     1027090 <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0xa0>
 10270df:	mov    -0x48(%rbp),%rax
 10270e3:	mov    0x8(%rbx),%rcx
 10270e7:	mov    %rax,0x10(%rcx)
 10270eb:	movq   $0xffffffffffffffff,0x18(%rcx)
 10270f3:	mov    $0x1,%eax
 10270f8:	jmp    10270fc <_ZN9libunwindL24findUnwindSectionsByPhdrEP12dl_phdr_infomPv+0x10c>
 10270fa:	xor    %eax,%eax
 10270fc:	add    $0x28,%rsp
 1027100:	pop    %rbx
 1027101:	pop    %r12
 1027103:	pop    %r13
 1027105:	pop    %r14
 1027107:	pop    %r15
 1027109:	pop    %rbp
 102710a:	ret
 102710b:	int3
 102710c:	int3
 102710d:	int3
 102710e:	int3
 102710f:	int3

0000000001027110 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE>:
 1027110:	push   %rbp
 1027111:	mov    %rsp,%rbp
 1027114:	push   %r15
 1027116:	push   %r14
 1027118:	push   %r13
 102711a:	push   %r12
 102711c:	push   %rbx
 102711d:	sub    $0x28,%rsp
 1027121:	mov    %r8,%r14
 1027124:	mov    %rsi,-0x50(%rbp)
 1027128:	test   %r8,%r8
 102712b:	cmove  %rdx,%r14
 102712f:	mov    %r14,-0x30(%rbp)
 1027133:	lea    (%rcx,%rdx,1),%r15
 1027137:	cmp    $0xffffffffffffffff,%rcx
 102713b:	cmove  %rcx,%r15
 102713f:	cmp    %r15,%r14
 1027142:	jae    10272c6 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1b6>
 1027148:	mov    %rdx,%r13
 102714b:	mov    %rdi,-0x48(%rbp)
 102714f:	mov    %r9,-0x38(%rbp)
 1027153:	mov    $0xffffffff,%edx
 1027158:	jmp    102716d <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x5d>
 102715a:	nopw   0x0(%rax,%rax,1)
 1027160:	mov    %r14,-0x30(%rbp)
 1027164:	cmp    %r15,%r14
 1027167:	jae    10272c6 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1b6>
 102716d:	mov    %r14,%rbx
 1027170:	mov    (%r14),%r14d
 1027173:	lea    0x4(%rbx),%rsi
 1027177:	mov    %rsi,-0x30(%rbp)
 102717b:	cmp    %rdx,%r14
 102717e:	jne    102718c <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x7c>
 1027180:	mov    0x4(%rbx),%r14
 1027184:	lea    0xc(%rbx),%rsi
 1027188:	mov    %rsi,-0x30(%rbp)
 102718c:	test   %r14,%r14
 102718f:	je     10272c6 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1b6>
 1027195:	mov    (%rsi),%eax
 1027197:	add    %rsi,%r14
 102719a:	test   %rax,%rax
 102719d:	je     1027160 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 102719f:	sub    %rax,%rsi
 10271a2:	cmp    %rsi,%r13
 10271a5:	seta   %al
 10271a8:	cmp    %r15,%rsi
 10271ab:	setae  %cl
 10271ae:	or     %al,%cl
 10271b0:	jne    1027160 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 10271b2:	mov    -0x48(%rbp),%rdi
 10271b6:	mov    0x10(%rbp),%rdx
 10271ba:	call   1024580 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE8parseCIEERS1_mPNS2_8CIE_InfoE>
 10271bf:	mov    $0xffffffff,%edx
 10271c4:	test   %rax,%rax
 10271c7:	jne    1027160 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 10271c9:	addq   $0x4,-0x30(%rbp)
 10271ce:	mov    0x10(%rbp),%rax
 10271d2:	movzbl 0x18(%rax),%ecx
 10271d6:	mov    -0x48(%rbp),%r12
 10271da:	mov    %r12,%rdi
 10271dd:	lea    -0x30(%rbp),%rsi
 10271e1:	mov    %r14,%rdx
 10271e4:	xor    %r8d,%r8d
 10271e7:	xor    %r9d,%r9d
 10271ea:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 10271ef:	mov    %rax,-0x40(%rbp)
 10271f3:	mov    0x10(%rbp),%rax
 10271f7:	movzbl 0x18(%rax),%ecx
 10271fb:	and    $0xf,%ecx
 10271fe:	mov    %r12,%rdi
 1027201:	lea    -0x30(%rbp),%rsi
 1027205:	mov    %r14,%rdx
 1027208:	xor    %r8d,%r8d
 102720b:	xor    %r9d,%r9d
 102720e:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1027213:	mov    -0x40(%rbp),%rcx
 1027217:	mov    $0xffffffff,%edx
 102721c:	mov    %rax,%r12
 102721f:	mov    -0x50(%rbp),%rax
 1027223:	mov    (%rax),%rax
 1027226:	cmp    %rax,%rcx
 1027229:	ja     1027160 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 102722f:	add    %rcx,%r12
 1027232:	cmp    %r12,%rax
 1027235:	jae    1027160 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x50>
 102723b:	mov    -0x38(%rbp),%rax
 102723f:	movq   $0x0,0x28(%rax)
 1027247:	mov    0x10(%rbp),%r15
 102724b:	cmpb   $0x0,0x31(%r15)
 1027250:	je     10272d7 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1c7>
 1027256:	lea    -0x30(%rbp),%rdi
 102725a:	mov    %r14,%rsi
 102725d:	call   10261e0 <_ZN9libunwind17LocalAddressSpace10getULEB128ERmm>
 1027262:	mov    %rax,%r13
 1027265:	mov    %r15,%rax
 1027268:	mov    -0x30(%rbp),%r15
 102726c:	add    %r15,%r13
 102726f:	movzbl 0x19(%rax),%eax
 1027273:	cmp    $0xff,%al
 1027275:	je     10272dd <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1cd>
 1027277:	and    $0xf,%al
 1027279:	movzbl %al,%ecx
 102727c:	lea    -0x30(%rbp),%rsi
 1027280:	mov    -0x48(%rbp),%rdi
 1027284:	mov    %r14,%rdx
 1027287:	xor    %r8d,%r8d
 102728a:	xor    %r9d,%r9d
 102728d:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1027292:	test   %rax,%rax
 1027295:	je     10272dd <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1cd>
 1027297:	mov    %r15,-0x30(%rbp)
 102729b:	mov    0x10(%rbp),%rax
 102729f:	movzbl 0x19(%rax),%ecx
 10272a3:	lea    -0x30(%rbp),%rsi
 10272a7:	mov    -0x48(%rbp),%rdi
 10272ab:	mov    %r14,%rdx
 10272ae:	xor    %r8d,%r8d
 10272b1:	xor    %r9d,%r9d
 10272b4:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 10272b9:	mov    -0x38(%rbp),%rcx
 10272bd:	mov    %rax,0x28(%rcx)
 10272c1:	mov    %rcx,%rax
 10272c4:	jmp    10272e1 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1d1>
 10272c6:	xor    %eax,%eax
 10272c8:	add    $0x28,%rsp
 10272cc:	pop    %rbx
 10272cd:	pop    %r12
 10272cf:	pop    %r13
 10272d1:	pop    %r14
 10272d3:	pop    %r15
 10272d5:	pop    %rbp
 10272d6:	ret
 10272d7:	mov    -0x30(%rbp),%r13
 10272db:	jmp    10272e5 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1d5>
 10272dd:	mov    -0x38(%rbp),%rax
 10272e1:	mov    -0x40(%rbp),%rcx
 10272e5:	mov    %rbx,(%rax)
 10272e8:	sub    %rbx,%r14
 10272eb:	mov    %r14,0x8(%rax)
 10272ef:	mov    %r13,0x10(%rax)
 10272f3:	mov    %rcx,0x18(%rax)
 10272f7:	mov    %r12,0x20(%rax)
 10272fb:	mov    $0x1,%al
 10272fd:	jmp    10272c8 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmmmPNS2_8FDE_InfoEPNS2_8CIE_InfoE+0x1b8>
 10272ff:	int3

0000000001027300 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE>:
 1027300:	push   %rbp
 1027301:	mov    %rsp,%rbp
 1027304:	push   %r15
 1027306:	push   %r14
 1027308:	push   %r13
 102730a:	push   %r12
 102730c:	push   %rbx
 102730d:	sub    $0x68,%rsp
 1027311:	mov    %r9,%r14
 1027314:	mov    %r8,%rbx
 1027317:	mov    %rsi,-0x40(%rbp)
 102731b:	mov    %ecx,%eax
 102731d:	add    %rdx,%rax
 1027320:	lea    -0x88(%rbp),%rcx
 1027327:	mov    %rdi,-0x58(%rbp)
 102732b:	mov    %rdx,-0x50(%rbp)
 102732f:	mov    %rdx,%rsi
 1027332:	mov    %rax,-0x48(%rbp)
 1027336:	mov    %rax,%rdx
 1027339:	call   1026ef0 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE11decodeEHHdrERS1_mmRNS2_12EHHeaderInfoE>
 102733e:	test   %al,%al
 1027340:	je     1027448 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x148>
 1027346:	cmpq   $0x0,-0x80(%rbp)
 102734b:	je     1027448 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x148>
 1027351:	mov    %r14,-0x60(%rbp)
 1027355:	mov    %rbx,-0x68(%rbp)
 1027359:	movzbl -0x70(%rbp),%edi
 102735d:	call   1027460 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh>
 1027362:	mov    %rax,-0x38(%rbp)
 1027366:	xor    %r13d,%r13d
 1027369:	mov    -0x80(%rbp),%r12
 102736d:	nopl   (%rax)
 1027370:	cmp    $0x1,%r12
 1027374:	jbe    10273c5 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0xc5>
 1027376:	mov    %r12,%rbx
 1027379:	shr    $1,%rbx
 102737c:	lea    (%rbx,%r13,1),%r15
 1027380:	mov    %r15,%r14
 1027383:	imul   -0x38(%rbp),%r14
 1027388:	mov    -0x78(%rbp),%rax
 102738c:	add    %r14,%rax
 102738f:	mov    %rax,-0x30(%rbp)
 1027393:	movzbl -0x70(%rbp),%ecx
 1027397:	mov    -0x58(%rbp),%rdi
 102739b:	lea    -0x30(%rbp),%rsi
 102739f:	mov    -0x48(%rbp),%rdx
 10273a3:	mov    -0x50(%rbp),%r8
 10273a7:	xor    %r9d,%r9d
 10273aa:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 10273af:	sub    %rbx,%r12
 10273b2:	mov    -0x40(%rbp),%rcx
 10273b6:	cmp    (%rcx),%rax
 10273b9:	cmovb  %r15,%r13
 10273bd:	cmovae %rbx,%r12
 10273c1:	jne    1027370 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x70>
 10273c3:	jmp    10273cd <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0xcd>
 10273c5:	imul   -0x38(%rbp),%r13
 10273ca:	mov    %r13,%r14
 10273cd:	add    -0x78(%rbp),%r14
 10273d1:	mov    %r14,-0x30(%rbp)
 10273d5:	movzbl -0x70(%rbp),%ebx
 10273d9:	lea    -0x30(%rbp),%r13
 10273dd:	mov    -0x58(%rbp),%r14
 10273e1:	mov    %r14,%rdi
 10273e4:	mov    %r13,%rsi
 10273e7:	mov    -0x48(%rbp),%r12
 10273eb:	mov    %r12,%rdx
 10273ee:	mov    %ebx,%ecx
 10273f0:	mov    -0x50(%rbp),%r15
 10273f4:	mov    %r15,%r8
 10273f7:	xor    %r9d,%r9d
 10273fa:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 10273ff:	mov    %r14,%rdi
 1027402:	mov    %r13,%rsi
 1027405:	mov    %r12,%rdx
 1027408:	mov    %ebx,%ecx
 102740a:	mov    %r15,%r8
 102740d:	xor    %r9d,%r9d
 1027410:	call   1025fb0 <_ZN9libunwind17LocalAddressSpace11getEncodedPERmmhmPm>
 1027415:	mov    %r14,%rdi
 1027418:	mov    %rax,%rsi
 102741b:	mov    -0x68(%rbp),%rbx
 102741f:	mov    %rbx,%rdx
 1027422:	mov    -0x60(%rbp),%rcx
 1027426:	xor    %r8d,%r8d
 1027429:	call   10243e0 <_ZN9libunwind10CFI_ParserINS_17LocalAddressSpaceEE9decodeFDEERS1_mPNS2_8FDE_InfoEPNS2_8CIE_InfoEb>
 102742e:	test   %rax,%rax
 1027431:	jne    1027448 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x148>
 1027433:	mov    -0x40(%rbp),%rax
 1027437:	mov    (%rax),%rcx
 102743a:	cmp    0x18(%rbx),%rcx
 102743e:	jb     1027448 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x148>
 1027440:	mov    $0x1,%al
 1027442:	cmp    0x20(%rbx),%rcx
 1027446:	jb     102744a <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE7findFDEINS_16Registers_x86_64EEEbRS1_NT_23link_hardened_reg_arg_tEmjPNS_10CFI_ParserIS1_E8FDE_InfoEPNS9_8CIE_InfoE+0x14a>
 1027448:	xor    %eax,%eax
 102744a:	add    $0x68,%rsp
 102744e:	pop    %rbx
 102744f:	pop    %r12
 1027451:	pop    %r13
 1027453:	pop    %r14
 1027455:	pop    %r15
 1027457:	pop    %rbp
 1027458:	ret
 1027459:	int3
 102745a:	int3
 102745b:	int3
 102745c:	int3
 102745d:	int3
 102745e:	int3
 102745f:	int3

0000000001027460 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh>:
 1027460:	push   %rbp
 1027461:	mov    %rsp,%rbp
 1027464:	push   %rbx
 1027465:	push   %rax
 1027466:	and    $0xf,%edi
 1027469:	dec    %edi
 102746b:	cmp    $0xb,%edi
 102746e:	ja     10274bb <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh+0x5b>
 1027470:	lea    -0x1b257(%rip),%rax        # 100c220 <raw_shape+0x720>
 1027477:	movslq (%rax,%rdi,4),%rcx
 102747b:	add    %rax,%rcx
 102747e:	jmp    *%rcx
 1027480:	mov    $0x4,%eax
 1027485:	jmp    1027493 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh+0x33>
 1027487:	mov    $0x10,%eax
 102748c:	jmp    1027493 <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh+0x33>
 102748e:	mov    $0x8,%eax
 1027493:	add    $0x8,%rsp
 1027497:	pop    %rbx
 1027498:	pop    %rbp
 1027499:	ret
 102749a:	mov    0x1877(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 10274a1:	mov    (%rbx),%rdi
 10274a4:	lea    -0x22be0(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10274ab:	lea    -0x23407(%rip),%rdx        # 10040ab <qbe_empty_registry+0x553>
 10274b2:	lea    -0x22e8a(%rip),%rcx        # 100462f <qbe_empty_registry+0xad7>
 10274b9:	jmp    10274da <_ZN9libunwind14EHHeaderParserINS_17LocalAddressSpaceEE17getTableEntrySizeEh+0x7a>
 10274bb:	mov    0x1856(%rip),%rbx        # 1028d18 <stderr@GLIBC_2.2.5>
 10274c2:	mov    (%rbx),%rdi
 10274c5:	lea    -0x22c01(%rip),%rsi        # 10048cb <qbe_empty_registry+0xd73>
 10274cc:	lea    -0x23428(%rip),%rdx        # 10040ab <qbe_empty_registry+0x553>
 10274d3:	lea    -0x22ed4(%rip),%rcx        # 1004606 <qbe_empty_registry+0xaae>
 10274da:	xor    %eax,%eax
 10274dc:	call   1027760 <fprintf@plt>
 10274e1:	mov    (%rbx),%rdi
 10274e4:	call   1027800 <fflush@plt>
 10274e9:	call   1027810 <abort@plt>
 10274ee:	int3
 10274ef:	int3

00000000010274f0 <_Unwind_Backtrace>:
 10274f0:	push   %rbp
 10274f1:	mov    %rsp,%rbp
 10274f4:	push   %r15
 10274f6:	push   %r14
 10274f8:	push   %r12
 10274fa:	push   %rbx
 10274fb:	sub    $0x1b0,%rsp
 1027502:	mov    %rsi,%rbx
 1027505:	mov    %rdi,%r14
 1027508:	lea    -0xc8(%rbp),%r12
 102750f:	mov    %r12,%rdi
 1027512:	call   10275c0 <__unw_getcontext>
 1027517:	lea    -0x1d0(%rbp),%r15
 102751e:	mov    %r15,%rdi
 1027521:	mov    %r12,%rsi
 1027524:	call   1024300 <__unw_init_local>
 1027529:	nopl   0x0(%rax)
 1027530:	mov    %r15,%rdi
 1027533:	call   10243d0 <__unw_step>
 1027538:	test   %eax,%eax
 102753a:	jle    102754b <_Unwind_Backtrace+0x5b>
 102753c:	mov    %r15,%rdi
 102753f:	mov    %rbx,%rsi
 1027542:	call   *%r14
 1027545:	test   %eax,%eax
 1027547:	je     1027530 <_Unwind_Backtrace+0x40>
 1027549:	jmp    1027550 <_Unwind_Backtrace+0x60>
 102754b:	mov    $0x5,%eax
 1027550:	add    $0x1b0,%rsp
 1027557:	pop    %rbx
 1027558:	pop    %r12
 102755a:	pop    %r14
 102755c:	pop    %r15
 102755e:	pop    %rbp
 102755f:	ret

0000000001027560 <__libunwind_Registers_x86_64_jumpto>:
 1027560:	mov    0x38(%rdi),%rax
 1027564:	sub    $0x10,%rax
 1027568:	mov    %rax,0x38(%rdi)
 102756c:	mov    0x20(%rdi),%rbx
 1027570:	mov    %rbx,(%rax)
 1027573:	mov    0x80(%rdi),%rbx
 102757a:	mov    %rbx,0x8(%rax)
 102757e:	mov    (%rdi),%rax
 1027581:	mov    0x8(%rdi),%rbx
 1027585:	mov    0x10(%rdi),%rcx
 1027589:	mov    0x18(%rdi),%rdx
 102758d:	mov    0x28(%rdi),%rsi
 1027591:	mov    0x30(%rdi),%rbp
 1027595:	mov    0x40(%rdi),%r8
 1027599:	mov    0x48(%rdi),%r9
 102759d:	mov    0x50(%rdi),%r10
 10275a1:	mov    0x58(%rdi),%r11
 10275a5:	mov    0x60(%rdi),%r12
 10275a9:	mov    0x68(%rdi),%r13
 10275ad:	mov    0x70(%rdi),%r14
 10275b1:	mov    0x78(%rdi),%r15
 10275b5:	mov    0x38(%rdi),%rsp
 10275b9:	pop    %rdi
 10275ba:	pop    %rcx
 10275bb:	jmp    *%rcx
 10275bd:	int3
 10275be:	int3
 10275bf:	int3

00000000010275c0 <__unw_getcontext>:
 10275c0:	mov    %rax,(%rdi)
 10275c3:	mov    %rbx,0x8(%rdi)
 10275c7:	mov    %rcx,0x10(%rdi)
 10275cb:	mov    %rdx,0x18(%rdi)
 10275cf:	mov    %rdi,0x20(%rdi)
 10275d3:	mov    %rsi,0x28(%rdi)
 10275d7:	mov    %rbp,0x30(%rdi)
 10275db:	mov    %rsp,0x38(%rdi)
 10275df:	addq   $0x8,0x38(%rdi)
 10275e4:	mov    %r8,0x40(%rdi)
 10275e8:	mov    %r9,0x48(%rdi)
 10275ec:	mov    %r10,0x50(%rdi)
 10275f0:	mov    %r11,0x58(%rdi)
 10275f4:	mov    %r12,0x60(%rdi)
 10275f8:	mov    %r13,0x68(%rdi)
 10275fc:	mov    %r14,0x70(%rdi)
 1027600:	mov    %r15,0x78(%rdi)
 1027604:	mov    (%rsp),%rsi
 1027608:	mov    %rsi,0x80(%rdi)
 102760f:	xor    %eax,%eax
 1027611:	ret

Disassembly of section .init:

0000000001027614 <_init>:
 1027614:	endbr64
 1027618:	sub    $0x8,%rsp
 102761c:	mov    0x16ed(%rip),%rax        # 1028d10 <__gmon_start__>
 1027623:	test   %rax,%rax
 1027626:	je     102762a <_init+0x16>
 1027628:	call   *%rax
 102762a:	add    $0x8,%rsp
 102762e:	ret

Disassembly of section .fini:

0000000001027630 <_fini>:
 1027630:	endbr64
 1027634:	sub    $0x8,%rsp
 1027638:	add    $0x8,%rsp
 102763c:	ret

Disassembly of section .plt:

0000000001027640 <memset@plt-0x10>:
 1027640:	push   0x16f2(%rip)        # 1028d38 <_GLOBAL_OFFSET_TABLE_+0x8>
 1027646:	jmp    *0x16f4(%rip)        # 1028d40 <_GLOBAL_OFFSET_TABLE_+0x10>
 102764c:	nopl   0x0(%rax)

0000000001027650 <memset@plt>:
 1027650:	jmp    *0x16f2(%rip)        # 1028d48 <memset@GLIBC_2.2.5>
 1027656:	push   $0x0
 102765b:	jmp    1027640 <_fini+0x10>

0000000001027660 <getenv@plt>:
 1027660:	jmp    *0x16ea(%rip)        # 1028d50 <getenv@GLIBC_2.2.5>
 1027666:	push   $0x1
 102766b:	jmp    1027640 <_fini+0x10>

0000000001027670 <strlen@plt>:
 1027670:	jmp    *0x16e2(%rip)        # 1028d58 <strlen@GLIBC_2.2.5>
 1027676:	push   $0x2
 102767b:	jmp    1027640 <_fini+0x10>

0000000001027680 <malloc@plt>:
 1027680:	jmp    *0x16da(%rip)        # 1028d60 <malloc@GLIBC_2.2.5>
 1027686:	push   $0x3
 102768b:	jmp    1027640 <_fini+0x10>

0000000001027690 <calloc@plt>:
 1027690:	jmp    *0x16d2(%rip)        # 1028d68 <calloc@GLIBC_2.2.5>
 1027696:	push   $0x4
 102769b:	jmp    1027640 <_fini+0x10>

00000000010276a0 <memcpy@plt>:
 10276a0:	jmp    *0x16ca(%rip)        # 1028d70 <memcpy@GLIBC_2.14>
 10276a6:	push   $0x5
 10276ab:	jmp    1027640 <_fini+0x10>

00000000010276b0 <open@plt>:
 10276b0:	jmp    *0x16c2(%rip)        # 1028d78 <open@GLIBC_2.2.5>
 10276b6:	push   $0x6
 10276bb:	jmp    1027640 <_fini+0x10>

00000000010276c0 <strcmp@plt>:
 10276c0:	jmp    *0x16ba(%rip)        # 1028d80 <strcmp@GLIBC_2.2.5>
 10276c6:	push   $0x7
 10276cb:	jmp    1027640 <_fini+0x10>

00000000010276d0 <strncmp@plt>:
 10276d0:	jmp    *0x16b2(%rip)        # 1028d88 <strncmp@GLIBC_2.2.5>
 10276d6:	push   $0x8
 10276db:	jmp    1027640 <_fini+0x10>

00000000010276e0 <strtoull@plt>:
 10276e0:	jmp    *0x16aa(%rip)        # 1028d90 <strtoull@GLIBC_2.2.5>
 10276e6:	push   $0x9
 10276eb:	jmp    1027640 <_fini+0x10>

00000000010276f0 <free@plt>:
 10276f0:	jmp    *0x16a2(%rip)        # 1028d98 <free@GLIBC_2.2.5>
 10276f6:	push   $0xa
 10276fb:	jmp    1027640 <_fini+0x10>

0000000001027700 <clock_gettime@plt>:
 1027700:	jmp    *0x169a(%rip)        # 1028da0 <clock_gettime@GLIBC_2.17>
 1027706:	push   $0xb
 102770b:	jmp    1027640 <_fini+0x10>

0000000001027710 <sigemptyset@plt>:
 1027710:	jmp    *0x1692(%rip)        # 1028da8 <sigemptyset@GLIBC_2.2.5>
 1027716:	push   $0xc
 102771b:	jmp    1027640 <_fini+0x10>

0000000001027720 <sigaction@plt>:
 1027720:	jmp    *0x168a(%rip)        # 1028db0 <sigaction@GLIBC_2.2.5>
 1027726:	push   $0xd
 102772b:	jmp    1027640 <_fini+0x10>

0000000001027730 <timer_create@plt>:
 1027730:	jmp    *0x1682(%rip)        # 1028db8 <timer_create@GLIBC_2.34>
 1027736:	push   $0xe
 102773b:	jmp    1027640 <_fini+0x10>

0000000001027740 <timer_settime@plt>:
 1027740:	jmp    *0x167a(%rip)        # 1028dc0 <timer_settime@GLIBC_2.34>
 1027746:	push   $0xf
 102774b:	jmp    1027640 <_fini+0x10>

0000000001027750 <fwrite@plt>:
 1027750:	jmp    *0x1672(%rip)        # 1028dc8 <fwrite@GLIBC_2.2.5>
 1027756:	push   $0x10
 102775b:	jmp    1027640 <_fini+0x10>

0000000001027760 <fprintf@plt>:
 1027760:	jmp    *0x166a(%rip)        # 1028dd0 <fprintf@GLIBC_2.2.5>
 1027766:	push   $0x11
 102776b:	jmp    1027640 <_fini+0x10>

0000000001027770 <unsetenv@plt>:
 1027770:	jmp    *0x1662(%rip)        # 1028dd8 <unsetenv@GLIBC_2.2.5>
 1027776:	push   $0x12
 102777b:	jmp    1027640 <_fini+0x10>

0000000001027780 <getrlimit@plt>:
 1027780:	jmp    *0x165a(%rip)        # 1028de0 <getrlimit@GLIBC_2.2.5>
 1027786:	push   $0x13
 102778b:	jmp    1027640 <_fini+0x10>

0000000001027790 <setrlimit@plt>:
 1027790:	jmp    *0x1652(%rip)        # 1028de8 <setrlimit@GLIBC_2.2.5>
 1027796:	push   $0x14
 102779b:	jmp    1027640 <_fini+0x10>

00000000010277a0 <fegetround@plt>:
 10277a0:	jmp    *0x164a(%rip)        # 1028df0 <fegetround@GLIBC_2.2.5>
 10277a6:	push   $0x15
 10277ab:	jmp    1027640 <_fini+0x10>

00000000010277b0 <printf@plt>:
 10277b0:	jmp    *0x1642(%rip)        # 1028df8 <printf@GLIBC_2.2.5>
 10277b6:	push   $0x16
 10277bb:	jmp    1027640 <_fini+0x10>

00000000010277c0 <close@plt>:
 10277c0:	jmp    *0x163a(%rip)        # 1028e00 <close@GLIBC_2.2.5>
 10277c6:	push   $0x17
 10277cb:	jmp    1027640 <_fini+0x10>

00000000010277d0 <sqrt@plt>:
 10277d0:	jmp    *0x1632(%rip)        # 1028e08 <sqrt@GLIBC_2.2.5>
 10277d6:	push   $0x18
 10277db:	jmp    1027640 <_fini+0x10>

00000000010277e0 <snprintf@plt>:
 10277e0:	jmp    *0x162a(%rip)        # 1028e10 <snprintf@GLIBC_2.2.5>
 10277e6:	push   $0x19
 10277eb:	jmp    1027640 <_fini+0x10>

00000000010277f0 <realloc@plt>:
 10277f0:	jmp    *0x1622(%rip)        # 1028e18 <realloc@GLIBC_2.2.5>
 10277f6:	push   $0x1a
 10277fb:	jmp    1027640 <_fini+0x10>

0000000001027800 <fflush@plt>:
 1027800:	jmp    *0x161a(%rip)        # 1028e20 <fflush@GLIBC_2.2.5>
 1027806:	push   $0x1b
 102780b:	jmp    1027640 <_fini+0x10>

0000000001027810 <abort@plt>:
 1027810:	jmp    *0x1612(%rip)        # 1028e28 <abort@GLIBC_2.2.5>
 1027816:	push   $0x1c
 102781b:	jmp    1027640 <_fini+0x10>

0000000001027820 <longjmp@plt>:
 1027820:	jmp    *0x160a(%rip)        # 1028e30 <longjmp@GLIBC_2.2.5>
 1027826:	push   $0x1d
 102782b:	jmp    1027640 <_fini+0x10>

0000000001027830 <qsort@plt>:
 1027830:	jmp    *0x1602(%rip)        # 1028e38 <qsort@GLIBC_2.2.5>
 1027836:	push   $0x1e
 102783b:	jmp    1027640 <_fini+0x10>

0000000001027840 <write@plt>:
 1027840:	jmp    *0x15fa(%rip)        # 1028e40 <write@GLIBC_2.2.5>
 1027846:	push   $0x1f
 102784b:	jmp    1027640 <_fini+0x10>

0000000001027850 <_exit@plt>:
 1027850:	jmp    *0x15f2(%rip)        # 1028e48 <_exit@GLIBC_2.2.5>
 1027856:	push   $0x20
 102785b:	jmp    1027640 <_fini+0x10>

0000000001027860 <vsnprintf@plt>:
 1027860:	jmp    *0x15ea(%rip)        # 1028e50 <vsnprintf@GLIBC_2.2.5>
 1027866:	push   $0x21
 102786b:	jmp    1027640 <_fini+0x10>

0000000001027870 <bcmp@plt>:
 1027870:	jmp    *0x15e2(%rip)        # 1028e58 <bcmp@GLIBC_2.2.5>
 1027876:	push   $0x22
 102787b:	jmp    1027640 <_fini+0x10>

0000000001027880 <memmove@plt>:
 1027880:	jmp    *0x15da(%rip)        # 1028e60 <memmove@GLIBC_2.2.5>
 1027886:	push   $0x23
 102788b:	jmp    1027640 <_fini+0x10>

0000000001027890 <sysconf@plt>:
 1027890:	jmp    *0x15d2(%rip)        # 1028e68 <sysconf@GLIBC_2.2.5>
 1027896:	push   $0x24
 102789b:	jmp    1027640 <_fini+0x10>

00000000010278a0 <mmap@plt>:
 10278a0:	jmp    *0x15ca(%rip)        # 1028e70 <mmap@GLIBC_2.2.5>
 10278a6:	push   $0x25
 10278ab:	jmp    1027640 <_fini+0x10>

00000000010278b0 <mprotect@plt>:
 10278b0:	jmp    *0x15c2(%rip)        # 1028e78 <mprotect@GLIBC_2.2.5>
 10278b6:	push   $0x26
 10278bb:	jmp    1027640 <_fini+0x10>

00000000010278c0 <getcontext@plt>:
 10278c0:	jmp    *0x15ba(%rip)        # 1028e80 <getcontext@GLIBC_2.2.5>
 10278c6:	push   $0x27
 10278cb:	jmp    1027640 <_fini+0x10>

00000000010278d0 <makecontext@plt>:
 10278d0:	jmp    *0x15b2(%rip)        # 1028e88 <makecontext@GLIBC_2.2.5>
 10278d6:	push   $0x28
 10278db:	jmp    1027640 <_fini+0x10>

00000000010278e0 <swapcontext@plt>:
 10278e0:	jmp    *0x15aa(%rip)        # 1028e90 <swapcontext@GLIBC_2.2.5>
 10278e6:	push   $0x29
 10278eb:	jmp    1027640 <_fini+0x10>

00000000010278f0 <munmap@plt>:
 10278f0:	jmp    *0x15a2(%rip)        # 1028e98 <munmap@GLIBC_2.2.5>
 10278f6:	push   $0x2a
 10278fb:	jmp    1027640 <_fini+0x10>

0000000001027900 <_setjmp@plt>:
 1027900:	jmp    *0x159a(%rip)        # 1028ea0 <_setjmp@GLIBC_2.2.5>
 1027906:	push   $0x2b
 102790b:	jmp    1027640 <_fini+0x10>

0000000001027910 <strchr@plt>:
 1027910:	jmp    *0x1592(%rip)        # 1028ea8 <strchr@GLIBC_2.2.5>
 1027916:	push   $0x2c
 102791b:	jmp    1027640 <_fini+0x10>

0000000001027920 <strrchr@plt>:
 1027920:	jmp    *0x158a(%rip)        # 1028eb0 <strrchr@GLIBC_2.2.5>
 1027926:	push   $0x2d
 102792b:	jmp    1027640 <_fini+0x10>

0000000001027930 <strtoul@plt>:
 1027930:	jmp    *0x1582(%rip)        # 1028eb8 <strtoul@GLIBC_2.2.5>
 1027936:	push   $0x2e
 102793b:	jmp    1027640 <_fini+0x10>

0000000001027940 <inet_pton@plt>:
 1027940:	jmp    *0x157a(%rip)        # 1028ec0 <inet_pton@GLIBC_2.2.5>
 1027946:	push   $0x2f
 102794b:	jmp    1027640 <_fini+0x10>

0000000001027950 <socket@plt>:
 1027950:	jmp    *0x1572(%rip)        # 1028ec8 <socket@GLIBC_2.2.5>
 1027956:	push   $0x30
 102795b:	jmp    1027640 <_fini+0x10>

0000000001027960 <connect@plt>:
 1027960:	jmp    *0x156a(%rip)        # 1028ed0 <connect@GLIBC_2.2.5>
 1027966:	push   $0x31
 102796b:	jmp    1027640 <_fini+0x10>

0000000001027970 <read@plt>:
 1027970:	jmp    *0x1562(%rip)        # 1028ed8 <read@GLIBC_2.2.5>
 1027976:	push   $0x32
 102797b:	jmp    1027640 <_fini+0x10>

0000000001027980 <__errno_location@plt>:
 1027980:	jmp    *0x155a(%rip)        # 1028ee0 <__errno_location@GLIBC_2.2.5>
 1027986:	push   $0x33
 102798b:	jmp    1027640 <_fini+0x10>

0000000001027990 <lseek@plt>:
 1027990:	jmp    *0x1552(%rip)        # 1028ee8 <lseek@GLIBC_2.2.5>
 1027996:	push   $0x34
 102799b:	jmp    1027640 <_fini+0x10>

00000000010279a0 <pwrite@plt>:
 10279a0:	jmp    *0x154a(%rip)        # 1028ef0 <pwrite@GLIBC_2.2.5>
 10279a6:	push   $0x35
 10279ab:	jmp    1027640 <_fini+0x10>

00000000010279b0 <openat@plt>:
 10279b0:	jmp    *0x1542(%rip)        # 1028ef8 <openat@GLIBC_2.4>
 10279b6:	push   $0x36
 10279bb:	jmp    1027640 <_fini+0x10>

00000000010279c0 <memchr@plt>:
 10279c0:	jmp    *0x153a(%rip)        # 1028f00 <memchr@GLIBC_2.2.5>
 10279c6:	push   $0x37
 10279cb:	jmp    1027640 <_fini+0x10>

00000000010279d0 <fstatat@plt>:
 10279d0:	jmp    *0x1532(%rip)        # 1028f08 <fstatat@GLIBC_2.33>
 10279d6:	push   $0x38
 10279db:	jmp    1027640 <_fini+0x10>

00000000010279e0 <mkdirat@plt>:
 10279e0:	jmp    *0x152a(%rip)        # 1028f10 <mkdirat@GLIBC_2.4>
 10279e6:	push   $0x39
 10279eb:	jmp    1027640 <_fini+0x10>

00000000010279f0 <fdopendir@plt>:
 10279f0:	jmp    *0x1522(%rip)        # 1028f18 <fdopendir@GLIBC_2.4>
 10279f6:	push   $0x3a
 10279fb:	jmp    1027640 <_fini+0x10>

0000000001027a00 <readdir@plt>:
 1027a00:	jmp    *0x151a(%rip)        # 1028f20 <readdir@GLIBC_2.2.5>
 1027a06:	push   $0x3b
 1027a0b:	jmp    1027640 <_fini+0x10>

0000000001027a10 <dirfd@plt>:
 1027a10:	jmp    *0x1512(%rip)        # 1028f28 <dirfd@GLIBC_2.2.5>
 1027a16:	push   $0x3c
 1027a1b:	jmp    1027640 <_fini+0x10>

0000000001027a20 <fstat@plt>:
 1027a20:	jmp    *0x150a(%rip)        # 1028f30 <fstat@GLIBC_2.33>
 1027a26:	push   $0x3d
 1027a2b:	jmp    1027640 <_fini+0x10>

0000000001027a30 <unlinkat@plt>:
 1027a30:	jmp    *0x1502(%rip)        # 1028f38 <unlinkat@GLIBC_2.4>
 1027a36:	push   $0x3e
 1027a3b:	jmp    1027640 <_fini+0x10>

0000000001027a40 <ftruncate@plt>:
 1027a40:	jmp    *0x14fa(%rip)        # 1028f40 <ftruncate@GLIBC_2.2.5>
 1027a46:	push   $0x3f
 1027a4b:	jmp    1027640 <_fini+0x10>

0000000001027a50 <closedir@plt>:
 1027a50:	jmp    *0x14f2(%rip)        # 1028f48 <closedir@GLIBC_2.2.5>
 1027a56:	push   $0x40
 1027a5b:	jmp    1027640 <_fini+0x10>

0000000001027a60 <fcntl@plt>:
 1027a60:	jmp    *0x14ea(%rip)        # 1028f50 <fcntl@GLIBC_2.2.5>
 1027a66:	push   $0x41
 1027a6b:	jmp    1027640 <_fini+0x10>

0000000001027a70 <madvise@plt>:
 1027a70:	jmp    *0x14e2(%rip)        # 1028f58 <madvise@GLIBC_2.2.5>
 1027a76:	push   $0x42
 1027a7b:	jmp    1027640 <_fini+0x10>

0000000001027a80 <mremap@plt>:
 1027a80:	jmp    *0x14da(%rip)        # 1028f60 <mremap@GLIBC_2.2.5>
 1027a86:	push   $0x43
 1027a8b:	jmp    1027640 <_fini+0x10>

0000000001027a90 <pthread_rwlock_wrlock@plt>:
 1027a90:	jmp    *0x14d2(%rip)        # 1028f68 <pthread_rwlock_wrlock@GLIBC_2.34>
 1027a96:	push   $0x44
 1027a9b:	jmp    1027640 <_fini+0x10>

0000000001027aa0 <pthread_rwlock_unlock@plt>:
 1027aa0:	jmp    *0x14ca(%rip)        # 1028f70 <pthread_rwlock_unlock@GLIBC_2.34>
 1027aa6:	push   $0x45
 1027aab:	jmp    1027640 <_fini+0x10>

0000000001027ab0 <dladdr@plt>:
 1027ab0:	jmp    *0x14c2(%rip)        # 1028f78 <dladdr@GLIBC_2.34>
 1027ab6:	push   $0x46
 1027abb:	jmp    1027640 <_fini+0x10>

0000000001027ac0 <dlsym@plt>:
 1027ac0:	jmp    *0x14ba(%rip)        # 1028f80 <dlsym@GLIBC_2.34>
 1027ac6:	push   $0x47
 1027acb:	jmp    1027640 <_fini+0x10>

0000000001027ad0 <dl_iterate_phdr@plt>:
 1027ad0:	jmp    *0x14b2(%rip)        # 1028f88 <dl_iterate_phdr@GLIBC_2.2.5>
 1027ad6:	push   $0x48
 1027adb:	jmp    1027640 <_fini+0x10>

0000000001027ae0 <pthread_rwlock_rdlock@plt>:
 1027ae0:	jmp    *0x14aa(%rip)        # 1028f90 <pthread_rwlock_rdlock@GLIBC_2.34>
 1027ae6:	push   $0x49
 1027aeb:	jmp    1027640 <_fini+0x10>
