
/home/epentland/ai/canopy/mylang-worktrees/codex-next-runtime-cold-fail-20260930/.tmp/cold-fail/raytrace.qbe:     file format elf64-x86-64


Disassembly of section .text:

0000000001007a40 <_start>:
 1007a40:	endbr64
 1007a44:	xor    %ebp,%ebp
 1007a46:	mov    %rdx,%r9
 1007a49:	pop    %rsi
 1007a4a:	mov    %rsp,%rdx
 1007a4d:	and    $0xfffffffffffffff0,%rsp
 1007a51:	push   %rax
 1007a52:	push   %rsp
 1007a53:	xor    %r8d,%r8d
 1007a56:	xor    %ecx,%ecx
 1007a58:	lea    0x35d1(%rip),%rdi        # 100b030 <main>
 1007a5f:	call   *0x21af3(%rip)        # 1029558 <__libc_start_main@GLIBC_2.34>
 1007a65:	hlt
 1007a66:	cs nopw 0x0(%rax,%rax,1)

0000000001007a70 <_dl_relocate_static_pie>:
 1007a70:	endbr64
 1007a74:	ret
 1007a75:	int3
 1007a76:	int3
 1007a77:	int3
 1007a78:	int3
 1007a79:	int3
 1007a7a:	int3
 1007a7b:	int3
 1007a7c:	int3
 1007a7d:	int3
 1007a7e:	int3
 1007a7f:	int3

0000000001007a80 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>:
 1007a80:	endbr64
 1007a84:	push   %rbp
 1007a85:	mov    %rsp,%rbp
 1007a88:	sub    $0x448,%rsp
 1007a8f:	push   %rbx
 1007a90:	push   %r12
 1007a92:	push   %r13
 1007a94:	push   %r14
 1007a96:	push   %r15
 1007a98:	mov    %rsi,-0x48(%rbp)
 1007a9c:	mov    0x40(%rdi),%rax
 1007aa0:	lea    -0x58(%rbp),%rcx
 1007aa4:	cmp    %rax,%rcx
 1007aa7:	setb   %al
 1007aaa:	movzbq %al,%rax
 1007aae:	mov    $0x2,%ecx
 1007ab3:	mov    %ecx,-0x24(%rbp)
 1007ab6:	cmp    $0x10,%ecx
 1007ab9:	sete   %dl
 1007abc:	movzbl %dl,%edx
 1007abf:	mov    %edx,-0x10(%rbp)
 1007ac2:	mov    $0x0,%edx
 1007ac7:	mov    %edx,-0x28(%rbp)
 1007aca:	cmp    $0x0,%eax
 1007acd:	jne    1009a87 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x2007>
 1007ad3:	movq   $0x0,-0x370(%rbp)
 1007ade:	movq   $0x0,-0x368(%rbp)
 1007ae9:	mov    %rdi,%rbx
 1007aec:	call   100ba30 <myl_qbe_heap>
 1007af1:	mov    %rbx,%rdi
 1007af4:	mov    %rax,%rbx
 1007af7:	mov    %rbx,-0x50(%rbp)
 1007afb:	mov    %rdi,%r12
 1007afe:	call   100d960 <myl_qbe_region_mark>
 1007b03:	mov    %r12,%rdi
 1007b06:	mov    %rax,%r13
 1007b09:	movl   $0x0,-0x3f0(%rbp)
 1007b13:	mov    %rdi,%r12
 1007b16:	call   100bbe0 <myl_qbe_require_step_accounting>
 1007b1b:	mov    %r12,%rdi
 1007b1e:	mov    %rdi,%r12
 1007b21:	call   100bc30 <myl_qbe_require_frame_accounting>
 1007b26:	mov    %r12,%rdi
 1007b29:	mov    $0x6,%edx
 1007b2e:	lea    0x1ef0b(%rip),%rsi        # 1026a40 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf>
 1007b35:	mov    %rdi,%r12
 1007b38:	mov    %rbx,%rdi
 1007b3b:	call   10117a0 <myl_native_list_new>
 1007b40:	mov    %r13,%rcx
 1007b43:	mov    %r12,%rdi
 1007b46:	cmp    $0x0,%eax
 1007b49:	jne    1007b55 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd5>
 1007b4b:	mov    %rdi,%rbx
 1007b4e:	call   100b780 <myl_qbe_fail_allocation>
 1007b53:	ud2
 1007b55:	xchg   %rdi,%rbx
 1007b58:	mov    %rax,-0x3b0(%rbp)
 1007b5f:	mov    -0x3b0(%rbp),%rdx
 1007b66:	mov    %rdx,-0x3a8(%rbp)
 1007b6d:	mov    -0x3a8(%rbp),%rdx
 1007b74:	mov    %rdx,-0x3e8(%rbp)
 1007b7b:	mov    %rax,-0x3b0(%rbp)
 1007b82:	lea    -0x3a8(%rbp),%rsi
 1007b89:	lea    -0x3b0(%rbp),%rdx
 1007b90:	neg    %rsi
 1007b93:	add    %rdx,%rsi
 1007b96:	lea    -0x3b0(%rbp),%r8
 1007b9d:	lea    -0x3a8(%rbp),%rdx
 1007ba4:	sub    %r8,%rdx
 1007ba7:	cmp    $0x8,%rsi
 1007bab:	setb   %r12b
 1007baf:	movzbl %r12b,%r12d
 1007bb3:	cmp    $0x8,%rdx
 1007bb7:	setb   %r13b
 1007bbb:	movzbl %r13b,%r13d
 1007bbf:	mov    %r12d,%edx
 1007bc2:	or     %r13d,%edx
 1007bc5:	jne    1007c05 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x185>
 1007bc7:	cmp    $0x0,%rax
 1007bcb:	je     1007be7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x167>
 1007bcd:	sub    $0x10,%rax
 1007bd1:	mov    (%rax),%rax
 1007bd4:	movabs $0x5000000000000001,%rdx
 1007bde:	and    %rdx,%rax
 1007be1:	cmp    $0x0,%rax
 1007be5:	jne    1007c05 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x185>
 1007be7:	mov    -0x3b0(%rbp),%rax
 1007bee:	mov    %rax,-0x3a8(%rbp)
 1007bf5:	movq   $0x0,-0x3b0(%rbp)
 1007c00:	xchg   %rbx,%rdi
 1007c03:	jmp    1007c40 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1c0>
 1007c05:	mov    %rcx,%r15
 1007c08:	lea    -0x3b0(%rbp),%rdx
 1007c0f:	lea    -0x3a8(%rbp),%rsi
 1007c16:	mov    %rdi,%r14
 1007c19:	call   100ae40 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take>
 1007c1e:	mov    %r15,%rcx
 1007c21:	mov    %r14,%rdi
 1007c24:	cmp    $0x0,%eax
 1007c27:	jne    1007c3d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1bd>
 1007c29:	call   10127a0 <myl_rc_take_failure>
 1007c2e:	mov    %rbx,%rdi
 1007c31:	mov    %eax,%esi
 1007c33:	call   100b0c0 <myl_qbe_rc_status>
 1007c38:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1007c3d:	xchg   %rbx,%rdi
 1007c40:	mov    -0x3f0(%rbp),%eax
 1007c46:	cmp    $0x0,%eax
 1007c49:	jne    1007c53 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1d3>
 1007c4b:	mov    %rcx,%r15
 1007c4e:	jmp    1007cd3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x253>
 1007c53:	movl   $0x0,-0x3f0(%rbp)
 1007c5d:	mov    %rcx,%r15
 1007c60:	mov    -0x370(%rbp),%rcx
 1007c67:	cmp    $0x0,%rcx
 1007c6b:	je     1007cd3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x253>
 1007c6d:	mov    %rcx,%rax
 1007c70:	sub    $0x10,%rax
 1007c74:	mov    (%rax),%rax
 1007c77:	movabs $0x4000000000000002,%rdx
 1007c81:	and    %rdx,%rax
 1007c84:	cmp    $0x0,%rax
 1007c88:	jne    1007cc8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x248>
 1007c8a:	mov    %rcx,%rax
 1007c8d:	sub    $0x20,%rax
 1007c91:	mov    (%rax),%rax
 1007c94:	sub    $0x1,%rax
 1007c98:	jne    1007cc1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x241>
 1007c9a:	mov    %rcx,%rdx
 1007c9d:	sub    $0x18,%rdx
 1007ca1:	mov    (%rdx),%rdx
 1007ca4:	cmp    $0x0,%rdx
 1007ca8:	jne    1007cc1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x241>
 1007caa:	lea    -0x370(%rbp),%rsi
 1007cb1:	mov    %rdi,%r14
 1007cb4:	mov    %rbx,%rdi
 1007cb7:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1007cbc:	mov    %r14,%rdi
 1007cbf:	jmp    1007cd3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x253>
 1007cc1:	sub    $0x20,%rcx
 1007cc5:	mov    %rax,(%rcx)
 1007cc8:	movq   $0x0,-0x370(%rbp)
 1007cd3:	mov    -0x3a8(%rbp),%rax
 1007cda:	mov    %rax,-0x370(%rbp)
 1007ce1:	movl   $0x1,-0x3f0(%rbp)
 1007ceb:	movabs $0x408f400000000000,%rax
 1007cf5:	mov    %rax,-0x318(%rbp)
 1007cfc:	movabs $0x408f400000000000,%rdx
 1007d06:	mov    $0x7,%esi
 1007d0b:	mov    %rdi,%r14
 1007d0e:	call   100ba60 <myl_qbe_float_unary>
 1007d13:	mov    %r15,%rcx
 1007d16:	mov    %r14,%rdi
 1007d19:	mov    %rax,%rsi
 1007d1c:	mov    -0x24(%rbp),%eax
 1007d1f:	mov    -0x10(%rbp),%edx
 1007d22:	mov    %rsi,-0x318(%rbp)
 1007d29:	movq   $0x0,-0x310(%rbp)
 1007d34:	mov    %rsi,-0x308(%rbp)
 1007d3b:	movq   $0x0,-0x300(%rbp)
 1007d46:	movabs $0x408f380000000000,%rsi
 1007d50:	mov    %rsi,-0x318(%rbp)
 1007d57:	movabs $0x3fe0000000000000,%rsi
 1007d61:	mov    %rsi,-0x2f8(%rbp)
 1007d68:	movabs $0x3fe0000000000000,%rsi
 1007d72:	mov    %rsi,-0x2f0(%rbp)
 1007d79:	movabs $0x3fe0000000000000,%rsi
 1007d83:	mov    %rsi,-0x2e8(%rbp)
 1007d8a:	mov    -0x310(%rbp),%rsi
 1007d91:	mov    %rsi,-0x2e0(%rbp)
 1007d98:	mov    -0x308(%rbp),%rsi
 1007d9f:	mov    %rsi,-0x2d8(%rbp)
 1007da6:	mov    -0x300(%rbp),%rsi
 1007dad:	mov    %rsi,-0x2d0(%rbp)
 1007db4:	movabs $0x408f380000000000,%rsi
 1007dbe:	mov    %rsi,-0x2c8(%rbp)
 1007dc5:	mov    -0x2f8(%rbp),%rsi
 1007dcc:	mov    %rsi,-0x2c0(%rbp)
 1007dd3:	mov    -0x2f0(%rbp),%rsi
 1007dda:	mov    %rsi,-0x2b8(%rbp)
 1007de1:	mov    -0x2e8(%rbp),%rsi
 1007de8:	mov    %rsi,-0x2b0(%rbp)
 1007def:	mov    -0x3f0(%rbp),%esi
 1007df5:	test   %edx,%esi
 1007df7:	je     1007ffc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x57c>
 1007dfd:	mov    -0x370(%rbp),%rdx
 1007e04:	cmp    $0x0,%rdx
 1007e08:	jne    1007e0f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x38f>
 1007e0a:	xchg   %rdi,%rbx
 1007e0d:	jmp    1007e73 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3f3>
 1007e0f:	mov    %rdx,%rsi
 1007e12:	sub    $0x10,%rsi
 1007e16:	mov    (%rsi),%rsi
 1007e19:	movabs $0x4000000000000002,%r8
 1007e23:	and    %rsi,%r8
 1007e26:	cmp    $0x0,%r8
 1007e2a:	jne    1007e5d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3dd>
 1007e2c:	mov    %rdx,%rsi
 1007e2f:	sub    $0x20,%rsi
 1007e33:	mov    (%rsi),%rsi
 1007e36:	add    $0x1,%rsi
 1007e3a:	je     1007e4b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3cb>
 1007e3c:	mov    %rdx,%r8
 1007e3f:	sub    $0x20,%r8
 1007e43:	mov    %rsi,(%r8)
 1007e46:	xchg   %rdi,%rbx
 1007e49:	jmp    1007e73 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3f3>
 1007e4b:	mov    $0x2,%esi
 1007e50:	mov    %rdi,%rbx
 1007e53:	call   100b0c0 <myl_qbe_rc_status>
 1007e58:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1007e5d:	xchg   %rdi,%rbx
 1007e60:	movabs $0x4000000000000000,%r8
 1007e6a:	and    %r8,%rsi
 1007e6d:	cmp    $0x0,%rsi
 1007e71:	jne    1007e7f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x3ff>
 1007e73:	mov    %rdx,-0x3a8(%rbp)
 1007e7a:	xchg   %rbx,%rdi
 1007e7d:	jmp    1007ebf <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x43f>
 1007e7f:	mov    %rcx,%r15
 1007e82:	lea    -0x370(%rbp),%rdx
 1007e89:	lea    -0x3a8(%rbp),%rsi
 1007e90:	mov    %rdi,%r14
 1007e93:	call   100adf0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 1007e98:	mov    %r15,%rcx
 1007e9b:	mov    %r14,%rdi
 1007e9e:	mov    %eax,%edx
 1007ea0:	mov    -0x24(%rbp),%eax
 1007ea3:	cmp    $0x0,%edx
 1007ea6:	jne    1007ebc <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x43c>
 1007ea8:	call   10127a0 <myl_rc_take_failure>
 1007ead:	mov    %rbx,%rdi
 1007eb0:	mov    %eax,%esi
 1007eb2:	call   100b0c0 <myl_qbe_rc_status>
 1007eb7:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1007ebc:	xchg   %rbx,%rdi
 1007ebf:	mov    -0x3f0(%rbp),%edx
 1007ec5:	cmp    $0x0,%edx
 1007ec8:	je     1007fe4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007ece:	movl   $0x0,-0x3f0(%rbp)
 1007ed8:	test   $0x1c,%eax
 1007edd:	jne    1007f68 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4e8>
 1007ee3:	mov    -0x370(%rbp),%rdx
 1007eea:	cmp    $0x0,%rdx
 1007eee:	je     1007fe4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007ef4:	mov    %rdx,%rax
 1007ef7:	sub    $0x10,%rax
 1007efb:	mov    (%rax),%rax
 1007efe:	movabs $0x4000000000000002,%rsi
 1007f08:	and    %rsi,%rax
 1007f0b:	cmp    $0x0,%rax
 1007f0f:	jne    1007f5b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4db>
 1007f11:	mov    %rdx,%rax
 1007f14:	sub    $0x20,%rax
 1007f18:	mov    (%rax),%rax
 1007f1b:	sub    $0x1,%rax
 1007f1f:	jne    1007f54 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4d4>
 1007f21:	mov    %rcx,%r15
 1007f24:	mov    %rdx,%rcx
 1007f27:	sub    $0x18,%rcx
 1007f2b:	mov    (%rcx),%rcx
 1007f2e:	cmp    $0x0,%rcx
 1007f32:	jne    1007f51 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x4d1>
 1007f34:	lea    -0x370(%rbp),%rsi
 1007f3b:	mov    %rdi,%r14
 1007f3e:	mov    %rbx,%rdi
 1007f41:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1007f46:	mov    %r15,%rcx
 1007f49:	mov    %r14,%rdi
 1007f4c:	jmp    1007fe4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007f51:	mov    %r15,%rcx
 1007f54:	sub    $0x20,%rdx
 1007f58:	mov    %rax,(%rdx)
 1007f5b:	movq   $0x0,-0x370(%rbp)
 1007f66:	jmp    1007fe4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007f68:	mov    -0x370(%rbp),%rdx
 1007f6f:	cmp    $0x0,%rdx
 1007f73:	je     1007fe4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007f75:	mov    %rdx,%rax
 1007f78:	sub    $0x10,%rax
 1007f7c:	mov    (%rax),%rax
 1007f7f:	movabs $0x4000000000000002,%rsi
 1007f89:	and    %rsi,%rax
 1007f8c:	cmp    $0x0,%rax
 1007f90:	jne    1007fd9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x559>
 1007f92:	mov    %rdx,%rax
 1007f95:	sub    $0x18,%rax
 1007f99:	mov    (%rax),%rax
 1007f9c:	sub    $0x1,%rax
 1007fa0:	jne    1007fd2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x552>
 1007fa2:	mov    %rcx,%r15
 1007fa5:	mov    %rdx,%rcx
 1007fa8:	sub    $0x20,%rcx
 1007fac:	mov    (%rcx),%rcx
 1007faf:	cmp    $0x0,%rcx
 1007fb3:	jne    1007fcf <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x54f>
 1007fb5:	lea    -0x370(%rbp),%rsi
 1007fbc:	mov    %rdi,%r14
 1007fbf:	mov    %rbx,%rdi
 1007fc2:	call   100ad10 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 1007fc7:	mov    %r15,%rcx
 1007fca:	mov    %r14,%rdi
 1007fcd:	jmp    1007fe4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x564>
 1007fcf:	mov    %r15,%rcx
 1007fd2:	sub    $0x18,%rdx
 1007fd6:	mov    %rax,(%rdx)
 1007fd9:	movq   $0x0,-0x370(%rbp)
 1007fe4:	mov    -0x3a8(%rbp),%rax
 1007feb:	mov    %rax,-0x370(%rbp)
 1007ff2:	movl   $0x1,-0x3f0(%rbp)
 1007ffc:	mov    -0x370(%rbp),%rax
 1008003:	cmp    $0x0,%rax
 1008007:	jne    100800e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x58e>
 1008009:	mov    %rcx,%r15
 100800c:	jmp    1008069 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5e9>
 100800e:	mov    %rax,%rdx
 1008011:	sub    $0x10,%rdx
 1008015:	mov    (%rdx),%rdx
 1008018:	movabs $0x6000000000000002,%rsi
 1008022:	and    %rsi,%rdx
 1008025:	cmp    $0x0,%rdx
 1008029:	jne    100803d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5bd>
 100802b:	sub    $0x20,%rax
 100802f:	mov    (%rax),%rax
 1008032:	cmp    $0x2,%rax
 1008036:	jae    100803d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5bd>
 1008038:	mov    %rcx,%r15
 100803b:	jmp    1008069 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x5e9>
 100803d:	mov    %rcx,%r15
 1008040:	lea    -0x3f0(%rbp),%rcx
 1008047:	lea    -0x370(%rbp),%rdx
 100804e:	lea    0x1ea5b(%rip),%rsi        # 1026ab0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 1008055:	mov    %rdi,%r14
 1008058:	call   100b360 <myl_qbe_rc_unique_local>
 100805d:	mov    %r14,%rdi
 1008060:	cmp    $0x0,%eax
 1008063:	je     1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008069:	mov    -0x370(%rbp),%rsi
 1008070:	lea    -0x2e0(%rbp),%rdx
 1008077:	mov    %rdi,%r14
 100807a:	mov    %rbx,%rdi
 100807d:	call   100ae90 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1008082:	mov    %r14,%rdi
 1008085:	cmp    $0x0,%eax
 1008088:	jne    1008091 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x611>
 100808a:	call   100b780 <myl_qbe_fail_allocation>
 100808f:	ud2
 1008091:	movq   $0x0,-0x318(%rbp)
 100809c:	movabs $0x4008000000000000,%rdx
 10080a6:	mov    $0x7,%esi
 10080ab:	mov    %rdi,%r14
 10080ae:	call   100ba60 <myl_qbe_float_unary>
 10080b3:	mov    %r15,%rcx
 10080b6:	mov    %r14,%rdi
 10080b9:	movq   $0x0,-0x2a8(%rbp)
 10080c4:	mov    -0x318(%rbp),%rdx
 10080cb:	mov    %rdx,-0x2a0(%rbp)
 10080d2:	mov    %rax,-0x298(%rbp)
 10080d9:	movabs $0x3ff0000000000000,%rax
 10080e3:	mov    %rax,-0x318(%rbp)
 10080ea:	movabs $0x3ff0000000000000,%rax
 10080f4:	mov    %rax,-0x290(%rbp)
 10080fb:	movabs $0x3fc999999999999a,%rax
 1008105:	mov    %rax,-0x288(%rbp)
 100810c:	movabs $0x3fc999999999999a,%rax
 1008116:	mov    %rax,-0x280(%rbp)
 100811d:	mov    -0x2a8(%rbp),%rax
 1008124:	mov    %rax,-0x278(%rbp)
 100812b:	mov    -0x2a0(%rbp),%rax
 1008132:	mov    %rax,-0x270(%rbp)
 1008139:	mov    -0x298(%rbp),%rax
 1008140:	mov    %rax,-0x268(%rbp)
 1008147:	movabs $0x3ff0000000000000,%rax
 1008151:	mov    %rax,-0x260(%rbp)
 1008158:	mov    -0x290(%rbp),%rax
 100815f:	mov    %rax,-0x258(%rbp)
 1008166:	mov    -0x288(%rbp),%rax
 100816d:	mov    %rax,-0x250(%rbp)
 1008174:	mov    -0x280(%rbp),%rax
 100817b:	mov    %rax,-0x248(%rbp)
 1008182:	mov    -0x3f0(%rbp),%eax
 1008188:	test   $0x0,%eax
 100818d:	je     10082fd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x87d>
 1008193:	mov    -0x370(%rbp),%rax
 100819a:	cmp    $0x0,%rax
 100819e:	jne    10081a5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x725>
 10081a0:	xchg   %rdi,%rbx
 10081a3:	jmp    1008209 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x789>
 10081a5:	mov    %rax,%rdx
 10081a8:	sub    $0x10,%rdx
 10081ac:	mov    (%rdx),%rdx
 10081af:	movabs $0x4000000000000002,%rsi
 10081b9:	and    %rdx,%rsi
 10081bc:	cmp    $0x0,%rsi
 10081c0:	jne    10081f3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x773>
 10081c2:	mov    %rax,%rdx
 10081c5:	sub    $0x20,%rdx
 10081c9:	mov    (%rdx),%rdx
 10081cc:	add    $0x1,%rdx
 10081d0:	je     10081e1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x761>
 10081d2:	mov    %rax,%rsi
 10081d5:	sub    $0x20,%rsi
 10081d9:	mov    %rdx,(%rsi)
 10081dc:	xchg   %rdi,%rbx
 10081df:	jmp    1008209 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x789>
 10081e1:	mov    $0x2,%esi
 10081e6:	mov    %rdi,%rbx
 10081e9:	call   100b0c0 <myl_qbe_rc_status>
 10081ee:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 10081f3:	xchg   %rdi,%rbx
 10081f6:	movabs $0x4000000000000000,%rsi
 1008200:	and    %rsi,%rdx
 1008203:	cmp    $0x0,%rdx
 1008207:	jne    1008215 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x795>
 1008209:	mov    %rax,-0x3a8(%rbp)
 1008210:	xchg   %rbx,%rdi
 1008213:	jmp    1008250 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7d0>
 1008215:	mov    %rcx,%r15
 1008218:	lea    -0x370(%rbp),%rdx
 100821f:	lea    -0x3a8(%rbp),%rsi
 1008226:	mov    %rdi,%r14
 1008229:	call   100adf0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 100822e:	mov    %r15,%rcx
 1008231:	mov    %r14,%rdi
 1008234:	cmp    $0x0,%eax
 1008237:	jne    100824d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x7cd>
 1008239:	call   10127a0 <myl_rc_take_failure>
 100823e:	mov    %rbx,%rdi
 1008241:	mov    %eax,%esi
 1008243:	call   100b0c0 <myl_qbe_rc_status>
 1008248:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 100824d:	xchg   %rbx,%rdi
 1008250:	mov    -0x3f0(%rbp),%eax
 1008256:	cmp    $0x0,%eax
 1008259:	je     10082e5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x865>
 100825f:	movl   $0x0,-0x3f0(%rbp)
 1008269:	mov    -0x370(%rbp),%rdx
 1008270:	cmp    $0x0,%rdx
 1008274:	je     10082e5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x865>
 1008276:	mov    %rdx,%rax
 1008279:	sub    $0x10,%rax
 100827d:	mov    (%rax),%rax
 1008280:	movabs $0x4000000000000002,%rsi
 100828a:	and    %rsi,%rax
 100828d:	cmp    $0x0,%rax
 1008291:	jne    10082da <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x85a>
 1008293:	mov    %rdx,%rax
 1008296:	sub    $0x20,%rax
 100829a:	mov    (%rax),%rax
 100829d:	sub    $0x1,%rax
 10082a1:	jne    10082d3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x853>
 10082a3:	mov    %rcx,%r15
 10082a6:	mov    %rdx,%rcx
 10082a9:	sub    $0x18,%rcx
 10082ad:	mov    (%rcx),%rcx
 10082b0:	cmp    $0x0,%rcx
 10082b4:	jne    10082d0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x850>
 10082b6:	lea    -0x370(%rbp),%rsi
 10082bd:	mov    %rdi,%r14
 10082c0:	mov    %rbx,%rdi
 10082c3:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10082c8:	mov    %r15,%rcx
 10082cb:	mov    %r14,%rdi
 10082ce:	jmp    10082e5 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x865>
 10082d0:	mov    %r15,%rcx
 10082d3:	sub    $0x20,%rdx
 10082d7:	mov    %rax,(%rdx)
 10082da:	movq   $0x0,-0x370(%rbp)
 10082e5:	mov    -0x3a8(%rbp),%rax
 10082ec:	mov    %rax,-0x370(%rbp)
 10082f3:	movl   $0x1,-0x3f0(%rbp)
 10082fd:	mov    -0x370(%rbp),%rax
 1008304:	cmp    $0x0,%rax
 1008308:	jne    100830f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x88f>
 100830a:	mov    %rcx,%r15
 100830d:	jmp    100836a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8ea>
 100830f:	mov    %rax,%rdx
 1008312:	sub    $0x10,%rdx
 1008316:	mov    (%rdx),%rdx
 1008319:	movabs $0x6000000000000002,%rsi
 1008323:	and    %rsi,%rdx
 1008326:	cmp    $0x0,%rdx
 100832a:	jne    100833e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8be>
 100832c:	sub    $0x20,%rax
 1008330:	mov    (%rax),%rax
 1008333:	cmp    $0x2,%rax
 1008337:	jae    100833e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8be>
 1008339:	mov    %rcx,%r15
 100833c:	jmp    100836a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x8ea>
 100833e:	mov    %rcx,%r15
 1008341:	lea    -0x3f0(%rbp),%rcx
 1008348:	lea    -0x370(%rbp),%rdx
 100834f:	lea    0x1e75a(%rip),%rsi        # 1026ab0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 1008356:	mov    %rdi,%r14
 1008359:	call   100b360 <myl_qbe_rc_unique_local>
 100835e:	mov    %r14,%rdi
 1008361:	cmp    $0x0,%eax
 1008364:	je     1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 100836a:	mov    -0x370(%rbp),%rsi
 1008371:	lea    -0x278(%rbp),%rdx
 1008378:	mov    %rdi,%r14
 100837b:	mov    %rbx,%rdi
 100837e:	call   100ae90 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1008383:	mov    %r14,%rdi
 1008386:	cmp    $0x0,%eax
 1008389:	jne    1008392 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x912>
 100838b:	call   100b780 <myl_qbe_fail_allocation>
 1008390:	ud2
 1008392:	movabs $0x4000000000000000,%rdx
 100839c:	mov    $0x7,%esi
 10083a1:	mov    %rdi,%r14
 10083a4:	call   100ba60 <myl_qbe_float_unary>
 10083a9:	mov    %r14,%rdi
 10083ac:	mov    %rax,-0x18(%rbp)
 10083b0:	movq   $0x0,-0x318(%rbp)
 10083bb:	movabs $0x4010000000000000,%rdx
 10083c5:	mov    $0x7,%esi
 10083ca:	mov    %rdi,%r14
 10083cd:	call   100ba60 <myl_qbe_float_unary>
 10083d2:	mov    %r15,%rcx
 10083d5:	mov    %r14,%rdi
 10083d8:	mov    -0x18(%rbp),%rdx
 10083dc:	mov    %rdx,-0x240(%rbp)
 10083e3:	mov    -0x318(%rbp),%rdx
 10083ea:	mov    %rdx,-0x238(%rbp)
 10083f1:	mov    %rax,-0x230(%rbp)
 10083f8:	movabs $0x3ff0000000000000,%rax
 1008402:	mov    %rax,-0x318(%rbp)
 1008409:	movabs $0x3fc999999999999a,%rax
 1008413:	mov    %rax,-0x228(%rbp)
 100841a:	movabs $0x3ff0000000000000,%rax
 1008424:	mov    %rax,-0x220(%rbp)
 100842b:	movabs $0x3fc999999999999a,%rax
 1008435:	mov    %rax,-0x218(%rbp)
 100843c:	mov    -0x240(%rbp),%rax
 1008443:	mov    %rax,-0x210(%rbp)
 100844a:	mov    -0x238(%rbp),%rax
 1008451:	mov    %rax,-0x208(%rbp)
 1008458:	mov    -0x230(%rbp),%rax
 100845f:	mov    %rax,-0x200(%rbp)
 1008466:	movabs $0x3ff0000000000000,%rax
 1008470:	mov    %rax,-0x1f8(%rbp)
 1008477:	mov    -0x228(%rbp),%rax
 100847e:	mov    %rax,-0x1f0(%rbp)
 1008485:	mov    -0x220(%rbp),%rax
 100848c:	mov    %rax,-0x1e8(%rbp)
 1008493:	mov    -0x218(%rbp),%rax
 100849a:	mov    %rax,-0x1e0(%rbp)
 10084a1:	mov    -0x3f0(%rbp),%eax
 10084a7:	test   $0x0,%eax
 10084ac:	je     100861c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb9c>
 10084b2:	mov    -0x370(%rbp),%rax
 10084b9:	cmp    $0x0,%rax
 10084bd:	jne    10084c4 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa44>
 10084bf:	xchg   %rdi,%rbx
 10084c2:	jmp    1008528 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaa8>
 10084c4:	mov    %rax,%rdx
 10084c7:	sub    $0x10,%rdx
 10084cb:	mov    (%rdx),%rdx
 10084ce:	movabs $0x4000000000000002,%rsi
 10084d8:	and    %rdx,%rsi
 10084db:	cmp    $0x0,%rsi
 10084df:	jne    1008512 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa92>
 10084e1:	mov    %rax,%rdx
 10084e4:	sub    $0x20,%rdx
 10084e8:	mov    (%rdx),%rdx
 10084eb:	add    $0x1,%rdx
 10084ef:	je     1008500 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xa80>
 10084f1:	mov    %rax,%rsi
 10084f4:	sub    $0x20,%rsi
 10084f8:	mov    %rdx,(%rsi)
 10084fb:	xchg   %rdi,%rbx
 10084fe:	jmp    1008528 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaa8>
 1008500:	mov    $0x2,%esi
 1008505:	mov    %rdi,%rbx
 1008508:	call   100b0c0 <myl_qbe_rc_status>
 100850d:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008512:	xchg   %rdi,%rbx
 1008515:	movabs $0x4000000000000000,%rsi
 100851f:	and    %rsi,%rdx
 1008522:	cmp    $0x0,%rdx
 1008526:	jne    1008534 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xab4>
 1008528:	mov    %rax,-0x3a8(%rbp)
 100852f:	xchg   %rbx,%rdi
 1008532:	jmp    100856f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaef>
 1008534:	mov    %rcx,%r15
 1008537:	lea    -0x370(%rbp),%rdx
 100853e:	lea    -0x3a8(%rbp),%rsi
 1008545:	mov    %rdi,%r14
 1008548:	call   100adf0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 100854d:	mov    %r15,%rcx
 1008550:	mov    %r14,%rdi
 1008553:	cmp    $0x0,%eax
 1008556:	jne    100856c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xaec>
 1008558:	call   10127a0 <myl_rc_take_failure>
 100855d:	mov    %rbx,%rdi
 1008560:	mov    %eax,%esi
 1008562:	call   100b0c0 <myl_qbe_rc_status>
 1008567:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 100856c:	xchg   %rbx,%rdi
 100856f:	mov    -0x3f0(%rbp),%eax
 1008575:	cmp    $0x0,%eax
 1008578:	je     1008604 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb84>
 100857e:	movl   $0x0,-0x3f0(%rbp)
 1008588:	mov    -0x370(%rbp),%rdx
 100858f:	cmp    $0x0,%rdx
 1008593:	je     1008604 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb84>
 1008595:	mov    %rdx,%rax
 1008598:	sub    $0x10,%rax
 100859c:	mov    (%rax),%rax
 100859f:	movabs $0x4000000000000002,%rsi
 10085a9:	and    %rsi,%rax
 10085ac:	cmp    $0x0,%rax
 10085b0:	jne    10085f9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb79>
 10085b2:	mov    %rdx,%rax
 10085b5:	sub    $0x20,%rax
 10085b9:	mov    (%rax),%rax
 10085bc:	sub    $0x1,%rax
 10085c0:	jne    10085f2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb72>
 10085c2:	mov    %rcx,%r15
 10085c5:	mov    %rdx,%rcx
 10085c8:	sub    $0x18,%rcx
 10085cc:	mov    (%rcx),%rcx
 10085cf:	cmp    $0x0,%rcx
 10085d3:	jne    10085ef <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb6f>
 10085d5:	lea    -0x370(%rbp),%rsi
 10085dc:	mov    %rdi,%r14
 10085df:	mov    %rbx,%rdi
 10085e2:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10085e7:	mov    %r15,%rcx
 10085ea:	mov    %r14,%rdi
 10085ed:	jmp    1008604 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xb84>
 10085ef:	mov    %r15,%rcx
 10085f2:	sub    $0x20,%rdx
 10085f6:	mov    %rax,(%rdx)
 10085f9:	movq   $0x0,-0x370(%rbp)
 1008604:	mov    -0x3a8(%rbp),%rax
 100860b:	mov    %rax,-0x370(%rbp)
 1008612:	movl   $0x1,-0x3f0(%rbp)
 100861c:	mov    -0x370(%rbp),%rax
 1008623:	cmp    $0x0,%rax
 1008627:	jne    100862e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xbae>
 1008629:	mov    %rcx,%r15
 100862c:	jmp    1008689 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc09>
 100862e:	mov    %rax,%rdx
 1008631:	sub    $0x10,%rdx
 1008635:	mov    (%rdx),%rdx
 1008638:	movabs $0x6000000000000002,%rsi
 1008642:	and    %rsi,%rdx
 1008645:	cmp    $0x0,%rdx
 1008649:	jne    100865d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xbdd>
 100864b:	sub    $0x20,%rax
 100864f:	mov    (%rax),%rax
 1008652:	cmp    $0x2,%rax
 1008656:	jae    100865d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xbdd>
 1008658:	mov    %rcx,%r15
 100865b:	jmp    1008689 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc09>
 100865d:	mov    %rcx,%r15
 1008660:	lea    -0x3f0(%rbp),%rcx
 1008667:	lea    -0x370(%rbp),%rdx
 100866e:	lea    0x1e43b(%rip),%rsi        # 1026ab0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 1008675:	mov    %rdi,%r14
 1008678:	call   100b360 <myl_qbe_rc_unique_local>
 100867d:	mov    %r14,%rdi
 1008680:	cmp    $0x0,%eax
 1008683:	je     1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008689:	mov    -0x370(%rbp),%rsi
 1008690:	lea    -0x210(%rbp),%rdx
 1008697:	mov    %rdi,%r14
 100869a:	mov    %rbx,%rdi
 100869d:	call   100ae90 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 10086a2:	mov    %r14,%rdi
 10086a5:	cmp    $0x0,%eax
 10086a8:	jne    10086b1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xc31>
 10086aa:	call   100b780 <myl_qbe_fail_allocation>
 10086af:	ud2
 10086b1:	movq   $0x0,-0x318(%rbp)
 10086bc:	movabs $0x4010000000000000,%rdx
 10086c6:	mov    $0x7,%esi
 10086cb:	mov    %rdi,%r14
 10086ce:	call   100ba60 <myl_qbe_float_unary>
 10086d3:	mov    %r15,%rcx
 10086d6:	mov    %r14,%rdi
 10086d9:	movabs $0x4000000000000000,%rdx
 10086e3:	mov    %rdx,-0x1d8(%rbp)
 10086ea:	mov    -0x318(%rbp),%rdx
 10086f1:	mov    %rdx,-0x1d0(%rbp)
 10086f8:	mov    %rax,-0x1c8(%rbp)
 10086ff:	movabs $0x3ff0000000000000,%rax
 1008709:	mov    %rax,-0x318(%rbp)
 1008710:	movabs $0x3fc999999999999a,%rax
 100871a:	mov    %rax,-0x1c0(%rbp)
 1008721:	movabs $0x3fc999999999999a,%rax
 100872b:	mov    %rax,-0x1b8(%rbp)
 1008732:	movabs $0x3ff0000000000000,%rax
 100873c:	mov    %rax,-0x1b0(%rbp)
 1008743:	mov    -0x1d8(%rbp),%rax
 100874a:	mov    %rax,-0x1a8(%rbp)
 1008751:	mov    -0x1d0(%rbp),%rax
 1008758:	mov    %rax,-0x1a0(%rbp)
 100875f:	mov    -0x1c8(%rbp),%rax
 1008766:	mov    %rax,-0x198(%rbp)
 100876d:	movabs $0x3ff0000000000000,%rax
 1008777:	mov    %rax,-0x190(%rbp)
 100877e:	mov    -0x1c0(%rbp),%rax
 1008785:	mov    %rax,-0x188(%rbp)
 100878c:	mov    -0x1b8(%rbp),%rax
 1008793:	mov    %rax,-0x180(%rbp)
 100879a:	mov    -0x1b0(%rbp),%rax
 10087a1:	mov    %rax,-0x178(%rbp)
 10087a8:	mov    -0x3f0(%rbp),%eax
 10087ae:	test   $0x0,%eax
 10087b3:	je     1008923 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xea3>
 10087b9:	mov    -0x370(%rbp),%rax
 10087c0:	cmp    $0x0,%rax
 10087c4:	jne    10087cb <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd4b>
 10087c6:	xchg   %rdi,%rbx
 10087c9:	jmp    100882f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdaf>
 10087cb:	mov    %rax,%rdx
 10087ce:	sub    $0x10,%rdx
 10087d2:	mov    (%rdx),%rdx
 10087d5:	movabs $0x4000000000000002,%rsi
 10087df:	and    %rdx,%rsi
 10087e2:	cmp    $0x0,%rsi
 10087e6:	jne    1008819 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd99>
 10087e8:	mov    %rax,%rdx
 10087eb:	sub    $0x20,%rdx
 10087ef:	mov    (%rdx),%rdx
 10087f2:	add    $0x1,%rdx
 10087f6:	je     1008807 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xd87>
 10087f8:	mov    %rax,%rsi
 10087fb:	sub    $0x20,%rsi
 10087ff:	mov    %rdx,(%rsi)
 1008802:	xchg   %rdi,%rbx
 1008805:	jmp    100882f <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdaf>
 1008807:	mov    $0x2,%esi
 100880c:	mov    %rdi,%rbx
 100880f:	call   100b0c0 <myl_qbe_rc_status>
 1008814:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008819:	xchg   %rdi,%rbx
 100881c:	movabs $0x4000000000000000,%rsi
 1008826:	and    %rsi,%rdx
 1008829:	cmp    $0x0,%rdx
 100882d:	jne    100883b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdbb>
 100882f:	mov    %rax,-0x3a8(%rbp)
 1008836:	xchg   %rbx,%rdi
 1008839:	jmp    1008876 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf6>
 100883b:	mov    %rcx,%r15
 100883e:	lea    -0x370(%rbp),%rdx
 1008845:	lea    -0x3a8(%rbp),%rsi
 100884c:	mov    %rdi,%r14
 100884f:	call   100adf0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 1008854:	mov    %r15,%rcx
 1008857:	mov    %r14,%rdi
 100885a:	cmp    $0x0,%eax
 100885d:	jne    1008873 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xdf3>
 100885f:	call   10127a0 <myl_rc_take_failure>
 1008864:	mov    %rbx,%rdi
 1008867:	mov    %eax,%esi
 1008869:	call   100b0c0 <myl_qbe_rc_status>
 100886e:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008873:	xchg   %rbx,%rdi
 1008876:	mov    -0x3f0(%rbp),%eax
 100887c:	cmp    $0x0,%eax
 100887f:	je     100890b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe8b>
 1008885:	movl   $0x0,-0x3f0(%rbp)
 100888f:	mov    -0x370(%rbp),%rdx
 1008896:	cmp    $0x0,%rdx
 100889a:	je     100890b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe8b>
 100889c:	mov    %rdx,%rax
 100889f:	sub    $0x10,%rax
 10088a3:	mov    (%rax),%rax
 10088a6:	movabs $0x4000000000000002,%rsi
 10088b0:	and    %rsi,%rax
 10088b3:	cmp    $0x0,%rax
 10088b7:	jne    1008900 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe80>
 10088b9:	mov    %rdx,%rax
 10088bc:	sub    $0x20,%rax
 10088c0:	mov    (%rax),%rax
 10088c3:	sub    $0x1,%rax
 10088c7:	jne    10088f9 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe79>
 10088c9:	mov    %rcx,%r15
 10088cc:	mov    %rdx,%rcx
 10088cf:	sub    $0x18,%rcx
 10088d3:	mov    (%rcx),%rcx
 10088d6:	cmp    $0x0,%rcx
 10088da:	jne    10088f6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe76>
 10088dc:	lea    -0x370(%rbp),%rsi
 10088e3:	mov    %rdi,%r14
 10088e6:	mov    %rbx,%rdi
 10088e9:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10088ee:	mov    %r15,%rcx
 10088f1:	mov    %r14,%rdi
 10088f4:	jmp    100890b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xe8b>
 10088f6:	mov    %r15,%rcx
 10088f9:	sub    $0x20,%rdx
 10088fd:	mov    %rax,(%rdx)
 1008900:	movq   $0x0,-0x370(%rbp)
 100890b:	mov    -0x3a8(%rbp),%rax
 1008912:	mov    %rax,-0x370(%rbp)
 1008919:	movl   $0x1,-0x3f0(%rbp)
 1008923:	mov    -0x370(%rbp),%rax
 100892a:	cmp    $0x0,%rax
 100892e:	jne    1008935 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xeb5>
 1008930:	mov    %rcx,%r15
 1008933:	jmp    1008990 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf10>
 1008935:	mov    %rax,%rdx
 1008938:	sub    $0x10,%rdx
 100893c:	mov    (%rdx),%rdx
 100893f:	movabs $0x6000000000000002,%rsi
 1008949:	and    %rsi,%rdx
 100894c:	cmp    $0x0,%rdx
 1008950:	jne    1008964 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xee4>
 1008952:	sub    $0x20,%rax
 1008956:	mov    (%rax),%rax
 1008959:	cmp    $0x2,%rax
 100895d:	jae    1008964 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xee4>
 100895f:	mov    %rcx,%r15
 1008962:	jmp    1008990 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf10>
 1008964:	mov    %rcx,%r15
 1008967:	lea    -0x3f0(%rbp),%rcx
 100896e:	lea    -0x370(%rbp),%rdx
 1008975:	lea    0x1e134(%rip),%rsi        # 1026ab0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 100897c:	mov    %rdi,%r14
 100897f:	call   100b360 <myl_qbe_rc_unique_local>
 1008984:	mov    %r14,%rdi
 1008987:	cmp    $0x0,%eax
 100898a:	je     1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008990:	mov    -0x370(%rbp),%rsi
 1008997:	lea    -0x1a8(%rbp),%rdx
 100899e:	mov    %rdi,%r14
 10089a1:	mov    %rbx,%rdi
 10089a4:	call   100ae90 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 10089a9:	mov    %r14,%rdi
 10089ac:	cmp    $0x0,%eax
 10089af:	jne    10089b8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0xf38>
 10089b1:	call   100b780 <myl_qbe_fail_allocation>
 10089b6:	ud2
 10089b8:	movabs $0x4000000000000000,%rax
 10089c2:	mov    %rax,-0x318(%rbp)
 10089c9:	movabs $0x4018000000000000,%rdx
 10089d3:	mov    $0x7,%esi
 10089d8:	mov    %rdi,%r14
 10089db:	call   100ba60 <myl_qbe_float_unary>
 10089e0:	mov    %r15,%rcx
 10089e3:	mov    %r14,%rdi
 10089e6:	movq   $0x0,-0x170(%rbp)
 10089f1:	mov    -0x318(%rbp),%rdx
 10089f8:	mov    %rdx,-0x168(%rbp)
 10089ff:	mov    %rax,-0x160(%rbp)
 1008a06:	movabs $0x3ff8000000000000,%rax
 1008a10:	mov    %rax,-0x318(%rbp)
 1008a17:	movabs $0x3ff0000000000000,%rax
 1008a21:	mov    %rax,-0x158(%rbp)
 1008a28:	movabs $0x3ff0000000000000,%rax
 1008a32:	mov    %rax,-0x150(%rbp)
 1008a39:	movabs $0x3fc999999999999a,%rax
 1008a43:	mov    %rax,-0x148(%rbp)
 1008a4a:	mov    -0x170(%rbp),%rax
 1008a51:	mov    %rax,-0x140(%rbp)
 1008a58:	mov    -0x168(%rbp),%rax
 1008a5f:	mov    %rax,-0x138(%rbp)
 1008a66:	mov    -0x160(%rbp),%rax
 1008a6d:	mov    %rax,-0x130(%rbp)
 1008a74:	movabs $0x3ff8000000000000,%rax
 1008a7e:	mov    %rax,-0x128(%rbp)
 1008a85:	mov    -0x158(%rbp),%rax
 1008a8c:	mov    %rax,-0x120(%rbp)
 1008a93:	mov    -0x150(%rbp),%rax
 1008a9a:	mov    %rax,-0x118(%rbp)
 1008aa1:	mov    -0x148(%rbp),%rax
 1008aa8:	mov    %rax,-0x110(%rbp)
 1008aaf:	mov    -0x3f0(%rbp),%eax
 1008ab5:	test   $0x0,%eax
 1008aba:	je     1008c2a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11aa>
 1008ac0:	mov    -0x370(%rbp),%rax
 1008ac7:	cmp    $0x0,%rax
 1008acb:	jne    1008ad2 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1052>
 1008acd:	xchg   %rdi,%rbx
 1008ad0:	jmp    1008b36 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10b6>
 1008ad2:	mov    %rax,%rdx
 1008ad5:	sub    $0x10,%rdx
 1008ad9:	mov    (%rdx),%rdx
 1008adc:	movabs $0x4000000000000002,%rsi
 1008ae6:	and    %rdx,%rsi
 1008ae9:	cmp    $0x0,%rsi
 1008aed:	jne    1008b20 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10a0>
 1008aef:	mov    %rax,%rdx
 1008af2:	sub    $0x20,%rdx
 1008af6:	mov    (%rdx),%rdx
 1008af9:	add    $0x1,%rdx
 1008afd:	je     1008b0e <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x108e>
 1008aff:	mov    %rax,%rsi
 1008b02:	sub    $0x20,%rsi
 1008b06:	mov    %rdx,(%rsi)
 1008b09:	xchg   %rdi,%rbx
 1008b0c:	jmp    1008b36 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10b6>
 1008b0e:	mov    $0x2,%esi
 1008b13:	mov    %rdi,%rbx
 1008b16:	call   100b0c0 <myl_qbe_rc_status>
 1008b1b:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008b20:	xchg   %rdi,%rbx
 1008b23:	movabs $0x4000000000000000,%rsi
 1008b2d:	and    %rsi,%rdx
 1008b30:	cmp    $0x0,%rdx
 1008b34:	jne    1008b42 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10c2>
 1008b36:	mov    %rax,-0x3a8(%rbp)
 1008b3d:	xchg   %rbx,%rdi
 1008b40:	jmp    1008b7d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10fd>
 1008b42:	mov    %rcx,%r15
 1008b45:	lea    -0x370(%rbp),%rdx
 1008b4c:	lea    -0x3a8(%rbp),%rsi
 1008b53:	mov    %rdi,%r14
 1008b56:	call   100adf0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 1008b5b:	mov    %r15,%rcx
 1008b5e:	mov    %r14,%rdi
 1008b61:	cmp    $0x0,%eax
 1008b64:	jne    1008b7a <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x10fa>
 1008b66:	call   10127a0 <myl_rc_take_failure>
 1008b6b:	mov    %rbx,%rdi
 1008b6e:	mov    %eax,%esi
 1008b70:	call   100b0c0 <myl_qbe_rc_status>
 1008b75:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008b7a:	xchg   %rbx,%rdi
 1008b7d:	mov    -0x3f0(%rbp),%eax
 1008b83:	cmp    $0x0,%eax
 1008b86:	je     1008c12 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1192>
 1008b8c:	movl   $0x0,-0x3f0(%rbp)
 1008b96:	mov    -0x370(%rbp),%rdx
 1008b9d:	cmp    $0x0,%rdx
 1008ba1:	je     1008c12 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1192>
 1008ba3:	mov    %rdx,%rax
 1008ba6:	sub    $0x10,%rax
 1008baa:	mov    (%rax),%rax
 1008bad:	movabs $0x4000000000000002,%rsi
 1008bb7:	and    %rsi,%rax
 1008bba:	cmp    $0x0,%rax
 1008bbe:	jne    1008c07 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1187>
 1008bc0:	mov    %rdx,%rax
 1008bc3:	sub    $0x20,%rax
 1008bc7:	mov    (%rax),%rax
 1008bca:	sub    $0x1,%rax
 1008bce:	jne    1008c00 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1180>
 1008bd0:	mov    %rcx,%r15
 1008bd3:	mov    %rdx,%rcx
 1008bd6:	sub    $0x18,%rcx
 1008bda:	mov    (%rcx),%rcx
 1008bdd:	cmp    $0x0,%rcx
 1008be1:	jne    1008bfd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x117d>
 1008be3:	lea    -0x370(%rbp),%rsi
 1008bea:	mov    %rdi,%r14
 1008bed:	mov    %rbx,%rdi
 1008bf0:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1008bf5:	mov    %r15,%rcx
 1008bf8:	mov    %r14,%rdi
 1008bfb:	jmp    1008c12 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1192>
 1008bfd:	mov    %r15,%rcx
 1008c00:	sub    $0x20,%rdx
 1008c04:	mov    %rax,(%rdx)
 1008c07:	movq   $0x0,-0x370(%rbp)
 1008c12:	mov    -0x3a8(%rbp),%rax
 1008c19:	mov    %rax,-0x370(%rbp)
 1008c20:	movl   $0x1,-0x3f0(%rbp)
 1008c2a:	mov    -0x370(%rbp),%rax
 1008c31:	cmp    $0x0,%rax
 1008c35:	jne    1008c3c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11bc>
 1008c37:	mov    %rcx,%r15
 1008c3a:	jmp    1008c97 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1217>
 1008c3c:	mov    %rax,%rdx
 1008c3f:	sub    $0x10,%rdx
 1008c43:	mov    (%rdx),%rdx
 1008c46:	movabs $0x6000000000000002,%rsi
 1008c50:	and    %rsi,%rdx
 1008c53:	cmp    $0x0,%rdx
 1008c57:	jne    1008c6b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11eb>
 1008c59:	sub    $0x20,%rax
 1008c5d:	mov    (%rax),%rax
 1008c60:	cmp    $0x2,%rax
 1008c64:	jae    1008c6b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x11eb>
 1008c66:	mov    %rcx,%r15
 1008c69:	jmp    1008c97 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1217>
 1008c6b:	mov    %rcx,%r15
 1008c6e:	lea    -0x3f0(%rbp),%rcx
 1008c75:	lea    -0x370(%rbp),%rdx
 1008c7c:	lea    0x1de2d(%rip),%rsi        # 1026ab0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 1008c83:	mov    %rdi,%r14
 1008c86:	call   100b360 <myl_qbe_rc_unique_local>
 1008c8b:	mov    %r14,%rdi
 1008c8e:	cmp    $0x0,%eax
 1008c91:	je     1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008c97:	mov    -0x370(%rbp),%rsi
 1008c9e:	lea    -0x140(%rbp),%rdx
 1008ca5:	mov    %rdi,%r14
 1008ca8:	mov    %rbx,%rdi
 1008cab:	call   100ae90 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1008cb0:	mov    %r14,%rdi
 1008cb3:	cmp    $0x0,%eax
 1008cb6:	jne    1008cbf <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x123f>
 1008cb8:	call   100b780 <myl_qbe_fail_allocation>
 1008cbd:	ud2
 1008cbf:	movabs $0x3ff8000000000000,%rdx
 1008cc9:	mov    $0x7,%esi
 1008cce:	mov    %rdi,%r14
 1008cd1:	call   100ba60 <myl_qbe_float_unary>
 1008cd6:	mov    %r14,%rdi
 1008cd9:	mov    %rax,-0x20(%rbp)
 1008cdd:	movabs $0x3fe0000000000000,%rax
 1008ce7:	mov    %rax,-0x318(%rbp)
 1008cee:	movabs $0x3fe0000000000000,%rdx
 1008cf8:	mov    $0x7,%esi
 1008cfd:	mov    %rdi,%r14
 1008d00:	call   100ba60 <myl_qbe_float_unary>
 1008d05:	mov    %r14,%rdi
 1008d08:	mov    %rax,-0x318(%rbp)
 1008d0f:	movabs $0x4000000000000000,%rdx
 1008d19:	mov    $0x7,%esi
 1008d1e:	mov    %rdi,%r14
 1008d21:	call   100ba60 <myl_qbe_float_unary>
 1008d26:	mov    %r15,%rcx
 1008d29:	mov    %r14,%rdi
 1008d2c:	mov    -0x20(%rbp),%rdx
 1008d30:	mov    %rdx,-0x108(%rbp)
 1008d37:	mov    -0x318(%rbp),%rdx
 1008d3e:	mov    %rdx,-0x100(%rbp)
 1008d45:	mov    %rax,-0xf8(%rbp)
 1008d4c:	movabs $0x3fe0000000000000,%rax
 1008d56:	mov    %rax,-0x318(%rbp)
 1008d5d:	movabs $0x3fc999999999999a,%rax
 1008d67:	mov    %rax,-0xf0(%rbp)
 1008d6e:	movabs $0x3ff0000000000000,%rax
 1008d78:	mov    %rax,-0xe8(%rbp)
 1008d7f:	movabs $0x3ff0000000000000,%rax
 1008d89:	mov    %rax,-0xe0(%rbp)
 1008d90:	mov    -0x108(%rbp),%rax
 1008d97:	mov    %rax,-0xd8(%rbp)
 1008d9e:	mov    -0x100(%rbp),%rax
 1008da5:	mov    %rax,-0xd0(%rbp)
 1008dac:	mov    -0xf8(%rbp),%rax
 1008db3:	mov    %rax,-0xc8(%rbp)
 1008dba:	movabs $0x3fe0000000000000,%rax
 1008dc4:	mov    %rax,-0xc0(%rbp)
 1008dcb:	mov    -0xf0(%rbp),%rax
 1008dd2:	mov    %rax,-0xb8(%rbp)
 1008dd9:	mov    -0xe8(%rbp),%rax
 1008de0:	mov    %rax,-0xb0(%rbp)
 1008de7:	mov    -0xe0(%rbp),%rax
 1008dee:	mov    %rax,-0xa8(%rbp)
 1008df5:	mov    -0x3f0(%rbp),%eax
 1008dfb:	test   $0x0,%eax
 1008e00:	je     1008f70 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14f0>
 1008e06:	mov    -0x370(%rbp),%rax
 1008e0d:	cmp    $0x0,%rax
 1008e11:	jne    1008e18 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1398>
 1008e13:	xchg   %rdi,%rbx
 1008e16:	jmp    1008e7c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13fc>
 1008e18:	mov    %rax,%rdx
 1008e1b:	sub    $0x10,%rdx
 1008e1f:	mov    (%rdx),%rdx
 1008e22:	movabs $0x4000000000000002,%rsi
 1008e2c:	and    %rdx,%rsi
 1008e2f:	cmp    $0x0,%rsi
 1008e33:	jne    1008e66 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13e6>
 1008e35:	mov    %rax,%rdx
 1008e38:	sub    $0x20,%rdx
 1008e3c:	mov    (%rdx),%rdx
 1008e3f:	add    $0x1,%rdx
 1008e43:	je     1008e54 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13d4>
 1008e45:	mov    %rax,%rsi
 1008e48:	sub    $0x20,%rsi
 1008e4c:	mov    %rdx,(%rsi)
 1008e4f:	xchg   %rdi,%rbx
 1008e52:	jmp    1008e7c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x13fc>
 1008e54:	mov    $0x2,%esi
 1008e59:	mov    %rdi,%rbx
 1008e5c:	call   100b0c0 <myl_qbe_rc_status>
 1008e61:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008e66:	xchg   %rdi,%rbx
 1008e69:	movabs $0x4000000000000000,%rsi
 1008e73:	and    %rsi,%rdx
 1008e76:	cmp    $0x0,%rdx
 1008e7a:	jne    1008e88 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1408>
 1008e7c:	mov    %rax,-0x3a8(%rbp)
 1008e83:	xchg   %rbx,%rdi
 1008e86:	jmp    1008ec3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1443>
 1008e88:	mov    %rcx,%r15
 1008e8b:	lea    -0x370(%rbp),%rdx
 1008e92:	lea    -0x3a8(%rbp),%rsi
 1008e99:	mov    %rdi,%r14
 1008e9c:	call   100adf0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 1008ea1:	mov    %r15,%rcx
 1008ea4:	mov    %r14,%rdi
 1008ea7:	cmp    $0x0,%eax
 1008eaa:	jne    1008ec0 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1440>
 1008eac:	call   10127a0 <myl_rc_take_failure>
 1008eb1:	mov    %rbx,%rdi
 1008eb4:	mov    %eax,%esi
 1008eb6:	call   100b0c0 <myl_qbe_rc_status>
 1008ebb:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008ec0:	xchg   %rbx,%rdi
 1008ec3:	mov    -0x3f0(%rbp),%eax
 1008ec9:	cmp    $0x0,%eax
 1008ecc:	je     1008f58 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d8>
 1008ed2:	movl   $0x0,-0x3f0(%rbp)
 1008edc:	mov    -0x370(%rbp),%rdx
 1008ee3:	cmp    $0x0,%rdx
 1008ee7:	je     1008f58 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d8>
 1008ee9:	mov    %rdx,%rax
 1008eec:	sub    $0x10,%rax
 1008ef0:	mov    (%rax),%rax
 1008ef3:	movabs $0x4000000000000002,%rsi
 1008efd:	and    %rsi,%rax
 1008f00:	cmp    $0x0,%rax
 1008f04:	jne    1008f4d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14cd>
 1008f06:	mov    %rdx,%rax
 1008f09:	sub    $0x20,%rax
 1008f0d:	mov    (%rax),%rax
 1008f10:	sub    $0x1,%rax
 1008f14:	jne    1008f46 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14c6>
 1008f16:	mov    %rcx,%r15
 1008f19:	mov    %rdx,%rcx
 1008f1c:	sub    $0x18,%rcx
 1008f20:	mov    (%rcx),%rcx
 1008f23:	cmp    $0x0,%rcx
 1008f27:	jne    1008f43 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14c3>
 1008f29:	lea    -0x370(%rbp),%rsi
 1008f30:	mov    %rdi,%r14
 1008f33:	mov    %rbx,%rdi
 1008f36:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1008f3b:	mov    %r15,%rcx
 1008f3e:	mov    %r14,%rdi
 1008f41:	jmp    1008f58 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x14d8>
 1008f43:	mov    %r15,%rcx
 1008f46:	sub    $0x20,%rdx
 1008f4a:	mov    %rax,(%rdx)
 1008f4d:	movq   $0x0,-0x370(%rbp)
 1008f58:	mov    -0x3a8(%rbp),%rax
 1008f5f:	mov    %rax,-0x370(%rbp)
 1008f66:	movl   $0x1,-0x3f0(%rbp)
 1008f70:	mov    -0x370(%rbp),%rax
 1008f77:	cmp    $0x0,%rax
 1008f7b:	jne    1008f82 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1502>
 1008f7d:	mov    %rcx,%r15
 1008f80:	jmp    1008fdd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x155d>
 1008f82:	mov    %rax,%rdx
 1008f85:	sub    $0x10,%rdx
 1008f89:	mov    (%rdx),%rdx
 1008f8c:	movabs $0x6000000000000002,%rsi
 1008f96:	and    %rsi,%rdx
 1008f99:	cmp    $0x0,%rdx
 1008f9d:	jne    1008fb1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1531>
 1008f9f:	sub    $0x20,%rax
 1008fa3:	mov    (%rax),%rax
 1008fa6:	cmp    $0x2,%rax
 1008faa:	jae    1008fb1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1531>
 1008fac:	mov    %rcx,%r15
 1008faf:	jmp    1008fdd <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x155d>
 1008fb1:	mov    %rcx,%r15
 1008fb4:	lea    -0x3f0(%rbp),%rcx
 1008fbb:	lea    -0x370(%rbp),%rdx
 1008fc2:	lea    0x1dae7(%rip),%rsi        # 1026ab0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 1008fc9:	mov    %rdi,%r14
 1008fcc:	call   100b360 <myl_qbe_rc_unique_local>
 1008fd1:	mov    %r14,%rdi
 1008fd4:	cmp    $0x0,%eax
 1008fd7:	je     1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 1008fdd:	mov    -0x370(%rbp),%rsi
 1008fe4:	lea    -0xd8(%rbp),%rdx
 1008feb:	mov    %rdi,%r14
 1008fee:	mov    %rbx,%rdi
 1008ff1:	call   100ae90 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>
 1008ff6:	mov    %r15,%rcx
 1008ff9:	mov    %r14,%rdi
 1008ffc:	mov    -0x28(%rbp),%edx
 1008fff:	cmp    $0x0,%eax
 1009002:	jne    100900b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x158b>
 1009004:	call   100b780 <myl_qbe_fail_allocation>
 1009009:	ud2
 100900b:	mov    -0x370(%rbp),%rax
 1009012:	mov    %rax,-0x3b0(%rbp)
 1009019:	cmp    $0x0,%edx
 100901c:	jne    10090d3 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1653>
 1009022:	cmp    $0x0,%rax
 1009026:	jne    100902d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x15ad>
 1009028:	xchg   %rdi,%rbx
 100902b:	jmp    1009091 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1611>
 100902d:	mov    %rax,%rdx
 1009030:	sub    $0x10,%rdx
 1009034:	mov    (%rdx),%rdx
 1009037:	movabs $0x4000000000000002,%rsi
 1009041:	and    %rdx,%rsi
 1009044:	cmp    $0x0,%rsi
 1009048:	jne    100907b <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x15fb>
 100904a:	mov    %rax,%rcx
 100904d:	sub    $0x20,%rcx
 1009051:	mov    (%rcx),%rcx
 1009054:	add    $0x1,%rcx
 1009058:	je     1009069 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x15e9>
 100905a:	mov    %rax,%rdx
 100905d:	sub    $0x20,%rdx
 1009061:	mov    %rcx,(%rdx)
 1009064:	xchg   %rdi,%rbx
 1009067:	jmp    1009091 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1611>
 1009069:	mov    $0x2,%esi
 100906e:	mov    %rdi,%rbx
 1009071:	call   100b0c0 <myl_qbe_rc_status>
 1009076:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 100907b:	xchg   %rdi,%rbx
 100907e:	movabs $0x4000000000000000,%rsi
 1009088:	and    %rsi,%rdx
 100908b:	cmp    $0x0,%rdx
 100908f:	jne    100909d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x161d>
 1009091:	mov    %rax,-0x3a8(%rbp)
 1009098:	jmp    1009153 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16d3>
 100909d:	lea    -0x3b0(%rbp),%rdx
 10090a4:	lea    -0x3a8(%rbp),%rsi
 10090ab:	mov    %rdi,%r12
 10090ae:	call   100adf0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>
 10090b3:	mov    %r12,%rdi
 10090b6:	cmp    $0x0,%eax
 10090b9:	jne    1009153 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16d3>
 10090bf:	call   10127a0 <myl_rc_take_failure>
 10090c4:	mov    %rbx,%rdi
 10090c7:	mov    %eax,%esi
 10090c9:	mov    %rdi,%rbx
 10090cc:	call   100b0c0 <myl_qbe_rc_status>
 10090d1:	jmp    1009149 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16c9>
 10090d3:	xchg   %rdi,%rbx
 10090d6:	mov    %r12d,%edx
 10090d9:	or     %r13d,%edx
 10090dc:	jne    1009119 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1699>
 10090de:	cmp    $0x0,%rax
 10090e2:	je     10090fe <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x167e>
 10090e4:	sub    $0x10,%rax
 10090e8:	mov    (%rax),%rax
 10090eb:	movabs $0x5000000000000001,%rdx
 10090f5:	and    %rdx,%rax
 10090f8:	cmp    $0x0,%rax
 10090fc:	jne    1009119 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1699>
 10090fe:	mov    -0x3b0(%rbp),%rax
 1009105:	mov    %rax,-0x3a8(%rbp)
 100910c:	movq   $0x0,-0x3b0(%rbp)
 1009117:	jmp    1009153 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16d3>
 1009119:	lea    -0x3b0(%rbp),%rdx
 1009120:	lea    -0x3a8(%rbp),%rsi
 1009127:	mov    %rdi,%r12
 100912a:	call   100ae40 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take>
 100912f:	mov    %r12,%rdi
 1009132:	cmp    $0x0,%eax
 1009135:	jne    1009153 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16d3>
 1009137:	call   10127a0 <myl_rc_take_failure>
 100913c:	mov    %rbx,%rdi
 100913f:	mov    %eax,%esi
 1009141:	mov    %rdi,%rbx
 1009144:	call   100b0c0 <myl_qbe_rc_status>
 1009149:	mov    $0x0,%eax
 100914e:	jmp    1009a7c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ffc>
 1009153:	mov    -0x3a8(%rbp),%rax
 100915a:	mov    %rax,-0x368(%rbp)
 1009161:	mov    -0x3f0(%rbp),%eax
 1009167:	cmp    $0x0,%eax
 100916a:	jne    1009174 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x16f4>
 100916c:	mov    %rbx,%rdi
 100916f:	jmp    10091f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1778>
 1009174:	movl   $0x0,-0x3f0(%rbp)
 100917e:	mov    -0x370(%rbp),%rcx
 1009185:	cmp    $0x0,%rcx
 1009189:	jne    1009190 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1710>
 100918b:	mov    %rbx,%rdi
 100918e:	jmp    10091f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1778>
 1009190:	mov    %rcx,%rax
 1009193:	sub    $0x10,%rax
 1009197:	mov    (%rax),%rax
 100919a:	movabs $0x4000000000000002,%rdx
 10091a4:	and    %rdx,%rax
 10091a7:	cmp    $0x0,%rax
 10091ab:	jne    10091ea <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x176a>
 10091ad:	mov    %rcx,%rax
 10091b0:	sub    $0x20,%rax
 10091b4:	mov    (%rax),%rax
 10091b7:	sub    $0x1,%rax
 10091bb:	jne    10091de <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x175e>
 10091bd:	mov    %rcx,%rdx
 10091c0:	sub    $0x18,%rdx
 10091c4:	mov    (%rdx),%rdx
 10091c7:	cmp    $0x0,%rdx
 10091cb:	jne    10091de <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x175e>
 10091cd:	lea    -0x370(%rbp),%rsi
 10091d4:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10091d9:	mov    %rbx,%rdi
 10091dc:	jmp    10091f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1778>
 10091de:	mov    %rbx,%rdi
 10091e1:	sub    $0x20,%rcx
 10091e5:	mov    %rax,(%rcx)
 10091e8:	jmp    10091ed <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x176d>
 10091ea:	mov    %rbx,%rdi
 10091ed:	movq   $0x0,-0x370(%rbp)
 10091f8:	movabs $0x3ff0000000000000,%rax
 1009202:	mov    %rax,-0x318(%rbp)
 1009209:	movabs $0x3ff0000000000000,%rax
 1009213:	mov    %rax,-0xa0(%rbp)
 100921a:	movabs $0x3ff0000000000000,%rax
 1009224:	mov    %rax,-0x98(%rbp)
 100922b:	movabs $0x3ff0000000000000,%rax
 1009235:	mov    %rax,-0x90(%rbp)
 100923c:	lea    -0xa0(%rbp),%rdx
 1009243:	mov    %rdi,%rsi
 1009246:	mov    %rdi,%rbx
 1009249:	lea    -0x438(%rbp),%rdi
 1009250:	call   1009d50 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380>
 1009255:	mov    %rbx,%rdi
 1009258:	mov    (%rax),%rcx
 100925b:	mov    %rcx,-0x360(%rbp)
 1009262:	mov    0x8(%rax),%rcx
 1009266:	mov    %rcx,-0x358(%rbp)
 100926d:	mov    0x10(%rax),%rax
 1009271:	mov    %rax,-0x350(%rbp)
 1009278:	mov    $0x780,%edx
 100927d:	mov    $0xa,%esi
 1009282:	mov    %rdi,%rbx
 1009285:	call   100ba60 <myl_qbe_float_unary>
 100928a:	mov    %rbx,%rdi
 100928d:	mov    %rax,%rbx
 1009290:	mov    $0x438,%edx
 1009295:	mov    $0xa,%esi
 100929a:	mov    %rdi,%r12
 100929d:	call   100ba60 <myl_qbe_float_unary>
 10092a2:	mov    %r12,%rdi
 10092a5:	mov    %rax,-0x318(%rbp)
 10092ac:	movq   %rbx,%xmm0
 10092b1:	movq   %rax,%xmm1
 10092b6:	divsd  %xmm1,%xmm0
 10092ba:	movq   %xmm0,%r14
 10092bf:	mov    %r14,-0x30(%rbp)
 10092c3:	movq   $0x0,-0x318(%rbp)
 10092ce:	movq   $0x0,-0x88(%rbp)
 10092d9:	movq   $0x0,-0x80(%rbp)
 10092e1:	movq   $0x0,-0x78(%rbp)
 10092e9:	mov    -0x88(%rbp),%rax
 10092f0:	mov    %rax,-0x348(%rbp)
 10092f7:	mov    -0x80(%rbp),%rax
 10092fb:	mov    %rax,-0x340(%rbp)
 1009302:	mov    -0x78(%rbp),%rax
 1009306:	mov    %rax,-0x338(%rbp)
 100930d:	movq   %r14,%xmm0
 1009312:	movsd  %xmm0,-0x40(%rbp)
 1009317:	mov    $0x0,%ebx
 100931c:	mov    $0x0,%r13d
 1009322:	cs nopw 0x0(%rax,%rax,1)
 100932c:	nopl   0x0(%rax)
 1009330:	mov    %r13,-0x38(%rbp)
 1009334:	movq   $0x438,-0x318(%rbp)
 100933f:	cmp    $0x438,%r13
 1009346:	jge    1009907 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e87>
 100934c:	mov    $0x0,%r12d
 1009352:	cs nopw 0x0(%rax,%rax,1)
 100935c:	nopl   0x0(%rax)
 1009360:	movq   $0x780,-0x318(%rbp)
 100936b:	cmp    $0x780,%r12
 1009372:	jge    10098c1 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e41>
 1009378:	mov    %r12,%rdx
 100937b:	mov    $0xa,%esi
 1009380:	mov    %rdi,%r14
 1009383:	call   100ba60 <myl_qbe_float_unary>
 1009388:	mov    %r14,%rdi
 100938b:	movabs $0x3fe0000000000000,%rcx
 1009395:	mov    %rcx,-0x318(%rbp)
 100939c:	movq   %rax,%xmm0
 10093a1:	addsd  -0x7ce9(%rip),%xmm0        # 10016c0 <__abi_tag+0x13c4>
 10093a9:	movq   %xmm0,%rax
 10093ae:	mov    %rax,-0x318(%rbp)
 10093b5:	movq   %rax,%xmm0
 10093ba:	mulsd  -0x7d0a(%rip),%xmm0        # 10016b8 <__abi_tag+0x13bc>
 10093c2:	movq   %xmm0,%r15
 10093c7:	mov    $0x780,%edx
 10093cc:	mov    $0xa,%esi
 10093d1:	mov    %rdi,%r14
 10093d4:	call   100ba60 <myl_qbe_float_unary>
 10093d9:	mov    %r14,%rdi
 10093dc:	movsd  -0x40(%rbp),%xmm0
 10093e1:	mov    -0x30(%rbp),%r14
 10093e5:	mov    %rax,-0x318(%rbp)
 10093ec:	movq   %r15,%xmm1
 10093f1:	movq   %rax,%xmm2
 10093f6:	divsd  %xmm2,%xmm1
 10093fa:	movq   %xmm1,%rax
 10093ff:	movabs $0x3ff0000000000000,%rcx
 1009409:	mov    %rcx,-0x318(%rbp)
 1009410:	movq   %rax,%xmm1
 1009415:	subsd  -0x7d6d(%rip),%xmm1        # 10016b0 <__abi_tag+0x13b4>
 100941d:	movq   %xmm1,%rax
 1009422:	mov    %r14,-0x318(%rbp)
 1009429:	movq   %rax,%xmm1
 100942e:	mulsd  %xmm1,%xmm0
 1009432:	movq   %xmm0,%r14
 1009437:	mov    %r13,%rdx
 100943a:	mov    $0xa,%esi
 100943f:	mov    %rdi,%r13
 1009442:	call   100ba60 <myl_qbe_float_unary>
 1009447:	mov    %r13,%rdi
 100944a:	movabs $0x3fe0000000000000,%rcx
 1009454:	mov    %rcx,-0x318(%rbp)
 100945b:	movq   %rax,%xmm0
 1009460:	addsd  -0x7da8(%rip),%xmm0        # 10016c0 <__abi_tag+0x13c4>
 1009468:	movq   %xmm0,%rax
 100946d:	mov    %rax,-0x318(%rbp)
 1009474:	movq   %rax,%xmm0
 1009479:	mulsd  -0x7dc9(%rip),%xmm0        # 10016b8 <__abi_tag+0x13bc>
 1009481:	movq   %xmm0,%r13
 1009486:	mov    $0x438,%edx
 100948b:	mov    $0xa,%esi
 1009490:	mov    %rdi,%r15
 1009493:	call   100ba60 <myl_qbe_float_unary>
 1009498:	mov    %r15,%rdi
 100949b:	mov    %rax,-0x318(%rbp)
 10094a2:	movq   %r13,%xmm0
 10094a7:	movq   %rax,%xmm1
 10094ac:	divsd  %xmm1,%xmm0
 10094b0:	movq   %xmm0,%rax
 10094b5:	mov    %rax,-0x318(%rbp)
 10094bc:	movq   %rax,%xmm0
 10094c1:	xorpd  -0x7e29(%rip),%xmm0        # 10016a0 <__abi_tag+0x13a4>
 10094c9:	addsd  -0x7e21(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 10094d1:	movq   %xmm0,%r13
 10094d6:	mov    %r14,-0x318(%rbp)
 10094dd:	movabs $0x3ff8000000000000,%rdx
 10094e7:	mov    $0x7,%esi
 10094ec:	mov    %rdi,%r14
 10094ef:	call   100ba60 <myl_qbe_float_unary>
 10094f4:	mov    %r14,%rdi
 10094f7:	mov    -0x318(%rbp),%rcx
 10094fe:	mov    %rcx,-0x70(%rbp)
 1009502:	mov    %r13,-0x68(%rbp)
 1009506:	mov    %rax,-0x60(%rbp)
 100950a:	lea    -0x70(%rbp),%rax
 100950e:	mov    %rax,-0x318(%rbp)
 1009515:	lea    -0x70(%rbp),%rdx
 1009519:	mov    %rdi,%rsi
 100951c:	mov    %rdi,%r13
 100951f:	lea    -0x408(%rbp),%rdi
 1009526:	call   1009d50 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380>
 100952b:	mov    %r13,%rdi
 100952e:	mov    %rax,%rcx
 1009531:	mov    %rcx,-0x318(%rbp)
 1009538:	mov    -0x368(%rbp),%r8
 100953f:	lea    -0x360(%rbp),%r9
 1009546:	lea    -0x348(%rbp),%rdx
 100954d:	mov    %rdi,%rsi
 1009550:	mov    %rdi,%r13
 1009553:	lea    -0x420(%rbp),%rdi
 100955a:	call   1009f10 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814>
 100955f:	mov    %r13,%rdi
 1009562:	mov    (%rax),%rcx
 1009565:	mov    %rcx,-0x330(%rbp)
 100956c:	mov    0x8(%rax),%rcx
 1009570:	mov    %rcx,-0x328(%rbp)
 1009577:	mov    0x10(%rax),%rax
 100957b:	mov    %rax,-0x320(%rbp)
 1009582:	mov    -0x330(%rbp),%rcx
 1009589:	mov    %rcx,-0x318(%rbp)
 1009590:	movq   %rcx,%xmm0
 1009595:	ucomisd -0x7eed(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 100959d:	movabs $0x3ff0000000000000,%rax
 10095a7:	cmovbe %rcx,%rax
 10095ab:	movabs $0x406fe00000000000,%rcx
 10095b5:	mov    %rcx,-0x318(%rbp)
 10095bc:	movq   %rax,%xmm0
 10095c1:	mulsd  -0x7f01(%rip),%xmm0        # 10016c8 <__abi_tag+0x13cc>
 10095c9:	movq   %xmm0,%rdx
 10095ce:	mov    $0xb,%esi
 10095d3:	mov    %rdi,%r13
 10095d6:	call   100ba60 <myl_qbe_float_unary>
 10095db:	mov    %r13,%rdi
 10095de:	mov    -0x328(%rbp),%rcx
 10095e5:	mov    %rcx,-0x318(%rbp)
 10095ec:	movq   %rcx,%xmm0
 10095f1:	ucomisd -0x7f49(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 10095f9:	mov    %rax,%r13
 10095fc:	movabs $0x3ff0000000000000,%rax
 1009606:	cmovbe %rcx,%rax
 100960a:	movabs $0x406fe00000000000,%rcx
 1009614:	mov    %rcx,-0x318(%rbp)
 100961b:	movq   %rax,%xmm0
 1009620:	mulsd  -0x7f60(%rip),%xmm0        # 10016c8 <__abi_tag+0x13cc>
 1009628:	movq   %xmm0,%rdx
 100962d:	mov    $0xb,%esi
 1009632:	mov    %rdi,%r14
 1009635:	call   100ba60 <myl_qbe_float_unary>
 100963a:	mov    %r14,%rdi
 100963d:	mov    %rax,%r15
 1009640:	mov    %r13,%rax
 1009643:	mov    -0x320(%rbp),%rcx
 100964a:	mov    %rcx,-0x318(%rbp)
 1009651:	movq   %rcx,%xmm0
 1009656:	ucomisd -0x7fae(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 100965e:	mov    %rax,%r13
 1009661:	movabs $0x3ff0000000000000,%rax
 100966b:	cmovbe %rcx,%rax
 100966f:	movabs $0x406fe00000000000,%rcx
 1009679:	mov    %rcx,-0x318(%rbp)
 1009680:	movq   %rax,%xmm0
 1009685:	mulsd  -0x7fc5(%rip),%xmm0        # 10016c8 <__abi_tag+0x13cc>
 100968d:	movq   %xmm0,%rdx
 1009692:	mov    $0xb,%esi
 1009697:	mov    %rdi,%r14
 100969a:	call   100ba60 <myl_qbe_float_unary>
 100969f:	mov    %r14,%rdi
 10096a2:	mov    %rax,%rcx
 10096a5:	mov    %r13,%rax
 10096a8:	mov    -0x38(%rbp),%r13
 10096ac:	mov    -0x30(%rbp),%r14
 10096b0:	mov    %rax,-0x318(%rbp)
 10096b7:	imul   $0x10000,%rax,%rdx
 10096be:	mov    $0xffffffff,%esi
 10096c3:	mov    %rax,%r10
 10096c6:	and    %rsi,%r10
 10096c9:	mov    %rax,%r9
 10096cc:	shr    $0x20,%r9
 10096d0:	imul   $0x10000,%r10,%rsi
 10096d7:	shr    $0x20,%rsi
 10096db:	imul   $0x10000,%r9,%r8
 10096e2:	add    %rsi,%r8
 10096e5:	mov    $0xffffffff,%esi
 10096ea:	and    %r8,%rsi
 10096ed:	shr    $0x20,%r8
 10096f1:	imul   $0x0,%r10,%r10
 10096f5:	add    %r10,%rsi
 10096f8:	shr    $0x20,%rsi
 10096fc:	imul   $0x0,%r9,%r9
 1009700:	add    %r9,%r8
 1009703:	add    %r8,%rsi
 1009706:	cmp    $0x0,%rax
 100970a:	setl   %r8b
 100970e:	movzbq %r8b,%r8
 1009712:	neg    %r8
 1009715:	mov    %r8,%r9
 1009718:	and    $0x10000,%r9
 100971f:	mov    %rax,%r8
 1009722:	and    $0x0,%r8
 1009726:	sub    %r9,%rsi
 1009729:	sub    %r8,%rsi
 100972c:	mov    %rdx,%r8
 100972f:	sar    $0x3f,%r8
 1009733:	cmp    %rsi,%r8
 1009736:	jne    10098a7 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e27>
 100973c:	mov    %rdx,-0x318(%rbp)
 1009743:	imul   $0x100,%r15,%rsi
 100974a:	mov    $0xffffffff,%eax
 100974f:	mov    %r15,%r10
 1009752:	and    %rax,%r10
 1009755:	mov    %r15,%r9
 1009758:	shr    $0x20,%r9
 100975c:	imul   $0x100,%r10,%rax
 1009763:	shr    $0x20,%rax
 1009767:	imul   $0x100,%r9,%r8
 100976e:	add    %rax,%r8
 1009771:	mov    $0xffffffff,%eax
 1009776:	and    %r8,%rax
 1009779:	shr    $0x20,%r8
 100977d:	imul   $0x0,%r10,%r10
 1009781:	add    %r10,%rax
 1009784:	shr    $0x20,%rax
 1009788:	imul   $0x0,%r9,%r9
 100978c:	add    %r9,%r8
 100978f:	add    %r8,%rax
 1009792:	cmp    $0x0,%r15
 1009796:	setl   %r8b
 100979a:	movzbq %r8b,%r8
 100979e:	neg    %r8
 10097a1:	mov    %r8,%r9
 10097a4:	and    $0x100,%r9
 10097ab:	mov    %r15,%r8
 10097ae:	and    $0x0,%r8
 10097b2:	sub    %r9,%rax
 10097b5:	sub    %r8,%rax
 10097b8:	mov    %rsi,%r8
 10097bb:	sar    $0x3f,%r8
 10097bf:	cmp    %rax,%r8
 10097c2:	jne    100988d <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e0d>
 10097c8:	mov    %rdx,%rax
 10097cb:	add    %rsi,%rax
 10097ce:	mov    %rdx,%r8
 10097d1:	xor    %rax,%r8
 10097d4:	mov    %rsi,%r9
 10097d7:	xor    %rax,%r9
 10097da:	and    %r9,%r8
 10097dd:	cmp    $0x0,%r8
 10097e1:	jl     1009878 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1df8>
 10097e7:	mov    %rax,-0x318(%rbp)
 10097ee:	mov    %rcx,%rdx
 10097f1:	add    %rax,%rdx
 10097f4:	mov    %rax,%rsi
 10097f7:	xor    %rdx,%rsi
 10097fa:	mov    %rcx,%r8
 10097fd:	xor    %rdx,%r8
 1009800:	and    %r8,%rsi
 1009803:	cmp    $0x0,%rsi
 1009807:	jl     1009863 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1de3>
 1009809:	mov    %rdx,-0x318(%rbp)
 1009810:	mov    %rbx,%rsi
 1009813:	mov    %rdi,%rbx
 1009816:	call   1009a90 <myl_f_2f907a6de331cc77376c52e70ba55765a30be18cd9bc69587585fbb71b80de1d>
 100981b:	mov    %rbx,%rdi
 100981e:	mov    %rax,%rbx
 1009821:	movsd  -0x40(%rbp),%xmm0
 1009826:	movq   $0x1,-0x318(%rbp)
 1009831:	movabs $0x7ffffffffffffffe,%rax
 100983b:	cmp    %rax,%r12
 100983e:	jg     1009849 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1dc9>
 1009840:	add    $0x1,%r12
 1009844:	jmp    1009360 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x18e0>
 1009849:	mov    %r12,%rdx
 100984c:	mov    $0x40,%r8d
 1009852:	mov    $0x1,%ecx
 1009857:	mov    $0x0,%esi
 100985c:	call   100b880 <myl_qbe_fail_overflow_op>
 1009861:	ud2
 1009863:	mov    %rax,%rdx
 1009866:	mov    $0x40,%r8d
 100986c:	mov    $0x0,%esi
 1009871:	call   100b880 <myl_qbe_fail_overflow_op>
 1009876:	ud2
 1009878:	mov    %rsi,%rcx
 100987b:	mov    $0x40,%r8d
 1009881:	mov    $0x0,%esi
 1009886:	call   100b880 <myl_qbe_fail_overflow_op>
 100988b:	ud2
 100988d:	mov    %r15,%rdx
 1009890:	mov    $0x40,%r8d
 1009896:	mov    $0x100,%ecx
 100989b:	mov    $0x2,%esi
 10098a0:	call   100b880 <myl_qbe_fail_overflow_op>
 10098a5:	ud2
 10098a7:	mov    %rax,%rdx
 10098aa:	mov    $0x40,%r8d
 10098b0:	mov    $0x10000,%ecx
 10098b5:	mov    $0x2,%esi
 10098ba:	call   100b880 <myl_qbe_fail_overflow_op>
 10098bf:	ud2
 10098c1:	movsd  -0x40(%rbp),%xmm0
 10098c6:	mov    -0x30(%rbp),%r14
 10098ca:	movq   $0x1,-0x318(%rbp)
 10098d5:	movabs $0x7ffffffffffffffe,%rax
 10098df:	cmp    %rax,%r13
 10098e2:	jg     10098ed <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1e6d>
 10098e4:	add    $0x1,%r13
 10098e8:	jmp    1009330 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x18b0>
 10098ed:	mov    %r13,%rdx
 10098f0:	mov    $0x40,%r8d
 10098f6:	mov    $0x1,%ecx
 10098fb:	mov    $0x0,%esi
 1009900:	call   100b880 <myl_qbe_fail_overflow_op>
 1009905:	ud2
 1009907:	mov    %rbx,%r12
 100990a:	mov    -0x50(%rbp),%rbx
 100990e:	mov    -0x48(%rbp),%r13
 1009912:	mov    %r12,-0x318(%rbp)
 1009919:	mov    %r13,%rsi
 100991c:	mov    %rdi,%r12
 100991f:	call   100da20 <myl_qbe_stream_begin>
 1009924:	mov    %r13,%rdx
 1009927:	mov    %r12,%rdi
 100992a:	mov    %rax,%rsi
 100992d:	mov    %rdx,%r14
 1009930:	mov    $0x0,%edx
 1009935:	mov    %rsi,%r13
 1009938:	lea    -0x318(%rbp),%rsi
 100993f:	mov    %rdi,%r12
 1009942:	mov    %r13,%rdi
 1009945:	call   100ad00 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>
 100994a:	mov    %r13,%rsi
 100994d:	mov    %r12,%rdi
 1009950:	mov    %rsi,%r13
 1009953:	mov    $0xa,%esi
 1009958:	mov    %rdi,%r12
 100995b:	mov    %r13,%rdi
 100995e:	call   100d970 <myl_qbe_print_byte>
 1009963:	mov    %r14,%rdx
 1009966:	mov    %r13,%rsi
 1009969:	mov    %r12,%rdi
 100996c:	mov    %rdi,%r12
 100996f:	call   100da60 <myl_qbe_stream_finish>
 1009974:	mov    %r12,%rdi
 1009977:	call   100b540 <myl_qbe_exit_skip>
 100997c:	mov    %rbx,%rdi
 100997f:	cmp    $0x0,%eax
 1009982:	jne    1009a77 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ff7>
 1009988:	mov    -0x368(%rbp),%rcx
 100998f:	cmp    $0x0,%rcx
 1009993:	je     10099f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f78>
 1009995:	mov    %rcx,%rax
 1009998:	sub    $0x10,%rax
 100999c:	mov    (%rax),%rax
 100999f:	movabs $0x4000000000000002,%rdx
 10099a9:	and    %rdx,%rax
 10099ac:	cmp    $0x0,%rax
 10099b0:	jne    10099ed <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f6d>
 10099b2:	mov    %rcx,%rax
 10099b5:	sub    $0x20,%rax
 10099b9:	mov    (%rax),%rax
 10099bc:	sub    $0x1,%rax
 10099c0:	jne    10099e6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f66>
 10099c2:	mov    %rcx,%rdx
 10099c5:	sub    $0x18,%rdx
 10099c9:	mov    (%rdx),%rdx
 10099cc:	cmp    $0x0,%rdx
 10099d0:	jne    10099e6 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f66>
 10099d2:	lea    -0x368(%rbp),%rsi
 10099d9:	mov    %rdi,%rbx
 10099dc:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 10099e1:	mov    %rbx,%rdi
 10099e4:	jmp    10099f8 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1f78>
 10099e6:	sub    $0x20,%rcx
 10099ea:	mov    %rax,(%rcx)
 10099ed:	movq   $0x0,-0x368(%rbp)
 10099f8:	mov    -0x3f0(%rbp),%eax
 10099fe:	cmp    $0x0,%eax
 1009a01:	je     1009a77 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ff7>
 1009a03:	movl   $0x0,-0x3f0(%rbp)
 1009a0d:	mov    -0x370(%rbp),%rcx
 1009a14:	cmp    $0x0,%rcx
 1009a18:	je     1009a77 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ff7>
 1009a1a:	mov    %rcx,%rax
 1009a1d:	sub    $0x10,%rax
 1009a21:	mov    (%rax),%rax
 1009a24:	movabs $0x4000000000000002,%rdx
 1009a2e:	and    %rdx,%rax
 1009a31:	cmp    $0x0,%rax
 1009a35:	jne    1009a6c <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1fec>
 1009a37:	mov    %rcx,%rax
 1009a3a:	sub    $0x20,%rax
 1009a3e:	mov    (%rax),%rax
 1009a41:	sub    $0x1,%rax
 1009a45:	jne    1009a65 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1fe5>
 1009a47:	mov    %rcx,%rdx
 1009a4a:	sub    $0x18,%rdx
 1009a4e:	mov    (%rdx),%rdx
 1009a51:	cmp    $0x0,%rdx
 1009a55:	jne    1009a65 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1fe5>
 1009a57:	lea    -0x370(%rbp),%rsi
 1009a5e:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 1009a63:	jmp    1009a77 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605+0x1ff7>
 1009a65:	sub    $0x20,%rcx
 1009a69:	mov    %rax,(%rcx)
 1009a6c:	movq   $0x0,-0x370(%rbp)
 1009a77:	mov    $0x0,%eax
 1009a7c:	pop    %r15
 1009a7e:	pop    %r14
 1009a80:	pop    %r13
 1009a82:	pop    %r12
 1009a84:	pop    %rbx
 1009a85:	leave
 1009a86:	ret
 1009a87:	call   100ba40 <myl_qbe_fail_frame>
 1009a8c:	ud2
 1009a8e:	int3
 1009a8f:	int3

0000000001009a90 <myl_f_2f907a6de331cc77376c52e70ba55765a30be18cd9bc69587585fbb71b80de1d>:
 1009a90:	endbr64
 1009a94:	push   %rbp
 1009a95:	mov    %rsp,%rbp
 1009a98:	mov    %rdx,%rcx
 1009a9b:	mov    %rsi,%rdx
 1009a9e:	imul   $0x1f,%rdx,%rax
 1009aa2:	mov    $0xffffffff,%esi
 1009aa7:	mov    %rdx,%r10
 1009aaa:	and    %rsi,%r10
 1009aad:	mov    %rdx,%r9
 1009ab0:	shr    $0x20,%r9
 1009ab4:	imul   $0x1f,%r10,%rsi
 1009ab8:	shr    $0x20,%rsi
 1009abc:	imul   $0x1f,%r9,%r8
 1009ac0:	add    %rsi,%r8
 1009ac3:	mov    $0xffffffff,%esi
 1009ac8:	and    %r8,%rsi
 1009acb:	shr    $0x20,%r8
 1009acf:	imul   $0x0,%r10,%r10
 1009ad3:	add    %r10,%rsi
 1009ad6:	shr    $0x20,%rsi
 1009ada:	imul   $0x0,%r9,%r9
 1009ade:	add    %r9,%r8
 1009ae1:	add    %r8,%rsi
 1009ae4:	cmp    $0x0,%rdx
 1009ae8:	setl   %r8b
 1009aec:	movzbq %r8b,%r8
 1009af0:	neg    %r8
 1009af3:	mov    %r8,%r9
 1009af6:	and    $0x1f,%r9
 1009afa:	mov    %rdx,%r8
 1009afd:	and    $0x0,%r8
 1009b01:	sub    %r9,%rsi
 1009b04:	sub    %r8,%rsi
 1009b07:	mov    %rax,%r8
 1009b0a:	sar    $0x3f,%r8
 1009b0e:	cmp    %rsi,%r8
 1009b11:	jne    1009ba5 <myl_f_2f907a6de331cc77376c52e70ba55765a30be18cd9bc69587585fbb71b80de1d+0x115>
 1009b17:	mov    %rax,%rdx
 1009b1a:	mov    %rcx,%rax
 1009b1d:	add    %rdx,%rax
 1009b20:	mov    %rdx,%rsi
 1009b23:	xor    %rax,%rsi
 1009b26:	mov    %rcx,%r8
 1009b29:	xor    %rax,%r8
 1009b2c:	and    %r8,%rsi
 1009b2f:	cmp    $0x0,%rsi
 1009b33:	jl     1009b93 <myl_f_2f907a6de331cc77376c52e70ba55765a30be18cd9bc69587585fbb71b80de1d+0x103>
 1009b35:	movabs $0x8000000000000000,%rcx
 1009b3f:	cmp    %rcx,%rax
 1009b42:	sete   %cl
 1009b45:	movzbq %cl,%rcx
 1009b49:	and    $0x0,%rcx
 1009b4d:	neg    %rcx
 1009b50:	and    $0x3b9aca06,%rcx
 1009b57:	mov    %rcx,%rsi
 1009b5a:	xor    $0x3b9aca07,%rsi
 1009b61:	cqto
 1009b63:	idiv   %rsi
 1009b66:	mov    %rdx,%rcx
 1009b69:	cmp    $0x0,%rcx
 1009b6d:	setne  %al
 1009b70:	movzbq %al,%rax
 1009b74:	mov    %rsi,%rdx
 1009b77:	xor    %rcx,%rdx
 1009b7a:	cmp    $0x0,%rdx
 1009b7e:	setl   %dl
 1009b81:	movzbq %dl,%rdx
 1009b85:	and    %rdx,%rax
 1009b88:	neg    %rax
 1009b8b:	and    %rsi,%rax
 1009b8e:	add    %rcx,%rax
 1009b91:	leave
 1009b92:	ret
 1009b93:	mov    $0x40,%r8d
 1009b99:	mov    $0x0,%esi
 1009b9e:	call   100b880 <myl_qbe_fail_overflow_op>
 1009ba3:	ud2
 1009ba5:	mov    $0x40,%r8d
 1009bab:	mov    $0x1f,%ecx
 1009bb0:	mov    $0x2,%esi
 1009bb5:	call   100b880 <myl_qbe_fail_overflow_op>
 1009bba:	ud2
 1009bbc:	int3
 1009bbd:	int3
 1009bbe:	int3
 1009bbf:	int3

0000000001009bc0 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986>:
 1009bc0:	endbr64
 1009bc4:	push   %rbp
 1009bc5:	mov    %rsp,%rbp
 1009bc8:	sub    $0x58,%rsp
 1009bcc:	push   %rbx
 1009bcd:	push   %r12
 1009bcf:	push   %r13
 1009bd1:	mov    %rcx,%r12
 1009bd4:	mov    %rdx,%r13
 1009bd7:	mov    %rsi,%rdx
 1009bda:	mov    0x40(%rdi),%rax
 1009bde:	lea    -0x18(%rbp),%rcx
 1009be2:	cmp    %rax,%rcx
 1009be5:	jb     1009d3a <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x17a>
 1009beb:	mov    %r12,%rcx
 1009bee:	mov    %rdi,%rsi
 1009bf1:	mov    %rdi,%rbx
 1009bf4:	lea    -0x48(%rbp),%rdi
 1009bf8:	call   1009e80 <myl_f_ddc6e2b224d0fd821669202258386936fc9ce2899e215eec6322b95f8dd96d6a>
 1009bfd:	mov    %r13,%rdx
 1009c00:	mov    %rbx,%rdi
 1009c03:	mov    (%rax),%rcx
 1009c06:	mov    %rcx,-0x30(%rbp)
 1009c0a:	mov    0x8(%rax),%rcx
 1009c0e:	mov    %rcx,-0x28(%rbp)
 1009c12:	mov    0x10(%rax),%rax
 1009c16:	mov    %rax,-0x20(%rbp)
 1009c1a:	lea    -0x30(%rbp),%rsi
 1009c1e:	mov    %rdi,%rbx
 1009c21:	call   100ac00 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>
 1009c26:	mov    %rbx,%rdi
 1009c29:	mov    %rax,%rbx
 1009c2c:	lea    -0x30(%rbp),%rdx
 1009c30:	lea    -0x30(%rbp),%rsi
 1009c34:	mov    %rdi,%r13
 1009c37:	call   100ac00 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>
 1009c3c:	mov    %r13,%rdi
 1009c3f:	mov    %rax,%rcx
 1009c42:	mov    0x18(%r12),%rax
 1009c47:	movq   %rax,%xmm0
 1009c4c:	mulsd  %xmm0,%xmm0
 1009c50:	movq   %xmm0,%rax
 1009c55:	movq   %rcx,%xmm0
 1009c5a:	movq   %rax,%xmm1
 1009c5f:	subsd  %xmm1,%xmm0
 1009c63:	movq   %xmm0,%rax
 1009c68:	movq   %rbx,%xmm0
 1009c6d:	movsd  %xmm0,-0x10(%rbp)
 1009c72:	mulsd  %xmm0,%xmm0
 1009c76:	movq   %xmm0,%rcx
 1009c7b:	movq   %rcx,%xmm0
 1009c80:	movq   %rax,%xmm1
 1009c85:	subsd  %xmm1,%xmm0
 1009c89:	movq   %xmm0,%rdx
 1009c8e:	movq   %rdx,%xmm0
 1009c93:	movsd  -0x85cb(%rip),%xmm1        # 10016d0 <__abi_tag+0x13d4>
 1009c9b:	ucomisd %xmm0,%xmm1
 1009c9f:	ja     1009d1f <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x15f>
 1009ca1:	mov    $0x2,%esi
 1009ca6:	mov    %rdi,%rbx
 1009ca9:	call   100ba60 <myl_qbe_float_unary>
 1009cae:	mov    %rbx,%rdi
 1009cb1:	movsd  -0x10(%rbp),%xmm0
 1009cb6:	xorpd  -0x861e(%rip),%xmm0        # 10016a0 <__abi_tag+0x13a4>
 1009cbe:	addsd  -0x85f6(%rip),%xmm0        # 10016d0 <__abi_tag+0x13d4>
 1009cc6:	movq   %xmm0,%rcx
 1009ccb:	movq   %rcx,%xmm0
 1009cd0:	movq   %rax,%xmm1
 1009cd5:	movsd  %xmm0,%xmm2
 1009cd9:	subsd  %xmm1,%xmm2
 1009cdd:	movq   %xmm2,%rax
 1009ce2:	movq   %rax,%xmm2
 1009ce7:	ucomisd -0x8617(%rip),%xmm2        # 10016d8 <__abi_tag+0x13dc>
 1009cef:	ja     1009d33 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x173>
 1009cf1:	addsd  %xmm1,%xmm0
 1009cf5:	movq   %xmm0,%rax
 1009cfa:	movq   %rax,%xmm0
 1009cff:	ucomisd -0x862f(%rip),%xmm0        # 10016d8 <__abi_tag+0x13dc>
 1009d07:	ja     1009d33 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x173>
 1009d09:	movabs $0x3ff0000000000000,%rdx
 1009d13:	mov    $0x7,%esi
 1009d18:	call   100ba60 <myl_qbe_float_unary>
 1009d1d:	jmp    1009d33 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986+0x173>
 1009d1f:	movabs $0x3ff0000000000000,%rdx
 1009d29:	mov    $0x7,%esi
 1009d2e:	call   100ba60 <myl_qbe_float_unary>
 1009d33:	pop    %r13
 1009d35:	pop    %r12
 1009d37:	pop    %rbx
 1009d38:	leave
 1009d39:	ret
 1009d3a:	call   100ba40 <myl_qbe_fail_frame>
 1009d3f:	ud2
 1009d41:	int3
 1009d42:	int3
 1009d43:	int3
 1009d44:	int3
 1009d45:	int3
 1009d46:	int3
 1009d47:	int3
 1009d48:	int3
 1009d49:	int3
 1009d4a:	int3
 1009d4b:	int3
 1009d4c:	int3
 1009d4d:	int3
 1009d4e:	int3
 1009d4f:	int3

0000000001009d50 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380>:
 1009d50:	endbr64
 1009d54:	push   %rbp
 1009d55:	mov    %rsp,%rbp
 1009d58:	sub    $0x28,%rsp
 1009d5c:	push   %rbx
 1009d5d:	push   %r12
 1009d5f:	push   %r13
 1009d61:	mov    %rdi,%rax
 1009d64:	mov    %rsi,%rdi
 1009d67:	mov    %rax,%rbx
 1009d6a:	mov    0x40(%rdi),%rax
 1009d6e:	lea    -0x8(%rbp),%rcx
 1009d72:	cmp    %rax,%rcx
 1009d75:	jb     1009de9 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380+0x99>
 1009d77:	mov    %rdx,%r13
 1009d7a:	mov    %r13,%rsi
 1009d7d:	mov    %rdi,%r12
 1009d80:	call   100ac00 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>
 1009d85:	mov    %r12,%rdi
 1009d88:	mov    %rax,%rdx
 1009d8b:	mov    $0x2,%esi
 1009d90:	mov    %rdi,%r12
 1009d93:	call   100ba60 <myl_qbe_float_unary>
 1009d98:	mov    %r13,%rdx
 1009d9b:	mov    %r12,%rdi
 1009d9e:	movq   %rax,%xmm0
 1009da3:	movsd  %xmm0,%xmm15
 1009da8:	movsd  -0x8700(%rip),%xmm0        # 10016b0 <__abi_tag+0x13b4>
 1009db0:	divsd  %xmm15,%xmm0
 1009db5:	movq   %xmm0,%rcx
 1009dba:	mov    %rdi,%rsi
 1009dbd:	lea    -0x20(%rbp),%rdi
 1009dc1:	call   100ac80 <myl_f_f469802a31447f90d6a033d43f18db7ebfbee7cc3c378024bcc0f1573d3feef8>
 1009dc6:	mov    %rax,%rcx
 1009dc9:	mov    %rbx,%rax
 1009dcc:	mov    (%rcx),%rdx
 1009dcf:	mov    %rdx,(%rax)
 1009dd2:	mov    0x8(%rcx),%rdx
 1009dd6:	mov    %rdx,0x8(%rax)
 1009dda:	mov    0x10(%rcx),%rcx
 1009dde:	mov    %rcx,0x10(%rax)
 1009de2:	pop    %r13
 1009de4:	pop    %r12
 1009de6:	pop    %rbx
 1009de7:	leave
 1009de8:	ret
 1009de9:	call   100ba40 <myl_qbe_fail_frame>
 1009dee:	ud2

0000000001009df0 <myl_f_7e9e5ac30f2216fd0fd6f5faed316f2d5983361a4203c3330cfa46ef65bb4767>:
 1009df0:	endbr64
 1009df4:	push   %rbp
 1009df5:	mov    %rsp,%rbp
 1009df8:	sub    $0x20,%rsp
 1009dfc:	mov    %rdi,%rax
 1009dff:	mov    %rdx,%rdi
 1009e02:	mov    (%rdi),%rsi
 1009e05:	mov    (%rcx),%rdx
 1009e08:	movq   %rsi,%xmm0
 1009e0d:	movq   %rdx,%xmm1
 1009e12:	addsd  %xmm1,%xmm0
 1009e16:	movq   %xmm0,%rsi
 1009e1b:	mov    0x8(%rdi),%r8
 1009e1f:	mov    0x8(%rcx),%rdx
 1009e23:	movq   %r8,%xmm0
 1009e28:	movq   %rdx,%xmm1
 1009e2d:	addsd  %xmm1,%xmm0
 1009e31:	movq   %xmm0,%rdx
 1009e36:	mov    0x10(%rdi),%rdi
 1009e3a:	mov    0x10(%rcx),%rcx
 1009e3e:	movq   %rdi,%xmm0
 1009e43:	movq   %rcx,%xmm1
 1009e48:	addsd  %xmm1,%xmm0
 1009e4c:	movq   %xmm0,%rcx
 1009e51:	mov    %rsi,-0x18(%rbp)
 1009e55:	mov    %rdx,-0x10(%rbp)
 1009e59:	mov    %rcx,-0x8(%rbp)
 1009e5d:	mov    -0x18(%rbp),%rcx
 1009e61:	mov    %rcx,(%rax)
 1009e64:	mov    -0x10(%rbp),%rcx
 1009e68:	mov    %rcx,0x8(%rax)
 1009e6c:	mov    -0x8(%rbp),%rcx
 1009e70:	mov    %rcx,0x10(%rax)
 1009e74:	leave
 1009e75:	ret
 1009e76:	int3
 1009e77:	int3
 1009e78:	int3
 1009e79:	int3
 1009e7a:	int3
 1009e7b:	int3
 1009e7c:	int3
 1009e7d:	int3
 1009e7e:	int3
 1009e7f:	int3

0000000001009e80 <myl_f_ddc6e2b224d0fd821669202258386936fc9ce2899e215eec6322b95f8dd96d6a>:
 1009e80:	endbr64
 1009e84:	push   %rbp
 1009e85:	mov    %rsp,%rbp
 1009e88:	sub    $0x20,%rsp
 1009e8c:	mov    %rdi,%rax
 1009e8f:	mov    %rdx,%rdi
 1009e92:	mov    (%rdi),%rsi
 1009e95:	mov    (%rcx),%rdx
 1009e98:	movq   %rsi,%xmm0
 1009e9d:	movq   %rdx,%xmm1
 1009ea2:	subsd  %xmm1,%xmm0
 1009ea6:	movq   %xmm0,%rsi
 1009eab:	mov    0x8(%rdi),%r8
 1009eaf:	mov    0x8(%rcx),%rdx
 1009eb3:	movq   %r8,%xmm0
 1009eb8:	movq   %rdx,%xmm1
 1009ebd:	subsd  %xmm1,%xmm0
 1009ec1:	movq   %xmm0,%rdx
 1009ec6:	mov    0x10(%rdi),%rdi
 1009eca:	mov    0x10(%rcx),%rcx
 1009ece:	movq   %rdi,%xmm0
 1009ed3:	movq   %rcx,%xmm1
 1009ed8:	subsd  %xmm1,%xmm0
 1009edc:	movq   %xmm0,%rcx
 1009ee1:	mov    %rsi,-0x18(%rbp)
 1009ee5:	mov    %rdx,-0x10(%rbp)
 1009ee9:	mov    %rcx,-0x8(%rbp)
 1009eed:	mov    -0x18(%rbp),%rcx
 1009ef1:	mov    %rcx,(%rax)
 1009ef4:	mov    -0x10(%rbp),%rcx
 1009ef8:	mov    %rcx,0x8(%rax)
 1009efc:	mov    -0x8(%rbp),%rcx
 1009f00:	mov    %rcx,0x10(%rax)
 1009f04:	leave
 1009f05:	ret
 1009f06:	int3
 1009f07:	int3
 1009f08:	int3
 1009f09:	int3
 1009f0a:	int3
 1009f0b:	int3
 1009f0c:	int3
 1009f0d:	int3
 1009f0e:	int3
 1009f0f:	int3

0000000001009f10 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814>:
 1009f10:	endbr64
 1009f14:	push   %rbp
 1009f15:	mov    %rsp,%rbp
 1009f18:	sub    $0x238,%rsp
 1009f1f:	push   %rbx
 1009f20:	push   %r12
 1009f22:	push   %r13
 1009f24:	push   %r14
 1009f26:	push   %r15
 1009f28:	mov    %r9,-0x28(%rbp)
 1009f2c:	mov    %r8,%r15
 1009f2f:	mov    %rcx,%r13
 1009f32:	mov    %rdx,%r14
 1009f35:	mov    %rdi,%rbx
 1009f38:	mov    %rsi,%rdi
 1009f3b:	mov    %r15,-0x30(%rbp)
 1009f3f:	mov    %r13,-0x18(%rbp)
 1009f43:	mov    %r14,-0x20(%rbp)
 1009f47:	mov    %rbx,-0x48(%rbp)
 1009f4b:	movq   $0x0,-0x150(%rbp)
 1009f56:	movq   $0x0,-0x130(%rbp)
 1009f61:	movq   $0x0,-0x110(%rbp)
 1009f6c:	mov    0x40(%rdi),%rax
 1009f70:	lea    -0x58(%rbp),%rcx
 1009f74:	cmp    %rax,%rcx
 1009f77:	setb   %al
 1009f7a:	movzbq %al,%rax
 1009f7e:	mov    $0x0,%ecx
 1009f83:	mov    %ecx,-0x10(%rbp)
 1009f86:	mov    $0x0,%esi
 1009f8b:	mov    %esi,-0xc(%rbp)
 1009f8e:	mov    $0x0,%esi
 1009f93:	mov    %esi,-0x34(%rbp)
 1009f96:	cmp    $0x0,%eax
 1009f99:	jne    100abf9 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xce9>
 1009f9f:	movq   $0x0,-0xf0(%rbp)
 1009faa:	movq   $0x0,-0xe8(%rbp)
 1009fb5:	movq   $0x0,-0x78(%rbp)
 1009fbd:	mov    %rdi,%r12
 1009fc0:	call   100ba30 <myl_qbe_heap>
 1009fc5:	mov    %r12,%rdi
 1009fc8:	mov    %rax,-0x40(%rbp)
 1009fcc:	mov    %rdi,%r12
 1009fcf:	call   100d960 <myl_qbe_region_mark>
 1009fd4:	mov    %r13,%rdx
 1009fd7:	mov    %r12,%rdi
 1009fda:	mov    %rdx,%r13
 1009fdd:	movabs $0x3ff0000000000000,%rdx
 1009fe7:	mov    $0x7,%esi
 1009fec:	mov    %rdi,%r12
 1009fef:	call   100ba60 <myl_qbe_float_unary>
 1009ff4:	mov    %r15,%r8
 1009ff7:	mov    %r13,%rdx
 1009ffa:	mov    %r12,%rdi
 1009ffd:	mov    %rax,%rcx
 100a000:	mov    %rbx,%rax
 100a003:	mov    -0xc(%rbp),%esi
 100a006:	mov    %rax,%rbx
 100a009:	mov    -0x10(%rbp),%eax
 100a00c:	mov    -0x40(%rbp),%r12
 100a010:	cmp    $0x0,%r8
 100a014:	setne  %r9b
 100a018:	movzbl %r9b,%r9d
 100a01c:	cmp    $0x0,%r9d
 100a020:	jne    100a02d <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x11d>
 100a022:	mov    %r8,%r15
 100a025:	mov    %rdi,%rbx
 100a028:	mov    %r12,%rdi
 100a02b:	jmp    100a08a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x17a>
 100a02d:	mov    %r8,%r9
 100a030:	sub    $0x10,%r9
 100a034:	mov    (%r9),%r9
 100a037:	movabs $0x4000000000000002,%r10
 100a041:	and    %r10,%r9
 100a044:	cmp    $0x0,%r9
 100a048:	jne    100a081 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x171>
 100a04a:	mov    %r8,%r15
 100a04d:	sub    $0x18,%r8
 100a051:	mov    (%r8),%r8
 100a054:	add    $0x1,%r8
 100a058:	je     100a06c <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x15c>
 100a05a:	mov    %r12,%rbx
 100a05d:	mov    %r15,%r9
 100a060:	sub    $0x18,%r9
 100a064:	mov    %r8,(%r9)
 100a067:	xchg   %rdi,%rbx
 100a06a:	jmp    100a08a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x17a>
 100a06c:	mov    $0x2,%esi
 100a071:	call   100b0c0 <myl_qbe_rc_status>
 100a076:	mov    %rbx,%rax
 100a079:	mov    %rax,%rbx
 100a07c:	jmp    100a561 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x651>
 100a081:	mov    %r8,%r15
 100a084:	mov    %rdi,%rbx
 100a087:	mov    %r12,%rdi
 100a08a:	cmp    $0x0,%esi
 100a08d:	jne    100a09a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x18a>
 100a08f:	mov    %r15,%r8
 100a092:	mov    %rbx,%rdi
 100a095:	jmp    100a1cf <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2bf>
 100a09a:	test   $0x1c,%eax
 100a09f:	jne    100a131 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x221>
 100a0a5:	mov    -0x1a0(%rbp),%rsi
 100a0ac:	cmp    $0x0,%rsi
 100a0b0:	je     100a126 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x216>
 100a0b2:	mov    %rsi,%rax
 100a0b5:	sub    $0x10,%rax
 100a0b9:	mov    (%rax),%rax
 100a0bc:	mov    %rdx,%r12
 100a0bf:	movabs $0x4000000000000002,%rdx
 100a0c9:	and    %rdx,%rax
 100a0cc:	cmp    $0x0,%rax
 100a0d0:	jne    100a118 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x208>
 100a0d2:	mov    %rsi,%rax
 100a0d5:	sub    $0x20,%rax
 100a0d9:	mov    (%rax),%rax
 100a0dc:	sub    $0x1,%rax
 100a0e0:	jne    100a10c <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x1fc>
 100a0e2:	mov    %rcx,%r13
 100a0e5:	mov    %rsi,%rcx
 100a0e8:	sub    $0x18,%rcx
 100a0ec:	mov    (%rcx),%rcx
 100a0ef:	cmp    $0x0,%rcx
 100a0f3:	jne    100a109 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x1f9>
 100a0f5:	lea    -0x1a0(%rbp),%rsi
 100a0fc:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 100a101:	mov    %r13,%rcx
 100a104:	mov    %r12,%rdx
 100a107:	jmp    100a126 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x216>
 100a109:	mov    %r13,%rcx
 100a10c:	mov    %r12,%rdx
 100a10f:	sub    $0x20,%rsi
 100a113:	mov    %rax,(%rsi)
 100a116:	jmp    100a11b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x20b>
 100a118:	mov    %r12,%rdx
 100a11b:	movq   $0x0,-0x1a0(%rbp)
 100a126:	mov    %r15,%r8
 100a129:	mov    %rbx,%rdi
 100a12c:	jmp    100a1cf <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2bf>
 100a131:	mov    -0x1a0(%rbp),%rsi
 100a138:	cmp    $0x0,%rsi
 100a13c:	jne    100a149 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x239>
 100a13e:	mov    %r15,%r8
 100a141:	mov    %rbx,%rdi
 100a144:	jmp    100a1cf <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2bf>
 100a149:	mov    %rsi,%rax
 100a14c:	sub    $0x10,%rax
 100a150:	mov    (%rax),%rax
 100a153:	mov    %rdx,%r12
 100a156:	movabs $0x4000000000000002,%rdx
 100a160:	and    %rdx,%rax
 100a163:	cmp    $0x0,%rax
 100a167:	jne    100a1bb <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2ab>
 100a169:	mov    %rsi,%rax
 100a16c:	sub    $0x18,%rax
 100a170:	mov    (%rax),%rax
 100a173:	sub    $0x1,%rax
 100a177:	jne    100a1a9 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x299>
 100a179:	mov    %rcx,%r13
 100a17c:	mov    %rsi,%rcx
 100a17f:	sub    $0x20,%rcx
 100a183:	mov    (%rcx),%rcx
 100a186:	cmp    $0x0,%rcx
 100a18a:	jne    100a1a6 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x296>
 100a18c:	lea    -0x1a0(%rbp),%rsi
 100a193:	call   100ad10 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100a198:	mov    %r15,%r8
 100a19b:	mov    %r13,%rcx
 100a19e:	mov    %r12,%rdx
 100a1a1:	mov    %rbx,%rdi
 100a1a4:	jmp    100a1cf <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2bf>
 100a1a6:	mov    %r13,%rcx
 100a1a9:	mov    %r12,%rdx
 100a1ac:	mov    %r15,%r8
 100a1af:	mov    %rbx,%rdi
 100a1b2:	sub    $0x18,%rsi
 100a1b6:	mov    %rax,(%rsi)
 100a1b9:	jmp    100a1c4 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x2b4>
 100a1bb:	mov    %r15,%r8
 100a1be:	mov    %r12,%rdx
 100a1c1:	mov    %rbx,%rdi
 100a1c4:	movq   $0x0,-0x1a0(%rbp)
 100a1cf:	mov    %r8,-0x1a0(%rbp)
 100a1d6:	mov    %r8,-0xf0(%rbp)
 100a1dd:	mov    (%r8),%rsi
 100a1e0:	movabs $0x7fffffffffffffff,%rax
 100a1ea:	cmp    %rax,%rsi
 100a1ed:	ja     100abed <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcdd>
 100a1f3:	mov    %rsi,%rbx
 100a1f6:	mov    %rdi,%rsi
 100a1f9:	mov    %rcx,%r13
 100a1fc:	mov    %rdx,%rcx
 100a1ff:	mov    %r14,%rdx
 100a202:	mov    $0xffffffffffffffff,%r12
 100a209:	mov    $0x0,%r14d
 100a20f:	nop
 100a210:	cmp    %rbx,%r14
 100a213:	setl   %al
 100a216:	movzbq %al,%rax
 100a21a:	cmp    $0x0,%eax
 100a21d:	je     100a31a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x40a>
 100a223:	mov    (%r8),%rax
 100a226:	cmp    %rax,%rbx
 100a229:	jne    100a310 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x400>
 100a22f:	cmp    %rax,%r14
 100a232:	jae    100a300 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x3f0>
 100a238:	mov    0x20(%r8),%rax
 100a23c:	mov    %rcx,%r15
 100a23f:	imul   $0x38,%r14,%rcx
 100a243:	add    %rax,%rcx
 100a246:	mov    %rdx,%rax
 100a249:	mov    %r15,%rdx
 100a24c:	mov    %rsi,%r15
 100a24f:	mov    %rax,%rsi
 100a252:	mov    %r15,%rdi
 100a255:	call   1009bc0 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986>
 100a25a:	mov    %r15,%rsi
 100a25d:	mov    -0x18(%rbp),%rcx
 100a261:	mov    -0x20(%rbp),%rdx
 100a265:	movq   %rax,%xmm0
 100a26a:	ucomisd -0x8ba2(%rip),%xmm0        # 10016d0 <__abi_tag+0x13d4>
 100a272:	ja     100a27b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x36b>
 100a274:	mov    $0x0,%edi
 100a279:	jmp    100a2a4 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x394>
 100a27b:	cmp    $0x0,%r12
 100a27f:	setl   %dil
 100a283:	movzbq %dil,%rdi
 100a287:	movq   %r13,%xmm1
 100a28c:	ucomisd %xmm0,%xmm1
 100a290:	seta   %r8b
 100a294:	movzbq %r8b,%r8
 100a298:	cmp    $0x0,%edi
 100a29b:	mov    $0x1,%edi
 100a2a0:	cmove  %r8,%rdi
 100a2a4:	cmp    $0x0,%edi
 100a2a7:	cmovne %r14,%r12
 100a2ab:	cmovne %rax,%r13
 100a2af:	mov    -0xf0(%rbp),%r8
 100a2b6:	mov    (%r8),%rax
 100a2b9:	cmp    %rax,%rbx
 100a2bc:	jne    100a2f6 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x3e6>
 100a2be:	movabs $0x7ffffffffffffffe,%rax
 100a2c8:	cmp    %rax,%r14
 100a2cb:	jg     100a2d6 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x3c6>
 100a2cd:	add    $0x1,%r14
 100a2d1:	jmp    100a210 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x300>
 100a2d6:	mov    %rsi,%rdi
 100a2d9:	mov    %r14,%rsi
 100a2dc:	mov    $0x40,%r8d
 100a2e2:	mov    $0x1,%ecx
 100a2e7:	mov    %rsi,%rdx
 100a2ea:	mov    $0x0,%esi
 100a2ef:	call   100b880 <myl_qbe_fail_overflow_op>
 100a2f4:	ud2
 100a2f6:	mov    %rsi,%rdi
 100a2f9:	call   100b7f0 <myl_qbe_fail_iteration>
 100a2fe:	ud2
 100a300:	mov    %rax,%rdx
 100a303:	mov    %rsi,%rdi
 100a306:	mov    %r14,%rsi
 100a309:	call   100b810 <myl_qbe_fail_normalized_index_bounds>
 100a30e:	ud2
 100a310:	mov    %rsi,%rdi
 100a313:	call   100b7f0 <myl_qbe_fail_iteration>
 100a318:	ud2
 100a31a:	mov    -0x48(%rbp),%rax
 100a31e:	mov    -0x40(%rbp),%rbx
 100a322:	mov    -0x28(%rbp),%r15
 100a326:	mov    -0x30(%rbp),%r8
 100a32a:	mov    %rdx,%r14
 100a32d:	mov    %rcx,%rdx
 100a330:	mov    %r13,%rcx
 100a333:	mov    %rsi,%rdi
 100a336:	mov    -0x34(%rbp),%esi
 100a339:	cmp    $0x0,%r12
 100a33d:	jl     100aaca <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xbba>
 100a343:	cmp    $0x0,%esi
 100a346:	jne    100a362 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x452>
 100a348:	mov    %r8,-0xe8(%rbp)
 100a34f:	movl   $0x0,-0x4c(%rbp)
 100a356:	movl   $0x2,-0x50(%rbp)
 100a35d:	mov    %esi,-0x38(%rbp)
 100a360:	jmp    100a37e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x46e>
 100a362:	mov    %r8,-0xe8(%rbp)
 100a369:	movl   $0x1,-0x4c(%rbp)
 100a370:	movl   $0x8,-0x50(%rbp)
 100a377:	movl   $0x0,-0x38(%rbp)
 100a37e:	mov    %r12,%rsi
 100a381:	mov    (%r8),%r9
 100a384:	cmp    %r9,%rsi
 100a387:	jb     100a393 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x483>
 100a389:	mov    %r9,%rdx
 100a38c:	call   100b810 <myl_qbe_fail_normalized_index_bounds>
 100a391:	ud2
 100a393:	mov    %rax,%rbx
 100a396:	mov    0x20(%r8),%rax
 100a39a:	imul   $0x38,%rsi,%rsi
 100a39e:	mov    (%rax,%rsi,1),%r9
 100a3a2:	mov    %r9,-0xe0(%rbp)
 100a3a9:	mov    0x8(%rax,%rsi,1),%r9
 100a3ae:	mov    %r9,-0xd8(%rbp)
 100a3b5:	mov    0x10(%rax,%rsi,1),%r9
 100a3ba:	mov    %r9,-0xd0(%rbp)
 100a3c1:	mov    0x18(%rax,%rsi,1),%r9
 100a3c6:	mov    %r9,-0xc8(%rbp)
 100a3cd:	mov    0x20(%rax,%rsi,1),%r9
 100a3d2:	mov    %r9,-0xc0(%rbp)
 100a3d9:	mov    %r8,%r12
 100a3dc:	mov    0x28(%rax,%rsi,1),%r8
 100a3e1:	mov    %r8,-0xb8(%rbp)
 100a3e8:	mov    0x30(%rax,%rsi,1),%rax
 100a3ed:	mov    %rax,-0xb0(%rbp)
 100a3f4:	mov    %rdi,%rsi
 100a3f7:	mov    %rdi,%r13
 100a3fa:	lea    -0x1e8(%rbp),%rdi
 100a401:	call   100ac80 <myl_f_f469802a31447f90d6a033d43f18db7ebfbee7cc3c378024bcc0f1573d3feef8>
 100a406:	mov    %r14,%rdx
 100a409:	mov    %r13,%rdi
 100a40c:	mov    %rax,%rcx
 100a40f:	mov    -0x40(%rbp),%r14
 100a413:	mov    %rdi,%rsi
 100a416:	mov    %rdi,%r13
 100a419:	lea    -0x200(%rbp),%rdi
 100a420:	call   1009df0 <myl_f_7e9e5ac30f2216fd0fd6f5faed316f2d5983361a4203c3330cfa46ef65bb4767>
 100a425:	mov    %r13,%rdi
 100a428:	mov    (%rax),%rcx
 100a42b:	mov    %rcx,-0xa8(%rbp)
 100a432:	mov    0x8(%rax),%rcx
 100a436:	mov    %rcx,-0xa0(%rbp)
 100a43d:	mov    0x10(%rax),%rax
 100a441:	mov    %rax,-0x98(%rbp)
 100a448:	lea    -0xe0(%rbp),%rcx
 100a44f:	lea    -0xa8(%rbp),%rdx
 100a456:	mov    %rdi,%rsi
 100a459:	mov    %rdi,%r13
 100a45c:	lea    -0x218(%rbp),%rdi
 100a463:	call   1009e80 <myl_f_ddc6e2b224d0fd821669202258386936fc9ce2899e215eec6322b95f8dd96d6a>
 100a468:	mov    %r13,%rdi
 100a46b:	mov    %rax,%rdx
 100a46e:	mov    %rdi,%rsi
 100a471:	mov    %rdi,%r13
 100a474:	lea    -0x230(%rbp),%rdi
 100a47b:	call   1009d50 <myl_f_768207cf3cf6d5aa36cd8942d06c7cf72a078060d1fede08ee9dc07bbae1d380>
 100a480:	mov    %r13,%rdi
 100a483:	mov    (%rax),%rcx
 100a486:	mov    %rcx,-0x90(%rbp)
 100a48d:	mov    0x8(%rax),%rcx
 100a491:	mov    %rcx,-0x88(%rbp)
 100a498:	mov    0x10(%rax),%rax
 100a49c:	mov    %rax,-0x80(%rbp)
 100a4a0:	mov    %r15,%rdx
 100a4a3:	lea    -0x90(%rbp),%rsi
 100a4aa:	mov    %rdi,%r13
 100a4ad:	call   100ac00 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>
 100a4b2:	mov    %r13,%rdi
 100a4b5:	mov    %rax,%rdx
 100a4b8:	mov    %rbx,%rax
 100a4bb:	mov    %rax,%rbx
 100a4be:	mov    -0x38(%rbp),%eax
 100a4c1:	movq   %rdx,%xmm0
 100a4c6:	movsd  -0x8dfe(%rip),%xmm1        # 10016d0 <__abi_tag+0x13d4>
 100a4ce:	ucomisd %xmm0,%xmm1
 100a4d2:	mov    $0x0,%ecx
 100a4d7:	mov    %rcx,%r13
 100a4da:	cmovbe %rdx,%r13
 100a4de:	movq   %r13,%xmm0
 100a4e3:	ucomisd -0x8e1b(%rip),%xmm0        # 10016d0 <__abi_tag+0x13d4>
 100a4eb:	ja     100a507 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x5f7>
 100a4ed:	mov    %rbx,%rax
 100a4f0:	mov    $0x0,%r15d
 100a4f6:	mov    %r13,%rbx
 100a4f9:	mov    %r14,%r13
 100a4fc:	mov    $0x2,%r14d
 100a502:	jmp    100a763 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x853>
 100a507:	cmp    $0x0,%r12
 100a50b:	jne    100a518 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x608>
 100a50d:	mov    %rdi,%rbx
 100a510:	mov    %r14,%rdi
 100a513:	jmp    100a5a5 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x695>
 100a518:	mov    %r12,%rcx
 100a51b:	sub    $0x10,%rcx
 100a51f:	mov    (%rcx),%rcx
 100a522:	movabs $0x4000000000000002,%rdx
 100a52c:	and    %rdx,%rcx
 100a52f:	cmp    $0x0,%rcx
 100a533:	jne    100a59f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x68f>
 100a535:	mov    %r12,%rcx
 100a538:	sub    $0x18,%rcx
 100a53c:	mov    (%rcx),%rcx
 100a53f:	add    $0x1,%rcx
 100a543:	je     100a557 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x647>
 100a545:	mov    %r14,%rbx
 100a548:	mov    %r12,%rdx
 100a54b:	sub    $0x18,%rdx
 100a54f:	mov    %rcx,(%rdx)
 100a552:	xchg   %rdi,%rbx
 100a555:	jmp    100a5a5 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x695>
 100a557:	mov    $0x2,%esi
 100a55c:	call   100b0c0 <myl_qbe_rc_status>
 100a561:	mov    $0x18,%edx
 100a566:	mov    $0x0,%esi
 100a56b:	lea    -0x1b8(%rbp),%rdi
 100a572:	call   101e6b0 <compiler_rt.fastMemset>
 100a577:	mov    %rbx,%rax
 100a57a:	mov    -0x1b8(%rbp),%rcx
 100a581:	mov    %rcx,(%rax)
 100a584:	mov    -0x1b0(%rbp),%rcx
 100a58b:	mov    %rcx,0x8(%rax)
 100a58f:	mov    -0x1a8(%rbp),%rcx
 100a596:	mov    %rcx,0x10(%rax)
 100a59a:	jmp    100abe2 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcd2>
 100a59f:	mov    %rdi,%rbx
 100a5a2:	mov    %r14,%rdi
 100a5a5:	cmp    $0x0,%eax
 100a5a8:	jne    100a5b5 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x6a5>
 100a5aa:	mov    %r12,%r8
 100a5ad:	mov    %rbx,%rdi
 100a5b0:	jmp    100a63b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x72b>
 100a5b5:	mov    -0x1a0(%rbp),%rcx
 100a5bc:	cmp    $0x0,%rcx
 100a5c0:	jne    100a5ca <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x6ba>
 100a5c2:	mov    %r12,%r8
 100a5c5:	mov    %rbx,%rdi
 100a5c8:	jmp    100a63b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x72b>
 100a5ca:	mov    %rcx,%rax
 100a5cd:	sub    $0x10,%rax
 100a5d1:	mov    (%rax),%rax
 100a5d4:	movabs $0x4000000000000002,%rdx
 100a5de:	and    %rdx,%rax
 100a5e1:	cmp    $0x0,%rax
 100a5e5:	jne    100a62a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x71a>
 100a5e7:	mov    %rcx,%rax
 100a5ea:	sub    $0x18,%rax
 100a5ee:	mov    (%rax),%rax
 100a5f1:	sub    $0x1,%rax
 100a5f5:	jne    100a61b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x70b>
 100a5f7:	mov    %rcx,%rdx
 100a5fa:	sub    $0x20,%rdx
 100a5fe:	mov    (%rdx),%rdx
 100a601:	cmp    $0x0,%rdx
 100a605:	jne    100a61b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x70b>
 100a607:	lea    -0x1a0(%rbp),%rsi
 100a60e:	call   100ad10 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100a613:	mov    %r12,%r8
 100a616:	mov    %rbx,%rdi
 100a619:	jmp    100a63b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x72b>
 100a61b:	mov    %r12,%r8
 100a61e:	mov    %rbx,%rdi
 100a621:	sub    $0x18,%rcx
 100a625:	mov    %rax,(%rcx)
 100a628:	jmp    100a630 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x720>
 100a62a:	mov    %r12,%r8
 100a62d:	mov    %rbx,%rdi
 100a630:	movq   $0x0,-0x1a0(%rbp)
 100a63b:	mov    %r8,-0x1a0(%rbp)
 100a642:	mov    %r8,-0x78(%rbp)
 100a646:	mov    (%r8),%rsi
 100a649:	movabs $0x7fffffffffffffff,%rax
 100a653:	cmp    %rax,%rsi
 100a656:	ja     100aabe <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xbae>
 100a65c:	mov    %rsi,%rbx
 100a65f:	mov    %rdi,%rsi
 100a662:	mov    $0x0,%r12d
 100a668:	nopl   0x0(%rax,%rax,1)
 100a670:	cmp    %rbx,%r12
 100a673:	jge    100a749 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x839>
 100a679:	mov    (%r8),%rax
 100a67c:	cmp    %rax,%rbx
 100a67f:	jne    100a73f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x82f>
 100a685:	cmp    %rax,%r12
 100a688:	jae    100a72f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x81f>
 100a68e:	mov    0x20(%r8),%rax
 100a692:	imul   $0x38,%r12,%rcx
 100a696:	add    %rax,%rcx
 100a699:	mov    %r15,%rdx
 100a69c:	mov    %rsi,%r14
 100a69f:	lea    -0xa8(%rbp),%rsi
 100a6a6:	mov    %r14,%rdi
 100a6a9:	call   1009bc0 <myl_f_4780c43f8dcb1870d529a9d0bbb716ca1a76dd08c556ec34844b7addb803b986>
 100a6ae:	mov    %r15,%r9
 100a6b1:	mov    %r14,%rsi
 100a6b4:	movq   %rax,%xmm0
 100a6b9:	ucomisd -0x8ff1(%rip),%xmm0        # 10016d0 <__abi_tag+0x13d4>
 100a6c1:	ja     100a711 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x801>
 100a6c3:	mov    -0x78(%rbp),%r8
 100a6c7:	mov    (%r8),%rax
 100a6ca:	cmp    %rax,%rbx
 100a6cd:	jne    100a707 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x7f7>
 100a6cf:	movabs $0x7ffffffffffffffe,%rax
 100a6d9:	cmp    %rax,%r12
 100a6dc:	jg     100a6e7 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x7d7>
 100a6de:	add    $0x1,%r12
 100a6e2:	mov    %r9,%r15
 100a6e5:	jmp    100a670 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x760>
 100a6e7:	mov    %rsi,%rdi
 100a6ea:	mov    %r12,%rsi
 100a6ed:	mov    $0x40,%r8d
 100a6f3:	mov    $0x1,%ecx
 100a6f8:	mov    %rsi,%rdx
 100a6fb:	mov    $0x0,%esi
 100a700:	call   100b880 <myl_qbe_fail_overflow_op>
 100a705:	ud2
 100a707:	mov    %rsi,%rdi
 100a70a:	call   100b7f0 <myl_qbe_fail_iteration>
 100a70f:	ud2
 100a711:	mov    -0x48(%rbp),%rax
 100a715:	mov    -0x40(%rbp),%r13
 100a719:	mov    %rsi,%rdi
 100a71c:	mov    $0x1,%r15d
 100a722:	mov    $0x8,%r14d
 100a728:	mov    $0x0,%ebx
 100a72d:	jmp    100a763 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x853>
 100a72f:	mov    %rax,%rdx
 100a732:	mov    %rsi,%rdi
 100a735:	mov    %r12,%rsi
 100a738:	call   100b810 <myl_qbe_fail_normalized_index_bounds>
 100a73d:	ud2
 100a73f:	mov    %rsi,%rdi
 100a742:	call   100b7f0 <myl_qbe_fail_iteration>
 100a747:	ud2
 100a749:	mov    -0x48(%rbp),%rax
 100a74d:	mov    %rsi,%rdi
 100a750:	mov    $0x1,%r15d
 100a756:	mov    $0x8,%r14d
 100a75c:	mov    %r13,%rbx
 100a75f:	mov    -0x40(%rbp),%r13
 100a763:	lea    -0xe0(%rbp),%rcx
 100a76a:	mov    %rcx,%rdx
 100a76d:	add    $0x20,%rdx
 100a771:	movq   %rbx,%xmm0
 100a776:	mulsd  -0x9096(%rip),%xmm0        # 10016e8 <__abi_tag+0x13ec>
 100a77e:	mov    %rax,%rbx
 100a781:	movq   %xmm0,%rax
 100a786:	movq   %rax,%xmm0
 100a78b:	addsd  -0x90b3(%rip),%xmm0        # 10016e0 <__abi_tag+0x13e4>
 100a793:	movq   %xmm0,%rcx
 100a798:	mov    %rdi,%rsi
 100a79b:	mov    %rdi,%r12
 100a79e:	lea    -0x1d0(%rbp),%rdi
 100a7a5:	call   100ac80 <myl_f_f469802a31447f90d6a033d43f18db7ebfbee7cc3c378024bcc0f1573d3feef8>
 100a7aa:	mov    %r12,%rdi
 100a7ad:	xchg   %rax,%rbx
 100a7af:	mov    -0x4c(%rbp),%ecx
 100a7b2:	mov    -0x50(%rbp),%r12d
 100a7b6:	mov    -0x150(%rbp),%edx
 100a7bc:	mov    -0x130(%rbp),%esi
 100a7c2:	or     %esi,%edx
 100a7c4:	mov    -0x110(%rbp),%esi
 100a7ca:	or     %esi,%edx
 100a7cc:	jne    100a7d6 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x8c6>
 100a7ce:	mov    %r13,%rdi
 100a7d1:	mov    %ecx,%r13d
 100a7d4:	jmp    100a822 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x912>
 100a7d6:	lea    -0x168(%rbp),%rcx
 100a7dd:	mov    %rcx,-0x108(%rbp)
 100a7e4:	lea    -0x148(%rbp),%rcx
 100a7eb:	mov    %rcx,-0x100(%rbp)
 100a7f2:	mov    %rax,%r12
 100a7f5:	lea    -0x128(%rbp),%rax
 100a7fc:	mov    %rax,-0xf8(%rbp)
 100a803:	mov    $0x3,%edx
 100a808:	lea    -0x108(%rbp),%rsi
 100a80f:	call   100b200 <myl_qbe_rc_scopes_close>
 100a814:	mov    %r13,%rdi
 100a817:	mov    %r12,%rax
 100a81a:	mov    -0x4c(%rbp),%r13d
 100a81e:	mov    -0x50(%rbp),%r12d
 100a822:	cmp    $0x0,%r15d
 100a826:	je     100a91e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a82c:	test   $0x1c,%r14d
 100a833:	jne    100a8ae <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x99e>
 100a835:	mov    -0x78(%rbp),%rdx
 100a839:	cmp    $0x0,%rdx
 100a83d:	je     100a91e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a843:	mov    %rdx,%rcx
 100a846:	sub    $0x10,%rcx
 100a84a:	mov    (%rcx),%rcx
 100a84d:	movabs $0x4000000000000002,%rsi
 100a857:	and    %rsi,%rcx
 100a85a:	cmp    $0x0,%rcx
 100a85e:	jne    100a8a4 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x994>
 100a860:	mov    %rdx,%rcx
 100a863:	sub    $0x20,%rcx
 100a867:	mov    (%rcx),%rcx
 100a86a:	sub    $0x1,%rcx
 100a86e:	jne    100a89d <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x98d>
 100a870:	mov    %rax,%r14
 100a873:	mov    %rdx,%rax
 100a876:	sub    $0x18,%rax
 100a87a:	mov    (%rax),%rax
 100a87d:	cmp    $0x0,%rax
 100a881:	jne    100a89a <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x98a>
 100a883:	lea    -0x78(%rbp),%rsi
 100a887:	mov    %rdi,%r15
 100a88a:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 100a88f:	mov    %r15,%rdi
 100a892:	mov    %r14,%rax
 100a895:	jmp    100a91e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a89a:	mov    %r14,%rax
 100a89d:	sub    $0x20,%rdx
 100a8a1:	mov    %rcx,(%rdx)
 100a8a4:	movq   $0x0,-0x78(%rbp)
 100a8ac:	jmp    100a91e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a8ae:	mov    -0x78(%rbp),%rdx
 100a8b2:	cmp    $0x0,%rdx
 100a8b6:	je     100a91e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a8b8:	mov    %rdx,%rcx
 100a8bb:	sub    $0x10,%rcx
 100a8bf:	mov    (%rcx),%rcx
 100a8c2:	movabs $0x4000000000000002,%rsi
 100a8cc:	and    %rsi,%rcx
 100a8cf:	cmp    $0x0,%rcx
 100a8d3:	jne    100a916 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa06>
 100a8d5:	mov    %rdx,%rcx
 100a8d8:	sub    $0x18,%rcx
 100a8dc:	mov    (%rcx),%rcx
 100a8df:	sub    $0x1,%rcx
 100a8e3:	jne    100a90f <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x9ff>
 100a8e5:	mov    %rax,%r14
 100a8e8:	mov    %rdx,%rax
 100a8eb:	sub    $0x20,%rax
 100a8ef:	mov    (%rax),%rax
 100a8f2:	cmp    $0x0,%rax
 100a8f6:	jne    100a90c <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0x9fc>
 100a8f8:	lea    -0x78(%rbp),%rsi
 100a8fc:	mov    %rdi,%r15
 100a8ff:	call   100ad10 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100a904:	mov    %r15,%rdi
 100a907:	mov    %r14,%rax
 100a90a:	jmp    100a91e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa0e>
 100a90c:	mov    %r14,%rax
 100a90f:	sub    $0x18,%rdx
 100a913:	mov    %rcx,(%rdx)
 100a916:	movq   $0x0,-0x78(%rbp)
 100a91e:	cmp    $0x0,%r13d
 100a922:	je     100aa30 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a928:	test   $0x1c,%r12d
 100a92f:	jne    100a9b7 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xaa7>
 100a935:	mov    -0xe8(%rbp),%rdx
 100a93c:	cmp    $0x0,%rdx
 100a940:	je     100aa30 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a946:	mov    %rdx,%rcx
 100a949:	sub    $0x10,%rcx
 100a94d:	mov    (%rcx),%rcx
 100a950:	movabs $0x4000000000000002,%rsi
 100a95a:	and    %rsi,%rcx
 100a95d:	cmp    $0x0,%rcx
 100a961:	jne    100a9aa <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa9a>
 100a963:	mov    %rdx,%rcx
 100a966:	sub    $0x20,%rcx
 100a96a:	mov    (%rcx),%rcx
 100a96d:	sub    $0x1,%rcx
 100a971:	jne    100a9a3 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa93>
 100a973:	mov    %rax,%r12
 100a976:	mov    %rdx,%rax
 100a979:	sub    $0x18,%rax
 100a97d:	mov    (%rax),%rax
 100a980:	cmp    $0x0,%rax
 100a984:	jne    100a9a0 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xa90>
 100a986:	lea    -0xe8(%rbp),%rsi
 100a98d:	mov    %rdi,%r13
 100a990:	call   100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>
 100a995:	mov    %r13,%rdi
 100a998:	mov    %r12,%rax
 100a99b:	jmp    100aa30 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a9a0:	mov    %r12,%rax
 100a9a3:	sub    $0x20,%rdx
 100a9a7:	mov    %rcx,(%rdx)
 100a9aa:	movq   $0x0,-0xe8(%rbp)
 100a9b5:	jmp    100aa30 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a9b7:	mov    -0xe8(%rbp),%rdx
 100a9be:	cmp    $0x0,%rdx
 100a9c2:	je     100aa30 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100a9c4:	mov    %rdx,%rcx
 100a9c7:	sub    $0x10,%rcx
 100a9cb:	mov    (%rcx),%rcx
 100a9ce:	movabs $0x4000000000000002,%rsi
 100a9d8:	and    %rsi,%rcx
 100a9db:	cmp    $0x0,%rcx
 100a9df:	jne    100aa25 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb15>
 100a9e1:	mov    %rdx,%rcx
 100a9e4:	sub    $0x18,%rcx
 100a9e8:	mov    (%rcx),%rcx
 100a9eb:	sub    $0x1,%rcx
 100a9ef:	jne    100aa1e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb0e>
 100a9f1:	mov    %rax,%r12
 100a9f4:	mov    %rdx,%rax
 100a9f7:	sub    $0x20,%rax
 100a9fb:	mov    (%rax),%rax
 100a9fe:	cmp    $0x0,%rax
 100aa02:	jne    100aa1b <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb0b>
 100aa04:	lea    -0xe8(%rbp),%rsi
 100aa0b:	mov    %rdi,%r13
 100aa0e:	call   100ad10 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100aa13:	mov    %r13,%rdi
 100aa16:	mov    %r12,%rax
 100aa19:	jmp    100aa30 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb20>
 100aa1b:	mov    %r12,%rax
 100aa1e:	sub    $0x18,%rdx
 100aa22:	mov    %rcx,(%rdx)
 100aa25:	movq   $0x0,-0xe8(%rbp)
 100aa30:	mov    -0xf0(%rbp),%rdx
 100aa37:	cmp    $0x0,%rdx
 100aa3b:	je     100aaa3 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb93>
 100aa3d:	mov    %rdx,%rcx
 100aa40:	sub    $0x10,%rcx
 100aa44:	mov    (%rcx),%rcx
 100aa47:	movabs $0x4000000000000002,%rsi
 100aa51:	and    %rsi,%rcx
 100aa54:	cmp    $0x0,%rcx
 100aa58:	jne    100aa98 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb88>
 100aa5a:	mov    %rdx,%rcx
 100aa5d:	sub    $0x18,%rcx
 100aa61:	mov    (%rcx),%rcx
 100aa64:	sub    $0x1,%rcx
 100aa68:	jne    100aa91 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb81>
 100aa6a:	mov    %rax,%r12
 100aa6d:	mov    %rdx,%rax
 100aa70:	sub    $0x20,%rax
 100aa74:	mov    (%rax),%rax
 100aa77:	cmp    $0x0,%rax
 100aa7b:	jne    100aa8e <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb7e>
 100aa7d:	lea    -0xf0(%rbp),%rsi
 100aa84:	call   100ad10 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100aa89:	mov    %r12,%rax
 100aa8c:	jmp    100aaa3 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xb93>
 100aa8e:	mov    %r12,%rax
 100aa91:	sub    $0x18,%rdx
 100aa95:	mov    %rcx,(%rdx)
 100aa98:	movq   $0x0,-0xf0(%rbp)
 100aaa3:	mov    (%rbx),%rcx
 100aaa6:	mov    %rcx,(%rax)
 100aaa9:	mov    0x8(%rbx),%rcx
 100aaad:	mov    %rcx,0x8(%rax)
 100aab1:	mov    0x10(%rbx),%rcx
 100aab5:	mov    %rcx,0x10(%rax)
 100aab9:	jmp    100abe2 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcd2>
 100aabe:	mov    $0x140,%edx
 100aac3:	call   100b9c0 <myl_qbe_fail_cast>
 100aac8:	ud2
 100aaca:	mov    %rbx,%r12
 100aacd:	movabs $0x3fe3333333333333,%rcx
 100aad7:	mov    %rcx,-0x70(%rbp)
 100aadb:	movabs $0x3fe6666666666666,%rcx
 100aae5:	mov    %rcx,-0x68(%rbp)
 100aae9:	movabs $0x3feccccccccccccd,%rcx
 100aaf3:	mov    %rcx,-0x60(%rbp)
 100aaf7:	mov    -0x150(%rbp),%ecx
 100aafd:	mov    -0x130(%rbp),%edx
 100ab03:	or     %edx,%ecx
 100ab05:	mov    -0x110(%rbp),%edx
 100ab0b:	or     %edx,%ecx
 100ab0d:	jne    100ab14 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xc04>
 100ab0f:	mov    %r12,%rdi
 100ab12:	jmp    100ab58 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xc48>
 100ab14:	lea    -0x168(%rbp),%rcx
 100ab1b:	mov    %rcx,-0x108(%rbp)
 100ab22:	lea    -0x148(%rbp),%rcx
 100ab29:	mov    %rcx,-0x100(%rbp)
 100ab30:	mov    %rax,%rbx
 100ab33:	lea    -0x128(%rbp),%rax
 100ab3a:	mov    %rax,-0xf8(%rbp)
 100ab41:	mov    $0x3,%edx
 100ab46:	lea    -0x108(%rbp),%rsi
 100ab4d:	call   100b200 <myl_qbe_rc_scopes_close>
 100ab52:	mov    %r12,%rdi
 100ab55:	mov    %rbx,%rax
 100ab58:	mov    -0xf0(%rbp),%rdx
 100ab5f:	cmp    $0x0,%rdx
 100ab63:	je     100abcb <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcbb>
 100ab65:	mov    %rdx,%rcx
 100ab68:	sub    $0x10,%rcx
 100ab6c:	mov    (%rcx),%rcx
 100ab6f:	movabs $0x4000000000000002,%rsi
 100ab79:	and    %rsi,%rcx
 100ab7c:	cmp    $0x0,%rcx
 100ab80:	jne    100abc0 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcb0>
 100ab82:	mov    %rdx,%rcx
 100ab85:	sub    $0x18,%rcx
 100ab89:	mov    (%rcx),%rcx
 100ab8c:	sub    $0x1,%rcx
 100ab90:	jne    100abb9 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xca9>
 100ab92:	mov    %rax,%rbx
 100ab95:	mov    %rdx,%rax
 100ab98:	sub    $0x20,%rax
 100ab9c:	mov    (%rax),%rax
 100ab9f:	cmp    $0x0,%rax
 100aba3:	jne    100abb6 <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xca6>
 100aba5:	lea    -0xf0(%rbp),%rsi
 100abac:	call   100ad10 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>
 100abb1:	mov    %rbx,%rax
 100abb4:	jmp    100abcb <myl_f_e02d7fca852ac60ed43f21a3d5032b58d9d13fe7719321284209ad753eba0814+0xcbb>
 100abb6:	mov    %rbx,%rax
 100abb9:	sub    $0x18,%rdx
 100abbd:	mov    %rcx,(%rdx)
 100abc0:	movq   $0x0,-0xf0(%rbp)
 100abcb:	mov    -0x70(%rbp),%rcx
 100abcf:	mov    %rcx,(%rax)
 100abd2:	mov    -0x68(%rbp),%rcx
 100abd6:	mov    %rcx,0x8(%rax)
 100abda:	mov    -0x60(%rbp),%rcx
 100abde:	mov    %rcx,0x10(%rax)
 100abe2:	pop    %r15
 100abe4:	pop    %r14
 100abe6:	pop    %r13
 100abe8:	pop    %r12
 100abea:	pop    %rbx
 100abeb:	leave
 100abec:	ret
 100abed:	mov    $0x140,%edx
 100abf2:	call   100b9c0 <myl_qbe_fail_cast>
 100abf7:	ud2
 100abf9:	call   100ba40 <myl_qbe_fail_frame>
 100abfe:	ud2

000000000100ac00 <myl_f_e392dad8b08599f74d4819cd291feef81ab4389e0a6fae2b1286f99411b0c7ca>:
 100ac00:	endbr64
 100ac04:	mov    %rdx,%rax
 100ac07:	mov    (%rsi),%rdx
 100ac0a:	mov    (%rax),%rcx
 100ac0d:	movq   %rdx,%xmm0
 100ac12:	movq   %rcx,%xmm1
 100ac17:	mulsd  %xmm1,%xmm0
 100ac1b:	movq   %xmm0,%rdx
 100ac20:	mov    0x8(%rsi),%rdi
 100ac24:	mov    0x8(%rax),%rcx
 100ac28:	movq   %rdi,%xmm0
 100ac2d:	movq   %rcx,%xmm1
 100ac32:	mulsd  %xmm1,%xmm0
 100ac36:	movq   %xmm0,%rcx
 100ac3b:	movq   %rdx,%xmm0
 100ac40:	movq   %rcx,%xmm1
 100ac45:	addsd  %xmm1,%xmm0
 100ac49:	movq   %xmm0,%rcx
 100ac4e:	mov    0x10(%rsi),%rdx
 100ac52:	mov    0x10(%rax),%rax
 100ac56:	movq   %rdx,%xmm0
 100ac5b:	movq   %rax,%xmm1
 100ac60:	mulsd  %xmm1,%xmm0
 100ac64:	movq   %xmm0,%rax
 100ac69:	movq   %rcx,%xmm0
 100ac6e:	movq   %rax,%xmm1
 100ac73:	addsd  %xmm1,%xmm0
 100ac77:	movq   %xmm0,%rax
 100ac7c:	ret
 100ac7d:	int3
 100ac7e:	int3
 100ac7f:	int3

000000000100ac80 <myl_f_f469802a31447f90d6a033d43f18db7ebfbee7cc3c378024bcc0f1573d3feef8>:
 100ac80:	endbr64
 100ac84:	push   %rbp
 100ac85:	mov    %rsp,%rbp
 100ac88:	sub    $0x20,%rsp
 100ac8c:	xchg   %rdx,%rcx
 100ac8f:	mov    %rdi,%rax
 100ac92:	mov    (%rcx),%rsi
 100ac95:	movq   %rsi,%xmm1
 100ac9a:	movq   %rdx,%xmm0
 100ac9f:	mulsd  %xmm0,%xmm1
 100aca3:	movq   %xmm1,%rsi
 100aca8:	mov    0x8(%rcx),%rdx
 100acac:	movq   %rdx,%xmm1
 100acb1:	mulsd  %xmm0,%xmm1
 100acb5:	movq   %xmm1,%rdx
 100acba:	mov    0x10(%rcx),%rcx
 100acbe:	movq   %rcx,%xmm1
 100acc3:	mulsd  %xmm1,%xmm0
 100acc7:	movq   %xmm0,%rcx
 100accc:	mov    %rsi,-0x18(%rbp)
 100acd0:	mov    %rdx,-0x10(%rbp)
 100acd4:	mov    %rcx,-0x8(%rbp)
 100acd8:	mov    -0x18(%rbp),%rcx
 100acdc:	mov    %rcx,(%rax)
 100acdf:	mov    -0x10(%rbp),%rcx
 100ace3:	mov    %rcx,0x8(%rax)
 100ace7:	mov    -0x8(%rbp),%rcx
 100aceb:	mov    %rcx,0x10(%rax)
 100acef:	leave
 100acf0:	ret
 100acf1:	int3
 100acf2:	int3
 100acf3:	int3
 100acf4:	int3
 100acf5:	int3
 100acf6:	int3
 100acf7:	int3
 100acf8:	int3
 100acf9:	int3
 100acfa:	int3
 100acfb:	int3
 100acfc:	int3
 100acfd:	int3
 100acfe:	int3
 100acff:	int3

000000000100ad00 <myl_r_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda>:
 100ad00:	mov    $0x8,%ecx
 100ad05:	mov    $0x1,%r8d
 100ad0b:	jmp    1017380 <myl_print_integer>

000000000100ad10 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan>:
 100ad10:	mov    (%rsi),%rax
 100ad13:	movq   $0x0,(%rsi)
 100ad1a:	test   %rax,%rax
 100ad1d:	je     100ad2f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan+0x1f>
 100ad1f:	movabs $0x4000000000000002,%rcx
 100ad29:	test   %rcx,-0x10(%rax)
 100ad2d:	je     100ad37 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan+0x27>
 100ad2f:	movq   $0x0,(%rsi)
 100ad36:	ret
 100ad37:	mov    -0x18(%rax),%rcx
 100ad3b:	cmp    $0x1,%rcx
 100ad3f:	jne    100ad48 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan+0x38>
 100ad41:	cmpq   $0x0,-0x20(%rax)
 100ad46:	je     100ad57 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_unloan+0x47>
 100ad48:	dec    %rcx
 100ad4b:	mov    %rcx,-0x18(%rax)
 100ad4f:	movq   $0x0,(%rsi)
 100ad56:	ret
 100ad57:	push   %rbp
 100ad58:	mov    %rsp,%rbp
 100ad5b:	push   %r14
 100ad5d:	push   %rbx
 100ad5e:	mov    %rdi,%rbx
 100ad61:	mov    %rsi,%r14
 100ad64:	mov    %rax,%rsi
 100ad67:	call   1012e00 <myl_rc_hold_edge_release>
 100ad6c:	movq   $0x0,(%r14)
 100ad73:	mov    %rbx,%rdi
 100ad76:	pop    %rbx
 100ad77:	pop    %r14
 100ad79:	pop    %rbp
 100ad7a:	jmp    1016210 <myl_rc_drain>
 100ad7f:	int3

000000000100ad80 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop>:
 100ad80:	mov    (%rsi),%rax
 100ad83:	movq   $0x0,(%rsi)
 100ad8a:	test   %rax,%rax
 100ad8d:	je     100ad9f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x1f>
 100ad8f:	movabs $0x4000000000000002,%rcx
 100ad99:	test   %rcx,-0x10(%rax)
 100ad9d:	je     100ada7 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x27>
 100ad9f:	movq   $0x0,(%rsi)
 100ada6:	ret
 100ada7:	mov    -0x20(%rax),%rcx
 100adab:	cmp    $0x1,%rcx
 100adaf:	jne    100adb8 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x38>
 100adb1:	cmpq   $0x0,-0x18(%rax)
 100adb6:	je     100adc7 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_drop+0x47>
 100adb8:	dec    %rcx
 100adbb:	mov    %rcx,-0x20(%rax)
 100adbf:	movq   $0x0,(%rsi)
 100adc6:	ret
 100adc7:	push   %rbp
 100adc8:	mov    %rsp,%rbp
 100adcb:	push   %r14
 100adcd:	push   %rbx
 100adce:	mov    %rdi,%rbx
 100add1:	mov    %rsi,%r14
 100add4:	mov    %rax,%rsi
 100add7:	call   1012bb0 <myl_rc_edge_release>
 100addc:	movq   $0x0,(%r14)
 100ade3:	mov    %rbx,%rdi
 100ade6:	pop    %rbx
 100ade7:	pop    %r14
 100ade9:	pop    %rbp
 100adea:	jmp    1016210 <myl_rc_drain>
 100adef:	int3

000000000100adf0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain>:
 100adf0:	mov    %ecx,%r8d
 100adf3:	mov    %rdx,%rcx
 100adf6:	mov    %rsi,%rdx
 100adf9:	mov    (%rcx),%rax
 100adfc:	test   %rax,%rax
 100adff:	je     100ae26 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain+0x36>
 100ae01:	mov    -0x10(%rax),%rsi
 100ae05:	bt     $0x3e,%rsi
 100ae0a:	jb     100ae2f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain+0x3f>
 100ae0c:	test   $0x2,%sil
 100ae10:	jne    100ae26 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain+0x36>
 100ae12:	mov    -0x20(%rax),%rsi
 100ae16:	cmp    $0xffffffffffffffff,%rsi
 100ae1a:	je     100ae2f <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_retain+0x3f>
 100ae1c:	inc    %rsi
 100ae1f:	mov    %rsi,-0x20(%rax)
 100ae23:	mov    (%rcx),%rax
 100ae26:	mov    %rax,(%rdx)
 100ae29:	mov    $0x1,%eax
 100ae2e:	ret
 100ae2f:	lea    0x1bc7a(%rip),%rsi        # 1026ab0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 100ae36:	jmp    101e0d0 <myl_rc_native_retain>
 100ae3b:	int3
 100ae3c:	int3
 100ae3d:	int3
 100ae3e:	int3
 100ae3f:	int3

000000000100ae40 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take>:
 100ae40:	mov    %ecx,%r8d
 100ae43:	mov    %rdx,%rcx
 100ae46:	mov    %rsi,%rdx
 100ae49:	mov    (%rcx),%rax
 100ae4c:	test   %rax,%rax
 100ae4f:	je     100ae57 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take+0x17>
 100ae51:	testb  $0x50,-0x9(%rax)
 100ae55:	jne    100ae7d <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take+0x3d>
 100ae57:	mov    %rdx,%rsi
 100ae5a:	sub    %rcx,%rsi
 100ae5d:	mov    %rcx,%r9
 100ae60:	sub    %rdx,%r9
 100ae63:	cmovb  %rsi,%r9
 100ae67:	cmp    $0x7,%r9
 100ae6b:	jbe    100ae7d <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f_rcg_take+0x3d>
 100ae6d:	mov    %rax,(%rdx)
 100ae70:	movq   $0x0,(%rcx)
 100ae77:	mov    $0x1,%eax
 100ae7c:	ret
 100ae7d:	lea    0x1bc2c(%rip),%rsi        # 1026ab0 <myl_t_677a7e29c1f72518168f5e18d2348f52b728c1a8f74dfb0464a79214e56d242f>
 100ae84:	jmp    101dde0 <myl_rc_native_take>
 100ae89:	int3
 100ae8a:	int3
 100ae8b:	int3
 100ae8c:	int3
 100ae8d:	int3
 100ae8e:	int3
 100ae8f:	int3

000000000100ae90 <myl_t_c9e8a01ef40ab54ae7a1fc2699500e6dc375b92b5ee5c0a9c220fa7cdce1fddf_rcg_list_append>:
 100ae90:	mov    (%rsi),%rax
 100ae93:	cmp    0x8(%rsi),%rax
 100ae97:	jae    1011990 <myl_rc_list_append>
 100ae9d:	cmpq   $0xffffffffffffffff,0x10(%rsi)
 100aea2:	je     1011990 <myl_rc_list_append>
 100aea8:	mov    0x20(%rsi),%rcx
 100aeac:	mov    %rdx,%r9
 100aeaf:	sub    %rcx,%r9
 100aeb2:	imul   $0x38,%rax,%r8
 100aeb6:	cmp    %r8,%r9
 100aeb9:	jb     1011990 <myl_rc_list_append>
 100aebf:	vmovups (%rdx),%ymm0
 100aec3:	vmovups 0x18(%rdx),%ymm1
 100aec8:	vmovups %ymm1,0x18(%rcx,%r8,1)
 100aecf:	vmovups %ymm0,(%rcx,%r8,1)
 100aed5:	inc    %rax
 100aed8:	mov    %rax,(%rsi)
 100aedb:	incq   0x10(%rsi)
 100aedf:	mov    $0x1,%eax
 100aee4:	vzeroupper
 100aee7:	ret
 100aee8:	int3
 100aee9:	int3
 100aeea:	int3
 100aeeb:	int3
 100aeec:	int3
 100aeed:	int3
 100aeee:	int3
 100aeef:	int3

000000000100aef0 <myl_qbe_host_begin>:
 100aef0:	push   %rbp
 100aef1:	mov    %rsp,%rbp
 100aef4:	push   %rbx
 100aef5:	push   %rax
 100aef6:	cmpq   $0x0,0x39a8(%rdi)
 100aefe:	je     100af07 <myl_qbe_host_begin+0x17>
 100af00:	add    $0x8,%rsp
 100af04:	pop    %rbx
 100af05:	pop    %rbp
 100af06:	ret
 100af07:	mov    %rdi,%rbx
 100af0a:	mov    $0x1,%edi
 100af0f:	mov    $0x40,%esi
 100af14:	call   101ef80 <calloc@plt>
 100af19:	test   %rax,%rax
 100af1c:	je     100afee <myl_qbe_host_begin+0xfe>
 100af22:	mov    %rax,0x39a8(%rbx)
 100af29:	mov    0x3978(%rbx),%rcx
 100af30:	lea    0xa0(%rcx),%rdx
 100af37:	test   %rcx,%rcx
 100af3a:	lea    -0x8199(%rip),%rcx        # 1002da8 <qbe_empty_registry>
 100af41:	cmovne %rdx,%rcx
 100af45:	mov    %rcx,(%rax)
 100af48:	cmpq   $0x0,0x8(%rcx)
 100af4d:	je     100af59 <myl_qbe_host_begin+0x69>
 100af4f:	cmpq   $0x0,(%rcx)
 100af53:	je     100aff7 <myl_qbe_host_begin+0x107>
 100af59:	mov    0x10(%rcx),%rdx
 100af5d:	test   %rdx,%rdx
 100af60:	mov    $0x2710,%esi
 100af65:	cmovne %rdx,%rsi
 100af69:	mov    %rsi,0x18(%rax)
 100af6d:	mov    0x18(%rcx),%rdx
 100af71:	test   %rdx,%rdx
 100af74:	mov    $0xf4240,%esi
 100af79:	cmovne %rdx,%rsi
 100af7d:	mov    %rsi,0x10(%rax)
 100af81:	mov    0x20(%rcx),%rdx
 100af85:	test   %rdx,%rdx
 100af88:	mov    $0x10000,%r8d
 100af8e:	cmovne %rdx,%r8
 100af92:	mov    %r8,0x20(%rax)
 100af96:	mov    0x28(%rcx),%rsi
 100af9a:	test   %rsi,%rsi
 100af9d:	mov    $0x40,%edx
 100afa2:	cmovne %rsi,%rdx
 100afa6:	mov    %rdx,0x28(%rax)
 100afaa:	mov    0x30(%rcx),%r9
 100afae:	test   %r9,%r9
 100afb1:	mov    $0x100000,%esi
 100afb6:	cmovne %r9,%rsi
 100afba:	mov    %rsi,0x30(%rax)
 100afbe:	cmp    $0x186a0,%r8
 100afc5:	ja     100afe5 <myl_qbe_host_begin+0xf5>
 100afc7:	cmp    $0x81,%rdx
 100afce:	setae  %dl
 100afd1:	cmp    $0x4000001,%rsi
 100afd8:	setae  %sil
 100afdc:	or     %dl,%sil
 100afdf:	cmp    $0x1,%sil
 100afe3:	jne    100b000 <myl_qbe_host_begin+0x110>
 100afe5:	lea    -0x9785(%rip),%rsi        # 1001867 <__abi_tag+0x156b>
 100afec:	jmp    100b00e <myl_qbe_host_begin+0x11e>
 100afee:	lea    -0x9903(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100aff5:	jmp    100b00e <myl_qbe_host_begin+0x11e>
 100aff7:	lea    -0x9726(%rip),%rsi        # 10018d8 <__abi_tag+0x15dc>
 100affe:	jmp    100b00e <myl_qbe_host_begin+0x11e>
 100b000:	cmpq   $0x0,0x8(%rcx)
 100b005:	je     100b01c <myl_qbe_host_begin+0x12c>
 100b007:	lea    -0x974a(%rip),%rsi        # 10018c4 <__abi_tag+0x15c8>
 100b00e:	mov    %rbx,%rdi
 100b011:	add    $0x8,%rsp
 100b015:	pop    %rbx
 100b016:	pop    %rbp
 100b017:	jmp    100b570 <myl_qbe_fail>
 100b01c:	movl   $0x1,0x38(%rax)
 100b023:	jmp    100af00 <myl_qbe_host_begin+0x10>
 100b028:	int3
 100b029:	int3
 100b02a:	int3
 100b02b:	int3
 100b02c:	int3
 100b02d:	int3
 100b02e:	int3
 100b02f:	int3

000000000100b030 <main>:
 100b030:	push   %rbp
 100b031:	mov    %rsp,%rbp
 100b034:	push   %r14
 100b036:	push   %rbx
 100b037:	mov    %rsi,%rbx
 100b03a:	mov    %edi,%r14d
 100b03d:	call   100b530 <myl_qbe_exit_without_sweep>
 100b042:	lea    0x17(%rip),%rdi        # 100b060 <entry_run>
 100b049:	mov    %r14d,%esi
 100b04c:	mov    %rbx,%rdx
 100b04f:	xor    %ecx,%ecx
 100b051:	pop    %rbx
 100b052:	pop    %r14
 100b054:	pop    %rbp
 100b055:	jmp    100da90 <mylang_qbe_run_grants>
 100b05a:	int3
 100b05b:	int3
 100b05c:	int3
 100b05d:	int3
 100b05e:	int3
 100b05f:	int3

000000000100b060 <entry_run>:
 100b060:	push   %rbp
 100b061:	mov    %rsp,%rbp
 100b064:	push   %rbx
 100b065:	push   %rax
 100b066:	mov    %rdi,%rbx
 100b069:	call   100aef0 <myl_qbe_host_begin>
 100b06e:	mov    %rbx,%rdi
 100b071:	call   100b770 <myl_qbe_failed>
 100b076:	test   %rax,%rax
 100b079:	jne    100b095 <entry_run+0x35>
 100b07b:	mov    %rbx,%rdi
 100b07e:	call   100b770 <myl_qbe_failed>
 100b083:	test   %rax,%rax
 100b086:	jne    100b095 <entry_run+0x35>
 100b088:	mov    %rbx,%rdi
 100b08b:	call   100b770 <myl_qbe_failed>
 100b090:	test   %rax,%rax
 100b093:	je     100b09e <entry_run+0x3e>
 100b095:	xor    %eax,%eax
 100b097:	add    $0x8,%rsp
 100b09b:	pop    %rbx
 100b09c:	pop    %rbp
 100b09d:	ret
 100b09e:	mov    $0x1,%esi
 100b0a3:	mov    %rbx,%rdi
 100b0a6:	add    $0x8,%rsp
 100b0aa:	pop    %rbx
 100b0ab:	pop    %rbp
 100b0ac:	jmp    1007a80 <myl_f_0d6e4079e36703ebd37c00722f5891d28b0e2811dc114b129215123adcce3605>
 100b0b1:	int3
 100b0b2:	int3
 100b0b3:	int3
 100b0b4:	int3
 100b0b5:	int3
 100b0b6:	int3
 100b0b7:	int3
 100b0b8:	int3
 100b0b9:	int3
 100b0ba:	int3
 100b0bb:	int3
 100b0bc:	int3
 100b0bd:	int3
 100b0be:	int3
 100b0bf:	int3

000000000100b0c0 <myl_qbe_rc_status>:
 100b0c0:	test   %esi,%esi
 100b0c2:	je     100b0ff <myl_qbe_rc_status+0x3f>
 100b0c4:	push   %rbp
 100b0c5:	mov    %rsp,%rbp
 100b0c8:	push   %rbx
 100b0c9:	push   %rax
 100b0ca:	cmp    $0x1,%esi
 100b0cd:	jne    100b0e1 <myl_qbe_rc_status+0x21>
 100b0cf:	cmpl   $0x0,0x2c4(%rdi)
 100b0d6:	je     100b0e1 <myl_qbe_rc_status+0x21>
 100b0d8:	lea    -0x94bb(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100b0df:	jmp    100b0f1 <myl_qbe_rc_status+0x31>
 100b0e1:	mov    %rdi,%rbx
 100b0e4:	mov    %esi,%edi
 100b0e6:	call   1012750 <myl_rc_status_code>
 100b0eb:	mov    %rbx,%rdi
 100b0ee:	mov    %rax,%rsi
 100b0f1:	call   100b570 <myl_qbe_fail>
 100b0f6:	xor    %eax,%eax
 100b0f8:	add    $0x8,%rsp
 100b0fc:	pop    %rbx
 100b0fd:	pop    %rbp
 100b0fe:	ret
 100b0ff:	mov    $0x1,%eax
 100b104:	ret
 100b105:	int3
 100b106:	int3
 100b107:	int3
 100b108:	int3
 100b109:	int3
 100b10a:	int3
 100b10b:	int3
 100b10c:	int3
 100b10d:	int3
 100b10e:	int3
 100b10f:	int3

000000000100b110 <myl_qbe_rc_initialize>:
 100b110:	push   %rbp
 100b111:	mov    %rsp,%rbp
 100b114:	push   %rbx
 100b115:	push   %rax
 100b116:	cmpq   $0x0,0x1860(%rdi)
 100b11e:	je     100b186 <myl_qbe_rc_initialize+0x76>
 100b120:	lea    0x258(%rdi),%rax
 100b127:	lea    -0x9461(%rip),%rsi        # 1001ccd <__abi_tag+0x19d1>
 100b12e:	cmpq   $0x0,0x1e43a(%rip)        # 1029570 <_DYNAMIC+0x1a8>
 100b136:	je     100b198 <myl_qbe_rc_initialize+0x88>
 100b138:	cmpq   $0x0,0x1e428(%rip)        # 1029568 <_DYNAMIC+0x1a0>
 100b140:	je     100b1e3 <myl_qbe_rc_initialize+0xd3>
 100b146:	lea    0x1c8f3(%rip),%rcx        # 1027a40 <myl_rc_generated_module>
 100b14d:	cmpl   $0x5,(%rcx)
 100b150:	jne    100b1e3 <myl_qbe_rc_initialize+0xd3>
 100b156:	mov    %rdi,%rbx
 100b159:	lea    0x1c8e0(%rip),%rsi        # 1027a40 <myl_rc_generated_module>
 100b160:	lea    0x1c9d1(%rip),%rdx        # 1027b38 <myl_rc_generated_image>
 100b167:	mov    %rax,%rdi
 100b16a:	call   1014500 <myl_rc_module_register_image>
 100b16f:	test   %eax,%eax
 100b171:	je     100b1f1 <myl_qbe_rc_initialize+0xe1>
 100b173:	cmp    $0x1,%eax
 100b176:	jne    100b1c9 <myl_qbe_rc_initialize+0xb9>
 100b178:	mov    %rbx,%rdi
 100b17b:	cmpl   $0x0,0x2c4(%rbx)
 100b182:	jne    100b18f <myl_qbe_rc_initialize+0x7f>
 100b184:	jmp    100b1d3 <myl_qbe_rc_initialize+0xc3>
 100b186:	cmpl   $0x0,0x2c4(%rdi)
 100b18d:	je     100b1ce <myl_qbe_rc_initialize+0xbe>
 100b18f:	lea    -0x9572(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100b196:	jmp    100b1e3 <myl_qbe_rc_initialize+0xd3>
 100b198:	cmpq   $0x0,0x1e3c8(%rip)        # 1029568 <_DYNAMIC+0x1a0>
 100b1a0:	je     100b1e3 <myl_qbe_rc_initialize+0xd3>
 100b1a2:	lea    0x1c897(%rip),%rcx        # 1027a40 <myl_rc_generated_module>
 100b1a9:	cmpl   $0x5,(%rcx)
 100b1ac:	jne    100b1e3 <myl_qbe_rc_initialize+0xd3>
 100b1ae:	mov    %rdi,%rbx
 100b1b1:	lea    0x1c888(%rip),%rsi        # 1027a40 <myl_rc_generated_module>
 100b1b8:	mov    %rax,%rdi
 100b1bb:	call   1013620 <myl_rc_module_register>
 100b1c0:	test   %eax,%eax
 100b1c2:	je     100b1f1 <myl_qbe_rc_initialize+0xe1>
 100b1c4:	cmp    $0x1,%eax
 100b1c7:	je     100b178 <myl_qbe_rc_initialize+0x68>
 100b1c9:	mov    %rbx,%rdi
 100b1cc:	jmp    100b1d3 <myl_qbe_rc_initialize+0xc3>
 100b1ce:	mov    $0x1,%eax
 100b1d3:	mov    %rdi,%rbx
 100b1d6:	mov    %eax,%edi
 100b1d8:	call   1012750 <myl_rc_status_code>
 100b1dd:	mov    %rbx,%rdi
 100b1e0:	mov    %rax,%rsi
 100b1e3:	call   100b570 <myl_qbe_fail>
 100b1e8:	xor    %eax,%eax
 100b1ea:	add    $0x8,%rsp
 100b1ee:	pop    %rbx
 100b1ef:	pop    %rbp
 100b1f0:	ret
 100b1f1:	mov    $0x1,%eax
 100b1f6:	jmp    100b1ea <myl_qbe_rc_initialize+0xda>
 100b1f8:	int3
 100b1f9:	int3
 100b1fa:	int3
 100b1fb:	int3
 100b1fc:	int3
 100b1fd:	int3
 100b1fe:	int3
 100b1ff:	int3

000000000100b200 <myl_qbe_rc_scopes_close>:
 100b200:	push   %rbp
 100b201:	mov    %rsp,%rbp
 100b204:	push   %r15
 100b206:	push   %r14
 100b208:	push   %rbx
 100b209:	push   %rax
 100b20a:	test   %rdx,%rdx
 100b20d:	sete   %al
 100b210:	test   %rsi,%rsi
 100b213:	setne  %cl
 100b216:	or     %al,%cl
 100b218:	je     100b275 <myl_qbe_rc_scopes_close+0x75>
 100b21a:	mov    %rdx,%r14
 100b21d:	mov    %rsi,%r15
 100b220:	mov    %rdi,%rbx
 100b223:	add    $0x258,%rbx
 100b22a:	mov    %rbx,%rdi
 100b22d:	call   10191e0 <myl_rc_scope_current>
 100b232:	test   %r14,%r14
 100b235:	je     100b260 <myl_qbe_rc_scopes_close+0x60>
 100b237:	xor    %ecx,%ecx
 100b239:	nopl   0x0(%rax)
 100b240:	cmp    %rax,(%r15,%rcx,8)
 100b244:	je     100b250 <myl_qbe_rc_scopes_close+0x50>
 100b246:	inc    %rcx
 100b249:	cmp    %rcx,%r14
 100b24c:	jne    100b240 <myl_qbe_rc_scopes_close+0x40>
 100b24e:	jmp    100b260 <myl_qbe_rc_scopes_close+0x60>
 100b250:	test   %rax,%rax
 100b253:	je     100b260 <myl_qbe_rc_scopes_close+0x60>
 100b255:	cmp    %rcx,%r14
 100b258:	je     100b260 <myl_qbe_rc_scopes_close+0x60>
 100b25a:	mov    0x8(%rax),%rax
 100b25e:	jmp    100b237 <myl_qbe_rc_scopes_close+0x37>
 100b260:	mov    %rbx,%rdi
 100b263:	mov    %rax,%rsi
 100b266:	add    $0x8,%rsp
 100b26a:	pop    %rbx
 100b26b:	pop    %r14
 100b26d:	pop    %r15
 100b26f:	pop    %rbp
 100b270:	jmp    1018ee0 <myl_rc_scope_unwind>
 100b275:	call   101267d <myl_rc_invariant_failed>
 100b27a:	int3
 100b27b:	int3
 100b27c:	int3
 100b27d:	int3
 100b27e:	int3
 100b27f:	int3

000000000100b280 <myl_qbe_rc_trap>:
 100b280:	cmpq   $0x0,0x1860(%rdi)
 100b288:	je     100b296 <myl_qbe_rc_trap+0x16>
 100b28a:	add    $0x258,%rdi
 100b291:	jmp    1018d90 <myl_rc_scopes_abandon>
 100b296:	ret
 100b297:	int3
 100b298:	int3
 100b299:	int3
 100b29a:	int3
 100b29b:	int3
 100b29c:	int3
 100b29d:	int3
 100b29e:	int3
 100b29f:	int3

000000000100b2a0 <myl_qbe_rc_finish>:
 100b2a0:	push   %rbp
 100b2a1:	mov    %rsp,%rbp
 100b2a4:	push   %r15
 100b2a6:	push   %r14
 100b2a8:	push   %r12
 100b2aa:	push   %rbx
 100b2ab:	cmpq   $0x0,0x1860(%rdi)
 100b2b3:	je     100b350 <myl_qbe_rc_finish+0xb0>
 100b2b9:	mov    %rdi,%r15
 100b2bc:	lea    0x258(%rdi),%rbx
 100b2c3:	lea    0x328(%rdi),%r14
 100b2ca:	cmpq   $0x0,0x20(%rdi)
 100b2cf:	je     100b30b <myl_qbe_rc_finish+0x6b>
 100b2d1:	mov    %rbx,%rdi
 100b2d4:	call   1018d90 <myl_rc_scopes_abandon>
 100b2d9:	mov    %rbx,%rdi
 100b2dc:	call   1011010 <myl_native_arena_discard>
 100b2e1:	movl   $0x0,0x2c8(%r15)
 100b2ec:	mov    $0x400,%edx
 100b2f1:	mov    %r14,%rdi
 100b2f4:	xor    %esi,%esi
 100b2f6:	call   101e6b0 <compiler_rt.fastMemset>
 100b2fb:	mov    %rbx,%rdi
 100b2fe:	pop    %rbx
 100b2ff:	pop    %r12
 100b301:	pop    %r14
 100b303:	pop    %r15
 100b305:	pop    %rbp
 100b306:	jmp    10129d0 <myl_rc_heap_teardown>
 100b30b:	xor    %r12d,%r12d
 100b30e:	mov    %rbx,%rdi
 100b311:	xor    %esi,%esi
 100b313:	call   1018ee0 <myl_rc_scope_unwind>
 100b318:	mov    %rbx,%rdi
 100b31b:	xor    %esi,%esi
 100b31d:	call   1011260 <myl_native_arena_release>
 100b322:	movl   $0x0,0x2c8(%r15)
 100b32d:	nopl   (%rax)
 100b330:	mov    (%r14,%r12,8),%rsi
 100b334:	movq   $0x0,(%r14,%r12,8)
 100b33c:	mov    %rbx,%rdi
 100b33f:	call   1012cd0 <myl_rc_owner_release>
 100b344:	inc    %r12
 100b347:	cmp    $0x80,%r12
 100b34e:	jne    100b330 <myl_qbe_rc_finish+0x90>
 100b350:	pop    %rbx
 100b351:	pop    %r12
 100b353:	pop    %r14
 100b355:	pop    %r15
 100b357:	pop    %rbp
 100b358:	ret
 100b359:	int3
 100b35a:	int3
 100b35b:	int3
 100b35c:	int3
 100b35d:	int3
 100b35e:	int3
 100b35f:	int3

000000000100b360 <myl_qbe_rc_unique_local>:
 100b360:	push   %rbp
 100b361:	mov    %rsp,%rbp
 100b364:	push   %r15
 100b366:	push   %r14
 100b368:	push   %rbx
 100b369:	sub    $0x38,%rsp
 100b36d:	test   %rcx,%rcx
 100b370:	je     100b451 <myl_qbe_rc_unique_local+0xf1>
 100b376:	mov    (%rdx),%r8
 100b379:	mov    $0x1,%eax
 100b37e:	test   %r8,%r8
 100b381:	je     100b4fb <myl_qbe_rc_unique_local+0x19b>
 100b387:	mov    -0x10(%r8),%r9
 100b38b:	movabs $0x2000000000000002,%r10
 100b395:	test   %r10,%r9
 100b398:	je     100b41e <myl_qbe_rc_unique_local+0xbe>
 100b39e:	lea    0x258(%rdi),%r8
 100b3a5:	mov    0x1860(%rdi),%r9
 100b3ac:	mov    0x34(%rsi),%eax
 100b3af:	cmp    %rax,0xa0(%r9)
 100b3b6:	jbe    100b506 <myl_qbe_rc_unique_local+0x1a6>
 100b3bc:	mov    0x98(%r9),%r9
 100b3c3:	shl    $0x4,%rax
 100b3c7:	cmp    %rsi,(%r9,%rax,1)
 100b3cb:	jne    100b506 <myl_qbe_rc_unique_local+0x1a6>
 100b3d1:	add    %rax,%r9
 100b3d4:	mov    0x8(%r9),%rax
 100b3d8:	test   %rax,%rax
 100b3db:	je     100b451 <myl_qbe_rc_unique_local+0xf1>
 100b3dd:	mov    0x8(%rax),%rax
 100b3e1:	cmpl   $0x1,0x8(%rax)
 100b3e5:	jne    100b451 <myl_qbe_rc_unique_local+0xf1>
 100b3e7:	mov    %rax,-0x50(%rbp)
 100b3eb:	mov    %rdx,-0x48(%rbp)
 100b3ef:	movq   $0x0,-0x40(%rbp)
 100b3f7:	mov    (%rdx),%rax
 100b3fa:	test   %rax,%rax
 100b3fd:	je     100b456 <myl_qbe_rc_unique_local+0xf6>
 100b3ff:	mov    -0x10(%rax),%rsi
 100b403:	mov    %rsi,%r9
 100b406:	shr    $0x28,%r9
 100b40a:	and    $0xfffff,%r9d
 100b411:	xor    %eax,%eax
 100b413:	bt     $0x3e,%rsi
 100b418:	cmovb  %r9d,%eax
 100b41c:	jmp    100b458 <myl_qbe_rc_unique_local+0xf8>
 100b41e:	bt     $0x3e,%r9
 100b423:	jb     100b4fb <myl_qbe_rc_unique_local+0x19b>
 100b429:	test   $0x1,%r9b
 100b42d:	jne    100b451 <myl_qbe_rc_unique_local+0xf1>
 100b42f:	mov    -0x20(%r8),%r9
 100b433:	cmp    $0x1,%r9
 100b437:	je     100b4fb <myl_qbe_rc_unique_local+0x19b>
 100b43d:	test   %r9,%r9
 100b440:	jne    100b39e <myl_qbe_rc_unique_local+0x3e>
 100b446:	cmpq   $0x0,-0x18(%r8)
 100b44b:	jne    100b4fb <myl_qbe_rc_unique_local+0x19b>
 100b451:	call   101267d <myl_rc_invariant_failed>
 100b456:	xor    %eax,%eax
 100b458:	mov    %rdi,%rbx
 100b45b:	mov    %eax,-0x38(%rbp)
 100b45e:	movl   $0x0,-0x34(%rbp)
 100b465:	cmpl   $0x0,(%rcx)
 100b468:	je     100b48a <myl_qbe_rc_unique_local+0x12a>
 100b46a:	lea    -0x50(%rbp),%rsi
 100b46e:	mov    %r8,%rdi
 100b471:	call   101a810 <myl_rc_unique_owned>
 100b476:	test   %eax,%eax
 100b478:	je     100b4e0 <myl_qbe_rc_unique_local+0x180>
 100b47a:	cmp    $0x1,%eax
 100b47d:	jne    100b4e7 <myl_qbe_rc_unique_local+0x187>
 100b47f:	cmpl   $0x0,0x2c4(%rbx)
 100b486:	jne    100b4d7 <myl_qbe_rc_unique_local+0x177>
 100b488:	jmp    100b4e7 <myl_qbe_rc_unique_local+0x187>
 100b48a:	mov    %rdx,%r15
 100b48d:	mov    %rcx,%r14
 100b490:	vxorps %xmm0,%xmm0,%xmm0
 100b494:	vmovaps %xmm0,-0x30(%rbp)
 100b499:	lea    -0x50(%rbp),%rsi
 100b49d:	lea    -0x30(%rbp),%rcx
 100b4a1:	mov    %r8,%rdi
 100b4a4:	xor    %edx,%edx
 100b4a6:	call   101aad0 <myl_rc_unique_borrow>
 100b4ab:	test   %eax,%eax
 100b4ad:	jne    100b4c5 <myl_qbe_rc_unique_local+0x165>
 100b4af:	cmpl   $0x0,-0x28(%rbp)
 100b4b3:	je     100b4c5 <myl_qbe_rc_unique_local+0x165>
 100b4b5:	mov    -0x30(%rbp),%rax
 100b4b9:	mov    %rax,(%r15)
 100b4bc:	movl   $0x1,(%r14)
 100b4c3:	jmp    100b4e0 <myl_qbe_rc_unique_local+0x180>
 100b4c5:	test   %eax,%eax
 100b4c7:	je     100b4e0 <myl_qbe_rc_unique_local+0x180>
 100b4c9:	cmp    $0x1,%eax
 100b4cc:	jne    100b4e7 <myl_qbe_rc_unique_local+0x187>
 100b4ce:	cmpl   $0x0,0x2c4(%rbx)
 100b4d5:	je     100b4e7 <myl_qbe_rc_unique_local+0x187>
 100b4d7:	lea    -0x98ba(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100b4de:	jmp    100b4f1 <myl_qbe_rc_unique_local+0x191>
 100b4e0:	mov    $0x1,%eax
 100b4e5:	jmp    100b4fb <myl_qbe_rc_unique_local+0x19b>
 100b4e7:	mov    %eax,%edi
 100b4e9:	call   1012750 <myl_rc_status_code>
 100b4ee:	mov    %rax,%rsi
 100b4f1:	mov    %rbx,%rdi
 100b4f4:	call   100b570 <myl_qbe_fail>
 100b4f9:	xor    %eax,%eax
 100b4fb:	add    $0x38,%rsp
 100b4ff:	pop    %rbx
 100b500:	pop    %r14
 100b502:	pop    %r15
 100b504:	pop    %rbp
 100b505:	ret
 100b506:	mov    %rdi,%r9
 100b509:	mov    %r8,%rdi
 100b50c:	call   10130fa <myl_rc_binding_find_slow>
 100b511:	mov    %r9,%rdi
 100b514:	test   %rax,%rax
 100b517:	jne    100b3dd <myl_qbe_rc_unique_local+0x7d>
 100b51d:	jmp    100b451 <myl_qbe_rc_unique_local+0xf1>
 100b522:	int3
 100b523:	int3
 100b524:	int3
 100b525:	int3
 100b526:	int3
 100b527:	int3
 100b528:	int3
 100b529:	int3
 100b52a:	int3
 100b52b:	int3
 100b52c:	int3
 100b52d:	int3
 100b52e:	int3
 100b52f:	int3

000000000100b530 <myl_qbe_exit_without_sweep>:
 100b530:	movb   $0x1,0x1f281(%rip)        # 102a7b8 <exit_without_sweep>
 100b537:	ret
 100b538:	int3
 100b539:	int3
 100b53a:	int3
 100b53b:	int3
 100b53c:	int3
 100b53d:	int3
 100b53e:	int3
 100b53f:	int3

000000000100b540 <myl_qbe_exit_skip>:
 100b540:	xor    %eax,%eax
 100b542:	cmpb   $0x1,0x1f26f(%rip)        # 102a7b8 <exit_without_sweep>
 100b549:	jne    100b554 <myl_qbe_exit_skip+0x14>
 100b54b:	cmpl   $0x0,0x2c0(%rdi)
 100b552:	je     100b555 <myl_qbe_exit_skip+0x15>
 100b554:	ret
 100b555:	cmpq   $0x0,0x3990(%rdi)
 100b55d:	jne    100b554 <myl_qbe_exit_skip+0x14>
 100b55f:	xor    %eax,%eax
 100b561:	cmpq   $0x0,0x3998(%rdi)
 100b569:	sete   %al
 100b56c:	ret
 100b56d:	int3
 100b56e:	int3
 100b56f:	int3

000000000100b570 <myl_qbe_fail>:
 100b570:	push   %rbp
 100b571:	mov    %rsp,%rbp
 100b574:	call   100b580 <fail>
 100b579:	pop    %rbp
 100b57a:	ret
 100b57b:	int3
 100b57c:	int3
 100b57d:	int3
 100b57e:	int3
 100b57f:	int3

000000000100b580 <fail>:
 100b580:	push   %rbp
 100b581:	mov    %rsp,%rbp
 100b584:	push   %r10
 100b586:	push   %r9
 100b588:	push   %r8
 100b58a:	push   %rdi
 100b58b:	push   %rsi
 100b58c:	push   %rdx
 100b58d:	push   %rcx
 100b58e:	push   %rax
 100b58f:	push   %r15
 100b591:	push   %r14
 100b593:	push   %rbx
 100b594:	and    $0xffffffffffffffe0,%rsp
 100b598:	sub    $0x240,%rsp
 100b59f:	vmovups %ymm15,-0x90(%rbp)
 100b5a7:	vmovups %ymm14,-0xb0(%rbp)
 100b5af:	vmovups %ymm13,-0xd0(%rbp)
 100b5b7:	vmovups %ymm12,-0xf0(%rbp)
 100b5bf:	vmovups %ymm11,-0x110(%rbp)
 100b5c7:	vmovups %ymm10,-0x130(%rbp)
 100b5cf:	vmovups %ymm9,-0x150(%rbp)
 100b5d7:	vmovups %ymm8,-0x170(%rbp)
 100b5df:	vmovups %ymm7,-0x190(%rbp)
 100b5e7:	vmovups %ymm6,-0x1b0(%rbp)
 100b5ef:	vmovups %ymm5,-0x1d0(%rbp)
 100b5f7:	vmovups %ymm4,-0x1f0(%rbp)
 100b5ff:	vmovups %ymm3,-0x210(%rbp)
 100b607:	vmovups %ymm2,-0x230(%rbp)
 100b60f:	vmovups %ymm1,-0x250(%rbp)
 100b617:	vmovups %ymm0,-0x270(%rbp)
 100b61f:	cmpq   $0x0,0x20(%rdi)
 100b624:	jne    100b6b5 <fail+0x135>
 100b62a:	mov    %rdi,%rbx
 100b62d:	mov    %rsi,0x20(%rdi)
 100b631:	movq   $0x0,0x18(%rsp)
 100b63a:	mov    0x30(%rdi),%r15
 100b63e:	test   %r15,%r15
 100b641:	je     100b677 <fail+0xf7>
 100b643:	lea    0x18(%rsp),%r14
 100b648:	nopl   0x0(%rax,%rax,1)
 100b650:	mov    0x8(%r15),%rsi
 100b654:	mov    0x10(%r15),%rdx
 100b658:	mov    %rbx,%rdi
 100b65b:	xor    %ecx,%ecx
 100b65d:	mov    %r14,%r8
 100b660:	vzeroupper
 100b663:	call   100cec0 <trace_frame>
 100b668:	mov    (%r15),%r15
 100b66b:	test   %r15,%r15
 100b66e:	jne    100b650 <fail+0xd0>
 100b670:	cmpq   $0x0,0x30(%rbx)
 100b675:	jne    100b68e <fail+0x10e>
 100b677:	lea    0x1ac2(%rip),%rsi        # 100d140 <trace_visit>
 100b67e:	lea    0x18(%rsp),%rdx
 100b683:	mov    %rbx,%rdi
 100b686:	vzeroupper
 100b689:	call   100d000 <walk_frames>
 100b68e:	mov    0x18(%rsp),%r11
 100b693:	xor    %eax,%eax
 100b695:	sub    0x248(%rbx),%r11
 100b69c:	cmovae %r11,%rax
 100b6a0:	mov    %rax,0x250(%rbx)
 100b6a7:	cmpq   $0x0,0x3e60(%rbx)
 100b6af:	jne    100b74e <fail+0x1ce>
 100b6b5:	vmovups -0x270(%rbp),%ymm0
 100b6bd:	vmovups -0x250(%rbp),%ymm1
 100b6c5:	vmovups -0x230(%rbp),%ymm2
 100b6cd:	vmovups -0x210(%rbp),%ymm3
 100b6d5:	vmovups -0x1f0(%rbp),%ymm4
 100b6dd:	vmovups -0x1d0(%rbp),%ymm5
 100b6e5:	vmovups -0x1b0(%rbp),%ymm6
 100b6ed:	vmovups -0x190(%rbp),%ymm7
 100b6f5:	vmovups -0x170(%rbp),%ymm8
 100b6fd:	vmovups -0x150(%rbp),%ymm9
 100b705:	vmovups -0x130(%rbp),%ymm10
 100b70d:	vmovups -0x110(%rbp),%ymm11
 100b715:	vmovups -0xf0(%rbp),%ymm12
 100b71d:	vmovups -0xd0(%rbp),%ymm13
 100b725:	vmovups -0xb0(%rbp),%ymm14
 100b72d:	vmovups -0x90(%rbp),%ymm15
 100b735:	lea    -0x58(%rbp),%rsp
 100b739:	pop    %rbx
 100b73a:	pop    %r14
 100b73c:	pop    %r15
 100b73e:	pop    %rax
 100b73f:	pop    %rcx
 100b740:	pop    %rdx
 100b741:	pop    %rsi
 100b742:	pop    %rdi
 100b743:	pop    %r8
 100b745:	pop    %r9
 100b747:	pop    %r10
 100b749:	pop    %rbp
 100b74a:	vzeroupper
 100b74d:	ret
 100b74e:	mov    %rbx,%rdi
 100b751:	call   100b280 <myl_qbe_rc_trap>
 100b756:	mov    0x3e60(%rbx),%rdi
 100b75d:	mov    $0x1,%esi
 100b762:	call   101ef90 <longjmp@plt>
 100b767:	int3
 100b768:	int3
 100b769:	int3
 100b76a:	int3
 100b76b:	int3
 100b76c:	int3
 100b76d:	int3
 100b76e:	int3
 100b76f:	int3

000000000100b770 <myl_qbe_failed>:
 100b770:	xor    %eax,%eax
 100b772:	cmpq   $0x0,0x20(%rdi)
 100b777:	setne  %al
 100b77a:	ret
 100b77b:	int3
 100b77c:	int3
 100b77d:	int3
 100b77e:	int3
 100b77f:	int3

000000000100b780 <myl_qbe_fail_allocation>:
 100b780:	push   %rbp
 100b781:	mov    %rsp,%rbp
 100b784:	push   %rbx
 100b785:	push   %rax
 100b786:	mov    %rdi,%rbx
 100b789:	cmpq   $0x0,0x1860(%rdi)
 100b791:	je     100b7b3 <myl_qbe_fail_allocation+0x33>
 100b793:	lea    0x258(%rbx),%rdi
 100b79a:	call   10127a0 <myl_rc_take_failure>
 100b79f:	test   %eax,%eax
 100b7a1:	je     100b7b3 <myl_qbe_fail_allocation+0x33>
 100b7a3:	mov    %rbx,%rdi
 100b7a6:	mov    %eax,%esi
 100b7a8:	add    $0x8,%rsp
 100b7ac:	pop    %rbx
 100b7ad:	pop    %rbp
 100b7ae:	jmp    100b0c0 <myl_qbe_rc_status>
 100b7b3:	call   1018cf0 <myl_native_cow_take_depth_failure>
 100b7b8:	test   %eax,%eax
 100b7ba:	je     100b7c5 <myl_qbe_fail_allocation+0x45>
 100b7bc:	lea    -0x9aeb(%rip),%rsi        # 1001cd8 <__abi_tag+0x19dc>
 100b7c3:	jmp    100b7de <myl_qbe_fail_allocation+0x5e>
 100b7c5:	cmpl   $0x0,0x2c4(%rbx)
 100b7cc:	lea    -0xa0e1(%rip),%rax        # 10016f2 <__abi_tag+0x13f6>
 100b7d3:	lea    -0x9bb6(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100b7da:	cmove  %rax,%rsi
 100b7de:	mov    %rbx,%rdi
 100b7e1:	call   100b580 <fail>
 100b7e6:	add    $0x8,%rsp
 100b7ea:	pop    %rbx
 100b7eb:	pop    %rbp
 100b7ec:	ret
 100b7ed:	int3
 100b7ee:	int3
 100b7ef:	int3

000000000100b7f0 <myl_qbe_fail_iteration>:
 100b7f0:	push   %rbp
 100b7f1:	mov    %rsp,%rbp
 100b7f4:	lea    -0x9b95(%rip),%rsi        # 1001c66 <__abi_tag+0x196a>
 100b7fb:	call   100b580 <fail>
 100b800:	pop    %rbp
 100b801:	ret
 100b802:	int3
 100b803:	int3
 100b804:	int3
 100b805:	int3
 100b806:	int3
 100b807:	int3
 100b808:	int3
 100b809:	int3
 100b80a:	int3
 100b80b:	int3
 100b80c:	int3
 100b80d:	int3
 100b80e:	int3
 100b80f:	int3

000000000100b810 <myl_qbe_fail_normalized_index_bounds>:
 100b810:	cmpq   $0x0,0x20(%rdi)
 100b815:	jne    100b868 <myl_qbe_fail_normalized_index_bounds+0x58>
 100b817:	mov    %rsi,%rax
 100b81a:	sar    $0x3f,%rax
 100b81e:	and    %rdx,%rax
 100b821:	sub    %rax,%rsi
 100b824:	movabs $0x300000001,%rax
 100b82e:	mov    %rax,0x39e8(%rdi)
 100b835:	mov    %rsi,0x39f0(%rdi)
 100b83c:	mov    %rdx,0x39f8(%rdi)
 100b843:	vxorps %xmm0,%xmm0,%xmm0
 100b847:	vmovups %xmm0,0x3a00(%rdi)
 100b84f:	movq   $0x0,0x3a10(%rdi)
 100b85a:	lea    -0xa0ef(%rip),%rax        # 1001772 <__abi_tag+0x1476>
 100b861:	mov    %rax,0x3a18(%rdi)
 100b868:	push   %rbp
 100b869:	mov    %rsp,%rbp
 100b86c:	lea    -0x9c1b(%rip),%rsi        # 1001c58 <__abi_tag+0x195c>
 100b873:	call   100b580 <fail>
 100b878:	pop    %rbp
 100b879:	ret
 100b87a:	int3
 100b87b:	int3
 100b87c:	int3
 100b87d:	int3
 100b87e:	int3
 100b87f:	int3

000000000100b880 <myl_qbe_fail_overflow_op>:
 100b880:	cmp    $0x6,%rsi
 100b884:	ja     100b8ad <myl_qbe_fail_overflow_op+0x2d>
 100b886:	lea    -0x8aad(%rip),%rax        # 1002de0 <qbe_empty_registry+0x38>
 100b88d:	movslq (%rax,%rsi,4),%rsi
 100b891:	add    %rax,%rsi
 100b894:	jmp    *%rsi
 100b896:	lea    -0x9d28(%rip),%rax        # 1001b75 <__abi_tag+0x1879>
 100b89d:	cmpq   $0x0,0x20(%rdi)
 100b8a2:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b8a8:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b8ad:	cmp    $0x64,%rsi
 100b8b1:	je     100b8f9 <myl_qbe_fail_overflow_op+0x79>
 100b8b3:	cmp    $0x65,%rsi
 100b8b7:	jne    100b9ac <myl_qbe_fail_overflow_op+0x12c>
 100b8bd:	lea    -0x9e6d(%rip),%rax        # 1001a57 <__abi_tag+0x175b>
 100b8c4:	cmpq   $0x0,0x20(%rdi)
 100b8c9:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b8cf:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b8d1:	lea    -0x9fc4(%rip),%rax        # 1001914 <__abi_tag+0x1618>
 100b8d8:	cmpq   $0x0,0x20(%rdi)
 100b8dd:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b8e3:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b8e5:	lea    -0x9fd4(%rip),%rax        # 1001918 <__abi_tag+0x161c>
 100b8ec:	cmpq   $0x0,0x20(%rdi)
 100b8f1:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b8f7:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b8f9:	lea    -0xa0ce(%rip),%rax        # 1001832 <__abi_tag+0x1536>
 100b900:	cmpq   $0x0,0x20(%rdi)
 100b905:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b90b:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b90d:	lea    -0xa183(%rip),%rax        # 1001791 <__abi_tag+0x1495>
 100b914:	cmpq   $0x0,0x20(%rdi)
 100b919:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b91b:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b91d:	lea    -0x9d9c(%rip),%rax        # 1001b88 <__abi_tag+0x188c>
 100b924:	cmpq   $0x0,0x20(%rdi)
 100b929:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b92b:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b92d:	lea    -0xa1a9(%rip),%rax        # 100178b <__abi_tag+0x148f>
 100b934:	cmpq   $0x0,0x20(%rdi)
 100b939:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b93b:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b93d:	lea    -0xa036(%rip),%rax        # 100190e <__abi_tag+0x1612>
 100b944:	cmpq   $0x0,0x20(%rdi)
 100b949:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b94b:	mov    %r8,%rsi
 100b94e:	and    $0xfffffffffffffeff,%rsi
 100b955:	shr    $0x3,%r8d
 100b959:	and    $0x20,%r8d
 100b95d:	or     $0x1c,%r8d
 100b961:	movl   $0x1,0x39e8(%rdi)
 100b96b:	mov    %r8d,0x39ec(%rdi)
 100b972:	vxorps %xmm0,%xmm0,%xmm0
 100b976:	vmovups %xmm0,0x39f0(%rdi)
 100b97e:	mov    %rdx,0x3a00(%rdi)
 100b985:	mov    %rcx,0x3a08(%rdi)
 100b98c:	mov    %rsi,0x3a10(%rdi)
 100b993:	mov    %rax,0x3a18(%rdi)
 100b99a:	push   %rbp
 100b99b:	mov    %rsp,%rbp
 100b99e:	lea    -0x9e19(%rip),%rsi        # 1001b8c <__abi_tag+0x1890>
 100b9a5:	call   100b580 <fail>
 100b9aa:	pop    %rbp
 100b9ab:	ret
 100b9ac:	lea    -0x9e3a(%rip),%rax        # 1001b79 <__abi_tag+0x187d>
 100b9b3:	cmpq   $0x0,0x20(%rdi)
 100b9b8:	jne    100b99a <myl_qbe_fail_overflow_op+0x11a>
 100b9ba:	jmp    100b94b <myl_qbe_fail_overflow_op+0xcb>
 100b9bc:	int3
 100b9bd:	int3
 100b9be:	int3
 100b9bf:	int3

000000000100b9c0 <myl_qbe_fail_cast>:
 100b9c0:	cmpq   $0x0,0x20(%rdi)
 100b9c5:	jne    100ba1c <myl_qbe_fail_cast+0x5c>
 100b9c7:	mov    %rdx,%rax
 100b9ca:	and    $0xfffffffffffffeff,%rax
 100b9d0:	shr    $0x3,%edx
 100b9d3:	and    $0x20,%edx
 100b9d6:	or     $0x14,%edx
 100b9d9:	movl   $0x1,0x39e8(%rdi)
 100b9e3:	mov    %edx,0x39ec(%rdi)
 100b9e9:	vxorps %xmm0,%xmm0,%xmm0
 100b9ed:	vmovups %xmm0,0x39f0(%rdi)
 100b9f5:	mov    %rsi,0x3a00(%rdi)
 100b9fc:	movq   $0x0,0x3a08(%rdi)
 100ba07:	mov    %rax,0x3a10(%rdi)
 100ba0e:	lea    -0xa1e3(%rip),%rax        # 1001832 <__abi_tag+0x1536>
 100ba15:	mov    %rax,0x3a18(%rdi)
 100ba1c:	push   %rbp
 100ba1d:	mov    %rsp,%rbp
 100ba20:	lea    -0x9e9b(%rip),%rsi        # 1001b8c <__abi_tag+0x1890>
 100ba27:	call   100b580 <fail>
 100ba2c:	pop    %rbp
 100ba2d:	ret
 100ba2e:	int3
 100ba2f:	int3

000000000100ba30 <myl_qbe_heap>:
 100ba30:	lea    0x258(%rdi),%rax
 100ba37:	ret
 100ba38:	int3
 100ba39:	int3
 100ba3a:	int3
 100ba3b:	int3
 100ba3c:	int3
 100ba3d:	int3
 100ba3e:	int3
 100ba3f:	int3

000000000100ba40 <myl_qbe_fail_frame>:
 100ba40:	push   %rbp
 100ba41:	mov    %rsp,%rbp
 100ba44:	lea    -0x9e35(%rip),%rsi        # 1001c16 <__abi_tag+0x191a>
 100ba4b:	call   100b580 <fail>
 100ba50:	pop    %rbp
 100ba51:	ret
 100ba52:	int3
 100ba53:	int3
 100ba54:	int3
 100ba55:	int3
 100ba56:	int3
 100ba57:	int3
 100ba58:	int3
 100ba59:	int3
 100ba5a:	int3
 100ba5b:	int3
 100ba5c:	int3
 100ba5d:	int3
 100ba5e:	int3
 100ba5f:	int3

000000000100ba60 <myl_qbe_float_unary>:
 100ba60:	push   %rbp
 100ba61:	mov    %rsp,%rbp
 100ba64:	add    $0xfffffffffffffffe,%rsi
 100ba68:	cmp    $0x9,%rsi
 100ba6c:	ja     100bbbc <myl_qbe_float_unary+0x15c>
 100ba72:	vmovq  %rdx,%xmm0
 100ba77:	lea    -0x8c1e(%rip),%rax        # 1002e60 <qbe_empty_registry+0xb8>
 100ba7e:	movslq (%rax,%rsi,4),%rcx
 100ba82:	add    %rax,%rcx
 100ba85:	jmp    *%rcx
 100ba87:	vxorpd %xmm1,%xmm1,%xmm1
 100ba8b:	vucomisd %xmm1,%xmm0
 100ba8f:	jb     100bbd3 <myl_qbe_float_unary+0x173>
 100ba95:	vsqrtsd %xmm0,%xmm0,%xmm0
 100ba99:	jmp    100bbd8 <myl_qbe_float_unary+0x178>
 100ba9e:	mov    $0x3f,%al
 100baa0:	bzhi   %rax,%rdx,%rax
 100baa5:	pop    %rbp
 100baa6:	ret
 100baa7:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 100baad:	vmovq  %xmm0,%rax
 100bab2:	mov    $0x3f,%cl
 100bab4:	bzhi   %rcx,%rax,%rax
 100bab9:	movabs $0x7fefffffffffffff,%rcx
 100bac3:	cmp    %rcx,%rax
 100bac6:	jg     100bb7c <myl_qbe_float_unary+0x11c>
 100bacc:	vmovsd -0x8cb4(%rip),%xmm1        # 1002e20 <qbe_empty_registry+0x78>
 100bad4:	vucomisd %xmm0,%xmm1
 100bad8:	ja     100bb7c <myl_qbe_float_unary+0x11c>
 100bade:	vucomisd -0x8cce(%rip),%xmm0        # 1002e18 <qbe_empty_registry+0x70>
 100bae6:	jae    100bb7c <myl_qbe_float_unary+0x11c>
 100baec:	vcvttsd2si %xmm0,%rax
 100baf1:	pop    %rbp
 100baf2:	ret
 100baf3:	vroundsd $0xa,%xmm0,%xmm0,%xmm0
 100baf9:	jmp    100bbd8 <myl_qbe_float_unary+0x178>
 100bafe:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 100bb04:	jmp    100bbd8 <myl_qbe_float_unary+0x178>
 100bb09:	vroundsd $0xb,%xmm0,%xmm0,%xmm0
 100bb0f:	vmovq  %xmm0,%rax
 100bb14:	mov    $0x3f,%cl
 100bb16:	bzhi   %rcx,%rax,%rcx
 100bb1b:	movabs $0xfff0000000000000,%rdx
 100bb25:	add    %rcx,%rdx
 100bb28:	shr    $0x35,%rdx
 100bb2c:	cmp    $0x3ff,%edx
 100bb32:	setb   %dl
 100bb35:	test   %rax,%rax
 100bb38:	sets   %al
 100bb3b:	and    %dl,%al
 100bb3d:	movabs $0x7fefffffffffffff,%rdx
 100bb47:	cmp    %rdx,%rcx
 100bb4a:	setg   %cl
 100bb4d:	or     %al,%cl
 100bb4f:	jne    100bb7c <myl_qbe_float_unary+0x11c>
 100bb51:	vucomisd -0x8d49(%rip),%xmm0        # 1002e10 <qbe_empty_registry+0x68>
 100bb59:	jae    100bb7c <myl_qbe_float_unary+0x11c>
 100bb5b:	vcvttsd2si %xmm0,%rcx
 100bb60:	mov    %rcx,%rdx
 100bb63:	sar    $0x3f,%rdx
 100bb67:	vsubsd -0x8d57(%rip),%xmm0,%xmm0        # 1002e18 <qbe_empty_registry+0x70>
 100bb6f:	vcvttsd2si %xmm0,%rax
 100bb74:	and    %rdx,%rax
 100bb77:	or     %rcx,%rax
 100bb7a:	pop    %rbp
 100bb7b:	ret
 100bb7c:	lea    -0x9f03(%rip),%rsi        # 1001c80 <__abi_tag+0x1984>
 100bb83:	jmp    100bbc3 <myl_qbe_float_unary+0x163>
 100bb85:	vroundsd $0x9,%xmm0,%xmm0,%xmm0
 100bb8b:	jmp    100bbd8 <myl_qbe_float_unary+0x178>
 100bb8d:	movabs $0x8000000000000000,%rax
 100bb97:	xor    %rdx,%rax
 100bb9a:	pop    %rbp
 100bb9b:	ret
 100bb9c:	vmovq  %rdx,%xmm0
 100bba1:	vpunpckldq -0x8d69(%rip),%xmm0,%xmm0        # 1002e40 <qbe_empty_registry+0x98>
 100bba9:	vsubpd -0x8d81(%rip),%xmm0,%xmm0        # 1002e30 <qbe_empty_registry+0x88>
 100bbb1:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 100bbb6:	vaddsd %xmm0,%xmm1,%xmm0
 100bbba:	jmp    100bbd8 <myl_qbe_float_unary+0x178>
 100bbbc:	lea    -0x9ef6(%rip),%rsi        # 1001ccd <__abi_tag+0x19d1>
 100bbc3:	call   100b580 <fail>
 100bbc8:	xor    %eax,%eax
 100bbca:	pop    %rbp
 100bbcb:	ret
 100bbcc:	vcvtsi2sd %rdx,%xmm15,%xmm0
 100bbd1:	jmp    100bbd8 <myl_qbe_float_unary+0x178>
 100bbd3:	call   101ed90 <compiler_rt.sqrt.sqrt>
 100bbd8:	vmovq  %xmm0,%rax
 100bbdd:	pop    %rbp
 100bbde:	ret
 100bbdf:	int3

000000000100bbe0 <myl_qbe_require_step_accounting>:
 100bbe0:	cmpq   $0xffffffffffffffff,0x10(%rdi)
 100bbe5:	je     100bc2b <myl_qbe_require_step_accounting+0x4b>
 100bbe7:	cmpq   $0x0,0x20(%rdi)
 100bbec:	jne    100bc1a <myl_qbe_require_step_accounting+0x3a>
 100bbee:	movl   $0x1,0x39e8(%rdi)
 100bbf8:	vxorps %xmm0,%xmm0,%xmm0
 100bbfc:	vmovups %ymm0,0x39ec(%rdi)
 100bc04:	vmovups %ymm0,0x39f8(%rdi)
 100bc0c:	lea    -0xa2c4(%rip),%rax        # 100194f <__abi_tag+0x1653>
 100bc13:	mov    %rax,0x3a18(%rdi)
 100bc1a:	push   %rbp
 100bc1b:	mov    %rsp,%rbp
 100bc1e:	lea    -0x9f41(%rip),%rsi        # 1001ce4 <__abi_tag+0x19e8>
 100bc25:	call   100b580 <fail>
 100bc2a:	pop    %rbp
 100bc2b:	vzeroupper
 100bc2e:	ret
 100bc2f:	int3

000000000100bc30 <myl_qbe_require_frame_accounting>:
 100bc30:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 100bc35:	je     100bc7b <myl_qbe_require_frame_accounting+0x4b>
 100bc37:	cmpq   $0x0,0x20(%rdi)
 100bc3c:	jne    100bc6a <myl_qbe_require_frame_accounting+0x3a>
 100bc3e:	movl   $0x1,0x39e8(%rdi)
 100bc48:	vxorps %xmm0,%xmm0,%xmm0
 100bc4c:	vmovups %ymm0,0x39ec(%rdi)
 100bc54:	vmovups %ymm0,0x39f8(%rdi)
 100bc5c:	lea    -0xa2cb(%rip),%rax        # 1001998 <__abi_tag+0x169c>
 100bc63:	mov    %rax,0x3a18(%rdi)
 100bc6a:	push   %rbp
 100bc6b:	mov    %rsp,%rbp
 100bc6e:	lea    -0x9f7c(%rip),%rsi        # 1001cf9 <__abi_tag+0x19fd>
 100bc75:	call   100b580 <fail>
 100bc7a:	pop    %rbp
 100bc7b:	vzeroupper
 100bc7e:	ret
 100bc7f:	int3

000000000100bc80 <myl_qbe_control>:
 100bc80:	push   %rbp
 100bc81:	mov    %rsp,%rbp
 100bc84:	push   %r14
 100bc86:	push   %rbx
 100bc87:	mov    %rsi,%r14
 100bc8a:	mov    %rdi,%rbx
 100bc8d:	lea    -0x9f1c(%rip),%rsi        # 1001d78 <__abi_tag+0x1a7c>
 100bc94:	mov    $0xc,%edx
 100bc99:	mov    %r14,%rdi
 100bc9c:	call   101efe0 <strncmp@plt>
 100bca1:	test   %eax,%eax
 100bca3:	je     100bd30 <myl_qbe_control+0xb0>
 100bca9:	lea    -0x9f2b(%rip),%rsi        # 1001d85 <__abi_tag+0x1a89>
 100bcb0:	mov    $0xd,%edx
 100bcb5:	mov    %r14,%rdi
 100bcb8:	call   101efe0 <strncmp@plt>
 100bcbd:	test   %eax,%eax
 100bcbf:	je     100bdc6 <myl_qbe_control+0x146>
 100bcc5:	lea    -0x9f71(%rip),%rsi        # 1001d5b <__abi_tag+0x1a5f>
 100bccc:	mov    $0xa,%edx
 100bcd1:	mov    %r14,%rdi
 100bcd4:	call   101efe0 <strncmp@plt>
 100bcd9:	test   %eax,%eax
 100bcdb:	je     100be57 <myl_qbe_control+0x1d7>
 100bce1:	lea    -0xa45a(%rip),%rsi        # 100188e <__abi_tag+0x1592>
 100bce8:	mov    %r14,%rdi
 100bceb:	call   101eff0 <strcmp@plt>
 100bcf0:	test   %eax,%eax
 100bcf2:	je     100bee4 <myl_qbe_control+0x264>
 100bcf8:	lea    -0xa4c8(%rip),%rsi        # 1001837 <__abi_tag+0x153b>
 100bcff:	mov    %r14,%rdi
 100bd02:	call   101eff0 <strcmp@plt>
 100bd07:	mov    %eax,%ecx
 100bd09:	xor    %eax,%eax
 100bd0b:	test   %ecx,%ecx
 100bd0d:	jne    100bf01 <myl_qbe_control+0x281>
 100bd13:	cmpl   $0x0,0x28(%rbx)
 100bd17:	je     100bd24 <myl_qbe_control+0xa4>
 100bd19:	lea    -0xa472(%rip),%rax        # 10018ae <__abi_tag+0x15b2>
 100bd20:	mov    %rax,0x30(%rbx)
 100bd24:	movl   $0x1,0x28(%rbx)
 100bd2b:	jmp    100befc <myl_qbe_control+0x27c>
 100bd30:	movzbl 0xc(%r14),%edx
 100bd35:	test   %dl,%dl
 100bd37:	je     100bd96 <myl_qbe_control+0x116>
 100bd39:	add    $0xd,%r14
 100bd3d:	xor    %eax,%eax
 100bd3f:	movabs $0xcccccccccccccccd,%rcx
 100bd49:	nopl   0x0(%rax)
 100bd50:	lea    -0x3a(%rdx),%esi
 100bd53:	cmp    $0xf6,%sil
 100bd57:	jb     100bd96 <myl_qbe_control+0x116>
 100bd59:	add    $0xd0,%dl
 100bd5c:	movzbl %dl,%esi
 100bd5f:	mov    %rsi,%rdx
 100bd62:	not    %rdx
 100bd65:	mulx   %rcx,%rdx,%rdx
 100bd6a:	shr    $0x3,%rdx
 100bd6e:	cmp    %rdx,%rax
 100bd71:	ja     100bd96 <myl_qbe_control+0x116>
 100bd73:	lea    (%rax,%rax,4),%rax
 100bd77:	lea    (%rsi,%rax,2),%rax
 100bd7b:	movzbl (%r14),%edx
 100bd7f:	inc    %r14
 100bd82:	test   %dl,%dl
 100bd84:	jne    100bd50 <myl_qbe_control+0xd0>
 100bd86:	cmpl   $0x0,0x18(%rbx)
 100bd8a:	sete   %cl
 100bd8d:	jne    100bd9f <myl_qbe_control+0x11f>
 100bd8f:	test   %rax,%rax
 100bd92:	jne    100bdb7 <myl_qbe_control+0x137>
 100bd94:	jmp    100bd9f <myl_qbe_control+0x11f>
 100bd96:	cmpl   $0x0,0x18(%rbx)
 100bd9a:	sete   %cl
 100bd9d:	xor    %eax,%eax
 100bd9f:	lea    -0xa53b(%rip),%rdx        # 100186b <__abi_tag+0x156f>
 100bda6:	lea    -0xa4ff(%rip),%rsi        # 10018ae <__abi_tag+0x15b2>
 100bdad:	test   %cl,%cl
 100bdaf:	cmovne %rdx,%rsi
 100bdb3:	mov    %rsi,0x30(%rbx)
 100bdb7:	movl   $0x1,0x18(%rbx)
 100bdbe:	mov    %rax,(%rbx)
 100bdc1:	jmp    100befc <myl_qbe_control+0x27c>
 100bdc6:	movzbl 0xd(%r14),%edx
 100bdcb:	test   %dl,%dl
 100bdcd:	je     100be26 <myl_qbe_control+0x1a6>
 100bdcf:	add    $0xe,%r14
 100bdd3:	xor    %eax,%eax
 100bdd5:	movabs $0xcccccccccccccccd,%rcx
 100bddf:	nop
 100bde0:	lea    -0x3a(%rdx),%esi
 100bde3:	cmp    $0xf6,%sil
 100bde7:	jb     100be26 <myl_qbe_control+0x1a6>
 100bde9:	add    $0xd0,%dl
 100bdec:	movzbl %dl,%esi
 100bdef:	mov    %rsi,%rdx
 100bdf2:	not    %rdx
 100bdf5:	mulx   %rcx,%rdx,%rdx
 100bdfa:	shr    $0x3,%rdx
 100bdfe:	cmp    %rdx,%rax
 100be01:	ja     100be26 <myl_qbe_control+0x1a6>
 100be03:	lea    (%rax,%rax,4),%rax
 100be07:	lea    (%rsi,%rax,2),%rax
 100be0b:	movzbl (%r14),%edx
 100be0f:	inc    %r14
 100be12:	test   %dl,%dl
 100be14:	jne    100bde0 <myl_qbe_control+0x160>
 100be16:	cmpl   $0x0,0x1c(%rbx)
 100be1a:	sete   %cl
 100be1d:	jne    100be2f <myl_qbe_control+0x1af>
 100be1f:	test   %rax,%rax
 100be22:	jne    100be47 <myl_qbe_control+0x1c7>
 100be24:	jmp    100be2f <myl_qbe_control+0x1af>
 100be26:	cmpl   $0x0,0x1c(%rbx)
 100be2a:	sete   %cl
 100be2d:	xor    %eax,%eax
 100be2f:	lea    -0xa5cb(%rip),%rdx        # 100186b <__abi_tag+0x156f>
 100be36:	lea    -0xa58f(%rip),%rsi        # 10018ae <__abi_tag+0x15b2>
 100be3d:	test   %cl,%cl
 100be3f:	cmovne %rdx,%rsi
 100be43:	mov    %rsi,0x30(%rbx)
 100be47:	movl   $0x1,0x1c(%rbx)
 100be4e:	mov    %rax,0x8(%rbx)
 100be52:	jmp    100befc <myl_qbe_control+0x27c>
 100be57:	movzbl 0xa(%r14),%edx
 100be5c:	test   %dl,%dl
 100be5e:	je     100beb6 <myl_qbe_control+0x236>
 100be60:	add    $0xb,%r14
 100be64:	xor    %eax,%eax
 100be66:	movabs $0xcccccccccccccccd,%rcx
 100be70:	lea    -0x3a(%rdx),%esi
 100be73:	cmp    $0xf6,%sil
 100be77:	jb     100beb6 <myl_qbe_control+0x236>
 100be79:	add    $0xd0,%dl
 100be7c:	movzbl %dl,%esi
 100be7f:	mov    %rsi,%rdx
 100be82:	not    %rdx
 100be85:	mulx   %rcx,%rdx,%rdx
 100be8a:	shr    $0x3,%rdx
 100be8e:	cmp    %rdx,%rax
 100be91:	ja     100beb6 <myl_qbe_control+0x236>
 100be93:	lea    (%rax,%rax,4),%rax
 100be97:	lea    (%rsi,%rax,2),%rax
 100be9b:	movzbl (%r14),%edx
 100be9f:	inc    %r14
 100bea2:	test   %dl,%dl
 100bea4:	jne    100be70 <myl_qbe_control+0x1f0>
 100bea6:	cmpl   $0x0,0x20(%rbx)
 100beaa:	sete   %cl
 100bead:	jne    100bebf <myl_qbe_control+0x23f>
 100beaf:	test   %rax,%rax
 100beb2:	jne    100bed7 <myl_qbe_control+0x257>
 100beb4:	jmp    100bebf <myl_qbe_control+0x23f>
 100beb6:	cmpl   $0x0,0x20(%rbx)
 100beba:	sete   %cl
 100bebd:	xor    %eax,%eax
 100bebf:	lea    -0xa65b(%rip),%rdx        # 100186b <__abi_tag+0x156f>
 100bec6:	lea    -0xa61f(%rip),%rsi        # 10018ae <__abi_tag+0x15b2>
 100becd:	test   %cl,%cl
 100becf:	cmovne %rdx,%rsi
 100bed3:	mov    %rsi,0x30(%rbx)
 100bed7:	movl   $0x1,0x20(%rbx)
 100bede:	mov    %rax,0x10(%rbx)
 100bee2:	jmp    100befc <myl_qbe_control+0x27c>
 100bee4:	cmpl   $0x0,0x24(%rbx)
 100bee8:	je     100bf06 <myl_qbe_control+0x286>
 100beea:	lea    -0xa643(%rip),%rax        # 10018ae <__abi_tag+0x15b2>
 100bef1:	mov    %rax,0x30(%rbx)
 100bef5:	movl   $0x1,0x24(%rbx)
 100befc:	mov    $0x1,%eax
 100bf01:	pop    %rbx
 100bf02:	pop    %r14
 100bf04:	pop    %rbp
 100bf05:	ret
 100bf06:	cmpq   $0x0,0x30(%rbx)
 100bf0b:	movl   $0x1,0x24(%rbx)
 100bf12:	mov    $0x1,%eax
 100bf17:	jne    100bf01 <myl_qbe_control+0x281>
 100bf19:	lea    -0x9090(%rip),%rcx        # 1002e90 <stress_needs_gc>
 100bf20:	mov    %rcx,0x30(%rbx)
 100bf24:	jmp    100bf01 <myl_qbe_control+0x281>
 100bf26:	int3
 100bf27:	int3
 100bf28:	int3
 100bf29:	int3
 100bf2a:	int3
 100bf2b:	int3
 100bf2c:	int3
 100bf2d:	int3
 100bf2e:	int3
 100bf2f:	int3

000000000100bf30 <mylang_qbe_run_process>:
 100bf30:	push   %rbp
 100bf31:	mov    %rsp,%rbp
 100bf34:	push   %r15
 100bf36:	push   %r14
 100bf38:	push   %r13
 100bf3a:	push   %r12
 100bf3c:	push   %rbx
 100bf3d:	sub    $0xc98,%rsp
 100bf44:	mov    %edx,%r14d
 100bf47:	mov    0x30(%rsi),%rdx
 100bf4b:	lea    -0x90c2(%rip),%rax        # 1002e90 <stress_needs_gc>
 100bf52:	cmp    %rax,%rdx
 100bf55:	je     100c1c7 <mylang_qbe_run_process+0x297>
 100bf5b:	test   %rdx,%rdx
 100bf5e:	jne    100c1df <mylang_qbe_run_process+0x2af>
 100bf64:	mov    %rcx,%r15
 100bf67:	mov    %rsi,%rbx
 100bf6a:	mov    $0xffffffffffffffff,%r13
 100bf71:	cmpl   $0x0,0x18(%rsi)
 100bf75:	mov    $0xffffffffffffffff,%rax
 100bf7c:	je     100bf81 <mylang_qbe_run_process+0x51>
 100bf7e:	mov    (%rbx),%rax
 100bf81:	mov    %rax,-0x58(%rbp)
 100bf85:	mov    %rdi,-0x48(%rbp)
 100bf89:	mov    %r8,-0x38(%rbp)
 100bf8d:	cmpl   $0x0,0x1c(%rbx)
 100bf91:	je     100bf97 <mylang_qbe_run_process+0x67>
 100bf93:	mov    0x8(%rbx),%r13
 100bf97:	mov    0x10(%rbx),%r12
 100bf9b:	test   %r12,%r12
 100bf9e:	je     100c07e <mylang_qbe_run_process+0x14e>
 100bfa4:	lea    -0x8b8(%rbp),%rdi
 100bfab:	vxorps %xmm0,%xmm0,%xmm0
 100bfaf:	vmovups %ymm0,-0x848(%rbp)
 100bfb7:	vmovups %ymm0,-0x858(%rbp)
 100bfbf:	vmovups %ymm0,-0x878(%rbp)
 100bfc7:	vmovups %ymm0,-0x898(%rbp)
 100bfcf:	vmovups %ymm0,-0x8b8(%rbp)
 100bfd7:	lea    0x14f2(%rip),%rax        # 100d4d0 <on_timeout>
 100bfde:	mov    %rax,-0x8c0(%rbp)
 100bfe5:	vzeroupper
 100bfe8:	call   101f000 <sigemptyset@plt>
 100bfed:	lea    -0x8c0(%rbp),%rsi
 100bff4:	mov    $0xe,%edi
 100bff9:	xor    %edx,%edx
 100bffb:	call   101f010 <sigaction@plt>
 100c000:	test   %eax,%eax
 100c002:	jne    100c1af <mylang_qbe_run_process+0x27f>
 100c008:	vxorps %xmm0,%xmm0,%xmm0
 100c00c:	vmovups %ymm0,-0xcc0(%rbp)
 100c014:	vmovups %ymm0,-0xca0(%rbp)
 100c01c:	movl   $0xe,-0xcb8(%rbp)
 100c026:	lea    0x1e7ab(%rip),%rdx        # 102a7d8 <timeout_timer>
 100c02d:	lea    -0xcc0(%rbp),%rsi
 100c034:	mov    $0x1,%edi
 100c039:	vzeroupper
 100c03c:	call   101f020 <timer_create@plt>
 100c041:	test   %eax,%eax
 100c043:	jne    100c1af <mylang_qbe_run_process+0x27f>
 100c049:	vxorps %xmm0,%xmm0,%xmm0
 100c04d:	vmovups %ymm0,-0x2c0(%rbp)
 100c055:	mov    %r12,-0x2b0(%rbp)
 100c05c:	mov    0x1e775(%rip),%rdi        # 102a7d8 <timeout_timer>
 100c063:	lea    -0x2c0(%rbp),%rdx
 100c06a:	xor    %esi,%esi
 100c06c:	xor    %ecx,%ecx
 100c06e:	vzeroupper
 100c071:	call   101f030 <timer_settime@plt>
 100c076:	test   %eax,%eax
 100c078:	jne    100c1af <mylang_qbe_run_process+0x27f>
 100c07e:	mov    %r13,-0x50(%rbp)
 100c082:	mov    %r14,-0x40(%rbp)
 100c086:	test   %r14d,%r14d
 100c089:	jle    100c0c7 <mylang_qbe_run_process+0x197>
 100c08b:	mov    -0x40(%rbp),%r13d
 100c08f:	xor    %r14d,%r14d
 100c092:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100c0a0:	mov    (%r15,%r14,8),%r12
 100c0a4:	mov    %r12,%rdi
 100c0a7:	call   101e660 <compiler_rt.strlen>
 100c0ac:	mov    %r12,%rdi
 100c0af:	mov    %rax,%rsi
 100c0b2:	call   1012420 <myl_native_text_valid_utf8>
 100c0b7:	test   %eax,%eax
 100c0b9:	je     100c1f9 <mylang_qbe_run_process+0x2c9>
 100c0bf:	inc    %r14
 100c0c2:	cmp    %r14,%r13
 100c0c5:	jne    100c0a0 <mylang_qbe_run_process+0x170>
 100c0c7:	mov    0x24(%rbx),%ecx
 100c0ca:	sub    $0x8,%rsp
 100c0ce:	lea    -0x2c0(%rbp),%rax
 100c0d5:	mov    -0x48(%rbp),%rdi
 100c0d9:	mov    -0x58(%rbp),%rsi
 100c0dd:	mov    -0x50(%rbp),%rdx
 100c0e1:	mov    -0x38(%rbp),%r8
 100c0e5:	xor    %r9d,%r9d
 100c0e8:	push   %rax
 100c0e9:	push   %r15
 100c0eb:	push   -0x40(%rbp)
 100c0ee:	call   100c840 <execute_config_args>
 100c0f3:	add    $0x20,%rsp
 100c0f7:	test   %eax,%eax
 100c0f9:	je     100c18b <mylang_qbe_run_process+0x25b>
 100c0ff:	mov    $0x2,%eax
 100c104:	cmpl   $0x0,-0x98(%rbp)
 100c10b:	jne    100c21e <mylang_qbe_run_process+0x2ee>
 100c111:	lea    -0xcc0(%rbp),%rdi
 100c118:	mov    $0x400,%edx
 100c11d:	xor    %esi,%esi
 100c11f:	call   101e6b0 <compiler_rt.fastMemset>
 100c124:	movq   $0x0,-0x8c0(%rbp)
 100c12f:	movb   $0x0,-0xcc0(%rbp)
 100c136:	mov    -0x90(%rbp),%eax
 100c13c:	mov    %eax,-0x40(%rbp)
 100c13f:	test   %eax,%eax
 100c141:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c147:	mov    -0x8c(%rbp),%ebx
 100c14d:	test   $0x1,%bl
 100c150:	jne    100c230 <mylang_qbe_run_process+0x300>
 100c156:	test   $0x2,%bl
 100c159:	jne    100c2ad <mylang_qbe_run_process+0x37d>
 100c15f:	mov    -0x60(%rbp),%r8
 100c163:	test   $0x1c,%bl
 100c166:	jne    100c60c <mylang_qbe_run_process+0x6dc>
 100c16c:	test   %r8,%r8
 100c16f:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c175:	cmpb   $0x0,(%r8)
 100c179:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c17f:	lea    -0xa8eb(%rip),%rcx        # 100189b <__abi_tag+0x159f>
 100c186:	jmp    100c2b8 <mylang_qbe_run_process+0x388>
 100c18b:	mov    -0x2c0(%rbp),%r14
 100c192:	cmpl   $0x0,0x28(%rbx)
 100c196:	je     100c1a9 <mylang_qbe_run_process+0x279>
 100c198:	lea    -0xa045(%rip),%rdi        # 100215a <__abi_tag+0x1e5e>
 100c19f:	mov    %r14,%rsi
 100c1a2:	xor    %eax,%eax
 100c1a4:	call   101f040 <printf@plt>
 100c1a9:	movzbl %r14b,%eax
 100c1ad:	jmp    100c21e <mylang_qbe_run_process+0x2ee>
 100c1af:	mov    0x1d3c2(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100c1b6:	mov    (%rax),%rcx
 100c1b9:	lea    -0xa099(%rip),%rdi        # 1002127 <__abi_tag+0x1e2b>
 100c1c0:	mov    $0x32,%esi
 100c1c5:	jmp    100c20f <mylang_qbe_run_process+0x2df>
 100c1c7:	mov    0x1d3aa(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100c1ce:	mov    (%rax),%rcx
 100c1d1:	lea    -0xa17d(%rip),%rdi        # 100205b <__abi_tag+0x1d5f>
 100c1d8:	mov    $0x5e,%esi
 100c1dd:	jmp    100c20f <mylang_qbe_run_process+0x2df>
 100c1df:	mov    0x1d392(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100c1e6:	mov    (%rax),%rdi
 100c1e9:	lea    -0xa0e2(%rip),%rsi        # 100210e <__abi_tag+0x1e12>
 100c1f0:	xor    %eax,%eax
 100c1f2:	call   101efb0 <fprintf@plt>
 100c1f7:	jmp    100c219 <mylang_qbe_run_process+0x2e9>
 100c1f9:	mov    0x1d378(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100c200:	mov    (%rax),%rcx
 100c203:	lea    -0xa072(%rip),%rdi        # 1002198 <__abi_tag+0x1e9c>
 100c20a:	mov    $0x2a,%esi
 100c20f:	mov    $0x1,%edx
 100c214:	call   101efa0 <fwrite@plt>
 100c219:	mov    $0x2,%eax
 100c21e:	add    $0xc98,%rsp
 100c225:	pop    %rbx
 100c226:	pop    %r12
 100c228:	pop    %r13
 100c22a:	pop    %r14
 100c22c:	pop    %r15
 100c22e:	pop    %rbp
 100c22f:	ret
 100c230:	mov    -0x88(%rbp),%r8
 100c237:	lea    -0xa783(%rip),%rcx        # 1001abb <__abi_tag+0x17bf>
 100c23e:	lea    -0xcc0(%rbp),%rdi
 100c245:	lea    -0x8c0(%rbp),%rdx
 100c24c:	mov    $0x400,%esi
 100c251:	xor    %eax,%eax
 100c253:	call   100cbd0 <append>
 100c258:	test   %eax,%eax
 100c25a:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c25c:	test   $0x2,%bl
 100c25f:	je     100c28a <mylang_qbe_run_process+0x35a>
 100c261:	mov    -0x80(%rbp),%r8
 100c265:	lea    -0xaa60(%rip),%rcx        # 100180c <__abi_tag+0x1510>
 100c26c:	lea    -0xcc0(%rbp),%rdi
 100c273:	lea    -0x8c0(%rbp),%rdx
 100c27a:	mov    $0x400,%esi
 100c27f:	xor    %eax,%eax
 100c281:	call   100cbd0 <append>
 100c286:	test   %eax,%eax
 100c288:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c28a:	lea    -0xa418(%rip),%rcx        # 1001e79 <__abi_tag+0x1b7d>
 100c291:	lea    -0xcc0(%rbp),%rdi
 100c298:	lea    -0x8c0(%rbp),%rdx
 100c29f:	mov    $0x400,%esi
 100c2a4:	xor    %eax,%eax
 100c2a6:	call   100cbd0 <append>
 100c2ab:	jmp    100c2d2 <mylang_qbe_run_process+0x3a2>
 100c2ad:	mov    -0x80(%rbp),%r8
 100c2b1:	lea    -0xa4d8(%rip),%rcx        # 1001de0 <__abi_tag+0x1ae4>
 100c2b8:	lea    -0xcc0(%rbp),%rdi
 100c2bf:	lea    -0x8c0(%rbp),%rdx
 100c2c6:	mov    $0x400,%esi
 100c2cb:	xor    %eax,%eax
 100c2cd:	call   100cbd0 <append>
 100c2d2:	mov    -0x2b0(%rbp),%r14
 100c2d9:	lea    -0xa693(%rip),%rsi        # 1001c4d <__abi_tag+0x1951>
 100c2e0:	mov    %r14,%rdi
 100c2e3:	call   101eff0 <strcmp@plt>
 100c2e8:	test   %eax,%eax
 100c2ea:	sete   %al
 100c2ed:	mov    -0xa8(%rbp),%rbx
 100c2f4:	cmp    $0x2,%rbx
 100c2f8:	setae  %cl
 100c2fb:	and    %al,%cl
 100c2fd:	cmp    $0x1,%cl
 100c300:	jne    100c35a <mylang_qbe_run_process+0x42a>
 100c302:	lea    -0xcc0(%rbp),%r12
 100c309:	mov    %r12,%rdi
 100c30c:	call   101e660 <compiler_rt.strlen>
 100c311:	mov    %rax,-0x8c0(%rbp)
 100c318:	mov    -0x288(%rbp),%r8
 100c31f:	mov    -0x280(%rbp),%r9
 100c326:	vmovups -0x278(%rbp),%xmm0
 100c32e:	sub    $0x10,%rsp
 100c332:	vmovups %xmm0,(%rsp)
 100c337:	lea    -0xaba4(%rip),%rcx        # 100179a <__abi_tag+0x149e>
 100c33e:	lea    -0x8c0(%rbp),%rdx
 100c345:	mov    $0x400,%esi
 100c34a:	mov    %r12,%rdi
 100c34d:	xor    %eax,%eax
 100c34f:	call   100cbd0 <append>
 100c354:	add    $0x10,%rsp
 100c358:	jmp    100c397 <mylang_qbe_run_process+0x467>
 100c35a:	test   %rbx,%rbx
 100c35d:	jne    100c397 <mylang_qbe_run_process+0x467>
 100c35f:	mov    0x1d212(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100c366:	mov    (%rax),%r15
 100c369:	mov    %r14,%rdi
 100c36c:	call   100cd90 <describe>
 100c371:	lea    -0xa398(%rip),%rsi        # 1001fe0 <__abi_tag+0x1ce4>
 100c378:	lea    -0xcc0(%rbp),%r8
 100c37f:	mov    %r15,%rdi
 100c382:	mov    %r14,%r13
 100c385:	mov    %r14,%rdx
 100c388:	mov    %rax,%rcx
 100c38b:	xor    %eax,%eax
 100c38d:	call   101efb0 <fprintf@plt>
 100c392:	jmp    100c435 <mylang_qbe_run_process+0x505>
 100c397:	mov    0x1d1da(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100c39e:	mov    (%rax),%r12
 100c3a1:	mov    -0x2a0(%rbp),%rax
 100c3a8:	mov    %rax,-0x38(%rbp)
 100c3ac:	mov    -0x298(%rbp),%rax
 100c3b3:	mov    %rax,-0x48(%rbp)
 100c3b7:	lea    -0x290(%rbp),%r15
 100c3be:	mov    -0x290(%rbp),%r13
 100c3c5:	mov    %r14,%rdi
 100c3c8:	call   100cd90 <describe>
 100c3cd:	mov    %rax,%r10
 100c3d0:	lea    -0xa3ed(%rip),%rsi        # 1001fea <__abi_tag+0x1cee>
 100c3d7:	mov    %r12,%rdi
 100c3da:	mov    0x1d197(%rip),%r12        # 1029578 <stderr@GLIBC_2.2.5>
 100c3e1:	mov    -0x38(%rbp),%rdx
 100c3e5:	mov    -0x48(%rbp),%rcx
 100c3e9:	mov    %r13,%r8
 100c3ec:	mov    %r14,%r13
 100c3ef:	mov    %r14,%r9
 100c3f2:	xor    %eax,%eax
 100c3f4:	lea    -0xcc0(%rbp),%r11
 100c3fb:	push   %r11
 100c3fd:	push   %r10
 100c3ff:	call   101efb0 <fprintf@plt>
 100c404:	add    $0x10,%rsp
 100c408:	lea    -0xa584(%rip),%r14        # 1001e8b <__abi_tag+0x1b8f>
 100c40f:	mov    -0x18(%r15),%rdx
 100c413:	mov    -0x10(%r15),%rcx
 100c417:	mov    -0x8(%r15),%r8
 100c41b:	mov    (%r15),%r9
 100c41e:	mov    (%r12),%rdi
 100c422:	mov    %r14,%rsi
 100c425:	xor    %eax,%eax
 100c427:	call   101efb0 <fprintf@plt>
 100c42c:	add    $0x20,%r15
 100c430:	dec    %rbx
 100c433:	jne    100c40f <mylang_qbe_run_process+0x4df>
 100c435:	movq   $0x0,-0x30(%rbp)
 100c43d:	movb   $0x0,-0x8c0(%rbp)
 100c444:	mov    -0x40(%rbp),%r8d
 100c448:	test   %r8d,%r8d
 100c44b:	je     100c775 <mylang_qbe_run_process+0x845>
 100c451:	mov    -0x8c(%rbp),%eax
 100c457:	mov    %eax,-0x38(%rbp)
 100c45a:	lea    -0xa6ab(%rip),%rcx        # 1001db6 <__abi_tag+0x1aba>
 100c461:	lea    -0x8c0(%rbp),%rdi
 100c468:	lea    -0x30(%rbp),%rdx
 100c46c:	mov    $0x600,%esi
 100c471:	xor    %eax,%eax
 100c473:	call   100cbd0 <append>
 100c478:	test   %eax,%eax
 100c47a:	je     100c775 <mylang_qbe_run_process+0x845>
 100c480:	mov    -0x60(%rbp),%r14
 100c484:	lea    -0xa610(%rip),%rcx        # 1001e7b <__abi_tag+0x1b7f>
 100c48b:	lea    -0x8c0(%rbp),%rdi
 100c492:	lea    -0x30(%rbp),%rdx
 100c496:	mov    $0x600,%esi
 100c49b:	xor    %eax,%eax
 100c49d:	call   100cbd0 <append>
 100c4a2:	test   %eax,%eax
 100c4a4:	je     100c775 <mylang_qbe_run_process+0x845>
 100c4aa:	test   %r14,%r14
 100c4ad:	lea    -0xabc4(%rip),%rbx        # 10018f0 <__abi_tag+0x15f4>
 100c4b4:	cmovne %r14,%rbx
 100c4b8:	movzbl (%rbx),%eax
 100c4bb:	test   %al,%al
 100c4bd:	je     100c530 <mylang_qbe_run_process+0x600>
 100c4bf:	inc    %rbx
 100c4c2:	lea    -0xa945(%rip),%r14        # 1001b84 <__abi_tag+0x1888>
 100c4c9:	lea    -0x8c0(%rbp),%r15
 100c4d0:	lea    -0x30(%rbp),%r12
 100c4d4:	movzbl %al,%r8d
 100c4d8:	cmp    $0x5c,%r8b
 100c4dc:	je     100c4e4 <mylang_qbe_run_process+0x5b4>
 100c4de:	cmp    $0x22,%r8d
 100c4e2:	jne    100c50d <mylang_qbe_run_process+0x5dd>
 100c4e4:	mov    $0x600,%esi
 100c4e9:	mov    %r15,%rdi
 100c4ec:	mov    %r12,%rdx
 100c4ef:	mov    %r14,%rcx
 100c4f2:	xor    %eax,%eax
 100c4f4:	call   100cbd0 <append>
 100c4f9:	test   %eax,%eax
 100c4fb:	je     100c775 <mylang_qbe_run_process+0x845>
 100c501:	movzbl (%rbx),%eax
 100c504:	inc    %rbx
 100c507:	test   %al,%al
 100c509:	jne    100c4d4 <mylang_qbe_run_process+0x5a4>
 100c50b:	jmp    100c530 <mylang_qbe_run_process+0x600>
 100c50d:	mov    $0x600,%esi
 100c512:	mov    %r15,%rdi
 100c515:	mov    %r12,%rdx
 100c518:	cmp    $0x1f,%r8b
 100c51c:	ja     100c527 <mylang_qbe_run_process+0x5f7>
 100c51e:	lea    -0xadad(%rip),%rcx        # 1001778 <__abi_tag+0x147c>
 100c525:	jmp    100c4f2 <mylang_qbe_run_process+0x5c2>
 100c527:	lea    -0xa9a9(%rip),%rcx        # 1001b85 <__abi_tag+0x1889>
 100c52e:	jmp    100c4f2 <mylang_qbe_run_process+0x5c2>
 100c530:	lea    -0xa6bc(%rip),%rcx        # 1001e7b <__abi_tag+0x1b7f>
 100c537:	lea    -0x8c0(%rbp),%rdi
 100c53e:	lea    -0x30(%rbp),%rdx
 100c542:	mov    $0x600,%esi
 100c547:	xor    %eax,%eax
 100c549:	call   100cbd0 <append>
 100c54e:	test   %eax,%eax
 100c550:	je     100c775 <mylang_qbe_run_process+0x845>
 100c556:	testb  $0x1,-0x38(%rbp)
 100c55a:	je     100c589 <mylang_qbe_run_process+0x659>
 100c55c:	mov    -0x88(%rbp),%r8
 100c563:	lea    -0xaad5(%rip),%rcx        # 1001a95 <__abi_tag+0x1799>
 100c56a:	lea    -0x8c0(%rbp),%rdi
 100c571:	lea    -0x30(%rbp),%rdx
 100c575:	mov    $0x600,%esi
 100c57a:	xor    %eax,%eax
 100c57c:	call   100cbd0 <append>
 100c581:	test   %eax,%eax
 100c583:	je     100c775 <mylang_qbe_run_process+0x845>
 100c589:	testb  $0x2,-0x38(%rbp)
 100c58d:	je     100c5b9 <mylang_qbe_run_process+0x689>
 100c58f:	mov    -0x80(%rbp),%r8
 100c593:	lea    -0xadbf(%rip),%rcx        # 10017db <__abi_tag+0x14df>
 100c59a:	lea    -0x8c0(%rbp),%rdi
 100c5a1:	lea    -0x30(%rbp),%rdx
 100c5a5:	mov    $0x600,%esi
 100c5aa:	xor    %eax,%eax
 100c5ac:	call   100cbd0 <append>
 100c5b1:	test   %eax,%eax
 100c5b3:	je     100c775 <mylang_qbe_run_process+0x845>
 100c5b9:	mov    -0x38(%rbp),%eax
 100c5bc:	test   $0x20,%al
 100c5be:	jne    100c69a <mylang_qbe_run_process+0x76a>
 100c5c4:	test   $0x4,%al
 100c5c6:	je     100c5f2 <mylang_qbe_run_process+0x6c2>
 100c5c8:	mov    -0x78(%rbp),%r8
 100c5cc:	lea    -0xab24(%rip),%rcx        # 1001aaf <__abi_tag+0x17b3>
 100c5d3:	lea    -0x8c0(%rbp),%rdi
 100c5da:	lea    -0x30(%rbp),%rdx
 100c5de:	mov    $0x600,%esi
 100c5e3:	xor    %eax,%eax
 100c5e5:	call   100cbd0 <append>
 100c5ea:	test   %eax,%eax
 100c5ec:	je     100c775 <mylang_qbe_run_process+0x845>
 100c5f2:	testb  $0x8,-0x38(%rbp)
 100c5f6:	je     100c71c <mylang_qbe_run_process+0x7ec>
 100c5fc:	mov    -0x70(%rbp),%r8
 100c600:	lea    -0xab65(%rip),%rcx        # 1001aa2 <__abi_tag+0x17a6>
 100c607:	jmp    100c701 <mylang_qbe_run_process+0x7d1>
 100c60c:	test   %r8,%r8
 100c60f:	lea    -0xaa9d(%rip),%rax        # 1001b79 <__abi_tag+0x187d>
 100c616:	cmovne %r8,%rax
 100c61a:	lea    -0xa871(%rip),%rcx        # 1001db0 <__abi_tag+0x1ab4>
 100c621:	lea    -0xcc0(%rbp),%rdi
 100c628:	lea    -0x8c0(%rbp),%rdx
 100c62f:	mov    $0x400,%esi
 100c634:	mov    %rax,%r8
 100c637:	xor    %eax,%eax
 100c639:	call   100cbd0 <append>
 100c63e:	test   %eax,%eax
 100c640:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c646:	test   $0x20,%bl
 100c649:	jne    100c796 <mylang_qbe_run_process+0x866>
 100c64f:	test   $0x4,%bl
 100c652:	je     100c681 <mylang_qbe_run_process+0x751>
 100c654:	mov    -0x78(%rbp),%r8
 100c658:	lea    -0xab8c(%rip),%rcx        # 1001ad3 <__abi_tag+0x17d7>
 100c65f:	lea    -0xcc0(%rbp),%rdi
 100c666:	lea    -0x8c0(%rbp),%rdx
 100c66d:	mov    $0x400,%esi
 100c672:	xor    %eax,%eax
 100c674:	call   100cbd0 <append>
 100c679:	test   %eax,%eax
 100c67b:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c681:	test   $0x8,%bl
 100c684:	je     100c7fa <mylang_qbe_run_process+0x8ca>
 100c68a:	mov    -0x70(%rbp),%r8
 100c68e:	lea    -0xabce(%rip),%rcx        # 1001ac7 <__abi_tag+0x17cb>
 100c695:	jmp    100c7d8 <mylang_qbe_run_process+0x8a8>
 100c69a:	lea    -0xac3c(%rip),%rcx        # 1001a65 <__abi_tag+0x1769>
 100c6a1:	lea    -0x8c0(%rbp),%rdi
 100c6a8:	lea    -0x30(%rbp),%rdx
 100c6ac:	mov    $0x600,%esi
 100c6b1:	xor    %eax,%eax
 100c6b3:	call   100cbd0 <append>
 100c6b8:	test   %eax,%eax
 100c6ba:	je     100c775 <mylang_qbe_run_process+0x845>
 100c6c0:	testb  $0x4,-0x38(%rbp)
 100c6c4:	je     100c6f0 <mylang_qbe_run_process+0x7c0>
 100c6c6:	mov    -0x78(%rbp),%r8
 100c6ca:	lea    -0xaf02(%rip),%rcx        # 10017cf <__abi_tag+0x14d3>
 100c6d1:	lea    -0x8c0(%rbp),%rdi
 100c6d8:	lea    -0x30(%rbp),%rdx
 100c6dc:	mov    $0x600,%esi
 100c6e1:	xor    %eax,%eax
 100c6e3:	call   100cbd0 <append>
 100c6e8:	test   %eax,%eax
 100c6ea:	je     100c775 <mylang_qbe_run_process+0x845>
 100c6f0:	testb  $0x8,-0x38(%rbp)
 100c6f4:	je     100c71c <mylang_qbe_run_process+0x7ec>
 100c6f6:	mov    -0x70(%rbp),%r8
 100c6fa:	lea    -0xaf3f(%rip),%rcx        # 10017c2 <__abi_tag+0x14c6>
 100c701:	lea    -0x8c0(%rbp),%rdi
 100c708:	lea    -0x30(%rbp),%rdx
 100c70c:	mov    $0x600,%esi
 100c711:	xor    %eax,%eax
 100c713:	call   100cbd0 <append>
 100c718:	test   %eax,%eax
 100c71a:	je     100c775 <mylang_qbe_run_process+0x845>
 100c71c:	testb  $0x10,-0x38(%rbp)
 100c720:	je     100c748 <mylang_qbe_run_process+0x818>
 100c722:	mov    -0x68(%rbp),%r8
 100c726:	lea    -0xaf44(%rip),%rcx        # 10017e9 <__abi_tag+0x14ed>
 100c72d:	lea    -0x8c0(%rbp),%rdi
 100c734:	lea    -0x30(%rbp),%rdx
 100c738:	mov    $0x600,%esi
 100c73d:	xor    %eax,%eax
 100c73f:	call   100cbd0 <append>
 100c744:	test   %eax,%eax
 100c746:	je     100c775 <mylang_qbe_run_process+0x845>
 100c748:	lea    -0xb05f(%rip),%rcx        # 10016f0 <__abi_tag+0x13f4>
 100c74f:	lea    -0x8c0(%rbp),%rdi
 100c756:	lea    -0x30(%rbp),%rdx
 100c75a:	mov    $0x600,%esi
 100c75f:	xor    %eax,%eax
 100c761:	call   100cbd0 <append>
 100c766:	test   %eax,%eax
 100c768:	je     100c775 <mylang_qbe_run_process+0x845>
 100c76a:	cmpq   $0x0,-0x30(%rbp)
 100c76f:	jne    100c813 <mylang_qbe_run_process+0x8e3>
 100c775:	mov    $0x2,%eax
 100c77a:	cmpb   $0x52,0x0(%r13)
 100c77f:	jne    100c21e <mylang_qbe_run_process+0x2ee>
 100c785:	xor    %eax,%eax
 100c787:	cmpb   $0x5f,0x1(%r13)
 100c78c:	setne  %al
 100c78f:	inc    %eax
 100c791:	jmp    100c21e <mylang_qbe_run_process+0x2ee>
 100c796:	test   $0x4,%bl
 100c799:	je     100c7c8 <mylang_qbe_run_process+0x898>
 100c79b:	mov    -0x78(%rbp),%r8
 100c79f:	lea    -0xafa4(%rip),%rcx        # 1001802 <__abi_tag+0x1506>
 100c7a6:	lea    -0xcc0(%rbp),%rdi
 100c7ad:	lea    -0x8c0(%rbp),%rdx
 100c7b4:	mov    $0x400,%esi
 100c7b9:	xor    %eax,%eax
 100c7bb:	call   100cbd0 <append>
 100c7c0:	test   %eax,%eax
 100c7c2:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c7c8:	test   $0x8,%bl
 100c7cb:	je     100c7fa <mylang_qbe_run_process+0x8ca>
 100c7cd:	mov    -0x70(%rbp),%r8
 100c7d1:	lea    -0xafe2(%rip),%rcx        # 10017f6 <__abi_tag+0x14fa>
 100c7d8:	lea    -0xcc0(%rbp),%rdi
 100c7df:	lea    -0x8c0(%rbp),%rdx
 100c7e6:	mov    $0x400,%esi
 100c7eb:	xor    %eax,%eax
 100c7ed:	call   100cbd0 <append>
 100c7f2:	test   %eax,%eax
 100c7f4:	je     100c2d2 <mylang_qbe_run_process+0x3a2>
 100c7fa:	test   $0x10,%bl
 100c7fd:	je     100c28a <mylang_qbe_run_process+0x35a>
 100c803:	mov    -0x68(%rbp),%r8
 100c807:	lea    -0xaff5(%rip),%rcx        # 1001819 <__abi_tag+0x151d>
 100c80e:	jmp    100c26c <mylang_qbe_run_process+0x33c>
 100c813:	mov    0x1cd5e(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100c81a:	mov    (%rax),%rdi
 100c81d:	lea    -0xa80f(%rip),%rsi        # 1002015 <__abi_tag+0x1d19>
 100c824:	lea    -0xa9ae(%rip),%rdx        # 1001e7d <__abi_tag+0x1b81>
 100c82b:	lea    -0x8c0(%rbp),%rcx
 100c832:	xor    %eax,%eax
 100c834:	call   101efb0 <fprintf@plt>
 100c839:	jmp    100c775 <mylang_qbe_run_process+0x845>
 100c83e:	int3
 100c83f:	int3

000000000100c840 <execute_config_args>:
 100c840:	push   %rbp
 100c841:	mov    %rsp,%rbp
 100c844:	push   %r15
 100c846:	push   %r14
 100c848:	push   %r13
 100c84a:	push   %r12
 100c84c:	push   %rbx
 100c84d:	sub    $0x48,%rsp
 100c851:	mov    %r9,%r12
 100c854:	mov    %r8,-0x50(%rbp)
 100c858:	mov    %ecx,-0x30(%rbp)
 100c85b:	mov    %rdx,%r14
 100c85e:	mov    %rsi,%r13
 100c861:	mov    %rdi,%rbx
 100c864:	mov    0x20(%rbp),%r15
 100c868:	mov    $0x268,%edx
 100c86d:	mov    %r15,%rdi
 100c870:	xor    %esi,%esi
 100c872:	call   101e6b0 <compiler_rt.fastMemset>
 100c877:	test   %r13,%r13
 100c87a:	setne  %al
 100c87d:	test   %r14,%r14
 100c880:	setne  %cl
 100c883:	test   %cl,%al
 100c885:	je     100c8ab <execute_config_args+0x6b>
 100c887:	mov    %r12,-0x48(%rbp)
 100c88b:	cmp    $0xffffffffffffffff,%r14
 100c88f:	mov    $0x400,%r12d
 100c895:	cmovne %r14,%r12
 100c899:	mov    %r12,%rax
 100c89c:	shr    $0x3b,%rax
 100c8a0:	je     100c8ca <execute_config_args+0x8a>
 100c8a2:	lea    -0xb1b7(%rip),%rax        # 10016f2 <__abi_tag+0x13f6>
 100c8a9:	jmp    100c8b2 <execute_config_args+0x72>
 100c8ab:	lea    -0xb047(%rip),%rax        # 100186b <__abi_tag+0x156f>
 100c8b2:	mov    %rax,0x10(%r15)
 100c8b6:	mov    $0x1,%eax
 100c8bb:	add    $0x48,%rsp
 100c8bf:	pop    %rbx
 100c8c0:	pop    %r12
 100c8c2:	pop    %r13
 100c8c4:	pop    %r14
 100c8c6:	pop    %r15
 100c8c8:	pop    %rbp
 100c8c9:	ret
 100c8ca:	movl   $0x1,-0x2c(%rbp)
 100c8d1:	lea    -0x2c(%rbp),%rdi
 100c8d5:	call   100ea30 <myl_native_budget_environment>
 100c8da:	cmpl   $0x0,-0x2c(%rbp)
 100c8de:	je     100ca0a <execute_config_args+0x1ca>
 100c8e4:	mov    %rbx,-0x38(%rbp)
 100c8e8:	mov    %rax,-0x40(%rbp)
 100c8ec:	mov    %rax,%rdi
 100c8ef:	call   100eb50 <myl_native_budget_guard>
 100c8f4:	mov    $0x1,%edi
 100c8f9:	mov    $0x3e88,%esi
 100c8fe:	call   101ef80 <calloc@plt>
 100c903:	test   %rax,%rax
 100c906:	je     100c8a2 <execute_config_args+0x62>
 100c908:	mov    %rax,%rbx
 100c90b:	mov    0x18(%rbp),%rax
 100c90f:	mov    0x10(%rbp),%ecx
 100c912:	mov    %r13,0x10(%rbx)
 100c916:	mov    %r12,0x18(%rbx)
 100c91a:	mov    %r14,0x38(%rbx)
 100c91e:	mov    -0x50(%rbp),%rdx
 100c922:	mov    %rdx,0x3978(%rbx)
 100c929:	mov    %ecx,0x39d0(%rbx)
 100c92f:	mov    %rax,0x39d8(%rbx)
 100c936:	lea    0x258(%rbx),%r14
 100c93d:	xor    %esi,%esi
 100c93f:	mov    -0x40(%rbp),%rax
 100c943:	cmp    $0x1,%rax
 100c947:	sbb    %rsi,%rsi
 100c94a:	or     %rax,%rsi
 100c94d:	mov    %r14,%rdi
 100c950:	call   100ed40 <myl_native_heap_init>
 100c955:	mov    -0x30(%rbp),%eax
 100c958:	mov    %eax,0x2c0(%rbx)
 100c95e:	mov    %rbx,%rdi
 100c961:	call   100b110 <myl_qbe_rc_initialize>
 100c966:	cmpq   $0x0,0x20(%rbx)
 100c96b:	jne    100ca21 <execute_config_args+0x1e1>
 100c971:	mov    $0x20,%esi
 100c976:	mov    %r12,%rdi
 100c979:	call   101ef80 <calloc@plt>
 100c97e:	mov    %rax,0x28(%rbx)
 100c982:	test   %rax,%rax
 100c985:	je     100ca16 <execute_config_args+0x1d6>
 100c98b:	call   101efc0 <fegetround@plt>
 100c990:	test   %eax,%eax
 100c992:	jne    100c9f9 <execute_config_args+0x1b9>
 100c994:	movabs $0x10000000000000,%rax
 100c99e:	mov    %rax,-0x70(%rbp)
 100c9a2:	movabs $0x3fe0000000000000,%rax
 100c9ac:	mov    %rax,-0x68(%rbp)
 100c9b0:	movq   $0x1,-0x60(%rbp)
 100c9b8:	movabs $0x3ff0000000000000,%rax
 100c9c2:	mov    %rax,-0x58(%rbp)
 100c9c6:	vmovsd -0x70(%rbp),%xmm0
 100c9cb:	vmulsd -0x68(%rbp),%xmm0,%xmm0
 100c9d0:	vmovq  %xmm0,%rax
 100c9d5:	movabs $0x8000000000000,%rcx
 100c9df:	cmp    %rcx,%rax
 100c9e2:	jne    100c9f9 <execute_config_args+0x1b9>
 100c9e4:	vmovsd -0x60(%rbp),%xmm0
 100c9e9:	vmulsd -0x58(%rbp),%xmm0,%xmm0
 100c9ee:	vmovq  %xmm0,%rax
 100c9f3:	cmp    $0x1,%rax
 100c9f7:	je     100ca21 <execute_config_args+0x1e1>
 100c9f9:	lea    -0xae43(%rip),%rsi        # 1001bbd <__abi_tag+0x18c1>
 100ca00:	mov    %rbx,%rdi
 100ca03:	call   100b580 <fail>
 100ca08:	jmp    100ca21 <execute_config_args+0x1e1>
 100ca0a:	lea    -0xb1bd(%rip),%rax        # 1001854 <__abi_tag+0x1558>
 100ca11:	jmp    100c8b2 <execute_config_args+0x72>
 100ca16:	lea    -0xb32b(%rip),%rax        # 10016f2 <__abi_tag+0x13f6>
 100ca1d:	mov    %rax,0x20(%rbx)
 100ca21:	mov    0x20(%rbx),%rax
 100ca25:	test   %rax,%rax
 100ca28:	setne  %cl
 100ca2b:	mov    -0x48(%rbp),%rsi
 100ca2f:	test   %rsi,%rsi
 100ca32:	sete   %dl
 100ca35:	or     %cl,%dl
 100ca37:	jne    100ca45 <execute_config_args+0x205>
 100ca39:	mov    %rbx,%rdi
 100ca3c:	vzeroupper
 100ca3f:	call   *%rsi
 100ca41:	mov    0x20(%rbx),%rax
 100ca45:	test   %rax,%rax
 100ca48:	jne    100ca7b <execute_config_args+0x23b>
 100ca4a:	mov    -0x38(%rbp),%rdi
 100ca4e:	mov    %rbx,%rsi
 100ca51:	vzeroupper
 100ca54:	call   100d500 <myl_qbe_on_stack>
 100ca59:	mov    %rax,(%r15)
 100ca5c:	mov    0x20(%rbx),%rax
 100ca60:	test   %rax,%rax
 100ca63:	jne    100ca7b <execute_config_args+0x23b>
 100ca65:	cmpq   $0x0,0x8(%rbx)
 100ca6a:	je     100ca79 <execute_config_args+0x239>
 100ca6c:	lea    -0xada6(%rip),%rax        # 1001ccd <__abi_tag+0x19d1>
 100ca73:	mov    %rax,0x20(%rbx)
 100ca77:	jmp    100ca7b <execute_config_args+0x23b>
 100ca79:	xor    %eax,%eax
 100ca7b:	mov    (%rbx),%rcx
 100ca7e:	mov    %rcx,0x8(%r15)
 100ca82:	mov    %rax,0x10(%r15)
 100ca86:	vmovups 0x248(%rbx),%xmm0
 100ca8e:	vmovups %xmm0,0x218(%r15)
 100ca97:	mov    0x39e0(%rbx),%eax
 100ca9d:	mov    %eax,0x228(%r15)
 100caa4:	vmovups 0x39e8(%rbx),%ymm0
 100caac:	vmovups 0x3a00(%rbx),%ymm1
 100cab4:	vmovups %ymm0,0x230(%r15)
 100cabd:	vmovups %ymm1,0x248(%r15)
 100cac6:	add    $0x18,%r15
 100caca:	mov    %rbx,%rsi
 100cacd:	add    $0x48,%rsi
 100cad1:	mov    $0x200,%edx
 100cad6:	mov    %r15,%rdi
 100cad9:	vzeroupper
 100cadc:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 100cae1:	mov    0x3e80(%rbx),%rax
 100cae8:	test   %rax,%rax
 100caeb:	je     100caf2 <execute_config_args+0x2b2>
 100caed:	mov    %rbx,%rdi
 100caf0:	call   *%rax
 100caf2:	mov    0x39a0(%rbx),%rax
 100caf9:	test   %rax,%rax
 100cafc:	je     100cb03 <execute_config_args+0x2c3>
 100cafe:	mov    %rbx,%rdi
 100cb01:	call   *%rax
 100cb03:	mov    0x3e78(%rbx),%rax
 100cb0a:	test   %rax,%rax
 100cb0d:	je     100cb14 <execute_config_args+0x2d4>
 100cb0f:	mov    %rbx,%rdi
 100cb12:	call   *%rax
 100cb14:	cmpq   $0x0,0x20(%rbx)
 100cb19:	jne    100cb41 <execute_config_args+0x301>
 100cb1b:	cmpb   $0x1,0x1dc96(%rip)        # 102a7b8 <exit_without_sweep>
 100cb22:	jne    100cb41 <execute_config_args+0x301>
 100cb24:	cmpl   $0x0,0x2c0(%rbx)
 100cb2b:	jne    100cb41 <execute_config_args+0x301>
 100cb2d:	cmpq   $0x0,0x3990(%rbx)
 100cb35:	jne    100cb41 <execute_config_args+0x301>
 100cb37:	cmpq   $0x0,0x3998(%rbx)
 100cb3f:	je     100cb64 <execute_config_args+0x324>
 100cb41:	mov    %rbx,%rdi
 100cb44:	call   100b2a0 <myl_qbe_rc_finish>
 100cb49:	jmp    100cb64 <execute_config_args+0x324>
 100cb4b:	nopl   0x0(%rax,%rax,1)
 100cb50:	mov    %rcx,0x39c8(%rbx)
 100cb57:	test   %rcx,%rcx
 100cb5a:	je     100cb5f <execute_config_args+0x31f>
 100cb5c:	mov    %rax,(%rcx)
 100cb5f:	call   101efd0 <free@plt>
 100cb64:	mov    0x39c8(%rbx),%rdi
 100cb6b:	test   %rdi,%rdi
 100cb6e:	je     100cb87 <execute_config_args+0x347>
 100cb70:	mov    (%rdi),%rax
 100cb73:	mov    0x8(%rdi),%rcx
 100cb77:	test   %rax,%rax
 100cb7a:	je     100cb50 <execute_config_args+0x310>
 100cb7c:	mov    %rcx,0x8(%rax)
 100cb80:	test   %rcx,%rcx
 100cb83:	jne    100cb5c <execute_config_args+0x31c>
 100cb85:	jmp    100cb5f <execute_config_args+0x31f>
 100cb87:	mov    0x39a8(%rbx),%rdi
 100cb8e:	call   101efd0 <free@plt>
 100cb93:	mov    0x28(%rbx),%rdi
 100cb97:	call   101efd0 <free@plt>
 100cb9c:	cmpb   $0x0,0x1dc15(%rip)        # 102a7b8 <exit_without_sweep>
 100cba3:	jne    100cbad <execute_config_args+0x36d>
 100cba5:	mov    %r14,%rdi
 100cba8:	call   100fe30 <myl_native_heap_destroy>
 100cbad:	xor    %r14d,%r14d
 100cbb0:	cmpq   $0x0,0x20(%rbx)
 100cbb5:	setne  %r14b
 100cbb9:	mov    %rbx,%rdi
 100cbbc:	call   101efd0 <free@plt>
 100cbc1:	mov    %r14d,%eax
 100cbc4:	jmp    100c8bb <execute_config_args+0x7b>
 100cbc9:	int3
 100cbca:	int3
 100cbcb:	int3
 100cbcc:	int3
 100cbcd:	int3
 100cbce:	int3
 100cbcf:	int3

000000000100cbd0 <append>:
 100cbd0:	push   %rbp
 100cbd1:	mov    %rsp,%rbp
 100cbd4:	push   %r14
 100cbd6:	push   %rbx
 100cbd7:	sub    $0xd0,%rsp
 100cbde:	mov    %rdx,%rbx
 100cbe1:	mov    %rsi,%r14
 100cbe4:	mov    %r8,-0xc0(%rbp)
 100cbeb:	mov    %r9,-0xb8(%rbp)
 100cbf2:	test   %al,%al
 100cbf4:	je     100cc27 <append+0x57>
 100cbf6:	vmovaps %xmm0,-0xb0(%rbp)
 100cbfe:	vmovaps %xmm1,-0xa0(%rbp)
 100cc06:	vmovaps %xmm2,-0x90(%rbp)
 100cc0e:	vmovaps %xmm3,-0x80(%rbp)
 100cc13:	vmovaps %xmm4,-0x70(%rbp)
 100cc18:	vmovaps %xmm5,-0x60(%rbp)
 100cc1d:	vmovaps %xmm6,-0x50(%rbp)
 100cc22:	vmovaps %xmm7,-0x40(%rbp)
 100cc27:	lea    -0xe0(%rbp),%rax
 100cc2e:	mov    %rax,-0x20(%rbp)
 100cc32:	lea    0x10(%rbp),%rax
 100cc36:	mov    %rax,-0x28(%rbp)
 100cc3a:	movabs $0x3000000020,%rax
 100cc44:	mov    %rax,-0x30(%rbp)
 100cc48:	mov    (%rdx),%rax
 100cc4b:	add    %rax,%rdi
 100cc4e:	sub    %rax,%rsi
 100cc51:	lea    -0x30(%rbp),%rax
 100cc55:	mov    %rcx,%rdx
 100cc58:	mov    %rax,%rcx
 100cc5b:	call   101f050 <vsnprintf@plt>
 100cc60:	mov    %eax,%ecx
 100cc62:	xor    %eax,%eax
 100cc64:	test   %ecx,%ecx
 100cc66:	js     100cc80 <append+0xb0>
 100cc68:	mov    %ecx,%ecx
 100cc6a:	mov    (%rbx),%rdx
 100cc6d:	sub    %rdx,%r14
 100cc70:	cmp    %rcx,%r14
 100cc73:	jbe    100cc80 <append+0xb0>
 100cc75:	add    %rcx,%rdx
 100cc78:	mov    %rdx,(%rbx)
 100cc7b:	mov    $0x1,%eax
 100cc80:	add    $0xd0,%rsp
 100cc87:	pop    %rbx
 100cc88:	pop    %r14
 100cc8a:	pop    %rbp
 100cc8b:	ret
 100cc8c:	int3
 100cc8d:	int3
 100cc8e:	int3
 100cc8f:	int3

000000000100cc90 <append>:
 100cc90:	push   %rbp
 100cc91:	mov    %rsp,%rbp
 100cc94:	push   %r15
 100cc96:	push   %r14
 100cc98:	push   %r13
 100cc9a:	push   %r12
 100cc9c:	push   %rbx
 100cc9d:	push   %rax
 100cc9e:	mov    %rdx,%r14
 100cca1:	mov    %esi,%r15d
 100cca4:	mov    %rdi,%rbx
 100cca7:	mov    0x3e70(%rdi),%r12
 100ccae:	test   %r12,%r12
 100ccb1:	jne    100cce3 <append+0x53>
 100ccb3:	mov    $0x1,%edi
 100ccb8:	mov    $0x18,%esi
 100ccbd:	call   101ef80 <calloc@plt>
 100ccc2:	test   %rax,%rax
 100ccc5:	je     100cd6a <append+0xda>
 100cccb:	mov    %rax,%r12
 100ccce:	mov    %rax,0x3e70(%rbx)
 100ccd5:	lea    0x1bc4(%rip),%rax        # 100e8a0 <release_all>
 100ccdc:	mov    %rax,0x3e78(%rbx)
 100cce3:	mov    0x8(%r12),%rax
 100cce8:	cmp    $0x1000,%rax
 100ccee:	jne    100cd01 <append+0x71>
 100ccf0:	lea    -0xb4b1(%rip),%rsi        # 1001846 <__abi_tag+0x154a>
 100ccf7:	mov    %rbx,%rdi
 100ccfa:	call   100b570 <myl_qbe_fail>
 100ccff:	jmp    100cd72 <append+0xe2>
 100cd01:	cmp    0x10(%r12),%rax
 100cd06:	jne    100cd38 <append+0xa8>
 100cd08:	lea    (%rax,%rax,1),%rcx
 100cd0c:	test   %rax,%rax
 100cd0f:	mov    $0x8,%r13d
 100cd15:	cmovne %rcx,%r13
 100cd19:	mov    (%r12),%rdi
 100cd1d:	lea    0x0(,%r13,8),%rsi
 100cd25:	call   101f180 <realloc@plt>
 100cd2a:	test   %rax,%rax
 100cd2d:	je     100cd6a <append+0xda>
 100cd2f:	mov    %rax,(%r12)
 100cd33:	mov    %r13,0x10(%r12)
 100cd38:	mov    $0x1,%edi
 100cd3d:	mov    $0x70,%esi
 100cd42:	call   101ef80 <calloc@plt>
 100cd47:	test   %rax,%rax
 100cd4a:	je     100cd6a <append+0xda>
 100cd4c:	mov    %r15d,(%rax)
 100cd4f:	mov    0x8(%r12),%rcx
 100cd54:	mov    %rcx,(%r14)
 100cd57:	mov    (%r12),%rdx
 100cd5b:	lea    0x1(%rcx),%rsi
 100cd5f:	mov    %rsi,0x8(%r12)
 100cd64:	mov    %rax,(%rdx,%rcx,8)
 100cd68:	jmp    100cd74 <append+0xe4>
 100cd6a:	mov    %rbx,%rdi
 100cd6d:	call   100b780 <myl_qbe_fail_allocation>
 100cd72:	xor    %eax,%eax
 100cd74:	add    $0x8,%rsp
 100cd78:	pop    %rbx
 100cd79:	pop    %r12
 100cd7b:	pop    %r13
 100cd7d:	pop    %r14
 100cd7f:	pop    %r15
 100cd81:	pop    %rbp
 100cd82:	ret
 100cd83:	int3
 100cd84:	int3
 100cd85:	int3
 100cd86:	int3
 100cd87:	int3
 100cd88:	int3
 100cd89:	int3
 100cd8a:	int3
 100cd8b:	int3
 100cd8c:	int3
 100cd8d:	int3
 100cd8e:	int3
 100cd8f:	int3

000000000100cd90 <describe>:
 100cd90:	push   %rbp
 100cd91:	mov    %rsp,%rbp
 100cd94:	push   %rbx
 100cd95:	push   %rax
 100cd96:	mov    %rdi,%rbx
 100cd99:	lea    -0xb17c(%rip),%rsi        # 1001c24 <__abi_tag+0x1928>
 100cda0:	call   101eff0 <strcmp@plt>
 100cda5:	test   %eax,%eax
 100cda7:	je     100ce5b <describe+0xcb>
 100cdad:	lea    -0xb1ab(%rip),%rsi        # 1001c09 <__abi_tag+0x190d>
 100cdb4:	mov    %rbx,%rdi
 100cdb7:	call   101eff0 <strcmp@plt>
 100cdbc:	test   %eax,%eax
 100cdbe:	je     100ce64 <describe+0xd4>
 100cdc4:	lea    -0xb0e7(%rip),%rsi        # 1001ce4 <__abi_tag+0x19e8>
 100cdcb:	mov    %rbx,%rdi
 100cdce:	call   101eff0 <strcmp@plt>
 100cdd3:	test   %eax,%eax
 100cdd5:	je     100ce6d <describe+0xdd>
 100cddb:	lea    -0xb0e9(%rip),%rsi        # 1001cf9 <__abi_tag+0x19fd>
 100cde2:	mov    %rbx,%rdi
 100cde5:	call   101eff0 <strcmp@plt>
 100cdea:	test   %eax,%eax
 100cdec:	je     100ce76 <describe+0xe6>
 100cdf2:	lea    -0xb1e3(%rip),%rsi        # 1001c16 <__abi_tag+0x191a>
 100cdf9:	mov    %rbx,%rdi
 100cdfc:	call   101eff0 <strcmp@plt>
 100ce01:	test   %eax,%eax
 100ce03:	je     100ce7f <describe+0xef>
 100ce05:	lea    -0xb1bf(%rip),%rsi        # 1001c4d <__abi_tag+0x1951>
 100ce0c:	mov    %rbx,%rdi
 100ce0f:	call   101eff0 <strcmp@plt>
 100ce14:	test   %eax,%eax
 100ce16:	je     100ce88 <describe+0xf8>
 100ce18:	lea    -0xb1dc(%rip),%rsi        # 1001c43 <__abi_tag+0x1947>
 100ce1f:	mov    %rbx,%rdi
 100ce22:	call   101eff0 <strcmp@plt>
 100ce27:	test   %eax,%eax
 100ce29:	je     100ce91 <describe+0x101>
 100ce2b:	lea    -0xb261(%rip),%rsi        # 1001bd1 <__abi_tag+0x18d5>
 100ce32:	mov    %rbx,%rdi
 100ce35:	call   101eff0 <strcmp@plt>
 100ce3a:	test   %eax,%eax
 100ce3c:	je     100ce9a <describe+0x10a>
 100ce3e:	cmpb   $0x52,(%rbx)
 100ce41:	jne    100cea3 <describe+0x113>
 100ce43:	cmpb   $0x5f,0x1(%rbx)
 100ce47:	lea    -0xb2f1(%rip),%rcx        # 1001b5d <__abi_tag+0x1861>
 100ce4e:	lea    -0xb3df(%rip),%rax        # 1001a76 <__abi_tag+0x177a>
 100ce55:	cmove  %rcx,%rax
 100ce59:	jmp    100ceaa <describe+0x11a>
 100ce5b:	lea    -0xb385(%rip),%rax        # 1001add <__abi_tag+0x17e1>
 100ce62:	jmp    100ceaa <describe+0x11a>
 100ce64:	lea    -0xb1d8(%rip),%rax        # 1001c93 <__abi_tag+0x1997>
 100ce6b:	jmp    100ceaa <describe+0x11a>
 100ce6d:	lea    -0xb492(%rip),%rax        # 10019e2 <__abi_tag+0x16e6>
 100ce74:	jmp    100ceaa <describe+0x11a>
 100ce76:	lea    -0xb46c(%rip),%rax        # 1001a11 <__abi_tag+0x1715>
 100ce7d:	jmp    100ceaa <describe+0x11a>
 100ce7f:	lea    -0xb098(%rip),%rax        # 1001dee <__abi_tag+0x1af2>
 100ce86:	jmp    100ceaa <describe+0x11a>
 100ce88:	lea    -0xb370(%rip),%rax        # 1001b1f <__abi_tag+0x1823>
 100ce8f:	jmp    100ceaa <describe+0x11a>
 100ce91:	lea    -0xb390(%rip),%rax        # 1001b08 <__abi_tag+0x180c>
 100ce98:	jmp    100ceaa <describe+0x11a>
 100ce9a:	lea    -0xb3ac(%rip),%rax        # 1001af5 <__abi_tag+0x17f9>
 100cea1:	jmp    100ceaa <describe+0x11a>
 100cea3:	lea    -0xb434(%rip),%rax        # 1001a76 <__abi_tag+0x177a>
 100ceaa:	add    $0x8,%rsp
 100ceae:	pop    %rbx
 100ceaf:	pop    %rbp
 100ceb0:	ret
 100ceb1:	int3
 100ceb2:	int3
 100ceb3:	int3
 100ceb4:	int3
 100ceb5:	int3
 100ceb6:	int3
 100ceb7:	int3
 100ceb8:	int3
 100ceb9:	int3
 100ceba:	int3
 100cebb:	int3
 100cebc:	int3
 100cebd:	int3
 100cebe:	int3
 100cebf:	int3

000000000100cec0 <trace_frame>:
 100cec0:	test   %rsi,%rsi
 100cec3:	je     100cfa9 <trace_frame+0xe9>
 100cec9:	cmp    0x10(%rsi),%rdx
 100cecd:	jae    100cfa9 <trace_frame+0xe9>
 100ced3:	push   %rbp
 100ced4:	mov    %rsp,%rbp
 100ced7:	push   %r15
 100ced9:	push   %r14
 100cedb:	push   %r12
 100cedd:	push   %rbx
 100cede:	cmp    $0x1f,%ecx
 100cee1:	ja     100cfad <trace_frame+0xed>
 100cee7:	mov    0x20(%rsi),%r15
 100ceeb:	test   %r15,%r15
 100ceee:	je     100cfad <trace_frame+0xed>
 100cef4:	mov    0x28(%rsi),%rax
 100cef8:	test   %rax,%rax
 100cefb:	je     100cfad <trace_frame+0xed>
 100cf01:	add    $0x20,%r15
 100cf05:	jmp    100cf1d <trace_frame+0x5d>
 100cf07:	nopw   0x0(%rax,%rax,1)
 100cf10:	add    $0x28,%r15
 100cf14:	dec    %rax
 100cf17:	je     100cfad <trace_frame+0xed>
 100cf1d:	mov    -0x18(%r15),%r9
 100cf21:	cmp    %r9,%rdx
 100cf24:	jb     100cf10 <trace_frame+0x50>
 100cf26:	cmp    -0x10(%r15),%rdx
 100cf2a:	jae    100cf10 <trace_frame+0x50>
 100cf2c:	mov    -0x20(%r15),%rax
 100cf30:	test   %rax,%rax
 100cf33:	je     100cfad <trace_frame+0xed>
 100cf35:	add    -0x8(%r15),%rdx
 100cf39:	sub    %r9,%rdx
 100cf3c:	inc    %ecx
 100cf3e:	mov    %rdi,%rbx
 100cf41:	mov    %rsi,%r12
 100cf44:	mov    %rax,%rsi
 100cf47:	mov    %r8,%r14
 100cf4a:	call   100cec0 <trace_frame>
 100cf4f:	mov    (%r15),%rdx
 100cf52:	incq   (%r14)
 100cf55:	cmp    0x10(%r12),%rdx
 100cf5a:	jae    100cff7 <trace_frame+0x137>
 100cf60:	mov    0x248(%rbx),%rax
 100cf67:	cmp    $0xf,%rax
 100cf6b:	ja     100cff7 <trace_frame+0x137>
 100cf71:	mov    (%r12),%rsi
 100cf75:	mov    0x8(%r12),%rcx
 100cf7a:	lea    (%rdx,%rdx,2),%rdx
 100cf7e:	mov    (%rcx,%rdx,8),%rdi
 100cf82:	lea    0x1(%rax),%r8
 100cf86:	shl    $0x5,%rax
 100cf8a:	mov    %rsi,0x48(%rbx,%rax,1)
 100cf8f:	mov    %rdi,0x50(%rbx,%rax,1)
 100cf94:	vmovups 0x8(%rcx,%rdx,8),%xmm0
 100cf9a:	mov    %r8,0x248(%rbx)
 100cfa1:	vmovups %xmm0,0x58(%rbx,%rax,1)
 100cfa7:	jmp    100cff7 <trace_frame+0x137>
 100cfa9:	incq   (%r8)
 100cfac:	ret
 100cfad:	incq   (%r8)
 100cfb0:	cmp    0x10(%rsi),%rdx
 100cfb4:	jae    100cff7 <trace_frame+0x137>
 100cfb6:	mov    0x248(%rdi),%rax
 100cfbd:	cmp    $0xf,%rax
 100cfc1:	ja     100cff7 <trace_frame+0x137>
 100cfc3:	mov    (%rsi),%rcx
 100cfc6:	mov    0x8(%rsi),%rsi
 100cfca:	lea    (%rdx,%rdx,2),%rdx
 100cfce:	mov    (%rsi,%rdx,8),%r8
 100cfd2:	lea    0x1(%rax),%r9
 100cfd6:	shl    $0x5,%rax
 100cfda:	mov    %rcx,0x48(%rdi,%rax,1)
 100cfdf:	mov    %r8,0x50(%rdi,%rax,1)
 100cfe4:	vmovups 0x8(%rsi,%rdx,8),%xmm0
 100cfea:	mov    %r9,0x248(%rdi)
 100cff1:	vmovups %xmm0,0x58(%rdi,%rax,1)
 100cff7:	pop    %rbx
 100cff8:	pop    %r12
 100cffa:	pop    %r14
 100cffc:	pop    %r15
 100cffe:	pop    %rbp
 100cfff:	ret

000000000100d000 <walk_frames>:
 100d000:	push   %rbp
 100d001:	mov    %rsp,%rbp
 100d004:	push   %r15
 100d006:	push   %r14
 100d008:	push   %r13
 100d00a:	push   %r12
 100d00c:	push   %rbx
 100d00d:	sub    $0x38,%rsp
 100d011:	mov    %rdx,-0x38(%rbp)
 100d015:	mov    %rsi,-0x30(%rbp)
 100d019:	mov    0x39c0(%rdi),%r12
 100d020:	mov    0x3e68(%rdi),%r13
 100d027:	test   %r12,%r12
 100d02a:	setne  %al
 100d02d:	cmp    %r12,%r13
 100d030:	seta   %cl
 100d033:	and    %al,%cl
 100d035:	cmp    $0x1,%cl
 100d038:	jne    100d122 <walk_frames+0x122>
 100d03e:	lea    -0x916d(%rip),%rax        # 1003ed8 <__stop_mylang_frame_map>
 100d045:	mov    %rax,%rcx
 100d048:	sub    $0x10037a0,%rcx
 100d04f:	cmp    $0x9,%rcx
 100d053:	jb     100d122 <walk_frames+0x122>
 100d059:	cmpq   $0x0,0x1c51f(%rip)        # 1029580 <_DYNAMIC+0x1b8>
 100d061:	je     100d122 <walk_frames+0x122>
 100d067:	cmp    $0x10037a0,%rax
 100d06e:	jbe    100d122 <walk_frames+0x122>
 100d074:	mov    %rdi,%r15
 100d077:	lea    -0x98de(%rip),%rax        # 10037a0 <__start_mylang_frame_map>
 100d07e:	testb  $0x20,0x7(%rax)
 100d082:	jne    100d0dc <walk_frames+0xdc>
 100d084:	mov    %rbp,%rbx
 100d087:	add    $0xfffffffffffffff0,%r13
 100d08b:	nopl   0x0(%rax,%rax,1)
 100d090:	cmp    %r12,%rbx
 100d093:	jb     100d122 <walk_frames+0x122>
 100d099:	cmp    %r13,%rbx
 100d09c:	ja     100d122 <walk_frames+0x122>
 100d0a2:	mov    %ebx,%eax
 100d0a4:	and    $0x7,%eax
 100d0a7:	jne    100d122 <walk_frames+0x122>
 100d0a9:	mov    (%rbx),%r14
 100d0ac:	mov    0x8(%rbx),%rsi
 100d0b0:	mov    %r15,%rdi
 100d0b3:	mov    -0x30(%rbp),%rdx
 100d0b7:	mov    -0x38(%rbp),%rcx
 100d0bb:	call   100d1a0 <visit_return>
 100d0c0:	cmp    %rbx,%r14
 100d0c3:	mov    %rbx,%rcx
 100d0c6:	cmova  %r14,%rcx
 100d0ca:	test   %eax,%eax
 100d0cc:	cmove  %rbx,%rcx
 100d0d0:	je     100d122 <walk_frames+0x122>
 100d0d2:	cmp    %rbx,%r14
 100d0d5:	mov    %rcx,%rbx
 100d0d8:	ja     100d090 <walk_frames+0x90>
 100d0da:	jmp    100d122 <walk_frames+0x122>
 100d0dc:	mov    %r15,-0x58(%rbp)
 100d0e0:	mov    -0x30(%rbp),%rax
 100d0e4:	mov    %rax,-0x50(%rbp)
 100d0e8:	mov    -0x38(%rbp),%rax
 100d0ec:	mov    %rax,-0x48(%rbp)
 100d0f0:	movq   $0x0,-0x40(%rbp)
 100d0f8:	cmpq   $0x0,0x1c488(%rip)        # 1029588 <_Unwind_Backtrace>
 100d100:	sete   %al
 100d103:	cmpq   $0x0,0x1c485(%rip)        # 1029590 <_Unwind_GetIP>
 100d10b:	sete   %cl
 100d10e:	or     %al,%cl
 100d110:	jne    100d122 <walk_frames+0x122>
 100d112:	lea    0x47(%rip),%rdi        # 100d160 <unwind_step>
 100d119:	lea    -0x58(%rbp),%rsi
 100d11d:	call   101f090 <_Unwind_Backtrace@plt>
 100d122:	add    $0x38,%rsp
 100d126:	pop    %rbx
 100d127:	pop    %r12
 100d129:	pop    %r13
 100d12b:	pop    %r14
 100d12d:	pop    %r15
 100d12f:	pop    %rbp
 100d130:	ret
 100d131:	int3
 100d132:	int3
 100d133:	int3
 100d134:	int3
 100d135:	int3
 100d136:	int3
 100d137:	int3
 100d138:	int3
 100d139:	int3
 100d13a:	int3
 100d13b:	int3
 100d13c:	int3
 100d13d:	int3
 100d13e:	int3
 100d13f:	int3

000000000100d140 <trace_visit>:
 100d140:	push   %rbp
 100d141:	mov    %rsp,%rbp
 100d144:	mov    %rcx,%r8
 100d147:	xor    %ecx,%ecx
 100d149:	call   100cec0 <trace_frame>
 100d14e:	mov    $0x1,%eax
 100d153:	pop    %rbp
 100d154:	ret
 100d155:	int3
 100d156:	int3
 100d157:	int3
 100d158:	int3
 100d159:	int3
 100d15a:	int3
 100d15b:	int3
 100d15c:	int3
 100d15d:	int3
 100d15e:	int3
 100d15f:	int3

000000000100d160 <unwind_step>:
 100d160:	push   %rbp
 100d161:	mov    %rsp,%rbp
 100d164:	push   %r14
 100d166:	push   %rbx
 100d167:	mov    %rsi,%rbx
 100d16a:	mov    (%rsi),%r14
 100d16d:	call   101f0a0 <_Unwind_GetIP@plt>
 100d172:	mov    0x8(%rbx),%rdx
 100d176:	mov    0x10(%rbx),%rcx
 100d17a:	mov    %r14,%rdi
 100d17d:	mov    %rax,%rsi
 100d180:	call   100d1a0 <visit_return>
 100d185:	mov    %eax,%ecx
 100d187:	xor    %eax,%eax
 100d189:	test   %ecx,%ecx
 100d18b:	jne    100d199 <unwind_step+0x39>
 100d18d:	movl   $0x1,0x18(%rbx)
 100d194:	mov    $0x5,%eax
 100d199:	pop    %rbx
 100d19a:	pop    %r14
 100d19c:	pop    %rbp
 100d19d:	ret
 100d19e:	int3
 100d19f:	int3

000000000100d1a0 <visit_return>:
 100d1a0:	push   %rbp
 100d1a1:	mov    %rsp,%rbp
 100d1a4:	push   %r15
 100d1a6:	push   %r14
 100d1a8:	push   %r13
 100d1aa:	push   %r12
 100d1ac:	push   %rbx
 100d1ad:	sub    $0x18,%rsp
 100d1b1:	mov    %rcx,-0x38(%rbp)
 100d1b5:	mov    %rdx,%r14
 100d1b8:	mov    %rdi,%r15
 100d1bb:	cmpb   $0x0,0x1d60e(%rip)        # 102a7d0 <frame_sites_ready>
 100d1c2:	jne    100d27f <visit_return+0xdf>
 100d1c8:	movb   $0x1,0x1d601(%rip)        # 102a7d0 <frame_sites_ready>
 100d1cf:	lea    -0x9a36(%rip),%r13        # 10037a0 <__start_mylang_frame_map>
 100d1d6:	test   %r13,%r13
 100d1d9:	sete   %al
 100d1dc:	lea    -0x930b(%rip),%r12        # 1003ed8 <__stop_mylang_frame_map>
 100d1e3:	cmp    %r13,%r12
 100d1e6:	setbe  %cl
 100d1e9:	or     %al,%cl
 100d1eb:	jne    100d27f <visit_return+0xdf>
 100d1f1:	sub    $0x10037a0,%r12
 100d1f8:	sar    $0x2,%r12
 100d1fc:	movabs $0xaaaaaaaaaaaaaaab,%rax
 100d206:	mov    %r12,%rdx
 100d209:	mulx   %rax,%rbx,%rbx
 100d20e:	shr    $1,%rbx
 100d211:	movabs $0xf555555555555555,%rax
 100d21b:	lea    (%rbx,%rax,1),%rcx
 100d21f:	inc    %rax
 100d222:	cmp    %rax,%rcx
 100d225:	jb     100d27f <visit_return+0xdf>
 100d227:	lea    0x0(,%rbx,8),%rax
 100d22f:	lea    (%rax,%rax,2),%rdi
 100d233:	mov    %rsi,-0x30(%rbp)
 100d237:	call   101f070 <malloc@plt>
 100d23c:	mov    -0x30(%rbp),%rsi
 100d240:	mov    %rax,0x1d579(%rip)        # 102a7c0 <frame_sites>
 100d247:	test   %rax,%rax
 100d24a:	je     100d35b <visit_return+0x1bb>
 100d250:	cmp    $0x3,%r12
 100d254:	jae    100d427 <visit_return+0x287>
 100d25a:	xor    %r12d,%r12d
 100d25d:	lea    0x25c(%rip),%rcx        # 100d4c0 <site_order>
 100d264:	mov    $0x18,%edx
 100d269:	mov    %rax,%rdi
 100d26c:	mov    %r12,%rsi
 100d26f:	call   101f0b0 <qsort@plt>
 100d274:	mov    %r12,0x1d54d(%rip)        # 102a7c8 <frame_site_count>
 100d27b:	mov    -0x30(%rbp),%rsi
 100d27f:	mov    0x1d53a(%rip),%rcx        # 102a7c0 <frame_sites>
 100d286:	test   %rcx,%rcx
 100d289:	je     100d35b <visit_return+0x1bb>
 100d28f:	mov    0x1d532(%rip),%rdx        # 102a7c8 <frame_site_count>
 100d296:	xor    %edi,%edi
 100d298:	test   %rdx,%rdx
 100d29b:	je     100d2da <visit_return+0x13a>
 100d29d:	mov    %rdx,%rax
 100d2a0:	jmp    100d2b8 <visit_return+0x118>
 100d2a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100d2b0:	mov    %r9,%rax
 100d2b3:	cmp    %rax,%rdi
 100d2b6:	jae    100d2da <visit_return+0x13a>
 100d2b8:	mov    %rax,%r8
 100d2bb:	sub    %rdi,%r8
 100d2be:	shr    $1,%r8
 100d2c1:	lea    (%r8,%rdi,1),%r9
 100d2c5:	lea    (%r9,%r9,2),%r10
 100d2c9:	cmp    %rsi,(%rcx,%r10,8)
 100d2cd:	jae    100d2b0 <visit_return+0x110>
 100d2cf:	add    %r8,%rdi
 100d2d2:	inc    %rdi
 100d2d5:	cmp    %rax,%rdi
 100d2d8:	jb     100d2b8 <visit_return+0x118>
 100d2da:	mov    $0x1,%eax
 100d2df:	cmp    %rdx,%rdi
 100d2e2:	jae    100d418 <visit_return+0x278>
 100d2e8:	lea    (%rdi,%rdi,2),%rdx
 100d2ec:	cmp    %rsi,(%rcx,%rdx,8)
 100d2f0:	jne    100d418 <visit_return+0x278>
 100d2f6:	lea    (%rcx,%rdx,8),%rcx
 100d2fa:	mov    0x10(%rcx),%r12
 100d2fe:	test   %r12,%r12
 100d301:	je     100d418 <visit_return+0x278>
 100d307:	mov    0x8(%rcx),%r13
 100d30b:	add    $0x8,%r13
 100d30f:	mov    %r13,%rbx
 100d312:	jmp    100d331 <visit_return+0x191>
 100d314:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100d320:	add    $0xc,%r13
 100d324:	add    $0xc,%rbx
 100d328:	dec    %r12
 100d32b:	je     100d413 <visit_return+0x273>
 100d331:	mov    -0x4(%r13),%edx
 100d335:	test   %edx,%edx
 100d337:	js     100d320 <visit_return+0x180>
 100d339:	movslq 0x0(%r13),%rsi
 100d33d:	add    %rbx,%rsi
 100d340:	and    $0x1fffffff,%edx
 100d346:	mov    %r15,%rdi
 100d349:	mov    -0x38(%rbp),%rcx
 100d34d:	call   *%r14
 100d350:	test   %eax,%eax
 100d352:	jne    100d320 <visit_return+0x180>
 100d354:	xor    %eax,%eax
 100d356:	jmp    100d418 <visit_return+0x278>
 100d35b:	lea    -0x9bc2(%rip),%rcx        # 10037a0 <__start_mylang_frame_map>
 100d362:	test   %rcx,%rcx
 100d365:	sete   %al
 100d368:	lea    -0x9497(%rip),%rdx        # 1003ed8 <__stop_mylang_frame_map>
 100d36f:	cmp    %rcx,%rdx
 100d372:	setbe  %dil
 100d376:	or     %al,%dil
 100d379:	mov    $0x1,%eax
 100d37e:	jne    100d418 <visit_return+0x278>
 100d384:	sub    $0x10037a0,%rdx
 100d38b:	sar    $0x2,%rdx
 100d38f:	movabs $0xaaaaaaaaaaaaaaab,%rdi
 100d399:	mulx   %rdi,%rdi,%rdi
 100d39e:	cmp    $0x3,%rdx
 100d3a2:	jb     100d418 <visit_return+0x278>
 100d3a4:	shr    $1,%rdi
 100d3a7:	lea    -0x1(%rdi),%rdx
 100d3ab:	xor    %r8d,%r8d
 100d3ae:	xchg   %ax,%ax
 100d3b0:	lea    0x0(,%r8,4),%r9
 100d3b8:	lea    (%r9,%r9,2),%r13
 100d3bc:	mov    $0x1,%r12d
 100d3c2:	cmp    %rdx,%r8
 100d3c5:	jae    100d3f6 <visit_return+0x256>
 100d3c7:	mov    %rdi,%r9
 100d3ca:	sub    %r8,%r9
 100d3cd:	lea    (%rcx,%r13,1),%r10
 100d3d1:	add    $0x10,%r10
 100d3d5:	data16 cs nopw 0x0(%rax,%rax,1)
 100d3e0:	testb  $0x40,0x3(%r10)
 100d3e5:	je     100d3f6 <visit_return+0x256>
 100d3e7:	inc    %r12
 100d3ea:	add    $0xc,%r10
 100d3ee:	cmp    %r12,%r9
 100d3f1:	jne    100d3e0 <visit_return+0x240>
 100d3f3:	mov    %r9,%r12
 100d3f6:	add    %rcx,%r13
 100d3f9:	movslq 0x0(%r13),%r9
 100d3fd:	add    %r13,%r9
 100d400:	cmp    %rsi,%r9
 100d403:	je     100d30b <visit_return+0x16b>
 100d409:	add    %r12,%r8
 100d40c:	cmp    %rdi,%r8
 100d40f:	jb     100d3b0 <visit_return+0x210>
 100d411:	jmp    100d418 <visit_return+0x278>
 100d413:	mov    $0x1,%eax
 100d418:	add    $0x18,%rsp
 100d41c:	pop    %rbx
 100d41d:	pop    %r12
 100d41f:	pop    %r13
 100d421:	pop    %r14
 100d423:	pop    %r15
 100d425:	pop    %rbp
 100d426:	ret
 100d427:	lea    -0x1(%rbx),%rcx
 100d42b:	xor    %r12d,%r12d
 100d42e:	xor    %edx,%edx
 100d430:	jmp    100d46e <visit_return+0x2ce>
 100d432:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100d440:	mov    %r8,%rdi
 100d443:	lea    (%r12,%r12,2),%r8
 100d447:	lea    (%rax,%r8,8),%r8
 100d44b:	add    %r13,%rsi
 100d44e:	movslq (%rsi),%r9
 100d451:	add    %rsi,%r9
 100d454:	mov    %r9,(%r8)
 100d457:	mov    %rsi,0x8(%r8)
 100d45b:	mov    %rdi,0x10(%r8)
 100d45f:	add    %rdi,%rdx
 100d462:	inc    %r12
 100d465:	cmp    %rbx,%rdx
 100d468:	jae    100d25d <visit_return+0xbd>
 100d46e:	lea    0x0(,%rdx,4),%rsi
 100d476:	lea    (%rsi,%rsi,2),%rsi
 100d47a:	mov    $0x1,%edi
 100d47f:	cmp    %rcx,%rdx
 100d482:	jae    100d443 <visit_return+0x2a3>
 100d484:	mov    %rbx,%r8
 100d487:	sub    %rdx,%r8
 100d48a:	lea    (%rsi,%r13,1),%r9
 100d48e:	add    $0x10,%r9
 100d492:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100d4a0:	testb  $0x40,0x3(%r9)
 100d4a5:	je     100d443 <visit_return+0x2a3>
 100d4a7:	inc    %rdi
 100d4aa:	add    $0xc,%r9
 100d4ae:	cmp    %rdi,%r8
 100d4b1:	jne    100d4a0 <visit_return+0x300>
 100d4b3:	jmp    100d440 <visit_return+0x2a0>
 100d4b5:	int3
 100d4b6:	int3
 100d4b7:	int3
 100d4b8:	int3
 100d4b9:	int3
 100d4ba:	int3
 100d4bb:	int3
 100d4bc:	int3
 100d4bd:	int3
 100d4be:	int3
 100d4bf:	int3

000000000100d4c0 <site_order>:
 100d4c0:	mov    (%rdi),%rax
 100d4c3:	cmp    (%rsi),%rax
 100d4c6:	seta   %al
 100d4c9:	sbb    $0x0,%al
 100d4cb:	movsbl %al,%eax
 100d4ce:	ret
 100d4cf:	int3

000000000100d4d0 <on_timeout>:
 100d4d0:	push   %rbp
 100d4d1:	mov    %rsp,%rbp
 100d4d4:	lea    -0xa62b(%rip),%rsi        # 1002eb0 <on_timeout.message>
 100d4db:	mov    $0x48,%edx
 100d4e0:	mov    $0x2,%edi
 100d4e5:	call   101f0c0 <write@plt>
 100d4ea:	mov    $0x1,%edi
 100d4ef:	call   101f0d0 <_exit@plt>
 100d4f4:	int3
 100d4f5:	int3
 100d4f6:	int3
 100d4f7:	int3
 100d4f8:	int3
 100d4f9:	int3
 100d4fa:	int3
 100d4fb:	int3
 100d4fc:	int3
 100d4fd:	int3
 100d4fe:	int3
 100d4ff:	int3

000000000100d500 <myl_qbe_on_stack>:
 100d500:	push   %rbp
 100d501:	mov    %rsp,%rbp
 100d504:	push   %r15
 100d506:	push   %r14
 100d508:	push   %r13
 100d50a:	push   %r12
 100d50c:	push   %rbx
 100d50d:	sub    $0x878,%rsp
 100d514:	mov    %rsi,%rbx
 100d517:	mov    %rdi,%r12
 100d51a:	mov    $0x1e,%edi
 100d51f:	call   101f0e0 <sysconf@plt>
 100d524:	test   %rax,%rax
 100d527:	jle    100d5bf <myl_qbe_on_stack+0xbf>
 100d52d:	mov    %rax,%rcx
 100d530:	shr    $0x3e,%rcx
 100d534:	jne    100d551 <myl_qbe_on_stack+0x51>
 100d536:	lea    (%rax,%rax,1),%r14
 100d53a:	mov    0x18(%rbx),%rcx
 100d53e:	mov    $0xffffffffff7ffffe,%rdx
 100d545:	sub    %r14,%rdx
 100d548:	shr    $0xf,%rdx
 100d54c:	cmp    %rdx,%rcx
 100d54f:	jbe    100d562 <myl_qbe_on_stack+0x62>
 100d551:	mov    $0xffffffffffffffff,%rsi
 100d558:	mov    %rbx,%rdi
 100d55b:	call   100d770 <stack_refused>
 100d560:	jmp    100d5ce <myl_qbe_on_stack+0xce>
 100d562:	shl    $0xf,%rcx
 100d566:	mov    %rcx,%rdx
 100d569:	add    $0x800000,%rdx
 100d570:	mov    %rax,%rcx
 100d573:	neg    %rcx
 100d576:	cmp    %rcx,%rdx
 100d579:	ja     100d5bf <myl_qbe_on_stack+0xbf>
 100d57b:	mov    %r14,%rcx
 100d57e:	not    %rcx
 100d581:	lea    (%rdx,%rax,1),%r13
 100d585:	dec    %r13
 100d588:	mov    %r13,%rdx
 100d58b:	or     %rax,%rdx
 100d58e:	shr    $0x20,%rdx
 100d592:	je     100d5a9 <myl_qbe_on_stack+0xa9>
 100d594:	mov    %rax,%rsi
 100d597:	mov    %rax,%r15
 100d59a:	xor    %eax,%eax
 100d59c:	mov    %eax,%edx
 100d59e:	mov    %r13,%rax
 100d5a1:	div    %rsi
 100d5a4:	mov    %rdx,%rax
 100d5a7:	jmp    100d5b7 <myl_qbe_on_stack+0xb7>
 100d5a9:	mov    %rax,%r15
 100d5ac:	mov    %eax,%esi
 100d5ae:	mov    %r13d,%eax
 100d5b1:	xor    %edx,%edx
 100d5b3:	div    %esi
 100d5b5:	mov    %edx,%eax
 100d5b7:	sub    %rax,%r13
 100d5ba:	cmp    %rcx,%r13
 100d5bd:	jbe    100d5e2 <myl_qbe_on_stack+0xe2>
 100d5bf:	lea    -0xbed4(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100d5c6:	mov    %rbx,%rdi
 100d5c9:	call   100b570 <myl_qbe_fail>
 100d5ce:	xor    %eax,%eax
 100d5d0:	add    $0x878,%rsp
 100d5d7:	pop    %rbx
 100d5d8:	pop    %r12
 100d5da:	pop    %r13
 100d5dc:	pop    %r14
 100d5de:	pop    %r15
 100d5e0:	pop    %rbp
 100d5e1:	ret
 100d5e2:	add    %r13,%r14
 100d5e5:	xor    %eax,%eax
 100d5e7:	mov    %eax,%edi
 100d5e9:	mov    %r14,%rsi
 100d5ec:	xor    %edx,%edx
 100d5ee:	mov    $0x20022,%ecx
 100d5f3:	mov    $0xffffffff,%r8d
 100d5f9:	mov    %rdi,%r9
 100d5fc:	call   101f0f0 <mmap@plt>
 100d601:	cmp    $0xffffffffffffffff,%rax
 100d605:	je     100d758 <myl_qbe_on_stack+0x258>
 100d60b:	mov    %rax,-0x30(%rbp)
 100d60f:	add    %rax,%r15
 100d612:	vxorps %xmm0,%xmm0,%xmm0
 100d616:	vmovups %ymm0,-0x50(%rbp)
 100d61b:	vmovups %ymm0,-0x60(%rbp)
 100d620:	vmovups %ymm0,-0x80(%rbp)
 100d625:	vmovups %ymm0,-0xa0(%rbp)
 100d62d:	vmovups %ymm0,-0xc0(%rbp)
 100d635:	vmovups %ymm0,-0xe0(%rbp)
 100d63d:	vmovups %ymm0,-0x100(%rbp)
 100d645:	mov    %r12,-0x110(%rbp)
 100d64c:	mov    %rbx,-0x108(%rbp)
 100d653:	mov    %r15,%rdi
 100d656:	mov    %r13,%rsi
 100d659:	mov    $0x3,%edx
 100d65e:	vzeroupper
 100d661:	call   101f100 <mprotect@plt>
 100d666:	test   %eax,%eax
 100d668:	jne    100d712 <myl_qbe_on_stack+0x212>
 100d66e:	lea    -0x4d8(%rbp),%rdi
 100d675:	call   101f110 <getcontext@plt>
 100d67a:	test   %eax,%eax
 100d67c:	jne    100d712 <myl_qbe_on_stack+0x212>
 100d682:	lea    -0x800000(%r13),%rax
 100d689:	mov    %rax,0x39b8(%rbx)
 100d690:	mov    %r15,0x39c0(%rbx)
 100d697:	lea    (%r15,%r13,1),%rax
 100d69b:	mov    %rax,0x3e68(%rbx)
 100d6a2:	lea    0x10000(%r15),%rax
 100d6a9:	mov    %rax,0x40(%rbx)
 100d6ad:	mov    %r15,-0x4c8(%rbp)
 100d6b4:	mov    %r13,-0x4b8(%rbp)
 100d6bb:	movl   $0x0,-0x4c0(%rbp)
 100d6c5:	lea    -0x8a0(%rbp),%r15
 100d6cc:	mov    %r15,-0x4d0(%rbp)
 100d6d3:	lea    -0x110(%rbp),%rax
 100d6da:	mov    %rax,%rdx
 100d6dd:	mov    %eax,%ecx
 100d6df:	shr    $0x20,%rdx
 100d6e3:	mov    %edx,%r8d
 100d6e6:	lea    0x1f3(%rip),%rsi        # 100d8e0 <launch>
 100d6ed:	xor    %eax,%eax
 100d6ef:	lea    -0x4d8(%rbp),%r12
 100d6f6:	mov    %r12,%rdi
 100d6f9:	mov    $0x2,%edx
 100d6fe:	call   101f120 <makecontext@plt>
 100d703:	mov    %r15,%rdi
 100d706:	mov    %r12,%rsi
 100d709:	call   101f130 <swapcontext@plt>
 100d70e:	test   %eax,%eax
 100d710:	je     100d763 <myl_qbe_on_stack+0x263>
 100d712:	lea    -0xc027(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100d719:	mov    %rbx,%rdi
 100d71c:	call   100b570 <myl_qbe_fail>
 100d721:	xor    %eax,%eax
 100d723:	mov    %rax,%r15
 100d726:	movq   $0x0,0x39c0(%rbx)
 100d731:	movq   $0x0,0x3e68(%rbx)
 100d73c:	movq   $0x0,0x40(%rbx)
 100d744:	mov    -0x30(%rbp),%rdi
 100d748:	mov    %r14,%rsi
 100d74b:	call   101f140 <munmap@plt>
 100d750:	mov    %r15,%rax
 100d753:	jmp    100d5d0 <myl_qbe_on_stack+0xd0>
 100d758:	mov    %rbx,%rdi
 100d75b:	mov    %r14,%rsi
 100d75e:	jmp    100d55b <myl_qbe_on_stack+0x5b>
 100d763:	mov    -0x100(%rbp),%rax
 100d76a:	jmp    100d723 <myl_qbe_on_stack+0x223>
 100d76c:	int3
 100d76d:	int3
 100d76e:	int3
 100d76f:	int3

000000000100d770 <stack_refused>:
 100d770:	push   %rbp
 100d771:	mov    %rsp,%rbp
 100d774:	push   %r14
 100d776:	push   %rbx
 100d777:	sub    $0x80,%rsp
 100d77e:	cmpq   $0xffffffffffffffff,0x38(%rdi)
 100d783:	je     100d7a0 <stack_refused+0x30>
 100d785:	mov    %rsi,%rbx
 100d788:	lea    -0x20(%rbp),%rsi
 100d78c:	mov    %rdi,%r14
 100d78f:	mov    $0x9,%edi
 100d794:	call   101f150 <getrlimit@plt>
 100d799:	mov    %r14,%rdi
 100d79c:	test   %eax,%eax
 100d79e:	je     100d7b8 <stack_refused+0x48>
 100d7a0:	lea    -0xc0b5(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100d7a7:	call   100b570 <myl_qbe_fail>
 100d7ac:	add    $0x80,%rsp
 100d7b3:	pop    %rbx
 100d7b4:	pop    %r14
 100d7b6:	pop    %rbp
 100d7b7:	ret
 100d7b8:	cmp    $0xffffffffffffffff,%rbx
 100d7bc:	jne    100d7db <stack_refused+0x6b>
 100d7be:	vmovupd -0xbc91(%rip),%ymm0        # 1001b35 <__abi_tag+0x1839>
 100d7c6:	vmovupd %ymm0,-0x50(%rbp)
 100d7cb:	movabs $0x64657373657264,%rax
 100d7d5:	mov    %rax,-0x30(%rbp)
 100d7d9:	jmp    100d818 <stack_refused+0xa8>
 100d7db:	vmovq  %rbx,%xmm0
 100d7e0:	vpunpckldq -0xa9a8(%rip),%xmm0,%xmm0        # 1002e40 <qbe_empty_registry+0x98>
 100d7e8:	vsubpd -0xa9c0(%rip),%xmm0,%xmm0        # 1002e30 <qbe_empty_registry+0x88>
 100d7f0:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 100d7f5:	vaddsd %xmm0,%xmm1,%xmm0
 100d7f9:	vmulsd -0xa9d9(%rip),%xmm0,%xmm0        # 1002e28 <qbe_empty_registry+0x80>
 100d801:	lea    -0xbed2(%rip),%rdx        # 1001936 <__abi_tag+0x163a>
 100d808:	lea    -0x50(%rbp),%rdi
 100d80c:	mov    $0x30,%esi
 100d811:	mov    $0x1,%al
 100d813:	call   101f060 <snprintf@plt>
 100d818:	mov    -0x20(%rbp),%rax
 100d81c:	cmp    $0xffffffffffffffff,%rax
 100d820:	jne    100d844 <stack_refused+0xd4>
 100d822:	vmovups -0xbde3(%rip),%xmm0        # 1001a47 <__abi_tag+0x174b>
 100d82a:	vmovups %xmm0,-0x81(%rbp)
 100d832:	vmovupd -0xbe02(%rip),%xmm0        # 1001a38 <__abi_tag+0x173c>
 100d83a:	vmovapd %xmm0,-0x90(%rbp)
 100d842:	jmp    100d887 <stack_refused+0x117>
 100d844:	vmovq  %rax,%xmm0
 100d849:	vpunpckldq -0xaa11(%rip),%xmm0,%xmm0        # 1002e40 <qbe_empty_registry+0x98>
 100d851:	vsubpd -0xaa29(%rip),%xmm0,%xmm0        # 1002e30 <qbe_empty_registry+0x88>
 100d859:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
 100d85e:	vaddsd %xmm0,%xmm1,%xmm0
 100d862:	vmulsd -0xaa42(%rip),%xmm0,%xmm0        # 1002e28 <qbe_empty_registry+0x80>
 100d86a:	lea    -0xbb39(%rip),%rdx        # 1001d38 <__abi_tag+0x1a3c>
 100d871:	lea    -0x90(%rbp),%rdi
 100d878:	mov    $0x40,%esi
 100d87d:	mov    $0x1,%al
 100d87f:	vzeroupper
 100d882:	call   101f060 <snprintf@plt>
 100d887:	mov    0x1bcea(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100d88e:	mov    (%rax),%rdi
 100d891:	mov    0x18(%r14),%rdx
 100d895:	lea    -0xb9c2(%rip),%rsi        # 1001eda <__abi_tag+0x1bde>
 100d89c:	lea    -0x50(%rbp),%rcx
 100d8a0:	lea    -0x90(%rbp),%r9
 100d8a7:	mov    $0x20,%r8d
 100d8ad:	xor    %eax,%eax
 100d8af:	vzeroupper
 100d8b2:	call   101efb0 <fprintf@plt>
 100d8b7:	movl   $0x1,0x39e0(%r14)
 100d8c2:	lea    -0xc1d7(%rip),%rsi        # 10016f2 <__abi_tag+0x13f6>
 100d8c9:	mov    %r14,%rdi
 100d8cc:	jmp    100d7a7 <stack_refused+0x37>
 100d8d1:	int3
 100d8d2:	int3
 100d8d3:	int3
 100d8d4:	int3
 100d8d5:	int3
 100d8d6:	int3
 100d8d7:	int3
 100d8d8:	int3
 100d8d9:	int3
 100d8da:	int3
 100d8db:	int3
 100d8dc:	int3
 100d8dd:	int3
 100d8de:	int3
 100d8df:	int3

000000000100d8e0 <launch>:
 100d8e0:	push   %rbp
 100d8e1:	mov    %rsp,%rbp
 100d8e4:	sub    $0x10,%rsp
 100d8e8:	mov    %edi,%edi
 100d8ea:	mov    %edi,%eax
 100d8ec:	mov    %esi,%ecx
 100d8ee:	shl    $0x20,%rcx
 100d8f2:	or     %rax,%rcx
 100d8f5:	mov    %rcx,-0x8(%rbp)
 100d8f9:	mov    -0x8(%rbp),%rdi
 100d8fd:	add    $0x18,%rdi
 100d901:	call   101f160 <_setjmp@plt>
 100d906:	mov    -0x8(%rbp),%rcx
 100d90a:	test   %eax,%eax
 100d90c:	je     100d912 <launch+0x32>
 100d90e:	xor    %eax,%eax
 100d910:	jmp    100d937 <launch+0x57>
 100d912:	add    $0x18,%rcx
 100d916:	mov    -0x8(%rbp),%rax
 100d91a:	mov    0x8(%rax),%rax
 100d91e:	mov    %rcx,0x3e60(%rax)
 100d925:	mov    -0x8(%rbp),%rax
 100d929:	mov    -0x8(%rbp),%rcx
 100d92d:	mov    0x8(%rcx),%rdi
 100d931:	call   *(%rax)
 100d933:	mov    -0x8(%rbp),%rcx
 100d937:	mov    %rax,0x10(%rcx)
 100d93b:	mov    -0x8(%rbp),%rax
 100d93f:	mov    0x8(%rax),%rax
 100d943:	movq   $0x0,0x3e60(%rax)
 100d94e:	add    $0x10,%rsp
 100d952:	pop    %rbp
 100d953:	ret
 100d954:	int3
 100d955:	int3
 100d956:	int3
 100d957:	int3
 100d958:	int3
 100d959:	int3
 100d95a:	int3
 100d95b:	int3
 100d95c:	int3
 100d95d:	int3
 100d95e:	int3
 100d95f:	int3

000000000100d960 <myl_qbe_region_mark>:
 100d960:	push   %rbp
 100d961:	mov    %rsp,%rbp
 100d964:	call   100ba30 <myl_qbe_heap>
 100d969:	mov    0x70(%rax),%eax
 100d96c:	pop    %rbp
 100d96d:	ret
 100d96e:	int3
 100d96f:	int3

000000000100d970 <myl_qbe_print_byte>:
 100d970:	push   %rbp
 100d971:	mov    %rsp,%rbp
 100d974:	sub    $0x10,%rsp
 100d978:	mov    %sil,-0x1(%rbp)
 100d97c:	lea    -0x1(%rbp),%rsi
 100d980:	mov    $0x1,%edx
 100d985:	call   10171f0 <myl_print_raw>
 100d98a:	add    $0x10,%rsp
 100d98e:	pop    %rbp
 100d98f:	ret

000000000100d990 <print_finish>:
 100d990:	test   %rsi,%rsi
 100d993:	je     100d9b6 <print_finish+0x26>
 100d995:	push   %rbp
 100d996:	mov    %rsp,%rbp
 100d999:	push   %r15
 100d99b:	push   %r14
 100d99d:	push   %rbx
 100d99e:	push   %rax
 100d99f:	mov    %rsi,%rbx
 100d9a2:	cmpl   $0x0,0x1c(%rsi)
 100d9a6:	je     100d9b7 <print_finish+0x27>
 100d9a8:	lea    -0xc10f(%rip),%rsi        # 10018a0 <__abi_tag+0x15a4>
 100d9af:	call   100b570 <myl_qbe_fail>
 100d9b4:	jmp    100d9c2 <print_finish+0x32>
 100d9b6:	ret
 100d9b7:	cmpl   $0x0,0x18(%rbx)
 100d9bb:	je     100d9dc <print_finish+0x4c>
 100d9bd:	call   100b780 <myl_qbe_fail_allocation>
 100d9c2:	mov    (%rbx),%rdi
 100d9c5:	call   101efd0 <free@plt>
 100d9ca:	mov    %rbx,%rdi
 100d9cd:	add    $0x8,%rsp
 100d9d1:	pop    %rbx
 100d9d2:	pop    %r14
 100d9d4:	pop    %r15
 100d9d6:	pop    %rbp
 100d9d7:	jmp    101efd0 <free@plt>
 100d9dc:	mov    %rdi,%r14
 100d9df:	mov    0x8(%rbx),%rax
 100d9e3:	test   %rax,%rax
 100d9e6:	je     100da07 <print_finish+0x77>
 100d9e8:	mov    (%rbx),%rdi
 100d9eb:	mov    $0x1,%esi
 100d9f0:	mov    %rdx,%r15
 100d9f3:	mov    %rax,%rdx
 100d9f6:	mov    %r15,%rcx
 100d9f9:	call   101efa0 <fwrite@plt>
 100d9fe:	mov    %r15,%rdx
 100da01:	cmp    0x8(%rbx),%rax
 100da05:	jne    100da13 <print_finish+0x83>
 100da07:	mov    %rdx,%rdi
 100da0a:	call   101f080 <fflush@plt>
 100da0f:	test   %eax,%eax
 100da11:	je     100d9c2 <print_finish+0x32>
 100da13:	lea    -0xbe83(%rip),%rsi        # 1001b97 <__abi_tag+0x189b>
 100da1a:	mov    %r14,%rdi
 100da1d:	jmp    100d9af <print_finish+0x1f>
 100da1f:	int3

000000000100da20 <myl_qbe_stream_begin>:
 100da20:	push   %rbp
 100da21:	mov    %rsp,%rbp
 100da24:	push   %rbx
 100da25:	push   %rax
 100da26:	mov    %rdi,%rbx
 100da29:	mov    $0x1,%edi
 100da2e:	mov    $0x20,%esi
 100da33:	call   101ef80 <calloc@plt>
 100da38:	test   %rax,%rax
 100da3b:	jne    100da4b <myl_qbe_stream_begin+0x2b>
 100da3d:	mov    %rbx,%rdi
 100da40:	mov    %rax,%rbx
 100da43:	call   100b780 <myl_qbe_fail_allocation>
 100da48:	mov    %rbx,%rax
 100da4b:	add    $0x8,%rsp
 100da4f:	pop    %rbx
 100da50:	pop    %rbp
 100da51:	ret
 100da52:	int3
 100da53:	int3
 100da54:	int3
 100da55:	int3
 100da56:	int3
 100da57:	int3
 100da58:	int3
 100da59:	int3
 100da5a:	int3
 100da5b:	int3
 100da5c:	int3
 100da5d:	int3
 100da5e:	int3
 100da5f:	int3

000000000100da60 <myl_qbe_stream_finish>:
 100da60:	cmp    $0x2,%rdx
 100da64:	jne    100da75 <myl_qbe_stream_finish+0x15>
 100da66:	mov    0x1bb0b(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100da6d:	mov    (%rax),%rdx
 100da70:	jmp    100d990 <print_finish>
 100da75:	mov    0x1bb1c(%rip),%rax        # 1029598 <stdout@GLIBC_2.2.5>
 100da7c:	mov    (%rax),%rdx
 100da7f:	jmp    100d990 <print_finish>
 100da84:	int3
 100da85:	int3
 100da86:	int3
 100da87:	int3
 100da88:	int3
 100da89:	int3
 100da8a:	int3
 100da8b:	int3
 100da8c:	int3
 100da8d:	int3
 100da8e:	int3
 100da8f:	int3

000000000100da90 <mylang_qbe_run_grants>:
 100da90:	push   %rbp
 100da91:	mov    %rsp,%rbp
 100da94:	push   %r15
 100da96:	push   %r14
 100da98:	push   %r13
 100da9a:	push   %r12
 100da9c:	push   %rbx
 100da9d:	sub    $0x2b28,%rsp
 100daa4:	mov    %rcx,%r14
 100daa7:	mov    %rdx,-0x60(%rbp)
 100daab:	mov    %esi,-0x4c(%rbp)
 100daae:	mov    %rdi,-0x68(%rbp)
 100dab2:	lea    -0x2b50(%rbp),%rbx
 100dab9:	xor    %r12d,%r12d
 100dabc:	mov    $0x29a0,%edx
 100dac1:	mov    %rbx,%rdi
 100dac4:	xor    %esi,%esi
 100dac6:	call   101e6b0 <compiler_rt.fastMemset>
 100dacb:	mov    %rbx,%rdi
 100dace:	call   1017c60 <mylang_scoped_init>
 100dad3:	lea    -0xb8f9(%rip),%rax        # 10021e1 <__abi_tag+0x1ee5>
 100dada:	mov    %rax,-0x1c0(%rbp)
 100dae1:	vpxor  %xmm0,%xmm0,%xmm0
 100dae5:	vmovdqu %ymm0,-0x198(%rbp)
 100daed:	vmovdqu %ymm0,-0x1b0(%rbp)
 100daf5:	lea    -0xbec8(%rip),%rdi        # 1001c34 <__abi_tag+0x1938>
 100dafc:	vzeroupper
 100daff:	call   101f1a0 <getenv@plt>
 100db04:	test   %rax,%rax
 100db07:	je     100e16a <mylang_qbe_run_grants+0x6da>
 100db0d:	mov    %rax,%r15
 100db10:	cmpb   $0x0,(%rax)
 100db13:	je     100e1f5 <mylang_qbe_run_grants+0x765>
 100db19:	mov    %r14,-0x58(%rbp)
 100db1d:	mov    %r15,%rdi
 100db20:	call   101e660 <compiler_rt.strlen>
 100db25:	mov    %rax,%r14
 100db28:	lea    0x1(%rax),%rbx
 100db2c:	mov    %rbx,%rdi
 100db2f:	call   101f070 <malloc@plt>
 100db34:	mov    %rax,%r12
 100db37:	shr    $1,%r14
 100db3a:	inc    %r14
 100db3d:	mov    $0x8,%esi
 100db42:	mov    %r14,%rdi
 100db45:	call   101ef80 <calloc@plt>
 100db4a:	mov    %rax,%r13
 100db4d:	mov    %r12,-0x40(%rbp)
 100db51:	test   %r12,%r12
 100db54:	je     100e491 <mylang_qbe_run_grants+0xa01>
 100db5a:	test   %r13,%r13
 100db5d:	je     100e491 <mylang_qbe_run_grants+0xa01>
 100db63:	mov    -0x40(%rbp),%r14
 100db67:	mov    %r14,%rdi
 100db6a:	mov    %r15,%rsi
 100db6d:	mov    %rbx,%rdx
 100db70:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 100db75:	movzbl (%r14),%esi
 100db79:	test   %sil,%sil
 100db7c:	je     100e15a <mylang_qbe_run_grants+0x6ca>
 100db82:	xor    %ebx,%ebx
 100db84:	movabs $0x100002600,%rax
 100db8e:	mov    -0x40(%rbp),%rdi
 100db92:	mov    %rdi,%rcx
 100db95:	mov    %rdi,%rdx
 100db98:	cmp    $0x20,%sil
 100db9c:	ja     100dbc9 <mylang_qbe_run_grants+0x139>
 100db9e:	xchg   %ax,%ax
 100dba0:	movzbl %sil,%esi
 100dba4:	bt     %rsi,%rax
 100dba8:	jae    100dbc0 <mylang_qbe_run_grants+0x130>
 100dbaa:	movzbl 0x1(%rdx),%esi
 100dbae:	inc    %rdx
 100dbb1:	cmp    $0x20,%sil
 100dbb5:	jbe    100dba0 <mylang_qbe_run_grants+0x110>
 100dbb7:	jmp    100dbc9 <mylang_qbe_run_grants+0x139>
 100dbb9:	nopl   0x0(%rax)
 100dbc0:	test   %rsi,%rsi
 100dbc3:	je     100dc6f <mylang_qbe_run_grants+0x1df>
 100dbc9:	mov    %rcx,0x0(%r13,%rbx,8)
 100dbce:	movzbl (%rdx),%edi
 100dbd1:	test   %dil,%dil
 100dbd4:	je     100dc4c <mylang_qbe_run_grants+0x1bc>
 100dbd6:	xor    %esi,%esi
 100dbd8:	jmp    100dbef <mylang_qbe_run_grants+0x15f>
 100dbda:	nopw   0x0(%rax,%rax,1)
 100dbe0:	xor    $0x1,%esi
 100dbe3:	movzbl 0x1(%rdx),%edi
 100dbe7:	inc    %rdx
 100dbea:	test   %dil,%dil
 100dbed:	je     100dc44 <mylang_qbe_run_grants+0x1b4>
 100dbef:	test   %esi,%esi
 100dbf1:	je     100dc10 <mylang_qbe_run_grants+0x180>
 100dbf3:	cmp    $0x5c,%dil
 100dbf7:	je     100dc30 <mylang_qbe_run_grants+0x1a0>
 100dbf9:	movzbl %dil,%r8d
 100dbfd:	cmp    $0x22,%r8d
 100dc01:	je     100dbe0 <mylang_qbe_run_grants+0x150>
 100dc03:	jmp    100dc3c <mylang_qbe_run_grants+0x1ac>
 100dc05:	data16 cs nopw 0x0(%rax,%rax,1)
 100dc10:	cmp    $0x22,%dil
 100dc14:	ja     100dc3c <mylang_qbe_run_grants+0x1ac>
 100dc16:	movzbl %dil,%r8d
 100dc1a:	cmp    $0x22,%r8
 100dc1e:	je     100dbe0 <mylang_qbe_run_grants+0x150>
 100dc20:	bt     %r8,%rax
 100dc24:	jae    100dc3c <mylang_qbe_run_grants+0x1ac>
 100dc26:	jmp    100dc50 <mylang_qbe_run_grants+0x1c0>
 100dc28:	nopl   0x0(%rax,%rax,1)
 100dc30:	cmpb   $0x0,0x1(%rdx)
 100dc34:	je     100dc39 <mylang_qbe_run_grants+0x1a9>
 100dc36:	inc    %rdx
 100dc39:	movzbl (%rdx),%edi
 100dc3c:	mov    %dil,(%rcx)
 100dc3f:	inc    %rcx
 100dc42:	jmp    100dbe3 <mylang_qbe_run_grants+0x153>
 100dc44:	test   %esi,%esi
 100dc46:	jne    100e575 <mylang_qbe_run_grants+0xae5>
 100dc4c:	xor    %esi,%esi
 100dc4e:	jmp    100dc55 <mylang_qbe_run_grants+0x1c5>
 100dc50:	mov    $0x1,%esi
 100dc55:	inc    %rbx
 100dc58:	lea    (%rdx,%rsi,1),%rdi
 100dc5c:	movb   $0x0,(%rcx)
 100dc5f:	inc    %rcx
 100dc62:	movzbl (%rdx,%rsi,1),%esi
 100dc66:	test   %sil,%sil
 100dc69:	jne    100db95 <mylang_qbe_run_grants+0x105>
 100dc6f:	test   %ebx,%ebx
 100dc71:	js     100e575 <mylang_qbe_run_grants+0xae5>
 100dc77:	je     100e15a <mylang_qbe_run_grants+0x6ca>
 100dc7d:	and    $0x7fffffff,%ebx
 100dc83:	xor    %r14d,%r14d
 100dc86:	lea    -0xc414(%rip),%r15        # 1001879 <__abi_tag+0x157d>
 100dc8d:	mov    %r13,-0x38(%rbp)
 100dc91:	mov    %rbx,-0x30(%rbp)
 100dc95:	jmp    100dcbc <mylang_qbe_run_grants+0x22c>
 100dc97:	movl   $0x1,-0x1cc(%rbp)
 100dca1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100dcb0:	inc    %r14
 100dcb3:	cmp    %rbx,%r14
 100dcb6:	je     100e15a <mylang_qbe_run_grants+0x6ca>
 100dcbc:	mov    0x0(%r13,%r14,8),%r12
 100dcc1:	mov    %r12,%rdi
 100dcc4:	mov    %r15,%rsi
 100dcc7:	call   101eff0 <strcmp@plt>
 100dccc:	test   %eax,%eax
 100dcce:	mov    %r12,-0x48(%rbp)
 100dcd2:	je     100ddf0 <mylang_qbe_run_grants+0x360>
 100dcd8:	mov    $0xd,%edx
 100dcdd:	mov    %r12,%rdi
 100dce0:	lea    -0xbf45(%rip),%rsi        # 1001da2 <__abi_tag+0x1aa6>
 100dce7:	call   101efe0 <strncmp@plt>
 100dcec:	test   %eax,%eax
 100dcee:	je     100de10 <mylang_qbe_run_grants+0x380>
 100dcf4:	mov    $0xe,%edx
 100dcf9:	mov    %r12,%rdi
 100dcfc:	lea    -0xbf70(%rip),%rsi        # 1001d93 <__abi_tag+0x1a97>
 100dd03:	call   101efe0 <strncmp@plt>
 100dd08:	test   %eax,%eax
 100dd0a:	je     100de75 <mylang_qbe_run_grants+0x3e5>
 100dd10:	mov    $0x11,%edx
 100dd15:	mov    %r12,%rdi
 100dd18:	lea    -0xbfb9(%rip),%rsi        # 1001d66 <__abi_tag+0x1a6a>
 100dd1f:	call   101efe0 <strncmp@plt>
 100dd24:	test   %eax,%eax
 100dd26:	je     100deeb <mylang_qbe_run_grants+0x45b>
 100dd2c:	mov    %r12,%rdi
 100dd2f:	lea    -0xc40e(%rip),%rsi        # 1001928 <__abi_tag+0x162c>
 100dd36:	call   101eff0 <strcmp@plt>
 100dd3b:	test   %eax,%eax
 100dd3d:	je     100df2e <mylang_qbe_run_grants+0x49e>
 100dd43:	mov    %r12,%rdi
 100dd46:	lea    -0xc528(%rip),%rsi        # 1001825 <__abi_tag+0x1529>
 100dd4d:	call   101eff0 <strcmp@plt>
 100dd52:	test   %eax,%eax
 100dd54:	je     100df7d <mylang_qbe_run_grants+0x4ed>
 100dd5a:	mov    $0xe,%edx
 100dd5f:	mov    %r12,%rdi
 100dd62:	lea    -0xc46a(%rip),%rsi        # 10018ff <__abi_tag+0x1603>
 100dd69:	call   101efe0 <strncmp@plt>
 100dd6e:	test   %eax,%eax
 100dd70:	je     100dfc5 <mylang_qbe_run_grants+0x535>
 100dd76:	mov    $0xb,%edx
 100dd7b:	mov    %r12,%rdi
 100dd7e:	lea    -0xc606(%rip),%rsi        # 100177f <__abi_tag+0x1483>
 100dd85:	call   101efe0 <strncmp@plt>
 100dd8a:	mov    -0x48(%rbp),%r12
 100dd8e:	test   %eax,%eax
 100dd90:	je     100e001 <mylang_qbe_run_grants+0x571>
 100dd96:	mov    %r12,%rdi
 100dd99:	lea    -0xc484(%rip),%rsi        # 100191c <__abi_tag+0x1620>
 100dda0:	call   101eff0 <strcmp@plt>
 100dda5:	test   %eax,%eax
 100dda7:	je     100e03d <mylang_qbe_run_grants+0x5ad>
 100ddad:	mov    $0x8,%edx
 100ddb2:	mov    %r12,%rdi
 100ddb5:	lea    -0xbfe7(%rip),%rsi        # 1001dd5 <__abi_tag+0x1ad9>
 100ddbc:	call   101efe0 <strncmp@plt>
 100ddc1:	test   %eax,%eax
 100ddc3:	je     100df90 <mylang_qbe_run_grants+0x500>
 100ddc9:	mov    $0xa,%edx
 100ddce:	mov    %r12,%rdi
 100ddd1:	mov    %r15,%rsi
 100ddd4:	call   101efe0 <strncmp@plt>
 100ddd9:	test   %eax,%eax
 100dddb:	setne  %al
 100ddde:	mov    %eax,%ecx
 100dde0:	jmp    100df94 <mylang_qbe_run_grants+0x504>
 100dde5:	data16 cs nopw 0x0(%rax,%rax,1)
 100ddf0:	cmpl   $0x0,-0x1cc(%rbp)
 100ddf7:	jne    100df90 <mylang_qbe_run_grants+0x500>
 100ddfd:	jmp    100dc97 <mylang_qbe_run_grants+0x207>
 100de02:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100de10:	cmpb   $0x0,0xd(%r12)
 100de16:	je     100df90 <mylang_qbe_run_grants+0x500>
 100de1c:	lea    0xd(%r12),%rbx
 100de21:	mov    -0x1e0(%rbp),%r12
 100de28:	test   %r12,%r12
 100de2b:	je     100df08 <mylang_qbe_run_grants+0x478>
 100de31:	cmp    $0x8,%r12
 100de35:	je     100ded3 <mylang_qbe_run_grants+0x443>
 100de3b:	lea    -0x258(%rbp),%r15
 100de42:	mov    %r12,%r13
 100de45:	jmp    100de5d <mylang_qbe_run_grants+0x3cd>
 100de47:	nopw   0x0(%rax,%rax,1)
 100de50:	add    $0x10,%r15
 100de54:	dec    %r13
 100de57:	je     100df08 <mylang_qbe_run_grants+0x478>
 100de5d:	mov    -0x8(%r15),%rdi
 100de61:	mov    %rbx,%rsi
 100de64:	call   101eff0 <strcmp@plt>
 100de69:	test   %eax,%eax
 100de6b:	jne    100de50 <mylang_qbe_run_grants+0x3c0>
 100de6d:	cmpl   $0x0,(%r15)
 100de71:	jne    100de50 <mylang_qbe_run_grants+0x3c0>
 100de73:	jmp    100ded3 <mylang_qbe_run_grants+0x443>
 100de75:	cmpb   $0x0,0xe(%r12)
 100de7b:	je     100df90 <mylang_qbe_run_grants+0x500>
 100de81:	lea    0xe(%r12),%rbx
 100de86:	mov    -0x1e0(%rbp),%r13
 100de8d:	test   %r13,%r13
 100de90:	je     100df46 <mylang_qbe_run_grants+0x4b6>
 100de96:	cmp    $0x8,%r13
 100de9a:	je     100ded3 <mylang_qbe_run_grants+0x443>
 100de9c:	lea    -0x258(%rbp),%r15
 100dea3:	mov    %r13,%r12
 100dea6:	jmp    100debd <mylang_qbe_run_grants+0x42d>
 100dea8:	nopl   0x0(%rax,%rax,1)
 100deb0:	add    $0x10,%r15
 100deb4:	dec    %r12
 100deb7:	je     100df46 <mylang_qbe_run_grants+0x4b6>
 100debd:	mov    -0x8(%r15),%rdi
 100dec1:	mov    %rbx,%rsi
 100dec4:	call   101eff0 <strcmp@plt>
 100dec9:	test   %eax,%eax
 100decb:	jne    100deb0 <mylang_qbe_run_grants+0x420>
 100decd:	cmpl   $0x1,(%r15)
 100ded1:	jne    100deb0 <mylang_qbe_run_grants+0x420>
 100ded3:	xor    %eax,%eax
 100ded5:	xor    %ecx,%ecx
 100ded7:	mov    -0x38(%rbp),%r13
 100dedb:	mov    -0x30(%rbp),%rbx
 100dedf:	lea    -0xc66d(%rip),%r15        # 1001879 <__abi_tag+0x157d>
 100dee6:	jmp    100df94 <mylang_qbe_run_grants+0x504>
 100deeb:	lea    0x11(%r12),%rsi
 100def0:	lea    -0x2b50(%rbp),%rdi
 100def7:	call   10174e0 <mylang_scoped_endpoint>
 100defc:	test   %eax,%eax
 100defe:	setne  %cl
 100df01:	xor    %eax,%eax
 100df03:	jmp    100df94 <mylang_qbe_run_grants+0x504>
 100df08:	lea    0x1(%r12),%rax
 100df0d:	mov    %rax,-0x1e0(%rbp)
 100df14:	shl    $0x4,%r12
 100df18:	lea    -0x260(%rbp),%rax
 100df1f:	mov    %rbx,(%rax,%r12,1)
 100df23:	movq   $0x0,0x8(%rax,%r12,1)
 100df2c:	jmp    100df69 <mylang_qbe_run_grants+0x4d9>
 100df2e:	cmpl   $0x0,-0x1d8(%rbp)
 100df35:	jne    100df90 <mylang_qbe_run_grants+0x500>
 100df37:	movl   $0x1,-0x1d8(%rbp)
 100df41:	jmp    100dcb0 <mylang_qbe_run_grants+0x220>
 100df46:	lea    0x1(%r13),%rax
 100df4a:	mov    %rax,-0x1e0(%rbp)
 100df51:	shl    $0x4,%r13
 100df55:	lea    -0x260(%rbp),%rax
 100df5c:	mov    %rbx,(%rax,%r13,1)
 100df60:	movq   $0x1,0x8(%rax,%r13,1)
 100df69:	mov    -0x38(%rbp),%r13
 100df6d:	mov    -0x30(%rbp),%rbx
 100df71:	lea    -0xc6ff(%rip),%r15        # 1001879 <__abi_tag+0x157d>
 100df78:	jmp    100dcb0 <mylang_qbe_run_grants+0x220>
 100df7d:	cmpl   $0x0,-0x1c8(%rbp)
 100df84:	je     100e0e2 <mylang_qbe_run_grants+0x652>
 100df8a:	nopw   0x0(%rax,%rax,1)
 100df90:	xor    %eax,%eax
 100df92:	xor    %ecx,%ecx
 100df94:	test   %al,%al
 100df96:	jne    100dfa0 <mylang_qbe_run_grants+0x510>
 100df98:	test   %cl,%cl
 100df9a:	je     100e597 <mylang_qbe_run_grants+0xb07>
 100dfa0:	test   %al,%al
 100dfa2:	je     100dcb0 <mylang_qbe_run_grants+0x220>
 100dfa8:	lea    -0x1b0(%rbp),%rdi
 100dfaf:	mov    -0x48(%rbp),%rsi
 100dfb3:	call   100bc80 <myl_qbe_control>
 100dfb8:	test   %eax,%eax
 100dfba:	jne    100dcb0 <mylang_qbe_run_grants+0x220>
 100dfc0:	jmp    100e5a0 <mylang_qbe_run_grants+0xb10>
 100dfc5:	movzbl 0xe(%r12),%eax
 100dfcb:	test   %eax,%eax
 100dfcd:	je     100e0f1 <mylang_qbe_run_grants+0x661>
 100dfd3:	cmp    $0x3d,%eax
 100dfd6:	jne    100dd76 <mylang_qbe_run_grants+0x2e6>
 100dfdc:	cmpb   $0x0,0xf(%r12)
 100dfe2:	je     100dd76 <mylang_qbe_run_grants+0x2e6>
 100dfe8:	cmpl   $0x0,-0x1d4(%rbp)
 100dfef:	jne    100dd76 <mylang_qbe_run_grants+0x2e6>
 100dff5:	add    $0xf,%r12
 100dff9:	mov    %r12,%rdi
 100dffc:	jmp    100e105 <mylang_qbe_run_grants+0x675>
 100e001:	movzbl 0xb(%r12),%eax
 100e007:	test   %eax,%eax
 100e009:	je     100e130 <mylang_qbe_run_grants+0x6a0>
 100e00f:	cmp    $0x3d,%eax
 100e012:	jne    100dd96 <mylang_qbe_run_grants+0x306>
 100e018:	cmpb   $0x0,0xc(%r12)
 100e01e:	je     100dd96 <mylang_qbe_run_grants+0x306>
 100e024:	cmpl   $0x0,-0x1d0(%rbp)
 100e02b:	jne    100dd96 <mylang_qbe_run_grants+0x306>
 100e031:	add    $0xc,%r12
 100e035:	mov    %r12,%rax
 100e038:	jmp    100e144 <mylang_qbe_run_grants+0x6b4>
 100e03d:	vmovdqu -0x1d8(%rbp),%xmm0
 100e045:	vpinsrd $0x3,-0x1c8(%rbp),%xmm0,%xmm0
 100e04f:	xor    %eax,%eax
 100e051:	vptest %xmm0,%xmm0
 100e056:	jne    100df92 <mylang_qbe_run_grants+0x502>
 100e05c:	cmpq   $0x0,-0x1e0(%rbp)
 100e064:	jne    100df92 <mylang_qbe_run_grants+0x502>
 100e06a:	cmpq   $0x0,-0x268(%rbp)
 100e072:	mov    $0x0,%ecx
 100e077:	jne    100df94 <mylang_qbe_run_grants+0x504>
 100e07d:	movl   $0x1,-0x1c8(%rbp)
 100e087:	movl   $0x1,-0x1d0(%rbp)
 100e091:	movabs $0x100000001,%rax
 100e09b:	mov    %rax,-0x1d8(%rbp)
 100e0a2:	lea    -0xbec8(%rip),%rax        # 10021e1 <__abi_tag+0x1ee5>
 100e0a9:	mov    %rax,-0x1c0(%rbp)
 100e0b0:	lea    -0x2b50(%rbp),%r12
 100e0b7:	mov    %r12,%rdi
 100e0ba:	lea    -0xc2ee(%rip),%rsi        # 1001dd3 <__abi_tag+0x1ad7>
 100e0c1:	mov    $0x1,%edx
 100e0c6:	call   100e5e0 <directory>
 100e0cb:	test   %eax,%eax
 100e0cd:	je     100df90 <mylang_qbe_run_grants+0x500>
 100e0d3:	mov    %r12,%rdi
 100e0d6:	lea    -0xc2ff(%rip),%rsi        # 1001dde <__abi_tag+0x1ae2>
 100e0dd:	jmp    100def7 <mylang_qbe_run_grants+0x467>
 100e0e2:	movl   $0x1,-0x1c8(%rbp)
 100e0ec:	jmp    100dcb0 <mylang_qbe_run_grants+0x220>
 100e0f1:	cmpl   $0x0,-0x1d4(%rbp)
 100e0f8:	lea    -0xbf1e(%rip),%rdi        # 10021e1 <__abi_tag+0x1ee5>
 100e0ff:	jne    100dd76 <mylang_qbe_run_grants+0x2e6>
 100e105:	movl   $0x1,-0x1d4(%rbp)
 100e10f:	cmpb   $0x0,(%rdi)
 100e112:	je     100dcb0 <mylang_qbe_run_grants+0x220>
 100e118:	xor    %esi,%esi
 100e11a:	mov    $0xa,%edx
 100e11f:	call   101f1b0 <strtoull@plt>
 100e124:	mov    %rax,-0x1b8(%rbp)
 100e12b:	jmp    100dcb0 <mylang_qbe_run_grants+0x220>
 100e130:	cmpl   $0x0,-0x1d0(%rbp)
 100e137:	lea    -0xbf5d(%rip),%rax        # 10021e1 <__abi_tag+0x1ee5>
 100e13e:	jne    100dd96 <mylang_qbe_run_grants+0x306>
 100e144:	movl   $0x1,-0x1d0(%rbp)
 100e14e:	mov    %rax,-0x1c0(%rbp)
 100e155:	jmp    100dcb0 <mylang_qbe_run_grants+0x220>
 100e15a:	mov    %r13,%rdi
 100e15d:	call   101efd0 <free@plt>
 100e162:	mov    -0x58(%rbp),%r14
 100e166:	mov    -0x40(%rbp),%r12
 100e16a:	test   %r14,%r14
 100e16d:	je     100e201 <mylang_qbe_run_grants+0x771>
 100e173:	vmovups 0xb8(%r14),%ymm0
 100e17c:	vmovups %ymm0,-0x88(%rbp)
 100e184:	vmovups 0xa0(%r14),%ymm0
 100e18d:	vmovups %ymm0,-0xa0(%rbp)
 100e195:	vmovups 0x80(%r14),%ymm0
 100e19e:	vmovups %ymm0,-0xc0(%rbp)
 100e1a6:	vmovdqu (%r14),%ymm0
 100e1ab:	vmovups 0x20(%r14),%ymm1
 100e1b1:	vmovups 0x40(%r14),%ymm2
 100e1b7:	vmovups 0x60(%r14),%ymm3
 100e1bd:	vmovups %ymm3,-0xe0(%rbp)
 100e1c5:	vmovups %ymm2,-0x100(%rbp)
 100e1cd:	vmovups %ymm1,-0x120(%rbp)
 100e1d5:	vmovdqu %ymm0,-0x140(%rbp)
 100e1dd:	cmpl   $0x0,-0x1cc(%rbp)
 100e1e4:	jne    100e246 <mylang_qbe_run_grants+0x7b6>
 100e1e6:	movl   $0x1,0x1c5f0(%rip)        # 102a7e0 <host_authority>
 100e1f0:	jmp    100e512 <mylang_qbe_run_grants+0xa82>
 100e1f5:	xor    %r12d,%r12d
 100e1f8:	test   %r14,%r14
 100e1fb:	jne    100e173 <mylang_qbe_run_grants+0x6e3>
 100e201:	vpxor  %xmm0,%xmm0,%xmm0
 100e205:	vmovdqu %ymm0,-0x88(%rbp)
 100e20d:	vmovdqu %ymm0,-0xa0(%rbp)
 100e215:	vmovdqu %ymm0,-0xc0(%rbp)
 100e21d:	vmovdqu %ymm0,-0xe0(%rbp)
 100e225:	vmovdqu %ymm0,-0x100(%rbp)
 100e22d:	vmovdqu %ymm0,-0x120(%rbp)
 100e235:	vmovdqu %ymm0,-0x140(%rbp)
 100e23d:	cmpl   $0x0,-0x1cc(%rbp)
 100e244:	je     100e2ac <mylang_qbe_run_grants+0x81c>
 100e246:	xor    %eax,%eax
 100e248:	cmpl   $0x0,-0x1c8(%rbp)
 100e24f:	setne  %al
 100e252:	mov    %eax,0x1c588(%rip)        # 102a7e0 <host_authority>
 100e258:	cmpq   $0x0,-0x1e0(%rbp)
 100e260:	je     100e2cd <mylang_qbe_run_grants+0x83d>
 100e262:	lea    -0x258(%rbp),%r14
 100e269:	xor    %r15d,%r15d
 100e26c:	lea    -0x2b50(%rbp),%rbx
 100e273:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100e280:	mov    -0x8(%r14),%rsi
 100e284:	mov    (%r14),%edx
 100e287:	mov    %rbx,%rdi
 100e28a:	vzeroupper
 100e28d:	call   1017cc0 <mylang_scoped_grant>
 100e292:	test   %eax,%eax
 100e294:	je     100e467 <mylang_qbe_run_grants+0x9d7>
 100e29a:	inc    %r15
 100e29d:	add    $0x10,%r14
 100e2a1:	cmp    -0x1e0(%rbp),%r15
 100e2a8:	jb     100e280 <mylang_qbe_run_grants+0x7f0>
 100e2aa:	jmp    100e2cd <mylang_qbe_run_grants+0x83d>
 100e2ac:	movl   $0x1,0x1c52a(%rip)        # 102a7e0 <host_authority>
 100e2b6:	lea    -0x2b50(%rbp),%rdi
 100e2bd:	vzeroupper
 100e2c0:	call   1017d30 <mylang_scoped_working_directory>
 100e2c5:	test   %eax,%eax
 100e2c7:	je     100e467 <mylang_qbe_run_grants+0x9d7>
 100e2cd:	mov    -0x1cc(%rbp),%ebx
 100e2d3:	lea    -0x110(%rbp),%rdi
 100e2da:	cmpq   $0x0,-0x2af0(%rbp)
 100e2e2:	je     100e324 <mylang_qbe_run_grants+0x894>
 100e2e4:	mov    $0x7,%edx
 100e2e9:	test   %ebx,%ebx
 100e2eb:	je     100e313 <mylang_qbe_run_grants+0x883>
 100e2ed:	mov    -0x1e0(%rbp),%rax
 100e2f4:	test   %rax,%rax
 100e2f7:	je     100e30e <mylang_qbe_run_grants+0x87e>
 100e2f9:	lea    -0x258(%rbp),%rcx
 100e300:	cmpl   $0x0,(%rcx)
 100e303:	jne    100e313 <mylang_qbe_run_grants+0x883>
 100e305:	add    $0x10,%rcx
 100e309:	dec    %rax
 100e30c:	jne    100e300 <mylang_qbe_run_grants+0x870>
 100e30e:	mov    $0x5,%edx
 100e313:	lea    -0x2b50(%rbp),%rsi
 100e31a:	vzeroupper
 100e31d:	call   1017e90 <mylang_scoped_provider>
 100e322:	jmp    100e331 <mylang_qbe_run_grants+0x8a1>
 100e324:	vpxor  %xmm0,%xmm0,%xmm0
 100e328:	vmovdqu %ymm0,0x18(%rdi)
 100e32d:	vmovdqu %ymm0,(%rdi)
 100e331:	lea    -0xd8(%rbp),%r14
 100e338:	cmpq   $0x0,-0x268(%rbp)
 100e340:	je     100e375 <mylang_qbe_run_grants+0x8e5>
 100e342:	lea    -0x178(%rbp),%rdi
 100e349:	lea    -0x2b50(%rbp),%rsi
 100e350:	mov    $0x7,%edx
 100e355:	vzeroupper
 100e358:	call   10176a0 <mylang_scoped_network_provider>
 100e35d:	vmovdqu -0x178(%rbp),%ymm0
 100e365:	vmovups -0x160(%rbp),%ymm1
 100e36d:	vmovups %ymm1,0x18(%r14)
 100e373:	jmp    100e37f <mylang_qbe_run_grants+0x8ef>
 100e375:	vpxor  %xmm0,%xmm0,%xmm0
 100e379:	vmovdqu %ymm0,0x18(%r14)
 100e37f:	vmovdqu %ymm0,(%r14)
 100e384:	test   %ebx,%ebx
 100e386:	je     100e3ee <mylang_qbe_run_grants+0x95e>
 100e388:	xor    %eax,%eax
 100e38a:	cmpl   $0x0,-0x1d8(%rbp)
 100e391:	lea    0x2f8(%rip),%rcx        # 100e690 <clock_now>
 100e398:	cmovne %rcx,%rax
 100e39c:	mov    %rax,-0x138(%rbp)
 100e3a3:	vpxor  %xmm0,%xmm0,%xmm0
 100e3a7:	vmovdqa %xmm0,-0x130(%rbp)
 100e3af:	cmpl   $0x0,-0x1d4(%rbp)
 100e3b6:	je     100e3d4 <mylang_qbe_run_grants+0x944>
 100e3b8:	lea    -0x1b8(%rbp),%rax
 100e3bf:	mov    %rax,-0x130(%rbp)
 100e3c6:	lea    0x333(%rip),%rax        # 100e700 <random_u64>
 100e3cd:	mov    %rax,-0x128(%rbp)
 100e3d4:	vmovdqa %xmm0,-0x120(%rbp)
 100e3dc:	cmpl   $0x0,-0x1d0(%rbp)
 100e3e3:	jne    100e4f6 <mylang_qbe_run_grants+0xa66>
 100e3e9:	jmp    100e512 <mylang_qbe_run_grants+0xa82>
 100e3ee:	lea    0x29b(%rip),%rax        # 100e690 <clock_now>
 100e3f5:	mov    %rax,-0x138(%rbp)
 100e3fc:	vpxor  %xmm0,%xmm0,%xmm0
 100e400:	vmovdqa %xmm0,-0x130(%rbp)
 100e408:	cmpl   $0x0,-0x1d4(%rbp)
 100e40f:	jne    100e4cf <mylang_qbe_run_grants+0xa3f>
 100e415:	xor    %ebx,%ebx
 100e417:	lea    -0x178(%rbp),%rsi
 100e41e:	xor    %edi,%edi
 100e420:	vzeroupper
 100e423:	call   101f1c0 <clock_gettime@plt>
 100e428:	test   %eax,%eax
 100e42a:	jne    100e4c8 <mylang_qbe_run_grants+0xa38>
 100e430:	mov    -0x178(%rbp),%rcx
 100e437:	mov    -0x170(%rbp),%rax
 100e43e:	movabs $0x7fffffffffffffff,%rdx
 100e448:	xor    %rax,%rdx
 100e44b:	movabs $0x112e0be826d694b3,%rsi
 100e455:	mulx   %rsi,%rdx,%rdx
 100e45a:	shr    $0x1a,%rdx
 100e45e:	cmp    %rdx,%rcx
 100e461:	jle    100e4be <mylang_qbe_run_grants+0xa2e>
 100e463:	xor    %ebx,%ebx
 100e465:	jmp    100e4c8 <mylang_qbe_run_grants+0xa38>
 100e467:	mov    0x1b10a(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100e46e:	mov    (%rax),%rcx
 100e471:	lea    -0xc319(%rip),%rdi        # 100215f <__abi_tag+0x1e63>
 100e478:	mov    $0x38,%esi
 100e47d:	mov    $0x1,%edx
 100e482:	call   101efa0 <fwrite@plt>
 100e487:	mov    $0x2,%ebx
 100e48c:	jmp    100e54d <mylang_qbe_run_grants+0xabd>
 100e491:	mov    %r13,%rdi
 100e494:	call   101efd0 <free@plt>
 100e499:	mov    0x1b0d8(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100e4a0:	mov    (%rax),%rcx
 100e4a3:	lea    -0xc3be(%rip),%rdi        # 10020ec <__abi_tag+0x1df0>
 100e4aa:	mov    $0x21,%esi
 100e4af:	mov    $0x1,%edx
 100e4b4:	call   101efa0 <fwrite@plt>
 100e4b9:	jmp    100e5c4 <mylang_qbe_run_grants+0xb34>
 100e4be:	imul   $0x3b9aca00,%rcx,%rbx
 100e4c5:	add    %rax,%rbx
 100e4c8:	mov    %rbx,-0x1b8(%rbp)
 100e4cf:	lea    -0x1b8(%rbp),%rax
 100e4d6:	mov    %rax,-0x130(%rbp)
 100e4dd:	lea    0x21c(%rip),%rax        # 100e700 <random_u64>
 100e4e4:	mov    %rax,-0x128(%rbp)
 100e4eb:	movq   $0x0,-0x120(%rbp)
 100e4f6:	mov    -0x1c0(%rbp),%rax
 100e4fd:	mov    %rax,-0x120(%rbp)
 100e504:	lea    0x245(%rip),%rax        # 100e750 <environment_get>
 100e50b:	mov    %rax,-0x118(%rbp)
 100e512:	xor    %eax,%eax
 100e514:	mov    -0x4c(%rbp),%ecx
 100e517:	test   %ecx,%ecx
 100e519:	setg   %al
 100e51c:	cmp    $0x2,%ecx
 100e51f:	mov    $0x1,%edx
 100e524:	cmovge %ecx,%edx
 100e527:	dec    %edx
 100e529:	mov    -0x60(%rbp),%rcx
 100e52d:	lea    (%rcx,%rax,8),%rcx
 100e531:	lea    -0x1b0(%rbp),%rsi
 100e538:	lea    -0x140(%rbp),%r8
 100e53f:	mov    -0x68(%rbp),%rdi
 100e543:	vzeroupper
 100e546:	call   100bf30 <mylang_qbe_run_process>
 100e54b:	mov    %eax,%ebx
 100e54d:	lea    -0x2b50(%rbp),%rdi
 100e554:	call   1017d90 <mylang_scoped_close>
 100e559:	mov    %r12,%rdi
 100e55c:	call   101efd0 <free@plt>
 100e561:	mov    %ebx,%eax
 100e563:	add    $0x2b28,%rsp
 100e56a:	pop    %rbx
 100e56b:	pop    %r12
 100e56d:	pop    %r13
 100e56f:	pop    %r14
 100e571:	pop    %r15
 100e573:	pop    %rbp
 100e574:	ret
 100e575:	mov    0x1affc(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100e57c:	mov    (%rax),%rcx
 100e57f:	lea    -0xc4cc(%rip),%rdi        # 10020ba <__abi_tag+0x1dbe>
 100e586:	mov    $0x31,%esi
 100e58b:	mov    $0x1,%edx
 100e590:	call   101efa0 <fwrite@plt>
 100e595:	jmp    100e5bc <mylang_qbe_run_grants+0xb2c>
 100e597:	lea    -0xc6fc(%rip),%rsi        # 1001ea2 <__abi_tag+0x1ba6>
 100e59e:	jmp    100e5a7 <mylang_qbe_run_grants+0xb17>
 100e5a0:	lea    -0xc58c(%rip),%rsi        # 100201b <__abi_tag+0x1d1f>
 100e5a7:	mov    0x1afca(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 100e5ae:	mov    (%rax),%rdi
 100e5b1:	mov    -0x48(%rbp),%rdx
 100e5b5:	xor    %eax,%eax
 100e5b7:	call   101efb0 <fprintf@plt>
 100e5bc:	mov    %r13,%rdi
 100e5bf:	call   101efd0 <free@plt>
 100e5c4:	mov    -0x40(%rbp),%rdi
 100e5c8:	call   101efd0 <free@plt>
 100e5cd:	mov    $0x2,%ebx
 100e5d2:	jmp    100e561 <mylang_qbe_run_grants+0xad1>
 100e5d4:	int3
 100e5d5:	int3
 100e5d6:	int3
 100e5d7:	int3
 100e5d8:	int3
 100e5d9:	int3
 100e5da:	int3
 100e5db:	int3
 100e5dc:	int3
 100e5dd:	int3
 100e5de:	int3
 100e5df:	int3

000000000100e5e0 <directory>:
 100e5e0:	push   %rbp
 100e5e1:	mov    %rsp,%rbp
 100e5e4:	push   %r15
 100e5e6:	push   %r14
 100e5e8:	push   %r13
 100e5ea:	push   %r12
 100e5ec:	push   %rbx
 100e5ed:	push   %rax
 100e5ee:	mov    %edx,-0x2c(%rbp)
 100e5f1:	xor    %eax,%eax
 100e5f3:	cmpb   $0x0,(%rsi)
 100e5f6:	je     100e677 <directory+0x97>
 100e5f8:	mov    %rsi,%r12
 100e5fb:	mov    %rdi,%r15
 100e5fe:	mov    0x2970(%rdi),%r14
 100e605:	test   %r14,%r14
 100e608:	je     100e644 <directory+0x64>
 100e60a:	cmp    $0x8,%r14
 100e60e:	je     100e640 <directory+0x60>
 100e610:	lea    0x28f8(%r15),%rbx
 100e617:	mov    %r14,%r13
 100e61a:	jmp    100e629 <directory+0x49>
 100e61c:	nopl   0x0(%rax)
 100e620:	add    $0x10,%rbx
 100e624:	dec    %r13
 100e627:	je     100e644 <directory+0x64>
 100e629:	mov    -0x8(%rbx),%rdi
 100e62d:	mov    %r12,%rsi
 100e630:	call   101eff0 <strcmp@plt>
 100e635:	test   %eax,%eax
 100e637:	jne    100e620 <directory+0x40>
 100e639:	mov    -0x2c(%rbp),%eax
 100e63c:	cmp    %eax,(%rbx)
 100e63e:	jne    100e620 <directory+0x40>
 100e640:	xor    %eax,%eax
 100e642:	jmp    100e677 <directory+0x97>
 100e644:	lea    0x1(%r14),%rax
 100e648:	mov    %rax,0x2970(%r15)
 100e64f:	shl    $0x4,%r14
 100e653:	mov    %r12,0x28f0(%r15,%r14,1)
 100e65b:	mov    -0x2c(%rbp),%eax
 100e65e:	mov    %eax,0x28f8(%r15,%r14,1)
 100e666:	movl   $0x0,0x28fc(%r15,%r14,1)
 100e672:	mov    $0x1,%eax
 100e677:	add    $0x8,%rsp
 100e67b:	pop    %rbx
 100e67c:	pop    %r12
 100e67e:	pop    %r13
 100e680:	pop    %r14
 100e682:	pop    %r15
 100e684:	pop    %rbp
 100e685:	ret
 100e686:	int3
 100e687:	int3
 100e688:	int3
 100e689:	int3
 100e68a:	int3
 100e68b:	int3
 100e68c:	int3
 100e68d:	int3
 100e68e:	int3
 100e68f:	int3

000000000100e690 <clock_now>:
 100e690:	push   %rbp
 100e691:	mov    %rsp,%rbp
 100e694:	push   %rbx
 100e695:	sub    $0x18,%rsp
 100e699:	xor    %ebx,%ebx
 100e69b:	lea    -0x18(%rbp),%rsi
 100e69f:	xor    %edi,%edi
 100e6a1:	call   101f1c0 <clock_gettime@plt>
 100e6a6:	mov    %eax,%ecx
 100e6a8:	mov    $0x3,%eax
 100e6ad:	test   %ecx,%ecx
 100e6af:	jne    100e6ec <clock_now+0x5c>
 100e6b1:	mov    -0x18(%rbp),%rsi
 100e6b5:	mov    -0x10(%rbp),%rcx
 100e6b9:	movabs $0x7fffffffffffffff,%rdx
 100e6c3:	xor    %rcx,%rdx
 100e6c6:	movabs $0x112e0be826d694b3,%rdi
 100e6d0:	mulx   %rdi,%rdx,%rdx
 100e6d5:	shr    $0x1a,%rdx
 100e6d9:	xor    %ebx,%ebx
 100e6db:	cmp    %rdx,%rsi
 100e6de:	jg     100e6ec <clock_now+0x5c>
 100e6e0:	imul   $0x3b9aca00,%rsi,%rbx
 100e6e7:	add    %rcx,%rbx
 100e6ea:	xor    %eax,%eax
 100e6ec:	mov    %rbx,%rdx
 100e6ef:	add    $0x18,%rsp
 100e6f3:	pop    %rbx
 100e6f4:	pop    %rbp
 100e6f5:	ret
 100e6f6:	int3
 100e6f7:	int3
 100e6f8:	int3
 100e6f9:	int3
 100e6fa:	int3
 100e6fb:	int3
 100e6fc:	int3
 100e6fd:	int3
 100e6fe:	int3
 100e6ff:	int3

000000000100e700 <random_u64>:
 100e700:	movabs $0x9e3779b97f4a7c15,%rax
 100e70a:	add    (%rdi),%rax
 100e70d:	mov    %rax,(%rdi)
 100e710:	mov    %rax,%rcx
 100e713:	shr    $0x1e,%rcx
 100e717:	xor    %rax,%rcx
 100e71a:	movabs $0xbf58476d1ce4e5b9,%rax
 100e724:	imul   %rcx,%rax
 100e728:	mov    %rax,%rcx
 100e72b:	shr    $0x1b,%rcx
 100e72f:	xor    %rax,%rcx
 100e732:	movabs $0x94d049bb133111eb,%rax
 100e73c:	imul   %rcx,%rax
 100e740:	mov    %rax,%rdx
 100e743:	shr    $0x1f,%rdx
 100e747:	xor    %rax,%rdx
 100e74a:	xor    %eax,%eax
 100e74c:	ret
 100e74d:	int3
 100e74e:	int3
 100e74f:	int3

000000000100e750 <environment_get>:
 100e750:	push   %rbp
 100e751:	mov    %rsp,%rbp
 100e754:	push   %r15
 100e756:	push   %r14
 100e758:	push   %r13
 100e75a:	push   %r12
 100e75c:	push   %rbx
 100e75d:	sub    $0x118,%rsp
 100e764:	mov    %rdi,%rbx
 100e767:	vxorps %xmm0,%xmm0,%xmm0
 100e76b:	vmovups %xmm0,(%rdi)
 100e76f:	movq   $0x0,0x10(%rdi)
 100e777:	cmp    $0x100,%rcx
 100e77e:	jb     100e79b <environment_get+0x4b>
 100e780:	movl   $0x2,(%rbx)
 100e786:	mov    %rbx,%rax
 100e789:	add    $0x118,%rsp
 100e790:	pop    %rbx
 100e791:	pop    %r12
 100e793:	pop    %r13
 100e795:	pop    %r14
 100e797:	pop    %r15
 100e799:	pop    %rbp
 100e79a:	ret
 100e79b:	mov    %rcx,%r15
 100e79e:	mov    %rsi,%r14
 100e7a1:	mov    %r9,-0x38(%rbp)
 100e7a5:	mov    %r8,-0x30(%rbp)
 100e7a9:	lea    -0x140(%rbp),%rdi
 100e7b0:	mov    %rdx,%rsi
 100e7b3:	mov    %rcx,%rdx
 100e7b6:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 100e7bb:	movb   $0x0,-0x140(%rbp,%r15,1)
 100e7c4:	cmpb   $0x0,(%r14)
 100e7c8:	je     100e84b <environment_get+0xfb>
 100e7ce:	lea    -0x140(%rbp),%r13
 100e7d5:	jmp    100e7ef <environment_get+0x9f>
 100e7d7:	nopw   0x0(%rax,%rax,1)
 100e7e0:	mov    %r12,%rax
 100e7e3:	inc    %r12
 100e7e6:	cmpb   $0x0,0x1(%rax)
 100e7ea:	mov    %r12,%r14
 100e7ed:	je     100e780 <environment_get+0x30>
 100e7ef:	mov    %r14,%rdi
 100e7f2:	mov    $0x2c,%esi
 100e7f7:	call   101f170 <strchr@plt>
 100e7fc:	test   %rax,%rax
 100e7ff:	je     100e820 <environment_get+0xd0>
 100e801:	mov    %rax,%r12
 100e804:	sub    %r14,%rax
 100e807:	cmp    %r15,%rax
 100e80a:	jne    100e7e0 <environment_get+0x90>
 100e80c:	mov    %r14,%rdi
 100e80f:	mov    %r13,%rsi
 100e812:	mov    %r15,%rdx
 100e815:	call   101e680 <bcmp>
 100e81a:	test   %eax,%eax
 100e81c:	jne    100e7e0 <environment_get+0x90>
 100e81e:	jmp    100e84b <environment_get+0xfb>
 100e820:	mov    %r14,%rdi
 100e823:	call   101e660 <compiler_rt.strlen>
 100e828:	cmp    %r15,%rax
 100e82b:	jne    100e780 <environment_get+0x30>
 100e831:	lea    -0x140(%rbp),%rsi
 100e838:	mov    %r14,%rdi
 100e83b:	mov    %r15,%rdx
 100e83e:	call   101e680 <bcmp>
 100e843:	test   %eax,%eax
 100e845:	jne    100e780 <environment_get+0x30>
 100e84b:	lea    -0x140(%rbp),%rdi
 100e852:	call   101f1a0 <getenv@plt>
 100e857:	test   %rax,%rax
 100e85a:	je     100e786 <environment_get+0x36>
 100e860:	mov    %rax,%r14
 100e863:	mov    %rax,%rdi
 100e866:	call   101e660 <compiler_rt.strlen>
 100e86b:	cmp    -0x38(%rbp),%rax
 100e86f:	jbe    100e87c <environment_get+0x12c>
 100e871:	movl   $0x5,(%rbx)
 100e877:	jmp    100e786 <environment_get+0x36>
 100e87c:	mov    -0x30(%rbp),%rdi
 100e880:	mov    %r14,%rsi
 100e883:	mov    %rax,%rdx
 100e886:	mov    %rax,%r14
 100e889:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 100e88e:	movl   $0x1,0x10(%rbx)
 100e895:	mov    %r14,0x8(%rbx)
 100e899:	jmp    100e786 <environment_get+0x36>
 100e89e:	int3
 100e89f:	int3

000000000100e8a0 <release_all>:
 100e8a0:	push   %rbp
 100e8a1:	mov    %rsp,%rbp
 100e8a4:	push   %r15
 100e8a6:	push   %r14
 100e8a8:	push   %r13
 100e8aa:	push   %r12
 100e8ac:	push   %rbx
 100e8ad:	sub    $0x18,%rsp
 100e8b1:	mov    0x3e70(%rdi),%r14
 100e8b8:	test   %r14,%r14
 100e8bb:	je     100ea20 <release_all+0x180>
 100e8c1:	add    $0x3e70,%rdi
 100e8c8:	mov    %rdi,-0x30(%rbp)
 100e8cc:	cmpq   $0x0,0x8(%r14)
 100e8d1:	je     100ea04 <release_all+0x164>
 100e8d7:	xor    %ebx,%ebx
 100e8d9:	mov    %r14,-0x38(%rbp)
 100e8dd:	jmp    100e91f <release_all+0x7f>
 100e8df:	nop
 100e8e0:	mov    (%r12),%rdi
 100e8e4:	vzeroupper
 100e8e7:	call   101efd0 <free@plt>
 100e8ec:	mov    %r12,%rdi
 100e8ef:	call   101efd0 <free@plt>
 100e8f4:	mov    -0x38(%rbp),%r14
 100e8f8:	mov    0x50(%r15),%rdi
 100e8fc:	call   101efd0 <free@plt>
 100e901:	mov    0x58(%r15),%rdi
 100e905:	call   101efd0 <free@plt>
 100e90a:	mov    %r15,%rdi
 100e90d:	call   101efd0 <free@plt>
 100e912:	inc    %rbx
 100e915:	cmp    0x8(%r14),%rbx
 100e919:	jae    100ea04 <release_all+0x164>
 100e91f:	mov    (%r14),%rax
 100e922:	mov    (%rax,%rbx,8),%r15
 100e926:	mov    0x10(%r15),%r12
 100e92a:	test   %r12,%r12
 100e92d:	je     100e8f8 <release_all+0x58>
 100e92f:	mov    $0x30,%r14d
 100e935:	jmp    100e971 <release_all+0xd1>
 100e937:	nopw   0x0(%rax,%rax,1)
 100e940:	lea    (%r12,%r14,1),%r13
 100e944:	add    $0xfffffffffffffff0,%r13
 100e948:	mov    (%r12,%r14,1),%rdi
 100e94c:	vzeroupper
 100e94f:	call   101efd0 <free@plt>
 100e954:	vxorps %xmm0,%xmm0,%xmm0
 100e958:	vmovups %ymm0,0x10(%r13)
 100e95e:	vmovups %ymm0,0x0(%r13)
 100e964:	add    $0x30,%r14
 100e968:	cmp    $0x3030,%r14
 100e96f:	je     100e9c0 <release_all+0x120>
 100e971:	cmpl   $0x0,-0x10(%r12,%r14,1)
 100e977:	je     100e964 <release_all+0xc4>
 100e979:	mov    -0x8(%r12,%r14,1),%r13
 100e97e:	test   %r13,%r13
 100e981:	je     100e940 <release_all+0xa0>
 100e983:	mov    0x30(%r13),%eax
 100e987:	cmpl   $0x0,0x14(%r13)
 100e98c:	setne  %cl
 100e98f:	dec    %eax
 100e991:	mov    %eax,0x30(%r13)
 100e995:	sete   %al
 100e998:	and    %cl,%al
 100e99a:	cmp    $0x1,%al
 100e99c:	jne    100e940 <release_all+0xa0>
 100e99e:	mov    0x0(%r13),%rdi
 100e9a2:	vzeroupper
 100e9a5:	call   101efd0 <free@plt>
 100e9aa:	mov    0x18(%r13),%rdi
 100e9ae:	call   101efd0 <free@plt>
 100e9b3:	mov    %r13,%rdi
 100e9b6:	call   101efd0 <free@plt>
 100e9bb:	jmp    100e940 <release_all+0xa0>
 100e9bd:	nopl   (%rax)
 100e9c0:	cmpq   $0x0,0x8(%r12)
 100e9c6:	je     100e8e0 <release_all+0x40>
 100e9cc:	xor    %r14d,%r14d
 100e9cf:	nop
 100e9d0:	mov    (%r12),%rax
 100e9d4:	mov    (%rax,%r14,8),%r13
 100e9d8:	mov    0x0(%r13),%rdi
 100e9dc:	vzeroupper
 100e9df:	call   101efd0 <free@plt>
 100e9e4:	mov    0x18(%r13),%rdi
 100e9e8:	call   101efd0 <free@plt>
 100e9ed:	mov    %r13,%rdi
 100e9f0:	call   101efd0 <free@plt>
 100e9f5:	inc    %r14
 100e9f8:	cmp    0x8(%r12),%r14
 100e9fd:	jb     100e9d0 <release_all+0x130>
 100e9ff:	jmp    100e8e0 <release_all+0x40>
 100ea04:	mov    (%r14),%rdi
 100ea07:	call   101efd0 <free@plt>
 100ea0c:	mov    %r14,%rdi
 100ea0f:	call   101efd0 <free@plt>
 100ea14:	vxorps %xmm0,%xmm0,%xmm0
 100ea18:	mov    -0x30(%rbp),%rax
 100ea1c:	vmovups %xmm0,(%rax)
 100ea20:	add    $0x18,%rsp
 100ea24:	pop    %rbx
 100ea25:	pop    %r12
 100ea27:	pop    %r13
 100ea29:	pop    %r14
 100ea2b:	pop    %r15
 100ea2d:	pop    %rbp
 100ea2e:	ret
 100ea2f:	int3

000000000100ea30 <myl_native_budget_environment>:
 100ea30:	push   %rbp
 100ea31:	mov    %rsp,%rbp
 100ea34:	push   %rbx
 100ea35:	push   %rax
 100ea36:	mov    %rdi,%rbx
 100ea39:	lea    -0xce63(%rip),%rdi        # 1001bdd <__abi_tag+0x18e1>
 100ea40:	call   101f1a0 <getenv@plt>
 100ea45:	test   %rbx,%rbx
 100ea48:	je     100ea50 <myl_native_budget_environment+0x20>
 100ea4a:	movl   $0x1,(%rbx)
 100ea50:	test   %rax,%rax
 100ea53:	je     100eb35 <myl_native_budget_environment+0x105>
 100ea59:	movzbl (%rax),%edx
 100ea5c:	test   %dl,%dl
 100ea5e:	je     100eb35 <myl_native_budget_environment+0x105>
 100ea64:	lea    -0x30(%rdx),%ecx
 100ea67:	cmp    $0x9,%cl
 100ea6a:	ja     100eb2a <myl_native_budget_environment+0xfa>
 100ea70:	inc    %rax
 100ea73:	xor    %ecx,%ecx
 100ea75:	movabs $0xcccccccccccccccd,%rsi
 100ea7f:	nop
 100ea80:	add    $0xd0,%dl
 100ea83:	movzbl %dl,%edi
 100ea86:	mov    %rdi,%rdx
 100ea89:	not    %rdx
 100ea8c:	mulx   %rsi,%rdx,%rdx
 100ea91:	shr    $0x3,%rdx
 100ea95:	cmp    %rdx,%rcx
 100ea98:	ja     100eb2a <myl_native_budget_environment+0xfa>
 100ea9e:	lea    (%rcx,%rcx,4),%rcx
 100eaa2:	lea    (%rdi,%rcx,2),%rcx
 100eaa6:	movzbl (%rax),%edx
 100eaa9:	lea    -0x30(%rdx),%edi
 100eaac:	inc    %rax
 100eaaf:	cmp    $0xa,%dil
 100eab3:	jb     100ea80 <myl_native_budget_environment+0x50>
 100eab5:	movzbl %dl,%edx
 100eab8:	lea    -0x47(%rdx),%esi
 100eabb:	cmp    $0x26,%esi
 100eabe:	ja     100eafc <myl_native_budget_environment+0xcc>
 100eac0:	movabs $0x100000001,%rdi
 100eaca:	bt     %rsi,%rdi
 100eace:	jb     100eb07 <myl_native_budget_environment+0xd7>
 100ead0:	mov    $0x400,%edi
 100ead5:	movabs $0x1000000010,%r8
 100eadf:	bt     %rsi,%r8
 100eae3:	jb     100eb0c <myl_native_budget_environment+0xdc>
 100eae5:	movabs $0x4000000040,%rdi
 100eaef:	bt     %rsi,%rdi
 100eaf3:	jae    100eafc <myl_native_budget_environment+0xcc>
 100eaf5:	mov    $0x100000,%edi
 100eafa:	jmp    100eb0c <myl_native_budget_environment+0xdc>
 100eafc:	mov    $0x1,%eax
 100eb01:	test   %edx,%edx
 100eb03:	je     100eb14 <myl_native_budget_environment+0xe4>
 100eb05:	jmp    100eb2a <myl_native_budget_environment+0xfa>
 100eb07:	mov    $0x40000000,%edi
 100eb0c:	cmpb   $0x0,(%rax)
 100eb0f:	mov    %rdi,%rax
 100eb12:	jne    100eb2a <myl_native_budget_environment+0xfa>
 100eb14:	tzcnt  %rax,%rdx
 100eb19:	mov    $0xffffffffffffffff,%rsi
 100eb20:	shrx   %rdx,%rsi,%rdx
 100eb25:	cmp    %rdx,%rcx
 100eb28:	jbe    100eb3e <myl_native_budget_environment+0x10e>
 100eb2a:	test   %rbx,%rbx
 100eb2d:	je     100eb35 <myl_native_budget_environment+0x105>
 100eb2f:	movl   $0x0,(%rbx)
 100eb35:	xor    %eax,%eax
 100eb37:	add    $0x8,%rsp
 100eb3b:	pop    %rbx
 100eb3c:	pop    %rbp
 100eb3d:	ret
 100eb3e:	imul   %rcx,%rax
 100eb42:	jmp    100eb37 <myl_native_budget_environment+0x107>
 100eb44:	int3
 100eb45:	int3
 100eb46:	int3
 100eb47:	int3
 100eb48:	int3
 100eb49:	int3
 100eb4a:	int3
 100eb4b:	int3
 100eb4c:	int3
 100eb4d:	int3
 100eb4e:	int3
 100eb4f:	int3

000000000100eb50 <myl_native_budget_guard>:
 100eb50:	push   %rbp
 100eb51:	mov    %rsp,%rbp
 100eb54:	push   %r15
 100eb56:	push   %r14
 100eb58:	push   %r12
 100eb5a:	push   %rbx
 100eb5b:	sub    $0x10,%rsp
 100eb5f:	mov    %rdi,%rbx
 100eb62:	lea    -0xce5a(%rip),%rdi        # 1001d0f <__abi_tag+0x1a13>
 100eb69:	call   101f1a0 <getenv@plt>
 100eb6e:	test   %rax,%rax
 100eb71:	je     100eb9a <myl_native_budget_guard+0x4a>
 100eb73:	movzbl (%rax),%edx
 100eb76:	lea    -0x3a(%rdx),%ecx
 100eb79:	cmp    $0xf6,%cl
 100eb7c:	jae    100ec18 <myl_native_budget_guard+0xc8>
 100eb82:	lea    -0xce7a(%rip),%rdi        # 1001d0f <__abi_tag+0x1a13>
 100eb89:	call   101f1d0 <unsetenv@plt>
 100eb8e:	lea    -0xcff5(%rip),%rdi        # 1001ba0 <__abi_tag+0x18a4>
 100eb95:	call   101f1d0 <unsetenv@plt>
 100eb9a:	add    $0x10000000,%rbx
 100eba1:	xor    %r14d,%r14d
 100eba4:	cmp    $0x10000001,%rbx
 100ebab:	jb     100ec08 <myl_native_budget_guard+0xb8>
 100ebad:	lea    -0x30(%rbp),%rsi
 100ebb1:	mov    $0x9,%edi
 100ebb6:	call   101f150 <getrlimit@plt>
 100ebbb:	test   %eax,%eax
 100ebbd:	jne    100ec08 <myl_native_budget_guard+0xb8>
 100ebbf:	mov    -0x28(%rbp),%rcx
 100ebc3:	cmp    %rcx,%rbx
 100ebc6:	mov    %rcx,%rax
 100ebc9:	cmovb  %rbx,%rax
 100ebcd:	cmp    $0xffffffffffffffff,%rcx
 100ebd1:	cmove  %rbx,%rax
 100ebd5:	mov    -0x30(%rbp),%rcx
 100ebd9:	cmp    $0xffffffffffffffff,%rcx
 100ebdd:	sete   %dl
 100ebe0:	cmp    %rax,%rcx
 100ebe3:	seta   %cl
 100ebe6:	or     %dl,%cl
 100ebe8:	cmp    $0x1,%cl
 100ebeb:	jne    100ec08 <myl_native_budget_guard+0xb8>
 100ebed:	mov    %rax,-0x30(%rbp)
 100ebf1:	lea    -0x30(%rbp),%rsi
 100ebf5:	mov    $0x9,%edi
 100ebfa:	call   101f1e0 <setrlimit@plt>
 100ebff:	xor    %r14d,%r14d
 100ec02:	test   %eax,%eax
 100ec04:	sete   %r14b
 100ec08:	mov    %r14d,%eax
 100ec0b:	add    $0x10,%rsp
 100ec0f:	pop    %rbx
 100ec10:	pop    %r12
 100ec12:	pop    %r14
 100ec14:	pop    %r15
 100ec16:	pop    %rbp
 100ec17:	ret
 100ec18:	add    $0x2,%rax
 100ec1c:	xor    %r14d,%r14d
 100ec1f:	movabs $0xcccccccccccccccd,%rcx
 100ec29:	nopl   0x0(%rax)
 100ec30:	add    $0xd0,%dl
 100ec33:	movzbl %dl,%esi
 100ec36:	mov    %rsi,%rdx
 100ec39:	not    %rdx
 100ec3c:	mulx   %rcx,%rdx,%rdx
 100ec41:	shr    $0x3,%rdx
 100ec45:	cmp    %rdx,%r14
 100ec48:	ja     100eb82 <myl_native_budget_guard+0x32>
 100ec4e:	lea    (%r14,%r14,4),%rdx
 100ec52:	lea    (%rsi,%rdx,2),%r14
 100ec56:	movzbl -0x1(%rax),%edx
 100ec5a:	lea    -0x30(%rdx),%esi
 100ec5d:	inc    %rax
 100ec60:	cmp    $0xa,%sil
 100ec64:	jb     100ec30 <myl_native_budget_guard+0xe0>
 100ec66:	cmp    $0x3a,%dl
 100ec69:	jne    100eb82 <myl_native_budget_guard+0x32>
 100ec6f:	movzbl -0x1(%rax),%r12d
 100ec74:	lea    -0x3a(%r12),%edx
 100ec79:	cmp    $0xf6,%dl
 100ec7c:	jb     100eb82 <myl_native_budget_guard+0x32>
 100ec82:	xor    %r15d,%r15d
 100ec85:	data16 cs nopw 0x0(%rax,%rax,1)
 100ec90:	add    $0xd0,%r12b
 100ec94:	movzbl %r12b,%esi
 100ec98:	mov    %rsi,%rdx
 100ec9b:	not    %rdx
 100ec9e:	mulx   %rcx,%rdx,%rdx
 100eca3:	shr    $0x3,%rdx
 100eca7:	cmp    %rdx,%r15
 100ecaa:	ja     100eb82 <myl_native_budget_guard+0x32>
 100ecb0:	lea    (%r15,%r15,4),%rdx
 100ecb4:	lea    (%rsi,%rdx,2),%r15
 100ecb8:	movzbl (%rax),%r12d
 100ecbc:	lea    -0x30(%r12),%edx
 100ecc1:	inc    %rax
 100ecc4:	cmp    $0xa,%dl
 100ecc7:	jb     100ec90 <myl_native_budget_guard+0x140>
 100ecc9:	lea    -0xcfc1(%rip),%rdi        # 1001d0f <__abi_tag+0x1a13>
 100ecd0:	call   101f1d0 <unsetenv@plt>
 100ecd5:	lea    -0xd13c(%rip),%rdi        # 1001ba0 <__abi_tag+0x18a4>
 100ecdc:	call   101f1d0 <unsetenv@plt>
 100ece1:	test   %r12b,%r12b
 100ece4:	jne    100eb9a <myl_native_budget_guard+0x4a>
 100ecea:	lea    -0x30(%rbp),%rsi
 100ecee:	mov    $0x9,%edi
 100ecf3:	call   101f150 <getrlimit@plt>
 100ecf8:	test   %eax,%eax
 100ecfa:	jne    100eb9a <myl_native_budget_guard+0x4a>
 100ed00:	cmp    %r14,-0x30(%rbp)
 100ed04:	jne    100eb9a <myl_native_budget_guard+0x4a>
 100ed0a:	mov    -0x28(%rbp),%rcx
 100ed0e:	cmp    %rcx,%r15
 100ed11:	mov    %rcx,%rax
 100ed14:	cmovb  %r15,%rax
 100ed18:	cmp    $0xffffffffffffffff,%rcx
 100ed1c:	cmove  %r15,%rax
 100ed20:	cmp    %r14,%rax
 100ed23:	jbe    100eb9a <myl_native_budget_guard+0x4a>
 100ed29:	mov    %rax,-0x30(%rbp)
 100ed2d:	lea    -0x30(%rbp),%rsi
 100ed31:	mov    $0x9,%edi
 100ed36:	call   101f1e0 <setrlimit@plt>
 100ed3b:	jmp    100eb9a <myl_native_budget_guard+0x4a>

000000000100ed40 <myl_native_heap_init>:
 100ed40:	push   %rbp
 100ed41:	mov    %rsp,%rbp
 100ed44:	push   %r14
 100ed46:	push   %rbx
 100ed47:	mov    %rsi,%r14
 100ed4a:	mov    %rdi,%rbx
 100ed4d:	mov    $0x1718,%edx
 100ed52:	xor    %esi,%esi
 100ed54:	call   101e6b0 <compiler_rt.fastMemset>
 100ed59:	mov    %r14,0x58(%rbx)
 100ed5d:	movq   $0x1,0x38(%rbx)
 100ed65:	movq   $0x100000,0x60(%rbx)
 100ed6d:	mov    %rbx,%rdi
 100ed70:	call   101c800 <myl_rc_storage_init>
 100ed75:	test   %eax,%eax
 100ed77:	je     100ed83 <myl_native_heap_init+0x43>
 100ed79:	movl   $0x1,0x4f8(%rbx)
 100ed83:	pop    %rbx
 100ed84:	pop    %r14
 100ed86:	pop    %rbp
 100ed87:	ret
 100ed88:	int3
 100ed89:	int3
 100ed8a:	int3
 100ed8b:	int3
 100ed8c:	int3
 100ed8d:	int3
 100ed8e:	int3
 100ed8f:	int3

000000000100ed90 <myl_native_root_push>:
 100ed90:	push   %rbp
 100ed91:	mov    %rsp,%rbp
 100ed94:	mov    0x10(%rdi),%rax
 100ed98:	mov    %rax,(%rsi)
 100ed9b:	mov    %rdx,0x8(%rsi)
 100ed9f:	mov    %rcx,0x10(%rsi)
 100eda3:	mov    %rsi,0x10(%rdi)
 100eda7:	pop    %rbp
 100eda8:	ret
 100eda9:	int3
 100edaa:	int3
 100edab:	int3
 100edac:	int3
 100edad:	int3
 100edae:	int3
 100edaf:	int3

000000000100edb0 <myl_native_root_pop>:
 100edb0:	push   %rbp
 100edb1:	mov    %rsp,%rbp
 100edb4:	xor    %eax,%eax
 100edb6:	cmp    %rsi,0x10(%rdi)
 100edba:	je     100edbe <myl_native_root_pop+0xe>
 100edbc:	pop    %rbp
 100edbd:	ret
 100edbe:	mov    (%rsi),%rax
 100edc1:	mov    %rax,0x10(%rdi)
 100edc5:	mov    $0x1,%eax
 100edca:	pop    %rbp
 100edcb:	ret
 100edcc:	int3
 100edcd:	int3
 100edce:	int3
 100edcf:	int3

000000000100edd0 <flatten>:
 100edd0:	mov    0x58(%rsi),%r9d
 100edd4:	cmp    $0x1,%r9d
 100edd8:	jne    100ede0 <flatten+0x10>
 100edda:	mov    $0x1,%eax
 100eddf:	ret
 100ede0:	mov    $0xffffffff,%r10d
 100ede6:	sub    (%rsi),%r10
 100ede9:	xor    %eax,%eax
 100edeb:	cmp    %r10,%rdx
 100edee:	jbe    100edf1 <flatten+0x21>
 100edf0:	ret
 100edf1:	push   %rbp
 100edf2:	mov    %rsp,%rbp
 100edf5:	push   %r15
 100edf7:	push   %r14
 100edf9:	push   %r13
 100edfb:	push   %r12
 100edfd:	push   %rbx
 100edfe:	sub    $0x28,%rsp
 100ee02:	mov    %rcx,%r15
 100ee05:	shr    $0x20,%r15
 100ee09:	movzwl 0x30(%rsi),%r10d
 100ee0e:	cmp    $0x6,%r10d
 100ee12:	ja     100ee5a <flatten+0x8a>
 100ee14:	mov    $0x62,%r11d
 100ee1a:	bt     %r10d,%r11d
 100ee1e:	jae    100ee5a <flatten+0x8a>
 100ee20:	mov    0x10(%rdi),%rcx
 100ee24:	cmp    0x8(%rdi),%rcx
 100ee28:	je     100ee4b <flatten+0x7b>
 100ee2a:	mov    (%rdi),%rax
 100ee2d:	lea    0x1(%rcx),%rsi
 100ee31:	mov    %rsi,0x10(%rdi)
 100ee35:	lea    (%rcx,%rcx,2),%rcx
 100ee39:	mov    %edx,(%rax,%rcx,4)
 100ee3c:	mov    %r15d,0x4(%rax,%rcx,4)
 100ee41:	mov    %r8d,0x8(%rax,%rcx,4)
 100ee46:	mov    $0x1,%eax
 100ee4b:	add    $0x28,%rsp
 100ee4f:	pop    %rbx
 100ee50:	pop    %r12
 100ee52:	pop    %r13
 100ee54:	pop    %r14
 100ee56:	pop    %r15
 100ee58:	pop    %rbp
 100ee59:	ret
 100ee5a:	lea    0x10(%rsi),%r11
 100ee5e:	lea    0x48(%rsi),%rbx
 100ee62:	cmp    $0x2,%r9d
 100ee66:	cmove  %rbx,%r11
 100ee6a:	mov    (%r11),%rbx
 100ee6d:	cmp    $0x2,%r10d
 100ee71:	mov    %r8d,-0x2c(%rbp)
 100ee75:	mov    %rdx,-0x40(%rbp)
 100ee79:	mov    %rdi,%r13
 100ee7c:	mov    %rcx,%r14
 100ee7f:	mov    %rsi,-0x38(%rbp)
 100ee83:	je     100eedd <flatten+0x10d>
 100ee85:	cmp    $0x4,%r10d
 100ee89:	je     100eedd <flatten+0x10d>
 100ee8b:	cmp    $0x3,%r10d
 100ee8f:	jne    100ee46 <flatten+0x76>
 100ee91:	cmpq   $0x0,0x20(%rsi)
 100ee96:	je     100ee46 <flatten+0x76>
 100ee98:	xor    %r15d,%r15d
 100ee9b:	mov    0x8(%rbx),%rax
 100ee9f:	mov    0x28(%rsi),%r9
 100eea3:	imul   %r15,%r9
 100eea7:	add    %rdx,%r9
 100eeaa:	mov    %rax,%rsi
 100eead:	mov    %r9,%rdx
 100eeb0:	call   100edd0 <flatten>
 100eeb5:	test   %eax,%eax
 100eeb7:	je     100ef74 <flatten+0x1a4>
 100eebd:	inc    %r15
 100eec0:	mov    -0x38(%rbp),%rsi
 100eec4:	cmp    0x20(%rsi),%r15
 100eec8:	mov    -0x2c(%rbp),%r8d
 100eecc:	mov    -0x40(%rbp),%rdx
 100eed0:	mov    %r13,%rdi
 100eed3:	mov    %r14,%rcx
 100eed6:	jb     100ee9b <flatten+0xcb>
 100eed8:	jmp    100ee46 <flatten+0x76>
 100eedd:	lea    0x18(%rsi),%r11
 100eee1:	lea    0x50(%rsi),%r12
 100eee5:	cmp    $0x2,%r9d
 100eee9:	cmove  %r12,%r11
 100eeed:	cmp    $0x4,%r10d
 100eef1:	sete   %r9b
 100eef5:	mov    $0xffffffff,%r10d
 100eefb:	cmp    %r10,%r15
 100eefe:	setne  %r10b
 100ef02:	test   %r10b,%r9b
 100ef05:	jne    100ee4b <flatten+0x7b>
 100ef0b:	mov    (%r11),%r12
 100ef0e:	test   %r12,%r12
 100ef11:	je     100ee46 <flatten+0x76>
 100ef17:	mov    %edx,%eax
 100ef19:	mov    %rax,-0x48(%rbp)
 100ef1d:	add    $0x10,%rbx
 100ef21:	cmpw   $0x4,0x30(%rsi)
 100ef26:	mov    %r15,%r9
 100ef29:	jne    100ef34 <flatten+0x164>
 100ef2b:	mov    (%rbx),%r8d
 100ef2e:	xor    %ecx,%ecx
 100ef30:	mov    -0x48(%rbp),%r9
 100ef34:	mov    -0x8(%rbx),%rsi
 100ef38:	mov    -0x10(%rbx),%rax
 100ef3c:	add    %rdx,%rax
 100ef3f:	shl    $0x20,%r9
 100ef43:	mov    %ecx,%ecx
 100ef45:	or     %r9,%rcx
 100ef48:	mov    %rax,%rdx
 100ef4b:	call   100edd0 <flatten>
 100ef50:	test   %eax,%eax
 100ef52:	je     100ef74 <flatten+0x1a4>
 100ef54:	add    $0x18,%rbx
 100ef58:	dec    %r12
 100ef5b:	mov    -0x2c(%rbp),%r8d
 100ef5f:	mov    -0x40(%rbp),%rdx
 100ef63:	mov    %r13,%rdi
 100ef66:	mov    %r14,%rcx
 100ef69:	mov    -0x38(%rbp),%rsi
 100ef6d:	jne    100ef21 <flatten+0x151>
 100ef6f:	jmp    100ee46 <flatten+0x76>
 100ef74:	xor    %eax,%eax
 100ef76:	jmp    100ee4b <flatten+0x7b>
 100ef7b:	int3
 100ef7c:	int3
 100ef7d:	int3
 100ef7e:	int3
 100ef7f:	int3

000000000100ef80 <myl_native_heap_collect>:
 100ef80:	push   %rbp
 100ef81:	mov    %rsp,%rbp
 100ef84:	test   %rdi,%rdi
 100ef87:	je     100ef99 <myl_native_heap_collect+0x19>
 100ef89:	cmpq   $0x0,0x1608(%rdi)
 100ef91:	je     100ef99 <myl_native_heap_collect+0x19>
 100ef93:	pop    %rbp
 100ef94:	jmp    1016210 <myl_rc_drain>
 100ef99:	mov    $0x1,%esi
 100ef9e:	pop    %rbp
 100ef9f:	jmp    100efb0 <collect>
 100efa4:	int3
 100efa5:	int3
 100efa6:	int3
 100efa7:	int3
 100efa8:	int3
 100efa9:	int3
 100efaa:	int3
 100efab:	int3
 100efac:	int3
 100efad:	int3
 100efae:	int3
 100efaf:	int3

000000000100efb0 <collect>:
 100efb0:	cmpl   $0x0,0x74(%rdi)
 100efb4:	je     100efb7 <collect+0x7>
 100efb6:	ret
 100efb7:	push   %rbp
 100efb8:	mov    %rsp,%rbp
 100efbb:	push   %r15
 100efbd:	push   %r14
 100efbf:	push   %r13
 100efc1:	push   %r12
 100efc3:	push   %rbx
 100efc4:	and    $0xffffffffffffffe0,%rsp
 100efc8:	sub    $0x80,%rsp
 100efcf:	mov    %rdi,%rbx
 100efd2:	mov    0x1170(%rdi),%eax
 100efd8:	incq   0x50(%rdi)
 100efdc:	movq   $0x0,0x4e8(%rdi)
 100efe7:	movl   $0x0,0x4f8(%rdi)
 100eff1:	vpxor  %xmm0,%xmm0,%xmm0
 100eff5:	vmovdqu %ymm0,0x500(%rdi)
 100effd:	vmovdqu %ymm0,0x520(%rdi)
 100f005:	vmovdqu %ymm0,0x540(%rdi)
 100f00d:	vmovdqu %ymm0,0x560(%rdi)
 100f015:	vmovdqu %ymm0,0x580(%rdi)
 100f01d:	vmovdqu %ymm0,0x5a0(%rdi)
 100f025:	mov    $0x688,%ecx
 100f02a:	nopw   0x0(%rax,%rax,1)
 100f030:	vmovdqu %ymm0,-0xa8(%rbx,%rcx,1)
 100f039:	movq   $0x0,-0x88(%rbx,%rcx,1)
 100f045:	vmovdqu %ymm0,-0x70(%rbx,%rcx,1)
 100f04b:	movq   $0x0,-0x50(%rbx,%rcx,1)
 100f054:	vmovdqu %ymm0,-0x38(%rbx,%rcx,1)
 100f05a:	movq   $0x0,-0x18(%rbx,%rcx,1)
 100f063:	vmovdqu %ymm0,(%rbx,%rcx,1)
 100f068:	movq   $0x0,0x20(%rbx,%rcx,1)
 100f071:	add    $0xe0,%rcx
 100f078:	cmp    $0x11e8,%rcx
 100f07f:	jne    100f030 <collect+0x80>
 100f081:	test   %eax,%eax
 100f083:	mov    $0x1,%r15d
 100f089:	cmove  %esi,%r15d
 100f08d:	test   %r15d,%r15d
 100f090:	je     100f17e <collect+0x1ce>
 100f096:	mov    (%rbx),%r14
 100f099:	test   %r14,%r14
 100f09c:	jne    100f0cf <collect+0x11f>
 100f09e:	jmp    100f157 <collect+0x1a7>
 100f0a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f0b0:	lea    0x48(%r14),%rdi
 100f0b4:	mov    $0x400,%edx
 100f0b9:	xor    %esi,%esi
 100f0bb:	vzeroupper
 100f0be:	call   101e6b0 <compiler_rt.fastMemset>
 100f0c3:	mov    (%r14),%r14
 100f0c6:	test   %r14,%r14
 100f0c9:	je     100f157 <collect+0x1a7>
 100f0cf:	cmpq   $0x20,0x20(%r14)
 100f0d4:	jb     100f0b0 <collect+0x100>
 100f0d6:	mov    0x18(%r14),%rdx
 100f0da:	test   %rdx,%rdx
 100f0dd:	je     100f14b <collect+0x19b>
 100f0df:	mov    0x8(%r14),%rax
 100f0e3:	mov    %edx,%ecx
 100f0e5:	and    $0x3,%ecx
 100f0e8:	cmp    $0x4,%rdx
 100f0ec:	jae    100f0f2 <collect+0x142>
 100f0ee:	xor    %esi,%esi
 100f0f0:	jmp    100f131 <collect+0x181>
 100f0f2:	lea    0x470(%r14),%rdi
 100f0f9:	and    $0xfffffffffffffffc,%rdx
 100f0fd:	lea    (%rax,%rax,2),%r8
 100f101:	lea    0x0(,%rax,4),%r9
 100f109:	xor    %esi,%esi
 100f10b:	nopl   0x0(%rax,%rax,1)
 100f110:	andb   $0xfe,(%rdi)
 100f113:	andb   $0xfe,(%rdi,%rax,1)
 100f117:	andb   $0xfe,(%rdi,%rax,2)
 100f11b:	andb   $0xfe,(%rdi,%r8,1)
 100f120:	add    $0x4,%rsi
 100f124:	add    %r9,%rdi
 100f127:	cmp    %rsi,%rdx
 100f12a:	jne    100f110 <collect+0x160>
 100f12c:	test   %rcx,%rcx
 100f12f:	je     100f14b <collect+0x19b>
 100f131:	imul   %rax,%rsi
 100f135:	lea    (%r14,%rsi,1),%rdx
 100f139:	add    $0x470,%rdx
 100f140:	andb   $0xfe,(%rdx)
 100f143:	add    %rax,%rdx
 100f146:	dec    %rcx
 100f149:	jne    100f140 <collect+0x190>
 100f14b:	mov    (%r14),%r14
 100f14e:	test   %r14,%r14
 100f151:	jne    100f0cf <collect+0x11f>
 100f157:	movq   $0x0,0x1158(%rbx)
 100f162:	movq   $0x0,0x1140(%rbx)
 100f16d:	movl   $0x0,0x1170(%rbx)
 100f177:	mov    $0x1180,%eax
 100f17c:	jmp    100f183 <collect+0x1d3>
 100f17e:	mov    $0x1178,%eax
 100f183:	incq   (%rbx,%rax,1)
 100f187:	mov    %r15d,%eax
 100f18a:	xor    $0x1,%al
 100f18c:	mov    %al,0x1174(%rbx)
 100f192:	mov    0x10(%rbx),%r14
 100f196:	test   %r14,%r14
 100f199:	je     100f1bb <collect+0x20b>
 100f19b:	nopl   0x0(%rax,%rax,1)
 100f1a0:	mov    0x8(%r14),%rdx
 100f1a4:	mov    0x10(%r14),%rsi
 100f1a8:	mov    %rbx,%rdi
 100f1ab:	vzeroupper
 100f1ae:	call   100ff50 <trace>
 100f1b3:	mov    (%r14),%r14
 100f1b6:	test   %r14,%r14
 100f1b9:	jne    100f1a0 <collect+0x1f0>
 100f1bb:	mov    $0x1a,%r14d
 100f1c1:	jmp    100f1dc <collect+0x22c>
 100f1c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f1d0:	inc    %r14
 100f1d3:	cmp    $0x9a,%r14
 100f1da:	je     100f1f2 <collect+0x242>
 100f1dc:	mov    (%rbx,%r14,8),%rsi
 100f1e0:	test   %rsi,%rsi
 100f1e3:	je     100f1d0 <collect+0x220>
 100f1e5:	mov    %rbx,%rdi
 100f1e8:	vzeroupper
 100f1eb:	call   10101a0 <mark>
 100f1f0:	jmp    100f1d0 <collect+0x220>
 100f1f2:	cmpq   $0x0,(%rbx)
 100f1f6:	je     100f20a <collect+0x25a>
 100f1f8:	lea    0xd51(%rip),%rsi        # 100ff50 <trace>
 100f1ff:	mov    %rbx,%rdi
 100f202:	vzeroupper
 100f205:	call   1010e80 <myl_native_arena_trace>
 100f20a:	mov    %r15d,0x14(%rsp)
 100f20f:	test   %r15d,%r15d
 100f212:	jne    100f444 <collect+0x494>
 100f218:	movb   $0x2,0x1174(%rbx)
 100f21f:	mov    0x1140(%rbx),%rax
 100f226:	xor    %r14d,%r14d
 100f229:	test   %rax,%rax
 100f22c:	je     100f29f <collect+0x2ef>
 100f22e:	xor    %r15d,%r15d
 100f231:	jmp    100f248 <collect+0x298>
 100f233:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f240:	inc    %r15
 100f243:	cmp    %rax,%r15
 100f246:	jae    100f29f <collect+0x2ef>
 100f248:	mov    0x1138(%rbx),%rcx
 100f24f:	mov    (%rcx,%r15,8),%rsi
 100f253:	mov    (%rsi),%rdx
 100f256:	test   %rdx,%rdx
 100f259:	js     100f27f <collect+0x2cf>
 100f25b:	mov    %rsi,%rdx
 100f25e:	and    $0xffffffffffff0000,%rdx
 100f265:	mov    %esi,%edi
 100f267:	shr    $0x4,%edi
 100f26a:	mov    %esi,%r8d
 100f26d:	shr    $0x7,%r8d
 100f271:	and    $0x1f8,%r8d
 100f278:	shrx   %rdi,0x48(%rdx,%r8,1),%rdx
 100f27f:	test   $0x1,%dl
 100f282:	je     100f240 <collect+0x290>
 100f284:	mov    %rsi,(%rcx,%r14,8)
 100f288:	inc    %r14
 100f28b:	mov    %rbx,%rdi
 100f28e:	vzeroupper
 100f291:	call   10103f0 <scan_payload>
 100f296:	mov    0x1140(%rbx),%rax
 100f29d:	jmp    100f240 <collect+0x290>
 100f29f:	mov    %r14,0x1140(%rbx)
 100f2a6:	mov    (%rbx),%r14
 100f2a9:	jmp    100f2b3 <collect+0x303>
 100f2ab:	nopl   0x0(%rax,%rax,1)
 100f2b0:	mov    (%r14),%r14
 100f2b3:	test   %r14,%r14
 100f2b6:	je     100f2f7 <collect+0x347>
 100f2b8:	cmpq   $0x34,0x20(%r14)
 100f2bd:	jb     100f2b0 <collect+0x300>
 100f2bf:	testb  $0x1,0x470(%r14)
 100f2c7:	je     100f2b0 <collect+0x300>
 100f2c9:	mov    0x478(%r14),%rax
 100f2d0:	cmpw   $0x0,0x30(%rax)
 100f2d5:	je     100f2b0 <collect+0x300>
 100f2d7:	cmpl   $0x1,0x58(%rax)
 100f2db:	je     100f2b0 <collect+0x300>
 100f2dd:	cmpl   $0x0,0x5c(%rax)
 100f2e1:	jne    100f2b0 <collect+0x300>
 100f2e3:	lea    0x470(%r14),%rsi
 100f2ea:	mov    %rbx,%rdi
 100f2ed:	vzeroupper
 100f2f0:	call   10103f0 <scan_payload>
 100f2f5:	jmp    100f2b0 <collect+0x300>
 100f2f7:	mov    0x1158(%rbx),%rax
 100f2fe:	test   %rax,%rax
 100f301:	je     100f43d <collect+0x48d>
 100f307:	mov    0x1150(%rbx),%r8
 100f30e:	xor    %ecx,%ecx
 100f310:	xor    %edi,%edi
 100f312:	jmp    100f328 <collect+0x378>
 100f314:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f320:	inc    %rcx
 100f323:	cmp    %rcx,%rax
 100f326:	je     100f34c <collect+0x39c>
 100f328:	mov    (%r8,%rcx,8),%rdx
 100f32c:	cmpq   $0x0,0x8(%rdx)
 100f331:	je     100f320 <collect+0x370>
 100f333:	mov    (%rdx),%rsi
 100f336:	test   $0x1,%sil
 100f33a:	jne    100f320 <collect+0x370>
 100f33c:	or     $0x1,%rsi
 100f340:	mov    %rsi,(%rdx)
 100f343:	mov    %rdx,(%r8,%rdi,8)
 100f347:	inc    %rdi
 100f34a:	jmp    100f320 <collect+0x370>
 100f34c:	movq   $0x0,0x1158(%rbx)
 100f357:	test   %rdi,%rdi
 100f35a:	je     100f43d <collect+0x48d>
 100f360:	xor    %r13d,%r13d
 100f363:	jmp    100f387 <collect+0x3d7>
 100f365:	mov    0x1150(%rbx),%rax
 100f36c:	lea    0x1(%rcx),%rdx
 100f370:	mov    %rdx,0x1158(%rbx)
 100f377:	mov    %r14,(%rax,%rcx,8)
 100f37b:	inc    %r13
 100f37e:	cmp    %r13,%rdi
 100f381:	je     100f43d <collect+0x48d>
 100f387:	mov    (%r8,%r13,8),%r14
 100f38b:	cmpq   $0x0,0x8(%r14)
 100f390:	je     100f37b <collect+0x3cb>
 100f392:	movb   $0x0,0x1175(%rbx)
 100f399:	mov    %rdi,%r15
 100f39c:	mov    %rbx,%rdi
 100f39f:	mov    %r14,%rsi
 100f3a2:	mov    %r8,%r12
 100f3a5:	vzeroupper
 100f3a8:	call   10103f0 <scan_payload>
 100f3ad:	mov    %r12,%r8
 100f3b0:	mov    %r15,%rdi
 100f3b3:	cmpb   $0x0,0x1175(%rbx)
 100f3ba:	je     100f37b <collect+0x3cb>
 100f3bc:	mov    0x1158(%rbx),%rcx
 100f3c3:	cmp    0x1160(%rbx),%rcx
 100f3ca:	jne    100f365 <collect+0x3b5>
 100f3cc:	lea    (%rcx,%rcx,1),%rdx
 100f3d0:	test   %rcx,%rcx
 100f3d3:	mov    $0x100,%eax
 100f3d8:	cmove  %rax,%rdx
 100f3dc:	cmp    %rcx,%rdx
 100f3df:	setbe  %al
 100f3e2:	movabs $0x1fffffffffffffff,%rcx
 100f3ec:	cmp    %rcx,%rdx
 100f3ef:	seta   %cl
 100f3f2:	or     %al,%cl
 100f3f4:	jne    100f37b <collect+0x3cb>
 100f3f6:	mov    0x1150(%rbx),%rdi
 100f3fd:	lea    0x0(,%rdx,8),%rsi
 100f405:	mov    %rdx,0x20(%rsp)
 100f40a:	call   101f180 <realloc@plt>
 100f40f:	mov    0x20(%rsp),%rcx
 100f414:	mov    %r12,%r8
 100f417:	mov    %r15,%rdi
 100f41a:	test   %rax,%rax
 100f41d:	je     100f37b <collect+0x3cb>
 100f423:	mov    %rax,0x1150(%rbx)
 100f42a:	mov    %rcx,0x1160(%rbx)
 100f431:	mov    0x1158(%rbx),%rcx
 100f438:	jmp    100f36c <collect+0x3bc>
 100f43d:	movb   $0x1,0x1174(%rbx)
 100f444:	mov    0x4e8(%rbx),%rax
 100f44b:	test   %rax,%rax
 100f44e:	je     100f642 <collect+0x692>
 100f454:	mov    $0x3c,%r12d
 100f45a:	mov    $0x100,%r13d
 100f460:	jmp    100f480 <collect+0x4d0>
 100f462:	movl   $0x1,0x1170(%rbx)
 100f46c:	nopl   0x0(%rax)
 100f470:	mov    0x4e8(%rbx),%rax
 100f477:	test   %rax,%rax
 100f47a:	je     100f642 <collect+0x692>
 100f480:	mov    0x8(%rbx),%rcx
 100f484:	lea    -0x1(%rax),%rdx
 100f488:	mov    %rdx,0x4e8(%rbx)
 100f48f:	mov    -0x8(%rcx,%rax,8),%r14
 100f494:	movb   $0x0,0x1175(%rbx)
 100f49b:	mov    %rbx,%rdi
 100f49e:	mov    %r14,%rsi
 100f4a1:	vzeroupper
 100f4a4:	call   10103f0 <scan_payload>
 100f4a9:	mov    (%r14),%rax
 100f4ac:	test   $0x1,%al
 100f4ae:	je     100f470 <collect+0x4c0>
 100f4b0:	mov    0x8(%r14),%rcx
 100f4b4:	cmpw   $0x0,0x30(%rcx)
 100f4b9:	je     100f470 <collect+0x4c0>
 100f4bb:	cmpl   $0x1,0x58(%rcx)
 100f4bf:	je     100f470 <collect+0x4c0>
 100f4c1:	cmpl   $0x0,0x5c(%rcx)
 100f4c5:	je     100f541 <collect+0x591>
 100f4c7:	cmpb   $0x0,0x1175(%rbx)
 100f4ce:	je     100f470 <collect+0x4c0>
 100f4d0:	mov    0x1158(%rbx),%rcx
 100f4d7:	cmp    0x1160(%rbx),%rcx
 100f4de:	jne    100f56f <collect+0x5bf>
 100f4e4:	lea    (%rcx,%rcx,1),%r15
 100f4e8:	test   %rcx,%rcx
 100f4eb:	cmove  %r13,%r15
 100f4ef:	cmp    %rcx,%r15
 100f4f2:	setbe  %al
 100f4f5:	movabs $0x1fffffffffffffff,%rcx
 100f4ff:	cmp    %rcx,%r15
 100f502:	seta   %cl
 100f505:	or     %al,%cl
 100f507:	jne    100f462 <collect+0x4b2>
 100f50d:	mov    0x1150(%rbx),%rdi
 100f514:	lea    0x0(,%r15,8),%rsi
 100f51c:	call   101f180 <realloc@plt>
 100f521:	test   %rax,%rax
 100f524:	je     100f462 <collect+0x4b2>
 100f52a:	mov    %rax,0x1150(%rbx)
 100f531:	mov    %r15,0x1160(%rbx)
 100f538:	mov    0x1158(%rbx),%rcx
 100f53f:	jmp    100f576 <collect+0x5c6>
 100f541:	mov    (%rcx),%rcx
 100f544:	bzhi   %r12,%rax,%rsi
 100f549:	shr    $0x2,%rsi
 100f54d:	test   %rcx,%rcx
 100f550:	je     100f595 <collect+0x5e5>
 100f552:	cmp    $0x3fff0,%rcx
 100f559:	ja     100f58a <collect+0x5da>
 100f55b:	mov    $0x3fff0,%eax
 100f560:	xor    %edx,%edx
 100f562:	div    %ecx
 100f564:	cmp    %rax,%rsi
 100f567:	ja     100f470 <collect+0x4c0>
 100f56d:	jmp    100f595 <collect+0x5e5>
 100f56f:	mov    0x1150(%rbx),%rax
 100f576:	lea    0x1(%rcx),%rdx
 100f57a:	mov    %rdx,0x1158(%rbx)
 100f581:	mov    %r14,(%rax,%rcx,8)
 100f585:	jmp    100f470 <collect+0x4c0>
 100f58a:	xor    %eax,%eax
 100f58c:	cmp    %rax,%rsi
 100f58f:	ja     100f470 <collect+0x4c0>
 100f595:	imul   %rsi,%rcx
 100f599:	add    $0x1f,%rcx
 100f59d:	cmp    $0xf,%rcx
 100f5a1:	setae  %al
 100f5a4:	and    $0xfffffffffffffff0,%rcx
 100f5a8:	cmp    $0x40001,%rcx
 100f5af:	setae  %cl
 100f5b2:	test   %cl,%al
 100f5b4:	jne    100f470 <collect+0x4c0>
 100f5ba:	mov    0x1140(%rbx),%rcx
 100f5c1:	cmp    0x1148(%rbx),%rcx
 100f5c8:	jne    100f627 <collect+0x677>
 100f5ca:	lea    (%rcx,%rcx,1),%r15
 100f5ce:	test   %rcx,%rcx
 100f5d1:	cmove  %r13,%r15
 100f5d5:	cmp    %rcx,%r15
 100f5d8:	setbe  %al
 100f5db:	movabs $0x1fffffffffffffff,%rcx
 100f5e5:	cmp    %rcx,%r15
 100f5e8:	seta   %cl
 100f5eb:	or     %al,%cl
 100f5ed:	jne    100f462 <collect+0x4b2>
 100f5f3:	mov    0x1138(%rbx),%rdi
 100f5fa:	lea    0x0(,%r15,8),%rsi
 100f602:	call   101f180 <realloc@plt>
 100f607:	test   %rax,%rax
 100f60a:	je     100f462 <collect+0x4b2>
 100f610:	mov    %rax,0x1138(%rbx)
 100f617:	mov    %r15,0x1148(%rbx)
 100f61e:	mov    0x1140(%rbx),%rcx
 100f625:	jmp    100f62e <collect+0x67e>
 100f627:	mov    0x1138(%rbx),%rax
 100f62e:	lea    0x1(%rcx),%rdx
 100f632:	mov    %rdx,0x1140(%rbx)
 100f639:	mov    %r14,(%rax,%rcx,8)
 100f63d:	jmp    100f470 <collect+0x4c0>
 100f642:	movb   $0x0,0x1174(%rbx)
 100f649:	cmpl   $0x0,0x4f8(%rbx)
 100f650:	mov    (%rbx),%r14
 100f653:	jne    100fc36 <collect+0xc86>
 100f659:	test   %r14,%r14
 100f65c:	je     100fce1 <collect+0xd31>
 100f662:	xor    %r15d,%r15d
 100f665:	vpbroadcastb -0xc74e(%rip),%ymm12        # 1002f20 <on_timeout.message+0x70>
 100f66e:	vmovdqa -0xc776(%rip),%ymm13        # 1002f00 <on_timeout.message+0x50>
 100f676:	vpbroadcastq -0xc87f(%rip),%ymm14        # 1002e00 <qbe_empty_registry+0x58>
 100f67f:	vpxor  %xmm15,%xmm15,%xmm15
 100f684:	xor    %r11d,%r11d
 100f687:	xor    %r13d,%r13d
 100f68a:	mov    %rbx,%rdi
 100f68d:	mov    0x14(%rsp),%r12d
 100f692:	vmovdqa %ymm14,0x40(%rsp)
 100f698:	nopl   0x0(%rax,%rax,1)
 100f6a0:	mov    0x20(%r14),%rax
 100f6a4:	cmp    $0x34,%rax
 100f6a8:	jb     100f710 <collect+0x760>
 100f6aa:	testb  $0x1,0x470(%r14)
 100f6b2:	jne    100f7b0 <collect+0x800>
 100f6b8:	mov    (%r14),%rax
 100f6bb:	mov    %rax,(%rdi)
 100f6be:	mov    %r15,0x20(%rsp)
 100f6c3:	mov    %r12d,%r15d
 100f6c6:	mov    %rdi,%r12
 100f6c9:	mov    %r14,%rdi
 100f6cc:	mov    %r11,%r14
 100f6cf:	vzeroupper
 100f6d2:	call   101efd0 <free@plt>
 100f6d7:	vpxor  %xmm15,%xmm15,%xmm15
 100f6dc:	vmovdqa 0x40(%rsp),%ymm14
 100f6e2:	vmovdqa -0xc7ea(%rip),%ymm13        # 1002f00 <on_timeout.message+0x50>
 100f6ea:	vpbroadcastb -0xc7d3(%rip),%ymm12        # 1002f20 <on_timeout.message+0x70>
 100f6f3:	mov    %r14,%r11
 100f6f6:	mov    %r12,%r14
 100f6f9:	mov    %r15d,%r12d
 100f6fc:	mov    0x20(%rsp),%r15
 100f701:	jmp    100fbae <collect+0xbfe>
 100f706:	cs nopw 0x0(%rax,%rax,1)
 100f710:	test   %r12d,%r12d
 100f713:	mov    %rax,0x38(%rsp)
 100f718:	jne    100f725 <collect+0x775>
 100f71a:	cmpb   $0x0,0x40(%r14)
 100f71f:	je     100f8de <collect+0x92e>
 100f725:	mov    %r13,0x18(%rsp)
 100f72a:	lea    0x470(%r14),%r13
 100f731:	mov    0x8(%r14),%rcx
 100f735:	mov    0x18(%r14),%r9
 100f739:	imul   %rcx,%r9
 100f73d:	lea    (%r14,%r9,1),%r8
 100f741:	add    $0x470,%r8
 100f748:	cmp    $0x20,%rax
 100f74c:	jb     100f7c0 <collect+0x810>
 100f74e:	test   %r9,%r9
 100f751:	je     100f8d3 <collect+0x923>
 100f757:	mov    %r13,%r9
 100f75a:	xor    %edx,%edx
 100f75c:	xor    %r10d,%r10d
 100f75f:	xor    %esi,%esi
 100f761:	jmp    100f789 <collect+0x7d9>
 100f763:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f770:	mov    %r10,%r13
 100f773:	mov    %r13,%r10
 100f776:	lea    (%r9,%rcx,1),%r13
 100f77a:	inc    %rdx
 100f77d:	add    %rcx,%r9
 100f780:	cmp    %r8,%r9
 100f783:	jae    100f89b <collect+0x8eb>
 100f789:	testb  $0x1,(%r9)
 100f78d:	je     100f77d <collect+0x7cd>
 100f78f:	cmp    %r9,%r13
 100f792:	jae    100f770 <collect+0x7c0>
 100f794:	mov    %r9,0x0(%r13)
 100f798:	movq   $0x0,0x8(%r13)
 100f7a0:	test   %r10,%r10
 100f7a3:	je     100f7ab <collect+0x7fb>
 100f7a5:	mov    %r13,0x8(%r10)
 100f7a9:	jmp    100f773 <collect+0x7c3>
 100f7ab:	mov    %r13,%rsi
 100f7ae:	jmp    100f773 <collect+0x7c3>
 100f7b0:	add    0x8(%r14),%r15
 100f7b4:	inc    %r11
 100f7b7:	jmp    100fbae <collect+0xbfe>
 100f7bc:	nopl   0x0(%rax)
 100f7c0:	mov    %rdi,0x30(%rsp)
 100f7c5:	mov    %r11,0x28(%rsp)
 100f7ca:	mov    %r15,0x20(%rsp)
 100f7cf:	add    $0x470,%r9
 100f7d6:	shr    $0x4,%r9
 100f7da:	lea    0x3f(%r9),%r10
 100f7de:	shr    $0x6,%r10
 100f7e2:	mov    $0x1,%r12d
 100f7e8:	xor    %esi,%esi
 100f7ea:	xor    %eax,%eax
 100f7ec:	xor    %edx,%edx
 100f7ee:	jmp    100f7f8 <collect+0x848>
 100f7f0:	inc    %r12
 100f7f3:	cmp    %r10,%r12
 100f7f6:	je     100f870 <collect+0x8c0>
 100f7f8:	mov    0x48(%r14,%r12,8),%r15
 100f7fd:	test   %r15,%r15
 100f800:	je     100f7f0 <collect+0x840>
 100f802:	mov    %r12,%r11
 100f805:	shl    $0x6,%r11
 100f809:	jmp    100f826 <collect+0x876>
 100f80b:	nopl   0x0(%rax,%rax,1)
 100f810:	mov    %rax,%r13
 100f813:	add    %rcx,%rdi
 100f816:	inc    %rdx
 100f819:	mov    %r13,%rax
 100f81c:	mov    %rdi,%r13
 100f81f:	blsr   %r15,%r15
 100f824:	je     100f7f0 <collect+0x840>
 100f826:	tzcnt  %r15,%rdi
 100f82b:	or     %r11,%rdi
 100f82e:	cmp    $0x47,%rdi
 100f832:	jb     100f81f <collect+0x86f>
 100f834:	cmp    %r9,%rdi
 100f837:	jae    100f81f <collect+0x86f>
 100f839:	shl    $0x4,%rdi
 100f83d:	add    %r14,%rdi
 100f840:	cmp    %rdi,%r13
 100f843:	jae    100f810 <collect+0x860>
 100f845:	mov    %rdi,0x0(%r13)
 100f849:	movq   $0x0,0x8(%r13)
 100f851:	test   %rax,%rax
 100f854:	je     100f85c <collect+0x8ac>
 100f856:	mov    %r13,0x8(%rax)
 100f85a:	jmp    100f813 <collect+0x863>
 100f85c:	mov    %r13,%rsi
 100f85f:	jmp    100f813 <collect+0x863>
 100f861:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f870:	cmp    %r8,%r13
 100f873:	jae    100f8c2 <collect+0x912>
 100f875:	mov    %r8,0x0(%r13)
 100f879:	movq   $0x0,0x8(%r13)
 100f881:	test   %rax,%rax
 100f884:	mov    0x14(%rsp),%r12d
 100f889:	mov    0x20(%rsp),%r15
 100f88e:	mov    0x28(%rsp),%r11
 100f893:	je     100f8f0 <collect+0x940>
 100f895:	mov    %r13,0x8(%rax)
 100f899:	jmp    100f900 <collect+0x950>
 100f89b:	cmp    %r8,%r13
 100f89e:	jae    100fa8b <collect+0xadb>
 100f8a4:	mov    %r8,0x0(%r13)
 100f8a8:	movq   $0x0,0x8(%r13)
 100f8b0:	test   %r10,%r10
 100f8b3:	je     100fa88 <collect+0xad8>
 100f8b9:	mov    %r13,0x8(%r10)
 100f8bd:	jmp    100fa8b <collect+0xadb>
 100f8c2:	mov    0x14(%rsp),%r12d
 100f8c7:	mov    0x20(%rsp),%r15
 100f8cc:	mov    0x28(%rsp),%r11
 100f8d1:	jmp    100f900 <collect+0x950>
 100f8d3:	xor    %esi,%esi
 100f8d5:	xor    %eax,%eax
 100f8d7:	xor    %edx,%edx
 100f8d9:	jmp    100fa8d <collect+0xadd>
 100f8de:	mov    0x30(%r14),%rdx
 100f8e2:	test   %rdx,%rdx
 100f8e5:	jne    100fb73 <collect+0xbc3>
 100f8eb:	jmp    100fab2 <collect+0xb02>
 100f8f0:	mov    %r13,%rsi
 100f8f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 100f900:	vpxor  %xmm0,%xmm0,%xmm0
 100f904:	mov    $0xfffffffffffffe00,%rdi
 100f90b:	vpxor  %xmm1,%xmm1,%xmm1
 100f90f:	vpxor  %xmm2,%xmm2,%xmm2
 100f913:	vpxor  %xmm3,%xmm3,%xmm3
 100f917:	mov    0x18(%rsp),%r13
 100f91c:	nopl   0x0(%rax)
 100f920:	vmovdqu 0x248(%r14,%rdi,1),%ymm5
 100f92a:	vmovdqu 0x268(%r14,%rdi,1),%ymm6
 100f934:	vmovdqu 0x288(%r14,%rdi,1),%ymm7
 100f93e:	vpand  0x448(%r14,%rdi,1),%ymm5,%ymm8
 100f948:	vpand  0x468(%r14,%rdi,1),%ymm6,%ymm9
 100f952:	vpand  0x488(%r14,%rdi,1),%ymm7,%ymm10
 100f95c:	vmovdqu 0x2a8(%r14,%rdi,1),%ymm11
 100f966:	vpand  0x4a8(%r14,%rdi,1),%ymm11,%ymm4
 100f970:	vmovdqu %ymm8,0x448(%r14,%rdi,1)
 100f97a:	vmovdqu %ymm9,0x468(%r14,%rdi,1)
 100f984:	vmovdqu %ymm10,0x488(%r14,%rdi,1)
 100f98e:	vmovdqu %ymm4,0x4a8(%r14,%rdi,1)
 100f998:	vpxor  %ymm5,%ymm8,%ymm5
 100f99c:	vpxor  %ymm6,%ymm9,%ymm6
 100f9a0:	vpxor  %ymm7,%ymm10,%ymm7
 100f9a4:	vpxor  %ymm4,%ymm11,%ymm11
 100f9a8:	vmovdqu %ymm5,0x248(%r14,%rdi,1)
 100f9b2:	vmovdqu %ymm6,0x268(%r14,%rdi,1)
 100f9bc:	vmovdqu %ymm7,0x288(%r14,%rdi,1)
 100f9c6:	vmovdqu %ymm11,0x2a8(%r14,%rdi,1)
 100f9d0:	vpand  %ymm12,%ymm8,%ymm5
 100f9d5:	vpshufb %ymm5,%ymm13,%ymm5
 100f9da:	vgf2p8affineqb $0x0,%ymm14,%ymm8,%ymm6
 100f9e0:	vpshufb %ymm6,%ymm13,%ymm6
 100f9e5:	vpaddb %ymm5,%ymm6,%ymm5
 100f9e9:	vpsadbw %ymm5,%ymm15,%ymm5
 100f9ed:	vpaddq %ymm0,%ymm5,%ymm0
 100f9f1:	vpand  %ymm12,%ymm9,%ymm5
 100f9f6:	vpshufb %ymm5,%ymm13,%ymm5
 100f9fb:	vgf2p8affineqb $0x0,%ymm14,%ymm9,%ymm6
 100fa01:	vpshufb %ymm6,%ymm13,%ymm6
 100fa06:	vpaddb %ymm5,%ymm6,%ymm5
 100fa0a:	vpsadbw %ymm5,%ymm15,%ymm5
 100fa0e:	vpaddq %ymm1,%ymm5,%ymm1
 100fa12:	vpand  %ymm12,%ymm10,%ymm5
 100fa17:	vpshufb %ymm5,%ymm13,%ymm5
 100fa1c:	vgf2p8affineqb $0x0,%ymm14,%ymm10,%ymm6
 100fa22:	vpshufb %ymm6,%ymm13,%ymm6
 100fa27:	vpaddb %ymm5,%ymm6,%ymm5
 100fa2b:	vpsadbw %ymm5,%ymm15,%ymm5
 100fa2f:	vpaddq %ymm2,%ymm5,%ymm2
 100fa33:	vpand  %ymm4,%ymm12,%ymm5
 100fa37:	vpshufb %ymm5,%ymm13,%ymm5
 100fa3c:	vgf2p8affineqb $0x0,%ymm14,%ymm4,%ymm4
 100fa42:	vpshufb %ymm4,%ymm13,%ymm4
 100fa47:	vpaddb %ymm5,%ymm4,%ymm4
 100fa4b:	vpsadbw %ymm4,%ymm15,%ymm4
 100fa4f:	vpaddq %ymm3,%ymm4,%ymm3
 100fa53:	sub    $0xffffffffffffff80,%rdi
 100fa57:	jne    100f920 <collect+0x970>
 100fa5d:	vpaddq %ymm0,%ymm1,%ymm0
 100fa61:	vpaddq %ymm0,%ymm2,%ymm0
 100fa65:	vpaddq %ymm0,%ymm3,%ymm0
 100fa69:	vextracti128 $0x1,%ymm0,%xmm1
 100fa6f:	vpaddq %xmm1,%xmm0,%xmm0
 100fa73:	vpshufd $0xee,%xmm0,%xmm1
 100fa78:	vpaddq %xmm1,%xmm0,%xmm0
 100fa7c:	vmovq  %xmm0,%rax
 100fa81:	mov    0x30(%rsp),%rdi
 100fa86:	jmp    100fa92 <collect+0xae2>
 100fa88:	mov    %r13,%rsi
 100fa8b:	xor    %eax,%eax
 100fa8d:	mov    0x18(%rsp),%r13
 100fa92:	mov    %rsi,0x28(%r14)
 100fa96:	mov    %rdx,0x30(%r14)
 100fa9a:	test   %rax,%rax
 100fa9d:	setne  0x40(%r14)
 100faa2:	imul   %rax,%rcx
 100faa6:	add    %rcx,%r13
 100faa9:	test   %rdx,%rdx
 100faac:	jne    100fb73 <collect+0xbc3>
 100fab2:	mov    0x38(%rsp),%rax
 100fab7:	cmp    $0x1f,%rax
 100fabb:	ja     100fb71 <collect+0xbc1>
 100fac1:	imul   $0x38,%rax,%rax
 100fac5:	lea    0x5d8(%rbx),%rcx
 100facc:	cmp    %r14,(%rcx,%rax,1)
 100fad0:	je     100fb71 <collect+0xbc1>
 100fad6:	mov    0x11d8(%rbx),%rcx
 100fadd:	cmp    0x11e0(%rbx),%rcx
 100fae4:	jne    100fbc5 <collect+0xc15>
 100faea:	mov    %rdi,0x30(%rsp)
 100faef:	mov    %r11,0x28(%rsp)
 100faf4:	mov    %r13,0x18(%rsp)
 100faf9:	mov    %r15,%r13
 100fafc:	lea    (%rcx,%rcx,1),%r15
 100fb00:	test   %rcx,%rcx
 100fb03:	mov    $0x40,%eax
 100fb08:	cmove  %rax,%r15
 100fb0c:	mov    0x11d0(%rbx),%rdi
 100fb13:	lea    0x0(,%r15,8),%rsi
 100fb1b:	vzeroupper
 100fb1e:	call   101f180 <realloc@plt>
 100fb23:	test   %rax,%rax
 100fb26:	je     100fbe3 <collect+0xc33>
 100fb2c:	mov    %rax,0x11d0(%rbx)
 100fb33:	mov    %r15,0x11e0(%rbx)
 100fb3a:	mov    0x11d8(%rbx),%rcx
 100fb41:	mov    %r13,%r15
 100fb44:	mov    0x18(%rsp),%r13
 100fb49:	mov    0x28(%rsp),%r11
 100fb4e:	vpbroadcastb -0xcc37(%rip),%ymm12        # 1002f20 <on_timeout.message+0x70>
 100fb57:	vmovdqa -0xcc5f(%rip),%ymm13        # 1002f00 <on_timeout.message+0x50>
 100fb5f:	vmovdqa 0x40(%rsp),%ymm14
 100fb65:	vpxor  %xmm15,%xmm15,%xmm15
 100fb6a:	mov    0x30(%rsp),%rdi
 100fb6f:	jmp    100fbcc <collect+0xc1c>
 100fb71:	xor    %edx,%edx
 100fb73:	mov    0x8(%r14),%rax
 100fb77:	imul   %rdx,%rax
 100fb7b:	add    %rax,%r15
 100fb7e:	add    %rdx,%r11
 100fb81:	movq   $0x0,0x38(%r14)
 100fb89:	cmpq   $0x0,0x28(%r14)
 100fb8e:	setne  0x41(%r14)
 100fb93:	je     100fbae <collect+0xbfe>
 100fb95:	imul   $0x38,0x20(%r14),%rax
 100fb9a:	mov    0x5e8(%rbx,%rax,1),%rcx
 100fba2:	mov    %rcx,0x38(%r14)
 100fba6:	mov    %r14,0x5e8(%rbx,%rax,1)
 100fbae:	mov    (%r14),%rax
 100fbb1:	mov    %r14,%rdi
 100fbb4:	mov    %rax,%r14
 100fbb7:	test   %rax,%rax
 100fbba:	jne    100f6a0 <collect+0x6f0>
 100fbc0:	jmp    100fcef <collect+0xd3f>
 100fbc5:	mov    0x11d0(%rbx),%rax
 100fbcc:	lea    0x1(%rcx),%rdx
 100fbd0:	mov    %rdx,0x11d8(%rbx)
 100fbd7:	mov    %r14,(%rax,%rcx,8)
 100fbdb:	mov    (%r14),%rax
 100fbde:	mov    %rax,(%rdi)
 100fbe1:	jmp    100fbb4 <collect+0xc04>
 100fbe3:	mov    0x30(%r14),%rdx
 100fbe7:	mov    %r13,%r15
 100fbea:	mov    0x18(%rsp),%r13
 100fbef:	mov    0x28(%rsp),%r11
 100fbf4:	vpbroadcastb -0xccdd(%rip),%ymm12        # 1002f20 <on_timeout.message+0x70>
 100fbfd:	vmovdqa -0xcd05(%rip),%ymm13        # 1002f00 <on_timeout.message+0x50>
 100fc05:	vmovdqa 0x40(%rsp),%ymm14
 100fc0b:	vpxor  %xmm15,%xmm15,%xmm15
 100fc10:	jmp    100fb73 <collect+0xbc3>
 100fc15:	data16 cs nopw 0x0(%rax,%rax,1)
 100fc20:	lea    0x48(%r14),%rdi
 100fc24:	mov    $0x400,%edx
 100fc29:	xor    %esi,%esi
 100fc2b:	vzeroupper
 100fc2e:	call   101e6b0 <compiler_rt.fastMemset>
 100fc33:	mov    (%r14),%r14
 100fc36:	test   %r14,%r14
 100fc39:	je     100fcc7 <collect+0xd17>
 100fc3f:	cmpq   $0x20,0x20(%r14)
 100fc44:	jb     100fc20 <collect+0xc70>
 100fc46:	mov    0x18(%r14),%rdx
 100fc4a:	test   %rdx,%rdx
 100fc4d:	je     100fcbb <collect+0xd0b>
 100fc4f:	mov    0x8(%r14),%rax
 100fc53:	mov    %edx,%ecx
 100fc55:	and    $0x3,%ecx
 100fc58:	cmp    $0x4,%rdx
 100fc5c:	jae    100fc62 <collect+0xcb2>
 100fc5e:	xor    %esi,%esi
 100fc60:	jmp    100fca1 <collect+0xcf1>
 100fc62:	lea    0x470(%r14),%rdi
 100fc69:	and    $0xfffffffffffffffc,%rdx
 100fc6d:	lea    (%rax,%rax,2),%r8
 100fc71:	lea    0x0(,%rax,4),%r9
 100fc79:	xor    %esi,%esi
 100fc7b:	nopl   0x0(%rax,%rax,1)
 100fc80:	andb   $0xfe,(%rdi)
 100fc83:	andb   $0xfe,(%rdi,%rax,1)
 100fc87:	andb   $0xfe,(%rdi,%rax,2)
 100fc8b:	andb   $0xfe,(%rdi,%r8,1)
 100fc90:	add    $0x4,%rsi
 100fc94:	add    %r9,%rdi
 100fc97:	cmp    %rsi,%rdx
 100fc9a:	jne    100fc80 <collect+0xcd0>
 100fc9c:	test   %rcx,%rcx
 100fc9f:	je     100fcbb <collect+0xd0b>
 100fca1:	imul   %rax,%rsi
 100fca5:	lea    (%r14,%rsi,1),%rdx
 100fca9:	add    $0x470,%rdx
 100fcb0:	andb   $0xfe,(%rdx)
 100fcb3:	add    %rax,%rdx
 100fcb6:	dec    %rcx
 100fcb9:	jne    100fcb0 <collect+0xd00>
 100fcbb:	mov    (%r14),%r14
 100fcbe:	test   %r14,%r14
 100fcc1:	jne    100fc3f <collect+0xc8f>
 100fcc7:	movq   $0x0,0x4e8(%rbx)
 100fcd2:	movl   $0x1,0x1170(%rbx)
 100fcdc:	jmp    100fdf3 <collect+0xe43>
 100fce1:	xor    %r13d,%r13d
 100fce4:	xor    %r11d,%r11d
 100fce7:	xor    %r15d,%r15d
 100fcea:	mov    0x14(%rsp),%r12d
 100fcef:	mov    0xb0(%rbx),%rax
 100fcf6:	add    %r15,%rax
 100fcf9:	mov    %rax,0x18(%rbx)
 100fcfd:	mov    0x40(%rbx),%rax
 100fd01:	add    %r11,%rax
 100fd04:	sub    0x1198(%rbx),%rax
 100fd0b:	mov    %rax,0x40(%rbx)
 100fd0f:	mov    %r11,0x1198(%rbx)
 100fd16:	mov    %r13,0x1190(%rbx)
 100fd1d:	mov    0x1158(%rbx),%rdx
 100fd24:	test   %rdx,%rdx
 100fd27:	je     100fda0 <collect+0xdf0>
 100fd29:	mov    0x1150(%rbx),%rcx
 100fd30:	mov    %edx,%eax
 100fd32:	and    $0x3,%eax
 100fd35:	cmp    $0x4,%rdx
 100fd39:	jae    100fd3f <collect+0xd8f>
 100fd3b:	xor    %esi,%esi
 100fd3d:	jmp    100fd81 <collect+0xdd1>
 100fd3f:	and    $0xfffffffffffffffc,%rdx
 100fd43:	xor    %esi,%esi
 100fd45:	data16 cs nopw 0x0(%rax,%rax,1)
 100fd50:	mov    (%rcx,%rsi,8),%rdi
 100fd54:	andq   $0xfffffffffffffffe,(%rdi)
 100fd58:	mov    0x8(%rcx,%rsi,8),%rdi
 100fd5d:	andq   $0xfffffffffffffffe,(%rdi)
 100fd61:	mov    0x10(%rcx,%rsi,8),%rdi
 100fd66:	andq   $0xfffffffffffffffe,(%rdi)
 100fd6a:	mov    0x18(%rcx,%rsi,8),%rdi
 100fd6f:	andq   $0xfffffffffffffffe,(%rdi)
 100fd73:	add    $0x4,%rsi
 100fd77:	cmp    %rsi,%rdx
 100fd7a:	jne    100fd50 <collect+0xda0>
 100fd7c:	test   %rax,%rax
 100fd7f:	je     100fda0 <collect+0xdf0>
 100fd81:	lea    (%rcx,%rsi,8),%rcx
 100fd85:	xor    %edx,%edx
 100fd87:	nopw   0x0(%rax,%rax,1)
 100fd90:	mov    (%rcx,%rdx,8),%rsi
 100fd94:	andq   $0xfffffffffffffffe,(%rsi)
 100fd98:	inc    %rdx
 100fd9b:	cmp    %rdx,%rax
 100fd9e:	jne    100fd90 <collect+0xde0>
 100fda0:	mov    %r15,%rax
 100fda3:	shr    $1,%rax
 100fda6:	cmp    $0x400001,%rax
 100fdac:	mov    $0x400000,%ecx
 100fdb1:	cmovae %rax,%rcx
 100fdb5:	add    %r15,%rcx
 100fdb8:	mov    $0xffffffffffffffff,%rax
 100fdbf:	cmovb  %rax,%rcx
 100fdc3:	mov    %r15,%rdx
 100fdc6:	sub    %r13,%rdx
 100fdc9:	mov    %rcx,0x60(%rbx)
 100fdcd:	mov    %rdx,0x1188(%rbx)
 100fdd4:	test   %r12d,%r12d
 100fdd7:	je     100fdf3 <collect+0xe43>
 100fdd9:	test   %r15,%r15
 100fddc:	js     100fdec <collect+0xe3c>
 100fdde:	add    %r15,%r15
 100fde1:	add    $0x400000,%r15
 100fde8:	cmovae %r15,%rax
 100fdec:	mov    %rax,0x1168(%rbx)
 100fdf3:	lea    -0x28(%rbp),%rsp
 100fdf7:	pop    %rbx
 100fdf8:	pop    %r12
 100fdfa:	pop    %r13
 100fdfc:	pop    %r14
 100fdfe:	pop    %r15
 100fe00:	pop    %rbp
 100fe01:	vzeroupper
 100fe04:	ret
 100fe05:	int3
 100fe06:	int3
 100fe07:	int3
 100fe08:	int3
 100fe09:	int3
 100fe0a:	int3
 100fe0b:	int3
 100fe0c:	int3
 100fe0d:	int3
 100fe0e:	int3
 100fe0f:	int3

000000000100fe10 <myl_native_heap_alloc>:
 100fe10:	push   %rbp
 100fe11:	mov    %rsp,%rbp
 100fe14:	cmpq   $0x0,0x1608(%rdi)
 100fe1c:	je     100fe27 <myl_native_heap_alloc+0x17>
 100fe1e:	mov    0x70(%rdi),%ecx
 100fe21:	pop    %rbp
 100fe22:	jmp    101be60 <myl_rc_storage_alloc>
 100fe27:	xor    %eax,%eax
 100fe29:	pop    %rbp
 100fe2a:	ret
 100fe2b:	int3
 100fe2c:	int3
 100fe2d:	int3
 100fe2e:	int3
 100fe2f:	int3

000000000100fe30 <myl_native_heap_destroy>:
 100fe30:	push   %rbp
 100fe31:	mov    %rsp,%rbp
 100fe34:	push   %r14
 100fe36:	push   %rbx
 100fe37:	mov    %rdi,%rbx
 100fe3a:	call   10115c0 <myl_native_arena_destroy>
 100fe3f:	test   %rbx,%rbx
 100fe42:	je     100fe80 <myl_native_heap_destroy+0x50>
 100fe44:	cmpq   $0x0,0x1608(%rbx)
 100fe4c:	je     100fe80 <myl_native_heap_destroy+0x50>
 100fe4e:	mov    $0x1a,%r14d
 100fe54:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 100fe60:	mov    (%rbx,%r14,8),%rsi
 100fe64:	mov    %rbx,%rdi
 100fe67:	call   1012cd0 <myl_rc_owner_release>
 100fe6c:	inc    %r14
 100fe6f:	cmp    $0x9a,%r14
 100fe76:	jne    100fe60 <myl_native_heap_destroy+0x30>
 100fe78:	mov    %rbx,%rdi
 100fe7b:	call   10128a0 <myl_rc_heap_destroy>
 100fe80:	mov    (%rbx),%rdi
 100fe83:	test   %rdi,%rdi
 100fe86:	jne    100ff2c <myl_native_heap_destroy+0xfc>
 100fe8c:	cmpq   $0x0,0x11c0(%rbx)
 100fe94:	je     100fec1 <myl_native_heap_destroy+0x91>
 100fe96:	xor    %r14d,%r14d
 100fe99:	nopl   0x0(%rax)
 100fea0:	mov    0x11b8(%rbx),%rax
 100fea7:	mov    (%rax,%r14,8),%rdi
 100feab:	mov    $0x200000,%esi
 100feb0:	call   101f140 <munmap@plt>
 100feb5:	inc    %r14
 100feb8:	cmp    0x11c0(%rbx),%r14
 100febf:	jb     100fea0 <myl_native_heap_destroy+0x70>
 100fec1:	mov    0x11f8(%rbx),%rdi
 100fec8:	call   101efd0 <free@plt>
 100fecd:	mov    0x11b8(%rbx),%rdi
 100fed4:	call   101efd0 <free@plt>
 100fed9:	mov    0x11d0(%rbx),%rdi
 100fee0:	call   101efd0 <free@plt>
 100fee5:	mov    0x8(%rbx),%rdi
 100fee9:	call   101efd0 <free@plt>
 100feee:	mov    0x1138(%rbx),%rdi
 100fef5:	call   101efd0 <free@plt>
 100fefa:	mov    0x1150(%rbx),%rdi
 100ff01:	call   101efd0 <free@plt>
 100ff06:	mov    $0x1718,%edx
 100ff0b:	mov    %rbx,%rdi
 100ff0e:	xor    %esi,%esi
 100ff10:	pop    %rbx
 100ff11:	pop    %r14
 100ff13:	pop    %rbp
 100ff14:	jmp    101e6b0 <compiler_rt.fastMemset>
 100ff19:	nopl   0x0(%rax)
 100ff20:	mov    %rax,%rdi
 100ff23:	test   %rax,%rax
 100ff26:	je     100fe8c <myl_native_heap_destroy+0x5c>
 100ff2c:	mov    (%rdi),%rax
 100ff2f:	mov    %rax,(%rbx)
 100ff32:	cmpq   $0x20,0x20(%rdi)
 100ff37:	jb     100ff20 <myl_native_heap_destroy+0xf0>
 100ff39:	call   101efd0 <free@plt>
 100ff3e:	mov    (%rbx),%rax
 100ff41:	jmp    100ff20 <myl_native_heap_destroy+0xf0>
 100ff43:	int3
 100ff44:	int3
 100ff45:	int3
 100ff46:	int3
 100ff47:	int3
 100ff48:	int3
 100ff49:	int3
 100ff4a:	int3
 100ff4b:	int3
 100ff4c:	int3
 100ff4d:	int3
 100ff4e:	int3
 100ff4f:	int3

000000000100ff50 <trace>:
 100ff50:	push   %rbp
 100ff51:	mov    %rsp,%rbp
 100ff54:	push   %r15
 100ff56:	push   %r14
 100ff58:	push   %r13
 100ff5a:	push   %r12
 100ff5c:	push   %rbx
 100ff5d:	sub    $0x88,%rsp
 100ff64:	mov    0x58(%rsi),%eax
 100ff67:	cmp    $0x1,%eax
 100ff6a:	jne    100ff7e <trace+0x2e>
 100ff6c:	add    $0x88,%rsp
 100ff73:	pop    %rbx
 100ff74:	pop    %r12
 100ff76:	pop    %r13
 100ff78:	pop    %r14
 100ff7a:	pop    %r15
 100ff7c:	pop    %rbp
 100ff7d:	ret
 100ff7e:	mov    %rdx,%rbx
 100ff81:	mov    %rsi,%r15
 100ff84:	mov    %rdi,%r14
 100ff87:	movzwl 0x30(%rsi),%ecx
 100ff8b:	cmp    $0x6,%ecx
 100ff8e:	ja     100ffb6 <trace+0x66>
 100ff90:	mov    $0x62,%edx
 100ff95:	bt     %ecx,%edx
 100ff98:	jae    100ffb6 <trace+0x66>
 100ff9a:	mov    (%rbx),%rsi
 100ff9d:	mov    %r14,%rdi
 100ffa0:	add    $0x88,%rsp
 100ffa7:	pop    %rbx
 100ffa8:	pop    %r12
 100ffaa:	pop    %r13
 100ffac:	pop    %r14
 100ffae:	pop    %r15
 100ffb0:	pop    %rbp
 100ffb1:	jmp    10101a0 <mark>
 100ffb6:	mov    0x60(%r15),%r12
 100ffba:	test   %r12,%r12
 100ffbd:	je     1010064 <trace+0x114>
 100ffc3:	cmpl   $0x0,0x68(%r14)
 100ffc8:	je     10100c6 <trace+0x176>
 100ffce:	lea    -0xb0(%rbp),%rax
 100ffd5:	mov    %rax,-0x48(%rbp)
 100ffd9:	movq   $0x8,-0x40(%rbp)
 100ffe1:	movq   $0x0,-0x38(%rbp)
 100ffe9:	lea    -0x48(%rbp),%rdi
 100ffed:	movabs $0xffffffff00000000,%rcx
 100fff7:	mov    %r15,%rsi
 100fffa:	xor    %edx,%edx
 100fffc:	xor    %r8d,%r8d
 100ffff:	call   100edd0 <flatten>
 1010004:	test   %eax,%eax
 1010006:	je     101003f <trace+0xef>
 1010008:	mov    -0x38(%rbp),%r13
 101000c:	cmp    0x68(%r15),%r13
 1010010:	jne    101003f <trace+0xef>
 1010012:	test   %r13,%r13
 1010015:	je     100ff6c <trace+0x1c>
 101001b:	mov    0x60(%r15),%rsi
 101001f:	lea    0x0(,%r13,4),%rax
 1010027:	lea    (%rax,%rax,2),%rdx
 101002b:	lea    -0xb0(%rbp),%rdi
 1010032:	call   101e680 <bcmp>
 1010037:	test   %eax,%eax
 1010039:	je     10100d3 <trace+0x183>
 101003f:	mov    0x19532(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 1010046:	mov    (%rax),%rcx
 1010049:	lea    -0xe0b4(%rip),%rdi        # 1001f9c <__abi_tag+0x1ca0>
 1010050:	mov    $0x43,%esi
 1010055:	mov    $0x1,%edx
 101005a:	call   101efa0 <fwrite@plt>
 101005f:	call   101f1f0 <abort@plt>
 1010064:	cmp    $0x2,%ecx
 1010067:	je     1010113 <trace+0x1c3>
 101006d:	cmp    $0x4,%ecx
 1010070:	je     1010113 <trace+0x1c3>
 1010076:	cmp    $0x3,%ecx
 1010079:	jne    100ff6c <trace+0x1c>
 101007f:	cmpq   $0x0,0x20(%r15)
 1010084:	je     100ff6c <trace+0x1c>
 101008a:	lea    0x10(%r15),%rcx
 101008e:	lea    0x48(%r15),%rdx
 1010092:	cmp    $0x2,%eax
 1010095:	cmove  %rdx,%rcx
 1010099:	mov    (%rcx),%r12
 101009c:	xor    %r13d,%r13d
 101009f:	nop
 10100a0:	mov    0x8(%r12),%rsi
 10100a5:	mov    0x28(%r15),%rdx
 10100a9:	imul   %r13,%rdx
 10100ad:	add    %rbx,%rdx
 10100b0:	mov    %r14,%rdi
 10100b3:	call   100ff50 <trace>
 10100b8:	inc    %r13
 10100bb:	cmp    0x20(%r15),%r13
 10100bf:	jb     10100a0 <trace+0x150>
 10100c1:	jmp    100ff6c <trace+0x1c>
 10100c6:	mov    0x68(%r15),%r13
 10100ca:	test   %r13,%r13
 10100cd:	je     100ff6c <trace+0x1c>
 10100d3:	add    $0x8,%r12
 10100d7:	mov    $0xffffffff,%r15d
 10100dd:	jmp    10100fe <trace+0x1ae>
 10100df:	nop
 10100e0:	mov    -0x8(%r12),%eax
 10100e5:	mov    (%rbx,%rax,1),%rsi
 10100e9:	mov    %r14,%rdi
 10100ec:	call   10101a0 <mark>
 10100f1:	add    $0xc,%r12
 10100f5:	dec    %r13
 10100f8:	je     100ff6c <trace+0x1c>
 10100fe:	mov    -0x4(%r12),%eax
 1010103:	cmp    %r15,%rax
 1010106:	je     10100e0 <trace+0x190>
 1010108:	mov    (%rbx,%rax,1),%eax
 101010b:	cmp    (%r12),%eax
 101010f:	je     10100e0 <trace+0x190>
 1010111:	jmp    10100f1 <trace+0x1a1>
 1010113:	lea    0x10(%r15),%rdx
 1010117:	lea    0x48(%r15),%rsi
 101011b:	lea    0x18(%r15),%rdi
 101011f:	lea    0x50(%r15),%r8
 1010123:	cmp    $0x2,%eax
 1010126:	cmove  %rsi,%rdx
 101012a:	cmovne %rdi,%r8
 101012e:	mov    (%r8),%r12
 1010131:	movl   $0x0,-0x2c(%rbp)
 1010138:	cmp    $0x4,%ecx
 101013b:	jne    1010142 <trace+0x1f2>
 101013d:	mov    (%rbx),%eax
 101013f:	mov    %eax,-0x2c(%rbp)
 1010142:	test   %r12,%r12
 1010145:	je     100ff6c <trace+0x1c>
 101014b:	mov    (%rdx),%r13
 101014e:	add    $0x10,%r13
 1010152:	jmp    1010180 <trace+0x230>
 1010154:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010160:	mov    -0x8(%r13),%rsi
 1010164:	mov    -0x10(%r13),%rdx
 1010168:	add    %rbx,%rdx
 101016b:	mov    %r14,%rdi
 101016e:	call   100ff50 <trace>
 1010173:	add    $0x18,%r13
 1010177:	dec    %r12
 101017a:	je     100ff6c <trace+0x1c>
 1010180:	cmpw   $0x2,0x30(%r15)
 1010186:	je     1010160 <trace+0x210>
 1010188:	mov    -0x2c(%rbp),%eax
 101018b:	cmp    0x0(%r13),%eax
 101018f:	je     1010160 <trace+0x210>
 1010191:	jmp    1010173 <trace+0x223>
 1010193:	int3
 1010194:	int3
 1010195:	int3
 1010196:	int3
 1010197:	int3
 1010198:	int3
 1010199:	int3
 101019a:	int3
 101019b:	int3
 101019c:	int3
 101019d:	int3
 101019e:	int3
 101019f:	int3

00000000010101a0 <mark>:
 10101a0:	test   %rsi,%rsi
 10101a3:	je     10103ec <mark+0x24c>
 10101a9:	push   %rbp
 10101aa:	mov    %rsp,%rbp
 10101ad:	push   %r15
 10101af:	push   %r14
 10101b1:	push   %r13
 10101b3:	push   %r12
 10101b5:	push   %rbx
 10101b6:	push   %rax
 10101b7:	add    $0xfffffffffffffff0,%rsi
 10101bb:	mov    %rsi,%rax
 10101be:	shr    $0x15,%rax
 10101c2:	mov    %eax,%ecx
 10101c4:	and    $0x7f,%ecx
 10101c7:	mov    %ecx,%edx
 10101c9:	cmp    %rax,0x1208(%rdi,%rdx,8)
 10101d1:	je     1010221 <mark+0x81>
 10101d3:	mov    0x1200(%rdi),%rdx
 10101da:	test   %rdx,%rdx
 10101dd:	je     101026e <mark+0xce>
 10101e3:	mov    0x11f8(%rdi),%r8
 10101ea:	dec    %rdx
 10101ed:	movabs $0x9e3779b97f4a7c15,%r9
 10101f7:	imul   %rax,%r9
 10101fb:	shr    $0x20,%r9
 10101ff:	nop
 1010200:	and    %rdx,%r9
 1010203:	mov    (%r8,%r9,8),%r10
 1010207:	test   %r10,%r10
 101020a:	je     1010214 <mark+0x74>
 101020c:	inc    %r9
 101020f:	cmp    %rax,%r10
 1010212:	jne    1010200 <mark+0x60>
 1010214:	cmp    %rax,%r10
 1010217:	jne    101026e <mark+0xce>
 1010219:	mov    %rax,0x1208(%rdi,%rcx,8)
 1010221:	mov    %rsi,%rbx
 1010224:	and    $0xffffffffffff0000,%rbx
 101022b:	mov    %esi,%eax
 101022d:	shr    $0x4,%eax
 1010230:	mov    %esi,%r14d
 1010233:	shr    $0xa,%r14d
 1010237:	and    $0x3f,%r14d
 101023b:	mov    $0x1,%ecx
 1010240:	shlx   %rax,%rcx,%r15
 1010245:	mov    0x48(%rbx,%r14,8),%rcx
 101024a:	bt     %rax,%rcx
 101024e:	jae    10102f1 <mark+0x151>
 1010254:	test   %r15,0x248(%rbx,%r14,8)
 101025c:	je     10103de <mark+0x23e>
 1010262:	movb   $0x1,0x1175(%rdi)
 1010269:	jmp    10103de <mark+0x23e>
 101026e:	mov    (%rsi),%rbx
 1010271:	movabs $0x4000000000000003,%rax
 101027b:	test   %rax,%rbx
 101027e:	jne    10103de <mark+0x23e>
 1010284:	mov    0x4e8(%rdi),%rcx
 101028b:	cmp    0x4f0(%rdi),%rcx
 1010292:	jne    10103aa <mark+0x20a>
 1010298:	lea    (%rcx,%rcx,1),%rax
 101029c:	test   %rcx,%rcx
 101029f:	mov    $0x400,%r14d
 10102a5:	cmovne %rax,%r14
 10102a9:	cmp    %rcx,%r14
 10102ac:	jbe    1010355 <mark+0x1b5>
 10102b2:	mov    0x8(%rdi),%rax
 10102b6:	lea    0x0(,%r14,8),%rcx
 10102be:	mov    %rdi,%r15
 10102c1:	mov    %rax,%rdi
 10102c4:	mov    %rsi,%r12
 10102c7:	mov    %rcx,%rsi
 10102ca:	call   101f180 <realloc@plt>
 10102cf:	mov    %r15,%rdi
 10102d2:	test   %rax,%rax
 10102d5:	je     1010355 <mark+0x1b5>
 10102d7:	mov    %r12,%rsi
 10102da:	mov    %rax,0x8(%rdi)
 10102de:	mov    %r14,0x4f0(%rdi)
 10102e5:	mov    0x4e8(%rdi),%rcx
 10102ec:	jmp    10103ae <mark+0x20e>
 10102f1:	mov    0x4e8(%rdi),%rcx
 10102f8:	cmp    0x4f0(%rdi),%rcx
 10102ff:	jne    1010361 <mark+0x1c1>
 1010301:	lea    (%rcx,%rcx,1),%rax
 1010305:	test   %rcx,%rcx
 1010308:	mov    $0x400,%r12d
 101030e:	cmovne %rax,%r12
 1010312:	cmp    %rcx,%r12
 1010315:	jbe    1010355 <mark+0x1b5>
 1010317:	mov    0x8(%rdi),%rax
 101031b:	lea    0x0(,%r12,8),%rcx
 1010323:	mov    %rdi,-0x30(%rbp)
 1010327:	mov    %rax,%rdi
 101032a:	mov    %rsi,%r13
 101032d:	mov    %rcx,%rsi
 1010330:	call   101f180 <realloc@plt>
 1010335:	mov    -0x30(%rbp),%rdi
 1010339:	test   %rax,%rax
 101033c:	je     1010355 <mark+0x1b5>
 101033e:	mov    %r13,%rsi
 1010341:	mov    %rax,0x8(%rdi)
 1010345:	mov    %r12,0x4f0(%rdi)
 101034c:	mov    0x4e8(%rdi),%rcx
 1010353:	jmp    1010365 <mark+0x1c5>
 1010355:	movl   $0x1,0x4f8(%rdi)
 101035f:	jmp    10103de <mark+0x23e>
 1010361:	mov    0x8(%rdi),%rax
 1010365:	lea    0x1(%rcx),%rdx
 1010369:	mov    %rdx,0x4e8(%rdi)
 1010370:	mov    %rsi,(%rax,%rcx,8)
 1010374:	or     %r15,0x48(%rbx,%r14,8)
 1010379:	movzbl 0x1174(%rdi),%eax
 1010380:	test   %eax,%eax
 1010382:	je     10103db <mark+0x23b>
 1010384:	cmp    $0x1,%eax
 1010387:	jne    10103c6 <mark+0x226>
 1010389:	mov    0x248(%rbx,%r14,8),%rax
 1010391:	test   %r15,%rax
 1010394:	jne    10103ce <mark+0x22e>
 1010396:	or     %r15,%rax
 1010399:	mov    %rax,0x248(%rbx,%r14,8)
 10103a1:	movb   $0x1,0x1175(%rdi)
 10103a8:	jmp    10103de <mark+0x23e>
 10103aa:	mov    0x8(%rdi),%rax
 10103ae:	lea    0x1(%rcx),%rdx
 10103b2:	mov    %rdx,0x4e8(%rdi)
 10103b9:	mov    %rsi,(%rax,%rcx,8)
 10103bd:	or     $0x1,%rbx
 10103c1:	mov    %rbx,(%rsi)
 10103c4:	jmp    10103de <mark+0x23e>
 10103c6:	mov    0x248(%rbx,%r14,8),%rax
 10103ce:	andn   %rax,%r15,%rax
 10103d3:	mov    %rax,0x248(%rbx,%r14,8)
 10103db:	orb    $0x1,(%rsi)
 10103de:	add    $0x8,%rsp
 10103e2:	pop    %rbx
 10103e3:	pop    %r12
 10103e5:	pop    %r13
 10103e7:	pop    %r14
 10103e9:	pop    %r15
 10103eb:	pop    %rbp
 10103ec:	ret
 10103ed:	int3
 10103ee:	int3
 10103ef:	int3

00000000010103f0 <scan_payload>:
 10103f0:	push   %rbp
 10103f1:	mov    %rsp,%rbp
 10103f4:	push   %r15
 10103f6:	push   %r14
 10103f8:	push   %r13
 10103fa:	push   %r12
 10103fc:	push   %rbx
 10103fd:	sub    $0x98,%rsp
 1010404:	mov    0x8(%rsi),%r15
 1010408:	movzwl 0x30(%r15),%eax
 101040d:	test   %eax,%eax
 101040f:	je     1010463 <scan_payload+0x73>
 1010411:	cmpl   $0x1,0x58(%r15)
 1010416:	je     1010463 <scan_payload+0x73>
 1010418:	mov    %rsi,%rbx
 101041b:	mov    %rdi,%r13
 101041e:	mov    $0x3c,%ecx
 1010423:	bzhi   %rcx,(%rsi),%r12
 1010428:	add    $0x10,%rbx
 101042c:	shr    $0x2,%r12
 1010430:	cmp    $0x6,%eax
 1010433:	ja     1010475 <scan_payload+0x85>
 1010435:	mov    $0x62,%ecx
 101043a:	bt     %eax,%ecx
 101043d:	jae    1010475 <scan_payload+0x85>
 101043f:	test   %r12,%r12
 1010442:	je     1010463 <scan_payload+0x73>
 1010444:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010450:	mov    (%rbx),%rsi
 1010453:	mov    %r13,%rdi
 1010456:	call   10101a0 <mark>
 101045b:	add    (%r15),%rbx
 101045e:	dec    %r12
 1010461:	jne    1010450 <scan_payload+0x60>
 1010463:	add    $0x98,%rsp
 101046a:	pop    %rbx
 101046b:	pop    %r12
 101046d:	pop    %r13
 101046f:	pop    %r14
 1010471:	pop    %r15
 1010473:	pop    %rbp
 1010474:	ret
 1010475:	mov    0x60(%r15),%rax
 1010479:	mov    %rax,-0x30(%rbp)
 101047d:	test   %rax,%rax
 1010480:	je     101051f <scan_payload+0x12f>
 1010486:	cmpl   $0x0,0x68(%r13)
 101048b:	je     1010552 <scan_payload+0x162>
 1010491:	lea    -0xc0(%rbp),%rax
 1010498:	mov    %rax,-0x60(%rbp)
 101049c:	movq   $0x8,-0x58(%rbp)
 10104a4:	movq   $0x0,-0x50(%rbp)
 10104ac:	lea    -0x60(%rbp),%rdi
 10104b0:	movabs $0xffffffff00000000,%rcx
 10104ba:	mov    %r15,%rsi
 10104bd:	xor    %edx,%edx
 10104bf:	xor    %r8d,%r8d
 10104c2:	call   100edd0 <flatten>
 10104c7:	test   %eax,%eax
 10104c9:	je     10104fa <scan_payload+0x10a>
 10104cb:	mov    -0x50(%rbp),%r14
 10104cf:	cmp    0x68(%r15),%r14
 10104d3:	jne    10104fa <scan_payload+0x10a>
 10104d5:	test   %r14,%r14
 10104d8:	je     1010463 <scan_payload+0x73>
 10104da:	mov    0x60(%r15),%rsi
 10104de:	lea    0x0(,%r14,4),%rax
 10104e6:	lea    (%rax,%rax,2),%rdx
 10104ea:	lea    -0xc0(%rbp),%rdi
 10104f1:	call   101e680 <bcmp>
 10104f6:	test   %eax,%eax
 10104f8:	je     101055f <scan_payload+0x16f>
 10104fa:	mov    0x19077(%rip),%rax        # 1029578 <stderr@GLIBC_2.2.5>
 1010501:	mov    (%rax),%rcx
 1010504:	lea    -0xe56f(%rip),%rdi        # 1001f9c <__abi_tag+0x1ca0>
 101050b:	mov    $0x43,%esi
 1010510:	mov    $0x1,%edx
 1010515:	call   101efa0 <fwrite@plt>
 101051a:	call   101f1f0 <abort@plt>
 101051f:	test   %r12,%r12
 1010522:	je     1010463 <scan_payload+0x73>
 1010528:	xor    %r14d,%r14d
 101052b:	nopl   0x0(%rax,%rax,1)
 1010530:	mov    (%r15),%rdx
 1010533:	imul   %r14,%rdx
 1010537:	add    %rbx,%rdx
 101053a:	mov    %r13,%rdi
 101053d:	mov    %r15,%rsi
 1010540:	call   100ff50 <trace>
 1010545:	inc    %r14
 1010548:	cmp    %r14,%r12
 101054b:	jne    1010530 <scan_payload+0x140>
 101054d:	jmp    1010463 <scan_payload+0x73>
 1010552:	mov    0x68(%r15),%r14
 1010556:	test   %r14,%r14
 1010559:	je     1010463 <scan_payload+0x73>
 101055f:	test   %r12,%r12
 1010562:	je     1010463 <scan_payload+0x73>
 1010568:	mov    (%r15),%rax
 101056b:	mov    %rax,-0x38(%rbp)
 101056f:	addq   $0x8,-0x30(%rbp)
 1010574:	xor    %eax,%eax
 1010576:	mov    %r14,-0x40(%rbp)
 101057a:	jmp    101059b <scan_payload+0x1ab>
 101057c:	nopl   0x0(%rax)
 1010580:	mov    -0x48(%rbp),%rax
 1010584:	inc    %rax
 1010587:	add    -0x38(%rbp),%rbx
 101058b:	cmp    %r12,%rax
 101058e:	mov    %r15,%r13
 1010591:	mov    -0x40(%rbp),%r14
 1010595:	je     1010463 <scan_payload+0x73>
 101059b:	mov    %rax,-0x48(%rbp)
 101059f:	mov    %r13,%r15
 10105a2:	mov    -0x30(%rbp),%r13
 10105a6:	jmp    10105c9 <scan_payload+0x1d9>
 10105a8:	nopl   0x0(%rax,%rax,1)
 10105b0:	mov    -0x8(%r13),%eax
 10105b4:	mov    (%rbx,%rax,1),%rsi
 10105b8:	mov    %r15,%rdi
 10105bb:	call   10101a0 <mark>
 10105c0:	add    $0xc,%r13
 10105c4:	dec    %r14
 10105c7:	je     1010580 <scan_payload+0x190>
 10105c9:	mov    -0x4(%r13),%eax
 10105cd:	mov    $0xffffffff,%ecx
 10105d2:	cmp    %rcx,%rax
 10105d5:	je     10105b0 <scan_payload+0x1c0>
 10105d7:	mov    (%rbx,%rax,1),%eax
 10105da:	cmp    0x0(%r13),%eax
 10105de:	je     10105b0 <scan_payload+0x1c0>
 10105e0:	jmp    10105c0 <scan_payload+0x1d0>
 10105e2:	int3
 10105e3:	int3
 10105e4:	int3
 10105e5:	int3
 10105e6:	int3
 10105e7:	int3
 10105e8:	int3
 10105e9:	int3
 10105ea:	int3
 10105eb:	int3
 10105ec:	int3
 10105ed:	int3
 10105ee:	int3
 10105ef:	int3

00000000010105f0 <myl_native_arena_reclaim>:
 10105f0:	push   %rbp
 10105f1:	mov    %rsp,%rbp
 10105f4:	push   %rbx
 10105f5:	push   %rax
 10105f6:	mov    %rdi,%rbx
 10105f9:	mov    0x4e0(%rdi),%rdi
 1010600:	jmp    101061c <myl_native_arena_reclaim+0x2c>
 1010602:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010610:	call   101efd0 <free@plt>
 1010615:	mov    0x4e0(%rbx),%rdi
 101061c:	test   %rdi,%rdi
 101061f:	je     101063f <myl_native_arena_reclaim+0x4f>
 1010621:	mov    (%rdi),%rax
 1010624:	mov    %rax,0x4e0(%rbx)
 101062b:	cmpq   $0x0,0x1608(%rbx)
 1010633:	je     1010610 <myl_native_arena_reclaim+0x20>
 1010635:	mov    0x8(%rdi),%rax
 1010639:	sub    %rax,0x18(%rbx)
 101063d:	jmp    1010610 <myl_native_arena_reclaim+0x20>
 101063f:	vxorps %xmm0,%xmm0,%xmm0
 1010643:	vmovups %xmm0,0xc0(%rbx)
 101064b:	add    $0x8,%rsp
 101064f:	pop    %rbx
 1010650:	pop    %rbp
 1010651:	ret
 1010652:	int3
 1010653:	int3
 1010654:	int3
 1010655:	int3
 1010656:	int3
 1010657:	int3
 1010658:	int3
 1010659:	int3
 101065a:	int3
 101065b:	int3
 101065c:	int3
 101065d:	int3
 101065e:	int3
 101065f:	int3

0000000001010660 <myl_native_arena_alloc>:
 1010660:	push   %rbp
 1010661:	mov    %rsp,%rbp
 1010664:	push   %r15
 1010666:	push   %r14
 1010668:	push   %r13
 101066a:	push   %r12
 101066c:	push   %rbx
 101066d:	sub    $0x48,%rsp
 1010671:	mov    %rdi,%rbx
 1010674:	mov    %rdx,%rax
 1010677:	shr    $0x26,%rax
 101067b:	setne  %al
 101067e:	cmp    $0x100000,%ecx
 1010684:	setae  %dil
 1010688:	or     %al,%dil
 101068b:	je     1010694 <myl_native_arena_alloc+0x34>
 101068d:	xor    %eax,%eax
 101068f:	jmp    1010dbe <myl_native_arena_alloc+0x75e>
 1010694:	mov    (%rsi),%r14
 1010697:	imul   %rdx,%r14
 101069b:	cmp    $0x1,%r14
 101069f:	mov    %r14,%r15
 10106a2:	adc    $0x0,%r15
 10106a6:	cmpl   $0x0,0x68(%rbx)
 10106aa:	je     10106d4 <myl_native_arena_alloc+0x74>
 10106ac:	cmpl   $0x0,0x74(%rbx)
 10106b0:	jne    10106d4 <myl_native_arena_alloc+0x74>
 10106b2:	mov    %rbx,%rdi
 10106b5:	mov    %r15,-0x38(%rbp)
 10106b9:	mov    %rcx,%r15
 10106bc:	mov    %rsi,%r13
 10106bf:	mov    %rdx,%r12
 10106c2:	call   100ef80 <myl_native_heap_collect>
 10106c7:	mov    %r12,%rdx
 10106ca:	mov    %r13,%rsi
 10106cd:	mov    %r15,%rcx
 10106d0:	mov    -0x38(%rbp),%r15
 10106d4:	mov    0x11a0(%rbx),%rdi
 10106db:	test   %rdi,%rdi
 10106de:	je     10107a4 <myl_native_arena_alloc+0x144>
 10106e4:	mov    0x5c0(%rbx),%rax
 10106eb:	mov    0x5c8(%rbx),%r8
 10106f2:	mov    %r8,%r9
 10106f5:	sub    %rax,%r9
 10106f8:	sub    $0x10,%r9
 10106fc:	setb   %r10b
 1010700:	cmp    %ecx,0x20(%rdi)
 1010703:	jne    101077e <myl_native_arena_alloc+0x11e>
 1010705:	test   %r10b,%r10b
 1010708:	jne    101077e <myl_native_arena_alloc+0x11e>
 101070a:	cmp    %r9,%r15
 101070d:	ja     101077e <myl_native_arena_alloc+0x11e>
 101070f:	shl    $0x28,%rcx
 1010713:	shl    $0x2,%rdx
 1010717:	or     %rcx,%rdx
 101071a:	movabs $0x4000000000000000,%rcx
 1010724:	or     %rdx,%rcx
 1010727:	mov    %rcx,(%rax)
 101072a:	mov    %rsi,0x8(%rax)
 101072e:	incq   0x18(%rdi)
 1010732:	lea    0x50(%rdi),%rcx
 1010736:	sub    %rcx,%r15
 1010739:	lea    (%r15,%rax,1),%rcx
 101073d:	add    $0x1f,%rcx
 1010741:	and    $0xfffffffffffffff0,%rcx
 1010745:	mov    0x8(%rdi),%rdx
 1010749:	add    $0xffffffffffffffb0,%rdx
 101074d:	cmp    %rdx,%rcx
 1010750:	lea    0x50(%rdi,%rcx,1),%rcx
 1010755:	cmovb  %rcx,%r8
 1010759:	mov    %r8,0x5c0(%rbx)
 1010760:	vmovdqu 0x40(%rbx),%xmm0
 1010765:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1010769:	vpsubq %xmm1,%xmm0,%xmm0
 101076d:	vmovdqu %xmm0,0x40(%rbx)
 1010772:	incq   0x90(%rbx)
 1010779:	jmp    1010dba <myl_native_arena_alloc+0x75a>
 101077e:	lea    0x5c0(%rbx),%r8
 1010785:	sub    %rdi,%rax
 1010788:	add    $0xffffffffffffffb0,%rax
 101078c:	mov    %rax,0x10(%rdi)
 1010790:	movq   $0x0,0x11a0(%rbx)
 101079b:	vpxor  %xmm0,%xmm0,%xmm0
 101079f:	vmovdqu %xmm0,(%r8)
 10107a4:	mov    %ecx,%r13d
 10107a7:	cmp    %r13,0x11e8(%rbx)
 10107ae:	jbe    10107d2 <myl_native_arena_alloc+0x172>
 10107b0:	mov    0x4d8(%rbx),%rax
 10107b7:	mov    (%rax,%r13,8),%r12
 10107bb:	test   %r12,%r12
 10107be:	je     10107d2 <myl_native_arena_alloc+0x172>
 10107c0:	mov    0x10(%r12),%rax
 10107c5:	cmp    $0xfffffffffffffff1,%rax
 10107c9:	jb     10107e0 <myl_native_arena_alloc+0x180>
 10107cb:	mov    0x8(%r12),%rdi
 10107d0:	jmp    1010812 <myl_native_arena_alloc+0x1b2>
 10107d2:	xor    %eax,%eax
 10107d4:	cmp    $0xffffffffffffff90,%r14
 10107d8:	ja     101068d <myl_native_arena_alloc+0x2d>
 10107de:	jmp    101082e <myl_native_arena_alloc+0x1ce>
 10107e0:	add    $0xf,%rax
 10107e4:	and    $0xfffffffffffffff0,%rax
 10107e8:	mov    0x8(%r12),%rdi
 10107ed:	lea    -0x50(%rdi),%r8
 10107f1:	sub    %rax,%r8
 10107f4:	jb     1010812 <myl_native_arena_alloc+0x1b2>
 10107f6:	sub    $0x10,%r8
 10107fa:	setb   %r9b
 10107fe:	cmp    %r8,%r15
 1010801:	seta   %r8b
 1010805:	or     %r9b,%r8b
 1010808:	cmp    $0x1,%r8b
 101080c:	jne    1010d07 <myl_native_arena_alloc+0x6a7>
 1010812:	cmp    $0x80000,%rdi
 1010819:	mov    $0x80000,%eax
 101081e:	cmovb  %rdi,%rax
 1010822:	add    %eax,%eax
 1010824:	cmp    $0xffffffffffffff90,%r14
 1010828:	ja     101068d <myl_native_arena_alloc+0x2d>
 101082e:	mov    %r15,-0x38(%rbp)
 1010832:	lea    0x6f(%r15),%r12
 1010836:	and    $0xfffffffffffffff0,%r12
 101083a:	cmp    %r12,%rax
 101083d:	cmovbe %r12,%rax
 1010841:	cmp    $0x10001,%rax
 1010847:	mov    $0x10000,%r15d
 101084d:	cmovae %rax,%r15
 1010851:	cmpq   $0x0,0x1608(%rbx)
 1010859:	mov    0x11f0(%rbx),%r14
 1010860:	mov    %rcx,-0x58(%rbp)
 1010864:	mov    %rdx,-0x48(%rbp)
 1010868:	mov    %rsi,-0x40(%rbp)
 101086c:	je     1010884 <myl_native_arena_alloc+0x224>
 101086e:	cmp    %r13,%r14
 1010871:	jbe    1010946 <myl_native_arena_alloc+0x2e6>
 1010877:	movq   $0x0,-0x30(%rbp)
 101087f:	jmp    10109a7 <myl_native_arena_alloc+0x347>
 1010884:	cmp    %r13,%r14
 1010887:	ja     10108fa <myl_native_arena_alloc+0x29a>
 1010889:	test   %r14,%r14
 101088c:	mov    $0x8,%eax
 1010891:	cmovne %r14,%rax
 1010895:	data16 cs nopw 0x0(%rax,%rax,1)
 10108a0:	mov    %rax,%r14
 10108a3:	add    %rax,%rax
 10108a6:	cmp    %r13,%r14
 10108a9:	jbe    10108a0 <myl_native_arena_alloc+0x240>
 10108ab:	mov    0x4d8(%rbx),%rdi
 10108b2:	lea    0x0(,%r14,8),%rsi
 10108ba:	call   101f180 <realloc@plt>
 10108bf:	test   %rax,%rax
 10108c2:	je     101068d <myl_native_arena_alloc+0x2d>
 10108c8:	mov    0x11f0(%rbx),%rcx
 10108cf:	lea    (%rax,%rcx,8),%rdi
 10108d3:	mov    %r14,%rdx
 10108d6:	sub    %rcx,%rdx
 10108d9:	shl    $0x3,%rdx
 10108dd:	xor    %esi,%esi
 10108df:	mov    %rax,-0x30(%rbp)
 10108e3:	call   101e6b0 <compiler_rt.fastMemset>
 10108e8:	mov    -0x30(%rbp),%rax
 10108ec:	mov    %rax,0x4d8(%rbx)
 10108f3:	mov    %r14,0x11f0(%rbx)
 10108fa:	mov    0x18(%rbx),%rdi
 10108fe:	mov    0x58(%rbx),%rax
 1010902:	mov    %rax,%r8
 1010905:	sub    %rdi,%r8
 1010908:	jb     101090f <myl_native_arena_alloc+0x2af>
 101090a:	cmp    %r8,%r12
 101090d:	jbe    1010925 <myl_native_arena_alloc+0x2c5>
 101090f:	cmpl   $0x0,0x74(%rbx)
 1010913:	jne    1010925 <myl_native_arena_alloc+0x2c5>
 1010915:	mov    %rbx,%rdi
 1010918:	call   100ef80 <myl_native_heap_collect>
 101091d:	mov    0x18(%rbx),%rdi
 1010921:	mov    0x58(%rbx),%rax
 1010925:	xor    %r8d,%r8d
 1010928:	sub    %rdi,%rax
 101092b:	cmovae %rax,%r8
 101092f:	cmp    %r8,%r12
 1010932:	jbe    1010a63 <myl_native_arena_alloc+0x403>
 1010938:	movl   $0x1,0x6c(%rbx)
 101093f:	xor    %eax,%eax
 1010941:	jmp    1010dbe <myl_native_arena_alloc+0x75e>
 1010946:	test   %r14,%r14
 1010949:	mov    $0x8,%eax
 101094e:	cmovne %r14,%rax
 1010952:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010960:	mov    %rax,%r14
 1010963:	add    %rax,%rax
 1010966:	cmp    %r13,%r14
 1010969:	jbe    1010960 <myl_native_arena_alloc+0x300>
 101096b:	lea    0x0(,%r14,8),%rsi
 1010973:	mov    %rbx,%rdi
 1010976:	call   1012690 <myl_rc_meta_alloc>
 101097b:	test   %rax,%rax
 101097e:	je     101068d <myl_native_arena_alloc+0x2d>
 1010984:	mov    0x11f0(%rbx),%rdx
 101098b:	test   %rdx,%rdx
 101098e:	mov    %rax,-0x30(%rbp)
 1010992:	je     10109a7 <myl_native_arena_alloc+0x347>
 1010994:	mov    0x4d8(%rbx),%rsi
 101099b:	shl    $0x3,%rdx
 101099f:	mov    %rax,%rdi
 10109a2:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 10109a7:	mov    0x4e0(%rbx),%rdi
 10109ae:	test   %rdi,%rdi
 10109b1:	je     1010a4b <myl_native_arena_alloc+0x3eb>
 10109b7:	xor    %eax,%eax
 10109b9:	mov    %rdi,%r10
 10109bc:	lea    0x4e0(%rbx),%r8
 10109c3:	jmp    10109db <myl_native_arena_alloc+0x37b>
 10109c5:	data16 cs nopw 0x0(%rax,%rax,1)
 10109d0:	mov    %r9,%rax
 10109d3:	mov    (%r8),%r10
 10109d6:	test   %r10,%r10
 10109d9:	je     10109ff <myl_native_arena_alloc+0x39f>
 10109db:	mov    %r8,%r9
 10109de:	mov    %r10,%r8
 10109e1:	mov    0x8(%r10),%r10
 10109e5:	cmp    %r12,%r10
 10109e8:	jb     10109d3 <myl_native_arena_alloc+0x373>
 10109ea:	cmp    %r15,%r10
 10109ed:	ja     10109d3 <myl_native_arena_alloc+0x373>
 10109ef:	test   %rax,%rax
 10109f2:	je     10109d0 <myl_native_arena_alloc+0x370>
 10109f4:	mov    (%rax),%r11
 10109f7:	cmp    0x8(%r11),%r10
 10109fb:	ja     10109d0 <myl_native_arena_alloc+0x370>
 10109fd:	jmp    10109d3 <myl_native_arena_alloc+0x373>
 10109ff:	test   %rax,%rax
 1010a02:	je     1010a4b <myl_native_arena_alloc+0x3eb>
 1010a04:	mov    (%rax),%r12
 1010a07:	mov    (%r12),%rcx
 1010a0b:	mov    %rcx,(%rax)
 1010a0e:	decq   0xc0(%rbx)
 1010a15:	mov    0x8(%r12),%rax
 1010a1a:	sub    %rax,0xc8(%rbx)
 1010a21:	lea    0x50(%r12),%rdi
 1010a26:	mov    0x10(%r12),%rdx
 1010a2b:	xor    %esi,%esi
 1010a2d:	call   101e6b0 <compiler_rt.fastMemset>
 1010a32:	vpxor  %xmm0,%xmm0,%xmm0
 1010a36:	vmovdqa %xmm0,0x10(%r12)
 1010a3d:	mov    $0xa0,%eax
 1010a42:	mov    -0x38(%rbp),%r15
 1010a46:	jmp    1010c6e <myl_native_arena_alloc+0x60e>
 1010a4b:	mov    0x18(%rbx),%r9
 1010a4f:	mov    0x58(%rbx),%r8
 1010a53:	test   %r8,%r8
 1010a56:	je     1010ac3 <myl_native_arena_alloc+0x463>
 1010a58:	xor    %eax,%eax
 1010a5a:	sub    %r9,%r8
 1010a5d:	cmovae %r8,%rax
 1010a61:	jmp    1010ac9 <myl_native_arena_alloc+0x469>
 1010a63:	mov    %r8,%r14
 1010a66:	and    $0xfffffffffffffff0,%r14
 1010a6a:	cmp    %r8,%r15
 1010a6d:	cmovb  %r15,%r14
 1010a71:	mov    0x4e0(%rbx),%rdx
 1010a78:	test   %rdx,%rdx
 1010a7b:	mov    -0x38(%rbp),%r15
 1010a7f:	je     1010ba2 <myl_native_arena_alloc+0x542>
 1010a85:	lea    0x4e0(%rbx),%rcx
 1010a8c:	xor    %eax,%eax
 1010a8e:	jmp    1010a9f <myl_native_arena_alloc+0x43f>
 1010a90:	mov    %rsi,%rax
 1010a93:	mov    (%rcx),%rdx
 1010a96:	test   %rdx,%rdx
 1010a99:	je     1010b56 <myl_native_arena_alloc+0x4f6>
 1010a9f:	mov    %rcx,%rsi
 1010aa2:	mov    %rdx,%rcx
 1010aa5:	mov    0x8(%rdx),%rdx
 1010aa9:	cmp    %r12,%rdx
 1010aac:	jb     1010a93 <myl_native_arena_alloc+0x433>
 1010aae:	cmp    %r14,%rdx
 1010ab1:	ja     1010a93 <myl_native_arena_alloc+0x433>
 1010ab3:	test   %rax,%rax
 1010ab6:	je     1010a90 <myl_native_arena_alloc+0x430>
 1010ab8:	mov    (%rax),%rdi
 1010abb:	cmp    0x8(%rdi),%rdx
 1010abf:	ja     1010a90 <myl_native_arena_alloc+0x430>
 1010ac1:	jmp    1010a93 <myl_native_arena_alloc+0x433>
 1010ac3:	mov    %r9,%rax
 1010ac6:	not    %rax
 1010ac9:	xor    %r8d,%r8d
 1010acc:	cmp    %rax,%r12
 1010acf:	cmovbe %rdi,%r8
 1010ad3:	mov    %r8,-0x50(%rbp)
 1010ad7:	test   %rdi,%rdi
 1010ada:	je     1010c01 <myl_native_arena_alloc+0x5a1>
 1010ae0:	cmp    %rax,%r12
 1010ae3:	ja     1010b04 <myl_native_arena_alloc+0x4a4>
 1010ae5:	jmp    1010c01 <myl_native_arena_alloc+0x5a1>
 1010aea:	nopw   0x0(%rax,%rax,1)
 1010af0:	call   101efd0 <free@plt>
 1010af5:	lea    0x4e0(%rbx),%rax
 1010afc:	mov    (%rax),%rdi
 1010aff:	test   %rdi,%rdi
 1010b02:	je     1010b22 <myl_native_arena_alloc+0x4c2>
 1010b04:	mov    (%rdi),%rax
 1010b07:	mov    %rax,0x4e0(%rbx)
 1010b0e:	cmpq   $0x0,0x1608(%rbx)
 1010b16:	je     1010af0 <myl_native_arena_alloc+0x490>
 1010b18:	mov    0x8(%rdi),%rax
 1010b1c:	sub    %rax,0x18(%rbx)
 1010b20:	jmp    1010af0 <myl_native_arena_alloc+0x490>
 1010b22:	vpxor  %xmm0,%xmm0,%xmm0
 1010b26:	vmovdqu %xmm0,0xc0(%rbx)
 1010b2e:	mov    0x18(%rbx),%r9
 1010b32:	mov    0x58(%rbx),%rax
 1010b36:	test   %rax,%rax
 1010b39:	je     1010bf3 <myl_native_arena_alloc+0x593>
 1010b3f:	xor    %edx,%edx
 1010b41:	sub    %r9,%rax
 1010b44:	mov    $0x0,%ecx
 1010b49:	mov    %rcx,-0x50(%rbp)
 1010b4d:	cmovb  %rdx,%rax
 1010b51:	jmp    1010c01 <myl_native_arena_alloc+0x5a1>
 1010b56:	test   %rax,%rax
 1010b59:	je     1010ba2 <myl_native_arena_alloc+0x542>
 1010b5b:	mov    (%rax),%r12
 1010b5e:	mov    (%r12),%rcx
 1010b62:	mov    %rcx,(%rax)
 1010b65:	decq   0xc0(%rbx)
 1010b6c:	mov    0x8(%r12),%rax
 1010b71:	sub    %rax,0xc8(%rbx)
 1010b78:	lea    0x50(%r12),%rdi
 1010b7d:	mov    0x10(%r12),%rdx
 1010b82:	xor    %esi,%esi
 1010b84:	call   101e6b0 <compiler_rt.fastMemset>
 1010b89:	vpxor  %xmm0,%xmm0,%xmm0
 1010b8d:	vmovdqa %xmm0,0x10(%r12)
 1010b94:	incq   0xa0(%rbx)
 1010b9b:	mov    0x8(%r12),%r14
 1010ba0:	jmp    1010bc6 <myl_native_arena_alloc+0x566>
 1010ba2:	mov    $0x1,%edi
 1010ba7:	mov    %r14,%rsi
 1010baa:	call   101ef80 <calloc@plt>
 1010baf:	test   %rax,%rax
 1010bb2:	je     1010e4c <myl_native_arena_alloc+0x7ec>
 1010bb8:	mov    %rax,%r12
 1010bbb:	mov    %r14,0x8(%rax)
 1010bbf:	incq   0x98(%rbx)
 1010bc6:	mov    -0x58(%rbp),%rcx
 1010bca:	mov    -0x40(%rbp),%rsi
 1010bce:	mov    -0x48(%rbp),%rdx
 1010bd2:	add    %r14,0x18(%rbx)
 1010bd6:	mov    0x4d8(%rbx),%rax
 1010bdd:	mov    (%rax,%r13,8),%rdi
 1010be1:	mov    %rdi,(%r12)
 1010be5:	mov    %ecx,0x20(%r12)
 1010bea:	mov    %r12,(%rax,%r13,8)
 1010bee:	jmp    1010cc7 <myl_native_arena_alloc+0x667>
 1010bf3:	mov    %r9,%rax
 1010bf6:	not    %rax
 1010bf9:	movq   $0x0,-0x50(%rbp)
 1010c01:	cmp    %rax,%r12
 1010c04:	jbe    1010c27 <myl_native_arena_alloc+0x5c7>
 1010c06:	movl   $0x1,0x6c(%rbx)
 1010c0d:	shl    $0x3,%r14
 1010c11:	mov    %rbx,%rdi
 1010c14:	mov    -0x30(%rbp),%rsi
 1010c18:	mov    %r14,%rdx
 1010c1b:	call   1012710 <myl_rc_meta_free>
 1010c20:	xor    %eax,%eax
 1010c22:	jmp    1010dbe <myl_native_arena_alloc+0x75e>
 1010c27:	mov    %r9,-0x68(%rbp)
 1010c2b:	mov    %rax,%r12
 1010c2e:	and    $0xfffffffffffffff0,%r12
 1010c32:	cmp    %rax,%r15
 1010c35:	cmovb  %r15,%r12
 1010c39:	mov    $0x1,%edi
 1010c3e:	mov    %r12,%rsi
 1010c41:	call   101ef80 <calloc@plt>
 1010c46:	mov    %r12,%rcx
 1010c49:	mov    %rax,%r12
 1010c4c:	test   %rax,%rax
 1010c4f:	mov    -0x38(%rbp),%r15
 1010c53:	je     1010dcd <myl_native_arena_alloc+0x76d>
 1010c59:	mov    %rcx,0x8(%r12)
 1010c5e:	mov    -0x68(%rbp),%rax
 1010c62:	add    %rcx,%rax
 1010c65:	mov    %rax,0x18(%rbx)
 1010c69:	mov    $0x98,%eax
 1010c6e:	incq   (%rbx,%rax,1)
 1010c72:	mov    0x4d8(%rbx),%rsi
 1010c79:	cmpq   $0x0,-0x30(%rbp)
 1010c7e:	je     1010ca7 <myl_native_arena_alloc+0x647>
 1010c80:	mov    0x11f0(%rbx),%rdx
 1010c87:	shl    $0x3,%rdx
 1010c8b:	mov    %rbx,%rdi
 1010c8e:	call   1012710 <myl_rc_meta_free>
 1010c93:	mov    -0x30(%rbp),%rdi
 1010c97:	mov    %rdi,0x4d8(%rbx)
 1010c9e:	mov    %r14,0x11f0(%rbx)
 1010ca5:	jmp    1010caa <myl_native_arena_alloc+0x64a>
 1010ca7:	mov    %rsi,%rdi
 1010caa:	mov    -0x40(%rbp),%rsi
 1010cae:	mov    -0x48(%rbp),%rdx
 1010cb2:	mov    (%rdi,%r13,8),%rax
 1010cb6:	mov    %rax,(%r12)
 1010cba:	mov    -0x58(%rbp),%rcx
 1010cbe:	mov    %ecx,0x20(%r12)
 1010cc3:	mov    %r12,(%rdi,%r13,8)
 1010cc7:	cmp    %r13,0x11e8(%rbx)
 1010cce:	ja     1010cdb <myl_native_arena_alloc+0x67b>
 1010cd0:	lea    0x1(%r13),%rax
 1010cd4:	mov    %rax,0x11e8(%rbx)
 1010cdb:	incq   0xa8(%rbx)
 1010ce2:	mov    0xb0(%rbx),%rax
 1010ce9:	add    0x8(%r12),%rax
 1010cee:	mov    %rax,0xb0(%rbx)
 1010cf5:	cmp    0xb8(%rbx),%rax
 1010cfc:	jbe    1010d05 <myl_native_arena_alloc+0x6a5>
 1010cfe:	mov    %rax,0xb8(%rbx)
 1010d05:	xor    %eax,%eax
 1010d07:	movabs $0x4000000000000000,%rdi
 1010d11:	shl    $0x28,%r13
 1010d15:	lea    0x0(,%rdx,4),%rdx
 1010d1d:	add    %r13,%rdx
 1010d20:	or     %rdi,%rdx
 1010d23:	mov    %rdx,0x50(%r12,%rax,1)
 1010d28:	mov    %rsi,0x58(%r12,%rax,1)
 1010d2d:	incq   0x18(%r12)
 1010d32:	lea    (%r15,%rax,1),%rdx
 1010d36:	add    $0x10,%rdx
 1010d3a:	mov    %rdx,0x10(%r12)
 1010d3f:	vmovdqu 0x40(%rbx),%xmm0
 1010d44:	vpcmpeqd %xmm1,%xmm1,%xmm1
 1010d48:	vpsubq %xmm1,%xmm0,%xmm0
 1010d4c:	vmovdqu %xmm0,0x40(%rbx)
 1010d51:	incq   0x90(%rbx)
 1010d58:	add    %r12,%rax
 1010d5b:	add    $0x50,%rax
 1010d5f:	cmp    0x70(%rbx),%ecx
 1010d62:	jne    1010dba <myl_native_arena_alloc+0x75a>
 1010d64:	cmpl   $0x0,0x74(%rbx)
 1010d68:	jne    1010dba <myl_native_arena_alloc+0x75a>
 1010d6a:	cmpl   $0x0,0x68(%rbx)
 1010d6e:	jne    1010dba <myl_native_arena_alloc+0x75a>
 1010d70:	mov    0x8(%r12),%rcx
 1010d75:	mov    0x10(%r12),%rdx
 1010d7a:	add    $0xf,%rdx
 1010d7e:	and    $0xfffffffffffffff0,%rdx
 1010d82:	lea    -0x50(%rcx),%rsi
 1010d86:	cmp    %rsi,%rdx
 1010d89:	jae    1010dba <myl_native_arena_alloc+0x75a>
 1010d8b:	lea    0x50(%r12),%rsi
 1010d90:	add    %rdx,%rsi
 1010d93:	add    %r12,%rcx
 1010d96:	mov    %rsi,0x5c0(%rbx)
 1010d9d:	mov    %rcx,0x5c8(%rbx)
 1010da4:	lea    (%rdi,%r13,1),%rcx
 1010da8:	add    $0x4,%rcx
 1010dac:	mov    %rcx,0x5d0(%rbx)
 1010db3:	mov    %r12,0x11a0(%rbx)
 1010dba:	add    $0x10,%rax
 1010dbe:	add    $0x48,%rsp
 1010dc2:	pop    %rbx
 1010dc3:	pop    %r12
 1010dc5:	pop    %r13
 1010dc7:	pop    %r14
 1010dc9:	pop    %r15
 1010dcb:	pop    %rbp
 1010dcc:	ret
 1010dcd:	mov    %rcx,-0x60(%rbp)
 1010dd1:	mov    -0x50(%rbp),%rdi
 1010dd5:	test   %rdi,%rdi
 1010dd8:	je     1010c0d <myl_native_arena_alloc+0x5ad>
 1010dde:	mov    -0x60(%rbp),%r12
 1010de2:	jmp    1010df8 <myl_native_arena_alloc+0x798>
 1010de4:	call   101efd0 <free@plt>
 1010de9:	lea    0x4e0(%rbx),%rax
 1010df0:	mov    (%rax),%rdi
 1010df3:	test   %rdi,%rdi
 1010df6:	je     1010e16 <myl_native_arena_alloc+0x7b6>
 1010df8:	mov    (%rdi),%rax
 1010dfb:	mov    %rax,0x4e0(%rbx)
 1010e02:	cmpq   $0x0,0x1608(%rbx)
 1010e0a:	je     1010de4 <myl_native_arena_alloc+0x784>
 1010e0c:	mov    0x8(%rdi),%rax
 1010e10:	sub    %rax,0x18(%rbx)
 1010e14:	jmp    1010de4 <myl_native_arena_alloc+0x784>
 1010e16:	vpxor  %xmm0,%xmm0,%xmm0
 1010e1a:	vmovdqu %xmm0,0xc0(%rbx)
 1010e22:	mov    $0x1,%edi
 1010e27:	mov    %r12,%rsi
 1010e2a:	call   101ef80 <calloc@plt>
 1010e2f:	test   %rax,%rax
 1010e32:	je     1010c0d <myl_native_arena_alloc+0x5ad>
 1010e38:	mov    %rax,%r12
 1010e3b:	mov    0x18(%rbx),%rax
 1010e3f:	mov    %rax,-0x68(%rbp)
 1010e43:	mov    -0x60(%rbp),%rcx
 1010e47:	jmp    1010c59 <myl_native_arena_alloc+0x5f9>
 1010e4c:	cmpq   $0x0,0xc0(%rbx)
 1010e54:	je     101068d <myl_native_arena_alloc+0x2d>
 1010e5a:	mov    %rbx,%rdi
 1010e5d:	call   10105f0 <myl_native_arena_reclaim>
 1010e62:	mov    $0x1,%edi
 1010e67:	mov    %r14,%rsi
 1010e6a:	call   101ef80 <calloc@plt>
 1010e6f:	test   %rax,%rax
 1010e72:	jne    1010bb8 <myl_native_arena_alloc+0x558>
 1010e78:	jmp    101068d <myl_native_arena_alloc+0x2d>
 1010e7d:	int3
 1010e7e:	int3
 1010e7f:	int3

0000000001010e80 <myl_native_arena_trace>:
 1010e80:	push   %rbp
 1010e81:	mov    %rsp,%rbp
 1010e84:	push   %r15
 1010e86:	push   %r14
 1010e88:	push   %r13
 1010e8a:	push   %r12
 1010e8c:	push   %rbx
 1010e8d:	sub    $0x38,%rsp
 1010e91:	mov    %rsi,%r8
 1010e94:	mov    %rdi,%r12
 1010e97:	mov    0x11a0(%rdi),%rax
 1010e9e:	test   %rax,%rax
 1010ea1:	je     1010ed0 <myl_native_arena_trace+0x50>
 1010ea3:	mov    0x5c0(%r12),%rcx
 1010eab:	sub    %rax,%rcx
 1010eae:	add    $0xffffffffffffffb0,%rcx
 1010eb2:	mov    %rcx,0x10(%rax)
 1010eb6:	movq   $0x0,0x11a0(%r12)
 1010ec2:	vxorps %xmm0,%xmm0,%xmm0
 1010ec6:	vmovups %xmm0,0x5c0(%r12)
 1010ed0:	mov    0x11e8(%r12),%rax
 1010ed8:	test   %rax,%rax
 1010edb:	je     1011000 <myl_native_arena_trace+0x180>
 1010ee1:	xor    %edx,%edx
 1010ee3:	mov    $0x28,%esi
 1010ee8:	jmp    1010f08 <myl_native_arena_trace+0x88>
 1010eea:	nopw   0x0(%rax,%rax,1)
 1010ef0:	mov    0x11e8(%r12),%rax
 1010ef8:	mov    -0x30(%rbp),%rdx
 1010efc:	inc    %rdx
 1010eff:	cmp    %rax,%rdx
 1010f02:	jae    1011000 <myl_native_arena_trace+0x180>
 1010f08:	mov    0x4d8(%r12),%rcx
 1010f10:	mov    %rdx,-0x30(%rbp)
 1010f14:	mov    (%rcx,%rdx,8),%r9
 1010f18:	test   %r9,%r9
 1010f1b:	jne    1010f28 <myl_native_arena_trace+0xa8>
 1010f1d:	jmp    1010ef8 <myl_native_arena_trace+0x78>
 1010f1f:	nop
 1010f20:	mov    (%r9),%r9
 1010f23:	test   %r9,%r9
 1010f26:	je     1010ef0 <myl_native_arena_trace+0x70>
 1010f28:	mov    0x10(%r9),%rax
 1010f2c:	test   %rax,%rax
 1010f2f:	je     1010f20 <myl_native_arena_trace+0xa0>
 1010f31:	lea    0x50(%r9),%r10
 1010f35:	xor    %r11d,%r11d
 1010f38:	mov    %r9,-0x40(%rbp)
 1010f3c:	mov    %r10,-0x38(%rbp)
 1010f40:	jmp    1010f60 <myl_native_arena_trace+0xe0>
 1010f42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010f50:	add    %r14,%r11
 1010f53:	add    $0x1f,%r11
 1010f57:	and    $0xfffffffffffffff0,%r11
 1010f5b:	cmp    %rax,%r11
 1010f5e:	jae    1010f20 <myl_native_arena_trace+0xa0>
 1010f60:	mov    0x8(%r10,%r11,1),%r15
 1010f65:	bzhi   %rsi,(%r10,%r11,1),%rbx
 1010f6b:	shr    $0x2,%rbx
 1010f6f:	mov    (%r15),%r14
 1010f72:	imul   %rbx,%r14
 1010f76:	cmp    $0x1,%r14
 1010f7a:	adc    $0x0,%r14
 1010f7e:	cmpw   $0x0,0x30(%r15)
 1010f84:	je     1010f50 <myl_native_arena_trace+0xd0>
 1010f86:	cmpl   $0x1,0x58(%r15)
 1010f8b:	setne  %cl
 1010f8e:	test   %rbx,%rbx
 1010f91:	setne  %dl
 1010f94:	and    %cl,%dl
 1010f96:	cmp    $0x1,%dl
 1010f99:	jne    1010f50 <myl_native_arena_trace+0xd0>
 1010f9b:	mov    %r14,-0x48(%rbp)
 1010f9f:	mov    %r11,-0x50(%rbp)
 1010fa3:	lea    (%r10,%r11,1),%rax
 1010fa7:	add    $0x10,%rax
 1010fab:	mov    %rax,-0x58(%rbp)
 1010faf:	xor    %r13d,%r13d
 1010fb2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1010fc0:	mov    (%r15),%rdx
 1010fc3:	imul   %r13,%rdx
 1010fc7:	add    -0x58(%rbp),%rdx
 1010fcb:	mov    %r12,%rdi
 1010fce:	mov    %r15,%rsi
 1010fd1:	mov    %r8,%r14
 1010fd4:	call   *%r8
 1010fd7:	mov    %r14,%r8
 1010fda:	inc    %r13
 1010fdd:	cmp    %r13,%rbx
 1010fe0:	jne    1010fc0 <myl_native_arena_trace+0x140>
 1010fe2:	mov    -0x40(%rbp),%r9
 1010fe6:	mov    0x10(%r9),%rax
 1010fea:	mov    $0x28,%esi
 1010fef:	mov    -0x38(%rbp),%r10
 1010ff3:	mov    -0x50(%rbp),%r11
 1010ff7:	mov    -0x48(%rbp),%r14
 1010ffb:	jmp    1010f50 <myl_native_arena_trace+0xd0>
 1011000:	add    $0x38,%rsp
 1011004:	pop    %rbx
 1011005:	pop    %r12
 1011007:	pop    %r13
 1011009:	pop    %r14
 101100b:	pop    %r15
 101100d:	pop    %rbp
 101100e:	ret
 101100f:	int3

0000000001011010 <myl_native_arena_discard>:
 1011010:	push   %rbp
 1011011:	mov    %rsp,%rbp
 1011014:	test   %rdi,%rdi
 1011017:	je     1011143 <myl_native_arena_discard+0x133>
 101101d:	cmpq   $0x0,0x1608(%rdi)
 1011025:	je     1011143 <myl_native_arena_discard+0x133>
 101102b:	mov    0x11a0(%rdi),%rax
 1011032:	test   %rax,%rax
 1011035:	je     1011060 <myl_native_arena_discard+0x50>
 1011037:	mov    0x5c0(%rdi),%rcx
 101103e:	sub    %rax,%rcx
 1011041:	add    $0xffffffffffffffb0,%rcx
 1011045:	mov    %rcx,0x10(%rax)
 1011049:	movq   $0x0,0x11a0(%rdi)
 1011054:	vxorps %xmm0,%xmm0,%xmm0
 1011058:	vmovups %xmm0,0x5c0(%rdi)
 1011060:	mov    0x11e8(%rdi),%r8
 1011067:	test   %r8,%r8
 101106a:	je     1011080 <myl_native_arena_discard+0x70>
 101106c:	mov    0x4d8(%rdi),%rax
 1011073:	test   $0x1,%r8b
 1011077:	jne    1011088 <myl_native_arena_discard+0x78>
 1011079:	xor    %edx,%edx
 101107b:	mov    %r8,%rcx
 101107e:	jmp    10110c5 <myl_native_arena_discard+0xb5>
 1011080:	xor    %esi,%esi
 1011082:	pop    %rbp
 1011083:	jmp    1011150 <rc_retire_chunks>
 1011088:	lea    -0x1(%r8),%rcx
 101108c:	mov    -0x8(%rax,%r8,8),%rsi
 1011091:	movq   $0x0,-0x8(%rax,%r8,8)
 101109a:	test   %rsi,%rsi
 101109d:	je     10110c3 <myl_native_arena_discard+0xb3>
 101109f:	xor    %r9d,%r9d
 10110a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10110b0:	mov    %rsi,%rdx
 10110b3:	mov    (%rsi),%rsi
 10110b6:	mov    %r9,(%rdx)
 10110b9:	mov    %rdx,%r9
 10110bc:	test   %rsi,%rsi
 10110bf:	jne    10110b0 <myl_native_arena_discard+0xa0>
 10110c1:	jmp    10110c5 <myl_native_arena_discard+0xb5>
 10110c3:	xor    %edx,%edx
 10110c5:	mov    %rdx,%rsi
 10110c8:	cmp    $0x1,%r8
 10110cc:	jne    10110ec <myl_native_arena_discard+0xdc>
 10110ce:	movq   $0x0,0x11e8(%rdi)
 10110d9:	pop    %rbp
 10110da:	jmp    1011150 <rc_retire_chunks>
 10110df:	nop
 10110e0:	mov    %rdx,%rsi
 10110e3:	mov    %rsi,%rdx
 10110e6:	add    $0xfffffffffffffffe,%rcx
 10110ea:	je     10110ce <myl_native_arena_discard+0xbe>
 10110ec:	mov    -0x8(%rax,%rcx,8),%rsi
 10110f1:	movq   $0x0,-0x8(%rax,%rcx,8)
 10110fa:	test   %rsi,%rsi
 10110fd:	je     1011111 <myl_native_arena_discard+0x101>
 10110ff:	nop
 1011100:	mov    (%rsi),%r8
 1011103:	mov    %rdx,(%rsi)
 1011106:	mov    %rsi,%rdx
 1011109:	mov    %r8,%rsi
 101110c:	test   %r8,%r8
 101110f:	jne    1011100 <myl_native_arena_discard+0xf0>
 1011111:	mov    -0x10(%rax,%rcx,8),%r8
 1011116:	movq   $0x0,-0x10(%rax,%rcx,8)
 101111f:	test   %r8,%r8
 1011122:	je     10110e0 <myl_native_arena_discard+0xd0>
 1011124:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011130:	mov    %r8,%rsi
 1011133:	mov    (%r8),%r8
 1011136:	mov    %rdx,(%rsi)
 1011139:	mov    %rsi,%rdx
 101113c:	test   %r8,%r8
 101113f:	jne    1011130 <myl_native_arena_discard+0x120>
 1011141:	jmp    10110e3 <myl_native_arena_discard+0xd3>
 1011143:	call   101267d <myl_rc_invariant_failed>
 1011148:	int3
 1011149:	int3
 101114a:	int3
 101114b:	int3
 101114c:	int3
 101114d:	int3
 101114e:	int3
 101114f:	int3

0000000001011150 <rc_retire_chunks>:
 1011150:	test   %rsi,%rsi
 1011153:	je     101125f <rc_retire_chunks+0x10f>
 1011159:	push   %rbp
 101115a:	mov    %rsp,%rbp
 101115d:	push   %r15
 101115f:	push   %r14
 1011161:	push   %rbx
 1011162:	push   %rax
 1011163:	mov    %rdi,%rbx
 1011166:	mov    $0x200000,%r14d
 101116c:	jmp    1011188 <rc_retire_chunks+0x38>
 101116e:	xchg   %ax,%ax
 1011170:	sub    %rcx,0x18(%rbx)
 1011174:	mov    %rsi,%rdi
 1011177:	call   101efd0 <free@plt>
 101117c:	mov    %r15,%rsi
 101117f:	test   %r15,%r15
 1011182:	je     1011255 <rc_retire_chunks+0x105>
 1011188:	mov    (%rsi),%r15
 101118b:	mov    0x18(%rsi),%rax
 101118f:	sub    %rax,0x40(%rbx)
 1011193:	mov    0x18(%rsi),%rax
 1011197:	add    %rax,0x80(%rbx)
 101119e:	vmovdqu 0xa8(%rbx),%xmm0
 10111a6:	vmovdqa -0xe35e(%rip),%xmm1        # 1002e50 <qbe_empty_registry+0xa8>
 10111ae:	vpinsrq $0x1,0x8(%rsi),%xmm1,%xmm1
 10111b5:	vpsubq %xmm1,%xmm0,%xmm0
 10111b9:	vmovdqu %xmm0,0xa8(%rbx)
 10111c1:	mov    0x58(%rbx),%rax
 10111c5:	cmp    $0x200000,%rax
 10111cb:	mov    $0x200000,%ecx
 10111d0:	cmovb  %rax,%rcx
 10111d4:	test   %rax,%rax
 10111d7:	mov    %rcx,%rdi
 10111da:	cmove  %r14,%rdi
 10111de:	cmpq   $0x0,0x1608(%rbx)
 10111e6:	cmove  %rcx,%rdi
 10111ea:	mov    0x8(%rsi),%rcx
 10111ee:	cmp    $0x100000,%rcx
 10111f5:	ja     1011170 <rc_retire_chunks+0x20>
 10111fb:	mov    0xc0(%rbx),%rax
 1011202:	cmp    $0x3,%rax
 1011206:	ja     1011170 <rc_retire_chunks+0x20>
 101120c:	mov    0xc8(%rbx),%rdx
 1011213:	sub    %rdx,%rdi
 1011216:	setbe  %r8b
 101121a:	cmp    %rdi,%rcx
 101121d:	seta   %dil
 1011221:	or     %r8b,%dil
 1011224:	jne    1011170 <rc_retire_chunks+0x20>
 101122a:	mov    0x4e0(%rbx),%rcx
 1011231:	mov    %rcx,(%rsi)
 1011234:	mov    %rsi,0x4e0(%rbx)
 101123b:	inc    %rax
 101123e:	mov    %rax,0xc0(%rbx)
 1011245:	add    0x8(%rsi),%rdx
 1011249:	mov    %rdx,0xc8(%rbx)
 1011250:	jmp    101117c <rc_retire_chunks+0x2c>
 1011255:	add    $0x8,%rsp
 1011259:	pop    %rbx
 101125a:	pop    %r14
 101125c:	pop    %r15
 101125e:	pop    %rbp
 101125f:	ret

0000000001011260 <myl_native_arena_release>:
 1011260:	push   %rbp
 1011261:	mov    %rsp,%rbp
 1011264:	push   %r15
 1011266:	push   %r14
 1011268:	push   %r13
 101126a:	push   %r12
 101126c:	push   %rbx
 101126d:	push   %rax
 101126e:	mov    %rdi,%rbx
 1011271:	mov    0x11a0(%rdi),%rax
 1011278:	test   %rax,%rax
 101127b:	je     10112a6 <myl_native_arena_release+0x46>
 101127d:	mov    0x5c0(%rbx),%rcx
 1011284:	sub    %rax,%rcx
 1011287:	add    $0xffffffffffffffb0,%rcx
 101128b:	mov    %rcx,0x10(%rax)
 101128f:	movq   $0x0,0x11a0(%rbx)
 101129a:	vpxor  %xmm0,%xmm0,%xmm0
 101129e:	vmovdqu %xmm0,0x5c0(%rbx)
 10112a6:	cmpq   $0x0,0x1608(%rbx)
 10112ae:	mov    %esi,%r15d
 10112b1:	mov    0x11e8(%rbx),%rcx
 10112b8:	je     10112e6 <myl_native_arena_release+0x86>
 10112ba:	cmp    %r15,%rcx
 10112bd:	jbe    1011453 <myl_native_arena_release+0x1f3>
 10112c3:	mov    0x4d8(%rbx),%rax
 10112ca:	mov    %ecx,%edx
 10112cc:	sub    %r15d,%edx
 10112cf:	lea    0x1(%r15),%r8
 10112d3:	test   $0x1,%dl
 10112d6:	jne    1011458 <myl_native_arena_release+0x1f8>
 10112dc:	xor    %edi,%edi
 10112de:	mov    %rcx,%rdx
 10112e1:	jmp    1011495 <myl_native_arena_release+0x235>
 10112e6:	cmp    %r15,%rcx
 10112e9:	jbe    101141d <myl_native_arena_release+0x1bd>
 10112ef:	mov    $0x200000,%r14d
 10112f5:	jmp    1011310 <myl_native_arena_release+0xb0>
 10112f7:	nopw   0x0(%rax,%rax,1)
 1011300:	mov    0x11e8(%rbx),%rcx
 1011307:	cmp    %r15,%rcx
 101130a:	jbe    101141d <myl_native_arena_release+0x1bd>
 1011310:	lea    -0x1(%rcx),%rax
 1011314:	mov    %rax,0x11e8(%rbx)
 101131b:	mov    0x4d8(%rbx),%rdx
 1011322:	mov    -0x8(%rdx,%rcx,8),%rdi
 1011327:	movq   $0x0,-0x8(%rdx,%rcx,8)
 1011330:	mov    %rax,%rcx
 1011333:	test   %rdi,%rdi
 1011336:	jne    101134d <myl_native_arena_release+0xed>
 1011338:	jmp    1011307 <myl_native_arena_release+0xa7>
 101133a:	nopw   0x0(%rax,%rax,1)
 1011340:	call   101efd0 <free@plt>
 1011345:	mov    %r12,%rdi
 1011348:	test   %r12,%r12
 101134b:	je     1011300 <myl_native_arena_release+0xa0>
 101134d:	mov    (%rdi),%r12
 1011350:	mov    0x8(%rdi),%rax
 1011354:	sub    %rax,0x18(%rbx)
 1011358:	mov    0x18(%rdi),%rax
 101135c:	sub    %rax,0x40(%rbx)
 1011360:	mov    0x18(%rdi),%rax
 1011364:	add    %rax,0x80(%rbx)
 101136b:	vmovdqu 0xa8(%rbx),%xmm0
 1011373:	vmovdqa -0xe52b(%rip),%xmm1        # 1002e50 <qbe_empty_registry+0xa8>
 101137b:	vpinsrq $0x1,0x8(%rdi),%xmm1,%xmm1
 1011382:	vpsubq %xmm1,%xmm0,%xmm0
 1011386:	vmovdqu %xmm0,0xa8(%rbx)
 101138e:	mov    0x58(%rbx),%rax
 1011392:	cmp    $0x200000,%rax
 1011398:	mov    $0x200000,%ecx
 101139d:	cmovb  %rax,%rcx
 10113a1:	test   %rax,%rax
 10113a4:	mov    %rcx,%rax
 10113a7:	cmove  %r14,%rax
 10113ab:	cmpq   $0x0,0x1608(%rbx)
 10113b3:	cmove  %rcx,%rax
 10113b7:	mov    0x8(%rdi),%rsi
 10113bb:	cmp    $0x100000,%rsi
 10113c2:	ja     1011340 <myl_native_arena_release+0xe0>
 10113c8:	mov    0xc0(%rbx),%rcx
 10113cf:	cmp    $0x3,%rcx
 10113d3:	ja     1011340 <myl_native_arena_release+0xe0>
 10113d9:	mov    0xc8(%rbx),%rdx
 10113e0:	sub    %rdx,%rax
 10113e3:	jbe    1011340 <myl_native_arena_release+0xe0>
 10113e9:	cmp    %rax,%rsi
 10113ec:	ja     1011340 <myl_native_arena_release+0xe0>
 10113f2:	mov    0x4e0(%rbx),%rax
 10113f9:	mov    %rax,(%rdi)
 10113fc:	mov    %rdi,0x4e0(%rbx)
 1011403:	inc    %rcx
 1011406:	mov    %rcx,0xc0(%rbx)
 101140d:	add    0x8(%rdi),%rdx
 1011411:	mov    %rdx,0xc8(%rbx)
 1011418:	jmp    1011345 <myl_native_arena_release+0xe5>
 101141d:	test   %rcx,%rcx
 1011420:	je     1011444 <myl_native_arena_release+0x1e4>
 1011422:	mov    0x4d8(%rbx),%rax
 1011429:	dec    %rcx
 101142c:	nopl   0x0(%rax)
 1011430:	cmpq   $0x0,(%rax,%rcx,8)
 1011435:	jne    1011444 <myl_native_arena_release+0x1e4>
 1011437:	mov    %rcx,0x11e8(%rbx)
 101143e:	add    $0xffffffffffffffff,%rcx
 1011442:	jb     1011430 <myl_native_arena_release+0x1d0>
 1011444:	add    $0x8,%rsp
 1011448:	pop    %rbx
 1011449:	pop    %r12
 101144b:	pop    %r13
 101144d:	pop    %r14
 101144f:	pop    %r15
 1011451:	pop    %rbp
 1011452:	ret
 1011453:	xor    %r14d,%r14d
 1011456:	jmp    10114a8 <myl_native_arena_release+0x248>
 1011458:	lea    -0x1(%rcx),%rdx
 101145c:	mov    -0x8(%rax,%rcx,8),%r9
 1011461:	movq   $0x0,-0x8(%rax,%rcx,8)
 101146a:	test   %r9,%r9
 101146d:	je     1011493 <myl_native_arena_release+0x233>
 101146f:	xor    %r10d,%r10d
 1011472:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011480:	mov    %r9,%rdi
 1011483:	mov    (%r9),%r9
 1011486:	mov    %r10,(%rdi)
 1011489:	mov    %rdi,%r10
 101148c:	test   %r9,%r9
 101148f:	jne    1011480 <myl_native_arena_release+0x220>
 1011491:	jmp    1011495 <myl_native_arena_release+0x235>
 1011493:	xor    %edi,%edi
 1011495:	mov    %rdi,%r14
 1011498:	cmp    %r8,%rcx
 101149b:	jne    1011553 <myl_native_arena_release+0x2f3>
 10114a1:	mov    %rdx,0x11e8(%rbx)
 10114a8:	mov    0x70(%rbx),%r12d
 10114ac:	cmp    $0x1,%esi
 10114af:	mov    %esi,%r13d
 10114b2:	adc    $0xffffffff,%r13d
 10114b6:	mov    %r13d,0x70(%rbx)
 10114ba:	mov    %rbx,%rdi
 10114bd:	call   1018ea0 <myl_rc_scopes_close_region>
 10114c2:	test   %r14,%r14
 10114c5:	je     1011505 <myl_native_arena_release+0x2a5>
 10114c7:	mov    %r14,%r15
 10114ca:	nopw   0x0(%rax,%rax,1)
 10114d0:	mov    %rbx,%rdi
 10114d3:	mov    %r15,%rsi
 10114d6:	mov    $0x1,%edx
 10114db:	call   1011670 <release_pass>
 10114e0:	mov    (%r15),%r15
 10114e3:	test   %r15,%r15
 10114e6:	jne    10114d0 <myl_native_arena_release+0x270>
 10114e8:	mov    %r14,%r15
 10114eb:	nopl   0x0(%rax,%rax,1)
 10114f0:	mov    %rbx,%rdi
 10114f3:	mov    %r15,%rsi
 10114f6:	xor    %edx,%edx
 10114f8:	call   1011670 <release_pass>
 10114fd:	mov    (%r15),%r15
 1011500:	test   %r15,%r15
 1011503:	jne    10114f0 <myl_native_arena_release+0x290>
 1011505:	mov    %rbx,%rdi
 1011508:	call   1016210 <myl_rc_drain>
 101150d:	cmp    %r13d,0x70(%rbx)
 1011511:	jne    10115b3 <myl_native_arena_release+0x353>
 1011517:	mov    %r12d,0x70(%rbx)
 101151b:	mov    %rbx,%rdi
 101151e:	mov    %r14,%rsi
 1011521:	add    $0x8,%rsp
 1011525:	pop    %rbx
 1011526:	pop    %r12
 1011528:	pop    %r13
 101152a:	pop    %r14
 101152c:	pop    %r15
 101152e:	pop    %rbp
 101152f:	jmp    1011150 <rc_retire_chunks>
 1011534:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1011540:	mov    %rdi,%r14
 1011543:	add    $0xfffffffffffffffe,%rdx
 1011547:	mov    %r14,%rdi
 101154a:	cmp    %r15,%rdx
 101154d:	jbe    10114a1 <myl_native_arena_release+0x241>
 1011553:	mov    -0x8(%rax,%rdx,8),%rcx
 1011558:	movq   $0x0,-0x8(%rax,%rdx,8)
 1011561:	test   %rcx,%rcx
 1011564:	je     1011581 <myl_native_arena_release+0x321>
 1011566:	cs nopw 0x0(%rax,%rax,1)
 1011570:	mov    (%rcx),%r8
 1011573:	mov    %rdi,(%rcx)
 1011576:	mov    %rcx,%rdi
 1011579:	mov    %r8,%rcx
 101157c:	test   %r8,%r8
 101157f:	jne    1011570 <myl_native_arena_release+0x310>
 1011581:	mov    -0x10(%rax,%rdx,8),%rcx
 1011586:	movq   $0x0,-0x10(%rax,%rdx,8)
 101158f:	test   %rcx,%rcx
 1011592:	je     1011540 <myl_native_arena_release+0x2e0>
 1011594:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10115a0:	mov    %rcx,%r14
 10115a3:	mov    (%rcx),%rcx
 10115a6:	mov    %rdi,(%r14)
 10115a9:	mov    %r14,%rdi
 10115ac:	test   %rcx,%rcx
 10115af:	jne    10115a0 <myl_native_arena_release+0x340>
 10115b1:	jmp    1011543 <myl_native_arena_release+0x2e3>
 10115b3:	call   101267d <myl_rc_invariant_failed>
 10115b8:	int3
 10115b9:	int3
 10115ba:	int3
 10115bb:	int3
 10115bc:	int3
 10115bd:	int3
 10115be:	int3
 10115bf:	int3

00000000010115c0 <myl_native_arena_destroy>:
 10115c0:	push   %rbp
 10115c1:	mov    %rsp,%rbp
 10115c4:	push   %rbx
 10115c5:	push   %rax
 10115c6:	mov    %rdi,%rbx
 10115c9:	xor    %esi,%esi
 10115cb:	call   1011260 <myl_native_arena_release>
 10115d0:	jmp    10115e5 <myl_native_arena_destroy+0x25>
 10115d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10115e0:	call   101efd0 <free@plt>
 10115e5:	mov    0x4e0(%rbx),%rdi
 10115ec:	test   %rdi,%rdi
 10115ef:	je     101160f <myl_native_arena_destroy+0x4f>
 10115f1:	mov    (%rdi),%rax
 10115f4:	mov    %rax,0x4e0(%rbx)
 10115fb:	cmpq   $0x0,0x1608(%rbx)
 1011603:	je     10115e0 <myl_native_arena_destroy+0x20>
 1011605:	mov    0x8(%rdi),%rax
 1011609:	sub    %rax,0x18(%rbx)
 101160d:	jmp    10115e0 <myl_native_arena_destroy+0x20>
 101160f:	vxorps %xmm0,%xmm0,%xmm0
 1011613:	vmovups %xmm0,0xc0(%rbx)
 101161b:	cmpq   $0x0,0x1608(%rbx)
 1011623:	mov    0x4d8(%rbx),%rsi
 101162a:	je     1011641 <myl_native_arena_destroy+0x81>
 101162c:	mov    0x11f0(%rbx),%rdx
 1011633:	shl    $0x3,%rdx
 1011637:	mov    %rbx,%rdi
 101163a:	call   1012710 <myl_rc_meta_free>
 101163f:	jmp    1011649 <myl_native_arena_destroy+0x89>
 1011641:	mov    %rsi,%rdi
 1011644:	call   101efd0 <free@plt>
 1011649:	movq   $0x0,0x4d8(%rbx)
 1011654:	movq   $0x0,0x11f0(%rbx)
 101165f:	add    $0x8,%rsp
 1011663:	pop    %rbx
 1011664:	pop    %rbp
 1011665:	ret
 1011666:	int3
 1011667:	int3
 1011668:	int3
 1011669:	int3
 101166a:	int3
 101166b:	int3
 101166c:	int3
 101166d:	int3
 101166e:	int3
 101166f:	int3

0000000001011670 <release_pass>:
 1011670:	push   %rbp
 1011671:	mov    %rsp,%rbp
 1011674:	push   %r15
 1011676:	push   %r14
 1011678:	push   %r13
 101167a:	push   %r12
 101167c:	push   %rbx
 101167d:	push   %rax
 101167e:	cmpq   $0x0,0x10(%rsi)
 1011683:	je     101178d <release_pass+0x11d>
 1011689:	mov    %edx,%ebx
 101168b:	mov    %rsi,%r14
 101168e:	lea    0x50(%rsi),%r12
 1011692:	xor    %r13d,%r13d
 1011695:	mov    $0x28,%r8d
 101169b:	mov    %rdi,-0x30(%rbp)
 101169f:	jmp    10116d5 <release_pass+0x65>
 10116a1:	mov    0x8(%rax),%rsi
 10116a5:	add    $0x10,%rdx
 10116a9:	call   1015bb0 <myl_rc_edges_release>
 10116ae:	mov    -0x30(%rbp),%rdi
 10116b2:	mov    $0x28,%r8d
 10116b8:	nopl   0x0(%rax,%rax,1)
 10116c0:	add    %r15,%r13
 10116c3:	add    $0x1f,%r13
 10116c7:	and    $0xfffffffffffffff0,%r13
 10116cb:	cmp    0x10(%r14),%r13
 10116cf:	jae    101178d <release_pass+0x11d>
 10116d5:	mov    (%r12,%r13,1),%rax
 10116d9:	mov    0x8(%r12,%r13,1),%rsi
 10116de:	bzhi   %r8,%rax,%rcx
 10116e3:	shr    $0x2,%rcx
 10116e7:	mov    (%rsi),%r15
 10116ea:	imul   %rcx,%r15
 10116ee:	cmp    $0x1,%r15
 10116f2:	adc    $0x0,%r15
 10116f6:	test   %ebx,%ebx
 10116f8:	je     10116ff <release_pass+0x8f>
 10116fa:	and    $0x1,%eax
 10116fd:	jne    10116c0 <release_pass+0x50>
 10116ff:	mov    0x1608(%rdi),%rdx
 1011706:	mov    0x34(%rsi),%eax
 1011709:	cmp    %rax,0xa0(%rdx)
 1011710:	jbe    101177e <release_pass+0x10e>
 1011712:	mov    0x98(%rdx),%rdx
 1011719:	shl    $0x4,%rax
 101171d:	cmp    %rsi,(%rdx,%rax,1)
 1011721:	jne    101177e <release_pass+0x10e>
 1011723:	add    %rax,%rdx
 1011726:	mov    0x8(%rdx),%rax
 101172a:	test   %rax,%rax
 101172d:	je     1011788 <release_pass+0x118>
 101172f:	lea    (%r12,%r13,1),%rdx
 1011733:	test   %ebx,%ebx
 1011735:	je     101175f <release_pass+0xef>
 1011737:	orb    $0x1,(%rdx)
 101173a:	mov    0x18(%rax),%rax
 101173e:	test   %rax,%rax
 1011741:	je     10116c0 <release_pass+0x50>
 1011747:	add    $0x10,%rdx
 101174b:	mov    %rdx,%rsi
 101174e:	call   *%rax
 1011750:	mov    $0x28,%r8d
 1011756:	mov    -0x30(%rbp),%rdi
 101175a:	jmp    10116c0 <release_pass+0x50>
 101175f:	mov    0x10(%rax),%r8
 1011763:	test   %r8,%r8
 1011766:	je     10116a1 <release_pass+0x31>
 101176c:	add    $0x10,%rdx
 1011770:	mov    %rdx,%rsi
 1011773:	mov    %rcx,%rdx
 1011776:	call   *%r8
 1011779:	jmp    10116ae <release_pass+0x3e>
 101177e:	call   10130fa <myl_rc_binding_find_slow>
 1011783:	test   %rax,%rax
 1011786:	jne    101172f <release_pass+0xbf>
 1011788:	call   101267d <myl_rc_invariant_failed>
 101178d:	add    $0x8,%rsp
 1011791:	pop    %rbx
 1011792:	pop    %r12
 1011794:	pop    %r13
 1011796:	pop    %r14
 1011798:	pop    %r15
 101179a:	pop    %rbp
 101179b:	ret
 101179c:	int3
 101179d:	int3
 101179e:	int3
 101179f:	int3

00000000010117a0 <myl_native_list_new>:
 10117a0:	push   %rbp
 10117a1:	mov    %rsp,%rbp
 10117a4:	push   %r15
 10117a6:	push   %r14
 10117a8:	push   %rbx
 10117a9:	sub    $0x28,%rsp
 10117ad:	test   %rsi,%rsi
 10117b0:	je     101186a <myl_native_list_new+0xca>
 10117b6:	mov    %rdi,%rbx
 10117b9:	test   %rdi,%rdi
 10117bc:	je     10117e0 <myl_native_list_new+0x40>
 10117be:	cmpq   $0x0,0x1608(%rbx)
 10117c6:	je     10117e0 <myl_native_list_new+0x40>
 10117c8:	mov    0x70(%rbx),%ecx
 10117cb:	mov    %rbx,%rdi
 10117ce:	xor    %r8d,%r8d
 10117d1:	add    $0x28,%rsp
 10117d5:	pop    %rbx
 10117d6:	pop    %r14
 10117d8:	pop    %r15
 10117da:	pop    %rbp
 10117db:	jmp    1011880 <rc_list_new>
 10117e0:	mov    %rsi,%r15
 10117e3:	mov    %rdx,%r14
 10117e6:	lea    0x1794b(%rip),%rsi        # 1029138 <myl_native_list_header_descriptor>
 10117ed:	mov    $0x1,%edx
 10117f2:	mov    %rbx,%rdi
 10117f5:	call   100fe10 <myl_native_heap_alloc>
 10117fa:	mov    %rax,-0x20(%rbp)
 10117fe:	test   %rax,%rax
 1011801:	je     101186a <myl_native_list_new+0xca>
 1011803:	lea    -0xe63a(%rip),%rcx        # 10031d0 <myl_rc_pointer_leaf>
 101180a:	lea    -0x40(%rbp),%rsi
 101180e:	lea    -0x20(%rbp),%rdx
 1011812:	mov    %rbx,%rdi
 1011815:	call   100ed90 <myl_native_root_push>
 101181a:	mov    -0x20(%rbp),%rdx
 101181e:	mov    %r15,0x18(%rdx)
 1011822:	mov    %r14,%rcx
 1011825:	test   %r14,%r14
 1011828:	je     1011848 <myl_native_list_new+0xa8>
 101182a:	mov    %r15,%rsi
 101182d:	mov    %rbx,%rdi
 1011830:	mov    %r14,%rdx
 1011833:	call   100fe10 <myl_native_heap_alloc>
 1011838:	mov    %r14,%rcx
 101183b:	mov    -0x20(%rbp),%rdx
 101183f:	mov    %rax,0x20(%rdx)
 1011843:	test   %rax,%rax
 1011846:	je     101185e <myl_native_list_new+0xbe>
 1011848:	mov    %rcx,0x8(%rdx)
 101184c:	lea    -0x40(%rbp),%rsi
 1011850:	mov    %rbx,%rdi
 1011853:	call   100edb0 <myl_native_root_pop>
 1011858:	mov    -0x20(%rbp),%rax
 101185c:	jmp    101186c <myl_native_list_new+0xcc>
 101185e:	lea    -0x40(%rbp),%rsi
 1011862:	mov    %rbx,%rdi
 1011865:	call   100edb0 <myl_native_root_pop>
 101186a:	xor    %eax,%eax
 101186c:	add    $0x28,%rsp
 1011870:	pop    %rbx
 1011871:	pop    %r14
 1011873:	pop    %r15
 1011875:	pop    %rbp
 1011876:	ret
 1011877:	int3
 1011878:	int3
 1011879:	int3
 101187a:	int3
 101187b:	int3
 101187c:	int3
 101187d:	int3
 101187e:	int3
 101187f:	int3

0000000001011880 <rc_list_new>:
 1011880:	push   %rbp
 1011881:	mov    %rsp,%rbp
 1011884:	push   %r15
 1011886:	push   %r14
 1011888:	push   %r13
 101188a:	push   %r12
 101188c:	push   %rbx
 101188d:	push   %rax
 101188e:	mov    %r8d,%r13d
 1011891:	mov    %ecx,%r15d
 1011894:	mov    %rdx,%r14
 1011897:	mov    %rsi,%r12
 101189a:	mov    %rdi,%rbx
 101189d:	test   %r8d,%r8d
 10118a0:	je     10118c0 <rc_list_new+0x40>
 10118a2:	mov    0x1608(%rbx),%rax
 10118a9:	cmpb   $0x0,0x120(%rax)
 10118b0:	je     10118e5 <rc_list_new+0x65>
 10118b2:	test   %r13d,%r13d
 10118b5:	jne    1011917 <rc_list_new+0x97>
 10118b7:	lea    0x1787a(%rip),%rsi        # 1029138 <myl_native_list_header_descriptor>
 10118be:	jmp    101191e <rc_list_new+0x9e>
 10118c0:	mov    0x1608(%rbx),%rax
 10118c7:	cmp    %r12,0x110(%rax)
 10118ce:	je     10118a2 <rc_list_new+0x22>
 10118d0:	mov    %rbx,%rdi
 10118d3:	mov    %r12,%rsi
 10118d6:	call   101d7b0 <myl_rc_native_shape>
 10118db:	test   %rax,%rax
 10118de:	jne    10118a2 <rc_list_new+0x22>
 10118e0:	jmp    1011970 <rc_list_new+0xf0>
 10118e5:	lea    0x17964(%rip),%rsi        # 1029250 <rc_list_module>
 10118ec:	mov    %rbx,%rdi
 10118ef:	call   1013620 <myl_rc_module_register>
 10118f4:	test   %eax,%eax
 10118f6:	je     1011904 <rc_list_new+0x84>
 10118f8:	mov    %rbx,%rdi
 10118fb:	mov    %eax,%esi
 10118fd:	call   1012770 <myl_rc_record_failure>
 1011902:	jmp    1011970 <rc_list_new+0xf0>
 1011904:	mov    0x1608(%rbx),%rax
 101190b:	movb   $0x1,0x120(%rax)
 1011912:	test   %r13d,%r13d
 1011915:	je     10118b7 <rc_list_new+0x37>
 1011917:	lea    -0xe9de(%rip),%rsi        # 1002f40 <rc_storage_type>
 101191e:	mov    $0x1,%edx
 1011923:	mov    %rbx,%rdi
 1011926:	mov    %r15d,%ecx
 1011929:	call   101be60 <myl_rc_storage_alloc>
 101192e:	test   %rax,%rax
 1011931:	je     1011970 <rc_list_new+0xf0>
 1011933:	mov    %r12,0x18(%rax)
 1011937:	test   %r14,%r14
 101193a:	je     101195f <rc_list_new+0xdf>
 101193c:	mov    %rbx,%rdi
 101193f:	mov    %r12,%rsi
 1011942:	mov    %r14,%rdx
 1011945:	mov    %r15d,%ecx
 1011948:	mov    %rax,%r15
 101194b:	call   101e5e0 <myl_rc_native_storage>
 1011950:	mov    %rax,%rcx
 1011953:	mov    %r15,%rax
 1011956:	mov    %rcx,0x20(%r15)
 101195a:	test   %rcx,%rcx
 101195d:	je     1011965 <rc_list_new+0xe5>
 101195f:	mov    %r14,0x8(%rax)
 1011963:	jmp    1011972 <rc_list_new+0xf2>
 1011965:	mov    %rbx,%rdi
 1011968:	mov    %rax,%rsi
 101196b:	call   101e650 <myl_rc_native_abort>
 1011970:	xor    %eax,%eax
 1011972:	add    $0x8,%rsp
 1011976:	pop    %rbx
 1011977:	pop    %r12
 1011979:	pop    %r13
 101197b:	pop    %r14
 101197d:	pop    %r15
 101197f:	pop    %rbp
 1011980:	ret
 1011981:	int3
 1011982:	int3
 1011983:	int3
 1011984:	int3
 1011985:	int3
 1011986:	int3
 1011987:	int3
 1011988:	int3
 1011989:	int3
 101198a:	int3
 101198b:	int3
 101198c:	int3
 101198d:	int3
 101198e:	int3
 101198f:	int3

0000000001011990 <myl_rc_list_append>:
 1011990:	push   %rbp
 1011991:	mov    %rsp,%rbp
 1011994:	mov    %rdx,%rcx
 1011997:	mov    (%rsi),%rdx
 101199a:	pop    %rbp
 101199b:	jmp    1011d30 <rc_list_insert_at>

00000000010119a0 <rc_list_clone>:
 10119a0:	push   %rbp
 10119a1:	mov    %rsp,%rbp
 10119a4:	push   %r15
 10119a6:	push   %r14
 10119a8:	push   %r13
 10119aa:	push   %r12
 10119ac:	push   %rbx
 10119ad:	push   %rax
 10119ae:	mov    %rdx,%r15
 10119b1:	mov    %rsi,%r14
 10119b4:	mov    %rdi,%r12
 10119b7:	mov    (%rsi),%rdx
 10119ba:	mov    0x8(%rsi),%rax
 10119be:	cmp    %rdx,%rax
 10119c1:	cmova  %rax,%rdx
 10119c5:	mov    %r15,%rsi
 10119c8:	xor    %r8d,%r8d
 10119cb:	call   1011880 <rc_list_new>
 10119d0:	test   %rax,%rax
 10119d3:	je     1011a82 <rc_list_clone+0xe2>
 10119d9:	mov    %rax,%rbx
 10119dc:	mov    (%r14),%rax
 10119df:	test   %rax,%rax
 10119e2:	je     1011ab2 <rc_list_clone+0x112>
 10119e8:	mov    (%r15),%rdx
 10119eb:	test   %rdx,%rdx
 10119ee:	je     1011a49 <rc_list_clone+0xa9>
 10119f0:	mov    0x1608(%r12),%rcx
 10119f8:	cmp    %r15,0x110(%rcx)
 10119ff:	je     1011a9b <rc_list_clone+0xfb>
 1011a05:	mov    0x34(%r15),%eax
 1011a09:	cmp    %rax,0xa0(%rcx)
 1011a10:	jbe    1011acc <rc_list_clone+0x12c>
 1011a16:	mov    0x98(%rcx),%rcx
 1011a1d:	shl    $0x4,%rax
 1011a21:	cmp    %r15,(%rcx,%rax,1)
 1011a25:	jne    1011acc <rc_list_clone+0x12c>
 1011a2b:	add    %rax,%rcx
 1011a2e:	mov    0x8(%rcx),%rax
 1011a32:	test   %rax,%rax
 1011a35:	je     1011a43 <rc_list_clone+0xa3>
 1011a37:	cmpl   $0x0,0x40(%rax)
 1011a3b:	jne    1011a43 <rc_list_clone+0xa3>
 1011a3d:	cmpb   $0x0,0x45(%rax)
 1011a41:	je     1011a86 <rc_list_clone+0xe6>
 1011a43:	cmpq   $0x0,(%r14)
 1011a47:	je     1011ab2 <rc_list_clone+0x112>
 1011a49:	xor    %r13d,%r13d
 1011a4c:	nopl   0x0(%rax)
 1011a50:	mov    (%r15),%rcx
 1011a53:	imul   %r13,%rcx
 1011a57:	add    0x20(%r14),%rcx
 1011a5b:	mov    (%rbx),%rdx
 1011a5e:	mov    %r12,%rdi
 1011a61:	mov    %rbx,%rsi
 1011a64:	call   1011d30 <rc_list_insert_at>
 1011a69:	test   %eax,%eax
 1011a6b:	je     1011a77 <rc_list_clone+0xd7>
 1011a6d:	inc    %r13
 1011a70:	cmp    (%r14),%r13
 1011a73:	jb     1011a50 <rc_list_clone+0xb0>
 1011a75:	jmp    1011ab2 <rc_list_clone+0x112>
 1011a77:	mov    %r12,%rdi
 1011a7a:	mov    %rbx,%rsi
 1011a7d:	call   101e650 <myl_rc_native_abort>
 1011a82:	xor    %ebx,%ebx
 1011a84:	jmp    1011aba <rc_list_clone+0x11a>
 1011a86:	mov    0x1608(%r12),%rax
 1011a8e:	mov    %r15,0x110(%rax)
 1011a95:	mov    (%r14),%rax
 1011a98:	mov    (%r15),%rdx
 1011a9b:	imul   %rax,%rdx
 1011a9f:	mov    0x20(%rbx),%rdi
 1011aa3:	mov    0x20(%r14),%rsi
 1011aa7:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1011aac:	mov    (%r14),%rax
 1011aaf:	mov    %rax,(%rbx)
 1011ab2:	movq   $0x0,0x10(%rbx)
 1011aba:	mov    %rbx,%rax
 1011abd:	add    $0x8,%rsp
 1011ac1:	pop    %rbx
 1011ac2:	pop    %r12
 1011ac4:	pop    %r13
 1011ac6:	pop    %r14
 1011ac8:	pop    %r15
 1011aca:	pop    %rbp
 1011acb:	ret
 1011acc:	mov    %r12,%rdi
 1011acf:	mov    %r15,%rsi
 1011ad2:	call   10130fa <myl_rc_binding_find_slow>
 1011ad7:	test   %rax,%rax
 1011ada:	jne    1011a37 <rc_list_clone+0x97>
 1011ae0:	jmp    1011a43 <rc_list_clone+0xa3>
 1011ae5:	int3
 1011ae6:	int3
 1011ae7:	int3
 1011ae8:	int3
 1011ae9:	int3
 1011aea:	int3
 1011aeb:	int3
 1011aec:	int3
 1011aed:	int3
 1011aee:	int3
 1011aef:	int3

0000000001011af0 <myl_native_list_header>:
 1011af0:	test   %rdi,%rdi
 1011af3:	je     1011b0b <myl_native_list_header+0x1b>
 1011af5:	push   %rbp
 1011af6:	mov    %rsp,%rbp
 1011af9:	mov    -0x8(%rdi),%rcx
 1011afd:	xor    %eax,%eax
 1011aff:	cmp    $0x1029138,%rcx
 1011b06:	sete   %al
 1011b09:	pop    %rbp
 1011b0a:	ret
 1011b0b:	xor    %eax,%eax
 1011b0d:	ret
 1011b0e:	int3
 1011b0f:	int3

0000000001011b10 <myl_rc_list_require>:
 1011b10:	push   %rbp
 1011b11:	mov    %rsp,%rbp
 1011b14:	push   %rbx
 1011b15:	push   %rax
 1011b16:	mov    0x1608(%rdi),%rcx
 1011b1d:	xor    %eax,%eax
 1011b1f:	cmpb   $0x0,0x120(%rcx)
 1011b26:	jne    1011b4b <myl_rc_list_require+0x3b>
 1011b28:	lea    0x17721(%rip),%rsi        # 1029250 <rc_list_module>
 1011b2f:	mov    %rdi,%rbx
 1011b32:	call   1013620 <myl_rc_module_register>
 1011b37:	test   %eax,%eax
 1011b39:	jne    1011b4b <myl_rc_list_require+0x3b>
 1011b3b:	mov    0x1608(%rbx),%rax
 1011b42:	movb   $0x1,0x120(%rax)
 1011b49:	xor    %eax,%eax
 1011b4b:	add    $0x8,%rsp
 1011b4f:	pop    %rbx
 1011b50:	pop    %rbp
 1011b51:	ret
 1011b52:	int3
 1011b53:	int3
 1011b54:	int3
 1011b55:	int3
 1011b56:	int3
 1011b57:	int3
 1011b58:	int3
 1011b59:	int3
 1011b5a:	int3
 1011b5b:	int3
 1011b5c:	int3
 1011b5d:	int3
 1011b5e:	int3
 1011b5f:	int3

0000000001011b60 <myl_rc_list_storage_reserve>:
 1011b60:	mov    0x8(%rsi),%rcx
 1011b64:	mov    $0x1,%eax
 1011b69:	cmp    %rcx,%rdx
 1011b6c:	jbe    1011d12 <myl_rc_list_storage_reserve+0x1b2>
 1011b72:	push   %rbp
 1011b73:	mov    %rsp,%rbp
 1011b76:	push   %r15
 1011b78:	push   %r14
 1011b7a:	push   %r13
 1011b7c:	push   %r12
 1011b7e:	push   %rbx
 1011b7f:	push   %rax
 1011b80:	mov    %rsi,%rbx
 1011b83:	cmp    $0x5,%rcx
 1011b87:	mov    $0x4,%r14d
 1011b8d:	cmovae %rcx,%r14
 1011b91:	cmp    $0x5,%rdx
 1011b95:	jb     1011bb1 <myl_rc_list_storage_reserve+0x51>
 1011b97:	nopw   0x0(%rax,%rax,1)
 1011ba0:	test   %r14,%r14
 1011ba3:	js     1011d02 <myl_rc_list_storage_reserve+0x1a2>
 1011ba9:	add    %r14,%r14
 1011bac:	cmp    %rdx,%r14
 1011baf:	jb     1011ba0 <myl_rc_list_storage_reserve+0x40>
 1011bb1:	mov    0x18(%rbx),%rsi
 1011bb5:	mov    (%rsi),%rcx
 1011bb8:	test   %rcx,%rcx
 1011bbb:	je     1011bc9 <myl_rc_list_storage_reserve+0x69>
 1011bbd:	mov    %rcx,%rax
 1011bc0:	mul    %r14
 1011bc3:	jo     1011d02 <myl_rc_list_storage_reserve+0x1a2>
 1011bc9:	mov    0x20(%rbx),%r15
 1011bcd:	mov    0x1608(%rdi),%rdx
 1011bd4:	cmp    %rsi,0x110(%rdx)
 1011bdb:	je     1011c7a <myl_rc_list_storage_reserve+0x11a>
 1011be1:	mov    0x34(%rsi),%eax
 1011be4:	cmp    %rax,0xa0(%rdx)
 1011beb:	jbe    1011d13 <myl_rc_list_storage_reserve+0x1b3>
 1011bf1:	mov    0x98(%rdx),%rcx
 1011bf8:	shl    $0x4,%rax
 1011bfc:	cmp    %rsi,(%rcx,%rax,1)
 1011c00:	jne    1011d13 <myl_rc_list_storage_reserve+0x1b3>
 1011c06:	add    %rax,%rcx
 1011c09:	mov    0x8(%rcx),%rax
 1011c0d:	test   %rax,%rax
 1011c10:	je     1011c1e <myl_rc_list_storage_reserve+0xbe>
 1011c12:	cmpl   $0x0,0x40(%rax)
 1011c16:	jne    1011c1e <myl_rc_list_storage_reserve+0xbe>
 1011c18:	cmpb   $0x0,0x45(%rax)
 1011c1c:	je     1011c65 <myl_rc_list_storage_reserve+0x105>
 1011c1e:	mov    0x18(%rbx),%rax
 1011c22:	mov    (%rax),%rdx
 1011c25:	imul   %r14,%rdx
 1011c29:	mov    %rdi,%r12
 1011c2c:	mov    %r15,%rsi
 1011c2f:	call   101cad0 <myl_rc_storage_extend>
 1011c34:	test   %rax,%rax
 1011c37:	jne    1011c91 <myl_rc_list_storage_reserve+0x131>
 1011c39:	mov    -0x10(%rbx),%rax
 1011c3d:	mov    0x18(%rbx),%rsi
 1011c41:	mov    %rax,%rdx
 1011c44:	shr    $0x28,%rdx
 1011c48:	and    $0xfffff,%edx
 1011c4e:	xor    %ecx,%ecx
 1011c50:	bt     $0x3e,%rax
 1011c55:	cmovb  %edx,%ecx
 1011c58:	mov    %r12,%rdi
 1011c5b:	mov    %r14,%rdx
 1011c5e:	call   101e5e0 <myl_rc_native_storage>
 1011c63:	jmp    1011cc5 <myl_rc_list_storage_reserve+0x165>
 1011c65:	mov    0x1608(%rdi),%rax
 1011c6c:	mov    %rsi,0x110(%rax)
 1011c73:	mov    0x18(%rbx),%rax
 1011c77:	mov    (%rax),%rcx
 1011c7a:	imul   %r14,%rcx
 1011c7e:	mov    %rdi,%r12
 1011c81:	mov    %r15,%rsi
 1011c84:	mov    %rcx,%rdx
 1011c87:	call   101cc90 <myl_rc_storage_extend_opaque>
 1011c8c:	test   %rax,%rax
 1011c8f:	je     1011c97 <myl_rc_list_storage_reserve+0x137>
 1011c91:	mov    %rax,0x20(%rbx)
 1011c95:	jmp    1011cf7 <myl_rc_list_storage_reserve+0x197>
 1011c97:	mov    -0x10(%rbx),%rax
 1011c9b:	mov    0x18(%rbx),%rcx
 1011c9f:	mov    (%rcx),%rsi
 1011ca2:	imul   %r14,%rsi
 1011ca6:	mov    %rax,%rcx
 1011ca9:	shr    $0x28,%rcx
 1011cad:	and    $0xfffff,%ecx
 1011cb3:	xor    %edx,%edx
 1011cb5:	bt     $0x3e,%rax
 1011cba:	cmovb  %ecx,%edx
 1011cbd:	mov    %r12,%rdi
 1011cc0:	call   101cac0 <myl_rc_storage_block>
 1011cc5:	mov    %rax,%r13
 1011cc8:	test   %rax,%rax
 1011ccb:	je     1011d02 <myl_rc_list_storage_reserve+0x1a2>
 1011ccd:	mov    (%rbx),%rdx
 1011cd0:	test   %rdx,%rdx
 1011cd3:	je     1011ce8 <myl_rc_list_storage_reserve+0x188>
 1011cd5:	mov    0x18(%rbx),%rax
 1011cd9:	imul   (%rax),%rdx
 1011cdd:	mov    %r13,%rdi
 1011ce0:	mov    %r15,%rsi
 1011ce3:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1011ce8:	mov    %r13,0x20(%rbx)
 1011cec:	mov    %r12,%rdi
 1011cef:	mov    %r15,%rsi
 1011cf2:	call   1012cd0 <myl_rc_owner_release>
 1011cf7:	mov    $0x1,%eax
 1011cfc:	mov    %r14,0x8(%rbx)
 1011d00:	jmp    1011d04 <myl_rc_list_storage_reserve+0x1a4>
 1011d02:	xor    %eax,%eax
 1011d04:	add    $0x8,%rsp
 1011d08:	pop    %rbx
 1011d09:	pop    %r12
 1011d0b:	pop    %r13
 1011d0d:	pop    %r14
 1011d0f:	pop    %r15
 1011d11:	pop    %rbp
 1011d12:	ret
 1011d13:	call   10130fa <myl_rc_binding_find_slow>
 1011d18:	test   %rax,%rax
 1011d1b:	jne    1011c12 <myl_rc_list_storage_reserve+0xb2>
 1011d21:	jmp    1011c1e <myl_rc_list_storage_reserve+0xbe>
 1011d26:	int3
 1011d27:	int3
 1011d28:	int3
 1011d29:	int3
 1011d2a:	int3
 1011d2b:	int3
 1011d2c:	int3
 1011d2d:	int3
 1011d2e:	int3
 1011d2f:	int3

0000000001011d30 <rc_list_insert_at>:
 1011d30:	push   %rbp
 1011d31:	mov    %rsp,%rbp
 1011d34:	push   %r15
 1011d36:	push   %r14
 1011d38:	push   %r13
 1011d3a:	push   %r12
 1011d3c:	push   %rbx
 1011d3d:	sub    $0xa8,%rsp
 1011d44:	xor    %r12d,%r12d
 1011d47:	cmpq   $0xffffffffffffffff,0x10(%rsi)
 1011d4c:	je     1011ef4 <rc_list_insert_at+0x1c4>
 1011d52:	mov    %rsi,%rbx
 1011d55:	mov    (%rsi),%r15
 1011d58:	cmp    $0xffffffffffffffff,%r15
 1011d5c:	je     1011ef4 <rc_list_insert_at+0x1c4>
 1011d62:	mov    0x18(%rbx),%rax
 1011d66:	mov    (%rax),%rsi
 1011d69:	cmp    %r15,%rdx
 1011d6c:	mov    %rdx,-0x50(%rbp)
 1011d70:	mov    %rdi,-0x38(%rbp)
 1011d74:	jne    1011d90 <rc_list_insert_at+0x60>
 1011d76:	test   %rsi,%rsi
 1011d79:	je     1011dd2 <rc_list_insert_at+0xa2>
 1011d7b:	mov    0x1608(%rdi),%rax
 1011d82:	cmpq   $0x0,0xc8(%rax)
 1011d8a:	je     1011f09 <rc_list_insert_at+0x1d9>
 1011d90:	cmp    $0x81,%rsi
 1011d97:	jae    1011da6 <rc_list_insert_at+0x76>
 1011d99:	lea    -0xd0(%rbp),%rax
 1011da0:	mov    %rax,-0x40(%rbp)
 1011da4:	jmp    1011ddf <rc_list_insert_at+0xaf>
 1011da6:	mov    %rcx,%r14
 1011da9:	xor    %r12d,%r12d
 1011dac:	mov    %rsi,%r13
 1011daf:	xor    %edx,%edx
 1011db1:	call   101c8e0 <myl_rc_storage_bytes>
 1011db6:	mov    %rax,-0x40(%rbp)
 1011dba:	test   %rax,%rax
 1011dbd:	je     1011ef4 <rc_list_insert_at+0x1c4>
 1011dc3:	mov    (%rbx),%r15
 1011dc6:	mov    %r14,%rcx
 1011dc9:	mov    -0x38(%rbp),%rdi
 1011dcd:	mov    %r13,%rsi
 1011dd0:	jmp    1011ddf <rc_list_insert_at+0xaf>
 1011dd2:	lea    -0xd0(%rbp),%rax
 1011dd9:	mov    %rax,-0x40(%rbp)
 1011ddd:	xor    %esi,%esi
 1011ddf:	mov    %rsi,-0x30(%rbp)
 1011de3:	mov    -0x10(%rbx),%rax
 1011de7:	mov    0x20(%rbx),%rdx
 1011deb:	mov    %rax,%r14
 1011dee:	shr    $0x28,%r14
 1011df2:	and    $0xfffff,%r14d
 1011df9:	xor    %r12d,%r12d
 1011dfc:	bt     $0x3e,%rax
 1011e01:	cmovae %r12d,%r14d
 1011e05:	test   %rdx,%rdx
 1011e08:	sete   %al
 1011e0b:	mov    %rcx,-0x48(%rbp)
 1011e0f:	mov    %rcx,%r13
 1011e12:	sub    %rdx,%r13
 1011e15:	setb   %cl
 1011e18:	or     %al,%cl
 1011e1a:	je     1011e33 <rc_list_insert_at+0x103>
 1011e1c:	inc    %r15
 1011e1f:	mov    %rbx,%rsi
 1011e22:	mov    %r15,%rdx
 1011e25:	call   1011b60 <myl_rc_list_storage_reserve>
 1011e2a:	test   %eax,%eax
 1011e2c:	jne    1011e59 <rc_list_insert_at+0x129>
 1011e2e:	jmp    1011ed8 <rc_list_insert_at+0x1a8>
 1011e33:	lea    0x1(%r15),%rdx
 1011e37:	mov    %rbx,%rsi
 1011e3a:	call   1011b60 <myl_rc_list_storage_reserve>
 1011e3f:	test   %eax,%eax
 1011e41:	je     1011ed8 <rc_list_insert_at+0x1a8>
 1011e47:	imul   -0x30(%rbp),%r15
 1011e4c:	cmp    %r15,%r13
 1011e4f:	jae    1011e59 <rc_list_insert_at+0x129>
 1011e51:	add    0x20(%rbx),%r13
 1011e55:	mov    %r13,-0x48(%rbp)
 1011e59:	mov    0x18(%rbx),%rsi
 1011e5d:	mov    -0x38(%rbp),%rdi
 1011e61:	mov    -0x40(%rbp),%r13
 1011e65:	mov    %r13,%rdx
 1011e68:	mov    -0x48(%rbp),%rcx
 1011e6c:	mov    %r14d,%r8d
 1011e6f:	call   101e0d0 <myl_rc_native_retain>
 1011e74:	test   %eax,%eax
 1011e76:	je     1011edc <rc_list_insert_at+0x1ac>
 1011e78:	mov    %eax,%r14d
 1011e7b:	mov    (%rbx),%rdx
 1011e7e:	mov    0x20(%rbx),%r15
 1011e82:	mov    -0x50(%rbp),%rax
 1011e86:	sub    %rax,%rdx
 1011e89:	jbe    1011eb1 <rc_list_insert_at+0x181>
 1011e8b:	lea    0x1(%rax),%rdi
 1011e8f:	mov    -0x30(%rbp),%rcx
 1011e93:	imul   %rcx,%rdi
 1011e97:	add    %r15,%rdi
 1011e9a:	mov    %rcx,%rsi
 1011e9d:	imul   %rax,%rsi
 1011ea1:	add    %r15,%rsi
 1011ea4:	imul   %rcx,%rdx
 1011ea8:	call   101e820 <compiler_rt.memmove.memmoveFast>
 1011ead:	mov    -0x50(%rbp),%rax
 1011eb1:	mov    -0x30(%rbp),%rdx
 1011eb5:	test   %rdx,%rdx
 1011eb8:	je     1011ecc <rc_list_insert_at+0x19c>
 1011eba:	imul   %rdx,%rax
 1011ebe:	add    %rax,%r15
 1011ec1:	mov    %r15,%rdi
 1011ec4:	mov    %r13,%rsi
 1011ec7:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1011ecc:	incq   (%rbx)
 1011ecf:	incq   0x10(%rbx)
 1011ed3:	mov    %r14d,%r12d
 1011ed6:	jmp    1011edc <rc_list_insert_at+0x1ac>
 1011ed8:	mov    -0x40(%rbp),%r13
 1011edc:	lea    -0xd0(%rbp),%rax
 1011ee3:	cmp    %rax,%r13
 1011ee6:	je     1011ef4 <rc_list_insert_at+0x1c4>
 1011ee8:	mov    -0x38(%rbp),%rdi
 1011eec:	mov    %r13,%rsi
 1011eef:	call   1012cd0 <myl_rc_owner_release>
 1011ef4:	mov    %r12d,%eax
 1011ef7:	add    $0xa8,%rsp
 1011efe:	pop    %rbx
 1011eff:	pop    %r12
 1011f01:	pop    %r13
 1011f03:	pop    %r14
 1011f05:	pop    %r15
 1011f07:	pop    %rbp
 1011f08:	ret
 1011f09:	mov    0x20(%rbx),%rax
 1011f0d:	mov    %rsi,%r14
 1011f10:	imul   %rdx,%r14
 1011f14:	test   %rax,%rax
 1011f17:	sete   %r8b
 1011f1b:	mov    %rcx,%r13
 1011f1e:	sub    %rax,%r13
 1011f21:	setb   %al
 1011f24:	or     %r8b,%al
 1011f27:	je     1011f4e <rc_list_insert_at+0x21e>
 1011f29:	mov    %rsi,%r13
 1011f2c:	mov    %rcx,%r15
 1011f2f:	inc    %rdx
 1011f32:	mov    %rbx,%rsi
 1011f35:	call   1011b60 <myl_rc_list_storage_reserve>
 1011f3a:	test   %eax,%eax
 1011f3c:	je     1011ef4 <rc_list_insert_at+0x1c4>
 1011f3e:	mov    0x20(%rbx),%rdx
 1011f42:	mov    %r15,%rcx
 1011f45:	mov    -0x38(%rbp),%rdi
 1011f49:	mov    %r13,%r9
 1011f4c:	jmp    1011fa3 <rc_list_insert_at+0x273>
 1011f4e:	cmp    %r14,%r13
 1011f51:	setb   %r8b
 1011f55:	jb     1011f68 <rc_list_insert_at+0x238>
 1011f57:	mov    0x8(%rbx),%rax
 1011f5b:	imul   %rsi,%rax
 1011f5f:	cmp    %rax,%r13
 1011f62:	jb     1011d90 <rc_list_insert_at+0x60>
 1011f68:	mov    %r8d,%r15d
 1011f6b:	mov    %rsi,-0x30(%rbp)
 1011f6f:	mov    %rcx,-0x48(%rbp)
 1011f73:	inc    %rdx
 1011f76:	mov    %rbx,%rsi
 1011f79:	call   1011b60 <myl_rc_list_storage_reserve>
 1011f7e:	test   %eax,%eax
 1011f80:	je     1011ef4 <rc_list_insert_at+0x1c4>
 1011f86:	mov    0x20(%rbx),%rdx
 1011f8a:	test   %r15b,%r15b
 1011f8d:	je     1011f97 <rc_list_insert_at+0x267>
 1011f8f:	add    %rdx,%r13
 1011f92:	mov    %r13,%rcx
 1011f95:	jmp    1011f9b <rc_list_insert_at+0x26b>
 1011f97:	mov    -0x48(%rbp),%rcx
 1011f9b:	mov    -0x38(%rbp),%rdi
 1011f9f:	mov    -0x30(%rbp),%r9
 1011fa3:	add    %r14,%rdx
 1011fa6:	lea    (%rcx,%r9,1),%rax
 1011faa:	cmp    %rdx,%rax
 1011fad:	jbe    1011fbc <rc_list_insert_at+0x28c>
 1011faf:	lea    (%r9,%rdx,1),%rax
 1011fb3:	cmp    %rcx,%rax
 1011fb6:	ja     1012075 <rc_list_insert_at+0x345>
 1011fbc:	mov    0x18(%rbx),%rsi
 1011fc0:	mov    0x1608(%rdi),%r8
 1011fc7:	cmp    %rsi,0x110(%r8)
 1011fce:	je     1012047 <rc_list_insert_at+0x317>
 1011fd0:	mov    0x34(%rsi),%eax
 1011fd3:	cmp    %rax,0xa0(%r8)
 1011fda:	jbe    1012069 <rc_list_insert_at+0x339>
 1011fe0:	mov    0x98(%r8),%r8
 1011fe7:	shl    $0x4,%rax
 1011feb:	cmp    %rsi,(%r8,%rax,1)
 1011fef:	jne    1012069 <rc_list_insert_at+0x339>
 1011ff1:	add    %rax,%r8
 1011ff4:	mov    0x8(%r8),%rax
 1011ff8:	test   %rax,%rax
 1011ffb:	je     1012009 <rc_list_insert_at+0x2d9>
 1011ffd:	cmpl   $0x0,0x40(%rax)
 1012001:	jne    1012009 <rc_list_insert_at+0x2d9>
 1012003:	cmpb   $0x0,0x45(%rax)
 1012007:	je     1012039 <rc_list_insert_at+0x309>
 1012009:	mov    -0x10(%rbx),%rax
 101200d:	mov    0x18(%rbx),%rsi
 1012011:	mov    %rax,%r8
 1012014:	shr    $0x28,%r8
 1012018:	and    $0xfffff,%r8d
 101201f:	xor    %r12d,%r12d
 1012022:	bt     $0x3e,%rax
 1012027:	cmovae %r12d,%r8d
 101202b:	call   101e0d0 <myl_rc_native_retain>
 1012030:	test   %eax,%eax
 1012032:	jne    101205a <rc_list_insert_at+0x32a>
 1012034:	jmp    1011ef4 <rc_list_insert_at+0x1c4>
 1012039:	mov    0x1608(%rdi),%rax
 1012040:	mov    %rsi,0x110(%rax)
 1012047:	mov    %rdx,%rdi
 101204a:	mov    %rcx,%rsi
 101204d:	mov    %r9,%rdx
 1012050:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1012055:	mov    $0x1,%eax
 101205a:	incq   (%rbx)
 101205d:	incq   0x10(%rbx)
 1012061:	mov    %eax,%r12d
 1012064:	jmp    1011ef4 <rc_list_insert_at+0x1c4>
 1012069:	call   10130fa <myl_rc_binding_find_slow>
 101206e:	test   %rax,%rax
 1012071:	jne    1011ffd <rc_list_insert_at+0x2cd>
 1012073:	jmp    1012009 <rc_list_insert_at+0x2d9>
 1012075:	call   101267d <myl_rc_invariant_failed>
 101207a:	int3
 101207b:	int3
 101207c:	int3
 101207d:	int3
 101207e:	int3
 101207f:	int3

0000000001012080 <rc_elements_release>:
 1012080:	push   %rbp
 1012081:	mov    %rsp,%rbp
 1012084:	mov    0x1608(%rdi),%r8
 101208b:	mov    0x34(%rsi),%eax
 101208e:	cmp    %rax,0xa0(%r8)
 1012095:	jbe    10120e8 <rc_elements_release+0x68>
 1012097:	mov    0x98(%r8),%r8
 101209e:	shl    $0x4,%rax
 10120a2:	cmp    %rsi,(%r8,%rax,1)
 10120a6:	jne    10120e8 <rc_elements_release+0x68>
 10120a8:	add    %rax,%r8
 10120ab:	mov    0x8(%r8),%rsi
 10120af:	test   %rsi,%rsi
 10120b2:	je     10120f5 <rc_elements_release+0x75>
 10120b4:	mov    0x40(%rsi),%eax
 10120b7:	test   %eax,%eax
 10120b9:	je     10120c6 <rc_elements_release+0x46>
 10120bb:	cmp    $0x11,%eax
 10120be:	jb     10120cc <rc_elements_release+0x4c>
 10120c0:	mov    0x8(%rsi),%rax
 10120c4:	jmp    10120dd <rc_elements_release+0x5d>
 10120c6:	cmpb   $0x0,0x45(%rsi)
 10120ca:	je     10120e6 <rc_elements_release+0x66>
 10120cc:	mov    0x8(%rsi),%rax
 10120d0:	cmpq   $0x3,0x28(%rax)
 10120d5:	jb     10120dd <rc_elements_release+0x5d>
 10120d7:	pop    %rbp
 10120d8:	jmp    1016060 <myl_rc_flat_edges_release>
 10120dd:	mov    %rax,%rsi
 10120e0:	pop    %rbp
 10120e1:	jmp    1015bb0 <myl_rc_edges_release>
 10120e6:	pop    %rbp
 10120e7:	ret
 10120e8:	call   10130fa <myl_rc_binding_find_slow>
 10120ed:	mov    %rax,%rsi
 10120f0:	test   %rsi,%rsi
 10120f3:	jne    10120b4 <rc_elements_release+0x34>
 10120f5:	call   101f1f0 <abort@plt>
 10120fa:	int3
 10120fb:	int3
 10120fc:	int3
 10120fd:	int3
 10120fe:	int3
 10120ff:	int3

0000000001012100 <rc_list_edges>:
 1012100:	cmpq   $0x0,(%rsi)
 1012104:	je     1012179 <rc_list_edges+0x79>
 1012106:	push   %rbp
 1012107:	mov    %rsp,%rbp
 101210a:	push   %r14
 101210c:	push   %rbx
 101210d:	mov    0x18(%rsi),%rcx
 1012111:	mov    0x1608(%rdi),%rdx
 1012118:	cmp    %rcx,0x110(%rdx)
 101211f:	je     1012175 <rc_list_edges+0x75>
 1012121:	mov    0x34(%rcx),%eax
 1012124:	cmp    %rax,0xa0(%rdx)
 101212b:	jbe    1012192 <rc_list_edges+0x92>
 101212d:	mov    0x98(%rdx),%rdx
 1012134:	shl    $0x4,%rax
 1012138:	cmp    %rcx,(%rdx,%rax,1)
 101213c:	jne    1012192 <rc_list_edges+0x92>
 101213e:	add    %rax,%rdx
 1012141:	mov    0x8(%rdx),%rax
 1012145:	test   %rax,%rax
 1012148:	je     1012156 <rc_list_edges+0x56>
 101214a:	cmpl   $0x0,0x40(%rax)
 101214e:	jne    1012156 <rc_list_edges+0x56>
 1012150:	cmpb   $0x0,0x45(%rax)
 1012154:	je     1012182 <rc_list_edges+0x82>
 1012156:	mov    (%rsi),%rcx
 1012159:	mov    0x18(%rsi),%rax
 101215d:	mov    0x20(%rsi),%rdx
 1012161:	mov    %rdi,%rbx
 1012164:	mov    %rsi,%r14
 1012167:	mov    %rax,%rsi
 101216a:	call   1012080 <rc_elements_release>
 101216f:	mov    %r14,%rsi
 1012172:	mov    %rbx,%rdi
 1012175:	pop    %rbx
 1012176:	pop    %r14
 1012178:	pop    %rbp
 1012179:	mov    0x20(%rsi),%rsi
 101217d:	jmp    1012bb0 <myl_rc_edge_release>
 1012182:	mov    0x1608(%rdi),%rax
 1012189:	mov    %rcx,0x110(%rax)
 1012190:	jmp    1012175 <rc_list_edges+0x75>
 1012192:	mov    %rsi,%rdx
 1012195:	mov    %rcx,%rsi
 1012198:	call   10130fa <myl_rc_binding_find_slow>
 101219d:	mov    %rdx,%rsi
 10121a0:	test   %rax,%rax
 10121a3:	jne    101214a <rc_list_edges+0x4a>
 10121a5:	jmp    1012156 <rc_list_edges+0x56>
 10121a7:	int3
 10121a8:	int3
 10121a9:	int3
 10121aa:	int3
 10121ab:	int3
 10121ac:	int3
 10121ad:	int3
 10121ae:	int3
 10121af:	int3

00000000010121b0 <rc_list_clone_adapter>:
 10121b0:	push   %rbp
 10121b1:	mov    %rsp,%rbp
 10121b4:	push   %r14
 10121b6:	push   %rbx
 10121b7:	mov    %rcx,%rbx
 10121ba:	mov    %edx,%ecx
 10121bc:	mov    %rdi,%r14
 10121bf:	mov    0x18(%rsi),%rdx
 10121c3:	call   10119a0 <rc_list_clone>
 10121c8:	mov    %rax,(%rbx)
 10121cb:	mov    %r14,%rdi
 10121ce:	mov    %rax,%rsi
 10121d1:	pop    %rbx
 10121d2:	pop    %r14
 10121d4:	pop    %rbp
 10121d5:	jmp    101e610 <myl_rc_native_result>
 10121da:	int3
 10121db:	int3
 10121dc:	int3
 10121dd:	int3
 10121de:	int3
 10121df:	int3

00000000010121e0 <rc_list_shell>:
 10121e0:	push   %rbp
 10121e1:	mov    %rsp,%rbp
 10121e4:	push   %r15
 10121e6:	push   %r14
 10121e8:	push   %r12
 10121ea:	push   %rbx
 10121eb:	mov    %rcx,%r12
 10121ee:	mov    %edx,%ecx
 10121f0:	mov    %rsi,%rbx
 10121f3:	mov    %rdi,%r14
 10121f6:	mov    (%rsi),%rdx
 10121f9:	mov    0x8(%rsi),%rax
 10121fd:	cmp    %rdx,%rax
 1012200:	cmova  %rax,%rdx
 1012204:	mov    0x18(%rsi),%rsi
 1012208:	xor    %r8d,%r8d
 101220b:	call   1011880 <rc_list_new>
 1012210:	mov    %rax,(%r12)
 1012214:	test   %rax,%rax
 1012217:	je     1012271 <rc_list_shell+0x91>
 1012219:	mov    %rax,%r15
 101221c:	mov    0x18(%rbx),%rsi
 1012220:	mov    0x1608(%r14),%rcx
 1012227:	mov    0x34(%rsi),%eax
 101222a:	cmp    %rax,0xa0(%rcx)
 1012231:	jbe    1012293 <rc_list_shell+0xb3>
 1012233:	mov    0x98(%rcx),%rcx
 101223a:	shl    $0x4,%rax
 101223e:	cmp    %rsi,(%rcx,%rax,1)
 1012242:	jne    1012293 <rc_list_shell+0xb3>
 1012244:	add    %rax,%rcx
 1012247:	mov    0x8(%rcx),%rax
 101224b:	test   %rax,%rax
 101224e:	je     10122a0 <rc_list_shell+0xc0>
 1012250:	mov    (%rbx),%r8
 1012253:	test   %r8,%r8
 1012256:	je     1012283 <rc_list_shell+0xa3>
 1012258:	mov    0x8(%rax),%rsi
 101225c:	mov    0x20(%r15),%rdx
 1012260:	mov    0x20(%rbx),%rcx
 1012264:	mov    %r14,%rdi
 1012267:	call   1016c50 <myl_rc_value_seed>
 101226c:	mov    (%rbx),%rax
 101226f:	jmp    1012285 <rc_list_shell+0xa5>
 1012271:	mov    %r14,%rdi
 1012274:	xor    %esi,%esi
 1012276:	pop    %rbx
 1012277:	pop    %r12
 1012279:	pop    %r14
 101227b:	pop    %r15
 101227d:	pop    %rbp
 101227e:	jmp    101e610 <myl_rc_native_result>
 1012283:	xor    %eax,%eax
 1012285:	mov    %rax,(%r15)
 1012288:	xor    %eax,%eax
 101228a:	pop    %rbx
 101228b:	pop    %r12
 101228d:	pop    %r14
 101228f:	pop    %r15
 1012291:	pop    %rbp
 1012292:	ret
 1012293:	mov    %r14,%rdi
 1012296:	call   10130fa <myl_rc_binding_find_slow>
 101229b:	test   %rax,%rax
 101229e:	jne    1012250 <rc_list_shell+0x70>
 10122a0:	call   101f1f0 <abort@plt>
 10122a5:	int3
 10122a6:	int3
 10122a7:	int3
 10122a8:	int3
 10122a9:	int3
 10122aa:	int3
 10122ab:	int3
 10122ac:	int3
 10122ad:	int3
 10122ae:	int3
 10122af:	int3

00000000010122b0 <rc_list_next>:
 10122b0:	push   %rbp
 10122b1:	mov    %rsp,%rbp
 10122b4:	push   %r14
 10122b6:	push   %rbx
 10122b7:	mov    0x18(%rsi),%rax
 10122bb:	mov    0x1608(%rdi),%r11
 10122c2:	mov    0x34(%rax),%r10d
 10122c6:	cmp    %r10,0xa0(%r11)
 10122cd:	jbe    10123a4 <rc_list_next+0xf4>
 10122d3:	mov    0x98(%r11),%r11
 10122da:	shl    $0x4,%r10
 10122de:	cmp    %rax,(%r11,%r10,1)
 10122e2:	jne    10123a4 <rc_list_next+0xf4>
 10122e8:	add    %r10,%r11
 10122eb:	mov    0x8(%r11),%rax
 10122ef:	test   %rax,%rax
 10122f2:	je     10123bb <rc_list_next+0x10b>
 10122f8:	mov    (%rcx),%r10
 10122fb:	xor    %edi,%edi
 10122fd:	cmp    (%rsi),%r10
 1012300:	jae    101239d <rc_list_next+0xed>
 1012306:	mov    0x8(%rax),%r11
 101230a:	cmpl   $0x0,0x8(%r11)
 101230f:	je     101239d <rc_list_next+0xed>
 1012315:	lea    0x1(%r10),%rdi
 1012319:	mov    %rdi,(%rcx)
 101231c:	mov    0x18(%rsi),%rcx
 1012320:	imul   (%rcx),%r10
 1012324:	mov    0x20(%rdx),%rcx
 1012328:	add    %r10,%rcx
 101232b:	mov    -0x10(%rdx),%rdi
 101232f:	mov    %rdi,%rbx
 1012332:	shr    $0x28,%rbx
 1012336:	and    $0xfffff,%ebx
 101233c:	xor    %r14d,%r14d
 101233f:	bt     $0x3e,%rdi
 1012344:	cmovae %r14d,%ebx
 1012348:	mov    %r11,(%r8)
 101234b:	mov    %rcx,0x8(%r8)
 101234f:	mov    %rdx,0x10(%r8)
 1012353:	mov    %ebx,0x18(%r8)
 1012357:	movl   $0x0,0x1c(%r8)
 101235f:	mov    0x8(%rax),%rax
 1012363:	add    0x20(%rsi),%r10
 1012367:	mov    -0x10(%rsi),%rcx
 101236b:	mov    %rcx,%rdx
 101236e:	shr    $0x28,%rdx
 1012372:	and    $0xfffff,%edx
 1012378:	bt     $0x3e,%rcx
 101237d:	cmovae %r14d,%edx
 1012381:	mov    %rax,(%r9)
 1012384:	mov    %r10,0x8(%r9)
 1012388:	mov    %rsi,0x10(%r9)
 101238c:	mov    %edx,0x18(%r9)
 1012390:	movl   $0x0,0x1c(%r9)
 1012398:	mov    $0x1,%edi
 101239d:	mov    %edi,%eax
 101239f:	pop    %rbx
 10123a0:	pop    %r14
 10123a2:	pop    %rbp
 10123a3:	ret
 10123a4:	mov    %rsi,%r10
 10123a7:	mov    %rax,%rsi
 10123aa:	call   10130fa <myl_rc_binding_find_slow>
 10123af:	mov    %r10,%rsi
 10123b2:	test   %rax,%rax
 10123b5:	jne    10122f8 <rc_list_next+0x48>
 10123bb:	call   101f1f0 <abort@plt>

00000000010123c0 <rc_list_span>:
 10123c0:	push   %rbp
 10123c1:	mov    %rsp,%rbp
 10123c4:	push   %r15
 10123c6:	push   %r14
 10123c8:	push   %rbx
 10123c9:	push   %rax
 10123ca:	mov    %rcx,%rbx
 10123cd:	mov    %rsi,%r14
 10123d0:	mov    (%rcx),%r15
 10123d3:	call   10122b0 <rc_list_next>
 10123d8:	test   %eax,%eax
 10123da:	je     10123f6 <rc_list_span+0x36>
 10123dc:	mov    0x10(%rbp),%rax
 10123e0:	mov    (%r14),%rcx
 10123e3:	sub    %r15,%rcx
 10123e6:	mov    %rcx,(%rax)
 10123e9:	mov    (%r14),%rax
 10123ec:	mov    %rax,(%rbx)
 10123ef:	mov    $0x1,%eax
 10123f4:	jmp    10123f8 <rc_list_span+0x38>
 10123f6:	xor    %eax,%eax
 10123f8:	add    $0x8,%rsp
 10123fc:	pop    %rbx
 10123fd:	pop    %r14
 10123ff:	pop    %r15
 1012401:	pop    %rbp
 1012402:	ret
 1012403:	int3
 1012404:	int3
 1012405:	int3
 1012406:	int3
 1012407:	int3
 1012408:	int3
 1012409:	int3
 101240a:	int3
 101240b:	int3
 101240c:	int3
 101240d:	int3
 101240e:	int3
 101240f:	int3

0000000001012410 <rc_storage_edges>:
 1012410:	push   %rbp
 1012411:	mov    %rsp,%rbp
 1012414:	mov    0x20(%rsi),%rsi
 1012418:	pop    %rbp
 1012419:	jmp    1012bb0 <myl_rc_edge_release>
 101241e:	int3
 101241f:	int3

0000000001012420 <myl_native_text_valid_utf8>:
 1012420:	test   %rsi,%rsi
 1012423:	je     101257f <myl_native_text_valid_utf8+0x15f>
 1012429:	push   %rbp
 101242a:	mov    %rsp,%rbp
 101242d:	push   %r15
 101242f:	push   %r14
 1012431:	push   %r12
 1012433:	push   %rbx
 1012434:	xor    %ecx,%ecx
 1012436:	jmp    1012456 <myl_native_text_valid_utf8+0x36>
 1012438:	nopl   0x0(%rax,%rax,1)
 1012440:	dec    %edx
 1012442:	lea    (%rcx,%rdx,1),%r10
 1012446:	add    $0x2,%r10
 101244a:	mov    %r10,%rcx
 101244d:	cmp    %rsi,%r10
 1012450:	je     1012585 <myl_native_text_valid_utf8+0x165>
 1012456:	lea    0x1(%rcx),%r10
 101245a:	movzbl (%rdi,%rcx,1),%r9d
 101245f:	test   %r9b,%r9b
 1012462:	jns    101244a <myl_native_text_valid_utf8+0x2a>
 1012464:	lea    0x3e(%r9),%r11d
 1012468:	xor    %eax,%eax
 101246a:	cmp    $0x1e,%r11b
 101246e:	jae    1012485 <myl_native_text_valid_utf8+0x65>
 1012470:	mov    $0x80,%r8d
 1012476:	mov    $0x1,%edx
 101247b:	mov    $0x1f,%ebx
 1012480:	xor    %r14d,%r14d
 1012483:	jmp    10124c5 <myl_native_text_valid_utf8+0xa5>
 1012485:	mov    %r9d,%edx
 1012488:	and    $0xf0,%dl
 101248b:	cmp    $0xe0,%dl
 101248e:	jne    10124a5 <myl_native_text_valid_utf8+0x85>
 1012490:	mov    $0x800,%r8d
 1012496:	mov    $0x2,%edx
 101249b:	mov    $0x1,%r14b
 101249e:	mov    $0xf,%ebx
 10124a3:	jmp    10124c5 <myl_native_text_valid_utf8+0xa5>
 10124a5:	lea    0x10(%r9),%edx
 10124a9:	xor    %r14d,%r14d
 10124ac:	cmp    $0x4,%dl
 10124af:	ja     1012593 <myl_native_text_valid_utf8+0x173>
 10124b5:	mov    $0x10000,%r8d
 10124bb:	mov    $0x3,%edx
 10124c0:	mov    $0x7,%ebx
 10124c5:	mov    %edx,%r15d
 10124c8:	mov    %rsi,%r12
 10124cb:	sub    %r10,%r12
 10124ce:	cmp    %r15,%r12
 10124d1:	jb     101258a <myl_native_text_valid_utf8+0x16a>
 10124d7:	movzbl 0x1(%rdi,%rcx,1),%r10d
 10124dd:	mov    %r10d,%r15d
 10124e0:	and    $0xffffffc0,%r15d
 10124e4:	cmp    $0x80,%r15d
 10124eb:	jne    101258a <myl_native_text_valid_utf8+0x16a>
 10124f1:	and    %r9d,%ebx
 10124f4:	shl    $0x6,%ebx
 10124f7:	and    $0x3f,%r10d
 10124fb:	or     %ebx,%r10d
 10124fe:	cmp    $0x1e,%r11b
 1012502:	jb     1012530 <myl_native_text_valid_utf8+0x110>
 1012504:	movzbl 0x2(%rdi,%rcx,1),%r9d
 101250a:	mov    %r9d,%r11d
 101250d:	and    $0xffffffc0,%r11d
 1012511:	cmp    $0x80,%r11d
 1012518:	jne    101258a <myl_native_text_valid_utf8+0x16a>
 101251a:	shl    $0x6,%r10d
 101251e:	and    $0x3f,%r9d
 1012522:	or     %r10d,%r9d
 1012525:	test   %r14b,%r14b
 1012528:	je     1012551 <myl_native_text_valid_utf8+0x131>
 101252a:	mov    %r10d,%ebx
 101252d:	mov    %r9d,%r10d
 1012530:	cmp    $0x10ffff,%ebx
 1012536:	ja     101258a <myl_native_text_valid_utf8+0x16a>
 1012538:	cmp    %r8d,%r10d
 101253b:	jb     101258a <myl_native_text_valid_utf8+0x16a>
 101253d:	add    $0xffff2000,%ebx
 1012543:	cmp    $0xfffff7ff,%ebx
 1012549:	jbe    1012440 <myl_native_text_valid_utf8+0x20>
 101254f:	jmp    101258a <myl_native_text_valid_utf8+0x16a>
 1012551:	movzbl 0x3(%rdi,%rcx,1),%r10d
 1012557:	mov    %r10d,%r11d
 101255a:	and    $0xffffffc0,%r11d
 101255e:	cmp    $0x80,%r11d
 1012565:	jne    101258a <myl_native_text_valid_utf8+0x16a>
 1012567:	shl    $0x6,%r9d
 101256b:	and    $0x3f,%r10d
 101256f:	or     %r9d,%r10d
 1012572:	mov    %r9d,%ebx
 1012575:	cmp    $0x10ffff,%ebx
 101257b:	jbe    1012538 <myl_native_text_valid_utf8+0x118>
 101257d:	jmp    101258a <myl_native_text_valid_utf8+0x16a>
 101257f:	mov    $0x1,%eax
 1012584:	ret
 1012585:	mov    $0x1,%eax
 101258a:	pop    %rbx
 101258b:	pop    %r12
 101258d:	pop    %r14
 101258f:	pop    %r15
 1012591:	pop    %rbp
 1012592:	ret
 1012593:	xor    %eax,%eax
 1012595:	jmp    101258a <myl_native_text_valid_utf8+0x16a>
 1012597:	int3
 1012598:	int3
 1012599:	int3
 101259a:	int3
 101259b:	int3
 101259c:	int3
 101259d:	int3
 101259e:	int3
 101259f:	int3

00000000010125a0 <myl_native_dictionary_header>:
 10125a0:	push   %rbp
 10125a1:	mov    %rsp,%rbp
 10125a4:	test   %rdi,%rdi
 10125a7:	je     10125ca <myl_native_dictionary_header+0x2a>
 10125a9:	mov    -0x8(%rdi),%rcx
 10125ad:	lea    0x16cc4(%rip),%rax        # 1029278 <dict_type>
 10125b4:	cmp    %rax,%rcx
 10125b7:	je     10125ce <myl_native_dictionary_header+0x2e>
 10125b9:	lea    -0xf5e8(%rip),%rdx        # 1002fd8 <rc_dict_type>
 10125c0:	xor    %eax,%eax
 10125c2:	cmp    %rdx,%rcx
 10125c5:	sete   %al
 10125c8:	pop    %rbp
 10125c9:	ret
 10125ca:	xor    %eax,%eax
 10125cc:	pop    %rbp
 10125cd:	ret
 10125ce:	mov    $0x1,%eax
 10125d3:	pop    %rbp
 10125d4:	ret
 10125d5:	int3
 10125d6:	int3
 10125d7:	int3
 10125d8:	int3
 10125d9:	int3
 10125da:	int3
 10125db:	int3
 10125dc:	int3
 10125dd:	int3
 10125de:	int3
 10125df:	int3

00000000010125e0 <myl_rc_owner_take>:
 10125e0:	xor    %eax,%eax
 10125e2:	test   %rdi,%rdi
 10125e5:	je     10125fa <myl_rc_owner_take+0x1a>
 10125e7:	mov    -0x10(%rdi),%rcx
 10125eb:	movabs $0x4000000000000002,%rdx
 10125f5:	test   %rdx,%rcx
 10125f8:	je     10125fb <myl_rc_owner_take+0x1b>
 10125fa:	ret
 10125fb:	test   $0x1,%cl
 10125fe:	jne    1012624 <myl_rc_owner_take+0x44>
 1012600:	mov    -0x20(%rdi),%rcx
 1012604:	cmp    $0xffffffffffffffff,%rcx
 1012608:	je     101261e <myl_rc_owner_take+0x3e>
 101260a:	test   %rcx,%rcx
 101260d:	jne    1012616 <myl_rc_owner_take+0x36>
 101260f:	cmpq   $0x0,-0x18(%rdi)
 1012614:	je     1012624 <myl_rc_owner_take+0x44>
 1012616:	inc    %rcx
 1012619:	mov    %rcx,-0x20(%rdi)
 101261d:	ret
 101261e:	mov    $0x2,%eax
 1012623:	ret
 1012624:	push   %rbp
 1012625:	mov    %rsp,%rbp
 1012628:	call   101267d <myl_rc_invariant_failed>
 101262d:	int3
 101262e:	int3
 101262f:	int3

0000000001012630 <myl_rc_owner_take>:
 1012630:	xor    %eax,%eax
 1012632:	test   %rdi,%rdi
 1012635:	je     101264a <myl_rc_owner_take+0x1a>
 1012637:	mov    -0x10(%rdi),%rcx
 101263b:	movabs $0x4000000000000002,%rdx
 1012645:	test   %rdx,%rcx
 1012648:	je     101264b <myl_rc_owner_take+0x1b>
 101264a:	ret
 101264b:	test   $0x1,%cl
 101264e:	jne    1012674 <myl_rc_owner_take+0x44>
 1012650:	mov    -0x20(%rdi),%rcx
 1012654:	cmp    $0xffffffffffffffff,%rcx
 1012658:	je     101266e <myl_rc_owner_take+0x3e>
 101265a:	test   %rcx,%rcx
 101265d:	jne    1012666 <myl_rc_owner_take+0x36>
 101265f:	cmpq   $0x0,-0x18(%rdi)
 1012664:	je     1012674 <myl_rc_owner_take+0x44>
 1012666:	inc    %rcx
 1012669:	mov    %rcx,-0x20(%rdi)
 101266d:	ret
 101266e:	mov    $0x2,%eax
 1012673:	ret
 1012674:	push   %rbp
 1012675:	mov    %rsp,%rbp
 1012678:	call   101267d <myl_rc_invariant_failed>

000000000101267d <myl_rc_invariant_failed>:
 101267d:	push   %rbp
 101267e:	mov    %rsp,%rbp
 1012681:	call   101f1f0 <abort@plt>
 1012686:	int3
 1012687:	int3
 1012688:	int3
 1012689:	int3
 101268a:	int3
 101268b:	int3
 101268c:	int3
 101268d:	int3
 101268e:	int3
 101268f:	int3

0000000001012690 <myl_rc_meta_alloc>:
 1012690:	push   %rbp
 1012691:	mov    %rsp,%rbp
 1012694:	push   %r15
 1012696:	push   %r14
 1012698:	push   %r12
 101269a:	push   %rbx
 101269b:	test   %rdi,%rdi
 101269e:	je     1012701 <myl_rc_meta_alloc+0x71>
 10126a0:	test   %rsi,%rsi
 10126a3:	je     1012701 <myl_rc_meta_alloc+0x71>
 10126a5:	mov    0x1608(%rdi),%rbx
 10126ac:	test   %rbx,%rbx
 10126af:	je     1012701 <myl_rc_meta_alloc+0x71>
 10126b1:	mov    0x18(%rdi),%r14
 10126b5:	add    %rsi,%r14
 10126b8:	jb     10126d0 <myl_rc_meta_alloc+0x40>
 10126ba:	mov    0x58(%rdi),%rax
 10126be:	test   %rax,%rax
 10126c1:	setne  %cl
 10126c4:	cmp    %rax,%r14
 10126c7:	seta   %al
 10126ca:	and    %cl,%al
 10126cc:	cmp    $0x1,%al
 10126ce:	jne    10126e2 <myl_rc_meta_alloc+0x52>
 10126d0:	movl   $0x1,0x6c(%rdi)
 10126d7:	xor    %eax,%eax
 10126d9:	pop    %rbx
 10126da:	pop    %r12
 10126dc:	pop    %r14
 10126de:	pop    %r15
 10126e0:	pop    %rbp
 10126e1:	ret
 10126e2:	mov    %rdi,%r15
 10126e5:	mov    $0x1,%edi
 10126ea:	mov    %rsi,%r12
 10126ed:	call   101ef80 <calloc@plt>
 10126f2:	test   %rax,%rax
 10126f5:	je     10126d7 <myl_rc_meta_alloc+0x47>
 10126f7:	mov    %r14,0x18(%r15)
 10126fb:	add    %r12,0x30(%rbx)
 10126ff:	jmp    10126d9 <myl_rc_meta_alloc+0x49>
 1012701:	call   101267d <myl_rc_invariant_failed>
 1012706:	int3
 1012707:	int3
 1012708:	int3
 1012709:	int3
 101270a:	int3
 101270b:	int3
 101270c:	int3
 101270d:	int3
 101270e:	int3
 101270f:	int3

0000000001012710 <myl_rc_meta_free>:
 1012710:	test   %rsi,%rsi
 1012713:	je     101273e <myl_rc_meta_free+0x2e>
 1012715:	mov    0x18(%rdi),%rax
 1012719:	sub    %rdx,%rax
 101271c:	jb     101273f <myl_rc_meta_free+0x2f>
 101271e:	mov    0x1608(%rdi),%rcx
 1012725:	mov    0x30(%rcx),%r8
 1012729:	sub    %rdx,%r8
 101272c:	jb     101273f <myl_rc_meta_free+0x2f>
 101272e:	mov    %rax,0x18(%rdi)
 1012732:	mov    %r8,0x30(%rcx)
 1012736:	mov    %rsi,%rdi
 1012739:	jmp    101efd0 <free@plt>
 101273e:	ret
 101273f:	push   %rbp
 1012740:	mov    %rsp,%rbp
 1012743:	call   101267d <myl_rc_invariant_failed>
 1012748:	int3
 1012749:	int3
 101274a:	int3
 101274b:	int3
 101274c:	int3
 101274d:	int3
 101274e:	int3
 101274f:	int3

0000000001012750 <myl_rc_status_code>:
 1012750:	cmp    $0x4,%edi
 1012753:	jae    1012763 <myl_rc_status_code+0x13>
 1012755:	mov    %edi,%eax
 1012757:	lea    0x16bc2(%rip),%rcx        # 1029320 <dict_fields+0x30>
 101275e:	mov    (%rcx,%rax,8),%rax
 1012762:	ret
 1012763:	push   %rbp
 1012764:	mov    %rsp,%rbp
 1012767:	call   101f1f0 <abort@plt>
 101276c:	int3
 101276d:	int3
 101276e:	int3
 101276f:	int3

0000000001012770 <myl_rc_record_failure>:
 1012770:	test   %rdi,%rdi
 1012773:	je     1012792 <myl_rc_record_failure+0x22>
 1012775:	mov    0x1608(%rdi),%rax
 101277c:	test   %rax,%rax
 101277f:	je     1012792 <myl_rc_record_failure+0x22>
 1012781:	cmpl   $0x0,0x124(%rax)
 1012788:	je     101278b <myl_rc_record_failure+0x1b>
 101278a:	ret
 101278b:	mov    %esi,0x124(%rax)
 1012791:	ret
 1012792:	push   %rbp
 1012793:	mov    %rsp,%rbp
 1012796:	call   101267d <myl_rc_invariant_failed>
 101279b:	int3
 101279c:	int3
 101279d:	int3
 101279e:	int3
 101279f:	int3

00000000010127a0 <myl_rc_take_failure>:
 10127a0:	test   %rdi,%rdi
 10127a3:	je     10127c2 <myl_rc_take_failure+0x22>
 10127a5:	mov    0x1608(%rdi),%rcx
 10127ac:	test   %rcx,%rcx
 10127af:	je     10127c2 <myl_rc_take_failure+0x22>
 10127b1:	mov    0x124(%rcx),%eax
 10127b7:	movl   $0x0,0x124(%rcx)
 10127c1:	ret
 10127c2:	push   %rbp
 10127c3:	mov    %rsp,%rbp
 10127c6:	call   101267d <myl_rc_invariant_failed>
 10127cb:	int3
 10127cc:	int3
 10127cd:	int3
 10127ce:	int3
 10127cf:	int3

00000000010127d0 <myl_rc_heap_init>:
 10127d0:	push   %rbp
 10127d1:	mov    %rsp,%rbp
 10127d4:	push   %r15
 10127d6:	push   %r14
 10127d8:	push   %r12
 10127da:	push   %rbx
 10127db:	test   %rdi,%rdi
 10127de:	je     1012896 <myl_rc_heap_init+0xc6>
 10127e4:	test   %rsi,%rsi
 10127e7:	je     1012896 <myl_rc_heap_init+0xc6>
 10127ed:	cmpq   $0x0,0x1608(%rdi)
 10127f5:	jne    1012896 <myl_rc_heap_init+0xc6>
 10127fb:	cmpq   $0x0,(%rsi)
 10127ff:	je     1012896 <myl_rc_heap_init+0xc6>
 1012805:	cmpq   $0x0,0x8(%rsi)
 101280a:	je     1012896 <myl_rc_heap_init+0xc6>
 1012810:	mov    $0x128,%ebx
 1012815:	add    0x18(%rdi),%rbx
 1012819:	jb     1012831 <myl_rc_heap_init+0x61>
 101281b:	mov    0x58(%rdi),%rax
 101281f:	test   %rax,%rax
 1012822:	setne  %cl
 1012825:	cmp    %rax,%rbx
 1012828:	seta   %al
 101282b:	and    %cl,%al
 101282d:	cmp    $0x1,%al
 101282f:	jne    1012846 <myl_rc_heap_init+0x76>
 1012831:	movl   $0x1,0x6c(%rdi)
 1012838:	mov    $0x1,%eax
 101283d:	pop    %rbx
 101283e:	pop    %r12
 1012840:	pop    %r14
 1012842:	pop    %r15
 1012844:	pop    %rbp
 1012845:	ret
 1012846:	mov    %rsi,%r12
 1012849:	mov    %rdx,%r15
 101284c:	mov    %rdi,%r14
 101284f:	mov    $0x1,%edi
 1012854:	mov    $0x128,%esi
 1012859:	call   101ef80 <calloc@plt>
 101285e:	test   %rax,%rax
 1012861:	je     1012838 <myl_rc_heap_init+0x68>
 1012863:	vmovups (%r12),%ymm0
 1012869:	vmovups %ymm0,(%rax)
 101286d:	mov    %r15,0x20(%rax)
 1012871:	movq   $0x128,0x30(%rax)
 1012879:	mov    %rax,%rdi
 101287c:	mov    %rax,%r15
 101287f:	vzeroupper
 1012882:	call   1012f80 <myl_rc_metadata_init>
 1012887:	mov    %rbx,0x18(%r14)
 101288b:	mov    %r15,0x1608(%r14)
 1012892:	xor    %eax,%eax
 1012894:	jmp    101283d <myl_rc_heap_init+0x6d>
 1012896:	call   101267d <myl_rc_invariant_failed>
 101289b:	int3
 101289c:	int3
 101289d:	int3
 101289e:	int3
 101289f:	int3

00000000010128a0 <myl_rc_heap_destroy>:
 10128a0:	push   %rbp
 10128a1:	mov    %rsp,%rbp
 10128a4:	push   %r14
 10128a6:	push   %rbx
 10128a7:	cmpq   $0x0,0x1608(%rdi)
 10128af:	je     10129c0 <myl_rc_heap_destroy+0x120>
 10128b5:	mov    %rdi,%rbx
 10128b8:	call   1016210 <myl_rc_drain>
 10128bd:	mov    0x1608(%rbx),%r14
 10128c4:	cmpq   $0x0,0xf8(%r14)
 10128cc:	jne    10129c5 <myl_rc_heap_destroy+0x125>
 10128d2:	cmpq   $0x0,0xc0(%r14)
 10128da:	jne    10129c5 <myl_rc_heap_destroy+0x125>
 10128e0:	cmpl   $0x0,0xd0(%r14)
 10128e8:	jne    10129c5 <myl_rc_heap_destroy+0x125>
 10128ee:	mov    %rbx,%rdi
 10128f1:	call   1018d20 <myl_rc_scope_spares_release>
 10128f6:	mov    0x10(%r14),%rax
 10128fa:	test   %rax,%rax
 10128fd:	je     1012949 <myl_rc_heap_destroy+0xa9>
 10128ff:	mov    %rbx,%rdi
 1012902:	call   *%rax
 1012904:	jmp    1012949 <myl_rc_heap_destroy+0xa9>
 1012906:	cs nopw 0x0(%rax,%rax,1)
 1012910:	mov    (%rdi),%rax
 1012913:	mov    %rax,0x28(%r14)
 1012917:	mov    0x30(%rdi),%rcx
 101291b:	mov    0x18(%rbx),%rax
 101291f:	sub    %rcx,%rax
 1012922:	jb     10129c5 <myl_rc_heap_destroy+0x125>
 1012928:	mov    0x1608(%rbx),%rdx
 101292f:	mov    0x30(%rdx),%rsi
 1012933:	sub    %rcx,%rsi
 1012936:	jb     10129c5 <myl_rc_heap_destroy+0x125>
 101293c:	mov    %rax,0x18(%rbx)
 1012940:	mov    %rsi,0x30(%rdx)
 1012944:	call   101efd0 <free@plt>
 1012949:	mov    0x28(%r14),%rdi
 101294d:	test   %rdi,%rdi
 1012950:	jne    1012910 <myl_rc_heap_destroy+0x70>
 1012952:	mov    0xb0(%r14),%rdi
 1012959:	test   %rdi,%rdi
 101295c:	je     1012993 <myl_rc_heap_destroy+0xf3>
 101295e:	mov    0xb8(%r14),%rax
 1012965:	shl    $0x3,%rax
 1012969:	lea    (%rax,%rax,2),%rcx
 101296d:	mov    0x18(%rbx),%rax
 1012971:	sub    %rcx,%rax
 1012974:	jb     10129c5 <myl_rc_heap_destroy+0x125>
 1012976:	mov    0x1608(%rbx),%rdx
 101297d:	mov    0x30(%rdx),%rsi
 1012981:	sub    %rcx,%rsi
 1012984:	jb     10129c5 <myl_rc_heap_destroy+0x125>
 1012986:	mov    %rax,0x18(%rbx)
 101298a:	mov    %rsi,0x30(%rdx)
 101298e:	call   101efd0 <free@plt>
 1012993:	mov    %rbx,%rdi
 1012996:	call   1012fd0 <myl_rc_metadata_release>
 101299b:	cmpq   $0x128,0x30(%r14)
 10129a3:	jne    10129c5 <myl_rc_heap_destroy+0x125>
 10129a5:	addq   $0xfffffffffffffed8,0x18(%rbx)
 10129ad:	mov    %r14,%rdi
 10129b0:	call   101efd0 <free@plt>
 10129b5:	movq   $0x0,0x1608(%rbx)
 10129c0:	pop    %rbx
 10129c1:	pop    %r14
 10129c3:	pop    %rbp
 10129c4:	ret
 10129c5:	call   101267d <myl_rc_invariant_failed>
 10129ca:	int3
 10129cb:	int3
 10129cc:	int3
 10129cd:	int3
 10129ce:	int3
 10129cf:	int3

00000000010129d0 <myl_rc_heap_teardown>:
 10129d0:	push   %rbp
 10129d1:	mov    %rsp,%rbp
 10129d4:	push   %r14
 10129d6:	push   %rbx
 10129d7:	mov    0x1608(%rdi),%r14
 10129de:	test   %r14,%r14
 10129e1:	je     1012a20 <myl_rc_heap_teardown+0x50>
 10129e3:	mov    %rdi,%rbx
 10129e6:	call   1018d90 <myl_rc_scopes_abandon>
 10129eb:	movl   $0x0,0x124(%r14)
 10129f6:	vxorps %xmm0,%xmm0,%xmm0
 10129fa:	vmovups %xmm0,0xc0(%r14)
 1012a03:	movl   $0x0,0xd0(%r14)
 1012a0e:	mov    0x18(%r14),%rax
 1012a12:	test   %rax,%rax
 1012a15:	je     1012a25 <myl_rc_heap_teardown+0x55>
 1012a17:	mov    %rbx,%rdi
 1012a1a:	pop    %rbx
 1012a1b:	pop    %r14
 1012a1d:	pop    %rbp
 1012a1e:	jmp    *%rax
 1012a20:	pop    %rbx
 1012a21:	pop    %r14
 1012a23:	pop    %rbp
 1012a24:	ret
 1012a25:	call   101267d <myl_rc_invariant_failed>
 1012a2a:	int3
 1012a2b:	int3
 1012a2c:	int3
 1012a2d:	int3
 1012a2e:	int3
 1012a2f:	int3

0000000001012a30 <myl_rc_new>:
 1012a30:	push   %rbp
 1012a31:	mov    %rsp,%rbp
 1012a34:	push   %rbx
 1012a35:	push   %rax
 1012a36:	test   %rdi,%rdi
 1012a39:	je     1012af8 <myl_rc_new+0xc8>
 1012a3f:	mov    %rdx,%rbx
 1012a42:	test   %rdx,%rdx
 1012a45:	je     1012af8 <myl_rc_new+0xc8>
 1012a4b:	test   %rsi,%rsi
 1012a4e:	je     1012af8 <myl_rc_new+0xc8>
 1012a54:	cmpq   $0x0,0x1608(%rdi)
 1012a5c:	je     1012af8 <myl_rc_new+0xc8>
 1012a62:	movq   $0x0,(%rbx)
 1012a69:	mov    (%rsi),%rdx
 1012a6c:	test   %rdx,%rdx
 1012a6f:	je     1012af8 <myl_rc_new+0xc8>
 1012a75:	mov    0x8(%rsi),%rcx
 1012a79:	mov    %rcx,%rax
 1012a7c:	mulq   (%rdx)
 1012a7f:	mov    %rax,%rdx
 1012a82:	mov    $0x1,%eax
 1012a87:	jo     1012aea <myl_rc_new+0xba>
 1012a89:	mov    0x10(%rsi),%r8d
 1012a8d:	xor    %r9d,%r9d
 1012a90:	test   %r8d,%r8d
 1012a93:	sete   %r9b
 1012a97:	movabs $0x3ffffffffffffff,%r10
 1012aa1:	movabs $0x3fffffffff,%r11
 1012aab:	cmove  %r10,%r11
 1012aaf:	shl    $0x4,%r9d
 1012ab3:	add    $0x10,%r9
 1012ab7:	add    %r9,%rdx
 1012aba:	setb   %dl
 1012abd:	cmp    %r11,%rcx
 1012ac0:	seta   %cl
 1012ac3:	or     %dl,%cl
 1012ac5:	jne    1012aea <myl_rc_new+0xba>
 1012ac7:	mov    $0x3,%eax
 1012acc:	cmp    0x70(%rdi),%r8d
 1012ad0:	ja     1012aea <myl_rc_new+0xba>
 1012ad2:	mov    0x1608(%rdi),%rax
 1012ad9:	mov    %rbx,%rdx
 1012adc:	call   *(%rax)
 1012ade:	mov    (%rbx),%rcx
 1012ae1:	test   %eax,%eax
 1012ae3:	je     1012af1 <myl_rc_new+0xc1>
 1012ae5:	test   %rcx,%rcx
 1012ae8:	jne    1012af8 <myl_rc_new+0xc8>
 1012aea:	add    $0x8,%rsp
 1012aee:	pop    %rbx
 1012aef:	pop    %rbp
 1012af0:	ret
 1012af1:	xor    %eax,%eax
 1012af3:	test   %rcx,%rcx
 1012af6:	jne    1012aea <myl_rc_new+0xba>
 1012af8:	call   101267d <myl_rc_invariant_failed>
 1012afd:	int3
 1012afe:	int3
 1012aff:	int3

0000000001012b00 <myl_rc_dead_outside>:
 1012b00:	push   %rbp
 1012b01:	mov    %rsp,%rbp
 1012b04:	mov    0x18(%rsi),%rax
 1012b08:	mov    0x1608(%rdi),%rdx
 1012b0f:	cmp    %rax,0x110(%rdx)
 1012b16:	je     1012b68 <myl_rc_dead_outside+0x68>
 1012b18:	mov    0x34(%rax),%ecx
 1012b1b:	cmp    %rcx,0xa0(%rdx)
 1012b22:	jbe    1012b8e <myl_rc_dead_outside+0x8e>
 1012b24:	mov    0x98(%rdx),%rdx
 1012b2b:	shl    $0x4,%rcx
 1012b2f:	cmp    %rax,(%rdx,%rcx,1)
 1012b33:	jne    1012b8e <myl_rc_dead_outside+0x8e>
 1012b35:	add    %rcx,%rdx
 1012b38:	mov    0x8(%rdx),%rax
 1012b3c:	test   %rax,%rax
 1012b3f:	je     1012b47 <myl_rc_dead_outside+0x47>
 1012b41:	cmpl   $0x0,0x40(%rax)
 1012b45:	je     1012b68 <myl_rc_dead_outside+0x68>
 1012b47:	mov    0x1608(%rdi),%rax
 1012b4e:	mov    0xc8(%rax),%rax
 1012b55:	mov    %rax,(%rsi)
 1012b58:	mov    0x1608(%rdi),%rax
 1012b5f:	mov    %rsi,0xc8(%rax)
 1012b66:	pop    %rbp
 1012b67:	ret
 1012b68:	movabs $0x4000000000000003,%rax
 1012b72:	and    0x10(%rsi),%rax
 1012b76:	cmp    $0x1,%rax
 1012b7a:	jne    1012ba3 <myl_rc_dead_outside+0xa3>
 1012b7c:	mov    0x1608(%rdi),%rax
 1012b83:	mov    0x8(%rax),%rax
 1012b87:	add    $0x20,%rsi
 1012b8b:	pop    %rbp
 1012b8c:	jmp    *%rax
 1012b8e:	mov    %rsi,%rcx
 1012b91:	mov    %rax,%rsi
 1012b94:	call   10130fa <myl_rc_binding_find_slow>
 1012b99:	mov    %rcx,%rsi
 1012b9c:	test   %rax,%rax
 1012b9f:	jne    1012b41 <myl_rc_dead_outside+0x41>
 1012ba1:	jmp    1012b47 <myl_rc_dead_outside+0x47>
 1012ba3:	call   101267d <myl_rc_invariant_failed>
 1012ba8:	int3
 1012ba9:	int3
 1012baa:	int3
 1012bab:	int3
 1012bac:	int3
 1012bad:	int3
 1012bae:	int3
 1012baf:	int3

0000000001012bb0 <myl_rc_edge_release>:
 1012bb0:	push   %rbp
 1012bb1:	mov    %rsp,%rbp
 1012bb4:	test   %rsi,%rsi
 1012bb7:	je     1012bcc <myl_rc_edge_release+0x1c>
 1012bb9:	movabs $0x4000000000000002,%rcx
 1012bc3:	mov    -0x10(%rsi),%r8
 1012bc7:	test   %rcx,%r8
 1012bca:	je     1012bce <myl_rc_edge_release+0x1e>
 1012bcc:	pop    %rbp
 1012bcd:	ret
 1012bce:	test   %rdi,%rdi
 1012bd1:	je     1012cc2 <myl_rc_edge_release+0x112>
 1012bd7:	cmpq   $0x0,0x1608(%rdi)
 1012bdf:	je     1012cc2 <myl_rc_edge_release+0x112>
 1012be5:	test   $0x1,%r8b
 1012be9:	jne    1012cc2 <myl_rc_edge_release+0x112>
 1012bef:	mov    -0x20(%rsi),%rax
 1012bf3:	test   %rax,%rax
 1012bf6:	je     1012cc2 <myl_rc_edge_release+0x112>
 1012bfc:	lea    -0x20(%rsi),%rdx
 1012c00:	dec    %rax
 1012c03:	mov    %rax,(%rdx)
 1012c06:	jne    1012bcc <myl_rc_edge_release+0x1c>
 1012c08:	cmpq   $0x0,-0x18(%rsi)
 1012c0d:	jne    1012bcc <myl_rc_edge_release+0x1c>
 1012c0f:	or     $0x1,%r8
 1012c13:	mov    %r8,-0x10(%rsi)
 1012c17:	mov    0x1608(%rdi),%r9
 1012c1e:	cmpl   $0x0,0xd0(%r9)
 1012c26:	je     1012c31 <myl_rc_edge_release+0x81>
 1012c28:	mov    0xc8(%r9),%rax
 1012c2f:	jmp    1012c7c <myl_rc_edge_release+0xcc>
 1012c31:	mov    -0x8(%rsi),%rax
 1012c35:	cmp    %rax,0x110(%r9)
 1012c3c:	je     1012c93 <myl_rc_edge_release+0xe3>
 1012c3e:	mov    0x34(%rax),%r8d
 1012c42:	cmp    %r8,0xa0(%r9)
 1012c49:	jbe    1012cad <myl_rc_edge_release+0xfd>
 1012c4b:	mov    0x98(%r9),%r9
 1012c52:	shl    $0x4,%r8
 1012c56:	cmp    %rax,(%r9,%r8,1)
 1012c5a:	jne    1012cad <myl_rc_edge_release+0xfd>
 1012c5c:	add    %r8,%r9
 1012c5f:	mov    0x8(%r9),%rax
 1012c63:	test   %rax,%rax
 1012c66:	je     1012c6e <myl_rc_edge_release+0xbe>
 1012c68:	cmpl   $0x0,0x40(%rax)
 1012c6c:	je     1012c8f <myl_rc_edge_release+0xdf>
 1012c6e:	mov    0x1608(%rdi),%rax
 1012c75:	mov    0xc8(%rax),%rax
 1012c7c:	mov    %rax,(%rdx)
 1012c7f:	mov    0x1608(%rdi),%rax
 1012c86:	mov    %rdx,0xc8(%rax)
 1012c8d:	pop    %rbp
 1012c8e:	ret
 1012c8f:	mov    -0x10(%rsi),%r8
 1012c93:	inc    %rcx
 1012c96:	and    %r8,%rcx
 1012c99:	cmp    $0x1,%rcx
 1012c9d:	jne    1012cc2 <myl_rc_edge_release+0x112>
 1012c9f:	mov    0x1608(%rdi),%rax
 1012ca6:	mov    0x8(%rax),%rax
 1012caa:	pop    %rbp
 1012cab:	jmp    *%rax
 1012cad:	mov    %rsi,%r8
 1012cb0:	mov    %rax,%rsi
 1012cb3:	call   10130fa <myl_rc_binding_find_slow>
 1012cb8:	mov    %r8,%rsi
 1012cbb:	test   %rax,%rax
 1012cbe:	jne    1012c68 <myl_rc_edge_release+0xb8>
 1012cc0:	jmp    1012c6e <myl_rc_edge_release+0xbe>
 1012cc2:	call   101267d <myl_rc_invariant_failed>
 1012cc7:	int3
 1012cc8:	int3
 1012cc9:	int3
 1012cca:	int3
 1012ccb:	int3
 1012ccc:	int3
 1012ccd:	int3
 1012cce:	int3
 1012ccf:	int3

0000000001012cd0 <myl_rc_owner_release>:
 1012cd0:	push   %rbp
 1012cd1:	mov    %rsp,%rbp
 1012cd4:	push   %rbx
 1012cd5:	push   %rax
 1012cd6:	mov    %rdi,%rbx
 1012cd9:	call   1012bb0 <myl_rc_edge_release>
 1012cde:	test   %rbx,%rbx
 1012ce1:	je     1012d07 <myl_rc_owner_release+0x37>
 1012ce3:	mov    0x1608(%rbx),%rax
 1012cea:	test   %rax,%rax
 1012ced:	je     1012d07 <myl_rc_owner_release+0x37>
 1012cef:	cmpq   $0x0,0xc8(%rax)
 1012cf7:	je     1012d07 <myl_rc_owner_release+0x37>
 1012cf9:	mov    %rbx,%rdi
 1012cfc:	add    $0x8,%rsp
 1012d00:	pop    %rbx
 1012d01:	pop    %rbp
 1012d02:	jmp    1016210 <myl_rc_drain>
 1012d07:	add    $0x8,%rsp
 1012d0b:	pop    %rbx
 1012d0c:	pop    %rbp
 1012d0d:	ret
 1012d0e:	int3
 1012d0f:	int3

0000000001012d10 <myl_rc_unique>:
 1012d10:	push   %rbp
 1012d11:	mov    %rsp,%rbp
 1012d14:	mov    $0x1,%eax
 1012d19:	test   %rsi,%rsi
 1012d1c:	je     1012d51 <myl_rc_unique+0x41>
 1012d1e:	mov    -0x10(%rsi),%rcx
 1012d22:	movabs $0x6000000000000002,%rax
 1012d2c:	test   %rax,%rcx
 1012d2f:	jne    1012d40 <myl_rc_unique+0x30>
 1012d31:	test   %rdi,%rdi
 1012d34:	je     1012d7f <myl_rc_unique+0x6f>
 1012d36:	cmpq   $0x0,0x1608(%rdi)
 1012d3e:	je     1012d7f <myl_rc_unique+0x6f>
 1012d40:	xor    %eax,%eax
 1012d42:	movabs $0x2000000000000002,%rdx
 1012d4c:	test   %rdx,%rcx
 1012d4f:	je     1012d53 <myl_rc_unique+0x43>
 1012d51:	pop    %rbp
 1012d52:	ret
 1012d53:	bt     $0x3e,%rcx
 1012d58:	mov    $0x1,%eax
 1012d5d:	jb     1012d51 <myl_rc_unique+0x41>
 1012d5f:	test   $0x1,%cl
 1012d62:	jne    1012d7f <myl_rc_unique+0x6f>
 1012d64:	mov    -0x20(%rsi),%rcx
 1012d68:	test   %rcx,%rcx
 1012d6b:	jne    1012d74 <myl_rc_unique+0x64>
 1012d6d:	cmpq   $0x0,-0x18(%rsi)
 1012d72:	je     1012d7f <myl_rc_unique+0x6f>
 1012d74:	xor    %eax,%eax
 1012d76:	cmp    $0x2,%rcx
 1012d7a:	setb   %al
 1012d7d:	pop    %rbp
 1012d7e:	ret
 1012d7f:	call   101267d <myl_rc_invariant_failed>
 1012d84:	int3
 1012d85:	int3
 1012d86:	int3
 1012d87:	int3
 1012d88:	int3
 1012d89:	int3
 1012d8a:	int3
 1012d8b:	int3
 1012d8c:	int3
 1012d8d:	int3
 1012d8e:	int3
 1012d8f:	int3

0000000001012d90 <myl_rc_hold_acquire>:
 1012d90:	push   %rbp
 1012d91:	mov    %rsp,%rbp
 1012d94:	test   %rdx,%rdx
 1012d97:	je     1012df2 <myl_rc_hold_acquire+0x62>
 1012d99:	cmpq   $0x0,(%rdx)
 1012d9d:	jne    1012df2 <myl_rc_hold_acquire+0x62>
 1012d9f:	test   %rsi,%rsi
 1012da2:	je     1012de4 <myl_rc_hold_acquire+0x54>
 1012da4:	mov    -0x10(%rsi),%rax
 1012da8:	movabs $0x4000000000000002,%rcx
 1012db2:	test   %rcx,%rax
 1012db5:	jne    1012de4 <myl_rc_hold_acquire+0x54>
 1012db7:	test   %rdi,%rdi
 1012dba:	je     1012df2 <myl_rc_hold_acquire+0x62>
 1012dbc:	cmpq   $0x0,0x1608(%rdi)
 1012dc4:	je     1012df2 <myl_rc_hold_acquire+0x62>
 1012dc6:	test   $0x1,%al
 1012dc8:	jne    1012df2 <myl_rc_hold_acquire+0x62>
 1012dca:	mov    -0x18(%rsi),%rax
 1012dce:	mov    -0x20(%rsi),%rcx
 1012dd2:	or     %rax,%rcx
 1012dd5:	je     1012df2 <myl_rc_hold_acquire+0x62>
 1012dd7:	cmp    $0xffffffffffffffff,%rax
 1012ddb:	je     1012deb <myl_rc_hold_acquire+0x5b>
 1012ddd:	inc    %rax
 1012de0:	mov    %rax,-0x18(%rsi)
 1012de4:	mov    %rsi,(%rdx)
 1012de7:	xor    %eax,%eax
 1012de9:	pop    %rbp
 1012dea:	ret
 1012deb:	mov    $0x2,%eax
 1012df0:	pop    %rbp
 1012df1:	ret
 1012df2:	call   101267d <myl_rc_invariant_failed>
 1012df7:	int3
 1012df8:	int3
 1012df9:	int3
 1012dfa:	int3
 1012dfb:	int3
 1012dfc:	int3
 1012dfd:	int3
 1012dfe:	int3
 1012dff:	int3

0000000001012e00 <myl_rc_hold_edge_release>:
 1012e00:	push   %rbp
 1012e01:	mov    %rsp,%rbp
 1012e04:	test   %rsi,%rsi
 1012e07:	je     1012e1c <myl_rc_hold_edge_release+0x1c>
 1012e09:	movabs $0x4000000000000002,%rcx
 1012e13:	mov    -0x10(%rsi),%r8
 1012e17:	test   %rcx,%r8
 1012e1a:	je     1012e1e <myl_rc_hold_edge_release+0x1e>
 1012e1c:	pop    %rbp
 1012e1d:	ret
 1012e1e:	test   %rdi,%rdi
 1012e21:	je     1012f10 <myl_rc_hold_edge_release+0x110>
 1012e27:	cmpq   $0x0,0x1608(%rdi)
 1012e2f:	je     1012f10 <myl_rc_hold_edge_release+0x110>
 1012e35:	test   $0x1,%r8b
 1012e39:	jne    1012f10 <myl_rc_hold_edge_release+0x110>
 1012e3f:	mov    -0x18(%rsi),%rax
 1012e43:	test   %rax,%rax
 1012e46:	je     1012f10 <myl_rc_hold_edge_release+0x110>
 1012e4c:	dec    %rax
 1012e4f:	mov    %rax,-0x18(%rsi)
 1012e53:	or     -0x20(%rsi),%rax
 1012e57:	jne    1012e1c <myl_rc_hold_edge_release+0x1c>
 1012e59:	lea    -0x20(%rsi),%rdx
 1012e5d:	or     $0x1,%r8
 1012e61:	mov    %r8,-0x10(%rsi)
 1012e65:	mov    0x1608(%rdi),%r9
 1012e6c:	cmpl   $0x0,0xd0(%r9)
 1012e74:	je     1012e7f <myl_rc_hold_edge_release+0x7f>
 1012e76:	mov    0xc8(%r9),%rax
 1012e7d:	jmp    1012eca <myl_rc_hold_edge_release+0xca>
 1012e7f:	mov    -0x8(%rsi),%rax
 1012e83:	cmp    %rax,0x110(%r9)
 1012e8a:	je     1012ee1 <myl_rc_hold_edge_release+0xe1>
 1012e8c:	mov    0x34(%rax),%r8d
 1012e90:	cmp    %r8,0xa0(%r9)
 1012e97:	jbe    1012efb <myl_rc_hold_edge_release+0xfb>
 1012e99:	mov    0x98(%r9),%r9
 1012ea0:	shl    $0x4,%r8
 1012ea4:	cmp    %rax,(%r9,%r8,1)
 1012ea8:	jne    1012efb <myl_rc_hold_edge_release+0xfb>
 1012eaa:	add    %r8,%r9
 1012ead:	mov    0x8(%r9),%rax
 1012eb1:	test   %rax,%rax
 1012eb4:	je     1012ebc <myl_rc_hold_edge_release+0xbc>
 1012eb6:	cmpl   $0x0,0x40(%rax)
 1012eba:	je     1012edd <myl_rc_hold_edge_release+0xdd>
 1012ebc:	mov    0x1608(%rdi),%rax
 1012ec3:	mov    0xc8(%rax),%rax
 1012eca:	mov    %rax,(%rdx)
 1012ecd:	mov    0x1608(%rdi),%rax
 1012ed4:	mov    %rdx,0xc8(%rax)
 1012edb:	pop    %rbp
 1012edc:	ret
 1012edd:	mov    -0x10(%rsi),%r8
 1012ee1:	inc    %rcx
 1012ee4:	and    %r8,%rcx
 1012ee7:	cmp    $0x1,%rcx
 1012eeb:	jne    1012f10 <myl_rc_hold_edge_release+0x110>
 1012eed:	mov    0x1608(%rdi),%rax
 1012ef4:	mov    0x8(%rax),%rax
 1012ef8:	pop    %rbp
 1012ef9:	jmp    *%rax
 1012efb:	mov    %rsi,%r8
 1012efe:	mov    %rax,%rsi
 1012f01:	call   10130fa <myl_rc_binding_find_slow>
 1012f06:	mov    %r8,%rsi
 1012f09:	test   %rax,%rax
 1012f0c:	jne    1012eb6 <myl_rc_hold_edge_release+0xb6>
 1012f0e:	jmp    1012ebc <myl_rc_hold_edge_release+0xbc>
 1012f10:	call   101267d <myl_rc_invariant_failed>
 1012f15:	int3
 1012f16:	int3
 1012f17:	int3
 1012f18:	int3
 1012f19:	int3
 1012f1a:	int3
 1012f1b:	int3
 1012f1c:	int3
 1012f1d:	int3
 1012f1e:	int3
 1012f1f:	int3

0000000001012f20 <myl_rc_hold_release>:
 1012f20:	push   %rbp
 1012f21:	mov    %rsp,%rbp
 1012f24:	push   %rbx
 1012f25:	push   %rax
 1012f26:	test   %rsi,%rsi
 1012f29:	je     1012f70 <myl_rc_hold_release+0x50>
 1012f2b:	mov    %rdi,%rbx
 1012f2e:	mov    (%rsi),%rax
 1012f31:	movq   $0x0,(%rsi)
 1012f38:	mov    %rax,%rsi
 1012f3b:	call   1012e00 <myl_rc_hold_edge_release>
 1012f40:	test   %rbx,%rbx
 1012f43:	je     1012f69 <myl_rc_hold_release+0x49>
 1012f45:	mov    0x1608(%rbx),%rax
 1012f4c:	test   %rax,%rax
 1012f4f:	je     1012f69 <myl_rc_hold_release+0x49>
 1012f51:	cmpq   $0x0,0xc8(%rax)
 1012f59:	je     1012f69 <myl_rc_hold_release+0x49>
 1012f5b:	mov    %rbx,%rdi
 1012f5e:	add    $0x8,%rsp
 1012f62:	pop    %rbx
 1012f63:	pop    %rbp
 1012f64:	jmp    1016210 <myl_rc_drain>
 1012f69:	add    $0x8,%rsp
 1012f6d:	pop    %rbx
 1012f6e:	pop    %rbp
 1012f6f:	ret
 1012f70:	call   101267d <myl_rc_invariant_failed>
 1012f75:	int3
 1012f76:	int3
 1012f77:	int3
 1012f78:	int3
 1012f79:	int3
 1012f7a:	int3
 1012f7b:	int3
 1012f7c:	int3
 1012f7d:	int3
 1012f7e:	int3
 1012f7f:	int3

0000000001012f80 <myl_rc_metadata_init>:
 1012f80:	push   %rbp
 1012f81:	mov    %rsp,%rbp
 1012f84:	lea    -0xfeeb(%rip),%rax        # 10030a0 <myl_rc_map_sentinel>
 1012f8b:	mov    %rax,0x78(%rdi)
 1012f8f:	vxorps %xmm0,%xmm0,%xmm0
 1012f93:	vmovups %xmm0,0x80(%rdi)
 1012f9b:	movq   $0x3f,0x90(%rdi)
 1012fa6:	vmovups 0x78(%rdi),%ymm1
 1012fab:	vmovups %ymm1,0x58(%rdi)
 1012fb0:	vmovups %ymm1,0x38(%rdi)
 1012fb5:	vmovups %xmm0,0x98(%rdi)
 1012fbd:	movq   $0x0,0xa8(%rdi)
 1012fc8:	pop    %rbp
 1012fc9:	vzeroupper
 1012fcc:	ret
 1012fcd:	int3
 1012fce:	int3
 1012fcf:	int3

0000000001012fd0 <myl_rc_metadata_release>:
 1012fd0:	push   %rbp
 1012fd1:	mov    %rsp,%rbp
 1012fd4:	push   %r15
 1012fd6:	push   %r14
 1012fd8:	push   %rbx
 1012fd9:	push   %rax
 1012fda:	mov    %rdi,%rbx
 1012fdd:	mov    0x1608(%rdi),%r15
 1012fe4:	mov    0x38(%r15),%rsi
 1012fe8:	cmp    $0x10030a0,%rsi
 1012fef:	je     101300b <myl_rc_metadata_release+0x3b>
 1012ff1:	mov    0x40(%r15),%rdx
 1012ff5:	cmp    $0xffffffffffffffff,%rdx
 1012ff9:	je     101300b <myl_rc_metadata_release+0x3b>
 1012ffb:	shl    $0x4,%rdx
 1012fff:	add    $0x10,%rdx
 1013003:	mov    %rbx,%rdi
 1013006:	call   1012710 <myl_rc_meta_free>
 101300b:	lea    -0xff72(%rip),%r14        # 10030a0 <myl_rc_map_sentinel>
 1013012:	mov    %r14,0x38(%r15)
 1013016:	vxorps %xmm0,%xmm0,%xmm0
 101301a:	vmovups %xmm0,0x40(%r15)
 1013020:	movq   $0x3f,0x50(%r15)
 1013028:	mov    0x1608(%rbx),%r15
 101302f:	mov    0x58(%r15),%rsi
 1013033:	cmp    %r14,%rsi
 1013036:	je     1013056 <myl_rc_metadata_release+0x86>
 1013038:	mov    0x60(%r15),%rdx
 101303c:	cmp    $0xffffffffffffffff,%rdx
 1013040:	je     1013056 <myl_rc_metadata_release+0x86>
 1013042:	shl    $0x4,%rdx
 1013046:	add    $0x10,%rdx
 101304a:	mov    %rbx,%rdi
 101304d:	call   1012710 <myl_rc_meta_free>
 1013052:	vxorps %xmm0,%xmm0,%xmm0
 1013056:	mov    %r14,0x58(%r15)
 101305a:	vmovups %xmm0,0x60(%r15)
 1013060:	movq   $0x3f,0x70(%r15)
 1013068:	mov    0x1608(%rbx),%r15
 101306f:	mov    0x78(%r15),%rsi
 1013073:	cmp    %r14,%rsi
 1013076:	je     1013095 <myl_rc_metadata_release+0xc5>
 1013078:	mov    0x80(%r15),%rdx
 101307f:	cmp    $0xffffffffffffffff,%rdx
 1013083:	je     1013095 <myl_rc_metadata_release+0xc5>
 1013085:	shl    $0x4,%rdx
 1013089:	add    $0x10,%rdx
 101308d:	mov    %rbx,%rdi
 1013090:	call   1012710 <myl_rc_meta_free>
 1013095:	mov    %r14,0x78(%r15)
 1013099:	vxorps %xmm0,%xmm0,%xmm0
 101309d:	vmovups %xmm0,0x80(%r15)
 10130a6:	movq   $0x3f,0x90(%r15)
 10130b1:	mov    0x1608(%rbx),%rax
 10130b8:	lea    0x98(%rax),%r14
 10130bf:	mov    0x98(%rax),%rsi
 10130c6:	test   %rsi,%rsi
 10130c9:	je     10130e2 <myl_rc_metadata_release+0x112>
 10130cb:	mov    0xa0(%rax),%rdx
 10130d2:	shl    $0x4,%rdx
 10130d6:	mov    %rbx,%rdi
 10130d9:	call   1012710 <myl_rc_meta_free>
 10130de:	vxorps %xmm0,%xmm0,%xmm0
 10130e2:	vmovups %xmm0,(%r14)
 10130e7:	movq   $0x0,0x10(%r14)
 10130ef:	add    $0x8,%rsp
 10130f3:	pop    %rbx
 10130f4:	pop    %r14
 10130f6:	pop    %r15
 10130f8:	pop    %rbp
 10130f9:	ret

00000000010130fa <myl_rc_binding_find_slow>:
 10130fa:	push   %rbp
 10130fb:	mov    %rsp,%rbp
 10130fe:	push   %r10
 1013100:	push   %r9
 1013102:	push   %r8
 1013104:	push   %rdi
 1013105:	push   %rsi
 1013106:	push   %rdx
 1013107:	push   %rcx
 1013108:	push   %r15
 101310a:	push   %r14
 101310c:	push   %rbx
 101310d:	mov    %rsi,%rbx
 1013110:	mov    0x1608(%rdi),%r11
 1013117:	mov    0x34(%rsi),%eax
 101311a:	cmp    %rax,0xa0(%r11)
 1013121:	jbe    1013140 <myl_rc_binding_find_slow+0x46>
 1013123:	mov    0x98(%r11),%rcx
 101312a:	shl    $0x4,%rax
 101312e:	lea    (%rcx,%rax,1),%r15
 1013132:	mov    (%rcx,%rax,1),%rax
 1013136:	cmp    %rbx,%rax
 1013139:	je     10131a1 <myl_rc_binding_find_slow+0xa7>
 101313b:	test   %rax,%rax
 101313e:	je     10131b9 <myl_rc_binding_find_slow+0xbf>
 1013140:	mov    0x78(%r11),%rax
 1013144:	mov    0x80(%r11),%rcx
 101314b:	mov    0x90(%r11),%r11b
 1013152:	movabs $0x9e3779b97f4a7c15,%rdx
 101315c:	imul   %rbx,%rdx
 1013160:	shrx   %r11,%rdx,%r11
 1013165:	and    %rcx,%r11
 1013168:	mov    %r11,%rdx
 101316b:	shl    $0x4,%rdx
 101316f:	mov    (%rax,%rdx,1),%rdx
 1013173:	cmp    %rbx,%rdx
 1013176:	je     1013196 <myl_rc_binding_find_slow+0x9c>
 1013178:	xor    %r14d,%r14d
 101317b:	test   %rdx,%rdx
 101317e:	je     10131a5 <myl_rc_binding_find_slow+0xab>
 1013180:	inc    %r11
 1013183:	and    %rcx,%r11
 1013186:	mov    %r11,%rdx
 1013189:	shl    $0x4,%rdx
 101318d:	mov    (%rax,%rdx,1),%rdx
 1013191:	cmp    %rbx,%rdx
 1013194:	jne    101317b <myl_rc_binding_find_slow+0x81>
 1013196:	shl    $0x4,%r11
 101319a:	mov    0x8(%rax,%r11,1),%r14
 101319f:	jmp    10131a5 <myl_rc_binding_find_slow+0xab>
 10131a1:	mov    0x8(%r15),%r14
 10131a5:	mov    %r14,%rax
 10131a8:	pop    %rbx
 10131a9:	pop    %r14
 10131ab:	pop    %r15
 10131ad:	pop    %rcx
 10131ae:	pop    %rdx
 10131af:	pop    %rsi
 10131b0:	pop    %rdi
 10131b1:	pop    %r8
 10131b3:	pop    %r9
 10131b5:	pop    %r10
 10131b7:	pop    %rbp
 10131b8:	ret
 10131b9:	mov    0x8(%r15),%r14
 10131bd:	test   %r14,%r14
 10131c0:	je     1013140 <myl_rc_binding_find_slow+0x46>
 10131c6:	cmp    %rbx,(%r14)
 10131c9:	jne    1013140 <myl_rc_binding_find_slow+0x46>
 10131cf:	mov    %r14,%rdi
 10131d2:	call   10131e0 <flat_build>
 10131d7:	mov    %rbx,(%r15)
 10131da:	jmp    10131a5 <myl_rc_binding_find_slow+0xab>
 10131dc:	int3
 10131dd:	int3
 10131de:	int3
 10131df:	int3

00000000010131e0 <flat_build>:
 10131e0:	push   %rbp
 10131e1:	mov    %rsp,%rbp
 10131e4:	push   %r15
 10131e6:	push   %r14
 10131e8:	push   %r13
 10131ea:	push   %r12
 10131ec:	push   %rbx
 10131ed:	sub    $0x368,%rsp
 10131f4:	movl   $0x11,0x40(%rdi)
 10131fb:	movw   $0x0,0x44(%rdi)
 1013201:	movb   $0x0,0x46(%rdi)
 1013205:	mov    (%rdi),%r14
 1013208:	mov    (%r14),%rax
 101320b:	mov    %rax,0x50(%rdi)
 101320f:	cmpq   $0x0,0x10(%rdi)
 1013214:	jne    1013239 <flat_build+0x59>
 1013216:	cmpq   $0x0,0x18(%rdi)
 101321b:	jne    1013239 <flat_build+0x59>
 101321d:	cmpq   $0x0,0x20(%rdi)
 1013222:	jne    1013239 <flat_build+0x59>
 1013224:	cmpq   $0x0,0x28(%rdi)
 1013229:	jne    1013239 <flat_build+0x59>
 101322b:	cmpq   $0x0,0x30(%rdi)
 1013230:	jne    1013239 <flat_build+0x59>
 1013232:	cmpq   $0x0,0x38(%rdi)
 1013237:	je     101324b <flat_build+0x6b>
 1013239:	add    $0x368,%rsp
 1013240:	pop    %rbx
 1013241:	pop    %r12
 1013243:	pop    %r13
 1013245:	pop    %r14
 1013247:	pop    %r15
 1013249:	pop    %rbp
 101324a:	ret
 101324b:	lea    0x40(%rdi),%rax
 101324f:	mov    %rax,-0x48(%rbp)
 1013253:	lea    -0x380(%rbp),%rax
 101325a:	mov    $0x270,%edx
 101325f:	mov    %rdi,-0x38(%rbp)
 1013263:	mov    %rax,%rdi
 1013266:	xor    %esi,%esi
 1013268:	call   101e6b0 <compiler_rt.fastMemset>
 101326d:	mov    %r14,-0x390(%rbp)
 1013274:	mov    -0x38(%rbp),%rax
 1013278:	mov    0x8(%rax),%rax
 101327c:	mov    %rax,-0x388(%rbp)
 1013283:	movl   $0xffffffff,-0x370(%rbp)
 101328d:	mov    $0x1,%r12b
 1013290:	mov    $0x1,%ecx
 1013295:	mov    $0xc1,%esi
 101329a:	xor    %r14d,%r14d
 101329d:	xor    %ebx,%ebx
 101329f:	cmp    $0x9,%rcx
 10132a3:	movzbl %r12b,%r12d
 10132a7:	mov    $0x0,%eax
 10132ac:	cmovae %eax,%r12d
 10132b0:	dec    %rsi
 10132b3:	je     1013239 <flat_build+0x59>
 10132b5:	lea    (%rcx,%rcx,4),%rax
 10132b9:	mov    -0x3b8(%rbp,%rax,8),%r8
 10132c1:	test   %r8,%r8
 10132c4:	je     1013239 <flat_build+0x59>
 10132ca:	mov    -0x3b0(%rbp,%rax,8),%r11
 10132d2:	test   %r11,%r11
 10132d5:	je     10132e9 <flat_build+0x109>
 10132d7:	mov    (%r8),%rdx
 10132da:	cmp    (%r11),%rdx
 10132dd:	jne    1013239 <flat_build+0x59>
 10132e3:	mov    0x8(%r11),%r13d
 10132e7:	jmp    10132ec <flat_build+0x10c>
 10132e9:	xor    %r13d,%r13d
 10132ec:	movzwl 0x30(%r8),%edx
 10132f1:	cmp    $0x7,%edx
 10132f4:	je     101330e <flat_build+0x12e>
 10132f6:	lea    -0x390(,%rax,8),%rdi
 10132fe:	add    %rbp,%rdi
 1013301:	cmp    $0x1,%edx
 1013304:	je     1013318 <flat_build+0x138>
 1013306:	test   %edx,%edx
 1013308:	jne    1013390 <flat_build+0x1b0>
 101330e:	test   %r13d,%r13d
 1013311:	je     101337f <flat_build+0x19f>
 1013313:	jmp    1013239 <flat_build+0x59>
 1013318:	cmpw   $0x5,0x32(%r8)
 101331e:	jne    1013332 <flat_build+0x152>
 1013320:	cmpq   $0x0,0x38(%r8)
 1013325:	movzbl %r12b,%r12d
 1013329:	mov    $0x0,%eax
 101332e:	cmovne %eax,%r12d
 1013332:	cmp    $0x1,%r13d
 1013336:	jne    1013239 <flat_build+0x59>
 101333c:	cmpq   $0x8,(%r8)
 1013340:	jne    1013239 <flat_build+0x59>
 1013346:	cmp    $0x10,%r14d
 101334a:	je     1013239 <flat_build+0x59>
 1013350:	mov    -0x18(%rdi),%rax
 1013354:	mov    $0xfffffff7,%edx
 1013359:	cmp    %rdx,%rax
 101335c:	ja     1013239 <flat_build+0x59>
 1013362:	mov    %r14d,%edx
 1013365:	inc    %r14d
 1013368:	lea    (%rdx,%rdx,2),%rdx
 101336c:	mov    %eax,-0x110(%rbp,%rdx,4)
 1013373:	mov    -0x8(%rdi),%rax
 1013377:	mov    %rax,-0x10c(%rbp,%rdx,4)
 101337f:	dec    %rcx
 1013382:	test   %rcx,%rcx
 1013385:	jne    101329f <flat_build+0xbf>
 101338b:	jmp    10135d2 <flat_build+0x3f2>
 1013390:	mov    -0x8(%rdi),%eax
 1013393:	mov    %rax,-0x30(%rbp)
 1013397:	mov    -0x4(%rdi),%r9d
 101339b:	cmp    $0x4,%edx
 101339e:	je     10134ac <flat_build+0x2cc>
 10133a4:	cmp    $0x3,%edx
 10133a7:	je     1013423 <flat_build+0x243>
 10133a9:	cmp    $0x2,%edx
 10133ac:	jne    1013239 <flat_build+0x59>
 10133b2:	test   $0xfffffffd,%r13d
 10133b9:	jne    1013239 <flat_build+0x59>
 10133bf:	mov    0x18(%r8),%rdx
 10133c3:	cmp    $0x2,%r13d
 10133c7:	jne    10133d3 <flat_build+0x1f3>
 10133c9:	cmp    0x18(%r11),%rdx
 10133cd:	jne    1013239 <flat_build+0x59>
 10133d3:	mov    -0x10(%rdi),%rax
 10133d7:	cmp    %rdx,%rax
 10133da:	je     101337f <flat_build+0x19f>
 10133dc:	mov    0x10(%r8),%r10
 10133e0:	test   %r10,%r10
 10133e3:	je     1013239 <flat_build+0x59>
 10133e9:	lea    0x1(%rax),%rdx
 10133ed:	mov    %rdx,-0x10(%rdi)
 10133f1:	lea    (%rax,%rax,2),%rdx
 10133f5:	mov    (%r10,%rdx,8),%rax
 10133f9:	mov    0x8(%r10,%rdx,8),%r15
 10133fe:	cmp    $0x2,%r13d
 1013402:	jne    1013561 <flat_build+0x381>
 1013408:	mov    0x10(%r11),%r10
 101340c:	cmp    (%r10,%rdx,8),%rax
 1013410:	jne    1013239 <flat_build+0x59>
 1013416:	lea    (%r10,%rdx,8),%rdx
 101341a:	mov    0x8(%rdx),%rdx
 101341e:	jmp    101356b <flat_build+0x38b>
 1013423:	cmp    $0x3,%r13d
 1013427:	je     1013432 <flat_build+0x252>
 1013429:	test   %r13d,%r13d
 101342c:	jne    1013239 <flat_build+0x59>
 1013432:	mov    0x20(%r8),%rdx
 1013436:	cmp    $0x3,%r13d
 101343a:	jne    1013454 <flat_build+0x274>
 101343c:	cmp    0x18(%r11),%rdx
 1013440:	jne    1013239 <flat_build+0x59>
 1013446:	mov    0x28(%r8),%rax
 101344a:	cmp    0x20(%r11),%rax
 101344e:	jne    1013239 <flat_build+0x59>
 1013454:	mov    -0x10(%rdi),%rax
 1013458:	cmp    %rdx,%rax
 101345b:	je     101337f <flat_build+0x19f>
 1013461:	mov    0x38(%r8),%r15
 1013465:	test   %r15,%r15
 1013468:	jne    1013487 <flat_build+0x2a7>
 101346a:	cmpq   $0x1,0x18(%r8)
 101346f:	jne    1013484 <flat_build+0x2a4>
 1013471:	mov    0x10(%r8),%rdx
 1013475:	test   %rdx,%rdx
 1013478:	je     1013484 <flat_build+0x2a4>
 101347a:	cmpq   $0x0,(%rdx)
 101347e:	je     10135c9 <flat_build+0x3e9>
 1013484:	xor    %r15d,%r15d
 1013487:	lea    0x1(%rax),%rdx
 101348b:	mov    %rdx,-0x10(%rdi)
 101348f:	mulq   0x28(%r8)
 1013493:	jo     1013239 <flat_build+0x59>
 1013499:	cmp    $0x3,%r13d
 101349d:	jne    1013561 <flat_build+0x381>
 10134a3:	mov    0x10(%r11),%rdx
 10134a7:	jmp    101356b <flat_build+0x38b>
 10134ac:	test   $0xfffffffb,%r13d
 10134b3:	jne    1013239 <flat_build+0x59>
 10134b9:	mov    -0x10(%rdi),%rax
 10134bd:	mov    0x18(%r8),%r10
 10134c1:	cmp    %r10,%rax
 10134c4:	je     101337f <flat_build+0x19f>
 10134ca:	mov    0x10(%r8),%rdx
 10134ce:	test   %rdx,%rdx
 10134d1:	je     1013239 <flat_build+0x59>
 10134d7:	mov    %rbx,-0x40(%rbp)
 10134db:	lea    0x1(%rax),%rbx
 10134df:	mov    %rbx,-0x10(%rdi)
 10134e3:	lea    (%rax,%rax,2),%rbx
 10134e7:	mov    (%rdx,%rbx,8),%rax
 10134eb:	mov    0x8(%rdx,%rbx,8),%r15
 10134f0:	cmp    $0x4,%r13d
 10134f4:	jne    1013565 <flat_build+0x385>
 10134f6:	cmp    0x18(%r11),%r10
 10134fa:	jne    1013239 <flat_build+0x59>
 1013500:	cmpl   $0xffffffff,-0x30(%rbp)
 1013504:	jne    1013239 <flat_build+0x59>
 101350a:	lea    0x0(,%rbx,8),%r13
 1013512:	add    0x10(%r11),%r13
 1013516:	cmp    0x0(%r13),%rax
 101351a:	jne    1013239 <flat_build+0x59>
 1013520:	lea    (%rdx,%rbx,8),%rdx
 1013524:	mov    0x10(%rdx),%edx
 1013527:	cmp    0x10(%r13),%edx
 101352b:	jne    1013239 <flat_build+0x59>
 1013531:	mov    %edx,%r9d
 1013534:	mov    -0x18(%rdi),%rdx
 1013538:	add    0x20(%r11),%rdx
 101353c:	mov    %rdx,-0x30(%rbp)
 1013540:	jb     1013239 <flat_build+0x59>
 1013546:	mov    $0xfffffff7,%edx
 101354b:	add    $0x4,%rdx
 101354f:	cmp    %rdx,-0x30(%rbp)
 1013553:	ja     1013239 <flat_build+0x59>
 1013559:	mov    0x8(%r13),%rdx
 101355d:	mov    $0x1,%bl
 101355f:	jmp    101356b <flat_build+0x38b>
 1013561:	xor    %edx,%edx
 1013563:	jmp    101356b <flat_build+0x38b>
 1013565:	xor    %edx,%edx
 1013567:	mov    -0x40(%rbp),%rbx
 101356b:	cmp    $0x10,%rcx
 101356f:	je     1013239 <flat_build+0x59>
 1013575:	test   %r15,%r15
 1013578:	je     1013239 <flat_build+0x59>
 101357e:	mov    (%r8),%r8
 1013581:	sub    %rax,%r8
 1013584:	jb     1013239 <flat_build+0x59>
 101358a:	cmp    %r8,(%r15)
 101358d:	ja     1013239 <flat_build+0x59>
 1013593:	add    -0x18(%rdi),%rax
 1013597:	jb     1013239 <flat_build+0x59>
 101359d:	inc    %rcx
 10135a0:	mov    %r15,(%rdi)
 10135a3:	mov    %rdx,0x8(%rdi)
 10135a7:	mov    %rax,0x10(%rdi)
 10135ab:	movq   $0x0,0x18(%rdi)
 10135b3:	mov    -0x30(%rbp),%rax
 10135b7:	mov    %eax,0x20(%rdi)
 10135ba:	mov    %r9d,0x24(%rdi)
 10135be:	test   %rcx,%rcx
 10135c1:	jne    101329f <flat_build+0xbf>
 10135c7:	jmp    10135d2 <flat_build+0x3f2>
 10135c9:	mov    0x8(%rdx),%r15
 10135cd:	jmp    1013487 <flat_build+0x2a7>
 10135d2:	lea    -0x110(%rbp),%rdi
 10135d9:	mov    %r14d,%esi
 10135dc:	call   1015570 <flat_disjoint>
 10135e1:	test   %eax,%eax
 10135e3:	je     1013239 <flat_build+0x59>
 10135e9:	lea    -0x110(%rbp),%rsi
 10135f0:	mov    -0x48(%rbp),%rdi
 10135f4:	mov    %r14d,%edx
 10135f7:	call   1015660 <flat_masks>
 10135fc:	mov    -0x38(%rbp),%rcx
 1013600:	test   %eax,%eax
 1013602:	je     1013239 <flat_build+0x59>
 1013608:	mov    %r14d,0x40(%rcx)
 101360c:	mov    %r12b,0x44(%rcx)
 1013610:	mov    %bl,0x46(%rcx)
 1013613:	jmp    1013239 <flat_build+0x59>
 1013618:	int3
 1013619:	int3
 101361a:	int3
 101361b:	int3
 101361c:	int3
 101361d:	int3
 101361e:	int3
 101361f:	int3

0000000001013620 <myl_rc_module_register>:
 1013620:	push   %rbp
 1013621:	mov    %rsp,%rbp
 1013624:	push   %r15
 1013626:	push   %r14
 1013628:	push   %r12
 101362a:	push   %rbx
 101362b:	sub    $0x30,%rsp
 101362f:	test   %rdi,%rdi
 1013632:	je     10137fb <myl_rc_module_register+0x1db>
 1013638:	mov    %rsi,%rbx
 101363b:	test   %rsi,%rsi
 101363e:	je     10137fb <myl_rc_module_register+0x1db>
 1013644:	mov    0x1608(%rdi),%rcx
 101364b:	test   %rcx,%rcx
 101364e:	je     10137fb <myl_rc_module_register+0x1db>
 1013654:	cmpl   $0x5,(%rbx)
 1013657:	jne    10137fb <myl_rc_module_register+0x1db>
 101365d:	cmpq   $0x0,0xc0(%rcx)
 1013665:	jne    10137fb <myl_rc_module_register+0x1db>
 101366b:	mov    0x38(%rcx),%rax
 101366f:	mov    0x40(%rcx),%rdx
 1013673:	movzbl 0x50(%rcx),%ecx
 1013677:	movabs $0x9e3779b97f4a7c15,%rsi
 1013681:	imul   %rbx,%rsi
 1013685:	shrx   %rcx,%rsi,%rcx
 101368a:	nopw   0x0(%rax,%rax,1)
 1013690:	and    %rdx,%rcx
 1013693:	mov    %rcx,%rsi
 1013696:	shl    $0x4,%rsi
 101369a:	mov    (%rax,%rsi,1),%rsi
 101369e:	cmp    %rbx,%rsi
 10136a1:	je     10136ad <myl_rc_module_register+0x8d>
 10136a3:	test   %rsi,%rsi
 10136a6:	je     10136c0 <myl_rc_module_register+0xa0>
 10136a8:	inc    %rcx
 10136ab:	jmp    1013690 <myl_rc_module_register+0x70>
 10136ad:	shl    $0x4,%rcx
 10136b1:	xor    %r14d,%r14d
 10136b4:	cmpq   $0x0,0x8(%rax,%rcx,1)
 10136ba:	jne    10137eb <myl_rc_module_register+0x1cb>
 10136c0:	mov    0x10(%rbx),%rax
 10136c4:	test   %rax,%rax
 10136c7:	je     10136d4 <myl_rc_module_register+0xb4>
 10136c9:	cmpq   $0x0,0x8(%rbx)
 10136ce:	je     10137fb <myl_rc_module_register+0x1db>
 10136d4:	mov    0x20(%rbx),%rcx
 10136d8:	test   %rcx,%rcx
 10136db:	je     10136e8 <myl_rc_module_register+0xc8>
 10136dd:	cmpq   $0x0,0x18(%rbx)
 10136e2:	je     10137fb <myl_rc_module_register+0x1db>
 10136e8:	vxorps %xmm0,%xmm0,%xmm0
 10136ec:	vmovups %ymm0,-0x48(%rbp)
 10136f1:	movq   $0x0,-0x28(%rbp)
 10136f9:	mov    %rdi,-0x50(%rbp)
 10136fd:	test   %rax,%rax
 1013700:	je     1013738 <myl_rc_module_register+0x118>
 1013702:	xor    %r15d,%r15d
 1013705:	lea    -0x50(%rbp),%r14
 1013709:	nopl   0x0(%rax)
 1013710:	mov    0x8(%rbx),%rax
 1013714:	mov    (%rax,%r15,8),%rsi
 1013718:	mov    %r14,%rdi
 101371b:	vzeroupper
 101371e:	call   1013810 <builder_add>
 1013723:	test   %eax,%eax
 1013725:	je     10137b2 <myl_rc_module_register+0x192>
 101372b:	inc    %r15
 101372e:	cmp    0x10(%rbx),%r15
 1013732:	jb     1013710 <myl_rc_module_register+0xf0>
 1013734:	mov    0x20(%rbx),%rcx
 1013738:	test   %rcx,%rcx
 101373b:	je     1013797 <myl_rc_module_register+0x177>
 101373d:	mov    $0x8,%r15d
 1013743:	xor    %r12d,%r12d
 1013746:	lea    -0x50(%rbp),%r14
 101374a:	nopw   0x0(%rax,%rax,1)
 1013750:	mov    0x18(%rbx),%rcx
 1013754:	mov    -0x8(%rcx,%r15,1),%rax
 1013759:	test   %rax,%rax
 101375c:	je     10137fb <myl_rc_module_register+0x1db>
 1013762:	mov    (%rcx,%r15,1),%rsi
 1013766:	test   %rsi,%rsi
 1013769:	je     10137fb <myl_rc_module_register+0x1db>
 101376f:	mov    (%rax),%rax
 1013772:	cmp    (%rsi),%rax
 1013775:	jne    10137fb <myl_rc_module_register+0x1db>
 101377b:	mov    %r14,%rdi
 101377e:	vzeroupper
 1013781:	call   1013810 <builder_add>
 1013786:	test   %eax,%eax
 1013788:	je     10137b2 <myl_rc_module_register+0x192>
 101378a:	inc    %r12
 101378d:	add    $0x40,%r15
 1013791:	cmp    0x20(%rbx),%r12
 1013795:	jb     1013750 <myl_rc_module_register+0x130>
 1013797:	lea    -0x50(%rbp),%rdi
 101379b:	mov    %rbx,%rsi
 101379e:	xor    %edx,%edx
 10137a0:	mov    $0x1,%ecx
 10137a5:	vzeroupper
 10137a8:	call   1013ac0 <register_shapes>
 10137ad:	mov    %eax,%r14d
 10137b0:	jmp    10137b8 <myl_rc_module_register+0x198>
 10137b2:	mov    $0x1,%r14d
 10137b8:	mov    -0x50(%rbp),%rbx
 10137bc:	mov    -0x48(%rbp),%rsi
 10137c0:	mov    -0x30(%rbp),%r15
 10137c4:	lea    0x0(,%r15,8),%rax
 10137cc:	lea    (%rax,%rax,4),%rdx
 10137d0:	mov    %rbx,%rdi
 10137d3:	call   1012710 <myl_rc_meta_free>
 10137d8:	mov    -0x40(%rbp),%rsi
 10137dc:	shl    $0x4,%r15
 10137e0:	mov    %rbx,%rdi
 10137e3:	mov    %r15,%rdx
 10137e6:	call   1012710 <myl_rc_meta_free>
 10137eb:	mov    %r14d,%eax
 10137ee:	add    $0x30,%rsp
 10137f2:	pop    %rbx
 10137f3:	pop    %r12
 10137f5:	pop    %r14
 10137f7:	pop    %r15
 10137f9:	pop    %rbp
 10137fa:	ret
 10137fb:	vzeroupper
 10137fe:	call   101267d <myl_rc_invariant_failed>
 1013803:	int3
 1013804:	int3
 1013805:	int3
 1013806:	int3
 1013807:	int3
 1013808:	int3
 1013809:	int3
 101380a:	int3
 101380b:	int3
 101380c:	int3
 101380d:	int3
 101380e:	int3
 101380f:	int3

0000000001013810 <builder_add>:
 1013810:	push   %rbp
 1013811:	mov    %rsp,%rbp
 1013814:	push   %r15
 1013816:	push   %r14
 1013818:	push   %r13
 101381a:	push   %r12
 101381c:	push   %rbx
 101381d:	sub    $0x18,%rsp
 1013821:	test   %rsi,%rsi
 1013824:	je     1013ab0 <builder_add+0x2a0>
 101382a:	movabs $0xbf58476d1ce4e5b9,%r13
 1013834:	mov    0x20(%rdi),%rcx
 1013838:	test   %rcx,%rcx
 101383b:	je     101389e <builder_add+0x8e>
 101383d:	mov    0x10(%rdi),%rax
 1013841:	mov    %rsi,%rdx
 1013844:	shr    $0x3,%rdx
 1013848:	mov    %rsi,%r8
 101384b:	shr    $0x21,%r8
 101384f:	xor    %rdx,%r8
 1013852:	imul   %r13,%r8
 1013856:	mov    %r8,%rdx
 1013859:	shr    $0x1b,%rdx
 101385d:	xor    %r8,%rdx
 1013860:	lea    -0x1(,%rcx,2),%r8
 1013868:	and    %r8,%rdx
 101386b:	mov    (%rax,%rdx,8),%r10
 101386f:	test   %r10,%r10
 1013872:	je     101389e <builder_add+0x8e>
 1013874:	mov    0x8(%rdi),%r9
 1013878:	nopl   0x0(%rax,%rax,1)
 1013880:	lea    (%r10,%r10,4),%r10
 1013884:	cmp    %rsi,-0x28(%r9,%r10,8)
 1013889:	je     1013a6d <builder_add+0x25d>
 101388f:	inc    %rdx
 1013892:	and    %r8,%rdx
 1013895:	mov    (%rax,%rdx,8),%r10
 1013899:	test   %r10,%r10
 101389c:	jne    1013880 <builder_add+0x70>
 101389e:	mov    0x18(%rdi),%rax
 10138a2:	cmp    %rcx,%rax
 10138a5:	jne    10139fc <builder_add+0x1ec>
 10138ab:	lea    (%rcx,%rcx,1),%rax
 10138af:	test   %rcx,%rcx
 10138b2:	mov    $0x10,%r15d
 10138b8:	cmovne %rax,%r15
 10138bc:	xor    %eax,%eax
 10138be:	cmp    %rcx,%r15
 10138c1:	jb     1013a72 <builder_add+0x262>
 10138c7:	mov    $0x28,%ecx
 10138cc:	mov    %r15,%rax
 10138cf:	mul    %rcx
 10138d2:	jo     1013a81 <builder_add+0x271>
 10138d8:	mov    %rsi,-0x30(%rbp)
 10138dc:	mov    %rdi,%r12
 10138df:	mov    (%rdi),%rdi
 10138e2:	mov    %rax,-0x38(%rbp)
 10138e6:	mov    %rax,%rsi
 10138e9:	call   1012690 <myl_rc_meta_alloc>
 10138ee:	test   %rax,%rax
 10138f1:	je     1013a81 <builder_add+0x271>
 10138f7:	mov    %rax,%r14
 10138fa:	mov    %r15,%rsi
 10138fd:	shl    $0x4,%rsi
 1013901:	mov    (%r12),%rdi
 1013905:	call   1012690 <myl_rc_meta_alloc>
 101390a:	test   %rax,%rax
 101390d:	je     1013a8e <builder_add+0x27e>
 1013913:	mov    %rax,%rbx
 1013916:	mov    %r12,%rax
 1013919:	mov    0x18(%r12),%rcx
 101391e:	test   %rcx,%rcx
 1013921:	je     101393a <builder_add+0x12a>
 1013923:	mov    0x8(%rax),%rsi
 1013927:	shl    $0x3,%rcx
 101392b:	lea    (%rcx,%rcx,4),%rdx
 101392f:	mov    %r14,%rdi
 1013932:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1013937:	mov    %r12,%rax
 101393a:	mov    (%rax),%rdi
 101393d:	mov    0x8(%rax),%rsi
 1013941:	mov    0x20(%rax),%rax
 1013945:	shl    $0x3,%rax
 1013949:	lea    (%rax,%rax,4),%rdx
 101394d:	call   1012710 <myl_rc_meta_free>
 1013952:	mov    (%r12),%rdi
 1013956:	mov    0x10(%r12),%rsi
 101395b:	mov    0x20(%r12),%rdx
 1013960:	shl    $0x4,%rdx
 1013964:	call   1012710 <myl_rc_meta_free>
 1013969:	mov    %r12,%rdi
 101396c:	mov    %r14,0x8(%r12)
 1013971:	mov    %rbx,0x10(%r12)
 1013976:	mov    %r15,0x20(%r12)
 101397b:	cmpq   $0x0,0x18(%r12)
 1013981:	je     1013aa2 <builder_add+0x292>
 1013987:	xor    %ecx,%ecx
 1013989:	mov    -0x30(%rbp),%rsi
 101398d:	jmp    10139a4 <builder_add+0x194>
 101398f:	nop
 1013990:	inc    %rcx
 1013993:	mov    %rcx,(%rbx,%rax,8)
 1013997:	mov    0x18(%rdi),%rax
 101399b:	cmp    %rax,%rcx
 101399e:	jae    1013a85 <builder_add+0x275>
 10139a4:	lea    (%rcx,%rcx,4),%rax
 10139a8:	mov    (%r14,%rax,8),%rdx
 10139ac:	mov    %rdx,%rax
 10139af:	shr    $0x3,%rax
 10139b3:	mov    %rdx,%r8
 10139b6:	shr    $0x21,%r8
 10139ba:	xor    %rax,%r8
 10139bd:	imul   %r13,%r8
 10139c1:	mov    %r8,%rax
 10139c4:	shr    $0x1b,%rax
 10139c8:	xor    %r8,%rax
 10139cb:	mov    0x20(%rdi),%r8
 10139cf:	lea    -0x1(,%r8,2),%r8
 10139d7:	nopw   0x0(%rax,%rax,1)
 10139e0:	and    %r8,%rax
 10139e3:	mov    (%rbx,%rax,8),%r9
 10139e7:	test   %r9,%r9
 10139ea:	je     1013990 <builder_add+0x180>
 10139ec:	lea    (%r9,%r9,4),%r9
 10139f0:	cmp    %rdx,-0x28(%r14,%r9,8)
 10139f5:	je     1013990 <builder_add+0x180>
 10139f7:	inc    %rax
 10139fa:	jmp    10139e0 <builder_add+0x1d0>
 10139fc:	mov    0x10(%rdi),%rbx
 1013a00:	mov    %rsi,%rdx
 1013a03:	shr    $0x3,%rdx
 1013a07:	mov    %rsi,%r8
 1013a0a:	shr    $0x21,%r8
 1013a0e:	xor    %rdx,%r8
 1013a11:	imul   %r13,%r8
 1013a15:	mov    %r8,%rdx
 1013a18:	shr    $0x1b,%rdx
 1013a1c:	xor    %r8,%rdx
 1013a1f:	lea    -0x1(,%rcx,2),%r8
 1013a27:	and    %r8,%rdx
 1013a2a:	mov    (%rbx,%rdx,8),%r9
 1013a2e:	mov    0x8(%rdi),%rcx
 1013a32:	test   %r9,%r9
 1013a35:	je     1013a5a <builder_add+0x24a>
 1013a37:	nopw   0x0(%rax,%rax,1)
 1013a40:	lea    (%r9,%r9,4),%r9
 1013a44:	cmp    %rsi,-0x28(%rcx,%r9,8)
 1013a49:	je     1013a5a <builder_add+0x24a>
 1013a4b:	inc    %rdx
 1013a4e:	and    %r8,%rdx
 1013a51:	mov    (%rbx,%rdx,8),%r9
 1013a55:	test   %r9,%r9
 1013a58:	jne    1013a40 <builder_add+0x230>
 1013a5a:	lea    (%rax,%rax,4),%r8
 1013a5e:	mov    %rsi,(%rcx,%r8,8)
 1013a62:	inc    %rax
 1013a65:	mov    %rax,0x18(%rdi)
 1013a69:	mov    %rax,(%rbx,%rdx,8)
 1013a6d:	mov    $0x1,%eax
 1013a72:	add    $0x18,%rsp
 1013a76:	pop    %rbx
 1013a77:	pop    %r12
 1013a79:	pop    %r13
 1013a7b:	pop    %r14
 1013a7d:	pop    %r15
 1013a7f:	pop    %rbp
 1013a80:	ret
 1013a81:	xor    %eax,%eax
 1013a83:	jmp    1013a72 <builder_add+0x262>
 1013a85:	mov    0x20(%rdi),%rcx
 1013a89:	jmp    1013a00 <builder_add+0x1f0>
 1013a8e:	mov    (%r12),%rdi
 1013a92:	mov    %r14,%rsi
 1013a95:	mov    -0x38(%rbp),%rdx
 1013a99:	call   1012710 <myl_rc_meta_free>
 1013a9e:	xor    %eax,%eax
 1013aa0:	jmp    1013a72 <builder_add+0x262>
 1013aa2:	xor    %eax,%eax
 1013aa4:	mov    %r15,%rcx
 1013aa7:	mov    -0x30(%rbp),%rsi
 1013aab:	jmp    1013a00 <builder_add+0x1f0>
 1013ab0:	call   101267d <myl_rc_invariant_failed>
 1013ab5:	int3
 1013ab6:	int3
 1013ab7:	int3
 1013ab8:	int3
 1013ab9:	int3
 1013aba:	int3
 1013abb:	int3
 1013abc:	int3
 1013abd:	int3
 1013abe:	int3
 1013abf:	int3

0000000001013ac0 <register_shapes>:
 1013ac0:	push   %rbp
 1013ac1:	mov    %rsp,%rbp
 1013ac4:	push   %r15
 1013ac6:	push   %r14
 1013ac8:	push   %r13
 1013aca:	push   %r12
 1013acc:	push   %rbx
 1013acd:	sub    $0x88,%rsp
 1013ad4:	mov    %ecx,-0x3c(%rbp)
 1013ad7:	mov    %rsi,-0x58(%rbp)
 1013adb:	mov    (%rdi),%rax
 1013ade:	mov    %rax,-0x48(%rbp)
 1013ae2:	mov    0x18(%rdi),%r15
 1013ae6:	test   %r15,%r15
 1013ae9:	mov    %rdi,-0x30(%rbp)
 1013aed:	mov    %rdx,-0x68(%rbp)
 1013af1:	je     1013afe <register_shapes+0x3e>
 1013af3:	xor    %ebx,%ebx
 1013af5:	lea    -0x10a94(%rip),%r8        # 1003068 <dict_scan+0x18>
 1013afc:	jmp    1013b4c <register_shapes+0x8c>
 1013afe:	xor    %esi,%esi
 1013b00:	xor    %edx,%edx
 1013b02:	movq   $0x0,-0x38(%rbp)
 1013b0a:	mov    (%rdi),%rdi
 1013b0d:	call   1012710 <myl_rc_meta_free>
 1013b12:	mov    -0x58(%rbp),%rax
 1013b16:	test   %rax,%rax
 1013b19:	je     1013cd3 <register_shapes+0x213>
 1013b1f:	mov    0x20(%rax),%r13
 1013b23:	jmp    1013cd6 <register_shapes+0x216>
 1013b28:	mov    0x18(%rdi),%r15
 1013b2c:	lea    -0x10acb(%rip),%r8        # 1003068 <dict_scan+0x18>
 1013b33:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013b40:	inc    %rbx
 1013b43:	cmp    %r15,%rbx
 1013b46:	jae    1013fb3 <register_shapes+0x4f3>
 1013b4c:	mov    0x8(%rdi),%rax
 1013b50:	lea    (%rbx,%rbx,4),%rcx
 1013b54:	mov    (%rax,%rcx,8),%r12
 1013b58:	mov    0x8(%r12),%ecx
 1013b5d:	cmp    $0x5,%rcx
 1013b61:	ja     10144f5 <register_shapes+0xa35>
 1013b67:	movslq (%r8,%rcx,4),%rax
 1013b6b:	add    %r8,%rax
 1013b6e:	jmp    *%rax
 1013b70:	cmpq   $0x8,(%r12)
 1013b75:	jne    10144f5 <register_shapes+0xa35>
 1013b7b:	cmp    $0x2,%ecx
 1013b7e:	je     1013b85 <register_shapes+0xc5>
 1013b80:	cmp    $0x4,%ecx
 1013b83:	jne    1013b40 <register_shapes+0x80>
 1013b85:	mov    0x10(%r12),%rax
 1013b8a:	xor    %r14d,%r14d
 1013b8d:	jmp    1013bb4 <register_shapes+0xf4>
 1013b8f:	nop
 1013b90:	mov    0x10(%r12),%rax
 1013b95:	mov    0x18(%r12),%r14
 1013b9a:	test   %r14,%r14
 1013b9d:	setne  %dl
 1013ba0:	test   %rax,%rax
 1013ba3:	sete   %sil
 1013ba7:	and    %dl,%sil
 1013baa:	cmp    $0x1,%sil
 1013bae:	je     10144f5 <register_shapes+0xa35>
 1013bb4:	cmp    $0x4,%ecx
 1013bb7:	jne    1013bd2 <register_shapes+0x112>
 1013bb9:	mov    0x20(%r12),%rcx
 1013bbe:	add    $0x4,%rcx
 1013bc2:	jb     10144da <register_shapes+0xa1a>
 1013bc8:	cmp    (%r12),%rcx
 1013bcc:	ja     10144f5 <register_shapes+0xa35>
 1013bd2:	mov    $0x1,%r9d
 1013bd8:	add    %r14,0x28(%rdi)
 1013bdc:	jb     10144e0 <register_shapes+0xa20>
 1013be2:	test   %r14,%r14
 1013be5:	je     1013b40 <register_shapes+0x80>
 1013beb:	add    $0x8,%rax
 1013bef:	mov    %r14,%rcx
 1013bf2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013c00:	mov    (%rax),%rdx
 1013c03:	test   %rdx,%rdx
 1013c06:	je     10144f5 <register_shapes+0xa35>
 1013c0c:	mov    -0x8(%rax),%rsi
 1013c10:	add    (%rdx),%rsi
 1013c13:	jb     10144e0 <register_shapes+0xa20>
 1013c19:	cmp    (%r12),%rsi
 1013c1d:	ja     10144f5 <register_shapes+0xa35>
 1013c23:	add    $0x18,%rax
 1013c27:	dec    %rcx
 1013c2a:	jne    1013c00 <register_shapes+0x140>
 1013c2c:	jmp    1013c86 <register_shapes+0x1c6>
 1013c2e:	mov    0x18(%r12),%rax
 1013c33:	test   %rax,%rax
 1013c36:	je     1013b40 <register_shapes+0x80>
 1013c3c:	mov    0x10(%r12),%rcx
 1013c41:	test   %rcx,%rcx
 1013c44:	je     10144f5 <register_shapes+0xa35>
 1013c4a:	mov    0x20(%r12),%rdx
 1013c4f:	mov    (%rcx),%rcx
 1013c52:	cmp    %rcx,%rdx
 1013c55:	jb     10144f5 <register_shapes+0xa35>
 1013c5b:	dec    %rax
 1013c5e:	mul    %rdx
 1013c61:	mov    $0x1,%r9d
 1013c67:	jo     10144e0 <register_shapes+0xa20>
 1013c6d:	add    %rcx,%rax
 1013c70:	jb     10144e0 <register_shapes+0xa20>
 1013c76:	mov    $0x1,%r14d
 1013c7c:	cmp    (%r12),%rax
 1013c80:	ja     10144f5 <register_shapes+0xa35>
 1013c86:	lea    0x10(%r12),%r15
 1013c8b:	mov    $0x8,%r13d
 1013c91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1013ca0:	cmpl   $0x3,0x8(%r12)
 1013ca6:	mov    %r15,%rax
 1013ca9:	je     1013cb1 <register_shapes+0x1f1>
 1013cab:	mov    (%r15),%rax
 1013cae:	add    %r13,%rax
 1013cb1:	mov    (%rax),%rsi
 1013cb4:	call   1013810 <builder_add>
 1013cb9:	test   %eax,%eax
 1013cbb:	je     10144da <register_shapes+0xa1a>
 1013cc1:	add    $0x18,%r13
 1013cc5:	dec    %r14
 1013cc8:	mov    -0x30(%rbp),%rdi
 1013ccc:	jne    1013ca0 <register_shapes+0x1e0>
 1013cce:	jmp    1013b28 <register_shapes+0x68>
 1013cd3:	xor    %r13d,%r13d
 1013cd6:	mov    -0x30(%rbp),%r8
 1013cda:	mov    0x18(%r8),%r14
 1013cde:	mov    %r14,%rax
 1013ce1:	shr    $0x3a,%rax
 1013ce5:	mov    $0x1,%r9d
 1013ceb:	jne    10144e0 <register_shapes+0xa20>
 1013cf1:	mov    $0x18,%eax
 1013cf6:	mulq   0x28(%r8)
 1013cfa:	jo     10144e0 <register_shapes+0xa20>
 1013d00:	mov    %rax,%r12
 1013d03:	mov    $0xc8,%ecx
 1013d08:	mov    %r13,%rax
 1013d0b:	mul    %rcx
 1013d0e:	jo     10144e0 <register_shapes+0xa20>
 1013d14:	shl    $0x6,%r14
 1013d18:	mov    %r14,%r15
 1013d1b:	add    $0x40,%r15
 1013d1f:	jb     10144e0 <register_shapes+0xa20>
 1013d25:	add    %r12,%r15
 1013d28:	jb     10144e0 <register_shapes+0xa20>
 1013d2e:	add    %rax,%r15
 1013d31:	jb     10144e0 <register_shapes+0xa20>
 1013d37:	mov    (%r8),%rdi
 1013d3a:	mov    %r15,%rsi
 1013d3d:	mov    %r8,%rbx
 1013d40:	call   1012690 <myl_rc_meta_alloc>
 1013d45:	test   %rax,%rax
 1013d48:	je     10144da <register_shapes+0xa1a>
 1013d4e:	xor    %ecx,%ecx
 1013d50:	mov    %r13,%rsi
 1013d53:	mov    -0x3c(%rbp),%r13d
 1013d57:	test   %r13d,%r13d
 1013d5a:	cmovne -0x58(%rbp),%rcx
 1013d5f:	mov    %rcx,0x8(%rax)
 1013d63:	mov    0x18(%rbx),%rdx
 1013d67:	mov    %rdx,0x20(%rax)
 1013d6b:	mov    %rsi,-0x60(%rbp)
 1013d6f:	mov    %rsi,0x28(%rax)
 1013d73:	mov    %r15,0x30(%rax)
 1013d77:	lea    0x40(%rax),%rcx
 1013d7b:	mov    %rcx,0x10(%rax)
 1013d7f:	lea    (%rax,%r14,1),%rcx
 1013d83:	add    $0x40,%rcx
 1013d87:	add    %rcx,%r12
 1013d8a:	mov    %r12,0x18(%rax)
 1013d8e:	test   %rdx,%rdx
 1013d91:	mov    %rbx,%r9
 1013d94:	mov    %rax,%rbx
 1013d97:	je     10142a3 <register_shapes+0x7e3>
 1013d9d:	xor    %edx,%edx
 1013d9f:	jmp    1013dc6 <register_shapes+0x306>
 1013da1:	mov    -0x50(%rbp),%rax
 1013da5:	mov    %rcx,0x18(%rax)
 1013da9:	lea    (%r8,%r8,2),%rax
 1013dad:	lea    (%rcx,%rax,8),%rcx
 1013db1:	mov    -0x3c(%rbp),%r13d
 1013db5:	inc    %rdx
 1013db8:	mov    -0x30(%rbp),%r9
 1013dbc:	cmp    0x18(%r9),%rdx
 1013dc0:	jae    10142a3 <register_shapes+0x7e3>
 1013dc6:	lea    0x0(,%rdx,8),%rsi
 1013dce:	mov    %r9,%r11
 1013dd1:	mov    0x10(%rbx),%r9
 1013dd5:	mov    %rdx,%r10
 1013dd8:	shl    $0x6,%r10
 1013ddc:	lea    (%r9,%r10,1),%r12
 1013de0:	test   %r13d,%r13d
 1013de3:	mov    0x8(%r11),%rdi
 1013de7:	lea    (%rsi,%rsi,4),%rsi
 1013deb:	mov    (%rdi,%rsi,1),%rdi
 1013def:	mov    $0x0,%r8d
 1013df5:	cmovne %rdi,%r8
 1013df9:	mov    %r8,(%r9,%r10,1)
 1013dfd:	vmovups (%rdi),%ymm0
 1013e01:	vmovups %ymm0,0x8(%r9,%r10,1)
 1013e08:	mov    0x20(%rdi),%r8
 1013e0c:	mov    %r8,0x28(%r9,%r10,1)
 1013e11:	mov    0x8(%r11),%r8
 1013e15:	vmovups 0x10(%r8,%rsi,1),%xmm0
 1013e1c:	cmpq   $0x0,0x10(%r8,%rsi,1)
 1013e22:	vmovups %xmm0,0x30(%r9,%r10,1)
 1013e29:	jne    1013e34 <register_shapes+0x374>
 1013e2b:	movl   $0x0,0x10(%r12)
 1013e34:	mov    0x8(%rdi),%esi
 1013e37:	cmp    $0x3,%esi
 1013e3a:	jne    1013ec6 <register_shapes+0x406>
 1013e40:	cmpq   $0x0,0x18(%rdi)
 1013e45:	je     1013db5 <register_shapes+0x2f5>
 1013e4b:	mov    0x10(%rdi),%r9
 1013e4f:	mov    -0x30(%rbp),%rsi
 1013e53:	mov    0x10(%rsi),%r10
 1013e57:	mov    0x20(%rsi),%rsi
 1013e5b:	mov    %r9,%r11
 1013e5e:	shr    $0x3,%r11
 1013e62:	mov    %r9,%r14
 1013e65:	shr    $0x21,%r14
 1013e69:	xor    %r11,%r14
 1013e6c:	movabs $0xbf58476d1ce4e5b9,%rax
 1013e76:	imul   %rax,%r14
 1013e7a:	mov    %r14,%r11
 1013e7d:	shr    $0x1b,%r11
 1013e81:	xor    %r14,%r11
 1013e84:	lea    -0x1(,%rsi,2),%r14
 1013e8c:	nopl   0x0(%rax)
 1013e90:	and    %r14,%r11
 1013e93:	mov    (%r10,%r11,8),%r15
 1013e97:	test   %r15,%r15
 1013e9a:	je     1013eac <register_shapes+0x3ec>
 1013e9c:	lea    (%r15,%r15,4),%rsi
 1013ea0:	cmp    %r9,-0x28(%r8,%rsi,8)
 1013ea5:	je     1013eaf <register_shapes+0x3ef>
 1013ea7:	inc    %r11
 1013eaa:	jmp    1013e90 <register_shapes+0x3d0>
 1013eac:	xor    %r15d,%r15d
 1013eaf:	mov    0x10(%rbx),%rsi
 1013eb3:	shl    $0x6,%r15
 1013eb7:	add    %r15,%rsi
 1013eba:	add    $0xffffffffffffffc8,%rsi
 1013ebe:	mov    %rsi,0x18(%r12)
 1013ec3:	mov    0x8(%rdi),%esi
 1013ec6:	cmp    $0x4,%esi
 1013ec9:	je     1013ed4 <register_shapes+0x414>
 1013ecb:	cmp    $0x2,%esi
 1013ece:	jne    1013db5 <register_shapes+0x2f5>
 1013ed4:	mov    %r12,-0x50(%rbp)
 1013ed8:	mov    0x18(%rdi),%r8
 1013edc:	test   %r8,%r8
 1013edf:	je     1013da1 <register_shapes+0x2e1>
 1013ee5:	mov    0x10(%rdi),%rdi
 1013ee9:	xor    %r9d,%r9d
 1013eec:	jmp    1013f15 <register_shapes+0x455>
 1013eee:	xchg   %ax,%ax
 1013ef0:	xor    %r12d,%r12d
 1013ef3:	add    %rcx,%r10
 1013ef6:	mov    0x10(%rbx),%rax
 1013efa:	shl    $0x6,%r12
 1013efe:	add    %r12,%rax
 1013f01:	add    $0xffffffffffffffc8,%rax
 1013f05:	mov    %rax,0x8(%r10)
 1013f09:	inc    %r9
 1013f0c:	cmp    %r8,%r9
 1013f0f:	je     1013da1 <register_shapes+0x2e1>
 1013f15:	lea    0x0(,%r9,8),%rsi
 1013f1d:	lea    (%rsi,%rsi,2),%r10
 1013f21:	mov    0x10(%rdi,%r10,1),%rsi
 1013f26:	mov    %rsi,0x10(%rcx,%r10,1)
 1013f2b:	vmovups (%rdi,%r10,1),%xmm0
 1013f31:	vmovups %xmm0,(%rcx,%r10,1)
 1013f37:	mov    0x8(%rdi,%r10,1),%r11
 1013f3c:	mov    -0x30(%rbp),%rax
 1013f40:	mov    0x10(%rax),%r14
 1013f44:	mov    0x20(%rax),%rsi
 1013f48:	mov    %r11,%r15
 1013f4b:	shr    $0x3,%r15
 1013f4f:	mov    %r11,%r12
 1013f52:	shr    $0x21,%r12
 1013f56:	xor    %r15,%r12
 1013f59:	movabs $0xbf58476d1ce4e5b9,%r15
 1013f63:	imul   %r15,%r12
 1013f67:	mov    %r12,%r15
 1013f6a:	shr    $0x1b,%r15
 1013f6e:	xor    %r12,%r15
 1013f71:	lea    -0x1(,%rsi,2),%r13
 1013f79:	and    %r13,%r15
 1013f7c:	mov    (%r14,%r15,8),%r12
 1013f80:	test   %r12,%r12
 1013f83:	je     1013ef0 <register_shapes+0x430>
 1013f89:	mov    0x8(%rax),%rsi
 1013f8d:	nopl   (%rax)
 1013f90:	lea    (%r12,%r12,4),%rax
 1013f94:	cmp    %r11,-0x28(%rsi,%rax,8)
 1013f99:	je     1013ef3 <register_shapes+0x433>
 1013f9f:	inc    %r15
 1013fa2:	and    %r13,%r15
 1013fa5:	mov    (%r14,%r15,8),%r12
 1013fa9:	test   %r12,%r12
 1013fac:	jne    1013f90 <register_shapes+0x4d0>
 1013fae:	jmp    1013ef0 <register_shapes+0x430>
 1013fb3:	mov    %r15,%rax
 1013fb6:	shr    $0x3d,%rax
 1013fba:	mov    $0x1,%r9d
 1013fc0:	jne    10144e0 <register_shapes+0xa20>
 1013fc6:	test   %r15,%r15
 1013fc9:	je     1013ff9 <register_shapes+0x539>
 1013fcb:	shl    $0x3,%r15
 1013fcf:	mov    (%rdi),%rdi
 1013fd2:	mov    %r15,%rsi
 1013fd5:	call   1012690 <myl_rc_meta_alloc>
 1013fda:	mov    $0x1,%r9d
 1013fe0:	mov    -0x30(%rbp),%rdi
 1013fe4:	test   %rax,%rax
 1013fe7:	je     10144e0 <register_shapes+0xa20>
 1013fed:	mov    %rax,%rsi
 1013ff0:	mov    %r15,%rdx
 1013ff3:	mov    0x18(%rdi),%r15
 1013ff7:	jmp    1013ffd <register_shapes+0x53d>
 1013ff9:	xor    %edx,%edx
 1013ffb:	xor    %esi,%esi
 1013ffd:	test   %r15,%r15
 1014000:	je     1013b02 <register_shapes+0x42>
 1014006:	mov    %rdx,-0x50(%rbp)
 101400a:	mov    0x8(%rdi),%rcx
 101400e:	xor    %r9d,%r9d
 1014011:	lea    -0x10f98(%rip),%rbx        # 1003080 <dict_scan+0x30>
 1014018:	xor    %edx,%edx
 101401a:	jmp    1014030 <register_shapes+0x570>
 101401c:	mov    0x18(%rdi),%r15
 1014020:	mov    -0x38(%rbp),%rdx
 1014024:	inc    %rdx
 1014027:	cmp    %r15,%rdx
 101402a:	jae    1014296 <register_shapes+0x7d6>
 1014030:	lea    (%rdx,%rdx,4),%rax
 1014034:	cmpl   $0x2,0x20(%rcx,%rax,8)
 1014039:	je     1014024 <register_shapes+0x564>
 101403b:	mov    %rdx,-0x38(%rbp)
 101403f:	mov    %rdx,(%rsi)
 1014042:	mov    $0x1,%r10d
 1014048:	jmp    1014067 <register_shapes+0x5a7>
 101404a:	nopw   0x0(%rax,%rax,1)
 1014050:	cmp    %r9,%r14
 1014053:	cmova  %r14,%r9
 1014057:	movl   $0x2,0x20(%r11)
 101405f:	dec    %r10
 1014062:	test   %r10,%r10
 1014065:	je     101401c <register_shapes+0x55c>
 1014067:	mov    -0x8(%rsi,%r10,8),%rax
 101406c:	lea    (%rax,%rax,4),%rdx
 1014070:	movl   $0x1,0x20(%rcx,%rdx,8)
 1014078:	mov    (%rcx,%rdx,8),%r15
 101407c:	mov    0x8(%r15),%eax
 1014080:	cmp    $0x5,%rax
 1014084:	ja     10144f5 <register_shapes+0xa35>
 101408a:	lea    (%rcx,%rdx,8),%r11
 101408e:	mov    0x8(%rcx,%rdx,8),%r14
 1014093:	movslq (%rbx,%rax,4),%rdx
 1014097:	add    %rbx,%rdx
 101409a:	jmp    *%rdx
 101409c:	movq   $0x1,0x10(%r11)
 10140a4:	jmp    1014190 <register_shapes+0x6d0>
 10140a9:	nopl   0x0(%rax)
 10140b0:	cmp    0x18(%r15),%r14
 10140b4:	jae    1014180 <register_shapes+0x6c0>
 10140ba:	add    $0x10,%r15
 10140be:	mov    %r9,%rbx
 10140c1:	cmp    $0x3,%eax
 10140c4:	je     10140f2 <register_shapes+0x632>
 10140c6:	mov    (%r15),%rax
 10140c9:	lea    (%r14,%r14,2),%rdx
 10140cd:	lea    (%rax,%rdx,8),%r15
 10140d1:	add    $0x8,%r15
 10140d5:	jmp    10140f2 <register_shapes+0x632>
 10140d7:	test   %r14,%r14
 10140da:	jne    1014180 <register_shapes+0x6c0>
 10140e0:	cmpq   $0x0,0x18(%r15)
 10140e5:	je     1014180 <register_shapes+0x6c0>
 10140eb:	mov    %r9,%rbx
 10140ee:	add    $0x10,%r15
 10140f2:	mov    (%r15),%r15
 10140f5:	mov    0x10(%rdi),%r12
 10140f9:	mov    0x20(%rdi),%rax
 10140fd:	mov    %r15,%rdx
 1014100:	shr    $0x3,%rdx
 1014104:	mov    %r15,%r8
 1014107:	shr    $0x21,%r8
 101410b:	xor    %rdx,%r8
 101410e:	movabs $0xbf58476d1ce4e5b9,%rdx
 1014118:	imul   %rdx,%r8
 101411c:	mov    %r8,%r13
 101411f:	shr    $0x1b,%r13
 1014123:	xor    %r8,%r13
 1014126:	lea    -0x1(,%rax,2),%r8
 101412e:	and    %r8,%r13
 1014131:	mov    (%r12,%r13,8),%rax
 1014135:	mov    $0xffffffffffffffff,%rdx
 101413c:	test   %rax,%rax
 101413f:	je     1014235 <register_shapes+0x775>
 1014145:	data16 cs nopw 0x0(%rax,%rax,1)
 1014150:	lea    (%rax,%rax,4),%r9
 1014154:	cmp    %r15,-0x28(%rcx,%r9,8)
 1014159:	je     101422b <register_shapes+0x76b>
 101415f:	inc    %r13
 1014162:	and    %r8,%r13
 1014165:	mov    (%r12,%r13,8),%rax
 1014169:	test   %rax,%rax
 101416c:	jne    1014150 <register_shapes+0x690>
 101416e:	jmp    1014231 <register_shapes+0x771>
 1014173:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1014180:	mov    0x10(%r11),%rax
 1014184:	test   %rax,%rax
 1014187:	je     1014190 <register_shapes+0x6d0>
 1014189:	inc    %rax
 101418c:	mov    %rax,0x10(%r11)
 1014190:	mov    0x18(%r11),%r14
 1014194:	inc    %r14
 1014197:	mov    %r14,0x18(%r11)
 101419b:	mov    (%rdi),%rax
 101419e:	mov    0x1608(%rax),%rdx
 10141a5:	mov    0x58(%rdx),%r12
 10141a9:	mov    0x60(%rdx),%rax
 10141ad:	movzbl 0x70(%rdx),%edx
 10141b1:	mov    %r15,%r8
 10141b4:	movabs $0x9e3779b97f4a7c15,%r13
 10141be:	imul   %r13,%r8
 10141c2:	shrx   %rdx,%r8,%r13
 10141c7:	nopw   0x0(%rax,%rax,1)
 10141d0:	and    %rax,%r13
 10141d3:	mov    %r13,%rdx
 10141d6:	shl    $0x4,%rdx
 10141da:	mov    (%r12,%rdx,1),%rdx
 10141de:	cmp    %r15,%rdx
 10141e1:	je     1014200 <register_shapes+0x740>
 10141e3:	test   %rdx,%rdx
 10141e6:	je     1014050 <register_shapes+0x590>
 10141ec:	inc    %r13
 10141ef:	jmp    10141d0 <register_shapes+0x710>
 10141f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1014200:	shl    $0x4,%r13
 1014204:	mov    0x8(%r12,%r13,1),%rax
 1014209:	test   %rax,%rax
 101420c:	je     1014050 <register_shapes+0x590>
 1014212:	mov    0x30(%rax),%rax
 1014216:	cmp    %r14,%rax
 1014219:	jbe    1014050 <register_shapes+0x590>
 101421f:	mov    %rax,0x18(%r11)
 1014223:	mov    %rax,%r14
 1014226:	jmp    1014050 <register_shapes+0x590>
 101422b:	dec    %rax
 101422e:	mov    %rax,%rdx
 1014231:	mov    -0x30(%rbp),%rdi
 1014235:	lea    (%rdx,%rdx,4),%rax
 1014239:	mov    0x20(%rcx,%rax,8),%r8d
 101423e:	test   %r8d,%r8d
 1014241:	mov    %rbx,%r9
 1014244:	je     1014283 <register_shapes+0x7c3>
 1014246:	cmp    $0x1,%r8d
 101424a:	lea    -0x111d1(%rip),%rbx        # 1003080 <dict_scan+0x30>
 1014251:	je     10144f5 <register_shapes+0xa35>
 1014257:	lea    (%rcx,%rax,8),%rax
 101425b:	mov    0x10(%rax),%rdx
 101425f:	cmp    0x10(%r11),%rdx
 1014263:	jbe    1014269 <register_shapes+0x7a9>
 1014265:	mov    %rdx,0x10(%r11)
 1014269:	mov    0x18(%rax),%rax
 101426d:	cmp    0x18(%r11),%rax
 1014271:	jbe    1014277 <register_shapes+0x7b7>
 1014273:	mov    %rax,0x18(%r11)
 1014277:	inc    %r14
 101427a:	mov    %r14,0x8(%r11)
 101427e:	jmp    1014062 <register_shapes+0x5a2>
 1014283:	mov    %rdx,(%rsi,%r10,8)
 1014287:	inc    %r10
 101428a:	lea    -0x11211(%rip),%rbx        # 1003080 <dict_scan+0x30>
 1014291:	jmp    1014062 <register_shapes+0x5a2>
 1014296:	mov    %r9,-0x38(%rbp)
 101429a:	mov    -0x50(%rbp),%rdx
 101429e:	jmp    1013b0a <register_shapes+0x4a>
 10142a3:	mov    -0x60(%rbp),%r13
 10142a7:	test   %r13,%r13
 10142aa:	mov    -0x58(%rbp),%r15
 10142ae:	je     10143a6 <register_shapes+0x8e6>
 10142b4:	mov    0x18(%rbx),%rdi
 10142b8:	mov    0x18(%r15),%rdx
 10142bc:	xor    %ecx,%ecx
 10142be:	jmp    10142ee <register_shapes+0x82e>
 10142c0:	xor    %r10d,%r10d
 10142c3:	mov    %r12,%rbx
 10142c6:	shl    $0x6,%r10
 10142ca:	mov    0x10(%rbx),%rax
 10142ce:	mov    0x18(%rbx),%rdi
 10142d2:	add    %r10,%rax
 10142d5:	add    $0xffffffffffffffc8,%rax
 10142d9:	mov    %rax,0x8(%rdi,%rsi,1)
 10142de:	inc    %rcx
 10142e1:	cmp    %r13,%rcx
 10142e4:	mov    -0x30(%rbp),%r9
 10142e8:	je     10143a6 <register_shapes+0x8e6>
 10142ee:	mov    %rbx,%r12
 10142f1:	imul   $0xc8,%rcx,%rsi
 10142f8:	mov    %rcx,%rax
 10142fb:	shl    $0x6,%rax
 10142ff:	vmovups (%rdx,%rax,1),%ymm0
 1014304:	vmovups 0x20(%rdx,%rax,1),%ymm1
 101430a:	vmovups %ymm1,0x20(%rdi,%rsi,1)
 1014310:	vmovups %ymm0,(%rdi,%rsi,1)
 1014315:	mov    0x18(%r15),%rdx
 1014319:	mov    0x8(%rdx,%rax,1),%rdi
 101431e:	mov    0x10(%r9),%r8
 1014322:	mov    0x20(%r9),%rax
 1014326:	mov    %r9,%rbx
 1014329:	mov    %rdi,%r9
 101432c:	shr    $0x3,%r9
 1014330:	mov    %rdi,%r10
 1014333:	shr    $0x21,%r10
 1014337:	xor    %r9,%r10
 101433a:	movabs $0xbf58476d1ce4e5b9,%r9
 1014344:	imul   %r9,%r10
 1014348:	mov    %r10,%r9
 101434b:	shr    $0x1b,%r9
 101434f:	xor    %r10,%r9
 1014352:	lea    -0x1(,%rax,2),%r11
 101435a:	and    %r11,%r9
 101435d:	mov    (%r8,%r9,8),%r10
 1014361:	test   %r10,%r10
 1014364:	je     10142c0 <register_shapes+0x800>
 101436a:	mov    0x8(%rbx),%r14
 101436e:	mov    %r12,%rbx
 1014371:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1014380:	lea    (%r10,%r10,4),%rax
 1014384:	cmp    %rdi,-0x28(%r14,%rax,8)
 1014389:	je     10142c6 <register_shapes+0x806>
 101438f:	inc    %r9
 1014392:	and    %r11,%r9
 1014395:	mov    (%r8,%r9,8),%r10
 1014399:	test   %r10,%r10
 101439c:	jne    1014380 <register_shapes+0x8c0>
 101439e:	xor    %r10d,%r10d
 10143a1:	jmp    10142c6 <register_shapes+0x806>
 10143a6:	mov    -0x48(%rbp),%rdi
 10143aa:	mov    0x1608(%rdi),%rax
 10143b1:	mov    -0x38(%rbp),%rsi
 10143b5:	cmp    0xb8(%rax),%rsi
 10143bc:	jbe    10143f6 <register_shapes+0x936>
 10143be:	mov    $0x18,%ecx
 10143c3:	mov    %rsi,%rax
 10143c6:	mul    %rcx
 10143c9:	mov    -0x48(%rbp),%rdi
 10143cd:	jo     10143ea <register_shapes+0x92a>
 10143cf:	mov    %rax,%rsi
 10143d2:	vzeroupper
 10143d5:	call   1012690 <myl_rc_meta_alloc>
 10143da:	mov    -0x38(%rbp),%rsi
 10143de:	mov    -0x48(%rbp),%rdi
 10143e2:	mov    %rax,%r12
 10143e5:	test   %rax,%rax
 10143e8:	jne    10143f9 <register_shapes+0x939>
 10143ea:	mov    0x30(%rbx),%rdx
 10143ee:	mov    %rbx,%rsi
 10143f1:	jmp    10144d2 <register_shapes+0xa12>
 10143f6:	xor    %r12d,%r12d
 10143f9:	mov    -0x3c(%rbp),%ecx
 10143fc:	cmp    $0x1,%ecx
 10143ff:	mov    $0x2,%eax
 1014404:	sbb    $0x0,%rax
 1014408:	mulq   0x20(%rbx)
 101440c:	jo     10144af <register_shapes+0x9ef>
 1014412:	mov    %ecx,%esi
 1014414:	lea    -0xa8(%rbp),%r8
 101441b:	mov    %rax,%rdx
 101441e:	mov    %rbx,%rcx
 1014421:	vzeroupper
 1014424:	call   1014ac0 <index_prepare>
 1014429:	mov    -0x38(%rbp),%rsi
 101442d:	mov    -0x48(%rbp),%rdi
 1014431:	test   %eax,%eax
 1014433:	je     10144af <register_shapes+0x9ef>
 1014435:	lea    -0xa8(%rbp),%rdx
 101443c:	mov    %rbx,%rsi
 101443f:	call   1014d50 <index_commit>
 1014444:	mov    -0x48(%rbp),%rdi
 1014448:	mov    0x1608(%rdi),%rax
 101444f:	test   %r12,%r12
 1014452:	je     101448b <register_shapes+0x9cb>
 1014454:	mov    0xb0(%rax),%rsi
 101445b:	mov    0xb8(%rax),%rax
 1014462:	shl    $0x3,%rax
 1014466:	lea    (%rax,%rax,2),%rdx
 101446a:	mov    %rdi,%r14
 101446d:	call   1012710 <myl_rc_meta_free>
 1014472:	mov    0x1608(%r14),%rax
 1014479:	mov    %r12,0xb0(%rax)
 1014480:	mov    -0x38(%rbp),%rcx
 1014484:	mov    %rcx,0xb8(%rax)
 101448b:	mov    0x28(%rax),%rcx
 101448f:	mov    %rcx,(%rbx)
 1014492:	mov    %rbx,0x28(%rax)
 1014496:	xor    %r9d,%r9d
 1014499:	mov    -0x68(%rbp),%rcx
 101449d:	test   %rcx,%rcx
 10144a0:	je     10144e0 <register_shapes+0xa20>
 10144a2:	mov    0x10(%rbx),%rax
 10144a6:	add    $0x8,%rax
 10144aa:	mov    %rax,(%rcx)
 10144ad:	jmp    10144e0 <register_shapes+0xa20>
 10144af:	shl    $0x3,%rsi
 10144b3:	lea    (%rsi,%rsi,2),%rdx
 10144b7:	mov    %r12,%rsi
 10144ba:	mov    %rbx,%r14
 10144bd:	mov    %rdi,%rbx
 10144c0:	vzeroupper
 10144c3:	call   1012710 <myl_rc_meta_free>
 10144c8:	mov    0x30(%r14),%rdx
 10144cc:	mov    %rbx,%rdi
 10144cf:	mov    %r14,%rsi
 10144d2:	vzeroupper
 10144d5:	call   1012710 <myl_rc_meta_free>
 10144da:	mov    $0x1,%r9d
 10144e0:	mov    %r9d,%eax
 10144e3:	add    $0x88,%rsp
 10144ea:	pop    %rbx
 10144eb:	pop    %r12
 10144ed:	pop    %r13
 10144ef:	pop    %r14
 10144f1:	pop    %r15
 10144f3:	pop    %rbp
 10144f4:	ret
 10144f5:	call   101267d <myl_rc_invariant_failed>
 10144fa:	int3
 10144fb:	int3
 10144fc:	int3
 10144fd:	int3
 10144fe:	int3
 10144ff:	int3

0000000001014500 <myl_rc_module_register_image>:
 1014500:	push   %rbp
 1014501:	mov    %rsp,%rbp
 1014504:	push   %r15
 1014506:	push   %r14
 1014508:	push   %r13
 101450a:	push   %r12
 101450c:	push   %rbx
 101450d:	sub    $0x78,%rsp
 1014511:	test   %rdi,%rdi
 1014514:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 101451a:	test   %rsi,%rsi
 101451d:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014523:	mov    0x1608(%rdi),%r8
 101452a:	test   %r8,%r8
 101452d:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014533:	cmpl   $0x5,(%rsi)
 1014536:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101453c:	cmpq   $0x0,0xc0(%r8)
 1014544:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101454a:	test   %rdx,%rdx
 101454d:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014553:	cmpl   $0x1,(%rdx)
 1014556:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101455c:	mov    0x10(%rdx),%rax
 1014560:	cmp    0x10(%rsi),%rax
 1014564:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101456a:	mov    0x20(%rdx),%rcx
 101456e:	mov    %rcx,-0x40(%rbp)
 1014572:	cmp    0x20(%rsi),%rcx
 1014576:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101457c:	test   %rax,%rax
 101457f:	je     1014597 <myl_rc_module_register_image+0x97>
 1014581:	cmpq   $0x0,0x8(%rdx)
 1014586:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 101458c:	cmpq   $0x0,0x8(%rsi)
 1014591:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014597:	cmpq   $0x0,-0x40(%rbp)
 101459c:	je     10145b4 <myl_rc_module_register_image+0xb4>
 101459e:	cmpq   $0x0,0x18(%rdx)
 10145a3:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 10145a9:	cmpq   $0x0,0x18(%rsi)
 10145ae:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 10145b4:	mov    %r8,-0x58(%rbp)
 10145b8:	mov    %rsi,-0x50(%rbp)
 10145bc:	mov    %rdi,-0x30(%rbp)
 10145c0:	test   %rax,%rax
 10145c3:	mov    %rax,-0x48(%rbp)
 10145c7:	mov    %rdx,-0x38(%rbp)
 10145cb:	je     10146b1 <myl_rc_module_register_image+0x1b1>
 10145d1:	mov    0x8(%rdx),%rcx
 10145d5:	mov    (%rcx),%r8
 10145d8:	test   %r8,%r8
 10145db:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 10145e1:	mov    (%r8),%rdx
 10145e4:	test   %rdx,%rdx
 10145e7:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 10145ed:	mov    -0x50(%rbp),%rax
 10145f1:	mov    0x8(%rax),%rdi
 10145f5:	cmp    (%rdi),%rdx
 10145f8:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 10145fe:	mov    0x8(%r8),%rsi
 1014602:	cmp    (%rdx),%rsi
 1014605:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101460b:	mov    0x38(%r8),%rdx
 101460f:	test   %rdx,%rdx
 1014612:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014618:	cmp    %rdx,0x30(%r8)
 101461c:	ja     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014622:	mov    -0x38(%rbp),%rax
 1014626:	mov    0x28(%rax),%r8
 101462a:	mov    -0x48(%rbp),%rax
 101462e:	cmp    %r8,%rdx
 1014631:	ja     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014637:	cmp    $0x1,%rax
 101463b:	je     10146b7 <myl_rc_module_register_image+0x1b7>
 101463d:	mov    $0x1,%r9d
 1014643:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1014650:	mov    (%rcx,%r9,8),%r10
 1014654:	test   %r10,%r10
 1014657:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 101465d:	mov    (%r10),%rsi
 1014660:	test   %rsi,%rsi
 1014663:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014669:	cmp    (%rdi,%r9,8),%rsi
 101466d:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 1014673:	mov    0x8(%r10),%r11
 1014677:	cmp    (%rsi),%r11
 101467a:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 1014680:	mov    0x38(%r10),%rsi
 1014684:	test   %rsi,%rsi
 1014687:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 101468d:	cmp    %r8,%rsi
 1014690:	ja     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014696:	cmp    %rsi,0x30(%r10)
 101469a:	ja     1014ab7 <myl_rc_module_register_image+0x5b7>
 10146a0:	cmp    %rdx,%rsi
 10146a3:	cmova  %rsi,%rdx
 10146a7:	inc    %r9
 10146aa:	cmp    %r9,%rax
 10146ad:	jne    1014650 <myl_rc_module_register_image+0x150>
 10146af:	jmp    10146b7 <myl_rc_module_register_image+0x1b7>
 10146b1:	mov    0x28(%rdx),%r8
 10146b5:	xor    %edx,%edx
 10146b7:	cmp    %rdx,%r8
 10146ba:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 10146c0:	cmpq   $0x0,-0x40(%rbp)
 10146c5:	je     10148b5 <myl_rc_module_register_image+0x3b5>
 10146cb:	mov    -0x38(%rbp),%rax
 10146cf:	mov    0x18(%rax),%rdx
 10146d3:	mov    -0x50(%rbp),%rax
 10146d7:	mov    0x18(%rax),%rax
 10146db:	lea    0x9c(%rdx),%r8
 10146e2:	lea    0x60(%rdx),%r9
 10146e6:	xor    %r10d,%r10d
 10146e9:	jmp    1014714 <myl_rc_module_register_image+0x214>
 10146eb:	nopl   0x0(%rax,%rax,1)
 10146f0:	or     %cl,%r11b
 10146f3:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 10146f9:	inc    %r10
 10146fc:	add    $0xc8,%r8
 1014703:	add    $0xc8,%r9
 101470a:	cmp    -0x40(%rbp),%r10
 101470e:	je     10148b5 <myl_rc_module_register_image+0x3b5>
 1014714:	imul   $0xc8,%r10,%rbx
 101471b:	mov    (%rdx,%rbx,1),%rcx
 101471f:	test   %rcx,%rcx
 1014722:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014728:	add    %rdx,%rbx
 101472b:	mov    0x8(%rbx),%rdi
 101472f:	test   %rdi,%rdi
 1014732:	je     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014738:	mov    %r10,%r11
 101473b:	shl    $0x6,%r11
 101473f:	add    %rax,%r11
 1014742:	cmp    (%r11),%rcx
 1014745:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101474b:	mov    (%rcx),%r15
 101474e:	cmp    (%rdi),%r15
 1014751:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 1014757:	cmpl   $0x0,0xc0(%rbx)
 101475e:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 1014764:	cmp    %r15,0x50(%rbx)
 1014768:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101476e:	mov    0x40(%rbx),%r14d
 1014772:	cmp    $0x11,%r14
 1014776:	ja     1014ab7 <myl_rc_module_register_image+0x5b7>
 101477c:	movzbl 0x44(%rbx),%ecx
 1014780:	cmp    $0x1,%cl
 1014783:	ja     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014789:	cmpb   $0x0,0x45(%rbx)
 101478d:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 1014793:	movzbl 0x46(%rbx),%r11d
 1014798:	cmp    $0x2,%r11b
 101479c:	jae    1014ab7 <myl_rc_module_register_image+0x5b7>
 10147a2:	cmp    $0x11,%r14d
 10147a6:	je     10146f0 <myl_rc_module_register_image+0x1f0>
 10147ac:	movzwl 0x58(%rbx),%r12d
 10147b1:	mov    $0xffff,%ecx
 10147b6:	shrx   %r14d,%ecx,%ecx
 10147bb:	shlx   %r14d,%ecx,%ecx
 10147c0:	xor    %r12d,%ecx
 10147c3:	cmp    $0xffff,%ecx
 10147c9:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 10147cf:	movzwl 0x5a(%rbx),%r13d
 10147d4:	andn   %r13d,%r12d,%ecx
 10147d9:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 10147df:	test   %r14,%r14
 10147e2:	je     1014816 <myl_rc_module_register_image+0x316>
 10147e4:	mov    %r15,%rcx
 10147e7:	sub    $0x8,%rcx
 10147eb:	jb     1014ab7 <myl_rc_module_register_image+0x5b7>
 10147f1:	xor    %edi,%edi
 10147f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1014800:	movzwl (%r8,%rdi,2),%esi
 1014805:	cmp    %rsi,%rcx
 1014808:	jb     1014ab7 <myl_rc_module_register_image+0x5b7>
 101480e:	inc    %rdi
 1014811:	cmp    %rdi,%r14
 1014814:	jne    1014800 <myl_rc_module_register_image+0x300>
 1014816:	test   %r11b,%r11b
 1014819:	je     1014836 <myl_rc_module_register_image+0x336>
 101481b:	cmp    $0x4,%r15
 101481f:	jb     1014ab7 <myl_rc_module_register_image+0x5b7>
 1014825:	mov    0x48(%rbx),%ecx
 1014828:	add    $0xfffffffffffffffc,%r15
 101482c:	cmp    %rcx,%r15
 101482f:	jae    101484a <myl_rc_module_register_image+0x34a>
 1014831:	jmp    1014ab7 <myl_rc_module_register_image+0x5b7>
 1014836:	cmp    %r12w,%r13w
 101483a:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 1014840:	cmpl   $0xffffffff,0x48(%rbx)
 1014844:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101484a:	not    %r12d
 101484d:	movzwl 0x5c(%rbx),%ecx
 1014851:	test   %r12d,%ecx
 1014854:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101485a:	and    %r13d,%ecx
 101485d:	cmp    %r13d,%ecx
 1014860:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 1014866:	xor    %ecx,%ecx
 1014868:	nopl   0x0(%rax,%rax,1)
 1014870:	movzwl -0x2(%r9,%rcx,2),%edi
 1014876:	test   %r12d,%edi
 1014879:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101487f:	and    %r13d,%edi
 1014882:	cmp    %r13d,%edi
 1014885:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 101488b:	cmp    $0x1e,%rcx
 101488f:	je     10146f9 <myl_rc_module_register_image+0x1f9>
 1014895:	movzwl (%r9,%rcx,2),%edi
 101489a:	test   %r12d,%edi
 101489d:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 10148a3:	and    %r13d,%edi
 10148a6:	cmp    %r13d,%edi
 10148a9:	jne    1014ab7 <myl_rc_module_register_image+0x5b7>
 10148af:	add    $0x2,%rcx
 10148b3:	jmp    1014870 <myl_rc_module_register_image+0x370>
 10148b5:	mov    -0x58(%rbp),%rax
 10148b9:	mov    0x38(%rax),%rcx
 10148bd:	mov    0x40(%rax),%rdi
 10148c1:	movzbl 0x50(%rax),%eax
 10148c5:	movabs $0x9e3779b97f4a7c15,%rdx
 10148cf:	mov    -0x50(%rbp),%r14
 10148d3:	imul   %r14,%rdx
 10148d7:	shrx   %rax,%rdx,%rdx
 10148dc:	nopl   0x0(%rax)
 10148e0:	and    %rdi,%rdx
 10148e3:	mov    %rdx,%rax
 10148e6:	shl    $0x4,%rax
 10148ea:	mov    (%rcx,%rax,1),%r8
 10148ee:	cmp    %r14,%r8
 10148f1:	je     10148fd <myl_rc_module_register_image+0x3fd>
 10148f3:	test   %r8,%r8
 10148f6:	je     1014910 <myl_rc_module_register_image+0x410>
 10148f8:	inc    %rdx
 10148fb:	jmp    10148e0 <myl_rc_module_register_image+0x3e0>
 10148fd:	shl    $0x4,%rdx
 1014901:	xor    %r12d,%r12d
 1014904:	cmpq   $0x0,0x8(%rcx,%rdx,1)
 101490a:	jne    1014aa5 <myl_rc_module_register_image+0x5a5>
 1014910:	mov    $0xc8,%ecx
 1014915:	mov    -0x40(%rbp),%rax
 1014919:	mul    %rcx
 101491c:	mov    $0x1,%r12d
 1014922:	jo     1014aa5 <myl_rc_module_register_image+0x5a5>
 1014928:	mov    %rax,%r13
 101492b:	mov    %rax,%rbx
 101492e:	add    $0x40,%rbx
 1014932:	jb     1014aa5 <myl_rc_module_register_image+0x5a5>
 1014938:	cmpq   $0x0,-0x48(%rbp)
 101493d:	js     1014aa5 <myl_rc_module_register_image+0x5a5>
 1014943:	mov    -0x30(%rbp),%rdi
 1014947:	mov    %rbx,%rsi
 101494a:	call   1012690 <myl_rc_meta_alloc>
 101494f:	test   %rax,%rax
 1014952:	je     1014aa5 <myl_rc_module_register_image+0x5a5>
 1014958:	mov    %r14,0x8(%rax)
 101495c:	mov    -0x38(%rbp),%rcx
 1014960:	mov    %rcx,0x38(%rax)
 1014964:	mov    0x10(%rcx),%rdx
 1014968:	mov    %rdx,0x20(%rax)
 101496c:	mov    0x20(%rcx),%rdx
 1014970:	mov    %rdx,0x28(%rax)
 1014974:	mov    %rbx,0x30(%rax)
 1014978:	mov    %rax,%rdi
 101497b:	add    $0x40,%rdi
 101497f:	mov    %rdi,0x18(%rax)
 1014983:	test   %r13,%r13
 1014986:	mov    %rax,%r12
 1014989:	je     101499d <myl_rc_module_register_image+0x49d>
 101498b:	mov    0x18(%rcx),%rsi
 101498f:	mov    %rcx,%r14
 1014992:	mov    %r13,%rdx
 1014995:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101499a:	mov    %r14,%rcx
 101499d:	mov    0x28(%rcx),%rax
 10149a1:	mov    -0x30(%rbp),%rdi
 10149a5:	mov    0x1608(%rdi),%rcx
 10149ac:	xor    %r15d,%r15d
 10149af:	mov    $0x0,%r13d
 10149b5:	cmp    0xb8(%rcx),%rax
 10149bc:	jbe    10149eb <myl_rc_module_register_image+0x4eb>
 10149be:	mov    $0x18,%ecx
 10149c3:	mul    %rcx
 10149c6:	mov    %rax,%r15
 10149c9:	jno    10149d3 <myl_rc_module_register_image+0x4d3>
 10149cb:	xor    %r13d,%r13d
 10149ce:	jmp    1014a83 <myl_rc_module_register_image+0x583>
 10149d3:	mov    %r15,%rsi
 10149d6:	call   1012690 <myl_rc_meta_alloc>
 10149db:	test   %rax,%rax
 10149de:	je     1014a7c <myl_rc_module_register_image+0x57c>
 10149e4:	mov    %rax,%r13
 10149e7:	mov    -0x30(%rbp),%rdi
 10149eb:	mov    -0x48(%rbp),%rdx
 10149ef:	add    %rdx,%rdx
 10149f2:	lea    -0x98(%rbp),%r8
 10149f9:	mov    $0x1,%esi
 10149fe:	mov    %r12,%rcx
 1014a01:	mov    %rdi,%r14
 1014a04:	call   1014ac0 <index_prepare>
 1014a09:	test   %eax,%eax
 1014a0b:	je     1014a77 <myl_rc_module_register_image+0x577>
 1014a0d:	lea    -0x98(%rbp),%rdx
 1014a14:	mov    %r14,%rdi
 1014a17:	mov    %r12,%rsi
 1014a1a:	call   1014d50 <index_commit>
 1014a1f:	mov    0x1608(%r14),%rax
 1014a26:	test   %r13,%r13
 1014a29:	je     1014a66 <myl_rc_module_register_image+0x566>
 1014a2b:	mov    0xb0(%rax),%rsi
 1014a32:	mov    0xb8(%rax),%rax
 1014a39:	shl    $0x3,%rax
 1014a3d:	lea    (%rax,%rax,2),%rdx
 1014a41:	mov    %r14,%rdi
 1014a44:	call   1012710 <myl_rc_meta_free>
 1014a49:	mov    0x1608(%r14),%rax
 1014a50:	mov    %r13,0xb0(%rax)
 1014a57:	mov    -0x38(%rbp),%rcx
 1014a5b:	mov    0x28(%rcx),%rcx
 1014a5f:	mov    %rcx,0xb8(%rax)
 1014a66:	mov    0x28(%rax),%rcx
 1014a6a:	mov    %rcx,(%r12)
 1014a6e:	mov    %r12,0x28(%rax)
 1014a72:	xor    %r12d,%r12d
 1014a75:	jmp    1014aa5 <myl_rc_module_register_image+0x5a5>
 1014a77:	mov    %r14,%rdi
 1014a7a:	jmp    1014a83 <myl_rc_module_register_image+0x583>
 1014a7c:	xor    %r13d,%r13d
 1014a7f:	mov    -0x30(%rbp),%rdi
 1014a83:	mov    %r13,%rsi
 1014a86:	mov    %r15,%rdx
 1014a89:	mov    %rdi,%r14
 1014a8c:	call   1012710 <myl_rc_meta_free>
 1014a91:	mov    %r14,%rdi
 1014a94:	mov    %r12,%rsi
 1014a97:	mov    %rbx,%rdx
 1014a9a:	call   1012710 <myl_rc_meta_free>
 1014a9f:	mov    $0x1,%r12d
 1014aa5:	mov    %r12d,%eax
 1014aa8:	add    $0x78,%rsp
 1014aac:	pop    %rbx
 1014aad:	pop    %r12
 1014aaf:	pop    %r13
 1014ab1:	pop    %r14
 1014ab3:	pop    %r15
 1014ab5:	pop    %rbp
 1014ab6:	ret
 1014ab7:	call   101267d <myl_rc_invariant_failed>
 1014abc:	int3
 1014abd:	int3
 1014abe:	int3
 1014abf:	int3

0000000001014ac0 <index_prepare>:
 1014ac0:	push   %rbp
 1014ac1:	mov    %rsp,%rbp
 1014ac4:	push   %r15
 1014ac6:	push   %r14
 1014ac8:	push   %r13
 1014aca:	push   %r12
 1014acc:	push   %rbx
 1014acd:	sub    $0x18,%rsp
 1014ad1:	mov    %r8,%rbx
 1014ad4:	mov    %rdx,-0x40(%rbp)
 1014ad8:	mov    %rsi,%rdx
 1014adb:	mov    %rdi,%r14
 1014ade:	vxorps %xmm0,%xmm0,%xmm0
 1014ae2:	vmovups %ymm0,0x20(%r8)
 1014ae8:	vmovups %ymm0,(%r8)
 1014aed:	mov    0x1608(%rdi),%r15
 1014af4:	mov    0x28(%rcx),%rax
 1014af8:	xor    %edi,%edi
 1014afa:	test   %rax,%rax
 1014afd:	je     1014bb3 <index_prepare+0xf3>
 1014b03:	mov    %rdx,-0x30(%rbp)
 1014b07:	mov    %r14,-0x38(%rbp)
 1014b0b:	mov    0xa8(%r15),%rdx
 1014b12:	add    %rax,%rdx
 1014b15:	lea    0x10(,%rdx,4),%rdx
 1014b1d:	mov    0xa0(%r15),%r13
 1014b24:	mov    0x18(%rcx),%rsi
 1014b28:	xor    %r12d,%r12d
 1014b2b:	xor    %r8d,%r8d
 1014b2e:	mov    %r13,%rcx
 1014b31:	jmp    1014b62 <index_prepare+0xa2>
 1014b33:	mov    0x98(%r15),%r11
 1014b3a:	mov    %r10,%r14
 1014b3d:	shl    $0x4,%r14
 1014b41:	cmpq   $0x0,(%r11,%r14,1)
 1014b46:	je     1014b9c <index_prepare+0xdc>
 1014b48:	nopl   0x0(%rax,%rax,1)
 1014b50:	inc    %r8
 1014b53:	mov    %r8,%r12
 1014b56:	add    $0xc8,%rsi
 1014b5d:	dec    %rax
 1014b60:	je     1014ba8 <index_prepare+0xe8>
 1014b62:	mov    (%rsi),%r9
 1014b65:	mov    0x34(%r9),%r9d
 1014b69:	test   %r9d,%r9d
 1014b6c:	setne  %r10b
 1014b70:	cmp    %edi,%r9d
 1014b73:	seta   %r11b
 1014b77:	and    %r10b,%r11b
 1014b7a:	cmp    $0x1,%r11b
 1014b7e:	jne    1014b50 <index_prepare+0x90>
 1014b80:	mov    %r9d,%r10d
 1014b83:	cmp    %r10,%rdx
 1014b86:	jbe    1014b50 <index_prepare+0x90>
 1014b88:	cmp    %r10,%r13
 1014b8b:	ja     1014b33 <index_prepare+0x73>
 1014b8d:	inc    %r10
 1014b90:	cmp    %r10,%rcx
 1014b93:	cmovbe %r10,%rcx
 1014b97:	mov    %r9d,%edi
 1014b9a:	jmp    1014b56 <index_prepare+0x96>
 1014b9c:	add    %r14,%r11
 1014b9f:	cmpq   $0x0,0x8(%r11)
 1014ba4:	jne    1014b50 <index_prepare+0x90>
 1014ba6:	jmp    1014b8d <index_prepare+0xcd>
 1014ba8:	cmp    %r13,%rcx
 1014bab:	jne    1014bb8 <index_prepare+0xf8>
 1014bad:	mov    -0x38(%rbp),%r14
 1014bb1:	jmp    1014c22 <index_prepare+0x162>
 1014bb3:	xor    %r12d,%r12d
 1014bb6:	jmp    1014c26 <index_prepare+0x166>
 1014bb8:	add    %r13,%r13
 1014bbb:	cmp    %r13,%rcx
 1014bbe:	cmova  %rcx,%r13
 1014bc2:	mov    %r13,%rax
 1014bc5:	shr    $0x3c,%rax
 1014bc9:	mov    -0x38(%rbp),%r14
 1014bcd:	jne    1014c87 <index_prepare+0x1c7>
 1014bd3:	mov    %r13,%rsi
 1014bd6:	shl    $0x4,%rsi
 1014bda:	mov    %r14,%rdi
 1014bdd:	vzeroupper
 1014be0:	call   1012690 <myl_rc_meta_alloc>
 1014be5:	test   %rax,%rax
 1014be8:	je     1014c87 <index_prepare+0x1c7>
 1014bee:	mov    0xa0(%r15),%rdx
 1014bf5:	test   %rdx,%rdx
 1014bf8:	je     1014c13 <index_prepare+0x153>
 1014bfa:	mov    0x98(%r15),%rsi
 1014c01:	shl    $0x4,%rdx
 1014c05:	mov    %rax,%rdi
 1014c08:	mov    %rax,%r15
 1014c0b:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1014c10:	mov    %r15,%rax
 1014c13:	mov    %rax,0x30(%rbx)
 1014c17:	mov    %r13,0x38(%rbx)
 1014c1b:	mov    0x1608(%r14),%r15
 1014c22:	mov    -0x30(%rbp),%rdx
 1014c26:	add    $0x38,%r15
 1014c2a:	mov    %r14,%rdi
 1014c2d:	mov    %r15,%rsi
 1014c30:	mov    %rbx,%rcx
 1014c33:	vzeroupper
 1014c36:	call   10157e0 <map_prepare>
 1014c3b:	test   %eax,%eax
 1014c3d:	je     1014c87 <index_prepare+0x1c7>
 1014c3f:	mov    0x1608(%r14),%rsi
 1014c46:	add    $0x58,%rsi
 1014c4a:	lea    0x10(%rbx),%rcx
 1014c4e:	mov    %r14,%rdi
 1014c51:	mov    -0x40(%rbp),%rdx
 1014c55:	call   10157e0 <map_prepare>
 1014c5a:	test   %eax,%eax
 1014c5c:	je     1014c87 <index_prepare+0x1c7>
 1014c5e:	mov    0x1608(%r14),%rsi
 1014c65:	add    $0x78,%rsi
 1014c69:	lea    0x20(%rbx),%rcx
 1014c6d:	mov    %r14,%rdi
 1014c70:	mov    %r12,%rdx
 1014c73:	call   10157e0 <map_prepare>
 1014c78:	mov    %eax,%ecx
 1014c7a:	mov    $0x1,%eax
 1014c7f:	test   %ecx,%ecx
 1014c81:	jne    1014d33 <index_prepare+0x273>
 1014c87:	mov    (%rbx),%rsi
 1014c8a:	test   %rsi,%rsi
 1014c8d:	je     1014ca6 <index_prepare+0x1e6>
 1014c8f:	mov    0x8(%rbx),%rdx
 1014c93:	shl    $0x4,%rdx
 1014c97:	add    $0x10,%rdx
 1014c9b:	mov    %r14,%rdi
 1014c9e:	vzeroupper
 1014ca1:	call   1012710 <myl_rc_meta_free>
 1014ca6:	vxorps %xmm0,%xmm0,%xmm0
 1014caa:	vmovups %xmm0,(%rbx)
 1014cae:	lea    0x10(%rbx),%r15
 1014cb2:	mov    0x10(%rbx),%rsi
 1014cb6:	test   %rsi,%rsi
 1014cb9:	je     1014cd6 <index_prepare+0x216>
 1014cbb:	mov    0x18(%rbx),%rdx
 1014cbf:	shl    $0x4,%rdx
 1014cc3:	add    $0x10,%rdx
 1014cc7:	mov    %r14,%rdi
 1014cca:	vzeroupper
 1014ccd:	call   1012710 <myl_rc_meta_free>
 1014cd2:	vxorps %xmm0,%xmm0,%xmm0
 1014cd6:	vmovups %xmm0,(%r15)
 1014cdb:	lea    0x20(%rbx),%r15
 1014cdf:	mov    0x20(%rbx),%rsi
 1014ce3:	test   %rsi,%rsi
 1014ce6:	je     1014cff <index_prepare+0x23f>
 1014ce8:	mov    0x28(%rbx),%rdx
 1014cec:	shl    $0x4,%rdx
 1014cf0:	add    $0x10,%rdx
 1014cf4:	mov    %r14,%rdi
 1014cf7:	vzeroupper
 1014cfa:	call   1012710 <myl_rc_meta_free>
 1014cff:	vxorps %xmm0,%xmm0,%xmm0
 1014d03:	vmovups %xmm0,(%r15)
 1014d08:	mov    0x30(%rbx),%rsi
 1014d0c:	test   %rsi,%rsi
 1014d0f:	je     1014d24 <index_prepare+0x264>
 1014d11:	mov    0x38(%rbx),%rdx
 1014d15:	shl    $0x4,%rdx
 1014d19:	mov    %r14,%rdi
 1014d1c:	vzeroupper
 1014d1f:	call   1012710 <myl_rc_meta_free>
 1014d24:	vxorps %xmm0,%xmm0,%xmm0
 1014d28:	vmovups %ymm0,0x20(%rbx)
 1014d2d:	vmovups %ymm0,(%rbx)
 1014d31:	xor    %eax,%eax
 1014d33:	add    $0x18,%rsp
 1014d37:	pop    %rbx
 1014d38:	pop    %r12
 1014d3a:	pop    %r13
 1014d3c:	pop    %r14
 1014d3e:	pop    %r15
 1014d40:	pop    %rbp
 1014d41:	vzeroupper
 1014d44:	ret
 1014d45:	int3
 1014d46:	int3
 1014d47:	int3
 1014d48:	int3
 1014d49:	int3
 1014d4a:	int3
 1014d4b:	int3
 1014d4c:	int3
 1014d4d:	int3
 1014d4e:	int3
 1014d4f:	int3

0000000001014d50 <index_commit>:
 1014d50:	push   %rbp
 1014d51:	mov    %rsp,%rbp
 1014d54:	push   %r15
 1014d56:	push   %r14
 1014d58:	push   %r13
 1014d5a:	push   %r12
 1014d5c:	push   %rbx
 1014d5d:	sub    $0x28,%rsp
 1014d61:	mov    %rdx,%r15
 1014d64:	mov    %rsi,%rbx
 1014d67:	mov    %rdi,%r13
 1014d6a:	mov    0x1608(%rdi),%rax
 1014d71:	cmpq   $0x0,(%rdx)
 1014d75:	je     1014e2d <index_commit+0xdd>
 1014d7b:	mov    0x38(%rax),%rsi
 1014d7f:	mov    0x48(%rax),%r14
 1014d83:	cmp    $0x10030a0,%rsi
 1014d8a:	je     1014dac <index_commit+0x5c>
 1014d8c:	mov    0x40(%rax),%rdx
 1014d90:	cmp    $0xffffffffffffffff,%rdx
 1014d94:	je     1014dac <index_commit+0x5c>
 1014d96:	shl    $0x4,%rdx
 1014d9a:	add    $0x10,%rdx
 1014d9e:	mov    %r13,%rdi
 1014da1:	mov    %rax,%r12
 1014da4:	call   1012710 <myl_rc_meta_free>
 1014da9:	mov    %r12,%rax
 1014dac:	mov    %rax,%rcx
 1014daf:	lea    -0x11d16(%rip),%rax        # 10030a0 <myl_rc_map_sentinel>
 1014db6:	mov    %rax,0x38(%rcx)
 1014dba:	vxorps %xmm0,%xmm0,%xmm0
 1014dbe:	vmovups %xmm0,0x40(%rcx)
 1014dc3:	mov    %rcx,%r8
 1014dc6:	movl   $0x0,0x54(%rcx)
 1014dcd:	mov    (%r15),%rax
 1014dd0:	mov    0x8(%r15),%rcx
 1014dd4:	lea    0x1(%rcx),%rdx
 1014dd8:	mov    $0x3f,%edi
 1014ddd:	cmp    $0x2,%rdx
 1014de1:	jb     1014e09 <index_commit+0xb9>
 1014de3:	mov    $0x40,%esi
 1014de8:	mov    %rdx,%rdi
 1014deb:	nopl   0x0(%rax,%rax,1)
 1014df0:	shr    $1,%rdi
 1014df3:	dec    %esi
 1014df5:	cmp    $0x3,%rdx
 1014df9:	mov    %rdi,%rdx
 1014dfc:	ja     1014df0 <index_commit+0xa0>
 1014dfe:	cmp    $0x3f,%esi
 1014e01:	mov    $0x3f,%edi
 1014e06:	cmovb  %esi,%edi
 1014e09:	mov    %rax,0x38(%r8)
 1014e0d:	mov    %rcx,0x40(%r8)
 1014e11:	mov    %r14,0x48(%r8)
 1014e15:	mov    %edi,0x50(%r8)
 1014e19:	movl   $0x0,0x54(%r8)
 1014e21:	vmovups %xmm0,(%r15)
 1014e26:	mov    0x1608(%r13),%rax
 1014e2d:	cmpq   $0x0,0x10(%r15)
 1014e32:	je     1014eee <index_commit+0x19e>
 1014e38:	mov    0x58(%rax),%rsi
 1014e3c:	mov    0x68(%rax),%r14
 1014e40:	cmp    $0x10030a0,%rsi
 1014e47:	je     1014e69 <index_commit+0x119>
 1014e49:	mov    0x60(%rax),%rdx
 1014e4d:	cmp    $0xffffffffffffffff,%rdx
 1014e51:	je     1014e69 <index_commit+0x119>
 1014e53:	shl    $0x4,%rdx
 1014e57:	add    $0x10,%rdx
 1014e5b:	mov    %r13,%rdi
 1014e5e:	mov    %rax,%r12
 1014e61:	call   1012710 <myl_rc_meta_free>
 1014e66:	mov    %r12,%rax
 1014e69:	mov    %rax,%rdx
 1014e6c:	lea    0x10(%r15),%rax
 1014e70:	lea    -0x11dd7(%rip),%rcx        # 10030a0 <myl_rc_map_sentinel>
 1014e77:	mov    %rcx,0x58(%rdx)
 1014e7b:	vxorps %xmm0,%xmm0,%xmm0
 1014e7f:	vmovups %xmm0,0x60(%rdx)
 1014e84:	mov    %rdx,%r9
 1014e87:	movl   $0x0,0x74(%rdx)
 1014e8e:	mov    0x10(%r15),%rcx
 1014e92:	mov    0x18(%r15),%rdx
 1014e96:	lea    0x1(%rdx),%rsi
 1014e9a:	mov    $0x3f,%r8d
 1014ea0:	cmp    $0x2,%rsi
 1014ea4:	jb     1014ecb <index_commit+0x17b>
 1014ea6:	mov    $0x40,%edi
 1014eab:	mov    %rsi,%r8
 1014eae:	xchg   %ax,%ax
 1014eb0:	shr    $1,%r8
 1014eb3:	dec    %edi
 1014eb5:	cmp    $0x3,%rsi
 1014eb9:	mov    %r8,%rsi
 1014ebc:	ja     1014eb0 <index_commit+0x160>
 1014ebe:	cmp    $0x3f,%edi
 1014ec1:	mov    $0x3f,%r8d
 1014ec7:	cmovb  %edi,%r8d
 1014ecb:	mov    %rcx,0x58(%r9)
 1014ecf:	mov    %rdx,0x60(%r9)
 1014ed3:	mov    %r14,0x68(%r9)
 1014ed7:	mov    %r8d,0x70(%r9)
 1014edb:	movl   $0x0,0x74(%r9)
 1014ee3:	vmovups %xmm0,(%rax)
 1014ee7:	mov    0x1608(%r13),%rax
 1014eee:	cmpq   $0x0,0x20(%r15)
 1014ef3:	je     1014fca <index_commit+0x27a>
 1014ef9:	mov    0x78(%rax),%rsi
 1014efd:	mov    0x88(%rax),%r14
 1014f04:	cmp    $0x10030a0,%rsi
 1014f0b:	je     1014f30 <index_commit+0x1e0>
 1014f0d:	mov    0x80(%rax),%rdx
 1014f14:	cmp    $0xffffffffffffffff,%rdx
 1014f18:	je     1014f30 <index_commit+0x1e0>
 1014f1a:	shl    $0x4,%rdx
 1014f1e:	add    $0x10,%rdx
 1014f22:	mov    %r13,%rdi
 1014f25:	mov    %rax,%r12
 1014f28:	call   1012710 <myl_rc_meta_free>
 1014f2d:	mov    %r12,%rax
 1014f30:	mov    %rax,%rdx
 1014f33:	lea    0x20(%r15),%rax
 1014f37:	lea    -0x11e9e(%rip),%rcx        # 10030a0 <myl_rc_map_sentinel>
 1014f3e:	mov    %rcx,0x78(%rdx)
 1014f42:	vxorps %xmm0,%xmm0,%xmm0
 1014f46:	vmovups %xmm0,0x80(%rdx)
 1014f4e:	mov    %rdx,%r9
 1014f51:	movl   $0x0,0x94(%rdx)
 1014f5b:	mov    0x20(%r15),%rcx
 1014f5f:	mov    0x28(%r15),%rdx
 1014f63:	lea    0x1(%rdx),%rsi
 1014f67:	mov    $0x3f,%r8d
 1014f6d:	cmp    $0x2,%rsi
 1014f71:	jb     1014f9b <index_commit+0x24b>
 1014f73:	mov    $0x40,%edi
 1014f78:	mov    %rsi,%r8
 1014f7b:	nopl   0x0(%rax,%rax,1)
 1014f80:	shr    $1,%r8
 1014f83:	dec    %edi
 1014f85:	cmp    $0x3,%rsi
 1014f89:	mov    %r8,%rsi
 1014f8c:	ja     1014f80 <index_commit+0x230>
 1014f8e:	cmp    $0x3f,%edi
 1014f91:	mov    $0x3f,%r8d
 1014f97:	cmovb  %edi,%r8d
 1014f9b:	mov    %rcx,0x78(%r9)
 1014f9f:	mov    %rdx,0x80(%r9)
 1014fa6:	mov    %r14,0x88(%r9)
 1014fad:	mov    %r8d,0x90(%r9)
 1014fb4:	movl   $0x0,0x94(%r9)
 1014fbf:	vmovups %xmm0,(%rax)
 1014fc3:	mov    0x1608(%r13),%rax
 1014fca:	mov    %rax,-0x30(%rbp)
 1014fce:	mov    0x30(%r15),%rax
 1014fd2:	test   %rax,%rax
 1014fd5:	je     1015018 <index_commit+0x2c8>
 1014fd7:	mov    -0x30(%rbp),%r14
 1014fdb:	mov    0x98(%r14),%rsi
 1014fe2:	test   %rsi,%rsi
 1014fe5:	je     1014ffe <index_commit+0x2ae>
 1014fe7:	mov    0xa0(%r14),%rdx
 1014fee:	shl    $0x4,%rdx
 1014ff2:	mov    %r13,%rdi
 1014ff5:	call   1012710 <myl_rc_meta_free>
 1014ffa:	mov    0x30(%r15),%rax
 1014ffe:	mov    %rax,0x98(%r14)
 1015005:	mov    0x38(%r15),%rax
 1015009:	mov    %rax,0xa0(%r14)
 1015010:	movq   $0x0,0x30(%r15)
 1015018:	mov    0x8(%rbx),%rax
 101501c:	test   %rax,%rax
 101501f:	je     10150b1 <index_commit+0x361>
 1015025:	mov    0x1608(%r13),%rcx
 101502c:	mov    0x38(%rcx),%rdx
 1015030:	cmp    $0x10030a0,%rdx
 1015037:	je     10153cc <index_commit+0x67c>
 101503d:	mov    0x40(%rcx),%rdi
 1015041:	cmp    $0xffffffffffffffff,%rdi
 1015045:	je     10153cc <index_commit+0x67c>
 101504b:	mov    0x48(%rcx),%rsi
 101504f:	lea    0x1(%rdi),%r8
 1015053:	shr    $1,%r8
 1015056:	cmp    %r8,%rsi
 1015059:	ja     10153cc <index_commit+0x67c>
 101505f:	movzbl 0x50(%rcx),%r8d
 1015064:	mov    %rax,%r9
 1015067:	movabs $0x9e3779b97f4a7c15,%r10
 1015071:	imul   %r10,%r9
 1015075:	shrx   %r8,%r9,%r9
 101507a:	nopw   0x0(%rax,%rax,1)
 1015080:	and    %rdi,%r9
 1015083:	mov    %r9,%r8
 1015086:	shl    $0x4,%r8
 101508a:	mov    (%rdx,%r8,1),%r10
 101508e:	test   %r10,%r10
 1015091:	je     101509b <index_commit+0x34b>
 1015093:	inc    %r9
 1015096:	cmp    %rax,%r10
 1015099:	jne    1015080 <index_commit+0x330>
 101509b:	test   %r10,%r10
 101509e:	jne    10150b1 <index_commit+0x361>
 10150a0:	add    %r8,%rdx
 10150a3:	mov    %rax,(%rdx)
 10150a6:	mov    %rbx,0x8(%rdx)
 10150aa:	inc    %rsi
 10150ad:	mov    %rsi,0x48(%rcx)
 10150b1:	mov    0x20(%rbx),%rax
 10150b5:	test   %rax,%rax
 10150b8:	je     101521a <index_commit+0x4ca>
 10150be:	xor    %ecx,%ecx
 10150c0:	lea    -0x12027(%rip),%rdx        # 10030a0 <myl_rc_map_sentinel>
 10150c7:	jmp    10150dc <index_commit+0x38c>
 10150c9:	nopl   0x0(%rax)
 10150d0:	inc    %rcx
 10150d3:	cmp    %rax,%rcx
 10150d6:	je     101521a <index_commit+0x4ca>
 10150dc:	mov    0x38(%rbx),%rsi
 10150e0:	test   %rsi,%rsi
 10150e3:	je     10150f0 <index_commit+0x3a0>
 10150e5:	mov    0x8(%rsi),%rsi
 10150e9:	mov    (%rsi,%rcx,8),%rdi
 10150ed:	jmp    10150fb <index_commit+0x3ab>
 10150ef:	nop
 10150f0:	mov    %rcx,%rdi
 10150f3:	shl    $0x6,%rdi
 10150f7:	add    0x10(%rbx),%rdi
 10150fb:	mov    0x1608(%r13),%r8
 1015102:	mov    0x58(%r8),%r9
 1015106:	cmp    %rdx,%r9
 1015109:	je     10153cc <index_commit+0x67c>
 101510f:	mov    0x60(%r8),%r11
 1015113:	cmp    $0xffffffffffffffff,%r11
 1015117:	je     10153cc <index_commit+0x67c>
 101511d:	mov    0x68(%r8),%r10
 1015121:	lea    0x1(%r11),%rsi
 1015125:	shr    $1,%rsi
 1015128:	cmp    %rsi,%r10
 101512b:	ja     10153cc <index_commit+0x67c>
 1015131:	lea    0x8(%rdi),%rsi
 1015135:	movzbl 0x70(%r8),%r14d
 101513a:	mov    %rsi,%r15
 101513d:	movabs $0x9e3779b97f4a7c15,%r12
 1015147:	imul   %r12,%r15
 101514b:	shrx   %r14,%r15,%r15
 1015150:	and    %r11,%r15
 1015153:	mov    %r15,%r14
 1015156:	shl    $0x4,%r14
 101515a:	mov    (%r9,%r14,1),%r12
 101515e:	test   %r12,%r12
 1015161:	je     101516b <index_commit+0x41b>
 1015163:	inc    %r15
 1015166:	cmp    %rsi,%r12
 1015169:	jne    1015150 <index_commit+0x400>
 101516b:	test   %r12,%r12
 101516e:	jne    1015181 <index_commit+0x431>
 1015170:	add    %r14,%r9
 1015173:	mov    %rsi,(%r9)
 1015176:	mov    %rsi,0x8(%r9)
 101517a:	inc    %r10
 101517d:	mov    %r10,0x68(%r8)
 1015181:	mov    (%rdi),%rdi
 1015184:	test   %rdi,%rdi
 1015187:	je     10150d0 <index_commit+0x380>
 101518d:	mov    0x1608(%r13),%r8
 1015194:	mov    0x58(%r8),%r9
 1015198:	cmp    %rdx,%r9
 101519b:	je     10153cc <index_commit+0x67c>
 10151a1:	mov    0x60(%r8),%r11
 10151a5:	cmp    $0xffffffffffffffff,%r11
 10151a9:	je     10153cc <index_commit+0x67c>
 10151af:	mov    0x68(%r8),%r10
 10151b3:	lea    0x1(%r11),%r14
 10151b7:	shr    $1,%r14
 10151ba:	cmp    %r14,%r10
 10151bd:	ja     10153cc <index_commit+0x67c>
 10151c3:	movzbl 0x70(%r8),%r14d
 10151c8:	mov    %rdi,%r15
 10151cb:	movabs $0x9e3779b97f4a7c15,%r12
 10151d5:	imul   %r12,%r15
 10151d9:	shrx   %r14,%r15,%r15
 10151de:	xchg   %ax,%ax
 10151e0:	and    %r11,%r15
 10151e3:	mov    %r15,%r14
 10151e6:	shl    $0x4,%r14
 10151ea:	mov    (%r9,%r14,1),%r12
 10151ee:	test   %r12,%r12
 10151f1:	je     10151fb <index_commit+0x4ab>
 10151f3:	inc    %r15
 10151f6:	cmp    %rdi,%r12
 10151f9:	jne    10151e0 <index_commit+0x490>
 10151fb:	test   %r12,%r12
 10151fe:	jne    10150d0 <index_commit+0x380>
 1015204:	add    %r14,%r9
 1015207:	mov    %rdi,(%r9)
 101520a:	mov    %rsi,0x8(%r9)
 101520e:	inc    %r10
 1015211:	mov    %r10,0x68(%r8)
 1015215:	jmp    10150d0 <index_commit+0x380>
 101521a:	mov    %r13,-0x48(%rbp)
 101521e:	mov    0x28(%rbx),%rax
 1015222:	test   %rax,%rax
 1015225:	je     10153bd <index_commit+0x66d>
 101522b:	mov    -0x30(%rbp),%rcx
 101522f:	add    0xa8(%rcx),%rax
 1015236:	lea    0x10(,%rax,4),%rax
 101523e:	mov    %rax,-0x38(%rbp)
 1015242:	xor    %r11d,%r11d
 1015245:	lea    -0x121ac(%rip),%r10        # 10030a0 <myl_rc_map_sentinel>
 101524c:	xor    %r12d,%r12d
 101524f:	jmp    101528d <index_commit+0x53d>
 1015251:	shl    $0x4,%rcx
 1015255:	mov    0x38(%rbx),%rsi
 1015259:	test   %rsi,%rsi
 101525c:	cmove  %rsi,%r14
 1015260:	mov    %r14,(%rdx,%rcx,1)
 1015264:	mov    %rdi,0x8(%rdx,%rcx,1)
 1015269:	mov    -0x30(%rbp),%rcx
 101526d:	incq   0xa8(%rcx)
 1015274:	mov    %eax,%r11d
 1015277:	nopw   0x0(%rax,%rax,1)
 1015280:	inc    %r12
 1015283:	cmp    0x28(%rbx),%r12
 1015287:	jae    10153bd <index_commit+0x66d>
 101528d:	mov    0x18(%rbx),%rax
 1015291:	imul   $0xc8,%r12,%rcx
 1015298:	lea    (%rax,%rcx,1),%rdi
 101529c:	mov    (%rax,%rcx,1),%r14
 10152a0:	mov    0x34(%r14),%eax
 10152a4:	test   %eax,%eax
 10152a6:	setne  %cl
 10152a9:	cmp    %r11d,%eax
 10152ac:	seta   %dl
 10152af:	and    %cl,%dl
 10152b1:	cmp    $0x1,%dl
 10152b4:	jne    1015300 <index_commit+0x5b0>
 10152b6:	mov    %eax,%ecx
 10152b8:	cmp    %rcx,-0x38(%rbp)
 10152bc:	jbe    1015300 <index_commit+0x5b0>
 10152be:	mov    -0x30(%rbp),%rsi
 10152c2:	mov    0x98(%rsi),%rdx
 10152c9:	cmp    %rcx,0xa0(%rsi)
 10152d0:	jbe    1015251 <index_commit+0x501>
 10152d6:	mov    %rcx,%rsi
 10152d9:	shl    $0x4,%rsi
 10152dd:	cmpq   $0x0,(%rdx,%rsi,1)
 10152e2:	jne    1015300 <index_commit+0x5b0>
 10152e4:	add    %rdx,%rsi
 10152e7:	cmpq   $0x0,0x8(%rsi)
 10152ec:	je     1015251 <index_commit+0x501>
 10152f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015300:	cmpq   $0x0,0x38(%rbx)
 1015305:	jne    1015326 <index_commit+0x5d6>
 1015307:	mov    %rbx,%r13
 101530a:	mov    %r10,%rbx
 101530d:	mov    %rdi,-0x40(%rbp)
 1015311:	mov    %r11,%r15
 1015314:	call   10131e0 <flat_build>
 1015319:	mov    %r15,%r11
 101531c:	mov    -0x40(%rbp),%rdi
 1015320:	mov    %rbx,%r10
 1015323:	mov    %r13,%rbx
 1015326:	mov    -0x48(%rbp),%rax
 101532a:	mov    0x1608(%rax),%rax
 1015331:	mov    0x78(%rax),%rcx
 1015335:	cmp    %r10,%rcx
 1015338:	je     10153cc <index_commit+0x67c>
 101533e:	mov    0x80(%rax),%rsi
 1015345:	cmp    $0xffffffffffffffff,%rsi
 1015349:	je     10153cc <index_commit+0x67c>
 101534f:	mov    0x88(%rax),%rdx
 1015356:	lea    0x1(%rsi),%r8
 101535a:	shr    $1,%r8
 101535d:	cmp    %r8,%rdx
 1015360:	ja     10153cc <index_commit+0x67c>
 1015362:	movzbl 0x90(%rax),%r15d
 101536a:	mov    %r14,%r8
 101536d:	movabs $0x9e3779b97f4a7c15,%r9
 1015377:	imul   %r9,%r8
 101537b:	shrx   %r15,%r8,%r15
 1015380:	and    %rsi,%r15
 1015383:	mov    %r15,%r8
 1015386:	shl    $0x4,%r8
 101538a:	mov    (%rcx,%r8,1),%r9
 101538e:	test   %r9,%r9
 1015391:	je     101539b <index_commit+0x64b>
 1015393:	inc    %r15
 1015396:	cmp    %r14,%r9
 1015399:	jne    1015380 <index_commit+0x630>
 101539b:	test   %r9,%r9
 101539e:	jne    1015280 <index_commit+0x530>
 10153a4:	add    %r8,%rcx
 10153a7:	mov    %r14,(%rcx)
 10153aa:	mov    %rdi,0x8(%rcx)
 10153ae:	inc    %rdx
 10153b1:	mov    %rdx,0x88(%rax)
 10153b8:	jmp    1015280 <index_commit+0x530>
 10153bd:	add    $0x28,%rsp
 10153c1:	pop    %rbx
 10153c2:	pop    %r12
 10153c4:	pop    %r13
 10153c6:	pop    %r14
 10153c8:	pop    %r15
 10153ca:	pop    %rbp
 10153cb:	ret
 10153cc:	call   101267d <myl_rc_invariant_failed>
 10153d1:	int3
 10153d2:	int3
 10153d3:	int3
 10153d4:	int3
 10153d5:	int3
 10153d6:	int3
 10153d7:	int3
 10153d8:	int3
 10153d9:	int3
 10153da:	int3
 10153db:	int3
 10153dc:	int3
 10153dd:	int3
 10153de:	int3
 10153df:	int3

00000000010153e0 <myl_rc_descriptor_import>:
 10153e0:	push   %rbp
 10153e1:	mov    %rsp,%rbp
 10153e4:	push   %r15
 10153e6:	push   %r14
 10153e8:	push   %rbx
 10153e9:	sub    $0x58,%rsp
 10153ed:	test   %rdi,%rdi
 10153f0:	je     10154a1 <myl_rc_descriptor_import+0xc1>
 10153f6:	test   %rsi,%rsi
 10153f9:	je     10154a1 <myl_rc_descriptor_import+0xc1>
 10153ff:	mov    0x1608(%rdi),%rcx
 1015406:	test   %rcx,%rcx
 1015409:	je     10154a1 <myl_rc_descriptor_import+0xc1>
 101540f:	mov    (%rsi),%rax
 1015412:	test   %rax,%rax
 1015415:	je     10154a1 <myl_rc_descriptor_import+0xc1>
 101541b:	mov    0x8(%rsi),%rdx
 101541f:	test   %rdx,%rdx
 1015422:	je     10154a1 <myl_rc_descriptor_import+0xc1>
 1015424:	cmpq   $0x0,0xc0(%rcx)
 101542c:	jne    10154a1 <myl_rc_descriptor_import+0xc1>
 101542e:	mov    (%rdx),%rdx
 1015431:	cmp    (%rax),%rdx
 1015434:	jne    10154a1 <myl_rc_descriptor_import+0xc1>
 1015436:	mov    0x34(%rax),%edx
 1015439:	cmp    %rdx,0xa0(%rcx)
 1015440:	jbe    10154a6 <myl_rc_descriptor_import+0xc6>
 1015442:	mov    0x98(%rcx),%rcx
 1015449:	shl    $0x4,%rdx
 101544d:	cmp    %rax,(%rcx,%rdx,1)
 1015451:	jne    10154a6 <myl_rc_descriptor_import+0xc6>
 1015453:	add    %rdx,%rcx
 1015456:	mov    0x8(%rcx),%rax
 101545a:	test   %rax,%rax
 101545d:	je     10154b9 <myl_rc_descriptor_import+0xd9>
 101545f:	mov    0x10(%rax),%rcx
 1015463:	cmp    0x10(%rsi),%rcx
 1015467:	jne    10154a1 <myl_rc_descriptor_import+0xc1>
 1015469:	mov    0x18(%rax),%rcx
 101546d:	cmp    0x18(%rsi),%rcx
 1015471:	jne    10154a1 <myl_rc_descriptor_import+0xc1>
 1015473:	mov    0x20(%rax),%rcx
 1015477:	cmp    0x20(%rsi),%rcx
 101547b:	jne    10154a1 <myl_rc_descriptor_import+0xc1>
 101547d:	mov    0x28(%rax),%rcx
 1015481:	cmp    0x28(%rsi),%rcx
 1015485:	jne    10154a1 <myl_rc_descriptor_import+0xc1>
 1015487:	mov    0x30(%rax),%rcx
 101548b:	cmp    0x30(%rsi),%rcx
 101548f:	jne    10154a1 <myl_rc_descriptor_import+0xc1>
 1015491:	mov    0x38(%rax),%rcx
 1015495:	xor    %eax,%eax
 1015497:	cmp    0x38(%rsi),%rcx
 101549b:	je     1015557 <myl_rc_descriptor_import+0x177>
 10154a1:	call   101267d <myl_rc_invariant_failed>
 10154a6:	mov    %rsi,%rcx
 10154a9:	mov    %rax,%rsi
 10154ac:	call   10130fa <myl_rc_binding_find_slow>
 10154b1:	mov    %rcx,%rsi
 10154b4:	test   %rax,%rax
 10154b7:	jne    101545f <myl_rc_descriptor_import+0x7f>
 10154b9:	mov    0x8(%rsi),%rax
 10154bd:	movl   $0x5,-0x70(%rbp)
 10154c4:	vxorps %xmm0,%xmm0,%xmm0
 10154c8:	vmovups %xmm0,-0x6c(%rbp)
 10154cd:	movl   $0x0,-0x5c(%rbp)
 10154d4:	mov    %rsi,-0x58(%rbp)
 10154d8:	movq   $0x1,-0x50(%rbp)
 10154e0:	vxorps %xmm0,%xmm0,%xmm0
 10154e4:	vmovups %ymm0,-0x40(%rbp)
 10154e9:	movq   $0x0,-0x20(%rbp)
 10154f1:	mov    %rdi,-0x48(%rbp)
 10154f5:	lea    -0x48(%rbp),%rdi
 10154f9:	mov    %rax,%rsi
 10154fc:	vzeroupper
 10154ff:	call   1013810 <builder_add>
 1015504:	test   %eax,%eax
 1015506:	je     101551d <myl_rc_descriptor_import+0x13d>
 1015508:	lea    -0x48(%rbp),%rdi
 101550c:	lea    -0x70(%rbp),%rsi
 1015510:	xor    %edx,%edx
 1015512:	xor    %ecx,%ecx
 1015514:	call   1013ac0 <register_shapes>
 1015519:	mov    %eax,%ebx
 101551b:	jmp    1015522 <myl_rc_descriptor_import+0x142>
 101551d:	mov    $0x1,%ebx
 1015522:	mov    -0x48(%rbp),%r14
 1015526:	mov    -0x40(%rbp),%rsi
 101552a:	mov    -0x28(%rbp),%r15
 101552e:	lea    0x0(,%r15,8),%rax
 1015536:	lea    (%rax,%rax,4),%rdx
 101553a:	mov    %r14,%rdi
 101553d:	call   1012710 <myl_rc_meta_free>
 1015542:	mov    -0x38(%rbp),%rsi
 1015546:	shl    $0x4,%r15
 101554a:	mov    %r14,%rdi
 101554d:	mov    %r15,%rdx
 1015550:	call   1012710 <myl_rc_meta_free>
 1015555:	mov    %ebx,%eax
 1015557:	add    $0x58,%rsp
 101555b:	pop    %rbx
 101555c:	pop    %r14
 101555e:	pop    %r15
 1015560:	pop    %rbp
 1015561:	ret
 1015562:	int3
 1015563:	int3
 1015564:	int3
 1015565:	int3
 1015566:	int3
 1015567:	int3
 1015568:	int3
 1015569:	int3
 101556a:	int3
 101556b:	int3
 101556c:	int3
 101556d:	int3
 101556e:	int3
 101556f:	int3

0000000001015570 <flat_disjoint>:
 1015570:	mov    $0x1,%eax
 1015575:	test   %esi,%esi
 1015577:	je     101565a <flat_disjoint+0xea>
 101557d:	push   %rbp
 101557e:	mov    %rsp,%rbp
 1015581:	push   %r15
 1015583:	push   %r14
 1015585:	push   %r13
 1015587:	push   %r12
 1015589:	push   %rbx
 101558a:	mov    %esi,%ecx
 101558c:	lea    0x8(%rdi),%rdx
 1015590:	xor    %esi,%esi
 1015592:	mov    $0xffffffff,%r8d
 1015598:	lea    (%rsi,%rsi,2),%r9
 101559c:	lea    (%rdi,%r9,4),%r9
 10155a0:	mov    %rdx,%r10
 10155a3:	xor    %r11d,%r11d
 10155a6:	jmp    10155c0 <flat_disjoint+0x50>
 10155a8:	nopl   0x0(%rax,%rax,1)
 10155b0:	inc    %r11
 10155b3:	add    $0xc,%r10
 10155b7:	cmp    %r11,%rcx
 10155ba:	je     1015640 <flat_disjoint+0xd0>
 10155c0:	cmp    %r11,%rsi
 10155c3:	jae    10155fc <flat_disjoint+0x8c>
 10155c5:	mov    0x4(%r9),%ebx
 10155c9:	cmp    $0xffffffff,%ebx
 10155cc:	je     10155e0 <flat_disjoint+0x70>
 10155ce:	cmp    -0x4(%r10),%ebx
 10155d2:	jne    10155e0 <flat_disjoint+0x70>
 10155d4:	mov    0x8(%r9),%ebx
 10155d8:	cmp    (%r10),%ebx
 10155db:	jne    10155fc <flat_disjoint+0x8c>
 10155dd:	nopl   (%rax)
 10155e0:	mov    (%r9),%ebx
 10155e3:	mov    -0x8(%r10),%r14d
 10155e7:	mov    %ebx,%r15d
 10155ea:	sub    %r14d,%r15d
 10155ed:	neg    %r15d
 10155f0:	sub    %r14d,%ebx
 10155f3:	cmovb  %r15,%rbx
 10155f7:	cmp    $0x8,%ebx
 10155fa:	jb     101564e <flat_disjoint+0xde>
 10155fc:	mov    -0x4(%r10),%ebx
 1015600:	cmp    %r8,%rbx
 1015603:	je     10155b0 <flat_disjoint+0x40>
 1015605:	mov    (%r9),%r14d
 1015608:	mov    %r14d,%r15d
 101560b:	sub    %ebx,%r15d
 101560e:	mov    %r15d,%r12d
 1015611:	neg    %r12d
 1015614:	xor    %r13d,%r13d
 1015617:	cmp    $0x8,%r12d
 101561b:	setae  %r13b
 101561f:	xor    %r12d,%r12d
 1015622:	cmp    $0x4,%r15d
 1015626:	setae  %r12b
 101562a:	cmp    %ebx,%r14d
 101562d:	cmovae %r12d,%r13d
 1015631:	cmp    $0x1,%r13b
 1015635:	je     10155b0 <flat_disjoint+0x40>
 101563b:	jmp    101564e <flat_disjoint+0xde>
 101563d:	nopl   (%rax)
 1015640:	inc    %rsi
 1015643:	cmp    %rcx,%rsi
 1015646:	jne    1015598 <flat_disjoint+0x28>
 101564c:	jmp    1015650 <flat_disjoint+0xe0>
 101564e:	xor    %eax,%eax
 1015650:	pop    %rbx
 1015651:	pop    %r12
 1015653:	pop    %r13
 1015655:	pop    %r14
 1015657:	pop    %r15
 1015659:	pop    %rbp
 101565a:	ret
 101565b:	int3
 101565c:	int3
 101565d:	int3
 101565e:	int3
 101565f:	int3

0000000001015660 <flat_masks>:
 1015660:	push   %rbp
 1015661:	mov    %rsp,%rbp
 1015664:	push   %r14
 1015666:	push   %rbx
 1015667:	mov    $0xffffffff,%ecx
 101566c:	test   %edx,%edx
 101566e:	je     10156cc <flat_masks+0x6c>
 1015670:	mov    %edx,%r9d
 1015673:	lea    0x8(%rsi),%r11
 1015677:	mov    $0xffffffff,%r14d
 101567d:	xor    %ebx,%ebx
 101567f:	xor    %r8d,%r8d
 1015682:	jmp    10156a6 <flat_masks+0x46>
 1015684:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015690:	bts    %ebx,%r8d
 1015694:	mov    %r14d,%r10d
 1015697:	inc    %rbx
 101569a:	add    $0xc,%r11
 101569e:	mov    %r10d,%r14d
 10156a1:	cmp    %rbx,%r9
 10156a4:	je     10156d7 <flat_masks+0x77>
 10156a6:	mov    -0x4(%r11),%r10d
 10156aa:	cmp    $0xffffffff,%r10d
 10156ae:	je     1015690 <flat_masks+0x30>
 10156b0:	xor    %eax,%eax
 10156b2:	cmp    $0xffffffff,%r14d
 10156b6:	je     10156c1 <flat_masks+0x61>
 10156b8:	cmp    %r10d,%r14d
 10156bb:	jne    10157ce <flat_masks+0x16e>
 10156c1:	cmpl   $0x1f,(%r11)
 10156c5:	jbe    1015697 <flat_masks+0x37>
 10156c7:	jmp    10157ce <flat_masks+0x16e>
 10156cc:	xor    %r8d,%r8d
 10156cf:	mov    $0xffffffff,%r10d
 10156d5:	jmp    1015702 <flat_masks+0xa2>
 10156d7:	xor    %eax,%eax
 10156d9:	mov    %rsi,%r11
 10156dc:	xor    %ebx,%ebx
 10156de:	xchg   %ax,%ax
 10156e0:	mov    (%r11),%r14d
 10156e3:	cmp    $0xfff7,%r14d
 10156ea:	ja     10157ce <flat_masks+0x16e>
 10156f0:	mov    %r14w,0x5c(%rdi,%rbx,2)
 10156f6:	inc    %rbx
 10156f9:	add    $0xc,%r11
 10156fd:	cmp    %rbx,%r9
 1015700:	jne    10156e0 <flat_masks+0x80>
 1015702:	shlx   %edx,%ecx,%eax
 1015707:	not    %eax
 1015709:	mov    %ax,0x18(%rdi)
 101570d:	mov    %r10d,0x8(%rdi)
 1015711:	vmovd  %r8d,%xmm0
 1015716:	vpbroadcastw %xmm0,%ymm0
 101571b:	vmovdqu %ymm0,0x1a(%rdi)
 1015720:	vmovdqu %ymm0,0x3a(%rdi)
 1015725:	mov    %r8w,0x5a(%rdi)
 101572a:	mov    $0x1,%eax
 101572f:	test   %edx,%edx
 1015731:	je     10157ce <flat_masks+0x16e>
 1015737:	cmp    $0x1,%edx
 101573a:	jne    1015740 <flat_masks+0xe0>
 101573c:	xor    %ecx,%ecx
 101573e:	jmp    10157a8 <flat_masks+0x148>
 1015740:	mov    %edx,%edx
 1015742:	mov    %edx,%eax
 1015744:	and    $0xfffffffe,%eax
 1015747:	lea    0x14(%rsi),%r8
 101574b:	xor    %ecx,%ecx
 101574d:	mov    $0x1,%r9d
 1015753:	jmp    101576d <flat_masks+0x10d>
 1015755:	data16 cs nopw 0x0(%rax,%rax,1)
 1015760:	add    $0x2,%rcx
 1015764:	add    $0x18,%r8
 1015768:	cmp    %rcx,%rax
 101576b:	je     101579e <flat_masks+0x13e>
 101576d:	cmpl   $0xffffffff,-0x10(%r8)
 1015772:	je     1015783 <flat_masks+0x123>
 1015774:	shlx   %ecx,%r9d,%r10d
 1015779:	mov    -0xc(%r8),%r11d
 101577d:	or     %r10w,0x1c(%rdi,%r11,2)
 1015783:	cmpl   $0xffffffff,-0x4(%r8)
 1015788:	je     1015760 <flat_masks+0x100>
 101578a:	lea    0x1(%rcx),%r10d
 101578e:	shlx   %r10d,%r9d,%r10d
 1015793:	mov    (%r8),%r11d
 1015796:	or     %r10w,0x1c(%rdi,%r11,2)
 101579c:	jmp    1015760 <flat_masks+0x100>
 101579e:	mov    $0x1,%eax
 10157a3:	test   $0x1,%dl
 10157a6:	je     10157ce <flat_masks+0x16e>
 10157a8:	lea    (%rcx,%rcx,2),%rdx
 10157ac:	cmpl   $0xffffffff,0x4(%rsi,%rdx,4)
 10157b1:	mov    $0x1,%eax
 10157b6:	je     10157ce <flat_masks+0x16e>
 10157b8:	lea    (%rsi,%rdx,4),%rdx
 10157bc:	mov    $0x1,%eax
 10157c1:	shlx   %ecx,%eax,%ecx
 10157c6:	mov    0x8(%rdx),%edx
 10157c9:	or     %cx,0x1c(%rdi,%rdx,2)
 10157ce:	pop    %rbx
 10157cf:	pop    %r14
 10157d1:	pop    %rbp
 10157d2:	vzeroupper
 10157d5:	ret
 10157d6:	int3
 10157d7:	int3
 10157d8:	int3
 10157d9:	int3
 10157da:	int3
 10157db:	int3
 10157dc:	int3
 10157dd:	int3
 10157de:	int3
 10157df:	int3

00000000010157e0 <map_prepare>:
 10157e0:	push   %rbp
 10157e1:	mov    %rsp,%rbp
 10157e4:	push   %r15
 10157e6:	push   %r14
 10157e8:	push   %r12
 10157ea:	push   %rbx
 10157eb:	vxorps %xmm0,%xmm0,%xmm0
 10157ef:	vmovups %xmm0,(%rcx)
 10157f3:	mov    (%rsi),%rax
 10157f6:	xor    %ebx,%ebx
 10157f8:	cmp    $0x10030a0,%rax
 10157ff:	je     1015813 <map_prepare+0x33>
 1015801:	mov    0x8(%rsi),%rax
 1015805:	inc    %rax
 1015808:	add    0x10(%rsi),%rdx
 101580c:	jae    101581f <map_prepare+0x3f>
 101580e:	jmp    1015979 <map_prepare+0x199>
 1015813:	xor    %eax,%eax
 1015815:	add    0x10(%rsi),%rdx
 1015819:	jb     1015979 <map_prepare+0x199>
 101581f:	mov    %rax,%r8
 1015822:	shr    $1,%r8
 1015825:	cmp    %r8,%rdx
 1015828:	jbe    1015974 <map_prepare+0x194>
 101582e:	test   %rax,%rax
 1015831:	mov    $0x20,%r14d
 1015837:	cmovne %rax,%r14
 101583b:	mov    %r14,%rax
 101583e:	shr    $1,%rax
 1015841:	cmp    %rax,%rdx
 1015844:	jbe    101586a <map_prepare+0x8a>
 1015846:	mov    %r14,%rax
 1015849:	nopl   0x0(%rax)
 1015850:	cmp    $0x7fffffff,%rax
 1015856:	ja     1015979 <map_prepare+0x199>
 101585c:	lea    (%rax,%rax,1),%r14
 1015860:	cmp    %rax,%rdx
 1015863:	mov    %r14,%rax
 1015866:	ja     1015850 <map_prepare+0x70>
 1015868:	jmp    1015877 <map_prepare+0x97>
 101586a:	mov    %r14,%rax
 101586d:	shr    $0x3c,%rax
 1015871:	jne    1015979 <map_prepare+0x199>
 1015877:	mov    %rsi,%r15
 101587a:	mov    %rcx,%r12
 101587d:	mov    %r14,%rsi
 1015880:	shl    $0x4,%rsi
 1015884:	call   1012690 <myl_rc_meta_alloc>
 1015889:	test   %rax,%rax
 101588c:	je     1015979 <map_prepare+0x199>
 1015892:	mov    $0x3f,%esi
 1015897:	cmp    $0x2,%r14
 101589b:	mov    %r12,%rcx
 101589e:	mov    %r15,%rdx
 10158a1:	jb     10158c9 <map_prepare+0xe9>
 10158a3:	mov    $0x40,%edi
 10158a8:	mov    %r14,%r8
 10158ab:	mov    %r14,%rsi
 10158ae:	xchg   %ax,%ax
 10158b0:	shr    $1,%rsi
 10158b3:	dec    %edi
 10158b5:	cmp    $0x3,%r8
 10158b9:	mov    %rsi,%r8
 10158bc:	ja     10158b0 <map_prepare+0xd0>
 10158be:	cmp    $0x3f,%edi
 10158c1:	mov    $0x3f,%esi
 10158c6:	cmovb  %edi,%esi
 10158c9:	mov    (%rdx),%rdi
 10158cc:	dec    %r14
 10158cf:	cmp    $0x10030a0,%rdi
 10158d6:	je     101596d <map_prepare+0x18d>
 10158dc:	xor    %r8d,%r8d
 10158df:	lea    -0x12846(%rip),%r9        # 10030a0 <myl_rc_map_sentinel>
 10158e6:	movabs $0x9e3779b97f4a7c15,%r10
 10158f0:	jmp    1015917 <map_prepare+0x137>
 10158f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015900:	add    %rax,%r15
 1015903:	vmovups (%rdi),%xmm0
 1015907:	vmovups %xmm0,(%r15)
 101590c:	mov    (%rdx),%rdi
 101590f:	inc    %r8
 1015912:	cmp    %r9,%rdi
 1015915:	je     101596d <map_prepare+0x18d>
 1015917:	mov    0x8(%rdx),%r11
 101591b:	inc    %r11
 101591e:	cmp    %r11,%r8
 1015921:	jae    101596d <map_prepare+0x18d>
 1015923:	mov    %r8,%rbx
 1015926:	shl    $0x4,%rbx
 101592a:	mov    (%rdi,%rbx,1),%r11
 101592e:	test   %r11,%r11
 1015931:	je     101590f <map_prepare+0x12f>
 1015933:	add    %rbx,%rdi
 1015936:	mov    %r11,%rbx
 1015939:	imul   %r10,%rbx
 101593d:	shrx   %rsi,%rbx,%rbx
 1015942:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015950:	and    %r14,%rbx
 1015953:	mov    %rbx,%r15
 1015956:	shl    $0x4,%r15
 101595a:	mov    (%rax,%r15,1),%r12
 101595e:	test   %r12,%r12
 1015961:	je     1015900 <map_prepare+0x120>
 1015963:	inc    %rbx
 1015966:	cmp    %r11,%r12
 1015969:	jne    1015950 <map_prepare+0x170>
 101596b:	jmp    1015900 <map_prepare+0x120>
 101596d:	mov    %rax,(%rcx)
 1015970:	mov    %r14,0x8(%rcx)
 1015974:	mov    $0x1,%ebx
 1015979:	mov    %ebx,%eax
 101597b:	pop    %rbx
 101597c:	pop    %r12
 101597e:	pop    %r14
 1015980:	pop    %r15
 1015982:	pop    %rbp
 1015983:	ret
 1015984:	int3
 1015985:	int3
 1015986:	int3
 1015987:	int3
 1015988:	int3
 1015989:	int3
 101598a:	int3
 101598b:	int3
 101598c:	int3
 101598d:	int3
 101598e:	int3
 101598f:	int3

0000000001015990 <walk>:
 1015990:	push   %rbp
 1015991:	mov    %rsp,%rbp
 1015994:	push   %r15
 1015996:	push   %r14
 1015998:	push   %r13
 101599a:	push   %r12
 101599c:	push   %rbx
 101599d:	push   %rax
 101599e:	mov    0x1608(%rdi),%rcx
 10159a5:	mov    0xc0(%rcx),%rax
 10159ac:	test   %rax,%rax
 10159af:	je     1015b8b <walk+0x1fb>
 10159b5:	mov    %esi,%ebx
 10159b7:	mov    %rdi,%r14
 10159ba:	lea    0xc0(%rcx),%rdx
 10159c1:	xor    %r15d,%r15d
 10159c4:	lea    -0x1291b(%rip),%r13        # 10030b0 <myl_rc_map_sentinel+0x10>
 10159cb:	mov    %esi,%r12d
 10159ce:	or     $0x2,%r12d
 10159d2:	jmp    1015a04 <walk+0x74>
 10159d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 10159e0:	dec    %rax
 10159e3:	mov    %rax,(%rdx)
 10159e6:	mov    0x1608(%r14),%rcx
 10159ed:	lea    0xc0(%rcx),%rdx
 10159f4:	mov    0xc0(%rcx),%rax
 10159fb:	test   %rax,%rax
 10159fe:	je     1015b8e <walk+0x1fe>
 1015a04:	mov    0xb0(%rcx),%rsi
 1015a0b:	lea    (%rax,%rax,2),%r8
 1015a0f:	mov    -0x18(%rsi,%r8,8),%rdi
 1015a14:	mov    0x8(%rdi),%r9d
 1015a18:	lea    -0x1(%r9),%r10d
 1015a1c:	cmp    $0x4,%r10d
 1015a20:	ja     1015ba0 <walk+0x210>
 1015a26:	lea    (%rsi,%r8,8),%rsi
 1015a2a:	movslq 0x0(%r13,%r10,4),%r8
 1015a2f:	add    %r13,%r8
 1015a32:	jmp    *%r8
 1015a35:	mov    -0x10(%rsi),%rdx
 1015a39:	mov    (%rdx),%rsi
 1015a3c:	cmp    $0x2,%ebx
 1015a3f:	jne    1015b3f <walk+0x1af>
 1015a45:	test   %rsi,%rsi
 1015a48:	je     1015a6e <walk+0xde>
 1015a4a:	mov    -0x10(%rsi),%rdx
 1015a4e:	mov    %rdx,%rsi
 1015a51:	shr    $0x28,%rsi
 1015a55:	and    $0xfffff,%esi
 1015a5b:	cmp    %r15d,%esi
 1015a5e:	cmovbe %r15d,%esi
 1015a62:	bt     $0x3e,%rdx
 1015a67:	cmovae %r15d,%esi
 1015a6b:	mov    %esi,%r15d
 1015a6e:	dec    %rax
 1015a71:	mov    %rax,0xc0(%rcx)
 1015a78:	jmp    10159e6 <walk+0x56>
 1015a7d:	nopl   (%rax)
 1015a80:	mov    -0x8(%rsi),%r10
 1015a84:	cmp    0x18(%rdi),%r10
 1015a88:	je     10159e0 <walk+0x50>
 1015a8e:	lea    (%r10,%r10,2),%r8
 1015a92:	shl    $0x3,%r8
 1015a96:	add    0x10(%rdi),%r8
 1015a9a:	inc    %r10
 1015a9d:	mov    %r10,-0x8(%rsi)
 1015aa1:	mov    -0x10(%rsi),%r10
 1015aa5:	cmp    $0x4,%r9d
 1015aa9:	jne    1015abd <walk+0x12d>
 1015aab:	mov    0x20(%rdi),%rdi
 1015aaf:	mov    0x10(%r8),%r9d
 1015ab3:	cmp    (%r10,%rdi,1),%r9d
 1015ab7:	jne    10159e6 <walk+0x56>
 1015abd:	mov    0x8(%r8),%rdi
 1015ac1:	cmpl   $0x0,0x8(%rdi)
 1015ac5:	je     10159e6 <walk+0x56>
 1015acb:	cmp    0xb8(%rcx),%rax
 1015ad2:	jae    1015ba0 <walk+0x210>
 1015ad8:	add    (%r8),%r10
 1015adb:	inc    %rax
 1015ade:	mov    %rax,(%rdx)
 1015ae1:	mov    %rdi,(%rsi)
 1015ae4:	mov    %r10,0x8(%rsi)
 1015ae8:	jmp    1015b32 <walk+0x1a2>
 1015aea:	mov    -0x8(%rsi),%r8
 1015aee:	cmp    0x18(%rdi),%r8
 1015af2:	je     10159e0 <walk+0x50>
 1015af8:	lea    0x1(%r8),%r9
 1015afc:	mov    %r9,-0x8(%rsi)
 1015b00:	mov    0x10(%rdi),%r9
 1015b04:	cmpl   $0x0,0x8(%r9)
 1015b09:	je     10159e6 <walk+0x56>
 1015b0f:	cmp    0xb8(%rcx),%rax
 1015b16:	jae    1015ba0 <walk+0x210>
 1015b1c:	imul   0x20(%rdi),%r8
 1015b21:	add    -0x10(%rsi),%r8
 1015b25:	inc    %rax
 1015b28:	mov    %rax,(%rdx)
 1015b2b:	mov    %r9,(%rsi)
 1015b2e:	mov    %r8,0x8(%rsi)
 1015b32:	movq   $0x0,0x10(%rsi)
 1015b3a:	jmp    10159e6 <walk+0x56>
 1015b3f:	movq   $0x0,(%rdx)
 1015b46:	mov    0x1608(%r14),%rax
 1015b4d:	decq   0xc0(%rax)
 1015b54:	cmp    $0x3,%r12d
 1015b58:	jne    10159e6 <walk+0x56>
 1015b5e:	cmp    $0x3,%ebx
 1015b61:	je     1015b76 <walk+0x1e6>
 1015b63:	cmpl   $0x5,0x8(%rdi)
 1015b67:	je     1015b76 <walk+0x1e6>
 1015b69:	mov    %r14,%rdi
 1015b6c:	call   1012bb0 <myl_rc_edge_release>
 1015b71:	jmp    10159e6 <walk+0x56>
 1015b76:	mov    %rsi,-0x30(%rbp)
 1015b7a:	mov    %r14,%rdi
 1015b7d:	lea    -0x30(%rbp),%rsi
 1015b81:	call   1012f20 <myl_rc_hold_release>
 1015b86:	jmp    10159e6 <walk+0x56>
 1015b8b:	xor    %r15d,%r15d
 1015b8e:	mov    %r15d,%eax
 1015b91:	add    $0x8,%rsp
 1015b95:	pop    %rbx
 1015b96:	pop    %r12
 1015b98:	pop    %r13
 1015b9a:	pop    %r14
 1015b9c:	pop    %r15
 1015b9e:	pop    %rbp
 1015b9f:	ret
 1015ba0:	call   101267d <myl_rc_invariant_failed>
 1015ba5:	int3
 1015ba6:	int3
 1015ba7:	int3
 1015ba8:	int3
 1015ba9:	int3
 1015baa:	int3
 1015bab:	int3
 1015bac:	int3
 1015bad:	int3
 1015bae:	int3
 1015baf:	int3

0000000001015bb0 <myl_rc_edges_release>:
 1015bb0:	push   %rbp
 1015bb1:	mov    %rsp,%rbp
 1015bb4:	push   %r15
 1015bb6:	push   %r14
 1015bb8:	push   %r13
 1015bba:	push   %r12
 1015bbc:	push   %rbx
 1015bbd:	push   %rax
 1015bbe:	test   %rdi,%rdi
 1015bc1:	je     1015db4 <myl_rc_edges_release+0x204>
 1015bc7:	mov    %rcx,%rbx
 1015bca:	mov    %rdi,%r15
 1015bcd:	mov    0x1608(%rdi),%rcx
 1015bd4:	test   %rcx,%rcx
 1015bd7:	je     1015db4 <myl_rc_edges_release+0x204>
 1015bdd:	cmpq   $0x0,0xc0(%rcx)
 1015be5:	jne    1015db4 <myl_rc_edges_release+0x204>
 1015beb:	mov    %rdx,%r14
 1015bee:	mov    0x58(%rcx),%rax
 1015bf2:	mov    0x60(%rcx),%rdx
 1015bf6:	movzbl 0x70(%rcx),%ecx
 1015bfa:	movabs $0x9e3779b97f4a7c15,%rdi
 1015c04:	imul   %rsi,%rdi
 1015c08:	shrx   %rcx,%rdi,%rcx
 1015c0d:	nopl   (%rax)
 1015c10:	and    %rdx,%rcx
 1015c13:	mov    %rcx,%rdi
 1015c16:	shl    $0x4,%rdi
 1015c1a:	mov    (%rax,%rdi,1),%rdi
 1015c1e:	cmp    %rsi,%rdi
 1015c21:	je     1015c31 <myl_rc_edges_release+0x81>
 1015c23:	test   %rdi,%rdi
 1015c26:	je     1015db4 <myl_rc_edges_release+0x204>
 1015c2c:	inc    %rcx
 1015c2f:	jmp    1015c10 <myl_rc_edges_release+0x60>
 1015c31:	shl    $0x4,%rcx
 1015c35:	mov    0x8(%rax,%rcx,1),%r12
 1015c3a:	test   %r12,%r12
 1015c3d:	je     1015db4 <myl_rc_edges_release+0x204>
 1015c43:	mov    %rbx,%rax
 1015c46:	mulq   (%r12)
 1015c4a:	jo     1015db4 <myl_rc_edges_release+0x204>
 1015c50:	test   %r14,%r14
 1015c53:	jne    1015c5e <myl_rc_edges_release+0xae>
 1015c55:	test   %rax,%rax
 1015c58:	jne    1015db4 <myl_rc_edges_release+0x204>
 1015c5e:	mov    0x8(%r12),%eax
 1015c63:	test   %eax,%eax
 1015c65:	je     1015da5 <myl_rc_edges_release+0x1f5>
 1015c6b:	cmp    $0x1,%eax
 1015c6e:	jne    1015c8b <myl_rc_edges_release+0xdb>
 1015c70:	test   %rbx,%rbx
 1015c73:	je     1015da5 <myl_rc_edges_release+0x1f5>
 1015c79:	xor    %r12d,%r12d
 1015c7c:	movabs $0x4000000000000002,%r13
 1015c86:	jmp    1015d48 <myl_rc_edges_release+0x198>
 1015c8b:	test   %rbx,%rbx
 1015c8e:	je     1015da5 <myl_rc_edges_release+0x1f5>
 1015c94:	mov    0x28(%r12),%r13
 1015c99:	jmp    1015cbd <myl_rc_edges_release+0x10d>
 1015c9b:	nopl   0x0(%rax,%rax,1)
 1015ca0:	mov    %r15,%rdi
 1015ca3:	mov    %r12,%rsi
 1015ca6:	mov    %r14,%rdx
 1015ca9:	xor    %ecx,%ecx
 1015cab:	call   1015dc0 <shallow_release>
 1015cb0:	add    (%r12),%r14
 1015cb4:	dec    %rbx
 1015cb7:	je     1015da5 <myl_rc_edges_release+0x1f5>
 1015cbd:	cmp    $0x2,%r13
 1015cc1:	jbe    1015ca0 <myl_rc_edges_release+0xf0>
 1015cc3:	cmpl   $0x0,0x8(%r12)
 1015cc9:	je     1015d0e <myl_rc_edges_release+0x15e>
 1015ccb:	mov    0x1608(%r15),%rax
 1015cd2:	mov    0xc0(%rax),%rcx
 1015cd9:	cmp    0xb8(%rax),%rcx
 1015ce0:	jae    1015db4 <myl_rc_edges_release+0x204>
 1015ce6:	mov    0xb0(%rax),%rdx
 1015ced:	lea    0x1(%rcx),%rsi
 1015cf1:	mov    %rsi,0xc0(%rax)
 1015cf8:	lea    (%rcx,%rcx,2),%rax
 1015cfc:	mov    %r12,(%rdx,%rax,8)
 1015d00:	mov    %r14,0x8(%rdx,%rax,8)
 1015d05:	movq   $0x0,0x10(%rdx,%rax,8)
 1015d0e:	mov    %r15,%rdi
 1015d11:	mov    $0x1,%esi
 1015d16:	call   1015990 <walk>
 1015d1b:	jmp    1015cb0 <myl_rc_edges_release+0x100>
 1015d1d:	mov    0xc8(%rax),%rax
 1015d24:	mov    %rax,(%rsi)
 1015d27:	mov    0x1608(%r15),%rax
 1015d2e:	mov    %rsi,0xc8(%rax)
 1015d35:	data16 cs nopw 0x0(%rax,%rax,1)
 1015d40:	inc    %r12
 1015d43:	cmp    %r12,%rbx
 1015d46:	je     1015da5 <myl_rc_edges_release+0x1f5>
 1015d48:	mov    (%r14,%r12,8),%rax
 1015d4c:	movq   $0x0,(%r14,%r12,8)
 1015d54:	test   %rax,%rax
 1015d57:	je     1015d40 <myl_rc_edges_release+0x190>
 1015d59:	mov    -0x10(%rax),%rcx
 1015d5d:	test   %r13,%rcx
 1015d60:	jne    1015d40 <myl_rc_edges_release+0x190>
 1015d62:	test   $0x1,%cl
 1015d65:	jne    1015db4 <myl_rc_edges_release+0x204>
 1015d67:	mov    -0x20(%rax),%rdx
 1015d6b:	test   %rdx,%rdx
 1015d6e:	je     1015db4 <myl_rc_edges_release+0x204>
 1015d70:	lea    -0x20(%rax),%rsi
 1015d74:	dec    %rdx
 1015d77:	mov    %rdx,(%rsi)
 1015d7a:	jne    1015d40 <myl_rc_edges_release+0x190>
 1015d7c:	cmpq   $0x0,-0x18(%rax)
 1015d81:	jne    1015d40 <myl_rc_edges_release+0x190>
 1015d83:	or     $0x1,%rcx
 1015d87:	mov    %rcx,-0x10(%rax)
 1015d8b:	mov    0x1608(%r15),%rax
 1015d92:	cmpl   $0x0,0xd0(%rax)
 1015d99:	jne    1015d1d <myl_rc_edges_release+0x16d>
 1015d9b:	mov    %r15,%rdi
 1015d9e:	call   1012b00 <myl_rc_dead_outside>
 1015da3:	jmp    1015d40 <myl_rc_edges_release+0x190>
 1015da5:	add    $0x8,%rsp
 1015da9:	pop    %rbx
 1015daa:	pop    %r12
 1015dac:	pop    %r13
 1015dae:	pop    %r14
 1015db0:	pop    %r15
 1015db2:	pop    %rbp
 1015db3:	ret
 1015db4:	call   101267d <myl_rc_invariant_failed>
 1015db9:	int3
 1015dba:	int3
 1015dbb:	int3
 1015dbc:	int3
 1015dbd:	int3
 1015dbe:	int3
 1015dbf:	int3

0000000001015dc0 <shallow_release>:
 1015dc0:	push   %rbp
 1015dc1:	mov    %rsp,%rbp
 1015dc4:	push   %r15
 1015dc6:	push   %r14
 1015dc8:	push   %r13
 1015dca:	push   %r12
 1015dcc:	push   %rbx
 1015dcd:	sub    $0x28,%rsp
 1015dd1:	mov    0x8(%rsi),%r10d
 1015dd5:	lea    -0x1(%r10),%eax
 1015dd9:	cmp    $0x4,%eax
 1015ddc:	ja     1015e35 <shallow_release+0x75>
 1015dde:	lea    -0x12d21(%rip),%r8        # 10030c4 <myl_rc_map_sentinel+0x24>
 1015de5:	movslq (%r8,%rax,4),%rax
 1015de9:	add    %r8,%rax
 1015dec:	jmp    *%rax
 1015dee:	mov    $0x1,%r13d
 1015df4:	jmp    1015e38 <shallow_release+0x78>
 1015df6:	mov    0x10(%rsi),%r12
 1015dfa:	mov    0x18(%rsi),%r13
 1015dfe:	mov    0x20(%rsi),%rbx
 1015e02:	add    %rdx,%rbx
 1015e05:	mov    $0x4,%r10d
 1015e0b:	xor    %r11d,%r11d
 1015e0e:	jmp    1015e40 <shallow_release+0x80>
 1015e10:	mov    0x10(%rsi),%r12
 1015e14:	mov    0x18(%rsi),%r13
 1015e18:	mov    $0x2,%r10d
 1015e1e:	xor    %r11d,%r11d
 1015e21:	jmp    1015e3e <shallow_release+0x7e>
 1015e23:	mov    0x10(%rsi),%rax
 1015e27:	mov    0x18(%rsi),%r13
 1015e2b:	mov    0x20(%rsi),%r11
 1015e2f:	mov    0x8(%rax),%r10d
 1015e33:	jmp    1015e3b <shallow_release+0x7b>
 1015e35:	xor    %r13d,%r13d
 1015e38:	xor    %r11d,%r11d
 1015e3b:	xor    %r12d,%r12d
 1015e3e:	xor    %ebx,%ebx
 1015e40:	movabs $0x4000000000000002,%r9
 1015e4a:	mov    %r13,%r15
 1015e4d:	neg    %r15
 1015e50:	xor    %r14d,%r14d
 1015e53:	test   %r12,%r12
 1015e56:	je     1015ec0 <shallow_release+0x100>
 1015e58:	cmp    %r13,%r14
 1015e5b:	jae    1016040 <shallow_release+0x280>
 1015e61:	lea    (%r14,%r14,2),%rax
 1015e65:	lea    0x10(%r12),%rsi
 1015e6a:	lea    (%rsi,%rax,8),%rax
 1015e6e:	inc    %r14
 1015e71:	jmp    1015e98 <shallow_release+0xd8>
 1015e73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1015e80:	add    $0x18,%rax
 1015e84:	lea    (%r15,%r14,1),%rsi
 1015e88:	inc    %rsi
 1015e8b:	inc    %r14
 1015e8e:	cmp    $0x1,%rsi
 1015e92:	je     1016040 <shallow_release+0x280>
 1015e98:	mov    -0x8(%rax),%rsi
 1015e9c:	mov    0x8(%rsi),%r8d
 1015ea0:	test   %r8d,%r8d
 1015ea3:	je     1015e80 <shallow_release+0xc0>
 1015ea5:	test   %rbx,%rbx
 1015ea8:	je     1015eb0 <shallow_release+0xf0>
 1015eaa:	mov    (%rax),%esi
 1015eac:	cmp    (%rbx),%esi
 1015eae:	jne    1015e80 <shallow_release+0xc0>
 1015eb0:	mov    -0x10(%rax),%rax
 1015eb4:	jmp    1015ed6 <shallow_release+0x116>
 1015eb6:	cs nopw 0x0(%rax,%rax,1)
 1015ec0:	cmp    %r13,%r14
 1015ec3:	je     1016040 <shallow_release+0x280>
 1015ec9:	mov    %r14,%rax
 1015ecc:	inc    %r14
 1015ecf:	imul   %r11,%rax
 1015ed3:	mov    %r10d,%r8d
 1015ed6:	mov    (%rdx,%rax,1),%rsi
 1015eda:	movq   $0x0,(%rdx,%rax,1)
 1015ee2:	test   %ecx,%ecx
 1015ee4:	jne    1015f80 <shallow_release+0x1c0>
 1015eea:	cmp    $0x5,%r8d
 1015eee:	je     1015f80 <shallow_release+0x1c0>
 1015ef4:	test   %rsi,%rsi
 1015ef7:	je     1015e53 <shallow_release+0x93>
 1015efd:	mov    -0x10(%rsi),%r8
 1015f01:	test   %r9,%r8
 1015f04:	jne    1015e53 <shallow_release+0x93>
 1015f0a:	test   $0x1,%r8b
 1015f0e:	jne    101604f <shallow_release+0x28f>
 1015f14:	mov    -0x20(%rsi),%r9
 1015f18:	test   %r9,%r9
 1015f1b:	je     101604f <shallow_release+0x28f>
 1015f21:	lea    -0x20(%rsi),%rax
 1015f25:	dec    %r9
 1015f28:	mov    %r9,(%rax)
 1015f2b:	movabs $0x4000000000000002,%r9
 1015f35:	jne    1015e53 <shallow_release+0x93>
 1015f3b:	cmpq   $0x0,-0x18(%rsi)
 1015f40:	jne    1015e53 <shallow_release+0x93>
 1015f46:	or     $0x1,%r8
 1015f4a:	mov    %r8,-0x10(%rsi)
 1015f4e:	mov    0x1608(%rdi),%rsi
 1015f55:	cmpl   $0x0,0xd0(%rsi)
 1015f5c:	je     1015fff <shallow_release+0x23f>
 1015f62:	mov    0xc8(%rsi),%rsi
 1015f69:	mov    %rsi,(%rax)
 1015f6c:	mov    0x1608(%rdi),%rsi
 1015f73:	mov    %rax,0xc8(%rsi)
 1015f7a:	jmp    1015e53 <shallow_release+0x93>
 1015f7f:	nop
 1015f80:	test   %rsi,%rsi
 1015f83:	je     1015e53 <shallow_release+0x93>
 1015f89:	mov    -0x10(%rsi),%rax
 1015f8d:	test   %r9,%rax
 1015f90:	jne    1015e53 <shallow_release+0x93>
 1015f96:	test   $0x1,%al
 1015f98:	jne    101604f <shallow_release+0x28f>
 1015f9e:	mov    -0x18(%rsi),%r8
 1015fa2:	test   %r8,%r8
 1015fa5:	je     101604f <shallow_release+0x28f>
 1015fab:	dec    %r8
 1015fae:	mov    %r8,-0x18(%rsi)
 1015fb2:	or     -0x20(%rsi),%r8
 1015fb6:	jne    1015e53 <shallow_release+0x93>
 1015fbc:	or     $0x1,%rax
 1015fc0:	mov    %rax,-0x10(%rsi)
 1015fc4:	add    $0xffffffffffffffe0,%rsi
 1015fc8:	mov    0x1608(%rdi),%rax
 1015fcf:	cmpl   $0x0,0xd0(%rax)
 1015fd6:	je     1015ff5 <shallow_release+0x235>
 1015fd8:	mov    0xc8(%rax),%rax
 1015fdf:	mov    %rax,(%rsi)
 1015fe2:	mov    0x1608(%rdi),%rax
 1015fe9:	mov    %rsi,0xc8(%rax)
 1015ff0:	jmp    1015e53 <shallow_release+0x93>
 1015ff5:	mov    %rdi,-0x38(%rbp)
 1015ff9:	mov    -0x38(%rbp),%rdi
 1015ffd:	jmp    101600a <shallow_release+0x24a>
 1015fff:	mov    %rdi,-0x38(%rbp)
 1016003:	mov    -0x38(%rbp),%rdi
 1016007:	mov    %rax,%rsi
 101600a:	mov    %ecx,-0x2c(%rbp)
 101600d:	mov    %rdx,-0x50(%rbp)
 1016011:	mov    %r10,-0x48(%rbp)
 1016015:	mov    %r11,-0x40(%rbp)
 1016019:	call   1012b00 <myl_rc_dead_outside>
 101601e:	movabs $0x4000000000000002,%r9
 1016028:	mov    -0x40(%rbp),%r11
 101602c:	mov    -0x48(%rbp),%r10
 1016030:	mov    -0x38(%rbp),%rdi
 1016034:	mov    -0x50(%rbp),%rdx
 1016038:	mov    -0x2c(%rbp),%ecx
 101603b:	jmp    1015e53 <shallow_release+0x93>
 1016040:	add    $0x28,%rsp
 1016044:	pop    %rbx
 1016045:	pop    %r12
 1016047:	pop    %r13
 1016049:	pop    %r14
 101604b:	pop    %r15
 101604d:	pop    %rbp
 101604e:	ret
 101604f:	call   101267d <myl_rc_invariant_failed>
 1016054:	int3
 1016055:	int3
 1016056:	int3
 1016057:	int3
 1016058:	int3
 1016059:	int3
 101605a:	int3
 101605b:	int3
 101605c:	int3
 101605d:	int3
 101605e:	int3
 101605f:	int3

0000000001016060 <myl_rc_flat_edges_release>:
 1016060:	push   %rbp
 1016061:	mov    %rsp,%rbp
 1016064:	push   %r15
 1016066:	push   %r14
 1016068:	push   %r13
 101606a:	push   %r12
 101606c:	push   %rbx
 101606d:	sub    $0x18,%rsp
 1016071:	test   %rdi,%rdi
 1016074:	je     101620a <myl_rc_flat_edges_release+0x1aa>
 101607a:	mov    0x1608(%rdi),%rax
 1016081:	test   %rax,%rax
 1016084:	je     101620a <myl_rc_flat_edges_release+0x1aa>
 101608a:	cmpq   $0x0,0xc0(%rax)
 1016092:	jne    101620a <myl_rc_flat_edges_release+0x1aa>
 1016098:	mov    %rsi,%r15
 101609b:	mov    0x40(%rsi),%esi
 101609e:	cmp    $0x11,%esi
 10160a1:	jae    101620a <myl_rc_flat_edges_release+0x1aa>
 10160a7:	mov    %rdx,%r14
 10160aa:	mov    0x50(%r15),%r8
 10160ae:	mov    %r8,%rax
 10160b1:	mul    %rcx
 10160b4:	jo     101620a <myl_rc_flat_edges_release+0x1aa>
 10160ba:	test   %rax,%rax
 10160bd:	sete   %al
 10160c0:	test   %r14,%r14
 10160c3:	setne  %dl
 10160c6:	or     %al,%dl
 10160c8:	je     101620a <myl_rc_flat_edges_release+0x1aa>
 10160ce:	test   %esi,%esi
 10160d0:	sete   %al
 10160d3:	test   %rcx,%rcx
 10160d6:	sete   %dl
 10160d9:	or     %al,%dl
 10160db:	jne    10161fb <myl_rc_flat_edges_release+0x19b>
 10160e1:	lea    0x5c(%r15),%r9
 10160e5:	lea    0x5a(%r15),%r10
 10160e9:	lea    0x58(%r15),%r11
 10160ed:	xor    %r13d,%r13d
 10160f0:	movabs $0x4000000000000002,%rbx
 10160fa:	mov    %rcx,-0x38(%rbp)
 10160fe:	mov    %rdi,-0x30(%rbp)
 1016102:	jmp    1016123 <myl_rc_flat_edges_release+0xc3>
 1016104:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016110:	mov    0x50(%r15),%r8
 1016114:	add    %r8,%r14
 1016117:	inc    %r13
 101611a:	cmp    %rcx,%r13
 101611d:	je     10161fb <myl_rc_flat_edges_release+0x19b>
 1016123:	cmpb   $0x0,0x46(%r15)
 1016128:	mov    %r11,%rax
 101612b:	je     1016141 <myl_rc_flat_edges_release+0xe1>
 101612d:	mov    0x48(%r15),%eax
 1016131:	mov    (%r14,%rax,1),%eax
 1016135:	cmp    $0x20,%rax
 1016139:	lea    (%r9,%rax,2),%rax
 101613d:	cmovae %r10,%rax
 1016141:	movzwl (%rax),%r12d
 1016145:	test   %r12d,%r12d
 1016148:	jne    1016177 <myl_rc_flat_edges_release+0x117>
 101614a:	jmp    1016114 <myl_rc_flat_edges_release+0xb4>
 101614c:	mov    0xc8(%rax),%rax
 1016153:	mov    %rax,(%rsi)
 1016156:	mov    0x1608(%rdi),%rax
 101615d:	mov    %rsi,0xc8(%rax)
 1016164:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016170:	blsr   %r12d,%r12d
 1016175:	je     1016110 <myl_rc_flat_edges_release+0xb0>
 1016177:	tzcnt  %r12d,%eax
 101617c:	movzwl 0x9c(%r15,%rax,2),%edx
 1016185:	mov    (%r14,%rdx,1),%rax
 1016189:	movq   $0x0,(%r14,%rdx,1)
 1016191:	test   %rax,%rax
 1016194:	je     1016170 <myl_rc_flat_edges_release+0x110>
 1016196:	mov    -0x10(%rax),%r8
 101619a:	test   %rbx,%r8
 101619d:	jne    1016170 <myl_rc_flat_edges_release+0x110>
 101619f:	test   $0x1,%r8b
 10161a3:	jne    101620a <myl_rc_flat_edges_release+0x1aa>
 10161a5:	mov    -0x20(%rax),%rdx
 10161a9:	test   %rdx,%rdx
 10161ac:	je     101620a <myl_rc_flat_edges_release+0x1aa>
 10161ae:	lea    -0x20(%rax),%rsi
 10161b2:	dec    %rdx
 10161b5:	mov    %rdx,(%rsi)
 10161b8:	jne    1016170 <myl_rc_flat_edges_release+0x110>
 10161ba:	cmpq   $0x0,-0x18(%rax)
 10161bf:	jne    1016170 <myl_rc_flat_edges_release+0x110>
 10161c1:	or     $0x1,%r8
 10161c5:	mov    %r8,-0x10(%rax)
 10161c9:	mov    0x1608(%rdi),%rax
 10161d0:	cmpl   $0x0,0xd0(%rax)
 10161d7:	jne    101614c <myl_rc_flat_edges_release+0xec>
 10161dd:	call   1012b00 <myl_rc_dead_outside>
 10161e2:	lea    0x58(%r15),%r11
 10161e6:	lea    0x5a(%r15),%r10
 10161ea:	lea    0x5c(%r15),%r9
 10161ee:	mov    -0x30(%rbp),%rdi
 10161f2:	mov    -0x38(%rbp),%rcx
 10161f6:	jmp    1016170 <myl_rc_flat_edges_release+0x110>
 10161fb:	add    $0x18,%rsp
 10161ff:	pop    %rbx
 1016200:	pop    %r12
 1016202:	pop    %r13
 1016204:	pop    %r14
 1016206:	pop    %r15
 1016208:	pop    %rbp
 1016209:	ret
 101620a:	call   101267d <myl_rc_invariant_failed>
 101620f:	int3

0000000001016210 <myl_rc_drain>:
 1016210:	push   %rbp
 1016211:	mov    %rsp,%rbp
 1016214:	push   %r15
 1016216:	push   %r14
 1016218:	push   %r13
 101621a:	push   %r12
 101621c:	push   %rbx
 101621d:	sub    $0x48,%rsp
 1016221:	test   %rdi,%rdi
 1016224:	je     1016342 <myl_rc_drain+0x132>
 101622a:	mov    %rdi,%rbx
 101622d:	mov    0x1608(%rdi),%r13
 1016234:	test   %r13,%r13
 1016237:	je     1016342 <myl_rc_drain+0x132>
 101623d:	mov    0xc8(%r13),%rax
 1016244:	test   %rax,%rax
 1016247:	je     1016333 <myl_rc_drain+0x123>
 101624d:	cmpl   $0x0,0xd0(%r13)
 1016255:	jne    1016333 <myl_rc_drain+0x123>
 101625b:	cmpq   $0x0,0xc0(%r13)
 1016263:	jne    1016333 <myl_rc_drain+0x123>
 1016269:	movl   $0x1,0xd0(%r13)
 1016274:	mov    0x8(%r13),%rcx
 1016278:	xor    %r14d,%r14d
 101627b:	cmp    $0x101c550,%rcx
 1016282:	sete   %r14b
 1016286:	vxorps %xmm0,%xmm0,%xmm0
 101628a:	vmovups %ymm0,-0x48(%rbp)
 101628f:	vmovups %ymm0,-0x60(%rbp)
 1016294:	mov    %rax,-0x68(%rbp)
 1016298:	movq   $0xffffffffffffffff,-0x48(%rbp)
 10162a0:	lea    -0x68(%rbp),%rsi
 10162a4:	mov    %rbx,%rdi
 10162a7:	mov    %r14d,%edx
 10162aa:	vzeroupper
 10162ad:	call   1016350 <drain_fast>
 10162b2:	test   %rax,%rax
 10162b5:	je     10162e9 <myl_rc_drain+0xd9>
 10162b7:	lea    -0x38(%rbp),%r15
 10162bb:	lea    -0x68(%rbp),%r12
 10162bf:	nop
 10162c0:	mov    -0x68(%rbp),%rdx
 10162c4:	mov    %rbx,%rdi
 10162c7:	mov    %rax,%rsi
 10162ca:	mov    %r15,%rcx
 10162cd:	call   1016680 <drain_one>
 10162d2:	mov    %rax,-0x68(%rbp)
 10162d6:	mov    %rbx,%rdi
 10162d9:	mov    %r12,%rsi
 10162dc:	mov    %r14d,%edx
 10162df:	call   1016350 <drain_fast>
 10162e4:	test   %rax,%rax
 10162e7:	jne    10162c0 <myl_rc_drain+0xb0>
 10162e9:	movq   $0x0,0xc8(%r13)
 10162f4:	mov    -0x38(%rbp),%rax
 10162f8:	test   %rax,%rax
 10162fb:	je     1016328 <myl_rc_drain+0x118>
 10162fd:	mov    0x40(%rbx),%rcx
 1016301:	sub    %rax,%rcx
 1016304:	jb     1016342 <myl_rc_drain+0x132>
 1016306:	mov    %rcx,0x40(%rbx)
 101630a:	add    0x50(%rbx),%rax
 101630e:	mov    $0xffffffffffffffff,%rcx
 1016315:	cmovae %rax,%rcx
 1016319:	mov    %rcx,0x50(%rbx)
 101631d:	mov    -0x30(%rbp),%rax
 1016321:	add    %rax,0x1710(%rbx)
 1016328:	movl   $0x0,0xd0(%r13)
 1016333:	add    $0x48,%rsp
 1016337:	pop    %rbx
 1016338:	pop    %r12
 101633a:	pop    %r13
 101633c:	pop    %r14
 101633e:	pop    %r15
 1016340:	pop    %rbp
 1016341:	ret
 1016342:	call   101267d <myl_rc_invariant_failed>
 1016347:	int3
 1016348:	int3
 1016349:	int3
 101634a:	int3
 101634b:	int3
 101634c:	int3
 101634d:	int3
 101634e:	int3
 101634f:	int3

0000000001016350 <drain_fast>:
 1016350:	push   %rbp
 1016351:	mov    %rsp,%rbp
 1016354:	push   %r15
 1016356:	push   %r14
 1016358:	push   %r13
 101635a:	push   %r12
 101635c:	push   %rbx
 101635d:	sub    $0x48,%rsp
 1016361:	mov    %rsi,%rax
 1016364:	mov    (%rsi),%rsi
 1016367:	mov    0x8(%rax),%rcx
 101636b:	mov    %rcx,-0x40(%rbp)
 101636f:	mov    0x10(%rax),%r14
 1016373:	mov    0x18(%rax),%r11
 1016377:	mov    0x20(%rax),%r15
 101637b:	mov    0x28(%rax),%ebx
 101637e:	vmovdqu 0x30(%rax),%xmm1
 1016383:	test   %rsi,%rsi
 1016386:	je     1016643 <drain_fast+0x2f3>
 101638c:	mov    %edx,%r10d
 101638f:	mov    %rdi,%r12
 1016392:	mov    %rax,-0x48(%rbp)
 1016396:	vmovdqa -0x1354e(%rip),%xmm2        # 1002e50 <qbe_empty_registry+0xa8>
 101639e:	movabs $0x4000000000000003,%r13
 10163a8:	mov    %rdi,-0x58(%rbp)
 10163ac:	jmp    10163fc <drain_fast+0xac>
 10163ae:	xchg   %ax,%ax
 10163b0:	vmovdqa %xmm1,-0x70(%rbp)
 10163b5:	mov    %r12,%rdi
 10163b8:	mov    %r14,%rcx
 10163bb:	lea    -0x70(%rbp),%r8
 10163bf:	mov    %ebx,-0x4c(%rbp)
 10163c2:	mov    %r10d,%ebx
 10163c5:	mov    %r15,%r12
 10163c8:	mov    %r11,%r15
 10163cb:	call   1017050 <drain_pairs>
 10163d0:	mov    %r15,%r11
 10163d3:	mov    %r12,%r15
 10163d6:	mov    -0x58(%rbp),%r12
 10163da:	vmovdqa -0x13592(%rip),%xmm2        # 1002e50 <qbe_empty_registry+0xa8>
 10163e2:	mov    %ebx,%r10d
 10163e5:	mov    -0x4c(%rbp),%ebx
 10163e8:	mov    %rax,%rdx
 10163eb:	vmovdqa -0x70(%rbp),%xmm1
 10163f0:	mov    %rdx,%rsi
 10163f3:	test   %rdx,%rdx
 10163f6:	je     1016639 <drain_fast+0x2e9>
 10163fc:	mov    (%rsi),%rdx
 10163ff:	mov    0x18(%rsi),%rcx
 1016403:	cmp    -0x40(%rbp),%rcx
 1016407:	je     10164f3 <drain_fast+0x1a3>
 101640d:	mov    0x1608(%r12),%r8
 1016415:	mov    0xd8(%r8),%rax
 101641c:	cmp    %rcx,%rax
 101641f:	je     1016470 <drain_fast+0x120>
 1016421:	cmp    %rcx,0xe0(%r8)
 1016428:	je     1016479 <drain_fast+0x129>
 101642a:	mov    0x34(%rcx),%eax
 101642d:	cmp    %rax,0xa0(%r8)
 1016434:	jbe    1016605 <drain_fast+0x2b5>
 101643a:	mov    0x98(%r8),%rdi
 1016441:	shl    $0x4,%rax
 1016445:	cmp    %rcx,(%rdi,%rax,1)
 1016449:	jne    1016605 <drain_fast+0x2b5>
 101644f:	add    %rax,%rdi
 1016452:	mov    0x8(%rdi),%r14
 1016456:	test   %r14,%r14
 1016459:	je     1016634 <drain_fast+0x2e4>
 101645f:	add    $0x40,%r14
 1016463:	mov    0xd8(%r8),%rax
 101646a:	jmp    1016480 <drain_fast+0x130>
 101646c:	nopl   0x0(%rax)
 1016470:	mov    0xe8(%r8),%r14
 1016477:	jmp    10164a3 <drain_fast+0x153>
 1016479:	mov    0xf0(%r8),%r14
 1016480:	mov    %rax,0xe0(%r8)
 1016487:	mov    0xe8(%r8),%rax
 101648e:	mov    %rax,0xf0(%r8)
 1016495:	mov    %rcx,0xd8(%r8)
 101649c:	mov    %r14,0xe8(%r8)
 10164a3:	mov    (%r14),%eax
 10164a6:	test   %eax,%eax
 10164a8:	je     10164c0 <drain_fast+0x170>
 10164aa:	movzwl 0x18(%r14),%ebx
 10164af:	movabs $0xcfffffffffffffff,%r11
 10164b9:	test   %r10d,%r10d
 10164bc:	jne    10164d1 <drain_fast+0x181>
 10164be:	jmp    10164e8 <drain_fast+0x198>
 10164c0:	xor    %ebx,%ebx
 10164c2:	movabs $0xc000000000000003,%r11
 10164cc:	test   %r10d,%r10d
 10164cf:	je     10164e8 <drain_fast+0x198>
 10164d1:	cmp    $0x10,%eax
 10164d4:	ja     10164e8 <drain_fast+0x198>
 10164d6:	xor    %edi,%edi
 10164d8:	test   %eax,%eax
 10164da:	setne  %al
 10164dd:	cmpb   $0x0,0x6(%r14)
 10164e2:	je     10165f5 <drain_fast+0x2a5>
 10164e8:	mov    $0xffffffffffffffff,%r15
 10164ef:	mov    %rcx,-0x40(%rbp)
 10164f3:	mov    0x10(%rsi),%rax
 10164f7:	and    %r11,%rax
 10164fa:	cmp    %r15,%rax
 10164fd:	jne    101663d <drain_fast+0x2ed>
 1016503:	cmp    $0x3,%ebx
 1016506:	je     10163b0 <drain_fast+0x60>
 101650c:	nopl   0x0(%rax)
 1016510:	test   %ebx,%ebx
 1016512:	je     1016590 <drain_fast+0x240>
 1016514:	mov    %ebx,%eax
 1016516:	jmp    1016531 <drain_fast+0x1e1>
 1016518:	nopl   0x0(%rax,%rax,1)
 1016520:	test   $0x1,%r9b
 1016524:	jne    1016634 <drain_fast+0x2e4>
 101652a:	blsr   %eax,%eax
 101652f:	je     1016590 <drain_fast+0x240>
 1016531:	tzcnt  %eax,%ecx
 1016535:	movzwl 0x5c(%r14,%rcx,2),%ecx
 101653b:	mov    0x20(%rsi,%rcx,1),%r8
 1016540:	test   %r8,%r8
 1016543:	je     101652a <drain_fast+0x1da>
 1016545:	mov    -0x10(%r8),%r9
 1016549:	test   %r13,%r9
 101654c:	jne    1016520 <drain_fast+0x1d0>
 101654e:	lea    -0x20(%r8),%rcx
 1016552:	mov    (%rcx),%rdi
 1016555:	cmp    $0x1,%rdi
 1016559:	je     1016565 <drain_fast+0x215>
 101655b:	test   %rdi,%rdi
 101655e:	jne    101656c <drain_fast+0x21c>
 1016560:	jmp    1016634 <drain_fast+0x2e4>
 1016565:	cmpq   $0x0,-0x18(%r8)
 101656a:	je     1016574 <drain_fast+0x224>
 101656c:	dec    %rdi
 101656f:	mov    %rdi,(%rcx)
 1016572:	jmp    101652a <drain_fast+0x1da>
 1016574:	or     $0x1,%r9
 1016578:	mov    %r9,-0x10(%r8)
 101657c:	mov    %rdx,%rdi
 101657f:	mov    %rcx,%rdx
 1016582:	jmp    101656f <drain_fast+0x21f>
 1016584:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016590:	mov    %rsi,%rax
 1016593:	and    $0xffffffffffff0000,%rax
 1016599:	mov    (%rax),%rcx
 101659c:	movq   $0x3,0x10(%rsi)
 10165a4:	mov    0x1610(%r12,%rcx,8),%rdi
 10165ac:	mov    %rdi,(%rsi)
 10165af:	mov    %rsi,0x1610(%r12,%rcx,8)
 10165b7:	vpinsrq $0x1,0x8(%rax),%xmm2,%xmm0
 10165be:	vpaddq %xmm1,%xmm0,%xmm1
 10165c2:	test   %rdx,%rdx
 10165c5:	je     1016639 <drain_fast+0x2e9>
 10165c7:	mov    -0x40(%rbp),%rax
 10165cb:	cmp    %rax,0x18(%rdx)
 10165cf:	jne    10163f0 <drain_fast+0xa0>
 10165d5:	mov    0x10(%rdx),%rax
 10165d9:	and    %r11,%rax
 10165dc:	cmp    %r15,%rax
 10165df:	jne    10163f0 <drain_fast+0xa0>
 10165e5:	mov    %rdx,%rsi
 10165e8:	mov    (%rdx),%rdx
 10165eb:	test   %ebx,%ebx
 10165ed:	jne    1016514 <drain_fast+0x1c4>
 10165f3:	jmp    1016590 <drain_fast+0x240>
 10165f5:	mov    %al,%dil
 10165f8:	lea    0x1(,%rdi,4),%r15
 1016600:	jmp    10164ef <drain_fast+0x19f>
 1016605:	mov    %r12,%rdi
 1016608:	mov    %rsi,%r9
 101660b:	mov    %rcx,%rsi
 101660e:	vmovdqa %xmm1,-0x40(%rbp)
 1016613:	call   10130fa <myl_rc_binding_find_slow>
 1016618:	vmovdqa -0x137d0(%rip),%xmm2        # 1002e50 <qbe_empty_registry+0xa8>
 1016620:	vmovdqa -0x40(%rbp),%xmm1
 1016625:	mov    %r9,%rsi
 1016628:	mov    %rax,%r14
 101662b:	test   %r14,%r14
 101662e:	jne    101645f <drain_fast+0x10f>
 1016634:	call   101267d <myl_rc_invariant_failed>
 1016639:	xor    %esi,%esi
 101663b:	xor    %edx,%edx
 101663d:	mov    -0x48(%rbp),%rax
 1016641:	jmp    1016647 <drain_fast+0x2f7>
 1016643:	xor    %esi,%esi
 1016645:	xor    %edx,%edx
 1016647:	mov    %rdx,(%rax)
 101664a:	mov    -0x40(%rbp),%rcx
 101664e:	mov    %rcx,0x8(%rax)
 1016652:	mov    %r14,0x10(%rax)
 1016656:	mov    %r11,0x18(%rax)
 101665a:	mov    %r15,0x20(%rax)
 101665e:	mov    %ebx,0x28(%rax)
 1016661:	movl   $0x0,0x2c(%rax)
 1016668:	vmovdqu %xmm1,0x30(%rax)
 101666d:	mov    %rsi,%rax
 1016670:	add    $0x48,%rsp
 1016674:	pop    %rbx
 1016675:	pop    %r12
 1016677:	pop    %r13
 1016679:	pop    %r14
 101667b:	pop    %r15
 101667d:	pop    %rbp
 101667e:	ret
 101667f:	int3

0000000001016680 <drain_one>:
 1016680:	push   %rbp
 1016681:	mov    %rsp,%rbp
 1016684:	push   %r15
 1016686:	push   %r14
 1016688:	push   %r13
 101668a:	push   %r12
 101668c:	push   %rbx
 101668d:	push   %rax
 101668e:	mov    %rsi,%r14
 1016691:	mov    %rdi,%rbx
 1016694:	mov    0x1608(%rdi),%r8
 101669b:	mov    %rdx,0xc8(%r8)
 10166a2:	mov    (%rcx),%rax
 10166a5:	mov    %r8,%rdx
 10166a8:	test   %rax,%rax
 10166ab:	je     10166eb <drain_one+0x6b>
 10166ad:	mov    0x40(%rbx),%rdx
 10166b1:	sub    %rax,%rdx
 10166b4:	jb     1016a09 <drain_one+0x389>
 10166ba:	mov    %rdx,0x40(%rbx)
 10166be:	add    0x50(%rbx),%rax
 10166c2:	mov    $0xffffffffffffffff,%rdx
 10166c9:	cmovae %rax,%rdx
 10166cd:	mov    %rdx,0x50(%rbx)
 10166d1:	mov    0x8(%rcx),%rax
 10166d5:	add    %rax,0x1710(%rbx)
 10166dc:	vxorps %xmm0,%xmm0,%xmm0
 10166e0:	vmovups %xmm0,(%rcx)
 10166e4:	mov    0x1608(%rbx),%rdx
 10166eb:	mov    0x18(%r14),%rsi
 10166ef:	mov    0xd8(%rdx),%rcx
 10166f6:	cmp    %rsi,%rcx
 10166f9:	je     1016746 <drain_one+0xc6>
 10166fb:	cmp    %rsi,0xe0(%rdx)
 1016702:	je     101674f <drain_one+0xcf>
 1016704:	mov    0x34(%rsi),%eax
 1016707:	cmp    %rax,0xa0(%rdx)
 101670e:	jbe    10169e2 <drain_one+0x362>
 1016714:	mov    0x98(%rdx),%rcx
 101671b:	shl    $0x4,%rax
 101671f:	cmp    %rsi,(%rcx,%rax,1)
 1016723:	jne    10169e2 <drain_one+0x362>
 1016729:	add    %rax,%rcx
 101672c:	mov    0x8(%rcx),%rax
 1016730:	test   %rax,%rax
 1016733:	je     1016a09 <drain_one+0x389>
 1016739:	add    $0x40,%rax
 101673d:	mov    0xd8(%rdx),%rcx
 1016744:	jmp    1016756 <drain_one+0xd6>
 1016746:	mov    0xe8(%rdx),%rax
 101674d:	jmp    1016779 <drain_one+0xf9>
 101674f:	mov    0xf0(%rdx),%rax
 1016756:	mov    %rcx,0xe0(%rdx)
 101675d:	mov    0xe8(%rdx),%rcx
 1016764:	mov    %rcx,0xf0(%rdx)
 101676b:	mov    %rsi,0xd8(%rdx)
 1016772:	mov    %rax,0xe8(%rdx)
 1016779:	mov    %r8,-0x30(%rbp)
 101677d:	movabs $0x4000000000000003,%r13
 1016787:	mov    0x10(%r14),%rcx
 101678b:	mov    %rcx,%rdx
 101678e:	and    %r13,%rdx
 1016791:	cmp    $0x1,%rdx
 1016795:	jne    1016a09 <drain_one+0x389>
 101679b:	lea    0x20(%r14),%r15
 101679f:	lea    -0x40(%rax),%rsi
 10167a3:	mov    $0x3c,%edx
 10167a8:	bzhi   %rdx,%rcx,%r12
 10167ad:	shr    $0x2,%r12
 10167b1:	cmpl   $0x10,(%rax)
 10167b4:	ja     10167e7 <drain_one+0x167>
 10167b6:	cmp    $0x1,%r12
 10167ba:	jne    1016860 <drain_one+0x1e0>
 10167c0:	cmpb   $0x0,0x6(%rax)
 10167c4:	je     1016896 <drain_one+0x216>
 10167ca:	mov    0x8(%rax),%ecx
 10167cd:	mov    (%r15,%rcx,1),%ecx
 10167d1:	lea    0x1a(%rax),%rdx
 10167d5:	cmp    $0x20,%rcx
 10167d9:	lea    0x1c(%rax,%rcx,2),%rcx
 10167de:	cmovae %rdx,%rcx
 10167e2:	jmp    101689a <drain_one+0x21a>
 10167e7:	mov    -0x28(%rax),%rax
 10167eb:	test   %rax,%rax
 10167ee:	je     1016838 <drain_one+0x1b8>
 10167f0:	mov    %rbx,%rdi
 10167f3:	mov    %r15,%rsi
 10167f6:	call   *%rax
 10167f8:	mov    0x18(%r14),%rsi
 10167fc:	mov    0x1608(%rbx),%rcx
 1016803:	mov    0x34(%rsi),%eax
 1016806:	cmp    %rax,0xa0(%rcx)
 101680d:	jbe    10169f5 <drain_one+0x375>
 1016813:	mov    0x98(%rcx),%rcx
 101681a:	shl    $0x4,%rax
 101681e:	cmp    %rsi,(%rcx,%rax,1)
 1016822:	jne    10169f5 <drain_one+0x375>
 1016828:	add    %rax,%rcx
 101682b:	mov    0x8(%rcx),%rsi
 101682f:	test   %rsi,%rsi
 1016832:	je     1016a09 <drain_one+0x389>
 1016838:	mov    -0x30(%rbp),%rax
 101683c:	cmpq   $0x0,0xc0(%rax)
 1016844:	jne    1016a09 <drain_one+0x389>
 101684a:	mov    0x10(%rsi),%rax
 101684e:	test   %rax,%rax
 1016851:	je     1016870 <drain_one+0x1f0>
 1016853:	mov    %rbx,%rdi
 1016856:	mov    %r15,%rsi
 1016859:	mov    %r12,%rdx
 101685c:	call   *%rax
 101685e:	jmp    1016882 <drain_one+0x202>
 1016860:	mov    %rbx,%rdi
 1016863:	mov    %r15,%rdx
 1016866:	mov    %r12,%rcx
 1016869:	call   1016060 <myl_rc_flat_edges_release>
 101686e:	jmp    1016882 <drain_one+0x202>
 1016870:	mov    0x8(%rsi),%rsi
 1016874:	mov    %rbx,%rdi
 1016877:	mov    %r15,%rdx
 101687a:	mov    %r12,%rcx
 101687d:	call   1015bb0 <myl_rc_edges_release>
 1016882:	mov    -0x30(%rbp),%r12
 1016886:	cmpq   $0x0,0xc0(%r12)
 101688f:	je     10168c8 <drain_one+0x248>
 1016891:	jmp    1016a09 <drain_one+0x389>
 1016896:	lea    0x18(%rax),%rcx
 101689a:	mov    -0x30(%rbp),%r12
 101689e:	movzwl (%rcx),%edx
 10168a1:	mov    0xc8(%r12),%rcx
 10168a9:	test   %edx,%edx
 10168ab:	jne    1016975 <drain_one+0x2f5>
 10168b1:	mov    %rcx,0xc8(%r12)
 10168b9:	cmpq   $0x0,0xc0(%r12)
 10168c2:	jne    1016a09 <drain_one+0x389>
 10168c8:	mov    0x10(%r14),%rax
 10168cc:	and    %rax,%r13
 10168cf:	cmp    $0x1,%r13
 10168d3:	jne    1016a09 <drain_one+0x389>
 10168d9:	test   %rax,%rax
 10168dc:	setns  %cl
 10168df:	mov    0x1608(%rbx),%rax
 10168e6:	mov    0x8(%rax),%rax
 10168ea:	cmp    $0x101c550,%rax
 10168f1:	sete   %dl
 10168f4:	and    %cl,%dl
 10168f6:	cmp    $0x1,%dl
 10168f9:	jne    10169c3 <drain_one+0x343>
 10168ff:	mov    0x40(%rbx),%rax
 1016903:	test   %rax,%rax
 1016906:	je     1016a09 <drain_one+0x389>
 101690c:	mov    0x50(%rbx),%rcx
 1016910:	cmp    $0xffffffffffffffff,%rcx
 1016914:	je     101691d <drain_one+0x29d>
 1016916:	inc    %rcx
 1016919:	mov    %rcx,0x50(%rbx)
 101691d:	mov    %r14,%rcx
 1016920:	and    $0xffffffffffff0000,%rcx
 1016927:	dec    %rax
 101692a:	mov    %rax,0x40(%rbx)
 101692e:	movq   $0x3,0x10(%r14)
 1016936:	mov    (%rcx),%rax
 1016939:	mov    0x1610(%rbx,%rax,8),%rax
 1016941:	mov    %rax,(%r14)
 1016944:	mov    (%rcx),%rax
 1016947:	mov    %r14,0x1610(%rbx,%rax,8)
 101694f:	mov    0x8(%rcx),%rax
 1016953:	add    %rax,0x1710(%rbx)
 101695a:	jmp    10169cb <drain_one+0x34b>
 101695c:	nopl   0x0(%rax)
 1016960:	test   $0x1,%r9b
 1016964:	jne    1016a09 <drain_one+0x389>
 101696a:	blsr   %edx,%edx
 101696f:	je     10168b1 <drain_one+0x231>
 1016975:	tzcnt  %edx,%esi
 1016979:	movzwl 0x5c(%rax,%rsi,2),%esi
 101697e:	mov    (%r15,%rsi,1),%r8
 1016982:	test   %r8,%r8
 1016985:	je     101696a <drain_one+0x2ea>
 1016987:	mov    -0x10(%r8),%r9
 101698b:	test   %r13,%r9
 101698e:	jne    1016960 <drain_one+0x2e0>
 1016990:	lea    -0x20(%r8),%rsi
 1016994:	mov    (%rsi),%rdi
 1016997:	cmp    $0x1,%rdi
 101699b:	je     10169a4 <drain_one+0x324>
 101699d:	test   %rdi,%rdi
 10169a0:	jne    10169ab <drain_one+0x32b>
 10169a2:	jmp    1016a09 <drain_one+0x389>
 10169a4:	cmpq   $0x0,-0x18(%r8)
 10169a9:	je     10169b3 <drain_one+0x333>
 10169ab:	dec    %rdi
 10169ae:	mov    %rdi,(%rsi)
 10169b1:	jmp    101696a <drain_one+0x2ea>
 10169b3:	or     $0x1,%r9
 10169b7:	mov    %r9,-0x10(%r8)
 10169bb:	mov    %rcx,%rdi
 10169be:	mov    %rsi,%rcx
 10169c1:	jmp    10169ae <drain_one+0x32e>
 10169c3:	mov    %rbx,%rdi
 10169c6:	mov    %r15,%rsi
 10169c9:	call   *%rax
 10169cb:	mov    0xc8(%r12),%rax
 10169d3:	add    $0x8,%rsp
 10169d7:	pop    %rbx
 10169d8:	pop    %r12
 10169da:	pop    %r13
 10169dc:	pop    %r14
 10169de:	pop    %r15
 10169e0:	pop    %rbp
 10169e1:	ret
 10169e2:	mov    %rbx,%rdi
 10169e5:	call   10130fa <myl_rc_binding_find_slow>
 10169ea:	test   %rax,%rax
 10169ed:	jne    1016739 <drain_one+0xb9>
 10169f3:	jmp    1016a09 <drain_one+0x389>
 10169f5:	mov    %rbx,%rdi
 10169f8:	call   10130fa <myl_rc_binding_find_slow>
 10169fd:	mov    %rax,%rsi
 1016a00:	test   %rsi,%rsi
 1016a03:	jne    1016838 <drain_one+0x1b8>
 1016a09:	call   101267d <myl_rc_invariant_failed>
 1016a0e:	int3
 1016a0f:	int3

0000000001016a10 <myl_rc_native_has_unique>:
 1016a10:	push   %rbp
 1016a11:	mov    %rsp,%rbp
 1016a14:	test   %rdi,%rdi
 1016a17:	je     1016bb8 <myl_rc_native_has_unique+0x1a8>
 1016a1d:	mov    0x1608(%rdi),%rdx
 1016a24:	test   %rdx,%rdx
 1016a27:	je     1016bb8 <myl_rc_native_has_unique+0x1a8>
 1016a2d:	cmpq   $0x0,0xc0(%rdx)
 1016a35:	jne    1016bb8 <myl_rc_native_has_unique+0x1a8>
 1016a3b:	vxorps %xmm0,%xmm0,%xmm0
 1016a3f:	mov    $0x160,%ecx
 1016a44:	movzwl 0x30(%rsi),%eax
 1016a48:	cmp    $0x1,%ax
 1016a4c:	jne    1016aab <myl_rc_native_has_unique+0x9b>
 1016a4e:	cmpw   $0x5,0x32(%rsi)
 1016a53:	jne    1016af6 <myl_rc_native_has_unique+0xe6>
 1016a59:	mov    0x38(%rsi),%rax
 1016a5d:	test   %rax,%rax
 1016a60:	je     1016af6 <myl_rc_native_has_unique+0xe6>
 1016a66:	mov    0x34(%rax),%r8d
 1016a6a:	cmp    %r8,0xa0(%rdx)
 1016a71:	jbe    1016b9d <myl_rc_native_has_unique+0x18d>
 1016a77:	mov    0x98(%rdx),%rdx
 1016a7e:	shl    $0x4,%r8
 1016a82:	cmp    %rax,(%rdx,%r8,1)
 1016a86:	jne    1016b9d <myl_rc_native_has_unique+0x18d>
 1016a8c:	add    %r8,%rdx
 1016a8f:	mov    0x8(%rdx),%rax
 1016a93:	test   %rax,%rax
 1016a96:	je     1016bb8 <myl_rc_native_has_unique+0x1a8>
 1016a9c:	cmpq   $0x0,0x18(%rax)
 1016aa1:	jne    1016bbf <myl_rc_native_has_unique+0x1af>
 1016aa7:	movzwl 0x30(%rsi),%eax
 1016aab:	movzwl %ax,%eax
 1016aae:	lea    -0x2(%rax),%edx
 1016ab1:	cmp    $0x3,%edx
 1016ab4:	jae    1016b89 <myl_rc_native_has_unique+0x179>
 1016aba:	mov    0x1608(%rdi),%rax
 1016ac1:	mov    0xc0(%rax),%rdx
 1016ac8:	cmp    0xb8(%rax),%rdx
 1016acf:	jae    1016bb8 <myl_rc_native_has_unique+0x1a8>
 1016ad5:	mov    0xb0(%rax),%r8
 1016adc:	lea    0x1(%rdx),%r9
 1016ae0:	mov    %r9,0xc0(%rax)
 1016ae7:	lea    (%rdx,%rdx,2),%rax
 1016aeb:	mov    %rsi,(%r8,%rax,8)
 1016aef:	vmovups %xmm0,0x8(%r8,%rax,8)
 1016af6:	mov    0x1608(%rdi),%rdx
 1016afd:	mov    0xc0(%rdx),%rsi
 1016b04:	xor    %eax,%eax
 1016b06:	test   %rsi,%rsi
 1016b09:	je     1016bbd <myl_rc_native_has_unique+0x1ad>
 1016b0f:	mov    0xb0(%rdx),%r8
 1016b16:	lea    (%rsi,%rsi,2),%r9
 1016b1a:	dec    %rsi
 1016b1d:	lea    (%r8,%r9,8),%r8
 1016b21:	add    $0xfffffffffffffff8,%r8
 1016b25:	data16 cs nopw 0x0(%rax,%rax,1)
 1016b30:	mov    -0x10(%r8),%r9
 1016b34:	cmpw   $0x3,0x30(%r9)
 1016b3a:	jne    1016b50 <myl_rc_native_has_unique+0x140>
 1016b3c:	xor    %r10d,%r10d
 1016b3f:	cmpq   $0x0,0x20(%r9)
 1016b44:	setne  %r10b
 1016b48:	jmp    1016b54 <myl_rc_native_has_unique+0x144>
 1016b4a:	nopw   0x0(%rax,%rax,1)
 1016b50:	mov    0x18(%r9),%r10
 1016b54:	mov    (%r8),%r11
 1016b57:	cmp    %r10,%r11
 1016b5a:	jb     1016b70 <myl_rc_native_has_unique+0x160>
 1016b5c:	mov    %rsi,0xc0(%rdx)
 1016b63:	add    $0xffffffffffffffe8,%r8
 1016b67:	add    $0xffffffffffffffff,%rsi
 1016b6b:	jb     1016b30 <myl_rc_native_has_unique+0x120>
 1016b6d:	jmp    1016bbd <myl_rc_native_has_unique+0x1ad>
 1016b6f:	nop
 1016b70:	mov    0x10(%r9),%rax
 1016b74:	lea    0x1(%r11),%rsi
 1016b78:	mov    %rsi,(%r8)
 1016b7b:	lea    (%r11,%r11,2),%rsi
 1016b7f:	mov    0x8(%rax,%rsi,8),%rsi
 1016b84:	jmp    1016a44 <myl_rc_native_has_unique+0x34>
 1016b89:	cmp    $0x8,%eax
 1016b8c:	ja     1016af6 <myl_rc_native_has_unique+0xe6>
 1016b92:	bt     %eax,%ecx
 1016b95:	jae    1016af6 <myl_rc_native_has_unique+0xe6>
 1016b9b:	jmp    1016bbf <myl_rc_native_has_unique+0x1af>
 1016b9d:	mov    %rsi,%rdx
 1016ba0:	mov    %rax,%rsi
 1016ba3:	call   10130fa <myl_rc_binding_find_slow>
 1016ba8:	vxorps %xmm0,%xmm0,%xmm0
 1016bac:	mov    %rdx,%rsi
 1016baf:	test   %rax,%rax
 1016bb2:	jne    1016a9c <myl_rc_native_has_unique+0x8c>
 1016bb8:	call   101267d <myl_rc_invariant_failed>
 1016bbd:	pop    %rbp
 1016bbe:	ret
 1016bbf:	mov    0x1608(%rdi),%rax
 1016bc6:	movq   $0x0,0xc0(%rax)
 1016bd1:	mov    $0x1,%eax
 1016bd6:	pop    %rbp
 1016bd7:	ret
 1016bd8:	int3
 1016bd9:	int3
 1016bda:	int3
 1016bdb:	int3
 1016bdc:	int3
 1016bdd:	int3
 1016bde:	int3
 1016bdf:	int3

0000000001016be0 <myl_rc_binding_has_unique>:
 1016be0:	push   %rbp
 1016be1:	mov    %rsp,%rbp
 1016be4:	push   %rbx
 1016be5:	push   %rax
 1016be6:	test   %rdi,%rdi
 1016be9:	je     1016c13 <myl_rc_binding_has_unique+0x33>
 1016beb:	mov    0x1608(%rdi),%rax
 1016bf2:	test   %rax,%rax
 1016bf5:	je     1016c13 <myl_rc_binding_has_unique+0x33>
 1016bf7:	test   %rsi,%rsi
 1016bfa:	je     1016c13 <myl_rc_binding_has_unique+0x33>
 1016bfc:	cmpq   $0x0,0xc0(%rax)
 1016c04:	jne    1016c13 <myl_rc_binding_has_unique+0x33>
 1016c06:	movzbl 0x45(%rsi),%ecx
 1016c0a:	test   %ecx,%ecx
 1016c0c:	je     1016c18 <myl_rc_binding_has_unique+0x38>
 1016c0e:	cmp    $0x3,%cl
 1016c11:	jb     1016c34 <myl_rc_binding_has_unique+0x54>
 1016c13:	call   101267d <myl_rc_invariant_failed>
 1016c18:	mov    (%rsi),%rax
 1016c1b:	mov    %rsi,%rbx
 1016c1e:	mov    %rax,%rsi
 1016c21:	call   1016a10 <myl_rc_native_has_unique>
 1016c26:	cmp    $0x1,%eax
 1016c29:	mov    $0x2,%ecx
 1016c2e:	sbb    $0x0,%ecx
 1016c31:	mov    %cl,0x45(%rbx)
 1016c34:	xor    %eax,%eax
 1016c36:	cmp    $0x2,%ecx
 1016c39:	sete   %al
 1016c3c:	add    $0x8,%rsp
 1016c40:	pop    %rbx
 1016c41:	pop    %rbp
 1016c42:	ret
 1016c43:	int3
 1016c44:	int3
 1016c45:	int3
 1016c46:	int3
 1016c47:	int3
 1016c48:	int3
 1016c49:	int3
 1016c4a:	int3
 1016c4b:	int3
 1016c4c:	int3
 1016c4d:	int3
 1016c4e:	int3
 1016c4f:	int3

0000000001016c50 <myl_rc_value_seed>:
 1016c50:	push   %rbp
 1016c51:	mov    %rsp,%rbp
 1016c54:	push   %r15
 1016c56:	push   %r14
 1016c58:	push   %r13
 1016c5a:	push   %r12
 1016c5c:	push   %rbx
 1016c5d:	push   %rax
 1016c5e:	mov    %r8,-0x30(%rbp)
 1016c62:	test   %rdi,%rdi
 1016c65:	je     1016ed0 <myl_rc_value_seed+0x280>
 1016c6b:	mov    %rdx,%r14
 1016c6e:	mov    %rdi,%r15
 1016c71:	mov    0x1608(%rdi),%rdx
 1016c78:	test   %rdx,%rdx
 1016c7b:	je     1016ed0 <myl_rc_value_seed+0x280>
 1016c81:	cmp    %rcx,%r14
 1016c84:	je     1016ed0 <myl_rc_value_seed+0x280>
 1016c8a:	cmpq   $0x0,0xc0(%rdx)
 1016c92:	jne    1016ed0 <myl_rc_value_seed+0x280>
 1016c98:	mov    0x58(%rdx),%rax
 1016c9c:	mov    0x60(%rdx),%rdi
 1016ca0:	movzbl 0x70(%rdx),%edx
 1016ca4:	movabs $0x9e3779b97f4a7c15,%r8
 1016cae:	imul   %rsi,%r8
 1016cb2:	shrx   %rdx,%r8,%rdx
 1016cb7:	nopw   0x0(%rax,%rax,1)
 1016cc0:	and    %rdi,%rdx
 1016cc3:	mov    %rdx,%r8
 1016cc6:	shl    $0x4,%r8
 1016cca:	mov    (%rax,%r8,1),%r8
 1016cce:	cmp    %rsi,%r8
 1016cd1:	je     1016ce1 <myl_rc_value_seed+0x91>
 1016cd3:	test   %r8,%r8
 1016cd6:	je     1016ed0 <myl_rc_value_seed+0x280>
 1016cdc:	inc    %rdx
 1016cdf:	jmp    1016cc0 <myl_rc_value_seed+0x70>
 1016ce1:	shl    $0x4,%rdx
 1016ce5:	mov    0x8(%rax,%rdx,1),%r12
 1016cea:	test   %r12,%r12
 1016ced:	je     1016ed0 <myl_rc_value_seed+0x280>
 1016cf3:	mov    -0x30(%rbp),%rax
 1016cf7:	mulq   (%r12)
 1016cfb:	jo     1016ed0 <myl_rc_value_seed+0x280>
 1016d01:	mov    0x8(%r12),%edx
 1016d06:	or     $0x4,%edx
 1016d09:	cmp    $0x5,%edx
 1016d0c:	jne    1016d29 <myl_rc_value_seed+0xd9>
 1016d0e:	mov    %r14,%rdi
 1016d11:	xor    %esi,%esi
 1016d13:	mov    %rax,%rdx
 1016d16:	add    $0x8,%rsp
 1016d1a:	pop    %rbx
 1016d1b:	pop    %r12
 1016d1d:	pop    %r13
 1016d1f:	pop    %r14
 1016d21:	pop    %r15
 1016d23:	pop    %rbp
 1016d24:	jmp    101e6b0 <compiler_rt.fastMemset>
 1016d29:	mov    %r14,%rdi
 1016d2c:	mov    %rcx,%rsi
 1016d2f:	mov    %rax,%rdx
 1016d32:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1016d37:	cmpl   $0x0,0x8(%r12)
 1016d3d:	je     1016ec1 <myl_rc_value_seed+0x271>
 1016d43:	cmpq   $0x0,-0x30(%rbp)
 1016d48:	je     1016ec1 <myl_rc_value_seed+0x271>
 1016d4e:	mov    0x28(%r12),%r13
 1016d53:	xor    %ebx,%ebx
 1016d55:	jmp    1016d7b <myl_rc_value_seed+0x12b>
 1016d57:	nopw   0x0(%rax,%rax,1)
 1016d60:	mov    %r15,%rdi
 1016d63:	xor    %esi,%esi
 1016d65:	call   1015990 <walk>
 1016d6a:	add    (%r12),%r14
 1016d6e:	inc    %rbx
 1016d71:	cmp    -0x30(%rbp),%rbx
 1016d75:	je     1016ec1 <myl_rc_value_seed+0x271>
 1016d7b:	mov    0x8(%r12),%eax
 1016d80:	cmp    $0x2,%r13
 1016d84:	jbe    1016dd0 <myl_rc_value_seed+0x180>
 1016d86:	test   %eax,%eax
 1016d88:	je     1016d60 <myl_rc_value_seed+0x110>
 1016d8a:	mov    0x1608(%r15),%rax
 1016d91:	mov    0xc0(%rax),%rcx
 1016d98:	cmp    0xb8(%rax),%rcx
 1016d9f:	jae    1016ed0 <myl_rc_value_seed+0x280>
 1016da5:	mov    0xb0(%rax),%rdx
 1016dac:	lea    0x1(%rcx),%rsi
 1016db0:	mov    %rsi,0xc0(%rax)
 1016db7:	lea    (%rcx,%rcx,2),%rax
 1016dbb:	mov    %r12,(%rdx,%rax,8)
 1016dbf:	mov    %r14,0x8(%rdx,%rax,8)
 1016dc4:	movq   $0x0,0x10(%rdx,%rax,8)
 1016dcd:	jmp    1016d60 <myl_rc_value_seed+0x110>
 1016dcf:	nop
 1016dd0:	dec    %eax
 1016dd2:	cmp    $0x4,%eax
 1016dd5:	ja     1016e22 <myl_rc_value_seed+0x1d2>
 1016dd7:	lea    -0x13d06(%rip),%rcx        # 10030d8 <myl_rc_map_sentinel+0x38>
 1016dde:	movslq (%rcx,%rax,4),%rax
 1016de2:	add    %rcx,%rax
 1016de5:	jmp    *%rax
 1016de7:	mov    $0x1,%eax
 1016dec:	xor    %ecx,%ecx
 1016dee:	jmp    1016e26 <myl_rc_value_seed+0x1d6>
 1016df0:	mov    0x10(%r12),%rdx
 1016df5:	mov    0x18(%r12),%rax
 1016dfa:	mov    0x20(%r12),%rsi
 1016dff:	add    %r14,%rsi
 1016e02:	xor    %ecx,%ecx
 1016e04:	jmp    1016e2a <myl_rc_value_seed+0x1da>
 1016e06:	mov    0x10(%r12),%rdx
 1016e0b:	mov    0x18(%r12),%rax
 1016e10:	xor    %ecx,%ecx
 1016e12:	xor    %esi,%esi
 1016e14:	jmp    1016e2a <myl_rc_value_seed+0x1da>
 1016e16:	mov    0x18(%r12),%rax
 1016e1b:	mov    0x20(%r12),%rcx
 1016e20:	jmp    1016e26 <myl_rc_value_seed+0x1d6>
 1016e22:	xor    %ecx,%ecx
 1016e24:	xor    %eax,%eax
 1016e26:	xor    %esi,%esi
 1016e28:	xor    %edx,%edx
 1016e2a:	lea    0x10(%rdx),%rdi
 1016e2e:	mov    %rax,%r8
 1016e31:	neg    %r8
 1016e34:	xor    %r9d,%r9d
 1016e37:	test   %rdx,%rdx
 1016e3a:	je     1016ea0 <myl_rc_value_seed+0x250>
 1016e3c:	cmp    %rax,%r9
 1016e3f:	jae    1016d6a <myl_rc_value_seed+0x11a>
 1016e45:	lea    (%r9,%r9,2),%r10
 1016e49:	lea    (%rdi,%r10,8),%r10
 1016e4d:	inc    %r9
 1016e50:	jmp    1016e78 <myl_rc_value_seed+0x228>
 1016e52:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1016e60:	add    $0x18,%r10
 1016e64:	lea    (%r8,%r9,1),%r11
 1016e68:	inc    %r11
 1016e6b:	inc    %r9
 1016e6e:	cmp    $0x1,%r11
 1016e72:	je     1016d6a <myl_rc_value_seed+0x11a>
 1016e78:	mov    -0x8(%r10),%r11
 1016e7c:	cmpl   $0x0,0x8(%r11)
 1016e81:	je     1016e60 <myl_rc_value_seed+0x210>
 1016e83:	test   %rsi,%rsi
 1016e86:	je     1016e90 <myl_rc_value_seed+0x240>
 1016e88:	mov    (%r10),%r11d
 1016e8b:	cmp    (%rsi),%r11d
 1016e8e:	jne    1016e60 <myl_rc_value_seed+0x210>
 1016e90:	mov    -0x10(%r10),%r10
 1016e94:	movq   $0x0,(%r14,%r10,1)
 1016e9c:	jmp    1016e37 <myl_rc_value_seed+0x1e7>
 1016e9e:	xchg   %ax,%ax
 1016ea0:	cmp    %rax,%r9
 1016ea3:	je     1016d6a <myl_rc_value_seed+0x11a>
 1016ea9:	lea    0x1(%r9),%r10
 1016ead:	imul   %rcx,%r9
 1016eb1:	movq   $0x0,(%r14,%r9,1)
 1016eb9:	mov    %r10,%r9
 1016ebc:	jmp    1016e37 <myl_rc_value_seed+0x1e7>
 1016ec1:	add    $0x8,%rsp
 1016ec5:	pop    %rbx
 1016ec6:	pop    %r12
 1016ec8:	pop    %r13
 1016eca:	pop    %r14
 1016ecc:	pop    %r15
 1016ece:	pop    %rbp
 1016ecf:	ret
 1016ed0:	call   101267d <myl_rc_invariant_failed>
 1016ed5:	int3
 1016ed6:	int3
 1016ed7:	int3
 1016ed8:	int3
 1016ed9:	int3
 1016eda:	int3
 1016edb:	int3
 1016edc:	int3
 1016edd:	int3
 1016ede:	int3
 1016edf:	int3

0000000001016ee0 <myl_rc_construction_abort>:
 1016ee0:	push   %rbp
 1016ee1:	mov    %rsp,%rbp
 1016ee4:	push   %r15
 1016ee6:	push   %r14
 1016ee8:	push   %rbx
 1016ee9:	push   %rax
 1016eea:	test   %rsi,%rsi
 1016eed:	je     1016fd4 <myl_rc_construction_abort+0xf4>
 1016ef3:	mov    -0x10(%rsi),%rax
 1016ef7:	test   $0x2,%al
 1016ef9:	jne    1017033 <myl_rc_construction_abort+0x153>
 1016eff:	bt     $0x3e,%rax
 1016f04:	jb     1016f15 <myl_rc_construction_abort+0x35>
 1016f06:	add    $0x8,%rsp
 1016f0a:	pop    %rbx
 1016f0b:	pop    %r14
 1016f0d:	pop    %r15
 1016f0f:	pop    %rbp
 1016f10:	jmp    1012cd0 <myl_rc_owner_release>
 1016f15:	test   $0x1,%al
 1016f17:	jne    1016fd4 <myl_rc_construction_abort+0xf4>
 1016f1d:	or     $0x1,%rax
 1016f21:	mov    %rax,-0x10(%rsi)
 1016f25:	mov    -0x8(%rsi),%rax
 1016f29:	mov    0x1608(%rdi),%rdx
 1016f30:	mov    0x34(%rax),%ecx
 1016f33:	cmp    %rcx,0xa0(%rdx)
 1016f3a:	mov    %rdi,%rbx
 1016f3d:	mov    %rsi,%r14
 1016f40:	jbe    101701c <myl_rc_construction_abort+0x13c>
 1016f46:	mov    0x98(%rdx),%rdx
 1016f4d:	shl    $0x4,%rcx
 1016f51:	cmp    %rax,(%rdx,%rcx,1)
 1016f55:	jne    101701c <myl_rc_construction_abort+0x13c>
 1016f5b:	add    %rcx,%rdx
 1016f5e:	mov    0x8(%rdx),%rax
 1016f62:	test   %rax,%rax
 1016f65:	je     1017033 <myl_rc_construction_abort+0x153>
 1016f6b:	mov    $0x28,%ecx
 1016f70:	bzhi   %rcx,-0x10(%rsi),%r15
 1016f76:	mov    0x18(%rax),%rax
 1016f7a:	test   %rax,%rax
 1016f7d:	je     1016f8d <myl_rc_construction_abort+0xad>
 1016f7f:	mov    %rbx,%rdi
 1016f82:	mov    %r14,%rsi
 1016f85:	call   *%rax
 1016f87:	mov    %r14,%rsi
 1016f8a:	mov    %rbx,%rdi
 1016f8d:	mov    -0x8(%rsi),%rax
 1016f91:	mov    0x1608(%rdi),%rdx
 1016f98:	mov    0x34(%rax),%ecx
 1016f9b:	cmp    %rcx,0xa0(%rdx)
 1016fa2:	jbe    1017038 <myl_rc_construction_abort+0x158>
 1016fa8:	mov    0x98(%rdx),%rdx
 1016faf:	shl    $0x4,%rcx
 1016fb3:	cmp    %rax,(%rdx,%rcx,1)
 1016fb7:	jne    1017038 <myl_rc_construction_abort+0x158>
 1016fb9:	add    %rcx,%rdx
 1016fbc:	mov    0x8(%rdx),%rax
 1016fc0:	shr    $0x2,%r15
 1016fc4:	mov    0x10(%rax),%rcx
 1016fc8:	test   %rcx,%rcx
 1016fcb:	je     1016fdf <myl_rc_construction_abort+0xff>
 1016fcd:	mov    %r15,%rdx
 1016fd0:	call   *%rcx
 1016fd2:	jmp    1016ff1 <myl_rc_construction_abort+0x111>
 1016fd4:	add    $0x8,%rsp
 1016fd8:	pop    %rbx
 1016fd9:	pop    %r14
 1016fdb:	pop    %r15
 1016fdd:	pop    %rbp
 1016fde:	ret
 1016fdf:	mov    0x8(%rax),%rax
 1016fe3:	mov    %rsi,%rdx
 1016fe6:	mov    %rax,%rsi
 1016fe9:	mov    %r15,%rcx
 1016fec:	call   1015bb0 <myl_rc_edges_release>
 1016ff1:	mov    -0x8(%r14),%rcx
 1016ff5:	mov    %r15,%rax
 1016ff8:	mulq   (%rcx)
 1016ffb:	jo     1017033 <myl_rc_construction_abort+0x153>
 1016ffd:	mov    %r14,%rdi
 1017000:	xor    %esi,%esi
 1017002:	mov    %rax,%rdx
 1017005:	call   101e6b0 <compiler_rt.fastMemset>
 101700a:	mov    %rbx,%rdi
 101700d:	add    $0x8,%rsp
 1017011:	pop    %rbx
 1017012:	pop    %r14
 1017014:	pop    %r15
 1017016:	pop    %rbp
 1017017:	jmp    1016210 <myl_rc_drain>
 101701c:	mov    %rbx,%rdi
 101701f:	mov    %rax,%rsi
 1017022:	call   10130fa <myl_rc_binding_find_slow>
 1017027:	mov    %r14,%rsi
 101702a:	test   %rax,%rax
 101702d:	jne    1016f6b <myl_rc_construction_abort+0x8b>
 1017033:	call   101267d <myl_rc_invariant_failed>
 1017038:	mov    %rbx,%rdi
 101703b:	mov    %rax,%rsi
 101703e:	call   10130fa <myl_rc_binding_find_slow>
 1017043:	mov    %r14,%rsi
 1017046:	jmp    1016fc0 <myl_rc_construction_abort+0xe0>
 101704b:	int3
 101704c:	int3
 101704d:	int3
 101704e:	int3
 101704f:	int3

0000000001017050 <drain_pairs>:
 1017050:	push   %rbp
 1017051:	mov    %rsp,%rbp
 1017054:	push   %r15
 1017056:	push   %r14
 1017058:	push   %r13
 101705a:	push   %r12
 101705c:	push   %rbx
 101705d:	sub    $0x18,%rsp
 1017061:	mov    %r8,-0x40(%rbp)
 1017065:	mov    %rdx,%rbx
 1017068:	movabs $0x4000000000000003,%r10
 1017072:	mov    0x18(%rsi),%r11
 1017076:	mov    %rsi,%r9
 1017079:	and    $0xffffffffffff0000,%r9
 1017080:	mov    (%r9),%rax
 1017083:	movzwl 0x5c(%rcx),%r14d
 1017088:	movzwl 0x5e(%rcx),%r15d
 101708d:	mov    %rdi,-0x38(%rbp)
 1017091:	mov    %rax,-0x30(%rbp)
 1017095:	mov    0x1610(%rdi,%rax,8),%r13
 101709d:	mov    $0x1,%ecx
 10170a2:	movabs $0xcfffffffffffffff,%r12
 10170ac:	nopl   0x0(%rax)
 10170b0:	mov    0x20(%rsi,%r14,1),%r8
 10170b5:	test   %r8,%r8
 10170b8:	je     10170f8 <drain_pairs+0xa8>
 10170ba:	mov    -0x10(%r8),%rdi
 10170be:	test   %r10,%rdi
 10170c1:	je     10170d0 <drain_pairs+0x80>
 10170c3:	test   $0x1,%dil
 10170c7:	je     10170f8 <drain_pairs+0xa8>
 10170c9:	jmp    10171dc <drain_pairs+0x18c>
 10170ce:	xchg   %ax,%ax
 10170d0:	lea    -0x20(%r8),%rax
 10170d4:	mov    (%rax),%rdx
 10170d7:	cmp    $0x1,%rdx
 10170db:	je     10170e7 <drain_pairs+0x97>
 10170dd:	test   %rdx,%rdx
 10170e0:	jne    10170f2 <drain_pairs+0xa2>
 10170e2:	jmp    10171dc <drain_pairs+0x18c>
 10170e7:	cmpq   $0x0,-0x18(%r8)
 10170ec:	je     101717b <drain_pairs+0x12b>
 10170f2:	dec    %rdx
 10170f5:	mov    %rdx,(%rax)
 10170f8:	mov    0x20(%rsi,%r15,1),%rdi
 10170fd:	test   %rdi,%rdi
 1017100:	je     1017144 <drain_pairs+0xf4>
 1017102:	mov    -0x10(%rdi),%r8
 1017106:	test   %r10,%r8
 1017109:	je     1017120 <drain_pairs+0xd0>
 101710b:	mov    %rbx,%rax
 101710e:	test   $0x1,%r8b
 1017112:	je     1017147 <drain_pairs+0xf7>
 1017114:	jmp    10171dc <drain_pairs+0x18c>
 1017119:	nopl   0x0(%rax)
 1017120:	lea    -0x20(%rdi),%rax
 1017124:	mov    (%rax),%rdx
 1017127:	cmp    $0x1,%rdx
 101712b:	je     1017137 <drain_pairs+0xe7>
 101712d:	test   %rdx,%rdx
 1017130:	jne    101713e <drain_pairs+0xee>
 1017132:	jmp    10171dc <drain_pairs+0x18c>
 1017137:	cmpq   $0x0,-0x18(%rdi)
 101713c:	je     101718e <drain_pairs+0x13e>
 101713e:	dec    %rdx
 1017141:	mov    %rdx,(%rax)
 1017144:	mov    %rbx,%rax
 1017147:	movq   $0x3,0x10(%rsi)
 101714f:	mov    %r13,(%rsi)
 1017152:	test   %rax,%rax
 1017155:	je     101719e <drain_pairs+0x14e>
 1017157:	cmp    %r11,0x18(%rax)
 101715b:	jne    101719e <drain_pairs+0x14e>
 101715d:	mov    0x10(%rax),%rdx
 1017161:	and    %r12,%rdx
 1017164:	cmp    $0x5,%rdx
 1017168:	jne    101719e <drain_pairs+0x14e>
 101716a:	mov    (%rax),%rbx
 101716d:	inc    %rcx
 1017170:	mov    %rsi,%r13
 1017173:	mov    %rax,%rsi
 1017176:	jmp    10170b0 <drain_pairs+0x60>
 101717b:	or     $0x1,%rdi
 101717f:	mov    %rdi,-0x10(%r8)
 1017183:	mov    %rbx,%rdx
 1017186:	mov    %rax,%rbx
 1017189:	jmp    10170f5 <drain_pairs+0xa5>
 101718e:	or     $0x1,%r8
 1017192:	mov    %r8,-0x10(%rdi)
 1017196:	mov    %rbx,%rdx
 1017199:	mov    %rax,%rbx
 101719c:	jmp    1017141 <drain_pairs+0xf1>
 101719e:	mov    -0x38(%rbp),%rdx
 10171a2:	mov    -0x30(%rbp),%rdi
 10171a6:	mov    %rsi,0x1610(%rdx,%rdi,8)
 10171ae:	vmovq  %rcx,%xmm0
 10171b3:	imul   0x8(%r9),%rcx
 10171b8:	vmovq  %rcx,%xmm1
 10171bd:	vpunpcklqdq %xmm1,%xmm0,%xmm0
 10171c1:	mov    -0x40(%rbp),%rcx
 10171c5:	vpaddq (%rcx),%xmm0,%xmm0
 10171c9:	vmovdqu %xmm0,(%rcx)
 10171cd:	add    $0x18,%rsp
 10171d1:	pop    %rbx
 10171d2:	pop    %r12
 10171d4:	pop    %r13
 10171d6:	pop    %r14
 10171d8:	pop    %r15
 10171da:	pop    %rbp
 10171db:	ret
 10171dc:	call   101267d <myl_rc_invariant_failed>
 10171e1:	int3
 10171e2:	int3
 10171e3:	int3
 10171e4:	int3
 10171e5:	int3
 10171e6:	int3
 10171e7:	int3
 10171e8:	int3
 10171e9:	int3
 10171ea:	int3
 10171eb:	int3
 10171ec:	int3
 10171ed:	int3
 10171ee:	int3
 10171ef:	int3

00000000010171f0 <myl_print_raw>:
 10171f0:	test   %rdx,%rdx
 10171f3:	je     101720e <myl_print_raw+0x1e>
 10171f5:	cmpl   $0x0,0x18(%rdi)
 10171f9:	jne    101720e <myl_print_raw+0x1e>
 10171fb:	mov    0x8(%rdi),%rcx
 10171ff:	mov    %rcx,%rax
 1017202:	add    %rdx,%rax
 1017205:	jae    101720f <myl_print_raw+0x1f>
 1017207:	movl   $0x1,0x18(%rdi)
 101720e:	ret
 101720f:	push   %rbp
 1017210:	mov    %rsp,%rbp
 1017213:	push   %r15
 1017215:	push   %r14
 1017217:	push   %r12
 1017219:	push   %rbx
 101721a:	mov    0x10(%rdi),%rax
 101721e:	mov    %rax,%r8
 1017221:	sub    %rcx,%r8
 1017224:	cmp    %r8,%rdx
 1017227:	jbe    1017255 <myl_print_raw+0x65>
 1017229:	test   %rax,%rax
 101722c:	mov    $0x40,%ebx
 1017231:	cmovne %rax,%rbx
 1017235:	data16 cs nopw 0x0(%rax,%rax,1)
 1017240:	mov    %rbx,%rax
 1017243:	sub    %rcx,%rax
 1017246:	cmp    %rdx,%rax
 1017249:	jae    101725d <myl_print_raw+0x6d>
 101724b:	test   %rbx,%rbx
 101724e:	js     10172ac <myl_print_raw+0xbc>
 1017250:	add    %rbx,%rbx
 1017253:	jmp    1017240 <myl_print_raw+0x50>
 1017255:	mov    %rdi,%r14
 1017258:	mov    (%rdi),%rax
 101725b:	jmp    1017287 <myl_print_raw+0x97>
 101725d:	mov    %rsi,%r12
 1017260:	mov    %rdx,%r15
 1017263:	mov    %rdi,%r14
 1017266:	mov    (%rdi),%rdi
 1017269:	mov    %rbx,%rsi
 101726c:	call   101f180 <realloc@plt>
 1017271:	test   %rax,%rax
 1017274:	je     10172a2 <myl_print_raw+0xb2>
 1017276:	mov    %rax,(%r14)
 1017279:	mov    %rbx,0x10(%r14)
 101727d:	mov    0x8(%r14),%rcx
 1017281:	mov    %r15,%rdx
 1017284:	mov    %r12,%rsi
 1017287:	add    %rax,%rcx
 101728a:	mov    %rcx,%rdi
 101728d:	mov    %rdx,%rbx
 1017290:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1017295:	add    %rbx,0x8(%r14)
 1017299:	pop    %rbx
 101729a:	pop    %r12
 101729c:	pop    %r14
 101729e:	pop    %r15
 10172a0:	pop    %rbp
 10172a1:	ret
 10172a2:	movl   $0x1,0x18(%r14)
 10172aa:	jmp    1017299 <myl_print_raw+0xa9>
 10172ac:	movl   $0x1,0x18(%rdi)
 10172b3:	jmp    1017299 <myl_print_raw+0xa9>
 10172b5:	int3
 10172b6:	int3
 10172b7:	int3
 10172b8:	int3
 10172b9:	int3
 10172ba:	int3
 10172bb:	int3
 10172bc:	int3
 10172bd:	int3
 10172be:	int3
 10172bf:	int3

00000000010172c0 <literal>:
 10172c0:	push   %rbp
 10172c1:	mov    %rsp,%rbp
 10172c4:	push   %r15
 10172c6:	push   %r14
 10172c8:	push   %r12
 10172ca:	push   %rbx
 10172cb:	mov    %rsi,%r14
 10172ce:	mov    %rdi,%rbx
 10172d1:	mov    %rsi,%rdi
 10172d4:	call   101e660 <compiler_rt.strlen>
 10172d9:	test   %rax,%rax
 10172dc:	je     1017373 <literal+0xb3>
 10172e2:	cmpl   $0x0,0x18(%rbx)
 10172e6:	jne    1017373 <literal+0xb3>
 10172ec:	mov    0x8(%rbx),%rdi
 10172f0:	mov    %rdi,%rcx
 10172f3:	add    %rax,%rcx
 10172f6:	jae    1017301 <literal+0x41>
 10172f8:	movl   $0x1,0x18(%rbx)
 10172ff:	jmp    1017373 <literal+0xb3>
 1017301:	mov    0x10(%rbx),%rcx
 1017305:	mov    %rcx,%rdx
 1017308:	sub    %rdi,%rdx
 101730b:	cmp    %rdx,%rax
 101730e:	jbe    1017335 <literal+0x75>
 1017310:	test   %rcx,%rcx
 1017313:	mov    $0x40,%r15d
 1017319:	cmovne %rcx,%r15
 101731d:	nopl   (%rax)
 1017320:	mov    %r15,%rcx
 1017323:	sub    %rdi,%rcx
 1017326:	cmp    %rax,%rcx
 1017329:	jae    101733a <literal+0x7a>
 101732b:	test   %r15,%r15
 101732e:	js     10172f8 <literal+0x38>
 1017330:	add    %r15,%r15
 1017333:	jmp    1017320 <literal+0x60>
 1017335:	mov    (%rbx),%rcx
 1017338:	jmp    101735e <literal+0x9e>
 101733a:	mov    %rax,%r12
 101733d:	mov    (%rbx),%rdi
 1017340:	mov    %r15,%rsi
 1017343:	call   101f180 <realloc@plt>
 1017348:	test   %rax,%rax
 101734b:	je     10172f8 <literal+0x38>
 101734d:	mov    %rax,%rcx
 1017350:	mov    %rax,(%rbx)
 1017353:	mov    %r15,0x10(%rbx)
 1017357:	mov    0x8(%rbx),%rdi
 101735b:	mov    %r12,%rax
 101735e:	add    %rcx,%rdi
 1017361:	mov    %r14,%rsi
 1017364:	mov    %rax,%rdx
 1017367:	mov    %rax,%r14
 101736a:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101736f:	add    %r14,0x8(%rbx)
 1017373:	pop    %rbx
 1017374:	pop    %r12
 1017376:	pop    %r14
 1017378:	pop    %r15
 101737a:	pop    %rbp
 101737b:	ret
 101737c:	int3
 101737d:	int3
 101737e:	int3
 101737f:	int3

0000000001017380 <myl_print_integer>:
 1017380:	push   %rbp
 1017381:	mov    %rsp,%rbp
 1017384:	push   %r15
 1017386:	push   %r14
 1017388:	push   %rbx
 1017389:	sub    $0x28,%rsp
 101738d:	mov    %rdi,%rbx
 1017390:	cmp    $0x19,%edx
 1017393:	jae    10173fb <myl_print_integer+0x7b>
 1017395:	mov    %r8d,%r15d
 1017398:	mov    %ecx,%r14d
 101739b:	movq   $0x0,-0x20(%rbp)
 10173a3:	mov    %ecx,%edx
 10173a5:	lea    -0x20(%rbp),%rdi
 10173a9:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 10173ae:	lea    0x0(,%r14,8),%eax
 10173b6:	cmp    $0x8,%r14d
 10173ba:	mov    $0xffffffffffffffff,%rsi
 10173c1:	shlx   %rax,%rsi,%rdx
 10173c6:	mov    %rdx,%rcx
 10173c9:	not    %rcx
 10173cc:	cmovae %rsi,%rcx
 10173d0:	mov    -0x20(%rbp),%rsi
 10173d4:	and    %rsi,%rcx
 10173d7:	test   %r15d,%r15d
 10173da:	je     1017414 <myl_print_integer+0x94>
 10173dc:	cmp    $0x7,%r14d
 10173e0:	ja     10173f2 <myl_print_integer+0x72>
 10173e2:	dec    %al
 10173e4:	movzbl %al,%eax
 10173e7:	or     %rdx,%rsi
 10173ea:	bt     %rax,%rcx
 10173ee:	cmovb  %rsi,%rcx
 10173f2:	lea    -0x15969(%rip),%rdx        # 1001a90 <__abi_tag+0x1794>
 10173f9:	jmp    101741b <myl_print_integer+0x9b>
 10173fb:	lea    -0x15631(%rip),%rsi        # 1001dd1 <__abi_tag+0x1ad5>
 1017402:	mov    %rbx,%rdi
 1017405:	add    $0x28,%rsp
 1017409:	pop    %rbx
 101740a:	pop    %r14
 101740c:	pop    %r15
 101740e:	pop    %rbp
 101740f:	jmp    10172c0 <literal>
 1017414:	lea    -0x15c86(%rip),%rdx        # 1001795 <__abi_tag+0x1499>
 101741b:	lea    -0x40(%rbp),%rdi
 101741f:	mov    $0x18,%esi
 1017424:	xor    %eax,%eax
 1017426:	call   101f060 <snprintf@plt>
 101742b:	test   %eax,%eax
 101742d:	jle    10174c8 <myl_print_integer+0x148>
 1017433:	cmpl   $0x0,0x18(%rbx)
 1017437:	jne    10174c8 <myl_print_integer+0x148>
 101743d:	mov    %eax,%r14d
 1017440:	mov    0x8(%rbx),%rdi
 1017444:	mov    %rdi,%rax
 1017447:	add    %r14,%rax
 101744a:	jae    1017455 <myl_print_integer+0xd5>
 101744c:	movl   $0x1,0x18(%rbx)
 1017453:	jmp    10174c8 <myl_print_integer+0x148>
 1017455:	mov    0x10(%rbx),%rax
 1017459:	mov    %rax,%rcx
 101745c:	sub    %rdi,%rcx
 101745f:	cmp    %r14,%rcx
 1017462:	jae    1017495 <myl_print_integer+0x115>
 1017464:	test   %rax,%rax
 1017467:	mov    $0x40,%r15d
 101746d:	cmovne %rax,%r15
 1017471:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1017480:	mov    %r15,%rax
 1017483:	sub    %rdi,%rax
 1017486:	cmp    %r14,%rax
 1017489:	jae    101749a <myl_print_integer+0x11a>
 101748b:	test   %r15,%r15
 101748e:	js     101744c <myl_print_integer+0xcc>
 1017490:	add    %r15,%r15
 1017493:	jmp    1017480 <myl_print_integer+0x100>
 1017495:	mov    (%rbx),%rax
 1017498:	jmp    10174b5 <myl_print_integer+0x135>
 101749a:	mov    (%rbx),%rdi
 101749d:	mov    %r15,%rsi
 10174a0:	call   101f180 <realloc@plt>
 10174a5:	test   %rax,%rax
 10174a8:	je     101744c <myl_print_integer+0xcc>
 10174aa:	mov    %rax,(%rbx)
 10174ad:	mov    %r15,0x10(%rbx)
 10174b1:	mov    0x8(%rbx),%rdi
 10174b5:	add    %rax,%rdi
 10174b8:	lea    -0x40(%rbp),%rsi
 10174bc:	mov    %r14,%rdx
 10174bf:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 10174c4:	add    %r14,0x8(%rbx)
 10174c8:	add    $0x28,%rsp
 10174cc:	pop    %rbx
 10174cd:	pop    %r14
 10174cf:	pop    %r15
 10174d1:	pop    %rbp
 10174d2:	ret
 10174d3:	int3
 10174d4:	int3
 10174d5:	int3
 10174d6:	int3
 10174d7:	int3
 10174d8:	int3
 10174d9:	int3
 10174da:	int3
 10174db:	int3
 10174dc:	int3
 10174dd:	int3
 10174de:	int3
 10174df:	int3

00000000010174e0 <mylang_scoped_endpoint>:
 10174e0:	push   %rbp
 10174e1:	mov    %rsp,%rbp
 10174e4:	push   %r15
 10174e6:	push   %r14
 10174e8:	push   %r13
 10174ea:	push   %r12
 10174ec:	push   %rbx
 10174ed:	sub    $0x58,%rsp
 10174f1:	mov    %rsi,%r15
 10174f4:	mov    %rdi,%r13
 10174f7:	mov    %rsi,%rdi
 10174fa:	call   101e660 <compiler_rt.strlen>
 10174ff:	mov    %rax,%r14
 1017502:	add    $0xffffffffffffefff,%rax
 1017508:	cmp    $0xfffffffffffff000,%rax
 101750e:	jb     101751d <mylang_scoped_endpoint+0x3d>
 1017510:	mov    0x28e8(%r13),%rbx
 1017517:	cmp    $0x7,%rbx
 101751b:	jbe    101752e <mylang_scoped_endpoint+0x4e>
 101751d:	xor    %eax,%eax
 101751f:	add    $0x58,%rsp
 1017523:	pop    %rbx
 1017524:	pop    %r12
 1017526:	pop    %r13
 1017528:	pop    %r14
 101752a:	pop    %r15
 101752c:	pop    %rbp
 101752d:	ret
 101752e:	cmp    $0x1,%r14
 1017532:	jne    1017589 <mylang_scoped_endpoint+0xa9>
 1017534:	cmpb   $0x2a,(%r15)
 1017538:	jne    1017589 <mylang_scoped_endpoint+0xa9>
 101753a:	mov    %r13,-0x30(%rbp)
 101753e:	test   %rbx,%rbx
 1017541:	je     101763c <mylang_scoped_endpoint+0x15c>
 1017547:	mov    -0x30(%rbp),%rax
 101754b:	lea    0x2870(%rax),%r12
 1017552:	mov    %rbx,%r13
 1017555:	jmp    101756d <mylang_scoped_endpoint+0x8d>
 1017557:	nopw   0x0(%rax,%rax,1)
 1017560:	add    $0x10,%r12
 1017564:	dec    %r13
 1017567:	je     101763c <mylang_scoped_endpoint+0x15c>
 101756d:	cmp    %r14,(%r12)
 1017571:	jne    1017560 <mylang_scoped_endpoint+0x80>
 1017573:	mov    -0x8(%r12),%rdi
 1017578:	mov    %r15,%rsi
 101757b:	mov    %r14,%rdx
 101757e:	call   101e680 <bcmp>
 1017583:	test   %eax,%eax
 1017585:	jne    1017560 <mylang_scoped_endpoint+0x80>
 1017587:	jmp    101751d <mylang_scoped_endpoint+0x3d>
 1017589:	mov    %r15,%rdi
 101758c:	mov    $0x3a,%esi
 1017591:	call   101f200 <strrchr@plt>
 1017596:	test   %rax,%rax
 1017599:	je     101751d <mylang_scoped_endpoint+0x3d>
 101759b:	mov    %rax,%r12
 101759e:	sub    %r15,%r12
 10175a1:	je     101751d <mylang_scoped_endpoint+0x3d>
 10175a7:	cmp    $0x3f,%r12
 10175ab:	ja     101751d <mylang_scoped_endpoint+0x3d>
 10175b1:	lea    -0x80(%rbp),%rdi
 10175b5:	mov    %r15,%rsi
 10175b8:	mov    %r12,%rdx
 10175bb:	mov    %r13,%rbx
 10175be:	mov    %rax,%r13
 10175c1:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 10175c6:	movb   $0x0,-0x80(%rbp,%r12,1)
 10175cc:	inc    %r13
 10175cf:	mov    %r13,%rdi
 10175d2:	mov    %rbx,%r13
 10175d5:	xor    %esi,%esi
 10175d7:	mov    $0xa,%edx
 10175dc:	call   101f210 <strtoul@plt>
 10175e1:	lea    -0x10000(%rax),%rcx
 10175e8:	cmp    $0xffffffffffff0001,%rcx
 10175ef:	jb     101751d <mylang_scoped_endpoint+0x3d>
 10175f5:	lea    -0x3c(%rbp),%rdx
 10175f9:	movl   $0x0,-0x34(%rbp)
 1017600:	movq   $0x0,-0x3c(%rbp)
 1017608:	movw   $0x2,-0x40(%rbp)
 101760e:	movbe  %ax,-0x3e(%rbp)
 1017614:	lea    -0x80(%rbp),%rsi
 1017618:	mov    $0x2,%edi
 101761d:	call   101f220 <inet_pton@plt>
 1017622:	cmp    $0x1,%eax
 1017625:	mov    $0x0,%eax
 101762a:	jne    101751f <mylang_scoped_endpoint+0x3f>
 1017630:	mov    0x28e8(%r13),%rbx
 1017637:	jmp    101753a <mylang_scoped_endpoint+0x5a>
 101763c:	mov    %r14,%rdi
 101763f:	inc    %rdi
 1017642:	call   101f070 <malloc@plt>
 1017647:	mov    %rax,%r12
 101764a:	mov    $0x0,%eax
 101764f:	test   %r12,%r12
 1017652:	mov    -0x30(%rbp),%r13
 1017656:	je     101751f <mylang_scoped_endpoint+0x3f>
 101765c:	mov    %r12,%rdi
 101765f:	mov    %r15,%rsi
 1017662:	mov    %r14,%rdx
 1017665:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101766a:	movb   $0x0,(%r12,%r14,1)
 101766f:	mov    %rbx,%rax
 1017672:	shl    $0x4,%rax
 1017676:	mov    %r12,0x2868(%r13,%rax,1)
 101767e:	mov    %r14,0x2870(%r13,%rax,1)
 1017686:	inc    %rbx
 1017689:	mov    %rbx,0x28e8(%r13)
 1017690:	mov    $0x1,%eax
 1017695:	jmp    101751f <mylang_scoped_endpoint+0x3f>
 101769a:	int3
 101769b:	int3
 101769c:	int3
 101769d:	int3
 101769e:	int3
 101769f:	int3

00000000010176a0 <mylang_scoped_network_provider>:
 10176a0:	push   %rbp
 10176a1:	mov    %rsp,%rbp
 10176a4:	mov    %rdi,%rax
 10176a7:	movq   $0x0,0x8(%rdi)
 10176af:	mov    %rsi,(%rdi)
 10176b2:	mov    %edx,0x8(%rdi)
 10176b5:	lea    0x34(%rip),%rcx        # 10176f0 <acquire_network>
 10176bc:	mov    %rcx,0x10(%rdi)
 10176c0:	lea    0x269(%rip),%rcx        # 1017930 <complete>
 10176c7:	mov    %rcx,0x18(%rdi)
 10176cb:	lea    0x2ce(%rip),%rcx        # 10179a0 <release>
 10176d2:	mov    %rcx,0x20(%rdi)
 10176d6:	lea    0x323(%rip),%rcx        # 1017a00 <read_handle>
 10176dd:	mov    %rcx,0x28(%rdi)
 10176e1:	lea    0x458(%rip),%rcx        # 1017b40 <write_handle>
 10176e8:	mov    %rcx,0x30(%rdi)
 10176ec:	pop    %rbp
 10176ed:	ret
 10176ee:	int3
 10176ef:	int3

00000000010176f0 <acquire_network>:
 10176f0:	push   %rbp
 10176f1:	mov    %rsp,%rbp
 10176f4:	push   %r15
 10176f6:	push   %r14
 10176f8:	push   %r13
 10176fa:	push   %r12
 10176fc:	push   %rbx
 10176fd:	sub    $0xe8,%rsp
 1017704:	mov    0x28e8(%rdi),%r12
 101770b:	test   %r12,%r12
 101770e:	je     10178dd <acquire_network+0x1ed>
 1017714:	test   $0x3,%cl
 1017717:	je     10178e4 <acquire_network+0x1f4>
 101771d:	mov    %rdx,%r13
 1017720:	mov    $0x2,%eax
 1017725:	cmp    $0x7f,%rdx
 1017729:	ja     10178e9 <acquire_network+0x1f9>
 101772f:	mov    %rdi,%r14
 1017732:	lea    -0x110(%rbp),%rdi
 1017739:	mov    %r13,%rdx
 101773c:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1017741:	movb   $0x0,-0x110(%rbp,%r13,1)
 101774a:	lea    0x2868(%r14),%r15
 1017751:	xor    %ebx,%ebx
 1017753:	jmp    101776d <acquire_network+0x7d>
 1017755:	data16 cs nopw 0x0(%rax,%rax,1)
 1017760:	add    $0x10,%r15
 1017764:	dec    %r12
 1017767:	je     1017903 <acquire_network+0x213>
 101776d:	mov    0x8(%r15),%rax
 1017771:	cmp    $0x1,%rax
 1017775:	jne    101777f <acquire_network+0x8f>
 1017777:	mov    (%r15),%rcx
 101777a:	cmpb   $0x2a,(%rcx)
 101777d:	je     101779a <acquire_network+0xaa>
 101777f:	cmp    %r13,%rax
 1017782:	jne    1017760 <acquire_network+0x70>
 1017784:	mov    (%r15),%rdi
 1017787:	lea    -0x110(%rbp),%rsi
 101778e:	mov    %r13,%rdx
 1017791:	call   101e680 <bcmp>
 1017796:	test   %eax,%eax
 1017798:	jne    1017760 <acquire_network+0x70>
 101779a:	add    $0x68,%r14
 101779e:	xor    %ebx,%ebx
 10177a0:	mov    $0x2,%eax
 10177a5:	jmp    10177c5 <acquire_network+0xd5>
 10177a7:	nopw   0x0(%rax,%rax,1)
 10177b0:	add    $0x2,%rbx
 10177b4:	add    $0x50,%r14
 10177b8:	cmp    $0x100,%rbx
 10177bf:	je     10178e9 <acquire_network+0x1f9>
 10177c5:	cmpl   $0x0,(%r14)
 10177c9:	jns    10177d2 <acquire_network+0xe2>
 10177cb:	cmpq   $0x0,0x8(%r14)
 10177d0:	je     10177e7 <acquire_network+0xf7>
 10177d2:	cmpl   $0x0,0x28(%r14)
 10177d7:	jns    10177b0 <acquire_network+0xc0>
 10177d9:	cmpq   $0x0,0x30(%r14)
 10177de:	jne    10177b0 <acquire_network+0xc0>
 10177e0:	inc    %rbx
 10177e3:	add    $0x28,%r14
 10177e7:	lea    -0x110(%rbp),%r12
 10177ee:	mov    %r12,%rdi
 10177f1:	mov    $0x3a,%esi
 10177f6:	call   101f200 <strrchr@plt>
 10177fb:	mov    %rax,%r15
 10177fe:	sub    %r12,%r15
 1017801:	sete   %cl
 1017804:	test   %rax,%rax
 1017807:	je     10178d6 <acquire_network+0x1e6>
 101780d:	test   %cl,%cl
 101780f:	jne    10178d6 <acquire_network+0x1e6>
 1017815:	cmp    $0x3f,%r15
 1017819:	ja     10178d6 <acquire_network+0x1e6>
 101781f:	lea    -0x90(%rbp),%rdi
 1017826:	lea    -0x110(%rbp),%rsi
 101782d:	mov    %r15,%rdx
 1017830:	mov    %rax,%r12
 1017833:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1017838:	movb   $0x0,-0x90(%rbp,%r15,1)
 1017841:	inc    %r12
 1017844:	mov    %r12,%rdi
 1017847:	xor    %esi,%esi
 1017849:	mov    $0xa,%edx
 101784e:	call   101f210 <strtoul@plt>
 1017853:	lea    -0x10000(%rax),%rcx
 101785a:	cmp    $0xffffffffffff0001,%rcx
 1017861:	jb     10178d6 <acquire_network+0x1e6>
 1017863:	lea    -0x34(%rbp),%rdx
 1017867:	movl   $0x0,-0x2c(%rbp)
 101786e:	movq   $0x0,-0x34(%rbp)
 1017876:	movw   $0x2,-0x38(%rbp)
 101787c:	movbe  %ax,-0x36(%rbp)
 1017882:	lea    -0x90(%rbp),%rsi
 1017889:	mov    $0x2,%edi
 101788e:	call   101f220 <inet_pton@plt>
 1017893:	cmp    $0x1,%eax
 1017896:	jne    10178d6 <acquire_network+0x1e6>
 1017898:	vmovups -0x38(%rbp),%xmm0
 101789d:	vmovaps %xmm0,-0x50(%rbp)
 10178a2:	mov    $0x2,%edi
 10178a7:	mov    $0x1,%esi
 10178ac:	xor    %edx,%edx
 10178ae:	call   101f230 <socket@plt>
 10178b3:	test   %eax,%eax
 10178b5:	js     10178d6 <acquire_network+0x1e6>
 10178b7:	mov    %eax,%r15d
 10178ba:	lea    -0x50(%rbp),%rsi
 10178be:	mov    %eax,%edi
 10178c0:	mov    $0x10,%edx
 10178c5:	call   101f240 <connect@plt>
 10178ca:	test   %eax,%eax
 10178cc:	je     101790a <acquire_network+0x21a>
 10178ce:	mov    %r15d,%edi
 10178d1:	call   101f250 <close@plt>
 10178d6:	mov    $0x3,%eax
 10178db:	jmp    10178e9 <acquire_network+0x1f9>
 10178dd:	mov    $0x1,%eax
 10178e2:	jmp    10178e9 <acquire_network+0x1f9>
 10178e4:	mov    $0x2,%eax
 10178e9:	xor    %ebx,%ebx
 10178eb:	mov    %rbx,%rdx
 10178ee:	add    $0xe8,%rsp
 10178f5:	pop    %rbx
 10178f6:	pop    %r12
 10178f8:	pop    %r13
 10178fa:	pop    %r14
 10178fc:	pop    %r15
 10178fe:	pop    %rbp
 10178ff:	vzeroupper
 1017902:	ret
 1017903:	mov    $0x2,%eax
 1017908:	jmp    10178eb <acquire_network+0x1fb>
 101790a:	mov    %r15d,(%r14)
 101790d:	vxorps %xmm0,%xmm0,%xmm0
 1017911:	vmovups %ymm0,0x4(%r14)
 1017917:	movl   $0x0,0x24(%r14)
 101791f:	xor    %eax,%eax
 1017921:	jmp    10178eb <acquire_network+0x1fb>
 1017923:	int3
 1017924:	int3
 1017925:	int3
 1017926:	int3
 1017927:	int3
 1017928:	int3
 1017929:	int3
 101792a:	int3
 101792b:	int3
 101792c:	int3
 101792d:	int3
 101792e:	int3
 101792f:	int3

0000000001017930 <complete>:
 1017930:	mov    $0x3,%eax
 1017935:	cmp    $0xff,%rsi
 101793c:	ja     101798f <complete+0x5f>
 101793e:	push   %rbp
 101793f:	mov    %rsp,%rbp
 1017942:	push   %rbx
 1017943:	push   %rax
 1017944:	lea    (%rsi,%rsi,4),%rcx
 1017948:	lea    (%rdi,%rcx,8),%rbx
 101794c:	add    $0x68,%rbx
 1017950:	mov    0x68(%rdi,%rcx,8),%edi
 1017954:	test   %edi,%edi
 1017956:	js     1017963 <complete+0x33>
 1017958:	call   101f250 <close@plt>
 101795d:	mov    0x8(%rbx),%rdi
 1017961:	jmp    101796c <complete+0x3c>
 1017963:	mov    0x8(%rbx),%rdi
 1017967:	test   %rdi,%rdi
 101796a:	je     1017989 <complete+0x59>
 101796c:	call   101efd0 <free@plt>
 1017971:	movl   $0xffffffff,(%rbx)
 1017977:	vxorps %xmm0,%xmm0,%xmm0
 101797b:	vmovups %ymm0,0x4(%rbx)
 1017980:	movl   $0x0,0x24(%rbx)
 1017987:	xor    %eax,%eax
 1017989:	add    $0x8,%rsp
 101798d:	pop    %rbx
 101798e:	pop    %rbp
 101798f:	vzeroupper
 1017992:	ret
 1017993:	int3
 1017994:	int3
 1017995:	int3
 1017996:	int3
 1017997:	int3
 1017998:	int3
 1017999:	int3
 101799a:	int3
 101799b:	int3
 101799c:	int3
 101799d:	int3
 101799e:	int3
 101799f:	int3

00000000010179a0 <release>:
 10179a0:	push   %rbp
 10179a1:	mov    %rsp,%rbp
 10179a4:	push   %rbx
 10179a5:	push   %rax
 10179a6:	cmp    $0xff,%rsi
 10179ad:	ja     10179f2 <release+0x52>
 10179af:	lea    (%rsi,%rsi,4),%rax
 10179b3:	lea    (%rdi,%rax,8),%rbx
 10179b7:	add    $0x68,%rbx
 10179bb:	mov    0x68(%rdi,%rax,8),%edi
 10179bf:	test   %edi,%edi
 10179c1:	js     10179ce <release+0x2e>
 10179c3:	call   101f250 <close@plt>
 10179c8:	mov    0x8(%rbx),%rdi
 10179cc:	jmp    10179d7 <release+0x37>
 10179ce:	mov    0x8(%rbx),%rdi
 10179d2:	test   %rdi,%rdi
 10179d5:	je     10179f2 <release+0x52>
 10179d7:	call   101efd0 <free@plt>
 10179dc:	movl   $0xffffffff,(%rbx)
 10179e2:	vxorps %xmm0,%xmm0,%xmm0
 10179e6:	vmovups %ymm0,0x4(%rbx)
 10179eb:	movl   $0x0,0x24(%rbx)
 10179f2:	add    $0x8,%rsp
 10179f6:	pop    %rbx
 10179f7:	pop    %rbp
 10179f8:	vzeroupper
 10179fb:	ret
 10179fc:	int3
 10179fd:	int3
 10179fe:	int3
 10179ff:	int3

0000000001017a00 <read_handle>:
 1017a00:	mov    %rdi,%rax
 1017a03:	vmovups -0x148e3(%rip),%xmm0        # 1003128 <myl_rc_map_sentinel+0x88>
 1017a0b:	vmovups %xmm0,(%rdi)
 1017a0f:	movq   $0x0,0x10(%rdi)
 1017a17:	cmp    $0xff,%rdx
 1017a1e:	ja     1017b2c <read_handle+0x12c>
 1017a24:	push   %rbp
 1017a25:	mov    %rsp,%rbp
 1017a28:	push   %r15
 1017a2a:	push   %r14
 1017a2c:	push   %rbx
 1017a2d:	push   %rax
 1017a2e:	lea    (%rdx,%rdx,4),%rdx
 1017a32:	lea    (%rsi,%rdx,8),%r15
 1017a36:	add    $0x68,%r15
 1017a3a:	mov    0x68(%rsi,%rdx,8),%edi
 1017a3e:	test   %edi,%edi
 1017a40:	jns    1017a4d <read_handle+0x4d>
 1017a42:	cmpq   $0x0,0x8(%r15)
 1017a47:	je     1017b22 <read_handle+0x122>
 1017a4d:	test   %r8,%r8
 1017a50:	je     1017ab6 <read_handle+0xb6>
 1017a52:	mov    %rax,%r14
 1017a55:	cmp    $0x10000,%r8
 1017a5c:	mov    $0x10000,%edx
 1017a61:	cmovb  %r8,%rdx
 1017a65:	mov    0x8(%r15),%rsi
 1017a69:	test   %rsi,%rsi
 1017a6c:	je     1017abe <read_handle+0xbe>
 1017a6e:	mov    0x10(%r15),%rbx
 1017a72:	mov    0x18(%r15),%rax
 1017a76:	sub    %rax,%rbx
 1017a79:	cmp    %rdx,%rbx
 1017a7c:	cmovae %rdx,%rbx
 1017a80:	add    %rax,%rsi
 1017a83:	mov    %rcx,%rdi
 1017a86:	mov    %rbx,%rdx
 1017a89:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1017a8e:	mov    0x18(%r15),%rcx
 1017a92:	add    %rbx,%rcx
 1017a95:	mov    %rcx,0x18(%r15)
 1017a99:	mov    %r14,%rax
 1017a9c:	movl   $0x0,(%r14)
 1017aa3:	mov    %rbx,0x8(%r14)
 1017aa7:	xor    %edx,%edx
 1017aa9:	cmp    0x10(%r15),%rcx
 1017aad:	sete   %dl
 1017ab0:	mov    %edx,0x10(%r14)
 1017ab4:	jmp    1017b22 <read_handle+0x122>
 1017ab6:	movl   $0x0,(%rax)
 1017abc:	jmp    1017b22 <read_handle+0x122>
 1017abe:	cmpb   $0x61,0x20(%r15)
 1017ac3:	jne    1017ad1 <read_handle+0xd1>
 1017ac5:	mov    %r14,%rax
 1017ac8:	movl   $0x2,(%r14)
 1017acf:	jmp    1017b22 <read_handle+0x122>
 1017ad1:	mov    %rcx,%rsi
 1017ad4:	call   101f260 <read@plt>
 1017ad9:	test   %rax,%rax
 1017adc:	js     1017afb <read_handle+0xfb>
 1017ade:	mov    %rax,%rcx
 1017ae1:	mov    %r14,%rax
 1017ae4:	movl   $0x0,(%r14)
 1017aeb:	mov    %rcx,0x8(%r14)
 1017aef:	sete   %cl
 1017af2:	movzbl %cl,%ecx
 1017af5:	mov    %ecx,0x10(%r14)
 1017af9:	jmp    1017b22 <read_handle+0x122>
 1017afb:	call   101f270 <__errno_location@plt>
 1017b00:	mov    (%rax),%edx
 1017b02:	cmp    $0x28,%rdx
 1017b06:	mov    %r14,%rax
 1017b09:	ja     1017b38 <read_handle+0x138>
 1017b0b:	movabs $0x10000102002,%rcx
 1017b15:	bt     %rdx,%rcx
 1017b19:	jae    1017b2d <read_handle+0x12d>
 1017b1b:	mov    $0x2,%ecx
 1017b20:	mov    %ecx,(%rax)
 1017b22:	add    $0x8,%rsp
 1017b26:	pop    %rbx
 1017b27:	pop    %r14
 1017b29:	pop    %r15
 1017b2b:	pop    %rbp
 1017b2c:	ret
 1017b2d:	mov    $0x4,%ecx
 1017b32:	cmp    $0xc,%rdx
 1017b36:	je     1017b20 <read_handle+0x120>
 1017b38:	mov    $0x3,%ecx
 1017b3d:	jmp    1017b20 <read_handle+0x120>
 1017b3f:	int3

0000000001017b40 <write_handle>:
 1017b40:	mov    $0x3,%eax
 1017b45:	cmp    $0xff,%rsi
 1017b4c:	jbe    1017b51 <write_handle+0x11>
 1017b4e:	xor    %edx,%edx
 1017b50:	ret
 1017b51:	mov    %rdi,%r8
 1017b54:	lea    (%rsi,%rsi,4),%rax
 1017b58:	mov    0x68(%rdi,%rax,8),%edi
 1017b5c:	mov    0x70(%r8,%rax,8),%rsi
 1017b61:	test   %edi,%edi
 1017b63:	js     1017b72 <write_handle+0x32>
 1017b65:	test   %rsi,%rsi
 1017b68:	je     1017b81 <write_handle+0x41>
 1017b6a:	xor    %edx,%edx
 1017b6c:	mov    $0x2,%eax
 1017b71:	ret
 1017b72:	xor    %edx,%edx
 1017b74:	cmp    $0x1,%rsi
 1017b78:	mov    $0x0,%eax
 1017b7d:	adc    $0x2,%eax
 1017b80:	ret
 1017b81:	push   %rbp
 1017b82:	mov    %rsp,%rbp
 1017b85:	push   %r15
 1017b87:	push   %r14
 1017b89:	push   %rbx
 1017b8a:	push   %rax
 1017b8b:	lea    (%r8,%rax,8),%r15
 1017b8f:	add    $0x68,%r15
 1017b93:	cmp    $0x10000,%rcx
 1017b9a:	mov    $0x10000,%ebx
 1017b9f:	cmovb  %rcx,%rbx
 1017ba3:	cmpb   $0x61,0x20(%r15)
 1017ba8:	jne    1017bd1 <write_handle+0x91>
 1017baa:	mov    %rdx,%r14
 1017bad:	xor    %esi,%esi
 1017baf:	mov    $0x2,%edx
 1017bb4:	call   101f280 <lseek@plt>
 1017bb9:	test   %rax,%rax
 1017bbc:	js     1017c0c <write_handle+0xcc>
 1017bbe:	mov    (%r15),%edi
 1017bc1:	mov    %r14,%rsi
 1017bc4:	mov    %rbx,%rdx
 1017bc7:	mov    %rax,%rcx
 1017bca:	call   101f290 <pwrite@plt>
 1017bcf:	jmp    1017bdc <write_handle+0x9c>
 1017bd1:	mov    %rdx,%rsi
 1017bd4:	mov    %rbx,%rdx
 1017bd7:	call   101f0c0 <write@plt>
 1017bdc:	mov    %rax,%rdx
 1017bdf:	xor    %eax,%eax
 1017be1:	test   %rdx,%rdx
 1017be4:	jns    1017c46 <write_handle+0x106>
 1017be6:	call   101f270 <__errno_location@plt>
 1017beb:	mov    (%rax),%eax
 1017bed:	cmp    $0x28,%rax
 1017bf1:	ja     1017c3f <write_handle+0xff>
 1017bf3:	movabs $0x10000102002,%rcx
 1017bfd:	bt     %rax,%rcx
 1017c01:	jae    1017c30 <write_handle+0xf0>
 1017c03:	xor    %edx,%edx
 1017c05:	mov    $0x2,%eax
 1017c0a:	jmp    1017c46 <write_handle+0x106>
 1017c0c:	call   101f270 <__errno_location@plt>
 1017c11:	mov    (%rax),%eax
 1017c13:	cmp    $0x28,%rax
 1017c17:	ja     1017c3f <write_handle+0xff>
 1017c19:	movabs $0x10000102002,%rcx
 1017c23:	bt     %rax,%rcx
 1017c27:	jae    1017c30 <write_handle+0xf0>
 1017c29:	mov    $0x2,%eax
 1017c2e:	jmp    1017c3b <write_handle+0xfb>
 1017c30:	cmp    $0xc,%rax
 1017c34:	jne    1017c3f <write_handle+0xff>
 1017c36:	mov    $0x4,%eax
 1017c3b:	xor    %edx,%edx
 1017c3d:	jmp    1017c46 <write_handle+0x106>
 1017c3f:	xor    %edx,%edx
 1017c41:	mov    $0x3,%eax
 1017c46:	add    $0x8,%rsp
 1017c4a:	pop    %rbx
 1017c4b:	pop    %r14
 1017c4d:	pop    %r15
 1017c4f:	pop    %rbp
 1017c50:	ret
 1017c51:	int3
 1017c52:	int3
 1017c53:	int3
 1017c54:	int3
 1017c55:	int3
 1017c56:	int3
 1017c57:	int3
 1017c58:	int3
 1017c59:	int3
 1017c5a:	int3
 1017c5b:	int3
 1017c5c:	int3
 1017c5d:	int3
 1017c5e:	int3
 1017c5f:	int3

0000000001017c60 <mylang_scoped_init>:
 1017c60:	push   %rbp
 1017c61:	mov    %rsp,%rbp
 1017c64:	push   %rbx
 1017c65:	push   %rax
 1017c66:	mov    %rdi,%rbx
 1017c69:	mov    $0x28f0,%edx
 1017c6e:	xor    %esi,%esi
 1017c70:	call   101e6b0 <compiler_rt.fastMemset>
 1017c75:	mov    $0xe0,%eax
 1017c7a:	nopw   0x0(%rax,%rax,1)
 1017c80:	movl   $0xffffffff,-0x78(%rbx,%rax,1)
 1017c88:	movl   $0xffffffff,-0x50(%rbx,%rax,1)
 1017c90:	movl   $0xffffffff,-0x28(%rbx,%rax,1)
 1017c98:	movl   $0xffffffff,(%rbx,%rax,1)
 1017c9f:	add    $0xa0,%rax
 1017ca5:	cmp    $0x28e0,%rax
 1017cab:	jne    1017c80 <mylang_scoped_init+0x20>
 1017cad:	add    $0x8,%rsp
 1017cb1:	pop    %rbx
 1017cb2:	pop    %rbp
 1017cb3:	ret
 1017cb4:	int3
 1017cb5:	int3
 1017cb6:	int3
 1017cb7:	int3
 1017cb8:	int3
 1017cb9:	int3
 1017cba:	int3
 1017cbb:	int3
 1017cbc:	int3
 1017cbd:	int3
 1017cbe:	int3
 1017cbf:	int3

0000000001017cc0 <mylang_scoped_grant>:
 1017cc0:	push   %rbp
 1017cc1:	mov    %rsp,%rbp
 1017cc4:	push   %r15
 1017cc6:	push   %r14
 1017cc8:	push   %rbx
 1017cc9:	push   %rax
 1017cca:	xor    %r15d,%r15d
 1017ccd:	cmpq   $0x7,0x60(%rdi)
 1017cd2:	ja     1017d17 <mylang_scoped_grant+0x57>
 1017cd4:	mov    %edx,%ebx
 1017cd6:	mov    %rdi,%r14
 1017cd9:	xor    %r15d,%r15d
 1017cdc:	mov    %rsi,%rdi
 1017cdf:	mov    $0x90000,%esi
 1017ce4:	xor    %eax,%eax
 1017ce6:	call   101f2a0 <open@plt>
 1017ceb:	test   %eax,%eax
 1017ced:	js     1017d17 <mylang_scoped_grant+0x57>
 1017cef:	mov    0x60(%r14),%rcx
 1017cf3:	lea    0x1(%rcx),%rdx
 1017cf7:	mov    %rdx,0x60(%r14)
 1017cfb:	lea    (%rcx,%rcx,2),%rcx
 1017cff:	mov    %eax,(%r14,%rcx,4)
 1017d03:	mov    %ebx,0x4(%r14,%rcx,4)
 1017d08:	movl   $0x0,0x8(%r14,%rcx,4)
 1017d11:	mov    $0x1,%r15d
 1017d17:	mov    %r15d,%eax
 1017d1a:	add    $0x8,%rsp
 1017d1e:	pop    %rbx
 1017d1f:	pop    %r14
 1017d21:	pop    %r15
 1017d23:	pop    %rbp
 1017d24:	ret
 1017d25:	int3
 1017d26:	int3
 1017d27:	int3
 1017d28:	int3
 1017d29:	int3
 1017d2a:	int3
 1017d2b:	int3
 1017d2c:	int3
 1017d2d:	int3
 1017d2e:	int3
 1017d2f:	int3

0000000001017d30 <mylang_scoped_working_directory>:
 1017d30:	push   %rbp
 1017d31:	mov    %rsp,%rbp
 1017d34:	push   %r14
 1017d36:	push   %rbx
 1017d37:	xor    %r14d,%r14d
 1017d3a:	cmpq   $0x7,0x60(%rdi)
 1017d3f:	ja     1017d86 <mylang_scoped_working_directory+0x56>
 1017d41:	mov    %rdi,%rbx
 1017d44:	lea    -0x15f78(%rip),%rdi        # 1001dd3 <__abi_tag+0x1ad7>
 1017d4b:	xor    %r14d,%r14d
 1017d4e:	mov    $0x90000,%esi
 1017d53:	xor    %eax,%eax
 1017d55:	call   101f2a0 <open@plt>
 1017d5a:	test   %eax,%eax
 1017d5c:	js     1017d86 <mylang_scoped_working_directory+0x56>
 1017d5e:	mov    0x60(%rbx),%rcx
 1017d62:	lea    0x1(%rcx),%rdx
 1017d66:	mov    %rdx,0x60(%rbx)
 1017d6a:	lea    (%rcx,%rcx,2),%rcx
 1017d6e:	mov    %eax,(%rbx,%rcx,4)
 1017d71:	movabs $0x100000001,%rax
 1017d7b:	mov    %rax,0x4(%rbx,%rcx,4)
 1017d80:	mov    $0x1,%r14d
 1017d86:	mov    %r14d,%eax
 1017d89:	pop    %rbx
 1017d8a:	pop    %r14
 1017d8c:	pop    %rbp
 1017d8d:	ret
 1017d8e:	int3
 1017d8f:	int3

0000000001017d90 <mylang_scoped_close>:
 1017d90:	push   %rbp
 1017d91:	mov    %rsp,%rbp
 1017d94:	push   %r15
 1017d96:	push   %r14
 1017d98:	push   %rbx
 1017d99:	push   %rax
 1017d9a:	mov    %rdi,%rbx
 1017d9d:	mov    $0x70,%r14d
 1017da3:	jmp    1017dee <mylang_scoped_close+0x5e>
 1017da5:	data16 cs nopw 0x0(%rax,%rax,1)
 1017db0:	vzeroupper
 1017db3:	call   101f250 <close@plt>
 1017db8:	mov    (%rbx,%r14,1),%rdi
 1017dbc:	vzeroupper
 1017dbf:	call   101efd0 <free@plt>
 1017dc4:	movl   $0xffffffff,-0x8(%rbx,%r14,1)
 1017dcd:	vxorps %xmm0,%xmm0,%xmm0
 1017dd1:	vmovups %ymm0,-0x4(%rbx,%r14,1)
 1017dd8:	movl   $0x0,0x1c(%rbx,%r14,1)
 1017de1:	add    $0x28,%r14
 1017de5:	cmp    $0x2870,%r14
 1017dec:	je     1017e02 <mylang_scoped_close+0x72>
 1017dee:	mov    -0x8(%rbx,%r14,1),%edi
 1017df3:	test   %edi,%edi
 1017df5:	jns    1017db0 <mylang_scoped_close+0x20>
 1017df7:	mov    (%rbx,%r14,1),%rdi
 1017dfb:	test   %rdi,%rdi
 1017dfe:	jne    1017dbc <mylang_scoped_close+0x2c>
 1017e00:	jmp    1017de1 <mylang_scoped_close+0x51>
 1017e02:	cmpq   $0x0,0x60(%rbx)
 1017e07:	je     1017e28 <mylang_scoped_close+0x98>
 1017e09:	xor    %r14d,%r14d
 1017e0c:	mov    %rbx,%r15
 1017e0f:	nop
 1017e10:	mov    (%r15),%edi
 1017e13:	vzeroupper
 1017e16:	call   101f250 <close@plt>
 1017e1b:	inc    %r14
 1017e1e:	add    $0xc,%r15
 1017e22:	cmp    0x60(%rbx),%r14
 1017e26:	jb     1017e10 <mylang_scoped_close+0x80>
 1017e28:	movq   $0x0,0x60(%rbx)
 1017e30:	cmpq   $0x0,0x28e8(%rbx)
 1017e38:	je     1017e6b <mylang_scoped_close+0xdb>
 1017e3a:	lea    0x2868(%rbx),%r14
 1017e41:	xor    %r15d,%r15d
 1017e44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1017e50:	mov    (%r14),%rdi
 1017e53:	vzeroupper
 1017e56:	call   101efd0 <free@plt>
 1017e5b:	inc    %r15
 1017e5e:	add    $0x10,%r14
 1017e62:	cmp    0x28e8(%rbx),%r15
 1017e69:	jb     1017e50 <mylang_scoped_close+0xc0>
 1017e6b:	movq   $0x0,0x28e8(%rbx)
 1017e76:	add    $0x8,%rsp
 1017e7a:	pop    %rbx
 1017e7b:	pop    %r14
 1017e7d:	pop    %r15
 1017e7f:	pop    %rbp
 1017e80:	vzeroupper
 1017e83:	ret
 1017e84:	int3
 1017e85:	int3
 1017e86:	int3
 1017e87:	int3
 1017e88:	int3
 1017e89:	int3
 1017e8a:	int3
 1017e8b:	int3
 1017e8c:	int3
 1017e8d:	int3
 1017e8e:	int3
 1017e8f:	int3

0000000001017e90 <mylang_scoped_provider>:
 1017e90:	push   %rbp
 1017e91:	mov    %rsp,%rbp
 1017e94:	mov    %rdi,%rax
 1017e97:	movq   $0x0,0x8(%rdi)
 1017e9f:	mov    %rsi,(%rdi)
 1017ea2:	mov    %edx,0x8(%rdi)
 1017ea5:	lea    0x34(%rip),%rcx        # 1017ee0 <acquire>
 1017eac:	mov    %rcx,0x10(%rdi)
 1017eb0:	lea    -0x587(%rip),%rcx        # 1017930 <complete>
 1017eb7:	mov    %rcx,0x18(%rdi)
 1017ebb:	lea    -0x522(%rip),%rcx        # 10179a0 <release>
 1017ec2:	mov    %rcx,0x20(%rdi)
 1017ec6:	lea    -0x4cd(%rip),%rcx        # 1017a00 <read_handle>
 1017ecd:	mov    %rcx,0x28(%rdi)
 1017ed1:	lea    -0x398(%rip),%rcx        # 1017b40 <write_handle>
 1017ed8:	mov    %rcx,0x30(%rdi)
 1017edc:	pop    %rbp
 1017edd:	ret
 1017ede:	int3
 1017edf:	int3

0000000001017ee0 <acquire>:
 1017ee0:	push   %rbp
 1017ee1:	mov    %rsp,%rbp
 1017ee4:	push   %r15
 1017ee6:	push   %r14
 1017ee8:	push   %r13
 1017eea:	push   %r12
 1017eec:	push   %rbx
 1017eed:	sub    $0x1138,%rsp
 1017ef4:	cmpq   $0x0,0x60(%rdi)
 1017ef9:	je     1017f4c <acquire+0x6c>
 1017efb:	mov    %rdx,%r8
 1017efe:	lea    -0x1001(%rdx),%rax
 1017f05:	mov    $0x2,%r9d
 1017f0b:	cmp    $0xfffffffffffff001,%rax
 1017f11:	jb     1017f52 <acquire+0x72>
 1017f13:	mov    %rsi,%r13
 1017f16:	cmpb   $0x3a,0x1(%rsi)
 1017f1a:	jne    1017f52 <acquire+0x72>
 1017f1c:	movzbl 0x0(%r13),%eax
 1017f21:	mov    %al,-0x2d(%rbp)
 1017f24:	movzbl %al,%eax
 1017f27:	xor    %ebx,%ebx
 1017f29:	lea    -0x61(%rax),%r12d
 1017f2d:	cmp    $0x17,%r12d
 1017f31:	ja     1017f54 <acquire+0x74>
 1017f33:	mov    %rax,-0xa8(%rbp)
 1017f3a:	mov    $0xc80405,%eax
 1017f3f:	bt     %r12d,%eax
 1017f43:	jae    1017f6c <acquire+0x8c>
 1017f45:	mov    $0x2,%eax
 1017f4a:	jmp    1017f7c <acquire+0x9c>
 1017f4c:	mov    $0x1,%r9d
 1017f52:	xor    %ebx,%ebx
 1017f54:	mov    %r9d,%eax
 1017f57:	mov    %rbx,%rdx
 1017f5a:	add    $0x1138,%rsp
 1017f61:	pop    %rbx
 1017f62:	pop    %r12
 1017f64:	pop    %r13
 1017f66:	pop    %r14
 1017f68:	pop    %r15
 1017f6a:	pop    %rbp
 1017f6b:	ret
 1017f6c:	mov    $0x1,%eax
 1017f71:	mov    $0x21800,%edx
 1017f76:	bt     %r12d,%edx
 1017f7a:	jae    1017f54 <acquire+0x74>
 1017f7c:	test   %ecx,%eax
 1017f7e:	je     1017f52 <acquire+0x72>
 1017f80:	add    $0x2,%r13
 1017f84:	lea    -0x2(%r8),%rdx
 1017f88:	mov    -0xa8(%rbp),%rax
 1017f8f:	mov    %eax,%ecx
 1017f91:	and    $0xfe,%cl
 1017f94:	mov    %cl,-0x51(%rbp)
 1017f97:	lea    0x68(%rdi),%rcx
 1017f9b:	mov    %rcx,-0xc8(%rbp)
 1017fa2:	xor    %ecx,%ecx
 1017fa4:	cmp    $0x72,%al
 1017fa6:	setne  %cl
 1017fa9:	mov    %ecx,-0x7c(%rbp)
 1017fac:	dec    %r8
 1017faf:	add    $0xffffff95,%eax
 1017fb2:	mov    %rax,-0xc0(%rbp)
 1017fb9:	mov    $0xc80405,%r15d
 1017fbf:	xor    %ecx,%ecx
 1017fc1:	mov    %r13,-0x70(%rbp)
 1017fc5:	mov    %rdx,-0x38(%rbp)
 1017fc9:	mov    %r8,-0x40(%rbp)
 1017fcd:	mov    %rdi,-0x68(%rbp)
 1017fd1:	mov    %r12d,-0x44(%rbp)
 1017fd5:	jmp    1017ffe <acquire+0x11e>
 1017fd7:	nopw   0x0(%rax,%rax,1)
 1017fe0:	mov    $0x2,%r9d
 1017fe6:	mov    -0x44(%rbp),%r12d
 1017fea:	mov    -0xd0(%rbp),%rcx
 1017ff1:	inc    %rcx
 1017ff4:	cmp    0x60(%rdi),%rcx
 1017ff8:	jae    1017f52 <acquire+0x72>
 1017ffe:	cmp    $0x17,%r12d
 1018002:	mov    %rcx,-0xd0(%rbp)
 1018009:	ja     101801c <acquire+0x13c>
 101800b:	bt     %r12d,%r15d
 101800f:	jae    101801c <acquire+0x13c>
 1018011:	lea    (%rcx,%rcx,2),%rax
 1018015:	cmpl   $0x0,0x4(%rdi,%rax,4)
 101801a:	je     1017fea <acquire+0x10a>
 101801c:	lea    (%rcx,%rcx,2),%rbx
 1018020:	mov    0x8(%rdi,%rbx,4),%r10d
 1018025:	test   %r10d,%r10d
 1018028:	je     1018150 <acquire+0x270>
 101802e:	lea    (%rdi,%rbx,4),%rax
 1018032:	mov    (%rax),%eax
 1018034:	mov    %eax,-0x48(%rbp)
 1018037:	mov    -0xc8(%rbp),%r12
 101803e:	xor    %ebx,%ebx
 1018040:	jmp    1018065 <acquire+0x185>
 1018042:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018050:	add    $0x2,%rbx
 1018054:	add    $0x50,%r12
 1018058:	cmp    $0x100,%rbx
 101805f:	je     1017fe0 <acquire+0x100>
 1018065:	cmpl   $0x0,(%r12)
 101806a:	jns    1018074 <acquire+0x194>
 101806c:	cmpq   $0x0,0x8(%r12)
 1018072:	je     101808b <acquire+0x1ab>
 1018074:	cmpl   $0x0,0x28(%r12)
 101807a:	jns    1018050 <acquire+0x170>
 101807c:	cmpq   $0x0,0x30(%r12)
 1018082:	jne    1018050 <acquire+0x170>
 1018084:	inc    %rbx
 1018087:	add    $0x28,%r12
 101808b:	mov    %r10d,-0x60(%rbp)
 101808f:	test   %rdx,%rdx
 1018092:	je     10181b9 <acquire+0x2d9>
 1018098:	mov    $0x0,%r14d
 101809e:	mov    -0x48(%rbp),%eax
 10180a1:	mov    %eax,-0x2c(%rbp)
 10180a4:	cmpl   $0x0,-0x60(%rbp)
 10180a8:	jne    10181c2 <acquire+0x2e2>
 10180ae:	xor    %r15d,%r15d
 10180b1:	mov    -0x48(%rbp),%eax
 10180b4:	mov    %eax,-0x2c(%rbp)
 10180b7:	xor    %r14d,%r14d
 10180ba:	jmp    10180e5 <acquire+0x205>
 10180bc:	nopl   0x0(%rax)
 10180c0:	test   %r13d,%r13d
 10180c3:	js     10182d3 <acquire+0x3f3>
 10180c9:	lea    0x1(%r15),%r14
 10180cd:	mov    %r13d,-0x2c(%rbp)
 10180d1:	mov    -0x70(%rbp),%r13
 10180d5:	mov    -0x38(%rbp),%rdx
 10180d9:	inc    %r15
 10180dc:	cmp    %r15,%rdx
 10180df:	je     10181c2 <acquire+0x2e2>
 10180e5:	cmpb   $0x2f,0x0(%r13,%r15,1)
 10180eb:	jne    10180d9 <acquire+0x1f9>
 10180ed:	mov    %r15,%rdx
 10180f0:	sub    %r14,%rdx
 10180f3:	cmp    $0xffe,%rdx
 10180fa:	ja     10182b9 <acquire+0x3d9>
 1018100:	lea    (%r14,%r13,1),%rsi
 1018104:	lea    -0x1160(%rbp),%r13
 101810b:	mov    %r13,%rdi
 101810e:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1018113:	mov    %r13,%rax
 1018116:	sub    %r14,%rax
 1018119:	movb   $0x0,(%rax,%r15,1)
 101811e:	mov    -0x2c(%rbp),%r14d
 1018122:	mov    %r14d,%edi
 1018125:	mov    %r13,%rsi
 1018128:	mov    $0xb0000,%edx
 101812d:	xor    %eax,%eax
 101812f:	call   101f2b0 <openat@plt>
 1018134:	mov    %eax,%r13d
 1018137:	cmp    -0x48(%rbp),%r14d
 101813b:	je     10180c0 <acquire+0x1e0>
 101813d:	mov    %r14d,%edi
 1018140:	call   101f250 <close@plt>
 1018145:	jmp    10180c0 <acquire+0x1e0>
 101814a:	nopw   0x0(%rax,%rax,1)
 1018150:	test   %rdx,%rdx
 1018153:	je     101817a <acquire+0x29a>
 1018155:	mov    %r10d,-0x60(%rbp)
 1018159:	mov    %r9d,-0x50(%rbp)
 101815d:	mov    %r8,%r14
 1018160:	mov    %r13,%rdi
 1018163:	mov    $0x5c,%esi
 1018168:	mov    %rdx,%r15
 101816b:	call   101f190 <memchr@plt>
 1018170:	test   %rax,%rax
 1018173:	je     1018189 <acquire+0x2a9>
 1018175:	mov    %r15,%rdx
 1018178:	jmp    10181a3 <acquire+0x2c3>
 101817a:	cmpb   $0x6c,-0x51(%rbp)
 101817e:	jne    1017fea <acquire+0x10a>
 1018184:	jmp    101802e <acquire+0x14e>
 1018189:	mov    %r13,%rdi
 101818c:	xor    %esi,%esi
 101818e:	mov    %r15,%rdx
 1018191:	call   101f190 <memchr@plt>
 1018196:	test   %rax,%rax
 1018199:	je     1018329 <acquire+0x449>
 101819f:	mov    -0x38(%rbp),%rdx
 10181a3:	mov    $0xc80405,%r15d
 10181a9:	mov    %r14,%r8
 10181ac:	mov    -0x68(%rbp),%rdi
 10181b0:	mov    -0x50(%rbp),%r9d
 10181b4:	jmp    1017fea <acquire+0x10a>
 10181b9:	xor    %r14d,%r14d
 10181bc:	mov    -0x48(%rbp),%eax
 10181bf:	mov    %eax,-0x2c(%rbp)
 10181c2:	cmpl   $0x0,-0x2c(%rbp)
 10181c6:	js     10182d7 <acquire+0x3f7>
 10181cc:	mov    %rdx,%r13
 10181cf:	sub    %r14,%r13
 10181d2:	cmp    $0xfff,%r13
 10181d9:	mov    -0x40(%rbp),%r8
 10181dd:	mov    $0xc80405,%r15d
 10181e3:	jb     101821c <acquire+0x33c>
 10181e5:	mov    $0x2,%r9d
 10181eb:	mov    -0x2c(%rbp),%edi
 10181ee:	cmp    -0x48(%rbp),%edi
 10181f1:	mov    -0x68(%rbp),%r14
 10181f5:	mov    -0x44(%rbp),%r12d
 10181f9:	je     1018210 <acquire+0x330>
 10181fb:	mov    %r8,%rbx
 10181fe:	call   101f250 <close@plt>
 1018203:	mov    $0x2,%r9d
 1018209:	mov    %rbx,%r8
 101820c:	mov    -0x38(%rbp),%rdx
 1018210:	mov    -0x70(%rbp),%r13
 1018214:	mov    %r14,%rdi
 1018217:	jmp    1017fea <acquire+0x10a>
 101821c:	add    -0x70(%rbp),%r14
 1018220:	lea    -0x1160(%rbp),%rdi
 1018227:	mov    %r14,%rsi
 101822a:	mov    %r13,%rdx
 101822d:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1018232:	movb   $0x0,-0x1160(%rbp,%r13,1)
 101823b:	mov    -0xc0(%rbp),%rax
 1018242:	cmp    $0xd,%eax
 1018245:	ja     101869c <acquire+0x7bc>
 101824b:	lea    -0x15166(%rip),%rcx        # 10030ec <myl_rc_map_sentinel+0x4c>
 1018252:	movslq (%rcx,%rax,4),%rax
 1018256:	add    %rcx,%rax
 1018259:	jmp    *%rax
 101825b:	movzbl -0x1160(%rbp),%eax
 1018262:	cmpb   $0x6d,-0x2d(%rbp)
 1018266:	mov    -0x2c(%rbp),%r14d
 101826a:	jne    10183b5 <acquire+0x4d5>
 1018270:	mov    %r14d,%edi
 1018273:	test   %al,%al
 1018275:	je     10186ea <acquire+0x80a>
 101827b:	lea    -0x1160(%rbp),%rsi
 1018282:	lea    -0x160(%rbp),%rdx
 1018289:	mov    $0x100,%ecx
 101828e:	call   101f2c0 <fstatat@plt>
 1018293:	test   %eax,%eax
 1018295:	je     10186fe <acquire+0x81e>
 101829b:	call   101f270 <__errno_location@plt>
 10182a0:	mov    (%rax),%eax
 10182a2:	cmp    $0x28,%rax
 10182a6:	mov    -0x38(%rbp),%rdx
 10182aa:	mov    -0x40(%rbp),%r8
 10182ae:	jbe    101883d <acquire+0x95d>
 10182b4:	jmp    1018bac <acquire+0xccc>
 10182b9:	call   101f270 <__errno_location@plt>
 10182be:	movl   $0x24,(%rax)
 10182c4:	mov    -0x2c(%rbp),%edi
 10182c7:	cmp    -0x48(%rbp),%edi
 10182ca:	je     10182d7 <acquire+0x3f7>
 10182cc:	call   101f250 <close@plt>
 10182d1:	jmp    10182d7 <acquire+0x3f7>
 10182d3:	mov    -0x70(%rbp),%r13
 10182d7:	call   101f270 <__errno_location@plt>
 10182dc:	mov    -0x38(%rbp),%rdx
 10182e0:	mov    (%rax),%eax
 10182e2:	cmp    $0x28,%rax
 10182e6:	mov    -0x40(%rbp),%r8
 10182ea:	mov    -0x68(%rbp),%rdi
 10182ee:	mov    -0x44(%rbp),%r12d
 10182f2:	mov    $0xc80405,%r15d
 10182f8:	ja     101831e <acquire+0x43e>
 10182fa:	mov    $0x2,%r9d
 1018300:	movabs $0x10000102002,%rcx
 101830a:	bt     %rax,%rcx
 101830e:	jb     1017fea <acquire+0x10a>
 1018314:	cmp    $0xc,%rax
 1018318:	je     1018c7c <acquire+0xd9c>
 101831e:	mov    $0x3,%r9d
 1018324:	jmp    1017fea <acquire+0x10a>
 1018329:	xor    %eax,%eax
 101832b:	xor    %ecx,%ecx
 101832d:	mov    -0x38(%rbp),%rdx
 1018331:	mov    $0xc80405,%r15d
 1018337:	mov    %r14,%r8
 101833a:	mov    -0x68(%rbp),%rdi
 101833e:	mov    -0x50(%rbp),%r9d
 1018342:	mov    -0x60(%rbp),%r10d
 1018346:	jmp    1018360 <acquire+0x480>
 1018348:	nopl   0x0(%rax,%rax,1)
 1018350:	lea    0x1(%rax),%rcx
 1018354:	inc    %rax
 1018357:	cmp    %rax,%r8
 101835a:	je     101802e <acquire+0x14e>
 1018360:	cmp    %rax,%rdx
 1018363:	je     101836d <acquire+0x48d>
 1018365:	cmpb   $0x2f,0x0(%r13,%rax,1)
 101836b:	jne    1018354 <acquire+0x474>
 101836d:	mov    %rax,%rsi
 1018370:	sub    %rcx,%rsi
 1018373:	je     1017fea <acquire+0x10a>
 1018379:	cmp    $0x2,%rsi
 101837d:	je     10183a0 <acquire+0x4c0>
 101837f:	cmp    $0x1,%rsi
 1018383:	jne    1018350 <acquire+0x470>
 1018385:	cmpb   $0x2e,0x0(%r13,%rcx,1)
 101838b:	jne    1018350 <acquire+0x470>
 101838d:	jmp    1017fea <acquire+0x10a>
 1018392:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10183a0:	cmpb   $0x2e,0x0(%r13,%rcx,1)
 10183a6:	jne    1018350 <acquire+0x470>
 10183a8:	cmpb   $0x2e,0x1(%r13,%rcx,1)
 10183ae:	jne    1018350 <acquire+0x470>
 10183b0:	jmp    1017fea <acquire+0x10a>
 10183b5:	mov    $0x2,%r9d
 10183bb:	test   %al,%al
 10183bd:	mov    -0x38(%rbp),%rdx
 10183c1:	mov    -0x40(%rbp),%r8
 10183c5:	je     1018bb2 <acquire+0xcd2>
 10183cb:	cmpb   $0x6b,-0x2d(%rbp)
 10183cf:	jne    1018754 <acquire+0x874>
 10183d5:	mov    %r14d,%edi
 10183d8:	lea    -0x1160(%rbp),%rsi
 10183df:	mov    $0x1ff,%edx
 10183e4:	call   101f2d0 <mkdirat@plt>
 10183e9:	test   %eax,%eax
 10183eb:	je     10187fd <acquire+0x91d>
 10183f1:	call   101f270 <__errno_location@plt>
 10183f6:	mov    (%rax),%eax
 10183f8:	cmp    $0x28,%rax
 10183fc:	mov    -0x38(%rbp),%rdx
 1018400:	mov    -0x40(%rbp),%r8
 1018404:	mov    -0x2c(%rbp),%r14d
 1018408:	ja     1018bac <acquire+0xccc>
 101840e:	movabs $0x10000102002,%rcx
 1018418:	bt     %rax,%rcx
 101841c:	jb     101897a <acquire+0xa9a>
 1018422:	jmp    1018858 <acquire+0x978>
 1018427:	cmpb   $0x0,-0x1160(%rbp)
 101842e:	lea    -0x1160(%rbp),%rsi
 1018435:	lea    -0x16669(%rip),%rax        # 1001dd3 <__abi_tag+0x1ad7>
 101843c:	cmove  %rax,%rsi
 1018440:	mov    -0x2c(%rbp),%edi
 1018443:	mov    $0xb0000,%edx
 1018448:	xor    %eax,%eax
 101844a:	call   101f2b0 <openat@plt>
 101844f:	test   %eax,%eax
 1018451:	js     1018820 <acquire+0x940>
 1018457:	mov    %eax,%r14d
 101845a:	mov    %eax,%edi
 101845c:	call   101f2e0 <fdopendir@plt>
 1018461:	mov    %rax,-0x60(%rbp)
 1018465:	test   %rax,%rax
 1018468:	je     101898a <acquire+0xaaa>
 101846e:	mov    $0x400,%edi
 1018473:	call   101f070 <malloc@plt>
 1018478:	test   %rax,%rax
 101847b:	je     1018a7e <acquire+0xb9e>
 1018481:	mov    %rax,%r13
 1018484:	movb   $0x1,(%rax)
 1018487:	call   101f270 <__errno_location@plt>
 101848c:	mov    %rax,%r14
 101848f:	movl   $0x0,(%rax)
 1018495:	mov    -0x60(%rbp),%rdi
 1018499:	call   101f2f0 <readdir@plt>
 101849e:	test   %rax,%rax
 10184a1:	je     1018afc <acquire+0xc1c>
 10184a7:	mov    %r14,-0x98(%rbp)
 10184ae:	mov    $0x400,%ecx
 10184b3:	mov    %rcx,-0x88(%rbp)
 10184ba:	mov    $0x1,%r14d
 10184c0:	movq   $0x0,-0x90(%rbp)
 10184cb:	mov    %r14,-0x50(%rbp)
 10184cf:	mov    -0x98(%rbp),%r14
 10184d6:	jmp    10184f1 <acquire+0x611>
 10184d8:	movl   $0x0,(%r14)
 10184df:	mov    -0x60(%rbp),%rdi
 10184e3:	call   101f2f0 <readdir@plt>
 10184e8:	test   %rax,%rax
 10184eb:	je     1018b52 <acquire+0xc72>
 10184f1:	cmpb   $0x2e,0x13(%rax)
 10184f5:	jne    101850a <acquire+0x62a>
 10184f7:	movzbl 0x14(%rax),%ecx
 10184fb:	test   %ecx,%ecx
 10184fd:	je     10184d8 <acquire+0x5f8>
 10184ff:	cmp    $0x2e,%ecx
 1018502:	jne    101850a <acquire+0x62a>
 1018504:	cmpb   $0x0,0x15(%rax)
 1018508:	je     10184d8 <acquire+0x5f8>
 101850a:	add    $0x13,%rax
 101850e:	mov    %rax,-0x78(%rbp)
 1018512:	mov    %rax,%rdi
 1018515:	call   101e660 <compiler_rt.strlen>
 101851a:	mov    -0x50(%rbp),%rdx
 101851e:	cmp    $0x10000,%rdx
 1018525:	ja     1018c53 <acquire+0xd73>
 101852b:	cmpq   $0xff,-0x90(%rbp)
 1018536:	ja     1018c53 <acquire+0xd73>
 101853c:	mov    %rax,%rsi
 101853f:	add    $0xfffffffffffff001,%rax
 1018545:	cmp    $0xfffffffffffff002,%rax
 101854b:	jb     1018c53 <acquire+0xd73>
 1018551:	lea    0x3(%rsi),%rax
 1018555:	mov    $0x10000,%ecx
 101855a:	sub    %rdx,%rcx
 101855d:	cmp    %rcx,%rax
 1018560:	ja     1018c53 <acquire+0xd73>
 1018566:	lea    0x3(%rdx),%rax
 101856a:	mov    %rax,-0xb0(%rbp)
 1018571:	lea    (%rsi,%rdx,1),%rcx
 1018575:	add    $0x3,%rcx
 1018579:	mov    %r13,%rax
 101857c:	mov    -0x88(%rbp),%r14
 1018583:	mov    %rcx,-0xb8(%rbp)
 101858a:	mov    %rsi,-0xa0(%rbp)
 1018591:	cmp    %r14,%rcx
 1018594:	jbe    10185c1 <acquire+0x6e1>
 1018596:	add    %r14,%r14
 1018599:	mov    %rax,%r13
 101859c:	mov    %rax,%rdi
 101859f:	mov    %r14,%rsi
 10185a2:	call   101f180 <realloc@plt>
 10185a7:	test   %rax,%rax
 10185aa:	mov    -0x50(%rbp),%rcx
 10185ae:	mov    -0xa0(%rbp),%rsi
 10185b5:	lea    0x3(%rsi,%rcx,1),%rcx
 10185ba:	jne    1018591 <acquire+0x6b1>
 10185bc:	jmp    1018b73 <acquire+0xc93>
 10185c1:	mov    %r14,-0x88(%rbp)
 10185c8:	mov    %rax,%r13
 10185cb:	mov    -0x60(%rbp),%rdi
 10185cf:	call   101f300 <dirfd@plt>
 10185d4:	mov    %eax,%edi
 10185d6:	mov    -0x78(%rbp),%rsi
 10185da:	lea    -0x160(%rbp),%rdx
 10185e1:	mov    $0x100,%ecx
 10185e6:	call   101f2c0 <fstatat@plt>
 10185eb:	test   %eax,%eax
 10185ed:	je     101864c <acquire+0x76c>
 10185ef:	xor    %eax,%eax
 10185f1:	mov    -0x78(%rbp),%rsi
 10185f5:	mov    %r13,%rcx
 10185f8:	mov    -0x50(%rbp),%rdi
 10185fc:	mov    %al,(%rcx,%rdi,1)
 10185ff:	mov    -0xa0(%rbp),%rdx
 1018606:	mov    %dx,0x1(%rcx,%rdi,1)
 101860b:	mov    -0xb0(%rbp),%rdi
 1018612:	add    %rcx,%rdi
 1018615:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101861a:	incq   -0x90(%rbp)
 1018621:	mov    -0x98(%rbp),%rax
 1018628:	movl   $0x0,(%rax)
 101862e:	mov    -0x60(%rbp),%rdi
 1018632:	call   101f2f0 <readdir@plt>
 1018637:	test   %rax,%rax
 101863a:	mov    -0xb8(%rbp),%r14
 1018641:	jne    10184cb <acquire+0x5eb>
 1018647:	jmp    1018b56 <acquire+0xc76>
 101864c:	mov    -0x148(%rbp),%eax
 1018652:	mov    $0xf000,%ecx
 1018657:	and    %ecx,%eax
 1018659:	cmp    $0xa000,%eax
 101865e:	mov    -0x50(%rbp),%rdi
 1018662:	je     1018687 <acquire+0x7a7>
 1018664:	cmp    $0x8000,%eax
 1018669:	mov    -0x78(%rbp),%rsi
 101866d:	mov    %r13,%rcx
 1018670:	je     1018680 <acquire+0x7a0>
 1018672:	cmp    $0x4000,%eax
 1018677:	jne    1018695 <acquire+0x7b5>
 1018679:	mov    $0x2,%al
 101867b:	jmp    10185fc <acquire+0x71c>
 1018680:	mov    $0x1,%al
 1018682:	jmp    10185fc <acquire+0x71c>
 1018687:	mov    $0x3,%al
 1018689:	mov    -0x78(%rbp),%rsi
 101868d:	mov    %r13,%rcx
 1018690:	jmp    10185fc <acquire+0x71c>
 1018695:	xor    %eax,%eax
 1018697:	jmp    10185fc <acquire+0x71c>
 101869c:	xor    %edx,%edx
 101869e:	cmpl   $0x0,-0x60(%rbp)
 10186a2:	sete   %dl
 10186a5:	shl    $0xb,%edx
 10186a8:	mov    -0xa8(%rbp),%rax
 10186af:	cmp    $0x61,%eax
 10186b2:	mov    -0x2c(%rbp),%r14d
 10186b6:	je     101886d <acquire+0x98d>
 10186bc:	cmp    $0x63,%eax
 10186bf:	mov    -0x70(%rbp),%r13
 10186c3:	jne    101888f <acquire+0x9af>
 10186c9:	or     $0x800c1,%edx
 10186cf:	mov    %r14d,%edi
 10186d2:	lea    -0x1160(%rbp),%rsi
 10186d9:	mov    $0x1b6,%ecx
 10186de:	xor    %eax,%eax
 10186e0:	call   101f2b0 <openat@plt>
 10186e5:	jmp    10188b4 <acquire+0x9d4>
 10186ea:	lea    -0x160(%rbp),%rsi
 10186f1:	call   101f310 <fstat@plt>
 10186f6:	test   %eax,%eax
 10186f8:	jne    101829b <acquire+0x3bb>
 10186fe:	mov    $0xa,%edi
 1018703:	call   101f070 <malloc@plt>
 1018708:	test   %rax,%rax
 101870b:	je     1018a66 <acquire+0xb86>
 1018711:	mov    %rax,%r13
 1018714:	movb   $0x1,(%rax)
 1018717:	mov    -0x148(%rbp),%eax
 101871d:	mov    $0xf000,%ecx
 1018722:	and    %ecx,%eax
 1018724:	cmp    $0xa000,%eax
 1018729:	je     1018b08 <acquire+0xc28>
 101872f:	cmp    $0x8000,%eax
 1018734:	mov    -0x38(%rbp),%rdx
 1018738:	mov    -0x40(%rbp),%r8
 101873c:	je     1018b04 <acquire+0xc24>
 1018742:	cmp    $0x4000,%eax
 1018747:	jne    1018b14 <acquire+0xc34>
 101874d:	mov    $0x2,%al
 101874f:	jmp    1018b16 <acquire+0xc36>
 1018754:	mov    %r14d,%edi
 1018757:	lea    -0x1160(%rbp),%rsi
 101875e:	xor    %edx,%edx
 1018760:	call   101f320 <unlinkat@plt>
 1018765:	test   %eax,%eax
 1018767:	je     10187fd <acquire+0x91d>
 101876d:	call   101f270 <__errno_location@plt>
 1018772:	mov    (%rax),%ecx
 1018774:	cmp    $0x28,%rcx
 1018778:	mov    -0x38(%rbp),%rdx
 101877c:	mov    -0x40(%rbp),%r8
 1018780:	mov    -0x2c(%rbp),%r14d
 1018784:	ja     1018bac <acquire+0xccc>
 101878a:	movabs $0x10000102000,%rsi
 1018794:	bt     %rcx,%rsi
 1018798:	jb     101897a <acquire+0xa9a>
 101879e:	mov    $0x200002,%esi
 10187a3:	bt     %rcx,%rsi
 10187a7:	jae    1018ba2 <acquire+0xcc2>
 10187ad:	mov    %r14d,%edi
 10187b0:	mov    %rax,%r14
 10187b3:	lea    -0x1160(%rbp),%rsi
 10187ba:	mov    $0x200,%edx
 10187bf:	call   101f320 <unlinkat@plt>
 10187c4:	test   %eax,%eax
 10187c6:	je     10187fd <acquire+0x91d>
 10187c8:	mov    (%r14),%eax
 10187cb:	cmp    $0x28,%rax
 10187cf:	mov    -0x38(%rbp),%rdx
 10187d3:	mov    -0x40(%rbp),%r8
 10187d7:	mov    -0x2c(%rbp),%r14d
 10187db:	ja     1018bac <acquire+0xccc>
 10187e1:	movabs $0x10000102002,%rcx
 10187eb:	bt     %rax,%rcx
 10187ef:	mov    $0x2,%r9d
 10187f5:	jb     1018bb2 <acquire+0xcd2>
 10187fb:	jmp    1018858 <acquire+0x978>
 10187fd:	mov    $0x1,%edi
 1018802:	call   101f070 <malloc@plt>
 1018807:	test   %rax,%rax
 101880a:	je     1018a8e <acquire+0xbae>
 1018810:	mov    %rax,%r13
 1018813:	movb   $0x1,(%rax)
 1018816:	mov    $0x1,%ecx
 101881b:	jmp    1018b62 <acquire+0xc82>
 1018820:	call   101f270 <__errno_location@plt>
 1018825:	mov    (%rax),%eax
 1018827:	cmp    $0x28,%rax
 101882b:	mov    -0x38(%rbp),%rdx
 101882f:	mov    -0x40(%rbp),%r8
 1018833:	mov    -0x2c(%rbp),%r14d
 1018837:	ja     1018bac <acquire+0xccc>
 101883d:	movabs $0x10000102002,%rcx
 1018847:	bt     %rax,%rcx
 101884b:	jae    1018858 <acquire+0x978>
 101884d:	mov    $0x2,%r9d
 1018853:	jmp    1018bb2 <acquire+0xcd2>
 1018858:	cmp    $0xc,%rax
 101885c:	jne    1018bac <acquire+0xccc>
 1018862:	mov    $0x4,%r9d
 1018868:	jmp    1018bb2 <acquire+0xcd2>
 101886d:	or     $0x80041,%edx
 1018873:	mov    %r14d,%edi
 1018876:	lea    -0x1160(%rbp),%rsi
 101887d:	mov    $0x1b6,%ecx
 1018882:	xor    %eax,%eax
 1018884:	call   101f2b0 <openat@plt>
 1018889:	mov    -0x70(%rbp),%r13
 101888d:	jmp    10188b4 <acquire+0x9d4>
 101888f:	cmpl   $0x0,-0x60(%rbp)
 1018893:	mov    $0xa0800,%edx
 1018898:	mov    $0x80000,%eax
 101889d:	cmovne %eax,%edx
 10188a0:	add    -0x7c(%rbp),%edx
 10188a3:	mov    %r14d,%edi
 10188a6:	lea    -0x1160(%rbp),%rsi
 10188ad:	xor    %eax,%eax
 10188af:	call   101f2b0 <openat@plt>
 10188b4:	cmp    -0x48(%rbp),%r14d
 10188b8:	je     10188c8 <acquire+0x9e8>
 10188ba:	mov    %eax,-0x48(%rbp)
 10188bd:	mov    %r14d,%edi
 10188c0:	call   101f250 <close@plt>
 10188c5:	mov    -0x48(%rbp),%eax
 10188c8:	test   %eax,%eax
 10188ca:	lea    -0x160(%rbp),%rsi
 10188d1:	js     1018930 <acquire+0xa50>
 10188d3:	mov    %eax,%r14d
 10188d6:	mov    %eax,%edi
 10188d8:	mov    %rsi,%r15
 10188db:	call   101f310 <fstat@plt>
 10188e0:	test   %eax,%eax
 10188e2:	je     10189c7 <acquire+0xae7>
 10188e8:	call   101f270 <__errno_location@plt>
 10188ed:	mov    (%rax),%eax
 10188ef:	cmp    $0x28,%rax
 10188f3:	mov    -0x44(%rbp),%r12d
 10188f7:	mov    $0xc80405,%r15d
 10188fd:	ja     1018af2 <acquire+0xc12>
 1018903:	movabs $0x10000102002,%rcx
 101890d:	bt     %rax,%rcx
 1018911:	jae    1018ae3 <acquire+0xc03>
 1018917:	mov    $0x2,%ecx
 101891c:	mov    %r14d,%edi
 101891f:	mov    %ecx,%ebx
 1018921:	call   101f250 <close@plt>
 1018926:	mov    %ebx,%r9d
 1018929:	xor    %ebx,%ebx
 101892b:	jmp    1018ad6 <acquire+0xbf6>
 1018930:	call   101f270 <__errno_location@plt>
 1018935:	mov    (%rax),%eax
 1018937:	cmp    $0x28,%rax
 101893b:	mov    -0x44(%rbp),%r12d
 101893f:	mov    -0x38(%rbp),%rdx
 1018943:	mov    -0x40(%rbp),%r8
 1018947:	mov    -0x68(%rbp),%rdi
 101894b:	ja     101831e <acquire+0x43e>
 1018951:	mov    $0x2,%r9d
 1018957:	movabs $0x10000102002,%rcx
 1018961:	bt     %rax,%rcx
 1018965:	jb     1017fea <acquire+0x10a>
 101896b:	cmp    $0xc,%rax
 101896f:	jne    101831e <acquire+0x43e>
 1018975:	jmp    1018c7c <acquire+0xd9c>
 101897a:	xor    %ecx,%ecx
 101897c:	xor    %r13d,%r13d
 101897f:	mov    $0x2,%r9d
 1018985:	jmp    1018bb7 <acquire+0xcd7>
 101898a:	call   101f270 <__errno_location@plt>
 101898f:	mov    (%rax),%eax
 1018991:	cmp    $0x28,%rax
 1018995:	ja     1018c49 <acquire+0xd69>
 101899b:	movabs $0x10000102002,%rcx
 10189a5:	bt     %rax,%rcx
 10189a9:	jae    1018c3a <acquire+0xd5a>
 10189af:	mov    $0x2,%ecx
 10189b4:	mov    %r14d,%edi
 10189b7:	mov    %ecx,%r14d
 10189ba:	call   101f250 <close@plt>
 10189bf:	mov    %r14d,%r9d
 10189c2:	jmp    1018a94 <acquire+0xbb4>
 10189c7:	mov    -0x60(%rbp),%edi
 10189ca:	mov    %r14d,%esi
 10189cd:	mov    %r15,%rdx
 10189d0:	call   1018c90 <usable>
 10189d5:	test   %eax,%eax
 10189d7:	je     1018b32 <acquire+0xc52>
 10189dd:	cmpb   $0x74,-0x2d(%rbp)
 10189e1:	mov    $0xc80405,%r15d
 10189e7:	jne    1018a9e <acquire+0xbbe>
 10189ed:	mov    -0x148(%rbp),%eax
 10189f3:	mov    $0xf000,%ecx
 10189f8:	and    %ecx,%eax
 10189fa:	cmp    $0x8000,%eax
 10189ff:	jne    1018a9e <acquire+0xbbe>
 1018a05:	mov    %r14d,%edi
 1018a08:	xor    %esi,%esi
 1018a0a:	call   101f330 <ftruncate@plt>
 1018a0f:	test   %eax,%eax
 1018a11:	je     1018a9e <acquire+0xbbe>
 1018a17:	call   101f270 <__errno_location@plt>
 1018a1c:	mov    (%rax),%eax
 1018a1e:	cmp    $0x28,%rax
 1018a22:	mov    -0x44(%rbp),%r12d
 1018a26:	ja     1018c70 <acquire+0xd90>
 1018a2c:	movabs $0x10000102002,%rcx
 1018a36:	bt     %rax,%rcx
 1018a3a:	jae    1018c5f <acquire+0xd7f>
 1018a40:	movl   $0x2,-0x50(%rbp)
 1018a47:	mov    %r14d,%edi
 1018a4a:	call   101f250 <close@plt>
 1018a4f:	xor    %ebx,%ebx
 1018a51:	mov    -0x38(%rbp),%rdx
 1018a55:	mov    -0x40(%rbp),%r8
 1018a59:	mov    -0x68(%rbp),%rdi
 1018a5d:	mov    -0x50(%rbp),%r9d
 1018a61:	jmp    1018c2b <acquire+0xd4b>
 1018a66:	mov    $0x4,%r9d
 1018a6c:	xor    %ecx,%ecx
 1018a6e:	xor    %r13d,%r13d
 1018a71:	mov    -0x38(%rbp),%rdx
 1018a75:	mov    -0x40(%rbp),%r8
 1018a79:	jmp    1018bb7 <acquire+0xcd7>
 1018a7e:	movl   $0x4,-0x50(%rbp)
 1018a85:	mov    -0x2c(%rbp),%r14d
 1018a89:	jmp    1018b86 <acquire+0xca6>
 1018a8e:	mov    $0x4,%r9d
 1018a94:	xor    %ecx,%ecx
 1018a96:	xor    %r13d,%r13d
 1018a99:	jmp    1018b65 <acquire+0xc85>
 1018a9e:	mov    %r14d,(%r12)
 1018aa2:	vxorps %xmm0,%xmm0,%xmm0
 1018aa6:	vmovups %xmm0,0x4(%r12)
 1018aad:	vmovups %xmm0,0x10(%r12)
 1018ab4:	movzbl -0x2d(%rbp),%eax
 1018ab8:	mov    %al,0x20(%r12)
 1018abd:	movl   $0x0,0x21(%r12)
 1018ac6:	movl   $0x0,0x24(%r12)
 1018acf:	xor    %r9d,%r9d
 1018ad2:	mov    -0x44(%rbp),%r12d
 1018ad6:	mov    -0x38(%rbp),%rdx
 1018ada:	mov    -0x40(%rbp),%r8
 1018ade:	jmp    1018c27 <acquire+0xd47>
 1018ae3:	mov    $0x4,%ecx
 1018ae8:	cmp    $0xc,%rax
 1018aec:	je     101891c <acquire+0xa3c>
 1018af2:	mov    $0x3,%ecx
 1018af7:	jmp    101891c <acquire+0xa3c>
 1018afc:	mov    $0x1,%r14d
 1018b02:	jmp    1018b56 <acquire+0xc76>
 1018b04:	mov    $0x1,%al
 1018b06:	jmp    1018b16 <acquire+0xc36>
 1018b08:	mov    $0x3,%al
 1018b0a:	mov    -0x38(%rbp),%rdx
 1018b0e:	mov    -0x40(%rbp),%r8
 1018b12:	jmp    1018b16 <acquire+0xc36>
 1018b14:	xor    %eax,%eax
 1018b16:	mov    %al,0x1(%r13)
 1018b1a:	mov    -0x130(%rbp),%rax
 1018b21:	mov    %rax,0x2(%r13)
 1018b25:	mov    $0xa,%ecx
 1018b2a:	xor    %r9d,%r9d
 1018b2d:	jmp    1018bb7 <acquire+0xcd7>
 1018b32:	mov    %r14d,%edi
 1018b35:	call   101f250 <close@plt>
 1018b3a:	mov    $0x2,%r9d
 1018b40:	xor    %ebx,%ebx
 1018b42:	mov    -0x44(%rbp),%r12d
 1018b46:	mov    -0x38(%rbp),%rdx
 1018b4a:	mov    $0xc80405,%r15d
 1018b50:	jmp    1018ada <acquire+0xbfa>
 1018b52:	mov    -0x50(%rbp),%r14
 1018b56:	mov    -0x60(%rbp),%rdi
 1018b5a:	call   101f340 <closedir@plt>
 1018b5f:	mov    %r14,%rcx
 1018b62:	xor    %r9d,%r9d
 1018b65:	mov    -0x38(%rbp),%rdx
 1018b69:	mov    -0x40(%rbp),%r8
 1018b6d:	mov    -0x2c(%rbp),%r14d
 1018b71:	jmp    1018bb7 <acquire+0xcd7>
 1018b73:	movl   $0x4,-0x50(%rbp)
 1018b7a:	mov    -0x2c(%rbp),%r14d
 1018b7e:	mov    %r13,%rdi
 1018b81:	call   101efd0 <free@plt>
 1018b86:	mov    -0x60(%rbp),%rdi
 1018b8a:	call   101f340 <closedir@plt>
 1018b8f:	xor    %ecx,%ecx
 1018b91:	xor    %r13d,%r13d
 1018b94:	mov    -0x38(%rbp),%rdx
 1018b98:	mov    -0x40(%rbp),%r8
 1018b9c:	mov    -0x50(%rbp),%r9d
 1018ba0:	jmp    1018bb7 <acquire+0xcd7>
 1018ba2:	cmp    $0xc,%rcx
 1018ba6:	je     1018862 <acquire+0x982>
 1018bac:	mov    $0x3,%r9d
 1018bb2:	xor    %ecx,%ecx
 1018bb4:	xor    %r13d,%r13d
 1018bb7:	cmp    -0x48(%rbp),%r14d
 1018bbb:	je     1018bdf <acquire+0xcff>
 1018bbd:	mov    %r14d,%edi
 1018bc0:	mov    %r9d,%r14d
 1018bc3:	mov    %rcx,%r15
 1018bc6:	call   101f250 <close@plt>
 1018bcb:	mov    %r15,%rcx
 1018bce:	mov    $0xc80405,%r15d
 1018bd4:	mov    %r14d,%r9d
 1018bd7:	mov    -0x40(%rbp),%r8
 1018bdb:	mov    -0x38(%rbp),%rdx
 1018bdf:	test   %r13,%r13
 1018be2:	je     1018c1d <acquire+0xd3d>
 1018be4:	mov    $0xffffffff,%eax
 1018be9:	mov    %rax,(%r12)
 1018bed:	mov    %r13,0x8(%r12)
 1018bf2:	mov    %rcx,0x10(%r12)
 1018bf7:	movq   $0x0,0x18(%r12)
 1018c00:	movzbl -0x2d(%rbp),%eax
 1018c04:	mov    %al,0x20(%r12)
 1018c09:	movl   $0x0,0x21(%r12)
 1018c12:	movl   $0x0,0x24(%r12)
 1018c1b:	jmp    1018c1f <acquire+0xd3f>
 1018c1d:	xor    %ebx,%ebx
 1018c1f:	mov    -0x70(%rbp),%r13
 1018c23:	mov    -0x44(%rbp),%r12d
 1018c27:	mov    -0x68(%rbp),%rdi
 1018c2b:	test   $0x3,%r9b
 1018c2f:	jne    1017fea <acquire+0x10a>
 1018c35:	jmp    1017f54 <acquire+0x74>
 1018c3a:	mov    $0x4,%ecx
 1018c3f:	cmp    $0xc,%rax
 1018c43:	je     10189b4 <acquire+0xad4>
 1018c49:	mov    $0x3,%ecx
 1018c4e:	jmp    10189b4 <acquire+0xad4>
 1018c53:	movl   $0x2,-0x50(%rbp)
 1018c5a:	jmp    1018b7a <acquire+0xc9a>
 1018c5f:	movl   $0x4,-0x50(%rbp)
 1018c66:	cmp    $0xc,%rax
 1018c6a:	je     1018a47 <acquire+0xb67>
 1018c70:	movl   $0x3,-0x50(%rbp)
 1018c77:	jmp    1018a47 <acquire+0xb67>
 1018c7c:	mov    $0x4,%r9d
 1018c82:	jmp    1017f52 <acquire+0x72>
 1018c87:	int3
 1018c88:	int3
 1018c89:	int3
 1018c8a:	int3
 1018c8b:	int3
 1018c8c:	int3
 1018c8d:	int3
 1018c8e:	int3
 1018c8f:	int3

0000000001018c90 <usable>:
 1018c90:	mov    $0xf000,%eax
 1018c95:	and    0x18(%rdx),%eax
 1018c98:	test   %edi,%edi
 1018c9a:	je     1018ca8 <usable+0x18>
 1018c9c:	cmp    $0x4000,%eax
 1018ca1:	setne  %al
 1018ca4:	movzbl %al,%eax
 1018ca7:	ret
 1018ca8:	cmp    $0x8000,%eax
 1018cad:	jne    1018ce9 <usable+0x59>
 1018caf:	push   %rbp
 1018cb0:	mov    %rsp,%rbp
 1018cb3:	push   %rbx
 1018cb4:	push   %rax
 1018cb5:	mov    %esi,%edi
 1018cb7:	mov    %esi,%ebx
 1018cb9:	mov    $0x3,%esi
 1018cbe:	xor    %eax,%eax
 1018cc0:	call   101f350 <fcntl@plt>
 1018cc5:	and    $0xfffff7ff,%eax
 1018cca:	mov    %ebx,%edi
 1018ccc:	mov    $0x4,%esi
 1018cd1:	mov    %eax,%edx
 1018cd3:	xor    %eax,%eax
 1018cd5:	call   101f350 <fcntl@plt>
 1018cda:	test   %eax,%eax
 1018cdc:	sete   %al
 1018cdf:	add    $0x8,%rsp
 1018ce3:	pop    %rbx
 1018ce4:	pop    %rbp
 1018ce5:	movzbl %al,%eax
 1018ce8:	ret
 1018ce9:	xor    %eax,%eax
 1018ceb:	movzbl %al,%eax
 1018cee:	ret
 1018cef:	int3

0000000001018cf0 <myl_native_cow_take_depth_failure>:
 1018cf0:	push   %rbp
 1018cf1:	mov    %rsp,%rbp
 1018cf4:	data16 data16 data16 mov %fs:0x0,%rax
 1018d00:	mov    -0x4(%rax),%ecx
 1018d06:	movl   $0x0,-0x4(%rax)
 1018d10:	mov    %ecx,%eax
 1018d12:	pop    %rbp
 1018d13:	ret
 1018d14:	int3
 1018d15:	int3
 1018d16:	int3
 1018d17:	int3
 1018d18:	int3
 1018d19:	int3
 1018d1a:	int3
 1018d1b:	int3
 1018d1c:	int3
 1018d1d:	int3
 1018d1e:	int3
 1018d1f:	int3

0000000001018d20 <myl_rc_scope_spares_release>:
 1018d20:	push   %rbp
 1018d21:	mov    %rsp,%rbp
 1018d24:	push   %rbx
 1018d25:	push   %rax
 1018d26:	mov    %rdi,%rbx
 1018d29:	mov    0x1608(%rdi),%rax
 1018d30:	mov    0x100(%rax),%rdi
 1018d37:	test   %rdi,%rdi
 1018d3a:	je     1018d75 <myl_rc_scope_spares_release+0x55>
 1018d3c:	add    $0x100,%rax
 1018d42:	mov    %rax,%rcx
 1018d45:	data16 cs nopw 0x0(%rax,%rax,1)
 1018d50:	mov    (%rdi),%rax
 1018d53:	mov    %rax,(%rcx)
 1018d56:	call   101efd0 <free@plt>
 1018d5b:	mov    0x1608(%rbx),%rax
 1018d62:	lea    0x100(%rax),%rcx
 1018d69:	mov    0x100(%rax),%rdi
 1018d70:	test   %rdi,%rdi
 1018d73:	jne    1018d50 <myl_rc_scope_spares_release+0x30>
 1018d75:	movq   $0x0,0x108(%rax)
 1018d80:	add    $0x8,%rsp
 1018d84:	pop    %rbx
 1018d85:	pop    %rbp
 1018d86:	ret
 1018d87:	int3
 1018d88:	int3
 1018d89:	int3
 1018d8a:	int3
 1018d8b:	int3
 1018d8c:	int3
 1018d8d:	int3
 1018d8e:	int3
 1018d8f:	int3

0000000001018d90 <myl_rc_scopes_abandon>:
 1018d90:	push   %rbp
 1018d91:	mov    %rsp,%rbp
 1018d94:	push   %r15
 1018d96:	push   %r14
 1018d98:	push   %r12
 1018d9a:	push   %rbx
 1018d9b:	test   %rdi,%rdi
 1018d9e:	je     1018e84 <myl_rc_scopes_abandon+0xf4>
 1018da4:	mov    0x1608(%rdi),%rax
 1018dab:	test   %rax,%rax
 1018dae:	je     1018e84 <myl_rc_scopes_abandon+0xf4>
 1018db4:	mov    0xf8(%rax),%r14
 1018dbb:	movq   $0x0,0xf8(%rax)
 1018dc6:	test   %r14,%r14
 1018dc9:	je     1018e84 <myl_rc_scopes_abandon+0xf4>
 1018dcf:	vxorps %xmm0,%xmm0,%xmm0
 1018dd3:	jmp    1018dfd <myl_rc_scopes_abandon+0x6d>
 1018dd5:	data16 cs nopw 0x0(%rax,%rax,1)
 1018de0:	add    $0x8,%r14
 1018de4:	vmovups %xmm0,(%r14)
 1018de9:	movl   $0x0,0x10(%r14)
 1018df1:	mov    %r15,%r14
 1018df4:	test   %r15,%r15
 1018df7:	je     1018e84 <myl_rc_scopes_abandon+0xf4>
 1018dfd:	mov    0x8(%r14),%r15
 1018e01:	mov    0x10(%r14),%rsi
 1018e05:	test   %rsi,%rsi
 1018e08:	je     1018de0 <myl_rc_scopes_abandon+0x50>
 1018e0a:	nopw   0x0(%rax,%rax,1)
 1018e10:	mov    (%rsi),%r12
 1018e13:	mov    0x1608(%rdi),%rax
 1018e1a:	mov    0x108(%rax),%rcx
 1018e21:	cmp    $0x20,%rcx
 1018e25:	je     1018e73 <myl_rc_scopes_abandon+0xe3>
 1018e27:	mov    0x18(%rdi),%rdx
 1018e2b:	cmp    $0x28,%rdx
 1018e2f:	jb     1018e8d <myl_rc_scopes_abandon+0xfd>
 1018e31:	mov    0x30(%rax),%r8
 1018e35:	cmp    $0x27,%r8
 1018e39:	jbe    1018e8d <myl_rc_scopes_abandon+0xfd>
 1018e3b:	add    $0xffffffffffffffd8,%rdx
 1018e3f:	mov    %rdx,0x18(%rdi)
 1018e43:	add    $0xffffffffffffffd8,%r8
 1018e47:	mov    %r8,0x30(%rax)
 1018e4b:	mov    0x100(%rax),%rdx
 1018e52:	mov    %rdx,(%rsi)
 1018e55:	mov    %rsi,0x100(%rax)
 1018e5c:	inc    %rcx
 1018e5f:	mov    %rcx,0x108(%rax)
 1018e66:	mov    %r12,%rsi
 1018e69:	test   %r12,%r12
 1018e6c:	jne    1018e10 <myl_rc_scopes_abandon+0x80>
 1018e6e:	jmp    1018de0 <myl_rc_scopes_abandon+0x50>
 1018e73:	mov    %rdi,%rbx
 1018e76:	call   1019483 <entry_release>
 1018e7b:	vxorps %xmm0,%xmm0,%xmm0
 1018e7f:	mov    %rbx,%rdi
 1018e82:	jmp    1018e66 <myl_rc_scopes_abandon+0xd6>
 1018e84:	pop    %rbx
 1018e85:	pop    %r12
 1018e87:	pop    %r14
 1018e89:	pop    %r15
 1018e8b:	pop    %rbp
 1018e8c:	ret
 1018e8d:	call   101267d <myl_rc_invariant_failed>
 1018e92:	int3
 1018e93:	int3
 1018e94:	int3
 1018e95:	int3
 1018e96:	int3
 1018e97:	int3
 1018e98:	int3
 1018e99:	int3
 1018e9a:	int3
 1018e9b:	int3
 1018e9c:	int3
 1018e9d:	int3
 1018e9e:	int3
 1018e9f:	int3

0000000001018ea0 <myl_rc_scopes_close_region>:
 1018ea0:	push   %rbp
 1018ea1:	mov    %rsp,%rbp
 1018ea4:	mov    %esi,%eax
 1018ea6:	mov    0x1608(%rdi),%rcx
 1018ead:	mov    0xf8(%rcx),%rsi
 1018eb4:	test   %rsi,%rsi
 1018eb7:	je     1018ece <myl_rc_scopes_close_region+0x2e>
 1018eb9:	nopl   0x0(%rax)
 1018ec0:	cmp    %eax,0x1c(%rsi)
 1018ec3:	jb     1018ed0 <myl_rc_scopes_close_region+0x30>
 1018ec5:	mov    0x8(%rsi),%rsi
 1018ec9:	test   %rsi,%rsi
 1018ecc:	jne    1018ec0 <myl_rc_scopes_close_region+0x20>
 1018ece:	xor    %esi,%esi
 1018ed0:	pop    %rbp
 1018ed1:	jmp    1018ee0 <myl_rc_scope_unwind>
 1018ed6:	int3
 1018ed7:	int3
 1018ed8:	int3
 1018ed9:	int3
 1018eda:	int3
 1018edb:	int3
 1018edc:	int3
 1018edd:	int3
 1018ede:	int3
 1018edf:	int3

0000000001018ee0 <myl_rc_scope_unwind>:
 1018ee0:	push   %rbp
 1018ee1:	mov    %rsp,%rbp
 1018ee4:	push   %r15
 1018ee6:	push   %r14
 1018ee8:	push   %r13
 1018eea:	push   %r12
 1018eec:	push   %rbx
 1018eed:	push   %rax
 1018eee:	mov    %rsi,%rbx
 1018ef1:	test   %rdi,%rdi
 1018ef4:	je     1018f75 <myl_rc_scope_unwind+0x95>
 1018ef6:	mov    %rdi,%r12
 1018ef9:	mov    0x1608(%rdi),%rax
 1018f00:	test   %rax,%rax
 1018f03:	je     1018f75 <myl_rc_scope_unwind+0x95>
 1018f05:	mov    0xf8(%rax),%rdi
 1018f0c:	cmp    %rbx,%rdi
 1018f0f:	je     1018f7e <myl_rc_scope_unwind+0x9e>
 1018f11:	movabs $0xeffffffffffffffd,%r14
 1018f1b:	mov    %rdi,%rax
 1018f1e:	jmp    1018f29 <myl_rc_scope_unwind+0x49>
 1018f20:	mov    0x8(%rax),%rax
 1018f24:	cmp    %rbx,%rax
 1018f27:	je     1018f8d <myl_rc_scope_unwind+0xad>
 1018f29:	test   %rax,%rax
 1018f2c:	je     10191d7 <myl_rc_scope_unwind+0x2f7>
 1018f32:	mov    0x10(%rax),%rcx
 1018f36:	jmp    1018f4a <myl_rc_scope_unwind+0x6a>
 1018f38:	nopl   0x0(%rax,%rax,1)
 1018f40:	movl   $0x0,0x18(%rcx)
 1018f47:	mov    (%rcx),%rcx
 1018f4a:	test   %rcx,%rcx
 1018f4d:	je     1018f20 <myl_rc_scope_unwind+0x40>
 1018f4f:	cmpl   $0x0,0x18(%rcx)
 1018f53:	je     1018f40 <myl_rc_scope_unwind+0x60>
 1018f55:	mov    0x8(%rcx),%rdx
 1018f59:	test   %rdx,%rdx
 1018f5c:	je     1018f40 <myl_rc_scope_unwind+0x60>
 1018f5e:	mov    -0x10(%rdx),%rsi
 1018f62:	test   $0x2,%sil
 1018f66:	jne    1018f40 <myl_rc_scope_unwind+0x60>
 1018f68:	and    %r14,%rsi
 1018f6b:	or     0x10(%rcx),%rsi
 1018f6f:	mov    %rsi,-0x10(%rdx)
 1018f73:	jmp    1018f40 <myl_rc_scope_unwind+0x60>
 1018f75:	test   %rbx,%rbx
 1018f78:	jne    10191d7 <myl_rc_scope_unwind+0x2f7>
 1018f7e:	add    $0x8,%rsp
 1018f82:	pop    %rbx
 1018f83:	pop    %r12
 1018f85:	pop    %r13
 1018f87:	pop    %r14
 1018f89:	pop    %r15
 1018f8b:	pop    %rbp
 1018f8c:	ret
 1018f8d:	mov    %r12,-0x30(%rbp)
 1018f91:	jmp    1018fb4 <myl_rc_scope_unwind+0xd4>
 1018f93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1018fa0:	mov    0x1608(%r12),%rax
 1018fa8:	mov    0xf8(%rax),%rdi
 1018faf:	cmp    %rbx,%rdi
 1018fb2:	je     1018f7e <myl_rc_scope_unwind+0x9e>
 1018fb4:	test   %rdi,%rdi
 1018fb7:	je     10191d7 <myl_rc_scope_unwind+0x2f7>
 1018fbd:	cmpl   $0x0,0x18(%rdi)
 1018fc1:	je     1018fa0 <myl_rc_scope_unwind+0xc0>
 1018fc3:	mov    (%rdi),%r15
 1018fc6:	test   %r15,%r15
 1018fc9:	je     10191d7 <myl_rc_scope_unwind+0x2f7>
 1018fcf:	mov    0x1608(%r15),%rax
 1018fd6:	test   %rax,%rax
 1018fd9:	je     10191d7 <myl_rc_scope_unwind+0x2f7>
 1018fdf:	cmp    %rdi,0xf8(%rax)
 1018fe6:	jne    10191d7 <myl_rc_scope_unwind+0x2f7>
 1018fec:	mov    0x8(%rdi),%rcx
 1018ff0:	mov    %rcx,0xf8(%rax)
 1018ff7:	movl   $0x0,0x18(%rdi)
 1018ffe:	movq   $0x0,0x8(%rdi)
 1019006:	mov    0x10(%rdi),%rsi
 101900a:	test   %rsi,%rsi
 101900d:	je     101916d <myl_rc_scope_unwind+0x28d>
 1019013:	cmpq   $0x0,(%rsi)
 1019017:	jne    101918f <myl_rc_scope_unwind+0x2af>
 101901d:	cmpl   $0x0,0x18(%rsi)
 1019021:	mov    0x8(%rsi),%r12
 1019025:	je     1019047 <myl_rc_scope_unwind+0x167>
 1019027:	test   %r12,%r12
 101902a:	je     1019044 <myl_rc_scope_unwind+0x164>
 101902c:	mov    -0x10(%r12),%rcx
 1019031:	test   $0x2,%cl
 1019034:	jne    1019047 <myl_rc_scope_unwind+0x167>
 1019036:	and    %r14,%rcx
 1019039:	or     0x10(%rsi),%rcx
 101903d:	mov    %rcx,-0x10(%r12)
 1019042:	jmp    1019047 <myl_rc_scope_unwind+0x167>
 1019044:	xor    %r12d,%r12d
 1019047:	movq   $0x0,0x10(%rdi)
 101904f:	mov    0x20(%rsi),%r13
 1019053:	mov    0x108(%rax),%rcx
 101905a:	cmp    $0x20,%rcx
 101905e:	je     1019198 <myl_rc_scope_unwind+0x2b8>
 1019064:	mov    0x18(%r15),%rdx
 1019068:	cmp    $0x28,%rdx
 101906c:	jb     10191d7 <myl_rc_scope_unwind+0x2f7>
 1019072:	mov    0x30(%rax),%rdi
 1019076:	cmp    $0x27,%rdi
 101907a:	jbe    10191d7 <myl_rc_scope_unwind+0x2f7>
 1019080:	add    $0xffffffffffffffd8,%rdx
 1019084:	mov    %rdx,0x18(%r15)
 1019088:	add    $0xffffffffffffffd8,%rdi
 101908c:	mov    %rdi,0x30(%rax)
 1019090:	mov    0x100(%rax),%rdx
 1019097:	mov    %rdx,(%rsi)
 101909a:	mov    %rsi,0x100(%rax)
 10190a1:	inc    %rcx
 10190a4:	mov    %rcx,0x108(%rax)
 10190ab:	test   %r13,%r13
 10190ae:	je     1019109 <myl_rc_scope_unwind+0x229>
 10190b0:	mov    -0x10(%r13),%rcx
 10190b4:	movabs $0x4000000000000002,%rax
 10190be:	test   %rax,%rcx
 10190c1:	jne    10190f0 <myl_rc_scope_unwind+0x210>
 10190c3:	mov    -0x18(%r13),%rax
 10190c7:	test   %rax,%rax
 10190ca:	je     10191d7 <myl_rc_scope_unwind+0x2f7>
 10190d0:	and    $0x1,%ecx
 10190d3:	jne    10191d7 <myl_rc_scope_unwind+0x2f7>
 10190d9:	dec    %rax
 10190dc:	mov    %rax,-0x18(%r13)
 10190e0:	jne    10190f0 <myl_rc_scope_unwind+0x210>
 10190e2:	cmpq   $0x0,-0x20(%r13)
 10190e7:	je     10191ae <myl_rc_scope_unwind+0x2ce>
 10190ed:	nopl   (%rax)
 10190f0:	mov    0x1608(%r15),%rax
 10190f7:	cmpq   $0x0,0xc8(%rax)
 10190ff:	je     1019109 <myl_rc_scope_unwind+0x229>
 1019101:	mov    %r15,%rdi
 1019104:	call   1016210 <myl_rc_drain>
 1019109:	test   %r12,%r12
 101910c:	je     1019150 <myl_rc_scope_unwind+0x270>
 101910e:	mov    -0x10(%r12),%rcx
 1019113:	movabs $0x4000000000000002,%rax
 101911d:	test   %rax,%rcx
 1019120:	jne    1019150 <myl_rc_scope_unwind+0x270>
 1019122:	mov    -0x18(%r12),%rax
 1019127:	test   %rax,%rax
 101912a:	je     10191d7 <myl_rc_scope_unwind+0x2f7>
 1019130:	and    $0x1,%ecx
 1019133:	jne    10191d7 <myl_rc_scope_unwind+0x2f7>
 1019139:	dec    %rax
 101913c:	mov    %rax,-0x18(%r12)
 1019141:	jne    1019150 <myl_rc_scope_unwind+0x270>
 1019143:	cmpq   $0x0,-0x20(%r12)
 1019149:	je     10191c2 <myl_rc_scope_unwind+0x2e2>
 101914b:	nopl   0x0(%rax,%rax,1)
 1019150:	mov    0x1608(%r15),%rax
 1019157:	cmpq   $0x0,0xc8(%rax)
 101915f:	mov    -0x30(%rbp),%r12
 1019163:	je     101916d <myl_rc_scope_unwind+0x28d>
 1019165:	mov    %r15,%rdi
 1019168:	call   1016210 <myl_rc_drain>
 101916d:	mov    0x1608(%r15),%rax
 1019174:	cmpq   $0x0,0xc8(%rax)
 101917c:	je     1018fa0 <myl_rc_scope_unwind+0xc0>
 1019182:	mov    %r15,%rdi
 1019185:	call   1016210 <myl_rc_drain>
 101918a:	jmp    1018fa0 <myl_rc_scope_unwind+0xc0>
 101918f:	xor    %esi,%esi
 1019191:	call   1019210 <unwind_many>
 1019196:	jmp    101916d <myl_rc_scope_unwind+0x28d>
 1019198:	mov    %r15,%rdi
 101919b:	call   1019483 <entry_release>
 10191a0:	test   %r13,%r13
 10191a3:	jne    10190b0 <myl_rc_scope_unwind+0x1d0>
 10191a9:	jmp    1019109 <myl_rc_scope_unwind+0x229>
 10191ae:	add    $0xffffffffffffffe0,%r13
 10191b2:	mov    %r15,%rdi
 10191b5:	mov    %r13,%rsi
 10191b8:	call   101940d <hold_death>
 10191bd:	jmp    1019109 <myl_rc_scope_unwind+0x229>
 10191c2:	add    $0xffffffffffffffe0,%r12
 10191c6:	mov    %r15,%rdi
 10191c9:	mov    %r12,%rsi
 10191cc:	call   101940d <hold_death>
 10191d1:	mov    -0x30(%rbp),%r12
 10191d5:	jmp    101916d <myl_rc_scope_unwind+0x28d>
 10191d7:	call   101267d <myl_rc_invariant_failed>
 10191dc:	int3
 10191dd:	int3
 10191de:	int3
 10191df:	int3

00000000010191e0 <myl_rc_scope_current>:
 10191e0:	test   %rdi,%rdi
 10191e3:	je     10191fe <myl_rc_scope_current+0x1e>
 10191e5:	mov    0x1608(%rdi),%rax
 10191ec:	test   %rax,%rax
 10191ef:	je     10191fe <myl_rc_scope_current+0x1e>
 10191f1:	push   %rbp
 10191f2:	mov    %rsp,%rbp
 10191f5:	mov    0xf8(%rax),%rax
 10191fc:	pop    %rbp
 10191fd:	ret
 10191fe:	xor    %eax,%eax
 1019200:	ret
 1019201:	int3
 1019202:	int3
 1019203:	int3
 1019204:	int3
 1019205:	int3
 1019206:	int3
 1019207:	int3
 1019208:	int3
 1019209:	int3
 101920a:	int3
 101920b:	int3
 101920c:	int3
 101920d:	int3
 101920e:	int3
 101920f:	int3

0000000001019210 <unwind_many>:
 1019210:	push   %rbp
 1019211:	mov    %rsp,%rbp
 1019214:	push   %r15
 1019216:	push   %r14
 1019218:	push   %r13
 101921a:	push   %r12
 101921c:	push   %rbx
 101921d:	push   %rax
 101921e:	mov    %rsi,%rbx
 1019221:	mov    (%rdi),%r14
 1019224:	mov    0x10(%rdi),%r13
 1019228:	cmp    %rsi,%r13
 101922b:	je     101926e <unwind_many+0x5e>
 101922d:	movabs $0xeffffffffffffffd,%rax
 1019237:	mov    %r13,%rcx
 101923a:	jmp    1019248 <unwind_many+0x38>
 101923c:	nopl   0x0(%rax)
 1019240:	mov    (%rcx),%rcx
 1019243:	cmp    %rbx,%rcx
 1019246:	je     101926e <unwind_many+0x5e>
 1019248:	cmpl   $0x0,0x18(%rcx)
 101924c:	je     1019240 <unwind_many+0x30>
 101924e:	mov    0x8(%rcx),%rdx
 1019252:	test   %rdx,%rdx
 1019255:	je     1019240 <unwind_many+0x30>
 1019257:	mov    -0x10(%rdx),%rsi
 101925b:	test   $0x2,%sil
 101925f:	jne    1019240 <unwind_many+0x30>
 1019261:	and    %rax,%rsi
 1019264:	or     0x10(%rcx),%rsi
 1019268:	mov    %rsi,-0x10(%rdx)
 101926c:	jmp    1019240 <unwind_many+0x30>
 101926e:	mov    %rbx,0x10(%rdi)
 1019272:	jmp    1019299 <unwind_many+0x89>
 1019274:	add    $0xffffffffffffffe0,%r15
 1019278:	mov    %r14,%rdi
 101927b:	mov    %r15,%rsi
 101927e:	call   101940d <hold_death>
 1019283:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019290:	cmp    %rbx,%r13
 1019293:	je     10193f9 <unwind_many+0x1e9>
 1019299:	mov    %r13,%rsi
 101929c:	mov    0x0(%r13),%r13
 10192a0:	mov    0x8(%rsi),%r15
 10192a4:	mov    0x20(%rsi),%r12
 10192a8:	mov    0x1608(%r14),%rax
 10192af:	mov    0x108(%rax),%rcx
 10192b6:	cmp    $0x20,%rcx
 10192ba:	je     10193d2 <unwind_many+0x1c2>
 10192c0:	mov    0x18(%r14),%rdx
 10192c4:	cmp    $0x28,%rdx
 10192c8:	jb     1019408 <unwind_many+0x1f8>
 10192ce:	mov    0x30(%rax),%rdi
 10192d2:	cmp    $0x27,%rdi
 10192d6:	jbe    1019408 <unwind_many+0x1f8>
 10192dc:	add    $0xffffffffffffffd8,%rdx
 10192e0:	mov    %rdx,0x18(%r14)
 10192e4:	add    $0xffffffffffffffd8,%rdi
 10192e8:	mov    %rdi,0x30(%rax)
 10192ec:	mov    0x100(%rax),%rdx
 10192f3:	mov    %rdx,(%rsi)
 10192f6:	mov    %rsi,0x100(%rax)
 10192fd:	inc    %rcx
 1019300:	mov    %rcx,0x108(%rax)
 1019307:	test   %r12,%r12
 101930a:	je     1019369 <unwind_many+0x159>
 101930c:	mov    -0x10(%r12),%rcx
 1019311:	movabs $0x4000000000000002,%rax
 101931b:	test   %rax,%rcx
 101931e:	jne    1019350 <unwind_many+0x140>
 1019320:	mov    -0x18(%r12),%rax
 1019325:	test   %rax,%rax
 1019328:	je     1019408 <unwind_many+0x1f8>
 101932e:	and    $0x1,%ecx
 1019331:	jne    1019408 <unwind_many+0x1f8>
 1019337:	dec    %rax
 101933a:	mov    %rax,-0x18(%r12)
 101933f:	jne    1019350 <unwind_many+0x140>
 1019341:	cmpq   $0x0,-0x20(%r12)
 1019347:	je     10193e5 <unwind_many+0x1d5>
 101934d:	nopl   (%rax)
 1019350:	mov    0x1608(%r14),%rax
 1019357:	cmpq   $0x0,0xc8(%rax)
 101935f:	je     1019369 <unwind_many+0x159>
 1019361:	mov    %r14,%rdi
 1019364:	call   1016210 <myl_rc_drain>
 1019369:	test   %r15,%r15
 101936c:	je     10193b0 <unwind_many+0x1a0>
 101936e:	mov    -0x10(%r15),%rcx
 1019372:	movabs $0x4000000000000002,%rax
 101937c:	test   %rax,%rcx
 101937f:	jne    10193b0 <unwind_many+0x1a0>
 1019381:	mov    -0x18(%r15),%rax
 1019385:	test   %rax,%rax
 1019388:	je     1019408 <unwind_many+0x1f8>
 101938a:	and    $0x1,%ecx
 101938d:	jne    1019408 <unwind_many+0x1f8>
 101938f:	dec    %rax
 1019392:	mov    %rax,-0x18(%r15)
 1019396:	jne    10193b0 <unwind_many+0x1a0>
 1019398:	cmpq   $0x0,-0x20(%r15)
 101939d:	je     1019274 <unwind_many+0x64>
 10193a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 10193b0:	mov    0x1608(%r14),%rax
 10193b7:	cmpq   $0x0,0xc8(%rax)
 10193bf:	je     1019290 <unwind_many+0x80>
 10193c5:	mov    %r14,%rdi
 10193c8:	call   1016210 <myl_rc_drain>
 10193cd:	jmp    1019290 <unwind_many+0x80>
 10193d2:	mov    %r14,%rdi
 10193d5:	call   1019483 <entry_release>
 10193da:	test   %r12,%r12
 10193dd:	jne    101930c <unwind_many+0xfc>
 10193e3:	jmp    1019369 <unwind_many+0x159>
 10193e5:	add    $0xffffffffffffffe0,%r12
 10193e9:	mov    %r14,%rdi
 10193ec:	mov    %r12,%rsi
 10193ef:	call   101940d <hold_death>
 10193f4:	jmp    1019369 <unwind_many+0x159>
 10193f9:	add    $0x8,%rsp
 10193fd:	pop    %rbx
 10193fe:	pop    %r12
 1019400:	pop    %r13
 1019402:	pop    %r14
 1019404:	pop    %r15
 1019406:	pop    %rbp
 1019407:	ret
 1019408:	call   101267d <myl_rc_invariant_failed>

000000000101940d <hold_death>:
 101940d:	push   %rbp
 101940e:	mov    %rsp,%rbp
 1019411:	push   %rbx
 1019412:	push   %rax
 1019413:	mov    0x10(%rsi),%rax
 1019417:	test   $0x1,%al
 1019419:	jne    101947e <hold_death+0x71>
 101941b:	mov    %rdi,%rbx
 101941e:	or     $0x1,%rax
 1019422:	mov    %rax,0x10(%rsi)
 1019426:	mov    0x1608(%rdi),%rax
 101942d:	cmpl   $0x0,0xd0(%rax)
 1019434:	je     1019450 <hold_death+0x43>
 1019436:	mov    0xc8(%rax),%rax
 101943d:	mov    %rax,(%rsi)
 1019440:	mov    0x1608(%rbx),%rax
 1019447:	mov    %rsi,0xc8(%rax)
 101944e:	jmp    1019469 <hold_death+0x5c>
 1019450:	mov    %rbx,%rdi
 1019453:	call   1012b00 <myl_rc_dead_outside>
 1019458:	mov    0x1608(%rbx),%rax
 101945f:	cmpq   $0x0,0xc8(%rax)
 1019467:	je     1019477 <hold_death+0x6a>
 1019469:	mov    %rbx,%rdi
 101946c:	add    $0x8,%rsp
 1019470:	pop    %rbx
 1019471:	pop    %rbp
 1019472:	jmp    1016210 <myl_rc_drain>
 1019477:	add    $0x8,%rsp
 101947b:	pop    %rbx
 101947c:	pop    %rbp
 101947d:	ret
 101947e:	call   101267d <myl_rc_invariant_failed>

0000000001019483 <entry_release>:
 1019483:	push   %rbp
 1019484:	mov    %rsp,%rbp
 1019487:	mov    $0x28,%edx
 101948c:	pop    %rbp
 101948d:	jmp    1012710 <myl_rc_meta_free>
 1019492:	int3
 1019493:	int3
 1019494:	int3
 1019495:	int3
 1019496:	int3
 1019497:	int3
 1019498:	int3
 1019499:	int3
 101949a:	int3
 101949b:	int3
 101949c:	int3
 101949d:	int3
 101949e:	int3
 101949f:	int3

00000000010194a0 <transfer>:
 10194a0:	push   %rbp
 10194a1:	mov    %rsp,%rbp
 10194a4:	push   %r15
 10194a6:	push   %r14
 10194a8:	push   %r13
 10194aa:	push   %r12
 10194ac:	push   %rbx
 10194ad:	sub    $0x2b8,%rsp
 10194b4:	mov    %r9d,-0x50(%rbp)
 10194b8:	mov    %ecx,-0x2c(%rbp)
 10194bb:	test   %rdi,%rdi
 10194be:	je     1019eac <transfer+0xa0c>
 10194c4:	test   %rdx,%rdx
 10194c7:	je     1019eac <transfer+0xa0c>
 10194cd:	mov    %rsi,%r15
 10194d0:	test   %rsi,%rsi
 10194d3:	je     1019eac <transfer+0xa0c>
 10194d9:	mov    %r8d,%r14d
 10194dc:	mov    0x1608(%rdi),%r8
 10194e3:	test   %r8,%r8
 10194e6:	je     1019eac <transfer+0xa0c>
 10194ec:	mov    0x8(%r15),%r12
 10194f0:	test   %r12,%r12
 10194f3:	je     1019eac <transfer+0xa0c>
 10194f9:	mov    0x8(%rdx),%r13
 10194fd:	test   %r13,%r13
 1019500:	je     1019eac <transfer+0xa0c>
 1019506:	movabs $0x9e3779b97f4a7c15,%rbx
 1019510:	mov    (%rdx),%r11
 1019513:	mov    0x58(%r8),%rax
 1019517:	mov    0x60(%r8),%rcx
 101951b:	mov    0x70(%r8),%r10d
 101951f:	mov    %r11,%r8
 1019522:	imul   %rbx,%r8
 1019526:	shrx   %r10,%r8,%r9
 101952b:	and    %rcx,%r9
 101952e:	mov    %r9,%r8
 1019531:	shl    $0x4,%r8
 1019535:	mov    (%rax,%r8,1),%r8
 1019539:	cmp    %r11,%r8
 101953c:	je     101955b <transfer+0xbb>
 101953e:	xor    %esi,%esi
 1019540:	test   %r8,%r8
 1019543:	je     1019564 <transfer+0xc4>
 1019545:	inc    %r9
 1019548:	and    %rcx,%r9
 101954b:	mov    %r9,%r8
 101954e:	shl    $0x4,%r8
 1019552:	mov    (%rax,%r8,1),%r8
 1019556:	cmp    %r11,%r8
 1019559:	jne    1019540 <transfer+0xa0>
 101955b:	shl    $0x4,%r9
 101955f:	mov    0x8(%rax,%r9,1),%rsi
 1019564:	mov    (%r15),%r11
 1019567:	mov    %r11,%r8
 101956a:	imul   %rbx,%r8
 101956e:	shrx   %r10,%r8,%r9
 1019573:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019580:	and    %rcx,%r9
 1019583:	mov    %r9,%r8
 1019586:	shl    $0x4,%r8
 101958a:	mov    (%rax,%r8,1),%r8
 101958e:	cmp    %r11,%r8
 1019591:	je     10195a1 <transfer+0x101>
 1019593:	test   %r8,%r8
 1019596:	je     1019eac <transfer+0xa0c>
 101959c:	inc    %r9
 101959f:	jmp    1019580 <transfer+0xe0>
 10195a1:	test   %rsi,%rsi
 10195a4:	je     1019eac <transfer+0xa0c>
 10195aa:	shl    $0x4,%r9
 10195ae:	mov    0x8(%rax,%r9,1),%rax
 10195b3:	test   %rax,%rax
 10195b6:	je     1019eac <transfer+0xa0c>
 10195bc:	mov    (%rsi),%rcx
 10195bf:	cmp    (%rax),%rcx
 10195c2:	jne    1019eac <transfer+0xa0c>
 10195c8:	cmp    %r12,%r13
 10195cb:	je     1019eac <transfer+0xa0c>
 10195d1:	mov    %rdx,-0x98(%rbp)
 10195d8:	mov    0x18(%r15),%ecx
 10195dc:	mov    $0x3,%ebx
 10195e1:	cmp    0x70(%rdi),%ecx
 10195e4:	ja     1019c79 <transfer+0x7d9>
 10195ea:	mov    -0x50(%rbp),%r9d
 10195ee:	test   %r9d,%r9d
 10195f1:	mov    %rdi,-0x38(%rbp)
 10195f5:	mov    %rsi,-0x48(%rbp)
 10195f9:	je     1019614 <transfer+0x174>
 10195fb:	cmp    $0x1,%r9d
 10195ff:	setne  %al
 1019602:	test   %r14d,%r14d
 1019605:	setne  %dl
 1019608:	or     %dl,%al
 101960a:	je     1019651 <transfer+0x1b1>
 101960c:	mov    %edx,-0x3c(%rbp)
 101960f:	jmp    1019747 <transfer+0x2a7>
 1019614:	cmpl   $0x1,0x8(%rsi)
 1019618:	jne    1019643 <transfer+0x1a3>
 101961a:	mov    %r12,%rsi
 101961d:	mov    %r13,%rdx
 1019620:	mov    -0x2c(%rbp),%r8d
 1019624:	call   1019f60 <pointer_fast>
 1019629:	mov    -0x48(%rbp),%rsi
 101962d:	mov    -0x38(%rbp),%rdi
 1019631:	mov    %eax,%ebx
 1019633:	test   %eax,%eax
 1019635:	jns    1019c79 <transfer+0x7d9>
 101963b:	mov    0x18(%r15),%ecx
 101963f:	mov    -0x50(%rbp),%r9d
 1019643:	test   %r14d,%r14d
 1019646:	setne  %al
 1019649:	mov    %eax,-0x3c(%rbp)
 101964c:	jmp    1019747 <transfer+0x2a7>
 1019651:	cmpl   $0x1,0x8(%rsi)
 1019655:	jne    1019740 <transfer+0x2a0>
 101965b:	mov    0x0(%r13),%rbx
 101965f:	test   %rbx,%rbx
 1019662:	je     101970d <transfer+0x26d>
 1019668:	mov    -0x10(%rbx),%rax
 101966c:	test   $0x2,%al
 101966e:	jne    101970d <transfer+0x26d>
 1019674:	mov    %rax,%rdx
 1019677:	shr    $0x28,%rdx
 101967b:	and    $0xfffff,%edx
 1019681:	xor    %r8d,%r8d
 1019684:	bt     $0x3e,%rax
 1019689:	movl   $0x0,-0x3c(%rbp)
 1019690:	cmovae %r8d,%edx
 1019694:	bt     $0x3c,%rax
 1019699:	jb     1019747 <transfer+0x2a7>
 101969f:	cmp    %ecx,%edx
 10196a1:	ja     1019747 <transfer+0x2a7>
 10196a7:	movabs $0x4000000000000000,%rcx
 10196b1:	test   %rcx,%rax
 10196b4:	jne    10196e8 <transfer+0x248>
 10196b6:	or     -0x2c(%rbp),%edx
 10196b9:	jne    10196e8 <transfer+0x248>
 10196bb:	test   $0x1,%al
 10196bd:	jne    1019eac <transfer+0xa0c>
 10196c3:	mov    -0x20(%rbx),%rcx
 10196c7:	cmp    $0xffffffffffffffff,%rcx
 10196cb:	je     1019e7b <transfer+0x9db>
 10196d1:	test   %rcx,%rcx
 10196d4:	jne    10196e1 <transfer+0x241>
 10196d6:	cmpq   $0x0,-0x18(%rbx)
 10196db:	je     1019eac <transfer+0xa0c>
 10196e1:	inc    %rcx
 10196e4:	mov    %rcx,-0x20(%rbx)
 10196e8:	bt     $0x3d,%rax
 10196ed:	jb     101970d <transfer+0x26d>
 10196ef:	mov    %rbx,%rdi
 10196f2:	call   101e090 <myl_rc_native_mutable>
 10196f7:	mov    -0x38(%rbp),%rdi
 10196fb:	test   %eax,%eax
 10196fd:	je     101970d <transfer+0x26d>
 10196ff:	movabs $0x2000000000000000,%rax
 1019709:	or     %rax,-0x10(%rbx)
 101970d:	mov    %rbx,(%r12)
 1019711:	cmpl   $0x1,-0x2c(%rbp)
 1019715:	jne    101971f <transfer+0x27f>
 1019717:	movq   $0x0,0x0(%r13)
 101971f:	mov    0x1608(%rdi),%rax
 1019726:	xor    %ebx,%ebx
 1019728:	cmpq   $0x0,0xc8(%rax)
 1019730:	je     1019c79 <transfer+0x7d9>
 1019736:	call   1016210 <myl_rc_drain>
 101973b:	jmp    1019c79 <transfer+0x7d9>
 1019740:	movl   $0x0,-0x3c(%rbp)
 1019747:	vxorps %xmm0,%xmm0,%xmm0
 101974b:	vmovups %ymm0,-0x140(%rbp)
 1019753:	vmovups %ymm0,-0x160(%rbp)
 101975b:	vmovups %ymm0,-0x180(%rbp)
 1019763:	vmovups %ymm0,-0x1a0(%rbp)
 101976b:	vmovups %ymm0,-0x1c0(%rbp)
 1019773:	vmovups %ymm0,-0x1e0(%rbp)
 101977b:	movq   $0x0,-0x120(%rbp)
 1019786:	mov    %r14d,-0x138(%rbp)
 101978d:	mov    %r9d,-0x134(%rbp)
 1019794:	mov    %rdi,-0x88(%rbp)
 101979b:	lea    -0x2e0(%rbp),%rax
 10197a2:	mov    %rax,-0x80(%rbp)
 10197a6:	movq   $0x8,-0x78(%rbp)
 10197ae:	movq   $0x0,-0x70(%rbp)
 10197b6:	mov    %ecx,-0x68(%rbp)
 10197b9:	mov    -0x2c(%rbp),%r12d
 10197bd:	mov    %r12d,-0x64(%rbp)
 10197c1:	lea    -0x1e0(%rbp),%rax
 10197c8:	mov    %rax,-0x60(%rbp)
 10197cc:	mov    0x28(%rsi),%rbx
 10197d0:	cmp    $0x9,%rbx
 10197d4:	jb     1019833 <transfer+0x393>
 10197d6:	mov    %rbx,%rax
 10197d9:	shr    $0x3b,%rax
 10197dd:	jne    1019eac <transfer+0xa0c>
 10197e3:	mov    %rbx,%rsi
 10197e6:	shl    $0x5,%rsi
 10197ea:	vzeroupper
 10197ed:	call   1012690 <myl_rc_meta_alloc>
 10197f2:	test   %rax,%rax
 10197f5:	je     1019c8d <transfer+0x7ed>
 10197fb:	mov    -0x78(%rbp),%rdx
 10197ff:	cmp    $0x9,%rdx
 1019803:	jb     1019823 <transfer+0x383>
 1019805:	mov    -0x88(%rbp),%rdi
 101980c:	mov    -0x80(%rbp),%rsi
 1019810:	shl    $0x5,%rdx
 1019814:	mov    %rax,%r12
 1019817:	call   1012710 <myl_rc_meta_free>
 101981c:	mov    %r12,%rax
 101981f:	mov    -0x2c(%rbp),%r12d
 1019823:	mov    %rax,-0x80(%rbp)
 1019827:	mov    %rbx,-0x78(%rbp)
 101982b:	mov    -0x38(%rbp),%rdi
 101982f:	mov    -0x48(%rbp),%rsi
 1019833:	mov    0x8(%r15),%rax
 1019837:	mov    -0x98(%rbp),%rbx
 101983e:	mov    0x8(%rbx),%rcx
 1019842:	test   %r12d,%r12d
 1019845:	je     101985a <transfer+0x3ba>
 1019847:	mov    (%rsi),%rdx
 101984a:	mov    %rax,%rdi
 101984d:	mov    %rcx,%rsi
 1019850:	vzeroupper
 1019853:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 1019858:	jmp    101986b <transfer+0x3cb>
 101985a:	mov    $0x1,%r8d
 1019860:	mov    %rax,%rdx
 1019863:	vzeroupper
 1019866:	call   1016c50 <myl_rc_value_seed>
 101986b:	cmpl   $0x2,-0x50(%rbp)
 101986f:	mov    -0x48(%rbp),%rsi
 1019873:	jne    1019972 <transfer+0x4d2>
 1019879:	cmpl   $0x1,0x8(%rsi)
 101987d:	jne    1019972 <transfer+0x4d2>
 1019883:	mov    0x8(%r15),%rdx
 1019887:	mov    0x8(%rbx),%rax
 101988b:	mov    (%rax),%rsi
 101988e:	test   %rsi,%rsi
 1019891:	je     1019cdb <transfer+0x83b>
 1019897:	mov    -0x10(%rsi),%rax
 101989b:	mov    %rax,%rcx
 101989e:	shr    $0x28,%rcx
 10198a2:	and    $0xfffff,%ecx
 10198a8:	xor    %edi,%edi
 10198aa:	bt     $0x3e,%rax
 10198af:	cmovb  %ecx,%edi
 10198b2:	mov    $0x3,%ebx
 10198b7:	cmp    -0x68(%rbp),%edi
 10198ba:	mov    -0x38(%rbp),%r8
 10198be:	ja     1019993 <transfer+0x4f3>
 10198c4:	mov    %edi,-0x54(%rbp)
 10198c7:	mov    -0x88(%rbp),%rdi
 10198ce:	mov    %rsi,-0x90(%rbp)
 10198d5:	mov    -0x8(%rsi),%rsi
 10198d9:	mov    0x1608(%rdi),%rcx
 10198e0:	mov    0x34(%rsi),%eax
 10198e3:	cmp    %rax,0xa0(%rcx)
 10198ea:	jbe    1019eb4 <transfer+0xa14>
 10198f0:	mov    0x98(%rcx),%rcx
 10198f7:	shl    $0x4,%rax
 10198fb:	cmp    %rsi,(%rcx,%rax,1)
 10198ff:	jne    1019eb4 <transfer+0xa14>
 1019905:	add    %rax,%rcx
 1019908:	mov    0x8(%rcx),%r12
 101990c:	mov    %rdx,-0xa0(%rbp)
 1019913:	test   %r12,%r12
 1019916:	mov    -0x90(%rbp),%rax
 101991d:	mov    -0x54(%rbp),%ecx
 1019920:	je     1019eac <transfer+0xa0c>
 1019926:	cmpq   $0x0,0x18(%r12)
 101992c:	jne    1019eac <transfer+0xa0c>
 1019932:	mov    %rax,-0xc8(%rbp)
 1019939:	mov    %rax,-0xc0(%rbp)
 1019940:	mov    %r12,-0xb8(%rbp)
 1019947:	movq   $0x0,-0xb0(%rbp)
 1019952:	mov    %ecx,-0xa8(%rbp)
 1019958:	movl   $0x0,-0xa4(%rbp)
 1019962:	lea    0x19a7(%rip),%r13        # 101b310 <inspect_child>
 1019969:	mov    %r12,-0x50(%rbp)
 101996d:	jmp    1019a3f <transfer+0x59f>
 1019972:	mov    0x8(%r15),%rdx
 1019976:	mov    0x8(%rbx),%rcx
 101997a:	lea    0x121f(%rip),%r8        # 101aba0 <transfer_pointer>
 1019981:	lea    -0x88(%rbp),%rdi
 1019988:	call   101a070 <visit>
 101998d:	mov    %eax,%ebx
 101998f:	mov    -0x38(%rbp),%r8
 1019993:	test   %ebx,%ebx
 1019995:	je     10199a8 <transfer+0x508>
 1019997:	mov    -0x60(%rbp),%rax
 101999b:	movq   $0x0,0xb8(%rax)
 10199a6:	jmp    10199d1 <transfer+0x531>
 10199a8:	lea    -0x88(%rbp),%rdi
 10199af:	call   101acb0 <finish_clones>
 10199b4:	mov    %eax,%ebx
 10199b6:	mov    -0x60(%rbp),%rax
 10199ba:	test   %ebx,%ebx
 10199bc:	je     1019c94 <transfer+0x7f4>
 10199c2:	movq   $0x0,0xb8(%rax)
 10199cd:	mov    -0x38(%rbp),%r8
 10199d1:	mov    -0x48(%rbp),%rsi
 10199d5:	mov    0x8(%r15),%rdx
 10199d9:	test   %r12d,%r12d
 10199dc:	je     1019c4a <transfer+0x7aa>
 10199e2:	mov    -0x98(%rbp),%rax
 10199e9:	mov    0x8(%rax),%rcx
 10199ed:	lea    0x189c(%rip),%r8        # 101b290 <rollback_take>
 10199f4:	lea    -0x88(%rbp),%rdi
 10199fb:	mov    %rsi,%r14
 10199fe:	call   101a070 <visit>
 1019a03:	jmp    1019c5a <transfer+0x7ba>
 1019a08:	mov    %r13,-0x80(%rbp)
 1019a0c:	mov    %r14,-0x78(%rbp)
 1019a10:	mov    %r12,%r13
 1019a13:	mov    -0x50(%rbp),%r12
 1019a17:	mov    -0xe8(%rbp),%rcx
 1019a1e:	lea    -0x88(%rbp),%rdi
 1019a25:	mov    %rbx,%rsi
 1019a28:	mov    %rcx,%rdx
 1019a2b:	mov    %r13,%r8
 1019a2e:	call   101a070 <visit>
 1019a33:	test   %eax,%eax
 1019a35:	mov    -0x38(%rbp),%r8
 1019a39:	jne    1019e5e <transfer+0x9be>
 1019a3f:	cmpq   $0x0,0x30(%r12)
 1019a45:	movabs $0x9e3779b97f4a7c15,%rbx
 1019a4f:	je     1019ce9 <transfer+0x849>
 1019a55:	mov    -0xc8(%rbp),%rsi
 1019a5c:	mov    -0xb8(%rbp),%rax
 1019a63:	mov    0x30(%rax),%r10
 1019a67:	test   %r10,%r10
 1019a6a:	je     1019aaa <transfer+0x60a>
 1019a6c:	mov    -0x88(%rbp),%rdi
 1019a73:	mov    -0xc0(%rbp),%rdx
 1019a7a:	lea    -0xb0(%rbp),%rcx
 1019a81:	lea    -0x110(%rbp),%r8
 1019a88:	lea    -0xf0(%rbp),%r9
 1019a8f:	call   *%r10
 1019a92:	mov    -0x38(%rbp),%r8
 1019a96:	test   %eax,%eax
 1019a98:	je     1019ce9 <transfer+0x849>
 1019a9e:	mov    -0xf0(%rbp),%rax
 1019aa5:	jmp    1019b5b <transfer+0x6bb>
 1019aaa:	mov    -0xb0(%rbp),%rcx
 1019ab1:	mov    -0x10(%rsi),%rdx
 1019ab5:	mov    %rdx,%rdi
 1019ab8:	shr    $0x2,%rdi
 1019abc:	movabs $0x4000000000000000,%r9
 1019ac6:	test   %r9,%rdx
 1019ac9:	movabs $0x3fffffffff,%rdx
 1019ad3:	movabs $0x3ffffffffffffff,%r9
 1019add:	cmove  %r9,%rdx
 1019ae1:	and    %rdi,%rdx
 1019ae4:	cmp    %rdx,%rcx
 1019ae7:	je     1019ce9 <transfer+0x849>
 1019aed:	mov    0x8(%rax),%rax
 1019af1:	lea    0x1(%rcx),%rdx
 1019af5:	mov    %rdx,-0xb0(%rbp)
 1019afc:	imul   (%rax),%rcx
 1019b00:	mov    -0xc0(%rbp),%rdx
 1019b07:	lea    (%rdx,%rcx,1),%rdi
 1019b0b:	mov    -0xa8(%rbp),%r8d
 1019b12:	mov    %rax,-0x110(%rbp)
 1019b19:	mov    %rdi,-0x108(%rbp)
 1019b20:	mov    %rdx,-0x100(%rbp)
 1019b27:	mov    %r8d,-0xf8(%rbp)
 1019b2e:	movl   $0x0,-0xf4(%rbp)
 1019b38:	add    %rsi,%rcx
 1019b3b:	mov    %rax,-0xf0(%rbp)
 1019b42:	mov    %rcx,-0xe8(%rbp)
 1019b49:	mov    %rsi,-0xe0(%rbp)
 1019b50:	movq   $0x0,-0xd8(%rbp)
 1019b5b:	mov    -0x88(%rbp),%rdi
 1019b62:	mov    0x1608(%rdi),%rsi
 1019b69:	mov    0x58(%rsi),%rcx
 1019b6d:	mov    0x60(%rsi),%rdx
 1019b71:	movzbl 0x70(%rsi),%esi
 1019b75:	mov    %rax,%r8
 1019b78:	imul   %rbx,%r8
 1019b7c:	shrx   %rsi,%r8,%rsi
 1019b81:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019b90:	and    %rdx,%rsi
 1019b93:	mov    %rsi,%r8
 1019b96:	shl    $0x4,%r8
 1019b9a:	mov    (%rcx,%r8,1),%r8
 1019b9e:	cmp    %rax,%r8
 1019ba1:	je     1019bc0 <transfer+0x720>
 1019ba3:	test   %r8,%r8
 1019ba6:	je     1019eac <transfer+0xa0c>
 1019bac:	inc    %rsi
 1019baf:	jmp    1019b90 <transfer+0x6f0>
 1019bb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1019bc0:	shl    $0x4,%rsi
 1019bc4:	mov    0x8(%rcx,%rsi,1),%rbx
 1019bc9:	test   %rbx,%rbx
 1019bcc:	je     1019eac <transfer+0xa0c>
 1019bd2:	mov    0x28(%rbx),%r14
 1019bd6:	cmp    $0x2,%r14
 1019bda:	jb     1019a17 <transfer+0x577>
 1019be0:	cmp    -0x78(%rbp),%r14
 1019be4:	jbe    1019a17 <transfer+0x577>
 1019bea:	cmpq   $0x0,-0x70(%rbp)
 1019bef:	jne    1019eac <transfer+0xa0c>
 1019bf5:	movabs $0x7ffffffffffffff,%rax
 1019bff:	cmp    %rax,%r14
 1019c02:	ja     1019eac <transfer+0xa0c>
 1019c08:	mov    %r13,%r12
 1019c0b:	mov    %r14,%rsi
 1019c0e:	shl    $0x5,%rsi
 1019c12:	call   1012690 <myl_rc_meta_alloc>
 1019c17:	test   %rax,%rax
 1019c1a:	je     1019e69 <transfer+0x9c9>
 1019c20:	mov    %rax,%r13
 1019c23:	mov    -0x78(%rbp),%rdx
 1019c27:	cmp    $0x9,%rdx
 1019c2b:	jb     1019a08 <transfer+0x568>
 1019c31:	mov    -0x88(%rbp),%rdi
 1019c38:	mov    -0x80(%rbp),%rsi
 1019c3c:	shl    $0x5,%rdx
 1019c40:	call   1012710 <myl_rc_meta_free>
 1019c45:	jmp    1019a08 <transfer+0x568>
 1019c4a:	mov    $0x1,%ecx
 1019c4f:	mov    %r8,%rdi
 1019c52:	mov    %rsi,%r14
 1019c55:	call   1015bb0 <myl_rc_edges_release>
 1019c5a:	mov    0x8(%r15),%rdi
 1019c5e:	mov    (%r14),%rdx
 1019c61:	xor    %esi,%esi
 1019c63:	call   101e6b0 <compiler_rt.fastMemset>
 1019c68:	mov    $0x1,%esi
 1019c6d:	lea    -0x88(%rbp),%rdi
 1019c74:	call   101a380 <dispose_walk>
 1019c79:	mov    %ebx,%eax
 1019c7b:	add    $0x2b8,%rsp
 1019c82:	pop    %rbx
 1019c83:	pop    %r12
 1019c85:	pop    %r13
 1019c87:	pop    %r14
 1019c89:	pop    %r15
 1019c8b:	pop    %rbp
 1019c8c:	ret
 1019c8d:	mov    $0x1,%ebx
 1019c92:	jmp    1019c79 <transfer+0x7d9>
 1019c94:	mov    0xb8(%rax),%rdi
 1019c9b:	test   %rdi,%rdi
 1019c9e:	mov    -0x38(%rbp),%r10
 1019ca2:	mov    -0x98(%rbp),%rbx
 1019ca9:	mov    -0x48(%rbp),%rsi
 1019cad:	je     1019dc0 <transfer+0x920>
 1019cb3:	movabs $0x2000000000000000,%rcx
 1019cbd:	mov    0xb0(%rax),%r11
 1019cc4:	mov    %edi,%edx
 1019cc6:	and    $0x3,%edx
 1019cc9:	cmp    $0x4,%rdi
 1019ccd:	jae    1019d68 <transfer+0x8c8>
 1019cd3:	xor    %r8d,%r8d
 1019cd6:	jmp    1019da1 <transfer+0x901>
 1019cdb:	mov    -0x38(%rbp),%r8
 1019cdf:	mov    %rsi,(%rdx)
 1019ce2:	xor    %ebx,%ebx
 1019ce4:	jmp    1019993 <transfer+0x4f3>
 1019ce9:	mov    -0x60(%rbp),%rax
 1019ced:	mov    0xac(%rax),%ecx
 1019cf3:	mov    %ecx,%edx
 1019cf5:	and    $0xfffffffb,%edx
 1019cf8:	mov    %edx,0xac(%rax)
 1019cfe:	test   $0x4,%cl
 1019d01:	jne    1019e1e <transfer+0x97e>
 1019d07:	cmpl   $0x0,-0x64(%rbp)
 1019d0b:	mov    -0x2c(%rbp),%r12d
 1019d0f:	mov    -0xa0(%rbp),%rdx
 1019d16:	mov    -0x90(%rbp),%rsi
 1019d1d:	jne    1019cdf <transfer+0x83f>
 1019d1f:	mov    -0x10(%rsi),%rax
 1019d23:	movabs $0x4000000000000000,%rcx
 1019d2d:	add    $0x2,%rcx
 1019d31:	test   %rcx,%rax
 1019d34:	jne    1019cdf <transfer+0x83f>
 1019d36:	test   $0x1,%al
 1019d38:	jne    1019eac <transfer+0xa0c>
 1019d3e:	mov    -0x20(%rsi),%rax
 1019d42:	cmp    $0xffffffffffffffff,%rax
 1019d46:	je     1019ea2 <transfer+0xa02>
 1019d4c:	test   %rax,%rax
 1019d4f:	jne    1019d5c <transfer+0x8bc>
 1019d51:	cmpq   $0x0,-0x18(%rsi)
 1019d56:	je     1019eac <transfer+0xa0c>
 1019d5c:	inc    %rax
 1019d5f:	mov    %rax,-0x20(%rsi)
 1019d63:	jmp    1019cdf <transfer+0x83f>
 1019d68:	and    $0xfffffffffffffffc,%rdi
 1019d6c:	xor    %r8d,%r8d
 1019d6f:	nop
 1019d70:	mov    (%r11,%r8,8),%r9
 1019d74:	or     %rcx,-0x10(%r9)
 1019d78:	mov    0x8(%r11,%r8,8),%r9
 1019d7d:	or     %rcx,-0x10(%r9)
 1019d81:	mov    0x10(%r11,%r8,8),%r9
 1019d86:	or     %rcx,-0x10(%r9)
 1019d8a:	mov    0x18(%r11,%r8,8),%r9
 1019d8f:	or     %rcx,-0x10(%r9)
 1019d93:	add    $0x4,%r8
 1019d97:	cmp    %r8,%rdi
 1019d9a:	jne    1019d70 <transfer+0x8d0>
 1019d9c:	test   %rdx,%rdx
 1019d9f:	je     1019dc0 <transfer+0x920>
 1019da1:	lea    (%r11,%r8,8),%r9
 1019da5:	xor    %edi,%edi
 1019da7:	nopw   0x0(%rax,%rax,1)
 1019db0:	mov    (%r9,%rdi,8),%r8
 1019db4:	or     %rcx,-0x10(%r8)
 1019db8:	inc    %rdi
 1019dbb:	cmp    %rdi,%rdx
 1019dbe:	jne    1019db0 <transfer+0x910>
 1019dc0:	movq   $0x0,0xb8(%rax)
 1019dcb:	cmp    $0x1,%r12d
 1019dcf:	jne    1019e01 <transfer+0x961>
 1019dd1:	mov    0x8(%r15),%rdx
 1019dd5:	mov    0x8(%rbx),%rcx
 1019dd9:	lea    0x14f0(%rip),%r8        # 101b2d0 <commit_take>
 1019de0:	lea    -0x88(%rbp),%rdi
 1019de7:	mov    %rsi,%r14
 1019dea:	call   101a070 <visit>
 1019def:	mov    0x8(%rbx),%rdi
 1019df3:	mov    (%r14),%rdx
 1019df6:	xor    %esi,%esi
 1019df8:	call   101e6b0 <compiler_rt.fastMemset>
 1019dfd:	mov    -0x38(%rbp),%r10
 1019e01:	xor    %ebx,%ebx
 1019e03:	cmpb   $0x0,-0x3c(%rbp)
 1019e07:	je     1019e17 <transfer+0x977>
 1019e09:	mov    -0x148(%rbp),%rax
 1019e10:	add    %rax,0x88(%r10)
 1019e17:	xor    %esi,%esi
 1019e19:	jmp    1019c6d <transfer+0x7cd>
 1019e1e:	lea    -0x88(%rbp),%rdi
 1019e25:	lea    -0xd0(%rbp),%rcx
 1019e2c:	mov    -0x90(%rbp),%rsi
 1019e33:	mov    -0x54(%rbp),%edx
 1019e36:	call   101b340 <schedule_clone>
 1019e3b:	test   %eax,%eax
 1019e3d:	mov    -0x2c(%rbp),%r12d
 1019e41:	jne    101998d <transfer+0x4ed>
 1019e47:	mov    -0xd0(%rbp),%rsi
 1019e4e:	mov    -0x38(%rbp),%r8
 1019e52:	mov    -0xa0(%rbp),%rdx
 1019e59:	jmp    1019cdf <transfer+0x83f>
 1019e5e:	mov    %eax,%ebx
 1019e60:	mov    -0x2c(%rbp),%r12d
 1019e64:	jmp    1019993 <transfer+0x4f3>
 1019e69:	mov    $0x1,%ebx
 1019e6e:	mov    -0x38(%rbp),%r8
 1019e72:	mov    -0x2c(%rbp),%r12d
 1019e76:	jmp    1019993 <transfer+0x4f3>
 1019e7b:	movq   $0x0,(%r12)
 1019e83:	mov    0x1608(%rdi),%rax
 1019e8a:	mov    $0x2,%ebx
 1019e8f:	cmpq   $0x0,0xc8(%rax)
 1019e97:	jne    1019736 <transfer+0x296>
 1019e9d:	jmp    1019c79 <transfer+0x7d9>
 1019ea2:	mov    $0x2,%ebx
 1019ea7:	jmp    1019993 <transfer+0x4f3>
 1019eac:	vzeroupper
 1019eaf:	call   101267d <myl_rc_invariant_failed>
 1019eb4:	call   10130fa <myl_rc_binding_find_slow>
 1019eb9:	mov    -0x38(%rbp),%r8
 1019ebd:	mov    %rax,%r12
 1019ec0:	jmp    101990c <transfer+0x46c>
 1019ec5:	int3
 1019ec6:	int3
 1019ec7:	int3
 1019ec8:	int3
 1019ec9:	int3
 1019eca:	int3
 1019ecb:	int3
 1019ecc:	int3
 1019ecd:	int3
 1019ece:	int3
 1019ecf:	int3

0000000001019ed0 <myl_rc_pointer_transfer>:
 1019ed0:	push   %rbp
 1019ed1:	mov    %rsp,%rbp
 1019ed4:	push   %r15
 1019ed6:	push   %r14
 1019ed8:	push   %r13
 1019eda:	push   %r12
 1019edc:	push   %rbx
 1019edd:	sub    $0x48,%rsp
 1019ee1:	mov    %r9d,%ebx
 1019ee4:	mov    %r8d,%r12d
 1019ee7:	mov    %rcx,%r15
 1019eea:	mov    %rdx,%r13
 1019eed:	mov    %rsi,-0x30(%rbp)
 1019ef1:	mov    %rdi,%r14
 1019ef4:	mov    %rdx,%rsi
 1019ef7:	mov    %rcx,%rdx
 1019efa:	mov    %r8d,%ecx
 1019efd:	mov    %r9d,%r8d
 1019f00:	call   1019f60 <pointer_fast>
 1019f05:	test   %eax,%eax
 1019f07:	jns    1019f51 <myl_rc_pointer_transfer+0x81>
 1019f09:	mov    -0x30(%rbp),%rax
 1019f0d:	mov    %rax,-0x50(%rbp)
 1019f11:	mov    %r13,-0x48(%rbp)
 1019f15:	movq   $0x0,-0x40(%rbp)
 1019f1d:	mov    %r12d,-0x38(%rbp)
 1019f21:	movl   $0x0,-0x34(%rbp)
 1019f28:	mov    %rax,-0x70(%rbp)
 1019f2c:	mov    %r15,-0x68(%rbp)
 1019f30:	vxorps %xmm0,%xmm0,%xmm0
 1019f34:	vmovups %xmm0,-0x60(%rbp)
 1019f39:	lea    -0x50(%rbp),%rsi
 1019f3d:	lea    -0x70(%rbp),%rdx
 1019f41:	mov    %r14,%rdi
 1019f44:	mov    %ebx,%ecx
 1019f46:	xor    %r8d,%r8d
 1019f49:	xor    %r9d,%r9d
 1019f4c:	call   10194a0 <transfer>
 1019f51:	add    $0x48,%rsp
 1019f55:	pop    %rbx
 1019f56:	pop    %r12
 1019f58:	pop    %r13
 1019f5a:	pop    %r14
 1019f5c:	pop    %r15
 1019f5e:	pop    %rbp
 1019f5f:	ret

0000000001019f60 <pointer_fast>:
 1019f60:	push   %rbp
 1019f61:	mov    %rsp,%rbp
 1019f64:	push   %r15
 1019f66:	push   %r14
 1019f68:	push   %rbx
 1019f69:	push   %rax
 1019f6a:	test   %rdi,%rdi
 1019f6d:	je     101a069 <pointer_fast+0x109>
 1019f73:	cmp    %rdx,%rsi
 1019f76:	je     101a069 <pointer_fast+0x109>
 1019f7c:	test   %rdx,%rdx
 1019f7f:	je     101a069 <pointer_fast+0x109>
 1019f85:	test   %rsi,%rsi
 1019f88:	je     101a069 <pointer_fast+0x109>
 1019f8e:	cmpq   $0x0,0x1608(%rdi)
 1019f96:	je     101a069 <pointer_fast+0x109>
 1019f9c:	mov    $0x3,%eax
 1019fa1:	cmp    0x70(%rdi),%ecx
 1019fa4:	ja     101a01c <pointer_fast+0xbc>
 1019fa6:	mov    (%rdx),%rbx
 1019fa9:	test   %rbx,%rbx
 1019fac:	je     1019ff0 <pointer_fast+0x90>
 1019fae:	mov    -0x10(%rbx),%r9
 1019fb2:	test   $0x2,%r9b
 1019fb6:	jne    1019ff0 <pointer_fast+0x90>
 1019fb8:	mov    %r9,%rax
 1019fbb:	shr    $0x28,%rax
 1019fbf:	and    $0xfffff,%eax
 1019fc4:	xor    %r10d,%r10d
 1019fc7:	bt     $0x3e,%r9
 1019fcc:	cmovb  %eax,%r10d
 1019fd0:	cmp    %ecx,%r10d
 1019fd3:	seta   %cl
 1019fd6:	mov    %r9,%r11
 1019fd9:	shr    $0x3c,%r11
 1019fdd:	and    $0x1,%r11d
 1019fe1:	mov    $0xffffffff,%eax
 1019fe6:	or     %cl,%r11b
 1019fe9:	jne    101a01c <pointer_fast+0xbc>
 1019feb:	test   %r8d,%r8d
 1019fee:	je     101a027 <pointer_fast+0xc7>
 1019ff0:	mov    %rbx,(%rsi)
 1019ff3:	xor    %eax,%eax
 1019ff5:	cmp    $0x1,%r8d
 1019ff9:	jne    101a002 <pointer_fast+0xa2>
 1019ffb:	movq   $0x0,(%rdx)
 101a002:	mov    0x1608(%rdi),%rcx
 101a009:	cmpq   $0x0,0xc8(%rcx)
 101a011:	je     101a01c <pointer_fast+0xbc>
 101a013:	mov    %eax,%ebx
 101a015:	call   1016210 <myl_rc_drain>
 101a01a:	mov    %ebx,%eax
 101a01c:	add    $0x8,%rsp
 101a020:	pop    %rbx
 101a021:	pop    %r14
 101a023:	pop    %r15
 101a025:	pop    %rbp
 101a026:	ret
 101a027:	test   %r10d,%r10d
 101a02a:	je     101a044 <pointer_fast+0xe4>
 101a02c:	movabs $0x2000000000000000,%rax
 101a036:	or     %rax,%r9
 101a039:	mov    %r9,-0x10(%rbx)
 101a03d:	mov    %rbx,(%rsi)
 101a040:	xor    %eax,%eax
 101a042:	jmp    101a002 <pointer_fast+0xa2>
 101a044:	mov    %rsi,%r15
 101a047:	mov    %rdi,%r14
 101a04a:	mov    %rbx,%rdi
 101a04d:	call   1012630 <myl_rc_owner_take>
 101a052:	test   %eax,%eax
 101a054:	je     101a05f <pointer_fast+0xff>
 101a056:	movq   $0x0,(%r15)
 101a05d:	jmp    101a064 <pointer_fast+0x104>
 101a05f:	mov    %rbx,(%r15)
 101a062:	xor    %eax,%eax
 101a064:	mov    %r14,%rdi
 101a067:	jmp    101a002 <pointer_fast+0xa2>
 101a069:	call   101267d <myl_rc_invariant_failed>
 101a06e:	int3
 101a06f:	int3

000000000101a070 <visit>:
 101a070:	push   %rbp
 101a071:	mov    %rsp,%rbp
 101a074:	push   %r15
 101a076:	push   %r14
 101a078:	push   %r13
 101a07a:	push   %r12
 101a07c:	push   %rbx
 101a07d:	sub    $0x38,%rsp
 101a081:	mov    %rdi,%rbx
 101a084:	movq   $0x0,0x18(%rdi)
 101a08c:	mov    0x8(%rsi),%r13d
 101a090:	mov    %r13d,%eax
 101a093:	or     $0x4,%eax
 101a096:	cmp    $0x5,%eax
 101a099:	jne    101a0b8 <visit+0x48>
 101a09b:	mov    %rbx,%rdi
 101a09e:	mov    %rdx,%rsi
 101a0a1:	mov    %rcx,%rdx
 101a0a4:	mov    %r13d,%ecx
 101a0a7:	add    $0x38,%rsp
 101a0ab:	pop    %rbx
 101a0ac:	pop    %r12
 101a0ae:	pop    %r13
 101a0b0:	pop    %r14
 101a0b2:	pop    %r15
 101a0b4:	pop    %rbp
 101a0b5:	jmp    *%r8
 101a0b8:	cmpq   $0x2,0x28(%rsi)
 101a0bd:	mov    %r8,-0x38(%rbp)
 101a0c1:	jbe    101a221 <visit+0x1b1>
 101a0c7:	test   %r13d,%r13d
 101a0ca:	je     101a35d <visit+0x2ed>
 101a0d0:	cmpq   $0x0,0x10(%rbx)
 101a0d5:	je     101a378 <visit+0x308>
 101a0db:	mov    0x8(%rbx),%rax
 101a0df:	movq   $0x1,0x18(%rbx)
 101a0e7:	mov    %rsi,(%rax)
 101a0ea:	mov    %rdx,0x8(%rax)
 101a0ee:	mov    %rcx,0x10(%rax)
 101a0f2:	movq   $0x0,0x18(%rax)
 101a0fa:	mov    0x18(%rbx),%rax
 101a0fe:	test   %rax,%rax
 101a101:	je     101a35d <visit+0x2ed>
 101a107:	mov    0x8(%rbx),%rcx
 101a10b:	mov    %rax,%rsi
 101a10e:	shl    $0x5,%rsi
 101a112:	lea    (%rcx,%rsi,1),%rdx
 101a116:	mov    -0x20(%rcx,%rsi,1),%rsi
 101a11b:	mov    0x8(%rsi),%ecx
 101a11e:	cmp    $0x5,%ecx
 101a121:	je     101a12d <visit+0xbd>
 101a123:	cmp    $0x3,%ecx
 101a126:	je     101a160 <visit+0xf0>
 101a128:	cmp    $0x1,%ecx
 101a12b:	jne    101a170 <visit+0x100>
 101a12d:	mov    -0x18(%rdx),%rsi
 101a131:	mov    -0x10(%rdx),%rdx
 101a135:	mov    %rbx,%rdi
 101a138:	call   *%r8
 101a13b:	test   %eax,%eax
 101a13d:	jne    101a36e <visit+0x2fe>
 101a143:	mov    0x18(%rbx),%rax
 101a147:	dec    %rax
 101a14a:	mov    %rax,0x18(%rbx)
 101a14e:	mov    -0x38(%rbp),%r8
 101a152:	jmp    101a0fe <visit+0x8e>
 101a154:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a160:	mov    -0x8(%rdx),%rcx
 101a164:	cmp    0x18(%rsi),%rcx
 101a168:	je     101a17a <visit+0x10a>
 101a16a:	jmp    101a186 <visit+0x116>
 101a16c:	nopl   0x0(%rax)
 101a170:	mov    -0x8(%rdx),%rdi
 101a174:	cmp    0x18(%rsi),%rdi
 101a178:	jne    101a1b2 <visit+0x142>
 101a17a:	dec    %rax
 101a17d:	mov    %rax,0x18(%rbx)
 101a181:	jmp    101a0fe <visit+0x8e>
 101a186:	lea    0x1(%rcx),%rdi
 101a18a:	mov    %rdi,-0x8(%rdx)
 101a18e:	mov    0x10(%rsi),%r10
 101a192:	cmpl   $0x0,0x8(%r10)
 101a197:	je     101a0fa <visit+0x8a>
 101a19d:	cmp    0x10(%rbx),%rax
 101a1a1:	jae    101a378 <visit+0x308>
 101a1a7:	imul   0x20(%rsi),%rcx
 101a1ac:	mov    -0x10(%rdx),%rdi
 101a1b0:	jmp    101a1fb <visit+0x18b>
 101a1b2:	lea    (%rdi,%rdi,2),%r9
 101a1b6:	shl    $0x3,%r9
 101a1ba:	add    0x10(%rsi),%r9
 101a1be:	inc    %rdi
 101a1c1:	mov    %rdi,-0x8(%rdx)
 101a1c5:	mov    -0x10(%rdx),%rdi
 101a1c9:	cmp    $0x4,%ecx
 101a1cc:	jne    101a1df <visit+0x16f>
 101a1ce:	mov    0x20(%rsi),%rcx
 101a1d2:	mov    (%rdi,%rcx,1),%ecx
 101a1d5:	cmp    0x10(%r9),%ecx
 101a1d9:	jne    101a0fa <visit+0x8a>
 101a1df:	mov    0x8(%r9),%r10
 101a1e3:	cmpl   $0x0,0x8(%r10)
 101a1e8:	je     101a0fa <visit+0x8a>
 101a1ee:	cmp    0x10(%rbx),%rax
 101a1f2:	jae    101a378 <visit+0x308>
 101a1f8:	mov    (%r9),%rcx
 101a1fb:	add    %rcx,%rdi
 101a1fe:	add    -0x18(%rdx),%rcx
 101a202:	inc    %rax
 101a205:	mov    %rax,0x18(%rbx)
 101a209:	mov    %r10,(%rdx)
 101a20c:	mov    %rcx,0x8(%rdx)
 101a210:	mov    %rdi,0x10(%rdx)
 101a214:	movq   $0x0,0x18(%rdx)
 101a21c:	jmp    101a0fa <visit+0x8a>
 101a221:	lea    -0x1(%r13),%eax
 101a225:	cmp    $0x3,%eax
 101a228:	mov    %rcx,-0x60(%rbp)
 101a22c:	mov    %rdx,-0x58(%rbp)
 101a230:	ja     101a296 <visit+0x226>
 101a232:	lea    -0x170f9(%rip),%rdi        # 1003140 <myl_rc_map_sentinel+0xa0>
 101a239:	movslq (%rdi,%rax,4),%rax
 101a23d:	add    %rdi,%rax
 101a240:	jmp    *%rax
 101a242:	mov    $0x1,%edx
 101a247:	jmp    101a298 <visit+0x228>
 101a249:	mov    0x10(%rsi),%rax
 101a24d:	mov    0x18(%rsi),%rdx
 101a251:	mov    0x20(%rsi),%rcx
 101a255:	mov    %rcx,-0x30(%rbp)
 101a259:	mov    0x8(%rax),%r13d
 101a25d:	jmp    101a2a0 <visit+0x230>
 101a25f:	mov    0x10(%rsi),%rdi
 101a263:	mov    0x18(%rsi),%rdx
 101a267:	mov    0x20(%rsi),%r12
 101a26b:	add    %rcx,%r12
 101a26e:	mov    $0x4,%r13d
 101a274:	movq   $0x0,-0x30(%rbp)
 101a27c:	jmp    101a2a5 <visit+0x235>
 101a27e:	mov    0x10(%rsi),%rdi
 101a282:	mov    0x18(%rsi),%rdx
 101a286:	mov    $0x2,%r13d
 101a28c:	movq   $0x0,-0x30(%rbp)
 101a294:	jmp    101a2a2 <visit+0x232>
 101a296:	xor    %edx,%edx
 101a298:	movq   $0x0,-0x30(%rbp)
 101a2a0:	xor    %edi,%edi
 101a2a2:	xor    %r12d,%r12d
 101a2a5:	lea    0x10(%rdi),%rax
 101a2a9:	mov    %rax,-0x40(%rbp)
 101a2ad:	mov    %rdx,%r15
 101a2b0:	neg    %r15
 101a2b3:	xor    %r14d,%r14d
 101a2b6:	mov    %rdx,-0x50(%rbp)
 101a2ba:	mov    %rdi,-0x48(%rbp)
 101a2be:	test   %rdi,%rdi
 101a2c1:	je     101a322 <visit+0x2b2>
 101a2c3:	xor    %eax,%eax
 101a2c5:	cmp    %rdx,%r14
 101a2c8:	mov    -0x38(%rbp),%r8
 101a2cc:	jae    101a35f <visit+0x2ef>
 101a2d2:	lea    (%r14,%r14,2),%rcx
 101a2d6:	mov    -0x40(%rbp),%rdx
 101a2da:	lea    (%rdx,%rcx,8),%rsi
 101a2de:	inc    %r14
 101a2e1:	jmp    101a304 <visit+0x294>
 101a2e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a2f0:	add    $0x18,%rsi
 101a2f4:	lea    (%r15,%r14,1),%rcx
 101a2f8:	inc    %rcx
 101a2fb:	inc    %r14
 101a2fe:	cmp    $0x1,%rcx
 101a302:	je     101a35f <visit+0x2ef>
 101a304:	mov    -0x8(%rsi),%rcx
 101a308:	mov    0x8(%rcx),%ecx
 101a30b:	test   %ecx,%ecx
 101a30d:	je     101a2f0 <visit+0x280>
 101a30f:	test   %r12,%r12
 101a312:	je     101a31c <visit+0x2ac>
 101a314:	mov    (%rsi),%edx
 101a316:	cmp    (%r12),%edx
 101a31a:	jne    101a2f0 <visit+0x280>
 101a31c:	mov    -0x10(%rsi),%rdx
 101a320:	jmp    101a339 <visit+0x2c9>
 101a322:	cmp    %rdx,%r14
 101a325:	mov    -0x38(%rbp),%r8
 101a329:	je     101a35d <visit+0x2ed>
 101a32b:	mov    %r14,%rdx
 101a32e:	inc    %r14
 101a331:	imul   -0x30(%rbp),%rdx
 101a336:	mov    %r13d,%ecx
 101a339:	mov    -0x58(%rbp),%rax
 101a33d:	lea    (%rax,%rdx,1),%rsi
 101a341:	add    -0x60(%rbp),%rdx
 101a345:	mov    %rbx,%rdi
 101a348:	call   *%r8
 101a34b:	test   %eax,%eax
 101a34d:	mov    -0x50(%rbp),%rdx
 101a351:	mov    -0x48(%rbp),%rdi
 101a355:	je     101a2be <visit+0x24e>
 101a35b:	jmp    101a35f <visit+0x2ef>
 101a35d:	xor    %eax,%eax
 101a35f:	add    $0x38,%rsp
 101a363:	pop    %rbx
 101a364:	pop    %r12
 101a366:	pop    %r13
 101a368:	pop    %r14
 101a36a:	pop    %r15
 101a36c:	pop    %rbp
 101a36d:	ret
 101a36e:	movq   $0x0,0x18(%rbx)
 101a376:	jmp    101a35f <visit+0x2ef>
 101a378:	call   101267d <myl_rc_invariant_failed>
 101a37d:	int3
 101a37e:	int3
 101a37f:	int3

000000000101a380 <dispose_walk>:
 101a380:	push   %rbp
 101a381:	mov    %rsp,%rbp
 101a384:	push   %r15
 101a386:	push   %r14
 101a388:	push   %rbx
 101a389:	push   %rax
 101a38a:	mov    %rdi,%rbx
 101a38d:	mov    0x28(%rdi),%r14
 101a391:	test   %esi,%esi
 101a393:	je     101a3b9 <dispose_walk+0x39>
 101a395:	cmpq   $0x0,0x20(%r14)
 101a39a:	je     101a3b9 <dispose_walk+0x39>
 101a39c:	xor    %r15d,%r15d
 101a39f:	nop
 101a3a0:	mov    (%rbx),%rdi
 101a3a3:	mov    0x18(%r14),%rax
 101a3a7:	mov    (%rax,%r15,8),%rsi
 101a3ab:	call   1016ee0 <myl_rc_construction_abort>
 101a3b0:	inc    %r15
 101a3b3:	cmp    0x20(%r14),%r15
 101a3b7:	jb     101a3a0 <dispose_walk+0x20>
 101a3b9:	mov    (%rbx),%rdi
 101a3bc:	mov    0xb0(%r14),%rsi
 101a3c3:	mov    0xc0(%r14),%rdx
 101a3ca:	shl    $0x3,%rdx
 101a3ce:	call   1012710 <myl_rc_meta_free>
 101a3d3:	mov    (%rbx),%rdi
 101a3d6:	mov    0x18(%r14),%rsi
 101a3da:	mov    0x28(%r14),%rdx
 101a3de:	shl    $0x3,%rdx
 101a3e2:	call   1012710 <myl_rc_meta_free>
 101a3e7:	mov    (%rbx),%rdi
 101a3ea:	mov    0x30(%r14),%rsi
 101a3ee:	mov    0xa0(%r14),%rax
 101a3f5:	shl    $0x3,%rax
 101a3f9:	lea    (%rax,%rax,2),%rdx
 101a3fd:	call   1012710 <myl_rc_meta_free>
 101a402:	mov    (%rbx),%rdi
 101a405:	mov    (%r14),%rsi
 101a408:	mov    0x10(%r14),%rax
 101a40c:	shl    $0x3,%rax
 101a410:	lea    (%rax,%rax,4),%rdx
 101a414:	call   1012710 <myl_rc_meta_free>
 101a419:	mov    0x10(%rbx),%rdx
 101a41d:	cmp    $0x9,%rdx
 101a421:	jb     101a433 <dispose_walk+0xb3>
 101a423:	mov    (%rbx),%rdi
 101a426:	mov    0x8(%rbx),%rsi
 101a42a:	shl    $0x5,%rdx
 101a42e:	call   1012710 <myl_rc_meta_free>
 101a433:	mov    (%rbx),%rdi
 101a436:	add    $0x8,%rsp
 101a43a:	pop    %rbx
 101a43b:	pop    %r14
 101a43d:	pop    %r15
 101a43f:	pop    %rbp
 101a440:	jmp    1016210 <myl_rc_drain>
 101a445:	int3
 101a446:	int3
 101a447:	int3
 101a448:	int3
 101a449:	int3
 101a44a:	int3
 101a44b:	int3
 101a44c:	int3
 101a44d:	int3
 101a44e:	int3
 101a44f:	int3

000000000101a450 <copy_many>:
 101a450:	push   %rbp
 101a451:	mov    %rsp,%rbp
 101a454:	push   %r15
 101a456:	push   %r14
 101a458:	push   %r13
 101a45a:	push   %r12
 101a45c:	push   %rbx
 101a45d:	sub    $0x228,%rsp
 101a464:	test   %rdi,%rdi
 101a467:	je     101a7cd <copy_many+0x37d>
 101a46d:	mov    %rdi,%r12
 101a470:	cmpq   $0x0,0x1608(%rdi)
 101a478:	je     101a7cd <copy_many+0x37d>
 101a47e:	mov    %rcx,%r15
 101a481:	mov    %rdx,%r9
 101a484:	mov    %rsi,%rbx
 101a487:	test   %rcx,%rcx
 101a48a:	je     101a49e <copy_many+0x4e>
 101a48c:	test   %rbx,%rbx
 101a48f:	je     101a7cd <copy_many+0x37d>
 101a495:	test   %r9,%r9
 101a498:	je     101a7cd <copy_many+0x37d>
 101a49e:	vxorps %xmm0,%xmm0,%xmm0
 101a4a2:	vmovups %ymm0,-0xb0(%rbp)
 101a4aa:	vmovups %ymm0,-0xd0(%rbp)
 101a4b2:	vmovups %ymm0,-0xf0(%rbp)
 101a4ba:	vmovups %ymm0,-0x110(%rbp)
 101a4c2:	vmovups %ymm0,-0x130(%rbp)
 101a4ca:	vmovups %ymm0,-0x150(%rbp)
 101a4d2:	movq   $0x0,-0x90(%rbp)
 101a4dd:	mov    %r12,-0x78(%rbp)
 101a4e1:	lea    -0x250(%rbp),%rax
 101a4e8:	mov    %rax,-0x70(%rbp)
 101a4ec:	movq   $0x8,-0x68(%rbp)
 101a4f4:	vxorps %xmm0,%xmm0,%xmm0
 101a4f8:	vmovups %xmm0,-0x60(%rbp)
 101a4fd:	lea    -0x150(%rbp),%rax
 101a504:	mov    %rax,-0x50(%rbp)
 101a508:	test   %r15,%r15
 101a50b:	je     101a728 <copy_many+0x2d8>
 101a511:	test   %r8d,%r8d
 101a514:	lea    0x685(%rip),%rax        # 101aba0 <transfer_pointer>
 101a51b:	lea    0x18ae(%rip),%rcx        # 101bdd0 <retain_pointer>
 101a522:	cmove  %rax,%rcx
 101a526:	mov    %rcx,-0x88(%rbp)
 101a52d:	xor    %r13d,%r13d
 101a530:	mov    %r12,-0x30(%rbp)
 101a534:	mov    %r9,-0x80(%rbp)
 101a538:	nopl   0x0(%rax,%rax,1)
 101a540:	mov    %r13,%r14
 101a543:	shl    $0x5,%r14
 101a547:	mov    (%r9,%r14,1),%rsi
 101a54b:	mov    0x1608(%r12),%rdx
 101a553:	mov    0x58(%rdx),%rax
 101a557:	mov    0x60(%rdx),%rcx
 101a55b:	mov    0x70(%rdx),%edx
 101a55e:	mov    %rsi,%rdi
 101a561:	movabs $0x9e3779b97f4a7c15,%r8
 101a56b:	imul   %r8,%rdi
 101a56f:	shrx   %rdx,%rdi,%rdi
 101a574:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a580:	and    %rcx,%rdi
 101a583:	mov    %rdi,%r8
 101a586:	shl    $0x4,%r8
 101a58a:	mov    (%rax,%r8,1),%r8
 101a58e:	cmp    %rsi,%r8
 101a591:	je     101a5a0 <copy_many+0x150>
 101a593:	test   %r8,%r8
 101a596:	je     101a5b0 <copy_many+0x160>
 101a598:	inc    %rdi
 101a59b:	jmp    101a580 <copy_many+0x130>
 101a59d:	nopl   (%rax)
 101a5a0:	shl    $0x4,%rdi
 101a5a4:	mov    0x8(%rax,%rdi,1),%rsi
 101a5a9:	jmp    101a5b2 <copy_many+0x162>
 101a5ab:	nopl   0x0(%rax,%rax,1)
 101a5b0:	xor    %esi,%esi
 101a5b2:	mov    (%rbx,%r14,1),%r10
 101a5b6:	mov    %r10,%rdi
 101a5b9:	movabs $0x9e3779b97f4a7c15,%r8
 101a5c3:	imul   %r8,%rdi
 101a5c7:	shrx   %rdx,%rdi,%rdx
 101a5cc:	nopl   0x0(%rax)
 101a5d0:	and    %rcx,%rdx
 101a5d3:	mov    %rdx,%rdi
 101a5d6:	shl    $0x4,%rdi
 101a5da:	mov    (%rax,%rdi,1),%rdi
 101a5de:	cmp    %r10,%rdi
 101a5e1:	je     101a600 <copy_many+0x1b0>
 101a5e3:	test   %rdi,%rdi
 101a5e6:	je     101a7cd <copy_many+0x37d>
 101a5ec:	inc    %rdx
 101a5ef:	jmp    101a5d0 <copy_many+0x180>
 101a5f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101a600:	test   %rsi,%rsi
 101a603:	je     101a7cd <copy_many+0x37d>
 101a609:	shl    $0x4,%rdx
 101a60d:	mov    0x8(%rax,%rdx,1),%rax
 101a612:	test   %rax,%rax
 101a615:	je     101a7cd <copy_many+0x37d>
 101a61b:	mov    (%rsi),%rcx
 101a61e:	cmp    (%rax),%rcx
 101a621:	jne    101a7cd <copy_many+0x37d>
 101a627:	lea    (%r9,%r14,1),%rax
 101a62b:	add    %rbx,%r14
 101a62e:	mov    %rax,-0x48(%rbp)
 101a632:	mov    0x8(%rax),%rcx
 101a636:	mov    0x8(%r14),%rdx
 101a63a:	cmp    %rdx,%rcx
 101a63d:	je     101a7cd <copy_many+0x37d>
 101a643:	mov    0x18(%r14),%eax
 101a647:	cmp    0x70(%r12),%eax
 101a64c:	ja     101a736 <copy_many+0x2e6>
 101a652:	mov    %r13,-0x38(%rbp)
 101a656:	mov    0x28(%rsi),%r13
 101a65a:	cmp    $0x2,%r13
 101a65e:	mov    %rsi,-0x40(%rbp)
 101a662:	jb     101a6d8 <copy_many+0x288>
 101a664:	cmp    -0x68(%rbp),%r13
 101a668:	jbe    101a6d8 <copy_many+0x288>
 101a66a:	cmpq   $0x0,-0x60(%rbp)
 101a66f:	jne    101a7cd <copy_many+0x37d>
 101a675:	mov    %r13,%rax
 101a678:	shr    $0x3b,%rax
 101a67c:	jne    101a7cd <copy_many+0x37d>
 101a682:	mov    %r13,%rsi
 101a685:	shl    $0x5,%rsi
 101a689:	mov    -0x78(%rbp),%rdi
 101a68d:	vzeroupper
 101a690:	call   1012690 <myl_rc_meta_alloc>
 101a695:	test   %rax,%rax
 101a698:	je     101a7bb <copy_many+0x36b>
 101a69e:	mov    %rax,%r12
 101a6a1:	mov    -0x68(%rbp),%rdx
 101a6a5:	cmp    $0x9,%rdx
 101a6a9:	jb     101a6bc <copy_many+0x26c>
 101a6ab:	mov    -0x78(%rbp),%rdi
 101a6af:	mov    -0x70(%rbp),%rsi
 101a6b3:	shl    $0x5,%rdx
 101a6b7:	call   1012710 <myl_rc_meta_free>
 101a6bc:	mov    %r12,-0x70(%rbp)
 101a6c0:	mov    %r13,-0x68(%rbp)
 101a6c4:	mov    0x8(%r14),%rdx
 101a6c8:	mov    -0x48(%rbp),%rax
 101a6cc:	mov    0x8(%rax),%rcx
 101a6d0:	mov    -0x30(%rbp),%r12
 101a6d4:	mov    -0x40(%rbp),%rsi
 101a6d8:	mov    $0x1,%r8d
 101a6de:	mov    %r12,%rdi
 101a6e1:	vzeroupper
 101a6e4:	call   1016c50 <myl_rc_value_seed>
 101a6e9:	mov    -0x38(%rbp),%r13
 101a6ed:	inc    %r13
 101a6f0:	mov    0x18(%r14),%eax
 101a6f4:	mov    %eax,-0x58(%rbp)
 101a6f7:	mov    0x8(%r14),%rdx
 101a6fb:	mov    -0x48(%rbp),%rax
 101a6ff:	mov    0x8(%rax),%rcx
 101a703:	lea    -0x78(%rbp),%rdi
 101a707:	mov    -0x40(%rbp),%rsi
 101a70b:	mov    -0x88(%rbp),%r8
 101a712:	call   101a070 <visit>
 101a717:	test   %eax,%eax
 101a719:	jne    101a73b <copy_many+0x2eb>
 101a71b:	cmp    %r15,%r13
 101a71e:	mov    -0x80(%rbp),%r9
 101a722:	jne    101a540 <copy_many+0xf0>
 101a728:	lea    -0x78(%rbp),%rdi
 101a72c:	vzeroupper
 101a72f:	call   101acb0 <finish_clones>
 101a734:	jmp    101a73e <copy_many+0x2ee>
 101a736:	mov    $0x3,%eax
 101a73b:	mov    %r13,%r15
 101a73e:	mov    %eax,%r14d
 101a741:	test   %eax,%eax
 101a743:	setne  %al
 101a746:	test   %r15,%r15
 101a749:	setne  %cl
 101a74c:	and    %al,%cl
 101a74e:	cmp    $0x1,%cl
 101a751:	jne    101a791 <copy_many+0x341>
 101a753:	add    $0x8,%rbx
 101a757:	nopw   0x0(%rax,%rax,1)
 101a760:	mov    -0x8(%rbx),%rsi
 101a764:	mov    (%rbx),%rdx
 101a767:	mov    $0x1,%ecx
 101a76c:	mov    %r12,%rdi
 101a76f:	vzeroupper
 101a772:	call   1015bb0 <myl_rc_edges_release>
 101a777:	mov    -0x8(%rbx),%rax
 101a77b:	mov    (%rbx),%rdi
 101a77e:	mov    (%rax),%rdx
 101a781:	xor    %esi,%esi
 101a783:	call   101e6b0 <compiler_rt.fastMemset>
 101a788:	add    $0x20,%rbx
 101a78c:	dec    %r15
 101a78f:	jne    101a760 <copy_many+0x310>
 101a791:	xor    %esi,%esi
 101a793:	test   %r14d,%r14d
 101a796:	setne  %sil
 101a79a:	lea    -0x78(%rbp),%rdi
 101a79e:	vzeroupper
 101a7a1:	call   101a380 <dispose_walk>
 101a7a6:	mov    %r14d,%eax
 101a7a9:	add    $0x228,%rsp
 101a7b0:	pop    %rbx
 101a7b1:	pop    %r12
 101a7b3:	pop    %r13
 101a7b5:	pop    %r14
 101a7b7:	pop    %r15
 101a7b9:	pop    %rbp
 101a7ba:	ret
 101a7bb:	mov    $0x1,%eax
 101a7c0:	mov    -0x38(%rbp),%r15
 101a7c4:	mov    -0x30(%rbp),%r12
 101a7c8:	jmp    101a73e <copy_many+0x2ee>
 101a7cd:	vzeroupper
 101a7d0:	call   101267d <myl_rc_invariant_failed>
 101a7d5:	int3
 101a7d6:	int3
 101a7d7:	int3
 101a7d8:	int3
 101a7d9:	int3
 101a7da:	int3
 101a7db:	int3
 101a7dc:	int3
 101a7dd:	int3
 101a7de:	int3
 101a7df:	int3

000000000101a7e0 <myl_rc_value_retain_many>:
 101a7e0:	push   %rbp
 101a7e1:	mov    %rsp,%rbp
 101a7e4:	mov    $0x1,%r8d
 101a7ea:	pop    %rbp
 101a7eb:	jmp    101a450 <copy_many>

000000000101a7f0 <myl_rc_value_take>:
 101a7f0:	push   %rbp
 101a7f1:	mov    %rsp,%rbp
 101a7f4:	mov    $0x1,%ecx
 101a7f9:	xor    %r8d,%r8d
 101a7fc:	xor    %r9d,%r9d
 101a7ff:	pop    %rbp
 101a800:	jmp    10194a0 <transfer>
 101a805:	int3
 101a806:	int3
 101a807:	int3
 101a808:	int3
 101a809:	int3
 101a80a:	int3
 101a80b:	int3
 101a80c:	int3
 101a80d:	int3
 101a80e:	int3
 101a80f:	int3

000000000101a810 <myl_rc_unique_owned>:
 101a810:	push   %rbp
 101a811:	mov    %rsp,%rbp
 101a814:	push   %r15
 101a816:	push   %r14
 101a818:	push   %rbx
 101a819:	push   %rax
 101a81a:	test   %rsi,%rsi
 101a81d:	je     101a89c <myl_rc_unique_owned+0x8c>
 101a81f:	mov    %rsi,%r14
 101a822:	mov    0x8(%rsi),%rax
 101a826:	test   %rax,%rax
 101a829:	je     101a89c <myl_rc_unique_owned+0x8c>
 101a82b:	mov    (%r14),%rcx
 101a82e:	test   %rcx,%rcx
 101a831:	je     101a89c <myl_rc_unique_owned+0x8c>
 101a833:	cmpl   $0x1,0x8(%rcx)
 101a837:	jne    101a89c <myl_rc_unique_owned+0x8c>
 101a839:	cmpq   $0x8,(%rcx)
 101a83d:	jne    101a89c <myl_rc_unique_owned+0x8c>
 101a83f:	mov    %rdi,%rbx
 101a842:	mov    (%rax),%r15
 101a845:	mov    %r15,%rsi
 101a848:	call   1012d10 <myl_rc_unique>
 101a84d:	mov    %eax,%ecx
 101a84f:	xor    %eax,%eax
 101a851:	test   %ecx,%ecx
 101a853:	jne    101a891 <myl_rc_unique_owned+0x81>
 101a855:	movq   $0x0,-0x20(%rbp)
 101a85d:	mov    0x18(%r14),%edx
 101a861:	lea    -0x20(%rbp),%rcx
 101a865:	mov    %rbx,%rdi
 101a868:	mov    %r15,%rsi
 101a86b:	xor    %r8d,%r8d
 101a86e:	call   101a8b0 <clone_payload>
 101a873:	test   %eax,%eax
 101a875:	jne    101a891 <myl_rc_unique_owned+0x81>
 101a877:	mov    0x8(%r14),%rcx
 101a87b:	mov    -0x20(%rbp),%rdx
 101a87f:	mov    %rdx,(%rcx)
 101a882:	mov    %rbx,%rdi
 101a885:	mov    %r15,%rsi
 101a888:	mov    %eax,%ebx
 101a88a:	call   1012cd0 <myl_rc_owner_release>
 101a88f:	mov    %ebx,%eax
 101a891:	add    $0x8,%rsp
 101a895:	pop    %rbx
 101a896:	pop    %r14
 101a898:	pop    %r15
 101a89a:	pop    %rbp
 101a89b:	ret
 101a89c:	call   101267d <myl_rc_invariant_failed>
 101a8a1:	int3
 101a8a2:	int3
 101a8a3:	int3
 101a8a4:	int3
 101a8a5:	int3
 101a8a6:	int3
 101a8a7:	int3
 101a8a8:	int3
 101a8a9:	int3
 101a8aa:	int3
 101a8ab:	int3
 101a8ac:	int3
 101a8ad:	int3
 101a8ae:	int3
 101a8af:	int3

000000000101a8b0 <clone_payload>:
 101a8b0:	push   %rbp
 101a8b1:	mov    %rsp,%rbp
 101a8b4:	push   %r15
 101a8b6:	push   %r14
 101a8b8:	push   %r13
 101a8ba:	push   %r12
 101a8bc:	push   %rbx
 101a8bd:	sub    $0x208,%rsp
 101a8c4:	mov    %rcx,-0x30(%rbp)
 101a8c8:	mov    %rdi,%r14
 101a8cb:	vxorps %xmm0,%xmm0,%xmm0
 101a8cf:	vmovups %ymm0,-0x90(%rbp)
 101a8d7:	vmovups %ymm0,-0xb0(%rbp)
 101a8df:	vmovups %ymm0,-0xd0(%rbp)
 101a8e7:	vmovups %ymm0,-0xf0(%rbp)
 101a8ef:	vmovups %ymm0,-0x110(%rbp)
 101a8f7:	vmovups %ymm0,-0x130(%rbp)
 101a8ff:	movq   $0x0,-0x70(%rbp)
 101a907:	mov    $0x1,%ecx
 101a90c:	test   %r8d,%r8d
 101a90f:	jne    101a937 <clone_payload+0x87>
 101a911:	xor    %ecx,%ecx
 101a913:	testb  $0x20,-0x9(%rsi)
 101a917:	je     101a937 <clone_payload+0x87>
 101a919:	mov    %rsi,%rdi
 101a91c:	mov    %rsi,%rbx
 101a91f:	mov    %edx,%r15d
 101a922:	vzeroupper
 101a925:	call   101e090 <myl_rc_native_mutable>
 101a92a:	mov    %r15d,%edx
 101a92d:	mov    %rbx,%rsi
 101a930:	xor    %ecx,%ecx
 101a932:	test   %eax,%eax
 101a934:	setne  %cl
 101a937:	mov    %ecx,-0x84(%rbp)
 101a93d:	mov    -0x10(%rsi),%rax
 101a941:	mov    %rax,%r15
 101a944:	shr    $0x28,%r15
 101a948:	and    $0xfffff,%r15d
 101a94f:	cmp    %edx,%r15d
 101a952:	cmovae %edx,%r15d
 101a956:	xor    %ebx,%ebx
 101a958:	bt     $0x3e,%rax
 101a95d:	cmovae %ebx,%r15d
 101a961:	test   %ecx,%ecx
 101a963:	cmove  %edx,%r15d
 101a967:	mov    %r14,-0x68(%rbp)
 101a96b:	lea    -0x230(%rbp),%rax
 101a972:	mov    %rax,-0x60(%rbp)
 101a976:	movq   $0x8,-0x58(%rbp)
 101a97e:	movq   $0x0,-0x50(%rbp)
 101a986:	mov    %r15d,-0x48(%rbp)
 101a98a:	movl   $0x0,-0x44(%rbp)
 101a991:	lea    -0x130(%rbp),%r13
 101a998:	mov    %r13,-0x40(%rbp)
 101a99c:	lea    -0x68(%rbp),%rdi
 101a9a0:	lea    -0x38(%rbp),%rcx
 101a9a4:	mov    %r15d,%edx
 101a9a7:	vzeroupper
 101a9aa:	call   101b340 <schedule_clone>
 101a9af:	test   %eax,%eax
 101a9b1:	je     101a9bb <clone_payload+0x10b>
 101a9b3:	mov    %eax,%r12d
 101a9b6:	jmp    101aa60 <clone_payload+0x1b0>
 101a9bb:	lea    -0x68(%rbp),%rdi
 101a9bf:	call   101acb0 <finish_clones>
 101a9c4:	xor    %r12d,%r12d
 101a9c7:	mov    -0x40(%rbp),%r13
 101a9cb:	test   %eax,%eax
 101a9cd:	je     101a9d9 <clone_payload+0x129>
 101a9cf:	xor    %ebx,%ebx
 101a9d1:	mov    %eax,%r12d
 101a9d4:	jmp    101aa60 <clone_payload+0x1b0>
 101a9d9:	mov    0xb8(%r13),%rsi
 101a9e0:	mov    $0x1,%bl
 101a9e2:	test   %rsi,%rsi
 101a9e5:	je     101aa60 <clone_payload+0x1b0>
 101a9e7:	movabs $0x2000000000000000,%rax
 101a9f1:	mov    0xb0(%r13),%rdx
 101a9f8:	mov    %esi,%ecx
 101a9fa:	and    $0x3,%ecx
 101a9fd:	cmp    $0x4,%rsi
 101aa01:	jae    101aa07 <clone_payload+0x157>
 101aa03:	xor    %edi,%edi
 101aa05:	jmp    101aa41 <clone_payload+0x191>
 101aa07:	and    $0xfffffffffffffffc,%rsi
 101aa0b:	xor    %edi,%edi
 101aa0d:	nopl   (%rax)
 101aa10:	mov    (%rdx,%rdi,8),%r8
 101aa14:	or     %rax,-0x10(%r8)
 101aa18:	mov    0x8(%rdx,%rdi,8),%r8
 101aa1d:	or     %rax,-0x10(%r8)
 101aa21:	mov    0x10(%rdx,%rdi,8),%r8
 101aa26:	or     %rax,-0x10(%r8)
 101aa2a:	mov    0x18(%rdx,%rdi,8),%r8
 101aa2f:	or     %rax,-0x10(%r8)
 101aa33:	add    $0x4,%rdi
 101aa37:	cmp    %rdi,%rsi
 101aa3a:	jne    101aa10 <clone_payload+0x160>
 101aa3c:	test   %rcx,%rcx
 101aa3f:	je     101aabf <clone_payload+0x20f>
 101aa41:	lea    (%rdx,%rdi,8),%rdx
 101aa45:	xor    %r12d,%r12d
 101aa48:	xor    %esi,%esi
 101aa4a:	nopw   0x0(%rax,%rax,1)
 101aa50:	mov    (%rdx,%rsi,8),%rdi
 101aa54:	or     %rax,-0x10(%rdi)
 101aa58:	inc    %rsi
 101aa5b:	cmp    %rsi,%rcx
 101aa5e:	jne    101aa50 <clone_payload+0x1a0>
 101aa60:	movq   $0x0,0xb8(%r13)
 101aa6b:	mov    -0x38(%rbp),%r13
 101aa6f:	test   %r15d,%r15d
 101aa72:	jne    101aa89 <clone_payload+0x1d9>
 101aa74:	test   %r12d,%r12d
 101aa77:	je     101aa89 <clone_payload+0x1d9>
 101aa79:	test   %r13,%r13
 101aa7c:	je     101aa89 <clone_payload+0x1d9>
 101aa7e:	mov    %r14,%rdi
 101aa81:	mov    %r13,%rsi
 101aa84:	call   1012cd0 <myl_rc_owner_release>
 101aa89:	xor    %esi,%esi
 101aa8b:	test   %r12d,%r12d
 101aa8e:	setne  %sil
 101aa92:	lea    -0x68(%rbp),%rdi
 101aa96:	call   101a380 <dispose_walk>
 101aa9b:	xor    %eax,%eax
 101aa9d:	test   %bl,%bl
 101aa9f:	cmovne %r13,%rax
 101aaa3:	mov    -0x30(%rbp),%rcx
 101aaa7:	mov    %rax,(%rcx)
 101aaaa:	mov    %r12d,%eax
 101aaad:	add    $0x208,%rsp
 101aab4:	pop    %rbx
 101aab5:	pop    %r12
 101aab7:	pop    %r13
 101aab9:	pop    %r14
 101aabb:	pop    %r15
 101aabd:	pop    %rbp
 101aabe:	ret
 101aabf:	xor    %r12d,%r12d
 101aac2:	jmp    101aa60 <clone_payload+0x1b0>
 101aac4:	int3
 101aac5:	int3
 101aac6:	int3
 101aac7:	int3
 101aac8:	int3
 101aac9:	int3
 101aaca:	int3
 101aacb:	int3
 101aacc:	int3
 101aacd:	int3
 101aace:	int3
 101aacf:	int3

000000000101aad0 <myl_rc_unique_borrow>:
 101aad0:	push   %rbp
 101aad1:	mov    %rsp,%rbp
 101aad4:	push   %r15
 101aad6:	push   %r14
 101aad8:	push   %r12
 101aada:	push   %rbx
 101aadb:	sub    $0x10,%rsp
 101aadf:	test   %rcx,%rcx
 101aae2:	je     101ab8d <myl_rc_unique_borrow+0xbd>
 101aae8:	mov    %rcx,%rbx
 101aaeb:	cmpq   $0x0,(%rcx)
 101aaef:	jne    101ab8d <myl_rc_unique_borrow+0xbd>
 101aaf5:	cmpl   $0x0,0x8(%rbx)
 101aaf9:	jne    101ab8d <myl_rc_unique_borrow+0xbd>
 101aaff:	mov    %rsi,%r15
 101ab02:	mov    %rdi,%r14
 101ab05:	test   %rdx,%rdx
 101ab08:	je     101ab15 <myl_rc_unique_borrow+0x45>
 101ab0a:	cmpl   $0x0,0x18(%rdx)
 101ab0e:	je     101ab8d <myl_rc_unique_borrow+0xbd>
 101ab10:	cmp    %r14,(%rdx)
 101ab13:	jne    101ab8d <myl_rc_unique_borrow+0xbd>
 101ab15:	test   %r15,%r15
 101ab18:	je     101ab8d <myl_rc_unique_borrow+0xbd>
 101ab1a:	mov    0x8(%r15),%rax
 101ab1e:	test   %rax,%rax
 101ab21:	je     101ab8d <myl_rc_unique_borrow+0xbd>
 101ab23:	mov    (%r15),%rcx
 101ab26:	test   %rcx,%rcx
 101ab29:	je     101ab8d <myl_rc_unique_borrow+0xbd>
 101ab2b:	cmpl   $0x1,0x8(%rcx)
 101ab2f:	jne    101ab8d <myl_rc_unique_borrow+0xbd>
 101ab31:	cmpq   $0x8,(%rcx)
 101ab35:	jne    101ab8d <myl_rc_unique_borrow+0xbd>
 101ab37:	mov    (%rax),%r12
 101ab3a:	mov    %r14,%rdi
 101ab3d:	mov    %r12,%rsi
 101ab40:	call   1012d10 <myl_rc_unique>
 101ab45:	test   %eax,%eax
 101ab47:	je     101ab50 <myl_rc_unique_borrow+0x80>
 101ab49:	mov    %r12,(%rbx)
 101ab4c:	xor    %eax,%eax
 101ab4e:	jmp    101ab80 <myl_rc_unique_borrow+0xb0>
 101ab50:	movq   $0x0,-0x28(%rbp)
 101ab58:	mov    0x18(%r15),%edx
 101ab5c:	lea    -0x28(%rbp),%rcx
 101ab60:	mov    %r14,%rdi
 101ab63:	mov    %r12,%rsi
 101ab66:	xor    %r8d,%r8d
 101ab69:	call   101a8b0 <clone_payload>
 101ab6e:	test   %eax,%eax
 101ab70:	jne    101ab80 <myl_rc_unique_borrow+0xb0>
 101ab72:	mov    -0x28(%rbp),%rcx
 101ab76:	mov    %rcx,(%rbx)
 101ab79:	movl   $0x1,0x8(%rbx)
 101ab80:	add    $0x10,%rsp
 101ab84:	pop    %rbx
 101ab85:	pop    %r12
 101ab87:	pop    %r14
 101ab89:	pop    %r15
 101ab8b:	pop    %rbp
 101ab8c:	ret
 101ab8d:	call   101267d <myl_rc_invariant_failed>
 101ab92:	int3
 101ab93:	int3
 101ab94:	int3
 101ab95:	int3
 101ab96:	int3
 101ab97:	int3
 101ab98:	int3
 101ab99:	int3
 101ab9a:	int3
 101ab9b:	int3
 101ab9c:	int3
 101ab9d:	int3
 101ab9e:	int3
 101ab9f:	int3

000000000101aba0 <transfer_pointer>:
 101aba0:	mov    (%rdx),%rdx
 101aba3:	cmp    $0x5,%ecx
 101aba6:	je     101bcf0 <transfer_hold>
 101abac:	push   %rbp
 101abad:	mov    %rsp,%rbp
 101abb0:	push   %r15
 101abb2:	push   %r14
 101abb4:	push   %r12
 101abb6:	push   %rbx
 101abb7:	sub    $0x10,%rsp
 101abbb:	test   %rdx,%rdx
 101abbe:	je     101ac6a <transfer_pointer+0xca>
 101abc4:	mov    -0x10(%rdx),%rcx
 101abc8:	test   $0x2,%cl
 101abcb:	jne    101ac6a <transfer_pointer+0xca>
 101abd1:	bt     $0x3e,%rcx
 101abd6:	mov    %rsi,%r14
 101abd9:	jb     101abe9 <transfer_pointer+0x49>
 101abdb:	xor    %ebx,%ebx
 101abdd:	bt     $0x3c,%rcx
 101abe2:	jae    101ac1a <transfer_pointer+0x7a>
 101abe4:	mov    0x20(%rdi),%eax
 101abe7:	jmp    101ac43 <transfer_pointer+0xa3>
 101abe9:	mov    %rcx,%rbx
 101abec:	shr    $0x28,%rbx
 101abf0:	and    $0xfffff,%ebx
 101abf6:	mov    0x20(%rdi),%eax
 101abf9:	cmp    %eax,%ebx
 101abfb:	jbe    101ac13 <transfer_pointer+0x73>
 101abfd:	mov    0x28(%rdi),%rcx
 101ac01:	cmpl   $0x0,0xa8(%rcx)
 101ac08:	mov    %eax,%ebx
 101ac0a:	jne    101ac43 <transfer_pointer+0xa3>
 101ac0c:	mov    $0x3,%eax
 101ac11:	jmp    101ac6f <transfer_pointer+0xcf>
 101ac13:	bt     $0x3c,%rcx
 101ac18:	jb     101ac43 <transfer_pointer+0xa3>
 101ac1a:	mov    %rdi,%r12
 101ac1d:	mov    %rdx,%r15
 101ac20:	mov    %rdx,%rsi
 101ac23:	call   101bb90 <queue_mark>
 101ac28:	mov    %eax,%ecx
 101ac2a:	mov    $0x1,%eax
 101ac2f:	test   %ecx,%ecx
 101ac31:	jne    101ac6f <transfer_pointer+0xcf>
 101ac33:	cmpl   $0x0,0x24(%r12)
 101ac39:	je     101ac7c <transfer_pointer+0xdc>
 101ac3b:	mov    %r14,%rsi
 101ac3e:	mov    %r15,%rdx
 101ac41:	jmp    101ac6a <transfer_pointer+0xca>
 101ac43:	mov    0x28(%rdi),%rcx
 101ac47:	cmpl   $0x0,0xac(%rcx)
 101ac4e:	cmove  %eax,%ebx
 101ac51:	lea    -0x28(%rbp),%rcx
 101ac55:	mov    %rdx,%rsi
 101ac58:	mov    %ebx,%edx
 101ac5a:	call   101b340 <schedule_clone>
 101ac5f:	test   %eax,%eax
 101ac61:	jne    101ac6f <transfer_pointer+0xcf>
 101ac63:	mov    -0x28(%rbp),%rdx
 101ac67:	mov    %r14,%rsi
 101ac6a:	mov    %rdx,(%rsi)
 101ac6d:	xor    %eax,%eax
 101ac6f:	add    $0x10,%rsp
 101ac73:	pop    %rbx
 101ac74:	pop    %r12
 101ac76:	pop    %r14
 101ac78:	pop    %r15
 101ac7a:	pop    %rbp
 101ac7b:	ret
 101ac7c:	test   %ebx,%ebx
 101ac7e:	mov    %r15,%rdx
 101ac81:	je     101ac9a <transfer_pointer+0xfa>
 101ac83:	mov    %r14,%rsi
 101ac86:	mov    0x28(%r12),%rax
 101ac8b:	cmpl   $0x0,0xac(%rax)
 101ac92:	jne    101ac6a <transfer_pointer+0xca>
 101ac94:	orb    $0x20,-0x9(%rdx)
 101ac98:	jmp    101ac6a <transfer_pointer+0xca>
 101ac9a:	mov    %rdx,%rdi
 101ac9d:	call   1012630 <myl_rc_owner_take>
 101aca2:	test   %eax,%eax
 101aca4:	jne    101ac6f <transfer_pointer+0xcf>
 101aca6:	jmp    101ac3b <transfer_pointer+0x9b>
 101aca8:	int3
 101aca9:	int3
 101acaa:	int3
 101acab:	int3
 101acac:	int3
 101acad:	int3
 101acae:	int3
 101acaf:	int3

000000000101acb0 <finish_clones>:
 101acb0:	push   %rbp
 101acb1:	mov    %rsp,%rbp
 101acb4:	push   %r15
 101acb6:	push   %r14
 101acb8:	push   %r13
 101acba:	push   %r12
 101acbc:	push   %rbx
 101acbd:	sub    $0xa8,%rsp
 101acc4:	mov    0x28(%rdi),%r14
 101acc8:	movl   $0x0,0x24(%rdi)
 101accf:	mov    0x8(%r14),%rax
 101acd3:	test   %rax,%rax
 101acd6:	je     101b26a <finish_clones+0x5ba>
 101acdc:	mov    %rdi,%r12
 101acdf:	mov    %rdi,-0x40(%rbp)
 101ace3:	mov    %r14,-0x68(%rbp)
 101ace7:	jmp    101ad09 <finish_clones+0x59>
 101ace9:	nopl   0x0(%rax)
 101acf0:	decq   0x8(%r14)
 101acf4:	mov    -0x40(%rbp),%r12
 101acf8:	mov    -0x68(%rbp),%r14
 101acfc:	mov    0x8(%r14),%rax
 101ad00:	test   %rax,%rax
 101ad03:	je     101b26a <finish_clones+0x5ba>
 101ad09:	mov    (%r14),%rdx
 101ad0c:	lea    (%rax,%rax,4),%rsi
 101ad10:	lea    (%rdx,%rsi,8),%rcx
 101ad14:	mov    -0x18(%rdx,%rsi,8),%rsi
 101ad19:	mov    0x38(%rsi),%r10
 101ad1d:	test   %r10,%r10
 101ad20:	je     101b060 <finish_clones+0x3b0>
 101ad26:	movq   $0x0,-0x78(%rbp)
 101ad2e:	mov    (%r12),%rdi
 101ad32:	mov    -0x28(%rcx),%rsi
 101ad36:	mov    -0x20(%rcx),%rdx
 101ad3a:	add    $0xfffffffffffffff0,%rcx
 101ad3e:	lea    -0x78(%rbp),%rax
 101ad42:	mov    %rax,(%rsp)
 101ad46:	lea    -0x60(%rbp),%r8
 101ad4a:	lea    -0x98(%rbp),%r9
 101ad51:	call   *%r10
 101ad54:	test   %eax,%eax
 101ad56:	je     101acf0 <finish_clones+0x40>
 101ad58:	mov    -0x78(%rbp),%rax
 101ad5c:	mov    %rax,-0x70(%rbp)
 101ad60:	mov    (%r12),%rdi
 101ad64:	mov    -0x98(%rbp),%rcx
 101ad6b:	mov    0x1608(%rdi),%rsi
 101ad72:	mov    0x58(%rsi),%rax
 101ad76:	mov    0x60(%rsi),%rdx
 101ad7a:	movzbl 0x70(%rsi),%esi
 101ad7e:	mov    %rcx,%r8
 101ad81:	movabs $0x9e3779b97f4a7c15,%r9
 101ad8b:	imul   %r9,%r8
 101ad8f:	shrx   %rsi,%r8,%rsi
 101ad94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 101ada0:	and    %rdx,%rsi
 101ada3:	mov    %rsi,%r8
 101ada6:	shl    $0x4,%r8
 101adaa:	mov    (%rax,%r8,1),%r8
 101adae:	cmp    %rcx,%r8
 101adb1:	je     101add0 <finish_clones+0x120>
 101adb3:	test   %r8,%r8
 101adb6:	je     101b285 <finish_clones+0x5d5>
 101adbc:	inc    %rsi
 101adbf:	jmp    101ada0 <finish_clones+0xf0>
 101adc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101add0:	shl    $0x4,%rsi
 101add4:	mov    0x8(%rax,%rsi,1),%rsi
 101add9:	test   %rsi,%rsi
 101addc:	je     101b285 <finish_clones+0x5d5>
 101ade2:	mov    -0x60(%rbp),%rax
 101ade6:	test   %rax,%rax
 101ade9:	je     101b285 <finish_clones+0x5d5>
 101adef:	mov    (%rax),%rax
 101adf2:	cmp    (%rsi),%rax
 101adf5:	jne    101b285 <finish_clones+0x5d5>
 101adfb:	mov    0x28(%rsi),%r14
 101adff:	cmp    $0x2,%r14
 101ae03:	jb     101ae6e <finish_clones+0x1be>
 101ae05:	cmp    0x10(%r12),%r14
 101ae0a:	jbe    101ae6e <finish_clones+0x1be>
 101ae0c:	cmpq   $0x0,0x18(%r12)
 101ae12:	jne    101b285 <finish_clones+0x5d5>
 101ae18:	mov    %r14,%rax
 101ae1b:	shr    $0x3b,%rax
 101ae1f:	jne    101b285 <finish_clones+0x5d5>
 101ae25:	mov    %rsi,%rbx
 101ae28:	mov    %r14,%rsi
 101ae2b:	shl    $0x5,%rsi
 101ae2f:	call   1012690 <myl_rc_meta_alloc>
 101ae34:	test   %rax,%rax
 101ae37:	je     101b27e <finish_clones+0x5ce>
 101ae3d:	mov    %rax,%r15
 101ae40:	mov    0x10(%r12),%rdx
 101ae45:	cmp    $0x9,%rdx
 101ae49:	jb     101ae5d <finish_clones+0x1ad>
 101ae4b:	mov    (%r12),%rdi
 101ae4f:	mov    0x8(%r12),%rsi
 101ae54:	shl    $0x5,%rdx
 101ae58:	call   1012710 <myl_rc_meta_free>
 101ae5d:	mov    %r15,0x8(%r12)
 101ae62:	mov    %r14,0x10(%r12)
 101ae67:	mov    %rbx,%rsi
 101ae6a:	mov    0x28(%rbx),%r14
 101ae6e:	mov    -0x48(%rbp),%eax
 101ae71:	mov    %eax,0x20(%r12)
 101ae76:	cmpq   $0x0,-0x70(%rbp)
 101ae7b:	je     101acf4 <finish_clones+0x44>
 101ae81:	mov    -0x90(%rbp),%r15
 101ae88:	mov    -0x58(%rbp),%r12
 101ae8c:	xor    %edx,%edx
 101ae8e:	mov    %rsi,-0xa8(%rbp)
 101ae95:	mov    %r14,-0xa0(%rbp)
 101ae9c:	jmp    101aee9 <finish_clones+0x239>
 101ae9e:	xchg   %ax,%ax
 101aea0:	mov    -0x40(%rbp),%rdi
 101aea4:	mov    %r12,%rdx
 101aea7:	mov    %r15,%rcx
 101aeaa:	lea    -0x311(%rip),%r8        # 101aba0 <transfer_pointer>
 101aeb1:	call   101a070 <visit>
 101aeb6:	test   %eax,%eax
 101aeb8:	jne    101b26c <finish_clones+0x5bc>
 101aebe:	mov    -0xc8(%rbp),%rdx
 101aec5:	inc    %rdx
 101aec8:	mov    -0xa8(%rbp),%rsi
 101aecf:	mov    (%rsi),%rax
 101aed2:	add    %rax,%r12
 101aed5:	add    %rax,%r15
 101aed8:	cmp    -0x70(%rbp),%rdx
 101aedc:	mov    -0xa0(%rbp),%r14
 101aee3:	je     101acf4 <finish_clones+0x44>
 101aee9:	cmp    $0x2,%r14
 101aeed:	mov    %rdx,-0xc8(%rbp)
 101aef4:	ja     101aea0 <finish_clones+0x1f0>
 101aef6:	mov    0x8(%rsi),%eax
 101aef9:	mov    %rax,-0x38(%rbp)
 101aefd:	dec    %eax
 101aeff:	cmp    $0x4,%eax
 101af02:	ja     101af71 <finish_clones+0x2c1>
 101af04:	lea    -0x17dbb(%rip),%rcx        # 1003150 <myl_rc_map_sentinel+0xb0>
 101af0b:	movslq (%rcx,%rax,4),%rax
 101af0f:	add    %rcx,%rax
 101af12:	jmp    *%rax
 101af14:	mov    $0x1,%ecx
 101af19:	jmp    101af73 <finish_clones+0x2c3>
 101af1b:	mov    0x10(%rsi),%rdx
 101af1f:	mov    0x18(%rsi),%rcx
 101af23:	mov    0x20(%rsi),%r14
 101af27:	add    %r15,%r14
 101af2a:	mov    $0x4,%eax
 101af2f:	mov    %rax,-0x38(%rbp)
 101af33:	movq   $0x0,-0x30(%rbp)
 101af3b:	jmp    101af80 <finish_clones+0x2d0>
 101af3d:	mov    0x10(%rsi),%rdx
 101af41:	mov    0x18(%rsi),%rcx
 101af45:	mov    $0x2,%eax
 101af4a:	mov    %rax,-0x38(%rbp)
 101af4e:	movq   $0x0,-0x30(%rbp)
 101af56:	jmp    101af7d <finish_clones+0x2cd>
 101af58:	mov    0x10(%rsi),%rax
 101af5c:	mov    0x18(%rsi),%rcx
 101af60:	mov    0x20(%rsi),%rdx
 101af64:	mov    %rdx,-0x30(%rbp)
 101af68:	mov    0x8(%rax),%eax
 101af6b:	mov    %rax,-0x38(%rbp)
 101af6f:	jmp    101af7b <finish_clones+0x2cb>
 101af71:	xor    %ecx,%ecx
 101af73:	movq   $0x0,-0x30(%rbp)
 101af7b:	xor    %edx,%edx
 101af7d:	xor    %r14d,%r14d
 101af80:	lea    0x10(%rdx),%rax
 101af84:	mov    %rax,-0xb0(%rbp)
 101af8b:	mov    %rcx,%r13
 101af8e:	neg    %r13
 101af91:	xor    %ebx,%ebx
 101af93:	mov    %rcx,-0xc0(%rbp)
 101af9a:	mov    %rdx,-0xb8(%rbp)
 101afa1:	test   %rdx,%rdx
 101afa4:	je     101b010 <finish_clones+0x360>
 101afa6:	cmp    %rcx,%rbx
 101afa9:	jae    101aebe <finish_clones+0x20e>
 101afaf:	lea    (%rbx,%rbx,2),%rax
 101afb3:	mov    -0xb0(%rbp),%rcx
 101afba:	lea    (%rcx,%rax,8),%rax
 101afbe:	inc    %rbx
 101afc1:	jmp    101afe8 <finish_clones+0x338>
 101afc3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101afd0:	add    $0x18,%rax
 101afd4:	lea    (%rbx,%r13,1),%rcx
 101afd8:	inc    %rcx
 101afdb:	inc    %rbx
 101afde:	cmp    $0x1,%rcx
 101afe2:	je     101aebe <finish_clones+0x20e>
 101afe8:	mov    -0x8(%rax),%rcx
 101afec:	mov    0x8(%rcx),%ecx
 101afef:	test   %ecx,%ecx
 101aff1:	je     101afd0 <finish_clones+0x320>
 101aff3:	test   %r14,%r14
 101aff6:	je     101afff <finish_clones+0x34f>
 101aff8:	mov    (%rax),%edx
 101affa:	cmp    (%r14),%edx
 101affd:	jne    101afd0 <finish_clones+0x320>
 101afff:	mov    -0x10(%rax),%rdx
 101b003:	jmp    101b02a <finish_clones+0x37a>
 101b005:	data16 cs nopw 0x0(%rax,%rax,1)
 101b010:	cmp    %rcx,%rbx
 101b013:	je     101aebe <finish_clones+0x20e>
 101b019:	mov    %rbx,%rdx
 101b01c:	inc    %rbx
 101b01f:	imul   -0x30(%rbp),%rdx
 101b024:	mov    -0x38(%rbp),%rax
 101b028:	mov    %eax,%ecx
 101b02a:	lea    (%r12,%rdx,1),%rsi
 101b02e:	add    %r15,%rdx
 101b031:	mov    -0x40(%rbp),%rdi
 101b035:	call   101aba0 <transfer_pointer>
 101b03a:	test   %eax,%eax
 101b03c:	mov    -0xc0(%rbp),%rcx
 101b043:	mov    -0xb8(%rbp),%rdx
 101b04a:	je     101afa1 <finish_clones+0x2f1>
 101b050:	jmp    101b26c <finish_clones+0x5bc>
 101b055:	data16 cs nopw 0x0(%rax,%rax,1)
 101b060:	mov    0x30(%rsi),%r10
 101b064:	test   %r10,%r10
 101b067:	je     101b09b <finish_clones+0x3eb>
 101b069:	mov    (%r12),%rdi
 101b06d:	mov    -0x28(%rcx),%rsi
 101b071:	mov    -0x20(%rcx),%rdx
 101b075:	add    $0xfffffffffffffff0,%rcx
 101b079:	lea    -0x60(%rbp),%r8
 101b07d:	lea    -0x98(%rbp),%r9
 101b084:	call   *%r10
 101b087:	test   %eax,%eax
 101b089:	je     101b25a <finish_clones+0x5aa>
 101b08f:	mov    -0x98(%rbp),%rax
 101b096:	jmp    101b12e <finish_clones+0x47e>
 101b09b:	mov    -0x28(%rcx),%rdi
 101b09f:	mov    -0x10(%rcx),%rdx
 101b0a3:	mov    -0x10(%rdi),%rdi
 101b0a7:	mov    %rdi,%r8
 101b0aa:	shr    $0x2,%r8
 101b0ae:	bt     $0x3e,%rdi
 101b0b3:	movabs $0x3fffffffff,%rdi
 101b0bd:	movabs $0x3ffffffffffffff,%r9
 101b0c7:	cmovae %r9,%rdi
 101b0cb:	and    %r8,%rdi
 101b0ce:	cmp    %rdi,%rdx
 101b0d1:	je     101b25e <finish_clones+0x5ae>
 101b0d7:	mov    0x8(%rsi),%rax
 101b0db:	lea    0x1(%rdx),%rsi
 101b0df:	mov    %rsi,-0x10(%rcx)
 101b0e3:	imul   (%rax),%rdx
 101b0e7:	mov    -0x20(%rcx),%rsi
 101b0eb:	lea    (%rsi,%rdx,1),%rdi
 101b0ef:	mov    -0x8(%rcx),%r8d
 101b0f3:	mov    %rax,-0x60(%rbp)
 101b0f7:	mov    %rdi,-0x58(%rbp)
 101b0fb:	mov    %rsi,-0x50(%rbp)
 101b0ff:	mov    %r8d,-0x48(%rbp)
 101b103:	movl   $0x0,-0x44(%rbp)
 101b10a:	mov    -0x28(%rcx),%rcx
 101b10e:	add    %rcx,%rdx
 101b111:	mov    %rax,-0x98(%rbp)
 101b118:	mov    %rdx,-0x90(%rbp)
 101b11f:	mov    %rcx,-0x88(%rbp)
 101b126:	movq   $0x0,-0x80(%rbp)
 101b12e:	mov    (%r12),%rdi
 101b132:	mov    0x1608(%rdi),%rsi
 101b139:	mov    0x58(%rsi),%rcx
 101b13d:	mov    0x60(%rsi),%rdx
 101b141:	movzbl 0x70(%rsi),%esi
 101b145:	mov    %rax,%r8
 101b148:	movabs $0x9e3779b97f4a7c15,%r9
 101b152:	imul   %r9,%r8
 101b156:	shrx   %rsi,%r8,%rsi
 101b15b:	nopl   0x0(%rax,%rax,1)
 101b160:	and    %rdx,%rsi
 101b163:	mov    %rsi,%r8
 101b166:	shl    $0x4,%r8
 101b16a:	mov    (%rcx,%r8,1),%r8
 101b16e:	cmp    %rax,%r8
 101b171:	je     101b190 <finish_clones+0x4e0>
 101b173:	test   %r8,%r8
 101b176:	je     101b285 <finish_clones+0x5d5>
 101b17c:	inc    %rsi
 101b17f:	jmp    101b160 <finish_clones+0x4b0>
 101b181:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b190:	shl    $0x4,%rsi
 101b194:	mov    0x8(%rcx,%rsi,1),%rsi
 101b199:	test   %rsi,%rsi
 101b19c:	je     101b285 <finish_clones+0x5d5>
 101b1a2:	mov    -0x60(%rbp),%rax
 101b1a6:	test   %rax,%rax
 101b1a9:	je     101b285 <finish_clones+0x5d5>
 101b1af:	mov    (%rax),%rax
 101b1b2:	cmp    (%rsi),%rax
 101b1b5:	jne    101b285 <finish_clones+0x5d5>
 101b1bb:	mov    0x28(%rsi),%rbx
 101b1bf:	cmp    $0x2,%rbx
 101b1c3:	jb     101b22e <finish_clones+0x57e>
 101b1c5:	cmp    0x10(%r12),%rbx
 101b1ca:	jbe    101b22e <finish_clones+0x57e>
 101b1cc:	cmpq   $0x0,0x18(%r12)
 101b1d2:	jne    101b285 <finish_clones+0x5d5>
 101b1d8:	mov    %rbx,%rax
 101b1db:	shr    $0x3b,%rax
 101b1df:	jne    101b285 <finish_clones+0x5d5>
 101b1e5:	mov    %rsi,%r14
 101b1e8:	mov    %rbx,%rsi
 101b1eb:	shl    $0x5,%rsi
 101b1ef:	call   1012690 <myl_rc_meta_alloc>
 101b1f4:	test   %rax,%rax
 101b1f7:	je     101b27e <finish_clones+0x5ce>
 101b1fd:	mov    %rax,%r15
 101b200:	mov    0x10(%r12),%rdx
 101b205:	cmp    $0x9,%rdx
 101b209:	jb     101b21d <finish_clones+0x56d>
 101b20b:	mov    (%r12),%rdi
 101b20f:	mov    0x8(%r12),%rsi
 101b214:	shl    $0x5,%rdx
 101b218:	call   1012710 <myl_rc_meta_free>
 101b21d:	mov    %r15,0x8(%r12)
 101b222:	mov    %rbx,0x10(%r12)
 101b227:	mov    %r14,%rsi
 101b22a:	mov    -0x68(%rbp),%r14
 101b22e:	mov    -0x48(%rbp),%eax
 101b231:	mov    %eax,0x20(%r12)
 101b236:	mov    -0x58(%rbp),%rdx
 101b23a:	mov    -0x90(%rbp),%rcx
 101b241:	mov    %r12,%rdi
 101b244:	lea    -0x6ab(%rip),%r8        # 101aba0 <transfer_pointer>
 101b24b:	call   101a070 <visit>
 101b250:	test   %eax,%eax
 101b252:	je     101acfc <finish_clones+0x4c>
 101b258:	jmp    101b26c <finish_clones+0x5bc>
 101b25a:	mov    0x8(%r14),%rax
 101b25e:	dec    %rax
 101b261:	mov    %rax,0x8(%r14)
 101b265:	jmp    101acfc <finish_clones+0x4c>
 101b26a:	xor    %eax,%eax
 101b26c:	add    $0xa8,%rsp
 101b273:	pop    %rbx
 101b274:	pop    %r12
 101b276:	pop    %r13
 101b278:	pop    %r14
 101b27a:	pop    %r15
 101b27c:	pop    %rbp
 101b27d:	ret
 101b27e:	mov    $0x1,%eax
 101b283:	jmp    101b26c <finish_clones+0x5bc>
 101b285:	call   101267d <myl_rc_invariant_failed>
 101b28a:	int3
 101b28b:	int3
 101b28c:	int3
 101b28d:	int3
 101b28e:	int3
 101b28f:	int3

000000000101b290 <rollback_take>:
 101b290:	mov    (%rsi),%rsi
 101b293:	cmp    %rsi,(%rdx)
 101b296:	je     101b2c1 <rollback_take+0x31>
 101b298:	push   %rbp
 101b299:	mov    %rsp,%rbp
 101b29c:	sub    $0x10,%rsp
 101b2a0:	mov    (%rdi),%rdi
 101b2a3:	cmp    $0x5,%ecx
 101b2a6:	jne    101b2b7 <rollback_take+0x27>
 101b2a8:	mov    %rsi,-0x8(%rbp)
 101b2ac:	lea    -0x8(%rbp),%rsi
 101b2b0:	call   1012f20 <myl_rc_hold_release>
 101b2b5:	jmp    101b2bc <rollback_take+0x2c>
 101b2b7:	call   1012bb0 <myl_rc_edge_release>
 101b2bc:	add    $0x10,%rsp
 101b2c0:	pop    %rbp
 101b2c1:	xor    %eax,%eax
 101b2c3:	ret
 101b2c4:	int3
 101b2c5:	int3
 101b2c6:	int3
 101b2c7:	int3
 101b2c8:	int3
 101b2c9:	int3
 101b2ca:	int3
 101b2cb:	int3
 101b2cc:	int3
 101b2cd:	int3
 101b2ce:	int3
 101b2cf:	int3

000000000101b2d0 <commit_take>:
 101b2d0:	mov    %rsi,%rax
 101b2d3:	mov    (%rdx),%rsi
 101b2d6:	cmp    (%rax),%rsi
 101b2d9:	je     101b304 <commit_take+0x34>
 101b2db:	push   %rbp
 101b2dc:	mov    %rsp,%rbp
 101b2df:	sub    $0x10,%rsp
 101b2e3:	mov    (%rdi),%rdi
 101b2e6:	cmp    $0x5,%ecx
 101b2e9:	jne    101b2fa <commit_take+0x2a>
 101b2eb:	mov    %rsi,-0x8(%rbp)
 101b2ef:	lea    -0x8(%rbp),%rsi
 101b2f3:	call   1012f20 <myl_rc_hold_release>
 101b2f8:	jmp    101b2ff <commit_take+0x2f>
 101b2fa:	call   1012bb0 <myl_rc_edge_release>
 101b2ff:	add    $0x10,%rsp
 101b303:	pop    %rbp
 101b304:	xor    %eax,%eax
 101b306:	ret
 101b307:	int3
 101b308:	int3
 101b309:	int3
 101b30a:	int3
 101b30b:	int3
 101b30c:	int3
 101b30d:	int3
 101b30e:	int3
 101b30f:	int3

000000000101b310 <inspect_child>:
 101b310:	push   %rbp
 101b311:	mov    %rsp,%rbp
 101b314:	cmp    $0x5,%ecx
 101b317:	je     101b338 <inspect_child+0x28>
 101b319:	mov    (%rdx),%rsi
 101b31c:	test   %rsi,%rsi
 101b31f:	je     101b338 <inspect_child+0x28>
 101b321:	testb  $0x10,-0x9(%rsi)
 101b325:	jne    101b32d <inspect_child+0x1d>
 101b327:	pop    %rbp
 101b328:	jmp    101bb90 <queue_mark>
 101b32d:	mov    0x28(%rdi),%rax
 101b331:	orl    $0x4,0xac(%rax)
 101b338:	xor    %eax,%eax
 101b33a:	pop    %rbp
 101b33b:	ret
 101b33c:	int3
 101b33d:	int3
 101b33e:	int3
 101b33f:	int3

000000000101b340 <schedule_clone>:
 101b340:	push   %rbp
 101b341:	mov    %rsp,%rbp
 101b344:	push   %r15
 101b346:	push   %r14
 101b348:	push   %r13
 101b34a:	push   %r12
 101b34c:	push   %rbx
 101b34d:	sub    $0x68,%rsp
 101b351:	mov    %rcx,%rbx
 101b354:	mov    %edx,%r8d
 101b357:	mov    %rsi,%r15
 101b35a:	mov    %rdi,%r13
 101b35d:	movq   $0x0,(%rcx)
 101b364:	mov    0x28(%rdi),%r14
 101b368:	cmpl   $0x0,0xac(%r14)
 101b370:	mov    %r14,-0x58(%rbp)
 101b374:	je     101b390 <schedule_clone+0x50>
 101b376:	mov    %r15,%rdi
 101b379:	mov    %r8d,%r12d
 101b37c:	call   101e090 <myl_rc_native_mutable>
 101b381:	mov    %r12d,%r8d
 101b384:	test   %eax,%eax
 101b386:	je     101b390 <schedule_clone+0x50>
 101b388:	xor    %r9d,%r9d
 101b38b:	jmp    101b6b5 <schedule_clone+0x375>
 101b390:	mov    0xa0(%r14),%rcx
 101b397:	test   %rcx,%rcx
 101b39a:	je     101b45d <schedule_clone+0x11d>
 101b3a0:	mov    0x30(%r14),%rax
 101b3a4:	mov    %r15,%rdx
 101b3a7:	shr    $0x4,%rdx
 101b3ab:	mov    %r8d,%esi
 101b3ae:	movabs $0x9e3779b97f4a7c15,%rdi
 101b3b8:	imul   %rsi,%rdi
 101b3bc:	xor    %rdx,%rdi
 101b3bf:	mov    %rdi,%rdx
 101b3c2:	shr    $0x1e,%rdx
 101b3c6:	xor    %rdi,%rdx
 101b3c9:	movabs $0xbf58476d1ce4e5b9,%rsi
 101b3d3:	imul   %rdx,%rsi
 101b3d7:	mov    %rsi,%rdx
 101b3da:	shr    $0x1b,%rdx
 101b3de:	xor    %rsi,%rdx
 101b3e1:	movabs $0x94d049bb133111eb,%rsi
 101b3eb:	imul   %rdx,%rsi
 101b3ef:	mov    %rsi,%rdx
 101b3f2:	shr    $0x1f,%rdx
 101b3f6:	xor    %rsi,%rdx
 101b3f9:	dec    %rcx
 101b3fc:	jmp    101b403 <schedule_clone+0xc3>
 101b3fe:	xchg   %ax,%ax
 101b400:	inc    %rdx
 101b403:	and    %rcx,%rdx
 101b406:	lea    (%rdx,%rdx,2),%rsi
 101b40a:	mov    (%rax,%rsi,8),%rsi
 101b40e:	test   %rsi,%rsi
 101b411:	je     101b423 <schedule_clone+0xe3>
 101b413:	cmp    %r15,%rsi
 101b416:	jne    101b400 <schedule_clone+0xc0>
 101b418:	lea    (%rdx,%rdx,2),%rsi
 101b41c:	cmp    %r8d,0x10(%rax,%rsi,8)
 101b421:	jne    101b400 <schedule_clone+0xc0>
 101b423:	lea    (%rdx,%rdx,2),%rcx
 101b427:	lea    (%rax,%rcx,8),%rax
 101b42b:	mov    0x8(%rax),%rax
 101b42f:	test   %rax,%rax
 101b432:	je     101b486 <schedule_clone+0x146>
 101b434:	mov    -0x10(%rax),%rcx
 101b438:	movabs $0x4000000000000000,%rdx
 101b442:	or     $0x2,%rdx
 101b446:	test   %rdx,%rcx
 101b449:	je     101b527 <schedule_clone+0x1e7>
 101b44f:	test   %r8d,%r8d
 101b452:	jne    101b55a <schedule_clone+0x21a>
 101b458:	jmp    101bb5d <schedule_clone+0x81d>
 101b45d:	mov    0x98(%r14),%rcx
 101b464:	test   %rcx,%rcx
 101b467:	je     101b486 <schedule_clone+0x146>
 101b469:	lea    0x38(%r14),%rax
 101b46d:	jmp    101b479 <schedule_clone+0x139>
 101b46f:	nop
 101b470:	add    $0x18,%rax
 101b474:	dec    %rcx
 101b477:	je     101b486 <schedule_clone+0x146>
 101b479:	cmp    %r15,(%rax)
 101b47c:	jne    101b470 <schedule_clone+0x130>
 101b47e:	cmp    %r8d,0x10(%rax)
 101b482:	jne    101b470 <schedule_clone+0x130>
 101b484:	jmp    101b42b <schedule_clone+0xeb>
 101b486:	mov    0x28(%r13),%r14
 101b48a:	mov    0x98(%r14),%rcx
 101b491:	mov    0xa0(%r14),%rax
 101b498:	test   %rax,%rax
 101b49b:	je     101b4b0 <schedule_clone+0x170>
 101b49d:	mov    %rax,%rdx
 101b4a0:	shr    $1,%rdx
 101b4a3:	mov    $0x1,%r9b
 101b4a6:	cmp    %rdx,%rcx
 101b4a9:	jae    101b4bd <schedule_clone+0x17d>
 101b4ab:	jmp    101b6b5 <schedule_clone+0x375>
 101b4b0:	mov    $0x1,%r9b
 101b4b3:	cmp    $0x4,%rcx
 101b4b7:	jb     101b6b5 <schedule_clone+0x375>
 101b4bd:	mov    %r13,-0x40(%rbp)
 101b4c1:	lea    (%rax,%rax,1),%rcx
 101b4c5:	test   %rax,%rax
 101b4c8:	mov    $0x20,%r13d
 101b4ce:	cmovne %rcx,%r13
 101b4d2:	mov    $0x1,%r12d
 101b4d8:	cmp    %rax,%r13
 101b4db:	jb     101bb63 <schedule_clone+0x823>
 101b4e1:	mov    $0x18,%ecx
 101b4e6:	mov    %r13,%rax
 101b4e9:	mul    %rcx
 101b4ec:	jo     101bb63 <schedule_clone+0x823>
 101b4f2:	mov    %r8d,-0x2c(%rbp)
 101b4f6:	mov    %rbx,-0x48(%rbp)
 101b4fa:	mov    -0x40(%rbp),%rcx
 101b4fe:	mov    (%rcx),%rdi
 101b501:	mov    %rax,%rsi
 101b504:	call   1012690 <myl_rc_meta_alloc>
 101b509:	test   %rax,%rax
 101b50c:	je     101bb63 <schedule_clone+0x823>
 101b512:	mov    %rax,%rbx
 101b515:	mov    0xa0(%r14),%rax
 101b51c:	test   %rax,%rax
 101b51f:	je     101b58c <schedule_clone+0x24c>
 101b521:	mov    0x30(%r14),%rcx
 101b525:	jmp    101b5a0 <schedule_clone+0x260>
 101b527:	test   $0x1,%cl
 101b52a:	jne    101bb89 <schedule_clone+0x849>
 101b530:	mov    -0x20(%rax),%rdx
 101b534:	cmp    $0xffffffffffffffff,%rdx
 101b538:	je     101b581 <schedule_clone+0x241>
 101b53a:	test   %rdx,%rdx
 101b53d:	jne    101b54a <schedule_clone+0x20a>
 101b53f:	cmpq   $0x0,-0x18(%rax)
 101b544:	je     101bb89 <schedule_clone+0x849>
 101b54a:	inc    %rdx
 101b54d:	mov    %rdx,-0x20(%rax)
 101b551:	test   %r8d,%r8d
 101b554:	je     101bb5d <schedule_clone+0x81d>
 101b55a:	cmpl   $0x0,0xac(%r14)
 101b562:	jne    101bb5d <schedule_clone+0x81d>
 101b568:	movabs $0x1fffffffffffffff,%rdx
 101b572:	inc    %rdx
 101b575:	or     %rdx,%rcx
 101b578:	mov    %rcx,-0x10(%rax)
 101b57c:	jmp    101bb5d <schedule_clone+0x81d>
 101b581:	mov    $0x2,%r12d
 101b587:	jmp    101bb63 <schedule_clone+0x823>
 101b58c:	mov    0x98(%r14),%rax
 101b593:	test   %rax,%rax
 101b596:	je     101bb75 <schedule_clone+0x835>
 101b59c:	lea    0x38(%r14),%rcx
 101b5a0:	lea    -0x1(%r13),%r8
 101b5a4:	xor    %r9d,%r9d
 101b5a7:	movabs $0x9e3779b97f4a7c15,%rdi
 101b5b1:	jmp    101b5e3 <schedule_clone+0x2a3>
 101b5b3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101b5c0:	lea    (%rdx,%rdx,2),%rdx
 101b5c4:	mov    0x10(%r10),%rsi
 101b5c8:	mov    %rsi,0x10(%rbx,%rdx,8)
 101b5cd:	vmovups (%r10),%xmm0
 101b5d2:	vmovups %xmm0,(%rbx,%rdx,8)
 101b5d7:	inc    %r9
 101b5da:	cmp    %rax,%r9
 101b5dd:	je     101b67c <schedule_clone+0x33c>
 101b5e3:	lea    (%r9,%r9,2),%rdx
 101b5e7:	mov    (%rcx,%rdx,8),%r11
 101b5eb:	test   %r11,%r11
 101b5ee:	je     101b5d7 <schedule_clone+0x297>
 101b5f0:	lea    (%rcx,%rdx,8),%r10
 101b5f4:	mov    0x10(%r10),%r12d
 101b5f8:	mov    %r11,%rdx
 101b5fb:	shr    $0x4,%rdx
 101b5ff:	mov    %r12,%rsi
 101b602:	imul   %rdi,%rsi
 101b606:	xor    %rdx,%rsi
 101b609:	mov    %rsi,%rdx
 101b60c:	shr    $0x1e,%rdx
 101b610:	xor    %rsi,%rdx
 101b613:	movabs $0xbf58476d1ce4e5b9,%rsi
 101b61d:	imul   %rsi,%rdx
 101b621:	mov    %rdx,%rsi
 101b624:	shr    $0x1b,%rsi
 101b628:	xor    %rdx,%rsi
 101b62b:	movabs $0x94d049bb133111eb,%rdx
 101b635:	imul   %rdx,%rsi
 101b639:	mov    %rsi,%rdx
 101b63c:	shr    $0x1f,%rdx
 101b640:	xor    %rsi,%rdx
 101b643:	jmp    101b653 <schedule_clone+0x313>
 101b645:	data16 cs nopw 0x0(%rax,%rax,1)
 101b650:	inc    %rdx
 101b653:	and    %r8,%rdx
 101b656:	lea    (%rdx,%rdx,2),%rsi
 101b65a:	mov    (%rbx,%rsi,8),%rsi
 101b65e:	test   %rsi,%rsi
 101b661:	je     101b5c0 <schedule_clone+0x280>
 101b667:	cmp    %r11,%rsi
 101b66a:	jne    101b650 <schedule_clone+0x310>
 101b66c:	lea    (%rdx,%rdx,2),%rsi
 101b670:	cmp    %r12d,0x10(%rbx,%rsi,8)
 101b675:	jne    101b650 <schedule_clone+0x310>
 101b677:	jmp    101b5c0 <schedule_clone+0x280>
 101b67c:	mov    0xa0(%r14),%rax
 101b683:	shl    $0x3,%rax
 101b687:	lea    (%rax,%rax,2),%rdx
 101b68b:	mov    -0x40(%rbp),%r12
 101b68f:	mov    (%r12),%rdi
 101b693:	mov    0x30(%r14),%rsi
 101b697:	call   1012710 <myl_rc_meta_free>
 101b69c:	mov    %rbx,0x30(%r14)
 101b6a0:	mov    %r13,0xa0(%r14)
 101b6a7:	mov    %r12,%r13
 101b6aa:	mov    $0x1,%r9b
 101b6ad:	mov    -0x48(%rbp),%rbx
 101b6b1:	mov    -0x2c(%rbp),%r8d
 101b6b5:	mov    0x0(%r13),%rdi
 101b6b9:	mov    0x1608(%rdi),%rax
 101b6c0:	cmpb   $0x0,0x120(%rax)
 101b6c7:	jne    101b6da <schedule_clone+0x39a>
 101b6c9:	mov    -0x8(%r15),%rcx
 101b6cd:	cmp    $0x1029138,%rcx
 101b6d4:	je     101b960 <schedule_clone+0x620>
 101b6da:	mov    %r13,-0x40(%rbp)
 101b6de:	mov    -0x8(%r15),%rsi
 101b6e2:	mov    0x34(%rsi),%ecx
 101b6e5:	cmp    %rcx,0xa0(%rax)
 101b6ec:	jbe    101bb7c <schedule_clone+0x83c>
 101b6f2:	mov    0x98(%rax),%rax
 101b6f9:	shl    $0x4,%rcx
 101b6fd:	cmp    %rsi,(%rax,%rcx,1)
 101b701:	jne    101bb7c <schedule_clone+0x83c>
 101b707:	add    %rcx,%rax
 101b70a:	mov    0x8(%rax),%r13
 101b70e:	mov    -0x58(%rbp),%r14
 101b712:	test   %r13,%r13
 101b715:	je     101bb89 <schedule_clone+0x849>
 101b71b:	cmpq   $0x0,0x18(%r13)
 101b720:	jne    101bb89 <schedule_clone+0x849>
 101b726:	cmpq   $0x0,0x28(%r13)
 101b72b:	je     101b740 <schedule_clone+0x400>
 101b72d:	cmpq   $0x0,0x30(%r13)
 101b732:	jne    101b75c <schedule_clone+0x41c>
 101b734:	xor    %edx,%edx
 101b736:	test   %r8d,%r8d
 101b739:	jne    101b784 <schedule_clone+0x444>
 101b73b:	jmp    101b929 <schedule_clone+0x5e9>
 101b740:	cmpq   $0x0,0x10(%r13)
 101b745:	jne    101bb89 <schedule_clone+0x849>
 101b74b:	cmpq   $0x0,0x30(%r13)
 101b750:	jne    101b75c <schedule_clone+0x41c>
 101b752:	mov    0x8(%r13),%rax
 101b756:	cmpl   $0x0,0x8(%rax)
 101b75a:	je     101b734 <schedule_clone+0x3f4>
 101b75c:	mov    %rbx,-0x48(%rbp)
 101b760:	mov    (%r14),%rsi
 101b763:	mov    0x8(%r14),%rbx
 101b767:	mov    0x10(%r14),%rax
 101b76b:	cmp    %rax,%rbx
 101b76e:	jae    101b7b4 <schedule_clone+0x474>
 101b770:	mov    $0x1,%dl
 101b772:	test   %rsi,%rsi
 101b775:	mov    -0x48(%rbp),%rbx
 101b779:	je     101b7a9 <schedule_clone+0x469>
 101b77b:	test   %r8d,%r8d
 101b77e:	je     101b929 <schedule_clone+0x5e9>
 101b784:	mov    0x18(%r14),%rsi
 101b788:	mov    %r14,%rax
 101b78b:	mov    0x20(%r14),%r14
 101b78f:	mov    0x28(%rax),%rax
 101b793:	cmp    %rax,%r14
 101b796:	jae    101b874 <schedule_clone+0x534>
 101b79c:	test   %rsi,%rsi
 101b79f:	mov    -0x58(%rbp),%r14
 101b7a3:	jne    101b929 <schedule_clone+0x5e9>
 101b7a9:	mov    $0x1,%r12d
 101b7af:	jmp    101bb63 <schedule_clone+0x823>
 101b7b4:	lea    (%rax,%rax,1),%rcx
 101b7b8:	test   %rax,%rax
 101b7bb:	mov    $0x10,%r14d
 101b7c1:	cmovne %rcx,%r14
 101b7c5:	mov    $0x1,%r12d
 101b7cb:	cmp    %rax,%r14
 101b7ce:	jb     101bb63 <schedule_clone+0x823>
 101b7d4:	mov    $0x28,%ecx
 101b7d9:	mov    %r14,%rax
 101b7dc:	mul    %rcx
 101b7df:	jo     101bb63 <schedule_clone+0x823>
 101b7e5:	mov    %rsi,-0x60(%rbp)
 101b7e9:	mov    %r9d,-0x30(%rbp)
 101b7ed:	mov    %r8d,-0x2c(%rbp)
 101b7f1:	mov    -0x40(%rbp),%rcx
 101b7f5:	mov    (%rcx),%rdi
 101b7f8:	mov    %rdi,-0x68(%rbp)
 101b7fc:	mov    %rax,%rsi
 101b7ff:	call   1012690 <myl_rc_meta_alloc>
 101b804:	test   %rax,%rax
 101b807:	je     101bb63 <schedule_clone+0x823>
 101b80d:	test   %rbx,%rbx
 101b810:	mov    -0x60(%rbp),%r12
 101b814:	mov    %rax,-0x38(%rbp)
 101b818:	je     101b82e <schedule_clone+0x4ee>
 101b81a:	shl    $0x3,%rbx
 101b81e:	lea    (%rbx,%rbx,4),%rdx
 101b822:	mov    -0x38(%rbp),%rdi
 101b826:	mov    %r12,%rsi
 101b829:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101b82e:	mov    -0x58(%rbp),%rbx
 101b832:	mov    0x10(%rbx),%rax
 101b836:	shl    $0x3,%rax
 101b83a:	lea    (%rax,%rax,4),%rdx
 101b83e:	mov    -0x68(%rbp),%rdi
 101b842:	mov    %r12,%rsi
 101b845:	call   1012710 <myl_rc_meta_free>
 101b84a:	mov    %r14,0x10(%rbx)
 101b84e:	mov    %rbx,%r14
 101b851:	mov    -0x38(%rbp),%rax
 101b855:	mov    %rax,(%rbx)
 101b858:	mov    $0x1,%dl
 101b85a:	mov    -0x48(%rbp),%rbx
 101b85e:	mov    -0x2c(%rbp),%r8d
 101b862:	mov    -0x30(%rbp),%r9d
 101b866:	test   %r8d,%r8d
 101b869:	jne    101b784 <schedule_clone+0x444>
 101b86f:	jmp    101b929 <schedule_clone+0x5e9>
 101b874:	mov    %rbx,-0x48(%rbp)
 101b878:	lea    (%rax,%rax,1),%rcx
 101b87c:	test   %rax,%rax
 101b87f:	mov    $0x10,%ebx
 101b884:	cmovne %rcx,%rbx
 101b888:	cmp    %rax,%rbx
 101b88b:	setb   %al
 101b88e:	mov    %rbx,%rcx
 101b891:	shr    $0x3d,%rcx
 101b895:	setne  %cl
 101b898:	or     %al,%cl
 101b89a:	mov    $0x1,%r12d
 101b8a0:	jne    101bb63 <schedule_clone+0x823>
 101b8a6:	mov    %rsi,-0x68(%rbp)
 101b8aa:	mov    %edx,-0x38(%rbp)
 101b8ad:	mov    %r9d,-0x30(%rbp)
 101b8b1:	mov    %r8d,-0x2c(%rbp)
 101b8b5:	mov    -0x40(%rbp),%rax
 101b8b9:	mov    (%rax),%rdi
 101b8bc:	lea    0x0(,%rbx,8),%rsi
 101b8c4:	mov    %rdi,-0x70(%rbp)
 101b8c8:	call   1012690 <myl_rc_meta_alloc>
 101b8cd:	test   %rax,%rax
 101b8d0:	je     101bb63 <schedule_clone+0x823>
 101b8d6:	test   %r14,%r14
 101b8d9:	mov    -0x68(%rbp),%r12
 101b8dd:	mov    %rax,-0x60(%rbp)
 101b8e1:	je     101b8f6 <schedule_clone+0x5b6>
 101b8e3:	shl    $0x3,%r14
 101b8e7:	mov    -0x60(%rbp),%rdi
 101b8eb:	mov    %r12,%rsi
 101b8ee:	mov    %r14,%rdx
 101b8f1:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101b8f6:	mov    -0x58(%rbp),%r14
 101b8fa:	mov    0x28(%r14),%rdx
 101b8fe:	shl    $0x3,%rdx
 101b902:	mov    -0x70(%rbp),%rdi
 101b906:	mov    %r12,%rsi
 101b909:	call   1012710 <myl_rc_meta_free>
 101b90e:	mov    %rbx,0x28(%r14)
 101b912:	mov    -0x60(%rbp),%rax
 101b916:	mov    %rax,0x18(%r14)
 101b91a:	mov    -0x48(%rbp),%rbx
 101b91e:	mov    -0x2c(%rbp),%r8d
 101b922:	mov    -0x30(%rbp),%r9d
 101b926:	mov    -0x38(%rbp),%edx
 101b929:	mov    %edx,-0x38(%rbp)
 101b92c:	mov    %r9d,-0x30(%rbp)
 101b930:	movq   $0x0,-0x50(%rbp)
 101b938:	mov    0x28(%r13),%rax
 101b93c:	test   %rax,%rax
 101b93f:	mov    %r8d,-0x2c(%rbp)
 101b943:	je     101b98e <schedule_clone+0x64e>
 101b945:	mov    -0x40(%rbp),%rcx
 101b949:	mov    (%rcx),%rdi
 101b94c:	lea    -0x50(%rbp),%rcx
 101b950:	mov    %r15,%rsi
 101b953:	mov    %r8d,%edx
 101b956:	call   *%rax
 101b958:	mov    %eax,%r12d
 101b95b:	jmp    101ba0c <schedule_clone+0x6cc>
 101b960:	mov    %r9d,-0x30(%rbp)
 101b964:	mov    %r8d,%r14d
 101b967:	call   1011b10 <myl_rc_list_require>
 101b96c:	mov    %eax,%r12d
 101b96f:	test   %eax,%eax
 101b971:	jne    101bb63 <schedule_clone+0x823>
 101b977:	mov    0x0(%r13),%rdi
 101b97b:	mov    0x1608(%rdi),%rax
 101b982:	mov    %r14d,%r8d
 101b985:	mov    -0x30(%rbp),%r9d
 101b989:	jmp    101b6da <schedule_clone+0x39a>
 101b98e:	mov    -0x8(%r15),%rax
 101b992:	mov    %rax,-0x88(%rbp)
 101b999:	mov    -0x10(%r15),%rax
 101b99d:	mov    %rax,%rcx
 101b9a0:	shr    $0x2,%rcx
 101b9a4:	bt     $0x3e,%rax
 101b9a9:	movabs $0x3ffffffffffffff,%rax
 101b9b3:	movabs $0x3fffffffff,%rdx
 101b9bd:	cmovae %rax,%rdx
 101b9c1:	and    %rcx,%rdx
 101b9c4:	mov    %rdx,-0x80(%rbp)
 101b9c8:	mov    %r8d,-0x78(%rbp)
 101b9cc:	movl   $0x0,-0x74(%rbp)
 101b9d3:	mov    -0x40(%rbp),%rax
 101b9d7:	mov    (%rax),%rdi
 101b9da:	lea    -0x88(%rbp),%rsi
 101b9e1:	lea    -0x50(%rbp),%rdx
 101b9e5:	call   1012a30 <myl_rc_new>
 101b9ea:	mov    %eax,%r12d
 101b9ed:	test   %eax,%eax
 101b9ef:	jne    101ba0c <schedule_clone+0x6cc>
 101b9f1:	mov    -0x40(%rbp),%rax
 101b9f5:	mov    (%rax),%rdi
 101b9f8:	mov    0x8(%r13),%rsi
 101b9fc:	mov    -0x50(%rbp),%rdx
 101ba00:	mov    -0x80(%rbp),%r8
 101ba04:	mov    %r15,%rcx
 101ba07:	call   1016c50 <myl_rc_value_seed>
 101ba0c:	test   %r12d,%r12d
 101ba0f:	mov    -0x30(%rbp),%ecx
 101ba12:	jne    101bb63 <schedule_clone+0x823>
 101ba18:	mov    -0x50(%rbp),%rax
 101ba1c:	test   %rax,%rax
 101ba1f:	je     101bb89 <schedule_clone+0x849>
 101ba25:	test   %cl,%cl
 101ba27:	mov    -0x2c(%rbp),%r9d
 101ba2b:	je     101bacd <schedule_clone+0x78d>
 101ba31:	mov    0xa0(%r14),%rdx
 101ba38:	test   %rdx,%rdx
 101ba3b:	je     101bad2 <schedule_clone+0x792>
 101ba41:	mov    0x30(%r14),%rcx
 101ba45:	mov    %r15,%rsi
 101ba48:	shr    $0x4,%rsi
 101ba4c:	mov    %r9d,%edi
 101ba4f:	movabs $0x9e3779b97f4a7c15,%r8
 101ba59:	imul   %rdi,%r8
 101ba5d:	xor    %rsi,%r8
 101ba60:	mov    %r8,%rsi
 101ba63:	shr    $0x1e,%rsi
 101ba67:	xor    %r8,%rsi
 101ba6a:	movabs $0xbf58476d1ce4e5b9,%rdi
 101ba74:	imul   %rsi,%rdi
 101ba78:	mov    %rdi,%rsi
 101ba7b:	shr    $0x1b,%rsi
 101ba7f:	xor    %rdi,%rsi
 101ba82:	movabs $0x94d049bb133111eb,%rdi
 101ba8c:	imul   %rsi,%rdi
 101ba90:	mov    %rdi,%rsi
 101ba93:	shr    $0x1f,%rsi
 101ba97:	xor    %rdi,%rsi
 101ba9a:	dec    %rdx
 101ba9d:	jmp    101baa3 <schedule_clone+0x763>
 101ba9f:	nop
 101baa0:	inc    %rsi
 101baa3:	and    %rdx,%rsi
 101baa6:	lea    (%rsi,%rsi,2),%rdi
 101baaa:	mov    (%rcx,%rdi,8),%rdi
 101baae:	test   %rdi,%rdi
 101bab1:	je     101bac3 <schedule_clone+0x783>
 101bab3:	cmp    %r15,%rdi
 101bab6:	jne    101baa0 <schedule_clone+0x760>
 101bab8:	lea    (%rsi,%rsi,2),%rdi
 101babc:	cmp    %r9d,0x10(%rcx,%rdi,8)
 101bac1:	jne    101baa0 <schedule_clone+0x760>
 101bac3:	lea    (%rsi,%rsi,2),%rdx
 101bac7:	lea    (%rcx,%rdx,8),%rcx
 101bacb:	jmp    101bae5 <schedule_clone+0x7a5>
 101bacd:	mov    -0x38(%rbp),%edx
 101bad0:	jmp    101bb05 <schedule_clone+0x7c5>
 101bad2:	mov    0x98(%r14),%rcx
 101bad9:	lea    (%rcx,%rcx,2),%rcx
 101badd:	lea    (%r14,%rcx,8),%rcx
 101bae1:	add    $0x38,%rcx
 101bae5:	mov    -0x38(%rbp),%edx
 101bae8:	mov    %r15,(%rcx)
 101baeb:	mov    %rax,0x8(%rcx)
 101baef:	mov    %r9d,0x10(%rcx)
 101baf3:	movl   $0x0,0x14(%rcx)
 101bafa:	incq   0x98(%r14)
 101bb01:	mov    -0x50(%rbp),%rax
 101bb05:	test   %dl,%dl
 101bb07:	je     101bb44 <schedule_clone+0x804>
 101bb09:	mov    (%r14),%rcx
 101bb0c:	mov    0x8(%r14),%rdx
 101bb10:	lea    0x1(%rdx),%rsi
 101bb14:	mov    %rsi,0x8(%r14)
 101bb18:	lea    (%rdx,%rdx,4),%rdx
 101bb1c:	mov    %r15,(%rcx,%rdx,8)
 101bb20:	mov    %rax,0x8(%rcx,%rdx,8)
 101bb25:	mov    %r13,0x10(%rcx,%rdx,8)
 101bb2a:	movq   $0x0,0x18(%rcx,%rdx,8)
 101bb33:	mov    %r9d,0x20(%rcx,%rdx,8)
 101bb38:	movl   $0x0,0x24(%rcx,%rdx,8)
 101bb40:	mov    -0x50(%rbp),%rax
 101bb44:	test   %r9d,%r9d
 101bb47:	je     101bb5d <schedule_clone+0x81d>
 101bb49:	mov    0x18(%r14),%rcx
 101bb4d:	mov    0x20(%r14),%rdx
 101bb51:	lea    0x1(%rdx),%rsi
 101bb55:	mov    %rsi,0x20(%r14)
 101bb59:	mov    %rax,(%rcx,%rdx,8)
 101bb5d:	mov    %rax,(%rbx)
 101bb60:	xor    %r12d,%r12d
 101bb63:	mov    %r12d,%eax
 101bb66:	add    $0x68,%rsp
 101bb6a:	pop    %rbx
 101bb6b:	pop    %r12
 101bb6d:	pop    %r13
 101bb6f:	pop    %r14
 101bb71:	pop    %r15
 101bb73:	pop    %rbp
 101bb74:	ret
 101bb75:	xor    %edx,%edx
 101bb77:	jmp    101b68b <schedule_clone+0x34b>
 101bb7c:	call   10130fa <myl_rc_binding_find_slow>
 101bb81:	mov    %rax,%r13
 101bb84:	jmp    101b70e <schedule_clone+0x3ce>
 101bb89:	call   101267d <myl_rc_invariant_failed>
 101bb8e:	int3
 101bb8f:	int3

000000000101bb90 <queue_mark>:
 101bb90:	push   %rbp
 101bb91:	mov    %rsp,%rbp
 101bb94:	push   %r15
 101bb96:	push   %r14
 101bb98:	push   %r13
 101bb9a:	push   %r12
 101bb9c:	push   %rbx
 101bb9d:	sub    $0x18,%rsp
 101bba1:	mov    0x28(%rdi),%rcx
 101bba5:	xor    %eax,%eax
 101bba7:	cmpl   $0x0,0xac(%rcx)
 101bbae:	je     101bcd4 <queue_mark+0x144>
 101bbb4:	movabs $0x1fffffffffffffff,%r15
 101bbbe:	lea    0x3(%r15),%rcx
 101bbc2:	test   %rcx,-0x10(%rsi)
 101bbc6:	jne    101bcd4 <queue_mark+0x144>
 101bbcc:	mov    %rdi,%rbx
 101bbcf:	mov    %rsi,%r12
 101bbd2:	mov    %rsi,%rdi
 101bbd5:	call   101e090 <myl_rc_native_mutable>
 101bbda:	test   %eax,%eax
 101bbdc:	je     101bcd2 <queue_mark+0x142>
 101bbe2:	testb  $0x10,-0x9(%r12)
 101bbe8:	jne    101bce3 <queue_mark+0x153>
 101bbee:	mov    %rbx,%rcx
 101bbf1:	mov    0x28(%rbx),%r13
 101bbf5:	mov    0xb0(%r13),%rsi
 101bbfc:	mov    0xb8(%r13),%rbx
 101bc03:	mov    0xc0(%r13),%rdx
 101bc0a:	cmp    %rdx,%rbx
 101bc0d:	jae    101bc28 <queue_mark+0x98>
 101bc0f:	mov    %r12,%rax
 101bc12:	mov    %rsi,%r15
 101bc15:	test   %rsi,%rsi
 101bc18:	jne    101bcbc <queue_mark+0x12c>
 101bc1e:	mov    $0x1,%eax
 101bc23:	jmp    101bcd4 <queue_mark+0x144>
 101bc28:	lea    (%rdx,%rdx,1),%rax
 101bc2c:	test   %rdx,%rdx
 101bc2f:	mov    $0x10,%r14d
 101bc35:	cmovne %rax,%r14
 101bc39:	cmp    %rdx,%r14
 101bc3c:	setb   %al
 101bc3f:	cmp    %r15,%r14
 101bc42:	seta   %dl
 101bc45:	or     %al,%dl
 101bc47:	mov    $0x1,%eax
 101bc4c:	jne    101bcd4 <queue_mark+0x144>
 101bc52:	mov    %rsi,-0x30(%rbp)
 101bc56:	mov    (%rcx),%rdi
 101bc59:	lea    0x0(,%r14,8),%rsi
 101bc61:	mov    %rdi,-0x38(%rbp)
 101bc65:	call   1012690 <myl_rc_meta_alloc>
 101bc6a:	mov    %rax,%r15
 101bc6d:	mov    $0x1,%eax
 101bc72:	test   %r15,%r15
 101bc75:	je     101bcd4 <queue_mark+0x144>
 101bc77:	test   %rbx,%rbx
 101bc7a:	mov    -0x30(%rbp),%rsi
 101bc7e:	je     101bc97 <queue_mark+0x107>
 101bc80:	shl    $0x3,%rbx
 101bc84:	mov    %r15,%rdi
 101bc87:	mov    -0x30(%rbp),%rsi
 101bc8b:	mov    %rbx,%rdx
 101bc8e:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101bc93:	mov    -0x30(%rbp),%rsi
 101bc97:	mov    0xc0(%r13),%rdx
 101bc9e:	shl    $0x3,%rdx
 101bca2:	mov    -0x38(%rbp),%rdi
 101bca6:	call   1012710 <myl_rc_meta_free>
 101bcab:	mov    %r14,0xc0(%r13)
 101bcb2:	mov    0xb8(%r13),%rbx
 101bcb9:	mov    %r12,%rax
 101bcbc:	mov    %r15,0xb0(%r13)
 101bcc3:	lea    0x1(%rbx),%rcx
 101bcc7:	mov    %rcx,0xb8(%r13)
 101bcce:	mov    %rax,(%r15,%rbx,8)
 101bcd2:	xor    %eax,%eax
 101bcd4:	add    $0x18,%rsp
 101bcd8:	pop    %rbx
 101bcd9:	pop    %r12
 101bcdb:	pop    %r13
 101bcdd:	pop    %r14
 101bcdf:	pop    %r15
 101bce1:	pop    %rbp
 101bce2:	ret
 101bce3:	call   101267d <myl_rc_invariant_failed>
 101bce8:	int3
 101bce9:	int3
 101bcea:	int3
 101bceb:	int3
 101bcec:	int3
 101bced:	int3
 101bcee:	int3
 101bcef:	int3

000000000101bcf0 <transfer_hold>:
 101bcf0:	push   %rbp
 101bcf1:	mov    %rsp,%rbp
 101bcf4:	push   %r15
 101bcf6:	push   %r14
 101bcf8:	push   %r12
 101bcfa:	push   %rbx
 101bcfb:	sub    $0x10,%rsp
 101bcff:	mov    %rsi,%rbx
 101bd02:	test   %rdx,%rdx
 101bd05:	je     101bd83 <transfer_hold+0x93>
 101bd07:	mov    -0x10(%rdx),%rcx
 101bd0b:	bt     $0x3e,%rcx
 101bd10:	jae    101bd83 <transfer_hold+0x93>
 101bd12:	shr    $0x28,%rcx
 101bd16:	and    $0xfffff,%ecx
 101bd1c:	mov    0x20(%rdi),%eax
 101bd1f:	cmp    %eax,%ecx
 101bd21:	jbe    101bd83 <transfer_hold+0x93>
 101bd23:	mov    0x28(%rdi),%rcx
 101bd27:	cmpl   $0x0,0xa8(%rcx)
 101bd2e:	je     101bdb6 <transfer_hold+0xc6>
 101bd34:	lea    -0x28(%rbp),%rcx
 101bd38:	mov    %rdi,%r14
 101bd3b:	mov    %rdx,%rsi
 101bd3e:	mov    %eax,%edx
 101bd40:	call   101b340 <schedule_clone>
 101bd45:	test   %eax,%eax
 101bd47:	jne    101bdbb <transfer_hold+0xcb>
 101bd49:	movq   $0x0,-0x30(%rbp)
 101bd51:	mov    %r14,%r12
 101bd54:	mov    (%r14),%rdi
 101bd57:	mov    -0x28(%rbp),%r14
 101bd5b:	lea    -0x30(%rbp),%rdx
 101bd5f:	mov    %r14,%rsi
 101bd62:	call   1012d90 <myl_rc_hold_acquire>
 101bd67:	mov    %eax,%r15d
 101bd6a:	mov    (%r12),%rdi
 101bd6e:	mov    %r14,%rsi
 101bd71:	call   1012cd0 <myl_rc_owner_release>
 101bd76:	mov    %r14,%rdx
 101bd79:	test   %r15d,%r15d
 101bd7c:	je     101bd89 <transfer_hold+0x99>
 101bd7e:	mov    %r15d,%eax
 101bd81:	jmp    101bdbb <transfer_hold+0xcb>
 101bd83:	cmpl   $0x0,0x24(%rdi)
 101bd87:	je     101bd90 <transfer_hold+0xa0>
 101bd89:	mov    %rdx,(%rbx)
 101bd8c:	xor    %eax,%eax
 101bd8e:	jmp    101bdbb <transfer_hold+0xcb>
 101bd90:	movq   $0x0,-0x28(%rbp)
 101bd98:	mov    (%rdi),%rdi
 101bd9b:	lea    -0x28(%rbp),%rax
 101bd9f:	mov    %rdx,%rsi
 101bda2:	mov    %rdx,%r14
 101bda5:	mov    %rax,%rdx
 101bda8:	call   1012d90 <myl_rc_hold_acquire>
 101bdad:	mov    %r14,%rdx
 101bdb0:	test   %eax,%eax
 101bdb2:	jne    101bdbb <transfer_hold+0xcb>
 101bdb4:	jmp    101bd89 <transfer_hold+0x99>
 101bdb6:	mov    $0x3,%eax
 101bdbb:	add    $0x10,%rsp
 101bdbf:	pop    %rbx
 101bdc0:	pop    %r12
 101bdc2:	pop    %r14
 101bdc4:	pop    %r15
 101bdc6:	pop    %rbp
 101bdc7:	ret
 101bdc8:	int3
 101bdc9:	int3
 101bdca:	int3
 101bdcb:	int3
 101bdcc:	int3
 101bdcd:	int3
 101bdce:	int3
 101bdcf:	int3

000000000101bdd0 <retain_pointer>:
 101bdd0:	mov    (%rdx),%rdx
 101bdd3:	test   %rdx,%rdx
 101bdd6:	je     101bdfd <retain_pointer+0x2d>
 101bdd8:	mov    -0x10(%rdx),%r8
 101bddc:	bt     $0x3e,%r8
 101bde1:	jae    101be07 <retain_pointer+0x37>
 101bde3:	mov    %r8,%r9
 101bde6:	shr    $0x28,%r9
 101bdea:	and    $0xfffff,%r9d
 101bdf1:	mov    $0x3,%eax
 101bdf6:	cmp    0x20(%rdi),%r9d
 101bdfa:	jbe    101be07 <retain_pointer+0x37>
 101bdfc:	ret
 101bdfd:	cmp    $0x5,%ecx
 101be00:	jne    101be46 <retain_pointer+0x76>
 101be02:	jmp    101bcf0 <transfer_hold>
 101be07:	cmp    $0x5,%ecx
 101be0a:	je     101bcf0 <transfer_hold>
 101be10:	movabs $0x4000000000000000,%rax
 101be1a:	add    $0x2,%rax
 101be1e:	test   %rax,%r8
 101be21:	jne    101be46 <retain_pointer+0x76>
 101be23:	test   $0x1,%r8b
 101be27:	jne    101be52 <retain_pointer+0x82>
 101be29:	mov    -0x20(%rdx),%rax
 101be2d:	cmp    $0xffffffffffffffff,%rax
 101be31:	je     101be4c <retain_pointer+0x7c>
 101be33:	test   %rax,%rax
 101be36:	jne    101be3f <retain_pointer+0x6f>
 101be38:	cmpq   $0x0,-0x18(%rdx)
 101be3d:	je     101be52 <retain_pointer+0x82>
 101be3f:	inc    %rax
 101be42:	mov    %rax,-0x20(%rdx)
 101be46:	mov    %rdx,(%rsi)
 101be49:	xor    %eax,%eax
 101be4b:	ret
 101be4c:	mov    $0x2,%eax
 101be51:	ret
 101be52:	push   %rbp
 101be53:	mov    %rsp,%rbp
 101be56:	call   101267d <myl_rc_invariant_failed>
 101be5b:	int3
 101be5c:	int3
 101be5d:	int3
 101be5e:	int3
 101be5f:	int3

000000000101be60 <myl_rc_storage_alloc>:
 101be60:	push   %rbp
 101be61:	mov    %rsp,%rbp
 101be64:	push   %r15
 101be66:	push   %r14
 101be68:	push   %r13
 101be6a:	push   %r12
 101be6c:	push   %rbx
 101be6d:	sub    $0x28,%rsp
 101be71:	test   %rdi,%rdi
 101be74:	je     101c1ef <myl_rc_storage_alloc+0x38f>
 101be7a:	mov    %rsi,%r14
 101be7d:	test   %rsi,%rsi
 101be80:	je     101c1ef <myl_rc_storage_alloc+0x38f>
 101be86:	mov    %rdi,%rbx
 101be89:	mov    0x1608(%rdi),%rax
 101be90:	test   %rax,%rax
 101be93:	je     101c1ef <myl_rc_storage_alloc+0x38f>
 101be99:	mov    %ecx,%r12d
 101be9c:	mov    %rdx,%r15
 101be9f:	test   %ecx,%ecx
 101bea1:	setne  %cl
 101bea4:	cmp    $0x1,%rdx
 101bea8:	setne  %dl
 101beab:	or     %cl,%dl
 101bead:	jne    101bebb <myl_rc_storage_alloc+0x5b>
 101beaf:	lea    0x34a(%rip),%rcx        # 101c200 <allocate>
 101beb6:	cmp    %rcx,(%rax)
 101beb9:	je     101bf37 <myl_rc_storage_alloc+0xd7>
 101bebb:	cmp    %r14,0x110(%rax)
 101bec2:	je     101bed8 <myl_rc_storage_alloc+0x78>
 101bec4:	mov    %rbx,%rdi
 101bec7:	mov    %r14,%rsi
 101beca:	call   101d7b0 <myl_rc_native_shape>
 101becf:	test   %rax,%rax
 101bed2:	je     101c1ad <myl_rc_storage_alloc+0x34d>
 101bed8:	test   %r12d,%r12d
 101bedb:	setne  %al
 101bede:	cmp    $0x2,%r15
 101bee2:	setb   %cl
 101bee5:	or     %al,%cl
 101bee7:	jne    101c16e <myl_rc_storage_alloc+0x30e>
 101beed:	mov    (%r14),%r13
 101bef0:	test   %r13,%r13
 101bef3:	je     101c16e <myl_rc_storage_alloc+0x30e>
 101bef9:	cmpq   $0x10,0x8(%r14)
 101befe:	ja     101c16e <myl_rc_storage_alloc+0x30e>
 101bf04:	mov    0x1608(%rbx),%rax
 101bf0b:	lea    0x2ee(%rip),%rcx        # 101c200 <allocate>
 101bf12:	cmp    %rcx,(%rax)
 101bf15:	jne    101c16e <myl_rc_storage_alloc+0x30e>
 101bf1b:	cmp    $0x1fe0,%r13
 101bf22:	ja     101c07e <myl_rc_storage_alloc+0x21e>
 101bf28:	mov    $0x1fe0,%eax
 101bf2d:	xor    %edx,%edx
 101bf2f:	div    %r13d
 101bf32:	jmp    101c080 <myl_rc_storage_alloc+0x220>
 101bf37:	mov    0x20(%rax),%r13
 101bf3b:	cmp    %r14,0x210(%r13)
 101bf42:	je     101bf9a <myl_rc_storage_alloc+0x13a>
 101bf44:	mov    0x34(%r14),%ecx
 101bf48:	cmp    %rcx,0xa0(%rax)
 101bf4f:	jbe    101c138 <myl_rc_storage_alloc+0x2d8>
 101bf55:	mov    0x98(%rax),%rax
 101bf5c:	shl    $0x4,%rcx
 101bf60:	cmp    %r14,(%rax,%rcx,1)
 101bf64:	jne    101c138 <myl_rc_storage_alloc+0x2d8>
 101bf6a:	add    %rcx,%rax
 101bf6d:	mov    0x8(%rax),%rax
 101bf71:	test   %rax,%rax
 101bf74:	je     101c14c <myl_rc_storage_alloc+0x2ec>
 101bf7a:	mov    0xc0(%rax),%esi
 101bf80:	test   %esi,%esi
 101bf82:	je     101c14c <myl_rc_storage_alloc+0x2ec>
 101bf88:	dec    %esi
 101bf8a:	mov    %r14,0x210(%r13)
 101bf91:	mov    %rsi,0x218(%r13)
 101bf98:	jmp    101bfa1 <myl_rc_storage_alloc+0x141>
 101bf9a:	mov    0x218(%r13),%rsi
 101bfa1:	mov    0x1610(%rbx,%rsi,8),%r15
 101bfa9:	test   %r15,%r15
 101bfac:	je     101bfbb <myl_rc_storage_alloc+0x15b>
 101bfae:	mov    (%r15),%rax
 101bfb1:	mov    %rax,0x1610(%rbx,%rsi,8)
 101bfb9:	jmp    101bfcf <myl_rc_storage_alloc+0x16f>
 101bfbb:	mov    %rbx,%rdi
 101bfbe:	call   101cfa0 <slab_refill>
 101bfc3:	mov    %rax,%r15
 101bfc6:	test   %rax,%rax
 101bfc9:	je     101c127 <myl_rc_storage_alloc+0x2c7>
 101bfcf:	lea    0x20(%r15),%rax
 101bfd3:	mov    (%r14),%rdx
 101bfd6:	lea    0xf(%rdx),%rcx
 101bfda:	shr    $0x4,%rcx
 101bfde:	cmp    $0x8,%rcx
 101bfe2:	ja     101c0cc <myl_rc_storage_alloc+0x26c>
 101bfe8:	lea    -0x18e8b(%rip),%rdx        # 1003164 <myl_rc_map_sentinel+0xc4>
 101bfef:	movslq (%rdx,%rcx,4),%rcx
 101bff3:	add    %rdx,%rcx
 101bff6:	jmp    *%rcx
 101bff8:	vxorps %xmm0,%xmm0,%xmm0
 101bffc:	vmovaps %xmm0,0x90(%r15)
 101c005:	vxorps %xmm0,%xmm0,%xmm0
 101c009:	vmovaps %xmm0,0x80(%r15)
 101c012:	vxorps %xmm0,%xmm0,%xmm0
 101c016:	vmovaps %xmm0,0x70(%r15)
 101c01c:	vxorps %xmm0,%xmm0,%xmm0
 101c020:	vmovaps %xmm0,0x60(%r15)
 101c026:	vxorps %xmm0,%xmm0,%xmm0
 101c02a:	vmovaps %xmm0,0x50(%r15)
 101c030:	vxorps %xmm0,%xmm0,%xmm0
 101c034:	vmovaps %xmm0,0x40(%r15)
 101c03a:	vxorps %xmm0,%xmm0,%xmm0
 101c03e:	vmovaps %xmm0,0x30(%r15)
 101c044:	vxorps %xmm0,%xmm0,%xmm0
 101c048:	vmovaps %xmm0,(%rax)
 101c04c:	movq   $0x1,(%r15)
 101c053:	movq   $0x0,0x8(%r15)
 101c05b:	movq   $0x4,0x10(%r15)
 101c063:	mov    %r14,0x18(%r15)
 101c067:	vmovdqu 0x40(%rbx),%xmm0
 101c06c:	vpcmpeqd %xmm1,%xmm1,%xmm1
 101c070:	vpsubq %xmm1,%xmm0,%xmm0
 101c074:	vmovdqu %xmm0,0x40(%rbx)
 101c079:	jmp    101c1af <myl_rc_storage_alloc+0x34f>
 101c07e:	xor    %eax,%eax
 101c080:	cmp    %rax,%r15
 101c083:	ja     101c16e <myl_rc_storage_alloc+0x30e>
 101c089:	imul   %r15,%r13
 101c08d:	lea    0x20(%r13),%rax
 101c091:	mov    $0x20,%esi
 101c096:	cmp    $0x2000,%rax
 101c09c:	ja     101c0b1 <myl_rc_storage_alloc+0x251>
 101c09e:	lea    0x2f(%r13),%rax
 101c0a2:	shr    $0x4,%rax
 101c0a6:	lea    -0x18d6d(%rip),%rcx        # 1003340 <class_of>
 101c0ad:	movzbl (%rax,%rcx,1),%esi
 101c0b1:	mov    0x1610(%rbx,%rsi,8),%r12
 101c0b9:	test   %r12,%r12
 101c0bc:	je     101c0e1 <myl_rc_storage_alloc+0x281>
 101c0be:	mov    (%r12),%rax
 101c0c2:	mov    %rax,0x1610(%rbx,%rsi,8)
 101c0ca:	jmp    101c0f1 <myl_rc_storage_alloc+0x291>
 101c0cc:	mov    %rax,%rdi
 101c0cf:	xor    %esi,%esi
 101c0d1:	mov    %rax,%r12
 101c0d4:	call   101e6b0 <compiler_rt.fastMemset>
 101c0d9:	mov    %r12,%rax
 101c0dc:	jmp    101c04c <myl_rc_storage_alloc+0x1ec>
 101c0e1:	mov    %rbx,%rdi
 101c0e4:	call   101cfa0 <slab_refill>
 101c0e9:	mov    %rax,%r12
 101c0ec:	test   %rax,%rax
 101c0ef:	je     101c127 <myl_rc_storage_alloc+0x2c7>
 101c0f1:	lea    0x20(%r12),%rdi
 101c0f6:	mov    %r13,%rsi
 101c0f9:	call   101c4d0 <zero_payload>
 101c0fe:	lea    0x20(%r12),%rax
 101c103:	movq   $0x1,(%r12)
 101c10b:	movq   $0x0,0x8(%r12)
 101c114:	shl    $0x2,%r15
 101c118:	mov    %r15,0x10(%r12)
 101c11d:	mov    %r14,0x18(%r12)
 101c122:	jmp    101c067 <myl_rc_storage_alloc+0x207>
 101c127:	mov    %rbx,%rdi
 101c12a:	mov    $0x1,%esi
 101c12f:	call   1012770 <myl_rc_record_failure>
 101c134:	xor    %eax,%eax
 101c136:	jmp    101c1af <myl_rc_storage_alloc+0x34f>
 101c138:	mov    %rbx,%rdi
 101c13b:	mov    %r14,%rsi
 101c13e:	call   10130fa <myl_rc_binding_find_slow>
 101c143:	test   %rax,%rax
 101c146:	jne    101bf7a <myl_rc_storage_alloc+0x11a>
 101c14c:	mov    %rbx,%rdi
 101c14f:	mov    %r14,%rsi
 101c152:	call   101d7b0 <myl_rc_native_shape>
 101c157:	test   %rax,%rax
 101c15a:	je     101c1ad <myl_rc_storage_alloc+0x34d>
 101c15c:	cmpq   $0x10,0x8(%r14)
 101c161:	ja     101c16e <myl_rc_storage_alloc+0x30e>
 101c163:	mov    (%r14),%rax
 101c166:	cmp    $0x1fe0,%rax
 101c16c:	jbe    101c1be <myl_rc_storage_alloc+0x35e>
 101c16e:	mov    %r14,-0x48(%rbp)
 101c172:	mov    %r15,-0x40(%rbp)
 101c176:	mov    %r12d,-0x38(%rbp)
 101c17a:	movl   $0x0,-0x34(%rbp)
 101c181:	movq   $0x0,-0x30(%rbp)
 101c189:	lea    -0x48(%rbp),%rsi
 101c18d:	lea    -0x30(%rbp),%rdx
 101c191:	mov    %rbx,%rdi
 101c194:	call   1012a30 <myl_rc_new>
 101c199:	test   %eax,%eax
 101c19b:	je     101c1a7 <myl_rc_storage_alloc+0x347>
 101c19d:	mov    %rbx,%rdi
 101c1a0:	mov    %eax,%esi
 101c1a2:	call   1012770 <myl_rc_record_failure>
 101c1a7:	mov    -0x30(%rbp),%rax
 101c1ab:	jmp    101c1af <myl_rc_storage_alloc+0x34f>
 101c1ad:	xor    %eax,%eax
 101c1af:	add    $0x28,%rsp
 101c1b3:	pop    %rbx
 101c1b4:	pop    %r12
 101c1b6:	pop    %r13
 101c1b8:	pop    %r14
 101c1ba:	pop    %r15
 101c1bc:	pop    %rbp
 101c1bd:	ret
 101c1be:	add    $0x2f,%rax
 101c1c2:	shr    $0x4,%rax
 101c1c6:	lea    -0x18e8d(%rip),%rcx        # 1003340 <class_of>
 101c1cd:	movzbl (%rax,%rcx,1),%r15d
 101c1d2:	mov    %rbx,%rdi
 101c1d5:	mov    %r14,%rsi
 101c1d8:	call   101c490 <myl_rc_binding_find>
 101c1dd:	mov    %r15,%rsi
 101c1e0:	mov    %esi,%ecx
 101c1e2:	inc    %ecx
 101c1e4:	mov    %ecx,0xc0(%rax)
 101c1ea:	jmp    101bf8a <myl_rc_storage_alloc+0x12a>
 101c1ef:	call   101267d <myl_rc_invariant_failed>
 101c1f4:	int3
 101c1f5:	int3
 101c1f6:	int3
 101c1f7:	int3
 101c1f8:	int3
 101c1f9:	int3
 101c1fa:	int3
 101c1fb:	int3
 101c1fc:	int3
 101c1fd:	int3
 101c1fe:	int3
 101c1ff:	int3

000000000101c200 <allocate>:
 101c200:	push   %rbp
 101c201:	mov    %rsp,%rbp
 101c204:	push   %r15
 101c206:	push   %r14
 101c208:	push   %r13
 101c20a:	push   %r12
 101c20c:	push   %rbx
 101c20d:	push   %rax
 101c20e:	mov    %rdx,%rbx
 101c211:	movq   $0x0,(%rdx)
 101c218:	mov    0x10(%rsi),%ecx
 101c21b:	mov    (%rsi),%r8
 101c21e:	test   %ecx,%ecx
 101c220:	je     101c24b <allocate+0x4b>
 101c222:	mov    0x8(%rsi),%rdx
 101c226:	mov    %r8,%rsi
 101c229:	call   1010660 <myl_native_arena_alloc>
 101c22e:	mov    %rax,%rcx
 101c231:	mov    %rax,(%rbx)
 101c234:	xor    %eax,%eax
 101c236:	test   %rcx,%rcx
 101c239:	sete   %al
 101c23c:	add    $0x8,%rsp
 101c240:	pop    %rbx
 101c241:	pop    %r12
 101c243:	pop    %r13
 101c245:	pop    %r14
 101c247:	pop    %r15
 101c249:	pop    %rbp
 101c24a:	ret
 101c24b:	mov    $0x1,%eax
 101c250:	test   %r8,%r8
 101c253:	je     101c23c <allocate+0x3c>
 101c255:	cmpq   $0x10,0x8(%r8)
 101c25a:	ja     101c23c <allocate+0x3c>
 101c25c:	mov    0x8(%rsi),%r9
 101c260:	mov    %r9,%rcx
 101c263:	shr    $0x3a,%rcx
 101c267:	jne    101c23c <allocate+0x3c>
 101c269:	mov    (%r8),%r14
 101c26c:	test   %r14,%r14
 101c26f:	je     101c28a <allocate+0x8a>
 101c271:	mov    $0xffffffffffffffdf,%rax
 101c278:	xor    %edx,%edx
 101c27a:	div    %r14
 101c27d:	mov    %rax,%rcx
 101c280:	mov    $0x1,%eax
 101c285:	cmp    %rcx,%r9
 101c288:	ja     101c23c <allocate+0x3c>
 101c28a:	test   %rdi,%rdi
 101c28d:	je     101c480 <allocate+0x280>
 101c293:	cmpq   $0x0,0x1608(%rdi)
 101c29b:	je     101c480 <allocate+0x280>
 101c2a1:	imul   %r9,%r14
 101c2a5:	lea    0x20(%r14),%r13
 101c2a9:	cmp    $0x2000,%r13
 101c2b0:	ja     101c2ec <allocate+0xec>
 101c2b2:	mov    %rsi,%r13
 101c2b5:	lea    0x2f(%r14),%rax
 101c2b9:	shr    $0x4,%rax
 101c2bd:	lea    -0x18f84(%rip),%rcx        # 1003340 <class_of>
 101c2c4:	movzbl (%rax,%rcx,1),%esi
 101c2c8:	mov    0x1610(%rdi,%rsi,8),%r15
 101c2d0:	test   %r15,%r15
 101c2d3:	je     101c36e <allocate+0x16e>
 101c2d9:	mov    (%r15),%rax
 101c2dc:	mov    %rdi,%r12
 101c2df:	mov    %rax,0x1610(%rdi,%rsi,8)
 101c2e7:	jmp    101c387 <allocate+0x187>
 101c2ec:	cmp    $0xffffffffffffffcf,%r13
 101c2f0:	ja     101c23c <allocate+0x3c>
 101c2f6:	mov    %rsi,-0x30(%rbp)
 101c2fa:	add    $0x50,%r14
 101c2fe:	mov    0x18(%rdi),%rax
 101c302:	mov    %rax,%rcx
 101c305:	add    %r14,%rcx
 101c308:	jb     101c32a <allocate+0x12a>
 101c30a:	mov    0x58(%rdi),%rcx
 101c30e:	test   %rcx,%rcx
 101c311:	je     101c39d <allocate+0x19d>
 101c317:	sub    %rax,%rcx
 101c31a:	setb   %al
 101c31d:	cmp    %rcx,%r14
 101c320:	seta   %cl
 101c323:	or     %al,%cl
 101c325:	cmp    $0x1,%cl
 101c328:	jne    101c39d <allocate+0x19d>
 101c32a:	mov    %rdi,%r15
 101c32d:	call   101cda0 <trim_empty>
 101c332:	mov    %r15,%rdi
 101c335:	mov    0x18(%r15),%rax
 101c339:	mov    %rax,%rcx
 101c33c:	add    %r14,%rcx
 101c33f:	jb     101c35d <allocate+0x15d>
 101c341:	mov    0x58(%rdi),%rcx
 101c345:	test   %rcx,%rcx
 101c348:	je     101c39d <allocate+0x19d>
 101c34a:	sub    %rax,%rcx
 101c34d:	setb   %al
 101c350:	cmp    %rcx,%r14
 101c353:	seta   %cl
 101c356:	or     %al,%cl
 101c358:	cmp    $0x1,%cl
 101c35b:	jne    101c39d <allocate+0x19d>
 101c35d:	movl   $0x1,0x6c(%rdi)
 101c364:	mov    $0x1,%eax
 101c369:	jmp    101c23c <allocate+0x3c>
 101c36e:	mov    %rdi,%r12
 101c371:	call   101cfa0 <slab_refill>
 101c376:	mov    %rax,%r15
 101c379:	mov    $0x1,%eax
 101c37e:	test   %r15,%r15
 101c381:	je     101c23c <allocate+0x3c>
 101c387:	lea    0x20(%r15),%rdi
 101c38b:	mov    %r14,%rsi
 101c38e:	call   101c4d0 <zero_payload>
 101c393:	xor    %ecx,%ecx
 101c395:	mov    %r13,%rax
 101c398:	jmp    101c437 <allocate+0x237>
 101c39d:	mov    %rdi,%r12
 101c3a0:	mov    %r14,%rdi
 101c3a3:	call   101cd20 <large_block>
 101c3a8:	test   %rax,%rax
 101c3ab:	je     101c3b2 <allocate+0x1b2>
 101c3ad:	mov    %rax,%r15
 101c3b0:	jmp    101c3d3 <allocate+0x1d3>
 101c3b2:	mov    %r12,%rdi
 101c3b5:	call   101cda0 <trim_empty>
 101c3ba:	mov    %r14,%rdi
 101c3bd:	call   101cd20 <large_block>
 101c3c2:	mov    %rax,%r15
 101c3c5:	test   %rax,%rax
 101c3c8:	mov    $0x1,%eax
 101c3cd:	je     101c23c <allocate+0x3c>
 101c3d3:	mov    0x1608(%r12),%rcx
 101c3db:	test   %rcx,%rcx
 101c3de:	mov    -0x30(%rbp),%rax
 101c3e2:	je     101c480 <allocate+0x280>
 101c3e8:	mov    0x20(%rcx),%rcx
 101c3ec:	mov    0x200(%rcx),%rdx
 101c3f3:	movq   $0x0,(%r15)
 101c3fa:	mov    %rdx,0x8(%r15)
 101c3fe:	mov    %r14,0x10(%r15)
 101c402:	mov    %r13,0x18(%r15)
 101c406:	movq   $0x0,0x28(%r15)
 101c40e:	test   %rdx,%rdx
 101c411:	je     101c416 <allocate+0x216>
 101c413:	mov    %r15,(%rdx)
 101c416:	mov    %r15,0x200(%rcx)
 101c41d:	add    %r14,0x18(%r12)
 101c422:	add    %r14,0x208(%rcx)
 101c429:	add    $0x30,%r15
 101c42d:	movabs $0x8000000000000000,%rcx
 101c437:	mov    (%rax),%rdx
 101c43a:	mov    0x8(%rax),%rax
 101c43e:	movq   $0x1,(%r15)
 101c445:	movq   $0x0,0x8(%r15)
 101c44d:	shl    $0x2,%rax
 101c451:	or     %rcx,%rax
 101c454:	mov    %rax,0x10(%r15)
 101c458:	mov    %rdx,0x18(%r15)
 101c45c:	vmovdqu 0x40(%r12),%xmm0
 101c463:	vpcmpeqd %xmm1,%xmm1,%xmm1
 101c467:	vpsubq %xmm1,%xmm0,%xmm0
 101c46b:	vmovdqu %xmm0,0x40(%r12)
 101c472:	add    $0x20,%r15
 101c476:	mov    %r15,(%rbx)
 101c479:	xor    %eax,%eax
 101c47b:	jmp    101c23c <allocate+0x3c>
 101c480:	call   101267d <myl_rc_invariant_failed>
 101c485:	int3
 101c486:	int3
 101c487:	int3
 101c488:	int3
 101c489:	int3
 101c48a:	int3
 101c48b:	int3
 101c48c:	int3
 101c48d:	int3
 101c48e:	int3
 101c48f:	int3

000000000101c490 <myl_rc_binding_find>:
 101c490:	mov    0x1608(%rdi),%rcx
 101c497:	mov    0x34(%rsi),%eax
 101c49a:	cmp    %rax,0xa0(%rcx)
 101c4a1:	jbe    101c4bc <myl_rc_binding_find+0x2c>
 101c4a3:	mov    0x98(%rcx),%rcx
 101c4aa:	shl    $0x4,%rax
 101c4ae:	cmp    %rsi,(%rcx,%rax,1)
 101c4b2:	jne    101c4bc <myl_rc_binding_find+0x2c>
 101c4b4:	add    %rax,%rcx
 101c4b7:	mov    0x8(%rcx),%rax
 101c4bb:	ret
 101c4bc:	push   %rbp
 101c4bd:	mov    %rsp,%rbp
 101c4c0:	call   10130fa <myl_rc_binding_find_slow>
 101c4c5:	pop    %rbp
 101c4c6:	ret
 101c4c7:	int3
 101c4c8:	int3
 101c4c9:	int3
 101c4ca:	int3
 101c4cb:	int3
 101c4cc:	int3
 101c4cd:	int3
 101c4ce:	int3
 101c4cf:	int3

000000000101c4d0 <zero_payload>:
 101c4d0:	push   %rbp
 101c4d1:	mov    %rsp,%rbp
 101c4d4:	lea    0xf(%rsi),%rax
 101c4d8:	shr    $0x4,%rax
 101c4dc:	cmp    $0x8,%rax
 101c4e0:	ja     101c53b <zero_payload+0x6b>
 101c4e2:	lea    -0x19361(%rip),%rcx        # 1003188 <myl_rc_map_sentinel+0xe8>
 101c4e9:	movslq (%rcx,%rax,4),%rax
 101c4ed:	add    %rcx,%rax
 101c4f0:	jmp    *%rax
 101c4f2:	vxorps %xmm0,%xmm0,%xmm0
 101c4f6:	vmovaps %xmm0,0x70(%rdi)
 101c4fb:	vxorps %xmm0,%xmm0,%xmm0
 101c4ff:	vmovaps %xmm0,0x60(%rdi)
 101c504:	vxorps %xmm0,%xmm0,%xmm0
 101c508:	vmovaps %xmm0,0x50(%rdi)
 101c50d:	vxorps %xmm0,%xmm0,%xmm0
 101c511:	vmovaps %xmm0,0x40(%rdi)
 101c516:	vxorps %xmm0,%xmm0,%xmm0
 101c51a:	vmovaps %xmm0,0x30(%rdi)
 101c51f:	vxorps %xmm0,%xmm0,%xmm0
 101c523:	vmovaps %xmm0,0x20(%rdi)
 101c528:	vxorps %xmm0,%xmm0,%xmm0
 101c52c:	vmovaps %xmm0,0x10(%rdi)
 101c531:	vxorps %xmm0,%xmm0,%xmm0
 101c535:	vmovaps %xmm0,(%rdi)
 101c539:	pop    %rbp
 101c53a:	ret
 101c53b:	mov    %rsi,%rdx
 101c53e:	xor    %esi,%esi
 101c540:	pop    %rbp
 101c541:	jmp    101e6b0 <compiler_rt.fastMemset>
 101c546:	int3
 101c547:	int3
 101c548:	int3
 101c549:	int3
 101c54a:	int3
 101c54b:	int3
 101c54c:	int3
 101c54d:	int3
 101c54e:	int3
 101c54f:	int3

000000000101c550 <myl_rc_storage_retire>:
 101c550:	push   %rbp
 101c551:	mov    %rsp,%rbp
 101c554:	cmpq   $0x0,-0x10(%rsi)
 101c559:	js     101c5bd <myl_rc_storage_retire+0x6d>
 101c55b:	mov    0x40(%rdi),%rcx
 101c55f:	test   %rcx,%rcx
 101c562:	je     101c639 <myl_rc_storage_retire+0xe9>
 101c568:	lea    -0x20(%rsi),%rax
 101c56c:	mov    0x50(%rdi),%rdx
 101c570:	cmp    $0xffffffffffffffff,%rdx
 101c574:	je     101c57d <myl_rc_storage_retire+0x2d>
 101c576:	inc    %rdx
 101c579:	mov    %rdx,0x50(%rdi)
 101c57d:	mov    %rax,%rdx
 101c580:	and    $0xffffffffffff0000,%rdx
 101c587:	dec    %rcx
 101c58a:	mov    %rcx,0x40(%rdi)
 101c58e:	movq   $0x3,-0x10(%rsi)
 101c596:	mov    (%rdx),%rcx
 101c599:	mov    0x1610(%rdi,%rcx,8),%rcx
 101c5a1:	mov    %rcx,-0x20(%rsi)
 101c5a5:	mov    (%rdx),%rcx
 101c5a8:	mov    %rax,0x1610(%rdi,%rcx,8)
 101c5b0:	mov    0x8(%rdx),%rax
 101c5b4:	add    %rax,0x1710(%rdi)
 101c5bb:	pop    %rbp
 101c5bc:	ret
 101c5bd:	mov    0x50(%rdi),%rax
 101c5c1:	cmp    $0xffffffffffffffff,%rax
 101c5c5:	je     101c5ce <myl_rc_storage_retire+0x7e>
 101c5c7:	inc    %rax
 101c5ca:	mov    %rax,0x50(%rdi)
 101c5ce:	decq   0x40(%rdi)
 101c5d2:	mov    -0x50(%rsi),%rax
 101c5d6:	test   %rax,%rax
 101c5d9:	je     101c617 <myl_rc_storage_retire+0xc7>
 101c5db:	mov    -0x48(%rsi),%rcx
 101c5df:	mov    %rcx,0x8(%rax)
 101c5e3:	test   %rcx,%rcx
 101c5e6:	je     101c5eb <myl_rc_storage_retire+0x9b>
 101c5e8:	mov    %rax,(%rcx)
 101c5eb:	mov    -0x40(%rsi),%rax
 101c5ef:	sub    %rax,0x18(%rdi)
 101c5f3:	mov    0x1608(%rdi),%rcx
 101c5fa:	test   %rcx,%rcx
 101c5fd:	je     101c639 <myl_rc_storage_retire+0xe9>
 101c5ff:	add    $0xffffffffffffffb0,%rsi
 101c603:	mov    0x20(%rcx),%rcx
 101c607:	sub    %rax,0x208(%rcx)
 101c60e:	mov    %rsi,%rdi
 101c611:	pop    %rbp
 101c612:	jmp    101c640 <large_release>
 101c617:	mov    0x1608(%rdi),%rdx
 101c61e:	test   %rdx,%rdx
 101c621:	je     101c639 <myl_rc_storage_retire+0xe9>
 101c623:	mov    -0x48(%rsi),%rcx
 101c627:	mov    0x20(%rdx),%rdx
 101c62b:	mov    %rcx,0x200(%rdx)
 101c632:	test   %rcx,%rcx
 101c635:	jne    101c5e8 <myl_rc_storage_retire+0x98>
 101c637:	jmp    101c5eb <myl_rc_storage_retire+0x9b>
 101c639:	call   101267d <myl_rc_invariant_failed>
 101c63e:	int3
 101c63f:	int3

000000000101c640 <large_release>:
 101c640:	push   %rbp
 101c641:	mov    %rsp,%rbp
 101c644:	mov    0x20(%rdi),%rsi
 101c648:	test   %rsi,%rsi
 101c64b:	je     101c653 <large_release+0x13>
 101c64d:	pop    %rbp
 101c64e:	jmp    101f140 <munmap@plt>
 101c653:	pop    %rbp
 101c654:	jmp    101efd0 <free@plt>
 101c659:	int3
 101c65a:	int3
 101c65b:	int3
 101c65c:	int3
 101c65d:	int3
 101c65e:	int3
 101c65f:	int3

000000000101c660 <release_extents>:
 101c660:	push   %rbp
 101c661:	mov    %rsp,%rbp
 101c664:	push   %r15
 101c666:	push   %r14
 101c668:	push   %r13
 101c66a:	push   %r12
 101c66c:	push   %rbx
 101c66d:	push   %rax
 101c66e:	mov    0x1608(%rdi),%rax
 101c675:	cmpl   $0x0,0xd0(%rax)
 101c67c:	jne    101c7f6 <release_extents+0x196>
 101c682:	cmpq   $0x0,0xc0(%rax)
 101c68a:	jne    101c7f6 <release_extents+0x196>
 101c690:	mov    %rdi,%rbx
 101c693:	mov    0x20(%rax),%r14
 101c697:	xor    %eax,%eax
 101c699:	jmp    101c6b5 <release_extents+0x55>
 101c69b:	nopl   0x0(%rax,%rax,1)
 101c6a0:	movq   $0x0,0x1610(%rbx,%rax,8)
 101c6ac:	inc    %rax
 101c6af:	cmp    $0x20,%rax
 101c6b3:	je     101c6e8 <release_extents+0x88>
 101c6b5:	mov    0x1610(%rbx,%rax,8),%rcx
 101c6bd:	test   %rcx,%rcx
 101c6c0:	je     101c6a0 <release_extents+0x40>
 101c6c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c6d0:	mov    %rcx,%rdx
 101c6d3:	and    $0xffffffffffff0000,%rdx
 101c6da:	decq   0x38(%rdx)
 101c6de:	mov    (%rcx),%rcx
 101c6e1:	test   %rcx,%rcx
 101c6e4:	jne    101c6d0 <release_extents+0x70>
 101c6e6:	jmp    101c6a0 <release_extents+0x40>
 101c6e8:	movq   $0x0,0x1710(%rbx)
 101c6f3:	mov    0x200(%r14),%rdi
 101c6fa:	xor    %r15d,%r15d
 101c6fd:	test   %rdi,%rdi
 101c700:	je     101c752 <release_extents+0xf2>
 101c702:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101c710:	mov    0x8(%rdi),%rax
 101c714:	mov    %rax,0x200(%r14)
 101c71b:	mov    0x10(%rdi),%rax
 101c71f:	sub    %rax,0x18(%rbx)
 101c723:	mov    0x1608(%rbx),%rcx
 101c72a:	test   %rcx,%rcx
 101c72d:	je     101c7f6 <release_extents+0x196>
 101c733:	mov    0x20(%rcx),%rcx
 101c737:	sub    %rax,0x208(%rcx)
 101c73e:	call   101c640 <large_release>
 101c743:	inc    %r15
 101c746:	mov    0x200(%r14),%rdi
 101c74d:	test   %rdi,%rdi
 101c750:	jne    101c710 <release_extents+0xb0>
 101c752:	xor    %r12d,%r12d
 101c755:	jmp    101c769 <release_extents+0x109>
 101c757:	nopw   0x0(%rax,%rax,1)
 101c760:	inc    %r12
 101c763:	cmp    $0x20,%r12
 101c767:	je     101c79f <release_extents+0x13f>
 101c769:	mov    %r12,%r13
 101c76c:	shl    $0x4,%r13
 101c770:	mov    (%r14,%r13,1),%rsi
 101c774:	test   %rsi,%rsi
 101c777:	je     101c760 <release_extents+0x100>
 101c779:	add    %r14,%r13
 101c77c:	nopl   0x0(%rax)
 101c780:	add    0x38(%rsi),%r15
 101c784:	movq   $0x0,0x38(%rsi)
 101c78c:	mov    %rbx,%rdi
 101c78f:	call   101ce90 <slab_free>
 101c794:	mov    0x0(%r13),%rsi
 101c798:	test   %rsi,%rsi
 101c79b:	jne    101c780 <release_extents+0x120>
 101c79d:	jmp    101c760 <release_extents+0x100>
 101c79f:	mov    0x40(%rbx),%rax
 101c7a3:	sub    %r15,%rax
 101c7a6:	jb     101c7f6 <release_extents+0x196>
 101c7a8:	mov    0x440(%r14),%rcx
 101c7af:	lea    0x458(,%rcx,8),%rcx
 101c7b7:	cmp    %rcx,0x208(%r14)
 101c7be:	jne    101c7f6 <release_extents+0x196>
 101c7c0:	mov    %rax,0x40(%rbx)
 101c7c4:	mov    0x1608(%rbx),%rax
 101c7cb:	movq   $0x0,0xc8(%rax)
 101c7d6:	mov    0x50(%rbx),%rax
 101c7da:	cmp    $0xffffffffffffffff,%rax
 101c7de:	je     101c7e7 <release_extents+0x187>
 101c7e0:	inc    %rax
 101c7e3:	mov    %rax,0x50(%rbx)
 101c7e7:	add    $0x8,%rsp
 101c7eb:	pop    %rbx
 101c7ec:	pop    %r12
 101c7ee:	pop    %r13
 101c7f0:	pop    %r14
 101c7f2:	pop    %r15
 101c7f4:	pop    %rbp
 101c7f5:	ret
 101c7f6:	call   101267d <myl_rc_invariant_failed>
 101c7fb:	int3
 101c7fc:	int3
 101c7fd:	int3
 101c7fe:	int3
 101c7ff:	int3

000000000101c800 <myl_rc_storage_init>:
 101c800:	push   %rbp
 101c801:	mov    %rsp,%rbp
 101c804:	push   %r15
 101c806:	push   %r14
 101c808:	push   %rbx
 101c809:	push   %rax
 101c80a:	mov    %rdi,%rbx
 101c80d:	mov    0x18(%rdi),%r15
 101c811:	cmp    $0xfffffffffffffba7,%r15
 101c818:	ja     101c838 <myl_rc_storage_init+0x38>
 101c81a:	mov    0x58(%rbx),%rax
 101c81e:	test   %rax,%rax
 101c821:	je     101c846 <myl_rc_storage_init+0x46>
 101c823:	sub    %r15,%rax
 101c826:	setb   %cl
 101c829:	cmp    $0x458,%rax
 101c82f:	setb   %al
 101c832:	or     %cl,%al
 101c834:	cmp    $0x1,%al
 101c836:	jne    101c846 <myl_rc_storage_init+0x46>
 101c838:	movl   $0x1,0x6c(%rbx)
 101c83f:	mov    $0x1,%eax
 101c844:	jmp    101c8c3 <myl_rc_storage_init+0xc3>
 101c846:	mov    $0x1,%edi
 101c84b:	mov    $0x458,%esi
 101c850:	call   101ef80 <calloc@plt>
 101c855:	test   %rax,%rax
 101c858:	je     101c89d <myl_rc_storage_init+0x9d>
 101c85a:	mov    %rax,%r14
 101c85d:	add    $0x458,%r15
 101c864:	mov    %r15,0x18(%rbx)
 101c868:	movq   $0x458,0x208(%rax)
 101c873:	lea    0xcac6(%rip),%rsi        # 1029340 <allocator>
 101c87a:	mov    %rbx,%rdi
 101c87d:	mov    %rax,%rdx
 101c880:	call   10127d0 <myl_rc_heap_init>
 101c885:	test   %eax,%eax
 101c887:	je     101c8a4 <myl_rc_storage_init+0xa4>
 101c889:	addq   $0xfffffffffffffba8,0x18(%rbx)
 101c891:	mov    %r14,%rdi
 101c894:	mov    %eax,%ebx
 101c896:	call   101efd0 <free@plt>
 101c89b:	jmp    101c8c1 <myl_rc_storage_init+0xc1>
 101c89d:	mov    $0x1,%eax
 101c8a2:	jmp    101c8c3 <myl_rc_storage_init+0xc3>
 101c8a4:	lea    0xcaf5(%rip),%rsi        # 10293a0 <raw_module>
 101c8ab:	mov    %rbx,%rdi
 101c8ae:	call   1013620 <myl_rc_module_register>
 101c8b3:	test   %eax,%eax
 101c8b5:	je     101c8ce <myl_rc_storage_init+0xce>
 101c8b7:	mov    %rbx,%rdi
 101c8ba:	mov    %eax,%ebx
 101c8bc:	call   10128a0 <myl_rc_heap_destroy>
 101c8c1:	mov    %ebx,%eax
 101c8c3:	add    $0x8,%rsp
 101c8c7:	pop    %rbx
 101c8c8:	pop    %r14
 101c8ca:	pop    %r15
 101c8cc:	pop    %rbp
 101c8cd:	ret
 101c8ce:	xor    %eax,%eax
 101c8d0:	jmp    101c8c3 <myl_rc_storage_init+0xc3>
 101c8d2:	int3
 101c8d3:	int3
 101c8d4:	int3
 101c8d5:	int3
 101c8d6:	int3
 101c8d7:	int3
 101c8d8:	int3
 101c8d9:	int3
 101c8da:	int3
 101c8db:	int3
 101c8dc:	int3
 101c8dd:	int3
 101c8de:	int3
 101c8df:	int3

000000000101c8e0 <myl_rc_storage_bytes>:
 101c8e0:	push   %rbp
 101c8e1:	mov    %rsp,%rbp
 101c8e4:	mov    $0x1,%ecx
 101c8e9:	pop    %rbp
 101c8ea:	jmp    101c8f0 <raw_bytes>
 101c8ef:	int3

000000000101c8f0 <raw_bytes>:
 101c8f0:	push   %rbp
 101c8f1:	mov    %rsp,%rbp
 101c8f4:	push   %r15
 101c8f6:	push   %r14
 101c8f8:	push   %rbx
 101c8f9:	sub    $0x28,%rsp
 101c8fd:	test   %rdi,%rdi
 101c900:	je     101caad <raw_bytes+0x1bd>
 101c906:	mov    %rdi,%rbx
 101c909:	mov    0x1608(%rdi),%rax
 101c910:	test   %rax,%rax
 101c913:	je     101caad <raw_bytes+0x1bd>
 101c919:	test   %edx,%edx
 101c91b:	je     101c96b <raw_bytes+0x7b>
 101c91d:	movq   $0x0,-0x20(%rbp)
 101c925:	lea    -0x193e4(%rip),%rax        # 1003548 <raw_type>
 101c92c:	mov    %rax,-0x38(%rbp)
 101c930:	mov    %rsi,-0x30(%rbp)
 101c934:	mov    %edx,-0x28(%rbp)
 101c937:	movl   $0x0,-0x24(%rbp)
 101c93e:	lea    -0x38(%rbp),%rsi
 101c942:	lea    -0x20(%rbp),%rdx
 101c946:	mov    %rbx,%rdi
 101c949:	call   1012a30 <myl_rc_new>
 101c94e:	test   %eax,%eax
 101c950:	je     101c95c <raw_bytes+0x6c>
 101c952:	mov    %rbx,%rdi
 101c955:	mov    %eax,%esi
 101c957:	call   1012770 <myl_rc_record_failure>
 101c95c:	mov    -0x20(%rbp),%rax
 101c960:	add    $0x28,%rsp
 101c964:	pop    %rbx
 101c965:	pop    %r14
 101c967:	pop    %r15
 101c969:	pop    %rbp
 101c96a:	ret
 101c96b:	cmp    $0x1fe0,%rsi
 101c972:	ja     101c91d <raw_bytes+0x2d>
 101c974:	lea    -0x77b(%rip),%rdi        # 101c200 <allocate>
 101c97b:	cmp    %rdi,(%rax)
 101c97e:	jne    101c91d <raw_bytes+0x2d>
 101c980:	lea    0x2f(%rsi),%rax
 101c984:	shr    $0x4,%rax
 101c988:	lea    -0x1964f(%rip),%rdx        # 1003340 <class_of>
 101c98f:	movzbl (%rax,%rdx,1),%edx
 101c993:	mov    0x1610(%rbx,%rdx,8),%rax
 101c99b:	test   %rax,%rax
 101c99e:	je     101c9ad <raw_bytes+0xbd>
 101c9a0:	mov    (%rax),%rdi
 101c9a3:	mov    %rdi,0x1610(%rbx,%rdx,8)
 101c9ab:	jmp    101c9cd <raw_bytes+0xdd>
 101c9ad:	mov    %rbx,%rdi
 101c9b0:	mov    %rsi,%r14
 101c9b3:	mov    %rdx,%rsi
 101c9b6:	mov    %ecx,%r15d
 101c9b9:	call   101cfa0 <slab_refill>
 101c9be:	mov    %r15d,%ecx
 101c9c1:	mov    %r14,%rsi
 101c9c4:	test   %rax,%rax
 101c9c7:	je     101ca81 <raw_bytes+0x191>
 101c9cd:	test   %ecx,%ecx
 101c9cf:	je     101ca44 <raw_bytes+0x154>
 101c9d1:	lea    0x20(%rax),%rdi
 101c9d5:	lea    0xf(%rsi),%rcx
 101c9d9:	shr    $0x4,%rcx
 101c9dd:	cmp    $0x8,%rcx
 101c9e1:	ja     101ca95 <raw_bytes+0x1a5>
 101c9e7:	lea    -0x19842(%rip),%rdx        # 10031ac <myl_rc_map_sentinel+0x10c>
 101c9ee:	movslq (%rdx,%rcx,4),%rcx
 101c9f2:	add    %rdx,%rcx
 101c9f5:	jmp    *%rcx
 101c9f7:	vxorps %xmm0,%xmm0,%xmm0
 101c9fb:	vmovaps %xmm0,0x90(%rax)
 101ca03:	vxorps %xmm0,%xmm0,%xmm0
 101ca07:	vmovaps %xmm0,0x80(%rax)
 101ca0f:	vxorps %xmm0,%xmm0,%xmm0
 101ca13:	vmovaps %xmm0,0x70(%rax)
 101ca18:	vxorps %xmm0,%xmm0,%xmm0
 101ca1c:	vmovaps %xmm0,0x60(%rax)
 101ca21:	vxorps %xmm0,%xmm0,%xmm0
 101ca25:	vmovaps %xmm0,0x50(%rax)
 101ca2a:	vxorps %xmm0,%xmm0,%xmm0
 101ca2e:	vmovaps %xmm0,0x40(%rax)
 101ca33:	vxorps %xmm0,%xmm0,%xmm0
 101ca37:	vmovaps %xmm0,0x30(%rax)
 101ca3c:	vxorps %xmm0,%xmm0,%xmm0
 101ca40:	vmovaps %xmm0,(%rdi)
 101ca44:	movq   $0x1,(%rax)
 101ca4b:	movq   $0x0,0x8(%rax)
 101ca53:	shl    $0x2,%rsi
 101ca57:	mov    %rsi,0x10(%rax)
 101ca5b:	lea    -0x1951a(%rip),%rcx        # 1003548 <raw_type>
 101ca62:	mov    %rcx,0x18(%rax)
 101ca66:	vmovdqu 0x40(%rbx),%xmm0
 101ca6b:	vpcmpeqd %xmm1,%xmm1,%xmm1
 101ca6f:	vpsubq %xmm1,%xmm0,%xmm0
 101ca73:	vmovdqu %xmm0,0x40(%rbx)
 101ca78:	add    $0x20,%rax
 101ca7c:	jmp    101c960 <raw_bytes+0x70>
 101ca81:	mov    %rbx,%rdi
 101ca84:	mov    $0x1,%esi
 101ca89:	call   1012770 <myl_rc_record_failure>
 101ca8e:	xor    %eax,%eax
 101ca90:	jmp    101c960 <raw_bytes+0x70>
 101ca95:	mov    %rsi,%r14
 101ca98:	xor    %esi,%esi
 101ca9a:	mov    %r14,%rdx
 101ca9d:	mov    %rax,%r15
 101caa0:	call   101e6b0 <compiler_rt.fastMemset>
 101caa5:	mov    %r15,%rax
 101caa8:	mov    %r14,%rsi
 101caab:	jmp    101ca44 <raw_bytes+0x154>
 101caad:	call   101267d <myl_rc_invariant_failed>
 101cab2:	int3
 101cab3:	int3
 101cab4:	int3
 101cab5:	int3
 101cab6:	int3
 101cab7:	int3
 101cab8:	int3
 101cab9:	int3
 101caba:	int3
 101cabb:	int3
 101cabc:	int3
 101cabd:	int3
 101cabe:	int3
 101cabf:	int3

000000000101cac0 <myl_rc_storage_block>:
 101cac0:	push   %rbp
 101cac1:	mov    %rsp,%rbp
 101cac4:	xor    %ecx,%ecx
 101cac6:	pop    %rbp
 101cac7:	jmp    101c8f0 <raw_bytes>
 101cacc:	int3
 101cacd:	int3
 101cace:	int3
 101cacf:	int3

000000000101cad0 <myl_rc_storage_extend>:
 101cad0:	push   %rbp
 101cad1:	mov    %rsp,%rbp
 101cad4:	mov    $0x1,%ecx
 101cad9:	pop    %rbp
 101cada:	jmp    101cae0 <storage_extend>
 101cadf:	int3

000000000101cae0 <storage_extend>:
 101cae0:	push   %rbp
 101cae1:	mov    %rsp,%rbp
 101cae4:	push   %r15
 101cae6:	push   %r14
 101cae8:	push   %r13
 101caea:	push   %r12
 101caec:	push   %rbx
 101caed:	sub    $0x18,%rsp
 101caf1:	test   %rsi,%rsi
 101caf4:	je     101cbf3 <storage_extend+0x113>
 101cafa:	mov    -0x10(%rsi),%rax
 101cafe:	movabs $0xc000000000000003,%r8
 101cb08:	and    %rax,%r8
 101cb0b:	neg    %r8
 101cb0e:	jno    101cbf3 <storage_extend+0x113>
 101cb14:	cmpq   $0x1,-0x20(%rsi)
 101cb19:	jne    101cbf3 <storage_extend+0x113>
 101cb1f:	cmpq   $0x0,-0x18(%rsi)
 101cb24:	jne    101cbf3 <storage_extend+0x113>
 101cb2a:	movabs $0x1000000000000000,%r8
 101cb34:	and    %r8,%rax
 101cb37:	mov    %rdx,%r8
 101cb3a:	shr    $0x3a,%r8
 101cb3e:	or     %rax,%r8
 101cb41:	jne    101cbf3 <storage_extend+0x113>
 101cb47:	mov    -0x8(%rsi),%rax
 101cb4b:	mov    (%rax),%rbx
 101cb4e:	test   %rbx,%rbx
 101cb51:	je     101cbf3 <storage_extend+0x113>
 101cb57:	mov    $0xffffffffffffffaf,%rax
 101cb5e:	mov    %rdx,%r13
 101cb61:	xor    %edx,%edx
 101cb63:	div    %rbx
 101cb66:	mov    %rax,%rdx
 101cb69:	xor    %eax,%eax
 101cb6b:	cmp    %rdx,%r13
 101cb6e:	ja     101cbf5 <storage_extend+0x115>
 101cb74:	imul   %r13,%rbx
 101cb78:	lea    0x20(%rbx),%r12
 101cb7c:	cmp    -0x38(%rsi),%r12
 101cb80:	jbe    101cbf3 <storage_extend+0x113>
 101cb82:	mov    %ecx,-0x2c(%rbp)
 101cb85:	add    $0x50,%rbx
 101cb89:	mov    %rbx,%r14
 101cb8c:	mov    %rsi,%r15
 101cb8f:	sub    -0x40(%rsi),%r14
 101cb93:	mov    %rdi,-0x38(%rbp)
 101cb97:	mov    %r14,%rsi
 101cb9a:	call   101cca0 <reserve>
 101cb9f:	test   %eax,%eax
 101cba1:	je     101cbf3 <storage_extend+0x113>
 101cba3:	mov    %r15,%rdi
 101cba6:	mov    -0x40(%r15),%r15
 101cbaa:	add    $0xffffffffffffffb0,%rdi
 101cbae:	mov    %r15,%rsi
 101cbb1:	mov    %rbx,%rdx
 101cbb4:	call   101d6f0 <large_grow>
 101cbb9:	test   %rax,%rax
 101cbbc:	je     101cbf3 <storage_extend+0x113>
 101cbbe:	cmpl   $0x0,-0x2c(%rbp)
 101cbc2:	je     101cbe1 <storage_extend+0x101>
 101cbc4:	cmpq   $0x0,0x20(%rax)
 101cbc9:	jne    101cbe1 <storage_extend+0x101>
 101cbcb:	add    %rax,%r15
 101cbce:	mov    %r15,%rdi
 101cbd1:	xor    %esi,%esi
 101cbd3:	mov    %r14,%rdx
 101cbd6:	mov    %rax,%r15
 101cbd9:	call   101e6b0 <compiler_rt.fastMemset>
 101cbde:	mov    %r15,%rax
 101cbe1:	mov    (%rax),%rcx
 101cbe4:	test   %rcx,%rcx
 101cbe7:	je     101cc04 <storage_extend+0x124>
 101cbe9:	mov    %rax,0x8(%rcx)
 101cbed:	mov    -0x38(%rbp),%rcx
 101cbf1:	jmp    101cc24 <storage_extend+0x144>
 101cbf3:	xor    %eax,%eax
 101cbf5:	add    $0x18,%rsp
 101cbf9:	pop    %rbx
 101cbfa:	pop    %r12
 101cbfc:	pop    %r13
 101cbfe:	pop    %r14
 101cc00:	pop    %r15
 101cc02:	pop    %rbp
 101cc03:	ret
 101cc04:	mov    -0x38(%rbp),%rcx
 101cc08:	test   %rcx,%rcx
 101cc0b:	je     101cc83 <storage_extend+0x1a3>
 101cc0d:	mov    0x1608(%rcx),%rdx
 101cc14:	test   %rdx,%rdx
 101cc17:	je     101cc83 <storage_extend+0x1a3>
 101cc19:	mov    0x20(%rdx),%rdx
 101cc1d:	mov    %rax,0x200(%rdx)
 101cc24:	mov    0x8(%rax),%rdx
 101cc28:	test   %rdx,%rdx
 101cc2b:	je     101cc30 <storage_extend+0x150>
 101cc2d:	mov    %rax,(%rdx)
 101cc30:	mov    %rbx,0x10(%rax)
 101cc34:	mov    %r12,0x18(%rax)
 101cc38:	movabs $0xf000000000000003,%rdx
 101cc42:	and    0x40(%rax),%rdx
 101cc46:	lea    (%rdx,%r13,4),%rdx
 101cc4a:	mov    %rdx,0x40(%rax)
 101cc4e:	add    %r14,0x18(%rcx)
 101cc52:	mov    0x1608(%rcx),%rdx
 101cc59:	test   %rdx,%rdx
 101cc5c:	je     101cc83 <storage_extend+0x1a3>
 101cc5e:	mov    0x20(%rdx),%rdx
 101cc62:	add    %r14,0x208(%rdx)
 101cc69:	mov    0x50(%rcx),%rdx
 101cc6d:	cmp    $0xffffffffffffffff,%rdx
 101cc71:	je     101cc7a <storage_extend+0x19a>
 101cc73:	inc    %rdx
 101cc76:	mov    %rdx,0x50(%rcx)
 101cc7a:	add    $0x50,%rax
 101cc7e:	jmp    101cbf5 <storage_extend+0x115>
 101cc83:	call   101267d <myl_rc_invariant_failed>
 101cc88:	int3
 101cc89:	int3
 101cc8a:	int3
 101cc8b:	int3
 101cc8c:	int3
 101cc8d:	int3
 101cc8e:	int3
 101cc8f:	int3

000000000101cc90 <myl_rc_storage_extend_opaque>:
 101cc90:	push   %rbp
 101cc91:	mov    %rsp,%rbp
 101cc94:	xor    %ecx,%ecx
 101cc96:	pop    %rbp
 101cc97:	jmp    101cae0 <storage_extend>
 101cc9c:	int3
 101cc9d:	int3
 101cc9e:	int3
 101cc9f:	int3

000000000101cca0 <reserve>:
 101cca0:	push   %rbp
 101cca1:	mov    %rsp,%rbp
 101cca4:	push   %r14
 101cca6:	push   %rbx
 101cca7:	mov    %rsi,%r14
 101ccaa:	mov    %rdi,%rbx
 101ccad:	mov    0x18(%rdi),%rcx
 101ccb1:	mov    %rcx,%rax
 101ccb4:	add    %rsi,%rax
 101ccb7:	jb     101ccda <reserve+0x3a>
 101ccb9:	mov    0x58(%rbx),%rdx
 101ccbd:	mov    $0x1,%eax
 101ccc2:	test   %rdx,%rdx
 101ccc5:	je     101cd18 <reserve+0x78>
 101ccc7:	sub    %rcx,%rdx
 101ccca:	setb   %cl
 101cccd:	cmp    %rdx,%r14
 101ccd0:	seta   %dl
 101ccd3:	or     %cl,%dl
 101ccd5:	cmp    $0x1,%dl
 101ccd8:	jne    101cd18 <reserve+0x78>
 101ccda:	mov    %rbx,%rdi
 101ccdd:	call   101cda0 <trim_empty>
 101cce2:	mov    0x18(%rbx),%rcx
 101cce6:	mov    %rcx,%rax
 101cce9:	add    %r14,%rax
 101ccec:	jb     101cd0f <reserve+0x6f>
 101ccee:	mov    0x58(%rbx),%rdx
 101ccf2:	mov    $0x1,%eax
 101ccf7:	test   %rdx,%rdx
 101ccfa:	je     101cd18 <reserve+0x78>
 101ccfc:	sub    %rcx,%rdx
 101ccff:	setb   %cl
 101cd02:	cmp    %rdx,%r14
 101cd05:	seta   %dl
 101cd08:	or     %cl,%dl
 101cd0a:	cmp    $0x1,%dl
 101cd0d:	jne    101cd18 <reserve+0x78>
 101cd0f:	movl   $0x1,0x6c(%rbx)
 101cd16:	xor    %eax,%eax
 101cd18:	pop    %rbx
 101cd19:	pop    %r14
 101cd1b:	pop    %rbp
 101cd1c:	ret
 101cd1d:	int3
 101cd1e:	int3
 101cd1f:	int3

000000000101cd20 <large_block>:
 101cd20:	push   %rbp
 101cd21:	mov    %rsp,%rbp
 101cd24:	push   %r14
 101cd26:	push   %rbx
 101cd27:	mov    %rdi,%rbx
 101cd2a:	cmp    $0x1ffff,%rdi
 101cd31:	ja     101cd44 <large_block+0x24>
 101cd33:	mov    $0x1,%edi
 101cd38:	mov    %rbx,%rsi
 101cd3b:	pop    %rbx
 101cd3c:	pop    %r14
 101cd3e:	pop    %rbp
 101cd3f:	jmp    101ef80 <calloc@plt>
 101cd44:	cmp    $0xffffffffffffefff,%rbx
 101cd4b:	jbe    101cd52 <large_block+0x32>
 101cd4d:	xor    %r14d,%r14d
 101cd50:	jmp    101cd8d <large_block+0x6d>
 101cd52:	add    $0xfff,%rbx
 101cd59:	and    $0xfffffffffffff000,%rbx
 101cd60:	xor    %r14d,%r14d
 101cd63:	xor    %edi,%edi
 101cd65:	mov    %rbx,%rsi
 101cd68:	mov    $0x3,%edx
 101cd6d:	mov    $0x22,%ecx
 101cd72:	mov    $0xffffffff,%r8d
 101cd78:	xor    %r9d,%r9d
 101cd7b:	call   101f0f0 <mmap@plt>
 101cd80:	cmp    $0xffffffffffffffff,%rax
 101cd84:	je     101cd8d <large_block+0x6d>
 101cd86:	mov    %rbx,0x20(%rax)
 101cd8a:	mov    %rax,%r14
 101cd8d:	mov    %r14,%rax
 101cd90:	pop    %rbx
 101cd91:	pop    %r14
 101cd93:	pop    %rbp
 101cd94:	ret
 101cd95:	int3
 101cd96:	int3
 101cd97:	int3
 101cd98:	int3
 101cd99:	int3
 101cd9a:	int3
 101cd9b:	int3
 101cd9c:	int3
 101cd9d:	int3
 101cd9e:	int3
 101cd9f:	int3

000000000101cda0 <trim_empty>:
 101cda0:	push   %rbp
 101cda1:	mov    %rsp,%rbp
 101cda4:	push   %r15
 101cda6:	push   %r14
 101cda8:	push   %r12
 101cdaa:	push   %rbx
 101cdab:	test   %rdi,%rdi
 101cdae:	je     101ce8b <trim_empty+0xeb>
 101cdb4:	mov    %rdi,%rbx
 101cdb7:	xor    %r14d,%r14d
 101cdba:	jmp    101cdcd <trim_empty+0x2d>
 101cdbc:	nopl   0x0(%rax)
 101cdc0:	inc    %r14
 101cdc3:	cmp    $0x20,%r14
 101cdc7:	je     101ce77 <trim_empty+0xd7>
 101cdcd:	mov    0x1608(%rbx),%rax
 101cdd4:	test   %rax,%rax
 101cdd7:	je     101ce8b <trim_empty+0xeb>
 101cddd:	mov    0x20(%rax),%r15
 101cde1:	mov    0x1610(%rbx,%r14,8),%rax
 101cde9:	movq   $0x0,0x1610(%rbx,%r14,8)
 101cdf5:	test   %rax,%rax
 101cdf8:	je     101cdc0 <trim_empty+0x20>
 101cdfa:	mov    %r14,%rcx
 101cdfd:	shl    $0x4,%rcx
 101ce01:	add    %rcx,%r15
 101ce04:	jmp    101ce18 <trim_empty+0x78>
 101ce06:	cs nopw 0x0(%rax,%rax,1)
 101ce10:	mov    %r12,%rax
 101ce13:	test   %r12,%r12
 101ce16:	je     101cdc0 <trim_empty+0x20>
 101ce18:	mov    (%rax),%r12
 101ce1b:	mov    %rax,%rsi
 101ce1e:	and    $0xffffffffffff0000,%rsi
 101ce25:	mov    0x48(%rsi),%rcx
 101ce29:	test   %rcx,%rcx
 101ce2c:	jne    101ce60 <trim_empty+0xc0>
 101ce2e:	mov    0x30(%rsi),%rdx
 101ce32:	cmp    0x40(%rsi),%rdx
 101ce36:	jne    101ce60 <trim_empty+0xc0>
 101ce38:	mov    0x8(%r15),%rcx
 101ce3c:	movq   $0x0,0x20(%rsi)
 101ce44:	mov    %rcx,0x28(%rsi)
 101ce48:	mov    0x8(%r15),%rcx
 101ce4c:	test   %rcx,%rcx
 101ce4f:	je     101ce55 <trim_empty+0xb5>
 101ce51:	mov    %rsi,0x20(%rcx)
 101ce55:	mov    %rsi,0x8(%r15)
 101ce59:	mov    0x48(%rsi),%rcx
 101ce5d:	nopl   (%rax)
 101ce60:	mov    %rcx,(%rax)
 101ce63:	mov    %rax,0x48(%rsi)
 101ce67:	decq   0x38(%rsi)
 101ce6b:	jne    101ce10 <trim_empty+0x70>
 101ce6d:	mov    %rbx,%rdi
 101ce70:	call   101ce90 <slab_free>
 101ce75:	jmp    101ce10 <trim_empty+0x70>
 101ce77:	movq   $0x0,0x1710(%rbx)
 101ce82:	pop    %rbx
 101ce83:	pop    %r12
 101ce85:	pop    %r14
 101ce87:	pop    %r15
 101ce89:	pop    %rbp
 101ce8a:	ret
 101ce8b:	call   101267d <myl_rc_invariant_failed>

000000000101ce90 <slab_free>:
 101ce90:	push   %rbp
 101ce91:	mov    %rsp,%rbp
 101ce94:	push   %r14
 101ce96:	push   %rbx
 101ce97:	test   %rdi,%rdi
 101ce9a:	je     101cf90 <slab_free+0x100>
 101cea0:	mov    0x1608(%rdi),%rcx
 101cea7:	test   %rcx,%rcx
 101ceaa:	je     101cf90 <slab_free+0x100>
 101ceb0:	mov    %rsi,%rbx
 101ceb3:	mov    (%rsi),%rax
 101ceb6:	shl    $0x4,%rax
 101ceba:	add    0x20(%rcx),%rax
 101cebe:	cmpq   $0x0,0x48(%rsi)
 101cec3:	jne    101cecf <slab_free+0x3f>
 101cec5:	mov    0x30(%rbx),%rcx
 101cec9:	cmp    0x40(%rbx),%rcx
 101cecd:	je     101cefb <slab_free+0x6b>
 101cecf:	mov    0x20(%rbx),%rcx
 101ced3:	mov    0x28(%rbx),%rdx
 101ced7:	test   %rcx,%rcx
 101ceda:	je     101cee2 <slab_free+0x52>
 101cedc:	mov    %rdx,0x28(%rcx)
 101cee0:	jmp    101cee6 <slab_free+0x56>
 101cee2:	mov    %rdx,0x8(%rax)
 101cee6:	lea    0x20(%rbx),%rsi
 101ceea:	test   %rdx,%rdx
 101ceed:	je     101cef3 <slab_free+0x63>
 101ceef:	mov    %rcx,0x20(%rdx)
 101cef3:	vxorps %xmm0,%xmm0,%xmm0
 101cef7:	vmovups %xmm0,(%rsi)
 101cefb:	mov    0x10(%rbx),%rdx
 101ceff:	mov    0x18(%rbx),%rcx
 101cf03:	test   %rdx,%rdx
 101cf06:	je     101cf86 <slab_free+0xf6>
 101cf08:	mov    %rcx,0x18(%rdx)
 101cf0c:	test   %rcx,%rcx
 101cf0f:	je     101cf19 <slab_free+0x89>
 101cf11:	mov    0x10(%rbx),%rax
 101cf15:	mov    %rax,0x10(%rcx)
 101cf19:	addq   $0xffffffffffff0000,0x18(%rdi)
 101cf21:	mov    0x1608(%rdi),%rax
 101cf28:	test   %rax,%rax
 101cf2b:	je     101cf90 <slab_free+0x100>
 101cf2d:	mov    0x20(%rax),%r14
 101cf31:	addq   $0xffffffffffff0000,0x208(%r14)
 101cf3c:	mov    0x450(%r14),%rax
 101cf43:	cmp    $0x10,%rax
 101cf47:	jb     101cf66 <slab_free+0xd6>
 101cf49:	lea    0x1000(%rbx),%rdi
 101cf50:	mov    $0xf000,%esi
 101cf55:	mov    $0x4,%edx
 101cf5a:	call   101f360 <madvise@plt>
 101cf5f:	mov    0x450(%r14),%rax
 101cf66:	mov    0x448(%r14),%rcx
 101cf6d:	mov    %rcx,(%rbx)
 101cf70:	mov    %rbx,0x448(%r14)
 101cf77:	inc    %rax
 101cf7a:	mov    %rax,0x450(%r14)
 101cf81:	pop    %rbx
 101cf82:	pop    %r14
 101cf84:	pop    %rbp
 101cf85:	ret
 101cf86:	mov    %rcx,(%rax)
 101cf89:	test   %rcx,%rcx
 101cf8c:	jne    101cf11 <slab_free+0x81>
 101cf8e:	jmp    101cf19 <slab_free+0x89>
 101cf90:	call   101267d <myl_rc_invariant_failed>
 101cf95:	int3
 101cf96:	int3
 101cf97:	int3
 101cf98:	int3
 101cf99:	int3
 101cf9a:	int3
 101cf9b:	int3
 101cf9c:	int3
 101cf9d:	int3
 101cf9e:	int3
 101cf9f:	int3

000000000101cfa0 <slab_refill>:
 101cfa0:	push   %rbp
 101cfa1:	mov    %rsp,%rbp
 101cfa4:	push   %r15
 101cfa6:	push   %r14
 101cfa8:	push   %r13
 101cfaa:	push   %r12
 101cfac:	push   %rbx
 101cfad:	sub    $0x38,%rsp
 101cfb1:	test   %rdi,%rdi
 101cfb4:	je     101d331 <slab_refill+0x391>
 101cfba:	mov    %rdi,%rbx
 101cfbd:	mov    0x1608(%rdi),%rax
 101cfc4:	test   %rax,%rax
 101cfc7:	je     101d331 <slab_refill+0x391>
 101cfcd:	mov    %rsi,%r12
 101cfd0:	mov    0x20(%rax),%r14
 101cfd4:	mov    %rsi,%r15
 101cfd7:	shl    $0x4,%r15
 101cfdb:	mov    0x8(%r14,%r15,1),%rcx
 101cfe0:	test   %rcx,%rcx
 101cfe3:	jne    101d14b <slab_refill+0x1ab>
 101cfe9:	cmpq   $0x0,0x448(%r14)
 101cff1:	jne    101d01a <slab_refill+0x7a>
 101cff3:	mov    0x1710(%rbx),%rax
 101cffa:	cmp    $0x100000,%rax
 101d000:	jb     101d01a <slab_refill+0x7a>
 101d002:	mov    0x208(%r14),%rcx
 101d009:	shr    $0x2,%rcx
 101d00d:	cmp    %rcx,%rax
 101d010:	jb     101d01a <slab_refill+0x7a>
 101d012:	mov    %rbx,%rdi
 101d015:	call   101cda0 <trim_empty>
 101d01a:	mov    0x18(%rbx),%rax
 101d01e:	cmp    $0xfffffffffffeffff,%rax
 101d024:	ja     101d046 <slab_refill+0xa6>
 101d026:	mov    0x58(%rbx),%rcx
 101d02a:	test   %rcx,%rcx
 101d02d:	je     101d088 <slab_refill+0xe8>
 101d02f:	sub    %rax,%rcx
 101d032:	setb   %al
 101d035:	cmp    $0x10000,%rcx
 101d03c:	setb   %cl
 101d03f:	or     %al,%cl
 101d041:	cmp    $0x1,%cl
 101d044:	jne    101d088 <slab_refill+0xe8>
 101d046:	mov    %rbx,%rdi
 101d049:	call   101cda0 <trim_empty>
 101d04e:	mov    0x18(%rbx),%rax
 101d052:	cmp    $0xfffffffffffeffff,%rax
 101d058:	ja     101d07a <slab_refill+0xda>
 101d05a:	mov    0x58(%rbx),%rcx
 101d05e:	test   %rcx,%rcx
 101d061:	je     101d088 <slab_refill+0xe8>
 101d063:	sub    %rax,%rcx
 101d066:	setb   %al
 101d069:	cmp    $0x10000,%rcx
 101d070:	setb   %cl
 101d073:	or     %al,%cl
 101d075:	cmp    $0x1,%cl
 101d078:	jne    101d088 <slab_refill+0xe8>
 101d07a:	movl   $0x1,0x6c(%rbx)
 101d081:	xor    %eax,%eax
 101d083:	jmp    101d31b <slab_refill+0x37b>
 101d088:	mov    %rbx,%rdi
 101d08b:	call   101d340 <range_take>
 101d090:	test   %rax,%rax
 101d093:	jne    101d0ae <slab_refill+0x10e>
 101d095:	mov    %rbx,%rdi
 101d098:	call   101cda0 <trim_empty>
 101d09d:	mov    %rbx,%rdi
 101d0a0:	call   101d340 <range_take>
 101d0a5:	test   %rax,%rax
 101d0a8:	je     101d32d <slab_refill+0x38d>
 101d0ae:	mov    %rax,%rcx
 101d0b1:	vxorps %xmm0,%xmm0,%xmm0
 101d0b5:	vmovups %ymm0,0x30(%rax)
 101d0ba:	vmovups %ymm0,0x10(%rax)
 101d0bf:	lea    -0x19e86(%rip),%rax        # 1003240 <strides>
 101d0c6:	mov    (%rax,%r12,8),%rdi
 101d0ca:	mov    %rdi,0x8(%rcx)
 101d0ce:	mov    %r12,(%rcx)
 101d0d1:	cmp    $0xffb0,%rdi
 101d0d8:	ja     101d0e5 <slab_refill+0x145>
 101d0da:	mov    $0xffb0,%eax
 101d0df:	xor    %edx,%edx
 101d0e1:	div    %edi
 101d0e3:	jmp    101d0e7 <slab_refill+0x147>
 101d0e5:	xor    %eax,%eax
 101d0e7:	mov    %rax,0x40(%rcx)
 101d0eb:	mov    0x1608(%rbx),%rax
 101d0f2:	test   %rax,%rax
 101d0f5:	je     101d331 <slab_refill+0x391>
 101d0fb:	mov    0x20(%rax),%rax
 101d0ff:	lea    (%rax,%r15,1),%rdx
 101d103:	mov    (%rax,%r15,1),%rdi
 101d107:	mov    %rdi,0x18(%rcx)
 101d10b:	test   %rdi,%rdi
 101d10e:	je     101d114 <slab_refill+0x174>
 101d110:	mov    %rcx,0x10(%rdi)
 101d114:	mov    %rcx,(%rdx)
 101d117:	mov    0x8(%rdx),%rdi
 101d11b:	movq   $0x0,0x20(%rcx)
 101d123:	mov    %rdi,0x28(%rcx)
 101d127:	mov    0x8(%rdx),%rdi
 101d12b:	test   %rdi,%rdi
 101d12e:	je     101d134 <slab_refill+0x194>
 101d130:	mov    %rcx,0x20(%rdi)
 101d134:	mov    %rcx,0x8(%rdx)
 101d138:	addq   $0x10000,0x18(%rbx)
 101d140:	addq   $0x10000,0x208(%rax)
 101d14b:	mov    0x48(%rcx),%rax
 101d14f:	test   %rax,%rax
 101d152:	je     101d176 <slab_refill+0x1d6>
 101d154:	movq   $0x0,0x48(%rcx)
 101d15c:	mov    0x30(%rcx),%rdi
 101d160:	mov    0x40(%rcx),%r9
 101d164:	mov    %rdi,0x38(%rcx)
 101d168:	cmp    %r9,%rdi
 101d16b:	je     101d2e1 <slab_refill+0x341>
 101d171:	jmp    101d310 <slab_refill+0x370>
 101d176:	mov    0x8(%rcx),%r13
 101d17a:	mov    0x30(%rcx),%rdi
 101d17e:	mov    0x40(%rcx),%r9
 101d182:	mov    %r9,%r8
 101d185:	sub    %rdi,%r8
 101d188:	cmp    $0x1000,%r13
 101d18f:	ja     101d19d <slab_refill+0x1fd>
 101d191:	mov    $0x1000,%eax
 101d196:	xor    %edx,%edx
 101d198:	div    %r13d
 101d19b:	jmp    101d19f <slab_refill+0x1ff>
 101d19d:	xor    %eax,%eax
 101d19f:	cmp    $0x1001,%r13
 101d1a6:	mov    $0x1,%edx
 101d1ab:	cmovb  %rax,%rdx
 101d1af:	cmp    %r8,%rdx
 101d1b2:	cmovae %r8,%rdx
 101d1b6:	mov    %rdi,%r8
 101d1b9:	imul   %r13,%r8
 101d1bd:	lea    (%rcx,%r8,1),%rax
 101d1c1:	add    $0x50,%rax
 101d1c5:	test   %rdx,%rdx
 101d1c8:	je     101d2d1 <slab_refill+0x331>
 101d1ce:	cmp    $0x1,%rdx
 101d1d2:	jne    101d1dc <slab_refill+0x23c>
 101d1d4:	xor    %r10d,%r10d
 101d1d7:	jmp    101d2a9 <slab_refill+0x309>
 101d1dc:	mov    %r9,-0x38(%rbp)
 101d1e0:	mov    %r12,-0x40(%rbp)
 101d1e4:	mov    %r15,-0x48(%rbp)
 101d1e8:	mov    %r14,-0x50(%rbp)
 101d1ec:	mov    %rbx,-0x58(%rbp)
 101d1f0:	lea    0x1(%rdi),%r10
 101d1f4:	imul   %r13,%r10
 101d1f8:	lea    (%rcx,%r10,1),%r11
 101d1fc:	add    $0x50,%r11
 101d200:	lea    0x0(,%r13,2),%r12
 101d208:	lea    0x2(%rdi),%r10
 101d20c:	mov    %r13,-0x30(%rbp)
 101d210:	imul   %r13,%r10
 101d214:	lea    (%rcx,%r10,1),%r13
 101d218:	add    $0x50,%r13
 101d21c:	lea    (%r8,%rcx,1),%r14
 101d220:	add    $0x60,%r14
 101d224:	mov    %rdx,%r8
 101d227:	and    $0xfffffffffffffffe,%r8
 101d22b:	neg    %r8
 101d22e:	mov    $0x1,%r10d
 101d234:	xor    %r15d,%r15d
 101d237:	xor    %ebx,%ebx
 101d239:	nopl   0x0(%rax)
 101d240:	lea    (%r11,%rbx,1),%r9
 101d244:	cmp    %rdx,%r10
 101d247:	cmovae %r15,%r9
 101d24b:	mov    %r9,-0x10(%r14,%rbx,1)
 101d250:	movq   $0x3,(%r14,%rbx,1)
 101d258:	lea    0x1(%r10),%r9
 101d25c:	lea    (%rbx,%r13,1),%rsi
 101d260:	cmp    %rdx,%r9
 101d263:	cmovae %r15,%rsi
 101d267:	mov    %rsi,(%r11,%rbx,1)
 101d26b:	movq   $0x3,0x10(%r11,%rbx,1)
 101d274:	add    %r12,%rbx
 101d277:	lea    (%r8,%r10,1),%rsi
 101d27b:	add    $0x2,%rsi
 101d27f:	add    $0x2,%r10
 101d283:	cmp    $0x1,%rsi
 101d287:	jne    101d240 <slab_refill+0x2a0>
 101d289:	test   $0x1,%dl
 101d28c:	mov    -0x58(%rbp),%rbx
 101d290:	mov    -0x50(%rbp),%r14
 101d294:	mov    -0x48(%rbp),%r15
 101d298:	mov    -0x40(%rbp),%r12
 101d29c:	mov    -0x38(%rbp),%r9
 101d2a0:	mov    -0x30(%rbp),%r13
 101d2a4:	je     101d2d1 <slab_refill+0x331>
 101d2a6:	dec    %r10
 101d2a9:	mov    %r10,%rsi
 101d2ac:	imul   %r13,%rsi
 101d2b0:	inc    %r10
 101d2b3:	imul   %r10,%r13
 101d2b7:	add    %rax,%r13
 101d2ba:	xor    %r8d,%r8d
 101d2bd:	cmp    %rdx,%r10
 101d2c0:	cmovb  %r13,%r8
 101d2c4:	mov    %r8,(%rax,%rsi,1)
 101d2c8:	movq   $0x3,0x10(%rax,%rsi,1)
 101d2d1:	add    %rdx,%rdi
 101d2d4:	mov    %rdi,0x30(%rcx)
 101d2d8:	add    %rdx,0x38(%rcx)
 101d2dc:	cmp    %r9,%rdi
 101d2df:	jne    101d310 <slab_refill+0x370>
 101d2e1:	mov    0x20(%rcx),%rdx
 101d2e5:	mov    0x28(%rcx),%rdi
 101d2e9:	test   %rdx,%rdx
 101d2ec:	je     101d2f4 <slab_refill+0x354>
 101d2ee:	mov    %rdi,0x28(%rdx)
 101d2f2:	jmp    101d2fb <slab_refill+0x35b>
 101d2f4:	add    %r15,%r14
 101d2f7:	mov    %rdi,0x8(%r14)
 101d2fb:	add    $0x20,%rcx
 101d2ff:	test   %rdi,%rdi
 101d302:	je     101d308 <slab_refill+0x368>
 101d304:	mov    %rdx,0x20(%rdi)
 101d308:	vxorps %xmm0,%xmm0,%xmm0
 101d30c:	vmovups %xmm0,(%rcx)
 101d310:	mov    (%rax),%rcx
 101d313:	mov    %rcx,0x1610(%rbx,%r12,8)
 101d31b:	add    $0x38,%rsp
 101d31f:	pop    %rbx
 101d320:	pop    %r12
 101d322:	pop    %r13
 101d324:	pop    %r14
 101d326:	pop    %r15
 101d328:	pop    %rbp
 101d329:	vzeroupper
 101d32c:	ret
 101d32d:	xor    %eax,%eax
 101d32f:	jmp    101d31b <slab_refill+0x37b>
 101d331:	vzeroupper
 101d334:	call   101267d <myl_rc_invariant_failed>
 101d339:	int3
 101d33a:	int3
 101d33b:	int3
 101d33c:	int3
 101d33d:	int3
 101d33e:	int3
 101d33f:	int3

000000000101d340 <range_take>:
 101d340:	push   %rbp
 101d341:	mov    %rsp,%rbp
 101d344:	push   %r15
 101d346:	push   %r14
 101d348:	push   %rbx
 101d349:	push   %rax
 101d34a:	test   %rdi,%rdi
 101d34d:	je     101d530 <range_take+0x1f0>
 101d353:	mov    0x1608(%rdi),%rax
 101d35a:	test   %rax,%rax
 101d35d:	je     101d530 <range_take+0x1f0>
 101d363:	mov    0x20(%rax),%r15
 101d367:	mov    0x448(%r15),%rax
 101d36e:	test   %rax,%rax
 101d371:	je     101d389 <range_take+0x49>
 101d373:	mov    (%rax),%rcx
 101d376:	mov    %rcx,0x448(%r15)
 101d37d:	decq   0x450(%r15)
 101d384:	jmp    101d521 <range_take+0x1e1>
 101d389:	mov    0x220(%r15),%rax
 101d390:	cmp    0x228(%r15),%rax
 101d397:	jne    101d513 <range_take+0x1d3>
 101d39d:	mov    0x438(%r15),%rcx
 101d3a4:	cmp    $0x40,%rcx
 101d3a8:	jb     101d461 <range_take+0x121>
 101d3ae:	add    $0xffffffffffffffc0,%rcx
 101d3b2:	cmp    0x440(%r15),%rcx
 101d3b9:	jne    101d461 <range_take+0x121>
 101d3bf:	lea    (%rcx,%rcx,1),%rax
 101d3c3:	test   %rcx,%rcx
 101d3c6:	mov    $0x40,%ebx
 101d3cb:	cmovne %rax,%rbx
 101d3cf:	mov    %rbx,%rax
 101d3d2:	sub    %rcx,%rax
 101d3d5:	shl    $0x3,%rax
 101d3d9:	mov    0x18(%rdi),%rcx
 101d3dd:	mov    %rcx,%rdx
 101d3e0:	add    %rax,%rdx
 101d3e3:	jae    101d3f3 <range_take+0xb3>
 101d3e5:	movl   $0x1,0x6c(%rdi)
 101d3ec:	xor    %eax,%eax
 101d3ee:	jmp    101d521 <range_take+0x1e1>
 101d3f3:	mov    0x58(%rdi),%rdx
 101d3f7:	test   %rdx,%rdx
 101d3fa:	je     101d406 <range_take+0xc6>
 101d3fc:	sub    %rcx,%rdx
 101d3ff:	jb     101d3e5 <range_take+0xa5>
 101d401:	cmp    %rdx,%rax
 101d404:	ja     101d3e5 <range_take+0xa5>
 101d406:	mov    %rdi,%r14
 101d409:	lea    0x0(,%rbx,8),%rsi
 101d411:	mov    0x430(%r15),%rdi
 101d418:	call   101f180 <realloc@plt>
 101d41d:	test   %rax,%rax
 101d420:	je     101d52c <range_take+0x1ec>
 101d426:	mov    %rbx,%rcx
 101d429:	sub    0x440(%r15),%rcx
 101d430:	shl    $0x3,%rcx
 101d434:	add    %rcx,0x18(%r14)
 101d438:	mov    0x1608(%r14),%rdx
 101d43f:	test   %rdx,%rdx
 101d442:	je     101d530 <range_take+0x1f0>
 101d448:	mov    0x20(%rdx),%rdx
 101d44c:	add    %rcx,0x208(%rdx)
 101d453:	mov    %rax,0x430(%r15)
 101d45a:	mov    %rbx,0x440(%r15)
 101d461:	mov    $0x210000,%esi
 101d466:	xor    %edi,%edi
 101d468:	mov    $0x3,%edx
 101d46d:	mov    $0x22,%ecx
 101d472:	mov    $0xffffffff,%r8d
 101d478:	xor    %r9d,%r9d
 101d47b:	call   101f0f0 <mmap@plt>
 101d480:	mov    %rax,%rbx
 101d483:	xor    %eax,%eax
 101d485:	cmp    $0xffffffffffffffff,%rbx
 101d489:	je     101d521 <range_take+0x1e1>
 101d48f:	lea    0xffff(%rbx),%rax
 101d496:	and    $0xffffffffffff0000,%rax
 101d49c:	cmp    %rax,%rbx
 101d49f:	je     101d4b5 <range_take+0x175>
 101d4a1:	mov    %rax,%rsi
 101d4a4:	sub    %rbx,%rsi
 101d4a7:	mov    %rbx,%rdi
 101d4aa:	mov    %rax,%r14
 101d4ad:	call   101f140 <munmap@plt>
 101d4b2:	mov    %r14,%rax
 101d4b5:	lea    0x200000(%rax),%r14
 101d4bc:	add    $0x210000,%rbx
 101d4c3:	cmp    %rbx,%r14
 101d4c6:	je     101d4dc <range_take+0x19c>
 101d4c8:	sub    %r14,%rbx
 101d4cb:	mov    %r14,%rdi
 101d4ce:	mov    %rbx,%rsi
 101d4d1:	mov    %rax,%rbx
 101d4d4:	call   101f140 <munmap@plt>
 101d4d9:	mov    %rbx,%rax
 101d4dc:	mov    0x438(%r15),%rcx
 101d4e3:	cmp    $0x3f,%rcx
 101d4e7:	ja     101d4f3 <range_take+0x1b3>
 101d4e9:	mov    %rax,0x230(%r15,%rcx,8)
 101d4f1:	jmp    101d502 <range_take+0x1c2>
 101d4f3:	mov    0x430(%r15),%rdx
 101d4fa:	mov    %rax,-0x200(%rdx,%rcx,8)
 101d502:	inc    %rcx
 101d505:	mov    %rcx,0x438(%r15)
 101d50c:	mov    %r14,0x228(%r15)
 101d513:	lea    0x10000(%rax),%rcx
 101d51a:	mov    %rcx,0x220(%r15)
 101d521:	add    $0x8,%rsp
 101d525:	pop    %rbx
 101d526:	pop    %r14
 101d528:	pop    %r15
 101d52a:	pop    %rbp
 101d52b:	ret
 101d52c:	xor    %eax,%eax
 101d52e:	jmp    101d521 <range_take+0x1e1>
 101d530:	call   101267d <myl_rc_invariant_failed>
 101d535:	int3
 101d536:	int3
 101d537:	int3
 101d538:	int3
 101d539:	int3
 101d53a:	int3
 101d53b:	int3
 101d53c:	int3
 101d53d:	int3
 101d53e:	int3
 101d53f:	int3

000000000101d540 <destroy>:
 101d540:	push   %rbp
 101d541:	mov    %rsp,%rbp
 101d544:	push   %r15
 101d546:	push   %r14
 101d548:	push   %r13
 101d54a:	push   %r12
 101d54c:	push   %rbx
 101d54d:	push   %rax
 101d54e:	test   %rdi,%rdi
 101d551:	je     101d6ce <destroy+0x18e>
 101d557:	mov    %rdi,%rbx
 101d55a:	mov    0x1608(%rdi),%rax
 101d561:	test   %rax,%rax
 101d564:	je     101d6ce <destroy+0x18e>
 101d56a:	mov    0x20(%rax),%r14
 101d56e:	xor    %eax,%eax
 101d570:	jmp    101d595 <destroy+0x55>
 101d572:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101d580:	movq   $0x0,0x1610(%rbx,%rax,8)
 101d58c:	inc    %rax
 101d58f:	cmp    $0x20,%rax
 101d593:	je     101d5c8 <destroy+0x88>
 101d595:	mov    0x1610(%rbx,%rax,8),%rcx
 101d59d:	test   %rcx,%rcx
 101d5a0:	je     101d580 <destroy+0x40>
 101d5a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101d5b0:	mov    %rcx,%rdx
 101d5b3:	and    $0xffffffffffff0000,%rdx
 101d5ba:	decq   0x38(%rdx)
 101d5be:	mov    (%rcx),%rcx
 101d5c1:	test   %rcx,%rcx
 101d5c4:	jne    101d5b0 <destroy+0x70>
 101d5c6:	jmp    101d580 <destroy+0x40>
 101d5c8:	movq   $0x0,0x1710(%rbx)
 101d5d3:	xor    %r15d,%r15d
 101d5d6:	jmp    101d5e9 <destroy+0xa9>
 101d5d8:	nopl   0x0(%rax,%rax,1)
 101d5e0:	inc    %r15
 101d5e3:	cmp    $0x20,%r15
 101d5e7:	je     101d613 <destroy+0xd3>
 101d5e9:	mov    %r15,%r12
 101d5ec:	shl    $0x4,%r12
 101d5f0:	mov    (%r14,%r12,1),%rsi
 101d5f4:	test   %rsi,%rsi
 101d5f7:	je     101d5e0 <destroy+0xa0>
 101d5f9:	add    %r14,%r12
 101d5fc:	nopl   0x0(%rax)
 101d600:	mov    %rbx,%rdi
 101d603:	call   101ce90 <slab_free>
 101d608:	mov    (%r12),%rsi
 101d60c:	test   %rsi,%rsi
 101d60f:	jne    101d600 <destroy+0xc0>
 101d611:	jmp    101d5e0 <destroy+0xa0>
 101d613:	cmpq   $0x0,0x438(%r14)
 101d61b:	je     101d663 <destroy+0x123>
 101d61d:	lea    0x230(%r14),%r15
 101d624:	mov    $0xfffffffffffffe00,%r12
 101d62b:	xor    %r13d,%r13d
 101d62e:	jmp    101d657 <destroy+0x117>
 101d630:	mov    0x430(%r14),%rax
 101d637:	add    %r12,%rax
 101d63a:	mov    (%rax),%rdi
 101d63d:	mov    $0x200000,%esi
 101d642:	call   101f140 <munmap@plt>
 101d647:	inc    %r13
 101d64a:	add    $0x8,%r12
 101d64e:	cmp    0x438(%r14),%r13
 101d655:	jae    101d663 <destroy+0x123>
 101d657:	cmp    $0x3f,%r13
 101d65b:	ja     101d630 <destroy+0xf0>
 101d65d:	lea    (%r15,%r13,8),%rax
 101d661:	jmp    101d63a <destroy+0xfa>
 101d663:	mov    0x440(%r14),%rax
 101d66a:	shl    $0x3,%rax
 101d66e:	sub    %rax,0x18(%rbx)
 101d672:	mov    0x1608(%rbx),%rcx
 101d679:	test   %rcx,%rcx
 101d67c:	je     101d6ce <destroy+0x18e>
 101d67e:	mov    0x20(%rcx),%rcx
 101d682:	sub    %rax,0x208(%rcx)
 101d689:	mov    0x430(%r14),%rdi
 101d690:	call   101efd0 <free@plt>
 101d695:	addq   $0xfffffffffffffba8,0x18(%rbx)
 101d69d:	mov    0x1608(%rbx),%rax
 101d6a4:	test   %rax,%rax
 101d6a7:	je     101d6ce <destroy+0x18e>
 101d6a9:	mov    0x20(%rax),%rax
 101d6ad:	addq   $0xfffffffffffffba8,0x208(%rax)
 101d6b8:	mov    %r14,%rdi
 101d6bb:	add    $0x8,%rsp
 101d6bf:	pop    %rbx
 101d6c0:	pop    %r12
 101d6c2:	pop    %r13
 101d6c4:	pop    %r14
 101d6c6:	pop    %r15
 101d6c8:	pop    %rbp
 101d6c9:	jmp    101efd0 <free@plt>
 101d6ce:	call   101267d <myl_rc_invariant_failed>
 101d6d3:	int3
 101d6d4:	int3
 101d6d5:	int3
 101d6d6:	int3
 101d6d7:	int3
 101d6d8:	int3
 101d6d9:	int3
 101d6da:	int3
 101d6db:	int3
 101d6dc:	int3
 101d6dd:	int3
 101d6de:	int3
 101d6df:	int3

000000000101d6e0 <teardown>:
 101d6e0:	push   %rbp
 101d6e1:	mov    %rsp,%rbp
 101d6e4:	pop    %rbp
 101d6e5:	jmp    101c660 <release_extents>
 101d6ea:	int3
 101d6eb:	int3
 101d6ec:	int3
 101d6ed:	int3
 101d6ee:	int3
 101d6ef:	int3

000000000101d6f0 <large_grow>:
 101d6f0:	push   %rbp
 101d6f1:	mov    %rsp,%rbp
 101d6f4:	push   %r15
 101d6f6:	push   %r14
 101d6f8:	push   %rbx
 101d6f9:	push   %rax
 101d6fa:	mov    %rsi,%rbx
 101d6fd:	mov    0x20(%rdi),%rsi
 101d701:	test   %rsi,%rsi
 101d704:	setne  %cl
 101d707:	cmp    $0x20000,%rdx
 101d70e:	setae  %r8b
 101d712:	or     %cl,%r8b
 101d715:	jne    101d729 <large_grow+0x39>
 101d717:	mov    %rdx,%rsi
 101d71a:	add    $0x8,%rsp
 101d71e:	pop    %rbx
 101d71f:	pop    %r14
 101d721:	pop    %r15
 101d723:	pop    %rbp
 101d724:	jmp    101f180 <realloc@plt>
 101d729:	test   %rsi,%rsi
 101d72c:	je     101d768 <large_grow+0x78>
 101d72e:	cmp    $0xffffffffffffefff,%rdx
 101d735:	ja     101d79e <large_grow+0xae>
 101d737:	add    $0xfff,%rdx
 101d73e:	and    $0xfffffffffffff000,%rdx
 101d745:	cmp    %rsi,%rdx
 101d748:	jbe    101d7a0 <large_grow+0xb0>
 101d74a:	mov    %rdx,%rbx
 101d74d:	mov    $0x1,%ecx
 101d752:	xor    %eax,%eax
 101d754:	call   101f370 <mremap@plt>
 101d759:	cmp    $0xffffffffffffffff,%rax
 101d75d:	je     101d79e <large_grow+0xae>
 101d75f:	mov    %rax,%rdi
 101d762:	mov    %rbx,0x20(%rax)
 101d766:	jmp    101d7a0 <large_grow+0xb0>
 101d768:	mov    %rdi,%r14
 101d76b:	mov    %rdx,%rdi
 101d76e:	call   101cd20 <large_block>
 101d773:	test   %rax,%rax
 101d776:	je     101d79e <large_grow+0xae>
 101d778:	mov    0x20(%rax),%r15
 101d77c:	mov    %rax,%rdi
 101d77f:	mov    %r14,%rsi
 101d782:	mov    %rbx,%rdx
 101d785:	mov    %rax,%rbx
 101d788:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101d78d:	mov    %r15,0x20(%rbx)
 101d791:	mov    %r14,%rdi
 101d794:	call   101efd0 <free@plt>
 101d799:	mov    %rbx,%rdi
 101d79c:	jmp    101d7a0 <large_grow+0xb0>
 101d79e:	xor    %edi,%edi
 101d7a0:	mov    %rdi,%rax
 101d7a3:	add    $0x8,%rsp
 101d7a7:	pop    %rbx
 101d7a8:	pop    %r14
 101d7aa:	pop    %r15
 101d7ac:	pop    %rbp
 101d7ad:	ret
 101d7ae:	int3
 101d7af:	int3

000000000101d7b0 <myl_rc_native_shape>:
 101d7b0:	push   %rbp
 101d7b1:	mov    %rsp,%rbp
 101d7b4:	push   %r14
 101d7b6:	push   %rbx
 101d7b7:	sub    $0x70,%rsp
 101d7bb:	mov    %rsi,%rbx
 101d7be:	mov    0x1608(%rdi),%rcx
 101d7c5:	mov    0x34(%rsi),%eax
 101d7c8:	cmp    %rax,0xa0(%rcx)
 101d7cf:	jbe    101d7f4 <myl_rc_native_shape+0x44>
 101d7d1:	mov    0x98(%rcx),%rcx
 101d7d8:	shl    $0x4,%rax
 101d7dc:	cmp    %rbx,(%rcx,%rax,1)
 101d7e0:	jne    101d7f4 <myl_rc_native_shape+0x44>
 101d7e2:	add    %rax,%rcx
 101d7e5:	mov    0x8(%rcx),%rax
 101d7e9:	test   %rax,%rax
 101d7ec:	je     101d801 <myl_rc_native_shape+0x51>
 101d7ee:	mov    0x8(%rax),%rax
 101d7f2:	jmp    101d863 <myl_rc_native_shape+0xb3>
 101d7f4:	mov    %rbx,%rsi
 101d7f7:	call   10130fa <myl_rc_binding_find_slow>
 101d7fc:	test   %rax,%rax
 101d7ff:	jne    101d7ee <myl_rc_native_shape+0x3e>
 101d801:	mov    (%rbx),%rax
 101d804:	mov    %rax,-0x38(%rbp)
 101d808:	vxorps %xmm0,%xmm0,%xmm0
 101d80c:	vmovups %ymm0,-0x30(%rbp)
 101d811:	movzwl 0x30(%rbx),%eax
 101d815:	test   %eax,%eax
 101d817:	je     101d82e <myl_rc_native_shape+0x7e>
 101d819:	cmp    $0x7,%eax
 101d81c:	je     101d82e <myl_rc_native_shape+0x7e>
 101d81e:	cmp    $0x1,%eax
 101d821:	jne    101d8ac <myl_rc_native_shape+0xfc>
 101d827:	movl   $0x1,-0x30(%rbp)
 101d82e:	vmovups %ymm0,-0x58(%rbp)
 101d833:	vmovups %ymm0,-0x68(%rbp)
 101d838:	mov    %rbx,-0x78(%rbp)
 101d83c:	lea    -0x38(%rbp),%rax
 101d840:	mov    %rax,-0x70(%rbp)
 101d844:	lea    -0x78(%rbp),%rsi
 101d848:	mov    %rdi,%r14
 101d84b:	vzeroupper
 101d84e:	call   10153e0 <myl_rc_descriptor_import>
 101d853:	test   %eax,%eax
 101d855:	je     101d86c <myl_rc_native_shape+0xbc>
 101d857:	mov    %r14,%rdi
 101d85a:	mov    %eax,%esi
 101d85c:	call   1012770 <myl_rc_record_failure>
 101d861:	xor    %eax,%eax
 101d863:	add    $0x70,%rsp
 101d867:	pop    %rbx
 101d868:	pop    %r14
 101d86a:	pop    %rbp
 101d86b:	ret
 101d86c:	mov    0x1608(%r14),%rcx
 101d873:	mov    0x34(%rbx),%eax
 101d876:	cmp    %rax,0xa0(%rcx)
 101d87d:	jbe    101d89c <myl_rc_native_shape+0xec>
 101d87f:	mov    0x98(%rcx),%rcx
 101d886:	shl    $0x4,%rax
 101d88a:	cmp    %rbx,(%rcx,%rax,1)
 101d88e:	jne    101d89c <myl_rc_native_shape+0xec>
 101d890:	add    %rax,%rcx
 101d893:	mov    0x8(%rcx),%rax
 101d897:	jmp    101d7ee <myl_rc_native_shape+0x3e>
 101d89c:	mov    %r14,%rdi
 101d89f:	mov    %rbx,%rsi
 101d8a2:	call   10130fa <myl_rc_binding_find_slow>
 101d8a7:	jmp    101d7ee <myl_rc_native_shape+0x3e>
 101d8ac:	vzeroupper
 101d8af:	call   101f1f0 <abort@plt>
 101d8b4:	int3
 101d8b5:	int3
 101d8b6:	int3
 101d8b7:	int3
 101d8b8:	int3
 101d8b9:	int3
 101d8ba:	int3
 101d8bb:	int3
 101d8bc:	int3
 101d8bd:	int3
 101d8be:	int3
 101d8bf:	int3

000000000101d8c0 <flat_transfer>:
 101d8c0:	push   %rbp
 101d8c1:	mov    %rsp,%rbp
 101d8c4:	push   %r15
 101d8c6:	push   %r14
 101d8c8:	push   %r13
 101d8ca:	push   %r12
 101d8cc:	push   %rbx
 101d8cd:	sub    $0x98,%rsp
 101d8d4:	mov    0x40(%rsi),%r10d
 101d8d8:	mov    $0xffffffff,%eax
 101d8dd:	cmp    $0x10,%r10
 101d8e1:	ja     101ddbe <flat_transfer+0x4fe>
 101d8e7:	test   %rdi,%rdi
 101d8ea:	je     101ddd3 <flat_transfer+0x513>
 101d8f0:	cmp    %rcx,%rdx
 101d8f3:	je     101ddd3 <flat_transfer+0x513>
 101d8f9:	test   %rcx,%rcx
 101d8fc:	je     101ddd3 <flat_transfer+0x513>
 101d902:	test   %rdx,%rdx
 101d905:	je     101ddd3 <flat_transfer+0x513>
 101d90b:	cmpq   $0x0,0x1608(%rdi)
 101d913:	je     101ddd3 <flat_transfer+0x513>
 101d919:	mov    0x50(%rsi),%r12
 101d91d:	mov    %rdx,%r11
 101d920:	sub    %rcx,%r11
 101d923:	ja     101d92b <flat_transfer+0x6b>
 101d925:	mov    %rcx,%r11
 101d928:	sub    %rdx,%r11
 101d92b:	cmp    %r12,%r11
 101d92e:	jb     101ddbe <flat_transfer+0x4fe>
 101d934:	mov    $0x3,%eax
 101d939:	cmp    0x70(%rdi),%r8d
 101d93d:	ja     101ddbe <flat_transfer+0x4fe>
 101d943:	cmpb   $0x0,0x46(%rsi)
 101d947:	je     101d962 <flat_transfer+0xa2>
 101d949:	mov    0x48(%rsi),%eax
 101d94c:	mov    (%rcx,%rax,1),%eax
 101d94f:	lea    0x5a(%rsi),%r11
 101d953:	cmp    $0x20,%rax
 101d957:	lea    0x5c(%rsi,%rax,2),%rax
 101d95c:	cmovae %r11,%rax
 101d960:	jmp    101d966 <flat_transfer+0xa6>
 101d962:	lea    0x58(%rsi),%rax
 101d966:	movzwl (%rax),%r11d
 101d96a:	test   %r10,%r10
 101d96d:	je     101dbd3 <flat_transfer+0x313>
 101d973:	movabs $0x4000000000000000,%rbx
 101d97d:	xor    %r15d,%r15d
 101d980:	movabs $0x7ffffffffffffff0,%rax
 101d98a:	add    $0xc,%rax
 101d98e:	mov    %rax,-0x40(%rbp)
 101d992:	vmovd  -0x1aa62(%rip),%xmm0        # 1002f38 <list_scan+0xc>
 101d99a:	jmp    101d9b8 <flat_transfer+0xf8>
 101d99c:	nopl   0x0(%rax)
 101d9a0:	movq   $0x0,-0xc0(%rbp,%r15,8)
 101d9ac:	inc    %r15
 101d9af:	cmp    %r10,%r15
 101d9b2:	je     101dbd3 <flat_transfer+0x313>
 101d9b8:	bt     %r15d,%r11d
 101d9bc:	jae    101d9a0 <flat_transfer+0xe0>
 101d9be:	movzwl 0x9c(%rsi,%r15,2),%eax
 101d9c7:	mov    (%rcx,%rax,1),%r13
 101d9cb:	mov    %r13,-0xc0(%rbp,%r15,8)
 101d9d3:	test   %r13,%r13
 101d9d6:	je     101d9ac <flat_transfer+0xec>
 101d9d8:	mov    -0x10(%r13),%r14
 101d9dc:	test   $0x2,%r14b
 101d9e0:	jne    101d9ac <flat_transfer+0xec>
 101d9e2:	mov    $0xffffffff,%eax
 101d9e7:	bt     $0x3c,%r14
 101d9ec:	jb     101ddbe <flat_transfer+0x4fe>
 101d9f2:	test   %rbx,%r14
 101d9f5:	jne    101da3b <flat_transfer+0x17b>
 101d9f7:	test   $0x1,%r14b
 101d9fb:	jne    101ddd3 <flat_transfer+0x513>
 101da01:	mov    -0x20(%r13),%rax
 101da05:	test   %rax,%rax
 101da08:	jne    101da15 <flat_transfer+0x155>
 101da0a:	cmpq   $0x0,-0x18(%r13)
 101da0f:	je     101ddd3 <flat_transfer+0x513>
 101da15:	test   %r9d,%r9d
 101da18:	jne    101d9ac <flat_transfer+0xec>
 101da1a:	test   %r15,%r15
 101da1d:	je     101da54 <flat_transfer+0x194>
 101da1f:	mov    %rax,-0x30(%rbp)
 101da23:	cmp    $0x4,%r15
 101da27:	mov    %r12,-0x38(%rbp)
 101da2b:	jae    101da69 <flat_transfer+0x1a9>
 101da2d:	mov    $0x1,%r14d
 101da33:	xor    %r12d,%r12d
 101da36:	jmp    101db80 <flat_transfer+0x2c0>
 101da3b:	shr    $0x28,%r14
 101da3f:	and    $0xfffff,%r14d
 101da46:	cmp    %r8d,%r14d
 101da49:	jbe    101d9ac <flat_transfer+0xec>
 101da4f:	jmp    101ddbe <flat_transfer+0x4fe>
 101da54:	mov    $0xfffffffffffffffe,%r14
 101da5b:	cmp    %r14,%rax
 101da5e:	jbe    101d9ac <flat_transfer+0xec>
 101da64:	jmp    101dbac <flat_transfer+0x2ec>
 101da69:	vmovq  %r13,%xmm1
 101da6e:	cmp    $0x10,%r15
 101da72:	jae    101da82 <flat_transfer+0x1c2>
 101da74:	mov    $0x1,%r14d
 101da7a:	xor    %r12d,%r12d
 101da7d:	jmp    101db1f <flat_transfer+0x25f>
 101da82:	mov    %r15,%r14
 101da85:	and    $0xfffffffffffffff0,%r14
 101da89:	mov    %r15,%r12
 101da8c:	movabs $0x7ffffffffffffff0,%rax
 101da96:	and    %rax,%r12
 101da99:	vpbroadcastq %xmm1,%ymm3
 101da9e:	vpxor  %xmm2,%xmm2,%xmm2
 101daa2:	xor    %eax,%eax
 101daa4:	vmovdqa %ymm0,%ymm4
 101daa8:	vpxor  %xmm5,%xmm5,%xmm5
 101daac:	vpxor  %xmm6,%xmm6,%xmm6
 101dab0:	vpcmpeqq -0xc0(%rbp,%rax,8),%ymm3,%ymm7
 101daba:	vpsubq %ymm7,%ymm4,%ymm4
 101dabe:	vpcmpeqq -0xa0(%rbp,%rax,8),%ymm3,%ymm7
 101dac8:	vpsubq %ymm7,%ymm2,%ymm2
 101dacc:	vpcmpeqq -0x80(%rbp,%rax,8),%ymm3,%ymm7
 101dad3:	vpcmpeqq -0x60(%rbp,%rax,8),%ymm3,%ymm8
 101dada:	vpsubq %ymm7,%ymm5,%ymm5
 101dade:	vpsubq %ymm8,%ymm6,%ymm6
 101dae3:	add    $0x10,%rax
 101dae7:	cmp    %rax,%r14
 101daea:	jne    101dab0 <flat_transfer+0x1f0>
 101daec:	vpaddq %ymm4,%ymm2,%ymm2
 101daf0:	vpaddq %ymm5,%ymm6,%ymm3
 101daf4:	vpaddq %ymm2,%ymm3,%ymm2
 101daf8:	vextracti128 $0x1,%ymm2,%xmm3
 101dafe:	vpaddq %xmm3,%xmm2,%xmm2
 101db02:	vpshufd $0xee,%xmm2,%xmm3
 101db07:	vpaddq %xmm3,%xmm2,%xmm2
 101db0b:	vmovq  %xmm2,%r14
 101db10:	cmp    %r12,%r15
 101db13:	je     101db98 <flat_transfer+0x2d8>
 101db19:	test   $0xc,%r15b
 101db1d:	je     101db80 <flat_transfer+0x2c0>
 101db1f:	mov    %r12,%rax
 101db22:	mov    %r15,%rbx
 101db25:	and    $0xfffffffffffffffc,%rbx
 101db29:	mov    %r15,%r12
 101db2c:	and    -0x40(%rbp),%r12
 101db30:	vmovq  %r14,%xmm2
 101db35:	vpbroadcastq %xmm1,%ymm1
 101db3a:	nopw   0x0(%rax,%rax,1)
 101db40:	vpcmpeqq -0xc0(%rbp,%rax,8),%ymm1,%ymm3
 101db4a:	vpsubq %ymm3,%ymm2,%ymm2
 101db4e:	add    $0x4,%rax
 101db52:	cmp    %rax,%rbx
 101db55:	jne    101db40 <flat_transfer+0x280>
 101db57:	vextracti128 $0x1,%ymm2,%xmm1
 101db5d:	vpaddq %xmm1,%xmm2,%xmm1
 101db61:	vpshufd $0xee,%xmm1,%xmm2
 101db66:	vpaddq %xmm2,%xmm1,%xmm1
 101db6a:	vmovq  %xmm1,%r14
 101db6f:	cmp    %r12,%r15
 101db72:	movabs $0x4000000000000000,%rbx
 101db7c:	je     101db98 <flat_transfer+0x2d8>
 101db7e:	xchg   %ax,%ax
 101db80:	xor    %eax,%eax
 101db82:	cmp    %r13,-0xc0(%rbp,%r12,8)
 101db8a:	sete   %al
 101db8d:	add    %rax,%r14
 101db90:	inc    %r12
 101db93:	cmp    %r12,%r15
 101db96:	jne    101db80 <flat_transfer+0x2c0>
 101db98:	not    %r14
 101db9b:	mov    -0x38(%rbp),%r12
 101db9f:	mov    -0x30(%rbp),%rax
 101dba3:	cmp    %r14,%rax
 101dba6:	jbe    101d9ac <flat_transfer+0xec>
 101dbac:	mov    %rdi,%rbx
 101dbaf:	mov    %rdx,%rdi
 101dbb2:	xor    %esi,%esi
 101dbb4:	mov    %r12,%rdx
 101dbb7:	vzeroupper
 101dbba:	call   101e6b0 <compiler_rt.fastMemset>
 101dbbf:	mov    %rbx,%rdi
 101dbc2:	mov    0x1608(%rbx),%rcx
 101dbc9:	mov    $0x2,%eax
 101dbce:	jmp    101dda8 <flat_transfer+0x4e8>
 101dbd3:	test   %r9d,%r9d
 101dbd6:	je     101dc19 <flat_transfer+0x359>
 101dbd8:	cmp    $0x61,%r12
 101dbdc:	setb   %al
 101dbdf:	test   $0x7,%r12b
 101dbe3:	sete   %sil
 101dbe7:	test   %sil,%al
 101dbea:	jne    101dc89 <flat_transfer+0x3c9>
 101dbf0:	mov    %rdi,%rbx
 101dbf3:	mov    %rdx,%rdi
 101dbf6:	mov    %rcx,%rsi
 101dbf9:	mov    %r12,%rdx
 101dbfc:	mov    %rcx,%r14
 101dbff:	vzeroupper
 101dc02:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101dc07:	mov    %r14,%rdi
 101dc0a:	xor    %esi,%esi
 101dc0c:	mov    %r12,%rdx
 101dc0f:	call   101e6b0 <compiler_rt.fastMemset>
 101dc14:	jmp    101dd9c <flat_transfer+0x4dc>
 101dc19:	test   %r11d,%r11d
 101dc1c:	je     101dc71 <flat_transfer+0x3b1>
 101dc1e:	movabs $0x4000000000000000,%rax
 101dc28:	movabs $0x2000000000000000,%rsi
 101dc32:	jmp    101dc47 <flat_transfer+0x387>
 101dc34:	incq   -0x20(%r8)
 101dc38:	nopl   0x0(%rax,%rax,1)
 101dc40:	blsr   %r11d,%r11d
 101dc45:	je     101dc71 <flat_transfer+0x3b1>
 101dc47:	tzcnt  %r11d,%r8d
 101dc4c:	mov    -0xc0(%rbp,%r8,8),%r8
 101dc54:	test   %r8,%r8
 101dc57:	je     101dc40 <flat_transfer+0x380>
 101dc59:	mov    -0x10(%r8),%r10
 101dc5d:	test   $0x2,%r10b
 101dc61:	jne    101dc40 <flat_transfer+0x380>
 101dc63:	test   %rax,%r10
 101dc66:	je     101dc34 <flat_transfer+0x374>
 101dc68:	or     %rsi,%r10
 101dc6b:	mov    %r10,-0x10(%r8)
 101dc6f:	jmp    101dc40 <flat_transfer+0x380>
 101dc71:	cmp    $0x61,%r12
 101dc75:	setb   %al
 101dc78:	test   $0x7,%r12b
 101dc7c:	sete   %sil
 101dc80:	test   %sil,%al
 101dc83:	je     101dd88 <flat_transfer+0x4c8>
 101dc89:	shr    $0x3,%r12
 101dc8d:	dec    %r12
 101dc90:	cmp    $0xb,%r12
 101dc94:	ja     101dd04 <flat_transfer+0x444>
 101dc96:	lea    -0x1a6bd(%rip),%rax        # 10035e0 <raw_shape+0x28>
 101dc9d:	movslq (%rax,%r12,4),%rsi
 101dca1:	add    %rax,%rsi
 101dca4:	jmp    *%rsi
 101dca6:	mov    0x58(%rcx),%rax
 101dcaa:	mov    %rax,0x58(%rdx)
 101dcae:	mov    0x50(%rcx),%rax
 101dcb2:	mov    %rax,0x50(%rdx)
 101dcb6:	mov    0x48(%rcx),%rax
 101dcba:	mov    %rax,0x48(%rdx)
 101dcbe:	mov    0x40(%rcx),%rax
 101dcc2:	mov    %rax,0x40(%rdx)
 101dcc6:	mov    0x38(%rcx),%rax
 101dcca:	mov    %rax,0x38(%rdx)
 101dcce:	mov    0x30(%rcx),%rax
 101dcd2:	mov    %rax,0x30(%rdx)
 101dcd6:	mov    0x28(%rcx),%rax
 101dcda:	mov    %rax,0x28(%rdx)
 101dcde:	mov    0x20(%rcx),%rax
 101dce2:	mov    %rax,0x20(%rdx)
 101dce6:	mov    0x18(%rcx),%rax
 101dcea:	mov    %rax,0x18(%rdx)
 101dcee:	mov    0x10(%rcx),%rax
 101dcf2:	mov    %rax,0x10(%rdx)
 101dcf6:	mov    0x8(%rcx),%rax
 101dcfa:	mov    %rax,0x8(%rdx)
 101dcfe:	mov    (%rcx),%rax
 101dd01:	mov    %rax,(%rdx)
 101dd04:	test   %r9d,%r9d
 101dd07:	je     101dd9f <flat_transfer+0x4df>
 101dd0d:	cmp    $0xb,%r12
 101dd11:	ja     101dd9f <flat_transfer+0x4df>
 101dd17:	lea    -0x1a70e(%rip),%rax        # 1003610 <raw_shape+0x58>
 101dd1e:	movslq (%rax,%r12,4),%rdx
 101dd22:	add    %rax,%rdx
 101dd25:	jmp    *%rdx
 101dd27:	movq   $0x0,0x58(%rcx)
 101dd2f:	movq   $0x0,0x50(%rcx)
 101dd37:	movq   $0x0,0x48(%rcx)
 101dd3f:	movq   $0x0,0x40(%rcx)
 101dd47:	movq   $0x0,0x38(%rcx)
 101dd4f:	movq   $0x0,0x30(%rcx)
 101dd57:	movq   $0x0,0x28(%rcx)
 101dd5f:	movq   $0x0,0x20(%rcx)
 101dd67:	movq   $0x0,0x18(%rcx)
 101dd6f:	movq   $0x0,0x10(%rcx)
 101dd77:	movq   $0x0,0x8(%rcx)
 101dd7f:	movq   $0x0,(%rcx)
 101dd86:	jmp    101dd9f <flat_transfer+0x4df>
 101dd88:	mov    %rdi,%rbx
 101dd8b:	mov    %rdx,%rdi
 101dd8e:	mov    %rcx,%rsi
 101dd91:	mov    %r12,%rdx
 101dd94:	vzeroupper
 101dd97:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101dd9c:	mov    %rbx,%rdi
 101dd9f:	mov    0x1608(%rdi),%rcx
 101dda6:	xor    %eax,%eax
 101dda8:	cmpq   $0x0,0xc8(%rcx)
 101ddb0:	je     101ddbe <flat_transfer+0x4fe>
 101ddb2:	mov    %eax,%ebx
 101ddb4:	vzeroupper
 101ddb7:	call   1016210 <myl_rc_drain>
 101ddbc:	mov    %ebx,%eax
 101ddbe:	add    $0x98,%rsp
 101ddc5:	pop    %rbx
 101ddc6:	pop    %r12
 101ddc8:	pop    %r13
 101ddca:	pop    %r14
 101ddcc:	pop    %r15
 101ddce:	pop    %rbp
 101ddcf:	vzeroupper
 101ddd2:	ret
 101ddd3:	vzeroupper
 101ddd6:	call   101267d <myl_rc_invariant_failed>
 101dddb:	int3
 101dddc:	int3
 101dddd:	int3
 101ddde:	int3
 101dddf:	int3

000000000101dde0 <myl_rc_native_take>:
 101dde0:	push   %rbp
 101dde1:	mov    %rsp,%rbp
 101dde4:	push   %r15
 101dde6:	push   %r14
 101dde8:	push   %r13
 101ddea:	push   %r12
 101ddec:	push   %rbx
 101dded:	sub    $0xd8,%rsp
 101ddf4:	mov    %rcx,%r12
 101ddf7:	mov    %rdx,%r14
 101ddfa:	mov    %rsi,%r15
 101ddfd:	movzwl 0x30(%rsi),%eax
 101de01:	cmp    $0x7,%eax
 101de04:	je     101de0a <myl_rc_native_take+0x2a>
 101de06:	test   %eax,%eax
 101de08:	jne    101de39 <myl_rc_native_take+0x59>
 101de0a:	mov    (%r15),%rdx
 101de0d:	mov    %r14,%rdi
 101de10:	mov    %r12,%rsi
 101de13:	call   101e820 <compiler_rt.memmove.memmoveFast>
 101de18:	mov    $0x1,%r13d
 101de1e:	cmp    %r12,%r14
 101de21:	je     101e065 <myl_rc_native_take+0x285>
 101de27:	mov    (%r15),%rdx
 101de2a:	mov    %r12,%rdi
 101de2d:	xor    %esi,%esi
 101de2f:	call   101e6b0 <compiler_rt.fastMemset>
 101de34:	jmp    101e065 <myl_rc_native_take+0x285>
 101de39:	mov    0x1608(%rdi),%rcx
 101de40:	mov    0x34(%r15),%eax
 101de44:	cmp    %rax,0xa0(%rcx)
 101de4b:	jbe    101dffe <myl_rc_native_take+0x21e>
 101de51:	mov    0x98(%rcx),%rcx
 101de58:	shl    $0x4,%rax
 101de5c:	cmp    %r15,(%rcx,%rax,1)
 101de60:	jne    101dffe <myl_rc_native_take+0x21e>
 101de66:	add    %rax,%rcx
 101de69:	mov    0x8(%rcx),%rbx
 101de6d:	test   %rbx,%rbx
 101de70:	je     101e012 <myl_rc_native_take+0x232>
 101de76:	mov    0x8(%rbx),%rsi
 101de7a:	cmpl   $0x1,0x8(%rsi)
 101de7e:	jne    101deb2 <myl_rc_native_take+0xd2>
 101de80:	movq   $0x0,-0x100(%rbp)
 101de8b:	lea    -0x100(%rbp),%rdx
 101de92:	mov    $0x1,%r13d
 101de98:	mov    %r12,%rcx
 101de9b:	mov    %rdi,%rbx
 101de9e:	mov    $0x1,%r9d
 101dea4:	call   1019ed0 <myl_rc_pointer_transfer>
 101dea9:	test   %eax,%eax
 101deab:	je     101df28 <myl_rc_native_take+0x148>
 101dead:	mov    %rbx,%rdi
 101deb0:	jmp    101df04 <myl_rc_native_take+0x124>
 101deb2:	mov    %rsi,-0x40(%rbp)
 101deb6:	cmp    %r12,%r14
 101deb9:	mov    %rdi,-0x38(%rbp)
 101debd:	je     101df13 <myl_rc_native_take+0x133>
 101debf:	mov    0x1608(%rdi),%rax
 101dec6:	cmpq   $0x0,0xc8(%rax)
 101dece:	jne    101df13 <myl_rc_native_take+0x133>
 101ded0:	mov    $0x1,%r13d
 101ded6:	mov    %rbx,%rsi
 101ded9:	mov    %r14,%rdx
 101dedc:	mov    %r12,%rcx
 101dedf:	mov    %r8d,-0x2c(%rbp)
 101dee3:	mov    -0x2c(%rbp),%r8d
 101dee7:	mov    $0x1,%r9d
 101deed:	call   101d8c0 <flat_transfer>
 101def2:	mov    -0x38(%rbp),%rdi
 101def6:	mov    -0x2c(%rbp),%r8d
 101defa:	test   %eax,%eax
 101defc:	js     101df13 <myl_rc_native_take+0x133>
 101defe:	je     101e065 <myl_rc_native_take+0x285>
 101df04:	mov    %eax,%esi
 101df06:	call   1012770 <myl_rc_record_failure>
 101df0b:	xor    %r13d,%r13d
 101df0e:	jmp    101e065 <myl_rc_native_take+0x285>
 101df13:	mov    (%r15),%rsi
 101df16:	cmp    $0x81,%rsi
 101df1d:	jae    101df37 <myl_rc_native_take+0x157>
 101df1f:	lea    -0x100(%rbp),%rax
 101df26:	jmp    101df56 <myl_rc_native_take+0x176>
 101df28:	mov    -0x100(%rbp),%rax
 101df2f:	mov    %rax,(%r14)
 101df32:	jmp    101e065 <myl_rc_native_take+0x285>
 101df37:	xor    %r13d,%r13d
 101df3a:	xor    %edx,%edx
 101df3c:	mov    %r8d,-0x2c(%rbp)
 101df40:	call   101c8e0 <myl_rc_storage_bytes>
 101df45:	mov    -0x38(%rbp),%rdi
 101df49:	mov    -0x2c(%rbp),%r8d
 101df4d:	test   %rax,%rax
 101df50:	je     101e065 <myl_rc_native_take+0x285>
 101df56:	mov    -0x40(%rbp),%rcx
 101df5a:	mov    %rcx,-0x80(%rbp)
 101df5e:	mov    %rax,-0x78(%rbp)
 101df62:	movq   $0x0,-0x70(%rbp)
 101df6a:	mov    %r8d,-0x68(%rbp)
 101df6e:	movl   $0x0,-0x64(%rbp)
 101df75:	mov    %rcx,-0x60(%rbp)
 101df79:	mov    %r12,-0x58(%rbp)
 101df7d:	movq   $0x0,-0x50(%rbp)
 101df85:	mov    %r8d,-0x48(%rbp)
 101df89:	movl   $0x0,-0x44(%rbp)
 101df90:	mov    %rbx,%rsi
 101df93:	mov    %rax,%rbx
 101df96:	mov    %rax,%rdx
 101df99:	mov    %r12,%rcx
 101df9c:	mov    $0x1,%r9d
 101dfa2:	call   101d8c0 <flat_transfer>
 101dfa7:	test   %eax,%eax
 101dfa9:	jns    101dfbc <myl_rc_native_take+0x1dc>
 101dfab:	lea    -0x80(%rbp),%rsi
 101dfaf:	lea    -0x60(%rbp),%rdx
 101dfb3:	mov    -0x38(%rbp),%rdi
 101dfb7:	call   101a7f0 <myl_rc_value_take>
 101dfbc:	test   %eax,%eax
 101dfbe:	je     101dfd0 <myl_rc_native_take+0x1f0>
 101dfc0:	mov    -0x38(%rbp),%rdi
 101dfc4:	mov    %eax,%esi
 101dfc6:	call   1012770 <myl_rc_record_failure>
 101dfcb:	xor    %r13d,%r13d
 101dfce:	jmp    101dfe4 <myl_rc_native_take+0x204>
 101dfd0:	mov    (%r15),%rdx
 101dfd3:	mov    %r14,%rdi
 101dfd6:	mov    %rbx,%rsi
 101dfd9:	call   101e820 <compiler_rt.memmove.memmoveFast>
 101dfde:	mov    $0x1,%r13d
 101dfe4:	lea    -0x100(%rbp),%rax
 101dfeb:	cmp    %rax,%rbx
 101dfee:	je     101e065 <myl_rc_native_take+0x285>
 101dff0:	mov    -0x38(%rbp),%rdi
 101dff4:	mov    %rbx,%rsi
 101dff7:	call   1012cd0 <myl_rc_owner_release>
 101dffc:	jmp    101e065 <myl_rc_native_take+0x285>
 101dffe:	mov    %r15,%rsi
 101e001:	call   10130fa <myl_rc_binding_find_slow>
 101e006:	mov    %rax,%rbx
 101e009:	test   %rbx,%rbx
 101e00c:	jne    101de76 <myl_rc_native_take+0x96>
 101e012:	mov    %r8d,-0x2c(%rbp)
 101e016:	mov    %r15,%rsi
 101e019:	mov    %rdi,%rbx
 101e01c:	call   101d7b0 <myl_rc_native_shape>
 101e021:	xor    %r13d,%r13d
 101e024:	test   %rax,%rax
 101e027:	je     101e065 <myl_rc_native_take+0x285>
 101e029:	mov    0x1608(%rbx),%rcx
 101e030:	mov    0x34(%r15),%eax
 101e034:	cmp    %rax,0xa0(%rcx)
 101e03b:	mov    %rbx,%rdi
 101e03e:	jbe    101e07a <myl_rc_native_take+0x29a>
 101e040:	mov    0x98(%rcx),%rcx
 101e047:	shl    $0x4,%rax
 101e04b:	cmp    %r15,(%rcx,%rax,1)
 101e04f:	jne    101e07a <myl_rc_native_take+0x29a>
 101e051:	add    %rax,%rcx
 101e054:	mov    0x8(%rcx),%rbx
 101e058:	mov    -0x2c(%rbp),%r8d
 101e05c:	test   %rbx,%rbx
 101e05f:	jne    101de76 <myl_rc_native_take+0x96>
 101e065:	mov    %r13d,%eax
 101e068:	add    $0xd8,%rsp
 101e06f:	pop    %rbx
 101e070:	pop    %r12
 101e072:	pop    %r13
 101e074:	pop    %r14
 101e076:	pop    %r15
 101e078:	pop    %rbp
 101e079:	ret
 101e07a:	mov    %r15,%rsi
 101e07d:	call   10130fa <myl_rc_binding_find_slow>
 101e082:	mov    %rax,%rbx
 101e085:	jmp    101e058 <myl_rc_native_take+0x278>
 101e087:	int3
 101e088:	int3
 101e089:	int3
 101e08a:	int3
 101e08b:	int3
 101e08c:	int3
 101e08d:	int3
 101e08e:	int3
 101e08f:	int3

000000000101e090 <myl_rc_native_mutable>:
 101e090:	push   %rbp
 101e091:	mov    %rsp,%rbp
 101e094:	push   %rbx
 101e095:	push   %rax
 101e096:	mov    %rdi,%rbx
 101e099:	call   1011af0 <myl_native_list_header>
 101e09e:	mov    %eax,%ecx
 101e0a0:	mov    $0x1,%eax
 101e0a5:	test   %ecx,%ecx
 101e0a7:	jne    101e0ba <myl_rc_native_mutable+0x2a>
 101e0a9:	mov    %rbx,%rdi
 101e0ac:	call   10125a0 <myl_native_dictionary_header>
 101e0b1:	mov    %eax,%ecx
 101e0b3:	xor    %eax,%eax
 101e0b5:	test   %ecx,%ecx
 101e0b7:	setne  %al
 101e0ba:	add    $0x8,%rsp
 101e0be:	pop    %rbx
 101e0bf:	pop    %rbp
 101e0c0:	ret
 101e0c1:	int3
 101e0c2:	int3
 101e0c3:	int3
 101e0c4:	int3
 101e0c5:	int3
 101e0c6:	int3
 101e0c7:	int3
 101e0c8:	int3
 101e0c9:	int3
 101e0ca:	int3
 101e0cb:	int3
 101e0cc:	int3
 101e0cd:	int3
 101e0ce:	int3
 101e0cf:	int3

000000000101e0d0 <myl_rc_native_retain>:
 101e0d0:	push   %rbp
 101e0d1:	mov    %rsp,%rbp
 101e0d4:	push   %r15
 101e0d6:	push   %r14
 101e0d8:	push   %r13
 101e0da:	push   %r12
 101e0dc:	push   %rbx
 101e0dd:	sub    $0x48,%rsp
 101e0e1:	mov    %rdx,%r14
 101e0e4:	mov    %rsi,%r12
 101e0e7:	mov    0x1608(%rdi),%rdx
 101e0ee:	mov    0x34(%rsi),%eax
 101e0f1:	cmp    %rax,0xa0(%rdx)
 101e0f8:	mov    %rdi,-0x30(%rbp)
 101e0fc:	jbe    101e4f5 <myl_rc_native_retain+0x425>
 101e102:	mov    0x98(%rdx),%rdx
 101e109:	shl    $0x4,%rax
 101e10d:	cmp    %r12,(%rdx,%rax,1)
 101e111:	jne    101e4f5 <myl_rc_native_retain+0x425>
 101e117:	add    %rax,%rdx
 101e11a:	mov    0x8(%rdx),%rsi
 101e11e:	test   %rsi,%rsi
 101e121:	je     101e511 <myl_rc_native_retain+0x441>
 101e127:	cmpl   $0x0,0x40(%rsi)
 101e12b:	jne    101e142 <myl_rc_native_retain+0x72>
 101e12d:	mov    0x1608(%rdi),%rax
 101e134:	cmpq   $0x0,0xc8(%rax)
 101e13c:	je     101e1f9 <myl_rc_native_retain+0x129>
 101e142:	mov    0x50(%rsi),%r13
 101e146:	cmpb   $0x0,0x44(%rsi)
 101e14a:	setne  %al
 101e14d:	test   %r13,%r13
 101e150:	setne  %dl
 101e153:	and    %al,%dl
 101e155:	cmp    $0x1,%dl
 101e158:	jne    101e19d <myl_rc_native_retain+0xcd>
 101e15a:	mov    0x1608(%rdi),%rax
 101e161:	test   %rax,%rax
 101e164:	je     101e5d0 <myl_rc_native_retain+0x500>
 101e16a:	test   %rcx,%rcx
 101e16d:	je     101e5d0 <myl_rc_native_retain+0x500>
 101e173:	test   %r14,%r14
 101e176:	je     101e5d0 <myl_rc_native_retain+0x500>
 101e17c:	cmpq   $0x0,0xc0(%rax)
 101e184:	jne    101e5d0 <myl_rc_native_retain+0x500>
 101e18a:	mov    %r14,%rax
 101e18d:	sub    %rcx,%rax
 101e190:	ja     101e198 <myl_rc_native_retain+0xc8>
 101e192:	mov    %rcx,%rax
 101e195:	sub    %r14,%rax
 101e198:	cmp    %r13,%rax
 101e19b:	jae    101e1c2 <myl_rc_native_retain+0xf2>
 101e19d:	mov    0x8(%rsi),%r13
 101e1a1:	test   %r13,%r13
 101e1a4:	je     101e5a5 <myl_rc_native_retain+0x4d5>
 101e1aa:	mov    %rcx,%rbx
 101e1ad:	mov    %r8d,%r15d
 101e1b0:	call   1016be0 <myl_rc_binding_has_unique>
 101e1b5:	test   %eax,%eax
 101e1b7:	je     101e53f <myl_rc_native_retain+0x46f>
 101e1bd:	jmp    101e5d0 <myl_rc_native_retain+0x500>
 101e1c2:	cmp    0x70(%rdi),%r8d
 101e1c6:	jbe    101e244 <myl_rc_native_retain+0x174>
 101e1c8:	mov    %r14,%rdi
 101e1cb:	xor    %esi,%esi
 101e1cd:	mov    %r13,%rdx
 101e1d0:	call   101e6b0 <compiler_rt.fastMemset>
 101e1d5:	mov    -0x30(%rbp),%rdi
 101e1d9:	mov    0x1608(%rdi),%rax
 101e1e0:	mov    $0x3,%r12d
 101e1e6:	cmpq   $0x0,0xc8(%rax)
 101e1ee:	jne    101e41e <myl_rc_native_retain+0x34e>
 101e1f4:	jmp    101e434 <myl_rc_native_retain+0x364>
 101e1f9:	mov    (%r12),%rdx
 101e1fd:	test   %rdx,%rdx
 101e200:	je     101e142 <myl_rc_native_retain+0x72>
 101e206:	mov    %r14,%rax
 101e209:	sub    %rcx,%rax
 101e20c:	ja     101e214 <myl_rc_native_retain+0x144>
 101e20e:	mov    %rcx,%rax
 101e211:	sub    %r14,%rax
 101e214:	cmp    %rdx,%rax
 101e217:	jb     101e142 <myl_rc_native_retain+0x72>
 101e21d:	cmp    0x70(%rdi),%r8d
 101e221:	jbe    101e444 <myl_rc_native_retain+0x374>
 101e227:	xor    %r12d,%r12d
 101e22a:	mov    %rdi,%rbx
 101e22d:	mov    %r14,%rdi
 101e230:	xor    %esi,%esi
 101e232:	call   101e6b0 <compiler_rt.fastMemset>
 101e237:	mov    %rbx,%rdi
 101e23a:	mov    $0x3,%esi
 101e23f:	jmp    101e59e <myl_rc_native_retain+0x4ce>
 101e244:	cmp    $0x61,%r13
 101e248:	setae  %al
 101e24b:	test   $0x7,%r13b
 101e24f:	setne  %dl
 101e252:	or     %al,%dl
 101e254:	jne    101e2f7 <myl_rc_native_retain+0x227>
 101e25a:	mov    %r13,%rax
 101e25d:	shr    $0x3,%rax
 101e261:	dec    %rax
 101e264:	cmp    $0xb,%rax
 101e268:	ja     101e2d8 <myl_rc_native_retain+0x208>
 101e26a:	lea    -0x1ac01(%rip),%rdx        # 1003670 <raw_shape+0xb8>
 101e271:	movslq (%rdx,%rax,4),%rax
 101e275:	add    %rdx,%rax
 101e278:	jmp    *%rax
 101e27a:	mov    0x58(%rcx),%rax
 101e27e:	mov    %rax,0x58(%r14)
 101e282:	mov    0x50(%rcx),%rax
 101e286:	mov    %rax,0x50(%r14)
 101e28a:	mov    0x48(%rcx),%rax
 101e28e:	mov    %rax,0x48(%r14)
 101e292:	mov    0x40(%rcx),%rax
 101e296:	mov    %rax,0x40(%r14)
 101e29a:	mov    0x38(%rcx),%rax
 101e29e:	mov    %rax,0x38(%r14)
 101e2a2:	mov    0x30(%rcx),%rax
 101e2a6:	mov    %rax,0x30(%r14)
 101e2aa:	mov    0x28(%rcx),%rax
 101e2ae:	mov    %rax,0x28(%r14)
 101e2b2:	mov    0x20(%rcx),%rax
 101e2b6:	mov    %rax,0x20(%r14)
 101e2ba:	mov    0x18(%rcx),%rax
 101e2be:	mov    %rax,0x18(%r14)
 101e2c2:	mov    0x10(%rcx),%rax
 101e2c6:	mov    %rax,0x10(%r14)
 101e2ca:	mov    0x8(%rcx),%rax
 101e2ce:	mov    %rax,0x8(%r14)
 101e2d2:	mov    (%rcx),%rax
 101e2d5:	mov    %rax,(%r14)
 101e2d8:	cmpb   $0x0,0x46(%rsi)
 101e2dc:	je     101e327 <myl_rc_native_retain+0x257>
 101e2de:	mov    0x48(%rsi),%eax
 101e2e1:	mov    (%rcx,%rax,1),%eax
 101e2e4:	lea    0x5a(%rsi),%rdx
 101e2e8:	cmp    $0x20,%rax
 101e2ec:	lea    0x5c(%rsi,%rax,2),%rax
 101e2f1:	cmovae %rdx,%rax
 101e2f5:	jmp    101e32b <myl_rc_native_retain+0x25b>
 101e2f7:	mov    %r14,%rdi
 101e2fa:	mov    %rsi,%r12
 101e2fd:	mov    %rcx,%rsi
 101e300:	mov    %r13,%rdx
 101e303:	mov    %r14,%rbx
 101e306:	mov    %rcx,%r14
 101e309:	mov    %r8d,%r15d
 101e30c:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101e311:	mov    -0x30(%rbp),%rdi
 101e315:	mov    %r15d,%r8d
 101e318:	mov    %r14,%rcx
 101e31b:	mov    %rbx,%r14
 101e31e:	mov    %r12,%rsi
 101e321:	cmpb   $0x0,0x46(%rsi)
 101e325:	jne    101e2de <myl_rc_native_retain+0x20e>
 101e327:	lea    0x58(%rsi),%rax
 101e32b:	movzwl (%rax),%eax
 101e32e:	xor    %r12d,%r12d
 101e331:	test   %eax,%eax
 101e333:	je     101e40d <myl_rc_native_retain+0x33d>
 101e339:	movabs $0x4000000000000000,%r11
 101e343:	lea    0x2(%r11),%rdx
 101e347:	jmp    101e366 <myl_rc_native_retain+0x296>
 101e349:	cmpq   $0x0,-0x18(%rdi)
 101e34e:	je     101e5d0 <myl_rc_native_retain+0x500>
 101e354:	inc    %r9
 101e357:	mov    %r9,-0x20(%rdi)
 101e35b:	blsr   %eax,%eax
 101e360:	je     101e409 <myl_rc_native_retain+0x339>
 101e366:	tzcnt  %eax,%edi
 101e36a:	movzwl 0x9c(%rsi,%rdi,2),%edi
 101e372:	mov    (%rcx,%rdi,1),%rdi
 101e376:	test   %rdi,%rdi
 101e379:	je     101e35b <myl_rc_native_retain+0x28b>
 101e37b:	mov    -0x10(%rdi),%r10
 101e37f:	test   %r11,%r10
 101e382:	je     101e397 <myl_rc_native_retain+0x2c7>
 101e384:	mov    %r10,%r9
 101e387:	shr    $0x28,%r9
 101e38b:	and    $0xfffff,%r9d
 101e392:	cmp    %r8d,%r9d
 101e395:	ja     101e3bd <myl_rc_native_retain+0x2ed>
 101e397:	test   %rdx,%r10
 101e39a:	jne    101e35b <myl_rc_native_retain+0x28b>
 101e39c:	test   $0x1,%r10b
 101e3a0:	jne    101e5d0 <myl_rc_native_retain+0x500>
 101e3a6:	mov    -0x20(%rdi),%r9
 101e3aa:	test   %r9,%r9
 101e3ad:	je     101e349 <myl_rc_native_retain+0x279>
 101e3af:	cmp    $0xffffffffffffffff,%r9
 101e3b3:	jne    101e354 <myl_rc_native_retain+0x284>
 101e3b5:	mov    $0x2,%r12d
 101e3bb:	jmp    101e3d0 <myl_rc_native_retain+0x300>
 101e3bd:	mov    $0x3,%r12d
 101e3c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101e3d0:	tzcnt  %eax,%ecx
 101e3d4:	movzwl 0x9c(%rsi,%rcx,2),%ecx
 101e3dc:	movq   $0x0,(%r14,%rcx,1)
 101e3e4:	blsr   %eax,%eax
 101e3e9:	jne    101e3d0 <myl_rc_native_retain+0x300>
 101e3eb:	mov    $0x1,%ecx
 101e3f0:	mov    -0x30(%rbp),%rdi
 101e3f4:	mov    %r14,%rdx
 101e3f7:	call   1016060 <myl_rc_flat_edges_release>
 101e3fc:	mov    %r14,%rdi
 101e3ff:	xor    %esi,%esi
 101e401:	mov    %r13,%rdx
 101e404:	call   101e6b0 <compiler_rt.fastMemset>
 101e409:	mov    -0x30(%rbp),%rdi
 101e40d:	mov    0x1608(%rdi),%rax
 101e414:	cmpq   $0x0,0xc8(%rax)
 101e41c:	je     101e42b <myl_rc_native_retain+0x35b>
 101e41e:	mov    -0x30(%rbp),%rdi
 101e422:	call   1016210 <myl_rc_drain>
 101e427:	mov    -0x30(%rbp),%rdi
 101e42b:	test   %r12d,%r12d
 101e42e:	je     101e5b8 <myl_rc_native_retain+0x4e8>
 101e434:	mov    %r12d,%esi
 101e437:	call   1012770 <myl_rc_record_failure>
 101e43c:	xor    %r12d,%r12d
 101e43f:	jmp    101e5be <myl_rc_native_retain+0x4ee>
 101e444:	cmp    $0x61,%rdx
 101e448:	setae  %al
 101e44b:	test   $0x7,%dl
 101e44e:	setne  %sil
 101e452:	or     %al,%sil
 101e455:	jne    101e4e5 <myl_rc_native_retain+0x415>
 101e45b:	shr    $0x3,%rdx
 101e45f:	mov    $0x1,%r12d
 101e465:	dec    %rdx
 101e468:	cmp    $0xb,%rdx
 101e46c:	ja     101e5be <myl_rc_native_retain+0x4ee>
 101e472:	lea    -0x1ae39(%rip),%rax        # 1003640 <raw_shape+0x88>
 101e479:	movslq (%rax,%rdx,4),%rdx
 101e47d:	add    %rax,%rdx
 101e480:	jmp    *%rdx
 101e482:	mov    0x58(%rcx),%rax
 101e486:	mov    %rax,0x58(%r14)
 101e48a:	mov    0x50(%rcx),%rax
 101e48e:	mov    %rax,0x50(%r14)
 101e492:	mov    0x48(%rcx),%rax
 101e496:	mov    %rax,0x48(%r14)
 101e49a:	mov    0x40(%rcx),%rax
 101e49e:	mov    %rax,0x40(%r14)
 101e4a2:	mov    0x38(%rcx),%rax
 101e4a6:	mov    %rax,0x38(%r14)
 101e4aa:	mov    0x30(%rcx),%rax
 101e4ae:	mov    %rax,0x30(%r14)
 101e4b2:	mov    0x28(%rcx),%rax
 101e4b6:	mov    %rax,0x28(%r14)
 101e4ba:	mov    0x20(%rcx),%rax
 101e4be:	mov    %rax,0x20(%r14)
 101e4c2:	mov    0x18(%rcx),%rax
 101e4c6:	mov    %rax,0x18(%r14)
 101e4ca:	mov    0x10(%rcx),%rax
 101e4ce:	mov    %rax,0x10(%r14)
 101e4d2:	mov    0x8(%rcx),%rax
 101e4d6:	mov    %rax,0x8(%r14)
 101e4da:	mov    (%rcx),%rax
 101e4dd:	mov    %rax,(%r14)
 101e4e0:	jmp    101e5be <myl_rc_native_retain+0x4ee>
 101e4e5:	mov    %r14,%rdi
 101e4e8:	mov    %rcx,%rsi
 101e4eb:	call   101ebb0 <compiler_rt.memcpy.memcpyFast>
 101e4f0:	jmp    101e5b8 <myl_rc_native_retain+0x4e8>
 101e4f5:	mov    -0x30(%rbp),%rdi
 101e4f9:	mov    %r12,%rsi
 101e4fc:	call   10130fa <myl_rc_binding_find_slow>
 101e501:	mov    -0x30(%rbp),%rdi
 101e505:	mov    %rax,%rsi
 101e508:	test   %rsi,%rsi
 101e50b:	jne    101e127 <myl_rc_native_retain+0x57>
 101e511:	mov    %rcx,%rbx
 101e514:	mov    %r8d,%r15d
 101e517:	mov    -0x30(%rbp),%rdi
 101e51b:	mov    %r12,%rsi
 101e51e:	call   101d7b0 <myl_rc_native_shape>
 101e523:	mov    -0x30(%rbp),%rdi
 101e527:	test   %rax,%rax
 101e52a:	je     101e5a5 <myl_rc_native_retain+0x4d5>
 101e52c:	mov    %rax,%r13
 101e52f:	mov    %r12,%rsi
 101e532:	call   1016a10 <myl_rc_native_has_unique>
 101e537:	test   %eax,%eax
 101e539:	jne    101e5d0 <myl_rc_native_retain+0x500>
 101e53f:	mov    (%r12),%rdx
 101e543:	xor    %r12d,%r12d
 101e546:	mov    %r14,%rdi
 101e549:	xor    %esi,%esi
 101e54b:	call   101e6b0 <compiler_rt.fastMemset>
 101e550:	mov    %r13,-0x50(%rbp)
 101e554:	mov    %r14,-0x48(%rbp)
 101e558:	movq   $0x0,-0x40(%rbp)
 101e560:	mov    %r15d,-0x38(%rbp)
 101e564:	movl   $0x0,-0x34(%rbp)
 101e56b:	mov    %r13,-0x70(%rbp)
 101e56f:	mov    %rbx,-0x68(%rbp)
 101e573:	vxorps %xmm0,%xmm0,%xmm0
 101e577:	vmovups %xmm0,-0x60(%rbp)
 101e57c:	lea    -0x50(%rbp),%rsi
 101e580:	lea    -0x70(%rbp),%rdx
 101e584:	mov    $0x1,%ecx
 101e589:	mov    -0x30(%rbp),%rbx
 101e58d:	mov    %rbx,%rdi
 101e590:	call   101a7e0 <myl_rc_value_retain_many>
 101e595:	test   %eax,%eax
 101e597:	je     101e5b8 <myl_rc_native_retain+0x4e8>
 101e599:	mov    %rbx,%rdi
 101e59c:	mov    %eax,%esi
 101e59e:	call   1012770 <myl_rc_record_failure>
 101e5a3:	jmp    101e5be <myl_rc_native_retain+0x4ee>
 101e5a5:	mov    (%r12),%rdx
 101e5a9:	xor    %r12d,%r12d
 101e5ac:	mov    %r14,%rdi
 101e5af:	xor    %esi,%esi
 101e5b1:	call   101e6b0 <compiler_rt.fastMemset>
 101e5b6:	jmp    101e5be <myl_rc_native_retain+0x4ee>
 101e5b8:	mov    $0x1,%r12d
 101e5be:	mov    %r12d,%eax
 101e5c1:	add    $0x48,%rsp
 101e5c5:	pop    %rbx
 101e5c6:	pop    %r12
 101e5c8:	pop    %r13
 101e5ca:	pop    %r14
 101e5cc:	pop    %r15
 101e5ce:	pop    %rbp
 101e5cf:	ret
 101e5d0:	call   101267d <myl_rc_invariant_failed>
 101e5d5:	int3
 101e5d6:	int3
 101e5d7:	int3
 101e5d8:	int3
 101e5d9:	int3
 101e5da:	int3
 101e5db:	int3
 101e5dc:	int3
 101e5dd:	int3
 101e5de:	int3
 101e5df:	int3

000000000101e5e0 <myl_rc_native_storage>:
 101e5e0:	push   %rbp
 101e5e1:	mov    %rsp,%rbp
 101e5e4:	mov    %rdx,%r8
 101e5e7:	mov    (%rsi),%rsi
 101e5ea:	test   %rsi,%rsi
 101e5ed:	je     101e5fb <myl_rc_native_storage+0x1b>
 101e5ef:	mov    %rsi,%rax
 101e5f2:	mul    %r8
 101e5f5:	jno    101e5fb <myl_rc_native_storage+0x1b>
 101e5f7:	xor    %eax,%eax
 101e5f9:	pop    %rbp
 101e5fa:	ret
 101e5fb:	imul   %r8,%rsi
 101e5ff:	mov    %ecx,%edx
 101e601:	pop    %rbp
 101e602:	jmp    101c8e0 <myl_rc_storage_bytes>
 101e607:	int3
 101e608:	int3
 101e609:	int3
 101e60a:	int3
 101e60b:	int3
 101e60c:	int3
 101e60d:	int3
 101e60e:	int3
 101e60f:	int3

000000000101e610 <myl_rc_native_result>:
 101e610:	xor    %eax,%eax
 101e612:	test   %rsi,%rsi
 101e615:	je     101e618 <myl_rc_native_result+0x8>
 101e617:	ret
 101e618:	push   %rbp
 101e619:	mov    %rsp,%rbp
 101e61c:	push   %r14
 101e61e:	push   %rbx
 101e61f:	mov    %rdi,%rbx
 101e622:	call   10127a0 <myl_rc_take_failure>
 101e627:	mov    %eax,%r14d
 101e62a:	cmp    $0x1,%eax
 101e62d:	adc    $0x0,%r14d
 101e631:	mov    %rbx,%rdi
 101e634:	mov    %r14d,%esi
 101e637:	call   1012770 <myl_rc_record_failure>
 101e63c:	mov    %r14d,%eax
 101e63f:	pop    %rbx
 101e640:	pop    %r14
 101e642:	pop    %rbp
 101e643:	ret
 101e644:	int3
 101e645:	int3
 101e646:	int3
 101e647:	int3
 101e648:	int3
 101e649:	int3
 101e64a:	int3
 101e64b:	int3
 101e64c:	int3
 101e64d:	int3
 101e64e:	int3
 101e64f:	int3

000000000101e650 <myl_rc_native_abort>:
 101e650:	push   %rbp
 101e651:	mov    %rsp,%rbp
 101e654:	pop    %rbp
 101e655:	jmp    1016ee0 <myl_rc_construction_abort>
 101e65a:	int3
 101e65b:	int3
 101e65c:	int3
 101e65d:	int3
 101e65e:	int3
 101e65f:	int3

000000000101e660 <compiler_rt.strlen>:
 101e660:	push   %rbp
 101e661:	mov    %rsp,%rbp
 101e664:	mov    $0xffffffffffffffff,%rax
 101e66b:	nopl   0x0(%rax,%rax,1)
 101e670:	cmpb   $0x0,0x1(%rdi,%rax,1)
 101e675:	lea    0x1(%rax),%rax
 101e679:	jne    101e670 <compiler_rt.strlen+0x10>
 101e67b:	pop    %rbp
 101e67c:	ret
 101e67d:	int3
 101e67e:	int3
 101e67f:	int3

000000000101e680 <bcmp>:
 101e680:	push   %rbp
 101e681:	mov    %rsp,%rbp
 101e684:	test   %rdx,%rdx
 101e687:	je     101e6a1 <bcmp+0x21>
 101e689:	xor    %eax,%eax
 101e68b:	nopl   0x0(%rax,%rax,1)
 101e690:	movzbl (%rdi,%rax,1),%ecx
 101e694:	cmp    (%rsi,%rax,1),%cl
 101e697:	jne    101e6a5 <bcmp+0x25>
 101e699:	inc    %rax
 101e69c:	cmp    %rax,%rdx
 101e69f:	jne    101e690 <bcmp+0x10>
 101e6a1:	xor    %eax,%eax
 101e6a3:	pop    %rbp
 101e6a4:	ret
 101e6a5:	mov    $0x1,%eax
 101e6aa:	pop    %rbp
 101e6ab:	ret
 101e6ac:	int3
 101e6ad:	int3
 101e6ae:	int3
 101e6af:	int3

000000000101e6b0 <compiler_rt.fastMemset>:
 101e6b0:	mov    %rdi,%rax
 101e6b3:	cmp    $0x40,%rdx
 101e6b7:	jbe    101e6fb <compiler_rt.fastMemset+0x4b>
 101e6b9:	push   %rbp
 101e6ba:	mov    %rsp,%rbp
 101e6bd:	vmovd  %esi,%xmm0
 101e6c1:	vpbroadcastb %xmm0,%ymm0
 101e6c6:	vmovdqu %ymm0,(%rax)
 101e6ca:	mov    %rax,%rcx
 101e6cd:	and    $0xffffffffffffffe0,%rcx
 101e6d1:	lea    (%rax,%rdx,1),%rdi
 101e6d5:	sub    %rcx,%rdi
 101e6d8:	add    $0x20,%rcx
 101e6dc:	add    $0xffffffffffffffdf,%rdi
 101e6e0:	shr    $0x5,%rdi
 101e6e4:	lea    -0x1(%rdi),%r8
 101e6e8:	mov    %edi,%esi
 101e6ea:	and    $0x7,%esi
 101e6ed:	cmp    $0x7,%r8
 101e6f1:	jae    101e73d <compiler_rt.fastMemset+0x8d>
 101e6f3:	xor    %r8d,%r8d
 101e6f6:	jmp    101e79d <compiler_rt.fastMemset+0xed>
 101e6fb:	test   %rdx,%rdx
 101e6fe:	je     101e7c5 <compiler_rt.fastMemset+0x115>
 101e704:	cmp    $0x9,%rdx
 101e708:	jb     101e7c9 <compiler_rt.fastMemset+0x119>
 101e70e:	cmp    $0x11,%rdx
 101e712:	jb     101e7e6 <compiler_rt.fastMemset+0x136>
 101e718:	vmovd  %esi,%xmm0
 101e71c:	vpbroadcastb %xmm0,%xmm0
 101e721:	vmovdqu %xmm0,(%rax)
 101e725:	cmp    $0x21,%rdx
 101e729:	jb     101e736 <compiler_rt.fastMemset+0x86>
 101e72b:	vmovdqu %xmm0,0x10(%rax)
 101e730:	vmovdqu %xmm0,-0x20(%rax,%rdx,1)
 101e736:	vmovdqu %xmm0,-0x10(%rax,%rdx,1)
 101e73c:	ret
 101e73d:	and    $0xfffffffffffffff8,%rdi
 101e741:	lea    0xe0(%rcx),%r9
 101e748:	xor    %r8d,%r8d
 101e74b:	nopl   0x0(%rax,%rax,1)
 101e750:	vmovdqa %ymm0,-0xe0(%r9)
 101e759:	vmovdqa %ymm0,-0xc0(%r9)
 101e762:	vmovdqa %ymm0,-0xa0(%r9)
 101e76b:	vmovdqa %ymm0,-0x80(%r9)
 101e771:	vmovdqa %ymm0,-0x60(%r9)
 101e777:	vmovdqa %ymm0,-0x40(%r9)
 101e77d:	vmovdqa %ymm0,-0x20(%r9)
 101e783:	vmovdqa %ymm0,(%r9)
 101e788:	add    $0x8,%r8
 101e78c:	add    $0x100,%r9
 101e793:	cmp    %r8,%rdi
 101e796:	jne    101e750 <compiler_rt.fastMemset+0xa0>
 101e798:	test   %rsi,%rsi
 101e79b:	je     101e7be <compiler_rt.fastMemset+0x10e>
 101e79d:	shl    $0x5,%r8
 101e7a1:	add    %r8,%rcx
 101e7a4:	shl    $0x5,%esi
 101e7a7:	xor    %edi,%edi
 101e7a9:	nopl   0x0(%rax)
 101e7b0:	vmovdqa %ymm0,(%rcx,%rdi,1)
 101e7b5:	add    $0x20,%rdi
 101e7b9:	cmp    %rdi,%rsi
 101e7bc:	jne    101e7b0 <compiler_rt.fastMemset+0x100>
 101e7be:	vmovdqu %ymm0,-0x20(%rax,%rdx,1)
 101e7c4:	pop    %rbp
 101e7c5:	vzeroupper
 101e7c8:	ret
 101e7c9:	cmp    $0x3,%rdx
 101e7cd:	jb     101e801 <compiler_rt.fastMemset+0x151>
 101e7cf:	cmp    $0x5,%rdx
 101e7d3:	jb     101e80a <compiler_rt.fastMemset+0x15a>
 101e7d5:	movzbl %sil,%ecx
 101e7d9:	imul   $0x1010101,%ecx,%ecx
 101e7df:	mov    %ecx,(%rax)
 101e7e1:	mov    %ecx,-0x4(%rax,%rdx,1)
 101e7e5:	ret
 101e7e6:	movzbl %sil,%ecx
 101e7ea:	movabs $0x101010101010101,%rsi
 101e7f4:	imul   %rcx,%rsi
 101e7f8:	mov    %rsi,(%rax)
 101e7fb:	mov    %rsi,-0x8(%rax,%rdx,1)
 101e800:	ret
 101e801:	mov    %sil,(%rax)
 101e804:	mov    %sil,-0x1(%rax,%rdx,1)
 101e809:	ret
 101e80a:	movzbl %sil,%ecx
 101e80e:	shl    $0x8,%esi
 101e811:	or     %ecx,%esi
 101e813:	mov    %si,(%rax)
 101e816:	mov    %si,-0x2(%rax,%rdx,1)
 101e81b:	ret
 101e81c:	int3
 101e81d:	int3
 101e81e:	int3
 101e81f:	int3

000000000101e820 <compiler_rt.memmove.memmoveFast>:
 101e820:	mov    %rdi,%rax
 101e823:	cmp    $0xf,%rdx
 101e827:	ja     101e85c <compiler_rt.memmove.memmoveFast+0x3c>
 101e829:	cmp    $0x3,%rdx
 101e82d:	ja     101e8cf <compiler_rt.memmove.memmoveFast+0xaf>
 101e833:	test   %rdx,%rdx
 101e836:	je     101e8fb <compiler_rt.memmove.memmoveFast+0xdb>
 101e83c:	mov    %rdx,%rcx
 101e83f:	shr    $1,%rcx
 101e842:	movzbl (%rsi),%edi
 101e845:	movzbl (%rsi,%rcx,1),%r8d
 101e84a:	movzbl -0x1(%rsi,%rdx,1),%esi
 101e84f:	mov    %dil,(%rax)
 101e852:	mov    %r8b,(%rax,%rcx,1)
 101e856:	mov    %sil,-0x1(%rax,%rdx,1)
 101e85b:	ret
 101e85c:	push   %rbp
 101e85d:	mov    %rsp,%rbp
 101e860:	push   %r14
 101e862:	push   %rbx
 101e863:	sub    $0x40,%rsp
 101e867:	cmp    $0x3f,%rdx
 101e86b:	ja     101e8fc <compiler_rt.memmove.memmoveFast+0xdc>
 101e871:	mov    %edx,%ecx
 101e873:	shr    $1,%ecx
 101e875:	and    $0x10,%ecx
 101e878:	lea    -0x10(%rdx),%rdi
 101e87c:	sub    %rcx,%rdi
 101e87f:	vmovups (%rsi),%xmm0
 101e883:	vmovaps %xmm0,-0x50(%rbp)
 101e888:	vmovups (%rsi,%rcx,1),%xmm1
 101e88d:	vmovaps %xmm1,-0x20(%rbp)
 101e892:	vmovups (%rsi,%rdi,1),%xmm1
 101e897:	vmovaps %xmm1,-0x30(%rbp)
 101e89c:	vmovups -0x10(%rsi,%rdx,1),%xmm1
 101e8a2:	vmovaps %xmm1,-0x40(%rbp)
 101e8a7:	vmovups %xmm0,(%rax)
 101e8ab:	vmovaps -0x20(%rbp),%xmm0
 101e8b0:	vmovups %xmm0,(%rax,%rcx,1)
 101e8b5:	vmovaps -0x30(%rbp),%xmm0
 101e8ba:	vmovups %xmm0,(%rax,%rdi,1)
 101e8bf:	vmovaps -0x40(%rbp),%xmm0
 101e8c4:	vmovups %xmm0,-0x10(%rax,%rdx,1)
 101e8ca:	jmp    101eb9e <compiler_rt.memmove.memmoveFast+0x37e>
 101e8cf:	mov    %edx,%ecx
 101e8d1:	shr    $1,%ecx
 101e8d3:	and    $0x4,%ecx
 101e8d6:	lea    -0x4(%rdx),%rdi
 101e8da:	sub    %rcx,%rdi
 101e8dd:	mov    (%rsi),%r8d
 101e8e0:	mov    (%rsi,%rcx,1),%r9d
 101e8e4:	mov    (%rsi,%rdi,1),%r10d
 101e8e8:	mov    -0x4(%rsi,%rdx,1),%esi
 101e8ec:	mov    %r8d,(%rax)
 101e8ef:	mov    %r9d,(%rax,%rcx,1)
 101e8f3:	mov    %r10d,(%rax,%rdi,1)
 101e8f7:	mov    %esi,-0x4(%rax,%rdx,1)
 101e8fb:	ret
 101e8fc:	cmp    %rax,%rsi
 101e8ff:	jae    101ea53 <compiler_rt.memmove.memmoveFast+0x233>
 101e905:	lea    -0x20(%rdx),%rcx
 101e909:	vmovups -0x20(%rsi,%rdx,1),%ymm0
 101e90f:	vmovups %ymm0,-0x70(%rbp)
 101e914:	vmovups (%rsi),%ymm0
 101e918:	vmovups %ymm0,-0x90(%rbp)
 101e920:	add    %rax,%rdx
 101e923:	and    $0xffffffffffffffe0,%rdx
 101e927:	mov    %rdx,%r8
 101e92a:	sub    %rax,%r8
 101e92d:	mov    %r8,%r9
 101e930:	shr    $0x5,%r9
 101e934:	je     101ea38 <compiler_rt.memmove.memmoveFast+0x218>
 101e93a:	mov    %r9d,%edi
 101e93d:	and    $0x7,%edi
 101e940:	mov    $0x1,%r10d
 101e946:	cmp    $0x100,%r8
 101e94d:	jb     101ea07 <compiler_rt.memmove.memmoveFast+0x1e7>
 101e953:	lea    (%r8,%rsi,1),%r11
 101e957:	add    $0xffffffffffffffe0,%r11
 101e95b:	and    $0xfffffffffffffff8,%r9
 101e95f:	neg    %r9
 101e962:	mov    $0xffffffffffffffe0,%rbx
 101e969:	nopl   0x0(%rax)
 101e970:	vmovups 0x20(%r11,%rbx,1),%ymm0
 101e977:	vmovaps %ymm0,(%rdx,%rbx,1)
 101e97c:	vmovups (%r11,%rbx,1),%ymm0
 101e982:	vmovaps %ymm0,-0x20(%rdx,%rbx,1)
 101e988:	vmovups -0x20(%r11,%rbx,1),%ymm0
 101e98f:	vmovaps %ymm0,-0x40(%rdx,%rbx,1)
 101e995:	vmovups -0x40(%r11,%rbx,1),%ymm0
 101e99c:	vmovaps %ymm0,-0x60(%rdx,%rbx,1)
 101e9a2:	vmovups -0x60(%r11,%rbx,1),%ymm0
 101e9a9:	vmovaps %ymm0,-0x80(%rdx,%rbx,1)
 101e9af:	vmovups -0x80(%r11,%rbx,1),%ymm0
 101e9b6:	vmovaps %ymm0,-0xa0(%rdx,%rbx,1)
 101e9bf:	vmovups -0xa0(%r11,%rbx,1),%ymm0
 101e9c9:	vmovaps %ymm0,-0xc0(%rdx,%rbx,1)
 101e9d2:	vmovups -0xc0(%r11,%rbx,1),%ymm0
 101e9dc:	vmovaps %ymm0,-0xe0(%rdx,%rbx,1)
 101e9e5:	add    $0xffffffffffffff00,%rbx
 101e9ec:	lea    (%r9,%r10,1),%r14
 101e9f0:	add    $0x8,%r14
 101e9f4:	add    $0x8,%r10
 101e9f8:	cmp    $0x1,%r14
 101e9fc:	jne    101e970 <compiler_rt.memmove.memmoveFast+0x150>
 101ea02:	test   %rdi,%rdi
 101ea05:	je     101ea38 <compiler_rt.memmove.memmoveFast+0x218>
 101ea07:	shl    $0x5,%r10
 101ea0b:	sub    %r10,%r8
 101ea0e:	add    %r8,%rsi
 101ea11:	sub    %r10,%rdx
 101ea14:	shl    $0x5,%edi
 101ea17:	xor    %r8d,%r8d
 101ea1a:	nopw   0x0(%rax,%rax,1)
 101ea20:	vmovups (%rsi,%r8,1),%ymm0
 101ea26:	vmovaps %ymm0,(%rdx,%r8,1)
 101ea2c:	add    $0xffffffffffffffe0,%r8
 101ea30:	mov    %rdi,%r9
 101ea33:	add    %r8,%r9
 101ea36:	jne    101ea20 <compiler_rt.memmove.memmoveFast+0x200>
 101ea38:	vmovups -0x90(%rbp),%ymm0
 101ea40:	vmovups %ymm0,(%rax)
 101ea44:	vmovups -0x70(%rbp),%ymm0
 101ea49:	vmovups %ymm0,(%rax,%rcx,1)
 101ea4e:	jmp    101eb9e <compiler_rt.memmove.memmoveFast+0x37e>
 101ea53:	vmovups (%rsi),%ymm0
 101ea57:	vmovups %ymm0,-0xb0(%rbp)
 101ea5f:	lea    -0x20(%rdx),%rcx
 101ea63:	vmovups -0x20(%rsi,%rdx,1),%ymm0
 101ea69:	vmovups %ymm0,-0xd0(%rbp)
 101ea71:	mov    %esi,%edi
 101ea73:	and    $0x1f,%edi
 101ea76:	lea    (%rdx,%rdi,1),%r8
 101ea7a:	add    $0xffffffffffffffe0,%r8
 101ea7e:	shr    $0x5,%r8
 101ea82:	lea    -0x1(%r8),%r9
 101ea86:	mov    %r8d,%edx
 101ea89:	and    $0x7,%edx
 101ea8c:	cmp    $0x7,%r9
 101ea90:	jae    101ea9a <compiler_rt.memmove.memmoveFast+0x27a>
 101ea92:	xor    %r9d,%r9d
 101ea95:	jmp    101eb49 <compiler_rt.memmove.memmoveFast+0x329>
 101ea9a:	and    $0xfffffffffffffff8,%r8
 101ea9e:	mov    $0x100,%r10d
 101eaa4:	sub    %rdi,%r10
 101eaa7:	xor    %r9d,%r9d
 101eaaa:	nopw   0x0(%rax,%rax,1)
 101eab0:	vmovaps -0xe0(%rsi,%r10,1),%ymm0
 101eaba:	vmovups %ymm0,-0xe0(%rax,%r10,1)
 101eac4:	vmovaps -0xc0(%rsi,%r10,1),%ymm0
 101eace:	vmovups %ymm0,-0xc0(%rax,%r10,1)
 101ead8:	vmovaps -0xa0(%rsi,%r10,1),%ymm0
 101eae2:	vmovups %ymm0,-0xa0(%rax,%r10,1)
 101eaec:	vmovaps -0x80(%rsi,%r10,1),%ymm0
 101eaf3:	vmovups %ymm0,-0x80(%rax,%r10,1)
 101eafa:	vmovaps -0x60(%rsi,%r10,1),%ymm0
 101eb01:	vmovups %ymm0,-0x60(%rax,%r10,1)
 101eb08:	vmovaps -0x40(%rsi,%r10,1),%ymm0
 101eb0f:	vmovups %ymm0,-0x40(%rax,%r10,1)
 101eb16:	vmovaps -0x20(%rsi,%r10,1),%ymm0
 101eb1d:	vmovups %ymm0,-0x20(%rax,%r10,1)
 101eb24:	vmovaps (%rsi,%r10,1),%ymm0
 101eb2a:	vmovups %ymm0,(%rax,%r10,1)
 101eb30:	add    $0x8,%r9
 101eb34:	add    $0x100,%r10
 101eb3b:	cmp    %r9,%r8
 101eb3e:	jne    101eab0 <compiler_rt.memmove.memmoveFast+0x290>
 101eb44:	test   %rdx,%rdx
 101eb47:	je     101eb85 <compiler_rt.memmove.memmoveFast+0x365>
 101eb49:	shl    $0x5,%r9
 101eb4d:	sub    %rdi,%r9
 101eb50:	add    %r9,%rsi
 101eb53:	add    $0x20,%rsi
 101eb57:	lea    (%rax,%r9,1),%rdi
 101eb5b:	add    $0x20,%rdi
 101eb5f:	shl    $0x5,%edx
 101eb62:	xor    %r8d,%r8d
 101eb65:	data16 cs nopw 0x0(%rax,%rax,1)
 101eb70:	vmovaps (%rsi,%r8,1),%ymm0
 101eb76:	vmovups %ymm0,(%rdi,%r8,1)
 101eb7c:	add    $0x20,%r8
 101eb80:	cmp    %r8,%rdx
 101eb83:	jne    101eb70 <compiler_rt.memmove.memmoveFast+0x350>
 101eb85:	vmovups -0xd0(%rbp),%ymm0
 101eb8d:	vmovups %ymm0,(%rax,%rcx,1)
 101eb92:	vmovups -0xb0(%rbp),%ymm0
 101eb9a:	vmovups %ymm0,(%rax)
 101eb9e:	add    $0x40,%rsp
 101eba2:	pop    %rbx
 101eba3:	pop    %r14
 101eba5:	pop    %rbp
 101eba6:	vzeroupper
 101eba9:	ret
 101ebaa:	int3
 101ebab:	int3
 101ebac:	int3
 101ebad:	int3
 101ebae:	int3
 101ebaf:	int3

000000000101ebb0 <compiler_rt.memcpy.memcpyFast>:
 101ebb0:	push   %rbp
 101ebb1:	mov    %rsp,%rbp
 101ebb4:	mov    %rdi,%rax
 101ebb7:	cmp    $0xf,%rdx
 101ebbb:	ja     101ebe6 <compiler_rt.memcpy.memcpyFast+0x36>
 101ebbd:	cmp    $0x3,%rdx
 101ebc1:	ja     101ec24 <compiler_rt.memcpy.memcpyFast+0x74>
 101ebc3:	test   %rdx,%rdx
 101ebc6:	je     101ec22 <compiler_rt.memcpy.memcpyFast+0x72>
 101ebc8:	movzbl (%rsi),%ecx
 101ebcb:	mov    %cl,(%rax)
 101ebcd:	mov    %rdx,%rcx
 101ebd0:	shr    $1,%rcx
 101ebd3:	movzbl (%rsi,%rcx,1),%edi
 101ebd7:	mov    %dil,(%rax,%rcx,1)
 101ebdb:	movzbl -0x1(%rsi,%rdx,1),%ecx
 101ebe0:	mov    %cl,-0x1(%rax,%rdx,1)
 101ebe4:	pop    %rbp
 101ebe5:	ret
 101ebe6:	cmp    $0x3f,%rdx
 101ebea:	ja     101ec50 <compiler_rt.memcpy.memcpyFast+0xa0>
 101ebec:	mov    %edx,%ecx
 101ebee:	shr    $1,%ecx
 101ebf0:	and    $0x10,%ecx
 101ebf3:	lea    -0x10(%rdx),%rdi
 101ebf7:	sub    %rcx,%rdi
 101ebfa:	vmovups (%rsi),%xmm0
 101ebfe:	vmovups %xmm0,(%rax)
 101ec02:	vmovups (%rsi,%rcx,1),%xmm0
 101ec07:	vmovups %xmm0,(%rax,%rcx,1)
 101ec0c:	vmovups (%rsi,%rdi,1),%xmm0
 101ec11:	vmovups %xmm0,(%rax,%rdi,1)
 101ec16:	vmovups -0x10(%rsi,%rdx,1),%xmm0
 101ec1c:	vmovups %xmm0,-0x10(%rax,%rdx,1)
 101ec22:	pop    %rbp
 101ec23:	ret
 101ec24:	mov    %edx,%ecx
 101ec26:	shr    $1,%ecx
 101ec28:	and    $0x4,%ecx
 101ec2b:	lea    -0x4(%rdx),%rdi
 101ec2f:	sub    %rcx,%rdi
 101ec32:	mov    (%rsi),%r8d
 101ec35:	mov    %r8d,(%rax)
 101ec38:	mov    (%rsi,%rcx,1),%r8d
 101ec3c:	mov    %r8d,(%rax,%rcx,1)
 101ec40:	mov    (%rsi,%rdi,1),%ecx
 101ec43:	mov    %ecx,(%rax,%rdi,1)
 101ec46:	mov    -0x4(%rsi,%rdx,1),%ecx
 101ec4a:	mov    %ecx,-0x4(%rax,%rdx,1)
 101ec4e:	pop    %rbp
 101ec4f:	ret
 101ec50:	vmovups (%rsi),%ymm0
 101ec54:	vmovups %ymm0,(%rax)
 101ec58:	mov    %esi,%edi
 101ec5a:	and    $0x1f,%edi
 101ec5d:	lea    (%rdi,%rdx,1),%r8
 101ec61:	add    $0xffffffffffffffe0,%r8
 101ec65:	shr    $0x5,%r8
 101ec69:	lea    -0x1(%r8),%r9
 101ec6d:	mov    %r8d,%ecx
 101ec70:	and    $0x7,%ecx
 101ec73:	cmp    $0x7,%r9
 101ec77:	jae    101ec81 <compiler_rt.memcpy.memcpyFast+0xd1>
 101ec79:	xor    %r9d,%r9d
 101ec7c:	jmp    101ed39 <compiler_rt.memcpy.memcpyFast+0x189>
 101ec81:	and    $0xfffffffffffffff8,%r8
 101ec85:	mov    $0x100,%r10d
 101ec8b:	sub    %rdi,%r10
 101ec8e:	xor    %r9d,%r9d
 101ec91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 101eca0:	vmovaps -0xe0(%rsi,%r10,1),%ymm0
 101ecaa:	vmovups %ymm0,-0xe0(%rax,%r10,1)
 101ecb4:	vmovaps -0xc0(%rsi,%r10,1),%ymm0
 101ecbe:	vmovups %ymm0,-0xc0(%rax,%r10,1)
 101ecc8:	vmovaps -0xa0(%rsi,%r10,1),%ymm0
 101ecd2:	vmovups %ymm0,-0xa0(%rax,%r10,1)
 101ecdc:	vmovaps -0x80(%rsi,%r10,1),%ymm0
 101ece3:	vmovups %ymm0,-0x80(%rax,%r10,1)
 101ecea:	vmovaps -0x60(%rsi,%r10,1),%ymm0
 101ecf1:	vmovups %ymm0,-0x60(%rax,%r10,1)
 101ecf8:	vmovaps -0x40(%rsi,%r10,1),%ymm0
 101ecff:	vmovups %ymm0,-0x40(%rax,%r10,1)
 101ed06:	vmovaps -0x20(%rsi,%r10,1),%ymm0
 101ed0d:	vmovups %ymm0,-0x20(%rax,%r10,1)
 101ed14:	vmovaps (%rsi,%r10,1),%ymm0
 101ed1a:	vmovups %ymm0,(%rax,%r10,1)
 101ed20:	add    $0x8,%r9
 101ed24:	add    $0x100,%r10
 101ed2b:	cmp    %r9,%r8
 101ed2e:	jne    101eca0 <compiler_rt.memcpy.memcpyFast+0xf0>
 101ed34:	test   %rcx,%rcx
 101ed37:	je     101ed75 <compiler_rt.memcpy.memcpyFast+0x1c5>
 101ed39:	shl    $0x5,%r9
 101ed3d:	sub    %rdi,%r9
 101ed40:	lea    (%rsi,%r9,1),%rdi
 101ed44:	add    $0x20,%rdi
 101ed48:	lea    (%rax,%r9,1),%r8
 101ed4c:	add    $0x20,%r8
 101ed50:	shl    $0x5,%ecx
 101ed53:	xor    %r9d,%r9d
 101ed56:	cs nopw 0x0(%rax,%rax,1)
 101ed60:	vmovaps (%rdi,%r9,1),%ymm0
 101ed66:	vmovups %ymm0,(%r8,%r9,1)
 101ed6c:	add    $0x20,%r9
 101ed70:	cmp    %r9,%rcx
 101ed73:	jne    101ed60 <compiler_rt.memcpy.memcpyFast+0x1b0>
 101ed75:	vmovups -0x20(%rsi,%rdx,1),%ymm0
 101ed7b:	vmovups %ymm0,-0x20(%rax,%rdx,1)
 101ed81:	pop    %rbp
 101ed82:	vzeroupper
 101ed85:	ret
 101ed86:	int3
 101ed87:	int3
 101ed88:	int3
 101ed89:	int3
 101ed8a:	int3
 101ed8b:	int3
 101ed8c:	int3
 101ed8d:	int3
 101ed8e:	int3
 101ed8f:	int3

000000000101ed90 <compiler_rt.sqrt.sqrt>:
 101ed90:	push   %rbp
 101ed91:	mov    %rsp,%rbp
 101ed94:	vmovq  %xmm0,%rax
 101ed99:	mov    %rax,%rcx
 101ed9c:	shr    $0x34,%rcx
 101eda0:	lea    -0x7ff(%rcx),%edx
 101eda6:	cmp    $0xfffff802,%edx
 101edac:	jb     101eee7 <compiler_rt.sqrt.sqrt+0x157>
 101edb2:	movabs $0x8000000000000000,%rsi
 101edbc:	mov    %rax,%rdx
 101edbf:	shl    $0xa,%rdx
 101edc3:	lea    -0x400(%rsi),%r8
 101edca:	and    %rdx,%r8
 101edcd:	mov    %rax,%rdi
 101edd0:	shl    $0xb,%rdi
 101edd4:	or     %rsi,%rdi
 101edd7:	test   $0x1,%cl
 101edda:	cmovne %r8,%rdi
 101edde:	shr    $0x2e,%rax
 101ede2:	and    $0x7f,%eax
 101ede5:	lea    -0x1b74c(%rip),%rdx        # 10036a0 <__anon_939530997>
 101edec:	movzwl (%rdx,%rax,2),%eax
 101edf0:	shl    $0x10,%eax
 101edf3:	mov    %rdi,%rdx
 101edf6:	shr    $0x20,%rdx
 101edfa:	imul   %rax,%rdx
 101edfe:	shr    $0x20,%rdx
 101ee02:	mov    %rdx,%r9
 101ee05:	imul   %rax,%r9
 101ee09:	shr    $0x20,%r9
 101ee0d:	mov    $0xc0000000,%r8d
 101ee13:	mov    $0xc0000000,%r10d
 101ee19:	sub    %r9d,%r10d
 101ee1c:	imul   %r10,%rax
 101ee20:	shr    $0x1f,%rax
 101ee24:	and    $0xfffffffe,%eax
 101ee27:	imul   %r10,%rdx
 101ee2b:	shr    $0x1f,%rdx
 101ee2f:	and    $0xfffffffe,%edx
 101ee32:	imul   %rax,%rdx
 101ee36:	shr    $0x20,%rdx
 101ee3a:	sub    %edx,%r8d
 101ee3d:	imul   %rax,%r8
 101ee41:	add    %r8,%r8
 101ee44:	movabs $0xfffffffe00000000,%rax
 101ee4e:	and    %r8,%rax
 101ee51:	mov    %rax,%rdx
 101ee54:	mulx   %rdi,%rdx,%rdx
 101ee59:	mulx   %rax,%rax,%rax
 101ee5e:	movabs $0xc000000000000000,%r8
 101ee68:	sub    %rax,%r8
 101ee6b:	mulx   %r8,%rax,%rax
 101ee70:	add    $0xfffffffffffffffe,%rax
 101ee74:	shr    $0x9,%rax
 101ee78:	shl    $0x2a,%rdi
 101ee7c:	mov    %rax,%rdx
 101ee7f:	imul   %rax,%rdx
 101ee83:	sub    %rdi,%rdx
 101ee86:	add    %rax,%rdx
 101ee89:	mov    %rdx,%rdi
 101ee8c:	shr    $0x3f,%rdi
 101ee90:	add    %rax,%rdi
 101ee93:	add    %rdx,%rax
 101ee96:	mov    $0x34,%r8b
 101ee99:	bzhi   %r8,%rdi,%rdi
 101ee9e:	shl    $0x33,%rcx
 101eea2:	movabs $0x1ff8000000000000,%r8
 101eeac:	add    %rcx,%r8
 101eeaf:	movabs $0xfff0000000000000,%rcx
 101eeb9:	and    %r8,%rcx
 101eebc:	or     %rdi,%rcx
 101eebf:	vmovq  %rcx,%xmm0
 101eec4:	inc    %rax
 101eec7:	je     101eee5 <compiler_rt.sqrt.sqrt+0x155>
 101eec9:	xor    %rdx,%rax
 101eecc:	and    %rsi,%rax
 101eecf:	movabs $0x10000000000000,%rcx
 101eed9:	or     %rax,%rcx
 101eedc:	vmovq  %rcx,%xmm1
 101eee1:	vaddsd %xmm1,%xmm0,%xmm0
 101eee5:	pop    %rbp
 101eee6:	ret
 101eee7:	vxorpd %xmm1,%xmm1,%xmm1
 101eeeb:	vucomisd %xmm1,%xmm0
 101eeef:	setnp  %dl
 101eef2:	sete   %sil
 101eef6:	movabs $0x7ff0000000000000,%rcx
 101ef00:	and    %dl,%sil
 101ef03:	cmp    %rcx,%rax
 101ef06:	sete   %dl
 101ef09:	or     %sil,%dl
 101ef0c:	jne    101eee5 <compiler_rt.sqrt.sqrt+0x155>
 101ef0e:	cmp    %rcx,%rax
 101ef11:	jbe    101ef1d <compiler_rt.sqrt.sqrt+0x18d>
 101ef13:	vsubsd %xmm0,%xmm0,%xmm0
 101ef17:	vdivsd %xmm1,%xmm0,%xmm0
 101ef1b:	pop    %rbp
 101ef1c:	ret
 101ef1d:	vmulsd -0x1c11d(%rip),%xmm0,%xmm0        # 1002e08 <qbe_empty_registry+0x60>
 101ef25:	vmovq  %xmm0,%rax
 101ef2a:	mov    %rax,%rcx
 101ef2d:	shr    $0x34,%rcx
 101ef31:	add    $0xffffffffffffffcc,%rcx
 101ef35:	jmp    101edb2 <compiler_rt.sqrt.sqrt+0x22>

Disassembly of section .init:

000000000101ef3c <_init>:
 101ef3c:	endbr64
 101ef40:	sub    $0x8,%rsp
 101ef44:	mov    0xa615(%rip),%rax        # 1029560 <__gmon_start__>
 101ef4b:	test   %rax,%rax
 101ef4e:	je     101ef52 <_init+0x16>
 101ef50:	call   *%rax
 101ef52:	add    $0x8,%rsp
 101ef56:	ret

Disassembly of section .fini:

000000000101ef58 <_fini>:
 101ef58:	endbr64
 101ef5c:	sub    $0x8,%rsp
 101ef60:	add    $0x8,%rsp
 101ef64:	ret

Disassembly of section .plt:

000000000101ef70 <calloc@plt-0x10>:
 101ef70:	push   0xa632(%rip)        # 10295a8 <_GLOBAL_OFFSET_TABLE_+0x8>
 101ef76:	jmp    *0xa634(%rip)        # 10295b0 <_GLOBAL_OFFSET_TABLE_+0x10>
 101ef7c:	nopl   0x0(%rax)

000000000101ef80 <calloc@plt>:
 101ef80:	jmp    *0xa632(%rip)        # 10295b8 <calloc@GLIBC_2.2.5>
 101ef86:	push   $0x0
 101ef8b:	jmp    101ef70 <_fini+0x18>

000000000101ef90 <longjmp@plt>:
 101ef90:	jmp    *0xa62a(%rip)        # 10295c0 <longjmp@GLIBC_2.2.5>
 101ef96:	push   $0x1
 101ef9b:	jmp    101ef70 <_fini+0x18>

000000000101efa0 <fwrite@plt>:
 101efa0:	jmp    *0xa622(%rip)        # 10295c8 <fwrite@GLIBC_2.2.5>
 101efa6:	push   $0x2
 101efab:	jmp    101ef70 <_fini+0x18>

000000000101efb0 <fprintf@plt>:
 101efb0:	jmp    *0xa61a(%rip)        # 10295d0 <fprintf@GLIBC_2.2.5>
 101efb6:	push   $0x3
 101efbb:	jmp    101ef70 <_fini+0x18>

000000000101efc0 <fegetround@plt>:
 101efc0:	jmp    *0xa612(%rip)        # 10295d8 <fegetround@GLIBC_2.2.5>
 101efc6:	push   $0x4
 101efcb:	jmp    101ef70 <_fini+0x18>

000000000101efd0 <free@plt>:
 101efd0:	jmp    *0xa60a(%rip)        # 10295e0 <free@GLIBC_2.2.5>
 101efd6:	push   $0x5
 101efdb:	jmp    101ef70 <_fini+0x18>

000000000101efe0 <strncmp@plt>:
 101efe0:	jmp    *0xa602(%rip)        # 10295e8 <strncmp@GLIBC_2.2.5>
 101efe6:	push   $0x6
 101efeb:	jmp    101ef70 <_fini+0x18>

000000000101eff0 <strcmp@plt>:
 101eff0:	jmp    *0xa5fa(%rip)        # 10295f0 <strcmp@GLIBC_2.2.5>
 101eff6:	push   $0x7
 101effb:	jmp    101ef70 <_fini+0x18>

000000000101f000 <sigemptyset@plt>:
 101f000:	jmp    *0xa5f2(%rip)        # 10295f8 <sigemptyset@GLIBC_2.2.5>
 101f006:	push   $0x8
 101f00b:	jmp    101ef70 <_fini+0x18>

000000000101f010 <sigaction@plt>:
 101f010:	jmp    *0xa5ea(%rip)        # 1029600 <sigaction@GLIBC_2.2.5>
 101f016:	push   $0x9
 101f01b:	jmp    101ef70 <_fini+0x18>

000000000101f020 <timer_create@plt>:
 101f020:	jmp    *0xa5e2(%rip)        # 1029608 <timer_create@GLIBC_2.34>
 101f026:	push   $0xa
 101f02b:	jmp    101ef70 <_fini+0x18>

000000000101f030 <timer_settime@plt>:
 101f030:	jmp    *0xa5da(%rip)        # 1029610 <timer_settime@GLIBC_2.34>
 101f036:	push   $0xb
 101f03b:	jmp    101ef70 <_fini+0x18>

000000000101f040 <printf@plt>:
 101f040:	jmp    *0xa5d2(%rip)        # 1029618 <printf@GLIBC_2.2.5>
 101f046:	push   $0xc
 101f04b:	jmp    101ef70 <_fini+0x18>

000000000101f050 <vsnprintf@plt>:
 101f050:	jmp    *0xa5ca(%rip)        # 1029620 <vsnprintf@GLIBC_2.2.5>
 101f056:	push   $0xd
 101f05b:	jmp    101ef70 <_fini+0x18>

000000000101f060 <snprintf@plt>:
 101f060:	jmp    *0xa5c2(%rip)        # 1029628 <snprintf@GLIBC_2.2.5>
 101f066:	push   $0xe
 101f06b:	jmp    101ef70 <_fini+0x18>

000000000101f070 <malloc@plt>:
 101f070:	jmp    *0xa5ba(%rip)        # 1029630 <malloc@GLIBC_2.2.5>
 101f076:	push   $0xf
 101f07b:	jmp    101ef70 <_fini+0x18>

000000000101f080 <fflush@plt>:
 101f080:	jmp    *0xa5b2(%rip)        # 1029638 <fflush@GLIBC_2.2.5>
 101f086:	push   $0x10
 101f08b:	jmp    101ef70 <_fini+0x18>

000000000101f090 <_Unwind_Backtrace@plt>:
 101f090:	jmp    *0xa5aa(%rip)        # 1029640 <_Unwind_Backtrace>
 101f096:	push   $0x11
 101f09b:	jmp    101ef70 <_fini+0x18>

000000000101f0a0 <_Unwind_GetIP@plt>:
 101f0a0:	jmp    *0xa5a2(%rip)        # 1029648 <_Unwind_GetIP>
 101f0a6:	push   $0x12
 101f0ab:	jmp    101ef70 <_fini+0x18>

000000000101f0b0 <qsort@plt>:
 101f0b0:	jmp    *0xa59a(%rip)        # 1029650 <qsort@GLIBC_2.2.5>
 101f0b6:	push   $0x13
 101f0bb:	jmp    101ef70 <_fini+0x18>

000000000101f0c0 <write@plt>:
 101f0c0:	jmp    *0xa592(%rip)        # 1029658 <write@GLIBC_2.2.5>
 101f0c6:	push   $0x14
 101f0cb:	jmp    101ef70 <_fini+0x18>

000000000101f0d0 <_exit@plt>:
 101f0d0:	jmp    *0xa58a(%rip)        # 1029660 <_exit@GLIBC_2.2.5>
 101f0d6:	push   $0x15
 101f0db:	jmp    101ef70 <_fini+0x18>

000000000101f0e0 <sysconf@plt>:
 101f0e0:	jmp    *0xa582(%rip)        # 1029668 <sysconf@GLIBC_2.2.5>
 101f0e6:	push   $0x16
 101f0eb:	jmp    101ef70 <_fini+0x18>

000000000101f0f0 <mmap@plt>:
 101f0f0:	jmp    *0xa57a(%rip)        # 1029670 <mmap@GLIBC_2.2.5>
 101f0f6:	push   $0x17
 101f0fb:	jmp    101ef70 <_fini+0x18>

000000000101f100 <mprotect@plt>:
 101f100:	jmp    *0xa572(%rip)        # 1029678 <mprotect@GLIBC_2.2.5>
 101f106:	push   $0x18
 101f10b:	jmp    101ef70 <_fini+0x18>

000000000101f110 <getcontext@plt>:
 101f110:	jmp    *0xa56a(%rip)        # 1029680 <getcontext@GLIBC_2.2.5>
 101f116:	push   $0x19
 101f11b:	jmp    101ef70 <_fini+0x18>

000000000101f120 <makecontext@plt>:
 101f120:	jmp    *0xa562(%rip)        # 1029688 <makecontext@GLIBC_2.2.5>
 101f126:	push   $0x1a
 101f12b:	jmp    101ef70 <_fini+0x18>

000000000101f130 <swapcontext@plt>:
 101f130:	jmp    *0xa55a(%rip)        # 1029690 <swapcontext@GLIBC_2.2.5>
 101f136:	push   $0x1b
 101f13b:	jmp    101ef70 <_fini+0x18>

000000000101f140 <munmap@plt>:
 101f140:	jmp    *0xa552(%rip)        # 1029698 <munmap@GLIBC_2.2.5>
 101f146:	push   $0x1c
 101f14b:	jmp    101ef70 <_fini+0x18>

000000000101f150 <getrlimit@plt>:
 101f150:	jmp    *0xa54a(%rip)        # 10296a0 <getrlimit@GLIBC_2.2.5>
 101f156:	push   $0x1d
 101f15b:	jmp    101ef70 <_fini+0x18>

000000000101f160 <_setjmp@plt>:
 101f160:	jmp    *0xa542(%rip)        # 10296a8 <_setjmp@GLIBC_2.2.5>
 101f166:	push   $0x1e
 101f16b:	jmp    101ef70 <_fini+0x18>

000000000101f170 <strchr@plt>:
 101f170:	jmp    *0xa53a(%rip)        # 10296b0 <strchr@GLIBC_2.2.5>
 101f176:	push   $0x1f
 101f17b:	jmp    101ef70 <_fini+0x18>

000000000101f180 <realloc@plt>:
 101f180:	jmp    *0xa532(%rip)        # 10296b8 <realloc@GLIBC_2.2.5>
 101f186:	push   $0x20
 101f18b:	jmp    101ef70 <_fini+0x18>

000000000101f190 <memchr@plt>:
 101f190:	jmp    *0xa52a(%rip)        # 10296c0 <memchr@GLIBC_2.2.5>
 101f196:	push   $0x21
 101f19b:	jmp    101ef70 <_fini+0x18>

000000000101f1a0 <getenv@plt>:
 101f1a0:	jmp    *0xa522(%rip)        # 10296c8 <getenv@GLIBC_2.2.5>
 101f1a6:	push   $0x22
 101f1ab:	jmp    101ef70 <_fini+0x18>

000000000101f1b0 <strtoull@plt>:
 101f1b0:	jmp    *0xa51a(%rip)        # 10296d0 <strtoull@GLIBC_2.2.5>
 101f1b6:	push   $0x23
 101f1bb:	jmp    101ef70 <_fini+0x18>

000000000101f1c0 <clock_gettime@plt>:
 101f1c0:	jmp    *0xa512(%rip)        # 10296d8 <clock_gettime@GLIBC_2.17>
 101f1c6:	push   $0x24
 101f1cb:	jmp    101ef70 <_fini+0x18>

000000000101f1d0 <unsetenv@plt>:
 101f1d0:	jmp    *0xa50a(%rip)        # 10296e0 <unsetenv@GLIBC_2.2.5>
 101f1d6:	push   $0x25
 101f1db:	jmp    101ef70 <_fini+0x18>

000000000101f1e0 <setrlimit@plt>:
 101f1e0:	jmp    *0xa502(%rip)        # 10296e8 <setrlimit@GLIBC_2.2.5>
 101f1e6:	push   $0x26
 101f1eb:	jmp    101ef70 <_fini+0x18>

000000000101f1f0 <abort@plt>:
 101f1f0:	jmp    *0xa4fa(%rip)        # 10296f0 <abort@GLIBC_2.2.5>
 101f1f6:	push   $0x27
 101f1fb:	jmp    101ef70 <_fini+0x18>

000000000101f200 <strrchr@plt>:
 101f200:	jmp    *0xa4f2(%rip)        # 10296f8 <strrchr@GLIBC_2.2.5>
 101f206:	push   $0x28
 101f20b:	jmp    101ef70 <_fini+0x18>

000000000101f210 <strtoul@plt>:
 101f210:	jmp    *0xa4ea(%rip)        # 1029700 <strtoul@GLIBC_2.2.5>
 101f216:	push   $0x29
 101f21b:	jmp    101ef70 <_fini+0x18>

000000000101f220 <inet_pton@plt>:
 101f220:	jmp    *0xa4e2(%rip)        # 1029708 <inet_pton@GLIBC_2.2.5>
 101f226:	push   $0x2a
 101f22b:	jmp    101ef70 <_fini+0x18>

000000000101f230 <socket@plt>:
 101f230:	jmp    *0xa4da(%rip)        # 1029710 <socket@GLIBC_2.2.5>
 101f236:	push   $0x2b
 101f23b:	jmp    101ef70 <_fini+0x18>

000000000101f240 <connect@plt>:
 101f240:	jmp    *0xa4d2(%rip)        # 1029718 <connect@GLIBC_2.2.5>
 101f246:	push   $0x2c
 101f24b:	jmp    101ef70 <_fini+0x18>

000000000101f250 <close@plt>:
 101f250:	jmp    *0xa4ca(%rip)        # 1029720 <close@GLIBC_2.2.5>
 101f256:	push   $0x2d
 101f25b:	jmp    101ef70 <_fini+0x18>

000000000101f260 <read@plt>:
 101f260:	jmp    *0xa4c2(%rip)        # 1029728 <read@GLIBC_2.2.5>
 101f266:	push   $0x2e
 101f26b:	jmp    101ef70 <_fini+0x18>

000000000101f270 <__errno_location@plt>:
 101f270:	jmp    *0xa4ba(%rip)        # 1029730 <__errno_location@GLIBC_2.2.5>
 101f276:	push   $0x2f
 101f27b:	jmp    101ef70 <_fini+0x18>

000000000101f280 <lseek@plt>:
 101f280:	jmp    *0xa4b2(%rip)        # 1029738 <lseek@GLIBC_2.2.5>
 101f286:	push   $0x30
 101f28b:	jmp    101ef70 <_fini+0x18>

000000000101f290 <pwrite@plt>:
 101f290:	jmp    *0xa4aa(%rip)        # 1029740 <pwrite@GLIBC_2.2.5>
 101f296:	push   $0x31
 101f29b:	jmp    101ef70 <_fini+0x18>

000000000101f2a0 <open@plt>:
 101f2a0:	jmp    *0xa4a2(%rip)        # 1029748 <open@GLIBC_2.2.5>
 101f2a6:	push   $0x32
 101f2ab:	jmp    101ef70 <_fini+0x18>

000000000101f2b0 <openat@plt>:
 101f2b0:	jmp    *0xa49a(%rip)        # 1029750 <openat@GLIBC_2.4>
 101f2b6:	push   $0x33
 101f2bb:	jmp    101ef70 <_fini+0x18>

000000000101f2c0 <fstatat@plt>:
 101f2c0:	jmp    *0xa492(%rip)        # 1029758 <fstatat@GLIBC_2.33>
 101f2c6:	push   $0x34
 101f2cb:	jmp    101ef70 <_fini+0x18>

000000000101f2d0 <mkdirat@plt>:
 101f2d0:	jmp    *0xa48a(%rip)        # 1029760 <mkdirat@GLIBC_2.4>
 101f2d6:	push   $0x35
 101f2db:	jmp    101ef70 <_fini+0x18>

000000000101f2e0 <fdopendir@plt>:
 101f2e0:	jmp    *0xa482(%rip)        # 1029768 <fdopendir@GLIBC_2.4>
 101f2e6:	push   $0x36
 101f2eb:	jmp    101ef70 <_fini+0x18>

000000000101f2f0 <readdir@plt>:
 101f2f0:	jmp    *0xa47a(%rip)        # 1029770 <readdir@GLIBC_2.2.5>
 101f2f6:	push   $0x37
 101f2fb:	jmp    101ef70 <_fini+0x18>

000000000101f300 <dirfd@plt>:
 101f300:	jmp    *0xa472(%rip)        # 1029778 <dirfd@GLIBC_2.2.5>
 101f306:	push   $0x38
 101f30b:	jmp    101ef70 <_fini+0x18>

000000000101f310 <fstat@plt>:
 101f310:	jmp    *0xa46a(%rip)        # 1029780 <fstat@GLIBC_2.33>
 101f316:	push   $0x39
 101f31b:	jmp    101ef70 <_fini+0x18>

000000000101f320 <unlinkat@plt>:
 101f320:	jmp    *0xa462(%rip)        # 1029788 <unlinkat@GLIBC_2.4>
 101f326:	push   $0x3a
 101f32b:	jmp    101ef70 <_fini+0x18>

000000000101f330 <ftruncate@plt>:
 101f330:	jmp    *0xa45a(%rip)        # 1029790 <ftruncate@GLIBC_2.2.5>
 101f336:	push   $0x3b
 101f33b:	jmp    101ef70 <_fini+0x18>

000000000101f340 <closedir@plt>:
 101f340:	jmp    *0xa452(%rip)        # 1029798 <closedir@GLIBC_2.2.5>
 101f346:	push   $0x3c
 101f34b:	jmp    101ef70 <_fini+0x18>

000000000101f350 <fcntl@plt>:
 101f350:	jmp    *0xa44a(%rip)        # 10297a0 <fcntl@GLIBC_2.2.5>
 101f356:	push   $0x3d
 101f35b:	jmp    101ef70 <_fini+0x18>

000000000101f360 <madvise@plt>:
 101f360:	jmp    *0xa442(%rip)        # 10297a8 <madvise@GLIBC_2.2.5>
 101f366:	push   $0x3e
 101f36b:	jmp    101ef70 <_fini+0x18>

000000000101f370 <mremap@plt>:
 101f370:	jmp    *0xa43a(%rip)        # 10297b0 <mremap@GLIBC_2.2.5>
 101f376:	push   $0x3f
 101f37b:	jmp    101ef70 <_fini+0x18>
