<fail>:
 1014ab0:	push   %rbp
 1014ab1:	mov    %rsp,%rbp
 1014ab4:	push   %r10
 1014ab6:	push   %r9
 1014ab8:	push   %r8
 1014aba:	push   %rdi
 1014abb:	push   %rsi
 1014abc:	push   %rdx
 1014abd:	push   %rcx
 1014abe:	push   %rax
 1014abf:	push   %r15
 1014ac1:	push   %r14
 1014ac3:	push   %rbx
 1014ac4:	and    $0xffffffffffffffe0,%rsp
 1014ac8:	sub    $0x240,%rsp
 1014acf:	vmovups %ymm15,-0x90(%rbp)
 1014ad7:	vmovups %ymm14,-0xb0(%rbp)
 1014adf:	vmovups %ymm13,-0xd0(%rbp)
 1014ae7:	vmovups %ymm12,-0xf0(%rbp)
 1014aef:	vmovups %ymm11,-0x110(%rbp)
 1014af7:	vmovups %ymm10,-0x130(%rbp)
 1014aff:	vmovups %ymm9,-0x150(%rbp)
 1014b07:	vmovups %ymm8,-0x170(%rbp)
 1014b0f:	vmovups %ymm7,-0x190(%rbp)
 1014b17:	vmovups %ymm6,-0x1b0(%rbp)
 1014b1f:	vmovups %ymm5,-0x1d0(%rbp)
 1014b27:	vmovups %ymm4,-0x1f0(%rbp)
 1014b2f:	vmovups %ymm3,-0x210(%rbp)
 1014b37:	vmovups %ymm2,-0x230(%rbp)
 1014b3f:	vmovups %ymm1,-0x250(%rbp)
 1014b47:	vmovups %ymm0,-0x270(%rbp)
 1014b4f:	cmpq   $0x0,0x20(%rdi)
 1014b54:	jne    1014bde <fail+0x12e>
 1014b5a:	mov    %rdi,%rbx
 1014b5d:	mov    %rsi,0x20(%rdi)
 1014b61:	movq   $0x0,0x18(%rsp)
 1014b6a:	mov    0x30(%rdi),%r15
 1014b6e:	test   %r15,%r15
 1014b71:	je     1014ba7 <fail+0xf7>
 1014b73:	lea    0x18(%rsp),%r14
 1014b78:	nopl   0x0(%rax,%rax,1)
 1014b80:	mov    0x8(%r15),%rsi
 1014b84:	mov    0x10(%r15),%rdx
 1014b88:	mov    %rbx,%rdi
 1014b8b:	xor    %ecx,%ecx
 1014b8d:	mov    %r14,%r8
 1014b90:	vzeroupper
 1014b93:	call   1014c90 <trace_frame>
 1014b98:	mov    (%r15),%r15
 1014b9b:	test   %r15,%r15
 1014b9e:	jne    1014b80 <fail+0xd0>
 1014ba0:	cmpq   $0x0,0x30(%rbx)
 1014ba5:	jne    1014bb7 <fail+0x107>
 1014ba7:	lea    0x18(%rsp),%rsi
 1014bac:	mov    %rbx,%rdi
 1014baf:	vzeroupper
 1014bb2:	call   1014de0 <walk_frames>
 1014bb7:	mov    0x18(%rsp),%r11
 1014bbc:	xor    %eax,%eax
 1014bbe:	sub    0x248(%rbx),%r11
 1014bc5:	cmovae %r11,%rax
 1014bc9:	mov    %rax,0x250(%rbx)
 1014bd0:	cmpq   $0x0,0x3e60(%rbx)
 1014bd8:	jne    1014c77 <fail+0x1c7>
 1014bde:	vmovups -0x270(%rbp),%ymm0
 1014be6:	vmovups -0x250(%rbp),%ymm1
 1014bee:	vmovups -0x230(%rbp),%ymm2
 1014bf6:	vmovups -0x210(%rbp),%ymm3
 1014bfe:	vmovups -0x1f0(%rbp),%ymm4
 1014c06:	vmovups -0x1d0(%rbp),%ymm5
 1014c0e:	vmovups -0x1b0(%rbp),%ymm6
 1014c16:	vmovups -0x190(%rbp),%ymm7
 1014c1e:	vmovups -0x170(%rbp),%ymm8
 1014c26:	vmovups -0x150(%rbp),%ymm9
 1014c2e:	vmovups -0x130(%rbp),%ymm10
 1014c36:	vmovups -0x110(%rbp),%ymm11
 1014c3e:	vmovups -0xf0(%rbp),%ymm12
 1014c46:	vmovups -0xd0(%rbp),%ymm13
 1014c4e:	vmovups -0xb0(%rbp),%ymm14
 1014c56:	vmovups -0x90(%rbp),%ymm15
 1014c5e:	lea    -0x58(%rbp),%rsp
 1014c62:	pop    %rbx
 1014c63:	pop    %r14
 1014c65:	pop    %r15
 1014c67:	pop    %rax
 1014c68:	pop    %rcx
 1014c69:	pop    %rdx
 1014c6a:	pop    %rsi
 1014c6b:	pop    %rdi
 1014c6c:	pop    %r8
 1014c6e:	pop    %r9
 1014c70:	pop    %r10
 1014c72:	pop    %rbp
 1014c73:	vzeroupper
 1014c76:	ret
 1014c77:	mov    %rbx,%rdi
 1014c7a:	call   1014660 <myl_qbe_rc_trap>
 1014c7f:	mov    0x3e60(%rbx),%rdi
 1014c86:	mov    $0x1,%esi
 1014c8b:	call   1027820 <longjmp@plt>
