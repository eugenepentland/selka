from pathlib import Path
from types import SimpleNamespace
import json,sys,traceback
root=Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
sys.path.insert(0,str(root/'selfhost/tests'))
import run_body_check_qualification as D
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp/b6-edit-rebuild-diagnose')
work.mkdir(exist_ok=False)
args=SimpleNamespace(builder=root/'zig-out/tools/selka-components',zig=Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'))
q=SimpleNamespace(work=work,matrix=lambda:0)
original=D.F.execute
count=0

def retained(command,env,cwd,timeout=180,**kwargs):
 global count
 count+=1
 number=count
 traced=['/usr/bin/strace','-f','-e','trace=process,setrlimit,prlimit64','-e','signal=all','-o',str(work/f'command-{number}.strace'),'/usr/bin/time','-v','-o',str(work/f'command-{number}.time'),*command]
 result=original(traced,env,cwd,timeout,**kwargs)
 for suffix,data in [('stdout',result[1]),('stderr',result[2])]:
  (work/f'command-{number}.{suffix}').write_bytes(data)
 (work/f'command-{number}.json').write_text(json.dumps({'command':[str(x) for x in command],'status':result[0],'address_space_budget':kwargs.get('address_space_budget',D.F.ADDRESS_SPACE_BUDGET)},indent=2)+'\n')
 return result
D.F.execute=retained
receipt={'scope':'Isolated coordinator rebuild diagnosis only; deliberately no matrix or full-gate verdict'}
try:
 receipt['result']=D.coordinator_edit(args,q)
 receipt['complete']=True
except Exception as error:
 receipt['complete']=False
 receipt['error']=repr(error)
 traceback.print_exc()
finally:
 (work/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
sys.exit(0 if receipt['complete'] else 1)
