from pathlib import Path
import json
import subprocess

root=Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
work=Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
expected='802ad1f69a6beed4dda6987dd736143696f5e15f'
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==expected and not git('status','--porcelain')
report=dict(complete=False,base=expected,records=[])
path=work/'wave-integration-phase1.json'
commands=[
    ['git','merge','--no-ff','93ad4a32c42ba59de4f9fa8a077b373079ac680a','-m','Integrate qualified scalar and aggregate stream output'],
    ['git','cherry-pick','9ec15e340'],
    ['git','cherry-pick','fbcb3f665d55c032a7ba8ae66cf43aa48d2f4573'],
    ['git','cherry-pick','c97bbe211'],
    ['git','cherry-pick','1c6f2d368543051d67e14567dd618c5b4576171e'],
    ['git','cherry-pick','6e4814a1f5efd23215a1fd869b2ae56761b42b39'],
    ['git','cherry-pick','cbe764d787099073a48d4cf3458b27d617d88f53'],
]
path.write_text(json.dumps(report,indent=2)+'\n')
for command in commands:
    result=subprocess.run(command,cwd=root)
    report['records'].append(dict(command=command,status=result.returncode,head=git('rev-parse','HEAD'),dirty=git('status','--porcelain')))
    path.write_text(json.dumps(report,indent=2)+'\n')
    if result.returncode:
        raise SystemExit(result.returncode)
assert not git('status','--porcelain')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
report.update(complete=True,head=git('rev-parse','HEAD'),failed=0,skipped=0)
path.write_text(json.dumps(report,indent=2)+'\n')
