from pathlib import Path
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
expected = '65fa488b191389094d748b414a90b133e865ff56'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
assert git('rev-parse', 'HEAD') == expected and not git('status', '--porcelain')
report = dict(complete=False, base=expected, records=[])
path = work / 'wave-integration-phase2.json'
def save():
    path.write_text(json.dumps(report, indent=2) + '\n')
save()
for commit in ['df051814f5d656432aa909d4d95088a1335b6b65',
               '68a2c2d8b1dbe8fa5af8962f68fa060e9b1c0904',
               'e01ca47de6e53621a768bf300c8e93e0f61c648b']:
    command = ['git', 'cherry-pick', commit]
    result = subprocess.run(command, cwd=root)
    report['records'].append(dict(command=command, status=result.returncode,
                                  head=git('rev-parse', 'HEAD'), dirty=git('status', '--porcelain')))
    save()
    if result.returncode:
        raise SystemExit(result.returncode)
assert not git('status', '--porcelain')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
report.update(complete=True, head=git('rev-parse', 'HEAD'), failed=0, skipped=0)
save()
