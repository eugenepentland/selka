from pathlib import Path
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
expected = git_expected = __import__('subprocess').check_output(['git','rev-parse','fed60b34b'], cwd=root, text=True).strip()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
assert git('rev-parse', 'HEAD') == expected and not git('status', '--porcelain')
report = dict(complete=False, base=expected, records=[])
path = work / 'wave-integration-phase3.json'
def save():
    path.write_text(json.dumps(report, indent=2) + '\n')
save()
for commit in ['54210bc62d689ce0e22a5f5863194a0c18edadea',
               'ed562913ecbe58a89f65a3baeb03a66a91a6e611',
               '8987826f05f0cd4adf2d0523ddb8df4262024935',
               '98e09f26f761de18dacdc2229a133eaecd38f3c4']:
    command = ['git', 'cherry-pick', commit]
    result = subprocess.run(command, cwd=root)
    report['records'].append(dict(command=command, status=result.returncode,
                                  head=git('rev-parse', 'HEAD'), dirty=git('status', '--porcelain')))
    save()
    if result.returncode:
        raise SystemExit(result.returncode)
assert not git('status', '--porcelain')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
report.update(complete=True, head=git('rev-parse', 'HEAD'), failed=0, skipped=0)
save()
