from pathlib import Path
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
expected = '74eb97d489870129b555b1b300f7611e79df762a'
assert git('rev-parse', 'HEAD') == expected and not git('status', '--porcelain')
report = dict(complete=False, base=expected,
              qualification='Joined source preparation; sequence release pure and generic installed strict proof pending', records=[])
path = work / 'wave-integration-phase4.json'
def save():
    path.write_text(json.dumps(report, indent=2) + '\n')
save()
for commit in ['bcd9b8a3341af1cebc6ecfb101f141d1ad35379b',
               'ee0076e112b20ea2bb9d9bf0ea05b496564d4f50',
               'ac1b97b3a1d7a73928718b22ae0d9cc2bcb6c9e9',
               'a8ddcdf02ac3adbd497d85727de7e5b0c6cd70dc',
               '16f0d6712479ee1a6fae9beb8fcda83c49642d6e',
               '3c47d6077', '2d0068fc7', '12c2582d4', '5bb5b9007',
               'd5f0d688f', '2fac9f66f', '572eb7b49', '38dd899b4']:
    command = ['git', 'cherry-pick', commit]
    result = subprocess.run(command, cwd=root)
    report['records'].append(dict(command=command, status=result.returncode,
        head=git('rev-parse', 'HEAD'), unresolved=git('diff', '--name-only', '--diff-filter=U')))
    save()
    if result.returncode:
        raise SystemExit(result.returncode)
assert not git('status', '--porcelain')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
report.update(complete=True, head=git('rev-parse', 'HEAD'), failed=0, skipped=0)
save()
