from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
base = '5dfe4c3217a9924a4889e5716b8266112e8764ce'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == base
preflight = json.loads((work / 'wave-joined-preflight.json').read_text())
assert preflight['complete'] and preflight['failed'] == preflight['skipped'] == 0
assert [(r['name'], r['status']) for r in preflight['records']] == [
    ('python', 0), ('seed-check', 0), ('format', 0), ('guardian', 0), ('diff', 0)]
for name, digest in preflight['source_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
assert 'Ran 130 tests' in (work / 'wave-joined-preflight-python.log').read_text()
assert '88 check(s) passed' in (work / 'wave-joined-preflight-guardian.log').read_text()
help_text = (work / 'wave-joined-build-help.log').read_text()
assert 'test-selfhost-body-operations ' in help_text
assert 'test-selfhost-body-operations-self ' in help_text

files = ['build.zig', 'build_test_inputs.zig', 'selfhost/test_body_closure.py',
    'selfhost/tests/body_closure_gate_test.py', 'selfhost/tests/body_sequence_admission_test.py',
    'selfhost/tests/fixtures/body_sequence_candidate/inventory.json',
    'selfhost/tests/fixtures/body_sequence_hostile/inventory.json',
    'selfhost/tests/run_body_generic_admission.py', 'selfhost/tests/run_body_sequence_admission.py',
    'selfhost/tests/run_body_sequence_hostile.py', 'selfhost/test_body_operations.py',
    'selfhost/tests/body_operations_gate_test.py']
evidence = root / 'docs/audits/evidence/selka-joined-body-gates-20261011'
evidence.mkdir(parents=True, exist_ok=False)
artifacts = sorted(set(work.glob('wave-integration-phase*')) | set(work.glob('wave-joined-preflight*'))
                   | {work / 'wave-joined-build-help.log', Path(__file__)})
receipt = dict(format=1, source_base=base,
    scope='Joined source integration and harness preflight only; installed joined compiler gate pending',
    python_tests=130, guardian=88, qualified_seed_check=True, build_graph_configured=True,
    required_closure_source_operations=4575, required_operations_source_operations=3048,
    required_operations_malformed_replies=489, required_operations_authentic_replays=8,
    source_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files},
    artifacts=[])
for path in artifacts:
    data = path.read_bytes()
    archived = gzip.compress(data, mtime=0)
    output = evidence / (path.name + '.gz')
    output.write_bytes(archived)
    assert gzip.decompress(output.read_bytes()) == data
    receipt['artifacts'].append(dict(name=output.name, sha256=hashlib.sha256(data).hexdigest(),
        archive_sha256=hashlib.sha256(archived).hexdigest(), bytes=len(data), archive_bytes=len(archived)))
(evidence / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
doc = root / 'docs/audits/selka-joined-body-gates-2026-10-11.md'
doc.write_text('''# Joined body-language gate integration

The integration tree at 5dfe4c321 combines the aggregate, comprehension, text,
filesystem, ordinary-sequence and schema-11 generic implementations. This change
makes their installed qualification part of the full compiler gate. It does not
claim the newly joined compiler has passed that gate.

The closure driver now requires 4,575 source operations, including genuine
normal and release execution for comprehensions, text and generics. Existing
constant, structural, iteration, chained-comparison and hostile requirements
remain. Runtime accounting checks the actual command flags as well as report
metadata. The generic runner previously always supplied release flags; it now
honors the requested mode, and old reports are not reclassified as normal proof.

The new operations driver requires 3,048 source operations: 372 filesystem
operations covering both guest modes, plus 1,338 sequence operations per mode.
It additionally requires 489 malformed-reply rejections and eight authentic
filesystem replays. Exact inventories, source hashes, schema, runtime flags,
deployment identities, completion and failure counts are checked. Child runners
retain native transcript, diagnostic, trap, warning and mutation validations.
Sequence fixture schemas now match schema 11. No fixture inputs or limits change.

All 130 body Python harness tests pass, as do the qualified seed's check of the
joined body source, Zig formatting, 88 Guardian checks and whitespace checking.
The build graph configures successfully and exposes both new operations targets.
After preflight, only the build step's self-test pattern was broadened to the
same complete body-test pattern already used by preflight. The receipt records
the final build files and all harness files; preflight binds all selfhost source
bytes before and after its checks.

Evidence retains the first failing runtime-flag assertion and its corrected
rerun. Integration conflict records are also retained: the body engine keeps
both print_types and file_operations imports; B7 keeps its promoted classes and
schema 11. All original text/filesystem promotions remain source-identical.

The complete sequence release pure run and the rebuilt generic installed proof
were still pending when this receipt was prepared. The next integrated install
and full gate must also qualify the original B7 entries and generations. Native
semantic passes, Core/LLVM/driver migration, a compiler bootstrap fixed point and
the 1.5-times performance requirement remain open.

[Evidence and source identities](evidence/selka-joined-body-gates-20261011/receipt.json)
include successful and failed preflight runs and all four integration phases.
''')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *files, str(evidence.relative_to(root)), str(doc.relative_to(root))], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Require joined body operations and both generic execution modes'], cwd=root, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
print(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), flush=True)
