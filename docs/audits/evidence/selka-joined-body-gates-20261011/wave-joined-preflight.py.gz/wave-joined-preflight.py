from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/home/epentland/.codex/worktrees/selka-selfhost-pilots/mylang')
work = Path('/home/epentland/ai/canopy/.selka-agent-cache/bootstrap-20261011/tmp')
seed = '/home/epentland/.cache/mylang/components/seeds/99a0c5875f1543cbb9c55694eb744328012fd1454b83a451ea11c6b2f96963fc/source/zig-out/focus/mylang'
zig = '/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig'
source = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted((root / 'selfhost').rglob('*'))
          if p.is_file() and p.suffix in ('.my', '.py', '.json', '.input') and '__pycache__' not in p.parts}
report = dict(complete=False, source_sha256=source, records=[])
path = work / 'wave-joined-preflight.json'
def save():
    path.write_text(json.dumps(report, indent=2) + '\n')
save()
commands = [
    ('python', ['python3', '-m', 'unittest', 'discover', '-s', 'selfhost/tests', '-p', 'body_*test.py']),
    ('seed-check', [seed, 'check', 'selfhost/components/body_check/main.my', '--no-cache']),
    ('format', [zig, 'fmt', '--check', 'build.zig', 'build_test_inputs.zig']),
    ('guardian', ['/home/epentland/ai/canopy/guardian-zig/zig-out/bin/guardian-check', 'all', '.', '--gate', '--full']),
    ('diff', ['git', 'diff', '--check']),
]
for name, command in commands:
    print(name, flush=True)
    log = work / ('wave-joined-preflight-' + name + '.log')
    with log.open('wb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    report['records'].append(dict(name=name, command=command, status=result.returncode, log=str(log)))
    save()
    if result.returncode:
        print(log.read_text(errors='replace')[-10000:], flush=True)
        raise SystemExit(result.returncode)
for name, digest in source.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
report.update(complete=True, failed=0, skipped=0)
save()
