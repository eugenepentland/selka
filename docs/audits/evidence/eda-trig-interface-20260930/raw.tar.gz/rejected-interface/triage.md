# Read-only native trig module-cache failure triage

Compiler source: 0289edb6f24a826302ff133f885b8867f61b748b. Executed pin SHA256 b3de0bd627d48a6667517fc8cd448706fd4f32476ed9c3c5feaf287b72b73c71. Compiler source/worktree remained unchanged. All probes used absolute owned TMPDIR/Zig/cache paths. No native build, Guardian, hardware measurement or source patch was performed.

## Demonstrated cause

A module child compiling main against the cached math.myi exits 1 with E_INTERNAL_NAME at the retained __float_sin body. Exact embedded math compilation and whole-program checking of main both exit 0. math.sin/cos are small one-op inlined bodies, whereas existing math.sqrt is a larger declared body rendered as pass. Project.intern gives supplied standard-interface bytes the @stdlib/math.my path, but parser.trustedStdlib requires exact embedded bytes; that intended rule rejects reconstructed interface text.

The scheduler saves partial state after the child fails and returns to whole-program checking. Own main state has zero modules; standard state has math. Repeated accepted whole-program fallback rewrites these partial states. The unchanged-state guard works for a no-import program: both own and standard state bytes/inode/mtime stay unchanged on the second check.

## Controls and scope

manual-receipt.json records cached-interface child=1, embedded math child=0, whole math check=0, guest private-name refusal=1, no-import checks=0/0 and unchanged locked state identity. check-rounds.json retains three math checks and partial-state rewrites. Constant controls reject direct float const, int conversion of sin, int helper invoking sin and existing sqrt helper with E_CONSTANT_TYPE at the float-return function. Current accepted constants therefore cannot force these float-return wrappers into evaluated interface bodies.

Meaningful IEEE zero/nonfinite guards, matching sqrt's structure, are a narrow current remedy: signed-zero sin unchanged, cos zero 1, nonfinite canonical NaN, finite native trig. This naturally prevents the inline-body projection triggering the failure. It needs successful per-module/no-op/generic controls after patch. Do not trust arbitrary cached bytes based on @stdlib path or disable parser guarding. The general reserved-intrinsic/interface-projection limitation remains documented; future accepted evaluated/template standard bodies containing a private intrinsic would require an authenticated projection mechanism.

LLVM cold libunwind ar stderr is separate from this demonstrated source/parse failure. Relative gate cache paths are undesirable but absolute paths reproduce this defect.

## Source locations

parser.zig:323 trustedStdlib; parser.zig:1750 new trig guarded operations; project.zig:152 standard provider bytes and :165 reserved source path; module_interface_build.zig:174 inline role derivation and :575 stub rendering; module_interface_oracle.zig:258 cached interface.text; module_build.zig:886 partial-state save after failed schedule; module_build.zig:767 unchangedState guard. compiler.zig:136 initTrusted is a parser-unit-test hook only.
