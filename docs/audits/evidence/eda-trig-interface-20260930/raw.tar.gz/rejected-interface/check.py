import pathlib,subprocess,json,time,os
root=pathlib.Path.cwd();base=root/'.tmp/trig-review';project=base/'math';cache=base/'check-cache';pin='/home/epentland/ai/canopy/eda-bench-wt/mylang-0289edb6/bin/mylang'
rows=[]
for n in range(3):
 states={str(p.relative_to(cache)):{'bytes':p.read_text(),'mtime':p.stat().st_mtime_ns,'ino':p.stat().st_ino} for p in cache.glob('modules/*/state.json')}
 start=time.monotonic();p=subprocess.run([pin,'check',str(project/'main.my'),'--cache-dir='+str(cache)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);seconds=time.monotonic()-start
 after={str(p.relative_to(cache)):{'bytes':p.read_text(),'mtime':p.stat().st_mtime_ns,'ino':p.stat().st_ino} for p in cache.glob('modules/*/state.json')}
 row={'round':n,'status':p.returncode,'seconds':seconds,'output':p.stdout,'before':states,'after':after};rows.append(row);print(n,p.returncode,seconds,p.stdout,flush=True)
 for k,v in after.items():
  if k in states:print(k,'content_changed',v['bytes']!=states[k]['bytes'],'metadata_changed',(v['mtime'],v['ino'])!=(states[k]['mtime'],states[k]['ino']),flush=True)
(base/'check-rounds.json').write_text(json.dumps(rows,indent=2)+'\n')
