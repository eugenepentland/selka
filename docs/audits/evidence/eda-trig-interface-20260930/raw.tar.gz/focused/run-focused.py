from pathlib import Path
import subprocess, os, time, json, hashlib
root=Path.cwd(); work=root/'.tmp/trig-repair'; pin=work/'compiler/bin/mylang'
env=os.environ.copy(); env.update(MYLANG_FRONTEND_CACHE=str(work/'frontend'),XDG_CACHE_HOME=str(work/'xdg'),MYLANG_QBE=str(work/'compiler/bin/qbe'))
rows=[]
cases=[('guest-qbe',[str(pin),'test','tests/lang/math_trig.my','--jobs=2','--cache-dir='+str(work/'guest-qbe-cache')]),('guest-llvm',[str(pin),'test','tests/lang/math_trig.my','--release','--jobs=2','--cache-dir='+str(work/'guest-llvm-cache')]),('module-check',['python3','tests/module_check_oracle.py',str(pin),'tests/lang/math_trig.my','tests/lang/rounding.my','tests/lang/standard_strings.my','tests/fixtures/module_compile/main.my','tests/fixtures/module_projects/main.my','--jobs','2','--json',str(work/'check-oracle.json'),'--work',str(work/'check-oracle-work'),'--keep']),('module-build-diff',['python3','tests/module_build_diff.py',str(pin),'--steps','1','--keep',str(work/'build-diff-work'),'--json',str(work/'build-diff.json')])]
for name,cmd in cases:
 print('START',name,flush=True); start=time.monotonic(); proc=subprocess.run(cmd,capture_output=True,env=env); elapsed=time.monotonic()-start
 (work/(name+'.stdout')).write_bytes(proc.stdout); (work/(name+'.stderr')).write_bytes(proc.stderr)
 rows.append(dict(name=name,cmd=cmd,status=proc.returncode,seconds=elapsed)); print('END',name,proc.returncode,round(elapsed,3),proc.stdout.decode()[-900:],proc.stderr.decode()[-900:],flush=True)
 (work/'focused.json').write_text(json.dumps(dict(compiler_sha256=hashlib.sha256(pin.read_bytes()).hexdigest(),environment={k:env[k] for k in ('TMPDIR','ZIG_GLOBAL_CACHE_DIR','ZIG_LOCAL_CACHE_DIR','MYLANG_FRONTEND_CACHE','XDG_CACHE_HOME','MYLANG_QBE')},rows=rows),indent=2)+'\n')
 if proc.returncode: raise SystemExit(proc.returncode)
