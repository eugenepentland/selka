import json
import os
from pathlib import Path
import subprocess

TASK = Path('/home/epentland/ai/canopy/.selka-agent-cache/numeric-b9')
ROOT = Path('/home/epentland/.codex/worktrees/selka-numeric-pilot/mylang')
HOST = TASK / 'install-host-final/focus/mylang'
COMPONENTS = TASK / 'install-host-final/libexec/mylang/components'
ZIG = Path('/home/epentland/zig-toolchains/0.17.0-dev.1683+5ceec001b/zig')
BUILDER = TASK / 'install-host/tools/selka-components'
B8 = TASK / 'b8-schema9-regressions/selfhost/tests'
common = ['--compiler', str(HOST), '--component-dir', str(COMPONENTS)]
numeric = ['python3', str(ROOT / 'selfhost/tests/run_body_numeric_admission.py'), *common,
           '--zig', str(ZIG), '--builder', str(BUILDER), '--source-root', str(ROOT)]
dictionary = ['python3', str(B8 / 'run_body_dictionary_admission.py'), *common,
              '--zig', str(ZIG), '--builder', str(BUILDER), '--source-root', str(ROOT)]
jobs = [
    ('numeric-final-normal', numeric),
    ('numeric-final-release', [*numeric, '--release']),
    ('numeric-final-boundaries', ['python3', str(ROOT / 'selfhost/tests/run_body_numeric_boundaries.py'), *common]),
    ('dictionary-final-normal', dictionary),
    ('dictionary-final-release', [*dictionary, '--release']),
    ('dictionary-final-hostile', ['python3', str(B8 / 'run_body_dictionary_hostile.py'), *common,
      '--zig', str(ZIG), '--evidence-dir', str(TASK / 'dictionary-final-hostile-evidence')]),
]
receipt = {'complete': False, 'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
           'records': []}
for name, argv in jobs:
    command = [*argv, '--report', str(TASK / (name + '.json'))]
    print('starting', name, flush=True)
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    (TASK / (name + '.log')).write_text(result.stdout + result.stderr)
    receipt['records'].append({'name': name, 'command': command, 'status': result.returncode})
    (TASK / 'combined-final-replay.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, result.returncode, result.stdout[-1000:], result.stderr[-1000:], flush=True)
receipt['complete'] = True
(TASK / 'combined-final-replay.json').write_text(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(any(row['status'] != 0 for row in receipt['records']))
