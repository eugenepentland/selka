import hashlib,json,os,subprocess,sys
from pathlib import Path

work=Path(__file__).resolve().parent
root=work.parents[1]
side=sys.argv[1]
directory=work/side;directory.mkdir(exist_ok=True)
cases=json.loads((work/'design.json').read_text())
translator=work/(side+'-translator')
env=dict(os.environ)
rows=[]
for case in cases:
    name=case['name'];source=work/'fixtures'/(name+'.ssa')
    p=subprocess.run([translator,source],cwd=root,env=env,capture_output=True)
    (directory/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode==0,(name,p.stderr.decode(errors='replace'))
    path=directory/(name+'.ll');path.write_bytes(p.stdout)
    admitted=b'call { i64, i1 } @llvm.' in p.stdout
    assert admitted==(case['admit'] if side=='candidate' else False),(side,name,admitted)
    rows.append({'case':name,'status':p.returncode,'expected_intrinsic':case['admit'] if side=='candidate' else False,'actual_intrinsic':admitted,'executable':case['execute'],'ir_sha256':hashlib.sha256(p.stdout).hexdigest()})
commands=[]
inputs=[str(directory/(case['name']+'.ll')) for case in cases if case['execute']]
binary=directory/'oracle'
command=['zig','cc','-O3',*inputs,str(work/'oracle.c'),'-o',str(binary)]
p=subprocess.run(command,cwd=root,env=env,capture_output=True)
(directory/'compile.stdout').write_bytes(p.stdout);(directory/'compile.stderr').write_bytes(p.stderr)
commands.append({'command':command,'status':p.returncode});assert p.returncode==0,p.stderr.decode(errors='replace')
command=[str(binary)]
p=subprocess.run(command,cwd=root,env=env,capture_output=True)
(directory/'oracle.stdout').write_bytes(p.stdout);(directory/'oracle.stderr').write_bytes(p.stderr)
commands.append({'command':command,'status':p.returncode});assert p.returncode==0,p.stderr.decode(errors='replace')
receipt={'side':side,'translator_sha256':hashlib.sha256(translator.read_bytes()).hexdigest(),'rows':rows,'commands':commands,'executable_functions':34,'assertions':170476,'passed':True,'admission':'Entire serial side runner admitted through build-slot; no parallel compiler/guest processes.'}
(directory/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(p.stdout.decode(),end='')
print('Admission identities verified:',len(rows),'positive',sum(x['actual_intrinsic'] for x in rows),'negative',sum(not x['actual_intrinsic'] for x in rows))
