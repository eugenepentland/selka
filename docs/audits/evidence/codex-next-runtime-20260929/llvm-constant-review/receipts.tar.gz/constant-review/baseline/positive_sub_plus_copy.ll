target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @positive_sub_plus_copy(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  store i64 1, ptr %slot3, align 8
  %v7 = load i64, ptr %slot1, align 8
  %v8 = load i64, ptr %slot3, align 8
  %op9 = sub i64 %v7, %v8
  store i64 %op9, ptr %slot4, align 8
  %v10 = load i64, ptr %slot1, align 8
  %cmp11 = icmp slt i64 %v10, 9223372036854775809
  %cv12 = zext i1 %cmp11 to i64
  store i64 %cv12, ptr %slot5, align 8
  %v13 = load i64, ptr %slot4, align 8
  %v14 = load i64, ptr %slot5, align 8
  %op15 = xor i64 %v13, %v14
  store i64 %op15, ptr %slot6, align 8
  %v16 = load i64, ptr %slot6, align 8
  ret i64 %v16
}
