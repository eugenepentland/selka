target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @negative_derived_alias_write(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %mem9 = alloca i8, i64 8, align 8
  %ptr10 = ptrtoint ptr %mem9 to i64
  store i64 %ptr10, ptr %slot3, align 8
  %v11 = load i64, ptr %slot3, align 8
  %p12 = inttoptr i64 %v11 to ptr
  store i64 1, ptr %p12, align 8, !alias.scope !3, !noalias !4
  %v13 = load i64, ptr %slot3, align 8
  %p15 = inttoptr i64 %v13 to ptr
  %gep16 = getelementptr i8, ptr %p15, i64 0
  %op14 = ptrtoint ptr %gep16 to i64
  store i64 %op14, ptr %slot4, align 8
  %v17 = load i64, ptr %slot4, align 8
  %p18 = inttoptr i64 %v17 to ptr
  store i64 2, ptr %p18, align 8, !alias.scope !3, !noalias !4
  %v19 = load i64, ptr %slot3, align 8
  %p20 = inttoptr i64 %v19 to ptr
  %ld21 = load i64, ptr %p20, align 8, !alias.scope !3, !noalias !4
  store i64 %ld21, ptr %slot5, align 8
  %v22 = load i64, ptr %slot1, align 8
  %v23 = load i64, ptr %slot5, align 8
  %op24 = sub i64 %v22, %v23
  store i64 %op24, ptr %slot6, align 8
  %v25 = load i64, ptr %slot1, align 8
  %cmp26 = icmp slt i64 %v25, 9223372036854775809
  %cv27 = zext i1 %cmp26 to i64
  store i64 %cv27, ptr %slot7, align 8
  %v28 = load i64, ptr %slot6, align 8
  %v29 = load i64, ptr %slot7, align 8
  %op30 = xor i64 %v28, %v29
  store i64 %op30, ptr %slot8, align 8
  %v31 = load i64, ptr %slot8, align 8
  ret i64 %v31
}

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
