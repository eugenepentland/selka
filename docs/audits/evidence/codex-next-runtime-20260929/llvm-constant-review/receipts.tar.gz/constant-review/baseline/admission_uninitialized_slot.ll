target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @admission_uninitialized_slot(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %mem8 = alloca i8, i64 8, align 8
  %ptr9 = ptrtoint ptr %mem8 to i64
  store i64 %ptr9, ptr %slot3, align 8
  %v10 = load i64, ptr %slot3, align 8
  %p11 = inttoptr i64 %v10 to ptr
  %ld12 = load i64, ptr %p11, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12, ptr %slot4, align 8
  %v13 = load i64, ptr %slot1, align 8
  %v14 = load i64, ptr %slot4, align 8
  %op15 = sub i64 %v13, %v14
  store i64 %op15, ptr %slot5, align 8
  %v16 = load i64, ptr %slot1, align 8
  %cmp17 = icmp slt i64 %v16, 9223372036854775809
  %cv18 = zext i1 %cmp17 to i64
  store i64 %cv18, ptr %slot6, align 8
  %v19 = load i64, ptr %slot5, align 8
  %v20 = load i64, ptr %slot6, align 8
  %op21 = xor i64 %v19, %v20
  store i64 %op21, ptr %slot7, align 8
  %v22 = load i64, ptr %slot7, align 8
  ret i64 %v22
}

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
