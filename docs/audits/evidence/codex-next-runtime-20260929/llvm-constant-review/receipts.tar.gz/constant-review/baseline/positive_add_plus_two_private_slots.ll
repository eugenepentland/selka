target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @positive_add_plus_two_private_slots(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %mem9 = alloca i8, i64 8, align 8
  %ptr10 = ptrtoint ptr %mem9 to i64
  store i64 %ptr10, ptr %slot3, align 8
  %mem11 = alloca i8, i64 8, align 8
  %ptr12 = ptrtoint ptr %mem11 to i64
  store i64 %ptr12, ptr %slot4, align 8
  %v13 = load i64, ptr %slot3, align 8
  %p14 = inttoptr i64 %v13 to ptr
  store i64 1, ptr %p14, align 8, !alias.scope !3, !noalias !4
  %v15 = load i64, ptr %slot4, align 8
  %p16 = inttoptr i64 %v15 to ptr
  store i64 99, ptr %p16, align 8, !alias.scope !3, !noalias !4
  %v17 = load i64, ptr %slot3, align 8
  %p18 = inttoptr i64 %v17 to ptr
  %ld19 = load i64, ptr %p18, align 8, !alias.scope !3, !noalias !4
  store i64 %ld19, ptr %slot5, align 8
  %v20 = load i64, ptr %slot1, align 8
  %v21 = load i64, ptr %slot5, align 8
  %op22 = add i64 %v20, %v21
  store i64 %op22, ptr %slot6, align 8
  %v23 = load i64, ptr %slot1, align 8
  %cmp24 = icmp sgt i64 %v23, 9223372036854775806
  %cv25 = zext i1 %cmp24 to i64
  store i64 %cv25, ptr %slot7, align 8
  %v26 = load i64, ptr %slot6, align 8
  %v27 = load i64, ptr %slot7, align 8
  %op28 = xor i64 %v26, %v27
  store i64 %op28, ptr %slot8, align 8
  %v29 = load i64, ptr %slot8, align 8
  ret i64 %v29
}

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
