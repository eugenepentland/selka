target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @admission_indirect_slot_callee(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %mem8 = alloca i8, i64 8, align 8
  %ptr9 = ptrtoint ptr %mem8 to i64
  store i64 %ptr9, ptr %slot3, align 8
  %v10 = load i64, ptr %slot3, align 8
  %p11 = inttoptr i64 %v10 to ptr
  store i64 1, ptr %p11, align 8, !alias.scope !3, !noalias !4
  %v12 = load i64, ptr %slot3, align 8
  %p13 = inttoptr i64 %v12 to ptr
  %v14 = load i64, ptr %slot2, align 8
  call void %p13(i64 %v14)
  %v15 = load i64, ptr %slot3, align 8
  %p16 = inttoptr i64 %v15 to ptr
  %ld17 = load i64, ptr %p16, align 8, !alias.scope !3, !noalias !4
  store i64 %ld17, ptr %slot4, align 8
  %v18 = load i64, ptr %slot1, align 8
  %v19 = load i64, ptr %slot4, align 8
  %op20 = sub i64 %v18, %v19
  store i64 %op20, ptr %slot5, align 8
  %v21 = load i64, ptr %slot1, align 8
  %cmp22 = icmp slt i64 %v21, 9223372036854775809
  %cv23 = zext i1 %cmp22 to i64
  store i64 %cv23, ptr %slot6, align 8
  %v24 = load i64, ptr %slot5, align 8
  %v25 = load i64, ptr %slot6, align 8
  %op26 = xor i64 %v24, %v25
  store i64 %op26, ptr %slot7, align 8
  %v27 = load i64, ptr %slot7, align 8
  ret i64 %v27
}

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
