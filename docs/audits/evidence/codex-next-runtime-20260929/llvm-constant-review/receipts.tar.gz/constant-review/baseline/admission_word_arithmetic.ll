target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @admission_word_arithmetic(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i32, align 8
  %slot4 = alloca i32, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  store i32 1, ptr %slot3, align 8
  %v7 = load i64, ptr %slot1, align 8
  %cv8 = trunc i64 %v7 to i32
  %v9 = load i32, ptr %slot3, align 8
  %op10 = sub i32 %cv8, %v9
  store i32 %op10, ptr %slot4, align 8
  %v11 = load i64, ptr %slot1, align 8
  %cmp12 = icmp slt i64 %v11, 9223372036854775809
  %cv13 = zext i1 %cmp12 to i64
  store i64 %cv13, ptr %slot5, align 8
  %v14 = load i32, ptr %slot4, align 8
  %cv15 = zext i32 %v14 to i64
  %v16 = load i64, ptr %slot5, align 8
  %op17 = xor i64 %cv15, %v16
  store i64 %op17, ptr %slot6, align 8
  %v18 = load i64, ptr %slot6, align 8
  ret i64 %v18
}
