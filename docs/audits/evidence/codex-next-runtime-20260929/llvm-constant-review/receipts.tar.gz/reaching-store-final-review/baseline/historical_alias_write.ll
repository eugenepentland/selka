target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @historical_alias_write(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %mem9 = alloca i8, i64 8, align 8
  %ptr10 = ptrtoint ptr %mem9 to i64
  store i64 %ptr10, ptr %slot3, align 8
  %v11 = load i64, ptr %slot3, align 8
  store i64 %v11, ptr %slot4, align 8
  %v12 = load i64, ptr %slot3, align 8
  %p13 = inttoptr i64 %v12 to ptr
  store i64 1, ptr %p13, align 8, !alias.scope !3, !noalias !4
  %v14 = load i64, ptr %slot4, align 8
  %p15 = inttoptr i64 %v14 to ptr
  store i64 2, ptr %p15, align 8, !alias.scope !3, !noalias !4
  %v16 = load i64, ptr %slot3, align 8
  %p17 = inttoptr i64 %v16 to ptr
  %ld18 = load i64, ptr %p17, align 8, !alias.scope !3, !noalias !4
  store i64 %ld18, ptr %slot5, align 8
  %v19 = load i64, ptr %slot1, align 8
  %v20 = load i64, ptr %slot5, align 8
  %op21 = sub i64 %v19, %v20
  store i64 %op21, ptr %slot6, align 8
  %v22 = load i64, ptr %slot1, align 8
  %cmp23 = icmp slt i64 %v22, 9223372036854775809
  %cv24 = zext i1 %cmp23 to i64
  store i64 %cv24, ptr %slot7, align 8
  %v25 = load i64, ptr %slot6, align 8
  %v26 = load i64, ptr %slot7, align 8
  %op27 = xor i64 %v25, %v26
  store i64 %op27, ptr %slot8, align 8
  %v28 = load i64, ptr %slot8, align 8
  ret i64 %v28
}

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
