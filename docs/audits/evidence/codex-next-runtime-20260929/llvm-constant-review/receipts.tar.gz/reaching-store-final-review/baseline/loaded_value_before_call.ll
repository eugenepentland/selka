target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @loaded_value_before_call(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %mem8 = alloca i8, i64 8, align 8
  %ptr9 = ptrtoint ptr %mem8 to i64
  store i64 %ptr9, ptr %slot3, align 8
  %v10 = load i64, ptr %slot3, align 8
  %p11 = inttoptr i64 %v10 to ptr
  store i64 1, ptr %p11, align 8, !alias.scope !3, !noalias !4
  %v12 = load i64, ptr %slot3, align 8
  %p13 = inttoptr i64 %v12 to ptr
  %ld14 = load i64, ptr %p13, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14, ptr %slot4, align 8
  %v15 = load i64, ptr %slot3, align 8
  call void @touch(i64 %v15)
  %v16 = load i64, ptr %slot1, align 8
  %v17 = load i64, ptr %slot4, align 8
  %op18 = sub i64 %v16, %v17
  store i64 %op18, ptr %slot5, align 8
  %v19 = load i64, ptr %slot1, align 8
  %cmp20 = icmp slt i64 %v19, 9223372036854775809
  %cv21 = zext i1 %cmp20 to i64
  store i64 %cv21, ptr %slot6, align 8
  %v22 = load i64, ptr %slot5, align 8
  %v23 = load i64, ptr %slot6, align 8
  %op24 = xor i64 %v22, %v23
  store i64 %op24, ptr %slot7, align 8
  %v25 = load i64, ptr %slot7, align 8
  ret i64 %v25
}

declare void @touch(i64)

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
