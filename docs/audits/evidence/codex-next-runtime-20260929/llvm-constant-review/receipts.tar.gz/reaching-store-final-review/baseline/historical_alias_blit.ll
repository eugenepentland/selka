target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @historical_alias_blit(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %mem9 = alloca i8, i64 8, align 8
  %ptr10 = ptrtoint ptr %mem9 to i64
  store i64 %ptr10, ptr %slot3, align 8
  %v11 = load i64, ptr %slot3, align 8
  store i64 %v11, ptr %slot4, align 8
  %v12 = load i64, ptr %slot3, align 8
  %p13 = inttoptr i64 %v12 to ptr
  store i64 1, ptr %p13, align 8, !alias.scope !3, !noalias !4
  %v14 = load i64, ptr %slot2, align 8
  %v15 = load i64, ptr %slot4, align 8
  %p16 = inttoptr i64 %v14 to ptr
  %p17 = inttoptr i64 %v15 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p17, ptr %p16, i64 8, i1 false), !alias.scope !10000000
  %v18 = load i64, ptr %slot3, align 8
  %p19 = inttoptr i64 %v18 to ptr
  %ld20 = load i64, ptr %p19, align 8, !alias.scope !3, !noalias !4
  store i64 %ld20, ptr %slot5, align 8
  %v21 = load i64, ptr %slot1, align 8
  %v22 = load i64, ptr %slot5, align 8
  %op23 = sub i64 %v21, %v22
  store i64 %op23, ptr %slot6, align 8
  %v24 = load i64, ptr %slot1, align 8
  %cmp25 = icmp slt i64 %v24, 9223372036854775809
  %cv26 = zext i1 %cmp25 to i64
  store i64 %cv26, ptr %slot7, align 8
  %v27 = load i64, ptr %slot6, align 8
  %v28 = load i64, ptr %slot7, align 8
  %op29 = xor i64 %v27, %v28
  store i64 %op29, ptr %slot8, align 8
  %v30 = load i64, ptr %slot8, align 8
  ret i64 %v30
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
