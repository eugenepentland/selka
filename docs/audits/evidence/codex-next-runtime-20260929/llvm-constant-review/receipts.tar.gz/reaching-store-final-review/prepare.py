import json
from pathlib import Path

work=Path(__file__).resolve().parent
cases=[]
forms=[('add','1','csgtl','9223372036854775806'),('add','-1','csltl','-9223372036854775807'),('sub','1','csltl','-9223372036854775807'),('sub','-1','csgtl','9223372036854775806')]
for op,rhs,cmp,limit in forms:
    for flow in ['literal','slot','copy','two_private_slots']:
        start=''
        operand=rhs
        if flow=='slot':start=f' %slot =l alloc8 8\n storel {rhs}, %slot\n %rhs =l loadl %slot\n';operand='%rhs'
        if flow=='copy':start=f' %rhs =l copy {rhs}\n';operand='%rhs'
        if flow=='two_private_slots':start=f' %slot =l alloc8 8\n %other_slot =l alloc8 8\n storel {rhs}, %slot\n storel 99, %other_slot\n %rhs =l loadl %slot\n';operand='%rhs'
        body=start+f' %result =l {op} %a, {operand}\n %flag =l {cmp} %a, {limit}\n'
        cases.append(dict(name=f'positive_{op}_{"plus" if rhs=="1" else "minus"}_{flow}',body=body,admit=True,execute=True,op=op,rhs=int(rhs),cmp=cmp,limit=int(limit),flag_a=None))

before=' %slot =l alloc8 8\n storel 1, %slot\n'
after=' %rhs =l loadl %slot\n %result =l sub %a, %rhs\n %flag =l csltl %a, -9223372036854775807\n'
negatives=[
 ('escaped_call',before+' call $touch(l %slot)\n'+after,2),
 ('nested_call_escape',before+' call $touch(l call $identity(l %slot))\n'+after,2),
 ('copy_address_unused',before+' %alias =l copy %slot\n'+after,1),
 ('derived_address_unused',before+' %alias =l add %slot, 0\n'+after,1),
 ('derived_alias_write',before+' %alias =l add %slot, 0\n storel 2, %alias\n'+after,2),
 ('other_store_reset',before+' storel 2, %other\n'+after,1),
 ('other_call_reset',before+' call $touch(l %other)\n'+after,1),
 ('overwritten_slot',before+' storel 2, %slot\n'+after,2),
 ('partial_word_store',before+' storew 2, %slot\n'+after,2),
 ('copied_bytes_slot',before+' blit %other, %slot, 8\n'+after,2),
 ('facts_cross_block',before+' jmp @next\n@next\n'+after,1),
 ('result_cross_block',before+' %rhs =l loadl %slot\n %result =l sub %a, %rhs\n jmp @next\n@next\n %flag =l csltl %a, -9223372036854775807\n',1),
 ('direct_literal_two',' %result =l sub %a, 2\n %flag =l csltl %a, -9223372036854775807\n',2),
 ('wrong_bound',before+' %rhs =l loadl %slot\n %result =l sub %a, %rhs\n %flag =l csltl %a, -9223372036854775808\n',1),
 ('rebound_left',before+' %rhs =l loadl %slot\n %result =l sub %a, %rhs\n %a =l copy 7\n %flag =l csltl %a, -9223372036854775807\n',1),
 ('commuted_sub_operands',' %result =l sub 1, %a\n %flag =l csltl %a, -9223372036854775807\n',1),
 ('redefined_slot',before+' %slot =l copy %other\n'+after,2),
 ('future_address_escape',before+after+' %escaped =l copy %slot\n',1),
]
for name,body,rhs in negatives:
    cases.append(dict(name='negative_'+name,body=body,admit=False,execute=True,op='sub',rhs=rhs,cmp='csltl',limit=-9223372036854775808 if name=='wrong_bound' else -9223372036854775807,flag_a=7 if name=='rebound_left' else None,swapped=name=='commuted_sub_operands'))

# These are admission-only probes: malformed/undefined raw IL is never called
# a valid positive executable and cannot supply a semantic acceptance count.
extra=[
 ('extent_four',' %slot =l alloc8 4\n storel 1, %slot\n'+after),
 ('alignment_four',' %slot =l alloc4 8\n storel 1, %slot\n'+after),
 ('word_load_destination',before+' %rhs =w loadl %slot\n %result =l sub %a, %rhs\n %flag =l csltl %a, -9223372036854775807\n'),
 ('word_arithmetic',' %rhs =w copy 1\n %result =w sub %a, %rhs\n %flag =l csltl %a, -9223372036854775807\n'),
 ('uninitialized_slot',' %slot =l alloc8 8\n'+after),
 ('indirect_slot_callee',before+' call %slot(l %other)\n'+after),
 ('pointer_operand_marked',before+' # myl-obj %a\n'+after),
]
for name,body in extra:cases.append(dict(name='admission_'+name,body=body,admit=False,execute=False))

# Approved conservative reaching-store refinement: every store resets facts.
for case in cases:
    if case['name'].endswith('two_private_slots'):
        case['admit']=False
    if case['name']=='negative_future_address_escape':
        case['admit']=True
for op,rhs,cmp,limit in forms:
    body=f' %slot =l alloc8 8\n %alias =l copy %slot\n storel {rhs}, %slot\n %rhs =l loadl %slot\n %result =l {op} %a, %rhs\n %flag =l {cmp} %a, {limit}\n'
    cases.append(dict(name=f'historical_escape_{op}_{"plus" if rhs=="1" else "minus"}',body=body,admit=True,execute=True,op=op,rhs=int(rhs),cmp=cmp,limit=int(limit),flag_a=None))
new_cases=[
 ('fresh_store_after_call',before+' call $touch(l %slot)\n storel 1, %slot\n'+after,True,1),
 ('loaded_value_before_call',before+' %rhs =l loadl %slot\n call $touch(l %slot)\n %result =l sub %a, %rhs\n %flag =l csltl %a, -9223372036854775807\n',True,1),
 ('historical_alias_write',' %slot =l alloc8 8\n %alias =l copy %slot\n storel 1, %slot\n storel 2, %alias\n'+after,False,2),
 ('historical_alias_blit',' %slot =l alloc8 8\n %alias =l copy %slot\n storel 1, %slot\n blit %other, %alias, 8\n'+after,False,2),
 ('historical_alias_load',' %slot =l alloc8 8\n %alias =l copy %slot\n storel 1, %slot\n %rhs =l loadl %alias\n %result =l sub %a, %rhs\n %flag =l csltl %a, -9223372036854775807\n',False,1),
]
for name,body,admit,rhs in new_cases:
    cases.append(dict(name=name,body=body,admit=admit,execute=True,op='sub',rhs=rhs,cmp='csltl',limit=-9223372036854775807,flag_a=None))

fixture=work/'fixtures';fixture.mkdir(exist_ok=True)
for case in cases:
    name=case['name']
    tail=' %answer =l xor %result, %flag\n ret %answer\n'
    (fixture/(name+'.ssa')).write_text(f'export function l ${name}(l %a, l %other) {{\n@start\n'+case['body']+tail+'}\n')
(work/'design.json').write_text(json.dumps(cases,indent=2)+'\n')

execute=[case for case in cases if case['execute']]
lines=['#include <stdint.h>','#include <limits.h>','#include <stdio.h>','#include <stdlib.h>',
 'void touch(uint64_t *p) { *p=2; }','uintptr_t identity(uintptr_t p) { return p; }']
for case in execute:lines.append('extern uint64_t '+case['name']+'(uint64_t,uintptr_t);')
lines.append('int main(void) { unsigned long checks=0; uint64_t state=UINT64_C(0x6a09e667f3bcc909);')
lines.append('uint64_t edges[]={0,1,2,UINT64_MAX,UINT64_MAX-1,INT64_MAX,INT64_MAX-1,INT64_MAX-2,UINT64_C(0x8000000000000000),UINT64_C(0x8000000000000001),UINT64_C(0x8000000000000002),UINT64_C(0xffffffff),UINT64_C(0x100000000),UINT64_C(0x100000001)};')
lines.append('for (unsigned i=0;i<5014;++i) { state^=state<<13; state^=state>>7; state^=state<<17; uint64_t a=i<14?edges[i]:state;')
for case in execute:
    other='other_'+case['name'];name=case['name'];rhs=case['rhs']
    left='UINT64_C(1)' if case.get('swapped') else 'a'
    right='a' if case.get('swapped') else f'UINT64_C({rhs & ((1<<64)-1)})'
    result=left+('+' if case['op']=='add' else '-')+right
    flag_a=f'INT64_C({case["flag_a"]})' if case['flag_a'] is not None else '(int64_t)a'
    limit='(INT64_MIN)' if case['limit']==-(1<<63) else ('(INT64_MIN+1)' if case['limit']==-(1<<63)+1 else '(INT64_MAX-1)')
    flag=f'({flag_a}{">" if case["cmp"]=="csgtl" else "<"}{limit})'
    lines.append(f'{{ uint64_t {other}=2; uint64_t got={name}(a,(uintptr_t)&{other}); uint64_t want=({result})^(uint64_t){flag}; ++checks; if(got!=want) {{ fprintf(stderr,"{name} i=%u a=%016llx got=%016llx want=%016llx\\n",i,(unsigned long long)a,(unsigned long long)got,(unsigned long long)want); return 1; }} }}')
lines.append('} printf("constant review: %lu assertions in '+str(len(execute))+' functions passed\\n",checks); return 0; }')
(work/'oracle.c').write_text('\n'.join(lines)+'\n')
print('Prepared',len(cases),'admission cases,',len(execute),'executable functions,',len(execute)*5014,'assertions per side')
