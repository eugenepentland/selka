target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @positive_add_minus_literal(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %v6 = load i64, ptr %slot1, align 8
  %ovpair8 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v6, i64 18446744073709551615)
  %op7 = extractvalue { i64, i1 } %ovpair8, 0
  %ov9 = extractvalue { i64, i1 } %ovpair8, 1
  store i64 %op7, ptr %slot3, align 8
  %cv10 = zext i1 %ov9 to i64
  store i64 %cv10, ptr %slot4, align 8
  %v11 = load i64, ptr %slot3, align 8
  %v12 = load i64, ptr %slot4, align 8
  %op13 = xor i64 %v11, %v12
  store i64 %op13, ptr %slot5, align 8
  %v14 = load i64, ptr %slot5, align 8
  ret i64 %v14
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
