target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @negative_future_address_escape(i64 %p_a, i64 %p_other) {
bb_start:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  store i64 %p_a, ptr %slot1, align 8
  store i64 %p_other, ptr %slot2, align 8
  %mem9 = alloca i8, i64 8, align 8
  %ptr10 = ptrtoint ptr %mem9 to i64
  store i64 %ptr10, ptr %slot3, align 8
  %v11 = load i64, ptr %slot3, align 8
  %p12 = inttoptr i64 %v11 to ptr
  store i64 1, ptr %p12, align 8, !alias.scope !3, !noalias !4
  %v13 = load i64, ptr %slot3, align 8
  %p14 = inttoptr i64 %v13 to ptr
  %ld15 = load i64, ptr %p14, align 8, !alias.scope !3, !noalias !4
  store i64 %ld15, ptr %slot4, align 8
  %v16 = load i64, ptr %slot1, align 8
  %v17 = load i64, ptr %slot4, align 8
  %ovpair19 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v16, i64 %v17)
  %op18 = extractvalue { i64, i1 } %ovpair19, 0
  %ov20 = extractvalue { i64, i1 } %ovpair19, 1
  store i64 %op18, ptr %slot5, align 8
  %cv21 = zext i1 %ov20 to i64
  store i64 %cv21, ptr %slot6, align 8
  %v22 = load i64, ptr %slot3, align 8
  store i64 %v22, ptr %slot7, align 8
  %v23 = load i64, ptr %slot5, align 8
  %v24 = load i64, ptr %slot6, align 8
  %op25 = xor i64 %v23, %v24
  store i64 %op25, ptr %slot8, align 8
  %v26 = load i64, ptr %slot8, align 8
  ret i64 %v26
}

declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
