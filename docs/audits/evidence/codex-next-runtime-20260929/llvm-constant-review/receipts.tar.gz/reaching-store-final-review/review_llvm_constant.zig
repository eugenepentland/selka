const std = @import("std");
const llvm = @import("qbe_build_llvm.zig");

pub fn main(init: std.process.Init) !void {
    const arena = init.arena.allocator();
    const args = try init.minimal.args.toSlice(arena);
    const source = try std.Io.Dir.cwd().readFileAlloc(init.io, args[1], arena, .unlimited);
    var signatures: llvm.Signatures = .empty;
    try signatures.put(arena, "touch", .{ .parameters = &.{"l"}, .result = null });
    try signatures.put(arena, "identity", .{ .parameters = &.{"l"}, .result = "l" });
    const table: llvm.RuntimeTable = .{};
    var diagnostic: llvm.Diagnostic = .{ .unit = "independent-constant-review" };
    const ir = try llvm.translate(arena, source, .{ .signatures = &signatures, .runtime = &table, .sticky = false }, &diagnostic);
    try std.Io.File.stdout().writeStreamingAll(init.io, ir);
}
