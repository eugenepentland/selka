"""Read-only QBE attribution on allocated-section-identical Lox counterparts."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

work = Path(__file__).resolve().parent
own = work.parents[1]
tools = work / 'valgrind-local/usr'
env = {k: v for k, v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env.update(TMPDIR=str(own / '.tmp'), ZIG_GLOBAL_CACHE_DIR=str(own / '.zig-global-cache'),
           MYLANG_MEMORY_LIMIT='8G', VALGRIND_LIB=str(tools / 'libexec/valgrind'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = json.loads((work / 'inputs.json').read_text())
selection = json.loads((work / 'inputs-selection.json').read_text())
receipt = {'source_candidate': identity['source_candidate'], 'cpu': 6,
           'tool': subprocess.check_output([str(tools / 'bin/valgrind'), '--version'], env=env).decode().strip(),
           'scope': 'Exact simulated attribution only; no timing acceptance, Guardian or source edits.',
           'cases': {}}


def parse(path):
    counts, calls = collections.Counter(), collections.Counter()
    ips = collections.defaultdict(collections.Counter)
    fn = callee = None
    in_call = False
    total = None
    for line in path.read_text().splitlines():
        if line.startswith('summary: '):
            total = int(line.split()[1])
        elif line.startswith('fn='):
            fn = line[3:]
        elif line.startswith('cfn='):
            callee = line[4:]
        elif line.startswith('calls='):
            calls[fn, callee] += int(line[6:].split()[0])
            in_call = True
        elif line.startswith('0x'):
            fields = line.split()
            if in_call:
                in_call = False
            elif len(fields) == 3:
                counts[fn] += int(fields[2])
                ips[fn][int(fields[0], 16)] += int(fields[2])
    assert sum(counts.values()) == total
    table = json.loads((work / 'candidate/lox.symbols.qbe-manifest.json').read_text())
    names = {f['symbol']: f['name'] for f in table['functions']}
    return {'total': total, 'self': dict(counts), 'names': names,
            'calls': [{'caller': f, 'callee': c, 'count': n} for (f, c), n in calls.items()],
            'instructions': {f: {hex(a): n for a, n in v.items()} for f, v in ips.items()}}


for case, input_name in selection.items():
    records = receipt['cases'][case] = {}
    results = {}
    for side in ('control', 'candidate'):
        binary = work / side / 'lox.symbols'
        assert sha(binary) == identity['sides'][side]['symbol_binary_sha256']
        dest = work / case / side
        dest.mkdir(parents=True, exist_ok=False)
        command = [str(own / 'scripts/build-slot.sh'), 'build', 'taskset', '-c', '6',
                   str(tools / 'bin/valgrind'), '--tool=callgrind', '--dump-instr=yes',
                   '--collect-jumps=yes', '--compress-pos=no', '--compress-strings=no',
                   '--callgrind-out-file=' + str(dest / 'callgrind.out'), str(binary),
                   '--engine=vm', str(work / input_name)]
        print(case, side, 'starting', flush=True)
        started = time.monotonic()
        done = subprocess.run(command, cwd=work, env=env, capture_output=True)
        (dest / 'stdout').write_bytes(done.stdout)
        (dest / 'stderr').write_bytes(done.stderr)
        records[side] = {'admission_command': command, 'status': done.returncode,
                         'elapsed_seconds': time.monotonic() - started,
                         'stdout': done.stdout.decode(), 'binary_sha256': sha(binary)}
        (work / 'profile-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        assert done.returncode == 0, done.stderr.decode(errors='replace')
        results[side] = parse(dest / 'callgrind.out')
    assert records['control']['stdout'] == records['candidate']['stdout']
    a, b = results['control'], results['candidate']
    delta = [{'function': f, 'name': b['names'].get(f, f),
              'control': a['self'].get(f, 0), 'candidate': b['self'].get(f, 0),
              'delta': b['self'].get(f, 0) - a['self'].get(f, 0)}
             for f in a['self'].keys() | b['self'].keys()]
    delta.sort(key=lambda x: abs(x['delta']), reverse=True)
    result = dict(results, total_delta=b['total'] - a['total'], function_deltas=delta)
    (work / case / 'exact-counts.json').write_text(json.dumps(result, indent=2) + '\n')
    print(case, 'totals', a['total'], b['total'], 'delta', result['total_delta'], flush=True)
    for r in delta[:12]:
        print(r['name'], r['delta'], flush=True)
