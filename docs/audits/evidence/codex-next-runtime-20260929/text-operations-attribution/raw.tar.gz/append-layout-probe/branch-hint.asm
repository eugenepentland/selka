
.tmp/text-ops-final-review/append-layout-probe/branch-hint.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <myl_r_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>:
       0:	push   %rbp
       1:	mov    %rsp,%rbp
       4:	pop    %rbp
       5:	jmp    a <myl_r_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a+0xa>
       a:	nopw   0x0(%rax,%rax,1)

0000000000000010 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan>:
      10:	push   %rbp
      11:	mov    %rsp,%rbp
      14:	mov    %rdx,%rcx
      17:	mov    %rsi,%rdx
      1a:	cmpl   $0x1,(%rcx)
      1d:	jne    61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      1f:	mov    0x8(%rcx),%eax
      22:	cmp    $0x1,%eax
      25:	je     2b <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x1b>
      27:	test   %eax,%eax
      29:	jne    61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      2b:	mov    0x10(%rcx),%rsi
      2f:	test   %rsi,%rsi
      32:	je     44 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x34>
      34:	movabs $0x4000000000000002,%r8
      3e:	test   %r8,-0x10(%rsi)
      42:	je     78 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x68>
      44:	mov    0x10(%rcx),%rax
      48:	test   %rax,%rax
      4b:	je     61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      4d:	movabs $0x4000000000000002,%rsi
      57:	test   %rsi,-0x10(%rax)
      5b:	jne    61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      5d:	incq   -0x18(%rax)
      61:	mov    0x10(%rcx),%rax
      65:	mov    %rax,0x10(%rdx)
      69:	vmovups (%rcx),%xmm0
      6d:	vmovups %xmm0,(%rdx)
      71:	mov    $0x1,%eax
      76:	pop    %rbp
      77:	ret
      78:	cmpq   $0xfffffffffffffffd,-0x18(%rsi)
      7d:	jb     8c <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x7c>
      7f:	mov    0x0(%rip),%rsi        # 86 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x76>
      86:	pop    %rbp
      87:	jmp    8c <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x7c>
      8c:	cmp    $0x1,%eax
      8f:	je     44 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x34>
      91:	test   %eax,%eax
      93:	je     44 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x34>
      95:	jmp    61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      97:	nopw   0x0(%rax,%rax,1)

00000000000000a0 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan>:
      a0:	push   %rbp
      a1:	mov    %rsp,%rbp
      a4:	push   %r14
      a6:	push   %rbx
      a7:	cmpl   $0x1,(%rsi)
      aa:	jne    f1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x51>
      ac:	mov    0x8(%rsi),%eax
      af:	cmp    $0x1,%eax
      b2:	je     b8 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x18>
      b4:	test   %eax,%eax
      b6:	jne    f1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x51>
      b8:	mov    0x10(%rsi),%rax
      bc:	movq   $0x0,0x10(%rsi)
      c4:	test   %rax,%rax
      c7:	je     f1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x51>
      c9:	movabs $0x4000000000000002,%rcx
      d3:	test   %rcx,-0x10(%rax)
      d7:	jne    f1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x51>
      d9:	mov    -0x18(%rax),%rcx
      dd:	cmp    $0x1,%rcx
      e1:	jne    ea <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x4a>
      e3:	cmpq   $0x0,-0x20(%rax)
      e8:	je     106 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x66>
      ea:	dec    %rcx
      ed:	mov    %rcx,-0x18(%rax)
      f1:	vxorps %xmm0,%xmm0,%xmm0
      f5:	vmovups %xmm0,(%rsi)
      f9:	movq   $0x0,0x10(%rsi)
     101:	pop    %rbx
     102:	pop    %r14
     104:	pop    %rbp
     105:	ret
     106:	mov    %rsi,%r14
     109:	mov    %rdi,%rbx
     10c:	mov    %rax,%rsi
     10f:	call   114 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x74>
     114:	vxorps %xmm0,%xmm0,%xmm0
     118:	vmovups %xmm0,(%r14)
     11d:	movq   $0x0,0x10(%r14)
     125:	mov    %rbx,%rdi
     128:	pop    %rbx
     129:	pop    %r14
     12b:	pop    %rbp
     12c:	jmp    131 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x91>
     131:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000140 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop>:
     140:	push   %rbp
     141:	mov    %rsp,%rbp
     144:	push   %r14
     146:	push   %rbx
     147:	cmpl   $0x1,(%rsi)
     14a:	jne    191 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x51>
     14c:	mov    0x8(%rsi),%eax
     14f:	cmp    $0x1,%eax
     152:	je     158 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x18>
     154:	test   %eax,%eax
     156:	jne    191 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x51>
     158:	mov    0x10(%rsi),%rax
     15c:	movq   $0x0,0x10(%rsi)
     164:	test   %rax,%rax
     167:	je     191 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x51>
     169:	movabs $0x4000000000000002,%rcx
     173:	test   %rcx,-0x10(%rax)
     177:	jne    191 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x51>
     179:	mov    -0x20(%rax),%rcx
     17d:	cmp    $0x1,%rcx
     181:	jne    18a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x4a>
     183:	cmpq   $0x0,-0x18(%rax)
     188:	je     1a6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x66>
     18a:	dec    %rcx
     18d:	mov    %rcx,-0x20(%rax)
     191:	vxorps %xmm0,%xmm0,%xmm0
     195:	vmovups %xmm0,(%rsi)
     199:	movq   $0x0,0x10(%rsi)
     1a1:	pop    %rbx
     1a2:	pop    %r14
     1a4:	pop    %rbp
     1a5:	ret
     1a6:	mov    %rsi,%r14
     1a9:	mov    %rdi,%rbx
     1ac:	mov    %rax,%rsi
     1af:	call   1b4 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x74>
     1b4:	vxorps %xmm0,%xmm0,%xmm0
     1b8:	vmovups %xmm0,(%r14)
     1bd:	movq   $0x0,0x10(%r14)
     1c5:	mov    %rbx,%rdi
     1c8:	pop    %rbx
     1c9:	pop    %r14
     1cb:	pop    %rbp
     1cc:	jmp    1d1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x91>
     1d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

00000000000001e0 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain>:
     1e0:	push   %rbp
     1e1:	mov    %rsp,%rbp
     1e4:	mov    %ecx,%r8d
     1e7:	mov    %rdx,%rcx
     1ea:	mov    %rsi,%rdx
     1ed:	cmpl   $0x1,(%rcx)
     1f0:	jne    264 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x84>
     1f2:	movabs $0x4000000000000002,%rax
     1fc:	mov    0x8(%rcx),%esi
     1ff:	mov    $0x1,%r9b
     202:	cmp    $0x1,%esi
     205:	je     20b <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x2b>
     207:	test   %esi,%esi
     209:	jne    21a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x3a>
     20b:	mov    0x10(%rcx),%r10
     20f:	test   %r10,%r10
     212:	je     21f <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x3f>
     214:	mov    -0x10(%r10),%r10
     218:	jmp    222 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x42>
     21a:	xor    %r10d,%r10d
     21d:	jmp    23a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x5a>
     21f:	xor    %r10d,%r10d
     222:	mov    0x10(%rcx),%r11
     226:	test   %r11,%r11
     229:	je     23a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x5a>
     22b:	test   %rax,-0x10(%r11)
     22f:	jne    23a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x5a>
     231:	cmpq   $0xfffffffffffffffd,-0x20(%r11)
     236:	setb   %r9b
     23a:	test   %r9b,%r9b
     23d:	je     27b <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x9b>
     23f:	lea    -0x2(%rax),%r9
     243:	and    %r9,%r10
     246:	jne    27b <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x9b>
     248:	cmp    $0x1,%esi
     24b:	je     251 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x71>
     24d:	test   %esi,%esi
     24f:	jne    264 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x84>
     251:	mov    0x10(%rcx),%rsi
     255:	test   %rsi,%rsi
     258:	je     264 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x84>
     25a:	test   %rax,-0x10(%rsi)
     25e:	jne    264 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x84>
     260:	incq   -0x20(%rsi)
     264:	vmovups (%rcx),%xmm0
     268:	mov    0x10(%rcx),%rax
     26c:	mov    %rax,0x10(%rdx)
     270:	vmovups %xmm0,(%rdx)
     274:	mov    $0x1,%eax
     279:	pop    %rbp
     27a:	ret
     27b:	mov    0x0(%rip),%rsi        # 282 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0xa2>
     282:	pop    %rbp
     283:	jmp    288 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0xa8>
     288:	nopl   0x0(%rax,%rax,1)

0000000000000290 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take>:
     290:	push   %rbp
     291:	mov    %rsp,%rbp
     294:	mov    %ecx,%r8d
     297:	mov    %rdx,%rcx
     29a:	mov    %rsi,%rdx
     29d:	cmpl   $0x1,(%rcx)
     2a0:	jne    2bd <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x2d>
     2a2:	mov    0x8(%rcx),%eax
     2a5:	cmp    $0x1,%eax
     2a8:	je     2ae <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x1e>
     2aa:	test   %eax,%eax
     2ac:	jne    2bd <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x2d>
     2ae:	mov    0x10(%rcx),%rax
     2b2:	test   %rax,%rax
     2b5:	je     2bd <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x2d>
     2b7:	testb  $0x50,-0x9(%rax)
     2bb:	jne    2fa <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x6a>
     2bd:	mov    %rdx,%rax
     2c0:	sub    %rcx,%rax
     2c3:	mov    %rcx,%rsi
     2c6:	sub    %rdx,%rsi
     2c9:	cmovb  %rax,%rsi
     2cd:	cmp    $0x17,%rsi
     2d1:	jbe    2fa <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x6a>
     2d3:	mov    0x10(%rcx),%rax
     2d7:	mov    %rax,0x10(%rdx)
     2db:	vmovups (%rcx),%xmm0
     2df:	vmovups %xmm0,(%rdx)
     2e3:	vxorps %xmm0,%xmm0,%xmm0
     2e7:	vmovups %xmm0,(%rcx)
     2eb:	movq   $0x0,0x10(%rcx)
     2f3:	mov    $0x1,%eax
     2f8:	pop    %rbp
     2f9:	ret
     2fa:	mov    0x0(%rip),%rsi        # 301 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x71>
     301:	pop    %rbp
     302:	jmp    307 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x77>
     307:	nopw   0x0(%rax,%rax,1)

0000000000000310 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish>:
     310:	push   %rbp
     311:	mov    %rsp,%rbp
     314:	push   %r15
     316:	push   %r14
     318:	push   %r13
     31a:	push   %r12
     31c:	push   %rbx
     31d:	push   %rax
     31e:	mov    %r8d,%r15d
     321:	mov    %ecx,%r8d
     324:	mov    %rdx,%r14
     327:	mov    %rsi,%rbx
     32a:	mov    (%rdx),%eax
     32c:	mov    $0x1,%cl
     32e:	cmp    $0x1,%eax
     331:	jne    350 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x40>
     333:	mov    0x8(%r14),%edx
     337:	cmp    $0x1,%edx
     33a:	je     340 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x30>
     33c:	test   %edx,%edx
     33e:	jne    350 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x40>
     340:	mov    0x10(%r14),%rdx
     344:	test   %rdx,%rdx
     347:	je     350 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x40>
     349:	testb  $0x50,-0x9(%rdx)
     34d:	sete   %cl
     350:	test   $0x3,%r15b
     354:	jne    3b6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xa6>
     356:	test   %cl,%cl
     358:	je     3b6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xa6>
     35a:	mov    %rbx,%rcx
     35d:	sub    %r14,%rcx
     360:	mov    %r14,%rdx
     363:	sub    %rbx,%rdx
     366:	cmovb  %rcx,%rdx
     36a:	cmp    $0x17,%rdx
     36e:	jbe    3b6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xa6>
     370:	mov    %eax,%ecx
     372:	xor    $0x1,%ecx
     375:	mov    %r15d,%edx
     378:	and    $0x4,%edx
     37b:	or     %ecx,%edx
     37d:	je     389 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x79>
     37f:	cmp    $0x1,%eax
     382:	je     3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     384:	jmp    415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     389:	mov    0x8(%r14),%eax
     38d:	cmp    $0x1,%eax
     390:	je     396 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x86>
     392:	test   %eax,%eax
     394:	jne    3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     396:	mov    0x10(%r14),%rax
     39a:	test   %rax,%rax
     39d:	je     3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     39f:	movabs $0x4000000000000002,%rcx
     3a9:	test   %rcx,-0x10(%rax)
     3ad:	jne    3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     3af:	cmpq   $0xfffffffffffffffd,-0x20(%rax)
     3b4:	jb     3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     3b6:	mov    0x0(%rip),%rsi        # 3bd <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xad>
     3bd:	mov    %rbx,%rdx
     3c0:	mov    %r14,%rcx
     3c3:	mov    %r15d,%r9d
     3c6:	add    $0x8,%rsp
     3ca:	pop    %rbx
     3cb:	pop    %r12
     3cd:	pop    %r13
     3cf:	pop    %r14
     3d1:	pop    %r15
     3d3:	pop    %rbp
     3d4:	jmp    3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     3d9:	mov    0x8(%r14),%eax
     3dd:	cmp    $0x1,%eax
     3e0:	je     3e6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xd6>
     3e2:	test   %eax,%eax
     3e4:	jne    415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     3e6:	mov    0x10(%r14),%r12
     3ea:	test   %r12,%r12
     3ed:	je     415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     3ef:	movabs $0x2000000000000000,%r13
     3f9:	lea    0x2(%r13),%rax
     3fd:	test   %rax,-0x10(%r12)
     402:	jne    415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     404:	mov    %r12,%rdi
     407:	call   40c <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xfc>
     40c:	test   %eax,%eax
     40e:	je     415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     410:	or     %r13,-0x10(%r12)
     415:	mov    0x10(%r14),%rax
     419:	mov    %rax,0x10(%rbx)
     41d:	vmovups (%r14),%xmm0
     422:	vmovups %xmm0,(%rbx)
     426:	test   $0x4,%r15b
     42a:	je     43f <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x12f>
     42c:	vxorps %xmm0,%xmm0,%xmm0
     430:	vmovups %xmm0,(%r14)
     435:	movq   $0x0,0x10(%r14)
     43d:	jmp    46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     43f:	cmpl   $0x1,(%rbx)
     442:	jne    46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     444:	mov    0x8(%rbx),%eax
     447:	cmp    $0x1,%eax
     44a:	je     450 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x140>
     44c:	test   %eax,%eax
     44e:	jne    46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     450:	mov    0x10(%rbx),%rax
     454:	test   %rax,%rax
     457:	je     46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     459:	movabs $0x4000000000000002,%rcx
     463:	test   %rcx,-0x10(%rax)
     467:	jne    46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     469:	incq   -0x20(%rax)
     46d:	mov    $0x1,%eax
     472:	add    $0x8,%rsp
     476:	pop    %rbx
     477:	pop    %r12
     479:	pop    %r13
     47b:	pop    %r14
     47d:	pop    %r15
     47f:	pop    %rbp
     480:	ret
     481:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000490 <myl_rcg_share>:
     490:	test   %rdi,%rdi
     493:	je     4c4 <myl_rcg_share+0x34>
     495:	push   %rbp
     496:	mov    %rsp,%rbp
     499:	push   %r14
     49b:	push   %rbx
     49c:	movabs $0x2000000000000000,%r14
     4a6:	lea    0x2(%r14),%rax
     4aa:	test   %rax,-0x10(%rdi)
     4ae:	jne    4c0 <myl_rcg_share+0x30>
     4b0:	mov    %rdi,%rbx
     4b3:	call   4b8 <myl_rcg_share+0x28>
     4b8:	test   %eax,%eax
     4ba:	je     4c0 <myl_rcg_share+0x30>
     4bc:	or     %r14,-0x10(%rbx)
     4c0:	pop    %rbx
     4c1:	pop    %r14
     4c3:	pop    %rbp
     4c4:	ret
     4c5:	data16 cs nopw 0x0(%rax,%rax,1)

00000000000004d0 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan>:
     4d0:	push   %rbp
     4d1:	mov    %rsp,%rbp
     4d4:	mov    %rdx,%rcx
     4d7:	mov    %rsi,%rdx
     4da:	mov    (%rcx),%eax
     4dc:	cmp    $0x1,%eax
     4df:	je     4e5 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x15>
     4e1:	test   %eax,%eax
     4e3:	jne    51c <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x4c>
     4e5:	mov    0x8(%rcx),%rax
     4e9:	test   %rax,%rax
     4ec:	je     51c <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x4c>
     4ee:	movabs $0x4000000000000002,%rsi
     4f8:	test   %rsi,-0x10(%rax)
     4fc:	jne    51c <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x4c>
     4fe:	mov    -0x18(%rax),%rsi
     502:	cmp    $0xfffffffffffffffd,%rsi
     506:	jbe    515 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x45>
     508:	mov    0x0(%rip),%rsi        # 50f <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x3f>
     50f:	pop    %rbp
     510:	jmp    515 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x45>
     515:	inc    %rsi
     518:	mov    %rsi,-0x18(%rax)
     51c:	vmovups (%rcx),%xmm0
     520:	vmovups %xmm0,(%rdx)
     524:	mov    $0x1,%eax
     529:	pop    %rbp
     52a:	ret
     52b:	nopl   0x0(%rax,%rax,1)

0000000000000530 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan>:
     530:	push   %rbp
     531:	mov    %rsp,%rbp
     534:	push   %r14
     536:	push   %rbx
     537:	mov    (%rsi),%eax
     539:	cmp    $0x1,%eax
     53c:	je     542 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x12>
     53e:	test   %eax,%eax
     540:	jne    57b <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x4b>
     542:	mov    0x8(%rsi),%rax
     546:	movq   $0x0,0x8(%rsi)
     54e:	test   %rax,%rax
     551:	je     57b <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x4b>
     553:	movabs $0x4000000000000002,%rcx
     55d:	test   %rcx,-0x10(%rax)
     561:	jne    57b <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x4b>
     563:	mov    -0x18(%rax),%rcx
     567:	cmp    $0x1,%rcx
     56b:	jne    574 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x44>
     56d:	cmpq   $0x0,-0x20(%rax)
     572:	je     588 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x58>
     574:	dec    %rcx
     577:	mov    %rcx,-0x18(%rax)
     57b:	vxorps %xmm0,%xmm0,%xmm0
     57f:	vmovups %xmm0,(%rsi)
     583:	pop    %rbx
     584:	pop    %r14
     586:	pop    %rbp
     587:	ret
     588:	mov    %rsi,%r14
     58b:	mov    %rdi,%rbx
     58e:	mov    %rax,%rsi
     591:	call   596 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x66>
     596:	vxorps %xmm0,%xmm0,%xmm0
     59a:	vmovups %xmm0,(%r14)
     59f:	mov    %rbx,%rdi
     5a2:	pop    %rbx
     5a3:	pop    %r14
     5a5:	pop    %rbp
     5a6:	jmp    5ab <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x7b>
     5ab:	nopl   0x0(%rax,%rax,1)

00000000000005b0 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop>:
     5b0:	push   %rbp
     5b1:	mov    %rsp,%rbp
     5b4:	push   %r14
     5b6:	push   %rbx
     5b7:	mov    (%rsi),%eax
     5b9:	cmp    $0x1,%eax
     5bc:	je     5c2 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x12>
     5be:	test   %eax,%eax
     5c0:	jne    5fb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x4b>
     5c2:	mov    0x8(%rsi),%rax
     5c6:	movq   $0x0,0x8(%rsi)
     5ce:	test   %rax,%rax
     5d1:	je     5fb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x4b>
     5d3:	movabs $0x4000000000000002,%rcx
     5dd:	test   %rcx,-0x10(%rax)
     5e1:	jne    5fb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x4b>
     5e3:	mov    -0x20(%rax),%rcx
     5e7:	cmp    $0x1,%rcx
     5eb:	jne    5f4 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x44>
     5ed:	cmpq   $0x0,-0x18(%rax)
     5f2:	je     608 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x58>
     5f4:	dec    %rcx
     5f7:	mov    %rcx,-0x20(%rax)
     5fb:	vxorps %xmm0,%xmm0,%xmm0
     5ff:	vmovups %xmm0,(%rsi)
     603:	pop    %rbx
     604:	pop    %r14
     606:	pop    %rbp
     607:	ret
     608:	mov    %rsi,%r14
     60b:	mov    %rdi,%rbx
     60e:	mov    %rax,%rsi
     611:	call   616 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x66>
     616:	vxorps %xmm0,%xmm0,%xmm0
     61a:	vmovups %xmm0,(%r14)
     61f:	mov    %rbx,%rdi
     622:	pop    %rbx
     623:	pop    %r14
     625:	pop    %rbp
     626:	jmp    62b <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x7b>
     62b:	nopl   0x0(%rax,%rax,1)

0000000000000630 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain>:
     630:	push   %rbp
     631:	mov    %rsp,%rbp
     634:	mov    %ecx,%r8d
     637:	mov    %rdx,%rcx
     63a:	mov    %rsi,%rdx
     63d:	mov    (%rcx),%eax
     63f:	cmp    $0x1,%eax
     642:	je     648 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x18>
     644:	test   %eax,%eax
     646:	jne    680 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x50>
     648:	mov    0x8(%rcx),%rax
     64c:	test   %rax,%rax
     64f:	je     680 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x50>
     651:	mov    -0x10(%rax),%rsi
     655:	bt     $0x3e,%rsi
     65a:	jb     66c <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x3c>
     65c:	test   $0x2,%sil
     660:	jne    680 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x50>
     662:	mov    -0x20(%rax),%rsi
     666:	cmp    $0xfffffffffffffffd,%rsi
     66a:	jbe    679 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x49>
     66c:	mov    0x0(%rip),%rsi        # 673 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x43>
     673:	pop    %rbp
     674:	jmp    679 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x49>
     679:	inc    %rsi
     67c:	mov    %rsi,-0x20(%rax)
     680:	vmovups (%rcx),%xmm0
     684:	vmovups %xmm0,(%rdx)
     688:	mov    $0x1,%eax
     68d:	pop    %rbp
     68e:	ret
     68f:	nop

0000000000000690 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take>:
     690:	push   %rbp
     691:	mov    %rsp,%rbp
     694:	mov    %ecx,%r8d
     697:	mov    %rdx,%rcx
     69a:	mov    %rsi,%rdx
     69d:	mov    (%rcx),%eax
     69f:	cmp    $0x1,%eax
     6a2:	je     6a8 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x18>
     6a4:	test   %eax,%eax
     6a6:	jne    6b7 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x27>
     6a8:	mov    0x8(%rcx),%rax
     6ac:	test   %rax,%rax
     6af:	je     6b7 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x27>
     6b1:	testb  $0x50,-0x9(%rax)
     6b5:	jne    6e4 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x54>
     6b7:	mov    %rdx,%rax
     6ba:	sub    %rcx,%rax
     6bd:	mov    %rcx,%rsi
     6c0:	sub    %rdx,%rsi
     6c3:	cmovb  %rax,%rsi
     6c7:	cmp    $0xf,%rsi
     6cb:	jbe    6e4 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x54>
     6cd:	vmovups (%rcx),%xmm0
     6d1:	vmovups %xmm0,(%rdx)
     6d5:	vxorps %xmm0,%xmm0,%xmm0
     6d9:	vmovups %xmm0,(%rcx)
     6dd:	mov    $0x1,%eax
     6e2:	pop    %rbp
     6e3:	ret
     6e4:	mov    0x0(%rip),%rsi        # 6eb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x5b>
     6eb:	pop    %rbp
     6ec:	jmp    6f1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x61>
     6f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000700 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish>:
     700:	push   %rbp
     701:	mov    %rsp,%rbp
     704:	push   %r15
     706:	push   %r14
     708:	push   %r13
     70a:	push   %r12
     70c:	push   %rbx
     70d:	push   %rax
     70e:	mov    %r8d,%r14d
     711:	mov    %ecx,%r8d
     714:	mov    %rdx,%r15
     717:	mov    %rsi,%rbx
     71a:	mov    (%rdx),%eax
     71c:	mov    $0x1,%cl
     71e:	cmp    $0x1,%eax
     721:	je     727 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x27>
     723:	test   %eax,%eax
     725:	jne    737 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x37>
     727:	mov    0x8(%r15),%rdx
     72b:	test   %rdx,%rdx
     72e:	je     737 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x37>
     730:	testb  $0x50,-0x9(%rdx)
     734:	sete   %cl
     737:	test   $0x3,%r14b
     73b:	jne    786 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x86>
     73d:	test   %cl,%cl
     73f:	je     786 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x86>
     741:	mov    %rbx,%rcx
     744:	sub    %r15,%rcx
     747:	mov    %r15,%rdx
     74a:	sub    %rbx,%rdx
     74d:	cmovb  %rcx,%rdx
     751:	cmp    $0xf,%rdx
     755:	jbe    786 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x86>
     757:	test   $0x4,%r14b
     75b:	jne    7a9 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xa9>
     75d:	cmp    $0x1,%eax
     760:	je     766 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x66>
     762:	test   %eax,%eax
     764:	jne    7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     766:	mov    0x8(%r15),%rcx
     76a:	test   %rcx,%rcx
     76d:	je     7b2 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xb2>
     76f:	movabs $0x4000000000000002,%rdx
     779:	test   %rdx,-0x10(%rcx)
     77d:	jne    7b2 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xb2>
     77f:	cmpq   $0xfffffffffffffffe,-0x20(%rcx)
     784:	jb     7a9 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xa9>
     786:	mov    0x0(%rip),%rsi        # 78d <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x8d>
     78d:	mov    %rbx,%rdx
     790:	mov    %r15,%rcx
     793:	mov    %r14d,%r9d
     796:	add    $0x8,%rsp
     79a:	pop    %rbx
     79b:	pop    %r12
     79d:	pop    %r13
     79f:	pop    %r14
     7a1:	pop    %r15
     7a3:	pop    %rbp
     7a4:	jmp    7a9 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xa9>
     7a9:	cmp    $0x1,%eax
     7ac:	je     7b2 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xb2>
     7ae:	test   %eax,%eax
     7b0:	jne    7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     7b2:	mov    0x8(%r15),%r12
     7b6:	test   %r12,%r12
     7b9:	je     7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     7bb:	movabs $0x2000000000000000,%r13
     7c5:	lea    0x2(%r13),%rax
     7c9:	test   %rax,-0x10(%r12)
     7ce:	jne    7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     7d0:	mov    %r12,%rdi
     7d3:	call   7d8 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xd8>
     7d8:	test   %eax,%eax
     7da:	je     7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     7dc:	or     %r13,-0x10(%r12)
     7e1:	vmovups (%r15),%xmm0
     7e6:	vmovups %xmm0,(%rbx)
     7ea:	test   $0x4,%r14b
     7ee:	jne    81a <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x11a>
     7f0:	mov    (%rbx),%eax
     7f2:	cmp    $0x1,%eax
     7f5:	je     7fb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xfb>
     7f7:	test   %eax,%eax
     7f9:	jne    823 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x123>
     7fb:	mov    0x8(%rbx),%rax
     7ff:	test   %rax,%rax
     802:	je     823 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x123>
     804:	movabs $0x4000000000000002,%rcx
     80e:	test   %rcx,-0x10(%rax)
     812:	jne    823 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x123>
     814:	incq   -0x20(%rax)
     818:	jmp    823 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x123>
     81a:	vxorps %xmm0,%xmm0,%xmm0
     81e:	vmovups %xmm0,(%r15)
     823:	mov    $0x1,%eax
     828:	add    $0x8,%rsp
     82c:	pop    %rbx
     82d:	pop    %r12
     82f:	pop    %r13
     831:	pop    %r14
     833:	pop    %r15
     835:	pop    %rbp
     836:	ret
     837:	nopw   0x0(%rax,%rax,1)

0000000000000840 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan>:
     840:	push   %rbp
     841:	mov    %rsp,%rbp
     844:	mov    %rdx,%rcx
     847:	mov    %rsi,%rdx
     84a:	mov    (%rcx),%rax
     84d:	test   %rax,%rax
     850:	je     876 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x36>
     852:	movabs $0x4000000000000002,%rsi
     85c:	test   %rsi,-0x10(%rax)
     860:	jne    876 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x36>
     862:	mov    -0x18(%rax),%rsi
     866:	cmp    $0xffffffffffffffff,%rsi
     86a:	je     880 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x40>
     86c:	inc    %rsi
     86f:	mov    %rsi,-0x18(%rax)
     873:	mov    (%rcx),%rax
     876:	mov    %rax,(%rdx)
     879:	mov    $0x1,%eax
     87e:	pop    %rbp
     87f:	ret
     880:	mov    0x0(%rip),%rsi        # 887 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x47>
     887:	pop    %rbp
     888:	jmp    88d <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x4d>
     88d:	nopl   (%rax)

0000000000000890 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan>:
     890:	mov    (%rsi),%rax
     893:	movq   $0x0,(%rsi)
     89a:	test   %rax,%rax
     89d:	je     8af <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x1f>
     89f:	movabs $0x4000000000000002,%rcx
     8a9:	test   %rcx,-0x10(%rax)
     8ad:	je     8b7 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x27>
     8af:	movq   $0x0,(%rsi)
     8b6:	ret
     8b7:	mov    -0x18(%rax),%rcx
     8bb:	cmp    $0x1,%rcx
     8bf:	jne    8c8 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x38>
     8c1:	cmpq   $0x0,-0x20(%rax)
     8c6:	je     8d7 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x47>
     8c8:	dec    %rcx
     8cb:	mov    %rcx,-0x18(%rax)
     8cf:	movq   $0x0,(%rsi)
     8d6:	ret
     8d7:	push   %rbp
     8d8:	mov    %rsp,%rbp
     8db:	push   %r14
     8dd:	push   %rbx
     8de:	mov    %rdi,%rbx
     8e1:	mov    %rsi,%r14
     8e4:	mov    %rax,%rsi
     8e7:	call   8ec <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x5c>
     8ec:	movq   $0x0,(%r14)
     8f3:	mov    %rbx,%rdi
     8f6:	pop    %rbx
     8f7:	pop    %r14
     8f9:	pop    %rbp
     8fa:	jmp    8ff <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x6f>
     8ff:	nop

0000000000000900 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop>:
     900:	mov    (%rsi),%rax
     903:	movq   $0x0,(%rsi)
     90a:	test   %rax,%rax
     90d:	je     91f <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x1f>
     90f:	movabs $0x4000000000000002,%rcx
     919:	test   %rcx,-0x10(%rax)
     91d:	je     927 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x27>
     91f:	movq   $0x0,(%rsi)
     926:	ret
     927:	mov    -0x20(%rax),%rcx
     92b:	cmp    $0x1,%rcx
     92f:	jne    938 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x38>
     931:	cmpq   $0x0,-0x18(%rax)
     936:	je     947 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x47>
     938:	dec    %rcx
     93b:	mov    %rcx,-0x20(%rax)
     93f:	movq   $0x0,(%rsi)
     946:	ret
     947:	push   %rbp
     948:	mov    %rsp,%rbp
     94b:	push   %r14
     94d:	push   %rbx
     94e:	mov    %rdi,%rbx
     951:	mov    %rsi,%r14
     954:	mov    %rax,%rsi
     957:	call   95c <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x5c>
     95c:	movq   $0x0,(%r14)
     963:	mov    %rbx,%rdi
     966:	pop    %rbx
     967:	pop    %r14
     969:	pop    %rbp
     96a:	jmp    96f <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x6f>
     96f:	nop

0000000000000970 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain>:
     970:	push   %rbp
     971:	mov    %rsp,%rbp
     974:	mov    %ecx,%r8d
     977:	mov    %rdx,%rcx
     97a:	mov    %rsi,%rdx
     97d:	mov    (%rcx),%rax
     980:	test   %rax,%rax
     983:	je     9aa <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x3a>
     985:	mov    -0x10(%rax),%rsi
     989:	bt     $0x3e,%rsi
     98e:	jb     9b4 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x44>
     990:	test   $0x2,%sil
     994:	jne    9aa <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x3a>
     996:	mov    -0x20(%rax),%rsi
     99a:	cmp    $0xffffffffffffffff,%rsi
     99e:	je     9b4 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x44>
     9a0:	inc    %rsi
     9a3:	mov    %rsi,-0x20(%rax)
     9a7:	mov    (%rcx),%rax
     9aa:	mov    %rax,(%rdx)
     9ad:	mov    $0x1,%eax
     9b2:	pop    %rbp
     9b3:	ret
     9b4:	mov    0x0(%rip),%rsi        # 9bb <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x4b>
     9bb:	pop    %rbp
     9bc:	jmp    9c1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x51>
     9c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

00000000000009d0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take>:
     9d0:	push   %rbp
     9d1:	mov    %rsp,%rbp
     9d4:	mov    %ecx,%r8d
     9d7:	mov    %rdx,%rcx
     9da:	mov    %rsi,%rdx
     9dd:	mov    (%rcx),%rax
     9e0:	test   %rax,%rax
     9e3:	je     9eb <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x1b>
     9e5:	testb  $0x50,-0x9(%rax)
     9e9:	jne    a12 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x42>
     9eb:	mov    %rdx,%rsi
     9ee:	sub    %rcx,%rsi
     9f1:	mov    %rcx,%r9
     9f4:	sub    %rdx,%r9
     9f7:	cmovb  %rsi,%r9
     9fb:	cmp    $0x7,%r9
     9ff:	jbe    a12 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x42>
     a01:	mov    %rax,(%rdx)
     a04:	movq   $0x0,(%rcx)
     a0b:	mov    $0x1,%eax
     a10:	pop    %rbp
     a11:	ret
     a12:	mov    0x0(%rip),%rsi        # a19 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x49>
     a19:	pop    %rbp
     a1a:	jmp    a1f <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x4f>
     a1f:	nop

0000000000000a20 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish>:
     a20:	push   %rbp
     a21:	mov    %rsp,%rbp
     a24:	push   %r15
     a26:	push   %r14
     a28:	push   %r13
     a2a:	push   %r12
     a2c:	push   %rbx
     a2d:	push   %rax
     a2e:	mov    %r8d,%r9d
     a31:	mov    %ecx,%r8d
     a34:	mov    %rdx,%rbx
     a37:	mov    %rsi,%r14
     a3a:	mov    (%rdx),%r15
     a3d:	test   %r15,%r15
     a40:	je     a52 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x32>
     a42:	testb  $0x50,-0x9(%r15)
     a47:	sete   %al
     a4a:	test   $0x3,%r9b
     a4e:	je     a5a <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x3a>
     a50:	jmp    ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a52:	mov    $0x1,%al
     a54:	test   $0x3,%r9b
     a58:	jne    ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a5a:	test   %al,%al
     a5c:	je     ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a5e:	mov    %r14,%rax
     a61:	sub    %rbx,%rax
     a64:	mov    %rbx,%rcx
     a67:	sub    %r14,%rcx
     a6a:	cmovb  %rax,%rcx
     a6e:	cmp    $0x7,%rcx
     a72:	jbe    ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a74:	test   $0x4,%r9b
     a78:	jne    af1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xd1>
     a7a:	movabs $0x4000000000000002,%r12
     a84:	test   %r15,%r15
     a87:	je     aba <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x9a>
     a89:	test   %r12,-0x10(%r15)
     a8d:	jne    a96 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x76>
     a8f:	cmpq   $0xffffffffffffffff,-0x20(%r15)
     a94:	je     ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a96:	movabs $0x2000000000000000,%r13
     aa0:	lea    0x2(%r13),%rax
     aa4:	test   %rax,-0x10(%r15)
     aa8:	jne    aba <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x9a>
     aaa:	mov    %r15,%rdi
     aad:	call   ab2 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x92>
     ab2:	test   %eax,%eax
     ab4:	je     aba <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x9a>
     ab6:	or     %r13,-0x10(%r15)
     aba:	mov    (%rbx),%rax
     abd:	mov    %rax,(%r14)
     ac0:	test   %rax,%rax
     ac3:	je     b28 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x108>
     ac5:	test   %r12,-0x10(%rax)
     ac9:	jne    b28 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x108>
     acb:	incq   -0x20(%rax)
     acf:	jmp    b28 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x108>
     ad1:	mov    0x0(%rip),%rsi        # ad8 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb8>
     ad8:	mov    %r14,%rdx
     adb:	mov    %rbx,%rcx
     ade:	add    $0x8,%rsp
     ae2:	pop    %rbx
     ae3:	pop    %r12
     ae5:	pop    %r13
     ae7:	pop    %r14
     ae9:	pop    %r15
     aeb:	pop    %rbp
     aec:	jmp    af1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xd1>
     af1:	test   %r15,%r15
     af4:	je     b1b <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xfb>
     af6:	movabs $0x2000000000000000,%r12
     b00:	lea    0x2(%r12),%rax
     b05:	test   %rax,-0x10(%r15)
     b09:	jne    b1b <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xfb>
     b0b:	mov    %r15,%rdi
     b0e:	call   b13 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xf3>
     b13:	test   %eax,%eax
     b15:	je     b1b <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xfb>
     b17:	or     %r12,-0x10(%r15)
     b1b:	mov    (%rbx),%rax
     b1e:	mov    %rax,(%r14)
     b21:	movq   $0x0,(%rbx)
     b28:	mov    $0x1,%eax
     b2d:	add    $0x8,%rsp
     b31:	pop    %rbx
     b32:	pop    %r12
     b34:	pop    %r13
     b36:	pop    %r14
     b38:	pop    %r15
     b3a:	pop    %rbp
     b3b:	ret
     b3c:	nopl   0x0(%rax)

0000000000000b40 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan>:
     b40:	push   %rbp
     b41:	mov    %rsp,%rbp
     b44:	mov    %rdx,%rcx
     b47:	mov    %rsi,%rdx
     b4a:	mov    (%rcx),%rax
     b4d:	test   %rax,%rax
     b50:	je     b76 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x36>
     b52:	movabs $0x4000000000000002,%rsi
     b5c:	test   %rsi,-0x10(%rax)
     b60:	jne    b76 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x36>
     b62:	mov    -0x18(%rax),%rsi
     b66:	cmp    $0xffffffffffffffff,%rsi
     b6a:	je     b80 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x40>
     b6c:	inc    %rsi
     b6f:	mov    %rsi,-0x18(%rax)
     b73:	mov    (%rcx),%rax
     b76:	mov    %rax,(%rdx)
     b79:	mov    $0x1,%eax
     b7e:	pop    %rbp
     b7f:	ret
     b80:	mov    0x0(%rip),%rsi        # b87 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x47>
     b87:	pop    %rbp
     b88:	jmp    b8d <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x4d>
     b8d:	nopl   (%rax)

0000000000000b90 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan>:
     b90:	mov    (%rsi),%rax
     b93:	movq   $0x0,(%rsi)
     b9a:	test   %rax,%rax
     b9d:	je     baf <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x1f>
     b9f:	movabs $0x4000000000000002,%rcx
     ba9:	test   %rcx,-0x10(%rax)
     bad:	je     bb7 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x27>
     baf:	movq   $0x0,(%rsi)
     bb6:	ret
     bb7:	mov    -0x18(%rax),%rcx
     bbb:	cmp    $0x1,%rcx
     bbf:	jne    bc8 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x38>
     bc1:	cmpq   $0x0,-0x20(%rax)
     bc6:	je     bd7 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x47>
     bc8:	dec    %rcx
     bcb:	mov    %rcx,-0x18(%rax)
     bcf:	movq   $0x0,(%rsi)
     bd6:	ret
     bd7:	push   %rbp
     bd8:	mov    %rsp,%rbp
     bdb:	push   %r14
     bdd:	push   %rbx
     bde:	mov    %rdi,%rbx
     be1:	mov    %rsi,%r14
     be4:	mov    %rax,%rsi
     be7:	call   bec <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x5c>
     bec:	movq   $0x0,(%r14)
     bf3:	mov    %rbx,%rdi
     bf6:	pop    %rbx
     bf7:	pop    %r14
     bf9:	pop    %rbp
     bfa:	jmp    bff <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x6f>
     bff:	nop

0000000000000c00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop>:
     c00:	mov    (%rsi),%rax
     c03:	movq   $0x0,(%rsi)
     c0a:	test   %rax,%rax
     c0d:	je     c1f <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x1f>
     c0f:	movabs $0x4000000000000002,%rcx
     c19:	test   %rcx,-0x10(%rax)
     c1d:	je     c27 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x27>
     c1f:	movq   $0x0,(%rsi)
     c26:	ret
     c27:	mov    -0x20(%rax),%rcx
     c2b:	cmp    $0x1,%rcx
     c2f:	jne    c38 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x38>
     c31:	cmpq   $0x0,-0x18(%rax)
     c36:	je     c47 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x47>
     c38:	dec    %rcx
     c3b:	mov    %rcx,-0x20(%rax)
     c3f:	movq   $0x0,(%rsi)
     c46:	ret
     c47:	push   %rbp
     c48:	mov    %rsp,%rbp
     c4b:	push   %r14
     c4d:	push   %rbx
     c4e:	mov    %rdi,%rbx
     c51:	mov    %rsi,%r14
     c54:	mov    %rax,%rsi
     c57:	call   c5c <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x5c>
     c5c:	movq   $0x0,(%r14)
     c63:	mov    %rbx,%rdi
     c66:	pop    %rbx
     c67:	pop    %r14
     c69:	pop    %rbp
     c6a:	jmp    c6f <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x6f>
     c6f:	nop

0000000000000c70 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain>:
     c70:	push   %rbp
     c71:	mov    %rsp,%rbp
     c74:	mov    %ecx,%r8d
     c77:	mov    %rdx,%rcx
     c7a:	mov    %rsi,%rdx
     c7d:	mov    (%rcx),%rax
     c80:	test   %rax,%rax
     c83:	je     caa <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x3a>
     c85:	mov    -0x10(%rax),%rsi
     c89:	bt     $0x3e,%rsi
     c8e:	jb     cb4 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x44>
     c90:	test   $0x2,%sil
     c94:	jne    caa <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x3a>
     c96:	mov    -0x20(%rax),%rsi
     c9a:	cmp    $0xffffffffffffffff,%rsi
     c9e:	je     cb4 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x44>
     ca0:	inc    %rsi
     ca3:	mov    %rsi,-0x20(%rax)
     ca7:	mov    (%rcx),%rax
     caa:	mov    %rax,(%rdx)
     cad:	mov    $0x1,%eax
     cb2:	pop    %rbp
     cb3:	ret
     cb4:	mov    0x0(%rip),%rsi        # cbb <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x4b>
     cbb:	pop    %rbp
     cbc:	jmp    cc1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x51>
     cc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000cd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take>:
     cd0:	push   %rbp
     cd1:	mov    %rsp,%rbp
     cd4:	mov    %ecx,%r8d
     cd7:	mov    %rdx,%rcx
     cda:	mov    %rsi,%rdx
     cdd:	mov    (%rcx),%rax
     ce0:	test   %rax,%rax
     ce3:	je     ceb <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x1b>
     ce5:	testb  $0x50,-0x9(%rax)
     ce9:	jne    d12 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x42>
     ceb:	mov    %rdx,%rsi
     cee:	sub    %rcx,%rsi
     cf1:	mov    %rcx,%r9
     cf4:	sub    %rdx,%r9
     cf7:	cmovb  %rsi,%r9
     cfb:	cmp    $0x7,%r9
     cff:	jbe    d12 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x42>
     d01:	mov    %rax,(%rdx)
     d04:	movq   $0x0,(%rcx)
     d0b:	mov    $0x1,%eax
     d10:	pop    %rbp
     d11:	ret
     d12:	mov    0x0(%rip),%rsi        # d19 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x49>
     d19:	pop    %rbp
     d1a:	jmp    d1f <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x4f>
     d1f:	nop

0000000000000d20 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish>:
     d20:	push   %rbp
     d21:	mov    %rsp,%rbp
     d24:	push   %r15
     d26:	push   %r14
     d28:	push   %r13
     d2a:	push   %r12
     d2c:	push   %rbx
     d2d:	push   %rax
     d2e:	mov    %r8d,%r9d
     d31:	mov    %ecx,%r8d
     d34:	mov    %rdx,%rbx
     d37:	mov    %rsi,%r14
     d3a:	mov    (%rdx),%r15
     d3d:	test   %r15,%r15
     d40:	je     d52 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x32>
     d42:	testb  $0x50,-0x9(%r15)
     d47:	sete   %al
     d4a:	test   $0x3,%r9b
     d4e:	je     d5a <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x3a>
     d50:	jmp    dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d52:	mov    $0x1,%al
     d54:	test   $0x3,%r9b
     d58:	jne    dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d5a:	test   %al,%al
     d5c:	je     dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d5e:	mov    %r14,%rax
     d61:	sub    %rbx,%rax
     d64:	mov    %rbx,%rcx
     d67:	sub    %r14,%rcx
     d6a:	cmovb  %rax,%rcx
     d6e:	cmp    $0x7,%rcx
     d72:	jbe    dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d74:	test   $0x4,%r9b
     d78:	jne    df1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xd1>
     d7a:	movabs $0x4000000000000002,%r12
     d84:	test   %r15,%r15
     d87:	je     dba <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x9a>
     d89:	test   %r12,-0x10(%r15)
     d8d:	jne    d96 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x76>
     d8f:	cmpq   $0xffffffffffffffff,-0x20(%r15)
     d94:	je     dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d96:	movabs $0x2000000000000000,%r13
     da0:	lea    0x2(%r13),%rax
     da4:	test   %rax,-0x10(%r15)
     da8:	jne    dba <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x9a>
     daa:	mov    %r15,%rdi
     dad:	call   db2 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x92>
     db2:	test   %eax,%eax
     db4:	je     dba <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x9a>
     db6:	or     %r13,-0x10(%r15)
     dba:	mov    (%rbx),%rax
     dbd:	mov    %rax,(%r14)
     dc0:	test   %rax,%rax
     dc3:	je     e28 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x108>
     dc5:	test   %r12,-0x10(%rax)
     dc9:	jne    e28 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x108>
     dcb:	incq   -0x20(%rax)
     dcf:	jmp    e28 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x108>
     dd1:	mov    0x0(%rip),%rsi        # dd8 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb8>
     dd8:	mov    %r14,%rdx
     ddb:	mov    %rbx,%rcx
     dde:	add    $0x8,%rsp
     de2:	pop    %rbx
     de3:	pop    %r12
     de5:	pop    %r13
     de7:	pop    %r14
     de9:	pop    %r15
     deb:	pop    %rbp
     dec:	jmp    df1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xd1>
     df1:	test   %r15,%r15
     df4:	je     e1b <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xfb>
     df6:	movabs $0x2000000000000000,%r12
     e00:	lea    0x2(%r12),%rax
     e05:	test   %rax,-0x10(%r15)
     e09:	jne    e1b <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xfb>
     e0b:	mov    %r15,%rdi
     e0e:	call   e13 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xf3>
     e13:	test   %eax,%eax
     e15:	je     e1b <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xfb>
     e17:	or     %r12,-0x10(%r15)
     e1b:	mov    (%rbx),%rax
     e1e:	mov    %rax,(%r14)
     e21:	movq   $0x0,(%rbx)
     e28:	mov    $0x1,%eax
     e2d:	add    $0x8,%rsp
     e31:	pop    %rbx
     e32:	pop    %r12
     e34:	pop    %r13
     e36:	pop    %r14
     e38:	pop    %r15
     e3a:	pop    %rbp
     e3b:	ret
     e3c:	nopl   0x0(%rax)

0000000000000e40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan>:
     e40:	push   %rbp
     e41:	mov    %rsp,%rbp
     e44:	mov    %rdx,%rcx
     e47:	mov    %rsi,%rdx
     e4a:	mov    (%rcx),%rax
     e4d:	test   %rax,%rax
     e50:	je     e76 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x36>
     e52:	movabs $0x4000000000000002,%rsi
     e5c:	test   %rsi,-0x10(%rax)
     e60:	jne    e76 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x36>
     e62:	mov    -0x18(%rax),%rsi
     e66:	cmp    $0xffffffffffffffff,%rsi
     e6a:	je     e80 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x40>
     e6c:	inc    %rsi
     e6f:	mov    %rsi,-0x18(%rax)
     e73:	mov    (%rcx),%rax
     e76:	mov    %rax,(%rdx)
     e79:	mov    $0x1,%eax
     e7e:	pop    %rbp
     e7f:	ret
     e80:	mov    0x0(%rip),%rsi        # e87 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x47>
     e87:	pop    %rbp
     e88:	jmp    e8d <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x4d>
     e8d:	nopl   (%rax)

0000000000000e90 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan>:
     e90:	mov    (%rsi),%rax
     e93:	movq   $0x0,(%rsi)
     e9a:	test   %rax,%rax
     e9d:	je     eaf <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x1f>
     e9f:	movabs $0x4000000000000002,%rcx
     ea9:	test   %rcx,-0x10(%rax)
     ead:	je     eb7 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x27>
     eaf:	movq   $0x0,(%rsi)
     eb6:	ret
     eb7:	mov    -0x18(%rax),%rcx
     ebb:	cmp    $0x1,%rcx
     ebf:	jne    ec8 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x38>
     ec1:	cmpq   $0x0,-0x20(%rax)
     ec6:	je     ed7 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x47>
     ec8:	dec    %rcx
     ecb:	mov    %rcx,-0x18(%rax)
     ecf:	movq   $0x0,(%rsi)
     ed6:	ret
     ed7:	push   %rbp
     ed8:	mov    %rsp,%rbp
     edb:	push   %r14
     edd:	push   %rbx
     ede:	mov    %rdi,%rbx
     ee1:	mov    %rsi,%r14
     ee4:	mov    %rax,%rsi
     ee7:	call   eec <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x5c>
     eec:	movq   $0x0,(%r14)
     ef3:	mov    %rbx,%rdi
     ef6:	pop    %rbx
     ef7:	pop    %r14
     ef9:	pop    %rbp
     efa:	jmp    eff <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x6f>
     eff:	nop

0000000000000f00 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>:
     f00:	mov    (%rsi),%rax
     f03:	movq   $0x0,(%rsi)
     f0a:	test   %rax,%rax
     f0d:	je     f1f <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x1f>
     f0f:	movabs $0x4000000000000002,%rcx
     f19:	test   %rcx,-0x10(%rax)
     f1d:	je     f27 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x27>
     f1f:	movq   $0x0,(%rsi)
     f26:	ret
     f27:	mov    -0x20(%rax),%rcx
     f2b:	cmp    $0x1,%rcx
     f2f:	jne    f38 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x38>
     f31:	cmpq   $0x0,-0x18(%rax)
     f36:	je     f47 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x47>
     f38:	dec    %rcx
     f3b:	mov    %rcx,-0x20(%rax)
     f3f:	movq   $0x0,(%rsi)
     f46:	ret
     f47:	push   %rbp
     f48:	mov    %rsp,%rbp
     f4b:	push   %r14
     f4d:	push   %rbx
     f4e:	mov    %rdi,%rbx
     f51:	mov    %rsi,%r14
     f54:	mov    %rax,%rsi
     f57:	call   f5c <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x5c>
     f5c:	movq   $0x0,(%r14)
     f63:	mov    %rbx,%rdi
     f66:	pop    %rbx
     f67:	pop    %r14
     f69:	pop    %rbp
     f6a:	jmp    f6f <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x6f>
     f6f:	nop

0000000000000f70 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain>:
     f70:	push   %rbp
     f71:	mov    %rsp,%rbp
     f74:	mov    %ecx,%r8d
     f77:	mov    %rdx,%rcx
     f7a:	mov    %rsi,%rdx
     f7d:	mov    (%rcx),%rax
     f80:	test   %rax,%rax
     f83:	je     faa <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x3a>
     f85:	mov    -0x10(%rax),%rsi
     f89:	bt     $0x3e,%rsi
     f8e:	jb     fb4 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x44>
     f90:	test   $0x2,%sil
     f94:	jne    faa <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x3a>
     f96:	mov    -0x20(%rax),%rsi
     f9a:	cmp    $0xffffffffffffffff,%rsi
     f9e:	je     fb4 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x44>
     fa0:	inc    %rsi
     fa3:	mov    %rsi,-0x20(%rax)
     fa7:	mov    (%rcx),%rax
     faa:	mov    %rax,(%rdx)
     fad:	mov    $0x1,%eax
     fb2:	pop    %rbp
     fb3:	ret
     fb4:	mov    0x0(%rip),%rsi        # fbb <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x4b>
     fbb:	pop    %rbp
     fbc:	jmp    fc1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x51>
     fc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000fd0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take>:
     fd0:	push   %rbp
     fd1:	mov    %rsp,%rbp
     fd4:	mov    %ecx,%r8d
     fd7:	mov    %rdx,%rcx
     fda:	mov    %rsi,%rdx
     fdd:	mov    (%rcx),%rax
     fe0:	test   %rax,%rax
     fe3:	je     feb <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x1b>
     fe5:	testb  $0x50,-0x9(%rax)
     fe9:	jne    1012 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x42>
     feb:	mov    %rdx,%rsi
     fee:	sub    %rcx,%rsi
     ff1:	mov    %rcx,%r9
     ff4:	sub    %rdx,%r9
     ff7:	cmovb  %rsi,%r9
     ffb:	cmp    $0x7,%r9
     fff:	jbe    1012 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x42>
    1001:	mov    %rax,(%rdx)
    1004:	movq   $0x0,(%rcx)
    100b:	mov    $0x1,%eax
    1010:	pop    %rbp
    1011:	ret
    1012:	mov    0x0(%rip),%rsi        # 1019 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x49>
    1019:	pop    %rbp
    101a:	jmp    101f <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x4f>
    101f:	nop

0000000000001020 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish>:
    1020:	push   %rbp
    1021:	mov    %rsp,%rbp
    1024:	push   %r15
    1026:	push   %r14
    1028:	push   %r13
    102a:	push   %r12
    102c:	push   %rbx
    102d:	push   %rax
    102e:	mov    %r8d,%r9d
    1031:	mov    %ecx,%r8d
    1034:	mov    %rdx,%rbx
    1037:	mov    %rsi,%r14
    103a:	mov    (%rdx),%r15
    103d:	test   %r15,%r15
    1040:	je     1052 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x32>
    1042:	testb  $0x50,-0x9(%r15)
    1047:	sete   %al
    104a:	test   $0x3,%r9b
    104e:	je     105a <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x3a>
    1050:	jmp    10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    1052:	mov    $0x1,%al
    1054:	test   $0x3,%r9b
    1058:	jne    10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    105a:	test   %al,%al
    105c:	je     10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    105e:	mov    %r14,%rax
    1061:	sub    %rbx,%rax
    1064:	mov    %rbx,%rcx
    1067:	sub    %r14,%rcx
    106a:	cmovb  %rax,%rcx
    106e:	cmp    $0x7,%rcx
    1072:	jbe    10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    1074:	test   $0x4,%r9b
    1078:	jne    10f1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xd1>
    107a:	movabs $0x4000000000000002,%r12
    1084:	test   %r15,%r15
    1087:	je     10ba <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x9a>
    1089:	test   %r12,-0x10(%r15)
    108d:	jne    1096 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x76>
    108f:	cmpq   $0xffffffffffffffff,-0x20(%r15)
    1094:	je     10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    1096:	movabs $0x2000000000000000,%r13
    10a0:	lea    0x2(%r13),%rax
    10a4:	test   %rax,-0x10(%r15)
    10a8:	jne    10ba <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x9a>
    10aa:	mov    %r15,%rdi
    10ad:	call   10b2 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x92>
    10b2:	test   %eax,%eax
    10b4:	je     10ba <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x9a>
    10b6:	or     %r13,-0x10(%r15)
    10ba:	mov    (%rbx),%rax
    10bd:	mov    %rax,(%r14)
    10c0:	test   %rax,%rax
    10c3:	je     1128 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x108>
    10c5:	test   %r12,-0x10(%rax)
    10c9:	jne    1128 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x108>
    10cb:	incq   -0x20(%rax)
    10cf:	jmp    1128 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x108>
    10d1:	mov    0x0(%rip),%rsi        # 10d8 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb8>
    10d8:	mov    %r14,%rdx
    10db:	mov    %rbx,%rcx
    10de:	add    $0x8,%rsp
    10e2:	pop    %rbx
    10e3:	pop    %r12
    10e5:	pop    %r13
    10e7:	pop    %r14
    10e9:	pop    %r15
    10eb:	pop    %rbp
    10ec:	jmp    10f1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xd1>
    10f1:	test   %r15,%r15
    10f4:	je     111b <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xfb>
    10f6:	movabs $0x2000000000000000,%r12
    1100:	lea    0x2(%r12),%rax
    1105:	test   %rax,-0x10(%r15)
    1109:	jne    111b <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xfb>
    110b:	mov    %r15,%rdi
    110e:	call   1113 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xf3>
    1113:	test   %eax,%eax
    1115:	je     111b <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xfb>
    1117:	or     %r12,-0x10(%r15)
    111b:	mov    (%rbx),%rax
    111e:	mov    %rax,(%r14)
    1121:	movq   $0x0,(%rbx)
    1128:	mov    $0x1,%eax
    112d:	add    $0x8,%rsp
    1131:	pop    %rbx
    1132:	pop    %r12
    1134:	pop    %r13
    1136:	pop    %r14
    1138:	pop    %r15
    113a:	pop    %rbp
    113b:	ret
    113c:	nopl   0x0(%rax)

0000000000001140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan>:
    1140:	push   %rbp
    1141:	mov    %rsp,%rbp
    1144:	mov    %rdx,%rcx
    1147:	mov    %rsi,%rdx
    114a:	mov    (%rcx),%rax
    114d:	test   %rax,%rax
    1150:	je     1176 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x36>
    1152:	movabs $0x4000000000000002,%rsi
    115c:	test   %rsi,-0x10(%rax)
    1160:	jne    1176 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x36>
    1162:	mov    -0x18(%rax),%rsi
    1166:	cmp    $0xffffffffffffffff,%rsi
    116a:	je     1180 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x40>
    116c:	inc    %rsi
    116f:	mov    %rsi,-0x18(%rax)
    1173:	mov    (%rcx),%rax
    1176:	mov    %rax,(%rdx)
    1179:	mov    $0x1,%eax
    117e:	pop    %rbp
    117f:	ret
    1180:	mov    0x0(%rip),%rsi        # 1187 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x47>
    1187:	pop    %rbp
    1188:	jmp    118d <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x4d>
    118d:	nopl   (%rax)

0000000000001190 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>:
    1190:	mov    (%rsi),%rax
    1193:	movq   $0x0,(%rsi)
    119a:	test   %rax,%rax
    119d:	je     11af <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x1f>
    119f:	movabs $0x4000000000000002,%rcx
    11a9:	test   %rcx,-0x10(%rax)
    11ad:	je     11b7 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x27>
    11af:	movq   $0x0,(%rsi)
    11b6:	ret
    11b7:	mov    -0x18(%rax),%rcx
    11bb:	cmp    $0x1,%rcx
    11bf:	jne    11c8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x38>
    11c1:	cmpq   $0x0,-0x20(%rax)
    11c6:	je     11d7 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x47>
    11c8:	dec    %rcx
    11cb:	mov    %rcx,-0x18(%rax)
    11cf:	movq   $0x0,(%rsi)
    11d6:	ret
    11d7:	push   %rbp
    11d8:	mov    %rsp,%rbp
    11db:	push   %r14
    11dd:	push   %rbx
    11de:	mov    %rdi,%rbx
    11e1:	mov    %rsi,%r14
    11e4:	mov    %rax,%rsi
    11e7:	call   11ec <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x5c>
    11ec:	movq   $0x0,(%r14)
    11f3:	mov    %rbx,%rdi
    11f6:	pop    %rbx
    11f7:	pop    %r14
    11f9:	pop    %rbp
    11fa:	jmp    11ff <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x6f>
    11ff:	nop

0000000000001200 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>:
    1200:	mov    (%rsi),%rax
    1203:	movq   $0x0,(%rsi)
    120a:	test   %rax,%rax
    120d:	je     121f <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x1f>
    120f:	movabs $0x4000000000000002,%rcx
    1219:	test   %rcx,-0x10(%rax)
    121d:	je     1227 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x27>
    121f:	movq   $0x0,(%rsi)
    1226:	ret
    1227:	mov    -0x20(%rax),%rcx
    122b:	cmp    $0x1,%rcx
    122f:	jne    1238 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x38>
    1231:	cmpq   $0x0,-0x18(%rax)
    1236:	je     1247 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x47>
    1238:	dec    %rcx
    123b:	mov    %rcx,-0x20(%rax)
    123f:	movq   $0x0,(%rsi)
    1246:	ret
    1247:	push   %rbp
    1248:	mov    %rsp,%rbp
    124b:	push   %r14
    124d:	push   %rbx
    124e:	mov    %rdi,%rbx
    1251:	mov    %rsi,%r14
    1254:	mov    %rax,%rsi
    1257:	call   125c <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x5c>
    125c:	movq   $0x0,(%r14)
    1263:	mov    %rbx,%rdi
    1266:	pop    %rbx
    1267:	pop    %r14
    1269:	pop    %rbp
    126a:	jmp    126f <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x6f>
    126f:	nop

0000000000001270 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain>:
    1270:	push   %rbp
    1271:	mov    %rsp,%rbp
    1274:	mov    %ecx,%r8d
    1277:	mov    %rdx,%rcx
    127a:	mov    %rsi,%rdx
    127d:	mov    (%rcx),%rax
    1280:	test   %rax,%rax
    1283:	je     12aa <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x3a>
    1285:	mov    -0x10(%rax),%rsi
    1289:	bt     $0x3e,%rsi
    128e:	jb     12b4 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x44>
    1290:	test   $0x2,%sil
    1294:	jne    12aa <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x3a>
    1296:	mov    -0x20(%rax),%rsi
    129a:	cmp    $0xffffffffffffffff,%rsi
    129e:	je     12b4 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x44>
    12a0:	inc    %rsi
    12a3:	mov    %rsi,-0x20(%rax)
    12a7:	mov    (%rcx),%rax
    12aa:	mov    %rax,(%rdx)
    12ad:	mov    $0x1,%eax
    12b2:	pop    %rbp
    12b3:	ret
    12b4:	mov    0x0(%rip),%rsi        # 12bb <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x4b>
    12bb:	pop    %rbp
    12bc:	jmp    12c1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x51>
    12c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

00000000000012d0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take>:
    12d0:	push   %rbp
    12d1:	mov    %rsp,%rbp
    12d4:	mov    %ecx,%r8d
    12d7:	mov    %rdx,%rcx
    12da:	mov    %rsi,%rdx
    12dd:	mov    (%rcx),%rax
    12e0:	test   %rax,%rax
    12e3:	je     12eb <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x1b>
    12e5:	testb  $0x50,-0x9(%rax)
    12e9:	jne    1312 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x42>
    12eb:	mov    %rdx,%rsi
    12ee:	sub    %rcx,%rsi
    12f1:	mov    %rcx,%r9
    12f4:	sub    %rdx,%r9
    12f7:	cmovb  %rsi,%r9
    12fb:	cmp    $0x7,%r9
    12ff:	jbe    1312 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x42>
    1301:	mov    %rax,(%rdx)
    1304:	movq   $0x0,(%rcx)
    130b:	mov    $0x1,%eax
    1310:	pop    %rbp
    1311:	ret
    1312:	mov    0x0(%rip),%rsi        # 1319 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x49>
    1319:	pop    %rbp
    131a:	jmp    131f <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x4f>
    131f:	nop

0000000000001320 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish>:
    1320:	push   %rbp
    1321:	mov    %rsp,%rbp
    1324:	push   %r15
    1326:	push   %r14
    1328:	push   %r13
    132a:	push   %r12
    132c:	push   %rbx
    132d:	push   %rax
    132e:	mov    %r8d,%r9d
    1331:	mov    %ecx,%r8d
    1334:	mov    %rdx,%rbx
    1337:	mov    %rsi,%r14
    133a:	mov    (%rdx),%r15
    133d:	test   %r15,%r15
    1340:	je     1352 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x32>
    1342:	testb  $0x50,-0x9(%r15)
    1347:	sete   %al
    134a:	test   $0x3,%r9b
    134e:	je     135a <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x3a>
    1350:	jmp    13d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    1352:	mov    $0x1,%al
    1354:	test   $0x3,%r9b
    1358:	jne    13d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    135a:	test   %al,%al
    135c:	je     13d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    135e:	mov    %r14,%rax
    1361:	sub    %rbx,%rax
    1364:	mov    %rbx,%rcx
    1367:	sub    %r14,%rcx
    136a:	cmovb  %rax,%rcx
    136e:	cmp    $0x7,%rcx
    1372:	jbe    13d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    1374:	test   $0x4,%r9b
    1378:	jne    13f1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xd1>
    137a:	movabs $0x4000000000000002,%r12
    1384:	test   %r15,%r15
    1387:	je     13ba <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x9a>
    1389:	test   %r12,-0x10(%r15)
    138d:	jne    1396 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x76>
    138f:	cmpq   $0xffffffffffffffff,-0x20(%r15)
    1394:	je     13d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    1396:	movabs $0x2000000000000000,%r13
    13a0:	lea    0x2(%r13),%rax
    13a4:	test   %rax,-0x10(%r15)
    13a8:	jne    13ba <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x9a>
    13aa:	mov    %r15,%rdi
    13ad:	call   13b2 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x92>
    13b2:	test   %eax,%eax
    13b4:	je     13ba <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x9a>
    13b6:	or     %r13,-0x10(%r15)
    13ba:	mov    (%rbx),%rax
    13bd:	mov    %rax,(%r14)
    13c0:	test   %rax,%rax
    13c3:	je     1428 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x108>
    13c5:	test   %r12,-0x10(%rax)
    13c9:	jne    1428 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x108>
    13cb:	incq   -0x20(%rax)
    13cf:	jmp    1428 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x108>
    13d1:	mov    0x0(%rip),%rsi        # 13d8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb8>
    13d8:	mov    %r14,%rdx
    13db:	mov    %rbx,%rcx
    13de:	add    $0x8,%rsp
    13e2:	pop    %rbx
    13e3:	pop    %r12
    13e5:	pop    %r13
    13e7:	pop    %r14
    13e9:	pop    %r15
    13eb:	pop    %rbp
    13ec:	jmp    13f1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xd1>
    13f1:	test   %r15,%r15
    13f4:	je     141b <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xfb>
    13f6:	movabs $0x2000000000000000,%r12
    1400:	lea    0x2(%r12),%rax
    1405:	test   %rax,-0x10(%r15)
    1409:	jne    141b <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xfb>
    140b:	mov    %r15,%rdi
    140e:	call   1413 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xf3>
    1413:	test   %eax,%eax
    1415:	je     141b <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xfb>
    1417:	or     %r12,-0x10(%r15)
    141b:	mov    (%rbx),%rax
    141e:	mov    %rax,(%r14)
    1421:	movq   $0x0,(%rbx)
    1428:	mov    $0x1,%eax
    142d:	add    $0x8,%rsp
    1431:	pop    %rbx
    1432:	pop    %r12
    1434:	pop    %r13
    1436:	pop    %r14
    1438:	pop    %r15
    143a:	pop    %rbp
    143b:	ret
    143c:	nopl   0x0(%rax)

0000000000001440 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set>:
    1440:	xor    %eax,%eax
    1442:	cmp    (%rsi),%rdx
    1445:	jae    14f8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xb8>
    144b:	shl    $0x3,%rdx
    144f:	add    0x20(%rsi),%rdx
    1453:	cmp    %rcx,%rdx
    1456:	je     14f9 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xb9>
    145c:	push   %rbp
    145d:	mov    %rsp,%rbp
    1460:	push   %r15
    1462:	push   %r14
    1464:	push   %rbx
    1465:	push   %rax
    1466:	movabs $0x4000000000000000,%rbx
    1470:	mov    -0x10(%rsi),%rax
    1474:	mov    %rax,%rsi
    1477:	shr    $0x28,%rsi
    147b:	and    $0xfffff,%esi
    1481:	xor    %r8d,%r8d
    1484:	bt     $0x3e,%rax
    1489:	cmovb  %esi,%r8d
    148d:	mov    (%rcx),%rax
    1490:	test   %rax,%rax
    1493:	je     14b8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0x78>
    1495:	mov    -0x10(%rax),%rsi
    1499:	test   %rbx,%rsi
    149c:	jne    1516 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xd6>
    149e:	test   $0x2,%sil
    14a2:	jne    14b8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0x78>
    14a4:	mov    -0x20(%rax),%rsi
    14a8:	cmp    $0xffffffffffffffff,%rsi
    14ac:	je     1516 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xd6>
    14ae:	inc    %rsi
    14b1:	mov    %rsi,-0x20(%rax)
    14b5:	mov    (%rcx),%rax
    14b8:	mov    %rax,-0x20(%rbp)
    14bc:	mov    (%rdx),%rsi
    14bf:	mov    %rax,(%rdx)
    14c2:	mov    $0x1,%eax
    14c7:	test   %rsi,%rsi
    14ca:	je     14ee <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xae>
    14cc:	add    $0x2,%rbx
    14d0:	test   %rbx,-0x10(%rsi)
    14d4:	jne    14ee <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xae>
    14d6:	mov    -0x20(%rsi),%rcx
    14da:	cmp    $0x1,%rcx
    14de:	jne    14e7 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xa7>
    14e0:	cmpq   $0x0,-0x18(%rsi)
    14e5:	je     14ff <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xbf>
    14e7:	dec    %rcx
    14ea:	mov    %rcx,-0x20(%rsi)
    14ee:	add    $0x8,%rsp
    14f2:	pop    %rbx
    14f3:	pop    %r14
    14f5:	pop    %r15
    14f7:	pop    %rbp
    14f8:	ret
    14f9:	mov    $0x1,%eax
    14fe:	ret
    14ff:	mov    %rdi,%rbx
    1502:	call   1507 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xc7>
    1507:	mov    %rbx,%rdi
    150a:	call   150f <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xcf>
    150f:	mov    $0x1,%eax
    1514:	jmp    14ee <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xae>
    1516:	mov    %rdx,%r14
    1519:	mov    0x0(%rip),%rsi        # 1520 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xe0>
    1520:	lea    -0x20(%rbp),%rdx
    1524:	mov    %rdi,%r15
    1527:	call   152c <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xec>
    152c:	test   %eax,%eax
    152e:	je     153c <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xfc>
    1530:	mov    -0x20(%rbp),%rax
    1534:	mov    %r15,%rdi
    1537:	mov    %r14,%rdx
    153a:	jmp    14bc <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0x7c>
    153c:	xor    %eax,%eax
    153e:	jmp    14ee <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xae>

0000000000001540 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append>:
    1540:	push   %rbp
    1541:	mov    %rsp,%rbp
    1544:	push   %r14
    1546:	push   %rbx
    1547:	mov    %rdx,%rcx
    154a:	mov    (%rsi),%rbx
    154d:	cmp    0x8(%rsi),%rbx
    1551:	jae    1571 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x31>
    1553:	cmpq   $0xffffffffffffffff,0x10(%rsi)
    1558:	je     1571 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x31>
    155a:	mov    0x20(%rsi),%rdx
    155e:	mov    %rcx,%r8
    1561:	sub    %rdx,%r8
    1564:	lea    0x0(,%rbx,8),%rax
    156c:	cmp    %rax,%r8
    156f:	jae    157d <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x3d>
    1571:	mov    %rcx,%rdx
    1574:	pop    %rbx
    1575:	pop    %r14
    1577:	pop    %rbp
    1578:	jmp    157d <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x3d>
    157d:	add    %rax,%rdx
    1580:	mov    -0x10(%rsi),%rax
    1584:	mov    %rax,%r9
    1587:	shr    $0x28,%r9
    158b:	and    $0xfffff,%r9d
    1592:	xor    %r8d,%r8d
    1595:	bt     $0x3e,%rax
    159a:	cmovb  %r9d,%r8d
    159e:	mov    (%rcx),%rax
    15a1:	test   %rax,%rax
    15a4:	je     15d3 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x93>
    15a6:	movabs $0x4000000000000000,%r10
    15b0:	mov    -0x10(%rax),%r9
    15b4:	test   %r10,%r9
    15b7:	jne    15ea <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xaa>
    15b9:	test   $0x2,%r9b
    15bd:	jne    15d3 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x93>
    15bf:	mov    -0x20(%rax),%r9
    15c3:	cmp    $0xffffffffffffffff,%r9
    15c7:	je     15ea <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xaa>
    15c9:	inc    %r9
    15cc:	mov    %r9,-0x20(%rax)
    15d0:	mov    (%rcx),%rax
    15d3:	mov    %rax,(%rdx)
    15d6:	inc    %rbx
    15d9:	mov    %rbx,(%rsi)
    15dc:	incq   0x10(%rsi)
    15e0:	mov    $0x1,%eax
    15e5:	pop    %rbx
    15e6:	pop    %r14
    15e8:	pop    %rbp
    15e9:	ret
    15ea:	mov    0x0(%rip),%rax        # 15f1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xb1>
    15f1:	mov    %rsi,%r14
    15f4:	mov    %rax,%rsi
    15f7:	call   15fc <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xbc>
    15fc:	mov    %r14,%rsi
    15ff:	test   %eax,%eax
    1601:	jne    15d6 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x96>
    1603:	xor    %eax,%eax
    1605:	jmp    15e5 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xa5>
    1607:	nopw   0x0(%rax,%rax,1)

0000000000001610 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan>:
    1610:	push   %rbp
    1611:	mov    %rsp,%rbp
    1614:	mov    %rdx,%rcx
    1617:	mov    %rsi,%rdx
    161a:	mov    (%rcx),%eax
    161c:	cmp    $0x1,%eax
    161f:	je     1625 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x15>
    1621:	test   %eax,%eax
    1623:	jne    165c <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x4c>
    1625:	mov    0x8(%rcx),%rax
    1629:	test   %rax,%rax
    162c:	je     165c <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x4c>
    162e:	movabs $0x4000000000000002,%rsi
    1638:	test   %rsi,-0x10(%rax)
    163c:	jne    165c <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x4c>
    163e:	mov    -0x18(%rax),%rsi
    1642:	cmp    $0xfffffffffffffffd,%rsi
    1646:	jbe    1655 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x45>
    1648:	mov    0x0(%rip),%rsi        # 164f <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x3f>
    164f:	pop    %rbp
    1650:	jmp    1655 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x45>
    1655:	inc    %rsi
    1658:	mov    %rsi,-0x18(%rax)
    165c:	vmovups (%rcx),%xmm0
    1660:	vmovups %xmm0,(%rdx)
    1664:	mov    $0x1,%eax
    1669:	pop    %rbp
    166a:	ret
    166b:	nopl   0x0(%rax,%rax,1)

0000000000001670 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan>:
    1670:	push   %rbp
    1671:	mov    %rsp,%rbp
    1674:	push   %r14
    1676:	push   %rbx
    1677:	mov    (%rsi),%eax
    1679:	cmp    $0x1,%eax
    167c:	je     1682 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x12>
    167e:	test   %eax,%eax
    1680:	jne    16bb <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x4b>
    1682:	mov    0x8(%rsi),%rax
    1686:	movq   $0x0,0x8(%rsi)
    168e:	test   %rax,%rax
    1691:	je     16bb <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x4b>
    1693:	movabs $0x4000000000000002,%rcx
    169d:	test   %rcx,-0x10(%rax)
    16a1:	jne    16bb <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x4b>
    16a3:	mov    -0x18(%rax),%rcx
    16a7:	cmp    $0x1,%rcx
    16ab:	jne    16b4 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x44>
    16ad:	cmpq   $0x0,-0x20(%rax)
    16b2:	je     16c8 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x58>
    16b4:	dec    %rcx
    16b7:	mov    %rcx,-0x18(%rax)
    16bb:	vxorps %xmm0,%xmm0,%xmm0
    16bf:	vmovups %xmm0,(%rsi)
    16c3:	pop    %rbx
    16c4:	pop    %r14
    16c6:	pop    %rbp
    16c7:	ret
    16c8:	mov    %rsi,%r14
    16cb:	mov    %rdi,%rbx
    16ce:	mov    %rax,%rsi
    16d1:	call   16d6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x66>
    16d6:	vxorps %xmm0,%xmm0,%xmm0
    16da:	vmovups %xmm0,(%r14)
    16df:	mov    %rbx,%rdi
    16e2:	pop    %rbx
    16e3:	pop    %r14
    16e5:	pop    %rbp
    16e6:	jmp    16eb <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x7b>
    16eb:	nopl   0x0(%rax,%rax,1)

00000000000016f0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop>:
    16f0:	push   %rbp
    16f1:	mov    %rsp,%rbp
    16f4:	push   %r14
    16f6:	push   %rbx
    16f7:	mov    (%rsi),%eax
    16f9:	cmp    $0x1,%eax
    16fc:	je     1702 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x12>
    16fe:	test   %eax,%eax
    1700:	jne    173b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x4b>
    1702:	mov    0x8(%rsi),%rax
    1706:	movq   $0x0,0x8(%rsi)
    170e:	test   %rax,%rax
    1711:	je     173b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x4b>
    1713:	movabs $0x4000000000000002,%rcx
    171d:	test   %rcx,-0x10(%rax)
    1721:	jne    173b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x4b>
    1723:	mov    -0x20(%rax),%rcx
    1727:	cmp    $0x1,%rcx
    172b:	jne    1734 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x44>
    172d:	cmpq   $0x0,-0x18(%rax)
    1732:	je     1748 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x58>
    1734:	dec    %rcx
    1737:	mov    %rcx,-0x20(%rax)
    173b:	vxorps %xmm0,%xmm0,%xmm0
    173f:	vmovups %xmm0,(%rsi)
    1743:	pop    %rbx
    1744:	pop    %r14
    1746:	pop    %rbp
    1747:	ret
    1748:	mov    %rsi,%r14
    174b:	mov    %rdi,%rbx
    174e:	mov    %rax,%rsi
    1751:	call   1756 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x66>
    1756:	vxorps %xmm0,%xmm0,%xmm0
    175a:	vmovups %xmm0,(%r14)
    175f:	mov    %rbx,%rdi
    1762:	pop    %rbx
    1763:	pop    %r14
    1765:	pop    %rbp
    1766:	jmp    176b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x7b>
    176b:	nopl   0x0(%rax,%rax,1)

0000000000001770 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain>:
    1770:	push   %rbp
    1771:	mov    %rsp,%rbp
    1774:	mov    %ecx,%r8d
    1777:	mov    %rdx,%rcx
    177a:	mov    %rsi,%rdx
    177d:	mov    (%rcx),%eax
    177f:	cmp    $0x1,%eax
    1782:	je     1788 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x18>
    1784:	test   %eax,%eax
    1786:	jne    17c0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x50>
    1788:	mov    0x8(%rcx),%rax
    178c:	test   %rax,%rax
    178f:	je     17c0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x50>
    1791:	mov    -0x10(%rax),%rsi
    1795:	bt     $0x3e,%rsi
    179a:	jb     17ac <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x3c>
    179c:	test   $0x2,%sil
    17a0:	jne    17c0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x50>
    17a2:	mov    -0x20(%rax),%rsi
    17a6:	cmp    $0xfffffffffffffffd,%rsi
    17aa:	jbe    17b9 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x49>
    17ac:	mov    0x0(%rip),%rsi        # 17b3 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x43>
    17b3:	pop    %rbp
    17b4:	jmp    17b9 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x49>
    17b9:	inc    %rsi
    17bc:	mov    %rsi,-0x20(%rax)
    17c0:	vmovups (%rcx),%xmm0
    17c4:	vmovups %xmm0,(%rdx)
    17c8:	mov    $0x1,%eax
    17cd:	pop    %rbp
    17ce:	ret
    17cf:	nop

00000000000017d0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take>:
    17d0:	push   %rbp
    17d1:	mov    %rsp,%rbp
    17d4:	mov    %ecx,%r8d
    17d7:	mov    %rdx,%rcx
    17da:	mov    %rsi,%rdx
    17dd:	mov    (%rcx),%eax
    17df:	cmp    $0x1,%eax
    17e2:	je     17e8 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x18>
    17e4:	test   %eax,%eax
    17e6:	jne    17f7 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x27>
    17e8:	mov    0x8(%rcx),%rax
    17ec:	test   %rax,%rax
    17ef:	je     17f7 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x27>
    17f1:	testb  $0x50,-0x9(%rax)
    17f5:	jne    1824 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x54>
    17f7:	mov    %rdx,%rax
    17fa:	sub    %rcx,%rax
    17fd:	mov    %rcx,%rsi
    1800:	sub    %rdx,%rsi
    1803:	cmovb  %rax,%rsi
    1807:	cmp    $0xf,%rsi
    180b:	jbe    1824 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x54>
    180d:	vmovups (%rcx),%xmm0
    1811:	vmovups %xmm0,(%rdx)
    1815:	vxorps %xmm0,%xmm0,%xmm0
    1819:	vmovups %xmm0,(%rcx)
    181d:	mov    $0x1,%eax
    1822:	pop    %rbp
    1823:	ret
    1824:	mov    0x0(%rip),%rsi        # 182b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x5b>
    182b:	pop    %rbp
    182c:	jmp    1831 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x61>
    1831:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000001840 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish>:
    1840:	push   %rbp
    1841:	mov    %rsp,%rbp
    1844:	push   %r15
    1846:	push   %r14
    1848:	push   %r13
    184a:	push   %r12
    184c:	push   %rbx
    184d:	push   %rax
    184e:	mov    %r8d,%r14d
    1851:	mov    %ecx,%r8d
    1854:	mov    %rdx,%r15
    1857:	mov    %rsi,%rbx
    185a:	mov    (%rdx),%eax
    185c:	mov    $0x1,%cl
    185e:	cmp    $0x1,%eax
    1861:	je     1867 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x27>
    1863:	test   %eax,%eax
    1865:	jne    1877 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x37>
    1867:	mov    0x8(%r15),%rdx
    186b:	test   %rdx,%rdx
    186e:	je     1877 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x37>
    1870:	testb  $0x50,-0x9(%rdx)
    1874:	sete   %cl
    1877:	test   $0x3,%r14b
    187b:	jne    18c6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x86>
    187d:	test   %cl,%cl
    187f:	je     18c6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x86>
    1881:	mov    %rbx,%rcx
    1884:	sub    %r15,%rcx
    1887:	mov    %r15,%rdx
    188a:	sub    %rbx,%rdx
    188d:	cmovb  %rcx,%rdx
    1891:	cmp    $0xf,%rdx
    1895:	jbe    18c6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x86>
    1897:	test   $0x4,%r14b
    189b:	jne    18e9 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xa9>
    189d:	cmp    $0x1,%eax
    18a0:	je     18a6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x66>
    18a2:	test   %eax,%eax
    18a4:	jne    1921 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    18a6:	mov    0x8(%r15),%rcx
    18aa:	test   %rcx,%rcx
    18ad:	je     18f2 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xb2>
    18af:	movabs $0x4000000000000002,%rdx
    18b9:	test   %rdx,-0x10(%rcx)
    18bd:	jne    18f2 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xb2>
    18bf:	cmpq   $0xfffffffffffffffe,-0x20(%rcx)
    18c4:	jb     18e9 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xa9>
    18c6:	mov    0x0(%rip),%rsi        # 18cd <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x8d>
    18cd:	mov    %rbx,%rdx
    18d0:	mov    %r15,%rcx
    18d3:	mov    %r14d,%r9d
    18d6:	add    $0x8,%rsp
    18da:	pop    %rbx
    18db:	pop    %r12
    18dd:	pop    %r13
    18df:	pop    %r14
    18e1:	pop    %r15
    18e3:	pop    %rbp
    18e4:	jmp    18e9 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xa9>
    18e9:	cmp    $0x1,%eax
    18ec:	je     18f2 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xb2>
    18ee:	test   %eax,%eax
    18f0:	jne    1921 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    18f2:	mov    0x8(%r15),%r12
    18f6:	test   %r12,%r12
    18f9:	je     1921 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    18fb:	movabs $0x2000000000000000,%r13
    1905:	lea    0x2(%r13),%rax
    1909:	test   %rax,-0x10(%r12)
    190e:	jne    1921 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    1910:	mov    %r12,%rdi
    1913:	call   1918 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xd8>
    1918:	test   %eax,%eax
    191a:	je     1921 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    191c:	or     %r13,-0x10(%r12)
    1921:	vmovups (%r15),%xmm0
    1926:	vmovups %xmm0,(%rbx)
    192a:	test   $0x4,%r14b
    192e:	jne    195a <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x11a>
    1930:	mov    (%rbx),%eax
    1932:	cmp    $0x1,%eax
    1935:	je     193b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xfb>
    1937:	test   %eax,%eax
    1939:	jne    1963 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x123>
    193b:	mov    0x8(%rbx),%rax
    193f:	test   %rax,%rax
    1942:	je     1963 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x123>
    1944:	movabs $0x4000000000000002,%rcx
    194e:	test   %rcx,-0x10(%rax)
    1952:	jne    1963 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x123>
    1954:	incq   -0x20(%rax)
    1958:	jmp    1963 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x123>
    195a:	vxorps %xmm0,%xmm0,%xmm0
    195e:	vmovups %xmm0,(%r15)
    1963:	mov    $0x1,%eax
    1968:	add    $0x8,%rsp
    196c:	pop    %rbx
    196d:	pop    %r12
    196f:	pop    %r13
    1971:	pop    %r14
    1973:	pop    %r15
    1975:	pop    %rbp
    1976:	ret
    1977:	nopw   0x0(%rax,%rax,1)

0000000000001980 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan>:
    1980:	push   %rbp
    1981:	mov    %rsp,%rbp
    1984:	mov    %rdx,%rcx
    1987:	mov    %rsi,%rdx
    198a:	cmpl   $0x1,(%rcx)
    198d:	jne    19c6 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x46>
    198f:	mov    0x8(%rcx),%rax
    1993:	test   %rax,%rax
    1996:	je     19c6 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x46>
    1998:	movabs $0x4000000000000002,%rsi
    19a2:	test   %rsi,-0x10(%rax)
    19a6:	jne    19c6 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x46>
    19a8:	mov    -0x18(%rax),%rsi
    19ac:	cmp    $0xfffffffffffffffd,%rsi
    19b0:	jbe    19bf <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x3f>
    19b2:	mov    0x0(%rip),%rsi        # 19b9 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x39>
    19b9:	pop    %rbp
    19ba:	jmp    19bf <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x3f>
    19bf:	inc    %rsi
    19c2:	mov    %rsi,-0x18(%rax)
    19c6:	vmovups (%rcx),%xmm0
    19ca:	vmovups %xmm0,(%rdx)
    19ce:	mov    $0x1,%eax
    19d3:	pop    %rbp
    19d4:	ret
    19d5:	data16 cs nopw 0x0(%rax,%rax,1)

00000000000019e0 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan>:
    19e0:	cmpl   $0x1,(%rsi)
    19e3:	jne    1a1e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x3e>
    19e5:	mov    0x8(%rsi),%rax
    19e9:	movq   $0x0,0x8(%rsi)
    19f1:	test   %rax,%rax
    19f4:	je     1a1e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x3e>
    19f6:	movabs $0x4000000000000002,%rcx
    1a00:	test   %rcx,-0x10(%rax)
    1a04:	jne    1a1e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x3e>
    1a06:	mov    -0x18(%rax),%rcx
    1a0a:	cmp    $0x1,%rcx
    1a0e:	jne    1a17 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x37>
    1a10:	cmpq   $0x0,-0x20(%rax)
    1a15:	je     1a27 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x47>
    1a17:	dec    %rcx
    1a1a:	mov    %rcx,-0x18(%rax)
    1a1e:	vxorps %xmm0,%xmm0,%xmm0
    1a22:	vmovups %xmm0,(%rsi)
    1a26:	ret
    1a27:	push   %rbp
    1a28:	mov    %rsp,%rbp
    1a2b:	push   %r14
    1a2d:	push   %rbx
    1a2e:	mov    %rdi,%rbx
    1a31:	mov    %rsi,%r14
    1a34:	mov    %rax,%rsi
    1a37:	call   1a3c <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x5c>
    1a3c:	vxorps %xmm0,%xmm0,%xmm0
    1a40:	vmovups %xmm0,(%r14)
    1a45:	mov    %rbx,%rdi
    1a48:	pop    %rbx
    1a49:	pop    %r14
    1a4b:	pop    %rbp
    1a4c:	jmp    1a51 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x71>
    1a51:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000001a60 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop>:
    1a60:	cmpl   $0x1,(%rsi)
    1a63:	jne    1a9e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x3e>
    1a65:	mov    0x8(%rsi),%rax
    1a69:	movq   $0x0,0x8(%rsi)
    1a71:	test   %rax,%rax
    1a74:	je     1a9e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x3e>
    1a76:	movabs $0x4000000000000002,%rcx
    1a80:	test   %rcx,-0x10(%rax)
    1a84:	jne    1a9e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x3e>
    1a86:	mov    -0x20(%rax),%rcx
    1a8a:	cmp    $0x1,%rcx
    1a8e:	jne    1a97 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x37>
    1a90:	cmpq   $0x0,-0x18(%rax)
    1a95:	je     1aa7 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x47>
    1a97:	dec    %rcx
    1a9a:	mov    %rcx,-0x20(%rax)
    1a9e:	vxorps %xmm0,%xmm0,%xmm0
    1aa2:	vmovups %xmm0,(%rsi)
    1aa6:	ret
    1aa7:	push   %rbp
    1aa8:	mov    %rsp,%rbp
    1aab:	push   %r14
    1aad:	push   %rbx
    1aae:	mov    %rdi,%rbx
    1ab1:	mov    %rsi,%r14
    1ab4:	mov    %rax,%rsi
    1ab7:	call   1abc <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x5c>
    1abc:	vxorps %xmm0,%xmm0,%xmm0
    1ac0:	vmovups %xmm0,(%r14)
    1ac5:	mov    %rbx,%rdi
    1ac8:	pop    %rbx
    1ac9:	pop    %r14
    1acb:	pop    %rbp
    1acc:	jmp    1ad1 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x71>
    1ad1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000001ae0 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain>:
    1ae0:	push   %rbp
    1ae1:	mov    %rsp,%rbp
    1ae4:	mov    %ecx,%r8d
    1ae7:	mov    %rdx,%rcx
    1aea:	mov    %rsi,%rdx
    1aed:	cmpl   $0x1,(%rcx)
    1af0:	jne    1b2a <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x4a>
    1af2:	mov    0x8(%rcx),%rax
    1af6:	test   %rax,%rax
    1af9:	je     1b2a <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x4a>
    1afb:	mov    -0x10(%rax),%rsi
    1aff:	bt     $0x3e,%rsi
    1b04:	jb     1b16 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x36>
    1b06:	test   $0x2,%sil
    1b0a:	jne    1b2a <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x4a>
    1b0c:	mov    -0x20(%rax),%rsi
    1b10:	cmp    $0xfffffffffffffffd,%rsi
    1b14:	jbe    1b23 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x43>
    1b16:	mov    0x0(%rip),%rsi        # 1b1d <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x3d>
    1b1d:	pop    %rbp
    1b1e:	jmp    1b23 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x43>
    1b23:	inc    %rsi
    1b26:	mov    %rsi,-0x20(%rax)
    1b2a:	vmovups (%rcx),%xmm0
    1b2e:	vmovups %xmm0,(%rdx)
    1b32:	mov    $0x1,%eax
    1b37:	pop    %rbp
    1b38:	ret
    1b39:	nopl   0x0(%rax)

0000000000001b40 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take>:
    1b40:	push   %rbp
    1b41:	mov    %rsp,%rbp
    1b44:	mov    %ecx,%r8d
    1b47:	mov    %rdx,%rcx
    1b4a:	mov    %rsi,%rdx
    1b4d:	cmpl   $0x1,(%rcx)
    1b50:	jne    1b61 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x21>
    1b52:	mov    0x8(%rcx),%rax
    1b56:	test   %rax,%rax
    1b59:	je     1b61 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x21>
    1b5b:	testb  $0x50,-0x9(%rax)
    1b5f:	jne    1b8e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x4e>
    1b61:	mov    %rdx,%rax
    1b64:	sub    %rcx,%rax
    1b67:	mov    %rcx,%rsi
    1b6a:	sub    %rdx,%rsi
    1b6d:	cmovb  %rax,%rsi
    1b71:	cmp    $0xf,%rsi
    1b75:	jbe    1b8e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x4e>
    1b77:	vmovups (%rcx),%xmm0
    1b7b:	vmovups %xmm0,(%rdx)
    1b7f:	vxorps %xmm0,%xmm0,%xmm0
    1b83:	vmovups %xmm0,(%rcx)
    1b87:	mov    $0x1,%eax
    1b8c:	pop    %rbp
    1b8d:	ret
    1b8e:	mov    0x0(%rip),%rsi        # 1b95 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x55>
    1b95:	pop    %rbp
    1b96:	jmp    1b9b <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x5b>
    1b9b:	nopl   0x0(%rax,%rax,1)

0000000000001ba0 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish>:
    1ba0:	push   %rbp
    1ba1:	mov    %rsp,%rbp
    1ba4:	push   %r15
    1ba6:	push   %r14
    1ba8:	push   %r13
    1baa:	push   %r12
    1bac:	push   %rbx
    1bad:	push   %rax
    1bae:	mov    %r8d,%ebx
    1bb1:	mov    %ecx,%r8d
    1bb4:	mov    %rdx,%r15
    1bb7:	mov    %rsi,%r14
    1bba:	mov    (%rdx),%eax
    1bbc:	cmp    $0x1,%eax
    1bbf:	jne    1bd8 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x38>
    1bc1:	mov    0x8(%r15),%rcx
    1bc5:	test   %rcx,%rcx
    1bc8:	je     1bd8 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x38>
    1bca:	testb  $0x50,-0x9(%rcx)
    1bce:	setne  %cl
    1bd1:	test   $0x3,%bl
    1bd4:	je     1bdf <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x3f>
    1bd6:	jmp    1c2e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x8e>
    1bd8:	xor    %ecx,%ecx
    1bda:	test   $0x3,%bl
    1bdd:	jne    1c2e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x8e>
    1bdf:	test   %cl,%cl
    1be1:	jne    1c2e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x8e>
    1be3:	mov    %r14,%rcx
    1be6:	sub    %r15,%rcx
    1be9:	mov    %r15,%rdx
    1bec:	sub    %r14,%rdx
    1bef:	cmovb  %rcx,%rdx
    1bf3:	cmp    $0xf,%rdx
    1bf7:	jbe    1c2e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x8e>
    1bf9:	mov    %eax,%ecx
    1bfb:	xor    $0x1,%ecx
    1bfe:	mov    %ebx,%edx
    1c00:	and    $0x4,%edx
    1c03:	or     %ecx,%edx
    1c05:	je     1c0e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x6e>
    1c07:	cmp    $0x1,%eax
    1c0a:	je     1c51 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1c0c:	jmp    1c80 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xe0>
    1c0e:	mov    0x8(%r15),%rax
    1c12:	test   %rax,%rax
    1c15:	je     1c51 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1c17:	movabs $0x4000000000000002,%rcx
    1c21:	test   %rcx,-0x10(%rax)
    1c25:	jne    1c51 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1c27:	cmpq   $0xfffffffffffffffe,-0x20(%rax)
    1c2c:	jb     1c51 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1c2e:	mov    0x0(%rip),%rsi        # 1c35 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x95>
    1c35:	mov    %r14,%rdx
    1c38:	mov    %r15,%rcx
    1c3b:	mov    %ebx,%r9d
    1c3e:	add    $0x8,%rsp
    1c42:	pop    %rbx
    1c43:	pop    %r12
    1c45:	pop    %r13
    1c47:	pop    %r14
    1c49:	pop    %r15
    1c4b:	pop    %rbp
    1c4c:	jmp    1c51 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1c51:	mov    0x8(%r15),%r12
    1c55:	test   %r12,%r12
    1c58:	je     1c80 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xe0>
    1c5a:	movabs $0x2000000000000000,%r13
    1c64:	lea    0x2(%r13),%rax
    1c68:	test   %rax,-0x10(%r12)
    1c6d:	jne    1c80 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xe0>
    1c6f:	mov    %r12,%rdi
    1c72:	call   1c77 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xd7>
    1c77:	test   %eax,%eax
    1c79:	je     1c80 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xe0>
    1c7b:	or     %r13,-0x10(%r12)
    1c80:	vmovups (%r15),%xmm0
    1c85:	vmovups %xmm0,(%r14)
    1c8a:	test   $0x4,%bl
    1c8d:	je     1c9a <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xfa>
    1c8f:	vxorps %xmm0,%xmm0,%xmm0
    1c93:	vmovups %xmm0,(%r15)
    1c98:	jmp    1cbd <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x11d>
    1c9a:	cmpl   $0x1,(%r14)
    1c9e:	jne    1cbd <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x11d>
    1ca0:	mov    0x8(%r14),%rax
    1ca4:	test   %rax,%rax
    1ca7:	je     1cbd <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x11d>
    1ca9:	movabs $0x4000000000000002,%rcx
    1cb3:	test   %rcx,-0x10(%rax)
    1cb7:	jne    1cbd <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x11d>
    1cb9:	incq   -0x20(%rax)
    1cbd:	mov    $0x1,%eax
    1cc2:	add    $0x8,%rsp
    1cc6:	pop    %rbx
    1cc7:	pop    %r12
    1cc9:	pop    %r13
    1ccb:	pop    %r14
    1ccd:	pop    %r15
    1ccf:	pop    %rbp
    1cd0:	ret
    1cd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000001ce0 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan>:
    1ce0:	push   %rbp
    1ce1:	mov    %rsp,%rbp
    1ce4:	mov    %rdx,%rcx
    1ce7:	mov    %rsi,%rdx
    1cea:	mov    (%rcx),%esi
    1cec:	cmp    $0x1,%esi
    1cef:	je     1d26 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x46>
    1cf1:	test   %esi,%esi
    1cf3:	jne    1db7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1cf9:	mov    0x8(%rcx),%rax
    1cfd:	test   %rax,%rax
    1d00:	je     1db7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1d06:	movabs $0x4000000000000002,%r8
    1d10:	test   %r8,-0x10(%rax)
    1d14:	jne    1da3 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xc3>
    1d1a:	mov    %eax,%r8d
    1d1d:	cmpq   $0xfffffffffffffffd,-0x18(%rax)
    1d22:	jae    1d58 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x78>
    1d24:	jmp    1d8b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xab>
    1d26:	mov    0x8(%rcx),%r8d
    1d2a:	cmp    $0x1,%r8d
    1d2e:	je     1d65 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x85>
    1d30:	test   %r8d,%r8d
    1d33:	jne    1d8f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xaf>
    1d35:	mov    0x10(%rcx),%rax
    1d39:	test   %rax,%rax
    1d3c:	je     1d9a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d3e:	movabs $0x4000000000000002,%r8
    1d48:	test   %r8,-0x10(%rax)
    1d4c:	jne    1d9a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d4e:	xor    %r8d,%r8d
    1d51:	cmpq   $0xfffffffffffffffd,-0x18(%rax)
    1d56:	jb     1d8b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xab>
    1d58:	mov    0x0(%rip),%rsi        # 1d5f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x7f>
    1d5f:	pop    %rbp
    1d60:	jmp    1d65 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x85>
    1d65:	mov    0x10(%rcx),%rax
    1d69:	test   %rax,%rax
    1d6c:	je     1d9a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d6e:	movabs $0x4000000000000002,%r8
    1d78:	test   %r8,-0x10(%rax)
    1d7c:	jne    1d9a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d7e:	mov    $0x1,%r8d
    1d84:	cmpq   $0xfffffffffffffffd,-0x18(%rax)
    1d89:	jae    1d58 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x78>
    1d8b:	test   %esi,%esi
    1d8d:	je     1dce <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xee>
    1d8f:	cmp    $0x1,%r8d
    1d93:	je     1d9a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d95:	test   %r8d,%r8d
    1d98:	jne    1db7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1d9a:	mov    0x10(%rcx),%rax
    1d9e:	test   %rax,%rax
    1da1:	je     1db7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1da3:	movabs $0x4000000000000002,%rsi
    1dad:	test   %rsi,-0x10(%rax)
    1db1:	jne    1db7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1db3:	incq   -0x18(%rax)
    1db7:	mov    0x10(%rcx),%rax
    1dbb:	mov    %rax,0x10(%rdx)
    1dbf:	vmovups (%rcx),%xmm0
    1dc3:	vmovups %xmm0,(%rdx)
    1dc7:	mov    $0x1,%eax
    1dcc:	pop    %rbp
    1dcd:	ret
    1dce:	mov    0x8(%rcx),%rax
    1dd2:	test   %rax,%rax
    1dd5:	jne    1da3 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xc3>
    1dd7:	jmp    1db7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1dd9:	nopl   0x0(%rax)

0000000000001de0 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan>:
    1de0:	push   %rbp
    1de1:	mov    %rsp,%rbp
    1de4:	push   %r14
    1de6:	push   %rbx
    1de7:	mov    (%rsi),%eax
    1de9:	cmp    $0x1,%eax
    1dec:	je     1e05 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x25>
    1dee:	test   %eax,%eax
    1df0:	jne    1e4a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1df2:	mov    0x8(%rsi),%rax
    1df6:	movq   $0x0,0x8(%rsi)
    1dfe:	test   %rax,%rax
    1e01:	jne    1e22 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x42>
    1e03:	jmp    1e4a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1e05:	mov    0x8(%rsi),%eax
    1e08:	cmp    $0x1,%eax
    1e0b:	je     1e11 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x31>
    1e0d:	test   %eax,%eax
    1e0f:	jne    1e4a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1e11:	mov    0x10(%rsi),%rax
    1e15:	movq   $0x0,0x10(%rsi)
    1e1d:	test   %rax,%rax
    1e20:	je     1e4a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1e22:	movabs $0x4000000000000002,%rcx
    1e2c:	test   %rcx,-0x10(%rax)
    1e30:	jne    1e4a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1e32:	mov    -0x18(%rax),%rcx
    1e36:	cmp    $0x1,%rcx
    1e3a:	jne    1e43 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x63>
    1e3c:	cmpq   $0x0,-0x20(%rax)
    1e41:	je     1e5f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x7f>
    1e43:	dec    %rcx
    1e46:	mov    %rcx,-0x18(%rax)
    1e4a:	vxorps %xmm0,%xmm0,%xmm0
    1e4e:	vmovups %xmm0,(%rsi)
    1e52:	movq   $0x0,0x10(%rsi)
    1e5a:	pop    %rbx
    1e5b:	pop    %r14
    1e5d:	pop    %rbp
    1e5e:	ret
    1e5f:	mov    %rsi,%r14
    1e62:	mov    %rdi,%rbx
    1e65:	mov    %rax,%rsi
    1e68:	call   1e6d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x8d>
    1e6d:	vxorps %xmm0,%xmm0,%xmm0
    1e71:	vmovups %xmm0,(%r14)
    1e76:	movq   $0x0,0x10(%r14)
    1e7e:	mov    %rbx,%rdi
    1e81:	pop    %rbx
    1e82:	pop    %r14
    1e84:	pop    %rbp
    1e85:	jmp    1e8a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0xaa>
    1e8a:	nopw   0x0(%rax,%rax,1)

0000000000001e90 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop>:
    1e90:	push   %rbp
    1e91:	mov    %rsp,%rbp
    1e94:	push   %r14
    1e96:	push   %rbx
    1e97:	mov    (%rsi),%eax
    1e99:	cmp    $0x1,%eax
    1e9c:	je     1eb5 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x25>
    1e9e:	test   %eax,%eax
    1ea0:	jne    1efa <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1ea2:	mov    0x8(%rsi),%rax
    1ea6:	movq   $0x0,0x8(%rsi)
    1eae:	test   %rax,%rax
    1eb1:	jne    1ed2 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x42>
    1eb3:	jmp    1efa <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1eb5:	mov    0x8(%rsi),%eax
    1eb8:	cmp    $0x1,%eax
    1ebb:	je     1ec1 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x31>
    1ebd:	test   %eax,%eax
    1ebf:	jne    1efa <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1ec1:	mov    0x10(%rsi),%rax
    1ec5:	movq   $0x0,0x10(%rsi)
    1ecd:	test   %rax,%rax
    1ed0:	je     1efa <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1ed2:	movabs $0x4000000000000002,%rcx
    1edc:	test   %rcx,-0x10(%rax)
    1ee0:	jne    1efa <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1ee2:	mov    -0x20(%rax),%rcx
    1ee6:	cmp    $0x1,%rcx
    1eea:	jne    1ef3 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x63>
    1eec:	cmpq   $0x0,-0x18(%rax)
    1ef1:	je     1f0f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x7f>
    1ef3:	dec    %rcx
    1ef6:	mov    %rcx,-0x20(%rax)
    1efa:	vxorps %xmm0,%xmm0,%xmm0
    1efe:	vmovups %xmm0,(%rsi)
    1f02:	movq   $0x0,0x10(%rsi)
    1f0a:	pop    %rbx
    1f0b:	pop    %r14
    1f0d:	pop    %rbp
    1f0e:	ret
    1f0f:	mov    %rsi,%r14
    1f12:	mov    %rdi,%rbx
    1f15:	mov    %rax,%rsi
    1f18:	call   1f1d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x8d>
    1f1d:	vxorps %xmm0,%xmm0,%xmm0
    1f21:	vmovups %xmm0,(%r14)
    1f26:	movq   $0x0,0x10(%r14)
    1f2e:	mov    %rbx,%rdi
    1f31:	pop    %rbx
    1f32:	pop    %r14
    1f34:	pop    %rbp
    1f35:	jmp    1f3a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0xaa>
    1f3a:	nopw   0x0(%rax,%rax,1)

0000000000001f40 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain>:
    1f40:	push   %rbp
    1f41:	mov    %rsp,%rbp
    1f44:	mov    %ecx,%r8d
    1f47:	mov    %rdx,%rcx
    1f4a:	mov    %rsi,%rdx
    1f4d:	movabs $0x4000000000000002,%rax
    1f57:	mov    (%rcx),%esi
    1f59:	mov    $0x1,%r9b
    1f5c:	cmp    $0x1,%esi
    1f5f:	je     1f7c <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x3c>
    1f61:	test   %esi,%esi
    1f63:	jne    1f9a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5a>
    1f65:	mov    0x8(%rcx),%r11
    1f69:	test   %r11,%r11
    1f6c:	je     1f9a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5a>
    1f6e:	mov    -0x10(%r11),%r10
    1f72:	test   %rax,%r10
    1f75:	jne    1f9d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5d>
    1f77:	jmp    2014 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xd4>
    1f7c:	mov    0x8(%rcx),%r10d
    1f80:	cmp    $0x1,%r10d
    1f84:	je     1f8b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x4b>
    1f86:	test   %r10d,%r10d
    1f89:	jne    1f9a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5a>
    1f8b:	mov    0x10(%rcx),%r10
    1f8f:	test   %r10,%r10
    1f92:	je     2002 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xc2>
    1f94:	mov    -0x10(%r10),%r10
    1f98:	jmp    2005 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xc5>
    1f9a:	xor    %r10d,%r10d
    1f9d:	test   %r9b,%r9b
    1fa0:	je     1fbf <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x7f>
    1fa2:	lea    -0x2(%rax),%r9
    1fa6:	and    %r9,%r10
    1fa9:	jne    1fbf <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x7f>
    1fab:	cmp    $0x1,%esi
    1fae:	je     1fcc <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x8c>
    1fb0:	test   %esi,%esi
    1fb2:	jne    1feb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1fb4:	mov    0x8(%rcx),%rsi
    1fb8:	test   %rsi,%rsi
    1fbb:	jne    1fe1 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xa1>
    1fbd:	jmp    1feb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1fbf:	mov    0x0(%rip),%rsi        # 1fc6 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x86>
    1fc6:	pop    %rbp
    1fc7:	jmp    1fcc <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x8c>
    1fcc:	mov    0x8(%rcx),%esi
    1fcf:	cmp    $0x1,%esi
    1fd2:	je     1fd8 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x98>
    1fd4:	test   %esi,%esi
    1fd6:	jne    1feb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1fd8:	mov    0x10(%rcx),%rsi
    1fdc:	test   %rsi,%rsi
    1fdf:	je     1feb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1fe1:	test   %rax,-0x10(%rsi)
    1fe5:	jne    1feb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1fe7:	incq   -0x20(%rsi)
    1feb:	vmovups (%rcx),%xmm0
    1fef:	mov    0x10(%rcx),%rax
    1ff3:	mov    %rax,0x10(%rdx)
    1ff7:	vmovups %xmm0,(%rdx)
    1ffb:	mov    $0x1,%eax
    2000:	pop    %rbp
    2001:	ret
    2002:	xor    %r10d,%r10d
    2005:	mov    0x10(%rcx),%r11
    2009:	test   %r11,%r11
    200c:	je     1f9d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5d>
    200e:	test   %rax,-0x10(%r11)
    2012:	jne    1f9d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5d>
    2014:	cmpq   $0xfffffffffffffffd,-0x20(%r11)
    2019:	setb   %r9b
    201d:	jmp    1f9d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5d>
    2022:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000002030 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take>:
    2030:	push   %rbp
    2031:	mov    %rsp,%rbp
    2034:	mov    %ecx,%r8d
    2037:	mov    %rdx,%rcx
    203a:	mov    %rsi,%rdx
    203d:	mov    (%rcx),%eax
    203f:	cmp    $0x1,%eax
    2042:	je     2053 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x23>
    2044:	test   %eax,%eax
    2046:	jne    206e <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x3e>
    2048:	mov    0x8(%rcx),%rax
    204c:	test   %rax,%rax
    204f:	jne    2068 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x38>
    2051:	jmp    206e <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x3e>
    2053:	mov    0x8(%rcx),%eax
    2056:	cmp    $0x1,%eax
    2059:	je     205f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x2f>
    205b:	test   %eax,%eax
    205d:	jne    206e <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x3e>
    205f:	mov    0x10(%rcx),%rax
    2063:	test   %rax,%rax
    2066:	je     206e <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x3e>
    2068:	testb  $0x50,-0x9(%rax)
    206c:	jne    20ab <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x7b>
    206e:	mov    %rdx,%rax
    2071:	sub    %rcx,%rax
    2074:	mov    %rcx,%rsi
    2077:	sub    %rdx,%rsi
    207a:	cmovb  %rax,%rsi
    207e:	cmp    $0x17,%rsi
    2082:	jbe    20ab <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x7b>
    2084:	mov    0x10(%rcx),%rax
    2088:	mov    %rax,0x10(%rdx)
    208c:	vmovups (%rcx),%xmm0
    2090:	vmovups %xmm0,(%rdx)
    2094:	vxorps %xmm0,%xmm0,%xmm0
    2098:	vmovups %xmm0,(%rcx)
    209c:	movq   $0x0,0x10(%rcx)
    20a4:	mov    $0x1,%eax
    20a9:	pop    %rbp
    20aa:	ret
    20ab:	mov    0x0(%rip),%rsi        # 20b2 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x82>
    20b2:	pop    %rbp
    20b3:	jmp    20b8 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x88>
    20b8:	nopl   0x0(%rax,%rax,1)

00000000000020c0 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish>:
    20c0:	push   %rbp
    20c1:	mov    %rsp,%rbp
    20c4:	push   %r15
    20c6:	push   %r14
    20c8:	push   %r13
    20ca:	push   %r12
    20cc:	push   %rbx
    20cd:	push   %rax
    20ce:	mov    %r8d,%r15d
    20d1:	mov    %ecx,%r8d
    20d4:	mov    %rdx,%r14
    20d7:	mov    %rsi,%rbx
    20da:	mov    (%rdx),%eax
    20dc:	mov    $0x1,%cl
    20de:	cmp    $0x1,%eax
    20e1:	je     20f2 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x32>
    20e3:	test   %eax,%eax
    20e5:	jne    210f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x4f>
    20e7:	mov    0x8(%r14),%rdx
    20eb:	test   %rdx,%rdx
    20ee:	jne    2108 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x48>
    20f0:	jmp    210f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x4f>
    20f2:	mov    0x8(%r14),%edx
    20f6:	cmp    $0x1,%edx
    20f9:	je     20ff <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x3f>
    20fb:	test   %edx,%edx
    20fd:	jne    210f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x4f>
    20ff:	mov    0x10(%r14),%rdx
    2103:	test   %rdx,%rdx
    2106:	je     210f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x4f>
    2108:	testb  $0x50,-0x9(%rdx)
    210c:	sete   %cl
    210f:	test   $0x3,%r15b
    2113:	jne    218a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xca>
    2115:	test   %cl,%cl
    2117:	je     218a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xca>
    2119:	mov    %rbx,%rcx
    211c:	sub    %r14,%rcx
    211f:	mov    %r14,%rdx
    2122:	sub    %rbx,%rdx
    2125:	cmovb  %rcx,%rdx
    2129:	cmp    $0x17,%rdx
    212d:	jbe    218a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xca>
    212f:	test   $0x4,%r15b
    2133:	jne    21ad <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xed>
    2135:	cmp    $0x1,%eax
    2138:	je     215d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x9d>
    213a:	test   %eax,%eax
    213c:	jne    21fd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    2142:	mov    0x8(%r14),%rcx
    2146:	test   %rcx,%rcx
    2149:	je     21b6 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xf6>
    214b:	movabs $0x4000000000000002,%rdx
    2155:	test   %rdx,-0x10(%rcx)
    2159:	jne    21b6 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xf6>
    215b:	jmp    2183 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xc3>
    215d:	mov    0x8(%r14),%ecx
    2161:	cmp    $0x1,%ecx
    2164:	je     216a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xaa>
    2166:	test   %ecx,%ecx
    2168:	jne    21e7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x127>
    216a:	mov    0x10(%r14),%rcx
    216e:	test   %rcx,%rcx
    2171:	je     21e7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x127>
    2173:	movabs $0x4000000000000002,%rdx
    217d:	test   %rdx,-0x10(%rcx)
    2181:	jne    21e7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x127>
    2183:	cmpq   $0xfffffffffffffffd,-0x20(%rcx)
    2188:	jb     21ad <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xed>
    218a:	mov    0x0(%rip),%rsi        # 2191 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xd1>
    2191:	mov    %rbx,%rdx
    2194:	mov    %r14,%rcx
    2197:	mov    %r15d,%r9d
    219a:	add    $0x8,%rsp
    219e:	pop    %rbx
    219f:	pop    %r12
    21a1:	pop    %r13
    21a3:	pop    %r14
    21a5:	pop    %r15
    21a7:	pop    %rbp
    21a8:	jmp    21ad <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xed>
    21ad:	cmp    $0x1,%eax
    21b0:	je     21e7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x127>
    21b2:	test   %eax,%eax
    21b4:	jne    21fd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21b6:	mov    0x8(%r14),%r12
    21ba:	test   %r12,%r12
    21bd:	je     21fd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21bf:	movabs $0x2000000000000000,%r13
    21c9:	lea    0x2(%r13),%rax
    21cd:	test   %rax,-0x10(%r12)
    21d2:	jne    21fd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21d4:	mov    %r12,%rdi
    21d7:	call   21dc <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x11c>
    21dc:	test   %eax,%eax
    21de:	je     21fd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21e0:	or     %r13,-0x10(%r12)
    21e5:	jmp    21fd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21e7:	mov    0x8(%r14),%eax
    21eb:	cmp    $0x1,%eax
    21ee:	je     21f4 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x134>
    21f0:	test   %eax,%eax
    21f2:	jne    21fd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21f4:	mov    0x10(%r14),%rdi
    21f8:	call   490 <myl_rcg_share>
    21fd:	mov    0x10(%r14),%rax
    2201:	mov    %rax,0x10(%rbx)
    2205:	vmovups (%r14),%xmm0
    220a:	vmovups %xmm0,(%rbx)
    220e:	test   $0x4,%r15b
    2212:	jne    222a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x16a>
    2214:	mov    (%rbx),%eax
    2216:	cmp    $0x1,%eax
    2219:	je     224f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x18f>
    221b:	test   %eax,%eax
    221d:	jne    223b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    221f:	mov    0x8(%rbx),%rax
    2223:	test   %rax,%rax
    2226:	jne    2264 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x1a4>
    2228:	jmp    223b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    222a:	vxorps %xmm0,%xmm0,%xmm0
    222e:	vmovups %xmm0,(%r14)
    2233:	movq   $0x0,0x10(%r14)
    223b:	mov    $0x1,%eax
    2240:	add    $0x8,%rsp
    2244:	pop    %rbx
    2245:	pop    %r12
    2247:	pop    %r13
    2249:	pop    %r14
    224b:	pop    %r15
    224d:	pop    %rbp
    224e:	ret
    224f:	mov    0x8(%rbx),%eax
    2252:	cmp    $0x1,%eax
    2255:	je     225b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x19b>
    2257:	test   %eax,%eax
    2259:	jne    223b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    225b:	mov    0x10(%rbx),%rax
    225f:	test   %rax,%rax
    2262:	je     223b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    2264:	movabs $0x4000000000000002,%rcx
    226e:	test   %rcx,-0x10(%rax)
    2272:	jne    223b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    2274:	incq   -0x20(%rax)
    2278:	jmp    223b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
