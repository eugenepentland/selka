
.tmp/text-ops-final-review/append-layout-probe/cold-helper.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <myl_r_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a>:
       0:	push   %rbp
       1:	mov    %rsp,%rbp
       4:	pop    %rbp
       5:	jmp    a <myl_r_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a+0xa>
       a:	nopw   0x0(%rax,%rax,1)

0000000000000010 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan>:
      10:	push   %rbp
      11:	mov    %rsp,%rbp
      14:	mov    %rdx,%rcx
      17:	mov    %rsi,%rdx
      1a:	cmpl   $0x1,(%rcx)
      1d:	jne    61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      1f:	mov    0x8(%rcx),%eax
      22:	cmp    $0x1,%eax
      25:	je     2b <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x1b>
      27:	test   %eax,%eax
      29:	jne    61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      2b:	mov    0x10(%rcx),%rsi
      2f:	test   %rsi,%rsi
      32:	je     44 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x34>
      34:	movabs $0x4000000000000002,%r8
      3e:	test   %r8,-0x10(%rsi)
      42:	je     78 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x68>
      44:	mov    0x10(%rcx),%rax
      48:	test   %rax,%rax
      4b:	je     61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      4d:	movabs $0x4000000000000002,%rsi
      57:	test   %rsi,-0x10(%rax)
      5b:	jne    61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      5d:	incq   -0x18(%rax)
      61:	mov    0x10(%rcx),%rax
      65:	mov    %rax,0x10(%rdx)
      69:	vmovups (%rcx),%xmm0
      6d:	vmovups %xmm0,(%rdx)
      71:	mov    $0x1,%eax
      76:	pop    %rbp
      77:	ret
      78:	cmpq   $0xfffffffffffffffd,-0x18(%rsi)
      7d:	jb     8c <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x7c>
      7f:	mov    0x0(%rip),%rsi        # 86 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x76>
      86:	pop    %rbp
      87:	jmp    8c <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x7c>
      8c:	cmp    $0x1,%eax
      8f:	je     44 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x34>
      91:	test   %eax,%eax
      93:	je     44 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x34>
      95:	jmp    61 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_loan+0x51>
      97:	nopw   0x0(%rax,%rax,1)

00000000000000a0 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan>:
      a0:	push   %rbp
      a1:	mov    %rsp,%rbp
      a4:	push   %r14
      a6:	push   %rbx
      a7:	cmpl   $0x1,(%rsi)
      aa:	jne    f1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x51>
      ac:	mov    0x8(%rsi),%eax
      af:	cmp    $0x1,%eax
      b2:	je     b8 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x18>
      b4:	test   %eax,%eax
      b6:	jne    f1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x51>
      b8:	mov    0x10(%rsi),%rax
      bc:	movq   $0x0,0x10(%rsi)
      c4:	test   %rax,%rax
      c7:	je     f1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x51>
      c9:	movabs $0x4000000000000002,%rcx
      d3:	test   %rcx,-0x10(%rax)
      d7:	jne    f1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x51>
      d9:	mov    -0x18(%rax),%rcx
      dd:	cmp    $0x1,%rcx
      e1:	jne    ea <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x4a>
      e3:	cmpq   $0x0,-0x20(%rax)
      e8:	je     106 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x66>
      ea:	dec    %rcx
      ed:	mov    %rcx,-0x18(%rax)
      f1:	vxorps %xmm0,%xmm0,%xmm0
      f5:	vmovups %xmm0,(%rsi)
      f9:	movq   $0x0,0x10(%rsi)
     101:	pop    %rbx
     102:	pop    %r14
     104:	pop    %rbp
     105:	ret
     106:	mov    %rsi,%r14
     109:	mov    %rdi,%rbx
     10c:	mov    %rax,%rsi
     10f:	call   114 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x74>
     114:	vxorps %xmm0,%xmm0,%xmm0
     118:	vmovups %xmm0,(%r14)
     11d:	movq   $0x0,0x10(%r14)
     125:	mov    %rbx,%rdi
     128:	pop    %rbx
     129:	pop    %r14
     12b:	pop    %rbp
     12c:	jmp    131 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_unloan+0x91>
     131:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000140 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop>:
     140:	push   %rbp
     141:	mov    %rsp,%rbp
     144:	push   %r14
     146:	push   %rbx
     147:	cmpl   $0x1,(%rsi)
     14a:	jne    191 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x51>
     14c:	mov    0x8(%rsi),%eax
     14f:	cmp    $0x1,%eax
     152:	je     158 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x18>
     154:	test   %eax,%eax
     156:	jne    191 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x51>
     158:	mov    0x10(%rsi),%rax
     15c:	movq   $0x0,0x10(%rsi)
     164:	test   %rax,%rax
     167:	je     191 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x51>
     169:	movabs $0x4000000000000002,%rcx
     173:	test   %rcx,-0x10(%rax)
     177:	jne    191 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x51>
     179:	mov    -0x20(%rax),%rcx
     17d:	cmp    $0x1,%rcx
     181:	jne    18a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x4a>
     183:	cmpq   $0x0,-0x18(%rax)
     188:	je     1a6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x66>
     18a:	dec    %rcx
     18d:	mov    %rcx,-0x20(%rax)
     191:	vxorps %xmm0,%xmm0,%xmm0
     195:	vmovups %xmm0,(%rsi)
     199:	movq   $0x0,0x10(%rsi)
     1a1:	pop    %rbx
     1a2:	pop    %r14
     1a4:	pop    %rbp
     1a5:	ret
     1a6:	mov    %rsi,%r14
     1a9:	mov    %rdi,%rbx
     1ac:	mov    %rax,%rsi
     1af:	call   1b4 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x74>
     1b4:	vxorps %xmm0,%xmm0,%xmm0
     1b8:	vmovups %xmm0,(%r14)
     1bd:	movq   $0x0,0x10(%r14)
     1c5:	mov    %rbx,%rdi
     1c8:	pop    %rbx
     1c9:	pop    %r14
     1cb:	pop    %rbp
     1cc:	jmp    1d1 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_drop+0x91>
     1d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

00000000000001e0 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain>:
     1e0:	push   %rbp
     1e1:	mov    %rsp,%rbp
     1e4:	mov    %ecx,%r8d
     1e7:	mov    %rdx,%rcx
     1ea:	mov    %rsi,%rdx
     1ed:	cmpl   $0x1,(%rcx)
     1f0:	jne    264 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x84>
     1f2:	movabs $0x4000000000000002,%rax
     1fc:	mov    0x8(%rcx),%esi
     1ff:	mov    $0x1,%r9b
     202:	cmp    $0x1,%esi
     205:	je     20b <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x2b>
     207:	test   %esi,%esi
     209:	jne    21a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x3a>
     20b:	mov    0x10(%rcx),%r10
     20f:	test   %r10,%r10
     212:	je     21f <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x3f>
     214:	mov    -0x10(%r10),%r10
     218:	jmp    222 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x42>
     21a:	xor    %r10d,%r10d
     21d:	jmp    23a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x5a>
     21f:	xor    %r10d,%r10d
     222:	mov    0x10(%rcx),%r11
     226:	test   %r11,%r11
     229:	je     23a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x5a>
     22b:	test   %rax,-0x10(%r11)
     22f:	jne    23a <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x5a>
     231:	cmpq   $0xfffffffffffffffd,-0x20(%r11)
     236:	setb   %r9b
     23a:	test   %r9b,%r9b
     23d:	je     27b <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x9b>
     23f:	lea    -0x2(%rax),%r9
     243:	and    %r9,%r10
     246:	jne    27b <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x9b>
     248:	cmp    $0x1,%esi
     24b:	je     251 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x71>
     24d:	test   %esi,%esi
     24f:	jne    264 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x84>
     251:	mov    0x10(%rcx),%rsi
     255:	test   %rsi,%rsi
     258:	je     264 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x84>
     25a:	test   %rax,-0x10(%rsi)
     25e:	jne    264 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0x84>
     260:	incq   -0x20(%rsi)
     264:	vmovups (%rcx),%xmm0
     268:	mov    0x10(%rcx),%rax
     26c:	mov    %rax,0x10(%rdx)
     270:	vmovups %xmm0,(%rdx)
     274:	mov    $0x1,%eax
     279:	pop    %rbp
     27a:	ret
     27b:	mov    0x0(%rip),%rsi        # 282 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0xa2>
     282:	pop    %rbp
     283:	jmp    288 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_retain+0xa8>
     288:	nopl   0x0(%rax,%rax,1)

0000000000000290 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take>:
     290:	push   %rbp
     291:	mov    %rsp,%rbp
     294:	mov    %ecx,%r8d
     297:	mov    %rdx,%rcx
     29a:	mov    %rsi,%rdx
     29d:	cmpl   $0x1,(%rcx)
     2a0:	jne    2bd <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x2d>
     2a2:	mov    0x8(%rcx),%eax
     2a5:	cmp    $0x1,%eax
     2a8:	je     2ae <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x1e>
     2aa:	test   %eax,%eax
     2ac:	jne    2bd <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x2d>
     2ae:	mov    0x10(%rcx),%rax
     2b2:	test   %rax,%rax
     2b5:	je     2bd <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x2d>
     2b7:	testb  $0x50,-0x9(%rax)
     2bb:	jne    2fa <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x6a>
     2bd:	mov    %rdx,%rax
     2c0:	sub    %rcx,%rax
     2c3:	mov    %rcx,%rsi
     2c6:	sub    %rdx,%rsi
     2c9:	cmovb  %rax,%rsi
     2cd:	cmp    $0x17,%rsi
     2d1:	jbe    2fa <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x6a>
     2d3:	mov    0x10(%rcx),%rax
     2d7:	mov    %rax,0x10(%rdx)
     2db:	vmovups (%rcx),%xmm0
     2df:	vmovups %xmm0,(%rdx)
     2e3:	vxorps %xmm0,%xmm0,%xmm0
     2e7:	vmovups %xmm0,(%rcx)
     2eb:	movq   $0x0,0x10(%rcx)
     2f3:	mov    $0x1,%eax
     2f8:	pop    %rbp
     2f9:	ret
     2fa:	mov    0x0(%rip),%rsi        # 301 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x71>
     301:	pop    %rbp
     302:	jmp    307 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_take+0x77>
     307:	nopw   0x0(%rax,%rax,1)

0000000000000310 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish>:
     310:	push   %rbp
     311:	mov    %rsp,%rbp
     314:	push   %r15
     316:	push   %r14
     318:	push   %r13
     31a:	push   %r12
     31c:	push   %rbx
     31d:	push   %rax
     31e:	mov    %r8d,%r15d
     321:	mov    %ecx,%r8d
     324:	mov    %rdx,%r14
     327:	mov    %rsi,%rbx
     32a:	mov    (%rdx),%eax
     32c:	mov    $0x1,%cl
     32e:	cmp    $0x1,%eax
     331:	jne    350 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x40>
     333:	mov    0x8(%r14),%edx
     337:	cmp    $0x1,%edx
     33a:	je     340 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x30>
     33c:	test   %edx,%edx
     33e:	jne    350 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x40>
     340:	mov    0x10(%r14),%rdx
     344:	test   %rdx,%rdx
     347:	je     350 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x40>
     349:	testb  $0x50,-0x9(%rdx)
     34d:	sete   %cl
     350:	test   $0x3,%r15b
     354:	jne    3b6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xa6>
     356:	test   %cl,%cl
     358:	je     3b6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xa6>
     35a:	mov    %rbx,%rcx
     35d:	sub    %r14,%rcx
     360:	mov    %r14,%rdx
     363:	sub    %rbx,%rdx
     366:	cmovb  %rcx,%rdx
     36a:	cmp    $0x17,%rdx
     36e:	jbe    3b6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xa6>
     370:	mov    %eax,%ecx
     372:	xor    $0x1,%ecx
     375:	mov    %r15d,%edx
     378:	and    $0x4,%edx
     37b:	or     %ecx,%edx
     37d:	je     389 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x79>
     37f:	cmp    $0x1,%eax
     382:	je     3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     384:	jmp    415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     389:	mov    0x8(%r14),%eax
     38d:	cmp    $0x1,%eax
     390:	je     396 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x86>
     392:	test   %eax,%eax
     394:	jne    3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     396:	mov    0x10(%r14),%rax
     39a:	test   %rax,%rax
     39d:	je     3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     39f:	movabs $0x4000000000000002,%rcx
     3a9:	test   %rcx,-0x10(%rax)
     3ad:	jne    3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     3af:	cmpq   $0xfffffffffffffffd,-0x20(%rax)
     3b4:	jb     3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     3b6:	mov    0x0(%rip),%rsi        # 3bd <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xad>
     3bd:	mov    %rbx,%rdx
     3c0:	mov    %r14,%rcx
     3c3:	mov    %r15d,%r9d
     3c6:	add    $0x8,%rsp
     3ca:	pop    %rbx
     3cb:	pop    %r12
     3cd:	pop    %r13
     3cf:	pop    %r14
     3d1:	pop    %r15
     3d3:	pop    %rbp
     3d4:	jmp    3d9 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xc9>
     3d9:	mov    0x8(%r14),%eax
     3dd:	cmp    $0x1,%eax
     3e0:	je     3e6 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xd6>
     3e2:	test   %eax,%eax
     3e4:	jne    415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     3e6:	mov    0x10(%r14),%r12
     3ea:	test   %r12,%r12
     3ed:	je     415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     3ef:	movabs $0x2000000000000000,%r13
     3f9:	lea    0x2(%r13),%rax
     3fd:	test   %rax,-0x10(%r12)
     402:	jne    415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     404:	mov    %r12,%rdi
     407:	call   40c <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0xfc>
     40c:	test   %eax,%eax
     40e:	je     415 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x105>
     410:	or     %r13,-0x10(%r12)
     415:	mov    0x10(%r14),%rax
     419:	mov    %rax,0x10(%rbx)
     41d:	vmovups (%r14),%xmm0
     422:	vmovups %xmm0,(%rbx)
     426:	test   $0x4,%r15b
     42a:	je     43f <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x12f>
     42c:	vxorps %xmm0,%xmm0,%xmm0
     430:	vmovups %xmm0,(%r14)
     435:	movq   $0x0,0x10(%r14)
     43d:	jmp    46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     43f:	cmpl   $0x1,(%rbx)
     442:	jne    46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     444:	mov    0x8(%rbx),%eax
     447:	cmp    $0x1,%eax
     44a:	je     450 <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x140>
     44c:	test   %eax,%eax
     44e:	jne    46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     450:	mov    0x10(%rbx),%rax
     454:	test   %rax,%rax
     457:	je     46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     459:	movabs $0x4000000000000002,%rcx
     463:	test   %rcx,-0x10(%rax)
     467:	jne    46d <myl_t_085c0bd01226dbfb0329d8a31544ce52ff4b7dad1f406e39e147c95b3c7ea4f2_rcg_publish+0x15d>
     469:	incq   -0x20(%rax)
     46d:	mov    $0x1,%eax
     472:	add    $0x8,%rsp
     476:	pop    %rbx
     477:	pop    %r12
     479:	pop    %r13
     47b:	pop    %r14
     47d:	pop    %r15
     47f:	pop    %rbp
     480:	ret
     481:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000490 <myl_rcg_share>:
     490:	test   %rdi,%rdi
     493:	je     4c4 <myl_rcg_share+0x34>
     495:	push   %rbp
     496:	mov    %rsp,%rbp
     499:	push   %r14
     49b:	push   %rbx
     49c:	movabs $0x2000000000000000,%r14
     4a6:	lea    0x2(%r14),%rax
     4aa:	test   %rax,-0x10(%rdi)
     4ae:	jne    4c0 <myl_rcg_share+0x30>
     4b0:	mov    %rdi,%rbx
     4b3:	call   4b8 <myl_rcg_share+0x28>
     4b8:	test   %eax,%eax
     4ba:	je     4c0 <myl_rcg_share+0x30>
     4bc:	or     %r14,-0x10(%rbx)
     4c0:	pop    %rbx
     4c1:	pop    %r14
     4c3:	pop    %rbp
     4c4:	ret
     4c5:	data16 cs nopw 0x0(%rax,%rax,1)

00000000000004d0 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan>:
     4d0:	push   %rbp
     4d1:	mov    %rsp,%rbp
     4d4:	mov    %rdx,%rcx
     4d7:	mov    %rsi,%rdx
     4da:	mov    (%rcx),%eax
     4dc:	cmp    $0x1,%eax
     4df:	je     4e5 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x15>
     4e1:	test   %eax,%eax
     4e3:	jne    51c <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x4c>
     4e5:	mov    0x8(%rcx),%rax
     4e9:	test   %rax,%rax
     4ec:	je     51c <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x4c>
     4ee:	movabs $0x4000000000000002,%rsi
     4f8:	test   %rsi,-0x10(%rax)
     4fc:	jne    51c <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x4c>
     4fe:	mov    -0x18(%rax),%rsi
     502:	cmp    $0xfffffffffffffffd,%rsi
     506:	jbe    515 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x45>
     508:	mov    0x0(%rip),%rsi        # 50f <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x3f>
     50f:	pop    %rbp
     510:	jmp    515 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_loan+0x45>
     515:	inc    %rsi
     518:	mov    %rsi,-0x18(%rax)
     51c:	vmovups (%rcx),%xmm0
     520:	vmovups %xmm0,(%rdx)
     524:	mov    $0x1,%eax
     529:	pop    %rbp
     52a:	ret
     52b:	nopl   0x0(%rax,%rax,1)

0000000000000530 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan>:
     530:	push   %rbp
     531:	mov    %rsp,%rbp
     534:	push   %r14
     536:	push   %rbx
     537:	mov    (%rsi),%eax
     539:	cmp    $0x1,%eax
     53c:	je     542 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x12>
     53e:	test   %eax,%eax
     540:	jne    57b <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x4b>
     542:	mov    0x8(%rsi),%rax
     546:	movq   $0x0,0x8(%rsi)
     54e:	test   %rax,%rax
     551:	je     57b <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x4b>
     553:	movabs $0x4000000000000002,%rcx
     55d:	test   %rcx,-0x10(%rax)
     561:	jne    57b <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x4b>
     563:	mov    -0x18(%rax),%rcx
     567:	cmp    $0x1,%rcx
     56b:	jne    574 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x44>
     56d:	cmpq   $0x0,-0x20(%rax)
     572:	je     588 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x58>
     574:	dec    %rcx
     577:	mov    %rcx,-0x18(%rax)
     57b:	vxorps %xmm0,%xmm0,%xmm0
     57f:	vmovups %xmm0,(%rsi)
     583:	pop    %rbx
     584:	pop    %r14
     586:	pop    %rbp
     587:	ret
     588:	mov    %rsi,%r14
     58b:	mov    %rdi,%rbx
     58e:	mov    %rax,%rsi
     591:	call   596 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x66>
     596:	vxorps %xmm0,%xmm0,%xmm0
     59a:	vmovups %xmm0,(%r14)
     59f:	mov    %rbx,%rdi
     5a2:	pop    %rbx
     5a3:	pop    %r14
     5a5:	pop    %rbp
     5a6:	jmp    5ab <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_unloan+0x7b>
     5ab:	nopl   0x0(%rax,%rax,1)

00000000000005b0 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop>:
     5b0:	push   %rbp
     5b1:	mov    %rsp,%rbp
     5b4:	push   %r14
     5b6:	push   %rbx
     5b7:	mov    (%rsi),%eax
     5b9:	cmp    $0x1,%eax
     5bc:	je     5c2 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x12>
     5be:	test   %eax,%eax
     5c0:	jne    5fb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x4b>
     5c2:	mov    0x8(%rsi),%rax
     5c6:	movq   $0x0,0x8(%rsi)
     5ce:	test   %rax,%rax
     5d1:	je     5fb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x4b>
     5d3:	movabs $0x4000000000000002,%rcx
     5dd:	test   %rcx,-0x10(%rax)
     5e1:	jne    5fb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x4b>
     5e3:	mov    -0x20(%rax),%rcx
     5e7:	cmp    $0x1,%rcx
     5eb:	jne    5f4 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x44>
     5ed:	cmpq   $0x0,-0x18(%rax)
     5f2:	je     608 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x58>
     5f4:	dec    %rcx
     5f7:	mov    %rcx,-0x20(%rax)
     5fb:	vxorps %xmm0,%xmm0,%xmm0
     5ff:	vmovups %xmm0,(%rsi)
     603:	pop    %rbx
     604:	pop    %r14
     606:	pop    %rbp
     607:	ret
     608:	mov    %rsi,%r14
     60b:	mov    %rdi,%rbx
     60e:	mov    %rax,%rsi
     611:	call   616 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x66>
     616:	vxorps %xmm0,%xmm0,%xmm0
     61a:	vmovups %xmm0,(%r14)
     61f:	mov    %rbx,%rdi
     622:	pop    %rbx
     623:	pop    %r14
     625:	pop    %rbp
     626:	jmp    62b <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_drop+0x7b>
     62b:	nopl   0x0(%rax,%rax,1)

0000000000000630 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain>:
     630:	push   %rbp
     631:	mov    %rsp,%rbp
     634:	mov    %ecx,%r8d
     637:	mov    %rdx,%rcx
     63a:	mov    %rsi,%rdx
     63d:	mov    (%rcx),%eax
     63f:	cmp    $0x1,%eax
     642:	je     648 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x18>
     644:	test   %eax,%eax
     646:	jne    680 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x50>
     648:	mov    0x8(%rcx),%rax
     64c:	test   %rax,%rax
     64f:	je     680 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x50>
     651:	mov    -0x10(%rax),%rsi
     655:	bt     $0x3e,%rsi
     65a:	jb     66c <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x3c>
     65c:	test   $0x2,%sil
     660:	jne    680 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x50>
     662:	mov    -0x20(%rax),%rsi
     666:	cmp    $0xfffffffffffffffd,%rsi
     66a:	jbe    679 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x49>
     66c:	mov    0x0(%rip),%rsi        # 673 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x43>
     673:	pop    %rbp
     674:	jmp    679 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_retain+0x49>
     679:	inc    %rsi
     67c:	mov    %rsi,-0x20(%rax)
     680:	vmovups (%rcx),%xmm0
     684:	vmovups %xmm0,(%rdx)
     688:	mov    $0x1,%eax
     68d:	pop    %rbp
     68e:	ret
     68f:	nop

0000000000000690 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take>:
     690:	push   %rbp
     691:	mov    %rsp,%rbp
     694:	mov    %ecx,%r8d
     697:	mov    %rdx,%rcx
     69a:	mov    %rsi,%rdx
     69d:	mov    (%rcx),%eax
     69f:	cmp    $0x1,%eax
     6a2:	je     6a8 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x18>
     6a4:	test   %eax,%eax
     6a6:	jne    6b7 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x27>
     6a8:	mov    0x8(%rcx),%rax
     6ac:	test   %rax,%rax
     6af:	je     6b7 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x27>
     6b1:	testb  $0x50,-0x9(%rax)
     6b5:	jne    6e4 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x54>
     6b7:	mov    %rdx,%rax
     6ba:	sub    %rcx,%rax
     6bd:	mov    %rcx,%rsi
     6c0:	sub    %rdx,%rsi
     6c3:	cmovb  %rax,%rsi
     6c7:	cmp    $0xf,%rsi
     6cb:	jbe    6e4 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x54>
     6cd:	vmovups (%rcx),%xmm0
     6d1:	vmovups %xmm0,(%rdx)
     6d5:	vxorps %xmm0,%xmm0,%xmm0
     6d9:	vmovups %xmm0,(%rcx)
     6dd:	mov    $0x1,%eax
     6e2:	pop    %rbp
     6e3:	ret
     6e4:	mov    0x0(%rip),%rsi        # 6eb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x5b>
     6eb:	pop    %rbp
     6ec:	jmp    6f1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_take+0x61>
     6f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000700 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish>:
     700:	push   %rbp
     701:	mov    %rsp,%rbp
     704:	push   %r15
     706:	push   %r14
     708:	push   %r13
     70a:	push   %r12
     70c:	push   %rbx
     70d:	push   %rax
     70e:	mov    %r8d,%r14d
     711:	mov    %ecx,%r8d
     714:	mov    %rdx,%r15
     717:	mov    %rsi,%rbx
     71a:	mov    (%rdx),%eax
     71c:	mov    $0x1,%cl
     71e:	cmp    $0x1,%eax
     721:	je     727 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x27>
     723:	test   %eax,%eax
     725:	jne    737 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x37>
     727:	mov    0x8(%r15),%rdx
     72b:	test   %rdx,%rdx
     72e:	je     737 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x37>
     730:	testb  $0x50,-0x9(%rdx)
     734:	sete   %cl
     737:	test   $0x3,%r14b
     73b:	jne    786 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x86>
     73d:	test   %cl,%cl
     73f:	je     786 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x86>
     741:	mov    %rbx,%rcx
     744:	sub    %r15,%rcx
     747:	mov    %r15,%rdx
     74a:	sub    %rbx,%rdx
     74d:	cmovb  %rcx,%rdx
     751:	cmp    $0xf,%rdx
     755:	jbe    786 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x86>
     757:	test   $0x4,%r14b
     75b:	jne    7a9 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xa9>
     75d:	cmp    $0x1,%eax
     760:	je     766 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x66>
     762:	test   %eax,%eax
     764:	jne    7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     766:	mov    0x8(%r15),%rcx
     76a:	test   %rcx,%rcx
     76d:	je     7b2 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xb2>
     76f:	movabs $0x4000000000000002,%rdx
     779:	test   %rdx,-0x10(%rcx)
     77d:	jne    7b2 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xb2>
     77f:	cmpq   $0xfffffffffffffffe,-0x20(%rcx)
     784:	jb     7a9 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xa9>
     786:	mov    0x0(%rip),%rsi        # 78d <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x8d>
     78d:	mov    %rbx,%rdx
     790:	mov    %r15,%rcx
     793:	mov    %r14d,%r9d
     796:	add    $0x8,%rsp
     79a:	pop    %rbx
     79b:	pop    %r12
     79d:	pop    %r13
     79f:	pop    %r14
     7a1:	pop    %r15
     7a3:	pop    %rbp
     7a4:	jmp    7a9 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xa9>
     7a9:	cmp    $0x1,%eax
     7ac:	je     7b2 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xb2>
     7ae:	test   %eax,%eax
     7b0:	jne    7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     7b2:	mov    0x8(%r15),%r12
     7b6:	test   %r12,%r12
     7b9:	je     7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     7bb:	movabs $0x2000000000000000,%r13
     7c5:	lea    0x2(%r13),%rax
     7c9:	test   %rax,-0x10(%r12)
     7ce:	jne    7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     7d0:	mov    %r12,%rdi
     7d3:	call   7d8 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xd8>
     7d8:	test   %eax,%eax
     7da:	je     7e1 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xe1>
     7dc:	or     %r13,-0x10(%r12)
     7e1:	vmovups (%r15),%xmm0
     7e6:	vmovups %xmm0,(%rbx)
     7ea:	test   $0x4,%r14b
     7ee:	jne    81a <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x11a>
     7f0:	mov    (%rbx),%eax
     7f2:	cmp    $0x1,%eax
     7f5:	je     7fb <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0xfb>
     7f7:	test   %eax,%eax
     7f9:	jne    823 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x123>
     7fb:	mov    0x8(%rbx),%rax
     7ff:	test   %rax,%rax
     802:	je     823 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x123>
     804:	movabs $0x4000000000000002,%rcx
     80e:	test   %rcx,-0x10(%rax)
     812:	jne    823 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x123>
     814:	incq   -0x20(%rax)
     818:	jmp    823 <myl_t_09c8846278f428186ca0895241f7997dc6409b29b65b8af77066555a8059e500_rcg_publish+0x123>
     81a:	vxorps %xmm0,%xmm0,%xmm0
     81e:	vmovups %xmm0,(%r15)
     823:	mov    $0x1,%eax
     828:	add    $0x8,%rsp
     82c:	pop    %rbx
     82d:	pop    %r12
     82f:	pop    %r13
     831:	pop    %r14
     833:	pop    %r15
     835:	pop    %rbp
     836:	ret
     837:	nopw   0x0(%rax,%rax,1)

0000000000000840 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan>:
     840:	push   %rbp
     841:	mov    %rsp,%rbp
     844:	mov    %rdx,%rcx
     847:	mov    %rsi,%rdx
     84a:	mov    (%rcx),%rax
     84d:	test   %rax,%rax
     850:	je     876 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x36>
     852:	movabs $0x4000000000000002,%rsi
     85c:	test   %rsi,-0x10(%rax)
     860:	jne    876 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x36>
     862:	mov    -0x18(%rax),%rsi
     866:	cmp    $0xffffffffffffffff,%rsi
     86a:	je     880 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x40>
     86c:	inc    %rsi
     86f:	mov    %rsi,-0x18(%rax)
     873:	mov    (%rcx),%rax
     876:	mov    %rax,(%rdx)
     879:	mov    $0x1,%eax
     87e:	pop    %rbp
     87f:	ret
     880:	mov    0x0(%rip),%rsi        # 887 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x47>
     887:	pop    %rbp
     888:	jmp    88d <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan+0x4d>
     88d:	nopl   (%rax)

0000000000000890 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan>:
     890:	mov    (%rsi),%rax
     893:	movq   $0x0,(%rsi)
     89a:	test   %rax,%rax
     89d:	je     8af <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x1f>
     89f:	movabs $0x4000000000000002,%rcx
     8a9:	test   %rcx,-0x10(%rax)
     8ad:	je     8b7 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x27>
     8af:	movq   $0x0,(%rsi)
     8b6:	ret
     8b7:	mov    -0x18(%rax),%rcx
     8bb:	cmp    $0x1,%rcx
     8bf:	jne    8c8 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x38>
     8c1:	cmpq   $0x0,-0x20(%rax)
     8c6:	je     8d7 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x47>
     8c8:	dec    %rcx
     8cb:	mov    %rcx,-0x18(%rax)
     8cf:	movq   $0x0,(%rsi)
     8d6:	ret
     8d7:	push   %rbp
     8d8:	mov    %rsp,%rbp
     8db:	push   %r14
     8dd:	push   %rbx
     8de:	mov    %rdi,%rbx
     8e1:	mov    %rsi,%r14
     8e4:	mov    %rax,%rsi
     8e7:	call   8ec <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x5c>
     8ec:	movq   $0x0,(%r14)
     8f3:	mov    %rbx,%rdi
     8f6:	pop    %rbx
     8f7:	pop    %r14
     8f9:	pop    %rbp
     8fa:	jmp    8ff <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan+0x6f>
     8ff:	nop

0000000000000900 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop>:
     900:	mov    (%rsi),%rax
     903:	movq   $0x0,(%rsi)
     90a:	test   %rax,%rax
     90d:	je     91f <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x1f>
     90f:	movabs $0x4000000000000002,%rcx
     919:	test   %rcx,-0x10(%rax)
     91d:	je     927 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x27>
     91f:	movq   $0x0,(%rsi)
     926:	ret
     927:	mov    -0x20(%rax),%rcx
     92b:	cmp    $0x1,%rcx
     92f:	jne    938 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x38>
     931:	cmpq   $0x0,-0x18(%rax)
     936:	je     947 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x47>
     938:	dec    %rcx
     93b:	mov    %rcx,-0x20(%rax)
     93f:	movq   $0x0,(%rsi)
     946:	ret
     947:	push   %rbp
     948:	mov    %rsp,%rbp
     94b:	push   %r14
     94d:	push   %rbx
     94e:	mov    %rdi,%rbx
     951:	mov    %rsi,%r14
     954:	mov    %rax,%rsi
     957:	call   95c <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x5c>
     95c:	movq   $0x0,(%r14)
     963:	mov    %rbx,%rdi
     966:	pop    %rbx
     967:	pop    %r14
     969:	pop    %rbp
     96a:	jmp    96f <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop+0x6f>
     96f:	nop

0000000000000970 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain>:
     970:	push   %rbp
     971:	mov    %rsp,%rbp
     974:	mov    %ecx,%r8d
     977:	mov    %rdx,%rcx
     97a:	mov    %rsi,%rdx
     97d:	mov    (%rcx),%rax
     980:	test   %rax,%rax
     983:	je     9aa <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x3a>
     985:	mov    -0x10(%rax),%rsi
     989:	bt     $0x3e,%rsi
     98e:	jb     9b4 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x44>
     990:	test   $0x2,%sil
     994:	jne    9aa <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x3a>
     996:	mov    -0x20(%rax),%rsi
     99a:	cmp    $0xffffffffffffffff,%rsi
     99e:	je     9b4 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x44>
     9a0:	inc    %rsi
     9a3:	mov    %rsi,-0x20(%rax)
     9a7:	mov    (%rcx),%rax
     9aa:	mov    %rax,(%rdx)
     9ad:	mov    $0x1,%eax
     9b2:	pop    %rbp
     9b3:	ret
     9b4:	mov    0x0(%rip),%rsi        # 9bb <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x4b>
     9bb:	pop    %rbp
     9bc:	jmp    9c1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain+0x51>
     9c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

00000000000009d0 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take>:
     9d0:	push   %rbp
     9d1:	mov    %rsp,%rbp
     9d4:	mov    %ecx,%r8d
     9d7:	mov    %rdx,%rcx
     9da:	mov    %rsi,%rdx
     9dd:	mov    (%rcx),%rax
     9e0:	test   %rax,%rax
     9e3:	je     9eb <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x1b>
     9e5:	testb  $0x50,-0x9(%rax)
     9e9:	jne    a12 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x42>
     9eb:	mov    %rdx,%rsi
     9ee:	sub    %rcx,%rsi
     9f1:	mov    %rcx,%r9
     9f4:	sub    %rdx,%r9
     9f7:	cmovb  %rsi,%r9
     9fb:	cmp    $0x7,%r9
     9ff:	jbe    a12 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x42>
     a01:	mov    %rax,(%rdx)
     a04:	movq   $0x0,(%rcx)
     a0b:	mov    $0x1,%eax
     a10:	pop    %rbp
     a11:	ret
     a12:	mov    0x0(%rip),%rsi        # a19 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x49>
     a19:	pop    %rbp
     a1a:	jmp    a1f <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take+0x4f>
     a1f:	nop

0000000000000a20 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish>:
     a20:	push   %rbp
     a21:	mov    %rsp,%rbp
     a24:	push   %r15
     a26:	push   %r14
     a28:	push   %r13
     a2a:	push   %r12
     a2c:	push   %rbx
     a2d:	push   %rax
     a2e:	mov    %r8d,%r9d
     a31:	mov    %ecx,%r8d
     a34:	mov    %rdx,%rbx
     a37:	mov    %rsi,%r14
     a3a:	mov    (%rdx),%r15
     a3d:	test   %r15,%r15
     a40:	je     a52 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x32>
     a42:	testb  $0x50,-0x9(%r15)
     a47:	sete   %al
     a4a:	test   $0x3,%r9b
     a4e:	je     a5a <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x3a>
     a50:	jmp    ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a52:	mov    $0x1,%al
     a54:	test   $0x3,%r9b
     a58:	jne    ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a5a:	test   %al,%al
     a5c:	je     ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a5e:	mov    %r14,%rax
     a61:	sub    %rbx,%rax
     a64:	mov    %rbx,%rcx
     a67:	sub    %r14,%rcx
     a6a:	cmovb  %rax,%rcx
     a6e:	cmp    $0x7,%rcx
     a72:	jbe    ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a74:	test   $0x4,%r9b
     a78:	jne    af1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xd1>
     a7a:	movabs $0x4000000000000002,%r12
     a84:	test   %r15,%r15
     a87:	je     aba <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x9a>
     a89:	test   %r12,-0x10(%r15)
     a8d:	jne    a96 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x76>
     a8f:	cmpq   $0xffffffffffffffff,-0x20(%r15)
     a94:	je     ad1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb1>
     a96:	movabs $0x2000000000000000,%r13
     aa0:	lea    0x2(%r13),%rax
     aa4:	test   %rax,-0x10(%r15)
     aa8:	jne    aba <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x9a>
     aaa:	mov    %r15,%rdi
     aad:	call   ab2 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x92>
     ab2:	test   %eax,%eax
     ab4:	je     aba <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x9a>
     ab6:	or     %r13,-0x10(%r15)
     aba:	mov    (%rbx),%rax
     abd:	mov    %rax,(%r14)
     ac0:	test   %rax,%rax
     ac3:	je     b28 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x108>
     ac5:	test   %r12,-0x10(%rax)
     ac9:	jne    b28 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x108>
     acb:	incq   -0x20(%rax)
     acf:	jmp    b28 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0x108>
     ad1:	mov    0x0(%rip),%rsi        # ad8 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xb8>
     ad8:	mov    %r14,%rdx
     adb:	mov    %rbx,%rcx
     ade:	add    $0x8,%rsp
     ae2:	pop    %rbx
     ae3:	pop    %r12
     ae5:	pop    %r13
     ae7:	pop    %r14
     ae9:	pop    %r15
     aeb:	pop    %rbp
     aec:	jmp    af1 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xd1>
     af1:	test   %r15,%r15
     af4:	je     b1b <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xfb>
     af6:	movabs $0x2000000000000000,%r12
     b00:	lea    0x2(%r12),%rax
     b05:	test   %rax,-0x10(%r15)
     b09:	jne    b1b <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xfb>
     b0b:	mov    %r15,%rdi
     b0e:	call   b13 <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xf3>
     b13:	test   %eax,%eax
     b15:	je     b1b <myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish+0xfb>
     b17:	or     %r12,-0x10(%r15)
     b1b:	mov    (%rbx),%rax
     b1e:	mov    %rax,(%r14)
     b21:	movq   $0x0,(%rbx)
     b28:	mov    $0x1,%eax
     b2d:	add    $0x8,%rsp
     b31:	pop    %rbx
     b32:	pop    %r12
     b34:	pop    %r13
     b36:	pop    %r14
     b38:	pop    %r15
     b3a:	pop    %rbp
     b3b:	ret
     b3c:	nopl   0x0(%rax)

0000000000000b40 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan>:
     b40:	push   %rbp
     b41:	mov    %rsp,%rbp
     b44:	mov    %rdx,%rcx
     b47:	mov    %rsi,%rdx
     b4a:	mov    (%rcx),%rax
     b4d:	test   %rax,%rax
     b50:	je     b76 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x36>
     b52:	movabs $0x4000000000000002,%rsi
     b5c:	test   %rsi,-0x10(%rax)
     b60:	jne    b76 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x36>
     b62:	mov    -0x18(%rax),%rsi
     b66:	cmp    $0xffffffffffffffff,%rsi
     b6a:	je     b80 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x40>
     b6c:	inc    %rsi
     b6f:	mov    %rsi,-0x18(%rax)
     b73:	mov    (%rcx),%rax
     b76:	mov    %rax,(%rdx)
     b79:	mov    $0x1,%eax
     b7e:	pop    %rbp
     b7f:	ret
     b80:	mov    0x0(%rip),%rsi        # b87 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x47>
     b87:	pop    %rbp
     b88:	jmp    b8d <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_loan+0x4d>
     b8d:	nopl   (%rax)

0000000000000b90 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan>:
     b90:	mov    (%rsi),%rax
     b93:	movq   $0x0,(%rsi)
     b9a:	test   %rax,%rax
     b9d:	je     baf <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x1f>
     b9f:	movabs $0x4000000000000002,%rcx
     ba9:	test   %rcx,-0x10(%rax)
     bad:	je     bb7 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x27>
     baf:	movq   $0x0,(%rsi)
     bb6:	ret
     bb7:	mov    -0x18(%rax),%rcx
     bbb:	cmp    $0x1,%rcx
     bbf:	jne    bc8 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x38>
     bc1:	cmpq   $0x0,-0x20(%rax)
     bc6:	je     bd7 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x47>
     bc8:	dec    %rcx
     bcb:	mov    %rcx,-0x18(%rax)
     bcf:	movq   $0x0,(%rsi)
     bd6:	ret
     bd7:	push   %rbp
     bd8:	mov    %rsp,%rbp
     bdb:	push   %r14
     bdd:	push   %rbx
     bde:	mov    %rdi,%rbx
     be1:	mov    %rsi,%r14
     be4:	mov    %rax,%rsi
     be7:	call   bec <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x5c>
     bec:	movq   $0x0,(%r14)
     bf3:	mov    %rbx,%rdi
     bf6:	pop    %rbx
     bf7:	pop    %r14
     bf9:	pop    %rbp
     bfa:	jmp    bff <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan+0x6f>
     bff:	nop

0000000000000c00 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop>:
     c00:	mov    (%rsi),%rax
     c03:	movq   $0x0,(%rsi)
     c0a:	test   %rax,%rax
     c0d:	je     c1f <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x1f>
     c0f:	movabs $0x4000000000000002,%rcx
     c19:	test   %rcx,-0x10(%rax)
     c1d:	je     c27 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x27>
     c1f:	movq   $0x0,(%rsi)
     c26:	ret
     c27:	mov    -0x20(%rax),%rcx
     c2b:	cmp    $0x1,%rcx
     c2f:	jne    c38 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x38>
     c31:	cmpq   $0x0,-0x18(%rax)
     c36:	je     c47 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x47>
     c38:	dec    %rcx
     c3b:	mov    %rcx,-0x20(%rax)
     c3f:	movq   $0x0,(%rsi)
     c46:	ret
     c47:	push   %rbp
     c48:	mov    %rsp,%rbp
     c4b:	push   %r14
     c4d:	push   %rbx
     c4e:	mov    %rdi,%rbx
     c51:	mov    %rsi,%r14
     c54:	mov    %rax,%rsi
     c57:	call   c5c <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x5c>
     c5c:	movq   $0x0,(%r14)
     c63:	mov    %rbx,%rdi
     c66:	pop    %rbx
     c67:	pop    %r14
     c69:	pop    %rbp
     c6a:	jmp    c6f <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop+0x6f>
     c6f:	nop

0000000000000c70 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain>:
     c70:	push   %rbp
     c71:	mov    %rsp,%rbp
     c74:	mov    %ecx,%r8d
     c77:	mov    %rdx,%rcx
     c7a:	mov    %rsi,%rdx
     c7d:	mov    (%rcx),%rax
     c80:	test   %rax,%rax
     c83:	je     caa <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x3a>
     c85:	mov    -0x10(%rax),%rsi
     c89:	bt     $0x3e,%rsi
     c8e:	jb     cb4 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x44>
     c90:	test   $0x2,%sil
     c94:	jne    caa <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x3a>
     c96:	mov    -0x20(%rax),%rsi
     c9a:	cmp    $0xffffffffffffffff,%rsi
     c9e:	je     cb4 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x44>
     ca0:	inc    %rsi
     ca3:	mov    %rsi,-0x20(%rax)
     ca7:	mov    (%rcx),%rax
     caa:	mov    %rax,(%rdx)
     cad:	mov    $0x1,%eax
     cb2:	pop    %rbp
     cb3:	ret
     cb4:	mov    0x0(%rip),%rsi        # cbb <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x4b>
     cbb:	pop    %rbp
     cbc:	jmp    cc1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain+0x51>
     cc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000cd0 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take>:
     cd0:	push   %rbp
     cd1:	mov    %rsp,%rbp
     cd4:	mov    %ecx,%r8d
     cd7:	mov    %rdx,%rcx
     cda:	mov    %rsi,%rdx
     cdd:	mov    (%rcx),%rax
     ce0:	test   %rax,%rax
     ce3:	je     ceb <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x1b>
     ce5:	testb  $0x50,-0x9(%rax)
     ce9:	jne    d12 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x42>
     ceb:	mov    %rdx,%rsi
     cee:	sub    %rcx,%rsi
     cf1:	mov    %rcx,%r9
     cf4:	sub    %rdx,%r9
     cf7:	cmovb  %rsi,%r9
     cfb:	cmp    $0x7,%r9
     cff:	jbe    d12 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x42>
     d01:	mov    %rax,(%rdx)
     d04:	movq   $0x0,(%rcx)
     d0b:	mov    $0x1,%eax
     d10:	pop    %rbp
     d11:	ret
     d12:	mov    0x0(%rip),%rsi        # d19 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x49>
     d19:	pop    %rbp
     d1a:	jmp    d1f <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take+0x4f>
     d1f:	nop

0000000000000d20 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish>:
     d20:	push   %rbp
     d21:	mov    %rsp,%rbp
     d24:	push   %r15
     d26:	push   %r14
     d28:	push   %r13
     d2a:	push   %r12
     d2c:	push   %rbx
     d2d:	push   %rax
     d2e:	mov    %r8d,%r9d
     d31:	mov    %ecx,%r8d
     d34:	mov    %rdx,%rbx
     d37:	mov    %rsi,%r14
     d3a:	mov    (%rdx),%r15
     d3d:	test   %r15,%r15
     d40:	je     d52 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x32>
     d42:	testb  $0x50,-0x9(%r15)
     d47:	sete   %al
     d4a:	test   $0x3,%r9b
     d4e:	je     d5a <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x3a>
     d50:	jmp    dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d52:	mov    $0x1,%al
     d54:	test   $0x3,%r9b
     d58:	jne    dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d5a:	test   %al,%al
     d5c:	je     dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d5e:	mov    %r14,%rax
     d61:	sub    %rbx,%rax
     d64:	mov    %rbx,%rcx
     d67:	sub    %r14,%rcx
     d6a:	cmovb  %rax,%rcx
     d6e:	cmp    $0x7,%rcx
     d72:	jbe    dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d74:	test   $0x4,%r9b
     d78:	jne    df1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xd1>
     d7a:	movabs $0x4000000000000002,%r12
     d84:	test   %r15,%r15
     d87:	je     dba <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x9a>
     d89:	test   %r12,-0x10(%r15)
     d8d:	jne    d96 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x76>
     d8f:	cmpq   $0xffffffffffffffff,-0x20(%r15)
     d94:	je     dd1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb1>
     d96:	movabs $0x2000000000000000,%r13
     da0:	lea    0x2(%r13),%rax
     da4:	test   %rax,-0x10(%r15)
     da8:	jne    dba <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x9a>
     daa:	mov    %r15,%rdi
     dad:	call   db2 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x92>
     db2:	test   %eax,%eax
     db4:	je     dba <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x9a>
     db6:	or     %r13,-0x10(%r15)
     dba:	mov    (%rbx),%rax
     dbd:	mov    %rax,(%r14)
     dc0:	test   %rax,%rax
     dc3:	je     e28 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x108>
     dc5:	test   %r12,-0x10(%rax)
     dc9:	jne    e28 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x108>
     dcb:	incq   -0x20(%rax)
     dcf:	jmp    e28 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0x108>
     dd1:	mov    0x0(%rip),%rsi        # dd8 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xb8>
     dd8:	mov    %r14,%rdx
     ddb:	mov    %rbx,%rcx
     dde:	add    $0x8,%rsp
     de2:	pop    %rbx
     de3:	pop    %r12
     de5:	pop    %r13
     de7:	pop    %r14
     de9:	pop    %r15
     deb:	pop    %rbp
     dec:	jmp    df1 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xd1>
     df1:	test   %r15,%r15
     df4:	je     e1b <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xfb>
     df6:	movabs $0x2000000000000000,%r12
     e00:	lea    0x2(%r12),%rax
     e05:	test   %rax,-0x10(%r15)
     e09:	jne    e1b <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xfb>
     e0b:	mov    %r15,%rdi
     e0e:	call   e13 <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xf3>
     e13:	test   %eax,%eax
     e15:	je     e1b <myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_publish+0xfb>
     e17:	or     %r12,-0x10(%r15)
     e1b:	mov    (%rbx),%rax
     e1e:	mov    %rax,(%r14)
     e21:	movq   $0x0,(%rbx)
     e28:	mov    $0x1,%eax
     e2d:	add    $0x8,%rsp
     e31:	pop    %rbx
     e32:	pop    %r12
     e34:	pop    %r13
     e36:	pop    %r14
     e38:	pop    %r15
     e3a:	pop    %rbp
     e3b:	ret
     e3c:	nopl   0x0(%rax)

0000000000000e40 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan>:
     e40:	push   %rbp
     e41:	mov    %rsp,%rbp
     e44:	mov    %rdx,%rcx
     e47:	mov    %rsi,%rdx
     e4a:	mov    (%rcx),%rax
     e4d:	test   %rax,%rax
     e50:	je     e76 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x36>
     e52:	movabs $0x4000000000000002,%rsi
     e5c:	test   %rsi,-0x10(%rax)
     e60:	jne    e76 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x36>
     e62:	mov    -0x18(%rax),%rsi
     e66:	cmp    $0xffffffffffffffff,%rsi
     e6a:	je     e80 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x40>
     e6c:	inc    %rsi
     e6f:	mov    %rsi,-0x18(%rax)
     e73:	mov    (%rcx),%rax
     e76:	mov    %rax,(%rdx)
     e79:	mov    $0x1,%eax
     e7e:	pop    %rbp
     e7f:	ret
     e80:	mov    0x0(%rip),%rsi        # e87 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x47>
     e87:	pop    %rbp
     e88:	jmp    e8d <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan+0x4d>
     e8d:	nopl   (%rax)

0000000000000e90 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan>:
     e90:	mov    (%rsi),%rax
     e93:	movq   $0x0,(%rsi)
     e9a:	test   %rax,%rax
     e9d:	je     eaf <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x1f>
     e9f:	movabs $0x4000000000000002,%rcx
     ea9:	test   %rcx,-0x10(%rax)
     ead:	je     eb7 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x27>
     eaf:	movq   $0x0,(%rsi)
     eb6:	ret
     eb7:	mov    -0x18(%rax),%rcx
     ebb:	cmp    $0x1,%rcx
     ebf:	jne    ec8 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x38>
     ec1:	cmpq   $0x0,-0x20(%rax)
     ec6:	je     ed7 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x47>
     ec8:	dec    %rcx
     ecb:	mov    %rcx,-0x18(%rax)
     ecf:	movq   $0x0,(%rsi)
     ed6:	ret
     ed7:	push   %rbp
     ed8:	mov    %rsp,%rbp
     edb:	push   %r14
     edd:	push   %rbx
     ede:	mov    %rdi,%rbx
     ee1:	mov    %rsi,%r14
     ee4:	mov    %rax,%rsi
     ee7:	call   eec <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x5c>
     eec:	movq   $0x0,(%r14)
     ef3:	mov    %rbx,%rdi
     ef6:	pop    %rbx
     ef7:	pop    %r14
     ef9:	pop    %rbp
     efa:	jmp    eff <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan+0x6f>
     eff:	nop

0000000000000f00 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop>:
     f00:	mov    (%rsi),%rax
     f03:	movq   $0x0,(%rsi)
     f0a:	test   %rax,%rax
     f0d:	je     f1f <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x1f>
     f0f:	movabs $0x4000000000000002,%rcx
     f19:	test   %rcx,-0x10(%rax)
     f1d:	je     f27 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x27>
     f1f:	movq   $0x0,(%rsi)
     f26:	ret
     f27:	mov    -0x20(%rax),%rcx
     f2b:	cmp    $0x1,%rcx
     f2f:	jne    f38 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x38>
     f31:	cmpq   $0x0,-0x18(%rax)
     f36:	je     f47 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x47>
     f38:	dec    %rcx
     f3b:	mov    %rcx,-0x20(%rax)
     f3f:	movq   $0x0,(%rsi)
     f46:	ret
     f47:	push   %rbp
     f48:	mov    %rsp,%rbp
     f4b:	push   %r14
     f4d:	push   %rbx
     f4e:	mov    %rdi,%rbx
     f51:	mov    %rsi,%r14
     f54:	mov    %rax,%rsi
     f57:	call   f5c <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x5c>
     f5c:	movq   $0x0,(%r14)
     f63:	mov    %rbx,%rdi
     f66:	pop    %rbx
     f67:	pop    %r14
     f69:	pop    %rbp
     f6a:	jmp    f6f <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop+0x6f>
     f6f:	nop

0000000000000f70 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain>:
     f70:	push   %rbp
     f71:	mov    %rsp,%rbp
     f74:	mov    %ecx,%r8d
     f77:	mov    %rdx,%rcx
     f7a:	mov    %rsi,%rdx
     f7d:	mov    (%rcx),%rax
     f80:	test   %rax,%rax
     f83:	je     faa <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x3a>
     f85:	mov    -0x10(%rax),%rsi
     f89:	bt     $0x3e,%rsi
     f8e:	jb     fb4 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x44>
     f90:	test   $0x2,%sil
     f94:	jne    faa <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x3a>
     f96:	mov    -0x20(%rax),%rsi
     f9a:	cmp    $0xffffffffffffffff,%rsi
     f9e:	je     fb4 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x44>
     fa0:	inc    %rsi
     fa3:	mov    %rsi,-0x20(%rax)
     fa7:	mov    (%rcx),%rax
     faa:	mov    %rax,(%rdx)
     fad:	mov    $0x1,%eax
     fb2:	pop    %rbp
     fb3:	ret
     fb4:	mov    0x0(%rip),%rsi        # fbb <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x4b>
     fbb:	pop    %rbp
     fbc:	jmp    fc1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain+0x51>
     fc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000000fd0 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take>:
     fd0:	push   %rbp
     fd1:	mov    %rsp,%rbp
     fd4:	mov    %ecx,%r8d
     fd7:	mov    %rdx,%rcx
     fda:	mov    %rsi,%rdx
     fdd:	mov    (%rcx),%rax
     fe0:	test   %rax,%rax
     fe3:	je     feb <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x1b>
     fe5:	testb  $0x50,-0x9(%rax)
     fe9:	jne    1012 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x42>
     feb:	mov    %rdx,%rsi
     fee:	sub    %rcx,%rsi
     ff1:	mov    %rcx,%r9
     ff4:	sub    %rdx,%r9
     ff7:	cmovb  %rsi,%r9
     ffb:	cmp    $0x7,%r9
     fff:	jbe    1012 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x42>
    1001:	mov    %rax,(%rdx)
    1004:	movq   $0x0,(%rcx)
    100b:	mov    $0x1,%eax
    1010:	pop    %rbp
    1011:	ret
    1012:	mov    0x0(%rip),%rsi        # 1019 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x49>
    1019:	pop    %rbp
    101a:	jmp    101f <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take+0x4f>
    101f:	nop

0000000000001020 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish>:
    1020:	push   %rbp
    1021:	mov    %rsp,%rbp
    1024:	push   %r15
    1026:	push   %r14
    1028:	push   %r13
    102a:	push   %r12
    102c:	push   %rbx
    102d:	push   %rax
    102e:	mov    %r8d,%r9d
    1031:	mov    %ecx,%r8d
    1034:	mov    %rdx,%rbx
    1037:	mov    %rsi,%r14
    103a:	mov    (%rdx),%r15
    103d:	test   %r15,%r15
    1040:	je     1052 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x32>
    1042:	testb  $0x50,-0x9(%r15)
    1047:	sete   %al
    104a:	test   $0x3,%r9b
    104e:	je     105a <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x3a>
    1050:	jmp    10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    1052:	mov    $0x1,%al
    1054:	test   $0x3,%r9b
    1058:	jne    10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    105a:	test   %al,%al
    105c:	je     10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    105e:	mov    %r14,%rax
    1061:	sub    %rbx,%rax
    1064:	mov    %rbx,%rcx
    1067:	sub    %r14,%rcx
    106a:	cmovb  %rax,%rcx
    106e:	cmp    $0x7,%rcx
    1072:	jbe    10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    1074:	test   $0x4,%r9b
    1078:	jne    10f1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xd1>
    107a:	movabs $0x4000000000000002,%r12
    1084:	test   %r15,%r15
    1087:	je     10ba <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x9a>
    1089:	test   %r12,-0x10(%r15)
    108d:	jne    1096 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x76>
    108f:	cmpq   $0xffffffffffffffff,-0x20(%r15)
    1094:	je     10d1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb1>
    1096:	movabs $0x2000000000000000,%r13
    10a0:	lea    0x2(%r13),%rax
    10a4:	test   %rax,-0x10(%r15)
    10a8:	jne    10ba <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x9a>
    10aa:	mov    %r15,%rdi
    10ad:	call   10b2 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x92>
    10b2:	test   %eax,%eax
    10b4:	je     10ba <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x9a>
    10b6:	or     %r13,-0x10(%r15)
    10ba:	mov    (%rbx),%rax
    10bd:	mov    %rax,(%r14)
    10c0:	test   %rax,%rax
    10c3:	je     1128 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x108>
    10c5:	test   %r12,-0x10(%rax)
    10c9:	jne    1128 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x108>
    10cb:	incq   -0x20(%rax)
    10cf:	jmp    1128 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0x108>
    10d1:	mov    0x0(%rip),%rsi        # 10d8 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xb8>
    10d8:	mov    %r14,%rdx
    10db:	mov    %rbx,%rcx
    10de:	add    $0x8,%rsp
    10e2:	pop    %rbx
    10e3:	pop    %r12
    10e5:	pop    %r13
    10e7:	pop    %r14
    10e9:	pop    %r15
    10eb:	pop    %rbp
    10ec:	jmp    10f1 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xd1>
    10f1:	test   %r15,%r15
    10f4:	je     111b <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xfb>
    10f6:	movabs $0x2000000000000000,%r12
    1100:	lea    0x2(%r12),%rax
    1105:	test   %rax,-0x10(%r15)
    1109:	jne    111b <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xfb>
    110b:	mov    %r15,%rdi
    110e:	call   1113 <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xf3>
    1113:	test   %eax,%eax
    1115:	je     111b <myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish+0xfb>
    1117:	or     %r12,-0x10(%r15)
    111b:	mov    (%rbx),%rax
    111e:	mov    %rax,(%r14)
    1121:	movq   $0x0,(%rbx)
    1128:	mov    $0x1,%eax
    112d:	add    $0x8,%rsp
    1131:	pop    %rbx
    1132:	pop    %r12
    1134:	pop    %r13
    1136:	pop    %r14
    1138:	pop    %r15
    113a:	pop    %rbp
    113b:	ret
    113c:	nopl   0x0(%rax)

0000000000001140 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan>:
    1140:	push   %rbp
    1141:	mov    %rsp,%rbp
    1144:	mov    %rdx,%rcx
    1147:	mov    %rsi,%rdx
    114a:	mov    (%rcx),%rax
    114d:	test   %rax,%rax
    1150:	je     1176 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x36>
    1152:	movabs $0x4000000000000002,%rsi
    115c:	test   %rsi,-0x10(%rax)
    1160:	jne    1176 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x36>
    1162:	mov    -0x18(%rax),%rsi
    1166:	cmp    $0xffffffffffffffff,%rsi
    116a:	je     1180 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x40>
    116c:	inc    %rsi
    116f:	mov    %rsi,-0x18(%rax)
    1173:	mov    (%rcx),%rax
    1176:	mov    %rax,(%rdx)
    1179:	mov    $0x1,%eax
    117e:	pop    %rbp
    117f:	ret
    1180:	mov    0x0(%rip),%rsi        # 1187 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x47>
    1187:	pop    %rbp
    1188:	jmp    118d <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan+0x4d>
    118d:	nopl   (%rax)

0000000000001190 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan>:
    1190:	mov    (%rsi),%rax
    1193:	movq   $0x0,(%rsi)
    119a:	test   %rax,%rax
    119d:	je     11af <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x1f>
    119f:	movabs $0x4000000000000002,%rcx
    11a9:	test   %rcx,-0x10(%rax)
    11ad:	je     11b7 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x27>
    11af:	movq   $0x0,(%rsi)
    11b6:	ret
    11b7:	mov    -0x18(%rax),%rcx
    11bb:	cmp    $0x1,%rcx
    11bf:	jne    11c8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x38>
    11c1:	cmpq   $0x0,-0x20(%rax)
    11c6:	je     11d7 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x47>
    11c8:	dec    %rcx
    11cb:	mov    %rcx,-0x18(%rax)
    11cf:	movq   $0x0,(%rsi)
    11d6:	ret
    11d7:	push   %rbp
    11d8:	mov    %rsp,%rbp
    11db:	push   %r14
    11dd:	push   %rbx
    11de:	mov    %rdi,%rbx
    11e1:	mov    %rsi,%r14
    11e4:	mov    %rax,%rsi
    11e7:	call   11ec <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x5c>
    11ec:	movq   $0x0,(%r14)
    11f3:	mov    %rbx,%rdi
    11f6:	pop    %rbx
    11f7:	pop    %r14
    11f9:	pop    %rbp
    11fa:	jmp    11ff <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan+0x6f>
    11ff:	nop

0000000000001200 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop>:
    1200:	mov    (%rsi),%rax
    1203:	movq   $0x0,(%rsi)
    120a:	test   %rax,%rax
    120d:	je     121f <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x1f>
    120f:	movabs $0x4000000000000002,%rcx
    1219:	test   %rcx,-0x10(%rax)
    121d:	je     1227 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x27>
    121f:	movq   $0x0,(%rsi)
    1226:	ret
    1227:	mov    -0x20(%rax),%rcx
    122b:	cmp    $0x1,%rcx
    122f:	jne    1238 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x38>
    1231:	cmpq   $0x0,-0x18(%rax)
    1236:	je     1247 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x47>
    1238:	dec    %rcx
    123b:	mov    %rcx,-0x20(%rax)
    123f:	movq   $0x0,(%rsi)
    1246:	ret
    1247:	push   %rbp
    1248:	mov    %rsp,%rbp
    124b:	push   %r14
    124d:	push   %rbx
    124e:	mov    %rdi,%rbx
    1251:	mov    %rsi,%r14
    1254:	mov    %rax,%rsi
    1257:	call   125c <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x5c>
    125c:	movq   $0x0,(%r14)
    1263:	mov    %rbx,%rdi
    1266:	pop    %rbx
    1267:	pop    %r14
    1269:	pop    %rbp
    126a:	jmp    126f <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop+0x6f>
    126f:	nop

0000000000001270 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain>:
    1270:	push   %rbp
    1271:	mov    %rsp,%rbp
    1274:	mov    (%rdx),%rax
    1277:	test   %rax,%rax
    127a:	je     12a1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x31>
    127c:	mov    -0x10(%rax),%r8
    1280:	bt     $0x3e,%r8
    1285:	jb     12ab <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x3b>
    1287:	test   $0x2,%r8b
    128b:	jne    12a1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x31>
    128d:	mov    -0x20(%rax),%r8
    1291:	cmp    $0xffffffffffffffff,%r8
    1295:	je     12ab <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x3b>
    1297:	inc    %r8
    129a:	mov    %r8,-0x20(%rax)
    129e:	mov    (%rdx),%rax
    12a1:	mov    %rax,(%rsi)
    12a4:	mov    $0x1,%eax
    12a9:	pop    %rbp
    12aa:	ret
    12ab:	pop    %rbp
    12ac:	jmp    12b1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain+0x41>
    12b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

00000000000012c0 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take>:
    12c0:	push   %rbp
    12c1:	mov    %rsp,%rbp
    12c4:	mov    %ecx,%r8d
    12c7:	mov    %rdx,%rcx
    12ca:	mov    %rsi,%rdx
    12cd:	mov    (%rcx),%rax
    12d0:	test   %rax,%rax
    12d3:	je     12db <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x1b>
    12d5:	testb  $0x50,-0x9(%rax)
    12d9:	jne    1302 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x42>
    12db:	mov    %rdx,%rsi
    12de:	sub    %rcx,%rsi
    12e1:	mov    %rcx,%r9
    12e4:	sub    %rdx,%r9
    12e7:	cmovb  %rsi,%r9
    12eb:	cmp    $0x7,%r9
    12ef:	jbe    1302 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x42>
    12f1:	mov    %rax,(%rdx)
    12f4:	movq   $0x0,(%rcx)
    12fb:	mov    $0x1,%eax
    1300:	pop    %rbp
    1301:	ret
    1302:	mov    0x0(%rip),%rsi        # 1309 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x49>
    1309:	pop    %rbp
    130a:	jmp    130f <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take+0x4f>
    130f:	nop

0000000000001310 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish>:
    1310:	push   %rbp
    1311:	mov    %rsp,%rbp
    1314:	push   %r15
    1316:	push   %r14
    1318:	push   %r13
    131a:	push   %r12
    131c:	push   %rbx
    131d:	push   %rax
    131e:	mov    %r8d,%r9d
    1321:	mov    %ecx,%r8d
    1324:	mov    %rdx,%rbx
    1327:	mov    %rsi,%r14
    132a:	mov    (%rdx),%r15
    132d:	test   %r15,%r15
    1330:	je     1342 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x32>
    1332:	testb  $0x50,-0x9(%r15)
    1337:	sete   %al
    133a:	test   $0x3,%r9b
    133e:	je     134a <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x3a>
    1340:	jmp    13c1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    1342:	mov    $0x1,%al
    1344:	test   $0x3,%r9b
    1348:	jne    13c1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    134a:	test   %al,%al
    134c:	je     13c1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    134e:	mov    %r14,%rax
    1351:	sub    %rbx,%rax
    1354:	mov    %rbx,%rcx
    1357:	sub    %r14,%rcx
    135a:	cmovb  %rax,%rcx
    135e:	cmp    $0x7,%rcx
    1362:	jbe    13c1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    1364:	test   $0x4,%r9b
    1368:	jne    13e1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xd1>
    136a:	movabs $0x4000000000000002,%r12
    1374:	test   %r15,%r15
    1377:	je     13aa <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x9a>
    1379:	test   %r12,-0x10(%r15)
    137d:	jne    1386 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x76>
    137f:	cmpq   $0xffffffffffffffff,-0x20(%r15)
    1384:	je     13c1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb1>
    1386:	movabs $0x2000000000000000,%r13
    1390:	lea    0x2(%r13),%rax
    1394:	test   %rax,-0x10(%r15)
    1398:	jne    13aa <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x9a>
    139a:	mov    %r15,%rdi
    139d:	call   13a2 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x92>
    13a2:	test   %eax,%eax
    13a4:	je     13aa <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x9a>
    13a6:	or     %r13,-0x10(%r15)
    13aa:	mov    (%rbx),%rax
    13ad:	mov    %rax,(%r14)
    13b0:	test   %rax,%rax
    13b3:	je     1418 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x108>
    13b5:	test   %r12,-0x10(%rax)
    13b9:	jne    1418 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x108>
    13bb:	incq   -0x20(%rax)
    13bf:	jmp    1418 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0x108>
    13c1:	mov    0x0(%rip),%rsi        # 13c8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xb8>
    13c8:	mov    %r14,%rdx
    13cb:	mov    %rbx,%rcx
    13ce:	add    $0x8,%rsp
    13d2:	pop    %rbx
    13d3:	pop    %r12
    13d5:	pop    %r13
    13d7:	pop    %r14
    13d9:	pop    %r15
    13db:	pop    %rbp
    13dc:	jmp    13e1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xd1>
    13e1:	test   %r15,%r15
    13e4:	je     140b <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xfb>
    13e6:	movabs $0x2000000000000000,%r12
    13f0:	lea    0x2(%r12),%rax
    13f5:	test   %rax,-0x10(%r15)
    13f9:	jne    140b <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xfb>
    13fb:	mov    %r15,%rdi
    13fe:	call   1403 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xf3>
    1403:	test   %eax,%eax
    1405:	je     140b <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish+0xfb>
    1407:	or     %r12,-0x10(%r15)
    140b:	mov    (%rbx),%rax
    140e:	mov    %rax,(%r14)
    1411:	movq   $0x0,(%rbx)
    1418:	mov    $0x1,%eax
    141d:	add    $0x8,%rsp
    1421:	pop    %rbx
    1422:	pop    %r12
    1424:	pop    %r13
    1426:	pop    %r14
    1428:	pop    %r15
    142a:	pop    %rbp
    142b:	ret
    142c:	nopl   0x0(%rax)

0000000000001430 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set>:
    1430:	xor    %eax,%eax
    1432:	cmp    (%rsi),%rdx
    1435:	jae    14e8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xb8>
    143b:	shl    $0x3,%rdx
    143f:	add    0x20(%rsi),%rdx
    1443:	cmp    %rcx,%rdx
    1446:	je     14e9 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xb9>
    144c:	push   %rbp
    144d:	mov    %rsp,%rbp
    1450:	push   %r15
    1452:	push   %r14
    1454:	push   %rbx
    1455:	push   %rax
    1456:	movabs $0x4000000000000000,%rbx
    1460:	mov    -0x10(%rsi),%rsi
    1464:	mov    %rsi,%r8
    1467:	shr    $0x28,%r8
    146b:	and    $0xfffff,%r8d
    1472:	xor    %eax,%eax
    1474:	bt     $0x3e,%rsi
    1479:	cmovb  %r8d,%eax
    147d:	mov    (%rcx),%r8
    1480:	test   %r8,%r8
    1483:	je     14a8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0x78>
    1485:	mov    -0x10(%r8),%rsi
    1489:	test   %rbx,%rsi
    148c:	jne    14ef <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xbf>
    148e:	test   $0x2,%sil
    1492:	jne    14a8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0x78>
    1494:	mov    -0x20(%r8),%rsi
    1498:	cmp    $0xffffffffffffffff,%rsi
    149c:	je     14ef <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xbf>
    149e:	inc    %rsi
    14a1:	mov    %rsi,-0x20(%r8)
    14a5:	mov    (%rcx),%r8
    14a8:	mov    %r8,-0x20(%rbp)
    14ac:	mov    (%rdx),%rsi
    14af:	mov    %r8,(%rdx)
    14b2:	mov    $0x1,%eax
    14b7:	test   %rsi,%rsi
    14ba:	je     14de <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xae>
    14bc:	add    $0x2,%rbx
    14c0:	test   %rbx,-0x10(%rsi)
    14c4:	jne    14de <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xae>
    14c6:	mov    -0x20(%rsi),%rcx
    14ca:	cmp    $0x1,%rcx
    14ce:	jne    14d7 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xa7>
    14d0:	cmpq   $0x0,-0x18(%rsi)
    14d5:	je     1513 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xe3>
    14d7:	dec    %rcx
    14da:	mov    %rcx,-0x20(%rsi)
    14de:	add    $0x8,%rsp
    14e2:	pop    %rbx
    14e3:	pop    %r14
    14e5:	pop    %r15
    14e7:	pop    %rbp
    14e8:	ret
    14e9:	mov    $0x1,%eax
    14ee:	ret
    14ef:	mov    %rdx,%r14
    14f2:	lea    -0x20(%rbp),%rsi
    14f6:	mov    %rdi,%r15
    14f9:	mov    %rcx,%rdx
    14fc:	mov    %eax,%ecx
    14fe:	call   1503 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xd3>
    1503:	test   %eax,%eax
    1505:	je     152a <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xfa>
    1507:	mov    -0x20(%rbp),%r8
    150b:	mov    %r15,%rdi
    150e:	mov    %r14,%rdx
    1511:	jmp    14ac <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0x7c>
    1513:	mov    %rdi,%rbx
    1516:	call   151b <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xeb>
    151b:	mov    %rbx,%rdi
    151e:	call   1523 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xf3>
    1523:	mov    $0x1,%eax
    1528:	jmp    14de <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xae>
    152a:	xor    %eax,%eax
    152c:	jmp    14de <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_set+0xae>
    152e:	xchg   %ax,%ax

0000000000001530 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append>:
    1530:	push   %rbp
    1531:	mov    %rsp,%rbp
    1534:	push   %r14
    1536:	push   %rbx
    1537:	mov    (%rsi),%rbx
    153a:	cmp    0x8(%rsi),%rbx
    153e:	jae    155e <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x2e>
    1540:	cmpq   $0xffffffffffffffff,0x10(%rsi)
    1545:	je     155e <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x2e>
    1547:	mov    0x20(%rsi),%rax
    154b:	mov    %rdx,%rcx
    154e:	sub    %rax,%rcx
    1551:	lea    0x0(,%rbx,8),%r8
    1559:	cmp    %r8,%rcx
    155c:	jae    1567 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x37>
    155e:	pop    %rbx
    155f:	pop    %r14
    1561:	pop    %rbp
    1562:	jmp    1567 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x37>
    1567:	mov    -0x10(%rsi),%r9
    156b:	mov    %r9,%r10
    156e:	shr    $0x28,%r10
    1572:	and    $0xfffff,%r10d
    1579:	xor    %ecx,%ecx
    157b:	bt     $0x3e,%r9
    1580:	cmovb  %r10d,%ecx
    1584:	mov    (%rdx),%r9
    1587:	test   %r9,%r9
    158a:	je     15b9 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x89>
    158c:	movabs $0x4000000000000000,%r11
    1596:	mov    -0x10(%r9),%r10
    159a:	test   %r11,%r10
    159d:	jne    15d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xa1>
    159f:	test   $0x2,%r10b
    15a3:	jne    15b9 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x89>
    15a5:	mov    -0x20(%r9),%r10
    15a9:	cmp    $0xffffffffffffffff,%r10
    15ad:	je     15d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xa1>
    15af:	inc    %r10
    15b2:	mov    %r10,-0x20(%r9)
    15b6:	mov    (%rdx),%r9
    15b9:	mov    %r9,(%rax,%r8,1)
    15bd:	inc    %rbx
    15c0:	mov    %rbx,(%rsi)
    15c3:	incq   0x10(%rsi)
    15c7:	mov    $0x1,%eax
    15cc:	pop    %rbx
    15cd:	pop    %r14
    15cf:	pop    %rbp
    15d0:	ret
    15d1:	add    %r8,%rax
    15d4:	mov    %rsi,%r14
    15d7:	mov    %rax,%rsi
    15da:	call   15df <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xaf>
    15df:	mov    %r14,%rsi
    15e2:	test   %eax,%eax
    15e4:	jne    15bd <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x8d>
    15e6:	xor    %eax,%eax
    15e8:	jmp    15cc <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x9c>
    15ea:	nopw   0x0(%rax,%rax,1)

00000000000015f0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan>:
    15f0:	push   %rbp
    15f1:	mov    %rsp,%rbp
    15f4:	mov    %rdx,%rcx
    15f7:	mov    %rsi,%rdx
    15fa:	mov    (%rcx),%eax
    15fc:	cmp    $0x1,%eax
    15ff:	je     1605 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x15>
    1601:	test   %eax,%eax
    1603:	jne    163c <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x4c>
    1605:	mov    0x8(%rcx),%rax
    1609:	test   %rax,%rax
    160c:	je     163c <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x4c>
    160e:	movabs $0x4000000000000002,%rsi
    1618:	test   %rsi,-0x10(%rax)
    161c:	jne    163c <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x4c>
    161e:	mov    -0x18(%rax),%rsi
    1622:	cmp    $0xfffffffffffffffd,%rsi
    1626:	jbe    1635 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x45>
    1628:	mov    0x0(%rip),%rsi        # 162f <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x3f>
    162f:	pop    %rbp
    1630:	jmp    1635 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_loan+0x45>
    1635:	inc    %rsi
    1638:	mov    %rsi,-0x18(%rax)
    163c:	vmovups (%rcx),%xmm0
    1640:	vmovups %xmm0,(%rdx)
    1644:	mov    $0x1,%eax
    1649:	pop    %rbp
    164a:	ret
    164b:	nopl   0x0(%rax,%rax,1)

0000000000001650 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan>:
    1650:	push   %rbp
    1651:	mov    %rsp,%rbp
    1654:	push   %r14
    1656:	push   %rbx
    1657:	mov    (%rsi),%eax
    1659:	cmp    $0x1,%eax
    165c:	je     1662 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x12>
    165e:	test   %eax,%eax
    1660:	jne    169b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x4b>
    1662:	mov    0x8(%rsi),%rax
    1666:	movq   $0x0,0x8(%rsi)
    166e:	test   %rax,%rax
    1671:	je     169b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x4b>
    1673:	movabs $0x4000000000000002,%rcx
    167d:	test   %rcx,-0x10(%rax)
    1681:	jne    169b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x4b>
    1683:	mov    -0x18(%rax),%rcx
    1687:	cmp    $0x1,%rcx
    168b:	jne    1694 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x44>
    168d:	cmpq   $0x0,-0x20(%rax)
    1692:	je     16a8 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x58>
    1694:	dec    %rcx
    1697:	mov    %rcx,-0x18(%rax)
    169b:	vxorps %xmm0,%xmm0,%xmm0
    169f:	vmovups %xmm0,(%rsi)
    16a3:	pop    %rbx
    16a4:	pop    %r14
    16a6:	pop    %rbp
    16a7:	ret
    16a8:	mov    %rsi,%r14
    16ab:	mov    %rdi,%rbx
    16ae:	mov    %rax,%rsi
    16b1:	call   16b6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x66>
    16b6:	vxorps %xmm0,%xmm0,%xmm0
    16ba:	vmovups %xmm0,(%r14)
    16bf:	mov    %rbx,%rdi
    16c2:	pop    %rbx
    16c3:	pop    %r14
    16c5:	pop    %rbp
    16c6:	jmp    16cb <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_unloan+0x7b>
    16cb:	nopl   0x0(%rax,%rax,1)

00000000000016d0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop>:
    16d0:	push   %rbp
    16d1:	mov    %rsp,%rbp
    16d4:	push   %r14
    16d6:	push   %rbx
    16d7:	mov    (%rsi),%eax
    16d9:	cmp    $0x1,%eax
    16dc:	je     16e2 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x12>
    16de:	test   %eax,%eax
    16e0:	jne    171b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x4b>
    16e2:	mov    0x8(%rsi),%rax
    16e6:	movq   $0x0,0x8(%rsi)
    16ee:	test   %rax,%rax
    16f1:	je     171b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x4b>
    16f3:	movabs $0x4000000000000002,%rcx
    16fd:	test   %rcx,-0x10(%rax)
    1701:	jne    171b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x4b>
    1703:	mov    -0x20(%rax),%rcx
    1707:	cmp    $0x1,%rcx
    170b:	jne    1714 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x44>
    170d:	cmpq   $0x0,-0x18(%rax)
    1712:	je     1728 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x58>
    1714:	dec    %rcx
    1717:	mov    %rcx,-0x20(%rax)
    171b:	vxorps %xmm0,%xmm0,%xmm0
    171f:	vmovups %xmm0,(%rsi)
    1723:	pop    %rbx
    1724:	pop    %r14
    1726:	pop    %rbp
    1727:	ret
    1728:	mov    %rsi,%r14
    172b:	mov    %rdi,%rbx
    172e:	mov    %rax,%rsi
    1731:	call   1736 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x66>
    1736:	vxorps %xmm0,%xmm0,%xmm0
    173a:	vmovups %xmm0,(%r14)
    173f:	mov    %rbx,%rdi
    1742:	pop    %rbx
    1743:	pop    %r14
    1745:	pop    %rbp
    1746:	jmp    174b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_drop+0x7b>
    174b:	nopl   0x0(%rax,%rax,1)

0000000000001750 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain>:
    1750:	push   %rbp
    1751:	mov    %rsp,%rbp
    1754:	mov    %ecx,%r8d
    1757:	mov    %rdx,%rcx
    175a:	mov    %rsi,%rdx
    175d:	mov    (%rcx),%eax
    175f:	cmp    $0x1,%eax
    1762:	je     1768 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x18>
    1764:	test   %eax,%eax
    1766:	jne    17a0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x50>
    1768:	mov    0x8(%rcx),%rax
    176c:	test   %rax,%rax
    176f:	je     17a0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x50>
    1771:	mov    -0x10(%rax),%rsi
    1775:	bt     $0x3e,%rsi
    177a:	jb     178c <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x3c>
    177c:	test   $0x2,%sil
    1780:	jne    17a0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x50>
    1782:	mov    -0x20(%rax),%rsi
    1786:	cmp    $0xfffffffffffffffd,%rsi
    178a:	jbe    1799 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x49>
    178c:	mov    0x0(%rip),%rsi        # 1793 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x43>
    1793:	pop    %rbp
    1794:	jmp    1799 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_retain+0x49>
    1799:	inc    %rsi
    179c:	mov    %rsi,-0x20(%rax)
    17a0:	vmovups (%rcx),%xmm0
    17a4:	vmovups %xmm0,(%rdx)
    17a8:	mov    $0x1,%eax
    17ad:	pop    %rbp
    17ae:	ret
    17af:	nop

00000000000017b0 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take>:
    17b0:	push   %rbp
    17b1:	mov    %rsp,%rbp
    17b4:	mov    %ecx,%r8d
    17b7:	mov    %rdx,%rcx
    17ba:	mov    %rsi,%rdx
    17bd:	mov    (%rcx),%eax
    17bf:	cmp    $0x1,%eax
    17c2:	je     17c8 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x18>
    17c4:	test   %eax,%eax
    17c6:	jne    17d7 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x27>
    17c8:	mov    0x8(%rcx),%rax
    17cc:	test   %rax,%rax
    17cf:	je     17d7 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x27>
    17d1:	testb  $0x50,-0x9(%rax)
    17d5:	jne    1804 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x54>
    17d7:	mov    %rdx,%rax
    17da:	sub    %rcx,%rax
    17dd:	mov    %rcx,%rsi
    17e0:	sub    %rdx,%rsi
    17e3:	cmovb  %rax,%rsi
    17e7:	cmp    $0xf,%rsi
    17eb:	jbe    1804 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x54>
    17ed:	vmovups (%rcx),%xmm0
    17f1:	vmovups %xmm0,(%rdx)
    17f5:	vxorps %xmm0,%xmm0,%xmm0
    17f9:	vmovups %xmm0,(%rcx)
    17fd:	mov    $0x1,%eax
    1802:	pop    %rbp
    1803:	ret
    1804:	mov    0x0(%rip),%rsi        # 180b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x5b>
    180b:	pop    %rbp
    180c:	jmp    1811 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_take+0x61>
    1811:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000001820 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish>:
    1820:	push   %rbp
    1821:	mov    %rsp,%rbp
    1824:	push   %r15
    1826:	push   %r14
    1828:	push   %r13
    182a:	push   %r12
    182c:	push   %rbx
    182d:	push   %rax
    182e:	mov    %r8d,%r14d
    1831:	mov    %ecx,%r8d
    1834:	mov    %rdx,%r15
    1837:	mov    %rsi,%rbx
    183a:	mov    (%rdx),%eax
    183c:	mov    $0x1,%cl
    183e:	cmp    $0x1,%eax
    1841:	je     1847 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x27>
    1843:	test   %eax,%eax
    1845:	jne    1857 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x37>
    1847:	mov    0x8(%r15),%rdx
    184b:	test   %rdx,%rdx
    184e:	je     1857 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x37>
    1850:	testb  $0x50,-0x9(%rdx)
    1854:	sete   %cl
    1857:	test   $0x3,%r14b
    185b:	jne    18a6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x86>
    185d:	test   %cl,%cl
    185f:	je     18a6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x86>
    1861:	mov    %rbx,%rcx
    1864:	sub    %r15,%rcx
    1867:	mov    %r15,%rdx
    186a:	sub    %rbx,%rdx
    186d:	cmovb  %rcx,%rdx
    1871:	cmp    $0xf,%rdx
    1875:	jbe    18a6 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x86>
    1877:	test   $0x4,%r14b
    187b:	jne    18c9 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xa9>
    187d:	cmp    $0x1,%eax
    1880:	je     1886 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x66>
    1882:	test   %eax,%eax
    1884:	jne    1901 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    1886:	mov    0x8(%r15),%rcx
    188a:	test   %rcx,%rcx
    188d:	je     18d2 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xb2>
    188f:	movabs $0x4000000000000002,%rdx
    1899:	test   %rdx,-0x10(%rcx)
    189d:	jne    18d2 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xb2>
    189f:	cmpq   $0xfffffffffffffffe,-0x20(%rcx)
    18a4:	jb     18c9 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xa9>
    18a6:	mov    0x0(%rip),%rsi        # 18ad <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x8d>
    18ad:	mov    %rbx,%rdx
    18b0:	mov    %r15,%rcx
    18b3:	mov    %r14d,%r9d
    18b6:	add    $0x8,%rsp
    18ba:	pop    %rbx
    18bb:	pop    %r12
    18bd:	pop    %r13
    18bf:	pop    %r14
    18c1:	pop    %r15
    18c3:	pop    %rbp
    18c4:	jmp    18c9 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xa9>
    18c9:	cmp    $0x1,%eax
    18cc:	je     18d2 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xb2>
    18ce:	test   %eax,%eax
    18d0:	jne    1901 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    18d2:	mov    0x8(%r15),%r12
    18d6:	test   %r12,%r12
    18d9:	je     1901 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    18db:	movabs $0x2000000000000000,%r13
    18e5:	lea    0x2(%r13),%rax
    18e9:	test   %rax,-0x10(%r12)
    18ee:	jne    1901 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    18f0:	mov    %r12,%rdi
    18f3:	call   18f8 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xd8>
    18f8:	test   %eax,%eax
    18fa:	je     1901 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xe1>
    18fc:	or     %r13,-0x10(%r12)
    1901:	vmovups (%r15),%xmm0
    1906:	vmovups %xmm0,(%rbx)
    190a:	test   $0x4,%r14b
    190e:	jne    193a <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x11a>
    1910:	mov    (%rbx),%eax
    1912:	cmp    $0x1,%eax
    1915:	je     191b <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0xfb>
    1917:	test   %eax,%eax
    1919:	jne    1943 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x123>
    191b:	mov    0x8(%rbx),%rax
    191f:	test   %rax,%rax
    1922:	je     1943 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x123>
    1924:	movabs $0x4000000000000002,%rcx
    192e:	test   %rcx,-0x10(%rax)
    1932:	jne    1943 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x123>
    1934:	incq   -0x20(%rax)
    1938:	jmp    1943 <myl_t_d912b2c7523602ef47ce18873793b215b2d37090ae0fe8136bfe10f3b56851ea_rcg_publish+0x123>
    193a:	vxorps %xmm0,%xmm0,%xmm0
    193e:	vmovups %xmm0,(%r15)
    1943:	mov    $0x1,%eax
    1948:	add    $0x8,%rsp
    194c:	pop    %rbx
    194d:	pop    %r12
    194f:	pop    %r13
    1951:	pop    %r14
    1953:	pop    %r15
    1955:	pop    %rbp
    1956:	ret
    1957:	nopw   0x0(%rax,%rax,1)

0000000000001960 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan>:
    1960:	push   %rbp
    1961:	mov    %rsp,%rbp
    1964:	mov    %rdx,%rcx
    1967:	mov    %rsi,%rdx
    196a:	cmpl   $0x1,(%rcx)
    196d:	jne    19a6 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x46>
    196f:	mov    0x8(%rcx),%rax
    1973:	test   %rax,%rax
    1976:	je     19a6 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x46>
    1978:	movabs $0x4000000000000002,%rsi
    1982:	test   %rsi,-0x10(%rax)
    1986:	jne    19a6 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x46>
    1988:	mov    -0x18(%rax),%rsi
    198c:	cmp    $0xfffffffffffffffd,%rsi
    1990:	jbe    199f <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x3f>
    1992:	mov    0x0(%rip),%rsi        # 1999 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x39>
    1999:	pop    %rbp
    199a:	jmp    199f <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_loan+0x3f>
    199f:	inc    %rsi
    19a2:	mov    %rsi,-0x18(%rax)
    19a6:	vmovups (%rcx),%xmm0
    19aa:	vmovups %xmm0,(%rdx)
    19ae:	mov    $0x1,%eax
    19b3:	pop    %rbp
    19b4:	ret
    19b5:	data16 cs nopw 0x0(%rax,%rax,1)

00000000000019c0 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan>:
    19c0:	cmpl   $0x1,(%rsi)
    19c3:	jne    19fe <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x3e>
    19c5:	mov    0x8(%rsi),%rax
    19c9:	movq   $0x0,0x8(%rsi)
    19d1:	test   %rax,%rax
    19d4:	je     19fe <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x3e>
    19d6:	movabs $0x4000000000000002,%rcx
    19e0:	test   %rcx,-0x10(%rax)
    19e4:	jne    19fe <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x3e>
    19e6:	mov    -0x18(%rax),%rcx
    19ea:	cmp    $0x1,%rcx
    19ee:	jne    19f7 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x37>
    19f0:	cmpq   $0x0,-0x20(%rax)
    19f5:	je     1a07 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x47>
    19f7:	dec    %rcx
    19fa:	mov    %rcx,-0x18(%rax)
    19fe:	vxorps %xmm0,%xmm0,%xmm0
    1a02:	vmovups %xmm0,(%rsi)
    1a06:	ret
    1a07:	push   %rbp
    1a08:	mov    %rsp,%rbp
    1a0b:	push   %r14
    1a0d:	push   %rbx
    1a0e:	mov    %rdi,%rbx
    1a11:	mov    %rsi,%r14
    1a14:	mov    %rax,%rsi
    1a17:	call   1a1c <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x5c>
    1a1c:	vxorps %xmm0,%xmm0,%xmm0
    1a20:	vmovups %xmm0,(%r14)
    1a25:	mov    %rbx,%rdi
    1a28:	pop    %rbx
    1a29:	pop    %r14
    1a2b:	pop    %rbp
    1a2c:	jmp    1a31 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_unloan+0x71>
    1a31:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000001a40 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop>:
    1a40:	cmpl   $0x1,(%rsi)
    1a43:	jne    1a7e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x3e>
    1a45:	mov    0x8(%rsi),%rax
    1a49:	movq   $0x0,0x8(%rsi)
    1a51:	test   %rax,%rax
    1a54:	je     1a7e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x3e>
    1a56:	movabs $0x4000000000000002,%rcx
    1a60:	test   %rcx,-0x10(%rax)
    1a64:	jne    1a7e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x3e>
    1a66:	mov    -0x20(%rax),%rcx
    1a6a:	cmp    $0x1,%rcx
    1a6e:	jne    1a77 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x37>
    1a70:	cmpq   $0x0,-0x18(%rax)
    1a75:	je     1a87 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x47>
    1a77:	dec    %rcx
    1a7a:	mov    %rcx,-0x20(%rax)
    1a7e:	vxorps %xmm0,%xmm0,%xmm0
    1a82:	vmovups %xmm0,(%rsi)
    1a86:	ret
    1a87:	push   %rbp
    1a88:	mov    %rsp,%rbp
    1a8b:	push   %r14
    1a8d:	push   %rbx
    1a8e:	mov    %rdi,%rbx
    1a91:	mov    %rsi,%r14
    1a94:	mov    %rax,%rsi
    1a97:	call   1a9c <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x5c>
    1a9c:	vxorps %xmm0,%xmm0,%xmm0
    1aa0:	vmovups %xmm0,(%r14)
    1aa5:	mov    %rbx,%rdi
    1aa8:	pop    %rbx
    1aa9:	pop    %r14
    1aab:	pop    %rbp
    1aac:	jmp    1ab1 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_drop+0x71>
    1ab1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000001ac0 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain>:
    1ac0:	push   %rbp
    1ac1:	mov    %rsp,%rbp
    1ac4:	mov    %ecx,%r8d
    1ac7:	mov    %rdx,%rcx
    1aca:	mov    %rsi,%rdx
    1acd:	cmpl   $0x1,(%rcx)
    1ad0:	jne    1b0a <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x4a>
    1ad2:	mov    0x8(%rcx),%rax
    1ad6:	test   %rax,%rax
    1ad9:	je     1b0a <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x4a>
    1adb:	mov    -0x10(%rax),%rsi
    1adf:	bt     $0x3e,%rsi
    1ae4:	jb     1af6 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x36>
    1ae6:	test   $0x2,%sil
    1aea:	jne    1b0a <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x4a>
    1aec:	mov    -0x20(%rax),%rsi
    1af0:	cmp    $0xfffffffffffffffd,%rsi
    1af4:	jbe    1b03 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x43>
    1af6:	mov    0x0(%rip),%rsi        # 1afd <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x3d>
    1afd:	pop    %rbp
    1afe:	jmp    1b03 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_retain+0x43>
    1b03:	inc    %rsi
    1b06:	mov    %rsi,-0x20(%rax)
    1b0a:	vmovups (%rcx),%xmm0
    1b0e:	vmovups %xmm0,(%rdx)
    1b12:	mov    $0x1,%eax
    1b17:	pop    %rbp
    1b18:	ret
    1b19:	nopl   0x0(%rax)

0000000000001b20 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take>:
    1b20:	push   %rbp
    1b21:	mov    %rsp,%rbp
    1b24:	mov    %ecx,%r8d
    1b27:	mov    %rdx,%rcx
    1b2a:	mov    %rsi,%rdx
    1b2d:	cmpl   $0x1,(%rcx)
    1b30:	jne    1b41 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x21>
    1b32:	mov    0x8(%rcx),%rax
    1b36:	test   %rax,%rax
    1b39:	je     1b41 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x21>
    1b3b:	testb  $0x50,-0x9(%rax)
    1b3f:	jne    1b6e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x4e>
    1b41:	mov    %rdx,%rax
    1b44:	sub    %rcx,%rax
    1b47:	mov    %rcx,%rsi
    1b4a:	sub    %rdx,%rsi
    1b4d:	cmovb  %rax,%rsi
    1b51:	cmp    $0xf,%rsi
    1b55:	jbe    1b6e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x4e>
    1b57:	vmovups (%rcx),%xmm0
    1b5b:	vmovups %xmm0,(%rdx)
    1b5f:	vxorps %xmm0,%xmm0,%xmm0
    1b63:	vmovups %xmm0,(%rcx)
    1b67:	mov    $0x1,%eax
    1b6c:	pop    %rbp
    1b6d:	ret
    1b6e:	mov    0x0(%rip),%rsi        # 1b75 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x55>
    1b75:	pop    %rbp
    1b76:	jmp    1b7b <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_take+0x5b>
    1b7b:	nopl   0x0(%rax,%rax,1)

0000000000001b80 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish>:
    1b80:	push   %rbp
    1b81:	mov    %rsp,%rbp
    1b84:	push   %r15
    1b86:	push   %r14
    1b88:	push   %r13
    1b8a:	push   %r12
    1b8c:	push   %rbx
    1b8d:	push   %rax
    1b8e:	mov    %r8d,%ebx
    1b91:	mov    %ecx,%r8d
    1b94:	mov    %rdx,%r15
    1b97:	mov    %rsi,%r14
    1b9a:	mov    (%rdx),%eax
    1b9c:	cmp    $0x1,%eax
    1b9f:	jne    1bb8 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x38>
    1ba1:	mov    0x8(%r15),%rcx
    1ba5:	test   %rcx,%rcx
    1ba8:	je     1bb8 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x38>
    1baa:	testb  $0x50,-0x9(%rcx)
    1bae:	setne  %cl
    1bb1:	test   $0x3,%bl
    1bb4:	je     1bbf <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x3f>
    1bb6:	jmp    1c0e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x8e>
    1bb8:	xor    %ecx,%ecx
    1bba:	test   $0x3,%bl
    1bbd:	jne    1c0e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x8e>
    1bbf:	test   %cl,%cl
    1bc1:	jne    1c0e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x8e>
    1bc3:	mov    %r14,%rcx
    1bc6:	sub    %r15,%rcx
    1bc9:	mov    %r15,%rdx
    1bcc:	sub    %r14,%rdx
    1bcf:	cmovb  %rcx,%rdx
    1bd3:	cmp    $0xf,%rdx
    1bd7:	jbe    1c0e <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x8e>
    1bd9:	mov    %eax,%ecx
    1bdb:	xor    $0x1,%ecx
    1bde:	mov    %ebx,%edx
    1be0:	and    $0x4,%edx
    1be3:	or     %ecx,%edx
    1be5:	je     1bee <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x6e>
    1be7:	cmp    $0x1,%eax
    1bea:	je     1c31 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1bec:	jmp    1c60 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xe0>
    1bee:	mov    0x8(%r15),%rax
    1bf2:	test   %rax,%rax
    1bf5:	je     1c31 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1bf7:	movabs $0x4000000000000002,%rcx
    1c01:	test   %rcx,-0x10(%rax)
    1c05:	jne    1c31 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1c07:	cmpq   $0xfffffffffffffffe,-0x20(%rax)
    1c0c:	jb     1c31 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1c0e:	mov    0x0(%rip),%rsi        # 1c15 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x95>
    1c15:	mov    %r14,%rdx
    1c18:	mov    %r15,%rcx
    1c1b:	mov    %ebx,%r9d
    1c1e:	add    $0x8,%rsp
    1c22:	pop    %rbx
    1c23:	pop    %r12
    1c25:	pop    %r13
    1c27:	pop    %r14
    1c29:	pop    %r15
    1c2b:	pop    %rbp
    1c2c:	jmp    1c31 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xb1>
    1c31:	mov    0x8(%r15),%r12
    1c35:	test   %r12,%r12
    1c38:	je     1c60 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xe0>
    1c3a:	movabs $0x2000000000000000,%r13
    1c44:	lea    0x2(%r13),%rax
    1c48:	test   %rax,-0x10(%r12)
    1c4d:	jne    1c60 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xe0>
    1c4f:	mov    %r12,%rdi
    1c52:	call   1c57 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xd7>
    1c57:	test   %eax,%eax
    1c59:	je     1c60 <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xe0>
    1c5b:	or     %r13,-0x10(%r12)
    1c60:	vmovups (%r15),%xmm0
    1c65:	vmovups %xmm0,(%r14)
    1c6a:	test   $0x4,%bl
    1c6d:	je     1c7a <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0xfa>
    1c6f:	vxorps %xmm0,%xmm0,%xmm0
    1c73:	vmovups %xmm0,(%r15)
    1c78:	jmp    1c9d <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x11d>
    1c7a:	cmpl   $0x1,(%r14)
    1c7e:	jne    1c9d <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x11d>
    1c80:	mov    0x8(%r14),%rax
    1c84:	test   %rax,%rax
    1c87:	je     1c9d <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x11d>
    1c89:	movabs $0x4000000000000002,%rcx
    1c93:	test   %rcx,-0x10(%rax)
    1c97:	jne    1c9d <myl_t_dad7bf45c7342d0db813c8e5b741bc989161ff4675d7ac4dde1adcb9cfe5c73f_rcg_publish+0x11d>
    1c99:	incq   -0x20(%rax)
    1c9d:	mov    $0x1,%eax
    1ca2:	add    $0x8,%rsp
    1ca6:	pop    %rbx
    1ca7:	pop    %r12
    1ca9:	pop    %r13
    1cab:	pop    %r14
    1cad:	pop    %r15
    1caf:	pop    %rbp
    1cb0:	ret
    1cb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000001cc0 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan>:
    1cc0:	push   %rbp
    1cc1:	mov    %rsp,%rbp
    1cc4:	mov    %rdx,%rcx
    1cc7:	mov    %rsi,%rdx
    1cca:	mov    (%rcx),%esi
    1ccc:	cmp    $0x1,%esi
    1ccf:	je     1d06 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x46>
    1cd1:	test   %esi,%esi
    1cd3:	jne    1d97 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1cd9:	mov    0x8(%rcx),%rax
    1cdd:	test   %rax,%rax
    1ce0:	je     1d97 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1ce6:	movabs $0x4000000000000002,%r8
    1cf0:	test   %r8,-0x10(%rax)
    1cf4:	jne    1d83 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xc3>
    1cfa:	mov    %eax,%r8d
    1cfd:	cmpq   $0xfffffffffffffffd,-0x18(%rax)
    1d02:	jae    1d38 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x78>
    1d04:	jmp    1d6b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xab>
    1d06:	mov    0x8(%rcx),%r8d
    1d0a:	cmp    $0x1,%r8d
    1d0e:	je     1d45 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x85>
    1d10:	test   %r8d,%r8d
    1d13:	jne    1d6f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xaf>
    1d15:	mov    0x10(%rcx),%rax
    1d19:	test   %rax,%rax
    1d1c:	je     1d7a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d1e:	movabs $0x4000000000000002,%r8
    1d28:	test   %r8,-0x10(%rax)
    1d2c:	jne    1d7a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d2e:	xor    %r8d,%r8d
    1d31:	cmpq   $0xfffffffffffffffd,-0x18(%rax)
    1d36:	jb     1d6b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xab>
    1d38:	mov    0x0(%rip),%rsi        # 1d3f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x7f>
    1d3f:	pop    %rbp
    1d40:	jmp    1d45 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x85>
    1d45:	mov    0x10(%rcx),%rax
    1d49:	test   %rax,%rax
    1d4c:	je     1d7a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d4e:	movabs $0x4000000000000002,%r8
    1d58:	test   %r8,-0x10(%rax)
    1d5c:	jne    1d7a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d5e:	mov    $0x1,%r8d
    1d64:	cmpq   $0xfffffffffffffffd,-0x18(%rax)
    1d69:	jae    1d38 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0x78>
    1d6b:	test   %esi,%esi
    1d6d:	je     1dae <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xee>
    1d6f:	cmp    $0x1,%r8d
    1d73:	je     1d7a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xba>
    1d75:	test   %r8d,%r8d
    1d78:	jne    1d97 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1d7a:	mov    0x10(%rcx),%rax
    1d7e:	test   %rax,%rax
    1d81:	je     1d97 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1d83:	movabs $0x4000000000000002,%rsi
    1d8d:	test   %rsi,-0x10(%rax)
    1d91:	jne    1d97 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1d93:	incq   -0x18(%rax)
    1d97:	mov    0x10(%rcx),%rax
    1d9b:	mov    %rax,0x10(%rdx)
    1d9f:	vmovups (%rcx),%xmm0
    1da3:	vmovups %xmm0,(%rdx)
    1da7:	mov    $0x1,%eax
    1dac:	pop    %rbp
    1dad:	ret
    1dae:	mov    0x8(%rcx),%rax
    1db2:	test   %rax,%rax
    1db5:	jne    1d83 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xc3>
    1db7:	jmp    1d97 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_loan+0xd7>
    1db9:	nopl   0x0(%rax)

0000000000001dc0 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan>:
    1dc0:	push   %rbp
    1dc1:	mov    %rsp,%rbp
    1dc4:	push   %r14
    1dc6:	push   %rbx
    1dc7:	mov    (%rsi),%eax
    1dc9:	cmp    $0x1,%eax
    1dcc:	je     1de5 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x25>
    1dce:	test   %eax,%eax
    1dd0:	jne    1e2a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1dd2:	mov    0x8(%rsi),%rax
    1dd6:	movq   $0x0,0x8(%rsi)
    1dde:	test   %rax,%rax
    1de1:	jne    1e02 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x42>
    1de3:	jmp    1e2a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1de5:	mov    0x8(%rsi),%eax
    1de8:	cmp    $0x1,%eax
    1deb:	je     1df1 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x31>
    1ded:	test   %eax,%eax
    1def:	jne    1e2a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1df1:	mov    0x10(%rsi),%rax
    1df5:	movq   $0x0,0x10(%rsi)
    1dfd:	test   %rax,%rax
    1e00:	je     1e2a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1e02:	movabs $0x4000000000000002,%rcx
    1e0c:	test   %rcx,-0x10(%rax)
    1e10:	jne    1e2a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x6a>
    1e12:	mov    -0x18(%rax),%rcx
    1e16:	cmp    $0x1,%rcx
    1e1a:	jne    1e23 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x63>
    1e1c:	cmpq   $0x0,-0x20(%rax)
    1e21:	je     1e3f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x7f>
    1e23:	dec    %rcx
    1e26:	mov    %rcx,-0x18(%rax)
    1e2a:	vxorps %xmm0,%xmm0,%xmm0
    1e2e:	vmovups %xmm0,(%rsi)
    1e32:	movq   $0x0,0x10(%rsi)
    1e3a:	pop    %rbx
    1e3b:	pop    %r14
    1e3d:	pop    %rbp
    1e3e:	ret
    1e3f:	mov    %rsi,%r14
    1e42:	mov    %rdi,%rbx
    1e45:	mov    %rax,%rsi
    1e48:	call   1e4d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0x8d>
    1e4d:	vxorps %xmm0,%xmm0,%xmm0
    1e51:	vmovups %xmm0,(%r14)
    1e56:	movq   $0x0,0x10(%r14)
    1e5e:	mov    %rbx,%rdi
    1e61:	pop    %rbx
    1e62:	pop    %r14
    1e64:	pop    %rbp
    1e65:	jmp    1e6a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_unloan+0xaa>
    1e6a:	nopw   0x0(%rax,%rax,1)

0000000000001e70 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop>:
    1e70:	push   %rbp
    1e71:	mov    %rsp,%rbp
    1e74:	push   %r14
    1e76:	push   %rbx
    1e77:	mov    (%rsi),%eax
    1e79:	cmp    $0x1,%eax
    1e7c:	je     1e95 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x25>
    1e7e:	test   %eax,%eax
    1e80:	jne    1eda <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1e82:	mov    0x8(%rsi),%rax
    1e86:	movq   $0x0,0x8(%rsi)
    1e8e:	test   %rax,%rax
    1e91:	jne    1eb2 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x42>
    1e93:	jmp    1eda <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1e95:	mov    0x8(%rsi),%eax
    1e98:	cmp    $0x1,%eax
    1e9b:	je     1ea1 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x31>
    1e9d:	test   %eax,%eax
    1e9f:	jne    1eda <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1ea1:	mov    0x10(%rsi),%rax
    1ea5:	movq   $0x0,0x10(%rsi)
    1ead:	test   %rax,%rax
    1eb0:	je     1eda <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1eb2:	movabs $0x4000000000000002,%rcx
    1ebc:	test   %rcx,-0x10(%rax)
    1ec0:	jne    1eda <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x6a>
    1ec2:	mov    -0x20(%rax),%rcx
    1ec6:	cmp    $0x1,%rcx
    1eca:	jne    1ed3 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x63>
    1ecc:	cmpq   $0x0,-0x18(%rax)
    1ed1:	je     1eef <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x7f>
    1ed3:	dec    %rcx
    1ed6:	mov    %rcx,-0x20(%rax)
    1eda:	vxorps %xmm0,%xmm0,%xmm0
    1ede:	vmovups %xmm0,(%rsi)
    1ee2:	movq   $0x0,0x10(%rsi)
    1eea:	pop    %rbx
    1eeb:	pop    %r14
    1eed:	pop    %rbp
    1eee:	ret
    1eef:	mov    %rsi,%r14
    1ef2:	mov    %rdi,%rbx
    1ef5:	mov    %rax,%rsi
    1ef8:	call   1efd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0x8d>
    1efd:	vxorps %xmm0,%xmm0,%xmm0
    1f01:	vmovups %xmm0,(%r14)
    1f06:	movq   $0x0,0x10(%r14)
    1f0e:	mov    %rbx,%rdi
    1f11:	pop    %rbx
    1f12:	pop    %r14
    1f14:	pop    %rbp
    1f15:	jmp    1f1a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_drop+0xaa>
    1f1a:	nopw   0x0(%rax,%rax,1)

0000000000001f20 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain>:
    1f20:	push   %rbp
    1f21:	mov    %rsp,%rbp
    1f24:	mov    %ecx,%r8d
    1f27:	mov    %rdx,%rcx
    1f2a:	mov    %rsi,%rdx
    1f2d:	movabs $0x4000000000000002,%rax
    1f37:	mov    (%rcx),%esi
    1f39:	mov    $0x1,%r9b
    1f3c:	cmp    $0x1,%esi
    1f3f:	je     1f5c <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x3c>
    1f41:	test   %esi,%esi
    1f43:	jne    1f7a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5a>
    1f45:	mov    0x8(%rcx),%r11
    1f49:	test   %r11,%r11
    1f4c:	je     1f7a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5a>
    1f4e:	mov    -0x10(%r11),%r10
    1f52:	test   %rax,%r10
    1f55:	jne    1f7d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5d>
    1f57:	jmp    1ff4 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xd4>
    1f5c:	mov    0x8(%rcx),%r10d
    1f60:	cmp    $0x1,%r10d
    1f64:	je     1f6b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x4b>
    1f66:	test   %r10d,%r10d
    1f69:	jne    1f7a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5a>
    1f6b:	mov    0x10(%rcx),%r10
    1f6f:	test   %r10,%r10
    1f72:	je     1fe2 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xc2>
    1f74:	mov    -0x10(%r10),%r10
    1f78:	jmp    1fe5 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xc5>
    1f7a:	xor    %r10d,%r10d
    1f7d:	test   %r9b,%r9b
    1f80:	je     1f9f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x7f>
    1f82:	lea    -0x2(%rax),%r9
    1f86:	and    %r9,%r10
    1f89:	jne    1f9f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x7f>
    1f8b:	cmp    $0x1,%esi
    1f8e:	je     1fac <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x8c>
    1f90:	test   %esi,%esi
    1f92:	jne    1fcb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1f94:	mov    0x8(%rcx),%rsi
    1f98:	test   %rsi,%rsi
    1f9b:	jne    1fc1 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xa1>
    1f9d:	jmp    1fcb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1f9f:	mov    0x0(%rip),%rsi        # 1fa6 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x86>
    1fa6:	pop    %rbp
    1fa7:	jmp    1fac <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x8c>
    1fac:	mov    0x8(%rcx),%esi
    1faf:	cmp    $0x1,%esi
    1fb2:	je     1fb8 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x98>
    1fb4:	test   %esi,%esi
    1fb6:	jne    1fcb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1fb8:	mov    0x10(%rcx),%rsi
    1fbc:	test   %rsi,%rsi
    1fbf:	je     1fcb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1fc1:	test   %rax,-0x10(%rsi)
    1fc5:	jne    1fcb <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0xab>
    1fc7:	incq   -0x20(%rsi)
    1fcb:	vmovups (%rcx),%xmm0
    1fcf:	mov    0x10(%rcx),%rax
    1fd3:	mov    %rax,0x10(%rdx)
    1fd7:	vmovups %xmm0,(%rdx)
    1fdb:	mov    $0x1,%eax
    1fe0:	pop    %rbp
    1fe1:	ret
    1fe2:	xor    %r10d,%r10d
    1fe5:	mov    0x10(%rcx),%r11
    1fe9:	test   %r11,%r11
    1fec:	je     1f7d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5d>
    1fee:	test   %rax,-0x10(%r11)
    1ff2:	jne    1f7d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5d>
    1ff4:	cmpq   $0xfffffffffffffffd,-0x20(%r11)
    1ff9:	setb   %r9b
    1ffd:	jmp    1f7d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_retain+0x5d>
    2002:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)

0000000000002010 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take>:
    2010:	push   %rbp
    2011:	mov    %rsp,%rbp
    2014:	mov    %ecx,%r8d
    2017:	mov    %rdx,%rcx
    201a:	mov    %rsi,%rdx
    201d:	mov    (%rcx),%eax
    201f:	cmp    $0x1,%eax
    2022:	je     2033 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x23>
    2024:	test   %eax,%eax
    2026:	jne    204e <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x3e>
    2028:	mov    0x8(%rcx),%rax
    202c:	test   %rax,%rax
    202f:	jne    2048 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x38>
    2031:	jmp    204e <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x3e>
    2033:	mov    0x8(%rcx),%eax
    2036:	cmp    $0x1,%eax
    2039:	je     203f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x2f>
    203b:	test   %eax,%eax
    203d:	jne    204e <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x3e>
    203f:	mov    0x10(%rcx),%rax
    2043:	test   %rax,%rax
    2046:	je     204e <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x3e>
    2048:	testb  $0x50,-0x9(%rax)
    204c:	jne    208b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x7b>
    204e:	mov    %rdx,%rax
    2051:	sub    %rcx,%rax
    2054:	mov    %rcx,%rsi
    2057:	sub    %rdx,%rsi
    205a:	cmovb  %rax,%rsi
    205e:	cmp    $0x17,%rsi
    2062:	jbe    208b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x7b>
    2064:	mov    0x10(%rcx),%rax
    2068:	mov    %rax,0x10(%rdx)
    206c:	vmovups (%rcx),%xmm0
    2070:	vmovups %xmm0,(%rdx)
    2074:	vxorps %xmm0,%xmm0,%xmm0
    2078:	vmovups %xmm0,(%rcx)
    207c:	movq   $0x0,0x10(%rcx)
    2084:	mov    $0x1,%eax
    2089:	pop    %rbp
    208a:	ret
    208b:	mov    0x0(%rip),%rsi        # 2092 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x82>
    2092:	pop    %rbp
    2093:	jmp    2098 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_take+0x88>
    2098:	nopl   0x0(%rax,%rax,1)

00000000000020a0 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish>:
    20a0:	push   %rbp
    20a1:	mov    %rsp,%rbp
    20a4:	push   %r15
    20a6:	push   %r14
    20a8:	push   %r13
    20aa:	push   %r12
    20ac:	push   %rbx
    20ad:	push   %rax
    20ae:	mov    %r8d,%r15d
    20b1:	mov    %ecx,%r8d
    20b4:	mov    %rdx,%r14
    20b7:	mov    %rsi,%rbx
    20ba:	mov    (%rdx),%eax
    20bc:	mov    $0x1,%cl
    20be:	cmp    $0x1,%eax
    20c1:	je     20d2 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x32>
    20c3:	test   %eax,%eax
    20c5:	jne    20ef <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x4f>
    20c7:	mov    0x8(%r14),%rdx
    20cb:	test   %rdx,%rdx
    20ce:	jne    20e8 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x48>
    20d0:	jmp    20ef <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x4f>
    20d2:	mov    0x8(%r14),%edx
    20d6:	cmp    $0x1,%edx
    20d9:	je     20df <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x3f>
    20db:	test   %edx,%edx
    20dd:	jne    20ef <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x4f>
    20df:	mov    0x10(%r14),%rdx
    20e3:	test   %rdx,%rdx
    20e6:	je     20ef <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x4f>
    20e8:	testb  $0x50,-0x9(%rdx)
    20ec:	sete   %cl
    20ef:	test   $0x3,%r15b
    20f3:	jne    216a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xca>
    20f5:	test   %cl,%cl
    20f7:	je     216a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xca>
    20f9:	mov    %rbx,%rcx
    20fc:	sub    %r14,%rcx
    20ff:	mov    %r14,%rdx
    2102:	sub    %rbx,%rdx
    2105:	cmovb  %rcx,%rdx
    2109:	cmp    $0x17,%rdx
    210d:	jbe    216a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xca>
    210f:	test   $0x4,%r15b
    2113:	jne    218d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xed>
    2115:	cmp    $0x1,%eax
    2118:	je     213d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x9d>
    211a:	test   %eax,%eax
    211c:	jne    21dd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    2122:	mov    0x8(%r14),%rcx
    2126:	test   %rcx,%rcx
    2129:	je     2196 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xf6>
    212b:	movabs $0x4000000000000002,%rdx
    2135:	test   %rdx,-0x10(%rcx)
    2139:	jne    2196 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xf6>
    213b:	jmp    2163 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xc3>
    213d:	mov    0x8(%r14),%ecx
    2141:	cmp    $0x1,%ecx
    2144:	je     214a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xaa>
    2146:	test   %ecx,%ecx
    2148:	jne    21c7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x127>
    214a:	mov    0x10(%r14),%rcx
    214e:	test   %rcx,%rcx
    2151:	je     21c7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x127>
    2153:	movabs $0x4000000000000002,%rdx
    215d:	test   %rdx,-0x10(%rcx)
    2161:	jne    21c7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x127>
    2163:	cmpq   $0xfffffffffffffffd,-0x20(%rcx)
    2168:	jb     218d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xed>
    216a:	mov    0x0(%rip),%rsi        # 2171 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xd1>
    2171:	mov    %rbx,%rdx
    2174:	mov    %r14,%rcx
    2177:	mov    %r15d,%r9d
    217a:	add    $0x8,%rsp
    217e:	pop    %rbx
    217f:	pop    %r12
    2181:	pop    %r13
    2183:	pop    %r14
    2185:	pop    %r15
    2187:	pop    %rbp
    2188:	jmp    218d <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0xed>
    218d:	cmp    $0x1,%eax
    2190:	je     21c7 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x127>
    2192:	test   %eax,%eax
    2194:	jne    21dd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    2196:	mov    0x8(%r14),%r12
    219a:	test   %r12,%r12
    219d:	je     21dd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    219f:	movabs $0x2000000000000000,%r13
    21a9:	lea    0x2(%r13),%rax
    21ad:	test   %rax,-0x10(%r12)
    21b2:	jne    21dd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21b4:	mov    %r12,%rdi
    21b7:	call   21bc <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x11c>
    21bc:	test   %eax,%eax
    21be:	je     21dd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21c0:	or     %r13,-0x10(%r12)
    21c5:	jmp    21dd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21c7:	mov    0x8(%r14),%eax
    21cb:	cmp    $0x1,%eax
    21ce:	je     21d4 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x134>
    21d0:	test   %eax,%eax
    21d2:	jne    21dd <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x13d>
    21d4:	mov    0x10(%r14),%rdi
    21d8:	call   490 <myl_rcg_share>
    21dd:	mov    0x10(%r14),%rax
    21e1:	mov    %rax,0x10(%rbx)
    21e5:	vmovups (%r14),%xmm0
    21ea:	vmovups %xmm0,(%rbx)
    21ee:	test   $0x4,%r15b
    21f2:	jne    220a <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x16a>
    21f4:	mov    (%rbx),%eax
    21f6:	cmp    $0x1,%eax
    21f9:	je     222f <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x18f>
    21fb:	test   %eax,%eax
    21fd:	jne    221b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    21ff:	mov    0x8(%rbx),%rax
    2203:	test   %rax,%rax
    2206:	jne    2244 <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x1a4>
    2208:	jmp    221b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    220a:	vxorps %xmm0,%xmm0,%xmm0
    220e:	vmovups %xmm0,(%r14)
    2213:	movq   $0x0,0x10(%r14)
    221b:	mov    $0x1,%eax
    2220:	add    $0x8,%rsp
    2224:	pop    %rbx
    2225:	pop    %r12
    2227:	pop    %r13
    2229:	pop    %r14
    222b:	pop    %r15
    222d:	pop    %rbp
    222e:	ret
    222f:	mov    0x8(%rbx),%eax
    2232:	cmp    $0x1,%eax
    2235:	je     223b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x19b>
    2237:	test   %eax,%eax
    2239:	jne    221b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    223b:	mov    0x10(%rbx),%rax
    223f:	test   %rax,%rax
    2242:	je     221b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    2244:	movabs $0x4000000000000002,%rcx
    224e:	test   %rcx,-0x10(%rax)
    2252:	jne    221b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>
    2254:	incq   -0x20(%rax)
    2258:	jmp    221b <myl_t_f9b24c36cf8019baa7b5baa1c6be743f14319483cb9ec0f5772e97fb7b1a2d2c_rcg_publish+0x17b>

Disassembly of section .text.unlikely.:

0000000000000000 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain_slow>:
   0:	push   %rbp
   1:	mov    %rsp,%rbp
   4:	mov    %ecx,%r8d
   7:	mov    %rdx,%rcx
   a:	mov    %rsi,%rdx
   d:	mov    0x0(%rip),%rsi        # 14 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain_slow+0x14>
  14:	pop    %rbp
  15:	jmp    1a <myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0+0x2>
