    1540:	push   %rbp
    1541:	mov    %rsp,%rbp
    1544:	push   %r14
    1546:	push   %rbx
    1547:	mov    %rdx,%rcx
    154a:	mov    (%rsi),%rbx
    154d:	cmp    0x8(%rsi),%rbx
    1551:	jae    1571 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x31>
    1553:	cmpq   $0xffffffffffffffff,0x10(%rsi)
    1558:	je     1571 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x31>
    155a:	mov    0x20(%rsi),%rdx
    155e:	mov    %rcx,%r8
    1561:	sub    %rdx,%r8
    1564:	lea    0x0(,%rbx,8),%rax
    156c:	cmp    %rax,%r8
    156f:	jae    157d <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x3d>
    1571:	mov    %rcx,%rdx
    1574:	pop    %rbx
    1575:	pop    %r14
    1577:	pop    %rbp
    1578:	jmp    157d <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x3d>
    157d:	add    %rax,%rdx
    1580:	mov    -0x10(%rsi),%rax
    1584:	mov    %rax,%r9
    1587:	shr    $0x28,%r9
    158b:	and    $0xfffff,%r9d
    1592:	xor    %r8d,%r8d
    1595:	bt     $0x3e,%rax
    159a:	cmovb  %r9d,%r8d
    159e:	mov    (%rcx),%rax
    15a1:	test   %rax,%rax
    15a4:	je     15d3 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x93>
    15a6:	movabs $0x4000000000000000,%r10
    15b0:	mov    -0x10(%rax),%r9
    15b4:	test   %r10,%r9
    15b7:	jne    15d8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x98>
    15b9:	test   $0x2,%r9b
    15bd:	jne    15d3 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x93>
    15bf:	mov    -0x20(%rax),%r9
    15c3:	cmp    $0xffffffffffffffff,%r9
    15c7:	je     15d8 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x98>
    15c9:	inc    %r9
    15cc:	mov    %r9,-0x20(%rax)
    15d0:	mov    (%rcx),%rax
    15d3:	mov    %rax,(%rdx)
    15d6:	jmp    15f1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xb1>
    15d8:	mov    0x0(%rip),%rax        # 15df <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x9f>
    15df:	mov    %rsi,%r14
    15e2:	mov    %rax,%rsi
    15e5:	call   15ea <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xaa>
    15ea:	mov    %r14,%rsi
    15ed:	test   %eax,%eax
    15ef:	je     1605 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xc5>
    15f1:	inc    %rbx
    15f4:	mov    %rbx,(%rsi)
    15f7:	incq   0x10(%rsi)
    15fb:	mov    $0x1,%eax
    1600:	pop    %rbx
    1601:	pop    %r14
    1603:	pop    %rbp
    1604:	ret
    1605:	xor    %eax,%eax
    1607:	jmp    1600 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xc0>
    1609:	nopl   0x0(%rax)
