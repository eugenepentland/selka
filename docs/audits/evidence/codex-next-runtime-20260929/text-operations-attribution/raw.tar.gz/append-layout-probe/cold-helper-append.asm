    1530:	push   %rbp
    1531:	mov    %rsp,%rbp
    1534:	push   %r14
    1536:	push   %rbx
    1537:	mov    (%rsi),%rbx
    153a:	cmp    0x8(%rsi),%rbx
    153e:	jae    155e <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x2e>
    1540:	cmpq   $0xffffffffffffffff,0x10(%rsi)
    1545:	je     155e <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x2e>
    1547:	mov    0x20(%rsi),%rax
    154b:	mov    %rdx,%rcx
    154e:	sub    %rax,%rcx
    1551:	lea    0x0(,%rbx,8),%r8
    1559:	cmp    %r8,%rcx
    155c:	jae    1567 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x37>
    155e:	pop    %rbx
    155f:	pop    %r14
    1561:	pop    %rbp
    1562:	jmp    1567 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x37>
    1567:	mov    -0x10(%rsi),%r9
    156b:	mov    %r9,%r10
    156e:	shr    $0x28,%r10
    1572:	and    $0xfffff,%r10d
    1579:	xor    %ecx,%ecx
    157b:	bt     $0x3e,%r9
    1580:	cmovb  %r10d,%ecx
    1584:	mov    (%rdx),%r9
    1587:	test   %r9,%r9
    158a:	je     15b9 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x89>
    158c:	movabs $0x4000000000000000,%r11
    1596:	mov    -0x10(%r9),%r10
    159a:	test   %r11,%r10
    159d:	jne    15d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xa1>
    159f:	test   $0x2,%r10b
    15a3:	jne    15b9 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x89>
    15a5:	mov    -0x20(%r9),%r10
    15a9:	cmp    $0xffffffffffffffff,%r10
    15ad:	je     15d1 <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xa1>
    15af:	inc    %r10
    15b2:	mov    %r10,-0x20(%r9)
    15b6:	mov    (%rdx),%r9
    15b9:	mov    %r9,(%rax,%r8,1)
    15bd:	inc    %rbx
    15c0:	mov    %rbx,(%rsi)
    15c3:	incq   0x10(%rsi)
    15c7:	mov    $0x1,%eax
    15cc:	pop    %rbx
    15cd:	pop    %r14
    15cf:	pop    %rbp
    15d0:	ret
    15d1:	add    %r8,%rax
    15d4:	mov    %rsi,%r14
    15d7:	mov    %rax,%rsi
    15da:	call   15df <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0xaf>
    15df:	mov    %r14,%rsi
    15e2:	test   %eax,%eax
    15e4:	jne    15bd <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x8d>
    15e6:	xor    %eax,%eax
    15e8:	jmp    15cc <myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append+0x9c>
    15ea:	nopw   0x0(%rax,%rax,1)
