import ast,hashlib,json,os,subprocess,time,struct
from pathlib import Path
work=Path(__file__).resolve().parent;own=work.parents[1];root=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-closeout-20260929')
tool=Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-combined-module-review-20260930/.tmp/alloc-churn-attribution/valgrind-local/usr')
env={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'};env.update(TMPDIR=str(own/'.tmp'),ZIG_LOCAL_CACHE_DIR=str(own/'.zig-local-cache'),ZIG_GLOBAL_CACHE_DIR=str(own/'.zig-global-cache'),MYLANG_MEMORY_LIMIT='4G',VALGRIND_LIB=str(tool/'libexec/valgrind'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
definition=next(n for n in ast.parse((work/'previous-profile.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='allocated');exec(compile(ast.Module(body=[definition],type_ignores=[]),'allocated_verifier','exec'))
receipt={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=own,text=True).strip(),'cpu':0,'scope':'Read-only code-identical simulated instruction attribution, no hardware or acceptance samples','tool':subprocess.check_output([str(tool/'bin/valgrind'),'--version'],env=env,text=True).strip(),'sides':{}}
def command(d,label,argv):
 wrapped=[str(own/'scripts/build-slot.sh'),'build',*argv];print(d.name,label,flush=True);started=time.monotonic();x=subprocess.run(wrapped,cwd=own,env=env,capture_output=True);(d/(label+'.stdout')).write_bytes(x.stdout);(d/(label+'.stderr')).write_bytes(x.stderr);r={'admission':wrapped,'status':x.returncode,'elapsed_seconds':time.monotonic()-started};assert x.returncode==0,x.stderr.decode(errors='replace');return r
for side in ['control','candidate']:
 d=work/side;binary=d/'parity-suite-text_ops.llvm';symbols=d/'text_ops.symbols';compiler=d/'compiler/bin/mylang';receipt['sides'][side]={'original_sha256':sha(binary),'compiler_sha256':sha(compiler)};record=receipt['sides'][side]
 record['build']=command(d,'build',[str(compiler),'build',str(root/'bench/parity/suite/text_ops.my'),'-o',str(symbols),'--backend','llvm','--llvm-opt','3','--lto','--rc-runtime','--keep-symbols','--cache-dir',str(d/'cache')])
 record['allocated_sections_original']=allocated(binary);record['allocated_sections_symbols']=allocated(symbols);assert record['allocated_sections_original']==record['allocated_sections_symbols'],'allocated code/data mismatch';record['allocated_sections_equal']=True;record['symbols_sha256']=sha(symbols)
 for name,argv in [('assembly',['objdump','-d','--no-show-raw-insn',str(symbols)]),('symbols',['nm','-n','-S',str(symbols)])]:(d/name).write_bytes(subprocess.check_output(argv))
 (work/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 record['callgrind']=command(d,'callgrind',['taskset','-c','0',str(tool/'bin/valgrind'),'--tool=callgrind','--dump-instr=yes','--collect-jumps=yes','--compress-pos=no','--compress-strings=no','--callgrind-out-file='+str(d/'callgrind.out'),str(symbols)])
 assert (d/'callgrind.stdout').read_bytes()==(work/'text_ops.expected').read_bytes();record['output_exact']=True
 x=subprocess.run([str(tool/'bin/callgrind_annotate'),'--show=Ir','--threshold=100','--auto=no',str(d/'callgrind.out')],env=env,cwd=own,capture_output=True);(d/'callgrind.annotate').write_bytes(x.stdout);(d/'callgrind.annotate.stderr').write_bytes(x.stderr);assert x.returncode==0
 (work/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(side,'code identity and profile complete',flush=True)
