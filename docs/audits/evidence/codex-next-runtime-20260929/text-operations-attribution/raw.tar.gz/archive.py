from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile


worktree = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent
package = worktree / '.tmp/text-ops-final-review-package'
raw = package / 'raw'
assert not package.exists(), 'Refuse to replace an existing package'
raw.mkdir(parents=True)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def copy(source, relative):
    target = raw / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


for source in sorted(evidence.rglob('*')):
    if not source.is_file():
        continue
    relative = source.relative_to(evidence)
    if {'compiler', 'cache'} & set(relative.parts):
        continue
    copy(source, relative)

source_paths = [
    'src/rc_glue.zig', 'src/rc_glue_acquisition.zig',
    'src/qbe_rc_append.zig', 'src/native_rc_walk.c',
    'src/native_rc_shapes.c', 'src/native_rc_internal.h',
    'src/native_rc.h', 'src/native_collections.c',
    'src/native.h', 'src/native.c',
    'bench/parity/quick.py', 'scripts/build-slot.sh',
]
source_receipt = {'candidate': {}, 'control': {}}
for relative in source_paths:
    source = worktree / relative
    if source.is_file():
        copy(source, Path('frozen-sources/candidate') / relative)
        source_receipt['candidate'][relative] = digest(source)
    result = subprocess.run(
        ['git', 'show', '80dd51906c97ae76bf208474ac48c9baac3a11cd:' + relative],
        cwd=worktree, capture_output=True)
    if result.returncode == 0:
        target = raw / 'frozen-sources/control' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(result.stdout)
        source_receipt['control'][relative] = digest(target)
    else:
        source_receipt['control'][relative] = {'unavailable': True}

prefixes = {}
for side in ['control', 'candidate']:
    prefix = evidence / side / 'compiler'
    prefixes[side] = {
        str(f.relative_to(prefix)): {
            'bytes': f.stat().st_size, 'sha256': digest(f)
        }
        for f in sorted(prefix.rglob('*')) if f.is_file()
    }

verification = subprocess.run(
    ['git', 'diff', '--exit-code', 'HEAD', '--', 'src', 'vendor',
     'build.zig', 'build_test_inputs.zig'],
    cwd=worktree, capture_output=True, check=True)
assert not verification.stdout
provenance = {
    'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree,
                                      text=True).strip(),
    'production_diff_exit_code': verification.returncode,
    'production_diff_paths': ['src', 'vendor', 'build.zig', 'build_test_inputs.zig'],
    'frozen_source_snapshots': source_receipt,
    'compiler_prefixes_not_archived': prefixes,
    'scope': 'Read-only simulated attribution; no hardware measurements or acceptance claim',
}
(raw / 'archive-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')

manifest = {
    str(f.relative_to(raw)): {'bytes': f.stat().st_size, 'sha256': digest(f)}
    for f in sorted(raw.rglob('*')) if f.is_file()
}
(raw / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

archive = package / 'raw.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for f in sorted(raw.rglob('*')):
                if not f.is_file():
                    continue
                data = f.read_bytes()
                info = tarfile.TarInfo(str(f.relative_to(raw)))
                info.size = len(data)
                info.mode = 0o755 if f.stat().st_mode & 0o111 else 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))

with tarfile.open(archive, mode='r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(manifest) + 1
    assert len({m.name for m in members}) == len(members)
    archived_manifest = json.loads(tar.extractfile('manifest.json').read())
    assert archived_manifest == manifest
    for relative, expected in manifest.items():
        data = tar.extractfile(relative).read()
        assert len(data) == expected['bytes'], relative
        assert hashlib.sha256(data).hexdigest() == expected['sha256'], relative

result = {
    'archive': str(archive), 'bytes': archive.stat().st_size,
    'sha256': digest(archive), 'manifest_sha256': digest(raw / 'manifest.json'),
    'raw_members': len(manifest), 'total_members': len(manifest) + 1,
    'all_member_lengths_and_hashes_verified': True,
    'report_sha256': digest(raw / 'report.md'),
    'profile_receipt_sha256': digest(raw / 'receipt.json'),
}
(package / 'package-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
