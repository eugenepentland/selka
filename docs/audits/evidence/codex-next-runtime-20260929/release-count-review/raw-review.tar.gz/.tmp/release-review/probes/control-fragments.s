.text
.balign 16
.globl review_owner
review_owner:
	endbr64
	pushq %rbp
	movq %rsp, %rbp
	movq %rsi, %rdi
	movq (%rdx), %rcx
	cmpq $0, %rcx
	jz .Lbb7
	movq %rcx, %rax
	subq $16, %rax
	movq (%rax), %rax
	movq $4611686018427387906, %rsi
	andq %rsi, %rax
	cmpq $0, %rax
	jnz .Lbb6
	movq %rcx, %rax
	subq $32, %rax
	movq (%rax), %rax
	cmpq $1, %rax
	jnz .Lbb5
	movq %rcx, %rsi
	subq $24, %rsi
	movq (%rsi), %rsi
	cmpq $0, %rsi
	jnz .Lbb5
	movq %rdx, %rsi
	callq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop
	jmp .Lbb7
.Lbb5:
	subq $1, %rax
	subq $32, %rcx
	movq %rax, (%rcx)
.Lbb6:
	movq $0, (%rdx)
.Lbb7:
	movl $1, %eax
	leave
	ret
.type review_owner, @function
.size review_owner, .-review_owner
/* end function review_owner */

.text
.balign 16
.globl review_hold
review_hold:
	endbr64
	pushq %rbp
	movq %rsp, %rbp
	movq %rsi, %rdi
	movq (%rdx), %rcx
	cmpq $0, %rcx
	jz .Lbb16
	movq %rcx, %rax
	subq $16, %rax
	movq (%rax), %rax
	movq $4611686018427387906, %rsi
	andq %rsi, %rax
	cmpq $0, %rax
	jnz .Lbb15
	movq %rcx, %rax
	subq $24, %rax
	movq (%rax), %rax
	cmpq $1, %rax
	jnz .Lbb14
	movq %rcx, %rsi
	subq $32, %rsi
	movq (%rsi), %rsi
	cmpq $0, %rsi
	jnz .Lbb14
	movq %rdx, %rsi
	callq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan
	jmp .Lbb16
.Lbb14:
	subq $1, %rax
	subq $24, %rcx
	movq %rax, (%rcx)
.Lbb15:
	movq $0, (%rdx)
.Lbb16:
	movl $1, %eax
	leave
	ret
.type review_hold, @function
.size review_hold, .-review_hold
/* end function review_hold */

.text
.balign 16
.globl review_publish
review_publish:
	endbr64
	pushq %rbp
	movq %rsp, %rbp
	pushq %rbx
	pushq %r12
	movq %rdi, %rbx
	movq %rsi, %rdi
	movq %rdx, %rsi
	movq %rcx, %rdx
	movl %r8d, %ecx
	movl %r9d, %r8d
	movl %r8d, %eax
	andl $3, %eax
	movl %eax, %eax
	cmpq $0, %rax
	jnz .Lbb37
	movl %ecx, %r10d
	movq (%rdx), %rcx
	cmpq $0, %rcx
	setnz %al
	movzbl %al, %eax
	movl %r8d, %r9d
	andl $4, %r9d
	movl %r9d, %r9d
	cmpl $0, %eax
	jnz .Lbb21
	movq %rsi, %rdi
	movq %r9, %rsi
	movl $3735936685, %eax
	jmp .Lbb31
.Lbb21:
	movq %rcx, %rax
	subq $16, %rax
	movq (%rax), %rax
	movq $5764607523034234880, %r11
	andq %rax, %r11
	cmpq $0, %r11
	jnz .Lbb36
	cmpq $0, %r9
	jnz .Lbb28
	movq %rax, %r11
	andq $2, %r11
	cmpq $0, %r11
	jnz .Lbb27
	movq %rcx, %r11
	subq $32, %r11
	movq (%r11), %r11
	cmpq $-1, %r11
	jz .Lbb26
	movq %rsi, %rdi
	jmp .Lbb29
.Lbb26:
	movl %r10d, %ecx
	jmp .Lbb37
.Lbb27:
	movq %rsi, %rdi
	jmp .Lbb29
.Lbb28:
	movq %rsi, %rdi
.Lbb29:
	movq %r9, %rsi
	movq $2305843009213693954, %r8
	andq %rax, %r8
	cmpq $0, %r8
	jnz .Lbb31
	movq $2305843009213693952, %r8
	orq %rax, %r8
	movq %rcx, %r9
	subq $16, %r9
	movq %r8, (%r9)
.Lbb31:
	movq %rcx, (%rdi)
	cmpq $0, %rsi
	jnz .Lbb35
	cmpq $0, %rcx
	jz .Lbb39
	andq $2, %rax
	cmpq $0, %rax
	jnz .Lbb39
	movq %rcx, %rax
	subq $32, %rax
	movq (%rax), %rax
	addq $1, %rax
	subq $32, %rcx
	movq %rax, (%rcx)
	jmp .Lbb39
.Lbb35:
	movq $0, (%rdx)
	jmp .Lbb39
.Lbb36:
	movl %r10d, %ecx
.Lbb37:
	movq %rdi, %r12
	callq myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish
	movq %r12, %rdi
	cmpl $0, %eax
	jnz .Lbb39
	callq myl_rc_take_failure
	movq %rbx, %rdi
	movl %eax, %esi
	callq myl_qbe_rc_status
	movl $0, %eax
	jmp .Lbb40
.Lbb39:
	movl $1, %eax
.Lbb40:
	popq %r12
	popq %rbx
	leave
	ret
.type review_publish, @function
.size review_publish, .-review_publish
/* end function review_publish */

.section .note.GNU-stack,"",@progbits
