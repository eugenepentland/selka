#include "native_rc_internal.h"
#include "native_rc_alloc.h"
#include "native_rc_collections.h"
#include "native_collections.h"
#include "alias-symbol.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
extern const myl_rc_module myl_rc_generated_module;
extern const myl_rc_image myl_rc_generated_image;
extern int alias_publish(myl_native_heap *, void *, void *, unsigned, unsigned) __asm__(ALIAS_SYMBOL);
static const myl_native_type scalar={.size=8,.alignment=8,.kind=MYL_NATIVE_PLAIN};
int main(void) {
    const uint64_t values[]={3,UINT64_MAX-2,UINT64_MAX-1};
    for(unsigned i=0;i<3;++i) {
        myl_native_heap heap; myl_native_heap_init(&heap,64u<<20);
        assert(myl_rc_module_register_image(&heap,&myl_rc_generated_module,&myl_rc_generated_image)==MYL_RC_OK);
        assert(myl_rc_list_require(&heap)==MYL_RC_OK);
        myl_native_list *p=myl_native_list_new(&heap,&scalar,0); assert(p);
        myl_rc_object *o=(myl_rc_object *)p-1;
        o->owners=values[i]; const uintptr_t mark=o->common.mark;
        struct { void *left,*right; } src={p,p},dst={0};
        const size_t bytes=heap.bytes;
        const int ok=alias_publish(&heap,&dst,&src,0,0);
        assert(src.left==p && src.right==p && !o->holds);
        if(i==2) {
            assert(!ok && !dst.left && !dst.right);
            assert(o->owners==values[i] && o->common.mark==mark && heap.bytes==bytes);
            assert(myl_rc_take_failure(&heap)==MYL_RC_COUNT_LIMIT);
        } else {
            assert(ok && dst.left==p && dst.right==p && o->owners==values[i]+2);
            assert((o->common.mark&MYL_NATIVE_OBJECT_SHARED)!=0);
        }
        /* Remove the fabricated reference traffic before ordinary teardown. */
        o->owners=1; myl_rc_owner_release(&heap,p);
        assert(!heap.objects_live); myl_native_heap_destroy(&heap); assert(!heap.bytes);
    }
    puts("native duplicate-alias publication: 3 cases passed");
    return 0;
}
