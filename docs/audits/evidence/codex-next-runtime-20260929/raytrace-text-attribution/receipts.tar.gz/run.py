import ast, collections, hashlib, json, os, shutil, struct, subprocess, time
from pathlib import Path

work = Path(__file__).resolve().parent
own = work.parents[1]
root = Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-closeout-20260929')
prior = work.parent / 'alloc-churn-attribution'
localtools = prior / 'valgrind-local/usr'
env = {k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env.update(TMPDIR=str(own / '.tmp'), ZIG_GLOBAL_CACHE_DIR=str(own / '.zig-global-cache'), ZIG_LOCAL_CACHE_DIR=str(own / '.zig-cache'), MYLANG_MEMORY_LIMIT='4G', VALGRIND_LIB=str(localtools / 'libexec/valgrind'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = {'owned_source': subprocess.check_output(['git','rev-parse','HEAD'], cwd=own).decode().strip(), 'candidate_source': '7f5068a54946bcbe0cf1f7e20abf844f120046cd', 'cpu': 0, 'purpose': 'Separate read-only instruction attribution; no Guardian, source mutation, timing-pool claim or performance acceptance.', 'tool': subprocess.check_output([str(localtools/'bin/valgrind'),'--version'],env=env).decode().strip(), 'cases': {}}

# Reuse the already validated ELF allocated-section inspection, without
# executing the old script or changing any previous profile artifact.
definition = next(n for n in ast.parse((prior/'profile.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='allocated')
exec(compile(ast.Module(body=[definition],type_ignores=[]),'allocated_section_verifier','exec'))

def command(dest, label, argv):
    wrapped = [str(own / 'scripts/build-slot.sh'),'build', *argv]
    started = time.monotonic()
    print(dest.name,label,flush=True)
    done = subprocess.run(wrapped,cwd=own,env=env,capture_output=True)
    (dest/(label+'.stdout')).write_bytes(done.stdout)
    (dest/(label+'.stderr')).write_bytes(done.stderr)
    record = {'admission_command': wrapped, 'status':done.returncode,'elapsed_seconds':time.monotonic()-started}
    assert done.returncode==0, done.stderr.decode(errors='replace')
    return record

for case,arm in [('raytrace','llvm'),('text_ops','qbe')]:
    name=f'parity-suite-{case}.{arm}'
    source=root/'bench/parity/suite'/f'{case}.my'
    shutil.copy2(source,work/f'{case}.my')
    shutil.copy2(source.with_suffix('.expected'),work/f'{case}.expected')
    entry={'backend':arm,'source_sha256':sha(source),'sides':{}}
    receipt['cases'][case]=entry
    for side,tag in [('control','m17-codex'),('candidate','phase-b-zero-combined')]:
        dest=work/case/side
        dest.mkdir(parents=True,exist_ok=True)
        origin=root/'.tmp-rc-quick/bin'/tag
        for filename in ['compiler.json',name,name+'.qbe-manifest.json']:
            shutil.copy2(origin/filename,dest/filename)
        compiler=json.loads((dest/'compiler.json').read_text())
        assert sha(Path(compiler['compiler']))==compiler['sha256']
        frozen=dest/name
        symbols=dest/(name+'.symbols')
        record={'original':str(origin/name),'frozen_sha256':sha(frozen),'compiler':compiler}
        entry['sides'][side]=record
        backend=['--backend','llvm','--llvm-opt','3','--lto'] if arm=='llvm' else []
        record['build']=command(dest,'build',[compiler['compiler'],'build',str(source),'-o',str(symbols),*backend,'--rc-runtime','--keep-symbols','--cache-dir',str(dest/'cache')])
        assert allocated(frozen)==allocated(symbols), (case,side,'allocated code/data mismatch')
        record['allocated_sections_equal']=True
        record['allocated_sections']=allocated(frozen)
        record['symbols_sha256']=sha(symbols)
        for suffix,argv in [('symbols',['nm','-n','-S',str(symbols)]),('assembly',['objdump','-d','--no-show-raw-insn',str(symbols)])]:
            (dest/suffix).write_bytes(subprocess.check_output(argv))
        record['perf_stat']=command(dest,'stat',['taskset','-c','0','perf','stat','-x,','-e','cpu_core/instructions/u','-o',str(dest/'stat.csv'),'--',str(frozen)])
        record['callgrind']=command(dest,'callgrind',['taskset','-c','0',str(localtools/'bin/valgrind'),'--tool=callgrind','--dump-instr=yes','--collect-jumps=yes','--compress-pos=no','--compress-strings=no','--callgrind-out-file='+str(dest/'callgrind.out'),str(symbols)])
        annotation=subprocess.run([str(localtools/'bin/callgrind_annotate'),'--show=Ir','--threshold=100','--auto=no',str(dest/'callgrind.out')],cwd=own,env=env,capture_output=True)
        (dest/'callgrind.annotate').write_bytes(annotation.stdout)
        (dest/'callgrind.annotate.stderr').write_bytes(annotation.stderr)
        assert annotation.returncode==0
        assert (dest/'stat.stdout').read_bytes()==(work/f'{case}.expected').read_bytes()
        assert (dest/'callgrind.stdout').read_bytes()==(work/f'{case}.expected').read_bytes()
        assert sha(origin/name)==record['frozen_sha256']
        (work/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        print(case,side,'identity and output checked',flush=True)
print('Both instruction-attribution probes completed.',flush=True)
