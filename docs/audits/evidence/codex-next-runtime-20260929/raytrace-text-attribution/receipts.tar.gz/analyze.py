import ast, collections, difflib, json, re
from pathlib import Path

base = Path(__file__).resolve().parent
old = ast.parse((base.parent/'alloc-churn-attribution/analyze.py').read_text())
definition=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='parse')
exec(compile(ast.Module(body=[definition],type_ignores=[]),'callgrind_parser','exec'))

def assembly(side):
    result={}
    fn=None
    for line in (work/side/'assembly').read_text().splitlines():
        header=re.match(r'^[0-9a-f]+ <(.*)>:',line)
        if header: fn=header[1]
        inst=re.match(r'^\s*([0-9a-f]+):\s*(.*)',line)
        if inst: result[int(inst[1],16)]=(fn,inst[2])
    return result

def mnemonic_counts(data, asm):
    counts=collections.Counter()
    for fn,instructions in data['instructions'].items():
        for address,executions in instructions.items():
            inst=asm.get(int(address,16))
            if inst:
                mnemonic=inst[1].split()[0]
                counts[mnemonic]+=executions
    return counts

for case in ['raytrace','text_ops']:
    work=base/case
    if not all((work/side/'callgrind.annotate').exists() for side in ['control','candidate']): continue
    data={side:parse(side) for side in ['control','candidate']}
    delta=[{'function':fn,'control':data['control']['self'].get(fn,0),'candidate':data['candidate']['self'].get(fn,0),'delta':data['candidate']['self'].get(fn,0)-data['control']['self'].get(fn,0)} for fn in data['control']['self'].keys()|data['candidate']['self'].keys()]
    delta.sort(key=lambda row:abs(row['delta']),reverse=True)
    asms={side:assembly(side) for side in ['control','candidate']}
    counts={side:mnemonic_counts(data[side],asms[side]) for side in ['control','candidate']}
    mdelta=[{'mnemonic':m,'control':counts['control'].get(m,0),'candidate':counts['candidate'].get(m,0),'delta':counts['candidate'].get(m,0)-counts['control'].get(m,0)} for m in counts['control'].keys()|counts['candidate'].keys()]
    mdelta.sort(key=lambda row:abs(row['delta']),reverse=True)
    result={'total_delta':data['candidate']['total']-data['control']['total'],'function_deltas':delta,'mnemonic_deltas':mdelta,**data}
    (work/'exact-counts.json').write_text(json.dumps(result,indent=2)+'\n')
    # Annotate every executed guest/native instruction with its exact simulated count.
    for side in ['control','candidate']:
        out=[]
        for fn,instructions in data[side]['instructions'].items():
            native=[(int(a,16),n) for a,n in instructions.items() if int(a,16) in asms[side]]
            if not native: continue
            out.append(fn+'\n')
            for a,n in sorted(native): out.append(f'{a:x} {n:12,d} {asms[side][a][1]}\n')
        (work/side/'executed-assembly').write_text(''.join(out))
    print(case,json.dumps({'total_delta':result['total_delta'],'function_deltas':delta[:12],'mnemonic_deltas':mdelta[:16]},indent=2))
