import collections, hashlib, json, re, shutil
from pathlib import Path

base = Path(__file__).resolve().parent
root = Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-closeout-20260929')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = json.loads((base/'receipt.json').read_text())
summary = {}

for case in ['raytrace', 'text_ops']:
    d = json.loads((base/case/'exact-counts.json').read_text())
    summary[case] = {'control_callgrind': d['control']['total'], 'candidate_callgrind': d['candidate']['total'], 'callgrind_delta': d['total_delta']}
    for side in ['control','candidate']:
        assert sum(d[side]['self'].values()) == d[side]['total']
        assert sha(Path(receipt['cases'][case]['sides'][side]['original'])) == receipt['cases'][case]['sides'][side]['frozen_sha256']
        assert (base/case/side/'stat.stdout').read_bytes() == (base/f'{case}.expected').read_bytes()
        assert (base/case/side/'callgrind.stdout').read_bytes() == (base/f'{case}.expected').read_bytes()

ray = json.loads((base/'raytrace/exact-counts.json').read_text())
counts = ray['candidate']['instructions']['entry_run']
assert counts['0x1013795'] == counts['0x1013458'] == 2_073_600
assert counts['0x1013a35'] == counts['0x1013a43'] == 1_294_536
ray_sites = 2_073_600 + 1_294_536
assert ray['candidate']['self']['entry_run'] - ray['control']['self']['entry_run'] == 4*ray_sites + 4
summary['raytrace']['entry_delta'] = 4*ray_sites + 4
summary['raytrace']['checked_increment_delta'] = 3*ray_sites
summary['raytrace']['zero_rematerialization_delta'] = ray_sites
summary['raytrace']['startup_other_delta'] = ray['total_delta'] - (4*ray_sites + 4)

text = json.loads((base/'text_ops/exact-counts.json').read_text())
app = 'myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append'
counts = text['candidate']['instructions'][app]
assert counts['0x1035773'] == 742_862
assert counts['0x1035786'] == 1_400_010
assert text['candidate']['self'][app] - text['control']['self'][app] == 4*742_862 + 1_400_010
assert text['candidate']['self']['view'] + text['candidate']['self']['long_piece'] - text['control']['self']['long_piece'] == 17*190_000
edges = text['candidate']['instructions']['myl_rc_edges_release']
assert edges['0x1052627'] == 942_852
assert edges['0x1052510'] == 599_998
assert text['control']['instructions']['myl_rc_edges_release']['0x10512d0'] == 399_999
assert text['candidate']['self']['myl_rc_edges_release'] - text['control']['self']['myl_rc_edges_release'] == 942_852 + 199_999*10
summary['text_ops'].update(lost_view_inlining_delta=17*190_000, list_append_delta=4*742_862 + 1_400_010,
    edges_rc_reload_delta=942_852, edges_hash_probe_delta=199_999*10)

# Preserve exact compiler-emitted runtime source; omit configure/object caches.
for side in ['control', 'candidate']:
    source = next((base/'text_ops'/side/'cache/runtime').iterdir())
    dest = base/'runtime-source'/side
    dest.mkdir(parents=True, exist_ok=True)
    for p in source.iterdir():
        if p.suffix in ['.c', '.h'] and (p.name.startswith('native_rc') or p.name in ['native_text.c','native_text.h','native_heap.h','native_object.h']):
            shutil.copy2(p, dest/p.name)

def view(side):
    s = (base/'runtime-source'/side/'native_text.c').read_text()
    start = s.index('static myl_native_text *view(')
    return s[start:s.index('\n}',start)+2]
assert view('control') == view('candidate')
summary['text_ops']['view_source_identical'] = True

hist = {}
for label in ['main', 'repeat', 'pad']:
    sides = {s:collections.Counter(int(l.split(None,2)[1].replace(',','')) for l in (base/'text_ops'/f'{s}-{label}.txt').read_text().splitlines()[1:]) for s in ['control','candidate']}
    rows = [{'executions':n,'control_instruction_sites':sides['control'][n],'candidate_instruction_sites':sides['candidate'][n], 'delta':n*(sides['candidate'][n]-sides['control'][n])} for n in sorted(sides['control'].keys()|sides['candidate'].keys(),reverse=True) if sides['candidate'][n]!=sides['control'][n]]
    hist[label] = {'instruction_execution_histogram_difference':rows,'delta':sum(r['delta'] for r in rows)}
assert hist['main']['delta'] == 3_514_237
assert hist['repeat']['delta'] == 971_420
assert hist['pad']['delta'] == 3*142_856
summary['text_ops']['guest_path_histograms'] = hist

orig = base/'original-results'
orig.mkdir(exist_ok=True)
for tag in ['m17-codex','phase-b-zero-combined']:
    for size in ['dev','smoke','full']:
        name = f'results-{tag}-{size}.json'
        shutil.copy2(root/'.tmp-rc-quick'/name,orig/name)

# Keep imported parser/verifier sources alongside the raw harnesses.
helpers = base/'helper-source'
helpers.mkdir(exist_ok=True)
for name in ['profile.py','analyze.py']:
    shutil.copy2(base.parent/'alloc-churn-attribution'/name,helpers/name)
(base/'proof-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
