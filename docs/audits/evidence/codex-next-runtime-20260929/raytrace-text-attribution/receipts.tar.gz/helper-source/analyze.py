import collections, difflib, json, re
from pathlib import Path
work = Path(__file__).resolve().parent

def parse(side):
    self_counts, calls, instruction_counts = collections.Counter(), collections.Counter(), collections.defaultdict(collections.Counter)
    obj = fn = callee = None
    in_call = False
    total = None
    for line in (work / side / 'callgrind.out').read_text().splitlines():
        if line.startswith('summary: '): total = int(line.split()[1])
        elif line.startswith('ob='): obj = line[3:]
        elif line.startswith('fn='): fn = line[3:]
        elif line.startswith('cfn='): callee = line[4:]
        elif line.startswith('calls='):
            calls[fn, callee] += int(line[6:].split()[0])
            in_call = True
        elif line.startswith('0x'):
            fields = line.split()
            if in_call:
                in_call = False
            elif len(fields) == 3:
                self_counts[fn] += int(fields[2])
                instruction_counts[fn][int(fields[0], 16)] += int(fields[2])
    assert sum(self_counts.values()) == total
    return {'total': total, 'self': dict(self_counts), 'calls': [{'caller': f, 'callee': c, 'count': n} for (f,c),n in calls.items()], 'instructions': {f: {hex(a): n for a,n in counts.items()} for f,counts in instruction_counts.items()}}

def instructions(side, fn):
    text = (work / side / 'assembly').read_text()
    block = text.split('<' + fn + '>:\n', 1)[1].split('\n\n', 1)[0]
    result = []
    for line in block.splitlines():
        match = re.match(r'\s*([0-9a-f]+):\s*(.*)', line)
        if match:
            instr = match[2]
            # Normalize relocated branches/calls, preserving symbol and offset.
            instr = re.sub(r'\b[0-9a-f]+ <', '<', instr)
            result.append(instr)
    return result

data = {side: parse(side) for side in ['control', 'candidate']}
delta = [{'function': fn, 'control': data['control']['self'].get(fn,0), 'candidate': data['candidate']['self'].get(fn,0), 'delta': data['candidate']['self'].get(fn,0)-data['control']['self'].get(fn,0)} for fn in data['control']['self'].keys() | data['candidate']['self'].keys()]
delta.sort(key=lambda row: abs(row['delta']), reverse=True)
regions = {'control': [(0x100b330,0x100bb54,'create/ownership before append'), (0x100bb54,0x100be20,'append loop including readiness checks'), (0x100be20,0x100ef80,'fold/release and cold paths')], 'candidate': [(0x100d570,0x100dddb,'create/ownership before append'), (0x100dddb,0x100defe,'append loop including readiness checks'), (0x100defe,0x100ee60,'fold/release and cold paths')]}
region_counts = {}
for side, rs in regions.items():
    items = data[side]['instructions']['entry_run']
    region_counts[side] = [{'region': label, 'start': hex(start), 'end_exclusive': hex(end), 'instructions':sum(n for a,n in items.items() if start <= int(a,16) < end)} for start,end,label in rs]
    assert sum(r['instructions'] for r in region_counts[side]) == data[side]['self']['entry_run']
result = {'control': data['control'], 'candidate': data['candidate'], 'total_delta': data['candidate']['total']-data['control']['total'], 'function_deltas': delta, 'guest_region_counts': region_counts}
(work / 'exact-counts.json').write_text(json.dumps(result,indent=2)+'\n')
out = []
for fn in ['myl_rc_edge_release', 'myl_rc_hold_edge_release', 'myl_rc_storage_retire', 'drain_one']:
    out.extend(difflib.unified_diff(instructions('control', fn), instructions('candidate', fn), fromfile='control/' + fn, tofile='candidate/' + fn, lineterm=''))
(work / 'native-paths.diff').write_text('\n'.join(out)+'\n')
print(json.dumps({'total_delta':result['total_delta'], 'function_deltas':delta[:20], 'guest_region_counts':region_counts},indent=2))
