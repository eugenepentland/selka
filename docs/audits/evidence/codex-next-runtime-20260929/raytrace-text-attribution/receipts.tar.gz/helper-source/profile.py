import collections, hashlib, json, os, struct, subprocess
from pathlib import Path

work = Path(__file__).resolve().parent
own = work.parents[1]
env = {k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env.update(TMPDIR=str(own / '.tmp'), MYLANG_MEMORY_LIMIT='4G')

def allocated(path):
    data = path.read_bytes()
    hdr = struct.unpack_from('<16sHHIQQQIHHHHHH', data)
    assert hdr[0][:6] == b'\x7fELF\x02\x01'
    sections = [struct.unpack_from('<IIQQQQIIQQ', data, hdr[6]+n*hdr[11]) for n in range(hdr[12])]
    names = sections[hdr[13]]
    names = data[names[4]:names[4]+names[5]]
    result = {}
    for section in sections:
        if section[2] & 2:
            name = names[section[0]:].split(b'\0', 1)[0].decode()
            payload = b'' if section[1] == 8 else data[section[4]:section[4]+section[5]]
            result[name] = (section[1], section[2], section[3], section[5], hashlib.sha256(payload).hexdigest())
    return result

receipt = {'cpu': 0, 'event': 'cpu_core/instructions/upp', 'period': 20003, 'interpretation': 'Hardware retired-instruction samples are statistical attribution, not exact routine/basic-block counts.', 'sides': {}}
for side in ['control', 'candidate']:
    dest = work / side
    frozen = dest / 'parity-micro-alloc_churn.llvm'
    symbols = dest / 'alloc_churn.symbols'
    original, named = allocated(frozen), allocated(symbols)
    assert original == named, {k:(original.get(k), named.get(k)) for k in original.keys() | named.keys() if original.get(k) != named.get(k)}
    stats = ['taskset', '-c', '0', 'perf', 'stat', '-x,', '-e', 'cpu_core/instructions/u', '-o', str(dest / 'stat.csv'), '--', str(frozen)]
    recording = ['taskset', '-c', '0', 'perf', 'record', '-e', receipt['event'], '-c', str(receipt['period']), '-o', str(dest / 'perf.data'), '--', str(symbols)]
    item = {'allocated_sections_equal': True, 'allocated_sections': original, 'stat_command': stats, 'profile_command': recording,
            'stat_admission_command': [str(own / 'scripts/build-slot.sh'), 'build', *stats],
            'profile_admission_command': [str(own / 'scripts/build-slot.sh'), 'build', *recording]}
    receipt['sides'][side] = item
    for label, command in [('stat', stats), ('record', recording)]:
        print(side, label, flush=True)
        wrapped = [str(own / 'scripts/build-slot.sh'), 'build', *command]
        done = subprocess.run(wrapped, cwd=own, env=env, capture_output=True)
        (dest / (label + '.stdout')).write_bytes(done.stdout)
        (dest / (label + '.stderr')).write_bytes(done.stderr)
        item[label + '_status'] = done.returncode
        assert done.returncode == 0, done.stderr.decode(errors='replace')
        (work / 'profile-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    script = subprocess.check_output(['perf', 'script', '-i', str(dest / 'perf.data'), '-F', 'ip,sym,dso,period'], cwd=own, env=env)
    (dest / 'perf.script').write_bytes(script)
    report = subprocess.check_output(['perf', 'report', '-i', str(dest / 'perf.data'), '--stdio', '--no-children', '--sort', 'symbol,dso', '--percent-limit', '0.01'], cwd=own, env=env)
    (dest / 'perf.report').write_bytes(report)
    totals = collections.Counter()
    for line in script.decode().splitlines():
        fields = line.strip().split()
        if len(fields) >= 4 and fields[0].isdigit():
            totals[fields[2]] += int(fields[0])
    item['weighted_symbol_samples'] = dict(totals.most_common())
    print(side, 'profile complete', sum(totals.values()), flush=True)
    (work / 'profile-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
