#include "native_rc_internal.h"
#include <string.h>

#define LOCAL_TRANSFER_FRAMES 8
typedef struct {
    const myl_rc_shape *shape;
    unsigned char *destination;
    const unsigned char *source;
    size_t cursor;
} transfer_frame;
typedef struct {
    const void *source;
    void *destination;
    const myl_rc_descriptor *descriptor;
    size_t cursor;
    unsigned region;
} clone_frame;
typedef struct { const void *source; void *destination; unsigned region; } clone_memo;
typedef struct {
    clone_frame *items;
    size_t count, capacity;
    void **arenas;
    size_t arena_count, arena_capacity;
    struct {
        clone_memo *entries, local[4];
        size_t count, capacity;
        unsigned escaping, semantic;
        struct { void **items; size_t count, capacity; } marks;
    } memo;
} clone_work;
typedef struct {
    myl_native_heap *heap;
    transfer_frame *frames;
    size_t capacity, depth;
    unsigned region;
    myl_rc_transfer mode;
    clone_work *clones;
} transfer_walk;
typedef myl_rc_status (*pointer_action)(transfer_walk *, unsigned char *, const unsigned char *, myl_rc_shape_kind);

static void push(transfer_walk *walk, const myl_rc_shape *shape, unsigned char *destination, const unsigned char *source) {
    if (shape->kind == MYL_RC_SHAPE_NONE) return;
    myl_rc_invariant(walk->depth < walk->capacity);
    walk->frames[walk->depth++] = (transfer_frame){.shape = shape, .destination = destination, .source = source};
}
/* Fallible operations have their own frames. A clone callback may allocate or
 * register another descriptor; it never borrows or resizes these frames. */
static myl_rc_status visit(transfer_walk *walk, const myl_rc_shape *shape, void *destination,
                           const void *source, pointer_action action) {
    walk->depth = 0;
    if (shape->kind == MYL_RC_SHAPE_POINTER || shape->kind == MYL_RC_SHAPE_HOLD_POINTER)
        return action(walk, destination, source, shape->kind);
    if (myl_rc_shallow_admits(shape)) {
        myl_rc_shallow leaves;
        myl_rc_shallow_begin(&leaves, shape, source);
        size_t offset;
        myl_rc_shape_kind kind;
        while (myl_rc_shallow_next(&leaves, &offset, &kind)) {
            myl_rc_status status = action(walk, (unsigned char *)destination + offset,
                                          (const unsigned char *)source + offset, kind);
            if (status != MYL_RC_OK) return status;
        }
        return MYL_RC_OK;
    }
    push(walk, shape, destination, source);
    while (walk->depth) {
        transfer_frame *frame = &walk->frames[walk->depth - 1];
        shape = frame->shape;
        if (shape->kind == MYL_RC_SHAPE_POINTER || shape->kind == MYL_RC_SHAPE_HOLD_POINTER) {
            myl_rc_status status = action(walk, frame->destination, frame->source, shape->kind);
            if (status != MYL_RC_OK) { walk->depth = 0; return status; }
            --walk->depth;
        } else if (shape->kind == MYL_RC_SHAPE_ARRAY) {
            if (frame->cursor == shape->as.array.count) { --walk->depth; continue; }
            size_t offset = frame->cursor++ * shape->as.array.stride;
            push(walk, shape->as.array.element, frame->destination + offset, frame->source + offset);
        } else {
            const myl_rc_field *fields = shape->kind == MYL_RC_SHAPE_RECORD ? shape->as.record.fields : shape->as.variant.fields;
            size_t count = shape->kind == MYL_RC_SHAPE_RECORD ? shape->as.record.count : shape->as.variant.count;
            if (frame->cursor == count) { --walk->depth; continue; }
            const myl_rc_field *field = &fields[frame->cursor++];
            if (shape->kind == MYL_RC_SHAPE_VARIANT) {
                uint32_t tag;
                memcpy(&tag, frame->source + shape->as.variant.tag_offset, sizeof tag);
                if (tag != field->tag) continue;
            }
            push(walk, field->shape, frame->destination + field->offset, frame->source + field->offset);
        }
    }
    return MYL_RC_OK;
}
static void *reserve_items(myl_native_heap *heap, void *old, size_t *capacity, size_t used, size_t width) {
    if (used < *capacity) return old;
    size_t grown = *capacity ? *capacity * 2 : 16, bytes;
    if (grown < *capacity || !myl_rc_size_mul(grown, width, &bytes)) return NULL;
    void *items = myl_rc_meta_alloc(heap, bytes);
    if (!items) return NULL;
    if (used) memcpy(items, old, used * width);
    myl_rc_meta_free(heap, old, *capacity * width);
    *capacity = grown;
    return items;
}
/* No mark is visible before all ownership acquisitions and clone filling
 * succeed. A failed transfer discards this journal before any cleanup callback. */
static myl_rc_status queue_mark(transfer_walk *walk, void *payload) {
    if (!walk->clones->memo.semantic || !payload) return MYL_RC_OK;
    myl_native_object *header = (myl_native_object *)payload - 1;
    if (header->mark & (MYL_NATIVE_OBJECT_IMMORTAL | MYL_NATIVE_OBJECT_SHARED)) return MYL_RC_OK;
    if (!myl_rc_native_mutable(payload)) return MYL_RC_OK;
    myl_rc_invariant(!(header->mark & MYL_NATIVE_OBJECT_PINNED));
    clone_work *work = walk->clones;
    void **items = reserve_items(walk->heap, work->memo.marks.items, &work->memo.marks.capacity,
                                work->memo.marks.count, sizeof(void *));
    if (!items) return MYL_RC_ALLOCATION_REFUSED;
    work->memo.marks.items = items;
    items[work->memo.marks.count++] = payload;
    return MYL_RC_OK;
}
static void finish_marks(transfer_walk *walk, int success) {
    clone_work *work = walk->clones;
    if (success)
        for (size_t i = 0; i < work->memo.marks.count; ++i)
            ((myl_native_object *)work->memo.marks.items[i] - 1)->mark |= MYL_NATIVE_OBJECT_SHARED;
    work->memo.marks.count = 0;
}
static size_t payload_count(const void *payload) {
    uintptr_t mark = ((const myl_native_object *)payload - 1)->mark;
    return (mark >> MYL_NATIVE_OBJECT_COUNT_SHIFT) &
        (mark & MYL_NATIVE_OBJECT_ARENA ? MYL_NATIVE_ARENA_COUNT_MAX : MYL_NATIVE_OBJECT_COUNT_MAX);
}
static size_t memo_at(const clone_memo *entries, size_t capacity, const void *source, unsigned region) {
    uintptr_t hash = ((uintptr_t)source >> 4) ^ ((uintptr_t)region * UINT64_C(0x9e3779b97f4a7c15));
    /* Arena chunks and allocator size classes can align low address bits
     * across long runs. Mix the complete address before masking a power-of-two
     * table; a half-full table alone does not prevent quadratic clustering. */
    hash = (hash ^ (hash >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
    hash = (hash ^ (hash >> 27)) * UINT64_C(0x94d049bb133111eb);
    hash ^= hash >> 31;
    size_t at = (size_t)hash & (capacity - 1);
    while (entries[at].source && (entries[at].source != source || entries[at].region != region))
        at = (at + 1) & (capacity - 1);
    return at;
}
static void *memo_find(const clone_work *work, const void *source, unsigned region) {
    if (work->memo.capacity) {
        size_t at = memo_at(work->memo.entries, work->memo.capacity, source, region);
        return work->memo.entries[at].destination;
    }
    for (size_t i = 0; i < work->memo.count; ++i)
        if (work->memo.local[i].source == source && work->memo.local[i].region == region) return work->memo.local[i].destination;
    return NULL;
}
static myl_rc_status memo_reserve(transfer_walk *walk) {
    clone_work *work = walk->clones;
    if (!work->memo.capacity && work->memo.count < 4) return MYL_RC_OK;
    if (work->memo.capacity && work->memo.count < work->memo.capacity / 2) return MYL_RC_OK;
    size_t capacity = work->memo.capacity ? work->memo.capacity * 2 : 32, bytes;
    if (capacity < work->memo.capacity || !myl_rc_size_mul(capacity, sizeof(clone_memo), &bytes)) return MYL_RC_ALLOCATION_REFUSED;
    clone_memo *entries = myl_rc_meta_alloc(walk->heap, bytes);
    if (!entries) return MYL_RC_ALLOCATION_REFUSED;
    const clone_memo *old = work->memo.capacity ? work->memo.entries : work->memo.local;
    size_t count = work->memo.capacity ? work->memo.capacity : work->memo.count;
    for (size_t i = 0; i < count; ++i)
        if (old[i].source) entries[memo_at(entries, capacity, old[i].source, old[i].region)] = old[i];
    myl_rc_meta_free(walk->heap, work->memo.entries, work->memo.capacity * sizeof(clone_memo));
    work->memo.entries = entries;
    work->memo.capacity = capacity;
    return MYL_RC_OK;
}
static void memo_insert(clone_work *work, const void *source, void *destination, unsigned region) {
    clone_memo *entry = work->memo.capacity ?
        &work->memo.entries[memo_at(work->memo.entries, work->memo.capacity, source, region)] : &work->memo.local[work->memo.count];
    *entry = (clone_memo){source, destination, region};
    ++work->memo.count;
}
static myl_rc_status schedule_clone(transfer_walk *walk, const void *payload, unsigned region, void **out) {
    *out = NULL;
    clone_work *work = walk->clones;
    /* Each semantic pinned mutable occurrence is a distinct GC snapshot.
     * Reusing its fresh shell would let a later live view observe a detach
     * caused only by that hidden physical alias. Immutable boxes and physical
     * escape transactions retain the DAG memo. */
    int memoized = !work->memo.semantic || !myl_rc_native_mutable(payload);
    void *known = memoized ? memo_find(work, payload, region) : NULL;
    if (known) {
        myl_rc_status status = myl_rc_owner_take(walk->heap, known);
        if (status != MYL_RC_OK) return status;
        if (region && !work->memo.semantic) ((myl_native_object *)known - 1)->mark |= MYL_NATIVE_OBJECT_SHARED;
        *out = known;
        return MYL_RC_OK;
    }
    if (memoized) {
        myl_rc_status reserved = memo_reserve(walk);
        if (reserved != MYL_RC_OK) return reserved;
    }
    const myl_native_object *common = (const myl_native_object *)payload - 1;
    const myl_rc_binding *binding = myl_rc_binding_find(walk->heap, common->element);
    myl_rc_invariant(binding && !binding->descriptor.finalize);
    const myl_rc_descriptor *descriptor = &binding->descriptor;
    myl_rc_invariant(descriptor->shell || descriptor->edges == NULL);
    int pending = descriptor->next || (!descriptor->shell && descriptor->shape->kind != MYL_RC_SHAPE_NONE);
    if (pending) {
        clone_frame *items = reserve_items(walk->heap, work->items, &work->capacity, work->count, sizeof *items);
        if (!items) return MYL_RC_ALLOCATION_REFUSED;
        work->items = items;
    }
    if (region) {
        void **arenas = reserve_items(walk->heap, work->arenas, &work->arena_capacity, work->arena_count, sizeof *arenas);
        if (!arenas) return MYL_RC_ALLOCATION_REFUSED;
        work->arenas = arenas;
    }
    void *copy = NULL;
    myl_rc_status status;
    if (descriptor->shell) status = descriptor->shell(walk->heap, payload, region, &copy);
    else {
        myl_rc_alloc_request request = {.element = common->element, .count = payload_count(payload), .region = region};
        status = myl_rc_new(walk->heap, &request, &copy);
        if (status == MYL_RC_OK) myl_rc_value_seed(walk->heap, descriptor->shape, copy, payload, request.count);
    }
    if (status != MYL_RC_OK) return status;
    myl_rc_invariant(copy != NULL);
    if (memoized) memo_insert(work, payload, copy, region);
    MYL_RC_STAT(walk->heap, MYL_RC_STAT_CLONE);
    if (pending)
        work->items[work->count++] = (clone_frame){.source = payload, .destination = copy, .descriptor = descriptor, .region = region};
    if (region) work->arenas[work->arena_count++] = copy;
    *out = copy;
    return MYL_RC_OK;
}
/* H-token escape preserves live identity in the same/older region. Only a
 * younger arena referent needs a snapshot: its fresh O becomes H before the
 * ordinary owner is released, so a hold-only shell survives staged filling. */
static myl_rc_status transfer_hold(transfer_walk *walk, unsigned char *destination, void *payload) {
    void *result = payload;
    unsigned region = payload ? myl_native_header_region(payload) : 0;
    if (region > walk->region) {
        if (!walk->clones->memo.escaping) return MYL_RC_REGION_ERROR;
        myl_rc_status status = schedule_clone(walk, payload, walk->region, &result);
        if (status != MYL_RC_OK) return status;
        myl_rc_hold hold = {0};
        status = myl_rc_hold_acquire(walk->heap, result, &hold);
        myl_rc_owner_release(walk->heap, result);
        if (status != MYL_RC_OK) return status;
    } else if (walk->mode == MYL_RC_COPY) {
        myl_rc_hold hold = {0};
        myl_rc_status status = myl_rc_hold_acquire(walk->heap, result, &hold);
        if (status != MYL_RC_OK) return status;
    }
    memcpy(destination, &result, sizeof result);
    return MYL_RC_OK;
}
static myl_rc_status transfer_pointer(transfer_walk *walk, unsigned char *destination,
                                       const unsigned char *source, myl_rc_shape_kind kind) {
    void *payload, *result;
    memcpy(&payload, source, sizeof payload);
    if (kind == MYL_RC_SHAPE_HOLD_POINTER) return transfer_hold(walk, destination, payload);
    result = payload;
    if (payload) {
        myl_native_object *common = (myl_native_object *)payload - 1;
        uintptr_t mark = common->mark;
        if (!(mark & MYL_NATIVE_OBJECT_IMMORTAL)) {
            unsigned region = mark & MYL_NATIVE_OBJECT_ARENA ? myl_native_header_region(payload) : 0;
            if (region > walk->region && !walk->clones->memo.escaping) return MYL_RC_REGION_ERROR;
            if ((mark & MYL_NATIVE_OBJECT_PINNED) || region > walk->region) {
                unsigned target = walk->clones->memo.semantic && region < walk->region ? region : walk->region;
                myl_rc_status status = schedule_clone(walk, payload, target, &result);
                if (status != MYL_RC_OK) return status;
            } else {
                myl_rc_status status = queue_mark(walk, payload);
                if (status != MYL_RC_OK) return status;
                if (walk->mode == MYL_RC_COPY) {
                    if (region && !walk->clones->memo.semantic) common->mark |= MYL_NATIVE_OBJECT_SHARED;
                    else if (!region) {
                        status = myl_rc_owner_take(walk->heap, payload);
                        if (status != MYL_RC_OK) return status;
                    }
                }
            }
        }
    }
    memcpy(destination, &result, sizeof result);
    return MYL_RC_OK;
}
static void transfer_release(myl_native_heap *heap, void *payload, myl_rc_shape_kind kind) {
    if (kind == MYL_RC_SHAPE_HOLD_POINTER) {
        myl_rc_hold hold = {.payload = payload};
        myl_rc_hold_release(heap, &hold);
    } else myl_rc_edge_release(heap, payload);
}
/* In a TAKE staging value only differing pointers are new clone tokens. The
 * unchanged words still borrow the source tokens until the transaction commits. */
static myl_rc_status rollback_take(transfer_walk *walk, unsigned char *destination, const unsigned char *source, myl_rc_shape_kind kind) {
    void *old, *fresh;
    memcpy(&old, source, sizeof old);
    memcpy(&fresh, destination, sizeof fresh);
    if (old != fresh) transfer_release(walk->heap, fresh, kind);
    return MYL_RC_OK;
}
static myl_rc_status commit_take(transfer_walk *walk, unsigned char *destination, const unsigned char *source, myl_rc_shape_kind kind) {
    void *old, *fresh;
    memcpy(&old, source, sizeof old);
    memcpy(&fresh, destination, sizeof fresh);
    if (old != fresh) transfer_release(walk->heap, old, kind);
    return MYL_RC_OK;
}
/* Every operation starts with eight uninitialized automatic frames. Only
 * deeper shapes own charged heap storage; capacity distinguishes the two.
 * There is no maximum depth, and callbacks retain independent frame storage. */
static myl_rc_status prepare_frames(transfer_walk *walk, const myl_rc_shape *shape) {
    myl_rc_checked(myl_rc_shape_find(walk->heap, shape) == shape);
    size_t needed = myl_rc_registered_depth(shape), bytes;
    if (needed <= 1 || needed <= walk->capacity) return MYL_RC_OK;
    myl_rc_invariant(!walk->depth);
    myl_rc_invariant(myl_rc_size_mul(needed, sizeof(transfer_frame), &bytes));
    transfer_frame *frames = myl_rc_meta_alloc(walk->heap, bytes);
    if (!frames) return MYL_RC_ALLOCATION_REFUSED;
    if (walk->capacity > LOCAL_TRANSFER_FRAMES)
        myl_rc_meta_free(walk->heap, walk->frames, walk->capacity * sizeof *frames);
    walk->frames = frames;
    walk->capacity = needed;
    return MYL_RC_OK;
}
static int clone_next(transfer_walk *walk, clone_frame *frame, myl_rc_slot *to, myl_rc_slot *from) {
    if (frame->descriptor->next)
        return frame->descriptor->next(walk->heap, frame->source, frame->destination, &frame->cursor, to, from);
    if (frame->cursor == payload_count(frame->source)) return 0;
    const myl_rc_shape *shape = frame->descriptor->shape;
    size_t offset = frame->cursor++ * shape->size;
    *to = (myl_rc_slot){.shape = shape, .address = (unsigned char *)frame->destination + offset,
        .container = frame->destination, .region = frame->region};
    *from = (myl_rc_slot){.shape = shape, .address = (unsigned char *)frame->source + offset,
        .container = (void *)frame->source};
    return 1;
}
/* Child-only events preserve the outer identity unless a protected child
 * requires replacement. Scan without changing the source, then fill a fresh
 * outer shell if needed; this also safely implements the fresh-result mode. */
static myl_rc_status inspect_child(transfer_walk *walk, unsigned char *destination,
                                     const unsigned char *source, myl_rc_shape_kind kind) {
    (void)destination;
    if (kind == MYL_RC_SHAPE_HOLD_POINTER) return MYL_RC_OK;
    void *payload;
    memcpy(&payload, source, sizeof payload);
    if (!payload) return MYL_RC_OK;
    uintptr_t mark = ((const myl_native_object *)payload - 1)->mark;
    if (mark & MYL_NATIVE_OBJECT_PINNED) { walk->clones->memo.semantic |= 4u; return MYL_RC_OK; }
    return queue_mark(walk, payload);
}
static myl_rc_status transfer_children(transfer_walk *walk, void *destination, const void *source) {
    void *payload, *result;
    memcpy(&payload, source, sizeof payload);
    result = payload;
    if (payload) {
        unsigned region = myl_native_header_region(payload);
        if (region > walk->region) return MYL_RC_REGION_ERROR;
        const myl_native_object *header = (const myl_native_object *)payload - 1;
        const myl_rc_binding *binding = myl_rc_binding_find(walk->heap, header->element);
        myl_rc_invariant(binding && !binding->descriptor.finalize);
        const myl_rc_descriptor *descriptor = &binding->descriptor;
        clone_frame frame = {.source=payload,.destination=payload,.descriptor=descriptor,.region=region};
        myl_rc_slot to, from;
        while (descriptor->next && clone_next(walk, &frame, &to, &from)) {
            const myl_rc_shape *shape = myl_rc_shape_find(walk->heap, from.shape);
            myl_rc_invariant(shape != NULL);
            myl_rc_status status = prepare_frames(walk, shape);
            if (status != MYL_RC_OK) return status;
            status = visit(walk, shape, from.address, from.address, inspect_child);
            if (status != MYL_RC_OK) return status;
        }
        unsigned pinned = walk->clones->memo.semantic & 4u;
        walk->clones->memo.semantic &= ~4u;
        if (pinned) {
            myl_rc_status status = schedule_clone(walk, payload, region, &result);
            if (status != MYL_RC_OK) return status;
        } else if (walk->mode == MYL_RC_COPY) {
            myl_rc_status status = myl_rc_owner_take(walk->heap, payload);
            if (status != MYL_RC_OK) return status;
        }
    }
    memcpy(destination, &result, sizeof result);
    return MYL_RC_OK;
}
/* A clone frame finishes one direct value before resuming its next cursor.
 * New pinned children append frames; no clone calls copy recursively. Every
 * shell (and the generic body copy) seeds its destination, so each yielded
 * pair already holds the source bytes with empty edges. */
/* Fill one contiguous run of seeded pairs. The frame stack may grow (pinned
 * children schedule clones) and is not touched here; children scheduled by
 * any element are filled after the run, which only reorders filling. */
static myl_rc_status finish_span(transfer_walk *walk, const myl_rc_slot *to, const myl_rc_slot *from, size_t count) {
    const myl_rc_shape *shape = myl_rc_shape_find(walk->heap, from->shape);
    myl_rc_invariant(shape && to->shape && to->shape->size == shape->size);
    myl_rc_status status = prepare_frames(walk, shape);
    if (status != MYL_RC_OK) return status;
    walk->region = to->region;
    unsigned char *destination = to->address;
    const unsigned char *source = from->address;
    int shallow = myl_rc_shallow_admits(shape);
    for (size_t i = 0; i < count; ++i, destination += shape->size, source += shape->size) {
        if (shallow) {
            myl_rc_shallow leaves;
            myl_rc_shallow_begin(&leaves, shape, source);
            size_t offset;
            myl_rc_shape_kind kind;
            while (myl_rc_shallow_next(&leaves, &offset, &kind)) {
                status = transfer_pointer(walk, destination + offset, source + offset, kind);
                if (status != MYL_RC_OK) return status;
            }
        } else {
            status = visit(walk, shape, destination, source, transfer_pointer);
            if (status != MYL_RC_OK) return status;
        }
    }
    return MYL_RC_OK;
}
static myl_rc_status finish_clones(transfer_walk *walk) {
    clone_work *work = walk->clones;
    walk->mode = MYL_RC_COPY;
    while (work->count) {
        myl_rc_slot to, from;
        clone_frame *frame = &work->items[work->count - 1];
        if (frame->descriptor->span) {
            size_t count = 0;
            if (!frame->descriptor->span(walk->heap, frame->source, frame->destination, &frame->cursor, &to, &from, &count)) {
                --work->count;
                continue;
            }
            myl_rc_status status = finish_span(walk, &to, &from, count);
            if (status != MYL_RC_OK) return status;
            continue;
        }
        if (!clone_next(walk, frame, &to, &from)) { --work->count; continue; }
        const myl_rc_shape *shape = myl_rc_shape_find(walk->heap, from.shape);
        myl_rc_invariant(shape && to.shape && to.shape->size == shape->size);
        myl_rc_status status = prepare_frames(walk, shape);
        if (status != MYL_RC_OK) return status;
        walk->region = to.region;
        status = visit(walk, shape, to.address, from.address, transfer_pointer);
        if (status != MYL_RC_OK) return status;
    }
    return MYL_RC_OK;
}
static void dispose_walk(transfer_walk *walk, int failed) {
    clone_work *work = walk->clones;
    if (failed)
        for (size_t i = 0; i < work->arena_count; ++i)
            myl_rc_construction_abort(walk->heap, work->arenas[i]);
    myl_rc_meta_free(walk->heap, work->memo.marks.items, work->memo.marks.capacity * sizeof(void *));
    myl_rc_meta_free(walk->heap, work->arenas, work->arena_capacity * sizeof *work->arenas);
    myl_rc_meta_free(walk->heap, work->memo.entries, work->memo.capacity * sizeof(clone_memo));
    myl_rc_meta_free(walk->heap, work->items, work->capacity * sizeof *work->items);
    if (walk->capacity > LOCAL_TRANSFER_FRAMES)
        myl_rc_meta_free(walk->heap, walk->frames, walk->capacity * sizeof *walk->frames);
    myl_rc_drain(walk->heap);
}
static myl_rc_status clone_payload(myl_native_heap *heap, const void *payload, unsigned region, void **out, int box) {
    clone_work work = {0};
    uintptr_t source_mark = ((const myl_native_object *)payload - 1)->mark;
    work.memo.semantic = box || ((source_mark & MYL_NATIVE_OBJECT_SHARED) && myl_rc_native_mutable(payload));
    unsigned origin = myl_native_header_region(payload);
    if (work.memo.semantic && origin < region) region = origin;
    transfer_frame local[LOCAL_TRANSFER_FRAMES];
    transfer_walk walk = {.heap = heap, .frames = local, .capacity = LOCAL_TRANSFER_FRAMES,
        .clones = &work, .region = region, .mode = MYL_RC_COPY};
    void *copy = NULL;
    myl_rc_status status = schedule_clone(&walk, payload, region, &copy);
    if (status == MYL_RC_OK) status = finish_clones(&walk);
    finish_marks(&walk, status == MYL_RC_OK);
    if (status != MYL_RC_OK && copy && !region) myl_rc_owner_release(heap, copy);
    dispose_walk(&walk, status != MYL_RC_OK);
    *out = status == MYL_RC_OK ? copy : NULL;
    return status;
}
/* A single unpinned edge cannot create a clone journal or partially acquired
 * aggregate. Validate before publishing; only pinned/escaping values need the
 * general transaction. The negative result is private, never a runtime status. */
static int pointer_fast(myl_native_heap *heap, void *destination, void *source,
                        unsigned region, myl_rc_transfer mode) {
    myl_rc_invariant(heap && heap->rc && destination && source && destination != source);
    if (region > heap->region_depth) return MYL_RC_REGION_ERROR;
    myl_rc_status status = MYL_RC_OK;
    void *payload;
    memcpy(&payload, source, sizeof payload);
    if (payload) {
        myl_native_object *common = (myl_native_object *)payload - 1;
        uintptr_t mark = common->mark;
        if (!(mark & MYL_NATIVE_OBJECT_IMMORTAL)) {
            unsigned origin = mark & MYL_NATIVE_OBJECT_ARENA ? myl_native_header_region(payload) : 0;
            if (origin > region) return -1;
            if (mark & MYL_NATIVE_OBJECT_PINNED) return -1;
            if (mode == MYL_RC_COPY) {
                if (origin) common->mark |= MYL_NATIVE_OBJECT_SHARED;
                else status = myl_rc_owner_take(heap, payload);
            }
        }
    }
    if (status == MYL_RC_OK) {
        memcpy(destination, &payload, sizeof payload);
        if (mode == MYL_RC_TAKE) memset(source, 0, sizeof payload);
    } else if (mode == MYL_RC_COPY) memset(destination, 0, sizeof payload);
    if (heap->rc->dead.head) myl_rc_drain(heap);
    return (int)status;
}
/* Semantic (direct-payload) publication of one ordinary pointer: the general
 * transaction's queue_mark/finish_marks commit reduces to marking a reused
 * mutable payload SHARED once its owner acquisition has succeeded. Pinned or
 * younger-region payloads keep the general path; the negative result is
 * private, never a runtime status. */
static int pointer_semantic_fast(myl_native_heap *heap, void *destination, void *source,
                                 unsigned region, myl_rc_transfer mode) {
    myl_rc_invariant(heap && heap->rc && destination && source && destination != source);
    if (region > heap->region_depth) return MYL_RC_REGION_ERROR;
    void *payload;
    memcpy(&payload, source, sizeof payload);
    if (payload) {
        myl_native_object *common = (myl_native_object *)payload - 1;
        uintptr_t mark = common->mark;
        if (!(mark & MYL_NATIVE_OBJECT_IMMORTAL)) {
            unsigned origin = mark & MYL_NATIVE_OBJECT_ARENA ? myl_native_header_region(payload) : 0;
            if (origin > region || (mark & MYL_NATIVE_OBJECT_PINNED)) return -1;
            if (mode == MYL_RC_COPY && !origin) {
                myl_rc_status status = myl_rc_owner_take(heap, payload);
                if (status != MYL_RC_OK) {
                    memset(destination, 0, sizeof payload);
                    myl_rc_drain_pending(heap);
                    return (int)status;
                }
            }
            if (!(mark & MYL_NATIVE_OBJECT_SHARED) && myl_rc_native_mutable(payload))
                common->mark |= MYL_NATIVE_OBJECT_SHARED;
        }
    }
    memcpy(destination, &payload, sizeof payload);
    if (mode == MYL_RC_TAKE) memset(source, 0, sizeof payload);
    myl_rc_drain_pending(heap);
    return MYL_RC_OK;
}
static myl_rc_status transfer(myl_native_heap *heap, myl_rc_slot *destination,
                              const myl_rc_slot *source, myl_rc_transfer mode, unsigned escaping, unsigned semantic) {
    myl_rc_invariant(heap && heap->rc && destination && source && destination->address && source->address);
    const myl_rc_shape *shape = myl_rc_shape_find(heap, source->shape);
    const myl_rc_shape *target = myl_rc_shape_find(heap, destination->shape);
    myl_rc_invariant(shape && target && shape->size == target->size && source->address != destination->address);
    if (destination->region > heap->region_depth) return MYL_RC_REGION_ERROR;
    if (!semantic && shape->kind == MYL_RC_SHAPE_POINTER) {
        int fast = pointer_fast(heap, destination->address, source->address, destination->region, mode);
        if (fast >= 0) return (myl_rc_status)fast;
    }
    if (semantic == 1 && !escaping && shape->kind == MYL_RC_SHAPE_POINTER) {
        int fast = pointer_semantic_fast(heap, destination->address, source->address, destination->region, mode);
        if (fast >= 0) return (myl_rc_status)fast;
    }
    clone_work work = {0};
    work.memo.escaping = escaping;
    work.memo.semantic = semantic;
    transfer_frame local[LOCAL_TRANSFER_FRAMES];
    transfer_walk walk = {.heap = heap, .frames = local, .capacity = LOCAL_TRANSFER_FRAMES,
        .region = destination->region, .mode = mode, .clones = &work};
    myl_rc_status status = prepare_frames(&walk, shape);
    if (status != MYL_RC_OK) return status;
    if (mode == MYL_RC_COPY) myl_rc_value_seed(heap, shape, destination->address, source->address, 1);
    else memcpy(destination->address, source->address, shape->size);
    status = semantic == 2 && shape->kind == MYL_RC_SHAPE_POINTER ?
        transfer_children(&walk, destination->address, source->address) :
        visit(&walk, shape, destination->address, source->address, transfer_pointer);
    if (status == MYL_RC_OK) status = finish_clones(&walk);
    finish_marks(&walk, status == MYL_RC_OK);
    if (status != MYL_RC_OK) {
        if (mode == MYL_RC_COPY) myl_rc_edges_release(heap, shape, destination->address, 1);
        else (void)visit(&walk, shape, destination->address, source->address, rollback_take);
        memset(destination->address, 0, shape->size);
    } else if (mode == MYL_RC_TAKE) {
        (void)visit(&walk, shape, destination->address, source->address, commit_take);
        memset(source->address, 0, shape->size);
    }
    if (status == MYL_RC_OK && escaping) heap->arena.escaped += work.memo.count;
    dispose_walk(&walk, status != MYL_RC_OK);
    return status;
}
myl_rc_status myl_rc_semantic_transfer(myl_native_heap *heap, myl_rc_slot *destination,
                                         const myl_rc_slot *source, myl_rc_transfer mode, unsigned policy) {
    return transfer(heap, destination, source, mode, 0, policy);
}
myl_rc_status myl_rc_pointer_transfer(myl_native_heap *heap, const myl_rc_shape *shape,
                                       void *destination, void *source, unsigned region, myl_rc_transfer mode) {
    int fast = pointer_fast(heap, destination, source, region, mode);
    if (fast >= 0) return (myl_rc_status)fast;
    myl_rc_slot target = {.shape = shape, .address = destination, .region = region};
    myl_rc_slot origin = {.shape = shape, .address = source};
    return transfer(heap, &target, &origin, mode, 0, 0);
}
static myl_rc_status loan_pointer(transfer_walk *walk, unsigned char *destination,
                                   const unsigned char *source, myl_rc_shape_kind kind) {
    (void)kind;
    void *payload;
    memcpy(&payload, source, sizeof payload);
    if (MYL_RC_CHECKED && payload) {
        const myl_native_object *header = (const myl_native_object *)payload - 1;
        const myl_rc_descriptor *descriptor = myl_rc_descriptor_of(walk->heap, header->element);
        myl_rc_invariant((header->mark & MYL_NATIVE_OBJECT_IMMORTAL) || (descriptor && !descriptor->finalize));
    }
    myl_rc_hold hold = {0};
    myl_rc_status status = myl_rc_hold_acquire(walk->heap, payload, &hold);
    if (status == MYL_RC_OK) memcpy(destination, &payload, sizeof payload);
    return status;
}
myl_rc_status myl_rc_loan_copy(myl_native_heap *heap, const myl_rc_shape *source_shape,
                               void *destination, const void *source) {
    myl_rc_invariant(heap && heap->rc && destination && source && destination != source);
    const myl_rc_shape *shape = myl_rc_shape_find(heap, source_shape);
    myl_rc_invariant(shape != NULL);
    uintptr_t dst = (uintptr_t)destination, src = (uintptr_t)source;
    myl_rc_invariant(dst > src ? dst - src >= shape->size : src - dst >= shape->size);
    clone_work work = {0};
    transfer_frame local[LOCAL_TRANSFER_FRAMES];
    transfer_walk walk = {.heap = heap, .frames = local, .capacity = LOCAL_TRANSFER_FRAMES, .clones = &work};
    memset(destination, 0, shape->size);
    myl_rc_status status = prepare_frames(&walk, shape);
    if (status == MYL_RC_OK) {
        myl_rc_value_seed(heap, shape, destination, source, 1);
        status = visit(&walk, shape, destination, source, loan_pointer);
        if (status != MYL_RC_OK) myl_rc_loan_drop(heap, shape, destination);
    }
    dispose_walk(&walk, 0);
    return status;
}
myl_rc_status myl_rc_value_copy(myl_native_heap *heap, myl_rc_slot *destination, const myl_rc_slot *source) {
    return transfer(heap, destination, source, MYL_RC_COPY, 0, 0);
}
myl_rc_status myl_rc_region_escape(myl_native_heap *heap, myl_rc_slot *destination, const myl_rc_slot *source) {
    return transfer(heap, destination, source, MYL_RC_COPY, 1, 0);
}
/* Physical helper publication retains identity. Semantic SHARE was performed
 * by the compiler before this helper, or follows a fresh shallow producer. */
static myl_rc_status retain_pointer(transfer_walk *walk, unsigned char *destination,
                                      const unsigned char *source, myl_rc_shape_kind kind) {
    void *payload;
    memcpy(&payload, source, sizeof payload);
    if (payload && myl_native_header_region(payload) > walk->region) return MYL_RC_REGION_ERROR;
    if (kind == MYL_RC_SHAPE_HOLD_POINTER) return transfer_hold(walk, destination, payload);
    myl_rc_status status = myl_rc_owner_take(walk->heap, payload);
    if (status == MYL_RC_OK) memcpy(destination, &payload, sizeof payload);
    return status;
}
static myl_rc_status copy_many(myl_native_heap *heap, myl_rc_slot *destinations,
                                 const myl_rc_slot *sources, size_t count, int retaining) {

    myl_rc_invariant(heap && heap->rc && (!count || (destinations && sources)));
    clone_work work = {0};
    transfer_frame local[LOCAL_TRANSFER_FRAMES];
    transfer_walk walk = {.heap = heap, .frames = local, .capacity = LOCAL_TRANSFER_FRAMES,
        .mode = MYL_RC_COPY, .clones = &work};
    size_t initialized = 0;
    myl_rc_status status = MYL_RC_OK;
    for (size_t i = 0; i < count; ++i) {
        const myl_rc_shape *shape = myl_rc_shape_find(heap, sources[i].shape);
        const myl_rc_shape *target = myl_rc_shape_find(heap, destinations[i].shape);
        myl_rc_invariant(shape && target && shape->size == target->size && sources[i].address != destinations[i].address);
        if (destinations[i].region > heap->region_depth) { status = MYL_RC_REGION_ERROR; break; }
        status = prepare_frames(&walk, shape);
        if (status != MYL_RC_OK) break;
        myl_rc_value_seed(heap, shape, destinations[i].address, sources[i].address, 1);
        ++initialized;
        walk.region = destinations[i].region;
        status = visit(&walk, shape, destinations[i].address, sources[i].address, retaining ? retain_pointer : transfer_pointer);
        if (status != MYL_RC_OK) break;
    }
    if (status == MYL_RC_OK) status = finish_clones(&walk);
    if (status != MYL_RC_OK)
        for (size_t i = 0; i < initialized; ++i) {
            myl_rc_edges_release(heap, destinations[i].shape, destinations[i].address, 1);
            memset(destinations[i].address, 0, destinations[i].shape->size);
        }
    dispose_walk(&walk, status != MYL_RC_OK);
    return status;
}
myl_rc_status myl_rc_value_copy_many(myl_native_heap *heap, myl_rc_slot *destinations,
                                     const myl_rc_slot *sources, size_t count) {
    return copy_many(heap, destinations, sources, count, 0);
}
myl_rc_status myl_rc_value_retain_many(myl_native_heap *heap, myl_rc_slot *destinations,
                                       const myl_rc_slot *sources, size_t count) {
    return copy_many(heap, destinations, sources, count, 1);
}
myl_rc_status myl_rc_value_take(myl_native_heap *heap, myl_rc_slot *destination, myl_rc_slot *source) {
    return transfer(heap, destination, source, MYL_RC_TAKE, 0, 0);
}
myl_rc_status myl_rc_value_replace(myl_native_heap *heap, myl_rc_slot *destination,
                                   myl_rc_slot *source, myl_rc_transfer mode) {
    myl_rc_invariant(destination && source && destination->shape && source->shape);
    if (destination->address == source->address) return MYL_RC_OK;
    size_t size = destination->shape->size, bytes;
    myl_rc_invariant(size == source->shape->size);
    const myl_rc_shape *shape = myl_rc_shape_find(heap, destination->shape);
    myl_rc_invariant(shape != NULL);
    if (shape->kind == MYL_RC_SHAPE_NONE) {
        memmove(destination->address, source->address, size);
        if (mode == MYL_RC_TAKE) memset(source->address, 0, size);
        return MYL_RC_OK;
    }
    if (!myl_rc_size_mul(size, 2, &bytes)) return MYL_RC_ALLOCATION_REFUSED;
    if (!bytes) return MYL_RC_OK;
    unsigned char local[256];
    unsigned char *storage = bytes <= sizeof local ? local : myl_rc_meta_alloc(heap, bytes);
    if (!storage) return MYL_RC_ALLOCATION_REFUSED;
    myl_rc_slot incoming = *destination;
    incoming.address = storage;
    myl_rc_status status = transfer(heap, &incoming, source, mode, 0, 0);
    if (status == MYL_RC_OK) {
        memcpy(storage + size, destination->address, size);
        memcpy(destination->address, storage, size);
        myl_rc_slot old = *destination;
        old.address = storage + size;
        myl_rc_value_drop(heap, &old);
    }
    if (storage != local) myl_rc_meta_free(heap, storage, bytes);
    return status;
}
static void *slot_payload_kind(myl_native_heap *heap, const myl_rc_slot *slot, myl_rc_shape_kind kind) {
    myl_rc_invariant(slot && slot->address && slot->shape);
    myl_rc_checked(myl_rc_shape_resolve(heap, slot->shape) != NULL);
    myl_rc_invariant(slot->shape->kind == kind && slot->shape->size == sizeof(void *));
    void *payload;
    memcpy(&payload, slot->address, sizeof payload);
    return payload;
}
static void *slot_payload(myl_native_heap *heap, const myl_rc_slot *slot) {
    return slot_payload_kind(heap, slot, MYL_RC_SHAPE_POINTER);
}
static myl_rc_status replace_held(myl_native_heap *heap, myl_rc_slot *slot, void *payload, void *copy) {
    myl_rc_hold replacement = {0};
    myl_rc_status status = myl_rc_hold_acquire(heap, copy, &replacement);
    if (status != MYL_RC_OK) { myl_rc_construction_abort(heap, copy); return status; }
    memcpy(slot->address, &copy, sizeof copy);
    myl_rc_hold previous = {.payload = payload};
    myl_rc_hold_release(heap, &previous);
    myl_rc_owner_release(heap, copy);
    return MYL_RC_OK;
}
static myl_rc_status box_detach(myl_native_heap *heap, myl_rc_slot *slot, unsigned held) {
    void *payload = slot_payload_kind(heap, slot, held ? MYL_RC_SHAPE_HOLD_POINTER : MYL_RC_SHAPE_POINTER);
    if (!payload) return MYL_RC_OK;
    const myl_native_object *header = (const myl_native_object *)payload - 1;
    const myl_rc_binding *binding = myl_rc_binding_find(heap, header->element);
    myl_rc_invariant(binding && !binding->descriptor.finalize && !binding->descriptor.next);
    unsigned region = myl_native_header_region(payload);
    if (region > slot->region) return MYL_RC_REGION_ERROR;
    void *copy = NULL;
    myl_rc_status status = clone_payload(heap, payload, region, &copy, 1);
    if (status != MYL_RC_OK) return status;
    if (held) return replace_held(heap, slot, payload, copy);
    memcpy(slot->address, &copy, sizeof copy);
    myl_rc_owner_release(heap, payload);
    return MYL_RC_OK;
}
myl_rc_status myl_rc_box_detach_owned(myl_native_heap *heap, myl_rc_slot *slot) {
    return box_detach(heap, slot, 0);
}
myl_rc_status myl_rc_box_detach_held(myl_native_heap *heap, myl_rc_slot *slot) {
    return box_detach(heap, slot, 1);
}
myl_rc_status myl_rc_unique_owned(myl_native_heap *heap, myl_rc_slot *slot) {
    void *payload = slot_payload(heap, slot);
    if (myl_rc_unique(heap, payload)) return MYL_RC_OK;
    void *copy = NULL;
    myl_rc_status status = clone_payload(heap, payload, slot->region, &copy, 0);
    if (status != MYL_RC_OK) return status;
    memcpy(slot->address, &copy, sizeof copy);
    myl_rc_owner_release(heap, payload);
    return MYL_RC_OK;
}
myl_rc_status myl_rc_unique_held(myl_native_heap *heap, myl_rc_slot *slot) {
    void *payload = slot_payload_kind(heap, slot, MYL_RC_SHAPE_HOLD_POINTER);
    if (slot->region > heap->region_depth || (payload && myl_native_header_region(payload) > slot->region))
        return MYL_RC_REGION_ERROR;
    if (myl_rc_unique(heap, payload)) return MYL_RC_OK;
    void *copy = NULL;
    myl_rc_status status = clone_payload(heap, payload, slot->region, &copy, 0);
    if (status != MYL_RC_OK) return status;
    return replace_held(heap, slot, payload, copy);
}
myl_rc_status myl_rc_unique_borrow(myl_native_heap *heap, const myl_rc_slot *slot,
                                   const myl_rc_scope *scope, myl_rc_edit *edit) {
    myl_rc_invariant(edit && !edit->payload && !edit->owned);
    myl_rc_invariant(!scope || (scope->active && scope->heap == heap));
    void *payload = slot_payload(heap, slot);
    if (myl_rc_unique(heap, payload)) { edit->payload = payload; return MYL_RC_OK; }
    void *copy = NULL;
    myl_rc_status status = clone_payload(heap, payload, slot->region, &copy, 0);
    if (status != MYL_RC_OK) return status;
    edit->payload = copy;
    edit->owned = 1;
    return MYL_RC_OK;
}
void myl_rc_edit_abort(myl_native_heap *heap, myl_rc_edit *edit) {
    myl_rc_invariant(edit != NULL);
    void *payload = edit->payload;
    unsigned owned = edit->owned;
    *edit = (myl_rc_edit){0};
    if (owned) myl_rc_construction_abort(heap, payload);
}
void myl_rc_edit_commit(myl_native_heap *heap, myl_rc_slot *slot, myl_rc_edit *edit) {
    myl_rc_invariant(edit != NULL);
    void *old = slot_payload(heap, slot);
    if (edit->owned) {
        memcpy(slot->address, &edit->payload, sizeof edit->payload);
        *edit = (myl_rc_edit){0};
        myl_rc_owner_release(heap, old);
    } else {
        myl_rc_invariant(old == edit->payload);
        *edit = (myl_rc_edit){0};
    }
}
