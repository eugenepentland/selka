import hashlib, json, os, subprocess, time
from pathlib import Path
work = Path(__file__).resolve().parent
own = work.parents[1]
tools = work / 'valgrind-local/usr'
env = {k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env.update(TMPDIR=str(own / '.tmp'), MYLANG_MEMORY_LIMIT='4G', VALGRIND_LIB=str(tools / 'libexec/valgrind'))
receipt = {'tool': subprocess.check_output([str(tools / 'bin/valgrind'), '--version'], env=env).decode().strip(), 'tool_deb_sha256': hashlib.sha256(next(work.glob('valgrind_*_amd64.deb')).read_bytes()).hexdigest(), 'measurement': 'Exact simulated retired instruction/basic-block counts on code-identical symbol-preserving counterparts; no system installation.', 'sides': {}}
for side in ['control', 'candidate']:
    dest = work / side
    cmd = [str(own / 'scripts/build-slot.sh'), 'build', 'taskset', '-c', '0', str(tools / 'bin/valgrind'), '--tool=callgrind', '--dump-instr=yes', '--collect-jumps=yes', '--compress-pos=no', '--compress-strings=no', '--callgrind-out-file=' + str(dest / 'callgrind.out'), str(dest / 'alloc_churn.symbols')]
    started = time.monotonic()
    print(side, 'Callgrind starting', flush=True)
    done = subprocess.run(cmd, cwd=own, env=env, capture_output=True)
    (dest / 'callgrind.stdout').write_bytes(done.stdout)
    (dest / 'callgrind.stderr').write_bytes(done.stderr)
    receipt['sides'][side] = {'command': cmd, 'status': done.returncode, 'elapsed_seconds': time.monotonic()-started, 'stdout': done.stdout.decode(errors='replace'), 'stderr': done.stderr.decode(errors='replace')}
    (work / 'callgrind-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(side, 'Callgrind status', done.returncode, flush=True)
    assert done.returncode == 0, done.stderr.decode(errors='replace')
    annotate = subprocess.run([str(tools / 'bin/callgrind_annotate'), '--show=Ir', '--threshold=100', '--auto=no', str(dest / 'callgrind.out')], cwd=own, env=env, capture_output=True)
    (dest / 'callgrind.annotate').write_bytes(annotate.stdout)
    (dest / 'callgrind.annotate.stderr').write_bytes(annotate.stderr)
    assert annotate.returncode == 0
assert receipt['sides']['control']['stdout'] == receipt['sides']['candidate']['stdout']
