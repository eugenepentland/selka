import hashlib, json, os, shutil, subprocess
from pathlib import Path

own = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
root = Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-closeout-20260929')
names = {'control': 'm17-codex', 'candidate': 'phase-b-zero-combined'}
expected = {'control': '668b41ae6dfa9d725523e344c92b321e83f9f2806c9da7a7a62f5bdbb07067bb', 'candidate': 'a96a5b7a53a710808b9de060b95d0838526d94b9ea8c0a8b2b33315371aa0879'}
env = {k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k != 'LD_PRELOAD'}
env.update(ZIG_GLOBAL_CACHE_DIR=str(own / '.zig-global-cache'), ZIG_LOCAL_CACHE_DIR=str(own / '.zig-cache'), TMPDIR=str(own / '.tmp'), MYLANG_MEMORY_LIMIT='4G')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = {'source_sha256': sha(root / 'bench/parity/micro/alloc_churn.my'), 'own_source_sha256': sha(own / 'bench/parity/micro/alloc_churn.my'), 'sides': {}}
assert receipt['source_sha256'] == receipt['own_source_sha256']
for side, tag in names.items():
    src = root / '.tmp-rc-quick/bin' / tag
    dest = work / side
    dest.mkdir(exist_ok=True)
    for filename in ['compiler.json', 'parity-micro-alloc_churn.llvm', 'parity-micro-alloc_churn.llvm.qbe-manifest.json']:
        shutil.copy2(src / filename, dest / filename)
    binary = dest / 'parity-micro-alloc_churn.llvm'
    assert sha(binary) == expected[side]
    compiler = json.loads((dest / 'compiler.json').read_text())
    assert sha(Path(compiler['compiler'])) == compiler['sha256']
    output = dest / 'alloc_churn.symbols'
    argv = [str(own / 'scripts/build-slot.sh'), 'build', compiler['compiler'], 'build', str(root / 'bench/parity/micro/alloc_churn.my'), '-o', str(output), '--backend', 'llvm', '--llvm-opt', '3', '--lto', '--rc-runtime', '--keep-symbols', '--cache-dir', str(dest / 'cache')]
    print(side, 'building symbol-preserving counterpart', flush=True)
    done = subprocess.run(argv, cwd=own, env=env, capture_output=True)
    (dest / 'build.stdout').write_bytes(done.stdout)
    (dest / 'build.stderr').write_bytes(done.stderr)
    record = {'original': str(src / binary.name), 'frozen_sha256': sha(binary), 'compiler': compiler, 'command': argv, 'build_status': done.returncode}
    receipt['sides'][side] = record
    (work / 'inputs.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(side, 'status', done.returncode, flush=True)
    assert done.returncode == 0, done.stderr.decode(errors='replace')
    record['symbol_binary_sha256'] = sha(output)
    for suffix, command in [('symbols', ['nm', '-n', '-S', str(output)]), ('assembly', ['objdump', '-d', '--no-show-raw-insn', str(output)]), ('sections', ['readelf', '-WS', str(output)])]:
        (dest / suffix).write_bytes(subprocess.check_output(command))
    for variant in [binary, output]:
        subprocess.run(['objcopy', '--dump-section', '.text=' + str(dest / (variant.name + '.text')), str(variant)], check=True)
    record['text_identical'] = (dest / (binary.name + '.text')).read_bytes() == (dest / (output.name + '.text')).read_bytes()
    print(side, '.text identical:', record['text_identical'], flush=True)
    (work / 'inputs.json').write_text(json.dumps(receipt, indent=2) + '\n')
