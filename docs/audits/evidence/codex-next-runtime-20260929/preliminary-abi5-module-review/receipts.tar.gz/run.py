from pathlib import Path
import subprocess,hashlib,json,os
root=Path.cwd();lane=root/'.tmp/combined-module-review';inputs=json.loads((lane/'inputs.json').read_text());compiler=inputs['compiler_path'];rows=[]
for mode in ('rc','gc','stats','sites'):
 argv=['scripts/build-slot.sh','build','python3','tests/module_compile_oracle.py',compiler,'tests/fixtures/module_compile/main.my','tests/fixtures/module_rc/main.my','--runtime',mode,'--jobs','2','--keep','--work',str(lane/('runtime-'+mode)),'--json',str(lane/('runtime-'+mode+'.json'))]
 with (lane/('runtime-'+mode+'.log')).open('w') as log:p=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 row={'name':'runtime-'+mode,'argv':argv,'status':p.returncode};rows.append(row);(lane/'status.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(row['name'],p.returncode,flush=True)
 result=json.loads((lane/('runtime-'+mode+'.json')).read_text());print(result['totals'],flush=True)
 if p.returncode:print('FAIL retained; continue independent modes/corpus to classify composition breadth',flush=True)
argv=['scripts/build-slot.sh','build','python3','experiments/module-scale-20260929/corpus_byte.py',compiler,str(lane/'corpus29'),'--lox-entry',str(lane/'lox/main.my'),'--source',inputs['compiler_source'],'--jobs','2','--json',str(lane/'corpus29.json')]
with (lane/'corpus29.log').open('w') as log:p=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
rows.append({'name':'corpus29','argv':argv,'status':p.returncode});(lane/'status.json').write_text(json.dumps(rows,indent=2)+'\n')
print('corpus29',p.returncode,flush=True)
if (lane/'corpus29.json').exists():print(json.loads((lane/'corpus29.json').read_text())['totals'],flush=True)
assert hashlib.sha256(Path(compiler).read_bytes()).hexdigest()==inputs['compiler_sha256'],'frozen compiler changed'
raise SystemExit(any(row['status']!=0 for row in rows))
