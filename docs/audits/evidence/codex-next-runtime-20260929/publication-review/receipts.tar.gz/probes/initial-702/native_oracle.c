#include "qbe_runtime.h"
#include "native_rc_internal.h"
#include "native_rc_alloc.h"
#include "native_rc_collections.h"
#include "native_collections.h"
#include "symbols.h"
#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>

extern int review_owner(void *, void *, void **), review_hold(void *, void *, void **);
extern int review_publish(void *, void *, void **, void **, unsigned, unsigned);
extern const myl_rc_module myl_rc_generated_module;
extern const myl_rc_image myl_rc_generated_image;
extern void direct_owner(myl_native_heap *, void *) __asm__(OWNER_SYMBOL);
extern void direct_hold(myl_native_heap *, void *) __asm__(HOLD_SYMBOL);
extern void real_owner(myl_native_heap *, void *) __asm__("__real_" OWNER_SYMBOL);
extern void real_hold(myl_native_heap *, void *) __asm__("__real_" HOLD_SYMBOL);
static void *expected;
static unsigned final_calls;
void wrapped_owner(myl_native_heap *, void *) __asm__("__wrap_" OWNER_SYMBOL);
void wrapped_owner(myl_native_heap *heap, void *slot) {
    if (expected) {
        assert(*(void **)slot==expected);
        myl_rc_object *o=(myl_rc_object *)expected-1;
        assert(o->owners==1 && !o->holds); ++final_calls;
    }
    real_owner(heap,slot);
}
void wrapped_hold(myl_native_heap *, void *) __asm__("__wrap_" HOLD_SYMBOL);
void wrapped_hold(myl_native_heap *heap, void *slot) {
    if (expected) {
        assert(*(void **)slot==expected);
        myl_rc_object *o=(myl_rc_object *)expected-1;
        assert(!o->owners && o->holds==1); ++final_calls;
    }
    real_hold(heap,slot);
}
static const myl_native_type scalar={.size=8,.alignment=8,.kind=MYL_NATIVE_PLAIN};
static void start(MylQbeContext *ctx) {
    memset(ctx,0,sizeof *ctx); myl_native_heap_init(&ctx->heap,64u<<20);
    assert(ctx->heap.rc);
    assert(myl_rc_module_register_image(&ctx->heap,&myl_rc_generated_module,&myl_rc_generated_image)==MYL_RC_OK);
    assert(myl_rc_list_require(&ctx->heap)==MYL_RC_OK);
}
static void finish(MylQbeContext *ctx) {
    assert(!ctx->heap.objects_live && !ctx->heap.rc->scopes && !ctx->heap.rc->dead.head);
    myl_native_heap_destroy(&ctx->heap); assert(!ctx->heap.bytes);
}
static myl_native_list *list(MylQbeContext *ctx) {
    myl_native_list *p=myl_native_list_new(&ctx->heap,&scalar,1);
    int64_t value=73; assert(p && myl_native_list_append(&ctx->heap,p,&value)); return p;
}
static void zero_case(int hold) {
    const pid_t pid=fork(); assert(pid>=0);
    if (!pid) {
        struct rlimit no_core={0}; setrlimit(RLIMIT_CORE,&no_core);
        struct { myl_rc_object prefix; uint64_t body; } block={0};
        block.prefix.owners=hold ? 1 : 0; block.prefix.holds=hold ? 0 : 1;
        void *slot=&block.prefix+1; myl_native_heap heap={0}; expected=NULL;
        (hold ? direct_hold : direct_owner)(&heap,&slot);
        assert(!slot && (hold ? block.prefix.holds : block.prefix.owners)==UINT64_MAX);
        _exit(0);
    }
    int status; assert(waitpid(pid,&status,0)==pid);
#if defined(MYL_RC_GLUE_CHECKED)
    assert(WIFSIGNALED(status) && WTERMSIG(status)==SIGABRT);
#else
    assert(WIFEXITED(status) && WEXITSTATUS(status)==0);
#endif
}
int main(void) {
    unsigned cases=0;
    zero_case(0); zero_case(1); cases+=2;
    for (int hold=0;hold<2;hold++) {
        MylQbeContext ctx; start(&ctx); myl_native_list *p=list(&ctx);
        myl_rc_object *o=(myl_rc_object *)p-1;
        if (hold) o->owners=0,o->holds=1;
        void *slot=p; expected=p; final_calls=0;
        assert((hold ? review_hold : review_owner)(&ctx,&ctx.heap,&slot));
        assert(!slot && final_calls==1 && !ctx.trap); expected=NULL;
        finish(&ctx); ++cases;
    }
    for (int high=0;high<3;high++) {
        MylQbeContext ctx; start(&ctx); myl_native_list *p=list(&ctx);
        myl_rc_object *o=(myl_rc_object *)p-1;
        o->owners=high==1 ? (UINT64_C(1)<<32)+1 : 1;
        o->holds=high==1 ? 0 : (UINT64_C(1)<<32)+(high==2);
        void *slot=p; final_calls=0;
        assert((high==2 ? review_hold : review_owner)(&ctx,&ctx.heap,&slot));
        assert(!slot && !final_calls && !ctx.trap && ctx.heap.objects_live);
        assert(o->owners==(high==0 ? 0 : high==1 ? (UINT64_C(1)<<32) : 1));
        assert(o->holds==(high==0 ? UINT64_C(1)<<32 : high==1 ? 0 : (UINT64_C(1)<<32)));
        o->owners=1; o->holds=0; myl_rc_owner_release(&ctx.heap,p); finish(&ctx); ++cases;
    }
    {
        MylQbeContext ctx; start(&ctx); myl_native_list *p=list(&ctx);
        myl_rc_object *o=(myl_rc_object *)p-1; const uintptr_t mark=o->common.mark;
        o->owners=UINT64_MAX; void *src=p,*dst=NULL;
        assert(!review_publish(&ctx,&ctx.heap,&dst,&src,0,0));
        assert(ctx.trap && !strcmp(ctx.trap,"R_REFERENCE_COUNT_LIMIT"));
        assert(!dst && src==p && o->owners==UINT64_MAX && !o->holds && o->common.mark==mark);
        o->owners=1; myl_rc_owner_release(&ctx.heap,p); finish(&ctx); ++cases;
    }
    const uint64_t copy_counts[]={(UINT64_C(1)<<32)-1,(UINT64_C(1)<<48)-1,UINT64_MAX-1};
    for(unsigned i=0;i<sizeof copy_counts/sizeof *copy_counts;++i) {
        for(unsigned shared=0;shared<2;++shared) {
            MylQbeContext ctx; start(&ctx); myl_native_list *p=list(&ctx);
            myl_rc_object *o=(myl_rc_object *)p-1;
            o->owners=copy_counts[i]; o->holds=UINT64_C(1)<<48;
            if(shared)o->common.mark|=MYL_NATIVE_OBJECT_SHARED;
            const uintptr_t mark=o->common.mark;
            const size_t bytes=ctx.heap.bytes; void *src=p,*dst=NULL;
            assert(review_publish(&ctx,&ctx.heap,&dst,&src,0,0));
            assert(!ctx.trap && src==p && dst==p && o->owners==copy_counts[i]+1);
            assert(o->holds==(UINT64_C(1)<<48) && o->common.mark==(mark|MYL_NATIVE_OBJECT_SHARED));
            assert(ctx.heap.bytes==bytes);
            o->owners=1;o->holds=0; myl_rc_owner_release(&ctx.heap,p);finish(&ctx);++cases;
        }
    }
    for(unsigned shared=0;shared<2;++shared) {
        MylQbeContext ctx;start(&ctx);myl_native_list *p=list(&ctx);
        myl_rc_object *o=(myl_rc_object *)p-1;o->owners=UINT64_MAX;
        if(shared)o->common.mark|=MYL_NATIVE_OBJECT_SHARED;
        const uintptr_t mark=o->common.mark;void *src=p,*dst=NULL;
        assert(review_publish(&ctx,&ctx.heap,&dst,&src,0,4));
        assert(!ctx.trap && !src && dst==p && o->owners==UINT64_MAX && !o->holds);
        assert(o->common.mark==(mark|MYL_NATIVE_OBJECT_SHARED));
        o->owners=1;myl_rc_owner_release(&ctx.heap,p);finish(&ctx);++cases;
    }
    for (int refuse=0;refuse<2;refuse++) {
        MylQbeContext ctx; start(&ctx); myl_native_list *p=list(&ctx); myl_rc_scope scope={0};
        myl_rc_scope_begin(&ctx.heap,&scope); assert(myl_rc_scope_pin(&scope,p)==MYL_RC_OK);
        myl_rc_object *o=(myl_rc_object *)p-1; const uintptr_t mark=o->common.mark;
        const size_t bytes=ctx.heap.bytes,limit=ctx.heap.limit; void *journal=scope.journal;
        void *src=p,*dst=NULL; if(refuse)ctx.heap.limit=ctx.heap.bytes;
        const int result=review_publish(&ctx,&ctx.heap,&dst,&src,0,0);
        assert(src==p && o->owners==1 && o->holds==1 && o->common.mark==mark && scope.journal==journal);
        if(refuse) {
            assert(!result && !dst && ctx.trap && !strcmp(ctx.trap,"R_MEMORY_BUDGET"));
            assert(ctx.heap.bytes==bytes);
        } else {
            assert(result && !ctx.trap && dst && dst!=p);
            int64_t value=0; assert(myl_native_list_get(dst,0,&value) && value==73);
        }
        ctx.heap.limit=limit; myl_rc_scope_end(&scope);
        myl_rc_owner_release(&ctx.heap,p); if(dst)myl_rc_owner_release(&ctx.heap,dst);
        finish(&ctx); ++cases;
    }
    {
        MylQbeContext ctx; start(&ctx); assert(myl_native_region_begin(&ctx.heap));
        myl_native_list *p=list(&ctx); assert(((myl_native_object *)p-1)->mark&MYL_NATIVE_OBJECT_ARENA);
        void *src=p,*dst=NULL; const uintptr_t mark=((myl_native_object *)p-1)->mark;
        assert(!review_publish(&ctx,&ctx.heap,&dst,&src,0,0));
        assert(!dst && src==p && ctx.trap && !strcmp(ctx.trap,"R_ARENA_ESCAPE"));
        assert(((myl_native_object *)p-1)->mark==mark);
        myl_native_region_end(&ctx.heap); finish(&ctx); ++cases;
    }
    printf("native generated release/publication: %u cases passed (%s zero invariants)\n",cases,
#if defined(MYL_RC_GLUE_CHECKED)
        "checked"
#else
        "unchecked"
#endif
    );
    return 0;
}
