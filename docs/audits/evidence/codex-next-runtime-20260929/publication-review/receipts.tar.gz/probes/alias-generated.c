#include "native_heap.h"
extern const myl_native_type myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0;
extern const myl_native_type myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527;
extern const myl_native_type myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda;
extern const myl_native_type myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9;
extern const myl_native_type myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef;
extern const myl_native_type myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1;
extern const myl_native_type myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80;
extern const myl_native_type myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba;
extern const myl_native_type myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af;
extern const myl_native_type myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e;
extern const myl_native_type myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb;
extern const myl_native_type myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18;
extern const myl_native_type myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde;
extern const myl_native_type myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511;
extern const myl_native_type myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a;
extern const myl_native_type myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded;
extern const myl_native_type myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903;
extern const myl_native_type myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9;
extern const myl_native_type myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b;
extern const myl_native_type myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5;
extern const myl_native_type myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d;
extern const myl_native_type myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc;
extern const myl_native_type myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98;
extern const myl_native_type myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037;
const myl_native_type myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+0,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_POINTER,.collection_kind=1,.element=&myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_FIELDS,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+1,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+2,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_POINTER,.collection_kind=4,.element=&myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_FIELDS,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+3,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef = {.size=2,.alignment=2,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+4,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1 = {.size=0,.alignment=1,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+5,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_RESOURCE,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_FIELDS,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+6,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba = {.size=1,.alignment=1,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+7,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af = {.size=4,.alignment=4,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+8,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+9,.scan=NULL,.scan_count=0};
static const myl_native_field myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_fields[] = {
 {.offset=0,.type=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527,.tag=0},
 {.offset=8,.type=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527,.tag=0},
};
static const myl_native_field myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_trace_fields[] = {
 {.offset=0,.type=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527,.tag=0},
 {.offset=8,.type=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527,.tag=0},
};
static const myl_native_scan_entry myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_scan[] = {
 {.offset=0,.tag_offset=MYL_NATIVE_SCAN_ALWAYS,.tag=0},
 {.offset=8,.tag_offset=MYL_NATIVE_SCAN_ALWAYS,.tag=0},
};
const myl_native_type myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb = {.size=16,.alignment=8,.fields=myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_fields,.field_count=2,.count=1,.stride=0,.kind=MYL_NATIVE_RECORD,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_trace_fields,.trace_field_count=2,.trace_mode=MYL_NATIVE_TRACE_FIELDS,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+10,.scan=myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_scan,.scan_count=2};
static const myl_native_field myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields[] = {
 {.offset=0,.type=&myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0,.tag=0},
};
const myl_native_type myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18 = {.size=8,.alignment=8,.fields=myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_fields,.field_count=1,.count=1,.stride=0,.kind=MYL_NATIVE_FLOAT,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+11,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde = {.size=2,.alignment=2,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+12,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+13,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_POINTER,.collection_kind=2,.element=&myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_FIELDS,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+14,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+15,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903 = {.size=1,.alignment=1,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+16,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+17,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b = {.size=1,.alignment=1,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+18,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+19,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+20,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc = {.size=4,.alignment=4,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+21,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_PLAIN,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_NONE,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+22,.scan=NULL,.scan_count=0};
const myl_native_type myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037 = {.size=8,.alignment=8,.fields=NULL,.field_count=0,.count=1,.stride=0,.kind=MYL_NATIVE_RESOURCE,.collection_kind=0,.element=NULL,.key=NULL,.trace_fields=NULL,.trace_field_count=0,.trace_mode=MYL_NATIVE_TRACE_FIELDS,.cell=0,.rc_id=MYL_RC_ID_FIRST_GENERATED+23,.scan=NULL,.scan_count=0};
#include "native_rc_internal.h"
extern const myl_native_type myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0;
extern const myl_rc_shape myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc;
extern const myl_rc_shape_entry myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc_image_entry;
extern const myl_native_type myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527;
extern const myl_rc_shape myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc;
extern const myl_rc_shape_entry myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc_image_entry;
extern const myl_native_type myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda;
extern const myl_rc_shape myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc;
extern const myl_rc_shape_entry myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc_image_entry;
extern const myl_native_type myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9;
extern const myl_rc_shape myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc;
extern const myl_rc_shape_entry myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc_image_entry;
extern const myl_native_type myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef;
extern const myl_rc_shape myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc;
extern const myl_rc_shape_entry myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc_image_entry;
extern const myl_native_type myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1;
extern const myl_rc_shape myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc;
extern const myl_rc_shape_entry myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc_image_entry;
extern const myl_native_type myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80;
extern const myl_rc_shape myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc;
extern const myl_rc_shape_entry myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc_image_entry;
extern const myl_native_type myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba;
extern const myl_rc_shape myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc;
extern const myl_rc_shape_entry myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc_image_entry;
extern const myl_native_type myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af;
extern const myl_rc_shape myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc;
extern const myl_rc_shape_entry myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc_image_entry;
extern const myl_native_type myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e;
extern const myl_rc_shape myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc;
extern const myl_rc_shape_entry myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc_image_entry;
extern const myl_native_type myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb;
extern const myl_rc_shape myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc;
extern const myl_rc_shape_entry myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc_image_entry;
extern const myl_native_type myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18;
extern const myl_rc_shape myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc;
extern const myl_rc_shape_entry myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_image_entry;
extern const myl_native_type myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde;
extern const myl_rc_shape myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc;
extern const myl_rc_shape_entry myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc_image_entry;
extern const myl_native_type myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511;
extern const myl_rc_shape myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc;
extern const myl_rc_shape_entry myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc_image_entry;
extern const myl_native_type myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a;
extern const myl_rc_shape myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc;
extern const myl_rc_shape_entry myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc_image_entry;
extern const myl_native_type myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded;
extern const myl_rc_shape myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc;
extern const myl_rc_shape_entry myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc_image_entry;
extern const myl_native_type myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903;
extern const myl_rc_shape myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc;
extern const myl_rc_shape_entry myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc_image_entry;
extern const myl_native_type myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9;
extern const myl_rc_shape myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc;
extern const myl_rc_shape_entry myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc_image_entry;
extern const myl_native_type myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b;
extern const myl_rc_shape myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc;
extern const myl_rc_shape_entry myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc_image_entry;
extern const myl_native_type myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5;
extern const myl_rc_shape myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc;
extern const myl_rc_shape_entry myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc_image_entry;
extern const myl_native_type myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d;
extern const myl_rc_shape myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc;
extern const myl_rc_shape_entry myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc_image_entry;
extern const myl_native_type myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc;
extern const myl_rc_shape myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc;
extern const myl_rc_shape_entry myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc_image_entry;
extern const myl_native_type myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98;
extern const myl_rc_shape myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc;
extern const myl_rc_shape_entry myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc_image_entry;
extern const myl_native_type myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037;
extern const myl_rc_shape myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc;
extern const myl_rc_shape_entry myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc_image_entry;
const myl_rc_shape myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc_image_entry = {.source=&myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_RC_IMAGE_DEPTH 1
#define myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0,.shape=&myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc = {.size=8,.kind=MYL_RC_SHAPE_POINTER};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc_image_entry = {.source=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_POINTER},.depth=1,.inline_depth=1};
#define myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_RC_IMAGE_DEPTH 1
#define myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527,.shape=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc_image_entry.shape,.finalize=NULL},.flat={.count=1,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=1,.always=1,.arms={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc_image_entry = {.source=&myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_RC_IMAGE_DEPTH 1
#define myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda,.shape=&myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc = {.size=8,.kind=MYL_RC_SHAPE_POINTER};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc_image_entry = {.source=&myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_POINTER},.depth=1,.inline_depth=1};
#define myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_RC_IMAGE_DEPTH 1
#define myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9,.shape=&myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc_image_entry.shape,.finalize=NULL},.flat={.count=1,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=1,.always=1,.arms={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc = {.size=2,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc_image_entry = {.source=&myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc,.shape={.size=2,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_RC_IMAGE_DEPTH 1
#define myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef,.shape=&myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=2,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc = {.size=0,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc_image_entry = {.source=&myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc,.shape={.size=0,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_RC_IMAGE_DEPTH 1
#define myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1,.shape=&myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=0,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc_image_entry = {.source=&myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_RC_IMAGE_DEPTH 1
#define myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80,.shape=&myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc_image_entry.shape,.finalize=NULL},.flat={.count=17,.loanable=0,.conditional=0,.arm_offset=0,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc = {.size=1,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc_image_entry = {.source=&myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc,.shape={.size=1,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_RC_IMAGE_DEPTH 1
#define myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba,.shape=&myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=1,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc = {.size=4,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc_image_entry = {.source=&myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc,.shape={.size=4,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_RC_IMAGE_DEPTH 1
#define myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af,.shape=&myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=4,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc_image_entry = {.source=&myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_RC_IMAGE_DEPTH 1
#define myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e,.shape=&myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
static const myl_rc_field myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc_fields[] = {
 {.offset=0,.shape=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc,.tag=0},
 {.offset=8,.shape=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc,.tag=0},
};
const myl_rc_shape myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc = {.size=16,.kind=MYL_RC_SHAPE_RECORD,.as.record={.fields=myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc_fields,.count=2}};
/* mylang-rc-image-block-v1 */
static const myl_rc_field myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc_image_fields[] = {
 {.offset=0,.shape=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc_image_entry.shape,.tag=0},
 {.offset=8,.shape=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc_image_entry.shape,.tag=0},
};
const myl_rc_shape_entry myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc_image_entry = {.source=&myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc,.shape={.size=16,.kind=MYL_RC_SHAPE_RECORD,.as.record={.fields=myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc_image_fields,.count=2}},.depth=2,.inline_depth=2};
#define myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_RC_IMAGE_DEPTH 2
#define myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb,.shape=&myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc_image_entry.shape,.finalize=NULL},.flat={.count=2,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=16,.all=3,.always=3,.arms={3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,},.offsets={0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
static const myl_rc_field myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields[] = {
 {.offset=0,.shape=&myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc,.tag=0},
};
const myl_rc_shape myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc = {.size=8,.kind=MYL_RC_SHAPE_RECORD,.as.record={.fields=myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_fields,.count=1}};
/* mylang-rc-image-block-v1 */
static const myl_rc_field myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_image_fields[] = {
 {.offset=0,.shape=&myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc_image_entry.shape,.tag=0},
};
const myl_rc_shape_entry myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_image_entry = {.source=&myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE,.as.record={.fields=myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_image_fields,.count=1}},.depth=0,.inline_depth=2};
#define myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_RC_IMAGE_DEPTH 2
#define myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18,.shape=&myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc = {.size=2,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc_image_entry = {.source=&myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc,.shape={.size=2,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_RC_IMAGE_DEPTH 1
#define myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde,.shape=&myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=2,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc_image_entry = {.source=&myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_RC_IMAGE_DEPTH 1
#define myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511,.shape=&myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc = {.size=8,.kind=MYL_RC_SHAPE_POINTER};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc_image_entry = {.source=&myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_POINTER},.depth=1,.inline_depth=1};
#define myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_RC_IMAGE_DEPTH 1
#define myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a,.shape=&myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc_image_entry.shape,.finalize=NULL},.flat={.count=1,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=1,.always=1,.arms={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc_image_entry = {.source=&myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_RC_IMAGE_DEPTH 1
#define myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded,.shape=&myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc = {.size=1,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc_image_entry = {.source=&myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc,.shape={.size=1,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_RC_IMAGE_DEPTH 1
#define myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903,.shape=&myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=1,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc_image_entry = {.source=&myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_RC_IMAGE_DEPTH 1
#define myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9,.shape=&myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc = {.size=1,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc_image_entry = {.source=&myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc,.shape={.size=1,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_RC_IMAGE_DEPTH 1
#define myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b,.shape=&myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=1,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc_image_entry = {.source=&myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_RC_IMAGE_DEPTH 1
#define myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5,.shape=&myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc_image_entry = {.source=&myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_RC_IMAGE_DEPTH 1
#define myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d,.shape=&myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc = {.size=4,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc_image_entry = {.source=&myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc,.shape={.size=4,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_RC_IMAGE_DEPTH 1
#define myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc,.shape=&myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=4,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc_image_entry = {.source=&myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_RC_IMAGE_DEPTH 1
#define myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98,.shape=&myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc_image_entry.shape,.finalize=NULL},.flat={.count=0,.loanable=1,.conditional=0,.arm_offset=4294967295,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
const myl_rc_shape myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc = {.size=8,.kind=MYL_RC_SHAPE_NONE};
/* mylang-rc-image-block-v1 */
const myl_rc_shape_entry myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc_image_entry = {.source=&myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc,.shape={.size=8,.kind=MYL_RC_SHAPE_NONE},.depth=0,.inline_depth=1};
#define myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_RC_IMAGE_DEPTH 1
#define myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_RC_IMAGE_BINDING {.descriptor={.type=&myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037,.shape=&myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc_image_entry.shape,.finalize=NULL},.flat={.count=17,.loanable=0,.conditional=0,.arm_offset=0,.size=8,.all=0,.always=0,.arms={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},.offsets={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}}}
static const myl_rc_shape *const myl_rc_generated_shapes[] = {
 &myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc,
 &myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc,
 &myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc,
 &myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc,
 &myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc,
 &myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc,
 &myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc,
 &myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc,
 &myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc,
 &myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc,
 &myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc,
 &myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc,
 &myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc,
 &myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc,
 &myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc,
 &myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc,
 &myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc,
 &myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc,
 &myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc,
 &myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc,
 &myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc,
 &myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc,
 &myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc,
 &myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc,
};
static const myl_rc_descriptor myl_rc_generated_descriptors[] = {
 {.type=&myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0,.shape=&myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527,.shape=&myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda,.shape=&myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9,.shape=&myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef,.shape=&myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1,.shape=&myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80,.shape=&myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba,.shape=&myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af,.shape=&myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e,.shape=&myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb,.shape=&myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18,.shape=&myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde,.shape=&myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511,.shape=&myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a,.shape=&myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded,.shape=&myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903,.shape=&myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9,.shape=&myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b,.shape=&myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5,.shape=&myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d,.shape=&myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc,.shape=&myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98,.shape=&myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc,.edges=NULL,.finalize=NULL},
 {.type=&myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037,.shape=&myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc,.edges=NULL,.finalize=NULL},
};
const myl_rc_module myl_rc_generated_module = {.abi=MYL_RC_ABI_VERSION,.shapes=myl_rc_generated_shapes,.shape_count=24,.descriptors=myl_rc_generated_descriptors,.descriptor_count=24};
static const myl_rc_shape_entry *const myl_rc_generated_image_shapes[] = {
 &myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_rc_image_entry,
 &myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rc_image_entry,
 &myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_rc_image_entry,
 &myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rc_image_entry,
 &myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_rc_image_entry,
 &myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_rc_image_entry,
 &myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_rc_image_entry,
 &myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_rc_image_entry,
 &myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_rc_image_entry,
 &myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_rc_image_entry,
 &myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rc_image_entry,
 &myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_rc_image_entry,
 &myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_rc_image_entry,
 &myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_rc_image_entry,
 &myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rc_image_entry,
 &myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_rc_image_entry,
 &myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_rc_image_entry,
 &myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_rc_image_entry,
 &myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_rc_image_entry,
 &myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_rc_image_entry,
 &myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_rc_image_entry,
 &myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_rc_image_entry,
 &myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_rc_image_entry,
 &myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_rc_image_entry,
};
static const myl_rc_binding myl_rc_generated_image_bindings[] = {
 myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_RC_IMAGE_BINDING,
 myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_RC_IMAGE_BINDING,
 myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_RC_IMAGE_BINDING,
 myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_RC_IMAGE_BINDING,
 myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_RC_IMAGE_BINDING,
 myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_RC_IMAGE_BINDING,
 myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_RC_IMAGE_BINDING,
 myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_RC_IMAGE_BINDING,
 myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_RC_IMAGE_BINDING,
 myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_RC_IMAGE_BINDING,
 myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_RC_IMAGE_BINDING,
 myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_RC_IMAGE_BINDING,
 myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_RC_IMAGE_BINDING,
 myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_RC_IMAGE_BINDING,
 myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_RC_IMAGE_BINDING,
 myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_RC_IMAGE_BINDING,
 myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_RC_IMAGE_BINDING,
 myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_RC_IMAGE_BINDING,
 myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_RC_IMAGE_BINDING,
 myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_RC_IMAGE_BINDING,
 myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_RC_IMAGE_BINDING,
 myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_RC_IMAGE_BINDING,
 myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_RC_IMAGE_BINDING,
 myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_RC_IMAGE_BINDING,
};
enum {myl_rc_image_depth_0 = 0};
enum {myl_rc_image_depth_1 = myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_RC_IMAGE_DEPTH > myl_rc_image_depth_0 ? myl_t_1506e6f44c1d6291cdf46395a8e573276a4fa79e8ace3fc891e092ef32d1b0a0_RC_IMAGE_DEPTH : myl_rc_image_depth_0};
enum {myl_rc_image_depth_2 = myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_RC_IMAGE_DEPTH > myl_rc_image_depth_1 ? myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_RC_IMAGE_DEPTH : myl_rc_image_depth_1};
enum {myl_rc_image_depth_3 = myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_RC_IMAGE_DEPTH > myl_rc_image_depth_2 ? myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda_RC_IMAGE_DEPTH : myl_rc_image_depth_2};
enum {myl_rc_image_depth_4 = myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_RC_IMAGE_DEPTH > myl_rc_image_depth_3 ? myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_RC_IMAGE_DEPTH : myl_rc_image_depth_3};
enum {myl_rc_image_depth_5 = myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_RC_IMAGE_DEPTH > myl_rc_image_depth_4 ? myl_t_29881aad8730c5ab11d275376323d8e4ff4179aae8ccb6c13fe4902137e162ef_RC_IMAGE_DEPTH : myl_rc_image_depth_4};
enum {myl_rc_image_depth_6 = myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_RC_IMAGE_DEPTH > myl_rc_image_depth_5 ? myl_t_385cfdbc00ec32031699460779c15099b2bba3cad0e440fffb08e10df0acb9e1_RC_IMAGE_DEPTH : myl_rc_image_depth_5};
enum {myl_rc_image_depth_7 = myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_RC_IMAGE_DEPTH > myl_rc_image_depth_6 ? myl_t_3b9c358f36f0a31b6ad3e14f309c7cf198ac9246e8316f9ce543d5b19ac02b80_RC_IMAGE_DEPTH : myl_rc_image_depth_6};
enum {myl_rc_image_depth_8 = myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_RC_IMAGE_DEPTH > myl_rc_image_depth_7 ? myl_t_4c1dc1f491eb4e4e3e5e34a36df4fd84932bb09a01b248edbcb1581d16ce4dba_RC_IMAGE_DEPTH : myl_rc_image_depth_7};
enum {myl_rc_image_depth_9 = myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_RC_IMAGE_DEPTH > myl_rc_image_depth_8 ? myl_t_579a6e6b342a11b9c01fffd40edb24ad3ba63ce50f15b096619d4415c21509af_RC_IMAGE_DEPTH : myl_rc_image_depth_8};
enum {myl_rc_image_depth_10 = myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_RC_IMAGE_DEPTH > myl_rc_image_depth_9 ? myl_t_601363c049b52965deca3c30de62d7c1e35c1b345738a9b6eaf0dae82b2d525e_RC_IMAGE_DEPTH : myl_rc_image_depth_9};
enum {myl_rc_image_depth_11 = myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_RC_IMAGE_DEPTH > myl_rc_image_depth_10 ? myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_RC_IMAGE_DEPTH : myl_rc_image_depth_10};
enum {myl_rc_image_depth_12 = myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_RC_IMAGE_DEPTH > myl_rc_image_depth_11 ? myl_t_76a7e234dc54e9c605b2cc9fdf71279526150df48c574bdfa69e436e0b3d5c18_RC_IMAGE_DEPTH : myl_rc_image_depth_11};
enum {myl_rc_image_depth_13 = myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_RC_IMAGE_DEPTH > myl_rc_image_depth_12 ? myl_t_7daa2b32ed44f20a09e879c26e1e49854993e9f8405148f50cc682a431443bde_RC_IMAGE_DEPTH : myl_rc_image_depth_12};
enum {myl_rc_image_depth_14 = myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_RC_IMAGE_DEPTH > myl_rc_image_depth_13 ? myl_t_886f24827f05c4b769435ada943aac3b6d4fe5a4b031155fcc44470e901bd511_RC_IMAGE_DEPTH : myl_rc_image_depth_13};
enum {myl_rc_image_depth_15 = myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_RC_IMAGE_DEPTH > myl_rc_image_depth_14 ? myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_RC_IMAGE_DEPTH : myl_rc_image_depth_14};
enum {myl_rc_image_depth_16 = myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_RC_IMAGE_DEPTH > myl_rc_image_depth_15 ? myl_t_af94d33f4827bb6e0ae845fbba0dfb49c7e7b1483a9f8ac07530a393025deded_RC_IMAGE_DEPTH : myl_rc_image_depth_15};
enum {myl_rc_image_depth_17 = myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_RC_IMAGE_DEPTH > myl_rc_image_depth_16 ? myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903_RC_IMAGE_DEPTH : myl_rc_image_depth_16};
enum {myl_rc_image_depth_18 = myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_RC_IMAGE_DEPTH > myl_rc_image_depth_17 ? myl_t_beeeed5d585e43e1c74f43c903192f8db9ff4e18b8869c4b318503a20bf1c1b9_RC_IMAGE_DEPTH : myl_rc_image_depth_17};
enum {myl_rc_image_depth_19 = myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_RC_IMAGE_DEPTH > myl_rc_image_depth_18 ? myl_t_c89951a24c6ca28c13fd1cfdc646b2b656d69e61a92b91023be7eb58eb914b6b_RC_IMAGE_DEPTH : myl_rc_image_depth_18};
enum {myl_rc_image_depth_20 = myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_RC_IMAGE_DEPTH > myl_rc_image_depth_19 ? myl_t_cd976913740f306bd067637f0a1be848018e4fbfd3e395aea42a9231391cb1c5_RC_IMAGE_DEPTH : myl_rc_image_depth_19};
enum {myl_rc_image_depth_21 = myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_RC_IMAGE_DEPTH > myl_rc_image_depth_20 ? myl_t_d1cce237c552db48f92d82d5f95684c2d207ccf5f1afdc028c4548ea066b0e5d_RC_IMAGE_DEPTH : myl_rc_image_depth_20};
enum {myl_rc_image_depth_22 = myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_RC_IMAGE_DEPTH > myl_rc_image_depth_21 ? myl_t_d7649d428b9ff33d188ecbf38a7e4d8fd167fa01b2e10fe9a8f9308e52f1d7cc_RC_IMAGE_DEPTH : myl_rc_image_depth_21};
enum {myl_rc_image_depth_23 = myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_RC_IMAGE_DEPTH > myl_rc_image_depth_22 ? myl_t_ded747889058c060268bcaac8aaf5412abee4bb007b867310c7075dd7aae3f98_RC_IMAGE_DEPTH : myl_rc_image_depth_22};
enum {myl_rc_image_depth_24 = myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_RC_IMAGE_DEPTH > myl_rc_image_depth_23 ? myl_t_f726d343c6f3811085b0abb29689c152180acd9c6f861914d7f6796e3395e037_RC_IMAGE_DEPTH : myl_rc_image_depth_23};
const myl_rc_image myl_rc_generated_image = {.abi=MYL_RC_IMAGE_ABI_VERSION,.shapes=myl_rc_generated_image_shapes,.shape_count=24,.bindings=myl_rc_generated_image_bindings,.descriptor_count=24,.depth=myl_rc_image_depth_24};
#include "qbe_runtime.h"
#include "native_rc_internal.h"
#include "native_rc_values.h"
#include "native_rc_collections.h"
#include <string.h>
/* RC-GLUE-1: active counts are unsigned 64-bit words. Generated glue
 * preflights its whole value before changing bytes or marks: a count
 * near saturation uses the runtime's exact alias-aware transaction.
 * Remaining paths can acquire every leaf without wrapping. */
#if (defined(MYL_NATIVE_RC_COUNTING) && MYL_NATIVE_RC_COUNTING) || defined(MYL_RC_GLUE_CHECKED)
#define MYL_RCG_CHECK(valid) myl_rc_invariant(valid)
#define MYL_RCG_CHECKED 1
#else
#define MYL_RCG_CHECK(valid) ((void)0)
#define MYL_RCG_CHECKED 0
#endif
#define MYL_RCG_UNCOUNTED (MYL_NATIVE_OBJECT_IMMORTAL | MYL_NATIVE_OBJECT_ARENA)
/* Helpers stay plain inline: clang inlines them at -O2 anyway, and
 * forcing it costs a third of the unit's compile time. */
#define MYL_RCG_INLINE static inline
MYL_RCG_INLINE void *myl_rcg_load(const unsigned char *at) { void *p; memcpy(&p, at, sizeof p); return p; }
MYL_RCG_INLINE void *myl_rcg_clear(unsigned char *at) { void *p; memcpy(&p, at, sizeof p); memset(at, 0, sizeof p); return p; }
MYL_RCG_INLINE uint32_t myl_rcg_tag(const unsigned char *at) { uint32_t tag; memcpy(&tag, at, sizeof tag); return tag; }
MYL_RCG_INLINE uintptr_t myl_rcg_flags(const void *p) { return p ? ((const myl_native_object *)p - 1)->mark : 0; }
MYL_RCG_INLINE int myl_rcg_overlap(const void *a, const void *b, size_t bytes) {
    uintptr_t x = (uintptr_t)a, y = (uintptr_t)b;
    return x > y ? x - y < bytes : y - x < bytes;
}
/* The counted prefix of a live ordinary object, or NULL for null/immortal/arena. */
MYL_RCG_INLINE myl_rc_object *myl_rcg_counted(const void *p) {
    if (!p) return NULL;
    uintptr_t mark = ((const myl_native_object *)p - 1)->mark;
    if (mark & MYL_RCG_UNCOUNTED) return NULL;
    myl_rc_object *object = (myl_rc_object *)p - 1;
    MYL_RCG_CHECK(!(mark & MYL_RC_OBJECT_DYING) && (object->owners || object->holds));
    return object;
}
MYL_RCG_INLINE int myl_rcg_capacity(const void *p, size_t bound, int hold) {
    myl_rc_object *object = myl_rcg_counted(p);
    return !object || (bound <= MYL_RC_COUNT_MAX &&
        (hold ? object->holds : object->owners) <= MYL_RC_COUNT_MAX - bound);
}
MYL_RCG_INLINE void myl_rcg_owner_acquire(myl_native_heap *heap, void *p) {
    myl_rc_object *object = myl_rcg_counted(p);
    (void)heap;
    if (!object) return;
    ++object->owners;
    MYL_RC_STAT(heap, MYL_RC_STAT_OWNER_ACQUIRE);
}
MYL_RCG_INLINE void myl_rcg_hold_acquire(myl_native_heap *heap, void *p) {
    myl_rc_object *object = myl_rcg_counted(p);
    (void)heap;
    if (!object) return;
    ++object->holds;
    MYL_RC_STAT(heap, MYL_RC_STAT_HOLD_ACQUIRE);
}
/* A loan never pins a finalizing body; checked builds prove it per edge. */
MYL_RCG_INLINE void myl_rcg_loan_check(myl_native_heap *heap, void *p) {
#if MYL_RCG_CHECKED
    if (p) {
        const myl_native_object *header = (const myl_native_object *)p - 1;
        const myl_rc_descriptor *descriptor = myl_rc_descriptor_find(heap, header->element);
        myl_rc_invariant((header->mark & MYL_NATIVE_OBJECT_IMMORTAL) || (descriptor && !descriptor->finalize));
    }
#else
    (void)heap; (void)p;
#endif
}
MYL_RCG_INLINE void myl_rcg_loan_acquire(myl_native_heap *heap, void *p) {
    myl_rcg_loan_check(heap, p);
    myl_rcg_hold_acquire(heap, p);
}
/* Returns 1 when the edge was the last token and its death is now queued. */
MYL_RCG_INLINE int myl_rcg_owner_release(myl_native_heap *heap, void *p) {
    myl_rc_object *object = myl_rcg_counted(p);
    if (!object) return 0;
    if (object->owners != 1 || object->holds) {
        MYL_RCG_CHECK(object->owners != 0);
        --object->owners;
        MYL_RC_STAT(heap, MYL_RC_STAT_OWNER_RELEASE);
        return 0;
    }
    myl_rc_edge_release(heap, p);
    return 1;
}
/* Semantic SHARE of one direct payload, as the runtime's queued marks. */
MYL_RCG_INLINE void myl_rcg_share(void *p) {
    if (!p) return;
    myl_native_object *header = (myl_native_object *)p - 1;
    if (header->mark & (MYL_NATIVE_OBJECT_IMMORTAL | MYL_NATIVE_OBJECT_SHARED)) return;
    MYL_RCG_CHECK(!(header->mark & MYL_NATIVE_OBJECT_PINNED));
    if (myl_rc_native_mutable(p)) header->mark |= MYL_NATIVE_OBJECT_SHARED;
}
MYL_RCG_INLINE int myl_rcg_hold_release(myl_native_heap *heap, void *p) {
    myl_rc_object *object = myl_rcg_counted(p);
    if (!object) return 0;
    if (object->holds != 1 || object->owners) {
        MYL_RCG_CHECK(object->holds != 0);
        --object->holds;
        MYL_RC_STAT(heap, MYL_RC_STAT_HOLD_RELEASE);
        return 0;
    }
    myl_rc_hold_edge_release(heap, p);
    return 1;
}
int myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_loan(myl_native_heap *heap, void *dst, const void *src) {
void *p0 = myl_rcg_load((const unsigned char *)src + 0);
myl_rc_object *o0 = myl_rcg_counted(p0);
if (0 || (o0 && o0->holds > MYL_RC_COUNT_MAX - 1)) return myl_rc_native_loan(heap, &myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, dst, src);
MYL_RCG_CHECK(!myl_rcg_overlap(dst, src, 8));
myl_rcg_loan_check(heap, p0);
if (o0) { ++o0->holds; MYL_RC_STAT(heap, MYL_RC_STAT_HOLD_ACQUIRE); }
MYL_RCG_CHECK(!myl_rcg_overlap(dst, src, 8));
memcpy(dst, src, 8);
return 1;
}
void myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(myl_native_heap *heap, void *value) {
int died = 0;
died |= myl_rcg_hold_release(heap, myl_rcg_clear((unsigned char *)(value)));
memset(value, 0, 8);
if (died) myl_rc_drain(heap);
}
void myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(myl_native_heap *heap, void *value) {
int died = 0;
died |= myl_rcg_owner_release(heap, myl_rcg_clear((unsigned char *)(value)));
memset(value, 0, 8);
if (died) myl_rc_drain(heap);
}
int myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(myl_native_heap *heap, void *dst, const void *src, unsigned region) {
uintptr_t any = 0;
void *p0 = myl_rcg_load((const unsigned char *)src + 0);
myl_rc_object *o0 = myl_rcg_counted(p0);
any |= myl_rcg_flags(p0);
if ((any & MYL_NATIVE_OBJECT_ARENA) || (o0 && o0->owners > MYL_RC_COUNT_MAX - 1)) return myl_rc_native_retain(heap, &myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, dst, src, region);
MYL_RCG_CHECK(dst != src && region <= heap->region_depth);
if (o0) { ++o0->owners; MYL_RC_STAT(heap, MYL_RC_STAT_OWNER_ACQUIRE); }
MYL_RCG_CHECK(dst != src && region <= heap->region_depth);
memmove(dst, src, 8);
return 1;
}
int myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(myl_native_heap *heap, void *dst, void *src, unsigned region) {
uintptr_t any = 0;
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)(src)));
if ((any & (MYL_NATIVE_OBJECT_ARENA | MYL_NATIVE_OBJECT_PINNED)) || myl_rcg_overlap(dst, src, 8))
return myl_rc_native_take(heap, &myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, dst, src, region);
MYL_RCG_CHECK(!(any & MYL_RC_OBJECT_DYING) && region <= heap->region_depth);
memcpy(dst, src, 8);
memset(src, 0, 8);
return 1;
}
int myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish(myl_native_heap *heap, void *dst, void *src, unsigned region, unsigned mode) {
uintptr_t any = 0;
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)(src)));
if ((mode & 3u) || (any & (MYL_NATIVE_OBJECT_ARENA | MYL_NATIVE_OBJECT_PINNED)) || myl_rcg_overlap(dst, src, 8))
return myl_rc_native_publish(heap, &myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, dst, src, region, mode);
if (!(mode & MYL_RC_HISTORY_TAKE)) {
int capacity = 1; const size_t bound = 1;
capacity &= myl_rcg_capacity(myl_rcg_load((const unsigned char *)(src)), bound, 0);
if (!capacity) return myl_rc_native_publish(heap, &myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527, dst, src, region, mode);
}
MYL_RCG_CHECK(!(any & MYL_RC_OBJECT_DYING) && region <= heap->region_depth);
myl_rcg_share(myl_rcg_load((const unsigned char *)(src)));
memcpy(dst, src, 8);
if (mode & MYL_RC_HISTORY_TAKE) { memset(src, 0, 8); return 1; }
myl_rcg_owner_acquire(heap, myl_rcg_load((const unsigned char *)(dst)));
return 1;
}
int myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_loan(myl_native_heap *heap, void *dst, const void *src) {
void *p0 = myl_rcg_load((const unsigned char *)src + 0);
myl_rc_object *o0 = myl_rcg_counted(p0);
if (0 || (o0 && o0->holds > MYL_RC_COUNT_MAX - 1)) return myl_rc_native_loan(heap, &myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9, dst, src);
MYL_RCG_CHECK(!myl_rcg_overlap(dst, src, 8));
myl_rcg_loan_check(heap, p0);
if (o0) { ++o0->holds; MYL_RC_STAT(heap, MYL_RC_STAT_HOLD_ACQUIRE); }
MYL_RCG_CHECK(!myl_rcg_overlap(dst, src, 8));
memcpy(dst, src, 8);
return 1;
}
void myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(myl_native_heap *heap, void *value) {
int died = 0;
died |= myl_rcg_hold_release(heap, myl_rcg_clear((unsigned char *)(value)));
memset(value, 0, 8);
if (died) myl_rc_drain(heap);
}
void myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(myl_native_heap *heap, void *value) {
int died = 0;
died |= myl_rcg_owner_release(heap, myl_rcg_clear((unsigned char *)(value)));
memset(value, 0, 8);
if (died) myl_rc_drain(heap);
}
int myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(myl_native_heap *heap, void *dst, const void *src, unsigned region) {
uintptr_t any = 0;
void *p0 = myl_rcg_load((const unsigned char *)src + 0);
myl_rc_object *o0 = myl_rcg_counted(p0);
any |= myl_rcg_flags(p0);
if ((any & MYL_NATIVE_OBJECT_ARENA) || (o0 && o0->owners > MYL_RC_COUNT_MAX - 1)) return myl_rc_native_retain(heap, &myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9, dst, src, region);
MYL_RCG_CHECK(dst != src && region <= heap->region_depth);
if (o0) { ++o0->owners; MYL_RC_STAT(heap, MYL_RC_STAT_OWNER_ACQUIRE); }
MYL_RCG_CHECK(dst != src && region <= heap->region_depth);
memmove(dst, src, 8);
return 1;
}
int myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(myl_native_heap *heap, void *dst, void *src, unsigned region) {
uintptr_t any = 0;
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)(src)));
if ((any & (MYL_NATIVE_OBJECT_ARENA | MYL_NATIVE_OBJECT_PINNED)) || myl_rcg_overlap(dst, src, 8))
return myl_rc_native_take(heap, &myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9, dst, src, region);
MYL_RCG_CHECK(!(any & MYL_RC_OBJECT_DYING) && region <= heap->region_depth);
memcpy(dst, src, 8);
memset(src, 0, 8);
return 1;
}
int myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_publish(myl_native_heap *heap, void *dst, void *src, unsigned region, unsigned mode) {
uintptr_t any = 0;
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)(src)));
if ((mode & 3u) || (any & (MYL_NATIVE_OBJECT_ARENA | MYL_NATIVE_OBJECT_PINNED)) || myl_rcg_overlap(dst, src, 8))
return myl_rc_native_publish(heap, &myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9, dst, src, region, mode);
if (!(mode & MYL_RC_HISTORY_TAKE)) {
int capacity = 1; const size_t bound = 1;
capacity &= myl_rcg_capacity(myl_rcg_load((const unsigned char *)(src)), bound, 0);
if (!capacity) return myl_rc_native_publish(heap, &myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9, dst, src, region, mode);
}
MYL_RCG_CHECK(!(any & MYL_RC_OBJECT_DYING) && region <= heap->region_depth);
myl_rcg_share(myl_rcg_load((const unsigned char *)(src)));
memcpy(dst, src, 8);
if (mode & MYL_RC_HISTORY_TAKE) { memset(src, 0, 8); return 1; }
myl_rcg_owner_acquire(heap, myl_rcg_load((const unsigned char *)(dst)));
return 1;
}
int myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rcg_loan(myl_native_heap *heap, void *dst, const void *src) {
void *p0 = myl_rcg_load((const unsigned char *)src + 0);
myl_rc_object *o0 = myl_rcg_counted(p0);
void *p1 = myl_rcg_load((const unsigned char *)src + 8);
myl_rc_object *o1 = myl_rcg_counted(p1);
if (0 || (o0 && o0->holds > MYL_RC_COUNT_MAX - 2) || (o1 && o1->holds > MYL_RC_COUNT_MAX - 2)) return myl_rc_native_loan(heap, &myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb, dst, src);
MYL_RCG_CHECK(!myl_rcg_overlap(dst, src, 16));
myl_rcg_loan_check(heap, p0);
myl_rcg_loan_check(heap, p1);
if (o0) { ++o0->holds; MYL_RC_STAT(heap, MYL_RC_STAT_HOLD_ACQUIRE); }
if (o1) { ++o1->holds; MYL_RC_STAT(heap, MYL_RC_STAT_HOLD_ACQUIRE); }
MYL_RCG_CHECK(!myl_rcg_overlap(dst, src, 16));
memcpy(dst, src, 16);
return 1;
}
void myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rcg_unloan(myl_native_heap *heap, void *value) {
int died = 0;
died |= myl_rcg_hold_release(heap, myl_rcg_clear((unsigned char *)(value)));
died |= myl_rcg_hold_release(heap, myl_rcg_clear((unsigned char *)((unsigned char *)(value) + 8)));
memset(value, 0, 16);
if (died) myl_rc_drain(heap);
}
void myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rcg_drop(myl_native_heap *heap, void *value) {
int died = 0;
died |= myl_rcg_owner_release(heap, myl_rcg_clear((unsigned char *)(value)));
died |= myl_rcg_owner_release(heap, myl_rcg_clear((unsigned char *)((unsigned char *)(value) + 8)));
memset(value, 0, 16);
if (died) myl_rc_drain(heap);
}
int myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rcg_retain(myl_native_heap *heap, void *dst, const void *src, unsigned region) {
uintptr_t any = 0;
void *p0 = myl_rcg_load((const unsigned char *)src + 0);
myl_rc_object *o0 = myl_rcg_counted(p0);
any |= myl_rcg_flags(p0);
void *p1 = myl_rcg_load((const unsigned char *)src + 8);
myl_rc_object *o1 = myl_rcg_counted(p1);
any |= myl_rcg_flags(p1);
if ((any & MYL_NATIVE_OBJECT_ARENA) || (o0 && o0->owners > MYL_RC_COUNT_MAX - 2) || (o1 && o1->owners > MYL_RC_COUNT_MAX - 2)) return myl_rc_native_retain(heap, &myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb, dst, src, region);
MYL_RCG_CHECK(dst != src && region <= heap->region_depth);
if (o0) { ++o0->owners; MYL_RC_STAT(heap, MYL_RC_STAT_OWNER_ACQUIRE); }
if (o1) { ++o1->owners; MYL_RC_STAT(heap, MYL_RC_STAT_OWNER_ACQUIRE); }
MYL_RCG_CHECK(dst != src && region <= heap->region_depth);
memmove(dst, src, 16);
return 1;
}
int myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rcg_take(myl_native_heap *heap, void *dst, void *src, unsigned region) {
uintptr_t any = 0;
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)(src)));
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)((unsigned char *)(src) + 8)));
if ((any & (MYL_NATIVE_OBJECT_ARENA | MYL_NATIVE_OBJECT_PINNED)) || myl_rcg_overlap(dst, src, 16))
return myl_rc_native_take(heap, &myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb, dst, src, region);
MYL_RCG_CHECK(!(any & MYL_RC_OBJECT_DYING) && region <= heap->region_depth);
memcpy(dst, src, 16);
memset(src, 0, 16);
return 1;
}
int myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb_rcg_publish(myl_native_heap *heap, void *dst, void *src, unsigned region, unsigned mode) {
uintptr_t any = 0;
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)(src)));
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)((unsigned char *)(src) + 8)));
if ((mode & 3u) || (any & (MYL_NATIVE_OBJECT_ARENA | MYL_NATIVE_OBJECT_PINNED)) || myl_rcg_overlap(dst, src, 16))
return myl_rc_native_publish(heap, &myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb, dst, src, region, mode);
if (!(mode & MYL_RC_HISTORY_TAKE)) {
int capacity = 1; const size_t bound = 2;
capacity &= myl_rcg_capacity(myl_rcg_load((const unsigned char *)(src)), bound, 0);
capacity &= myl_rcg_capacity(myl_rcg_load((const unsigned char *)((unsigned char *)(src) + 8)), bound, 0);
if (!capacity) return myl_rc_native_publish(heap, &myl_t_60b103692bd44efe9b0174d16df4462d9ad1cfe2b778dc10367868d44f2d97eb, dst, src, region, mode);
}
MYL_RCG_CHECK(!(any & MYL_RC_OBJECT_DYING) && region <= heap->region_depth);
myl_rcg_share(myl_rcg_load((const unsigned char *)(src)));
myl_rcg_share(myl_rcg_load((const unsigned char *)((unsigned char *)(src) + 8)));
memcpy(dst, src, 16);
if (mode & MYL_RC_HISTORY_TAKE) { memset(src, 0, 16); return 1; }
myl_rcg_owner_acquire(heap, myl_rcg_load((const unsigned char *)(dst)));
myl_rcg_owner_acquire(heap, myl_rcg_load((const unsigned char *)((unsigned char *)(dst) + 8)));
return 1;
}
int myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_loan(myl_native_heap *heap, void *dst, const void *src) {
void *p0 = myl_rcg_load((const unsigned char *)src + 0);
myl_rc_object *o0 = myl_rcg_counted(p0);
if (0 || (o0 && o0->holds > MYL_RC_COUNT_MAX - 1)) return myl_rc_native_loan(heap, &myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a, dst, src);
MYL_RCG_CHECK(!myl_rcg_overlap(dst, src, 8));
myl_rcg_loan_check(heap, p0);
if (o0) { ++o0->holds; MYL_RC_STAT(heap, MYL_RC_STAT_HOLD_ACQUIRE); }
MYL_RCG_CHECK(!myl_rcg_overlap(dst, src, 8));
memcpy(dst, src, 8);
return 1;
}
void myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(myl_native_heap *heap, void *value) {
int died = 0;
died |= myl_rcg_hold_release(heap, myl_rcg_clear((unsigned char *)(value)));
memset(value, 0, 8);
if (died) myl_rc_drain(heap);
}
void myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(myl_native_heap *heap, void *value) {
int died = 0;
died |= myl_rcg_owner_release(heap, myl_rcg_clear((unsigned char *)(value)));
memset(value, 0, 8);
if (died) myl_rc_drain(heap);
}
int myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_retain(myl_native_heap *heap, void *dst, const void *src, unsigned region) {
uintptr_t any = 0;
void *p0 = myl_rcg_load((const unsigned char *)src + 0);
myl_rc_object *o0 = myl_rcg_counted(p0);
any |= myl_rcg_flags(p0);
if ((any & MYL_NATIVE_OBJECT_ARENA) || (o0 && o0->owners > MYL_RC_COUNT_MAX - 1)) return myl_rc_native_retain(heap, &myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a, dst, src, region);
MYL_RCG_CHECK(dst != src && region <= heap->region_depth);
if (o0) { ++o0->owners; MYL_RC_STAT(heap, MYL_RC_STAT_OWNER_ACQUIRE); }
MYL_RCG_CHECK(dst != src && region <= heap->region_depth);
memmove(dst, src, 8);
return 1;
}
int myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(myl_native_heap *heap, void *dst, void *src, unsigned region) {
uintptr_t any = 0;
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)(src)));
if ((any & (MYL_NATIVE_OBJECT_ARENA | MYL_NATIVE_OBJECT_PINNED)) || myl_rcg_overlap(dst, src, 8))
return myl_rc_native_take(heap, &myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a, dst, src, region);
MYL_RCG_CHECK(!(any & MYL_RC_OBJECT_DYING) && region <= heap->region_depth);
memcpy(dst, src, 8);
memset(src, 0, 8);
return 1;
}
int myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_publish(myl_native_heap *heap, void *dst, void *src, unsigned region, unsigned mode) {
uintptr_t any = 0;
any |= myl_rcg_flags(myl_rcg_load((const unsigned char *)(src)));
if ((mode & 3u) || (any & (MYL_NATIVE_OBJECT_ARENA | MYL_NATIVE_OBJECT_PINNED)) || myl_rcg_overlap(dst, src, 8))
return myl_rc_native_publish(heap, &myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a, dst, src, region, mode);
if (!(mode & MYL_RC_HISTORY_TAKE)) {
int capacity = 1; const size_t bound = 1;
capacity &= myl_rcg_capacity(myl_rcg_load((const unsigned char *)(src)), bound, 0);
if (!capacity) return myl_rc_native_publish(heap, &myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a, dst, src, region, mode);
}
MYL_RCG_CHECK(!(any & MYL_RC_OBJECT_DYING) && region <= heap->region_depth);
myl_rcg_share(myl_rcg_load((const unsigned char *)(src)));
memcpy(dst, src, 8);
if (mode & MYL_RC_HISTORY_TAKE) { memset(src, 0, 8); return 1; }
myl_rcg_owner_acquire(heap, myl_rcg_load((const unsigned char *)(dst)));
return 1;
}
