"""Add valid held-only ownership and dictionary execution to initial proof."""
import json
import subprocess
from pathlib import Path

p = Path('.tmp/publish-review/probes')
root = Path('.tmp/publish-review').resolve()
results = []

def run(command, label):
    command = [str(x) for x in command]
    result = subprocess.run(command, capture_output=True, text=True)
    log = f'exit {result.returncode} {command!r}\n' + result.stdout + result.stderr
    (p/(label+'.log')).write_text(log)
    print(log, end='', flush=True)
    results.append(dict(command=command, exit=result.returncode, log=label+'.log'))
    assert result.returncode == 0

run([root/'bin/qbe','-o',p/'dictionary-fragments.s',p/'dictionary-fragments.ssa'], 'dictionary-translate')
for prefix in ['', 'control-', 'dictionary-']:
    source = p/('dictionary-oracle.c' if prefix == 'dictionary-' else 'oracle.c')
    run(['cc','-std=c11','-O2','-UNDEBUG','-Wall','-Wextra','-Werror','-Isrc','-I'+str(p),source,p/(prefix+'fragments.s'),'-o',p/(prefix+'oracle-final')], prefix+'boundary-final-build')
    run([p/(prefix+'oracle-final')], prefix+'boundary-final')
archive = json.loads((p/'runtime-selection.json').read_text())['archive']
symbols = json.loads((p/'extraction.json').read_text())
for checked in [False, True]:
    label = 'native-' + ('checked' if checked else 'unchecked') + '-final'
    command = ['cc','-std=c11','-O2','-DMYL_NATIVE_RC=1','-UNDEBUG','-Wall','-Wextra','-Isrc','-I'+str(p)]
    if checked:
        command.append('-DMYL_RC_GLUE_CHECKED=1')
    command += [p/'native_oracle.c',p/'generated.c',p/'fragments.s',archive]
    command += ['-Wl,--wrap='+symbols[n]['symbol'] for n in ['owner','hold']]
    command += ['-lm','-ldl','-lpthread','-o',p/label]
    run(command, label+'-build')
    run([p/label], label)
(root/'extra-commands.json').write_text(json.dumps(results, indent=2)+'\n')
