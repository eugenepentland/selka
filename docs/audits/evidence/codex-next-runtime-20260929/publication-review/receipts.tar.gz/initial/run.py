"""Run a narrow immutable production-emission review under one build slot."""
import json
import os
import subprocess
from pathlib import Path

p = Path('.tmp/publish-review/probes')
root = Path('.tmp/publish-review').resolve()
results = []

def run(command, logname, output=None, env=None):
    r = subprocess.run([str(x) for x in command], text=True, capture_output=True, env=env)
    text = 'exit ' + str(r.returncode) + ' ' + repr([str(x) for x in command]) + '\n' + r.stdout + r.stderr
    (p / logname).write_text(text)
    print(text, end='', flush=True)
    results.append(dict(command=[str(x) for x in command], log=logname, exit=r.returncode))
    assert r.returncode == 0, text
    if output:
        (p / output).write_text(r.stdout)

candidate = root/'bin/mylang'
control = root/'bin/control-mylang'
qbe = root/'bin/qbe'
baseenv = os.environ.copy()
for label, compiler, source, runtime in [
    ('rc', candidate, 'source.my', 'rc-v5'),
    ('control', control, 'source.my', 'rc-v5'),
    ('stats', candidate, 'source.my', 'rc-v5-counting'),
    ('alias', candidate, 'alias.my', 'rc-v5'),
    ('dictionary', candidate, 'dictionary.my', 'rc-v5'),
]:
    env = dict(baseenv, MYLANG_RUNTIME=runtime)
    run([compiler, 'emit-qbe', p/source], 'emit-' + label + '.log', label+'.json', env)
run(['python3', root/'extract.py'], 'extract.log')
for prefix in ['', 'control-']:
    run([qbe, '-o', p/(prefix+'fragments.s'), p/(prefix+'fragments.ssa')], prefix+'translate.log')
    run(['cc','-std=c11','-O2','-UNDEBUG','-Wall','-Wextra','-Werror','-Isrc','-I'+str(p),p/'oracle.c',p/(prefix+'fragments.s'),'-o',p/(prefix+'oracle')], prefix+'boundary-build.log')
    run([p/(prefix+'oracle')], prefix+'boundary.log')
run([candidate,'build',p/'source.my','-o',p/'guest','--cache-dir',root/'cache','--report'], 'build-guest.log')
archives = set()
for args in (root/'cache/objects').glob('*/link-*.args'):
    for line in args.read_text().splitlines():
        if 'mylang-runtime/' in line and line.endswith('.a'):
            archives.add(line.strip('"'))
assert len(archives) == 1, archives
archive = Path(archives.pop())
(p/'runtime-selection.json').write_text(json.dumps(dict(archive=str(archive)), indent=2)+'\n')
symbols = json.loads((p/'extraction.json').read_text())
for checked in [False, True]:
    label = 'native-' + ('checked' if checked else 'unchecked')
    command = ['cc','-std=c11','-O2','-DMYL_NATIVE_RC=1','-UNDEBUG','-Wall','-Wextra','-Isrc','-I'+str(p)]
    if checked:
        command.append('-DMYL_RC_GLUE_CHECKED=1')
    command += [p/'native_oracle.c',p/'generated.c',p/'fragments.s',archive]
    command += ['-Wl,--wrap='+symbols[n]['symbol'] for n in ['owner','hold']]
    command += ['-lm','-ldl','-lpthread','-o',p/label]
    run(command, label+'-build.log')
    run([p/label], label+'.log')
run(['cc','-std=c11','-O2','-DMYL_NATIVE_RC=1','-DMYL_RC_GLUE_CHECKED=1','-UNDEBUG','-Wall','-Wextra','-Werror','-Isrc','-I'+str(p),p/'alias_oracle.c',p/'alias-generated.c',archive,'-lm','-ldl','-lpthread','-o',p/'alias-oracle'], 'alias-build.log')
run([p/'alias-oracle'], 'alias.log')
(root/'commands.json').write_text(json.dumps(results, indent=2)+'\n')
