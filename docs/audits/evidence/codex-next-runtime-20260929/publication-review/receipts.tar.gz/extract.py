"""Wrap byte-exact production emission for independent execution; no rewriting."""
import json
import re
from pathlib import Path

p = Path('.tmp/publish-review/probes')

def extract(manifest, prefix=''):
    data = json.loads((p / manifest).read_text())
    il = next(f['il'] for f in data['functions'] if f['name'] == 'keep')
    (p / (prefix + 'keep.ssa')).write_text(il)
    records = {}
    functions = []
    for name, kind in [('owner', 'drop'), ('hold', 'unloan')]:
        start = il.index(' # RC-GLUE-1 ' + kind + '\n')
        segment = il[start:]
        end = re.search(r'(?m)^@rcgdone\d+\n', segment).end()
        raw = segment[:end]
        symbol, heap, slot = re.search(r'call \$(\w+)(?:\(l (\S+), l (%v\d+)\))', raw).groups()
        assert symbol.endswith('_rcg_' + kind)
        records[name] = dict(source_range=[start, start + end], raw_body=raw, slot=slot, symbol=symbol)
        functions.append(f'export function w $review_{name}(l %ctx, l %heap, l {slot}) {{\n@start\n' + raw + ' ret 1\n}\n')
    start = il.index(' # RC-GLUE-1 publish\n')
    segment = il[start:]
    end = re.search(r'(?m)^@rcgpublished\d+\n', segment).end()
    raw = segment[:end]
    symbol, dst, src, region, mode = re.search(r'call \$(\w+_rcg_publish)\(l %heap, l (%v\d+), l (%v\d+), w (%v\d+), w (%v\d+)\)', raw).groups()
    records['publish'] = dict(source_range=[start, start + end], raw_body=raw, symbol=symbol, dst=dst, src=src, region=region, mode=mode)
    functions.append(f'export function w $review_publish(l %ctx, l %heap, l {dst}, l {src}, w {region}, w {mode}) {{\n@start\n' + raw + ' ret 1\n@failure\n ret 0\n}\n')
    (p / (prefix + 'fragments.ssa')).write_text('\n'.join(functions))
    (p / (prefix + 'extraction.json')).write_text(json.dumps(records, indent=2) + '\n')
    (p / (prefix + 'symbols.h')).write_text(''.join('#define ' + n.upper() + '_SYMBOL "' + records[n]['symbol'] + '"\n' for n in ('owner', 'hold', 'publish')))
    if not prefix:
        (p / 'generated.c').write_text(data['runtime_data'])

extract('rc.json')
extract('control.json', 'control-')
extract('dictionary.json', 'dictionary-')
alias = json.loads((p / 'alias.json').read_text())
(p / 'alias-generated.c').write_text(alias['runtime_data'])
original = Path('/home/epentland/ai/canopy/mylang-worktrees/codex-next-release-review-20260930/.tmp/release-review/probes/alias-symbol.h').read_text()
symbol = re.search(r'"(\w+)"', original).group(1)
assert symbol + '(' in alias['runtime_data']
(p / 'alias-symbol.h').write_text(original)
