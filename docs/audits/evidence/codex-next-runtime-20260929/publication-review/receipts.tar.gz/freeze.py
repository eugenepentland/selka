import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path('.tmp/publish-review')
files = subprocess.check_output(['git','ls-files','src','vendor/qbe'],text=True).splitlines()
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
snapshot = dict(source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
                files={f:digest(f) for f in files},
                binaries={str(f):digest(f) for f in (root/'bin').iterdir() if f.is_file()})
(root/('frozen-'+sys.argv[1]+'.json')).write_text(json.dumps(snapshot,sort_keys=True,indent=2)+'\n')
