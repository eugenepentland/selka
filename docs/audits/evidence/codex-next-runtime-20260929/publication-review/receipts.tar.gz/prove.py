"""Check CFG dominance on every actual fast publication from owned fixtures."""
import json
import re
from pathlib import Path

p = Path('.tmp/publish-review/probes')
proofs = []
branches = []

def prove(raw, classes, provenance):
    blocks = {'start': []}
    at = 'start'
    for line in raw.splitlines():
        if line.startswith('@'):
            at = line[1:]
            blocks[at] = []
        else:
            blocks[at].append(line.strip())
    names = list(blocks)
    edges = {}
    for i, (name, lines) in enumerate(blocks.items()):
        terminal = next((line for line in reversed(lines) if line), '')
        if terminal.startswith('jnz '):
            operand, yes, no = re.fullmatch(r'jnz (%\w+), @(\w+), @(\w+)', terminal).groups()
            assert classes[operand] == 'w', (provenance, operand, classes.get(operand))
            branches.append(dict(provenance=provenance, block=name, operand=operand, type='w'))
            edges[name] = {yes, no}
        elif terminal.startswith('jmp '):
            edges[name] = {terminal[5:]}
        else:
            edges[name] = {names[i+1]} if i+1 < len(names) else set()
    edges['failure'] = set()
    predecessors = {name: set() for name in edges}
    for source, targets in edges.items():
        for target in targets:
            assert target in edges, (provenance, source, target)
            predecessors[target].add(source)
    dom = {name: set(edges) for name in edges}
    dom['start'] = {'start'}
    while True:
        updated = {name: ({'start'} if name == 'start' else {name} | (set.intersection(*(dom[n] for n in predecessors[name])) if predecessors[name] else set())) for name in edges}
        if updated == dom:
            break
        dom = updated
    find = lambda prefix: next(n for n in names if n.startswith(prefix))
    capacity = find('rcgpublishcapacity')
    acquire = find('rcgpublishacquire')
    slow = find('rcgpublishslow')
    capbody = '\n'.join(blocks[capacity])
    address, payload = re.search(r'(%v\d+) =l sub (%v\d+), 32', capbody).groups()
    count = re.search(r'(%v\d+) =l loadl '+re.escape(address), capbody).group(1)
    new = re.search(r'(%v\d+) =l add '+re.escape(count)+r', 1', capbody).group(1)
    saturated = re.search(r'(%v\d+) =w ceql '+re.escape(new)+r', 0', capbody).group(1)
    assert capbody.endswith(f'jnz {saturated}, @{slow}, @{acquire}')
    assert blocks[acquire] == [f'storel {new}, {address}']
    assert predecessors[acquire] == {capacity}
    assert capacity in dom[acquire]
    for prefix in ['rcgpublishmode','rcgpublishnn','rcgpublishshare','rcgpublishordinary']:
        assert find(prefix) in dom[acquire], (provenance, prefix, dom[acquire])
    reach = {acquire}
    while True:
        updated = reach | set.union(*(edges[n] for n in reach))
        if reach == updated:
            break
        reach = updated
    assert slow not in reach and 'failure' not in reach
    for name in reach:
        assert not any('call $' in line or 'alloc' in line or 'load' in line for line in blocks[name]), (provenance, name, blocks[name])
    stores = [(n,l) for n,ls in blocks.items() for l in ls if l.startswith('store')]
    assert len(stores) == 4, stores
    assert all(capacity not in n for n,_ in stores)
    proofs.append(dict(provenance=provenance, acquire=acquire, count_address=address, count=count, reduced=new, capacity=capacity, dominators=sorted(dom[acquire]), no_fallible_or_load_after_acquire=sorted(reach), store_blocks=stores))

for label in ['rc', 'dictionary']:
    manifest = json.loads((p/(label+'.json')).read_text())
    for function in manifest['functions']:
        il = function['il']
        classes = dict(re.findall(r'(%\w+) =[ ]*([wlsd]) ', il))
        for i, match in enumerate(re.finditer(r' # RC-GLUE-1 publish\n.*?\n@rcgpublished\d+\n', il, re.S)):
            if '@rcgpublishcapacity' in match[0]:
                prove(match[0], classes, label+':'+function['name']+':'+str(i))
stats = json.loads((p/'stats.json').read_text())
stats_sites = sum(f['il'].count(' # RC-GLUE-1 publish\n') for f in stats['functions'])
stats_calls = sum(len(re.findall(r'call \$\w+_rcg_publish\(', f['il'])) for f in stats['functions'])
assert stats_sites == stats_calls and stats_sites > 0
assert not any('@rcgpublishcapacity' in f['il'] or '@rcgpublishacquire' in f['il'] for f in stats['functions'])
(p/'dominance-proof.json').write_text(json.dumps(dict(proofs=proofs, branch_types=branches, counting=dict(publication_sites=stats_sites, generated_calls=stats_calls, inline_sites=0)),indent=2)+'\n')
print(f'Independent CFG proofs: {len(proofs)} actual publication sites, {len(branches)} word predicates, counting {stats_sites}/{stats_calls} generated calls')
