import importlib.util, os, shlex
from pathlib import Path

root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('native_memory',root/'scripts/test_native_memory.py')
suite=importlib.util.module_from_spec(spec)
spec.loader.exec_module(suite)
directory=root/'.tmp/view-inline/native'
directory.mkdir(exist_ok=True)
selected=['native_text_views','native_text_index','native_text_methods','native_rc_collections','native_heap','native_python','native_regions']
flags=['-std=c11','-O2','-Wall','-Wextra','-Werror','-fsanitize=undefined','-ffunction-sections','-fdata-sections','-Wl,--gc-sections']
for name,sources in suite.SUITES:
    if name in selected:
        print('BEGIN '+name,flush=True)
        suite.run_suite(root,shlex.split(os.environ.get('CC','cc'))+flags,directory,name,list(sources))
        print('PASS '+name,flush=True)
print('Selected native families passed: '+str(len(selected)),flush=True)
