import hashlib,json,os,re,subprocess,time
from pathlib import Path

work=Path(__file__).resolve().parent
root=work.parents[1]
compiler=work/'compiler/bin/mylang'
env={k:v for k,v in os.environ.items() if not k.startswith('MYLANG_') and k!='LD_PRELOAD'}
env.update(TMPDIR=str(root/'.tmp'),ZIG_LOCAL_CACHE_DIR=str(root/'.zig-cache'),ZIG_GLOBAL_CACHE_DIR=str(root/'.zig-global-cache'),MYLANG_JOBS='4',MYLANG_MEMORY_LIMIT='4G')
receipt={'base':'40bd74a0c52939c5f92d56f3a447269592077bd3','compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'commands':[],'purpose':'Focused correctness/code-shape only; no timing or broad corpus acceptance.'}

def run(label,args):
    command=[str(root/'scripts/build-slot.sh'),'build',*map(str,args)]
    start=time.monotonic()
    p=subprocess.run(command,cwd=root,env=env,capture_output=True)
    (work/(label+'.stdout')).write_bytes(p.stdout)
    (work/(label+'.stderr')).write_bytes(p.stderr)
    receipt['commands'].append({'label':label,'admission_command':command,'status':p.returncode,'wall_seconds':time.monotonic()-start})
    (work/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    assert p.returncode==0,(label,p.stderr.decode(errors='replace'))
    return p

source=(root/'src/native_text.c').read_bytes()
old=subprocess.check_output(['git','show',receipt['base']+':src/native_text.c'],cwd=root)
old_decl=b'static myl_native_text *view('
new_decl=b'static inline __attribute__((always_inline)) myl_native_text *view('
assert old.count(old_decl)==source.count(new_decl)==1
assert old.replace(old_decl,new_decl)==source
receipt['only_declaration_changed']=True
receipt['native_text_sha256']=hashlib.sha256(source).hexdigest()

shapes=[]
for mode,flags in [('qbe',[]),('llvm-no-lto',['--backend','llvm','--llvm-opt','3']),('llvm-full',['--backend','llvm','--llvm-opt','3','--lto=full']),('llvm-thin',['--backend','llvm','--llvm-opt','3','--lto=thin'])]:
    binary=work/('text_ops.'+mode)
    run(mode+'-build',[compiler,'build',root/'bench/parity/suite/text_ops.my','-o',binary,*flags,'--rc-runtime','--keep-symbols','--cache-dir',work/('cache-'+mode)])
    symbols=subprocess.check_output(['nm','-n','-S',binary]).decode()
    asm=subprocess.check_output(['objdump','-d','--no-show-raw-insn',binary]).decode()
    (work/(mode+'.symbols')).write_text(symbols)
    (work/(mode+'.assembly')).write_text(asm)
    matches=[line for line in symbols.splitlines() if re.search(r'\b[tT] view(?:\.[^ ]*)?$',line)]
    calls=[line for line in asm.splitlines() if re.search(r'\b(call|jmp)\s+.*<view(?:\.[^>]*)?>',line)]
    assert not matches and not calls,(mode,matches,calls)
    assert 'long_piece' in symbols,(mode,'nonvacuous long_piece missing')
    p=run(mode+'-output',[binary])
    assert p.stdout==(root/'bench/parity/suite/text_ops.expected').read_bytes(),mode
    shapes.append({'mode':mode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'out_of_line_view_definitions':len(matches),'out_of_line_view_calls':len(calls),'long_piece_present':True,'output_matches_expected':True})
    receipt['code_shapes']=shapes

expected=set(re.findall(r'^public def (test_[^(]+)',(root/'tests/lang/text_views.my').read_text(),re.M))
assert len(expected)==10
for mode,flags in [('rc',['--rc-runtime']),('gc-stress',['--gc-runtime','--gc-stress'])]:
    p=run('guest-views-'+mode,[compiler,'test',root/'tests/lang/text_views.my',*flags,'--cache-dir',work/('views-cache-'+mode),'--force','--json','--jobs','4'])
    data=json.loads(p.stdout)
    assert data['version']=='native-tests-v1'
    assert data['passed']==data['executed']==len(expected) and data['failed']==data['skipped']==data['cached']==0
    assert {row['name'].split('::')[-1] for row in data['tests']}==expected
    assert all(row['status']=='passed' and row['actual'] is True and row['expected'] is True for row in data['tests'])
    (work/('guest-views-'+mode+'.parsed.json')).write_text(json.dumps(data,indent=2)+'\n')
    receipt.setdefault('guest_views',{})[mode]=data
    print(mode,'passed',data['passed'],'cached',data['cached'],'skipped',data['skipped'],flush=True)
(work/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Focused text_ops matrix completed.',flush=True)
