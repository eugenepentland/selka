target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_9e17d65d841827246848c5d0ddb85bf1c21e01b97a04e1691964273775333481(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v179 = load i64, ptr %slot1, align 8
  %op180 = add i64 %v179, 32
  store i64 %op180, ptr %slot3, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot4, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot5, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot6, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot7, align 8
  %mem189 = alloca i8, i64 8, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot8, align 8
  %mem191 = alloca i8, i64 8, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot9, align 8
  %mem193 = alloca i8, i64 8, align 8
  %ptr194 = ptrtoint ptr %mem193 to i64
  store i64 %ptr194, ptr %slot10, align 8
  %mem195 = alloca i8, i64 8, align 8
  %ptr196 = ptrtoint ptr %mem195 to i64
  store i64 %ptr196, ptr %slot11, align 8
  %mem197 = alloca i8, i64 8, align 8
  %ptr198 = ptrtoint ptr %mem197 to i64
  store i64 %ptr198, ptr %slot12, align 8
  %mem199 = alloca i8, i64 8, align 8
  %ptr200 = ptrtoint ptr %mem199 to i64
  store i64 %ptr200, ptr %slot13, align 8
  %mem201 = alloca i8, i64 8, align 8
  %ptr202 = ptrtoint ptr %mem201 to i64
  store i64 %ptr202, ptr %slot14, align 8
  %mem203 = alloca i8, i64 392, align 8
  %ptr204 = ptrtoint ptr %mem203 to i64
  store i64 %ptr204, ptr %slot15, align 8
  %mem205 = alloca i8, i64 8, align 8
  %ptr206 = ptrtoint ptr %mem205 to i64
  store i64 %ptr206, ptr %slot16, align 8
  %mem207 = alloca i8, i64 392, align 8
  %ptr208 = ptrtoint ptr %mem207 to i64
  store i64 %ptr208, ptr %slot17, align 8
  %mem209 = alloca i8, i64 8, align 8
  %ptr210 = ptrtoint ptr %mem209 to i64
  store i64 %ptr210, ptr %slot18, align 8
  %mem211 = alloca i8, i64 392, align 8
  %ptr212 = ptrtoint ptr %mem211 to i64
  store i64 %ptr212, ptr %slot19, align 8
  %mem213 = alloca i8, i64 8, align 8
  %ptr214 = ptrtoint ptr %mem213 to i64
  store i64 %ptr214, ptr %slot20, align 8
  %mem215 = alloca i8, i64 8, align 8
  %ptr216 = ptrtoint ptr %mem215 to i64
  store i64 %ptr216, ptr %slot21, align 8
  %mem217 = alloca i8, i64 8, align 8
  %ptr218 = ptrtoint ptr %mem217 to i64
  store i64 %ptr218, ptr %slot22, align 8
  %mem219 = alloca i8, i64 8, align 8
  %ptr220 = ptrtoint ptr %mem219 to i64
  store i64 %ptr220, ptr %slot23, align 8
  %mem221 = alloca i8, i64 392, align 8
  %ptr222 = ptrtoint ptr %mem221 to i64
  store i64 %ptr222, ptr %slot24, align 8
  %mem223 = alloca i8, i64 40, align 8
  %ptr224 = ptrtoint ptr %mem223 to i64
  store i64 %ptr224, ptr %slot25, align 8
  %mem225 = alloca i8, i64 392, align 8
  %ptr226 = ptrtoint ptr %mem225 to i64
  store i64 %ptr226, ptr %slot26, align 8
  %mem227 = alloca i8, i64 40, align 8
  %ptr228 = ptrtoint ptr %mem227 to i64
  store i64 %ptr228, ptr %slot27, align 8
  %mem229 = alloca i8, i64 392, align 8
  %ptr230 = ptrtoint ptr %mem229 to i64
  store i64 %ptr230, ptr %slot28, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem231 = alloca i8, i64 8, align 8
  %ptr232 = ptrtoint ptr %mem231 to i64
  store i64 %ptr232, ptr %slot29, align 8
  %v233 = load i64, ptr %slot1, align 8
  %op234 = add i64 %v233, 64
  store i64 %op234, ptr %slot30, align 8
  %v235 = load i64, ptr %slot30, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %ld237 = load i64, ptr %p236, align 8, !alias.scope !4, !noalias !3
  store i64 %ld237, ptr %slot31, align 8
  %stack238 = call ptr @llvm.stacksave()
  %stackaddr239 = ptrtoint ptr %stack238 to i64
  %v240 = load i64, ptr %slot31, align 8
  %cmp241 = icmp ult i64 %stackaddr239, %v240
  %cv242 = zext i1 %cmp241 to i64
  store i64 %cv242, ptr %slot32, align 8
  %v243 = load i64, ptr %slot32, align 8
  %cond244 = icmp ne i64 %v243, 0
  br i1 %cond244, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v245 = load i64, ptr %slot1, align 8
  %p246 = inttoptr i64 %v245 to ptr
  call void @myl_qbe_fail_frame(ptr %p246) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v247 = load i64, ptr %slot2, align 8
  %v248 = load i64, ptr %slot16, align 8
  %p249 = inttoptr i64 %v248 to ptr
  store i64 %v247, ptr %p249, align 8, !alias.scope !3, !noalias !4
  %v250 = load i64, ptr %slot1, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %call252 = call ptr @myl_qbe_heap(ptr %p251) nomerge, !dbg !112
  %calladdr253 = ptrtoint ptr %call252 to i64
  store i64 %calladdr253, ptr %slot33, align 8
  %v254 = load i64, ptr %slot1, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %call256 = call i64 @myl_qbe_region_mark(ptr %p255) nomerge, !dbg !112
  store i64 %call256, ptr %slot34, align 8
  %v257 = load i64, ptr %slot4, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i32 0, ptr %p258, align 4, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot5, align 8
  %p260 = inttoptr i64 %v259 to ptr
  store i32 0, ptr %p260, align 4, !alias.scope !3, !noalias !4
  %v261 = load i64, ptr %slot6, align 8
  %p262 = inttoptr i64 %v261 to ptr
  store i32 0, ptr %p262, align 4, !alias.scope !3, !noalias !4
  %v263 = load i64, ptr %slot7, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i32 0, ptr %p264, align 4, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot8, align 8
  %p266 = inttoptr i64 %v265 to ptr
  store i32 0, ptr %p266, align 4, !alias.scope !3, !noalias !4
  %v267 = load i64, ptr %slot9, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i32 0, ptr %p268, align 4, !alias.scope !3, !noalias !4
  %v269 = load i64, ptr %slot10, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i32 0, ptr %p270, align 4, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot11, align 8
  %p272 = inttoptr i64 %v271 to ptr
  store i32 0, ptr %p272, align 4, !alias.scope !3, !noalias !4
  %v273 = load i64, ptr %slot12, align 8
  %p274 = inttoptr i64 %v273 to ptr
  store i32 0, ptr %p274, align 4, !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot5, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i32 2, ptr %p276, align 4, !alias.scope !3, !noalias !4
  %v277 = load i64, ptr %slot7, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i32 2, ptr %p278, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v279 = load i64, ptr %slot16, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i64, ptr %p280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld281, ptr %slot35, align 8
  %v282 = load i64, ptr %slot35, align 8
  %v283 = load i64, ptr %slot21, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 %v282, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot24, align 8
  store i64 %v285, ptr %slot36, align 8
  %v286 = load i64, ptr %slot36, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i32 0, ptr %p287, align 4, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot36, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i32 3, ptr %p289, align 4, !alias.scope !3, !noalias !4
  %v290 = load i64, ptr %slot36, align 8
  %v291 = load i64, ptr %slot22, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i64 %v290, ptr %p292, align 8, !alias.scope !3, !noalias !4
  %v293 = load i64, ptr %slot22, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot37, align 8
  %v296 = load i64, ptr %slot37, align 8
  %v297 = load i64, ptr %slot18, align 8
  %p298 = inttoptr i64 %v296 to ptr
  %p299 = inttoptr i64 %v297 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p299, ptr %p298, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot21, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot38, align 8
  store i32 0, ptr %slot39, align 8
  %v303 = load i64, ptr %slot8, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i32, ptr %p304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld305, ptr %slot40, align 8
  %v306 = load i32, ptr %slot40, align 8
  %op307 = and i32 %v306, 24
  store i32 %op307, ptr %slot40, align 8
  %v308 = load i32, ptr %slot40, align 8
  %cmp309 = icmp eq i32 %v308, 0
  %cv310 = zext i1 %cmp309 to i32
  store i32 %cv310, ptr %slot41, align 8
  %v311 = load i32, ptr %slot39, align 8
  %v312 = load i32, ptr %slot41, align 8
  %op313 = and i32 %v311, %v312
  store i32 %op313, ptr %slot42, align 8
  %v314 = load i32, ptr %slot42, align 8
  %cv315 = zext i32 %v314 to i64
  %cond316 = icmp ne i64 %cv315, 0
  br i1 %cond316, label %bb_rctake14, label %bb_rccopy14
bb_rctake14:
  %v317 = load i64, ptr %slot15, align 8
  store i64 %v317, ptr %slot43, align 8
  %v318 = load i64, ptr %slot34, align 8
  store i64 %v318, ptr %slot44, align 8
  %v319 = load i64, ptr %slot33, align 8
  %v320 = load i64, ptr %slot43, align 8
  %v321 = load i64, ptr %slot38, align 8
  %v322 = load i64, ptr %slot44, align 8
  %cv323 = trunc i64 %v322 to i32
  %call324 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v319, i64 %v320, i64 %v321, i32 %cv323) nomerge, !dbg !114
  store i32 %call324, ptr %slot45, align 8
  %v325 = load i32, ptr %slot45, align 8
  %cv326 = zext i32 %v325 to i64
  %cond327 = icmp ne i64 %cv326, 0
  br i1 %cond327, label %bb_rcsuccess24, label %bb_rcfailure24
bb_rcfailure24:
  %v328 = load i64, ptr %slot33, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %call330 = call i32 @myl_rc_take_failure(ptr %p329) nomerge, !dbg !114
  store i32 %call330, ptr %slot46, align 8
  %v331 = load i64, ptr %slot1, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %v333 = load i32, ptr %slot46, align 8
  %call334 = call i32 @myl_qbe_rc_status(ptr %p332, i32 %v333) nomerge, !dbg !114
  store i32 %call334, ptr %slot47, align 8
  br label %bb_failure
bb_rcsuccess24:
  %v335 = load i64, ptr %slot12, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i32 2, ptr %p336, align 4, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot11, align 8
  %p338 = inttoptr i64 %v337 to ptr
  store i32 1, ptr %p338, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared14
bb_rccopy14:
  %v339 = load i64, ptr %slot15, align 8
  store i64 %v339, ptr %slot48, align 8
  %v340 = load i64, ptr %slot34, align 8
  store i64 %v340, ptr %slot49, align 8
  %v341 = load i64, ptr %slot33, align 8
  %v342 = load i64, ptr %slot48, align 8
  %v343 = load i64, ptr %slot38, align 8
  %v344 = load i64, ptr %slot49, align 8
  %cv345 = trunc i64 %v344 to i32
  %call346 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v341, i64 %v342, i64 %v343, i32 %cv345) nomerge, !dbg !114
  store i32 %call346, ptr %slot50, align 8
  %v347 = load i32, ptr %slot50, align 8
  %cv348 = zext i32 %v347 to i64
  %cond349 = icmp ne i64 %cv348, 0
  br i1 %cond349, label %bb_rcsuccess33, label %bb_rcfailure33
bb_rcfailure33:
  %v350 = load i64, ptr %slot33, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %call352 = call i32 @myl_rc_take_failure(ptr %p351) nomerge, !dbg !114
  store i32 %call352, ptr %slot51, align 8
  %v353 = load i64, ptr %slot1, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %v355 = load i32, ptr %slot51, align 8
  %call356 = call i32 @myl_qbe_rc_status(ptr %p354, i32 %v355) nomerge, !dbg !114
  store i32 %call356, ptr %slot52, align 8
  br label %bb_failure
bb_rcsuccess33:
  %v357 = load i64, ptr %slot12, align 8
  %p358 = inttoptr i64 %v357 to ptr
  store i32 2, ptr %p358, align 4, !alias.scope !3, !noalias !4
  %v359 = load i64, ptr %slot11, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i32 1, ptr %p360, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared14
bb_rcprepared14:
  %v361 = load i64, ptr %slot4, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %ld363 = load i32, ptr %p362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld363, ptr %slot53, align 8
  %v364 = load i32, ptr %slot53, align 8
  %cv365 = zext i32 %v364 to i64
  %cond366 = icmp ne i64 %cv365, 0
  br i1 %cond366, label %bb_rcslotdrop50, label %bb_rcslotdone50
bb_rcslotdrop50:
  %v367 = load i64, ptr %slot4, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i32 0, ptr %p368, align 4, !alias.scope !3, !noalias !4
  %v369 = load i64, ptr %slot17, align 8
  store i64 %v369, ptr %slot54, align 8
  %v370 = load i64, ptr %slot5, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i32, ptr %p371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld372, ptr %slot55, align 8
  %v373 = load i32, ptr %slot55, align 8
  %op374 = and i32 %v373, 28
  store i32 %op374, ptr %slot56, align 8
  %v375 = load i32, ptr %slot56, align 8
  %cv376 = zext i32 %v375 to i64
  %cond377 = icmp ne i64 %cv376, 0
  br i1 %cond377, label %bb_rcslotrole50, label %bb_rcslotowner50
bb_rcslotrole50:
  %v378 = load i64, ptr %slot33, align 8
  store i64 %v378, ptr %slot57, align 8
  %v379 = load i64, ptr %slot57, align 8
  %v380 = load i64, ptr %slot54, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v379, i64 %v380) nomerge, !dbg !114
  br label %bb_rcslotdone50
bb_rcslotowner50:
  %v381 = load i64, ptr %slot33, align 8
  store i64 %v381, ptr %slot58, align 8
  %v382 = load i64, ptr %slot58, align 8
  %v383 = load i64, ptr %slot54, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v382, i64 %v383) nomerge, !dbg !114
  br label %bb_rcslotdone50
bb_rcslotdone50:
  %v384 = load i64, ptr %slot17, align 8
  store i64 %v384, ptr %slot59, align 8
  %v385 = load i64, ptr %slot15, align 8
  store i64 %v385, ptr %slot60, align 8
  %v386 = load i64, ptr %slot60, align 8
  %v387 = load i64, ptr %slot59, align 8
  %p388 = inttoptr i64 %v386 to ptr
  %p389 = inttoptr i64 %v387 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p389, ptr %p388, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot11, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i32 0, ptr %p391, align 4, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot5, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i32 2, ptr %p393, align 4, !alias.scope !3, !noalias !4
  %v394 = load i64, ptr %slot12, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i32, ptr %p395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld396, ptr %slot61, align 8
  %v397 = load i32, ptr %slot61, align 8
  %v398 = load i64, ptr %slot5, align 8
  %p399 = inttoptr i64 %v398 to ptr
  store i32 %v397, ptr %p399, align 4, !alias.scope !3, !noalias !4
  %v400 = load i64, ptr %slot4, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i32 1, ptr %p401, align 4, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot17, align 8
  %v403 = load i64, ptr %slot21, align 8
  %p404 = inttoptr i64 %v403 to ptr
  store i64 %v402, ptr %p404, align 8, !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot21, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i64, ptr %p406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld407, ptr %slot62, align 8
  %v408 = load i64, ptr %slot62, align 8
  %op409 = add i64 %v408, 288
  store i64 %op409, ptr %slot63, align 8
  %v410 = load i64, ptr %slot63, align 8
  %v411 = load i64, ptr %slot21, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i64 %v410, ptr %p412, align 8, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot21, align 8
  %p414 = inttoptr i64 %v413 to ptr
  %ld415 = load i64, ptr %p414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld415, ptr %slot64, align 8
  %v416 = load i64, ptr %slot64, align 8
  %op417 = add i64 %v416, 0
  store i64 %op417, ptr %slot65, align 8
  %v418 = load i64, ptr %slot65, align 8
  %v419 = load i64, ptr %slot21, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i64 %v418, ptr %p420, align 8, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot21, align 8
  %p422 = inttoptr i64 %v421 to ptr
  %ld423 = load i64, ptr %p422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld423, ptr %slot66, align 8
  %v424 = load i64, ptr %slot25, align 8
  store i64 %v424, ptr %slot67, align 8
  %v425 = load i64, ptr %slot66, align 8
  %v426 = load i64, ptr %slot67, align 8
  %p427 = inttoptr i64 %v425 to ptr
  %p428 = inttoptr i64 %v426 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p428, ptr %p427, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v429 = load i64, ptr %slot67, align 8
  %v430 = load i64, ptr %slot21, align 8
  %p431 = inttoptr i64 %v430 to ptr
  store i64 %v429, ptr %p431, align 8, !alias.scope !3, !noalias !4
  %v432 = load i64, ptr %slot18, align 8
  %v433 = load i64, ptr %slot22, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i64 %v432, ptr %p434, align 8, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot22, align 8
  %p436 = inttoptr i64 %v435 to ptr
  %ld437 = load i64, ptr %p436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld437, ptr %slot68, align 8
  %v438 = load i64, ptr %slot21, align 8
  %p439 = inttoptr i64 %v438 to ptr
  %ld440 = load i64, ptr %p439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld440, ptr %slot69, align 8
  %v441 = load i64, ptr %slot69, align 8
  %p442 = inttoptr i64 %v441 to ptr
  %ld443 = load i32, ptr %p442, align 4, !alias.scope !3, !noalias !4
  %ext444 = zext i32 %ld443 to i64
  store i64 %ext444, ptr %slot70, align 8
  %v445 = load i64, ptr %slot68, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %ld447 = load i32, ptr %p446, align 4, !alias.scope !3, !noalias !4
  %ext448 = zext i32 %ld447 to i64
  store i64 %ext448, ptr %slot71, align 8
  %v449 = load i64, ptr %slot70, align 8
  %v450 = load i64, ptr %slot71, align 8
  %cmp451 = icmp eq i64 %v449, %v450
  %cv452 = zext i1 %cmp451 to i64
  store i64 %cv452, ptr %slot72, align 8
  %v453 = load i64, ptr %slot72, align 8
  %v454 = load i64, ptr %slot21, align 8
  %p455 = inttoptr i64 %v454 to ptr
  store i64 %v453, ptr %p455, align 8, !alias.scope !3, !noalias !4
  br label %bb_i10
bb_i10:
  %v456 = load i64, ptr %slot21, align 8
  %p457 = inttoptr i64 %v456 to ptr
  %ld458 = load i64, ptr %p457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld458, ptr %slot73, align 8
  %v459 = load i64, ptr %slot73, align 8
  %op460 = xor i64 %v459, 1
  store i64 %op460, ptr %slot74, align 8
  %v461 = load i64, ptr %slot74, align 8
  %v462 = load i64, ptr %slot21, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i64 %v461, ptr %p463, align 8, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot21, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i64, ptr %p465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld466, ptr %slot75, align 8
  %v467 = load i64, ptr %slot75, align 8
  %cond468 = icmp ne i64 %v467, 0
  br i1 %cond468, label %bb_next96, label %bb_i24
bb_next96:
  %v469 = load i64, ptr %slot16, align 8
  %p470 = inttoptr i64 %v469 to ptr
  %ld471 = load i64, ptr %p470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld471, ptr %slot76, align 8
  %v472 = load i64, ptr %slot76, align 8
  %v473 = load i64, ptr %slot21, align 8
  %p474 = inttoptr i64 %v473 to ptr
  store i64 %v472, ptr %p474, align 8, !alias.scope !3, !noalias !4
  %v475 = load i64, ptr %slot26, align 8
  store i64 %v475, ptr %slot77, align 8
  %v476 = load i64, ptr %slot77, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i32 0, ptr %p477, align 4, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot77, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i32 39, ptr %p479, align 4, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot77, align 8
  %v481 = load i64, ptr %slot22, align 8
  %p482 = inttoptr i64 %v481 to ptr
  store i64 %v480, ptr %p482, align 8, !alias.scope !3, !noalias !4
  %v483 = load i64, ptr %slot22, align 8
  %p484 = inttoptr i64 %v483 to ptr
  %ld485 = load i64, ptr %p484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld485, ptr %slot78, align 8
  %v486 = load i64, ptr %slot78, align 8
  %v487 = load i64, ptr %slot20, align 8
  %p488 = inttoptr i64 %v486 to ptr
  %p489 = inttoptr i64 %v487 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p489, ptr %p488, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot21, align 8
  %p491 = inttoptr i64 %v490 to ptr
  %ld492 = load i64, ptr %p491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld492, ptr %slot79, align 8
  store i32 0, ptr %slot80, align 8
  %v493 = load i64, ptr %slot8, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %ld495 = load i32, ptr %p494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld495, ptr %slot81, align 8
  %v496 = load i32, ptr %slot81, align 8
  %op497 = and i32 %v496, 24
  store i32 %op497, ptr %slot81, align 8
  %v498 = load i32, ptr %slot81, align 8
  %cmp499 = icmp eq i32 %v498, 0
  %cv500 = zext i1 %cmp499 to i32
  store i32 %cv500, ptr %slot82, align 8
  %v501 = load i32, ptr %slot80, align 8
  %v502 = load i32, ptr %slot82, align 8
  %op503 = and i32 %v501, %v502
  store i32 %op503, ptr %slot83, align 8
  %v504 = load i32, ptr %slot83, align 8
  %cv505 = zext i32 %v504 to i64
  %cond506 = icmp ne i64 %cv505, 0
  br i1 %cond506, label %bb_rctake100, label %bb_rccopy100
bb_rctake100:
  %v507 = load i64, ptr %slot15, align 8
  store i64 %v507, ptr %slot84, align 8
  %v508 = load i64, ptr %slot34, align 8
  store i64 %v508, ptr %slot85, align 8
  %v509 = load i64, ptr %slot33, align 8
  %v510 = load i64, ptr %slot84, align 8
  %v511 = load i64, ptr %slot79, align 8
  %v512 = load i64, ptr %slot85, align 8
  %cv513 = trunc i64 %v512 to i32
  %call514 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v509, i64 %v510, i64 %v511, i32 %cv513) nomerge, !dbg !116
  store i32 %call514, ptr %slot86, align 8
  %v515 = load i32, ptr %slot86, align 8
  %cv516 = zext i32 %v515 to i64
  %cond517 = icmp ne i64 %cv516, 0
  br i1 %cond517, label %bb_rcsuccess110, label %bb_rcfailure110
bb_rcfailure110:
  %v518 = load i64, ptr %slot33, align 8
  %p519 = inttoptr i64 %v518 to ptr
  %call520 = call i32 @myl_rc_take_failure(ptr %p519) nomerge, !dbg !116
  store i32 %call520, ptr %slot87, align 8
  %v521 = load i64, ptr %slot1, align 8
  %p522 = inttoptr i64 %v521 to ptr
  %v523 = load i32, ptr %slot87, align 8
  %call524 = call i32 @myl_qbe_rc_status(ptr %p522, i32 %v523) nomerge, !dbg !116
  store i32 %call524, ptr %slot88, align 8
  br label %bb_failure
bb_rcsuccess110:
  %v525 = load i64, ptr %slot12, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 2, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %v527 = load i64, ptr %slot11, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i32 1, ptr %p528, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared100
bb_rccopy100:
  %v529 = load i64, ptr %slot15, align 8
  store i64 %v529, ptr %slot89, align 8
  %v530 = load i64, ptr %slot34, align 8
  store i64 %v530, ptr %slot90, align 8
  %v531 = load i64, ptr %slot33, align 8
  %v532 = load i64, ptr %slot89, align 8
  %v533 = load i64, ptr %slot79, align 8
  %v534 = load i64, ptr %slot90, align 8
  %cv535 = trunc i64 %v534 to i32
  %call536 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v531, i64 %v532, i64 %v533, i32 %cv535) nomerge, !dbg !116
  store i32 %call536, ptr %slot91, align 8
  %v537 = load i32, ptr %slot91, align 8
  %cv538 = zext i32 %v537 to i64
  %cond539 = icmp ne i64 %cv538, 0
  br i1 %cond539, label %bb_rcsuccess119, label %bb_rcfailure119
bb_rcfailure119:
  %v540 = load i64, ptr %slot33, align 8
  %p541 = inttoptr i64 %v540 to ptr
  %call542 = call i32 @myl_rc_take_failure(ptr %p541) nomerge, !dbg !116
  store i32 %call542, ptr %slot92, align 8
  %v543 = load i64, ptr %slot1, align 8
  %p544 = inttoptr i64 %v543 to ptr
  %v545 = load i32, ptr %slot92, align 8
  %call546 = call i32 @myl_qbe_rc_status(ptr %p544, i32 %v545) nomerge, !dbg !116
  store i32 %call546, ptr %slot93, align 8
  br label %bb_failure
bb_rcsuccess119:
  %v547 = load i64, ptr %slot12, align 8
  %p548 = inttoptr i64 %v547 to ptr
  store i32 2, ptr %p548, align 4, !alias.scope !3, !noalias !4
  %v549 = load i64, ptr %slot11, align 8
  %p550 = inttoptr i64 %v549 to ptr
  store i32 1, ptr %p550, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared100
bb_rcprepared100:
  %v551 = load i64, ptr %slot6, align 8
  %p552 = inttoptr i64 %v551 to ptr
  %ld553 = load i32, ptr %p552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld553, ptr %slot94, align 8
  %v554 = load i32, ptr %slot94, align 8
  %cv555 = zext i32 %v554 to i64
  %cond556 = icmp ne i64 %cv555, 0
  br i1 %cond556, label %bb_rcslotdrop136, label %bb_rcslotdone136
bb_rcslotdrop136:
  %v557 = load i64, ptr %slot6, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i32 0, ptr %p558, align 4, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot19, align 8
  store i64 %v559, ptr %slot95, align 8
  %v560 = load i64, ptr %slot7, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i32, ptr %p561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld562, ptr %slot96, align 8
  %v563 = load i32, ptr %slot96, align 8
  %op564 = and i32 %v563, 28
  store i32 %op564, ptr %slot97, align 8
  %v565 = load i32, ptr %slot97, align 8
  %cv566 = zext i32 %v565 to i64
  %cond567 = icmp ne i64 %cv566, 0
  br i1 %cond567, label %bb_rcslotrole136, label %bb_rcslotowner136
bb_rcslotrole136:
  %v568 = load i64, ptr %slot33, align 8
  store i64 %v568, ptr %slot98, align 8
  %v569 = load i64, ptr %slot98, align 8
  %v570 = load i64, ptr %slot95, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v569, i64 %v570) nomerge, !dbg !116
  br label %bb_rcslotdone136
bb_rcslotowner136:
  %v571 = load i64, ptr %slot33, align 8
  store i64 %v571, ptr %slot99, align 8
  %v572 = load i64, ptr %slot99, align 8
  %v573 = load i64, ptr %slot95, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v572, i64 %v573) nomerge, !dbg !116
  br label %bb_rcslotdone136
bb_rcslotdone136:
  %v574 = load i64, ptr %slot19, align 8
  store i64 %v574, ptr %slot100, align 8
  %v575 = load i64, ptr %slot15, align 8
  store i64 %v575, ptr %slot101, align 8
  %v576 = load i64, ptr %slot101, align 8
  %v577 = load i64, ptr %slot100, align 8
  %p578 = inttoptr i64 %v576 to ptr
  %p579 = inttoptr i64 %v577 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p579, ptr %p578, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v580 = load i64, ptr %slot11, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i32 0, ptr %p581, align 4, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot7, align 8
  %p583 = inttoptr i64 %v582 to ptr
  store i32 2, ptr %p583, align 4, !alias.scope !3, !noalias !4
  %v584 = load i64, ptr %slot12, align 8
  %p585 = inttoptr i64 %v584 to ptr
  %ld586 = load i32, ptr %p585, align 4, !alias.scope !3, !noalias !4
  store i32 %ld586, ptr %slot102, align 8
  %v587 = load i32, ptr %slot102, align 8
  %v588 = load i64, ptr %slot7, align 8
  %p589 = inttoptr i64 %v588 to ptr
  store i32 %v587, ptr %p589, align 4, !alias.scope !3, !noalias !4
  %v590 = load i64, ptr %slot6, align 8
  %p591 = inttoptr i64 %v590 to ptr
  store i32 1, ptr %p591, align 4, !alias.scope !3, !noalias !4
  %v592 = load i64, ptr %slot19, align 8
  %v593 = load i64, ptr %slot21, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i64 %v592, ptr %p594, align 8, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot21, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i64, ptr %p596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld597, ptr %slot103, align 8
  %v598 = load i64, ptr %slot103, align 8
  %op599 = add i64 %v598, 288
  store i64 %op599, ptr %slot104, align 8
  %v600 = load i64, ptr %slot104, align 8
  %v601 = load i64, ptr %slot21, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i64 %v600, ptr %p602, align 8, !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot21, align 8
  %p604 = inttoptr i64 %v603 to ptr
  %ld605 = load i64, ptr %p604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld605, ptr %slot105, align 8
  %v606 = load i64, ptr %slot105, align 8
  %op607 = add i64 %v606, 0
  store i64 %op607, ptr %slot106, align 8
  %v608 = load i64, ptr %slot106, align 8
  %v609 = load i64, ptr %slot21, align 8
  %p610 = inttoptr i64 %v609 to ptr
  store i64 %v608, ptr %p610, align 8, !alias.scope !3, !noalias !4
  %v611 = load i64, ptr %slot21, align 8
  %p612 = inttoptr i64 %v611 to ptr
  %ld613 = load i64, ptr %p612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld613, ptr %slot107, align 8
  %v614 = load i64, ptr %slot27, align 8
  store i64 %v614, ptr %slot108, align 8
  %v615 = load i64, ptr %slot107, align 8
  %v616 = load i64, ptr %slot108, align 8
  %p617 = inttoptr i64 %v615 to ptr
  %p618 = inttoptr i64 %v616 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p618, ptr %p617, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v619 = load i64, ptr %slot108, align 8
  %v620 = load i64, ptr %slot21, align 8
  %p621 = inttoptr i64 %v620 to ptr
  store i64 %v619, ptr %p621, align 8, !alias.scope !3, !noalias !4
  %v622 = load i64, ptr %slot20, align 8
  %v623 = load i64, ptr %slot22, align 8
  %p624 = inttoptr i64 %v623 to ptr
  store i64 %v622, ptr %p624, align 8, !alias.scope !3, !noalias !4
  %v625 = load i64, ptr %slot22, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ld627 = load i64, ptr %p626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld627, ptr %slot109, align 8
  %v628 = load i64, ptr %slot21, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %ld630 = load i64, ptr %p629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld630, ptr %slot110, align 8
  %v631 = load i64, ptr %slot110, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %ld633 = load i32, ptr %p632, align 4, !alias.scope !3, !noalias !4
  %ext634 = zext i32 %ld633 to i64
  store i64 %ext634, ptr %slot111, align 8
  %v635 = load i64, ptr %slot109, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i32, ptr %p636, align 4, !alias.scope !3, !noalias !4
  %ext638 = zext i32 %ld637 to i64
  store i64 %ext638, ptr %slot112, align 8
  %v639 = load i64, ptr %slot111, align 8
  %v640 = load i64, ptr %slot112, align 8
  %cmp641 = icmp eq i64 %v639, %v640
  %cv642 = zext i1 %cmp641 to i64
  store i64 %cv642, ptr %slot113, align 8
  %v643 = load i64, ptr %slot113, align 8
  %v644 = load i64, ptr %slot21, align 8
  %p645 = inttoptr i64 %v644 to ptr
  store i64 %v643, ptr %p645, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i22:
  %v646 = load i64, ptr %slot21, align 8
  %p647 = inttoptr i64 %v646 to ptr
  %ld648 = load i64, ptr %p647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld648, ptr %slot114, align 8
  %v649 = load i64, ptr %slot114, align 8
  %op650 = xor i64 %v649, 1
  store i64 %op650, ptr %slot115, align 8
  %v651 = load i64, ptr %slot115, align 8
  %v652 = load i64, ptr %slot21, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i64 %v651, ptr %p653, align 8, !alias.scope !3, !noalias !4
  br label %bb_i25
bb_i24:
  %v654 = load i64, ptr %slot21, align 8
  %p655 = inttoptr i64 %v654 to ptr
  store i64 0, ptr %p655, align 8, !alias.scope !3, !noalias !4
  br label %bb_i25
bb_i25:
  %v656 = load i64, ptr %slot21, align 8
  %p657 = inttoptr i64 %v656 to ptr
  %ld658 = load i64, ptr %p657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld658, ptr %slot116, align 8
  %v659 = load i64, ptr %slot116, align 8
  %cond660 = icmp ne i64 %v659, 0
  br i1 %cond660, label %bb_next182, label %bb_i30
bb_next182:
  %v661 = load i64, ptr %slot16, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %ld663 = load i64, ptr %p662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld663, ptr %slot117, align 8
  %v664 = load i64, ptr %slot117, align 8
  %v665 = load i64, ptr %slot21, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i64 %v664, ptr %p666, align 8, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot21, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %ld669 = load i64, ptr %p668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld669, ptr %slot118, align 8
  %v670 = load i64, ptr %slot1, align 8
  %v671 = load i64, ptr %slot118, align 8
  %call672 = call i64 @myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8(i64 %v670, i64 %v671) nomerge, !dbg !118
  store i64 %call672, ptr %slot119, align 8
  %v673 = load i64, ptr %slot119, align 8
  %v674 = load i64, ptr %slot21, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 %v673, ptr %p675, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i30:
  %v676 = load i64, ptr %slot16, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot120, align 8
  %v679 = load i64, ptr %slot120, align 8
  %v680 = load i64, ptr %slot21, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 %v679, ptr %p681, align 8, !alias.scope !3, !noalias !4
  %v682 = load i64, ptr %slot28, align 8
  store i64 %v682, ptr %slot121, align 8
  %v683 = load i64, ptr %slot121, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i32 0, ptr %p684, align 4, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot121, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i32 3, ptr %p686, align 4, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot121, align 8
  %v688 = load i64, ptr %slot22, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i64 %v687, ptr %p689, align 8, !alias.scope !3, !noalias !4
  %p690 = inttoptr i64 ptrtoint (ptr @myl_lit_146d534849d3e93fd30ab0fa32197316072c792978757f394cddd3246cba50a7 to i64) to ptr
  %ld691 = load i64, ptr %p690, align 8, !alias.scope !4, !noalias !3
  store i64 %ld691, ptr %slot122, align 8
  %v692 = load i64, ptr %slot122, align 8
  %v693 = load i64, ptr %slot23, align 8
  %p694 = inttoptr i64 %v693 to ptr
  store i64 %v692, ptr %p694, align 8, !alias.scope !3, !noalias !4
  %v695 = load i64, ptr %slot23, align 8
  %p696 = inttoptr i64 %v695 to ptr
  %ld697 = load i64, ptr %p696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld697, ptr %slot123, align 8
  %v698 = load i64, ptr %slot123, align 8
  %v699 = load i64, ptr %slot14, align 8
  %p700 = inttoptr i64 %v699 to ptr
  store i64 %v698, ptr %p700, align 8, !alias.scope !3, !noalias !4
  %v701 = load i64, ptr %slot14, align 8
  store i64 %v701, ptr %slot124, align 8
  %v702 = load i64, ptr %slot15, align 8
  store i64 %v702, ptr %slot125, align 8
  %v703 = load i64, ptr %slot124, align 8
  %v704 = load i64, ptr %slot125, align 8
  %p705 = inttoptr i64 %v703 to ptr
  %p706 = inttoptr i64 %v704 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p706, ptr %p705, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v707 = load i64, ptr %slot12, align 8
  %p708 = inttoptr i64 %v707 to ptr
  store i32 2, ptr %p708, align 4, !alias.scope !3, !noalias !4
  %v709 = load i64, ptr %slot11, align 8
  %p710 = inttoptr i64 %v709 to ptr
  store i32 1, ptr %p710, align 4, !alias.scope !3, !noalias !4
  %v711 = load i64, ptr %slot13, align 8
  store i64 %v711, ptr %slot126, align 8
  %v712 = load i64, ptr %slot15, align 8
  store i64 %v712, ptr %slot127, align 8
  %v713 = load i64, ptr %slot127, align 8
  %v714 = load i64, ptr %slot126, align 8
  %p715 = inttoptr i64 %v713 to ptr
  %p716 = inttoptr i64 %v714 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p716, ptr %p715, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v717 = load i64, ptr %slot10, align 8
  %p718 = inttoptr i64 %v717 to ptr
  store i32 2, ptr %p718, align 4, !alias.scope !3, !noalias !4
  %v719 = load i64, ptr %slot12, align 8
  %p720 = inttoptr i64 %v719 to ptr
  %ld721 = load i32, ptr %p720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld721, ptr %slot128, align 8
  %v722 = load i32, ptr %slot128, align 8
  %v723 = load i64, ptr %slot10, align 8
  %p724 = inttoptr i64 %v723 to ptr
  store i32 %v722, ptr %p724, align 4, !alias.scope !3, !noalias !4
  %v725 = load i64, ptr %slot11, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i32 0, ptr %p726, align 4, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot9, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i32 1, ptr %p728, align 4, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot126, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %ld731 = load i64, ptr %p730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld731, ptr %slot129, align 8
  %v732 = load i64, ptr %slot129, align 8
  %v733 = load i64, ptr %slot23, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 %v732, ptr %p734, align 8, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot21, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld737, ptr %slot130, align 8
  %v738 = load i64, ptr %slot22, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i64, ptr %p739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld740, ptr %slot131, align 8
  %v741 = load i64, ptr %slot23, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %ld743 = load i64, ptr %p742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld743, ptr %slot132, align 8
  %v744 = load i64, ptr %slot1, align 8
  %v745 = load i64, ptr %slot130, align 8
  %v746 = load i64, ptr %slot131, align 8
  %v747 = load i64, ptr %slot132, align 8
  %call748 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v744, i64 %v745, i64 %v746, i64 %v747) nomerge, !dbg !120
  store i64 %call748, ptr %slot133, align 8
  %v749 = load i64, ptr %slot133, align 8
  %v750 = load i64, ptr %slot21, align 8
  %p751 = inttoptr i64 %v750 to ptr
  store i64 %v749, ptr %p751, align 8, !alias.scope !3, !noalias !4
  %v752 = load i64, ptr %slot9, align 8
  %p753 = inttoptr i64 %v752 to ptr
  %ld754 = load i32, ptr %p753, align 4, !alias.scope !3, !noalias !4
  store i32 %ld754, ptr %slot134, align 8
  %v755 = load i32, ptr %slot134, align 8
  %cv756 = zext i32 %v755 to i64
  %cond757 = icmp ne i64 %cv756, 0
  br i1 %cond757, label %bb_rcslotdrop227, label %bb_rcslotdone227
bb_rcslotdrop227:
  %v758 = load i64, ptr %slot9, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i32 0, ptr %p759, align 4, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot13, align 8
  store i64 %v760, ptr %slot135, align 8
  %v761 = load i64, ptr %slot10, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %ld763 = load i32, ptr %p762, align 4, !alias.scope !3, !noalias !4
  store i32 %ld763, ptr %slot136, align 8
  %v764 = load i32, ptr %slot136, align 8
  %op765 = and i32 %v764, 28
  store i32 %op765, ptr %slot137, align 8
  %v766 = load i32, ptr %slot137, align 8
  %cv767 = zext i32 %v766 to i64
  %cond768 = icmp ne i64 %cv767, 0
  br i1 %cond768, label %bb_rcslotrole227, label %bb_rcslotowner227
bb_rcslotrole227:
  %v769 = load i64, ptr %slot33, align 8
  store i64 %v769, ptr %slot138, align 8
  %v770 = load i64, ptr %slot135, align 8
  %p771 = inttoptr i64 %v770 to ptr
  %ld772 = load i64, ptr %p771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld772, ptr %slot139, align 8
  %v773 = load i64, ptr %slot139, align 8
  %cmp774 = icmp ne i64 %v773, 0
  %cv775 = zext i1 %cmp774 to i32
  store i32 %cv775, ptr %slot140, align 8
  %v776 = load i32, ptr %slot140, align 8
  %cv777 = zext i32 %v776 to i64
  %cond778 = icmp ne i64 %cv777, 0
  br i1 %cond778, label %bb_rcgnn243, label %bb_rcgdone243
bb_rcgnn243:
  %v779 = load i64, ptr %slot139, align 8
  %op780 = sub i64 %v779, 16
  store i64 %op780, ptr %slot141, align 8
  %v781 = load i64, ptr %slot139, align 8
  %p782 = inttoptr i64 %v781 to ptr
  %rgep783 = getelementptr i8, ptr %p782, i64 -16
  %ld784 = load i64, ptr %rgep783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld784, ptr %slot142, align 8
  %v785 = load i64, ptr %slot142, align 8
  %op786 = and i64 %v785, 4611686018427387906
  store i64 %op786, ptr %slot143, align 8
  %v787 = load i64, ptr %slot143, align 8
  %cmp788 = icmp ne i64 %v787, 0
  %cv789 = zext i1 %cmp788 to i32
  store i32 %cv789, ptr %slot144, align 8
  %v790 = load i32, ptr %slot144, align 8
  %cv791 = zext i32 %v790 to i64
  %cond792 = icmp ne i64 %cv791, 0
  br i1 %cond792, label %bb_rcgclear243, label %bb_rcgcounted243
bb_rcgcounted243:
  %v793 = load i64, ptr %slot139, align 8
  %op794 = sub i64 %v793, 24
  store i64 %op794, ptr %slot145, align 8
  %v795 = load i64, ptr %slot139, align 8
  %p796 = inttoptr i64 %v795 to ptr
  %rgep797 = getelementptr i8, ptr %p796, i64 -24
  %ld798 = load i64, ptr %rgep797, align 8, !alias.scope !9, !noalias !10
  store i64 %ld798, ptr %slot146, align 8
  %v799 = load i64, ptr %slot146, align 8
  %op800 = sub i64 %v799, 1
  store i64 %op800, ptr %slot147, align 8
  %v801 = load i64, ptr %slot147, align 8
  %cmp802 = icmp eq i64 %v801, 0
  %cv803 = zext i1 %cmp802 to i32
  store i32 %cv803, ptr %slot148, align 8
  %v804 = load i32, ptr %slot148, align 8
  %cv805 = zext i32 %v804 to i64
  %cond806 = icmp ne i64 %cv805, 0
  br i1 %cond806, label %bb_rcglast243, label %bb_rcgdec243
bb_rcglast243:
  %v807 = load i64, ptr %slot139, align 8
  %op808 = sub i64 %v807, 32
  store i64 %op808, ptr %slot149, align 8
  %v809 = load i64, ptr %slot139, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %rgep811 = getelementptr i8, ptr %p810, i64 -32
  %ld812 = load i64, ptr %rgep811, align 8, !alias.scope !9, !noalias !10
  store i64 %ld812, ptr %slot150, align 8
  %v813 = load i64, ptr %slot150, align 8
  %cmp814 = icmp ne i64 %v813, 0
  %cv815 = zext i1 %cmp814 to i32
  store i32 %cv815, ptr %slot151, align 8
  %v816 = load i32, ptr %slot151, align 8
  %cv817 = zext i32 %v816 to i64
  %cond818 = icmp ne i64 %cv817, 0
  br i1 %cond818, label %bb_rcgdec243, label %bb_rcgslow243
bb_rcgslow243:
  %v819 = load i64, ptr %slot138, align 8
  %v820 = load i64, ptr %slot135, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v819, i64 %v820) nomerge, !dbg !120
  br label %bb_rcgdone243
bb_rcgdec243:
  %v821 = load i64, ptr %slot147, align 8
  %v822 = load i64, ptr %slot139, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %rgep824 = getelementptr i8, ptr %p823, i64 -24
  store i64 %v821, ptr %rgep824, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear243
bb_rcgclear243:
  %v825 = load i64, ptr %slot135, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i64 0, ptr %p826, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone243
bb_rcgdone243:
  br label %bb_rcslotdone227
bb_rcslotowner227:
  %v827 = load i64, ptr %slot33, align 8
  store i64 %v827, ptr %slot152, align 8
  %v828 = load i64, ptr %slot135, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %ld830 = load i64, ptr %p829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld830, ptr %slot153, align 8
  %v831 = load i64, ptr %slot153, align 8
  %cmp832 = icmp ne i64 %v831, 0
  %cv833 = zext i1 %cmp832 to i32
  store i32 %cv833, ptr %slot154, align 8
  %v834 = load i32, ptr %slot154, align 8
  %cv835 = zext i32 %v834 to i64
  %cond836 = icmp ne i64 %cv835, 0
  br i1 %cond836, label %bb_rcgnn258, label %bb_rcgdone258
bb_rcgnn258:
  %v837 = load i64, ptr %slot153, align 8
  %op838 = sub i64 %v837, 16
  store i64 %op838, ptr %slot155, align 8
  %v839 = load i64, ptr %slot153, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %rgep841 = getelementptr i8, ptr %p840, i64 -16
  %ld842 = load i64, ptr %rgep841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld842, ptr %slot156, align 8
  %v843 = load i64, ptr %slot156, align 8
  %op844 = and i64 %v843, 4611686018427387906
  store i64 %op844, ptr %slot157, align 8
  %v845 = load i64, ptr %slot157, align 8
  %cmp846 = icmp ne i64 %v845, 0
  %cv847 = zext i1 %cmp846 to i32
  store i32 %cv847, ptr %slot158, align 8
  %v848 = load i32, ptr %slot158, align 8
  %cv849 = zext i32 %v848 to i64
  %cond850 = icmp ne i64 %cv849, 0
  br i1 %cond850, label %bb_rcgclear258, label %bb_rcgcounted258
bb_rcgcounted258:
  %v851 = load i64, ptr %slot153, align 8
  %op852 = sub i64 %v851, 32
  store i64 %op852, ptr %slot159, align 8
  %v853 = load i64, ptr %slot153, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %rgep855 = getelementptr i8, ptr %p854, i64 -32
  %ld856 = load i64, ptr %rgep855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld856, ptr %slot160, align 8
  %v857 = load i64, ptr %slot160, align 8
  %op858 = sub i64 %v857, 1
  store i64 %op858, ptr %slot161, align 8
  %v859 = load i64, ptr %slot161, align 8
  %cmp860 = icmp eq i64 %v859, 0
  %cv861 = zext i1 %cmp860 to i32
  store i32 %cv861, ptr %slot162, align 8
  %v862 = load i32, ptr %slot162, align 8
  %cv863 = zext i32 %v862 to i64
  %cond864 = icmp ne i64 %cv863, 0
  br i1 %cond864, label %bb_rcglast258, label %bb_rcgdec258
bb_rcglast258:
  %v865 = load i64, ptr %slot153, align 8
  %op866 = sub i64 %v865, 24
  store i64 %op866, ptr %slot163, align 8
  %v867 = load i64, ptr %slot153, align 8
  %p868 = inttoptr i64 %v867 to ptr
  %rgep869 = getelementptr i8, ptr %p868, i64 -24
  %ld870 = load i64, ptr %rgep869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld870, ptr %slot164, align 8
  %v871 = load i64, ptr %slot164, align 8
  %cmp872 = icmp ne i64 %v871, 0
  %cv873 = zext i1 %cmp872 to i32
  store i32 %cv873, ptr %slot165, align 8
  %v874 = load i32, ptr %slot165, align 8
  %cv875 = zext i32 %v874 to i64
  %cond876 = icmp ne i64 %cv875, 0
  br i1 %cond876, label %bb_rcgdec258, label %bb_rcgslow258
bb_rcgslow258:
  %v877 = load i64, ptr %slot152, align 8
  %v878 = load i64, ptr %slot135, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v877, i64 %v878) nomerge, !dbg !120
  br label %bb_rcgdone258
bb_rcgdec258:
  %v879 = load i64, ptr %slot161, align 8
  %v880 = load i64, ptr %slot153, align 8
  %p881 = inttoptr i64 %v880 to ptr
  %rgep882 = getelementptr i8, ptr %p881, i64 -32
  store i64 %v879, ptr %rgep882, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear258
bb_rcgclear258:
  %v883 = load i64, ptr %slot135, align 8
  %p884 = inttoptr i64 %v883 to ptr
  store i64 0, ptr %p884, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone258
bb_rcgdone258:
  br label %bb_rcslotdone227
bb_rcslotdone227:
  %v885 = load i64, ptr %slot21, align 8
  %p886 = inttoptr i64 %v885 to ptr
  store i64 0, ptr %p886, align 8, !alias.scope !3, !noalias !4
  %v887 = load i64, ptr %slot21, align 8
  %p888 = inttoptr i64 %v887 to ptr
  %ld889 = load i64, ptr %p888, align 8, !alias.scope !3, !noalias !4
  store i64 %ld889, ptr %slot166, align 8
  %v890 = load i64, ptr %slot6, align 8
  %p891 = inttoptr i64 %v890 to ptr
  %ld892 = load i32, ptr %p891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld892, ptr %slot167, align 8
  %v893 = load i32, ptr %slot167, align 8
  %cv894 = zext i32 %v893 to i64
  %cond895 = icmp ne i64 %cv894, 0
  br i1 %cond895, label %bb_rcslotdrop268, label %bb_rcslotdone268
bb_rcslotdrop268:
  %v896 = load i64, ptr %slot6, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i32 0, ptr %p897, align 4, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot19, align 8
  store i64 %v898, ptr %slot168, align 8
  %v899 = load i64, ptr %slot7, align 8
  %p900 = inttoptr i64 %v899 to ptr
  %ld901 = load i32, ptr %p900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld901, ptr %slot169, align 8
  %v902 = load i32, ptr %slot169, align 8
  %op903 = and i32 %v902, 28
  store i32 %op903, ptr %slot170, align 8
  %v904 = load i32, ptr %slot170, align 8
  %cv905 = zext i32 %v904 to i64
  %cond906 = icmp ne i64 %cv905, 0
  br i1 %cond906, label %bb_rcslotrole268, label %bb_rcslotowner268
bb_rcslotrole268:
  %v907 = load i64, ptr %slot33, align 8
  store i64 %v907, ptr %slot171, align 8
  %v908 = load i64, ptr %slot171, align 8
  %v909 = load i64, ptr %slot168, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v908, i64 %v909) nomerge, !dbg !122
  br label %bb_rcslotdone268
bb_rcslotowner268:
  %v910 = load i64, ptr %slot33, align 8
  store i64 %v910, ptr %slot172, align 8
  %v911 = load i64, ptr %slot172, align 8
  %v912 = load i64, ptr %slot168, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v911, i64 %v912) nomerge, !dbg !122
  br label %bb_rcslotdone268
bb_rcslotdone268:
  %v913 = load i64, ptr %slot4, align 8
  %p914 = inttoptr i64 %v913 to ptr
  %ld915 = load i32, ptr %p914, align 4, !alias.scope !3, !noalias !4
  store i32 %ld915, ptr %slot173, align 8
  %v916 = load i32, ptr %slot173, align 8
  %cv917 = zext i32 %v916 to i64
  %cond918 = icmp ne i64 %cv917, 0
  br i1 %cond918, label %bb_rcslotdrop277, label %bb_rcslotdone277
bb_rcslotdrop277:
  %v919 = load i64, ptr %slot4, align 8
  %p920 = inttoptr i64 %v919 to ptr
  store i32 0, ptr %p920, align 4, !alias.scope !3, !noalias !4
  %v921 = load i64, ptr %slot17, align 8
  store i64 %v921, ptr %slot174, align 8
  %v922 = load i64, ptr %slot5, align 8
  %p923 = inttoptr i64 %v922 to ptr
  %ld924 = load i32, ptr %p923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld924, ptr %slot175, align 8
  %v925 = load i32, ptr %slot175, align 8
  %op926 = and i32 %v925, 28
  store i32 %op926, ptr %slot176, align 8
  %v927 = load i32, ptr %slot176, align 8
  %cv928 = zext i32 %v927 to i64
  %cond929 = icmp ne i64 %cv928, 0
  br i1 %cond929, label %bb_rcslotrole277, label %bb_rcslotowner277
bb_rcslotrole277:
  %v930 = load i64, ptr %slot33, align 8
  store i64 %v930, ptr %slot177, align 8
  %v931 = load i64, ptr %slot177, align 8
  %v932 = load i64, ptr %slot174, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v931, i64 %v932) nomerge, !dbg !122
  br label %bb_rcslotdone277
bb_rcslotowner277:
  %v933 = load i64, ptr %slot33, align 8
  store i64 %v933, ptr %slot178, align 8
  %v934 = load i64, ptr %slot178, align 8
  %v935 = load i64, ptr %slot174, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v934, i64 %v935) nomerge, !dbg !122
  br label %bb_rcslotdone277
bb_rcslotdone277:
  %v936 = load i64, ptr %slot166, align 8
  ret i64 %v936
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_146d534849d3e93fd30ab0fa32197316072c792978757f394cddd3246cba50a7 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64, i64, i64, i64)
declare i64 @myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64, i64, i64, i32)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9e17d65d841827246848c5d0ddb85bf1c21e01b97a04e1691964273775333481", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9e17d65d841827246848c5d0ddb85bf1c21e01b97a04e1691964273775333481", linkageName: "myl_f_9e17d65d841827246848c5d0ddb85bf1c21e01b97a04e1691964273775333481", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14251201153004728683, i64 0, !"myl_f_9e17d65d841827246848c5d0ddb85bf1c21e01b97a04e1691964273775333481"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!116 = !DILocation(line: 16, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!118 = !DILocation(line: 28, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!120 = !DILocation(line: 34, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!122 = !DILocation(line: 37, column: 0, scope: !123)
