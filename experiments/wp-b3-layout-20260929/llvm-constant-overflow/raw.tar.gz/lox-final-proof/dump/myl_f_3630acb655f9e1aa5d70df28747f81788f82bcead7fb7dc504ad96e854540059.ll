target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3630acb655f9e1aa5d70df28747f81788f82bcead7fb7dc504ad96e854540059(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %callresult180 = alloca [32 x i8], align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i32, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i32, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i32, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i32, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %callresult890 = alloca [88 x i8], align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i32, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i32, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i32, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i32, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i32, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i32, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i32, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i32, align 8
  %slot1119 = alloca i32, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i32, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i32, align 8
  %slot1125 = alloca i32, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i32, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i32, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i32, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i32, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i32, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i32, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i32, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i32, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i32, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i32, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v1198 = load i64, ptr %slot1, align 8
  %op1199 = add i64 %v1198, 32
  store i64 %op1199, ptr %slot5, align 8
  %mem1200 = alloca i8, i64 8, align 8
  %ptr1201 = ptrtoint ptr %mem1200 to i64
  store i64 %ptr1201, ptr %slot6, align 8
  %mem1202 = alloca i8, i64 8, align 8
  %ptr1203 = ptrtoint ptr %mem1202 to i64
  store i64 %ptr1203, ptr %slot7, align 8
  %mem1204 = alloca i8, i64 8, align 8
  %ptr1205 = ptrtoint ptr %mem1204 to i64
  store i64 %ptr1205, ptr %slot8, align 8
  %mem1206 = alloca i8, i64 8, align 8
  %ptr1207 = ptrtoint ptr %mem1206 to i64
  store i64 %ptr1207, ptr %slot9, align 8
  %mem1208 = alloca i8, i64 8, align 8
  %ptr1209 = ptrtoint ptr %mem1208 to i64
  store i64 %ptr1209, ptr %slot10, align 8
  %mem1210 = alloca i8, i64 8, align 8
  %ptr1211 = ptrtoint ptr %mem1210 to i64
  store i64 %ptr1211, ptr %slot11, align 8
  %mem1212 = alloca i8, i64 8, align 8
  %ptr1213 = ptrtoint ptr %mem1212 to i64
  store i64 %ptr1213, ptr %slot12, align 8
  %mem1214 = alloca i8, i64 8, align 8
  %ptr1215 = ptrtoint ptr %mem1214 to i64
  store i64 %ptr1215, ptr %slot13, align 8
  %mem1216 = alloca i8, i64 8, align 8
  %ptr1217 = ptrtoint ptr %mem1216 to i64
  store i64 %ptr1217, ptr %slot14, align 8
  %mem1218 = alloca i8, i64 8, align 8
  %ptr1219 = ptrtoint ptr %mem1218 to i64
  store i64 %ptr1219, ptr %slot15, align 8
  %mem1220 = alloca i8, i64 8, align 8
  %ptr1221 = ptrtoint ptr %mem1220 to i64
  store i64 %ptr1221, ptr %slot16, align 8
  %mem1222 = alloca i8, i64 8, align 8
  %ptr1223 = ptrtoint ptr %mem1222 to i64
  store i64 %ptr1223, ptr %slot17, align 8
  %mem1224 = alloca i8, i64 8, align 8
  %ptr1225 = ptrtoint ptr %mem1224 to i64
  store i64 %ptr1225, ptr %slot18, align 8
  %mem1226 = alloca i8, i64 8, align 8
  %ptr1227 = ptrtoint ptr %mem1226 to i64
  store i64 %ptr1227, ptr %slot19, align 8
  %mem1228 = alloca i8, i64 8, align 8
  %ptr1229 = ptrtoint ptr %mem1228 to i64
  store i64 %ptr1229, ptr %slot20, align 8
  %mem1230 = alloca i8, i64 8, align 8
  %ptr1231 = ptrtoint ptr %mem1230 to i64
  store i64 %ptr1231, ptr %slot21, align 8
  %mem1232 = alloca i8, i64 8, align 8
  %ptr1233 = ptrtoint ptr %mem1232 to i64
  store i64 %ptr1233, ptr %slot22, align 8
  %mem1234 = alloca i8, i64 8, align 8
  %ptr1235 = ptrtoint ptr %mem1234 to i64
  store i64 %ptr1235, ptr %slot23, align 8
  %mem1236 = alloca i8, i64 8, align 8
  %ptr1237 = ptrtoint ptr %mem1236 to i64
  store i64 %ptr1237, ptr %slot24, align 8
  %mem1238 = alloca i8, i64 8, align 8
  %ptr1239 = ptrtoint ptr %mem1238 to i64
  store i64 %ptr1239, ptr %slot25, align 8
  %mem1240 = alloca i8, i64 8, align 8
  %ptr1241 = ptrtoint ptr %mem1240 to i64
  store i64 %ptr1241, ptr %slot26, align 8
  %mem1242 = alloca i8, i64 8, align 8
  %ptr1243 = ptrtoint ptr %mem1242 to i64
  store i64 %ptr1243, ptr %slot27, align 8
  %mem1244 = alloca i8, i64 8, align 8
  %ptr1245 = ptrtoint ptr %mem1244 to i64
  store i64 %ptr1245, ptr %slot28, align 8
  %mem1246 = alloca i8, i64 8, align 8
  %ptr1247 = ptrtoint ptr %mem1246 to i64
  store i64 %ptr1247, ptr %slot29, align 8
  %mem1248 = alloca i8, i64 8, align 8
  %ptr1249 = ptrtoint ptr %mem1248 to i64
  store i64 %ptr1249, ptr %slot30, align 8
  %mem1250 = alloca i8, i64 8, align 8
  %ptr1251 = ptrtoint ptr %mem1250 to i64
  store i64 %ptr1251, ptr %slot31, align 8
  %mem1252 = alloca i8, i64 392, align 8
  %ptr1253 = ptrtoint ptr %mem1252 to i64
  store i64 %ptr1253, ptr %slot32, align 8
  %mem1254 = alloca i8, i64 40, align 8
  %ptr1255 = ptrtoint ptr %mem1254 to i64
  store i64 %ptr1255, ptr %slot33, align 8
  %mem1256 = alloca i8, i64 40, align 8
  %ptr1257 = ptrtoint ptr %mem1256 to i64
  store i64 %ptr1257, ptr %slot34, align 8
  %mem1258 = alloca i8, i64 8, align 8
  %ptr1259 = ptrtoint ptr %mem1258 to i64
  store i64 %ptr1259, ptr %slot35, align 8
  %mem1260 = alloca i8, i64 8, align 8
  %ptr1261 = ptrtoint ptr %mem1260 to i64
  store i64 %ptr1261, ptr %slot36, align 8
  %mem1262 = alloca i8, i64 8, align 8
  %ptr1263 = ptrtoint ptr %mem1262 to i64
  store i64 %ptr1263, ptr %slot37, align 8
  %mem1264 = alloca i8, i64 8, align 8
  %ptr1265 = ptrtoint ptr %mem1264 to i64
  store i64 %ptr1265, ptr %slot38, align 8
  %mem1266 = alloca i8, i64 8, align 8
  %ptr1267 = ptrtoint ptr %mem1266 to i64
  store i64 %ptr1267, ptr %slot39, align 8
  %mem1268 = alloca i8, i64 8, align 8
  %ptr1269 = ptrtoint ptr %mem1268 to i64
  store i64 %ptr1269, ptr %slot40, align 8
  %mem1270 = alloca i8, i64 392, align 8
  %ptr1271 = ptrtoint ptr %mem1270 to i64
  store i64 %ptr1271, ptr %slot41, align 8
  %mem1272 = alloca i8, i64 8, align 8
  %ptr1273 = ptrtoint ptr %mem1272 to i64
  store i64 %ptr1273, ptr %slot42, align 8
  %mem1274 = alloca i8, i64 8, align 8
  %ptr1275 = ptrtoint ptr %mem1274 to i64
  store i64 %ptr1275, ptr %slot43, align 8
  %mem1276 = alloca i8, i64 8, align 8
  %ptr1277 = ptrtoint ptr %mem1276 to i64
  store i64 %ptr1277, ptr %slot44, align 8
  %mem1278 = alloca i8, i64 40, align 8
  %ptr1279 = ptrtoint ptr %mem1278 to i64
  store i64 %ptr1279, ptr %slot45, align 8
  %mem1280 = alloca i8, i64 8, align 8
  %ptr1281 = ptrtoint ptr %mem1280 to i64
  store i64 %ptr1281, ptr %slot46, align 8
  %mem1282 = alloca i8, i64 8, align 8
  %ptr1283 = ptrtoint ptr %mem1282 to i64
  store i64 %ptr1283, ptr %slot47, align 8
  %mem1284 = alloca i8, i64 392, align 8
  %ptr1285 = ptrtoint ptr %mem1284 to i64
  store i64 %ptr1285, ptr %slot48, align 8
  %mem1286 = alloca i8, i64 88, align 8
  %ptr1287 = ptrtoint ptr %mem1286 to i64
  store i64 %ptr1287, ptr %slot49, align 8
  %mem1288 = alloca i8, i64 8, align 8
  %ptr1289 = ptrtoint ptr %mem1288 to i64
  store i64 %ptr1289, ptr %slot50, align 8
  %mem1290 = alloca i8, i64 8, align 8
  %ptr1291 = ptrtoint ptr %mem1290 to i64
  store i64 %ptr1291, ptr %slot51, align 8
  %mem1292 = alloca i8, i64 8, align 8
  %ptr1293 = ptrtoint ptr %mem1292 to i64
  store i64 %ptr1293, ptr %slot52, align 8
  %mem1294 = alloca i8, i64 8, align 8
  %ptr1295 = ptrtoint ptr %mem1294 to i64
  store i64 %ptr1295, ptr %slot53, align 8
  %mem1296 = alloca i8, i64 8, align 8
  %ptr1297 = ptrtoint ptr %mem1296 to i64
  store i64 %ptr1297, ptr %slot54, align 8
  %mem1298 = alloca i8, i64 8, align 8
  %ptr1299 = ptrtoint ptr %mem1298 to i64
  store i64 %ptr1299, ptr %slot55, align 8
  %mem1300 = alloca i8, i64 8, align 8
  %ptr1301 = ptrtoint ptr %mem1300 to i64
  store i64 %ptr1301, ptr %slot56, align 8
  %mem1302 = alloca i8, i64 8, align 8
  %ptr1303 = ptrtoint ptr %mem1302 to i64
  store i64 %ptr1303, ptr %slot57, align 8
  %mem1304 = alloca i8, i64 8, align 8
  %ptr1305 = ptrtoint ptr %mem1304 to i64
  store i64 %ptr1305, ptr %slot58, align 8
  %mem1306 = alloca i8, i64 8, align 8
  %ptr1307 = ptrtoint ptr %mem1306 to i64
  store i64 %ptr1307, ptr %slot59, align 8
  %mem1308 = alloca i8, i64 8, align 8
  %ptr1309 = ptrtoint ptr %mem1308 to i64
  store i64 %ptr1309, ptr %slot60, align 8
  %mem1310 = alloca i8, i64 40, align 8
  %ptr1311 = ptrtoint ptr %mem1310 to i64
  store i64 %ptr1311, ptr %slot61, align 8
  %mem1312 = alloca i8, i64 392, align 8
  %ptr1313 = ptrtoint ptr %mem1312 to i64
  store i64 %ptr1313, ptr %slot62, align 8
  %mem1314 = alloca i8, i64 392, align 8
  %ptr1315 = ptrtoint ptr %mem1314 to i64
  store i64 %ptr1315, ptr %slot63, align 8
  %mem1316 = alloca i8, i64 392, align 8
  %ptr1317 = ptrtoint ptr %mem1316 to i64
  store i64 %ptr1317, ptr %slot64, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1318 = alloca i8, i64 8, align 8
  %ptr1319 = ptrtoint ptr %mem1318 to i64
  store i64 %ptr1319, ptr %slot65, align 8
  %v1320 = load i64, ptr %slot1, align 8
  %op1321 = add i64 %v1320, 64
  store i64 %op1321, ptr %slot66, align 8
  %v1322 = load i64, ptr %slot66, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  %ld1324 = load i64, ptr %p1323, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1324, ptr %slot67, align 8
  %stack1325 = call ptr @llvm.stacksave()
  %stackaddr1326 = ptrtoint ptr %stack1325 to i64
  %v1327 = load i64, ptr %slot67, align 8
  %cmp1328 = icmp ult i64 %stackaddr1326, %v1327
  %cv1329 = zext i1 %cmp1328 to i64
  store i64 %cv1329, ptr %slot68, align 8
  %v1330 = load i64, ptr %slot68, align 8
  %cond1331 = icmp ne i64 %v1330, 0
  br i1 %cond1331, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1332 = load i64, ptr %slot1, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  call void @myl_qbe_fail_frame(ptr %p1333) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1334 = load i64, ptr %slot46, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i64 0, ptr %p1335, align 8, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot47, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i64 0, ptr %p1337, align 8, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot2, align 8
  %v1339 = load i64, ptr %slot42, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  store i64 %v1338, ptr %p1340, align 8, !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot3, align 8
  %v1342 = load i64, ptr %slot43, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  store i64 %v1341, ptr %p1343, align 8, !alias.scope !3, !noalias !4
  %v1344 = load i64, ptr %slot4, align 8
  %v1345 = load i64, ptr %slot44, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  store i64 %v1344, ptr %p1346, align 8, !alias.scope !3, !noalias !4
  %v1347 = load i64, ptr %slot1, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  %call1349 = call ptr @myl_qbe_heap(ptr %p1348) nomerge, !dbg !112
  %calladdr1350 = ptrtoint ptr %call1349 to i64
  store i64 %calladdr1350, ptr %slot69, align 8
  %v1351 = load i64, ptr %slot1, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  %call1353 = call i64 @myl_qbe_region_mark(ptr %p1352) nomerge, !dbg !112
  store i64 %call1353, ptr %slot70, align 8
  %v1354 = load i64, ptr %slot6, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  store i32 0, ptr %p1355, align 4, !alias.scope !3, !noalias !4
  %v1356 = load i64, ptr %slot7, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  store i32 0, ptr %p1357, align 4, !alias.scope !3, !noalias !4
  %v1358 = load i64, ptr %slot8, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  store i32 0, ptr %p1359, align 4, !alias.scope !3, !noalias !4
  %v1360 = load i64, ptr %slot9, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  store i32 0, ptr %p1361, align 4, !alias.scope !3, !noalias !4
  %v1362 = load i64, ptr %slot10, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  store i32 0, ptr %p1363, align 4, !alias.scope !3, !noalias !4
  %v1364 = load i64, ptr %slot11, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  store i32 0, ptr %p1365, align 4, !alias.scope !3, !noalias !4
  %v1366 = load i64, ptr %slot12, align 8
  %p1367 = inttoptr i64 %v1366 to ptr
  store i32 0, ptr %p1367, align 4, !alias.scope !3, !noalias !4
  %v1368 = load i64, ptr %slot13, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  store i32 0, ptr %p1369, align 4, !alias.scope !3, !noalias !4
  %v1370 = load i64, ptr %slot14, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  store i32 0, ptr %p1371, align 4, !alias.scope !3, !noalias !4
  %v1372 = load i64, ptr %slot15, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  store i32 0, ptr %p1373, align 4, !alias.scope !3, !noalias !4
  %v1374 = load i64, ptr %slot16, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  store i32 0, ptr %p1375, align 4, !alias.scope !3, !noalias !4
  %v1376 = load i64, ptr %slot17, align 8
  %p1377 = inttoptr i64 %v1376 to ptr
  store i32 0, ptr %p1377, align 4, !alias.scope !3, !noalias !4
  %v1378 = load i64, ptr %slot18, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i32 0, ptr %p1379, align 4, !alias.scope !3, !noalias !4
  %v1380 = load i64, ptr %slot19, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  store i32 0, ptr %p1381, align 4, !alias.scope !3, !noalias !4
  %v1382 = load i64, ptr %slot20, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  store i32 0, ptr %p1383, align 4, !alias.scope !3, !noalias !4
  %v1384 = load i64, ptr %slot21, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  store i32 0, ptr %p1385, align 4, !alias.scope !3, !noalias !4
  %v1386 = load i64, ptr %slot22, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  store i32 0, ptr %p1387, align 4, !alias.scope !3, !noalias !4
  %v1388 = load i64, ptr %slot23, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  store i32 0, ptr %p1389, align 4, !alias.scope !3, !noalias !4
  %v1390 = load i64, ptr %slot24, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  store i32 0, ptr %p1391, align 4, !alias.scope !3, !noalias !4
  %v1392 = load i64, ptr %slot25, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i32 0, ptr %p1393, align 4, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot26, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  store i32 0, ptr %p1395, align 4, !alias.scope !3, !noalias !4
  %v1396 = load i64, ptr %slot27, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  store i32 0, ptr %p1397, align 4, !alias.scope !3, !noalias !4
  %v1398 = load i64, ptr %slot28, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  store i32 0, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  %v1400 = load i64, ptr %slot29, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 0, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot30, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  store i32 0, ptr %p1403, align 4, !alias.scope !3, !noalias !4
  %v1404 = load i64, ptr %slot31, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  store i32 0, ptr %p1405, align 4, !alias.scope !3, !noalias !4
  %v1406 = load i64, ptr %slot7, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i32 2, ptr %p1407, align 4, !alias.scope !3, !noalias !4
  %v1408 = load i64, ptr %slot9, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  store i32 2, ptr %p1409, align 4, !alias.scope !3, !noalias !4
  %v1410 = load i64, ptr %slot11, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  store i32 2, ptr %p1411, align 4, !alias.scope !3, !noalias !4
  %v1412 = load i64, ptr %slot13, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  store i32 2, ptr %p1413, align 4, !alias.scope !3, !noalias !4
  %v1414 = load i64, ptr %slot15, align 8
  %p1415 = inttoptr i64 %v1414 to ptr
  store i32 2, ptr %p1415, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1416 = load i64, ptr %slot60, align 8
  store i64 %v1416, ptr %slot71, align 8
  %v1417 = load i64, ptr %slot71, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  store i32 0, ptr %p1418, align 4, !alias.scope !3, !noalias !4
  %v1419 = load i64, ptr %slot71, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  store i32 39, ptr %p1420, align 4, !alias.scope !3, !noalias !4
  %v1421 = load i64, ptr %slot71, align 8
  %v1422 = load i64, ptr %slot50, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i64 %v1421, ptr %p1423, align 8, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot51, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i64 0, ptr %p1425, align 8, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot52, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  store i64 0, ptr %p1427, align 8, !alias.scope !3, !noalias !4
  %v1428 = load i64, ptr %slot53, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  store i64 1, ptr %p1429, align 8, !alias.scope !3, !noalias !4
  %p1430 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1431, ptr %slot72, align 8
  %v1432 = load i64, ptr %slot72, align 8
  %v1433 = load i64, ptr %slot54, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  store i64 %v1432, ptr %p1434, align 8, !alias.scope !3, !noalias !4
  %v1435 = load i64, ptr %slot54, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  %ld1437 = load i64, ptr %p1436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1437, ptr %slot73, align 8
  %v1438 = load i64, ptr %slot73, align 8
  %v1439 = load i64, ptr %slot38, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  store i64 %v1438, ptr %p1440, align 8, !alias.scope !3, !noalias !4
  %v1441 = load i64, ptr %slot38, align 8
  store i64 %v1441, ptr %slot74, align 8
  %v1442 = load i64, ptr %slot41, align 8
  store i64 %v1442, ptr %slot75, align 8
  %v1443 = load i64, ptr %slot74, align 8
  %v1444 = load i64, ptr %slot75, align 8
  %p1445 = inttoptr i64 %v1443 to ptr
  %p1446 = inttoptr i64 %v1444 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1446, ptr %p1445, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1447 = load i64, ptr %slot30, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  store i32 2, ptr %p1448, align 4, !alias.scope !3, !noalias !4
  %v1449 = load i64, ptr %slot29, align 8
  %p1450 = inttoptr i64 %v1449 to ptr
  store i32 1, ptr %p1450, align 4, !alias.scope !3, !noalias !4
  %v1451 = load i64, ptr %slot34, align 8
  store i64 %v1451, ptr %slot76, align 8
  %v1452 = load i64, ptr %slot41, align 8
  store i64 %v1452, ptr %slot77, align 8
  %v1453 = load i64, ptr %slot77, align 8
  %v1454 = load i64, ptr %slot76, align 8
  %p1455 = inttoptr i64 %v1453 to ptr
  %p1456 = inttoptr i64 %v1454 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1456, ptr %p1455, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1457 = load i64, ptr %slot23, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  store i32 2, ptr %p1458, align 4, !alias.scope !3, !noalias !4
  %v1459 = load i64, ptr %slot30, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %ld1461 = load i32, ptr %p1460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1461, ptr %slot78, align 8
  %v1462 = load i32, ptr %slot78, align 8
  %v1463 = load i64, ptr %slot23, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  store i32 %v1462, ptr %p1464, align 4, !alias.scope !3, !noalias !4
  %v1465 = load i64, ptr %slot29, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i32 0, ptr %p1466, align 4, !alias.scope !3, !noalias !4
  %v1467 = load i64, ptr %slot22, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  store i32 1, ptr %p1468, align 4, !alias.scope !3, !noalias !4
  %v1469 = load i64, ptr %slot76, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i64, ptr %p1470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1471, ptr %slot79, align 8
  %v1472 = load i64, ptr %slot79, align 8
  %v1473 = load i64, ptr %slot54, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i64 %v1472, ptr %p1474, align 8, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot61, align 8
  store i64 %v1475, ptr %slot80, align 8
  %v1476 = load i64, ptr %slot80, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  store i64 0, ptr %p1477, align 8, !alias.scope !3, !noalias !4
  %v1478 = load i64, ptr %slot80, align 8
  %p1480 = inttoptr i64 %v1478 to ptr
  %gep1481 = getelementptr i8, ptr %p1480, i64 8
  %op1479 = ptrtoint ptr %gep1481 to i64
  store i64 %op1479, ptr %slot81, align 8
  %v1482 = load i64, ptr %slot81, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  store i64 0, ptr %p1483, align 8, !alias.scope !3, !noalias !4
  %v1484 = load i64, ptr %slot80, align 8
  %p1486 = inttoptr i64 %v1484 to ptr
  %gep1487 = getelementptr i8, ptr %p1486, i64 16
  %op1485 = ptrtoint ptr %gep1487 to i64
  store i64 %op1485, ptr %slot82, align 8
  %v1488 = load i64, ptr %slot82, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  store i64 0, ptr %p1489, align 8, !alias.scope !3, !noalias !4
  %v1490 = load i64, ptr %slot80, align 8
  %p1492 = inttoptr i64 %v1490 to ptr
  %gep1493 = getelementptr i8, ptr %p1492, i64 24
  %op1491 = ptrtoint ptr %gep1493 to i64
  store i64 %op1491, ptr %slot83, align 8
  %v1494 = load i64, ptr %slot83, align 8
  %p1495 = inttoptr i64 %v1494 to ptr
  store i64 0, ptr %p1495, align 8, !alias.scope !3, !noalias !4
  %v1496 = load i64, ptr %slot80, align 8
  %p1498 = inttoptr i64 %v1496 to ptr
  %gep1499 = getelementptr i8, ptr %p1498, i64 32
  %op1497 = ptrtoint ptr %gep1499 to i64
  store i64 %op1497, ptr %slot84, align 8
  %v1500 = load i64, ptr %slot84, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  store i64 0, ptr %p1501, align 8, !alias.scope !3, !noalias !4
  %v1502 = load i64, ptr %slot31, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  store i32 1, ptr %p1503, align 4, !alias.scope !3, !noalias !4
  %v1504 = load i64, ptr %slot70, align 8
  store i64 %v1504, ptr %slot85, align 8
  %v1505 = load i64, ptr %slot50, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %ld1507 = load i64, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1507, ptr %slot86, align 8
  %v1508 = load i64, ptr %slot80, align 8
  %p1510 = inttoptr i64 %v1508 to ptr
  %gep1511 = getelementptr i8, ptr %p1510, i64 0
  %op1509 = ptrtoint ptr %gep1511 to i64
  store i64 %op1509, ptr %slot87, align 8
  %v1512 = load i64, ptr %slot86, align 8
  %v1513 = load i64, ptr %slot87, align 8
  %p1514 = inttoptr i64 %v1512 to ptr
  %p1515 = inttoptr i64 %v1513 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1515, ptr %p1514, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v1516 = load i64, ptr %slot51, align 8
  store i64 %v1516, ptr %slot88, align 8
  %v1517 = load i64, ptr %slot80, align 8
  %p1519 = inttoptr i64 %v1517 to ptr
  %gep1520 = getelementptr i8, ptr %p1519, i64 8
  %op1518 = ptrtoint ptr %gep1520 to i64
  store i64 %op1518, ptr %slot89, align 8
  %v1521 = load i64, ptr %slot88, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  %ld1523 = load i64, ptr %p1522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1523, ptr %slot90, align 8
  %v1524 = load i64, ptr %slot90, align 8
  %v1525 = load i64, ptr %slot89, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  store i64 %v1524, ptr %p1526, align 8, !alias.scope !3, !noalias !4
  %v1527 = load i64, ptr %slot52, align 8
  store i64 %v1527, ptr %slot91, align 8
  %v1528 = load i64, ptr %slot80, align 8
  %p1530 = inttoptr i64 %v1528 to ptr
  %gep1531 = getelementptr i8, ptr %p1530, i64 16
  %op1529 = ptrtoint ptr %gep1531 to i64
  store i64 %op1529, ptr %slot92, align 8
  %v1532 = load i64, ptr %slot91, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  %ld1534 = load i64, ptr %p1533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1534, ptr %slot93, align 8
  %v1535 = load i64, ptr %slot93, align 8
  %v1536 = load i64, ptr %slot92, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  store i64 %v1535, ptr %p1537, align 8, !alias.scope !3, !noalias !4
  %v1538 = load i64, ptr %slot53, align 8
  store i64 %v1538, ptr %slot94, align 8
  %v1539 = load i64, ptr %slot80, align 8
  %p1541 = inttoptr i64 %v1539 to ptr
  %gep1542 = getelementptr i8, ptr %p1541, i64 24
  %op1540 = ptrtoint ptr %gep1542 to i64
  store i64 %op1540, ptr %slot95, align 8
  %v1543 = load i64, ptr %slot94, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  %ld1545 = load i64, ptr %p1544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1545, ptr %slot96, align 8
  %v1546 = load i64, ptr %slot96, align 8
  %v1547 = load i64, ptr %slot95, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  store i64 %v1546, ptr %p1548, align 8, !alias.scope !3, !noalias !4
  %v1549 = load i64, ptr %slot54, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  %ld1551 = load i64, ptr %p1550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1551, ptr %slot97, align 8
  %v1552 = load i64, ptr %slot97, align 8
  %v1553 = load i64, ptr %slot38, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  store i64 %v1552, ptr %p1554, align 8, !alias.scope !3, !noalias !4
  %v1555 = load i64, ptr %slot38, align 8
  store i64 %v1555, ptr %slot98, align 8
  %v1556 = load i64, ptr %slot80, align 8
  %p1558 = inttoptr i64 %v1556 to ptr
  %gep1559 = getelementptr i8, ptr %p1558, i64 32
  %op1557 = ptrtoint ptr %gep1559 to i64
  store i64 %op1557, ptr %slot99, align 8
  %v1560 = load i64, ptr %slot54, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  %ld1562 = load i64, ptr %p1561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1562, ptr %slot100, align 8
  %v1563 = load i64, ptr %slot100, align 8
  %v1564 = load i64, ptr %slot38, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i64 %v1563, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  %v1566 = load i64, ptr %slot38, align 8
  store i64 %v1566, ptr %slot101, align 8
  %v1567 = load i64, ptr %slot41, align 8
  store i64 %v1567, ptr %slot102, align 8
  %v1568 = load i64, ptr %slot70, align 8
  store i64 %v1568, ptr %slot103, align 8
  %v1569 = load i64, ptr %slot101, align 8
  %p1571 = inttoptr i64 %v1569 to ptr
  %gep1572 = getelementptr i8, ptr %p1571, i64 0
  %op1570 = ptrtoint ptr %gep1572 to i64
  store i64 %op1570, ptr %slot104, align 8
  %v1573 = load i64, ptr %slot104, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  %ld1575 = load i64, ptr %p1574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1575, ptr %slot105, align 8
  %v1576 = load i64, ptr %slot105, align 8
  %cmp1577 = icmp ne i64 %v1576, 0
  %cv1578 = zext i1 %cmp1577 to i32
  store i32 %cv1578, ptr %slot106, align 8
  %v1579 = load i32, ptr %slot106, align 8
  %cv1580 = zext i32 %v1579 to i64
  %cond1581 = icmp ne i64 %cv1580, 0
  br i1 %cond1581, label %bb_rcmoveheader61, label %bb_rcmovenext61
bb_rcmoveheader61:
  %v1582 = load i64, ptr %slot105, align 8
  %op1583 = sub i64 %v1582, 16
  store i64 %op1583, ptr %slot107, align 8
  %v1584 = load i64, ptr %slot105, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %rgep1586 = getelementptr i8, ptr %p1585, i64 -16
  %ld1587 = load i64, ptr %rgep1586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1587, ptr %slot108, align 8
  %v1588 = load i64, ptr %slot108, align 8
  %op1589 = and i64 %v1588, 5764607523034234881
  store i64 %op1589, ptr %slot109, align 8
  %v1590 = load i64, ptr %slot109, align 8
  %cmp1591 = icmp ne i64 %v1590, 0
  %cv1592 = zext i1 %cmp1591 to i32
  store i32 %cv1592, ptr %slot110, align 8
  %v1593 = load i32, ptr %slot110, align 8
  %cv1594 = zext i32 %v1593 to i64
  %cond1595 = icmp ne i64 %cv1594, 0
  br i1 %cond1595, label %bb_rcmoveslow58, label %bb_rcmovenext61
bb_rcmovenext61:
  %v1596 = load i64, ptr %slot101, align 8
  %v1597 = load i64, ptr %slot102, align 8
  %p1598 = inttoptr i64 %v1596 to ptr
  %p1599 = inttoptr i64 %v1597 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1599, ptr %p1598, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot101, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  store i64 0, ptr %p1601, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved58
bb_rcmoveslow58:
  %v1602 = load i64, ptr %slot69, align 8
  %v1603 = load i64, ptr %slot102, align 8
  %v1604 = load i64, ptr %slot101, align 8
  %v1605 = load i64, ptr %slot103, align 8
  %cv1606 = trunc i64 %v1605 to i32
  %call1607 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v1602, i64 %v1603, i64 %v1604, i32 %cv1606) nomerge, !dbg !114
  store i32 %call1607, ptr %slot111, align 8
  %v1608 = load i32, ptr %slot111, align 8
  %cv1609 = zext i32 %v1608 to i64
  %cond1610 = icmp ne i64 %cv1609, 0
  br i1 %cond1610, label %bb_rcsuccess68, label %bb_rcfailure68
bb_rcfailure68:
  %v1611 = load i64, ptr %slot69, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %call1613 = call i32 @myl_rc_take_failure(ptr %p1612) nomerge, !dbg !114
  store i32 %call1613, ptr %slot112, align 8
  %v1614 = load i64, ptr %slot1, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  %v1616 = load i32, ptr %slot112, align 8
  %call1617 = call i32 @myl_qbe_rc_status(ptr %p1615, i32 %v1616) nomerge, !dbg !114
  store i32 %call1617, ptr %slot113, align 8
  br label %bb_failure
bb_rcsuccess68:
  br label %bb_rcmoved58
bb_rcmoved58:
  %v1618 = load i64, ptr %slot22, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i32 0, ptr %p1619, align 4, !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot30, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  store i32 2, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot29, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 1, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot41, align 8
  store i64 %v1624, ptr %slot114, align 8
  %v1625 = load i64, ptr %slot114, align 8
  %v1626 = load i64, ptr %slot99, align 8
  %p1627 = inttoptr i64 %v1625 to ptr
  %p1628 = inttoptr i64 %v1626 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1628, ptr %p1627, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1629 = load i64, ptr %slot29, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  store i32 0, ptr %p1630, align 4, !alias.scope !3, !noalias !4
  %v1631 = load i64, ptr %slot80, align 8
  %v1632 = load i64, ptr %slot50, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  store i64 %v1631, ptr %p1633, align 8, !alias.scope !3, !noalias !4
  %v1634 = load i64, ptr %slot50, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  %ld1636 = load i64, ptr %p1635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1636, ptr %slot115, align 8
  %v1637 = load i64, ptr %slot32, align 8
  store i64 %v1637, ptr %slot116, align 8
  %v1638 = load i64, ptr %slot115, align 8
  %v1639 = load i64, ptr %slot116, align 8
  %p1640 = inttoptr i64 %v1638 to ptr
  %p1641 = inttoptr i64 %v1639 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1641, ptr %p1640, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1642 = load i64, ptr %slot17, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  store i32 2, ptr %p1643, align 4, !alias.scope !3, !noalias !4
  %v1644 = load i64, ptr %slot16, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  store i32 1, ptr %p1645, align 4, !alias.scope !3, !noalias !4
  %v1646 = load i64, ptr %slot116, align 8
  %v1647 = load i64, ptr %slot50, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  store i64 %v1646, ptr %p1648, align 8, !alias.scope !3, !noalias !4
  %v1649 = load i64, ptr %slot50, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  %ld1651 = load i64, ptr %p1650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1651, ptr %slot117, align 8
  %v1652 = load i64, ptr %slot41, align 8
  store i64 %v1652, ptr %slot118, align 8
  %v1653 = load i64, ptr %slot70, align 8
  store i64 %v1653, ptr %slot119, align 8
  %v1654 = load i64, ptr %slot69, align 8
  %v1655 = load i64, ptr %slot118, align 8
  %v1656 = load i64, ptr %slot117, align 8
  %v1657 = load i64, ptr %slot119, align 8
  %cv1658 = trunc i64 %v1657 to i32
  %call1659 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v1654, i64 %v1655, i64 %v1656, i32 %cv1658) nomerge, !dbg !116
  store i32 %call1659, ptr %slot120, align 8
  %v1660 = load i32, ptr %slot120, align 8
  %cv1661 = zext i32 %v1660 to i64
  %cond1662 = icmp ne i64 %cv1661, 0
  br i1 %cond1662, label %bb_rcsuccess84, label %bb_rcfailure84
bb_rcfailure84:
  %v1663 = load i64, ptr %slot69, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  %call1665 = call i32 @myl_rc_take_failure(ptr %p1664) nomerge, !dbg !116
  store i32 %call1665, ptr %slot121, align 8
  %v1666 = load i64, ptr %slot1, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  %v1668 = load i32, ptr %slot121, align 8
  %call1669 = call i32 @myl_qbe_rc_status(ptr %p1667, i32 %v1668) nomerge, !dbg !116
  store i32 %call1669, ptr %slot122, align 8
  br label %bb_failure
bb_rcsuccess84:
  %v1670 = load i64, ptr %slot16, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  store i32 0, ptr %p1671, align 4, !alias.scope !3, !noalias !4
  %v1672 = load i64, ptr %slot30, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  store i32 2, ptr %p1673, align 4, !alias.scope !3, !noalias !4
  %v1674 = load i64, ptr %slot29, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i32 1, ptr %p1675, align 4, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot6, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  %ld1678 = load i32, ptr %p1677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1678, ptr %slot123, align 8
  %v1679 = load i32, ptr %slot123, align 8
  %cv1680 = zext i32 %v1679 to i64
  %cond1681 = icmp ne i64 %cv1680, 0
  br i1 %cond1681, label %bb_rcslotdrop93, label %bb_rcslotdone93
bb_rcslotdrop93:
  %v1682 = load i64, ptr %slot6, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  store i32 0, ptr %p1683, align 4, !alias.scope !3, !noalias !4
  %v1684 = load i64, ptr %slot45, align 8
  store i64 %v1684, ptr %slot124, align 8
  %v1685 = load i64, ptr %slot7, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %ld1687 = load i32, ptr %p1686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1687, ptr %slot125, align 8
  %v1688 = load i32, ptr %slot125, align 8
  %op1689 = and i32 %v1688, 28
  store i32 %op1689, ptr %slot126, align 8
  %v1690 = load i32, ptr %slot126, align 8
  %cv1691 = zext i32 %v1690 to i64
  %cond1692 = icmp ne i64 %cv1691, 0
  br i1 %cond1692, label %bb_rcslotrole93, label %bb_rcslotowner93
bb_rcslotrole93:
  %v1693 = load i64, ptr %slot69, align 8
  store i64 %v1693, ptr %slot127, align 8
  %v1694 = load i64, ptr %slot127, align 8
  %v1695 = load i64, ptr %slot124, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1694, i64 %v1695) nomerge, !dbg !116
  br label %bb_rcslotdone93
bb_rcslotowner93:
  %v1696 = load i64, ptr %slot69, align 8
  store i64 %v1696, ptr %slot128, align 8
  %v1697 = load i64, ptr %slot128, align 8
  %v1698 = load i64, ptr %slot124, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1697, i64 %v1698) nomerge, !dbg !116
  br label %bb_rcslotdone93
bb_rcslotdone93:
  %v1699 = load i64, ptr %slot45, align 8
  store i64 %v1699, ptr %slot129, align 8
  %v1700 = load i64, ptr %slot41, align 8
  store i64 %v1700, ptr %slot130, align 8
  %v1701 = load i64, ptr %slot130, align 8
  %v1702 = load i64, ptr %slot129, align 8
  %p1703 = inttoptr i64 %v1701 to ptr
  %p1704 = inttoptr i64 %v1702 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1704, ptr %p1703, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1705 = load i64, ptr %slot29, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  store i32 0, ptr %p1706, align 4, !alias.scope !3, !noalias !4
  %v1707 = load i64, ptr %slot7, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  store i32 2, ptr %p1708, align 4, !alias.scope !3, !noalias !4
  %v1709 = load i64, ptr %slot30, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %ld1711 = load i32, ptr %p1710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1711, ptr %slot131, align 8
  %v1712 = load i32, ptr %slot131, align 8
  %v1713 = load i64, ptr %slot7, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  store i32 %v1712, ptr %p1714, align 4, !alias.scope !3, !noalias !4
  %v1715 = load i64, ptr %slot6, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 1, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot42, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %ld1719 = load i64, ptr %p1718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1719, ptr %slot132, align 8
  %v1720 = load i64, ptr %slot132, align 8
  %v1721 = load i64, ptr %slot50, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  store i64 %v1720, ptr %p1722, align 8, !alias.scope !3, !noalias !4
  %v1723 = load i64, ptr %slot50, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  %ld1725 = load i64, ptr %p1724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1725, ptr %slot133, align 8
  %v1726 = load i64, ptr %slot16, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  %ld1728 = load i32, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1728, ptr %slot134, align 8
  %v1729 = load i64, ptr %slot17, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %ld1731 = load i32, ptr %p1730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1731, ptr %slot135, align 8
  %v1732 = load i32, ptr %slot135, align 8
  %op1733 = and i32 %v1732, 24
  store i32 %op1733, ptr %slot135, align 8
  %v1734 = load i32, ptr %slot135, align 8
  %cmp1735 = icmp eq i32 %v1734, 0
  %cv1736 = zext i1 %cmp1735 to i32
  store i32 %cv1736, ptr %slot136, align 8
  %v1737 = load i32, ptr %slot134, align 8
  %v1738 = load i32, ptr %slot136, align 8
  %op1739 = and i32 %v1737, %v1738
  store i32 %op1739, ptr %slot137, align 8
  %v1740 = load i64, ptr %slot70, align 8
  store i64 %v1740, ptr %slot138, align 8
  %v1741 = load i32, ptr %slot137, align 8
  %op1742 = mul i32 %v1741, 4
  store i32 %op1742, ptr %slot139, align 8
  %v1743 = load i32, ptr %slot139, align 8
  %op1744 = or i32 %v1743, 0
  store i32 %op1744, ptr %slot140, align 8
  %v1745 = load i64, ptr %slot41, align 8
  store i64 %v1745, ptr %slot141, align 8
  %v1746 = load i64, ptr %slot69, align 8
  %v1747 = load i64, ptr %slot141, align 8
  %v1748 = load i64, ptr %slot133, align 8
  %v1749 = load i64, ptr %slot138, align 8
  %cv1750 = trunc i64 %v1749 to i32
  %v1751 = load i32, ptr %slot140, align 8
  %call1752 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_publish(i64 %v1746, i64 %v1747, i64 %v1748, i32 %cv1750, i32 %v1751) nomerge, !dbg !118
  store i32 %call1752, ptr %slot142, align 8
  %v1753 = load i32, ptr %slot142, align 8
  %cv1754 = zext i32 %v1753 to i64
  %cond1755 = icmp ne i64 %cv1754, 0
  br i1 %cond1755, label %bb_rcsuccess122, label %bb_rcfailure122
bb_rcfailure122:
  %v1756 = load i64, ptr %slot69, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  %call1758 = call i32 @myl_rc_take_failure(ptr %p1757) nomerge, !dbg !118
  store i32 %call1758, ptr %slot143, align 8
  %v1759 = load i64, ptr %slot1, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  %v1761 = load i32, ptr %slot143, align 8
  %call1762 = call i32 @myl_qbe_rc_status(ptr %p1760, i32 %v1761) nomerge, !dbg !118
  store i32 %call1762, ptr %slot144, align 8
  br label %bb_failure
bb_rcsuccess122:
  %v1763 = load i32, ptr %slot137, align 8
  %cv1764 = zext i32 %v1763 to i64
  %cond1765 = icmp ne i64 %cv1764, 0
  br i1 %cond1765, label %bb_rchtaken125, label %bb_rchcopied125
bb_rchcopied125:
  %v1766 = load i64, ptr %slot16, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  %ld1768 = load i32, ptr %p1767, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1768, ptr %slot145, align 8
  %v1769 = load i32, ptr %slot145, align 8
  %cv1770 = zext i32 %v1769 to i64
  %cond1771 = icmp ne i64 %cv1770, 0
  br i1 %cond1771, label %bb_rcslotdrop128, label %bb_rcslotdone128
bb_rcslotdrop128:
  %v1772 = load i64, ptr %slot16, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  store i32 0, ptr %p1773, align 4, !alias.scope !3, !noalias !4
  %v1774 = load i64, ptr %slot32, align 8
  store i64 %v1774, ptr %slot146, align 8
  %v1775 = load i64, ptr %slot17, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  %ld1777 = load i32, ptr %p1776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1777, ptr %slot147, align 8
  %v1778 = load i32, ptr %slot147, align 8
  %op1779 = and i32 %v1778, 28
  store i32 %op1779, ptr %slot148, align 8
  %v1780 = load i32, ptr %slot148, align 8
  %cv1781 = zext i32 %v1780 to i64
  %cond1782 = icmp ne i64 %cv1781, 0
  br i1 %cond1782, label %bb_rcslotrole128, label %bb_rcslotowner128
bb_rcslotrole128:
  %v1783 = load i64, ptr %slot69, align 8
  store i64 %v1783, ptr %slot149, align 8
  %v1784 = load i64, ptr %slot149, align 8
  %v1785 = load i64, ptr %slot146, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1784, i64 %v1785) nomerge, !dbg !118
  br label %bb_rcslotdone128
bb_rcslotowner128:
  %v1786 = load i64, ptr %slot69, align 8
  store i64 %v1786, ptr %slot150, align 8
  %v1787 = load i64, ptr %slot150, align 8
  %v1788 = load i64, ptr %slot146, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1787, i64 %v1788) nomerge, !dbg !118
  br label %bb_rcslotdone128
bb_rcslotdone128:
  br label %bb_rchprepared125
bb_rchtaken125:
  %v1789 = load i64, ptr %slot16, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  store i32 0, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared125
bb_rchprepared125:
  %v1791 = load i64, ptr %slot30, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  store i32 2, ptr %p1792, align 4, !alias.scope !3, !noalias !4
  %v1793 = load i64, ptr %slot29, align 8
  %p1794 = inttoptr i64 %v1793 to ptr
  store i32 1, ptr %p1794, align 4, !alias.scope !3, !noalias !4
  %v1795 = load i64, ptr %slot32, align 8
  store i64 %v1795, ptr %slot151, align 8
  %v1796 = load i64, ptr %slot41, align 8
  store i64 %v1796, ptr %slot152, align 8
  %v1797 = load i64, ptr %slot152, align 8
  %v1798 = load i64, ptr %slot151, align 8
  %p1799 = inttoptr i64 %v1797 to ptr
  %p1800 = inttoptr i64 %v1798 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1800, ptr %p1799, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v1801 = load i64, ptr %slot17, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  store i32 2, ptr %p1802, align 4, !alias.scope !3, !noalias !4
  %v1803 = load i64, ptr %slot30, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %ld1805 = load i32, ptr %p1804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1805, ptr %slot153, align 8
  %v1806 = load i32, ptr %slot153, align 8
  %v1807 = load i64, ptr %slot17, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i32 %v1806, ptr %p1808, align 4, !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot29, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  store i32 0, ptr %p1810, align 4, !alias.scope !3, !noalias !4
  %v1811 = load i64, ptr %slot16, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  store i32 1, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  %v1813 = load i64, ptr %slot151, align 8
  %v1814 = load i64, ptr %slot50, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  store i64 %v1813, ptr %p1815, align 8, !alias.scope !3, !noalias !4
  %v1816 = load i64, ptr %slot43, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  %ld1818 = load i64, ptr %p1817, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1818, ptr %slot154, align 8
  %v1819 = load i64, ptr %slot154, align 8
  %v1820 = load i64, ptr %slot51, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i64 %v1819, ptr %p1821, align 8, !alias.scope !3, !noalias !4
  %v1822 = load i64, ptr %slot51, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  %ld1824 = load i64, ptr %p1823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1824, ptr %slot155, align 8
  %v1825 = load i64, ptr %slot18, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %ld1827 = load i32, ptr %p1826, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1827, ptr %slot156, align 8
  %v1828 = load i64, ptr %slot19, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  %ld1830 = load i32, ptr %p1829, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1830, ptr %slot157, align 8
  %v1831 = load i32, ptr %slot157, align 8
  %op1832 = and i32 %v1831, 24
  store i32 %op1832, ptr %slot157, align 8
  %v1833 = load i32, ptr %slot157, align 8
  %cmp1834 = icmp eq i32 %v1833, 0
  %cv1835 = zext i1 %cmp1834 to i32
  store i32 %cv1835, ptr %slot158, align 8
  %v1836 = load i32, ptr %slot156, align 8
  %v1837 = load i32, ptr %slot158, align 8
  %op1838 = and i32 %v1836, %v1837
  store i32 %op1838, ptr %slot159, align 8
  %v1839 = load i64, ptr %slot70, align 8
  store i64 %v1839, ptr %slot160, align 8
  %v1840 = load i32, ptr %slot159, align 8
  %op1841 = mul i32 %v1840, 4
  store i32 %op1841, ptr %slot161, align 8
  %v1842 = load i32, ptr %slot161, align 8
  %op1843 = or i32 %v1842, 0
  store i32 %op1843, ptr %slot162, align 8
  %v1844 = load i64, ptr %slot41, align 8
  store i64 %v1844, ptr %slot163, align 8
  %v1845 = load i64, ptr %slot69, align 8
  %v1846 = load i64, ptr %slot163, align 8
  %v1847 = load i64, ptr %slot155, align 8
  %v1848 = load i64, ptr %slot160, align 8
  %cv1849 = trunc i64 %v1848 to i32
  %v1850 = load i32, ptr %slot162, align 8
  %call1851 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64 %v1845, i64 %v1846, i64 %v1847, i32 %cv1849, i32 %v1850) nomerge, !dbg !120
  store i32 %call1851, ptr %slot164, align 8
  %v1852 = load i32, ptr %slot164, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcsuccess161, label %bb_rcfailure161
bb_rcfailure161:
  %v1855 = load i64, ptr %slot69, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %call1857 = call i32 @myl_rc_take_failure(ptr %p1856) nomerge, !dbg !120
  store i32 %call1857, ptr %slot165, align 8
  %v1858 = load i64, ptr %slot1, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %v1860 = load i32, ptr %slot165, align 8
  %call1861 = call i32 @myl_qbe_rc_status(ptr %p1859, i32 %v1860) nomerge, !dbg !120
  store i32 %call1861, ptr %slot166, align 8
  br label %bb_failure
bb_rcsuccess161:
  %v1862 = load i32, ptr %slot159, align 8
  %cv1863 = zext i32 %v1862 to i64
  %cond1864 = icmp ne i64 %cv1863, 0
  br i1 %cond1864, label %bb_rchtaken164, label %bb_rchcopied164
bb_rchcopied164:
  %v1865 = load i64, ptr %slot18, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  %ld1867 = load i32, ptr %p1866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1867, ptr %slot167, align 8
  %v1868 = load i32, ptr %slot167, align 8
  %cv1869 = zext i32 %v1868 to i64
  %cond1870 = icmp ne i64 %cv1869, 0
  br i1 %cond1870, label %bb_rcslotdrop167, label %bb_rcslotdone167
bb_rcslotdrop167:
  %v1871 = load i64, ptr %slot18, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  store i32 0, ptr %p1872, align 4, !alias.scope !3, !noalias !4
  %v1873 = load i64, ptr %slot33, align 8
  store i64 %v1873, ptr %slot168, align 8
  %v1874 = load i64, ptr %slot19, align 8
  %p1875 = inttoptr i64 %v1874 to ptr
  %ld1876 = load i32, ptr %p1875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1876, ptr %slot169, align 8
  %v1877 = load i32, ptr %slot169, align 8
  %op1878 = and i32 %v1877, 28
  store i32 %op1878, ptr %slot170, align 8
  %v1879 = load i32, ptr %slot170, align 8
  %cv1880 = zext i32 %v1879 to i64
  %cond1881 = icmp ne i64 %cv1880, 0
  br i1 %cond1881, label %bb_rcslotrole167, label %bb_rcslotowner167
bb_rcslotrole167:
  %v1882 = load i64, ptr %slot69, align 8
  store i64 %v1882, ptr %slot171, align 8
  %v1883 = load i64, ptr %slot171, align 8
  %v1884 = load i64, ptr %slot168, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1883, i64 %v1884) nomerge, !dbg !120
  br label %bb_rcslotdone167
bb_rcslotowner167:
  %v1885 = load i64, ptr %slot69, align 8
  store i64 %v1885, ptr %slot172, align 8
  %v1886 = load i64, ptr %slot172, align 8
  %v1887 = load i64, ptr %slot168, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1886, i64 %v1887) nomerge, !dbg !120
  br label %bb_rcslotdone167
bb_rcslotdone167:
  br label %bb_rchprepared164
bb_rchtaken164:
  %v1888 = load i64, ptr %slot18, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i32 0, ptr %p1889, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared164
bb_rchprepared164:
  %v1890 = load i64, ptr %slot30, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  store i32 2, ptr %p1891, align 4, !alias.scope !3, !noalias !4
  %v1892 = load i64, ptr %slot29, align 8
  %p1893 = inttoptr i64 %v1892 to ptr
  store i32 1, ptr %p1893, align 4, !alias.scope !3, !noalias !4
  %v1894 = load i64, ptr %slot33, align 8
  store i64 %v1894, ptr %slot173, align 8
  %v1895 = load i64, ptr %slot41, align 8
  store i64 %v1895, ptr %slot174, align 8
  %v1896 = load i64, ptr %slot174, align 8
  %v1897 = load i64, ptr %slot173, align 8
  %p1898 = inttoptr i64 %v1896 to ptr
  %p1899 = inttoptr i64 %v1897 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1899, ptr %p1898, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1900 = load i64, ptr %slot19, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  store i32 2, ptr %p1901, align 4, !alias.scope !3, !noalias !4
  %v1902 = load i64, ptr %slot30, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  %ld1904 = load i32, ptr %p1903, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1904, ptr %slot175, align 8
  %v1905 = load i32, ptr %slot175, align 8
  %v1906 = load i64, ptr %slot19, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i32 %v1905, ptr %p1907, align 4, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot29, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  store i32 0, ptr %p1909, align 4, !alias.scope !3, !noalias !4
  %v1910 = load i64, ptr %slot18, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i32 1, ptr %p1911, align 4, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot173, align 8
  %v1913 = load i64, ptr %slot51, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  store i64 %v1912, ptr %p1914, align 8, !alias.scope !3, !noalias !4
  %v1915 = load i64, ptr %slot44, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  %ld1917 = load i64, ptr %p1916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1917, ptr %slot176, align 8
  %v1918 = load i64, ptr %slot176, align 8
  %v1919 = load i64, ptr %slot52, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  store i64 %v1918, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  %v1921 = load i64, ptr %slot44, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  %ld1923 = load i64, ptr %p1922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1923, ptr %slot177, align 8
  %v1924 = load i64, ptr %slot177, align 8
  %v1925 = load i64, ptr %slot53, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  store i64 %v1924, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  %v1927 = load i64, ptr %slot53, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  %ld1929 = load i64, ptr %p1928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1929, ptr %slot178, align 8
  %v1930 = load i64, ptr %slot1, align 8
  %v1931 = load i64, ptr %slot178, align 8
  call void @myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow(ptr sret([32 x i8]) align 8 %callresult180, i64 %v1930, i64 %v1931) nomerge, !dbg !122
  %addr1932 = ptrtoint ptr %callresult180 to i64
  store i64 %addr1932, ptr %slot179, align 8
  %v1933 = load i64, ptr %slot179, align 8
  %v1934 = load i64, ptr %slot53, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  store i64 %v1933, ptr %p1935, align 8, !alias.scope !3, !noalias !4
  %v1936 = load i64, ptr %slot45, align 8
  %v1937 = load i64, ptr %slot54, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  store i64 %v1936, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  %v1939 = load i64, ptr %slot45, align 8
  %v1940 = load i64, ptr %slot55, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  store i64 %v1939, ptr %p1941, align 8, !alias.scope !3, !noalias !4
  %v1942 = load i64, ptr %slot56, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  store i64 0, ptr %p1943, align 8, !alias.scope !3, !noalias !4
  %v1944 = load i64, ptr %slot57, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  store i64 0, ptr %p1945, align 8, !alias.scope !3, !noalias !4
  %v1946 = load i64, ptr %slot58, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  store i64 0, ptr %p1947, align 8, !alias.scope !3, !noalias !4
  %v1948 = load i64, ptr %slot58, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  %ld1950 = load i64, ptr %p1949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1950, ptr %slot181, align 8
  %v1951 = load i64, ptr %slot181, align 8
  %cmp1952 = icmp sge i64 %v1951, 0
  %cv1953 = zext i1 %cmp1952 to i64
  store i64 %cv1953, ptr %slot182, align 8
  %v1954 = load i64, ptr %slot182, align 8
  %cond1955 = icmp ne i64 %v1954, 0
  br i1 %cond1955, label %bb_success228, label %bb_failed228
bb_failed228:
  %v1956 = load i64, ptr %slot1, align 8
  %p1957 = inttoptr i64 %v1956 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1957) nomerge, !dbg !124
  unreachable
bb_success228:
  %v1958 = load i64, ptr %slot69, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  %p1960 = inttoptr i64 ptrtoint (ptr @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd to i64) to ptr
  %v1961 = load i64, ptr %slot181, align 8
  %call1962 = call ptr @myl_native_list_new(ptr %p1959, ptr %p1960, i64 %v1961) nomerge, !dbg !124
  %calladdr1963 = ptrtoint ptr %call1962 to i64
  store i64 %calladdr1963, ptr %slot183, align 8
  %v1964 = load i64, ptr %slot183, align 8
  %cond1965 = icmp ne i64 %v1964, 0
  br i1 %cond1965, label %bb_success230, label %bb_failed230
bb_failed230:
  %v1966 = load i64, ptr %slot1, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1967) nomerge, !dbg !124
  unreachable
bb_success230:
  %v1968 = load i64, ptr %slot183, align 8
  %v1969 = load i64, ptr %slot58, align 8
  %p1970 = inttoptr i64 %v1969 to ptr
  store i64 %v1968, ptr %p1970, align 8, !alias.scope !3, !noalias !4
  %v1971 = load i64, ptr %slot58, align 8
  %p1972 = inttoptr i64 %v1971 to ptr
  %ld1973 = load i64, ptr %p1972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1973, ptr %slot184, align 8
  %v1974 = load i64, ptr %slot184, align 8
  %v1975 = load i64, ptr %slot39, align 8
  %p1976 = inttoptr i64 %v1975 to ptr
  store i64 %v1974, ptr %p1976, align 8, !alias.scope !3, !noalias !4
  %v1977 = load i64, ptr %slot39, align 8
  store i64 %v1977, ptr %slot185, align 8
  %v1978 = load i64, ptr %slot41, align 8
  store i64 %v1978, ptr %slot186, align 8
  %v1979 = load i64, ptr %slot185, align 8
  %v1980 = load i64, ptr %slot186, align 8
  %p1981 = inttoptr i64 %v1979 to ptr
  %p1982 = inttoptr i64 %v1980 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1982, ptr %p1981, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1983 = load i64, ptr %slot30, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  store i32 2, ptr %p1984, align 4, !alias.scope !3, !noalias !4
  %v1985 = load i64, ptr %slot29, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  store i32 1, ptr %p1986, align 4, !alias.scope !3, !noalias !4
  %v1987 = load i64, ptr %slot35, align 8
  store i64 %v1987, ptr %slot187, align 8
  %v1988 = load i64, ptr %slot41, align 8
  store i64 %v1988, ptr %slot188, align 8
  %v1989 = load i64, ptr %slot188, align 8
  %v1990 = load i64, ptr %slot187, align 8
  %p1991 = inttoptr i64 %v1989 to ptr
  %p1992 = inttoptr i64 %v1990 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1992, ptr %p1991, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1993 = load i64, ptr %slot26, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  store i32 2, ptr %p1994, align 4, !alias.scope !3, !noalias !4
  %v1995 = load i64, ptr %slot30, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  %ld1997 = load i32, ptr %p1996, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1997, ptr %slot189, align 8
  %v1998 = load i32, ptr %slot189, align 8
  %v1999 = load i64, ptr %slot26, align 8
  %p2000 = inttoptr i64 %v1999 to ptr
  store i32 %v1998, ptr %p2000, align 4, !alias.scope !3, !noalias !4
  %v2001 = load i64, ptr %slot29, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  store i32 0, ptr %p2002, align 4, !alias.scope !3, !noalias !4
  %v2003 = load i64, ptr %slot25, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  store i32 1, ptr %p2004, align 4, !alias.scope !3, !noalias !4
  %v2005 = load i64, ptr %slot187, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  %ld2007 = load i64, ptr %p2006, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2007, ptr %slot190, align 8
  %v2008 = load i64, ptr %slot190, align 8
  %v2009 = load i64, ptr %slot58, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  store i64 %v2008, ptr %p2010, align 8, !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot58, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  %ld2013 = load i64, ptr %p2012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2013, ptr %slot191, align 8
  %v2014 = load i64, ptr %slot191, align 8
  %v2015 = load i64, ptr %slot39, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  store i64 %v2014, ptr %p2016, align 8, !alias.scope !3, !noalias !4
  %v2017 = load i64, ptr %slot39, align 8
  store i64 %v2017, ptr %slot192, align 8
  %v2018 = load i64, ptr %slot25, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  %ld2020 = load i32, ptr %p2019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2020, ptr %slot193, align 8
  %v2021 = load i64, ptr %slot26, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  %ld2023 = load i32, ptr %p2022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2023, ptr %slot194, align 8
  %v2024 = load i32, ptr %slot194, align 8
  %op2025 = and i32 %v2024, 24
  store i32 %op2025, ptr %slot194, align 8
  %v2026 = load i32, ptr %slot194, align 8
  %cmp2027 = icmp eq i32 %v2026, 0
  %cv2028 = zext i1 %cmp2027 to i32
  store i32 %cv2028, ptr %slot195, align 8
  %v2029 = load i32, ptr %slot193, align 8
  %v2030 = load i32, ptr %slot195, align 8
  %op2031 = and i32 %v2029, %v2030
  store i32 %op2031, ptr %slot196, align 8
  %v2032 = load i32, ptr %slot196, align 8
  %cv2033 = zext i32 %v2032 to i64
  %cond2034 = icmp ne i64 %cv2033, 0
  br i1 %cond2034, label %bb_rcprivateown253, label %bb_rcprivateloan253
bb_rcprivateown253:
  %v2035 = load i64, ptr %slot41, align 8
  store i64 %v2035, ptr %slot197, align 8
  %v2036 = load i64, ptr %slot70, align 8
  store i64 %v2036, ptr %slot198, align 8
  %v2037 = load i64, ptr %slot192, align 8
  %v2038 = load i64, ptr %slot197, align 8
  %op2039 = sub i64 %v2037, %v2038
  store i64 %op2039, ptr %slot199, align 8
  %v2040 = load i64, ptr %slot197, align 8
  %v2041 = load i64, ptr %slot192, align 8
  %op2042 = sub i64 %v2040, %v2041
  store i64 %op2042, ptr %slot200, align 8
  %v2043 = load i64, ptr %slot199, align 8
  %cmp2044 = icmp ult i64 %v2043, 8
  %cv2045 = zext i1 %cmp2044 to i32
  store i32 %cv2045, ptr %slot201, align 8
  %v2046 = load i64, ptr %slot200, align 8
  %cmp2047 = icmp ult i64 %v2046, 8
  %cv2048 = zext i1 %cmp2047 to i32
  store i32 %cv2048, ptr %slot202, align 8
  %v2049 = load i32, ptr %slot201, align 8
  %v2050 = load i32, ptr %slot202, align 8
  %op2051 = or i32 %v2049, %v2050
  store i32 %op2051, ptr %slot203, align 8
  %v2052 = load i32, ptr %slot203, align 8
  %cv2053 = zext i32 %v2052 to i64
  %cond2054 = icmp ne i64 %cv2053, 0
  br i1 %cond2054, label %bb_rcmoveslow256, label %bb_rcmovecheck256
bb_rcmovecheck256:
  %v2055 = load i64, ptr %slot192, align 8
  %p2057 = inttoptr i64 %v2055 to ptr
  %gep2058 = getelementptr i8, ptr %p2057, i64 0
  %op2056 = ptrtoint ptr %gep2058 to i64
  store i64 %op2056, ptr %slot204, align 8
  %v2059 = load i64, ptr %slot204, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  %ld2061 = load i64, ptr %p2060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2061, ptr %slot205, align 8
  %v2062 = load i64, ptr %slot205, align 8
  %cmp2063 = icmp ne i64 %v2062, 0
  %cv2064 = zext i1 %cmp2063 to i32
  store i32 %cv2064, ptr %slot206, align 8
  %v2065 = load i32, ptr %slot206, align 8
  %cv2066 = zext i32 %v2065 to i64
  %cond2067 = icmp ne i64 %cv2066, 0
  br i1 %cond2067, label %bb_rcmoveheader264, label %bb_rcmovenext264
bb_rcmoveheader264:
  %v2068 = load i64, ptr %slot205, align 8
  %op2069 = sub i64 %v2068, 16
  store i64 %op2069, ptr %slot207, align 8
  %v2070 = load i64, ptr %slot205, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  %rgep2072 = getelementptr i8, ptr %p2071, i64 -16
  %ld2073 = load i64, ptr %rgep2072, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2073, ptr %slot208, align 8
  %v2074 = load i64, ptr %slot208, align 8
  %op2075 = and i64 %v2074, 5764607523034234881
  store i64 %op2075, ptr %slot209, align 8
  %v2076 = load i64, ptr %slot209, align 8
  %cmp2077 = icmp ne i64 %v2076, 0
  %cv2078 = zext i1 %cmp2077 to i32
  store i32 %cv2078, ptr %slot210, align 8
  %v2079 = load i32, ptr %slot210, align 8
  %cv2080 = zext i32 %v2079 to i64
  %cond2081 = icmp ne i64 %cv2080, 0
  br i1 %cond2081, label %bb_rcmoveslow256, label %bb_rcmovenext264
bb_rcmovenext264:
  %v2082 = load i64, ptr %slot192, align 8
  %v2083 = load i64, ptr %slot197, align 8
  %p2084 = inttoptr i64 %v2082 to ptr
  %p2085 = inttoptr i64 %v2083 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2085, ptr %p2084, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2086 = load i64, ptr %slot192, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i64 0, ptr %p2087, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved256
bb_rcmoveslow256:
  %v2088 = load i64, ptr %slot69, align 8
  %v2089 = load i64, ptr %slot197, align 8
  %v2090 = load i64, ptr %slot192, align 8
  %v2091 = load i64, ptr %slot198, align 8
  %cv2092 = trunc i64 %v2091 to i32
  %call2093 = call i32 @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_take(i64 %v2088, i64 %v2089, i64 %v2090, i32 %cv2092) nomerge, !dbg !126
  store i32 %call2093, ptr %slot211, align 8
  %v2094 = load i32, ptr %slot211, align 8
  %cv2095 = zext i32 %v2094 to i64
  %cond2096 = icmp ne i64 %cv2095, 0
  br i1 %cond2096, label %bb_rcsuccess271, label %bb_rcfailure271
bb_rcfailure271:
  %v2097 = load i64, ptr %slot69, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  %call2099 = call i32 @myl_rc_take_failure(ptr %p2098) nomerge, !dbg !126
  store i32 %call2099, ptr %slot212, align 8
  %v2100 = load i64, ptr %slot1, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  %v2102 = load i32, ptr %slot212, align 8
  %call2103 = call i32 @myl_qbe_rc_status(ptr %p2101, i32 %v2102) nomerge, !dbg !126
  store i32 %call2103, ptr %slot213, align 8
  br label %bb_failure
bb_rcsuccess271:
  br label %bb_rcmoved256
bb_rcmoved256:
  %v2104 = load i64, ptr %slot25, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i32 0, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot30, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  store i32 2, ptr %p2107, align 4, !alias.scope !3, !noalias !4
  %v2108 = load i64, ptr %slot29, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  store i32 1, ptr %p2109, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared253
bb_rcprivateloan253:
  %v2110 = load i64, ptr %slot25, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %ld2112 = load i32, ptr %p2111, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2112, ptr %slot214, align 8
  %v2113 = load i64, ptr %slot26, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %ld2115 = load i32, ptr %p2114, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2115, ptr %slot215, align 8
  %v2116 = load i32, ptr %slot215, align 8
  %cmp2117 = icmp eq i32 %v2116, 16
  %cv2118 = zext i1 %cmp2117 to i32
  store i32 %cv2118, ptr %slot216, align 8
  %v2119 = load i32, ptr %slot216, align 8
  %v2120 = load i32, ptr %slot214, align 8
  %op2121 = and i32 %v2119, %v2120
  store i32 %op2121, ptr %slot216, align 8
  %v2122 = load i32, ptr %slot216, align 8
  %cv2123 = zext i32 %v2122 to i64
  %cond2124 = icmp ne i64 %cv2123, 0
  br i1 %cond2124, label %bb_rcprivatemove253, label %bb_rcprivatenew253
bb_rcprivatemove253:
  %v2125 = load i64, ptr %slot41, align 8
  store i64 %v2125, ptr %slot217, align 8
  %v2126 = load i64, ptr %slot192, align 8
  %v2127 = load i64, ptr %slot217, align 8
  %p2128 = inttoptr i64 %v2126 to ptr
  %p2129 = inttoptr i64 %v2127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2129, ptr %p2128, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2130 = load i64, ptr %slot192, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  store i64 0, ptr %p2131, align 8, !alias.scope !3, !noalias !4
  %v2132 = load i64, ptr %slot30, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  store i32 2, ptr %p2133, align 4, !alias.scope !3, !noalias !4
  %v2134 = load i64, ptr %slot30, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  store i32 16, ptr %p2135, align 4, !alias.scope !3, !noalias !4
  %v2136 = load i64, ptr %slot29, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  store i32 1, ptr %p2137, align 4, !alias.scope !3, !noalias !4
  %v2138 = load i64, ptr %slot25, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  store i32 0, ptr %p2139, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared253
bb_rcprivatenew253:
  %v2140 = load i64, ptr %slot41, align 8
  store i64 %v2140, ptr %slot218, align 8
  %v2141 = load i64, ptr %slot192, align 8
  %p2142 = inttoptr i64 %v2141 to ptr
  %ld2143 = load i64, ptr %p2142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2143, ptr %slot219, align 8
  %v2144 = load i64, ptr %slot219, align 8
  %cmp2145 = icmp ne i64 %v2144, 0
  %cv2146 = zext i1 %cmp2145 to i32
  store i32 %cv2146, ptr %slot220, align 8
  %v2147 = load i32, ptr %slot220, align 8
  %cv2148 = zext i32 %v2147 to i64
  %cond2149 = icmp ne i64 %cv2148, 0
  br i1 %cond2149, label %bb_rcgnn289, label %bb_rcgstore289
bb_rcgnn289:
  %v2150 = load i64, ptr %slot219, align 8
  %op2151 = sub i64 %v2150, 16
  store i64 %op2151, ptr %slot221, align 8
  %v2152 = load i64, ptr %slot219, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  %rgep2154 = getelementptr i8, ptr %p2153, i64 -16
  %ld2155 = load i64, ptr %rgep2154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2155, ptr %slot222, align 8
  %v2156 = load i64, ptr %slot222, align 8
  %op2157 = and i64 %v2156, 4611686018427387906
  store i64 %op2157, ptr %slot223, align 8
  %v2158 = load i64, ptr %slot223, align 8
  %cmp2159 = icmp ne i64 %v2158, 0
  %cv2160 = zext i1 %cmp2159 to i32
  store i32 %cv2160, ptr %slot224, align 8
  %v2161 = load i32, ptr %slot224, align 8
  %cv2162 = zext i32 %v2161 to i64
  %cond2163 = icmp ne i64 %cv2162, 0
  br i1 %cond2163, label %bb_rcgstore289, label %bb_rcginc289
bb_rcginc289:
  %v2164 = load i64, ptr %slot219, align 8
  %op2165 = sub i64 %v2164, 24
  store i64 %op2165, ptr %slot225, align 8
  %v2166 = load i64, ptr %slot219, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %rgep2168 = getelementptr i8, ptr %p2167, i64 -24
  %ld2169 = load i64, ptr %rgep2168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2169, ptr %slot226, align 8
  %v2170 = load i64, ptr %slot226, align 8
  %op2171 = add i64 %v2170, 1
  store i64 %op2171, ptr %slot227, align 8
  %v2172 = load i64, ptr %slot227, align 8
  %cmp2173 = icmp eq i64 %v2172, 0
  %cv2174 = zext i1 %cmp2173 to i32
  store i32 %cv2174, ptr %slot228, align 8
  %v2175 = load i32, ptr %slot228, align 8
  %cv2176 = zext i32 %v2175 to i64
  %cond2177 = icmp ne i64 %cv2176, 0
  br i1 %cond2177, label %bb_rcglimit289, label %bb_rcgcapacity289
bb_rcglimit289:
  %v2178 = load i64, ptr %slot1, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  %call2180 = call i32 @myl_qbe_rc_status(ptr %p2179, i32 2) nomerge, !dbg !126
  store i32 %call2180, ptr %slot229, align 8
  br label %bb_failure
bb_rcgcapacity289:
  %v2181 = load i64, ptr %slot227, align 8
  %v2182 = load i64, ptr %slot219, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  %rgep2184 = getelementptr i8, ptr %p2183, i64 -24
  store i64 %v2181, ptr %rgep2184, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore289
bb_rcgstore289:
  %v2185 = load i64, ptr %slot219, align 8
  %v2186 = load i64, ptr %slot218, align 8
  %p2187 = inttoptr i64 %v2186 to ptr
  store i64 %v2185, ptr %p2187, align 8, !alias.scope !3, !noalias !4
  %v2188 = load i64, ptr %slot30, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  store i32 2, ptr %p2189, align 4, !alias.scope !3, !noalias !4
  %v2190 = load i64, ptr %slot30, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  store i32 16, ptr %p2191, align 4, !alias.scope !3, !noalias !4
  %v2192 = load i64, ptr %slot29, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  store i32 1, ptr %p2193, align 4, !alias.scope !3, !noalias !4
  %v2194 = load i64, ptr %slot25, align 8
  %p2195 = inttoptr i64 %v2194 to ptr
  %ld2196 = load i32, ptr %p2195, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2196, ptr %slot230, align 8
  %v2197 = load i32, ptr %slot230, align 8
  %cv2198 = zext i32 %v2197 to i64
  %cond2199 = icmp ne i64 %cv2198, 0
  br i1 %cond2199, label %bb_rcslotdrop305, label %bb_rcslotdone305
bb_rcslotdrop305:
  %v2200 = load i64, ptr %slot25, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  store i32 0, ptr %p2201, align 4, !alias.scope !3, !noalias !4
  %v2202 = load i64, ptr %slot35, align 8
  store i64 %v2202, ptr %slot231, align 8
  %v2203 = load i64, ptr %slot26, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  %ld2205 = load i32, ptr %p2204, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2205, ptr %slot232, align 8
  %v2206 = load i32, ptr %slot232, align 8
  %op2207 = and i32 %v2206, 28
  store i32 %op2207, ptr %slot233, align 8
  %v2208 = load i32, ptr %slot233, align 8
  %cv2209 = zext i32 %v2208 to i64
  %cond2210 = icmp ne i64 %cv2209, 0
  br i1 %cond2210, label %bb_rcslotrole305, label %bb_rcslotowner305
bb_rcslotrole305:
  %v2211 = load i64, ptr %slot69, align 8
  store i64 %v2211, ptr %slot234, align 8
  %v2212 = load i64, ptr %slot231, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  %ld2214 = load i64, ptr %p2213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2214, ptr %slot235, align 8
  %v2215 = load i64, ptr %slot235, align 8
  %cmp2216 = icmp ne i64 %v2215, 0
  %cv2217 = zext i1 %cmp2216 to i32
  store i32 %cv2217, ptr %slot236, align 8
  %v2218 = load i32, ptr %slot236, align 8
  %cv2219 = zext i32 %v2218 to i64
  %cond2220 = icmp ne i64 %cv2219, 0
  br i1 %cond2220, label %bb_rcgnn321, label %bb_rcgdone321
bb_rcgnn321:
  %v2221 = load i64, ptr %slot235, align 8
  %op2222 = sub i64 %v2221, 16
  store i64 %op2222, ptr %slot237, align 8
  %v2223 = load i64, ptr %slot235, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %rgep2225 = getelementptr i8, ptr %p2224, i64 -16
  %ld2226 = load i64, ptr %rgep2225, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2226, ptr %slot238, align 8
  %v2227 = load i64, ptr %slot238, align 8
  %op2228 = and i64 %v2227, 4611686018427387906
  store i64 %op2228, ptr %slot239, align 8
  %v2229 = load i64, ptr %slot239, align 8
  %cmp2230 = icmp ne i64 %v2229, 0
  %cv2231 = zext i1 %cmp2230 to i32
  store i32 %cv2231, ptr %slot240, align 8
  %v2232 = load i32, ptr %slot240, align 8
  %cv2233 = zext i32 %v2232 to i64
  %cond2234 = icmp ne i64 %cv2233, 0
  br i1 %cond2234, label %bb_rcgclear321, label %bb_rcgcounted321
bb_rcgcounted321:
  %v2235 = load i64, ptr %slot235, align 8
  %op2236 = sub i64 %v2235, 24
  store i64 %op2236, ptr %slot241, align 8
  %v2237 = load i64, ptr %slot235, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  %rgep2239 = getelementptr i8, ptr %p2238, i64 -24
  %ld2240 = load i64, ptr %rgep2239, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2240, ptr %slot242, align 8
  %v2241 = load i64, ptr %slot242, align 8
  %op2242 = sub i64 %v2241, 1
  store i64 %op2242, ptr %slot243, align 8
  %v2243 = load i64, ptr %slot243, align 8
  %cmp2244 = icmp eq i64 %v2243, 0
  %cv2245 = zext i1 %cmp2244 to i32
  store i32 %cv2245, ptr %slot244, align 8
  %v2246 = load i32, ptr %slot244, align 8
  %cv2247 = zext i32 %v2246 to i64
  %cond2248 = icmp ne i64 %cv2247, 0
  br i1 %cond2248, label %bb_rcglast321, label %bb_rcgdec321
bb_rcglast321:
  %v2249 = load i64, ptr %slot235, align 8
  %op2250 = sub i64 %v2249, 32
  store i64 %op2250, ptr %slot245, align 8
  %v2251 = load i64, ptr %slot235, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  %rgep2253 = getelementptr i8, ptr %p2252, i64 -32
  %ld2254 = load i64, ptr %rgep2253, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2254, ptr %slot246, align 8
  %v2255 = load i64, ptr %slot246, align 8
  %cmp2256 = icmp ne i64 %v2255, 0
  %cv2257 = zext i1 %cmp2256 to i32
  store i32 %cv2257, ptr %slot247, align 8
  %v2258 = load i32, ptr %slot247, align 8
  %cv2259 = zext i32 %v2258 to i64
  %cond2260 = icmp ne i64 %cv2259, 0
  br i1 %cond2260, label %bb_rcgdec321, label %bb_rcgslow321
bb_rcgslow321:
  %v2261 = load i64, ptr %slot234, align 8
  %v2262 = load i64, ptr %slot231, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v2261, i64 %v2262) nomerge, !dbg !126
  br label %bb_rcgdone321
bb_rcgdec321:
  %v2263 = load i64, ptr %slot243, align 8
  %v2264 = load i64, ptr %slot235, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  %rgep2266 = getelementptr i8, ptr %p2265, i64 -24
  store i64 %v2263, ptr %rgep2266, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear321
bb_rcgclear321:
  %v2267 = load i64, ptr %slot231, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  store i64 0, ptr %p2268, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone321
bb_rcgdone321:
  br label %bb_rcslotdone305
bb_rcslotowner305:
  %v2269 = load i64, ptr %slot69, align 8
  store i64 %v2269, ptr %slot248, align 8
  %v2270 = load i64, ptr %slot231, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  %ld2272 = load i64, ptr %p2271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2272, ptr %slot249, align 8
  %v2273 = load i64, ptr %slot249, align 8
  %cmp2274 = icmp ne i64 %v2273, 0
  %cv2275 = zext i1 %cmp2274 to i32
  store i32 %cv2275, ptr %slot250, align 8
  %v2276 = load i32, ptr %slot250, align 8
  %cv2277 = zext i32 %v2276 to i64
  %cond2278 = icmp ne i64 %cv2277, 0
  br i1 %cond2278, label %bb_rcgnn336, label %bb_rcgdone336
bb_rcgnn336:
  %v2279 = load i64, ptr %slot249, align 8
  %op2280 = sub i64 %v2279, 16
  store i64 %op2280, ptr %slot251, align 8
  %v2281 = load i64, ptr %slot249, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  %rgep2283 = getelementptr i8, ptr %p2282, i64 -16
  %ld2284 = load i64, ptr %rgep2283, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2284, ptr %slot252, align 8
  %v2285 = load i64, ptr %slot252, align 8
  %op2286 = and i64 %v2285, 4611686018427387906
  store i64 %op2286, ptr %slot253, align 8
  %v2287 = load i64, ptr %slot253, align 8
  %cmp2288 = icmp ne i64 %v2287, 0
  %cv2289 = zext i1 %cmp2288 to i32
  store i32 %cv2289, ptr %slot254, align 8
  %v2290 = load i32, ptr %slot254, align 8
  %cv2291 = zext i32 %v2290 to i64
  %cond2292 = icmp ne i64 %cv2291, 0
  br i1 %cond2292, label %bb_rcgclear336, label %bb_rcgcounted336
bb_rcgcounted336:
  %v2293 = load i64, ptr %slot249, align 8
  %op2294 = sub i64 %v2293, 32
  store i64 %op2294, ptr %slot255, align 8
  %v2295 = load i64, ptr %slot249, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  %rgep2297 = getelementptr i8, ptr %p2296, i64 -32
  %ld2298 = load i64, ptr %rgep2297, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2298, ptr %slot256, align 8
  %v2299 = load i64, ptr %slot256, align 8
  %op2300 = sub i64 %v2299, 1
  store i64 %op2300, ptr %slot257, align 8
  %v2301 = load i64, ptr %slot257, align 8
  %cmp2302 = icmp eq i64 %v2301, 0
  %cv2303 = zext i1 %cmp2302 to i32
  store i32 %cv2303, ptr %slot258, align 8
  %v2304 = load i32, ptr %slot258, align 8
  %cv2305 = zext i32 %v2304 to i64
  %cond2306 = icmp ne i64 %cv2305, 0
  br i1 %cond2306, label %bb_rcglast336, label %bb_rcgdec336
bb_rcglast336:
  %v2307 = load i64, ptr %slot249, align 8
  %op2308 = sub i64 %v2307, 24
  store i64 %op2308, ptr %slot259, align 8
  %v2309 = load i64, ptr %slot249, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  %rgep2311 = getelementptr i8, ptr %p2310, i64 -24
  %ld2312 = load i64, ptr %rgep2311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2312, ptr %slot260, align 8
  %v2313 = load i64, ptr %slot260, align 8
  %cmp2314 = icmp ne i64 %v2313, 0
  %cv2315 = zext i1 %cmp2314 to i32
  store i32 %cv2315, ptr %slot261, align 8
  %v2316 = load i32, ptr %slot261, align 8
  %cv2317 = zext i32 %v2316 to i64
  %cond2318 = icmp ne i64 %cv2317, 0
  br i1 %cond2318, label %bb_rcgdec336, label %bb_rcgslow336
bb_rcgslow336:
  %v2319 = load i64, ptr %slot248, align 8
  %v2320 = load i64, ptr %slot231, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v2319, i64 %v2320) nomerge, !dbg !126
  br label %bb_rcgdone336
bb_rcgdec336:
  %v2321 = load i64, ptr %slot257, align 8
  %v2322 = load i64, ptr %slot249, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  %rgep2324 = getelementptr i8, ptr %p2323, i64 -32
  store i64 %v2321, ptr %rgep2324, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear336
bb_rcgclear336:
  %v2325 = load i64, ptr %slot231, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  store i64 0, ptr %p2326, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone336
bb_rcgdone336:
  br label %bb_rcslotdone305
bb_rcslotdone305:
  br label %bb_rcprivateprepared253
bb_rcprivateprepared253:
  %v2327 = load i64, ptr %slot8, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  %ld2329 = load i32, ptr %p2328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2329, ptr %slot262, align 8
  %v2330 = load i32, ptr %slot262, align 8
  %cv2331 = zext i32 %v2330 to i64
  %cond2332 = icmp ne i64 %cv2331, 0
  br i1 %cond2332, label %bb_rcslotdrop343, label %bb_rcslotdone343
bb_rcslotdrop343:
  %v2333 = load i64, ptr %slot8, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  store i32 0, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  %v2335 = load i64, ptr %slot46, align 8
  store i64 %v2335, ptr %slot263, align 8
  %v2336 = load i64, ptr %slot9, align 8
  %p2337 = inttoptr i64 %v2336 to ptr
  %ld2338 = load i32, ptr %p2337, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2338, ptr %slot264, align 8
  %v2339 = load i32, ptr %slot264, align 8
  %op2340 = and i32 %v2339, 28
  store i32 %op2340, ptr %slot265, align 8
  %v2341 = load i32, ptr %slot265, align 8
  %cv2342 = zext i32 %v2341 to i64
  %cond2343 = icmp ne i64 %cv2342, 0
  br i1 %cond2343, label %bb_rcslotrole343, label %bb_rcslotowner343
bb_rcslotrole343:
  %v2344 = load i64, ptr %slot69, align 8
  store i64 %v2344, ptr %slot266, align 8
  %v2345 = load i64, ptr %slot263, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  %ld2347 = load i64, ptr %p2346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2347, ptr %slot267, align 8
  %v2348 = load i64, ptr %slot267, align 8
  %cmp2349 = icmp ne i64 %v2348, 0
  %cv2350 = zext i1 %cmp2349 to i32
  store i32 %cv2350, ptr %slot268, align 8
  %v2351 = load i32, ptr %slot268, align 8
  %cv2352 = zext i32 %v2351 to i64
  %cond2353 = icmp ne i64 %cv2352, 0
  br i1 %cond2353, label %bb_rcgnn359, label %bb_rcgdone359
bb_rcgnn359:
  %v2354 = load i64, ptr %slot267, align 8
  %op2355 = sub i64 %v2354, 16
  store i64 %op2355, ptr %slot269, align 8
  %v2356 = load i64, ptr %slot267, align 8
  %p2357 = inttoptr i64 %v2356 to ptr
  %rgep2358 = getelementptr i8, ptr %p2357, i64 -16
  %ld2359 = load i64, ptr %rgep2358, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2359, ptr %slot270, align 8
  %v2360 = load i64, ptr %slot270, align 8
  %op2361 = and i64 %v2360, 4611686018427387906
  store i64 %op2361, ptr %slot271, align 8
  %v2362 = load i64, ptr %slot271, align 8
  %cmp2363 = icmp ne i64 %v2362, 0
  %cv2364 = zext i1 %cmp2363 to i32
  store i32 %cv2364, ptr %slot272, align 8
  %v2365 = load i32, ptr %slot272, align 8
  %cv2366 = zext i32 %v2365 to i64
  %cond2367 = icmp ne i64 %cv2366, 0
  br i1 %cond2367, label %bb_rcgclear359, label %bb_rcgcounted359
bb_rcgcounted359:
  %v2368 = load i64, ptr %slot267, align 8
  %op2369 = sub i64 %v2368, 24
  store i64 %op2369, ptr %slot273, align 8
  %v2370 = load i64, ptr %slot267, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  %rgep2372 = getelementptr i8, ptr %p2371, i64 -24
  %ld2373 = load i64, ptr %rgep2372, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2373, ptr %slot274, align 8
  %v2374 = load i64, ptr %slot274, align 8
  %op2375 = sub i64 %v2374, 1
  store i64 %op2375, ptr %slot275, align 8
  %v2376 = load i64, ptr %slot275, align 8
  %cmp2377 = icmp eq i64 %v2376, 0
  %cv2378 = zext i1 %cmp2377 to i32
  store i32 %cv2378, ptr %slot276, align 8
  %v2379 = load i32, ptr %slot276, align 8
  %cv2380 = zext i32 %v2379 to i64
  %cond2381 = icmp ne i64 %cv2380, 0
  br i1 %cond2381, label %bb_rcglast359, label %bb_rcgdec359
bb_rcglast359:
  %v2382 = load i64, ptr %slot267, align 8
  %op2383 = sub i64 %v2382, 32
  store i64 %op2383, ptr %slot277, align 8
  %v2384 = load i64, ptr %slot267, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  %rgep2386 = getelementptr i8, ptr %p2385, i64 -32
  %ld2387 = load i64, ptr %rgep2386, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2387, ptr %slot278, align 8
  %v2388 = load i64, ptr %slot278, align 8
  %cmp2389 = icmp ne i64 %v2388, 0
  %cv2390 = zext i1 %cmp2389 to i32
  store i32 %cv2390, ptr %slot279, align 8
  %v2391 = load i32, ptr %slot279, align 8
  %cv2392 = zext i32 %v2391 to i64
  %cond2393 = icmp ne i64 %cv2392, 0
  br i1 %cond2393, label %bb_rcgdec359, label %bb_rcgslow359
bb_rcgslow359:
  %v2394 = load i64, ptr %slot266, align 8
  %v2395 = load i64, ptr %slot263, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v2394, i64 %v2395) nomerge, !dbg !126
  br label %bb_rcgdone359
bb_rcgdec359:
  %v2396 = load i64, ptr %slot275, align 8
  %v2397 = load i64, ptr %slot267, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  %rgep2399 = getelementptr i8, ptr %p2398, i64 -24
  store i64 %v2396, ptr %rgep2399, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear359
bb_rcgclear359:
  %v2400 = load i64, ptr %slot263, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  store i64 0, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone359
bb_rcgdone359:
  br label %bb_rcslotdone343
bb_rcslotowner343:
  %v2402 = load i64, ptr %slot69, align 8
  store i64 %v2402, ptr %slot280, align 8
  %v2403 = load i64, ptr %slot263, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  %ld2405 = load i64, ptr %p2404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2405, ptr %slot281, align 8
  %v2406 = load i64, ptr %slot281, align 8
  %cmp2407 = icmp ne i64 %v2406, 0
  %cv2408 = zext i1 %cmp2407 to i32
  store i32 %cv2408, ptr %slot282, align 8
  %v2409 = load i32, ptr %slot282, align 8
  %cv2410 = zext i32 %v2409 to i64
  %cond2411 = icmp ne i64 %cv2410, 0
  br i1 %cond2411, label %bb_rcgnn374, label %bb_rcgdone374
bb_rcgnn374:
  %v2412 = load i64, ptr %slot281, align 8
  %op2413 = sub i64 %v2412, 16
  store i64 %op2413, ptr %slot283, align 8
  %v2414 = load i64, ptr %slot281, align 8
  %p2415 = inttoptr i64 %v2414 to ptr
  %rgep2416 = getelementptr i8, ptr %p2415, i64 -16
  %ld2417 = load i64, ptr %rgep2416, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2417, ptr %slot284, align 8
  %v2418 = load i64, ptr %slot284, align 8
  %op2419 = and i64 %v2418, 4611686018427387906
  store i64 %op2419, ptr %slot285, align 8
  %v2420 = load i64, ptr %slot285, align 8
  %cmp2421 = icmp ne i64 %v2420, 0
  %cv2422 = zext i1 %cmp2421 to i32
  store i32 %cv2422, ptr %slot286, align 8
  %v2423 = load i32, ptr %slot286, align 8
  %cv2424 = zext i32 %v2423 to i64
  %cond2425 = icmp ne i64 %cv2424, 0
  br i1 %cond2425, label %bb_rcgclear374, label %bb_rcgcounted374
bb_rcgcounted374:
  %v2426 = load i64, ptr %slot281, align 8
  %op2427 = sub i64 %v2426, 32
  store i64 %op2427, ptr %slot287, align 8
  %v2428 = load i64, ptr %slot281, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  %rgep2430 = getelementptr i8, ptr %p2429, i64 -32
  %ld2431 = load i64, ptr %rgep2430, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2431, ptr %slot288, align 8
  %v2432 = load i64, ptr %slot288, align 8
  %op2433 = sub i64 %v2432, 1
  store i64 %op2433, ptr %slot289, align 8
  %v2434 = load i64, ptr %slot289, align 8
  %cmp2435 = icmp eq i64 %v2434, 0
  %cv2436 = zext i1 %cmp2435 to i32
  store i32 %cv2436, ptr %slot290, align 8
  %v2437 = load i32, ptr %slot290, align 8
  %cv2438 = zext i32 %v2437 to i64
  %cond2439 = icmp ne i64 %cv2438, 0
  br i1 %cond2439, label %bb_rcglast374, label %bb_rcgdec374
bb_rcglast374:
  %v2440 = load i64, ptr %slot281, align 8
  %op2441 = sub i64 %v2440, 24
  store i64 %op2441, ptr %slot291, align 8
  %v2442 = load i64, ptr %slot281, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  %rgep2444 = getelementptr i8, ptr %p2443, i64 -24
  %ld2445 = load i64, ptr %rgep2444, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2445, ptr %slot292, align 8
  %v2446 = load i64, ptr %slot292, align 8
  %cmp2447 = icmp ne i64 %v2446, 0
  %cv2448 = zext i1 %cmp2447 to i32
  store i32 %cv2448, ptr %slot293, align 8
  %v2449 = load i32, ptr %slot293, align 8
  %cv2450 = zext i32 %v2449 to i64
  %cond2451 = icmp ne i64 %cv2450, 0
  br i1 %cond2451, label %bb_rcgdec374, label %bb_rcgslow374
bb_rcgslow374:
  %v2452 = load i64, ptr %slot280, align 8
  %v2453 = load i64, ptr %slot263, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v2452, i64 %v2453) nomerge, !dbg !126
  br label %bb_rcgdone374
bb_rcgdec374:
  %v2454 = load i64, ptr %slot289, align 8
  %v2455 = load i64, ptr %slot281, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  %rgep2457 = getelementptr i8, ptr %p2456, i64 -32
  store i64 %v2454, ptr %rgep2457, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear374
bb_rcgclear374:
  %v2458 = load i64, ptr %slot263, align 8
  %p2459 = inttoptr i64 %v2458 to ptr
  store i64 0, ptr %p2459, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone374
bb_rcgdone374:
  br label %bb_rcslotdone343
bb_rcslotdone343:
  %v2460 = load i64, ptr %slot46, align 8
  store i64 %v2460, ptr %slot294, align 8
  %v2461 = load i64, ptr %slot41, align 8
  store i64 %v2461, ptr %slot295, align 8
  %v2462 = load i64, ptr %slot295, align 8
  %v2463 = load i64, ptr %slot294, align 8
  %p2464 = inttoptr i64 %v2462 to ptr
  %p2465 = inttoptr i64 %v2463 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2465, ptr %p2464, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2466 = load i64, ptr %slot29, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  store i32 0, ptr %p2467, align 4, !alias.scope !3, !noalias !4
  %v2468 = load i64, ptr %slot9, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  store i32 2, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  %v2470 = load i64, ptr %slot30, align 8
  %p2471 = inttoptr i64 %v2470 to ptr
  %ld2472 = load i32, ptr %p2471, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2472, ptr %slot296, align 8
  %v2473 = load i32, ptr %slot296, align 8
  %v2474 = load i64, ptr %slot9, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  store i32 %v2473, ptr %p2475, align 4, !alias.scope !3, !noalias !4
  %v2476 = load i64, ptr %slot8, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  store i32 1, ptr %p2477, align 4, !alias.scope !3, !noalias !4
  %v2478 = load i64, ptr %slot46, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  %ld2480 = load i64, ptr %p2479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2480, ptr %slot297, align 8
  %v2481 = load i64, ptr %slot297, align 8
  %v2482 = load i64, ptr %slot58, align 8
  %p2483 = inttoptr i64 %v2482 to ptr
  store i64 %v2481, ptr %p2483, align 8, !alias.scope !3, !noalias !4
  %v2484 = load i64, ptr %slot59, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  store i64 0, ptr %p2485, align 8, !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot59, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  %ld2488 = load i64, ptr %p2487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2488, ptr %slot298, align 8
  %v2489 = load i64, ptr %slot298, align 8
  %cmp2490 = icmp sge i64 %v2489, 0
  %cv2491 = zext i1 %cmp2490 to i64
  store i64 %cv2491, ptr %slot299, align 8
  %v2492 = load i64, ptr %slot299, align 8
  %cond2493 = icmp ne i64 %v2492, 0
  br i1 %cond2493, label %bb_success388, label %bb_failed388
bb_failed388:
  %v2494 = load i64, ptr %slot1, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p2495) nomerge, !dbg !128
  unreachable
bb_success388:
  %v2496 = load i64, ptr %slot69, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  %p2498 = inttoptr i64 ptrtoint (ptr @myl_t_eaa2bbcf1c7f4f7dc2a456cf256ba18c275165535be3a775a2eb8fbf8fec29dc to i64) to ptr
  %v2499 = load i64, ptr %slot298, align 8
  %call2500 = call ptr @myl_native_list_new(ptr %p2497, ptr %p2498, i64 %v2499) nomerge, !dbg !128
  %calladdr2501 = ptrtoint ptr %call2500 to i64
  store i64 %calladdr2501, ptr %slot300, align 8
  %v2502 = load i64, ptr %slot300, align 8
  %cond2503 = icmp ne i64 %v2502, 0
  br i1 %cond2503, label %bb_success390, label %bb_failed390
bb_failed390:
  %v2504 = load i64, ptr %slot1, align 8
  %p2505 = inttoptr i64 %v2504 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2505) nomerge, !dbg !128
  unreachable
bb_success390:
  %v2506 = load i64, ptr %slot300, align 8
  %v2507 = load i64, ptr %slot59, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  store i64 %v2506, ptr %p2508, align 8, !alias.scope !3, !noalias !4
  %v2509 = load i64, ptr %slot59, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  %ld2511 = load i64, ptr %p2510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2511, ptr %slot301, align 8
  %v2512 = load i64, ptr %slot301, align 8
  %v2513 = load i64, ptr %slot40, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  store i64 %v2512, ptr %p2514, align 8, !alias.scope !3, !noalias !4
  %v2515 = load i64, ptr %slot40, align 8
  store i64 %v2515, ptr %slot302, align 8
  %v2516 = load i64, ptr %slot41, align 8
  store i64 %v2516, ptr %slot303, align 8
  %v2517 = load i64, ptr %slot302, align 8
  %v2518 = load i64, ptr %slot303, align 8
  %p2519 = inttoptr i64 %v2517 to ptr
  %p2520 = inttoptr i64 %v2518 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2520, ptr %p2519, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot30, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i32 2, ptr %p2522, align 4, !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot29, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  store i32 1, ptr %p2524, align 4, !alias.scope !3, !noalias !4
  %v2525 = load i64, ptr %slot36, align 8
  store i64 %v2525, ptr %slot304, align 8
  %v2526 = load i64, ptr %slot41, align 8
  store i64 %v2526, ptr %slot305, align 8
  %v2527 = load i64, ptr %slot305, align 8
  %v2528 = load i64, ptr %slot304, align 8
  %p2529 = inttoptr i64 %v2527 to ptr
  %p2530 = inttoptr i64 %v2528 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2530, ptr %p2529, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2531 = load i64, ptr %slot28, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  store i32 2, ptr %p2532, align 4, !alias.scope !3, !noalias !4
  %v2533 = load i64, ptr %slot30, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  %ld2535 = load i32, ptr %p2534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2535, ptr %slot306, align 8
  %v2536 = load i32, ptr %slot306, align 8
  %v2537 = load i64, ptr %slot28, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i32 %v2536, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot29, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  store i32 0, ptr %p2540, align 4, !alias.scope !3, !noalias !4
  %v2541 = load i64, ptr %slot27, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  store i32 1, ptr %p2542, align 4, !alias.scope !3, !noalias !4
  %v2543 = load i64, ptr %slot304, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  %ld2545 = load i64, ptr %p2544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2545, ptr %slot307, align 8
  %v2546 = load i64, ptr %slot307, align 8
  %v2547 = load i64, ptr %slot59, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  store i64 %v2546, ptr %p2548, align 8, !alias.scope !3, !noalias !4
  %v2549 = load i64, ptr %slot59, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  %ld2551 = load i64, ptr %p2550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2551, ptr %slot308, align 8
  %v2552 = load i64, ptr %slot308, align 8
  %v2553 = load i64, ptr %slot40, align 8
  %p2554 = inttoptr i64 %v2553 to ptr
  store i64 %v2552, ptr %p2554, align 8, !alias.scope !3, !noalias !4
  %v2555 = load i64, ptr %slot40, align 8
  store i64 %v2555, ptr %slot309, align 8
  %v2556 = load i64, ptr %slot27, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  %ld2558 = load i32, ptr %p2557, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2558, ptr %slot310, align 8
  %v2559 = load i64, ptr %slot28, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  %ld2561 = load i32, ptr %p2560, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2561, ptr %slot311, align 8
  %v2562 = load i32, ptr %slot311, align 8
  %op2563 = and i32 %v2562, 24
  store i32 %op2563, ptr %slot311, align 8
  %v2564 = load i32, ptr %slot311, align 8
  %cmp2565 = icmp eq i32 %v2564, 0
  %cv2566 = zext i1 %cmp2565 to i32
  store i32 %cv2566, ptr %slot312, align 8
  %v2567 = load i32, ptr %slot310, align 8
  %v2568 = load i32, ptr %slot312, align 8
  %op2569 = and i32 %v2567, %v2568
  store i32 %op2569, ptr %slot313, align 8
  %v2570 = load i32, ptr %slot313, align 8
  %cv2571 = zext i32 %v2570 to i64
  %cond2572 = icmp ne i64 %cv2571, 0
  br i1 %cond2572, label %bb_rcprivateown413, label %bb_rcprivateloan413
bb_rcprivateown413:
  %v2573 = load i64, ptr %slot41, align 8
  store i64 %v2573, ptr %slot314, align 8
  %v2574 = load i64, ptr %slot70, align 8
  store i64 %v2574, ptr %slot315, align 8
  %v2575 = load i64, ptr %slot309, align 8
  %v2576 = load i64, ptr %slot314, align 8
  %op2577 = sub i64 %v2575, %v2576
  store i64 %op2577, ptr %slot316, align 8
  %v2578 = load i64, ptr %slot314, align 8
  %v2579 = load i64, ptr %slot309, align 8
  %op2580 = sub i64 %v2578, %v2579
  store i64 %op2580, ptr %slot317, align 8
  %v2581 = load i64, ptr %slot316, align 8
  %cmp2582 = icmp ult i64 %v2581, 8
  %cv2583 = zext i1 %cmp2582 to i32
  store i32 %cv2583, ptr %slot318, align 8
  %v2584 = load i64, ptr %slot317, align 8
  %cmp2585 = icmp ult i64 %v2584, 8
  %cv2586 = zext i1 %cmp2585 to i32
  store i32 %cv2586, ptr %slot319, align 8
  %v2587 = load i32, ptr %slot318, align 8
  %v2588 = load i32, ptr %slot319, align 8
  %op2589 = or i32 %v2587, %v2588
  store i32 %op2589, ptr %slot320, align 8
  %v2590 = load i32, ptr %slot320, align 8
  %cv2591 = zext i32 %v2590 to i64
  %cond2592 = icmp ne i64 %cv2591, 0
  br i1 %cond2592, label %bb_rcmoveslow416, label %bb_rcmovecheck416
bb_rcmovecheck416:
  %v2593 = load i64, ptr %slot309, align 8
  %p2595 = inttoptr i64 %v2593 to ptr
  %gep2596 = getelementptr i8, ptr %p2595, i64 0
  %op2594 = ptrtoint ptr %gep2596 to i64
  store i64 %op2594, ptr %slot321, align 8
  %v2597 = load i64, ptr %slot321, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  %ld2599 = load i64, ptr %p2598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2599, ptr %slot322, align 8
  %v2600 = load i64, ptr %slot322, align 8
  %cmp2601 = icmp ne i64 %v2600, 0
  %cv2602 = zext i1 %cmp2601 to i32
  store i32 %cv2602, ptr %slot323, align 8
  %v2603 = load i32, ptr %slot323, align 8
  %cv2604 = zext i32 %v2603 to i64
  %cond2605 = icmp ne i64 %cv2604, 0
  br i1 %cond2605, label %bb_rcmoveheader424, label %bb_rcmovenext424
bb_rcmoveheader424:
  %v2606 = load i64, ptr %slot322, align 8
  %op2607 = sub i64 %v2606, 16
  store i64 %op2607, ptr %slot324, align 8
  %v2608 = load i64, ptr %slot322, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  %rgep2610 = getelementptr i8, ptr %p2609, i64 -16
  %ld2611 = load i64, ptr %rgep2610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2611, ptr %slot325, align 8
  %v2612 = load i64, ptr %slot325, align 8
  %op2613 = and i64 %v2612, 5764607523034234881
  store i64 %op2613, ptr %slot326, align 8
  %v2614 = load i64, ptr %slot326, align 8
  %cmp2615 = icmp ne i64 %v2614, 0
  %cv2616 = zext i1 %cmp2615 to i32
  store i32 %cv2616, ptr %slot327, align 8
  %v2617 = load i32, ptr %slot327, align 8
  %cv2618 = zext i32 %v2617 to i64
  %cond2619 = icmp ne i64 %cv2618, 0
  br i1 %cond2619, label %bb_rcmoveslow416, label %bb_rcmovenext424
bb_rcmovenext424:
  %v2620 = load i64, ptr %slot309, align 8
  %v2621 = load i64, ptr %slot314, align 8
  %p2622 = inttoptr i64 %v2620 to ptr
  %p2623 = inttoptr i64 %v2621 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2623, ptr %p2622, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2624 = load i64, ptr %slot309, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  store i64 0, ptr %p2625, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved416
bb_rcmoveslow416:
  %v2626 = load i64, ptr %slot69, align 8
  %v2627 = load i64, ptr %slot314, align 8
  %v2628 = load i64, ptr %slot309, align 8
  %v2629 = load i64, ptr %slot315, align 8
  %cv2630 = trunc i64 %v2629 to i32
  %call2631 = call i32 @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_take(i64 %v2626, i64 %v2627, i64 %v2628, i32 %cv2630) nomerge, !dbg !130
  store i32 %call2631, ptr %slot328, align 8
  %v2632 = load i32, ptr %slot328, align 8
  %cv2633 = zext i32 %v2632 to i64
  %cond2634 = icmp ne i64 %cv2633, 0
  br i1 %cond2634, label %bb_rcsuccess431, label %bb_rcfailure431
bb_rcfailure431:
  %v2635 = load i64, ptr %slot69, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  %call2637 = call i32 @myl_rc_take_failure(ptr %p2636) nomerge, !dbg !130
  store i32 %call2637, ptr %slot329, align 8
  %v2638 = load i64, ptr %slot1, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  %v2640 = load i32, ptr %slot329, align 8
  %call2641 = call i32 @myl_qbe_rc_status(ptr %p2639, i32 %v2640) nomerge, !dbg !130
  store i32 %call2641, ptr %slot330, align 8
  br label %bb_failure
bb_rcsuccess431:
  br label %bb_rcmoved416
bb_rcmoved416:
  %v2642 = load i64, ptr %slot27, align 8
  %p2643 = inttoptr i64 %v2642 to ptr
  store i32 0, ptr %p2643, align 4, !alias.scope !3, !noalias !4
  %v2644 = load i64, ptr %slot30, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  store i32 2, ptr %p2645, align 4, !alias.scope !3, !noalias !4
  %v2646 = load i64, ptr %slot29, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  store i32 1, ptr %p2647, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared413
bb_rcprivateloan413:
  %v2648 = load i64, ptr %slot27, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %ld2650 = load i32, ptr %p2649, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2650, ptr %slot331, align 8
  %v2651 = load i64, ptr %slot28, align 8
  %p2652 = inttoptr i64 %v2651 to ptr
  %ld2653 = load i32, ptr %p2652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2653, ptr %slot332, align 8
  %v2654 = load i32, ptr %slot332, align 8
  %cmp2655 = icmp eq i32 %v2654, 16
  %cv2656 = zext i1 %cmp2655 to i32
  store i32 %cv2656, ptr %slot333, align 8
  %v2657 = load i32, ptr %slot333, align 8
  %v2658 = load i32, ptr %slot331, align 8
  %op2659 = and i32 %v2657, %v2658
  store i32 %op2659, ptr %slot333, align 8
  %v2660 = load i32, ptr %slot333, align 8
  %cv2661 = zext i32 %v2660 to i64
  %cond2662 = icmp ne i64 %cv2661, 0
  br i1 %cond2662, label %bb_rcprivatemove413, label %bb_rcprivatenew413
bb_rcprivatemove413:
  %v2663 = load i64, ptr %slot41, align 8
  store i64 %v2663, ptr %slot334, align 8
  %v2664 = load i64, ptr %slot309, align 8
  %v2665 = load i64, ptr %slot334, align 8
  %p2666 = inttoptr i64 %v2664 to ptr
  %p2667 = inttoptr i64 %v2665 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2667, ptr %p2666, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2668 = load i64, ptr %slot309, align 8
  %p2669 = inttoptr i64 %v2668 to ptr
  store i64 0, ptr %p2669, align 8, !alias.scope !3, !noalias !4
  %v2670 = load i64, ptr %slot30, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  store i32 2, ptr %p2671, align 4, !alias.scope !3, !noalias !4
  %v2672 = load i64, ptr %slot30, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  store i32 16, ptr %p2673, align 4, !alias.scope !3, !noalias !4
  %v2674 = load i64, ptr %slot29, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  store i32 1, ptr %p2675, align 4, !alias.scope !3, !noalias !4
  %v2676 = load i64, ptr %slot27, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i32 0, ptr %p2677, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared413
bb_rcprivatenew413:
  %v2678 = load i64, ptr %slot41, align 8
  store i64 %v2678, ptr %slot335, align 8
  %v2679 = load i64, ptr %slot309, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  %ld2681 = load i64, ptr %p2680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2681, ptr %slot336, align 8
  %v2682 = load i64, ptr %slot336, align 8
  %cmp2683 = icmp ne i64 %v2682, 0
  %cv2684 = zext i1 %cmp2683 to i32
  store i32 %cv2684, ptr %slot337, align 8
  %v2685 = load i32, ptr %slot337, align 8
  %cv2686 = zext i32 %v2685 to i64
  %cond2687 = icmp ne i64 %cv2686, 0
  br i1 %cond2687, label %bb_rcgnn449, label %bb_rcgstore449
bb_rcgnn449:
  %v2688 = load i64, ptr %slot336, align 8
  %op2689 = sub i64 %v2688, 16
  store i64 %op2689, ptr %slot338, align 8
  %v2690 = load i64, ptr %slot336, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %rgep2692 = getelementptr i8, ptr %p2691, i64 -16
  %ld2693 = load i64, ptr %rgep2692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2693, ptr %slot339, align 8
  %v2694 = load i64, ptr %slot339, align 8
  %op2695 = and i64 %v2694, 4611686018427387906
  store i64 %op2695, ptr %slot340, align 8
  %v2696 = load i64, ptr %slot340, align 8
  %cmp2697 = icmp ne i64 %v2696, 0
  %cv2698 = zext i1 %cmp2697 to i32
  store i32 %cv2698, ptr %slot341, align 8
  %v2699 = load i32, ptr %slot341, align 8
  %cv2700 = zext i32 %v2699 to i64
  %cond2701 = icmp ne i64 %cv2700, 0
  br i1 %cond2701, label %bb_rcgstore449, label %bb_rcginc449
bb_rcginc449:
  %v2702 = load i64, ptr %slot336, align 8
  %op2703 = sub i64 %v2702, 24
  store i64 %op2703, ptr %slot342, align 8
  %v2704 = load i64, ptr %slot336, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  %rgep2706 = getelementptr i8, ptr %p2705, i64 -24
  %ld2707 = load i64, ptr %rgep2706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2707, ptr %slot343, align 8
  %v2708 = load i64, ptr %slot343, align 8
  %op2709 = add i64 %v2708, 1
  store i64 %op2709, ptr %slot344, align 8
  %v2710 = load i64, ptr %slot344, align 8
  %cmp2711 = icmp eq i64 %v2710, 0
  %cv2712 = zext i1 %cmp2711 to i32
  store i32 %cv2712, ptr %slot345, align 8
  %v2713 = load i32, ptr %slot345, align 8
  %cv2714 = zext i32 %v2713 to i64
  %cond2715 = icmp ne i64 %cv2714, 0
  br i1 %cond2715, label %bb_rcglimit449, label %bb_rcgcapacity449
bb_rcglimit449:
  %v2716 = load i64, ptr %slot1, align 8
  %p2717 = inttoptr i64 %v2716 to ptr
  %call2718 = call i32 @myl_qbe_rc_status(ptr %p2717, i32 2) nomerge, !dbg !130
  store i32 %call2718, ptr %slot346, align 8
  br label %bb_failure
bb_rcgcapacity449:
  %v2719 = load i64, ptr %slot344, align 8
  %v2720 = load i64, ptr %slot336, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  %rgep2722 = getelementptr i8, ptr %p2721, i64 -24
  store i64 %v2719, ptr %rgep2722, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore449
bb_rcgstore449:
  %v2723 = load i64, ptr %slot336, align 8
  %v2724 = load i64, ptr %slot335, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  store i64 %v2723, ptr %p2725, align 8, !alias.scope !3, !noalias !4
  %v2726 = load i64, ptr %slot30, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i32 2, ptr %p2727, align 4, !alias.scope !3, !noalias !4
  %v2728 = load i64, ptr %slot30, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  store i32 16, ptr %p2729, align 4, !alias.scope !3, !noalias !4
  %v2730 = load i64, ptr %slot29, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  store i32 1, ptr %p2731, align 4, !alias.scope !3, !noalias !4
  %v2732 = load i64, ptr %slot27, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  %ld2734 = load i32, ptr %p2733, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2734, ptr %slot347, align 8
  %v2735 = load i32, ptr %slot347, align 8
  %cv2736 = zext i32 %v2735 to i64
  %cond2737 = icmp ne i64 %cv2736, 0
  br i1 %cond2737, label %bb_rcslotdrop465, label %bb_rcslotdone465
bb_rcslotdrop465:
  %v2738 = load i64, ptr %slot27, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  store i32 0, ptr %p2739, align 4, !alias.scope !3, !noalias !4
  %v2740 = load i64, ptr %slot36, align 8
  store i64 %v2740, ptr %slot348, align 8
  %v2741 = load i64, ptr %slot28, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  %ld2743 = load i32, ptr %p2742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2743, ptr %slot349, align 8
  %v2744 = load i32, ptr %slot349, align 8
  %op2745 = and i32 %v2744, 28
  store i32 %op2745, ptr %slot350, align 8
  %v2746 = load i32, ptr %slot350, align 8
  %cv2747 = zext i32 %v2746 to i64
  %cond2748 = icmp ne i64 %cv2747, 0
  br i1 %cond2748, label %bb_rcslotrole465, label %bb_rcslotowner465
bb_rcslotrole465:
  %v2749 = load i64, ptr %slot69, align 8
  store i64 %v2749, ptr %slot351, align 8
  %v2750 = load i64, ptr %slot348, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  %ld2752 = load i64, ptr %p2751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2752, ptr %slot352, align 8
  %v2753 = load i64, ptr %slot352, align 8
  %cmp2754 = icmp ne i64 %v2753, 0
  %cv2755 = zext i1 %cmp2754 to i32
  store i32 %cv2755, ptr %slot353, align 8
  %v2756 = load i32, ptr %slot353, align 8
  %cv2757 = zext i32 %v2756 to i64
  %cond2758 = icmp ne i64 %cv2757, 0
  br i1 %cond2758, label %bb_rcgnn481, label %bb_rcgdone481
bb_rcgnn481:
  %v2759 = load i64, ptr %slot352, align 8
  %op2760 = sub i64 %v2759, 16
  store i64 %op2760, ptr %slot354, align 8
  %v2761 = load i64, ptr %slot352, align 8
  %p2762 = inttoptr i64 %v2761 to ptr
  %rgep2763 = getelementptr i8, ptr %p2762, i64 -16
  %ld2764 = load i64, ptr %rgep2763, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2764, ptr %slot355, align 8
  %v2765 = load i64, ptr %slot355, align 8
  %op2766 = and i64 %v2765, 4611686018427387906
  store i64 %op2766, ptr %slot356, align 8
  %v2767 = load i64, ptr %slot356, align 8
  %cmp2768 = icmp ne i64 %v2767, 0
  %cv2769 = zext i1 %cmp2768 to i32
  store i32 %cv2769, ptr %slot357, align 8
  %v2770 = load i32, ptr %slot357, align 8
  %cv2771 = zext i32 %v2770 to i64
  %cond2772 = icmp ne i64 %cv2771, 0
  br i1 %cond2772, label %bb_rcgclear481, label %bb_rcgcounted481
bb_rcgcounted481:
  %v2773 = load i64, ptr %slot352, align 8
  %op2774 = sub i64 %v2773, 24
  store i64 %op2774, ptr %slot358, align 8
  %v2775 = load i64, ptr %slot352, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  %rgep2777 = getelementptr i8, ptr %p2776, i64 -24
  %ld2778 = load i64, ptr %rgep2777, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2778, ptr %slot359, align 8
  %v2779 = load i64, ptr %slot359, align 8
  %op2780 = sub i64 %v2779, 1
  store i64 %op2780, ptr %slot360, align 8
  %v2781 = load i64, ptr %slot360, align 8
  %cmp2782 = icmp eq i64 %v2781, 0
  %cv2783 = zext i1 %cmp2782 to i32
  store i32 %cv2783, ptr %slot361, align 8
  %v2784 = load i32, ptr %slot361, align 8
  %cv2785 = zext i32 %v2784 to i64
  %cond2786 = icmp ne i64 %cv2785, 0
  br i1 %cond2786, label %bb_rcglast481, label %bb_rcgdec481
bb_rcglast481:
  %v2787 = load i64, ptr %slot352, align 8
  %op2788 = sub i64 %v2787, 32
  store i64 %op2788, ptr %slot362, align 8
  %v2789 = load i64, ptr %slot352, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  %rgep2791 = getelementptr i8, ptr %p2790, i64 -32
  %ld2792 = load i64, ptr %rgep2791, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2792, ptr %slot363, align 8
  %v2793 = load i64, ptr %slot363, align 8
  %cmp2794 = icmp ne i64 %v2793, 0
  %cv2795 = zext i1 %cmp2794 to i32
  store i32 %cv2795, ptr %slot364, align 8
  %v2796 = load i32, ptr %slot364, align 8
  %cv2797 = zext i32 %v2796 to i64
  %cond2798 = icmp ne i64 %cv2797, 0
  br i1 %cond2798, label %bb_rcgdec481, label %bb_rcgslow481
bb_rcgslow481:
  %v2799 = load i64, ptr %slot351, align 8
  %v2800 = load i64, ptr %slot348, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_unloan(i64 %v2799, i64 %v2800) nomerge, !dbg !130
  br label %bb_rcgdone481
bb_rcgdec481:
  %v2801 = load i64, ptr %slot360, align 8
  %v2802 = load i64, ptr %slot352, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  %rgep2804 = getelementptr i8, ptr %p2803, i64 -24
  store i64 %v2801, ptr %rgep2804, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear481
bb_rcgclear481:
  %v2805 = load i64, ptr %slot348, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  store i64 0, ptr %p2806, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone481
bb_rcgdone481:
  br label %bb_rcslotdone465
bb_rcslotowner465:
  %v2807 = load i64, ptr %slot69, align 8
  store i64 %v2807, ptr %slot365, align 8
  %v2808 = load i64, ptr %slot348, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  %ld2810 = load i64, ptr %p2809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2810, ptr %slot366, align 8
  %v2811 = load i64, ptr %slot366, align 8
  %cmp2812 = icmp ne i64 %v2811, 0
  %cv2813 = zext i1 %cmp2812 to i32
  store i32 %cv2813, ptr %slot367, align 8
  %v2814 = load i32, ptr %slot367, align 8
  %cv2815 = zext i32 %v2814 to i64
  %cond2816 = icmp ne i64 %cv2815, 0
  br i1 %cond2816, label %bb_rcgnn496, label %bb_rcgdone496
bb_rcgnn496:
  %v2817 = load i64, ptr %slot366, align 8
  %op2818 = sub i64 %v2817, 16
  store i64 %op2818, ptr %slot368, align 8
  %v2819 = load i64, ptr %slot366, align 8
  %p2820 = inttoptr i64 %v2819 to ptr
  %rgep2821 = getelementptr i8, ptr %p2820, i64 -16
  %ld2822 = load i64, ptr %rgep2821, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2822, ptr %slot369, align 8
  %v2823 = load i64, ptr %slot369, align 8
  %op2824 = and i64 %v2823, 4611686018427387906
  store i64 %op2824, ptr %slot370, align 8
  %v2825 = load i64, ptr %slot370, align 8
  %cmp2826 = icmp ne i64 %v2825, 0
  %cv2827 = zext i1 %cmp2826 to i32
  store i32 %cv2827, ptr %slot371, align 8
  %v2828 = load i32, ptr %slot371, align 8
  %cv2829 = zext i32 %v2828 to i64
  %cond2830 = icmp ne i64 %cv2829, 0
  br i1 %cond2830, label %bb_rcgclear496, label %bb_rcgcounted496
bb_rcgcounted496:
  %v2831 = load i64, ptr %slot366, align 8
  %op2832 = sub i64 %v2831, 32
  store i64 %op2832, ptr %slot372, align 8
  %v2833 = load i64, ptr %slot366, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  %rgep2835 = getelementptr i8, ptr %p2834, i64 -32
  %ld2836 = load i64, ptr %rgep2835, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2836, ptr %slot373, align 8
  %v2837 = load i64, ptr %slot373, align 8
  %op2838 = sub i64 %v2837, 1
  store i64 %op2838, ptr %slot374, align 8
  %v2839 = load i64, ptr %slot374, align 8
  %cmp2840 = icmp eq i64 %v2839, 0
  %cv2841 = zext i1 %cmp2840 to i32
  store i32 %cv2841, ptr %slot375, align 8
  %v2842 = load i32, ptr %slot375, align 8
  %cv2843 = zext i32 %v2842 to i64
  %cond2844 = icmp ne i64 %cv2843, 0
  br i1 %cond2844, label %bb_rcglast496, label %bb_rcgdec496
bb_rcglast496:
  %v2845 = load i64, ptr %slot366, align 8
  %op2846 = sub i64 %v2845, 24
  store i64 %op2846, ptr %slot376, align 8
  %v2847 = load i64, ptr %slot366, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %rgep2849 = getelementptr i8, ptr %p2848, i64 -24
  %ld2850 = load i64, ptr %rgep2849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2850, ptr %slot377, align 8
  %v2851 = load i64, ptr %slot377, align 8
  %cmp2852 = icmp ne i64 %v2851, 0
  %cv2853 = zext i1 %cmp2852 to i32
  store i32 %cv2853, ptr %slot378, align 8
  %v2854 = load i32, ptr %slot378, align 8
  %cv2855 = zext i32 %v2854 to i64
  %cond2856 = icmp ne i64 %cv2855, 0
  br i1 %cond2856, label %bb_rcgdec496, label %bb_rcgslow496
bb_rcgslow496:
  %v2857 = load i64, ptr %slot365, align 8
  %v2858 = load i64, ptr %slot348, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_drop(i64 %v2857, i64 %v2858) nomerge, !dbg !130
  br label %bb_rcgdone496
bb_rcgdec496:
  %v2859 = load i64, ptr %slot374, align 8
  %v2860 = load i64, ptr %slot366, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  %rgep2862 = getelementptr i8, ptr %p2861, i64 -32
  store i64 %v2859, ptr %rgep2862, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear496
bb_rcgclear496:
  %v2863 = load i64, ptr %slot348, align 8
  %p2864 = inttoptr i64 %v2863 to ptr
  store i64 0, ptr %p2864, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone496
bb_rcgdone496:
  br label %bb_rcslotdone465
bb_rcslotdone465:
  br label %bb_rcprivateprepared413
bb_rcprivateprepared413:
  %v2865 = load i64, ptr %slot10, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  %ld2867 = load i32, ptr %p2866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2867, ptr %slot379, align 8
  %v2868 = load i32, ptr %slot379, align 8
  %cv2869 = zext i32 %v2868 to i64
  %cond2870 = icmp ne i64 %cv2869, 0
  br i1 %cond2870, label %bb_rcslotdrop503, label %bb_rcslotdone503
bb_rcslotdrop503:
  %v2871 = load i64, ptr %slot10, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  store i32 0, ptr %p2872, align 4, !alias.scope !3, !noalias !4
  %v2873 = load i64, ptr %slot47, align 8
  store i64 %v2873, ptr %slot380, align 8
  %v2874 = load i64, ptr %slot11, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  %ld2876 = load i32, ptr %p2875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2876, ptr %slot381, align 8
  %v2877 = load i32, ptr %slot381, align 8
  %op2878 = and i32 %v2877, 28
  store i32 %op2878, ptr %slot382, align 8
  %v2879 = load i32, ptr %slot382, align 8
  %cv2880 = zext i32 %v2879 to i64
  %cond2881 = icmp ne i64 %cv2880, 0
  br i1 %cond2881, label %bb_rcslotrole503, label %bb_rcslotowner503
bb_rcslotrole503:
  %v2882 = load i64, ptr %slot69, align 8
  store i64 %v2882, ptr %slot383, align 8
  %v2883 = load i64, ptr %slot380, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  %ld2885 = load i64, ptr %p2884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2885, ptr %slot384, align 8
  %v2886 = load i64, ptr %slot384, align 8
  %cmp2887 = icmp ne i64 %v2886, 0
  %cv2888 = zext i1 %cmp2887 to i32
  store i32 %cv2888, ptr %slot385, align 8
  %v2889 = load i32, ptr %slot385, align 8
  %cv2890 = zext i32 %v2889 to i64
  %cond2891 = icmp ne i64 %cv2890, 0
  br i1 %cond2891, label %bb_rcgnn519, label %bb_rcgdone519
bb_rcgnn519:
  %v2892 = load i64, ptr %slot384, align 8
  %op2893 = sub i64 %v2892, 16
  store i64 %op2893, ptr %slot386, align 8
  %v2894 = load i64, ptr %slot384, align 8
  %p2895 = inttoptr i64 %v2894 to ptr
  %rgep2896 = getelementptr i8, ptr %p2895, i64 -16
  %ld2897 = load i64, ptr %rgep2896, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2897, ptr %slot387, align 8
  %v2898 = load i64, ptr %slot387, align 8
  %op2899 = and i64 %v2898, 4611686018427387906
  store i64 %op2899, ptr %slot388, align 8
  %v2900 = load i64, ptr %slot388, align 8
  %cmp2901 = icmp ne i64 %v2900, 0
  %cv2902 = zext i1 %cmp2901 to i32
  store i32 %cv2902, ptr %slot389, align 8
  %v2903 = load i32, ptr %slot389, align 8
  %cv2904 = zext i32 %v2903 to i64
  %cond2905 = icmp ne i64 %cv2904, 0
  br i1 %cond2905, label %bb_rcgclear519, label %bb_rcgcounted519
bb_rcgcounted519:
  %v2906 = load i64, ptr %slot384, align 8
  %op2907 = sub i64 %v2906, 24
  store i64 %op2907, ptr %slot390, align 8
  %v2908 = load i64, ptr %slot384, align 8
  %p2909 = inttoptr i64 %v2908 to ptr
  %rgep2910 = getelementptr i8, ptr %p2909, i64 -24
  %ld2911 = load i64, ptr %rgep2910, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2911, ptr %slot391, align 8
  %v2912 = load i64, ptr %slot391, align 8
  %op2913 = sub i64 %v2912, 1
  store i64 %op2913, ptr %slot392, align 8
  %v2914 = load i64, ptr %slot392, align 8
  %cmp2915 = icmp eq i64 %v2914, 0
  %cv2916 = zext i1 %cmp2915 to i32
  store i32 %cv2916, ptr %slot393, align 8
  %v2917 = load i32, ptr %slot393, align 8
  %cv2918 = zext i32 %v2917 to i64
  %cond2919 = icmp ne i64 %cv2918, 0
  br i1 %cond2919, label %bb_rcglast519, label %bb_rcgdec519
bb_rcglast519:
  %v2920 = load i64, ptr %slot384, align 8
  %op2921 = sub i64 %v2920, 32
  store i64 %op2921, ptr %slot394, align 8
  %v2922 = load i64, ptr %slot384, align 8
  %p2923 = inttoptr i64 %v2922 to ptr
  %rgep2924 = getelementptr i8, ptr %p2923, i64 -32
  %ld2925 = load i64, ptr %rgep2924, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2925, ptr %slot395, align 8
  %v2926 = load i64, ptr %slot395, align 8
  %cmp2927 = icmp ne i64 %v2926, 0
  %cv2928 = zext i1 %cmp2927 to i32
  store i32 %cv2928, ptr %slot396, align 8
  %v2929 = load i32, ptr %slot396, align 8
  %cv2930 = zext i32 %v2929 to i64
  %cond2931 = icmp ne i64 %cv2930, 0
  br i1 %cond2931, label %bb_rcgdec519, label %bb_rcgslow519
bb_rcgslow519:
  %v2932 = load i64, ptr %slot383, align 8
  %v2933 = load i64, ptr %slot380, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_unloan(i64 %v2932, i64 %v2933) nomerge, !dbg !130
  br label %bb_rcgdone519
bb_rcgdec519:
  %v2934 = load i64, ptr %slot392, align 8
  %v2935 = load i64, ptr %slot384, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  %rgep2937 = getelementptr i8, ptr %p2936, i64 -24
  store i64 %v2934, ptr %rgep2937, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear519
bb_rcgclear519:
  %v2938 = load i64, ptr %slot380, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  store i64 0, ptr %p2939, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone519
bb_rcgdone519:
  br label %bb_rcslotdone503
bb_rcslotowner503:
  %v2940 = load i64, ptr %slot69, align 8
  store i64 %v2940, ptr %slot397, align 8
  %v2941 = load i64, ptr %slot380, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  %ld2943 = load i64, ptr %p2942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2943, ptr %slot398, align 8
  %v2944 = load i64, ptr %slot398, align 8
  %cmp2945 = icmp ne i64 %v2944, 0
  %cv2946 = zext i1 %cmp2945 to i32
  store i32 %cv2946, ptr %slot399, align 8
  %v2947 = load i32, ptr %slot399, align 8
  %cv2948 = zext i32 %v2947 to i64
  %cond2949 = icmp ne i64 %cv2948, 0
  br i1 %cond2949, label %bb_rcgnn534, label %bb_rcgdone534
bb_rcgnn534:
  %v2950 = load i64, ptr %slot398, align 8
  %op2951 = sub i64 %v2950, 16
  store i64 %op2951, ptr %slot400, align 8
  %v2952 = load i64, ptr %slot398, align 8
  %p2953 = inttoptr i64 %v2952 to ptr
  %rgep2954 = getelementptr i8, ptr %p2953, i64 -16
  %ld2955 = load i64, ptr %rgep2954, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2955, ptr %slot401, align 8
  %v2956 = load i64, ptr %slot401, align 8
  %op2957 = and i64 %v2956, 4611686018427387906
  store i64 %op2957, ptr %slot402, align 8
  %v2958 = load i64, ptr %slot402, align 8
  %cmp2959 = icmp ne i64 %v2958, 0
  %cv2960 = zext i1 %cmp2959 to i32
  store i32 %cv2960, ptr %slot403, align 8
  %v2961 = load i32, ptr %slot403, align 8
  %cv2962 = zext i32 %v2961 to i64
  %cond2963 = icmp ne i64 %cv2962, 0
  br i1 %cond2963, label %bb_rcgclear534, label %bb_rcgcounted534
bb_rcgcounted534:
  %v2964 = load i64, ptr %slot398, align 8
  %op2965 = sub i64 %v2964, 32
  store i64 %op2965, ptr %slot404, align 8
  %v2966 = load i64, ptr %slot398, align 8
  %p2967 = inttoptr i64 %v2966 to ptr
  %rgep2968 = getelementptr i8, ptr %p2967, i64 -32
  %ld2969 = load i64, ptr %rgep2968, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2969, ptr %slot405, align 8
  %v2970 = load i64, ptr %slot405, align 8
  %op2971 = sub i64 %v2970, 1
  store i64 %op2971, ptr %slot406, align 8
  %v2972 = load i64, ptr %slot406, align 8
  %cmp2973 = icmp eq i64 %v2972, 0
  %cv2974 = zext i1 %cmp2973 to i32
  store i32 %cv2974, ptr %slot407, align 8
  %v2975 = load i32, ptr %slot407, align 8
  %cv2976 = zext i32 %v2975 to i64
  %cond2977 = icmp ne i64 %cv2976, 0
  br i1 %cond2977, label %bb_rcglast534, label %bb_rcgdec534
bb_rcglast534:
  %v2978 = load i64, ptr %slot398, align 8
  %op2979 = sub i64 %v2978, 24
  store i64 %op2979, ptr %slot408, align 8
  %v2980 = load i64, ptr %slot398, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  %rgep2982 = getelementptr i8, ptr %p2981, i64 -24
  %ld2983 = load i64, ptr %rgep2982, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2983, ptr %slot409, align 8
  %v2984 = load i64, ptr %slot409, align 8
  %cmp2985 = icmp ne i64 %v2984, 0
  %cv2986 = zext i1 %cmp2985 to i32
  store i32 %cv2986, ptr %slot410, align 8
  %v2987 = load i32, ptr %slot410, align 8
  %cv2988 = zext i32 %v2987 to i64
  %cond2989 = icmp ne i64 %cv2988, 0
  br i1 %cond2989, label %bb_rcgdec534, label %bb_rcgslow534
bb_rcgslow534:
  %v2990 = load i64, ptr %slot397, align 8
  %v2991 = load i64, ptr %slot380, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_drop(i64 %v2990, i64 %v2991) nomerge, !dbg !130
  br label %bb_rcgdone534
bb_rcgdec534:
  %v2992 = load i64, ptr %slot406, align 8
  %v2993 = load i64, ptr %slot398, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  %rgep2995 = getelementptr i8, ptr %p2994, i64 -32
  store i64 %v2992, ptr %rgep2995, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear534
bb_rcgclear534:
  %v2996 = load i64, ptr %slot380, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  store i64 0, ptr %p2997, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone534
bb_rcgdone534:
  br label %bb_rcslotdone503
bb_rcslotdone503:
  %v2998 = load i64, ptr %slot47, align 8
  store i64 %v2998, ptr %slot411, align 8
  %v2999 = load i64, ptr %slot41, align 8
  store i64 %v2999, ptr %slot412, align 8
  %v3000 = load i64, ptr %slot412, align 8
  %v3001 = load i64, ptr %slot411, align 8
  %p3002 = inttoptr i64 %v3000 to ptr
  %p3003 = inttoptr i64 %v3001 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3003, ptr %p3002, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3004 = load i64, ptr %slot29, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  store i32 0, ptr %p3005, align 4, !alias.scope !3, !noalias !4
  %v3006 = load i64, ptr %slot11, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i32 2, ptr %p3007, align 4, !alias.scope !3, !noalias !4
  %v3008 = load i64, ptr %slot30, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  %ld3010 = load i32, ptr %p3009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3010, ptr %slot413, align 8
  %v3011 = load i32, ptr %slot413, align 8
  %v3012 = load i64, ptr %slot11, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  store i32 %v3011, ptr %p3013, align 4, !alias.scope !3, !noalias !4
  %v3014 = load i64, ptr %slot10, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  store i32 1, ptr %p3015, align 4, !alias.scope !3, !noalias !4
  %v3016 = load i64, ptr %slot47, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  %ld3018 = load i64, ptr %p3017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3018, ptr %slot414, align 8
  %v3019 = load i64, ptr %slot414, align 8
  %v3020 = load i64, ptr %slot59, align 8
  %p3021 = inttoptr i64 %v3020 to ptr
  store i64 %v3019, ptr %p3021, align 8, !alias.scope !3, !noalias !4
  %v3022 = load i64, ptr %slot62, align 8
  store i64 %v3022, ptr %slot415, align 8
  %v3023 = load i64, ptr %slot415, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  call void @llvm.memset.p0.i64(ptr %p3024, i8 0, i64 392, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v3025 = load i64, ptr %slot31, align 8
  %p3026 = inttoptr i64 %v3025 to ptr
  store i32 1, ptr %p3026, align 4, !alias.scope !3, !noalias !4
  %v3027 = load i64, ptr %slot70, align 8
  store i64 %v3027, ptr %slot416, align 8
  %v3028 = load i64, ptr %slot50, align 8
  %p3029 = inttoptr i64 %v3028 to ptr
  %ld3030 = load i64, ptr %p3029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3030, ptr %slot417, align 8
  %v3031 = load i64, ptr %slot415, align 8
  %p3033 = inttoptr i64 %v3031 to ptr
  %gep3034 = getelementptr i8, ptr %p3033, i64 0
  %op3032 = ptrtoint ptr %gep3034 to i64
  store i64 %op3032, ptr %slot418, align 8
  %v3035 = load i64, ptr %slot50, align 8
  %p3036 = inttoptr i64 %v3035 to ptr
  %ld3037 = load i64, ptr %p3036, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3037, ptr %slot419, align 8
  %v3038 = load i64, ptr %slot16, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  %ld3040 = load i32, ptr %p3039, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3040, ptr %slot420, align 8
  %v3041 = load i64, ptr %slot17, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  %ld3043 = load i32, ptr %p3042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3043, ptr %slot421, align 8
  %v3044 = load i32, ptr %slot421, align 8
  %op3045 = and i32 %v3044, 24
  store i32 %op3045, ptr %slot421, align 8
  %v3046 = load i32, ptr %slot421, align 8
  %cmp3047 = icmp eq i32 %v3046, 0
  %cv3048 = zext i1 %cmp3047 to i32
  store i32 %cv3048, ptr %slot422, align 8
  %v3049 = load i32, ptr %slot420, align 8
  %v3050 = load i32, ptr %slot422, align 8
  %op3051 = and i32 %v3049, %v3050
  store i32 %op3051, ptr %slot423, align 8
  %v3052 = load i32, ptr %slot423, align 8
  %cv3053 = zext i32 %v3052 to i64
  %cond3054 = icmp ne i64 %cv3053, 0
  br i1 %cond3054, label %bb_rctake553, label %bb_rccopy553
bb_rctake553:
  %v3055 = load i64, ptr %slot41, align 8
  store i64 %v3055, ptr %slot424, align 8
  %v3056 = load i64, ptr %slot70, align 8
  store i64 %v3056, ptr %slot425, align 8
  %v3057 = load i64, ptr %slot69, align 8
  %v3058 = load i64, ptr %slot424, align 8
  %v3059 = load i64, ptr %slot419, align 8
  %v3060 = load i64, ptr %slot425, align 8
  %cv3061 = trunc i64 %v3060 to i32
  %call3062 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64 %v3057, i64 %v3058, i64 %v3059, i32 %cv3061) nomerge, !dbg !132
  store i32 %call3062, ptr %slot426, align 8
  %v3063 = load i32, ptr %slot426, align 8
  %cv3064 = zext i32 %v3063 to i64
  %cond3065 = icmp ne i64 %cv3064, 0
  br i1 %cond3065, label %bb_rcsuccess563, label %bb_rcfailure563
bb_rcfailure563:
  %v3066 = load i64, ptr %slot69, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  %call3068 = call i32 @myl_rc_take_failure(ptr %p3067) nomerge, !dbg !132
  store i32 %call3068, ptr %slot427, align 8
  %v3069 = load i64, ptr %slot1, align 8
  %p3070 = inttoptr i64 %v3069 to ptr
  %v3071 = load i32, ptr %slot427, align 8
  %call3072 = call i32 @myl_qbe_rc_status(ptr %p3070, i32 %v3071) nomerge, !dbg !132
  store i32 %call3072, ptr %slot428, align 8
  br label %bb_failure
bb_rcsuccess563:
  %v3073 = load i64, ptr %slot16, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  store i32 0, ptr %p3074, align 4, !alias.scope !3, !noalias !4
  %v3075 = load i64, ptr %slot30, align 8
  %p3076 = inttoptr i64 %v3075 to ptr
  store i32 2, ptr %p3076, align 4, !alias.scope !3, !noalias !4
  %v3077 = load i64, ptr %slot29, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  store i32 1, ptr %p3078, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared553
bb_rccopy553:
  %v3079 = load i64, ptr %slot41, align 8
  store i64 %v3079, ptr %slot429, align 8
  %v3080 = load i64, ptr %slot70, align 8
  store i64 %v3080, ptr %slot430, align 8
  %v3081 = load i64, ptr %slot69, align 8
  %v3082 = load i64, ptr %slot429, align 8
  %v3083 = load i64, ptr %slot419, align 8
  %v3084 = load i64, ptr %slot430, align 8
  %cv3085 = trunc i64 %v3084 to i32
  %call3086 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_retain(i64 %v3081, i64 %v3082, i64 %v3083, i32 %cv3085) nomerge, !dbg !132
  store i32 %call3086, ptr %slot431, align 8
  %v3087 = load i32, ptr %slot431, align 8
  %cv3088 = zext i32 %v3087 to i64
  %cond3089 = icmp ne i64 %cv3088, 0
  br i1 %cond3089, label %bb_rcsuccess572, label %bb_rcfailure572
bb_rcfailure572:
  %v3090 = load i64, ptr %slot69, align 8
  %p3091 = inttoptr i64 %v3090 to ptr
  %call3092 = call i32 @myl_rc_take_failure(ptr %p3091) nomerge, !dbg !132
  store i32 %call3092, ptr %slot432, align 8
  %v3093 = load i64, ptr %slot1, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  %v3095 = load i32, ptr %slot432, align 8
  %call3096 = call i32 @myl_qbe_rc_status(ptr %p3094, i32 %v3095) nomerge, !dbg !132
  store i32 %call3096, ptr %slot433, align 8
  br label %bb_failure
bb_rcsuccess572:
  %v3097 = load i64, ptr %slot30, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  store i32 2, ptr %p3098, align 4, !alias.scope !3, !noalias !4
  %v3099 = load i64, ptr %slot29, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  store i32 1, ptr %p3100, align 4, !alias.scope !3, !noalias !4
  %v3101 = load i64, ptr %slot16, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %ld3103 = load i32, ptr %p3102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3103, ptr %slot434, align 8
  %v3104 = load i32, ptr %slot434, align 8
  %cv3105 = zext i32 %v3104 to i64
  %cond3106 = icmp ne i64 %cv3105, 0
  br i1 %cond3106, label %bb_rcslotdrop579, label %bb_rcslotdone579
bb_rcslotdrop579:
  %v3107 = load i64, ptr %slot16, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  store i32 0, ptr %p3108, align 4, !alias.scope !3, !noalias !4
  %v3109 = load i64, ptr %slot32, align 8
  store i64 %v3109, ptr %slot435, align 8
  %v3110 = load i64, ptr %slot17, align 8
  %p3111 = inttoptr i64 %v3110 to ptr
  %ld3112 = load i32, ptr %p3111, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3112, ptr %slot436, align 8
  %v3113 = load i32, ptr %slot436, align 8
  %op3114 = and i32 %v3113, 28
  store i32 %op3114, ptr %slot437, align 8
  %v3115 = load i32, ptr %slot437, align 8
  %cv3116 = zext i32 %v3115 to i64
  %cond3117 = icmp ne i64 %cv3116, 0
  br i1 %cond3117, label %bb_rcslotrole579, label %bb_rcslotowner579
bb_rcslotrole579:
  %v3118 = load i64, ptr %slot69, align 8
  store i64 %v3118, ptr %slot438, align 8
  %v3119 = load i64, ptr %slot438, align 8
  %v3120 = load i64, ptr %slot435, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3119, i64 %v3120) nomerge, !dbg !132
  br label %bb_rcslotdone579
bb_rcslotowner579:
  %v3121 = load i64, ptr %slot69, align 8
  store i64 %v3121, ptr %slot439, align 8
  %v3122 = load i64, ptr %slot439, align 8
  %v3123 = load i64, ptr %slot435, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3122, i64 %v3123) nomerge, !dbg !132
  br label %bb_rcslotdone579
bb_rcslotdone579:
  br label %bb_rcprepared553
bb_rcprepared553:
  %v3124 = load i64, ptr %slot41, align 8
  store i64 %v3124, ptr %slot440, align 8
  %v3125 = load i64, ptr %slot440, align 8
  %v3126 = load i64, ptr %slot418, align 8
  %p3127 = inttoptr i64 %v3125 to ptr
  %p3128 = inttoptr i64 %v3126 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3128, ptr %p3127, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v3129 = load i64, ptr %slot29, align 8
  %p3130 = inttoptr i64 %v3129 to ptr
  store i32 0, ptr %p3130, align 4, !alias.scope !3, !noalias !4
  %v3131 = load i64, ptr %slot51, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  %ld3133 = load i64, ptr %p3132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3133, ptr %slot441, align 8
  %v3134 = load i64, ptr %slot415, align 8
  %p3136 = inttoptr i64 %v3134 to ptr
  %gep3137 = getelementptr i8, ptr %p3136, i64 208
  %op3135 = ptrtoint ptr %gep3137 to i64
  store i64 %op3135, ptr %slot442, align 8
  %v3138 = load i64, ptr %slot51, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  %ld3140 = load i64, ptr %p3139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3140, ptr %slot443, align 8
  %v3141 = load i64, ptr %slot18, align 8
  %p3142 = inttoptr i64 %v3141 to ptr
  %ld3143 = load i32, ptr %p3142, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3143, ptr %slot444, align 8
  %v3144 = load i64, ptr %slot19, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  %ld3146 = load i32, ptr %p3145, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3146, ptr %slot445, align 8
  %v3147 = load i32, ptr %slot445, align 8
  %op3148 = and i32 %v3147, 24
  store i32 %op3148, ptr %slot445, align 8
  %v3149 = load i32, ptr %slot445, align 8
  %cmp3150 = icmp eq i32 %v3149, 0
  %cv3151 = zext i1 %cmp3150 to i32
  store i32 %cv3151, ptr %slot446, align 8
  %v3152 = load i32, ptr %slot444, align 8
  %v3153 = load i32, ptr %slot446, align 8
  %op3154 = and i32 %v3152, %v3153
  store i32 %op3154, ptr %slot447, align 8
  %v3155 = load i32, ptr %slot447, align 8
  %cv3156 = zext i32 %v3155 to i64
  %cond3157 = icmp ne i64 %cv3156, 0
  br i1 %cond3157, label %bb_rctake591, label %bb_rccopy591
bb_rctake591:
  %v3158 = load i64, ptr %slot41, align 8
  store i64 %v3158, ptr %slot448, align 8
  %v3159 = load i64, ptr %slot70, align 8
  store i64 %v3159, ptr %slot449, align 8
  %v3160 = load i64, ptr %slot443, align 8
  %v3161 = load i64, ptr %slot448, align 8
  %op3162 = sub i64 %v3160, %v3161
  store i64 %op3162, ptr %slot450, align 8
  %v3163 = load i64, ptr %slot448, align 8
  %v3164 = load i64, ptr %slot443, align 8
  %op3165 = sub i64 %v3163, %v3164
  store i64 %op3165, ptr %slot451, align 8
  %v3166 = load i64, ptr %slot450, align 8
  %cmp3167 = icmp ult i64 %v3166, 40
  %cv3168 = zext i1 %cmp3167 to i32
  store i32 %cv3168, ptr %slot452, align 8
  %v3169 = load i64, ptr %slot451, align 8
  %cmp3170 = icmp ult i64 %v3169, 40
  %cv3171 = zext i1 %cmp3170 to i32
  store i32 %cv3171, ptr %slot453, align 8
  %v3172 = load i32, ptr %slot452, align 8
  %v3173 = load i32, ptr %slot453, align 8
  %op3174 = or i32 %v3172, %v3173
  store i32 %op3174, ptr %slot454, align 8
  %v3175 = load i32, ptr %slot454, align 8
  %cv3176 = zext i32 %v3175 to i64
  %cond3177 = icmp ne i64 %cv3176, 0
  br i1 %cond3177, label %bb_rcmoveslow600, label %bb_rcmovecheck600
bb_rcmovecheck600:
  %v3178 = load i64, ptr %slot443, align 8
  %op3179 = add i64 %v3178, 0
  store i64 %op3179, ptr %slot455, align 8
  %v3180 = load i64, ptr %slot455, align 8
  %p3181 = inttoptr i64 %v3180 to ptr
  %ld3182 = load i64, ptr %p3181, align 8
  store i64 %ld3182, ptr %slot456, align 8
  %v3183 = load i64, ptr %slot456, align 8
  %cmp3184 = icmp ne i64 %v3183, 0
  %cv3185 = zext i1 %cmp3184 to i32
  store i32 %cv3185, ptr %slot457, align 8
  %v3186 = load i32, ptr %slot457, align 8
  %cv3187 = zext i32 %v3186 to i64
  %cond3188 = icmp ne i64 %cv3187, 0
  br i1 %cond3188, label %bb_rcmoveheader608, label %bb_rcmovenext608
bb_rcmoveheader608:
  %v3189 = load i64, ptr %slot456, align 8
  %op3190 = sub i64 %v3189, 16
  store i64 %op3190, ptr %slot458, align 8
  %v3191 = load i64, ptr %slot456, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  %rgep3193 = getelementptr i8, ptr %p3192, i64 -16
  %ld3194 = load i64, ptr %rgep3193, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3194, ptr %slot459, align 8
  %v3195 = load i64, ptr %slot459, align 8
  %op3196 = and i64 %v3195, 5764607523034234881
  store i64 %op3196, ptr %slot460, align 8
  %v3197 = load i64, ptr %slot460, align 8
  %cmp3198 = icmp ne i64 %v3197, 0
  %cv3199 = zext i1 %cmp3198 to i32
  store i32 %cv3199, ptr %slot461, align 8
  %v3200 = load i32, ptr %slot461, align 8
  %cv3201 = zext i32 %v3200 to i64
  %cond3202 = icmp ne i64 %cv3201, 0
  br i1 %cond3202, label %bb_rcmoveslow600, label %bb_rcmovenext608
bb_rcmovenext608:
  %v3203 = load i64, ptr %slot443, align 8
  %op3204 = add i64 %v3203, 8
  store i64 %op3204, ptr %slot462, align 8
  %v3205 = load i64, ptr %slot462, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  %ld3207 = load i64, ptr %p3206, align 8
  store i64 %ld3207, ptr %slot463, align 8
  %v3208 = load i64, ptr %slot463, align 8
  %cmp3209 = icmp ne i64 %v3208, 0
  %cv3210 = zext i1 %cmp3209 to i32
  store i32 %cv3210, ptr %slot464, align 8
  %v3211 = load i32, ptr %slot464, align 8
  %cv3212 = zext i32 %v3211 to i64
  %cond3213 = icmp ne i64 %cv3212, 0
  br i1 %cond3213, label %bb_rcmoveheader616, label %bb_rcmovenext616
bb_rcmoveheader616:
  %v3214 = load i64, ptr %slot463, align 8
  %op3215 = sub i64 %v3214, 16
  store i64 %op3215, ptr %slot465, align 8
  %v3216 = load i64, ptr %slot463, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  %rgep3218 = getelementptr i8, ptr %p3217, i64 -16
  %ld3219 = load i64, ptr %rgep3218, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3219, ptr %slot466, align 8
  %v3220 = load i64, ptr %slot466, align 8
  %op3221 = and i64 %v3220, 5764607523034234881
  store i64 %op3221, ptr %slot467, align 8
  %v3222 = load i64, ptr %slot467, align 8
  %cmp3223 = icmp ne i64 %v3222, 0
  %cv3224 = zext i1 %cmp3223 to i32
  store i32 %cv3224, ptr %slot468, align 8
  %v3225 = load i32, ptr %slot468, align 8
  %cv3226 = zext i32 %v3225 to i64
  %cond3227 = icmp ne i64 %cv3226, 0
  br i1 %cond3227, label %bb_rcmoveslow600, label %bb_rcmovenext616
bb_rcmovenext616:
  %v3228 = load i64, ptr %slot443, align 8
  %v3229 = load i64, ptr %slot448, align 8
  %p3230 = inttoptr i64 %v3228 to ptr
  %p3231 = inttoptr i64 %v3229 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3231, ptr %p3230, i64 40, i1 false)
  %v3232 = load i64, ptr %slot443, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i64 0, ptr %p3233, align 8
  %v3234 = load i64, ptr %slot443, align 8
  %op3235 = add i64 %v3234, 8
  store i64 %op3235, ptr %slot469, align 8
  %v3236 = load i64, ptr %slot469, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  store i64 0, ptr %p3237, align 8
  %v3238 = load i64, ptr %slot443, align 8
  %op3239 = add i64 %v3238, 16
  store i64 %op3239, ptr %slot470, align 8
  %v3240 = load i64, ptr %slot470, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  store i64 0, ptr %p3241, align 8
  %v3242 = load i64, ptr %slot443, align 8
  %op3243 = add i64 %v3242, 24
  store i64 %op3243, ptr %slot471, align 8
  %v3244 = load i64, ptr %slot471, align 8
  %p3245 = inttoptr i64 %v3244 to ptr
  store i64 0, ptr %p3245, align 8
  %v3246 = load i64, ptr %slot443, align 8
  %op3247 = add i64 %v3246, 32
  store i64 %op3247, ptr %slot472, align 8
  %v3248 = load i64, ptr %slot472, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  store i64 0, ptr %p3249, align 8
  br label %bb_rcmoved600
bb_rcmoveslow600:
  %v3250 = load i64, ptr %slot69, align 8
  %v3251 = load i64, ptr %slot448, align 8
  %v3252 = load i64, ptr %slot443, align 8
  %v3253 = load i64, ptr %slot449, align 8
  %cv3254 = trunc i64 %v3253 to i32
  %call3255 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v3250, i64 %v3251, i64 %v3252, i32 %cv3254) nomerge, !dbg !132
  store i32 %call3255, ptr %slot473, align 8
  %v3256 = load i32, ptr %slot473, align 8
  %cv3257 = zext i32 %v3256 to i64
  %cond3258 = icmp ne i64 %cv3257, 0
  br i1 %cond3258, label %bb_rcsuccess627, label %bb_rcfailure627
bb_rcfailure627:
  %v3259 = load i64, ptr %slot69, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  %call3261 = call i32 @myl_rc_take_failure(ptr %p3260) nomerge, !dbg !132
  store i32 %call3261, ptr %slot474, align 8
  %v3262 = load i64, ptr %slot1, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  %v3264 = load i32, ptr %slot474, align 8
  %call3265 = call i32 @myl_qbe_rc_status(ptr %p3263, i32 %v3264) nomerge, !dbg !132
  store i32 %call3265, ptr %slot475, align 8
  br label %bb_failure
bb_rcsuccess627:
  br label %bb_rcmoved600
bb_rcmoved600:
  %v3266 = load i64, ptr %slot18, align 8
  %p3267 = inttoptr i64 %v3266 to ptr
  store i32 0, ptr %p3267, align 4, !alias.scope !3, !noalias !4
  %v3268 = load i64, ptr %slot30, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  store i32 2, ptr %p3269, align 4, !alias.scope !3, !noalias !4
  %v3270 = load i64, ptr %slot29, align 8
  %p3271 = inttoptr i64 %v3270 to ptr
  store i32 1, ptr %p3271, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared591
bb_rccopy591:
  %v3272 = load i64, ptr %slot41, align 8
  store i64 %v3272, ptr %slot476, align 8
  %v3273 = load i64, ptr %slot70, align 8
  store i64 %v3273, ptr %slot477, align 8
  %v3274 = load i64, ptr %slot69, align 8
  %v3275 = load i64, ptr %slot476, align 8
  %v3276 = load i64, ptr %slot443, align 8
  %v3277 = load i64, ptr %slot477, align 8
  %cv3278 = trunc i64 %v3277 to i32
  %call3279 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64 %v3274, i64 %v3275, i64 %v3276, i32 %cv3278) nomerge, !dbg !132
  store i32 %call3279, ptr %slot478, align 8
  %v3280 = load i32, ptr %slot478, align 8
  %cv3281 = zext i32 %v3280 to i64
  %cond3282 = icmp ne i64 %cv3281, 0
  br i1 %cond3282, label %bb_rcsuccess636, label %bb_rcfailure636
bb_rcfailure636:
  %v3283 = load i64, ptr %slot69, align 8
  %p3284 = inttoptr i64 %v3283 to ptr
  %call3285 = call i32 @myl_rc_take_failure(ptr %p3284) nomerge, !dbg !132
  store i32 %call3285, ptr %slot479, align 8
  %v3286 = load i64, ptr %slot1, align 8
  %p3287 = inttoptr i64 %v3286 to ptr
  %v3288 = load i32, ptr %slot479, align 8
  %call3289 = call i32 @myl_qbe_rc_status(ptr %p3287, i32 %v3288) nomerge, !dbg !132
  store i32 %call3289, ptr %slot480, align 8
  br label %bb_failure
bb_rcsuccess636:
  %v3290 = load i64, ptr %slot30, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  store i32 2, ptr %p3291, align 4, !alias.scope !3, !noalias !4
  %v3292 = load i64, ptr %slot29, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  store i32 1, ptr %p3293, align 4, !alias.scope !3, !noalias !4
  %v3294 = load i64, ptr %slot18, align 8
  %p3295 = inttoptr i64 %v3294 to ptr
  %ld3296 = load i32, ptr %p3295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3296, ptr %slot481, align 8
  %v3297 = load i32, ptr %slot481, align 8
  %cv3298 = zext i32 %v3297 to i64
  %cond3299 = icmp ne i64 %cv3298, 0
  br i1 %cond3299, label %bb_rcslotdrop643, label %bb_rcslotdone643
bb_rcslotdrop643:
  %v3300 = load i64, ptr %slot18, align 8
  %p3301 = inttoptr i64 %v3300 to ptr
  store i32 0, ptr %p3301, align 4, !alias.scope !3, !noalias !4
  %v3302 = load i64, ptr %slot33, align 8
  store i64 %v3302, ptr %slot482, align 8
  %v3303 = load i64, ptr %slot19, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  %ld3305 = load i32, ptr %p3304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3305, ptr %slot483, align 8
  %v3306 = load i32, ptr %slot483, align 8
  %op3307 = and i32 %v3306, 28
  store i32 %op3307, ptr %slot484, align 8
  %v3308 = load i32, ptr %slot484, align 8
  %cv3309 = zext i32 %v3308 to i64
  %cond3310 = icmp ne i64 %cv3309, 0
  br i1 %cond3310, label %bb_rcslotrole643, label %bb_rcslotowner643
bb_rcslotrole643:
  %v3311 = load i64, ptr %slot69, align 8
  store i64 %v3311, ptr %slot485, align 8
  %v3312 = load i64, ptr %slot485, align 8
  %v3313 = load i64, ptr %slot482, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v3312, i64 %v3313) nomerge, !dbg !132
  br label %bb_rcslotdone643
bb_rcslotowner643:
  %v3314 = load i64, ptr %slot69, align 8
  store i64 %v3314, ptr %slot486, align 8
  %v3315 = load i64, ptr %slot486, align 8
  %v3316 = load i64, ptr %slot482, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v3315, i64 %v3316) nomerge, !dbg !132
  br label %bb_rcslotdone643
bb_rcslotdone643:
  br label %bb_rcprepared591
bb_rcprepared591:
  %v3317 = load i64, ptr %slot41, align 8
  store i64 %v3317, ptr %slot487, align 8
  %v3318 = load i64, ptr %slot487, align 8
  %v3319 = load i64, ptr %slot442, align 8
  %p3320 = inttoptr i64 %v3318 to ptr
  %p3321 = inttoptr i64 %v3319 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3321, ptr %p3320, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3322 = load i64, ptr %slot29, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  store i32 0, ptr %p3323, align 4, !alias.scope !3, !noalias !4
  %v3324 = load i64, ptr %slot52, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %ld3326 = load i64, ptr %p3325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3326, ptr %slot488, align 8
  %v3327 = load i64, ptr %slot488, align 8
  %v3328 = load i64, ptr %slot37, align 8
  %p3329 = inttoptr i64 %v3328 to ptr
  store i64 %v3327, ptr %p3329, align 8, !alias.scope !3, !noalias !4
  %v3330 = load i64, ptr %slot37, align 8
  store i64 %v3330, ptr %slot489, align 8
  %v3331 = load i64, ptr %slot415, align 8
  %p3333 = inttoptr i64 %v3331 to ptr
  %gep3334 = getelementptr i8, ptr %p3333, i64 248
  %op3332 = ptrtoint ptr %gep3334 to i64
  store i64 %op3332, ptr %slot490, align 8
  %v3335 = load i64, ptr %slot52, align 8
  %p3336 = inttoptr i64 %v3335 to ptr
  %ld3337 = load i64, ptr %p3336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3337, ptr %slot491, align 8
  %v3338 = load i64, ptr %slot491, align 8
  %v3339 = load i64, ptr %slot37, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i64 %v3338, ptr %p3340, align 8, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot37, align 8
  store i64 %v3341, ptr %slot492, align 8
  store i32 0, ptr %slot493, align 8
  %v3342 = load i64, ptr %slot20, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  %ld3344 = load i32, ptr %p3343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3344, ptr %slot494, align 8
  %v3345 = load i32, ptr %slot494, align 8
  %op3346 = and i32 %v3345, 24
  store i32 %op3346, ptr %slot494, align 8
  %v3347 = load i32, ptr %slot494, align 8
  %cmp3348 = icmp eq i32 %v3347, 0
  %cv3349 = zext i1 %cmp3348 to i32
  store i32 %cv3349, ptr %slot495, align 8
  %v3350 = load i32, ptr %slot493, align 8
  %v3351 = load i32, ptr %slot495, align 8
  %op3352 = and i32 %v3350, %v3351
  store i32 %op3352, ptr %slot496, align 8
  %v3353 = load i32, ptr %slot496, align 8
  %cv3354 = zext i32 %v3353 to i64
  %cond3355 = icmp ne i64 %cv3354, 0
  br i1 %cond3355, label %bb_rctake657, label %bb_rccopy657
bb_rctake657:
  %v3356 = load i64, ptr %slot41, align 8
  store i64 %v3356, ptr %slot497, align 8
  %v3357 = load i64, ptr %slot70, align 8
  store i64 %v3357, ptr %slot498, align 8
  %v3358 = load i64, ptr %slot492, align 8
  %v3359 = load i64, ptr %slot497, align 8
  %op3360 = sub i64 %v3358, %v3359
  store i64 %op3360, ptr %slot499, align 8
  %v3361 = load i64, ptr %slot497, align 8
  %v3362 = load i64, ptr %slot492, align 8
  %op3363 = sub i64 %v3361, %v3362
  store i64 %op3363, ptr %slot500, align 8
  %v3364 = load i64, ptr %slot499, align 8
  %cmp3365 = icmp ult i64 %v3364, 8
  %cv3366 = zext i1 %cmp3365 to i32
  store i32 %cv3366, ptr %slot501, align 8
  %v3367 = load i64, ptr %slot500, align 8
  %cmp3368 = icmp ult i64 %v3367, 8
  %cv3369 = zext i1 %cmp3368 to i32
  store i32 %cv3369, ptr %slot502, align 8
  %v3370 = load i32, ptr %slot501, align 8
  %v3371 = load i32, ptr %slot502, align 8
  %op3372 = or i32 %v3370, %v3371
  store i32 %op3372, ptr %slot503, align 8
  %v3373 = load i32, ptr %slot503, align 8
  %cv3374 = zext i32 %v3373 to i64
  %cond3375 = icmp ne i64 %cv3374, 0
  br i1 %cond3375, label %bb_rcmoveslow666, label %bb_rcmovecheck666
bb_rcmovecheck666:
  %v3376 = load i64, ptr %slot492, align 8
  %p3378 = inttoptr i64 %v3376 to ptr
  %gep3379 = getelementptr i8, ptr %p3378, i64 0
  %op3377 = ptrtoint ptr %gep3379 to i64
  store i64 %op3377, ptr %slot504, align 8
  %v3380 = load i64, ptr %slot504, align 8
  %p3381 = inttoptr i64 %v3380 to ptr
  %ld3382 = load i64, ptr %p3381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3382, ptr %slot505, align 8
  %v3383 = load i64, ptr %slot505, align 8
  %cmp3384 = icmp ne i64 %v3383, 0
  %cv3385 = zext i1 %cmp3384 to i32
  store i32 %cv3385, ptr %slot506, align 8
  %v3386 = load i32, ptr %slot506, align 8
  %cv3387 = zext i32 %v3386 to i64
  %cond3388 = icmp ne i64 %cv3387, 0
  br i1 %cond3388, label %bb_rcmoveheader674, label %bb_rcmovenext674
bb_rcmoveheader674:
  %v3389 = load i64, ptr %slot505, align 8
  %op3390 = sub i64 %v3389, 16
  store i64 %op3390, ptr %slot507, align 8
  %v3391 = load i64, ptr %slot505, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  %rgep3393 = getelementptr i8, ptr %p3392, i64 -16
  %ld3394 = load i64, ptr %rgep3393, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3394, ptr %slot508, align 8
  %v3395 = load i64, ptr %slot508, align 8
  %op3396 = and i64 %v3395, 5764607523034234881
  store i64 %op3396, ptr %slot509, align 8
  %v3397 = load i64, ptr %slot509, align 8
  %cmp3398 = icmp ne i64 %v3397, 0
  %cv3399 = zext i1 %cmp3398 to i32
  store i32 %cv3399, ptr %slot510, align 8
  %v3400 = load i32, ptr %slot510, align 8
  %cv3401 = zext i32 %v3400 to i64
  %cond3402 = icmp ne i64 %cv3401, 0
  br i1 %cond3402, label %bb_rcmoveslow666, label %bb_rcmovenext674
bb_rcmovenext674:
  %v3403 = load i64, ptr %slot492, align 8
  %v3404 = load i64, ptr %slot497, align 8
  %p3405 = inttoptr i64 %v3403 to ptr
  %p3406 = inttoptr i64 %v3404 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3406, ptr %p3405, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3407 = load i64, ptr %slot492, align 8
  %p3408 = inttoptr i64 %v3407 to ptr
  store i64 0, ptr %p3408, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved666
bb_rcmoveslow666:
  %v3409 = load i64, ptr %slot69, align 8
  %v3410 = load i64, ptr %slot497, align 8
  %v3411 = load i64, ptr %slot492, align 8
  %v3412 = load i64, ptr %slot498, align 8
  %cv3413 = trunc i64 %v3412 to i32
  %call3414 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v3409, i64 %v3410, i64 %v3411, i32 %cv3413) nomerge, !dbg !132
  store i32 %call3414, ptr %slot511, align 8
  %v3415 = load i32, ptr %slot511, align 8
  %cv3416 = zext i32 %v3415 to i64
  %cond3417 = icmp ne i64 %cv3416, 0
  br i1 %cond3417, label %bb_rcsuccess681, label %bb_rcfailure681
bb_rcfailure681:
  %v3418 = load i64, ptr %slot69, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  %call3420 = call i32 @myl_rc_take_failure(ptr %p3419) nomerge, !dbg !132
  store i32 %call3420, ptr %slot512, align 8
  %v3421 = load i64, ptr %slot1, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  %v3423 = load i32, ptr %slot512, align 8
  %call3424 = call i32 @myl_qbe_rc_status(ptr %p3422, i32 %v3423) nomerge, !dbg !132
  store i32 %call3424, ptr %slot513, align 8
  br label %bb_failure
bb_rcsuccess681:
  br label %bb_rcmoved666
bb_rcmoved666:
  %v3425 = load i64, ptr %slot30, align 8
  %p3426 = inttoptr i64 %v3425 to ptr
  store i32 2, ptr %p3426, align 4, !alias.scope !3, !noalias !4
  %v3427 = load i64, ptr %slot29, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  store i32 1, ptr %p3428, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared657
bb_rccopy657:
  %v3429 = load i64, ptr %slot41, align 8
  store i64 %v3429, ptr %slot514, align 8
  %v3430 = load i64, ptr %slot70, align 8
  store i64 %v3430, ptr %slot515, align 8
  %v3431 = load i64, ptr %slot492, align 8
  %p3432 = inttoptr i64 %v3431 to ptr
  %ld3433 = load i64, ptr %p3432, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3433, ptr %slot516, align 8
  %v3434 = load i64, ptr %slot516, align 8
  %cmp3435 = icmp ne i64 %v3434, 0
  %cv3436 = zext i1 %cmp3435 to i32
  store i32 %cv3436, ptr %slot517, align 8
  %v3437 = load i32, ptr %slot517, align 8
  %cv3438 = zext i32 %v3437 to i64
  %cond3439 = icmp ne i64 %cv3438, 0
  br i1 %cond3439, label %bb_rcgnn690, label %bb_rcgplain690
bb_rcgnn690:
  %v3440 = load i64, ptr %slot516, align 8
  %op3441 = sub i64 %v3440, 16
  store i64 %op3441, ptr %slot518, align 8
  %v3442 = load i64, ptr %slot516, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  %rgep3444 = getelementptr i8, ptr %p3443, i64 -16
  %ld3445 = load i64, ptr %rgep3444, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3445, ptr %slot519, align 8
  %v3446 = load i64, ptr %slot519, align 8
  %op3447 = and i64 %v3446, 4611686018427387906
  store i64 %op3447, ptr %slot520, align 8
  %v3448 = load i64, ptr %slot520, align 8
  %cmp3449 = icmp ne i64 %v3448, 0
  %cv3450 = zext i1 %cmp3449 to i32
  store i32 %cv3450, ptr %slot521, align 8
  %v3451 = load i32, ptr %slot521, align 8
  %cv3452 = zext i32 %v3451 to i64
  %cond3453 = icmp ne i64 %cv3452, 0
  br i1 %cond3453, label %bb_rcgspecial690, label %bb_rcginc690
bb_rcginc690:
  %v3454 = load i64, ptr %slot516, align 8
  %op3455 = sub i64 %v3454, 32
  store i64 %op3455, ptr %slot522, align 8
  %v3456 = load i64, ptr %slot516, align 8
  %p3457 = inttoptr i64 %v3456 to ptr
  %rgep3458 = getelementptr i8, ptr %p3457, i64 -32
  %ld3459 = load i64, ptr %rgep3458, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3459, ptr %slot523, align 8
  %v3460 = load i64, ptr %slot523, align 8
  %op3461 = add i64 %v3460, 1
  store i64 %op3461, ptr %slot524, align 8
  %v3462 = load i64, ptr %slot524, align 8
  %cmp3463 = icmp eq i64 %v3462, 0
  %cv3464 = zext i1 %cmp3463 to i32
  store i32 %cv3464, ptr %slot525, align 8
  %v3465 = load i32, ptr %slot525, align 8
  %cv3466 = zext i32 %v3465 to i64
  %cond3467 = icmp ne i64 %cv3466, 0
  br i1 %cond3467, label %bb_rcglimit690, label %bb_rcgcapacity690
bb_rcglimit690:
  %v3468 = load i64, ptr %slot1, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  %call3470 = call i32 @myl_qbe_rc_status(ptr %p3469, i32 2) nomerge, !dbg !132
  store i32 %call3470, ptr %slot526, align 8
  br label %bb_failure
bb_rcgcapacity690:
  %v3471 = load i64, ptr %slot524, align 8
  %v3472 = load i64, ptr %slot516, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %rgep3474 = getelementptr i8, ptr %p3473, i64 -32
  store i64 %v3471, ptr %rgep3474, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain690
bb_rcgspecial690:
  %v3475 = load i64, ptr %slot519, align 8
  %op3476 = and i64 %v3475, 4611686018427387904
  store i64 %op3476, ptr %slot527, align 8
  %v3477 = load i64, ptr %slot527, align 8
  %cmp3478 = icmp ne i64 %v3477, 0
  %cv3479 = zext i1 %cmp3478 to i32
  store i32 %cv3479, ptr %slot528, align 8
  %v3480 = load i32, ptr %slot528, align 8
  %cv3481 = zext i32 %v3480 to i64
  %cond3482 = icmp ne i64 %cv3481, 0
  br i1 %cond3482, label %bb_rcgslow690, label %bb_rcgplain690
bb_rcgslow690:
  %v3483 = load i64, ptr %slot69, align 8
  %v3484 = load i64, ptr %slot514, align 8
  %v3485 = load i64, ptr %slot492, align 8
  %v3486 = load i64, ptr %slot515, align 8
  %cv3487 = trunc i64 %v3486 to i32
  %call3488 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v3483, i64 %v3484, i64 %v3485, i32 %cv3487) nomerge, !dbg !132
  store i32 %call3488, ptr %slot529, align 8
  %v3489 = load i32, ptr %slot529, align 8
  %cv3490 = zext i32 %v3489 to i64
  %cond3491 = icmp ne i64 %cv3490, 0
  br i1 %cond3491, label %bb_rcsuccess704, label %bb_rcfailure704
bb_rcfailure704:
  %v3492 = load i64, ptr %slot69, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  %call3494 = call i32 @myl_rc_take_failure(ptr %p3493) nomerge, !dbg !132
  store i32 %call3494, ptr %slot530, align 8
  %v3495 = load i64, ptr %slot1, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  %v3497 = load i32, ptr %slot530, align 8
  %call3498 = call i32 @myl_qbe_rc_status(ptr %p3496, i32 %v3497) nomerge, !dbg !132
  store i32 %call3498, ptr %slot531, align 8
  br label %bb_failure
bb_rcsuccess704:
  br label %bb_rcgdone690
bb_rcgplain690:
  %v3499 = load i64, ptr %slot516, align 8
  %v3500 = load i64, ptr %slot514, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  store i64 %v3499, ptr %p3501, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone690
bb_rcgdone690:
  %v3502 = load i64, ptr %slot30, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  store i32 2, ptr %p3503, align 4, !alias.scope !3, !noalias !4
  %v3504 = load i64, ptr %slot29, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  store i32 1, ptr %p3505, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared657
bb_rcprepared657:
  %v3506 = load i64, ptr %slot41, align 8
  store i64 %v3506, ptr %slot532, align 8
  %v3507 = load i64, ptr %slot532, align 8
  %v3508 = load i64, ptr %slot490, align 8
  %p3509 = inttoptr i64 %v3507 to ptr
  %p3510 = inttoptr i64 %v3508 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3510, ptr %p3509, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3511 = load i64, ptr %slot29, align 8
  %p3512 = inttoptr i64 %v3511 to ptr
  store i32 0, ptr %p3512, align 4, !alias.scope !3, !noalias !4
  %v3513 = load i64, ptr %slot53, align 8
  %p3514 = inttoptr i64 %v3513 to ptr
  %ld3515 = load i64, ptr %p3514, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3515, ptr %slot533, align 8
  %v3516 = load i64, ptr %slot415, align 8
  %p3518 = inttoptr i64 %v3516 to ptr
  %gep3519 = getelementptr i8, ptr %p3518, i64 256
  %op3517 = ptrtoint ptr %gep3519 to i64
  store i64 %op3517, ptr %slot534, align 8
  %v3520 = load i64, ptr %slot53, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  %ld3522 = load i64, ptr %p3521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3522, ptr %slot535, align 8
  store i32 0, ptr %slot536, align 8
  %v3523 = load i64, ptr %slot21, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  %ld3525 = load i32, ptr %p3524, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3525, ptr %slot537, align 8
  %v3526 = load i32, ptr %slot537, align 8
  %op3527 = and i32 %v3526, 24
  store i32 %op3527, ptr %slot537, align 8
  %v3528 = load i32, ptr %slot537, align 8
  %cmp3529 = icmp eq i32 %v3528, 0
  %cv3530 = zext i1 %cmp3529 to i32
  store i32 %cv3530, ptr %slot538, align 8
  %v3531 = load i32, ptr %slot536, align 8
  %v3532 = load i32, ptr %slot538, align 8
  %op3533 = and i32 %v3531, %v3532
  store i32 %op3533, ptr %slot539, align 8
  %v3534 = load i32, ptr %slot539, align 8
  %cv3535 = zext i32 %v3534 to i64
  %cond3536 = icmp ne i64 %cv3535, 0
  br i1 %cond3536, label %bb_rctake751, label %bb_rccopy751
bb_rctake751:
  %v3537 = load i64, ptr %slot41, align 8
  store i64 %v3537, ptr %slot540, align 8
  %v3538 = load i64, ptr %slot70, align 8
  store i64 %v3538, ptr %slot541, align 8
  %v3539 = load i64, ptr %slot535, align 8
  %v3540 = load i64, ptr %slot540, align 8
  %op3541 = sub i64 %v3539, %v3540
  store i64 %op3541, ptr %slot542, align 8
  %v3542 = load i64, ptr %slot540, align 8
  %v3543 = load i64, ptr %slot535, align 8
  %op3544 = sub i64 %v3542, %v3543
  store i64 %op3544, ptr %slot543, align 8
  %v3545 = load i64, ptr %slot542, align 8
  %cmp3546 = icmp ult i64 %v3545, 32
  %cv3547 = zext i1 %cmp3546 to i32
  store i32 %cv3547, ptr %slot544, align 8
  %v3548 = load i64, ptr %slot543, align 8
  %cmp3549 = icmp ult i64 %v3548, 32
  %cv3550 = zext i1 %cmp3549 to i32
  store i32 %cv3550, ptr %slot545, align 8
  %v3551 = load i32, ptr %slot544, align 8
  %v3552 = load i32, ptr %slot545, align 8
  %op3553 = or i32 %v3551, %v3552
  store i32 %op3553, ptr %slot546, align 8
  %v3554 = load i32, ptr %slot546, align 8
  %cv3555 = zext i32 %v3554 to i64
  %cond3556 = icmp ne i64 %cv3555, 0
  br i1 %cond3556, label %bb_rcmoveslow760, label %bb_rcmovecheck760
bb_rcmovecheck760:
  %v3557 = load i64, ptr %slot535, align 8
  %op3558 = add i64 %v3557, 0
  store i64 %op3558, ptr %slot547, align 8
  %v3559 = load i64, ptr %slot547, align 8
  %p3560 = inttoptr i64 %v3559 to ptr
  %ld3561 = load i64, ptr %p3560, align 8
  store i64 %ld3561, ptr %slot548, align 8
  %v3562 = load i64, ptr %slot548, align 8
  %cmp3563 = icmp ne i64 %v3562, 0
  %cv3564 = zext i1 %cmp3563 to i32
  store i32 %cv3564, ptr %slot549, align 8
  %v3565 = load i32, ptr %slot549, align 8
  %cv3566 = zext i32 %v3565 to i64
  %cond3567 = icmp ne i64 %cv3566, 0
  br i1 %cond3567, label %bb_rcmoveheader768, label %bb_rcmovenext768
bb_rcmoveheader768:
  %v3568 = load i64, ptr %slot548, align 8
  %op3569 = sub i64 %v3568, 16
  store i64 %op3569, ptr %slot550, align 8
  %v3570 = load i64, ptr %slot548, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  %rgep3572 = getelementptr i8, ptr %p3571, i64 -16
  %ld3573 = load i64, ptr %rgep3572, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3573, ptr %slot551, align 8
  %v3574 = load i64, ptr %slot551, align 8
  %op3575 = and i64 %v3574, 5764607523034234881
  store i64 %op3575, ptr %slot552, align 8
  %v3576 = load i64, ptr %slot552, align 8
  %cmp3577 = icmp ne i64 %v3576, 0
  %cv3578 = zext i1 %cmp3577 to i32
  store i32 %cv3578, ptr %slot553, align 8
  %v3579 = load i32, ptr %slot553, align 8
  %cv3580 = zext i32 %v3579 to i64
  %cond3581 = icmp ne i64 %cv3580, 0
  br i1 %cond3581, label %bb_rcmoveslow760, label %bb_rcmovenext768
bb_rcmovenext768:
  %v3582 = load i64, ptr %slot535, align 8
  %v3583 = load i64, ptr %slot540, align 8
  %p3584 = inttoptr i64 %v3582 to ptr
  %p3585 = inttoptr i64 %v3583 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3585, ptr %p3584, i64 32, i1 false)
  %v3586 = load i64, ptr %slot535, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  store i64 0, ptr %p3587, align 8
  %v3588 = load i64, ptr %slot535, align 8
  %op3589 = add i64 %v3588, 8
  store i64 %op3589, ptr %slot554, align 8
  %v3590 = load i64, ptr %slot554, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  store i64 0, ptr %p3591, align 8
  %v3592 = load i64, ptr %slot535, align 8
  %op3593 = add i64 %v3592, 16
  store i64 %op3593, ptr %slot555, align 8
  %v3594 = load i64, ptr %slot555, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  store i64 0, ptr %p3595, align 8
  %v3596 = load i64, ptr %slot535, align 8
  %op3597 = add i64 %v3596, 24
  store i64 %op3597, ptr %slot556, align 8
  %v3598 = load i64, ptr %slot556, align 8
  %p3599 = inttoptr i64 %v3598 to ptr
  store i64 0, ptr %p3599, align 8
  br label %bb_rcmoved760
bb_rcmoveslow760:
  %v3600 = load i64, ptr %slot69, align 8
  %v3601 = load i64, ptr %slot540, align 8
  %v3602 = load i64, ptr %slot535, align 8
  %v3603 = load i64, ptr %slot541, align 8
  %cv3604 = trunc i64 %v3603 to i32
  %call3605 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v3600, i64 %v3601, i64 %v3602, i32 %cv3604) nomerge, !dbg !132
  store i32 %call3605, ptr %slot557, align 8
  %v3606 = load i32, ptr %slot557, align 8
  %cv3607 = zext i32 %v3606 to i64
  %cond3608 = icmp ne i64 %cv3607, 0
  br i1 %cond3608, label %bb_rcsuccess778, label %bb_rcfailure778
bb_rcfailure778:
  %v3609 = load i64, ptr %slot69, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  %call3611 = call i32 @myl_rc_take_failure(ptr %p3610) nomerge, !dbg !132
  store i32 %call3611, ptr %slot558, align 8
  %v3612 = load i64, ptr %slot1, align 8
  %p3613 = inttoptr i64 %v3612 to ptr
  %v3614 = load i32, ptr %slot558, align 8
  %call3615 = call i32 @myl_qbe_rc_status(ptr %p3613, i32 %v3614) nomerge, !dbg !132
  store i32 %call3615, ptr %slot559, align 8
  br label %bb_failure
bb_rcsuccess778:
  br label %bb_rcmoved760
bb_rcmoved760:
  %v3616 = load i64, ptr %slot30, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  store i32 2, ptr %p3617, align 4, !alias.scope !3, !noalias !4
  %v3618 = load i64, ptr %slot29, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  store i32 1, ptr %p3619, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared751
bb_rccopy751:
  %v3620 = load i64, ptr %slot41, align 8
  store i64 %v3620, ptr %slot560, align 8
  %v3621 = load i64, ptr %slot70, align 8
  store i64 %v3621, ptr %slot561, align 8
  %v3622 = load i64, ptr %slot69, align 8
  %v3623 = load i64, ptr %slot560, align 8
  %v3624 = load i64, ptr %slot535, align 8
  %v3625 = load i64, ptr %slot561, align 8
  %cv3626 = trunc i64 %v3625 to i32
  %call3627 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v3622, i64 %v3623, i64 %v3624, i32 %cv3626) nomerge, !dbg !132
  store i32 %call3627, ptr %slot562, align 8
  %v3628 = load i32, ptr %slot562, align 8
  %cv3629 = zext i32 %v3628 to i64
  %cond3630 = icmp ne i64 %cv3629, 0
  br i1 %cond3630, label %bb_rcsuccess787, label %bb_rcfailure787
bb_rcfailure787:
  %v3631 = load i64, ptr %slot69, align 8
  %p3632 = inttoptr i64 %v3631 to ptr
  %call3633 = call i32 @myl_rc_take_failure(ptr %p3632) nomerge, !dbg !132
  store i32 %call3633, ptr %slot563, align 8
  %v3634 = load i64, ptr %slot1, align 8
  %p3635 = inttoptr i64 %v3634 to ptr
  %v3636 = load i32, ptr %slot563, align 8
  %call3637 = call i32 @myl_qbe_rc_status(ptr %p3635, i32 %v3636) nomerge, !dbg !132
  store i32 %call3637, ptr %slot564, align 8
  br label %bb_failure
bb_rcsuccess787:
  %v3638 = load i64, ptr %slot30, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  store i32 2, ptr %p3639, align 4, !alias.scope !3, !noalias !4
  %v3640 = load i64, ptr %slot29, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  store i32 1, ptr %p3641, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared751
bb_rcprepared751:
  %v3642 = load i64, ptr %slot41, align 8
  store i64 %v3642, ptr %slot565, align 8
  %v3643 = load i64, ptr %slot565, align 8
  %v3644 = load i64, ptr %slot534, align 8
  %p3645 = inttoptr i64 %v3643 to ptr
  %p3646 = inttoptr i64 %v3644 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3646, ptr %p3645, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3647 = load i64, ptr %slot29, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  store i32 0, ptr %p3648, align 4, !alias.scope !3, !noalias !4
  %v3649 = load i64, ptr %slot54, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  %ld3651 = load i64, ptr %p3650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3651, ptr %slot566, align 8
  %v3652 = load i64, ptr %slot415, align 8
  %p3654 = inttoptr i64 %v3652 to ptr
  %gep3655 = getelementptr i8, ptr %p3654, i64 288
  %op3653 = ptrtoint ptr %gep3655 to i64
  store i64 %op3653, ptr %slot567, align 8
  %v3656 = load i64, ptr %slot54, align 8
  %p3657 = inttoptr i64 %v3656 to ptr
  %ld3658 = load i64, ptr %p3657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3658, ptr %slot568, align 8
  %v3659 = load i64, ptr %slot22, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  %ld3661 = load i32, ptr %p3660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3661, ptr %slot569, align 8
  %v3662 = load i64, ptr %slot23, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  %ld3664 = load i32, ptr %p3663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3664, ptr %slot570, align 8
  %v3665 = load i32, ptr %slot570, align 8
  %op3666 = and i32 %v3665, 24
  store i32 %op3666, ptr %slot570, align 8
  %v3667 = load i32, ptr %slot570, align 8
  %cmp3668 = icmp eq i32 %v3667, 0
  %cv3669 = zext i1 %cmp3668 to i32
  store i32 %cv3669, ptr %slot571, align 8
  %v3670 = load i32, ptr %slot569, align 8
  %v3671 = load i32, ptr %slot571, align 8
  %op3672 = and i32 %v3670, %v3671
  store i32 %op3672, ptr %slot572, align 8
  %v3673 = load i32, ptr %slot572, align 8
  %cv3674 = zext i32 %v3673 to i64
  %cond3675 = icmp ne i64 %cv3674, 0
  br i1 %cond3675, label %bb_rctake806, label %bb_rccopy806
bb_rctake806:
  %v3676 = load i64, ptr %slot41, align 8
  store i64 %v3676, ptr %slot573, align 8
  %v3677 = load i64, ptr %slot70, align 8
  store i64 %v3677, ptr %slot574, align 8
  %v3678 = load i64, ptr %slot69, align 8
  %v3679 = load i64, ptr %slot573, align 8
  %v3680 = load i64, ptr %slot568, align 8
  %v3681 = load i64, ptr %slot574, align 8
  %cv3682 = trunc i64 %v3681 to i32
  %call3683 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v3678, i64 %v3679, i64 %v3680, i32 %cv3682) nomerge, !dbg !132
  store i32 %call3683, ptr %slot575, align 8
  %v3684 = load i32, ptr %slot575, align 8
  %cv3685 = zext i32 %v3684 to i64
  %cond3686 = icmp ne i64 %cv3685, 0
  br i1 %cond3686, label %bb_rcsuccess816, label %bb_rcfailure816
bb_rcfailure816:
  %v3687 = load i64, ptr %slot69, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %call3689 = call i32 @myl_rc_take_failure(ptr %p3688) nomerge, !dbg !132
  store i32 %call3689, ptr %slot576, align 8
  %v3690 = load i64, ptr %slot1, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  %v3692 = load i32, ptr %slot576, align 8
  %call3693 = call i32 @myl_qbe_rc_status(ptr %p3691, i32 %v3692) nomerge, !dbg !132
  store i32 %call3693, ptr %slot577, align 8
  br label %bb_failure
bb_rcsuccess816:
  %v3694 = load i64, ptr %slot22, align 8
  %p3695 = inttoptr i64 %v3694 to ptr
  store i32 0, ptr %p3695, align 4, !alias.scope !3, !noalias !4
  %v3696 = load i64, ptr %slot30, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  store i32 2, ptr %p3697, align 4, !alias.scope !3, !noalias !4
  %v3698 = load i64, ptr %slot29, align 8
  %p3699 = inttoptr i64 %v3698 to ptr
  store i32 1, ptr %p3699, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared806
bb_rccopy806:
  %v3700 = load i64, ptr %slot41, align 8
  store i64 %v3700, ptr %slot578, align 8
  %v3701 = load i64, ptr %slot70, align 8
  store i64 %v3701, ptr %slot579, align 8
  %v3702 = load i64, ptr %slot69, align 8
  %v3703 = load i64, ptr %slot578, align 8
  %v3704 = load i64, ptr %slot568, align 8
  %v3705 = load i64, ptr %slot579, align 8
  %cv3706 = trunc i64 %v3705 to i32
  %call3707 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v3702, i64 %v3703, i64 %v3704, i32 %cv3706) nomerge, !dbg !132
  store i32 %call3707, ptr %slot580, align 8
  %v3708 = load i32, ptr %slot580, align 8
  %cv3709 = zext i32 %v3708 to i64
  %cond3710 = icmp ne i64 %cv3709, 0
  br i1 %cond3710, label %bb_rcsuccess825, label %bb_rcfailure825
bb_rcfailure825:
  %v3711 = load i64, ptr %slot69, align 8
  %p3712 = inttoptr i64 %v3711 to ptr
  %call3713 = call i32 @myl_rc_take_failure(ptr %p3712) nomerge, !dbg !132
  store i32 %call3713, ptr %slot581, align 8
  %v3714 = load i64, ptr %slot1, align 8
  %p3715 = inttoptr i64 %v3714 to ptr
  %v3716 = load i32, ptr %slot581, align 8
  %call3717 = call i32 @myl_qbe_rc_status(ptr %p3715, i32 %v3716) nomerge, !dbg !132
  store i32 %call3717, ptr %slot582, align 8
  br label %bb_failure
bb_rcsuccess825:
  %v3718 = load i64, ptr %slot30, align 8
  %p3719 = inttoptr i64 %v3718 to ptr
  store i32 2, ptr %p3719, align 4, !alias.scope !3, !noalias !4
  %v3720 = load i64, ptr %slot29, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  store i32 1, ptr %p3721, align 4, !alias.scope !3, !noalias !4
  %v3722 = load i64, ptr %slot22, align 8
  %p3723 = inttoptr i64 %v3722 to ptr
  %ld3724 = load i32, ptr %p3723, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3724, ptr %slot583, align 8
  %v3725 = load i32, ptr %slot583, align 8
  %cv3726 = zext i32 %v3725 to i64
  %cond3727 = icmp ne i64 %cv3726, 0
  br i1 %cond3727, label %bb_rcslotdrop832, label %bb_rcslotdone832
bb_rcslotdrop832:
  %v3728 = load i64, ptr %slot22, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  store i32 0, ptr %p3729, align 4, !alias.scope !3, !noalias !4
  %v3730 = load i64, ptr %slot34, align 8
  store i64 %v3730, ptr %slot584, align 8
  %v3731 = load i64, ptr %slot23, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  %ld3733 = load i32, ptr %p3732, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3733, ptr %slot585, align 8
  %v3734 = load i32, ptr %slot585, align 8
  %op3735 = and i32 %v3734, 28
  store i32 %op3735, ptr %slot586, align 8
  %v3736 = load i32, ptr %slot586, align 8
  %cv3737 = zext i32 %v3736 to i64
  %cond3738 = icmp ne i64 %cv3737, 0
  br i1 %cond3738, label %bb_rcslotrole832, label %bb_rcslotowner832
bb_rcslotrole832:
  %v3739 = load i64, ptr %slot69, align 8
  store i64 %v3739, ptr %slot587, align 8
  %v3740 = load i64, ptr %slot587, align 8
  %v3741 = load i64, ptr %slot584, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3740, i64 %v3741) nomerge, !dbg !132
  br label %bb_rcslotdone832
bb_rcslotowner832:
  %v3742 = load i64, ptr %slot69, align 8
  store i64 %v3742, ptr %slot588, align 8
  %v3743 = load i64, ptr %slot588, align 8
  %v3744 = load i64, ptr %slot584, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3743, i64 %v3744) nomerge, !dbg !132
  br label %bb_rcslotdone832
bb_rcslotdone832:
  br label %bb_rcprepared806
bb_rcprepared806:
  %v3745 = load i64, ptr %slot41, align 8
  store i64 %v3745, ptr %slot589, align 8
  %v3746 = load i64, ptr %slot589, align 8
  %v3747 = load i64, ptr %slot567, align 8
  %p3748 = inttoptr i64 %v3746 to ptr
  %p3749 = inttoptr i64 %v3747 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3749, ptr %p3748, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3750 = load i64, ptr %slot29, align 8
  %p3751 = inttoptr i64 %v3750 to ptr
  store i32 0, ptr %p3751, align 4, !alias.scope !3, !noalias !4
  %v3752 = load i64, ptr %slot55, align 8
  %p3753 = inttoptr i64 %v3752 to ptr
  %ld3754 = load i64, ptr %p3753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3754, ptr %slot590, align 8
  %v3755 = load i64, ptr %slot415, align 8
  %p3757 = inttoptr i64 %v3755 to ptr
  %gep3758 = getelementptr i8, ptr %p3757, i64 328
  %op3756 = ptrtoint ptr %gep3758 to i64
  store i64 %op3756, ptr %slot591, align 8
  %v3759 = load i64, ptr %slot55, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  %ld3761 = load i64, ptr %p3760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3761, ptr %slot592, align 8
  store i32 0, ptr %slot593, align 8
  %v3762 = load i64, ptr %slot24, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %ld3764 = load i32, ptr %p3763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3764, ptr %slot594, align 8
  %v3765 = load i32, ptr %slot594, align 8
  %op3766 = and i32 %v3765, 24
  store i32 %op3766, ptr %slot594, align 8
  %v3767 = load i32, ptr %slot594, align 8
  %cmp3768 = icmp eq i32 %v3767, 0
  %cv3769 = zext i1 %cmp3768 to i32
  store i32 %cv3769, ptr %slot595, align 8
  %v3770 = load i32, ptr %slot593, align 8
  %v3771 = load i32, ptr %slot595, align 8
  %op3772 = and i32 %v3770, %v3771
  store i32 %op3772, ptr %slot596, align 8
  %v3773 = load i32, ptr %slot596, align 8
  %cv3774 = zext i32 %v3773 to i64
  %cond3775 = icmp ne i64 %cv3774, 0
  br i1 %cond3775, label %bb_rctake844, label %bb_rccopy844
bb_rctake844:
  %v3776 = load i64, ptr %slot41, align 8
  store i64 %v3776, ptr %slot597, align 8
  %v3777 = load i64, ptr %slot70, align 8
  store i64 %v3777, ptr %slot598, align 8
  %v3778 = load i64, ptr %slot69, align 8
  %v3779 = load i64, ptr %slot597, align 8
  %v3780 = load i64, ptr %slot592, align 8
  %v3781 = load i64, ptr %slot598, align 8
  %cv3782 = trunc i64 %v3781 to i32
  %call3783 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v3778, i64 %v3779, i64 %v3780, i32 %cv3782) nomerge, !dbg !132
  store i32 %call3783, ptr %slot599, align 8
  %v3784 = load i32, ptr %slot599, align 8
  %cv3785 = zext i32 %v3784 to i64
  %cond3786 = icmp ne i64 %cv3785, 0
  br i1 %cond3786, label %bb_rcsuccess854, label %bb_rcfailure854
bb_rcfailure854:
  %v3787 = load i64, ptr %slot69, align 8
  %p3788 = inttoptr i64 %v3787 to ptr
  %call3789 = call i32 @myl_rc_take_failure(ptr %p3788) nomerge, !dbg !132
  store i32 %call3789, ptr %slot600, align 8
  %v3790 = load i64, ptr %slot1, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  %v3792 = load i32, ptr %slot600, align 8
  %call3793 = call i32 @myl_qbe_rc_status(ptr %p3791, i32 %v3792) nomerge, !dbg !132
  store i32 %call3793, ptr %slot601, align 8
  br label %bb_failure
bb_rcsuccess854:
  %v3794 = load i64, ptr %slot30, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  store i32 2, ptr %p3795, align 4, !alias.scope !3, !noalias !4
  %v3796 = load i64, ptr %slot29, align 8
  %p3797 = inttoptr i64 %v3796 to ptr
  store i32 1, ptr %p3797, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared844
bb_rccopy844:
  %v3798 = load i64, ptr %slot41, align 8
  store i64 %v3798, ptr %slot602, align 8
  %v3799 = load i64, ptr %slot70, align 8
  store i64 %v3799, ptr %slot603, align 8
  %v3800 = load i64, ptr %slot69, align 8
  %v3801 = load i64, ptr %slot602, align 8
  %v3802 = load i64, ptr %slot592, align 8
  %v3803 = load i64, ptr %slot603, align 8
  %cv3804 = trunc i64 %v3803 to i32
  %call3805 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v3800, i64 %v3801, i64 %v3802, i32 %cv3804) nomerge, !dbg !132
  store i32 %call3805, ptr %slot604, align 8
  %v3806 = load i32, ptr %slot604, align 8
  %cv3807 = zext i32 %v3806 to i64
  %cond3808 = icmp ne i64 %cv3807, 0
  br i1 %cond3808, label %bb_rcsuccess863, label %bb_rcfailure863
bb_rcfailure863:
  %v3809 = load i64, ptr %slot69, align 8
  %p3810 = inttoptr i64 %v3809 to ptr
  %call3811 = call i32 @myl_rc_take_failure(ptr %p3810) nomerge, !dbg !132
  store i32 %call3811, ptr %slot605, align 8
  %v3812 = load i64, ptr %slot1, align 8
  %p3813 = inttoptr i64 %v3812 to ptr
  %v3814 = load i32, ptr %slot605, align 8
  %call3815 = call i32 @myl_qbe_rc_status(ptr %p3813, i32 %v3814) nomerge, !dbg !132
  store i32 %call3815, ptr %slot606, align 8
  br label %bb_failure
bb_rcsuccess863:
  %v3816 = load i64, ptr %slot30, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  store i32 2, ptr %p3817, align 4, !alias.scope !3, !noalias !4
  %v3818 = load i64, ptr %slot29, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  store i32 1, ptr %p3819, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared844
bb_rcprepared844:
  %v3820 = load i64, ptr %slot41, align 8
  store i64 %v3820, ptr %slot607, align 8
  %v3821 = load i64, ptr %slot607, align 8
  %v3822 = load i64, ptr %slot591, align 8
  %p3823 = inttoptr i64 %v3821 to ptr
  %p3824 = inttoptr i64 %v3822 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3824, ptr %p3823, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3825 = load i64, ptr %slot29, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  store i32 0, ptr %p3826, align 4, !alias.scope !3, !noalias !4
  %v3827 = load i64, ptr %slot56, align 8
  store i64 %v3827, ptr %slot608, align 8
  %v3828 = load i64, ptr %slot415, align 8
  %p3830 = inttoptr i64 %v3828 to ptr
  %gep3831 = getelementptr i8, ptr %p3830, i64 368
  %op3829 = ptrtoint ptr %gep3831 to i64
  store i64 %op3829, ptr %slot609, align 8
  %v3832 = load i64, ptr %slot608, align 8
  %p3833 = inttoptr i64 %v3832 to ptr
  %ld3834 = load i8, ptr %p3833, align 1, !alias.scope !3, !noalias !4
  %ext3835 = zext i8 %ld3834 to i64
  store i64 %ext3835, ptr %slot610, align 8
  %v3836 = load i64, ptr %slot610, align 8
  %cv3837 = trunc i64 %v3836 to i8
  %v3838 = load i64, ptr %slot609, align 8
  %p3839 = inttoptr i64 %v3838 to ptr
  store i8 %cv3837, ptr %p3839, align 1, !alias.scope !3, !noalias !4
  %v3840 = load i64, ptr %slot57, align 8
  store i64 %v3840, ptr %slot611, align 8
  %v3841 = load i64, ptr %slot415, align 8
  %p3843 = inttoptr i64 %v3841 to ptr
  %gep3844 = getelementptr i8, ptr %p3843, i64 369
  %op3842 = ptrtoint ptr %gep3844 to i64
  store i64 %op3842, ptr %slot612, align 8
  %v3845 = load i64, ptr %slot611, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  %ld3847 = load i8, ptr %p3846, align 1, !alias.scope !3, !noalias !4
  %ext3848 = zext i8 %ld3847 to i64
  store i64 %ext3848, ptr %slot613, align 8
  %v3849 = load i64, ptr %slot613, align 8
  %cv3850 = trunc i64 %v3849 to i8
  %v3851 = load i64, ptr %slot612, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  store i8 %cv3850, ptr %p3852, align 1, !alias.scope !3, !noalias !4
  %v3853 = load i64, ptr %slot58, align 8
  %p3854 = inttoptr i64 %v3853 to ptr
  %ld3855 = load i64, ptr %p3854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3855, ptr %slot614, align 8
  %v3856 = load i64, ptr %slot614, align 8
  %v3857 = load i64, ptr %slot39, align 8
  %p3858 = inttoptr i64 %v3857 to ptr
  store i64 %v3856, ptr %p3858, align 8, !alias.scope !3, !noalias !4
  %v3859 = load i64, ptr %slot39, align 8
  store i64 %v3859, ptr %slot615, align 8
  %v3860 = load i64, ptr %slot415, align 8
  %p3862 = inttoptr i64 %v3860 to ptr
  %gep3863 = getelementptr i8, ptr %p3862, i64 376
  %op3861 = ptrtoint ptr %gep3863 to i64
  store i64 %op3861, ptr %slot616, align 8
  %v3864 = load i64, ptr %slot58, align 8
  %p3865 = inttoptr i64 %v3864 to ptr
  %ld3866 = load i64, ptr %p3865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3866, ptr %slot617, align 8
  %v3867 = load i64, ptr %slot617, align 8
  %v3868 = load i64, ptr %slot39, align 8
  %p3869 = inttoptr i64 %v3868 to ptr
  store i64 %v3867, ptr %p3869, align 8, !alias.scope !3, !noalias !4
  %v3870 = load i64, ptr %slot39, align 8
  store i64 %v3870, ptr %slot618, align 8
  %v3871 = load i64, ptr %slot25, align 8
  %p3872 = inttoptr i64 %v3871 to ptr
  %ld3873 = load i32, ptr %p3872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3873, ptr %slot619, align 8
  %v3874 = load i64, ptr %slot26, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  %ld3876 = load i32, ptr %p3875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3876, ptr %slot620, align 8
  %v3877 = load i32, ptr %slot620, align 8
  %op3878 = and i32 %v3877, 24
  store i32 %op3878, ptr %slot620, align 8
  %v3879 = load i32, ptr %slot620, align 8
  %cmp3880 = icmp eq i32 %v3879, 0
  %cv3881 = zext i1 %cmp3880 to i32
  store i32 %cv3881, ptr %slot621, align 8
  %v3882 = load i32, ptr %slot619, align 8
  %v3883 = load i32, ptr %slot621, align 8
  %op3884 = and i32 %v3882, %v3883
  store i32 %op3884, ptr %slot622, align 8
  %v3885 = load i32, ptr %slot622, align 8
  %cv3886 = zext i32 %v3885 to i64
  %cond3887 = icmp ne i64 %cv3886, 0
  br i1 %cond3887, label %bb_rctake890, label %bb_rccopy890
bb_rctake890:
  %v3888 = load i64, ptr %slot41, align 8
  store i64 %v3888, ptr %slot623, align 8
  %v3889 = load i64, ptr %slot70, align 8
  store i64 %v3889, ptr %slot624, align 8
  %v3890 = load i64, ptr %slot618, align 8
  %v3891 = load i64, ptr %slot623, align 8
  %op3892 = sub i64 %v3890, %v3891
  store i64 %op3892, ptr %slot625, align 8
  %v3893 = load i64, ptr %slot623, align 8
  %v3894 = load i64, ptr %slot618, align 8
  %op3895 = sub i64 %v3893, %v3894
  store i64 %op3895, ptr %slot626, align 8
  %v3896 = load i64, ptr %slot625, align 8
  %cmp3897 = icmp ult i64 %v3896, 8
  %cv3898 = zext i1 %cmp3897 to i32
  store i32 %cv3898, ptr %slot627, align 8
  %v3899 = load i64, ptr %slot626, align 8
  %cmp3900 = icmp ult i64 %v3899, 8
  %cv3901 = zext i1 %cmp3900 to i32
  store i32 %cv3901, ptr %slot628, align 8
  %v3902 = load i32, ptr %slot627, align 8
  %v3903 = load i32, ptr %slot628, align 8
  %op3904 = or i32 %v3902, %v3903
  store i32 %op3904, ptr %slot629, align 8
  %v3905 = load i32, ptr %slot629, align 8
  %cv3906 = zext i32 %v3905 to i64
  %cond3907 = icmp ne i64 %cv3906, 0
  br i1 %cond3907, label %bb_rcmoveslow899, label %bb_rcmovecheck899
bb_rcmovecheck899:
  %v3908 = load i64, ptr %slot618, align 8
  %p3910 = inttoptr i64 %v3908 to ptr
  %gep3911 = getelementptr i8, ptr %p3910, i64 0
  %op3909 = ptrtoint ptr %gep3911 to i64
  store i64 %op3909, ptr %slot630, align 8
  %v3912 = load i64, ptr %slot630, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  %ld3914 = load i64, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3914, ptr %slot631, align 8
  %v3915 = load i64, ptr %slot631, align 8
  %cmp3916 = icmp ne i64 %v3915, 0
  %cv3917 = zext i1 %cmp3916 to i32
  store i32 %cv3917, ptr %slot632, align 8
  %v3918 = load i32, ptr %slot632, align 8
  %cv3919 = zext i32 %v3918 to i64
  %cond3920 = icmp ne i64 %cv3919, 0
  br i1 %cond3920, label %bb_rcmoveheader907, label %bb_rcmovenext907
bb_rcmoveheader907:
  %v3921 = load i64, ptr %slot631, align 8
  %op3922 = sub i64 %v3921, 16
  store i64 %op3922, ptr %slot633, align 8
  %v3923 = load i64, ptr %slot631, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  %rgep3925 = getelementptr i8, ptr %p3924, i64 -16
  %ld3926 = load i64, ptr %rgep3925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3926, ptr %slot634, align 8
  %v3927 = load i64, ptr %slot634, align 8
  %op3928 = and i64 %v3927, 5764607523034234881
  store i64 %op3928, ptr %slot635, align 8
  %v3929 = load i64, ptr %slot635, align 8
  %cmp3930 = icmp ne i64 %v3929, 0
  %cv3931 = zext i1 %cmp3930 to i32
  store i32 %cv3931, ptr %slot636, align 8
  %v3932 = load i32, ptr %slot636, align 8
  %cv3933 = zext i32 %v3932 to i64
  %cond3934 = icmp ne i64 %cv3933, 0
  br i1 %cond3934, label %bb_rcmoveslow899, label %bb_rcmovenext907
bb_rcmovenext907:
  %v3935 = load i64, ptr %slot618, align 8
  %v3936 = load i64, ptr %slot623, align 8
  %p3937 = inttoptr i64 %v3935 to ptr
  %p3938 = inttoptr i64 %v3936 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3938, ptr %p3937, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3939 = load i64, ptr %slot618, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  store i64 0, ptr %p3940, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved899
bb_rcmoveslow899:
  %v3941 = load i64, ptr %slot69, align 8
  %v3942 = load i64, ptr %slot623, align 8
  %v3943 = load i64, ptr %slot618, align 8
  %v3944 = load i64, ptr %slot624, align 8
  %cv3945 = trunc i64 %v3944 to i32
  %call3946 = call i32 @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_take(i64 %v3941, i64 %v3942, i64 %v3943, i32 %cv3945) nomerge, !dbg !132
  store i32 %call3946, ptr %slot637, align 8
  %v3947 = load i32, ptr %slot637, align 8
  %cv3948 = zext i32 %v3947 to i64
  %cond3949 = icmp ne i64 %cv3948, 0
  br i1 %cond3949, label %bb_rcsuccess914, label %bb_rcfailure914
bb_rcfailure914:
  %v3950 = load i64, ptr %slot69, align 8
  %p3951 = inttoptr i64 %v3950 to ptr
  %call3952 = call i32 @myl_rc_take_failure(ptr %p3951) nomerge, !dbg !132
  store i32 %call3952, ptr %slot638, align 8
  %v3953 = load i64, ptr %slot1, align 8
  %p3954 = inttoptr i64 %v3953 to ptr
  %v3955 = load i32, ptr %slot638, align 8
  %call3956 = call i32 @myl_qbe_rc_status(ptr %p3954, i32 %v3955) nomerge, !dbg !132
  store i32 %call3956, ptr %slot639, align 8
  br label %bb_failure
bb_rcsuccess914:
  br label %bb_rcmoved899
bb_rcmoved899:
  %v3957 = load i64, ptr %slot25, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  store i32 0, ptr %p3958, align 4, !alias.scope !3, !noalias !4
  %v3959 = load i64, ptr %slot30, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  store i32 2, ptr %p3960, align 4, !alias.scope !3, !noalias !4
  %v3961 = load i64, ptr %slot29, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  store i32 1, ptr %p3962, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared890
bb_rccopy890:
  %v3963 = load i64, ptr %slot41, align 8
  store i64 %v3963, ptr %slot640, align 8
  %v3964 = load i64, ptr %slot70, align 8
  store i64 %v3964, ptr %slot641, align 8
  %v3965 = load i64, ptr %slot618, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  %ld3967 = load i64, ptr %p3966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3967, ptr %slot642, align 8
  %v3968 = load i64, ptr %slot642, align 8
  %cmp3969 = icmp ne i64 %v3968, 0
  %cv3970 = zext i1 %cmp3969 to i32
  store i32 %cv3970, ptr %slot643, align 8
  %v3971 = load i32, ptr %slot643, align 8
  %cv3972 = zext i32 %v3971 to i64
  %cond3973 = icmp ne i64 %cv3972, 0
  br i1 %cond3973, label %bb_rcgnn923, label %bb_rcgplain923
bb_rcgnn923:
  %v3974 = load i64, ptr %slot642, align 8
  %op3975 = sub i64 %v3974, 16
  store i64 %op3975, ptr %slot644, align 8
  %v3976 = load i64, ptr %slot642, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  %rgep3978 = getelementptr i8, ptr %p3977, i64 -16
  %ld3979 = load i64, ptr %rgep3978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3979, ptr %slot645, align 8
  %v3980 = load i64, ptr %slot645, align 8
  %op3981 = and i64 %v3980, 4611686018427387906
  store i64 %op3981, ptr %slot646, align 8
  %v3982 = load i64, ptr %slot646, align 8
  %cmp3983 = icmp ne i64 %v3982, 0
  %cv3984 = zext i1 %cmp3983 to i32
  store i32 %cv3984, ptr %slot647, align 8
  %v3985 = load i32, ptr %slot647, align 8
  %cv3986 = zext i32 %v3985 to i64
  %cond3987 = icmp ne i64 %cv3986, 0
  br i1 %cond3987, label %bb_rcgspecial923, label %bb_rcginc923
bb_rcginc923:
  %v3988 = load i64, ptr %slot642, align 8
  %op3989 = sub i64 %v3988, 32
  store i64 %op3989, ptr %slot648, align 8
  %v3990 = load i64, ptr %slot642, align 8
  %p3991 = inttoptr i64 %v3990 to ptr
  %rgep3992 = getelementptr i8, ptr %p3991, i64 -32
  %ld3993 = load i64, ptr %rgep3992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3993, ptr %slot649, align 8
  %v3994 = load i64, ptr %slot649, align 8
  %op3995 = add i64 %v3994, 1
  store i64 %op3995, ptr %slot650, align 8
  %v3996 = load i64, ptr %slot650, align 8
  %cmp3997 = icmp eq i64 %v3996, 0
  %cv3998 = zext i1 %cmp3997 to i32
  store i32 %cv3998, ptr %slot651, align 8
  %v3999 = load i32, ptr %slot651, align 8
  %cv4000 = zext i32 %v3999 to i64
  %cond4001 = icmp ne i64 %cv4000, 0
  br i1 %cond4001, label %bb_rcglimit923, label %bb_rcgcapacity923
bb_rcglimit923:
  %v4002 = load i64, ptr %slot1, align 8
  %p4003 = inttoptr i64 %v4002 to ptr
  %call4004 = call i32 @myl_qbe_rc_status(ptr %p4003, i32 2) nomerge, !dbg !132
  store i32 %call4004, ptr %slot652, align 8
  br label %bb_failure
bb_rcgcapacity923:
  %v4005 = load i64, ptr %slot650, align 8
  %v4006 = load i64, ptr %slot642, align 8
  %p4007 = inttoptr i64 %v4006 to ptr
  %rgep4008 = getelementptr i8, ptr %p4007, i64 -32
  store i64 %v4005, ptr %rgep4008, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain923
bb_rcgspecial923:
  %v4009 = load i64, ptr %slot645, align 8
  %op4010 = and i64 %v4009, 4611686018427387904
  store i64 %op4010, ptr %slot653, align 8
  %v4011 = load i64, ptr %slot653, align 8
  %cmp4012 = icmp ne i64 %v4011, 0
  %cv4013 = zext i1 %cmp4012 to i32
  store i32 %cv4013, ptr %slot654, align 8
  %v4014 = load i32, ptr %slot654, align 8
  %cv4015 = zext i32 %v4014 to i64
  %cond4016 = icmp ne i64 %cv4015, 0
  br i1 %cond4016, label %bb_rcgslow923, label %bb_rcgplain923
bb_rcgslow923:
  %v4017 = load i64, ptr %slot69, align 8
  %v4018 = load i64, ptr %slot640, align 8
  %v4019 = load i64, ptr %slot618, align 8
  %v4020 = load i64, ptr %slot641, align 8
  %cv4021 = trunc i64 %v4020 to i32
  %call4022 = call i32 @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_retain(i64 %v4017, i64 %v4018, i64 %v4019, i32 %cv4021) nomerge, !dbg !132
  store i32 %call4022, ptr %slot655, align 8
  %v4023 = load i32, ptr %slot655, align 8
  %cv4024 = zext i32 %v4023 to i64
  %cond4025 = icmp ne i64 %cv4024, 0
  br i1 %cond4025, label %bb_rcsuccess937, label %bb_rcfailure937
bb_rcfailure937:
  %v4026 = load i64, ptr %slot69, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  %call4028 = call i32 @myl_rc_take_failure(ptr %p4027) nomerge, !dbg !132
  store i32 %call4028, ptr %slot656, align 8
  %v4029 = load i64, ptr %slot1, align 8
  %p4030 = inttoptr i64 %v4029 to ptr
  %v4031 = load i32, ptr %slot656, align 8
  %call4032 = call i32 @myl_qbe_rc_status(ptr %p4030, i32 %v4031) nomerge, !dbg !132
  store i32 %call4032, ptr %slot657, align 8
  br label %bb_failure
bb_rcsuccess937:
  br label %bb_rcgdone923
bb_rcgplain923:
  %v4033 = load i64, ptr %slot642, align 8
  %v4034 = load i64, ptr %slot640, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  store i64 %v4033, ptr %p4035, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone923
bb_rcgdone923:
  %v4036 = load i64, ptr %slot30, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  store i32 2, ptr %p4037, align 4, !alias.scope !3, !noalias !4
  %v4038 = load i64, ptr %slot29, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  store i32 1, ptr %p4039, align 4, !alias.scope !3, !noalias !4
  %v4040 = load i64, ptr %slot25, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %ld4042 = load i32, ptr %p4041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4042, ptr %slot658, align 8
  %v4043 = load i32, ptr %slot658, align 8
  %cv4044 = zext i32 %v4043 to i64
  %cond4045 = icmp ne i64 %cv4044, 0
  br i1 %cond4045, label %bb_rcslotdrop944, label %bb_rcslotdone944
bb_rcslotdrop944:
  %v4046 = load i64, ptr %slot25, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  store i32 0, ptr %p4047, align 4, !alias.scope !3, !noalias !4
  %v4048 = load i64, ptr %slot35, align 8
  store i64 %v4048, ptr %slot659, align 8
  %v4049 = load i64, ptr %slot26, align 8
  %p4050 = inttoptr i64 %v4049 to ptr
  %ld4051 = load i32, ptr %p4050, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4051, ptr %slot660, align 8
  %v4052 = load i32, ptr %slot660, align 8
  %op4053 = and i32 %v4052, 28
  store i32 %op4053, ptr %slot661, align 8
  %v4054 = load i32, ptr %slot661, align 8
  %cv4055 = zext i32 %v4054 to i64
  %cond4056 = icmp ne i64 %cv4055, 0
  br i1 %cond4056, label %bb_rcslotrole944, label %bb_rcslotowner944
bb_rcslotrole944:
  %v4057 = load i64, ptr %slot69, align 8
  store i64 %v4057, ptr %slot662, align 8
  %v4058 = load i64, ptr %slot659, align 8
  %p4059 = inttoptr i64 %v4058 to ptr
  %ld4060 = load i64, ptr %p4059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4060, ptr %slot663, align 8
  %v4061 = load i64, ptr %slot663, align 8
  %cmp4062 = icmp ne i64 %v4061, 0
  %cv4063 = zext i1 %cmp4062 to i32
  store i32 %cv4063, ptr %slot664, align 8
  %v4064 = load i32, ptr %slot664, align 8
  %cv4065 = zext i32 %v4064 to i64
  %cond4066 = icmp ne i64 %cv4065, 0
  br i1 %cond4066, label %bb_rcgnn960, label %bb_rcgdone960
bb_rcgnn960:
  %v4067 = load i64, ptr %slot663, align 8
  %op4068 = sub i64 %v4067, 16
  store i64 %op4068, ptr %slot665, align 8
  %v4069 = load i64, ptr %slot663, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  %rgep4071 = getelementptr i8, ptr %p4070, i64 -16
  %ld4072 = load i64, ptr %rgep4071, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4072, ptr %slot666, align 8
  %v4073 = load i64, ptr %slot666, align 8
  %op4074 = and i64 %v4073, 4611686018427387906
  store i64 %op4074, ptr %slot667, align 8
  %v4075 = load i64, ptr %slot667, align 8
  %cmp4076 = icmp ne i64 %v4075, 0
  %cv4077 = zext i1 %cmp4076 to i32
  store i32 %cv4077, ptr %slot668, align 8
  %v4078 = load i32, ptr %slot668, align 8
  %cv4079 = zext i32 %v4078 to i64
  %cond4080 = icmp ne i64 %cv4079, 0
  br i1 %cond4080, label %bb_rcgclear960, label %bb_rcgcounted960
bb_rcgcounted960:
  %v4081 = load i64, ptr %slot663, align 8
  %op4082 = sub i64 %v4081, 24
  store i64 %op4082, ptr %slot669, align 8
  %v4083 = load i64, ptr %slot663, align 8
  %p4084 = inttoptr i64 %v4083 to ptr
  %rgep4085 = getelementptr i8, ptr %p4084, i64 -24
  %ld4086 = load i64, ptr %rgep4085, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4086, ptr %slot670, align 8
  %v4087 = load i64, ptr %slot670, align 8
  %op4088 = sub i64 %v4087, 1
  store i64 %op4088, ptr %slot671, align 8
  %v4089 = load i64, ptr %slot671, align 8
  %cmp4090 = icmp eq i64 %v4089, 0
  %cv4091 = zext i1 %cmp4090 to i32
  store i32 %cv4091, ptr %slot672, align 8
  %v4092 = load i32, ptr %slot672, align 8
  %cv4093 = zext i32 %v4092 to i64
  %cond4094 = icmp ne i64 %cv4093, 0
  br i1 %cond4094, label %bb_rcglast960, label %bb_rcgdec960
bb_rcglast960:
  %v4095 = load i64, ptr %slot663, align 8
  %op4096 = sub i64 %v4095, 32
  store i64 %op4096, ptr %slot673, align 8
  %v4097 = load i64, ptr %slot663, align 8
  %p4098 = inttoptr i64 %v4097 to ptr
  %rgep4099 = getelementptr i8, ptr %p4098, i64 -32
  %ld4100 = load i64, ptr %rgep4099, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4100, ptr %slot674, align 8
  %v4101 = load i64, ptr %slot674, align 8
  %cmp4102 = icmp ne i64 %v4101, 0
  %cv4103 = zext i1 %cmp4102 to i32
  store i32 %cv4103, ptr %slot675, align 8
  %v4104 = load i32, ptr %slot675, align 8
  %cv4105 = zext i32 %v4104 to i64
  %cond4106 = icmp ne i64 %cv4105, 0
  br i1 %cond4106, label %bb_rcgdec960, label %bb_rcgslow960
bb_rcgslow960:
  %v4107 = load i64, ptr %slot662, align 8
  %v4108 = load i64, ptr %slot659, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v4107, i64 %v4108) nomerge, !dbg !132
  br label %bb_rcgdone960
bb_rcgdec960:
  %v4109 = load i64, ptr %slot671, align 8
  %v4110 = load i64, ptr %slot663, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  %rgep4112 = getelementptr i8, ptr %p4111, i64 -24
  store i64 %v4109, ptr %rgep4112, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear960
bb_rcgclear960:
  %v4113 = load i64, ptr %slot659, align 8
  %p4114 = inttoptr i64 %v4113 to ptr
  store i64 0, ptr %p4114, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone960
bb_rcgdone960:
  br label %bb_rcslotdone944
bb_rcslotowner944:
  %v4115 = load i64, ptr %slot69, align 8
  store i64 %v4115, ptr %slot676, align 8
  %v4116 = load i64, ptr %slot659, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  %ld4118 = load i64, ptr %p4117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4118, ptr %slot677, align 8
  %v4119 = load i64, ptr %slot677, align 8
  %cmp4120 = icmp ne i64 %v4119, 0
  %cv4121 = zext i1 %cmp4120 to i32
  store i32 %cv4121, ptr %slot678, align 8
  %v4122 = load i32, ptr %slot678, align 8
  %cv4123 = zext i32 %v4122 to i64
  %cond4124 = icmp ne i64 %cv4123, 0
  br i1 %cond4124, label %bb_rcgnn975, label %bb_rcgdone975
bb_rcgnn975:
  %v4125 = load i64, ptr %slot677, align 8
  %op4126 = sub i64 %v4125, 16
  store i64 %op4126, ptr %slot679, align 8
  %v4127 = load i64, ptr %slot677, align 8
  %p4128 = inttoptr i64 %v4127 to ptr
  %rgep4129 = getelementptr i8, ptr %p4128, i64 -16
  %ld4130 = load i64, ptr %rgep4129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4130, ptr %slot680, align 8
  %v4131 = load i64, ptr %slot680, align 8
  %op4132 = and i64 %v4131, 4611686018427387906
  store i64 %op4132, ptr %slot681, align 8
  %v4133 = load i64, ptr %slot681, align 8
  %cmp4134 = icmp ne i64 %v4133, 0
  %cv4135 = zext i1 %cmp4134 to i32
  store i32 %cv4135, ptr %slot682, align 8
  %v4136 = load i32, ptr %slot682, align 8
  %cv4137 = zext i32 %v4136 to i64
  %cond4138 = icmp ne i64 %cv4137, 0
  br i1 %cond4138, label %bb_rcgclear975, label %bb_rcgcounted975
bb_rcgcounted975:
  %v4139 = load i64, ptr %slot677, align 8
  %op4140 = sub i64 %v4139, 32
  store i64 %op4140, ptr %slot683, align 8
  %v4141 = load i64, ptr %slot677, align 8
  %p4142 = inttoptr i64 %v4141 to ptr
  %rgep4143 = getelementptr i8, ptr %p4142, i64 -32
  %ld4144 = load i64, ptr %rgep4143, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4144, ptr %slot684, align 8
  %v4145 = load i64, ptr %slot684, align 8
  %op4146 = sub i64 %v4145, 1
  store i64 %op4146, ptr %slot685, align 8
  %v4147 = load i64, ptr %slot685, align 8
  %cmp4148 = icmp eq i64 %v4147, 0
  %cv4149 = zext i1 %cmp4148 to i32
  store i32 %cv4149, ptr %slot686, align 8
  %v4150 = load i32, ptr %slot686, align 8
  %cv4151 = zext i32 %v4150 to i64
  %cond4152 = icmp ne i64 %cv4151, 0
  br i1 %cond4152, label %bb_rcglast975, label %bb_rcgdec975
bb_rcglast975:
  %v4153 = load i64, ptr %slot677, align 8
  %op4154 = sub i64 %v4153, 24
  store i64 %op4154, ptr %slot687, align 8
  %v4155 = load i64, ptr %slot677, align 8
  %p4156 = inttoptr i64 %v4155 to ptr
  %rgep4157 = getelementptr i8, ptr %p4156, i64 -24
  %ld4158 = load i64, ptr %rgep4157, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4158, ptr %slot688, align 8
  %v4159 = load i64, ptr %slot688, align 8
  %cmp4160 = icmp ne i64 %v4159, 0
  %cv4161 = zext i1 %cmp4160 to i32
  store i32 %cv4161, ptr %slot689, align 8
  %v4162 = load i32, ptr %slot689, align 8
  %cv4163 = zext i32 %v4162 to i64
  %cond4164 = icmp ne i64 %cv4163, 0
  br i1 %cond4164, label %bb_rcgdec975, label %bb_rcgslow975
bb_rcgslow975:
  %v4165 = load i64, ptr %slot676, align 8
  %v4166 = load i64, ptr %slot659, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v4165, i64 %v4166) nomerge, !dbg !132
  br label %bb_rcgdone975
bb_rcgdec975:
  %v4167 = load i64, ptr %slot685, align 8
  %v4168 = load i64, ptr %slot677, align 8
  %p4169 = inttoptr i64 %v4168 to ptr
  %rgep4170 = getelementptr i8, ptr %p4169, i64 -32
  store i64 %v4167, ptr %rgep4170, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear975
bb_rcgclear975:
  %v4171 = load i64, ptr %slot659, align 8
  %p4172 = inttoptr i64 %v4171 to ptr
  store i64 0, ptr %p4172, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone975
bb_rcgdone975:
  br label %bb_rcslotdone944
bb_rcslotdone944:
  br label %bb_rcprepared890
bb_rcprepared890:
  %v4173 = load i64, ptr %slot41, align 8
  store i64 %v4173, ptr %slot690, align 8
  %v4174 = load i64, ptr %slot690, align 8
  %v4175 = load i64, ptr %slot616, align 8
  %p4176 = inttoptr i64 %v4174 to ptr
  %p4177 = inttoptr i64 %v4175 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4177, ptr %p4176, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4178 = load i64, ptr %slot29, align 8
  %p4179 = inttoptr i64 %v4178 to ptr
  store i32 0, ptr %p4179, align 4, !alias.scope !3, !noalias !4
  %v4180 = load i64, ptr %slot59, align 8
  %p4181 = inttoptr i64 %v4180 to ptr
  %ld4182 = load i64, ptr %p4181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4182, ptr %slot691, align 8
  %v4183 = load i64, ptr %slot691, align 8
  %v4184 = load i64, ptr %slot40, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  store i64 %v4183, ptr %p4185, align 8, !alias.scope !3, !noalias !4
  %v4186 = load i64, ptr %slot40, align 8
  store i64 %v4186, ptr %slot692, align 8
  %v4187 = load i64, ptr %slot415, align 8
  %p4189 = inttoptr i64 %v4187 to ptr
  %gep4190 = getelementptr i8, ptr %p4189, i64 384
  %op4188 = ptrtoint ptr %gep4190 to i64
  store i64 %op4188, ptr %slot693, align 8
  %v4191 = load i64, ptr %slot59, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  %ld4193 = load i64, ptr %p4192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4193, ptr %slot694, align 8
  %v4194 = load i64, ptr %slot694, align 8
  %v4195 = load i64, ptr %slot40, align 8
  %p4196 = inttoptr i64 %v4195 to ptr
  store i64 %v4194, ptr %p4196, align 8, !alias.scope !3, !noalias !4
  %v4197 = load i64, ptr %slot40, align 8
  store i64 %v4197, ptr %slot695, align 8
  %v4198 = load i64, ptr %slot27, align 8
  %p4199 = inttoptr i64 %v4198 to ptr
  %ld4200 = load i32, ptr %p4199, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4200, ptr %slot696, align 8
  %v4201 = load i64, ptr %slot28, align 8
  %p4202 = inttoptr i64 %v4201 to ptr
  %ld4203 = load i32, ptr %p4202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4203, ptr %slot697, align 8
  %v4204 = load i32, ptr %slot697, align 8
  %op4205 = and i32 %v4204, 24
  store i32 %op4205, ptr %slot697, align 8
  %v4206 = load i32, ptr %slot697, align 8
  %cmp4207 = icmp eq i32 %v4206, 0
  %cv4208 = zext i1 %cmp4207 to i32
  store i32 %cv4208, ptr %slot698, align 8
  %v4209 = load i32, ptr %slot696, align 8
  %v4210 = load i32, ptr %slot698, align 8
  %op4211 = and i32 %v4209, %v4210
  store i32 %op4211, ptr %slot699, align 8
  %v4212 = load i32, ptr %slot699, align 8
  %cv4213 = zext i32 %v4212 to i64
  %cond4214 = icmp ne i64 %cv4213, 0
  br i1 %cond4214, label %bb_rctake986, label %bb_rccopy986
bb_rctake986:
  %v4215 = load i64, ptr %slot41, align 8
  store i64 %v4215, ptr %slot700, align 8
  %v4216 = load i64, ptr %slot70, align 8
  store i64 %v4216, ptr %slot701, align 8
  %v4217 = load i64, ptr %slot695, align 8
  %v4218 = load i64, ptr %slot700, align 8
  %op4219 = sub i64 %v4217, %v4218
  store i64 %op4219, ptr %slot702, align 8
  %v4220 = load i64, ptr %slot700, align 8
  %v4221 = load i64, ptr %slot695, align 8
  %op4222 = sub i64 %v4220, %v4221
  store i64 %op4222, ptr %slot703, align 8
  %v4223 = load i64, ptr %slot702, align 8
  %cmp4224 = icmp ult i64 %v4223, 8
  %cv4225 = zext i1 %cmp4224 to i32
  store i32 %cv4225, ptr %slot704, align 8
  %v4226 = load i64, ptr %slot703, align 8
  %cmp4227 = icmp ult i64 %v4226, 8
  %cv4228 = zext i1 %cmp4227 to i32
  store i32 %cv4228, ptr %slot705, align 8
  %v4229 = load i32, ptr %slot704, align 8
  %v4230 = load i32, ptr %slot705, align 8
  %op4231 = or i32 %v4229, %v4230
  store i32 %op4231, ptr %slot706, align 8
  %v4232 = load i32, ptr %slot706, align 8
  %cv4233 = zext i32 %v4232 to i64
  %cond4234 = icmp ne i64 %cv4233, 0
  br i1 %cond4234, label %bb_rcmoveslow995, label %bb_rcmovecheck995
bb_rcmovecheck995:
  %v4235 = load i64, ptr %slot695, align 8
  %p4237 = inttoptr i64 %v4235 to ptr
  %gep4238 = getelementptr i8, ptr %p4237, i64 0
  %op4236 = ptrtoint ptr %gep4238 to i64
  store i64 %op4236, ptr %slot707, align 8
  %v4239 = load i64, ptr %slot707, align 8
  %p4240 = inttoptr i64 %v4239 to ptr
  %ld4241 = load i64, ptr %p4240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4241, ptr %slot708, align 8
  %v4242 = load i64, ptr %slot708, align 8
  %cmp4243 = icmp ne i64 %v4242, 0
  %cv4244 = zext i1 %cmp4243 to i32
  store i32 %cv4244, ptr %slot709, align 8
  %v4245 = load i32, ptr %slot709, align 8
  %cv4246 = zext i32 %v4245 to i64
  %cond4247 = icmp ne i64 %cv4246, 0
  br i1 %cond4247, label %bb_rcmoveheader1003, label %bb_rcmovenext1003
bb_rcmoveheader1003:
  %v4248 = load i64, ptr %slot708, align 8
  %op4249 = sub i64 %v4248, 16
  store i64 %op4249, ptr %slot710, align 8
  %v4250 = load i64, ptr %slot708, align 8
  %p4251 = inttoptr i64 %v4250 to ptr
  %rgep4252 = getelementptr i8, ptr %p4251, i64 -16
  %ld4253 = load i64, ptr %rgep4252, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4253, ptr %slot711, align 8
  %v4254 = load i64, ptr %slot711, align 8
  %op4255 = and i64 %v4254, 5764607523034234881
  store i64 %op4255, ptr %slot712, align 8
  %v4256 = load i64, ptr %slot712, align 8
  %cmp4257 = icmp ne i64 %v4256, 0
  %cv4258 = zext i1 %cmp4257 to i32
  store i32 %cv4258, ptr %slot713, align 8
  %v4259 = load i32, ptr %slot713, align 8
  %cv4260 = zext i32 %v4259 to i64
  %cond4261 = icmp ne i64 %cv4260, 0
  br i1 %cond4261, label %bb_rcmoveslow995, label %bb_rcmovenext1003
bb_rcmovenext1003:
  %v4262 = load i64, ptr %slot695, align 8
  %v4263 = load i64, ptr %slot700, align 8
  %p4264 = inttoptr i64 %v4262 to ptr
  %p4265 = inttoptr i64 %v4263 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4265, ptr %p4264, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4266 = load i64, ptr %slot695, align 8
  %p4267 = inttoptr i64 %v4266 to ptr
  store i64 0, ptr %p4267, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved995
bb_rcmoveslow995:
  %v4268 = load i64, ptr %slot69, align 8
  %v4269 = load i64, ptr %slot700, align 8
  %v4270 = load i64, ptr %slot695, align 8
  %v4271 = load i64, ptr %slot701, align 8
  %cv4272 = trunc i64 %v4271 to i32
  %call4273 = call i32 @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_take(i64 %v4268, i64 %v4269, i64 %v4270, i32 %cv4272) nomerge, !dbg !132
  store i32 %call4273, ptr %slot714, align 8
  %v4274 = load i32, ptr %slot714, align 8
  %cv4275 = zext i32 %v4274 to i64
  %cond4276 = icmp ne i64 %cv4275, 0
  br i1 %cond4276, label %bb_rcsuccess1010, label %bb_rcfailure1010
bb_rcfailure1010:
  %v4277 = load i64, ptr %slot69, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  %call4279 = call i32 @myl_rc_take_failure(ptr %p4278) nomerge, !dbg !132
  store i32 %call4279, ptr %slot715, align 8
  %v4280 = load i64, ptr %slot1, align 8
  %p4281 = inttoptr i64 %v4280 to ptr
  %v4282 = load i32, ptr %slot715, align 8
  %call4283 = call i32 @myl_qbe_rc_status(ptr %p4281, i32 %v4282) nomerge, !dbg !132
  store i32 %call4283, ptr %slot716, align 8
  br label %bb_failure
bb_rcsuccess1010:
  br label %bb_rcmoved995
bb_rcmoved995:
  %v4284 = load i64, ptr %slot27, align 8
  %p4285 = inttoptr i64 %v4284 to ptr
  store i32 0, ptr %p4285, align 4, !alias.scope !3, !noalias !4
  %v4286 = load i64, ptr %slot30, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  store i32 2, ptr %p4287, align 4, !alias.scope !3, !noalias !4
  %v4288 = load i64, ptr %slot29, align 8
  %p4289 = inttoptr i64 %v4288 to ptr
  store i32 1, ptr %p4289, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared986
bb_rccopy986:
  %v4290 = load i64, ptr %slot41, align 8
  store i64 %v4290, ptr %slot717, align 8
  %v4291 = load i64, ptr %slot70, align 8
  store i64 %v4291, ptr %slot718, align 8
  %v4292 = load i64, ptr %slot695, align 8
  %p4293 = inttoptr i64 %v4292 to ptr
  %ld4294 = load i64, ptr %p4293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4294, ptr %slot719, align 8
  %v4295 = load i64, ptr %slot719, align 8
  %cmp4296 = icmp ne i64 %v4295, 0
  %cv4297 = zext i1 %cmp4296 to i32
  store i32 %cv4297, ptr %slot720, align 8
  %v4298 = load i32, ptr %slot720, align 8
  %cv4299 = zext i32 %v4298 to i64
  %cond4300 = icmp ne i64 %cv4299, 0
  br i1 %cond4300, label %bb_rcgnn1019, label %bb_rcgplain1019
bb_rcgnn1019:
  %v4301 = load i64, ptr %slot719, align 8
  %op4302 = sub i64 %v4301, 16
  store i64 %op4302, ptr %slot721, align 8
  %v4303 = load i64, ptr %slot719, align 8
  %p4304 = inttoptr i64 %v4303 to ptr
  %rgep4305 = getelementptr i8, ptr %p4304, i64 -16
  %ld4306 = load i64, ptr %rgep4305, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4306, ptr %slot722, align 8
  %v4307 = load i64, ptr %slot722, align 8
  %op4308 = and i64 %v4307, 4611686018427387906
  store i64 %op4308, ptr %slot723, align 8
  %v4309 = load i64, ptr %slot723, align 8
  %cmp4310 = icmp ne i64 %v4309, 0
  %cv4311 = zext i1 %cmp4310 to i32
  store i32 %cv4311, ptr %slot724, align 8
  %v4312 = load i32, ptr %slot724, align 8
  %cv4313 = zext i32 %v4312 to i64
  %cond4314 = icmp ne i64 %cv4313, 0
  br i1 %cond4314, label %bb_rcgspecial1019, label %bb_rcginc1019
bb_rcginc1019:
  %v4315 = load i64, ptr %slot719, align 8
  %op4316 = sub i64 %v4315, 32
  store i64 %op4316, ptr %slot725, align 8
  %v4317 = load i64, ptr %slot719, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  %rgep4319 = getelementptr i8, ptr %p4318, i64 -32
  %ld4320 = load i64, ptr %rgep4319, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4320, ptr %slot726, align 8
  %v4321 = load i64, ptr %slot726, align 8
  %op4322 = add i64 %v4321, 1
  store i64 %op4322, ptr %slot727, align 8
  %v4323 = load i64, ptr %slot727, align 8
  %cmp4324 = icmp eq i64 %v4323, 0
  %cv4325 = zext i1 %cmp4324 to i32
  store i32 %cv4325, ptr %slot728, align 8
  %v4326 = load i32, ptr %slot728, align 8
  %cv4327 = zext i32 %v4326 to i64
  %cond4328 = icmp ne i64 %cv4327, 0
  br i1 %cond4328, label %bb_rcglimit1019, label %bb_rcgcapacity1019
bb_rcglimit1019:
  %v4329 = load i64, ptr %slot1, align 8
  %p4330 = inttoptr i64 %v4329 to ptr
  %call4331 = call i32 @myl_qbe_rc_status(ptr %p4330, i32 2) nomerge, !dbg !132
  store i32 %call4331, ptr %slot729, align 8
  br label %bb_failure
bb_rcgcapacity1019:
  %v4332 = load i64, ptr %slot727, align 8
  %v4333 = load i64, ptr %slot719, align 8
  %p4334 = inttoptr i64 %v4333 to ptr
  %rgep4335 = getelementptr i8, ptr %p4334, i64 -32
  store i64 %v4332, ptr %rgep4335, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1019
bb_rcgspecial1019:
  %v4336 = load i64, ptr %slot722, align 8
  %op4337 = and i64 %v4336, 4611686018427387904
  store i64 %op4337, ptr %slot730, align 8
  %v4338 = load i64, ptr %slot730, align 8
  %cmp4339 = icmp ne i64 %v4338, 0
  %cv4340 = zext i1 %cmp4339 to i32
  store i32 %cv4340, ptr %slot731, align 8
  %v4341 = load i32, ptr %slot731, align 8
  %cv4342 = zext i32 %v4341 to i64
  %cond4343 = icmp ne i64 %cv4342, 0
  br i1 %cond4343, label %bb_rcgslow1019, label %bb_rcgplain1019
bb_rcgslow1019:
  %v4344 = load i64, ptr %slot69, align 8
  %v4345 = load i64, ptr %slot717, align 8
  %v4346 = load i64, ptr %slot695, align 8
  %v4347 = load i64, ptr %slot718, align 8
  %cv4348 = trunc i64 %v4347 to i32
  %call4349 = call i32 @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_retain(i64 %v4344, i64 %v4345, i64 %v4346, i32 %cv4348) nomerge, !dbg !132
  store i32 %call4349, ptr %slot732, align 8
  %v4350 = load i32, ptr %slot732, align 8
  %cv4351 = zext i32 %v4350 to i64
  %cond4352 = icmp ne i64 %cv4351, 0
  br i1 %cond4352, label %bb_rcsuccess1033, label %bb_rcfailure1033
bb_rcfailure1033:
  %v4353 = load i64, ptr %slot69, align 8
  %p4354 = inttoptr i64 %v4353 to ptr
  %call4355 = call i32 @myl_rc_take_failure(ptr %p4354) nomerge, !dbg !132
  store i32 %call4355, ptr %slot733, align 8
  %v4356 = load i64, ptr %slot1, align 8
  %p4357 = inttoptr i64 %v4356 to ptr
  %v4358 = load i32, ptr %slot733, align 8
  %call4359 = call i32 @myl_qbe_rc_status(ptr %p4357, i32 %v4358) nomerge, !dbg !132
  store i32 %call4359, ptr %slot734, align 8
  br label %bb_failure
bb_rcsuccess1033:
  br label %bb_rcgdone1019
bb_rcgplain1019:
  %v4360 = load i64, ptr %slot719, align 8
  %v4361 = load i64, ptr %slot717, align 8
  %p4362 = inttoptr i64 %v4361 to ptr
  store i64 %v4360, ptr %p4362, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1019
bb_rcgdone1019:
  %v4363 = load i64, ptr %slot30, align 8
  %p4364 = inttoptr i64 %v4363 to ptr
  store i32 2, ptr %p4364, align 4, !alias.scope !3, !noalias !4
  %v4365 = load i64, ptr %slot29, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  store i32 1, ptr %p4366, align 4, !alias.scope !3, !noalias !4
  %v4367 = load i64, ptr %slot27, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  %ld4369 = load i32, ptr %p4368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4369, ptr %slot735, align 8
  %v4370 = load i32, ptr %slot735, align 8
  %cv4371 = zext i32 %v4370 to i64
  %cond4372 = icmp ne i64 %cv4371, 0
  br i1 %cond4372, label %bb_rcslotdrop1040, label %bb_rcslotdone1040
bb_rcslotdrop1040:
  %v4373 = load i64, ptr %slot27, align 8
  %p4374 = inttoptr i64 %v4373 to ptr
  store i32 0, ptr %p4374, align 4, !alias.scope !3, !noalias !4
  %v4375 = load i64, ptr %slot36, align 8
  store i64 %v4375, ptr %slot736, align 8
  %v4376 = load i64, ptr %slot28, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %ld4378 = load i32, ptr %p4377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4378, ptr %slot737, align 8
  %v4379 = load i32, ptr %slot737, align 8
  %op4380 = and i32 %v4379, 28
  store i32 %op4380, ptr %slot738, align 8
  %v4381 = load i32, ptr %slot738, align 8
  %cv4382 = zext i32 %v4381 to i64
  %cond4383 = icmp ne i64 %cv4382, 0
  br i1 %cond4383, label %bb_rcslotrole1040, label %bb_rcslotowner1040
bb_rcslotrole1040:
  %v4384 = load i64, ptr %slot69, align 8
  store i64 %v4384, ptr %slot739, align 8
  %v4385 = load i64, ptr %slot736, align 8
  %p4386 = inttoptr i64 %v4385 to ptr
  %ld4387 = load i64, ptr %p4386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4387, ptr %slot740, align 8
  %v4388 = load i64, ptr %slot740, align 8
  %cmp4389 = icmp ne i64 %v4388, 0
  %cv4390 = zext i1 %cmp4389 to i32
  store i32 %cv4390, ptr %slot741, align 8
  %v4391 = load i32, ptr %slot741, align 8
  %cv4392 = zext i32 %v4391 to i64
  %cond4393 = icmp ne i64 %cv4392, 0
  br i1 %cond4393, label %bb_rcgnn1056, label %bb_rcgdone1056
bb_rcgnn1056:
  %v4394 = load i64, ptr %slot740, align 8
  %op4395 = sub i64 %v4394, 16
  store i64 %op4395, ptr %slot742, align 8
  %v4396 = load i64, ptr %slot740, align 8
  %p4397 = inttoptr i64 %v4396 to ptr
  %rgep4398 = getelementptr i8, ptr %p4397, i64 -16
  %ld4399 = load i64, ptr %rgep4398, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4399, ptr %slot743, align 8
  %v4400 = load i64, ptr %slot743, align 8
  %op4401 = and i64 %v4400, 4611686018427387906
  store i64 %op4401, ptr %slot744, align 8
  %v4402 = load i64, ptr %slot744, align 8
  %cmp4403 = icmp ne i64 %v4402, 0
  %cv4404 = zext i1 %cmp4403 to i32
  store i32 %cv4404, ptr %slot745, align 8
  %v4405 = load i32, ptr %slot745, align 8
  %cv4406 = zext i32 %v4405 to i64
  %cond4407 = icmp ne i64 %cv4406, 0
  br i1 %cond4407, label %bb_rcgclear1056, label %bb_rcgcounted1056
bb_rcgcounted1056:
  %v4408 = load i64, ptr %slot740, align 8
  %op4409 = sub i64 %v4408, 24
  store i64 %op4409, ptr %slot746, align 8
  %v4410 = load i64, ptr %slot740, align 8
  %p4411 = inttoptr i64 %v4410 to ptr
  %rgep4412 = getelementptr i8, ptr %p4411, i64 -24
  %ld4413 = load i64, ptr %rgep4412, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4413, ptr %slot747, align 8
  %v4414 = load i64, ptr %slot747, align 8
  %op4415 = sub i64 %v4414, 1
  store i64 %op4415, ptr %slot748, align 8
  %v4416 = load i64, ptr %slot748, align 8
  %cmp4417 = icmp eq i64 %v4416, 0
  %cv4418 = zext i1 %cmp4417 to i32
  store i32 %cv4418, ptr %slot749, align 8
  %v4419 = load i32, ptr %slot749, align 8
  %cv4420 = zext i32 %v4419 to i64
  %cond4421 = icmp ne i64 %cv4420, 0
  br i1 %cond4421, label %bb_rcglast1056, label %bb_rcgdec1056
bb_rcglast1056:
  %v4422 = load i64, ptr %slot740, align 8
  %op4423 = sub i64 %v4422, 32
  store i64 %op4423, ptr %slot750, align 8
  %v4424 = load i64, ptr %slot740, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  %rgep4426 = getelementptr i8, ptr %p4425, i64 -32
  %ld4427 = load i64, ptr %rgep4426, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4427, ptr %slot751, align 8
  %v4428 = load i64, ptr %slot751, align 8
  %cmp4429 = icmp ne i64 %v4428, 0
  %cv4430 = zext i1 %cmp4429 to i32
  store i32 %cv4430, ptr %slot752, align 8
  %v4431 = load i32, ptr %slot752, align 8
  %cv4432 = zext i32 %v4431 to i64
  %cond4433 = icmp ne i64 %cv4432, 0
  br i1 %cond4433, label %bb_rcgdec1056, label %bb_rcgslow1056
bb_rcgslow1056:
  %v4434 = load i64, ptr %slot739, align 8
  %v4435 = load i64, ptr %slot736, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_unloan(i64 %v4434, i64 %v4435) nomerge, !dbg !132
  br label %bb_rcgdone1056
bb_rcgdec1056:
  %v4436 = load i64, ptr %slot748, align 8
  %v4437 = load i64, ptr %slot740, align 8
  %p4438 = inttoptr i64 %v4437 to ptr
  %rgep4439 = getelementptr i8, ptr %p4438, i64 -24
  store i64 %v4436, ptr %rgep4439, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1056
bb_rcgclear1056:
  %v4440 = load i64, ptr %slot736, align 8
  %p4441 = inttoptr i64 %v4440 to ptr
  store i64 0, ptr %p4441, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1056
bb_rcgdone1056:
  br label %bb_rcslotdone1040
bb_rcslotowner1040:
  %v4442 = load i64, ptr %slot69, align 8
  store i64 %v4442, ptr %slot753, align 8
  %v4443 = load i64, ptr %slot736, align 8
  %p4444 = inttoptr i64 %v4443 to ptr
  %ld4445 = load i64, ptr %p4444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4445, ptr %slot754, align 8
  %v4446 = load i64, ptr %slot754, align 8
  %cmp4447 = icmp ne i64 %v4446, 0
  %cv4448 = zext i1 %cmp4447 to i32
  store i32 %cv4448, ptr %slot755, align 8
  %v4449 = load i32, ptr %slot755, align 8
  %cv4450 = zext i32 %v4449 to i64
  %cond4451 = icmp ne i64 %cv4450, 0
  br i1 %cond4451, label %bb_rcgnn1071, label %bb_rcgdone1071
bb_rcgnn1071:
  %v4452 = load i64, ptr %slot754, align 8
  %op4453 = sub i64 %v4452, 16
  store i64 %op4453, ptr %slot756, align 8
  %v4454 = load i64, ptr %slot754, align 8
  %p4455 = inttoptr i64 %v4454 to ptr
  %rgep4456 = getelementptr i8, ptr %p4455, i64 -16
  %ld4457 = load i64, ptr %rgep4456, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4457, ptr %slot757, align 8
  %v4458 = load i64, ptr %slot757, align 8
  %op4459 = and i64 %v4458, 4611686018427387906
  store i64 %op4459, ptr %slot758, align 8
  %v4460 = load i64, ptr %slot758, align 8
  %cmp4461 = icmp ne i64 %v4460, 0
  %cv4462 = zext i1 %cmp4461 to i32
  store i32 %cv4462, ptr %slot759, align 8
  %v4463 = load i32, ptr %slot759, align 8
  %cv4464 = zext i32 %v4463 to i64
  %cond4465 = icmp ne i64 %cv4464, 0
  br i1 %cond4465, label %bb_rcgclear1071, label %bb_rcgcounted1071
bb_rcgcounted1071:
  %v4466 = load i64, ptr %slot754, align 8
  %op4467 = sub i64 %v4466, 32
  store i64 %op4467, ptr %slot760, align 8
  %v4468 = load i64, ptr %slot754, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  %rgep4470 = getelementptr i8, ptr %p4469, i64 -32
  %ld4471 = load i64, ptr %rgep4470, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4471, ptr %slot761, align 8
  %v4472 = load i64, ptr %slot761, align 8
  %op4473 = sub i64 %v4472, 1
  store i64 %op4473, ptr %slot762, align 8
  %v4474 = load i64, ptr %slot762, align 8
  %cmp4475 = icmp eq i64 %v4474, 0
  %cv4476 = zext i1 %cmp4475 to i32
  store i32 %cv4476, ptr %slot763, align 8
  %v4477 = load i32, ptr %slot763, align 8
  %cv4478 = zext i32 %v4477 to i64
  %cond4479 = icmp ne i64 %cv4478, 0
  br i1 %cond4479, label %bb_rcglast1071, label %bb_rcgdec1071
bb_rcglast1071:
  %v4480 = load i64, ptr %slot754, align 8
  %op4481 = sub i64 %v4480, 24
  store i64 %op4481, ptr %slot764, align 8
  %v4482 = load i64, ptr %slot754, align 8
  %p4483 = inttoptr i64 %v4482 to ptr
  %rgep4484 = getelementptr i8, ptr %p4483, i64 -24
  %ld4485 = load i64, ptr %rgep4484, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4485, ptr %slot765, align 8
  %v4486 = load i64, ptr %slot765, align 8
  %cmp4487 = icmp ne i64 %v4486, 0
  %cv4488 = zext i1 %cmp4487 to i32
  store i32 %cv4488, ptr %slot766, align 8
  %v4489 = load i32, ptr %slot766, align 8
  %cv4490 = zext i32 %v4489 to i64
  %cond4491 = icmp ne i64 %cv4490, 0
  br i1 %cond4491, label %bb_rcgdec1071, label %bb_rcgslow1071
bb_rcgslow1071:
  %v4492 = load i64, ptr %slot753, align 8
  %v4493 = load i64, ptr %slot736, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_drop(i64 %v4492, i64 %v4493) nomerge, !dbg !132
  br label %bb_rcgdone1071
bb_rcgdec1071:
  %v4494 = load i64, ptr %slot762, align 8
  %v4495 = load i64, ptr %slot754, align 8
  %p4496 = inttoptr i64 %v4495 to ptr
  %rgep4497 = getelementptr i8, ptr %p4496, i64 -32
  store i64 %v4494, ptr %rgep4497, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1071
bb_rcgclear1071:
  %v4498 = load i64, ptr %slot736, align 8
  %p4499 = inttoptr i64 %v4498 to ptr
  store i64 0, ptr %p4499, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1071
bb_rcgdone1071:
  br label %bb_rcslotdone1040
bb_rcslotdone1040:
  br label %bb_rcprepared986
bb_rcprepared986:
  %v4500 = load i64, ptr %slot41, align 8
  store i64 %v4500, ptr %slot767, align 8
  %v4501 = load i64, ptr %slot767, align 8
  %v4502 = load i64, ptr %slot693, align 8
  %p4503 = inttoptr i64 %v4501 to ptr
  %p4504 = inttoptr i64 %v4502 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4504, ptr %p4503, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4505 = load i64, ptr %slot29, align 8
  %p4506 = inttoptr i64 %v4505 to ptr
  store i32 0, ptr %p4506, align 4, !alias.scope !3, !noalias !4
  %v4507 = load i64, ptr %slot415, align 8
  %v4508 = load i64, ptr %slot50, align 8
  %p4509 = inttoptr i64 %v4508 to ptr
  store i64 %v4507, ptr %p4509, align 8, !alias.scope !3, !noalias !4
  %v4510 = load i64, ptr %slot50, align 8
  %p4511 = inttoptr i64 %v4510 to ptr
  %ld4512 = load i64, ptr %p4511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4512, ptr %slot768, align 8
  %v4513 = load i64, ptr %slot32, align 8
  store i64 %v4513, ptr %slot769, align 8
  %v4514 = load i64, ptr %slot768, align 8
  %v4515 = load i64, ptr %slot769, align 8
  %p4516 = inttoptr i64 %v4514 to ptr
  %p4517 = inttoptr i64 %v4515 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4517, ptr %p4516, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v4518 = load i64, ptr %slot17, align 8
  %p4519 = inttoptr i64 %v4518 to ptr
  store i32 2, ptr %p4519, align 4, !alias.scope !3, !noalias !4
  %v4520 = load i64, ptr %slot16, align 8
  %p4521 = inttoptr i64 %v4520 to ptr
  store i32 1, ptr %p4521, align 4, !alias.scope !3, !noalias !4
  %v4522 = load i64, ptr %slot769, align 8
  %v4523 = load i64, ptr %slot50, align 8
  %p4524 = inttoptr i64 %v4523 to ptr
  store i64 %v4522, ptr %p4524, align 8, !alias.scope !3, !noalias !4
  %v4525 = load i64, ptr %slot50, align 8
  %p4526 = inttoptr i64 %v4525 to ptr
  %ld4527 = load i64, ptr %p4526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4527, ptr %slot770, align 8
  %v4528 = load i64, ptr %slot41, align 8
  store i64 %v4528, ptr %slot771, align 8
  %v4529 = load i64, ptr %slot70, align 8
  store i64 %v4529, ptr %slot772, align 8
  %v4530 = load i64, ptr %slot69, align 8
  %v4531 = load i64, ptr %slot771, align 8
  %v4532 = load i64, ptr %slot770, align 8
  %v4533 = load i64, ptr %slot772, align 8
  %cv4534 = trunc i64 %v4533 to i32
  %call4535 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v4530, i64 %v4531, i64 %v4532, i32 %cv4534) nomerge, !dbg !134
  store i32 %call4535, ptr %slot773, align 8
  %v4536 = load i32, ptr %slot773, align 8
  %cv4537 = zext i32 %v4536 to i64
  %cond4538 = icmp ne i64 %cv4537, 0
  br i1 %cond4538, label %bb_rcsuccess1085, label %bb_rcfailure1085
bb_rcfailure1085:
  %v4539 = load i64, ptr %slot69, align 8
  %p4540 = inttoptr i64 %v4539 to ptr
  %call4541 = call i32 @myl_rc_take_failure(ptr %p4540) nomerge, !dbg !134
  store i32 %call4541, ptr %slot774, align 8
  %v4542 = load i64, ptr %slot1, align 8
  %p4543 = inttoptr i64 %v4542 to ptr
  %v4544 = load i32, ptr %slot774, align 8
  %call4545 = call i32 @myl_qbe_rc_status(ptr %p4543, i32 %v4544) nomerge, !dbg !134
  store i32 %call4545, ptr %slot775, align 8
  br label %bb_failure
bb_rcsuccess1085:
  %v4546 = load i64, ptr %slot16, align 8
  %p4547 = inttoptr i64 %v4546 to ptr
  store i32 0, ptr %p4547, align 4, !alias.scope !3, !noalias !4
  %v4548 = load i64, ptr %slot30, align 8
  %p4549 = inttoptr i64 %v4548 to ptr
  store i32 2, ptr %p4549, align 4, !alias.scope !3, !noalias !4
  %v4550 = load i64, ptr %slot29, align 8
  %p4551 = inttoptr i64 %v4550 to ptr
  store i32 1, ptr %p4551, align 4, !alias.scope !3, !noalias !4
  %v4552 = load i64, ptr %slot12, align 8
  %p4553 = inttoptr i64 %v4552 to ptr
  %ld4554 = load i32, ptr %p4553, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4554, ptr %slot776, align 8
  %v4555 = load i32, ptr %slot776, align 8
  %cv4556 = zext i32 %v4555 to i64
  %cond4557 = icmp ne i64 %cv4556, 0
  br i1 %cond4557, label %bb_rcslotdrop1094, label %bb_rcslotdone1094
bb_rcslotdrop1094:
  %v4558 = load i64, ptr %slot12, align 8
  %p4559 = inttoptr i64 %v4558 to ptr
  store i32 0, ptr %p4559, align 4, !alias.scope !3, !noalias !4
  %v4560 = load i64, ptr %slot48, align 8
  store i64 %v4560, ptr %slot777, align 8
  %v4561 = load i64, ptr %slot13, align 8
  %p4562 = inttoptr i64 %v4561 to ptr
  %ld4563 = load i32, ptr %p4562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4563, ptr %slot778, align 8
  %v4564 = load i32, ptr %slot778, align 8
  %op4565 = and i32 %v4564, 28
  store i32 %op4565, ptr %slot779, align 8
  %v4566 = load i32, ptr %slot779, align 8
  %cv4567 = zext i32 %v4566 to i64
  %cond4568 = icmp ne i64 %cv4567, 0
  br i1 %cond4568, label %bb_rcslotrole1094, label %bb_rcslotowner1094
bb_rcslotrole1094:
  %v4569 = load i64, ptr %slot69, align 8
  store i64 %v4569, ptr %slot780, align 8
  %v4570 = load i64, ptr %slot780, align 8
  %v4571 = load i64, ptr %slot777, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4570, i64 %v4571) nomerge, !dbg !134
  br label %bb_rcslotdone1094
bb_rcslotowner1094:
  %v4572 = load i64, ptr %slot69, align 8
  store i64 %v4572, ptr %slot781, align 8
  %v4573 = load i64, ptr %slot781, align 8
  %v4574 = load i64, ptr %slot777, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4573, i64 %v4574) nomerge, !dbg !134
  br label %bb_rcslotdone1094
bb_rcslotdone1094:
  %v4575 = load i64, ptr %slot48, align 8
  store i64 %v4575, ptr %slot782, align 8
  %v4576 = load i64, ptr %slot41, align 8
  store i64 %v4576, ptr %slot783, align 8
  %v4577 = load i64, ptr %slot783, align 8
  %v4578 = load i64, ptr %slot782, align 8
  %p4579 = inttoptr i64 %v4577 to ptr
  %p4580 = inttoptr i64 %v4578 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4580, ptr %p4579, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v4581 = load i64, ptr %slot29, align 8
  %p4582 = inttoptr i64 %v4581 to ptr
  store i32 0, ptr %p4582, align 4, !alias.scope !3, !noalias !4
  %v4583 = load i64, ptr %slot13, align 8
  %p4584 = inttoptr i64 %v4583 to ptr
  store i32 2, ptr %p4584, align 4, !alias.scope !3, !noalias !4
  %v4585 = load i64, ptr %slot30, align 8
  %p4586 = inttoptr i64 %v4585 to ptr
  %ld4587 = load i32, ptr %p4586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4587, ptr %slot784, align 8
  %v4588 = load i32, ptr %slot784, align 8
  %v4589 = load i64, ptr %slot13, align 8
  %p4590 = inttoptr i64 %v4589 to ptr
  store i32 %v4588, ptr %p4590, align 4, !alias.scope !3, !noalias !4
  %v4591 = load i64, ptr %slot12, align 8
  %p4592 = inttoptr i64 %v4591 to ptr
  store i32 1, ptr %p4592, align 4, !alias.scope !3, !noalias !4
  %v4593 = load i64, ptr %slot8, align 8
  %p4594 = inttoptr i64 %v4593 to ptr
  %ld4595 = load i32, ptr %p4594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4595, ptr %slot785, align 8
  %v4596 = load i32, ptr %slot785, align 8
  %cv4597 = zext i32 %v4596 to i64
  %cond4598 = icmp ne i64 %cv4597, 0
  br i1 %cond4598, label %bb_rcslotdrop1110, label %bb_rcslotdone1110
bb_rcslotdrop1110:
  %v4599 = load i64, ptr %slot8, align 8
  %p4600 = inttoptr i64 %v4599 to ptr
  store i32 0, ptr %p4600, align 4, !alias.scope !3, !noalias !4
  %v4601 = load i64, ptr %slot46, align 8
  store i64 %v4601, ptr %slot786, align 8
  %v4602 = load i64, ptr %slot9, align 8
  %p4603 = inttoptr i64 %v4602 to ptr
  %ld4604 = load i32, ptr %p4603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4604, ptr %slot787, align 8
  %v4605 = load i32, ptr %slot787, align 8
  %op4606 = and i32 %v4605, 28
  store i32 %op4606, ptr %slot788, align 8
  %v4607 = load i32, ptr %slot788, align 8
  %cv4608 = zext i32 %v4607 to i64
  %cond4609 = icmp ne i64 %cv4608, 0
  br i1 %cond4609, label %bb_rcslotrole1110, label %bb_rcslotowner1110
bb_rcslotrole1110:
  %v4610 = load i64, ptr %slot69, align 8
  store i64 %v4610, ptr %slot789, align 8
  %v4611 = load i64, ptr %slot786, align 8
  %p4612 = inttoptr i64 %v4611 to ptr
  %ld4613 = load i64, ptr %p4612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4613, ptr %slot790, align 8
  %v4614 = load i64, ptr %slot790, align 8
  %cmp4615 = icmp ne i64 %v4614, 0
  %cv4616 = zext i1 %cmp4615 to i32
  store i32 %cv4616, ptr %slot791, align 8
  %v4617 = load i32, ptr %slot791, align 8
  %cv4618 = zext i32 %v4617 to i64
  %cond4619 = icmp ne i64 %cv4618, 0
  br i1 %cond4619, label %bb_rcgnn1126, label %bb_rcgdone1126
bb_rcgnn1126:
  %v4620 = load i64, ptr %slot790, align 8
  %op4621 = sub i64 %v4620, 16
  store i64 %op4621, ptr %slot792, align 8
  %v4622 = load i64, ptr %slot790, align 8
  %p4623 = inttoptr i64 %v4622 to ptr
  %rgep4624 = getelementptr i8, ptr %p4623, i64 -16
  %ld4625 = load i64, ptr %rgep4624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4625, ptr %slot793, align 8
  %v4626 = load i64, ptr %slot793, align 8
  %op4627 = and i64 %v4626, 4611686018427387906
  store i64 %op4627, ptr %slot794, align 8
  %v4628 = load i64, ptr %slot794, align 8
  %cmp4629 = icmp ne i64 %v4628, 0
  %cv4630 = zext i1 %cmp4629 to i32
  store i32 %cv4630, ptr %slot795, align 8
  %v4631 = load i32, ptr %slot795, align 8
  %cv4632 = zext i32 %v4631 to i64
  %cond4633 = icmp ne i64 %cv4632, 0
  br i1 %cond4633, label %bb_rcgclear1126, label %bb_rcgcounted1126
bb_rcgcounted1126:
  %v4634 = load i64, ptr %slot790, align 8
  %op4635 = sub i64 %v4634, 24
  store i64 %op4635, ptr %slot796, align 8
  %v4636 = load i64, ptr %slot790, align 8
  %p4637 = inttoptr i64 %v4636 to ptr
  %rgep4638 = getelementptr i8, ptr %p4637, i64 -24
  %ld4639 = load i64, ptr %rgep4638, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4639, ptr %slot797, align 8
  %v4640 = load i64, ptr %slot797, align 8
  %op4641 = sub i64 %v4640, 1
  store i64 %op4641, ptr %slot798, align 8
  %v4642 = load i64, ptr %slot798, align 8
  %cmp4643 = icmp eq i64 %v4642, 0
  %cv4644 = zext i1 %cmp4643 to i32
  store i32 %cv4644, ptr %slot799, align 8
  %v4645 = load i32, ptr %slot799, align 8
  %cv4646 = zext i32 %v4645 to i64
  %cond4647 = icmp ne i64 %cv4646, 0
  br i1 %cond4647, label %bb_rcglast1126, label %bb_rcgdec1126
bb_rcglast1126:
  %v4648 = load i64, ptr %slot790, align 8
  %op4649 = sub i64 %v4648, 32
  store i64 %op4649, ptr %slot800, align 8
  %v4650 = load i64, ptr %slot790, align 8
  %p4651 = inttoptr i64 %v4650 to ptr
  %rgep4652 = getelementptr i8, ptr %p4651, i64 -32
  %ld4653 = load i64, ptr %rgep4652, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4653, ptr %slot801, align 8
  %v4654 = load i64, ptr %slot801, align 8
  %cmp4655 = icmp ne i64 %v4654, 0
  %cv4656 = zext i1 %cmp4655 to i32
  store i32 %cv4656, ptr %slot802, align 8
  %v4657 = load i32, ptr %slot802, align 8
  %cv4658 = zext i32 %v4657 to i64
  %cond4659 = icmp ne i64 %cv4658, 0
  br i1 %cond4659, label %bb_rcgdec1126, label %bb_rcgslow1126
bb_rcgslow1126:
  %v4660 = load i64, ptr %slot789, align 8
  %v4661 = load i64, ptr %slot786, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v4660, i64 %v4661) nomerge, !dbg !134
  br label %bb_rcgdone1126
bb_rcgdec1126:
  %v4662 = load i64, ptr %slot798, align 8
  %v4663 = load i64, ptr %slot790, align 8
  %p4664 = inttoptr i64 %v4663 to ptr
  %rgep4665 = getelementptr i8, ptr %p4664, i64 -24
  store i64 %v4662, ptr %rgep4665, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1126
bb_rcgclear1126:
  %v4666 = load i64, ptr %slot786, align 8
  %p4667 = inttoptr i64 %v4666 to ptr
  store i64 0, ptr %p4667, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1126
bb_rcgdone1126:
  br label %bb_rcslotdone1110
bb_rcslotowner1110:
  %v4668 = load i64, ptr %slot69, align 8
  store i64 %v4668, ptr %slot803, align 8
  %v4669 = load i64, ptr %slot786, align 8
  %p4670 = inttoptr i64 %v4669 to ptr
  %ld4671 = load i64, ptr %p4670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4671, ptr %slot804, align 8
  %v4672 = load i64, ptr %slot804, align 8
  %cmp4673 = icmp ne i64 %v4672, 0
  %cv4674 = zext i1 %cmp4673 to i32
  store i32 %cv4674, ptr %slot805, align 8
  %v4675 = load i32, ptr %slot805, align 8
  %cv4676 = zext i32 %v4675 to i64
  %cond4677 = icmp ne i64 %cv4676, 0
  br i1 %cond4677, label %bb_rcgnn1141, label %bb_rcgdone1141
bb_rcgnn1141:
  %v4678 = load i64, ptr %slot804, align 8
  %op4679 = sub i64 %v4678, 16
  store i64 %op4679, ptr %slot806, align 8
  %v4680 = load i64, ptr %slot804, align 8
  %p4681 = inttoptr i64 %v4680 to ptr
  %rgep4682 = getelementptr i8, ptr %p4681, i64 -16
  %ld4683 = load i64, ptr %rgep4682, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4683, ptr %slot807, align 8
  %v4684 = load i64, ptr %slot807, align 8
  %op4685 = and i64 %v4684, 4611686018427387906
  store i64 %op4685, ptr %slot808, align 8
  %v4686 = load i64, ptr %slot808, align 8
  %cmp4687 = icmp ne i64 %v4686, 0
  %cv4688 = zext i1 %cmp4687 to i32
  store i32 %cv4688, ptr %slot809, align 8
  %v4689 = load i32, ptr %slot809, align 8
  %cv4690 = zext i32 %v4689 to i64
  %cond4691 = icmp ne i64 %cv4690, 0
  br i1 %cond4691, label %bb_rcgclear1141, label %bb_rcgcounted1141
bb_rcgcounted1141:
  %v4692 = load i64, ptr %slot804, align 8
  %op4693 = sub i64 %v4692, 32
  store i64 %op4693, ptr %slot810, align 8
  %v4694 = load i64, ptr %slot804, align 8
  %p4695 = inttoptr i64 %v4694 to ptr
  %rgep4696 = getelementptr i8, ptr %p4695, i64 -32
  %ld4697 = load i64, ptr %rgep4696, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4697, ptr %slot811, align 8
  %v4698 = load i64, ptr %slot811, align 8
  %op4699 = sub i64 %v4698, 1
  store i64 %op4699, ptr %slot812, align 8
  %v4700 = load i64, ptr %slot812, align 8
  %cmp4701 = icmp eq i64 %v4700, 0
  %cv4702 = zext i1 %cmp4701 to i32
  store i32 %cv4702, ptr %slot813, align 8
  %v4703 = load i32, ptr %slot813, align 8
  %cv4704 = zext i32 %v4703 to i64
  %cond4705 = icmp ne i64 %cv4704, 0
  br i1 %cond4705, label %bb_rcglast1141, label %bb_rcgdec1141
bb_rcglast1141:
  %v4706 = load i64, ptr %slot804, align 8
  %op4707 = sub i64 %v4706, 24
  store i64 %op4707, ptr %slot814, align 8
  %v4708 = load i64, ptr %slot804, align 8
  %p4709 = inttoptr i64 %v4708 to ptr
  %rgep4710 = getelementptr i8, ptr %p4709, i64 -24
  %ld4711 = load i64, ptr %rgep4710, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4711, ptr %slot815, align 8
  %v4712 = load i64, ptr %slot815, align 8
  %cmp4713 = icmp ne i64 %v4712, 0
  %cv4714 = zext i1 %cmp4713 to i32
  store i32 %cv4714, ptr %slot816, align 8
  %v4715 = load i32, ptr %slot816, align 8
  %cv4716 = zext i32 %v4715 to i64
  %cond4717 = icmp ne i64 %cv4716, 0
  br i1 %cond4717, label %bb_rcgdec1141, label %bb_rcgslow1141
bb_rcgslow1141:
  %v4718 = load i64, ptr %slot803, align 8
  %v4719 = load i64, ptr %slot786, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v4718, i64 %v4719) nomerge, !dbg !134
  br label %bb_rcgdone1141
bb_rcgdec1141:
  %v4720 = load i64, ptr %slot812, align 8
  %v4721 = load i64, ptr %slot804, align 8
  %p4722 = inttoptr i64 %v4721 to ptr
  %rgep4723 = getelementptr i8, ptr %p4722, i64 -32
  store i64 %v4720, ptr %rgep4723, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1141
bb_rcgclear1141:
  %v4724 = load i64, ptr %slot786, align 8
  %p4725 = inttoptr i64 %v4724 to ptr
  store i64 0, ptr %p4725, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1141
bb_rcgdone1141:
  br label %bb_rcslotdone1110
bb_rcslotdone1110:
  %v4726 = load i64, ptr %slot10, align 8
  %p4727 = inttoptr i64 %v4726 to ptr
  %ld4728 = load i32, ptr %p4727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4728, ptr %slot817, align 8
  %v4729 = load i32, ptr %slot817, align 8
  %cv4730 = zext i32 %v4729 to i64
  %cond4731 = icmp ne i64 %cv4730, 0
  br i1 %cond4731, label %bb_rcslotdrop1147, label %bb_rcslotdone1147
bb_rcslotdrop1147:
  %v4732 = load i64, ptr %slot10, align 8
  %p4733 = inttoptr i64 %v4732 to ptr
  store i32 0, ptr %p4733, align 4, !alias.scope !3, !noalias !4
  %v4734 = load i64, ptr %slot47, align 8
  store i64 %v4734, ptr %slot818, align 8
  %v4735 = load i64, ptr %slot11, align 8
  %p4736 = inttoptr i64 %v4735 to ptr
  %ld4737 = load i32, ptr %p4736, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4737, ptr %slot819, align 8
  %v4738 = load i32, ptr %slot819, align 8
  %op4739 = and i32 %v4738, 28
  store i32 %op4739, ptr %slot820, align 8
  %v4740 = load i32, ptr %slot820, align 8
  %cv4741 = zext i32 %v4740 to i64
  %cond4742 = icmp ne i64 %cv4741, 0
  br i1 %cond4742, label %bb_rcslotrole1147, label %bb_rcslotowner1147
bb_rcslotrole1147:
  %v4743 = load i64, ptr %slot69, align 8
  store i64 %v4743, ptr %slot821, align 8
  %v4744 = load i64, ptr %slot818, align 8
  %p4745 = inttoptr i64 %v4744 to ptr
  %ld4746 = load i64, ptr %p4745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4746, ptr %slot822, align 8
  %v4747 = load i64, ptr %slot822, align 8
  %cmp4748 = icmp ne i64 %v4747, 0
  %cv4749 = zext i1 %cmp4748 to i32
  store i32 %cv4749, ptr %slot823, align 8
  %v4750 = load i32, ptr %slot823, align 8
  %cv4751 = zext i32 %v4750 to i64
  %cond4752 = icmp ne i64 %cv4751, 0
  br i1 %cond4752, label %bb_rcgnn1163, label %bb_rcgdone1163
bb_rcgnn1163:
  %v4753 = load i64, ptr %slot822, align 8
  %op4754 = sub i64 %v4753, 16
  store i64 %op4754, ptr %slot824, align 8
  %v4755 = load i64, ptr %slot822, align 8
  %p4756 = inttoptr i64 %v4755 to ptr
  %rgep4757 = getelementptr i8, ptr %p4756, i64 -16
  %ld4758 = load i64, ptr %rgep4757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4758, ptr %slot825, align 8
  %v4759 = load i64, ptr %slot825, align 8
  %op4760 = and i64 %v4759, 4611686018427387906
  store i64 %op4760, ptr %slot826, align 8
  %v4761 = load i64, ptr %slot826, align 8
  %cmp4762 = icmp ne i64 %v4761, 0
  %cv4763 = zext i1 %cmp4762 to i32
  store i32 %cv4763, ptr %slot827, align 8
  %v4764 = load i32, ptr %slot827, align 8
  %cv4765 = zext i32 %v4764 to i64
  %cond4766 = icmp ne i64 %cv4765, 0
  br i1 %cond4766, label %bb_rcgclear1163, label %bb_rcgcounted1163
bb_rcgcounted1163:
  %v4767 = load i64, ptr %slot822, align 8
  %op4768 = sub i64 %v4767, 24
  store i64 %op4768, ptr %slot828, align 8
  %v4769 = load i64, ptr %slot822, align 8
  %p4770 = inttoptr i64 %v4769 to ptr
  %rgep4771 = getelementptr i8, ptr %p4770, i64 -24
  %ld4772 = load i64, ptr %rgep4771, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4772, ptr %slot829, align 8
  %v4773 = load i64, ptr %slot829, align 8
  %op4774 = sub i64 %v4773, 1
  store i64 %op4774, ptr %slot830, align 8
  %v4775 = load i64, ptr %slot830, align 8
  %cmp4776 = icmp eq i64 %v4775, 0
  %cv4777 = zext i1 %cmp4776 to i32
  store i32 %cv4777, ptr %slot831, align 8
  %v4778 = load i32, ptr %slot831, align 8
  %cv4779 = zext i32 %v4778 to i64
  %cond4780 = icmp ne i64 %cv4779, 0
  br i1 %cond4780, label %bb_rcglast1163, label %bb_rcgdec1163
bb_rcglast1163:
  %v4781 = load i64, ptr %slot822, align 8
  %op4782 = sub i64 %v4781, 32
  store i64 %op4782, ptr %slot832, align 8
  %v4783 = load i64, ptr %slot822, align 8
  %p4784 = inttoptr i64 %v4783 to ptr
  %rgep4785 = getelementptr i8, ptr %p4784, i64 -32
  %ld4786 = load i64, ptr %rgep4785, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4786, ptr %slot833, align 8
  %v4787 = load i64, ptr %slot833, align 8
  %cmp4788 = icmp ne i64 %v4787, 0
  %cv4789 = zext i1 %cmp4788 to i32
  store i32 %cv4789, ptr %slot834, align 8
  %v4790 = load i32, ptr %slot834, align 8
  %cv4791 = zext i32 %v4790 to i64
  %cond4792 = icmp ne i64 %cv4791, 0
  br i1 %cond4792, label %bb_rcgdec1163, label %bb_rcgslow1163
bb_rcgslow1163:
  %v4793 = load i64, ptr %slot821, align 8
  %v4794 = load i64, ptr %slot818, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_unloan(i64 %v4793, i64 %v4794) nomerge, !dbg !134
  br label %bb_rcgdone1163
bb_rcgdec1163:
  %v4795 = load i64, ptr %slot830, align 8
  %v4796 = load i64, ptr %slot822, align 8
  %p4797 = inttoptr i64 %v4796 to ptr
  %rgep4798 = getelementptr i8, ptr %p4797, i64 -24
  store i64 %v4795, ptr %rgep4798, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1163
bb_rcgclear1163:
  %v4799 = load i64, ptr %slot818, align 8
  %p4800 = inttoptr i64 %v4799 to ptr
  store i64 0, ptr %p4800, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1163
bb_rcgdone1163:
  br label %bb_rcslotdone1147
bb_rcslotowner1147:
  %v4801 = load i64, ptr %slot69, align 8
  store i64 %v4801, ptr %slot835, align 8
  %v4802 = load i64, ptr %slot818, align 8
  %p4803 = inttoptr i64 %v4802 to ptr
  %ld4804 = load i64, ptr %p4803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4804, ptr %slot836, align 8
  %v4805 = load i64, ptr %slot836, align 8
  %cmp4806 = icmp ne i64 %v4805, 0
  %cv4807 = zext i1 %cmp4806 to i32
  store i32 %cv4807, ptr %slot837, align 8
  %v4808 = load i32, ptr %slot837, align 8
  %cv4809 = zext i32 %v4808 to i64
  %cond4810 = icmp ne i64 %cv4809, 0
  br i1 %cond4810, label %bb_rcgnn1178, label %bb_rcgdone1178
bb_rcgnn1178:
  %v4811 = load i64, ptr %slot836, align 8
  %op4812 = sub i64 %v4811, 16
  store i64 %op4812, ptr %slot838, align 8
  %v4813 = load i64, ptr %slot836, align 8
  %p4814 = inttoptr i64 %v4813 to ptr
  %rgep4815 = getelementptr i8, ptr %p4814, i64 -16
  %ld4816 = load i64, ptr %rgep4815, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4816, ptr %slot839, align 8
  %v4817 = load i64, ptr %slot839, align 8
  %op4818 = and i64 %v4817, 4611686018427387906
  store i64 %op4818, ptr %slot840, align 8
  %v4819 = load i64, ptr %slot840, align 8
  %cmp4820 = icmp ne i64 %v4819, 0
  %cv4821 = zext i1 %cmp4820 to i32
  store i32 %cv4821, ptr %slot841, align 8
  %v4822 = load i32, ptr %slot841, align 8
  %cv4823 = zext i32 %v4822 to i64
  %cond4824 = icmp ne i64 %cv4823, 0
  br i1 %cond4824, label %bb_rcgclear1178, label %bb_rcgcounted1178
bb_rcgcounted1178:
  %v4825 = load i64, ptr %slot836, align 8
  %op4826 = sub i64 %v4825, 32
  store i64 %op4826, ptr %slot842, align 8
  %v4827 = load i64, ptr %slot836, align 8
  %p4828 = inttoptr i64 %v4827 to ptr
  %rgep4829 = getelementptr i8, ptr %p4828, i64 -32
  %ld4830 = load i64, ptr %rgep4829, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4830, ptr %slot843, align 8
  %v4831 = load i64, ptr %slot843, align 8
  %op4832 = sub i64 %v4831, 1
  store i64 %op4832, ptr %slot844, align 8
  %v4833 = load i64, ptr %slot844, align 8
  %cmp4834 = icmp eq i64 %v4833, 0
  %cv4835 = zext i1 %cmp4834 to i32
  store i32 %cv4835, ptr %slot845, align 8
  %v4836 = load i32, ptr %slot845, align 8
  %cv4837 = zext i32 %v4836 to i64
  %cond4838 = icmp ne i64 %cv4837, 0
  br i1 %cond4838, label %bb_rcglast1178, label %bb_rcgdec1178
bb_rcglast1178:
  %v4839 = load i64, ptr %slot836, align 8
  %op4840 = sub i64 %v4839, 24
  store i64 %op4840, ptr %slot846, align 8
  %v4841 = load i64, ptr %slot836, align 8
  %p4842 = inttoptr i64 %v4841 to ptr
  %rgep4843 = getelementptr i8, ptr %p4842, i64 -24
  %ld4844 = load i64, ptr %rgep4843, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4844, ptr %slot847, align 8
  %v4845 = load i64, ptr %slot847, align 8
  %cmp4846 = icmp ne i64 %v4845, 0
  %cv4847 = zext i1 %cmp4846 to i32
  store i32 %cv4847, ptr %slot848, align 8
  %v4848 = load i32, ptr %slot848, align 8
  %cv4849 = zext i32 %v4848 to i64
  %cond4850 = icmp ne i64 %cv4849, 0
  br i1 %cond4850, label %bb_rcgdec1178, label %bb_rcgslow1178
bb_rcgslow1178:
  %v4851 = load i64, ptr %slot835, align 8
  %v4852 = load i64, ptr %slot818, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_drop(i64 %v4851, i64 %v4852) nomerge, !dbg !134
  br label %bb_rcgdone1178
bb_rcgdec1178:
  %v4853 = load i64, ptr %slot844, align 8
  %v4854 = load i64, ptr %slot836, align 8
  %p4855 = inttoptr i64 %v4854 to ptr
  %rgep4856 = getelementptr i8, ptr %p4855, i64 -32
  store i64 %v4853, ptr %rgep4856, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1178
bb_rcgclear1178:
  %v4857 = load i64, ptr %slot818, align 8
  %p4858 = inttoptr i64 %v4857 to ptr
  store i64 0, ptr %p4858, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1178
bb_rcgdone1178:
  br label %bb_rcslotdone1147
bb_rcslotdone1147:
  %v4859 = load i64, ptr %slot48, align 8
  %v4860 = load i64, ptr %slot50, align 8
  %p4861 = inttoptr i64 %v4860 to ptr
  store i64 %v4859, ptr %p4861, align 8, !alias.scope !3, !noalias !4
  %v4862 = load i64, ptr %slot63, align 8
  store i64 %v4862, ptr %slot849, align 8
  %v4863 = load i64, ptr %slot849, align 8
  %p4864 = inttoptr i64 %v4863 to ptr
  store i32 0, ptr %p4864, align 4, !alias.scope !3, !noalias !4
  %v4865 = load i64, ptr %slot849, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  store i32 3, ptr %p4866, align 4, !alias.scope !3, !noalias !4
  %v4867 = load i64, ptr %slot849, align 8
  %v4868 = load i64, ptr %slot51, align 8
  %p4869 = inttoptr i64 %v4868 to ptr
  store i64 %v4867, ptr %p4869, align 8, !alias.scope !3, !noalias !4
  %v4870 = load i64, ptr %slot50, align 8
  %p4871 = inttoptr i64 %v4870 to ptr
  %ld4872 = load i64, ptr %p4871, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4872, ptr %slot850, align 8
  %v4873 = load i64, ptr %slot51, align 8
  %p4874 = inttoptr i64 %v4873 to ptr
  %ld4875 = load i64, ptr %p4874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4875, ptr %slot851, align 8
  %v4876 = load i64, ptr %slot1, align 8
  %v4877 = load i64, ptr %slot850, align 8
  %v4878 = load i64, ptr %slot851, align 8
  %call4879 = call i64 @myl_f_d0f0fd2ebc58c2edfb4f79ef4b78cc0dec904f09b2ad13c907ec77d7bf9667f3(i64 %v4876, i64 %v4877, i64 %v4878) nomerge, !dbg !136
  store i64 %call4879, ptr %slot852, align 8
  %v4880 = load i64, ptr %slot852, align 8
  %v4881 = load i64, ptr %slot50, align 8
  %p4882 = inttoptr i64 %v4881 to ptr
  store i64 %v4880, ptr %p4882, align 8, !alias.scope !3, !noalias !4
  %v4883 = load i64, ptr %slot16, align 8
  %p4884 = inttoptr i64 %v4883 to ptr
  %ld4885 = load i32, ptr %p4884, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4885, ptr %slot853, align 8
  %v4886 = load i32, ptr %slot853, align 8
  %cv4887 = zext i32 %v4886 to i64
  %cond4888 = icmp ne i64 %cv4887, 0
  br i1 %cond4888, label %bb_rcslotdrop1188, label %bb_rcslotdone1188
bb_rcslotdrop1188:
  %v4889 = load i64, ptr %slot16, align 8
  %p4890 = inttoptr i64 %v4889 to ptr
  store i32 0, ptr %p4890, align 4, !alias.scope !3, !noalias !4
  %v4891 = load i64, ptr %slot32, align 8
  store i64 %v4891, ptr %slot854, align 8
  %v4892 = load i64, ptr %slot17, align 8
  %p4893 = inttoptr i64 %v4892 to ptr
  %ld4894 = load i32, ptr %p4893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4894, ptr %slot855, align 8
  %v4895 = load i32, ptr %slot855, align 8
  %op4896 = and i32 %v4895, 28
  store i32 %op4896, ptr %slot856, align 8
  %v4897 = load i32, ptr %slot856, align 8
  %cv4898 = zext i32 %v4897 to i64
  %cond4899 = icmp ne i64 %cv4898, 0
  br i1 %cond4899, label %bb_rcslotrole1188, label %bb_rcslotowner1188
bb_rcslotrole1188:
  %v4900 = load i64, ptr %slot69, align 8
  store i64 %v4900, ptr %slot857, align 8
  %v4901 = load i64, ptr %slot857, align 8
  %v4902 = load i64, ptr %slot854, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4901, i64 %v4902) nomerge, !dbg !136
  br label %bb_rcslotdone1188
bb_rcslotowner1188:
  %v4903 = load i64, ptr %slot69, align 8
  store i64 %v4903, ptr %slot858, align 8
  %v4904 = load i64, ptr %slot858, align 8
  %v4905 = load i64, ptr %slot854, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4904, i64 %v4905) nomerge, !dbg !136
  br label %bb_rcslotdone1188
bb_rcslotdone1188:
  %v4906 = load i64, ptr %slot48, align 8
  %v4907 = load i64, ptr %slot50, align 8
  %p4908 = inttoptr i64 %v4907 to ptr
  store i64 %v4906, ptr %p4908, align 8, !alias.scope !3, !noalias !4
  %v4909 = load i64, ptr %slot50, align 8
  %p4910 = inttoptr i64 %v4909 to ptr
  %ld4911 = load i64, ptr %p4910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4911, ptr %slot859, align 8
  %v4912 = load i64, ptr %slot1, align 8
  %v4913 = load i64, ptr %slot859, align 8
  %call4914 = call i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64 %v4912, i64 %v4913) nomerge, !dbg !138
  store i64 %call4914, ptr %slot860, align 8
  %v4915 = load i64, ptr %slot860, align 8
  %v4916 = load i64, ptr %slot50, align 8
  %p4917 = inttoptr i64 %v4916 to ptr
  store i64 %v4915, ptr %p4917, align 8, !alias.scope !3, !noalias !4
  %v4918 = load i64, ptr %slot16, align 8
  %p4919 = inttoptr i64 %v4918 to ptr
  %ld4920 = load i32, ptr %p4919, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4920, ptr %slot861, align 8
  %v4921 = load i32, ptr %slot861, align 8
  %cv4922 = zext i32 %v4921 to i64
  %cond4923 = icmp ne i64 %cv4922, 0
  br i1 %cond4923, label %bb_rcslotdrop1199, label %bb_rcslotdone1199
bb_rcslotdrop1199:
  %v4924 = load i64, ptr %slot16, align 8
  %p4925 = inttoptr i64 %v4924 to ptr
  store i32 0, ptr %p4925, align 4, !alias.scope !3, !noalias !4
  %v4926 = load i64, ptr %slot32, align 8
  store i64 %v4926, ptr %slot862, align 8
  %v4927 = load i64, ptr %slot17, align 8
  %p4928 = inttoptr i64 %v4927 to ptr
  %ld4929 = load i32, ptr %p4928, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4929, ptr %slot863, align 8
  %v4930 = load i32, ptr %slot863, align 8
  %op4931 = and i32 %v4930, 28
  store i32 %op4931, ptr %slot864, align 8
  %v4932 = load i32, ptr %slot864, align 8
  %cv4933 = zext i32 %v4932 to i64
  %cond4934 = icmp ne i64 %cv4933, 0
  br i1 %cond4934, label %bb_rcslotrole1199, label %bb_rcslotowner1199
bb_rcslotrole1199:
  %v4935 = load i64, ptr %slot69, align 8
  store i64 %v4935, ptr %slot865, align 8
  %v4936 = load i64, ptr %slot865, align 8
  %v4937 = load i64, ptr %slot862, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4936, i64 %v4937) nomerge, !dbg !138
  br label %bb_rcslotdone1199
bb_rcslotowner1199:
  %v4938 = load i64, ptr %slot69, align 8
  store i64 %v4938, ptr %slot866, align 8
  %v4939 = load i64, ptr %slot866, align 8
  %v4940 = load i64, ptr %slot862, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4939, i64 %v4940) nomerge, !dbg !138
  br label %bb_rcslotdone1199
bb_rcslotdone1199:
  br label %bb_i37
bb_i37:
  %v4941 = load i64, ptr %slot48, align 8
  %v4942 = load i64, ptr %slot50, align 8
  %p4943 = inttoptr i64 %v4942 to ptr
  store i64 %v4941, ptr %p4943, align 8, !alias.scope !3, !noalias !4
  %v4944 = load i64, ptr %slot64, align 8
  store i64 %v4944, ptr %slot867, align 8
  %v4945 = load i64, ptr %slot867, align 8
  %p4946 = inttoptr i64 %v4945 to ptr
  store i32 0, ptr %p4946, align 4, !alias.scope !3, !noalias !4
  %v4947 = load i64, ptr %slot867, align 8
  %p4948 = inttoptr i64 %v4947 to ptr
  store i32 39, ptr %p4948, align 4, !alias.scope !3, !noalias !4
  %v4949 = load i64, ptr %slot867, align 8
  %v4950 = load i64, ptr %slot51, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  store i64 %v4949, ptr %p4951, align 8, !alias.scope !3, !noalias !4
  %v4952 = load i64, ptr %slot50, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %ld4954 = load i64, ptr %p4953, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4954, ptr %slot868, align 8
  %v4955 = load i64, ptr %slot51, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  %ld4957 = load i64, ptr %p4956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4957, ptr %slot869, align 8
  %v4958 = load i64, ptr %slot1, align 8
  %v4959 = load i64, ptr %slot868, align 8
  %v4960 = load i64, ptr %slot869, align 8
  %call4961 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v4958, i64 %v4959, i64 %v4960) nomerge, !dbg !140
  store i64 %call4961, ptr %slot870, align 8
  %v4962 = load i64, ptr %slot870, align 8
  %v4963 = load i64, ptr %slot50, align 8
  %p4964 = inttoptr i64 %v4963 to ptr
  store i64 %v4962, ptr %p4964, align 8, !alias.scope !3, !noalias !4
  %v4965 = load i64, ptr %slot16, align 8
  %p4966 = inttoptr i64 %v4965 to ptr
  %ld4967 = load i32, ptr %p4966, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4967, ptr %slot871, align 8
  %v4968 = load i32, ptr %slot871, align 8
  %cv4969 = zext i32 %v4968 to i64
  %cond4970 = icmp ne i64 %cv4969, 0
  br i1 %cond4970, label %bb_rcslotdrop1212, label %bb_rcslotdone1212
bb_rcslotdrop1212:
  %v4971 = load i64, ptr %slot16, align 8
  %p4972 = inttoptr i64 %v4971 to ptr
  store i32 0, ptr %p4972, align 4, !alias.scope !3, !noalias !4
  %v4973 = load i64, ptr %slot32, align 8
  store i64 %v4973, ptr %slot872, align 8
  %v4974 = load i64, ptr %slot17, align 8
  %p4975 = inttoptr i64 %v4974 to ptr
  %ld4976 = load i32, ptr %p4975, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4976, ptr %slot873, align 8
  %v4977 = load i32, ptr %slot873, align 8
  %op4978 = and i32 %v4977, 28
  store i32 %op4978, ptr %slot874, align 8
  %v4979 = load i32, ptr %slot874, align 8
  %cv4980 = zext i32 %v4979 to i64
  %cond4981 = icmp ne i64 %cv4980, 0
  br i1 %cond4981, label %bb_rcslotrole1212, label %bb_rcslotowner1212
bb_rcslotrole1212:
  %v4982 = load i64, ptr %slot69, align 8
  store i64 %v4982, ptr %slot875, align 8
  %v4983 = load i64, ptr %slot875, align 8
  %v4984 = load i64, ptr %slot872, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4983, i64 %v4984) nomerge, !dbg !140
  br label %bb_rcslotdone1212
bb_rcslotowner1212:
  %v4985 = load i64, ptr %slot69, align 8
  store i64 %v4985, ptr %slot876, align 8
  %v4986 = load i64, ptr %slot876, align 8
  %v4987 = load i64, ptr %slot872, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4986, i64 %v4987) nomerge, !dbg !140
  br label %bb_rcslotdone1212
bb_rcslotdone1212:
  %v4988 = load i64, ptr %slot50, align 8
  %p4989 = inttoptr i64 %v4988 to ptr
  %ld4990 = load i64, ptr %p4989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4990, ptr %slot877, align 8
  %v4991 = load i64, ptr %slot877, align 8
  %op4992 = xor i64 %v4991, 1
  store i64 %op4992, ptr %slot878, align 8
  %v4993 = load i64, ptr %slot878, align 8
  %v4994 = load i64, ptr %slot50, align 8
  %p4995 = inttoptr i64 %v4994 to ptr
  store i64 %v4993, ptr %p4995, align 8, !alias.scope !3, !noalias !4
  %v4996 = load i64, ptr %slot50, align 8
  %p4997 = inttoptr i64 %v4996 to ptr
  %ld4998 = load i64, ptr %p4997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4998, ptr %slot879, align 8
  %v4999 = load i64, ptr %slot879, align 8
  %cond5000 = icmp ne i64 %v4999, 0
  br i1 %cond5000, label %bb_next1222, label %bb_i46
bb_next1222:
  %v5001 = load i64, ptr %slot48, align 8
  %v5002 = load i64, ptr %slot50, align 8
  %p5003 = inttoptr i64 %v5002 to ptr
  store i64 %v5001, ptr %p5003, align 8, !alias.scope !3, !noalias !4
  %v5004 = load i64, ptr %slot50, align 8
  %p5005 = inttoptr i64 %v5004 to ptr
  %ld5006 = load i64, ptr %p5005, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5006, ptr %slot880, align 8
  %v5007 = load i64, ptr %slot1, align 8
  %v5008 = load i64, ptr %slot880, align 8
  %call5009 = call i64 @myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8(i64 %v5007, i64 %v5008) nomerge, !dbg !142
  store i64 %call5009, ptr %slot881, align 8
  %v5010 = load i64, ptr %slot881, align 8
  %v5011 = load i64, ptr %slot50, align 8
  %p5012 = inttoptr i64 %v5011 to ptr
  store i64 %v5010, ptr %p5012, align 8, !alias.scope !3, !noalias !4
  %v5013 = load i64, ptr %slot16, align 8
  %p5014 = inttoptr i64 %v5013 to ptr
  %ld5015 = load i32, ptr %p5014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5015, ptr %slot882, align 8
  %v5016 = load i32, ptr %slot882, align 8
  %cv5017 = zext i32 %v5016 to i64
  %cond5018 = icmp ne i64 %cv5017, 0
  br i1 %cond5018, label %bb_rcslotdrop1226, label %bb_rcslotdone1226
bb_rcslotdrop1226:
  %v5019 = load i64, ptr %slot16, align 8
  %p5020 = inttoptr i64 %v5019 to ptr
  store i32 0, ptr %p5020, align 4, !alias.scope !3, !noalias !4
  %v5021 = load i64, ptr %slot32, align 8
  store i64 %v5021, ptr %slot883, align 8
  %v5022 = load i64, ptr %slot17, align 8
  %p5023 = inttoptr i64 %v5022 to ptr
  %ld5024 = load i32, ptr %p5023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5024, ptr %slot884, align 8
  %v5025 = load i32, ptr %slot884, align 8
  %op5026 = and i32 %v5025, 28
  store i32 %op5026, ptr %slot885, align 8
  %v5027 = load i32, ptr %slot885, align 8
  %cv5028 = zext i32 %v5027 to i64
  %cond5029 = icmp ne i64 %cv5028, 0
  br i1 %cond5029, label %bb_rcslotrole1226, label %bb_rcslotowner1226
bb_rcslotrole1226:
  %v5030 = load i64, ptr %slot69, align 8
  store i64 %v5030, ptr %slot886, align 8
  %v5031 = load i64, ptr %slot886, align 8
  %v5032 = load i64, ptr %slot883, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5031, i64 %v5032) nomerge, !dbg !142
  br label %bb_rcslotdone1226
bb_rcslotowner1226:
  %v5033 = load i64, ptr %slot69, align 8
  store i64 %v5033, ptr %slot887, align 8
  %v5034 = load i64, ptr %slot887, align 8
  %v5035 = load i64, ptr %slot883, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5034, i64 %v5035) nomerge, !dbg !142
  br label %bb_rcslotdone1226
bb_rcslotdone1226:
  br label %bb_i37
bb_i46:
  %v5036 = load i64, ptr %slot48, align 8
  %v5037 = load i64, ptr %slot50, align 8
  %p5038 = inttoptr i64 %v5037 to ptr
  store i64 %v5036, ptr %p5038, align 8, !alias.scope !3, !noalias !4
  %v5039 = load i64, ptr %slot50, align 8
  %p5040 = inttoptr i64 %v5039 to ptr
  %ld5041 = load i64, ptr %p5040, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5041, ptr %slot888, align 8
  %v5042 = load i64, ptr %slot1, align 8
  %v5043 = load i64, ptr %slot888, align 8
  call void @myl_f_5e6209cefaee8ea6d883ace626debeee15428cfe0110c0f4efb2078a8004f54f(ptr sret([88 x i8]) align 8 %callresult890, i64 %v5042, i64 %v5043) nomerge, !dbg !144
  %addr5044 = ptrtoint ptr %callresult890 to i64
  store i64 %addr5044, ptr %slot889, align 8
  %v5045 = load i64, ptr %slot889, align 8
  %v5046 = load i64, ptr %slot50, align 8
  %p5047 = inttoptr i64 %v5046 to ptr
  store i64 %v5045, ptr %p5047, align 8, !alias.scope !3, !noalias !4
  %v5048 = load i64, ptr %slot50, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  %ld5050 = load i64, ptr %p5049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5050, ptr %slot891, align 8
  %v5051 = load i64, ptr %slot41, align 8
  store i64 %v5051, ptr %slot892, align 8
  %v5052 = load i64, ptr %slot891, align 8
  %v5053 = load i64, ptr %slot892, align 8
  %p5054 = inttoptr i64 %v5052 to ptr
  %p5055 = inttoptr i64 %v5053 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5055, ptr %p5054, i64 88, i1 false)
  %v5056 = load i64, ptr %slot30, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  store i32 2, ptr %p5057, align 4, !alias.scope !3, !noalias !4
  %v5058 = load i64, ptr %slot29, align 8
  %p5059 = inttoptr i64 %v5058 to ptr
  store i32 1, ptr %p5059, align 4, !alias.scope !3, !noalias !4
  %v5060 = load i64, ptr %slot16, align 8
  %p5061 = inttoptr i64 %v5060 to ptr
  %ld5062 = load i32, ptr %p5061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5062, ptr %slot893, align 8
  %v5063 = load i32, ptr %slot893, align 8
  %cv5064 = zext i32 %v5063 to i64
  %cond5065 = icmp ne i64 %cv5064, 0
  br i1 %cond5065, label %bb_rcslotdrop1241, label %bb_rcslotdone1241
bb_rcslotdrop1241:
  %v5066 = load i64, ptr %slot16, align 8
  %p5067 = inttoptr i64 %v5066 to ptr
  store i32 0, ptr %p5067, align 4, !alias.scope !3, !noalias !4
  %v5068 = load i64, ptr %slot32, align 8
  store i64 %v5068, ptr %slot894, align 8
  %v5069 = load i64, ptr %slot17, align 8
  %p5070 = inttoptr i64 %v5069 to ptr
  %ld5071 = load i32, ptr %p5070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5071, ptr %slot895, align 8
  %v5072 = load i32, ptr %slot895, align 8
  %op5073 = and i32 %v5072, 28
  store i32 %op5073, ptr %slot896, align 8
  %v5074 = load i32, ptr %slot896, align 8
  %cv5075 = zext i32 %v5074 to i64
  %cond5076 = icmp ne i64 %cv5075, 0
  br i1 %cond5076, label %bb_rcslotrole1241, label %bb_rcslotowner1241
bb_rcslotrole1241:
  %v5077 = load i64, ptr %slot69, align 8
  store i64 %v5077, ptr %slot897, align 8
  %v5078 = load i64, ptr %slot897, align 8
  %v5079 = load i64, ptr %slot894, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5078, i64 %v5079) nomerge, !dbg !144
  br label %bb_rcslotdone1241
bb_rcslotowner1241:
  %v5080 = load i64, ptr %slot69, align 8
  store i64 %v5080, ptr %slot898, align 8
  %v5081 = load i64, ptr %slot898, align 8
  %v5082 = load i64, ptr %slot894, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5081, i64 %v5082) nomerge, !dbg !144
  br label %bb_rcslotdone1241
bb_rcslotdone1241:
  %v5083 = load i64, ptr %slot32, align 8
  store i64 %v5083, ptr %slot899, align 8
  %v5084 = load i64, ptr %slot41, align 8
  store i64 %v5084, ptr %slot900, align 8
  %v5085 = load i64, ptr %slot900, align 8
  %v5086 = load i64, ptr %slot899, align 8
  %p5087 = inttoptr i64 %v5085 to ptr
  %p5088 = inttoptr i64 %v5086 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5088, ptr %p5087, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v5089 = load i64, ptr %slot17, align 8
  %p5090 = inttoptr i64 %v5089 to ptr
  store i32 2, ptr %p5090, align 4, !alias.scope !3, !noalias !4
  %v5091 = load i64, ptr %slot30, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  %ld5093 = load i32, ptr %p5092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5093, ptr %slot901, align 8
  %v5094 = load i32, ptr %slot901, align 8
  %v5095 = load i64, ptr %slot17, align 8
  %p5096 = inttoptr i64 %v5095 to ptr
  store i32 %v5094, ptr %p5096, align 4, !alias.scope !3, !noalias !4
  %v5097 = load i64, ptr %slot29, align 8
  %p5098 = inttoptr i64 %v5097 to ptr
  store i32 0, ptr %p5098, align 4, !alias.scope !3, !noalias !4
  %v5099 = load i64, ptr %slot16, align 8
  %p5100 = inttoptr i64 %v5099 to ptr
  store i32 1, ptr %p5100, align 4, !alias.scope !3, !noalias !4
  %v5101 = load i64, ptr %slot899, align 8
  %v5102 = load i64, ptr %slot50, align 8
  %p5103 = inttoptr i64 %v5102 to ptr
  store i64 %v5101, ptr %p5103, align 8, !alias.scope !3, !noalias !4
  %v5104 = load i64, ptr %slot50, align 8
  %p5105 = inttoptr i64 %v5104 to ptr
  %ld5106 = load i64, ptr %p5105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5106, ptr %slot902, align 8
  %v5107 = load i64, ptr %slot41, align 8
  store i64 %v5107, ptr %slot903, align 8
  %v5108 = load i64, ptr %slot70, align 8
  store i64 %v5108, ptr %slot904, align 8
  %v5109 = load i64, ptr %slot69, align 8
  %v5110 = load i64, ptr %slot903, align 8
  %v5111 = load i64, ptr %slot902, align 8
  %v5112 = load i64, ptr %slot904, align 8
  %cv5113 = trunc i64 %v5112 to i32
  %call5114 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v5109, i64 %v5110, i64 %v5111, i32 %cv5113) nomerge, !dbg !146
  store i32 %call5114, ptr %slot905, align 8
  %v5115 = load i32, ptr %slot905, align 8
  %cv5116 = zext i32 %v5115 to i64
  %cond5117 = icmp ne i64 %cv5116, 0
  br i1 %cond5117, label %bb_rcsuccess1260, label %bb_rcfailure1260
bb_rcfailure1260:
  %v5118 = load i64, ptr %slot69, align 8
  %p5119 = inttoptr i64 %v5118 to ptr
  %call5120 = call i32 @myl_rc_take_failure(ptr %p5119) nomerge, !dbg !146
  store i32 %call5120, ptr %slot906, align 8
  %v5121 = load i64, ptr %slot1, align 8
  %p5122 = inttoptr i64 %v5121 to ptr
  %v5123 = load i32, ptr %slot906, align 8
  %call5124 = call i32 @myl_qbe_rc_status(ptr %p5122, i32 %v5123) nomerge, !dbg !146
  store i32 %call5124, ptr %slot907, align 8
  br label %bb_failure
bb_rcsuccess1260:
  %v5125 = load i64, ptr %slot16, align 8
  %p5126 = inttoptr i64 %v5125 to ptr
  store i32 0, ptr %p5126, align 4, !alias.scope !3, !noalias !4
  %v5127 = load i64, ptr %slot30, align 8
  %p5128 = inttoptr i64 %v5127 to ptr
  store i32 2, ptr %p5128, align 4, !alias.scope !3, !noalias !4
  %v5129 = load i64, ptr %slot29, align 8
  %p5130 = inttoptr i64 %v5129 to ptr
  store i32 1, ptr %p5130, align 4, !alias.scope !3, !noalias !4
  %v5131 = load i64, ptr %slot14, align 8
  %p5132 = inttoptr i64 %v5131 to ptr
  %ld5133 = load i32, ptr %p5132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5133, ptr %slot908, align 8
  %v5134 = load i32, ptr %slot908, align 8
  %cv5135 = zext i32 %v5134 to i64
  %cond5136 = icmp ne i64 %cv5135, 0
  br i1 %cond5136, label %bb_rcslotdrop1269, label %bb_rcslotdone1269
bb_rcslotdrop1269:
  %v5137 = load i64, ptr %slot14, align 8
  %p5138 = inttoptr i64 %v5137 to ptr
  store i32 0, ptr %p5138, align 4, !alias.scope !3, !noalias !4
  %v5139 = load i64, ptr %slot49, align 8
  store i64 %v5139, ptr %slot909, align 8
  %v5140 = load i64, ptr %slot15, align 8
  %p5141 = inttoptr i64 %v5140 to ptr
  %ld5142 = load i32, ptr %p5141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5142, ptr %slot910, align 8
  %v5143 = load i32, ptr %slot910, align 8
  %op5144 = and i32 %v5143, 28
  store i32 %op5144, ptr %slot911, align 8
  %v5145 = load i32, ptr %slot911, align 8
  %cv5146 = zext i32 %v5145 to i64
  %cond5147 = icmp ne i64 %cv5146, 0
  br i1 %cond5147, label %bb_rcslotrole1269, label %bb_rcslotowner1269
bb_rcslotrole1269:
  %v5148 = load i64, ptr %slot69, align 8
  store i64 %v5148, ptr %slot912, align 8
  %v5149 = load i64, ptr %slot912, align 8
  %v5150 = load i64, ptr %slot909, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5149, i64 %v5150) nomerge, !dbg !146
  br label %bb_rcslotdone1269
bb_rcslotowner1269:
  %v5151 = load i64, ptr %slot69, align 8
  store i64 %v5151, ptr %slot913, align 8
  %v5152 = load i64, ptr %slot913, align 8
  %v5153 = load i64, ptr %slot909, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5152, i64 %v5153) nomerge, !dbg !146
  br label %bb_rcslotdone1269
bb_rcslotdone1269:
  %v5154 = load i64, ptr %slot49, align 8
  store i64 %v5154, ptr %slot914, align 8
  %v5155 = load i64, ptr %slot41, align 8
  store i64 %v5155, ptr %slot915, align 8
  %v5156 = load i64, ptr %slot915, align 8
  %v5157 = load i64, ptr %slot914, align 8
  %p5158 = inttoptr i64 %v5156 to ptr
  %p5159 = inttoptr i64 %v5157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5159, ptr %p5158, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v5160 = load i64, ptr %slot29, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  store i32 0, ptr %p5161, align 4, !alias.scope !3, !noalias !4
  %v5162 = load i64, ptr %slot15, align 8
  %p5163 = inttoptr i64 %v5162 to ptr
  store i32 2, ptr %p5163, align 4, !alias.scope !3, !noalias !4
  %v5164 = load i64, ptr %slot30, align 8
  %p5165 = inttoptr i64 %v5164 to ptr
  %ld5166 = load i32, ptr %p5165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5166, ptr %slot916, align 8
  %v5167 = load i32, ptr %slot916, align 8
  %v5168 = load i64, ptr %slot15, align 8
  %p5169 = inttoptr i64 %v5168 to ptr
  store i32 %v5167, ptr %p5169, align 4, !alias.scope !3, !noalias !4
  %v5170 = load i64, ptr %slot14, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  store i32 1, ptr %p5171, align 4, !alias.scope !3, !noalias !4
  %v5172 = load i64, ptr %slot48, align 8
  %v5173 = load i64, ptr %slot50, align 8
  %p5174 = inttoptr i64 %v5173 to ptr
  store i64 %v5172, ptr %p5174, align 8, !alias.scope !3, !noalias !4
  %v5175 = load i64, ptr %slot50, align 8
  %p5176 = inttoptr i64 %v5175 to ptr
  %ld5177 = load i64, ptr %p5176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5177, ptr %slot917, align 8
  %v5178 = load i64, ptr %slot917, align 8
  %op5179 = add i64 %v5178, 0
  store i64 %op5179, ptr %slot918, align 8
  %v5180 = load i64, ptr %slot918, align 8
  %v5181 = load i64, ptr %slot50, align 8
  %p5182 = inttoptr i64 %v5181 to ptr
  store i64 %v5180, ptr %p5182, align 8, !alias.scope !3, !noalias !4
  %v5183 = load i64, ptr %slot16, align 8
  %p5184 = inttoptr i64 %v5183 to ptr
  %ld5185 = load i32, ptr %p5184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5185, ptr %slot919, align 8
  %v5186 = load i32, ptr %slot919, align 8
  %cv5187 = zext i32 %v5186 to i64
  %cond5188 = icmp ne i64 %cv5187, 0
  br i1 %cond5188, label %bb_rcslotdrop1287, label %bb_rcslotdone1287
bb_rcslotdrop1287:
  %v5189 = load i64, ptr %slot16, align 8
  %p5190 = inttoptr i64 %v5189 to ptr
  store i32 0, ptr %p5190, align 4, !alias.scope !3, !noalias !4
  %v5191 = load i64, ptr %slot32, align 8
  store i64 %v5191, ptr %slot920, align 8
  %v5192 = load i64, ptr %slot17, align 8
  %p5193 = inttoptr i64 %v5192 to ptr
  %ld5194 = load i32, ptr %p5193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5194, ptr %slot921, align 8
  %v5195 = load i32, ptr %slot921, align 8
  %op5196 = and i32 %v5195, 28
  store i32 %op5196, ptr %slot922, align 8
  %v5197 = load i32, ptr %slot922, align 8
  %cv5198 = zext i32 %v5197 to i64
  %cond5199 = icmp ne i64 %cv5198, 0
  br i1 %cond5199, label %bb_rcslotrole1287, label %bb_rcslotowner1287
bb_rcslotrole1287:
  %v5200 = load i64, ptr %slot69, align 8
  store i64 %v5200, ptr %slot923, align 8
  %v5201 = load i64, ptr %slot923, align 8
  %v5202 = load i64, ptr %slot920, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5201, i64 %v5202) nomerge, !dbg !148
  br label %bb_rcslotdone1287
bb_rcslotowner1287:
  %v5203 = load i64, ptr %slot69, align 8
  store i64 %v5203, ptr %slot924, align 8
  %v5204 = load i64, ptr %slot924, align 8
  %v5205 = load i64, ptr %slot920, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5204, i64 %v5205) nomerge, !dbg !148
  br label %bb_rcslotdone1287
bb_rcslotdone1287:
  %v5206 = load i64, ptr %slot50, align 8
  %p5207 = inttoptr i64 %v5206 to ptr
  %ld5208 = load i64, ptr %p5207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5208, ptr %slot925, align 8
  %v5209 = load i64, ptr %slot16, align 8
  %p5210 = inttoptr i64 %v5209 to ptr
  %ld5211 = load i32, ptr %p5210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5211, ptr %slot926, align 8
  %v5212 = load i64, ptr %slot17, align 8
  %p5213 = inttoptr i64 %v5212 to ptr
  %ld5214 = load i32, ptr %p5213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5214, ptr %slot927, align 8
  %v5215 = load i32, ptr %slot927, align 8
  %op5216 = and i32 %v5215, 24
  store i32 %op5216, ptr %slot927, align 8
  %v5217 = load i32, ptr %slot927, align 8
  %cmp5218 = icmp eq i32 %v5217, 0
  %cv5219 = zext i1 %cmp5218 to i32
  store i32 %cv5219, ptr %slot928, align 8
  %v5220 = load i32, ptr %slot926, align 8
  %v5221 = load i32, ptr %slot928, align 8
  %op5222 = and i32 %v5220, %v5221
  store i32 %op5222, ptr %slot929, align 8
  %v5223 = load i64, ptr %slot70, align 8
  store i64 %v5223, ptr %slot930, align 8
  %v5224 = load i32, ptr %slot929, align 8
  %op5225 = mul i32 %v5224, 4
  store i32 %op5225, ptr %slot931, align 8
  %v5226 = load i32, ptr %slot931, align 8
  %op5227 = or i32 %v5226, 0
  store i32 %op5227, ptr %slot932, align 8
  %v5228 = load i64, ptr %slot41, align 8
  store i64 %v5228, ptr %slot933, align 8
  %v5229 = load i64, ptr %slot69, align 8
  %v5230 = load i64, ptr %slot933, align 8
  %v5231 = load i64, ptr %slot925, align 8
  %v5232 = load i64, ptr %slot930, align 8
  %cv5233 = trunc i64 %v5232 to i32
  %v5234 = load i32, ptr %slot932, align 8
  %call5235 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_publish(i64 %v5229, i64 %v5230, i64 %v5231, i32 %cv5233, i32 %v5234) nomerge, !dbg !150
  store i32 %call5235, ptr %slot934, align 8
  %v5236 = load i32, ptr %slot934, align 8
  %cv5237 = zext i32 %v5236 to i64
  %cond5238 = icmp ne i64 %cv5237, 0
  br i1 %cond5238, label %bb_rcsuccess1308, label %bb_rcfailure1308
bb_rcfailure1308:
  %v5239 = load i64, ptr %slot69, align 8
  %p5240 = inttoptr i64 %v5239 to ptr
  %call5241 = call i32 @myl_rc_take_failure(ptr %p5240) nomerge, !dbg !150
  store i32 %call5241, ptr %slot935, align 8
  %v5242 = load i64, ptr %slot1, align 8
  %p5243 = inttoptr i64 %v5242 to ptr
  %v5244 = load i32, ptr %slot935, align 8
  %call5245 = call i32 @myl_qbe_rc_status(ptr %p5243, i32 %v5244) nomerge, !dbg !150
  store i32 %call5245, ptr %slot936, align 8
  br label %bb_failure
bb_rcsuccess1308:
  %v5246 = load i32, ptr %slot929, align 8
  %cv5247 = zext i32 %v5246 to i64
  %cond5248 = icmp ne i64 %cv5247, 0
  br i1 %cond5248, label %bb_rchtaken1311, label %bb_rchcopied1311
bb_rchcopied1311:
  %v5249 = load i64, ptr %slot16, align 8
  %p5250 = inttoptr i64 %v5249 to ptr
  %ld5251 = load i32, ptr %p5250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5251, ptr %slot937, align 8
  %v5252 = load i32, ptr %slot937, align 8
  %cv5253 = zext i32 %v5252 to i64
  %cond5254 = icmp ne i64 %cv5253, 0
  br i1 %cond5254, label %bb_rcslotdrop1314, label %bb_rcslotdone1314
bb_rcslotdrop1314:
  %v5255 = load i64, ptr %slot16, align 8
  %p5256 = inttoptr i64 %v5255 to ptr
  store i32 0, ptr %p5256, align 4, !alias.scope !3, !noalias !4
  %v5257 = load i64, ptr %slot32, align 8
  store i64 %v5257, ptr %slot938, align 8
  %v5258 = load i64, ptr %slot17, align 8
  %p5259 = inttoptr i64 %v5258 to ptr
  %ld5260 = load i32, ptr %p5259, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5260, ptr %slot939, align 8
  %v5261 = load i32, ptr %slot939, align 8
  %op5262 = and i32 %v5261, 28
  store i32 %op5262, ptr %slot940, align 8
  %v5263 = load i32, ptr %slot940, align 8
  %cv5264 = zext i32 %v5263 to i64
  %cond5265 = icmp ne i64 %cv5264, 0
  br i1 %cond5265, label %bb_rcslotrole1314, label %bb_rcslotowner1314
bb_rcslotrole1314:
  %v5266 = load i64, ptr %slot69, align 8
  store i64 %v5266, ptr %slot941, align 8
  %v5267 = load i64, ptr %slot941, align 8
  %v5268 = load i64, ptr %slot938, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5267, i64 %v5268) nomerge, !dbg !150
  br label %bb_rcslotdone1314
bb_rcslotowner1314:
  %v5269 = load i64, ptr %slot69, align 8
  store i64 %v5269, ptr %slot942, align 8
  %v5270 = load i64, ptr %slot942, align 8
  %v5271 = load i64, ptr %slot938, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5270, i64 %v5271) nomerge, !dbg !150
  br label %bb_rcslotdone1314
bb_rcslotdone1314:
  br label %bb_rchprepared1311
bb_rchtaken1311:
  %v5272 = load i64, ptr %slot16, align 8
  %p5273 = inttoptr i64 %v5272 to ptr
  store i32 0, ptr %p5273, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1311
bb_rchprepared1311:
  %v5274 = load i64, ptr %slot30, align 8
  %p5275 = inttoptr i64 %v5274 to ptr
  store i32 2, ptr %p5275, align 4, !alias.scope !3, !noalias !4
  %v5276 = load i64, ptr %slot29, align 8
  %p5277 = inttoptr i64 %v5276 to ptr
  store i32 1, ptr %p5277, align 4, !alias.scope !3, !noalias !4
  %v5278 = load i64, ptr %slot32, align 8
  store i64 %v5278, ptr %slot943, align 8
  %v5279 = load i64, ptr %slot41, align 8
  store i64 %v5279, ptr %slot944, align 8
  %v5280 = load i64, ptr %slot944, align 8
  %v5281 = load i64, ptr %slot943, align 8
  %p5282 = inttoptr i64 %v5280 to ptr
  %p5283 = inttoptr i64 %v5281 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5283, ptr %p5282, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v5284 = load i64, ptr %slot17, align 8
  %p5285 = inttoptr i64 %v5284 to ptr
  store i32 2, ptr %p5285, align 4, !alias.scope !3, !noalias !4
  %v5286 = load i64, ptr %slot30, align 8
  %p5287 = inttoptr i64 %v5286 to ptr
  %ld5288 = load i32, ptr %p5287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5288, ptr %slot945, align 8
  %v5289 = load i32, ptr %slot945, align 8
  %v5290 = load i64, ptr %slot17, align 8
  %p5291 = inttoptr i64 %v5290 to ptr
  store i32 %v5289, ptr %p5291, align 4, !alias.scope !3, !noalias !4
  %v5292 = load i64, ptr %slot29, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  store i32 0, ptr %p5293, align 4, !alias.scope !3, !noalias !4
  %v5294 = load i64, ptr %slot16, align 8
  %p5295 = inttoptr i64 %v5294 to ptr
  store i32 1, ptr %p5295, align 4, !alias.scope !3, !noalias !4
  %v5296 = load i64, ptr %slot943, align 8
  %v5297 = load i64, ptr %slot50, align 8
  %p5298 = inttoptr i64 %v5297 to ptr
  store i64 %v5296, ptr %p5298, align 8, !alias.scope !3, !noalias !4
  %v5299 = load i64, ptr %slot50, align 8
  %p5300 = inttoptr i64 %v5299 to ptr
  %ld5301 = load i64, ptr %p5300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5301, ptr %slot946, align 8
  %v5302 = load i64, ptr %slot41, align 8
  store i64 %v5302, ptr %slot947, align 8
  %v5303 = load i64, ptr %slot70, align 8
  store i64 %v5303, ptr %slot948, align 8
  %v5304 = load i64, ptr %slot69, align 8
  %v5305 = load i64, ptr %slot947, align 8
  %v5306 = load i64, ptr %slot946, align 8
  %v5307 = load i64, ptr %slot948, align 8
  %cv5308 = trunc i64 %v5307 to i32
  %call5309 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64 %v5304, i64 %v5305, i64 %v5306, i32 %cv5308) nomerge, !dbg !152
  store i32 %call5309, ptr %slot949, align 8
  %v5310 = load i32, ptr %slot949, align 8
  %cv5311 = zext i32 %v5310 to i64
  %cond5312 = icmp ne i64 %cv5311, 0
  br i1 %cond5312, label %bb_rcsuccess1336, label %bb_rcfailure1336
bb_rcfailure1336:
  %v5313 = load i64, ptr %slot69, align 8
  %p5314 = inttoptr i64 %v5313 to ptr
  %call5315 = call i32 @myl_rc_take_failure(ptr %p5314) nomerge, !dbg !152
  store i32 %call5315, ptr %slot950, align 8
  %v5316 = load i64, ptr %slot1, align 8
  %p5317 = inttoptr i64 %v5316 to ptr
  %v5318 = load i32, ptr %slot950, align 8
  %call5319 = call i32 @myl_qbe_rc_status(ptr %p5317, i32 %v5318) nomerge, !dbg !152
  store i32 %call5319, ptr %slot951, align 8
  br label %bb_failure
bb_rcsuccess1336:
  %v5320 = load i64, ptr %slot16, align 8
  %p5321 = inttoptr i64 %v5320 to ptr
  store i32 0, ptr %p5321, align 4, !alias.scope !3, !noalias !4
  %v5322 = load i64, ptr %slot30, align 8
  %p5323 = inttoptr i64 %v5322 to ptr
  store i32 2, ptr %p5323, align 4, !alias.scope !3, !noalias !4
  %v5324 = load i64, ptr %slot29, align 8
  %p5325 = inttoptr i64 %v5324 to ptr
  store i32 1, ptr %p5325, align 4, !alias.scope !3, !noalias !4
  %v5326 = load i64, ptr %slot42, align 8
  %p5327 = inttoptr i64 %v5326 to ptr
  %ld5328 = load i64, ptr %p5327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5328, ptr %slot952, align 8
  %v5329 = load i64, ptr %slot69, align 8
  store i64 %v5329, ptr %slot953, align 8
  %v5330 = load i64, ptr %slot953, align 8
  %v5331 = load i64, ptr %slot952, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5330, i64 %v5331) nomerge, !dbg !152
  %v5332 = load i64, ptr %slot41, align 8
  store i64 %v5332, ptr %slot954, align 8
  %v5333 = load i64, ptr %slot954, align 8
  %v5334 = load i64, ptr %slot952, align 8
  %p5335 = inttoptr i64 %v5333 to ptr
  %p5336 = inttoptr i64 %v5334 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5336, ptr %p5335, i64 208, i1 false), !alias.scope !10000000
  %v5337 = load i64, ptr %slot29, align 8
  %p5338 = inttoptr i64 %v5337 to ptr
  store i32 0, ptr %p5338, align 4, !alias.scope !3, !noalias !4
  %v5339 = load i64, ptr %slot48, align 8
  %v5340 = load i64, ptr %slot50, align 8
  %p5341 = inttoptr i64 %v5340 to ptr
  store i64 %v5339, ptr %p5341, align 8, !alias.scope !3, !noalias !4
  %v5342 = load i64, ptr %slot50, align 8
  %p5343 = inttoptr i64 %v5342 to ptr
  %ld5344 = load i64, ptr %p5343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5344, ptr %slot955, align 8
  %v5345 = load i64, ptr %slot955, align 8
  %op5346 = add i64 %v5345, 208
  store i64 %op5346, ptr %slot956, align 8
  %v5347 = load i64, ptr %slot956, align 8
  %v5348 = load i64, ptr %slot50, align 8
  %p5349 = inttoptr i64 %v5348 to ptr
  store i64 %v5347, ptr %p5349, align 8, !alias.scope !3, !noalias !4
  %v5350 = load i64, ptr %slot16, align 8
  %p5351 = inttoptr i64 %v5350 to ptr
  %ld5352 = load i32, ptr %p5351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5352, ptr %slot957, align 8
  %v5353 = load i32, ptr %slot957, align 8
  %cv5354 = zext i32 %v5353 to i64
  %cond5355 = icmp ne i64 %cv5354, 0
  br i1 %cond5355, label %bb_rcslotdrop1350, label %bb_rcslotdone1350
bb_rcslotdrop1350:
  %v5356 = load i64, ptr %slot16, align 8
  %p5357 = inttoptr i64 %v5356 to ptr
  store i32 0, ptr %p5357, align 4, !alias.scope !3, !noalias !4
  %v5358 = load i64, ptr %slot32, align 8
  store i64 %v5358, ptr %slot958, align 8
  %v5359 = load i64, ptr %slot17, align 8
  %p5360 = inttoptr i64 %v5359 to ptr
  %ld5361 = load i32, ptr %p5360, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5361, ptr %slot959, align 8
  %v5362 = load i32, ptr %slot959, align 8
  %op5363 = and i32 %v5362, 28
  store i32 %op5363, ptr %slot960, align 8
  %v5364 = load i32, ptr %slot960, align 8
  %cv5365 = zext i32 %v5364 to i64
  %cond5366 = icmp ne i64 %cv5365, 0
  br i1 %cond5366, label %bb_rcslotrole1350, label %bb_rcslotowner1350
bb_rcslotrole1350:
  %v5367 = load i64, ptr %slot69, align 8
  store i64 %v5367, ptr %slot961, align 8
  %v5368 = load i64, ptr %slot961, align 8
  %v5369 = load i64, ptr %slot958, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5368, i64 %v5369) nomerge, !dbg !154
  br label %bb_rcslotdone1350
bb_rcslotowner1350:
  %v5370 = load i64, ptr %slot69, align 8
  store i64 %v5370, ptr %slot962, align 8
  %v5371 = load i64, ptr %slot962, align 8
  %v5372 = load i64, ptr %slot958, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5371, i64 %v5372) nomerge, !dbg !154
  br label %bb_rcslotdone1350
bb_rcslotdone1350:
  %v5373 = load i64, ptr %slot50, align 8
  %p5374 = inttoptr i64 %v5373 to ptr
  %ld5375 = load i64, ptr %p5374, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5375, ptr %slot963, align 8
  %v5376 = load i64, ptr %slot16, align 8
  %p5377 = inttoptr i64 %v5376 to ptr
  %ld5378 = load i32, ptr %p5377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5378, ptr %slot964, align 8
  %v5379 = load i64, ptr %slot17, align 8
  %p5380 = inttoptr i64 %v5379 to ptr
  %ld5381 = load i32, ptr %p5380, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5381, ptr %slot965, align 8
  %v5382 = load i32, ptr %slot965, align 8
  %op5383 = and i32 %v5382, 24
  store i32 %op5383, ptr %slot965, align 8
  %v5384 = load i32, ptr %slot965, align 8
  %cmp5385 = icmp eq i32 %v5384, 0
  %cv5386 = zext i1 %cmp5385 to i32
  store i32 %cv5386, ptr %slot966, align 8
  %v5387 = load i32, ptr %slot964, align 8
  %v5388 = load i32, ptr %slot966, align 8
  %op5389 = and i32 %v5387, %v5388
  store i32 %op5389, ptr %slot967, align 8
  %v5390 = load i64, ptr %slot70, align 8
  store i64 %v5390, ptr %slot968, align 8
  %v5391 = load i32, ptr %slot967, align 8
  %op5392 = mul i32 %v5391, 4
  store i32 %op5392, ptr %slot969, align 8
  %v5393 = load i32, ptr %slot969, align 8
  %op5394 = or i32 %v5393, 0
  store i32 %op5394, ptr %slot970, align 8
  %v5395 = load i64, ptr %slot41, align 8
  store i64 %v5395, ptr %slot971, align 8
  %v5396 = load i64, ptr %slot69, align 8
  %v5397 = load i64, ptr %slot971, align 8
  %v5398 = load i64, ptr %slot963, align 8
  %v5399 = load i64, ptr %slot968, align 8
  %cv5400 = trunc i64 %v5399 to i32
  %v5401 = load i32, ptr %slot970, align 8
  %call5402 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64 %v5396, i64 %v5397, i64 %v5398, i32 %cv5400, i32 %v5401) nomerge, !dbg !156
  store i32 %call5402, ptr %slot972, align 8
  %v5403 = load i32, ptr %slot972, align 8
  %cv5404 = zext i32 %v5403 to i64
  %cond5405 = icmp ne i64 %cv5404, 0
  br i1 %cond5405, label %bb_rcsuccess1371, label %bb_rcfailure1371
bb_rcfailure1371:
  %v5406 = load i64, ptr %slot69, align 8
  %p5407 = inttoptr i64 %v5406 to ptr
  %call5408 = call i32 @myl_rc_take_failure(ptr %p5407) nomerge, !dbg !156
  store i32 %call5408, ptr %slot973, align 8
  %v5409 = load i64, ptr %slot1, align 8
  %p5410 = inttoptr i64 %v5409 to ptr
  %v5411 = load i32, ptr %slot973, align 8
  %call5412 = call i32 @myl_qbe_rc_status(ptr %p5410, i32 %v5411) nomerge, !dbg !156
  store i32 %call5412, ptr %slot974, align 8
  br label %bb_failure
bb_rcsuccess1371:
  %v5413 = load i32, ptr %slot967, align 8
  %cv5414 = zext i32 %v5413 to i64
  %cond5415 = icmp ne i64 %cv5414, 0
  br i1 %cond5415, label %bb_rchtaken1374, label %bb_rchcopied1374
bb_rchcopied1374:
  %v5416 = load i64, ptr %slot16, align 8
  %p5417 = inttoptr i64 %v5416 to ptr
  %ld5418 = load i32, ptr %p5417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5418, ptr %slot975, align 8
  %v5419 = load i32, ptr %slot975, align 8
  %cv5420 = zext i32 %v5419 to i64
  %cond5421 = icmp ne i64 %cv5420, 0
  br i1 %cond5421, label %bb_rcslotdrop1377, label %bb_rcslotdone1377
bb_rcslotdrop1377:
  %v5422 = load i64, ptr %slot16, align 8
  %p5423 = inttoptr i64 %v5422 to ptr
  store i32 0, ptr %p5423, align 4, !alias.scope !3, !noalias !4
  %v5424 = load i64, ptr %slot32, align 8
  store i64 %v5424, ptr %slot976, align 8
  %v5425 = load i64, ptr %slot17, align 8
  %p5426 = inttoptr i64 %v5425 to ptr
  %ld5427 = load i32, ptr %p5426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5427, ptr %slot977, align 8
  %v5428 = load i32, ptr %slot977, align 8
  %op5429 = and i32 %v5428, 28
  store i32 %op5429, ptr %slot978, align 8
  %v5430 = load i32, ptr %slot978, align 8
  %cv5431 = zext i32 %v5430 to i64
  %cond5432 = icmp ne i64 %cv5431, 0
  br i1 %cond5432, label %bb_rcslotrole1377, label %bb_rcslotowner1377
bb_rcslotrole1377:
  %v5433 = load i64, ptr %slot69, align 8
  store i64 %v5433, ptr %slot979, align 8
  %v5434 = load i64, ptr %slot979, align 8
  %v5435 = load i64, ptr %slot976, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v5434, i64 %v5435) nomerge, !dbg !156
  br label %bb_rcslotdone1377
bb_rcslotowner1377:
  %v5436 = load i64, ptr %slot69, align 8
  store i64 %v5436, ptr %slot980, align 8
  %v5437 = load i64, ptr %slot980, align 8
  %v5438 = load i64, ptr %slot976, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v5437, i64 %v5438) nomerge, !dbg !156
  br label %bb_rcslotdone1377
bb_rcslotdone1377:
  br label %bb_rchprepared1374
bb_rchtaken1374:
  %v5439 = load i64, ptr %slot16, align 8
  %p5440 = inttoptr i64 %v5439 to ptr
  store i32 0, ptr %p5440, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1374
bb_rchprepared1374:
  %v5441 = load i64, ptr %slot30, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  store i32 2, ptr %p5442, align 4, !alias.scope !3, !noalias !4
  %v5443 = load i64, ptr %slot29, align 8
  %p5444 = inttoptr i64 %v5443 to ptr
  store i32 1, ptr %p5444, align 4, !alias.scope !3, !noalias !4
  %v5445 = load i64, ptr %slot32, align 8
  store i64 %v5445, ptr %slot981, align 8
  %v5446 = load i64, ptr %slot41, align 8
  store i64 %v5446, ptr %slot982, align 8
  %v5447 = load i64, ptr %slot982, align 8
  %v5448 = load i64, ptr %slot981, align 8
  %p5449 = inttoptr i64 %v5447 to ptr
  %p5450 = inttoptr i64 %v5448 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5450, ptr %p5449, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5451 = load i64, ptr %slot17, align 8
  %p5452 = inttoptr i64 %v5451 to ptr
  store i32 2, ptr %p5452, align 4, !alias.scope !3, !noalias !4
  %v5453 = load i64, ptr %slot30, align 8
  %p5454 = inttoptr i64 %v5453 to ptr
  %ld5455 = load i32, ptr %p5454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5455, ptr %slot983, align 8
  %v5456 = load i32, ptr %slot983, align 8
  %v5457 = load i64, ptr %slot17, align 8
  %p5458 = inttoptr i64 %v5457 to ptr
  store i32 %v5456, ptr %p5458, align 4, !alias.scope !3, !noalias !4
  %v5459 = load i64, ptr %slot29, align 8
  %p5460 = inttoptr i64 %v5459 to ptr
  store i32 0, ptr %p5460, align 4, !alias.scope !3, !noalias !4
  %v5461 = load i64, ptr %slot16, align 8
  %p5462 = inttoptr i64 %v5461 to ptr
  store i32 1, ptr %p5462, align 4, !alias.scope !3, !noalias !4
  %v5463 = load i64, ptr %slot981, align 8
  %v5464 = load i64, ptr %slot50, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i64 %v5463, ptr %p5465, align 8, !alias.scope !3, !noalias !4
  %v5466 = load i64, ptr %slot50, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  %ld5468 = load i64, ptr %p5467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5468, ptr %slot984, align 8
  %v5469 = load i64, ptr %slot41, align 8
  store i64 %v5469, ptr %slot985, align 8
  %v5470 = load i64, ptr %slot70, align 8
  store i64 %v5470, ptr %slot986, align 8
  %v5471 = load i64, ptr %slot984, align 8
  %op5472 = add i64 %v5471, 0
  store i64 %op5472, ptr %slot987, align 8
  %v5473 = load i64, ptr %slot987, align 8
  %p5474 = inttoptr i64 %v5473 to ptr
  %ld5475 = load i64, ptr %p5474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5475, ptr %slot988, align 8
  %v5476 = load i64, ptr %slot988, align 8
  %cmp5477 = icmp ne i64 %v5476, 0
  %cv5478 = zext i1 %cmp5477 to i32
  store i32 %cv5478, ptr %slot989, align 8
  %v5479 = load i32, ptr %slot989, align 8
  %cv5480 = zext i32 %v5479 to i64
  %cond5481 = icmp ne i64 %cv5480, 0
  br i1 %cond5481, label %bb_rcmoveheader1401, label %bb_rcmovenext1401
bb_rcmoveheader1401:
  %v5482 = load i64, ptr %slot988, align 8
  %op5483 = sub i64 %v5482, 16
  store i64 %op5483, ptr %slot990, align 8
  %v5484 = load i64, ptr %slot988, align 8
  %p5485 = inttoptr i64 %v5484 to ptr
  %rgep5486 = getelementptr i8, ptr %p5485, i64 -16
  %ld5487 = load i64, ptr %rgep5486, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5487, ptr %slot991, align 8
  %v5488 = load i64, ptr %slot991, align 8
  %op5489 = and i64 %v5488, 5764607523034234881
  store i64 %op5489, ptr %slot992, align 8
  %v5490 = load i64, ptr %slot992, align 8
  %cmp5491 = icmp ne i64 %v5490, 0
  %cv5492 = zext i1 %cmp5491 to i32
  store i32 %cv5492, ptr %slot993, align 8
  %v5493 = load i32, ptr %slot993, align 8
  %cv5494 = zext i32 %v5493 to i64
  %cond5495 = icmp ne i64 %cv5494, 0
  br i1 %cond5495, label %bb_rcmoveslow1398, label %bb_rcmovenext1401
bb_rcmovenext1401:
  %v5496 = load i64, ptr %slot984, align 8
  %op5497 = add i64 %v5496, 8
  store i64 %op5497, ptr %slot994, align 8
  %v5498 = load i64, ptr %slot994, align 8
  %p5499 = inttoptr i64 %v5498 to ptr
  %ld5500 = load i64, ptr %p5499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5500, ptr %slot995, align 8
  %v5501 = load i64, ptr %slot995, align 8
  %cmp5502 = icmp ne i64 %v5501, 0
  %cv5503 = zext i1 %cmp5502 to i32
  store i32 %cv5503, ptr %slot996, align 8
  %v5504 = load i32, ptr %slot996, align 8
  %cv5505 = zext i32 %v5504 to i64
  %cond5506 = icmp ne i64 %cv5505, 0
  br i1 %cond5506, label %bb_rcmoveheader1409, label %bb_rcmovenext1409
bb_rcmoveheader1409:
  %v5507 = load i64, ptr %slot995, align 8
  %op5508 = sub i64 %v5507, 16
  store i64 %op5508, ptr %slot997, align 8
  %v5509 = load i64, ptr %slot995, align 8
  %p5510 = inttoptr i64 %v5509 to ptr
  %rgep5511 = getelementptr i8, ptr %p5510, i64 -16
  %ld5512 = load i64, ptr %rgep5511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5512, ptr %slot998, align 8
  %v5513 = load i64, ptr %slot998, align 8
  %op5514 = and i64 %v5513, 5764607523034234881
  store i64 %op5514, ptr %slot999, align 8
  %v5515 = load i64, ptr %slot999, align 8
  %cmp5516 = icmp ne i64 %v5515, 0
  %cv5517 = zext i1 %cmp5516 to i32
  store i32 %cv5517, ptr %slot1000, align 8
  %v5518 = load i32, ptr %slot1000, align 8
  %cv5519 = zext i32 %v5518 to i64
  %cond5520 = icmp ne i64 %cv5519, 0
  br i1 %cond5520, label %bb_rcmoveslow1398, label %bb_rcmovenext1409
bb_rcmovenext1409:
  %v5521 = load i64, ptr %slot984, align 8
  %v5522 = load i64, ptr %slot985, align 8
  %p5523 = inttoptr i64 %v5521 to ptr
  %p5524 = inttoptr i64 %v5522 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5524, ptr %p5523, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5525 = load i64, ptr %slot984, align 8
  %p5526 = inttoptr i64 %v5525 to ptr
  store i64 0, ptr %p5526, align 8, !alias.scope !3, !noalias !4
  %v5527 = load i64, ptr %slot984, align 8
  %op5528 = add i64 %v5527, 8
  store i64 %op5528, ptr %slot1001, align 8
  %v5529 = load i64, ptr %slot1001, align 8
  %p5530 = inttoptr i64 %v5529 to ptr
  store i64 0, ptr %p5530, align 8, !alias.scope !3, !noalias !4
  %v5531 = load i64, ptr %slot984, align 8
  %op5532 = add i64 %v5531, 16
  store i64 %op5532, ptr %slot1002, align 8
  %v5533 = load i64, ptr %slot1002, align 8
  %p5534 = inttoptr i64 %v5533 to ptr
  store i64 0, ptr %p5534, align 8, !alias.scope !3, !noalias !4
  %v5535 = load i64, ptr %slot984, align 8
  %op5536 = add i64 %v5535, 24
  store i64 %op5536, ptr %slot1003, align 8
  %v5537 = load i64, ptr %slot1003, align 8
  %p5538 = inttoptr i64 %v5537 to ptr
  store i64 0, ptr %p5538, align 8, !alias.scope !3, !noalias !4
  %v5539 = load i64, ptr %slot984, align 8
  %op5540 = add i64 %v5539, 32
  store i64 %op5540, ptr %slot1004, align 8
  %v5541 = load i64, ptr %slot1004, align 8
  %p5542 = inttoptr i64 %v5541 to ptr
  store i64 0, ptr %p5542, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1398
bb_rcmoveslow1398:
  %v5543 = load i64, ptr %slot69, align 8
  %v5544 = load i64, ptr %slot985, align 8
  %v5545 = load i64, ptr %slot984, align 8
  %v5546 = load i64, ptr %slot986, align 8
  %cv5547 = trunc i64 %v5546 to i32
  %call5548 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v5543, i64 %v5544, i64 %v5545, i32 %cv5547) nomerge, !dbg !158
  store i32 %call5548, ptr %slot1005, align 8
  %v5549 = load i32, ptr %slot1005, align 8
  %cv5550 = zext i32 %v5549 to i64
  %cond5551 = icmp ne i64 %cv5550, 0
  br i1 %cond5551, label %bb_rcsuccess1420, label %bb_rcfailure1420
bb_rcfailure1420:
  %v5552 = load i64, ptr %slot69, align 8
  %p5553 = inttoptr i64 %v5552 to ptr
  %call5554 = call i32 @myl_rc_take_failure(ptr %p5553) nomerge, !dbg !158
  store i32 %call5554, ptr %slot1006, align 8
  %v5555 = load i64, ptr %slot1, align 8
  %p5556 = inttoptr i64 %v5555 to ptr
  %v5557 = load i32, ptr %slot1006, align 8
  %call5558 = call i32 @myl_qbe_rc_status(ptr %p5556, i32 %v5557) nomerge, !dbg !158
  store i32 %call5558, ptr %slot1007, align 8
  br label %bb_failure
bb_rcsuccess1420:
  br label %bb_rcmoved1398
bb_rcmoved1398:
  %v5559 = load i64, ptr %slot16, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  store i32 0, ptr %p5560, align 4, !alias.scope !3, !noalias !4
  %v5561 = load i64, ptr %slot30, align 8
  %p5562 = inttoptr i64 %v5561 to ptr
  store i32 2, ptr %p5562, align 4, !alias.scope !3, !noalias !4
  %v5563 = load i64, ptr %slot29, align 8
  %p5564 = inttoptr i64 %v5563 to ptr
  store i32 1, ptr %p5564, align 4, !alias.scope !3, !noalias !4
  %v5565 = load i64, ptr %slot43, align 8
  %p5566 = inttoptr i64 %v5565 to ptr
  %ld5567 = load i64, ptr %p5566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5567, ptr %slot1008, align 8
  %v5568 = load i64, ptr %slot69, align 8
  store i64 %v5568, ptr %slot1009, align 8
  %v5569 = load i64, ptr %slot1009, align 8
  %v5570 = load i64, ptr %slot1008, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v5569, i64 %v5570) nomerge, !dbg !158
  %v5571 = load i64, ptr %slot41, align 8
  store i64 %v5571, ptr %slot1010, align 8
  %v5572 = load i64, ptr %slot1010, align 8
  %v5573 = load i64, ptr %slot1008, align 8
  %p5574 = inttoptr i64 %v5572 to ptr
  %p5575 = inttoptr i64 %v5573 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5575, ptr %p5574, i64 40, i1 false), !alias.scope !10000000
  %v5576 = load i64, ptr %slot29, align 8
  %p5577 = inttoptr i64 %v5576 to ptr
  store i32 0, ptr %p5577, align 4, !alias.scope !3, !noalias !4
  %v5578 = load i64, ptr %slot48, align 8
  %v5579 = load i64, ptr %slot50, align 8
  %p5580 = inttoptr i64 %v5579 to ptr
  store i64 %v5578, ptr %p5580, align 8, !alias.scope !3, !noalias !4
  %v5581 = load i64, ptr %slot50, align 8
  %p5582 = inttoptr i64 %v5581 to ptr
  %ld5583 = load i64, ptr %p5582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5583, ptr %slot1011, align 8
  %v5584 = load i64, ptr %slot1011, align 8
  %op5585 = add i64 %v5584, 368
  store i64 %op5585, ptr %slot1012, align 8
  %v5586 = load i64, ptr %slot1012, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %ld5588 = load i8, ptr %p5587, align 1, !alias.scope !3, !noalias !4
  %ext5589 = zext i8 %ld5588 to i64
  store i64 %ext5589, ptr %slot1013, align 8
  %v5590 = load i64, ptr %slot1013, align 8
  %v5591 = load i64, ptr %slot50, align 8
  %p5592 = inttoptr i64 %v5591 to ptr
  store i64 %v5590, ptr %p5592, align 8, !alias.scope !3, !noalias !4
  %v5593 = load i64, ptr %slot16, align 8
  %p5594 = inttoptr i64 %v5593 to ptr
  %ld5595 = load i32, ptr %p5594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5595, ptr %slot1014, align 8
  %v5596 = load i32, ptr %slot1014, align 8
  %cv5597 = zext i32 %v5596 to i64
  %cond5598 = icmp ne i64 %cv5597, 0
  br i1 %cond5598, label %bb_rcslotdrop1435, label %bb_rcslotdone1435
bb_rcslotdrop1435:
  %v5599 = load i64, ptr %slot16, align 8
  %p5600 = inttoptr i64 %v5599 to ptr
  store i32 0, ptr %p5600, align 4, !alias.scope !3, !noalias !4
  %v5601 = load i64, ptr %slot32, align 8
  store i64 %v5601, ptr %slot1015, align 8
  %v5602 = load i64, ptr %slot17, align 8
  %p5603 = inttoptr i64 %v5602 to ptr
  %ld5604 = load i32, ptr %p5603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5604, ptr %slot1016, align 8
  %v5605 = load i32, ptr %slot1016, align 8
  %op5606 = and i32 %v5605, 28
  store i32 %op5606, ptr %slot1017, align 8
  %v5607 = load i32, ptr %slot1017, align 8
  %cv5608 = zext i32 %v5607 to i64
  %cond5609 = icmp ne i64 %cv5608, 0
  br i1 %cond5609, label %bb_rcslotrole1435, label %bb_rcslotowner1435
bb_rcslotrole1435:
  %v5610 = load i64, ptr %slot69, align 8
  store i64 %v5610, ptr %slot1018, align 8
  %v5611 = load i64, ptr %slot1018, align 8
  %v5612 = load i64, ptr %slot1015, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5611, i64 %v5612) nomerge, !dbg !160
  br label %bb_rcslotdone1435
bb_rcslotowner1435:
  %v5613 = load i64, ptr %slot69, align 8
  store i64 %v5613, ptr %slot1019, align 8
  %v5614 = load i64, ptr %slot1019, align 8
  %v5615 = load i64, ptr %slot1015, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5614, i64 %v5615) nomerge, !dbg !160
  br label %bb_rcslotdone1435
bb_rcslotdone1435:
  %v5616 = load i64, ptr %slot50, align 8
  %p5617 = inttoptr i64 %v5616 to ptr
  %ld5618 = load i64, ptr %p5617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5618, ptr %slot1020, align 8
  %v5619 = load i64, ptr %slot1020, align 8
  %cond5620 = icmp ne i64 %v5619, 0
  br i1 %cond5620, label %bb_next1443, label %bb_i62
bb_next1443:
  %v5621 = load i64, ptr %slot50, align 8
  %p5622 = inttoptr i64 %v5621 to ptr
  store i64 18446744073709551615, ptr %p5622, align 8, !alias.scope !3, !noalias !4
  %v5623 = load i64, ptr %slot50, align 8
  %p5624 = inttoptr i64 %v5623 to ptr
  %ld5625 = load i64, ptr %p5624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5625, ptr %slot1021, align 8
  %v5626 = load i64, ptr %slot16, align 8
  %p5627 = inttoptr i64 %v5626 to ptr
  %ld5628 = load i32, ptr %p5627, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5628, ptr %slot1022, align 8
  %v5629 = load i32, ptr %slot1022, align 8
  %cv5630 = zext i32 %v5629 to i64
  %cond5631 = icmp ne i64 %cv5630, 0
  br i1 %cond5631, label %bb_rcslotdrop1446, label %bb_rcslotdone1446
bb_rcslotdrop1446:
  %v5632 = load i64, ptr %slot16, align 8
  %p5633 = inttoptr i64 %v5632 to ptr
  store i32 0, ptr %p5633, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1446
bb_rcslotdone1446:
  %v5634 = load i64, ptr %slot14, align 8
  %p5635 = inttoptr i64 %v5634 to ptr
  %ld5636 = load i32, ptr %p5635, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5636, ptr %slot1023, align 8
  %v5637 = load i32, ptr %slot1023, align 8
  %cv5638 = zext i32 %v5637 to i64
  %cond5639 = icmp ne i64 %cv5638, 0
  br i1 %cond5639, label %bb_rcslotdrop1449, label %bb_rcslotdone1449
bb_rcslotdrop1449:
  %v5640 = load i64, ptr %slot14, align 8
  %p5641 = inttoptr i64 %v5640 to ptr
  store i32 0, ptr %p5641, align 4, !alias.scope !3, !noalias !4
  %v5642 = load i64, ptr %slot49, align 8
  store i64 %v5642, ptr %slot1024, align 8
  %v5643 = load i64, ptr %slot15, align 8
  %p5644 = inttoptr i64 %v5643 to ptr
  %ld5645 = load i32, ptr %p5644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5645, ptr %slot1025, align 8
  %v5646 = load i32, ptr %slot1025, align 8
  %op5647 = and i32 %v5646, 28
  store i32 %op5647, ptr %slot1026, align 8
  %v5648 = load i32, ptr %slot1026, align 8
  %cv5649 = zext i32 %v5648 to i64
  %cond5650 = icmp ne i64 %cv5649, 0
  br i1 %cond5650, label %bb_rcslotrole1449, label %bb_rcslotowner1449
bb_rcslotrole1449:
  %v5651 = load i64, ptr %slot69, align 8
  store i64 %v5651, ptr %slot1027, align 8
  %v5652 = load i64, ptr %slot1027, align 8
  %v5653 = load i64, ptr %slot1024, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5652, i64 %v5653) nomerge, !dbg !162
  br label %bb_rcslotdone1449
bb_rcslotowner1449:
  %v5654 = load i64, ptr %slot69, align 8
  store i64 %v5654, ptr %slot1028, align 8
  %v5655 = load i64, ptr %slot1028, align 8
  %v5656 = load i64, ptr %slot1024, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5655, i64 %v5656) nomerge, !dbg !162
  br label %bb_rcslotdone1449
bb_rcslotdone1449:
  %v5657 = load i64, ptr %slot12, align 8
  %p5658 = inttoptr i64 %v5657 to ptr
  %ld5659 = load i32, ptr %p5658, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5659, ptr %slot1029, align 8
  %v5660 = load i32, ptr %slot1029, align 8
  %cv5661 = zext i32 %v5660 to i64
  %cond5662 = icmp ne i64 %cv5661, 0
  br i1 %cond5662, label %bb_rcslotdrop1458, label %bb_rcslotdone1458
bb_rcslotdrop1458:
  %v5663 = load i64, ptr %slot12, align 8
  %p5664 = inttoptr i64 %v5663 to ptr
  store i32 0, ptr %p5664, align 4, !alias.scope !3, !noalias !4
  %v5665 = load i64, ptr %slot48, align 8
  store i64 %v5665, ptr %slot1030, align 8
  %v5666 = load i64, ptr %slot13, align 8
  %p5667 = inttoptr i64 %v5666 to ptr
  %ld5668 = load i32, ptr %p5667, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5668, ptr %slot1031, align 8
  %v5669 = load i32, ptr %slot1031, align 8
  %op5670 = and i32 %v5669, 28
  store i32 %op5670, ptr %slot1032, align 8
  %v5671 = load i32, ptr %slot1032, align 8
  %cv5672 = zext i32 %v5671 to i64
  %cond5673 = icmp ne i64 %cv5672, 0
  br i1 %cond5673, label %bb_rcslotrole1458, label %bb_rcslotowner1458
bb_rcslotrole1458:
  %v5674 = load i64, ptr %slot69, align 8
  store i64 %v5674, ptr %slot1033, align 8
  %v5675 = load i64, ptr %slot1033, align 8
  %v5676 = load i64, ptr %slot1030, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5675, i64 %v5676) nomerge, !dbg !162
  br label %bb_rcslotdone1458
bb_rcslotowner1458:
  %v5677 = load i64, ptr %slot69, align 8
  store i64 %v5677, ptr %slot1034, align 8
  %v5678 = load i64, ptr %slot1034, align 8
  %v5679 = load i64, ptr %slot1030, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5678, i64 %v5679) nomerge, !dbg !162
  br label %bb_rcslotdone1458
bb_rcslotdone1458:
  %v5680 = load i64, ptr %slot10, align 8
  %p5681 = inttoptr i64 %v5680 to ptr
  %ld5682 = load i32, ptr %p5681, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5682, ptr %slot1035, align 8
  %v5683 = load i32, ptr %slot1035, align 8
  %cv5684 = zext i32 %v5683 to i64
  %cond5685 = icmp ne i64 %cv5684, 0
  br i1 %cond5685, label %bb_rcslotdrop1467, label %bb_rcslotdone1467
bb_rcslotdrop1467:
  %v5686 = load i64, ptr %slot10, align 8
  %p5687 = inttoptr i64 %v5686 to ptr
  store i32 0, ptr %p5687, align 4, !alias.scope !3, !noalias !4
  %v5688 = load i64, ptr %slot47, align 8
  store i64 %v5688, ptr %slot1036, align 8
  %v5689 = load i64, ptr %slot11, align 8
  %p5690 = inttoptr i64 %v5689 to ptr
  %ld5691 = load i32, ptr %p5690, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5691, ptr %slot1037, align 8
  %v5692 = load i32, ptr %slot1037, align 8
  %op5693 = and i32 %v5692, 28
  store i32 %op5693, ptr %slot1038, align 8
  %v5694 = load i32, ptr %slot1038, align 8
  %cv5695 = zext i32 %v5694 to i64
  %cond5696 = icmp ne i64 %cv5695, 0
  br i1 %cond5696, label %bb_rcslotrole1467, label %bb_rcslotowner1467
bb_rcslotrole1467:
  %v5697 = load i64, ptr %slot69, align 8
  store i64 %v5697, ptr %slot1039, align 8
  %v5698 = load i64, ptr %slot1036, align 8
  %p5699 = inttoptr i64 %v5698 to ptr
  %ld5700 = load i64, ptr %p5699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5700, ptr %slot1040, align 8
  %v5701 = load i64, ptr %slot1040, align 8
  %cmp5702 = icmp ne i64 %v5701, 0
  %cv5703 = zext i1 %cmp5702 to i32
  store i32 %cv5703, ptr %slot1041, align 8
  %v5704 = load i32, ptr %slot1041, align 8
  %cv5705 = zext i32 %v5704 to i64
  %cond5706 = icmp ne i64 %cv5705, 0
  br i1 %cond5706, label %bb_rcgnn1483, label %bb_rcgdone1483
bb_rcgnn1483:
  %v5707 = load i64, ptr %slot1040, align 8
  %op5708 = sub i64 %v5707, 16
  store i64 %op5708, ptr %slot1042, align 8
  %v5709 = load i64, ptr %slot1040, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  %rgep5711 = getelementptr i8, ptr %p5710, i64 -16
  %ld5712 = load i64, ptr %rgep5711, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5712, ptr %slot1043, align 8
  %v5713 = load i64, ptr %slot1043, align 8
  %op5714 = and i64 %v5713, 4611686018427387906
  store i64 %op5714, ptr %slot1044, align 8
  %v5715 = load i64, ptr %slot1044, align 8
  %cmp5716 = icmp ne i64 %v5715, 0
  %cv5717 = zext i1 %cmp5716 to i32
  store i32 %cv5717, ptr %slot1045, align 8
  %v5718 = load i32, ptr %slot1045, align 8
  %cv5719 = zext i32 %v5718 to i64
  %cond5720 = icmp ne i64 %cv5719, 0
  br i1 %cond5720, label %bb_rcgclear1483, label %bb_rcgcounted1483
bb_rcgcounted1483:
  %v5721 = load i64, ptr %slot1040, align 8
  %op5722 = sub i64 %v5721, 24
  store i64 %op5722, ptr %slot1046, align 8
  %v5723 = load i64, ptr %slot1040, align 8
  %p5724 = inttoptr i64 %v5723 to ptr
  %rgep5725 = getelementptr i8, ptr %p5724, i64 -24
  %ld5726 = load i64, ptr %rgep5725, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5726, ptr %slot1047, align 8
  %v5727 = load i64, ptr %slot1047, align 8
  %op5728 = sub i64 %v5727, 1
  store i64 %op5728, ptr %slot1048, align 8
  %v5729 = load i64, ptr %slot1048, align 8
  %cmp5730 = icmp eq i64 %v5729, 0
  %cv5731 = zext i1 %cmp5730 to i32
  store i32 %cv5731, ptr %slot1049, align 8
  %v5732 = load i32, ptr %slot1049, align 8
  %cv5733 = zext i32 %v5732 to i64
  %cond5734 = icmp ne i64 %cv5733, 0
  br i1 %cond5734, label %bb_rcglast1483, label %bb_rcgdec1483
bb_rcglast1483:
  %v5735 = load i64, ptr %slot1040, align 8
  %op5736 = sub i64 %v5735, 32
  store i64 %op5736, ptr %slot1050, align 8
  %v5737 = load i64, ptr %slot1040, align 8
  %p5738 = inttoptr i64 %v5737 to ptr
  %rgep5739 = getelementptr i8, ptr %p5738, i64 -32
  %ld5740 = load i64, ptr %rgep5739, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5740, ptr %slot1051, align 8
  %v5741 = load i64, ptr %slot1051, align 8
  %cmp5742 = icmp ne i64 %v5741, 0
  %cv5743 = zext i1 %cmp5742 to i32
  store i32 %cv5743, ptr %slot1052, align 8
  %v5744 = load i32, ptr %slot1052, align 8
  %cv5745 = zext i32 %v5744 to i64
  %cond5746 = icmp ne i64 %cv5745, 0
  br i1 %cond5746, label %bb_rcgdec1483, label %bb_rcgslow1483
bb_rcgslow1483:
  %v5747 = load i64, ptr %slot1039, align 8
  %v5748 = load i64, ptr %slot1036, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_unloan(i64 %v5747, i64 %v5748) nomerge, !dbg !162
  br label %bb_rcgdone1483
bb_rcgdec1483:
  %v5749 = load i64, ptr %slot1048, align 8
  %v5750 = load i64, ptr %slot1040, align 8
  %p5751 = inttoptr i64 %v5750 to ptr
  %rgep5752 = getelementptr i8, ptr %p5751, i64 -24
  store i64 %v5749, ptr %rgep5752, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1483
bb_rcgclear1483:
  %v5753 = load i64, ptr %slot1036, align 8
  %p5754 = inttoptr i64 %v5753 to ptr
  store i64 0, ptr %p5754, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1483
bb_rcgdone1483:
  br label %bb_rcslotdone1467
bb_rcslotowner1467:
  %v5755 = load i64, ptr %slot69, align 8
  store i64 %v5755, ptr %slot1053, align 8
  %v5756 = load i64, ptr %slot1036, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  %ld5758 = load i64, ptr %p5757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5758, ptr %slot1054, align 8
  %v5759 = load i64, ptr %slot1054, align 8
  %cmp5760 = icmp ne i64 %v5759, 0
  %cv5761 = zext i1 %cmp5760 to i32
  store i32 %cv5761, ptr %slot1055, align 8
  %v5762 = load i32, ptr %slot1055, align 8
  %cv5763 = zext i32 %v5762 to i64
  %cond5764 = icmp ne i64 %cv5763, 0
  br i1 %cond5764, label %bb_rcgnn1498, label %bb_rcgdone1498
bb_rcgnn1498:
  %v5765 = load i64, ptr %slot1054, align 8
  %op5766 = sub i64 %v5765, 16
  store i64 %op5766, ptr %slot1056, align 8
  %v5767 = load i64, ptr %slot1054, align 8
  %p5768 = inttoptr i64 %v5767 to ptr
  %rgep5769 = getelementptr i8, ptr %p5768, i64 -16
  %ld5770 = load i64, ptr %rgep5769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5770, ptr %slot1057, align 8
  %v5771 = load i64, ptr %slot1057, align 8
  %op5772 = and i64 %v5771, 4611686018427387906
  store i64 %op5772, ptr %slot1058, align 8
  %v5773 = load i64, ptr %slot1058, align 8
  %cmp5774 = icmp ne i64 %v5773, 0
  %cv5775 = zext i1 %cmp5774 to i32
  store i32 %cv5775, ptr %slot1059, align 8
  %v5776 = load i32, ptr %slot1059, align 8
  %cv5777 = zext i32 %v5776 to i64
  %cond5778 = icmp ne i64 %cv5777, 0
  br i1 %cond5778, label %bb_rcgclear1498, label %bb_rcgcounted1498
bb_rcgcounted1498:
  %v5779 = load i64, ptr %slot1054, align 8
  %op5780 = sub i64 %v5779, 32
  store i64 %op5780, ptr %slot1060, align 8
  %v5781 = load i64, ptr %slot1054, align 8
  %p5782 = inttoptr i64 %v5781 to ptr
  %rgep5783 = getelementptr i8, ptr %p5782, i64 -32
  %ld5784 = load i64, ptr %rgep5783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5784, ptr %slot1061, align 8
  %v5785 = load i64, ptr %slot1061, align 8
  %op5786 = sub i64 %v5785, 1
  store i64 %op5786, ptr %slot1062, align 8
  %v5787 = load i64, ptr %slot1062, align 8
  %cmp5788 = icmp eq i64 %v5787, 0
  %cv5789 = zext i1 %cmp5788 to i32
  store i32 %cv5789, ptr %slot1063, align 8
  %v5790 = load i32, ptr %slot1063, align 8
  %cv5791 = zext i32 %v5790 to i64
  %cond5792 = icmp ne i64 %cv5791, 0
  br i1 %cond5792, label %bb_rcglast1498, label %bb_rcgdec1498
bb_rcglast1498:
  %v5793 = load i64, ptr %slot1054, align 8
  %op5794 = sub i64 %v5793, 24
  store i64 %op5794, ptr %slot1064, align 8
  %v5795 = load i64, ptr %slot1054, align 8
  %p5796 = inttoptr i64 %v5795 to ptr
  %rgep5797 = getelementptr i8, ptr %p5796, i64 -24
  %ld5798 = load i64, ptr %rgep5797, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5798, ptr %slot1065, align 8
  %v5799 = load i64, ptr %slot1065, align 8
  %cmp5800 = icmp ne i64 %v5799, 0
  %cv5801 = zext i1 %cmp5800 to i32
  store i32 %cv5801, ptr %slot1066, align 8
  %v5802 = load i32, ptr %slot1066, align 8
  %cv5803 = zext i32 %v5802 to i64
  %cond5804 = icmp ne i64 %cv5803, 0
  br i1 %cond5804, label %bb_rcgdec1498, label %bb_rcgslow1498
bb_rcgslow1498:
  %v5805 = load i64, ptr %slot1053, align 8
  %v5806 = load i64, ptr %slot1036, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_drop(i64 %v5805, i64 %v5806) nomerge, !dbg !162
  br label %bb_rcgdone1498
bb_rcgdec1498:
  %v5807 = load i64, ptr %slot1062, align 8
  %v5808 = load i64, ptr %slot1054, align 8
  %p5809 = inttoptr i64 %v5808 to ptr
  %rgep5810 = getelementptr i8, ptr %p5809, i64 -32
  store i64 %v5807, ptr %rgep5810, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1498
bb_rcgclear1498:
  %v5811 = load i64, ptr %slot1036, align 8
  %p5812 = inttoptr i64 %v5811 to ptr
  store i64 0, ptr %p5812, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1498
bb_rcgdone1498:
  br label %bb_rcslotdone1467
bb_rcslotdone1467:
  %v5813 = load i64, ptr %slot8, align 8
  %p5814 = inttoptr i64 %v5813 to ptr
  %ld5815 = load i32, ptr %p5814, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5815, ptr %slot1067, align 8
  %v5816 = load i32, ptr %slot1067, align 8
  %cv5817 = zext i32 %v5816 to i64
  %cond5818 = icmp ne i64 %cv5817, 0
  br i1 %cond5818, label %bb_rcslotdrop1504, label %bb_rcslotdone1504
bb_rcslotdrop1504:
  %v5819 = load i64, ptr %slot8, align 8
  %p5820 = inttoptr i64 %v5819 to ptr
  store i32 0, ptr %p5820, align 4, !alias.scope !3, !noalias !4
  %v5821 = load i64, ptr %slot46, align 8
  store i64 %v5821, ptr %slot1068, align 8
  %v5822 = load i64, ptr %slot9, align 8
  %p5823 = inttoptr i64 %v5822 to ptr
  %ld5824 = load i32, ptr %p5823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5824, ptr %slot1069, align 8
  %v5825 = load i32, ptr %slot1069, align 8
  %op5826 = and i32 %v5825, 28
  store i32 %op5826, ptr %slot1070, align 8
  %v5827 = load i32, ptr %slot1070, align 8
  %cv5828 = zext i32 %v5827 to i64
  %cond5829 = icmp ne i64 %cv5828, 0
  br i1 %cond5829, label %bb_rcslotrole1504, label %bb_rcslotowner1504
bb_rcslotrole1504:
  %v5830 = load i64, ptr %slot69, align 8
  store i64 %v5830, ptr %slot1071, align 8
  %v5831 = load i64, ptr %slot1068, align 8
  %p5832 = inttoptr i64 %v5831 to ptr
  %ld5833 = load i64, ptr %p5832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5833, ptr %slot1072, align 8
  %v5834 = load i64, ptr %slot1072, align 8
  %cmp5835 = icmp ne i64 %v5834, 0
  %cv5836 = zext i1 %cmp5835 to i32
  store i32 %cv5836, ptr %slot1073, align 8
  %v5837 = load i32, ptr %slot1073, align 8
  %cv5838 = zext i32 %v5837 to i64
  %cond5839 = icmp ne i64 %cv5838, 0
  br i1 %cond5839, label %bb_rcgnn1520, label %bb_rcgdone1520
bb_rcgnn1520:
  %v5840 = load i64, ptr %slot1072, align 8
  %op5841 = sub i64 %v5840, 16
  store i64 %op5841, ptr %slot1074, align 8
  %v5842 = load i64, ptr %slot1072, align 8
  %p5843 = inttoptr i64 %v5842 to ptr
  %rgep5844 = getelementptr i8, ptr %p5843, i64 -16
  %ld5845 = load i64, ptr %rgep5844, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5845, ptr %slot1075, align 8
  %v5846 = load i64, ptr %slot1075, align 8
  %op5847 = and i64 %v5846, 4611686018427387906
  store i64 %op5847, ptr %slot1076, align 8
  %v5848 = load i64, ptr %slot1076, align 8
  %cmp5849 = icmp ne i64 %v5848, 0
  %cv5850 = zext i1 %cmp5849 to i32
  store i32 %cv5850, ptr %slot1077, align 8
  %v5851 = load i32, ptr %slot1077, align 8
  %cv5852 = zext i32 %v5851 to i64
  %cond5853 = icmp ne i64 %cv5852, 0
  br i1 %cond5853, label %bb_rcgclear1520, label %bb_rcgcounted1520
bb_rcgcounted1520:
  %v5854 = load i64, ptr %slot1072, align 8
  %op5855 = sub i64 %v5854, 24
  store i64 %op5855, ptr %slot1078, align 8
  %v5856 = load i64, ptr %slot1072, align 8
  %p5857 = inttoptr i64 %v5856 to ptr
  %rgep5858 = getelementptr i8, ptr %p5857, i64 -24
  %ld5859 = load i64, ptr %rgep5858, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5859, ptr %slot1079, align 8
  %v5860 = load i64, ptr %slot1079, align 8
  %op5861 = sub i64 %v5860, 1
  store i64 %op5861, ptr %slot1080, align 8
  %v5862 = load i64, ptr %slot1080, align 8
  %cmp5863 = icmp eq i64 %v5862, 0
  %cv5864 = zext i1 %cmp5863 to i32
  store i32 %cv5864, ptr %slot1081, align 8
  %v5865 = load i32, ptr %slot1081, align 8
  %cv5866 = zext i32 %v5865 to i64
  %cond5867 = icmp ne i64 %cv5866, 0
  br i1 %cond5867, label %bb_rcglast1520, label %bb_rcgdec1520
bb_rcglast1520:
  %v5868 = load i64, ptr %slot1072, align 8
  %op5869 = sub i64 %v5868, 32
  store i64 %op5869, ptr %slot1082, align 8
  %v5870 = load i64, ptr %slot1072, align 8
  %p5871 = inttoptr i64 %v5870 to ptr
  %rgep5872 = getelementptr i8, ptr %p5871, i64 -32
  %ld5873 = load i64, ptr %rgep5872, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5873, ptr %slot1083, align 8
  %v5874 = load i64, ptr %slot1083, align 8
  %cmp5875 = icmp ne i64 %v5874, 0
  %cv5876 = zext i1 %cmp5875 to i32
  store i32 %cv5876, ptr %slot1084, align 8
  %v5877 = load i32, ptr %slot1084, align 8
  %cv5878 = zext i32 %v5877 to i64
  %cond5879 = icmp ne i64 %cv5878, 0
  br i1 %cond5879, label %bb_rcgdec1520, label %bb_rcgslow1520
bb_rcgslow1520:
  %v5880 = load i64, ptr %slot1071, align 8
  %v5881 = load i64, ptr %slot1068, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v5880, i64 %v5881) nomerge, !dbg !162
  br label %bb_rcgdone1520
bb_rcgdec1520:
  %v5882 = load i64, ptr %slot1080, align 8
  %v5883 = load i64, ptr %slot1072, align 8
  %p5884 = inttoptr i64 %v5883 to ptr
  %rgep5885 = getelementptr i8, ptr %p5884, i64 -24
  store i64 %v5882, ptr %rgep5885, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1520
bb_rcgclear1520:
  %v5886 = load i64, ptr %slot1068, align 8
  %p5887 = inttoptr i64 %v5886 to ptr
  store i64 0, ptr %p5887, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1520
bb_rcgdone1520:
  br label %bb_rcslotdone1504
bb_rcslotowner1504:
  %v5888 = load i64, ptr %slot69, align 8
  store i64 %v5888, ptr %slot1085, align 8
  %v5889 = load i64, ptr %slot1068, align 8
  %p5890 = inttoptr i64 %v5889 to ptr
  %ld5891 = load i64, ptr %p5890, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5891, ptr %slot1086, align 8
  %v5892 = load i64, ptr %slot1086, align 8
  %cmp5893 = icmp ne i64 %v5892, 0
  %cv5894 = zext i1 %cmp5893 to i32
  store i32 %cv5894, ptr %slot1087, align 8
  %v5895 = load i32, ptr %slot1087, align 8
  %cv5896 = zext i32 %v5895 to i64
  %cond5897 = icmp ne i64 %cv5896, 0
  br i1 %cond5897, label %bb_rcgnn1535, label %bb_rcgdone1535
bb_rcgnn1535:
  %v5898 = load i64, ptr %slot1086, align 8
  %op5899 = sub i64 %v5898, 16
  store i64 %op5899, ptr %slot1088, align 8
  %v5900 = load i64, ptr %slot1086, align 8
  %p5901 = inttoptr i64 %v5900 to ptr
  %rgep5902 = getelementptr i8, ptr %p5901, i64 -16
  %ld5903 = load i64, ptr %rgep5902, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5903, ptr %slot1089, align 8
  %v5904 = load i64, ptr %slot1089, align 8
  %op5905 = and i64 %v5904, 4611686018427387906
  store i64 %op5905, ptr %slot1090, align 8
  %v5906 = load i64, ptr %slot1090, align 8
  %cmp5907 = icmp ne i64 %v5906, 0
  %cv5908 = zext i1 %cmp5907 to i32
  store i32 %cv5908, ptr %slot1091, align 8
  %v5909 = load i32, ptr %slot1091, align 8
  %cv5910 = zext i32 %v5909 to i64
  %cond5911 = icmp ne i64 %cv5910, 0
  br i1 %cond5911, label %bb_rcgclear1535, label %bb_rcgcounted1535
bb_rcgcounted1535:
  %v5912 = load i64, ptr %slot1086, align 8
  %op5913 = sub i64 %v5912, 32
  store i64 %op5913, ptr %slot1092, align 8
  %v5914 = load i64, ptr %slot1086, align 8
  %p5915 = inttoptr i64 %v5914 to ptr
  %rgep5916 = getelementptr i8, ptr %p5915, i64 -32
  %ld5917 = load i64, ptr %rgep5916, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5917, ptr %slot1093, align 8
  %v5918 = load i64, ptr %slot1093, align 8
  %op5919 = sub i64 %v5918, 1
  store i64 %op5919, ptr %slot1094, align 8
  %v5920 = load i64, ptr %slot1094, align 8
  %cmp5921 = icmp eq i64 %v5920, 0
  %cv5922 = zext i1 %cmp5921 to i32
  store i32 %cv5922, ptr %slot1095, align 8
  %v5923 = load i32, ptr %slot1095, align 8
  %cv5924 = zext i32 %v5923 to i64
  %cond5925 = icmp ne i64 %cv5924, 0
  br i1 %cond5925, label %bb_rcglast1535, label %bb_rcgdec1535
bb_rcglast1535:
  %v5926 = load i64, ptr %slot1086, align 8
  %op5927 = sub i64 %v5926, 24
  store i64 %op5927, ptr %slot1096, align 8
  %v5928 = load i64, ptr %slot1086, align 8
  %p5929 = inttoptr i64 %v5928 to ptr
  %rgep5930 = getelementptr i8, ptr %p5929, i64 -24
  %ld5931 = load i64, ptr %rgep5930, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5931, ptr %slot1097, align 8
  %v5932 = load i64, ptr %slot1097, align 8
  %cmp5933 = icmp ne i64 %v5932, 0
  %cv5934 = zext i1 %cmp5933 to i32
  store i32 %cv5934, ptr %slot1098, align 8
  %v5935 = load i32, ptr %slot1098, align 8
  %cv5936 = zext i32 %v5935 to i64
  %cond5937 = icmp ne i64 %cv5936, 0
  br i1 %cond5937, label %bb_rcgdec1535, label %bb_rcgslow1535
bb_rcgslow1535:
  %v5938 = load i64, ptr %slot1085, align 8
  %v5939 = load i64, ptr %slot1068, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v5938, i64 %v5939) nomerge, !dbg !162
  br label %bb_rcgdone1535
bb_rcgdec1535:
  %v5940 = load i64, ptr %slot1094, align 8
  %v5941 = load i64, ptr %slot1086, align 8
  %p5942 = inttoptr i64 %v5941 to ptr
  %rgep5943 = getelementptr i8, ptr %p5942, i64 -32
  store i64 %v5940, ptr %rgep5943, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1535
bb_rcgclear1535:
  %v5944 = load i64, ptr %slot1068, align 8
  %p5945 = inttoptr i64 %v5944 to ptr
  store i64 0, ptr %p5945, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1535
bb_rcgdone1535:
  br label %bb_rcslotdone1504
bb_rcslotdone1504:
  %v5946 = load i64, ptr %slot6, align 8
  %p5947 = inttoptr i64 %v5946 to ptr
  %ld5948 = load i32, ptr %p5947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5948, ptr %slot1099, align 8
  %v5949 = load i32, ptr %slot1099, align 8
  %cv5950 = zext i32 %v5949 to i64
  %cond5951 = icmp ne i64 %cv5950, 0
  br i1 %cond5951, label %bb_rcslotdrop1541, label %bb_rcslotdone1541
bb_rcslotdrop1541:
  %v5952 = load i64, ptr %slot6, align 8
  %p5953 = inttoptr i64 %v5952 to ptr
  store i32 0, ptr %p5953, align 4, !alias.scope !3, !noalias !4
  %v5954 = load i64, ptr %slot45, align 8
  store i64 %v5954, ptr %slot1100, align 8
  %v5955 = load i64, ptr %slot7, align 8
  %p5956 = inttoptr i64 %v5955 to ptr
  %ld5957 = load i32, ptr %p5956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5957, ptr %slot1101, align 8
  %v5958 = load i32, ptr %slot1101, align 8
  %op5959 = and i32 %v5958, 28
  store i32 %op5959, ptr %slot1102, align 8
  %v5960 = load i32, ptr %slot1102, align 8
  %cv5961 = zext i32 %v5960 to i64
  %cond5962 = icmp ne i64 %cv5961, 0
  br i1 %cond5962, label %bb_rcslotrole1541, label %bb_rcslotowner1541
bb_rcslotrole1541:
  %v5963 = load i64, ptr %slot69, align 8
  store i64 %v5963, ptr %slot1103, align 8
  %v5964 = load i64, ptr %slot1103, align 8
  %v5965 = load i64, ptr %slot1100, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v5964, i64 %v5965) nomerge, !dbg !162
  br label %bb_rcslotdone1541
bb_rcslotowner1541:
  %v5966 = load i64, ptr %slot69, align 8
  store i64 %v5966, ptr %slot1104, align 8
  %v5967 = load i64, ptr %slot1104, align 8
  %v5968 = load i64, ptr %slot1100, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v5967, i64 %v5968) nomerge, !dbg !162
  br label %bb_rcslotdone1541
bb_rcslotdone1541:
  %v5969 = load i64, ptr %slot1021, align 8
  ret i64 %v5969
bb_i62:
  %v5970 = load i64, ptr %slot49, align 8
  %v5971 = load i64, ptr %slot50, align 8
  %p5972 = inttoptr i64 %v5971 to ptr
  store i64 %v5970, ptr %p5972, align 8, !alias.scope !3, !noalias !4
  %v5973 = load i64, ptr %slot50, align 8
  %p5974 = inttoptr i64 %v5973 to ptr
  %ld5975 = load i64, ptr %p5974, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5975, ptr %slot1105, align 8
  %v5976 = load i64, ptr %slot1105, align 8
  %op5977 = add i64 %v5976, 48
  store i64 %op5977, ptr %slot1106, align 8
  %v5978 = load i64, ptr %slot1106, align 8
  %p5979 = inttoptr i64 %v5978 to ptr
  %ld5980 = load i64, ptr %p5979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5980, ptr %slot1107, align 8
  %v5981 = load i64, ptr %slot1107, align 8
  %v5982 = load i64, ptr %slot50, align 8
  %p5983 = inttoptr i64 %v5982 to ptr
  store i64 %v5981, ptr %p5983, align 8, !alias.scope !3, !noalias !4
  %v5984 = load i64, ptr %slot16, align 8
  %p5985 = inttoptr i64 %v5984 to ptr
  %ld5986 = load i32, ptr %p5985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5986, ptr %slot1108, align 8
  %v5987 = load i32, ptr %slot1108, align 8
  %cv5988 = zext i32 %v5987 to i64
  %cond5989 = icmp ne i64 %cv5988, 0
  br i1 %cond5989, label %bb_rcslotdrop1608, label %bb_rcslotdone1608
bb_rcslotdrop1608:
  %v5990 = load i64, ptr %slot16, align 8
  %p5991 = inttoptr i64 %v5990 to ptr
  store i32 0, ptr %p5991, align 4, !alias.scope !3, !noalias !4
  %v5992 = load i64, ptr %slot32, align 8
  store i64 %v5992, ptr %slot1109, align 8
  %v5993 = load i64, ptr %slot17, align 8
  %p5994 = inttoptr i64 %v5993 to ptr
  %ld5995 = load i32, ptr %p5994, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5995, ptr %slot1110, align 8
  %v5996 = load i32, ptr %slot1110, align 8
  %op5997 = and i32 %v5996, 28
  store i32 %op5997, ptr %slot1111, align 8
  %v5998 = load i32, ptr %slot1111, align 8
  %cv5999 = zext i32 %v5998 to i64
  %cond6000 = icmp ne i64 %cv5999, 0
  br i1 %cond6000, label %bb_rcslotrole1608, label %bb_rcslotowner1608
bb_rcslotrole1608:
  %v6001 = load i64, ptr %slot69, align 8
  store i64 %v6001, ptr %slot1112, align 8
  %v6002 = load i64, ptr %slot1112, align 8
  %v6003 = load i64, ptr %slot1109, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6002, i64 %v6003) nomerge, !dbg !164
  br label %bb_rcslotdone1608
bb_rcslotowner1608:
  %v6004 = load i64, ptr %slot69, align 8
  store i64 %v6004, ptr %slot1113, align 8
  %v6005 = load i64, ptr %slot1113, align 8
  %v6006 = load i64, ptr %slot1109, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6005, i64 %v6006) nomerge, !dbg !164
  br label %bb_rcslotdone1608
bb_rcslotdone1608:
  %v6007 = load i64, ptr %slot50, align 8
  %p6008 = inttoptr i64 %v6007 to ptr
  %ld6009 = load i64, ptr %p6008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6009, ptr %slot1114, align 8
  %v6010 = load i64, ptr %slot16, align 8
  %p6011 = inttoptr i64 %v6010 to ptr
  %ld6012 = load i32, ptr %p6011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6012, ptr %slot1115, align 8
  %v6013 = load i32, ptr %slot1115, align 8
  %cv6014 = zext i32 %v6013 to i64
  %cond6015 = icmp ne i64 %cv6014, 0
  br i1 %cond6015, label %bb_rcslotdrop1618, label %bb_rcslotdone1618
bb_rcslotdrop1618:
  %v6016 = load i64, ptr %slot16, align 8
  %p6017 = inttoptr i64 %v6016 to ptr
  store i32 0, ptr %p6017, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1618
bb_rcslotdone1618:
  %v6018 = load i64, ptr %slot14, align 8
  %p6019 = inttoptr i64 %v6018 to ptr
  %ld6020 = load i32, ptr %p6019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6020, ptr %slot1116, align 8
  %v6021 = load i32, ptr %slot1116, align 8
  %cv6022 = zext i32 %v6021 to i64
  %cond6023 = icmp ne i64 %cv6022, 0
  br i1 %cond6023, label %bb_rcslotdrop1621, label %bb_rcslotdone1621
bb_rcslotdrop1621:
  %v6024 = load i64, ptr %slot14, align 8
  %p6025 = inttoptr i64 %v6024 to ptr
  store i32 0, ptr %p6025, align 4, !alias.scope !3, !noalias !4
  %v6026 = load i64, ptr %slot49, align 8
  store i64 %v6026, ptr %slot1117, align 8
  %v6027 = load i64, ptr %slot15, align 8
  %p6028 = inttoptr i64 %v6027 to ptr
  %ld6029 = load i32, ptr %p6028, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6029, ptr %slot1118, align 8
  %v6030 = load i32, ptr %slot1118, align 8
  %op6031 = and i32 %v6030, 28
  store i32 %op6031, ptr %slot1119, align 8
  %v6032 = load i32, ptr %slot1119, align 8
  %cv6033 = zext i32 %v6032 to i64
  %cond6034 = icmp ne i64 %cv6033, 0
  br i1 %cond6034, label %bb_rcslotrole1621, label %bb_rcslotowner1621
bb_rcslotrole1621:
  %v6035 = load i64, ptr %slot69, align 8
  store i64 %v6035, ptr %slot1120, align 8
  %v6036 = load i64, ptr %slot1120, align 8
  %v6037 = load i64, ptr %slot1117, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6036, i64 %v6037) nomerge, !dbg !166
  br label %bb_rcslotdone1621
bb_rcslotowner1621:
  %v6038 = load i64, ptr %slot69, align 8
  store i64 %v6038, ptr %slot1121, align 8
  %v6039 = load i64, ptr %slot1121, align 8
  %v6040 = load i64, ptr %slot1117, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6039, i64 %v6040) nomerge, !dbg !166
  br label %bb_rcslotdone1621
bb_rcslotdone1621:
  %v6041 = load i64, ptr %slot12, align 8
  %p6042 = inttoptr i64 %v6041 to ptr
  %ld6043 = load i32, ptr %p6042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6043, ptr %slot1122, align 8
  %v6044 = load i32, ptr %slot1122, align 8
  %cv6045 = zext i32 %v6044 to i64
  %cond6046 = icmp ne i64 %cv6045, 0
  br i1 %cond6046, label %bb_rcslotdrop1630, label %bb_rcslotdone1630
bb_rcslotdrop1630:
  %v6047 = load i64, ptr %slot12, align 8
  %p6048 = inttoptr i64 %v6047 to ptr
  store i32 0, ptr %p6048, align 4, !alias.scope !3, !noalias !4
  %v6049 = load i64, ptr %slot48, align 8
  store i64 %v6049, ptr %slot1123, align 8
  %v6050 = load i64, ptr %slot13, align 8
  %p6051 = inttoptr i64 %v6050 to ptr
  %ld6052 = load i32, ptr %p6051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6052, ptr %slot1124, align 8
  %v6053 = load i32, ptr %slot1124, align 8
  %op6054 = and i32 %v6053, 28
  store i32 %op6054, ptr %slot1125, align 8
  %v6055 = load i32, ptr %slot1125, align 8
  %cv6056 = zext i32 %v6055 to i64
  %cond6057 = icmp ne i64 %cv6056, 0
  br i1 %cond6057, label %bb_rcslotrole1630, label %bb_rcslotowner1630
bb_rcslotrole1630:
  %v6058 = load i64, ptr %slot69, align 8
  store i64 %v6058, ptr %slot1126, align 8
  %v6059 = load i64, ptr %slot1126, align 8
  %v6060 = load i64, ptr %slot1123, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v6059, i64 %v6060) nomerge, !dbg !166
  br label %bb_rcslotdone1630
bb_rcslotowner1630:
  %v6061 = load i64, ptr %slot69, align 8
  store i64 %v6061, ptr %slot1127, align 8
  %v6062 = load i64, ptr %slot1127, align 8
  %v6063 = load i64, ptr %slot1123, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v6062, i64 %v6063) nomerge, !dbg !166
  br label %bb_rcslotdone1630
bb_rcslotdone1630:
  %v6064 = load i64, ptr %slot10, align 8
  %p6065 = inttoptr i64 %v6064 to ptr
  %ld6066 = load i32, ptr %p6065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6066, ptr %slot1128, align 8
  %v6067 = load i32, ptr %slot1128, align 8
  %cv6068 = zext i32 %v6067 to i64
  %cond6069 = icmp ne i64 %cv6068, 0
  br i1 %cond6069, label %bb_rcslotdrop1639, label %bb_rcslotdone1639
bb_rcslotdrop1639:
  %v6070 = load i64, ptr %slot10, align 8
  %p6071 = inttoptr i64 %v6070 to ptr
  store i32 0, ptr %p6071, align 4, !alias.scope !3, !noalias !4
  %v6072 = load i64, ptr %slot47, align 8
  store i64 %v6072, ptr %slot1129, align 8
  %v6073 = load i64, ptr %slot11, align 8
  %p6074 = inttoptr i64 %v6073 to ptr
  %ld6075 = load i32, ptr %p6074, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6075, ptr %slot1130, align 8
  %v6076 = load i32, ptr %slot1130, align 8
  %op6077 = and i32 %v6076, 28
  store i32 %op6077, ptr %slot1131, align 8
  %v6078 = load i32, ptr %slot1131, align 8
  %cv6079 = zext i32 %v6078 to i64
  %cond6080 = icmp ne i64 %cv6079, 0
  br i1 %cond6080, label %bb_rcslotrole1639, label %bb_rcslotowner1639
bb_rcslotrole1639:
  %v6081 = load i64, ptr %slot69, align 8
  store i64 %v6081, ptr %slot1132, align 8
  %v6082 = load i64, ptr %slot1129, align 8
  %p6083 = inttoptr i64 %v6082 to ptr
  %ld6084 = load i64, ptr %p6083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6084, ptr %slot1133, align 8
  %v6085 = load i64, ptr %slot1133, align 8
  %cmp6086 = icmp ne i64 %v6085, 0
  %cv6087 = zext i1 %cmp6086 to i32
  store i32 %cv6087, ptr %slot1134, align 8
  %v6088 = load i32, ptr %slot1134, align 8
  %cv6089 = zext i32 %v6088 to i64
  %cond6090 = icmp ne i64 %cv6089, 0
  br i1 %cond6090, label %bb_rcgnn1655, label %bb_rcgdone1655
bb_rcgnn1655:
  %v6091 = load i64, ptr %slot1133, align 8
  %op6092 = sub i64 %v6091, 16
  store i64 %op6092, ptr %slot1135, align 8
  %v6093 = load i64, ptr %slot1133, align 8
  %p6094 = inttoptr i64 %v6093 to ptr
  %rgep6095 = getelementptr i8, ptr %p6094, i64 -16
  %ld6096 = load i64, ptr %rgep6095, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6096, ptr %slot1136, align 8
  %v6097 = load i64, ptr %slot1136, align 8
  %op6098 = and i64 %v6097, 4611686018427387906
  store i64 %op6098, ptr %slot1137, align 8
  %v6099 = load i64, ptr %slot1137, align 8
  %cmp6100 = icmp ne i64 %v6099, 0
  %cv6101 = zext i1 %cmp6100 to i32
  store i32 %cv6101, ptr %slot1138, align 8
  %v6102 = load i32, ptr %slot1138, align 8
  %cv6103 = zext i32 %v6102 to i64
  %cond6104 = icmp ne i64 %cv6103, 0
  br i1 %cond6104, label %bb_rcgclear1655, label %bb_rcgcounted1655
bb_rcgcounted1655:
  %v6105 = load i64, ptr %slot1133, align 8
  %op6106 = sub i64 %v6105, 24
  store i64 %op6106, ptr %slot1139, align 8
  %v6107 = load i64, ptr %slot1133, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  %rgep6109 = getelementptr i8, ptr %p6108, i64 -24
  %ld6110 = load i64, ptr %rgep6109, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6110, ptr %slot1140, align 8
  %v6111 = load i64, ptr %slot1140, align 8
  %op6112 = sub i64 %v6111, 1
  store i64 %op6112, ptr %slot1141, align 8
  %v6113 = load i64, ptr %slot1141, align 8
  %cmp6114 = icmp eq i64 %v6113, 0
  %cv6115 = zext i1 %cmp6114 to i32
  store i32 %cv6115, ptr %slot1142, align 8
  %v6116 = load i32, ptr %slot1142, align 8
  %cv6117 = zext i32 %v6116 to i64
  %cond6118 = icmp ne i64 %cv6117, 0
  br i1 %cond6118, label %bb_rcglast1655, label %bb_rcgdec1655
bb_rcglast1655:
  %v6119 = load i64, ptr %slot1133, align 8
  %op6120 = sub i64 %v6119, 32
  store i64 %op6120, ptr %slot1143, align 8
  %v6121 = load i64, ptr %slot1133, align 8
  %p6122 = inttoptr i64 %v6121 to ptr
  %rgep6123 = getelementptr i8, ptr %p6122, i64 -32
  %ld6124 = load i64, ptr %rgep6123, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6124, ptr %slot1144, align 8
  %v6125 = load i64, ptr %slot1144, align 8
  %cmp6126 = icmp ne i64 %v6125, 0
  %cv6127 = zext i1 %cmp6126 to i32
  store i32 %cv6127, ptr %slot1145, align 8
  %v6128 = load i32, ptr %slot1145, align 8
  %cv6129 = zext i32 %v6128 to i64
  %cond6130 = icmp ne i64 %cv6129, 0
  br i1 %cond6130, label %bb_rcgdec1655, label %bb_rcgslow1655
bb_rcgslow1655:
  %v6131 = load i64, ptr %slot1132, align 8
  %v6132 = load i64, ptr %slot1129, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_unloan(i64 %v6131, i64 %v6132) nomerge, !dbg !166
  br label %bb_rcgdone1655
bb_rcgdec1655:
  %v6133 = load i64, ptr %slot1141, align 8
  %v6134 = load i64, ptr %slot1133, align 8
  %p6135 = inttoptr i64 %v6134 to ptr
  %rgep6136 = getelementptr i8, ptr %p6135, i64 -24
  store i64 %v6133, ptr %rgep6136, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1655
bb_rcgclear1655:
  %v6137 = load i64, ptr %slot1129, align 8
  %p6138 = inttoptr i64 %v6137 to ptr
  store i64 0, ptr %p6138, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1655
bb_rcgdone1655:
  br label %bb_rcslotdone1639
bb_rcslotowner1639:
  %v6139 = load i64, ptr %slot69, align 8
  store i64 %v6139, ptr %slot1146, align 8
  %v6140 = load i64, ptr %slot1129, align 8
  %p6141 = inttoptr i64 %v6140 to ptr
  %ld6142 = load i64, ptr %p6141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6142, ptr %slot1147, align 8
  %v6143 = load i64, ptr %slot1147, align 8
  %cmp6144 = icmp ne i64 %v6143, 0
  %cv6145 = zext i1 %cmp6144 to i32
  store i32 %cv6145, ptr %slot1148, align 8
  %v6146 = load i32, ptr %slot1148, align 8
  %cv6147 = zext i32 %v6146 to i64
  %cond6148 = icmp ne i64 %cv6147, 0
  br i1 %cond6148, label %bb_rcgnn1670, label %bb_rcgdone1670
bb_rcgnn1670:
  %v6149 = load i64, ptr %slot1147, align 8
  %op6150 = sub i64 %v6149, 16
  store i64 %op6150, ptr %slot1149, align 8
  %v6151 = load i64, ptr %slot1147, align 8
  %p6152 = inttoptr i64 %v6151 to ptr
  %rgep6153 = getelementptr i8, ptr %p6152, i64 -16
  %ld6154 = load i64, ptr %rgep6153, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6154, ptr %slot1150, align 8
  %v6155 = load i64, ptr %slot1150, align 8
  %op6156 = and i64 %v6155, 4611686018427387906
  store i64 %op6156, ptr %slot1151, align 8
  %v6157 = load i64, ptr %slot1151, align 8
  %cmp6158 = icmp ne i64 %v6157, 0
  %cv6159 = zext i1 %cmp6158 to i32
  store i32 %cv6159, ptr %slot1152, align 8
  %v6160 = load i32, ptr %slot1152, align 8
  %cv6161 = zext i32 %v6160 to i64
  %cond6162 = icmp ne i64 %cv6161, 0
  br i1 %cond6162, label %bb_rcgclear1670, label %bb_rcgcounted1670
bb_rcgcounted1670:
  %v6163 = load i64, ptr %slot1147, align 8
  %op6164 = sub i64 %v6163, 32
  store i64 %op6164, ptr %slot1153, align 8
  %v6165 = load i64, ptr %slot1147, align 8
  %p6166 = inttoptr i64 %v6165 to ptr
  %rgep6167 = getelementptr i8, ptr %p6166, i64 -32
  %ld6168 = load i64, ptr %rgep6167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6168, ptr %slot1154, align 8
  %v6169 = load i64, ptr %slot1154, align 8
  %op6170 = sub i64 %v6169, 1
  store i64 %op6170, ptr %slot1155, align 8
  %v6171 = load i64, ptr %slot1155, align 8
  %cmp6172 = icmp eq i64 %v6171, 0
  %cv6173 = zext i1 %cmp6172 to i32
  store i32 %cv6173, ptr %slot1156, align 8
  %v6174 = load i32, ptr %slot1156, align 8
  %cv6175 = zext i32 %v6174 to i64
  %cond6176 = icmp ne i64 %cv6175, 0
  br i1 %cond6176, label %bb_rcglast1670, label %bb_rcgdec1670
bb_rcglast1670:
  %v6177 = load i64, ptr %slot1147, align 8
  %op6178 = sub i64 %v6177, 24
  store i64 %op6178, ptr %slot1157, align 8
  %v6179 = load i64, ptr %slot1147, align 8
  %p6180 = inttoptr i64 %v6179 to ptr
  %rgep6181 = getelementptr i8, ptr %p6180, i64 -24
  %ld6182 = load i64, ptr %rgep6181, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6182, ptr %slot1158, align 8
  %v6183 = load i64, ptr %slot1158, align 8
  %cmp6184 = icmp ne i64 %v6183, 0
  %cv6185 = zext i1 %cmp6184 to i32
  store i32 %cv6185, ptr %slot1159, align 8
  %v6186 = load i32, ptr %slot1159, align 8
  %cv6187 = zext i32 %v6186 to i64
  %cond6188 = icmp ne i64 %cv6187, 0
  br i1 %cond6188, label %bb_rcgdec1670, label %bb_rcgslow1670
bb_rcgslow1670:
  %v6189 = load i64, ptr %slot1146, align 8
  %v6190 = load i64, ptr %slot1129, align 8
  call void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_drop(i64 %v6189, i64 %v6190) nomerge, !dbg !166
  br label %bb_rcgdone1670
bb_rcgdec1670:
  %v6191 = load i64, ptr %slot1155, align 8
  %v6192 = load i64, ptr %slot1147, align 8
  %p6193 = inttoptr i64 %v6192 to ptr
  %rgep6194 = getelementptr i8, ptr %p6193, i64 -32
  store i64 %v6191, ptr %rgep6194, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1670
bb_rcgclear1670:
  %v6195 = load i64, ptr %slot1129, align 8
  %p6196 = inttoptr i64 %v6195 to ptr
  store i64 0, ptr %p6196, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1670
bb_rcgdone1670:
  br label %bb_rcslotdone1639
bb_rcslotdone1639:
  %v6197 = load i64, ptr %slot8, align 8
  %p6198 = inttoptr i64 %v6197 to ptr
  %ld6199 = load i32, ptr %p6198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6199, ptr %slot1160, align 8
  %v6200 = load i32, ptr %slot1160, align 8
  %cv6201 = zext i32 %v6200 to i64
  %cond6202 = icmp ne i64 %cv6201, 0
  br i1 %cond6202, label %bb_rcslotdrop1676, label %bb_rcslotdone1676
bb_rcslotdrop1676:
  %v6203 = load i64, ptr %slot8, align 8
  %p6204 = inttoptr i64 %v6203 to ptr
  store i32 0, ptr %p6204, align 4, !alias.scope !3, !noalias !4
  %v6205 = load i64, ptr %slot46, align 8
  store i64 %v6205, ptr %slot1161, align 8
  %v6206 = load i64, ptr %slot9, align 8
  %p6207 = inttoptr i64 %v6206 to ptr
  %ld6208 = load i32, ptr %p6207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6208, ptr %slot1162, align 8
  %v6209 = load i32, ptr %slot1162, align 8
  %op6210 = and i32 %v6209, 28
  store i32 %op6210, ptr %slot1163, align 8
  %v6211 = load i32, ptr %slot1163, align 8
  %cv6212 = zext i32 %v6211 to i64
  %cond6213 = icmp ne i64 %cv6212, 0
  br i1 %cond6213, label %bb_rcslotrole1676, label %bb_rcslotowner1676
bb_rcslotrole1676:
  %v6214 = load i64, ptr %slot69, align 8
  store i64 %v6214, ptr %slot1164, align 8
  %v6215 = load i64, ptr %slot1161, align 8
  %p6216 = inttoptr i64 %v6215 to ptr
  %ld6217 = load i64, ptr %p6216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6217, ptr %slot1165, align 8
  %v6218 = load i64, ptr %slot1165, align 8
  %cmp6219 = icmp ne i64 %v6218, 0
  %cv6220 = zext i1 %cmp6219 to i32
  store i32 %cv6220, ptr %slot1166, align 8
  %v6221 = load i32, ptr %slot1166, align 8
  %cv6222 = zext i32 %v6221 to i64
  %cond6223 = icmp ne i64 %cv6222, 0
  br i1 %cond6223, label %bb_rcgnn1692, label %bb_rcgdone1692
bb_rcgnn1692:
  %v6224 = load i64, ptr %slot1165, align 8
  %op6225 = sub i64 %v6224, 16
  store i64 %op6225, ptr %slot1167, align 8
  %v6226 = load i64, ptr %slot1165, align 8
  %p6227 = inttoptr i64 %v6226 to ptr
  %rgep6228 = getelementptr i8, ptr %p6227, i64 -16
  %ld6229 = load i64, ptr %rgep6228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6229, ptr %slot1168, align 8
  %v6230 = load i64, ptr %slot1168, align 8
  %op6231 = and i64 %v6230, 4611686018427387906
  store i64 %op6231, ptr %slot1169, align 8
  %v6232 = load i64, ptr %slot1169, align 8
  %cmp6233 = icmp ne i64 %v6232, 0
  %cv6234 = zext i1 %cmp6233 to i32
  store i32 %cv6234, ptr %slot1170, align 8
  %v6235 = load i32, ptr %slot1170, align 8
  %cv6236 = zext i32 %v6235 to i64
  %cond6237 = icmp ne i64 %cv6236, 0
  br i1 %cond6237, label %bb_rcgclear1692, label %bb_rcgcounted1692
bb_rcgcounted1692:
  %v6238 = load i64, ptr %slot1165, align 8
  %op6239 = sub i64 %v6238, 24
  store i64 %op6239, ptr %slot1171, align 8
  %v6240 = load i64, ptr %slot1165, align 8
  %p6241 = inttoptr i64 %v6240 to ptr
  %rgep6242 = getelementptr i8, ptr %p6241, i64 -24
  %ld6243 = load i64, ptr %rgep6242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6243, ptr %slot1172, align 8
  %v6244 = load i64, ptr %slot1172, align 8
  %op6245 = sub i64 %v6244, 1
  store i64 %op6245, ptr %slot1173, align 8
  %v6246 = load i64, ptr %slot1173, align 8
  %cmp6247 = icmp eq i64 %v6246, 0
  %cv6248 = zext i1 %cmp6247 to i32
  store i32 %cv6248, ptr %slot1174, align 8
  %v6249 = load i32, ptr %slot1174, align 8
  %cv6250 = zext i32 %v6249 to i64
  %cond6251 = icmp ne i64 %cv6250, 0
  br i1 %cond6251, label %bb_rcglast1692, label %bb_rcgdec1692
bb_rcglast1692:
  %v6252 = load i64, ptr %slot1165, align 8
  %op6253 = sub i64 %v6252, 32
  store i64 %op6253, ptr %slot1175, align 8
  %v6254 = load i64, ptr %slot1165, align 8
  %p6255 = inttoptr i64 %v6254 to ptr
  %rgep6256 = getelementptr i8, ptr %p6255, i64 -32
  %ld6257 = load i64, ptr %rgep6256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6257, ptr %slot1176, align 8
  %v6258 = load i64, ptr %slot1176, align 8
  %cmp6259 = icmp ne i64 %v6258, 0
  %cv6260 = zext i1 %cmp6259 to i32
  store i32 %cv6260, ptr %slot1177, align 8
  %v6261 = load i32, ptr %slot1177, align 8
  %cv6262 = zext i32 %v6261 to i64
  %cond6263 = icmp ne i64 %cv6262, 0
  br i1 %cond6263, label %bb_rcgdec1692, label %bb_rcgslow1692
bb_rcgslow1692:
  %v6264 = load i64, ptr %slot1164, align 8
  %v6265 = load i64, ptr %slot1161, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v6264, i64 %v6265) nomerge, !dbg !166
  br label %bb_rcgdone1692
bb_rcgdec1692:
  %v6266 = load i64, ptr %slot1173, align 8
  %v6267 = load i64, ptr %slot1165, align 8
  %p6268 = inttoptr i64 %v6267 to ptr
  %rgep6269 = getelementptr i8, ptr %p6268, i64 -24
  store i64 %v6266, ptr %rgep6269, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1692
bb_rcgclear1692:
  %v6270 = load i64, ptr %slot1161, align 8
  %p6271 = inttoptr i64 %v6270 to ptr
  store i64 0, ptr %p6271, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1692
bb_rcgdone1692:
  br label %bb_rcslotdone1676
bb_rcslotowner1676:
  %v6272 = load i64, ptr %slot69, align 8
  store i64 %v6272, ptr %slot1178, align 8
  %v6273 = load i64, ptr %slot1161, align 8
  %p6274 = inttoptr i64 %v6273 to ptr
  %ld6275 = load i64, ptr %p6274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6275, ptr %slot1179, align 8
  %v6276 = load i64, ptr %slot1179, align 8
  %cmp6277 = icmp ne i64 %v6276, 0
  %cv6278 = zext i1 %cmp6277 to i32
  store i32 %cv6278, ptr %slot1180, align 8
  %v6279 = load i32, ptr %slot1180, align 8
  %cv6280 = zext i32 %v6279 to i64
  %cond6281 = icmp ne i64 %cv6280, 0
  br i1 %cond6281, label %bb_rcgnn1707, label %bb_rcgdone1707
bb_rcgnn1707:
  %v6282 = load i64, ptr %slot1179, align 8
  %op6283 = sub i64 %v6282, 16
  store i64 %op6283, ptr %slot1181, align 8
  %v6284 = load i64, ptr %slot1179, align 8
  %p6285 = inttoptr i64 %v6284 to ptr
  %rgep6286 = getelementptr i8, ptr %p6285, i64 -16
  %ld6287 = load i64, ptr %rgep6286, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6287, ptr %slot1182, align 8
  %v6288 = load i64, ptr %slot1182, align 8
  %op6289 = and i64 %v6288, 4611686018427387906
  store i64 %op6289, ptr %slot1183, align 8
  %v6290 = load i64, ptr %slot1183, align 8
  %cmp6291 = icmp ne i64 %v6290, 0
  %cv6292 = zext i1 %cmp6291 to i32
  store i32 %cv6292, ptr %slot1184, align 8
  %v6293 = load i32, ptr %slot1184, align 8
  %cv6294 = zext i32 %v6293 to i64
  %cond6295 = icmp ne i64 %cv6294, 0
  br i1 %cond6295, label %bb_rcgclear1707, label %bb_rcgcounted1707
bb_rcgcounted1707:
  %v6296 = load i64, ptr %slot1179, align 8
  %op6297 = sub i64 %v6296, 32
  store i64 %op6297, ptr %slot1185, align 8
  %v6298 = load i64, ptr %slot1179, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  %rgep6300 = getelementptr i8, ptr %p6299, i64 -32
  %ld6301 = load i64, ptr %rgep6300, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6301, ptr %slot1186, align 8
  %v6302 = load i64, ptr %slot1186, align 8
  %op6303 = sub i64 %v6302, 1
  store i64 %op6303, ptr %slot1187, align 8
  %v6304 = load i64, ptr %slot1187, align 8
  %cmp6305 = icmp eq i64 %v6304, 0
  %cv6306 = zext i1 %cmp6305 to i32
  store i32 %cv6306, ptr %slot1188, align 8
  %v6307 = load i32, ptr %slot1188, align 8
  %cv6308 = zext i32 %v6307 to i64
  %cond6309 = icmp ne i64 %cv6308, 0
  br i1 %cond6309, label %bb_rcglast1707, label %bb_rcgdec1707
bb_rcglast1707:
  %v6310 = load i64, ptr %slot1179, align 8
  %op6311 = sub i64 %v6310, 24
  store i64 %op6311, ptr %slot1189, align 8
  %v6312 = load i64, ptr %slot1179, align 8
  %p6313 = inttoptr i64 %v6312 to ptr
  %rgep6314 = getelementptr i8, ptr %p6313, i64 -24
  %ld6315 = load i64, ptr %rgep6314, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6315, ptr %slot1190, align 8
  %v6316 = load i64, ptr %slot1190, align 8
  %cmp6317 = icmp ne i64 %v6316, 0
  %cv6318 = zext i1 %cmp6317 to i32
  store i32 %cv6318, ptr %slot1191, align 8
  %v6319 = load i32, ptr %slot1191, align 8
  %cv6320 = zext i32 %v6319 to i64
  %cond6321 = icmp ne i64 %cv6320, 0
  br i1 %cond6321, label %bb_rcgdec1707, label %bb_rcgslow1707
bb_rcgslow1707:
  %v6322 = load i64, ptr %slot1178, align 8
  %v6323 = load i64, ptr %slot1161, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v6322, i64 %v6323) nomerge, !dbg !166
  br label %bb_rcgdone1707
bb_rcgdec1707:
  %v6324 = load i64, ptr %slot1187, align 8
  %v6325 = load i64, ptr %slot1179, align 8
  %p6326 = inttoptr i64 %v6325 to ptr
  %rgep6327 = getelementptr i8, ptr %p6326, i64 -32
  store i64 %v6324, ptr %rgep6327, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1707
bb_rcgclear1707:
  %v6328 = load i64, ptr %slot1161, align 8
  %p6329 = inttoptr i64 %v6328 to ptr
  store i64 0, ptr %p6329, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1707
bb_rcgdone1707:
  br label %bb_rcslotdone1676
bb_rcslotdone1676:
  %v6330 = load i64, ptr %slot6, align 8
  %p6331 = inttoptr i64 %v6330 to ptr
  %ld6332 = load i32, ptr %p6331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6332, ptr %slot1192, align 8
  %v6333 = load i32, ptr %slot1192, align 8
  %cv6334 = zext i32 %v6333 to i64
  %cond6335 = icmp ne i64 %cv6334, 0
  br i1 %cond6335, label %bb_rcslotdrop1713, label %bb_rcslotdone1713
bb_rcslotdrop1713:
  %v6336 = load i64, ptr %slot6, align 8
  %p6337 = inttoptr i64 %v6336 to ptr
  store i32 0, ptr %p6337, align 4, !alias.scope !3, !noalias !4
  %v6338 = load i64, ptr %slot45, align 8
  store i64 %v6338, ptr %slot1193, align 8
  %v6339 = load i64, ptr %slot7, align 8
  %p6340 = inttoptr i64 %v6339 to ptr
  %ld6341 = load i32, ptr %p6340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6341, ptr %slot1194, align 8
  %v6342 = load i32, ptr %slot1194, align 8
  %op6343 = and i32 %v6342, 28
  store i32 %op6343, ptr %slot1195, align 8
  %v6344 = load i32, ptr %slot1195, align 8
  %cv6345 = zext i32 %v6344 to i64
  %cond6346 = icmp ne i64 %cv6345, 0
  br i1 %cond6346, label %bb_rcslotrole1713, label %bb_rcslotowner1713
bb_rcslotrole1713:
  %v6347 = load i64, ptr %slot69, align 8
  store i64 %v6347, ptr %slot1196, align 8
  %v6348 = load i64, ptr %slot1196, align 8
  %v6349 = load i64, ptr %slot1193, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6348, i64 %v6349) nomerge, !dbg !166
  br label %bb_rcslotdone1713
bb_rcslotowner1713:
  %v6350 = load i64, ptr %slot69, align 8
  store i64 %v6350, ptr %slot1197, align 8
  %v6351 = load i64, ptr %slot1197, align 8
  %v6352 = load i64, ptr %slot1193, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6351, i64 %v6352) nomerge, !dbg !166
  br label %bb_rcslotdone1713
bb_rcslotdone1713:
  %v6353 = load i64, ptr %slot1114, align 8
  ret i64 %v6353
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 = external global i8, align 8
@myl_t_eaa2bbcf1c7f4f7dc2a456cf256ba18c275165535be3a775a2eb8fbf8fec29dc = external global i8, align 8
@myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_5e6209cefaee8ea6d883ace626debeee15428cfe0110c0f4efb2078a8004f54f(ptr sret([88 x i8]) align 8, i64, i64)
declare i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64, i64)
declare i64 @myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8(i64, i64)
declare void @myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc_rc_borrow(ptr sret([32 x i8]) align 8, i64, i64)
declare i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64, i64, i64)
declare i64 @myl_f_d0f0fd2ebc58c2edfb4f79ef4b78cc0dec904f09b2ad13c907ec77d7bf9667f3(i64, i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64, i64, i64, i32)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare i32 @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_take(i64, i64, i64, i32)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64, i64, i64, i32)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_drop(i64, i64)
declare i32 @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a5f5eb6b7fca94d1db160832e04baa45b6202a07ceabfcb845257cf7ba2a5b1b_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3630acb655f9e1aa5d70df28747f81788f82bcead7fb7dc504ad96e854540059", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3630acb655f9e1aa5d70df28747f81788f82bcead7fb7dc504ad96e854540059", linkageName: "myl_f_3630acb655f9e1aa5d70df28747f81788f82bcead7fb7dc504ad96e854540059", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8591394188107695672, i64 0, !"myl_f_3630acb655f9e1aa5d70df28747f81788f82bcead7fb7dc504ad96e854540059"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!118 = !DILocation(line: 9, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!120 = !DILocation(line: 11, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!122 = !DILocation(line: 14, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!124 = !DILocation(line: 20, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!126 = !DILocation(line: 21, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!128 = !DILocation(line: 25, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!130 = !DILocation(line: 26, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!132 = !DILocation(line: 29, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!134 = !DILocation(line: 30, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!136 = !DILocation(line: 33, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!138 = !DILocation(line: 36, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!140 = !DILocation(line: 40, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!142 = !DILocation(line: 44, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!144 = !DILocation(line: 48, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!146 = !DILocation(line: 49, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!148 = !DILocation(line: 51, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!150 = !DILocation(line: 52, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!152 = !DILocation(line: 53, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!154 = !DILocation(line: 55, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!156 = !DILocation(line: 56, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!158 = !DILocation(line: 57, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!160 = !DILocation(line: 59, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!162 = !DILocation(line: 62, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647047)
!164 = !DILocation(line: 64, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!166 = !DILocation(line: 65, column: 0, scope: !167)
