target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v26 = load i64, ptr %slot1, align 8
  %op27 = add i64 %v26, 32
  store i64 %op27, ptr %slot4, align 8
  %mem28 = alloca i8, i64 8, align 8
  %ptr29 = ptrtoint ptr %mem28 to i64
  store i64 %ptr29, ptr %slot5, align 8
  %mem30 = alloca i8, i64 8, align 8
  %ptr31 = ptrtoint ptr %mem30 to i64
  store i64 %ptr31, ptr %slot6, align 8
  %mem32 = alloca i8, i64 8, align 8
  %ptr33 = ptrtoint ptr %mem32 to i64
  store i64 %ptr33, ptr %slot7, align 8
  %mem34 = alloca i8, i64 8, align 8
  %ptr35 = ptrtoint ptr %mem34 to i64
  store i64 %ptr35, ptr %slot8, align 8
  %mem36 = alloca i8, i64 8, align 8
  %ptr37 = ptrtoint ptr %mem36 to i64
  store i64 %ptr37, ptr %slot9, align 8
  %mem38 = alloca i8, i64 8, align 8
  %ptr39 = ptrtoint ptr %mem38 to i64
  store i64 %ptr39, ptr %slot10, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem40 = alloca i8, i64 8, align 8
  %ptr41 = ptrtoint ptr %mem40 to i64
  store i64 %ptr41, ptr %slot11, align 8
  %v42 = load i64, ptr %slot1, align 8
  %op43 = add i64 %v42, 64
  store i64 %op43, ptr %slot12, align 8
  %v44 = load i64, ptr %slot12, align 8
  %p45 = inttoptr i64 %v44 to ptr
  %ld46 = load i64, ptr %p45, align 8, !alias.scope !4, !noalias !3
  store i64 %ld46, ptr %slot13, align 8
  %stack47 = call ptr @llvm.stacksave()
  %stackaddr48 = ptrtoint ptr %stack47 to i64
  %v49 = load i64, ptr %slot13, align 8
  %cmp50 = icmp ult i64 %stackaddr48, %v49
  %cv51 = zext i1 %cmp50 to i64
  store i64 %cv51, ptr %slot14, align 8
  %v52 = load i64, ptr %slot14, align 8
  %cond53 = icmp ne i64 %v52, 0
  br i1 %cond53, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v54 = load i64, ptr %slot1, align 8
  %p55 = inttoptr i64 %v54 to ptr
  call void @myl_qbe_fail_frame(ptr %p55) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v56 = load i64, ptr %slot2, align 8
  %v57 = load i64, ptr %slot5, align 8
  %p58 = inttoptr i64 %v57 to ptr
  store i64 %v56, ptr %p58, align 8, !alias.scope !3, !noalias !4
  %v59 = load i64, ptr %slot3, align 8
  %v60 = load i64, ptr %slot6, align 8
  %p61 = inttoptr i64 %v60 to ptr
  store i64 %v59, ptr %p61, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v62 = load i64, ptr %slot5, align 8
  %p63 = inttoptr i64 %v62 to ptr
  %ld64 = load i64, ptr %p63, align 8, !alias.scope !3, !noalias !4
  store i64 %ld64, ptr %slot15, align 8
  %v65 = load i64, ptr %slot15, align 8
  %v66 = load i64, ptr %slot7, align 8
  %p67 = inttoptr i64 %v66 to ptr
  store i64 %v65, ptr %p67, align 8, !alias.scope !3, !noalias !4
  %v68 = load i64, ptr %slot8, align 8
  %p69 = inttoptr i64 %v68 to ptr
  store i64 0, ptr %p69, align 8, !alias.scope !3, !noalias !4
  %v70 = load i64, ptr %slot5, align 8
  %p71 = inttoptr i64 %v70 to ptr
  %ld72 = load i64, ptr %p71, align 8, !alias.scope !3, !noalias !4
  store i64 %ld72, ptr %slot16, align 8
  %v73 = load i64, ptr %slot16, align 8
  %v74 = load i64, ptr %slot9, align 8
  %p75 = inttoptr i64 %v74 to ptr
  store i64 %v73, ptr %p75, align 8, !alias.scope !3, !noalias !4
  %v76 = load i64, ptr %slot6, align 8
  %p77 = inttoptr i64 %v76 to ptr
  %ld78 = load i64, ptr %p77, align 8, !alias.scope !3, !noalias !4
  store i64 %ld78, ptr %slot17, align 8
  %v79 = load i64, ptr %slot17, align 8
  %v80 = load i64, ptr %slot10, align 8
  %p81 = inttoptr i64 %v80 to ptr
  store i64 %v79, ptr %p81, align 8, !alias.scope !3, !noalias !4
  %v82 = load i64, ptr %slot9, align 8
  %p83 = inttoptr i64 %v82 to ptr
  %ld84 = load i64, ptr %p83, align 8, !alias.scope !3, !noalias !4
  store i64 %ld84, ptr %slot18, align 8
  %v85 = load i64, ptr %slot10, align 8
  %p86 = inttoptr i64 %v85 to ptr
  %ld87 = load i64, ptr %p86, align 8, !alias.scope !3, !noalias !4
  store i64 %ld87, ptr %slot19, align 8
  %v88 = load i64, ptr %slot1, align 8
  %v89 = load i64, ptr %slot18, align 8
  %v90 = load i64, ptr %slot19, align 8
  %call91 = call i64 @myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f(i64 %v88, i64 %v89, i64 %v90) nomerge, !dbg !112
  store i64 %call91, ptr %slot20, align 8
  %v92 = load i64, ptr %slot20, align 8
  %v93 = load i64, ptr %slot9, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i64 %v92, ptr %p94, align 8, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot7, align 8
  %p96 = inttoptr i64 %v95 to ptr
  %ld97 = load i64, ptr %p96, align 8, !alias.scope !3, !noalias !4
  store i64 %ld97, ptr %slot21, align 8
  %v98 = load i64, ptr %slot8, align 8
  %p99 = inttoptr i64 %v98 to ptr
  %ld100 = load i64, ptr %p99, align 8, !alias.scope !3, !noalias !4
  store i64 %ld100, ptr %slot22, align 8
  %v101 = load i64, ptr %slot9, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %ld103 = load i64, ptr %p102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld103, ptr %slot23, align 8
  %v104 = load i64, ptr %slot1, align 8
  %v105 = load i64, ptr %slot21, align 8
  %v106 = load i64, ptr %slot22, align 8
  %v107 = load i64, ptr %slot23, align 8
  %call108 = call i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64 %v104, i64 %v105, i64 %v106, i64 %v107) nomerge, !dbg !114
  store i64 %call108, ptr %slot24, align 8
  %v109 = load i64, ptr %slot24, align 8
  %v110 = load i64, ptr %slot7, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot7, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 0, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot7, align 8
  %p115 = inttoptr i64 %v114 to ptr
  %ld116 = load i64, ptr %p115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld116, ptr %slot25, align 8
  %v117 = load i64, ptr %slot25, align 8
  ret i64 %v117
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare i64 @myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f(i64, i64, i64)
declare i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365", linkageName: "myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5225656223848315895, i64 0, !"myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!112 = !DILocation(line: 5, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
