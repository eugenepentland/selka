target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_e22482a0807d12562d64ed5d8c5e8b8ccef34761b2567c14443ddc2d6e9decfd(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i32, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i32, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i32, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i32, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i32, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i32, align 8
  %slot1077 = alloca i32, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i32, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i32, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i32, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i32, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i32, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i32, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i32, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i32, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i32, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i32, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i32, align 8
  %slot1182 = alloca i32, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i32, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i32, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i32, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i32, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i32, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i32, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i32, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i32, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i32, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i32, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i32, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i32, align 8
  %slot1260 = alloca i32, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i32, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i32, align 8
  %slot1277 = alloca i32, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i32, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i32, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i32, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i32, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i32, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i64, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i32, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i32, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %callresult1346 = alloca [40 x i8], align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i32, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i32, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i32, align 8
  %slot1363 = alloca i32, align 8
  %slot1364 = alloca i32, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i32, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i32, align 8
  %slot1369 = alloca i32, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i32, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i32, align 8
  %slot1375 = alloca i32, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i32, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i32, align 8
  %slot1381 = alloca i32, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i32, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i32, align 8
  %slot1387 = alloca i32, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i32, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i32, align 8
  %slot1393 = alloca i32, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i32, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i32, align 8
  %slot1399 = alloca i32, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i32, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i32, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i32, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v1414 = load i64, ptr %slot1, align 8
  %op1415 = add i64 %v1414, 32
  store i64 %op1415, ptr %slot3, align 8
  %mem1416 = alloca i8, i64 40, align 8
  %ptr1417 = ptrtoint ptr %mem1416 to i64
  store i64 %ptr1417, ptr %slot4, align 8
  %mem1418 = alloca i8, i64 8, align 8
  %ptr1419 = ptrtoint ptr %mem1418 to i64
  store i64 %ptr1419, ptr %slot5, align 8
  %mem1420 = alloca i8, i64 8, align 8
  %ptr1421 = ptrtoint ptr %mem1420 to i64
  store i64 %ptr1421, ptr %slot6, align 8
  %mem1422 = alloca i8, i64 8, align 8
  %ptr1423 = ptrtoint ptr %mem1422 to i64
  store i64 %ptr1423, ptr %slot7, align 8
  %mem1424 = alloca i8, i64 8, align 8
  %ptr1425 = ptrtoint ptr %mem1424 to i64
  store i64 %ptr1425, ptr %slot8, align 8
  %mem1426 = alloca i8, i64 8, align 8
  %ptr1427 = ptrtoint ptr %mem1426 to i64
  store i64 %ptr1427, ptr %slot9, align 8
  %mem1428 = alloca i8, i64 8, align 8
  %ptr1429 = ptrtoint ptr %mem1428 to i64
  store i64 %ptr1429, ptr %slot10, align 8
  %mem1430 = alloca i8, i64 8, align 8
  %ptr1431 = ptrtoint ptr %mem1430 to i64
  store i64 %ptr1431, ptr %slot11, align 8
  %mem1432 = alloca i8, i64 8, align 8
  %ptr1433 = ptrtoint ptr %mem1432 to i64
  store i64 %ptr1433, ptr %slot12, align 8
  %mem1434 = alloca i8, i64 8, align 8
  %ptr1435 = ptrtoint ptr %mem1434 to i64
  store i64 %ptr1435, ptr %slot13, align 8
  %mem1436 = alloca i8, i64 8, align 8
  %ptr1437 = ptrtoint ptr %mem1436 to i64
  store i64 %ptr1437, ptr %slot14, align 8
  %mem1438 = alloca i8, i64 8, align 8
  %ptr1439 = ptrtoint ptr %mem1438 to i64
  store i64 %ptr1439, ptr %slot15, align 8
  %mem1440 = alloca i8, i64 8, align 8
  %ptr1441 = ptrtoint ptr %mem1440 to i64
  store i64 %ptr1441, ptr %slot16, align 8
  %mem1442 = alloca i8, i64 8, align 8
  %ptr1443 = ptrtoint ptr %mem1442 to i64
  store i64 %ptr1443, ptr %slot17, align 8
  %mem1444 = alloca i8, i64 8, align 8
  %ptr1445 = ptrtoint ptr %mem1444 to i64
  store i64 %ptr1445, ptr %slot18, align 8
  %mem1446 = alloca i8, i64 8, align 8
  %ptr1447 = ptrtoint ptr %mem1446 to i64
  store i64 %ptr1447, ptr %slot19, align 8
  %mem1448 = alloca i8, i64 8, align 8
  %ptr1449 = ptrtoint ptr %mem1448 to i64
  store i64 %ptr1449, ptr %slot20, align 8
  %mem1450 = alloca i8, i64 8, align 8
  %ptr1451 = ptrtoint ptr %mem1450 to i64
  store i64 %ptr1451, ptr %slot21, align 8
  %mem1452 = alloca i8, i64 8, align 8
  %ptr1453 = ptrtoint ptr %mem1452 to i64
  store i64 %ptr1453, ptr %slot22, align 8
  %mem1454 = alloca i8, i64 8, align 8
  %ptr1455 = ptrtoint ptr %mem1454 to i64
  store i64 %ptr1455, ptr %slot23, align 8
  %mem1456 = alloca i8, i64 8, align 8
  %ptr1457 = ptrtoint ptr %mem1456 to i64
  store i64 %ptr1457, ptr %slot24, align 8
  %mem1458 = alloca i8, i64 40, align 8
  %ptr1459 = ptrtoint ptr %mem1458 to i64
  store i64 %ptr1459, ptr %slot25, align 8
  %mem1460 = alloca i8, i64 32, align 8
  %ptr1461 = ptrtoint ptr %mem1460 to i64
  store i64 %ptr1461, ptr %slot26, align 8
  %mem1462 = alloca i8, i64 8, align 8
  %ptr1463 = ptrtoint ptr %mem1462 to i64
  store i64 %ptr1463, ptr %slot27, align 8
  %mem1464 = alloca i8, i64 8, align 8
  %ptr1465 = ptrtoint ptr %mem1464 to i64
  store i64 %ptr1465, ptr %slot28, align 8
  %mem1466 = alloca i8, i64 40, align 8
  %ptr1467 = ptrtoint ptr %mem1466 to i64
  store i64 %ptr1467, ptr %slot29, align 8
  %mem1468 = alloca i8, i64 8, align 8
  %ptr1469 = ptrtoint ptr %mem1468 to i64
  store i64 %ptr1469, ptr %slot30, align 8
  %mem1470 = alloca i8, i64 8, align 8
  %ptr1471 = ptrtoint ptr %mem1470 to i64
  store i64 %ptr1471, ptr %slot31, align 8
  %mem1472 = alloca i8, i64 8, align 8
  %ptr1473 = ptrtoint ptr %mem1472 to i64
  store i64 %ptr1473, ptr %slot32, align 8
  %mem1474 = alloca i8, i64 8, align 8
  %ptr1475 = ptrtoint ptr %mem1474 to i64
  store i64 %ptr1475, ptr %slot33, align 8
  %mem1476 = alloca i8, i64 32, align 8
  %ptr1477 = ptrtoint ptr %mem1476 to i64
  store i64 %ptr1477, ptr %slot34, align 8
  %mem1478 = alloca i8, i64 32, align 8
  %ptr1479 = ptrtoint ptr %mem1478 to i64
  store i64 %ptr1479, ptr %slot35, align 8
  %mem1480 = alloca i8, i64 8, align 8
  %ptr1481 = ptrtoint ptr %mem1480 to i64
  store i64 %ptr1481, ptr %slot36, align 8
  %mem1482 = alloca i8, i64 32, align 8
  %ptr1483 = ptrtoint ptr %mem1482 to i64
  store i64 %ptr1483, ptr %slot37, align 8
  %mem1484 = alloca i8, i64 32, align 8
  %ptr1485 = ptrtoint ptr %mem1484 to i64
  store i64 %ptr1485, ptr %slot38, align 8
  %mem1486 = alloca i8, i64 32, align 8
  %ptr1487 = ptrtoint ptr %mem1486 to i64
  store i64 %ptr1487, ptr %slot39, align 8
  %mem1488 = alloca i8, i64 8, align 8
  %ptr1489 = ptrtoint ptr %mem1488 to i64
  store i64 %ptr1489, ptr %slot40, align 8
  %mem1490 = alloca i8, i64 32, align 8
  %ptr1491 = ptrtoint ptr %mem1490 to i64
  store i64 %ptr1491, ptr %slot41, align 8
  %mem1492 = alloca i8, i64 32, align 8
  %ptr1493 = ptrtoint ptr %mem1492 to i64
  store i64 %ptr1493, ptr %slot42, align 8
  %mem1494 = alloca i8, i64 8, align 8
  %ptr1495 = ptrtoint ptr %mem1494 to i64
  store i64 %ptr1495, ptr %slot43, align 8
  %mem1496 = alloca i8, i64 8, align 8
  %ptr1497 = ptrtoint ptr %mem1496 to i64
  store i64 %ptr1497, ptr %slot44, align 8
  %mem1498 = alloca i8, i64 8, align 8
  %ptr1499 = ptrtoint ptr %mem1498 to i64
  store i64 %ptr1499, ptr %slot45, align 8
  %mem1500 = alloca i8, i64 8, align 8
  %ptr1501 = ptrtoint ptr %mem1500 to i64
  store i64 %ptr1501, ptr %slot46, align 8
  %mem1502 = alloca i8, i64 32, align 8
  %ptr1503 = ptrtoint ptr %mem1502 to i64
  store i64 %ptr1503, ptr %slot47, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1504 = alloca i8, i64 8, align 8
  %ptr1505 = ptrtoint ptr %mem1504 to i64
  store i64 %ptr1505, ptr %slot48, align 8
  %v1506 = load i64, ptr %slot1, align 8
  %op1507 = add i64 %v1506, 64
  store i64 %op1507, ptr %slot49, align 8
  %v1508 = load i64, ptr %slot49, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %ld1510 = load i64, ptr %p1509, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1510, ptr %slot50, align 8
  %stack1511 = call ptr @llvm.stacksave()
  %stackaddr1512 = ptrtoint ptr %stack1511 to i64
  %v1513 = load i64, ptr %slot50, align 8
  %cmp1514 = icmp ult i64 %stackaddr1512, %v1513
  %cv1515 = zext i1 %cmp1514 to i64
  store i64 %cv1515, ptr %slot51, align 8
  %v1516 = load i64, ptr %slot51, align 8
  %cond1517 = icmp ne i64 %v1516, 0
  br i1 %cond1517, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1518 = load i64, ptr %slot1, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  call void @myl_qbe_fail_frame(ptr %p1519) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1520 = load i64, ptr %slot2, align 8
  %v1521 = load i64, ptr %slot30, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  store i64 %v1520, ptr %p1522, align 8, !alias.scope !3, !noalias !4
  %v1523 = load i64, ptr %slot1, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  %call1525 = call ptr @myl_qbe_heap(ptr %p1524) nomerge, !dbg !112
  %calladdr1526 = ptrtoint ptr %call1525 to i64
  store i64 %calladdr1526, ptr %slot52, align 8
  %v1527 = load i64, ptr %slot1, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  %call1529 = call i64 @myl_qbe_region_mark(ptr %p1528) nomerge, !dbg !112
  store i64 %call1529, ptr %slot53, align 8
  %v1530 = load i64, ptr %slot5, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  store i32 0, ptr %p1531, align 4, !alias.scope !3, !noalias !4
  %v1532 = load i64, ptr %slot6, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  store i32 0, ptr %p1533, align 4, !alias.scope !3, !noalias !4
  %v1534 = load i64, ptr %slot7, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  store i32 0, ptr %p1535, align 4, !alias.scope !3, !noalias !4
  %v1536 = load i64, ptr %slot8, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  store i32 0, ptr %p1537, align 4, !alias.scope !3, !noalias !4
  %v1538 = load i64, ptr %slot9, align 8
  %p1539 = inttoptr i64 %v1538 to ptr
  store i32 0, ptr %p1539, align 4, !alias.scope !3, !noalias !4
  %v1540 = load i64, ptr %slot10, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  store i32 0, ptr %p1541, align 4, !alias.scope !3, !noalias !4
  %v1542 = load i64, ptr %slot11, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  store i32 0, ptr %p1543, align 4, !alias.scope !3, !noalias !4
  %v1544 = load i64, ptr %slot12, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  store i32 0, ptr %p1545, align 4, !alias.scope !3, !noalias !4
  %v1546 = load i64, ptr %slot13, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  store i32 0, ptr %p1547, align 4, !alias.scope !3, !noalias !4
  %v1548 = load i64, ptr %slot14, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  store i32 0, ptr %p1549, align 4, !alias.scope !3, !noalias !4
  %v1550 = load i64, ptr %slot15, align 8
  %p1551 = inttoptr i64 %v1550 to ptr
  store i32 0, ptr %p1551, align 4, !alias.scope !3, !noalias !4
  %v1552 = load i64, ptr %slot16, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  store i32 0, ptr %p1553, align 4, !alias.scope !3, !noalias !4
  %v1554 = load i64, ptr %slot17, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  store i32 0, ptr %p1555, align 4, !alias.scope !3, !noalias !4
  %v1556 = load i64, ptr %slot18, align 8
  %p1557 = inttoptr i64 %v1556 to ptr
  store i32 0, ptr %p1557, align 4, !alias.scope !3, !noalias !4
  %v1558 = load i64, ptr %slot19, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  store i32 0, ptr %p1559, align 4, !alias.scope !3, !noalias !4
  %v1560 = load i64, ptr %slot20, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  store i32 0, ptr %p1561, align 4, !alias.scope !3, !noalias !4
  %v1562 = load i64, ptr %slot21, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  store i32 0, ptr %p1563, align 4, !alias.scope !3, !noalias !4
  %v1564 = load i64, ptr %slot22, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i32 0, ptr %p1565, align 4, !alias.scope !3, !noalias !4
  %v1566 = load i64, ptr %slot23, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  store i32 0, ptr %p1567, align 4, !alias.scope !3, !noalias !4
  %v1568 = load i64, ptr %slot24, align 8
  %p1569 = inttoptr i64 %v1568 to ptr
  store i32 0, ptr %p1569, align 4, !alias.scope !3, !noalias !4
  %v1570 = load i64, ptr %slot6, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  store i32 2, ptr %p1571, align 4, !alias.scope !3, !noalias !4
  %v1572 = load i64, ptr %slot8, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i32 2, ptr %p1573, align 4, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot10, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i32 2, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot12, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  store i32 2, ptr %p1577, align 4, !alias.scope !3, !noalias !4
  %v1578 = load i64, ptr %slot14, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  store i32 2, ptr %p1579, align 4, !alias.scope !3, !noalias !4
  %v1580 = load i64, ptr %slot16, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  store i32 2, ptr %p1581, align 4, !alias.scope !3, !noalias !4
  %v1582 = load i64, ptr %slot18, align 8
  %p1583 = inttoptr i64 %v1582 to ptr
  store i32 2, ptr %p1583, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1584 = load i64, ptr %slot30, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %ld1586 = load i64, ptr %p1585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1586, ptr %slot54, align 8
  %v1587 = load i64, ptr %slot54, align 8
  %v1588 = load i64, ptr %slot44, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  store i64 %v1587, ptr %p1589, align 8, !alias.scope !3, !noalias !4
  %v1590 = load i64, ptr %slot44, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  %ld1592 = load i64, ptr %p1591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1592, ptr %slot55, align 8
  %v1593 = load i64, ptr %slot19, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  %ld1595 = load i32, ptr %p1594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1595, ptr %slot56, align 8
  %v1596 = load i64, ptr %slot20, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %ld1598 = load i32, ptr %p1597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1598, ptr %slot57, align 8
  %v1599 = load i32, ptr %slot57, align 8
  %op1600 = and i32 %v1599, 24
  store i32 %op1600, ptr %slot57, align 8
  %v1601 = load i32, ptr %slot57, align 8
  %cmp1602 = icmp eq i32 %v1601, 0
  %cv1603 = zext i1 %cmp1602 to i32
  store i32 %cv1603, ptr %slot58, align 8
  %v1604 = load i32, ptr %slot56, align 8
  %v1605 = load i32, ptr %slot58, align 8
  %op1606 = and i32 %v1604, %v1605
  store i32 %op1606, ptr %slot59, align 8
  %v1607 = load i32, ptr %slot59, align 8
  %cv1608 = zext i32 %v1607 to i64
  %cond1609 = icmp ne i64 %cv1608, 0
  br i1 %cond1609, label %bb_rctake20, label %bb_rccopy20
bb_rctake20:
  %v1610 = load i64, ptr %slot29, align 8
  store i64 %v1610, ptr %slot60, align 8
  %v1611 = load i64, ptr %slot53, align 8
  store i64 %v1611, ptr %slot61, align 8
  %v1612 = load i64, ptr %slot55, align 8
  %v1613 = load i64, ptr %slot60, align 8
  %op1614 = sub i64 %v1612, %v1613
  store i64 %op1614, ptr %slot62, align 8
  %v1615 = load i64, ptr %slot60, align 8
  %v1616 = load i64, ptr %slot55, align 8
  %op1617 = sub i64 %v1615, %v1616
  store i64 %op1617, ptr %slot63, align 8
  %v1618 = load i64, ptr %slot62, align 8
  %cmp1619 = icmp ult i64 %v1618, 32
  %cv1620 = zext i1 %cmp1619 to i32
  store i32 %cv1620, ptr %slot64, align 8
  %v1621 = load i64, ptr %slot63, align 8
  %cmp1622 = icmp ult i64 %v1621, 32
  %cv1623 = zext i1 %cmp1622 to i32
  store i32 %cv1623, ptr %slot65, align 8
  %v1624 = load i32, ptr %slot64, align 8
  %v1625 = load i32, ptr %slot65, align 8
  %op1626 = or i32 %v1624, %v1625
  store i32 %op1626, ptr %slot66, align 8
  %v1627 = load i32, ptr %slot66, align 8
  %cv1628 = zext i32 %v1627 to i64
  %cond1629 = icmp ne i64 %cv1628, 0
  br i1 %cond1629, label %bb_rcmoveslow29, label %bb_rcmovecheck29
bb_rcmovecheck29:
  %v1630 = load i64, ptr %slot55, align 8
  %op1631 = add i64 %v1630, 0
  store i64 %op1631, ptr %slot67, align 8
  %v1632 = load i64, ptr %slot67, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i64, ptr %p1633, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1634, ptr %slot68, align 8
  %v1635 = load i64, ptr %slot68, align 8
  %cmp1636 = icmp ne i64 %v1635, 0
  %cv1637 = zext i1 %cmp1636 to i32
  store i32 %cv1637, ptr %slot69, align 8
  %v1638 = load i32, ptr %slot69, align 8
  %cv1639 = zext i32 %v1638 to i64
  %cond1640 = icmp ne i64 %cv1639, 0
  br i1 %cond1640, label %bb_rcmoveheader37, label %bb_rcmovenext37
bb_rcmoveheader37:
  %v1641 = load i64, ptr %slot68, align 8
  %op1642 = sub i64 %v1641, 16
  store i64 %op1642, ptr %slot70, align 8
  %v1643 = load i64, ptr %slot68, align 8
  %p1644 = inttoptr i64 %v1643 to ptr
  %rgep1645 = getelementptr i8, ptr %p1644, i64 -16
  %ld1646 = load i64, ptr %rgep1645, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1646, ptr %slot71, align 8
  %v1647 = load i64, ptr %slot71, align 8
  %op1648 = and i64 %v1647, 5764607523034234881
  store i64 %op1648, ptr %slot72, align 8
  %v1649 = load i64, ptr %slot72, align 8
  %cmp1650 = icmp ne i64 %v1649, 0
  %cv1651 = zext i1 %cmp1650 to i32
  store i32 %cv1651, ptr %slot73, align 8
  %v1652 = load i32, ptr %slot73, align 8
  %cv1653 = zext i32 %v1652 to i64
  %cond1654 = icmp ne i64 %cv1653, 0
  br i1 %cond1654, label %bb_rcmoveslow29, label %bb_rcmovenext37
bb_rcmovenext37:
  %v1655 = load i64, ptr %slot55, align 8
  %v1656 = load i64, ptr %slot60, align 8
  %p1657 = inttoptr i64 %v1655 to ptr
  %p1658 = inttoptr i64 %v1656 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1658, ptr %p1657, i64 32, i1 false), !alias.scope !10000000
  %v1659 = load i64, ptr %slot55, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i64 0, ptr %p1660, align 8, !alias.scope !4, !noalias !3
  %v1661 = load i64, ptr %slot55, align 8
  %op1662 = add i64 %v1661, 8
  store i64 %op1662, ptr %slot74, align 8
  %v1663 = load i64, ptr %slot74, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  store i64 0, ptr %p1664, align 8, !alias.scope !4, !noalias !3
  %v1665 = load i64, ptr %slot55, align 8
  %op1666 = add i64 %v1665, 16
  store i64 %op1666, ptr %slot75, align 8
  %v1667 = load i64, ptr %slot75, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  store i64 0, ptr %p1668, align 8, !alias.scope !4, !noalias !3
  %v1669 = load i64, ptr %slot55, align 8
  %op1670 = add i64 %v1669, 24
  store i64 %op1670, ptr %slot76, align 8
  %v1671 = load i64, ptr %slot76, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  store i64 0, ptr %p1672, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved29
bb_rcmoveslow29:
  %v1673 = load i64, ptr %slot52, align 8
  %v1674 = load i64, ptr %slot60, align 8
  %v1675 = load i64, ptr %slot55, align 8
  %v1676 = load i64, ptr %slot61, align 8
  %cv1677 = trunc i64 %v1676 to i32
  %call1678 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v1673, i64 %v1674, i64 %v1675, i32 %cv1677) nomerge, !dbg !114
  store i32 %call1678, ptr %slot77, align 8
  %v1679 = load i32, ptr %slot77, align 8
  %cv1680 = zext i32 %v1679 to i64
  %cond1681 = icmp ne i64 %cv1680, 0
  br i1 %cond1681, label %bb_rcsuccess47, label %bb_rcfailure47
bb_rcfailure47:
  %v1682 = load i64, ptr %slot52, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  %call1684 = call i32 @myl_rc_take_failure(ptr %p1683) nomerge, !dbg !114
  store i32 %call1684, ptr %slot78, align 8
  %v1685 = load i64, ptr %slot1, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %v1687 = load i32, ptr %slot78, align 8
  %call1688 = call i32 @myl_qbe_rc_status(ptr %p1686, i32 %v1687) nomerge, !dbg !114
  store i32 %call1688, ptr %slot79, align 8
  br label %bb_failure
bb_rcsuccess47:
  br label %bb_rcmoved29
bb_rcmoved29:
  %v1689 = load i64, ptr %slot19, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i32 0, ptr %p1690, align 4, !alias.scope !3, !noalias !4
  %v1691 = load i64, ptr %slot24, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  store i32 2, ptr %p1692, align 4, !alias.scope !3, !noalias !4
  %v1693 = load i64, ptr %slot23, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i32 1, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared20
bb_rccopy20:
  %v1695 = load i64, ptr %slot29, align 8
  store i64 %v1695, ptr %slot80, align 8
  %v1696 = load i64, ptr %slot53, align 8
  store i64 %v1696, ptr %slot81, align 8
  %v1697 = load i64, ptr %slot52, align 8
  %v1698 = load i64, ptr %slot80, align 8
  %v1699 = load i64, ptr %slot55, align 8
  %v1700 = load i64, ptr %slot81, align 8
  %cv1701 = trunc i64 %v1700 to i32
  %call1702 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v1697, i64 %v1698, i64 %v1699, i32 %cv1701) nomerge, !dbg !114
  store i32 %call1702, ptr %slot82, align 8
  %v1703 = load i32, ptr %slot82, align 8
  %cv1704 = zext i32 %v1703 to i64
  %cond1705 = icmp ne i64 %cv1704, 0
  br i1 %cond1705, label %bb_rcsuccess56, label %bb_rcfailure56
bb_rcfailure56:
  %v1706 = load i64, ptr %slot52, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  %call1708 = call i32 @myl_rc_take_failure(ptr %p1707) nomerge, !dbg !114
  store i32 %call1708, ptr %slot83, align 8
  %v1709 = load i64, ptr %slot1, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %v1711 = load i32, ptr %slot83, align 8
  %call1712 = call i32 @myl_qbe_rc_status(ptr %p1710, i32 %v1711) nomerge, !dbg !114
  store i32 %call1712, ptr %slot84, align 8
  br label %bb_failure
bb_rcsuccess56:
  %v1713 = load i64, ptr %slot24, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  store i32 2, ptr %p1714, align 4, !alias.scope !3, !noalias !4
  %v1715 = load i64, ptr %slot23, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 1, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot19, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %ld1719 = load i32, ptr %p1718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1719, ptr %slot85, align 8
  %v1720 = load i32, ptr %slot85, align 8
  %cv1721 = zext i32 %v1720 to i64
  %cond1722 = icmp ne i64 %cv1721, 0
  br i1 %cond1722, label %bb_rcslotdrop63, label %bb_rcslotdone63
bb_rcslotdrop63:
  %v1723 = load i64, ptr %slot19, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i32 0, ptr %p1724, align 4, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot25, align 8
  store i64 %v1725, ptr %slot86, align 8
  %v1726 = load i64, ptr %slot20, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  %ld1728 = load i32, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1728, ptr %slot87, align 8
  %v1729 = load i32, ptr %slot87, align 8
  %op1730 = and i32 %v1729, 28
  store i32 %op1730, ptr %slot88, align 8
  %v1731 = load i32, ptr %slot88, align 8
  %cv1732 = zext i32 %v1731 to i64
  %cond1733 = icmp ne i64 %cv1732, 0
  br i1 %cond1733, label %bb_rcslotrole63, label %bb_rcslotowner63
bb_rcslotrole63:
  %v1734 = load i64, ptr %slot52, align 8
  store i64 %v1734, ptr %slot89, align 8
  %v1735 = load i64, ptr %slot89, align 8
  %v1736 = load i64, ptr %slot86, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1735, i64 %v1736) nomerge, !dbg !114
  br label %bb_rcslotdone63
bb_rcslotowner63:
  %v1737 = load i64, ptr %slot86, align 8
  %p1739 = inttoptr i64 %v1737 to ptr
  %gep1740 = getelementptr i8, ptr %p1739, i64 0
  %op1738 = ptrtoint ptr %gep1740 to i64
  store i64 %op1738, ptr %slot90, align 8
  %v1741 = load i64, ptr %slot52, align 8
  store i64 %v1741, ptr %slot91, align 8
  %v1742 = load i64, ptr %slot90, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %ld1744 = load i64, ptr %p1743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1744, ptr %slot92, align 8
  %v1745 = load i64, ptr %slot92, align 8
  %cmp1746 = icmp ne i64 %v1745, 0
  %cv1747 = zext i1 %cmp1746 to i32
  store i32 %cv1747, ptr %slot93, align 8
  %v1748 = load i32, ptr %slot93, align 8
  %cv1749 = zext i32 %v1748 to i64
  %cond1750 = icmp ne i64 %cv1749, 0
  br i1 %cond1750, label %bb_rcgnn81, label %bb_rcgdone81
bb_rcgnn81:
  %v1751 = load i64, ptr %slot92, align 8
  %op1752 = sub i64 %v1751, 16
  store i64 %op1752, ptr %slot94, align 8
  %v1753 = load i64, ptr %slot92, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  %rgep1755 = getelementptr i8, ptr %p1754, i64 -16
  %ld1756 = load i64, ptr %rgep1755, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1756, ptr %slot95, align 8
  %v1757 = load i64, ptr %slot95, align 8
  %op1758 = and i64 %v1757, 4611686018427387906
  store i64 %op1758, ptr %slot96, align 8
  %v1759 = load i64, ptr %slot96, align 8
  %cmp1760 = icmp ne i64 %v1759, 0
  %cv1761 = zext i1 %cmp1760 to i32
  store i32 %cv1761, ptr %slot97, align 8
  %v1762 = load i32, ptr %slot97, align 8
  %cv1763 = zext i32 %v1762 to i64
  %cond1764 = icmp ne i64 %cv1763, 0
  br i1 %cond1764, label %bb_rcgclear81, label %bb_rcgcounted81
bb_rcgcounted81:
  %v1765 = load i64, ptr %slot92, align 8
  %op1766 = sub i64 %v1765, 32
  store i64 %op1766, ptr %slot98, align 8
  %v1767 = load i64, ptr %slot92, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %rgep1769 = getelementptr i8, ptr %p1768, i64 -32
  %ld1770 = load i64, ptr %rgep1769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1770, ptr %slot99, align 8
  %v1771 = load i64, ptr %slot99, align 8
  %op1772 = sub i64 %v1771, 1
  store i64 %op1772, ptr %slot100, align 8
  %v1773 = load i64, ptr %slot100, align 8
  %cmp1774 = icmp eq i64 %v1773, 0
  %cv1775 = zext i1 %cmp1774 to i32
  store i32 %cv1775, ptr %slot101, align 8
  %v1776 = load i32, ptr %slot101, align 8
  %cv1777 = zext i32 %v1776 to i64
  %cond1778 = icmp ne i64 %cv1777, 0
  br i1 %cond1778, label %bb_rcglast81, label %bb_rcgdec81
bb_rcglast81:
  %v1779 = load i64, ptr %slot92, align 8
  %op1780 = sub i64 %v1779, 24
  store i64 %op1780, ptr %slot102, align 8
  %v1781 = load i64, ptr %slot92, align 8
  %p1782 = inttoptr i64 %v1781 to ptr
  %rgep1783 = getelementptr i8, ptr %p1782, i64 -24
  %ld1784 = load i64, ptr %rgep1783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1784, ptr %slot103, align 8
  %v1785 = load i64, ptr %slot103, align 8
  %cmp1786 = icmp ne i64 %v1785, 0
  %cv1787 = zext i1 %cmp1786 to i32
  store i32 %cv1787, ptr %slot104, align 8
  %v1788 = load i32, ptr %slot104, align 8
  %cv1789 = zext i32 %v1788 to i64
  %cond1790 = icmp ne i64 %cv1789, 0
  br i1 %cond1790, label %bb_rcgdec81, label %bb_rcgslow81
bb_rcgslow81:
  %v1791 = load i64, ptr %slot91, align 8
  %v1792 = load i64, ptr %slot90, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1791, i64 %v1792) nomerge, !dbg !114
  br label %bb_rcgdone81
bb_rcgdec81:
  %v1793 = load i64, ptr %slot100, align 8
  %v1794 = load i64, ptr %slot92, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  %rgep1796 = getelementptr i8, ptr %p1795, i64 -32
  store i64 %v1793, ptr %rgep1796, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear81
bb_rcgclear81:
  %v1797 = load i64, ptr %slot90, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  store i64 0, ptr %p1798, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone81
bb_rcgdone81:
  %v1799 = load i64, ptr %slot86, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  store i64 0, ptr %p1800, align 8, !alias.scope !3, !noalias !4
  %v1801 = load i64, ptr %slot86, align 8
  %p1803 = inttoptr i64 %v1801 to ptr
  %gep1804 = getelementptr i8, ptr %p1803, i64 8
  %op1802 = ptrtoint ptr %gep1804 to i64
  store i64 %op1802, ptr %slot105, align 8
  %v1805 = load i64, ptr %slot105, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i64 0, ptr %p1806, align 8, !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot86, align 8
  %p1809 = inttoptr i64 %v1807 to ptr
  %gep1810 = getelementptr i8, ptr %p1809, i64 16
  %op1808 = ptrtoint ptr %gep1810 to i64
  store i64 %op1808, ptr %slot106, align 8
  %v1811 = load i64, ptr %slot106, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  store i64 0, ptr %p1812, align 8, !alias.scope !3, !noalias !4
  %v1813 = load i64, ptr %slot86, align 8
  %p1815 = inttoptr i64 %v1813 to ptr
  %gep1816 = getelementptr i8, ptr %p1815, i64 24
  %op1814 = ptrtoint ptr %gep1816 to i64
  store i64 %op1814, ptr %slot107, align 8
  %v1817 = load i64, ptr %slot107, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i64 0, ptr %p1818, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone63
bb_rcslotdone63:
  br label %bb_rcprepared20
bb_rcprepared20:
  %v1819 = load i64, ptr %slot5, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  %ld1821 = load i32, ptr %p1820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1821, ptr %slot108, align 8
  %v1822 = load i32, ptr %slot108, align 8
  %cv1823 = zext i32 %v1822 to i64
  %cond1824 = icmp ne i64 %cv1823, 0
  br i1 %cond1824, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v1825 = load i64, ptr %slot5, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  store i32 0, ptr %p1826, align 4, !alias.scope !3, !noalias !4
  %v1827 = load i64, ptr %slot34, align 8
  store i64 %v1827, ptr %slot109, align 8
  %v1828 = load i64, ptr %slot6, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  %ld1830 = load i32, ptr %p1829, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1830, ptr %slot110, align 8
  %v1831 = load i32, ptr %slot110, align 8
  %op1832 = and i32 %v1831, 28
  store i32 %op1832, ptr %slot111, align 8
  %v1833 = load i32, ptr %slot111, align 8
  %cv1834 = zext i32 %v1833 to i64
  %cond1835 = icmp ne i64 %cv1834, 0
  br i1 %cond1835, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v1836 = load i64, ptr %slot52, align 8
  store i64 %v1836, ptr %slot112, align 8
  %v1837 = load i64, ptr %slot112, align 8
  %v1838 = load i64, ptr %slot109, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1837, i64 %v1838) nomerge, !dbg !114
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v1839 = load i64, ptr %slot109, align 8
  %p1841 = inttoptr i64 %v1839 to ptr
  %gep1842 = getelementptr i8, ptr %p1841, i64 0
  %op1840 = ptrtoint ptr %gep1842 to i64
  store i64 %op1840, ptr %slot113, align 8
  %v1843 = load i64, ptr %slot52, align 8
  store i64 %v1843, ptr %slot114, align 8
  %v1844 = load i64, ptr %slot113, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  %ld1846 = load i64, ptr %p1845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1846, ptr %slot115, align 8
  %v1847 = load i64, ptr %slot115, align 8
  %cmp1848 = icmp ne i64 %v1847, 0
  %cv1849 = zext i1 %cmp1848 to i32
  store i32 %cv1849, ptr %slot116, align 8
  %v1850 = load i32, ptr %slot116, align 8
  %cv1851 = zext i32 %v1850 to i64
  %cond1852 = icmp ne i64 %cv1851, 0
  br i1 %cond1852, label %bb_rcgnn109, label %bb_rcgdone109
bb_rcgnn109:
  %v1853 = load i64, ptr %slot115, align 8
  %op1854 = sub i64 %v1853, 16
  store i64 %op1854, ptr %slot117, align 8
  %v1855 = load i64, ptr %slot115, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %rgep1857 = getelementptr i8, ptr %p1856, i64 -16
  %ld1858 = load i64, ptr %rgep1857, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1858, ptr %slot118, align 8
  %v1859 = load i64, ptr %slot118, align 8
  %op1860 = and i64 %v1859, 4611686018427387906
  store i64 %op1860, ptr %slot119, align 8
  %v1861 = load i64, ptr %slot119, align 8
  %cmp1862 = icmp ne i64 %v1861, 0
  %cv1863 = zext i1 %cmp1862 to i32
  store i32 %cv1863, ptr %slot120, align 8
  %v1864 = load i32, ptr %slot120, align 8
  %cv1865 = zext i32 %v1864 to i64
  %cond1866 = icmp ne i64 %cv1865, 0
  br i1 %cond1866, label %bb_rcgclear109, label %bb_rcgcounted109
bb_rcgcounted109:
  %v1867 = load i64, ptr %slot115, align 8
  %op1868 = sub i64 %v1867, 32
  store i64 %op1868, ptr %slot121, align 8
  %v1869 = load i64, ptr %slot115, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  %rgep1871 = getelementptr i8, ptr %p1870, i64 -32
  %ld1872 = load i64, ptr %rgep1871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1872, ptr %slot122, align 8
  %v1873 = load i64, ptr %slot122, align 8
  %op1874 = sub i64 %v1873, 1
  store i64 %op1874, ptr %slot123, align 8
  %v1875 = load i64, ptr %slot123, align 8
  %cmp1876 = icmp eq i64 %v1875, 0
  %cv1877 = zext i1 %cmp1876 to i32
  store i32 %cv1877, ptr %slot124, align 8
  %v1878 = load i32, ptr %slot124, align 8
  %cv1879 = zext i32 %v1878 to i64
  %cond1880 = icmp ne i64 %cv1879, 0
  br i1 %cond1880, label %bb_rcglast109, label %bb_rcgdec109
bb_rcglast109:
  %v1881 = load i64, ptr %slot115, align 8
  %op1882 = sub i64 %v1881, 24
  store i64 %op1882, ptr %slot125, align 8
  %v1883 = load i64, ptr %slot115, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  %rgep1885 = getelementptr i8, ptr %p1884, i64 -24
  %ld1886 = load i64, ptr %rgep1885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1886, ptr %slot126, align 8
  %v1887 = load i64, ptr %slot126, align 8
  %cmp1888 = icmp ne i64 %v1887, 0
  %cv1889 = zext i1 %cmp1888 to i32
  store i32 %cv1889, ptr %slot127, align 8
  %v1890 = load i32, ptr %slot127, align 8
  %cv1891 = zext i32 %v1890 to i64
  %cond1892 = icmp ne i64 %cv1891, 0
  br i1 %cond1892, label %bb_rcgdec109, label %bb_rcgslow109
bb_rcgslow109:
  %v1893 = load i64, ptr %slot114, align 8
  %v1894 = load i64, ptr %slot113, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1893, i64 %v1894) nomerge, !dbg !114
  br label %bb_rcgdone109
bb_rcgdec109:
  %v1895 = load i64, ptr %slot123, align 8
  %v1896 = load i64, ptr %slot115, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %rgep1898 = getelementptr i8, ptr %p1897, i64 -32
  store i64 %v1895, ptr %rgep1898, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear109
bb_rcgclear109:
  %v1899 = load i64, ptr %slot113, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  store i64 0, ptr %p1900, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone109
bb_rcgdone109:
  %v1901 = load i64, ptr %slot109, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  store i64 0, ptr %p1902, align 8, !alias.scope !3, !noalias !4
  %v1903 = load i64, ptr %slot109, align 8
  %p1905 = inttoptr i64 %v1903 to ptr
  %gep1906 = getelementptr i8, ptr %p1905, i64 8
  %op1904 = ptrtoint ptr %gep1906 to i64
  store i64 %op1904, ptr %slot128, align 8
  %v1907 = load i64, ptr %slot128, align 8
  %p1908 = inttoptr i64 %v1907 to ptr
  store i64 0, ptr %p1908, align 8, !alias.scope !3, !noalias !4
  %v1909 = load i64, ptr %slot109, align 8
  %p1911 = inttoptr i64 %v1909 to ptr
  %gep1912 = getelementptr i8, ptr %p1911, i64 16
  %op1910 = ptrtoint ptr %gep1912 to i64
  store i64 %op1910, ptr %slot129, align 8
  %v1913 = load i64, ptr %slot129, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  store i64 0, ptr %p1914, align 8, !alias.scope !3, !noalias !4
  %v1915 = load i64, ptr %slot109, align 8
  %p1917 = inttoptr i64 %v1915 to ptr
  %gep1918 = getelementptr i8, ptr %p1917, i64 24
  %op1916 = ptrtoint ptr %gep1918 to i64
  store i64 %op1916, ptr %slot130, align 8
  %v1919 = load i64, ptr %slot130, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  store i64 0, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v1921 = load i64, ptr %slot34, align 8
  store i64 %v1921, ptr %slot131, align 8
  %v1922 = load i64, ptr %slot29, align 8
  store i64 %v1922, ptr %slot132, align 8
  %v1923 = load i64, ptr %slot132, align 8
  %v1924 = load i64, ptr %slot131, align 8
  %p1925 = inttoptr i64 %v1923 to ptr
  %p1926 = inttoptr i64 %v1924 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1926, ptr %p1925, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1927 = load i64, ptr %slot23, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  store i32 0, ptr %p1928, align 4, !alias.scope !3, !noalias !4
  %v1929 = load i64, ptr %slot6, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  store i32 2, ptr %p1930, align 4, !alias.scope !3, !noalias !4
  %v1931 = load i64, ptr %slot24, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  %ld1933 = load i32, ptr %p1932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1933, ptr %slot133, align 8
  %v1934 = load i32, ptr %slot133, align 8
  %v1935 = load i64, ptr %slot6, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  store i32 %v1934, ptr %p1936, align 4, !alias.scope !3, !noalias !4
  %v1937 = load i64, ptr %slot5, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  store i32 1, ptr %p1938, align 4, !alias.scope !3, !noalias !4
  %v1939 = load i64, ptr %slot34, align 8
  %v1940 = load i64, ptr %slot44, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  store i64 %v1939, ptr %p1941, align 8, !alias.scope !3, !noalias !4
  %v1942 = load i64, ptr %slot44, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %ld1944 = load i64, ptr %p1943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1944, ptr %slot134, align 8
  %v1945 = load i64, ptr %slot19, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  %ld1947 = load i32, ptr %p1946, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1947, ptr %slot135, align 8
  %v1948 = load i64, ptr %slot20, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  %ld1950 = load i32, ptr %p1949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1950, ptr %slot136, align 8
  %v1951 = load i32, ptr %slot136, align 8
  %op1952 = and i32 %v1951, 24
  store i32 %op1952, ptr %slot136, align 8
  %v1953 = load i32, ptr %slot136, align 8
  %cmp1954 = icmp eq i32 %v1953, 0
  %cv1955 = zext i1 %cmp1954 to i32
  store i32 %cv1955, ptr %slot137, align 8
  %v1956 = load i32, ptr %slot135, align 8
  %v1957 = load i32, ptr %slot137, align 8
  %op1958 = and i32 %v1956, %v1957
  store i32 %op1958, ptr %slot138, align 8
  %v1959 = load i32, ptr %slot138, align 8
  %cv1960 = zext i32 %v1959 to i64
  %cond1961 = icmp ne i64 %cv1960, 0
  br i1 %cond1961, label %bb_rctake124, label %bb_rccopy124
bb_rctake124:
  %v1962 = load i64, ptr %slot29, align 8
  store i64 %v1962, ptr %slot139, align 8
  %v1963 = load i64, ptr %slot53, align 8
  store i64 %v1963, ptr %slot140, align 8
  %v1964 = load i64, ptr %slot134, align 8
  %v1965 = load i64, ptr %slot139, align 8
  %op1966 = sub i64 %v1964, %v1965
  store i64 %op1966, ptr %slot141, align 8
  %v1967 = load i64, ptr %slot139, align 8
  %v1968 = load i64, ptr %slot134, align 8
  %op1969 = sub i64 %v1967, %v1968
  store i64 %op1969, ptr %slot142, align 8
  %v1970 = load i64, ptr %slot141, align 8
  %cmp1971 = icmp ult i64 %v1970, 32
  %cv1972 = zext i1 %cmp1971 to i32
  store i32 %cv1972, ptr %slot143, align 8
  %v1973 = load i64, ptr %slot142, align 8
  %cmp1974 = icmp ult i64 %v1973, 32
  %cv1975 = zext i1 %cmp1974 to i32
  store i32 %cv1975, ptr %slot144, align 8
  %v1976 = load i32, ptr %slot143, align 8
  %v1977 = load i32, ptr %slot144, align 8
  %op1978 = or i32 %v1976, %v1977
  store i32 %op1978, ptr %slot145, align 8
  %v1979 = load i32, ptr %slot145, align 8
  %cv1980 = zext i32 %v1979 to i64
  %cond1981 = icmp ne i64 %cv1980, 0
  br i1 %cond1981, label %bb_rcmoveslow133, label %bb_rcmovecheck133
bb_rcmovecheck133:
  %v1982 = load i64, ptr %slot134, align 8
  %op1983 = add i64 %v1982, 0
  store i64 %op1983, ptr %slot146, align 8
  %v1984 = load i64, ptr %slot146, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  %ld1986 = load i64, ptr %p1985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1986, ptr %slot147, align 8
  %v1987 = load i64, ptr %slot147, align 8
  %cmp1988 = icmp ne i64 %v1987, 0
  %cv1989 = zext i1 %cmp1988 to i32
  store i32 %cv1989, ptr %slot148, align 8
  %v1990 = load i32, ptr %slot148, align 8
  %cv1991 = zext i32 %v1990 to i64
  %cond1992 = icmp ne i64 %cv1991, 0
  br i1 %cond1992, label %bb_rcmoveheader141, label %bb_rcmovenext141
bb_rcmoveheader141:
  %v1993 = load i64, ptr %slot147, align 8
  %op1994 = sub i64 %v1993, 16
  store i64 %op1994, ptr %slot149, align 8
  %v1995 = load i64, ptr %slot147, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  %rgep1997 = getelementptr i8, ptr %p1996, i64 -16
  %ld1998 = load i64, ptr %rgep1997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1998, ptr %slot150, align 8
  %v1999 = load i64, ptr %slot150, align 8
  %op2000 = and i64 %v1999, 5764607523034234881
  store i64 %op2000, ptr %slot151, align 8
  %v2001 = load i64, ptr %slot151, align 8
  %cmp2002 = icmp ne i64 %v2001, 0
  %cv2003 = zext i1 %cmp2002 to i32
  store i32 %cv2003, ptr %slot152, align 8
  %v2004 = load i32, ptr %slot152, align 8
  %cv2005 = zext i32 %v2004 to i64
  %cond2006 = icmp ne i64 %cv2005, 0
  br i1 %cond2006, label %bb_rcmoveslow133, label %bb_rcmovenext141
bb_rcmovenext141:
  %v2007 = load i64, ptr %slot134, align 8
  %v2008 = load i64, ptr %slot139, align 8
  %p2009 = inttoptr i64 %v2007 to ptr
  %p2010 = inttoptr i64 %v2008 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2010, ptr %p2009, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot134, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  store i64 0, ptr %p2012, align 8, !alias.scope !3, !noalias !4
  %v2013 = load i64, ptr %slot134, align 8
  %op2014 = add i64 %v2013, 8
  store i64 %op2014, ptr %slot153, align 8
  %v2015 = load i64, ptr %slot153, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  store i64 0, ptr %p2016, align 8, !alias.scope !3, !noalias !4
  %v2017 = load i64, ptr %slot134, align 8
  %op2018 = add i64 %v2017, 16
  store i64 %op2018, ptr %slot154, align 8
  %v2019 = load i64, ptr %slot154, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  store i64 0, ptr %p2020, align 8, !alias.scope !3, !noalias !4
  %v2021 = load i64, ptr %slot134, align 8
  %op2022 = add i64 %v2021, 24
  store i64 %op2022, ptr %slot155, align 8
  %v2023 = load i64, ptr %slot155, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i64 0, ptr %p2024, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved133
bb_rcmoveslow133:
  %v2025 = load i64, ptr %slot52, align 8
  %v2026 = load i64, ptr %slot139, align 8
  %v2027 = load i64, ptr %slot134, align 8
  %v2028 = load i64, ptr %slot140, align 8
  %cv2029 = trunc i64 %v2028 to i32
  %call2030 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v2025, i64 %v2026, i64 %v2027, i32 %cv2029) nomerge, !dbg !116
  store i32 %call2030, ptr %slot156, align 8
  %v2031 = load i32, ptr %slot156, align 8
  %cv2032 = zext i32 %v2031 to i64
  %cond2033 = icmp ne i64 %cv2032, 0
  br i1 %cond2033, label %bb_rcsuccess151, label %bb_rcfailure151
bb_rcfailure151:
  %v2034 = load i64, ptr %slot52, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %call2036 = call i32 @myl_rc_take_failure(ptr %p2035) nomerge, !dbg !116
  store i32 %call2036, ptr %slot157, align 8
  %v2037 = load i64, ptr %slot1, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  %v2039 = load i32, ptr %slot157, align 8
  %call2040 = call i32 @myl_qbe_rc_status(ptr %p2038, i32 %v2039) nomerge, !dbg !116
  store i32 %call2040, ptr %slot158, align 8
  br label %bb_failure
bb_rcsuccess151:
  br label %bb_rcmoved133
bb_rcmoved133:
  %v2041 = load i64, ptr %slot19, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  store i32 0, ptr %p2042, align 4, !alias.scope !3, !noalias !4
  %v2043 = load i64, ptr %slot24, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  store i32 2, ptr %p2044, align 4, !alias.scope !3, !noalias !4
  %v2045 = load i64, ptr %slot23, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  store i32 1, ptr %p2046, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared124
bb_rccopy124:
  %v2047 = load i64, ptr %slot29, align 8
  store i64 %v2047, ptr %slot159, align 8
  %v2048 = load i64, ptr %slot53, align 8
  store i64 %v2048, ptr %slot160, align 8
  %v2049 = load i64, ptr %slot52, align 8
  %v2050 = load i64, ptr %slot159, align 8
  %v2051 = load i64, ptr %slot134, align 8
  %v2052 = load i64, ptr %slot160, align 8
  %cv2053 = trunc i64 %v2052 to i32
  %call2054 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v2049, i64 %v2050, i64 %v2051, i32 %cv2053) nomerge, !dbg !116
  store i32 %call2054, ptr %slot161, align 8
  %v2055 = load i32, ptr %slot161, align 8
  %cv2056 = zext i32 %v2055 to i64
  %cond2057 = icmp ne i64 %cv2056, 0
  br i1 %cond2057, label %bb_rcsuccess160, label %bb_rcfailure160
bb_rcfailure160:
  %v2058 = load i64, ptr %slot52, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  %call2060 = call i32 @myl_rc_take_failure(ptr %p2059) nomerge, !dbg !116
  store i32 %call2060, ptr %slot162, align 8
  %v2061 = load i64, ptr %slot1, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %v2063 = load i32, ptr %slot162, align 8
  %call2064 = call i32 @myl_qbe_rc_status(ptr %p2062, i32 %v2063) nomerge, !dbg !116
  store i32 %call2064, ptr %slot163, align 8
  br label %bb_failure
bb_rcsuccess160:
  %v2065 = load i64, ptr %slot24, align 8
  %p2066 = inttoptr i64 %v2065 to ptr
  store i32 2, ptr %p2066, align 4, !alias.scope !3, !noalias !4
  %v2067 = load i64, ptr %slot23, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  store i32 1, ptr %p2068, align 4, !alias.scope !3, !noalias !4
  %v2069 = load i64, ptr %slot19, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  %ld2071 = load i32, ptr %p2070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2071, ptr %slot164, align 8
  %v2072 = load i32, ptr %slot164, align 8
  %cv2073 = zext i32 %v2072 to i64
  %cond2074 = icmp ne i64 %cv2073, 0
  br i1 %cond2074, label %bb_rcslotdrop167, label %bb_rcslotdone167
bb_rcslotdrop167:
  %v2075 = load i64, ptr %slot19, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  store i32 0, ptr %p2076, align 4, !alias.scope !3, !noalias !4
  %v2077 = load i64, ptr %slot25, align 8
  store i64 %v2077, ptr %slot165, align 8
  %v2078 = load i64, ptr %slot20, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  %ld2080 = load i32, ptr %p2079, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2080, ptr %slot166, align 8
  %v2081 = load i32, ptr %slot166, align 8
  %op2082 = and i32 %v2081, 28
  store i32 %op2082, ptr %slot167, align 8
  %v2083 = load i32, ptr %slot167, align 8
  %cv2084 = zext i32 %v2083 to i64
  %cond2085 = icmp ne i64 %cv2084, 0
  br i1 %cond2085, label %bb_rcslotrole167, label %bb_rcslotowner167
bb_rcslotrole167:
  %v2086 = load i64, ptr %slot52, align 8
  store i64 %v2086, ptr %slot168, align 8
  %v2087 = load i64, ptr %slot168, align 8
  %v2088 = load i64, ptr %slot165, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2087, i64 %v2088) nomerge, !dbg !116
  br label %bb_rcslotdone167
bb_rcslotowner167:
  %v2089 = load i64, ptr %slot165, align 8
  %p2091 = inttoptr i64 %v2089 to ptr
  %gep2092 = getelementptr i8, ptr %p2091, i64 0
  %op2090 = ptrtoint ptr %gep2092 to i64
  store i64 %op2090, ptr %slot169, align 8
  %v2093 = load i64, ptr %slot52, align 8
  store i64 %v2093, ptr %slot170, align 8
  %v2094 = load i64, ptr %slot169, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  %ld2096 = load i64, ptr %p2095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2096, ptr %slot171, align 8
  %v2097 = load i64, ptr %slot171, align 8
  %cmp2098 = icmp ne i64 %v2097, 0
  %cv2099 = zext i1 %cmp2098 to i32
  store i32 %cv2099, ptr %slot172, align 8
  %v2100 = load i32, ptr %slot172, align 8
  %cv2101 = zext i32 %v2100 to i64
  %cond2102 = icmp ne i64 %cv2101, 0
  br i1 %cond2102, label %bb_rcgnn185, label %bb_rcgdone185
bb_rcgnn185:
  %v2103 = load i64, ptr %slot171, align 8
  %op2104 = sub i64 %v2103, 16
  store i64 %op2104, ptr %slot173, align 8
  %v2105 = load i64, ptr %slot171, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  %rgep2107 = getelementptr i8, ptr %p2106, i64 -16
  %ld2108 = load i64, ptr %rgep2107, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2108, ptr %slot174, align 8
  %v2109 = load i64, ptr %slot174, align 8
  %op2110 = and i64 %v2109, 4611686018427387906
  store i64 %op2110, ptr %slot175, align 8
  %v2111 = load i64, ptr %slot175, align 8
  %cmp2112 = icmp ne i64 %v2111, 0
  %cv2113 = zext i1 %cmp2112 to i32
  store i32 %cv2113, ptr %slot176, align 8
  %v2114 = load i32, ptr %slot176, align 8
  %cv2115 = zext i32 %v2114 to i64
  %cond2116 = icmp ne i64 %cv2115, 0
  br i1 %cond2116, label %bb_rcgclear185, label %bb_rcgcounted185
bb_rcgcounted185:
  %v2117 = load i64, ptr %slot171, align 8
  %op2118 = sub i64 %v2117, 32
  store i64 %op2118, ptr %slot177, align 8
  %v2119 = load i64, ptr %slot171, align 8
  %p2120 = inttoptr i64 %v2119 to ptr
  %rgep2121 = getelementptr i8, ptr %p2120, i64 -32
  %ld2122 = load i64, ptr %rgep2121, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2122, ptr %slot178, align 8
  %v2123 = load i64, ptr %slot178, align 8
  %op2124 = sub i64 %v2123, 1
  store i64 %op2124, ptr %slot179, align 8
  %v2125 = load i64, ptr %slot179, align 8
  %cmp2126 = icmp eq i64 %v2125, 0
  %cv2127 = zext i1 %cmp2126 to i32
  store i32 %cv2127, ptr %slot180, align 8
  %v2128 = load i32, ptr %slot180, align 8
  %cv2129 = zext i32 %v2128 to i64
  %cond2130 = icmp ne i64 %cv2129, 0
  br i1 %cond2130, label %bb_rcglast185, label %bb_rcgdec185
bb_rcglast185:
  %v2131 = load i64, ptr %slot171, align 8
  %op2132 = sub i64 %v2131, 24
  store i64 %op2132, ptr %slot181, align 8
  %v2133 = load i64, ptr %slot171, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  %rgep2135 = getelementptr i8, ptr %p2134, i64 -24
  %ld2136 = load i64, ptr %rgep2135, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2136, ptr %slot182, align 8
  %v2137 = load i64, ptr %slot182, align 8
  %cmp2138 = icmp ne i64 %v2137, 0
  %cv2139 = zext i1 %cmp2138 to i32
  store i32 %cv2139, ptr %slot183, align 8
  %v2140 = load i32, ptr %slot183, align 8
  %cv2141 = zext i32 %v2140 to i64
  %cond2142 = icmp ne i64 %cv2141, 0
  br i1 %cond2142, label %bb_rcgdec185, label %bb_rcgslow185
bb_rcgslow185:
  %v2143 = load i64, ptr %slot170, align 8
  %v2144 = load i64, ptr %slot169, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2143, i64 %v2144) nomerge, !dbg !116
  br label %bb_rcgdone185
bb_rcgdec185:
  %v2145 = load i64, ptr %slot179, align 8
  %v2146 = load i64, ptr %slot171, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  %rgep2148 = getelementptr i8, ptr %p2147, i64 -32
  store i64 %v2145, ptr %rgep2148, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear185
bb_rcgclear185:
  %v2149 = load i64, ptr %slot169, align 8
  %p2150 = inttoptr i64 %v2149 to ptr
  store i64 0, ptr %p2150, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone185
bb_rcgdone185:
  %v2151 = load i64, ptr %slot165, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i64 0, ptr %p2152, align 8, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot165, align 8
  %p2155 = inttoptr i64 %v2153 to ptr
  %gep2156 = getelementptr i8, ptr %p2155, i64 8
  %op2154 = ptrtoint ptr %gep2156 to i64
  store i64 %op2154, ptr %slot184, align 8
  %v2157 = load i64, ptr %slot184, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i64 0, ptr %p2158, align 8, !alias.scope !3, !noalias !4
  %v2159 = load i64, ptr %slot165, align 8
  %p2161 = inttoptr i64 %v2159 to ptr
  %gep2162 = getelementptr i8, ptr %p2161, i64 16
  %op2160 = ptrtoint ptr %gep2162 to i64
  store i64 %op2160, ptr %slot185, align 8
  %v2163 = load i64, ptr %slot185, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  store i64 0, ptr %p2164, align 8, !alias.scope !3, !noalias !4
  %v2165 = load i64, ptr %slot165, align 8
  %p2167 = inttoptr i64 %v2165 to ptr
  %gep2168 = getelementptr i8, ptr %p2167, i64 24
  %op2166 = ptrtoint ptr %gep2168 to i64
  store i64 %op2166, ptr %slot186, align 8
  %v2169 = load i64, ptr %slot186, align 8
  %p2170 = inttoptr i64 %v2169 to ptr
  store i64 0, ptr %p2170, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone167
bb_rcslotdone167:
  br label %bb_rcprepared124
bb_rcprepared124:
  %v2171 = load i64, ptr %slot7, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %ld2173 = load i32, ptr %p2172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2173, ptr %slot187, align 8
  %v2174 = load i32, ptr %slot187, align 8
  %cv2175 = zext i32 %v2174 to i64
  %cond2176 = icmp ne i64 %cv2175, 0
  br i1 %cond2176, label %bb_rcslotdrop195, label %bb_rcslotdone195
bb_rcslotdrop195:
  %v2177 = load i64, ptr %slot7, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  store i32 0, ptr %p2178, align 4, !alias.scope !3, !noalias !4
  %v2179 = load i64, ptr %slot35, align 8
  store i64 %v2179, ptr %slot188, align 8
  %v2180 = load i64, ptr %slot8, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  %ld2182 = load i32, ptr %p2181, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2182, ptr %slot189, align 8
  %v2183 = load i32, ptr %slot189, align 8
  %op2184 = and i32 %v2183, 28
  store i32 %op2184, ptr %slot190, align 8
  %v2185 = load i32, ptr %slot190, align 8
  %cv2186 = zext i32 %v2185 to i64
  %cond2187 = icmp ne i64 %cv2186, 0
  br i1 %cond2187, label %bb_rcslotrole195, label %bb_rcslotowner195
bb_rcslotrole195:
  %v2188 = load i64, ptr %slot52, align 8
  store i64 %v2188, ptr %slot191, align 8
  %v2189 = load i64, ptr %slot191, align 8
  %v2190 = load i64, ptr %slot188, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2189, i64 %v2190) nomerge, !dbg !116
  br label %bb_rcslotdone195
bb_rcslotowner195:
  %v2191 = load i64, ptr %slot188, align 8
  %p2193 = inttoptr i64 %v2191 to ptr
  %gep2194 = getelementptr i8, ptr %p2193, i64 0
  %op2192 = ptrtoint ptr %gep2194 to i64
  store i64 %op2192, ptr %slot192, align 8
  %v2195 = load i64, ptr %slot52, align 8
  store i64 %v2195, ptr %slot193, align 8
  %v2196 = load i64, ptr %slot192, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %ld2198 = load i64, ptr %p2197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2198, ptr %slot194, align 8
  %v2199 = load i64, ptr %slot194, align 8
  %cmp2200 = icmp ne i64 %v2199, 0
  %cv2201 = zext i1 %cmp2200 to i32
  store i32 %cv2201, ptr %slot195, align 8
  %v2202 = load i32, ptr %slot195, align 8
  %cv2203 = zext i32 %v2202 to i64
  %cond2204 = icmp ne i64 %cv2203, 0
  br i1 %cond2204, label %bb_rcgnn213, label %bb_rcgdone213
bb_rcgnn213:
  %v2205 = load i64, ptr %slot194, align 8
  %op2206 = sub i64 %v2205, 16
  store i64 %op2206, ptr %slot196, align 8
  %v2207 = load i64, ptr %slot194, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  %rgep2209 = getelementptr i8, ptr %p2208, i64 -16
  %ld2210 = load i64, ptr %rgep2209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2210, ptr %slot197, align 8
  %v2211 = load i64, ptr %slot197, align 8
  %op2212 = and i64 %v2211, 4611686018427387906
  store i64 %op2212, ptr %slot198, align 8
  %v2213 = load i64, ptr %slot198, align 8
  %cmp2214 = icmp ne i64 %v2213, 0
  %cv2215 = zext i1 %cmp2214 to i32
  store i32 %cv2215, ptr %slot199, align 8
  %v2216 = load i32, ptr %slot199, align 8
  %cv2217 = zext i32 %v2216 to i64
  %cond2218 = icmp ne i64 %cv2217, 0
  br i1 %cond2218, label %bb_rcgclear213, label %bb_rcgcounted213
bb_rcgcounted213:
  %v2219 = load i64, ptr %slot194, align 8
  %op2220 = sub i64 %v2219, 32
  store i64 %op2220, ptr %slot200, align 8
  %v2221 = load i64, ptr %slot194, align 8
  %p2222 = inttoptr i64 %v2221 to ptr
  %rgep2223 = getelementptr i8, ptr %p2222, i64 -32
  %ld2224 = load i64, ptr %rgep2223, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2224, ptr %slot201, align 8
  %v2225 = load i64, ptr %slot201, align 8
  %op2226 = sub i64 %v2225, 1
  store i64 %op2226, ptr %slot202, align 8
  %v2227 = load i64, ptr %slot202, align 8
  %cmp2228 = icmp eq i64 %v2227, 0
  %cv2229 = zext i1 %cmp2228 to i32
  store i32 %cv2229, ptr %slot203, align 8
  %v2230 = load i32, ptr %slot203, align 8
  %cv2231 = zext i32 %v2230 to i64
  %cond2232 = icmp ne i64 %cv2231, 0
  br i1 %cond2232, label %bb_rcglast213, label %bb_rcgdec213
bb_rcglast213:
  %v2233 = load i64, ptr %slot194, align 8
  %op2234 = sub i64 %v2233, 24
  store i64 %op2234, ptr %slot204, align 8
  %v2235 = load i64, ptr %slot194, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %rgep2237 = getelementptr i8, ptr %p2236, i64 -24
  %ld2238 = load i64, ptr %rgep2237, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2238, ptr %slot205, align 8
  %v2239 = load i64, ptr %slot205, align 8
  %cmp2240 = icmp ne i64 %v2239, 0
  %cv2241 = zext i1 %cmp2240 to i32
  store i32 %cv2241, ptr %slot206, align 8
  %v2242 = load i32, ptr %slot206, align 8
  %cv2243 = zext i32 %v2242 to i64
  %cond2244 = icmp ne i64 %cv2243, 0
  br i1 %cond2244, label %bb_rcgdec213, label %bb_rcgslow213
bb_rcgslow213:
  %v2245 = load i64, ptr %slot193, align 8
  %v2246 = load i64, ptr %slot192, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2245, i64 %v2246) nomerge, !dbg !116
  br label %bb_rcgdone213
bb_rcgdec213:
  %v2247 = load i64, ptr %slot202, align 8
  %v2248 = load i64, ptr %slot194, align 8
  %p2249 = inttoptr i64 %v2248 to ptr
  %rgep2250 = getelementptr i8, ptr %p2249, i64 -32
  store i64 %v2247, ptr %rgep2250, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear213
bb_rcgclear213:
  %v2251 = load i64, ptr %slot192, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i64 0, ptr %p2252, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone213
bb_rcgdone213:
  %v2253 = load i64, ptr %slot188, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i64 0, ptr %p2254, align 8, !alias.scope !3, !noalias !4
  %v2255 = load i64, ptr %slot188, align 8
  %p2257 = inttoptr i64 %v2255 to ptr
  %gep2258 = getelementptr i8, ptr %p2257, i64 8
  %op2256 = ptrtoint ptr %gep2258 to i64
  store i64 %op2256, ptr %slot207, align 8
  %v2259 = load i64, ptr %slot207, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  store i64 0, ptr %p2260, align 8, !alias.scope !3, !noalias !4
  %v2261 = load i64, ptr %slot188, align 8
  %p2263 = inttoptr i64 %v2261 to ptr
  %gep2264 = getelementptr i8, ptr %p2263, i64 16
  %op2262 = ptrtoint ptr %gep2264 to i64
  store i64 %op2262, ptr %slot208, align 8
  %v2265 = load i64, ptr %slot208, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i64 0, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot188, align 8
  %p2269 = inttoptr i64 %v2267 to ptr
  %gep2270 = getelementptr i8, ptr %p2269, i64 24
  %op2268 = ptrtoint ptr %gep2270 to i64
  store i64 %op2268, ptr %slot209, align 8
  %v2271 = load i64, ptr %slot209, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  store i64 0, ptr %p2272, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone195
bb_rcslotdone195:
  %v2273 = load i64, ptr %slot35, align 8
  store i64 %v2273, ptr %slot210, align 8
  %v2274 = load i64, ptr %slot29, align 8
  store i64 %v2274, ptr %slot211, align 8
  %v2275 = load i64, ptr %slot211, align 8
  %v2276 = load i64, ptr %slot210, align 8
  %p2277 = inttoptr i64 %v2275 to ptr
  %p2278 = inttoptr i64 %v2276 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2278, ptr %p2277, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2279 = load i64, ptr %slot23, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  store i32 0, ptr %p2280, align 4, !alias.scope !3, !noalias !4
  %v2281 = load i64, ptr %slot8, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  store i32 2, ptr %p2282, align 4, !alias.scope !3, !noalias !4
  %v2283 = load i64, ptr %slot24, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  %ld2285 = load i32, ptr %p2284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2285, ptr %slot212, align 8
  %v2286 = load i32, ptr %slot212, align 8
  %v2287 = load i64, ptr %slot8, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  store i32 %v2286, ptr %p2288, align 4, !alias.scope !3, !noalias !4
  %v2289 = load i64, ptr %slot7, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  store i32 1, ptr %p2290, align 4, !alias.scope !3, !noalias !4
  %v2291 = load i64, ptr %slot35, align 8
  %v2292 = load i64, ptr %slot44, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  store i64 %v2291, ptr %p2293, align 8, !alias.scope !3, !noalias !4
  %v2294 = load i64, ptr %slot44, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  %ld2296 = load i64, ptr %p2295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2296, ptr %slot213, align 8
  %v2297 = load i64, ptr %slot213, align 8
  %op2298 = add i64 %v2297, 16
  store i64 %op2298, ptr %slot214, align 8
  %v2299 = load i64, ptr %slot214, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %ld2301 = load i64, ptr %p2300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2301, ptr %slot215, align 8
  %v2302 = load i64, ptr %slot215, align 8
  %v2303 = load i64, ptr %slot44, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  store i64 %v2302, ptr %p2304, align 8, !alias.scope !3, !noalias !4
  %v2305 = load i64, ptr %slot19, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  %ld2307 = load i32, ptr %p2306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2307, ptr %slot216, align 8
  %v2308 = load i32, ptr %slot216, align 8
  %cv2309 = zext i32 %v2308 to i64
  %cond2310 = icmp ne i64 %cv2309, 0
  br i1 %cond2310, label %bb_rcslotdrop232, label %bb_rcslotdone232
bb_rcslotdrop232:
  %v2311 = load i64, ptr %slot19, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  store i32 0, ptr %p2312, align 4, !alias.scope !3, !noalias !4
  %v2313 = load i64, ptr %slot25, align 8
  store i64 %v2313, ptr %slot217, align 8
  %v2314 = load i64, ptr %slot20, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %ld2316 = load i32, ptr %p2315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2316, ptr %slot218, align 8
  %v2317 = load i32, ptr %slot218, align 8
  %op2318 = and i32 %v2317, 28
  store i32 %op2318, ptr %slot219, align 8
  %v2319 = load i32, ptr %slot219, align 8
  %cv2320 = zext i32 %v2319 to i64
  %cond2321 = icmp ne i64 %cv2320, 0
  br i1 %cond2321, label %bb_rcslotrole232, label %bb_rcslotowner232
bb_rcslotrole232:
  %v2322 = load i64, ptr %slot52, align 8
  store i64 %v2322, ptr %slot220, align 8
  %v2323 = load i64, ptr %slot220, align 8
  %v2324 = load i64, ptr %slot217, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2323, i64 %v2324) nomerge, !dbg !118
  br label %bb_rcslotdone232
bb_rcslotowner232:
  %v2325 = load i64, ptr %slot52, align 8
  store i64 %v2325, ptr %slot221, align 8
  %v2326 = load i64, ptr %slot221, align 8
  %v2327 = load i64, ptr %slot217, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2326, i64 %v2327) nomerge, !dbg !118
  br label %bb_rcslotdone232
bb_rcslotdone232:
  %v2328 = load i64, ptr %slot35, align 8
  %v2329 = load i64, ptr %slot45, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  store i64 %v2328, ptr %p2330, align 8, !alias.scope !3, !noalias !4
  %v2331 = load i64, ptr %slot45, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  %ld2333 = load i64, ptr %p2332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2333, ptr %slot222, align 8
  %v2334 = load i64, ptr %slot222, align 8
  %op2335 = add i64 %v2334, 0
  store i64 %op2335, ptr %slot223, align 8
  %v2336 = load i64, ptr %slot223, align 8
  %p2337 = inttoptr i64 %v2336 to ptr
  %ld2338 = load i64, ptr %p2337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2338, ptr %slot224, align 8
  %v2339 = load i64, ptr %slot224, align 8
  %v2340 = load i64, ptr %slot45, align 8
  %p2341 = inttoptr i64 %v2340 to ptr
  store i64 %v2339, ptr %p2341, align 8, !alias.scope !3, !noalias !4
  %v2342 = load i64, ptr %slot45, align 8
  %p2343 = inttoptr i64 %v2342 to ptr
  %ld2344 = load i64, ptr %p2343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2344, ptr %slot225, align 8
  %v2345 = load i64, ptr %slot225, align 8
  %v2346 = load i64, ptr %slot28, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  store i64 %v2345, ptr %p2347, align 8, !alias.scope !3, !noalias !4
  %v2348 = load i64, ptr %slot28, align 8
  store i64 %v2348, ptr %slot226, align 8
  %v2349 = load i64, ptr %slot29, align 8
  store i64 %v2349, ptr %slot227, align 8
  %v2350 = load i64, ptr %slot226, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  %ld2352 = load i64, ptr %p2351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2352, ptr %slot228, align 8
  %v2353 = load i64, ptr %slot228, align 8
  %cmp2354 = icmp ne i64 %v2353, 0
  %cv2355 = zext i1 %cmp2354 to i32
  store i32 %cv2355, ptr %slot229, align 8
  %v2356 = load i32, ptr %slot229, align 8
  %cv2357 = zext i32 %v2356 to i64
  %cond2358 = icmp ne i64 %cv2357, 0
  br i1 %cond2358, label %bb_rcgnn246, label %bb_rcgstore246
bb_rcgnn246:
  %v2359 = load i64, ptr %slot228, align 8
  %op2360 = sub i64 %v2359, 16
  store i64 %op2360, ptr %slot230, align 8
  %v2361 = load i64, ptr %slot228, align 8
  %p2362 = inttoptr i64 %v2361 to ptr
  %rgep2363 = getelementptr i8, ptr %p2362, i64 -16
  %ld2364 = load i64, ptr %rgep2363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2364, ptr %slot231, align 8
  %v2365 = load i64, ptr %slot231, align 8
  %op2366 = and i64 %v2365, 4611686018427387906
  store i64 %op2366, ptr %slot232, align 8
  %v2367 = load i64, ptr %slot232, align 8
  %cmp2368 = icmp ne i64 %v2367, 0
  %cv2369 = zext i1 %cmp2368 to i32
  store i32 %cv2369, ptr %slot233, align 8
  %v2370 = load i32, ptr %slot233, align 8
  %cv2371 = zext i32 %v2370 to i64
  %cond2372 = icmp ne i64 %cv2371, 0
  br i1 %cond2372, label %bb_rcgstore246, label %bb_rcginc246
bb_rcginc246:
  %v2373 = load i64, ptr %slot228, align 8
  %op2374 = sub i64 %v2373, 24
  store i64 %op2374, ptr %slot234, align 8
  %v2375 = load i64, ptr %slot228, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  %rgep2377 = getelementptr i8, ptr %p2376, i64 -24
  %ld2378 = load i64, ptr %rgep2377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2378, ptr %slot235, align 8
  %v2379 = load i64, ptr %slot235, align 8
  %op2380 = add i64 %v2379, 1
  store i64 %op2380, ptr %slot236, align 8
  %v2381 = load i64, ptr %slot236, align 8
  %cmp2382 = icmp eq i64 %v2381, 0
  %cv2383 = zext i1 %cmp2382 to i32
  store i32 %cv2383, ptr %slot237, align 8
  %v2384 = load i32, ptr %slot237, align 8
  %cv2385 = zext i32 %v2384 to i64
  %cond2386 = icmp ne i64 %cv2385, 0
  br i1 %cond2386, label %bb_rcglimit246, label %bb_rcgcapacity246
bb_rcglimit246:
  %v2387 = load i64, ptr %slot1, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  %call2389 = call i32 @myl_qbe_rc_status(ptr %p2388, i32 2) nomerge, !dbg !120
  store i32 %call2389, ptr %slot238, align 8
  br label %bb_failure
bb_rcgcapacity246:
  %v2390 = load i64, ptr %slot236, align 8
  %v2391 = load i64, ptr %slot228, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  %rgep2393 = getelementptr i8, ptr %p2392, i64 -24
  store i64 %v2390, ptr %rgep2393, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore246
bb_rcgstore246:
  %v2394 = load i64, ptr %slot228, align 8
  %v2395 = load i64, ptr %slot227, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  store i64 %v2394, ptr %p2396, align 8, !alias.scope !3, !noalias !4
  %v2397 = load i64, ptr %slot24, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  store i32 2, ptr %p2398, align 4, !alias.scope !3, !noalias !4
  %v2399 = load i64, ptr %slot24, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  store i32 16, ptr %p2400, align 4, !alias.scope !3, !noalias !4
  %v2401 = load i64, ptr %slot23, align 8
  %p2402 = inttoptr i64 %v2401 to ptr
  store i32 1, ptr %p2402, align 4, !alias.scope !3, !noalias !4
  %v2403 = load i64, ptr %slot21, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  %ld2405 = load i32, ptr %p2404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2405, ptr %slot239, align 8
  %v2406 = load i32, ptr %slot239, align 8
  %cv2407 = zext i32 %v2406 to i64
  %cond2408 = icmp ne i64 %cv2407, 0
  br i1 %cond2408, label %bb_rcslotdrop262, label %bb_rcslotdone262
bb_rcslotdrop262:
  %v2409 = load i64, ptr %slot21, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  store i32 0, ptr %p2410, align 4, !alias.scope !3, !noalias !4
  %v2411 = load i64, ptr %slot26, align 8
  store i64 %v2411, ptr %slot240, align 8
  %v2412 = load i64, ptr %slot22, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  %ld2414 = load i32, ptr %p2413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2414, ptr %slot241, align 8
  %v2415 = load i32, ptr %slot241, align 8
  %op2416 = and i32 %v2415, 28
  store i32 %op2416, ptr %slot242, align 8
  %v2417 = load i32, ptr %slot242, align 8
  %cv2418 = zext i32 %v2417 to i64
  %cond2419 = icmp ne i64 %cv2418, 0
  br i1 %cond2419, label %bb_rcslotrole262, label %bb_rcslotowner262
bb_rcslotrole262:
  %v2420 = load i64, ptr %slot52, align 8
  store i64 %v2420, ptr %slot243, align 8
  %v2421 = load i64, ptr %slot243, align 8
  %v2422 = load i64, ptr %slot240, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2421, i64 %v2422) nomerge, !dbg !120
  br label %bb_rcslotdone262
bb_rcslotowner262:
  %v2423 = load i64, ptr %slot52, align 8
  store i64 %v2423, ptr %slot244, align 8
  %v2424 = load i64, ptr %slot244, align 8
  %v2425 = load i64, ptr %slot240, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2424, i64 %v2425) nomerge, !dbg !120
  br label %bb_rcslotdone262
bb_rcslotdone262:
  %v2426 = load i64, ptr %slot26, align 8
  store i64 %v2426, ptr %slot245, align 8
  %v2427 = load i64, ptr %slot29, align 8
  store i64 %v2427, ptr %slot246, align 8
  %v2428 = load i64, ptr %slot246, align 8
  %v2429 = load i64, ptr %slot245, align 8
  %p2430 = inttoptr i64 %v2428 to ptr
  %p2431 = inttoptr i64 %v2429 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2431, ptr %p2430, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2432 = load i64, ptr %slot22, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  store i32 2, ptr %p2433, align 4, !alias.scope !3, !noalias !4
  %v2434 = load i64, ptr %slot24, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  %ld2436 = load i32, ptr %p2435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2436, ptr %slot247, align 8
  %v2437 = load i32, ptr %slot247, align 8
  %v2438 = load i64, ptr %slot22, align 8
  %p2439 = inttoptr i64 %v2438 to ptr
  store i32 %v2437, ptr %p2439, align 4, !alias.scope !3, !noalias !4
  %v2440 = load i64, ptr %slot23, align 8
  %p2441 = inttoptr i64 %v2440 to ptr
  store i32 0, ptr %p2441, align 4, !alias.scope !3, !noalias !4
  %v2442 = load i64, ptr %slot21, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  store i32 1, ptr %p2443, align 4, !alias.scope !3, !noalias !4
  %v2444 = load i64, ptr %slot245, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  %ld2446 = load i64, ptr %p2445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2446, ptr %slot248, align 8
  %v2447 = load i64, ptr %slot248, align 8
  %v2448 = load i64, ptr %slot45, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  store i64 %v2447, ptr %p2449, align 8, !alias.scope !3, !noalias !4
  %v2450 = load i64, ptr %slot45, align 8
  %p2451 = inttoptr i64 %v2450 to ptr
  %ld2452 = load i64, ptr %p2451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2452, ptr %slot249, align 8
  %v2453 = load i64, ptr %slot249, align 8
  %p2454 = inttoptr i64 %v2453 to ptr
  %ld2455 = load i64, ptr %p2454, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2455, ptr %slot250, align 8
  %v2456 = load i64, ptr %slot250, align 8
  %v2457 = load i64, ptr %slot45, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  store i64 %v2456, ptr %p2458, align 8, !alias.scope !3, !noalias !4
  %v2459 = load i64, ptr %slot21, align 8
  %p2460 = inttoptr i64 %v2459 to ptr
  %ld2461 = load i32, ptr %p2460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2461, ptr %slot251, align 8
  %v2462 = load i32, ptr %slot251, align 8
  %cv2463 = zext i32 %v2462 to i64
  %cond2464 = icmp ne i64 %cv2463, 0
  br i1 %cond2464, label %bb_rcslotdrop282, label %bb_rcslotdone282
bb_rcslotdrop282:
  %v2465 = load i64, ptr %slot21, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  store i32 0, ptr %p2466, align 4, !alias.scope !3, !noalias !4
  %v2467 = load i64, ptr %slot26, align 8
  store i64 %v2467, ptr %slot252, align 8
  %v2468 = load i64, ptr %slot22, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  %ld2470 = load i32, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2470, ptr %slot253, align 8
  %v2471 = load i32, ptr %slot253, align 8
  %op2472 = and i32 %v2471, 28
  store i32 %op2472, ptr %slot254, align 8
  %v2473 = load i32, ptr %slot254, align 8
  %cv2474 = zext i32 %v2473 to i64
  %cond2475 = icmp ne i64 %cv2474, 0
  br i1 %cond2475, label %bb_rcslotrole282, label %bb_rcslotowner282
bb_rcslotrole282:
  %v2476 = load i64, ptr %slot52, align 8
  store i64 %v2476, ptr %slot255, align 8
  %v2477 = load i64, ptr %slot252, align 8
  %p2478 = inttoptr i64 %v2477 to ptr
  %ld2479 = load i64, ptr %p2478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2479, ptr %slot256, align 8
  %v2480 = load i64, ptr %slot256, align 8
  %cmp2481 = icmp ne i64 %v2480, 0
  %cv2482 = zext i1 %cmp2481 to i32
  store i32 %cv2482, ptr %slot257, align 8
  %v2483 = load i32, ptr %slot257, align 8
  %cv2484 = zext i32 %v2483 to i64
  %cond2485 = icmp ne i64 %cv2484, 0
  br i1 %cond2485, label %bb_rcgnn298, label %bb_rcgdone298
bb_rcgnn298:
  %v2486 = load i64, ptr %slot256, align 8
  %op2487 = sub i64 %v2486, 16
  store i64 %op2487, ptr %slot258, align 8
  %v2488 = load i64, ptr %slot256, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  %rgep2490 = getelementptr i8, ptr %p2489, i64 -16
  %ld2491 = load i64, ptr %rgep2490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2491, ptr %slot259, align 8
  %v2492 = load i64, ptr %slot259, align 8
  %op2493 = and i64 %v2492, 4611686018427387906
  store i64 %op2493, ptr %slot260, align 8
  %v2494 = load i64, ptr %slot260, align 8
  %cmp2495 = icmp ne i64 %v2494, 0
  %cv2496 = zext i1 %cmp2495 to i32
  store i32 %cv2496, ptr %slot261, align 8
  %v2497 = load i32, ptr %slot261, align 8
  %cv2498 = zext i32 %v2497 to i64
  %cond2499 = icmp ne i64 %cv2498, 0
  br i1 %cond2499, label %bb_rcgclear298, label %bb_rcgcounted298
bb_rcgcounted298:
  %v2500 = load i64, ptr %slot256, align 8
  %op2501 = sub i64 %v2500, 24
  store i64 %op2501, ptr %slot262, align 8
  %v2502 = load i64, ptr %slot256, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  %rgep2504 = getelementptr i8, ptr %p2503, i64 -24
  %ld2505 = load i64, ptr %rgep2504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2505, ptr %slot263, align 8
  %v2506 = load i64, ptr %slot263, align 8
  %op2507 = sub i64 %v2506, 1
  store i64 %op2507, ptr %slot264, align 8
  %v2508 = load i64, ptr %slot264, align 8
  %cmp2509 = icmp eq i64 %v2508, 0
  %cv2510 = zext i1 %cmp2509 to i32
  store i32 %cv2510, ptr %slot265, align 8
  %v2511 = load i32, ptr %slot265, align 8
  %cv2512 = zext i32 %v2511 to i64
  %cond2513 = icmp ne i64 %cv2512, 0
  br i1 %cond2513, label %bb_rcglast298, label %bb_rcgdec298
bb_rcglast298:
  %v2514 = load i64, ptr %slot256, align 8
  %op2515 = sub i64 %v2514, 32
  store i64 %op2515, ptr %slot266, align 8
  %v2516 = load i64, ptr %slot256, align 8
  %p2517 = inttoptr i64 %v2516 to ptr
  %rgep2518 = getelementptr i8, ptr %p2517, i64 -32
  %ld2519 = load i64, ptr %rgep2518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2519, ptr %slot267, align 8
  %v2520 = load i64, ptr %slot267, align 8
  %cmp2521 = icmp ne i64 %v2520, 0
  %cv2522 = zext i1 %cmp2521 to i32
  store i32 %cv2522, ptr %slot268, align 8
  %v2523 = load i32, ptr %slot268, align 8
  %cv2524 = zext i32 %v2523 to i64
  %cond2525 = icmp ne i64 %cv2524, 0
  br i1 %cond2525, label %bb_rcgdec298, label %bb_rcgslow298
bb_rcgslow298:
  %v2526 = load i64, ptr %slot255, align 8
  %v2527 = load i64, ptr %slot252, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2526, i64 %v2527) nomerge, !dbg !122
  br label %bb_rcgdone298
bb_rcgdec298:
  %v2528 = load i64, ptr %slot264, align 8
  %v2529 = load i64, ptr %slot256, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %rgep2531 = getelementptr i8, ptr %p2530, i64 -24
  store i64 %v2528, ptr %rgep2531, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear298
bb_rcgclear298:
  %v2532 = load i64, ptr %slot252, align 8
  %p2533 = inttoptr i64 %v2532 to ptr
  store i64 0, ptr %p2533, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone298
bb_rcgdone298:
  br label %bb_rcslotdone282
bb_rcslotowner282:
  %v2534 = load i64, ptr %slot52, align 8
  store i64 %v2534, ptr %slot269, align 8
  %v2535 = load i64, ptr %slot252, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  %ld2537 = load i64, ptr %p2536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2537, ptr %slot270, align 8
  %v2538 = load i64, ptr %slot270, align 8
  %cmp2539 = icmp ne i64 %v2538, 0
  %cv2540 = zext i1 %cmp2539 to i32
  store i32 %cv2540, ptr %slot271, align 8
  %v2541 = load i32, ptr %slot271, align 8
  %cv2542 = zext i32 %v2541 to i64
  %cond2543 = icmp ne i64 %cv2542, 0
  br i1 %cond2543, label %bb_rcgnn313, label %bb_rcgdone313
bb_rcgnn313:
  %v2544 = load i64, ptr %slot270, align 8
  %op2545 = sub i64 %v2544, 16
  store i64 %op2545, ptr %slot272, align 8
  %v2546 = load i64, ptr %slot270, align 8
  %p2547 = inttoptr i64 %v2546 to ptr
  %rgep2548 = getelementptr i8, ptr %p2547, i64 -16
  %ld2549 = load i64, ptr %rgep2548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2549, ptr %slot273, align 8
  %v2550 = load i64, ptr %slot273, align 8
  %op2551 = and i64 %v2550, 4611686018427387906
  store i64 %op2551, ptr %slot274, align 8
  %v2552 = load i64, ptr %slot274, align 8
  %cmp2553 = icmp ne i64 %v2552, 0
  %cv2554 = zext i1 %cmp2553 to i32
  store i32 %cv2554, ptr %slot275, align 8
  %v2555 = load i32, ptr %slot275, align 8
  %cv2556 = zext i32 %v2555 to i64
  %cond2557 = icmp ne i64 %cv2556, 0
  br i1 %cond2557, label %bb_rcgclear313, label %bb_rcgcounted313
bb_rcgcounted313:
  %v2558 = load i64, ptr %slot270, align 8
  %op2559 = sub i64 %v2558, 32
  store i64 %op2559, ptr %slot276, align 8
  %v2560 = load i64, ptr %slot270, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %rgep2562 = getelementptr i8, ptr %p2561, i64 -32
  %ld2563 = load i64, ptr %rgep2562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2563, ptr %slot277, align 8
  %v2564 = load i64, ptr %slot277, align 8
  %op2565 = sub i64 %v2564, 1
  store i64 %op2565, ptr %slot278, align 8
  %v2566 = load i64, ptr %slot278, align 8
  %cmp2567 = icmp eq i64 %v2566, 0
  %cv2568 = zext i1 %cmp2567 to i32
  store i32 %cv2568, ptr %slot279, align 8
  %v2569 = load i32, ptr %slot279, align 8
  %cv2570 = zext i32 %v2569 to i64
  %cond2571 = icmp ne i64 %cv2570, 0
  br i1 %cond2571, label %bb_rcglast313, label %bb_rcgdec313
bb_rcglast313:
  %v2572 = load i64, ptr %slot270, align 8
  %op2573 = sub i64 %v2572, 24
  store i64 %op2573, ptr %slot280, align 8
  %v2574 = load i64, ptr %slot270, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  %rgep2576 = getelementptr i8, ptr %p2575, i64 -24
  %ld2577 = load i64, ptr %rgep2576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2577, ptr %slot281, align 8
  %v2578 = load i64, ptr %slot281, align 8
  %cmp2579 = icmp ne i64 %v2578, 0
  %cv2580 = zext i1 %cmp2579 to i32
  store i32 %cv2580, ptr %slot282, align 8
  %v2581 = load i32, ptr %slot282, align 8
  %cv2582 = zext i32 %v2581 to i64
  %cond2583 = icmp ne i64 %cv2582, 0
  br i1 %cond2583, label %bb_rcgdec313, label %bb_rcgslow313
bb_rcgslow313:
  %v2584 = load i64, ptr %slot269, align 8
  %v2585 = load i64, ptr %slot252, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2584, i64 %v2585) nomerge, !dbg !122
  br label %bb_rcgdone313
bb_rcgdec313:
  %v2586 = load i64, ptr %slot278, align 8
  %v2587 = load i64, ptr %slot270, align 8
  %p2588 = inttoptr i64 %v2587 to ptr
  %rgep2589 = getelementptr i8, ptr %p2588, i64 -32
  store i64 %v2586, ptr %rgep2589, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear313
bb_rcgclear313:
  %v2590 = load i64, ptr %slot252, align 8
  %p2591 = inttoptr i64 %v2590 to ptr
  store i64 0, ptr %p2591, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone313
bb_rcgdone313:
  br label %bb_rcslotdone282
bb_rcslotdone282:
  %v2592 = load i64, ptr %slot45, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  %ld2594 = load i64, ptr %p2593, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2594, ptr %slot283, align 8
  %v2595 = load i64, ptr %slot44, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  %ld2597 = load i64, ptr %p2596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2597, ptr %slot284, align 8
  %v2598 = load i64, ptr %slot284, align 8
  %v2599 = load i64, ptr %slot283, align 8
  %cmp2600 = icmp sge i64 %v2598, %v2599
  %cv2601 = zext i1 %cmp2600 to i64
  store i64 %cv2601, ptr %slot285, align 8
  %v2602 = load i64, ptr %slot285, align 8
  %v2603 = load i64, ptr %slot44, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  store i64 %v2602, ptr %p2604, align 8, !alias.scope !3, !noalias !4
  br label %bb_i11
bb_i11:
  %v2605 = load i64, ptr %slot44, align 8
  %p2606 = inttoptr i64 %v2605 to ptr
  %ld2607 = load i64, ptr %p2606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2607, ptr %slot286, align 8
  %v2608 = load i64, ptr %slot286, align 8
  %cond2609 = icmp ne i64 %v2608, 0
  br i1 %cond2609, label %bb_next321, label %bb_i14
bb_next321:
  %v2610 = load i64, ptr %slot44, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i64 0, ptr %p2611, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i14:
  %v2612 = load i64, ptr %slot34, align 8
  %v2613 = load i64, ptr %slot44, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  store i64 %v2612, ptr %p2614, align 8, !alias.scope !3, !noalias !4
  %v2615 = load i64, ptr %slot44, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  %ld2617 = load i64, ptr %p2616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2617, ptr %slot287, align 8
  %v2618 = load i64, ptr %slot287, align 8
  %op2619 = add i64 %v2618, 0
  store i64 %op2619, ptr %slot288, align 8
  %v2620 = load i64, ptr %slot288, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  %ld2622 = load i64, ptr %p2621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2622, ptr %slot289, align 8
  %v2623 = load i64, ptr %slot289, align 8
  %v2624 = load i64, ptr %slot44, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  store i64 %v2623, ptr %p2625, align 8, !alias.scope !3, !noalias !4
  %v2626 = load i64, ptr %slot44, align 8
  %p2627 = inttoptr i64 %v2626 to ptr
  %ld2628 = load i64, ptr %p2627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2628, ptr %slot290, align 8
  %v2629 = load i64, ptr %slot290, align 8
  %v2630 = load i64, ptr %slot27, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  store i64 %v2629, ptr %p2631, align 8, !alias.scope !3, !noalias !4
  %v2632 = load i64, ptr %slot27, align 8
  store i64 %v2632, ptr %slot291, align 8
  %v2633 = load i64, ptr %slot29, align 8
  store i64 %v2633, ptr %slot292, align 8
  %v2634 = load i64, ptr %slot291, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  %ld2636 = load i64, ptr %p2635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2636, ptr %slot293, align 8
  %v2637 = load i64, ptr %slot293, align 8
  %cmp2638 = icmp ne i64 %v2637, 0
  %cv2639 = zext i1 %cmp2638 to i32
  store i32 %cv2639, ptr %slot294, align 8
  %v2640 = load i32, ptr %slot294, align 8
  %cv2641 = zext i32 %v2640 to i64
  %cond2642 = icmp ne i64 %cv2641, 0
  br i1 %cond2642, label %bb_rcgnn328, label %bb_rcgstore328
bb_rcgnn328:
  %v2643 = load i64, ptr %slot293, align 8
  %op2644 = sub i64 %v2643, 16
  store i64 %op2644, ptr %slot295, align 8
  %v2645 = load i64, ptr %slot293, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  %rgep2647 = getelementptr i8, ptr %p2646, i64 -16
  %ld2648 = load i64, ptr %rgep2647, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2648, ptr %slot296, align 8
  %v2649 = load i64, ptr %slot296, align 8
  %op2650 = and i64 %v2649, 4611686018427387906
  store i64 %op2650, ptr %slot297, align 8
  %v2651 = load i64, ptr %slot297, align 8
  %cmp2652 = icmp ne i64 %v2651, 0
  %cv2653 = zext i1 %cmp2652 to i32
  store i32 %cv2653, ptr %slot298, align 8
  %v2654 = load i32, ptr %slot298, align 8
  %cv2655 = zext i32 %v2654 to i64
  %cond2656 = icmp ne i64 %cv2655, 0
  br i1 %cond2656, label %bb_rcgstore328, label %bb_rcginc328
bb_rcginc328:
  %v2657 = load i64, ptr %slot293, align 8
  %op2658 = sub i64 %v2657, 24
  store i64 %op2658, ptr %slot299, align 8
  %v2659 = load i64, ptr %slot293, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  %rgep2661 = getelementptr i8, ptr %p2660, i64 -24
  %ld2662 = load i64, ptr %rgep2661, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2662, ptr %slot300, align 8
  %v2663 = load i64, ptr %slot300, align 8
  %op2664 = add i64 %v2663, 1
  store i64 %op2664, ptr %slot301, align 8
  %v2665 = load i64, ptr %slot301, align 8
  %cmp2666 = icmp eq i64 %v2665, 0
  %cv2667 = zext i1 %cmp2666 to i32
  store i32 %cv2667, ptr %slot302, align 8
  %v2668 = load i32, ptr %slot302, align 8
  %cv2669 = zext i32 %v2668 to i64
  %cond2670 = icmp ne i64 %cv2669, 0
  br i1 %cond2670, label %bb_rcglimit328, label %bb_rcgcapacity328
bb_rcglimit328:
  %v2671 = load i64, ptr %slot1, align 8
  %p2672 = inttoptr i64 %v2671 to ptr
  %call2673 = call i32 @myl_qbe_rc_status(ptr %p2672, i32 2) nomerge, !dbg !124
  store i32 %call2673, ptr %slot303, align 8
  br label %bb_failure
bb_rcgcapacity328:
  %v2674 = load i64, ptr %slot301, align 8
  %v2675 = load i64, ptr %slot293, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  %rgep2677 = getelementptr i8, ptr %p2676, i64 -24
  store i64 %v2674, ptr %rgep2677, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore328
bb_rcgstore328:
  %v2678 = load i64, ptr %slot293, align 8
  %v2679 = load i64, ptr %slot292, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  store i64 %v2678, ptr %p2680, align 8, !alias.scope !3, !noalias !4
  %v2681 = load i64, ptr %slot24, align 8
  %p2682 = inttoptr i64 %v2681 to ptr
  store i32 2, ptr %p2682, align 4, !alias.scope !3, !noalias !4
  %v2683 = load i64, ptr %slot24, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i32 16, ptr %p2684, align 4, !alias.scope !3, !noalias !4
  %v2685 = load i64, ptr %slot23, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  store i32 1, ptr %p2686, align 4, !alias.scope !3, !noalias !4
  %v2687 = load i64, ptr %slot19, align 8
  %p2688 = inttoptr i64 %v2687 to ptr
  %ld2689 = load i32, ptr %p2688, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2689, ptr %slot304, align 8
  %v2690 = load i32, ptr %slot304, align 8
  %cv2691 = zext i32 %v2690 to i64
  %cond2692 = icmp ne i64 %cv2691, 0
  br i1 %cond2692, label %bb_rcslotdrop344, label %bb_rcslotdone344
bb_rcslotdrop344:
  %v2693 = load i64, ptr %slot19, align 8
  %p2694 = inttoptr i64 %v2693 to ptr
  store i32 0, ptr %p2694, align 4, !alias.scope !3, !noalias !4
  %v2695 = load i64, ptr %slot25, align 8
  store i64 %v2695, ptr %slot305, align 8
  %v2696 = load i64, ptr %slot20, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  %ld2698 = load i32, ptr %p2697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2698, ptr %slot306, align 8
  %v2699 = load i32, ptr %slot306, align 8
  %op2700 = and i32 %v2699, 28
  store i32 %op2700, ptr %slot307, align 8
  %v2701 = load i32, ptr %slot307, align 8
  %cv2702 = zext i32 %v2701 to i64
  %cond2703 = icmp ne i64 %cv2702, 0
  br i1 %cond2703, label %bb_rcslotrole344, label %bb_rcslotowner344
bb_rcslotrole344:
  %v2704 = load i64, ptr %slot52, align 8
  store i64 %v2704, ptr %slot308, align 8
  %v2705 = load i64, ptr %slot308, align 8
  %v2706 = load i64, ptr %slot305, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2705, i64 %v2706) nomerge, !dbg !124
  br label %bb_rcslotdone344
bb_rcslotowner344:
  %v2707 = load i64, ptr %slot52, align 8
  store i64 %v2707, ptr %slot309, align 8
  %v2708 = load i64, ptr %slot309, align 8
  %v2709 = load i64, ptr %slot305, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2708, i64 %v2709) nomerge, !dbg !124
  br label %bb_rcslotdone344
bb_rcslotdone344:
  %v2710 = load i64, ptr %slot25, align 8
  store i64 %v2710, ptr %slot310, align 8
  %v2711 = load i64, ptr %slot29, align 8
  store i64 %v2711, ptr %slot311, align 8
  %v2712 = load i64, ptr %slot311, align 8
  %v2713 = load i64, ptr %slot310, align 8
  %p2714 = inttoptr i64 %v2712 to ptr
  %p2715 = inttoptr i64 %v2713 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2715, ptr %p2714, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2716 = load i64, ptr %slot20, align 8
  %p2717 = inttoptr i64 %v2716 to ptr
  store i32 2, ptr %p2717, align 4, !alias.scope !3, !noalias !4
  %v2718 = load i64, ptr %slot24, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  %ld2720 = load i32, ptr %p2719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2720, ptr %slot312, align 8
  %v2721 = load i32, ptr %slot312, align 8
  %v2722 = load i64, ptr %slot20, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  store i32 %v2721, ptr %p2723, align 4, !alias.scope !3, !noalias !4
  %v2724 = load i64, ptr %slot23, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  store i32 0, ptr %p2725, align 4, !alias.scope !3, !noalias !4
  %v2726 = load i64, ptr %slot19, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i32 1, ptr %p2727, align 4, !alias.scope !3, !noalias !4
  %v2728 = load i64, ptr %slot310, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  %ld2730 = load i64, ptr %p2729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2730, ptr %slot313, align 8
  %v2731 = load i64, ptr %slot313, align 8
  %v2732 = load i64, ptr %slot44, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  store i64 %v2731, ptr %p2733, align 8, !alias.scope !3, !noalias !4
  %v2734 = load i64, ptr %slot34, align 8
  %v2735 = load i64, ptr %slot45, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  store i64 %v2734, ptr %p2736, align 8, !alias.scope !3, !noalias !4
  %v2737 = load i64, ptr %slot45, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  %ld2739 = load i64, ptr %p2738, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2739, ptr %slot314, align 8
  %v2740 = load i64, ptr %slot314, align 8
  %op2741 = add i64 %v2740, 16
  store i64 %op2741, ptr %slot315, align 8
  %v2742 = load i64, ptr %slot315, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  %ld2744 = load i64, ptr %p2743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2744, ptr %slot316, align 8
  %v2745 = load i64, ptr %slot316, align 8
  %v2746 = load i64, ptr %slot45, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  store i64 %v2745, ptr %p2747, align 8, !alias.scope !3, !noalias !4
  %v2748 = load i64, ptr %slot21, align 8
  %p2749 = inttoptr i64 %v2748 to ptr
  %ld2750 = load i32, ptr %p2749, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2750, ptr %slot317, align 8
  %v2751 = load i32, ptr %slot317, align 8
  %cv2752 = zext i32 %v2751 to i64
  %cond2753 = icmp ne i64 %cv2752, 0
  br i1 %cond2753, label %bb_rcslotdrop365, label %bb_rcslotdone365
bb_rcslotdrop365:
  %v2754 = load i64, ptr %slot21, align 8
  %p2755 = inttoptr i64 %v2754 to ptr
  store i32 0, ptr %p2755, align 4, !alias.scope !3, !noalias !4
  %v2756 = load i64, ptr %slot26, align 8
  store i64 %v2756, ptr %slot318, align 8
  %v2757 = load i64, ptr %slot22, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  %ld2759 = load i32, ptr %p2758, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2759, ptr %slot319, align 8
  %v2760 = load i32, ptr %slot319, align 8
  %op2761 = and i32 %v2760, 28
  store i32 %op2761, ptr %slot320, align 8
  %v2762 = load i32, ptr %slot320, align 8
  %cv2763 = zext i32 %v2762 to i64
  %cond2764 = icmp ne i64 %cv2763, 0
  br i1 %cond2764, label %bb_rcslotrole365, label %bb_rcslotowner365
bb_rcslotrole365:
  %v2765 = load i64, ptr %slot52, align 8
  store i64 %v2765, ptr %slot321, align 8
  %v2766 = load i64, ptr %slot321, align 8
  %v2767 = load i64, ptr %slot318, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2766, i64 %v2767) nomerge, !dbg !126
  br label %bb_rcslotdone365
bb_rcslotowner365:
  %v2768 = load i64, ptr %slot52, align 8
  store i64 %v2768, ptr %slot322, align 8
  %v2769 = load i64, ptr %slot322, align 8
  %v2770 = load i64, ptr %slot318, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2769, i64 %v2770) nomerge, !dbg !126
  br label %bb_rcslotdone365
bb_rcslotdone365:
  %v2771 = load i64, ptr %slot44, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  %ld2773 = load i64, ptr %p2772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2773, ptr %slot323, align 8
  %v2774 = load i64, ptr %slot45, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  %ld2776 = load i64, ptr %p2775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2776, ptr %slot324, align 8
  %v2777 = load i64, ptr %slot323, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %ld2779 = load i64, ptr %p2778, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2779, ptr %slot325, align 8
  %v2780 = load i64, ptr %slot324, align 8
  %op2781 = ashr i64 %v2780, 63
  store i64 %op2781, ptr %slot326, align 8
  %v2782 = load i64, ptr %slot326, align 8
  %v2783 = load i64, ptr %slot325, align 8
  %op2784 = and i64 %v2782, %v2783
  store i64 %op2784, ptr %slot327, align 8
  %v2785 = load i64, ptr %slot324, align 8
  %v2786 = load i64, ptr %slot327, align 8
  %op2787 = add i64 %v2785, %v2786
  store i64 %op2787, ptr %slot328, align 8
  %v2788 = load i64, ptr %slot328, align 8
  %v2789 = load i64, ptr %slot325, align 8
  %cmp2790 = icmp ult i64 %v2788, %v2789
  %cv2791 = zext i1 %cmp2790 to i64
  store i64 %cv2791, ptr %slot329, align 8
  %v2792 = load i64, ptr %slot329, align 8
  %cond2793 = icmp ne i64 %v2792, 0
  br i1 %cond2793, label %bb_success380, label %bb_failed380
bb_failed380:
  %v2794 = load i64, ptr %slot1, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %v2796 = load i64, ptr %slot324, align 8
  %v2797 = load i64, ptr %slot325, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p2795, i64 %v2796, i64 %v2797) nomerge, !dbg !128
  unreachable
bb_success380:
  %v2798 = load i64, ptr %slot323, align 8
  %op2799 = add i64 %v2798, 32
  store i64 %op2799, ptr %slot330, align 8
  %v2800 = load i64, ptr %slot330, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i64, ptr %p2801, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2802, ptr %slot331, align 8
  %v2803 = load i64, ptr %slot331, align 8
  %v2804 = load i64, ptr %slot328, align 8
  %op2805 = add i64 %v2803, %v2804
  store i64 %op2805, ptr %slot332, align 8
  %v2806 = load i64, ptr %slot331, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  %v2808 = load i64, ptr %slot328, align 8
  %egep2809 = getelementptr i8, ptr %p2807, i64 %v2808
  %ld2810 = load i8, ptr %egep2809, align 1, !alias.scope !12, !noalias !13
  %ext2811 = zext i8 %ld2810 to i64
  store i64 %ext2811, ptr %slot333, align 8
  %v2812 = load i64, ptr %slot333, align 8
  %v2813 = load i64, ptr %slot44, align 8
  %p2814 = inttoptr i64 %v2813 to ptr
  store i64 %v2812, ptr %p2814, align 8, !alias.scope !3, !noalias !4
  %v2815 = load i64, ptr %slot19, align 8
  %p2816 = inttoptr i64 %v2815 to ptr
  %ld2817 = load i32, ptr %p2816, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2817, ptr %slot334, align 8
  %v2818 = load i32, ptr %slot334, align 8
  %cv2819 = zext i32 %v2818 to i64
  %cond2820 = icmp ne i64 %cv2819, 0
  br i1 %cond2820, label %bb_rcslotdrop388, label %bb_rcslotdone388
bb_rcslotdrop388:
  %v2821 = load i64, ptr %slot19, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  store i32 0, ptr %p2822, align 4, !alias.scope !3, !noalias !4
  %v2823 = load i64, ptr %slot25, align 8
  store i64 %v2823, ptr %slot335, align 8
  %v2824 = load i64, ptr %slot20, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  %ld2826 = load i32, ptr %p2825, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2826, ptr %slot336, align 8
  %v2827 = load i32, ptr %slot336, align 8
  %op2828 = and i32 %v2827, 28
  store i32 %op2828, ptr %slot337, align 8
  %v2829 = load i32, ptr %slot337, align 8
  %cv2830 = zext i32 %v2829 to i64
  %cond2831 = icmp ne i64 %cv2830, 0
  br i1 %cond2831, label %bb_rcslotrole388, label %bb_rcslotowner388
bb_rcslotrole388:
  %v2832 = load i64, ptr %slot52, align 8
  store i64 %v2832, ptr %slot338, align 8
  %v2833 = load i64, ptr %slot335, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  %ld2835 = load i64, ptr %p2834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2835, ptr %slot339, align 8
  %v2836 = load i64, ptr %slot339, align 8
  %cmp2837 = icmp ne i64 %v2836, 0
  %cv2838 = zext i1 %cmp2837 to i32
  store i32 %cv2838, ptr %slot340, align 8
  %v2839 = load i32, ptr %slot340, align 8
  %cv2840 = zext i32 %v2839 to i64
  %cond2841 = icmp ne i64 %cv2840, 0
  br i1 %cond2841, label %bb_rcgnn404, label %bb_rcgdone404
bb_rcgnn404:
  %v2842 = load i64, ptr %slot339, align 8
  %op2843 = sub i64 %v2842, 16
  store i64 %op2843, ptr %slot341, align 8
  %v2844 = load i64, ptr %slot339, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  %rgep2846 = getelementptr i8, ptr %p2845, i64 -16
  %ld2847 = load i64, ptr %rgep2846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2847, ptr %slot342, align 8
  %v2848 = load i64, ptr %slot342, align 8
  %op2849 = and i64 %v2848, 4611686018427387906
  store i64 %op2849, ptr %slot343, align 8
  %v2850 = load i64, ptr %slot343, align 8
  %cmp2851 = icmp ne i64 %v2850, 0
  %cv2852 = zext i1 %cmp2851 to i32
  store i32 %cv2852, ptr %slot344, align 8
  %v2853 = load i32, ptr %slot344, align 8
  %cv2854 = zext i32 %v2853 to i64
  %cond2855 = icmp ne i64 %cv2854, 0
  br i1 %cond2855, label %bb_rcgclear404, label %bb_rcgcounted404
bb_rcgcounted404:
  %v2856 = load i64, ptr %slot339, align 8
  %op2857 = sub i64 %v2856, 24
  store i64 %op2857, ptr %slot345, align 8
  %v2858 = load i64, ptr %slot339, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  %rgep2860 = getelementptr i8, ptr %p2859, i64 -24
  %ld2861 = load i64, ptr %rgep2860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2861, ptr %slot346, align 8
  %v2862 = load i64, ptr %slot346, align 8
  %op2863 = sub i64 %v2862, 1
  store i64 %op2863, ptr %slot347, align 8
  %v2864 = load i64, ptr %slot347, align 8
  %cmp2865 = icmp eq i64 %v2864, 0
  %cv2866 = zext i1 %cmp2865 to i32
  store i32 %cv2866, ptr %slot348, align 8
  %v2867 = load i32, ptr %slot348, align 8
  %cv2868 = zext i32 %v2867 to i64
  %cond2869 = icmp ne i64 %cv2868, 0
  br i1 %cond2869, label %bb_rcglast404, label %bb_rcgdec404
bb_rcglast404:
  %v2870 = load i64, ptr %slot339, align 8
  %op2871 = sub i64 %v2870, 32
  store i64 %op2871, ptr %slot349, align 8
  %v2872 = load i64, ptr %slot339, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  %rgep2874 = getelementptr i8, ptr %p2873, i64 -32
  %ld2875 = load i64, ptr %rgep2874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2875, ptr %slot350, align 8
  %v2876 = load i64, ptr %slot350, align 8
  %cmp2877 = icmp ne i64 %v2876, 0
  %cv2878 = zext i1 %cmp2877 to i32
  store i32 %cv2878, ptr %slot351, align 8
  %v2879 = load i32, ptr %slot351, align 8
  %cv2880 = zext i32 %v2879 to i64
  %cond2881 = icmp ne i64 %cv2880, 0
  br i1 %cond2881, label %bb_rcgdec404, label %bb_rcgslow404
bb_rcgslow404:
  %v2882 = load i64, ptr %slot338, align 8
  %v2883 = load i64, ptr %slot335, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2882, i64 %v2883) nomerge, !dbg !128
  br label %bb_rcgdone404
bb_rcgdec404:
  %v2884 = load i64, ptr %slot347, align 8
  %v2885 = load i64, ptr %slot339, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  %rgep2887 = getelementptr i8, ptr %p2886, i64 -24
  store i64 %v2884, ptr %rgep2887, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear404
bb_rcgclear404:
  %v2888 = load i64, ptr %slot335, align 8
  %p2889 = inttoptr i64 %v2888 to ptr
  store i64 0, ptr %p2889, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone404
bb_rcgdone404:
  br label %bb_rcslotdone388
bb_rcslotowner388:
  %v2890 = load i64, ptr %slot52, align 8
  store i64 %v2890, ptr %slot352, align 8
  %v2891 = load i64, ptr %slot335, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  %ld2893 = load i64, ptr %p2892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2893, ptr %slot353, align 8
  %v2894 = load i64, ptr %slot353, align 8
  %cmp2895 = icmp ne i64 %v2894, 0
  %cv2896 = zext i1 %cmp2895 to i32
  store i32 %cv2896, ptr %slot354, align 8
  %v2897 = load i32, ptr %slot354, align 8
  %cv2898 = zext i32 %v2897 to i64
  %cond2899 = icmp ne i64 %cv2898, 0
  br i1 %cond2899, label %bb_rcgnn419, label %bb_rcgdone419
bb_rcgnn419:
  %v2900 = load i64, ptr %slot353, align 8
  %op2901 = sub i64 %v2900, 16
  store i64 %op2901, ptr %slot355, align 8
  %v2902 = load i64, ptr %slot353, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  %rgep2904 = getelementptr i8, ptr %p2903, i64 -16
  %ld2905 = load i64, ptr %rgep2904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2905, ptr %slot356, align 8
  %v2906 = load i64, ptr %slot356, align 8
  %op2907 = and i64 %v2906, 4611686018427387906
  store i64 %op2907, ptr %slot357, align 8
  %v2908 = load i64, ptr %slot357, align 8
  %cmp2909 = icmp ne i64 %v2908, 0
  %cv2910 = zext i1 %cmp2909 to i32
  store i32 %cv2910, ptr %slot358, align 8
  %v2911 = load i32, ptr %slot358, align 8
  %cv2912 = zext i32 %v2911 to i64
  %cond2913 = icmp ne i64 %cv2912, 0
  br i1 %cond2913, label %bb_rcgclear419, label %bb_rcgcounted419
bb_rcgcounted419:
  %v2914 = load i64, ptr %slot353, align 8
  %op2915 = sub i64 %v2914, 32
  store i64 %op2915, ptr %slot359, align 8
  %v2916 = load i64, ptr %slot353, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  %rgep2918 = getelementptr i8, ptr %p2917, i64 -32
  %ld2919 = load i64, ptr %rgep2918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2919, ptr %slot360, align 8
  %v2920 = load i64, ptr %slot360, align 8
  %op2921 = sub i64 %v2920, 1
  store i64 %op2921, ptr %slot361, align 8
  %v2922 = load i64, ptr %slot361, align 8
  %cmp2923 = icmp eq i64 %v2922, 0
  %cv2924 = zext i1 %cmp2923 to i32
  store i32 %cv2924, ptr %slot362, align 8
  %v2925 = load i32, ptr %slot362, align 8
  %cv2926 = zext i32 %v2925 to i64
  %cond2927 = icmp ne i64 %cv2926, 0
  br i1 %cond2927, label %bb_rcglast419, label %bb_rcgdec419
bb_rcglast419:
  %v2928 = load i64, ptr %slot353, align 8
  %op2929 = sub i64 %v2928, 24
  store i64 %op2929, ptr %slot363, align 8
  %v2930 = load i64, ptr %slot353, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  %rgep2932 = getelementptr i8, ptr %p2931, i64 -24
  %ld2933 = load i64, ptr %rgep2932, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2933, ptr %slot364, align 8
  %v2934 = load i64, ptr %slot364, align 8
  %cmp2935 = icmp ne i64 %v2934, 0
  %cv2936 = zext i1 %cmp2935 to i32
  store i32 %cv2936, ptr %slot365, align 8
  %v2937 = load i32, ptr %slot365, align 8
  %cv2938 = zext i32 %v2937 to i64
  %cond2939 = icmp ne i64 %cv2938, 0
  br i1 %cond2939, label %bb_rcgdec419, label %bb_rcgslow419
bb_rcgslow419:
  %v2940 = load i64, ptr %slot352, align 8
  %v2941 = load i64, ptr %slot335, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2940, i64 %v2941) nomerge, !dbg !128
  br label %bb_rcgdone419
bb_rcgdec419:
  %v2942 = load i64, ptr %slot361, align 8
  %v2943 = load i64, ptr %slot353, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  %rgep2945 = getelementptr i8, ptr %p2944, i64 -32
  store i64 %v2942, ptr %rgep2945, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear419
bb_rcgclear419:
  %v2946 = load i64, ptr %slot335, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  store i64 0, ptr %p2947, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone419
bb_rcgdone419:
  br label %bb_rcslotdone388
bb_rcslotdone388:
  %v2948 = load i64, ptr %slot44, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  %ld2950 = load i64, ptr %p2949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2950, ptr %slot366, align 8
  %v2951 = load i64, ptr %slot366, align 8
  %v2952 = load i64, ptr %slot44, align 8
  %p2953 = inttoptr i64 %v2952 to ptr
  store i64 %v2951, ptr %p2953, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v2954 = load i64, ptr %slot44, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  %ld2956 = load i64, ptr %p2955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2956, ptr %slot367, align 8
  %v2957 = load i64, ptr %slot367, align 8
  %v2958 = load i64, ptr %slot36, align 8
  %p2959 = inttoptr i64 %v2958 to ptr
  store i64 %v2957, ptr %p2959, align 8, !alias.scope !3, !noalias !4
  %v2960 = load i64, ptr %slot36, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  %ld2962 = load i64, ptr %p2961, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2962, ptr %slot368, align 8
  %v2963 = load i64, ptr %slot368, align 8
  %v2964 = load i64, ptr %slot44, align 8
  %p2965 = inttoptr i64 %v2964 to ptr
  store i64 %v2963, ptr %p2965, align 8, !alias.scope !3, !noalias !4
  %v2966 = load i64, ptr %slot45, align 8
  %p2967 = inttoptr i64 %v2966 to ptr
  store i64 48, ptr %p2967, align 8, !alias.scope !3, !noalias !4
  %v2968 = load i64, ptr %slot45, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  %ld2970 = load i64, ptr %p2969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2970, ptr %slot369, align 8
  %v2971 = load i64, ptr %slot44, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  %ld2973 = load i64, ptr %p2972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2973, ptr %slot370, align 8
  %v2974 = load i64, ptr %slot370, align 8
  %v2975 = load i64, ptr %slot369, align 8
  %cmp2976 = icmp sge i64 %v2974, %v2975
  %cv2977 = zext i1 %cmp2976 to i64
  store i64 %cv2977, ptr %slot371, align 8
  %v2978 = load i64, ptr %slot371, align 8
  %v2979 = load i64, ptr %slot44, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  store i64 %v2978, ptr %p2980, align 8, !alias.scope !3, !noalias !4
  %v2981 = load i64, ptr %slot44, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  %ld2983 = load i64, ptr %p2982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2983, ptr %slot372, align 8
  %v2984 = load i64, ptr %slot372, align 8
  %cond2985 = icmp ne i64 %v2984, 0
  br i1 %cond2985, label %bb_next430, label %bb_i30
bb_next430:
  %v2986 = load i64, ptr %slot36, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  %ld2988 = load i64, ptr %p2987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2988, ptr %slot373, align 8
  %v2989 = load i64, ptr %slot373, align 8
  %v2990 = load i64, ptr %slot44, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  store i64 %v2989, ptr %p2991, align 8, !alias.scope !3, !noalias !4
  %v2992 = load i64, ptr %slot45, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  store i64 57, ptr %p2993, align 8, !alias.scope !3, !noalias !4
  %v2994 = load i64, ptr %slot45, align 8
  %p2995 = inttoptr i64 %v2994 to ptr
  %ld2996 = load i64, ptr %p2995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2996, ptr %slot374, align 8
  %v2997 = load i64, ptr %slot44, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  %ld2999 = load i64, ptr %p2998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2999, ptr %slot375, align 8
  %v3000 = load i64, ptr %slot375, align 8
  %v3001 = load i64, ptr %slot374, align 8
  %cmp3002 = icmp sle i64 %v3000, %v3001
  %cv3003 = zext i1 %cmp3002 to i64
  store i64 %cv3003, ptr %slot376, align 8
  %v3004 = load i64, ptr %slot376, align 8
  %v3005 = load i64, ptr %slot44, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  store i64 %v3004, ptr %p3006, align 8, !alias.scope !3, !noalias !4
  br label %bb_i31
bb_i30:
  %v3007 = load i64, ptr %slot44, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  store i64 0, ptr %p3008, align 8, !alias.scope !3, !noalias !4
  br label %bb_i31
bb_i31:
  br label %bb_i32
bb_i32:
  %v3009 = load i64, ptr %slot44, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  %ld3011 = load i64, ptr %p3010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3011, ptr %slot377, align 8
  %v3012 = load i64, ptr %slot377, align 8
  %cond3013 = icmp ne i64 %v3012, 0
  br i1 %cond3013, label %bb_next435, label %bb_i49
bb_next435:
  %v3014 = load i64, ptr %slot30, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  %ld3016 = load i64, ptr %p3015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3016, ptr %slot378, align 8
  %v3017 = load i64, ptr %slot378, align 8
  %v3018 = load i64, ptr %slot44, align 8
  %p3019 = inttoptr i64 %v3018 to ptr
  store i64 %v3017, ptr %p3019, align 8, !alias.scope !3, !noalias !4
  %v3020 = load i64, ptr %slot44, align 8
  %p3021 = inttoptr i64 %v3020 to ptr
  %ld3022 = load i64, ptr %p3021, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3022, ptr %slot379, align 8
  %v3023 = load i64, ptr %slot379, align 8
  %op3024 = add i64 %v3023, 16
  store i64 %op3024, ptr %slot380, align 8
  %v3025 = load i64, ptr %slot380, align 8
  %p3026 = inttoptr i64 %v3025 to ptr
  %ld3027 = load i64, ptr %p3026, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3027, ptr %slot381, align 8
  %v3028 = load i64, ptr %slot381, align 8
  %v3029 = load i64, ptr %slot44, align 8
  %p3030 = inttoptr i64 %v3029 to ptr
  store i64 %v3028, ptr %p3030, align 8, !alias.scope !3, !noalias !4
  %v3031 = load i64, ptr %slot19, align 8
  %p3032 = inttoptr i64 %v3031 to ptr
  %ld3033 = load i32, ptr %p3032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3033, ptr %slot382, align 8
  %v3034 = load i32, ptr %slot382, align 8
  %cv3035 = zext i32 %v3034 to i64
  %cond3036 = icmp ne i64 %cv3035, 0
  br i1 %cond3036, label %bb_rcslotdrop441, label %bb_rcslotdone441
bb_rcslotdrop441:
  %v3037 = load i64, ptr %slot19, align 8
  %p3038 = inttoptr i64 %v3037 to ptr
  store i32 0, ptr %p3038, align 4, !alias.scope !3, !noalias !4
  %v3039 = load i64, ptr %slot25, align 8
  store i64 %v3039, ptr %slot383, align 8
  %v3040 = load i64, ptr %slot20, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  %ld3042 = load i32, ptr %p3041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3042, ptr %slot384, align 8
  %v3043 = load i32, ptr %slot384, align 8
  %op3044 = and i32 %v3043, 28
  store i32 %op3044, ptr %slot385, align 8
  %v3045 = load i32, ptr %slot385, align 8
  %cv3046 = zext i32 %v3045 to i64
  %cond3047 = icmp ne i64 %cv3046, 0
  br i1 %cond3047, label %bb_rcslotrole441, label %bb_rcslotowner441
bb_rcslotrole441:
  %v3048 = load i64, ptr %slot52, align 8
  store i64 %v3048, ptr %slot386, align 8
  %v3049 = load i64, ptr %slot386, align 8
  %v3050 = load i64, ptr %slot383, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3049, i64 %v3050) nomerge, !dbg !130
  br label %bb_rcslotdone441
bb_rcslotowner441:
  %v3051 = load i64, ptr %slot52, align 8
  store i64 %v3051, ptr %slot387, align 8
  %v3052 = load i64, ptr %slot387, align 8
  %v3053 = load i64, ptr %slot383, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3052, i64 %v3053) nomerge, !dbg !130
  br label %bb_rcslotdone441
bb_rcslotdone441:
  %v3054 = load i64, ptr %slot45, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  store i64 1, ptr %p3055, align 8, !alias.scope !3, !noalias !4
  %v3056 = load i64, ptr %slot45, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  %ld3058 = load i64, ptr %p3057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3058, ptr %slot388, align 8
  %v3059 = load i64, ptr %slot44, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  %ld3061 = load i64, ptr %p3060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3061, ptr %slot389, align 8
  %v3062 = load i64, ptr %slot389, align 8
  %v3063 = load i64, ptr %slot388, align 8
  %ovpair3065 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3062, i64 %v3063)
  %op3064 = extractvalue { i64, i1 } %ovpair3065, 0
  %ov3066 = extractvalue { i64, i1 } %ovpair3065, 1
  store i64 %op3064, ptr %slot390, align 8
  %cv3067 = zext i1 %ov3066 to i64
  store i64 %cv3067, ptr %slot391, align 8
  %v3068 = load i64, ptr %slot391, align 8
  %cond3069 = icmp ne i64 %v3068, 0
  br i1 %cond3069, label %bb_overflow450, label %bb_checked450
bb_overflow450:
  %v3070 = load i64, ptr %slot1, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  %v3072 = load i64, ptr %slot389, align 8
  %v3073 = load i64, ptr %slot388, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3071, i64 0, i64 %v3072, i64 %v3073, i64 64) nomerge, !dbg !132
  unreachable
bb_checked450:
  %v3074 = load i64, ptr %slot390, align 8
  %v3075 = load i64, ptr %slot44, align 8
  %p3076 = inttoptr i64 %v3075 to ptr
  store i64 %v3074, ptr %p3076, align 8, !alias.scope !3, !noalias !4
  %v3077 = load i64, ptr %slot44, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  %ld3079 = load i64, ptr %p3078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3079, ptr %slot392, align 8
  %v3080 = load i64, ptr %slot392, align 8
  %v3081 = load i64, ptr %slot31, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  store i64 %v3080, ptr %p3082, align 8, !alias.scope !3, !noalias !4
  %v3083 = load i64, ptr %slot30, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  %ld3085 = load i64, ptr %p3084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3085, ptr %slot393, align 8
  %v3086 = load i64, ptr %slot393, align 8
  %v3087 = load i64, ptr %slot44, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  store i64 %v3086, ptr %p3088, align 8, !alias.scope !3, !noalias !4
  %v3089 = load i64, ptr %slot30, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %ld3091 = load i64, ptr %p3090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3091, ptr %slot394, align 8
  %v3092 = load i64, ptr %slot394, align 8
  %v3093 = load i64, ptr %slot44, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  store i64 %v3092, ptr %p3094, align 8, !alias.scope !3, !noalias !4
  %v3095 = load i64, ptr %slot30, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  %ld3097 = load i64, ptr %p3096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3097, ptr %slot395, align 8
  %v3098 = load i64, ptr %slot395, align 8
  %v3099 = load i64, ptr %slot44, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  store i64 %v3098, ptr %p3100, align 8, !alias.scope !3, !noalias !4
  %v3101 = load i64, ptr %slot31, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %ld3103 = load i64, ptr %p3102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3103, ptr %slot396, align 8
  %v3104 = load i64, ptr %slot396, align 8
  %v3105 = load i64, ptr %slot45, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  store i64 %v3104, ptr %p3106, align 8, !alias.scope !3, !noalias !4
  %v3107 = load i64, ptr %slot30, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  %ld3109 = load i64, ptr %p3108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3109, ptr %slot397, align 8
  %v3110 = load i64, ptr %slot397, align 8
  %v3111 = load i64, ptr %slot44, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  store i64 %v3110, ptr %p3112, align 8, !alias.scope !3, !noalias !4
  %v3113 = load i64, ptr %slot31, align 8
  %p3114 = inttoptr i64 %v3113 to ptr
  %ld3115 = load i64, ptr %p3114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3115, ptr %slot398, align 8
  %v3116 = load i64, ptr %slot30, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  %ld3118 = load i64, ptr %p3117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3118, ptr %slot399, align 8
  %v3119 = load i64, ptr %slot399, align 8
  %op3120 = add i64 %v3119, 16
  store i64 %op3120, ptr %slot400, align 8
  %v3121 = load i64, ptr %slot398, align 8
  %v3122 = load i64, ptr %slot400, align 8
  %p3123 = inttoptr i64 %v3122 to ptr
  store i64 %v3121, ptr %p3123, align 8, !alias.scope !4, !noalias !3
  %v3124 = load i64, ptr %slot44, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  store i64 0, ptr %p3125, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i49:
  %v3126 = load i64, ptr %slot30, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  %ld3128 = load i64, ptr %p3127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3128, ptr %slot401, align 8
  %v3129 = load i64, ptr %slot401, align 8
  %v3130 = load i64, ptr %slot44, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  store i64 %v3129, ptr %p3131, align 8, !alias.scope !3, !noalias !4
  %v3132 = load i64, ptr %slot44, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  %ld3134 = load i64, ptr %p3133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3134, ptr %slot402, align 8
  %v3135 = load i64, ptr %slot19, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  %ld3137 = load i32, ptr %p3136, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3137, ptr %slot403, align 8
  %v3138 = load i64, ptr %slot20, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  %ld3140 = load i32, ptr %p3139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3140, ptr %slot404, align 8
  %v3141 = load i32, ptr %slot404, align 8
  %op3142 = and i32 %v3141, 24
  store i32 %op3142, ptr %slot404, align 8
  %v3143 = load i32, ptr %slot404, align 8
  %cmp3144 = icmp eq i32 %v3143, 0
  %cv3145 = zext i1 %cmp3144 to i32
  store i32 %cv3145, ptr %slot405, align 8
  %v3146 = load i32, ptr %slot403, align 8
  %v3147 = load i32, ptr %slot405, align 8
  %op3148 = and i32 %v3146, %v3147
  store i32 %op3148, ptr %slot406, align 8
  %v3149 = load i32, ptr %slot406, align 8
  %cv3150 = zext i32 %v3149 to i64
  %cond3151 = icmp ne i64 %cv3150, 0
  br i1 %cond3151, label %bb_rctake463, label %bb_rccopy463
bb_rctake463:
  %v3152 = load i64, ptr %slot29, align 8
  store i64 %v3152, ptr %slot407, align 8
  %v3153 = load i64, ptr %slot53, align 8
  store i64 %v3153, ptr %slot408, align 8
  %v3154 = load i64, ptr %slot402, align 8
  %v3155 = load i64, ptr %slot407, align 8
  %op3156 = sub i64 %v3154, %v3155
  store i64 %op3156, ptr %slot409, align 8
  %v3157 = load i64, ptr %slot407, align 8
  %v3158 = load i64, ptr %slot402, align 8
  %op3159 = sub i64 %v3157, %v3158
  store i64 %op3159, ptr %slot410, align 8
  %v3160 = load i64, ptr %slot409, align 8
  %cmp3161 = icmp ult i64 %v3160, 32
  %cv3162 = zext i1 %cmp3161 to i32
  store i32 %cv3162, ptr %slot411, align 8
  %v3163 = load i64, ptr %slot410, align 8
  %cmp3164 = icmp ult i64 %v3163, 32
  %cv3165 = zext i1 %cmp3164 to i32
  store i32 %cv3165, ptr %slot412, align 8
  %v3166 = load i32, ptr %slot411, align 8
  %v3167 = load i32, ptr %slot412, align 8
  %op3168 = or i32 %v3166, %v3167
  store i32 %op3168, ptr %slot413, align 8
  %v3169 = load i32, ptr %slot413, align 8
  %cv3170 = zext i32 %v3169 to i64
  %cond3171 = icmp ne i64 %cv3170, 0
  br i1 %cond3171, label %bb_rcmoveslow472, label %bb_rcmovecheck472
bb_rcmovecheck472:
  %v3172 = load i64, ptr %slot402, align 8
  %op3173 = add i64 %v3172, 0
  store i64 %op3173, ptr %slot414, align 8
  %v3174 = load i64, ptr %slot414, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  %ld3176 = load i64, ptr %p3175, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3176, ptr %slot415, align 8
  %v3177 = load i64, ptr %slot415, align 8
  %cmp3178 = icmp ne i64 %v3177, 0
  %cv3179 = zext i1 %cmp3178 to i32
  store i32 %cv3179, ptr %slot416, align 8
  %v3180 = load i32, ptr %slot416, align 8
  %cv3181 = zext i32 %v3180 to i64
  %cond3182 = icmp ne i64 %cv3181, 0
  br i1 %cond3182, label %bb_rcmoveheader480, label %bb_rcmovenext480
bb_rcmoveheader480:
  %v3183 = load i64, ptr %slot415, align 8
  %op3184 = sub i64 %v3183, 16
  store i64 %op3184, ptr %slot417, align 8
  %v3185 = load i64, ptr %slot415, align 8
  %p3186 = inttoptr i64 %v3185 to ptr
  %rgep3187 = getelementptr i8, ptr %p3186, i64 -16
  %ld3188 = load i64, ptr %rgep3187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3188, ptr %slot418, align 8
  %v3189 = load i64, ptr %slot418, align 8
  %op3190 = and i64 %v3189, 5764607523034234881
  store i64 %op3190, ptr %slot419, align 8
  %v3191 = load i64, ptr %slot419, align 8
  %cmp3192 = icmp ne i64 %v3191, 0
  %cv3193 = zext i1 %cmp3192 to i32
  store i32 %cv3193, ptr %slot420, align 8
  %v3194 = load i32, ptr %slot420, align 8
  %cv3195 = zext i32 %v3194 to i64
  %cond3196 = icmp ne i64 %cv3195, 0
  br i1 %cond3196, label %bb_rcmoveslow472, label %bb_rcmovenext480
bb_rcmovenext480:
  %v3197 = load i64, ptr %slot402, align 8
  %v3198 = load i64, ptr %slot407, align 8
  %p3199 = inttoptr i64 %v3197 to ptr
  %p3200 = inttoptr i64 %v3198 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3200, ptr %p3199, i64 32, i1 false), !alias.scope !10000000
  %v3201 = load i64, ptr %slot402, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  store i64 0, ptr %p3202, align 8, !alias.scope !4, !noalias !3
  %v3203 = load i64, ptr %slot402, align 8
  %op3204 = add i64 %v3203, 8
  store i64 %op3204, ptr %slot421, align 8
  %v3205 = load i64, ptr %slot421, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  store i64 0, ptr %p3206, align 8, !alias.scope !4, !noalias !3
  %v3207 = load i64, ptr %slot402, align 8
  %op3208 = add i64 %v3207, 16
  store i64 %op3208, ptr %slot422, align 8
  %v3209 = load i64, ptr %slot422, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  store i64 0, ptr %p3210, align 8, !alias.scope !4, !noalias !3
  %v3211 = load i64, ptr %slot402, align 8
  %op3212 = add i64 %v3211, 24
  store i64 %op3212, ptr %slot423, align 8
  %v3213 = load i64, ptr %slot423, align 8
  %p3214 = inttoptr i64 %v3213 to ptr
  store i64 0, ptr %p3214, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved472
bb_rcmoveslow472:
  %v3215 = load i64, ptr %slot52, align 8
  %v3216 = load i64, ptr %slot407, align 8
  %v3217 = load i64, ptr %slot402, align 8
  %v3218 = load i64, ptr %slot408, align 8
  %cv3219 = trunc i64 %v3218 to i32
  %call3220 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v3215, i64 %v3216, i64 %v3217, i32 %cv3219) nomerge, !dbg !134
  store i32 %call3220, ptr %slot424, align 8
  %v3221 = load i32, ptr %slot424, align 8
  %cv3222 = zext i32 %v3221 to i64
  %cond3223 = icmp ne i64 %cv3222, 0
  br i1 %cond3223, label %bb_rcsuccess490, label %bb_rcfailure490
bb_rcfailure490:
  %v3224 = load i64, ptr %slot52, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  %call3226 = call i32 @myl_rc_take_failure(ptr %p3225) nomerge, !dbg !134
  store i32 %call3226, ptr %slot425, align 8
  %v3227 = load i64, ptr %slot1, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  %v3229 = load i32, ptr %slot425, align 8
  %call3230 = call i32 @myl_qbe_rc_status(ptr %p3228, i32 %v3229) nomerge, !dbg !134
  store i32 %call3230, ptr %slot426, align 8
  br label %bb_failure
bb_rcsuccess490:
  br label %bb_rcmoved472
bb_rcmoved472:
  %v3231 = load i64, ptr %slot19, align 8
  %p3232 = inttoptr i64 %v3231 to ptr
  store i32 0, ptr %p3232, align 4, !alias.scope !3, !noalias !4
  %v3233 = load i64, ptr %slot24, align 8
  %p3234 = inttoptr i64 %v3233 to ptr
  store i32 2, ptr %p3234, align 4, !alias.scope !3, !noalias !4
  %v3235 = load i64, ptr %slot23, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  store i32 1, ptr %p3236, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared463
bb_rccopy463:
  %v3237 = load i64, ptr %slot29, align 8
  store i64 %v3237, ptr %slot427, align 8
  %v3238 = load i64, ptr %slot53, align 8
  store i64 %v3238, ptr %slot428, align 8
  %v3239 = load i64, ptr %slot52, align 8
  %v3240 = load i64, ptr %slot427, align 8
  %v3241 = load i64, ptr %slot402, align 8
  %v3242 = load i64, ptr %slot428, align 8
  %cv3243 = trunc i64 %v3242 to i32
  %call3244 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v3239, i64 %v3240, i64 %v3241, i32 %cv3243) nomerge, !dbg !134
  store i32 %call3244, ptr %slot429, align 8
  %v3245 = load i32, ptr %slot429, align 8
  %cv3246 = zext i32 %v3245 to i64
  %cond3247 = icmp ne i64 %cv3246, 0
  br i1 %cond3247, label %bb_rcsuccess499, label %bb_rcfailure499
bb_rcfailure499:
  %v3248 = load i64, ptr %slot52, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %call3250 = call i32 @myl_rc_take_failure(ptr %p3249) nomerge, !dbg !134
  store i32 %call3250, ptr %slot430, align 8
  %v3251 = load i64, ptr %slot1, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  %v3253 = load i32, ptr %slot430, align 8
  %call3254 = call i32 @myl_qbe_rc_status(ptr %p3252, i32 %v3253) nomerge, !dbg !134
  store i32 %call3254, ptr %slot431, align 8
  br label %bb_failure
bb_rcsuccess499:
  %v3255 = load i64, ptr %slot24, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  store i32 2, ptr %p3256, align 4, !alias.scope !3, !noalias !4
  %v3257 = load i64, ptr %slot23, align 8
  %p3258 = inttoptr i64 %v3257 to ptr
  store i32 1, ptr %p3258, align 4, !alias.scope !3, !noalias !4
  %v3259 = load i64, ptr %slot19, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  %ld3261 = load i32, ptr %p3260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3261, ptr %slot432, align 8
  %v3262 = load i32, ptr %slot432, align 8
  %cv3263 = zext i32 %v3262 to i64
  %cond3264 = icmp ne i64 %cv3263, 0
  br i1 %cond3264, label %bb_rcslotdrop506, label %bb_rcslotdone506
bb_rcslotdrop506:
  %v3265 = load i64, ptr %slot19, align 8
  %p3266 = inttoptr i64 %v3265 to ptr
  store i32 0, ptr %p3266, align 4, !alias.scope !3, !noalias !4
  %v3267 = load i64, ptr %slot25, align 8
  store i64 %v3267, ptr %slot433, align 8
  %v3268 = load i64, ptr %slot20, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %ld3270 = load i32, ptr %p3269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3270, ptr %slot434, align 8
  %v3271 = load i32, ptr %slot434, align 8
  %op3272 = and i32 %v3271, 28
  store i32 %op3272, ptr %slot435, align 8
  %v3273 = load i32, ptr %slot435, align 8
  %cv3274 = zext i32 %v3273 to i64
  %cond3275 = icmp ne i64 %cv3274, 0
  br i1 %cond3275, label %bb_rcslotrole506, label %bb_rcslotowner506
bb_rcslotrole506:
  %v3276 = load i64, ptr %slot52, align 8
  store i64 %v3276, ptr %slot436, align 8
  %v3277 = load i64, ptr %slot436, align 8
  %v3278 = load i64, ptr %slot433, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3277, i64 %v3278) nomerge, !dbg !134
  br label %bb_rcslotdone506
bb_rcslotowner506:
  %v3279 = load i64, ptr %slot433, align 8
  %p3281 = inttoptr i64 %v3279 to ptr
  %gep3282 = getelementptr i8, ptr %p3281, i64 0
  %op3280 = ptrtoint ptr %gep3282 to i64
  store i64 %op3280, ptr %slot437, align 8
  %v3283 = load i64, ptr %slot52, align 8
  store i64 %v3283, ptr %slot438, align 8
  %v3284 = load i64, ptr %slot437, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  %ld3286 = load i64, ptr %p3285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3286, ptr %slot439, align 8
  %v3287 = load i64, ptr %slot439, align 8
  %cmp3288 = icmp ne i64 %v3287, 0
  %cv3289 = zext i1 %cmp3288 to i32
  store i32 %cv3289, ptr %slot440, align 8
  %v3290 = load i32, ptr %slot440, align 8
  %cv3291 = zext i32 %v3290 to i64
  %cond3292 = icmp ne i64 %cv3291, 0
  br i1 %cond3292, label %bb_rcgnn524, label %bb_rcgdone524
bb_rcgnn524:
  %v3293 = load i64, ptr %slot439, align 8
  %op3294 = sub i64 %v3293, 16
  store i64 %op3294, ptr %slot441, align 8
  %v3295 = load i64, ptr %slot439, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  %rgep3297 = getelementptr i8, ptr %p3296, i64 -16
  %ld3298 = load i64, ptr %rgep3297, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3298, ptr %slot442, align 8
  %v3299 = load i64, ptr %slot442, align 8
  %op3300 = and i64 %v3299, 4611686018427387906
  store i64 %op3300, ptr %slot443, align 8
  %v3301 = load i64, ptr %slot443, align 8
  %cmp3302 = icmp ne i64 %v3301, 0
  %cv3303 = zext i1 %cmp3302 to i32
  store i32 %cv3303, ptr %slot444, align 8
  %v3304 = load i32, ptr %slot444, align 8
  %cv3305 = zext i32 %v3304 to i64
  %cond3306 = icmp ne i64 %cv3305, 0
  br i1 %cond3306, label %bb_rcgclear524, label %bb_rcgcounted524
bb_rcgcounted524:
  %v3307 = load i64, ptr %slot439, align 8
  %op3308 = sub i64 %v3307, 32
  store i64 %op3308, ptr %slot445, align 8
  %v3309 = load i64, ptr %slot439, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  %rgep3311 = getelementptr i8, ptr %p3310, i64 -32
  %ld3312 = load i64, ptr %rgep3311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3312, ptr %slot446, align 8
  %v3313 = load i64, ptr %slot446, align 8
  %op3314 = sub i64 %v3313, 1
  store i64 %op3314, ptr %slot447, align 8
  %v3315 = load i64, ptr %slot447, align 8
  %cmp3316 = icmp eq i64 %v3315, 0
  %cv3317 = zext i1 %cmp3316 to i32
  store i32 %cv3317, ptr %slot448, align 8
  %v3318 = load i32, ptr %slot448, align 8
  %cv3319 = zext i32 %v3318 to i64
  %cond3320 = icmp ne i64 %cv3319, 0
  br i1 %cond3320, label %bb_rcglast524, label %bb_rcgdec524
bb_rcglast524:
  %v3321 = load i64, ptr %slot439, align 8
  %op3322 = sub i64 %v3321, 24
  store i64 %op3322, ptr %slot449, align 8
  %v3323 = load i64, ptr %slot439, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  %rgep3325 = getelementptr i8, ptr %p3324, i64 -24
  %ld3326 = load i64, ptr %rgep3325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3326, ptr %slot450, align 8
  %v3327 = load i64, ptr %slot450, align 8
  %cmp3328 = icmp ne i64 %v3327, 0
  %cv3329 = zext i1 %cmp3328 to i32
  store i32 %cv3329, ptr %slot451, align 8
  %v3330 = load i32, ptr %slot451, align 8
  %cv3331 = zext i32 %v3330 to i64
  %cond3332 = icmp ne i64 %cv3331, 0
  br i1 %cond3332, label %bb_rcgdec524, label %bb_rcgslow524
bb_rcgslow524:
  %v3333 = load i64, ptr %slot438, align 8
  %v3334 = load i64, ptr %slot437, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3333, i64 %v3334) nomerge, !dbg !134
  br label %bb_rcgdone524
bb_rcgdec524:
  %v3335 = load i64, ptr %slot447, align 8
  %v3336 = load i64, ptr %slot439, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  %rgep3338 = getelementptr i8, ptr %p3337, i64 -32
  store i64 %v3335, ptr %rgep3338, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear524
bb_rcgclear524:
  %v3339 = load i64, ptr %slot437, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i64 0, ptr %p3340, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone524
bb_rcgdone524:
  %v3341 = load i64, ptr %slot433, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  store i64 0, ptr %p3342, align 8, !alias.scope !3, !noalias !4
  %v3343 = load i64, ptr %slot433, align 8
  %p3345 = inttoptr i64 %v3343 to ptr
  %gep3346 = getelementptr i8, ptr %p3345, i64 8
  %op3344 = ptrtoint ptr %gep3346 to i64
  store i64 %op3344, ptr %slot452, align 8
  %v3347 = load i64, ptr %slot452, align 8
  %p3348 = inttoptr i64 %v3347 to ptr
  store i64 0, ptr %p3348, align 8, !alias.scope !3, !noalias !4
  %v3349 = load i64, ptr %slot433, align 8
  %p3351 = inttoptr i64 %v3349 to ptr
  %gep3352 = getelementptr i8, ptr %p3351, i64 16
  %op3350 = ptrtoint ptr %gep3352 to i64
  store i64 %op3350, ptr %slot453, align 8
  %v3353 = load i64, ptr %slot453, align 8
  %p3354 = inttoptr i64 %v3353 to ptr
  store i64 0, ptr %p3354, align 8, !alias.scope !3, !noalias !4
  %v3355 = load i64, ptr %slot433, align 8
  %p3357 = inttoptr i64 %v3355 to ptr
  %gep3358 = getelementptr i8, ptr %p3357, i64 24
  %op3356 = ptrtoint ptr %gep3358 to i64
  store i64 %op3356, ptr %slot454, align 8
  %v3359 = load i64, ptr %slot454, align 8
  %p3360 = inttoptr i64 %v3359 to ptr
  store i64 0, ptr %p3360, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone506
bb_rcslotdone506:
  br label %bb_rcprepared463
bb_rcprepared463:
  %v3361 = load i64, ptr %slot9, align 8
  %p3362 = inttoptr i64 %v3361 to ptr
  %ld3363 = load i32, ptr %p3362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3363, ptr %slot455, align 8
  %v3364 = load i32, ptr %slot455, align 8
  %cv3365 = zext i32 %v3364 to i64
  %cond3366 = icmp ne i64 %cv3365, 0
  br i1 %cond3366, label %bb_rcslotdrop534, label %bb_rcslotdone534
bb_rcslotdrop534:
  %v3367 = load i64, ptr %slot9, align 8
  %p3368 = inttoptr i64 %v3367 to ptr
  store i32 0, ptr %p3368, align 4, !alias.scope !3, !noalias !4
  %v3369 = load i64, ptr %slot37, align 8
  store i64 %v3369, ptr %slot456, align 8
  %v3370 = load i64, ptr %slot10, align 8
  %p3371 = inttoptr i64 %v3370 to ptr
  %ld3372 = load i32, ptr %p3371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3372, ptr %slot457, align 8
  %v3373 = load i32, ptr %slot457, align 8
  %op3374 = and i32 %v3373, 28
  store i32 %op3374, ptr %slot458, align 8
  %v3375 = load i32, ptr %slot458, align 8
  %cv3376 = zext i32 %v3375 to i64
  %cond3377 = icmp ne i64 %cv3376, 0
  br i1 %cond3377, label %bb_rcslotrole534, label %bb_rcslotowner534
bb_rcslotrole534:
  %v3378 = load i64, ptr %slot52, align 8
  store i64 %v3378, ptr %slot459, align 8
  %v3379 = load i64, ptr %slot459, align 8
  %v3380 = load i64, ptr %slot456, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3379, i64 %v3380) nomerge, !dbg !134
  br label %bb_rcslotdone534
bb_rcslotowner534:
  %v3381 = load i64, ptr %slot456, align 8
  %p3383 = inttoptr i64 %v3381 to ptr
  %gep3384 = getelementptr i8, ptr %p3383, i64 0
  %op3382 = ptrtoint ptr %gep3384 to i64
  store i64 %op3382, ptr %slot460, align 8
  %v3385 = load i64, ptr %slot52, align 8
  store i64 %v3385, ptr %slot461, align 8
  %v3386 = load i64, ptr %slot460, align 8
  %p3387 = inttoptr i64 %v3386 to ptr
  %ld3388 = load i64, ptr %p3387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3388, ptr %slot462, align 8
  %v3389 = load i64, ptr %slot462, align 8
  %cmp3390 = icmp ne i64 %v3389, 0
  %cv3391 = zext i1 %cmp3390 to i32
  store i32 %cv3391, ptr %slot463, align 8
  %v3392 = load i32, ptr %slot463, align 8
  %cv3393 = zext i32 %v3392 to i64
  %cond3394 = icmp ne i64 %cv3393, 0
  br i1 %cond3394, label %bb_rcgnn552, label %bb_rcgdone552
bb_rcgnn552:
  %v3395 = load i64, ptr %slot462, align 8
  %op3396 = sub i64 %v3395, 16
  store i64 %op3396, ptr %slot464, align 8
  %v3397 = load i64, ptr %slot462, align 8
  %p3398 = inttoptr i64 %v3397 to ptr
  %rgep3399 = getelementptr i8, ptr %p3398, i64 -16
  %ld3400 = load i64, ptr %rgep3399, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3400, ptr %slot465, align 8
  %v3401 = load i64, ptr %slot465, align 8
  %op3402 = and i64 %v3401, 4611686018427387906
  store i64 %op3402, ptr %slot466, align 8
  %v3403 = load i64, ptr %slot466, align 8
  %cmp3404 = icmp ne i64 %v3403, 0
  %cv3405 = zext i1 %cmp3404 to i32
  store i32 %cv3405, ptr %slot467, align 8
  %v3406 = load i32, ptr %slot467, align 8
  %cv3407 = zext i32 %v3406 to i64
  %cond3408 = icmp ne i64 %cv3407, 0
  br i1 %cond3408, label %bb_rcgclear552, label %bb_rcgcounted552
bb_rcgcounted552:
  %v3409 = load i64, ptr %slot462, align 8
  %op3410 = sub i64 %v3409, 32
  store i64 %op3410, ptr %slot468, align 8
  %v3411 = load i64, ptr %slot462, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  %rgep3413 = getelementptr i8, ptr %p3412, i64 -32
  %ld3414 = load i64, ptr %rgep3413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3414, ptr %slot469, align 8
  %v3415 = load i64, ptr %slot469, align 8
  %op3416 = sub i64 %v3415, 1
  store i64 %op3416, ptr %slot470, align 8
  %v3417 = load i64, ptr %slot470, align 8
  %cmp3418 = icmp eq i64 %v3417, 0
  %cv3419 = zext i1 %cmp3418 to i32
  store i32 %cv3419, ptr %slot471, align 8
  %v3420 = load i32, ptr %slot471, align 8
  %cv3421 = zext i32 %v3420 to i64
  %cond3422 = icmp ne i64 %cv3421, 0
  br i1 %cond3422, label %bb_rcglast552, label %bb_rcgdec552
bb_rcglast552:
  %v3423 = load i64, ptr %slot462, align 8
  %op3424 = sub i64 %v3423, 24
  store i64 %op3424, ptr %slot472, align 8
  %v3425 = load i64, ptr %slot462, align 8
  %p3426 = inttoptr i64 %v3425 to ptr
  %rgep3427 = getelementptr i8, ptr %p3426, i64 -24
  %ld3428 = load i64, ptr %rgep3427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3428, ptr %slot473, align 8
  %v3429 = load i64, ptr %slot473, align 8
  %cmp3430 = icmp ne i64 %v3429, 0
  %cv3431 = zext i1 %cmp3430 to i32
  store i32 %cv3431, ptr %slot474, align 8
  %v3432 = load i32, ptr %slot474, align 8
  %cv3433 = zext i32 %v3432 to i64
  %cond3434 = icmp ne i64 %cv3433, 0
  br i1 %cond3434, label %bb_rcgdec552, label %bb_rcgslow552
bb_rcgslow552:
  %v3435 = load i64, ptr %slot461, align 8
  %v3436 = load i64, ptr %slot460, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3435, i64 %v3436) nomerge, !dbg !134
  br label %bb_rcgdone552
bb_rcgdec552:
  %v3437 = load i64, ptr %slot470, align 8
  %v3438 = load i64, ptr %slot462, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  %rgep3440 = getelementptr i8, ptr %p3439, i64 -32
  store i64 %v3437, ptr %rgep3440, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear552
bb_rcgclear552:
  %v3441 = load i64, ptr %slot460, align 8
  %p3442 = inttoptr i64 %v3441 to ptr
  store i64 0, ptr %p3442, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone552
bb_rcgdone552:
  %v3443 = load i64, ptr %slot456, align 8
  %p3444 = inttoptr i64 %v3443 to ptr
  store i64 0, ptr %p3444, align 8, !alias.scope !3, !noalias !4
  %v3445 = load i64, ptr %slot456, align 8
  %p3447 = inttoptr i64 %v3445 to ptr
  %gep3448 = getelementptr i8, ptr %p3447, i64 8
  %op3446 = ptrtoint ptr %gep3448 to i64
  store i64 %op3446, ptr %slot475, align 8
  %v3449 = load i64, ptr %slot475, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  store i64 0, ptr %p3450, align 8, !alias.scope !3, !noalias !4
  %v3451 = load i64, ptr %slot456, align 8
  %p3453 = inttoptr i64 %v3451 to ptr
  %gep3454 = getelementptr i8, ptr %p3453, i64 16
  %op3452 = ptrtoint ptr %gep3454 to i64
  store i64 %op3452, ptr %slot476, align 8
  %v3455 = load i64, ptr %slot476, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i64 0, ptr %p3456, align 8, !alias.scope !3, !noalias !4
  %v3457 = load i64, ptr %slot456, align 8
  %p3459 = inttoptr i64 %v3457 to ptr
  %gep3460 = getelementptr i8, ptr %p3459, i64 24
  %op3458 = ptrtoint ptr %gep3460 to i64
  store i64 %op3458, ptr %slot477, align 8
  %v3461 = load i64, ptr %slot477, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  store i64 0, ptr %p3462, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone534
bb_rcslotdone534:
  %v3463 = load i64, ptr %slot37, align 8
  store i64 %v3463, ptr %slot478, align 8
  %v3464 = load i64, ptr %slot29, align 8
  store i64 %v3464, ptr %slot479, align 8
  %v3465 = load i64, ptr %slot479, align 8
  %v3466 = load i64, ptr %slot478, align 8
  %p3467 = inttoptr i64 %v3465 to ptr
  %p3468 = inttoptr i64 %v3466 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3468, ptr %p3467, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3469 = load i64, ptr %slot23, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  store i32 0, ptr %p3470, align 4, !alias.scope !3, !noalias !4
  %v3471 = load i64, ptr %slot10, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  store i32 2, ptr %p3472, align 4, !alias.scope !3, !noalias !4
  %v3473 = load i64, ptr %slot24, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  %ld3475 = load i32, ptr %p3474, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3475, ptr %slot480, align 8
  %v3476 = load i32, ptr %slot480, align 8
  %v3477 = load i64, ptr %slot10, align 8
  %p3478 = inttoptr i64 %v3477 to ptr
  store i32 %v3476, ptr %p3478, align 4, !alias.scope !3, !noalias !4
  %v3479 = load i64, ptr %slot9, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  store i32 1, ptr %p3480, align 4, !alias.scope !3, !noalias !4
  %v3481 = load i64, ptr %slot37, align 8
  %v3482 = load i64, ptr %slot44, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  store i64 %v3481, ptr %p3483, align 8, !alias.scope !3, !noalias !4
  %v3484 = load i64, ptr %slot44, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  %ld3486 = load i64, ptr %p3485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3486, ptr %slot481, align 8
  %v3487 = load i64, ptr %slot19, align 8
  %p3488 = inttoptr i64 %v3487 to ptr
  %ld3489 = load i32, ptr %p3488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3489, ptr %slot482, align 8
  %v3490 = load i64, ptr %slot20, align 8
  %p3491 = inttoptr i64 %v3490 to ptr
  %ld3492 = load i32, ptr %p3491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3492, ptr %slot483, align 8
  %v3493 = load i32, ptr %slot483, align 8
  %op3494 = and i32 %v3493, 24
  store i32 %op3494, ptr %slot483, align 8
  %v3495 = load i32, ptr %slot483, align 8
  %cmp3496 = icmp eq i32 %v3495, 0
  %cv3497 = zext i1 %cmp3496 to i32
  store i32 %cv3497, ptr %slot484, align 8
  %v3498 = load i32, ptr %slot482, align 8
  %v3499 = load i32, ptr %slot484, align 8
  %op3500 = and i32 %v3498, %v3499
  store i32 %op3500, ptr %slot485, align 8
  %v3501 = load i32, ptr %slot485, align 8
  %cv3502 = zext i32 %v3501 to i64
  %cond3503 = icmp ne i64 %cv3502, 0
  br i1 %cond3503, label %bb_rctake567, label %bb_rccopy567
bb_rctake567:
  %v3504 = load i64, ptr %slot29, align 8
  store i64 %v3504, ptr %slot486, align 8
  %v3505 = load i64, ptr %slot53, align 8
  store i64 %v3505, ptr %slot487, align 8
  %v3506 = load i64, ptr %slot481, align 8
  %v3507 = load i64, ptr %slot486, align 8
  %op3508 = sub i64 %v3506, %v3507
  store i64 %op3508, ptr %slot488, align 8
  %v3509 = load i64, ptr %slot486, align 8
  %v3510 = load i64, ptr %slot481, align 8
  %op3511 = sub i64 %v3509, %v3510
  store i64 %op3511, ptr %slot489, align 8
  %v3512 = load i64, ptr %slot488, align 8
  %cmp3513 = icmp ult i64 %v3512, 32
  %cv3514 = zext i1 %cmp3513 to i32
  store i32 %cv3514, ptr %slot490, align 8
  %v3515 = load i64, ptr %slot489, align 8
  %cmp3516 = icmp ult i64 %v3515, 32
  %cv3517 = zext i1 %cmp3516 to i32
  store i32 %cv3517, ptr %slot491, align 8
  %v3518 = load i32, ptr %slot490, align 8
  %v3519 = load i32, ptr %slot491, align 8
  %op3520 = or i32 %v3518, %v3519
  store i32 %op3520, ptr %slot492, align 8
  %v3521 = load i32, ptr %slot492, align 8
  %cv3522 = zext i32 %v3521 to i64
  %cond3523 = icmp ne i64 %cv3522, 0
  br i1 %cond3523, label %bb_rcmoveslow576, label %bb_rcmovecheck576
bb_rcmovecheck576:
  %v3524 = load i64, ptr %slot481, align 8
  %op3525 = add i64 %v3524, 0
  store i64 %op3525, ptr %slot493, align 8
  %v3526 = load i64, ptr %slot493, align 8
  %p3527 = inttoptr i64 %v3526 to ptr
  %ld3528 = load i64, ptr %p3527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3528, ptr %slot494, align 8
  %v3529 = load i64, ptr %slot494, align 8
  %cmp3530 = icmp ne i64 %v3529, 0
  %cv3531 = zext i1 %cmp3530 to i32
  store i32 %cv3531, ptr %slot495, align 8
  %v3532 = load i32, ptr %slot495, align 8
  %cv3533 = zext i32 %v3532 to i64
  %cond3534 = icmp ne i64 %cv3533, 0
  br i1 %cond3534, label %bb_rcmoveheader584, label %bb_rcmovenext584
bb_rcmoveheader584:
  %v3535 = load i64, ptr %slot494, align 8
  %op3536 = sub i64 %v3535, 16
  store i64 %op3536, ptr %slot496, align 8
  %v3537 = load i64, ptr %slot494, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  %rgep3539 = getelementptr i8, ptr %p3538, i64 -16
  %ld3540 = load i64, ptr %rgep3539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3540, ptr %slot497, align 8
  %v3541 = load i64, ptr %slot497, align 8
  %op3542 = and i64 %v3541, 5764607523034234881
  store i64 %op3542, ptr %slot498, align 8
  %v3543 = load i64, ptr %slot498, align 8
  %cmp3544 = icmp ne i64 %v3543, 0
  %cv3545 = zext i1 %cmp3544 to i32
  store i32 %cv3545, ptr %slot499, align 8
  %v3546 = load i32, ptr %slot499, align 8
  %cv3547 = zext i32 %v3546 to i64
  %cond3548 = icmp ne i64 %cv3547, 0
  br i1 %cond3548, label %bb_rcmoveslow576, label %bb_rcmovenext584
bb_rcmovenext584:
  %v3549 = load i64, ptr %slot481, align 8
  %v3550 = load i64, ptr %slot486, align 8
  %p3551 = inttoptr i64 %v3549 to ptr
  %p3552 = inttoptr i64 %v3550 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3552, ptr %p3551, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3553 = load i64, ptr %slot481, align 8
  %p3554 = inttoptr i64 %v3553 to ptr
  store i64 0, ptr %p3554, align 8, !alias.scope !3, !noalias !4
  %v3555 = load i64, ptr %slot481, align 8
  %op3556 = add i64 %v3555, 8
  store i64 %op3556, ptr %slot500, align 8
  %v3557 = load i64, ptr %slot500, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  store i64 0, ptr %p3558, align 8, !alias.scope !3, !noalias !4
  %v3559 = load i64, ptr %slot481, align 8
  %op3560 = add i64 %v3559, 16
  store i64 %op3560, ptr %slot501, align 8
  %v3561 = load i64, ptr %slot501, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  store i64 0, ptr %p3562, align 8, !alias.scope !3, !noalias !4
  %v3563 = load i64, ptr %slot481, align 8
  %op3564 = add i64 %v3563, 24
  store i64 %op3564, ptr %slot502, align 8
  %v3565 = load i64, ptr %slot502, align 8
  %p3566 = inttoptr i64 %v3565 to ptr
  store i64 0, ptr %p3566, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved576
bb_rcmoveslow576:
  %v3567 = load i64, ptr %slot52, align 8
  %v3568 = load i64, ptr %slot486, align 8
  %v3569 = load i64, ptr %slot481, align 8
  %v3570 = load i64, ptr %slot487, align 8
  %cv3571 = trunc i64 %v3570 to i32
  %call3572 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v3567, i64 %v3568, i64 %v3569, i32 %cv3571) nomerge, !dbg !136
  store i32 %call3572, ptr %slot503, align 8
  %v3573 = load i32, ptr %slot503, align 8
  %cv3574 = zext i32 %v3573 to i64
  %cond3575 = icmp ne i64 %cv3574, 0
  br i1 %cond3575, label %bb_rcsuccess594, label %bb_rcfailure594
bb_rcfailure594:
  %v3576 = load i64, ptr %slot52, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  %call3578 = call i32 @myl_rc_take_failure(ptr %p3577) nomerge, !dbg !136
  store i32 %call3578, ptr %slot504, align 8
  %v3579 = load i64, ptr %slot1, align 8
  %p3580 = inttoptr i64 %v3579 to ptr
  %v3581 = load i32, ptr %slot504, align 8
  %call3582 = call i32 @myl_qbe_rc_status(ptr %p3580, i32 %v3581) nomerge, !dbg !136
  store i32 %call3582, ptr %slot505, align 8
  br label %bb_failure
bb_rcsuccess594:
  br label %bb_rcmoved576
bb_rcmoved576:
  %v3583 = load i64, ptr %slot19, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  store i32 0, ptr %p3584, align 4, !alias.scope !3, !noalias !4
  %v3585 = load i64, ptr %slot24, align 8
  %p3586 = inttoptr i64 %v3585 to ptr
  store i32 2, ptr %p3586, align 4, !alias.scope !3, !noalias !4
  %v3587 = load i64, ptr %slot23, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  store i32 1, ptr %p3588, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared567
bb_rccopy567:
  %v3589 = load i64, ptr %slot29, align 8
  store i64 %v3589, ptr %slot506, align 8
  %v3590 = load i64, ptr %slot53, align 8
  store i64 %v3590, ptr %slot507, align 8
  %v3591 = load i64, ptr %slot52, align 8
  %v3592 = load i64, ptr %slot506, align 8
  %v3593 = load i64, ptr %slot481, align 8
  %v3594 = load i64, ptr %slot507, align 8
  %cv3595 = trunc i64 %v3594 to i32
  %call3596 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v3591, i64 %v3592, i64 %v3593, i32 %cv3595) nomerge, !dbg !136
  store i32 %call3596, ptr %slot508, align 8
  %v3597 = load i32, ptr %slot508, align 8
  %cv3598 = zext i32 %v3597 to i64
  %cond3599 = icmp ne i64 %cv3598, 0
  br i1 %cond3599, label %bb_rcsuccess603, label %bb_rcfailure603
bb_rcfailure603:
  %v3600 = load i64, ptr %slot52, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  %call3602 = call i32 @myl_rc_take_failure(ptr %p3601) nomerge, !dbg !136
  store i32 %call3602, ptr %slot509, align 8
  %v3603 = load i64, ptr %slot1, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  %v3605 = load i32, ptr %slot509, align 8
  %call3606 = call i32 @myl_qbe_rc_status(ptr %p3604, i32 %v3605) nomerge, !dbg !136
  store i32 %call3606, ptr %slot510, align 8
  br label %bb_failure
bb_rcsuccess603:
  %v3607 = load i64, ptr %slot24, align 8
  %p3608 = inttoptr i64 %v3607 to ptr
  store i32 2, ptr %p3608, align 4, !alias.scope !3, !noalias !4
  %v3609 = load i64, ptr %slot23, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  store i32 1, ptr %p3610, align 4, !alias.scope !3, !noalias !4
  %v3611 = load i64, ptr %slot19, align 8
  %p3612 = inttoptr i64 %v3611 to ptr
  %ld3613 = load i32, ptr %p3612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3613, ptr %slot511, align 8
  %v3614 = load i32, ptr %slot511, align 8
  %cv3615 = zext i32 %v3614 to i64
  %cond3616 = icmp ne i64 %cv3615, 0
  br i1 %cond3616, label %bb_rcslotdrop610, label %bb_rcslotdone610
bb_rcslotdrop610:
  %v3617 = load i64, ptr %slot19, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  store i32 0, ptr %p3618, align 4, !alias.scope !3, !noalias !4
  %v3619 = load i64, ptr %slot25, align 8
  store i64 %v3619, ptr %slot512, align 8
  %v3620 = load i64, ptr %slot20, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %ld3622 = load i32, ptr %p3621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3622, ptr %slot513, align 8
  %v3623 = load i32, ptr %slot513, align 8
  %op3624 = and i32 %v3623, 28
  store i32 %op3624, ptr %slot514, align 8
  %v3625 = load i32, ptr %slot514, align 8
  %cv3626 = zext i32 %v3625 to i64
  %cond3627 = icmp ne i64 %cv3626, 0
  br i1 %cond3627, label %bb_rcslotrole610, label %bb_rcslotowner610
bb_rcslotrole610:
  %v3628 = load i64, ptr %slot52, align 8
  store i64 %v3628, ptr %slot515, align 8
  %v3629 = load i64, ptr %slot515, align 8
  %v3630 = load i64, ptr %slot512, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3629, i64 %v3630) nomerge, !dbg !136
  br label %bb_rcslotdone610
bb_rcslotowner610:
  %v3631 = load i64, ptr %slot512, align 8
  %p3633 = inttoptr i64 %v3631 to ptr
  %gep3634 = getelementptr i8, ptr %p3633, i64 0
  %op3632 = ptrtoint ptr %gep3634 to i64
  store i64 %op3632, ptr %slot516, align 8
  %v3635 = load i64, ptr %slot52, align 8
  store i64 %v3635, ptr %slot517, align 8
  %v3636 = load i64, ptr %slot516, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  %ld3638 = load i64, ptr %p3637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3638, ptr %slot518, align 8
  %v3639 = load i64, ptr %slot518, align 8
  %cmp3640 = icmp ne i64 %v3639, 0
  %cv3641 = zext i1 %cmp3640 to i32
  store i32 %cv3641, ptr %slot519, align 8
  %v3642 = load i32, ptr %slot519, align 8
  %cv3643 = zext i32 %v3642 to i64
  %cond3644 = icmp ne i64 %cv3643, 0
  br i1 %cond3644, label %bb_rcgnn628, label %bb_rcgdone628
bb_rcgnn628:
  %v3645 = load i64, ptr %slot518, align 8
  %op3646 = sub i64 %v3645, 16
  store i64 %op3646, ptr %slot520, align 8
  %v3647 = load i64, ptr %slot518, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  %rgep3649 = getelementptr i8, ptr %p3648, i64 -16
  %ld3650 = load i64, ptr %rgep3649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3650, ptr %slot521, align 8
  %v3651 = load i64, ptr %slot521, align 8
  %op3652 = and i64 %v3651, 4611686018427387906
  store i64 %op3652, ptr %slot522, align 8
  %v3653 = load i64, ptr %slot522, align 8
  %cmp3654 = icmp ne i64 %v3653, 0
  %cv3655 = zext i1 %cmp3654 to i32
  store i32 %cv3655, ptr %slot523, align 8
  %v3656 = load i32, ptr %slot523, align 8
  %cv3657 = zext i32 %v3656 to i64
  %cond3658 = icmp ne i64 %cv3657, 0
  br i1 %cond3658, label %bb_rcgclear628, label %bb_rcgcounted628
bb_rcgcounted628:
  %v3659 = load i64, ptr %slot518, align 8
  %op3660 = sub i64 %v3659, 32
  store i64 %op3660, ptr %slot524, align 8
  %v3661 = load i64, ptr %slot518, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %rgep3663 = getelementptr i8, ptr %p3662, i64 -32
  %ld3664 = load i64, ptr %rgep3663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3664, ptr %slot525, align 8
  %v3665 = load i64, ptr %slot525, align 8
  %op3666 = sub i64 %v3665, 1
  store i64 %op3666, ptr %slot526, align 8
  %v3667 = load i64, ptr %slot526, align 8
  %cmp3668 = icmp eq i64 %v3667, 0
  %cv3669 = zext i1 %cmp3668 to i32
  store i32 %cv3669, ptr %slot527, align 8
  %v3670 = load i32, ptr %slot527, align 8
  %cv3671 = zext i32 %v3670 to i64
  %cond3672 = icmp ne i64 %cv3671, 0
  br i1 %cond3672, label %bb_rcglast628, label %bb_rcgdec628
bb_rcglast628:
  %v3673 = load i64, ptr %slot518, align 8
  %op3674 = sub i64 %v3673, 24
  store i64 %op3674, ptr %slot528, align 8
  %v3675 = load i64, ptr %slot518, align 8
  %p3676 = inttoptr i64 %v3675 to ptr
  %rgep3677 = getelementptr i8, ptr %p3676, i64 -24
  %ld3678 = load i64, ptr %rgep3677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3678, ptr %slot529, align 8
  %v3679 = load i64, ptr %slot529, align 8
  %cmp3680 = icmp ne i64 %v3679, 0
  %cv3681 = zext i1 %cmp3680 to i32
  store i32 %cv3681, ptr %slot530, align 8
  %v3682 = load i32, ptr %slot530, align 8
  %cv3683 = zext i32 %v3682 to i64
  %cond3684 = icmp ne i64 %cv3683, 0
  br i1 %cond3684, label %bb_rcgdec628, label %bb_rcgslow628
bb_rcgslow628:
  %v3685 = load i64, ptr %slot517, align 8
  %v3686 = load i64, ptr %slot516, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3685, i64 %v3686) nomerge, !dbg !136
  br label %bb_rcgdone628
bb_rcgdec628:
  %v3687 = load i64, ptr %slot526, align 8
  %v3688 = load i64, ptr %slot518, align 8
  %p3689 = inttoptr i64 %v3688 to ptr
  %rgep3690 = getelementptr i8, ptr %p3689, i64 -32
  store i64 %v3687, ptr %rgep3690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear628
bb_rcgclear628:
  %v3691 = load i64, ptr %slot516, align 8
  %p3692 = inttoptr i64 %v3691 to ptr
  store i64 0, ptr %p3692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone628
bb_rcgdone628:
  %v3693 = load i64, ptr %slot512, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  store i64 0, ptr %p3694, align 8, !alias.scope !3, !noalias !4
  %v3695 = load i64, ptr %slot512, align 8
  %p3697 = inttoptr i64 %v3695 to ptr
  %gep3698 = getelementptr i8, ptr %p3697, i64 8
  %op3696 = ptrtoint ptr %gep3698 to i64
  store i64 %op3696, ptr %slot531, align 8
  %v3699 = load i64, ptr %slot531, align 8
  %p3700 = inttoptr i64 %v3699 to ptr
  store i64 0, ptr %p3700, align 8, !alias.scope !3, !noalias !4
  %v3701 = load i64, ptr %slot512, align 8
  %p3703 = inttoptr i64 %v3701 to ptr
  %gep3704 = getelementptr i8, ptr %p3703, i64 16
  %op3702 = ptrtoint ptr %gep3704 to i64
  store i64 %op3702, ptr %slot532, align 8
  %v3705 = load i64, ptr %slot532, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  store i64 0, ptr %p3706, align 8, !alias.scope !3, !noalias !4
  %v3707 = load i64, ptr %slot512, align 8
  %p3709 = inttoptr i64 %v3707 to ptr
  %gep3710 = getelementptr i8, ptr %p3709, i64 24
  %op3708 = ptrtoint ptr %gep3710 to i64
  store i64 %op3708, ptr %slot533, align 8
  %v3711 = load i64, ptr %slot533, align 8
  %p3712 = inttoptr i64 %v3711 to ptr
  store i64 0, ptr %p3712, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone610
bb_rcslotdone610:
  br label %bb_rcprepared567
bb_rcprepared567:
  %v3713 = load i64, ptr %slot11, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  %ld3715 = load i32, ptr %p3714, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3715, ptr %slot534, align 8
  %v3716 = load i32, ptr %slot534, align 8
  %cv3717 = zext i32 %v3716 to i64
  %cond3718 = icmp ne i64 %cv3717, 0
  br i1 %cond3718, label %bb_rcslotdrop638, label %bb_rcslotdone638
bb_rcslotdrop638:
  %v3719 = load i64, ptr %slot11, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  store i32 0, ptr %p3720, align 4, !alias.scope !3, !noalias !4
  %v3721 = load i64, ptr %slot38, align 8
  store i64 %v3721, ptr %slot535, align 8
  %v3722 = load i64, ptr %slot12, align 8
  %p3723 = inttoptr i64 %v3722 to ptr
  %ld3724 = load i32, ptr %p3723, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3724, ptr %slot536, align 8
  %v3725 = load i32, ptr %slot536, align 8
  %op3726 = and i32 %v3725, 28
  store i32 %op3726, ptr %slot537, align 8
  %v3727 = load i32, ptr %slot537, align 8
  %cv3728 = zext i32 %v3727 to i64
  %cond3729 = icmp ne i64 %cv3728, 0
  br i1 %cond3729, label %bb_rcslotrole638, label %bb_rcslotowner638
bb_rcslotrole638:
  %v3730 = load i64, ptr %slot52, align 8
  store i64 %v3730, ptr %slot538, align 8
  %v3731 = load i64, ptr %slot538, align 8
  %v3732 = load i64, ptr %slot535, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3731, i64 %v3732) nomerge, !dbg !136
  br label %bb_rcslotdone638
bb_rcslotowner638:
  %v3733 = load i64, ptr %slot535, align 8
  %p3735 = inttoptr i64 %v3733 to ptr
  %gep3736 = getelementptr i8, ptr %p3735, i64 0
  %op3734 = ptrtoint ptr %gep3736 to i64
  store i64 %op3734, ptr %slot539, align 8
  %v3737 = load i64, ptr %slot52, align 8
  store i64 %v3737, ptr %slot540, align 8
  %v3738 = load i64, ptr %slot539, align 8
  %p3739 = inttoptr i64 %v3738 to ptr
  %ld3740 = load i64, ptr %p3739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3740, ptr %slot541, align 8
  %v3741 = load i64, ptr %slot541, align 8
  %cmp3742 = icmp ne i64 %v3741, 0
  %cv3743 = zext i1 %cmp3742 to i32
  store i32 %cv3743, ptr %slot542, align 8
  %v3744 = load i32, ptr %slot542, align 8
  %cv3745 = zext i32 %v3744 to i64
  %cond3746 = icmp ne i64 %cv3745, 0
  br i1 %cond3746, label %bb_rcgnn656, label %bb_rcgdone656
bb_rcgnn656:
  %v3747 = load i64, ptr %slot541, align 8
  %op3748 = sub i64 %v3747, 16
  store i64 %op3748, ptr %slot543, align 8
  %v3749 = load i64, ptr %slot541, align 8
  %p3750 = inttoptr i64 %v3749 to ptr
  %rgep3751 = getelementptr i8, ptr %p3750, i64 -16
  %ld3752 = load i64, ptr %rgep3751, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3752, ptr %slot544, align 8
  %v3753 = load i64, ptr %slot544, align 8
  %op3754 = and i64 %v3753, 4611686018427387906
  store i64 %op3754, ptr %slot545, align 8
  %v3755 = load i64, ptr %slot545, align 8
  %cmp3756 = icmp ne i64 %v3755, 0
  %cv3757 = zext i1 %cmp3756 to i32
  store i32 %cv3757, ptr %slot546, align 8
  %v3758 = load i32, ptr %slot546, align 8
  %cv3759 = zext i32 %v3758 to i64
  %cond3760 = icmp ne i64 %cv3759, 0
  br i1 %cond3760, label %bb_rcgclear656, label %bb_rcgcounted656
bb_rcgcounted656:
  %v3761 = load i64, ptr %slot541, align 8
  %op3762 = sub i64 %v3761, 32
  store i64 %op3762, ptr %slot547, align 8
  %v3763 = load i64, ptr %slot541, align 8
  %p3764 = inttoptr i64 %v3763 to ptr
  %rgep3765 = getelementptr i8, ptr %p3764, i64 -32
  %ld3766 = load i64, ptr %rgep3765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3766, ptr %slot548, align 8
  %v3767 = load i64, ptr %slot548, align 8
  %op3768 = sub i64 %v3767, 1
  store i64 %op3768, ptr %slot549, align 8
  %v3769 = load i64, ptr %slot549, align 8
  %cmp3770 = icmp eq i64 %v3769, 0
  %cv3771 = zext i1 %cmp3770 to i32
  store i32 %cv3771, ptr %slot550, align 8
  %v3772 = load i32, ptr %slot550, align 8
  %cv3773 = zext i32 %v3772 to i64
  %cond3774 = icmp ne i64 %cv3773, 0
  br i1 %cond3774, label %bb_rcglast656, label %bb_rcgdec656
bb_rcglast656:
  %v3775 = load i64, ptr %slot541, align 8
  %op3776 = sub i64 %v3775, 24
  store i64 %op3776, ptr %slot551, align 8
  %v3777 = load i64, ptr %slot541, align 8
  %p3778 = inttoptr i64 %v3777 to ptr
  %rgep3779 = getelementptr i8, ptr %p3778, i64 -24
  %ld3780 = load i64, ptr %rgep3779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3780, ptr %slot552, align 8
  %v3781 = load i64, ptr %slot552, align 8
  %cmp3782 = icmp ne i64 %v3781, 0
  %cv3783 = zext i1 %cmp3782 to i32
  store i32 %cv3783, ptr %slot553, align 8
  %v3784 = load i32, ptr %slot553, align 8
  %cv3785 = zext i32 %v3784 to i64
  %cond3786 = icmp ne i64 %cv3785, 0
  br i1 %cond3786, label %bb_rcgdec656, label %bb_rcgslow656
bb_rcgslow656:
  %v3787 = load i64, ptr %slot540, align 8
  %v3788 = load i64, ptr %slot539, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3787, i64 %v3788) nomerge, !dbg !136
  br label %bb_rcgdone656
bb_rcgdec656:
  %v3789 = load i64, ptr %slot549, align 8
  %v3790 = load i64, ptr %slot541, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  %rgep3792 = getelementptr i8, ptr %p3791, i64 -32
  store i64 %v3789, ptr %rgep3792, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear656
bb_rcgclear656:
  %v3793 = load i64, ptr %slot539, align 8
  %p3794 = inttoptr i64 %v3793 to ptr
  store i64 0, ptr %p3794, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone656
bb_rcgdone656:
  %v3795 = load i64, ptr %slot535, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  store i64 0, ptr %p3796, align 8, !alias.scope !3, !noalias !4
  %v3797 = load i64, ptr %slot535, align 8
  %p3799 = inttoptr i64 %v3797 to ptr
  %gep3800 = getelementptr i8, ptr %p3799, i64 8
  %op3798 = ptrtoint ptr %gep3800 to i64
  store i64 %op3798, ptr %slot554, align 8
  %v3801 = load i64, ptr %slot554, align 8
  %p3802 = inttoptr i64 %v3801 to ptr
  store i64 0, ptr %p3802, align 8, !alias.scope !3, !noalias !4
  %v3803 = load i64, ptr %slot535, align 8
  %p3805 = inttoptr i64 %v3803 to ptr
  %gep3806 = getelementptr i8, ptr %p3805, i64 16
  %op3804 = ptrtoint ptr %gep3806 to i64
  store i64 %op3804, ptr %slot555, align 8
  %v3807 = load i64, ptr %slot555, align 8
  %p3808 = inttoptr i64 %v3807 to ptr
  store i64 0, ptr %p3808, align 8, !alias.scope !3, !noalias !4
  %v3809 = load i64, ptr %slot535, align 8
  %p3811 = inttoptr i64 %v3809 to ptr
  %gep3812 = getelementptr i8, ptr %p3811, i64 24
  %op3810 = ptrtoint ptr %gep3812 to i64
  store i64 %op3810, ptr %slot556, align 8
  %v3813 = load i64, ptr %slot556, align 8
  %p3814 = inttoptr i64 %v3813 to ptr
  store i64 0, ptr %p3814, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone638
bb_rcslotdone638:
  %v3815 = load i64, ptr %slot38, align 8
  store i64 %v3815, ptr %slot557, align 8
  %v3816 = load i64, ptr %slot29, align 8
  store i64 %v3816, ptr %slot558, align 8
  %v3817 = load i64, ptr %slot558, align 8
  %v3818 = load i64, ptr %slot557, align 8
  %p3819 = inttoptr i64 %v3817 to ptr
  %p3820 = inttoptr i64 %v3818 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3820, ptr %p3819, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3821 = load i64, ptr %slot23, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  store i32 0, ptr %p3822, align 4, !alias.scope !3, !noalias !4
  %v3823 = load i64, ptr %slot12, align 8
  %p3824 = inttoptr i64 %v3823 to ptr
  store i32 2, ptr %p3824, align 4, !alias.scope !3, !noalias !4
  %v3825 = load i64, ptr %slot24, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  %ld3827 = load i32, ptr %p3826, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3827, ptr %slot559, align 8
  %v3828 = load i32, ptr %slot559, align 8
  %v3829 = load i64, ptr %slot12, align 8
  %p3830 = inttoptr i64 %v3829 to ptr
  store i32 %v3828, ptr %p3830, align 4, !alias.scope !3, !noalias !4
  %v3831 = load i64, ptr %slot11, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  store i32 1, ptr %p3832, align 4, !alias.scope !3, !noalias !4
  %v3833 = load i64, ptr %slot38, align 8
  %v3834 = load i64, ptr %slot44, align 8
  %p3835 = inttoptr i64 %v3834 to ptr
  store i64 %v3833, ptr %p3835, align 8, !alias.scope !3, !noalias !4
  %v3836 = load i64, ptr %slot44, align 8
  %p3837 = inttoptr i64 %v3836 to ptr
  %ld3838 = load i64, ptr %p3837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3838, ptr %slot560, align 8
  %v3839 = load i64, ptr %slot560, align 8
  %op3840 = add i64 %v3839, 16
  store i64 %op3840, ptr %slot561, align 8
  %v3841 = load i64, ptr %slot561, align 8
  %p3842 = inttoptr i64 %v3841 to ptr
  %ld3843 = load i64, ptr %p3842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3843, ptr %slot562, align 8
  %v3844 = load i64, ptr %slot562, align 8
  %v3845 = load i64, ptr %slot44, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  store i64 %v3844, ptr %p3846, align 8, !alias.scope !3, !noalias !4
  %v3847 = load i64, ptr %slot19, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  %ld3849 = load i32, ptr %p3848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3849, ptr %slot563, align 8
  %v3850 = load i32, ptr %slot563, align 8
  %cv3851 = zext i32 %v3850 to i64
  %cond3852 = icmp ne i64 %cv3851, 0
  br i1 %cond3852, label %bb_rcslotdrop675, label %bb_rcslotdone675
bb_rcslotdrop675:
  %v3853 = load i64, ptr %slot19, align 8
  %p3854 = inttoptr i64 %v3853 to ptr
  store i32 0, ptr %p3854, align 4, !alias.scope !3, !noalias !4
  %v3855 = load i64, ptr %slot25, align 8
  store i64 %v3855, ptr %slot564, align 8
  %v3856 = load i64, ptr %slot20, align 8
  %p3857 = inttoptr i64 %v3856 to ptr
  %ld3858 = load i32, ptr %p3857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3858, ptr %slot565, align 8
  %v3859 = load i32, ptr %slot565, align 8
  %op3860 = and i32 %v3859, 28
  store i32 %op3860, ptr %slot566, align 8
  %v3861 = load i32, ptr %slot566, align 8
  %cv3862 = zext i32 %v3861 to i64
  %cond3863 = icmp ne i64 %cv3862, 0
  br i1 %cond3863, label %bb_rcslotrole675, label %bb_rcslotowner675
bb_rcslotrole675:
  %v3864 = load i64, ptr %slot52, align 8
  store i64 %v3864, ptr %slot567, align 8
  %v3865 = load i64, ptr %slot567, align 8
  %v3866 = load i64, ptr %slot564, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3865, i64 %v3866) nomerge, !dbg !138
  br label %bb_rcslotdone675
bb_rcslotowner675:
  %v3867 = load i64, ptr %slot52, align 8
  store i64 %v3867, ptr %slot568, align 8
  %v3868 = load i64, ptr %slot568, align 8
  %v3869 = load i64, ptr %slot564, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3868, i64 %v3869) nomerge, !dbg !138
  br label %bb_rcslotdone675
bb_rcslotdone675:
  %v3870 = load i64, ptr %slot38, align 8
  %v3871 = load i64, ptr %slot45, align 8
  %p3872 = inttoptr i64 %v3871 to ptr
  store i64 %v3870, ptr %p3872, align 8, !alias.scope !3, !noalias !4
  %v3873 = load i64, ptr %slot45, align 8
  %p3874 = inttoptr i64 %v3873 to ptr
  %ld3875 = load i64, ptr %p3874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3875, ptr %slot569, align 8
  %v3876 = load i64, ptr %slot569, align 8
  %op3877 = add i64 %v3876, 0
  store i64 %op3877, ptr %slot570, align 8
  %v3878 = load i64, ptr %slot570, align 8
  %p3879 = inttoptr i64 %v3878 to ptr
  %ld3880 = load i64, ptr %p3879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3880, ptr %slot571, align 8
  %v3881 = load i64, ptr %slot571, align 8
  %v3882 = load i64, ptr %slot45, align 8
  %p3883 = inttoptr i64 %v3882 to ptr
  store i64 %v3881, ptr %p3883, align 8, !alias.scope !3, !noalias !4
  %v3884 = load i64, ptr %slot45, align 8
  %p3885 = inttoptr i64 %v3884 to ptr
  %ld3886 = load i64, ptr %p3885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3886, ptr %slot572, align 8
  %v3887 = load i64, ptr %slot572, align 8
  %v3888 = load i64, ptr %slot28, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  store i64 %v3887, ptr %p3889, align 8, !alias.scope !3, !noalias !4
  %v3890 = load i64, ptr %slot28, align 8
  store i64 %v3890, ptr %slot573, align 8
  %v3891 = load i64, ptr %slot29, align 8
  store i64 %v3891, ptr %slot574, align 8
  %v3892 = load i64, ptr %slot573, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  %ld3894 = load i64, ptr %p3893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3894, ptr %slot575, align 8
  %v3895 = load i64, ptr %slot575, align 8
  %cmp3896 = icmp ne i64 %v3895, 0
  %cv3897 = zext i1 %cmp3896 to i32
  store i32 %cv3897, ptr %slot576, align 8
  %v3898 = load i32, ptr %slot576, align 8
  %cv3899 = zext i32 %v3898 to i64
  %cond3900 = icmp ne i64 %cv3899, 0
  br i1 %cond3900, label %bb_rcgnn689, label %bb_rcgstore689
bb_rcgnn689:
  %v3901 = load i64, ptr %slot575, align 8
  %op3902 = sub i64 %v3901, 16
  store i64 %op3902, ptr %slot577, align 8
  %v3903 = load i64, ptr %slot575, align 8
  %p3904 = inttoptr i64 %v3903 to ptr
  %rgep3905 = getelementptr i8, ptr %p3904, i64 -16
  %ld3906 = load i64, ptr %rgep3905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3906, ptr %slot578, align 8
  %v3907 = load i64, ptr %slot578, align 8
  %op3908 = and i64 %v3907, 4611686018427387906
  store i64 %op3908, ptr %slot579, align 8
  %v3909 = load i64, ptr %slot579, align 8
  %cmp3910 = icmp ne i64 %v3909, 0
  %cv3911 = zext i1 %cmp3910 to i32
  store i32 %cv3911, ptr %slot580, align 8
  %v3912 = load i32, ptr %slot580, align 8
  %cv3913 = zext i32 %v3912 to i64
  %cond3914 = icmp ne i64 %cv3913, 0
  br i1 %cond3914, label %bb_rcgstore689, label %bb_rcginc689
bb_rcginc689:
  %v3915 = load i64, ptr %slot575, align 8
  %op3916 = sub i64 %v3915, 24
  store i64 %op3916, ptr %slot581, align 8
  %v3917 = load i64, ptr %slot575, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  %rgep3919 = getelementptr i8, ptr %p3918, i64 -24
  %ld3920 = load i64, ptr %rgep3919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3920, ptr %slot582, align 8
  %v3921 = load i64, ptr %slot582, align 8
  %op3922 = add i64 %v3921, 1
  store i64 %op3922, ptr %slot583, align 8
  %v3923 = load i64, ptr %slot583, align 8
  %cmp3924 = icmp eq i64 %v3923, 0
  %cv3925 = zext i1 %cmp3924 to i32
  store i32 %cv3925, ptr %slot584, align 8
  %v3926 = load i32, ptr %slot584, align 8
  %cv3927 = zext i32 %v3926 to i64
  %cond3928 = icmp ne i64 %cv3927, 0
  br i1 %cond3928, label %bb_rcglimit689, label %bb_rcgcapacity689
bb_rcglimit689:
  %v3929 = load i64, ptr %slot1, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  %call3931 = call i32 @myl_qbe_rc_status(ptr %p3930, i32 2) nomerge, !dbg !140
  store i32 %call3931, ptr %slot585, align 8
  br label %bb_failure
bb_rcgcapacity689:
  %v3932 = load i64, ptr %slot583, align 8
  %v3933 = load i64, ptr %slot575, align 8
  %p3934 = inttoptr i64 %v3933 to ptr
  %rgep3935 = getelementptr i8, ptr %p3934, i64 -24
  store i64 %v3932, ptr %rgep3935, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore689
bb_rcgstore689:
  %v3936 = load i64, ptr %slot575, align 8
  %v3937 = load i64, ptr %slot574, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  store i64 %v3936, ptr %p3938, align 8, !alias.scope !3, !noalias !4
  %v3939 = load i64, ptr %slot24, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  store i32 2, ptr %p3940, align 4, !alias.scope !3, !noalias !4
  %v3941 = load i64, ptr %slot24, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  store i32 16, ptr %p3942, align 4, !alias.scope !3, !noalias !4
  %v3943 = load i64, ptr %slot23, align 8
  %p3944 = inttoptr i64 %v3943 to ptr
  store i32 1, ptr %p3944, align 4, !alias.scope !3, !noalias !4
  %v3945 = load i64, ptr %slot21, align 8
  %p3946 = inttoptr i64 %v3945 to ptr
  %ld3947 = load i32, ptr %p3946, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3947, ptr %slot586, align 8
  %v3948 = load i32, ptr %slot586, align 8
  %cv3949 = zext i32 %v3948 to i64
  %cond3950 = icmp ne i64 %cv3949, 0
  br i1 %cond3950, label %bb_rcslotdrop705, label %bb_rcslotdone705
bb_rcslotdrop705:
  %v3951 = load i64, ptr %slot21, align 8
  %p3952 = inttoptr i64 %v3951 to ptr
  store i32 0, ptr %p3952, align 4, !alias.scope !3, !noalias !4
  %v3953 = load i64, ptr %slot26, align 8
  store i64 %v3953, ptr %slot587, align 8
  %v3954 = load i64, ptr %slot22, align 8
  %p3955 = inttoptr i64 %v3954 to ptr
  %ld3956 = load i32, ptr %p3955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3956, ptr %slot588, align 8
  %v3957 = load i32, ptr %slot588, align 8
  %op3958 = and i32 %v3957, 28
  store i32 %op3958, ptr %slot589, align 8
  %v3959 = load i32, ptr %slot589, align 8
  %cv3960 = zext i32 %v3959 to i64
  %cond3961 = icmp ne i64 %cv3960, 0
  br i1 %cond3961, label %bb_rcslotrole705, label %bb_rcslotowner705
bb_rcslotrole705:
  %v3962 = load i64, ptr %slot52, align 8
  store i64 %v3962, ptr %slot590, align 8
  %v3963 = load i64, ptr %slot590, align 8
  %v3964 = load i64, ptr %slot587, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3963, i64 %v3964) nomerge, !dbg !140
  br label %bb_rcslotdone705
bb_rcslotowner705:
  %v3965 = load i64, ptr %slot52, align 8
  store i64 %v3965, ptr %slot591, align 8
  %v3966 = load i64, ptr %slot591, align 8
  %v3967 = load i64, ptr %slot587, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3966, i64 %v3967) nomerge, !dbg !140
  br label %bb_rcslotdone705
bb_rcslotdone705:
  %v3968 = load i64, ptr %slot26, align 8
  store i64 %v3968, ptr %slot592, align 8
  %v3969 = load i64, ptr %slot29, align 8
  store i64 %v3969, ptr %slot593, align 8
  %v3970 = load i64, ptr %slot593, align 8
  %v3971 = load i64, ptr %slot592, align 8
  %p3972 = inttoptr i64 %v3970 to ptr
  %p3973 = inttoptr i64 %v3971 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3973, ptr %p3972, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3974 = load i64, ptr %slot22, align 8
  %p3975 = inttoptr i64 %v3974 to ptr
  store i32 2, ptr %p3975, align 4, !alias.scope !3, !noalias !4
  %v3976 = load i64, ptr %slot24, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  %ld3978 = load i32, ptr %p3977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3978, ptr %slot594, align 8
  %v3979 = load i32, ptr %slot594, align 8
  %v3980 = load i64, ptr %slot22, align 8
  %p3981 = inttoptr i64 %v3980 to ptr
  store i32 %v3979, ptr %p3981, align 4, !alias.scope !3, !noalias !4
  %v3982 = load i64, ptr %slot23, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  store i32 0, ptr %p3983, align 4, !alias.scope !3, !noalias !4
  %v3984 = load i64, ptr %slot21, align 8
  %p3985 = inttoptr i64 %v3984 to ptr
  store i32 1, ptr %p3985, align 4, !alias.scope !3, !noalias !4
  %v3986 = load i64, ptr %slot592, align 8
  %p3987 = inttoptr i64 %v3986 to ptr
  %ld3988 = load i64, ptr %p3987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3988, ptr %slot595, align 8
  %v3989 = load i64, ptr %slot595, align 8
  %v3990 = load i64, ptr %slot45, align 8
  %p3991 = inttoptr i64 %v3990 to ptr
  store i64 %v3989, ptr %p3991, align 8, !alias.scope !3, !noalias !4
  %v3992 = load i64, ptr %slot45, align 8
  %p3993 = inttoptr i64 %v3992 to ptr
  %ld3994 = load i64, ptr %p3993, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3994, ptr %slot596, align 8
  %v3995 = load i64, ptr %slot596, align 8
  %p3996 = inttoptr i64 %v3995 to ptr
  %ld3997 = load i64, ptr %p3996, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3997, ptr %slot597, align 8
  %v3998 = load i64, ptr %slot597, align 8
  %v3999 = load i64, ptr %slot45, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  store i64 %v3998, ptr %p4000, align 8, !alias.scope !3, !noalias !4
  %v4001 = load i64, ptr %slot21, align 8
  %p4002 = inttoptr i64 %v4001 to ptr
  %ld4003 = load i32, ptr %p4002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4003, ptr %slot598, align 8
  %v4004 = load i32, ptr %slot598, align 8
  %cv4005 = zext i32 %v4004 to i64
  %cond4006 = icmp ne i64 %cv4005, 0
  br i1 %cond4006, label %bb_rcslotdrop725, label %bb_rcslotdone725
bb_rcslotdrop725:
  %v4007 = load i64, ptr %slot21, align 8
  %p4008 = inttoptr i64 %v4007 to ptr
  store i32 0, ptr %p4008, align 4, !alias.scope !3, !noalias !4
  %v4009 = load i64, ptr %slot26, align 8
  store i64 %v4009, ptr %slot599, align 8
  %v4010 = load i64, ptr %slot22, align 8
  %p4011 = inttoptr i64 %v4010 to ptr
  %ld4012 = load i32, ptr %p4011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4012, ptr %slot600, align 8
  %v4013 = load i32, ptr %slot600, align 8
  %op4014 = and i32 %v4013, 28
  store i32 %op4014, ptr %slot601, align 8
  %v4015 = load i32, ptr %slot601, align 8
  %cv4016 = zext i32 %v4015 to i64
  %cond4017 = icmp ne i64 %cv4016, 0
  br i1 %cond4017, label %bb_rcslotrole725, label %bb_rcslotowner725
bb_rcslotrole725:
  %v4018 = load i64, ptr %slot52, align 8
  store i64 %v4018, ptr %slot602, align 8
  %v4019 = load i64, ptr %slot599, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  %ld4021 = load i64, ptr %p4020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4021, ptr %slot603, align 8
  %v4022 = load i64, ptr %slot603, align 8
  %cmp4023 = icmp ne i64 %v4022, 0
  %cv4024 = zext i1 %cmp4023 to i32
  store i32 %cv4024, ptr %slot604, align 8
  %v4025 = load i32, ptr %slot604, align 8
  %cv4026 = zext i32 %v4025 to i64
  %cond4027 = icmp ne i64 %cv4026, 0
  br i1 %cond4027, label %bb_rcgnn741, label %bb_rcgdone741
bb_rcgnn741:
  %v4028 = load i64, ptr %slot603, align 8
  %op4029 = sub i64 %v4028, 16
  store i64 %op4029, ptr %slot605, align 8
  %v4030 = load i64, ptr %slot603, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  %rgep4032 = getelementptr i8, ptr %p4031, i64 -16
  %ld4033 = load i64, ptr %rgep4032, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4033, ptr %slot606, align 8
  %v4034 = load i64, ptr %slot606, align 8
  %op4035 = and i64 %v4034, 4611686018427387906
  store i64 %op4035, ptr %slot607, align 8
  %v4036 = load i64, ptr %slot607, align 8
  %cmp4037 = icmp ne i64 %v4036, 0
  %cv4038 = zext i1 %cmp4037 to i32
  store i32 %cv4038, ptr %slot608, align 8
  %v4039 = load i32, ptr %slot608, align 8
  %cv4040 = zext i32 %v4039 to i64
  %cond4041 = icmp ne i64 %cv4040, 0
  br i1 %cond4041, label %bb_rcgclear741, label %bb_rcgcounted741
bb_rcgcounted741:
  %v4042 = load i64, ptr %slot603, align 8
  %op4043 = sub i64 %v4042, 24
  store i64 %op4043, ptr %slot609, align 8
  %v4044 = load i64, ptr %slot603, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  %rgep4046 = getelementptr i8, ptr %p4045, i64 -24
  %ld4047 = load i64, ptr %rgep4046, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4047, ptr %slot610, align 8
  %v4048 = load i64, ptr %slot610, align 8
  %op4049 = sub i64 %v4048, 1
  store i64 %op4049, ptr %slot611, align 8
  %v4050 = load i64, ptr %slot611, align 8
  %cmp4051 = icmp eq i64 %v4050, 0
  %cv4052 = zext i1 %cmp4051 to i32
  store i32 %cv4052, ptr %slot612, align 8
  %v4053 = load i32, ptr %slot612, align 8
  %cv4054 = zext i32 %v4053 to i64
  %cond4055 = icmp ne i64 %cv4054, 0
  br i1 %cond4055, label %bb_rcglast741, label %bb_rcgdec741
bb_rcglast741:
  %v4056 = load i64, ptr %slot603, align 8
  %op4057 = sub i64 %v4056, 32
  store i64 %op4057, ptr %slot613, align 8
  %v4058 = load i64, ptr %slot603, align 8
  %p4059 = inttoptr i64 %v4058 to ptr
  %rgep4060 = getelementptr i8, ptr %p4059, i64 -32
  %ld4061 = load i64, ptr %rgep4060, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4061, ptr %slot614, align 8
  %v4062 = load i64, ptr %slot614, align 8
  %cmp4063 = icmp ne i64 %v4062, 0
  %cv4064 = zext i1 %cmp4063 to i32
  store i32 %cv4064, ptr %slot615, align 8
  %v4065 = load i32, ptr %slot615, align 8
  %cv4066 = zext i32 %v4065 to i64
  %cond4067 = icmp ne i64 %cv4066, 0
  br i1 %cond4067, label %bb_rcgdec741, label %bb_rcgslow741
bb_rcgslow741:
  %v4068 = load i64, ptr %slot602, align 8
  %v4069 = load i64, ptr %slot599, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4068, i64 %v4069) nomerge, !dbg !142
  br label %bb_rcgdone741
bb_rcgdec741:
  %v4070 = load i64, ptr %slot611, align 8
  %v4071 = load i64, ptr %slot603, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  %rgep4073 = getelementptr i8, ptr %p4072, i64 -24
  store i64 %v4070, ptr %rgep4073, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear741
bb_rcgclear741:
  %v4074 = load i64, ptr %slot599, align 8
  %p4075 = inttoptr i64 %v4074 to ptr
  store i64 0, ptr %p4075, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone741
bb_rcgdone741:
  br label %bb_rcslotdone725
bb_rcslotowner725:
  %v4076 = load i64, ptr %slot52, align 8
  store i64 %v4076, ptr %slot616, align 8
  %v4077 = load i64, ptr %slot599, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  %ld4079 = load i64, ptr %p4078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4079, ptr %slot617, align 8
  %v4080 = load i64, ptr %slot617, align 8
  %cmp4081 = icmp ne i64 %v4080, 0
  %cv4082 = zext i1 %cmp4081 to i32
  store i32 %cv4082, ptr %slot618, align 8
  %v4083 = load i32, ptr %slot618, align 8
  %cv4084 = zext i32 %v4083 to i64
  %cond4085 = icmp ne i64 %cv4084, 0
  br i1 %cond4085, label %bb_rcgnn756, label %bb_rcgdone756
bb_rcgnn756:
  %v4086 = load i64, ptr %slot617, align 8
  %op4087 = sub i64 %v4086, 16
  store i64 %op4087, ptr %slot619, align 8
  %v4088 = load i64, ptr %slot617, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  %rgep4090 = getelementptr i8, ptr %p4089, i64 -16
  %ld4091 = load i64, ptr %rgep4090, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4091, ptr %slot620, align 8
  %v4092 = load i64, ptr %slot620, align 8
  %op4093 = and i64 %v4092, 4611686018427387906
  store i64 %op4093, ptr %slot621, align 8
  %v4094 = load i64, ptr %slot621, align 8
  %cmp4095 = icmp ne i64 %v4094, 0
  %cv4096 = zext i1 %cmp4095 to i32
  store i32 %cv4096, ptr %slot622, align 8
  %v4097 = load i32, ptr %slot622, align 8
  %cv4098 = zext i32 %v4097 to i64
  %cond4099 = icmp ne i64 %cv4098, 0
  br i1 %cond4099, label %bb_rcgclear756, label %bb_rcgcounted756
bb_rcgcounted756:
  %v4100 = load i64, ptr %slot617, align 8
  %op4101 = sub i64 %v4100, 32
  store i64 %op4101, ptr %slot623, align 8
  %v4102 = load i64, ptr %slot617, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  %rgep4104 = getelementptr i8, ptr %p4103, i64 -32
  %ld4105 = load i64, ptr %rgep4104, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4105, ptr %slot624, align 8
  %v4106 = load i64, ptr %slot624, align 8
  %op4107 = sub i64 %v4106, 1
  store i64 %op4107, ptr %slot625, align 8
  %v4108 = load i64, ptr %slot625, align 8
  %cmp4109 = icmp eq i64 %v4108, 0
  %cv4110 = zext i1 %cmp4109 to i32
  store i32 %cv4110, ptr %slot626, align 8
  %v4111 = load i32, ptr %slot626, align 8
  %cv4112 = zext i32 %v4111 to i64
  %cond4113 = icmp ne i64 %cv4112, 0
  br i1 %cond4113, label %bb_rcglast756, label %bb_rcgdec756
bb_rcglast756:
  %v4114 = load i64, ptr %slot617, align 8
  %op4115 = sub i64 %v4114, 24
  store i64 %op4115, ptr %slot627, align 8
  %v4116 = load i64, ptr %slot617, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  %rgep4118 = getelementptr i8, ptr %p4117, i64 -24
  %ld4119 = load i64, ptr %rgep4118, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4119, ptr %slot628, align 8
  %v4120 = load i64, ptr %slot628, align 8
  %cmp4121 = icmp ne i64 %v4120, 0
  %cv4122 = zext i1 %cmp4121 to i32
  store i32 %cv4122, ptr %slot629, align 8
  %v4123 = load i32, ptr %slot629, align 8
  %cv4124 = zext i32 %v4123 to i64
  %cond4125 = icmp ne i64 %cv4124, 0
  br i1 %cond4125, label %bb_rcgdec756, label %bb_rcgslow756
bb_rcgslow756:
  %v4126 = load i64, ptr %slot616, align 8
  %v4127 = load i64, ptr %slot599, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4126, i64 %v4127) nomerge, !dbg !142
  br label %bb_rcgdone756
bb_rcgdec756:
  %v4128 = load i64, ptr %slot625, align 8
  %v4129 = load i64, ptr %slot617, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  %rgep4131 = getelementptr i8, ptr %p4130, i64 -32
  store i64 %v4128, ptr %rgep4131, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear756
bb_rcgclear756:
  %v4132 = load i64, ptr %slot599, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  store i64 0, ptr %p4133, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone756
bb_rcgdone756:
  br label %bb_rcslotdone725
bb_rcslotdone725:
  %v4134 = load i64, ptr %slot45, align 8
  %p4135 = inttoptr i64 %v4134 to ptr
  %ld4136 = load i64, ptr %p4135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4136, ptr %slot630, align 8
  %v4137 = load i64, ptr %slot44, align 8
  %p4138 = inttoptr i64 %v4137 to ptr
  %ld4139 = load i64, ptr %p4138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4139, ptr %slot631, align 8
  %v4140 = load i64, ptr %slot631, align 8
  %v4141 = load i64, ptr %slot630, align 8
  %cmp4142 = icmp sge i64 %v4140, %v4141
  %cv4143 = zext i1 %cmp4142 to i64
  store i64 %cv4143, ptr %slot632, align 8
  %v4144 = load i64, ptr %slot632, align 8
  %v4145 = load i64, ptr %slot44, align 8
  %p4146 = inttoptr i64 %v4145 to ptr
  store i64 %v4144, ptr %p4146, align 8, !alias.scope !3, !noalias !4
  br label %bb_i60
bb_i60:
  %v4147 = load i64, ptr %slot44, align 8
  %p4148 = inttoptr i64 %v4147 to ptr
  %ld4149 = load i64, ptr %p4148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4149, ptr %slot633, align 8
  %v4150 = load i64, ptr %slot633, align 8
  %cond4151 = icmp ne i64 %v4150, 0
  br i1 %cond4151, label %bb_next764, label %bb_i63
bb_next764:
  %v4152 = load i64, ptr %slot44, align 8
  %p4153 = inttoptr i64 %v4152 to ptr
  store i64 0, ptr %p4153, align 8, !alias.scope !3, !noalias !4
  br label %bb_i70
bb_i63:
  %v4154 = load i64, ptr %slot37, align 8
  %v4155 = load i64, ptr %slot44, align 8
  %p4156 = inttoptr i64 %v4155 to ptr
  store i64 %v4154, ptr %p4156, align 8, !alias.scope !3, !noalias !4
  %v4157 = load i64, ptr %slot44, align 8
  %p4158 = inttoptr i64 %v4157 to ptr
  %ld4159 = load i64, ptr %p4158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4159, ptr %slot634, align 8
  %v4160 = load i64, ptr %slot634, align 8
  %op4161 = add i64 %v4160, 0
  store i64 %op4161, ptr %slot635, align 8
  %v4162 = load i64, ptr %slot635, align 8
  %p4163 = inttoptr i64 %v4162 to ptr
  %ld4164 = load i64, ptr %p4163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4164, ptr %slot636, align 8
  %v4165 = load i64, ptr %slot636, align 8
  %v4166 = load i64, ptr %slot44, align 8
  %p4167 = inttoptr i64 %v4166 to ptr
  store i64 %v4165, ptr %p4167, align 8, !alias.scope !3, !noalias !4
  %v4168 = load i64, ptr %slot44, align 8
  %p4169 = inttoptr i64 %v4168 to ptr
  %ld4170 = load i64, ptr %p4169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4170, ptr %slot637, align 8
  %v4171 = load i64, ptr %slot637, align 8
  %v4172 = load i64, ptr %slot27, align 8
  %p4173 = inttoptr i64 %v4172 to ptr
  store i64 %v4171, ptr %p4173, align 8, !alias.scope !3, !noalias !4
  %v4174 = load i64, ptr %slot27, align 8
  store i64 %v4174, ptr %slot638, align 8
  %v4175 = load i64, ptr %slot29, align 8
  store i64 %v4175, ptr %slot639, align 8
  %v4176 = load i64, ptr %slot638, align 8
  %p4177 = inttoptr i64 %v4176 to ptr
  %ld4178 = load i64, ptr %p4177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4178, ptr %slot640, align 8
  %v4179 = load i64, ptr %slot640, align 8
  %cmp4180 = icmp ne i64 %v4179, 0
  %cv4181 = zext i1 %cmp4180 to i32
  store i32 %cv4181, ptr %slot641, align 8
  %v4182 = load i32, ptr %slot641, align 8
  %cv4183 = zext i32 %v4182 to i64
  %cond4184 = icmp ne i64 %cv4183, 0
  br i1 %cond4184, label %bb_rcgnn771, label %bb_rcgstore771
bb_rcgnn771:
  %v4185 = load i64, ptr %slot640, align 8
  %op4186 = sub i64 %v4185, 16
  store i64 %op4186, ptr %slot642, align 8
  %v4187 = load i64, ptr %slot640, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  %rgep4189 = getelementptr i8, ptr %p4188, i64 -16
  %ld4190 = load i64, ptr %rgep4189, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4190, ptr %slot643, align 8
  %v4191 = load i64, ptr %slot643, align 8
  %op4192 = and i64 %v4191, 4611686018427387906
  store i64 %op4192, ptr %slot644, align 8
  %v4193 = load i64, ptr %slot644, align 8
  %cmp4194 = icmp ne i64 %v4193, 0
  %cv4195 = zext i1 %cmp4194 to i32
  store i32 %cv4195, ptr %slot645, align 8
  %v4196 = load i32, ptr %slot645, align 8
  %cv4197 = zext i32 %v4196 to i64
  %cond4198 = icmp ne i64 %cv4197, 0
  br i1 %cond4198, label %bb_rcgstore771, label %bb_rcginc771
bb_rcginc771:
  %v4199 = load i64, ptr %slot640, align 8
  %op4200 = sub i64 %v4199, 24
  store i64 %op4200, ptr %slot646, align 8
  %v4201 = load i64, ptr %slot640, align 8
  %p4202 = inttoptr i64 %v4201 to ptr
  %rgep4203 = getelementptr i8, ptr %p4202, i64 -24
  %ld4204 = load i64, ptr %rgep4203, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4204, ptr %slot647, align 8
  %v4205 = load i64, ptr %slot647, align 8
  %op4206 = add i64 %v4205, 1
  store i64 %op4206, ptr %slot648, align 8
  %v4207 = load i64, ptr %slot648, align 8
  %cmp4208 = icmp eq i64 %v4207, 0
  %cv4209 = zext i1 %cmp4208 to i32
  store i32 %cv4209, ptr %slot649, align 8
  %v4210 = load i32, ptr %slot649, align 8
  %cv4211 = zext i32 %v4210 to i64
  %cond4212 = icmp ne i64 %cv4211, 0
  br i1 %cond4212, label %bb_rcglimit771, label %bb_rcgcapacity771
bb_rcglimit771:
  %v4213 = load i64, ptr %slot1, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  %call4215 = call i32 @myl_qbe_rc_status(ptr %p4214, i32 2) nomerge, !dbg !144
  store i32 %call4215, ptr %slot650, align 8
  br label %bb_failure
bb_rcgcapacity771:
  %v4216 = load i64, ptr %slot648, align 8
  %v4217 = load i64, ptr %slot640, align 8
  %p4218 = inttoptr i64 %v4217 to ptr
  %rgep4219 = getelementptr i8, ptr %p4218, i64 -24
  store i64 %v4216, ptr %rgep4219, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore771
bb_rcgstore771:
  %v4220 = load i64, ptr %slot640, align 8
  %v4221 = load i64, ptr %slot639, align 8
  %p4222 = inttoptr i64 %v4221 to ptr
  store i64 %v4220, ptr %p4222, align 8, !alias.scope !3, !noalias !4
  %v4223 = load i64, ptr %slot24, align 8
  %p4224 = inttoptr i64 %v4223 to ptr
  store i32 2, ptr %p4224, align 4, !alias.scope !3, !noalias !4
  %v4225 = load i64, ptr %slot24, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  store i32 16, ptr %p4226, align 4, !alias.scope !3, !noalias !4
  %v4227 = load i64, ptr %slot23, align 8
  %p4228 = inttoptr i64 %v4227 to ptr
  store i32 1, ptr %p4228, align 4, !alias.scope !3, !noalias !4
  %v4229 = load i64, ptr %slot19, align 8
  %p4230 = inttoptr i64 %v4229 to ptr
  %ld4231 = load i32, ptr %p4230, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4231, ptr %slot651, align 8
  %v4232 = load i32, ptr %slot651, align 8
  %cv4233 = zext i32 %v4232 to i64
  %cond4234 = icmp ne i64 %cv4233, 0
  br i1 %cond4234, label %bb_rcslotdrop787, label %bb_rcslotdone787
bb_rcslotdrop787:
  %v4235 = load i64, ptr %slot19, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  store i32 0, ptr %p4236, align 4, !alias.scope !3, !noalias !4
  %v4237 = load i64, ptr %slot25, align 8
  store i64 %v4237, ptr %slot652, align 8
  %v4238 = load i64, ptr %slot20, align 8
  %p4239 = inttoptr i64 %v4238 to ptr
  %ld4240 = load i32, ptr %p4239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4240, ptr %slot653, align 8
  %v4241 = load i32, ptr %slot653, align 8
  %op4242 = and i32 %v4241, 28
  store i32 %op4242, ptr %slot654, align 8
  %v4243 = load i32, ptr %slot654, align 8
  %cv4244 = zext i32 %v4243 to i64
  %cond4245 = icmp ne i64 %cv4244, 0
  br i1 %cond4245, label %bb_rcslotrole787, label %bb_rcslotowner787
bb_rcslotrole787:
  %v4246 = load i64, ptr %slot52, align 8
  store i64 %v4246, ptr %slot655, align 8
  %v4247 = load i64, ptr %slot655, align 8
  %v4248 = load i64, ptr %slot652, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4247, i64 %v4248) nomerge, !dbg !144
  br label %bb_rcslotdone787
bb_rcslotowner787:
  %v4249 = load i64, ptr %slot52, align 8
  store i64 %v4249, ptr %slot656, align 8
  %v4250 = load i64, ptr %slot656, align 8
  %v4251 = load i64, ptr %slot652, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4250, i64 %v4251) nomerge, !dbg !144
  br label %bb_rcslotdone787
bb_rcslotdone787:
  %v4252 = load i64, ptr %slot25, align 8
  store i64 %v4252, ptr %slot657, align 8
  %v4253 = load i64, ptr %slot29, align 8
  store i64 %v4253, ptr %slot658, align 8
  %v4254 = load i64, ptr %slot658, align 8
  %v4255 = load i64, ptr %slot657, align 8
  %p4256 = inttoptr i64 %v4254 to ptr
  %p4257 = inttoptr i64 %v4255 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4257, ptr %p4256, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4258 = load i64, ptr %slot20, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  store i32 2, ptr %p4259, align 4, !alias.scope !3, !noalias !4
  %v4260 = load i64, ptr %slot24, align 8
  %p4261 = inttoptr i64 %v4260 to ptr
  %ld4262 = load i32, ptr %p4261, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4262, ptr %slot659, align 8
  %v4263 = load i32, ptr %slot659, align 8
  %v4264 = load i64, ptr %slot20, align 8
  %p4265 = inttoptr i64 %v4264 to ptr
  store i32 %v4263, ptr %p4265, align 4, !alias.scope !3, !noalias !4
  %v4266 = load i64, ptr %slot23, align 8
  %p4267 = inttoptr i64 %v4266 to ptr
  store i32 0, ptr %p4267, align 4, !alias.scope !3, !noalias !4
  %v4268 = load i64, ptr %slot19, align 8
  %p4269 = inttoptr i64 %v4268 to ptr
  store i32 1, ptr %p4269, align 4, !alias.scope !3, !noalias !4
  %v4270 = load i64, ptr %slot657, align 8
  %p4271 = inttoptr i64 %v4270 to ptr
  %ld4272 = load i64, ptr %p4271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4272, ptr %slot660, align 8
  %v4273 = load i64, ptr %slot660, align 8
  %v4274 = load i64, ptr %slot44, align 8
  %p4275 = inttoptr i64 %v4274 to ptr
  store i64 %v4273, ptr %p4275, align 8, !alias.scope !3, !noalias !4
  %v4276 = load i64, ptr %slot37, align 8
  %v4277 = load i64, ptr %slot45, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  store i64 %v4276, ptr %p4278, align 8, !alias.scope !3, !noalias !4
  %v4279 = load i64, ptr %slot45, align 8
  %p4280 = inttoptr i64 %v4279 to ptr
  %ld4281 = load i64, ptr %p4280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4281, ptr %slot661, align 8
  %v4282 = load i64, ptr %slot661, align 8
  %op4283 = add i64 %v4282, 16
  store i64 %op4283, ptr %slot662, align 8
  %v4284 = load i64, ptr %slot662, align 8
  %p4285 = inttoptr i64 %v4284 to ptr
  %ld4286 = load i64, ptr %p4285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4286, ptr %slot663, align 8
  %v4287 = load i64, ptr %slot663, align 8
  %v4288 = load i64, ptr %slot45, align 8
  %p4289 = inttoptr i64 %v4288 to ptr
  store i64 %v4287, ptr %p4289, align 8, !alias.scope !3, !noalias !4
  %v4290 = load i64, ptr %slot21, align 8
  %p4291 = inttoptr i64 %v4290 to ptr
  %ld4292 = load i32, ptr %p4291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4292, ptr %slot664, align 8
  %v4293 = load i32, ptr %slot664, align 8
  %cv4294 = zext i32 %v4293 to i64
  %cond4295 = icmp ne i64 %cv4294, 0
  br i1 %cond4295, label %bb_rcslotdrop808, label %bb_rcslotdone808
bb_rcslotdrop808:
  %v4296 = load i64, ptr %slot21, align 8
  %p4297 = inttoptr i64 %v4296 to ptr
  store i32 0, ptr %p4297, align 4, !alias.scope !3, !noalias !4
  %v4298 = load i64, ptr %slot26, align 8
  store i64 %v4298, ptr %slot665, align 8
  %v4299 = load i64, ptr %slot22, align 8
  %p4300 = inttoptr i64 %v4299 to ptr
  %ld4301 = load i32, ptr %p4300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4301, ptr %slot666, align 8
  %v4302 = load i32, ptr %slot666, align 8
  %op4303 = and i32 %v4302, 28
  store i32 %op4303, ptr %slot667, align 8
  %v4304 = load i32, ptr %slot667, align 8
  %cv4305 = zext i32 %v4304 to i64
  %cond4306 = icmp ne i64 %cv4305, 0
  br i1 %cond4306, label %bb_rcslotrole808, label %bb_rcslotowner808
bb_rcslotrole808:
  %v4307 = load i64, ptr %slot52, align 8
  store i64 %v4307, ptr %slot668, align 8
  %v4308 = load i64, ptr %slot668, align 8
  %v4309 = load i64, ptr %slot665, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4308, i64 %v4309) nomerge, !dbg !146
  br label %bb_rcslotdone808
bb_rcslotowner808:
  %v4310 = load i64, ptr %slot52, align 8
  store i64 %v4310, ptr %slot669, align 8
  %v4311 = load i64, ptr %slot669, align 8
  %v4312 = load i64, ptr %slot665, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4311, i64 %v4312) nomerge, !dbg !146
  br label %bb_rcslotdone808
bb_rcslotdone808:
  %v4313 = load i64, ptr %slot44, align 8
  %p4314 = inttoptr i64 %v4313 to ptr
  %ld4315 = load i64, ptr %p4314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4315, ptr %slot670, align 8
  %v4316 = load i64, ptr %slot45, align 8
  %p4317 = inttoptr i64 %v4316 to ptr
  %ld4318 = load i64, ptr %p4317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4318, ptr %slot671, align 8
  %v4319 = load i64, ptr %slot670, align 8
  %p4320 = inttoptr i64 %v4319 to ptr
  %ld4321 = load i64, ptr %p4320, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4321, ptr %slot672, align 8
  %v4322 = load i64, ptr %slot671, align 8
  %op4323 = ashr i64 %v4322, 63
  store i64 %op4323, ptr %slot673, align 8
  %v4324 = load i64, ptr %slot673, align 8
  %v4325 = load i64, ptr %slot672, align 8
  %op4326 = and i64 %v4324, %v4325
  store i64 %op4326, ptr %slot674, align 8
  %v4327 = load i64, ptr %slot671, align 8
  %v4328 = load i64, ptr %slot674, align 8
  %op4329 = add i64 %v4327, %v4328
  store i64 %op4329, ptr %slot675, align 8
  %v4330 = load i64, ptr %slot675, align 8
  %v4331 = load i64, ptr %slot672, align 8
  %cmp4332 = icmp ult i64 %v4330, %v4331
  %cv4333 = zext i1 %cmp4332 to i64
  store i64 %cv4333, ptr %slot676, align 8
  %v4334 = load i64, ptr %slot676, align 8
  %cond4335 = icmp ne i64 %v4334, 0
  br i1 %cond4335, label %bb_success823, label %bb_failed823
bb_failed823:
  %v4336 = load i64, ptr %slot1, align 8
  %p4337 = inttoptr i64 %v4336 to ptr
  %v4338 = load i64, ptr %slot671, align 8
  %v4339 = load i64, ptr %slot672, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p4337, i64 %v4338, i64 %v4339) nomerge, !dbg !148
  unreachable
bb_success823:
  %v4340 = load i64, ptr %slot670, align 8
  %op4341 = add i64 %v4340, 32
  store i64 %op4341, ptr %slot677, align 8
  %v4342 = load i64, ptr %slot677, align 8
  %p4343 = inttoptr i64 %v4342 to ptr
  %ld4344 = load i64, ptr %p4343, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4344, ptr %slot678, align 8
  %v4345 = load i64, ptr %slot678, align 8
  %v4346 = load i64, ptr %slot675, align 8
  %op4347 = add i64 %v4345, %v4346
  store i64 %op4347, ptr %slot679, align 8
  %v4348 = load i64, ptr %slot678, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  %v4350 = load i64, ptr %slot675, align 8
  %egep4351 = getelementptr i8, ptr %p4349, i64 %v4350
  %ld4352 = load i8, ptr %egep4351, align 1, !alias.scope !12, !noalias !13
  %ext4353 = zext i8 %ld4352 to i64
  store i64 %ext4353, ptr %slot680, align 8
  %v4354 = load i64, ptr %slot680, align 8
  %v4355 = load i64, ptr %slot44, align 8
  %p4356 = inttoptr i64 %v4355 to ptr
  store i64 %v4354, ptr %p4356, align 8, !alias.scope !3, !noalias !4
  %v4357 = load i64, ptr %slot19, align 8
  %p4358 = inttoptr i64 %v4357 to ptr
  %ld4359 = load i32, ptr %p4358, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4359, ptr %slot681, align 8
  %v4360 = load i32, ptr %slot681, align 8
  %cv4361 = zext i32 %v4360 to i64
  %cond4362 = icmp ne i64 %cv4361, 0
  br i1 %cond4362, label %bb_rcslotdrop831, label %bb_rcslotdone831
bb_rcslotdrop831:
  %v4363 = load i64, ptr %slot19, align 8
  %p4364 = inttoptr i64 %v4363 to ptr
  store i32 0, ptr %p4364, align 4, !alias.scope !3, !noalias !4
  %v4365 = load i64, ptr %slot25, align 8
  store i64 %v4365, ptr %slot682, align 8
  %v4366 = load i64, ptr %slot20, align 8
  %p4367 = inttoptr i64 %v4366 to ptr
  %ld4368 = load i32, ptr %p4367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4368, ptr %slot683, align 8
  %v4369 = load i32, ptr %slot683, align 8
  %op4370 = and i32 %v4369, 28
  store i32 %op4370, ptr %slot684, align 8
  %v4371 = load i32, ptr %slot684, align 8
  %cv4372 = zext i32 %v4371 to i64
  %cond4373 = icmp ne i64 %cv4372, 0
  br i1 %cond4373, label %bb_rcslotrole831, label %bb_rcslotowner831
bb_rcslotrole831:
  %v4374 = load i64, ptr %slot52, align 8
  store i64 %v4374, ptr %slot685, align 8
  %v4375 = load i64, ptr %slot682, align 8
  %p4376 = inttoptr i64 %v4375 to ptr
  %ld4377 = load i64, ptr %p4376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4377, ptr %slot686, align 8
  %v4378 = load i64, ptr %slot686, align 8
  %cmp4379 = icmp ne i64 %v4378, 0
  %cv4380 = zext i1 %cmp4379 to i32
  store i32 %cv4380, ptr %slot687, align 8
  %v4381 = load i32, ptr %slot687, align 8
  %cv4382 = zext i32 %v4381 to i64
  %cond4383 = icmp ne i64 %cv4382, 0
  br i1 %cond4383, label %bb_rcgnn847, label %bb_rcgdone847
bb_rcgnn847:
  %v4384 = load i64, ptr %slot686, align 8
  %op4385 = sub i64 %v4384, 16
  store i64 %op4385, ptr %slot688, align 8
  %v4386 = load i64, ptr %slot686, align 8
  %p4387 = inttoptr i64 %v4386 to ptr
  %rgep4388 = getelementptr i8, ptr %p4387, i64 -16
  %ld4389 = load i64, ptr %rgep4388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4389, ptr %slot689, align 8
  %v4390 = load i64, ptr %slot689, align 8
  %op4391 = and i64 %v4390, 4611686018427387906
  store i64 %op4391, ptr %slot690, align 8
  %v4392 = load i64, ptr %slot690, align 8
  %cmp4393 = icmp ne i64 %v4392, 0
  %cv4394 = zext i1 %cmp4393 to i32
  store i32 %cv4394, ptr %slot691, align 8
  %v4395 = load i32, ptr %slot691, align 8
  %cv4396 = zext i32 %v4395 to i64
  %cond4397 = icmp ne i64 %cv4396, 0
  br i1 %cond4397, label %bb_rcgclear847, label %bb_rcgcounted847
bb_rcgcounted847:
  %v4398 = load i64, ptr %slot686, align 8
  %op4399 = sub i64 %v4398, 24
  store i64 %op4399, ptr %slot692, align 8
  %v4400 = load i64, ptr %slot686, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  %rgep4402 = getelementptr i8, ptr %p4401, i64 -24
  %ld4403 = load i64, ptr %rgep4402, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4403, ptr %slot693, align 8
  %v4404 = load i64, ptr %slot693, align 8
  %op4405 = sub i64 %v4404, 1
  store i64 %op4405, ptr %slot694, align 8
  %v4406 = load i64, ptr %slot694, align 8
  %cmp4407 = icmp eq i64 %v4406, 0
  %cv4408 = zext i1 %cmp4407 to i32
  store i32 %cv4408, ptr %slot695, align 8
  %v4409 = load i32, ptr %slot695, align 8
  %cv4410 = zext i32 %v4409 to i64
  %cond4411 = icmp ne i64 %cv4410, 0
  br i1 %cond4411, label %bb_rcglast847, label %bb_rcgdec847
bb_rcglast847:
  %v4412 = load i64, ptr %slot686, align 8
  %op4413 = sub i64 %v4412, 32
  store i64 %op4413, ptr %slot696, align 8
  %v4414 = load i64, ptr %slot686, align 8
  %p4415 = inttoptr i64 %v4414 to ptr
  %rgep4416 = getelementptr i8, ptr %p4415, i64 -32
  %ld4417 = load i64, ptr %rgep4416, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4417, ptr %slot697, align 8
  %v4418 = load i64, ptr %slot697, align 8
  %cmp4419 = icmp ne i64 %v4418, 0
  %cv4420 = zext i1 %cmp4419 to i32
  store i32 %cv4420, ptr %slot698, align 8
  %v4421 = load i32, ptr %slot698, align 8
  %cv4422 = zext i32 %v4421 to i64
  %cond4423 = icmp ne i64 %cv4422, 0
  br i1 %cond4423, label %bb_rcgdec847, label %bb_rcgslow847
bb_rcgslow847:
  %v4424 = load i64, ptr %slot685, align 8
  %v4425 = load i64, ptr %slot682, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4424, i64 %v4425) nomerge, !dbg !148
  br label %bb_rcgdone847
bb_rcgdec847:
  %v4426 = load i64, ptr %slot694, align 8
  %v4427 = load i64, ptr %slot686, align 8
  %p4428 = inttoptr i64 %v4427 to ptr
  %rgep4429 = getelementptr i8, ptr %p4428, i64 -24
  store i64 %v4426, ptr %rgep4429, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear847
bb_rcgclear847:
  %v4430 = load i64, ptr %slot682, align 8
  %p4431 = inttoptr i64 %v4430 to ptr
  store i64 0, ptr %p4431, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone847
bb_rcgdone847:
  br label %bb_rcslotdone831
bb_rcslotowner831:
  %v4432 = load i64, ptr %slot52, align 8
  store i64 %v4432, ptr %slot699, align 8
  %v4433 = load i64, ptr %slot682, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  %ld4435 = load i64, ptr %p4434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4435, ptr %slot700, align 8
  %v4436 = load i64, ptr %slot700, align 8
  %cmp4437 = icmp ne i64 %v4436, 0
  %cv4438 = zext i1 %cmp4437 to i32
  store i32 %cv4438, ptr %slot701, align 8
  %v4439 = load i32, ptr %slot701, align 8
  %cv4440 = zext i32 %v4439 to i64
  %cond4441 = icmp ne i64 %cv4440, 0
  br i1 %cond4441, label %bb_rcgnn862, label %bb_rcgdone862
bb_rcgnn862:
  %v4442 = load i64, ptr %slot700, align 8
  %op4443 = sub i64 %v4442, 16
  store i64 %op4443, ptr %slot702, align 8
  %v4444 = load i64, ptr %slot700, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  %rgep4446 = getelementptr i8, ptr %p4445, i64 -16
  %ld4447 = load i64, ptr %rgep4446, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4447, ptr %slot703, align 8
  %v4448 = load i64, ptr %slot703, align 8
  %op4449 = and i64 %v4448, 4611686018427387906
  store i64 %op4449, ptr %slot704, align 8
  %v4450 = load i64, ptr %slot704, align 8
  %cmp4451 = icmp ne i64 %v4450, 0
  %cv4452 = zext i1 %cmp4451 to i32
  store i32 %cv4452, ptr %slot705, align 8
  %v4453 = load i32, ptr %slot705, align 8
  %cv4454 = zext i32 %v4453 to i64
  %cond4455 = icmp ne i64 %cv4454, 0
  br i1 %cond4455, label %bb_rcgclear862, label %bb_rcgcounted862
bb_rcgcounted862:
  %v4456 = load i64, ptr %slot700, align 8
  %op4457 = sub i64 %v4456, 32
  store i64 %op4457, ptr %slot706, align 8
  %v4458 = load i64, ptr %slot700, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  %rgep4460 = getelementptr i8, ptr %p4459, i64 -32
  %ld4461 = load i64, ptr %rgep4460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4461, ptr %slot707, align 8
  %v4462 = load i64, ptr %slot707, align 8
  %op4463 = sub i64 %v4462, 1
  store i64 %op4463, ptr %slot708, align 8
  %v4464 = load i64, ptr %slot708, align 8
  %cmp4465 = icmp eq i64 %v4464, 0
  %cv4466 = zext i1 %cmp4465 to i32
  store i32 %cv4466, ptr %slot709, align 8
  %v4467 = load i32, ptr %slot709, align 8
  %cv4468 = zext i32 %v4467 to i64
  %cond4469 = icmp ne i64 %cv4468, 0
  br i1 %cond4469, label %bb_rcglast862, label %bb_rcgdec862
bb_rcglast862:
  %v4470 = load i64, ptr %slot700, align 8
  %op4471 = sub i64 %v4470, 24
  store i64 %op4471, ptr %slot710, align 8
  %v4472 = load i64, ptr %slot700, align 8
  %p4473 = inttoptr i64 %v4472 to ptr
  %rgep4474 = getelementptr i8, ptr %p4473, i64 -24
  %ld4475 = load i64, ptr %rgep4474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4475, ptr %slot711, align 8
  %v4476 = load i64, ptr %slot711, align 8
  %cmp4477 = icmp ne i64 %v4476, 0
  %cv4478 = zext i1 %cmp4477 to i32
  store i32 %cv4478, ptr %slot712, align 8
  %v4479 = load i32, ptr %slot712, align 8
  %cv4480 = zext i32 %v4479 to i64
  %cond4481 = icmp ne i64 %cv4480, 0
  br i1 %cond4481, label %bb_rcgdec862, label %bb_rcgslow862
bb_rcgslow862:
  %v4482 = load i64, ptr %slot699, align 8
  %v4483 = load i64, ptr %slot682, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4482, i64 %v4483) nomerge, !dbg !148
  br label %bb_rcgdone862
bb_rcgdec862:
  %v4484 = load i64, ptr %slot708, align 8
  %v4485 = load i64, ptr %slot700, align 8
  %p4486 = inttoptr i64 %v4485 to ptr
  %rgep4487 = getelementptr i8, ptr %p4486, i64 -32
  store i64 %v4484, ptr %rgep4487, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear862
bb_rcgclear862:
  %v4488 = load i64, ptr %slot682, align 8
  %p4489 = inttoptr i64 %v4488 to ptr
  store i64 0, ptr %p4489, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone862
bb_rcgdone862:
  br label %bb_rcslotdone831
bb_rcslotdone831:
  %v4490 = load i64, ptr %slot44, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  %ld4492 = load i64, ptr %p4491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4492, ptr %slot713, align 8
  %v4493 = load i64, ptr %slot713, align 8
  %v4494 = load i64, ptr %slot44, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  store i64 %v4493, ptr %p4495, align 8, !alias.scope !3, !noalias !4
  br label %bb_i70
bb_i70:
  %v4496 = load i64, ptr %slot45, align 8
  %p4497 = inttoptr i64 %v4496 to ptr
  store i64 46, ptr %p4497, align 8, !alias.scope !3, !noalias !4
  %v4498 = load i64, ptr %slot45, align 8
  %p4499 = inttoptr i64 %v4498 to ptr
  %ld4500 = load i64, ptr %p4499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4500, ptr %slot714, align 8
  %v4501 = load i64, ptr %slot44, align 8
  %p4502 = inttoptr i64 %v4501 to ptr
  %ld4503 = load i64, ptr %p4502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4503, ptr %slot715, align 8
  %v4504 = load i64, ptr %slot715, align 8
  %v4505 = load i64, ptr %slot714, align 8
  %cmp4506 = icmp eq i64 %v4504, %v4505
  %cv4507 = zext i1 %cmp4506 to i64
  store i64 %cv4507, ptr %slot716, align 8
  %v4508 = load i64, ptr %slot716, align 8
  %v4509 = load i64, ptr %slot44, align 8
  %p4510 = inttoptr i64 %v4509 to ptr
  store i64 %v4508, ptr %p4510, align 8, !alias.scope !3, !noalias !4
  %v4511 = load i64, ptr %slot44, align 8
  %p4512 = inttoptr i64 %v4511 to ptr
  %ld4513 = load i64, ptr %p4512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4513, ptr %slot717, align 8
  %v4514 = load i64, ptr %slot717, align 8
  %cond4515 = icmp ne i64 %v4514, 0
  br i1 %cond4515, label %bb_next871, label %bb_i107
bb_next871:
  %v4516 = load i64, ptr %slot30, align 8
  %p4517 = inttoptr i64 %v4516 to ptr
  %ld4518 = load i64, ptr %p4517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4518, ptr %slot718, align 8
  %v4519 = load i64, ptr %slot718, align 8
  %v4520 = load i64, ptr %slot44, align 8
  %p4521 = inttoptr i64 %v4520 to ptr
  store i64 %v4519, ptr %p4521, align 8, !alias.scope !3, !noalias !4
  %v4522 = load i64, ptr %slot44, align 8
  %p4523 = inttoptr i64 %v4522 to ptr
  %ld4524 = load i64, ptr %p4523, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4524, ptr %slot719, align 8
  %v4525 = load i64, ptr %slot19, align 8
  %p4526 = inttoptr i64 %v4525 to ptr
  %ld4527 = load i32, ptr %p4526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4527, ptr %slot720, align 8
  %v4528 = load i64, ptr %slot20, align 8
  %p4529 = inttoptr i64 %v4528 to ptr
  %ld4530 = load i32, ptr %p4529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4530, ptr %slot721, align 8
  %v4531 = load i32, ptr %slot721, align 8
  %op4532 = and i32 %v4531, 24
  store i32 %op4532, ptr %slot721, align 8
  %v4533 = load i32, ptr %slot721, align 8
  %cmp4534 = icmp eq i32 %v4533, 0
  %cv4535 = zext i1 %cmp4534 to i32
  store i32 %cv4535, ptr %slot722, align 8
  %v4536 = load i32, ptr %slot720, align 8
  %v4537 = load i32, ptr %slot722, align 8
  %op4538 = and i32 %v4536, %v4537
  store i32 %op4538, ptr %slot723, align 8
  %v4539 = load i32, ptr %slot723, align 8
  %cv4540 = zext i32 %v4539 to i64
  %cond4541 = icmp ne i64 %cv4540, 0
  br i1 %cond4541, label %bb_rctake873, label %bb_rccopy873
bb_rctake873:
  %v4542 = load i64, ptr %slot29, align 8
  store i64 %v4542, ptr %slot724, align 8
  %v4543 = load i64, ptr %slot53, align 8
  store i64 %v4543, ptr %slot725, align 8
  %v4544 = load i64, ptr %slot719, align 8
  %v4545 = load i64, ptr %slot724, align 8
  %op4546 = sub i64 %v4544, %v4545
  store i64 %op4546, ptr %slot726, align 8
  %v4547 = load i64, ptr %slot724, align 8
  %v4548 = load i64, ptr %slot719, align 8
  %op4549 = sub i64 %v4547, %v4548
  store i64 %op4549, ptr %slot727, align 8
  %v4550 = load i64, ptr %slot726, align 8
  %cmp4551 = icmp ult i64 %v4550, 32
  %cv4552 = zext i1 %cmp4551 to i32
  store i32 %cv4552, ptr %slot728, align 8
  %v4553 = load i64, ptr %slot727, align 8
  %cmp4554 = icmp ult i64 %v4553, 32
  %cv4555 = zext i1 %cmp4554 to i32
  store i32 %cv4555, ptr %slot729, align 8
  %v4556 = load i32, ptr %slot728, align 8
  %v4557 = load i32, ptr %slot729, align 8
  %op4558 = or i32 %v4556, %v4557
  store i32 %op4558, ptr %slot730, align 8
  %v4559 = load i32, ptr %slot730, align 8
  %cv4560 = zext i32 %v4559 to i64
  %cond4561 = icmp ne i64 %cv4560, 0
  br i1 %cond4561, label %bb_rcmoveslow882, label %bb_rcmovecheck882
bb_rcmovecheck882:
  %v4562 = load i64, ptr %slot719, align 8
  %op4563 = add i64 %v4562, 0
  store i64 %op4563, ptr %slot731, align 8
  %v4564 = load i64, ptr %slot731, align 8
  %p4565 = inttoptr i64 %v4564 to ptr
  %ld4566 = load i64, ptr %p4565, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4566, ptr %slot732, align 8
  %v4567 = load i64, ptr %slot732, align 8
  %cmp4568 = icmp ne i64 %v4567, 0
  %cv4569 = zext i1 %cmp4568 to i32
  store i32 %cv4569, ptr %slot733, align 8
  %v4570 = load i32, ptr %slot733, align 8
  %cv4571 = zext i32 %v4570 to i64
  %cond4572 = icmp ne i64 %cv4571, 0
  br i1 %cond4572, label %bb_rcmoveheader890, label %bb_rcmovenext890
bb_rcmoveheader890:
  %v4573 = load i64, ptr %slot732, align 8
  %op4574 = sub i64 %v4573, 16
  store i64 %op4574, ptr %slot734, align 8
  %v4575 = load i64, ptr %slot732, align 8
  %p4576 = inttoptr i64 %v4575 to ptr
  %rgep4577 = getelementptr i8, ptr %p4576, i64 -16
  %ld4578 = load i64, ptr %rgep4577, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4578, ptr %slot735, align 8
  %v4579 = load i64, ptr %slot735, align 8
  %op4580 = and i64 %v4579, 5764607523034234881
  store i64 %op4580, ptr %slot736, align 8
  %v4581 = load i64, ptr %slot736, align 8
  %cmp4582 = icmp ne i64 %v4581, 0
  %cv4583 = zext i1 %cmp4582 to i32
  store i32 %cv4583, ptr %slot737, align 8
  %v4584 = load i32, ptr %slot737, align 8
  %cv4585 = zext i32 %v4584 to i64
  %cond4586 = icmp ne i64 %cv4585, 0
  br i1 %cond4586, label %bb_rcmoveslow882, label %bb_rcmovenext890
bb_rcmovenext890:
  %v4587 = load i64, ptr %slot719, align 8
  %v4588 = load i64, ptr %slot724, align 8
  %p4589 = inttoptr i64 %v4587 to ptr
  %p4590 = inttoptr i64 %v4588 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4590, ptr %p4589, i64 32, i1 false), !alias.scope !10000000
  %v4591 = load i64, ptr %slot719, align 8
  %p4592 = inttoptr i64 %v4591 to ptr
  store i64 0, ptr %p4592, align 8, !alias.scope !4, !noalias !3
  %v4593 = load i64, ptr %slot719, align 8
  %op4594 = add i64 %v4593, 8
  store i64 %op4594, ptr %slot738, align 8
  %v4595 = load i64, ptr %slot738, align 8
  %p4596 = inttoptr i64 %v4595 to ptr
  store i64 0, ptr %p4596, align 8, !alias.scope !4, !noalias !3
  %v4597 = load i64, ptr %slot719, align 8
  %op4598 = add i64 %v4597, 16
  store i64 %op4598, ptr %slot739, align 8
  %v4599 = load i64, ptr %slot739, align 8
  %p4600 = inttoptr i64 %v4599 to ptr
  store i64 0, ptr %p4600, align 8, !alias.scope !4, !noalias !3
  %v4601 = load i64, ptr %slot719, align 8
  %op4602 = add i64 %v4601, 24
  store i64 %op4602, ptr %slot740, align 8
  %v4603 = load i64, ptr %slot740, align 8
  %p4604 = inttoptr i64 %v4603 to ptr
  store i64 0, ptr %p4604, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved882
bb_rcmoveslow882:
  %v4605 = load i64, ptr %slot52, align 8
  %v4606 = load i64, ptr %slot724, align 8
  %v4607 = load i64, ptr %slot719, align 8
  %v4608 = load i64, ptr %slot725, align 8
  %cv4609 = trunc i64 %v4608 to i32
  %call4610 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v4605, i64 %v4606, i64 %v4607, i32 %cv4609) nomerge, !dbg !150
  store i32 %call4610, ptr %slot741, align 8
  %v4611 = load i32, ptr %slot741, align 8
  %cv4612 = zext i32 %v4611 to i64
  %cond4613 = icmp ne i64 %cv4612, 0
  br i1 %cond4613, label %bb_rcsuccess900, label %bb_rcfailure900
bb_rcfailure900:
  %v4614 = load i64, ptr %slot52, align 8
  %p4615 = inttoptr i64 %v4614 to ptr
  %call4616 = call i32 @myl_rc_take_failure(ptr %p4615) nomerge, !dbg !150
  store i32 %call4616, ptr %slot742, align 8
  %v4617 = load i64, ptr %slot1, align 8
  %p4618 = inttoptr i64 %v4617 to ptr
  %v4619 = load i32, ptr %slot742, align 8
  %call4620 = call i32 @myl_qbe_rc_status(ptr %p4618, i32 %v4619) nomerge, !dbg !150
  store i32 %call4620, ptr %slot743, align 8
  br label %bb_failure
bb_rcsuccess900:
  br label %bb_rcmoved882
bb_rcmoved882:
  %v4621 = load i64, ptr %slot19, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  store i32 0, ptr %p4622, align 4, !alias.scope !3, !noalias !4
  %v4623 = load i64, ptr %slot24, align 8
  %p4624 = inttoptr i64 %v4623 to ptr
  store i32 2, ptr %p4624, align 4, !alias.scope !3, !noalias !4
  %v4625 = load i64, ptr %slot23, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  store i32 1, ptr %p4626, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared873
bb_rccopy873:
  %v4627 = load i64, ptr %slot29, align 8
  store i64 %v4627, ptr %slot744, align 8
  %v4628 = load i64, ptr %slot53, align 8
  store i64 %v4628, ptr %slot745, align 8
  %v4629 = load i64, ptr %slot52, align 8
  %v4630 = load i64, ptr %slot744, align 8
  %v4631 = load i64, ptr %slot719, align 8
  %v4632 = load i64, ptr %slot745, align 8
  %cv4633 = trunc i64 %v4632 to i32
  %call4634 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v4629, i64 %v4630, i64 %v4631, i32 %cv4633) nomerge, !dbg !150
  store i32 %call4634, ptr %slot746, align 8
  %v4635 = load i32, ptr %slot746, align 8
  %cv4636 = zext i32 %v4635 to i64
  %cond4637 = icmp ne i64 %cv4636, 0
  br i1 %cond4637, label %bb_rcsuccess909, label %bb_rcfailure909
bb_rcfailure909:
  %v4638 = load i64, ptr %slot52, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  %call4640 = call i32 @myl_rc_take_failure(ptr %p4639) nomerge, !dbg !150
  store i32 %call4640, ptr %slot747, align 8
  %v4641 = load i64, ptr %slot1, align 8
  %p4642 = inttoptr i64 %v4641 to ptr
  %v4643 = load i32, ptr %slot747, align 8
  %call4644 = call i32 @myl_qbe_rc_status(ptr %p4642, i32 %v4643) nomerge, !dbg !150
  store i32 %call4644, ptr %slot748, align 8
  br label %bb_failure
bb_rcsuccess909:
  %v4645 = load i64, ptr %slot24, align 8
  %p4646 = inttoptr i64 %v4645 to ptr
  store i32 2, ptr %p4646, align 4, !alias.scope !3, !noalias !4
  %v4647 = load i64, ptr %slot23, align 8
  %p4648 = inttoptr i64 %v4647 to ptr
  store i32 1, ptr %p4648, align 4, !alias.scope !3, !noalias !4
  %v4649 = load i64, ptr %slot19, align 8
  %p4650 = inttoptr i64 %v4649 to ptr
  %ld4651 = load i32, ptr %p4650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4651, ptr %slot749, align 8
  %v4652 = load i32, ptr %slot749, align 8
  %cv4653 = zext i32 %v4652 to i64
  %cond4654 = icmp ne i64 %cv4653, 0
  br i1 %cond4654, label %bb_rcslotdrop916, label %bb_rcslotdone916
bb_rcslotdrop916:
  %v4655 = load i64, ptr %slot19, align 8
  %p4656 = inttoptr i64 %v4655 to ptr
  store i32 0, ptr %p4656, align 4, !alias.scope !3, !noalias !4
  %v4657 = load i64, ptr %slot25, align 8
  store i64 %v4657, ptr %slot750, align 8
  %v4658 = load i64, ptr %slot20, align 8
  %p4659 = inttoptr i64 %v4658 to ptr
  %ld4660 = load i32, ptr %p4659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4660, ptr %slot751, align 8
  %v4661 = load i32, ptr %slot751, align 8
  %op4662 = and i32 %v4661, 28
  store i32 %op4662, ptr %slot752, align 8
  %v4663 = load i32, ptr %slot752, align 8
  %cv4664 = zext i32 %v4663 to i64
  %cond4665 = icmp ne i64 %cv4664, 0
  br i1 %cond4665, label %bb_rcslotrole916, label %bb_rcslotowner916
bb_rcslotrole916:
  %v4666 = load i64, ptr %slot52, align 8
  store i64 %v4666, ptr %slot753, align 8
  %v4667 = load i64, ptr %slot753, align 8
  %v4668 = load i64, ptr %slot750, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4667, i64 %v4668) nomerge, !dbg !150
  br label %bb_rcslotdone916
bb_rcslotowner916:
  %v4669 = load i64, ptr %slot750, align 8
  %p4671 = inttoptr i64 %v4669 to ptr
  %gep4672 = getelementptr i8, ptr %p4671, i64 0
  %op4670 = ptrtoint ptr %gep4672 to i64
  store i64 %op4670, ptr %slot754, align 8
  %v4673 = load i64, ptr %slot52, align 8
  store i64 %v4673, ptr %slot755, align 8
  %v4674 = load i64, ptr %slot754, align 8
  %p4675 = inttoptr i64 %v4674 to ptr
  %ld4676 = load i64, ptr %p4675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4676, ptr %slot756, align 8
  %v4677 = load i64, ptr %slot756, align 8
  %cmp4678 = icmp ne i64 %v4677, 0
  %cv4679 = zext i1 %cmp4678 to i32
  store i32 %cv4679, ptr %slot757, align 8
  %v4680 = load i32, ptr %slot757, align 8
  %cv4681 = zext i32 %v4680 to i64
  %cond4682 = icmp ne i64 %cv4681, 0
  br i1 %cond4682, label %bb_rcgnn934, label %bb_rcgdone934
bb_rcgnn934:
  %v4683 = load i64, ptr %slot756, align 8
  %op4684 = sub i64 %v4683, 16
  store i64 %op4684, ptr %slot758, align 8
  %v4685 = load i64, ptr %slot756, align 8
  %p4686 = inttoptr i64 %v4685 to ptr
  %rgep4687 = getelementptr i8, ptr %p4686, i64 -16
  %ld4688 = load i64, ptr %rgep4687, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4688, ptr %slot759, align 8
  %v4689 = load i64, ptr %slot759, align 8
  %op4690 = and i64 %v4689, 4611686018427387906
  store i64 %op4690, ptr %slot760, align 8
  %v4691 = load i64, ptr %slot760, align 8
  %cmp4692 = icmp ne i64 %v4691, 0
  %cv4693 = zext i1 %cmp4692 to i32
  store i32 %cv4693, ptr %slot761, align 8
  %v4694 = load i32, ptr %slot761, align 8
  %cv4695 = zext i32 %v4694 to i64
  %cond4696 = icmp ne i64 %cv4695, 0
  br i1 %cond4696, label %bb_rcgclear934, label %bb_rcgcounted934
bb_rcgcounted934:
  %v4697 = load i64, ptr %slot756, align 8
  %op4698 = sub i64 %v4697, 32
  store i64 %op4698, ptr %slot762, align 8
  %v4699 = load i64, ptr %slot756, align 8
  %p4700 = inttoptr i64 %v4699 to ptr
  %rgep4701 = getelementptr i8, ptr %p4700, i64 -32
  %ld4702 = load i64, ptr %rgep4701, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4702, ptr %slot763, align 8
  %v4703 = load i64, ptr %slot763, align 8
  %op4704 = sub i64 %v4703, 1
  store i64 %op4704, ptr %slot764, align 8
  %v4705 = load i64, ptr %slot764, align 8
  %cmp4706 = icmp eq i64 %v4705, 0
  %cv4707 = zext i1 %cmp4706 to i32
  store i32 %cv4707, ptr %slot765, align 8
  %v4708 = load i32, ptr %slot765, align 8
  %cv4709 = zext i32 %v4708 to i64
  %cond4710 = icmp ne i64 %cv4709, 0
  br i1 %cond4710, label %bb_rcglast934, label %bb_rcgdec934
bb_rcglast934:
  %v4711 = load i64, ptr %slot756, align 8
  %op4712 = sub i64 %v4711, 24
  store i64 %op4712, ptr %slot766, align 8
  %v4713 = load i64, ptr %slot756, align 8
  %p4714 = inttoptr i64 %v4713 to ptr
  %rgep4715 = getelementptr i8, ptr %p4714, i64 -24
  %ld4716 = load i64, ptr %rgep4715, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4716, ptr %slot767, align 8
  %v4717 = load i64, ptr %slot767, align 8
  %cmp4718 = icmp ne i64 %v4717, 0
  %cv4719 = zext i1 %cmp4718 to i32
  store i32 %cv4719, ptr %slot768, align 8
  %v4720 = load i32, ptr %slot768, align 8
  %cv4721 = zext i32 %v4720 to i64
  %cond4722 = icmp ne i64 %cv4721, 0
  br i1 %cond4722, label %bb_rcgdec934, label %bb_rcgslow934
bb_rcgslow934:
  %v4723 = load i64, ptr %slot755, align 8
  %v4724 = load i64, ptr %slot754, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4723, i64 %v4724) nomerge, !dbg !150
  br label %bb_rcgdone934
bb_rcgdec934:
  %v4725 = load i64, ptr %slot764, align 8
  %v4726 = load i64, ptr %slot756, align 8
  %p4727 = inttoptr i64 %v4726 to ptr
  %rgep4728 = getelementptr i8, ptr %p4727, i64 -32
  store i64 %v4725, ptr %rgep4728, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear934
bb_rcgclear934:
  %v4729 = load i64, ptr %slot754, align 8
  %p4730 = inttoptr i64 %v4729 to ptr
  store i64 0, ptr %p4730, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone934
bb_rcgdone934:
  %v4731 = load i64, ptr %slot750, align 8
  %p4732 = inttoptr i64 %v4731 to ptr
  store i64 0, ptr %p4732, align 8, !alias.scope !3, !noalias !4
  %v4733 = load i64, ptr %slot750, align 8
  %p4735 = inttoptr i64 %v4733 to ptr
  %gep4736 = getelementptr i8, ptr %p4735, i64 8
  %op4734 = ptrtoint ptr %gep4736 to i64
  store i64 %op4734, ptr %slot769, align 8
  %v4737 = load i64, ptr %slot769, align 8
  %p4738 = inttoptr i64 %v4737 to ptr
  store i64 0, ptr %p4738, align 8, !alias.scope !3, !noalias !4
  %v4739 = load i64, ptr %slot750, align 8
  %p4741 = inttoptr i64 %v4739 to ptr
  %gep4742 = getelementptr i8, ptr %p4741, i64 16
  %op4740 = ptrtoint ptr %gep4742 to i64
  store i64 %op4740, ptr %slot770, align 8
  %v4743 = load i64, ptr %slot770, align 8
  %p4744 = inttoptr i64 %v4743 to ptr
  store i64 0, ptr %p4744, align 8, !alias.scope !3, !noalias !4
  %v4745 = load i64, ptr %slot750, align 8
  %p4747 = inttoptr i64 %v4745 to ptr
  %gep4748 = getelementptr i8, ptr %p4747, i64 24
  %op4746 = ptrtoint ptr %gep4748 to i64
  store i64 %op4746, ptr %slot771, align 8
  %v4749 = load i64, ptr %slot771, align 8
  %p4750 = inttoptr i64 %v4749 to ptr
  store i64 0, ptr %p4750, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone916
bb_rcslotdone916:
  br label %bb_rcprepared873
bb_rcprepared873:
  %v4751 = load i64, ptr %slot13, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  %ld4753 = load i32, ptr %p4752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4753, ptr %slot772, align 8
  %v4754 = load i32, ptr %slot772, align 8
  %cv4755 = zext i32 %v4754 to i64
  %cond4756 = icmp ne i64 %cv4755, 0
  br i1 %cond4756, label %bb_rcslotdrop944, label %bb_rcslotdone944
bb_rcslotdrop944:
  %v4757 = load i64, ptr %slot13, align 8
  %p4758 = inttoptr i64 %v4757 to ptr
  store i32 0, ptr %p4758, align 4, !alias.scope !3, !noalias !4
  %v4759 = load i64, ptr %slot39, align 8
  store i64 %v4759, ptr %slot773, align 8
  %v4760 = load i64, ptr %slot14, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  %ld4762 = load i32, ptr %p4761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4762, ptr %slot774, align 8
  %v4763 = load i32, ptr %slot774, align 8
  %op4764 = and i32 %v4763, 28
  store i32 %op4764, ptr %slot775, align 8
  %v4765 = load i32, ptr %slot775, align 8
  %cv4766 = zext i32 %v4765 to i64
  %cond4767 = icmp ne i64 %cv4766, 0
  br i1 %cond4767, label %bb_rcslotrole944, label %bb_rcslotowner944
bb_rcslotrole944:
  %v4768 = load i64, ptr %slot52, align 8
  store i64 %v4768, ptr %slot776, align 8
  %v4769 = load i64, ptr %slot776, align 8
  %v4770 = load i64, ptr %slot773, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4769, i64 %v4770) nomerge, !dbg !150
  br label %bb_rcslotdone944
bb_rcslotowner944:
  %v4771 = load i64, ptr %slot773, align 8
  %p4773 = inttoptr i64 %v4771 to ptr
  %gep4774 = getelementptr i8, ptr %p4773, i64 0
  %op4772 = ptrtoint ptr %gep4774 to i64
  store i64 %op4772, ptr %slot777, align 8
  %v4775 = load i64, ptr %slot52, align 8
  store i64 %v4775, ptr %slot778, align 8
  %v4776 = load i64, ptr %slot777, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %ld4778 = load i64, ptr %p4777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4778, ptr %slot779, align 8
  %v4779 = load i64, ptr %slot779, align 8
  %cmp4780 = icmp ne i64 %v4779, 0
  %cv4781 = zext i1 %cmp4780 to i32
  store i32 %cv4781, ptr %slot780, align 8
  %v4782 = load i32, ptr %slot780, align 8
  %cv4783 = zext i32 %v4782 to i64
  %cond4784 = icmp ne i64 %cv4783, 0
  br i1 %cond4784, label %bb_rcgnn962, label %bb_rcgdone962
bb_rcgnn962:
  %v4785 = load i64, ptr %slot779, align 8
  %op4786 = sub i64 %v4785, 16
  store i64 %op4786, ptr %slot781, align 8
  %v4787 = load i64, ptr %slot779, align 8
  %p4788 = inttoptr i64 %v4787 to ptr
  %rgep4789 = getelementptr i8, ptr %p4788, i64 -16
  %ld4790 = load i64, ptr %rgep4789, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4790, ptr %slot782, align 8
  %v4791 = load i64, ptr %slot782, align 8
  %op4792 = and i64 %v4791, 4611686018427387906
  store i64 %op4792, ptr %slot783, align 8
  %v4793 = load i64, ptr %slot783, align 8
  %cmp4794 = icmp ne i64 %v4793, 0
  %cv4795 = zext i1 %cmp4794 to i32
  store i32 %cv4795, ptr %slot784, align 8
  %v4796 = load i32, ptr %slot784, align 8
  %cv4797 = zext i32 %v4796 to i64
  %cond4798 = icmp ne i64 %cv4797, 0
  br i1 %cond4798, label %bb_rcgclear962, label %bb_rcgcounted962
bb_rcgcounted962:
  %v4799 = load i64, ptr %slot779, align 8
  %op4800 = sub i64 %v4799, 32
  store i64 %op4800, ptr %slot785, align 8
  %v4801 = load i64, ptr %slot779, align 8
  %p4802 = inttoptr i64 %v4801 to ptr
  %rgep4803 = getelementptr i8, ptr %p4802, i64 -32
  %ld4804 = load i64, ptr %rgep4803, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4804, ptr %slot786, align 8
  %v4805 = load i64, ptr %slot786, align 8
  %op4806 = sub i64 %v4805, 1
  store i64 %op4806, ptr %slot787, align 8
  %v4807 = load i64, ptr %slot787, align 8
  %cmp4808 = icmp eq i64 %v4807, 0
  %cv4809 = zext i1 %cmp4808 to i32
  store i32 %cv4809, ptr %slot788, align 8
  %v4810 = load i32, ptr %slot788, align 8
  %cv4811 = zext i32 %v4810 to i64
  %cond4812 = icmp ne i64 %cv4811, 0
  br i1 %cond4812, label %bb_rcglast962, label %bb_rcgdec962
bb_rcglast962:
  %v4813 = load i64, ptr %slot779, align 8
  %op4814 = sub i64 %v4813, 24
  store i64 %op4814, ptr %slot789, align 8
  %v4815 = load i64, ptr %slot779, align 8
  %p4816 = inttoptr i64 %v4815 to ptr
  %rgep4817 = getelementptr i8, ptr %p4816, i64 -24
  %ld4818 = load i64, ptr %rgep4817, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4818, ptr %slot790, align 8
  %v4819 = load i64, ptr %slot790, align 8
  %cmp4820 = icmp ne i64 %v4819, 0
  %cv4821 = zext i1 %cmp4820 to i32
  store i32 %cv4821, ptr %slot791, align 8
  %v4822 = load i32, ptr %slot791, align 8
  %cv4823 = zext i32 %v4822 to i64
  %cond4824 = icmp ne i64 %cv4823, 0
  br i1 %cond4824, label %bb_rcgdec962, label %bb_rcgslow962
bb_rcgslow962:
  %v4825 = load i64, ptr %slot778, align 8
  %v4826 = load i64, ptr %slot777, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4825, i64 %v4826) nomerge, !dbg !150
  br label %bb_rcgdone962
bb_rcgdec962:
  %v4827 = load i64, ptr %slot787, align 8
  %v4828 = load i64, ptr %slot779, align 8
  %p4829 = inttoptr i64 %v4828 to ptr
  %rgep4830 = getelementptr i8, ptr %p4829, i64 -32
  store i64 %v4827, ptr %rgep4830, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear962
bb_rcgclear962:
  %v4831 = load i64, ptr %slot777, align 8
  %p4832 = inttoptr i64 %v4831 to ptr
  store i64 0, ptr %p4832, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone962
bb_rcgdone962:
  %v4833 = load i64, ptr %slot773, align 8
  %p4834 = inttoptr i64 %v4833 to ptr
  store i64 0, ptr %p4834, align 8, !alias.scope !3, !noalias !4
  %v4835 = load i64, ptr %slot773, align 8
  %p4837 = inttoptr i64 %v4835 to ptr
  %gep4838 = getelementptr i8, ptr %p4837, i64 8
  %op4836 = ptrtoint ptr %gep4838 to i64
  store i64 %op4836, ptr %slot792, align 8
  %v4839 = load i64, ptr %slot792, align 8
  %p4840 = inttoptr i64 %v4839 to ptr
  store i64 0, ptr %p4840, align 8, !alias.scope !3, !noalias !4
  %v4841 = load i64, ptr %slot773, align 8
  %p4843 = inttoptr i64 %v4841 to ptr
  %gep4844 = getelementptr i8, ptr %p4843, i64 16
  %op4842 = ptrtoint ptr %gep4844 to i64
  store i64 %op4842, ptr %slot793, align 8
  %v4845 = load i64, ptr %slot793, align 8
  %p4846 = inttoptr i64 %v4845 to ptr
  store i64 0, ptr %p4846, align 8, !alias.scope !3, !noalias !4
  %v4847 = load i64, ptr %slot773, align 8
  %p4849 = inttoptr i64 %v4847 to ptr
  %gep4850 = getelementptr i8, ptr %p4849, i64 24
  %op4848 = ptrtoint ptr %gep4850 to i64
  store i64 %op4848, ptr %slot794, align 8
  %v4851 = load i64, ptr %slot794, align 8
  %p4852 = inttoptr i64 %v4851 to ptr
  store i64 0, ptr %p4852, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone944
bb_rcslotdone944:
  %v4853 = load i64, ptr %slot39, align 8
  store i64 %v4853, ptr %slot795, align 8
  %v4854 = load i64, ptr %slot29, align 8
  store i64 %v4854, ptr %slot796, align 8
  %v4855 = load i64, ptr %slot796, align 8
  %v4856 = load i64, ptr %slot795, align 8
  %p4857 = inttoptr i64 %v4855 to ptr
  %p4858 = inttoptr i64 %v4856 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4858, ptr %p4857, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v4859 = load i64, ptr %slot23, align 8
  %p4860 = inttoptr i64 %v4859 to ptr
  store i32 0, ptr %p4860, align 4, !alias.scope !3, !noalias !4
  %v4861 = load i64, ptr %slot14, align 8
  %p4862 = inttoptr i64 %v4861 to ptr
  store i32 2, ptr %p4862, align 4, !alias.scope !3, !noalias !4
  %v4863 = load i64, ptr %slot24, align 8
  %p4864 = inttoptr i64 %v4863 to ptr
  %ld4865 = load i32, ptr %p4864, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4865, ptr %slot797, align 8
  %v4866 = load i32, ptr %slot797, align 8
  %v4867 = load i64, ptr %slot14, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  store i32 %v4866, ptr %p4868, align 4, !alias.scope !3, !noalias !4
  %v4869 = load i64, ptr %slot13, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  store i32 1, ptr %p4870, align 4, !alias.scope !3, !noalias !4
  %v4871 = load i64, ptr %slot39, align 8
  %v4872 = load i64, ptr %slot44, align 8
  %p4873 = inttoptr i64 %v4872 to ptr
  store i64 %v4871, ptr %p4873, align 8, !alias.scope !3, !noalias !4
  %v4874 = load i64, ptr %slot44, align 8
  %p4875 = inttoptr i64 %v4874 to ptr
  %ld4876 = load i64, ptr %p4875, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4876, ptr %slot798, align 8
  %v4877 = load i64, ptr %slot798, align 8
  %op4878 = add i64 %v4877, 16
  store i64 %op4878, ptr %slot799, align 8
  %v4879 = load i64, ptr %slot799, align 8
  %p4880 = inttoptr i64 %v4879 to ptr
  %ld4881 = load i64, ptr %p4880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4881, ptr %slot800, align 8
  %v4882 = load i64, ptr %slot800, align 8
  %v4883 = load i64, ptr %slot44, align 8
  %p4884 = inttoptr i64 %v4883 to ptr
  store i64 %v4882, ptr %p4884, align 8, !alias.scope !3, !noalias !4
  %v4885 = load i64, ptr %slot19, align 8
  %p4886 = inttoptr i64 %v4885 to ptr
  %ld4887 = load i32, ptr %p4886, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4887, ptr %slot801, align 8
  %v4888 = load i32, ptr %slot801, align 8
  %cv4889 = zext i32 %v4888 to i64
  %cond4890 = icmp ne i64 %cv4889, 0
  br i1 %cond4890, label %bb_rcslotdrop981, label %bb_rcslotdone981
bb_rcslotdrop981:
  %v4891 = load i64, ptr %slot19, align 8
  %p4892 = inttoptr i64 %v4891 to ptr
  store i32 0, ptr %p4892, align 4, !alias.scope !3, !noalias !4
  %v4893 = load i64, ptr %slot25, align 8
  store i64 %v4893, ptr %slot802, align 8
  %v4894 = load i64, ptr %slot20, align 8
  %p4895 = inttoptr i64 %v4894 to ptr
  %ld4896 = load i32, ptr %p4895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4896, ptr %slot803, align 8
  %v4897 = load i32, ptr %slot803, align 8
  %op4898 = and i32 %v4897, 28
  store i32 %op4898, ptr %slot804, align 8
  %v4899 = load i32, ptr %slot804, align 8
  %cv4900 = zext i32 %v4899 to i64
  %cond4901 = icmp ne i64 %cv4900, 0
  br i1 %cond4901, label %bb_rcslotrole981, label %bb_rcslotowner981
bb_rcslotrole981:
  %v4902 = load i64, ptr %slot52, align 8
  store i64 %v4902, ptr %slot805, align 8
  %v4903 = load i64, ptr %slot805, align 8
  %v4904 = load i64, ptr %slot802, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4903, i64 %v4904) nomerge, !dbg !152
  br label %bb_rcslotdone981
bb_rcslotowner981:
  %v4905 = load i64, ptr %slot52, align 8
  store i64 %v4905, ptr %slot806, align 8
  %v4906 = load i64, ptr %slot806, align 8
  %v4907 = load i64, ptr %slot802, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4906, i64 %v4907) nomerge, !dbg !152
  br label %bb_rcslotdone981
bb_rcslotdone981:
  %v4908 = load i64, ptr %slot45, align 8
  %p4909 = inttoptr i64 %v4908 to ptr
  store i64 1, ptr %p4909, align 8, !alias.scope !3, !noalias !4
  %v4910 = load i64, ptr %slot45, align 8
  %p4911 = inttoptr i64 %v4910 to ptr
  %ld4912 = load i64, ptr %p4911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4912, ptr %slot807, align 8
  %v4913 = load i64, ptr %slot44, align 8
  %p4914 = inttoptr i64 %v4913 to ptr
  %ld4915 = load i64, ptr %p4914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4915, ptr %slot808, align 8
  %v4916 = load i64, ptr %slot808, align 8
  %v4917 = load i64, ptr %slot807, align 8
  %ovpair4919 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4916, i64 %v4917)
  %op4918 = extractvalue { i64, i1 } %ovpair4919, 0
  %ov4920 = extractvalue { i64, i1 } %ovpair4919, 1
  store i64 %op4918, ptr %slot809, align 8
  %cv4921 = zext i1 %ov4920 to i64
  store i64 %cv4921, ptr %slot810, align 8
  %v4922 = load i64, ptr %slot810, align 8
  %cond4923 = icmp ne i64 %v4922, 0
  br i1 %cond4923, label %bb_overflow990, label %bb_checked990
bb_overflow990:
  %v4924 = load i64, ptr %slot1, align 8
  %p4925 = inttoptr i64 %v4924 to ptr
  %v4926 = load i64, ptr %slot808, align 8
  %v4927 = load i64, ptr %slot807, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4925, i64 0, i64 %v4926, i64 %v4927, i64 64) nomerge, !dbg !154
  unreachable
bb_checked990:
  %v4928 = load i64, ptr %slot809, align 8
  %v4929 = load i64, ptr %slot44, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  store i64 %v4928, ptr %p4930, align 8, !alias.scope !3, !noalias !4
  %v4931 = load i64, ptr %slot39, align 8
  %v4932 = load i64, ptr %slot45, align 8
  %p4933 = inttoptr i64 %v4932 to ptr
  store i64 %v4931, ptr %p4933, align 8, !alias.scope !3, !noalias !4
  %v4934 = load i64, ptr %slot45, align 8
  %p4935 = inttoptr i64 %v4934 to ptr
  %ld4936 = load i64, ptr %p4935, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4936, ptr %slot811, align 8
  %v4937 = load i64, ptr %slot811, align 8
  %op4938 = add i64 %v4937, 0
  store i64 %op4938, ptr %slot812, align 8
  %v4939 = load i64, ptr %slot812, align 8
  %p4940 = inttoptr i64 %v4939 to ptr
  %ld4941 = load i64, ptr %p4940, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4941, ptr %slot813, align 8
  %v4942 = load i64, ptr %slot813, align 8
  %v4943 = load i64, ptr %slot45, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  store i64 %v4942, ptr %p4944, align 8, !alias.scope !3, !noalias !4
  %v4945 = load i64, ptr %slot45, align 8
  %p4946 = inttoptr i64 %v4945 to ptr
  %ld4947 = load i64, ptr %p4946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4947, ptr %slot814, align 8
  %v4948 = load i64, ptr %slot814, align 8
  %v4949 = load i64, ptr %slot28, align 8
  %p4950 = inttoptr i64 %v4949 to ptr
  store i64 %v4948, ptr %p4950, align 8, !alias.scope !3, !noalias !4
  %v4951 = load i64, ptr %slot28, align 8
  store i64 %v4951, ptr %slot815, align 8
  %v4952 = load i64, ptr %slot29, align 8
  store i64 %v4952, ptr %slot816, align 8
  %v4953 = load i64, ptr %slot815, align 8
  %p4954 = inttoptr i64 %v4953 to ptr
  %ld4955 = load i64, ptr %p4954, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4955, ptr %slot817, align 8
  %v4956 = load i64, ptr %slot817, align 8
  %cmp4957 = icmp ne i64 %v4956, 0
  %cv4958 = zext i1 %cmp4957 to i32
  store i32 %cv4958, ptr %slot818, align 8
  %v4959 = load i32, ptr %slot818, align 8
  %cv4960 = zext i32 %v4959 to i64
  %cond4961 = icmp ne i64 %cv4960, 0
  br i1 %cond4961, label %bb_rcgnn999, label %bb_rcgstore999
bb_rcgnn999:
  %v4962 = load i64, ptr %slot817, align 8
  %op4963 = sub i64 %v4962, 16
  store i64 %op4963, ptr %slot819, align 8
  %v4964 = load i64, ptr %slot817, align 8
  %p4965 = inttoptr i64 %v4964 to ptr
  %rgep4966 = getelementptr i8, ptr %p4965, i64 -16
  %ld4967 = load i64, ptr %rgep4966, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4967, ptr %slot820, align 8
  %v4968 = load i64, ptr %slot820, align 8
  %op4969 = and i64 %v4968, 4611686018427387906
  store i64 %op4969, ptr %slot821, align 8
  %v4970 = load i64, ptr %slot821, align 8
  %cmp4971 = icmp ne i64 %v4970, 0
  %cv4972 = zext i1 %cmp4971 to i32
  store i32 %cv4972, ptr %slot822, align 8
  %v4973 = load i32, ptr %slot822, align 8
  %cv4974 = zext i32 %v4973 to i64
  %cond4975 = icmp ne i64 %cv4974, 0
  br i1 %cond4975, label %bb_rcgstore999, label %bb_rcginc999
bb_rcginc999:
  %v4976 = load i64, ptr %slot817, align 8
  %op4977 = sub i64 %v4976, 24
  store i64 %op4977, ptr %slot823, align 8
  %v4978 = load i64, ptr %slot817, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  %rgep4980 = getelementptr i8, ptr %p4979, i64 -24
  %ld4981 = load i64, ptr %rgep4980, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4981, ptr %slot824, align 8
  %v4982 = load i64, ptr %slot824, align 8
  %op4983 = add i64 %v4982, 1
  store i64 %op4983, ptr %slot825, align 8
  %v4984 = load i64, ptr %slot825, align 8
  %cmp4985 = icmp eq i64 %v4984, 0
  %cv4986 = zext i1 %cmp4985 to i32
  store i32 %cv4986, ptr %slot826, align 8
  %v4987 = load i32, ptr %slot826, align 8
  %cv4988 = zext i32 %v4987 to i64
  %cond4989 = icmp ne i64 %cv4988, 0
  br i1 %cond4989, label %bb_rcglimit999, label %bb_rcgcapacity999
bb_rcglimit999:
  %v4990 = load i64, ptr %slot1, align 8
  %p4991 = inttoptr i64 %v4990 to ptr
  %call4992 = call i32 @myl_qbe_rc_status(ptr %p4991, i32 2) nomerge, !dbg !156
  store i32 %call4992, ptr %slot827, align 8
  br label %bb_failure
bb_rcgcapacity999:
  %v4993 = load i64, ptr %slot825, align 8
  %v4994 = load i64, ptr %slot817, align 8
  %p4995 = inttoptr i64 %v4994 to ptr
  %rgep4996 = getelementptr i8, ptr %p4995, i64 -24
  store i64 %v4993, ptr %rgep4996, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore999
bb_rcgstore999:
  %v4997 = load i64, ptr %slot817, align 8
  %v4998 = load i64, ptr %slot816, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  store i64 %v4997, ptr %p4999, align 8, !alias.scope !3, !noalias !4
  %v5000 = load i64, ptr %slot24, align 8
  %p5001 = inttoptr i64 %v5000 to ptr
  store i32 2, ptr %p5001, align 4, !alias.scope !3, !noalias !4
  %v5002 = load i64, ptr %slot24, align 8
  %p5003 = inttoptr i64 %v5002 to ptr
  store i32 16, ptr %p5003, align 4, !alias.scope !3, !noalias !4
  %v5004 = load i64, ptr %slot23, align 8
  %p5005 = inttoptr i64 %v5004 to ptr
  store i32 1, ptr %p5005, align 4, !alias.scope !3, !noalias !4
  %v5006 = load i64, ptr %slot21, align 8
  %p5007 = inttoptr i64 %v5006 to ptr
  %ld5008 = load i32, ptr %p5007, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5008, ptr %slot828, align 8
  %v5009 = load i32, ptr %slot828, align 8
  %cv5010 = zext i32 %v5009 to i64
  %cond5011 = icmp ne i64 %cv5010, 0
  br i1 %cond5011, label %bb_rcslotdrop1015, label %bb_rcslotdone1015
bb_rcslotdrop1015:
  %v5012 = load i64, ptr %slot21, align 8
  %p5013 = inttoptr i64 %v5012 to ptr
  store i32 0, ptr %p5013, align 4, !alias.scope !3, !noalias !4
  %v5014 = load i64, ptr %slot26, align 8
  store i64 %v5014, ptr %slot829, align 8
  %v5015 = load i64, ptr %slot22, align 8
  %p5016 = inttoptr i64 %v5015 to ptr
  %ld5017 = load i32, ptr %p5016, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5017, ptr %slot830, align 8
  %v5018 = load i32, ptr %slot830, align 8
  %op5019 = and i32 %v5018, 28
  store i32 %op5019, ptr %slot831, align 8
  %v5020 = load i32, ptr %slot831, align 8
  %cv5021 = zext i32 %v5020 to i64
  %cond5022 = icmp ne i64 %cv5021, 0
  br i1 %cond5022, label %bb_rcslotrole1015, label %bb_rcslotowner1015
bb_rcslotrole1015:
  %v5023 = load i64, ptr %slot52, align 8
  store i64 %v5023, ptr %slot832, align 8
  %v5024 = load i64, ptr %slot832, align 8
  %v5025 = load i64, ptr %slot829, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5024, i64 %v5025) nomerge, !dbg !156
  br label %bb_rcslotdone1015
bb_rcslotowner1015:
  %v5026 = load i64, ptr %slot52, align 8
  store i64 %v5026, ptr %slot833, align 8
  %v5027 = load i64, ptr %slot833, align 8
  %v5028 = load i64, ptr %slot829, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5027, i64 %v5028) nomerge, !dbg !156
  br label %bb_rcslotdone1015
bb_rcslotdone1015:
  %v5029 = load i64, ptr %slot26, align 8
  store i64 %v5029, ptr %slot834, align 8
  %v5030 = load i64, ptr %slot29, align 8
  store i64 %v5030, ptr %slot835, align 8
  %v5031 = load i64, ptr %slot835, align 8
  %v5032 = load i64, ptr %slot834, align 8
  %p5033 = inttoptr i64 %v5031 to ptr
  %p5034 = inttoptr i64 %v5032 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5034, ptr %p5033, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5035 = load i64, ptr %slot22, align 8
  %p5036 = inttoptr i64 %v5035 to ptr
  store i32 2, ptr %p5036, align 4, !alias.scope !3, !noalias !4
  %v5037 = load i64, ptr %slot24, align 8
  %p5038 = inttoptr i64 %v5037 to ptr
  %ld5039 = load i32, ptr %p5038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5039, ptr %slot836, align 8
  %v5040 = load i32, ptr %slot836, align 8
  %v5041 = load i64, ptr %slot22, align 8
  %p5042 = inttoptr i64 %v5041 to ptr
  store i32 %v5040, ptr %p5042, align 4, !alias.scope !3, !noalias !4
  %v5043 = load i64, ptr %slot23, align 8
  %p5044 = inttoptr i64 %v5043 to ptr
  store i32 0, ptr %p5044, align 4, !alias.scope !3, !noalias !4
  %v5045 = load i64, ptr %slot21, align 8
  %p5046 = inttoptr i64 %v5045 to ptr
  store i32 1, ptr %p5046, align 4, !alias.scope !3, !noalias !4
  %v5047 = load i64, ptr %slot834, align 8
  %p5048 = inttoptr i64 %v5047 to ptr
  %ld5049 = load i64, ptr %p5048, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5049, ptr %slot837, align 8
  %v5050 = load i64, ptr %slot837, align 8
  %v5051 = load i64, ptr %slot45, align 8
  %p5052 = inttoptr i64 %v5051 to ptr
  store i64 %v5050, ptr %p5052, align 8, !alias.scope !3, !noalias !4
  %v5053 = load i64, ptr %slot45, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  %ld5055 = load i64, ptr %p5054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5055, ptr %slot838, align 8
  %v5056 = load i64, ptr %slot838, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  %ld5058 = load i64, ptr %p5057, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5058, ptr %slot839, align 8
  %v5059 = load i64, ptr %slot839, align 8
  %v5060 = load i64, ptr %slot45, align 8
  %p5061 = inttoptr i64 %v5060 to ptr
  store i64 %v5059, ptr %p5061, align 8, !alias.scope !3, !noalias !4
  %v5062 = load i64, ptr %slot21, align 8
  %p5063 = inttoptr i64 %v5062 to ptr
  %ld5064 = load i32, ptr %p5063, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5064, ptr %slot840, align 8
  %v5065 = load i32, ptr %slot840, align 8
  %cv5066 = zext i32 %v5065 to i64
  %cond5067 = icmp ne i64 %cv5066, 0
  br i1 %cond5067, label %bb_rcslotdrop1035, label %bb_rcslotdone1035
bb_rcslotdrop1035:
  %v5068 = load i64, ptr %slot21, align 8
  %p5069 = inttoptr i64 %v5068 to ptr
  store i32 0, ptr %p5069, align 4, !alias.scope !3, !noalias !4
  %v5070 = load i64, ptr %slot26, align 8
  store i64 %v5070, ptr %slot841, align 8
  %v5071 = load i64, ptr %slot22, align 8
  %p5072 = inttoptr i64 %v5071 to ptr
  %ld5073 = load i32, ptr %p5072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5073, ptr %slot842, align 8
  %v5074 = load i32, ptr %slot842, align 8
  %op5075 = and i32 %v5074, 28
  store i32 %op5075, ptr %slot843, align 8
  %v5076 = load i32, ptr %slot843, align 8
  %cv5077 = zext i32 %v5076 to i64
  %cond5078 = icmp ne i64 %cv5077, 0
  br i1 %cond5078, label %bb_rcslotrole1035, label %bb_rcslotowner1035
bb_rcslotrole1035:
  %v5079 = load i64, ptr %slot52, align 8
  store i64 %v5079, ptr %slot844, align 8
  %v5080 = load i64, ptr %slot841, align 8
  %p5081 = inttoptr i64 %v5080 to ptr
  %ld5082 = load i64, ptr %p5081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5082, ptr %slot845, align 8
  %v5083 = load i64, ptr %slot845, align 8
  %cmp5084 = icmp ne i64 %v5083, 0
  %cv5085 = zext i1 %cmp5084 to i32
  store i32 %cv5085, ptr %slot846, align 8
  %v5086 = load i32, ptr %slot846, align 8
  %cv5087 = zext i32 %v5086 to i64
  %cond5088 = icmp ne i64 %cv5087, 0
  br i1 %cond5088, label %bb_rcgnn1051, label %bb_rcgdone1051
bb_rcgnn1051:
  %v5089 = load i64, ptr %slot845, align 8
  %op5090 = sub i64 %v5089, 16
  store i64 %op5090, ptr %slot847, align 8
  %v5091 = load i64, ptr %slot845, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  %rgep5093 = getelementptr i8, ptr %p5092, i64 -16
  %ld5094 = load i64, ptr %rgep5093, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5094, ptr %slot848, align 8
  %v5095 = load i64, ptr %slot848, align 8
  %op5096 = and i64 %v5095, 4611686018427387906
  store i64 %op5096, ptr %slot849, align 8
  %v5097 = load i64, ptr %slot849, align 8
  %cmp5098 = icmp ne i64 %v5097, 0
  %cv5099 = zext i1 %cmp5098 to i32
  store i32 %cv5099, ptr %slot850, align 8
  %v5100 = load i32, ptr %slot850, align 8
  %cv5101 = zext i32 %v5100 to i64
  %cond5102 = icmp ne i64 %cv5101, 0
  br i1 %cond5102, label %bb_rcgclear1051, label %bb_rcgcounted1051
bb_rcgcounted1051:
  %v5103 = load i64, ptr %slot845, align 8
  %op5104 = sub i64 %v5103, 24
  store i64 %op5104, ptr %slot851, align 8
  %v5105 = load i64, ptr %slot845, align 8
  %p5106 = inttoptr i64 %v5105 to ptr
  %rgep5107 = getelementptr i8, ptr %p5106, i64 -24
  %ld5108 = load i64, ptr %rgep5107, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5108, ptr %slot852, align 8
  %v5109 = load i64, ptr %slot852, align 8
  %op5110 = sub i64 %v5109, 1
  store i64 %op5110, ptr %slot853, align 8
  %v5111 = load i64, ptr %slot853, align 8
  %cmp5112 = icmp eq i64 %v5111, 0
  %cv5113 = zext i1 %cmp5112 to i32
  store i32 %cv5113, ptr %slot854, align 8
  %v5114 = load i32, ptr %slot854, align 8
  %cv5115 = zext i32 %v5114 to i64
  %cond5116 = icmp ne i64 %cv5115, 0
  br i1 %cond5116, label %bb_rcglast1051, label %bb_rcgdec1051
bb_rcglast1051:
  %v5117 = load i64, ptr %slot845, align 8
  %op5118 = sub i64 %v5117, 32
  store i64 %op5118, ptr %slot855, align 8
  %v5119 = load i64, ptr %slot845, align 8
  %p5120 = inttoptr i64 %v5119 to ptr
  %rgep5121 = getelementptr i8, ptr %p5120, i64 -32
  %ld5122 = load i64, ptr %rgep5121, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5122, ptr %slot856, align 8
  %v5123 = load i64, ptr %slot856, align 8
  %cmp5124 = icmp ne i64 %v5123, 0
  %cv5125 = zext i1 %cmp5124 to i32
  store i32 %cv5125, ptr %slot857, align 8
  %v5126 = load i32, ptr %slot857, align 8
  %cv5127 = zext i32 %v5126 to i64
  %cond5128 = icmp ne i64 %cv5127, 0
  br i1 %cond5128, label %bb_rcgdec1051, label %bb_rcgslow1051
bb_rcgslow1051:
  %v5129 = load i64, ptr %slot844, align 8
  %v5130 = load i64, ptr %slot841, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5129, i64 %v5130) nomerge, !dbg !158
  br label %bb_rcgdone1051
bb_rcgdec1051:
  %v5131 = load i64, ptr %slot853, align 8
  %v5132 = load i64, ptr %slot845, align 8
  %p5133 = inttoptr i64 %v5132 to ptr
  %rgep5134 = getelementptr i8, ptr %p5133, i64 -24
  store i64 %v5131, ptr %rgep5134, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1051
bb_rcgclear1051:
  %v5135 = load i64, ptr %slot841, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  store i64 0, ptr %p5136, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1051
bb_rcgdone1051:
  br label %bb_rcslotdone1035
bb_rcslotowner1035:
  %v5137 = load i64, ptr %slot52, align 8
  store i64 %v5137, ptr %slot858, align 8
  %v5138 = load i64, ptr %slot841, align 8
  %p5139 = inttoptr i64 %v5138 to ptr
  %ld5140 = load i64, ptr %p5139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5140, ptr %slot859, align 8
  %v5141 = load i64, ptr %slot859, align 8
  %cmp5142 = icmp ne i64 %v5141, 0
  %cv5143 = zext i1 %cmp5142 to i32
  store i32 %cv5143, ptr %slot860, align 8
  %v5144 = load i32, ptr %slot860, align 8
  %cv5145 = zext i32 %v5144 to i64
  %cond5146 = icmp ne i64 %cv5145, 0
  br i1 %cond5146, label %bb_rcgnn1066, label %bb_rcgdone1066
bb_rcgnn1066:
  %v5147 = load i64, ptr %slot859, align 8
  %op5148 = sub i64 %v5147, 16
  store i64 %op5148, ptr %slot861, align 8
  %v5149 = load i64, ptr %slot859, align 8
  %p5150 = inttoptr i64 %v5149 to ptr
  %rgep5151 = getelementptr i8, ptr %p5150, i64 -16
  %ld5152 = load i64, ptr %rgep5151, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5152, ptr %slot862, align 8
  %v5153 = load i64, ptr %slot862, align 8
  %op5154 = and i64 %v5153, 4611686018427387906
  store i64 %op5154, ptr %slot863, align 8
  %v5155 = load i64, ptr %slot863, align 8
  %cmp5156 = icmp ne i64 %v5155, 0
  %cv5157 = zext i1 %cmp5156 to i32
  store i32 %cv5157, ptr %slot864, align 8
  %v5158 = load i32, ptr %slot864, align 8
  %cv5159 = zext i32 %v5158 to i64
  %cond5160 = icmp ne i64 %cv5159, 0
  br i1 %cond5160, label %bb_rcgclear1066, label %bb_rcgcounted1066
bb_rcgcounted1066:
  %v5161 = load i64, ptr %slot859, align 8
  %op5162 = sub i64 %v5161, 32
  store i64 %op5162, ptr %slot865, align 8
  %v5163 = load i64, ptr %slot859, align 8
  %p5164 = inttoptr i64 %v5163 to ptr
  %rgep5165 = getelementptr i8, ptr %p5164, i64 -32
  %ld5166 = load i64, ptr %rgep5165, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5166, ptr %slot866, align 8
  %v5167 = load i64, ptr %slot866, align 8
  %op5168 = sub i64 %v5167, 1
  store i64 %op5168, ptr %slot867, align 8
  %v5169 = load i64, ptr %slot867, align 8
  %cmp5170 = icmp eq i64 %v5169, 0
  %cv5171 = zext i1 %cmp5170 to i32
  store i32 %cv5171, ptr %slot868, align 8
  %v5172 = load i32, ptr %slot868, align 8
  %cv5173 = zext i32 %v5172 to i64
  %cond5174 = icmp ne i64 %cv5173, 0
  br i1 %cond5174, label %bb_rcglast1066, label %bb_rcgdec1066
bb_rcglast1066:
  %v5175 = load i64, ptr %slot859, align 8
  %op5176 = sub i64 %v5175, 24
  store i64 %op5176, ptr %slot869, align 8
  %v5177 = load i64, ptr %slot859, align 8
  %p5178 = inttoptr i64 %v5177 to ptr
  %rgep5179 = getelementptr i8, ptr %p5178, i64 -24
  %ld5180 = load i64, ptr %rgep5179, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5180, ptr %slot870, align 8
  %v5181 = load i64, ptr %slot870, align 8
  %cmp5182 = icmp ne i64 %v5181, 0
  %cv5183 = zext i1 %cmp5182 to i32
  store i32 %cv5183, ptr %slot871, align 8
  %v5184 = load i32, ptr %slot871, align 8
  %cv5185 = zext i32 %v5184 to i64
  %cond5186 = icmp ne i64 %cv5185, 0
  br i1 %cond5186, label %bb_rcgdec1066, label %bb_rcgslow1066
bb_rcgslow1066:
  %v5187 = load i64, ptr %slot858, align 8
  %v5188 = load i64, ptr %slot841, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5187, i64 %v5188) nomerge, !dbg !158
  br label %bb_rcgdone1066
bb_rcgdec1066:
  %v5189 = load i64, ptr %slot867, align 8
  %v5190 = load i64, ptr %slot859, align 8
  %p5191 = inttoptr i64 %v5190 to ptr
  %rgep5192 = getelementptr i8, ptr %p5191, i64 -32
  store i64 %v5189, ptr %rgep5192, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1066
bb_rcgclear1066:
  %v5193 = load i64, ptr %slot841, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  store i64 0, ptr %p5194, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1066
bb_rcgdone1066:
  br label %bb_rcslotdone1035
bb_rcslotdone1035:
  %v5195 = load i64, ptr %slot45, align 8
  %p5196 = inttoptr i64 %v5195 to ptr
  %ld5197 = load i64, ptr %p5196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5197, ptr %slot872, align 8
  %v5198 = load i64, ptr %slot44, align 8
  %p5199 = inttoptr i64 %v5198 to ptr
  %ld5200 = load i64, ptr %p5199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5200, ptr %slot873, align 8
  %v5201 = load i64, ptr %slot873, align 8
  %v5202 = load i64, ptr %slot872, align 8
  %cmp5203 = icmp sge i64 %v5201, %v5202
  %cv5204 = zext i1 %cmp5203 to i64
  store i64 %cv5204, ptr %slot874, align 8
  %v5205 = load i64, ptr %slot874, align 8
  %v5206 = load i64, ptr %slot44, align 8
  %p5207 = inttoptr i64 %v5206 to ptr
  store i64 %v5205, ptr %p5207, align 8, !alias.scope !3, !noalias !4
  %v5208 = load i64, ptr %slot44, align 8
  %p5209 = inttoptr i64 %v5208 to ptr
  %ld5210 = load i64, ptr %p5209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5210, ptr %slot875, align 8
  %v5211 = load i64, ptr %slot875, align 8
  %cond5212 = icmp ne i64 %v5211, 0
  br i1 %cond5212, label %bb_next1074, label %bb_i86
bb_next1074:
  %v5213 = load i64, ptr %slot44, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  store i64 0, ptr %p5214, align 8, !alias.scope !3, !noalias !4
  br label %bb_i95
bb_i86:
  %v5215 = load i64, ptr %slot39, align 8
  %v5216 = load i64, ptr %slot44, align 8
  %p5217 = inttoptr i64 %v5216 to ptr
  store i64 %v5215, ptr %p5217, align 8, !alias.scope !3, !noalias !4
  %v5218 = load i64, ptr %slot44, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  %ld5220 = load i64, ptr %p5219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5220, ptr %slot876, align 8
  %v5221 = load i64, ptr %slot876, align 8
  %op5222 = add i64 %v5221, 0
  store i64 %op5222, ptr %slot877, align 8
  %v5223 = load i64, ptr %slot877, align 8
  %p5224 = inttoptr i64 %v5223 to ptr
  %ld5225 = load i64, ptr %p5224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5225, ptr %slot878, align 8
  %v5226 = load i64, ptr %slot878, align 8
  %v5227 = load i64, ptr %slot44, align 8
  %p5228 = inttoptr i64 %v5227 to ptr
  store i64 %v5226, ptr %p5228, align 8, !alias.scope !3, !noalias !4
  %v5229 = load i64, ptr %slot44, align 8
  %p5230 = inttoptr i64 %v5229 to ptr
  %ld5231 = load i64, ptr %p5230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5231, ptr %slot879, align 8
  %v5232 = load i64, ptr %slot879, align 8
  %v5233 = load i64, ptr %slot27, align 8
  %p5234 = inttoptr i64 %v5233 to ptr
  store i64 %v5232, ptr %p5234, align 8, !alias.scope !3, !noalias !4
  %v5235 = load i64, ptr %slot27, align 8
  store i64 %v5235, ptr %slot880, align 8
  %v5236 = load i64, ptr %slot29, align 8
  store i64 %v5236, ptr %slot881, align 8
  %v5237 = load i64, ptr %slot880, align 8
  %p5238 = inttoptr i64 %v5237 to ptr
  %ld5239 = load i64, ptr %p5238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5239, ptr %slot882, align 8
  %v5240 = load i64, ptr %slot882, align 8
  %cmp5241 = icmp ne i64 %v5240, 0
  %cv5242 = zext i1 %cmp5241 to i32
  store i32 %cv5242, ptr %slot883, align 8
  %v5243 = load i32, ptr %slot883, align 8
  %cv5244 = zext i32 %v5243 to i64
  %cond5245 = icmp ne i64 %cv5244, 0
  br i1 %cond5245, label %bb_rcgnn1081, label %bb_rcgstore1081
bb_rcgnn1081:
  %v5246 = load i64, ptr %slot882, align 8
  %op5247 = sub i64 %v5246, 16
  store i64 %op5247, ptr %slot884, align 8
  %v5248 = load i64, ptr %slot882, align 8
  %p5249 = inttoptr i64 %v5248 to ptr
  %rgep5250 = getelementptr i8, ptr %p5249, i64 -16
  %ld5251 = load i64, ptr %rgep5250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5251, ptr %slot885, align 8
  %v5252 = load i64, ptr %slot885, align 8
  %op5253 = and i64 %v5252, 4611686018427387906
  store i64 %op5253, ptr %slot886, align 8
  %v5254 = load i64, ptr %slot886, align 8
  %cmp5255 = icmp ne i64 %v5254, 0
  %cv5256 = zext i1 %cmp5255 to i32
  store i32 %cv5256, ptr %slot887, align 8
  %v5257 = load i32, ptr %slot887, align 8
  %cv5258 = zext i32 %v5257 to i64
  %cond5259 = icmp ne i64 %cv5258, 0
  br i1 %cond5259, label %bb_rcgstore1081, label %bb_rcginc1081
bb_rcginc1081:
  %v5260 = load i64, ptr %slot882, align 8
  %op5261 = sub i64 %v5260, 24
  store i64 %op5261, ptr %slot888, align 8
  %v5262 = load i64, ptr %slot882, align 8
  %p5263 = inttoptr i64 %v5262 to ptr
  %rgep5264 = getelementptr i8, ptr %p5263, i64 -24
  %ld5265 = load i64, ptr %rgep5264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5265, ptr %slot889, align 8
  %v5266 = load i64, ptr %slot889, align 8
  %op5267 = add i64 %v5266, 1
  store i64 %op5267, ptr %slot890, align 8
  %v5268 = load i64, ptr %slot890, align 8
  %cmp5269 = icmp eq i64 %v5268, 0
  %cv5270 = zext i1 %cmp5269 to i32
  store i32 %cv5270, ptr %slot891, align 8
  %v5271 = load i32, ptr %slot891, align 8
  %cv5272 = zext i32 %v5271 to i64
  %cond5273 = icmp ne i64 %cv5272, 0
  br i1 %cond5273, label %bb_rcglimit1081, label %bb_rcgcapacity1081
bb_rcglimit1081:
  %v5274 = load i64, ptr %slot1, align 8
  %p5275 = inttoptr i64 %v5274 to ptr
  %call5276 = call i32 @myl_qbe_rc_status(ptr %p5275, i32 2) nomerge, !dbg !160
  store i32 %call5276, ptr %slot892, align 8
  br label %bb_failure
bb_rcgcapacity1081:
  %v5277 = load i64, ptr %slot890, align 8
  %v5278 = load i64, ptr %slot882, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  %rgep5280 = getelementptr i8, ptr %p5279, i64 -24
  store i64 %v5277, ptr %rgep5280, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1081
bb_rcgstore1081:
  %v5281 = load i64, ptr %slot882, align 8
  %v5282 = load i64, ptr %slot881, align 8
  %p5283 = inttoptr i64 %v5282 to ptr
  store i64 %v5281, ptr %p5283, align 8, !alias.scope !3, !noalias !4
  %v5284 = load i64, ptr %slot24, align 8
  %p5285 = inttoptr i64 %v5284 to ptr
  store i32 2, ptr %p5285, align 4, !alias.scope !3, !noalias !4
  %v5286 = load i64, ptr %slot24, align 8
  %p5287 = inttoptr i64 %v5286 to ptr
  store i32 16, ptr %p5287, align 4, !alias.scope !3, !noalias !4
  %v5288 = load i64, ptr %slot23, align 8
  %p5289 = inttoptr i64 %v5288 to ptr
  store i32 1, ptr %p5289, align 4, !alias.scope !3, !noalias !4
  %v5290 = load i64, ptr %slot19, align 8
  %p5291 = inttoptr i64 %v5290 to ptr
  %ld5292 = load i32, ptr %p5291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5292, ptr %slot893, align 8
  %v5293 = load i32, ptr %slot893, align 8
  %cv5294 = zext i32 %v5293 to i64
  %cond5295 = icmp ne i64 %cv5294, 0
  br i1 %cond5295, label %bb_rcslotdrop1097, label %bb_rcslotdone1097
bb_rcslotdrop1097:
  %v5296 = load i64, ptr %slot19, align 8
  %p5297 = inttoptr i64 %v5296 to ptr
  store i32 0, ptr %p5297, align 4, !alias.scope !3, !noalias !4
  %v5298 = load i64, ptr %slot25, align 8
  store i64 %v5298, ptr %slot894, align 8
  %v5299 = load i64, ptr %slot20, align 8
  %p5300 = inttoptr i64 %v5299 to ptr
  %ld5301 = load i32, ptr %p5300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5301, ptr %slot895, align 8
  %v5302 = load i32, ptr %slot895, align 8
  %op5303 = and i32 %v5302, 28
  store i32 %op5303, ptr %slot896, align 8
  %v5304 = load i32, ptr %slot896, align 8
  %cv5305 = zext i32 %v5304 to i64
  %cond5306 = icmp ne i64 %cv5305, 0
  br i1 %cond5306, label %bb_rcslotrole1097, label %bb_rcslotowner1097
bb_rcslotrole1097:
  %v5307 = load i64, ptr %slot52, align 8
  store i64 %v5307, ptr %slot897, align 8
  %v5308 = load i64, ptr %slot897, align 8
  %v5309 = load i64, ptr %slot894, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5308, i64 %v5309) nomerge, !dbg !160
  br label %bb_rcslotdone1097
bb_rcslotowner1097:
  %v5310 = load i64, ptr %slot52, align 8
  store i64 %v5310, ptr %slot898, align 8
  %v5311 = load i64, ptr %slot898, align 8
  %v5312 = load i64, ptr %slot894, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5311, i64 %v5312) nomerge, !dbg !160
  br label %bb_rcslotdone1097
bb_rcslotdone1097:
  %v5313 = load i64, ptr %slot25, align 8
  store i64 %v5313, ptr %slot899, align 8
  %v5314 = load i64, ptr %slot29, align 8
  store i64 %v5314, ptr %slot900, align 8
  %v5315 = load i64, ptr %slot900, align 8
  %v5316 = load i64, ptr %slot899, align 8
  %p5317 = inttoptr i64 %v5315 to ptr
  %p5318 = inttoptr i64 %v5316 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5318, ptr %p5317, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5319 = load i64, ptr %slot20, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  store i32 2, ptr %p5320, align 4, !alias.scope !3, !noalias !4
  %v5321 = load i64, ptr %slot24, align 8
  %p5322 = inttoptr i64 %v5321 to ptr
  %ld5323 = load i32, ptr %p5322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5323, ptr %slot901, align 8
  %v5324 = load i32, ptr %slot901, align 8
  %v5325 = load i64, ptr %slot20, align 8
  %p5326 = inttoptr i64 %v5325 to ptr
  store i32 %v5324, ptr %p5326, align 4, !alias.scope !3, !noalias !4
  %v5327 = load i64, ptr %slot23, align 8
  %p5328 = inttoptr i64 %v5327 to ptr
  store i32 0, ptr %p5328, align 4, !alias.scope !3, !noalias !4
  %v5329 = load i64, ptr %slot19, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  store i32 1, ptr %p5330, align 4, !alias.scope !3, !noalias !4
  %v5331 = load i64, ptr %slot899, align 8
  %p5332 = inttoptr i64 %v5331 to ptr
  %ld5333 = load i64, ptr %p5332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5333, ptr %slot902, align 8
  %v5334 = load i64, ptr %slot902, align 8
  %v5335 = load i64, ptr %slot44, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  store i64 %v5334, ptr %p5336, align 8, !alias.scope !3, !noalias !4
  %v5337 = load i64, ptr %slot39, align 8
  %v5338 = load i64, ptr %slot45, align 8
  %p5339 = inttoptr i64 %v5338 to ptr
  store i64 %v5337, ptr %p5339, align 8, !alias.scope !3, !noalias !4
  %v5340 = load i64, ptr %slot45, align 8
  %p5341 = inttoptr i64 %v5340 to ptr
  %ld5342 = load i64, ptr %p5341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5342, ptr %slot903, align 8
  %v5343 = load i64, ptr %slot903, align 8
  %op5344 = add i64 %v5343, 16
  store i64 %op5344, ptr %slot904, align 8
  %v5345 = load i64, ptr %slot904, align 8
  %p5346 = inttoptr i64 %v5345 to ptr
  %ld5347 = load i64, ptr %p5346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5347, ptr %slot905, align 8
  %v5348 = load i64, ptr %slot905, align 8
  %v5349 = load i64, ptr %slot45, align 8
  %p5350 = inttoptr i64 %v5349 to ptr
  store i64 %v5348, ptr %p5350, align 8, !alias.scope !3, !noalias !4
  %v5351 = load i64, ptr %slot21, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  %ld5353 = load i32, ptr %p5352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5353, ptr %slot906, align 8
  %v5354 = load i32, ptr %slot906, align 8
  %cv5355 = zext i32 %v5354 to i64
  %cond5356 = icmp ne i64 %cv5355, 0
  br i1 %cond5356, label %bb_rcslotdrop1118, label %bb_rcslotdone1118
bb_rcslotdrop1118:
  %v5357 = load i64, ptr %slot21, align 8
  %p5358 = inttoptr i64 %v5357 to ptr
  store i32 0, ptr %p5358, align 4, !alias.scope !3, !noalias !4
  %v5359 = load i64, ptr %slot26, align 8
  store i64 %v5359, ptr %slot907, align 8
  %v5360 = load i64, ptr %slot22, align 8
  %p5361 = inttoptr i64 %v5360 to ptr
  %ld5362 = load i32, ptr %p5361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5362, ptr %slot908, align 8
  %v5363 = load i32, ptr %slot908, align 8
  %op5364 = and i32 %v5363, 28
  store i32 %op5364, ptr %slot909, align 8
  %v5365 = load i32, ptr %slot909, align 8
  %cv5366 = zext i32 %v5365 to i64
  %cond5367 = icmp ne i64 %cv5366, 0
  br i1 %cond5367, label %bb_rcslotrole1118, label %bb_rcslotowner1118
bb_rcslotrole1118:
  %v5368 = load i64, ptr %slot52, align 8
  store i64 %v5368, ptr %slot910, align 8
  %v5369 = load i64, ptr %slot910, align 8
  %v5370 = load i64, ptr %slot907, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5369, i64 %v5370) nomerge, !dbg !162
  br label %bb_rcslotdone1118
bb_rcslotowner1118:
  %v5371 = load i64, ptr %slot52, align 8
  store i64 %v5371, ptr %slot911, align 8
  %v5372 = load i64, ptr %slot911, align 8
  %v5373 = load i64, ptr %slot907, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5372, i64 %v5373) nomerge, !dbg !162
  br label %bb_rcslotdone1118
bb_rcslotdone1118:
  %v5374 = load i64, ptr %slot46, align 8
  %p5375 = inttoptr i64 %v5374 to ptr
  store i64 1, ptr %p5375, align 8, !alias.scope !3, !noalias !4
  %v5376 = load i64, ptr %slot46, align 8
  %p5377 = inttoptr i64 %v5376 to ptr
  %ld5378 = load i64, ptr %p5377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5378, ptr %slot912, align 8
  %v5379 = load i64, ptr %slot45, align 8
  %p5380 = inttoptr i64 %v5379 to ptr
  %ld5381 = load i64, ptr %p5380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5381, ptr %slot913, align 8
  %v5382 = load i64, ptr %slot913, align 8
  %v5383 = load i64, ptr %slot912, align 8
  %ovpair5385 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5382, i64 %v5383)
  %op5384 = extractvalue { i64, i1 } %ovpair5385, 0
  %ov5386 = extractvalue { i64, i1 } %ovpair5385, 1
  store i64 %op5384, ptr %slot914, align 8
  %cv5387 = zext i1 %ov5386 to i64
  store i64 %cv5387, ptr %slot915, align 8
  %v5388 = load i64, ptr %slot915, align 8
  %cond5389 = icmp ne i64 %v5388, 0
  br i1 %cond5389, label %bb_overflow1127, label %bb_checked1127
bb_overflow1127:
  %v5390 = load i64, ptr %slot1, align 8
  %p5391 = inttoptr i64 %v5390 to ptr
  %v5392 = load i64, ptr %slot913, align 8
  %v5393 = load i64, ptr %slot912, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5391, i64 0, i64 %v5392, i64 %v5393, i64 64) nomerge, !dbg !164
  unreachable
bb_checked1127:
  %v5394 = load i64, ptr %slot914, align 8
  %v5395 = load i64, ptr %slot45, align 8
  %p5396 = inttoptr i64 %v5395 to ptr
  store i64 %v5394, ptr %p5396, align 8, !alias.scope !3, !noalias !4
  %v5397 = load i64, ptr %slot44, align 8
  %p5398 = inttoptr i64 %v5397 to ptr
  %ld5399 = load i64, ptr %p5398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5399, ptr %slot916, align 8
  %v5400 = load i64, ptr %slot45, align 8
  %p5401 = inttoptr i64 %v5400 to ptr
  %ld5402 = load i64, ptr %p5401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5402, ptr %slot917, align 8
  %v5403 = load i64, ptr %slot916, align 8
  %p5404 = inttoptr i64 %v5403 to ptr
  %ld5405 = load i64, ptr %p5404, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5405, ptr %slot918, align 8
  %v5406 = load i64, ptr %slot917, align 8
  %op5407 = ashr i64 %v5406, 63
  store i64 %op5407, ptr %slot919, align 8
  %v5408 = load i64, ptr %slot919, align 8
  %v5409 = load i64, ptr %slot918, align 8
  %op5410 = and i64 %v5408, %v5409
  store i64 %op5410, ptr %slot920, align 8
  %v5411 = load i64, ptr %slot917, align 8
  %v5412 = load i64, ptr %slot920, align 8
  %op5413 = add i64 %v5411, %v5412
  store i64 %op5413, ptr %slot921, align 8
  %v5414 = load i64, ptr %slot921, align 8
  %v5415 = load i64, ptr %slot918, align 8
  %cmp5416 = icmp ult i64 %v5414, %v5415
  %cv5417 = zext i1 %cmp5416 to i64
  store i64 %cv5417, ptr %slot922, align 8
  %v5418 = load i64, ptr %slot922, align 8
  %cond5419 = icmp ne i64 %v5418, 0
  br i1 %cond5419, label %bb_success1137, label %bb_failed1137
bb_failed1137:
  %v5420 = load i64, ptr %slot1, align 8
  %p5421 = inttoptr i64 %v5420 to ptr
  %v5422 = load i64, ptr %slot917, align 8
  %v5423 = load i64, ptr %slot918, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p5421, i64 %v5422, i64 %v5423) nomerge, !dbg !166
  unreachable
bb_success1137:
  %v5424 = load i64, ptr %slot916, align 8
  %op5425 = add i64 %v5424, 32
  store i64 %op5425, ptr %slot923, align 8
  %v5426 = load i64, ptr %slot923, align 8
  %p5427 = inttoptr i64 %v5426 to ptr
  %ld5428 = load i64, ptr %p5427, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5428, ptr %slot924, align 8
  %v5429 = load i64, ptr %slot924, align 8
  %v5430 = load i64, ptr %slot921, align 8
  %op5431 = add i64 %v5429, %v5430
  store i64 %op5431, ptr %slot925, align 8
  %v5432 = load i64, ptr %slot924, align 8
  %p5433 = inttoptr i64 %v5432 to ptr
  %v5434 = load i64, ptr %slot921, align 8
  %egep5435 = getelementptr i8, ptr %p5433, i64 %v5434
  %ld5436 = load i8, ptr %egep5435, align 1, !alias.scope !12, !noalias !13
  %ext5437 = zext i8 %ld5436 to i64
  store i64 %ext5437, ptr %slot926, align 8
  %v5438 = load i64, ptr %slot926, align 8
  %v5439 = load i64, ptr %slot44, align 8
  %p5440 = inttoptr i64 %v5439 to ptr
  store i64 %v5438, ptr %p5440, align 8, !alias.scope !3, !noalias !4
  %v5441 = load i64, ptr %slot19, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  %ld5443 = load i32, ptr %p5442, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5443, ptr %slot927, align 8
  %v5444 = load i32, ptr %slot927, align 8
  %cv5445 = zext i32 %v5444 to i64
  %cond5446 = icmp ne i64 %cv5445, 0
  br i1 %cond5446, label %bb_rcslotdrop1145, label %bb_rcslotdone1145
bb_rcslotdrop1145:
  %v5447 = load i64, ptr %slot19, align 8
  %p5448 = inttoptr i64 %v5447 to ptr
  store i32 0, ptr %p5448, align 4, !alias.scope !3, !noalias !4
  %v5449 = load i64, ptr %slot25, align 8
  store i64 %v5449, ptr %slot928, align 8
  %v5450 = load i64, ptr %slot20, align 8
  %p5451 = inttoptr i64 %v5450 to ptr
  %ld5452 = load i32, ptr %p5451, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5452, ptr %slot929, align 8
  %v5453 = load i32, ptr %slot929, align 8
  %op5454 = and i32 %v5453, 28
  store i32 %op5454, ptr %slot930, align 8
  %v5455 = load i32, ptr %slot930, align 8
  %cv5456 = zext i32 %v5455 to i64
  %cond5457 = icmp ne i64 %cv5456, 0
  br i1 %cond5457, label %bb_rcslotrole1145, label %bb_rcslotowner1145
bb_rcslotrole1145:
  %v5458 = load i64, ptr %slot52, align 8
  store i64 %v5458, ptr %slot931, align 8
  %v5459 = load i64, ptr %slot928, align 8
  %p5460 = inttoptr i64 %v5459 to ptr
  %ld5461 = load i64, ptr %p5460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5461, ptr %slot932, align 8
  %v5462 = load i64, ptr %slot932, align 8
  %cmp5463 = icmp ne i64 %v5462, 0
  %cv5464 = zext i1 %cmp5463 to i32
  store i32 %cv5464, ptr %slot933, align 8
  %v5465 = load i32, ptr %slot933, align 8
  %cv5466 = zext i32 %v5465 to i64
  %cond5467 = icmp ne i64 %cv5466, 0
  br i1 %cond5467, label %bb_rcgnn1161, label %bb_rcgdone1161
bb_rcgnn1161:
  %v5468 = load i64, ptr %slot932, align 8
  %op5469 = sub i64 %v5468, 16
  store i64 %op5469, ptr %slot934, align 8
  %v5470 = load i64, ptr %slot932, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  %rgep5472 = getelementptr i8, ptr %p5471, i64 -16
  %ld5473 = load i64, ptr %rgep5472, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5473, ptr %slot935, align 8
  %v5474 = load i64, ptr %slot935, align 8
  %op5475 = and i64 %v5474, 4611686018427387906
  store i64 %op5475, ptr %slot936, align 8
  %v5476 = load i64, ptr %slot936, align 8
  %cmp5477 = icmp ne i64 %v5476, 0
  %cv5478 = zext i1 %cmp5477 to i32
  store i32 %cv5478, ptr %slot937, align 8
  %v5479 = load i32, ptr %slot937, align 8
  %cv5480 = zext i32 %v5479 to i64
  %cond5481 = icmp ne i64 %cv5480, 0
  br i1 %cond5481, label %bb_rcgclear1161, label %bb_rcgcounted1161
bb_rcgcounted1161:
  %v5482 = load i64, ptr %slot932, align 8
  %op5483 = sub i64 %v5482, 24
  store i64 %op5483, ptr %slot938, align 8
  %v5484 = load i64, ptr %slot932, align 8
  %p5485 = inttoptr i64 %v5484 to ptr
  %rgep5486 = getelementptr i8, ptr %p5485, i64 -24
  %ld5487 = load i64, ptr %rgep5486, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5487, ptr %slot939, align 8
  %v5488 = load i64, ptr %slot939, align 8
  %op5489 = sub i64 %v5488, 1
  store i64 %op5489, ptr %slot940, align 8
  %v5490 = load i64, ptr %slot940, align 8
  %cmp5491 = icmp eq i64 %v5490, 0
  %cv5492 = zext i1 %cmp5491 to i32
  store i32 %cv5492, ptr %slot941, align 8
  %v5493 = load i32, ptr %slot941, align 8
  %cv5494 = zext i32 %v5493 to i64
  %cond5495 = icmp ne i64 %cv5494, 0
  br i1 %cond5495, label %bb_rcglast1161, label %bb_rcgdec1161
bb_rcglast1161:
  %v5496 = load i64, ptr %slot932, align 8
  %op5497 = sub i64 %v5496, 32
  store i64 %op5497, ptr %slot942, align 8
  %v5498 = load i64, ptr %slot932, align 8
  %p5499 = inttoptr i64 %v5498 to ptr
  %rgep5500 = getelementptr i8, ptr %p5499, i64 -32
  %ld5501 = load i64, ptr %rgep5500, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5501, ptr %slot943, align 8
  %v5502 = load i64, ptr %slot943, align 8
  %cmp5503 = icmp ne i64 %v5502, 0
  %cv5504 = zext i1 %cmp5503 to i32
  store i32 %cv5504, ptr %slot944, align 8
  %v5505 = load i32, ptr %slot944, align 8
  %cv5506 = zext i32 %v5505 to i64
  %cond5507 = icmp ne i64 %cv5506, 0
  br i1 %cond5507, label %bb_rcgdec1161, label %bb_rcgslow1161
bb_rcgslow1161:
  %v5508 = load i64, ptr %slot931, align 8
  %v5509 = load i64, ptr %slot928, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5508, i64 %v5509) nomerge, !dbg !166
  br label %bb_rcgdone1161
bb_rcgdec1161:
  %v5510 = load i64, ptr %slot940, align 8
  %v5511 = load i64, ptr %slot932, align 8
  %p5512 = inttoptr i64 %v5511 to ptr
  %rgep5513 = getelementptr i8, ptr %p5512, i64 -24
  store i64 %v5510, ptr %rgep5513, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1161
bb_rcgclear1161:
  %v5514 = load i64, ptr %slot928, align 8
  %p5515 = inttoptr i64 %v5514 to ptr
  store i64 0, ptr %p5515, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1161
bb_rcgdone1161:
  br label %bb_rcslotdone1145
bb_rcslotowner1145:
  %v5516 = load i64, ptr %slot52, align 8
  store i64 %v5516, ptr %slot945, align 8
  %v5517 = load i64, ptr %slot928, align 8
  %p5518 = inttoptr i64 %v5517 to ptr
  %ld5519 = load i64, ptr %p5518, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5519, ptr %slot946, align 8
  %v5520 = load i64, ptr %slot946, align 8
  %cmp5521 = icmp ne i64 %v5520, 0
  %cv5522 = zext i1 %cmp5521 to i32
  store i32 %cv5522, ptr %slot947, align 8
  %v5523 = load i32, ptr %slot947, align 8
  %cv5524 = zext i32 %v5523 to i64
  %cond5525 = icmp ne i64 %cv5524, 0
  br i1 %cond5525, label %bb_rcgnn1176, label %bb_rcgdone1176
bb_rcgnn1176:
  %v5526 = load i64, ptr %slot946, align 8
  %op5527 = sub i64 %v5526, 16
  store i64 %op5527, ptr %slot948, align 8
  %v5528 = load i64, ptr %slot946, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  %rgep5530 = getelementptr i8, ptr %p5529, i64 -16
  %ld5531 = load i64, ptr %rgep5530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5531, ptr %slot949, align 8
  %v5532 = load i64, ptr %slot949, align 8
  %op5533 = and i64 %v5532, 4611686018427387906
  store i64 %op5533, ptr %slot950, align 8
  %v5534 = load i64, ptr %slot950, align 8
  %cmp5535 = icmp ne i64 %v5534, 0
  %cv5536 = zext i1 %cmp5535 to i32
  store i32 %cv5536, ptr %slot951, align 8
  %v5537 = load i32, ptr %slot951, align 8
  %cv5538 = zext i32 %v5537 to i64
  %cond5539 = icmp ne i64 %cv5538, 0
  br i1 %cond5539, label %bb_rcgclear1176, label %bb_rcgcounted1176
bb_rcgcounted1176:
  %v5540 = load i64, ptr %slot946, align 8
  %op5541 = sub i64 %v5540, 32
  store i64 %op5541, ptr %slot952, align 8
  %v5542 = load i64, ptr %slot946, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  %rgep5544 = getelementptr i8, ptr %p5543, i64 -32
  %ld5545 = load i64, ptr %rgep5544, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5545, ptr %slot953, align 8
  %v5546 = load i64, ptr %slot953, align 8
  %op5547 = sub i64 %v5546, 1
  store i64 %op5547, ptr %slot954, align 8
  %v5548 = load i64, ptr %slot954, align 8
  %cmp5549 = icmp eq i64 %v5548, 0
  %cv5550 = zext i1 %cmp5549 to i32
  store i32 %cv5550, ptr %slot955, align 8
  %v5551 = load i32, ptr %slot955, align 8
  %cv5552 = zext i32 %v5551 to i64
  %cond5553 = icmp ne i64 %cv5552, 0
  br i1 %cond5553, label %bb_rcglast1176, label %bb_rcgdec1176
bb_rcglast1176:
  %v5554 = load i64, ptr %slot946, align 8
  %op5555 = sub i64 %v5554, 24
  store i64 %op5555, ptr %slot956, align 8
  %v5556 = load i64, ptr %slot946, align 8
  %p5557 = inttoptr i64 %v5556 to ptr
  %rgep5558 = getelementptr i8, ptr %p5557, i64 -24
  %ld5559 = load i64, ptr %rgep5558, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5559, ptr %slot957, align 8
  %v5560 = load i64, ptr %slot957, align 8
  %cmp5561 = icmp ne i64 %v5560, 0
  %cv5562 = zext i1 %cmp5561 to i32
  store i32 %cv5562, ptr %slot958, align 8
  %v5563 = load i32, ptr %slot958, align 8
  %cv5564 = zext i32 %v5563 to i64
  %cond5565 = icmp ne i64 %cv5564, 0
  br i1 %cond5565, label %bb_rcgdec1176, label %bb_rcgslow1176
bb_rcgslow1176:
  %v5566 = load i64, ptr %slot945, align 8
  %v5567 = load i64, ptr %slot928, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5566, i64 %v5567) nomerge, !dbg !166
  br label %bb_rcgdone1176
bb_rcgdec1176:
  %v5568 = load i64, ptr %slot954, align 8
  %v5569 = load i64, ptr %slot946, align 8
  %p5570 = inttoptr i64 %v5569 to ptr
  %rgep5571 = getelementptr i8, ptr %p5570, i64 -32
  store i64 %v5568, ptr %rgep5571, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1176
bb_rcgclear1176:
  %v5572 = load i64, ptr %slot928, align 8
  %p5573 = inttoptr i64 %v5572 to ptr
  store i64 0, ptr %p5573, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1176
bb_rcgdone1176:
  br label %bb_rcslotdone1145
bb_rcslotdone1145:
  %v5574 = load i64, ptr %slot44, align 8
  %p5575 = inttoptr i64 %v5574 to ptr
  %ld5576 = load i64, ptr %p5575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5576, ptr %slot959, align 8
  %v5577 = load i64, ptr %slot959, align 8
  %v5578 = load i64, ptr %slot44, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  store i64 %v5577, ptr %p5579, align 8, !alias.scope !3, !noalias !4
  br label %bb_i95
bb_i95:
  %v5580 = load i64, ptr %slot44, align 8
  %p5581 = inttoptr i64 %v5580 to ptr
  %ld5582 = load i64, ptr %p5581, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5582, ptr %slot960, align 8
  %v5583 = load i64, ptr %slot960, align 8
  %v5584 = load i64, ptr %slot40, align 8
  %p5585 = inttoptr i64 %v5584 to ptr
  store i64 %v5583, ptr %p5585, align 8, !alias.scope !3, !noalias !4
  %v5586 = load i64, ptr %slot40, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %ld5588 = load i64, ptr %p5587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5588, ptr %slot961, align 8
  %v5589 = load i64, ptr %slot961, align 8
  %v5590 = load i64, ptr %slot44, align 8
  %p5591 = inttoptr i64 %v5590 to ptr
  store i64 %v5589, ptr %p5591, align 8, !alias.scope !3, !noalias !4
  %v5592 = load i64, ptr %slot45, align 8
  %p5593 = inttoptr i64 %v5592 to ptr
  store i64 48, ptr %p5593, align 8, !alias.scope !3, !noalias !4
  %v5594 = load i64, ptr %slot45, align 8
  %p5595 = inttoptr i64 %v5594 to ptr
  %ld5596 = load i64, ptr %p5595, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5596, ptr %slot962, align 8
  %v5597 = load i64, ptr %slot44, align 8
  %p5598 = inttoptr i64 %v5597 to ptr
  %ld5599 = load i64, ptr %p5598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5599, ptr %slot963, align 8
  %v5600 = load i64, ptr %slot963, align 8
  %v5601 = load i64, ptr %slot962, align 8
  %cmp5602 = icmp sge i64 %v5600, %v5601
  %cv5603 = zext i1 %cmp5602 to i64
  store i64 %cv5603, ptr %slot964, align 8
  %v5604 = load i64, ptr %slot964, align 8
  %v5605 = load i64, ptr %slot44, align 8
  %p5606 = inttoptr i64 %v5605 to ptr
  store i64 %v5604, ptr %p5606, align 8, !alias.scope !3, !noalias !4
  %v5607 = load i64, ptr %slot44, align 8
  %p5608 = inttoptr i64 %v5607 to ptr
  %ld5609 = load i64, ptr %p5608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5609, ptr %slot965, align 8
  %v5610 = load i64, ptr %slot965, align 8
  %cond5611 = icmp ne i64 %v5610, 0
  br i1 %cond5611, label %bb_next1187, label %bb_i104
bb_next1187:
  %v5612 = load i64, ptr %slot40, align 8
  %p5613 = inttoptr i64 %v5612 to ptr
  %ld5614 = load i64, ptr %p5613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5614, ptr %slot966, align 8
  %v5615 = load i64, ptr %slot966, align 8
  %v5616 = load i64, ptr %slot44, align 8
  %p5617 = inttoptr i64 %v5616 to ptr
  store i64 %v5615, ptr %p5617, align 8, !alias.scope !3, !noalias !4
  %v5618 = load i64, ptr %slot45, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  store i64 57, ptr %p5619, align 8, !alias.scope !3, !noalias !4
  %v5620 = load i64, ptr %slot45, align 8
  %p5621 = inttoptr i64 %v5620 to ptr
  %ld5622 = load i64, ptr %p5621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5622, ptr %slot967, align 8
  %v5623 = load i64, ptr %slot44, align 8
  %p5624 = inttoptr i64 %v5623 to ptr
  %ld5625 = load i64, ptr %p5624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5625, ptr %slot968, align 8
  %v5626 = load i64, ptr %slot968, align 8
  %v5627 = load i64, ptr %slot967, align 8
  %cmp5628 = icmp sle i64 %v5626, %v5627
  %cv5629 = zext i1 %cmp5628 to i64
  store i64 %cv5629, ptr %slot969, align 8
  %v5630 = load i64, ptr %slot969, align 8
  %v5631 = load i64, ptr %slot44, align 8
  %p5632 = inttoptr i64 %v5631 to ptr
  store i64 %v5630, ptr %p5632, align 8, !alias.scope !3, !noalias !4
  br label %bb_i105
bb_i104:
  %v5633 = load i64, ptr %slot44, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  store i64 0, ptr %p5634, align 8, !alias.scope !3, !noalias !4
  br label %bb_i105
bb_i105:
  br label %bb_i106
bb_i106:
  br label %bb_i108
bb_i107:
  %v5635 = load i64, ptr %slot44, align 8
  %p5636 = inttoptr i64 %v5635 to ptr
  store i64 0, ptr %p5636, align 8, !alias.scope !3, !noalias !4
  br label %bb_i108
bb_i108:
  %v5637 = load i64, ptr %slot44, align 8
  %p5638 = inttoptr i64 %v5637 to ptr
  %ld5639 = load i64, ptr %p5638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5639, ptr %slot970, align 8
  %v5640 = load i64, ptr %slot970, align 8
  %cond5641 = icmp ne i64 %v5640, 0
  br i1 %cond5641, label %bb_next1192, label %bb_i173
bb_next1192:
  %v5642 = load i64, ptr %slot30, align 8
  %p5643 = inttoptr i64 %v5642 to ptr
  %ld5644 = load i64, ptr %p5643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5644, ptr %slot971, align 8
  %v5645 = load i64, ptr %slot971, align 8
  %v5646 = load i64, ptr %slot44, align 8
  %p5647 = inttoptr i64 %v5646 to ptr
  store i64 %v5645, ptr %p5647, align 8, !alias.scope !3, !noalias !4
  %v5648 = load i64, ptr %slot44, align 8
  %p5649 = inttoptr i64 %v5648 to ptr
  %ld5650 = load i64, ptr %p5649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5650, ptr %slot972, align 8
  %v5651 = load i64, ptr %slot972, align 8
  %op5652 = add i64 %v5651, 16
  store i64 %op5652, ptr %slot973, align 8
  %v5653 = load i64, ptr %slot973, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  %ld5655 = load i64, ptr %p5654, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5655, ptr %slot974, align 8
  %v5656 = load i64, ptr %slot974, align 8
  %v5657 = load i64, ptr %slot44, align 8
  %p5658 = inttoptr i64 %v5657 to ptr
  store i64 %v5656, ptr %p5658, align 8, !alias.scope !3, !noalias !4
  %v5659 = load i64, ptr %slot19, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  %ld5661 = load i32, ptr %p5660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5661, ptr %slot975, align 8
  %v5662 = load i32, ptr %slot975, align 8
  %cv5663 = zext i32 %v5662 to i64
  %cond5664 = icmp ne i64 %cv5663, 0
  br i1 %cond5664, label %bb_rcslotdrop1198, label %bb_rcslotdone1198
bb_rcslotdrop1198:
  %v5665 = load i64, ptr %slot19, align 8
  %p5666 = inttoptr i64 %v5665 to ptr
  store i32 0, ptr %p5666, align 4, !alias.scope !3, !noalias !4
  %v5667 = load i64, ptr %slot25, align 8
  store i64 %v5667, ptr %slot976, align 8
  %v5668 = load i64, ptr %slot20, align 8
  %p5669 = inttoptr i64 %v5668 to ptr
  %ld5670 = load i32, ptr %p5669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5670, ptr %slot977, align 8
  %v5671 = load i32, ptr %slot977, align 8
  %op5672 = and i32 %v5671, 28
  store i32 %op5672, ptr %slot978, align 8
  %v5673 = load i32, ptr %slot978, align 8
  %cv5674 = zext i32 %v5673 to i64
  %cond5675 = icmp ne i64 %cv5674, 0
  br i1 %cond5675, label %bb_rcslotrole1198, label %bb_rcslotowner1198
bb_rcslotrole1198:
  %v5676 = load i64, ptr %slot52, align 8
  store i64 %v5676, ptr %slot979, align 8
  %v5677 = load i64, ptr %slot979, align 8
  %v5678 = load i64, ptr %slot976, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5677, i64 %v5678) nomerge, !dbg !168
  br label %bb_rcslotdone1198
bb_rcslotowner1198:
  %v5679 = load i64, ptr %slot52, align 8
  store i64 %v5679, ptr %slot980, align 8
  %v5680 = load i64, ptr %slot980, align 8
  %v5681 = load i64, ptr %slot976, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5680, i64 %v5681) nomerge, !dbg !168
  br label %bb_rcslotdone1198
bb_rcslotdone1198:
  %v5682 = load i64, ptr %slot45, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  store i64 1, ptr %p5683, align 8, !alias.scope !3, !noalias !4
  %v5684 = load i64, ptr %slot45, align 8
  %p5685 = inttoptr i64 %v5684 to ptr
  %ld5686 = load i64, ptr %p5685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5686, ptr %slot981, align 8
  %v5687 = load i64, ptr %slot44, align 8
  %p5688 = inttoptr i64 %v5687 to ptr
  %ld5689 = load i64, ptr %p5688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5689, ptr %slot982, align 8
  %v5690 = load i64, ptr %slot982, align 8
  %v5691 = load i64, ptr %slot981, align 8
  %ovpair5693 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5690, i64 %v5691)
  %op5692 = extractvalue { i64, i1 } %ovpair5693, 0
  %ov5694 = extractvalue { i64, i1 } %ovpair5693, 1
  store i64 %op5692, ptr %slot983, align 8
  %cv5695 = zext i1 %ov5694 to i64
  store i64 %cv5695, ptr %slot984, align 8
  %v5696 = load i64, ptr %slot984, align 8
  %cond5697 = icmp ne i64 %v5696, 0
  br i1 %cond5697, label %bb_overflow1207, label %bb_checked1207
bb_overflow1207:
  %v5698 = load i64, ptr %slot1, align 8
  %p5699 = inttoptr i64 %v5698 to ptr
  %v5700 = load i64, ptr %slot982, align 8
  %v5701 = load i64, ptr %slot981, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5699, i64 0, i64 %v5700, i64 %v5701, i64 64) nomerge, !dbg !170
  unreachable
bb_checked1207:
  %v5702 = load i64, ptr %slot983, align 8
  %v5703 = load i64, ptr %slot44, align 8
  %p5704 = inttoptr i64 %v5703 to ptr
  store i64 %v5702, ptr %p5704, align 8, !alias.scope !3, !noalias !4
  %v5705 = load i64, ptr %slot44, align 8
  %p5706 = inttoptr i64 %v5705 to ptr
  %ld5707 = load i64, ptr %p5706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5707, ptr %slot985, align 8
  %v5708 = load i64, ptr %slot985, align 8
  %v5709 = load i64, ptr %slot32, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  store i64 %v5708, ptr %p5710, align 8, !alias.scope !3, !noalias !4
  %v5711 = load i64, ptr %slot30, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  %ld5713 = load i64, ptr %p5712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5713, ptr %slot986, align 8
  %v5714 = load i64, ptr %slot986, align 8
  %v5715 = load i64, ptr %slot44, align 8
  %p5716 = inttoptr i64 %v5715 to ptr
  store i64 %v5714, ptr %p5716, align 8, !alias.scope !3, !noalias !4
  %v5717 = load i64, ptr %slot30, align 8
  %p5718 = inttoptr i64 %v5717 to ptr
  %ld5719 = load i64, ptr %p5718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5719, ptr %slot987, align 8
  %v5720 = load i64, ptr %slot987, align 8
  %v5721 = load i64, ptr %slot44, align 8
  %p5722 = inttoptr i64 %v5721 to ptr
  store i64 %v5720, ptr %p5722, align 8, !alias.scope !3, !noalias !4
  %v5723 = load i64, ptr %slot30, align 8
  %p5724 = inttoptr i64 %v5723 to ptr
  %ld5725 = load i64, ptr %p5724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5725, ptr %slot988, align 8
  %v5726 = load i64, ptr %slot988, align 8
  %v5727 = load i64, ptr %slot44, align 8
  %p5728 = inttoptr i64 %v5727 to ptr
  store i64 %v5726, ptr %p5728, align 8, !alias.scope !3, !noalias !4
  %v5729 = load i64, ptr %slot32, align 8
  %p5730 = inttoptr i64 %v5729 to ptr
  %ld5731 = load i64, ptr %p5730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5731, ptr %slot989, align 8
  %v5732 = load i64, ptr %slot989, align 8
  %v5733 = load i64, ptr %slot45, align 8
  %p5734 = inttoptr i64 %v5733 to ptr
  store i64 %v5732, ptr %p5734, align 8, !alias.scope !3, !noalias !4
  %v5735 = load i64, ptr %slot30, align 8
  %p5736 = inttoptr i64 %v5735 to ptr
  %ld5737 = load i64, ptr %p5736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5737, ptr %slot990, align 8
  %v5738 = load i64, ptr %slot990, align 8
  %v5739 = load i64, ptr %slot44, align 8
  %p5740 = inttoptr i64 %v5739 to ptr
  store i64 %v5738, ptr %p5740, align 8, !alias.scope !3, !noalias !4
  %v5741 = load i64, ptr %slot32, align 8
  %p5742 = inttoptr i64 %v5741 to ptr
  %ld5743 = load i64, ptr %p5742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5743, ptr %slot991, align 8
  %v5744 = load i64, ptr %slot30, align 8
  %p5745 = inttoptr i64 %v5744 to ptr
  %ld5746 = load i64, ptr %p5745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5746, ptr %slot992, align 8
  %v5747 = load i64, ptr %slot992, align 8
  %op5748 = add i64 %v5747, 16
  store i64 %op5748, ptr %slot993, align 8
  %v5749 = load i64, ptr %slot991, align 8
  %v5750 = load i64, ptr %slot993, align 8
  %p5751 = inttoptr i64 %v5750 to ptr
  store i64 %v5749, ptr %p5751, align 8, !alias.scope !4, !noalias !3
  %v5752 = load i64, ptr %slot44, align 8
  %p5753 = inttoptr i64 %v5752 to ptr
  store i64 0, ptr %p5753, align 8, !alias.scope !3, !noalias !4
  br label %bb_i124
bb_i124:
  %v5754 = load i64, ptr %slot30, align 8
  %p5755 = inttoptr i64 %v5754 to ptr
  %ld5756 = load i64, ptr %p5755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5756, ptr %slot994, align 8
  %v5757 = load i64, ptr %slot994, align 8
  %v5758 = load i64, ptr %slot44, align 8
  %p5759 = inttoptr i64 %v5758 to ptr
  store i64 %v5757, ptr %p5759, align 8, !alias.scope !3, !noalias !4
  %v5760 = load i64, ptr %slot44, align 8
  %p5761 = inttoptr i64 %v5760 to ptr
  %ld5762 = load i64, ptr %p5761, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5762, ptr %slot995, align 8
  %v5763 = load i64, ptr %slot19, align 8
  %p5764 = inttoptr i64 %v5763 to ptr
  %ld5765 = load i32, ptr %p5764, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5765, ptr %slot996, align 8
  %v5766 = load i64, ptr %slot20, align 8
  %p5767 = inttoptr i64 %v5766 to ptr
  %ld5768 = load i32, ptr %p5767, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5768, ptr %slot997, align 8
  %v5769 = load i32, ptr %slot997, align 8
  %op5770 = and i32 %v5769, 24
  store i32 %op5770, ptr %slot997, align 8
  %v5771 = load i32, ptr %slot997, align 8
  %cmp5772 = icmp eq i32 %v5771, 0
  %cv5773 = zext i1 %cmp5772 to i32
  store i32 %cv5773, ptr %slot998, align 8
  %v5774 = load i32, ptr %slot996, align 8
  %v5775 = load i32, ptr %slot998, align 8
  %op5776 = and i32 %v5774, %v5775
  store i32 %op5776, ptr %slot999, align 8
  %v5777 = load i32, ptr %slot999, align 8
  %cv5778 = zext i32 %v5777 to i64
  %cond5779 = icmp ne i64 %cv5778, 0
  br i1 %cond5779, label %bb_rctake1220, label %bb_rccopy1220
bb_rctake1220:
  %v5780 = load i64, ptr %slot29, align 8
  store i64 %v5780, ptr %slot1000, align 8
  %v5781 = load i64, ptr %slot53, align 8
  store i64 %v5781, ptr %slot1001, align 8
  %v5782 = load i64, ptr %slot995, align 8
  %v5783 = load i64, ptr %slot1000, align 8
  %op5784 = sub i64 %v5782, %v5783
  store i64 %op5784, ptr %slot1002, align 8
  %v5785 = load i64, ptr %slot1000, align 8
  %v5786 = load i64, ptr %slot995, align 8
  %op5787 = sub i64 %v5785, %v5786
  store i64 %op5787, ptr %slot1003, align 8
  %v5788 = load i64, ptr %slot1002, align 8
  %cmp5789 = icmp ult i64 %v5788, 32
  %cv5790 = zext i1 %cmp5789 to i32
  store i32 %cv5790, ptr %slot1004, align 8
  %v5791 = load i64, ptr %slot1003, align 8
  %cmp5792 = icmp ult i64 %v5791, 32
  %cv5793 = zext i1 %cmp5792 to i32
  store i32 %cv5793, ptr %slot1005, align 8
  %v5794 = load i32, ptr %slot1004, align 8
  %v5795 = load i32, ptr %slot1005, align 8
  %op5796 = or i32 %v5794, %v5795
  store i32 %op5796, ptr %slot1006, align 8
  %v5797 = load i32, ptr %slot1006, align 8
  %cv5798 = zext i32 %v5797 to i64
  %cond5799 = icmp ne i64 %cv5798, 0
  br i1 %cond5799, label %bb_rcmoveslow1229, label %bb_rcmovecheck1229
bb_rcmovecheck1229:
  %v5800 = load i64, ptr %slot995, align 8
  %op5801 = add i64 %v5800, 0
  store i64 %op5801, ptr %slot1007, align 8
  %v5802 = load i64, ptr %slot1007, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  %ld5804 = load i64, ptr %p5803, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5804, ptr %slot1008, align 8
  %v5805 = load i64, ptr %slot1008, align 8
  %cmp5806 = icmp ne i64 %v5805, 0
  %cv5807 = zext i1 %cmp5806 to i32
  store i32 %cv5807, ptr %slot1009, align 8
  %v5808 = load i32, ptr %slot1009, align 8
  %cv5809 = zext i32 %v5808 to i64
  %cond5810 = icmp ne i64 %cv5809, 0
  br i1 %cond5810, label %bb_rcmoveheader1237, label %bb_rcmovenext1237
bb_rcmoveheader1237:
  %v5811 = load i64, ptr %slot1008, align 8
  %op5812 = sub i64 %v5811, 16
  store i64 %op5812, ptr %slot1010, align 8
  %v5813 = load i64, ptr %slot1008, align 8
  %p5814 = inttoptr i64 %v5813 to ptr
  %rgep5815 = getelementptr i8, ptr %p5814, i64 -16
  %ld5816 = load i64, ptr %rgep5815, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5816, ptr %slot1011, align 8
  %v5817 = load i64, ptr %slot1011, align 8
  %op5818 = and i64 %v5817, 5764607523034234881
  store i64 %op5818, ptr %slot1012, align 8
  %v5819 = load i64, ptr %slot1012, align 8
  %cmp5820 = icmp ne i64 %v5819, 0
  %cv5821 = zext i1 %cmp5820 to i32
  store i32 %cv5821, ptr %slot1013, align 8
  %v5822 = load i32, ptr %slot1013, align 8
  %cv5823 = zext i32 %v5822 to i64
  %cond5824 = icmp ne i64 %cv5823, 0
  br i1 %cond5824, label %bb_rcmoveslow1229, label %bb_rcmovenext1237
bb_rcmovenext1237:
  %v5825 = load i64, ptr %slot995, align 8
  %v5826 = load i64, ptr %slot1000, align 8
  %p5827 = inttoptr i64 %v5825 to ptr
  %p5828 = inttoptr i64 %v5826 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5828, ptr %p5827, i64 32, i1 false), !alias.scope !10000000
  %v5829 = load i64, ptr %slot995, align 8
  %p5830 = inttoptr i64 %v5829 to ptr
  store i64 0, ptr %p5830, align 8, !alias.scope !4, !noalias !3
  %v5831 = load i64, ptr %slot995, align 8
  %op5832 = add i64 %v5831, 8
  store i64 %op5832, ptr %slot1014, align 8
  %v5833 = load i64, ptr %slot1014, align 8
  %p5834 = inttoptr i64 %v5833 to ptr
  store i64 0, ptr %p5834, align 8, !alias.scope !4, !noalias !3
  %v5835 = load i64, ptr %slot995, align 8
  %op5836 = add i64 %v5835, 16
  store i64 %op5836, ptr %slot1015, align 8
  %v5837 = load i64, ptr %slot1015, align 8
  %p5838 = inttoptr i64 %v5837 to ptr
  store i64 0, ptr %p5838, align 8, !alias.scope !4, !noalias !3
  %v5839 = load i64, ptr %slot995, align 8
  %op5840 = add i64 %v5839, 24
  store i64 %op5840, ptr %slot1016, align 8
  %v5841 = load i64, ptr %slot1016, align 8
  %p5842 = inttoptr i64 %v5841 to ptr
  store i64 0, ptr %p5842, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved1229
bb_rcmoveslow1229:
  %v5843 = load i64, ptr %slot52, align 8
  %v5844 = load i64, ptr %slot1000, align 8
  %v5845 = load i64, ptr %slot995, align 8
  %v5846 = load i64, ptr %slot1001, align 8
  %cv5847 = trunc i64 %v5846 to i32
  %call5848 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v5843, i64 %v5844, i64 %v5845, i32 %cv5847) nomerge, !dbg !172
  store i32 %call5848, ptr %slot1017, align 8
  %v5849 = load i32, ptr %slot1017, align 8
  %cv5850 = zext i32 %v5849 to i64
  %cond5851 = icmp ne i64 %cv5850, 0
  br i1 %cond5851, label %bb_rcsuccess1247, label %bb_rcfailure1247
bb_rcfailure1247:
  %v5852 = load i64, ptr %slot52, align 8
  %p5853 = inttoptr i64 %v5852 to ptr
  %call5854 = call i32 @myl_rc_take_failure(ptr %p5853) nomerge, !dbg !172
  store i32 %call5854, ptr %slot1018, align 8
  %v5855 = load i64, ptr %slot1, align 8
  %p5856 = inttoptr i64 %v5855 to ptr
  %v5857 = load i32, ptr %slot1018, align 8
  %call5858 = call i32 @myl_qbe_rc_status(ptr %p5856, i32 %v5857) nomerge, !dbg !172
  store i32 %call5858, ptr %slot1019, align 8
  br label %bb_failure
bb_rcsuccess1247:
  br label %bb_rcmoved1229
bb_rcmoved1229:
  %v5859 = load i64, ptr %slot19, align 8
  %p5860 = inttoptr i64 %v5859 to ptr
  store i32 0, ptr %p5860, align 4, !alias.scope !3, !noalias !4
  %v5861 = load i64, ptr %slot24, align 8
  %p5862 = inttoptr i64 %v5861 to ptr
  store i32 2, ptr %p5862, align 4, !alias.scope !3, !noalias !4
  %v5863 = load i64, ptr %slot23, align 8
  %p5864 = inttoptr i64 %v5863 to ptr
  store i32 1, ptr %p5864, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1220
bb_rccopy1220:
  %v5865 = load i64, ptr %slot29, align 8
  store i64 %v5865, ptr %slot1020, align 8
  %v5866 = load i64, ptr %slot53, align 8
  store i64 %v5866, ptr %slot1021, align 8
  %v5867 = load i64, ptr %slot52, align 8
  %v5868 = load i64, ptr %slot1020, align 8
  %v5869 = load i64, ptr %slot995, align 8
  %v5870 = load i64, ptr %slot1021, align 8
  %cv5871 = trunc i64 %v5870 to i32
  %call5872 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v5867, i64 %v5868, i64 %v5869, i32 %cv5871) nomerge, !dbg !172
  store i32 %call5872, ptr %slot1022, align 8
  %v5873 = load i32, ptr %slot1022, align 8
  %cv5874 = zext i32 %v5873 to i64
  %cond5875 = icmp ne i64 %cv5874, 0
  br i1 %cond5875, label %bb_rcsuccess1256, label %bb_rcfailure1256
bb_rcfailure1256:
  %v5876 = load i64, ptr %slot52, align 8
  %p5877 = inttoptr i64 %v5876 to ptr
  %call5878 = call i32 @myl_rc_take_failure(ptr %p5877) nomerge, !dbg !172
  store i32 %call5878, ptr %slot1023, align 8
  %v5879 = load i64, ptr %slot1, align 8
  %p5880 = inttoptr i64 %v5879 to ptr
  %v5881 = load i32, ptr %slot1023, align 8
  %call5882 = call i32 @myl_qbe_rc_status(ptr %p5880, i32 %v5881) nomerge, !dbg !172
  store i32 %call5882, ptr %slot1024, align 8
  br label %bb_failure
bb_rcsuccess1256:
  %v5883 = load i64, ptr %slot24, align 8
  %p5884 = inttoptr i64 %v5883 to ptr
  store i32 2, ptr %p5884, align 4, !alias.scope !3, !noalias !4
  %v5885 = load i64, ptr %slot23, align 8
  %p5886 = inttoptr i64 %v5885 to ptr
  store i32 1, ptr %p5886, align 4, !alias.scope !3, !noalias !4
  %v5887 = load i64, ptr %slot19, align 8
  %p5888 = inttoptr i64 %v5887 to ptr
  %ld5889 = load i32, ptr %p5888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5889, ptr %slot1025, align 8
  %v5890 = load i32, ptr %slot1025, align 8
  %cv5891 = zext i32 %v5890 to i64
  %cond5892 = icmp ne i64 %cv5891, 0
  br i1 %cond5892, label %bb_rcslotdrop1263, label %bb_rcslotdone1263
bb_rcslotdrop1263:
  %v5893 = load i64, ptr %slot19, align 8
  %p5894 = inttoptr i64 %v5893 to ptr
  store i32 0, ptr %p5894, align 4, !alias.scope !3, !noalias !4
  %v5895 = load i64, ptr %slot25, align 8
  store i64 %v5895, ptr %slot1026, align 8
  %v5896 = load i64, ptr %slot20, align 8
  %p5897 = inttoptr i64 %v5896 to ptr
  %ld5898 = load i32, ptr %p5897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5898, ptr %slot1027, align 8
  %v5899 = load i32, ptr %slot1027, align 8
  %op5900 = and i32 %v5899, 28
  store i32 %op5900, ptr %slot1028, align 8
  %v5901 = load i32, ptr %slot1028, align 8
  %cv5902 = zext i32 %v5901 to i64
  %cond5903 = icmp ne i64 %cv5902, 0
  br i1 %cond5903, label %bb_rcslotrole1263, label %bb_rcslotowner1263
bb_rcslotrole1263:
  %v5904 = load i64, ptr %slot52, align 8
  store i64 %v5904, ptr %slot1029, align 8
  %v5905 = load i64, ptr %slot1029, align 8
  %v5906 = load i64, ptr %slot1026, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5905, i64 %v5906) nomerge, !dbg !172
  br label %bb_rcslotdone1263
bb_rcslotowner1263:
  %v5907 = load i64, ptr %slot1026, align 8
  %p5909 = inttoptr i64 %v5907 to ptr
  %gep5910 = getelementptr i8, ptr %p5909, i64 0
  %op5908 = ptrtoint ptr %gep5910 to i64
  store i64 %op5908, ptr %slot1030, align 8
  %v5911 = load i64, ptr %slot52, align 8
  store i64 %v5911, ptr %slot1031, align 8
  %v5912 = load i64, ptr %slot1030, align 8
  %p5913 = inttoptr i64 %v5912 to ptr
  %ld5914 = load i64, ptr %p5913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5914, ptr %slot1032, align 8
  %v5915 = load i64, ptr %slot1032, align 8
  %cmp5916 = icmp ne i64 %v5915, 0
  %cv5917 = zext i1 %cmp5916 to i32
  store i32 %cv5917, ptr %slot1033, align 8
  %v5918 = load i32, ptr %slot1033, align 8
  %cv5919 = zext i32 %v5918 to i64
  %cond5920 = icmp ne i64 %cv5919, 0
  br i1 %cond5920, label %bb_rcgnn1281, label %bb_rcgdone1281
bb_rcgnn1281:
  %v5921 = load i64, ptr %slot1032, align 8
  %op5922 = sub i64 %v5921, 16
  store i64 %op5922, ptr %slot1034, align 8
  %v5923 = load i64, ptr %slot1032, align 8
  %p5924 = inttoptr i64 %v5923 to ptr
  %rgep5925 = getelementptr i8, ptr %p5924, i64 -16
  %ld5926 = load i64, ptr %rgep5925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5926, ptr %slot1035, align 8
  %v5927 = load i64, ptr %slot1035, align 8
  %op5928 = and i64 %v5927, 4611686018427387906
  store i64 %op5928, ptr %slot1036, align 8
  %v5929 = load i64, ptr %slot1036, align 8
  %cmp5930 = icmp ne i64 %v5929, 0
  %cv5931 = zext i1 %cmp5930 to i32
  store i32 %cv5931, ptr %slot1037, align 8
  %v5932 = load i32, ptr %slot1037, align 8
  %cv5933 = zext i32 %v5932 to i64
  %cond5934 = icmp ne i64 %cv5933, 0
  br i1 %cond5934, label %bb_rcgclear1281, label %bb_rcgcounted1281
bb_rcgcounted1281:
  %v5935 = load i64, ptr %slot1032, align 8
  %op5936 = sub i64 %v5935, 32
  store i64 %op5936, ptr %slot1038, align 8
  %v5937 = load i64, ptr %slot1032, align 8
  %p5938 = inttoptr i64 %v5937 to ptr
  %rgep5939 = getelementptr i8, ptr %p5938, i64 -32
  %ld5940 = load i64, ptr %rgep5939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5940, ptr %slot1039, align 8
  %v5941 = load i64, ptr %slot1039, align 8
  %op5942 = sub i64 %v5941, 1
  store i64 %op5942, ptr %slot1040, align 8
  %v5943 = load i64, ptr %slot1040, align 8
  %cmp5944 = icmp eq i64 %v5943, 0
  %cv5945 = zext i1 %cmp5944 to i32
  store i32 %cv5945, ptr %slot1041, align 8
  %v5946 = load i32, ptr %slot1041, align 8
  %cv5947 = zext i32 %v5946 to i64
  %cond5948 = icmp ne i64 %cv5947, 0
  br i1 %cond5948, label %bb_rcglast1281, label %bb_rcgdec1281
bb_rcglast1281:
  %v5949 = load i64, ptr %slot1032, align 8
  %op5950 = sub i64 %v5949, 24
  store i64 %op5950, ptr %slot1042, align 8
  %v5951 = load i64, ptr %slot1032, align 8
  %p5952 = inttoptr i64 %v5951 to ptr
  %rgep5953 = getelementptr i8, ptr %p5952, i64 -24
  %ld5954 = load i64, ptr %rgep5953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5954, ptr %slot1043, align 8
  %v5955 = load i64, ptr %slot1043, align 8
  %cmp5956 = icmp ne i64 %v5955, 0
  %cv5957 = zext i1 %cmp5956 to i32
  store i32 %cv5957, ptr %slot1044, align 8
  %v5958 = load i32, ptr %slot1044, align 8
  %cv5959 = zext i32 %v5958 to i64
  %cond5960 = icmp ne i64 %cv5959, 0
  br i1 %cond5960, label %bb_rcgdec1281, label %bb_rcgslow1281
bb_rcgslow1281:
  %v5961 = load i64, ptr %slot1031, align 8
  %v5962 = load i64, ptr %slot1030, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5961, i64 %v5962) nomerge, !dbg !172
  br label %bb_rcgdone1281
bb_rcgdec1281:
  %v5963 = load i64, ptr %slot1040, align 8
  %v5964 = load i64, ptr %slot1032, align 8
  %p5965 = inttoptr i64 %v5964 to ptr
  %rgep5966 = getelementptr i8, ptr %p5965, i64 -32
  store i64 %v5963, ptr %rgep5966, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1281
bb_rcgclear1281:
  %v5967 = load i64, ptr %slot1030, align 8
  %p5968 = inttoptr i64 %v5967 to ptr
  store i64 0, ptr %p5968, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1281
bb_rcgdone1281:
  %v5969 = load i64, ptr %slot1026, align 8
  %p5970 = inttoptr i64 %v5969 to ptr
  store i64 0, ptr %p5970, align 8, !alias.scope !3, !noalias !4
  %v5971 = load i64, ptr %slot1026, align 8
  %p5973 = inttoptr i64 %v5971 to ptr
  %gep5974 = getelementptr i8, ptr %p5973, i64 8
  %op5972 = ptrtoint ptr %gep5974 to i64
  store i64 %op5972, ptr %slot1045, align 8
  %v5975 = load i64, ptr %slot1045, align 8
  %p5976 = inttoptr i64 %v5975 to ptr
  store i64 0, ptr %p5976, align 8, !alias.scope !3, !noalias !4
  %v5977 = load i64, ptr %slot1026, align 8
  %p5979 = inttoptr i64 %v5977 to ptr
  %gep5980 = getelementptr i8, ptr %p5979, i64 16
  %op5978 = ptrtoint ptr %gep5980 to i64
  store i64 %op5978, ptr %slot1046, align 8
  %v5981 = load i64, ptr %slot1046, align 8
  %p5982 = inttoptr i64 %v5981 to ptr
  store i64 0, ptr %p5982, align 8, !alias.scope !3, !noalias !4
  %v5983 = load i64, ptr %slot1026, align 8
  %p5985 = inttoptr i64 %v5983 to ptr
  %gep5986 = getelementptr i8, ptr %p5985, i64 24
  %op5984 = ptrtoint ptr %gep5986 to i64
  store i64 %op5984, ptr %slot1047, align 8
  %v5987 = load i64, ptr %slot1047, align 8
  %p5988 = inttoptr i64 %v5987 to ptr
  store i64 0, ptr %p5988, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1263
bb_rcslotdone1263:
  br label %bb_rcprepared1220
bb_rcprepared1220:
  %v5989 = load i64, ptr %slot15, align 8
  %p5990 = inttoptr i64 %v5989 to ptr
  %ld5991 = load i32, ptr %p5990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5991, ptr %slot1048, align 8
  %v5992 = load i32, ptr %slot1048, align 8
  %cv5993 = zext i32 %v5992 to i64
  %cond5994 = icmp ne i64 %cv5993, 0
  br i1 %cond5994, label %bb_rcslotdrop1291, label %bb_rcslotdone1291
bb_rcslotdrop1291:
  %v5995 = load i64, ptr %slot15, align 8
  %p5996 = inttoptr i64 %v5995 to ptr
  store i32 0, ptr %p5996, align 4, !alias.scope !3, !noalias !4
  %v5997 = load i64, ptr %slot41, align 8
  store i64 %v5997, ptr %slot1049, align 8
  %v5998 = load i64, ptr %slot16, align 8
  %p5999 = inttoptr i64 %v5998 to ptr
  %ld6000 = load i32, ptr %p5999, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6000, ptr %slot1050, align 8
  %v6001 = load i32, ptr %slot1050, align 8
  %op6002 = and i32 %v6001, 28
  store i32 %op6002, ptr %slot1051, align 8
  %v6003 = load i32, ptr %slot1051, align 8
  %cv6004 = zext i32 %v6003 to i64
  %cond6005 = icmp ne i64 %cv6004, 0
  br i1 %cond6005, label %bb_rcslotrole1291, label %bb_rcslotowner1291
bb_rcslotrole1291:
  %v6006 = load i64, ptr %slot52, align 8
  store i64 %v6006, ptr %slot1052, align 8
  %v6007 = load i64, ptr %slot1052, align 8
  %v6008 = load i64, ptr %slot1049, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6007, i64 %v6008) nomerge, !dbg !172
  br label %bb_rcslotdone1291
bb_rcslotowner1291:
  %v6009 = load i64, ptr %slot1049, align 8
  %p6011 = inttoptr i64 %v6009 to ptr
  %gep6012 = getelementptr i8, ptr %p6011, i64 0
  %op6010 = ptrtoint ptr %gep6012 to i64
  store i64 %op6010, ptr %slot1053, align 8
  %v6013 = load i64, ptr %slot52, align 8
  store i64 %v6013, ptr %slot1054, align 8
  %v6014 = load i64, ptr %slot1053, align 8
  %p6015 = inttoptr i64 %v6014 to ptr
  %ld6016 = load i64, ptr %p6015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6016, ptr %slot1055, align 8
  %v6017 = load i64, ptr %slot1055, align 8
  %cmp6018 = icmp ne i64 %v6017, 0
  %cv6019 = zext i1 %cmp6018 to i32
  store i32 %cv6019, ptr %slot1056, align 8
  %v6020 = load i32, ptr %slot1056, align 8
  %cv6021 = zext i32 %v6020 to i64
  %cond6022 = icmp ne i64 %cv6021, 0
  br i1 %cond6022, label %bb_rcgnn1309, label %bb_rcgdone1309
bb_rcgnn1309:
  %v6023 = load i64, ptr %slot1055, align 8
  %op6024 = sub i64 %v6023, 16
  store i64 %op6024, ptr %slot1057, align 8
  %v6025 = load i64, ptr %slot1055, align 8
  %p6026 = inttoptr i64 %v6025 to ptr
  %rgep6027 = getelementptr i8, ptr %p6026, i64 -16
  %ld6028 = load i64, ptr %rgep6027, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6028, ptr %slot1058, align 8
  %v6029 = load i64, ptr %slot1058, align 8
  %op6030 = and i64 %v6029, 4611686018427387906
  store i64 %op6030, ptr %slot1059, align 8
  %v6031 = load i64, ptr %slot1059, align 8
  %cmp6032 = icmp ne i64 %v6031, 0
  %cv6033 = zext i1 %cmp6032 to i32
  store i32 %cv6033, ptr %slot1060, align 8
  %v6034 = load i32, ptr %slot1060, align 8
  %cv6035 = zext i32 %v6034 to i64
  %cond6036 = icmp ne i64 %cv6035, 0
  br i1 %cond6036, label %bb_rcgclear1309, label %bb_rcgcounted1309
bb_rcgcounted1309:
  %v6037 = load i64, ptr %slot1055, align 8
  %op6038 = sub i64 %v6037, 32
  store i64 %op6038, ptr %slot1061, align 8
  %v6039 = load i64, ptr %slot1055, align 8
  %p6040 = inttoptr i64 %v6039 to ptr
  %rgep6041 = getelementptr i8, ptr %p6040, i64 -32
  %ld6042 = load i64, ptr %rgep6041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6042, ptr %slot1062, align 8
  %v6043 = load i64, ptr %slot1062, align 8
  %op6044 = sub i64 %v6043, 1
  store i64 %op6044, ptr %slot1063, align 8
  %v6045 = load i64, ptr %slot1063, align 8
  %cmp6046 = icmp eq i64 %v6045, 0
  %cv6047 = zext i1 %cmp6046 to i32
  store i32 %cv6047, ptr %slot1064, align 8
  %v6048 = load i32, ptr %slot1064, align 8
  %cv6049 = zext i32 %v6048 to i64
  %cond6050 = icmp ne i64 %cv6049, 0
  br i1 %cond6050, label %bb_rcglast1309, label %bb_rcgdec1309
bb_rcglast1309:
  %v6051 = load i64, ptr %slot1055, align 8
  %op6052 = sub i64 %v6051, 24
  store i64 %op6052, ptr %slot1065, align 8
  %v6053 = load i64, ptr %slot1055, align 8
  %p6054 = inttoptr i64 %v6053 to ptr
  %rgep6055 = getelementptr i8, ptr %p6054, i64 -24
  %ld6056 = load i64, ptr %rgep6055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6056, ptr %slot1066, align 8
  %v6057 = load i64, ptr %slot1066, align 8
  %cmp6058 = icmp ne i64 %v6057, 0
  %cv6059 = zext i1 %cmp6058 to i32
  store i32 %cv6059, ptr %slot1067, align 8
  %v6060 = load i32, ptr %slot1067, align 8
  %cv6061 = zext i32 %v6060 to i64
  %cond6062 = icmp ne i64 %cv6061, 0
  br i1 %cond6062, label %bb_rcgdec1309, label %bb_rcgslow1309
bb_rcgslow1309:
  %v6063 = load i64, ptr %slot1054, align 8
  %v6064 = load i64, ptr %slot1053, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6063, i64 %v6064) nomerge, !dbg !172
  br label %bb_rcgdone1309
bb_rcgdec1309:
  %v6065 = load i64, ptr %slot1063, align 8
  %v6066 = load i64, ptr %slot1055, align 8
  %p6067 = inttoptr i64 %v6066 to ptr
  %rgep6068 = getelementptr i8, ptr %p6067, i64 -32
  store i64 %v6065, ptr %rgep6068, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1309
bb_rcgclear1309:
  %v6069 = load i64, ptr %slot1053, align 8
  %p6070 = inttoptr i64 %v6069 to ptr
  store i64 0, ptr %p6070, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1309
bb_rcgdone1309:
  %v6071 = load i64, ptr %slot1049, align 8
  %p6072 = inttoptr i64 %v6071 to ptr
  store i64 0, ptr %p6072, align 8, !alias.scope !3, !noalias !4
  %v6073 = load i64, ptr %slot1049, align 8
  %p6075 = inttoptr i64 %v6073 to ptr
  %gep6076 = getelementptr i8, ptr %p6075, i64 8
  %op6074 = ptrtoint ptr %gep6076 to i64
  store i64 %op6074, ptr %slot1068, align 8
  %v6077 = load i64, ptr %slot1068, align 8
  %p6078 = inttoptr i64 %v6077 to ptr
  store i64 0, ptr %p6078, align 8, !alias.scope !3, !noalias !4
  %v6079 = load i64, ptr %slot1049, align 8
  %p6081 = inttoptr i64 %v6079 to ptr
  %gep6082 = getelementptr i8, ptr %p6081, i64 16
  %op6080 = ptrtoint ptr %gep6082 to i64
  store i64 %op6080, ptr %slot1069, align 8
  %v6083 = load i64, ptr %slot1069, align 8
  %p6084 = inttoptr i64 %v6083 to ptr
  store i64 0, ptr %p6084, align 8, !alias.scope !3, !noalias !4
  %v6085 = load i64, ptr %slot1049, align 8
  %p6087 = inttoptr i64 %v6085 to ptr
  %gep6088 = getelementptr i8, ptr %p6087, i64 24
  %op6086 = ptrtoint ptr %gep6088 to i64
  store i64 %op6086, ptr %slot1070, align 8
  %v6089 = load i64, ptr %slot1070, align 8
  %p6090 = inttoptr i64 %v6089 to ptr
  store i64 0, ptr %p6090, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1291
bb_rcslotdone1291:
  %v6091 = load i64, ptr %slot41, align 8
  store i64 %v6091, ptr %slot1071, align 8
  %v6092 = load i64, ptr %slot29, align 8
  store i64 %v6092, ptr %slot1072, align 8
  %v6093 = load i64, ptr %slot1072, align 8
  %v6094 = load i64, ptr %slot1071, align 8
  %p6095 = inttoptr i64 %v6093 to ptr
  %p6096 = inttoptr i64 %v6094 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6096, ptr %p6095, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v6097 = load i64, ptr %slot23, align 8
  %p6098 = inttoptr i64 %v6097 to ptr
  store i32 0, ptr %p6098, align 4, !alias.scope !3, !noalias !4
  %v6099 = load i64, ptr %slot16, align 8
  %p6100 = inttoptr i64 %v6099 to ptr
  store i32 2, ptr %p6100, align 4, !alias.scope !3, !noalias !4
  %v6101 = load i64, ptr %slot24, align 8
  %p6102 = inttoptr i64 %v6101 to ptr
  %ld6103 = load i32, ptr %p6102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6103, ptr %slot1073, align 8
  %v6104 = load i32, ptr %slot1073, align 8
  %v6105 = load i64, ptr %slot16, align 8
  %p6106 = inttoptr i64 %v6105 to ptr
  store i32 %v6104, ptr %p6106, align 4, !alias.scope !3, !noalias !4
  %v6107 = load i64, ptr %slot15, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  store i32 1, ptr %p6108, align 4, !alias.scope !3, !noalias !4
  %v6109 = load i64, ptr %slot41, align 8
  %v6110 = load i64, ptr %slot44, align 8
  %p6111 = inttoptr i64 %v6110 to ptr
  store i64 %v6109, ptr %p6111, align 8, !alias.scope !3, !noalias !4
  %v6112 = load i64, ptr %slot44, align 8
  %p6113 = inttoptr i64 %v6112 to ptr
  %ld6114 = load i64, ptr %p6113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6114, ptr %slot1074, align 8
  %v6115 = load i64, ptr %slot19, align 8
  %p6116 = inttoptr i64 %v6115 to ptr
  %ld6117 = load i32, ptr %p6116, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6117, ptr %slot1075, align 8
  %v6118 = load i64, ptr %slot20, align 8
  %p6119 = inttoptr i64 %v6118 to ptr
  %ld6120 = load i32, ptr %p6119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6120, ptr %slot1076, align 8
  %v6121 = load i32, ptr %slot1076, align 8
  %op6122 = and i32 %v6121, 24
  store i32 %op6122, ptr %slot1076, align 8
  %v6123 = load i32, ptr %slot1076, align 8
  %cmp6124 = icmp eq i32 %v6123, 0
  %cv6125 = zext i1 %cmp6124 to i32
  store i32 %cv6125, ptr %slot1077, align 8
  %v6126 = load i32, ptr %slot1075, align 8
  %v6127 = load i32, ptr %slot1077, align 8
  %op6128 = and i32 %v6126, %v6127
  store i32 %op6128, ptr %slot1078, align 8
  %v6129 = load i32, ptr %slot1078, align 8
  %cv6130 = zext i32 %v6129 to i64
  %cond6131 = icmp ne i64 %cv6130, 0
  br i1 %cond6131, label %bb_rctake1324, label %bb_rccopy1324
bb_rctake1324:
  %v6132 = load i64, ptr %slot29, align 8
  store i64 %v6132, ptr %slot1079, align 8
  %v6133 = load i64, ptr %slot53, align 8
  store i64 %v6133, ptr %slot1080, align 8
  %v6134 = load i64, ptr %slot1074, align 8
  %v6135 = load i64, ptr %slot1079, align 8
  %op6136 = sub i64 %v6134, %v6135
  store i64 %op6136, ptr %slot1081, align 8
  %v6137 = load i64, ptr %slot1079, align 8
  %v6138 = load i64, ptr %slot1074, align 8
  %op6139 = sub i64 %v6137, %v6138
  store i64 %op6139, ptr %slot1082, align 8
  %v6140 = load i64, ptr %slot1081, align 8
  %cmp6141 = icmp ult i64 %v6140, 32
  %cv6142 = zext i1 %cmp6141 to i32
  store i32 %cv6142, ptr %slot1083, align 8
  %v6143 = load i64, ptr %slot1082, align 8
  %cmp6144 = icmp ult i64 %v6143, 32
  %cv6145 = zext i1 %cmp6144 to i32
  store i32 %cv6145, ptr %slot1084, align 8
  %v6146 = load i32, ptr %slot1083, align 8
  %v6147 = load i32, ptr %slot1084, align 8
  %op6148 = or i32 %v6146, %v6147
  store i32 %op6148, ptr %slot1085, align 8
  %v6149 = load i32, ptr %slot1085, align 8
  %cv6150 = zext i32 %v6149 to i64
  %cond6151 = icmp ne i64 %cv6150, 0
  br i1 %cond6151, label %bb_rcmoveslow1333, label %bb_rcmovecheck1333
bb_rcmovecheck1333:
  %v6152 = load i64, ptr %slot1074, align 8
  %op6153 = add i64 %v6152, 0
  store i64 %op6153, ptr %slot1086, align 8
  %v6154 = load i64, ptr %slot1086, align 8
  %p6155 = inttoptr i64 %v6154 to ptr
  %ld6156 = load i64, ptr %p6155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6156, ptr %slot1087, align 8
  %v6157 = load i64, ptr %slot1087, align 8
  %cmp6158 = icmp ne i64 %v6157, 0
  %cv6159 = zext i1 %cmp6158 to i32
  store i32 %cv6159, ptr %slot1088, align 8
  %v6160 = load i32, ptr %slot1088, align 8
  %cv6161 = zext i32 %v6160 to i64
  %cond6162 = icmp ne i64 %cv6161, 0
  br i1 %cond6162, label %bb_rcmoveheader1341, label %bb_rcmovenext1341
bb_rcmoveheader1341:
  %v6163 = load i64, ptr %slot1087, align 8
  %op6164 = sub i64 %v6163, 16
  store i64 %op6164, ptr %slot1089, align 8
  %v6165 = load i64, ptr %slot1087, align 8
  %p6166 = inttoptr i64 %v6165 to ptr
  %rgep6167 = getelementptr i8, ptr %p6166, i64 -16
  %ld6168 = load i64, ptr %rgep6167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6168, ptr %slot1090, align 8
  %v6169 = load i64, ptr %slot1090, align 8
  %op6170 = and i64 %v6169, 5764607523034234881
  store i64 %op6170, ptr %slot1091, align 8
  %v6171 = load i64, ptr %slot1091, align 8
  %cmp6172 = icmp ne i64 %v6171, 0
  %cv6173 = zext i1 %cmp6172 to i32
  store i32 %cv6173, ptr %slot1092, align 8
  %v6174 = load i32, ptr %slot1092, align 8
  %cv6175 = zext i32 %v6174 to i64
  %cond6176 = icmp ne i64 %cv6175, 0
  br i1 %cond6176, label %bb_rcmoveslow1333, label %bb_rcmovenext1341
bb_rcmovenext1341:
  %v6177 = load i64, ptr %slot1074, align 8
  %v6178 = load i64, ptr %slot1079, align 8
  %p6179 = inttoptr i64 %v6177 to ptr
  %p6180 = inttoptr i64 %v6178 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6180, ptr %p6179, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v6181 = load i64, ptr %slot1074, align 8
  %p6182 = inttoptr i64 %v6181 to ptr
  store i64 0, ptr %p6182, align 8, !alias.scope !3, !noalias !4
  %v6183 = load i64, ptr %slot1074, align 8
  %op6184 = add i64 %v6183, 8
  store i64 %op6184, ptr %slot1093, align 8
  %v6185 = load i64, ptr %slot1093, align 8
  %p6186 = inttoptr i64 %v6185 to ptr
  store i64 0, ptr %p6186, align 8, !alias.scope !3, !noalias !4
  %v6187 = load i64, ptr %slot1074, align 8
  %op6188 = add i64 %v6187, 16
  store i64 %op6188, ptr %slot1094, align 8
  %v6189 = load i64, ptr %slot1094, align 8
  %p6190 = inttoptr i64 %v6189 to ptr
  store i64 0, ptr %p6190, align 8, !alias.scope !3, !noalias !4
  %v6191 = load i64, ptr %slot1074, align 8
  %op6192 = add i64 %v6191, 24
  store i64 %op6192, ptr %slot1095, align 8
  %v6193 = load i64, ptr %slot1095, align 8
  %p6194 = inttoptr i64 %v6193 to ptr
  store i64 0, ptr %p6194, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1333
bb_rcmoveslow1333:
  %v6195 = load i64, ptr %slot52, align 8
  %v6196 = load i64, ptr %slot1079, align 8
  %v6197 = load i64, ptr %slot1074, align 8
  %v6198 = load i64, ptr %slot1080, align 8
  %cv6199 = trunc i64 %v6198 to i32
  %call6200 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v6195, i64 %v6196, i64 %v6197, i32 %cv6199) nomerge, !dbg !174
  store i32 %call6200, ptr %slot1096, align 8
  %v6201 = load i32, ptr %slot1096, align 8
  %cv6202 = zext i32 %v6201 to i64
  %cond6203 = icmp ne i64 %cv6202, 0
  br i1 %cond6203, label %bb_rcsuccess1351, label %bb_rcfailure1351
bb_rcfailure1351:
  %v6204 = load i64, ptr %slot52, align 8
  %p6205 = inttoptr i64 %v6204 to ptr
  %call6206 = call i32 @myl_rc_take_failure(ptr %p6205) nomerge, !dbg !174
  store i32 %call6206, ptr %slot1097, align 8
  %v6207 = load i64, ptr %slot1, align 8
  %p6208 = inttoptr i64 %v6207 to ptr
  %v6209 = load i32, ptr %slot1097, align 8
  %call6210 = call i32 @myl_qbe_rc_status(ptr %p6208, i32 %v6209) nomerge, !dbg !174
  store i32 %call6210, ptr %slot1098, align 8
  br label %bb_failure
bb_rcsuccess1351:
  br label %bb_rcmoved1333
bb_rcmoved1333:
  %v6211 = load i64, ptr %slot19, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  store i32 0, ptr %p6212, align 4, !alias.scope !3, !noalias !4
  %v6213 = load i64, ptr %slot24, align 8
  %p6214 = inttoptr i64 %v6213 to ptr
  store i32 2, ptr %p6214, align 4, !alias.scope !3, !noalias !4
  %v6215 = load i64, ptr %slot23, align 8
  %p6216 = inttoptr i64 %v6215 to ptr
  store i32 1, ptr %p6216, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1324
bb_rccopy1324:
  %v6217 = load i64, ptr %slot29, align 8
  store i64 %v6217, ptr %slot1099, align 8
  %v6218 = load i64, ptr %slot53, align 8
  store i64 %v6218, ptr %slot1100, align 8
  %v6219 = load i64, ptr %slot52, align 8
  %v6220 = load i64, ptr %slot1099, align 8
  %v6221 = load i64, ptr %slot1074, align 8
  %v6222 = load i64, ptr %slot1100, align 8
  %cv6223 = trunc i64 %v6222 to i32
  %call6224 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v6219, i64 %v6220, i64 %v6221, i32 %cv6223) nomerge, !dbg !174
  store i32 %call6224, ptr %slot1101, align 8
  %v6225 = load i32, ptr %slot1101, align 8
  %cv6226 = zext i32 %v6225 to i64
  %cond6227 = icmp ne i64 %cv6226, 0
  br i1 %cond6227, label %bb_rcsuccess1360, label %bb_rcfailure1360
bb_rcfailure1360:
  %v6228 = load i64, ptr %slot52, align 8
  %p6229 = inttoptr i64 %v6228 to ptr
  %call6230 = call i32 @myl_rc_take_failure(ptr %p6229) nomerge, !dbg !174
  store i32 %call6230, ptr %slot1102, align 8
  %v6231 = load i64, ptr %slot1, align 8
  %p6232 = inttoptr i64 %v6231 to ptr
  %v6233 = load i32, ptr %slot1102, align 8
  %call6234 = call i32 @myl_qbe_rc_status(ptr %p6232, i32 %v6233) nomerge, !dbg !174
  store i32 %call6234, ptr %slot1103, align 8
  br label %bb_failure
bb_rcsuccess1360:
  %v6235 = load i64, ptr %slot24, align 8
  %p6236 = inttoptr i64 %v6235 to ptr
  store i32 2, ptr %p6236, align 4, !alias.scope !3, !noalias !4
  %v6237 = load i64, ptr %slot23, align 8
  %p6238 = inttoptr i64 %v6237 to ptr
  store i32 1, ptr %p6238, align 4, !alias.scope !3, !noalias !4
  %v6239 = load i64, ptr %slot19, align 8
  %p6240 = inttoptr i64 %v6239 to ptr
  %ld6241 = load i32, ptr %p6240, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6241, ptr %slot1104, align 8
  %v6242 = load i32, ptr %slot1104, align 8
  %cv6243 = zext i32 %v6242 to i64
  %cond6244 = icmp ne i64 %cv6243, 0
  br i1 %cond6244, label %bb_rcslotdrop1367, label %bb_rcslotdone1367
bb_rcslotdrop1367:
  %v6245 = load i64, ptr %slot19, align 8
  %p6246 = inttoptr i64 %v6245 to ptr
  store i32 0, ptr %p6246, align 4, !alias.scope !3, !noalias !4
  %v6247 = load i64, ptr %slot25, align 8
  store i64 %v6247, ptr %slot1105, align 8
  %v6248 = load i64, ptr %slot20, align 8
  %p6249 = inttoptr i64 %v6248 to ptr
  %ld6250 = load i32, ptr %p6249, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6250, ptr %slot1106, align 8
  %v6251 = load i32, ptr %slot1106, align 8
  %op6252 = and i32 %v6251, 28
  store i32 %op6252, ptr %slot1107, align 8
  %v6253 = load i32, ptr %slot1107, align 8
  %cv6254 = zext i32 %v6253 to i64
  %cond6255 = icmp ne i64 %cv6254, 0
  br i1 %cond6255, label %bb_rcslotrole1367, label %bb_rcslotowner1367
bb_rcslotrole1367:
  %v6256 = load i64, ptr %slot52, align 8
  store i64 %v6256, ptr %slot1108, align 8
  %v6257 = load i64, ptr %slot1108, align 8
  %v6258 = load i64, ptr %slot1105, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6257, i64 %v6258) nomerge, !dbg !174
  br label %bb_rcslotdone1367
bb_rcslotowner1367:
  %v6259 = load i64, ptr %slot1105, align 8
  %p6261 = inttoptr i64 %v6259 to ptr
  %gep6262 = getelementptr i8, ptr %p6261, i64 0
  %op6260 = ptrtoint ptr %gep6262 to i64
  store i64 %op6260, ptr %slot1109, align 8
  %v6263 = load i64, ptr %slot52, align 8
  store i64 %v6263, ptr %slot1110, align 8
  %v6264 = load i64, ptr %slot1109, align 8
  %p6265 = inttoptr i64 %v6264 to ptr
  %ld6266 = load i64, ptr %p6265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6266, ptr %slot1111, align 8
  %v6267 = load i64, ptr %slot1111, align 8
  %cmp6268 = icmp ne i64 %v6267, 0
  %cv6269 = zext i1 %cmp6268 to i32
  store i32 %cv6269, ptr %slot1112, align 8
  %v6270 = load i32, ptr %slot1112, align 8
  %cv6271 = zext i32 %v6270 to i64
  %cond6272 = icmp ne i64 %cv6271, 0
  br i1 %cond6272, label %bb_rcgnn1385, label %bb_rcgdone1385
bb_rcgnn1385:
  %v6273 = load i64, ptr %slot1111, align 8
  %op6274 = sub i64 %v6273, 16
  store i64 %op6274, ptr %slot1113, align 8
  %v6275 = load i64, ptr %slot1111, align 8
  %p6276 = inttoptr i64 %v6275 to ptr
  %rgep6277 = getelementptr i8, ptr %p6276, i64 -16
  %ld6278 = load i64, ptr %rgep6277, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6278, ptr %slot1114, align 8
  %v6279 = load i64, ptr %slot1114, align 8
  %op6280 = and i64 %v6279, 4611686018427387906
  store i64 %op6280, ptr %slot1115, align 8
  %v6281 = load i64, ptr %slot1115, align 8
  %cmp6282 = icmp ne i64 %v6281, 0
  %cv6283 = zext i1 %cmp6282 to i32
  store i32 %cv6283, ptr %slot1116, align 8
  %v6284 = load i32, ptr %slot1116, align 8
  %cv6285 = zext i32 %v6284 to i64
  %cond6286 = icmp ne i64 %cv6285, 0
  br i1 %cond6286, label %bb_rcgclear1385, label %bb_rcgcounted1385
bb_rcgcounted1385:
  %v6287 = load i64, ptr %slot1111, align 8
  %op6288 = sub i64 %v6287, 32
  store i64 %op6288, ptr %slot1117, align 8
  %v6289 = load i64, ptr %slot1111, align 8
  %p6290 = inttoptr i64 %v6289 to ptr
  %rgep6291 = getelementptr i8, ptr %p6290, i64 -32
  %ld6292 = load i64, ptr %rgep6291, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6292, ptr %slot1118, align 8
  %v6293 = load i64, ptr %slot1118, align 8
  %op6294 = sub i64 %v6293, 1
  store i64 %op6294, ptr %slot1119, align 8
  %v6295 = load i64, ptr %slot1119, align 8
  %cmp6296 = icmp eq i64 %v6295, 0
  %cv6297 = zext i1 %cmp6296 to i32
  store i32 %cv6297, ptr %slot1120, align 8
  %v6298 = load i32, ptr %slot1120, align 8
  %cv6299 = zext i32 %v6298 to i64
  %cond6300 = icmp ne i64 %cv6299, 0
  br i1 %cond6300, label %bb_rcglast1385, label %bb_rcgdec1385
bb_rcglast1385:
  %v6301 = load i64, ptr %slot1111, align 8
  %op6302 = sub i64 %v6301, 24
  store i64 %op6302, ptr %slot1121, align 8
  %v6303 = load i64, ptr %slot1111, align 8
  %p6304 = inttoptr i64 %v6303 to ptr
  %rgep6305 = getelementptr i8, ptr %p6304, i64 -24
  %ld6306 = load i64, ptr %rgep6305, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6306, ptr %slot1122, align 8
  %v6307 = load i64, ptr %slot1122, align 8
  %cmp6308 = icmp ne i64 %v6307, 0
  %cv6309 = zext i1 %cmp6308 to i32
  store i32 %cv6309, ptr %slot1123, align 8
  %v6310 = load i32, ptr %slot1123, align 8
  %cv6311 = zext i32 %v6310 to i64
  %cond6312 = icmp ne i64 %cv6311, 0
  br i1 %cond6312, label %bb_rcgdec1385, label %bb_rcgslow1385
bb_rcgslow1385:
  %v6313 = load i64, ptr %slot1110, align 8
  %v6314 = load i64, ptr %slot1109, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6313, i64 %v6314) nomerge, !dbg !174
  br label %bb_rcgdone1385
bb_rcgdec1385:
  %v6315 = load i64, ptr %slot1119, align 8
  %v6316 = load i64, ptr %slot1111, align 8
  %p6317 = inttoptr i64 %v6316 to ptr
  %rgep6318 = getelementptr i8, ptr %p6317, i64 -32
  store i64 %v6315, ptr %rgep6318, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1385
bb_rcgclear1385:
  %v6319 = load i64, ptr %slot1109, align 8
  %p6320 = inttoptr i64 %v6319 to ptr
  store i64 0, ptr %p6320, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1385
bb_rcgdone1385:
  %v6321 = load i64, ptr %slot1105, align 8
  %p6322 = inttoptr i64 %v6321 to ptr
  store i64 0, ptr %p6322, align 8, !alias.scope !3, !noalias !4
  %v6323 = load i64, ptr %slot1105, align 8
  %p6325 = inttoptr i64 %v6323 to ptr
  %gep6326 = getelementptr i8, ptr %p6325, i64 8
  %op6324 = ptrtoint ptr %gep6326 to i64
  store i64 %op6324, ptr %slot1124, align 8
  %v6327 = load i64, ptr %slot1124, align 8
  %p6328 = inttoptr i64 %v6327 to ptr
  store i64 0, ptr %p6328, align 8, !alias.scope !3, !noalias !4
  %v6329 = load i64, ptr %slot1105, align 8
  %p6331 = inttoptr i64 %v6329 to ptr
  %gep6332 = getelementptr i8, ptr %p6331, i64 16
  %op6330 = ptrtoint ptr %gep6332 to i64
  store i64 %op6330, ptr %slot1125, align 8
  %v6333 = load i64, ptr %slot1125, align 8
  %p6334 = inttoptr i64 %v6333 to ptr
  store i64 0, ptr %p6334, align 8, !alias.scope !3, !noalias !4
  %v6335 = load i64, ptr %slot1105, align 8
  %p6337 = inttoptr i64 %v6335 to ptr
  %gep6338 = getelementptr i8, ptr %p6337, i64 24
  %op6336 = ptrtoint ptr %gep6338 to i64
  store i64 %op6336, ptr %slot1126, align 8
  %v6339 = load i64, ptr %slot1126, align 8
  %p6340 = inttoptr i64 %v6339 to ptr
  store i64 0, ptr %p6340, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1367
bb_rcslotdone1367:
  br label %bb_rcprepared1324
bb_rcprepared1324:
  %v6341 = load i64, ptr %slot17, align 8
  %p6342 = inttoptr i64 %v6341 to ptr
  %ld6343 = load i32, ptr %p6342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6343, ptr %slot1127, align 8
  %v6344 = load i32, ptr %slot1127, align 8
  %cv6345 = zext i32 %v6344 to i64
  %cond6346 = icmp ne i64 %cv6345, 0
  br i1 %cond6346, label %bb_rcslotdrop1395, label %bb_rcslotdone1395
bb_rcslotdrop1395:
  %v6347 = load i64, ptr %slot17, align 8
  %p6348 = inttoptr i64 %v6347 to ptr
  store i32 0, ptr %p6348, align 4, !alias.scope !3, !noalias !4
  %v6349 = load i64, ptr %slot42, align 8
  store i64 %v6349, ptr %slot1128, align 8
  %v6350 = load i64, ptr %slot18, align 8
  %p6351 = inttoptr i64 %v6350 to ptr
  %ld6352 = load i32, ptr %p6351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6352, ptr %slot1129, align 8
  %v6353 = load i32, ptr %slot1129, align 8
  %op6354 = and i32 %v6353, 28
  store i32 %op6354, ptr %slot1130, align 8
  %v6355 = load i32, ptr %slot1130, align 8
  %cv6356 = zext i32 %v6355 to i64
  %cond6357 = icmp ne i64 %cv6356, 0
  br i1 %cond6357, label %bb_rcslotrole1395, label %bb_rcslotowner1395
bb_rcslotrole1395:
  %v6358 = load i64, ptr %slot52, align 8
  store i64 %v6358, ptr %slot1131, align 8
  %v6359 = load i64, ptr %slot1131, align 8
  %v6360 = load i64, ptr %slot1128, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6359, i64 %v6360) nomerge, !dbg !174
  br label %bb_rcslotdone1395
bb_rcslotowner1395:
  %v6361 = load i64, ptr %slot1128, align 8
  %p6363 = inttoptr i64 %v6361 to ptr
  %gep6364 = getelementptr i8, ptr %p6363, i64 0
  %op6362 = ptrtoint ptr %gep6364 to i64
  store i64 %op6362, ptr %slot1132, align 8
  %v6365 = load i64, ptr %slot52, align 8
  store i64 %v6365, ptr %slot1133, align 8
  %v6366 = load i64, ptr %slot1132, align 8
  %p6367 = inttoptr i64 %v6366 to ptr
  %ld6368 = load i64, ptr %p6367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6368, ptr %slot1134, align 8
  %v6369 = load i64, ptr %slot1134, align 8
  %cmp6370 = icmp ne i64 %v6369, 0
  %cv6371 = zext i1 %cmp6370 to i32
  store i32 %cv6371, ptr %slot1135, align 8
  %v6372 = load i32, ptr %slot1135, align 8
  %cv6373 = zext i32 %v6372 to i64
  %cond6374 = icmp ne i64 %cv6373, 0
  br i1 %cond6374, label %bb_rcgnn1413, label %bb_rcgdone1413
bb_rcgnn1413:
  %v6375 = load i64, ptr %slot1134, align 8
  %op6376 = sub i64 %v6375, 16
  store i64 %op6376, ptr %slot1136, align 8
  %v6377 = load i64, ptr %slot1134, align 8
  %p6378 = inttoptr i64 %v6377 to ptr
  %rgep6379 = getelementptr i8, ptr %p6378, i64 -16
  %ld6380 = load i64, ptr %rgep6379, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6380, ptr %slot1137, align 8
  %v6381 = load i64, ptr %slot1137, align 8
  %op6382 = and i64 %v6381, 4611686018427387906
  store i64 %op6382, ptr %slot1138, align 8
  %v6383 = load i64, ptr %slot1138, align 8
  %cmp6384 = icmp ne i64 %v6383, 0
  %cv6385 = zext i1 %cmp6384 to i32
  store i32 %cv6385, ptr %slot1139, align 8
  %v6386 = load i32, ptr %slot1139, align 8
  %cv6387 = zext i32 %v6386 to i64
  %cond6388 = icmp ne i64 %cv6387, 0
  br i1 %cond6388, label %bb_rcgclear1413, label %bb_rcgcounted1413
bb_rcgcounted1413:
  %v6389 = load i64, ptr %slot1134, align 8
  %op6390 = sub i64 %v6389, 32
  store i64 %op6390, ptr %slot1140, align 8
  %v6391 = load i64, ptr %slot1134, align 8
  %p6392 = inttoptr i64 %v6391 to ptr
  %rgep6393 = getelementptr i8, ptr %p6392, i64 -32
  %ld6394 = load i64, ptr %rgep6393, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6394, ptr %slot1141, align 8
  %v6395 = load i64, ptr %slot1141, align 8
  %op6396 = sub i64 %v6395, 1
  store i64 %op6396, ptr %slot1142, align 8
  %v6397 = load i64, ptr %slot1142, align 8
  %cmp6398 = icmp eq i64 %v6397, 0
  %cv6399 = zext i1 %cmp6398 to i32
  store i32 %cv6399, ptr %slot1143, align 8
  %v6400 = load i32, ptr %slot1143, align 8
  %cv6401 = zext i32 %v6400 to i64
  %cond6402 = icmp ne i64 %cv6401, 0
  br i1 %cond6402, label %bb_rcglast1413, label %bb_rcgdec1413
bb_rcglast1413:
  %v6403 = load i64, ptr %slot1134, align 8
  %op6404 = sub i64 %v6403, 24
  store i64 %op6404, ptr %slot1144, align 8
  %v6405 = load i64, ptr %slot1134, align 8
  %p6406 = inttoptr i64 %v6405 to ptr
  %rgep6407 = getelementptr i8, ptr %p6406, i64 -24
  %ld6408 = load i64, ptr %rgep6407, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6408, ptr %slot1145, align 8
  %v6409 = load i64, ptr %slot1145, align 8
  %cmp6410 = icmp ne i64 %v6409, 0
  %cv6411 = zext i1 %cmp6410 to i32
  store i32 %cv6411, ptr %slot1146, align 8
  %v6412 = load i32, ptr %slot1146, align 8
  %cv6413 = zext i32 %v6412 to i64
  %cond6414 = icmp ne i64 %cv6413, 0
  br i1 %cond6414, label %bb_rcgdec1413, label %bb_rcgslow1413
bb_rcgslow1413:
  %v6415 = load i64, ptr %slot1133, align 8
  %v6416 = load i64, ptr %slot1132, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6415, i64 %v6416) nomerge, !dbg !174
  br label %bb_rcgdone1413
bb_rcgdec1413:
  %v6417 = load i64, ptr %slot1142, align 8
  %v6418 = load i64, ptr %slot1134, align 8
  %p6419 = inttoptr i64 %v6418 to ptr
  %rgep6420 = getelementptr i8, ptr %p6419, i64 -32
  store i64 %v6417, ptr %rgep6420, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1413
bb_rcgclear1413:
  %v6421 = load i64, ptr %slot1132, align 8
  %p6422 = inttoptr i64 %v6421 to ptr
  store i64 0, ptr %p6422, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1413
bb_rcgdone1413:
  %v6423 = load i64, ptr %slot1128, align 8
  %p6424 = inttoptr i64 %v6423 to ptr
  store i64 0, ptr %p6424, align 8, !alias.scope !3, !noalias !4
  %v6425 = load i64, ptr %slot1128, align 8
  %p6427 = inttoptr i64 %v6425 to ptr
  %gep6428 = getelementptr i8, ptr %p6427, i64 8
  %op6426 = ptrtoint ptr %gep6428 to i64
  store i64 %op6426, ptr %slot1147, align 8
  %v6429 = load i64, ptr %slot1147, align 8
  %p6430 = inttoptr i64 %v6429 to ptr
  store i64 0, ptr %p6430, align 8, !alias.scope !3, !noalias !4
  %v6431 = load i64, ptr %slot1128, align 8
  %p6433 = inttoptr i64 %v6431 to ptr
  %gep6434 = getelementptr i8, ptr %p6433, i64 16
  %op6432 = ptrtoint ptr %gep6434 to i64
  store i64 %op6432, ptr %slot1148, align 8
  %v6435 = load i64, ptr %slot1148, align 8
  %p6436 = inttoptr i64 %v6435 to ptr
  store i64 0, ptr %p6436, align 8, !alias.scope !3, !noalias !4
  %v6437 = load i64, ptr %slot1128, align 8
  %p6439 = inttoptr i64 %v6437 to ptr
  %gep6440 = getelementptr i8, ptr %p6439, i64 24
  %op6438 = ptrtoint ptr %gep6440 to i64
  store i64 %op6438, ptr %slot1149, align 8
  %v6441 = load i64, ptr %slot1149, align 8
  %p6442 = inttoptr i64 %v6441 to ptr
  store i64 0, ptr %p6442, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1395
bb_rcslotdone1395:
  %v6443 = load i64, ptr %slot42, align 8
  store i64 %v6443, ptr %slot1150, align 8
  %v6444 = load i64, ptr %slot29, align 8
  store i64 %v6444, ptr %slot1151, align 8
  %v6445 = load i64, ptr %slot1151, align 8
  %v6446 = load i64, ptr %slot1150, align 8
  %p6447 = inttoptr i64 %v6445 to ptr
  %p6448 = inttoptr i64 %v6446 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6448, ptr %p6447, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v6449 = load i64, ptr %slot23, align 8
  %p6450 = inttoptr i64 %v6449 to ptr
  store i32 0, ptr %p6450, align 4, !alias.scope !3, !noalias !4
  %v6451 = load i64, ptr %slot18, align 8
  %p6452 = inttoptr i64 %v6451 to ptr
  store i32 2, ptr %p6452, align 4, !alias.scope !3, !noalias !4
  %v6453 = load i64, ptr %slot24, align 8
  %p6454 = inttoptr i64 %v6453 to ptr
  %ld6455 = load i32, ptr %p6454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6455, ptr %slot1152, align 8
  %v6456 = load i32, ptr %slot1152, align 8
  %v6457 = load i64, ptr %slot18, align 8
  %p6458 = inttoptr i64 %v6457 to ptr
  store i32 %v6456, ptr %p6458, align 4, !alias.scope !3, !noalias !4
  %v6459 = load i64, ptr %slot17, align 8
  %p6460 = inttoptr i64 %v6459 to ptr
  store i32 1, ptr %p6460, align 4, !alias.scope !3, !noalias !4
  %v6461 = load i64, ptr %slot42, align 8
  %v6462 = load i64, ptr %slot44, align 8
  %p6463 = inttoptr i64 %v6462 to ptr
  store i64 %v6461, ptr %p6463, align 8, !alias.scope !3, !noalias !4
  %v6464 = load i64, ptr %slot44, align 8
  %p6465 = inttoptr i64 %v6464 to ptr
  %ld6466 = load i64, ptr %p6465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6466, ptr %slot1153, align 8
  %v6467 = load i64, ptr %slot1153, align 8
  %op6468 = add i64 %v6467, 16
  store i64 %op6468, ptr %slot1154, align 8
  %v6469 = load i64, ptr %slot1154, align 8
  %p6470 = inttoptr i64 %v6469 to ptr
  %ld6471 = load i64, ptr %p6470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6471, ptr %slot1155, align 8
  %v6472 = load i64, ptr %slot1155, align 8
  %v6473 = load i64, ptr %slot44, align 8
  %p6474 = inttoptr i64 %v6473 to ptr
  store i64 %v6472, ptr %p6474, align 8, !alias.scope !3, !noalias !4
  %v6475 = load i64, ptr %slot19, align 8
  %p6476 = inttoptr i64 %v6475 to ptr
  %ld6477 = load i32, ptr %p6476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6477, ptr %slot1156, align 8
  %v6478 = load i32, ptr %slot1156, align 8
  %cv6479 = zext i32 %v6478 to i64
  %cond6480 = icmp ne i64 %cv6479, 0
  br i1 %cond6480, label %bb_rcslotdrop1432, label %bb_rcslotdone1432
bb_rcslotdrop1432:
  %v6481 = load i64, ptr %slot19, align 8
  %p6482 = inttoptr i64 %v6481 to ptr
  store i32 0, ptr %p6482, align 4, !alias.scope !3, !noalias !4
  %v6483 = load i64, ptr %slot25, align 8
  store i64 %v6483, ptr %slot1157, align 8
  %v6484 = load i64, ptr %slot20, align 8
  %p6485 = inttoptr i64 %v6484 to ptr
  %ld6486 = load i32, ptr %p6485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6486, ptr %slot1158, align 8
  %v6487 = load i32, ptr %slot1158, align 8
  %op6488 = and i32 %v6487, 28
  store i32 %op6488, ptr %slot1159, align 8
  %v6489 = load i32, ptr %slot1159, align 8
  %cv6490 = zext i32 %v6489 to i64
  %cond6491 = icmp ne i64 %cv6490, 0
  br i1 %cond6491, label %bb_rcslotrole1432, label %bb_rcslotowner1432
bb_rcslotrole1432:
  %v6492 = load i64, ptr %slot52, align 8
  store i64 %v6492, ptr %slot1160, align 8
  %v6493 = load i64, ptr %slot1160, align 8
  %v6494 = load i64, ptr %slot1157, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6493, i64 %v6494) nomerge, !dbg !176
  br label %bb_rcslotdone1432
bb_rcslotowner1432:
  %v6495 = load i64, ptr %slot52, align 8
  store i64 %v6495, ptr %slot1161, align 8
  %v6496 = load i64, ptr %slot1161, align 8
  %v6497 = load i64, ptr %slot1157, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6496, i64 %v6497) nomerge, !dbg !176
  br label %bb_rcslotdone1432
bb_rcslotdone1432:
  %v6498 = load i64, ptr %slot42, align 8
  %v6499 = load i64, ptr %slot45, align 8
  %p6500 = inttoptr i64 %v6499 to ptr
  store i64 %v6498, ptr %p6500, align 8, !alias.scope !3, !noalias !4
  %v6501 = load i64, ptr %slot45, align 8
  %p6502 = inttoptr i64 %v6501 to ptr
  %ld6503 = load i64, ptr %p6502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6503, ptr %slot1162, align 8
  %v6504 = load i64, ptr %slot1162, align 8
  %op6505 = add i64 %v6504, 0
  store i64 %op6505, ptr %slot1163, align 8
  %v6506 = load i64, ptr %slot1163, align 8
  %p6507 = inttoptr i64 %v6506 to ptr
  %ld6508 = load i64, ptr %p6507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6508, ptr %slot1164, align 8
  %v6509 = load i64, ptr %slot1164, align 8
  %v6510 = load i64, ptr %slot45, align 8
  %p6511 = inttoptr i64 %v6510 to ptr
  store i64 %v6509, ptr %p6511, align 8, !alias.scope !3, !noalias !4
  %v6512 = load i64, ptr %slot45, align 8
  %p6513 = inttoptr i64 %v6512 to ptr
  %ld6514 = load i64, ptr %p6513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6514, ptr %slot1165, align 8
  %v6515 = load i64, ptr %slot1165, align 8
  %v6516 = load i64, ptr %slot28, align 8
  %p6517 = inttoptr i64 %v6516 to ptr
  store i64 %v6515, ptr %p6517, align 8, !alias.scope !3, !noalias !4
  %v6518 = load i64, ptr %slot28, align 8
  store i64 %v6518, ptr %slot1166, align 8
  %v6519 = load i64, ptr %slot29, align 8
  store i64 %v6519, ptr %slot1167, align 8
  %v6520 = load i64, ptr %slot1166, align 8
  %p6521 = inttoptr i64 %v6520 to ptr
  %ld6522 = load i64, ptr %p6521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6522, ptr %slot1168, align 8
  %v6523 = load i64, ptr %slot1168, align 8
  %cmp6524 = icmp ne i64 %v6523, 0
  %cv6525 = zext i1 %cmp6524 to i32
  store i32 %cv6525, ptr %slot1169, align 8
  %v6526 = load i32, ptr %slot1169, align 8
  %cv6527 = zext i32 %v6526 to i64
  %cond6528 = icmp ne i64 %cv6527, 0
  br i1 %cond6528, label %bb_rcgnn1446, label %bb_rcgstore1446
bb_rcgnn1446:
  %v6529 = load i64, ptr %slot1168, align 8
  %op6530 = sub i64 %v6529, 16
  store i64 %op6530, ptr %slot1170, align 8
  %v6531 = load i64, ptr %slot1168, align 8
  %p6532 = inttoptr i64 %v6531 to ptr
  %rgep6533 = getelementptr i8, ptr %p6532, i64 -16
  %ld6534 = load i64, ptr %rgep6533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6534, ptr %slot1171, align 8
  %v6535 = load i64, ptr %slot1171, align 8
  %op6536 = and i64 %v6535, 4611686018427387906
  store i64 %op6536, ptr %slot1172, align 8
  %v6537 = load i64, ptr %slot1172, align 8
  %cmp6538 = icmp ne i64 %v6537, 0
  %cv6539 = zext i1 %cmp6538 to i32
  store i32 %cv6539, ptr %slot1173, align 8
  %v6540 = load i32, ptr %slot1173, align 8
  %cv6541 = zext i32 %v6540 to i64
  %cond6542 = icmp ne i64 %cv6541, 0
  br i1 %cond6542, label %bb_rcgstore1446, label %bb_rcginc1446
bb_rcginc1446:
  %v6543 = load i64, ptr %slot1168, align 8
  %op6544 = sub i64 %v6543, 24
  store i64 %op6544, ptr %slot1174, align 8
  %v6545 = load i64, ptr %slot1168, align 8
  %p6546 = inttoptr i64 %v6545 to ptr
  %rgep6547 = getelementptr i8, ptr %p6546, i64 -24
  %ld6548 = load i64, ptr %rgep6547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6548, ptr %slot1175, align 8
  %v6549 = load i64, ptr %slot1175, align 8
  %op6550 = add i64 %v6549, 1
  store i64 %op6550, ptr %slot1176, align 8
  %v6551 = load i64, ptr %slot1176, align 8
  %cmp6552 = icmp eq i64 %v6551, 0
  %cv6553 = zext i1 %cmp6552 to i32
  store i32 %cv6553, ptr %slot1177, align 8
  %v6554 = load i32, ptr %slot1177, align 8
  %cv6555 = zext i32 %v6554 to i64
  %cond6556 = icmp ne i64 %cv6555, 0
  br i1 %cond6556, label %bb_rcglimit1446, label %bb_rcgcapacity1446
bb_rcglimit1446:
  %v6557 = load i64, ptr %slot1, align 8
  %p6558 = inttoptr i64 %v6557 to ptr
  %call6559 = call i32 @myl_qbe_rc_status(ptr %p6558, i32 2) nomerge, !dbg !178
  store i32 %call6559, ptr %slot1178, align 8
  br label %bb_failure
bb_rcgcapacity1446:
  %v6560 = load i64, ptr %slot1176, align 8
  %v6561 = load i64, ptr %slot1168, align 8
  %p6562 = inttoptr i64 %v6561 to ptr
  %rgep6563 = getelementptr i8, ptr %p6562, i64 -24
  store i64 %v6560, ptr %rgep6563, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1446
bb_rcgstore1446:
  %v6564 = load i64, ptr %slot1168, align 8
  %v6565 = load i64, ptr %slot1167, align 8
  %p6566 = inttoptr i64 %v6565 to ptr
  store i64 %v6564, ptr %p6566, align 8, !alias.scope !3, !noalias !4
  %v6567 = load i64, ptr %slot24, align 8
  %p6568 = inttoptr i64 %v6567 to ptr
  store i32 2, ptr %p6568, align 4, !alias.scope !3, !noalias !4
  %v6569 = load i64, ptr %slot24, align 8
  %p6570 = inttoptr i64 %v6569 to ptr
  store i32 16, ptr %p6570, align 4, !alias.scope !3, !noalias !4
  %v6571 = load i64, ptr %slot23, align 8
  %p6572 = inttoptr i64 %v6571 to ptr
  store i32 1, ptr %p6572, align 4, !alias.scope !3, !noalias !4
  %v6573 = load i64, ptr %slot21, align 8
  %p6574 = inttoptr i64 %v6573 to ptr
  %ld6575 = load i32, ptr %p6574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6575, ptr %slot1179, align 8
  %v6576 = load i32, ptr %slot1179, align 8
  %cv6577 = zext i32 %v6576 to i64
  %cond6578 = icmp ne i64 %cv6577, 0
  br i1 %cond6578, label %bb_rcslotdrop1462, label %bb_rcslotdone1462
bb_rcslotdrop1462:
  %v6579 = load i64, ptr %slot21, align 8
  %p6580 = inttoptr i64 %v6579 to ptr
  store i32 0, ptr %p6580, align 4, !alias.scope !3, !noalias !4
  %v6581 = load i64, ptr %slot26, align 8
  store i64 %v6581, ptr %slot1180, align 8
  %v6582 = load i64, ptr %slot22, align 8
  %p6583 = inttoptr i64 %v6582 to ptr
  %ld6584 = load i32, ptr %p6583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6584, ptr %slot1181, align 8
  %v6585 = load i32, ptr %slot1181, align 8
  %op6586 = and i32 %v6585, 28
  store i32 %op6586, ptr %slot1182, align 8
  %v6587 = load i32, ptr %slot1182, align 8
  %cv6588 = zext i32 %v6587 to i64
  %cond6589 = icmp ne i64 %cv6588, 0
  br i1 %cond6589, label %bb_rcslotrole1462, label %bb_rcslotowner1462
bb_rcslotrole1462:
  %v6590 = load i64, ptr %slot52, align 8
  store i64 %v6590, ptr %slot1183, align 8
  %v6591 = load i64, ptr %slot1183, align 8
  %v6592 = load i64, ptr %slot1180, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6591, i64 %v6592) nomerge, !dbg !178
  br label %bb_rcslotdone1462
bb_rcslotowner1462:
  %v6593 = load i64, ptr %slot52, align 8
  store i64 %v6593, ptr %slot1184, align 8
  %v6594 = load i64, ptr %slot1184, align 8
  %v6595 = load i64, ptr %slot1180, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6594, i64 %v6595) nomerge, !dbg !178
  br label %bb_rcslotdone1462
bb_rcslotdone1462:
  %v6596 = load i64, ptr %slot26, align 8
  store i64 %v6596, ptr %slot1185, align 8
  %v6597 = load i64, ptr %slot29, align 8
  store i64 %v6597, ptr %slot1186, align 8
  %v6598 = load i64, ptr %slot1186, align 8
  %v6599 = load i64, ptr %slot1185, align 8
  %p6600 = inttoptr i64 %v6598 to ptr
  %p6601 = inttoptr i64 %v6599 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6601, ptr %p6600, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6602 = load i64, ptr %slot22, align 8
  %p6603 = inttoptr i64 %v6602 to ptr
  store i32 2, ptr %p6603, align 4, !alias.scope !3, !noalias !4
  %v6604 = load i64, ptr %slot24, align 8
  %p6605 = inttoptr i64 %v6604 to ptr
  %ld6606 = load i32, ptr %p6605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6606, ptr %slot1187, align 8
  %v6607 = load i32, ptr %slot1187, align 8
  %v6608 = load i64, ptr %slot22, align 8
  %p6609 = inttoptr i64 %v6608 to ptr
  store i32 %v6607, ptr %p6609, align 4, !alias.scope !3, !noalias !4
  %v6610 = load i64, ptr %slot23, align 8
  %p6611 = inttoptr i64 %v6610 to ptr
  store i32 0, ptr %p6611, align 4, !alias.scope !3, !noalias !4
  %v6612 = load i64, ptr %slot21, align 8
  %p6613 = inttoptr i64 %v6612 to ptr
  store i32 1, ptr %p6613, align 4, !alias.scope !3, !noalias !4
  %v6614 = load i64, ptr %slot1185, align 8
  %p6615 = inttoptr i64 %v6614 to ptr
  %ld6616 = load i64, ptr %p6615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6616, ptr %slot1188, align 8
  %v6617 = load i64, ptr %slot1188, align 8
  %v6618 = load i64, ptr %slot45, align 8
  %p6619 = inttoptr i64 %v6618 to ptr
  store i64 %v6617, ptr %p6619, align 8, !alias.scope !3, !noalias !4
  %v6620 = load i64, ptr %slot45, align 8
  %p6621 = inttoptr i64 %v6620 to ptr
  %ld6622 = load i64, ptr %p6621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6622, ptr %slot1189, align 8
  %v6623 = load i64, ptr %slot1189, align 8
  %p6624 = inttoptr i64 %v6623 to ptr
  %ld6625 = load i64, ptr %p6624, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6625, ptr %slot1190, align 8
  %v6626 = load i64, ptr %slot1190, align 8
  %v6627 = load i64, ptr %slot45, align 8
  %p6628 = inttoptr i64 %v6627 to ptr
  store i64 %v6626, ptr %p6628, align 8, !alias.scope !3, !noalias !4
  %v6629 = load i64, ptr %slot21, align 8
  %p6630 = inttoptr i64 %v6629 to ptr
  %ld6631 = load i32, ptr %p6630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6631, ptr %slot1191, align 8
  %v6632 = load i32, ptr %slot1191, align 8
  %cv6633 = zext i32 %v6632 to i64
  %cond6634 = icmp ne i64 %cv6633, 0
  br i1 %cond6634, label %bb_rcslotdrop1482, label %bb_rcslotdone1482
bb_rcslotdrop1482:
  %v6635 = load i64, ptr %slot21, align 8
  %p6636 = inttoptr i64 %v6635 to ptr
  store i32 0, ptr %p6636, align 4, !alias.scope !3, !noalias !4
  %v6637 = load i64, ptr %slot26, align 8
  store i64 %v6637, ptr %slot1192, align 8
  %v6638 = load i64, ptr %slot22, align 8
  %p6639 = inttoptr i64 %v6638 to ptr
  %ld6640 = load i32, ptr %p6639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6640, ptr %slot1193, align 8
  %v6641 = load i32, ptr %slot1193, align 8
  %op6642 = and i32 %v6641, 28
  store i32 %op6642, ptr %slot1194, align 8
  %v6643 = load i32, ptr %slot1194, align 8
  %cv6644 = zext i32 %v6643 to i64
  %cond6645 = icmp ne i64 %cv6644, 0
  br i1 %cond6645, label %bb_rcslotrole1482, label %bb_rcslotowner1482
bb_rcslotrole1482:
  %v6646 = load i64, ptr %slot52, align 8
  store i64 %v6646, ptr %slot1195, align 8
  %v6647 = load i64, ptr %slot1192, align 8
  %p6648 = inttoptr i64 %v6647 to ptr
  %ld6649 = load i64, ptr %p6648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6649, ptr %slot1196, align 8
  %v6650 = load i64, ptr %slot1196, align 8
  %cmp6651 = icmp ne i64 %v6650, 0
  %cv6652 = zext i1 %cmp6651 to i32
  store i32 %cv6652, ptr %slot1197, align 8
  %v6653 = load i32, ptr %slot1197, align 8
  %cv6654 = zext i32 %v6653 to i64
  %cond6655 = icmp ne i64 %cv6654, 0
  br i1 %cond6655, label %bb_rcgnn1498, label %bb_rcgdone1498
bb_rcgnn1498:
  %v6656 = load i64, ptr %slot1196, align 8
  %op6657 = sub i64 %v6656, 16
  store i64 %op6657, ptr %slot1198, align 8
  %v6658 = load i64, ptr %slot1196, align 8
  %p6659 = inttoptr i64 %v6658 to ptr
  %rgep6660 = getelementptr i8, ptr %p6659, i64 -16
  %ld6661 = load i64, ptr %rgep6660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6661, ptr %slot1199, align 8
  %v6662 = load i64, ptr %slot1199, align 8
  %op6663 = and i64 %v6662, 4611686018427387906
  store i64 %op6663, ptr %slot1200, align 8
  %v6664 = load i64, ptr %slot1200, align 8
  %cmp6665 = icmp ne i64 %v6664, 0
  %cv6666 = zext i1 %cmp6665 to i32
  store i32 %cv6666, ptr %slot1201, align 8
  %v6667 = load i32, ptr %slot1201, align 8
  %cv6668 = zext i32 %v6667 to i64
  %cond6669 = icmp ne i64 %cv6668, 0
  br i1 %cond6669, label %bb_rcgclear1498, label %bb_rcgcounted1498
bb_rcgcounted1498:
  %v6670 = load i64, ptr %slot1196, align 8
  %op6671 = sub i64 %v6670, 24
  store i64 %op6671, ptr %slot1202, align 8
  %v6672 = load i64, ptr %slot1196, align 8
  %p6673 = inttoptr i64 %v6672 to ptr
  %rgep6674 = getelementptr i8, ptr %p6673, i64 -24
  %ld6675 = load i64, ptr %rgep6674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6675, ptr %slot1203, align 8
  %v6676 = load i64, ptr %slot1203, align 8
  %op6677 = sub i64 %v6676, 1
  store i64 %op6677, ptr %slot1204, align 8
  %v6678 = load i64, ptr %slot1204, align 8
  %cmp6679 = icmp eq i64 %v6678, 0
  %cv6680 = zext i1 %cmp6679 to i32
  store i32 %cv6680, ptr %slot1205, align 8
  %v6681 = load i32, ptr %slot1205, align 8
  %cv6682 = zext i32 %v6681 to i64
  %cond6683 = icmp ne i64 %cv6682, 0
  br i1 %cond6683, label %bb_rcglast1498, label %bb_rcgdec1498
bb_rcglast1498:
  %v6684 = load i64, ptr %slot1196, align 8
  %op6685 = sub i64 %v6684, 32
  store i64 %op6685, ptr %slot1206, align 8
  %v6686 = load i64, ptr %slot1196, align 8
  %p6687 = inttoptr i64 %v6686 to ptr
  %rgep6688 = getelementptr i8, ptr %p6687, i64 -32
  %ld6689 = load i64, ptr %rgep6688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6689, ptr %slot1207, align 8
  %v6690 = load i64, ptr %slot1207, align 8
  %cmp6691 = icmp ne i64 %v6690, 0
  %cv6692 = zext i1 %cmp6691 to i32
  store i32 %cv6692, ptr %slot1208, align 8
  %v6693 = load i32, ptr %slot1208, align 8
  %cv6694 = zext i32 %v6693 to i64
  %cond6695 = icmp ne i64 %cv6694, 0
  br i1 %cond6695, label %bb_rcgdec1498, label %bb_rcgslow1498
bb_rcgslow1498:
  %v6696 = load i64, ptr %slot1195, align 8
  %v6697 = load i64, ptr %slot1192, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6696, i64 %v6697) nomerge, !dbg !180
  br label %bb_rcgdone1498
bb_rcgdec1498:
  %v6698 = load i64, ptr %slot1204, align 8
  %v6699 = load i64, ptr %slot1196, align 8
  %p6700 = inttoptr i64 %v6699 to ptr
  %rgep6701 = getelementptr i8, ptr %p6700, i64 -24
  store i64 %v6698, ptr %rgep6701, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1498
bb_rcgclear1498:
  %v6702 = load i64, ptr %slot1192, align 8
  %p6703 = inttoptr i64 %v6702 to ptr
  store i64 0, ptr %p6703, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1498
bb_rcgdone1498:
  br label %bb_rcslotdone1482
bb_rcslotowner1482:
  %v6704 = load i64, ptr %slot52, align 8
  store i64 %v6704, ptr %slot1209, align 8
  %v6705 = load i64, ptr %slot1192, align 8
  %p6706 = inttoptr i64 %v6705 to ptr
  %ld6707 = load i64, ptr %p6706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6707, ptr %slot1210, align 8
  %v6708 = load i64, ptr %slot1210, align 8
  %cmp6709 = icmp ne i64 %v6708, 0
  %cv6710 = zext i1 %cmp6709 to i32
  store i32 %cv6710, ptr %slot1211, align 8
  %v6711 = load i32, ptr %slot1211, align 8
  %cv6712 = zext i32 %v6711 to i64
  %cond6713 = icmp ne i64 %cv6712, 0
  br i1 %cond6713, label %bb_rcgnn1513, label %bb_rcgdone1513
bb_rcgnn1513:
  %v6714 = load i64, ptr %slot1210, align 8
  %op6715 = sub i64 %v6714, 16
  store i64 %op6715, ptr %slot1212, align 8
  %v6716 = load i64, ptr %slot1210, align 8
  %p6717 = inttoptr i64 %v6716 to ptr
  %rgep6718 = getelementptr i8, ptr %p6717, i64 -16
  %ld6719 = load i64, ptr %rgep6718, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6719, ptr %slot1213, align 8
  %v6720 = load i64, ptr %slot1213, align 8
  %op6721 = and i64 %v6720, 4611686018427387906
  store i64 %op6721, ptr %slot1214, align 8
  %v6722 = load i64, ptr %slot1214, align 8
  %cmp6723 = icmp ne i64 %v6722, 0
  %cv6724 = zext i1 %cmp6723 to i32
  store i32 %cv6724, ptr %slot1215, align 8
  %v6725 = load i32, ptr %slot1215, align 8
  %cv6726 = zext i32 %v6725 to i64
  %cond6727 = icmp ne i64 %cv6726, 0
  br i1 %cond6727, label %bb_rcgclear1513, label %bb_rcgcounted1513
bb_rcgcounted1513:
  %v6728 = load i64, ptr %slot1210, align 8
  %op6729 = sub i64 %v6728, 32
  store i64 %op6729, ptr %slot1216, align 8
  %v6730 = load i64, ptr %slot1210, align 8
  %p6731 = inttoptr i64 %v6730 to ptr
  %rgep6732 = getelementptr i8, ptr %p6731, i64 -32
  %ld6733 = load i64, ptr %rgep6732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6733, ptr %slot1217, align 8
  %v6734 = load i64, ptr %slot1217, align 8
  %op6735 = sub i64 %v6734, 1
  store i64 %op6735, ptr %slot1218, align 8
  %v6736 = load i64, ptr %slot1218, align 8
  %cmp6737 = icmp eq i64 %v6736, 0
  %cv6738 = zext i1 %cmp6737 to i32
  store i32 %cv6738, ptr %slot1219, align 8
  %v6739 = load i32, ptr %slot1219, align 8
  %cv6740 = zext i32 %v6739 to i64
  %cond6741 = icmp ne i64 %cv6740, 0
  br i1 %cond6741, label %bb_rcglast1513, label %bb_rcgdec1513
bb_rcglast1513:
  %v6742 = load i64, ptr %slot1210, align 8
  %op6743 = sub i64 %v6742, 24
  store i64 %op6743, ptr %slot1220, align 8
  %v6744 = load i64, ptr %slot1210, align 8
  %p6745 = inttoptr i64 %v6744 to ptr
  %rgep6746 = getelementptr i8, ptr %p6745, i64 -24
  %ld6747 = load i64, ptr %rgep6746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6747, ptr %slot1221, align 8
  %v6748 = load i64, ptr %slot1221, align 8
  %cmp6749 = icmp ne i64 %v6748, 0
  %cv6750 = zext i1 %cmp6749 to i32
  store i32 %cv6750, ptr %slot1222, align 8
  %v6751 = load i32, ptr %slot1222, align 8
  %cv6752 = zext i32 %v6751 to i64
  %cond6753 = icmp ne i64 %cv6752, 0
  br i1 %cond6753, label %bb_rcgdec1513, label %bb_rcgslow1513
bb_rcgslow1513:
  %v6754 = load i64, ptr %slot1209, align 8
  %v6755 = load i64, ptr %slot1192, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6754, i64 %v6755) nomerge, !dbg !180
  br label %bb_rcgdone1513
bb_rcgdec1513:
  %v6756 = load i64, ptr %slot1218, align 8
  %v6757 = load i64, ptr %slot1210, align 8
  %p6758 = inttoptr i64 %v6757 to ptr
  %rgep6759 = getelementptr i8, ptr %p6758, i64 -32
  store i64 %v6756, ptr %rgep6759, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1513
bb_rcgclear1513:
  %v6760 = load i64, ptr %slot1192, align 8
  %p6761 = inttoptr i64 %v6760 to ptr
  store i64 0, ptr %p6761, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1513
bb_rcgdone1513:
  br label %bb_rcslotdone1482
bb_rcslotdone1482:
  %v6762 = load i64, ptr %slot45, align 8
  %p6763 = inttoptr i64 %v6762 to ptr
  %ld6764 = load i64, ptr %p6763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6764, ptr %slot1223, align 8
  %v6765 = load i64, ptr %slot44, align 8
  %p6766 = inttoptr i64 %v6765 to ptr
  %ld6767 = load i64, ptr %p6766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6767, ptr %slot1224, align 8
  %v6768 = load i64, ptr %slot1224, align 8
  %v6769 = load i64, ptr %slot1223, align 8
  %cmp6770 = icmp sge i64 %v6768, %v6769
  %cv6771 = zext i1 %cmp6770 to i64
  store i64 %cv6771, ptr %slot1225, align 8
  %v6772 = load i64, ptr %slot1225, align 8
  %v6773 = load i64, ptr %slot44, align 8
  %p6774 = inttoptr i64 %v6773 to ptr
  store i64 %v6772, ptr %p6774, align 8, !alias.scope !3, !noalias !4
  br label %bb_i135
bb_i135:
  %v6775 = load i64, ptr %slot44, align 8
  %p6776 = inttoptr i64 %v6775 to ptr
  %ld6777 = load i64, ptr %p6776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6777, ptr %slot1226, align 8
  %v6778 = load i64, ptr %slot1226, align 8
  %cond6779 = icmp ne i64 %v6778, 0
  br i1 %cond6779, label %bb_next1521, label %bb_i138
bb_next1521:
  %v6780 = load i64, ptr %slot44, align 8
  %p6781 = inttoptr i64 %v6780 to ptr
  store i64 0, ptr %p6781, align 8, !alias.scope !3, !noalias !4
  br label %bb_i145
bb_i138:
  %v6782 = load i64, ptr %slot41, align 8
  %v6783 = load i64, ptr %slot44, align 8
  %p6784 = inttoptr i64 %v6783 to ptr
  store i64 %v6782, ptr %p6784, align 8, !alias.scope !3, !noalias !4
  %v6785 = load i64, ptr %slot44, align 8
  %p6786 = inttoptr i64 %v6785 to ptr
  %ld6787 = load i64, ptr %p6786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6787, ptr %slot1227, align 8
  %v6788 = load i64, ptr %slot1227, align 8
  %op6789 = add i64 %v6788, 0
  store i64 %op6789, ptr %slot1228, align 8
  %v6790 = load i64, ptr %slot1228, align 8
  %p6791 = inttoptr i64 %v6790 to ptr
  %ld6792 = load i64, ptr %p6791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6792, ptr %slot1229, align 8
  %v6793 = load i64, ptr %slot1229, align 8
  %v6794 = load i64, ptr %slot44, align 8
  %p6795 = inttoptr i64 %v6794 to ptr
  store i64 %v6793, ptr %p6795, align 8, !alias.scope !3, !noalias !4
  %v6796 = load i64, ptr %slot44, align 8
  %p6797 = inttoptr i64 %v6796 to ptr
  %ld6798 = load i64, ptr %p6797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6798, ptr %slot1230, align 8
  %v6799 = load i64, ptr %slot1230, align 8
  %v6800 = load i64, ptr %slot27, align 8
  %p6801 = inttoptr i64 %v6800 to ptr
  store i64 %v6799, ptr %p6801, align 8, !alias.scope !3, !noalias !4
  %v6802 = load i64, ptr %slot27, align 8
  store i64 %v6802, ptr %slot1231, align 8
  %v6803 = load i64, ptr %slot29, align 8
  store i64 %v6803, ptr %slot1232, align 8
  %v6804 = load i64, ptr %slot1231, align 8
  %p6805 = inttoptr i64 %v6804 to ptr
  %ld6806 = load i64, ptr %p6805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6806, ptr %slot1233, align 8
  %v6807 = load i64, ptr %slot1233, align 8
  %cmp6808 = icmp ne i64 %v6807, 0
  %cv6809 = zext i1 %cmp6808 to i32
  store i32 %cv6809, ptr %slot1234, align 8
  %v6810 = load i32, ptr %slot1234, align 8
  %cv6811 = zext i32 %v6810 to i64
  %cond6812 = icmp ne i64 %cv6811, 0
  br i1 %cond6812, label %bb_rcgnn1528, label %bb_rcgstore1528
bb_rcgnn1528:
  %v6813 = load i64, ptr %slot1233, align 8
  %op6814 = sub i64 %v6813, 16
  store i64 %op6814, ptr %slot1235, align 8
  %v6815 = load i64, ptr %slot1233, align 8
  %p6816 = inttoptr i64 %v6815 to ptr
  %rgep6817 = getelementptr i8, ptr %p6816, i64 -16
  %ld6818 = load i64, ptr %rgep6817, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6818, ptr %slot1236, align 8
  %v6819 = load i64, ptr %slot1236, align 8
  %op6820 = and i64 %v6819, 4611686018427387906
  store i64 %op6820, ptr %slot1237, align 8
  %v6821 = load i64, ptr %slot1237, align 8
  %cmp6822 = icmp ne i64 %v6821, 0
  %cv6823 = zext i1 %cmp6822 to i32
  store i32 %cv6823, ptr %slot1238, align 8
  %v6824 = load i32, ptr %slot1238, align 8
  %cv6825 = zext i32 %v6824 to i64
  %cond6826 = icmp ne i64 %cv6825, 0
  br i1 %cond6826, label %bb_rcgstore1528, label %bb_rcginc1528
bb_rcginc1528:
  %v6827 = load i64, ptr %slot1233, align 8
  %op6828 = sub i64 %v6827, 24
  store i64 %op6828, ptr %slot1239, align 8
  %v6829 = load i64, ptr %slot1233, align 8
  %p6830 = inttoptr i64 %v6829 to ptr
  %rgep6831 = getelementptr i8, ptr %p6830, i64 -24
  %ld6832 = load i64, ptr %rgep6831, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6832, ptr %slot1240, align 8
  %v6833 = load i64, ptr %slot1240, align 8
  %op6834 = add i64 %v6833, 1
  store i64 %op6834, ptr %slot1241, align 8
  %v6835 = load i64, ptr %slot1241, align 8
  %cmp6836 = icmp eq i64 %v6835, 0
  %cv6837 = zext i1 %cmp6836 to i32
  store i32 %cv6837, ptr %slot1242, align 8
  %v6838 = load i32, ptr %slot1242, align 8
  %cv6839 = zext i32 %v6838 to i64
  %cond6840 = icmp ne i64 %cv6839, 0
  br i1 %cond6840, label %bb_rcglimit1528, label %bb_rcgcapacity1528
bb_rcglimit1528:
  %v6841 = load i64, ptr %slot1, align 8
  %p6842 = inttoptr i64 %v6841 to ptr
  %call6843 = call i32 @myl_qbe_rc_status(ptr %p6842, i32 2) nomerge, !dbg !182
  store i32 %call6843, ptr %slot1243, align 8
  br label %bb_failure
bb_rcgcapacity1528:
  %v6844 = load i64, ptr %slot1241, align 8
  %v6845 = load i64, ptr %slot1233, align 8
  %p6846 = inttoptr i64 %v6845 to ptr
  %rgep6847 = getelementptr i8, ptr %p6846, i64 -24
  store i64 %v6844, ptr %rgep6847, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1528
bb_rcgstore1528:
  %v6848 = load i64, ptr %slot1233, align 8
  %v6849 = load i64, ptr %slot1232, align 8
  %p6850 = inttoptr i64 %v6849 to ptr
  store i64 %v6848, ptr %p6850, align 8, !alias.scope !3, !noalias !4
  %v6851 = load i64, ptr %slot24, align 8
  %p6852 = inttoptr i64 %v6851 to ptr
  store i32 2, ptr %p6852, align 4, !alias.scope !3, !noalias !4
  %v6853 = load i64, ptr %slot24, align 8
  %p6854 = inttoptr i64 %v6853 to ptr
  store i32 16, ptr %p6854, align 4, !alias.scope !3, !noalias !4
  %v6855 = load i64, ptr %slot23, align 8
  %p6856 = inttoptr i64 %v6855 to ptr
  store i32 1, ptr %p6856, align 4, !alias.scope !3, !noalias !4
  %v6857 = load i64, ptr %slot19, align 8
  %p6858 = inttoptr i64 %v6857 to ptr
  %ld6859 = load i32, ptr %p6858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6859, ptr %slot1244, align 8
  %v6860 = load i32, ptr %slot1244, align 8
  %cv6861 = zext i32 %v6860 to i64
  %cond6862 = icmp ne i64 %cv6861, 0
  br i1 %cond6862, label %bb_rcslotdrop1544, label %bb_rcslotdone1544
bb_rcslotdrop1544:
  %v6863 = load i64, ptr %slot19, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  store i32 0, ptr %p6864, align 4, !alias.scope !3, !noalias !4
  %v6865 = load i64, ptr %slot25, align 8
  store i64 %v6865, ptr %slot1245, align 8
  %v6866 = load i64, ptr %slot20, align 8
  %p6867 = inttoptr i64 %v6866 to ptr
  %ld6868 = load i32, ptr %p6867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6868, ptr %slot1246, align 8
  %v6869 = load i32, ptr %slot1246, align 8
  %op6870 = and i32 %v6869, 28
  store i32 %op6870, ptr %slot1247, align 8
  %v6871 = load i32, ptr %slot1247, align 8
  %cv6872 = zext i32 %v6871 to i64
  %cond6873 = icmp ne i64 %cv6872, 0
  br i1 %cond6873, label %bb_rcslotrole1544, label %bb_rcslotowner1544
bb_rcslotrole1544:
  %v6874 = load i64, ptr %slot52, align 8
  store i64 %v6874, ptr %slot1248, align 8
  %v6875 = load i64, ptr %slot1248, align 8
  %v6876 = load i64, ptr %slot1245, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6875, i64 %v6876) nomerge, !dbg !182
  br label %bb_rcslotdone1544
bb_rcslotowner1544:
  %v6877 = load i64, ptr %slot52, align 8
  store i64 %v6877, ptr %slot1249, align 8
  %v6878 = load i64, ptr %slot1249, align 8
  %v6879 = load i64, ptr %slot1245, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6878, i64 %v6879) nomerge, !dbg !182
  br label %bb_rcslotdone1544
bb_rcslotdone1544:
  %v6880 = load i64, ptr %slot25, align 8
  store i64 %v6880, ptr %slot1250, align 8
  %v6881 = load i64, ptr %slot29, align 8
  store i64 %v6881, ptr %slot1251, align 8
  %v6882 = load i64, ptr %slot1251, align 8
  %v6883 = load i64, ptr %slot1250, align 8
  %p6884 = inttoptr i64 %v6882 to ptr
  %p6885 = inttoptr i64 %v6883 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6885, ptr %p6884, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6886 = load i64, ptr %slot20, align 8
  %p6887 = inttoptr i64 %v6886 to ptr
  store i32 2, ptr %p6887, align 4, !alias.scope !3, !noalias !4
  %v6888 = load i64, ptr %slot24, align 8
  %p6889 = inttoptr i64 %v6888 to ptr
  %ld6890 = load i32, ptr %p6889, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6890, ptr %slot1252, align 8
  %v6891 = load i32, ptr %slot1252, align 8
  %v6892 = load i64, ptr %slot20, align 8
  %p6893 = inttoptr i64 %v6892 to ptr
  store i32 %v6891, ptr %p6893, align 4, !alias.scope !3, !noalias !4
  %v6894 = load i64, ptr %slot23, align 8
  %p6895 = inttoptr i64 %v6894 to ptr
  store i32 0, ptr %p6895, align 4, !alias.scope !3, !noalias !4
  %v6896 = load i64, ptr %slot19, align 8
  %p6897 = inttoptr i64 %v6896 to ptr
  store i32 1, ptr %p6897, align 4, !alias.scope !3, !noalias !4
  %v6898 = load i64, ptr %slot1250, align 8
  %p6899 = inttoptr i64 %v6898 to ptr
  %ld6900 = load i64, ptr %p6899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6900, ptr %slot1253, align 8
  %v6901 = load i64, ptr %slot1253, align 8
  %v6902 = load i64, ptr %slot44, align 8
  %p6903 = inttoptr i64 %v6902 to ptr
  store i64 %v6901, ptr %p6903, align 8, !alias.scope !3, !noalias !4
  %v6904 = load i64, ptr %slot41, align 8
  %v6905 = load i64, ptr %slot45, align 8
  %p6906 = inttoptr i64 %v6905 to ptr
  store i64 %v6904, ptr %p6906, align 8, !alias.scope !3, !noalias !4
  %v6907 = load i64, ptr %slot45, align 8
  %p6908 = inttoptr i64 %v6907 to ptr
  %ld6909 = load i64, ptr %p6908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6909, ptr %slot1254, align 8
  %v6910 = load i64, ptr %slot1254, align 8
  %op6911 = add i64 %v6910, 16
  store i64 %op6911, ptr %slot1255, align 8
  %v6912 = load i64, ptr %slot1255, align 8
  %p6913 = inttoptr i64 %v6912 to ptr
  %ld6914 = load i64, ptr %p6913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6914, ptr %slot1256, align 8
  %v6915 = load i64, ptr %slot1256, align 8
  %v6916 = load i64, ptr %slot45, align 8
  %p6917 = inttoptr i64 %v6916 to ptr
  store i64 %v6915, ptr %p6917, align 8, !alias.scope !3, !noalias !4
  %v6918 = load i64, ptr %slot21, align 8
  %p6919 = inttoptr i64 %v6918 to ptr
  %ld6920 = load i32, ptr %p6919, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6920, ptr %slot1257, align 8
  %v6921 = load i32, ptr %slot1257, align 8
  %cv6922 = zext i32 %v6921 to i64
  %cond6923 = icmp ne i64 %cv6922, 0
  br i1 %cond6923, label %bb_rcslotdrop1565, label %bb_rcslotdone1565
bb_rcslotdrop1565:
  %v6924 = load i64, ptr %slot21, align 8
  %p6925 = inttoptr i64 %v6924 to ptr
  store i32 0, ptr %p6925, align 4, !alias.scope !3, !noalias !4
  %v6926 = load i64, ptr %slot26, align 8
  store i64 %v6926, ptr %slot1258, align 8
  %v6927 = load i64, ptr %slot22, align 8
  %p6928 = inttoptr i64 %v6927 to ptr
  %ld6929 = load i32, ptr %p6928, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6929, ptr %slot1259, align 8
  %v6930 = load i32, ptr %slot1259, align 8
  %op6931 = and i32 %v6930, 28
  store i32 %op6931, ptr %slot1260, align 8
  %v6932 = load i32, ptr %slot1260, align 8
  %cv6933 = zext i32 %v6932 to i64
  %cond6934 = icmp ne i64 %cv6933, 0
  br i1 %cond6934, label %bb_rcslotrole1565, label %bb_rcslotowner1565
bb_rcslotrole1565:
  %v6935 = load i64, ptr %slot52, align 8
  store i64 %v6935, ptr %slot1261, align 8
  %v6936 = load i64, ptr %slot1261, align 8
  %v6937 = load i64, ptr %slot1258, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6936, i64 %v6937) nomerge, !dbg !184
  br label %bb_rcslotdone1565
bb_rcslotowner1565:
  %v6938 = load i64, ptr %slot52, align 8
  store i64 %v6938, ptr %slot1262, align 8
  %v6939 = load i64, ptr %slot1262, align 8
  %v6940 = load i64, ptr %slot1258, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6939, i64 %v6940) nomerge, !dbg !184
  br label %bb_rcslotdone1565
bb_rcslotdone1565:
  %v6941 = load i64, ptr %slot44, align 8
  %p6942 = inttoptr i64 %v6941 to ptr
  %ld6943 = load i64, ptr %p6942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6943, ptr %slot1263, align 8
  %v6944 = load i64, ptr %slot45, align 8
  %p6945 = inttoptr i64 %v6944 to ptr
  %ld6946 = load i64, ptr %p6945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6946, ptr %slot1264, align 8
  %v6947 = load i64, ptr %slot1263, align 8
  %p6948 = inttoptr i64 %v6947 to ptr
  %ld6949 = load i64, ptr %p6948, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6949, ptr %slot1265, align 8
  %v6950 = load i64, ptr %slot1264, align 8
  %op6951 = ashr i64 %v6950, 63
  store i64 %op6951, ptr %slot1266, align 8
  %v6952 = load i64, ptr %slot1266, align 8
  %v6953 = load i64, ptr %slot1265, align 8
  %op6954 = and i64 %v6952, %v6953
  store i64 %op6954, ptr %slot1267, align 8
  %v6955 = load i64, ptr %slot1264, align 8
  %v6956 = load i64, ptr %slot1267, align 8
  %op6957 = add i64 %v6955, %v6956
  store i64 %op6957, ptr %slot1268, align 8
  %v6958 = load i64, ptr %slot1268, align 8
  %v6959 = load i64, ptr %slot1265, align 8
  %cmp6960 = icmp ult i64 %v6958, %v6959
  %cv6961 = zext i1 %cmp6960 to i64
  store i64 %cv6961, ptr %slot1269, align 8
  %v6962 = load i64, ptr %slot1269, align 8
  %cond6963 = icmp ne i64 %v6962, 0
  br i1 %cond6963, label %bb_success1580, label %bb_failed1580
bb_failed1580:
  %v6964 = load i64, ptr %slot1, align 8
  %p6965 = inttoptr i64 %v6964 to ptr
  %v6966 = load i64, ptr %slot1264, align 8
  %v6967 = load i64, ptr %slot1265, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p6965, i64 %v6966, i64 %v6967) nomerge, !dbg !186
  unreachable
bb_success1580:
  %v6968 = load i64, ptr %slot1263, align 8
  %op6969 = add i64 %v6968, 32
  store i64 %op6969, ptr %slot1270, align 8
  %v6970 = load i64, ptr %slot1270, align 8
  %p6971 = inttoptr i64 %v6970 to ptr
  %ld6972 = load i64, ptr %p6971, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6972, ptr %slot1271, align 8
  %v6973 = load i64, ptr %slot1271, align 8
  %v6974 = load i64, ptr %slot1268, align 8
  %op6975 = add i64 %v6973, %v6974
  store i64 %op6975, ptr %slot1272, align 8
  %v6976 = load i64, ptr %slot1271, align 8
  %p6977 = inttoptr i64 %v6976 to ptr
  %v6978 = load i64, ptr %slot1268, align 8
  %egep6979 = getelementptr i8, ptr %p6977, i64 %v6978
  %ld6980 = load i8, ptr %egep6979, align 1, !alias.scope !12, !noalias !13
  %ext6981 = zext i8 %ld6980 to i64
  store i64 %ext6981, ptr %slot1273, align 8
  %v6982 = load i64, ptr %slot1273, align 8
  %v6983 = load i64, ptr %slot44, align 8
  %p6984 = inttoptr i64 %v6983 to ptr
  store i64 %v6982, ptr %p6984, align 8, !alias.scope !3, !noalias !4
  %v6985 = load i64, ptr %slot19, align 8
  %p6986 = inttoptr i64 %v6985 to ptr
  %ld6987 = load i32, ptr %p6986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6987, ptr %slot1274, align 8
  %v6988 = load i32, ptr %slot1274, align 8
  %cv6989 = zext i32 %v6988 to i64
  %cond6990 = icmp ne i64 %cv6989, 0
  br i1 %cond6990, label %bb_rcslotdrop1588, label %bb_rcslotdone1588
bb_rcslotdrop1588:
  %v6991 = load i64, ptr %slot19, align 8
  %p6992 = inttoptr i64 %v6991 to ptr
  store i32 0, ptr %p6992, align 4, !alias.scope !3, !noalias !4
  %v6993 = load i64, ptr %slot25, align 8
  store i64 %v6993, ptr %slot1275, align 8
  %v6994 = load i64, ptr %slot20, align 8
  %p6995 = inttoptr i64 %v6994 to ptr
  %ld6996 = load i32, ptr %p6995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6996, ptr %slot1276, align 8
  %v6997 = load i32, ptr %slot1276, align 8
  %op6998 = and i32 %v6997, 28
  store i32 %op6998, ptr %slot1277, align 8
  %v6999 = load i32, ptr %slot1277, align 8
  %cv7000 = zext i32 %v6999 to i64
  %cond7001 = icmp ne i64 %cv7000, 0
  br i1 %cond7001, label %bb_rcslotrole1588, label %bb_rcslotowner1588
bb_rcslotrole1588:
  %v7002 = load i64, ptr %slot52, align 8
  store i64 %v7002, ptr %slot1278, align 8
  %v7003 = load i64, ptr %slot1275, align 8
  %p7004 = inttoptr i64 %v7003 to ptr
  %ld7005 = load i64, ptr %p7004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7005, ptr %slot1279, align 8
  %v7006 = load i64, ptr %slot1279, align 8
  %cmp7007 = icmp ne i64 %v7006, 0
  %cv7008 = zext i1 %cmp7007 to i32
  store i32 %cv7008, ptr %slot1280, align 8
  %v7009 = load i32, ptr %slot1280, align 8
  %cv7010 = zext i32 %v7009 to i64
  %cond7011 = icmp ne i64 %cv7010, 0
  br i1 %cond7011, label %bb_rcgnn1604, label %bb_rcgdone1604
bb_rcgnn1604:
  %v7012 = load i64, ptr %slot1279, align 8
  %op7013 = sub i64 %v7012, 16
  store i64 %op7013, ptr %slot1281, align 8
  %v7014 = load i64, ptr %slot1279, align 8
  %p7015 = inttoptr i64 %v7014 to ptr
  %rgep7016 = getelementptr i8, ptr %p7015, i64 -16
  %ld7017 = load i64, ptr %rgep7016, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7017, ptr %slot1282, align 8
  %v7018 = load i64, ptr %slot1282, align 8
  %op7019 = and i64 %v7018, 4611686018427387906
  store i64 %op7019, ptr %slot1283, align 8
  %v7020 = load i64, ptr %slot1283, align 8
  %cmp7021 = icmp ne i64 %v7020, 0
  %cv7022 = zext i1 %cmp7021 to i32
  store i32 %cv7022, ptr %slot1284, align 8
  %v7023 = load i32, ptr %slot1284, align 8
  %cv7024 = zext i32 %v7023 to i64
  %cond7025 = icmp ne i64 %cv7024, 0
  br i1 %cond7025, label %bb_rcgclear1604, label %bb_rcgcounted1604
bb_rcgcounted1604:
  %v7026 = load i64, ptr %slot1279, align 8
  %op7027 = sub i64 %v7026, 24
  store i64 %op7027, ptr %slot1285, align 8
  %v7028 = load i64, ptr %slot1279, align 8
  %p7029 = inttoptr i64 %v7028 to ptr
  %rgep7030 = getelementptr i8, ptr %p7029, i64 -24
  %ld7031 = load i64, ptr %rgep7030, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7031, ptr %slot1286, align 8
  %v7032 = load i64, ptr %slot1286, align 8
  %op7033 = sub i64 %v7032, 1
  store i64 %op7033, ptr %slot1287, align 8
  %v7034 = load i64, ptr %slot1287, align 8
  %cmp7035 = icmp eq i64 %v7034, 0
  %cv7036 = zext i1 %cmp7035 to i32
  store i32 %cv7036, ptr %slot1288, align 8
  %v7037 = load i32, ptr %slot1288, align 8
  %cv7038 = zext i32 %v7037 to i64
  %cond7039 = icmp ne i64 %cv7038, 0
  br i1 %cond7039, label %bb_rcglast1604, label %bb_rcgdec1604
bb_rcglast1604:
  %v7040 = load i64, ptr %slot1279, align 8
  %op7041 = sub i64 %v7040, 32
  store i64 %op7041, ptr %slot1289, align 8
  %v7042 = load i64, ptr %slot1279, align 8
  %p7043 = inttoptr i64 %v7042 to ptr
  %rgep7044 = getelementptr i8, ptr %p7043, i64 -32
  %ld7045 = load i64, ptr %rgep7044, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7045, ptr %slot1290, align 8
  %v7046 = load i64, ptr %slot1290, align 8
  %cmp7047 = icmp ne i64 %v7046, 0
  %cv7048 = zext i1 %cmp7047 to i32
  store i32 %cv7048, ptr %slot1291, align 8
  %v7049 = load i32, ptr %slot1291, align 8
  %cv7050 = zext i32 %v7049 to i64
  %cond7051 = icmp ne i64 %cv7050, 0
  br i1 %cond7051, label %bb_rcgdec1604, label %bb_rcgslow1604
bb_rcgslow1604:
  %v7052 = load i64, ptr %slot1278, align 8
  %v7053 = load i64, ptr %slot1275, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7052, i64 %v7053) nomerge, !dbg !186
  br label %bb_rcgdone1604
bb_rcgdec1604:
  %v7054 = load i64, ptr %slot1287, align 8
  %v7055 = load i64, ptr %slot1279, align 8
  %p7056 = inttoptr i64 %v7055 to ptr
  %rgep7057 = getelementptr i8, ptr %p7056, i64 -24
  store i64 %v7054, ptr %rgep7057, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1604
bb_rcgclear1604:
  %v7058 = load i64, ptr %slot1275, align 8
  %p7059 = inttoptr i64 %v7058 to ptr
  store i64 0, ptr %p7059, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1604
bb_rcgdone1604:
  br label %bb_rcslotdone1588
bb_rcslotowner1588:
  %v7060 = load i64, ptr %slot52, align 8
  store i64 %v7060, ptr %slot1292, align 8
  %v7061 = load i64, ptr %slot1275, align 8
  %p7062 = inttoptr i64 %v7061 to ptr
  %ld7063 = load i64, ptr %p7062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7063, ptr %slot1293, align 8
  %v7064 = load i64, ptr %slot1293, align 8
  %cmp7065 = icmp ne i64 %v7064, 0
  %cv7066 = zext i1 %cmp7065 to i32
  store i32 %cv7066, ptr %slot1294, align 8
  %v7067 = load i32, ptr %slot1294, align 8
  %cv7068 = zext i32 %v7067 to i64
  %cond7069 = icmp ne i64 %cv7068, 0
  br i1 %cond7069, label %bb_rcgnn1619, label %bb_rcgdone1619
bb_rcgnn1619:
  %v7070 = load i64, ptr %slot1293, align 8
  %op7071 = sub i64 %v7070, 16
  store i64 %op7071, ptr %slot1295, align 8
  %v7072 = load i64, ptr %slot1293, align 8
  %p7073 = inttoptr i64 %v7072 to ptr
  %rgep7074 = getelementptr i8, ptr %p7073, i64 -16
  %ld7075 = load i64, ptr %rgep7074, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7075, ptr %slot1296, align 8
  %v7076 = load i64, ptr %slot1296, align 8
  %op7077 = and i64 %v7076, 4611686018427387906
  store i64 %op7077, ptr %slot1297, align 8
  %v7078 = load i64, ptr %slot1297, align 8
  %cmp7079 = icmp ne i64 %v7078, 0
  %cv7080 = zext i1 %cmp7079 to i32
  store i32 %cv7080, ptr %slot1298, align 8
  %v7081 = load i32, ptr %slot1298, align 8
  %cv7082 = zext i32 %v7081 to i64
  %cond7083 = icmp ne i64 %cv7082, 0
  br i1 %cond7083, label %bb_rcgclear1619, label %bb_rcgcounted1619
bb_rcgcounted1619:
  %v7084 = load i64, ptr %slot1293, align 8
  %op7085 = sub i64 %v7084, 32
  store i64 %op7085, ptr %slot1299, align 8
  %v7086 = load i64, ptr %slot1293, align 8
  %p7087 = inttoptr i64 %v7086 to ptr
  %rgep7088 = getelementptr i8, ptr %p7087, i64 -32
  %ld7089 = load i64, ptr %rgep7088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7089, ptr %slot1300, align 8
  %v7090 = load i64, ptr %slot1300, align 8
  %op7091 = sub i64 %v7090, 1
  store i64 %op7091, ptr %slot1301, align 8
  %v7092 = load i64, ptr %slot1301, align 8
  %cmp7093 = icmp eq i64 %v7092, 0
  %cv7094 = zext i1 %cmp7093 to i32
  store i32 %cv7094, ptr %slot1302, align 8
  %v7095 = load i32, ptr %slot1302, align 8
  %cv7096 = zext i32 %v7095 to i64
  %cond7097 = icmp ne i64 %cv7096, 0
  br i1 %cond7097, label %bb_rcglast1619, label %bb_rcgdec1619
bb_rcglast1619:
  %v7098 = load i64, ptr %slot1293, align 8
  %op7099 = sub i64 %v7098, 24
  store i64 %op7099, ptr %slot1303, align 8
  %v7100 = load i64, ptr %slot1293, align 8
  %p7101 = inttoptr i64 %v7100 to ptr
  %rgep7102 = getelementptr i8, ptr %p7101, i64 -24
  %ld7103 = load i64, ptr %rgep7102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7103, ptr %slot1304, align 8
  %v7104 = load i64, ptr %slot1304, align 8
  %cmp7105 = icmp ne i64 %v7104, 0
  %cv7106 = zext i1 %cmp7105 to i32
  store i32 %cv7106, ptr %slot1305, align 8
  %v7107 = load i32, ptr %slot1305, align 8
  %cv7108 = zext i32 %v7107 to i64
  %cond7109 = icmp ne i64 %cv7108, 0
  br i1 %cond7109, label %bb_rcgdec1619, label %bb_rcgslow1619
bb_rcgslow1619:
  %v7110 = load i64, ptr %slot1292, align 8
  %v7111 = load i64, ptr %slot1275, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7110, i64 %v7111) nomerge, !dbg !186
  br label %bb_rcgdone1619
bb_rcgdec1619:
  %v7112 = load i64, ptr %slot1301, align 8
  %v7113 = load i64, ptr %slot1293, align 8
  %p7114 = inttoptr i64 %v7113 to ptr
  %rgep7115 = getelementptr i8, ptr %p7114, i64 -32
  store i64 %v7112, ptr %rgep7115, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1619
bb_rcgclear1619:
  %v7116 = load i64, ptr %slot1275, align 8
  %p7117 = inttoptr i64 %v7116 to ptr
  store i64 0, ptr %p7117, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1619
bb_rcgdone1619:
  br label %bb_rcslotdone1588
bb_rcslotdone1588:
  %v7118 = load i64, ptr %slot44, align 8
  %p7119 = inttoptr i64 %v7118 to ptr
  %ld7120 = load i64, ptr %p7119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7120, ptr %slot1306, align 8
  %v7121 = load i64, ptr %slot1306, align 8
  %v7122 = load i64, ptr %slot44, align 8
  %p7123 = inttoptr i64 %v7122 to ptr
  store i64 %v7121, ptr %p7123, align 8, !alias.scope !3, !noalias !4
  br label %bb_i145
bb_i145:
  %v7124 = load i64, ptr %slot44, align 8
  %p7125 = inttoptr i64 %v7124 to ptr
  %ld7126 = load i64, ptr %p7125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7126, ptr %slot1307, align 8
  %v7127 = load i64, ptr %slot1307, align 8
  %v7128 = load i64, ptr %slot43, align 8
  %p7129 = inttoptr i64 %v7128 to ptr
  store i64 %v7127, ptr %p7129, align 8, !alias.scope !3, !noalias !4
  %v7130 = load i64, ptr %slot43, align 8
  %p7131 = inttoptr i64 %v7130 to ptr
  %ld7132 = load i64, ptr %p7131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7132, ptr %slot1308, align 8
  %v7133 = load i64, ptr %slot1308, align 8
  %v7134 = load i64, ptr %slot44, align 8
  %p7135 = inttoptr i64 %v7134 to ptr
  store i64 %v7133, ptr %p7135, align 8, !alias.scope !3, !noalias !4
  %v7136 = load i64, ptr %slot45, align 8
  %p7137 = inttoptr i64 %v7136 to ptr
  store i64 48, ptr %p7137, align 8, !alias.scope !3, !noalias !4
  %v7138 = load i64, ptr %slot45, align 8
  %p7139 = inttoptr i64 %v7138 to ptr
  %ld7140 = load i64, ptr %p7139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7140, ptr %slot1309, align 8
  %v7141 = load i64, ptr %slot44, align 8
  %p7142 = inttoptr i64 %v7141 to ptr
  %ld7143 = load i64, ptr %p7142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7143, ptr %slot1310, align 8
  %v7144 = load i64, ptr %slot1310, align 8
  %v7145 = load i64, ptr %slot1309, align 8
  %cmp7146 = icmp sge i64 %v7144, %v7145
  %cv7147 = zext i1 %cmp7146 to i64
  store i64 %cv7147, ptr %slot1311, align 8
  %v7148 = load i64, ptr %slot1311, align 8
  %v7149 = load i64, ptr %slot44, align 8
  %p7150 = inttoptr i64 %v7149 to ptr
  store i64 %v7148, ptr %p7150, align 8, !alias.scope !3, !noalias !4
  %v7151 = load i64, ptr %slot44, align 8
  %p7152 = inttoptr i64 %v7151 to ptr
  %ld7153 = load i64, ptr %p7152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7153, ptr %slot1312, align 8
  %v7154 = load i64, ptr %slot1312, align 8
  %cond7155 = icmp ne i64 %v7154, 0
  br i1 %cond7155, label %bb_next1630, label %bb_i154
bb_next1630:
  %v7156 = load i64, ptr %slot43, align 8
  %p7157 = inttoptr i64 %v7156 to ptr
  %ld7158 = load i64, ptr %p7157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7158, ptr %slot1313, align 8
  %v7159 = load i64, ptr %slot1313, align 8
  %v7160 = load i64, ptr %slot44, align 8
  %p7161 = inttoptr i64 %v7160 to ptr
  store i64 %v7159, ptr %p7161, align 8, !alias.scope !3, !noalias !4
  %v7162 = load i64, ptr %slot45, align 8
  %p7163 = inttoptr i64 %v7162 to ptr
  store i64 57, ptr %p7163, align 8, !alias.scope !3, !noalias !4
  %v7164 = load i64, ptr %slot45, align 8
  %p7165 = inttoptr i64 %v7164 to ptr
  %ld7166 = load i64, ptr %p7165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7166, ptr %slot1314, align 8
  %v7167 = load i64, ptr %slot44, align 8
  %p7168 = inttoptr i64 %v7167 to ptr
  %ld7169 = load i64, ptr %p7168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7169, ptr %slot1315, align 8
  %v7170 = load i64, ptr %slot1315, align 8
  %v7171 = load i64, ptr %slot1314, align 8
  %cmp7172 = icmp sle i64 %v7170, %v7171
  %cv7173 = zext i1 %cmp7172 to i64
  store i64 %cv7173, ptr %slot1316, align 8
  %v7174 = load i64, ptr %slot1316, align 8
  %v7175 = load i64, ptr %slot44, align 8
  %p7176 = inttoptr i64 %v7175 to ptr
  store i64 %v7174, ptr %p7176, align 8, !alias.scope !3, !noalias !4
  br label %bb_i155
bb_i154:
  %v7177 = load i64, ptr %slot44, align 8
  %p7178 = inttoptr i64 %v7177 to ptr
  store i64 0, ptr %p7178, align 8, !alias.scope !3, !noalias !4
  br label %bb_i155
bb_i155:
  br label %bb_i156
bb_i156:
  %v7179 = load i64, ptr %slot44, align 8
  %p7180 = inttoptr i64 %v7179 to ptr
  %ld7181 = load i64, ptr %p7180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7181, ptr %slot1317, align 8
  %v7182 = load i64, ptr %slot1317, align 8
  %cond7183 = icmp ne i64 %v7182, 0
  br i1 %cond7183, label %bb_next1635, label %bb_i173
bb_next1635:
  %v7184 = load i64, ptr %slot30, align 8
  %p7185 = inttoptr i64 %v7184 to ptr
  %ld7186 = load i64, ptr %p7185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7186, ptr %slot1318, align 8
  %v7187 = load i64, ptr %slot1318, align 8
  %v7188 = load i64, ptr %slot44, align 8
  %p7189 = inttoptr i64 %v7188 to ptr
  store i64 %v7187, ptr %p7189, align 8, !alias.scope !3, !noalias !4
  %v7190 = load i64, ptr %slot44, align 8
  %p7191 = inttoptr i64 %v7190 to ptr
  %ld7192 = load i64, ptr %p7191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7192, ptr %slot1319, align 8
  %v7193 = load i64, ptr %slot1319, align 8
  %op7194 = add i64 %v7193, 16
  store i64 %op7194, ptr %slot1320, align 8
  %v7195 = load i64, ptr %slot1320, align 8
  %p7196 = inttoptr i64 %v7195 to ptr
  %ld7197 = load i64, ptr %p7196, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7197, ptr %slot1321, align 8
  %v7198 = load i64, ptr %slot1321, align 8
  %v7199 = load i64, ptr %slot44, align 8
  %p7200 = inttoptr i64 %v7199 to ptr
  store i64 %v7198, ptr %p7200, align 8, !alias.scope !3, !noalias !4
  %v7201 = load i64, ptr %slot19, align 8
  %p7202 = inttoptr i64 %v7201 to ptr
  %ld7203 = load i32, ptr %p7202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7203, ptr %slot1322, align 8
  %v7204 = load i32, ptr %slot1322, align 8
  %cv7205 = zext i32 %v7204 to i64
  %cond7206 = icmp ne i64 %cv7205, 0
  br i1 %cond7206, label %bb_rcslotdrop1641, label %bb_rcslotdone1641
bb_rcslotdrop1641:
  %v7207 = load i64, ptr %slot19, align 8
  %p7208 = inttoptr i64 %v7207 to ptr
  store i32 0, ptr %p7208, align 4, !alias.scope !3, !noalias !4
  %v7209 = load i64, ptr %slot25, align 8
  store i64 %v7209, ptr %slot1323, align 8
  %v7210 = load i64, ptr %slot20, align 8
  %p7211 = inttoptr i64 %v7210 to ptr
  %ld7212 = load i32, ptr %p7211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7212, ptr %slot1324, align 8
  %v7213 = load i32, ptr %slot1324, align 8
  %op7214 = and i32 %v7213, 28
  store i32 %op7214, ptr %slot1325, align 8
  %v7215 = load i32, ptr %slot1325, align 8
  %cv7216 = zext i32 %v7215 to i64
  %cond7217 = icmp ne i64 %cv7216, 0
  br i1 %cond7217, label %bb_rcslotrole1641, label %bb_rcslotowner1641
bb_rcslotrole1641:
  %v7218 = load i64, ptr %slot52, align 8
  store i64 %v7218, ptr %slot1326, align 8
  %v7219 = load i64, ptr %slot1326, align 8
  %v7220 = load i64, ptr %slot1323, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7219, i64 %v7220) nomerge, !dbg !188
  br label %bb_rcslotdone1641
bb_rcslotowner1641:
  %v7221 = load i64, ptr %slot52, align 8
  store i64 %v7221, ptr %slot1327, align 8
  %v7222 = load i64, ptr %slot1327, align 8
  %v7223 = load i64, ptr %slot1323, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7222, i64 %v7223) nomerge, !dbg !188
  br label %bb_rcslotdone1641
bb_rcslotdone1641:
  %v7224 = load i64, ptr %slot45, align 8
  %p7225 = inttoptr i64 %v7224 to ptr
  store i64 1, ptr %p7225, align 8, !alias.scope !3, !noalias !4
  %v7226 = load i64, ptr %slot45, align 8
  %p7227 = inttoptr i64 %v7226 to ptr
  %ld7228 = load i64, ptr %p7227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7228, ptr %slot1328, align 8
  %v7229 = load i64, ptr %slot44, align 8
  %p7230 = inttoptr i64 %v7229 to ptr
  %ld7231 = load i64, ptr %p7230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7231, ptr %slot1329, align 8
  %v7232 = load i64, ptr %slot1329, align 8
  %v7233 = load i64, ptr %slot1328, align 8
  %ovpair7235 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v7232, i64 %v7233)
  %op7234 = extractvalue { i64, i1 } %ovpair7235, 0
  %ov7236 = extractvalue { i64, i1 } %ovpair7235, 1
  store i64 %op7234, ptr %slot1330, align 8
  %cv7237 = zext i1 %ov7236 to i64
  store i64 %cv7237, ptr %slot1331, align 8
  %v7238 = load i64, ptr %slot1331, align 8
  %cond7239 = icmp ne i64 %v7238, 0
  br i1 %cond7239, label %bb_overflow1650, label %bb_checked1650
bb_overflow1650:
  %v7240 = load i64, ptr %slot1, align 8
  %p7241 = inttoptr i64 %v7240 to ptr
  %v7242 = load i64, ptr %slot1329, align 8
  %v7243 = load i64, ptr %slot1328, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p7241, i64 0, i64 %v7242, i64 %v7243, i64 64) nomerge, !dbg !190
  unreachable
bb_checked1650:
  %v7244 = load i64, ptr %slot1330, align 8
  %v7245 = load i64, ptr %slot44, align 8
  %p7246 = inttoptr i64 %v7245 to ptr
  store i64 %v7244, ptr %p7246, align 8, !alias.scope !3, !noalias !4
  %v7247 = load i64, ptr %slot44, align 8
  %p7248 = inttoptr i64 %v7247 to ptr
  %ld7249 = load i64, ptr %p7248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7249, ptr %slot1332, align 8
  %v7250 = load i64, ptr %slot1332, align 8
  %v7251 = load i64, ptr %slot33, align 8
  %p7252 = inttoptr i64 %v7251 to ptr
  store i64 %v7250, ptr %p7252, align 8, !alias.scope !3, !noalias !4
  %v7253 = load i64, ptr %slot30, align 8
  %p7254 = inttoptr i64 %v7253 to ptr
  %ld7255 = load i64, ptr %p7254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7255, ptr %slot1333, align 8
  %v7256 = load i64, ptr %slot1333, align 8
  %v7257 = load i64, ptr %slot44, align 8
  %p7258 = inttoptr i64 %v7257 to ptr
  store i64 %v7256, ptr %p7258, align 8, !alias.scope !3, !noalias !4
  %v7259 = load i64, ptr %slot30, align 8
  %p7260 = inttoptr i64 %v7259 to ptr
  %ld7261 = load i64, ptr %p7260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7261, ptr %slot1334, align 8
  %v7262 = load i64, ptr %slot1334, align 8
  %v7263 = load i64, ptr %slot44, align 8
  %p7264 = inttoptr i64 %v7263 to ptr
  store i64 %v7262, ptr %p7264, align 8, !alias.scope !3, !noalias !4
  %v7265 = load i64, ptr %slot30, align 8
  %p7266 = inttoptr i64 %v7265 to ptr
  %ld7267 = load i64, ptr %p7266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7267, ptr %slot1335, align 8
  %v7268 = load i64, ptr %slot1335, align 8
  %v7269 = load i64, ptr %slot44, align 8
  %p7270 = inttoptr i64 %v7269 to ptr
  store i64 %v7268, ptr %p7270, align 8, !alias.scope !3, !noalias !4
  %v7271 = load i64, ptr %slot33, align 8
  %p7272 = inttoptr i64 %v7271 to ptr
  %ld7273 = load i64, ptr %p7272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7273, ptr %slot1336, align 8
  %v7274 = load i64, ptr %slot1336, align 8
  %v7275 = load i64, ptr %slot45, align 8
  %p7276 = inttoptr i64 %v7275 to ptr
  store i64 %v7274, ptr %p7276, align 8, !alias.scope !3, !noalias !4
  %v7277 = load i64, ptr %slot30, align 8
  %p7278 = inttoptr i64 %v7277 to ptr
  %ld7279 = load i64, ptr %p7278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7279, ptr %slot1337, align 8
  %v7280 = load i64, ptr %slot1337, align 8
  %v7281 = load i64, ptr %slot44, align 8
  %p7282 = inttoptr i64 %v7281 to ptr
  store i64 %v7280, ptr %p7282, align 8, !alias.scope !3, !noalias !4
  %v7283 = load i64, ptr %slot33, align 8
  %p7284 = inttoptr i64 %v7283 to ptr
  %ld7285 = load i64, ptr %p7284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7285, ptr %slot1338, align 8
  %v7286 = load i64, ptr %slot30, align 8
  %p7287 = inttoptr i64 %v7286 to ptr
  %ld7288 = load i64, ptr %p7287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7288, ptr %slot1339, align 8
  %v7289 = load i64, ptr %slot1339, align 8
  %op7290 = add i64 %v7289, 16
  store i64 %op7290, ptr %slot1340, align 8
  %v7291 = load i64, ptr %slot1338, align 8
  %v7292 = load i64, ptr %slot1340, align 8
  %p7293 = inttoptr i64 %v7292 to ptr
  store i64 %v7291, ptr %p7293, align 8, !alias.scope !4, !noalias !3
  %v7294 = load i64, ptr %slot44, align 8
  %p7295 = inttoptr i64 %v7294 to ptr
  store i64 0, ptr %p7295, align 8, !alias.scope !3, !noalias !4
  br label %bb_i124
bb_i173:
  %v7296 = load i64, ptr %slot30, align 8
  %p7297 = inttoptr i64 %v7296 to ptr
  %ld7298 = load i64, ptr %p7297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7298, ptr %slot1341, align 8
  %v7299 = load i64, ptr %slot1341, align 8
  %v7300 = load i64, ptr %slot44, align 8
  %p7301 = inttoptr i64 %v7300 to ptr
  store i64 %v7299, ptr %p7301, align 8, !alias.scope !3, !noalias !4
  %v7302 = load i64, ptr %slot47, align 8
  store i64 %v7302, ptr %slot1342, align 8
  %v7303 = load i64, ptr %slot1342, align 8
  %p7304 = inttoptr i64 %v7303 to ptr
  store i32 0, ptr %p7304, align 4, !alias.scope !3, !noalias !4
  %v7305 = load i64, ptr %slot1342, align 8
  %p7306 = inttoptr i64 %v7305 to ptr
  store i32 21, ptr %p7306, align 4, !alias.scope !3, !noalias !4
  %v7307 = load i64, ptr %slot1342, align 8
  %v7308 = load i64, ptr %slot45, align 8
  %p7309 = inttoptr i64 %v7308 to ptr
  store i64 %v7307, ptr %p7309, align 8, !alias.scope !3, !noalias !4
  %v7310 = load i64, ptr %slot44, align 8
  %p7311 = inttoptr i64 %v7310 to ptr
  %ld7312 = load i64, ptr %p7311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7312, ptr %slot1343, align 8
  %v7313 = load i64, ptr %slot45, align 8
  %p7314 = inttoptr i64 %v7313 to ptr
  %ld7315 = load i64, ptr %p7314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7315, ptr %slot1344, align 8
  %v7316 = load i64, ptr %slot1, align 8
  %v7317 = load i64, ptr %slot1343, align 8
  %v7318 = load i64, ptr %slot1344, align 8
  call void @myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d(ptr sret([40 x i8]) align 8 %callresult1346, i64 %v7316, i64 %v7317, i64 %v7318) nomerge, !dbg !192
  %addr7319 = ptrtoint ptr %callresult1346 to i64
  store i64 %addr7319, ptr %slot1345, align 8
  %v7320 = load i64, ptr %slot1345, align 8
  %v7321 = load i64, ptr %slot44, align 8
  %p7322 = inttoptr i64 %v7321 to ptr
  store i64 %v7320, ptr %p7322, align 8, !alias.scope !3, !noalias !4
  %v7323 = load i64, ptr %slot44, align 8
  %p7324 = inttoptr i64 %v7323 to ptr
  %ld7325 = load i64, ptr %p7324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7325, ptr %slot1347, align 8
  %v7326 = load i64, ptr %slot29, align 8
  store i64 %v7326, ptr %slot1348, align 8
  %v7327 = load i64, ptr %slot1347, align 8
  %v7328 = load i64, ptr %slot1348, align 8
  %p7329 = inttoptr i64 %v7327 to ptr
  %p7330 = inttoptr i64 %v7328 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7330, ptr %p7329, i64 40, i1 false)
  %v7331 = load i64, ptr %slot24, align 8
  %p7332 = inttoptr i64 %v7331 to ptr
  store i32 2, ptr %p7332, align 4, !alias.scope !3, !noalias !4
  %v7333 = load i64, ptr %slot23, align 8
  %p7334 = inttoptr i64 %v7333 to ptr
  store i32 1, ptr %p7334, align 4, !alias.scope !3, !noalias !4
  %v7335 = load i64, ptr %slot19, align 8
  %p7336 = inttoptr i64 %v7335 to ptr
  %ld7337 = load i32, ptr %p7336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7337, ptr %slot1349, align 8
  %v7338 = load i32, ptr %slot1349, align 8
  %cv7339 = zext i32 %v7338 to i64
  %cond7340 = icmp ne i64 %cv7339, 0
  br i1 %cond7340, label %bb_rcslotdrop1672, label %bb_rcslotdone1672
bb_rcslotdrop1672:
  %v7341 = load i64, ptr %slot19, align 8
  %p7342 = inttoptr i64 %v7341 to ptr
  store i32 0, ptr %p7342, align 4, !alias.scope !3, !noalias !4
  %v7343 = load i64, ptr %slot25, align 8
  store i64 %v7343, ptr %slot1350, align 8
  %v7344 = load i64, ptr %slot20, align 8
  %p7345 = inttoptr i64 %v7344 to ptr
  %ld7346 = load i32, ptr %p7345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7346, ptr %slot1351, align 8
  %v7347 = load i32, ptr %slot1351, align 8
  %op7348 = and i32 %v7347, 28
  store i32 %op7348, ptr %slot1352, align 8
  %v7349 = load i32, ptr %slot1352, align 8
  %cv7350 = zext i32 %v7349 to i64
  %cond7351 = icmp ne i64 %cv7350, 0
  br i1 %cond7351, label %bb_rcslotrole1672, label %bb_rcslotowner1672
bb_rcslotrole1672:
  %v7352 = load i64, ptr %slot52, align 8
  store i64 %v7352, ptr %slot1353, align 8
  %v7353 = load i64, ptr %slot1353, align 8
  %v7354 = load i64, ptr %slot1350, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7353, i64 %v7354) nomerge, !dbg !192
  br label %bb_rcslotdone1672
bb_rcslotowner1672:
  %v7355 = load i64, ptr %slot52, align 8
  store i64 %v7355, ptr %slot1354, align 8
  %v7356 = load i64, ptr %slot1354, align 8
  %v7357 = load i64, ptr %slot1350, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7356, i64 %v7357) nomerge, !dbg !192
  br label %bb_rcslotdone1672
bb_rcslotdone1672:
  %v7358 = load i64, ptr %slot25, align 8
  store i64 %v7358, ptr %slot1355, align 8
  %v7359 = load i64, ptr %slot29, align 8
  store i64 %v7359, ptr %slot1356, align 8
  %v7360 = load i64, ptr %slot1356, align 8
  %v7361 = load i64, ptr %slot1355, align 8
  %p7362 = inttoptr i64 %v7360 to ptr
  %p7363 = inttoptr i64 %v7361 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7363, ptr %p7362, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v7364 = load i64, ptr %slot20, align 8
  %p7365 = inttoptr i64 %v7364 to ptr
  store i32 2, ptr %p7365, align 4, !alias.scope !3, !noalias !4
  %v7366 = load i64, ptr %slot24, align 8
  %p7367 = inttoptr i64 %v7366 to ptr
  %ld7368 = load i32, ptr %p7367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7368, ptr %slot1357, align 8
  %v7369 = load i32, ptr %slot1357, align 8
  %v7370 = load i64, ptr %slot20, align 8
  %p7371 = inttoptr i64 %v7370 to ptr
  store i32 %v7369, ptr %p7371, align 4, !alias.scope !3, !noalias !4
  %v7372 = load i64, ptr %slot23, align 8
  %p7373 = inttoptr i64 %v7372 to ptr
  store i32 0, ptr %p7373, align 4, !alias.scope !3, !noalias !4
  %v7374 = load i64, ptr %slot19, align 8
  %p7375 = inttoptr i64 %v7374 to ptr
  store i32 1, ptr %p7375, align 4, !alias.scope !3, !noalias !4
  %v7376 = load i64, ptr %slot1355, align 8
  %v7377 = load i64, ptr %slot44, align 8
  %p7378 = inttoptr i64 %v7377 to ptr
  store i64 %v7376, ptr %p7378, align 8, !alias.scope !3, !noalias !4
  %v7379 = load i64, ptr %slot44, align 8
  %p7380 = inttoptr i64 %v7379 to ptr
  %ld7381 = load i64, ptr %p7380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7381, ptr %slot1358, align 8
  %v7382 = load i64, ptr %slot44, align 8
  %p7383 = inttoptr i64 %v7382 to ptr
  %ld7384 = load i64, ptr %p7383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7384, ptr %slot1359, align 8
  %v7385 = load i64, ptr %slot29, align 8
  store i64 %v7385, ptr %slot1360, align 8
  %v7386 = load i64, ptr %slot53, align 8
  store i64 %v7386, ptr %slot1361, align 8
  %v7387 = load i64, ptr %slot52, align 8
  %v7388 = load i64, ptr %slot1360, align 8
  %v7389 = load i64, ptr %slot1359, align 8
  %v7390 = load i64, ptr %slot1361, align 8
  %cv7391 = trunc i64 %v7390 to i32
  %call7392 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v7387, i64 %v7388, i64 %v7389, i32 %cv7391) nomerge, !dbg !194
  store i32 %call7392, ptr %slot1362, align 8
  %v7393 = load i32, ptr %slot1362, align 8
  %cv7394 = zext i32 %v7393 to i64
  %cond7395 = icmp ne i64 %cv7394, 0
  br i1 %cond7395, label %bb_rcsuccess1692, label %bb_rcfailure1692
bb_rcfailure1692:
  %v7396 = load i64, ptr %slot52, align 8
  %p7397 = inttoptr i64 %v7396 to ptr
  %call7398 = call i32 @myl_rc_take_failure(ptr %p7397) nomerge, !dbg !194
  store i32 %call7398, ptr %slot1363, align 8
  %v7399 = load i64, ptr %slot1, align 8
  %p7400 = inttoptr i64 %v7399 to ptr
  %v7401 = load i32, ptr %slot1363, align 8
  %call7402 = call i32 @myl_qbe_rc_status(ptr %p7400, i32 %v7401) nomerge, !dbg !194
  store i32 %call7402, ptr %slot1364, align 8
  br label %bb_failure
bb_rcsuccess1692:
  %v7403 = load i64, ptr %slot19, align 8
  %p7404 = inttoptr i64 %v7403 to ptr
  store i32 0, ptr %p7404, align 4, !alias.scope !3, !noalias !4
  %v7405 = load i64, ptr %slot24, align 8
  %p7406 = inttoptr i64 %v7405 to ptr
  store i32 2, ptr %p7406, align 4, !alias.scope !3, !noalias !4
  %v7407 = load i64, ptr %slot23, align 8
  %p7408 = inttoptr i64 %v7407 to ptr
  store i32 1, ptr %p7408, align 4, !alias.scope !3, !noalias !4
  %v7409 = load i64, ptr %slot29, align 8
  store i64 %v7409, ptr %slot1365, align 8
  %v7410 = load i64, ptr %slot23, align 8
  %p7411 = inttoptr i64 %v7410 to ptr
  store i32 0, ptr %p7411, align 4, !alias.scope !3, !noalias !4
  %v7412 = load i64, ptr %slot19, align 8
  %p7413 = inttoptr i64 %v7412 to ptr
  %ld7414 = load i32, ptr %p7413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7414, ptr %slot1366, align 8
  %v7415 = load i32, ptr %slot1366, align 8
  %cv7416 = zext i32 %v7415 to i64
  %cond7417 = icmp ne i64 %cv7416, 0
  br i1 %cond7417, label %bb_rcslotdrop1702, label %bb_rcslotdone1702
bb_rcslotdrop1702:
  %v7418 = load i64, ptr %slot19, align 8
  %p7419 = inttoptr i64 %v7418 to ptr
  store i32 0, ptr %p7419, align 4, !alias.scope !3, !noalias !4
  %v7420 = load i64, ptr %slot25, align 8
  store i64 %v7420, ptr %slot1367, align 8
  %v7421 = load i64, ptr %slot20, align 8
  %p7422 = inttoptr i64 %v7421 to ptr
  %ld7423 = load i32, ptr %p7422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7423, ptr %slot1368, align 8
  %v7424 = load i32, ptr %slot1368, align 8
  %op7425 = and i32 %v7424, 28
  store i32 %op7425, ptr %slot1369, align 8
  %v7426 = load i32, ptr %slot1369, align 8
  %cv7427 = zext i32 %v7426 to i64
  %cond7428 = icmp ne i64 %cv7427, 0
  br i1 %cond7428, label %bb_rcslotrole1702, label %bb_rcslotowner1702
bb_rcslotrole1702:
  %v7429 = load i64, ptr %slot52, align 8
  store i64 %v7429, ptr %slot1370, align 8
  %v7430 = load i64, ptr %slot1370, align 8
  %v7431 = load i64, ptr %slot1367, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v7430, i64 %v7431) nomerge, !dbg !194
  br label %bb_rcslotdone1702
bb_rcslotowner1702:
  %v7432 = load i64, ptr %slot52, align 8
  store i64 %v7432, ptr %slot1371, align 8
  %v7433 = load i64, ptr %slot1371, align 8
  %v7434 = load i64, ptr %slot1367, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v7433, i64 %v7434) nomerge, !dbg !194
  br label %bb_rcslotdone1702
bb_rcslotdone1702:
  %v7435 = load i64, ptr %slot17, align 8
  %p7436 = inttoptr i64 %v7435 to ptr
  %ld7437 = load i32, ptr %p7436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7437, ptr %slot1372, align 8
  %v7438 = load i32, ptr %slot1372, align 8
  %cv7439 = zext i32 %v7438 to i64
  %cond7440 = icmp ne i64 %cv7439, 0
  br i1 %cond7440, label %bb_rcslotdrop1711, label %bb_rcslotdone1711
bb_rcslotdrop1711:
  %v7441 = load i64, ptr %slot17, align 8
  %p7442 = inttoptr i64 %v7441 to ptr
  store i32 0, ptr %p7442, align 4, !alias.scope !3, !noalias !4
  %v7443 = load i64, ptr %slot42, align 8
  store i64 %v7443, ptr %slot1373, align 8
  %v7444 = load i64, ptr %slot18, align 8
  %p7445 = inttoptr i64 %v7444 to ptr
  %ld7446 = load i32, ptr %p7445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7446, ptr %slot1374, align 8
  %v7447 = load i32, ptr %slot1374, align 8
  %op7448 = and i32 %v7447, 28
  store i32 %op7448, ptr %slot1375, align 8
  %v7449 = load i32, ptr %slot1375, align 8
  %cv7450 = zext i32 %v7449 to i64
  %cond7451 = icmp ne i64 %cv7450, 0
  br i1 %cond7451, label %bb_rcslotrole1711, label %bb_rcslotowner1711
bb_rcslotrole1711:
  %v7452 = load i64, ptr %slot52, align 8
  store i64 %v7452, ptr %slot1376, align 8
  %v7453 = load i64, ptr %slot1376, align 8
  %v7454 = load i64, ptr %slot1373, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7453, i64 %v7454) nomerge, !dbg !194
  br label %bb_rcslotdone1711
bb_rcslotowner1711:
  %v7455 = load i64, ptr %slot52, align 8
  store i64 %v7455, ptr %slot1377, align 8
  %v7456 = load i64, ptr %slot1377, align 8
  %v7457 = load i64, ptr %slot1373, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7456, i64 %v7457) nomerge, !dbg !194
  br label %bb_rcslotdone1711
bb_rcslotdone1711:
  %v7458 = load i64, ptr %slot15, align 8
  %p7459 = inttoptr i64 %v7458 to ptr
  %ld7460 = load i32, ptr %p7459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7460, ptr %slot1378, align 8
  %v7461 = load i32, ptr %slot1378, align 8
  %cv7462 = zext i32 %v7461 to i64
  %cond7463 = icmp ne i64 %cv7462, 0
  br i1 %cond7463, label %bb_rcslotdrop1720, label %bb_rcslotdone1720
bb_rcslotdrop1720:
  %v7464 = load i64, ptr %slot15, align 8
  %p7465 = inttoptr i64 %v7464 to ptr
  store i32 0, ptr %p7465, align 4, !alias.scope !3, !noalias !4
  %v7466 = load i64, ptr %slot41, align 8
  store i64 %v7466, ptr %slot1379, align 8
  %v7467 = load i64, ptr %slot16, align 8
  %p7468 = inttoptr i64 %v7467 to ptr
  %ld7469 = load i32, ptr %p7468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7469, ptr %slot1380, align 8
  %v7470 = load i32, ptr %slot1380, align 8
  %op7471 = and i32 %v7470, 28
  store i32 %op7471, ptr %slot1381, align 8
  %v7472 = load i32, ptr %slot1381, align 8
  %cv7473 = zext i32 %v7472 to i64
  %cond7474 = icmp ne i64 %cv7473, 0
  br i1 %cond7474, label %bb_rcslotrole1720, label %bb_rcslotowner1720
bb_rcslotrole1720:
  %v7475 = load i64, ptr %slot52, align 8
  store i64 %v7475, ptr %slot1382, align 8
  %v7476 = load i64, ptr %slot1382, align 8
  %v7477 = load i64, ptr %slot1379, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7476, i64 %v7477) nomerge, !dbg !194
  br label %bb_rcslotdone1720
bb_rcslotowner1720:
  %v7478 = load i64, ptr %slot52, align 8
  store i64 %v7478, ptr %slot1383, align 8
  %v7479 = load i64, ptr %slot1383, align 8
  %v7480 = load i64, ptr %slot1379, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7479, i64 %v7480) nomerge, !dbg !194
  br label %bb_rcslotdone1720
bb_rcslotdone1720:
  %v7481 = load i64, ptr %slot13, align 8
  %p7482 = inttoptr i64 %v7481 to ptr
  %ld7483 = load i32, ptr %p7482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7483, ptr %slot1384, align 8
  %v7484 = load i32, ptr %slot1384, align 8
  %cv7485 = zext i32 %v7484 to i64
  %cond7486 = icmp ne i64 %cv7485, 0
  br i1 %cond7486, label %bb_rcslotdrop1729, label %bb_rcslotdone1729
bb_rcslotdrop1729:
  %v7487 = load i64, ptr %slot13, align 8
  %p7488 = inttoptr i64 %v7487 to ptr
  store i32 0, ptr %p7488, align 4, !alias.scope !3, !noalias !4
  %v7489 = load i64, ptr %slot39, align 8
  store i64 %v7489, ptr %slot1385, align 8
  %v7490 = load i64, ptr %slot14, align 8
  %p7491 = inttoptr i64 %v7490 to ptr
  %ld7492 = load i32, ptr %p7491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7492, ptr %slot1386, align 8
  %v7493 = load i32, ptr %slot1386, align 8
  %op7494 = and i32 %v7493, 28
  store i32 %op7494, ptr %slot1387, align 8
  %v7495 = load i32, ptr %slot1387, align 8
  %cv7496 = zext i32 %v7495 to i64
  %cond7497 = icmp ne i64 %cv7496, 0
  br i1 %cond7497, label %bb_rcslotrole1729, label %bb_rcslotowner1729
bb_rcslotrole1729:
  %v7498 = load i64, ptr %slot52, align 8
  store i64 %v7498, ptr %slot1388, align 8
  %v7499 = load i64, ptr %slot1388, align 8
  %v7500 = load i64, ptr %slot1385, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7499, i64 %v7500) nomerge, !dbg !194
  br label %bb_rcslotdone1729
bb_rcslotowner1729:
  %v7501 = load i64, ptr %slot52, align 8
  store i64 %v7501, ptr %slot1389, align 8
  %v7502 = load i64, ptr %slot1389, align 8
  %v7503 = load i64, ptr %slot1385, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7502, i64 %v7503) nomerge, !dbg !194
  br label %bb_rcslotdone1729
bb_rcslotdone1729:
  %v7504 = load i64, ptr %slot11, align 8
  %p7505 = inttoptr i64 %v7504 to ptr
  %ld7506 = load i32, ptr %p7505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7506, ptr %slot1390, align 8
  %v7507 = load i32, ptr %slot1390, align 8
  %cv7508 = zext i32 %v7507 to i64
  %cond7509 = icmp ne i64 %cv7508, 0
  br i1 %cond7509, label %bb_rcslotdrop1738, label %bb_rcslotdone1738
bb_rcslotdrop1738:
  %v7510 = load i64, ptr %slot11, align 8
  %p7511 = inttoptr i64 %v7510 to ptr
  store i32 0, ptr %p7511, align 4, !alias.scope !3, !noalias !4
  %v7512 = load i64, ptr %slot38, align 8
  store i64 %v7512, ptr %slot1391, align 8
  %v7513 = load i64, ptr %slot12, align 8
  %p7514 = inttoptr i64 %v7513 to ptr
  %ld7515 = load i32, ptr %p7514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7515, ptr %slot1392, align 8
  %v7516 = load i32, ptr %slot1392, align 8
  %op7517 = and i32 %v7516, 28
  store i32 %op7517, ptr %slot1393, align 8
  %v7518 = load i32, ptr %slot1393, align 8
  %cv7519 = zext i32 %v7518 to i64
  %cond7520 = icmp ne i64 %cv7519, 0
  br i1 %cond7520, label %bb_rcslotrole1738, label %bb_rcslotowner1738
bb_rcslotrole1738:
  %v7521 = load i64, ptr %slot52, align 8
  store i64 %v7521, ptr %slot1394, align 8
  %v7522 = load i64, ptr %slot1394, align 8
  %v7523 = load i64, ptr %slot1391, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7522, i64 %v7523) nomerge, !dbg !194
  br label %bb_rcslotdone1738
bb_rcslotowner1738:
  %v7524 = load i64, ptr %slot52, align 8
  store i64 %v7524, ptr %slot1395, align 8
  %v7525 = load i64, ptr %slot1395, align 8
  %v7526 = load i64, ptr %slot1391, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7525, i64 %v7526) nomerge, !dbg !194
  br label %bb_rcslotdone1738
bb_rcslotdone1738:
  %v7527 = load i64, ptr %slot9, align 8
  %p7528 = inttoptr i64 %v7527 to ptr
  %ld7529 = load i32, ptr %p7528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7529, ptr %slot1396, align 8
  %v7530 = load i32, ptr %slot1396, align 8
  %cv7531 = zext i32 %v7530 to i64
  %cond7532 = icmp ne i64 %cv7531, 0
  br i1 %cond7532, label %bb_rcslotdrop1747, label %bb_rcslotdone1747
bb_rcslotdrop1747:
  %v7533 = load i64, ptr %slot9, align 8
  %p7534 = inttoptr i64 %v7533 to ptr
  store i32 0, ptr %p7534, align 4, !alias.scope !3, !noalias !4
  %v7535 = load i64, ptr %slot37, align 8
  store i64 %v7535, ptr %slot1397, align 8
  %v7536 = load i64, ptr %slot10, align 8
  %p7537 = inttoptr i64 %v7536 to ptr
  %ld7538 = load i32, ptr %p7537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7538, ptr %slot1398, align 8
  %v7539 = load i32, ptr %slot1398, align 8
  %op7540 = and i32 %v7539, 28
  store i32 %op7540, ptr %slot1399, align 8
  %v7541 = load i32, ptr %slot1399, align 8
  %cv7542 = zext i32 %v7541 to i64
  %cond7543 = icmp ne i64 %cv7542, 0
  br i1 %cond7543, label %bb_rcslotrole1747, label %bb_rcslotowner1747
bb_rcslotrole1747:
  %v7544 = load i64, ptr %slot52, align 8
  store i64 %v7544, ptr %slot1400, align 8
  %v7545 = load i64, ptr %slot1400, align 8
  %v7546 = load i64, ptr %slot1397, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7545, i64 %v7546) nomerge, !dbg !194
  br label %bb_rcslotdone1747
bb_rcslotowner1747:
  %v7547 = load i64, ptr %slot52, align 8
  store i64 %v7547, ptr %slot1401, align 8
  %v7548 = load i64, ptr %slot1401, align 8
  %v7549 = load i64, ptr %slot1397, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7548, i64 %v7549) nomerge, !dbg !194
  br label %bb_rcslotdone1747
bb_rcslotdone1747:
  %v7550 = load i64, ptr %slot7, align 8
  %p7551 = inttoptr i64 %v7550 to ptr
  %ld7552 = load i32, ptr %p7551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7552, ptr %slot1402, align 8
  %v7553 = load i32, ptr %slot1402, align 8
  %cv7554 = zext i32 %v7553 to i64
  %cond7555 = icmp ne i64 %cv7554, 0
  br i1 %cond7555, label %bb_rcslotdrop1756, label %bb_rcslotdone1756
bb_rcslotdrop1756:
  %v7556 = load i64, ptr %slot7, align 8
  %p7557 = inttoptr i64 %v7556 to ptr
  store i32 0, ptr %p7557, align 4, !alias.scope !3, !noalias !4
  %v7558 = load i64, ptr %slot35, align 8
  store i64 %v7558, ptr %slot1403, align 8
  %v7559 = load i64, ptr %slot8, align 8
  %p7560 = inttoptr i64 %v7559 to ptr
  %ld7561 = load i32, ptr %p7560, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7561, ptr %slot1404, align 8
  %v7562 = load i32, ptr %slot1404, align 8
  %op7563 = and i32 %v7562, 28
  store i32 %op7563, ptr %slot1405, align 8
  %v7564 = load i32, ptr %slot1405, align 8
  %cv7565 = zext i32 %v7564 to i64
  %cond7566 = icmp ne i64 %cv7565, 0
  br i1 %cond7566, label %bb_rcslotrole1756, label %bb_rcslotowner1756
bb_rcslotrole1756:
  %v7567 = load i64, ptr %slot52, align 8
  store i64 %v7567, ptr %slot1406, align 8
  %v7568 = load i64, ptr %slot1406, align 8
  %v7569 = load i64, ptr %slot1403, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7568, i64 %v7569) nomerge, !dbg !194
  br label %bb_rcslotdone1756
bb_rcslotowner1756:
  %v7570 = load i64, ptr %slot52, align 8
  store i64 %v7570, ptr %slot1407, align 8
  %v7571 = load i64, ptr %slot1407, align 8
  %v7572 = load i64, ptr %slot1403, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7571, i64 %v7572) nomerge, !dbg !194
  br label %bb_rcslotdone1756
bb_rcslotdone1756:
  %v7573 = load i64, ptr %slot5, align 8
  %p7574 = inttoptr i64 %v7573 to ptr
  %ld7575 = load i32, ptr %p7574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7575, ptr %slot1408, align 8
  %v7576 = load i32, ptr %slot1408, align 8
  %cv7577 = zext i32 %v7576 to i64
  %cond7578 = icmp ne i64 %cv7577, 0
  br i1 %cond7578, label %bb_rcslotdrop1765, label %bb_rcslotdone1765
bb_rcslotdrop1765:
  %v7579 = load i64, ptr %slot5, align 8
  %p7580 = inttoptr i64 %v7579 to ptr
  store i32 0, ptr %p7580, align 4, !alias.scope !3, !noalias !4
  %v7581 = load i64, ptr %slot34, align 8
  store i64 %v7581, ptr %slot1409, align 8
  %v7582 = load i64, ptr %slot6, align 8
  %p7583 = inttoptr i64 %v7582 to ptr
  %ld7584 = load i32, ptr %p7583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7584, ptr %slot1410, align 8
  %v7585 = load i32, ptr %slot1410, align 8
  %op7586 = and i32 %v7585, 28
  store i32 %op7586, ptr %slot1411, align 8
  %v7587 = load i32, ptr %slot1411, align 8
  %cv7588 = zext i32 %v7587 to i64
  %cond7589 = icmp ne i64 %cv7588, 0
  br i1 %cond7589, label %bb_rcslotrole1765, label %bb_rcslotowner1765
bb_rcslotrole1765:
  %v7590 = load i64, ptr %slot52, align 8
  store i64 %v7590, ptr %slot1412, align 8
  %v7591 = load i64, ptr %slot1412, align 8
  %v7592 = load i64, ptr %slot1409, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7591, i64 %v7592) nomerge, !dbg !194
  br label %bb_rcslotdone1765
bb_rcslotowner1765:
  %v7593 = load i64, ptr %slot52, align 8
  store i64 %v7593, ptr %slot1413, align 8
  %v7594 = load i64, ptr %slot1413, align 8
  %v7595 = load i64, ptr %slot1409, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7594, i64 %v7595) nomerge, !dbg !194
  br label %bb_rcslotdone1765
bb_rcslotdone1765:
  %v7596 = load i64, ptr %slot1365, align 8
  %p7597 = inttoptr i64 %v7596 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p7597, i64 40, i1 false)
  ret void
bb_failure:
  %v7598 = load i64, ptr %slot4, align 8
  %p7599 = inttoptr i64 %v7598 to ptr
  call void @llvm.memset.p0.i64(ptr %p7599, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !194
  %v7600 = load i64, ptr %slot4, align 8
  %p7601 = inttoptr i64 %v7600 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p7601, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v7602 = load i64, ptr %slot4, align 8
  %p7603 = inttoptr i64 %v7602 to ptr
  call void @llvm.memset.p0.i64(ptr %p7603, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !194
  %v7604 = load i64, ptr %slot4, align 8
  %p7605 = inttoptr i64 %v7604 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p7605, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d(ptr sret([40 x i8]) align 8, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_e22482a0807d12562d64ed5d8c5e8b8ccef34761b2567c14443ddc2d6e9decfd", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_e22482a0807d12562d64ed5d8c5e8b8ccef34761b2567c14443ddc2d6e9decfd", linkageName: "myl_f_e22482a0807d12562d64ed5d8c5e8b8ccef34761b2567c14443ddc2d6e9decfd", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10613497501988132117, i64 0, !"myl_f_e22482a0807d12562d64ed5d8c5e8b8ccef34761b2567c14443ddc2d6e9decfd"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!130 = !DILocation(line: 35, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!132 = !DILocation(line: 37, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!134 = !DILocation(line: 51, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!136 = !DILocation(line: 53, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!138 = !DILocation(line: 55, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!140 = !DILocation(line: 57, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!142 = !DILocation(line: 58, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!144 = !DILocation(line: 65, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!146 = !DILocation(line: 67, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!148 = !DILocation(line: 68, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!150 = !DILocation(line: 75, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!152 = !DILocation(line: 77, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!154 = !DILocation(line: 79, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647183)
!156 = !DILocation(line: 81, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!158 = !DILocation(line: 82, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647239)
!160 = !DILocation(line: 88, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647255)
!162 = !DILocation(line: 90, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!164 = !DILocation(line: 92, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647279)
!166 = !DILocation(line: 93, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647423)
!168 = !DILocation(line: 111, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647439)
!170 = !DILocation(line: 113, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647543)
!172 = !DILocation(line: 126, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647559)
!174 = !DILocation(line: 128, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647575)
!176 = !DILocation(line: 130, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647591)
!178 = !DILocation(line: 132, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647599)
!180 = !DILocation(line: 133, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647655)
!182 = !DILocation(line: 140, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647671)
!184 = !DILocation(line: 142, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647679)
!186 = !DILocation(line: 143, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647807)
!188 = !DILocation(line: 159, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647823)
!190 = !DILocation(line: 161, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647943)
!192 = !DILocation(line: 176, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647951)
!194 = !DILocation(line: 177, column: 0, scope: !195)
