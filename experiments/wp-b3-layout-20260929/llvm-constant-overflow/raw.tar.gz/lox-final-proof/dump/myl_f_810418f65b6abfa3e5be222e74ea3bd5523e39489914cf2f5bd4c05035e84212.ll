target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_810418f65b6abfa3e5be222e74ea3bd5523e39489914cf2f5bd4c05035e84212(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %callresult49 = alloca [16 x i8], align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca double, align 8
  %slot86 = alloca double, align 8
  %slot87 = alloca double, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v113 = load i64, ptr %slot1, align 8
  %op114 = add i64 %v113, 32
  store i64 %op114, ptr %slot3, align 8
  %mem115 = alloca i8, i64 16, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot4, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot5, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot6, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot7, align 8
  %mem123 = alloca i8, i64 8, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot8, align 8
  %mem125 = alloca i8, i64 8, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot9, align 8
  %mem127 = alloca i8, i64 208, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot10, align 8
  %mem129 = alloca i8, i64 208, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot11, align 8
  %mem131 = alloca i8, i64 8, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot12, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot13, align 8
  %mem135 = alloca i8, i64 8, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot14, align 8
  %mem137 = alloca i8, i64 8, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot15, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot16, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot17, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot18, align 8
  %mem145 = alloca i8, i64 16, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot19, align 8
  %mem147 = alloca i8, i64 16, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot20, align 8
  %mem149 = alloca i8, i64 16, align 8
  %ptr150 = ptrtoint ptr %mem149 to i64
  store i64 %ptr150, ptr %slot21, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem151 = alloca i8, i64 8, align 8
  %ptr152 = ptrtoint ptr %mem151 to i64
  store i64 %ptr152, ptr %slot22, align 8
  %v153 = load i64, ptr %slot1, align 8
  %op154 = add i64 %v153, 64
  store i64 %op154, ptr %slot23, align 8
  %v155 = load i64, ptr %slot23, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !4, !noalias !3
  store i64 %ld157, ptr %slot24, align 8
  %stack158 = call ptr @llvm.stacksave()
  %stackaddr159 = ptrtoint ptr %stack158 to i64
  %v160 = load i64, ptr %slot24, align 8
  %cmp161 = icmp ult i64 %stackaddr159, %v160
  %cv162 = zext i1 %cmp161 to i64
  store i64 %cv162, ptr %slot25, align 8
  %v163 = load i64, ptr %slot25, align 8
  %cond164 = icmp ne i64 %v163, 0
  br i1 %cond164, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v165 = load i64, ptr %slot1, align 8
  %p166 = inttoptr i64 %v165 to ptr
  call void @myl_qbe_fail_frame(ptr %p166) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v167 = load i64, ptr %slot2, align 8
  %v168 = load i64, ptr %slot12, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i64 %v167, ptr %p169, align 8, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot1, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %call172 = call ptr @myl_qbe_heap(ptr %p171) nomerge, !dbg !112
  %calladdr173 = ptrtoint ptr %call172 to i64
  store i64 %calladdr173, ptr %slot26, align 8
  %v174 = load i64, ptr %slot1, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %call176 = call i64 @myl_qbe_region_mark(ptr %p175) nomerge, !dbg !112
  store i64 %call176, ptr %slot27, align 8
  %v177 = load i64, ptr %slot5, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i32 0, ptr %p178, align 4, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot6, align 8
  %p180 = inttoptr i64 %v179 to ptr
  store i32 0, ptr %p180, align 4, !alias.scope !3, !noalias !4
  %v181 = load i64, ptr %slot7, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i32 0, ptr %p182, align 4, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot8, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i32 0, ptr %p184, align 4, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot9, align 8
  %p186 = inttoptr i64 %v185 to ptr
  store i32 0, ptr %p186, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v187 = load i64, ptr %slot12, align 8
  %p188 = inttoptr i64 %v187 to ptr
  %ld189 = load i64, ptr %p188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld189, ptr %slot28, align 8
  %v190 = load i64, ptr %slot28, align 8
  %v191 = load i64, ptr %slot17, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot17, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot29, align 8
  %v196 = load i64, ptr %slot29, align 8
  %op197 = add i64 %v196, 192
  store i64 %op197, ptr %slot30, align 8
  %v198 = load i64, ptr %slot30, align 8
  %v199 = load i64, ptr %slot17, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 %v198, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot5, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i32, ptr %p202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld203, ptr %slot31, align 8
  %v204 = load i32, ptr %slot31, align 8
  %cv205 = zext i32 %v204 to i64
  %cond206 = icmp ne i64 %cv205, 0
  br i1 %cond206, label %bb_rcslotdrop13, label %bb_rcslotdone13
bb_rcslotdrop13:
  %v207 = load i64, ptr %slot5, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i32 0, ptr %p208, align 4, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot10, align 8
  store i64 %v209, ptr %slot32, align 8
  %v210 = load i64, ptr %slot6, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i32, ptr %p211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld212, ptr %slot33, align 8
  %v213 = load i32, ptr %slot33, align 8
  %op214 = and i32 %v213, 28
  store i32 %op214, ptr %slot34, align 8
  %v215 = load i32, ptr %slot34, align 8
  %cv216 = zext i32 %v215 to i64
  %cond217 = icmp ne i64 %cv216, 0
  br i1 %cond217, label %bb_rcslotrole13, label %bb_rcslotowner13
bb_rcslotrole13:
  %v218 = load i64, ptr %slot26, align 8
  store i64 %v218, ptr %slot35, align 8
  %v219 = load i64, ptr %slot35, align 8
  %v220 = load i64, ptr %slot32, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v219, i64 %v220) nomerge, !dbg !114
  br label %bb_rcslotdone13
bb_rcslotowner13:
  %v221 = load i64, ptr %slot26, align 8
  store i64 %v221, ptr %slot36, align 8
  %v222 = load i64, ptr %slot36, align 8
  %v223 = load i64, ptr %slot32, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v222, i64 %v223) nomerge, !dbg !114
  br label %bb_rcslotdone13
bb_rcslotdone13:
  %v224 = load i64, ptr %slot17, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i64, ptr %p225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld226, ptr %slot37, align 8
  %v227 = load i64, ptr %slot37, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i32, ptr %p228, align 4
  %ext230 = zext i32 %ld229 to i64
  store i64 %ext230, ptr %slot38, align 8
  %v231 = load i64, ptr %slot38, align 8
  %cmp232 = icmp eq i64 %v231, 0
  %cv233 = zext i1 %cmp232 to i64
  store i64 %cv233, ptr %slot39, align 8
  %v234 = load i64, ptr %slot39, align 8
  %cond235 = icmp ne i64 %v234, 0
  br i1 %cond235, label %bb_rcarm22, label %bb_rcarmnext22
bb_rcarm22:
  br label %bb_i26
bb_rcarmnext22:
  %v236 = load i64, ptr %slot38, align 8
  %cmp237 = icmp eq i64 %v236, 1
  %cv238 = zext i1 %cmp237 to i64
  store i64 %cv238, ptr %slot40, align 8
  %v239 = load i64, ptr %slot40, align 8
  %cond240 = icmp ne i64 %v239, 0
  br i1 %cond240, label %bb_rcarm23, label %bb_rcarmnext23
bb_rcarm23:
  %v241 = load i64, ptr %slot11, align 8
  store i64 %v241, ptr %slot41, align 8
  %v242 = load i64, ptr %slot37, align 8
  %op243 = add i64 %v242, 8
  store i64 %op243, ptr %slot42, align 8
  %v244 = load i64, ptr %slot27, align 8
  store i64 %v244, ptr %slot43, align 8
  %v245 = load i64, ptr %slot42, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %ld247 = load i64, ptr %p246, align 8
  store i64 %ld247, ptr %slot44, align 8
  %v248 = load i64, ptr %slot44, align 8
  %v249 = load i64, ptr %slot41, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 %v248, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot8, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i32 0, ptr %p252, align 4, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot7, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i32 1, ptr %p254, align 4, !alias.scope !3, !noalias !4
  %v255 = load i64, ptr %slot41, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %ld257 = load i64, ptr %p256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld257, ptr %slot45, align 8
  %v258 = load i64, ptr %slot45, align 8
  %v259 = load i64, ptr %slot13, align 8
  %p260 = inttoptr i64 %v259 to ptr
  store i64 %v258, ptr %p260, align 8, !alias.scope !3, !noalias !4
  %v261 = load i64, ptr %slot7, align 8
  %p262 = inttoptr i64 %v261 to ptr
  store i32 0, ptr %p262, align 4, !alias.scope !3, !noalias !4
  br label %bb_i3
bb_rcarmnext23:
  br label %bb_failure
bb_i3:
  %v263 = load i64, ptr %slot13, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot46, align 8
  %v266 = load i64, ptr %slot46, align 8
  %v267 = load i64, ptr %slot17, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i64 %v266, ptr %p268, align 8, !alias.scope !3, !noalias !4
  %v269 = load i64, ptr %slot17, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld271, ptr %slot47, align 8
  %v272 = load i64, ptr %slot1, align 8
  %v273 = load i64, ptr %slot47, align 8
  %call274 = call { i64, i64 } @myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c(i64 %v272, i64 %v273) nomerge, !dbg !116
  store { i64, i64 } %call274, ptr %callresult49, align 8
  %addr275 = ptrtoint ptr %callresult49 to i64
  store i64 %addr275, ptr %slot48, align 8
  %v276 = load i64, ptr %slot48, align 8
  %v277 = load i64, ptr %slot17, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i64 %v276, ptr %p278, align 8, !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot17, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i64, ptr %p280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld281, ptr %slot50, align 8
  %v282 = load i64, ptr %slot11, align 8
  store i64 %v282, ptr %slot51, align 8
  %v283 = load i64, ptr %slot50, align 8
  %v284 = load i64, ptr %slot51, align 8
  %p285 = inttoptr i64 %v283 to ptr
  %p286 = inttoptr i64 %v284 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p286, ptr %p285, i64 16, i1 false)
  %v287 = load i64, ptr %slot8, align 8
  %p288 = inttoptr i64 %v287 to ptr
  store i32 2, ptr %p288, align 4, !alias.scope !3, !noalias !4
  %v289 = load i64, ptr %slot7, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i32 1, ptr %p290, align 4, !alias.scope !3, !noalias !4
  %v291 = load i64, ptr %slot10, align 8
  store i64 %v291, ptr %slot52, align 8
  %v292 = load i64, ptr %slot11, align 8
  store i64 %v292, ptr %slot53, align 8
  %v293 = load i64, ptr %slot53, align 8
  %v294 = load i64, ptr %slot52, align 8
  %p295 = inttoptr i64 %v293 to ptr
  %p296 = inttoptr i64 %v294 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p296, ptr %p295, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot6, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i32 2, ptr %p298, align 4, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot8, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i32, ptr %p300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld301, ptr %slot54, align 8
  %v302 = load i32, ptr %slot54, align 8
  %v303 = load i64, ptr %slot6, align 8
  %p304 = inttoptr i64 %v303 to ptr
  store i32 %v302, ptr %p304, align 4, !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot7, align 8
  %p306 = inttoptr i64 %v305 to ptr
  store i32 0, ptr %p306, align 4, !alias.scope !3, !noalias !4
  %v307 = load i64, ptr %slot5, align 8
  %p308 = inttoptr i64 %v307 to ptr
  store i32 1, ptr %p308, align 4, !alias.scope !3, !noalias !4
  %v309 = load i64, ptr %slot52, align 8
  %v310 = load i64, ptr %slot17, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i64 %v309, ptr %p311, align 8, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot17, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %ld314 = load i64, ptr %p313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld314, ptr %slot55, align 8
  %v315 = load i64, ptr %slot55, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i32, ptr %p316, align 4
  %ext318 = zext i32 %ld317 to i64
  store i64 %ext318, ptr %slot56, align 8
  %v319 = load i64, ptr %slot56, align 8
  %cmp320 = icmp eq i64 %v319, 0
  %cv321 = zext i1 %cmp320 to i64
  store i64 %cv321, ptr %slot57, align 8
  %v322 = load i64, ptr %slot57, align 8
  %cond323 = icmp ne i64 %v322, 0
  br i1 %cond323, label %bb_rcarm49, label %bb_rcarmnext49
bb_rcarm49:
  %v324 = load i64, ptr %slot11, align 8
  store i64 %v324, ptr %slot58, align 8
  %v325 = load i64, ptr %slot55, align 8
  %op326 = add i64 %v325, 8
  store i64 %op326, ptr %slot59, align 8
  %v327 = load i64, ptr %slot27, align 8
  store i64 %v327, ptr %slot60, align 8
  %v328 = load i64, ptr %slot59, align 8
  %v329 = load i64, ptr %slot58, align 8
  %p330 = inttoptr i64 %v328 to ptr
  %p331 = inttoptr i64 %v329 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p331, ptr %p330, i64 8, i1 false)
  %v332 = load i64, ptr %slot8, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i32 0, ptr %p333, align 4, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot7, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i32 1, ptr %p335, align 4, !alias.scope !3, !noalias !4
  %v336 = load i64, ptr %slot58, align 8
  %v337 = load i64, ptr %slot14, align 8
  %p338 = inttoptr i64 %v336 to ptr
  %p339 = inttoptr i64 %v337 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p339, ptr %p338, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v340 = load i64, ptr %slot7, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i32 0, ptr %p341, align 4, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot5, align 8
  %p343 = inttoptr i64 %v342 to ptr
  %ld344 = load i32, ptr %p343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld344, ptr %slot61, align 8
  %v345 = load i32, ptr %slot61, align 8
  %cv346 = zext i32 %v345 to i64
  %cond347 = icmp ne i64 %cv346, 0
  br i1 %cond347, label %bb_rcslotdrop58, label %bb_rcslotdone58
bb_rcslotdrop58:
  %v348 = load i64, ptr %slot5, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i32 0, ptr %p349, align 4, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot10, align 8
  store i64 %v350, ptr %slot62, align 8
  %v351 = load i64, ptr %slot6, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %ld353 = load i32, ptr %p352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld353, ptr %slot63, align 8
  %v354 = load i32, ptr %slot63, align 8
  %op355 = and i32 %v354, 28
  store i32 %op355, ptr %slot64, align 8
  %v356 = load i32, ptr %slot64, align 8
  %cv357 = zext i32 %v356 to i64
  %cond358 = icmp ne i64 %cv357, 0
  br i1 %cond358, label %bb_rcslotrole58, label %bb_rcslotowner58
bb_rcslotrole58:
  %v359 = load i64, ptr %slot26, align 8
  store i64 %v359, ptr %slot65, align 8
  %v360 = load i64, ptr %slot65, align 8
  %v361 = load i64, ptr %slot62, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v360, i64 %v361) nomerge, !dbg !118
  br label %bb_rcslotdone58
bb_rcslotowner58:
  %v362 = load i64, ptr %slot26, align 8
  store i64 %v362, ptr %slot66, align 8
  %v363 = load i64, ptr %slot66, align 8
  %v364 = load i64, ptr %slot62, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v363, i64 %v364) nomerge, !dbg !118
  br label %bb_rcslotdone58
bb_rcslotdone58:
  br label %bb_i6
bb_rcarmnext49:
  %v365 = load i64, ptr %slot56, align 8
  %cmp366 = icmp eq i64 %v365, 1
  %cv367 = zext i1 %cmp366 to i64
  store i64 %cv367, ptr %slot67, align 8
  %v368 = load i64, ptr %slot67, align 8
  %cond369 = icmp ne i64 %v368, 0
  br i1 %cond369, label %bb_rcarm65, label %bb_rcarmnext65
bb_rcarm65:
  %v370 = load i64, ptr %slot5, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i32, ptr %p371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld372, ptr %slot68, align 8
  %v373 = load i32, ptr %slot68, align 8
  %cv374 = zext i32 %v373 to i64
  %cond375 = icmp ne i64 %cv374, 0
  br i1 %cond375, label %bb_rcslotdrop68, label %bb_rcslotdone68
bb_rcslotdrop68:
  %v376 = load i64, ptr %slot5, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i32 0, ptr %p377, align 4, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot10, align 8
  store i64 %v378, ptr %slot69, align 8
  %v379 = load i64, ptr %slot6, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %ld381 = load i32, ptr %p380, align 4, !alias.scope !3, !noalias !4
  store i32 %ld381, ptr %slot70, align 8
  %v382 = load i32, ptr %slot70, align 8
  %op383 = and i32 %v382, 28
  store i32 %op383, ptr %slot71, align 8
  %v384 = load i32, ptr %slot71, align 8
  %cv385 = zext i32 %v384 to i64
  %cond386 = icmp ne i64 %cv385, 0
  br i1 %cond386, label %bb_rcslotrole68, label %bb_rcslotowner68
bb_rcslotrole68:
  %v387 = load i64, ptr %slot26, align 8
  store i64 %v387, ptr %slot72, align 8
  %v388 = load i64, ptr %slot72, align 8
  %v389 = load i64, ptr %slot69, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v388, i64 %v389) nomerge, !dbg !118
  br label %bb_rcslotdone68
bb_rcslotowner68:
  %v390 = load i64, ptr %slot26, align 8
  store i64 %v390, ptr %slot73, align 8
  %v391 = load i64, ptr %slot73, align 8
  %v392 = load i64, ptr %slot69, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v391, i64 %v392) nomerge, !dbg !118
  br label %bb_rcslotdone68
bb_rcslotdone68:
  br label %bb_i22
bb_rcarmnext65:
  br label %bb_failure
bb_i6:
  %v393 = load i64, ptr %slot14, align 8
  %v394 = load i64, ptr %slot17, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 %v393, ptr %p395, align 8, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot17, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot74, align 8
  %v399 = load i64, ptr %slot74, align 8
  %op400 = add i64 %v399, 0
  store i64 %op400, ptr %slot75, align 8
  %v401 = load i64, ptr %slot75, align 8
  %p402 = inttoptr i64 %v401 to ptr
  %ld403 = load i64, ptr %p402, align 8
  store i64 %ld403, ptr %slot76, align 8
  %v404 = load i64, ptr %slot76, align 8
  %v405 = load i64, ptr %slot17, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 %v404, ptr %p406, align 8, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot17, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i64, ptr %p408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld409, ptr %slot77, align 8
  %v410 = load i64, ptr %slot1, align 8
  %p411 = inttoptr i64 %v410 to ptr
  %v412 = load i64, ptr %slot77, align 8
  %call413 = call i64 @myl_qbe_float_unary(ptr %p411, i64 10, i64 %v412) nomerge, !dbg !120
  store i64 %call413, ptr %slot78, align 8
  %v414 = load i64, ptr %slot78, align 8
  %v415 = load i64, ptr %slot17, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i64 %v414, ptr %p416, align 8, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot17, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot79, align 8
  %v420 = load i64, ptr %slot79, align 8
  %v421 = load i64, ptr %slot15, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i64 %v420, ptr %p422, align 8, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot17, align 8
  %p424 = inttoptr i64 %v423 to ptr
  store i64 4741671816366391296, ptr %p424, align 8, !alias.scope !3, !noalias !4
  %v425 = load i64, ptr %slot17, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i64, ptr %p426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld427, ptr %slot80, align 8
  %v428 = load i64, ptr %slot80, align 8
  %v429 = load i64, ptr %slot16, align 8
  %p430 = inttoptr i64 %v429 to ptr
  store i64 %v428, ptr %p430, align 8, !alias.scope !3, !noalias !4
  %v431 = load i64, ptr %slot15, align 8
  %p432 = inttoptr i64 %v431 to ptr
  %ld433 = load i64, ptr %p432, align 8, !alias.scope !3, !noalias !4
  store i64 %ld433, ptr %slot81, align 8
  %v434 = load i64, ptr %slot81, align 8
  %v435 = load i64, ptr %slot17, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i64 %v434, ptr %p436, align 8, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot16, align 8
  %p438 = inttoptr i64 %v437 to ptr
  %ld439 = load i64, ptr %p438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld439, ptr %slot82, align 8
  %v440 = load i64, ptr %slot82, align 8
  %v441 = load i64, ptr %slot18, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i64 %v440, ptr %p442, align 8, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot18, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i64, ptr %p444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld445, ptr %slot83, align 8
  %v446 = load i64, ptr %slot17, align 8
  %p447 = inttoptr i64 %v446 to ptr
  %ld448 = load i64, ptr %p447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld448, ptr %slot84, align 8
  %v449 = load i64, ptr %slot84, align 8
  %cast450 = bitcast i64 %v449 to double
  store double %cast450, ptr %slot85, align 8
  %v451 = load i64, ptr %slot83, align 8
  %cast452 = bitcast i64 %v451 to double
  store double %cast452, ptr %slot86, align 8
  %v453 = load double, ptr %slot85, align 8
  %v454 = load double, ptr %slot86, align 8
  %op455 = fdiv double %v453, %v454
  store double %op455, ptr %slot87, align 8
  %v456 = load double, ptr %slot87, align 8
  %cast457 = bitcast double %v456 to i64
  store i64 %cast457, ptr %slot88, align 8
  %v458 = load i64, ptr %slot88, align 8
  %v459 = load i64, ptr %slot17, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i64 %v458, ptr %p460, align 8, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot19, align 8
  store i64 %v461, ptr %slot89, align 8
  %v462 = load i64, ptr %slot89, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i64 0, ptr %p463, align 8, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot89, align 8
  %p466 = inttoptr i64 %v464 to ptr
  %gep467 = getelementptr i8, ptr %p466, i64 8
  %op465 = ptrtoint ptr %gep467 to i64
  store i64 %op465, ptr %slot90, align 8
  %v468 = load i64, ptr %slot90, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i64 0, ptr %p469, align 8, !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot89, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 2, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot9, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i32 1, ptr %p473, align 4, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot17, align 8
  store i64 %v474, ptr %slot91, align 8
  %v475 = load i64, ptr %slot89, align 8
  %p477 = inttoptr i64 %v475 to ptr
  %gep478 = getelementptr i8, ptr %p477, i64 8
  %op476 = ptrtoint ptr %gep478 to i64
  store i64 %op476, ptr %slot92, align 8
  %v479 = load i64, ptr %slot27, align 8
  store i64 %v479, ptr %slot93, align 8
  %v480 = load i64, ptr %slot91, align 8
  %p481 = inttoptr i64 %v480 to ptr
  %ld482 = load i64, ptr %p481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld482, ptr %slot94, align 8
  %v483 = load i64, ptr %slot94, align 8
  %v484 = load i64, ptr %slot92, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i64 %v483, ptr %p485, align 8, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot89, align 8
  %v487 = load i64, ptr %slot17, align 8
  %p488 = inttoptr i64 %v487 to ptr
  store i64 %v486, ptr %p488, align 8, !alias.scope !3, !noalias !4
  %v489 = load i64, ptr %slot17, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %ld491 = load i64, ptr %p490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld491, ptr %slot95, align 8
  %v492 = load i64, ptr %slot5, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i32, ptr %p493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld494, ptr %slot96, align 8
  %v495 = load i32, ptr %slot96, align 8
  %cv496 = zext i32 %v495 to i64
  %cond497 = icmp ne i64 %cv496, 0
  br i1 %cond497, label %bb_rcslotdrop101, label %bb_rcslotdone101
bb_rcslotdrop101:
  %v498 = load i64, ptr %slot5, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i32 0, ptr %p499, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone101
bb_rcslotdone101:
  %v500 = load i64, ptr %slot95, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ret502 = load { i64, i64 }, ptr %p501, align 8
  ret { i64, i64 } %ret502
bb_i22:
  %v503 = load i64, ptr %slot17, align 8
  %p504 = inttoptr i64 %v503 to ptr
  store i64 0, ptr %p504, align 8, !alias.scope !3, !noalias !4
  %v505 = load i64, ptr %slot20, align 8
  store i64 %v505, ptr %slot97, align 8
  %v506 = load i64, ptr %slot97, align 8
  %p507 = inttoptr i64 %v506 to ptr
  store i64 0, ptr %p507, align 8, !alias.scope !3, !noalias !4
  %v508 = load i64, ptr %slot97, align 8
  %p510 = inttoptr i64 %v508 to ptr
  %gep511 = getelementptr i8, ptr %p510, i64 8
  %op509 = ptrtoint ptr %gep511 to i64
  store i64 %op509, ptr %slot98, align 8
  %v512 = load i64, ptr %slot98, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i64 0, ptr %p513, align 8, !alias.scope !3, !noalias !4
  %v514 = load i64, ptr %slot97, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i32 2, ptr %p515, align 4, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot9, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i32 1, ptr %p517, align 4, !alias.scope !3, !noalias !4
  %v518 = load i64, ptr %slot17, align 8
  store i64 %v518, ptr %slot99, align 8
  %v519 = load i64, ptr %slot97, align 8
  %p521 = inttoptr i64 %v519 to ptr
  %gep522 = getelementptr i8, ptr %p521, i64 8
  %op520 = ptrtoint ptr %gep522 to i64
  store i64 %op520, ptr %slot100, align 8
  %v523 = load i64, ptr %slot27, align 8
  store i64 %v523, ptr %slot101, align 8
  %v524 = load i64, ptr %slot99, align 8
  %p525 = inttoptr i64 %v524 to ptr
  %ld526 = load i64, ptr %p525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld526, ptr %slot102, align 8
  %v527 = load i64, ptr %slot102, align 8
  %v528 = load i64, ptr %slot100, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i64 %v527, ptr %p529, align 8, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot97, align 8
  %v531 = load i64, ptr %slot17, align 8
  %p532 = inttoptr i64 %v531 to ptr
  store i64 %v530, ptr %p532, align 8, !alias.scope !3, !noalias !4
  %v533 = load i64, ptr %slot17, align 8
  %p534 = inttoptr i64 %v533 to ptr
  %ld535 = load i64, ptr %p534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld535, ptr %slot103, align 8
  %v536 = load i64, ptr %slot5, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i32, ptr %p537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld538, ptr %slot104, align 8
  %v539 = load i32, ptr %slot104, align 8
  %cv540 = zext i32 %v539 to i64
  %cond541 = icmp ne i64 %cv540, 0
  br i1 %cond541, label %bb_rcslotdrop122, label %bb_rcslotdone122
bb_rcslotdrop122:
  %v542 = load i64, ptr %slot5, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i32 0, ptr %p543, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone122
bb_rcslotdone122:
  %v544 = load i64, ptr %slot103, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ret546 = load { i64, i64 }, ptr %p545, align 8
  ret { i64, i64 } %ret546
bb_i26:
  %v547 = load i64, ptr %slot17, align 8
  %p548 = inttoptr i64 %v547 to ptr
  store i64 0, ptr %p548, align 8, !alias.scope !3, !noalias !4
  %v549 = load i64, ptr %slot21, align 8
  store i64 %v549, ptr %slot105, align 8
  %v550 = load i64, ptr %slot105, align 8
  %p551 = inttoptr i64 %v550 to ptr
  store i64 0, ptr %p551, align 8, !alias.scope !3, !noalias !4
  %v552 = load i64, ptr %slot105, align 8
  %p554 = inttoptr i64 %v552 to ptr
  %gep555 = getelementptr i8, ptr %p554, i64 8
  %op553 = ptrtoint ptr %gep555 to i64
  store i64 %op553, ptr %slot106, align 8
  %v556 = load i64, ptr %slot106, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i64 0, ptr %p557, align 8, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot105, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i32 2, ptr %p559, align 4, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot9, align 8
  %p561 = inttoptr i64 %v560 to ptr
  store i32 1, ptr %p561, align 4, !alias.scope !3, !noalias !4
  %v562 = load i64, ptr %slot17, align 8
  store i64 %v562, ptr %slot107, align 8
  %v563 = load i64, ptr %slot105, align 8
  %p565 = inttoptr i64 %v563 to ptr
  %gep566 = getelementptr i8, ptr %p565, i64 8
  %op564 = ptrtoint ptr %gep566 to i64
  store i64 %op564, ptr %slot108, align 8
  %v567 = load i64, ptr %slot27, align 8
  store i64 %v567, ptr %slot109, align 8
  %v568 = load i64, ptr %slot107, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %ld570 = load i64, ptr %p569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld570, ptr %slot110, align 8
  %v571 = load i64, ptr %slot110, align 8
  %v572 = load i64, ptr %slot108, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i64 %v571, ptr %p573, align 8, !alias.scope !3, !noalias !4
  %v574 = load i64, ptr %slot105, align 8
  %v575 = load i64, ptr %slot17, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot17, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld579, ptr %slot111, align 8
  %v580 = load i64, ptr %slot5, align 8
  %p581 = inttoptr i64 %v580 to ptr
  %ld582 = load i32, ptr %p581, align 4, !alias.scope !3, !noalias !4
  store i32 %ld582, ptr %slot112, align 8
  %v583 = load i32, ptr %slot112, align 8
  %cv584 = zext i32 %v583 to i64
  %cond585 = icmp ne i64 %cv584, 0
  br i1 %cond585, label %bb_rcslotdrop143, label %bb_rcslotdone143
bb_rcslotdrop143:
  %v586 = load i64, ptr %slot5, align 8
  %p587 = inttoptr i64 %v586 to ptr
  store i32 0, ptr %p587, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone143
bb_rcslotdone143:
  %v588 = load i64, ptr %slot111, align 8
  %p589 = inttoptr i64 %v588 to ptr
  %ret590 = load { i64, i64 }, ptr %p589, align 8
  ret { i64, i64 } %ret590
bb_failure:
  %v591 = load i64, ptr %slot4, align 8
  %p592 = inttoptr i64 %v591 to ptr
  call void @llvm.memset.p0.i64(ptr %p592, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v593 = load i64, ptr %slot4, align 8
  %p594 = inttoptr i64 %v593 to ptr
  %ret595 = load { i64, i64 }, ptr %p594, align 8
  ret { i64, i64 } %ret595
bb_entry_failure:
  %v596 = load i64, ptr %slot4, align 8
  %p597 = inttoptr i64 %v596 to ptr
  call void @llvm.memset.p0.i64(ptr %p597, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v598 = load i64, ptr %slot4, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ret600 = load { i64, i64 }, ptr %p599, align 8
  ret { i64, i64 } %ret600
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare i64 @myl_qbe_float_unary(ptr, i64, i64)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i64 @myl_qbe_region_mark(ptr)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64, i64)
declare void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_810418f65b6abfa3e5be222e74ea3bd5523e39489914cf2f5bd4c05035e84212", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_810418f65b6abfa3e5be222e74ea3bd5523e39489914cf2f5bd4c05035e84212", linkageName: "myl_f_810418f65b6abfa3e5be222e74ea3bd5523e39489914cf2f5bd4c05035e84212", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 6486337316504383715, i64 0, !"myl_f_810418f65b6abfa3e5be222e74ea3bd5523e39489914cf2f5bd4c05035e84212"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!122 = !DILocation(line: 30, column: 0, scope: !123)
