target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %p_sret, i64 %p_ctx) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %callresult26 = alloca [24 x i8], align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  %v142 = load i64, ptr %slot1, align 8
  %op143 = add i64 %v142, 32
  store i64 %op143, ptr %slot2, align 8
  %mem144 = alloca i8, i64 48, align 8
  %ptr145 = ptrtoint ptr %mem144 to i64
  store i64 %ptr145, ptr %slot3, align 8
  %mem146 = alloca i8, i64 8, align 8
  %ptr147 = ptrtoint ptr %mem146 to i64
  store i64 %ptr147, ptr %slot4, align 8
  %mem148 = alloca i8, i64 8, align 8
  %ptr149 = ptrtoint ptr %mem148 to i64
  store i64 %ptr149, ptr %slot5, align 8
  %mem150 = alloca i8, i64 8, align 8
  %ptr151 = ptrtoint ptr %mem150 to i64
  store i64 %ptr151, ptr %slot6, align 8
  %mem152 = alloca i8, i64 8, align 8
  %ptr153 = ptrtoint ptr %mem152 to i64
  store i64 %ptr153, ptr %slot7, align 8
  %mem154 = alloca i8, i64 8, align 8
  %ptr155 = ptrtoint ptr %mem154 to i64
  store i64 %ptr155, ptr %slot8, align 8
  %mem156 = alloca i8, i64 8, align 8
  %ptr157 = ptrtoint ptr %mem156 to i64
  store i64 %ptr157, ptr %slot9, align 8
  %mem158 = alloca i8, i64 8, align 8
  %ptr159 = ptrtoint ptr %mem158 to i64
  store i64 %ptr159, ptr %slot10, align 8
  %mem160 = alloca i8, i64 48, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot11, align 8
  %mem162 = alloca i8, i64 24, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot12, align 8
  %mem164 = alloca i8, i64 48, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot13, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot14, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot15, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot16, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot17, align 8
  %mem174 = alloca i8, i64 48, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot19, align 8
  %v178 = load i64, ptr %slot1, align 8
  %op179 = add i64 %v178, 64
  store i64 %op179, ptr %slot20, align 8
  %v180 = load i64, ptr %slot20, align 8
  %p181 = inttoptr i64 %v180 to ptr
  %ld182 = load i64, ptr %p181, align 8, !alias.scope !4, !noalias !3
  store i64 %ld182, ptr %slot21, align 8
  %stack183 = call ptr @llvm.stacksave()
  %stackaddr184 = ptrtoint ptr %stack183 to i64
  %v185 = load i64, ptr %slot21, align 8
  %cmp186 = icmp ult i64 %stackaddr184, %v185
  %cv187 = zext i1 %cmp186 to i64
  store i64 %cv187, ptr %slot22, align 8
  %v188 = load i64, ptr %slot22, align 8
  %cond189 = icmp ne i64 %v188, 0
  br i1 %cond189, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v190 = load i64, ptr %slot1, align 8
  %p191 = inttoptr i64 %v190 to ptr
  call void @myl_qbe_fail_frame(ptr %p191) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v192 = load i64, ptr %slot1, align 8
  %p193 = inttoptr i64 %v192 to ptr
  %call194 = call ptr @myl_qbe_heap(ptr %p193) nomerge, !dbg !112
  %calladdr195 = ptrtoint ptr %call194 to i64
  store i64 %calladdr195, ptr %slot23, align 8
  %v196 = load i64, ptr %slot1, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %call198 = call i64 @myl_qbe_region_mark(ptr %p197) nomerge, !dbg !112
  store i64 %call198, ptr %slot24, align 8
  %v199 = load i64, ptr %slot4, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i32 0, ptr %p200, align 4, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot5, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i32 0, ptr %p202, align 4, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot6, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i32 0, ptr %p204, align 4, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot7, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i32 0, ptr %p206, align 4, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot8, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i32 0, ptr %p208, align 4, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot9, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i32 0, ptr %p210, align 4, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot10, align 8
  %p212 = inttoptr i64 %v211 to ptr
  store i32 0, ptr %p212, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v213 = load i64, ptr %slot14, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i64 0, ptr %p214, align 8, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot15, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 0, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot1, align 8
  call void @myl_f_303de8965d13522a4151a6e2e522f6a03b75c7a5f48bf224980b233f4c14d7e2(ptr sret([24 x i8]) align 8 %callresult26, i64 %v217) nomerge, !dbg !114
  %addr218 = ptrtoint ptr %callresult26 to i64
  store i64 %addr218, ptr %slot25, align 8
  %v219 = load i64, ptr %slot25, align 8
  %v220 = load i64, ptr %slot16, align 8
  %p221 = inttoptr i64 %v220 to ptr
  store i64 %v219, ptr %p221, align 8, !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot16, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %ld224 = load i64, ptr %p223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld224, ptr %slot27, align 8
  %v225 = load i64, ptr %slot13, align 8
  store i64 %v225, ptr %slot28, align 8
  %v226 = load i64, ptr %slot27, align 8
  %v227 = load i64, ptr %slot28, align 8
  %p228 = inttoptr i64 %v226 to ptr
  %p229 = inttoptr i64 %v227 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p229, ptr %p228, i64 24, i1 false)
  %v230 = load i64, ptr %slot9, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i32 2, ptr %p231, align 4, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot8, align 8
  %p233 = inttoptr i64 %v232 to ptr
  store i32 1, ptr %p233, align 4, !alias.scope !3, !noalias !4
  %v234 = load i64, ptr %slot12, align 8
  store i64 %v234, ptr %slot29, align 8
  %v235 = load i64, ptr %slot13, align 8
  store i64 %v235, ptr %slot30, align 8
  %v236 = load i64, ptr %slot30, align 8
  %v237 = load i64, ptr %slot29, align 8
  %p238 = inttoptr i64 %v236 to ptr
  %p239 = inttoptr i64 %v237 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p239, ptr %p238, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v240 = load i64, ptr %slot7, align 8
  %p241 = inttoptr i64 %v240 to ptr
  store i32 2, ptr %p241, align 4, !alias.scope !3, !noalias !4
  %v242 = load i64, ptr %slot9, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %ld244 = load i32, ptr %p243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld244, ptr %slot31, align 8
  %v245 = load i32, ptr %slot31, align 8
  %v246 = load i64, ptr %slot7, align 8
  %p247 = inttoptr i64 %v246 to ptr
  store i32 %v245, ptr %p247, align 4, !alias.scope !3, !noalias !4
  %v248 = load i64, ptr %slot8, align 8
  %p249 = inttoptr i64 %v248 to ptr
  store i32 0, ptr %p249, align 4, !alias.scope !3, !noalias !4
  %v250 = load i64, ptr %slot6, align 8
  %p251 = inttoptr i64 %v250 to ptr
  store i32 1, ptr %p251, align 4, !alias.scope !3, !noalias !4
  %v252 = load i64, ptr %slot29, align 8
  %v253 = load i64, ptr %slot16, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i64 %v252, ptr %p254, align 8, !alias.scope !3, !noalias !4
  %v255 = load i64, ptr %slot17, align 8
  %p256 = inttoptr i64 %v255 to ptr
  store i64 18446744073709551615, ptr %p256, align 8, !alias.scope !3, !noalias !4
  %v257 = load i64, ptr %slot18, align 8
  store i64 %v257, ptr %slot32, align 8
  %v258 = load i64, ptr %slot32, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i64 0, ptr %p259, align 8, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot32, align 8
  %p262 = inttoptr i64 %v260 to ptr
  %gep263 = getelementptr i8, ptr %p262, i64 8
  %op261 = ptrtoint ptr %gep263 to i64
  store i64 %op261, ptr %slot33, align 8
  %v264 = load i64, ptr %slot33, align 8
  %p265 = inttoptr i64 %v264 to ptr
  store i64 0, ptr %p265, align 8, !alias.scope !3, !noalias !4
  %v266 = load i64, ptr %slot32, align 8
  %p268 = inttoptr i64 %v266 to ptr
  %gep269 = getelementptr i8, ptr %p268, i64 16
  %op267 = ptrtoint ptr %gep269 to i64
  store i64 %op267, ptr %slot34, align 8
  %v270 = load i64, ptr %slot34, align 8
  %p271 = inttoptr i64 %v270 to ptr
  store i64 0, ptr %p271, align 8, !alias.scope !3, !noalias !4
  %v272 = load i64, ptr %slot32, align 8
  %p274 = inttoptr i64 %v272 to ptr
  %gep275 = getelementptr i8, ptr %p274, i64 24
  %op273 = ptrtoint ptr %gep275 to i64
  store i64 %op273, ptr %slot35, align 8
  %v276 = load i64, ptr %slot35, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i64 0, ptr %p277, align 8, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot32, align 8
  %p280 = inttoptr i64 %v278 to ptr
  %gep281 = getelementptr i8, ptr %p280, i64 32
  %op279 = ptrtoint ptr %gep281 to i64
  store i64 %op279, ptr %slot36, align 8
  %v282 = load i64, ptr %slot36, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 0, ptr %p283, align 8, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot32, align 8
  %p286 = inttoptr i64 %v284 to ptr
  %gep287 = getelementptr i8, ptr %p286, i64 40
  %op285 = ptrtoint ptr %gep287 to i64
  store i64 %op285, ptr %slot37, align 8
  %v288 = load i64, ptr %slot37, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i64 0, ptr %p289, align 8, !alias.scope !3, !noalias !4
  %v290 = load i64, ptr %slot10, align 8
  %p291 = inttoptr i64 %v290 to ptr
  store i32 1, ptr %p291, align 4, !alias.scope !3, !noalias !4
  %v292 = load i64, ptr %slot24, align 8
  store i64 %v292, ptr %slot38, align 8
  %v293 = load i64, ptr %slot14, align 8
  store i64 %v293, ptr %slot39, align 8
  %v294 = load i64, ptr %slot32, align 8
  %p296 = inttoptr i64 %v294 to ptr
  %gep297 = getelementptr i8, ptr %p296, i64 0
  %op295 = ptrtoint ptr %gep297 to i64
  store i64 %op295, ptr %slot40, align 8
  %v298 = load i64, ptr %slot39, align 8
  %p299 = inttoptr i64 %v298 to ptr
  %ld300 = load i64, ptr %p299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld300, ptr %slot41, align 8
  %v301 = load i64, ptr %slot41, align 8
  %v302 = load i64, ptr %slot40, align 8
  %p303 = inttoptr i64 %v302 to ptr
  store i64 %v301, ptr %p303, align 8, !alias.scope !3, !noalias !4
  %v304 = load i64, ptr %slot15, align 8
  store i64 %v304, ptr %slot42, align 8
  %v305 = load i64, ptr %slot32, align 8
  %p307 = inttoptr i64 %v305 to ptr
  %gep308 = getelementptr i8, ptr %p307, i64 8
  %op306 = ptrtoint ptr %gep308 to i64
  store i64 %op306, ptr %slot43, align 8
  %v309 = load i64, ptr %slot42, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %ld311 = load i64, ptr %p310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld311, ptr %slot44, align 8
  %v312 = load i64, ptr %slot44, align 8
  %v313 = load i64, ptr %slot43, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot16, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot45, align 8
  %v318 = load i64, ptr %slot32, align 8
  %p320 = inttoptr i64 %v318 to ptr
  %gep321 = getelementptr i8, ptr %p320, i64 16
  %op319 = ptrtoint ptr %gep321 to i64
  store i64 %op319, ptr %slot46, align 8
  %v322 = load i64, ptr %slot16, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %ld324 = load i64, ptr %p323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld324, ptr %slot47, align 8
  %v325 = load i64, ptr %slot6, align 8
  %p326 = inttoptr i64 %v325 to ptr
  %ld327 = load i32, ptr %p326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld327, ptr %slot48, align 8
  %v328 = load i64, ptr %slot7, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i32, ptr %p329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld330, ptr %slot49, align 8
  %v331 = load i32, ptr %slot49, align 8
  %op332 = and i32 %v331, 24
  store i32 %op332, ptr %slot49, align 8
  %v333 = load i32, ptr %slot49, align 8
  %cmp334 = icmp eq i32 %v333, 0
  %cv335 = zext i1 %cmp334 to i32
  store i32 %cv335, ptr %slot50, align 8
  %v336 = load i32, ptr %slot48, align 8
  %v337 = load i32, ptr %slot50, align 8
  %op338 = and i32 %v336, %v337
  store i32 %op338, ptr %slot51, align 8
  %v339 = load i32, ptr %slot51, align 8
  %cv340 = zext i32 %v339 to i64
  %cond341 = icmp ne i64 %cv340, 0
  br i1 %cond341, label %bb_rctake38, label %bb_rccopy38
bb_rctake38:
  %v342 = load i64, ptr %slot13, align 8
  store i64 %v342, ptr %slot52, align 8
  %v343 = load i64, ptr %slot24, align 8
  store i64 %v343, ptr %slot53, align 8
  %v344 = load i64, ptr %slot47, align 8
  %v345 = load i64, ptr %slot52, align 8
  %op346 = sub i64 %v344, %v345
  store i64 %op346, ptr %slot54, align 8
  %v347 = load i64, ptr %slot52, align 8
  %v348 = load i64, ptr %slot47, align 8
  %op349 = sub i64 %v347, %v348
  store i64 %op349, ptr %slot55, align 8
  %v350 = load i64, ptr %slot54, align 8
  %cmp351 = icmp ult i64 %v350, 24
  %cv352 = zext i1 %cmp351 to i32
  store i32 %cv352, ptr %slot56, align 8
  %v353 = load i64, ptr %slot55, align 8
  %cmp354 = icmp ult i64 %v353, 24
  %cv355 = zext i1 %cmp354 to i32
  store i32 %cv355, ptr %slot57, align 8
  %v356 = load i32, ptr %slot56, align 8
  %v357 = load i32, ptr %slot57, align 8
  %op358 = or i32 %v356, %v357
  store i32 %op358, ptr %slot58, align 8
  %v359 = load i32, ptr %slot58, align 8
  %cv360 = zext i32 %v359 to i64
  %cond361 = icmp ne i64 %cv360, 0
  br i1 %cond361, label %bb_rcmoveslow47, label %bb_rcmovecheck47
bb_rcmovecheck47:
  %v362 = load i64, ptr %slot47, align 8
  %op363 = add i64 %v362, 0
  store i64 %op363, ptr %slot59, align 8
  %v364 = load i64, ptr %slot59, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot60, align 8
  %v367 = load i64, ptr %slot60, align 8
  %cmp368 = icmp ne i64 %v367, 0
  %cv369 = zext i1 %cmp368 to i32
  store i32 %cv369, ptr %slot61, align 8
  %v370 = load i32, ptr %slot61, align 8
  %cv371 = zext i32 %v370 to i64
  %cond372 = icmp ne i64 %cv371, 0
  br i1 %cond372, label %bb_rcmoveheader55, label %bb_rcmovenext55
bb_rcmoveheader55:
  %v373 = load i64, ptr %slot60, align 8
  %op374 = sub i64 %v373, 16
  store i64 %op374, ptr %slot62, align 8
  %v375 = load i64, ptr %slot60, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %rgep377 = getelementptr i8, ptr %p376, i64 -16
  %ld378 = load i64, ptr %rgep377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld378, ptr %slot63, align 8
  %v379 = load i64, ptr %slot63, align 8
  %op380 = and i64 %v379, 5764607523034234881
  store i64 %op380, ptr %slot64, align 8
  %v381 = load i64, ptr %slot64, align 8
  %cmp382 = icmp ne i64 %v381, 0
  %cv383 = zext i1 %cmp382 to i32
  store i32 %cv383, ptr %slot65, align 8
  %v384 = load i32, ptr %slot65, align 8
  %cv385 = zext i32 %v384 to i64
  %cond386 = icmp ne i64 %cv385, 0
  br i1 %cond386, label %bb_rcmoveslow47, label %bb_rcmovenext55
bb_rcmovenext55:
  %v387 = load i64, ptr %slot47, align 8
  %op388 = add i64 %v387, 8
  store i64 %op388, ptr %slot66, align 8
  %v389 = load i64, ptr %slot66, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %ld391 = load i64, ptr %p390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld391, ptr %slot67, align 8
  %v392 = load i64, ptr %slot67, align 8
  %cmp393 = icmp ne i64 %v392, 0
  %cv394 = zext i1 %cmp393 to i32
  store i32 %cv394, ptr %slot68, align 8
  %v395 = load i32, ptr %slot68, align 8
  %cv396 = zext i32 %v395 to i64
  %cond397 = icmp ne i64 %cv396, 0
  br i1 %cond397, label %bb_rcmoveheader63, label %bb_rcmovenext63
bb_rcmoveheader63:
  %v398 = load i64, ptr %slot67, align 8
  %op399 = sub i64 %v398, 16
  store i64 %op399, ptr %slot69, align 8
  %v400 = load i64, ptr %slot67, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %rgep402 = getelementptr i8, ptr %p401, i64 -16
  %ld403 = load i64, ptr %rgep402, align 8, !alias.scope !9, !noalias !10
  store i64 %ld403, ptr %slot70, align 8
  %v404 = load i64, ptr %slot70, align 8
  %op405 = and i64 %v404, 5764607523034234881
  store i64 %op405, ptr %slot71, align 8
  %v406 = load i64, ptr %slot71, align 8
  %cmp407 = icmp ne i64 %v406, 0
  %cv408 = zext i1 %cmp407 to i32
  store i32 %cv408, ptr %slot72, align 8
  %v409 = load i32, ptr %slot72, align 8
  %cv410 = zext i32 %v409 to i64
  %cond411 = icmp ne i64 %cv410, 0
  br i1 %cond411, label %bb_rcmoveslow47, label %bb_rcmovenext63
bb_rcmovenext63:
  %v412 = load i64, ptr %slot47, align 8
  %op413 = add i64 %v412, 16
  store i64 %op413, ptr %slot73, align 8
  %v414 = load i64, ptr %slot73, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot74, align 8
  %v417 = load i64, ptr %slot74, align 8
  %cmp418 = icmp ne i64 %v417, 0
  %cv419 = zext i1 %cmp418 to i32
  store i32 %cv419, ptr %slot75, align 8
  %v420 = load i32, ptr %slot75, align 8
  %cv421 = zext i32 %v420 to i64
  %cond422 = icmp ne i64 %cv421, 0
  br i1 %cond422, label %bb_rcmoveheader71, label %bb_rcmovenext71
bb_rcmoveheader71:
  %v423 = load i64, ptr %slot74, align 8
  %op424 = sub i64 %v423, 16
  store i64 %op424, ptr %slot76, align 8
  %v425 = load i64, ptr %slot74, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %rgep427 = getelementptr i8, ptr %p426, i64 -16
  %ld428 = load i64, ptr %rgep427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld428, ptr %slot77, align 8
  %v429 = load i64, ptr %slot77, align 8
  %op430 = and i64 %v429, 5764607523034234881
  store i64 %op430, ptr %slot78, align 8
  %v431 = load i64, ptr %slot78, align 8
  %cmp432 = icmp ne i64 %v431, 0
  %cv433 = zext i1 %cmp432 to i32
  store i32 %cv433, ptr %slot79, align 8
  %v434 = load i32, ptr %slot79, align 8
  %cv435 = zext i32 %v434 to i64
  %cond436 = icmp ne i64 %cv435, 0
  br i1 %cond436, label %bb_rcmoveslow47, label %bb_rcmovenext71
bb_rcmovenext71:
  %v437 = load i64, ptr %slot47, align 8
  %v438 = load i64, ptr %slot52, align 8
  %p439 = inttoptr i64 %v437 to ptr
  %p440 = inttoptr i64 %v438 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p440, ptr %p439, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot47, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i64 0, ptr %p442, align 8, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot47, align 8
  %op444 = add i64 %v443, 8
  store i64 %op444, ptr %slot80, align 8
  %v445 = load i64, ptr %slot80, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i64 0, ptr %p446, align 8, !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot47, align 8
  %op448 = add i64 %v447, 16
  store i64 %op448, ptr %slot81, align 8
  %v449 = load i64, ptr %slot81, align 8
  %p450 = inttoptr i64 %v449 to ptr
  store i64 0, ptr %p450, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved47
bb_rcmoveslow47:
  %v451 = load i64, ptr %slot23, align 8
  %v452 = load i64, ptr %slot52, align 8
  %v453 = load i64, ptr %slot47, align 8
  %v454 = load i64, ptr %slot53, align 8
  %cv455 = trunc i64 %v454 to i32
  %call456 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v451, i64 %v452, i64 %v453, i32 %cv455) nomerge, !dbg !116
  store i32 %call456, ptr %slot82, align 8
  %v457 = load i32, ptr %slot82, align 8
  %cv458 = zext i32 %v457 to i64
  %cond459 = icmp ne i64 %cv458, 0
  br i1 %cond459, label %bb_rcsuccess80, label %bb_rcfailure80
bb_rcfailure80:
  %v460 = load i64, ptr %slot23, align 8
  %p461 = inttoptr i64 %v460 to ptr
  %call462 = call i32 @myl_rc_take_failure(ptr %p461) nomerge, !dbg !116
  store i32 %call462, ptr %slot83, align 8
  %v463 = load i64, ptr %slot1, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %v465 = load i32, ptr %slot83, align 8
  %call466 = call i32 @myl_qbe_rc_status(ptr %p464, i32 %v465) nomerge, !dbg !116
  store i32 %call466, ptr %slot84, align 8
  br label %bb_failure
bb_rcsuccess80:
  br label %bb_rcmoved47
bb_rcmoved47:
  %v467 = load i64, ptr %slot6, align 8
  %p468 = inttoptr i64 %v467 to ptr
  store i32 0, ptr %p468, align 4, !alias.scope !3, !noalias !4
  %v469 = load i64, ptr %slot9, align 8
  %p470 = inttoptr i64 %v469 to ptr
  store i32 2, ptr %p470, align 4, !alias.scope !3, !noalias !4
  %v471 = load i64, ptr %slot8, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i32 1, ptr %p472, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared38
bb_rccopy38:
  %v473 = load i64, ptr %slot13, align 8
  store i64 %v473, ptr %slot85, align 8
  %v474 = load i64, ptr %slot24, align 8
  store i64 %v474, ptr %slot86, align 8
  %v475 = load i64, ptr %slot23, align 8
  %v476 = load i64, ptr %slot85, align 8
  %v477 = load i64, ptr %slot47, align 8
  %v478 = load i64, ptr %slot86, align 8
  %cv479 = trunc i64 %v478 to i32
  %call480 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_retain(i64 %v475, i64 %v476, i64 %v477, i32 %cv479) nomerge, !dbg !116
  store i32 %call480, ptr %slot87, align 8
  %v481 = load i32, ptr %slot87, align 8
  %cv482 = zext i32 %v481 to i64
  %cond483 = icmp ne i64 %cv482, 0
  br i1 %cond483, label %bb_rcsuccess89, label %bb_rcfailure89
bb_rcfailure89:
  %v484 = load i64, ptr %slot23, align 8
  %p485 = inttoptr i64 %v484 to ptr
  %call486 = call i32 @myl_rc_take_failure(ptr %p485) nomerge, !dbg !116
  store i32 %call486, ptr %slot88, align 8
  %v487 = load i64, ptr %slot1, align 8
  %p488 = inttoptr i64 %v487 to ptr
  %v489 = load i32, ptr %slot88, align 8
  %call490 = call i32 @myl_qbe_rc_status(ptr %p488, i32 %v489) nomerge, !dbg !116
  store i32 %call490, ptr %slot89, align 8
  br label %bb_failure
bb_rcsuccess89:
  %v491 = load i64, ptr %slot9, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i32 2, ptr %p492, align 4, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot8, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i32 1, ptr %p494, align 4, !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot6, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %ld497 = load i32, ptr %p496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld497, ptr %slot90, align 8
  %v498 = load i32, ptr %slot90, align 8
  %cv499 = zext i32 %v498 to i64
  %cond500 = icmp ne i64 %cv499, 0
  br i1 %cond500, label %bb_rcslotdrop96, label %bb_rcslotdone96
bb_rcslotdrop96:
  %v501 = load i64, ptr %slot6, align 8
  %p502 = inttoptr i64 %v501 to ptr
  store i32 0, ptr %p502, align 4, !alias.scope !3, !noalias !4
  %v503 = load i64, ptr %slot12, align 8
  store i64 %v503, ptr %slot91, align 8
  %v504 = load i64, ptr %slot7, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i32, ptr %p505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld506, ptr %slot92, align 8
  %v507 = load i32, ptr %slot92, align 8
  %op508 = and i32 %v507, 28
  store i32 %op508, ptr %slot93, align 8
  %v509 = load i32, ptr %slot93, align 8
  %cv510 = zext i32 %v509 to i64
  %cond511 = icmp ne i64 %cv510, 0
  br i1 %cond511, label %bb_rcslotrole96, label %bb_rcslotowner96
bb_rcslotrole96:
  %v512 = load i64, ptr %slot23, align 8
  store i64 %v512, ptr %slot94, align 8
  %v513 = load i64, ptr %slot94, align 8
  %v514 = load i64, ptr %slot91, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v513, i64 %v514) nomerge, !dbg !116
  br label %bb_rcslotdone96
bb_rcslotowner96:
  %v515 = load i64, ptr %slot23, align 8
  store i64 %v515, ptr %slot95, align 8
  %v516 = load i64, ptr %slot95, align 8
  %v517 = load i64, ptr %slot91, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v516, i64 %v517) nomerge, !dbg !116
  br label %bb_rcslotdone96
bb_rcslotdone96:
  br label %bb_rcprepared38
bb_rcprepared38:
  %v518 = load i64, ptr %slot13, align 8
  store i64 %v518, ptr %slot96, align 8
  %v519 = load i64, ptr %slot96, align 8
  %v520 = load i64, ptr %slot46, align 8
  %p521 = inttoptr i64 %v519 to ptr
  %p522 = inttoptr i64 %v520 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p522, ptr %p521, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot8, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 0, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot17, align 8
  store i64 %v525, ptr %slot97, align 8
  %v526 = load i64, ptr %slot32, align 8
  %p528 = inttoptr i64 %v526 to ptr
  %gep529 = getelementptr i8, ptr %p528, i64 40
  %op527 = ptrtoint ptr %gep529 to i64
  store i64 %op527, ptr %slot98, align 8
  %v530 = load i64, ptr %slot97, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot99, align 8
  %v533 = load i64, ptr %slot99, align 8
  %v534 = load i64, ptr %slot98, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot32, align 8
  %v537 = load i64, ptr %slot14, align 8
  %p538 = inttoptr i64 %v537 to ptr
  store i64 %v536, ptr %p538, align 8, !alias.scope !3, !noalias !4
  %v539 = load i64, ptr %slot14, align 8
  %p540 = inttoptr i64 %v539 to ptr
  %ld541 = load i64, ptr %p540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld541, ptr %slot100, align 8
  %v542 = load i64, ptr %slot11, align 8
  store i64 %v542, ptr %slot101, align 8
  %v543 = load i64, ptr %slot100, align 8
  %v544 = load i64, ptr %slot101, align 8
  %p545 = inttoptr i64 %v543 to ptr
  %p546 = inttoptr i64 %v544 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p546, ptr %p545, i64 48, i1 false)
  %v547 = load i64, ptr %slot5, align 8
  %p548 = inttoptr i64 %v547 to ptr
  store i32 2, ptr %p548, align 4, !alias.scope !3, !noalias !4
  %v549 = load i64, ptr %slot4, align 8
  %p550 = inttoptr i64 %v549 to ptr
  store i32 1, ptr %p550, align 4, !alias.scope !3, !noalias !4
  %v551 = load i64, ptr %slot101, align 8
  %v552 = load i64, ptr %slot14, align 8
  %p553 = inttoptr i64 %v552 to ptr
  store i64 %v551, ptr %p553, align 8, !alias.scope !3, !noalias !4
  %v554 = load i64, ptr %slot14, align 8
  %p555 = inttoptr i64 %v554 to ptr
  %ld556 = load i64, ptr %p555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld556, ptr %slot102, align 8
  %v557 = load i64, ptr %slot14, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i64, ptr %p558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld559, ptr %slot103, align 8
  %v560 = load i64, ptr %slot13, align 8
  store i64 %v560, ptr %slot104, align 8
  %v561 = load i64, ptr %slot24, align 8
  store i64 %v561, ptr %slot105, align 8
  %v562 = load i64, ptr %slot103, align 8
  %op563 = add i64 %v562, 16
  store i64 %op563, ptr %slot106, align 8
  %v564 = load i64, ptr %slot106, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %ld566 = load i64, ptr %p565, align 8
  store i64 %ld566, ptr %slot107, align 8
  %v567 = load i64, ptr %slot107, align 8
  %cmp568 = icmp ne i64 %v567, 0
  %cv569 = zext i1 %cmp568 to i32
  store i32 %cv569, ptr %slot108, align 8
  %v570 = load i32, ptr %slot108, align 8
  %cv571 = zext i32 %v570 to i64
  %cond572 = icmp ne i64 %cv571, 0
  br i1 %cond572, label %bb_rcmoveheader119, label %bb_rcmovenext119
bb_rcmoveheader119:
  %v573 = load i64, ptr %slot107, align 8
  %op574 = sub i64 %v573, 16
  store i64 %op574, ptr %slot109, align 8
  %v575 = load i64, ptr %slot107, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %rgep577 = getelementptr i8, ptr %p576, i64 -16
  %ld578 = load i64, ptr %rgep577, align 8, !alias.scope !9, !noalias !10
  store i64 %ld578, ptr %slot110, align 8
  %v579 = load i64, ptr %slot110, align 8
  %op580 = and i64 %v579, 5764607523034234881
  store i64 %op580, ptr %slot111, align 8
  %v581 = load i64, ptr %slot111, align 8
  %cmp582 = icmp ne i64 %v581, 0
  %cv583 = zext i1 %cmp582 to i32
  store i32 %cv583, ptr %slot112, align 8
  %v584 = load i32, ptr %slot112, align 8
  %cv585 = zext i32 %v584 to i64
  %cond586 = icmp ne i64 %cv585, 0
  br i1 %cond586, label %bb_rcmoveslow116, label %bb_rcmovenext119
bb_rcmovenext119:
  %v587 = load i64, ptr %slot103, align 8
  %op588 = add i64 %v587, 24
  store i64 %op588, ptr %slot113, align 8
  %v589 = load i64, ptr %slot113, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i64, ptr %p590, align 8
  store i64 %ld591, ptr %slot114, align 8
  %v592 = load i64, ptr %slot114, align 8
  %cmp593 = icmp ne i64 %v592, 0
  %cv594 = zext i1 %cmp593 to i32
  store i32 %cv594, ptr %slot115, align 8
  %v595 = load i32, ptr %slot115, align 8
  %cv596 = zext i32 %v595 to i64
  %cond597 = icmp ne i64 %cv596, 0
  br i1 %cond597, label %bb_rcmoveheader127, label %bb_rcmovenext127
bb_rcmoveheader127:
  %v598 = load i64, ptr %slot114, align 8
  %op599 = sub i64 %v598, 16
  store i64 %op599, ptr %slot116, align 8
  %v600 = load i64, ptr %slot114, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %rgep602 = getelementptr i8, ptr %p601, i64 -16
  %ld603 = load i64, ptr %rgep602, align 8, !alias.scope !9, !noalias !10
  store i64 %ld603, ptr %slot117, align 8
  %v604 = load i64, ptr %slot117, align 8
  %op605 = and i64 %v604, 5764607523034234881
  store i64 %op605, ptr %slot118, align 8
  %v606 = load i64, ptr %slot118, align 8
  %cmp607 = icmp ne i64 %v606, 0
  %cv608 = zext i1 %cmp607 to i32
  store i32 %cv608, ptr %slot119, align 8
  %v609 = load i32, ptr %slot119, align 8
  %cv610 = zext i32 %v609 to i64
  %cond611 = icmp ne i64 %cv610, 0
  br i1 %cond611, label %bb_rcmoveslow116, label %bb_rcmovenext127
bb_rcmovenext127:
  %v612 = load i64, ptr %slot103, align 8
  %op613 = add i64 %v612, 32
  store i64 %op613, ptr %slot120, align 8
  %v614 = load i64, ptr %slot120, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %ld616 = load i64, ptr %p615, align 8
  store i64 %ld616, ptr %slot121, align 8
  %v617 = load i64, ptr %slot121, align 8
  %cmp618 = icmp ne i64 %v617, 0
  %cv619 = zext i1 %cmp618 to i32
  store i32 %cv619, ptr %slot122, align 8
  %v620 = load i32, ptr %slot122, align 8
  %cv621 = zext i32 %v620 to i64
  %cond622 = icmp ne i64 %cv621, 0
  br i1 %cond622, label %bb_rcmoveheader135, label %bb_rcmovenext135
bb_rcmoveheader135:
  %v623 = load i64, ptr %slot121, align 8
  %op624 = sub i64 %v623, 16
  store i64 %op624, ptr %slot123, align 8
  %v625 = load i64, ptr %slot121, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %rgep627 = getelementptr i8, ptr %p626, i64 -16
  %ld628 = load i64, ptr %rgep627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld628, ptr %slot124, align 8
  %v629 = load i64, ptr %slot124, align 8
  %op630 = and i64 %v629, 5764607523034234881
  store i64 %op630, ptr %slot125, align 8
  %v631 = load i64, ptr %slot125, align 8
  %cmp632 = icmp ne i64 %v631, 0
  %cv633 = zext i1 %cmp632 to i32
  store i32 %cv633, ptr %slot126, align 8
  %v634 = load i32, ptr %slot126, align 8
  %cv635 = zext i32 %v634 to i64
  %cond636 = icmp ne i64 %cv635, 0
  br i1 %cond636, label %bb_rcmoveslow116, label %bb_rcmovenext135
bb_rcmovenext135:
  %v637 = load i64, ptr %slot103, align 8
  %v638 = load i64, ptr %slot104, align 8
  %p639 = inttoptr i64 %v637 to ptr
  %p640 = inttoptr i64 %v638 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p640, ptr %p639, i64 48, i1 false)
  %v641 = load i64, ptr %slot103, align 8
  %p642 = inttoptr i64 %v641 to ptr
  store i64 0, ptr %p642, align 8
  %v643 = load i64, ptr %slot103, align 8
  %op644 = add i64 %v643, 8
  store i64 %op644, ptr %slot127, align 8
  %v645 = load i64, ptr %slot127, align 8
  %p646 = inttoptr i64 %v645 to ptr
  store i64 0, ptr %p646, align 8
  %v647 = load i64, ptr %slot103, align 8
  %op648 = add i64 %v647, 16
  store i64 %op648, ptr %slot128, align 8
  %v649 = load i64, ptr %slot128, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i64 0, ptr %p650, align 8
  %v651 = load i64, ptr %slot103, align 8
  %op652 = add i64 %v651, 24
  store i64 %op652, ptr %slot129, align 8
  %v653 = load i64, ptr %slot129, align 8
  %p654 = inttoptr i64 %v653 to ptr
  store i64 0, ptr %p654, align 8
  %v655 = load i64, ptr %slot103, align 8
  %op656 = add i64 %v655, 32
  store i64 %op656, ptr %slot130, align 8
  %v657 = load i64, ptr %slot130, align 8
  %p658 = inttoptr i64 %v657 to ptr
  store i64 0, ptr %p658, align 8
  %v659 = load i64, ptr %slot103, align 8
  %op660 = add i64 %v659, 40
  store i64 %op660, ptr %slot131, align 8
  %v661 = load i64, ptr %slot131, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 0, ptr %p662, align 8
  br label %bb_rcmoved116
bb_rcmoveslow116:
  %v663 = load i64, ptr %slot23, align 8
  %v664 = load i64, ptr %slot104, align 8
  %v665 = load i64, ptr %slot103, align 8
  %v666 = load i64, ptr %slot105, align 8
  %cv667 = trunc i64 %v666 to i32
  %call668 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v663, i64 %v664, i64 %v665, i32 %cv667) nomerge, !dbg !118
  store i32 %call668, ptr %slot132, align 8
  %v669 = load i32, ptr %slot132, align 8
  %cv670 = zext i32 %v669 to i64
  %cond671 = icmp ne i64 %cv670, 0
  br i1 %cond671, label %bb_rcsuccess147, label %bb_rcfailure147
bb_rcfailure147:
  %v672 = load i64, ptr %slot23, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %call674 = call i32 @myl_rc_take_failure(ptr %p673) nomerge, !dbg !118
  store i32 %call674, ptr %slot133, align 8
  %v675 = load i64, ptr %slot1, align 8
  %p676 = inttoptr i64 %v675 to ptr
  %v677 = load i32, ptr %slot133, align 8
  %call678 = call i32 @myl_qbe_rc_status(ptr %p676, i32 %v677) nomerge, !dbg !118
  store i32 %call678, ptr %slot134, align 8
  br label %bb_failure
bb_rcsuccess147:
  br label %bb_rcmoved116
bb_rcmoved116:
  %v679 = load i64, ptr %slot4, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i32 0, ptr %p680, align 4, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot9, align 8
  %p682 = inttoptr i64 %v681 to ptr
  store i32 2, ptr %p682, align 4, !alias.scope !3, !noalias !4
  %v683 = load i64, ptr %slot8, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i32 1, ptr %p684, align 4, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot13, align 8
  store i64 %v685, ptr %slot135, align 8
  %v686 = load i64, ptr %slot8, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i32 0, ptr %p687, align 4, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot4, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i32, ptr %p689, align 4, !alias.scope !3, !noalias !4
  store i32 %ld690, ptr %slot136, align 8
  %v691 = load i32, ptr %slot136, align 8
  %cv692 = zext i32 %v691 to i64
  %cond693 = icmp ne i64 %cv692, 0
  br i1 %cond693, label %bb_rcslotdrop157, label %bb_rcslotdone157
bb_rcslotdrop157:
  %v694 = load i64, ptr %slot4, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i32 0, ptr %p695, align 4, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot11, align 8
  store i64 %v696, ptr %slot137, align 8
  %v697 = load i64, ptr %slot5, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i32, ptr %p698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld699, ptr %slot138, align 8
  %v700 = load i32, ptr %slot138, align 8
  %op701 = and i32 %v700, 28
  store i32 %op701, ptr %slot139, align 8
  %v702 = load i32, ptr %slot139, align 8
  %cv703 = zext i32 %v702 to i64
  %cond704 = icmp ne i64 %cv703, 0
  br i1 %cond704, label %bb_rcslotrole157, label %bb_rcslotowner157
bb_rcslotrole157:
  %v705 = load i64, ptr %slot23, align 8
  store i64 %v705, ptr %slot140, align 8
  %v706 = load i64, ptr %slot140, align 8
  %v707 = load i64, ptr %slot137, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v706, i64 %v707) nomerge, !dbg !118
  br label %bb_rcslotdone157
bb_rcslotowner157:
  %v708 = load i64, ptr %slot23, align 8
  store i64 %v708, ptr %slot141, align 8
  %v709 = load i64, ptr %slot141, align 8
  %v710 = load i64, ptr %slot137, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v709, i64 %v710) nomerge, !dbg !118
  br label %bb_rcslotdone157
bb_rcslotdone157:
  %v711 = load i64, ptr %slot135, align 8
  %p712 = inttoptr i64 %v711 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p712, i64 48, i1 false)
  ret void
bb_failure:
  %v713 = load i64, ptr %slot3, align 8
  %p714 = inttoptr i64 %v713 to ptr
  call void @llvm.memset.p0.i64(ptr %p714, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v715 = load i64, ptr %slot3, align 8
  %p716 = inttoptr i64 %v715 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p716, i64 48, i1 false)
  ret void
bb_entry_failure:
  %v717 = load i64, ptr %slot3, align 8
  %p718 = inttoptr i64 %v717 to ptr
  call void @llvm.memset.p0.i64(ptr %p718, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v719 = load i64, ptr %slot3, align 8
  %p720 = inttoptr i64 %v719 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p720, i64 48, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_303de8965d13522a4151a6e2e522f6a03b75c7a5f48bf224980b233f4c14d7e2(ptr sret([24 x i8]) align 8, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c", linkageName: "myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1164598878298259422, i64 0, !"myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
