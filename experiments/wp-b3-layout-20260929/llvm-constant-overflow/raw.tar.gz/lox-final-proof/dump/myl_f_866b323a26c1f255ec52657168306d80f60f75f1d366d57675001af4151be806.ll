target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %callresult311 = alloca [24 x i8], align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %callresult362 = alloca [24 x i8], align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %callresult460 = alloca [24 x i8], align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %callresult511 = alloca [24 x i8], align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %callresult561 = alloca [24 x i8], align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %callresult612 = alloca [24 x i8], align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %callresult662 = alloca [24 x i8], align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %callresult712 = alloca [24 x i8], align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %callresult762 = alloca [24 x i8], align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i32, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i32, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i32, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v849 = load i64, ptr %slot1, align 8
  %op850 = add i64 %v849, 32
  store i64 %op850, ptr %slot4, align 8
  %mem851 = alloca i8, i64 24, align 8
  %ptr852 = ptrtoint ptr %mem851 to i64
  store i64 %ptr852, ptr %slot5, align 8
  %mem853 = alloca i8, i64 8, align 8
  %ptr854 = ptrtoint ptr %mem853 to i64
  store i64 %ptr854, ptr %slot6, align 8
  %mem855 = alloca i8, i64 8, align 8
  %ptr856 = ptrtoint ptr %mem855 to i64
  store i64 %ptr856, ptr %slot7, align 8
  %mem857 = alloca i8, i64 8, align 8
  %ptr858 = ptrtoint ptr %mem857 to i64
  store i64 %ptr858, ptr %slot8, align 8
  %mem859 = alloca i8, i64 8, align 8
  %ptr860 = ptrtoint ptr %mem859 to i64
  store i64 %ptr860, ptr %slot9, align 8
  %mem861 = alloca i8, i64 8, align 8
  %ptr862 = ptrtoint ptr %mem861 to i64
  store i64 %ptr862, ptr %slot10, align 8
  %mem863 = alloca i8, i64 8, align 8
  %ptr864 = ptrtoint ptr %mem863 to i64
  store i64 %ptr864, ptr %slot11, align 8
  %mem865 = alloca i8, i64 8, align 8
  %ptr866 = ptrtoint ptr %mem865 to i64
  store i64 %ptr866, ptr %slot12, align 8
  %mem867 = alloca i8, i64 8, align 8
  %ptr868 = ptrtoint ptr %mem867 to i64
  store i64 %ptr868, ptr %slot13, align 8
  %mem869 = alloca i8, i64 8, align 8
  %ptr870 = ptrtoint ptr %mem869 to i64
  store i64 %ptr870, ptr %slot14, align 8
  %mem871 = alloca i8, i64 8, align 8
  %ptr872 = ptrtoint ptr %mem871 to i64
  store i64 %ptr872, ptr %slot15, align 8
  %mem873 = alloca i8, i64 8, align 8
  %ptr874 = ptrtoint ptr %mem873 to i64
  store i64 %ptr874, ptr %slot16, align 8
  %mem875 = alloca i8, i64 304, align 8
  %ptr876 = ptrtoint ptr %mem875 to i64
  store i64 %ptr876, ptr %slot17, align 8
  %mem877 = alloca i8, i64 304, align 8
  %ptr878 = ptrtoint ptr %mem877 to i64
  store i64 %ptr878, ptr %slot18, align 8
  %mem879 = alloca i8, i64 8, align 8
  %ptr880 = ptrtoint ptr %mem879 to i64
  store i64 %ptr880, ptr %slot19, align 8
  %mem881 = alloca i8, i64 8, align 8
  %ptr882 = ptrtoint ptr %mem881 to i64
  store i64 %ptr882, ptr %slot20, align 8
  %mem883 = alloca i8, i64 8, align 8
  %ptr884 = ptrtoint ptr %mem883 to i64
  store i64 %ptr884, ptr %slot21, align 8
  %mem885 = alloca i8, i64 8, align 8
  %ptr886 = ptrtoint ptr %mem885 to i64
  store i64 %ptr886, ptr %slot22, align 8
  %mem887 = alloca i8, i64 16, align 8
  %ptr888 = ptrtoint ptr %mem887 to i64
  store i64 %ptr888, ptr %slot23, align 8
  %mem889 = alloca i8, i64 8, align 8
  %ptr890 = ptrtoint ptr %mem889 to i64
  store i64 %ptr890, ptr %slot24, align 8
  %mem891 = alloca i8, i64 8, align 8
  %ptr892 = ptrtoint ptr %mem891 to i64
  store i64 %ptr892, ptr %slot25, align 8
  %mem893 = alloca i8, i64 32, align 8
  %ptr894 = ptrtoint ptr %mem893 to i64
  store i64 %ptr894, ptr %slot26, align 8
  %mem895 = alloca i8, i64 8, align 8
  %ptr896 = ptrtoint ptr %mem895 to i64
  store i64 %ptr896, ptr %slot27, align 8
  %mem897 = alloca i8, i64 56, align 8
  %ptr898 = ptrtoint ptr %mem897 to i64
  store i64 %ptr898, ptr %slot28, align 8
  %mem899 = alloca i8, i64 72, align 8
  %ptr900 = ptrtoint ptr %mem899 to i64
  store i64 %ptr900, ptr %slot29, align 8
  %mem901 = alloca i8, i64 16, align 8
  %ptr902 = ptrtoint ptr %mem901 to i64
  store i64 %ptr902, ptr %slot30, align 8
  %mem903 = alloca i8, i64 8, align 8
  %ptr904 = ptrtoint ptr %mem903 to i64
  store i64 %ptr904, ptr %slot31, align 8
  %mem905 = alloca i8, i64 8, align 8
  %ptr906 = ptrtoint ptr %mem905 to i64
  store i64 %ptr906, ptr %slot32, align 8
  %mem907 = alloca i8, i64 8, align 8
  %ptr908 = ptrtoint ptr %mem907 to i64
  store i64 %ptr908, ptr %slot33, align 8
  %mem909 = alloca i8, i64 24, align 8
  %ptr910 = ptrtoint ptr %mem909 to i64
  store i64 %ptr910, ptr %slot34, align 8
  %mem911 = alloca i8, i64 8, align 8
  %ptr912 = ptrtoint ptr %mem911 to i64
  store i64 %ptr912, ptr %slot35, align 8
  %mem913 = alloca i8, i64 24, align 8
  %ptr914 = ptrtoint ptr %mem913 to i64
  store i64 %ptr914, ptr %slot36, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem915 = alloca i8, i64 8, align 8
  %ptr916 = ptrtoint ptr %mem915 to i64
  store i64 %ptr916, ptr %slot37, align 8
  %v917 = load i64, ptr %slot1, align 8
  %op918 = add i64 %v917, 64
  store i64 %op918, ptr %slot38, align 8
  %v919 = load i64, ptr %slot38, align 8
  %p920 = inttoptr i64 %v919 to ptr
  %ld921 = load i64, ptr %p920, align 8, !alias.scope !4, !noalias !3
  store i64 %ld921, ptr %slot39, align 8
  %stack922 = call ptr @llvm.stacksave()
  %stackaddr923 = ptrtoint ptr %stack922 to i64
  %v924 = load i64, ptr %slot39, align 8
  %cmp925 = icmp ult i64 %stackaddr923, %v924
  %cv926 = zext i1 %cmp925 to i64
  store i64 %cv926, ptr %slot40, align 8
  %v927 = load i64, ptr %slot40, align 8
  %cond928 = icmp ne i64 %v927, 0
  br i1 %cond928, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v929 = load i64, ptr %slot1, align 8
  %p930 = inttoptr i64 %v929 to ptr
  call void @myl_qbe_fail_frame(ptr %p930) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v931 = load i64, ptr %slot21, align 8
  %p932 = inttoptr i64 %v931 to ptr
  store i64 0, ptr %p932, align 8, !alias.scope !3, !noalias !4
  %v933 = load i64, ptr %slot2, align 8
  %v934 = load i64, ptr %slot19, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i64 %v933, ptr %p935, align 8, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot3, align 8
  %v937 = load i64, ptr %slot20, align 8
  %p938 = inttoptr i64 %v937 to ptr
  store i64 %v936, ptr %p938, align 8, !alias.scope !3, !noalias !4
  %v939 = load i64, ptr %slot1, align 8
  %p940 = inttoptr i64 %v939 to ptr
  %call941 = call ptr @myl_qbe_heap(ptr %p940) nomerge, !dbg !112
  %calladdr942 = ptrtoint ptr %call941 to i64
  store i64 %calladdr942, ptr %slot41, align 8
  %v943 = load i64, ptr %slot1, align 8
  %p944 = inttoptr i64 %v943 to ptr
  %call945 = call i64 @myl_qbe_region_mark(ptr %p944) nomerge, !dbg !112
  store i64 %call945, ptr %slot42, align 8
  %v946 = load i64, ptr %slot6, align 8
  %p947 = inttoptr i64 %v946 to ptr
  store i32 0, ptr %p947, align 4, !alias.scope !3, !noalias !4
  %v948 = load i64, ptr %slot7, align 8
  %p949 = inttoptr i64 %v948 to ptr
  store i32 0, ptr %p949, align 4, !alias.scope !3, !noalias !4
  %v950 = load i64, ptr %slot8, align 8
  %p951 = inttoptr i64 %v950 to ptr
  store i32 0, ptr %p951, align 4, !alias.scope !3, !noalias !4
  %v952 = load i64, ptr %slot9, align 8
  %p953 = inttoptr i64 %v952 to ptr
  store i32 0, ptr %p953, align 4, !alias.scope !3, !noalias !4
  %v954 = load i64, ptr %slot10, align 8
  %p955 = inttoptr i64 %v954 to ptr
  store i32 0, ptr %p955, align 4, !alias.scope !3, !noalias !4
  %v956 = load i64, ptr %slot11, align 8
  %p957 = inttoptr i64 %v956 to ptr
  store i32 0, ptr %p957, align 4, !alias.scope !3, !noalias !4
  %v958 = load i64, ptr %slot12, align 8
  %p959 = inttoptr i64 %v958 to ptr
  store i32 0, ptr %p959, align 4, !alias.scope !3, !noalias !4
  %v960 = load i64, ptr %slot13, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i32 0, ptr %p961, align 4, !alias.scope !3, !noalias !4
  %v962 = load i64, ptr %slot14, align 8
  %p963 = inttoptr i64 %v962 to ptr
  store i32 0, ptr %p963, align 4, !alias.scope !3, !noalias !4
  %v964 = load i64, ptr %slot15, align 8
  %p965 = inttoptr i64 %v964 to ptr
  store i32 0, ptr %p965, align 4, !alias.scope !3, !noalias !4
  %v966 = load i64, ptr %slot16, align 8
  %p967 = inttoptr i64 %v966 to ptr
  store i32 0, ptr %p967, align 4, !alias.scope !3, !noalias !4
  %v968 = load i64, ptr %slot7, align 8
  %p969 = inttoptr i64 %v968 to ptr
  store i32 2, ptr %p969, align 4, !alias.scope !3, !noalias !4
  %v970 = load i64, ptr %slot9, align 8
  %p971 = inttoptr i64 %v970 to ptr
  store i32 2, ptr %p971, align 4, !alias.scope !3, !noalias !4
  %v972 = load i64, ptr %slot11, align 8
  %p973 = inttoptr i64 %v972 to ptr
  store i32 2, ptr %p973, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v974 = load i64, ptr %slot19, align 8
  %p975 = inttoptr i64 %v974 to ptr
  %ld976 = load i64, ptr %p975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld976, ptr %slot43, align 8
  %v977 = load i64, ptr %slot43, align 8
  %v978 = load i64, ptr %slot31, align 8
  %p979 = inttoptr i64 %v978 to ptr
  store i64 %v977, ptr %p979, align 8, !alias.scope !3, !noalias !4
  %v980 = load i64, ptr %slot31, align 8
  %p981 = inttoptr i64 %v980 to ptr
  %ld982 = load i64, ptr %p981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld982, ptr %slot44, align 8
  %v983 = load i64, ptr %slot44, align 8
  %op984 = add i64 %v983, 0
  store i64 %op984, ptr %slot45, align 8
  %v985 = load i64, ptr %slot45, align 8
  %v986 = load i64, ptr %slot31, align 8
  %p987 = inttoptr i64 %v986 to ptr
  store i64 %v985, ptr %p987, align 8, !alias.scope !3, !noalias !4
  %v988 = load i64, ptr %slot12, align 8
  %p989 = inttoptr i64 %v988 to ptr
  %ld990 = load i32, ptr %p989, align 4, !alias.scope !3, !noalias !4
  store i32 %ld990, ptr %slot46, align 8
  %v991 = load i32, ptr %slot46, align 8
  %cv992 = zext i32 %v991 to i64
  %cond993 = icmp ne i64 %cv992, 0
  br i1 %cond993, label %bb_rcslotdrop17, label %bb_rcslotdone17
bb_rcslotdrop17:
  %v994 = load i64, ptr %slot12, align 8
  %p995 = inttoptr i64 %v994 to ptr
  store i32 0, ptr %p995, align 4, !alias.scope !3, !noalias !4
  %v996 = load i64, ptr %slot17, align 8
  store i64 %v996, ptr %slot47, align 8
  %v997 = load i64, ptr %slot13, align 8
  %p998 = inttoptr i64 %v997 to ptr
  %ld999 = load i32, ptr %p998, align 4, !alias.scope !3, !noalias !4
  store i32 %ld999, ptr %slot48, align 8
  %v1000 = load i32, ptr %slot48, align 8
  %op1001 = and i32 %v1000, 28
  store i32 %op1001, ptr %slot49, align 8
  %v1002 = load i32, ptr %slot49, align 8
  %cv1003 = zext i32 %v1002 to i64
  %cond1004 = icmp ne i64 %cv1003, 0
  br i1 %cond1004, label %bb_rcslotrole17, label %bb_rcslotowner17
bb_rcslotrole17:
  %v1005 = load i64, ptr %slot41, align 8
  store i64 %v1005, ptr %slot50, align 8
  %v1006 = load i64, ptr %slot50, align 8
  %v1007 = load i64, ptr %slot47, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1006, i64 %v1007) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotowner17:
  %v1008 = load i64, ptr %slot41, align 8
  store i64 %v1008, ptr %slot51, align 8
  %v1009 = load i64, ptr %slot51, align 8
  %v1010 = load i64, ptr %slot47, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1009, i64 %v1010) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotdone17:
  %v1011 = load i64, ptr %slot31, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  %ld1013 = load i64, ptr %p1012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1013, ptr %slot52, align 8
  %v1014 = load i64, ptr %slot52, align 8
  %op1015 = add i64 %v1014, 8
  store i64 %op1015, ptr %slot53, align 8
  %v1016 = load i64, ptr %slot53, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %ld1018 = load i64, ptr %p1017, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1018, ptr %slot54, align 8
  %v1019 = load i64, ptr %slot54, align 8
  %v1020 = load i64, ptr %slot31, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  store i64 %v1019, ptr %p1021, align 8, !alias.scope !3, !noalias !4
  %v1022 = load i64, ptr %slot12, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  %ld1024 = load i32, ptr %p1023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1024, ptr %slot55, align 8
  %v1025 = load i32, ptr %slot55, align 8
  %cv1026 = zext i32 %v1025 to i64
  %cond1027 = icmp ne i64 %cv1026, 0
  br i1 %cond1027, label %bb_rcslotdrop29, label %bb_rcslotdone29
bb_rcslotdrop29:
  %v1028 = load i64, ptr %slot12, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  store i32 0, ptr %p1029, align 4, !alias.scope !3, !noalias !4
  %v1030 = load i64, ptr %slot17, align 8
  store i64 %v1030, ptr %slot56, align 8
  %v1031 = load i64, ptr %slot13, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  %ld1033 = load i32, ptr %p1032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1033, ptr %slot57, align 8
  %v1034 = load i32, ptr %slot57, align 8
  %op1035 = and i32 %v1034, 28
  store i32 %op1035, ptr %slot58, align 8
  %v1036 = load i32, ptr %slot58, align 8
  %cv1037 = zext i32 %v1036 to i64
  %cond1038 = icmp ne i64 %cv1037, 0
  br i1 %cond1038, label %bb_rcslotrole29, label %bb_rcslotowner29
bb_rcslotrole29:
  %v1039 = load i64, ptr %slot41, align 8
  store i64 %v1039, ptr %slot59, align 8
  %v1040 = load i64, ptr %slot59, align 8
  %v1041 = load i64, ptr %slot56, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v1040, i64 %v1041) nomerge, !dbg !116
  br label %bb_rcslotdone29
bb_rcslotowner29:
  %v1042 = load i64, ptr %slot41, align 8
  store i64 %v1042, ptr %slot60, align 8
  %v1043 = load i64, ptr %slot60, align 8
  %v1044 = load i64, ptr %slot56, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v1043, i64 %v1044) nomerge, !dbg !116
  br label %bb_rcslotdone29
bb_rcslotdone29:
  %v1045 = load i64, ptr %slot31, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  %ld1047 = load i64, ptr %p1046, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1047, ptr %slot61, align 8
  %v1048 = load i64, ptr %slot61, align 8
  %v1049 = load i64, ptr %slot21, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  store i64 %v1048, ptr %p1050, align 8, !alias.scope !3, !noalias !4
  %v1051 = load i64, ptr %slot20, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %ld1053 = load i64, ptr %p1052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1053, ptr %slot62, align 8
  %v1054 = load i64, ptr %slot62, align 8
  %v1055 = load i64, ptr %slot31, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  store i64 %v1054, ptr %p1056, align 8, !alias.scope !3, !noalias !4
  %v1057 = load i64, ptr %slot31, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  %ld1059 = load i64, ptr %p1058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1059, ptr %slot63, align 8
  %v1060 = load i64, ptr %slot63, align 8
  %v1061 = load i64, ptr %slot22, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  store i64 %v1060, ptr %p1062, align 8, !alias.scope !3, !noalias !4
  %v1063 = load i64, ptr %slot22, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  %ld1065 = load i64, ptr %p1064, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1065, ptr %slot64, align 8
  %v1066 = load i64, ptr %slot64, align 8
  %v1067 = load i64, ptr %slot31, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  store i64 %v1066, ptr %p1068, align 8, !alias.scope !3, !noalias !4
  %v1069 = load i64, ptr %slot32, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  store i64 0, ptr %p1070, align 8, !alias.scope !3, !noalias !4
  %v1071 = load i64, ptr %slot32, align 8
  %p1072 = inttoptr i64 %v1071 to ptr
  %ld1073 = load i64, ptr %p1072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1073, ptr %slot65, align 8
  %v1074 = load i64, ptr %slot31, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  %ld1076 = load i64, ptr %p1075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1076, ptr %slot66, align 8
  %v1077 = load i64, ptr %slot66, align 8
  %v1078 = load i64, ptr %slot65, align 8
  %cmp1079 = icmp slt i64 %v1077, %v1078
  %cv1080 = zext i1 %cmp1079 to i64
  store i64 %cv1080, ptr %slot67, align 8
  %v1081 = load i64, ptr %slot67, align 8
  %v1082 = load i64, ptr %slot31, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  store i64 %v1081, ptr %p1083, align 8, !alias.scope !3, !noalias !4
  %v1084 = load i64, ptr %slot31, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %ld1086 = load i64, ptr %p1085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1086, ptr %slot68, align 8
  %v1087 = load i64, ptr %slot68, align 8
  %cond1088 = icmp ne i64 %v1087, 0
  br i1 %cond1088, label %bb_next44, label %bb_i15
bb_next44:
  %v1089 = load i64, ptr %slot21, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  %ld1091 = load i64, ptr %p1090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1091, ptr %slot69, align 8
  %v1092 = load i64, ptr %slot69, align 8
  %op1093 = add i64 %v1092, 0
  store i64 %op1093, ptr %slot70, align 8
  %v1094 = load i64, ptr %slot70, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  %ld1096 = load i64, ptr %p1095, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1096, ptr %slot71, align 8
  %v1097 = load i64, ptr %slot71, align 8
  %v1098 = load i64, ptr %slot31, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  store i64 %v1097, ptr %p1099, align 8, !alias.scope !3, !noalias !4
  %v1100 = load i64, ptr %slot31, align 8
  %p1101 = inttoptr i64 %v1100 to ptr
  %ld1102 = load i64, ptr %p1101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1102, ptr %slot72, align 8
  %v1103 = load i64, ptr %slot72, align 8
  %cmp1104 = icmp ugt i64 %v1103, 9223372036854775807
  %cv1105 = zext i1 %cmp1104 to i64
  store i64 %cv1105, ptr %slot73, align 8
  %v1106 = load i64, ptr %slot73, align 8
  %cond1107 = icmp ne i64 %v1106, 0
  br i1 %cond1107, label %bb_cast_overflow49, label %bb_cast_ok49
bb_cast_overflow49:
  %v1108 = load i64, ptr %slot1, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %v1110 = load i64, ptr %slot72, align 8
  call void @myl_qbe_fail_cast(ptr %p1109, i64 %v1110, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok49:
  %v1111 = load i64, ptr %slot72, align 8
  %v1112 = load i64, ptr %slot31, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  store i64 %v1111, ptr %p1113, align 8, !alias.scope !3, !noalias !4
  %v1114 = load i64, ptr %slot22, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  %ld1116 = load i64, ptr %p1115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1116, ptr %slot74, align 8
  %v1117 = load i64, ptr %slot74, align 8
  %v1118 = load i64, ptr %slot32, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i64 %v1117, ptr %p1119, align 8, !alias.scope !3, !noalias !4
  %v1120 = load i64, ptr %slot32, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  %ld1122 = load i64, ptr %p1121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1122, ptr %slot75, align 8
  %v1123 = load i64, ptr %slot31, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  %ld1125 = load i64, ptr %p1124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1125, ptr %slot76, align 8
  %v1126 = load i64, ptr %slot76, align 8
  %v1127 = load i64, ptr %slot75, align 8
  %ovpair1129 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1126, i64 %v1127)
  %op1128 = extractvalue { i64, i1 } %ovpair1129, 0
  %ov1130 = extractvalue { i64, i1 } %ovpair1129, 1
  store i64 %op1128, ptr %slot77, align 8
  %v1131 = load i64, ptr %slot76, align 8
  %v1132 = load i64, ptr %slot77, align 8
  %op1133 = xor i64 %v1131, %v1132
  store i64 %op1133, ptr %slot78, align 8
  %v1134 = load i64, ptr %slot75, align 8
  %v1135 = load i64, ptr %slot77, align 8
  %op1136 = xor i64 %v1134, %v1135
  store i64 %op1136, ptr %slot79, align 8
  %v1137 = load i64, ptr %slot78, align 8
  %v1138 = load i64, ptr %slot79, align 8
  %op1139 = and i64 %v1137, %v1138
  store i64 %op1139, ptr %slot80, align 8
  %cv1140 = zext i1 %ov1130 to i64
  store i64 %cv1140, ptr %slot81, align 8
  %v1141 = load i64, ptr %slot81, align 8
  %cond1142 = icmp ne i64 %v1141, 0
  br i1 %cond1142, label %bb_overflow53, label %bb_checked53
bb_overflow53:
  %v1143 = load i64, ptr %slot1, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  %v1145 = load i64, ptr %slot76, align 8
  %v1146 = load i64, ptr %slot75, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1144, i64 0, i64 %v1145, i64 %v1146, i64 64) nomerge, !dbg !120
  unreachable
bb_checked53:
  %v1147 = load i64, ptr %slot77, align 8
  %v1148 = load i64, ptr %slot31, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  store i64 %v1147, ptr %p1149, align 8, !alias.scope !3, !noalias !4
  %v1150 = load i64, ptr %slot31, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i64, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1152, ptr %slot82, align 8
  %v1153 = load i64, ptr %slot82, align 8
  %v1154 = load i64, ptr %slot22, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i64 %v1153, ptr %p1155, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v1156 = load i64, ptr %slot22, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %ld1158 = load i64, ptr %p1157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1158, ptr %slot83, align 8
  %v1159 = load i64, ptr %slot83, align 8
  %v1160 = load i64, ptr %slot31, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  store i64 %v1159, ptr %p1161, align 8, !alias.scope !3, !noalias !4
  %v1162 = load i64, ptr %slot21, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  %ld1164 = load i64, ptr %p1163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1164, ptr %slot84, align 8
  %v1165 = load i64, ptr %slot31, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  %ld1167 = load i64, ptr %p1166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1167, ptr %slot85, align 8
  %v1168 = load i64, ptr %slot84, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %ld1170 = load i64, ptr %p1169, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1170, ptr %slot86, align 8
  %v1171 = load i64, ptr %slot85, align 8
  %v1172 = load i64, ptr %slot86, align 8
  %cmp1173 = icmp ult i64 %v1171, %v1172
  %cv1174 = zext i1 %cmp1173 to i64
  store i64 %cv1174, ptr %slot87, align 8
  %v1175 = load i64, ptr %slot87, align 8
  %cond1176 = icmp ne i64 %v1175, 0
  br i1 %cond1176, label %bb_success65, label %bb_failed65
bb_failed65:
  %v1177 = load i64, ptr %slot1, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %v1179 = load i64, ptr %slot85, align 8
  %v1180 = load i64, ptr %slot86, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1178, i64 %v1179, i64 %v1180) nomerge, !dbg !122
  unreachable
bb_success65:
  %v1181 = load i64, ptr %slot84, align 8
  %op1182 = add i64 %v1181, 32
  store i64 %op1182, ptr %slot88, align 8
  %v1183 = load i64, ptr %slot88, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %ld1185 = load i64, ptr %p1184, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1185, ptr %slot89, align 8
  %v1186 = load i64, ptr %slot85, align 8
  %op1187 = mul i64 %v1186, 88
  store i64 %op1187, ptr %slot90, align 8
  %v1188 = load i64, ptr %slot89, align 8
  %v1189 = load i64, ptr %slot90, align 8
  %op1190 = add i64 %v1188, %v1189
  store i64 %op1190, ptr %slot91, align 8
  %v1191 = load i64, ptr %slot91, align 8
  %v1192 = load i64, ptr %slot31, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  store i64 %v1191, ptr %p1193, align 8, !alias.scope !3, !noalias !4
  %v1194 = load i64, ptr %slot31, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  %ld1196 = load i64, ptr %p1195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1196, ptr %slot92, align 8
  %v1197 = load i64, ptr %slot18, align 8
  store i64 %v1197, ptr %slot93, align 8
  %v1198 = load i64, ptr %slot41, align 8
  %v1199 = load i64, ptr %slot93, align 8
  %v1200 = load i64, ptr %slot92, align 8
  %call1201 = call i32 @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_loan(i64 %v1198, i64 %v1199, i64 %v1200) nomerge, !dbg !122
  store i32 %call1201, ptr %slot94, align 8
  %v1202 = load i32, ptr %slot94, align 8
  %cv1203 = zext i32 %v1202 to i64
  %cond1204 = icmp ne i64 %cv1203, 0
  br i1 %cond1204, label %bb_rcsuccess73, label %bb_rcfailure73
bb_rcfailure73:
  %v1205 = load i64, ptr %slot41, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  %call1207 = call i32 @myl_rc_take_failure(ptr %p1206) nomerge, !dbg !122
  store i32 %call1207, ptr %slot95, align 8
  %v1208 = load i64, ptr %slot1, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  %v1210 = load i32, ptr %slot95, align 8
  %call1211 = call i32 @myl_qbe_rc_status(ptr %p1209, i32 %v1210) nomerge, !dbg !122
  store i32 %call1211, ptr %slot96, align 8
  br label %bb_failure
bb_rcsuccess73:
  %v1212 = load i64, ptr %slot15, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  store i32 2, ptr %p1213, align 4, !alias.scope !3, !noalias !4
  %v1214 = load i64, ptr %slot15, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  store i32 16, ptr %p1215, align 4, !alias.scope !3, !noalias !4
  %v1216 = load i64, ptr %slot14, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  store i32 1, ptr %p1217, align 4, !alias.scope !3, !noalias !4
  %v1218 = load i64, ptr %slot17, align 8
  store i64 %v1218, ptr %slot97, align 8
  %v1219 = load i64, ptr %slot18, align 8
  store i64 %v1219, ptr %slot98, align 8
  %v1220 = load i64, ptr %slot98, align 8
  %v1221 = load i64, ptr %slot97, align 8
  %p1222 = inttoptr i64 %v1220 to ptr
  %p1223 = inttoptr i64 %v1221 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1223, ptr %p1222, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1224 = load i64, ptr %slot13, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  store i32 2, ptr %p1225, align 4, !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot15, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  %ld1228 = load i32, ptr %p1227, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1228, ptr %slot99, align 8
  %v1229 = load i32, ptr %slot99, align 8
  %v1230 = load i64, ptr %slot13, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  store i32 %v1229, ptr %p1231, align 4, !alias.scope !3, !noalias !4
  %v1232 = load i64, ptr %slot14, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  store i32 0, ptr %p1233, align 4, !alias.scope !3, !noalias !4
  %v1234 = load i64, ptr %slot12, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  store i32 1, ptr %p1235, align 4, !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot97, align 8
  %v1237 = load i64, ptr %slot31, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  store i64 %v1236, ptr %p1238, align 8, !alias.scope !3, !noalias !4
  %v1239 = load i64, ptr %slot31, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %ld1241 = load i64, ptr %p1240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1241, ptr %slot100, align 8
  %v1242 = load i64, ptr %slot100, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  %ld1244 = load i32, ptr %p1243, align 4, !alias.scope !3, !noalias !4
  %ext1245 = zext i32 %ld1244 to i64
  store i64 %ext1245, ptr %slot101, align 8
  %v1246 = load i64, ptr %slot101, align 8
  %cmp1247 = icmp eq i64 %v1246, 0
  %cv1248 = zext i1 %cmp1247 to i64
  store i64 %cv1248, ptr %slot102, align 8
  %v1249 = load i64, ptr %slot102, align 8
  %cond1250 = icmp ne i64 %v1249, 0
  br i1 %cond1250, label %bb_rcarm89, label %bb_rcarmnext89
bb_rcarm89:
  %v1251 = load i64, ptr %slot18, align 8
  store i64 %v1251, ptr %slot103, align 8
  %v1252 = load i64, ptr %slot100, align 8
  %op1253 = add i64 %v1252, 8
  store i64 %op1253, ptr %slot104, align 8
  %v1254 = load i64, ptr %slot42, align 8
  store i64 %v1254, ptr %slot105, align 8
  %v1255 = load i64, ptr %slot41, align 8
  %v1256 = load i64, ptr %slot103, align 8
  %v1257 = load i64, ptr %slot104, align 8
  %v1258 = load i64, ptr %slot105, align 8
  %cv1259 = trunc i64 %v1258 to i32
  %call1260 = call i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_retain(i64 %v1255, i64 %v1256, i64 %v1257, i32 %cv1259) nomerge, !dbg !124
  store i32 %call1260, ptr %slot106, align 8
  %v1261 = load i32, ptr %slot106, align 8
  %cv1262 = zext i32 %v1261 to i64
  %cond1263 = icmp ne i64 %cv1262, 0
  br i1 %cond1263, label %bb_rcsuccess94, label %bb_rcfailure94
bb_rcfailure94:
  %v1264 = load i64, ptr %slot41, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  %call1266 = call i32 @myl_rc_take_failure(ptr %p1265) nomerge, !dbg !124
  store i32 %call1266, ptr %slot107, align 8
  %v1267 = load i64, ptr %slot1, align 8
  %p1268 = inttoptr i64 %v1267 to ptr
  %v1269 = load i32, ptr %slot107, align 8
  %call1270 = call i32 @myl_qbe_rc_status(ptr %p1268, i32 %v1269) nomerge, !dbg !124
  store i32 %call1270, ptr %slot108, align 8
  br label %bb_failure
bb_rcsuccess94:
  %v1271 = load i64, ptr %slot15, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  store i32 2, ptr %p1272, align 4, !alias.scope !3, !noalias !4
  %v1273 = load i64, ptr %slot14, align 8
  %p1274 = inttoptr i64 %v1273 to ptr
  store i32 1, ptr %p1274, align 4, !alias.scope !3, !noalias !4
  %v1275 = load i64, ptr %slot6, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  %ld1277 = load i32, ptr %p1276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1277, ptr %slot109, align 8
  %v1278 = load i32, ptr %slot109, align 8
  %cv1279 = zext i32 %v1278 to i64
  %cond1280 = icmp ne i64 %cv1279, 0
  br i1 %cond1280, label %bb_rcslotdrop101, label %bb_rcslotdone101
bb_rcslotdrop101:
  %v1281 = load i64, ptr %slot6, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i32 0, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot23, align 8
  store i64 %v1283, ptr %slot110, align 8
  %v1284 = load i64, ptr %slot7, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %ld1286 = load i32, ptr %p1285, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1286, ptr %slot111, align 8
  %v1287 = load i32, ptr %slot111, align 8
  %op1288 = and i32 %v1287, 28
  store i32 %op1288, ptr %slot112, align 8
  %v1289 = load i32, ptr %slot112, align 8
  %cv1290 = zext i32 %v1289 to i64
  %cond1291 = icmp ne i64 %cv1290, 0
  br i1 %cond1291, label %bb_rcslotrole101, label %bb_rcslotowner101
bb_rcslotrole101:
  %v1292 = load i64, ptr %slot41, align 8
  store i64 %v1292, ptr %slot113, align 8
  %v1293 = load i64, ptr %slot113, align 8
  %v1294 = load i64, ptr %slot110, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v1293, i64 %v1294) nomerge, !dbg !124
  br label %bb_rcslotdone101
bb_rcslotowner101:
  %v1295 = load i64, ptr %slot41, align 8
  store i64 %v1295, ptr %slot114, align 8
  %v1296 = load i64, ptr %slot114, align 8
  %v1297 = load i64, ptr %slot110, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v1296, i64 %v1297) nomerge, !dbg !124
  br label %bb_rcslotdone101
bb_rcslotdone101:
  %v1298 = load i64, ptr %slot103, align 8
  %v1299 = load i64, ptr %slot23, align 8
  %p1300 = inttoptr i64 %v1298 to ptr
  %p1301 = inttoptr i64 %v1299 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1301, ptr %p1300, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1302 = load i64, ptr %slot14, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  store i32 0, ptr %p1303, align 4, !alias.scope !3, !noalias !4
  %v1304 = load i64, ptr %slot23, align 8
  store i64 %v1304, ptr %slot115, align 8
  %v1305 = load i64, ptr %slot7, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  store i32 2, ptr %p1306, align 4, !alias.scope !3, !noalias !4
  %v1307 = load i64, ptr %slot6, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  store i32 1, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  %v1309 = load i64, ptr %slot12, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  %ld1311 = load i32, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1311, ptr %slot116, align 8
  %v1312 = load i32, ptr %slot116, align 8
  %cv1313 = zext i32 %v1312 to i64
  %cond1314 = icmp ne i64 %cv1313, 0
  br i1 %cond1314, label %bb_rcslotdrop114, label %bb_rcslotdone114
bb_rcslotdrop114:
  %v1315 = load i64, ptr %slot12, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  store i32 0, ptr %p1316, align 4, !alias.scope !3, !noalias !4
  %v1317 = load i64, ptr %slot17, align 8
  store i64 %v1317, ptr %slot117, align 8
  %v1318 = load i64, ptr %slot13, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  %ld1320 = load i32, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1320, ptr %slot118, align 8
  %v1321 = load i32, ptr %slot118, align 8
  %op1322 = and i32 %v1321, 28
  store i32 %op1322, ptr %slot119, align 8
  %v1323 = load i32, ptr %slot119, align 8
  %cv1324 = zext i32 %v1323 to i64
  %cond1325 = icmp ne i64 %cv1324, 0
  br i1 %cond1325, label %bb_rcslotrole114, label %bb_rcslotowner114
bb_rcslotrole114:
  %v1326 = load i64, ptr %slot41, align 8
  store i64 %v1326, ptr %slot120, align 8
  %v1327 = load i64, ptr %slot120, align 8
  %v1328 = load i64, ptr %slot117, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1327, i64 %v1328) nomerge, !dbg !124
  br label %bb_rcslotdone114
bb_rcslotowner114:
  %v1329 = load i64, ptr %slot41, align 8
  store i64 %v1329, ptr %slot121, align 8
  %v1330 = load i64, ptr %slot121, align 8
  %v1331 = load i64, ptr %slot117, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1330, i64 %v1331) nomerge, !dbg !124
  br label %bb_rcslotdone114
bb_rcslotdone114:
  br label %bb_i18
bb_rcarmnext89:
  %v1332 = load i64, ptr %slot101, align 8
  %cmp1333 = icmp eq i64 %v1332, 1
  %cv1334 = zext i1 %cmp1333 to i64
  store i64 %cv1334, ptr %slot122, align 8
  %v1335 = load i64, ptr %slot122, align 8
  %cond1336 = icmp ne i64 %v1335, 0
  br i1 %cond1336, label %bb_rcarm121, label %bb_rcarmnext121
bb_rcarm121:
  %v1337 = load i64, ptr %slot12, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  %ld1339 = load i32, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1339, ptr %slot123, align 8
  %v1340 = load i32, ptr %slot123, align 8
  %cv1341 = zext i32 %v1340 to i64
  %cond1342 = icmp ne i64 %cv1341, 0
  br i1 %cond1342, label %bb_rcslotdrop124, label %bb_rcslotdone124
bb_rcslotdrop124:
  %v1343 = load i64, ptr %slot12, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  store i32 0, ptr %p1344, align 4, !alias.scope !3, !noalias !4
  %v1345 = load i64, ptr %slot17, align 8
  store i64 %v1345, ptr %slot124, align 8
  %v1346 = load i64, ptr %slot13, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %ld1348 = load i32, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1348, ptr %slot125, align 8
  %v1349 = load i32, ptr %slot125, align 8
  %op1350 = and i32 %v1349, 28
  store i32 %op1350, ptr %slot126, align 8
  %v1351 = load i32, ptr %slot126, align 8
  %cv1352 = zext i32 %v1351 to i64
  %cond1353 = icmp ne i64 %cv1352, 0
  br i1 %cond1353, label %bb_rcslotrole124, label %bb_rcslotowner124
bb_rcslotrole124:
  %v1354 = load i64, ptr %slot41, align 8
  store i64 %v1354, ptr %slot127, align 8
  %v1355 = load i64, ptr %slot127, align 8
  %v1356 = load i64, ptr %slot124, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1355, i64 %v1356) nomerge, !dbg !124
  br label %bb_rcslotdone124
bb_rcslotowner124:
  %v1357 = load i64, ptr %slot41, align 8
  store i64 %v1357, ptr %slot128, align 8
  %v1358 = load i64, ptr %slot128, align 8
  %v1359 = load i64, ptr %slot124, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1358, i64 %v1359) nomerge, !dbg !124
  br label %bb_rcslotdone124
bb_rcslotdone124:
  br label %bb_i27
bb_rcarmnext121:
  %v1360 = load i64, ptr %slot101, align 8
  %cmp1361 = icmp eq i64 %v1360, 2
  %cv1362 = zext i1 %cmp1361 to i64
  store i64 %cv1362, ptr %slot129, align 8
  %v1363 = load i64, ptr %slot129, align 8
  %cond1364 = icmp ne i64 %v1363, 0
  br i1 %cond1364, label %bb_rcarm131, label %bb_rcarmnext131
bb_rcarm131:
  %v1365 = load i64, ptr %slot18, align 8
  store i64 %v1365, ptr %slot130, align 8
  %v1366 = load i64, ptr %slot100, align 8
  %op1367 = add i64 %v1366, 8
  store i64 %op1367, ptr %slot131, align 8
  %v1368 = load i64, ptr %slot42, align 8
  store i64 %v1368, ptr %slot132, align 8
  %v1369 = load i64, ptr %slot131, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %ld1371 = load i64, ptr %p1370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1371, ptr %slot133, align 8
  %v1372 = load i64, ptr %slot133, align 8
  %v1373 = load i64, ptr %slot130, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i64 %v1372, ptr %p1374, align 8, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot15, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i32 0, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot14, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  store i32 1, ptr %p1378, align 4, !alias.scope !3, !noalias !4
  %v1379 = load i64, ptr %slot130, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  %ld1381 = load i64, ptr %p1380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1381, ptr %slot134, align 8
  %v1382 = load i64, ptr %slot134, align 8
  %v1383 = load i64, ptr %slot24, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  store i64 %v1382, ptr %p1384, align 8, !alias.scope !3, !noalias !4
  %v1385 = load i64, ptr %slot14, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  store i32 0, ptr %p1386, align 4, !alias.scope !3, !noalias !4
  %v1387 = load i64, ptr %slot12, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  %ld1389 = load i32, ptr %p1388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1389, ptr %slot135, align 8
  %v1390 = load i32, ptr %slot135, align 8
  %cv1391 = zext i32 %v1390 to i64
  %cond1392 = icmp ne i64 %cv1391, 0
  br i1 %cond1392, label %bb_rcslotdrop142, label %bb_rcslotdone142
bb_rcslotdrop142:
  %v1393 = load i64, ptr %slot12, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  store i32 0, ptr %p1394, align 4, !alias.scope !3, !noalias !4
  %v1395 = load i64, ptr %slot17, align 8
  store i64 %v1395, ptr %slot136, align 8
  %v1396 = load i64, ptr %slot13, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  %ld1398 = load i32, ptr %p1397, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1398, ptr %slot137, align 8
  %v1399 = load i32, ptr %slot137, align 8
  %op1400 = and i32 %v1399, 28
  store i32 %op1400, ptr %slot138, align 8
  %v1401 = load i32, ptr %slot138, align 8
  %cv1402 = zext i32 %v1401 to i64
  %cond1403 = icmp ne i64 %cv1402, 0
  br i1 %cond1403, label %bb_rcslotrole142, label %bb_rcslotowner142
bb_rcslotrole142:
  %v1404 = load i64, ptr %slot41, align 8
  store i64 %v1404, ptr %slot139, align 8
  %v1405 = load i64, ptr %slot139, align 8
  %v1406 = load i64, ptr %slot136, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1405, i64 %v1406) nomerge, !dbg !124
  br label %bb_rcslotdone142
bb_rcslotowner142:
  %v1407 = load i64, ptr %slot41, align 8
  store i64 %v1407, ptr %slot140, align 8
  %v1408 = load i64, ptr %slot140, align 8
  %v1409 = load i64, ptr %slot136, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1408, i64 %v1409) nomerge, !dbg !124
  br label %bb_rcslotdone142
bb_rcslotdone142:
  br label %bb_i35
bb_rcarmnext131:
  %v1410 = load i64, ptr %slot101, align 8
  %cmp1411 = icmp eq i64 %v1410, 3
  %cv1412 = zext i1 %cmp1411 to i64
  store i64 %cv1412, ptr %slot141, align 8
  %v1413 = load i64, ptr %slot141, align 8
  %cond1414 = icmp ne i64 %v1413, 0
  br i1 %cond1414, label %bb_rcarm149, label %bb_rcarmnext149
bb_rcarm149:
  %v1415 = load i64, ptr %slot18, align 8
  store i64 %v1415, ptr %slot142, align 8
  %v1416 = load i64, ptr %slot100, align 8
  %op1417 = add i64 %v1416, 8
  store i64 %op1417, ptr %slot143, align 8
  %v1418 = load i64, ptr %slot42, align 8
  store i64 %v1418, ptr %slot144, align 8
  %v1419 = load i64, ptr %slot143, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %ld1421 = load i64, ptr %p1420, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1421, ptr %slot145, align 8
  %v1422 = load i64, ptr %slot145, align 8
  %v1423 = load i64, ptr %slot142, align 8
  %p1424 = inttoptr i64 %v1423 to ptr
  store i64 %v1422, ptr %p1424, align 8, !alias.scope !3, !noalias !4
  %v1425 = load i64, ptr %slot15, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  store i32 0, ptr %p1426, align 4, !alias.scope !3, !noalias !4
  %v1427 = load i64, ptr %slot14, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i32 1, ptr %p1428, align 4, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot142, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot146, align 8
  %v1432 = load i64, ptr %slot146, align 8
  %v1433 = load i64, ptr %slot25, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  store i64 %v1432, ptr %p1434, align 8, !alias.scope !3, !noalias !4
  %v1435 = load i64, ptr %slot14, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  store i32 0, ptr %p1436, align 4, !alias.scope !3, !noalias !4
  %v1437 = load i64, ptr %slot12, align 8
  %p1438 = inttoptr i64 %v1437 to ptr
  %ld1439 = load i32, ptr %p1438, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1439, ptr %slot147, align 8
  %v1440 = load i32, ptr %slot147, align 8
  %cv1441 = zext i32 %v1440 to i64
  %cond1442 = icmp ne i64 %cv1441, 0
  br i1 %cond1442, label %bb_rcslotdrop160, label %bb_rcslotdone160
bb_rcslotdrop160:
  %v1443 = load i64, ptr %slot12, align 8
  %p1444 = inttoptr i64 %v1443 to ptr
  store i32 0, ptr %p1444, align 4, !alias.scope !3, !noalias !4
  %v1445 = load i64, ptr %slot17, align 8
  store i64 %v1445, ptr %slot148, align 8
  %v1446 = load i64, ptr %slot13, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  %ld1448 = load i32, ptr %p1447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1448, ptr %slot149, align 8
  %v1449 = load i32, ptr %slot149, align 8
  %op1450 = and i32 %v1449, 28
  store i32 %op1450, ptr %slot150, align 8
  %v1451 = load i32, ptr %slot150, align 8
  %cv1452 = zext i32 %v1451 to i64
  %cond1453 = icmp ne i64 %cv1452, 0
  br i1 %cond1453, label %bb_rcslotrole160, label %bb_rcslotowner160
bb_rcslotrole160:
  %v1454 = load i64, ptr %slot41, align 8
  store i64 %v1454, ptr %slot151, align 8
  %v1455 = load i64, ptr %slot151, align 8
  %v1456 = load i64, ptr %slot148, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1455, i64 %v1456) nomerge, !dbg !124
  br label %bb_rcslotdone160
bb_rcslotowner160:
  %v1457 = load i64, ptr %slot41, align 8
  store i64 %v1457, ptr %slot152, align 8
  %v1458 = load i64, ptr %slot152, align 8
  %v1459 = load i64, ptr %slot148, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1458, i64 %v1459) nomerge, !dbg !124
  br label %bb_rcslotdone160
bb_rcslotdone160:
  br label %bb_i39
bb_rcarmnext149:
  %v1460 = load i64, ptr %slot101, align 8
  %cmp1461 = icmp eq i64 %v1460, 4
  %cv1462 = zext i1 %cmp1461 to i64
  store i64 %cv1462, ptr %slot153, align 8
  %v1463 = load i64, ptr %slot153, align 8
  %cond1464 = icmp ne i64 %v1463, 0
  br i1 %cond1464, label %bb_rcarm167, label %bb_rcarmnext167
bb_rcarm167:
  %v1465 = load i64, ptr %slot18, align 8
  store i64 %v1465, ptr %slot154, align 8
  %v1466 = load i64, ptr %slot100, align 8
  %op1467 = add i64 %v1466, 8
  store i64 %op1467, ptr %slot155, align 8
  %v1468 = load i64, ptr %slot42, align 8
  store i64 %v1468, ptr %slot156, align 8
  %v1469 = load i64, ptr %slot155, align 8
  %v1470 = load i64, ptr %slot154, align 8
  %p1471 = inttoptr i64 %v1469 to ptr
  %p1472 = inttoptr i64 %v1470 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1472, ptr %p1471, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1473 = load i64, ptr %slot15, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i32 0, ptr %p1474, align 4, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot14, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  store i32 1, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  %v1477 = load i64, ptr %slot154, align 8
  %v1478 = load i64, ptr %slot26, align 8
  %p1479 = inttoptr i64 %v1477 to ptr
  %p1480 = inttoptr i64 %v1478 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1480, ptr %p1479, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1481 = load i64, ptr %slot14, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i32 0, ptr %p1482, align 4, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot12, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  %ld1485 = load i32, ptr %p1484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1485, ptr %slot157, align 8
  %v1486 = load i32, ptr %slot157, align 8
  %cv1487 = zext i32 %v1486 to i64
  %cond1488 = icmp ne i64 %cv1487, 0
  br i1 %cond1488, label %bb_rcslotdrop176, label %bb_rcslotdone176
bb_rcslotdrop176:
  %v1489 = load i64, ptr %slot12, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  store i32 0, ptr %p1490, align 4, !alias.scope !3, !noalias !4
  %v1491 = load i64, ptr %slot17, align 8
  store i64 %v1491, ptr %slot158, align 8
  %v1492 = load i64, ptr %slot13, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  %ld1494 = load i32, ptr %p1493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1494, ptr %slot159, align 8
  %v1495 = load i32, ptr %slot159, align 8
  %op1496 = and i32 %v1495, 28
  store i32 %op1496, ptr %slot160, align 8
  %v1497 = load i32, ptr %slot160, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcslotrole176, label %bb_rcslotowner176
bb_rcslotrole176:
  %v1500 = load i64, ptr %slot41, align 8
  store i64 %v1500, ptr %slot161, align 8
  %v1501 = load i64, ptr %slot161, align 8
  %v1502 = load i64, ptr %slot158, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1501, i64 %v1502) nomerge, !dbg !124
  br label %bb_rcslotdone176
bb_rcslotowner176:
  %v1503 = load i64, ptr %slot41, align 8
  store i64 %v1503, ptr %slot162, align 8
  %v1504 = load i64, ptr %slot162, align 8
  %v1505 = load i64, ptr %slot158, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1504, i64 %v1505) nomerge, !dbg !124
  br label %bb_rcslotdone176
bb_rcslotdone176:
  br label %bb_i43
bb_rcarmnext167:
  %v1506 = load i64, ptr %slot101, align 8
  %cmp1507 = icmp eq i64 %v1506, 5
  %cv1508 = zext i1 %cmp1507 to i64
  store i64 %cv1508, ptr %slot163, align 8
  %v1509 = load i64, ptr %slot163, align 8
  %cond1510 = icmp ne i64 %v1509, 0
  br i1 %cond1510, label %bb_rcarm183, label %bb_rcarmnext183
bb_rcarm183:
  %v1511 = load i64, ptr %slot18, align 8
  store i64 %v1511, ptr %slot164, align 8
  %v1512 = load i64, ptr %slot100, align 8
  %op1513 = add i64 %v1512, 8
  store i64 %op1513, ptr %slot165, align 8
  %v1514 = load i64, ptr %slot42, align 8
  store i64 %v1514, ptr %slot166, align 8
  %v1515 = load i64, ptr %slot165, align 8
  %p1516 = inttoptr i64 %v1515 to ptr
  %ld1517 = load i64, ptr %p1516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1517, ptr %slot167, align 8
  %v1518 = load i64, ptr %slot167, align 8
  %v1519 = load i64, ptr %slot164, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  store i64 %v1518, ptr %p1520, align 8, !alias.scope !3, !noalias !4
  %v1521 = load i64, ptr %slot15, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  store i32 0, ptr %p1522, align 4, !alias.scope !3, !noalias !4
  %v1523 = load i64, ptr %slot14, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i32 1, ptr %p1524, align 4, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot164, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %ld1527 = load i64, ptr %p1526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1527, ptr %slot168, align 8
  %v1528 = load i64, ptr %slot168, align 8
  %v1529 = load i64, ptr %slot27, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  store i64 %v1528, ptr %p1530, align 8, !alias.scope !3, !noalias !4
  %v1531 = load i64, ptr %slot14, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  store i32 0, ptr %p1532, align 4, !alias.scope !3, !noalias !4
  %v1533 = load i64, ptr %slot12, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  %ld1535 = load i32, ptr %p1534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1535, ptr %slot169, align 8
  %v1536 = load i32, ptr %slot169, align 8
  %cv1537 = zext i32 %v1536 to i64
  %cond1538 = icmp ne i64 %cv1537, 0
  br i1 %cond1538, label %bb_rcslotdrop194, label %bb_rcslotdone194
bb_rcslotdrop194:
  %v1539 = load i64, ptr %slot12, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  store i32 0, ptr %p1540, align 4, !alias.scope !3, !noalias !4
  %v1541 = load i64, ptr %slot17, align 8
  store i64 %v1541, ptr %slot170, align 8
  %v1542 = load i64, ptr %slot13, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  %ld1544 = load i32, ptr %p1543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1544, ptr %slot171, align 8
  %v1545 = load i32, ptr %slot171, align 8
  %op1546 = and i32 %v1545, 28
  store i32 %op1546, ptr %slot172, align 8
  %v1547 = load i32, ptr %slot172, align 8
  %cv1548 = zext i32 %v1547 to i64
  %cond1549 = icmp ne i64 %cv1548, 0
  br i1 %cond1549, label %bb_rcslotrole194, label %bb_rcslotowner194
bb_rcslotrole194:
  %v1550 = load i64, ptr %slot41, align 8
  store i64 %v1550, ptr %slot173, align 8
  %v1551 = load i64, ptr %slot173, align 8
  %v1552 = load i64, ptr %slot170, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1551, i64 %v1552) nomerge, !dbg !124
  br label %bb_rcslotdone194
bb_rcslotowner194:
  %v1553 = load i64, ptr %slot41, align 8
  store i64 %v1553, ptr %slot174, align 8
  %v1554 = load i64, ptr %slot174, align 8
  %v1555 = load i64, ptr %slot170, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1554, i64 %v1555) nomerge, !dbg !124
  br label %bb_rcslotdone194
bb_rcslotdone194:
  br label %bb_i47
bb_rcarmnext183:
  %v1556 = load i64, ptr %slot101, align 8
  %cmp1557 = icmp eq i64 %v1556, 6
  %cv1558 = zext i1 %cmp1557 to i64
  store i64 %cv1558, ptr %slot175, align 8
  %v1559 = load i64, ptr %slot175, align 8
  %cond1560 = icmp ne i64 %v1559, 0
  br i1 %cond1560, label %bb_rcarm201, label %bb_rcarmnext201
bb_rcarm201:
  %v1561 = load i64, ptr %slot18, align 8
  store i64 %v1561, ptr %slot176, align 8
  %v1562 = load i64, ptr %slot100, align 8
  %op1563 = add i64 %v1562, 8
  store i64 %op1563, ptr %slot177, align 8
  %v1564 = load i64, ptr %slot42, align 8
  store i64 %v1564, ptr %slot178, align 8
  %v1565 = load i64, ptr %slot41, align 8
  %v1566 = load i64, ptr %slot176, align 8
  %v1567 = load i64, ptr %slot177, align 8
  %v1568 = load i64, ptr %slot178, align 8
  %cv1569 = trunc i64 %v1568 to i32
  %call1570 = call i32 @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_retain(i64 %v1565, i64 %v1566, i64 %v1567, i32 %cv1569) nomerge, !dbg !124
  store i32 %call1570, ptr %slot179, align 8
  %v1571 = load i32, ptr %slot179, align 8
  %cv1572 = zext i32 %v1571 to i64
  %cond1573 = icmp ne i64 %cv1572, 0
  br i1 %cond1573, label %bb_rcsuccess206, label %bb_rcfailure206
bb_rcfailure206:
  %v1574 = load i64, ptr %slot41, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %call1576 = call i32 @myl_rc_take_failure(ptr %p1575) nomerge, !dbg !124
  store i32 %call1576, ptr %slot180, align 8
  %v1577 = load i64, ptr %slot1, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  %v1579 = load i32, ptr %slot180, align 8
  %call1580 = call i32 @myl_qbe_rc_status(ptr %p1578, i32 %v1579) nomerge, !dbg !124
  store i32 %call1580, ptr %slot181, align 8
  br label %bb_failure
bb_rcsuccess206:
  %v1581 = load i64, ptr %slot15, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  store i32 2, ptr %p1582, align 4, !alias.scope !3, !noalias !4
  %v1583 = load i64, ptr %slot14, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  store i32 1, ptr %p1584, align 4, !alias.scope !3, !noalias !4
  %v1585 = load i64, ptr %slot8, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  %ld1587 = load i32, ptr %p1586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1587, ptr %slot182, align 8
  %v1588 = load i32, ptr %slot182, align 8
  %cv1589 = zext i32 %v1588 to i64
  %cond1590 = icmp ne i64 %cv1589, 0
  br i1 %cond1590, label %bb_rcslotdrop213, label %bb_rcslotdone213
bb_rcslotdrop213:
  %v1591 = load i64, ptr %slot8, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i32 0, ptr %p1592, align 4, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot28, align 8
  store i64 %v1593, ptr %slot183, align 8
  %v1594 = load i64, ptr %slot9, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  %ld1596 = load i32, ptr %p1595, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1596, ptr %slot184, align 8
  %v1597 = load i32, ptr %slot184, align 8
  %op1598 = and i32 %v1597, 28
  store i32 %op1598, ptr %slot185, align 8
  %v1599 = load i32, ptr %slot185, align 8
  %cv1600 = zext i32 %v1599 to i64
  %cond1601 = icmp ne i64 %cv1600, 0
  br i1 %cond1601, label %bb_rcslotrole213, label %bb_rcslotowner213
bb_rcslotrole213:
  %v1602 = load i64, ptr %slot41, align 8
  store i64 %v1602, ptr %slot186, align 8
  %v1603 = load i64, ptr %slot186, align 8
  %v1604 = load i64, ptr %slot183, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v1603, i64 %v1604) nomerge, !dbg !124
  br label %bb_rcslotdone213
bb_rcslotowner213:
  %v1605 = load i64, ptr %slot41, align 8
  store i64 %v1605, ptr %slot187, align 8
  %v1606 = load i64, ptr %slot187, align 8
  %v1607 = load i64, ptr %slot183, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v1606, i64 %v1607) nomerge, !dbg !124
  br label %bb_rcslotdone213
bb_rcslotdone213:
  %v1608 = load i64, ptr %slot176, align 8
  %v1609 = load i64, ptr %slot28, align 8
  %p1610 = inttoptr i64 %v1608 to ptr
  %p1611 = inttoptr i64 %v1609 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1611, ptr %p1610, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1612 = load i64, ptr %slot14, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  store i32 0, ptr %p1613, align 4, !alias.scope !3, !noalias !4
  %v1614 = load i64, ptr %slot28, align 8
  store i64 %v1614, ptr %slot188, align 8
  %v1615 = load i64, ptr %slot9, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  store i32 2, ptr %p1616, align 4, !alias.scope !3, !noalias !4
  %v1617 = load i64, ptr %slot8, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  store i32 1, ptr %p1618, align 4, !alias.scope !3, !noalias !4
  %v1619 = load i64, ptr %slot12, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  %ld1621 = load i32, ptr %p1620, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1621, ptr %slot189, align 8
  %v1622 = load i32, ptr %slot189, align 8
  %cv1623 = zext i32 %v1622 to i64
  %cond1624 = icmp ne i64 %cv1623, 0
  br i1 %cond1624, label %bb_rcslotdrop226, label %bb_rcslotdone226
bb_rcslotdrop226:
  %v1625 = load i64, ptr %slot12, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  store i32 0, ptr %p1626, align 4, !alias.scope !3, !noalias !4
  %v1627 = load i64, ptr %slot17, align 8
  store i64 %v1627, ptr %slot190, align 8
  %v1628 = load i64, ptr %slot13, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  %ld1630 = load i32, ptr %p1629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1630, ptr %slot191, align 8
  %v1631 = load i32, ptr %slot191, align 8
  %op1632 = and i32 %v1631, 28
  store i32 %op1632, ptr %slot192, align 8
  %v1633 = load i32, ptr %slot192, align 8
  %cv1634 = zext i32 %v1633 to i64
  %cond1635 = icmp ne i64 %cv1634, 0
  br i1 %cond1635, label %bb_rcslotrole226, label %bb_rcslotowner226
bb_rcslotrole226:
  %v1636 = load i64, ptr %slot41, align 8
  store i64 %v1636, ptr %slot193, align 8
  %v1637 = load i64, ptr %slot193, align 8
  %v1638 = load i64, ptr %slot190, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1637, i64 %v1638) nomerge, !dbg !124
  br label %bb_rcslotdone226
bb_rcslotowner226:
  %v1639 = load i64, ptr %slot41, align 8
  store i64 %v1639, ptr %slot194, align 8
  %v1640 = load i64, ptr %slot194, align 8
  %v1641 = load i64, ptr %slot190, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1640, i64 %v1641) nomerge, !dbg !124
  br label %bb_rcslotdone226
bb_rcslotdone226:
  br label %bb_i51
bb_rcarmnext201:
  %v1642 = load i64, ptr %slot101, align 8
  %cmp1643 = icmp eq i64 %v1642, 7
  %cv1644 = zext i1 %cmp1643 to i64
  store i64 %cv1644, ptr %slot195, align 8
  %v1645 = load i64, ptr %slot195, align 8
  %cond1646 = icmp ne i64 %v1645, 0
  br i1 %cond1646, label %bb_rcarm233, label %bb_rcarmnext233
bb_rcarm233:
  %v1647 = load i64, ptr %slot18, align 8
  store i64 %v1647, ptr %slot196, align 8
  %v1648 = load i64, ptr %slot100, align 8
  %op1649 = add i64 %v1648, 8
  store i64 %op1649, ptr %slot197, align 8
  %v1650 = load i64, ptr %slot42, align 8
  store i64 %v1650, ptr %slot198, align 8
  %v1651 = load i64, ptr %slot41, align 8
  %v1652 = load i64, ptr %slot196, align 8
  %v1653 = load i64, ptr %slot197, align 8
  %v1654 = load i64, ptr %slot198, align 8
  %cv1655 = trunc i64 %v1654 to i32
  %call1656 = call i32 @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_retain(i64 %v1651, i64 %v1652, i64 %v1653, i32 %cv1655) nomerge, !dbg !124
  store i32 %call1656, ptr %slot199, align 8
  %v1657 = load i32, ptr %slot199, align 8
  %cv1658 = zext i32 %v1657 to i64
  %cond1659 = icmp ne i64 %cv1658, 0
  br i1 %cond1659, label %bb_rcsuccess238, label %bb_rcfailure238
bb_rcfailure238:
  %v1660 = load i64, ptr %slot41, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  %call1662 = call i32 @myl_rc_take_failure(ptr %p1661) nomerge, !dbg !124
  store i32 %call1662, ptr %slot200, align 8
  %v1663 = load i64, ptr %slot1, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  %v1665 = load i32, ptr %slot200, align 8
  %call1666 = call i32 @myl_qbe_rc_status(ptr %p1664, i32 %v1665) nomerge, !dbg !124
  store i32 %call1666, ptr %slot201, align 8
  br label %bb_failure
bb_rcsuccess238:
  %v1667 = load i64, ptr %slot15, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  store i32 2, ptr %p1668, align 4, !alias.scope !3, !noalias !4
  %v1669 = load i64, ptr %slot14, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  store i32 1, ptr %p1670, align 4, !alias.scope !3, !noalias !4
  %v1671 = load i64, ptr %slot10, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  %ld1673 = load i32, ptr %p1672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1673, ptr %slot202, align 8
  %v1674 = load i32, ptr %slot202, align 8
  %cv1675 = zext i32 %v1674 to i64
  %cond1676 = icmp ne i64 %cv1675, 0
  br i1 %cond1676, label %bb_rcslotdrop245, label %bb_rcslotdone245
bb_rcslotdrop245:
  %v1677 = load i64, ptr %slot10, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  store i32 0, ptr %p1678, align 4, !alias.scope !3, !noalias !4
  %v1679 = load i64, ptr %slot29, align 8
  store i64 %v1679, ptr %slot203, align 8
  %v1680 = load i64, ptr %slot11, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  %ld1682 = load i32, ptr %p1681, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1682, ptr %slot204, align 8
  %v1683 = load i32, ptr %slot204, align 8
  %op1684 = and i32 %v1683, 28
  store i32 %op1684, ptr %slot205, align 8
  %v1685 = load i32, ptr %slot205, align 8
  %cv1686 = zext i32 %v1685 to i64
  %cond1687 = icmp ne i64 %cv1686, 0
  br i1 %cond1687, label %bb_rcslotrole245, label %bb_rcslotowner245
bb_rcslotrole245:
  %v1688 = load i64, ptr %slot41, align 8
  store i64 %v1688, ptr %slot206, align 8
  %v1689 = load i64, ptr %slot206, align 8
  %v1690 = load i64, ptr %slot203, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v1689, i64 %v1690) nomerge, !dbg !124
  br label %bb_rcslotdone245
bb_rcslotowner245:
  %v1691 = load i64, ptr %slot41, align 8
  store i64 %v1691, ptr %slot207, align 8
  %v1692 = load i64, ptr %slot207, align 8
  %v1693 = load i64, ptr %slot203, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v1692, i64 %v1693) nomerge, !dbg !124
  br label %bb_rcslotdone245
bb_rcslotdone245:
  %v1694 = load i64, ptr %slot196, align 8
  %v1695 = load i64, ptr %slot29, align 8
  %p1696 = inttoptr i64 %v1694 to ptr
  %p1697 = inttoptr i64 %v1695 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1697, ptr %p1696, i64 72, i1 false), !alias.scope !3, !noalias !4
  %v1698 = load i64, ptr %slot14, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  store i32 0, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  %v1700 = load i64, ptr %slot29, align 8
  store i64 %v1700, ptr %slot208, align 8
  %v1701 = load i64, ptr %slot11, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  store i32 2, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  %v1703 = load i64, ptr %slot10, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  store i32 1, ptr %p1704, align 4, !alias.scope !3, !noalias !4
  %v1705 = load i64, ptr %slot12, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %ld1707 = load i32, ptr %p1706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1707, ptr %slot209, align 8
  %v1708 = load i32, ptr %slot209, align 8
  %cv1709 = zext i32 %v1708 to i64
  %cond1710 = icmp ne i64 %cv1709, 0
  br i1 %cond1710, label %bb_rcslotdrop258, label %bb_rcslotdone258
bb_rcslotdrop258:
  %v1711 = load i64, ptr %slot12, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  store i32 0, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot17, align 8
  store i64 %v1713, ptr %slot210, align 8
  %v1714 = load i64, ptr %slot13, align 8
  %p1715 = inttoptr i64 %v1714 to ptr
  %ld1716 = load i32, ptr %p1715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1716, ptr %slot211, align 8
  %v1717 = load i32, ptr %slot211, align 8
  %op1718 = and i32 %v1717, 28
  store i32 %op1718, ptr %slot212, align 8
  %v1719 = load i32, ptr %slot212, align 8
  %cv1720 = zext i32 %v1719 to i64
  %cond1721 = icmp ne i64 %cv1720, 0
  br i1 %cond1721, label %bb_rcslotrole258, label %bb_rcslotowner258
bb_rcslotrole258:
  %v1722 = load i64, ptr %slot41, align 8
  store i64 %v1722, ptr %slot213, align 8
  %v1723 = load i64, ptr %slot213, align 8
  %v1724 = load i64, ptr %slot210, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1723, i64 %v1724) nomerge, !dbg !124
  br label %bb_rcslotdone258
bb_rcslotowner258:
  %v1725 = load i64, ptr %slot41, align 8
  store i64 %v1725, ptr %slot214, align 8
  %v1726 = load i64, ptr %slot214, align 8
  %v1727 = load i64, ptr %slot210, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1726, i64 %v1727) nomerge, !dbg !124
  br label %bb_rcslotdone258
bb_rcslotdone258:
  br label %bb_i55
bb_rcarmnext233:
  %v1728 = load i64, ptr %slot101, align 8
  %cmp1729 = icmp eq i64 %v1728, 8
  %cv1730 = zext i1 %cmp1729 to i64
  store i64 %cv1730, ptr %slot215, align 8
  %v1731 = load i64, ptr %slot215, align 8
  %cond1732 = icmp ne i64 %v1731, 0
  br i1 %cond1732, label %bb_rcarm265, label %bb_rcarmnext265
bb_rcarm265:
  %v1733 = load i64, ptr %slot18, align 8
  store i64 %v1733, ptr %slot216, align 8
  %v1734 = load i64, ptr %slot100, align 8
  %op1735 = add i64 %v1734, 8
  store i64 %op1735, ptr %slot217, align 8
  %v1736 = load i64, ptr %slot42, align 8
  store i64 %v1736, ptr %slot218, align 8
  %v1737 = load i64, ptr %slot217, align 8
  %v1738 = load i64, ptr %slot216, align 8
  %p1739 = inttoptr i64 %v1737 to ptr
  %p1740 = inttoptr i64 %v1738 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1740, ptr %p1739, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot15, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i32 0, ptr %p1742, align 4, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot14, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  store i32 1, ptr %p1744, align 4, !alias.scope !3, !noalias !4
  %v1745 = load i64, ptr %slot216, align 8
  %v1746 = load i64, ptr %slot30, align 8
  %p1747 = inttoptr i64 %v1745 to ptr
  %p1748 = inttoptr i64 %v1746 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1748, ptr %p1747, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1749 = load i64, ptr %slot14, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  store i32 0, ptr %p1750, align 4, !alias.scope !3, !noalias !4
  %v1751 = load i64, ptr %slot12, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  %ld1753 = load i32, ptr %p1752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1753, ptr %slot219, align 8
  %v1754 = load i32, ptr %slot219, align 8
  %cv1755 = zext i32 %v1754 to i64
  %cond1756 = icmp ne i64 %cv1755, 0
  br i1 %cond1756, label %bb_rcslotdrop274, label %bb_rcslotdone274
bb_rcslotdrop274:
  %v1757 = load i64, ptr %slot12, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  store i32 0, ptr %p1758, align 4, !alias.scope !3, !noalias !4
  %v1759 = load i64, ptr %slot17, align 8
  store i64 %v1759, ptr %slot220, align 8
  %v1760 = load i64, ptr %slot13, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  %ld1762 = load i32, ptr %p1761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1762, ptr %slot221, align 8
  %v1763 = load i32, ptr %slot221, align 8
  %op1764 = and i32 %v1763, 28
  store i32 %op1764, ptr %slot222, align 8
  %v1765 = load i32, ptr %slot222, align 8
  %cv1766 = zext i32 %v1765 to i64
  %cond1767 = icmp ne i64 %cv1766, 0
  br i1 %cond1767, label %bb_rcslotrole274, label %bb_rcslotowner274
bb_rcslotrole274:
  %v1768 = load i64, ptr %slot41, align 8
  store i64 %v1768, ptr %slot223, align 8
  %v1769 = load i64, ptr %slot223, align 8
  %v1770 = load i64, ptr %slot220, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1769, i64 %v1770) nomerge, !dbg !124
  br label %bb_rcslotdone274
bb_rcslotowner274:
  %v1771 = load i64, ptr %slot41, align 8
  store i64 %v1771, ptr %slot224, align 8
  %v1772 = load i64, ptr %slot224, align 8
  %v1773 = load i64, ptr %slot220, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1772, i64 %v1773) nomerge, !dbg !124
  br label %bb_rcslotdone274
bb_rcslotdone274:
  br label %bb_i59
bb_rcarmnext265:
  br label %bb_failure
bb_i18:
  %v1774 = load i64, ptr %slot23, align 8
  %v1775 = load i64, ptr %slot31, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  store i64 %v1774, ptr %p1776, align 8, !alias.scope !3, !noalias !4
  %v1777 = load i64, ptr %slot6, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  %ld1779 = load i32, ptr %p1778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1779, ptr %slot225, align 8
  %v1780 = load i64, ptr %slot7, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i32, ptr %p1781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1782, ptr %slot226, align 8
  %v1783 = load i32, ptr %slot226, align 8
  %op1784 = and i32 %v1783, 24
  store i32 %op1784, ptr %slot226, align 8
  %v1785 = load i32, ptr %slot226, align 8
  %cmp1786 = icmp eq i32 %v1785, 0
  %cv1787 = zext i1 %cmp1786 to i32
  store i32 %cv1787, ptr %slot227, align 8
  %v1788 = load i32, ptr %slot225, align 8
  %v1789 = load i32, ptr %slot227, align 8
  %op1790 = and i32 %v1788, %v1789
  store i32 %op1790, ptr %slot228, align 8
  %v1791 = load i32, ptr %slot228, align 8
  %cv1792 = zext i32 %v1791 to i64
  %cond1793 = icmp ne i64 %cv1792, 0
  br i1 %cond1793, label %bb_rcselfkept287, label %bb_rcselfstore287
bb_rcselfstore287:
  %v1794 = load i64, ptr %slot31, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  %ld1796 = load i64, ptr %p1795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1796, ptr %slot229, align 8
  %v1797 = load i64, ptr %slot12, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  %ld1799 = load i32, ptr %p1798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1799, ptr %slot230, align 8
  %v1800 = load i64, ptr %slot13, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %ld1802 = load i32, ptr %p1801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1802, ptr %slot231, align 8
  %v1803 = load i32, ptr %slot231, align 8
  %op1804 = and i32 %v1803, 24
  store i32 %op1804, ptr %slot231, align 8
  %v1805 = load i32, ptr %slot231, align 8
  %cmp1806 = icmp eq i32 %v1805, 0
  %cv1807 = zext i1 %cmp1806 to i32
  store i32 %cv1807, ptr %slot232, align 8
  %v1808 = load i32, ptr %slot230, align 8
  %v1809 = load i32, ptr %slot232, align 8
  %op1810 = and i32 %v1808, %v1809
  store i32 %op1810, ptr %slot233, align 8
  %v1811 = load i32, ptr %slot233, align 8
  %cv1812 = zext i32 %v1811 to i64
  %cond1813 = icmp ne i64 %cv1812, 0
  br i1 %cond1813, label %bb_rctake289, label %bb_rccopy289
bb_rctake289:
  %v1814 = load i64, ptr %slot18, align 8
  store i64 %v1814, ptr %slot234, align 8
  %v1815 = load i64, ptr %slot42, align 8
  store i64 %v1815, ptr %slot235, align 8
  %v1816 = load i64, ptr %slot229, align 8
  %v1817 = load i64, ptr %slot234, align 8
  %op1818 = sub i64 %v1816, %v1817
  store i64 %op1818, ptr %slot236, align 8
  %v1819 = load i64, ptr %slot234, align 8
  %v1820 = load i64, ptr %slot229, align 8
  %op1821 = sub i64 %v1819, %v1820
  store i64 %op1821, ptr %slot237, align 8
  %v1822 = load i64, ptr %slot236, align 8
  %cmp1823 = icmp ult i64 %v1822, 16
  %cv1824 = zext i1 %cmp1823 to i32
  store i32 %cv1824, ptr %slot238, align 8
  %v1825 = load i64, ptr %slot237, align 8
  %cmp1826 = icmp ult i64 %v1825, 16
  %cv1827 = zext i1 %cmp1826 to i32
  store i32 %cv1827, ptr %slot239, align 8
  %v1828 = load i32, ptr %slot238, align 8
  %v1829 = load i32, ptr %slot239, align 8
  %op1830 = or i32 %v1828, %v1829
  store i32 %op1830, ptr %slot240, align 8
  %v1831 = load i32, ptr %slot240, align 8
  %cv1832 = zext i32 %v1831 to i64
  %cond1833 = icmp ne i64 %cv1832, 0
  br i1 %cond1833, label %bb_rcmoveslow298, label %bb_rcmovecheck298
bb_rcmovecheck298:
  %v1834 = load i64, ptr %slot229, align 8
  %op1835 = add i64 %v1834, 0
  store i64 %op1835, ptr %slot241, align 8
  %v1836 = load i64, ptr %slot241, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %ld1838 = load i64, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1838, ptr %slot242, align 8
  %v1839 = load i64, ptr %slot242, align 8
  %cmp1840 = icmp ne i64 %v1839, 0
  %cv1841 = zext i1 %cmp1840 to i32
  store i32 %cv1841, ptr %slot243, align 8
  %v1842 = load i32, ptr %slot243, align 8
  %cv1843 = zext i32 %v1842 to i64
  %cond1844 = icmp ne i64 %cv1843, 0
  br i1 %cond1844, label %bb_rcmoveheader306, label %bb_rcmovenext306
bb_rcmoveheader306:
  %v1845 = load i64, ptr %slot242, align 8
  %op1846 = sub i64 %v1845, 16
  store i64 %op1846, ptr %slot244, align 8
  %v1847 = load i64, ptr %slot242, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  %rgep1849 = getelementptr i8, ptr %p1848, i64 -16
  %ld1850 = load i64, ptr %rgep1849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1850, ptr %slot245, align 8
  %v1851 = load i64, ptr %slot245, align 8
  %op1852 = and i64 %v1851, 5764607523034234881
  store i64 %op1852, ptr %slot246, align 8
  %v1853 = load i64, ptr %slot246, align 8
  %cmp1854 = icmp ne i64 %v1853, 0
  %cv1855 = zext i1 %cmp1854 to i32
  store i32 %cv1855, ptr %slot247, align 8
  %v1856 = load i32, ptr %slot247, align 8
  %cv1857 = zext i32 %v1856 to i64
  %cond1858 = icmp ne i64 %cv1857, 0
  br i1 %cond1858, label %bb_rcmoveslow298, label %bb_rcmovenext306
bb_rcmovenext306:
  %v1859 = load i64, ptr %slot229, align 8
  %v1860 = load i64, ptr %slot234, align 8
  %p1861 = inttoptr i64 %v1859 to ptr
  %p1862 = inttoptr i64 %v1860 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1862, ptr %p1861, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1863 = load i64, ptr %slot229, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  store i64 0, ptr %p1864, align 8, !alias.scope !3, !noalias !4
  %v1865 = load i64, ptr %slot229, align 8
  %op1866 = add i64 %v1865, 8
  store i64 %op1866, ptr %slot248, align 8
  %v1867 = load i64, ptr %slot248, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  store i64 0, ptr %p1868, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved298
bb_rcmoveslow298:
  %v1869 = load i64, ptr %slot41, align 8
  %v1870 = load i64, ptr %slot234, align 8
  %v1871 = load i64, ptr %slot229, align 8
  %v1872 = load i64, ptr %slot235, align 8
  %cv1873 = trunc i64 %v1872 to i32
  %call1874 = call i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_take(i64 %v1869, i64 %v1870, i64 %v1871, i32 %cv1873) nomerge, !dbg !126
  store i32 %call1874, ptr %slot249, align 8
  %v1875 = load i32, ptr %slot249, align 8
  %cv1876 = zext i32 %v1875 to i64
  %cond1877 = icmp ne i64 %cv1876, 0
  br i1 %cond1877, label %bb_rcsuccess314, label %bb_rcfailure314
bb_rcfailure314:
  %v1878 = load i64, ptr %slot41, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %call1880 = call i32 @myl_rc_take_failure(ptr %p1879) nomerge, !dbg !126
  store i32 %call1880, ptr %slot250, align 8
  %v1881 = load i64, ptr %slot1, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  %v1883 = load i32, ptr %slot250, align 8
  %call1884 = call i32 @myl_qbe_rc_status(ptr %p1882, i32 %v1883) nomerge, !dbg !126
  store i32 %call1884, ptr %slot251, align 8
  br label %bb_failure
bb_rcsuccess314:
  br label %bb_rcmoved298
bb_rcmoved298:
  %v1885 = load i64, ptr %slot12, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  store i32 0, ptr %p1886, align 4, !alias.scope !3, !noalias !4
  %v1887 = load i64, ptr %slot15, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  store i32 2, ptr %p1888, align 4, !alias.scope !3, !noalias !4
  %v1889 = load i64, ptr %slot14, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  store i32 1, ptr %p1890, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared289
bb_rccopy289:
  %v1891 = load i64, ptr %slot18, align 8
  store i64 %v1891, ptr %slot252, align 8
  %v1892 = load i64, ptr %slot42, align 8
  store i64 %v1892, ptr %slot253, align 8
  %v1893 = load i64, ptr %slot41, align 8
  %v1894 = load i64, ptr %slot252, align 8
  %v1895 = load i64, ptr %slot229, align 8
  %v1896 = load i64, ptr %slot253, align 8
  %cv1897 = trunc i64 %v1896 to i32
  %call1898 = call i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_retain(i64 %v1893, i64 %v1894, i64 %v1895, i32 %cv1897) nomerge, !dbg !126
  store i32 %call1898, ptr %slot254, align 8
  %v1899 = load i32, ptr %slot254, align 8
  %cv1900 = zext i32 %v1899 to i64
  %cond1901 = icmp ne i64 %cv1900, 0
  br i1 %cond1901, label %bb_rcsuccess323, label %bb_rcfailure323
bb_rcfailure323:
  %v1902 = load i64, ptr %slot41, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  %call1904 = call i32 @myl_rc_take_failure(ptr %p1903) nomerge, !dbg !126
  store i32 %call1904, ptr %slot255, align 8
  %v1905 = load i64, ptr %slot1, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  %v1907 = load i32, ptr %slot255, align 8
  %call1908 = call i32 @myl_qbe_rc_status(ptr %p1906, i32 %v1907) nomerge, !dbg !126
  store i32 %call1908, ptr %slot256, align 8
  br label %bb_failure
bb_rcsuccess323:
  %v1909 = load i64, ptr %slot15, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  store i32 2, ptr %p1910, align 4, !alias.scope !3, !noalias !4
  %v1911 = load i64, ptr %slot14, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  store i32 1, ptr %p1912, align 4, !alias.scope !3, !noalias !4
  %v1913 = load i64, ptr %slot12, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  %ld1915 = load i32, ptr %p1914, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1915, ptr %slot257, align 8
  %v1916 = load i32, ptr %slot257, align 8
  %cv1917 = zext i32 %v1916 to i64
  %cond1918 = icmp ne i64 %cv1917, 0
  br i1 %cond1918, label %bb_rcslotdrop330, label %bb_rcslotdone330
bb_rcslotdrop330:
  %v1919 = load i64, ptr %slot12, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  store i32 0, ptr %p1920, align 4, !alias.scope !3, !noalias !4
  %v1921 = load i64, ptr %slot17, align 8
  store i64 %v1921, ptr %slot258, align 8
  %v1922 = load i64, ptr %slot13, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %ld1924 = load i32, ptr %p1923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1924, ptr %slot259, align 8
  %v1925 = load i32, ptr %slot259, align 8
  %op1926 = and i32 %v1925, 28
  store i32 %op1926, ptr %slot260, align 8
  %v1927 = load i32, ptr %slot260, align 8
  %cv1928 = zext i32 %v1927 to i64
  %cond1929 = icmp ne i64 %cv1928, 0
  br i1 %cond1929, label %bb_rcslotrole330, label %bb_rcslotowner330
bb_rcslotrole330:
  %v1930 = load i64, ptr %slot41, align 8
  store i64 %v1930, ptr %slot261, align 8
  %v1931 = load i64, ptr %slot261, align 8
  %v1932 = load i64, ptr %slot258, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v1931, i64 %v1932) nomerge, !dbg !126
  br label %bb_rcslotdone330
bb_rcslotowner330:
  %v1933 = load i64, ptr %slot258, align 8
  %p1935 = inttoptr i64 %v1933 to ptr
  %gep1936 = getelementptr i8, ptr %p1935, i64 0
  %op1934 = ptrtoint ptr %gep1936 to i64
  store i64 %op1934, ptr %slot262, align 8
  %v1937 = load i64, ptr %slot41, align 8
  store i64 %v1937, ptr %slot263, align 8
  %v1938 = load i64, ptr %slot262, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  %ld1940 = load i64, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1940, ptr %slot264, align 8
  %v1941 = load i64, ptr %slot264, align 8
  %cmp1942 = icmp ne i64 %v1941, 0
  %cv1943 = zext i1 %cmp1942 to i32
  store i32 %cv1943, ptr %slot265, align 8
  %v1944 = load i32, ptr %slot265, align 8
  %cv1945 = zext i32 %v1944 to i64
  %cond1946 = icmp ne i64 %cv1945, 0
  br i1 %cond1946, label %bb_rcgnn348, label %bb_rcgdone348
bb_rcgnn348:
  %v1947 = load i64, ptr %slot264, align 8
  %op1948 = sub i64 %v1947, 16
  store i64 %op1948, ptr %slot266, align 8
  %v1949 = load i64, ptr %slot264, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %rgep1951 = getelementptr i8, ptr %p1950, i64 -16
  %ld1952 = load i64, ptr %rgep1951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1952, ptr %slot267, align 8
  %v1953 = load i64, ptr %slot267, align 8
  %op1954 = and i64 %v1953, 4611686018427387906
  store i64 %op1954, ptr %slot268, align 8
  %v1955 = load i64, ptr %slot268, align 8
  %cmp1956 = icmp ne i64 %v1955, 0
  %cv1957 = zext i1 %cmp1956 to i32
  store i32 %cv1957, ptr %slot269, align 8
  %v1958 = load i32, ptr %slot269, align 8
  %cv1959 = zext i32 %v1958 to i64
  %cond1960 = icmp ne i64 %cv1959, 0
  br i1 %cond1960, label %bb_rcgclear348, label %bb_rcgcounted348
bb_rcgcounted348:
  %v1961 = load i64, ptr %slot264, align 8
  %op1962 = sub i64 %v1961, 32
  store i64 %op1962, ptr %slot270, align 8
  %v1963 = load i64, ptr %slot264, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  %rgep1965 = getelementptr i8, ptr %p1964, i64 -32
  %ld1966 = load i64, ptr %rgep1965, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1966, ptr %slot271, align 8
  %v1967 = load i64, ptr %slot271, align 8
  %op1968 = sub i64 %v1967, 1
  store i64 %op1968, ptr %slot272, align 8
  %v1969 = load i64, ptr %slot272, align 8
  %cmp1970 = icmp eq i64 %v1969, 0
  %cv1971 = zext i1 %cmp1970 to i32
  store i32 %cv1971, ptr %slot273, align 8
  %v1972 = load i32, ptr %slot273, align 8
  %cv1973 = zext i32 %v1972 to i64
  %cond1974 = icmp ne i64 %cv1973, 0
  br i1 %cond1974, label %bb_rcglast348, label %bb_rcgdec348
bb_rcglast348:
  %v1975 = load i64, ptr %slot264, align 8
  %op1976 = sub i64 %v1975, 24
  store i64 %op1976, ptr %slot274, align 8
  %v1977 = load i64, ptr %slot264, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  %rgep1979 = getelementptr i8, ptr %p1978, i64 -24
  %ld1980 = load i64, ptr %rgep1979, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1980, ptr %slot275, align 8
  %v1981 = load i64, ptr %slot275, align 8
  %cmp1982 = icmp ne i64 %v1981, 0
  %cv1983 = zext i1 %cmp1982 to i32
  store i32 %cv1983, ptr %slot276, align 8
  %v1984 = load i32, ptr %slot276, align 8
  %cv1985 = zext i32 %v1984 to i64
  %cond1986 = icmp ne i64 %cv1985, 0
  br i1 %cond1986, label %bb_rcgdec348, label %bb_rcgslow348
bb_rcgslow348:
  %v1987 = load i64, ptr %slot263, align 8
  %v1988 = load i64, ptr %slot262, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1987, i64 %v1988) nomerge, !dbg !126
  br label %bb_rcgdone348
bb_rcgdec348:
  %v1989 = load i64, ptr %slot272, align 8
  %v1990 = load i64, ptr %slot264, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  %rgep1992 = getelementptr i8, ptr %p1991, i64 -32
  store i64 %v1989, ptr %rgep1992, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear348
bb_rcgclear348:
  %v1993 = load i64, ptr %slot262, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  store i64 0, ptr %p1994, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone348
bb_rcgdone348:
  %v1995 = load i64, ptr %slot258, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i64 0, ptr %p1996, align 8, !alias.scope !3, !noalias !4
  %v1997 = load i64, ptr %slot258, align 8
  %p1999 = inttoptr i64 %v1997 to ptr
  %gep2000 = getelementptr i8, ptr %p1999, i64 8
  %op1998 = ptrtoint ptr %gep2000 to i64
  store i64 %op1998, ptr %slot277, align 8
  %v2001 = load i64, ptr %slot277, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  store i64 0, ptr %p2002, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone330
bb_rcslotdone330:
  br label %bb_rcprepared289
bb_rcprepared289:
  %v2003 = load i64, ptr %slot6, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  %ld2005 = load i32, ptr %p2004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2005, ptr %slot278, align 8
  %v2006 = load i32, ptr %slot278, align 8
  %cv2007 = zext i32 %v2006 to i64
  %cond2008 = icmp ne i64 %cv2007, 0
  br i1 %cond2008, label %bb_rcslotdrop356, label %bb_rcslotdone356
bb_rcslotdrop356:
  %v2009 = load i64, ptr %slot6, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  store i32 0, ptr %p2010, align 4, !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot23, align 8
  store i64 %v2011, ptr %slot279, align 8
  %v2012 = load i64, ptr %slot7, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  %ld2014 = load i32, ptr %p2013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2014, ptr %slot280, align 8
  %v2015 = load i32, ptr %slot280, align 8
  %op2016 = and i32 %v2015, 28
  store i32 %op2016, ptr %slot281, align 8
  %v2017 = load i32, ptr %slot281, align 8
  %cv2018 = zext i32 %v2017 to i64
  %cond2019 = icmp ne i64 %cv2018, 0
  br i1 %cond2019, label %bb_rcslotrole356, label %bb_rcslotowner356
bb_rcslotrole356:
  %v2020 = load i64, ptr %slot41, align 8
  store i64 %v2020, ptr %slot282, align 8
  %v2021 = load i64, ptr %slot282, align 8
  %v2022 = load i64, ptr %slot279, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v2021, i64 %v2022) nomerge, !dbg !126
  br label %bb_rcslotdone356
bb_rcslotowner356:
  %v2023 = load i64, ptr %slot279, align 8
  %p2025 = inttoptr i64 %v2023 to ptr
  %gep2026 = getelementptr i8, ptr %p2025, i64 0
  %op2024 = ptrtoint ptr %gep2026 to i64
  store i64 %op2024, ptr %slot283, align 8
  %v2027 = load i64, ptr %slot41, align 8
  store i64 %v2027, ptr %slot284, align 8
  %v2028 = load i64, ptr %slot283, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  %ld2030 = load i64, ptr %p2029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2030, ptr %slot285, align 8
  %v2031 = load i64, ptr %slot285, align 8
  %cmp2032 = icmp ne i64 %v2031, 0
  %cv2033 = zext i1 %cmp2032 to i32
  store i32 %cv2033, ptr %slot286, align 8
  %v2034 = load i32, ptr %slot286, align 8
  %cv2035 = zext i32 %v2034 to i64
  %cond2036 = icmp ne i64 %cv2035, 0
  br i1 %cond2036, label %bb_rcgnn374, label %bb_rcgdone374
bb_rcgnn374:
  %v2037 = load i64, ptr %slot285, align 8
  %op2038 = sub i64 %v2037, 16
  store i64 %op2038, ptr %slot287, align 8
  %v2039 = load i64, ptr %slot285, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  %rgep2041 = getelementptr i8, ptr %p2040, i64 -16
  %ld2042 = load i64, ptr %rgep2041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2042, ptr %slot288, align 8
  %v2043 = load i64, ptr %slot288, align 8
  %op2044 = and i64 %v2043, 4611686018427387906
  store i64 %op2044, ptr %slot289, align 8
  %v2045 = load i64, ptr %slot289, align 8
  %cmp2046 = icmp ne i64 %v2045, 0
  %cv2047 = zext i1 %cmp2046 to i32
  store i32 %cv2047, ptr %slot290, align 8
  %v2048 = load i32, ptr %slot290, align 8
  %cv2049 = zext i32 %v2048 to i64
  %cond2050 = icmp ne i64 %cv2049, 0
  br i1 %cond2050, label %bb_rcgclear374, label %bb_rcgcounted374
bb_rcgcounted374:
  %v2051 = load i64, ptr %slot285, align 8
  %op2052 = sub i64 %v2051, 32
  store i64 %op2052, ptr %slot291, align 8
  %v2053 = load i64, ptr %slot285, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  %rgep2055 = getelementptr i8, ptr %p2054, i64 -32
  %ld2056 = load i64, ptr %rgep2055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2056, ptr %slot292, align 8
  %v2057 = load i64, ptr %slot292, align 8
  %op2058 = sub i64 %v2057, 1
  store i64 %op2058, ptr %slot293, align 8
  %v2059 = load i64, ptr %slot293, align 8
  %cmp2060 = icmp eq i64 %v2059, 0
  %cv2061 = zext i1 %cmp2060 to i32
  store i32 %cv2061, ptr %slot294, align 8
  %v2062 = load i32, ptr %slot294, align 8
  %cv2063 = zext i32 %v2062 to i64
  %cond2064 = icmp ne i64 %cv2063, 0
  br i1 %cond2064, label %bb_rcglast374, label %bb_rcgdec374
bb_rcglast374:
  %v2065 = load i64, ptr %slot285, align 8
  %op2066 = sub i64 %v2065, 24
  store i64 %op2066, ptr %slot295, align 8
  %v2067 = load i64, ptr %slot285, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %rgep2069 = getelementptr i8, ptr %p2068, i64 -24
  %ld2070 = load i64, ptr %rgep2069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2070, ptr %slot296, align 8
  %v2071 = load i64, ptr %slot296, align 8
  %cmp2072 = icmp ne i64 %v2071, 0
  %cv2073 = zext i1 %cmp2072 to i32
  store i32 %cv2073, ptr %slot297, align 8
  %v2074 = load i32, ptr %slot297, align 8
  %cv2075 = zext i32 %v2074 to i64
  %cond2076 = icmp ne i64 %cv2075, 0
  br i1 %cond2076, label %bb_rcgdec374, label %bb_rcgslow374
bb_rcgslow374:
  %v2077 = load i64, ptr %slot284, align 8
  %v2078 = load i64, ptr %slot283, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2077, i64 %v2078) nomerge, !dbg !126
  br label %bb_rcgdone374
bb_rcgdec374:
  %v2079 = load i64, ptr %slot293, align 8
  %v2080 = load i64, ptr %slot285, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  %rgep2082 = getelementptr i8, ptr %p2081, i64 -32
  store i64 %v2079, ptr %rgep2082, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear374
bb_rcgclear374:
  %v2083 = load i64, ptr %slot283, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  store i64 0, ptr %p2084, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone374
bb_rcgdone374:
  %v2085 = load i64, ptr %slot279, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  store i64 0, ptr %p2086, align 8, !alias.scope !3, !noalias !4
  %v2087 = load i64, ptr %slot279, align 8
  %p2089 = inttoptr i64 %v2087 to ptr
  %gep2090 = getelementptr i8, ptr %p2089, i64 8
  %op2088 = ptrtoint ptr %gep2090 to i64
  store i64 %op2088, ptr %slot298, align 8
  %v2091 = load i64, ptr %slot298, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  store i64 0, ptr %p2092, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone356
bb_rcslotdone356:
  %v2093 = load i64, ptr %slot23, align 8
  store i64 %v2093, ptr %slot299, align 8
  %v2094 = load i64, ptr %slot18, align 8
  store i64 %v2094, ptr %slot300, align 8
  %v2095 = load i64, ptr %slot300, align 8
  %v2096 = load i64, ptr %slot299, align 8
  %p2097 = inttoptr i64 %v2095 to ptr
  %p2098 = inttoptr i64 %v2096 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2098, ptr %p2097, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2099 = load i64, ptr %slot14, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  store i32 0, ptr %p2100, align 4, !alias.scope !3, !noalias !4
  %v2101 = load i64, ptr %slot7, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  store i32 2, ptr %p2102, align 4, !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot15, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  %ld2105 = load i32, ptr %p2104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2105, ptr %slot301, align 8
  %v2106 = load i32, ptr %slot301, align 8
  %v2107 = load i64, ptr %slot7, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  store i32 %v2106, ptr %p2108, align 4, !alias.scope !3, !noalias !4
  %v2109 = load i64, ptr %slot6, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  store i32 1, ptr %p2110, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcselfkept287
bb_rcselfkept287:
  %v2111 = load i64, ptr %slot19, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  %ld2113 = load i64, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2113, ptr %slot302, align 8
  %v2114 = load i64, ptr %slot302, align 8
  %v2115 = load i64, ptr %slot31, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i64 %v2114, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot20, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  %ld2119 = load i64, ptr %p2118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2119, ptr %slot303, align 8
  %v2120 = load i64, ptr %slot303, align 8
  %v2121 = load i64, ptr %slot32, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  store i64 %v2120, ptr %p2122, align 8, !alias.scope !3, !noalias !4
  %v2123 = load i64, ptr %slot23, align 8
  %v2124 = load i64, ptr %slot33, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  store i64 %v2123, ptr %p2125, align 8, !alias.scope !3, !noalias !4
  %v2126 = load i64, ptr %slot33, align 8
  %p2127 = inttoptr i64 %v2126 to ptr
  %ld2128 = load i64, ptr %p2127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2128, ptr %slot304, align 8
  %v2129 = load i64, ptr %slot304, align 8
  %op2130 = add i64 %v2129, 8
  store i64 %op2130, ptr %slot305, align 8
  %v2131 = load i64, ptr %slot305, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  %ld2133 = load i64, ptr %p2132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2133, ptr %slot306, align 8
  %v2134 = load i64, ptr %slot306, align 8
  %v2135 = load i64, ptr %slot33, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  store i64 %v2134, ptr %p2136, align 8, !alias.scope !3, !noalias !4
  %v2137 = load i64, ptr %slot31, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  %ld2139 = load i64, ptr %p2138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2139, ptr %slot307, align 8
  %v2140 = load i64, ptr %slot32, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %ld2142 = load i64, ptr %p2141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2142, ptr %slot308, align 8
  %v2143 = load i64, ptr %slot33, align 8
  %p2144 = inttoptr i64 %v2143 to ptr
  %ld2145 = load i64, ptr %p2144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2145, ptr %slot309, align 8
  %v2146 = load i64, ptr %slot1, align 8
  %v2147 = load i64, ptr %slot307, align 8
  %v2148 = load i64, ptr %slot308, align 8
  %v2149 = load i64, ptr %slot309, align 8
  call void @myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763(ptr sret([24 x i8]) align 8 %callresult311, i64 %v2146, i64 %v2147, i64 %v2148, i64 %v2149) nomerge, !dbg !128
  %addr2150 = ptrtoint ptr %callresult311 to i64
  store i64 %addr2150, ptr %slot310, align 8
  %v2151 = load i64, ptr %slot310, align 8
  %v2152 = load i64, ptr %slot31, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  store i64 %v2151, ptr %p2153, align 8, !alias.scope !3, !noalias !4
  %v2154 = load i64, ptr %slot31, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  %ld2156 = load i64, ptr %p2155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2156, ptr %slot312, align 8
  %v2157 = load i64, ptr %slot18, align 8
  store i64 %v2157, ptr %slot313, align 8
  %v2158 = load i64, ptr %slot312, align 8
  %v2159 = load i64, ptr %slot313, align 8
  %p2160 = inttoptr i64 %v2158 to ptr
  %p2161 = inttoptr i64 %v2159 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2161, ptr %p2160, i64 24, i1 false)
  %v2162 = load i64, ptr %slot15, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  store i32 2, ptr %p2163, align 4, !alias.scope !3, !noalias !4
  %v2164 = load i64, ptr %slot14, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  store i32 1, ptr %p2165, align 4, !alias.scope !3, !noalias !4
  %v2166 = load i64, ptr %slot12, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %ld2168 = load i32, ptr %p2167, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2168, ptr %slot314, align 8
  %v2169 = load i32, ptr %slot314, align 8
  %cv2170 = zext i32 %v2169 to i64
  %cond2171 = icmp ne i64 %cv2170, 0
  br i1 %cond2171, label %bb_rcslotdrop410, label %bb_rcslotdone410
bb_rcslotdrop410:
  %v2172 = load i64, ptr %slot12, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  store i32 0, ptr %p2173, align 4, !alias.scope !3, !noalias !4
  %v2174 = load i64, ptr %slot17, align 8
  store i64 %v2174, ptr %slot315, align 8
  %v2175 = load i64, ptr %slot13, align 8
  %p2176 = inttoptr i64 %v2175 to ptr
  %ld2177 = load i32, ptr %p2176, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2177, ptr %slot316, align 8
  %v2178 = load i32, ptr %slot316, align 8
  %op2179 = and i32 %v2178, 28
  store i32 %op2179, ptr %slot317, align 8
  %v2180 = load i32, ptr %slot317, align 8
  %cv2181 = zext i32 %v2180 to i64
  %cond2182 = icmp ne i64 %cv2181, 0
  br i1 %cond2182, label %bb_rcslotrole410, label %bb_rcslotowner410
bb_rcslotrole410:
  %v2183 = load i64, ptr %slot41, align 8
  store i64 %v2183, ptr %slot318, align 8
  %v2184 = load i64, ptr %slot318, align 8
  %v2185 = load i64, ptr %slot315, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2184, i64 %v2185) nomerge, !dbg !128
  br label %bb_rcslotdone410
bb_rcslotowner410:
  %v2186 = load i64, ptr %slot41, align 8
  store i64 %v2186, ptr %slot319, align 8
  %v2187 = load i64, ptr %slot319, align 8
  %v2188 = load i64, ptr %slot315, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2187, i64 %v2188) nomerge, !dbg !128
  br label %bb_rcslotdone410
bb_rcslotdone410:
  %v2189 = load i64, ptr %slot17, align 8
  store i64 %v2189, ptr %slot320, align 8
  %v2190 = load i64, ptr %slot18, align 8
  store i64 %v2190, ptr %slot321, align 8
  %v2191 = load i64, ptr %slot321, align 8
  %v2192 = load i64, ptr %slot320, align 8
  %p2193 = inttoptr i64 %v2191 to ptr
  %p2194 = inttoptr i64 %v2192 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2194, ptr %p2193, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2195 = load i64, ptr %slot13, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  store i32 2, ptr %p2196, align 4, !alias.scope !3, !noalias !4
  %v2197 = load i64, ptr %slot15, align 8
  %p2198 = inttoptr i64 %v2197 to ptr
  %ld2199 = load i32, ptr %p2198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2199, ptr %slot322, align 8
  %v2200 = load i32, ptr %slot322, align 8
  %v2201 = load i64, ptr %slot13, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  store i32 %v2200, ptr %p2202, align 4, !alias.scope !3, !noalias !4
  %v2203 = load i64, ptr %slot14, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  store i32 0, ptr %p2204, align 4, !alias.scope !3, !noalias !4
  %v2205 = load i64, ptr %slot12, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  store i32 1, ptr %p2206, align 4, !alias.scope !3, !noalias !4
  %v2207 = load i64, ptr %slot320, align 8
  %v2208 = load i64, ptr %slot31, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  store i64 %v2207, ptr %p2209, align 8, !alias.scope !3, !noalias !4
  %v2210 = load i64, ptr %slot31, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  %ld2212 = load i64, ptr %p2211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2212, ptr %slot323, align 8
  %v2213 = load i64, ptr %slot323, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  %ld2215 = load i32, ptr %p2214, align 4, !alias.scope !3, !noalias !4
  %ext2216 = zext i32 %ld2215 to i64
  store i64 %ext2216, ptr %slot324, align 8
  %v2217 = load i64, ptr %slot324, align 8
  %cmp2218 = icmp eq i64 %v2217, 1
  %cv2219 = zext i1 %cmp2218 to i64
  store i64 %cv2219, ptr %slot325, align 8
  %v2220 = load i64, ptr %slot325, align 8
  %cond2221 = icmp ne i64 %v2220, 0
  br i1 %cond2221, label %bb_errtrace427, label %bb_errtraced427
bb_errtrace427:
  %p2222 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2222, i64 8589934618) "call-inline-cost"="0", !dbg !130
  br label %bb_errtraced427
bb_errtraced427:
  %v2223 = load i64, ptr %slot31, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %ld2225 = load i64, ptr %p2224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2225, ptr %slot326, align 8
  %v2226 = load i64, ptr %slot18, align 8
  store i64 %v2226, ptr %slot327, align 8
  %v2227 = load i64, ptr %slot42, align 8
  store i64 %v2227, ptr %slot328, align 8
  %v2228 = load i64, ptr %slot41, align 8
  %v2229 = load i64, ptr %slot327, align 8
  %v2230 = load i64, ptr %slot326, align 8
  %v2231 = load i64, ptr %slot328, align 8
  %cv2232 = trunc i64 %v2231 to i32
  %call2233 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v2228, i64 %v2229, i64 %v2230, i32 %cv2232) nomerge, !dbg !130
  store i32 %call2233, ptr %slot329, align 8
  %v2234 = load i32, ptr %slot329, align 8
  %cv2235 = zext i32 %v2234 to i64
  %cond2236 = icmp ne i64 %cv2235, 0
  br i1 %cond2236, label %bb_rcsuccess432, label %bb_rcfailure432
bb_rcfailure432:
  %v2237 = load i64, ptr %slot41, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  %call2239 = call i32 @myl_rc_take_failure(ptr %p2238) nomerge, !dbg !130
  store i32 %call2239, ptr %slot330, align 8
  %v2240 = load i64, ptr %slot1, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  %v2242 = load i32, ptr %slot330, align 8
  %call2243 = call i32 @myl_qbe_rc_status(ptr %p2241, i32 %v2242) nomerge, !dbg !130
  store i32 %call2243, ptr %slot331, align 8
  br label %bb_failure
bb_rcsuccess432:
  %v2244 = load i64, ptr %slot12, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  store i32 0, ptr %p2245, align 4, !alias.scope !3, !noalias !4
  %v2246 = load i64, ptr %slot15, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  store i32 2, ptr %p2247, align 4, !alias.scope !3, !noalias !4
  %v2248 = load i64, ptr %slot14, align 8
  %p2249 = inttoptr i64 %v2248 to ptr
  store i32 1, ptr %p2249, align 4, !alias.scope !3, !noalias !4
  %v2250 = load i64, ptr %slot18, align 8
  store i64 %v2250, ptr %slot332, align 8
  %v2251 = load i64, ptr %slot14, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i32 0, ptr %p2252, align 4, !alias.scope !3, !noalias !4
  %v2253 = load i64, ptr %slot12, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  %ld2255 = load i32, ptr %p2254, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2255, ptr %slot333, align 8
  %v2256 = load i32, ptr %slot333, align 8
  %cv2257 = zext i32 %v2256 to i64
  %cond2258 = icmp ne i64 %cv2257, 0
  br i1 %cond2258, label %bb_rcslotdrop442, label %bb_rcslotdone442
bb_rcslotdrop442:
  %v2259 = load i64, ptr %slot12, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  store i32 0, ptr %p2260, align 4, !alias.scope !3, !noalias !4
  %v2261 = load i64, ptr %slot17, align 8
  store i64 %v2261, ptr %slot334, align 8
  %v2262 = load i64, ptr %slot13, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  %ld2264 = load i32, ptr %p2263, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2264, ptr %slot335, align 8
  %v2265 = load i32, ptr %slot335, align 8
  %op2266 = and i32 %v2265, 28
  store i32 %op2266, ptr %slot336, align 8
  %v2267 = load i32, ptr %slot336, align 8
  %cv2268 = zext i32 %v2267 to i64
  %cond2269 = icmp ne i64 %cv2268, 0
  br i1 %cond2269, label %bb_rcslotrole442, label %bb_rcslotowner442
bb_rcslotrole442:
  %v2270 = load i64, ptr %slot41, align 8
  store i64 %v2270, ptr %slot337, align 8
  %v2271 = load i64, ptr %slot337, align 8
  %v2272 = load i64, ptr %slot334, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2271, i64 %v2272) nomerge, !dbg !130
  br label %bb_rcslotdone442
bb_rcslotowner442:
  %v2273 = load i64, ptr %slot41, align 8
  store i64 %v2273, ptr %slot338, align 8
  %v2274 = load i64, ptr %slot338, align 8
  %v2275 = load i64, ptr %slot334, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2274, i64 %v2275) nomerge, !dbg !130
  br label %bb_rcslotdone442
bb_rcslotdone442:
  %v2276 = load i64, ptr %slot10, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %ld2278 = load i32, ptr %p2277, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2278, ptr %slot339, align 8
  %v2279 = load i32, ptr %slot339, align 8
  %cv2280 = zext i32 %v2279 to i64
  %cond2281 = icmp ne i64 %cv2280, 0
  br i1 %cond2281, label %bb_rcslotdrop451, label %bb_rcslotdone451
bb_rcslotdrop451:
  %v2282 = load i64, ptr %slot10, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  store i32 0, ptr %p2283, align 4, !alias.scope !3, !noalias !4
  %v2284 = load i64, ptr %slot29, align 8
  store i64 %v2284, ptr %slot340, align 8
  %v2285 = load i64, ptr %slot11, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %ld2287 = load i32, ptr %p2286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2287, ptr %slot341, align 8
  %v2288 = load i32, ptr %slot341, align 8
  %op2289 = and i32 %v2288, 28
  store i32 %op2289, ptr %slot342, align 8
  %v2290 = load i32, ptr %slot342, align 8
  %cv2291 = zext i32 %v2290 to i64
  %cond2292 = icmp ne i64 %cv2291, 0
  br i1 %cond2292, label %bb_rcslotrole451, label %bb_rcslotowner451
bb_rcslotrole451:
  %v2293 = load i64, ptr %slot41, align 8
  store i64 %v2293, ptr %slot343, align 8
  %v2294 = load i64, ptr %slot343, align 8
  %v2295 = load i64, ptr %slot340, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v2294, i64 %v2295) nomerge, !dbg !130
  br label %bb_rcslotdone451
bb_rcslotowner451:
  %v2296 = load i64, ptr %slot41, align 8
  store i64 %v2296, ptr %slot344, align 8
  %v2297 = load i64, ptr %slot344, align 8
  %v2298 = load i64, ptr %slot340, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v2297, i64 %v2298) nomerge, !dbg !130
  br label %bb_rcslotdone451
bb_rcslotdone451:
  %v2299 = load i64, ptr %slot8, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %ld2301 = load i32, ptr %p2300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2301, ptr %slot345, align 8
  %v2302 = load i32, ptr %slot345, align 8
  %cv2303 = zext i32 %v2302 to i64
  %cond2304 = icmp ne i64 %cv2303, 0
  br i1 %cond2304, label %bb_rcslotdrop460, label %bb_rcslotdone460
bb_rcslotdrop460:
  %v2305 = load i64, ptr %slot8, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  store i32 0, ptr %p2306, align 4, !alias.scope !3, !noalias !4
  %v2307 = load i64, ptr %slot28, align 8
  store i64 %v2307, ptr %slot346, align 8
  %v2308 = load i64, ptr %slot9, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  %ld2310 = load i32, ptr %p2309, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2310, ptr %slot347, align 8
  %v2311 = load i32, ptr %slot347, align 8
  %op2312 = and i32 %v2311, 28
  store i32 %op2312, ptr %slot348, align 8
  %v2313 = load i32, ptr %slot348, align 8
  %cv2314 = zext i32 %v2313 to i64
  %cond2315 = icmp ne i64 %cv2314, 0
  br i1 %cond2315, label %bb_rcslotrole460, label %bb_rcslotowner460
bb_rcslotrole460:
  %v2316 = load i64, ptr %slot41, align 8
  store i64 %v2316, ptr %slot349, align 8
  %v2317 = load i64, ptr %slot349, align 8
  %v2318 = load i64, ptr %slot346, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v2317, i64 %v2318) nomerge, !dbg !130
  br label %bb_rcslotdone460
bb_rcslotowner460:
  %v2319 = load i64, ptr %slot41, align 8
  store i64 %v2319, ptr %slot350, align 8
  %v2320 = load i64, ptr %slot350, align 8
  %v2321 = load i64, ptr %slot346, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v2320, i64 %v2321) nomerge, !dbg !130
  br label %bb_rcslotdone460
bb_rcslotdone460:
  %v2322 = load i64, ptr %slot6, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  %ld2324 = load i32, ptr %p2323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2324, ptr %slot351, align 8
  %v2325 = load i32, ptr %slot351, align 8
  %cv2326 = zext i32 %v2325 to i64
  %cond2327 = icmp ne i64 %cv2326, 0
  br i1 %cond2327, label %bb_rcslotdrop469, label %bb_rcslotdone469
bb_rcslotdrop469:
  %v2328 = load i64, ptr %slot6, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  store i32 0, ptr %p2329, align 4, !alias.scope !3, !noalias !4
  %v2330 = load i64, ptr %slot23, align 8
  store i64 %v2330, ptr %slot352, align 8
  %v2331 = load i64, ptr %slot7, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  %ld2333 = load i32, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2333, ptr %slot353, align 8
  %v2334 = load i32, ptr %slot353, align 8
  %op2335 = and i32 %v2334, 28
  store i32 %op2335, ptr %slot354, align 8
  %v2336 = load i32, ptr %slot354, align 8
  %cv2337 = zext i32 %v2336 to i64
  %cond2338 = icmp ne i64 %cv2337, 0
  br i1 %cond2338, label %bb_rcslotrole469, label %bb_rcslotowner469
bb_rcslotrole469:
  %v2339 = load i64, ptr %slot41, align 8
  store i64 %v2339, ptr %slot355, align 8
  %v2340 = load i64, ptr %slot355, align 8
  %v2341 = load i64, ptr %slot352, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v2340, i64 %v2341) nomerge, !dbg !130
  br label %bb_rcslotdone469
bb_rcslotowner469:
  %v2342 = load i64, ptr %slot41, align 8
  store i64 %v2342, ptr %slot356, align 8
  %v2343 = load i64, ptr %slot356, align 8
  %v2344 = load i64, ptr %slot352, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v2343, i64 %v2344) nomerge, !dbg !130
  br label %bb_rcslotdone469
bb_rcslotdone469:
  %v2345 = load i64, ptr %slot332, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2346, i64 24, i1 false)
  ret void
bb_i27:
  %v2347 = load i64, ptr %slot19, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  %ld2349 = load i64, ptr %p2348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2349, ptr %slot357, align 8
  %v2350 = load i64, ptr %slot357, align 8
  %v2351 = load i64, ptr %slot31, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  store i64 %v2350, ptr %p2352, align 8, !alias.scope !3, !noalias !4
  %v2353 = load i64, ptr %slot20, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  %ld2355 = load i64, ptr %p2354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2355, ptr %slot358, align 8
  %v2356 = load i64, ptr %slot358, align 8
  %v2357 = load i64, ptr %slot32, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i64 %v2356, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  %v2359 = load i64, ptr %slot31, align 8
  %p2360 = inttoptr i64 %v2359 to ptr
  %ld2361 = load i64, ptr %p2360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2361, ptr %slot359, align 8
  %v2362 = load i64, ptr %slot32, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  %ld2364 = load i64, ptr %p2363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2364, ptr %slot360, align 8
  %v2365 = load i64, ptr %slot1, align 8
  %v2366 = load i64, ptr %slot359, align 8
  %v2367 = load i64, ptr %slot360, align 8
  call void @myl_f_462f27e74799004fdcfa9633adb7a2d010fc9ea32e01e7826712c1dd2033d244(ptr sret([24 x i8]) align 8 %callresult362, i64 %v2365, i64 %v2366, i64 %v2367) nomerge, !dbg !132
  %addr2368 = ptrtoint ptr %callresult362 to i64
  store i64 %addr2368, ptr %slot361, align 8
  %v2369 = load i64, ptr %slot361, align 8
  %v2370 = load i64, ptr %slot31, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  store i64 %v2369, ptr %p2371, align 8, !alias.scope !3, !noalias !4
  %v2372 = load i64, ptr %slot31, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %ld2374 = load i64, ptr %p2373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2374, ptr %slot363, align 8
  %v2375 = load i64, ptr %slot18, align 8
  store i64 %v2375, ptr %slot364, align 8
  %v2376 = load i64, ptr %slot363, align 8
  %v2377 = load i64, ptr %slot364, align 8
  %p2378 = inttoptr i64 %v2376 to ptr
  %p2379 = inttoptr i64 %v2377 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2379, ptr %p2378, i64 24, i1 false)
  %v2380 = load i64, ptr %slot15, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  store i32 2, ptr %p2381, align 4, !alias.scope !3, !noalias !4
  %v2382 = load i64, ptr %slot14, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  store i32 1, ptr %p2383, align 4, !alias.scope !3, !noalias !4
  %v2384 = load i64, ptr %slot12, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  %ld2386 = load i32, ptr %p2385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2386, ptr %slot365, align 8
  %v2387 = load i32, ptr %slot365, align 8
  %cv2388 = zext i32 %v2387 to i64
  %cond2389 = icmp ne i64 %cv2388, 0
  br i1 %cond2389, label %bb_rcslotdrop533, label %bb_rcslotdone533
bb_rcslotdrop533:
  %v2390 = load i64, ptr %slot12, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  store i32 0, ptr %p2391, align 4, !alias.scope !3, !noalias !4
  %v2392 = load i64, ptr %slot17, align 8
  store i64 %v2392, ptr %slot366, align 8
  %v2393 = load i64, ptr %slot13, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  %ld2395 = load i32, ptr %p2394, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2395, ptr %slot367, align 8
  %v2396 = load i32, ptr %slot367, align 8
  %op2397 = and i32 %v2396, 28
  store i32 %op2397, ptr %slot368, align 8
  %v2398 = load i32, ptr %slot368, align 8
  %cv2399 = zext i32 %v2398 to i64
  %cond2400 = icmp ne i64 %cv2399, 0
  br i1 %cond2400, label %bb_rcslotrole533, label %bb_rcslotowner533
bb_rcslotrole533:
  %v2401 = load i64, ptr %slot41, align 8
  store i64 %v2401, ptr %slot369, align 8
  %v2402 = load i64, ptr %slot369, align 8
  %v2403 = load i64, ptr %slot366, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2402, i64 %v2403) nomerge, !dbg !132
  br label %bb_rcslotdone533
bb_rcslotowner533:
  %v2404 = load i64, ptr %slot41, align 8
  store i64 %v2404, ptr %slot370, align 8
  %v2405 = load i64, ptr %slot370, align 8
  %v2406 = load i64, ptr %slot366, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2405, i64 %v2406) nomerge, !dbg !132
  br label %bb_rcslotdone533
bb_rcslotdone533:
  %v2407 = load i64, ptr %slot17, align 8
  store i64 %v2407, ptr %slot371, align 8
  %v2408 = load i64, ptr %slot18, align 8
  store i64 %v2408, ptr %slot372, align 8
  %v2409 = load i64, ptr %slot372, align 8
  %v2410 = load i64, ptr %slot371, align 8
  %p2411 = inttoptr i64 %v2409 to ptr
  %p2412 = inttoptr i64 %v2410 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2412, ptr %p2411, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2413 = load i64, ptr %slot13, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  store i32 2, ptr %p2414, align 4, !alias.scope !3, !noalias !4
  %v2415 = load i64, ptr %slot15, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  %ld2417 = load i32, ptr %p2416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2417, ptr %slot373, align 8
  %v2418 = load i32, ptr %slot373, align 8
  %v2419 = load i64, ptr %slot13, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  store i32 %v2418, ptr %p2420, align 4, !alias.scope !3, !noalias !4
  %v2421 = load i64, ptr %slot14, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  store i32 0, ptr %p2422, align 4, !alias.scope !3, !noalias !4
  %v2423 = load i64, ptr %slot12, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  store i32 1, ptr %p2424, align 4, !alias.scope !3, !noalias !4
  %v2425 = load i64, ptr %slot371, align 8
  %v2426 = load i64, ptr %slot31, align 8
  %p2427 = inttoptr i64 %v2426 to ptr
  store i64 %v2425, ptr %p2427, align 8, !alias.scope !3, !noalias !4
  %v2428 = load i64, ptr %slot31, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  %ld2430 = load i64, ptr %p2429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2430, ptr %slot374, align 8
  %v2431 = load i64, ptr %slot374, align 8
  %p2432 = inttoptr i64 %v2431 to ptr
  %ld2433 = load i32, ptr %p2432, align 4, !alias.scope !3, !noalias !4
  %ext2434 = zext i32 %ld2433 to i64
  store i64 %ext2434, ptr %slot375, align 8
  %v2435 = load i64, ptr %slot375, align 8
  %cmp2436 = icmp eq i64 %v2435, 0
  %cv2437 = zext i1 %cmp2436 to i64
  store i64 %cv2437, ptr %slot376, align 8
  %v2438 = load i64, ptr %slot376, align 8
  %cond2439 = icmp ne i64 %v2438, 0
  br i1 %cond2439, label %bb_rctryok549, label %bb_rctryerror549
bb_rctryerror549:
  %p2440 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2440, i64 12884901918) "call-inline-cost"="0", !dbg !134
  %v2441 = load i64, ptr %slot374, align 8
  %op2442 = add i64 %v2441, 8
  store i64 %op2442, ptr %slot377, align 8
  %v2443 = load i64, ptr %slot34, align 8
  store i64 %v2443, ptr %slot378, align 8
  %v2444 = load i64, ptr %slot378, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  store i64 0, ptr %p2445, align 8, !alias.scope !3, !noalias !4
  %v2446 = load i64, ptr %slot378, align 8
  %p2448 = inttoptr i64 %v2446 to ptr
  %gep2449 = getelementptr i8, ptr %p2448, i64 8
  %op2447 = ptrtoint ptr %gep2449 to i64
  store i64 %op2447, ptr %slot379, align 8
  %v2450 = load i64, ptr %slot379, align 8
  %p2451 = inttoptr i64 %v2450 to ptr
  store i64 0, ptr %p2451, align 8, !alias.scope !3, !noalias !4
  %v2452 = load i64, ptr %slot378, align 8
  %p2454 = inttoptr i64 %v2452 to ptr
  %gep2455 = getelementptr i8, ptr %p2454, i64 16
  %op2453 = ptrtoint ptr %gep2455 to i64
  store i64 %op2453, ptr %slot380, align 8
  %v2456 = load i64, ptr %slot380, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  store i64 0, ptr %p2457, align 8, !alias.scope !3, !noalias !4
  %v2458 = load i64, ptr %slot378, align 8
  %p2459 = inttoptr i64 %v2458 to ptr
  store i32 1, ptr %p2459, align 4, !alias.scope !3, !noalias !4
  %v2460 = load i64, ptr %slot378, align 8
  %p2462 = inttoptr i64 %v2460 to ptr
  %gep2463 = getelementptr i8, ptr %p2462, i64 8
  %op2461 = ptrtoint ptr %gep2463 to i64
  store i64 %op2461, ptr %slot381, align 8
  %v2464 = load i64, ptr %slot16, align 8
  %p2465 = inttoptr i64 %v2464 to ptr
  store i32 1, ptr %p2465, align 4, !alias.scope !3, !noalias !4
  %v2466 = load i64, ptr %slot42, align 8
  store i64 %v2466, ptr %slot382, align 8
  %v2467 = load i64, ptr %slot41, align 8
  %v2468 = load i64, ptr %slot381, align 8
  %v2469 = load i64, ptr %slot377, align 8
  %v2470 = load i64, ptr %slot382, align 8
  %cv2471 = trunc i64 %v2470 to i32
  %call2472 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v2467, i64 %v2468, i64 %v2469, i32 %cv2471) nomerge, !dbg !134
  store i32 %call2472, ptr %slot383, align 8
  %v2473 = load i32, ptr %slot383, align 8
  %cv2474 = zext i32 %v2473 to i64
  %cond2475 = icmp ne i64 %cv2474, 0
  br i1 %cond2475, label %bb_rcsuccess560, label %bb_rcfailure560
bb_rcfailure560:
  %v2476 = load i64, ptr %slot41, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  %call2478 = call i32 @myl_rc_take_failure(ptr %p2477) nomerge, !dbg !134
  store i32 %call2478, ptr %slot384, align 8
  %v2479 = load i64, ptr %slot1, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  %v2481 = load i32, ptr %slot384, align 8
  %call2482 = call i32 @myl_qbe_rc_status(ptr %p2480, i32 %v2481) nomerge, !dbg !134
  store i32 %call2482, ptr %slot385, align 8
  br label %bb_failure
bb_rcsuccess560:
  %v2483 = load i64, ptr %slot378, align 8
  %v2484 = load i64, ptr %slot31, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  store i64 %v2483, ptr %p2485, align 8, !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot31, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  %ld2488 = load i64, ptr %p2487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2488, ptr %slot386, align 8
  %v2489 = load i64, ptr %slot18, align 8
  store i64 %v2489, ptr %slot387, align 8
  %v2490 = load i64, ptr %slot386, align 8
  %v2491 = load i64, ptr %slot387, align 8
  %p2492 = inttoptr i64 %v2490 to ptr
  %p2493 = inttoptr i64 %v2491 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2493, ptr %p2492, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2494 = load i64, ptr %slot15, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  store i32 2, ptr %p2495, align 4, !alias.scope !3, !noalias !4
  %v2496 = load i64, ptr %slot14, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  store i32 1, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  %v2498 = load i64, ptr %slot12, align 8
  %p2499 = inttoptr i64 %v2498 to ptr
  %ld2500 = load i32, ptr %p2499, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2500, ptr %slot388, align 8
  %v2501 = load i32, ptr %slot388, align 8
  %cv2502 = zext i32 %v2501 to i64
  %cond2503 = icmp ne i64 %cv2502, 0
  br i1 %cond2503, label %bb_rcslotdrop569, label %bb_rcslotdone569
bb_rcslotdrop569:
  %v2504 = load i64, ptr %slot12, align 8
  %p2505 = inttoptr i64 %v2504 to ptr
  store i32 0, ptr %p2505, align 4, !alias.scope !3, !noalias !4
  %v2506 = load i64, ptr %slot17, align 8
  store i64 %v2506, ptr %slot389, align 8
  %v2507 = load i64, ptr %slot13, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  %ld2509 = load i32, ptr %p2508, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2509, ptr %slot390, align 8
  %v2510 = load i32, ptr %slot390, align 8
  %op2511 = and i32 %v2510, 28
  store i32 %op2511, ptr %slot391, align 8
  %v2512 = load i32, ptr %slot391, align 8
  %cv2513 = zext i32 %v2512 to i64
  %cond2514 = icmp ne i64 %cv2513, 0
  br i1 %cond2514, label %bb_rcslotrole569, label %bb_rcslotowner569
bb_rcslotrole569:
  %v2515 = load i64, ptr %slot41, align 8
  store i64 %v2515, ptr %slot392, align 8
  %v2516 = load i64, ptr %slot392, align 8
  %v2517 = load i64, ptr %slot389, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2516, i64 %v2517) nomerge, !dbg !134
  br label %bb_rcslotdone569
bb_rcslotowner569:
  %v2518 = load i64, ptr %slot41, align 8
  store i64 %v2518, ptr %slot393, align 8
  %v2519 = load i64, ptr %slot393, align 8
  %v2520 = load i64, ptr %slot389, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2519, i64 %v2520) nomerge, !dbg !134
  br label %bb_rcslotdone569
bb_rcslotdone569:
  %v2521 = load i64, ptr %slot17, align 8
  store i64 %v2521, ptr %slot394, align 8
  %v2522 = load i64, ptr %slot18, align 8
  store i64 %v2522, ptr %slot395, align 8
  %v2523 = load i64, ptr %slot395, align 8
  %v2524 = load i64, ptr %slot394, align 8
  %p2525 = inttoptr i64 %v2523 to ptr
  %p2526 = inttoptr i64 %v2524 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2526, ptr %p2525, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2527 = load i64, ptr %slot13, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  store i32 2, ptr %p2528, align 4, !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot15, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %ld2531 = load i32, ptr %p2530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2531, ptr %slot396, align 8
  %v2532 = load i32, ptr %slot396, align 8
  %v2533 = load i64, ptr %slot13, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  store i32 %v2532, ptr %p2534, align 4, !alias.scope !3, !noalias !4
  %v2535 = load i64, ptr %slot14, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i32 0, ptr %p2536, align 4, !alias.scope !3, !noalias !4
  %v2537 = load i64, ptr %slot12, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i32 1, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot394, align 8
  %v2540 = load i64, ptr %slot31, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  store i64 %v2539, ptr %p2541, align 8, !alias.scope !3, !noalias !4
  br label %bb_i32
bb_rctryok549:
  %v2542 = load i64, ptr %slot34, align 8
  store i64 %v2542, ptr %slot397, align 8
  %v2543 = load i64, ptr %slot16, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  store i32 1, ptr %p2544, align 4, !alias.scope !3, !noalias !4
  %v2545 = load i64, ptr %slot374, align 8
  %op2546 = add i64 %v2545, 8
  store i64 %op2546, ptr %slot398, align 8
  %v2547 = load i64, ptr %slot42, align 8
  store i64 %v2547, ptr %slot399, align 8
  store i64 0, ptr %slot400, align 8
  store i64 0, ptr %slot401, align 8
  %v2548 = load i64, ptr %slot401, align 8
  %v2549 = load i64, ptr %slot31, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  store i64 %v2548, ptr %p2550, align 8, !alias.scope !3, !noalias !4
  %v2551 = load i64, ptr %slot12, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %ld2553 = load i32, ptr %p2552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2553, ptr %slot402, align 8
  %v2554 = load i32, ptr %slot402, align 8
  %cv2555 = zext i32 %v2554 to i64
  %cond2556 = icmp ne i64 %cv2555, 0
  br i1 %cond2556, label %bb_rcslotdrop593, label %bb_rcslotdone593
bb_rcslotdrop593:
  %v2557 = load i64, ptr %slot12, align 8
  %p2558 = inttoptr i64 %v2557 to ptr
  store i32 0, ptr %p2558, align 4, !alias.scope !3, !noalias !4
  %v2559 = load i64, ptr %slot17, align 8
  store i64 %v2559, ptr %slot403, align 8
  %v2560 = load i64, ptr %slot13, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %ld2562 = load i32, ptr %p2561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2562, ptr %slot404, align 8
  %v2563 = load i32, ptr %slot404, align 8
  %op2564 = and i32 %v2563, 28
  store i32 %op2564, ptr %slot405, align 8
  %v2565 = load i32, ptr %slot405, align 8
  %cv2566 = zext i32 %v2565 to i64
  %cond2567 = icmp ne i64 %cv2566, 0
  br i1 %cond2567, label %bb_rcslotrole593, label %bb_rcslotowner593
bb_rcslotrole593:
  %v2568 = load i64, ptr %slot41, align 8
  store i64 %v2568, ptr %slot406, align 8
  %v2569 = load i64, ptr %slot406, align 8
  %v2570 = load i64, ptr %slot403, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2569, i64 %v2570) nomerge, !dbg !134
  br label %bb_rcslotdone593
bb_rcslotowner593:
  %v2571 = load i64, ptr %slot41, align 8
  store i64 %v2571, ptr %slot407, align 8
  %v2572 = load i64, ptr %slot407, align 8
  %v2573 = load i64, ptr %slot403, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2572, i64 %v2573) nomerge, !dbg !134
  br label %bb_rcslotdone593
bb_rcslotdone593:
  br label %bb_i33
bb_i32:
  %v2574 = load i64, ptr %slot31, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  %ld2576 = load i64, ptr %p2575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2576, ptr %slot408, align 8
  %v2577 = load i64, ptr %slot31, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %ld2579 = load i64, ptr %p2578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2579, ptr %slot409, align 8
  %v2580 = load i64, ptr %slot12, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  %ld2582 = load i32, ptr %p2581, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2582, ptr %slot410, align 8
  %v2583 = load i64, ptr %slot13, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  %ld2585 = load i32, ptr %p2584, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2585, ptr %slot411, align 8
  %v2586 = load i32, ptr %slot411, align 8
  %op2587 = and i32 %v2586, 24
  store i32 %op2587, ptr %slot411, align 8
  %v2588 = load i32, ptr %slot411, align 8
  %cmp2589 = icmp eq i32 %v2588, 0
  %cv2590 = zext i1 %cmp2589 to i32
  store i32 %cv2590, ptr %slot412, align 8
  %v2591 = load i32, ptr %slot410, align 8
  %v2592 = load i32, ptr %slot412, align 8
  %op2593 = and i32 %v2591, %v2592
  store i32 %op2593, ptr %slot413, align 8
  %v2594 = load i32, ptr %slot413, align 8
  %cv2595 = zext i32 %v2594 to i64
  %cond2596 = icmp ne i64 %cv2595, 0
  br i1 %cond2596, label %bb_rctake602, label %bb_rccopy602
bb_rctake602:
  %v2597 = load i64, ptr %slot18, align 8
  store i64 %v2597, ptr %slot414, align 8
  %v2598 = load i64, ptr %slot42, align 8
  store i64 %v2598, ptr %slot415, align 8
  %v2599 = load i64, ptr %slot41, align 8
  %v2600 = load i64, ptr %slot414, align 8
  %v2601 = load i64, ptr %slot409, align 8
  %v2602 = load i64, ptr %slot415, align 8
  %cv2603 = trunc i64 %v2602 to i32
  %call2604 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v2599, i64 %v2600, i64 %v2601, i32 %cv2603) nomerge, !dbg !136
  store i32 %call2604, ptr %slot416, align 8
  %v2605 = load i32, ptr %slot416, align 8
  %cv2606 = zext i32 %v2605 to i64
  %cond2607 = icmp ne i64 %cv2606, 0
  br i1 %cond2607, label %bb_rcsuccess612, label %bb_rcfailure612
bb_rcfailure612:
  %v2608 = load i64, ptr %slot41, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  %call2610 = call i32 @myl_rc_take_failure(ptr %p2609) nomerge, !dbg !136
  store i32 %call2610, ptr %slot417, align 8
  %v2611 = load i64, ptr %slot1, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %v2613 = load i32, ptr %slot417, align 8
  %call2614 = call i32 @myl_qbe_rc_status(ptr %p2612, i32 %v2613) nomerge, !dbg !136
  store i32 %call2614, ptr %slot418, align 8
  br label %bb_failure
bb_rcsuccess612:
  %v2615 = load i64, ptr %slot12, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  store i32 0, ptr %p2616, align 4, !alias.scope !3, !noalias !4
  %v2617 = load i64, ptr %slot15, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  store i32 2, ptr %p2618, align 4, !alias.scope !3, !noalias !4
  %v2619 = load i64, ptr %slot14, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  store i32 1, ptr %p2620, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared602
bb_rccopy602:
  %v2621 = load i64, ptr %slot18, align 8
  store i64 %v2621, ptr %slot419, align 8
  %v2622 = load i64, ptr %slot42, align 8
  store i64 %v2622, ptr %slot420, align 8
  %v2623 = load i64, ptr %slot41, align 8
  %v2624 = load i64, ptr %slot419, align 8
  %v2625 = load i64, ptr %slot409, align 8
  %v2626 = load i64, ptr %slot420, align 8
  %cv2627 = trunc i64 %v2626 to i32
  %call2628 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64 %v2623, i64 %v2624, i64 %v2625, i32 %cv2627) nomerge, !dbg !136
  store i32 %call2628, ptr %slot421, align 8
  %v2629 = load i32, ptr %slot421, align 8
  %cv2630 = zext i32 %v2629 to i64
  %cond2631 = icmp ne i64 %cv2630, 0
  br i1 %cond2631, label %bb_rcsuccess621, label %bb_rcfailure621
bb_rcfailure621:
  %v2632 = load i64, ptr %slot41, align 8
  %p2633 = inttoptr i64 %v2632 to ptr
  %call2634 = call i32 @myl_rc_take_failure(ptr %p2633) nomerge, !dbg !136
  store i32 %call2634, ptr %slot422, align 8
  %v2635 = load i64, ptr %slot1, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  %v2637 = load i32, ptr %slot422, align 8
  %call2638 = call i32 @myl_qbe_rc_status(ptr %p2636, i32 %v2637) nomerge, !dbg !136
  store i32 %call2638, ptr %slot423, align 8
  br label %bb_failure
bb_rcsuccess621:
  %v2639 = load i64, ptr %slot15, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  store i32 2, ptr %p2640, align 4, !alias.scope !3, !noalias !4
  %v2641 = load i64, ptr %slot14, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  store i32 1, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  %v2643 = load i64, ptr %slot12, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  %ld2645 = load i32, ptr %p2644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2645, ptr %slot424, align 8
  %v2646 = load i32, ptr %slot424, align 8
  %cv2647 = zext i32 %v2646 to i64
  %cond2648 = icmp ne i64 %cv2647, 0
  br i1 %cond2648, label %bb_rcslotdrop628, label %bb_rcslotdone628
bb_rcslotdrop628:
  %v2649 = load i64, ptr %slot12, align 8
  %p2650 = inttoptr i64 %v2649 to ptr
  store i32 0, ptr %p2650, align 4, !alias.scope !3, !noalias !4
  %v2651 = load i64, ptr %slot17, align 8
  store i64 %v2651, ptr %slot425, align 8
  %v2652 = load i64, ptr %slot13, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  %ld2654 = load i32, ptr %p2653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2654, ptr %slot426, align 8
  %v2655 = load i32, ptr %slot426, align 8
  %op2656 = and i32 %v2655, 28
  store i32 %op2656, ptr %slot427, align 8
  %v2657 = load i32, ptr %slot427, align 8
  %cv2658 = zext i32 %v2657 to i64
  %cond2659 = icmp ne i64 %cv2658, 0
  br i1 %cond2659, label %bb_rcslotrole628, label %bb_rcslotowner628
bb_rcslotrole628:
  %v2660 = load i64, ptr %slot41, align 8
  store i64 %v2660, ptr %slot428, align 8
  %v2661 = load i64, ptr %slot428, align 8
  %v2662 = load i64, ptr %slot425, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2661, i64 %v2662) nomerge, !dbg !136
  br label %bb_rcslotdone628
bb_rcslotowner628:
  %v2663 = load i64, ptr %slot41, align 8
  store i64 %v2663, ptr %slot429, align 8
  %v2664 = load i64, ptr %slot429, align 8
  %v2665 = load i64, ptr %slot425, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2664, i64 %v2665) nomerge, !dbg !136
  br label %bb_rcslotdone628
bb_rcslotdone628:
  br label %bb_rcprepared602
bb_rcprepared602:
  %v2666 = load i64, ptr %slot18, align 8
  store i64 %v2666, ptr %slot430, align 8
  %v2667 = load i64, ptr %slot14, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  store i32 0, ptr %p2668, align 4, !alias.scope !3, !noalias !4
  %v2669 = load i64, ptr %slot12, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  %ld2671 = load i32, ptr %p2670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2671, ptr %slot431, align 8
  %v2672 = load i32, ptr %slot431, align 8
  %cv2673 = zext i32 %v2672 to i64
  %cond2674 = icmp ne i64 %cv2673, 0
  br i1 %cond2674, label %bb_rcslotdrop639, label %bb_rcslotdone639
bb_rcslotdrop639:
  %v2675 = load i64, ptr %slot12, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  store i32 0, ptr %p2676, align 4, !alias.scope !3, !noalias !4
  %v2677 = load i64, ptr %slot17, align 8
  store i64 %v2677, ptr %slot432, align 8
  %v2678 = load i64, ptr %slot13, align 8
  %p2679 = inttoptr i64 %v2678 to ptr
  %ld2680 = load i32, ptr %p2679, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2680, ptr %slot433, align 8
  %v2681 = load i32, ptr %slot433, align 8
  %op2682 = and i32 %v2681, 28
  store i32 %op2682, ptr %slot434, align 8
  %v2683 = load i32, ptr %slot434, align 8
  %cv2684 = zext i32 %v2683 to i64
  %cond2685 = icmp ne i64 %cv2684, 0
  br i1 %cond2685, label %bb_rcslotrole639, label %bb_rcslotowner639
bb_rcslotrole639:
  %v2686 = load i64, ptr %slot41, align 8
  store i64 %v2686, ptr %slot435, align 8
  %v2687 = load i64, ptr %slot435, align 8
  %v2688 = load i64, ptr %slot432, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2687, i64 %v2688) nomerge, !dbg !136
  br label %bb_rcslotdone639
bb_rcslotowner639:
  %v2689 = load i64, ptr %slot41, align 8
  store i64 %v2689, ptr %slot436, align 8
  %v2690 = load i64, ptr %slot436, align 8
  %v2691 = load i64, ptr %slot432, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2690, i64 %v2691) nomerge, !dbg !136
  br label %bb_rcslotdone639
bb_rcslotdone639:
  %v2692 = load i64, ptr %slot10, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  %ld2694 = load i32, ptr %p2693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2694, ptr %slot437, align 8
  %v2695 = load i32, ptr %slot437, align 8
  %cv2696 = zext i32 %v2695 to i64
  %cond2697 = icmp ne i64 %cv2696, 0
  br i1 %cond2697, label %bb_rcslotdrop648, label %bb_rcslotdone648
bb_rcslotdrop648:
  %v2698 = load i64, ptr %slot10, align 8
  %p2699 = inttoptr i64 %v2698 to ptr
  store i32 0, ptr %p2699, align 4, !alias.scope !3, !noalias !4
  %v2700 = load i64, ptr %slot29, align 8
  store i64 %v2700, ptr %slot438, align 8
  %v2701 = load i64, ptr %slot11, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  %ld2703 = load i32, ptr %p2702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2703, ptr %slot439, align 8
  %v2704 = load i32, ptr %slot439, align 8
  %op2705 = and i32 %v2704, 28
  store i32 %op2705, ptr %slot440, align 8
  %v2706 = load i32, ptr %slot440, align 8
  %cv2707 = zext i32 %v2706 to i64
  %cond2708 = icmp ne i64 %cv2707, 0
  br i1 %cond2708, label %bb_rcslotrole648, label %bb_rcslotowner648
bb_rcslotrole648:
  %v2709 = load i64, ptr %slot41, align 8
  store i64 %v2709, ptr %slot441, align 8
  %v2710 = load i64, ptr %slot441, align 8
  %v2711 = load i64, ptr %slot438, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v2710, i64 %v2711) nomerge, !dbg !136
  br label %bb_rcslotdone648
bb_rcslotowner648:
  %v2712 = load i64, ptr %slot41, align 8
  store i64 %v2712, ptr %slot442, align 8
  %v2713 = load i64, ptr %slot442, align 8
  %v2714 = load i64, ptr %slot438, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v2713, i64 %v2714) nomerge, !dbg !136
  br label %bb_rcslotdone648
bb_rcslotdone648:
  %v2715 = load i64, ptr %slot8, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  %ld2717 = load i32, ptr %p2716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2717, ptr %slot443, align 8
  %v2718 = load i32, ptr %slot443, align 8
  %cv2719 = zext i32 %v2718 to i64
  %cond2720 = icmp ne i64 %cv2719, 0
  br i1 %cond2720, label %bb_rcslotdrop657, label %bb_rcslotdone657
bb_rcslotdrop657:
  %v2721 = load i64, ptr %slot8, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  store i32 0, ptr %p2722, align 4, !alias.scope !3, !noalias !4
  %v2723 = load i64, ptr %slot28, align 8
  store i64 %v2723, ptr %slot444, align 8
  %v2724 = load i64, ptr %slot9, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  %ld2726 = load i32, ptr %p2725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2726, ptr %slot445, align 8
  %v2727 = load i32, ptr %slot445, align 8
  %op2728 = and i32 %v2727, 28
  store i32 %op2728, ptr %slot446, align 8
  %v2729 = load i32, ptr %slot446, align 8
  %cv2730 = zext i32 %v2729 to i64
  %cond2731 = icmp ne i64 %cv2730, 0
  br i1 %cond2731, label %bb_rcslotrole657, label %bb_rcslotowner657
bb_rcslotrole657:
  %v2732 = load i64, ptr %slot41, align 8
  store i64 %v2732, ptr %slot447, align 8
  %v2733 = load i64, ptr %slot447, align 8
  %v2734 = load i64, ptr %slot444, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v2733, i64 %v2734) nomerge, !dbg !136
  br label %bb_rcslotdone657
bb_rcslotowner657:
  %v2735 = load i64, ptr %slot41, align 8
  store i64 %v2735, ptr %slot448, align 8
  %v2736 = load i64, ptr %slot448, align 8
  %v2737 = load i64, ptr %slot444, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v2736, i64 %v2737) nomerge, !dbg !136
  br label %bb_rcslotdone657
bb_rcslotdone657:
  %v2738 = load i64, ptr %slot6, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %ld2740 = load i32, ptr %p2739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2740, ptr %slot449, align 8
  %v2741 = load i32, ptr %slot449, align 8
  %cv2742 = zext i32 %v2741 to i64
  %cond2743 = icmp ne i64 %cv2742, 0
  br i1 %cond2743, label %bb_rcslotdrop666, label %bb_rcslotdone666
bb_rcslotdrop666:
  %v2744 = load i64, ptr %slot6, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  store i32 0, ptr %p2745, align 4, !alias.scope !3, !noalias !4
  %v2746 = load i64, ptr %slot23, align 8
  store i64 %v2746, ptr %slot450, align 8
  %v2747 = load i64, ptr %slot7, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  %ld2749 = load i32, ptr %p2748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2749, ptr %slot451, align 8
  %v2750 = load i32, ptr %slot451, align 8
  %op2751 = and i32 %v2750, 28
  store i32 %op2751, ptr %slot452, align 8
  %v2752 = load i32, ptr %slot452, align 8
  %cv2753 = zext i32 %v2752 to i64
  %cond2754 = icmp ne i64 %cv2753, 0
  br i1 %cond2754, label %bb_rcslotrole666, label %bb_rcslotowner666
bb_rcslotrole666:
  %v2755 = load i64, ptr %slot41, align 8
  store i64 %v2755, ptr %slot453, align 8
  %v2756 = load i64, ptr %slot453, align 8
  %v2757 = load i64, ptr %slot450, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v2756, i64 %v2757) nomerge, !dbg !136
  br label %bb_rcslotdone666
bb_rcslotowner666:
  %v2758 = load i64, ptr %slot41, align 8
  store i64 %v2758, ptr %slot454, align 8
  %v2759 = load i64, ptr %slot454, align 8
  %v2760 = load i64, ptr %slot450, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v2759, i64 %v2760) nomerge, !dbg !136
  br label %bb_rcslotdone666
bb_rcslotdone666:
  %v2761 = load i64, ptr %slot430, align 8
  %p2762 = inttoptr i64 %v2761 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2762, i64 24, i1 false)
  ret void
bb_i33:
  br label %bb_i63
bb_i35:
  %v2763 = load i64, ptr %slot19, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %ld2765 = load i64, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2765, ptr %slot455, align 8
  %v2766 = load i64, ptr %slot455, align 8
  %v2767 = load i64, ptr %slot31, align 8
  %p2768 = inttoptr i64 %v2767 to ptr
  store i64 %v2766, ptr %p2768, align 8, !alias.scope !3, !noalias !4
  %v2769 = load i64, ptr %slot24, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  %ld2771 = load i64, ptr %p2770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2771, ptr %slot456, align 8
  %v2772 = load i64, ptr %slot456, align 8
  %v2773 = load i64, ptr %slot32, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i64 %v2772, ptr %p2774, align 8, !alias.scope !3, !noalias !4
  %v2775 = load i64, ptr %slot31, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  %ld2777 = load i64, ptr %p2776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2777, ptr %slot457, align 8
  %v2778 = load i64, ptr %slot32, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  %ld2780 = load i64, ptr %p2779, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2780, ptr %slot458, align 8
  %v2781 = load i64, ptr %slot1, align 8
  %v2782 = load i64, ptr %slot457, align 8
  %v2783 = load i64, ptr %slot458, align 8
  call void @myl_f_f98310dc433a6ffc4936ce128753c578f0bd1637e181fedcb5c9b547efaf94b4(ptr sret([24 x i8]) align 8 %callresult460, i64 %v2781, i64 %v2782, i64 %v2783) nomerge, !dbg !138
  %addr2784 = ptrtoint ptr %callresult460 to i64
  store i64 %addr2784, ptr %slot459, align 8
  %v2785 = load i64, ptr %slot459, align 8
  %v2786 = load i64, ptr %slot31, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  store i64 %v2785, ptr %p2787, align 8, !alias.scope !3, !noalias !4
  %v2788 = load i64, ptr %slot31, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  %ld2790 = load i64, ptr %p2789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2790, ptr %slot461, align 8
  %v2791 = load i64, ptr %slot18, align 8
  store i64 %v2791, ptr %slot462, align 8
  %v2792 = load i64, ptr %slot461, align 8
  %v2793 = load i64, ptr %slot462, align 8
  %p2794 = inttoptr i64 %v2792 to ptr
  %p2795 = inttoptr i64 %v2793 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2795, ptr %p2794, i64 24, i1 false)
  %v2796 = load i64, ptr %slot15, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  store i32 2, ptr %p2797, align 4, !alias.scope !3, !noalias !4
  %v2798 = load i64, ptr %slot14, align 8
  %p2799 = inttoptr i64 %v2798 to ptr
  store i32 1, ptr %p2799, align 4, !alias.scope !3, !noalias !4
  %v2800 = load i64, ptr %slot12, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i32, ptr %p2801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2802, ptr %slot463, align 8
  %v2803 = load i32, ptr %slot463, align 8
  %cv2804 = zext i32 %v2803 to i64
  %cond2805 = icmp ne i64 %cv2804, 0
  br i1 %cond2805, label %bb_rcslotdrop730, label %bb_rcslotdone730
bb_rcslotdrop730:
  %v2806 = load i64, ptr %slot12, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i32 0, ptr %p2807, align 4, !alias.scope !3, !noalias !4
  %v2808 = load i64, ptr %slot17, align 8
  store i64 %v2808, ptr %slot464, align 8
  %v2809 = load i64, ptr %slot13, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  %ld2811 = load i32, ptr %p2810, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2811, ptr %slot465, align 8
  %v2812 = load i32, ptr %slot465, align 8
  %op2813 = and i32 %v2812, 28
  store i32 %op2813, ptr %slot466, align 8
  %v2814 = load i32, ptr %slot466, align 8
  %cv2815 = zext i32 %v2814 to i64
  %cond2816 = icmp ne i64 %cv2815, 0
  br i1 %cond2816, label %bb_rcslotrole730, label %bb_rcslotowner730
bb_rcslotrole730:
  %v2817 = load i64, ptr %slot41, align 8
  store i64 %v2817, ptr %slot467, align 8
  %v2818 = load i64, ptr %slot467, align 8
  %v2819 = load i64, ptr %slot464, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2818, i64 %v2819) nomerge, !dbg !138
  br label %bb_rcslotdone730
bb_rcslotowner730:
  %v2820 = load i64, ptr %slot41, align 8
  store i64 %v2820, ptr %slot468, align 8
  %v2821 = load i64, ptr %slot468, align 8
  %v2822 = load i64, ptr %slot464, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2821, i64 %v2822) nomerge, !dbg !138
  br label %bb_rcslotdone730
bb_rcslotdone730:
  %v2823 = load i64, ptr %slot17, align 8
  store i64 %v2823, ptr %slot469, align 8
  %v2824 = load i64, ptr %slot18, align 8
  store i64 %v2824, ptr %slot470, align 8
  %v2825 = load i64, ptr %slot470, align 8
  %v2826 = load i64, ptr %slot469, align 8
  %p2827 = inttoptr i64 %v2825 to ptr
  %p2828 = inttoptr i64 %v2826 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2828, ptr %p2827, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2829 = load i64, ptr %slot13, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  store i32 2, ptr %p2830, align 4, !alias.scope !3, !noalias !4
  %v2831 = load i64, ptr %slot15, align 8
  %p2832 = inttoptr i64 %v2831 to ptr
  %ld2833 = load i32, ptr %p2832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2833, ptr %slot471, align 8
  %v2834 = load i32, ptr %slot471, align 8
  %v2835 = load i64, ptr %slot13, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  store i32 %v2834, ptr %p2836, align 4, !alias.scope !3, !noalias !4
  %v2837 = load i64, ptr %slot14, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  store i32 0, ptr %p2838, align 4, !alias.scope !3, !noalias !4
  %v2839 = load i64, ptr %slot12, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  store i32 1, ptr %p2840, align 4, !alias.scope !3, !noalias !4
  %v2841 = load i64, ptr %slot469, align 8
  %v2842 = load i64, ptr %slot31, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  store i64 %v2841, ptr %p2843, align 8, !alias.scope !3, !noalias !4
  %v2844 = load i64, ptr %slot31, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  %ld2846 = load i64, ptr %p2845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2846, ptr %slot472, align 8
  %v2847 = load i64, ptr %slot472, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %ld2849 = load i32, ptr %p2848, align 4, !alias.scope !3, !noalias !4
  %ext2850 = zext i32 %ld2849 to i64
  store i64 %ext2850, ptr %slot473, align 8
  %v2851 = load i64, ptr %slot473, align 8
  %cmp2852 = icmp eq i64 %v2851, 1
  %cv2853 = zext i1 %cmp2852 to i64
  store i64 %cv2853, ptr %slot474, align 8
  %v2854 = load i64, ptr %slot474, align 8
  %cond2855 = icmp ne i64 %v2854, 0
  br i1 %cond2855, label %bb_errtrace747, label %bb_errtraced747
bb_errtrace747:
  %p2856 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2856, i64 8589934630) "call-inline-cost"="0", !dbg !140
  br label %bb_errtraced747
bb_errtraced747:
  %v2857 = load i64, ptr %slot31, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  %ld2859 = load i64, ptr %p2858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2859, ptr %slot475, align 8
  %v2860 = load i64, ptr %slot18, align 8
  store i64 %v2860, ptr %slot476, align 8
  %v2861 = load i64, ptr %slot42, align 8
  store i64 %v2861, ptr %slot477, align 8
  %v2862 = load i64, ptr %slot41, align 8
  %v2863 = load i64, ptr %slot476, align 8
  %v2864 = load i64, ptr %slot475, align 8
  %v2865 = load i64, ptr %slot477, align 8
  %cv2866 = trunc i64 %v2865 to i32
  %call2867 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v2862, i64 %v2863, i64 %v2864, i32 %cv2866) nomerge, !dbg !140
  store i32 %call2867, ptr %slot478, align 8
  %v2868 = load i32, ptr %slot478, align 8
  %cv2869 = zext i32 %v2868 to i64
  %cond2870 = icmp ne i64 %cv2869, 0
  br i1 %cond2870, label %bb_rcsuccess752, label %bb_rcfailure752
bb_rcfailure752:
  %v2871 = load i64, ptr %slot41, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  %call2873 = call i32 @myl_rc_take_failure(ptr %p2872) nomerge, !dbg !140
  store i32 %call2873, ptr %slot479, align 8
  %v2874 = load i64, ptr %slot1, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  %v2876 = load i32, ptr %slot479, align 8
  %call2877 = call i32 @myl_qbe_rc_status(ptr %p2875, i32 %v2876) nomerge, !dbg !140
  store i32 %call2877, ptr %slot480, align 8
  br label %bb_failure
bb_rcsuccess752:
  %v2878 = load i64, ptr %slot12, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  store i32 0, ptr %p2879, align 4, !alias.scope !3, !noalias !4
  %v2880 = load i64, ptr %slot15, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  store i32 2, ptr %p2881, align 4, !alias.scope !3, !noalias !4
  %v2882 = load i64, ptr %slot14, align 8
  %p2883 = inttoptr i64 %v2882 to ptr
  store i32 1, ptr %p2883, align 4, !alias.scope !3, !noalias !4
  %v2884 = load i64, ptr %slot18, align 8
  store i64 %v2884, ptr %slot481, align 8
  %v2885 = load i64, ptr %slot14, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  store i32 0, ptr %p2886, align 4, !alias.scope !3, !noalias !4
  %v2887 = load i64, ptr %slot12, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  %ld2889 = load i32, ptr %p2888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2889, ptr %slot482, align 8
  %v2890 = load i32, ptr %slot482, align 8
  %cv2891 = zext i32 %v2890 to i64
  %cond2892 = icmp ne i64 %cv2891, 0
  br i1 %cond2892, label %bb_rcslotdrop762, label %bb_rcslotdone762
bb_rcslotdrop762:
  %v2893 = load i64, ptr %slot12, align 8
  %p2894 = inttoptr i64 %v2893 to ptr
  store i32 0, ptr %p2894, align 4, !alias.scope !3, !noalias !4
  %v2895 = load i64, ptr %slot17, align 8
  store i64 %v2895, ptr %slot483, align 8
  %v2896 = load i64, ptr %slot13, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  %ld2898 = load i32, ptr %p2897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2898, ptr %slot484, align 8
  %v2899 = load i32, ptr %slot484, align 8
  %op2900 = and i32 %v2899, 28
  store i32 %op2900, ptr %slot485, align 8
  %v2901 = load i32, ptr %slot485, align 8
  %cv2902 = zext i32 %v2901 to i64
  %cond2903 = icmp ne i64 %cv2902, 0
  br i1 %cond2903, label %bb_rcslotrole762, label %bb_rcslotowner762
bb_rcslotrole762:
  %v2904 = load i64, ptr %slot41, align 8
  store i64 %v2904, ptr %slot486, align 8
  %v2905 = load i64, ptr %slot486, align 8
  %v2906 = load i64, ptr %slot483, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2905, i64 %v2906) nomerge, !dbg !140
  br label %bb_rcslotdone762
bb_rcslotowner762:
  %v2907 = load i64, ptr %slot41, align 8
  store i64 %v2907, ptr %slot487, align 8
  %v2908 = load i64, ptr %slot487, align 8
  %v2909 = load i64, ptr %slot483, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2908, i64 %v2909) nomerge, !dbg !140
  br label %bb_rcslotdone762
bb_rcslotdone762:
  %v2910 = load i64, ptr %slot10, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  %ld2912 = load i32, ptr %p2911, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2912, ptr %slot488, align 8
  %v2913 = load i32, ptr %slot488, align 8
  %cv2914 = zext i32 %v2913 to i64
  %cond2915 = icmp ne i64 %cv2914, 0
  br i1 %cond2915, label %bb_rcslotdrop771, label %bb_rcslotdone771
bb_rcslotdrop771:
  %v2916 = load i64, ptr %slot10, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  store i32 0, ptr %p2917, align 4, !alias.scope !3, !noalias !4
  %v2918 = load i64, ptr %slot29, align 8
  store i64 %v2918, ptr %slot489, align 8
  %v2919 = load i64, ptr %slot11, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  %ld2921 = load i32, ptr %p2920, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2921, ptr %slot490, align 8
  %v2922 = load i32, ptr %slot490, align 8
  %op2923 = and i32 %v2922, 28
  store i32 %op2923, ptr %slot491, align 8
  %v2924 = load i32, ptr %slot491, align 8
  %cv2925 = zext i32 %v2924 to i64
  %cond2926 = icmp ne i64 %cv2925, 0
  br i1 %cond2926, label %bb_rcslotrole771, label %bb_rcslotowner771
bb_rcslotrole771:
  %v2927 = load i64, ptr %slot41, align 8
  store i64 %v2927, ptr %slot492, align 8
  %v2928 = load i64, ptr %slot492, align 8
  %v2929 = load i64, ptr %slot489, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v2928, i64 %v2929) nomerge, !dbg !140
  br label %bb_rcslotdone771
bb_rcslotowner771:
  %v2930 = load i64, ptr %slot41, align 8
  store i64 %v2930, ptr %slot493, align 8
  %v2931 = load i64, ptr %slot493, align 8
  %v2932 = load i64, ptr %slot489, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v2931, i64 %v2932) nomerge, !dbg !140
  br label %bb_rcslotdone771
bb_rcslotdone771:
  %v2933 = load i64, ptr %slot8, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  %ld2935 = load i32, ptr %p2934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2935, ptr %slot494, align 8
  %v2936 = load i32, ptr %slot494, align 8
  %cv2937 = zext i32 %v2936 to i64
  %cond2938 = icmp ne i64 %cv2937, 0
  br i1 %cond2938, label %bb_rcslotdrop780, label %bb_rcslotdone780
bb_rcslotdrop780:
  %v2939 = load i64, ptr %slot8, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  store i32 0, ptr %p2940, align 4, !alias.scope !3, !noalias !4
  %v2941 = load i64, ptr %slot28, align 8
  store i64 %v2941, ptr %slot495, align 8
  %v2942 = load i64, ptr %slot9, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  %ld2944 = load i32, ptr %p2943, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2944, ptr %slot496, align 8
  %v2945 = load i32, ptr %slot496, align 8
  %op2946 = and i32 %v2945, 28
  store i32 %op2946, ptr %slot497, align 8
  %v2947 = load i32, ptr %slot497, align 8
  %cv2948 = zext i32 %v2947 to i64
  %cond2949 = icmp ne i64 %cv2948, 0
  br i1 %cond2949, label %bb_rcslotrole780, label %bb_rcslotowner780
bb_rcslotrole780:
  %v2950 = load i64, ptr %slot41, align 8
  store i64 %v2950, ptr %slot498, align 8
  %v2951 = load i64, ptr %slot498, align 8
  %v2952 = load i64, ptr %slot495, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v2951, i64 %v2952) nomerge, !dbg !140
  br label %bb_rcslotdone780
bb_rcslotowner780:
  %v2953 = load i64, ptr %slot41, align 8
  store i64 %v2953, ptr %slot499, align 8
  %v2954 = load i64, ptr %slot499, align 8
  %v2955 = load i64, ptr %slot495, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v2954, i64 %v2955) nomerge, !dbg !140
  br label %bb_rcslotdone780
bb_rcslotdone780:
  %v2956 = load i64, ptr %slot6, align 8
  %p2957 = inttoptr i64 %v2956 to ptr
  %ld2958 = load i32, ptr %p2957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2958, ptr %slot500, align 8
  %v2959 = load i32, ptr %slot500, align 8
  %cv2960 = zext i32 %v2959 to i64
  %cond2961 = icmp ne i64 %cv2960, 0
  br i1 %cond2961, label %bb_rcslotdrop789, label %bb_rcslotdone789
bb_rcslotdrop789:
  %v2962 = load i64, ptr %slot6, align 8
  %p2963 = inttoptr i64 %v2962 to ptr
  store i32 0, ptr %p2963, align 4, !alias.scope !3, !noalias !4
  %v2964 = load i64, ptr %slot23, align 8
  store i64 %v2964, ptr %slot501, align 8
  %v2965 = load i64, ptr %slot7, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  %ld2967 = load i32, ptr %p2966, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2967, ptr %slot502, align 8
  %v2968 = load i32, ptr %slot502, align 8
  %op2969 = and i32 %v2968, 28
  store i32 %op2969, ptr %slot503, align 8
  %v2970 = load i32, ptr %slot503, align 8
  %cv2971 = zext i32 %v2970 to i64
  %cond2972 = icmp ne i64 %cv2971, 0
  br i1 %cond2972, label %bb_rcslotrole789, label %bb_rcslotowner789
bb_rcslotrole789:
  %v2973 = load i64, ptr %slot41, align 8
  store i64 %v2973, ptr %slot504, align 8
  %v2974 = load i64, ptr %slot504, align 8
  %v2975 = load i64, ptr %slot501, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v2974, i64 %v2975) nomerge, !dbg !140
  br label %bb_rcslotdone789
bb_rcslotowner789:
  %v2976 = load i64, ptr %slot41, align 8
  store i64 %v2976, ptr %slot505, align 8
  %v2977 = load i64, ptr %slot505, align 8
  %v2978 = load i64, ptr %slot501, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v2977, i64 %v2978) nomerge, !dbg !140
  br label %bb_rcslotdone789
bb_rcslotdone789:
  %v2979 = load i64, ptr %slot481, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2980, i64 24, i1 false)
  ret void
bb_i39:
  %v2981 = load i64, ptr %slot19, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  %ld2983 = load i64, ptr %p2982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2983, ptr %slot506, align 8
  %v2984 = load i64, ptr %slot506, align 8
  %v2985 = load i64, ptr %slot31, align 8
  %p2986 = inttoptr i64 %v2985 to ptr
  store i64 %v2984, ptr %p2986, align 8, !alias.scope !3, !noalias !4
  %v2987 = load i64, ptr %slot25, align 8
  %p2988 = inttoptr i64 %v2987 to ptr
  %ld2989 = load i64, ptr %p2988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2989, ptr %slot507, align 8
  %v2990 = load i64, ptr %slot507, align 8
  %v2991 = load i64, ptr %slot32, align 8
  %p2992 = inttoptr i64 %v2991 to ptr
  store i64 %v2990, ptr %p2992, align 8, !alias.scope !3, !noalias !4
  %v2993 = load i64, ptr %slot31, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  %ld2995 = load i64, ptr %p2994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2995, ptr %slot508, align 8
  %v2996 = load i64, ptr %slot32, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  %ld2998 = load i64, ptr %p2997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2998, ptr %slot509, align 8
  %v2999 = load i64, ptr %slot1, align 8
  %v3000 = load i64, ptr %slot508, align 8
  %v3001 = load i64, ptr %slot509, align 8
  call void @myl_f_9071aa69d62fb1d23e062dda66ed7f74ea3cd6b716225aca159e2b66890e85fc(ptr sret([24 x i8]) align 8 %callresult511, i64 %v2999, i64 %v3000, i64 %v3001) nomerge, !dbg !142
  %addr3002 = ptrtoint ptr %callresult511 to i64
  store i64 %addr3002, ptr %slot510, align 8
  %v3003 = load i64, ptr %slot510, align 8
  %v3004 = load i64, ptr %slot31, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  store i64 %v3003, ptr %p3005, align 8, !alias.scope !3, !noalias !4
  %v3006 = load i64, ptr %slot31, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  %ld3008 = load i64, ptr %p3007, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3008, ptr %slot512, align 8
  %v3009 = load i64, ptr %slot18, align 8
  store i64 %v3009, ptr %slot513, align 8
  %v3010 = load i64, ptr %slot512, align 8
  %v3011 = load i64, ptr %slot513, align 8
  %p3012 = inttoptr i64 %v3010 to ptr
  %p3013 = inttoptr i64 %v3011 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3013, ptr %p3012, i64 24, i1 false)
  %v3014 = load i64, ptr %slot15, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  store i32 2, ptr %p3015, align 4, !alias.scope !3, !noalias !4
  %v3016 = load i64, ptr %slot14, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  store i32 1, ptr %p3017, align 4, !alias.scope !3, !noalias !4
  %v3018 = load i64, ptr %slot12, align 8
  %p3019 = inttoptr i64 %v3018 to ptr
  %ld3020 = load i32, ptr %p3019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3020, ptr %slot514, align 8
  %v3021 = load i32, ptr %slot514, align 8
  %cv3022 = zext i32 %v3021 to i64
  %cond3023 = icmp ne i64 %cv3022, 0
  br i1 %cond3023, label %bb_rcslotdrop853, label %bb_rcslotdone853
bb_rcslotdrop853:
  %v3024 = load i64, ptr %slot12, align 8
  %p3025 = inttoptr i64 %v3024 to ptr
  store i32 0, ptr %p3025, align 4, !alias.scope !3, !noalias !4
  %v3026 = load i64, ptr %slot17, align 8
  store i64 %v3026, ptr %slot515, align 8
  %v3027 = load i64, ptr %slot13, align 8
  %p3028 = inttoptr i64 %v3027 to ptr
  %ld3029 = load i32, ptr %p3028, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3029, ptr %slot516, align 8
  %v3030 = load i32, ptr %slot516, align 8
  %op3031 = and i32 %v3030, 28
  store i32 %op3031, ptr %slot517, align 8
  %v3032 = load i32, ptr %slot517, align 8
  %cv3033 = zext i32 %v3032 to i64
  %cond3034 = icmp ne i64 %cv3033, 0
  br i1 %cond3034, label %bb_rcslotrole853, label %bb_rcslotowner853
bb_rcslotrole853:
  %v3035 = load i64, ptr %slot41, align 8
  store i64 %v3035, ptr %slot518, align 8
  %v3036 = load i64, ptr %slot518, align 8
  %v3037 = load i64, ptr %slot515, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3036, i64 %v3037) nomerge, !dbg !142
  br label %bb_rcslotdone853
bb_rcslotowner853:
  %v3038 = load i64, ptr %slot41, align 8
  store i64 %v3038, ptr %slot519, align 8
  %v3039 = load i64, ptr %slot519, align 8
  %v3040 = load i64, ptr %slot515, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3039, i64 %v3040) nomerge, !dbg !142
  br label %bb_rcslotdone853
bb_rcslotdone853:
  %v3041 = load i64, ptr %slot17, align 8
  store i64 %v3041, ptr %slot520, align 8
  %v3042 = load i64, ptr %slot18, align 8
  store i64 %v3042, ptr %slot521, align 8
  %v3043 = load i64, ptr %slot521, align 8
  %v3044 = load i64, ptr %slot520, align 8
  %p3045 = inttoptr i64 %v3043 to ptr
  %p3046 = inttoptr i64 %v3044 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3046, ptr %p3045, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3047 = load i64, ptr %slot13, align 8
  %p3048 = inttoptr i64 %v3047 to ptr
  store i32 2, ptr %p3048, align 4, !alias.scope !3, !noalias !4
  %v3049 = load i64, ptr %slot15, align 8
  %p3050 = inttoptr i64 %v3049 to ptr
  %ld3051 = load i32, ptr %p3050, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3051, ptr %slot522, align 8
  %v3052 = load i32, ptr %slot522, align 8
  %v3053 = load i64, ptr %slot13, align 8
  %p3054 = inttoptr i64 %v3053 to ptr
  store i32 %v3052, ptr %p3054, align 4, !alias.scope !3, !noalias !4
  %v3055 = load i64, ptr %slot14, align 8
  %p3056 = inttoptr i64 %v3055 to ptr
  store i32 0, ptr %p3056, align 4, !alias.scope !3, !noalias !4
  %v3057 = load i64, ptr %slot12, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  store i32 1, ptr %p3058, align 4, !alias.scope !3, !noalias !4
  %v3059 = load i64, ptr %slot520, align 8
  %v3060 = load i64, ptr %slot31, align 8
  %p3061 = inttoptr i64 %v3060 to ptr
  store i64 %v3059, ptr %p3061, align 8, !alias.scope !3, !noalias !4
  %v3062 = load i64, ptr %slot31, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  %ld3064 = load i64, ptr %p3063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3064, ptr %slot523, align 8
  %v3065 = load i64, ptr %slot523, align 8
  %p3066 = inttoptr i64 %v3065 to ptr
  %ld3067 = load i32, ptr %p3066, align 4, !alias.scope !3, !noalias !4
  %ext3068 = zext i32 %ld3067 to i64
  store i64 %ext3068, ptr %slot524, align 8
  %v3069 = load i64, ptr %slot524, align 8
  %cmp3070 = icmp eq i64 %v3069, 1
  %cv3071 = zext i1 %cmp3070 to i64
  store i64 %cv3071, ptr %slot525, align 8
  %v3072 = load i64, ptr %slot525, align 8
  %cond3073 = icmp ne i64 %v3072, 0
  br i1 %cond3073, label %bb_errtrace870, label %bb_errtraced870
bb_errtrace870:
  %p3074 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3074, i64 8589934634) "call-inline-cost"="0", !dbg !144
  br label %bb_errtraced870
bb_errtraced870:
  %v3075 = load i64, ptr %slot31, align 8
  %p3076 = inttoptr i64 %v3075 to ptr
  %ld3077 = load i64, ptr %p3076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3077, ptr %slot526, align 8
  %v3078 = load i64, ptr %slot18, align 8
  store i64 %v3078, ptr %slot527, align 8
  %v3079 = load i64, ptr %slot42, align 8
  store i64 %v3079, ptr %slot528, align 8
  %v3080 = load i64, ptr %slot41, align 8
  %v3081 = load i64, ptr %slot527, align 8
  %v3082 = load i64, ptr %slot526, align 8
  %v3083 = load i64, ptr %slot528, align 8
  %cv3084 = trunc i64 %v3083 to i32
  %call3085 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v3080, i64 %v3081, i64 %v3082, i32 %cv3084) nomerge, !dbg !144
  store i32 %call3085, ptr %slot529, align 8
  %v3086 = load i32, ptr %slot529, align 8
  %cv3087 = zext i32 %v3086 to i64
  %cond3088 = icmp ne i64 %cv3087, 0
  br i1 %cond3088, label %bb_rcsuccess875, label %bb_rcfailure875
bb_rcfailure875:
  %v3089 = load i64, ptr %slot41, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %call3091 = call i32 @myl_rc_take_failure(ptr %p3090) nomerge, !dbg !144
  store i32 %call3091, ptr %slot530, align 8
  %v3092 = load i64, ptr %slot1, align 8
  %p3093 = inttoptr i64 %v3092 to ptr
  %v3094 = load i32, ptr %slot530, align 8
  %call3095 = call i32 @myl_qbe_rc_status(ptr %p3093, i32 %v3094) nomerge, !dbg !144
  store i32 %call3095, ptr %slot531, align 8
  br label %bb_failure
bb_rcsuccess875:
  %v3096 = load i64, ptr %slot12, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  store i32 0, ptr %p3097, align 4, !alias.scope !3, !noalias !4
  %v3098 = load i64, ptr %slot15, align 8
  %p3099 = inttoptr i64 %v3098 to ptr
  store i32 2, ptr %p3099, align 4, !alias.scope !3, !noalias !4
  %v3100 = load i64, ptr %slot14, align 8
  %p3101 = inttoptr i64 %v3100 to ptr
  store i32 1, ptr %p3101, align 4, !alias.scope !3, !noalias !4
  %v3102 = load i64, ptr %slot18, align 8
  store i64 %v3102, ptr %slot532, align 8
  %v3103 = load i64, ptr %slot14, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  store i32 0, ptr %p3104, align 4, !alias.scope !3, !noalias !4
  %v3105 = load i64, ptr %slot12, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  %ld3107 = load i32, ptr %p3106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3107, ptr %slot533, align 8
  %v3108 = load i32, ptr %slot533, align 8
  %cv3109 = zext i32 %v3108 to i64
  %cond3110 = icmp ne i64 %cv3109, 0
  br i1 %cond3110, label %bb_rcslotdrop885, label %bb_rcslotdone885
bb_rcslotdrop885:
  %v3111 = load i64, ptr %slot12, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  store i32 0, ptr %p3112, align 4, !alias.scope !3, !noalias !4
  %v3113 = load i64, ptr %slot17, align 8
  store i64 %v3113, ptr %slot534, align 8
  %v3114 = load i64, ptr %slot13, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  %ld3116 = load i32, ptr %p3115, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3116, ptr %slot535, align 8
  %v3117 = load i32, ptr %slot535, align 8
  %op3118 = and i32 %v3117, 28
  store i32 %op3118, ptr %slot536, align 8
  %v3119 = load i32, ptr %slot536, align 8
  %cv3120 = zext i32 %v3119 to i64
  %cond3121 = icmp ne i64 %cv3120, 0
  br i1 %cond3121, label %bb_rcslotrole885, label %bb_rcslotowner885
bb_rcslotrole885:
  %v3122 = load i64, ptr %slot41, align 8
  store i64 %v3122, ptr %slot537, align 8
  %v3123 = load i64, ptr %slot537, align 8
  %v3124 = load i64, ptr %slot534, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v3123, i64 %v3124) nomerge, !dbg !144
  br label %bb_rcslotdone885
bb_rcslotowner885:
  %v3125 = load i64, ptr %slot41, align 8
  store i64 %v3125, ptr %slot538, align 8
  %v3126 = load i64, ptr %slot538, align 8
  %v3127 = load i64, ptr %slot534, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v3126, i64 %v3127) nomerge, !dbg !144
  br label %bb_rcslotdone885
bb_rcslotdone885:
  %v3128 = load i64, ptr %slot10, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  %ld3130 = load i32, ptr %p3129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3130, ptr %slot539, align 8
  %v3131 = load i32, ptr %slot539, align 8
  %cv3132 = zext i32 %v3131 to i64
  %cond3133 = icmp ne i64 %cv3132, 0
  br i1 %cond3133, label %bb_rcslotdrop894, label %bb_rcslotdone894
bb_rcslotdrop894:
  %v3134 = load i64, ptr %slot10, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  store i32 0, ptr %p3135, align 4, !alias.scope !3, !noalias !4
  %v3136 = load i64, ptr %slot29, align 8
  store i64 %v3136, ptr %slot540, align 8
  %v3137 = load i64, ptr %slot11, align 8
  %p3138 = inttoptr i64 %v3137 to ptr
  %ld3139 = load i32, ptr %p3138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3139, ptr %slot541, align 8
  %v3140 = load i32, ptr %slot541, align 8
  %op3141 = and i32 %v3140, 28
  store i32 %op3141, ptr %slot542, align 8
  %v3142 = load i32, ptr %slot542, align 8
  %cv3143 = zext i32 %v3142 to i64
  %cond3144 = icmp ne i64 %cv3143, 0
  br i1 %cond3144, label %bb_rcslotrole894, label %bb_rcslotowner894
bb_rcslotrole894:
  %v3145 = load i64, ptr %slot41, align 8
  store i64 %v3145, ptr %slot543, align 8
  %v3146 = load i64, ptr %slot543, align 8
  %v3147 = load i64, ptr %slot540, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v3146, i64 %v3147) nomerge, !dbg !144
  br label %bb_rcslotdone894
bb_rcslotowner894:
  %v3148 = load i64, ptr %slot41, align 8
  store i64 %v3148, ptr %slot544, align 8
  %v3149 = load i64, ptr %slot544, align 8
  %v3150 = load i64, ptr %slot540, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v3149, i64 %v3150) nomerge, !dbg !144
  br label %bb_rcslotdone894
bb_rcslotdone894:
  %v3151 = load i64, ptr %slot8, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %ld3153 = load i32, ptr %p3152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3153, ptr %slot545, align 8
  %v3154 = load i32, ptr %slot545, align 8
  %cv3155 = zext i32 %v3154 to i64
  %cond3156 = icmp ne i64 %cv3155, 0
  br i1 %cond3156, label %bb_rcslotdrop903, label %bb_rcslotdone903
bb_rcslotdrop903:
  %v3157 = load i64, ptr %slot8, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  store i32 0, ptr %p3158, align 4, !alias.scope !3, !noalias !4
  %v3159 = load i64, ptr %slot28, align 8
  store i64 %v3159, ptr %slot546, align 8
  %v3160 = load i64, ptr %slot9, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  %ld3162 = load i32, ptr %p3161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3162, ptr %slot547, align 8
  %v3163 = load i32, ptr %slot547, align 8
  %op3164 = and i32 %v3163, 28
  store i32 %op3164, ptr %slot548, align 8
  %v3165 = load i32, ptr %slot548, align 8
  %cv3166 = zext i32 %v3165 to i64
  %cond3167 = icmp ne i64 %cv3166, 0
  br i1 %cond3167, label %bb_rcslotrole903, label %bb_rcslotowner903
bb_rcslotrole903:
  %v3168 = load i64, ptr %slot41, align 8
  store i64 %v3168, ptr %slot549, align 8
  %v3169 = load i64, ptr %slot549, align 8
  %v3170 = load i64, ptr %slot546, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v3169, i64 %v3170) nomerge, !dbg !144
  br label %bb_rcslotdone903
bb_rcslotowner903:
  %v3171 = load i64, ptr %slot41, align 8
  store i64 %v3171, ptr %slot550, align 8
  %v3172 = load i64, ptr %slot550, align 8
  %v3173 = load i64, ptr %slot546, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v3172, i64 %v3173) nomerge, !dbg !144
  br label %bb_rcslotdone903
bb_rcslotdone903:
  %v3174 = load i64, ptr %slot6, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  %ld3176 = load i32, ptr %p3175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3176, ptr %slot551, align 8
  %v3177 = load i32, ptr %slot551, align 8
  %cv3178 = zext i32 %v3177 to i64
  %cond3179 = icmp ne i64 %cv3178, 0
  br i1 %cond3179, label %bb_rcslotdrop912, label %bb_rcslotdone912
bb_rcslotdrop912:
  %v3180 = load i64, ptr %slot6, align 8
  %p3181 = inttoptr i64 %v3180 to ptr
  store i32 0, ptr %p3181, align 4, !alias.scope !3, !noalias !4
  %v3182 = load i64, ptr %slot23, align 8
  store i64 %v3182, ptr %slot552, align 8
  %v3183 = load i64, ptr %slot7, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  %ld3185 = load i32, ptr %p3184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3185, ptr %slot553, align 8
  %v3186 = load i32, ptr %slot553, align 8
  %op3187 = and i32 %v3186, 28
  store i32 %op3187, ptr %slot554, align 8
  %v3188 = load i32, ptr %slot554, align 8
  %cv3189 = zext i32 %v3188 to i64
  %cond3190 = icmp ne i64 %cv3189, 0
  br i1 %cond3190, label %bb_rcslotrole912, label %bb_rcslotowner912
bb_rcslotrole912:
  %v3191 = load i64, ptr %slot41, align 8
  store i64 %v3191, ptr %slot555, align 8
  %v3192 = load i64, ptr %slot555, align 8
  %v3193 = load i64, ptr %slot552, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v3192, i64 %v3193) nomerge, !dbg !144
  br label %bb_rcslotdone912
bb_rcslotowner912:
  %v3194 = load i64, ptr %slot41, align 8
  store i64 %v3194, ptr %slot556, align 8
  %v3195 = load i64, ptr %slot556, align 8
  %v3196 = load i64, ptr %slot552, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v3195, i64 %v3196) nomerge, !dbg !144
  br label %bb_rcslotdone912
bb_rcslotdone912:
  %v3197 = load i64, ptr %slot532, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3198, i64 24, i1 false)
  ret void
bb_i43:
  %v3199 = load i64, ptr %slot19, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  %ld3201 = load i64, ptr %p3200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3201, ptr %slot557, align 8
  %v3202 = load i64, ptr %slot557, align 8
  %v3203 = load i64, ptr %slot31, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  store i64 %v3202, ptr %p3204, align 8, !alias.scope !3, !noalias !4
  %v3205 = load i64, ptr %slot26, align 8
  %v3206 = load i64, ptr %slot32, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  store i64 %v3205, ptr %p3207, align 8, !alias.scope !3, !noalias !4
  %v3208 = load i64, ptr %slot31, align 8
  %p3209 = inttoptr i64 %v3208 to ptr
  %ld3210 = load i64, ptr %p3209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3210, ptr %slot558, align 8
  %v3211 = load i64, ptr %slot32, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %ld3213 = load i64, ptr %p3212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3213, ptr %slot559, align 8
  %v3214 = load i64, ptr %slot1, align 8
  %v3215 = load i64, ptr %slot558, align 8
  %v3216 = load i64, ptr %slot559, align 8
  call void @myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004(ptr sret([24 x i8]) align 8 %callresult561, i64 %v3214, i64 %v3215, i64 %v3216) nomerge, !dbg !146
  %addr3217 = ptrtoint ptr %callresult561 to i64
  store i64 %addr3217, ptr %slot560, align 8
  %v3218 = load i64, ptr %slot560, align 8
  %v3219 = load i64, ptr %slot31, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  store i64 %v3218, ptr %p3220, align 8, !alias.scope !3, !noalias !4
  %v3221 = load i64, ptr %slot31, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  %ld3223 = load i64, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3223, ptr %slot562, align 8
  %v3224 = load i64, ptr %slot18, align 8
  store i64 %v3224, ptr %slot563, align 8
  %v3225 = load i64, ptr %slot562, align 8
  %v3226 = load i64, ptr %slot563, align 8
  %p3227 = inttoptr i64 %v3225 to ptr
  %p3228 = inttoptr i64 %v3226 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3228, ptr %p3227, i64 24, i1 false)
  %v3229 = load i64, ptr %slot15, align 8
  %p3230 = inttoptr i64 %v3229 to ptr
  store i32 2, ptr %p3230, align 4, !alias.scope !3, !noalias !4
  %v3231 = load i64, ptr %slot14, align 8
  %p3232 = inttoptr i64 %v3231 to ptr
  store i32 1, ptr %p3232, align 4, !alias.scope !3, !noalias !4
  %v3233 = load i64, ptr %slot12, align 8
  %p3234 = inttoptr i64 %v3233 to ptr
  %ld3235 = load i32, ptr %p3234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3235, ptr %slot564, align 8
  %v3236 = load i32, ptr %slot564, align 8
  %cv3237 = zext i32 %v3236 to i64
  %cond3238 = icmp ne i64 %cv3237, 0
  br i1 %cond3238, label %bb_rcslotdrop975, label %bb_rcslotdone975
bb_rcslotdrop975:
  %v3239 = load i64, ptr %slot12, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  store i32 0, ptr %p3240, align 4, !alias.scope !3, !noalias !4
  %v3241 = load i64, ptr %slot17, align 8
  store i64 %v3241, ptr %slot565, align 8
  %v3242 = load i64, ptr %slot13, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  %ld3244 = load i32, ptr %p3243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3244, ptr %slot566, align 8
  %v3245 = load i32, ptr %slot566, align 8
  %op3246 = and i32 %v3245, 28
  store i32 %op3246, ptr %slot567, align 8
  %v3247 = load i32, ptr %slot567, align 8
  %cv3248 = zext i32 %v3247 to i64
  %cond3249 = icmp ne i64 %cv3248, 0
  br i1 %cond3249, label %bb_rcslotrole975, label %bb_rcslotowner975
bb_rcslotrole975:
  %v3250 = load i64, ptr %slot41, align 8
  store i64 %v3250, ptr %slot568, align 8
  %v3251 = load i64, ptr %slot568, align 8
  %v3252 = load i64, ptr %slot565, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3251, i64 %v3252) nomerge, !dbg !146
  br label %bb_rcslotdone975
bb_rcslotowner975:
  %v3253 = load i64, ptr %slot41, align 8
  store i64 %v3253, ptr %slot569, align 8
  %v3254 = load i64, ptr %slot569, align 8
  %v3255 = load i64, ptr %slot565, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3254, i64 %v3255) nomerge, !dbg !146
  br label %bb_rcslotdone975
bb_rcslotdone975:
  %v3256 = load i64, ptr %slot17, align 8
  store i64 %v3256, ptr %slot570, align 8
  %v3257 = load i64, ptr %slot18, align 8
  store i64 %v3257, ptr %slot571, align 8
  %v3258 = load i64, ptr %slot571, align 8
  %v3259 = load i64, ptr %slot570, align 8
  %p3260 = inttoptr i64 %v3258 to ptr
  %p3261 = inttoptr i64 %v3259 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3261, ptr %p3260, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3262 = load i64, ptr %slot13, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  store i32 2, ptr %p3263, align 4, !alias.scope !3, !noalias !4
  %v3264 = load i64, ptr %slot15, align 8
  %p3265 = inttoptr i64 %v3264 to ptr
  %ld3266 = load i32, ptr %p3265, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3266, ptr %slot572, align 8
  %v3267 = load i32, ptr %slot572, align 8
  %v3268 = load i64, ptr %slot13, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  store i32 %v3267, ptr %p3269, align 4, !alias.scope !3, !noalias !4
  %v3270 = load i64, ptr %slot14, align 8
  %p3271 = inttoptr i64 %v3270 to ptr
  store i32 0, ptr %p3271, align 4, !alias.scope !3, !noalias !4
  %v3272 = load i64, ptr %slot12, align 8
  %p3273 = inttoptr i64 %v3272 to ptr
  store i32 1, ptr %p3273, align 4, !alias.scope !3, !noalias !4
  %v3274 = load i64, ptr %slot570, align 8
  %v3275 = load i64, ptr %slot31, align 8
  %p3276 = inttoptr i64 %v3275 to ptr
  store i64 %v3274, ptr %p3276, align 8, !alias.scope !3, !noalias !4
  %v3277 = load i64, ptr %slot31, align 8
  %p3278 = inttoptr i64 %v3277 to ptr
  %ld3279 = load i64, ptr %p3278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3279, ptr %slot573, align 8
  %v3280 = load i64, ptr %slot573, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  %ld3282 = load i32, ptr %p3281, align 4, !alias.scope !3, !noalias !4
  %ext3283 = zext i32 %ld3282 to i64
  store i64 %ext3283, ptr %slot574, align 8
  %v3284 = load i64, ptr %slot574, align 8
  %cmp3285 = icmp eq i64 %v3284, 1
  %cv3286 = zext i1 %cmp3285 to i64
  store i64 %cv3286, ptr %slot575, align 8
  %v3287 = load i64, ptr %slot575, align 8
  %cond3288 = icmp ne i64 %v3287, 0
  br i1 %cond3288, label %bb_errtrace992, label %bb_errtraced992
bb_errtrace992:
  %p3289 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3289, i64 8589934638) "call-inline-cost"="0", !dbg !148
  br label %bb_errtraced992
bb_errtraced992:
  %v3290 = load i64, ptr %slot31, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  %ld3292 = load i64, ptr %p3291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3292, ptr %slot576, align 8
  %v3293 = load i64, ptr %slot18, align 8
  store i64 %v3293, ptr %slot577, align 8
  %v3294 = load i64, ptr %slot42, align 8
  store i64 %v3294, ptr %slot578, align 8
  %v3295 = load i64, ptr %slot41, align 8
  %v3296 = load i64, ptr %slot577, align 8
  %v3297 = load i64, ptr %slot576, align 8
  %v3298 = load i64, ptr %slot578, align 8
  %cv3299 = trunc i64 %v3298 to i32
  %call3300 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v3295, i64 %v3296, i64 %v3297, i32 %cv3299) nomerge, !dbg !148
  store i32 %call3300, ptr %slot579, align 8
  %v3301 = load i32, ptr %slot579, align 8
  %cv3302 = zext i32 %v3301 to i64
  %cond3303 = icmp ne i64 %cv3302, 0
  br i1 %cond3303, label %bb_rcsuccess997, label %bb_rcfailure997
bb_rcfailure997:
  %v3304 = load i64, ptr %slot41, align 8
  %p3305 = inttoptr i64 %v3304 to ptr
  %call3306 = call i32 @myl_rc_take_failure(ptr %p3305) nomerge, !dbg !148
  store i32 %call3306, ptr %slot580, align 8
  %v3307 = load i64, ptr %slot1, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  %v3309 = load i32, ptr %slot580, align 8
  %call3310 = call i32 @myl_qbe_rc_status(ptr %p3308, i32 %v3309) nomerge, !dbg !148
  store i32 %call3310, ptr %slot581, align 8
  br label %bb_failure
bb_rcsuccess997:
  %v3311 = load i64, ptr %slot12, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  store i32 0, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  %v3313 = load i64, ptr %slot15, align 8
  %p3314 = inttoptr i64 %v3313 to ptr
  store i32 2, ptr %p3314, align 4, !alias.scope !3, !noalias !4
  %v3315 = load i64, ptr %slot14, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  store i32 1, ptr %p3316, align 4, !alias.scope !3, !noalias !4
  %v3317 = load i64, ptr %slot18, align 8
  store i64 %v3317, ptr %slot582, align 8
  %v3318 = load i64, ptr %slot14, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  store i32 0, ptr %p3319, align 4, !alias.scope !3, !noalias !4
  %v3320 = load i64, ptr %slot12, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  %ld3322 = load i32, ptr %p3321, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3322, ptr %slot583, align 8
  %v3323 = load i32, ptr %slot583, align 8
  %cv3324 = zext i32 %v3323 to i64
  %cond3325 = icmp ne i64 %cv3324, 0
  br i1 %cond3325, label %bb_rcslotdrop1007, label %bb_rcslotdone1007
bb_rcslotdrop1007:
  %v3326 = load i64, ptr %slot12, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  store i32 0, ptr %p3327, align 4, !alias.scope !3, !noalias !4
  %v3328 = load i64, ptr %slot17, align 8
  store i64 %v3328, ptr %slot584, align 8
  %v3329 = load i64, ptr %slot13, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  %ld3331 = load i32, ptr %p3330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3331, ptr %slot585, align 8
  %v3332 = load i32, ptr %slot585, align 8
  %op3333 = and i32 %v3332, 28
  store i32 %op3333, ptr %slot586, align 8
  %v3334 = load i32, ptr %slot586, align 8
  %cv3335 = zext i32 %v3334 to i64
  %cond3336 = icmp ne i64 %cv3335, 0
  br i1 %cond3336, label %bb_rcslotrole1007, label %bb_rcslotowner1007
bb_rcslotrole1007:
  %v3337 = load i64, ptr %slot41, align 8
  store i64 %v3337, ptr %slot587, align 8
  %v3338 = load i64, ptr %slot587, align 8
  %v3339 = load i64, ptr %slot584, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v3338, i64 %v3339) nomerge, !dbg !148
  br label %bb_rcslotdone1007
bb_rcslotowner1007:
  %v3340 = load i64, ptr %slot41, align 8
  store i64 %v3340, ptr %slot588, align 8
  %v3341 = load i64, ptr %slot588, align 8
  %v3342 = load i64, ptr %slot584, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v3341, i64 %v3342) nomerge, !dbg !148
  br label %bb_rcslotdone1007
bb_rcslotdone1007:
  %v3343 = load i64, ptr %slot10, align 8
  %p3344 = inttoptr i64 %v3343 to ptr
  %ld3345 = load i32, ptr %p3344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3345, ptr %slot589, align 8
  %v3346 = load i32, ptr %slot589, align 8
  %cv3347 = zext i32 %v3346 to i64
  %cond3348 = icmp ne i64 %cv3347, 0
  br i1 %cond3348, label %bb_rcslotdrop1016, label %bb_rcslotdone1016
bb_rcslotdrop1016:
  %v3349 = load i64, ptr %slot10, align 8
  %p3350 = inttoptr i64 %v3349 to ptr
  store i32 0, ptr %p3350, align 4, !alias.scope !3, !noalias !4
  %v3351 = load i64, ptr %slot29, align 8
  store i64 %v3351, ptr %slot590, align 8
  %v3352 = load i64, ptr %slot11, align 8
  %p3353 = inttoptr i64 %v3352 to ptr
  %ld3354 = load i32, ptr %p3353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3354, ptr %slot591, align 8
  %v3355 = load i32, ptr %slot591, align 8
  %op3356 = and i32 %v3355, 28
  store i32 %op3356, ptr %slot592, align 8
  %v3357 = load i32, ptr %slot592, align 8
  %cv3358 = zext i32 %v3357 to i64
  %cond3359 = icmp ne i64 %cv3358, 0
  br i1 %cond3359, label %bb_rcslotrole1016, label %bb_rcslotowner1016
bb_rcslotrole1016:
  %v3360 = load i64, ptr %slot41, align 8
  store i64 %v3360, ptr %slot593, align 8
  %v3361 = load i64, ptr %slot593, align 8
  %v3362 = load i64, ptr %slot590, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v3361, i64 %v3362) nomerge, !dbg !148
  br label %bb_rcslotdone1016
bb_rcslotowner1016:
  %v3363 = load i64, ptr %slot41, align 8
  store i64 %v3363, ptr %slot594, align 8
  %v3364 = load i64, ptr %slot594, align 8
  %v3365 = load i64, ptr %slot590, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v3364, i64 %v3365) nomerge, !dbg !148
  br label %bb_rcslotdone1016
bb_rcslotdone1016:
  %v3366 = load i64, ptr %slot8, align 8
  %p3367 = inttoptr i64 %v3366 to ptr
  %ld3368 = load i32, ptr %p3367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3368, ptr %slot595, align 8
  %v3369 = load i32, ptr %slot595, align 8
  %cv3370 = zext i32 %v3369 to i64
  %cond3371 = icmp ne i64 %cv3370, 0
  br i1 %cond3371, label %bb_rcslotdrop1025, label %bb_rcslotdone1025
bb_rcslotdrop1025:
  %v3372 = load i64, ptr %slot8, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  store i32 0, ptr %p3373, align 4, !alias.scope !3, !noalias !4
  %v3374 = load i64, ptr %slot28, align 8
  store i64 %v3374, ptr %slot596, align 8
  %v3375 = load i64, ptr %slot9, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  %ld3377 = load i32, ptr %p3376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3377, ptr %slot597, align 8
  %v3378 = load i32, ptr %slot597, align 8
  %op3379 = and i32 %v3378, 28
  store i32 %op3379, ptr %slot598, align 8
  %v3380 = load i32, ptr %slot598, align 8
  %cv3381 = zext i32 %v3380 to i64
  %cond3382 = icmp ne i64 %cv3381, 0
  br i1 %cond3382, label %bb_rcslotrole1025, label %bb_rcslotowner1025
bb_rcslotrole1025:
  %v3383 = load i64, ptr %slot41, align 8
  store i64 %v3383, ptr %slot599, align 8
  %v3384 = load i64, ptr %slot599, align 8
  %v3385 = load i64, ptr %slot596, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v3384, i64 %v3385) nomerge, !dbg !148
  br label %bb_rcslotdone1025
bb_rcslotowner1025:
  %v3386 = load i64, ptr %slot41, align 8
  store i64 %v3386, ptr %slot600, align 8
  %v3387 = load i64, ptr %slot600, align 8
  %v3388 = load i64, ptr %slot596, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v3387, i64 %v3388) nomerge, !dbg !148
  br label %bb_rcslotdone1025
bb_rcslotdone1025:
  %v3389 = load i64, ptr %slot6, align 8
  %p3390 = inttoptr i64 %v3389 to ptr
  %ld3391 = load i32, ptr %p3390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3391, ptr %slot601, align 8
  %v3392 = load i32, ptr %slot601, align 8
  %cv3393 = zext i32 %v3392 to i64
  %cond3394 = icmp ne i64 %cv3393, 0
  br i1 %cond3394, label %bb_rcslotdrop1034, label %bb_rcslotdone1034
bb_rcslotdrop1034:
  %v3395 = load i64, ptr %slot6, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  store i32 0, ptr %p3396, align 4, !alias.scope !3, !noalias !4
  %v3397 = load i64, ptr %slot23, align 8
  store i64 %v3397, ptr %slot602, align 8
  %v3398 = load i64, ptr %slot7, align 8
  %p3399 = inttoptr i64 %v3398 to ptr
  %ld3400 = load i32, ptr %p3399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3400, ptr %slot603, align 8
  %v3401 = load i32, ptr %slot603, align 8
  %op3402 = and i32 %v3401, 28
  store i32 %op3402, ptr %slot604, align 8
  %v3403 = load i32, ptr %slot604, align 8
  %cv3404 = zext i32 %v3403 to i64
  %cond3405 = icmp ne i64 %cv3404, 0
  br i1 %cond3405, label %bb_rcslotrole1034, label %bb_rcslotowner1034
bb_rcslotrole1034:
  %v3406 = load i64, ptr %slot41, align 8
  store i64 %v3406, ptr %slot605, align 8
  %v3407 = load i64, ptr %slot605, align 8
  %v3408 = load i64, ptr %slot602, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v3407, i64 %v3408) nomerge, !dbg !148
  br label %bb_rcslotdone1034
bb_rcslotowner1034:
  %v3409 = load i64, ptr %slot41, align 8
  store i64 %v3409, ptr %slot606, align 8
  %v3410 = load i64, ptr %slot606, align 8
  %v3411 = load i64, ptr %slot602, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v3410, i64 %v3411) nomerge, !dbg !148
  br label %bb_rcslotdone1034
bb_rcslotdone1034:
  %v3412 = load i64, ptr %slot582, align 8
  %p3413 = inttoptr i64 %v3412 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3413, i64 24, i1 false)
  ret void
bb_i47:
  %v3414 = load i64, ptr %slot19, align 8
  %p3415 = inttoptr i64 %v3414 to ptr
  %ld3416 = load i64, ptr %p3415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3416, ptr %slot607, align 8
  %v3417 = load i64, ptr %slot607, align 8
  %v3418 = load i64, ptr %slot31, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  store i64 %v3417, ptr %p3419, align 8, !alias.scope !3, !noalias !4
  %v3420 = load i64, ptr %slot27, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  %ld3422 = load i64, ptr %p3421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3422, ptr %slot608, align 8
  %v3423 = load i64, ptr %slot608, align 8
  %v3424 = load i64, ptr %slot32, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  store i64 %v3423, ptr %p3425, align 8, !alias.scope !3, !noalias !4
  %v3426 = load i64, ptr %slot31, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  %ld3428 = load i64, ptr %p3427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3428, ptr %slot609, align 8
  %v3429 = load i64, ptr %slot32, align 8
  %p3430 = inttoptr i64 %v3429 to ptr
  %ld3431 = load i64, ptr %p3430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3431, ptr %slot610, align 8
  %v3432 = load i64, ptr %slot1, align 8
  %v3433 = load i64, ptr %slot609, align 8
  %v3434 = load i64, ptr %slot610, align 8
  call void @myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2(ptr sret([24 x i8]) align 8 %callresult612, i64 %v3432, i64 %v3433, i64 %v3434) nomerge, !dbg !150
  %addr3435 = ptrtoint ptr %callresult612 to i64
  store i64 %addr3435, ptr %slot611, align 8
  %v3436 = load i64, ptr %slot611, align 8
  %v3437 = load i64, ptr %slot31, align 8
  %p3438 = inttoptr i64 %v3437 to ptr
  store i64 %v3436, ptr %p3438, align 8, !alias.scope !3, !noalias !4
  %v3439 = load i64, ptr %slot31, align 8
  %p3440 = inttoptr i64 %v3439 to ptr
  %ld3441 = load i64, ptr %p3440, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3441, ptr %slot613, align 8
  %v3442 = load i64, ptr %slot18, align 8
  store i64 %v3442, ptr %slot614, align 8
  %v3443 = load i64, ptr %slot613, align 8
  %v3444 = load i64, ptr %slot614, align 8
  %p3445 = inttoptr i64 %v3443 to ptr
  %p3446 = inttoptr i64 %v3444 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3446, ptr %p3445, i64 24, i1 false)
  %v3447 = load i64, ptr %slot15, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  store i32 2, ptr %p3448, align 4, !alias.scope !3, !noalias !4
  %v3449 = load i64, ptr %slot14, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  store i32 1, ptr %p3450, align 4, !alias.scope !3, !noalias !4
  %v3451 = load i64, ptr %slot12, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  %ld3453 = load i32, ptr %p3452, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3453, ptr %slot615, align 8
  %v3454 = load i32, ptr %slot615, align 8
  %cv3455 = zext i32 %v3454 to i64
  %cond3456 = icmp ne i64 %cv3455, 0
  br i1 %cond3456, label %bb_rcslotdrop1098, label %bb_rcslotdone1098
bb_rcslotdrop1098:
  %v3457 = load i64, ptr %slot12, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  store i32 0, ptr %p3458, align 4, !alias.scope !3, !noalias !4
  %v3459 = load i64, ptr %slot17, align 8
  store i64 %v3459, ptr %slot616, align 8
  %v3460 = load i64, ptr %slot13, align 8
  %p3461 = inttoptr i64 %v3460 to ptr
  %ld3462 = load i32, ptr %p3461, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3462, ptr %slot617, align 8
  %v3463 = load i32, ptr %slot617, align 8
  %op3464 = and i32 %v3463, 28
  store i32 %op3464, ptr %slot618, align 8
  %v3465 = load i32, ptr %slot618, align 8
  %cv3466 = zext i32 %v3465 to i64
  %cond3467 = icmp ne i64 %cv3466, 0
  br i1 %cond3467, label %bb_rcslotrole1098, label %bb_rcslotowner1098
bb_rcslotrole1098:
  %v3468 = load i64, ptr %slot41, align 8
  store i64 %v3468, ptr %slot619, align 8
  %v3469 = load i64, ptr %slot619, align 8
  %v3470 = load i64, ptr %slot616, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3469, i64 %v3470) nomerge, !dbg !150
  br label %bb_rcslotdone1098
bb_rcslotowner1098:
  %v3471 = load i64, ptr %slot41, align 8
  store i64 %v3471, ptr %slot620, align 8
  %v3472 = load i64, ptr %slot620, align 8
  %v3473 = load i64, ptr %slot616, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3472, i64 %v3473) nomerge, !dbg !150
  br label %bb_rcslotdone1098
bb_rcslotdone1098:
  %v3474 = load i64, ptr %slot17, align 8
  store i64 %v3474, ptr %slot621, align 8
  %v3475 = load i64, ptr %slot18, align 8
  store i64 %v3475, ptr %slot622, align 8
  %v3476 = load i64, ptr %slot622, align 8
  %v3477 = load i64, ptr %slot621, align 8
  %p3478 = inttoptr i64 %v3476 to ptr
  %p3479 = inttoptr i64 %v3477 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3479, ptr %p3478, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3480 = load i64, ptr %slot13, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  store i32 2, ptr %p3481, align 4, !alias.scope !3, !noalias !4
  %v3482 = load i64, ptr %slot15, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  %ld3484 = load i32, ptr %p3483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3484, ptr %slot623, align 8
  %v3485 = load i32, ptr %slot623, align 8
  %v3486 = load i64, ptr %slot13, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  store i32 %v3485, ptr %p3487, align 4, !alias.scope !3, !noalias !4
  %v3488 = load i64, ptr %slot14, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  store i32 0, ptr %p3489, align 4, !alias.scope !3, !noalias !4
  %v3490 = load i64, ptr %slot12, align 8
  %p3491 = inttoptr i64 %v3490 to ptr
  store i32 1, ptr %p3491, align 4, !alias.scope !3, !noalias !4
  %v3492 = load i64, ptr %slot621, align 8
  %v3493 = load i64, ptr %slot31, align 8
  %p3494 = inttoptr i64 %v3493 to ptr
  store i64 %v3492, ptr %p3494, align 8, !alias.scope !3, !noalias !4
  %v3495 = load i64, ptr %slot31, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  %ld3497 = load i64, ptr %p3496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3497, ptr %slot624, align 8
  %v3498 = load i64, ptr %slot624, align 8
  %p3499 = inttoptr i64 %v3498 to ptr
  %ld3500 = load i32, ptr %p3499, align 4, !alias.scope !3, !noalias !4
  %ext3501 = zext i32 %ld3500 to i64
  store i64 %ext3501, ptr %slot625, align 8
  %v3502 = load i64, ptr %slot625, align 8
  %cmp3503 = icmp eq i64 %v3502, 1
  %cv3504 = zext i1 %cmp3503 to i64
  store i64 %cv3504, ptr %slot626, align 8
  %v3505 = load i64, ptr %slot626, align 8
  %cond3506 = icmp ne i64 %v3505, 0
  br i1 %cond3506, label %bb_errtrace1115, label %bb_errtraced1115
bb_errtrace1115:
  %p3507 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3507, i64 8589934642) "call-inline-cost"="0", !dbg !152
  br label %bb_errtraced1115
bb_errtraced1115:
  %v3508 = load i64, ptr %slot31, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  %ld3510 = load i64, ptr %p3509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3510, ptr %slot627, align 8
  %v3511 = load i64, ptr %slot18, align 8
  store i64 %v3511, ptr %slot628, align 8
  %v3512 = load i64, ptr %slot42, align 8
  store i64 %v3512, ptr %slot629, align 8
  %v3513 = load i64, ptr %slot41, align 8
  %v3514 = load i64, ptr %slot628, align 8
  %v3515 = load i64, ptr %slot627, align 8
  %v3516 = load i64, ptr %slot629, align 8
  %cv3517 = trunc i64 %v3516 to i32
  %call3518 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v3513, i64 %v3514, i64 %v3515, i32 %cv3517) nomerge, !dbg !152
  store i32 %call3518, ptr %slot630, align 8
  %v3519 = load i32, ptr %slot630, align 8
  %cv3520 = zext i32 %v3519 to i64
  %cond3521 = icmp ne i64 %cv3520, 0
  br i1 %cond3521, label %bb_rcsuccess1120, label %bb_rcfailure1120
bb_rcfailure1120:
  %v3522 = load i64, ptr %slot41, align 8
  %p3523 = inttoptr i64 %v3522 to ptr
  %call3524 = call i32 @myl_rc_take_failure(ptr %p3523) nomerge, !dbg !152
  store i32 %call3524, ptr %slot631, align 8
  %v3525 = load i64, ptr %slot1, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  %v3527 = load i32, ptr %slot631, align 8
  %call3528 = call i32 @myl_qbe_rc_status(ptr %p3526, i32 %v3527) nomerge, !dbg !152
  store i32 %call3528, ptr %slot632, align 8
  br label %bb_failure
bb_rcsuccess1120:
  %v3529 = load i64, ptr %slot12, align 8
  %p3530 = inttoptr i64 %v3529 to ptr
  store i32 0, ptr %p3530, align 4, !alias.scope !3, !noalias !4
  %v3531 = load i64, ptr %slot15, align 8
  %p3532 = inttoptr i64 %v3531 to ptr
  store i32 2, ptr %p3532, align 4, !alias.scope !3, !noalias !4
  %v3533 = load i64, ptr %slot14, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  store i32 1, ptr %p3534, align 4, !alias.scope !3, !noalias !4
  %v3535 = load i64, ptr %slot18, align 8
  store i64 %v3535, ptr %slot633, align 8
  %v3536 = load i64, ptr %slot14, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  store i32 0, ptr %p3537, align 4, !alias.scope !3, !noalias !4
  %v3538 = load i64, ptr %slot12, align 8
  %p3539 = inttoptr i64 %v3538 to ptr
  %ld3540 = load i32, ptr %p3539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3540, ptr %slot634, align 8
  %v3541 = load i32, ptr %slot634, align 8
  %cv3542 = zext i32 %v3541 to i64
  %cond3543 = icmp ne i64 %cv3542, 0
  br i1 %cond3543, label %bb_rcslotdrop1130, label %bb_rcslotdone1130
bb_rcslotdrop1130:
  %v3544 = load i64, ptr %slot12, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  store i32 0, ptr %p3545, align 4, !alias.scope !3, !noalias !4
  %v3546 = load i64, ptr %slot17, align 8
  store i64 %v3546, ptr %slot635, align 8
  %v3547 = load i64, ptr %slot13, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  %ld3549 = load i32, ptr %p3548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3549, ptr %slot636, align 8
  %v3550 = load i32, ptr %slot636, align 8
  %op3551 = and i32 %v3550, 28
  store i32 %op3551, ptr %slot637, align 8
  %v3552 = load i32, ptr %slot637, align 8
  %cv3553 = zext i32 %v3552 to i64
  %cond3554 = icmp ne i64 %cv3553, 0
  br i1 %cond3554, label %bb_rcslotrole1130, label %bb_rcslotowner1130
bb_rcslotrole1130:
  %v3555 = load i64, ptr %slot41, align 8
  store i64 %v3555, ptr %slot638, align 8
  %v3556 = load i64, ptr %slot638, align 8
  %v3557 = load i64, ptr %slot635, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v3556, i64 %v3557) nomerge, !dbg !152
  br label %bb_rcslotdone1130
bb_rcslotowner1130:
  %v3558 = load i64, ptr %slot41, align 8
  store i64 %v3558, ptr %slot639, align 8
  %v3559 = load i64, ptr %slot639, align 8
  %v3560 = load i64, ptr %slot635, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v3559, i64 %v3560) nomerge, !dbg !152
  br label %bb_rcslotdone1130
bb_rcslotdone1130:
  %v3561 = load i64, ptr %slot10, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  %ld3563 = load i32, ptr %p3562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3563, ptr %slot640, align 8
  %v3564 = load i32, ptr %slot640, align 8
  %cv3565 = zext i32 %v3564 to i64
  %cond3566 = icmp ne i64 %cv3565, 0
  br i1 %cond3566, label %bb_rcslotdrop1139, label %bb_rcslotdone1139
bb_rcslotdrop1139:
  %v3567 = load i64, ptr %slot10, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  store i32 0, ptr %p3568, align 4, !alias.scope !3, !noalias !4
  %v3569 = load i64, ptr %slot29, align 8
  store i64 %v3569, ptr %slot641, align 8
  %v3570 = load i64, ptr %slot11, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  %ld3572 = load i32, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3572, ptr %slot642, align 8
  %v3573 = load i32, ptr %slot642, align 8
  %op3574 = and i32 %v3573, 28
  store i32 %op3574, ptr %slot643, align 8
  %v3575 = load i32, ptr %slot643, align 8
  %cv3576 = zext i32 %v3575 to i64
  %cond3577 = icmp ne i64 %cv3576, 0
  br i1 %cond3577, label %bb_rcslotrole1139, label %bb_rcslotowner1139
bb_rcslotrole1139:
  %v3578 = load i64, ptr %slot41, align 8
  store i64 %v3578, ptr %slot644, align 8
  %v3579 = load i64, ptr %slot644, align 8
  %v3580 = load i64, ptr %slot641, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v3579, i64 %v3580) nomerge, !dbg !152
  br label %bb_rcslotdone1139
bb_rcslotowner1139:
  %v3581 = load i64, ptr %slot41, align 8
  store i64 %v3581, ptr %slot645, align 8
  %v3582 = load i64, ptr %slot645, align 8
  %v3583 = load i64, ptr %slot641, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v3582, i64 %v3583) nomerge, !dbg !152
  br label %bb_rcslotdone1139
bb_rcslotdone1139:
  %v3584 = load i64, ptr %slot8, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  %ld3586 = load i32, ptr %p3585, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3586, ptr %slot646, align 8
  %v3587 = load i32, ptr %slot646, align 8
  %cv3588 = zext i32 %v3587 to i64
  %cond3589 = icmp ne i64 %cv3588, 0
  br i1 %cond3589, label %bb_rcslotdrop1148, label %bb_rcslotdone1148
bb_rcslotdrop1148:
  %v3590 = load i64, ptr %slot8, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  store i32 0, ptr %p3591, align 4, !alias.scope !3, !noalias !4
  %v3592 = load i64, ptr %slot28, align 8
  store i64 %v3592, ptr %slot647, align 8
  %v3593 = load i64, ptr %slot9, align 8
  %p3594 = inttoptr i64 %v3593 to ptr
  %ld3595 = load i32, ptr %p3594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3595, ptr %slot648, align 8
  %v3596 = load i32, ptr %slot648, align 8
  %op3597 = and i32 %v3596, 28
  store i32 %op3597, ptr %slot649, align 8
  %v3598 = load i32, ptr %slot649, align 8
  %cv3599 = zext i32 %v3598 to i64
  %cond3600 = icmp ne i64 %cv3599, 0
  br i1 %cond3600, label %bb_rcslotrole1148, label %bb_rcslotowner1148
bb_rcslotrole1148:
  %v3601 = load i64, ptr %slot41, align 8
  store i64 %v3601, ptr %slot650, align 8
  %v3602 = load i64, ptr %slot650, align 8
  %v3603 = load i64, ptr %slot647, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v3602, i64 %v3603) nomerge, !dbg !152
  br label %bb_rcslotdone1148
bb_rcslotowner1148:
  %v3604 = load i64, ptr %slot41, align 8
  store i64 %v3604, ptr %slot651, align 8
  %v3605 = load i64, ptr %slot651, align 8
  %v3606 = load i64, ptr %slot647, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v3605, i64 %v3606) nomerge, !dbg !152
  br label %bb_rcslotdone1148
bb_rcslotdone1148:
  %v3607 = load i64, ptr %slot6, align 8
  %p3608 = inttoptr i64 %v3607 to ptr
  %ld3609 = load i32, ptr %p3608, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3609, ptr %slot652, align 8
  %v3610 = load i32, ptr %slot652, align 8
  %cv3611 = zext i32 %v3610 to i64
  %cond3612 = icmp ne i64 %cv3611, 0
  br i1 %cond3612, label %bb_rcslotdrop1157, label %bb_rcslotdone1157
bb_rcslotdrop1157:
  %v3613 = load i64, ptr %slot6, align 8
  %p3614 = inttoptr i64 %v3613 to ptr
  store i32 0, ptr %p3614, align 4, !alias.scope !3, !noalias !4
  %v3615 = load i64, ptr %slot23, align 8
  store i64 %v3615, ptr %slot653, align 8
  %v3616 = load i64, ptr %slot7, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  %ld3618 = load i32, ptr %p3617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3618, ptr %slot654, align 8
  %v3619 = load i32, ptr %slot654, align 8
  %op3620 = and i32 %v3619, 28
  store i32 %op3620, ptr %slot655, align 8
  %v3621 = load i32, ptr %slot655, align 8
  %cv3622 = zext i32 %v3621 to i64
  %cond3623 = icmp ne i64 %cv3622, 0
  br i1 %cond3623, label %bb_rcslotrole1157, label %bb_rcslotowner1157
bb_rcslotrole1157:
  %v3624 = load i64, ptr %slot41, align 8
  store i64 %v3624, ptr %slot656, align 8
  %v3625 = load i64, ptr %slot656, align 8
  %v3626 = load i64, ptr %slot653, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v3625, i64 %v3626) nomerge, !dbg !152
  br label %bb_rcslotdone1157
bb_rcslotowner1157:
  %v3627 = load i64, ptr %slot41, align 8
  store i64 %v3627, ptr %slot657, align 8
  %v3628 = load i64, ptr %slot657, align 8
  %v3629 = load i64, ptr %slot653, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v3628, i64 %v3629) nomerge, !dbg !152
  br label %bb_rcslotdone1157
bb_rcslotdone1157:
  %v3630 = load i64, ptr %slot633, align 8
  %p3631 = inttoptr i64 %v3630 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3631, i64 24, i1 false)
  ret void
bb_i51:
  %v3632 = load i64, ptr %slot19, align 8
  %p3633 = inttoptr i64 %v3632 to ptr
  %ld3634 = load i64, ptr %p3633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3634, ptr %slot658, align 8
  %v3635 = load i64, ptr %slot658, align 8
  %v3636 = load i64, ptr %slot31, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  store i64 %v3635, ptr %p3637, align 8, !alias.scope !3, !noalias !4
  %v3638 = load i64, ptr %slot28, align 8
  %v3639 = load i64, ptr %slot32, align 8
  %p3640 = inttoptr i64 %v3639 to ptr
  store i64 %v3638, ptr %p3640, align 8, !alias.scope !3, !noalias !4
  %v3641 = load i64, ptr %slot31, align 8
  %p3642 = inttoptr i64 %v3641 to ptr
  %ld3643 = load i64, ptr %p3642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3643, ptr %slot659, align 8
  %v3644 = load i64, ptr %slot32, align 8
  %p3645 = inttoptr i64 %v3644 to ptr
  %ld3646 = load i64, ptr %p3645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3646, ptr %slot660, align 8
  %v3647 = load i64, ptr %slot1, align 8
  %v3648 = load i64, ptr %slot659, align 8
  %v3649 = load i64, ptr %slot660, align 8
  call void @myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01(ptr sret([24 x i8]) align 8 %callresult662, i64 %v3647, i64 %v3648, i64 %v3649) nomerge, !dbg !154
  %addr3650 = ptrtoint ptr %callresult662 to i64
  store i64 %addr3650, ptr %slot661, align 8
  %v3651 = load i64, ptr %slot661, align 8
  %v3652 = load i64, ptr %slot31, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  store i64 %v3651, ptr %p3653, align 8, !alias.scope !3, !noalias !4
  %v3654 = load i64, ptr %slot31, align 8
  %p3655 = inttoptr i64 %v3654 to ptr
  %ld3656 = load i64, ptr %p3655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3656, ptr %slot663, align 8
  %v3657 = load i64, ptr %slot18, align 8
  store i64 %v3657, ptr %slot664, align 8
  %v3658 = load i64, ptr %slot663, align 8
  %v3659 = load i64, ptr %slot664, align 8
  %p3660 = inttoptr i64 %v3658 to ptr
  %p3661 = inttoptr i64 %v3659 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3661, ptr %p3660, i64 24, i1 false)
  %v3662 = load i64, ptr %slot15, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  store i32 2, ptr %p3663, align 4, !alias.scope !3, !noalias !4
  %v3664 = load i64, ptr %slot14, align 8
  %p3665 = inttoptr i64 %v3664 to ptr
  store i32 1, ptr %p3665, align 4, !alias.scope !3, !noalias !4
  %v3666 = load i64, ptr %slot12, align 8
  %p3667 = inttoptr i64 %v3666 to ptr
  %ld3668 = load i32, ptr %p3667, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3668, ptr %slot665, align 8
  %v3669 = load i32, ptr %slot665, align 8
  %cv3670 = zext i32 %v3669 to i64
  %cond3671 = icmp ne i64 %cv3670, 0
  br i1 %cond3671, label %bb_rcslotdrop1220, label %bb_rcslotdone1220
bb_rcslotdrop1220:
  %v3672 = load i64, ptr %slot12, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  store i32 0, ptr %p3673, align 4, !alias.scope !3, !noalias !4
  %v3674 = load i64, ptr %slot17, align 8
  store i64 %v3674, ptr %slot666, align 8
  %v3675 = load i64, ptr %slot13, align 8
  %p3676 = inttoptr i64 %v3675 to ptr
  %ld3677 = load i32, ptr %p3676, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3677, ptr %slot667, align 8
  %v3678 = load i32, ptr %slot667, align 8
  %op3679 = and i32 %v3678, 28
  store i32 %op3679, ptr %slot668, align 8
  %v3680 = load i32, ptr %slot668, align 8
  %cv3681 = zext i32 %v3680 to i64
  %cond3682 = icmp ne i64 %cv3681, 0
  br i1 %cond3682, label %bb_rcslotrole1220, label %bb_rcslotowner1220
bb_rcslotrole1220:
  %v3683 = load i64, ptr %slot41, align 8
  store i64 %v3683, ptr %slot669, align 8
  %v3684 = load i64, ptr %slot669, align 8
  %v3685 = load i64, ptr %slot666, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3684, i64 %v3685) nomerge, !dbg !154
  br label %bb_rcslotdone1220
bb_rcslotowner1220:
  %v3686 = load i64, ptr %slot41, align 8
  store i64 %v3686, ptr %slot670, align 8
  %v3687 = load i64, ptr %slot670, align 8
  %v3688 = load i64, ptr %slot666, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3687, i64 %v3688) nomerge, !dbg !154
  br label %bb_rcslotdone1220
bb_rcslotdone1220:
  %v3689 = load i64, ptr %slot17, align 8
  store i64 %v3689, ptr %slot671, align 8
  %v3690 = load i64, ptr %slot18, align 8
  store i64 %v3690, ptr %slot672, align 8
  %v3691 = load i64, ptr %slot672, align 8
  %v3692 = load i64, ptr %slot671, align 8
  %p3693 = inttoptr i64 %v3691 to ptr
  %p3694 = inttoptr i64 %v3692 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3694, ptr %p3693, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3695 = load i64, ptr %slot13, align 8
  %p3696 = inttoptr i64 %v3695 to ptr
  store i32 2, ptr %p3696, align 4, !alias.scope !3, !noalias !4
  %v3697 = load i64, ptr %slot15, align 8
  %p3698 = inttoptr i64 %v3697 to ptr
  %ld3699 = load i32, ptr %p3698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3699, ptr %slot673, align 8
  %v3700 = load i32, ptr %slot673, align 8
  %v3701 = load i64, ptr %slot13, align 8
  %p3702 = inttoptr i64 %v3701 to ptr
  store i32 %v3700, ptr %p3702, align 4, !alias.scope !3, !noalias !4
  %v3703 = load i64, ptr %slot14, align 8
  %p3704 = inttoptr i64 %v3703 to ptr
  store i32 0, ptr %p3704, align 4, !alias.scope !3, !noalias !4
  %v3705 = load i64, ptr %slot12, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  store i32 1, ptr %p3706, align 4, !alias.scope !3, !noalias !4
  %v3707 = load i64, ptr %slot671, align 8
  %v3708 = load i64, ptr %slot31, align 8
  %p3709 = inttoptr i64 %v3708 to ptr
  store i64 %v3707, ptr %p3709, align 8, !alias.scope !3, !noalias !4
  %v3710 = load i64, ptr %slot31, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  %ld3712 = load i64, ptr %p3711, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3712, ptr %slot674, align 8
  %v3713 = load i64, ptr %slot674, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  %ld3715 = load i32, ptr %p3714, align 4, !alias.scope !3, !noalias !4
  %ext3716 = zext i32 %ld3715 to i64
  store i64 %ext3716, ptr %slot675, align 8
  %v3717 = load i64, ptr %slot675, align 8
  %cmp3718 = icmp eq i64 %v3717, 1
  %cv3719 = zext i1 %cmp3718 to i64
  store i64 %cv3719, ptr %slot676, align 8
  %v3720 = load i64, ptr %slot676, align 8
  %cond3721 = icmp ne i64 %v3720, 0
  br i1 %cond3721, label %bb_errtrace1246, label %bb_errtraced1246
bb_errtrace1246:
  %p3722 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3722, i64 8589934646) "call-inline-cost"="0", !dbg !156
  br label %bb_errtraced1246
bb_errtraced1246:
  %v3723 = load i64, ptr %slot31, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %ld3725 = load i64, ptr %p3724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3725, ptr %slot677, align 8
  %v3726 = load i64, ptr %slot18, align 8
  store i64 %v3726, ptr %slot678, align 8
  %v3727 = load i64, ptr %slot42, align 8
  store i64 %v3727, ptr %slot679, align 8
  %v3728 = load i64, ptr %slot41, align 8
  %v3729 = load i64, ptr %slot678, align 8
  %v3730 = load i64, ptr %slot677, align 8
  %v3731 = load i64, ptr %slot679, align 8
  %cv3732 = trunc i64 %v3731 to i32
  %call3733 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v3728, i64 %v3729, i64 %v3730, i32 %cv3732) nomerge, !dbg !156
  store i32 %call3733, ptr %slot680, align 8
  %v3734 = load i32, ptr %slot680, align 8
  %cv3735 = zext i32 %v3734 to i64
  %cond3736 = icmp ne i64 %cv3735, 0
  br i1 %cond3736, label %bb_rcsuccess1251, label %bb_rcfailure1251
bb_rcfailure1251:
  %v3737 = load i64, ptr %slot41, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  %call3739 = call i32 @myl_rc_take_failure(ptr %p3738) nomerge, !dbg !156
  store i32 %call3739, ptr %slot681, align 8
  %v3740 = load i64, ptr %slot1, align 8
  %p3741 = inttoptr i64 %v3740 to ptr
  %v3742 = load i32, ptr %slot681, align 8
  %call3743 = call i32 @myl_qbe_rc_status(ptr %p3741, i32 %v3742) nomerge, !dbg !156
  store i32 %call3743, ptr %slot682, align 8
  br label %bb_failure
bb_rcsuccess1251:
  %v3744 = load i64, ptr %slot12, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  store i32 0, ptr %p3745, align 4, !alias.scope !3, !noalias !4
  %v3746 = load i64, ptr %slot15, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  store i32 2, ptr %p3747, align 4, !alias.scope !3, !noalias !4
  %v3748 = load i64, ptr %slot14, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  store i32 1, ptr %p3749, align 4, !alias.scope !3, !noalias !4
  %v3750 = load i64, ptr %slot18, align 8
  store i64 %v3750, ptr %slot683, align 8
  %v3751 = load i64, ptr %slot14, align 8
  %p3752 = inttoptr i64 %v3751 to ptr
  store i32 0, ptr %p3752, align 4, !alias.scope !3, !noalias !4
  %v3753 = load i64, ptr %slot12, align 8
  %p3754 = inttoptr i64 %v3753 to ptr
  %ld3755 = load i32, ptr %p3754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3755, ptr %slot684, align 8
  %v3756 = load i32, ptr %slot684, align 8
  %cv3757 = zext i32 %v3756 to i64
  %cond3758 = icmp ne i64 %cv3757, 0
  br i1 %cond3758, label %bb_rcslotdrop1261, label %bb_rcslotdone1261
bb_rcslotdrop1261:
  %v3759 = load i64, ptr %slot12, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  store i32 0, ptr %p3760, align 4, !alias.scope !3, !noalias !4
  %v3761 = load i64, ptr %slot17, align 8
  store i64 %v3761, ptr %slot685, align 8
  %v3762 = load i64, ptr %slot13, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %ld3764 = load i32, ptr %p3763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3764, ptr %slot686, align 8
  %v3765 = load i32, ptr %slot686, align 8
  %op3766 = and i32 %v3765, 28
  store i32 %op3766, ptr %slot687, align 8
  %v3767 = load i32, ptr %slot687, align 8
  %cv3768 = zext i32 %v3767 to i64
  %cond3769 = icmp ne i64 %cv3768, 0
  br i1 %cond3769, label %bb_rcslotrole1261, label %bb_rcslotowner1261
bb_rcslotrole1261:
  %v3770 = load i64, ptr %slot41, align 8
  store i64 %v3770, ptr %slot688, align 8
  %v3771 = load i64, ptr %slot688, align 8
  %v3772 = load i64, ptr %slot685, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v3771, i64 %v3772) nomerge, !dbg !156
  br label %bb_rcslotdone1261
bb_rcslotowner1261:
  %v3773 = load i64, ptr %slot41, align 8
  store i64 %v3773, ptr %slot689, align 8
  %v3774 = load i64, ptr %slot689, align 8
  %v3775 = load i64, ptr %slot685, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v3774, i64 %v3775) nomerge, !dbg !156
  br label %bb_rcslotdone1261
bb_rcslotdone1261:
  %v3776 = load i64, ptr %slot10, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  %ld3778 = load i32, ptr %p3777, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3778, ptr %slot690, align 8
  %v3779 = load i32, ptr %slot690, align 8
  %cv3780 = zext i32 %v3779 to i64
  %cond3781 = icmp ne i64 %cv3780, 0
  br i1 %cond3781, label %bb_rcslotdrop1270, label %bb_rcslotdone1270
bb_rcslotdrop1270:
  %v3782 = load i64, ptr %slot10, align 8
  %p3783 = inttoptr i64 %v3782 to ptr
  store i32 0, ptr %p3783, align 4, !alias.scope !3, !noalias !4
  %v3784 = load i64, ptr %slot29, align 8
  store i64 %v3784, ptr %slot691, align 8
  %v3785 = load i64, ptr %slot11, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i32, ptr %p3786, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3787, ptr %slot692, align 8
  %v3788 = load i32, ptr %slot692, align 8
  %op3789 = and i32 %v3788, 28
  store i32 %op3789, ptr %slot693, align 8
  %v3790 = load i32, ptr %slot693, align 8
  %cv3791 = zext i32 %v3790 to i64
  %cond3792 = icmp ne i64 %cv3791, 0
  br i1 %cond3792, label %bb_rcslotrole1270, label %bb_rcslotowner1270
bb_rcslotrole1270:
  %v3793 = load i64, ptr %slot41, align 8
  store i64 %v3793, ptr %slot694, align 8
  %v3794 = load i64, ptr %slot694, align 8
  %v3795 = load i64, ptr %slot691, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v3794, i64 %v3795) nomerge, !dbg !156
  br label %bb_rcslotdone1270
bb_rcslotowner1270:
  %v3796 = load i64, ptr %slot41, align 8
  store i64 %v3796, ptr %slot695, align 8
  %v3797 = load i64, ptr %slot695, align 8
  %v3798 = load i64, ptr %slot691, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v3797, i64 %v3798) nomerge, !dbg !156
  br label %bb_rcslotdone1270
bb_rcslotdone1270:
  %v3799 = load i64, ptr %slot8, align 8
  %p3800 = inttoptr i64 %v3799 to ptr
  %ld3801 = load i32, ptr %p3800, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3801, ptr %slot696, align 8
  %v3802 = load i32, ptr %slot696, align 8
  %cv3803 = zext i32 %v3802 to i64
  %cond3804 = icmp ne i64 %cv3803, 0
  br i1 %cond3804, label %bb_rcslotdrop1279, label %bb_rcslotdone1279
bb_rcslotdrop1279:
  %v3805 = load i64, ptr %slot8, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  store i32 0, ptr %p3806, align 4, !alias.scope !3, !noalias !4
  %v3807 = load i64, ptr %slot28, align 8
  store i64 %v3807, ptr %slot697, align 8
  %v3808 = load i64, ptr %slot9, align 8
  %p3809 = inttoptr i64 %v3808 to ptr
  %ld3810 = load i32, ptr %p3809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3810, ptr %slot698, align 8
  %v3811 = load i32, ptr %slot698, align 8
  %op3812 = and i32 %v3811, 28
  store i32 %op3812, ptr %slot699, align 8
  %v3813 = load i32, ptr %slot699, align 8
  %cv3814 = zext i32 %v3813 to i64
  %cond3815 = icmp ne i64 %cv3814, 0
  br i1 %cond3815, label %bb_rcslotrole1279, label %bb_rcslotowner1279
bb_rcslotrole1279:
  %v3816 = load i64, ptr %slot41, align 8
  store i64 %v3816, ptr %slot700, align 8
  %v3817 = load i64, ptr %slot700, align 8
  %v3818 = load i64, ptr %slot697, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v3817, i64 %v3818) nomerge, !dbg !156
  br label %bb_rcslotdone1279
bb_rcslotowner1279:
  %v3819 = load i64, ptr %slot41, align 8
  store i64 %v3819, ptr %slot701, align 8
  %v3820 = load i64, ptr %slot701, align 8
  %v3821 = load i64, ptr %slot697, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v3820, i64 %v3821) nomerge, !dbg !156
  br label %bb_rcslotdone1279
bb_rcslotdone1279:
  %v3822 = load i64, ptr %slot6, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %ld3824 = load i32, ptr %p3823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3824, ptr %slot702, align 8
  %v3825 = load i32, ptr %slot702, align 8
  %cv3826 = zext i32 %v3825 to i64
  %cond3827 = icmp ne i64 %cv3826, 0
  br i1 %cond3827, label %bb_rcslotdrop1288, label %bb_rcslotdone1288
bb_rcslotdrop1288:
  %v3828 = load i64, ptr %slot6, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  store i32 0, ptr %p3829, align 4, !alias.scope !3, !noalias !4
  %v3830 = load i64, ptr %slot23, align 8
  store i64 %v3830, ptr %slot703, align 8
  %v3831 = load i64, ptr %slot7, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %ld3833 = load i32, ptr %p3832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3833, ptr %slot704, align 8
  %v3834 = load i32, ptr %slot704, align 8
  %op3835 = and i32 %v3834, 28
  store i32 %op3835, ptr %slot705, align 8
  %v3836 = load i32, ptr %slot705, align 8
  %cv3837 = zext i32 %v3836 to i64
  %cond3838 = icmp ne i64 %cv3837, 0
  br i1 %cond3838, label %bb_rcslotrole1288, label %bb_rcslotowner1288
bb_rcslotrole1288:
  %v3839 = load i64, ptr %slot41, align 8
  store i64 %v3839, ptr %slot706, align 8
  %v3840 = load i64, ptr %slot706, align 8
  %v3841 = load i64, ptr %slot703, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v3840, i64 %v3841) nomerge, !dbg !156
  br label %bb_rcslotdone1288
bb_rcslotowner1288:
  %v3842 = load i64, ptr %slot41, align 8
  store i64 %v3842, ptr %slot707, align 8
  %v3843 = load i64, ptr %slot707, align 8
  %v3844 = load i64, ptr %slot703, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v3843, i64 %v3844) nomerge, !dbg !156
  br label %bb_rcslotdone1288
bb_rcslotdone1288:
  %v3845 = load i64, ptr %slot683, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3846, i64 24, i1 false)
  ret void
bb_i55:
  %v3847 = load i64, ptr %slot19, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  %ld3849 = load i64, ptr %p3848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3849, ptr %slot708, align 8
  %v3850 = load i64, ptr %slot708, align 8
  %v3851 = load i64, ptr %slot31, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  store i64 %v3850, ptr %p3852, align 8, !alias.scope !3, !noalias !4
  %v3853 = load i64, ptr %slot29, align 8
  %v3854 = load i64, ptr %slot32, align 8
  %p3855 = inttoptr i64 %v3854 to ptr
  store i64 %v3853, ptr %p3855, align 8, !alias.scope !3, !noalias !4
  %v3856 = load i64, ptr %slot31, align 8
  %p3857 = inttoptr i64 %v3856 to ptr
  %ld3858 = load i64, ptr %p3857, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3858, ptr %slot709, align 8
  %v3859 = load i64, ptr %slot32, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  %ld3861 = load i64, ptr %p3860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3861, ptr %slot710, align 8
  %v3862 = load i64, ptr %slot1, align 8
  %v3863 = load i64, ptr %slot709, align 8
  %v3864 = load i64, ptr %slot710, align 8
  call void @myl_f_bd1b315e4bdfcb2555dc201fbffc9f3f3da9e1085b3c479b7a8afa8f3cd7d810(ptr sret([24 x i8]) align 8 %callresult712, i64 %v3862, i64 %v3863, i64 %v3864) nomerge, !dbg !158
  %addr3865 = ptrtoint ptr %callresult712 to i64
  store i64 %addr3865, ptr %slot711, align 8
  %v3866 = load i64, ptr %slot711, align 8
  %v3867 = load i64, ptr %slot31, align 8
  %p3868 = inttoptr i64 %v3867 to ptr
  store i64 %v3866, ptr %p3868, align 8, !alias.scope !3, !noalias !4
  %v3869 = load i64, ptr %slot31, align 8
  %p3870 = inttoptr i64 %v3869 to ptr
  %ld3871 = load i64, ptr %p3870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3871, ptr %slot713, align 8
  %v3872 = load i64, ptr %slot18, align 8
  store i64 %v3872, ptr %slot714, align 8
  %v3873 = load i64, ptr %slot713, align 8
  %v3874 = load i64, ptr %slot714, align 8
  %p3875 = inttoptr i64 %v3873 to ptr
  %p3876 = inttoptr i64 %v3874 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3876, ptr %p3875, i64 24, i1 false)
  %v3877 = load i64, ptr %slot15, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  store i32 2, ptr %p3878, align 4, !alias.scope !3, !noalias !4
  %v3879 = load i64, ptr %slot14, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  store i32 1, ptr %p3880, align 4, !alias.scope !3, !noalias !4
  %v3881 = load i64, ptr %slot12, align 8
  %p3882 = inttoptr i64 %v3881 to ptr
  %ld3883 = load i32, ptr %p3882, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3883, ptr %slot715, align 8
  %v3884 = load i32, ptr %slot715, align 8
  %cv3885 = zext i32 %v3884 to i64
  %cond3886 = icmp ne i64 %cv3885, 0
  br i1 %cond3886, label %bb_rcslotdrop1351, label %bb_rcslotdone1351
bb_rcslotdrop1351:
  %v3887 = load i64, ptr %slot12, align 8
  %p3888 = inttoptr i64 %v3887 to ptr
  store i32 0, ptr %p3888, align 4, !alias.scope !3, !noalias !4
  %v3889 = load i64, ptr %slot17, align 8
  store i64 %v3889, ptr %slot716, align 8
  %v3890 = load i64, ptr %slot13, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  %ld3892 = load i32, ptr %p3891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3892, ptr %slot717, align 8
  %v3893 = load i32, ptr %slot717, align 8
  %op3894 = and i32 %v3893, 28
  store i32 %op3894, ptr %slot718, align 8
  %v3895 = load i32, ptr %slot718, align 8
  %cv3896 = zext i32 %v3895 to i64
  %cond3897 = icmp ne i64 %cv3896, 0
  br i1 %cond3897, label %bb_rcslotrole1351, label %bb_rcslotowner1351
bb_rcslotrole1351:
  %v3898 = load i64, ptr %slot41, align 8
  store i64 %v3898, ptr %slot719, align 8
  %v3899 = load i64, ptr %slot719, align 8
  %v3900 = load i64, ptr %slot716, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3899, i64 %v3900) nomerge, !dbg !158
  br label %bb_rcslotdone1351
bb_rcslotowner1351:
  %v3901 = load i64, ptr %slot41, align 8
  store i64 %v3901, ptr %slot720, align 8
  %v3902 = load i64, ptr %slot720, align 8
  %v3903 = load i64, ptr %slot716, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3902, i64 %v3903) nomerge, !dbg !158
  br label %bb_rcslotdone1351
bb_rcslotdone1351:
  %v3904 = load i64, ptr %slot17, align 8
  store i64 %v3904, ptr %slot721, align 8
  %v3905 = load i64, ptr %slot18, align 8
  store i64 %v3905, ptr %slot722, align 8
  %v3906 = load i64, ptr %slot722, align 8
  %v3907 = load i64, ptr %slot721, align 8
  %p3908 = inttoptr i64 %v3906 to ptr
  %p3909 = inttoptr i64 %v3907 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3909, ptr %p3908, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3910 = load i64, ptr %slot13, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  store i32 2, ptr %p3911, align 4, !alias.scope !3, !noalias !4
  %v3912 = load i64, ptr %slot15, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  %ld3914 = load i32, ptr %p3913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3914, ptr %slot723, align 8
  %v3915 = load i32, ptr %slot723, align 8
  %v3916 = load i64, ptr %slot13, align 8
  %p3917 = inttoptr i64 %v3916 to ptr
  store i32 %v3915, ptr %p3917, align 4, !alias.scope !3, !noalias !4
  %v3918 = load i64, ptr %slot14, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  store i32 0, ptr %p3919, align 4, !alias.scope !3, !noalias !4
  %v3920 = load i64, ptr %slot12, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  store i32 1, ptr %p3921, align 4, !alias.scope !3, !noalias !4
  %v3922 = load i64, ptr %slot721, align 8
  %v3923 = load i64, ptr %slot31, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  store i64 %v3922, ptr %p3924, align 8, !alias.scope !3, !noalias !4
  %v3925 = load i64, ptr %slot31, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  %ld3927 = load i64, ptr %p3926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3927, ptr %slot724, align 8
  %v3928 = load i64, ptr %slot724, align 8
  %p3929 = inttoptr i64 %v3928 to ptr
  %ld3930 = load i32, ptr %p3929, align 4, !alias.scope !3, !noalias !4
  %ext3931 = zext i32 %ld3930 to i64
  store i64 %ext3931, ptr %slot725, align 8
  %v3932 = load i64, ptr %slot725, align 8
  %cmp3933 = icmp eq i64 %v3932, 1
  %cv3934 = zext i1 %cmp3933 to i64
  store i64 %cv3934, ptr %slot726, align 8
  %v3935 = load i64, ptr %slot726, align 8
  %cond3936 = icmp ne i64 %v3935, 0
  br i1 %cond3936, label %bb_errtrace1377, label %bb_errtraced1377
bb_errtrace1377:
  %p3937 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3937, i64 8589934650) "call-inline-cost"="0", !dbg !160
  br label %bb_errtraced1377
bb_errtraced1377:
  %v3938 = load i64, ptr %slot31, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  %ld3940 = load i64, ptr %p3939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3940, ptr %slot727, align 8
  %v3941 = load i64, ptr %slot18, align 8
  store i64 %v3941, ptr %slot728, align 8
  %v3942 = load i64, ptr %slot42, align 8
  store i64 %v3942, ptr %slot729, align 8
  %v3943 = load i64, ptr %slot41, align 8
  %v3944 = load i64, ptr %slot728, align 8
  %v3945 = load i64, ptr %slot727, align 8
  %v3946 = load i64, ptr %slot729, align 8
  %cv3947 = trunc i64 %v3946 to i32
  %call3948 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v3943, i64 %v3944, i64 %v3945, i32 %cv3947) nomerge, !dbg !160
  store i32 %call3948, ptr %slot730, align 8
  %v3949 = load i32, ptr %slot730, align 8
  %cv3950 = zext i32 %v3949 to i64
  %cond3951 = icmp ne i64 %cv3950, 0
  br i1 %cond3951, label %bb_rcsuccess1382, label %bb_rcfailure1382
bb_rcfailure1382:
  %v3952 = load i64, ptr %slot41, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  %call3954 = call i32 @myl_rc_take_failure(ptr %p3953) nomerge, !dbg !160
  store i32 %call3954, ptr %slot731, align 8
  %v3955 = load i64, ptr %slot1, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %v3957 = load i32, ptr %slot731, align 8
  %call3958 = call i32 @myl_qbe_rc_status(ptr %p3956, i32 %v3957) nomerge, !dbg !160
  store i32 %call3958, ptr %slot732, align 8
  br label %bb_failure
bb_rcsuccess1382:
  %v3959 = load i64, ptr %slot12, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  store i32 0, ptr %p3960, align 4, !alias.scope !3, !noalias !4
  %v3961 = load i64, ptr %slot15, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  store i32 2, ptr %p3962, align 4, !alias.scope !3, !noalias !4
  %v3963 = load i64, ptr %slot14, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  store i32 1, ptr %p3964, align 4, !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot18, align 8
  store i64 %v3965, ptr %slot733, align 8
  %v3966 = load i64, ptr %slot14, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  store i32 0, ptr %p3967, align 4, !alias.scope !3, !noalias !4
  %v3968 = load i64, ptr %slot12, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  %ld3970 = load i32, ptr %p3969, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3970, ptr %slot734, align 8
  %v3971 = load i32, ptr %slot734, align 8
  %cv3972 = zext i32 %v3971 to i64
  %cond3973 = icmp ne i64 %cv3972, 0
  br i1 %cond3973, label %bb_rcslotdrop1392, label %bb_rcslotdone1392
bb_rcslotdrop1392:
  %v3974 = load i64, ptr %slot12, align 8
  %p3975 = inttoptr i64 %v3974 to ptr
  store i32 0, ptr %p3975, align 4, !alias.scope !3, !noalias !4
  %v3976 = load i64, ptr %slot17, align 8
  store i64 %v3976, ptr %slot735, align 8
  %v3977 = load i64, ptr %slot13, align 8
  %p3978 = inttoptr i64 %v3977 to ptr
  %ld3979 = load i32, ptr %p3978, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3979, ptr %slot736, align 8
  %v3980 = load i32, ptr %slot736, align 8
  %op3981 = and i32 %v3980, 28
  store i32 %op3981, ptr %slot737, align 8
  %v3982 = load i32, ptr %slot737, align 8
  %cv3983 = zext i32 %v3982 to i64
  %cond3984 = icmp ne i64 %cv3983, 0
  br i1 %cond3984, label %bb_rcslotrole1392, label %bb_rcslotowner1392
bb_rcslotrole1392:
  %v3985 = load i64, ptr %slot41, align 8
  store i64 %v3985, ptr %slot738, align 8
  %v3986 = load i64, ptr %slot738, align 8
  %v3987 = load i64, ptr %slot735, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v3986, i64 %v3987) nomerge, !dbg !160
  br label %bb_rcslotdone1392
bb_rcslotowner1392:
  %v3988 = load i64, ptr %slot41, align 8
  store i64 %v3988, ptr %slot739, align 8
  %v3989 = load i64, ptr %slot739, align 8
  %v3990 = load i64, ptr %slot735, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v3989, i64 %v3990) nomerge, !dbg !160
  br label %bb_rcslotdone1392
bb_rcslotdone1392:
  %v3991 = load i64, ptr %slot10, align 8
  %p3992 = inttoptr i64 %v3991 to ptr
  %ld3993 = load i32, ptr %p3992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3993, ptr %slot740, align 8
  %v3994 = load i32, ptr %slot740, align 8
  %cv3995 = zext i32 %v3994 to i64
  %cond3996 = icmp ne i64 %cv3995, 0
  br i1 %cond3996, label %bb_rcslotdrop1401, label %bb_rcslotdone1401
bb_rcslotdrop1401:
  %v3997 = load i64, ptr %slot10, align 8
  %p3998 = inttoptr i64 %v3997 to ptr
  store i32 0, ptr %p3998, align 4, !alias.scope !3, !noalias !4
  %v3999 = load i64, ptr %slot29, align 8
  store i64 %v3999, ptr %slot741, align 8
  %v4000 = load i64, ptr %slot11, align 8
  %p4001 = inttoptr i64 %v4000 to ptr
  %ld4002 = load i32, ptr %p4001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4002, ptr %slot742, align 8
  %v4003 = load i32, ptr %slot742, align 8
  %op4004 = and i32 %v4003, 28
  store i32 %op4004, ptr %slot743, align 8
  %v4005 = load i32, ptr %slot743, align 8
  %cv4006 = zext i32 %v4005 to i64
  %cond4007 = icmp ne i64 %cv4006, 0
  br i1 %cond4007, label %bb_rcslotrole1401, label %bb_rcslotowner1401
bb_rcslotrole1401:
  %v4008 = load i64, ptr %slot41, align 8
  store i64 %v4008, ptr %slot744, align 8
  %v4009 = load i64, ptr %slot744, align 8
  %v4010 = load i64, ptr %slot741, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v4009, i64 %v4010) nomerge, !dbg !160
  br label %bb_rcslotdone1401
bb_rcslotowner1401:
  %v4011 = load i64, ptr %slot41, align 8
  store i64 %v4011, ptr %slot745, align 8
  %v4012 = load i64, ptr %slot745, align 8
  %v4013 = load i64, ptr %slot741, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v4012, i64 %v4013) nomerge, !dbg !160
  br label %bb_rcslotdone1401
bb_rcslotdone1401:
  %v4014 = load i64, ptr %slot8, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  %ld4016 = load i32, ptr %p4015, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4016, ptr %slot746, align 8
  %v4017 = load i32, ptr %slot746, align 8
  %cv4018 = zext i32 %v4017 to i64
  %cond4019 = icmp ne i64 %cv4018, 0
  br i1 %cond4019, label %bb_rcslotdrop1410, label %bb_rcslotdone1410
bb_rcslotdrop1410:
  %v4020 = load i64, ptr %slot8, align 8
  %p4021 = inttoptr i64 %v4020 to ptr
  store i32 0, ptr %p4021, align 4, !alias.scope !3, !noalias !4
  %v4022 = load i64, ptr %slot28, align 8
  store i64 %v4022, ptr %slot747, align 8
  %v4023 = load i64, ptr %slot9, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  %ld4025 = load i32, ptr %p4024, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4025, ptr %slot748, align 8
  %v4026 = load i32, ptr %slot748, align 8
  %op4027 = and i32 %v4026, 28
  store i32 %op4027, ptr %slot749, align 8
  %v4028 = load i32, ptr %slot749, align 8
  %cv4029 = zext i32 %v4028 to i64
  %cond4030 = icmp ne i64 %cv4029, 0
  br i1 %cond4030, label %bb_rcslotrole1410, label %bb_rcslotowner1410
bb_rcslotrole1410:
  %v4031 = load i64, ptr %slot41, align 8
  store i64 %v4031, ptr %slot750, align 8
  %v4032 = load i64, ptr %slot750, align 8
  %v4033 = load i64, ptr %slot747, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v4032, i64 %v4033) nomerge, !dbg !160
  br label %bb_rcslotdone1410
bb_rcslotowner1410:
  %v4034 = load i64, ptr %slot41, align 8
  store i64 %v4034, ptr %slot751, align 8
  %v4035 = load i64, ptr %slot751, align 8
  %v4036 = load i64, ptr %slot747, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v4035, i64 %v4036) nomerge, !dbg !160
  br label %bb_rcslotdone1410
bb_rcslotdone1410:
  %v4037 = load i64, ptr %slot6, align 8
  %p4038 = inttoptr i64 %v4037 to ptr
  %ld4039 = load i32, ptr %p4038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4039, ptr %slot752, align 8
  %v4040 = load i32, ptr %slot752, align 8
  %cv4041 = zext i32 %v4040 to i64
  %cond4042 = icmp ne i64 %cv4041, 0
  br i1 %cond4042, label %bb_rcslotdrop1419, label %bb_rcslotdone1419
bb_rcslotdrop1419:
  %v4043 = load i64, ptr %slot6, align 8
  %p4044 = inttoptr i64 %v4043 to ptr
  store i32 0, ptr %p4044, align 4, !alias.scope !3, !noalias !4
  %v4045 = load i64, ptr %slot23, align 8
  store i64 %v4045, ptr %slot753, align 8
  %v4046 = load i64, ptr %slot7, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  %ld4048 = load i32, ptr %p4047, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4048, ptr %slot754, align 8
  %v4049 = load i32, ptr %slot754, align 8
  %op4050 = and i32 %v4049, 28
  store i32 %op4050, ptr %slot755, align 8
  %v4051 = load i32, ptr %slot755, align 8
  %cv4052 = zext i32 %v4051 to i64
  %cond4053 = icmp ne i64 %cv4052, 0
  br i1 %cond4053, label %bb_rcslotrole1419, label %bb_rcslotowner1419
bb_rcslotrole1419:
  %v4054 = load i64, ptr %slot41, align 8
  store i64 %v4054, ptr %slot756, align 8
  %v4055 = load i64, ptr %slot756, align 8
  %v4056 = load i64, ptr %slot753, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v4055, i64 %v4056) nomerge, !dbg !160
  br label %bb_rcslotdone1419
bb_rcslotowner1419:
  %v4057 = load i64, ptr %slot41, align 8
  store i64 %v4057, ptr %slot757, align 8
  %v4058 = load i64, ptr %slot757, align 8
  %v4059 = load i64, ptr %slot753, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v4058, i64 %v4059) nomerge, !dbg !160
  br label %bb_rcslotdone1419
bb_rcslotdone1419:
  %v4060 = load i64, ptr %slot733, align 8
  %p4061 = inttoptr i64 %v4060 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4061, i64 24, i1 false)
  ret void
bb_i59:
  %v4062 = load i64, ptr %slot19, align 8
  %p4063 = inttoptr i64 %v4062 to ptr
  %ld4064 = load i64, ptr %p4063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4064, ptr %slot758, align 8
  %v4065 = load i64, ptr %slot758, align 8
  %v4066 = load i64, ptr %slot31, align 8
  %p4067 = inttoptr i64 %v4066 to ptr
  store i64 %v4065, ptr %p4067, align 8, !alias.scope !3, !noalias !4
  %v4068 = load i64, ptr %slot30, align 8
  %v4069 = load i64, ptr %slot32, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  store i64 %v4068, ptr %p4070, align 8, !alias.scope !3, !noalias !4
  %v4071 = load i64, ptr %slot31, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  %ld4073 = load i64, ptr %p4072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4073, ptr %slot759, align 8
  %v4074 = load i64, ptr %slot32, align 8
  %p4075 = inttoptr i64 %v4074 to ptr
  %ld4076 = load i64, ptr %p4075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4076, ptr %slot760, align 8
  %v4077 = load i64, ptr %slot1, align 8
  %v4078 = load i64, ptr %slot759, align 8
  %v4079 = load i64, ptr %slot760, align 8
  call void @myl_f_f34622ee99c4a79b053a9c68a8d926d3ee03a5d2a8e144813f93a413c8e2cea5(ptr sret([24 x i8]) align 8 %callresult762, i64 %v4077, i64 %v4078, i64 %v4079) nomerge, !dbg !162
  %addr4080 = ptrtoint ptr %callresult762 to i64
  store i64 %addr4080, ptr %slot761, align 8
  %v4081 = load i64, ptr %slot761, align 8
  %v4082 = load i64, ptr %slot31, align 8
  %p4083 = inttoptr i64 %v4082 to ptr
  store i64 %v4081, ptr %p4083, align 8, !alias.scope !3, !noalias !4
  %v4084 = load i64, ptr %slot31, align 8
  %p4085 = inttoptr i64 %v4084 to ptr
  %ld4086 = load i64, ptr %p4085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4086, ptr %slot763, align 8
  %v4087 = load i64, ptr %slot18, align 8
  store i64 %v4087, ptr %slot764, align 8
  %v4088 = load i64, ptr %slot763, align 8
  %v4089 = load i64, ptr %slot764, align 8
  %p4090 = inttoptr i64 %v4088 to ptr
  %p4091 = inttoptr i64 %v4089 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4091, ptr %p4090, i64 24, i1 false)
  %v4092 = load i64, ptr %slot15, align 8
  %p4093 = inttoptr i64 %v4092 to ptr
  store i32 2, ptr %p4093, align 4, !alias.scope !3, !noalias !4
  %v4094 = load i64, ptr %slot14, align 8
  %p4095 = inttoptr i64 %v4094 to ptr
  store i32 1, ptr %p4095, align 4, !alias.scope !3, !noalias !4
  %v4096 = load i64, ptr %slot12, align 8
  %p4097 = inttoptr i64 %v4096 to ptr
  %ld4098 = load i32, ptr %p4097, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4098, ptr %slot765, align 8
  %v4099 = load i32, ptr %slot765, align 8
  %cv4100 = zext i32 %v4099 to i64
  %cond4101 = icmp ne i64 %cv4100, 0
  br i1 %cond4101, label %bb_rcslotdrop1482, label %bb_rcslotdone1482
bb_rcslotdrop1482:
  %v4102 = load i64, ptr %slot12, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  store i32 0, ptr %p4103, align 4, !alias.scope !3, !noalias !4
  %v4104 = load i64, ptr %slot17, align 8
  store i64 %v4104, ptr %slot766, align 8
  %v4105 = load i64, ptr %slot13, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  %ld4107 = load i32, ptr %p4106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4107, ptr %slot767, align 8
  %v4108 = load i32, ptr %slot767, align 8
  %op4109 = and i32 %v4108, 28
  store i32 %op4109, ptr %slot768, align 8
  %v4110 = load i32, ptr %slot768, align 8
  %cv4111 = zext i32 %v4110 to i64
  %cond4112 = icmp ne i64 %cv4111, 0
  br i1 %cond4112, label %bb_rcslotrole1482, label %bb_rcslotowner1482
bb_rcslotrole1482:
  %v4113 = load i64, ptr %slot41, align 8
  store i64 %v4113, ptr %slot769, align 8
  %v4114 = load i64, ptr %slot769, align 8
  %v4115 = load i64, ptr %slot766, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v4114, i64 %v4115) nomerge, !dbg !162
  br label %bb_rcslotdone1482
bb_rcslotowner1482:
  %v4116 = load i64, ptr %slot41, align 8
  store i64 %v4116, ptr %slot770, align 8
  %v4117 = load i64, ptr %slot770, align 8
  %v4118 = load i64, ptr %slot766, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v4117, i64 %v4118) nomerge, !dbg !162
  br label %bb_rcslotdone1482
bb_rcslotdone1482:
  %v4119 = load i64, ptr %slot17, align 8
  store i64 %v4119, ptr %slot771, align 8
  %v4120 = load i64, ptr %slot18, align 8
  store i64 %v4120, ptr %slot772, align 8
  %v4121 = load i64, ptr %slot772, align 8
  %v4122 = load i64, ptr %slot771, align 8
  %p4123 = inttoptr i64 %v4121 to ptr
  %p4124 = inttoptr i64 %v4122 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4124, ptr %p4123, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4125 = load i64, ptr %slot13, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  store i32 2, ptr %p4126, align 4, !alias.scope !3, !noalias !4
  %v4127 = load i64, ptr %slot15, align 8
  %p4128 = inttoptr i64 %v4127 to ptr
  %ld4129 = load i32, ptr %p4128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4129, ptr %slot773, align 8
  %v4130 = load i32, ptr %slot773, align 8
  %v4131 = load i64, ptr %slot13, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  store i32 %v4130, ptr %p4132, align 4, !alias.scope !3, !noalias !4
  %v4133 = load i64, ptr %slot14, align 8
  %p4134 = inttoptr i64 %v4133 to ptr
  store i32 0, ptr %p4134, align 4, !alias.scope !3, !noalias !4
  %v4135 = load i64, ptr %slot12, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  store i32 1, ptr %p4136, align 4, !alias.scope !3, !noalias !4
  %v4137 = load i64, ptr %slot771, align 8
  %v4138 = load i64, ptr %slot31, align 8
  %p4139 = inttoptr i64 %v4138 to ptr
  store i64 %v4137, ptr %p4139, align 8, !alias.scope !3, !noalias !4
  %v4140 = load i64, ptr %slot31, align 8
  %p4141 = inttoptr i64 %v4140 to ptr
  %ld4142 = load i64, ptr %p4141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4142, ptr %slot774, align 8
  %v4143 = load i64, ptr %slot774, align 8
  %p4144 = inttoptr i64 %v4143 to ptr
  %ld4145 = load i32, ptr %p4144, align 4, !alias.scope !3, !noalias !4
  %ext4146 = zext i32 %ld4145 to i64
  store i64 %ext4146, ptr %slot775, align 8
  %v4147 = load i64, ptr %slot775, align 8
  %cmp4148 = icmp eq i64 %v4147, 1
  %cv4149 = zext i1 %cmp4148 to i64
  store i64 %cv4149, ptr %slot776, align 8
  %v4150 = load i64, ptr %slot776, align 8
  %cond4151 = icmp ne i64 %v4150, 0
  br i1 %cond4151, label %bb_errtrace1499, label %bb_errtraced1499
bb_errtrace1499:
  %p4152 = inttoptr i64 ptrtoint (ptr @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p4152, i64 8589934654) "call-inline-cost"="0", !dbg !164
  br label %bb_errtraced1499
bb_errtraced1499:
  %v4153 = load i64, ptr %slot31, align 8
  %p4154 = inttoptr i64 %v4153 to ptr
  %ld4155 = load i64, ptr %p4154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4155, ptr %slot777, align 8
  %v4156 = load i64, ptr %slot18, align 8
  store i64 %v4156, ptr %slot778, align 8
  %v4157 = load i64, ptr %slot42, align 8
  store i64 %v4157, ptr %slot779, align 8
  %v4158 = load i64, ptr %slot41, align 8
  %v4159 = load i64, ptr %slot778, align 8
  %v4160 = load i64, ptr %slot777, align 8
  %v4161 = load i64, ptr %slot779, align 8
  %cv4162 = trunc i64 %v4161 to i32
  %call4163 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v4158, i64 %v4159, i64 %v4160, i32 %cv4162) nomerge, !dbg !164
  store i32 %call4163, ptr %slot780, align 8
  %v4164 = load i32, ptr %slot780, align 8
  %cv4165 = zext i32 %v4164 to i64
  %cond4166 = icmp ne i64 %cv4165, 0
  br i1 %cond4166, label %bb_rcsuccess1504, label %bb_rcfailure1504
bb_rcfailure1504:
  %v4167 = load i64, ptr %slot41, align 8
  %p4168 = inttoptr i64 %v4167 to ptr
  %call4169 = call i32 @myl_rc_take_failure(ptr %p4168) nomerge, !dbg !164
  store i32 %call4169, ptr %slot781, align 8
  %v4170 = load i64, ptr %slot1, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %v4172 = load i32, ptr %slot781, align 8
  %call4173 = call i32 @myl_qbe_rc_status(ptr %p4171, i32 %v4172) nomerge, !dbg !164
  store i32 %call4173, ptr %slot782, align 8
  br label %bb_failure
bb_rcsuccess1504:
  %v4174 = load i64, ptr %slot12, align 8
  %p4175 = inttoptr i64 %v4174 to ptr
  store i32 0, ptr %p4175, align 4, !alias.scope !3, !noalias !4
  %v4176 = load i64, ptr %slot15, align 8
  %p4177 = inttoptr i64 %v4176 to ptr
  store i32 2, ptr %p4177, align 4, !alias.scope !3, !noalias !4
  %v4178 = load i64, ptr %slot14, align 8
  %p4179 = inttoptr i64 %v4178 to ptr
  store i32 1, ptr %p4179, align 4, !alias.scope !3, !noalias !4
  %v4180 = load i64, ptr %slot18, align 8
  store i64 %v4180, ptr %slot783, align 8
  %v4181 = load i64, ptr %slot14, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  store i32 0, ptr %p4182, align 4, !alias.scope !3, !noalias !4
  %v4183 = load i64, ptr %slot12, align 8
  %p4184 = inttoptr i64 %v4183 to ptr
  %ld4185 = load i32, ptr %p4184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4185, ptr %slot784, align 8
  %v4186 = load i32, ptr %slot784, align 8
  %cv4187 = zext i32 %v4186 to i64
  %cond4188 = icmp ne i64 %cv4187, 0
  br i1 %cond4188, label %bb_rcslotdrop1514, label %bb_rcslotdone1514
bb_rcslotdrop1514:
  %v4189 = load i64, ptr %slot12, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  store i32 0, ptr %p4190, align 4, !alias.scope !3, !noalias !4
  %v4191 = load i64, ptr %slot17, align 8
  store i64 %v4191, ptr %slot785, align 8
  %v4192 = load i64, ptr %slot13, align 8
  %p4193 = inttoptr i64 %v4192 to ptr
  %ld4194 = load i32, ptr %p4193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4194, ptr %slot786, align 8
  %v4195 = load i32, ptr %slot786, align 8
  %op4196 = and i32 %v4195, 28
  store i32 %op4196, ptr %slot787, align 8
  %v4197 = load i32, ptr %slot787, align 8
  %cv4198 = zext i32 %v4197 to i64
  %cond4199 = icmp ne i64 %cv4198, 0
  br i1 %cond4199, label %bb_rcslotrole1514, label %bb_rcslotowner1514
bb_rcslotrole1514:
  %v4200 = load i64, ptr %slot41, align 8
  store i64 %v4200, ptr %slot788, align 8
  %v4201 = load i64, ptr %slot788, align 8
  %v4202 = load i64, ptr %slot785, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v4201, i64 %v4202) nomerge, !dbg !164
  br label %bb_rcslotdone1514
bb_rcslotowner1514:
  %v4203 = load i64, ptr %slot41, align 8
  store i64 %v4203, ptr %slot789, align 8
  %v4204 = load i64, ptr %slot789, align 8
  %v4205 = load i64, ptr %slot785, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v4204, i64 %v4205) nomerge, !dbg !164
  br label %bb_rcslotdone1514
bb_rcslotdone1514:
  %v4206 = load i64, ptr %slot10, align 8
  %p4207 = inttoptr i64 %v4206 to ptr
  %ld4208 = load i32, ptr %p4207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4208, ptr %slot790, align 8
  %v4209 = load i32, ptr %slot790, align 8
  %cv4210 = zext i32 %v4209 to i64
  %cond4211 = icmp ne i64 %cv4210, 0
  br i1 %cond4211, label %bb_rcslotdrop1523, label %bb_rcslotdone1523
bb_rcslotdrop1523:
  %v4212 = load i64, ptr %slot10, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  store i32 0, ptr %p4213, align 4, !alias.scope !3, !noalias !4
  %v4214 = load i64, ptr %slot29, align 8
  store i64 %v4214, ptr %slot791, align 8
  %v4215 = load i64, ptr %slot11, align 8
  %p4216 = inttoptr i64 %v4215 to ptr
  %ld4217 = load i32, ptr %p4216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4217, ptr %slot792, align 8
  %v4218 = load i32, ptr %slot792, align 8
  %op4219 = and i32 %v4218, 28
  store i32 %op4219, ptr %slot793, align 8
  %v4220 = load i32, ptr %slot793, align 8
  %cv4221 = zext i32 %v4220 to i64
  %cond4222 = icmp ne i64 %cv4221, 0
  br i1 %cond4222, label %bb_rcslotrole1523, label %bb_rcslotowner1523
bb_rcslotrole1523:
  %v4223 = load i64, ptr %slot41, align 8
  store i64 %v4223, ptr %slot794, align 8
  %v4224 = load i64, ptr %slot794, align 8
  %v4225 = load i64, ptr %slot791, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v4224, i64 %v4225) nomerge, !dbg !164
  br label %bb_rcslotdone1523
bb_rcslotowner1523:
  %v4226 = load i64, ptr %slot41, align 8
  store i64 %v4226, ptr %slot795, align 8
  %v4227 = load i64, ptr %slot795, align 8
  %v4228 = load i64, ptr %slot791, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v4227, i64 %v4228) nomerge, !dbg !164
  br label %bb_rcslotdone1523
bb_rcslotdone1523:
  %v4229 = load i64, ptr %slot8, align 8
  %p4230 = inttoptr i64 %v4229 to ptr
  %ld4231 = load i32, ptr %p4230, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4231, ptr %slot796, align 8
  %v4232 = load i32, ptr %slot796, align 8
  %cv4233 = zext i32 %v4232 to i64
  %cond4234 = icmp ne i64 %cv4233, 0
  br i1 %cond4234, label %bb_rcslotdrop1532, label %bb_rcslotdone1532
bb_rcslotdrop1532:
  %v4235 = load i64, ptr %slot8, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  store i32 0, ptr %p4236, align 4, !alias.scope !3, !noalias !4
  %v4237 = load i64, ptr %slot28, align 8
  store i64 %v4237, ptr %slot797, align 8
  %v4238 = load i64, ptr %slot9, align 8
  %p4239 = inttoptr i64 %v4238 to ptr
  %ld4240 = load i32, ptr %p4239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4240, ptr %slot798, align 8
  %v4241 = load i32, ptr %slot798, align 8
  %op4242 = and i32 %v4241, 28
  store i32 %op4242, ptr %slot799, align 8
  %v4243 = load i32, ptr %slot799, align 8
  %cv4244 = zext i32 %v4243 to i64
  %cond4245 = icmp ne i64 %cv4244, 0
  br i1 %cond4245, label %bb_rcslotrole1532, label %bb_rcslotowner1532
bb_rcslotrole1532:
  %v4246 = load i64, ptr %slot41, align 8
  store i64 %v4246, ptr %slot800, align 8
  %v4247 = load i64, ptr %slot800, align 8
  %v4248 = load i64, ptr %slot797, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v4247, i64 %v4248) nomerge, !dbg !164
  br label %bb_rcslotdone1532
bb_rcslotowner1532:
  %v4249 = load i64, ptr %slot41, align 8
  store i64 %v4249, ptr %slot801, align 8
  %v4250 = load i64, ptr %slot801, align 8
  %v4251 = load i64, ptr %slot797, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v4250, i64 %v4251) nomerge, !dbg !164
  br label %bb_rcslotdone1532
bb_rcslotdone1532:
  %v4252 = load i64, ptr %slot6, align 8
  %p4253 = inttoptr i64 %v4252 to ptr
  %ld4254 = load i32, ptr %p4253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4254, ptr %slot802, align 8
  %v4255 = load i32, ptr %slot802, align 8
  %cv4256 = zext i32 %v4255 to i64
  %cond4257 = icmp ne i64 %cv4256, 0
  br i1 %cond4257, label %bb_rcslotdrop1541, label %bb_rcslotdone1541
bb_rcslotdrop1541:
  %v4258 = load i64, ptr %slot6, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  store i32 0, ptr %p4259, align 4, !alias.scope !3, !noalias !4
  %v4260 = load i64, ptr %slot23, align 8
  store i64 %v4260, ptr %slot803, align 8
  %v4261 = load i64, ptr %slot7, align 8
  %p4262 = inttoptr i64 %v4261 to ptr
  %ld4263 = load i32, ptr %p4262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4263, ptr %slot804, align 8
  %v4264 = load i32, ptr %slot804, align 8
  %op4265 = and i32 %v4264, 28
  store i32 %op4265, ptr %slot805, align 8
  %v4266 = load i32, ptr %slot805, align 8
  %cv4267 = zext i32 %v4266 to i64
  %cond4268 = icmp ne i64 %cv4267, 0
  br i1 %cond4268, label %bb_rcslotrole1541, label %bb_rcslotowner1541
bb_rcslotrole1541:
  %v4269 = load i64, ptr %slot41, align 8
  store i64 %v4269, ptr %slot806, align 8
  %v4270 = load i64, ptr %slot806, align 8
  %v4271 = load i64, ptr %slot803, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v4270, i64 %v4271) nomerge, !dbg !164
  br label %bb_rcslotdone1541
bb_rcslotowner1541:
  %v4272 = load i64, ptr %slot41, align 8
  store i64 %v4272, ptr %slot807, align 8
  %v4273 = load i64, ptr %slot807, align 8
  %v4274 = load i64, ptr %slot803, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v4273, i64 %v4274) nomerge, !dbg !164
  br label %bb_rcslotdone1541
bb_rcslotdone1541:
  %v4275 = load i64, ptr %slot783, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4276, i64 24, i1 false)
  ret void
bb_i63:
  %v4277 = load i64, ptr %slot35, align 8
  store i64 %v4277, ptr %slot808, align 8
  %v4278 = load i64, ptr %slot808, align 8
  %p4279 = inttoptr i64 %v4278 to ptr
  store i32 0, ptr %p4279, align 4, !alias.scope !3, !noalias !4
  %v4280 = load i64, ptr %slot808, align 8
  %p4281 = inttoptr i64 %v4280 to ptr
  store i32 0, ptr %p4281, align 4, !alias.scope !3, !noalias !4
  %v4282 = load i64, ptr %slot808, align 8
  %v4283 = load i64, ptr %slot31, align 8
  %p4284 = inttoptr i64 %v4283 to ptr
  store i64 %v4282, ptr %p4284, align 8, !alias.scope !3, !noalias !4
  %v4285 = load i64, ptr %slot36, align 8
  store i64 %v4285, ptr %slot809, align 8
  %v4286 = load i64, ptr %slot809, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  store i64 0, ptr %p4287, align 8, !alias.scope !3, !noalias !4
  %v4288 = load i64, ptr %slot809, align 8
  %p4290 = inttoptr i64 %v4288 to ptr
  %gep4291 = getelementptr i8, ptr %p4290, i64 8
  %op4289 = ptrtoint ptr %gep4291 to i64
  store i64 %op4289, ptr %slot810, align 8
  %v4292 = load i64, ptr %slot810, align 8
  %p4293 = inttoptr i64 %v4292 to ptr
  store i64 0, ptr %p4293, align 8, !alias.scope !3, !noalias !4
  %v4294 = load i64, ptr %slot809, align 8
  %p4296 = inttoptr i64 %v4294 to ptr
  %gep4297 = getelementptr i8, ptr %p4296, i64 16
  %op4295 = ptrtoint ptr %gep4297 to i64
  store i64 %op4295, ptr %slot811, align 8
  %v4298 = load i64, ptr %slot811, align 8
  %p4299 = inttoptr i64 %v4298 to ptr
  store i64 0, ptr %p4299, align 8, !alias.scope !3, !noalias !4
  %v4300 = load i64, ptr %slot809, align 8
  %p4301 = inttoptr i64 %v4300 to ptr
  store i32 0, ptr %p4301, align 4, !alias.scope !3, !noalias !4
  %v4302 = load i64, ptr %slot16, align 8
  %p4303 = inttoptr i64 %v4302 to ptr
  store i32 1, ptr %p4303, align 4, !alias.scope !3, !noalias !4
  %v4304 = load i64, ptr %slot31, align 8
  %p4305 = inttoptr i64 %v4304 to ptr
  %ld4306 = load i64, ptr %p4305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4306, ptr %slot812, align 8
  %v4307 = load i64, ptr %slot809, align 8
  %p4309 = inttoptr i64 %v4307 to ptr
  %gep4310 = getelementptr i8, ptr %p4309, i64 8
  %op4308 = ptrtoint ptr %gep4310 to i64
  store i64 %op4308, ptr %slot813, align 8
  %v4311 = load i64, ptr %slot42, align 8
  store i64 %v4311, ptr %slot814, align 8
  %v4312 = load i64, ptr %slot812, align 8
  %v4313 = load i64, ptr %slot813, align 8
  %p4314 = inttoptr i64 %v4312 to ptr
  %p4315 = inttoptr i64 %v4313 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4315, ptr %p4314, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v4316 = load i64, ptr %slot809, align 8
  %v4317 = load i64, ptr %slot31, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  store i64 %v4316, ptr %p4318, align 8, !alias.scope !3, !noalias !4
  %v4319 = load i64, ptr %slot31, align 8
  %p4320 = inttoptr i64 %v4319 to ptr
  %ld4321 = load i64, ptr %p4320, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4321, ptr %slot815, align 8
  %v4322 = load i64, ptr %slot17, align 8
  store i64 %v4322, ptr %slot816, align 8
  %v4323 = load i64, ptr %slot815, align 8
  %v4324 = load i64, ptr %slot816, align 8
  %p4325 = inttoptr i64 %v4323 to ptr
  %p4326 = inttoptr i64 %v4324 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4326, ptr %p4325, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4327 = load i64, ptr %slot13, align 8
  %p4328 = inttoptr i64 %v4327 to ptr
  store i32 2, ptr %p4328, align 4, !alias.scope !3, !noalias !4
  %v4329 = load i64, ptr %slot12, align 8
  %p4330 = inttoptr i64 %v4329 to ptr
  store i32 1, ptr %p4330, align 4, !alias.scope !3, !noalias !4
  %v4331 = load i64, ptr %slot816, align 8
  %v4332 = load i64, ptr %slot31, align 8
  %p4333 = inttoptr i64 %v4332 to ptr
  store i64 %v4331, ptr %p4333, align 8, !alias.scope !3, !noalias !4
  %v4334 = load i64, ptr %slot31, align 8
  %p4335 = inttoptr i64 %v4334 to ptr
  %ld4336 = load i64, ptr %p4335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4336, ptr %slot817, align 8
  %v4337 = load i64, ptr %slot31, align 8
  %p4338 = inttoptr i64 %v4337 to ptr
  %ld4339 = load i64, ptr %p4338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4339, ptr %slot818, align 8
  %v4340 = load i64, ptr %slot18, align 8
  store i64 %v4340, ptr %slot819, align 8
  %v4341 = load i64, ptr %slot42, align 8
  store i64 %v4341, ptr %slot820, align 8
  %v4342 = load i64, ptr %slot41, align 8
  %v4343 = load i64, ptr %slot819, align 8
  %v4344 = load i64, ptr %slot818, align 8
  %v4345 = load i64, ptr %slot820, align 8
  %cv4346 = trunc i64 %v4345 to i32
  %call4347 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v4342, i64 %v4343, i64 %v4344, i32 %cv4346) nomerge, !dbg !166
  store i32 %call4347, ptr %slot821, align 8
  %v4348 = load i32, ptr %slot821, align 8
  %cv4349 = zext i32 %v4348 to i64
  %cond4350 = icmp ne i64 %cv4349, 0
  br i1 %cond4350, label %bb_rcsuccess1612, label %bb_rcfailure1612
bb_rcfailure1612:
  %v4351 = load i64, ptr %slot41, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  %call4353 = call i32 @myl_rc_take_failure(ptr %p4352) nomerge, !dbg !166
  store i32 %call4353, ptr %slot822, align 8
  %v4354 = load i64, ptr %slot1, align 8
  %p4355 = inttoptr i64 %v4354 to ptr
  %v4356 = load i32, ptr %slot822, align 8
  %call4357 = call i32 @myl_qbe_rc_status(ptr %p4355, i32 %v4356) nomerge, !dbg !166
  store i32 %call4357, ptr %slot823, align 8
  br label %bb_failure
bb_rcsuccess1612:
  %v4358 = load i64, ptr %slot12, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  store i32 0, ptr %p4359, align 4, !alias.scope !3, !noalias !4
  %v4360 = load i64, ptr %slot15, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  store i32 2, ptr %p4361, align 4, !alias.scope !3, !noalias !4
  %v4362 = load i64, ptr %slot14, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  store i32 1, ptr %p4363, align 4, !alias.scope !3, !noalias !4
  %v4364 = load i64, ptr %slot18, align 8
  store i64 %v4364, ptr %slot824, align 8
  %v4365 = load i64, ptr %slot14, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  store i32 0, ptr %p4366, align 4, !alias.scope !3, !noalias !4
  %v4367 = load i64, ptr %slot12, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  %ld4369 = load i32, ptr %p4368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4369, ptr %slot825, align 8
  %v4370 = load i32, ptr %slot825, align 8
  %cv4371 = zext i32 %v4370 to i64
  %cond4372 = icmp ne i64 %cv4371, 0
  br i1 %cond4372, label %bb_rcslotdrop1622, label %bb_rcslotdone1622
bb_rcslotdrop1622:
  %v4373 = load i64, ptr %slot12, align 8
  %p4374 = inttoptr i64 %v4373 to ptr
  store i32 0, ptr %p4374, align 4, !alias.scope !3, !noalias !4
  %v4375 = load i64, ptr %slot17, align 8
  store i64 %v4375, ptr %slot826, align 8
  %v4376 = load i64, ptr %slot13, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %ld4378 = load i32, ptr %p4377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4378, ptr %slot827, align 8
  %v4379 = load i32, ptr %slot827, align 8
  %op4380 = and i32 %v4379, 28
  store i32 %op4380, ptr %slot828, align 8
  %v4381 = load i32, ptr %slot828, align 8
  %cv4382 = zext i32 %v4381 to i64
  %cond4383 = icmp ne i64 %cv4382, 0
  br i1 %cond4383, label %bb_rcslotrole1622, label %bb_rcslotowner1622
bb_rcslotrole1622:
  %v4384 = load i64, ptr %slot41, align 8
  store i64 %v4384, ptr %slot829, align 8
  %v4385 = load i64, ptr %slot829, align 8
  %v4386 = load i64, ptr %slot826, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v4385, i64 %v4386) nomerge, !dbg !166
  br label %bb_rcslotdone1622
bb_rcslotowner1622:
  %v4387 = load i64, ptr %slot41, align 8
  store i64 %v4387, ptr %slot830, align 8
  %v4388 = load i64, ptr %slot830, align 8
  %v4389 = load i64, ptr %slot826, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v4388, i64 %v4389) nomerge, !dbg !166
  br label %bb_rcslotdone1622
bb_rcslotdone1622:
  %v4390 = load i64, ptr %slot10, align 8
  %p4391 = inttoptr i64 %v4390 to ptr
  %ld4392 = load i32, ptr %p4391, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4392, ptr %slot831, align 8
  %v4393 = load i32, ptr %slot831, align 8
  %cv4394 = zext i32 %v4393 to i64
  %cond4395 = icmp ne i64 %cv4394, 0
  br i1 %cond4395, label %bb_rcslotdrop1631, label %bb_rcslotdone1631
bb_rcslotdrop1631:
  %v4396 = load i64, ptr %slot10, align 8
  %p4397 = inttoptr i64 %v4396 to ptr
  store i32 0, ptr %p4397, align 4, !alias.scope !3, !noalias !4
  %v4398 = load i64, ptr %slot29, align 8
  store i64 %v4398, ptr %slot832, align 8
  %v4399 = load i64, ptr %slot11, align 8
  %p4400 = inttoptr i64 %v4399 to ptr
  %ld4401 = load i32, ptr %p4400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4401, ptr %slot833, align 8
  %v4402 = load i32, ptr %slot833, align 8
  %op4403 = and i32 %v4402, 28
  store i32 %op4403, ptr %slot834, align 8
  %v4404 = load i32, ptr %slot834, align 8
  %cv4405 = zext i32 %v4404 to i64
  %cond4406 = icmp ne i64 %cv4405, 0
  br i1 %cond4406, label %bb_rcslotrole1631, label %bb_rcslotowner1631
bb_rcslotrole1631:
  %v4407 = load i64, ptr %slot41, align 8
  store i64 %v4407, ptr %slot835, align 8
  %v4408 = load i64, ptr %slot835, align 8
  %v4409 = load i64, ptr %slot832, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64 %v4408, i64 %v4409) nomerge, !dbg !166
  br label %bb_rcslotdone1631
bb_rcslotowner1631:
  %v4410 = load i64, ptr %slot41, align 8
  store i64 %v4410, ptr %slot836, align 8
  %v4411 = load i64, ptr %slot836, align 8
  %v4412 = load i64, ptr %slot832, align 8
  call void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64 %v4411, i64 %v4412) nomerge, !dbg !166
  br label %bb_rcslotdone1631
bb_rcslotdone1631:
  %v4413 = load i64, ptr %slot8, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  %ld4415 = load i32, ptr %p4414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4415, ptr %slot837, align 8
  %v4416 = load i32, ptr %slot837, align 8
  %cv4417 = zext i32 %v4416 to i64
  %cond4418 = icmp ne i64 %cv4417, 0
  br i1 %cond4418, label %bb_rcslotdrop1640, label %bb_rcslotdone1640
bb_rcslotdrop1640:
  %v4419 = load i64, ptr %slot8, align 8
  %p4420 = inttoptr i64 %v4419 to ptr
  store i32 0, ptr %p4420, align 4, !alias.scope !3, !noalias !4
  %v4421 = load i64, ptr %slot28, align 8
  store i64 %v4421, ptr %slot838, align 8
  %v4422 = load i64, ptr %slot9, align 8
  %p4423 = inttoptr i64 %v4422 to ptr
  %ld4424 = load i32, ptr %p4423, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4424, ptr %slot839, align 8
  %v4425 = load i32, ptr %slot839, align 8
  %op4426 = and i32 %v4425, 28
  store i32 %op4426, ptr %slot840, align 8
  %v4427 = load i32, ptr %slot840, align 8
  %cv4428 = zext i32 %v4427 to i64
  %cond4429 = icmp ne i64 %cv4428, 0
  br i1 %cond4429, label %bb_rcslotrole1640, label %bb_rcslotowner1640
bb_rcslotrole1640:
  %v4430 = load i64, ptr %slot41, align 8
  store i64 %v4430, ptr %slot841, align 8
  %v4431 = load i64, ptr %slot841, align 8
  %v4432 = load i64, ptr %slot838, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v4431, i64 %v4432) nomerge, !dbg !166
  br label %bb_rcslotdone1640
bb_rcslotowner1640:
  %v4433 = load i64, ptr %slot41, align 8
  store i64 %v4433, ptr %slot842, align 8
  %v4434 = load i64, ptr %slot842, align 8
  %v4435 = load i64, ptr %slot838, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v4434, i64 %v4435) nomerge, !dbg !166
  br label %bb_rcslotdone1640
bb_rcslotdone1640:
  %v4436 = load i64, ptr %slot6, align 8
  %p4437 = inttoptr i64 %v4436 to ptr
  %ld4438 = load i32, ptr %p4437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4438, ptr %slot843, align 8
  %v4439 = load i32, ptr %slot843, align 8
  %cv4440 = zext i32 %v4439 to i64
  %cond4441 = icmp ne i64 %cv4440, 0
  br i1 %cond4441, label %bb_rcslotdrop1649, label %bb_rcslotdone1649
bb_rcslotdrop1649:
  %v4442 = load i64, ptr %slot6, align 8
  %p4443 = inttoptr i64 %v4442 to ptr
  store i32 0, ptr %p4443, align 4, !alias.scope !3, !noalias !4
  %v4444 = load i64, ptr %slot23, align 8
  store i64 %v4444, ptr %slot844, align 8
  %v4445 = load i64, ptr %slot7, align 8
  %p4446 = inttoptr i64 %v4445 to ptr
  %ld4447 = load i32, ptr %p4446, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4447, ptr %slot845, align 8
  %v4448 = load i32, ptr %slot845, align 8
  %op4449 = and i32 %v4448, 28
  store i32 %op4449, ptr %slot846, align 8
  %v4450 = load i32, ptr %slot846, align 8
  %cv4451 = zext i32 %v4450 to i64
  %cond4452 = icmp ne i64 %cv4451, 0
  br i1 %cond4452, label %bb_rcslotrole1649, label %bb_rcslotowner1649
bb_rcslotrole1649:
  %v4453 = load i64, ptr %slot41, align 8
  store i64 %v4453, ptr %slot847, align 8
  %v4454 = load i64, ptr %slot847, align 8
  %v4455 = load i64, ptr %slot844, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64 %v4454, i64 %v4455) nomerge, !dbg !166
  br label %bb_rcslotdone1649
bb_rcslotowner1649:
  %v4456 = load i64, ptr %slot41, align 8
  store i64 %v4456, ptr %slot848, align 8
  %v4457 = load i64, ptr %slot848, align 8
  %v4458 = load i64, ptr %slot844, align 8
  call void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64 %v4457, i64 %v4458) nomerge, !dbg !166
  br label %bb_rcslotdone1649
bb_rcslotdone1649:
  %v4459 = load i64, ptr %slot824, align 8
  %p4460 = inttoptr i64 %v4459 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4460, i64 24, i1 false)
  ret void
bb_failure:
  %v4461 = load i64, ptr %slot5, align 8
  %p4462 = inttoptr i64 %v4461 to ptr
  call void @llvm.memset.p0.i64(ptr %p4462, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !166
  %v4463 = load i64, ptr %slot5, align 8
  %p4464 = inttoptr i64 %v4463 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4464, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v4465 = load i64, ptr %slot5, align 8
  %p4466 = inttoptr i64 %v4465 to ptr
  call void @llvm.memset.p0.i64(ptr %p4466, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !166
  %v4467 = load i64, ptr %slot5, align 8
  %p4468 = inttoptr i64 %v4467 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4468, i64 24, i1 false)
  ret void
}

@myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763(ptr sret([24 x i8]) align 8, i64, i64, i64, i64)
declare void @myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_462f27e74799004fdcfa9633adb7a2d010fc9ea32e01e7826712c1dd2033d244(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_9071aa69d62fb1d23e062dda66ed7f74ea3cd6b716225aca159e2b66890e85fc(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_bd1b315e4bdfcb2555dc201fbffc9f3f3da9e1085b3c479b7a8afa8f3cd7d810(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_f34622ee99c4a79b053a9c68a8d926d3ee03a5d2a8e144813f93a413c8e2cea5(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_f98310dc433a6ffc4936ce128753c578f0bd1637e181fedcb5c9b547efaf94b4(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_drop(i64, i64)
declare i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64, i64)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64, i64)
declare i32 @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_loan(i64, i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_drop(i64, i64)
declare i32 @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_unloan(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64, i64)
declare i32 @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806", linkageName: "myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9066525551576078104, i64 0, !"myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!126 = !DILocation(line: 21, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!128 = !DILocation(line: 26, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!130 = !DILocation(line: 27, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!132 = !DILocation(line: 30, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!134 = !DILocation(line: 31, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!136 = !DILocation(line: 33, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!138 = !DILocation(line: 38, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!140 = !DILocation(line: 39, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!142 = !DILocation(line: 42, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!144 = !DILocation(line: 43, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!146 = !DILocation(line: 46, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!148 = !DILocation(line: 47, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!150 = !DILocation(line: 50, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!152 = !DILocation(line: 51, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!154 = !DILocation(line: 54, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!156 = !DILocation(line: 55, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!158 = !DILocation(line: 58, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!160 = !DILocation(line: 59, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!162 = !DILocation(line: 62, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!164 = !DILocation(line: 63, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!166 = !DILocation(line: 66, column: 0, scope: !167)
