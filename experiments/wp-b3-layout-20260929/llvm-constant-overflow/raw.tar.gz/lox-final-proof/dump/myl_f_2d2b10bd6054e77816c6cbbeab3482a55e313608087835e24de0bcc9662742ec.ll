target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_2d2b10bd6054e77816c6cbbeab3482a55e313608087835e24de0bcc9662742ec(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %callresult730 = alloca [4 x i8], align 4
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %callresult740 = alloca [40 x i8], align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v790 = load i64, ptr %slot1, align 8
  %op791 = add i64 %v790, 32
  store i64 %op791, ptr %slot3, align 8
  %mem792 = alloca i8, i64 40, align 8
  %ptr793 = ptrtoint ptr %mem792 to i64
  store i64 %ptr793, ptr %slot4, align 8
  %mem794 = alloca i8, i64 8, align 8
  %ptr795 = ptrtoint ptr %mem794 to i64
  store i64 %ptr795, ptr %slot5, align 8
  %mem796 = alloca i8, i64 8, align 8
  %ptr797 = ptrtoint ptr %mem796 to i64
  store i64 %ptr797, ptr %slot6, align 8
  %mem798 = alloca i8, i64 8, align 8
  %ptr799 = ptrtoint ptr %mem798 to i64
  store i64 %ptr799, ptr %slot7, align 8
  %mem800 = alloca i8, i64 8, align 8
  %ptr801 = ptrtoint ptr %mem800 to i64
  store i64 %ptr801, ptr %slot8, align 8
  %mem802 = alloca i8, i64 8, align 8
  %ptr803 = ptrtoint ptr %mem802 to i64
  store i64 %ptr803, ptr %slot9, align 8
  %mem804 = alloca i8, i64 8, align 8
  %ptr805 = ptrtoint ptr %mem804 to i64
  store i64 %ptr805, ptr %slot10, align 8
  %mem806 = alloca i8, i64 8, align 8
  %ptr807 = ptrtoint ptr %mem806 to i64
  store i64 %ptr807, ptr %slot11, align 8
  %mem808 = alloca i8, i64 8, align 8
  %ptr809 = ptrtoint ptr %mem808 to i64
  store i64 %ptr809, ptr %slot12, align 8
  %mem810 = alloca i8, i64 8, align 8
  %ptr811 = ptrtoint ptr %mem810 to i64
  store i64 %ptr811, ptr %slot13, align 8
  %mem812 = alloca i8, i64 8, align 8
  %ptr813 = ptrtoint ptr %mem812 to i64
  store i64 %ptr813, ptr %slot14, align 8
  %mem814 = alloca i8, i64 8, align 8
  %ptr815 = ptrtoint ptr %mem814 to i64
  store i64 %ptr815, ptr %slot15, align 8
  %mem816 = alloca i8, i64 8, align 8
  %ptr817 = ptrtoint ptr %mem816 to i64
  store i64 %ptr817, ptr %slot16, align 8
  %mem818 = alloca i8, i64 8, align 8
  %ptr819 = ptrtoint ptr %mem818 to i64
  store i64 %ptr819, ptr %slot17, align 8
  %mem820 = alloca i8, i64 8, align 8
  %ptr821 = ptrtoint ptr %mem820 to i64
  store i64 %ptr821, ptr %slot18, align 8
  %mem822 = alloca i8, i64 40, align 8
  %ptr823 = ptrtoint ptr %mem822 to i64
  store i64 %ptr823, ptr %slot19, align 8
  %mem824 = alloca i8, i64 32, align 8
  %ptr825 = ptrtoint ptr %mem824 to i64
  store i64 %ptr825, ptr %slot20, align 8
  %mem826 = alloca i8, i64 8, align 8
  %ptr827 = ptrtoint ptr %mem826 to i64
  store i64 %ptr827, ptr %slot21, align 8
  %mem828 = alloca i8, i64 8, align 8
  %ptr829 = ptrtoint ptr %mem828 to i64
  store i64 %ptr829, ptr %slot22, align 8
  %mem830 = alloca i8, i64 40, align 8
  %ptr831 = ptrtoint ptr %mem830 to i64
  store i64 %ptr831, ptr %slot23, align 8
  %mem832 = alloca i8, i64 8, align 8
  %ptr833 = ptrtoint ptr %mem832 to i64
  store i64 %ptr833, ptr %slot24, align 8
  %mem834 = alloca i8, i64 8, align 8
  %ptr835 = ptrtoint ptr %mem834 to i64
  store i64 %ptr835, ptr %slot25, align 8
  %mem836 = alloca i8, i64 32, align 8
  %ptr837 = ptrtoint ptr %mem836 to i64
  store i64 %ptr837, ptr %slot26, align 8
  %mem838 = alloca i8, i64 32, align 8
  %ptr839 = ptrtoint ptr %mem838 to i64
  store i64 %ptr839, ptr %slot27, align 8
  %mem840 = alloca i8, i64 8, align 8
  %ptr841 = ptrtoint ptr %mem840 to i64
  store i64 %ptr841, ptr %slot28, align 8
  %mem842 = alloca i8, i64 32, align 8
  %ptr843 = ptrtoint ptr %mem842 to i64
  store i64 %ptr843, ptr %slot29, align 8
  %mem844 = alloca i8, i64 32, align 8
  %ptr845 = ptrtoint ptr %mem844 to i64
  store i64 %ptr845, ptr %slot30, align 8
  %mem846 = alloca i8, i64 8, align 8
  %ptr847 = ptrtoint ptr %mem846 to i64
  store i64 %ptr847, ptr %slot31, align 8
  %mem848 = alloca i8, i64 8, align 8
  %ptr849 = ptrtoint ptr %mem848 to i64
  store i64 %ptr849, ptr %slot32, align 8
  %mem850 = alloca i8, i64 8, align 8
  %ptr851 = ptrtoint ptr %mem850 to i64
  store i64 %ptr851, ptr %slot33, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem852 = alloca i8, i64 8, align 8
  %ptr853 = ptrtoint ptr %mem852 to i64
  store i64 %ptr853, ptr %slot34, align 8
  %v854 = load i64, ptr %slot1, align 8
  %op855 = add i64 %v854, 64
  store i64 %op855, ptr %slot35, align 8
  %v856 = load i64, ptr %slot35, align 8
  %p857 = inttoptr i64 %v856 to ptr
  %ld858 = load i64, ptr %p857, align 8, !alias.scope !4, !noalias !3
  store i64 %ld858, ptr %slot36, align 8
  %stack859 = call ptr @llvm.stacksave()
  %stackaddr860 = ptrtoint ptr %stack859 to i64
  %v861 = load i64, ptr %slot36, align 8
  %cmp862 = icmp ult i64 %stackaddr860, %v861
  %cv863 = zext i1 %cmp862 to i64
  store i64 %cv863, ptr %slot37, align 8
  %v864 = load i64, ptr %slot37, align 8
  %cond865 = icmp ne i64 %v864, 0
  br i1 %cond865, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v866 = load i64, ptr %slot1, align 8
  %p867 = inttoptr i64 %v866 to ptr
  call void @myl_qbe_fail_frame(ptr %p867) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v868 = load i64, ptr %slot2, align 8
  %v869 = load i64, ptr %slot24, align 8
  %p870 = inttoptr i64 %v869 to ptr
  store i64 %v868, ptr %p870, align 8, !alias.scope !3, !noalias !4
  %v871 = load i64, ptr %slot1, align 8
  %p872 = inttoptr i64 %v871 to ptr
  %call873 = call ptr @myl_qbe_heap(ptr %p872) nomerge, !dbg !112
  %calladdr874 = ptrtoint ptr %call873 to i64
  store i64 %calladdr874, ptr %slot38, align 8
  %v875 = load i64, ptr %slot1, align 8
  %p876 = inttoptr i64 %v875 to ptr
  %call877 = call i64 @myl_qbe_region_mark(ptr %p876) nomerge, !dbg !112
  store i64 %call877, ptr %slot39, align 8
  %v878 = load i64, ptr %slot5, align 8
  %p879 = inttoptr i64 %v878 to ptr
  store i32 0, ptr %p879, align 4, !alias.scope !3, !noalias !4
  %v880 = load i64, ptr %slot6, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i32 0, ptr %p881, align 4, !alias.scope !3, !noalias !4
  %v882 = load i64, ptr %slot7, align 8
  %p883 = inttoptr i64 %v882 to ptr
  store i32 0, ptr %p883, align 4, !alias.scope !3, !noalias !4
  %v884 = load i64, ptr %slot8, align 8
  %p885 = inttoptr i64 %v884 to ptr
  store i32 0, ptr %p885, align 4, !alias.scope !3, !noalias !4
  %v886 = load i64, ptr %slot9, align 8
  %p887 = inttoptr i64 %v886 to ptr
  store i32 0, ptr %p887, align 4, !alias.scope !3, !noalias !4
  %v888 = load i64, ptr %slot10, align 8
  %p889 = inttoptr i64 %v888 to ptr
  store i32 0, ptr %p889, align 4, !alias.scope !3, !noalias !4
  %v890 = load i64, ptr %slot11, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i32 0, ptr %p891, align 4, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot12, align 8
  %p893 = inttoptr i64 %v892 to ptr
  store i32 0, ptr %p893, align 4, !alias.scope !3, !noalias !4
  %v894 = load i64, ptr %slot13, align 8
  %p895 = inttoptr i64 %v894 to ptr
  store i32 0, ptr %p895, align 4, !alias.scope !3, !noalias !4
  %v896 = load i64, ptr %slot14, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i32 0, ptr %p897, align 4, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot15, align 8
  %p899 = inttoptr i64 %v898 to ptr
  store i32 0, ptr %p899, align 4, !alias.scope !3, !noalias !4
  %v900 = load i64, ptr %slot16, align 8
  %p901 = inttoptr i64 %v900 to ptr
  store i32 0, ptr %p901, align 4, !alias.scope !3, !noalias !4
  %v902 = load i64, ptr %slot17, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i32 0, ptr %p903, align 4, !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot18, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i32 0, ptr %p905, align 4, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot6, align 8
  %p907 = inttoptr i64 %v906 to ptr
  store i32 2, ptr %p907, align 4, !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot8, align 8
  %p909 = inttoptr i64 %v908 to ptr
  store i32 2, ptr %p909, align 4, !alias.scope !3, !noalias !4
  %v910 = load i64, ptr %slot10, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i32 2, ptr %p911, align 4, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot12, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i32 2, ptr %p913, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v914 = load i64, ptr %slot24, align 8
  %p915 = inttoptr i64 %v914 to ptr
  %ld916 = load i64, ptr %p915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld916, ptr %slot40, align 8
  %v917 = load i64, ptr %slot40, align 8
  %v918 = load i64, ptr %slot32, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i64 %v917, ptr %p919, align 8, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot32, align 8
  %p921 = inttoptr i64 %v920 to ptr
  %ld922 = load i64, ptr %p921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld922, ptr %slot41, align 8
  %v923 = load i64, ptr %slot13, align 8
  %p924 = inttoptr i64 %v923 to ptr
  %ld925 = load i32, ptr %p924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld925, ptr %slot42, align 8
  %v926 = load i64, ptr %slot14, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i32, ptr %p927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld928, ptr %slot43, align 8
  %v929 = load i32, ptr %slot43, align 8
  %op930 = and i32 %v929, 24
  store i32 %op930, ptr %slot43, align 8
  %v931 = load i32, ptr %slot43, align 8
  %cmp932 = icmp eq i32 %v931, 0
  %cv933 = zext i1 %cmp932 to i32
  store i32 %cv933, ptr %slot44, align 8
  %v934 = load i32, ptr %slot42, align 8
  %v935 = load i32, ptr %slot44, align 8
  %op936 = and i32 %v934, %v935
  store i32 %op936, ptr %slot45, align 8
  %v937 = load i32, ptr %slot45, align 8
  %cv938 = zext i32 %v937 to i64
  %cond939 = icmp ne i64 %cv938, 0
  br i1 %cond939, label %bb_rctake15, label %bb_rccopy15
bb_rctake15:
  %v940 = load i64, ptr %slot23, align 8
  store i64 %v940, ptr %slot46, align 8
  %v941 = load i64, ptr %slot39, align 8
  store i64 %v941, ptr %slot47, align 8
  %v942 = load i64, ptr %slot41, align 8
  %v943 = load i64, ptr %slot46, align 8
  %op944 = sub i64 %v942, %v943
  store i64 %op944, ptr %slot48, align 8
  %v945 = load i64, ptr %slot46, align 8
  %v946 = load i64, ptr %slot41, align 8
  %op947 = sub i64 %v945, %v946
  store i64 %op947, ptr %slot49, align 8
  %v948 = load i64, ptr %slot48, align 8
  %cmp949 = icmp ult i64 %v948, 32
  %cv950 = zext i1 %cmp949 to i32
  store i32 %cv950, ptr %slot50, align 8
  %v951 = load i64, ptr %slot49, align 8
  %cmp952 = icmp ult i64 %v951, 32
  %cv953 = zext i1 %cmp952 to i32
  store i32 %cv953, ptr %slot51, align 8
  %v954 = load i32, ptr %slot50, align 8
  %v955 = load i32, ptr %slot51, align 8
  %op956 = or i32 %v954, %v955
  store i32 %op956, ptr %slot52, align 8
  %v957 = load i32, ptr %slot52, align 8
  %cv958 = zext i32 %v957 to i64
  %cond959 = icmp ne i64 %cv958, 0
  br i1 %cond959, label %bb_rcmoveslow24, label %bb_rcmovecheck24
bb_rcmovecheck24:
  %v960 = load i64, ptr %slot41, align 8
  %op961 = add i64 %v960, 0
  store i64 %op961, ptr %slot53, align 8
  %v962 = load i64, ptr %slot53, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ld964 = load i64, ptr %p963, align 8, !alias.scope !4, !noalias !3
  store i64 %ld964, ptr %slot54, align 8
  %v965 = load i64, ptr %slot54, align 8
  %cmp966 = icmp ne i64 %v965, 0
  %cv967 = zext i1 %cmp966 to i32
  store i32 %cv967, ptr %slot55, align 8
  %v968 = load i32, ptr %slot55, align 8
  %cv969 = zext i32 %v968 to i64
  %cond970 = icmp ne i64 %cv969, 0
  br i1 %cond970, label %bb_rcmoveheader32, label %bb_rcmovenext32
bb_rcmoveheader32:
  %v971 = load i64, ptr %slot54, align 8
  %op972 = sub i64 %v971, 16
  store i64 %op972, ptr %slot56, align 8
  %v973 = load i64, ptr %slot54, align 8
  %p974 = inttoptr i64 %v973 to ptr
  %rgep975 = getelementptr i8, ptr %p974, i64 -16
  %ld976 = load i64, ptr %rgep975, align 8, !alias.scope !9, !noalias !10
  store i64 %ld976, ptr %slot57, align 8
  %v977 = load i64, ptr %slot57, align 8
  %op978 = and i64 %v977, 5764607523034234881
  store i64 %op978, ptr %slot58, align 8
  %v979 = load i64, ptr %slot58, align 8
  %cmp980 = icmp ne i64 %v979, 0
  %cv981 = zext i1 %cmp980 to i32
  store i32 %cv981, ptr %slot59, align 8
  %v982 = load i32, ptr %slot59, align 8
  %cv983 = zext i32 %v982 to i64
  %cond984 = icmp ne i64 %cv983, 0
  br i1 %cond984, label %bb_rcmoveslow24, label %bb_rcmovenext32
bb_rcmovenext32:
  %v985 = load i64, ptr %slot41, align 8
  %v986 = load i64, ptr %slot46, align 8
  %p987 = inttoptr i64 %v985 to ptr
  %p988 = inttoptr i64 %v986 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p988, ptr %p987, i64 32, i1 false), !alias.scope !10000000
  %v989 = load i64, ptr %slot41, align 8
  %p990 = inttoptr i64 %v989 to ptr
  store i64 0, ptr %p990, align 8, !alias.scope !4, !noalias !3
  %v991 = load i64, ptr %slot41, align 8
  %op992 = add i64 %v991, 8
  store i64 %op992, ptr %slot60, align 8
  %v993 = load i64, ptr %slot60, align 8
  %p994 = inttoptr i64 %v993 to ptr
  store i64 0, ptr %p994, align 8, !alias.scope !4, !noalias !3
  %v995 = load i64, ptr %slot41, align 8
  %op996 = add i64 %v995, 16
  store i64 %op996, ptr %slot61, align 8
  %v997 = load i64, ptr %slot61, align 8
  %p998 = inttoptr i64 %v997 to ptr
  store i64 0, ptr %p998, align 8, !alias.scope !4, !noalias !3
  %v999 = load i64, ptr %slot41, align 8
  %op1000 = add i64 %v999, 24
  store i64 %op1000, ptr %slot62, align 8
  %v1001 = load i64, ptr %slot62, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  store i64 0, ptr %p1002, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved24
bb_rcmoveslow24:
  %v1003 = load i64, ptr %slot38, align 8
  %v1004 = load i64, ptr %slot46, align 8
  %v1005 = load i64, ptr %slot41, align 8
  %v1006 = load i64, ptr %slot47, align 8
  %cv1007 = trunc i64 %v1006 to i32
  %call1008 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v1003, i64 %v1004, i64 %v1005, i32 %cv1007) nomerge, !dbg !114
  store i32 %call1008, ptr %slot63, align 8
  %v1009 = load i32, ptr %slot63, align 8
  %cv1010 = zext i32 %v1009 to i64
  %cond1011 = icmp ne i64 %cv1010, 0
  br i1 %cond1011, label %bb_rcsuccess42, label %bb_rcfailure42
bb_rcfailure42:
  %v1012 = load i64, ptr %slot38, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  %call1014 = call i32 @myl_rc_take_failure(ptr %p1013) nomerge, !dbg !114
  store i32 %call1014, ptr %slot64, align 8
  %v1015 = load i64, ptr %slot1, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %v1017 = load i32, ptr %slot64, align 8
  %call1018 = call i32 @myl_qbe_rc_status(ptr %p1016, i32 %v1017) nomerge, !dbg !114
  store i32 %call1018, ptr %slot65, align 8
  br label %bb_failure
bb_rcsuccess42:
  br label %bb_rcmoved24
bb_rcmoved24:
  %v1019 = load i64, ptr %slot13, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  store i32 0, ptr %p1020, align 4, !alias.scope !3, !noalias !4
  %v1021 = load i64, ptr %slot18, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  store i32 2, ptr %p1022, align 4, !alias.scope !3, !noalias !4
  %v1023 = load i64, ptr %slot17, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  store i32 1, ptr %p1024, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared15
bb_rccopy15:
  %v1025 = load i64, ptr %slot23, align 8
  store i64 %v1025, ptr %slot66, align 8
  %v1026 = load i64, ptr %slot39, align 8
  store i64 %v1026, ptr %slot67, align 8
  %v1027 = load i64, ptr %slot38, align 8
  %v1028 = load i64, ptr %slot66, align 8
  %v1029 = load i64, ptr %slot41, align 8
  %v1030 = load i64, ptr %slot67, align 8
  %cv1031 = trunc i64 %v1030 to i32
  %call1032 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v1027, i64 %v1028, i64 %v1029, i32 %cv1031) nomerge, !dbg !114
  store i32 %call1032, ptr %slot68, align 8
  %v1033 = load i32, ptr %slot68, align 8
  %cv1034 = zext i32 %v1033 to i64
  %cond1035 = icmp ne i64 %cv1034, 0
  br i1 %cond1035, label %bb_rcsuccess51, label %bb_rcfailure51
bb_rcfailure51:
  %v1036 = load i64, ptr %slot38, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  %call1038 = call i32 @myl_rc_take_failure(ptr %p1037) nomerge, !dbg !114
  store i32 %call1038, ptr %slot69, align 8
  %v1039 = load i64, ptr %slot1, align 8
  %p1040 = inttoptr i64 %v1039 to ptr
  %v1041 = load i32, ptr %slot69, align 8
  %call1042 = call i32 @myl_qbe_rc_status(ptr %p1040, i32 %v1041) nomerge, !dbg !114
  store i32 %call1042, ptr %slot70, align 8
  br label %bb_failure
bb_rcsuccess51:
  %v1043 = load i64, ptr %slot18, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  store i32 2, ptr %p1044, align 4, !alias.scope !3, !noalias !4
  %v1045 = load i64, ptr %slot17, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  store i32 1, ptr %p1046, align 4, !alias.scope !3, !noalias !4
  %v1047 = load i64, ptr %slot13, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  %ld1049 = load i32, ptr %p1048, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1049, ptr %slot71, align 8
  %v1050 = load i32, ptr %slot71, align 8
  %cv1051 = zext i32 %v1050 to i64
  %cond1052 = icmp ne i64 %cv1051, 0
  br i1 %cond1052, label %bb_rcslotdrop58, label %bb_rcslotdone58
bb_rcslotdrop58:
  %v1053 = load i64, ptr %slot13, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i32 0, ptr %p1054, align 4, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot19, align 8
  store i64 %v1055, ptr %slot72, align 8
  %v1056 = load i64, ptr %slot14, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  %ld1058 = load i32, ptr %p1057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1058, ptr %slot73, align 8
  %v1059 = load i32, ptr %slot73, align 8
  %op1060 = and i32 %v1059, 28
  store i32 %op1060, ptr %slot74, align 8
  %v1061 = load i32, ptr %slot74, align 8
  %cv1062 = zext i32 %v1061 to i64
  %cond1063 = icmp ne i64 %cv1062, 0
  br i1 %cond1063, label %bb_rcslotrole58, label %bb_rcslotowner58
bb_rcslotrole58:
  %v1064 = load i64, ptr %slot38, align 8
  store i64 %v1064, ptr %slot75, align 8
  %v1065 = load i64, ptr %slot75, align 8
  %v1066 = load i64, ptr %slot72, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1065, i64 %v1066) nomerge, !dbg !114
  br label %bb_rcslotdone58
bb_rcslotowner58:
  %v1067 = load i64, ptr %slot72, align 8
  %p1069 = inttoptr i64 %v1067 to ptr
  %gep1070 = getelementptr i8, ptr %p1069, i64 0
  %op1068 = ptrtoint ptr %gep1070 to i64
  store i64 %op1068, ptr %slot76, align 8
  %v1071 = load i64, ptr %slot38, align 8
  store i64 %v1071, ptr %slot77, align 8
  %v1072 = load i64, ptr %slot76, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i64, ptr %p1073, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1074, ptr %slot78, align 8
  %v1075 = load i64, ptr %slot78, align 8
  %cmp1076 = icmp ne i64 %v1075, 0
  %cv1077 = zext i1 %cmp1076 to i32
  store i32 %cv1077, ptr %slot79, align 8
  %v1078 = load i32, ptr %slot79, align 8
  %cv1079 = zext i32 %v1078 to i64
  %cond1080 = icmp ne i64 %cv1079, 0
  br i1 %cond1080, label %bb_rcgnn76, label %bb_rcgdone76
bb_rcgnn76:
  %v1081 = load i64, ptr %slot78, align 8
  %op1082 = sub i64 %v1081, 16
  store i64 %op1082, ptr %slot80, align 8
  %v1083 = load i64, ptr %slot78, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  %rgep1085 = getelementptr i8, ptr %p1084, i64 -16
  %ld1086 = load i64, ptr %rgep1085, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1086, ptr %slot81, align 8
  %v1087 = load i64, ptr %slot81, align 8
  %op1088 = and i64 %v1087, 4611686018427387906
  store i64 %op1088, ptr %slot82, align 8
  %v1089 = load i64, ptr %slot82, align 8
  %cmp1090 = icmp ne i64 %v1089, 0
  %cv1091 = zext i1 %cmp1090 to i32
  store i32 %cv1091, ptr %slot83, align 8
  %v1092 = load i32, ptr %slot83, align 8
  %cv1093 = zext i32 %v1092 to i64
  %cond1094 = icmp ne i64 %cv1093, 0
  br i1 %cond1094, label %bb_rcgclear76, label %bb_rcgcounted76
bb_rcgcounted76:
  %v1095 = load i64, ptr %slot78, align 8
  %op1096 = sub i64 %v1095, 32
  store i64 %op1096, ptr %slot84, align 8
  %v1097 = load i64, ptr %slot78, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  %rgep1099 = getelementptr i8, ptr %p1098, i64 -32
  %ld1100 = load i64, ptr %rgep1099, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1100, ptr %slot85, align 8
  %v1101 = load i64, ptr %slot85, align 8
  %op1102 = sub i64 %v1101, 1
  store i64 %op1102, ptr %slot86, align 8
  %v1103 = load i64, ptr %slot86, align 8
  %cmp1104 = icmp eq i64 %v1103, 0
  %cv1105 = zext i1 %cmp1104 to i32
  store i32 %cv1105, ptr %slot87, align 8
  %v1106 = load i32, ptr %slot87, align 8
  %cv1107 = zext i32 %v1106 to i64
  %cond1108 = icmp ne i64 %cv1107, 0
  br i1 %cond1108, label %bb_rcglast76, label %bb_rcgdec76
bb_rcglast76:
  %v1109 = load i64, ptr %slot78, align 8
  %op1110 = sub i64 %v1109, 24
  store i64 %op1110, ptr %slot88, align 8
  %v1111 = load i64, ptr %slot78, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  %rgep1113 = getelementptr i8, ptr %p1112, i64 -24
  %ld1114 = load i64, ptr %rgep1113, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1114, ptr %slot89, align 8
  %v1115 = load i64, ptr %slot89, align 8
  %cmp1116 = icmp ne i64 %v1115, 0
  %cv1117 = zext i1 %cmp1116 to i32
  store i32 %cv1117, ptr %slot90, align 8
  %v1118 = load i32, ptr %slot90, align 8
  %cv1119 = zext i32 %v1118 to i64
  %cond1120 = icmp ne i64 %cv1119, 0
  br i1 %cond1120, label %bb_rcgdec76, label %bb_rcgslow76
bb_rcgslow76:
  %v1121 = load i64, ptr %slot77, align 8
  %v1122 = load i64, ptr %slot76, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1121, i64 %v1122) nomerge, !dbg !114
  br label %bb_rcgdone76
bb_rcgdec76:
  %v1123 = load i64, ptr %slot86, align 8
  %v1124 = load i64, ptr %slot78, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  %rgep1126 = getelementptr i8, ptr %p1125, i64 -32
  store i64 %v1123, ptr %rgep1126, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear76
bb_rcgclear76:
  %v1127 = load i64, ptr %slot76, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  store i64 0, ptr %p1128, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone76
bb_rcgdone76:
  %v1129 = load i64, ptr %slot72, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  store i64 0, ptr %p1130, align 8, !alias.scope !3, !noalias !4
  %v1131 = load i64, ptr %slot72, align 8
  %p1133 = inttoptr i64 %v1131 to ptr
  %gep1134 = getelementptr i8, ptr %p1133, i64 8
  %op1132 = ptrtoint ptr %gep1134 to i64
  store i64 %op1132, ptr %slot91, align 8
  %v1135 = load i64, ptr %slot91, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  store i64 0, ptr %p1136, align 8, !alias.scope !3, !noalias !4
  %v1137 = load i64, ptr %slot72, align 8
  %p1139 = inttoptr i64 %v1137 to ptr
  %gep1140 = getelementptr i8, ptr %p1139, i64 16
  %op1138 = ptrtoint ptr %gep1140 to i64
  store i64 %op1138, ptr %slot92, align 8
  %v1141 = load i64, ptr %slot92, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  store i64 0, ptr %p1142, align 8, !alias.scope !3, !noalias !4
  %v1143 = load i64, ptr %slot72, align 8
  %p1145 = inttoptr i64 %v1143 to ptr
  %gep1146 = getelementptr i8, ptr %p1145, i64 24
  %op1144 = ptrtoint ptr %gep1146 to i64
  store i64 %op1144, ptr %slot93, align 8
  %v1147 = load i64, ptr %slot93, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  store i64 0, ptr %p1148, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone58
bb_rcslotdone58:
  br label %bb_rcprepared15
bb_rcprepared15:
  %v1149 = load i64, ptr %slot5, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  %ld1151 = load i32, ptr %p1150, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1151, ptr %slot94, align 8
  %v1152 = load i32, ptr %slot94, align 8
  %cv1153 = zext i32 %v1152 to i64
  %cond1154 = icmp ne i64 %cv1153, 0
  br i1 %cond1154, label %bb_rcslotdrop86, label %bb_rcslotdone86
bb_rcslotdrop86:
  %v1155 = load i64, ptr %slot5, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  store i32 0, ptr %p1156, align 4, !alias.scope !3, !noalias !4
  %v1157 = load i64, ptr %slot26, align 8
  store i64 %v1157, ptr %slot95, align 8
  %v1158 = load i64, ptr %slot6, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %ld1160 = load i32, ptr %p1159, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1160, ptr %slot96, align 8
  %v1161 = load i32, ptr %slot96, align 8
  %op1162 = and i32 %v1161, 28
  store i32 %op1162, ptr %slot97, align 8
  %v1163 = load i32, ptr %slot97, align 8
  %cv1164 = zext i32 %v1163 to i64
  %cond1165 = icmp ne i64 %cv1164, 0
  br i1 %cond1165, label %bb_rcslotrole86, label %bb_rcslotowner86
bb_rcslotrole86:
  %v1166 = load i64, ptr %slot38, align 8
  store i64 %v1166, ptr %slot98, align 8
  %v1167 = load i64, ptr %slot98, align 8
  %v1168 = load i64, ptr %slot95, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1167, i64 %v1168) nomerge, !dbg !114
  br label %bb_rcslotdone86
bb_rcslotowner86:
  %v1169 = load i64, ptr %slot95, align 8
  %p1171 = inttoptr i64 %v1169 to ptr
  %gep1172 = getelementptr i8, ptr %p1171, i64 0
  %op1170 = ptrtoint ptr %gep1172 to i64
  store i64 %op1170, ptr %slot99, align 8
  %v1173 = load i64, ptr %slot38, align 8
  store i64 %v1173, ptr %slot100, align 8
  %v1174 = load i64, ptr %slot99, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %ld1176 = load i64, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1176, ptr %slot101, align 8
  %v1177 = load i64, ptr %slot101, align 8
  %cmp1178 = icmp ne i64 %v1177, 0
  %cv1179 = zext i1 %cmp1178 to i32
  store i32 %cv1179, ptr %slot102, align 8
  %v1180 = load i32, ptr %slot102, align 8
  %cv1181 = zext i32 %v1180 to i64
  %cond1182 = icmp ne i64 %cv1181, 0
  br i1 %cond1182, label %bb_rcgnn104, label %bb_rcgdone104
bb_rcgnn104:
  %v1183 = load i64, ptr %slot101, align 8
  %op1184 = sub i64 %v1183, 16
  store i64 %op1184, ptr %slot103, align 8
  %v1185 = load i64, ptr %slot101, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  %rgep1187 = getelementptr i8, ptr %p1186, i64 -16
  %ld1188 = load i64, ptr %rgep1187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1188, ptr %slot104, align 8
  %v1189 = load i64, ptr %slot104, align 8
  %op1190 = and i64 %v1189, 4611686018427387906
  store i64 %op1190, ptr %slot105, align 8
  %v1191 = load i64, ptr %slot105, align 8
  %cmp1192 = icmp ne i64 %v1191, 0
  %cv1193 = zext i1 %cmp1192 to i32
  store i32 %cv1193, ptr %slot106, align 8
  %v1194 = load i32, ptr %slot106, align 8
  %cv1195 = zext i32 %v1194 to i64
  %cond1196 = icmp ne i64 %cv1195, 0
  br i1 %cond1196, label %bb_rcgclear104, label %bb_rcgcounted104
bb_rcgcounted104:
  %v1197 = load i64, ptr %slot101, align 8
  %op1198 = sub i64 %v1197, 32
  store i64 %op1198, ptr %slot107, align 8
  %v1199 = load i64, ptr %slot101, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  %rgep1201 = getelementptr i8, ptr %p1200, i64 -32
  %ld1202 = load i64, ptr %rgep1201, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1202, ptr %slot108, align 8
  %v1203 = load i64, ptr %slot108, align 8
  %op1204 = sub i64 %v1203, 1
  store i64 %op1204, ptr %slot109, align 8
  %v1205 = load i64, ptr %slot109, align 8
  %cmp1206 = icmp eq i64 %v1205, 0
  %cv1207 = zext i1 %cmp1206 to i32
  store i32 %cv1207, ptr %slot110, align 8
  %v1208 = load i32, ptr %slot110, align 8
  %cv1209 = zext i32 %v1208 to i64
  %cond1210 = icmp ne i64 %cv1209, 0
  br i1 %cond1210, label %bb_rcglast104, label %bb_rcgdec104
bb_rcglast104:
  %v1211 = load i64, ptr %slot101, align 8
  %op1212 = sub i64 %v1211, 24
  store i64 %op1212, ptr %slot111, align 8
  %v1213 = load i64, ptr %slot101, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %rgep1215 = getelementptr i8, ptr %p1214, i64 -24
  %ld1216 = load i64, ptr %rgep1215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1216, ptr %slot112, align 8
  %v1217 = load i64, ptr %slot112, align 8
  %cmp1218 = icmp ne i64 %v1217, 0
  %cv1219 = zext i1 %cmp1218 to i32
  store i32 %cv1219, ptr %slot113, align 8
  %v1220 = load i32, ptr %slot113, align 8
  %cv1221 = zext i32 %v1220 to i64
  %cond1222 = icmp ne i64 %cv1221, 0
  br i1 %cond1222, label %bb_rcgdec104, label %bb_rcgslow104
bb_rcgslow104:
  %v1223 = load i64, ptr %slot100, align 8
  %v1224 = load i64, ptr %slot99, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1223, i64 %v1224) nomerge, !dbg !114
  br label %bb_rcgdone104
bb_rcgdec104:
  %v1225 = load i64, ptr %slot109, align 8
  %v1226 = load i64, ptr %slot101, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  %rgep1228 = getelementptr i8, ptr %p1227, i64 -32
  store i64 %v1225, ptr %rgep1228, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear104
bb_rcgclear104:
  %v1229 = load i64, ptr %slot99, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  store i64 0, ptr %p1230, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone104
bb_rcgdone104:
  %v1231 = load i64, ptr %slot95, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  store i64 0, ptr %p1232, align 8, !alias.scope !3, !noalias !4
  %v1233 = load i64, ptr %slot95, align 8
  %p1235 = inttoptr i64 %v1233 to ptr
  %gep1236 = getelementptr i8, ptr %p1235, i64 8
  %op1234 = ptrtoint ptr %gep1236 to i64
  store i64 %op1234, ptr %slot114, align 8
  %v1237 = load i64, ptr %slot114, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  store i64 0, ptr %p1238, align 8, !alias.scope !3, !noalias !4
  %v1239 = load i64, ptr %slot95, align 8
  %p1241 = inttoptr i64 %v1239 to ptr
  %gep1242 = getelementptr i8, ptr %p1241, i64 16
  %op1240 = ptrtoint ptr %gep1242 to i64
  store i64 %op1240, ptr %slot115, align 8
  %v1243 = load i64, ptr %slot115, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  store i64 0, ptr %p1244, align 8, !alias.scope !3, !noalias !4
  %v1245 = load i64, ptr %slot95, align 8
  %p1247 = inttoptr i64 %v1245 to ptr
  %gep1248 = getelementptr i8, ptr %p1247, i64 24
  %op1246 = ptrtoint ptr %gep1248 to i64
  store i64 %op1246, ptr %slot116, align 8
  %v1249 = load i64, ptr %slot116, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  store i64 0, ptr %p1250, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone86
bb_rcslotdone86:
  %v1251 = load i64, ptr %slot26, align 8
  store i64 %v1251, ptr %slot117, align 8
  %v1252 = load i64, ptr %slot23, align 8
  store i64 %v1252, ptr %slot118, align 8
  %v1253 = load i64, ptr %slot118, align 8
  %v1254 = load i64, ptr %slot117, align 8
  %p1255 = inttoptr i64 %v1253 to ptr
  %p1256 = inttoptr i64 %v1254 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1256, ptr %p1255, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1257 = load i64, ptr %slot17, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  store i32 0, ptr %p1258, align 4, !alias.scope !3, !noalias !4
  %v1259 = load i64, ptr %slot6, align 8
  %p1260 = inttoptr i64 %v1259 to ptr
  store i32 2, ptr %p1260, align 4, !alias.scope !3, !noalias !4
  %v1261 = load i64, ptr %slot18, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %ld1263 = load i32, ptr %p1262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1263, ptr %slot119, align 8
  %v1264 = load i32, ptr %slot119, align 8
  %v1265 = load i64, ptr %slot6, align 8
  %p1266 = inttoptr i64 %v1265 to ptr
  store i32 %v1264, ptr %p1266, align 4, !alias.scope !3, !noalias !4
  %v1267 = load i64, ptr %slot5, align 8
  %p1268 = inttoptr i64 %v1267 to ptr
  store i32 1, ptr %p1268, align 4, !alias.scope !3, !noalias !4
  %v1269 = load i64, ptr %slot26, align 8
  %v1270 = load i64, ptr %slot32, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  store i64 %v1269, ptr %p1271, align 8, !alias.scope !3, !noalias !4
  %v1272 = load i64, ptr %slot32, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  %ld1274 = load i64, ptr %p1273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1274, ptr %slot120, align 8
  %v1275 = load i64, ptr %slot13, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  %ld1277 = load i32, ptr %p1276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1277, ptr %slot121, align 8
  %v1278 = load i64, ptr %slot14, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  %ld1280 = load i32, ptr %p1279, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1280, ptr %slot122, align 8
  %v1281 = load i32, ptr %slot122, align 8
  %op1282 = and i32 %v1281, 24
  store i32 %op1282, ptr %slot122, align 8
  %v1283 = load i32, ptr %slot122, align 8
  %cmp1284 = icmp eq i32 %v1283, 0
  %cv1285 = zext i1 %cmp1284 to i32
  store i32 %cv1285, ptr %slot123, align 8
  %v1286 = load i32, ptr %slot121, align 8
  %v1287 = load i32, ptr %slot123, align 8
  %op1288 = and i32 %v1286, %v1287
  store i32 %op1288, ptr %slot124, align 8
  %v1289 = load i32, ptr %slot124, align 8
  %cv1290 = zext i32 %v1289 to i64
  %cond1291 = icmp ne i64 %cv1290, 0
  br i1 %cond1291, label %bb_rctake119, label %bb_rccopy119
bb_rctake119:
  %v1292 = load i64, ptr %slot23, align 8
  store i64 %v1292, ptr %slot125, align 8
  %v1293 = load i64, ptr %slot39, align 8
  store i64 %v1293, ptr %slot126, align 8
  %v1294 = load i64, ptr %slot120, align 8
  %v1295 = load i64, ptr %slot125, align 8
  %op1296 = sub i64 %v1294, %v1295
  store i64 %op1296, ptr %slot127, align 8
  %v1297 = load i64, ptr %slot125, align 8
  %v1298 = load i64, ptr %slot120, align 8
  %op1299 = sub i64 %v1297, %v1298
  store i64 %op1299, ptr %slot128, align 8
  %v1300 = load i64, ptr %slot127, align 8
  %cmp1301 = icmp ult i64 %v1300, 32
  %cv1302 = zext i1 %cmp1301 to i32
  store i32 %cv1302, ptr %slot129, align 8
  %v1303 = load i64, ptr %slot128, align 8
  %cmp1304 = icmp ult i64 %v1303, 32
  %cv1305 = zext i1 %cmp1304 to i32
  store i32 %cv1305, ptr %slot130, align 8
  %v1306 = load i32, ptr %slot129, align 8
  %v1307 = load i32, ptr %slot130, align 8
  %op1308 = or i32 %v1306, %v1307
  store i32 %op1308, ptr %slot131, align 8
  %v1309 = load i32, ptr %slot131, align 8
  %cv1310 = zext i32 %v1309 to i64
  %cond1311 = icmp ne i64 %cv1310, 0
  br i1 %cond1311, label %bb_rcmoveslow128, label %bb_rcmovecheck128
bb_rcmovecheck128:
  %v1312 = load i64, ptr %slot120, align 8
  %op1313 = add i64 %v1312, 0
  store i64 %op1313, ptr %slot132, align 8
  %v1314 = load i64, ptr %slot132, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %ld1316 = load i64, ptr %p1315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1316, ptr %slot133, align 8
  %v1317 = load i64, ptr %slot133, align 8
  %cmp1318 = icmp ne i64 %v1317, 0
  %cv1319 = zext i1 %cmp1318 to i32
  store i32 %cv1319, ptr %slot134, align 8
  %v1320 = load i32, ptr %slot134, align 8
  %cv1321 = zext i32 %v1320 to i64
  %cond1322 = icmp ne i64 %cv1321, 0
  br i1 %cond1322, label %bb_rcmoveheader136, label %bb_rcmovenext136
bb_rcmoveheader136:
  %v1323 = load i64, ptr %slot133, align 8
  %op1324 = sub i64 %v1323, 16
  store i64 %op1324, ptr %slot135, align 8
  %v1325 = load i64, ptr %slot133, align 8
  %p1326 = inttoptr i64 %v1325 to ptr
  %rgep1327 = getelementptr i8, ptr %p1326, i64 -16
  %ld1328 = load i64, ptr %rgep1327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1328, ptr %slot136, align 8
  %v1329 = load i64, ptr %slot136, align 8
  %op1330 = and i64 %v1329, 5764607523034234881
  store i64 %op1330, ptr %slot137, align 8
  %v1331 = load i64, ptr %slot137, align 8
  %cmp1332 = icmp ne i64 %v1331, 0
  %cv1333 = zext i1 %cmp1332 to i32
  store i32 %cv1333, ptr %slot138, align 8
  %v1334 = load i32, ptr %slot138, align 8
  %cv1335 = zext i32 %v1334 to i64
  %cond1336 = icmp ne i64 %cv1335, 0
  br i1 %cond1336, label %bb_rcmoveslow128, label %bb_rcmovenext136
bb_rcmovenext136:
  %v1337 = load i64, ptr %slot120, align 8
  %v1338 = load i64, ptr %slot125, align 8
  %p1339 = inttoptr i64 %v1337 to ptr
  %p1340 = inttoptr i64 %v1338 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1340, ptr %p1339, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot120, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  store i64 0, ptr %p1342, align 8, !alias.scope !3, !noalias !4
  %v1343 = load i64, ptr %slot120, align 8
  %op1344 = add i64 %v1343, 8
  store i64 %op1344, ptr %slot139, align 8
  %v1345 = load i64, ptr %slot139, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  store i64 0, ptr %p1346, align 8, !alias.scope !3, !noalias !4
  %v1347 = load i64, ptr %slot120, align 8
  %op1348 = add i64 %v1347, 16
  store i64 %op1348, ptr %slot140, align 8
  %v1349 = load i64, ptr %slot140, align 8
  %p1350 = inttoptr i64 %v1349 to ptr
  store i64 0, ptr %p1350, align 8, !alias.scope !3, !noalias !4
  %v1351 = load i64, ptr %slot120, align 8
  %op1352 = add i64 %v1351, 24
  store i64 %op1352, ptr %slot141, align 8
  %v1353 = load i64, ptr %slot141, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  store i64 0, ptr %p1354, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved128
bb_rcmoveslow128:
  %v1355 = load i64, ptr %slot38, align 8
  %v1356 = load i64, ptr %slot125, align 8
  %v1357 = load i64, ptr %slot120, align 8
  %v1358 = load i64, ptr %slot126, align 8
  %cv1359 = trunc i64 %v1358 to i32
  %call1360 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v1355, i64 %v1356, i64 %v1357, i32 %cv1359) nomerge, !dbg !116
  store i32 %call1360, ptr %slot142, align 8
  %v1361 = load i32, ptr %slot142, align 8
  %cv1362 = zext i32 %v1361 to i64
  %cond1363 = icmp ne i64 %cv1362, 0
  br i1 %cond1363, label %bb_rcsuccess146, label %bb_rcfailure146
bb_rcfailure146:
  %v1364 = load i64, ptr %slot38, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  %call1366 = call i32 @myl_rc_take_failure(ptr %p1365) nomerge, !dbg !116
  store i32 %call1366, ptr %slot143, align 8
  %v1367 = load i64, ptr %slot1, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  %v1369 = load i32, ptr %slot143, align 8
  %call1370 = call i32 @myl_qbe_rc_status(ptr %p1368, i32 %v1369) nomerge, !dbg !116
  store i32 %call1370, ptr %slot144, align 8
  br label %bb_failure
bb_rcsuccess146:
  br label %bb_rcmoved128
bb_rcmoved128:
  %v1371 = load i64, ptr %slot13, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i32 0, ptr %p1372, align 4, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot18, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i32 2, ptr %p1374, align 4, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot17, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i32 1, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared119
bb_rccopy119:
  %v1377 = load i64, ptr %slot23, align 8
  store i64 %v1377, ptr %slot145, align 8
  %v1378 = load i64, ptr %slot39, align 8
  store i64 %v1378, ptr %slot146, align 8
  %v1379 = load i64, ptr %slot38, align 8
  %v1380 = load i64, ptr %slot145, align 8
  %v1381 = load i64, ptr %slot120, align 8
  %v1382 = load i64, ptr %slot146, align 8
  %cv1383 = trunc i64 %v1382 to i32
  %call1384 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v1379, i64 %v1380, i64 %v1381, i32 %cv1383) nomerge, !dbg !116
  store i32 %call1384, ptr %slot147, align 8
  %v1385 = load i32, ptr %slot147, align 8
  %cv1386 = zext i32 %v1385 to i64
  %cond1387 = icmp ne i64 %cv1386, 0
  br i1 %cond1387, label %bb_rcsuccess155, label %bb_rcfailure155
bb_rcfailure155:
  %v1388 = load i64, ptr %slot38, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %call1390 = call i32 @myl_rc_take_failure(ptr %p1389) nomerge, !dbg !116
  store i32 %call1390, ptr %slot148, align 8
  %v1391 = load i64, ptr %slot1, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %v1393 = load i32, ptr %slot148, align 8
  %call1394 = call i32 @myl_qbe_rc_status(ptr %p1392, i32 %v1393) nomerge, !dbg !116
  store i32 %call1394, ptr %slot149, align 8
  br label %bb_failure
bb_rcsuccess155:
  %v1395 = load i64, ptr %slot18, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  store i32 2, ptr %p1396, align 4, !alias.scope !3, !noalias !4
  %v1397 = load i64, ptr %slot17, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i32 1, ptr %p1398, align 4, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot13, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %ld1401 = load i32, ptr %p1400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1401, ptr %slot150, align 8
  %v1402 = load i32, ptr %slot150, align 8
  %cv1403 = zext i32 %v1402 to i64
  %cond1404 = icmp ne i64 %cv1403, 0
  br i1 %cond1404, label %bb_rcslotdrop162, label %bb_rcslotdone162
bb_rcslotdrop162:
  %v1405 = load i64, ptr %slot13, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  store i32 0, ptr %p1406, align 4, !alias.scope !3, !noalias !4
  %v1407 = load i64, ptr %slot19, align 8
  store i64 %v1407, ptr %slot151, align 8
  %v1408 = load i64, ptr %slot14, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i32, ptr %p1409, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1410, ptr %slot152, align 8
  %v1411 = load i32, ptr %slot152, align 8
  %op1412 = and i32 %v1411, 28
  store i32 %op1412, ptr %slot153, align 8
  %v1413 = load i32, ptr %slot153, align 8
  %cv1414 = zext i32 %v1413 to i64
  %cond1415 = icmp ne i64 %cv1414, 0
  br i1 %cond1415, label %bb_rcslotrole162, label %bb_rcslotowner162
bb_rcslotrole162:
  %v1416 = load i64, ptr %slot38, align 8
  store i64 %v1416, ptr %slot154, align 8
  %v1417 = load i64, ptr %slot154, align 8
  %v1418 = load i64, ptr %slot151, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1417, i64 %v1418) nomerge, !dbg !116
  br label %bb_rcslotdone162
bb_rcslotowner162:
  %v1419 = load i64, ptr %slot151, align 8
  %p1421 = inttoptr i64 %v1419 to ptr
  %gep1422 = getelementptr i8, ptr %p1421, i64 0
  %op1420 = ptrtoint ptr %gep1422 to i64
  store i64 %op1420, ptr %slot155, align 8
  %v1423 = load i64, ptr %slot38, align 8
  store i64 %v1423, ptr %slot156, align 8
  %v1424 = load i64, ptr %slot155, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  %ld1426 = load i64, ptr %p1425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1426, ptr %slot157, align 8
  %v1427 = load i64, ptr %slot157, align 8
  %cmp1428 = icmp ne i64 %v1427, 0
  %cv1429 = zext i1 %cmp1428 to i32
  store i32 %cv1429, ptr %slot158, align 8
  %v1430 = load i32, ptr %slot158, align 8
  %cv1431 = zext i32 %v1430 to i64
  %cond1432 = icmp ne i64 %cv1431, 0
  br i1 %cond1432, label %bb_rcgnn180, label %bb_rcgdone180
bb_rcgnn180:
  %v1433 = load i64, ptr %slot157, align 8
  %op1434 = sub i64 %v1433, 16
  store i64 %op1434, ptr %slot159, align 8
  %v1435 = load i64, ptr %slot157, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  %rgep1437 = getelementptr i8, ptr %p1436, i64 -16
  %ld1438 = load i64, ptr %rgep1437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1438, ptr %slot160, align 8
  %v1439 = load i64, ptr %slot160, align 8
  %op1440 = and i64 %v1439, 4611686018427387906
  store i64 %op1440, ptr %slot161, align 8
  %v1441 = load i64, ptr %slot161, align 8
  %cmp1442 = icmp ne i64 %v1441, 0
  %cv1443 = zext i1 %cmp1442 to i32
  store i32 %cv1443, ptr %slot162, align 8
  %v1444 = load i32, ptr %slot162, align 8
  %cv1445 = zext i32 %v1444 to i64
  %cond1446 = icmp ne i64 %cv1445, 0
  br i1 %cond1446, label %bb_rcgclear180, label %bb_rcgcounted180
bb_rcgcounted180:
  %v1447 = load i64, ptr %slot157, align 8
  %op1448 = sub i64 %v1447, 32
  store i64 %op1448, ptr %slot163, align 8
  %v1449 = load i64, ptr %slot157, align 8
  %p1450 = inttoptr i64 %v1449 to ptr
  %rgep1451 = getelementptr i8, ptr %p1450, i64 -32
  %ld1452 = load i64, ptr %rgep1451, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1452, ptr %slot164, align 8
  %v1453 = load i64, ptr %slot164, align 8
  %op1454 = sub i64 %v1453, 1
  store i64 %op1454, ptr %slot165, align 8
  %v1455 = load i64, ptr %slot165, align 8
  %cmp1456 = icmp eq i64 %v1455, 0
  %cv1457 = zext i1 %cmp1456 to i32
  store i32 %cv1457, ptr %slot166, align 8
  %v1458 = load i32, ptr %slot166, align 8
  %cv1459 = zext i32 %v1458 to i64
  %cond1460 = icmp ne i64 %cv1459, 0
  br i1 %cond1460, label %bb_rcglast180, label %bb_rcgdec180
bb_rcglast180:
  %v1461 = load i64, ptr %slot157, align 8
  %op1462 = sub i64 %v1461, 24
  store i64 %op1462, ptr %slot167, align 8
  %v1463 = load i64, ptr %slot157, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  %rgep1465 = getelementptr i8, ptr %p1464, i64 -24
  %ld1466 = load i64, ptr %rgep1465, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1466, ptr %slot168, align 8
  %v1467 = load i64, ptr %slot168, align 8
  %cmp1468 = icmp ne i64 %v1467, 0
  %cv1469 = zext i1 %cmp1468 to i32
  store i32 %cv1469, ptr %slot169, align 8
  %v1470 = load i32, ptr %slot169, align 8
  %cv1471 = zext i32 %v1470 to i64
  %cond1472 = icmp ne i64 %cv1471, 0
  br i1 %cond1472, label %bb_rcgdec180, label %bb_rcgslow180
bb_rcgslow180:
  %v1473 = load i64, ptr %slot156, align 8
  %v1474 = load i64, ptr %slot155, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1473, i64 %v1474) nomerge, !dbg !116
  br label %bb_rcgdone180
bb_rcgdec180:
  %v1475 = load i64, ptr %slot165, align 8
  %v1476 = load i64, ptr %slot157, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  %rgep1478 = getelementptr i8, ptr %p1477, i64 -32
  store i64 %v1475, ptr %rgep1478, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear180
bb_rcgclear180:
  %v1479 = load i64, ptr %slot155, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  store i64 0, ptr %p1480, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone180
bb_rcgdone180:
  %v1481 = load i64, ptr %slot151, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i64 0, ptr %p1482, align 8, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot151, align 8
  %p1485 = inttoptr i64 %v1483 to ptr
  %gep1486 = getelementptr i8, ptr %p1485, i64 8
  %op1484 = ptrtoint ptr %gep1486 to i64
  store i64 %op1484, ptr %slot170, align 8
  %v1487 = load i64, ptr %slot170, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  store i64 0, ptr %p1488, align 8, !alias.scope !3, !noalias !4
  %v1489 = load i64, ptr %slot151, align 8
  %p1491 = inttoptr i64 %v1489 to ptr
  %gep1492 = getelementptr i8, ptr %p1491, i64 16
  %op1490 = ptrtoint ptr %gep1492 to i64
  store i64 %op1490, ptr %slot171, align 8
  %v1493 = load i64, ptr %slot171, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  store i64 0, ptr %p1494, align 8, !alias.scope !3, !noalias !4
  %v1495 = load i64, ptr %slot151, align 8
  %p1497 = inttoptr i64 %v1495 to ptr
  %gep1498 = getelementptr i8, ptr %p1497, i64 24
  %op1496 = ptrtoint ptr %gep1498 to i64
  store i64 %op1496, ptr %slot172, align 8
  %v1499 = load i64, ptr %slot172, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  store i64 0, ptr %p1500, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone162
bb_rcslotdone162:
  br label %bb_rcprepared119
bb_rcprepared119:
  %v1501 = load i64, ptr %slot7, align 8
  %p1502 = inttoptr i64 %v1501 to ptr
  %ld1503 = load i32, ptr %p1502, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1503, ptr %slot173, align 8
  %v1504 = load i32, ptr %slot173, align 8
  %cv1505 = zext i32 %v1504 to i64
  %cond1506 = icmp ne i64 %cv1505, 0
  br i1 %cond1506, label %bb_rcslotdrop190, label %bb_rcslotdone190
bb_rcslotdrop190:
  %v1507 = load i64, ptr %slot7, align 8
  %p1508 = inttoptr i64 %v1507 to ptr
  store i32 0, ptr %p1508, align 4, !alias.scope !3, !noalias !4
  %v1509 = load i64, ptr %slot27, align 8
  store i64 %v1509, ptr %slot174, align 8
  %v1510 = load i64, ptr %slot8, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  %ld1512 = load i32, ptr %p1511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1512, ptr %slot175, align 8
  %v1513 = load i32, ptr %slot175, align 8
  %op1514 = and i32 %v1513, 28
  store i32 %op1514, ptr %slot176, align 8
  %v1515 = load i32, ptr %slot176, align 8
  %cv1516 = zext i32 %v1515 to i64
  %cond1517 = icmp ne i64 %cv1516, 0
  br i1 %cond1517, label %bb_rcslotrole190, label %bb_rcslotowner190
bb_rcslotrole190:
  %v1518 = load i64, ptr %slot38, align 8
  store i64 %v1518, ptr %slot177, align 8
  %v1519 = load i64, ptr %slot177, align 8
  %v1520 = load i64, ptr %slot174, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1519, i64 %v1520) nomerge, !dbg !116
  br label %bb_rcslotdone190
bb_rcslotowner190:
  %v1521 = load i64, ptr %slot174, align 8
  %p1523 = inttoptr i64 %v1521 to ptr
  %gep1524 = getelementptr i8, ptr %p1523, i64 0
  %op1522 = ptrtoint ptr %gep1524 to i64
  store i64 %op1522, ptr %slot178, align 8
  %v1525 = load i64, ptr %slot38, align 8
  store i64 %v1525, ptr %slot179, align 8
  %v1526 = load i64, ptr %slot178, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  %ld1528 = load i64, ptr %p1527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1528, ptr %slot180, align 8
  %v1529 = load i64, ptr %slot180, align 8
  %cmp1530 = icmp ne i64 %v1529, 0
  %cv1531 = zext i1 %cmp1530 to i32
  store i32 %cv1531, ptr %slot181, align 8
  %v1532 = load i32, ptr %slot181, align 8
  %cv1533 = zext i32 %v1532 to i64
  %cond1534 = icmp ne i64 %cv1533, 0
  br i1 %cond1534, label %bb_rcgnn208, label %bb_rcgdone208
bb_rcgnn208:
  %v1535 = load i64, ptr %slot180, align 8
  %op1536 = sub i64 %v1535, 16
  store i64 %op1536, ptr %slot182, align 8
  %v1537 = load i64, ptr %slot180, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  %rgep1539 = getelementptr i8, ptr %p1538, i64 -16
  %ld1540 = load i64, ptr %rgep1539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1540, ptr %slot183, align 8
  %v1541 = load i64, ptr %slot183, align 8
  %op1542 = and i64 %v1541, 4611686018427387906
  store i64 %op1542, ptr %slot184, align 8
  %v1543 = load i64, ptr %slot184, align 8
  %cmp1544 = icmp ne i64 %v1543, 0
  %cv1545 = zext i1 %cmp1544 to i32
  store i32 %cv1545, ptr %slot185, align 8
  %v1546 = load i32, ptr %slot185, align 8
  %cv1547 = zext i32 %v1546 to i64
  %cond1548 = icmp ne i64 %cv1547, 0
  br i1 %cond1548, label %bb_rcgclear208, label %bb_rcgcounted208
bb_rcgcounted208:
  %v1549 = load i64, ptr %slot180, align 8
  %op1550 = sub i64 %v1549, 32
  store i64 %op1550, ptr %slot186, align 8
  %v1551 = load i64, ptr %slot180, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %rgep1553 = getelementptr i8, ptr %p1552, i64 -32
  %ld1554 = load i64, ptr %rgep1553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1554, ptr %slot187, align 8
  %v1555 = load i64, ptr %slot187, align 8
  %op1556 = sub i64 %v1555, 1
  store i64 %op1556, ptr %slot188, align 8
  %v1557 = load i64, ptr %slot188, align 8
  %cmp1558 = icmp eq i64 %v1557, 0
  %cv1559 = zext i1 %cmp1558 to i32
  store i32 %cv1559, ptr %slot189, align 8
  %v1560 = load i32, ptr %slot189, align 8
  %cv1561 = zext i32 %v1560 to i64
  %cond1562 = icmp ne i64 %cv1561, 0
  br i1 %cond1562, label %bb_rcglast208, label %bb_rcgdec208
bb_rcglast208:
  %v1563 = load i64, ptr %slot180, align 8
  %op1564 = sub i64 %v1563, 24
  store i64 %op1564, ptr %slot190, align 8
  %v1565 = load i64, ptr %slot180, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  %rgep1567 = getelementptr i8, ptr %p1566, i64 -24
  %ld1568 = load i64, ptr %rgep1567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1568, ptr %slot191, align 8
  %v1569 = load i64, ptr %slot191, align 8
  %cmp1570 = icmp ne i64 %v1569, 0
  %cv1571 = zext i1 %cmp1570 to i32
  store i32 %cv1571, ptr %slot192, align 8
  %v1572 = load i32, ptr %slot192, align 8
  %cv1573 = zext i32 %v1572 to i64
  %cond1574 = icmp ne i64 %cv1573, 0
  br i1 %cond1574, label %bb_rcgdec208, label %bb_rcgslow208
bb_rcgslow208:
  %v1575 = load i64, ptr %slot179, align 8
  %v1576 = load i64, ptr %slot178, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1575, i64 %v1576) nomerge, !dbg !116
  br label %bb_rcgdone208
bb_rcgdec208:
  %v1577 = load i64, ptr %slot188, align 8
  %v1578 = load i64, ptr %slot180, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  %rgep1580 = getelementptr i8, ptr %p1579, i64 -32
  store i64 %v1577, ptr %rgep1580, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear208
bb_rcgclear208:
  %v1581 = load i64, ptr %slot178, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  store i64 0, ptr %p1582, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone208
bb_rcgdone208:
  %v1583 = load i64, ptr %slot174, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  store i64 0, ptr %p1584, align 8, !alias.scope !3, !noalias !4
  %v1585 = load i64, ptr %slot174, align 8
  %p1587 = inttoptr i64 %v1585 to ptr
  %gep1588 = getelementptr i8, ptr %p1587, i64 8
  %op1586 = ptrtoint ptr %gep1588 to i64
  store i64 %op1586, ptr %slot193, align 8
  %v1589 = load i64, ptr %slot193, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  store i64 0, ptr %p1590, align 8, !alias.scope !3, !noalias !4
  %v1591 = load i64, ptr %slot174, align 8
  %p1593 = inttoptr i64 %v1591 to ptr
  %gep1594 = getelementptr i8, ptr %p1593, i64 16
  %op1592 = ptrtoint ptr %gep1594 to i64
  store i64 %op1592, ptr %slot194, align 8
  %v1595 = load i64, ptr %slot194, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  store i64 0, ptr %p1596, align 8, !alias.scope !3, !noalias !4
  %v1597 = load i64, ptr %slot174, align 8
  %p1599 = inttoptr i64 %v1597 to ptr
  %gep1600 = getelementptr i8, ptr %p1599, i64 24
  %op1598 = ptrtoint ptr %gep1600 to i64
  store i64 %op1598, ptr %slot195, align 8
  %v1601 = load i64, ptr %slot195, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  store i64 0, ptr %p1602, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone190
bb_rcslotdone190:
  %v1603 = load i64, ptr %slot27, align 8
  store i64 %v1603, ptr %slot196, align 8
  %v1604 = load i64, ptr %slot23, align 8
  store i64 %v1604, ptr %slot197, align 8
  %v1605 = load i64, ptr %slot197, align 8
  %v1606 = load i64, ptr %slot196, align 8
  %p1607 = inttoptr i64 %v1605 to ptr
  %p1608 = inttoptr i64 %v1606 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1608, ptr %p1607, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1609 = load i64, ptr %slot17, align 8
  %p1610 = inttoptr i64 %v1609 to ptr
  store i32 0, ptr %p1610, align 4, !alias.scope !3, !noalias !4
  %v1611 = load i64, ptr %slot8, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  store i32 2, ptr %p1612, align 4, !alias.scope !3, !noalias !4
  %v1613 = load i64, ptr %slot18, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  %ld1615 = load i32, ptr %p1614, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1615, ptr %slot198, align 8
  %v1616 = load i32, ptr %slot198, align 8
  %v1617 = load i64, ptr %slot8, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  store i32 %v1616, ptr %p1618, align 4, !alias.scope !3, !noalias !4
  %v1619 = load i64, ptr %slot7, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  store i32 1, ptr %p1620, align 4, !alias.scope !3, !noalias !4
  %v1621 = load i64, ptr %slot27, align 8
  %v1622 = load i64, ptr %slot32, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i64 %v1621, ptr %p1623, align 8, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot32, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  %ld1626 = load i64, ptr %p1625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1626, ptr %slot199, align 8
  %v1627 = load i64, ptr %slot199, align 8
  %op1628 = add i64 %v1627, 16
  store i64 %op1628, ptr %slot200, align 8
  %v1629 = load i64, ptr %slot200, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  %ld1631 = load i64, ptr %p1630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1631, ptr %slot201, align 8
  %v1632 = load i64, ptr %slot201, align 8
  %v1633 = load i64, ptr %slot32, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  store i64 %v1632, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  %v1635 = load i64, ptr %slot13, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %ld1637 = load i32, ptr %p1636, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1637, ptr %slot202, align 8
  %v1638 = load i32, ptr %slot202, align 8
  %cv1639 = zext i32 %v1638 to i64
  %cond1640 = icmp ne i64 %cv1639, 0
  br i1 %cond1640, label %bb_rcslotdrop227, label %bb_rcslotdone227
bb_rcslotdrop227:
  %v1641 = load i64, ptr %slot13, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  store i32 0, ptr %p1642, align 4, !alias.scope !3, !noalias !4
  %v1643 = load i64, ptr %slot19, align 8
  store i64 %v1643, ptr %slot203, align 8
  %v1644 = load i64, ptr %slot14, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  %ld1646 = load i32, ptr %p1645, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1646, ptr %slot204, align 8
  %v1647 = load i32, ptr %slot204, align 8
  %op1648 = and i32 %v1647, 28
  store i32 %op1648, ptr %slot205, align 8
  %v1649 = load i32, ptr %slot205, align 8
  %cv1650 = zext i32 %v1649 to i64
  %cond1651 = icmp ne i64 %cv1650, 0
  br i1 %cond1651, label %bb_rcslotrole227, label %bb_rcslotowner227
bb_rcslotrole227:
  %v1652 = load i64, ptr %slot38, align 8
  store i64 %v1652, ptr %slot206, align 8
  %v1653 = load i64, ptr %slot206, align 8
  %v1654 = load i64, ptr %slot203, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1653, i64 %v1654) nomerge, !dbg !118
  br label %bb_rcslotdone227
bb_rcslotowner227:
  %v1655 = load i64, ptr %slot38, align 8
  store i64 %v1655, ptr %slot207, align 8
  %v1656 = load i64, ptr %slot207, align 8
  %v1657 = load i64, ptr %slot203, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v1656, i64 %v1657) nomerge, !dbg !118
  br label %bb_rcslotdone227
bb_rcslotdone227:
  %v1658 = load i64, ptr %slot27, align 8
  %v1659 = load i64, ptr %slot33, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i64 %v1658, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot33, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  %ld1663 = load i64, ptr %p1662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1663, ptr %slot208, align 8
  %v1664 = load i64, ptr %slot208, align 8
  %op1665 = add i64 %v1664, 0
  store i64 %op1665, ptr %slot209, align 8
  %v1666 = load i64, ptr %slot209, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  %ld1668 = load i64, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1668, ptr %slot210, align 8
  %v1669 = load i64, ptr %slot210, align 8
  %v1670 = load i64, ptr %slot33, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  store i64 %v1669, ptr %p1671, align 8, !alias.scope !3, !noalias !4
  %v1672 = load i64, ptr %slot33, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %ld1674 = load i64, ptr %p1673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1674, ptr %slot211, align 8
  %v1675 = load i64, ptr %slot211, align 8
  %v1676 = load i64, ptr %slot22, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  store i64 %v1675, ptr %p1677, align 8, !alias.scope !3, !noalias !4
  %v1678 = load i64, ptr %slot22, align 8
  store i64 %v1678, ptr %slot212, align 8
  %v1679 = load i64, ptr %slot23, align 8
  store i64 %v1679, ptr %slot213, align 8
  %v1680 = load i64, ptr %slot212, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  %ld1682 = load i64, ptr %p1681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1682, ptr %slot214, align 8
  %v1683 = load i64, ptr %slot214, align 8
  %cmp1684 = icmp ne i64 %v1683, 0
  %cv1685 = zext i1 %cmp1684 to i32
  store i32 %cv1685, ptr %slot215, align 8
  %v1686 = load i32, ptr %slot215, align 8
  %cv1687 = zext i32 %v1686 to i64
  %cond1688 = icmp ne i64 %cv1687, 0
  br i1 %cond1688, label %bb_rcgnn241, label %bb_rcgstore241
bb_rcgnn241:
  %v1689 = load i64, ptr %slot214, align 8
  %op1690 = sub i64 %v1689, 16
  store i64 %op1690, ptr %slot216, align 8
  %v1691 = load i64, ptr %slot214, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %rgep1693 = getelementptr i8, ptr %p1692, i64 -16
  %ld1694 = load i64, ptr %rgep1693, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1694, ptr %slot217, align 8
  %v1695 = load i64, ptr %slot217, align 8
  %op1696 = and i64 %v1695, 4611686018427387906
  store i64 %op1696, ptr %slot218, align 8
  %v1697 = load i64, ptr %slot218, align 8
  %cmp1698 = icmp ne i64 %v1697, 0
  %cv1699 = zext i1 %cmp1698 to i32
  store i32 %cv1699, ptr %slot219, align 8
  %v1700 = load i32, ptr %slot219, align 8
  %cv1701 = zext i32 %v1700 to i64
  %cond1702 = icmp ne i64 %cv1701, 0
  br i1 %cond1702, label %bb_rcgstore241, label %bb_rcginc241
bb_rcginc241:
  %v1703 = load i64, ptr %slot214, align 8
  %op1704 = sub i64 %v1703, 24
  store i64 %op1704, ptr %slot220, align 8
  %v1705 = load i64, ptr %slot214, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %rgep1707 = getelementptr i8, ptr %p1706, i64 -24
  %ld1708 = load i64, ptr %rgep1707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1708, ptr %slot221, align 8
  %v1709 = load i64, ptr %slot221, align 8
  %op1710 = add i64 %v1709, 1
  store i64 %op1710, ptr %slot222, align 8
  %v1711 = load i64, ptr %slot222, align 8
  %cmp1712 = icmp eq i64 %v1711, 0
  %cv1713 = zext i1 %cmp1712 to i32
  store i32 %cv1713, ptr %slot223, align 8
  %v1714 = load i32, ptr %slot223, align 8
  %cv1715 = zext i32 %v1714 to i64
  %cond1716 = icmp ne i64 %cv1715, 0
  br i1 %cond1716, label %bb_rcglimit241, label %bb_rcgcapacity241
bb_rcglimit241:
  %v1717 = load i64, ptr %slot1, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %call1719 = call i32 @myl_qbe_rc_status(ptr %p1718, i32 2) nomerge, !dbg !120
  store i32 %call1719, ptr %slot224, align 8
  br label %bb_failure
bb_rcgcapacity241:
  %v1720 = load i64, ptr %slot222, align 8
  %v1721 = load i64, ptr %slot214, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  %rgep1723 = getelementptr i8, ptr %p1722, i64 -24
  store i64 %v1720, ptr %rgep1723, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore241
bb_rcgstore241:
  %v1724 = load i64, ptr %slot214, align 8
  %v1725 = load i64, ptr %slot213, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i64 %v1724, ptr %p1726, align 8, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot18, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i32 2, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  %v1729 = load i64, ptr %slot18, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i32 16, ptr %p1730, align 4, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot17, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i32 1, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  %v1733 = load i64, ptr %slot15, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  %ld1735 = load i32, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1735, ptr %slot225, align 8
  %v1736 = load i32, ptr %slot225, align 8
  %cv1737 = zext i32 %v1736 to i64
  %cond1738 = icmp ne i64 %cv1737, 0
  br i1 %cond1738, label %bb_rcslotdrop257, label %bb_rcslotdone257
bb_rcslotdrop257:
  %v1739 = load i64, ptr %slot15, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i32 0, ptr %p1740, align 4, !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot20, align 8
  store i64 %v1741, ptr %slot226, align 8
  %v1742 = load i64, ptr %slot16, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %ld1744 = load i32, ptr %p1743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1744, ptr %slot227, align 8
  %v1745 = load i32, ptr %slot227, align 8
  %op1746 = and i32 %v1745, 28
  store i32 %op1746, ptr %slot228, align 8
  %v1747 = load i32, ptr %slot228, align 8
  %cv1748 = zext i32 %v1747 to i64
  %cond1749 = icmp ne i64 %cv1748, 0
  br i1 %cond1749, label %bb_rcslotrole257, label %bb_rcslotowner257
bb_rcslotrole257:
  %v1750 = load i64, ptr %slot38, align 8
  store i64 %v1750, ptr %slot229, align 8
  %v1751 = load i64, ptr %slot229, align 8
  %v1752 = load i64, ptr %slot226, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1751, i64 %v1752) nomerge, !dbg !120
  br label %bb_rcslotdone257
bb_rcslotowner257:
  %v1753 = load i64, ptr %slot38, align 8
  store i64 %v1753, ptr %slot230, align 8
  %v1754 = load i64, ptr %slot230, align 8
  %v1755 = load i64, ptr %slot226, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v1754, i64 %v1755) nomerge, !dbg !120
  br label %bb_rcslotdone257
bb_rcslotdone257:
  %v1756 = load i64, ptr %slot20, align 8
  store i64 %v1756, ptr %slot231, align 8
  %v1757 = load i64, ptr %slot23, align 8
  store i64 %v1757, ptr %slot232, align 8
  %v1758 = load i64, ptr %slot232, align 8
  %v1759 = load i64, ptr %slot231, align 8
  %p1760 = inttoptr i64 %v1758 to ptr
  %p1761 = inttoptr i64 %v1759 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1761, ptr %p1760, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1762 = load i64, ptr %slot16, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  store i32 2, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  %v1764 = load i64, ptr %slot18, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  %ld1766 = load i32, ptr %p1765, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1766, ptr %slot233, align 8
  %v1767 = load i32, ptr %slot233, align 8
  %v1768 = load i64, ptr %slot16, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  store i32 %v1767, ptr %p1769, align 4, !alias.scope !3, !noalias !4
  %v1770 = load i64, ptr %slot17, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  store i32 0, ptr %p1771, align 4, !alias.scope !3, !noalias !4
  %v1772 = load i64, ptr %slot15, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  store i32 1, ptr %p1773, align 4, !alias.scope !3, !noalias !4
  %v1774 = load i64, ptr %slot231, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  %ld1776 = load i64, ptr %p1775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1776, ptr %slot234, align 8
  %v1777 = load i64, ptr %slot234, align 8
  %v1778 = load i64, ptr %slot33, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i64 %v1777, ptr %p1779, align 8, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot33, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i64, ptr %p1781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1782, ptr %slot235, align 8
  %v1783 = load i64, ptr %slot235, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  %ld1785 = load i64, ptr %p1784, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1785, ptr %slot236, align 8
  %v1786 = load i64, ptr %slot236, align 8
  %v1787 = load i64, ptr %slot33, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  store i64 %v1786, ptr %p1788, align 8, !alias.scope !3, !noalias !4
  %v1789 = load i64, ptr %slot15, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  %ld1791 = load i32, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1791, ptr %slot237, align 8
  %v1792 = load i32, ptr %slot237, align 8
  %cv1793 = zext i32 %v1792 to i64
  %cond1794 = icmp ne i64 %cv1793, 0
  br i1 %cond1794, label %bb_rcslotdrop277, label %bb_rcslotdone277
bb_rcslotdrop277:
  %v1795 = load i64, ptr %slot15, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  store i32 0, ptr %p1796, align 4, !alias.scope !3, !noalias !4
  %v1797 = load i64, ptr %slot20, align 8
  store i64 %v1797, ptr %slot238, align 8
  %v1798 = load i64, ptr %slot16, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  %ld1800 = load i32, ptr %p1799, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1800, ptr %slot239, align 8
  %v1801 = load i32, ptr %slot239, align 8
  %op1802 = and i32 %v1801, 28
  store i32 %op1802, ptr %slot240, align 8
  %v1803 = load i32, ptr %slot240, align 8
  %cv1804 = zext i32 %v1803 to i64
  %cond1805 = icmp ne i64 %cv1804, 0
  br i1 %cond1805, label %bb_rcslotrole277, label %bb_rcslotowner277
bb_rcslotrole277:
  %v1806 = load i64, ptr %slot38, align 8
  store i64 %v1806, ptr %slot241, align 8
  %v1807 = load i64, ptr %slot238, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  %ld1809 = load i64, ptr %p1808, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1809, ptr %slot242, align 8
  %v1810 = load i64, ptr %slot242, align 8
  %cmp1811 = icmp ne i64 %v1810, 0
  %cv1812 = zext i1 %cmp1811 to i32
  store i32 %cv1812, ptr %slot243, align 8
  %v1813 = load i32, ptr %slot243, align 8
  %cv1814 = zext i32 %v1813 to i64
  %cond1815 = icmp ne i64 %cv1814, 0
  br i1 %cond1815, label %bb_rcgnn293, label %bb_rcgdone293
bb_rcgnn293:
  %v1816 = load i64, ptr %slot242, align 8
  %op1817 = sub i64 %v1816, 16
  store i64 %op1817, ptr %slot244, align 8
  %v1818 = load i64, ptr %slot242, align 8
  %p1819 = inttoptr i64 %v1818 to ptr
  %rgep1820 = getelementptr i8, ptr %p1819, i64 -16
  %ld1821 = load i64, ptr %rgep1820, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1821, ptr %slot245, align 8
  %v1822 = load i64, ptr %slot245, align 8
  %op1823 = and i64 %v1822, 4611686018427387906
  store i64 %op1823, ptr %slot246, align 8
  %v1824 = load i64, ptr %slot246, align 8
  %cmp1825 = icmp ne i64 %v1824, 0
  %cv1826 = zext i1 %cmp1825 to i32
  store i32 %cv1826, ptr %slot247, align 8
  %v1827 = load i32, ptr %slot247, align 8
  %cv1828 = zext i32 %v1827 to i64
  %cond1829 = icmp ne i64 %cv1828, 0
  br i1 %cond1829, label %bb_rcgclear293, label %bb_rcgcounted293
bb_rcgcounted293:
  %v1830 = load i64, ptr %slot242, align 8
  %op1831 = sub i64 %v1830, 24
  store i64 %op1831, ptr %slot248, align 8
  %v1832 = load i64, ptr %slot242, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  %rgep1834 = getelementptr i8, ptr %p1833, i64 -24
  %ld1835 = load i64, ptr %rgep1834, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1835, ptr %slot249, align 8
  %v1836 = load i64, ptr %slot249, align 8
  %op1837 = sub i64 %v1836, 1
  store i64 %op1837, ptr %slot250, align 8
  %v1838 = load i64, ptr %slot250, align 8
  %cmp1839 = icmp eq i64 %v1838, 0
  %cv1840 = zext i1 %cmp1839 to i32
  store i32 %cv1840, ptr %slot251, align 8
  %v1841 = load i32, ptr %slot251, align 8
  %cv1842 = zext i32 %v1841 to i64
  %cond1843 = icmp ne i64 %cv1842, 0
  br i1 %cond1843, label %bb_rcglast293, label %bb_rcgdec293
bb_rcglast293:
  %v1844 = load i64, ptr %slot242, align 8
  %op1845 = sub i64 %v1844, 32
  store i64 %op1845, ptr %slot252, align 8
  %v1846 = load i64, ptr %slot242, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  %rgep1848 = getelementptr i8, ptr %p1847, i64 -32
  %ld1849 = load i64, ptr %rgep1848, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1849, ptr %slot253, align 8
  %v1850 = load i64, ptr %slot253, align 8
  %cmp1851 = icmp ne i64 %v1850, 0
  %cv1852 = zext i1 %cmp1851 to i32
  store i32 %cv1852, ptr %slot254, align 8
  %v1853 = load i32, ptr %slot254, align 8
  %cv1854 = zext i32 %v1853 to i64
  %cond1855 = icmp ne i64 %cv1854, 0
  br i1 %cond1855, label %bb_rcgdec293, label %bb_rcgslow293
bb_rcgslow293:
  %v1856 = load i64, ptr %slot241, align 8
  %v1857 = load i64, ptr %slot238, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1856, i64 %v1857) nomerge, !dbg !122
  br label %bb_rcgdone293
bb_rcgdec293:
  %v1858 = load i64, ptr %slot250, align 8
  %v1859 = load i64, ptr %slot242, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  %rgep1861 = getelementptr i8, ptr %p1860, i64 -24
  store i64 %v1858, ptr %rgep1861, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear293
bb_rcgclear293:
  %v1862 = load i64, ptr %slot238, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i64 0, ptr %p1863, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone293
bb_rcgdone293:
  br label %bb_rcslotdone277
bb_rcslotowner277:
  %v1864 = load i64, ptr %slot38, align 8
  store i64 %v1864, ptr %slot255, align 8
  %v1865 = load i64, ptr %slot238, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  %ld1867 = load i64, ptr %p1866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1867, ptr %slot256, align 8
  %v1868 = load i64, ptr %slot256, align 8
  %cmp1869 = icmp ne i64 %v1868, 0
  %cv1870 = zext i1 %cmp1869 to i32
  store i32 %cv1870, ptr %slot257, align 8
  %v1871 = load i32, ptr %slot257, align 8
  %cv1872 = zext i32 %v1871 to i64
  %cond1873 = icmp ne i64 %cv1872, 0
  br i1 %cond1873, label %bb_rcgnn308, label %bb_rcgdone308
bb_rcgnn308:
  %v1874 = load i64, ptr %slot256, align 8
  %op1875 = sub i64 %v1874, 16
  store i64 %op1875, ptr %slot258, align 8
  %v1876 = load i64, ptr %slot256, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  %rgep1878 = getelementptr i8, ptr %p1877, i64 -16
  %ld1879 = load i64, ptr %rgep1878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1879, ptr %slot259, align 8
  %v1880 = load i64, ptr %slot259, align 8
  %op1881 = and i64 %v1880, 4611686018427387906
  store i64 %op1881, ptr %slot260, align 8
  %v1882 = load i64, ptr %slot260, align 8
  %cmp1883 = icmp ne i64 %v1882, 0
  %cv1884 = zext i1 %cmp1883 to i32
  store i32 %cv1884, ptr %slot261, align 8
  %v1885 = load i32, ptr %slot261, align 8
  %cv1886 = zext i32 %v1885 to i64
  %cond1887 = icmp ne i64 %cv1886, 0
  br i1 %cond1887, label %bb_rcgclear308, label %bb_rcgcounted308
bb_rcgcounted308:
  %v1888 = load i64, ptr %slot256, align 8
  %op1889 = sub i64 %v1888, 32
  store i64 %op1889, ptr %slot262, align 8
  %v1890 = load i64, ptr %slot256, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  %rgep1892 = getelementptr i8, ptr %p1891, i64 -32
  %ld1893 = load i64, ptr %rgep1892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1893, ptr %slot263, align 8
  %v1894 = load i64, ptr %slot263, align 8
  %op1895 = sub i64 %v1894, 1
  store i64 %op1895, ptr %slot264, align 8
  %v1896 = load i64, ptr %slot264, align 8
  %cmp1897 = icmp eq i64 %v1896, 0
  %cv1898 = zext i1 %cmp1897 to i32
  store i32 %cv1898, ptr %slot265, align 8
  %v1899 = load i32, ptr %slot265, align 8
  %cv1900 = zext i32 %v1899 to i64
  %cond1901 = icmp ne i64 %cv1900, 0
  br i1 %cond1901, label %bb_rcglast308, label %bb_rcgdec308
bb_rcglast308:
  %v1902 = load i64, ptr %slot256, align 8
  %op1903 = sub i64 %v1902, 24
  store i64 %op1903, ptr %slot266, align 8
  %v1904 = load i64, ptr %slot256, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  %rgep1906 = getelementptr i8, ptr %p1905, i64 -24
  %ld1907 = load i64, ptr %rgep1906, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1907, ptr %slot267, align 8
  %v1908 = load i64, ptr %slot267, align 8
  %cmp1909 = icmp ne i64 %v1908, 0
  %cv1910 = zext i1 %cmp1909 to i32
  store i32 %cv1910, ptr %slot268, align 8
  %v1911 = load i32, ptr %slot268, align 8
  %cv1912 = zext i32 %v1911 to i64
  %cond1913 = icmp ne i64 %cv1912, 0
  br i1 %cond1913, label %bb_rcgdec308, label %bb_rcgslow308
bb_rcgslow308:
  %v1914 = load i64, ptr %slot255, align 8
  %v1915 = load i64, ptr %slot238, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1914, i64 %v1915) nomerge, !dbg !122
  br label %bb_rcgdone308
bb_rcgdec308:
  %v1916 = load i64, ptr %slot264, align 8
  %v1917 = load i64, ptr %slot256, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %rgep1919 = getelementptr i8, ptr %p1918, i64 -32
  store i64 %v1916, ptr %rgep1919, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear308
bb_rcgclear308:
  %v1920 = load i64, ptr %slot238, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  store i64 0, ptr %p1921, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone308
bb_rcgdone308:
  br label %bb_rcslotdone277
bb_rcslotdone277:
  %v1922 = load i64, ptr %slot33, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %ld1924 = load i64, ptr %p1923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1924, ptr %slot269, align 8
  %v1925 = load i64, ptr %slot32, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %ld1927 = load i64, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1927, ptr %slot270, align 8
  %v1928 = load i64, ptr %slot270, align 8
  %v1929 = load i64, ptr %slot269, align 8
  %cmp1930 = icmp sge i64 %v1928, %v1929
  %cv1931 = zext i1 %cmp1930 to i64
  store i64 %cv1931, ptr %slot271, align 8
  %v1932 = load i64, ptr %slot271, align 8
  %v1933 = load i64, ptr %slot32, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  store i64 %v1932, ptr %p1934, align 8, !alias.scope !3, !noalias !4
  br label %bb_i11
bb_i11:
  %v1935 = load i64, ptr %slot32, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  %ld1937 = load i64, ptr %p1936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1937, ptr %slot272, align 8
  %v1938 = load i64, ptr %slot272, align 8
  %cond1939 = icmp ne i64 %v1938, 0
  br i1 %cond1939, label %bb_next316, label %bb_i14
bb_next316:
  %v1940 = load i64, ptr %slot32, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  store i64 0, ptr %p1941, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i14:
  %v1942 = load i64, ptr %slot26, align 8
  %v1943 = load i64, ptr %slot32, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  store i64 %v1942, ptr %p1944, align 8, !alias.scope !3, !noalias !4
  %v1945 = load i64, ptr %slot32, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  %ld1947 = load i64, ptr %p1946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1947, ptr %slot273, align 8
  %v1948 = load i64, ptr %slot273, align 8
  %op1949 = add i64 %v1948, 0
  store i64 %op1949, ptr %slot274, align 8
  %v1950 = load i64, ptr %slot274, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  %ld1952 = load i64, ptr %p1951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1952, ptr %slot275, align 8
  %v1953 = load i64, ptr %slot275, align 8
  %v1954 = load i64, ptr %slot32, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  store i64 %v1953, ptr %p1955, align 8, !alias.scope !3, !noalias !4
  %v1956 = load i64, ptr %slot32, align 8
  %p1957 = inttoptr i64 %v1956 to ptr
  %ld1958 = load i64, ptr %p1957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1958, ptr %slot276, align 8
  %v1959 = load i64, ptr %slot276, align 8
  %v1960 = load i64, ptr %slot21, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  store i64 %v1959, ptr %p1961, align 8, !alias.scope !3, !noalias !4
  %v1962 = load i64, ptr %slot21, align 8
  store i64 %v1962, ptr %slot277, align 8
  %v1963 = load i64, ptr %slot23, align 8
  store i64 %v1963, ptr %slot278, align 8
  %v1964 = load i64, ptr %slot277, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %ld1966 = load i64, ptr %p1965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1966, ptr %slot279, align 8
  %v1967 = load i64, ptr %slot279, align 8
  %cmp1968 = icmp ne i64 %v1967, 0
  %cv1969 = zext i1 %cmp1968 to i32
  store i32 %cv1969, ptr %slot280, align 8
  %v1970 = load i32, ptr %slot280, align 8
  %cv1971 = zext i32 %v1970 to i64
  %cond1972 = icmp ne i64 %cv1971, 0
  br i1 %cond1972, label %bb_rcgnn323, label %bb_rcgstore323
bb_rcgnn323:
  %v1973 = load i64, ptr %slot279, align 8
  %op1974 = sub i64 %v1973, 16
  store i64 %op1974, ptr %slot281, align 8
  %v1975 = load i64, ptr %slot279, align 8
  %p1976 = inttoptr i64 %v1975 to ptr
  %rgep1977 = getelementptr i8, ptr %p1976, i64 -16
  %ld1978 = load i64, ptr %rgep1977, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1978, ptr %slot282, align 8
  %v1979 = load i64, ptr %slot282, align 8
  %op1980 = and i64 %v1979, 4611686018427387906
  store i64 %op1980, ptr %slot283, align 8
  %v1981 = load i64, ptr %slot283, align 8
  %cmp1982 = icmp ne i64 %v1981, 0
  %cv1983 = zext i1 %cmp1982 to i32
  store i32 %cv1983, ptr %slot284, align 8
  %v1984 = load i32, ptr %slot284, align 8
  %cv1985 = zext i32 %v1984 to i64
  %cond1986 = icmp ne i64 %cv1985, 0
  br i1 %cond1986, label %bb_rcgstore323, label %bb_rcginc323
bb_rcginc323:
  %v1987 = load i64, ptr %slot279, align 8
  %op1988 = sub i64 %v1987, 24
  store i64 %op1988, ptr %slot285, align 8
  %v1989 = load i64, ptr %slot279, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  %rgep1991 = getelementptr i8, ptr %p1990, i64 -24
  %ld1992 = load i64, ptr %rgep1991, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1992, ptr %slot286, align 8
  %v1993 = load i64, ptr %slot286, align 8
  %op1994 = add i64 %v1993, 1
  store i64 %op1994, ptr %slot287, align 8
  %v1995 = load i64, ptr %slot287, align 8
  %cmp1996 = icmp eq i64 %v1995, 0
  %cv1997 = zext i1 %cmp1996 to i32
  store i32 %cv1997, ptr %slot288, align 8
  %v1998 = load i32, ptr %slot288, align 8
  %cv1999 = zext i32 %v1998 to i64
  %cond2000 = icmp ne i64 %cv1999, 0
  br i1 %cond2000, label %bb_rcglimit323, label %bb_rcgcapacity323
bb_rcglimit323:
  %v2001 = load i64, ptr %slot1, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  %call2003 = call i32 @myl_qbe_rc_status(ptr %p2002, i32 2) nomerge, !dbg !124
  store i32 %call2003, ptr %slot289, align 8
  br label %bb_failure
bb_rcgcapacity323:
  %v2004 = load i64, ptr %slot287, align 8
  %v2005 = load i64, ptr %slot279, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  %rgep2007 = getelementptr i8, ptr %p2006, i64 -24
  store i64 %v2004, ptr %rgep2007, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore323
bb_rcgstore323:
  %v2008 = load i64, ptr %slot279, align 8
  %v2009 = load i64, ptr %slot278, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  store i64 %v2008, ptr %p2010, align 8, !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot18, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  store i32 2, ptr %p2012, align 4, !alias.scope !3, !noalias !4
  %v2013 = load i64, ptr %slot18, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  store i32 16, ptr %p2014, align 4, !alias.scope !3, !noalias !4
  %v2015 = load i64, ptr %slot17, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  store i32 1, ptr %p2016, align 4, !alias.scope !3, !noalias !4
  %v2017 = load i64, ptr %slot13, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  %ld2019 = load i32, ptr %p2018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2019, ptr %slot290, align 8
  %v2020 = load i32, ptr %slot290, align 8
  %cv2021 = zext i32 %v2020 to i64
  %cond2022 = icmp ne i64 %cv2021, 0
  br i1 %cond2022, label %bb_rcslotdrop339, label %bb_rcslotdone339
bb_rcslotdrop339:
  %v2023 = load i64, ptr %slot13, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i32 0, ptr %p2024, align 4, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot19, align 8
  store i64 %v2025, ptr %slot291, align 8
  %v2026 = load i64, ptr %slot14, align 8
  %p2027 = inttoptr i64 %v2026 to ptr
  %ld2028 = load i32, ptr %p2027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2028, ptr %slot292, align 8
  %v2029 = load i32, ptr %slot292, align 8
  %op2030 = and i32 %v2029, 28
  store i32 %op2030, ptr %slot293, align 8
  %v2031 = load i32, ptr %slot293, align 8
  %cv2032 = zext i32 %v2031 to i64
  %cond2033 = icmp ne i64 %cv2032, 0
  br i1 %cond2033, label %bb_rcslotrole339, label %bb_rcslotowner339
bb_rcslotrole339:
  %v2034 = load i64, ptr %slot38, align 8
  store i64 %v2034, ptr %slot294, align 8
  %v2035 = load i64, ptr %slot294, align 8
  %v2036 = load i64, ptr %slot291, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2035, i64 %v2036) nomerge, !dbg !124
  br label %bb_rcslotdone339
bb_rcslotowner339:
  %v2037 = load i64, ptr %slot38, align 8
  store i64 %v2037, ptr %slot295, align 8
  %v2038 = load i64, ptr %slot295, align 8
  %v2039 = load i64, ptr %slot291, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2038, i64 %v2039) nomerge, !dbg !124
  br label %bb_rcslotdone339
bb_rcslotdone339:
  %v2040 = load i64, ptr %slot19, align 8
  store i64 %v2040, ptr %slot296, align 8
  %v2041 = load i64, ptr %slot23, align 8
  store i64 %v2041, ptr %slot297, align 8
  %v2042 = load i64, ptr %slot297, align 8
  %v2043 = load i64, ptr %slot296, align 8
  %p2044 = inttoptr i64 %v2042 to ptr
  %p2045 = inttoptr i64 %v2043 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2045, ptr %p2044, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2046 = load i64, ptr %slot14, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  store i32 2, ptr %p2047, align 4, !alias.scope !3, !noalias !4
  %v2048 = load i64, ptr %slot18, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  %ld2050 = load i32, ptr %p2049, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2050, ptr %slot298, align 8
  %v2051 = load i32, ptr %slot298, align 8
  %v2052 = load i64, ptr %slot14, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  store i32 %v2051, ptr %p2053, align 4, !alias.scope !3, !noalias !4
  %v2054 = load i64, ptr %slot17, align 8
  %p2055 = inttoptr i64 %v2054 to ptr
  store i32 0, ptr %p2055, align 4, !alias.scope !3, !noalias !4
  %v2056 = load i64, ptr %slot13, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  store i32 1, ptr %p2057, align 4, !alias.scope !3, !noalias !4
  %v2058 = load i64, ptr %slot296, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  %ld2060 = load i64, ptr %p2059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2060, ptr %slot299, align 8
  %v2061 = load i64, ptr %slot299, align 8
  %v2062 = load i64, ptr %slot32, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  store i64 %v2061, ptr %p2063, align 8, !alias.scope !3, !noalias !4
  %v2064 = load i64, ptr %slot26, align 8
  %v2065 = load i64, ptr %slot33, align 8
  %p2066 = inttoptr i64 %v2065 to ptr
  store i64 %v2064, ptr %p2066, align 8, !alias.scope !3, !noalias !4
  %v2067 = load i64, ptr %slot33, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %ld2069 = load i64, ptr %p2068, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2069, ptr %slot300, align 8
  %v2070 = load i64, ptr %slot300, align 8
  %op2071 = add i64 %v2070, 16
  store i64 %op2071, ptr %slot301, align 8
  %v2072 = load i64, ptr %slot301, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  %ld2074 = load i64, ptr %p2073, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2074, ptr %slot302, align 8
  %v2075 = load i64, ptr %slot302, align 8
  %v2076 = load i64, ptr %slot33, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  store i64 %v2075, ptr %p2077, align 8, !alias.scope !3, !noalias !4
  %v2078 = load i64, ptr %slot15, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  %ld2080 = load i32, ptr %p2079, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2080, ptr %slot303, align 8
  %v2081 = load i32, ptr %slot303, align 8
  %cv2082 = zext i32 %v2081 to i64
  %cond2083 = icmp ne i64 %cv2082, 0
  br i1 %cond2083, label %bb_rcslotdrop360, label %bb_rcslotdone360
bb_rcslotdrop360:
  %v2084 = load i64, ptr %slot15, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  store i32 0, ptr %p2085, align 4, !alias.scope !3, !noalias !4
  %v2086 = load i64, ptr %slot20, align 8
  store i64 %v2086, ptr %slot304, align 8
  %v2087 = load i64, ptr %slot16, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  %ld2089 = load i32, ptr %p2088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2089, ptr %slot305, align 8
  %v2090 = load i32, ptr %slot305, align 8
  %op2091 = and i32 %v2090, 28
  store i32 %op2091, ptr %slot306, align 8
  %v2092 = load i32, ptr %slot306, align 8
  %cv2093 = zext i32 %v2092 to i64
  %cond2094 = icmp ne i64 %cv2093, 0
  br i1 %cond2094, label %bb_rcslotrole360, label %bb_rcslotowner360
bb_rcslotrole360:
  %v2095 = load i64, ptr %slot38, align 8
  store i64 %v2095, ptr %slot307, align 8
  %v2096 = load i64, ptr %slot307, align 8
  %v2097 = load i64, ptr %slot304, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2096, i64 %v2097) nomerge, !dbg !126
  br label %bb_rcslotdone360
bb_rcslotowner360:
  %v2098 = load i64, ptr %slot38, align 8
  store i64 %v2098, ptr %slot308, align 8
  %v2099 = load i64, ptr %slot308, align 8
  %v2100 = load i64, ptr %slot304, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2099, i64 %v2100) nomerge, !dbg !126
  br label %bb_rcslotdone360
bb_rcslotdone360:
  %v2101 = load i64, ptr %slot32, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  %ld2103 = load i64, ptr %p2102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2103, ptr %slot309, align 8
  %v2104 = load i64, ptr %slot33, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  %ld2106 = load i64, ptr %p2105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2106, ptr %slot310, align 8
  %v2107 = load i64, ptr %slot309, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %ld2109 = load i64, ptr %p2108, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2109, ptr %slot311, align 8
  %v2110 = load i64, ptr %slot310, align 8
  %op2111 = ashr i64 %v2110, 63
  store i64 %op2111, ptr %slot312, align 8
  %v2112 = load i64, ptr %slot312, align 8
  %v2113 = load i64, ptr %slot311, align 8
  %op2114 = and i64 %v2112, %v2113
  store i64 %op2114, ptr %slot313, align 8
  %v2115 = load i64, ptr %slot310, align 8
  %v2116 = load i64, ptr %slot313, align 8
  %op2117 = add i64 %v2115, %v2116
  store i64 %op2117, ptr %slot314, align 8
  %v2118 = load i64, ptr %slot314, align 8
  %v2119 = load i64, ptr %slot311, align 8
  %cmp2120 = icmp ult i64 %v2118, %v2119
  %cv2121 = zext i1 %cmp2120 to i64
  store i64 %cv2121, ptr %slot315, align 8
  %v2122 = load i64, ptr %slot315, align 8
  %cond2123 = icmp ne i64 %v2122, 0
  br i1 %cond2123, label %bb_success375, label %bb_failed375
bb_failed375:
  %v2124 = load i64, ptr %slot1, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  %v2126 = load i64, ptr %slot310, align 8
  %v2127 = load i64, ptr %slot311, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p2125, i64 %v2126, i64 %v2127) nomerge, !dbg !128
  unreachable
bb_success375:
  %v2128 = load i64, ptr %slot309, align 8
  %op2129 = add i64 %v2128, 32
  store i64 %op2129, ptr %slot316, align 8
  %v2130 = load i64, ptr %slot316, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  %ld2132 = load i64, ptr %p2131, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2132, ptr %slot317, align 8
  %v2133 = load i64, ptr %slot317, align 8
  %v2134 = load i64, ptr %slot314, align 8
  %op2135 = add i64 %v2133, %v2134
  store i64 %op2135, ptr %slot318, align 8
  %v2136 = load i64, ptr %slot317, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  %v2138 = load i64, ptr %slot314, align 8
  %egep2139 = getelementptr i8, ptr %p2137, i64 %v2138
  %ld2140 = load i8, ptr %egep2139, align 1, !alias.scope !12, !noalias !13
  %ext2141 = zext i8 %ld2140 to i64
  store i64 %ext2141, ptr %slot319, align 8
  %v2142 = load i64, ptr %slot319, align 8
  %v2143 = load i64, ptr %slot32, align 8
  %p2144 = inttoptr i64 %v2143 to ptr
  store i64 %v2142, ptr %p2144, align 8, !alias.scope !3, !noalias !4
  %v2145 = load i64, ptr %slot13, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  %ld2147 = load i32, ptr %p2146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2147, ptr %slot320, align 8
  %v2148 = load i32, ptr %slot320, align 8
  %cv2149 = zext i32 %v2148 to i64
  %cond2150 = icmp ne i64 %cv2149, 0
  br i1 %cond2150, label %bb_rcslotdrop383, label %bb_rcslotdone383
bb_rcslotdrop383:
  %v2151 = load i64, ptr %slot13, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i32 0, ptr %p2152, align 4, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot19, align 8
  store i64 %v2153, ptr %slot321, align 8
  %v2154 = load i64, ptr %slot14, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  %ld2156 = load i32, ptr %p2155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2156, ptr %slot322, align 8
  %v2157 = load i32, ptr %slot322, align 8
  %op2158 = and i32 %v2157, 28
  store i32 %op2158, ptr %slot323, align 8
  %v2159 = load i32, ptr %slot323, align 8
  %cv2160 = zext i32 %v2159 to i64
  %cond2161 = icmp ne i64 %cv2160, 0
  br i1 %cond2161, label %bb_rcslotrole383, label %bb_rcslotowner383
bb_rcslotrole383:
  %v2162 = load i64, ptr %slot38, align 8
  store i64 %v2162, ptr %slot324, align 8
  %v2163 = load i64, ptr %slot321, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  %ld2165 = load i64, ptr %p2164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2165, ptr %slot325, align 8
  %v2166 = load i64, ptr %slot325, align 8
  %cmp2167 = icmp ne i64 %v2166, 0
  %cv2168 = zext i1 %cmp2167 to i32
  store i32 %cv2168, ptr %slot326, align 8
  %v2169 = load i32, ptr %slot326, align 8
  %cv2170 = zext i32 %v2169 to i64
  %cond2171 = icmp ne i64 %cv2170, 0
  br i1 %cond2171, label %bb_rcgnn399, label %bb_rcgdone399
bb_rcgnn399:
  %v2172 = load i64, ptr %slot325, align 8
  %op2173 = sub i64 %v2172, 16
  store i64 %op2173, ptr %slot327, align 8
  %v2174 = load i64, ptr %slot325, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  %rgep2176 = getelementptr i8, ptr %p2175, i64 -16
  %ld2177 = load i64, ptr %rgep2176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2177, ptr %slot328, align 8
  %v2178 = load i64, ptr %slot328, align 8
  %op2179 = and i64 %v2178, 4611686018427387906
  store i64 %op2179, ptr %slot329, align 8
  %v2180 = load i64, ptr %slot329, align 8
  %cmp2181 = icmp ne i64 %v2180, 0
  %cv2182 = zext i1 %cmp2181 to i32
  store i32 %cv2182, ptr %slot330, align 8
  %v2183 = load i32, ptr %slot330, align 8
  %cv2184 = zext i32 %v2183 to i64
  %cond2185 = icmp ne i64 %cv2184, 0
  br i1 %cond2185, label %bb_rcgclear399, label %bb_rcgcounted399
bb_rcgcounted399:
  %v2186 = load i64, ptr %slot325, align 8
  %op2187 = sub i64 %v2186, 24
  store i64 %op2187, ptr %slot331, align 8
  %v2188 = load i64, ptr %slot325, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  %rgep2190 = getelementptr i8, ptr %p2189, i64 -24
  %ld2191 = load i64, ptr %rgep2190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2191, ptr %slot332, align 8
  %v2192 = load i64, ptr %slot332, align 8
  %op2193 = sub i64 %v2192, 1
  store i64 %op2193, ptr %slot333, align 8
  %v2194 = load i64, ptr %slot333, align 8
  %cmp2195 = icmp eq i64 %v2194, 0
  %cv2196 = zext i1 %cmp2195 to i32
  store i32 %cv2196, ptr %slot334, align 8
  %v2197 = load i32, ptr %slot334, align 8
  %cv2198 = zext i32 %v2197 to i64
  %cond2199 = icmp ne i64 %cv2198, 0
  br i1 %cond2199, label %bb_rcglast399, label %bb_rcgdec399
bb_rcglast399:
  %v2200 = load i64, ptr %slot325, align 8
  %op2201 = sub i64 %v2200, 32
  store i64 %op2201, ptr %slot335, align 8
  %v2202 = load i64, ptr %slot325, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %rgep2204 = getelementptr i8, ptr %p2203, i64 -32
  %ld2205 = load i64, ptr %rgep2204, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2205, ptr %slot336, align 8
  %v2206 = load i64, ptr %slot336, align 8
  %cmp2207 = icmp ne i64 %v2206, 0
  %cv2208 = zext i1 %cmp2207 to i32
  store i32 %cv2208, ptr %slot337, align 8
  %v2209 = load i32, ptr %slot337, align 8
  %cv2210 = zext i32 %v2209 to i64
  %cond2211 = icmp ne i64 %cv2210, 0
  br i1 %cond2211, label %bb_rcgdec399, label %bb_rcgslow399
bb_rcgslow399:
  %v2212 = load i64, ptr %slot324, align 8
  %v2213 = load i64, ptr %slot321, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2212, i64 %v2213) nomerge, !dbg !128
  br label %bb_rcgdone399
bb_rcgdec399:
  %v2214 = load i64, ptr %slot333, align 8
  %v2215 = load i64, ptr %slot325, align 8
  %p2216 = inttoptr i64 %v2215 to ptr
  %rgep2217 = getelementptr i8, ptr %p2216, i64 -24
  store i64 %v2214, ptr %rgep2217, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear399
bb_rcgclear399:
  %v2218 = load i64, ptr %slot321, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  store i64 0, ptr %p2219, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone399
bb_rcgdone399:
  br label %bb_rcslotdone383
bb_rcslotowner383:
  %v2220 = load i64, ptr %slot38, align 8
  store i64 %v2220, ptr %slot338, align 8
  %v2221 = load i64, ptr %slot321, align 8
  %p2222 = inttoptr i64 %v2221 to ptr
  %ld2223 = load i64, ptr %p2222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2223, ptr %slot339, align 8
  %v2224 = load i64, ptr %slot339, align 8
  %cmp2225 = icmp ne i64 %v2224, 0
  %cv2226 = zext i1 %cmp2225 to i32
  store i32 %cv2226, ptr %slot340, align 8
  %v2227 = load i32, ptr %slot340, align 8
  %cv2228 = zext i32 %v2227 to i64
  %cond2229 = icmp ne i64 %cv2228, 0
  br i1 %cond2229, label %bb_rcgnn414, label %bb_rcgdone414
bb_rcgnn414:
  %v2230 = load i64, ptr %slot339, align 8
  %op2231 = sub i64 %v2230, 16
  store i64 %op2231, ptr %slot341, align 8
  %v2232 = load i64, ptr %slot339, align 8
  %p2233 = inttoptr i64 %v2232 to ptr
  %rgep2234 = getelementptr i8, ptr %p2233, i64 -16
  %ld2235 = load i64, ptr %rgep2234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2235, ptr %slot342, align 8
  %v2236 = load i64, ptr %slot342, align 8
  %op2237 = and i64 %v2236, 4611686018427387906
  store i64 %op2237, ptr %slot343, align 8
  %v2238 = load i64, ptr %slot343, align 8
  %cmp2239 = icmp ne i64 %v2238, 0
  %cv2240 = zext i1 %cmp2239 to i32
  store i32 %cv2240, ptr %slot344, align 8
  %v2241 = load i32, ptr %slot344, align 8
  %cv2242 = zext i32 %v2241 to i64
  %cond2243 = icmp ne i64 %cv2242, 0
  br i1 %cond2243, label %bb_rcgclear414, label %bb_rcgcounted414
bb_rcgcounted414:
  %v2244 = load i64, ptr %slot339, align 8
  %op2245 = sub i64 %v2244, 32
  store i64 %op2245, ptr %slot345, align 8
  %v2246 = load i64, ptr %slot339, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  %rgep2248 = getelementptr i8, ptr %p2247, i64 -32
  %ld2249 = load i64, ptr %rgep2248, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2249, ptr %slot346, align 8
  %v2250 = load i64, ptr %slot346, align 8
  %op2251 = sub i64 %v2250, 1
  store i64 %op2251, ptr %slot347, align 8
  %v2252 = load i64, ptr %slot347, align 8
  %cmp2253 = icmp eq i64 %v2252, 0
  %cv2254 = zext i1 %cmp2253 to i32
  store i32 %cv2254, ptr %slot348, align 8
  %v2255 = load i32, ptr %slot348, align 8
  %cv2256 = zext i32 %v2255 to i64
  %cond2257 = icmp ne i64 %cv2256, 0
  br i1 %cond2257, label %bb_rcglast414, label %bb_rcgdec414
bb_rcglast414:
  %v2258 = load i64, ptr %slot339, align 8
  %op2259 = sub i64 %v2258, 24
  store i64 %op2259, ptr %slot349, align 8
  %v2260 = load i64, ptr %slot339, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  %rgep2262 = getelementptr i8, ptr %p2261, i64 -24
  %ld2263 = load i64, ptr %rgep2262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2263, ptr %slot350, align 8
  %v2264 = load i64, ptr %slot350, align 8
  %cmp2265 = icmp ne i64 %v2264, 0
  %cv2266 = zext i1 %cmp2265 to i32
  store i32 %cv2266, ptr %slot351, align 8
  %v2267 = load i32, ptr %slot351, align 8
  %cv2268 = zext i32 %v2267 to i64
  %cond2269 = icmp ne i64 %cv2268, 0
  br i1 %cond2269, label %bb_rcgdec414, label %bb_rcgslow414
bb_rcgslow414:
  %v2270 = load i64, ptr %slot338, align 8
  %v2271 = load i64, ptr %slot321, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2270, i64 %v2271) nomerge, !dbg !128
  br label %bb_rcgdone414
bb_rcgdec414:
  %v2272 = load i64, ptr %slot347, align 8
  %v2273 = load i64, ptr %slot339, align 8
  %p2274 = inttoptr i64 %v2273 to ptr
  %rgep2275 = getelementptr i8, ptr %p2274, i64 -32
  store i64 %v2272, ptr %rgep2275, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear414
bb_rcgclear414:
  %v2276 = load i64, ptr %slot321, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  store i64 0, ptr %p2277, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone414
bb_rcgdone414:
  br label %bb_rcslotdone383
bb_rcslotdone383:
  %v2278 = load i64, ptr %slot32, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  %ld2280 = load i64, ptr %p2279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2280, ptr %slot352, align 8
  %v2281 = load i64, ptr %slot352, align 8
  %v2282 = load i64, ptr %slot32, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  store i64 %v2281, ptr %p2283, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v2284 = load i64, ptr %slot32, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  %ld2286 = load i64, ptr %p2285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2286, ptr %slot353, align 8
  %v2287 = load i64, ptr %slot353, align 8
  %v2288 = load i64, ptr %slot28, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i64 %v2287, ptr %p2289, align 8, !alias.scope !3, !noalias !4
  %v2290 = load i64, ptr %slot28, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i64, ptr %p2291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2292, ptr %slot354, align 8
  %v2293 = load i64, ptr %slot354, align 8
  %v2294 = load i64, ptr %slot32, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i64 %v2293, ptr %p2295, align 8, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot33, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  store i64 97, ptr %p2297, align 8, !alias.scope !3, !noalias !4
  %v2298 = load i64, ptr %slot33, align 8
  %p2299 = inttoptr i64 %v2298 to ptr
  %ld2300 = load i64, ptr %p2299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2300, ptr %slot355, align 8
  %v2301 = load i64, ptr %slot32, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  %ld2303 = load i64, ptr %p2302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2303, ptr %slot356, align 8
  %v2304 = load i64, ptr %slot356, align 8
  %v2305 = load i64, ptr %slot355, align 8
  %cmp2306 = icmp sge i64 %v2304, %v2305
  %cv2307 = zext i1 %cmp2306 to i64
  store i64 %cv2307, ptr %slot357, align 8
  %v2308 = load i64, ptr %slot357, align 8
  %v2309 = load i64, ptr %slot32, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  store i64 %v2308, ptr %p2310, align 8, !alias.scope !3, !noalias !4
  %v2311 = load i64, ptr %slot32, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %ld2313 = load i64, ptr %p2312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2313, ptr %slot358, align 8
  %v2314 = load i64, ptr %slot358, align 8
  %cond2315 = icmp ne i64 %v2314, 0
  br i1 %cond2315, label %bb_next425, label %bb_i30
bb_next425:
  %v2316 = load i64, ptr %slot28, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  %ld2318 = load i64, ptr %p2317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2318, ptr %slot359, align 8
  %v2319 = load i64, ptr %slot359, align 8
  %v2320 = load i64, ptr %slot32, align 8
  %p2321 = inttoptr i64 %v2320 to ptr
  store i64 %v2319, ptr %p2321, align 8, !alias.scope !3, !noalias !4
  %v2322 = load i64, ptr %slot33, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  store i64 122, ptr %p2323, align 8, !alias.scope !3, !noalias !4
  %v2324 = load i64, ptr %slot33, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %ld2326 = load i64, ptr %p2325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2326, ptr %slot360, align 8
  %v2327 = load i64, ptr %slot32, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  %ld2329 = load i64, ptr %p2328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2329, ptr %slot361, align 8
  %v2330 = load i64, ptr %slot361, align 8
  %v2331 = load i64, ptr %slot360, align 8
  %cmp2332 = icmp sle i64 %v2330, %v2331
  %cv2333 = zext i1 %cmp2332 to i64
  store i64 %cv2333, ptr %slot362, align 8
  %v2334 = load i64, ptr %slot362, align 8
  %v2335 = load i64, ptr %slot32, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  store i64 %v2334, ptr %p2336, align 8, !alias.scope !3, !noalias !4
  br label %bb_i31
bb_i30:
  %v2337 = load i64, ptr %slot32, align 8
  %p2338 = inttoptr i64 %v2337 to ptr
  store i64 0, ptr %p2338, align 8, !alias.scope !3, !noalias !4
  br label %bb_i31
bb_i31:
  %v2339 = load i64, ptr %slot32, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  %ld2341 = load i64, ptr %p2340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2341, ptr %slot363, align 8
  %v2342 = load i64, ptr %slot363, align 8
  %cond2343 = icmp ne i64 %v2342, 0
  br i1 %cond2343, label %bb_next430, label %bb_i34
bb_next430:
  %v2344 = load i64, ptr %slot32, align 8
  %p2345 = inttoptr i64 %v2344 to ptr
  store i64 1, ptr %p2345, align 8, !alias.scope !3, !noalias !4
  br label %bb_i43
bb_i34:
  %v2346 = load i64, ptr %slot28, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %ld2348 = load i64, ptr %p2347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2348, ptr %slot364, align 8
  %v2349 = load i64, ptr %slot364, align 8
  %v2350 = load i64, ptr %slot32, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  store i64 %v2349, ptr %p2351, align 8, !alias.scope !3, !noalias !4
  %v2352 = load i64, ptr %slot33, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  store i64 65, ptr %p2353, align 8, !alias.scope !3, !noalias !4
  %v2354 = load i64, ptr %slot33, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  %ld2356 = load i64, ptr %p2355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2356, ptr %slot365, align 8
  %v2357 = load i64, ptr %slot32, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %ld2359 = load i64, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2359, ptr %slot366, align 8
  %v2360 = load i64, ptr %slot366, align 8
  %v2361 = load i64, ptr %slot365, align 8
  %cmp2362 = icmp sge i64 %v2360, %v2361
  %cv2363 = zext i1 %cmp2362 to i64
  store i64 %cv2363, ptr %slot367, align 8
  %v2364 = load i64, ptr %slot367, align 8
  %v2365 = load i64, ptr %slot32, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  store i64 %v2364, ptr %p2366, align 8, !alias.scope !3, !noalias !4
  %v2367 = load i64, ptr %slot32, align 8
  %p2368 = inttoptr i64 %v2367 to ptr
  %ld2369 = load i64, ptr %p2368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2369, ptr %slot368, align 8
  %v2370 = load i64, ptr %slot368, align 8
  %cond2371 = icmp ne i64 %v2370, 0
  br i1 %cond2371, label %bb_next435, label %bb_i42
bb_next435:
  %v2372 = load i64, ptr %slot28, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %ld2374 = load i64, ptr %p2373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2374, ptr %slot369, align 8
  %v2375 = load i64, ptr %slot369, align 8
  %v2376 = load i64, ptr %slot32, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  store i64 %v2375, ptr %p2377, align 8, !alias.scope !3, !noalias !4
  %v2378 = load i64, ptr %slot33, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  store i64 90, ptr %p2379, align 8, !alias.scope !3, !noalias !4
  %v2380 = load i64, ptr %slot33, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  %ld2382 = load i64, ptr %p2381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2382, ptr %slot370, align 8
  %v2383 = load i64, ptr %slot32, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  %ld2385 = load i64, ptr %p2384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2385, ptr %slot371, align 8
  %v2386 = load i64, ptr %slot371, align 8
  %v2387 = load i64, ptr %slot370, align 8
  %cmp2388 = icmp sle i64 %v2386, %v2387
  %cv2389 = zext i1 %cmp2388 to i64
  store i64 %cv2389, ptr %slot372, align 8
  %v2390 = load i64, ptr %slot372, align 8
  %v2391 = load i64, ptr %slot32, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  store i64 %v2390, ptr %p2392, align 8, !alias.scope !3, !noalias !4
  br label %bb_i43
bb_i42:
  %v2393 = load i64, ptr %slot32, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  store i64 0, ptr %p2394, align 8, !alias.scope !3, !noalias !4
  br label %bb_i43
bb_i43:
  %v2395 = load i64, ptr %slot32, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  %ld2397 = load i64, ptr %p2396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2397, ptr %slot373, align 8
  %v2398 = load i64, ptr %slot373, align 8
  %cond2399 = icmp ne i64 %v2398, 0
  br i1 %cond2399, label %bb_next440, label %bb_i46
bb_next440:
  %v2400 = load i64, ptr %slot32, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  store i64 1, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  br label %bb_i49
bb_i46:
  %v2402 = load i64, ptr %slot28, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  %ld2404 = load i64, ptr %p2403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2404, ptr %slot374, align 8
  %v2405 = load i64, ptr %slot374, align 8
  %v2406 = load i64, ptr %slot32, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  store i64 %v2405, ptr %p2407, align 8, !alias.scope !3, !noalias !4
  %v2408 = load i64, ptr %slot33, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  store i64 95, ptr %p2409, align 8, !alias.scope !3, !noalias !4
  %v2410 = load i64, ptr %slot33, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  %ld2412 = load i64, ptr %p2411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2412, ptr %slot375, align 8
  %v2413 = load i64, ptr %slot32, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  %ld2415 = load i64, ptr %p2414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2415, ptr %slot376, align 8
  %v2416 = load i64, ptr %slot376, align 8
  %v2417 = load i64, ptr %slot375, align 8
  %cmp2418 = icmp eq i64 %v2416, %v2417
  %cv2419 = zext i1 %cmp2418 to i64
  store i64 %cv2419, ptr %slot377, align 8
  %v2420 = load i64, ptr %slot377, align 8
  %v2421 = load i64, ptr %slot32, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  store i64 %v2420, ptr %p2422, align 8, !alias.scope !3, !noalias !4
  br label %bb_i49
bb_i49:
  br label %bb_i50
bb_i50:
  %v2423 = load i64, ptr %slot32, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  %ld2425 = load i64, ptr %p2424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2425, ptr %slot378, align 8
  %v2426 = load i64, ptr %slot378, align 8
  %cond2427 = icmp ne i64 %v2426, 0
  br i1 %cond2427, label %bb_next445, label %bb_i53
bb_next445:
  %v2428 = load i64, ptr %slot32, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  store i64 1, ptr %p2429, align 8, !alias.scope !3, !noalias !4
  br label %bb_i85
bb_i53:
  %v2430 = load i64, ptr %slot24, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  %ld2432 = load i64, ptr %p2431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2432, ptr %slot379, align 8
  %v2433 = load i64, ptr %slot379, align 8
  %v2434 = load i64, ptr %slot32, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  store i64 %v2433, ptr %p2435, align 8, !alias.scope !3, !noalias !4
  %v2436 = load i64, ptr %slot32, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  %ld2438 = load i64, ptr %p2437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2438, ptr %slot380, align 8
  %v2439 = load i64, ptr %slot13, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  %ld2441 = load i32, ptr %p2440, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2441, ptr %slot381, align 8
  %v2442 = load i64, ptr %slot14, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  %ld2444 = load i32, ptr %p2443, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2444, ptr %slot382, align 8
  %v2445 = load i32, ptr %slot382, align 8
  %op2446 = and i32 %v2445, 24
  store i32 %op2446, ptr %slot382, align 8
  %v2447 = load i32, ptr %slot382, align 8
  %cmp2448 = icmp eq i32 %v2447, 0
  %cv2449 = zext i1 %cmp2448 to i32
  store i32 %cv2449, ptr %slot383, align 8
  %v2450 = load i32, ptr %slot381, align 8
  %v2451 = load i32, ptr %slot383, align 8
  %op2452 = and i32 %v2450, %v2451
  store i32 %op2452, ptr %slot384, align 8
  %v2453 = load i32, ptr %slot384, align 8
  %cv2454 = zext i32 %v2453 to i64
  %cond2455 = icmp ne i64 %cv2454, 0
  br i1 %cond2455, label %bb_rctake447, label %bb_rccopy447
bb_rctake447:
  %v2456 = load i64, ptr %slot23, align 8
  store i64 %v2456, ptr %slot385, align 8
  %v2457 = load i64, ptr %slot39, align 8
  store i64 %v2457, ptr %slot386, align 8
  %v2458 = load i64, ptr %slot380, align 8
  %v2459 = load i64, ptr %slot385, align 8
  %op2460 = sub i64 %v2458, %v2459
  store i64 %op2460, ptr %slot387, align 8
  %v2461 = load i64, ptr %slot385, align 8
  %v2462 = load i64, ptr %slot380, align 8
  %op2463 = sub i64 %v2461, %v2462
  store i64 %op2463, ptr %slot388, align 8
  %v2464 = load i64, ptr %slot387, align 8
  %cmp2465 = icmp ult i64 %v2464, 32
  %cv2466 = zext i1 %cmp2465 to i32
  store i32 %cv2466, ptr %slot389, align 8
  %v2467 = load i64, ptr %slot388, align 8
  %cmp2468 = icmp ult i64 %v2467, 32
  %cv2469 = zext i1 %cmp2468 to i32
  store i32 %cv2469, ptr %slot390, align 8
  %v2470 = load i32, ptr %slot389, align 8
  %v2471 = load i32, ptr %slot390, align 8
  %op2472 = or i32 %v2470, %v2471
  store i32 %op2472, ptr %slot391, align 8
  %v2473 = load i32, ptr %slot391, align 8
  %cv2474 = zext i32 %v2473 to i64
  %cond2475 = icmp ne i64 %cv2474, 0
  br i1 %cond2475, label %bb_rcmoveslow456, label %bb_rcmovecheck456
bb_rcmovecheck456:
  %v2476 = load i64, ptr %slot380, align 8
  %op2477 = add i64 %v2476, 0
  store i64 %op2477, ptr %slot392, align 8
  %v2478 = load i64, ptr %slot392, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  %ld2480 = load i64, ptr %p2479, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2480, ptr %slot393, align 8
  %v2481 = load i64, ptr %slot393, align 8
  %cmp2482 = icmp ne i64 %v2481, 0
  %cv2483 = zext i1 %cmp2482 to i32
  store i32 %cv2483, ptr %slot394, align 8
  %v2484 = load i32, ptr %slot394, align 8
  %cv2485 = zext i32 %v2484 to i64
  %cond2486 = icmp ne i64 %cv2485, 0
  br i1 %cond2486, label %bb_rcmoveheader464, label %bb_rcmovenext464
bb_rcmoveheader464:
  %v2487 = load i64, ptr %slot393, align 8
  %op2488 = sub i64 %v2487, 16
  store i64 %op2488, ptr %slot395, align 8
  %v2489 = load i64, ptr %slot393, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  %rgep2491 = getelementptr i8, ptr %p2490, i64 -16
  %ld2492 = load i64, ptr %rgep2491, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2492, ptr %slot396, align 8
  %v2493 = load i64, ptr %slot396, align 8
  %op2494 = and i64 %v2493, 5764607523034234881
  store i64 %op2494, ptr %slot397, align 8
  %v2495 = load i64, ptr %slot397, align 8
  %cmp2496 = icmp ne i64 %v2495, 0
  %cv2497 = zext i1 %cmp2496 to i32
  store i32 %cv2497, ptr %slot398, align 8
  %v2498 = load i32, ptr %slot398, align 8
  %cv2499 = zext i32 %v2498 to i64
  %cond2500 = icmp ne i64 %cv2499, 0
  br i1 %cond2500, label %bb_rcmoveslow456, label %bb_rcmovenext464
bb_rcmovenext464:
  %v2501 = load i64, ptr %slot380, align 8
  %v2502 = load i64, ptr %slot385, align 8
  %p2503 = inttoptr i64 %v2501 to ptr
  %p2504 = inttoptr i64 %v2502 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2504, ptr %p2503, i64 32, i1 false), !alias.scope !10000000
  %v2505 = load i64, ptr %slot380, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  store i64 0, ptr %p2506, align 8, !alias.scope !4, !noalias !3
  %v2507 = load i64, ptr %slot380, align 8
  %op2508 = add i64 %v2507, 8
  store i64 %op2508, ptr %slot399, align 8
  %v2509 = load i64, ptr %slot399, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  store i64 0, ptr %p2510, align 8, !alias.scope !4, !noalias !3
  %v2511 = load i64, ptr %slot380, align 8
  %op2512 = add i64 %v2511, 16
  store i64 %op2512, ptr %slot400, align 8
  %v2513 = load i64, ptr %slot400, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  store i64 0, ptr %p2514, align 8, !alias.scope !4, !noalias !3
  %v2515 = load i64, ptr %slot380, align 8
  %op2516 = add i64 %v2515, 24
  store i64 %op2516, ptr %slot401, align 8
  %v2517 = load i64, ptr %slot401, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  store i64 0, ptr %p2518, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved456
bb_rcmoveslow456:
  %v2519 = load i64, ptr %slot38, align 8
  %v2520 = load i64, ptr %slot385, align 8
  %v2521 = load i64, ptr %slot380, align 8
  %v2522 = load i64, ptr %slot386, align 8
  %cv2523 = trunc i64 %v2522 to i32
  %call2524 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v2519, i64 %v2520, i64 %v2521, i32 %cv2523) nomerge, !dbg !130
  store i32 %call2524, ptr %slot402, align 8
  %v2525 = load i32, ptr %slot402, align 8
  %cv2526 = zext i32 %v2525 to i64
  %cond2527 = icmp ne i64 %cv2526, 0
  br i1 %cond2527, label %bb_rcsuccess474, label %bb_rcfailure474
bb_rcfailure474:
  %v2528 = load i64, ptr %slot38, align 8
  %p2529 = inttoptr i64 %v2528 to ptr
  %call2530 = call i32 @myl_rc_take_failure(ptr %p2529) nomerge, !dbg !130
  store i32 %call2530, ptr %slot403, align 8
  %v2531 = load i64, ptr %slot1, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  %v2533 = load i32, ptr %slot403, align 8
  %call2534 = call i32 @myl_qbe_rc_status(ptr %p2532, i32 %v2533) nomerge, !dbg !130
  store i32 %call2534, ptr %slot404, align 8
  br label %bb_failure
bb_rcsuccess474:
  br label %bb_rcmoved456
bb_rcmoved456:
  %v2535 = load i64, ptr %slot13, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i32 0, ptr %p2536, align 4, !alias.scope !3, !noalias !4
  %v2537 = load i64, ptr %slot18, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i32 2, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot17, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  store i32 1, ptr %p2540, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared447
bb_rccopy447:
  %v2541 = load i64, ptr %slot23, align 8
  store i64 %v2541, ptr %slot405, align 8
  %v2542 = load i64, ptr %slot39, align 8
  store i64 %v2542, ptr %slot406, align 8
  %v2543 = load i64, ptr %slot38, align 8
  %v2544 = load i64, ptr %slot405, align 8
  %v2545 = load i64, ptr %slot380, align 8
  %v2546 = load i64, ptr %slot406, align 8
  %cv2547 = trunc i64 %v2546 to i32
  %call2548 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v2543, i64 %v2544, i64 %v2545, i32 %cv2547) nomerge, !dbg !130
  store i32 %call2548, ptr %slot407, align 8
  %v2549 = load i32, ptr %slot407, align 8
  %cv2550 = zext i32 %v2549 to i64
  %cond2551 = icmp ne i64 %cv2550, 0
  br i1 %cond2551, label %bb_rcsuccess483, label %bb_rcfailure483
bb_rcfailure483:
  %v2552 = load i64, ptr %slot38, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  %call2554 = call i32 @myl_rc_take_failure(ptr %p2553) nomerge, !dbg !130
  store i32 %call2554, ptr %slot408, align 8
  %v2555 = load i64, ptr %slot1, align 8
  %p2556 = inttoptr i64 %v2555 to ptr
  %v2557 = load i32, ptr %slot408, align 8
  %call2558 = call i32 @myl_qbe_rc_status(ptr %p2556, i32 %v2557) nomerge, !dbg !130
  store i32 %call2558, ptr %slot409, align 8
  br label %bb_failure
bb_rcsuccess483:
  %v2559 = load i64, ptr %slot18, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  store i32 2, ptr %p2560, align 4, !alias.scope !3, !noalias !4
  %v2561 = load i64, ptr %slot17, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  store i32 1, ptr %p2562, align 4, !alias.scope !3, !noalias !4
  %v2563 = load i64, ptr %slot13, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %ld2565 = load i32, ptr %p2564, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2565, ptr %slot410, align 8
  %v2566 = load i32, ptr %slot410, align 8
  %cv2567 = zext i32 %v2566 to i64
  %cond2568 = icmp ne i64 %cv2567, 0
  br i1 %cond2568, label %bb_rcslotdrop490, label %bb_rcslotdone490
bb_rcslotdrop490:
  %v2569 = load i64, ptr %slot13, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  store i32 0, ptr %p2570, align 4, !alias.scope !3, !noalias !4
  %v2571 = load i64, ptr %slot19, align 8
  store i64 %v2571, ptr %slot411, align 8
  %v2572 = load i64, ptr %slot14, align 8
  %p2573 = inttoptr i64 %v2572 to ptr
  %ld2574 = load i32, ptr %p2573, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2574, ptr %slot412, align 8
  %v2575 = load i32, ptr %slot412, align 8
  %op2576 = and i32 %v2575, 28
  store i32 %op2576, ptr %slot413, align 8
  %v2577 = load i32, ptr %slot413, align 8
  %cv2578 = zext i32 %v2577 to i64
  %cond2579 = icmp ne i64 %cv2578, 0
  br i1 %cond2579, label %bb_rcslotrole490, label %bb_rcslotowner490
bb_rcslotrole490:
  %v2580 = load i64, ptr %slot38, align 8
  store i64 %v2580, ptr %slot414, align 8
  %v2581 = load i64, ptr %slot414, align 8
  %v2582 = load i64, ptr %slot411, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2581, i64 %v2582) nomerge, !dbg !130
  br label %bb_rcslotdone490
bb_rcslotowner490:
  %v2583 = load i64, ptr %slot411, align 8
  %p2585 = inttoptr i64 %v2583 to ptr
  %gep2586 = getelementptr i8, ptr %p2585, i64 0
  %op2584 = ptrtoint ptr %gep2586 to i64
  store i64 %op2584, ptr %slot415, align 8
  %v2587 = load i64, ptr %slot38, align 8
  store i64 %v2587, ptr %slot416, align 8
  %v2588 = load i64, ptr %slot415, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  %ld2590 = load i64, ptr %p2589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2590, ptr %slot417, align 8
  %v2591 = load i64, ptr %slot417, align 8
  %cmp2592 = icmp ne i64 %v2591, 0
  %cv2593 = zext i1 %cmp2592 to i32
  store i32 %cv2593, ptr %slot418, align 8
  %v2594 = load i32, ptr %slot418, align 8
  %cv2595 = zext i32 %v2594 to i64
  %cond2596 = icmp ne i64 %cv2595, 0
  br i1 %cond2596, label %bb_rcgnn508, label %bb_rcgdone508
bb_rcgnn508:
  %v2597 = load i64, ptr %slot417, align 8
  %op2598 = sub i64 %v2597, 16
  store i64 %op2598, ptr %slot419, align 8
  %v2599 = load i64, ptr %slot417, align 8
  %p2600 = inttoptr i64 %v2599 to ptr
  %rgep2601 = getelementptr i8, ptr %p2600, i64 -16
  %ld2602 = load i64, ptr %rgep2601, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2602, ptr %slot420, align 8
  %v2603 = load i64, ptr %slot420, align 8
  %op2604 = and i64 %v2603, 4611686018427387906
  store i64 %op2604, ptr %slot421, align 8
  %v2605 = load i64, ptr %slot421, align 8
  %cmp2606 = icmp ne i64 %v2605, 0
  %cv2607 = zext i1 %cmp2606 to i32
  store i32 %cv2607, ptr %slot422, align 8
  %v2608 = load i32, ptr %slot422, align 8
  %cv2609 = zext i32 %v2608 to i64
  %cond2610 = icmp ne i64 %cv2609, 0
  br i1 %cond2610, label %bb_rcgclear508, label %bb_rcgcounted508
bb_rcgcounted508:
  %v2611 = load i64, ptr %slot417, align 8
  %op2612 = sub i64 %v2611, 32
  store i64 %op2612, ptr %slot423, align 8
  %v2613 = load i64, ptr %slot417, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  %rgep2615 = getelementptr i8, ptr %p2614, i64 -32
  %ld2616 = load i64, ptr %rgep2615, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2616, ptr %slot424, align 8
  %v2617 = load i64, ptr %slot424, align 8
  %op2618 = sub i64 %v2617, 1
  store i64 %op2618, ptr %slot425, align 8
  %v2619 = load i64, ptr %slot425, align 8
  %cmp2620 = icmp eq i64 %v2619, 0
  %cv2621 = zext i1 %cmp2620 to i32
  store i32 %cv2621, ptr %slot426, align 8
  %v2622 = load i32, ptr %slot426, align 8
  %cv2623 = zext i32 %v2622 to i64
  %cond2624 = icmp ne i64 %cv2623, 0
  br i1 %cond2624, label %bb_rcglast508, label %bb_rcgdec508
bb_rcglast508:
  %v2625 = load i64, ptr %slot417, align 8
  %op2626 = sub i64 %v2625, 24
  store i64 %op2626, ptr %slot427, align 8
  %v2627 = load i64, ptr %slot417, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  %rgep2629 = getelementptr i8, ptr %p2628, i64 -24
  %ld2630 = load i64, ptr %rgep2629, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2630, ptr %slot428, align 8
  %v2631 = load i64, ptr %slot428, align 8
  %cmp2632 = icmp ne i64 %v2631, 0
  %cv2633 = zext i1 %cmp2632 to i32
  store i32 %cv2633, ptr %slot429, align 8
  %v2634 = load i32, ptr %slot429, align 8
  %cv2635 = zext i32 %v2634 to i64
  %cond2636 = icmp ne i64 %cv2635, 0
  br i1 %cond2636, label %bb_rcgdec508, label %bb_rcgslow508
bb_rcgslow508:
  %v2637 = load i64, ptr %slot416, align 8
  %v2638 = load i64, ptr %slot415, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2637, i64 %v2638) nomerge, !dbg !130
  br label %bb_rcgdone508
bb_rcgdec508:
  %v2639 = load i64, ptr %slot425, align 8
  %v2640 = load i64, ptr %slot417, align 8
  %p2641 = inttoptr i64 %v2640 to ptr
  %rgep2642 = getelementptr i8, ptr %p2641, i64 -32
  store i64 %v2639, ptr %rgep2642, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear508
bb_rcgclear508:
  %v2643 = load i64, ptr %slot415, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  store i64 0, ptr %p2644, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone508
bb_rcgdone508:
  %v2645 = load i64, ptr %slot411, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  store i64 0, ptr %p2646, align 8, !alias.scope !3, !noalias !4
  %v2647 = load i64, ptr %slot411, align 8
  %p2649 = inttoptr i64 %v2647 to ptr
  %gep2650 = getelementptr i8, ptr %p2649, i64 8
  %op2648 = ptrtoint ptr %gep2650 to i64
  store i64 %op2648, ptr %slot430, align 8
  %v2651 = load i64, ptr %slot430, align 8
  %p2652 = inttoptr i64 %v2651 to ptr
  store i64 0, ptr %p2652, align 8, !alias.scope !3, !noalias !4
  %v2653 = load i64, ptr %slot411, align 8
  %p2655 = inttoptr i64 %v2653 to ptr
  %gep2656 = getelementptr i8, ptr %p2655, i64 16
  %op2654 = ptrtoint ptr %gep2656 to i64
  store i64 %op2654, ptr %slot431, align 8
  %v2657 = load i64, ptr %slot431, align 8
  %p2658 = inttoptr i64 %v2657 to ptr
  store i64 0, ptr %p2658, align 8, !alias.scope !3, !noalias !4
  %v2659 = load i64, ptr %slot411, align 8
  %p2661 = inttoptr i64 %v2659 to ptr
  %gep2662 = getelementptr i8, ptr %p2661, i64 24
  %op2660 = ptrtoint ptr %gep2662 to i64
  store i64 %op2660, ptr %slot432, align 8
  %v2663 = load i64, ptr %slot432, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  store i64 0, ptr %p2664, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone490
bb_rcslotdone490:
  br label %bb_rcprepared447
bb_rcprepared447:
  %v2665 = load i64, ptr %slot9, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  %ld2667 = load i32, ptr %p2666, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2667, ptr %slot433, align 8
  %v2668 = load i32, ptr %slot433, align 8
  %cv2669 = zext i32 %v2668 to i64
  %cond2670 = icmp ne i64 %cv2669, 0
  br i1 %cond2670, label %bb_rcslotdrop518, label %bb_rcslotdone518
bb_rcslotdrop518:
  %v2671 = load i64, ptr %slot9, align 8
  %p2672 = inttoptr i64 %v2671 to ptr
  store i32 0, ptr %p2672, align 4, !alias.scope !3, !noalias !4
  %v2673 = load i64, ptr %slot29, align 8
  store i64 %v2673, ptr %slot434, align 8
  %v2674 = load i64, ptr %slot10, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  %ld2676 = load i32, ptr %p2675, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2676, ptr %slot435, align 8
  %v2677 = load i32, ptr %slot435, align 8
  %op2678 = and i32 %v2677, 28
  store i32 %op2678, ptr %slot436, align 8
  %v2679 = load i32, ptr %slot436, align 8
  %cv2680 = zext i32 %v2679 to i64
  %cond2681 = icmp ne i64 %cv2680, 0
  br i1 %cond2681, label %bb_rcslotrole518, label %bb_rcslotowner518
bb_rcslotrole518:
  %v2682 = load i64, ptr %slot38, align 8
  store i64 %v2682, ptr %slot437, align 8
  %v2683 = load i64, ptr %slot437, align 8
  %v2684 = load i64, ptr %slot434, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2683, i64 %v2684) nomerge, !dbg !130
  br label %bb_rcslotdone518
bb_rcslotowner518:
  %v2685 = load i64, ptr %slot434, align 8
  %p2687 = inttoptr i64 %v2685 to ptr
  %gep2688 = getelementptr i8, ptr %p2687, i64 0
  %op2686 = ptrtoint ptr %gep2688 to i64
  store i64 %op2686, ptr %slot438, align 8
  %v2689 = load i64, ptr %slot38, align 8
  store i64 %v2689, ptr %slot439, align 8
  %v2690 = load i64, ptr %slot438, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %ld2692 = load i64, ptr %p2691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2692, ptr %slot440, align 8
  %v2693 = load i64, ptr %slot440, align 8
  %cmp2694 = icmp ne i64 %v2693, 0
  %cv2695 = zext i1 %cmp2694 to i32
  store i32 %cv2695, ptr %slot441, align 8
  %v2696 = load i32, ptr %slot441, align 8
  %cv2697 = zext i32 %v2696 to i64
  %cond2698 = icmp ne i64 %cv2697, 0
  br i1 %cond2698, label %bb_rcgnn536, label %bb_rcgdone536
bb_rcgnn536:
  %v2699 = load i64, ptr %slot440, align 8
  %op2700 = sub i64 %v2699, 16
  store i64 %op2700, ptr %slot442, align 8
  %v2701 = load i64, ptr %slot440, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  %rgep2703 = getelementptr i8, ptr %p2702, i64 -16
  %ld2704 = load i64, ptr %rgep2703, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2704, ptr %slot443, align 8
  %v2705 = load i64, ptr %slot443, align 8
  %op2706 = and i64 %v2705, 4611686018427387906
  store i64 %op2706, ptr %slot444, align 8
  %v2707 = load i64, ptr %slot444, align 8
  %cmp2708 = icmp ne i64 %v2707, 0
  %cv2709 = zext i1 %cmp2708 to i32
  store i32 %cv2709, ptr %slot445, align 8
  %v2710 = load i32, ptr %slot445, align 8
  %cv2711 = zext i32 %v2710 to i64
  %cond2712 = icmp ne i64 %cv2711, 0
  br i1 %cond2712, label %bb_rcgclear536, label %bb_rcgcounted536
bb_rcgcounted536:
  %v2713 = load i64, ptr %slot440, align 8
  %op2714 = sub i64 %v2713, 32
  store i64 %op2714, ptr %slot446, align 8
  %v2715 = load i64, ptr %slot440, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  %rgep2717 = getelementptr i8, ptr %p2716, i64 -32
  %ld2718 = load i64, ptr %rgep2717, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2718, ptr %slot447, align 8
  %v2719 = load i64, ptr %slot447, align 8
  %op2720 = sub i64 %v2719, 1
  store i64 %op2720, ptr %slot448, align 8
  %v2721 = load i64, ptr %slot448, align 8
  %cmp2722 = icmp eq i64 %v2721, 0
  %cv2723 = zext i1 %cmp2722 to i32
  store i32 %cv2723, ptr %slot449, align 8
  %v2724 = load i32, ptr %slot449, align 8
  %cv2725 = zext i32 %v2724 to i64
  %cond2726 = icmp ne i64 %cv2725, 0
  br i1 %cond2726, label %bb_rcglast536, label %bb_rcgdec536
bb_rcglast536:
  %v2727 = load i64, ptr %slot440, align 8
  %op2728 = sub i64 %v2727, 24
  store i64 %op2728, ptr %slot450, align 8
  %v2729 = load i64, ptr %slot440, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  %rgep2731 = getelementptr i8, ptr %p2730, i64 -24
  %ld2732 = load i64, ptr %rgep2731, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2732, ptr %slot451, align 8
  %v2733 = load i64, ptr %slot451, align 8
  %cmp2734 = icmp ne i64 %v2733, 0
  %cv2735 = zext i1 %cmp2734 to i32
  store i32 %cv2735, ptr %slot452, align 8
  %v2736 = load i32, ptr %slot452, align 8
  %cv2737 = zext i32 %v2736 to i64
  %cond2738 = icmp ne i64 %cv2737, 0
  br i1 %cond2738, label %bb_rcgdec536, label %bb_rcgslow536
bb_rcgslow536:
  %v2739 = load i64, ptr %slot439, align 8
  %v2740 = load i64, ptr %slot438, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2739, i64 %v2740) nomerge, !dbg !130
  br label %bb_rcgdone536
bb_rcgdec536:
  %v2741 = load i64, ptr %slot448, align 8
  %v2742 = load i64, ptr %slot440, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  %rgep2744 = getelementptr i8, ptr %p2743, i64 -32
  store i64 %v2741, ptr %rgep2744, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear536
bb_rcgclear536:
  %v2745 = load i64, ptr %slot438, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  store i64 0, ptr %p2746, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone536
bb_rcgdone536:
  %v2747 = load i64, ptr %slot434, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  store i64 0, ptr %p2748, align 8, !alias.scope !3, !noalias !4
  %v2749 = load i64, ptr %slot434, align 8
  %p2751 = inttoptr i64 %v2749 to ptr
  %gep2752 = getelementptr i8, ptr %p2751, i64 8
  %op2750 = ptrtoint ptr %gep2752 to i64
  store i64 %op2750, ptr %slot453, align 8
  %v2753 = load i64, ptr %slot453, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  store i64 0, ptr %p2754, align 8, !alias.scope !3, !noalias !4
  %v2755 = load i64, ptr %slot434, align 8
  %p2757 = inttoptr i64 %v2755 to ptr
  %gep2758 = getelementptr i8, ptr %p2757, i64 16
  %op2756 = ptrtoint ptr %gep2758 to i64
  store i64 %op2756, ptr %slot454, align 8
  %v2759 = load i64, ptr %slot454, align 8
  %p2760 = inttoptr i64 %v2759 to ptr
  store i64 0, ptr %p2760, align 8, !alias.scope !3, !noalias !4
  %v2761 = load i64, ptr %slot434, align 8
  %p2763 = inttoptr i64 %v2761 to ptr
  %gep2764 = getelementptr i8, ptr %p2763, i64 24
  %op2762 = ptrtoint ptr %gep2764 to i64
  store i64 %op2762, ptr %slot455, align 8
  %v2765 = load i64, ptr %slot455, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  store i64 0, ptr %p2766, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone518
bb_rcslotdone518:
  %v2767 = load i64, ptr %slot29, align 8
  store i64 %v2767, ptr %slot456, align 8
  %v2768 = load i64, ptr %slot23, align 8
  store i64 %v2768, ptr %slot457, align 8
  %v2769 = load i64, ptr %slot457, align 8
  %v2770 = load i64, ptr %slot456, align 8
  %p2771 = inttoptr i64 %v2769 to ptr
  %p2772 = inttoptr i64 %v2770 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2772, ptr %p2771, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2773 = load i64, ptr %slot17, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i32 0, ptr %p2774, align 4, !alias.scope !3, !noalias !4
  %v2775 = load i64, ptr %slot10, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  store i32 2, ptr %p2776, align 4, !alias.scope !3, !noalias !4
  %v2777 = load i64, ptr %slot18, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %ld2779 = load i32, ptr %p2778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2779, ptr %slot458, align 8
  %v2780 = load i32, ptr %slot458, align 8
  %v2781 = load i64, ptr %slot10, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  store i32 %v2780, ptr %p2782, align 4, !alias.scope !3, !noalias !4
  %v2783 = load i64, ptr %slot9, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  store i32 1, ptr %p2784, align 4, !alias.scope !3, !noalias !4
  %v2785 = load i64, ptr %slot29, align 8
  %v2786 = load i64, ptr %slot32, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  store i64 %v2785, ptr %p2787, align 8, !alias.scope !3, !noalias !4
  %v2788 = load i64, ptr %slot32, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  %ld2790 = load i64, ptr %p2789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2790, ptr %slot459, align 8
  %v2791 = load i64, ptr %slot13, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %ld2793 = load i32, ptr %p2792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2793, ptr %slot460, align 8
  %v2794 = load i64, ptr %slot14, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %ld2796 = load i32, ptr %p2795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2796, ptr %slot461, align 8
  %v2797 = load i32, ptr %slot461, align 8
  %op2798 = and i32 %v2797, 24
  store i32 %op2798, ptr %slot461, align 8
  %v2799 = load i32, ptr %slot461, align 8
  %cmp2800 = icmp eq i32 %v2799, 0
  %cv2801 = zext i1 %cmp2800 to i32
  store i32 %cv2801, ptr %slot462, align 8
  %v2802 = load i32, ptr %slot460, align 8
  %v2803 = load i32, ptr %slot462, align 8
  %op2804 = and i32 %v2802, %v2803
  store i32 %op2804, ptr %slot463, align 8
  %v2805 = load i32, ptr %slot463, align 8
  %cv2806 = zext i32 %v2805 to i64
  %cond2807 = icmp ne i64 %cv2806, 0
  br i1 %cond2807, label %bb_rctake551, label %bb_rccopy551
bb_rctake551:
  %v2808 = load i64, ptr %slot23, align 8
  store i64 %v2808, ptr %slot464, align 8
  %v2809 = load i64, ptr %slot39, align 8
  store i64 %v2809, ptr %slot465, align 8
  %v2810 = load i64, ptr %slot459, align 8
  %v2811 = load i64, ptr %slot464, align 8
  %op2812 = sub i64 %v2810, %v2811
  store i64 %op2812, ptr %slot466, align 8
  %v2813 = load i64, ptr %slot464, align 8
  %v2814 = load i64, ptr %slot459, align 8
  %op2815 = sub i64 %v2813, %v2814
  store i64 %op2815, ptr %slot467, align 8
  %v2816 = load i64, ptr %slot466, align 8
  %cmp2817 = icmp ult i64 %v2816, 32
  %cv2818 = zext i1 %cmp2817 to i32
  store i32 %cv2818, ptr %slot468, align 8
  %v2819 = load i64, ptr %slot467, align 8
  %cmp2820 = icmp ult i64 %v2819, 32
  %cv2821 = zext i1 %cmp2820 to i32
  store i32 %cv2821, ptr %slot469, align 8
  %v2822 = load i32, ptr %slot468, align 8
  %v2823 = load i32, ptr %slot469, align 8
  %op2824 = or i32 %v2822, %v2823
  store i32 %op2824, ptr %slot470, align 8
  %v2825 = load i32, ptr %slot470, align 8
  %cv2826 = zext i32 %v2825 to i64
  %cond2827 = icmp ne i64 %cv2826, 0
  br i1 %cond2827, label %bb_rcmoveslow560, label %bb_rcmovecheck560
bb_rcmovecheck560:
  %v2828 = load i64, ptr %slot459, align 8
  %op2829 = add i64 %v2828, 0
  store i64 %op2829, ptr %slot471, align 8
  %v2830 = load i64, ptr %slot471, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  %ld2832 = load i64, ptr %p2831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2832, ptr %slot472, align 8
  %v2833 = load i64, ptr %slot472, align 8
  %cmp2834 = icmp ne i64 %v2833, 0
  %cv2835 = zext i1 %cmp2834 to i32
  store i32 %cv2835, ptr %slot473, align 8
  %v2836 = load i32, ptr %slot473, align 8
  %cv2837 = zext i32 %v2836 to i64
  %cond2838 = icmp ne i64 %cv2837, 0
  br i1 %cond2838, label %bb_rcmoveheader568, label %bb_rcmovenext568
bb_rcmoveheader568:
  %v2839 = load i64, ptr %slot472, align 8
  %op2840 = sub i64 %v2839, 16
  store i64 %op2840, ptr %slot474, align 8
  %v2841 = load i64, ptr %slot472, align 8
  %p2842 = inttoptr i64 %v2841 to ptr
  %rgep2843 = getelementptr i8, ptr %p2842, i64 -16
  %ld2844 = load i64, ptr %rgep2843, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2844, ptr %slot475, align 8
  %v2845 = load i64, ptr %slot475, align 8
  %op2846 = and i64 %v2845, 5764607523034234881
  store i64 %op2846, ptr %slot476, align 8
  %v2847 = load i64, ptr %slot476, align 8
  %cmp2848 = icmp ne i64 %v2847, 0
  %cv2849 = zext i1 %cmp2848 to i32
  store i32 %cv2849, ptr %slot477, align 8
  %v2850 = load i32, ptr %slot477, align 8
  %cv2851 = zext i32 %v2850 to i64
  %cond2852 = icmp ne i64 %cv2851, 0
  br i1 %cond2852, label %bb_rcmoveslow560, label %bb_rcmovenext568
bb_rcmovenext568:
  %v2853 = load i64, ptr %slot459, align 8
  %v2854 = load i64, ptr %slot464, align 8
  %p2855 = inttoptr i64 %v2853 to ptr
  %p2856 = inttoptr i64 %v2854 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2856, ptr %p2855, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2857 = load i64, ptr %slot459, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  store i64 0, ptr %p2858, align 8, !alias.scope !3, !noalias !4
  %v2859 = load i64, ptr %slot459, align 8
  %op2860 = add i64 %v2859, 8
  store i64 %op2860, ptr %slot478, align 8
  %v2861 = load i64, ptr %slot478, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  store i64 0, ptr %p2862, align 8, !alias.scope !3, !noalias !4
  %v2863 = load i64, ptr %slot459, align 8
  %op2864 = add i64 %v2863, 16
  store i64 %op2864, ptr %slot479, align 8
  %v2865 = load i64, ptr %slot479, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  store i64 0, ptr %p2866, align 8, !alias.scope !3, !noalias !4
  %v2867 = load i64, ptr %slot459, align 8
  %op2868 = add i64 %v2867, 24
  store i64 %op2868, ptr %slot480, align 8
  %v2869 = load i64, ptr %slot480, align 8
  %p2870 = inttoptr i64 %v2869 to ptr
  store i64 0, ptr %p2870, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved560
bb_rcmoveslow560:
  %v2871 = load i64, ptr %slot38, align 8
  %v2872 = load i64, ptr %slot464, align 8
  %v2873 = load i64, ptr %slot459, align 8
  %v2874 = load i64, ptr %slot465, align 8
  %cv2875 = trunc i64 %v2874 to i32
  %call2876 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v2871, i64 %v2872, i64 %v2873, i32 %cv2875) nomerge, !dbg !132
  store i32 %call2876, ptr %slot481, align 8
  %v2877 = load i32, ptr %slot481, align 8
  %cv2878 = zext i32 %v2877 to i64
  %cond2879 = icmp ne i64 %cv2878, 0
  br i1 %cond2879, label %bb_rcsuccess578, label %bb_rcfailure578
bb_rcfailure578:
  %v2880 = load i64, ptr %slot38, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  %call2882 = call i32 @myl_rc_take_failure(ptr %p2881) nomerge, !dbg !132
  store i32 %call2882, ptr %slot482, align 8
  %v2883 = load i64, ptr %slot1, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  %v2885 = load i32, ptr %slot482, align 8
  %call2886 = call i32 @myl_qbe_rc_status(ptr %p2884, i32 %v2885) nomerge, !dbg !132
  store i32 %call2886, ptr %slot483, align 8
  br label %bb_failure
bb_rcsuccess578:
  br label %bb_rcmoved560
bb_rcmoved560:
  %v2887 = load i64, ptr %slot13, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  store i32 0, ptr %p2888, align 4, !alias.scope !3, !noalias !4
  %v2889 = load i64, ptr %slot18, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  store i32 2, ptr %p2890, align 4, !alias.scope !3, !noalias !4
  %v2891 = load i64, ptr %slot17, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  store i32 1, ptr %p2892, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared551
bb_rccopy551:
  %v2893 = load i64, ptr %slot23, align 8
  store i64 %v2893, ptr %slot484, align 8
  %v2894 = load i64, ptr %slot39, align 8
  store i64 %v2894, ptr %slot485, align 8
  %v2895 = load i64, ptr %slot38, align 8
  %v2896 = load i64, ptr %slot484, align 8
  %v2897 = load i64, ptr %slot459, align 8
  %v2898 = load i64, ptr %slot485, align 8
  %cv2899 = trunc i64 %v2898 to i32
  %call2900 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v2895, i64 %v2896, i64 %v2897, i32 %cv2899) nomerge, !dbg !132
  store i32 %call2900, ptr %slot486, align 8
  %v2901 = load i32, ptr %slot486, align 8
  %cv2902 = zext i32 %v2901 to i64
  %cond2903 = icmp ne i64 %cv2902, 0
  br i1 %cond2903, label %bb_rcsuccess587, label %bb_rcfailure587
bb_rcfailure587:
  %v2904 = load i64, ptr %slot38, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  %call2906 = call i32 @myl_rc_take_failure(ptr %p2905) nomerge, !dbg !132
  store i32 %call2906, ptr %slot487, align 8
  %v2907 = load i64, ptr %slot1, align 8
  %p2908 = inttoptr i64 %v2907 to ptr
  %v2909 = load i32, ptr %slot487, align 8
  %call2910 = call i32 @myl_qbe_rc_status(ptr %p2908, i32 %v2909) nomerge, !dbg !132
  store i32 %call2910, ptr %slot488, align 8
  br label %bb_failure
bb_rcsuccess587:
  %v2911 = load i64, ptr %slot18, align 8
  %p2912 = inttoptr i64 %v2911 to ptr
  store i32 2, ptr %p2912, align 4, !alias.scope !3, !noalias !4
  %v2913 = load i64, ptr %slot17, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  store i32 1, ptr %p2914, align 4, !alias.scope !3, !noalias !4
  %v2915 = load i64, ptr %slot13, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %ld2917 = load i32, ptr %p2916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2917, ptr %slot489, align 8
  %v2918 = load i32, ptr %slot489, align 8
  %cv2919 = zext i32 %v2918 to i64
  %cond2920 = icmp ne i64 %cv2919, 0
  br i1 %cond2920, label %bb_rcslotdrop594, label %bb_rcslotdone594
bb_rcslotdrop594:
  %v2921 = load i64, ptr %slot13, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  store i32 0, ptr %p2922, align 4, !alias.scope !3, !noalias !4
  %v2923 = load i64, ptr %slot19, align 8
  store i64 %v2923, ptr %slot490, align 8
  %v2924 = load i64, ptr %slot14, align 8
  %p2925 = inttoptr i64 %v2924 to ptr
  %ld2926 = load i32, ptr %p2925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2926, ptr %slot491, align 8
  %v2927 = load i32, ptr %slot491, align 8
  %op2928 = and i32 %v2927, 28
  store i32 %op2928, ptr %slot492, align 8
  %v2929 = load i32, ptr %slot492, align 8
  %cv2930 = zext i32 %v2929 to i64
  %cond2931 = icmp ne i64 %cv2930, 0
  br i1 %cond2931, label %bb_rcslotrole594, label %bb_rcslotowner594
bb_rcslotrole594:
  %v2932 = load i64, ptr %slot38, align 8
  store i64 %v2932, ptr %slot493, align 8
  %v2933 = load i64, ptr %slot493, align 8
  %v2934 = load i64, ptr %slot490, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2933, i64 %v2934) nomerge, !dbg !132
  br label %bb_rcslotdone594
bb_rcslotowner594:
  %v2935 = load i64, ptr %slot490, align 8
  %p2937 = inttoptr i64 %v2935 to ptr
  %gep2938 = getelementptr i8, ptr %p2937, i64 0
  %op2936 = ptrtoint ptr %gep2938 to i64
  store i64 %op2936, ptr %slot494, align 8
  %v2939 = load i64, ptr %slot38, align 8
  store i64 %v2939, ptr %slot495, align 8
  %v2940 = load i64, ptr %slot494, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  %ld2942 = load i64, ptr %p2941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2942, ptr %slot496, align 8
  %v2943 = load i64, ptr %slot496, align 8
  %cmp2944 = icmp ne i64 %v2943, 0
  %cv2945 = zext i1 %cmp2944 to i32
  store i32 %cv2945, ptr %slot497, align 8
  %v2946 = load i32, ptr %slot497, align 8
  %cv2947 = zext i32 %v2946 to i64
  %cond2948 = icmp ne i64 %cv2947, 0
  br i1 %cond2948, label %bb_rcgnn612, label %bb_rcgdone612
bb_rcgnn612:
  %v2949 = load i64, ptr %slot496, align 8
  %op2950 = sub i64 %v2949, 16
  store i64 %op2950, ptr %slot498, align 8
  %v2951 = load i64, ptr %slot496, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %rgep2953 = getelementptr i8, ptr %p2952, i64 -16
  %ld2954 = load i64, ptr %rgep2953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2954, ptr %slot499, align 8
  %v2955 = load i64, ptr %slot499, align 8
  %op2956 = and i64 %v2955, 4611686018427387906
  store i64 %op2956, ptr %slot500, align 8
  %v2957 = load i64, ptr %slot500, align 8
  %cmp2958 = icmp ne i64 %v2957, 0
  %cv2959 = zext i1 %cmp2958 to i32
  store i32 %cv2959, ptr %slot501, align 8
  %v2960 = load i32, ptr %slot501, align 8
  %cv2961 = zext i32 %v2960 to i64
  %cond2962 = icmp ne i64 %cv2961, 0
  br i1 %cond2962, label %bb_rcgclear612, label %bb_rcgcounted612
bb_rcgcounted612:
  %v2963 = load i64, ptr %slot496, align 8
  %op2964 = sub i64 %v2963, 32
  store i64 %op2964, ptr %slot502, align 8
  %v2965 = load i64, ptr %slot496, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  %rgep2967 = getelementptr i8, ptr %p2966, i64 -32
  %ld2968 = load i64, ptr %rgep2967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2968, ptr %slot503, align 8
  %v2969 = load i64, ptr %slot503, align 8
  %op2970 = sub i64 %v2969, 1
  store i64 %op2970, ptr %slot504, align 8
  %v2971 = load i64, ptr %slot504, align 8
  %cmp2972 = icmp eq i64 %v2971, 0
  %cv2973 = zext i1 %cmp2972 to i32
  store i32 %cv2973, ptr %slot505, align 8
  %v2974 = load i32, ptr %slot505, align 8
  %cv2975 = zext i32 %v2974 to i64
  %cond2976 = icmp ne i64 %cv2975, 0
  br i1 %cond2976, label %bb_rcglast612, label %bb_rcgdec612
bb_rcglast612:
  %v2977 = load i64, ptr %slot496, align 8
  %op2978 = sub i64 %v2977, 24
  store i64 %op2978, ptr %slot506, align 8
  %v2979 = load i64, ptr %slot496, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  %rgep2981 = getelementptr i8, ptr %p2980, i64 -24
  %ld2982 = load i64, ptr %rgep2981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2982, ptr %slot507, align 8
  %v2983 = load i64, ptr %slot507, align 8
  %cmp2984 = icmp ne i64 %v2983, 0
  %cv2985 = zext i1 %cmp2984 to i32
  store i32 %cv2985, ptr %slot508, align 8
  %v2986 = load i32, ptr %slot508, align 8
  %cv2987 = zext i32 %v2986 to i64
  %cond2988 = icmp ne i64 %cv2987, 0
  br i1 %cond2988, label %bb_rcgdec612, label %bb_rcgslow612
bb_rcgslow612:
  %v2989 = load i64, ptr %slot495, align 8
  %v2990 = load i64, ptr %slot494, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2989, i64 %v2990) nomerge, !dbg !132
  br label %bb_rcgdone612
bb_rcgdec612:
  %v2991 = load i64, ptr %slot504, align 8
  %v2992 = load i64, ptr %slot496, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  %rgep2994 = getelementptr i8, ptr %p2993, i64 -32
  store i64 %v2991, ptr %rgep2994, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear612
bb_rcgclear612:
  %v2995 = load i64, ptr %slot494, align 8
  %p2996 = inttoptr i64 %v2995 to ptr
  store i64 0, ptr %p2996, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone612
bb_rcgdone612:
  %v2997 = load i64, ptr %slot490, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  store i64 0, ptr %p2998, align 8, !alias.scope !3, !noalias !4
  %v2999 = load i64, ptr %slot490, align 8
  %p3001 = inttoptr i64 %v2999 to ptr
  %gep3002 = getelementptr i8, ptr %p3001, i64 8
  %op3000 = ptrtoint ptr %gep3002 to i64
  store i64 %op3000, ptr %slot509, align 8
  %v3003 = load i64, ptr %slot509, align 8
  %p3004 = inttoptr i64 %v3003 to ptr
  store i64 0, ptr %p3004, align 8, !alias.scope !3, !noalias !4
  %v3005 = load i64, ptr %slot490, align 8
  %p3007 = inttoptr i64 %v3005 to ptr
  %gep3008 = getelementptr i8, ptr %p3007, i64 16
  %op3006 = ptrtoint ptr %gep3008 to i64
  store i64 %op3006, ptr %slot510, align 8
  %v3009 = load i64, ptr %slot510, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  store i64 0, ptr %p3010, align 8, !alias.scope !3, !noalias !4
  %v3011 = load i64, ptr %slot490, align 8
  %p3013 = inttoptr i64 %v3011 to ptr
  %gep3014 = getelementptr i8, ptr %p3013, i64 24
  %op3012 = ptrtoint ptr %gep3014 to i64
  store i64 %op3012, ptr %slot511, align 8
  %v3015 = load i64, ptr %slot511, align 8
  %p3016 = inttoptr i64 %v3015 to ptr
  store i64 0, ptr %p3016, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone594
bb_rcslotdone594:
  br label %bb_rcprepared551
bb_rcprepared551:
  %v3017 = load i64, ptr %slot11, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  %ld3019 = load i32, ptr %p3018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3019, ptr %slot512, align 8
  %v3020 = load i32, ptr %slot512, align 8
  %cv3021 = zext i32 %v3020 to i64
  %cond3022 = icmp ne i64 %cv3021, 0
  br i1 %cond3022, label %bb_rcslotdrop622, label %bb_rcslotdone622
bb_rcslotdrop622:
  %v3023 = load i64, ptr %slot11, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  store i32 0, ptr %p3024, align 4, !alias.scope !3, !noalias !4
  %v3025 = load i64, ptr %slot30, align 8
  store i64 %v3025, ptr %slot513, align 8
  %v3026 = load i64, ptr %slot12, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %ld3028 = load i32, ptr %p3027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3028, ptr %slot514, align 8
  %v3029 = load i32, ptr %slot514, align 8
  %op3030 = and i32 %v3029, 28
  store i32 %op3030, ptr %slot515, align 8
  %v3031 = load i32, ptr %slot515, align 8
  %cv3032 = zext i32 %v3031 to i64
  %cond3033 = icmp ne i64 %cv3032, 0
  br i1 %cond3033, label %bb_rcslotrole622, label %bb_rcslotowner622
bb_rcslotrole622:
  %v3034 = load i64, ptr %slot38, align 8
  store i64 %v3034, ptr %slot516, align 8
  %v3035 = load i64, ptr %slot516, align 8
  %v3036 = load i64, ptr %slot513, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3035, i64 %v3036) nomerge, !dbg !132
  br label %bb_rcslotdone622
bb_rcslotowner622:
  %v3037 = load i64, ptr %slot513, align 8
  %p3039 = inttoptr i64 %v3037 to ptr
  %gep3040 = getelementptr i8, ptr %p3039, i64 0
  %op3038 = ptrtoint ptr %gep3040 to i64
  store i64 %op3038, ptr %slot517, align 8
  %v3041 = load i64, ptr %slot38, align 8
  store i64 %v3041, ptr %slot518, align 8
  %v3042 = load i64, ptr %slot517, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  %ld3044 = load i64, ptr %p3043, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3044, ptr %slot519, align 8
  %v3045 = load i64, ptr %slot519, align 8
  %cmp3046 = icmp ne i64 %v3045, 0
  %cv3047 = zext i1 %cmp3046 to i32
  store i32 %cv3047, ptr %slot520, align 8
  %v3048 = load i32, ptr %slot520, align 8
  %cv3049 = zext i32 %v3048 to i64
  %cond3050 = icmp ne i64 %cv3049, 0
  br i1 %cond3050, label %bb_rcgnn640, label %bb_rcgdone640
bb_rcgnn640:
  %v3051 = load i64, ptr %slot519, align 8
  %op3052 = sub i64 %v3051, 16
  store i64 %op3052, ptr %slot521, align 8
  %v3053 = load i64, ptr %slot519, align 8
  %p3054 = inttoptr i64 %v3053 to ptr
  %rgep3055 = getelementptr i8, ptr %p3054, i64 -16
  %ld3056 = load i64, ptr %rgep3055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3056, ptr %slot522, align 8
  %v3057 = load i64, ptr %slot522, align 8
  %op3058 = and i64 %v3057, 4611686018427387906
  store i64 %op3058, ptr %slot523, align 8
  %v3059 = load i64, ptr %slot523, align 8
  %cmp3060 = icmp ne i64 %v3059, 0
  %cv3061 = zext i1 %cmp3060 to i32
  store i32 %cv3061, ptr %slot524, align 8
  %v3062 = load i32, ptr %slot524, align 8
  %cv3063 = zext i32 %v3062 to i64
  %cond3064 = icmp ne i64 %cv3063, 0
  br i1 %cond3064, label %bb_rcgclear640, label %bb_rcgcounted640
bb_rcgcounted640:
  %v3065 = load i64, ptr %slot519, align 8
  %op3066 = sub i64 %v3065, 32
  store i64 %op3066, ptr %slot525, align 8
  %v3067 = load i64, ptr %slot519, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  %rgep3069 = getelementptr i8, ptr %p3068, i64 -32
  %ld3070 = load i64, ptr %rgep3069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3070, ptr %slot526, align 8
  %v3071 = load i64, ptr %slot526, align 8
  %op3072 = sub i64 %v3071, 1
  store i64 %op3072, ptr %slot527, align 8
  %v3073 = load i64, ptr %slot527, align 8
  %cmp3074 = icmp eq i64 %v3073, 0
  %cv3075 = zext i1 %cmp3074 to i32
  store i32 %cv3075, ptr %slot528, align 8
  %v3076 = load i32, ptr %slot528, align 8
  %cv3077 = zext i32 %v3076 to i64
  %cond3078 = icmp ne i64 %cv3077, 0
  br i1 %cond3078, label %bb_rcglast640, label %bb_rcgdec640
bb_rcglast640:
  %v3079 = load i64, ptr %slot519, align 8
  %op3080 = sub i64 %v3079, 24
  store i64 %op3080, ptr %slot529, align 8
  %v3081 = load i64, ptr %slot519, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  %rgep3083 = getelementptr i8, ptr %p3082, i64 -24
  %ld3084 = load i64, ptr %rgep3083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3084, ptr %slot530, align 8
  %v3085 = load i64, ptr %slot530, align 8
  %cmp3086 = icmp ne i64 %v3085, 0
  %cv3087 = zext i1 %cmp3086 to i32
  store i32 %cv3087, ptr %slot531, align 8
  %v3088 = load i32, ptr %slot531, align 8
  %cv3089 = zext i32 %v3088 to i64
  %cond3090 = icmp ne i64 %cv3089, 0
  br i1 %cond3090, label %bb_rcgdec640, label %bb_rcgslow640
bb_rcgslow640:
  %v3091 = load i64, ptr %slot518, align 8
  %v3092 = load i64, ptr %slot517, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3091, i64 %v3092) nomerge, !dbg !132
  br label %bb_rcgdone640
bb_rcgdec640:
  %v3093 = load i64, ptr %slot527, align 8
  %v3094 = load i64, ptr %slot519, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  %rgep3096 = getelementptr i8, ptr %p3095, i64 -32
  store i64 %v3093, ptr %rgep3096, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear640
bb_rcgclear640:
  %v3097 = load i64, ptr %slot517, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  store i64 0, ptr %p3098, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone640
bb_rcgdone640:
  %v3099 = load i64, ptr %slot513, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  store i64 0, ptr %p3100, align 8, !alias.scope !3, !noalias !4
  %v3101 = load i64, ptr %slot513, align 8
  %p3103 = inttoptr i64 %v3101 to ptr
  %gep3104 = getelementptr i8, ptr %p3103, i64 8
  %op3102 = ptrtoint ptr %gep3104 to i64
  store i64 %op3102, ptr %slot532, align 8
  %v3105 = load i64, ptr %slot532, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  store i64 0, ptr %p3106, align 8, !alias.scope !3, !noalias !4
  %v3107 = load i64, ptr %slot513, align 8
  %p3109 = inttoptr i64 %v3107 to ptr
  %gep3110 = getelementptr i8, ptr %p3109, i64 16
  %op3108 = ptrtoint ptr %gep3110 to i64
  store i64 %op3108, ptr %slot533, align 8
  %v3111 = load i64, ptr %slot533, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  store i64 0, ptr %p3112, align 8, !alias.scope !3, !noalias !4
  %v3113 = load i64, ptr %slot513, align 8
  %p3115 = inttoptr i64 %v3113 to ptr
  %gep3116 = getelementptr i8, ptr %p3115, i64 24
  %op3114 = ptrtoint ptr %gep3116 to i64
  store i64 %op3114, ptr %slot534, align 8
  %v3117 = load i64, ptr %slot534, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  store i64 0, ptr %p3118, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone622
bb_rcslotdone622:
  %v3119 = load i64, ptr %slot30, align 8
  store i64 %v3119, ptr %slot535, align 8
  %v3120 = load i64, ptr %slot23, align 8
  store i64 %v3120, ptr %slot536, align 8
  %v3121 = load i64, ptr %slot536, align 8
  %v3122 = load i64, ptr %slot535, align 8
  %p3123 = inttoptr i64 %v3121 to ptr
  %p3124 = inttoptr i64 %v3122 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3124, ptr %p3123, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3125 = load i64, ptr %slot17, align 8
  %p3126 = inttoptr i64 %v3125 to ptr
  store i32 0, ptr %p3126, align 4, !alias.scope !3, !noalias !4
  %v3127 = load i64, ptr %slot12, align 8
  %p3128 = inttoptr i64 %v3127 to ptr
  store i32 2, ptr %p3128, align 4, !alias.scope !3, !noalias !4
  %v3129 = load i64, ptr %slot18, align 8
  %p3130 = inttoptr i64 %v3129 to ptr
  %ld3131 = load i32, ptr %p3130, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3131, ptr %slot537, align 8
  %v3132 = load i32, ptr %slot537, align 8
  %v3133 = load i64, ptr %slot12, align 8
  %p3134 = inttoptr i64 %v3133 to ptr
  store i32 %v3132, ptr %p3134, align 4, !alias.scope !3, !noalias !4
  %v3135 = load i64, ptr %slot11, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  store i32 1, ptr %p3136, align 4, !alias.scope !3, !noalias !4
  %v3137 = load i64, ptr %slot30, align 8
  %v3138 = load i64, ptr %slot32, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  store i64 %v3137, ptr %p3139, align 8, !alias.scope !3, !noalias !4
  %v3140 = load i64, ptr %slot32, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  %ld3142 = load i64, ptr %p3141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3142, ptr %slot538, align 8
  %v3143 = load i64, ptr %slot538, align 8
  %op3144 = add i64 %v3143, 16
  store i64 %op3144, ptr %slot539, align 8
  %v3145 = load i64, ptr %slot539, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  %ld3147 = load i64, ptr %p3146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3147, ptr %slot540, align 8
  %v3148 = load i64, ptr %slot540, align 8
  %v3149 = load i64, ptr %slot32, align 8
  %p3150 = inttoptr i64 %v3149 to ptr
  store i64 %v3148, ptr %p3150, align 8, !alias.scope !3, !noalias !4
  %v3151 = load i64, ptr %slot13, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %ld3153 = load i32, ptr %p3152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3153, ptr %slot541, align 8
  %v3154 = load i32, ptr %slot541, align 8
  %cv3155 = zext i32 %v3154 to i64
  %cond3156 = icmp ne i64 %cv3155, 0
  br i1 %cond3156, label %bb_rcslotdrop659, label %bb_rcslotdone659
bb_rcslotdrop659:
  %v3157 = load i64, ptr %slot13, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  store i32 0, ptr %p3158, align 4, !alias.scope !3, !noalias !4
  %v3159 = load i64, ptr %slot19, align 8
  store i64 %v3159, ptr %slot542, align 8
  %v3160 = load i64, ptr %slot14, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  %ld3162 = load i32, ptr %p3161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3162, ptr %slot543, align 8
  %v3163 = load i32, ptr %slot543, align 8
  %op3164 = and i32 %v3163, 28
  store i32 %op3164, ptr %slot544, align 8
  %v3165 = load i32, ptr %slot544, align 8
  %cv3166 = zext i32 %v3165 to i64
  %cond3167 = icmp ne i64 %cv3166, 0
  br i1 %cond3167, label %bb_rcslotrole659, label %bb_rcslotowner659
bb_rcslotrole659:
  %v3168 = load i64, ptr %slot38, align 8
  store i64 %v3168, ptr %slot545, align 8
  %v3169 = load i64, ptr %slot545, align 8
  %v3170 = load i64, ptr %slot542, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3169, i64 %v3170) nomerge, !dbg !134
  br label %bb_rcslotdone659
bb_rcslotowner659:
  %v3171 = load i64, ptr %slot38, align 8
  store i64 %v3171, ptr %slot546, align 8
  %v3172 = load i64, ptr %slot546, align 8
  %v3173 = load i64, ptr %slot542, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3172, i64 %v3173) nomerge, !dbg !134
  br label %bb_rcslotdone659
bb_rcslotdone659:
  %v3174 = load i64, ptr %slot30, align 8
  %v3175 = load i64, ptr %slot33, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  store i64 %v3174, ptr %p3176, align 8, !alias.scope !3, !noalias !4
  %v3177 = load i64, ptr %slot33, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %ld3179 = load i64, ptr %p3178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3179, ptr %slot547, align 8
  %v3180 = load i64, ptr %slot547, align 8
  %op3181 = add i64 %v3180, 0
  store i64 %op3181, ptr %slot548, align 8
  %v3182 = load i64, ptr %slot548, align 8
  %p3183 = inttoptr i64 %v3182 to ptr
  %ld3184 = load i64, ptr %p3183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3184, ptr %slot549, align 8
  %v3185 = load i64, ptr %slot549, align 8
  %v3186 = load i64, ptr %slot33, align 8
  %p3187 = inttoptr i64 %v3186 to ptr
  store i64 %v3185, ptr %p3187, align 8, !alias.scope !3, !noalias !4
  %v3188 = load i64, ptr %slot33, align 8
  %p3189 = inttoptr i64 %v3188 to ptr
  %ld3190 = load i64, ptr %p3189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3190, ptr %slot550, align 8
  %v3191 = load i64, ptr %slot550, align 8
  %v3192 = load i64, ptr %slot22, align 8
  %p3193 = inttoptr i64 %v3192 to ptr
  store i64 %v3191, ptr %p3193, align 8, !alias.scope !3, !noalias !4
  %v3194 = load i64, ptr %slot22, align 8
  store i64 %v3194, ptr %slot551, align 8
  %v3195 = load i64, ptr %slot23, align 8
  store i64 %v3195, ptr %slot552, align 8
  %v3196 = load i64, ptr %slot551, align 8
  %p3197 = inttoptr i64 %v3196 to ptr
  %ld3198 = load i64, ptr %p3197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3198, ptr %slot553, align 8
  %v3199 = load i64, ptr %slot553, align 8
  %cmp3200 = icmp ne i64 %v3199, 0
  %cv3201 = zext i1 %cmp3200 to i32
  store i32 %cv3201, ptr %slot554, align 8
  %v3202 = load i32, ptr %slot554, align 8
  %cv3203 = zext i32 %v3202 to i64
  %cond3204 = icmp ne i64 %cv3203, 0
  br i1 %cond3204, label %bb_rcgnn673, label %bb_rcgstore673
bb_rcgnn673:
  %v3205 = load i64, ptr %slot553, align 8
  %op3206 = sub i64 %v3205, 16
  store i64 %op3206, ptr %slot555, align 8
  %v3207 = load i64, ptr %slot553, align 8
  %p3208 = inttoptr i64 %v3207 to ptr
  %rgep3209 = getelementptr i8, ptr %p3208, i64 -16
  %ld3210 = load i64, ptr %rgep3209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3210, ptr %slot556, align 8
  %v3211 = load i64, ptr %slot556, align 8
  %op3212 = and i64 %v3211, 4611686018427387906
  store i64 %op3212, ptr %slot557, align 8
  %v3213 = load i64, ptr %slot557, align 8
  %cmp3214 = icmp ne i64 %v3213, 0
  %cv3215 = zext i1 %cmp3214 to i32
  store i32 %cv3215, ptr %slot558, align 8
  %v3216 = load i32, ptr %slot558, align 8
  %cv3217 = zext i32 %v3216 to i64
  %cond3218 = icmp ne i64 %cv3217, 0
  br i1 %cond3218, label %bb_rcgstore673, label %bb_rcginc673
bb_rcginc673:
  %v3219 = load i64, ptr %slot553, align 8
  %op3220 = sub i64 %v3219, 24
  store i64 %op3220, ptr %slot559, align 8
  %v3221 = load i64, ptr %slot553, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  %rgep3223 = getelementptr i8, ptr %p3222, i64 -24
  %ld3224 = load i64, ptr %rgep3223, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3224, ptr %slot560, align 8
  %v3225 = load i64, ptr %slot560, align 8
  %op3226 = add i64 %v3225, 1
  store i64 %op3226, ptr %slot561, align 8
  %v3227 = load i64, ptr %slot561, align 8
  %cmp3228 = icmp eq i64 %v3227, 0
  %cv3229 = zext i1 %cmp3228 to i32
  store i32 %cv3229, ptr %slot562, align 8
  %v3230 = load i32, ptr %slot562, align 8
  %cv3231 = zext i32 %v3230 to i64
  %cond3232 = icmp ne i64 %cv3231, 0
  br i1 %cond3232, label %bb_rcglimit673, label %bb_rcgcapacity673
bb_rcglimit673:
  %v3233 = load i64, ptr %slot1, align 8
  %p3234 = inttoptr i64 %v3233 to ptr
  %call3235 = call i32 @myl_qbe_rc_status(ptr %p3234, i32 2) nomerge, !dbg !136
  store i32 %call3235, ptr %slot563, align 8
  br label %bb_failure
bb_rcgcapacity673:
  %v3236 = load i64, ptr %slot561, align 8
  %v3237 = load i64, ptr %slot553, align 8
  %p3238 = inttoptr i64 %v3237 to ptr
  %rgep3239 = getelementptr i8, ptr %p3238, i64 -24
  store i64 %v3236, ptr %rgep3239, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore673
bb_rcgstore673:
  %v3240 = load i64, ptr %slot553, align 8
  %v3241 = load i64, ptr %slot552, align 8
  %p3242 = inttoptr i64 %v3241 to ptr
  store i64 %v3240, ptr %p3242, align 8, !alias.scope !3, !noalias !4
  %v3243 = load i64, ptr %slot18, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  store i32 2, ptr %p3244, align 4, !alias.scope !3, !noalias !4
  %v3245 = load i64, ptr %slot18, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  store i32 16, ptr %p3246, align 4, !alias.scope !3, !noalias !4
  %v3247 = load i64, ptr %slot17, align 8
  %p3248 = inttoptr i64 %v3247 to ptr
  store i32 1, ptr %p3248, align 4, !alias.scope !3, !noalias !4
  %v3249 = load i64, ptr %slot15, align 8
  %p3250 = inttoptr i64 %v3249 to ptr
  %ld3251 = load i32, ptr %p3250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3251, ptr %slot564, align 8
  %v3252 = load i32, ptr %slot564, align 8
  %cv3253 = zext i32 %v3252 to i64
  %cond3254 = icmp ne i64 %cv3253, 0
  br i1 %cond3254, label %bb_rcslotdrop689, label %bb_rcslotdone689
bb_rcslotdrop689:
  %v3255 = load i64, ptr %slot15, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  store i32 0, ptr %p3256, align 4, !alias.scope !3, !noalias !4
  %v3257 = load i64, ptr %slot20, align 8
  store i64 %v3257, ptr %slot565, align 8
  %v3258 = load i64, ptr %slot16, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  %ld3260 = load i32, ptr %p3259, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3260, ptr %slot566, align 8
  %v3261 = load i32, ptr %slot566, align 8
  %op3262 = and i32 %v3261, 28
  store i32 %op3262, ptr %slot567, align 8
  %v3263 = load i32, ptr %slot567, align 8
  %cv3264 = zext i32 %v3263 to i64
  %cond3265 = icmp ne i64 %cv3264, 0
  br i1 %cond3265, label %bb_rcslotrole689, label %bb_rcslotowner689
bb_rcslotrole689:
  %v3266 = load i64, ptr %slot38, align 8
  store i64 %v3266, ptr %slot568, align 8
  %v3267 = load i64, ptr %slot568, align 8
  %v3268 = load i64, ptr %slot565, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3267, i64 %v3268) nomerge, !dbg !136
  br label %bb_rcslotdone689
bb_rcslotowner689:
  %v3269 = load i64, ptr %slot38, align 8
  store i64 %v3269, ptr %slot569, align 8
  %v3270 = load i64, ptr %slot569, align 8
  %v3271 = load i64, ptr %slot565, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3270, i64 %v3271) nomerge, !dbg !136
  br label %bb_rcslotdone689
bb_rcslotdone689:
  %v3272 = load i64, ptr %slot20, align 8
  store i64 %v3272, ptr %slot570, align 8
  %v3273 = load i64, ptr %slot23, align 8
  store i64 %v3273, ptr %slot571, align 8
  %v3274 = load i64, ptr %slot571, align 8
  %v3275 = load i64, ptr %slot570, align 8
  %p3276 = inttoptr i64 %v3274 to ptr
  %p3277 = inttoptr i64 %v3275 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3277, ptr %p3276, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3278 = load i64, ptr %slot16, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  store i32 2, ptr %p3279, align 4, !alias.scope !3, !noalias !4
  %v3280 = load i64, ptr %slot18, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  %ld3282 = load i32, ptr %p3281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3282, ptr %slot572, align 8
  %v3283 = load i32, ptr %slot572, align 8
  %v3284 = load i64, ptr %slot16, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  store i32 %v3283, ptr %p3285, align 4, !alias.scope !3, !noalias !4
  %v3286 = load i64, ptr %slot17, align 8
  %p3287 = inttoptr i64 %v3286 to ptr
  store i32 0, ptr %p3287, align 4, !alias.scope !3, !noalias !4
  %v3288 = load i64, ptr %slot15, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i32 1, ptr %p3289, align 4, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot570, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  %ld3292 = load i64, ptr %p3291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3292, ptr %slot573, align 8
  %v3293 = load i64, ptr %slot573, align 8
  %v3294 = load i64, ptr %slot33, align 8
  %p3295 = inttoptr i64 %v3294 to ptr
  store i64 %v3293, ptr %p3295, align 8, !alias.scope !3, !noalias !4
  %v3296 = load i64, ptr %slot33, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  %ld3298 = load i64, ptr %p3297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3298, ptr %slot574, align 8
  %v3299 = load i64, ptr %slot574, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  %ld3301 = load i64, ptr %p3300, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3301, ptr %slot575, align 8
  %v3302 = load i64, ptr %slot575, align 8
  %v3303 = load i64, ptr %slot33, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  store i64 %v3302, ptr %p3304, align 8, !alias.scope !3, !noalias !4
  %v3305 = load i64, ptr %slot15, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  %ld3307 = load i32, ptr %p3306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3307, ptr %slot576, align 8
  %v3308 = load i32, ptr %slot576, align 8
  %cv3309 = zext i32 %v3308 to i64
  %cond3310 = icmp ne i64 %cv3309, 0
  br i1 %cond3310, label %bb_rcslotdrop709, label %bb_rcslotdone709
bb_rcslotdrop709:
  %v3311 = load i64, ptr %slot15, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  store i32 0, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  %v3313 = load i64, ptr %slot20, align 8
  store i64 %v3313, ptr %slot577, align 8
  %v3314 = load i64, ptr %slot16, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  %ld3316 = load i32, ptr %p3315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3316, ptr %slot578, align 8
  %v3317 = load i32, ptr %slot578, align 8
  %op3318 = and i32 %v3317, 28
  store i32 %op3318, ptr %slot579, align 8
  %v3319 = load i32, ptr %slot579, align 8
  %cv3320 = zext i32 %v3319 to i64
  %cond3321 = icmp ne i64 %cv3320, 0
  br i1 %cond3321, label %bb_rcslotrole709, label %bb_rcslotowner709
bb_rcslotrole709:
  %v3322 = load i64, ptr %slot38, align 8
  store i64 %v3322, ptr %slot580, align 8
  %v3323 = load i64, ptr %slot577, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  %ld3325 = load i64, ptr %p3324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3325, ptr %slot581, align 8
  %v3326 = load i64, ptr %slot581, align 8
  %cmp3327 = icmp ne i64 %v3326, 0
  %cv3328 = zext i1 %cmp3327 to i32
  store i32 %cv3328, ptr %slot582, align 8
  %v3329 = load i32, ptr %slot582, align 8
  %cv3330 = zext i32 %v3329 to i64
  %cond3331 = icmp ne i64 %cv3330, 0
  br i1 %cond3331, label %bb_rcgnn725, label %bb_rcgdone725
bb_rcgnn725:
  %v3332 = load i64, ptr %slot581, align 8
  %op3333 = sub i64 %v3332, 16
  store i64 %op3333, ptr %slot583, align 8
  %v3334 = load i64, ptr %slot581, align 8
  %p3335 = inttoptr i64 %v3334 to ptr
  %rgep3336 = getelementptr i8, ptr %p3335, i64 -16
  %ld3337 = load i64, ptr %rgep3336, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3337, ptr %slot584, align 8
  %v3338 = load i64, ptr %slot584, align 8
  %op3339 = and i64 %v3338, 4611686018427387906
  store i64 %op3339, ptr %slot585, align 8
  %v3340 = load i64, ptr %slot585, align 8
  %cmp3341 = icmp ne i64 %v3340, 0
  %cv3342 = zext i1 %cmp3341 to i32
  store i32 %cv3342, ptr %slot586, align 8
  %v3343 = load i32, ptr %slot586, align 8
  %cv3344 = zext i32 %v3343 to i64
  %cond3345 = icmp ne i64 %cv3344, 0
  br i1 %cond3345, label %bb_rcgclear725, label %bb_rcgcounted725
bb_rcgcounted725:
  %v3346 = load i64, ptr %slot581, align 8
  %op3347 = sub i64 %v3346, 24
  store i64 %op3347, ptr %slot587, align 8
  %v3348 = load i64, ptr %slot581, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  %rgep3350 = getelementptr i8, ptr %p3349, i64 -24
  %ld3351 = load i64, ptr %rgep3350, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3351, ptr %slot588, align 8
  %v3352 = load i64, ptr %slot588, align 8
  %op3353 = sub i64 %v3352, 1
  store i64 %op3353, ptr %slot589, align 8
  %v3354 = load i64, ptr %slot589, align 8
  %cmp3355 = icmp eq i64 %v3354, 0
  %cv3356 = zext i1 %cmp3355 to i32
  store i32 %cv3356, ptr %slot590, align 8
  %v3357 = load i32, ptr %slot590, align 8
  %cv3358 = zext i32 %v3357 to i64
  %cond3359 = icmp ne i64 %cv3358, 0
  br i1 %cond3359, label %bb_rcglast725, label %bb_rcgdec725
bb_rcglast725:
  %v3360 = load i64, ptr %slot581, align 8
  %op3361 = sub i64 %v3360, 32
  store i64 %op3361, ptr %slot591, align 8
  %v3362 = load i64, ptr %slot581, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  %rgep3364 = getelementptr i8, ptr %p3363, i64 -32
  %ld3365 = load i64, ptr %rgep3364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3365, ptr %slot592, align 8
  %v3366 = load i64, ptr %slot592, align 8
  %cmp3367 = icmp ne i64 %v3366, 0
  %cv3368 = zext i1 %cmp3367 to i32
  store i32 %cv3368, ptr %slot593, align 8
  %v3369 = load i32, ptr %slot593, align 8
  %cv3370 = zext i32 %v3369 to i64
  %cond3371 = icmp ne i64 %cv3370, 0
  br i1 %cond3371, label %bb_rcgdec725, label %bb_rcgslow725
bb_rcgslow725:
  %v3372 = load i64, ptr %slot580, align 8
  %v3373 = load i64, ptr %slot577, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3372, i64 %v3373) nomerge, !dbg !138
  br label %bb_rcgdone725
bb_rcgdec725:
  %v3374 = load i64, ptr %slot589, align 8
  %v3375 = load i64, ptr %slot581, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  %rgep3377 = getelementptr i8, ptr %p3376, i64 -24
  store i64 %v3374, ptr %rgep3377, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear725
bb_rcgclear725:
  %v3378 = load i64, ptr %slot577, align 8
  %p3379 = inttoptr i64 %v3378 to ptr
  store i64 0, ptr %p3379, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone725
bb_rcgdone725:
  br label %bb_rcslotdone709
bb_rcslotowner709:
  %v3380 = load i64, ptr %slot38, align 8
  store i64 %v3380, ptr %slot594, align 8
  %v3381 = load i64, ptr %slot577, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  %ld3383 = load i64, ptr %p3382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3383, ptr %slot595, align 8
  %v3384 = load i64, ptr %slot595, align 8
  %cmp3385 = icmp ne i64 %v3384, 0
  %cv3386 = zext i1 %cmp3385 to i32
  store i32 %cv3386, ptr %slot596, align 8
  %v3387 = load i32, ptr %slot596, align 8
  %cv3388 = zext i32 %v3387 to i64
  %cond3389 = icmp ne i64 %cv3388, 0
  br i1 %cond3389, label %bb_rcgnn740, label %bb_rcgdone740
bb_rcgnn740:
  %v3390 = load i64, ptr %slot595, align 8
  %op3391 = sub i64 %v3390, 16
  store i64 %op3391, ptr %slot597, align 8
  %v3392 = load i64, ptr %slot595, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  %rgep3394 = getelementptr i8, ptr %p3393, i64 -16
  %ld3395 = load i64, ptr %rgep3394, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3395, ptr %slot598, align 8
  %v3396 = load i64, ptr %slot598, align 8
  %op3397 = and i64 %v3396, 4611686018427387906
  store i64 %op3397, ptr %slot599, align 8
  %v3398 = load i64, ptr %slot599, align 8
  %cmp3399 = icmp ne i64 %v3398, 0
  %cv3400 = zext i1 %cmp3399 to i32
  store i32 %cv3400, ptr %slot600, align 8
  %v3401 = load i32, ptr %slot600, align 8
  %cv3402 = zext i32 %v3401 to i64
  %cond3403 = icmp ne i64 %cv3402, 0
  br i1 %cond3403, label %bb_rcgclear740, label %bb_rcgcounted740
bb_rcgcounted740:
  %v3404 = load i64, ptr %slot595, align 8
  %op3405 = sub i64 %v3404, 32
  store i64 %op3405, ptr %slot601, align 8
  %v3406 = load i64, ptr %slot595, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  %rgep3408 = getelementptr i8, ptr %p3407, i64 -32
  %ld3409 = load i64, ptr %rgep3408, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3409, ptr %slot602, align 8
  %v3410 = load i64, ptr %slot602, align 8
  %op3411 = sub i64 %v3410, 1
  store i64 %op3411, ptr %slot603, align 8
  %v3412 = load i64, ptr %slot603, align 8
  %cmp3413 = icmp eq i64 %v3412, 0
  %cv3414 = zext i1 %cmp3413 to i32
  store i32 %cv3414, ptr %slot604, align 8
  %v3415 = load i32, ptr %slot604, align 8
  %cv3416 = zext i32 %v3415 to i64
  %cond3417 = icmp ne i64 %cv3416, 0
  br i1 %cond3417, label %bb_rcglast740, label %bb_rcgdec740
bb_rcglast740:
  %v3418 = load i64, ptr %slot595, align 8
  %op3419 = sub i64 %v3418, 24
  store i64 %op3419, ptr %slot605, align 8
  %v3420 = load i64, ptr %slot595, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  %rgep3422 = getelementptr i8, ptr %p3421, i64 -24
  %ld3423 = load i64, ptr %rgep3422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3423, ptr %slot606, align 8
  %v3424 = load i64, ptr %slot606, align 8
  %cmp3425 = icmp ne i64 %v3424, 0
  %cv3426 = zext i1 %cmp3425 to i32
  store i32 %cv3426, ptr %slot607, align 8
  %v3427 = load i32, ptr %slot607, align 8
  %cv3428 = zext i32 %v3427 to i64
  %cond3429 = icmp ne i64 %cv3428, 0
  br i1 %cond3429, label %bb_rcgdec740, label %bb_rcgslow740
bb_rcgslow740:
  %v3430 = load i64, ptr %slot594, align 8
  %v3431 = load i64, ptr %slot577, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3430, i64 %v3431) nomerge, !dbg !138
  br label %bb_rcgdone740
bb_rcgdec740:
  %v3432 = load i64, ptr %slot603, align 8
  %v3433 = load i64, ptr %slot595, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  %rgep3435 = getelementptr i8, ptr %p3434, i64 -32
  store i64 %v3432, ptr %rgep3435, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear740
bb_rcgclear740:
  %v3436 = load i64, ptr %slot577, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  store i64 0, ptr %p3437, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone740
bb_rcgdone740:
  br label %bb_rcslotdone709
bb_rcslotdone709:
  %v3438 = load i64, ptr %slot33, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  %ld3440 = load i64, ptr %p3439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3440, ptr %slot608, align 8
  %v3441 = load i64, ptr %slot32, align 8
  %p3442 = inttoptr i64 %v3441 to ptr
  %ld3443 = load i64, ptr %p3442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3443, ptr %slot609, align 8
  %v3444 = load i64, ptr %slot609, align 8
  %v3445 = load i64, ptr %slot608, align 8
  %cmp3446 = icmp sge i64 %v3444, %v3445
  %cv3447 = zext i1 %cmp3446 to i64
  store i64 %cv3447, ptr %slot610, align 8
  %v3448 = load i64, ptr %slot610, align 8
  %v3449 = load i64, ptr %slot32, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  store i64 %v3448, ptr %p3450, align 8, !alias.scope !3, !noalias !4
  br label %bb_i64
bb_i64:
  %v3451 = load i64, ptr %slot32, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  %ld3453 = load i64, ptr %p3452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3453, ptr %slot611, align 8
  %v3454 = load i64, ptr %slot611, align 8
  %cond3455 = icmp ne i64 %v3454, 0
  br i1 %cond3455, label %bb_next748, label %bb_i67
bb_next748:
  %v3456 = load i64, ptr %slot32, align 8
  %p3457 = inttoptr i64 %v3456 to ptr
  store i64 0, ptr %p3457, align 8, !alias.scope !3, !noalias !4
  br label %bb_i74
bb_i67:
  %v3458 = load i64, ptr %slot29, align 8
  %v3459 = load i64, ptr %slot32, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  store i64 %v3458, ptr %p3460, align 8, !alias.scope !3, !noalias !4
  %v3461 = load i64, ptr %slot32, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  %ld3463 = load i64, ptr %p3462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3463, ptr %slot612, align 8
  %v3464 = load i64, ptr %slot612, align 8
  %op3465 = add i64 %v3464, 0
  store i64 %op3465, ptr %slot613, align 8
  %v3466 = load i64, ptr %slot613, align 8
  %p3467 = inttoptr i64 %v3466 to ptr
  %ld3468 = load i64, ptr %p3467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3468, ptr %slot614, align 8
  %v3469 = load i64, ptr %slot614, align 8
  %v3470 = load i64, ptr %slot32, align 8
  %p3471 = inttoptr i64 %v3470 to ptr
  store i64 %v3469, ptr %p3471, align 8, !alias.scope !3, !noalias !4
  %v3472 = load i64, ptr %slot32, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %ld3474 = load i64, ptr %p3473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3474, ptr %slot615, align 8
  %v3475 = load i64, ptr %slot615, align 8
  %v3476 = load i64, ptr %slot21, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  store i64 %v3475, ptr %p3477, align 8, !alias.scope !3, !noalias !4
  %v3478 = load i64, ptr %slot21, align 8
  store i64 %v3478, ptr %slot616, align 8
  %v3479 = load i64, ptr %slot23, align 8
  store i64 %v3479, ptr %slot617, align 8
  %v3480 = load i64, ptr %slot616, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  %ld3482 = load i64, ptr %p3481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3482, ptr %slot618, align 8
  %v3483 = load i64, ptr %slot618, align 8
  %cmp3484 = icmp ne i64 %v3483, 0
  %cv3485 = zext i1 %cmp3484 to i32
  store i32 %cv3485, ptr %slot619, align 8
  %v3486 = load i32, ptr %slot619, align 8
  %cv3487 = zext i32 %v3486 to i64
  %cond3488 = icmp ne i64 %cv3487, 0
  br i1 %cond3488, label %bb_rcgnn755, label %bb_rcgstore755
bb_rcgnn755:
  %v3489 = load i64, ptr %slot618, align 8
  %op3490 = sub i64 %v3489, 16
  store i64 %op3490, ptr %slot620, align 8
  %v3491 = load i64, ptr %slot618, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %rgep3493 = getelementptr i8, ptr %p3492, i64 -16
  %ld3494 = load i64, ptr %rgep3493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3494, ptr %slot621, align 8
  %v3495 = load i64, ptr %slot621, align 8
  %op3496 = and i64 %v3495, 4611686018427387906
  store i64 %op3496, ptr %slot622, align 8
  %v3497 = load i64, ptr %slot622, align 8
  %cmp3498 = icmp ne i64 %v3497, 0
  %cv3499 = zext i1 %cmp3498 to i32
  store i32 %cv3499, ptr %slot623, align 8
  %v3500 = load i32, ptr %slot623, align 8
  %cv3501 = zext i32 %v3500 to i64
  %cond3502 = icmp ne i64 %cv3501, 0
  br i1 %cond3502, label %bb_rcgstore755, label %bb_rcginc755
bb_rcginc755:
  %v3503 = load i64, ptr %slot618, align 8
  %op3504 = sub i64 %v3503, 24
  store i64 %op3504, ptr %slot624, align 8
  %v3505 = load i64, ptr %slot618, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  %rgep3507 = getelementptr i8, ptr %p3506, i64 -24
  %ld3508 = load i64, ptr %rgep3507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3508, ptr %slot625, align 8
  %v3509 = load i64, ptr %slot625, align 8
  %op3510 = add i64 %v3509, 1
  store i64 %op3510, ptr %slot626, align 8
  %v3511 = load i64, ptr %slot626, align 8
  %cmp3512 = icmp eq i64 %v3511, 0
  %cv3513 = zext i1 %cmp3512 to i32
  store i32 %cv3513, ptr %slot627, align 8
  %v3514 = load i32, ptr %slot627, align 8
  %cv3515 = zext i32 %v3514 to i64
  %cond3516 = icmp ne i64 %cv3515, 0
  br i1 %cond3516, label %bb_rcglimit755, label %bb_rcgcapacity755
bb_rcglimit755:
  %v3517 = load i64, ptr %slot1, align 8
  %p3518 = inttoptr i64 %v3517 to ptr
  %call3519 = call i32 @myl_qbe_rc_status(ptr %p3518, i32 2) nomerge, !dbg !140
  store i32 %call3519, ptr %slot628, align 8
  br label %bb_failure
bb_rcgcapacity755:
  %v3520 = load i64, ptr %slot626, align 8
  %v3521 = load i64, ptr %slot618, align 8
  %p3522 = inttoptr i64 %v3521 to ptr
  %rgep3523 = getelementptr i8, ptr %p3522, i64 -24
  store i64 %v3520, ptr %rgep3523, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore755
bb_rcgstore755:
  %v3524 = load i64, ptr %slot618, align 8
  %v3525 = load i64, ptr %slot617, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  store i64 %v3524, ptr %p3526, align 8, !alias.scope !3, !noalias !4
  %v3527 = load i64, ptr %slot18, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  store i32 2, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  %v3529 = load i64, ptr %slot18, align 8
  %p3530 = inttoptr i64 %v3529 to ptr
  store i32 16, ptr %p3530, align 4, !alias.scope !3, !noalias !4
  %v3531 = load i64, ptr %slot17, align 8
  %p3532 = inttoptr i64 %v3531 to ptr
  store i32 1, ptr %p3532, align 4, !alias.scope !3, !noalias !4
  %v3533 = load i64, ptr %slot13, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  %ld3535 = load i32, ptr %p3534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3535, ptr %slot629, align 8
  %v3536 = load i32, ptr %slot629, align 8
  %cv3537 = zext i32 %v3536 to i64
  %cond3538 = icmp ne i64 %cv3537, 0
  br i1 %cond3538, label %bb_rcslotdrop771, label %bb_rcslotdone771
bb_rcslotdrop771:
  %v3539 = load i64, ptr %slot13, align 8
  %p3540 = inttoptr i64 %v3539 to ptr
  store i32 0, ptr %p3540, align 4, !alias.scope !3, !noalias !4
  %v3541 = load i64, ptr %slot19, align 8
  store i64 %v3541, ptr %slot630, align 8
  %v3542 = load i64, ptr %slot14, align 8
  %p3543 = inttoptr i64 %v3542 to ptr
  %ld3544 = load i32, ptr %p3543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3544, ptr %slot631, align 8
  %v3545 = load i32, ptr %slot631, align 8
  %op3546 = and i32 %v3545, 28
  store i32 %op3546, ptr %slot632, align 8
  %v3547 = load i32, ptr %slot632, align 8
  %cv3548 = zext i32 %v3547 to i64
  %cond3549 = icmp ne i64 %cv3548, 0
  br i1 %cond3549, label %bb_rcslotrole771, label %bb_rcslotowner771
bb_rcslotrole771:
  %v3550 = load i64, ptr %slot38, align 8
  store i64 %v3550, ptr %slot633, align 8
  %v3551 = load i64, ptr %slot633, align 8
  %v3552 = load i64, ptr %slot630, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3551, i64 %v3552) nomerge, !dbg !140
  br label %bb_rcslotdone771
bb_rcslotowner771:
  %v3553 = load i64, ptr %slot38, align 8
  store i64 %v3553, ptr %slot634, align 8
  %v3554 = load i64, ptr %slot634, align 8
  %v3555 = load i64, ptr %slot630, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3554, i64 %v3555) nomerge, !dbg !140
  br label %bb_rcslotdone771
bb_rcslotdone771:
  %v3556 = load i64, ptr %slot19, align 8
  store i64 %v3556, ptr %slot635, align 8
  %v3557 = load i64, ptr %slot23, align 8
  store i64 %v3557, ptr %slot636, align 8
  %v3558 = load i64, ptr %slot636, align 8
  %v3559 = load i64, ptr %slot635, align 8
  %p3560 = inttoptr i64 %v3558 to ptr
  %p3561 = inttoptr i64 %v3559 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3561, ptr %p3560, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3562 = load i64, ptr %slot14, align 8
  %p3563 = inttoptr i64 %v3562 to ptr
  store i32 2, ptr %p3563, align 4, !alias.scope !3, !noalias !4
  %v3564 = load i64, ptr %slot18, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  %ld3566 = load i32, ptr %p3565, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3566, ptr %slot637, align 8
  %v3567 = load i32, ptr %slot637, align 8
  %v3568 = load i64, ptr %slot14, align 8
  %p3569 = inttoptr i64 %v3568 to ptr
  store i32 %v3567, ptr %p3569, align 4, !alias.scope !3, !noalias !4
  %v3570 = load i64, ptr %slot17, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  store i32 0, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  %v3572 = load i64, ptr %slot13, align 8
  %p3573 = inttoptr i64 %v3572 to ptr
  store i32 1, ptr %p3573, align 4, !alias.scope !3, !noalias !4
  %v3574 = load i64, ptr %slot635, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  %ld3576 = load i64, ptr %p3575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3576, ptr %slot638, align 8
  %v3577 = load i64, ptr %slot638, align 8
  %v3578 = load i64, ptr %slot32, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  store i64 %v3577, ptr %p3579, align 8, !alias.scope !3, !noalias !4
  %v3580 = load i64, ptr %slot29, align 8
  %v3581 = load i64, ptr %slot33, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  store i64 %v3580, ptr %p3582, align 8, !alias.scope !3, !noalias !4
  %v3583 = load i64, ptr %slot33, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  %ld3585 = load i64, ptr %p3584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3585, ptr %slot639, align 8
  %v3586 = load i64, ptr %slot639, align 8
  %op3587 = add i64 %v3586, 16
  store i64 %op3587, ptr %slot640, align 8
  %v3588 = load i64, ptr %slot640, align 8
  %p3589 = inttoptr i64 %v3588 to ptr
  %ld3590 = load i64, ptr %p3589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3590, ptr %slot641, align 8
  %v3591 = load i64, ptr %slot641, align 8
  %v3592 = load i64, ptr %slot33, align 8
  %p3593 = inttoptr i64 %v3592 to ptr
  store i64 %v3591, ptr %p3593, align 8, !alias.scope !3, !noalias !4
  %v3594 = load i64, ptr %slot15, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  %ld3596 = load i32, ptr %p3595, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3596, ptr %slot642, align 8
  %v3597 = load i32, ptr %slot642, align 8
  %cv3598 = zext i32 %v3597 to i64
  %cond3599 = icmp ne i64 %cv3598, 0
  br i1 %cond3599, label %bb_rcslotdrop792, label %bb_rcslotdone792
bb_rcslotdrop792:
  %v3600 = load i64, ptr %slot15, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  store i32 0, ptr %p3601, align 4, !alias.scope !3, !noalias !4
  %v3602 = load i64, ptr %slot20, align 8
  store i64 %v3602, ptr %slot643, align 8
  %v3603 = load i64, ptr %slot16, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  %ld3605 = load i32, ptr %p3604, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3605, ptr %slot644, align 8
  %v3606 = load i32, ptr %slot644, align 8
  %op3607 = and i32 %v3606, 28
  store i32 %op3607, ptr %slot645, align 8
  %v3608 = load i32, ptr %slot645, align 8
  %cv3609 = zext i32 %v3608 to i64
  %cond3610 = icmp ne i64 %cv3609, 0
  br i1 %cond3610, label %bb_rcslotrole792, label %bb_rcslotowner792
bb_rcslotrole792:
  %v3611 = load i64, ptr %slot38, align 8
  store i64 %v3611, ptr %slot646, align 8
  %v3612 = load i64, ptr %slot646, align 8
  %v3613 = load i64, ptr %slot643, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3612, i64 %v3613) nomerge, !dbg !142
  br label %bb_rcslotdone792
bb_rcslotowner792:
  %v3614 = load i64, ptr %slot38, align 8
  store i64 %v3614, ptr %slot647, align 8
  %v3615 = load i64, ptr %slot647, align 8
  %v3616 = load i64, ptr %slot643, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3615, i64 %v3616) nomerge, !dbg !142
  br label %bb_rcslotdone792
bb_rcslotdone792:
  %v3617 = load i64, ptr %slot32, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  %ld3619 = load i64, ptr %p3618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3619, ptr %slot648, align 8
  %v3620 = load i64, ptr %slot33, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %ld3622 = load i64, ptr %p3621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3622, ptr %slot649, align 8
  %v3623 = load i64, ptr %slot648, align 8
  %p3624 = inttoptr i64 %v3623 to ptr
  %ld3625 = load i64, ptr %p3624, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3625, ptr %slot650, align 8
  %v3626 = load i64, ptr %slot649, align 8
  %op3627 = ashr i64 %v3626, 63
  store i64 %op3627, ptr %slot651, align 8
  %v3628 = load i64, ptr %slot651, align 8
  %v3629 = load i64, ptr %slot650, align 8
  %op3630 = and i64 %v3628, %v3629
  store i64 %op3630, ptr %slot652, align 8
  %v3631 = load i64, ptr %slot649, align 8
  %v3632 = load i64, ptr %slot652, align 8
  %op3633 = add i64 %v3631, %v3632
  store i64 %op3633, ptr %slot653, align 8
  %v3634 = load i64, ptr %slot653, align 8
  %v3635 = load i64, ptr %slot650, align 8
  %cmp3636 = icmp ult i64 %v3634, %v3635
  %cv3637 = zext i1 %cmp3636 to i64
  store i64 %cv3637, ptr %slot654, align 8
  %v3638 = load i64, ptr %slot654, align 8
  %cond3639 = icmp ne i64 %v3638, 0
  br i1 %cond3639, label %bb_success807, label %bb_failed807
bb_failed807:
  %v3640 = load i64, ptr %slot1, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %v3642 = load i64, ptr %slot649, align 8
  %v3643 = load i64, ptr %slot650, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p3641, i64 %v3642, i64 %v3643) nomerge, !dbg !144
  unreachable
bb_success807:
  %v3644 = load i64, ptr %slot648, align 8
  %op3645 = add i64 %v3644, 32
  store i64 %op3645, ptr %slot655, align 8
  %v3646 = load i64, ptr %slot655, align 8
  %p3647 = inttoptr i64 %v3646 to ptr
  %ld3648 = load i64, ptr %p3647, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3648, ptr %slot656, align 8
  %v3649 = load i64, ptr %slot656, align 8
  %v3650 = load i64, ptr %slot653, align 8
  %op3651 = add i64 %v3649, %v3650
  store i64 %op3651, ptr %slot657, align 8
  %v3652 = load i64, ptr %slot656, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  %v3654 = load i64, ptr %slot653, align 8
  %egep3655 = getelementptr i8, ptr %p3653, i64 %v3654
  %ld3656 = load i8, ptr %egep3655, align 1, !alias.scope !12, !noalias !13
  %ext3657 = zext i8 %ld3656 to i64
  store i64 %ext3657, ptr %slot658, align 8
  %v3658 = load i64, ptr %slot658, align 8
  %v3659 = load i64, ptr %slot32, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  store i64 %v3658, ptr %p3660, align 8, !alias.scope !3, !noalias !4
  %v3661 = load i64, ptr %slot13, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %ld3663 = load i32, ptr %p3662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3663, ptr %slot659, align 8
  %v3664 = load i32, ptr %slot659, align 8
  %cv3665 = zext i32 %v3664 to i64
  %cond3666 = icmp ne i64 %cv3665, 0
  br i1 %cond3666, label %bb_rcslotdrop815, label %bb_rcslotdone815
bb_rcslotdrop815:
  %v3667 = load i64, ptr %slot13, align 8
  %p3668 = inttoptr i64 %v3667 to ptr
  store i32 0, ptr %p3668, align 4, !alias.scope !3, !noalias !4
  %v3669 = load i64, ptr %slot19, align 8
  store i64 %v3669, ptr %slot660, align 8
  %v3670 = load i64, ptr %slot14, align 8
  %p3671 = inttoptr i64 %v3670 to ptr
  %ld3672 = load i32, ptr %p3671, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3672, ptr %slot661, align 8
  %v3673 = load i32, ptr %slot661, align 8
  %op3674 = and i32 %v3673, 28
  store i32 %op3674, ptr %slot662, align 8
  %v3675 = load i32, ptr %slot662, align 8
  %cv3676 = zext i32 %v3675 to i64
  %cond3677 = icmp ne i64 %cv3676, 0
  br i1 %cond3677, label %bb_rcslotrole815, label %bb_rcslotowner815
bb_rcslotrole815:
  %v3678 = load i64, ptr %slot38, align 8
  store i64 %v3678, ptr %slot663, align 8
  %v3679 = load i64, ptr %slot660, align 8
  %p3680 = inttoptr i64 %v3679 to ptr
  %ld3681 = load i64, ptr %p3680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3681, ptr %slot664, align 8
  %v3682 = load i64, ptr %slot664, align 8
  %cmp3683 = icmp ne i64 %v3682, 0
  %cv3684 = zext i1 %cmp3683 to i32
  store i32 %cv3684, ptr %slot665, align 8
  %v3685 = load i32, ptr %slot665, align 8
  %cv3686 = zext i32 %v3685 to i64
  %cond3687 = icmp ne i64 %cv3686, 0
  br i1 %cond3687, label %bb_rcgnn831, label %bb_rcgdone831
bb_rcgnn831:
  %v3688 = load i64, ptr %slot664, align 8
  %op3689 = sub i64 %v3688, 16
  store i64 %op3689, ptr %slot666, align 8
  %v3690 = load i64, ptr %slot664, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  %rgep3692 = getelementptr i8, ptr %p3691, i64 -16
  %ld3693 = load i64, ptr %rgep3692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3693, ptr %slot667, align 8
  %v3694 = load i64, ptr %slot667, align 8
  %op3695 = and i64 %v3694, 4611686018427387906
  store i64 %op3695, ptr %slot668, align 8
  %v3696 = load i64, ptr %slot668, align 8
  %cmp3697 = icmp ne i64 %v3696, 0
  %cv3698 = zext i1 %cmp3697 to i32
  store i32 %cv3698, ptr %slot669, align 8
  %v3699 = load i32, ptr %slot669, align 8
  %cv3700 = zext i32 %v3699 to i64
  %cond3701 = icmp ne i64 %cv3700, 0
  br i1 %cond3701, label %bb_rcgclear831, label %bb_rcgcounted831
bb_rcgcounted831:
  %v3702 = load i64, ptr %slot664, align 8
  %op3703 = sub i64 %v3702, 24
  store i64 %op3703, ptr %slot670, align 8
  %v3704 = load i64, ptr %slot664, align 8
  %p3705 = inttoptr i64 %v3704 to ptr
  %rgep3706 = getelementptr i8, ptr %p3705, i64 -24
  %ld3707 = load i64, ptr %rgep3706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3707, ptr %slot671, align 8
  %v3708 = load i64, ptr %slot671, align 8
  %op3709 = sub i64 %v3708, 1
  store i64 %op3709, ptr %slot672, align 8
  %v3710 = load i64, ptr %slot672, align 8
  %cmp3711 = icmp eq i64 %v3710, 0
  %cv3712 = zext i1 %cmp3711 to i32
  store i32 %cv3712, ptr %slot673, align 8
  %v3713 = load i32, ptr %slot673, align 8
  %cv3714 = zext i32 %v3713 to i64
  %cond3715 = icmp ne i64 %cv3714, 0
  br i1 %cond3715, label %bb_rcglast831, label %bb_rcgdec831
bb_rcglast831:
  %v3716 = load i64, ptr %slot664, align 8
  %op3717 = sub i64 %v3716, 32
  store i64 %op3717, ptr %slot674, align 8
  %v3718 = load i64, ptr %slot664, align 8
  %p3719 = inttoptr i64 %v3718 to ptr
  %rgep3720 = getelementptr i8, ptr %p3719, i64 -32
  %ld3721 = load i64, ptr %rgep3720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3721, ptr %slot675, align 8
  %v3722 = load i64, ptr %slot675, align 8
  %cmp3723 = icmp ne i64 %v3722, 0
  %cv3724 = zext i1 %cmp3723 to i32
  store i32 %cv3724, ptr %slot676, align 8
  %v3725 = load i32, ptr %slot676, align 8
  %cv3726 = zext i32 %v3725 to i64
  %cond3727 = icmp ne i64 %cv3726, 0
  br i1 %cond3727, label %bb_rcgdec831, label %bb_rcgslow831
bb_rcgslow831:
  %v3728 = load i64, ptr %slot663, align 8
  %v3729 = load i64, ptr %slot660, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3728, i64 %v3729) nomerge, !dbg !144
  br label %bb_rcgdone831
bb_rcgdec831:
  %v3730 = load i64, ptr %slot672, align 8
  %v3731 = load i64, ptr %slot664, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  %rgep3733 = getelementptr i8, ptr %p3732, i64 -24
  store i64 %v3730, ptr %rgep3733, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear831
bb_rcgclear831:
  %v3734 = load i64, ptr %slot660, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  store i64 0, ptr %p3735, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone831
bb_rcgdone831:
  br label %bb_rcslotdone815
bb_rcslotowner815:
  %v3736 = load i64, ptr %slot38, align 8
  store i64 %v3736, ptr %slot677, align 8
  %v3737 = load i64, ptr %slot660, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  %ld3739 = load i64, ptr %p3738, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3739, ptr %slot678, align 8
  %v3740 = load i64, ptr %slot678, align 8
  %cmp3741 = icmp ne i64 %v3740, 0
  %cv3742 = zext i1 %cmp3741 to i32
  store i32 %cv3742, ptr %slot679, align 8
  %v3743 = load i32, ptr %slot679, align 8
  %cv3744 = zext i32 %v3743 to i64
  %cond3745 = icmp ne i64 %cv3744, 0
  br i1 %cond3745, label %bb_rcgnn846, label %bb_rcgdone846
bb_rcgnn846:
  %v3746 = load i64, ptr %slot678, align 8
  %op3747 = sub i64 %v3746, 16
  store i64 %op3747, ptr %slot680, align 8
  %v3748 = load i64, ptr %slot678, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  %rgep3750 = getelementptr i8, ptr %p3749, i64 -16
  %ld3751 = load i64, ptr %rgep3750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3751, ptr %slot681, align 8
  %v3752 = load i64, ptr %slot681, align 8
  %op3753 = and i64 %v3752, 4611686018427387906
  store i64 %op3753, ptr %slot682, align 8
  %v3754 = load i64, ptr %slot682, align 8
  %cmp3755 = icmp ne i64 %v3754, 0
  %cv3756 = zext i1 %cmp3755 to i32
  store i32 %cv3756, ptr %slot683, align 8
  %v3757 = load i32, ptr %slot683, align 8
  %cv3758 = zext i32 %v3757 to i64
  %cond3759 = icmp ne i64 %cv3758, 0
  br i1 %cond3759, label %bb_rcgclear846, label %bb_rcgcounted846
bb_rcgcounted846:
  %v3760 = load i64, ptr %slot678, align 8
  %op3761 = sub i64 %v3760, 32
  store i64 %op3761, ptr %slot684, align 8
  %v3762 = load i64, ptr %slot678, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %rgep3764 = getelementptr i8, ptr %p3763, i64 -32
  %ld3765 = load i64, ptr %rgep3764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3765, ptr %slot685, align 8
  %v3766 = load i64, ptr %slot685, align 8
  %op3767 = sub i64 %v3766, 1
  store i64 %op3767, ptr %slot686, align 8
  %v3768 = load i64, ptr %slot686, align 8
  %cmp3769 = icmp eq i64 %v3768, 0
  %cv3770 = zext i1 %cmp3769 to i32
  store i32 %cv3770, ptr %slot687, align 8
  %v3771 = load i32, ptr %slot687, align 8
  %cv3772 = zext i32 %v3771 to i64
  %cond3773 = icmp ne i64 %cv3772, 0
  br i1 %cond3773, label %bb_rcglast846, label %bb_rcgdec846
bb_rcglast846:
  %v3774 = load i64, ptr %slot678, align 8
  %op3775 = sub i64 %v3774, 24
  store i64 %op3775, ptr %slot688, align 8
  %v3776 = load i64, ptr %slot678, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  %rgep3778 = getelementptr i8, ptr %p3777, i64 -24
  %ld3779 = load i64, ptr %rgep3778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3779, ptr %slot689, align 8
  %v3780 = load i64, ptr %slot689, align 8
  %cmp3781 = icmp ne i64 %v3780, 0
  %cv3782 = zext i1 %cmp3781 to i32
  store i32 %cv3782, ptr %slot690, align 8
  %v3783 = load i32, ptr %slot690, align 8
  %cv3784 = zext i32 %v3783 to i64
  %cond3785 = icmp ne i64 %cv3784, 0
  br i1 %cond3785, label %bb_rcgdec846, label %bb_rcgslow846
bb_rcgslow846:
  %v3786 = load i64, ptr %slot677, align 8
  %v3787 = load i64, ptr %slot660, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3786, i64 %v3787) nomerge, !dbg !144
  br label %bb_rcgdone846
bb_rcgdec846:
  %v3788 = load i64, ptr %slot686, align 8
  %v3789 = load i64, ptr %slot678, align 8
  %p3790 = inttoptr i64 %v3789 to ptr
  %rgep3791 = getelementptr i8, ptr %p3790, i64 -32
  store i64 %v3788, ptr %rgep3791, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear846
bb_rcgclear846:
  %v3792 = load i64, ptr %slot660, align 8
  %p3793 = inttoptr i64 %v3792 to ptr
  store i64 0, ptr %p3793, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone846
bb_rcgdone846:
  br label %bb_rcslotdone815
bb_rcslotdone815:
  %v3794 = load i64, ptr %slot32, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  %ld3796 = load i64, ptr %p3795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3796, ptr %slot691, align 8
  %v3797 = load i64, ptr %slot691, align 8
  %v3798 = load i64, ptr %slot32, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  store i64 %v3797, ptr %p3799, align 8, !alias.scope !3, !noalias !4
  br label %bb_i74
bb_i74:
  %v3800 = load i64, ptr %slot32, align 8
  %p3801 = inttoptr i64 %v3800 to ptr
  %ld3802 = load i64, ptr %p3801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3802, ptr %slot692, align 8
  %v3803 = load i64, ptr %slot692, align 8
  %v3804 = load i64, ptr %slot31, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  store i64 %v3803, ptr %p3805, align 8, !alias.scope !3, !noalias !4
  %v3806 = load i64, ptr %slot31, align 8
  %p3807 = inttoptr i64 %v3806 to ptr
  %ld3808 = load i64, ptr %p3807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3808, ptr %slot693, align 8
  %v3809 = load i64, ptr %slot693, align 8
  %v3810 = load i64, ptr %slot32, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  store i64 %v3809, ptr %p3811, align 8, !alias.scope !3, !noalias !4
  %v3812 = load i64, ptr %slot33, align 8
  %p3813 = inttoptr i64 %v3812 to ptr
  store i64 48, ptr %p3813, align 8, !alias.scope !3, !noalias !4
  %v3814 = load i64, ptr %slot33, align 8
  %p3815 = inttoptr i64 %v3814 to ptr
  %ld3816 = load i64, ptr %p3815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3816, ptr %slot694, align 8
  %v3817 = load i64, ptr %slot32, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  %ld3819 = load i64, ptr %p3818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3819, ptr %slot695, align 8
  %v3820 = load i64, ptr %slot695, align 8
  %v3821 = load i64, ptr %slot694, align 8
  %cmp3822 = icmp sge i64 %v3820, %v3821
  %cv3823 = zext i1 %cmp3822 to i64
  store i64 %cv3823, ptr %slot696, align 8
  %v3824 = load i64, ptr %slot696, align 8
  %v3825 = load i64, ptr %slot32, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  store i64 %v3824, ptr %p3826, align 8, !alias.scope !3, !noalias !4
  %v3827 = load i64, ptr %slot32, align 8
  %p3828 = inttoptr i64 %v3827 to ptr
  %ld3829 = load i64, ptr %p3828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3829, ptr %slot697, align 8
  %v3830 = load i64, ptr %slot697, align 8
  %cond3831 = icmp ne i64 %v3830, 0
  br i1 %cond3831, label %bb_next857, label %bb_i83
bb_next857:
  %v3832 = load i64, ptr %slot31, align 8
  %p3833 = inttoptr i64 %v3832 to ptr
  %ld3834 = load i64, ptr %p3833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3834, ptr %slot698, align 8
  %v3835 = load i64, ptr %slot698, align 8
  %v3836 = load i64, ptr %slot32, align 8
  %p3837 = inttoptr i64 %v3836 to ptr
  store i64 %v3835, ptr %p3837, align 8, !alias.scope !3, !noalias !4
  %v3838 = load i64, ptr %slot33, align 8
  %p3839 = inttoptr i64 %v3838 to ptr
  store i64 57, ptr %p3839, align 8, !alias.scope !3, !noalias !4
  %v3840 = load i64, ptr %slot33, align 8
  %p3841 = inttoptr i64 %v3840 to ptr
  %ld3842 = load i64, ptr %p3841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3842, ptr %slot699, align 8
  %v3843 = load i64, ptr %slot32, align 8
  %p3844 = inttoptr i64 %v3843 to ptr
  %ld3845 = load i64, ptr %p3844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3845, ptr %slot700, align 8
  %v3846 = load i64, ptr %slot700, align 8
  %v3847 = load i64, ptr %slot699, align 8
  %cmp3848 = icmp sle i64 %v3846, %v3847
  %cv3849 = zext i1 %cmp3848 to i64
  store i64 %cv3849, ptr %slot701, align 8
  %v3850 = load i64, ptr %slot701, align 8
  %v3851 = load i64, ptr %slot32, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  store i64 %v3850, ptr %p3852, align 8, !alias.scope !3, !noalias !4
  br label %bb_i84
bb_i83:
  %v3853 = load i64, ptr %slot32, align 8
  %p3854 = inttoptr i64 %v3853 to ptr
  store i64 0, ptr %p3854, align 8, !alias.scope !3, !noalias !4
  br label %bb_i84
bb_i84:
  br label %bb_i85
bb_i85:
  %v3855 = load i64, ptr %slot32, align 8
  %p3856 = inttoptr i64 %v3855 to ptr
  %ld3857 = load i64, ptr %p3856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3857, ptr %slot702, align 8
  %v3858 = load i64, ptr %slot702, align 8
  %cond3859 = icmp ne i64 %v3858, 0
  br i1 %cond3859, label %bb_next862, label %bb_i102
bb_next862:
  %v3860 = load i64, ptr %slot24, align 8
  %p3861 = inttoptr i64 %v3860 to ptr
  %ld3862 = load i64, ptr %p3861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3862, ptr %slot703, align 8
  %v3863 = load i64, ptr %slot703, align 8
  %v3864 = load i64, ptr %slot32, align 8
  %p3865 = inttoptr i64 %v3864 to ptr
  store i64 %v3863, ptr %p3865, align 8, !alias.scope !3, !noalias !4
  %v3866 = load i64, ptr %slot32, align 8
  %p3867 = inttoptr i64 %v3866 to ptr
  %ld3868 = load i64, ptr %p3867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3868, ptr %slot704, align 8
  %v3869 = load i64, ptr %slot704, align 8
  %op3870 = add i64 %v3869, 16
  store i64 %op3870, ptr %slot705, align 8
  %v3871 = load i64, ptr %slot705, align 8
  %p3872 = inttoptr i64 %v3871 to ptr
  %ld3873 = load i64, ptr %p3872, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3873, ptr %slot706, align 8
  %v3874 = load i64, ptr %slot706, align 8
  %v3875 = load i64, ptr %slot32, align 8
  %p3876 = inttoptr i64 %v3875 to ptr
  store i64 %v3874, ptr %p3876, align 8, !alias.scope !3, !noalias !4
  %v3877 = load i64, ptr %slot13, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  %ld3879 = load i32, ptr %p3878, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3879, ptr %slot707, align 8
  %v3880 = load i32, ptr %slot707, align 8
  %cv3881 = zext i32 %v3880 to i64
  %cond3882 = icmp ne i64 %cv3881, 0
  br i1 %cond3882, label %bb_rcslotdrop868, label %bb_rcslotdone868
bb_rcslotdrop868:
  %v3883 = load i64, ptr %slot13, align 8
  %p3884 = inttoptr i64 %v3883 to ptr
  store i32 0, ptr %p3884, align 4, !alias.scope !3, !noalias !4
  %v3885 = load i64, ptr %slot19, align 8
  store i64 %v3885, ptr %slot708, align 8
  %v3886 = load i64, ptr %slot14, align 8
  %p3887 = inttoptr i64 %v3886 to ptr
  %ld3888 = load i32, ptr %p3887, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3888, ptr %slot709, align 8
  %v3889 = load i32, ptr %slot709, align 8
  %op3890 = and i32 %v3889, 28
  store i32 %op3890, ptr %slot710, align 8
  %v3891 = load i32, ptr %slot710, align 8
  %cv3892 = zext i32 %v3891 to i64
  %cond3893 = icmp ne i64 %cv3892, 0
  br i1 %cond3893, label %bb_rcslotrole868, label %bb_rcslotowner868
bb_rcslotrole868:
  %v3894 = load i64, ptr %slot38, align 8
  store i64 %v3894, ptr %slot711, align 8
  %v3895 = load i64, ptr %slot711, align 8
  %v3896 = load i64, ptr %slot708, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3895, i64 %v3896) nomerge, !dbg !146
  br label %bb_rcslotdone868
bb_rcslotowner868:
  %v3897 = load i64, ptr %slot38, align 8
  store i64 %v3897, ptr %slot712, align 8
  %v3898 = load i64, ptr %slot712, align 8
  %v3899 = load i64, ptr %slot708, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3898, i64 %v3899) nomerge, !dbg !146
  br label %bb_rcslotdone868
bb_rcslotdone868:
  %v3900 = load i64, ptr %slot33, align 8
  %p3901 = inttoptr i64 %v3900 to ptr
  store i64 1, ptr %p3901, align 8, !alias.scope !3, !noalias !4
  %v3902 = load i64, ptr %slot33, align 8
  %p3903 = inttoptr i64 %v3902 to ptr
  %ld3904 = load i64, ptr %p3903, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3904, ptr %slot713, align 8
  %v3905 = load i64, ptr %slot32, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  %ld3907 = load i64, ptr %p3906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3907, ptr %slot714, align 8
  %v3908 = load i64, ptr %slot714, align 8
  %v3909 = load i64, ptr %slot713, align 8
  %ovpair3911 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3908, i64 %v3909)
  %op3910 = extractvalue { i64, i1 } %ovpair3911, 0
  %ov3912 = extractvalue { i64, i1 } %ovpair3911, 1
  store i64 %op3910, ptr %slot715, align 8
  %cv3913 = zext i1 %ov3912 to i64
  store i64 %cv3913, ptr %slot716, align 8
  %v3914 = load i64, ptr %slot716, align 8
  %cond3915 = icmp ne i64 %v3914, 0
  br i1 %cond3915, label %bb_overflow877, label %bb_checked877
bb_overflow877:
  %v3916 = load i64, ptr %slot1, align 8
  %p3917 = inttoptr i64 %v3916 to ptr
  %v3918 = load i64, ptr %slot714, align 8
  %v3919 = load i64, ptr %slot713, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3917, i64 0, i64 %v3918, i64 %v3919, i64 64) nomerge, !dbg !148
  unreachable
bb_checked877:
  %v3920 = load i64, ptr %slot715, align 8
  %v3921 = load i64, ptr %slot32, align 8
  %p3922 = inttoptr i64 %v3921 to ptr
  store i64 %v3920, ptr %p3922, align 8, !alias.scope !3, !noalias !4
  %v3923 = load i64, ptr %slot32, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  %ld3925 = load i64, ptr %p3924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3925, ptr %slot717, align 8
  %v3926 = load i64, ptr %slot717, align 8
  %v3927 = load i64, ptr %slot25, align 8
  %p3928 = inttoptr i64 %v3927 to ptr
  store i64 %v3926, ptr %p3928, align 8, !alias.scope !3, !noalias !4
  %v3929 = load i64, ptr %slot24, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  %ld3931 = load i64, ptr %p3930, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3931, ptr %slot718, align 8
  %v3932 = load i64, ptr %slot718, align 8
  %v3933 = load i64, ptr %slot32, align 8
  %p3934 = inttoptr i64 %v3933 to ptr
  store i64 %v3932, ptr %p3934, align 8, !alias.scope !3, !noalias !4
  %v3935 = load i64, ptr %slot24, align 8
  %p3936 = inttoptr i64 %v3935 to ptr
  %ld3937 = load i64, ptr %p3936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3937, ptr %slot719, align 8
  %v3938 = load i64, ptr %slot719, align 8
  %v3939 = load i64, ptr %slot32, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  store i64 %v3938, ptr %p3940, align 8, !alias.scope !3, !noalias !4
  %v3941 = load i64, ptr %slot24, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  %ld3943 = load i64, ptr %p3942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3943, ptr %slot720, align 8
  %v3944 = load i64, ptr %slot720, align 8
  %v3945 = load i64, ptr %slot32, align 8
  %p3946 = inttoptr i64 %v3945 to ptr
  store i64 %v3944, ptr %p3946, align 8, !alias.scope !3, !noalias !4
  %v3947 = load i64, ptr %slot25, align 8
  %p3948 = inttoptr i64 %v3947 to ptr
  %ld3949 = load i64, ptr %p3948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3949, ptr %slot721, align 8
  %v3950 = load i64, ptr %slot721, align 8
  %v3951 = load i64, ptr %slot33, align 8
  %p3952 = inttoptr i64 %v3951 to ptr
  store i64 %v3950, ptr %p3952, align 8, !alias.scope !3, !noalias !4
  %v3953 = load i64, ptr %slot24, align 8
  %p3954 = inttoptr i64 %v3953 to ptr
  %ld3955 = load i64, ptr %p3954, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3955, ptr %slot722, align 8
  %v3956 = load i64, ptr %slot722, align 8
  %v3957 = load i64, ptr %slot32, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  store i64 %v3956, ptr %p3958, align 8, !alias.scope !3, !noalias !4
  %v3959 = load i64, ptr %slot25, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  %ld3961 = load i64, ptr %p3960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3961, ptr %slot723, align 8
  %v3962 = load i64, ptr %slot24, align 8
  %p3963 = inttoptr i64 %v3962 to ptr
  %ld3964 = load i64, ptr %p3963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3964, ptr %slot724, align 8
  %v3965 = load i64, ptr %slot724, align 8
  %op3966 = add i64 %v3965, 16
  store i64 %op3966, ptr %slot725, align 8
  %v3967 = load i64, ptr %slot723, align 8
  %v3968 = load i64, ptr %slot725, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  store i64 %v3967, ptr %p3969, align 8, !alias.scope !4, !noalias !3
  %v3970 = load i64, ptr %slot32, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  store i64 0, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i102:
  %v3972 = load i64, ptr %slot24, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  %ld3974 = load i64, ptr %p3973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3974, ptr %slot726, align 8
  %v3975 = load i64, ptr %slot726, align 8
  %v3976 = load i64, ptr %slot32, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  store i64 %v3975, ptr %p3977, align 8, !alias.scope !3, !noalias !4
  %v3978 = load i64, ptr %slot24, align 8
  %p3979 = inttoptr i64 %v3978 to ptr
  %ld3980 = load i64, ptr %p3979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3980, ptr %slot727, align 8
  %v3981 = load i64, ptr %slot727, align 8
  %v3982 = load i64, ptr %slot33, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  store i64 %v3981, ptr %p3983, align 8, !alias.scope !3, !noalias !4
  %v3984 = load i64, ptr %slot33, align 8
  %p3985 = inttoptr i64 %v3984 to ptr
  %ld3986 = load i64, ptr %p3985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3986, ptr %slot728, align 8
  %v3987 = load i64, ptr %slot1, align 8
  %v3988 = load i64, ptr %slot728, align 8
  %call3989 = call i32 @myl_f_326edaf078a628d32599374ac5ee44ddf8c48c954b8b85920092e28da880e5a2(i64 %v3987, i64 %v3988) nomerge, !dbg !150
  store i32 %call3989, ptr %callresult730, align 4
  %addr3990 = ptrtoint ptr %callresult730 to i64
  store i64 %addr3990, ptr %slot729, align 8
  %v3991 = load i64, ptr %slot729, align 8
  %v3992 = load i64, ptr %slot33, align 8
  %p3993 = inttoptr i64 %v3992 to ptr
  store i64 %v3991, ptr %p3993, align 8, !alias.scope !3, !noalias !4
  %v3994 = load i64, ptr %slot15, align 8
  %p3995 = inttoptr i64 %v3994 to ptr
  %ld3996 = load i32, ptr %p3995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3996, ptr %slot731, align 8
  %v3997 = load i32, ptr %slot731, align 8
  %cv3998 = zext i32 %v3997 to i64
  %cond3999 = icmp ne i64 %cv3998, 0
  br i1 %cond3999, label %bb_rcslotdrop894, label %bb_rcslotdone894
bb_rcslotdrop894:
  %v4000 = load i64, ptr %slot15, align 8
  %p4001 = inttoptr i64 %v4000 to ptr
  store i32 0, ptr %p4001, align 4, !alias.scope !3, !noalias !4
  %v4002 = load i64, ptr %slot20, align 8
  store i64 %v4002, ptr %slot732, align 8
  %v4003 = load i64, ptr %slot16, align 8
  %p4004 = inttoptr i64 %v4003 to ptr
  %ld4005 = load i32, ptr %p4004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4005, ptr %slot733, align 8
  %v4006 = load i32, ptr %slot733, align 8
  %op4007 = and i32 %v4006, 28
  store i32 %op4007, ptr %slot734, align 8
  %v4008 = load i32, ptr %slot734, align 8
  %cv4009 = zext i32 %v4008 to i64
  %cond4010 = icmp ne i64 %cv4009, 0
  br i1 %cond4010, label %bb_rcslotrole894, label %bb_rcslotowner894
bb_rcslotrole894:
  %v4011 = load i64, ptr %slot38, align 8
  store i64 %v4011, ptr %slot735, align 8
  %v4012 = load i64, ptr %slot735, align 8
  %v4013 = load i64, ptr %slot732, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4012, i64 %v4013) nomerge, !dbg !150
  br label %bb_rcslotdone894
bb_rcslotowner894:
  %v4014 = load i64, ptr %slot38, align 8
  store i64 %v4014, ptr %slot736, align 8
  %v4015 = load i64, ptr %slot736, align 8
  %v4016 = load i64, ptr %slot732, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4015, i64 %v4016) nomerge, !dbg !150
  br label %bb_rcslotdone894
bb_rcslotdone894:
  %v4017 = load i64, ptr %slot32, align 8
  %p4018 = inttoptr i64 %v4017 to ptr
  %ld4019 = load i64, ptr %p4018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4019, ptr %slot737, align 8
  %v4020 = load i64, ptr %slot33, align 8
  %p4021 = inttoptr i64 %v4020 to ptr
  %ld4022 = load i64, ptr %p4021, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4022, ptr %slot738, align 8
  %v4023 = load i64, ptr %slot1, align 8
  %v4024 = load i64, ptr %slot737, align 8
  %v4025 = load i64, ptr %slot738, align 8
  call void @myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d(ptr sret([40 x i8]) align 8 %callresult740, i64 %v4023, i64 %v4024, i64 %v4025) nomerge, !dbg !152
  %addr4026 = ptrtoint ptr %callresult740 to i64
  store i64 %addr4026, ptr %slot739, align 8
  %v4027 = load i64, ptr %slot739, align 8
  %v4028 = load i64, ptr %slot32, align 8
  %p4029 = inttoptr i64 %v4028 to ptr
  store i64 %v4027, ptr %p4029, align 8, !alias.scope !3, !noalias !4
  %v4030 = load i64, ptr %slot32, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  %ld4032 = load i64, ptr %p4031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4032, ptr %slot741, align 8
  %v4033 = load i64, ptr %slot23, align 8
  store i64 %v4033, ptr %slot742, align 8
  %v4034 = load i64, ptr %slot741, align 8
  %v4035 = load i64, ptr %slot742, align 8
  %p4036 = inttoptr i64 %v4034 to ptr
  %p4037 = inttoptr i64 %v4035 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4037, ptr %p4036, i64 40, i1 false)
  %v4038 = load i64, ptr %slot18, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  store i32 2, ptr %p4039, align 4, !alias.scope !3, !noalias !4
  %v4040 = load i64, ptr %slot17, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  store i32 1, ptr %p4041, align 4, !alias.scope !3, !noalias !4
  %v4042 = load i64, ptr %slot13, align 8
  %p4043 = inttoptr i64 %v4042 to ptr
  %ld4044 = load i32, ptr %p4043, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4044, ptr %slot743, align 8
  %v4045 = load i32, ptr %slot743, align 8
  %cv4046 = zext i32 %v4045 to i64
  %cond4047 = icmp ne i64 %cv4046, 0
  br i1 %cond4047, label %bb_rcslotdrop910, label %bb_rcslotdone910
bb_rcslotdrop910:
  %v4048 = load i64, ptr %slot13, align 8
  %p4049 = inttoptr i64 %v4048 to ptr
  store i32 0, ptr %p4049, align 4, !alias.scope !3, !noalias !4
  %v4050 = load i64, ptr %slot19, align 8
  store i64 %v4050, ptr %slot744, align 8
  %v4051 = load i64, ptr %slot14, align 8
  %p4052 = inttoptr i64 %v4051 to ptr
  %ld4053 = load i32, ptr %p4052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4053, ptr %slot745, align 8
  %v4054 = load i32, ptr %slot745, align 8
  %op4055 = and i32 %v4054, 28
  store i32 %op4055, ptr %slot746, align 8
  %v4056 = load i32, ptr %slot746, align 8
  %cv4057 = zext i32 %v4056 to i64
  %cond4058 = icmp ne i64 %cv4057, 0
  br i1 %cond4058, label %bb_rcslotrole910, label %bb_rcslotowner910
bb_rcslotrole910:
  %v4059 = load i64, ptr %slot38, align 8
  store i64 %v4059, ptr %slot747, align 8
  %v4060 = load i64, ptr %slot747, align 8
  %v4061 = load i64, ptr %slot744, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4060, i64 %v4061) nomerge, !dbg !152
  br label %bb_rcslotdone910
bb_rcslotowner910:
  %v4062 = load i64, ptr %slot38, align 8
  store i64 %v4062, ptr %slot748, align 8
  %v4063 = load i64, ptr %slot748, align 8
  %v4064 = load i64, ptr %slot744, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4063, i64 %v4064) nomerge, !dbg !152
  br label %bb_rcslotdone910
bb_rcslotdone910:
  %v4065 = load i64, ptr %slot19, align 8
  store i64 %v4065, ptr %slot749, align 8
  %v4066 = load i64, ptr %slot23, align 8
  store i64 %v4066, ptr %slot750, align 8
  %v4067 = load i64, ptr %slot750, align 8
  %v4068 = load i64, ptr %slot749, align 8
  %p4069 = inttoptr i64 %v4067 to ptr
  %p4070 = inttoptr i64 %v4068 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4070, ptr %p4069, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v4071 = load i64, ptr %slot14, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  store i32 2, ptr %p4072, align 4, !alias.scope !3, !noalias !4
  %v4073 = load i64, ptr %slot18, align 8
  %p4074 = inttoptr i64 %v4073 to ptr
  %ld4075 = load i32, ptr %p4074, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4075, ptr %slot751, align 8
  %v4076 = load i32, ptr %slot751, align 8
  %v4077 = load i64, ptr %slot14, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  store i32 %v4076, ptr %p4078, align 4, !alias.scope !3, !noalias !4
  %v4079 = load i64, ptr %slot17, align 8
  %p4080 = inttoptr i64 %v4079 to ptr
  store i32 0, ptr %p4080, align 4, !alias.scope !3, !noalias !4
  %v4081 = load i64, ptr %slot13, align 8
  %p4082 = inttoptr i64 %v4081 to ptr
  store i32 1, ptr %p4082, align 4, !alias.scope !3, !noalias !4
  %v4083 = load i64, ptr %slot749, align 8
  %v4084 = load i64, ptr %slot32, align 8
  %p4085 = inttoptr i64 %v4084 to ptr
  store i64 %v4083, ptr %p4085, align 8, !alias.scope !3, !noalias !4
  %v4086 = load i64, ptr %slot32, align 8
  %p4087 = inttoptr i64 %v4086 to ptr
  %ld4088 = load i64, ptr %p4087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4088, ptr %slot752, align 8
  %v4089 = load i64, ptr %slot32, align 8
  %p4090 = inttoptr i64 %v4089 to ptr
  %ld4091 = load i64, ptr %p4090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4091, ptr %slot753, align 8
  %v4092 = load i64, ptr %slot23, align 8
  store i64 %v4092, ptr %slot754, align 8
  %v4093 = load i64, ptr %slot39, align 8
  store i64 %v4093, ptr %slot755, align 8
  %v4094 = load i64, ptr %slot38, align 8
  %v4095 = load i64, ptr %slot754, align 8
  %v4096 = load i64, ptr %slot753, align 8
  %v4097 = load i64, ptr %slot755, align 8
  %cv4098 = trunc i64 %v4097 to i32
  %call4099 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v4094, i64 %v4095, i64 %v4096, i32 %cv4098) nomerge, !dbg !154
  store i32 %call4099, ptr %slot756, align 8
  %v4100 = load i32, ptr %slot756, align 8
  %cv4101 = zext i32 %v4100 to i64
  %cond4102 = icmp ne i64 %cv4101, 0
  br i1 %cond4102, label %bb_rcsuccess930, label %bb_rcfailure930
bb_rcfailure930:
  %v4103 = load i64, ptr %slot38, align 8
  %p4104 = inttoptr i64 %v4103 to ptr
  %call4105 = call i32 @myl_rc_take_failure(ptr %p4104) nomerge, !dbg !154
  store i32 %call4105, ptr %slot757, align 8
  %v4106 = load i64, ptr %slot1, align 8
  %p4107 = inttoptr i64 %v4106 to ptr
  %v4108 = load i32, ptr %slot757, align 8
  %call4109 = call i32 @myl_qbe_rc_status(ptr %p4107, i32 %v4108) nomerge, !dbg !154
  store i32 %call4109, ptr %slot758, align 8
  br label %bb_failure
bb_rcsuccess930:
  %v4110 = load i64, ptr %slot13, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  store i32 0, ptr %p4111, align 4, !alias.scope !3, !noalias !4
  %v4112 = load i64, ptr %slot18, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  store i32 2, ptr %p4113, align 4, !alias.scope !3, !noalias !4
  %v4114 = load i64, ptr %slot17, align 8
  %p4115 = inttoptr i64 %v4114 to ptr
  store i32 1, ptr %p4115, align 4, !alias.scope !3, !noalias !4
  %v4116 = load i64, ptr %slot23, align 8
  store i64 %v4116, ptr %slot759, align 8
  %v4117 = load i64, ptr %slot17, align 8
  %p4118 = inttoptr i64 %v4117 to ptr
  store i32 0, ptr %p4118, align 4, !alias.scope !3, !noalias !4
  %v4119 = load i64, ptr %slot13, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  %ld4121 = load i32, ptr %p4120, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4121, ptr %slot760, align 8
  %v4122 = load i32, ptr %slot760, align 8
  %cv4123 = zext i32 %v4122 to i64
  %cond4124 = icmp ne i64 %cv4123, 0
  br i1 %cond4124, label %bb_rcslotdrop940, label %bb_rcslotdone940
bb_rcslotdrop940:
  %v4125 = load i64, ptr %slot13, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  store i32 0, ptr %p4126, align 4, !alias.scope !3, !noalias !4
  %v4127 = load i64, ptr %slot19, align 8
  store i64 %v4127, ptr %slot761, align 8
  %v4128 = load i64, ptr %slot14, align 8
  %p4129 = inttoptr i64 %v4128 to ptr
  %ld4130 = load i32, ptr %p4129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4130, ptr %slot762, align 8
  %v4131 = load i32, ptr %slot762, align 8
  %op4132 = and i32 %v4131, 28
  store i32 %op4132, ptr %slot763, align 8
  %v4133 = load i32, ptr %slot763, align 8
  %cv4134 = zext i32 %v4133 to i64
  %cond4135 = icmp ne i64 %cv4134, 0
  br i1 %cond4135, label %bb_rcslotrole940, label %bb_rcslotowner940
bb_rcslotrole940:
  %v4136 = load i64, ptr %slot38, align 8
  store i64 %v4136, ptr %slot764, align 8
  %v4137 = load i64, ptr %slot764, align 8
  %v4138 = load i64, ptr %slot761, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4137, i64 %v4138) nomerge, !dbg !154
  br label %bb_rcslotdone940
bb_rcslotowner940:
  %v4139 = load i64, ptr %slot38, align 8
  store i64 %v4139, ptr %slot765, align 8
  %v4140 = load i64, ptr %slot765, align 8
  %v4141 = load i64, ptr %slot761, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4140, i64 %v4141) nomerge, !dbg !154
  br label %bb_rcslotdone940
bb_rcslotdone940:
  %v4142 = load i64, ptr %slot11, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  %ld4144 = load i32, ptr %p4143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4144, ptr %slot766, align 8
  %v4145 = load i32, ptr %slot766, align 8
  %cv4146 = zext i32 %v4145 to i64
  %cond4147 = icmp ne i64 %cv4146, 0
  br i1 %cond4147, label %bb_rcslotdrop949, label %bb_rcslotdone949
bb_rcslotdrop949:
  %v4148 = load i64, ptr %slot11, align 8
  %p4149 = inttoptr i64 %v4148 to ptr
  store i32 0, ptr %p4149, align 4, !alias.scope !3, !noalias !4
  %v4150 = load i64, ptr %slot30, align 8
  store i64 %v4150, ptr %slot767, align 8
  %v4151 = load i64, ptr %slot12, align 8
  %p4152 = inttoptr i64 %v4151 to ptr
  %ld4153 = load i32, ptr %p4152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4153, ptr %slot768, align 8
  %v4154 = load i32, ptr %slot768, align 8
  %op4155 = and i32 %v4154, 28
  store i32 %op4155, ptr %slot769, align 8
  %v4156 = load i32, ptr %slot769, align 8
  %cv4157 = zext i32 %v4156 to i64
  %cond4158 = icmp ne i64 %cv4157, 0
  br i1 %cond4158, label %bb_rcslotrole949, label %bb_rcslotowner949
bb_rcslotrole949:
  %v4159 = load i64, ptr %slot38, align 8
  store i64 %v4159, ptr %slot770, align 8
  %v4160 = load i64, ptr %slot770, align 8
  %v4161 = load i64, ptr %slot767, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4160, i64 %v4161) nomerge, !dbg !154
  br label %bb_rcslotdone949
bb_rcslotowner949:
  %v4162 = load i64, ptr %slot38, align 8
  store i64 %v4162, ptr %slot771, align 8
  %v4163 = load i64, ptr %slot771, align 8
  %v4164 = load i64, ptr %slot767, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4163, i64 %v4164) nomerge, !dbg !154
  br label %bb_rcslotdone949
bb_rcslotdone949:
  %v4165 = load i64, ptr %slot9, align 8
  %p4166 = inttoptr i64 %v4165 to ptr
  %ld4167 = load i32, ptr %p4166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4167, ptr %slot772, align 8
  %v4168 = load i32, ptr %slot772, align 8
  %cv4169 = zext i32 %v4168 to i64
  %cond4170 = icmp ne i64 %cv4169, 0
  br i1 %cond4170, label %bb_rcslotdrop958, label %bb_rcslotdone958
bb_rcslotdrop958:
  %v4171 = load i64, ptr %slot9, align 8
  %p4172 = inttoptr i64 %v4171 to ptr
  store i32 0, ptr %p4172, align 4, !alias.scope !3, !noalias !4
  %v4173 = load i64, ptr %slot29, align 8
  store i64 %v4173, ptr %slot773, align 8
  %v4174 = load i64, ptr %slot10, align 8
  %p4175 = inttoptr i64 %v4174 to ptr
  %ld4176 = load i32, ptr %p4175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4176, ptr %slot774, align 8
  %v4177 = load i32, ptr %slot774, align 8
  %op4178 = and i32 %v4177, 28
  store i32 %op4178, ptr %slot775, align 8
  %v4179 = load i32, ptr %slot775, align 8
  %cv4180 = zext i32 %v4179 to i64
  %cond4181 = icmp ne i64 %cv4180, 0
  br i1 %cond4181, label %bb_rcslotrole958, label %bb_rcslotowner958
bb_rcslotrole958:
  %v4182 = load i64, ptr %slot38, align 8
  store i64 %v4182, ptr %slot776, align 8
  %v4183 = load i64, ptr %slot776, align 8
  %v4184 = load i64, ptr %slot773, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4183, i64 %v4184) nomerge, !dbg !154
  br label %bb_rcslotdone958
bb_rcslotowner958:
  %v4185 = load i64, ptr %slot38, align 8
  store i64 %v4185, ptr %slot777, align 8
  %v4186 = load i64, ptr %slot777, align 8
  %v4187 = load i64, ptr %slot773, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4186, i64 %v4187) nomerge, !dbg !154
  br label %bb_rcslotdone958
bb_rcslotdone958:
  %v4188 = load i64, ptr %slot7, align 8
  %p4189 = inttoptr i64 %v4188 to ptr
  %ld4190 = load i32, ptr %p4189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4190, ptr %slot778, align 8
  %v4191 = load i32, ptr %slot778, align 8
  %cv4192 = zext i32 %v4191 to i64
  %cond4193 = icmp ne i64 %cv4192, 0
  br i1 %cond4193, label %bb_rcslotdrop967, label %bb_rcslotdone967
bb_rcslotdrop967:
  %v4194 = load i64, ptr %slot7, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  store i32 0, ptr %p4195, align 4, !alias.scope !3, !noalias !4
  %v4196 = load i64, ptr %slot27, align 8
  store i64 %v4196, ptr %slot779, align 8
  %v4197 = load i64, ptr %slot8, align 8
  %p4198 = inttoptr i64 %v4197 to ptr
  %ld4199 = load i32, ptr %p4198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4199, ptr %slot780, align 8
  %v4200 = load i32, ptr %slot780, align 8
  %op4201 = and i32 %v4200, 28
  store i32 %op4201, ptr %slot781, align 8
  %v4202 = load i32, ptr %slot781, align 8
  %cv4203 = zext i32 %v4202 to i64
  %cond4204 = icmp ne i64 %cv4203, 0
  br i1 %cond4204, label %bb_rcslotrole967, label %bb_rcslotowner967
bb_rcslotrole967:
  %v4205 = load i64, ptr %slot38, align 8
  store i64 %v4205, ptr %slot782, align 8
  %v4206 = load i64, ptr %slot782, align 8
  %v4207 = load i64, ptr %slot779, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4206, i64 %v4207) nomerge, !dbg !154
  br label %bb_rcslotdone967
bb_rcslotowner967:
  %v4208 = load i64, ptr %slot38, align 8
  store i64 %v4208, ptr %slot783, align 8
  %v4209 = load i64, ptr %slot783, align 8
  %v4210 = load i64, ptr %slot779, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4209, i64 %v4210) nomerge, !dbg !154
  br label %bb_rcslotdone967
bb_rcslotdone967:
  %v4211 = load i64, ptr %slot5, align 8
  %p4212 = inttoptr i64 %v4211 to ptr
  %ld4213 = load i32, ptr %p4212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4213, ptr %slot784, align 8
  %v4214 = load i32, ptr %slot784, align 8
  %cv4215 = zext i32 %v4214 to i64
  %cond4216 = icmp ne i64 %cv4215, 0
  br i1 %cond4216, label %bb_rcslotdrop976, label %bb_rcslotdone976
bb_rcslotdrop976:
  %v4217 = load i64, ptr %slot5, align 8
  %p4218 = inttoptr i64 %v4217 to ptr
  store i32 0, ptr %p4218, align 4, !alias.scope !3, !noalias !4
  %v4219 = load i64, ptr %slot26, align 8
  store i64 %v4219, ptr %slot785, align 8
  %v4220 = load i64, ptr %slot6, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  %ld4222 = load i32, ptr %p4221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4222, ptr %slot786, align 8
  %v4223 = load i32, ptr %slot786, align 8
  %op4224 = and i32 %v4223, 28
  store i32 %op4224, ptr %slot787, align 8
  %v4225 = load i32, ptr %slot787, align 8
  %cv4226 = zext i32 %v4225 to i64
  %cond4227 = icmp ne i64 %cv4226, 0
  br i1 %cond4227, label %bb_rcslotrole976, label %bb_rcslotowner976
bb_rcslotrole976:
  %v4228 = load i64, ptr %slot38, align 8
  store i64 %v4228, ptr %slot788, align 8
  %v4229 = load i64, ptr %slot788, align 8
  %v4230 = load i64, ptr %slot785, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4229, i64 %v4230) nomerge, !dbg !154
  br label %bb_rcslotdone976
bb_rcslotowner976:
  %v4231 = load i64, ptr %slot38, align 8
  store i64 %v4231, ptr %slot789, align 8
  %v4232 = load i64, ptr %slot789, align 8
  %v4233 = load i64, ptr %slot785, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4232, i64 %v4233) nomerge, !dbg !154
  br label %bb_rcslotdone976
bb_rcslotdone976:
  %v4234 = load i64, ptr %slot759, align 8
  %p4235 = inttoptr i64 %v4234 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4235, i64 40, i1 false)
  ret void
bb_failure:
  %v4236 = load i64, ptr %slot4, align 8
  %p4237 = inttoptr i64 %v4236 to ptr
  call void @llvm.memset.p0.i64(ptr %p4237, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !154
  %v4238 = load i64, ptr %slot4, align 8
  %p4239 = inttoptr i64 %v4238 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4239, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v4240 = load i64, ptr %slot4, align 8
  %p4241 = inttoptr i64 %v4240 to ptr
  call void @llvm.memset.p0.i64(ptr %p4241, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !154
  %v4242 = load i64, ptr %slot4, align 8
  %p4243 = inttoptr i64 %v4242 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4243, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i32 @myl_f_326edaf078a628d32599374ac5ee44ddf8c48c954b8b85920092e28da880e5a2(i64, i64)
declare void @myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d(ptr sret([40 x i8]) align 8, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_2d2b10bd6054e77816c6cbbeab3482a55e313608087835e24de0bcc9662742ec", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_2d2b10bd6054e77816c6cbbeab3482a55e313608087835e24de0bcc9662742ec", linkageName: "myl_f_2d2b10bd6054e77816c6cbbeab3482a55e313608087835e24de0bcc9662742ec", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5433457315827161791, i64 0, !"myl_f_2d2b10bd6054e77816c6cbbeab3482a55e313608087835e24de0bcc9662742ec"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!130 = !DILocation(line: 55, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!132 = !DILocation(line: 57, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!134 = !DILocation(line: 59, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!136 = !DILocation(line: 61, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!138 = !DILocation(line: 62, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!140 = !DILocation(line: 69, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!142 = !DILocation(line: 71, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!144 = !DILocation(line: 72, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647239)
!146 = !DILocation(line: 88, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647255)
!148 = !DILocation(line: 90, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647375)
!150 = !DILocation(line: 105, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647383)
!152 = !DILocation(line: 106, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!154 = !DILocation(line: 107, column: 0, scope: !155)
