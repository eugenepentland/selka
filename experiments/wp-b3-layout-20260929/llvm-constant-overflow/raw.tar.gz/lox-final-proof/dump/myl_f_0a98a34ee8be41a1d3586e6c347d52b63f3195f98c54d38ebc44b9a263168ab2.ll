target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_0a98a34ee8be41a1d3586e6c347d52b63f3195f98c54d38ebc44b9a263168ab2(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v47 = load i64, ptr %slot1, align 8
  %op48 = add i64 %v47, 32
  store i64 %op48, ptr %slot3, align 8
  %mem49 = alloca i8, i64 8, align 8
  %ptr50 = ptrtoint ptr %mem49 to i64
  store i64 %ptr50, ptr %slot4, align 8
  %mem51 = alloca i8, i64 8, align 8
  %ptr52 = ptrtoint ptr %mem51 to i64
  store i64 %ptr52, ptr %slot5, align 8
  %mem53 = alloca i8, i64 8, align 8
  %ptr54 = ptrtoint ptr %mem53 to i64
  store i64 %ptr54, ptr %slot6, align 8
  %mem55 = alloca i8, i64 8, align 8
  %ptr56 = ptrtoint ptr %mem55 to i64
  store i64 %ptr56, ptr %slot7, align 8
  %mem57 = alloca i8, i64 8, align 8
  %ptr58 = ptrtoint ptr %mem57 to i64
  store i64 %ptr58, ptr %slot8, align 8
  %mem59 = alloca i8, i64 8, align 8
  %ptr60 = ptrtoint ptr %mem59 to i64
  store i64 %ptr60, ptr %slot9, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem61 = alloca i8, i64 8, align 8
  %ptr62 = ptrtoint ptr %mem61 to i64
  store i64 %ptr62, ptr %slot10, align 8
  %v63 = load i64, ptr %slot1, align 8
  %op64 = add i64 %v63, 64
  store i64 %op64, ptr %slot11, align 8
  %v65 = load i64, ptr %slot11, align 8
  %p66 = inttoptr i64 %v65 to ptr
  %ld67 = load i64, ptr %p66, align 8, !alias.scope !4, !noalias !3
  store i64 %ld67, ptr %slot12, align 8
  %stack68 = call ptr @llvm.stacksave()
  %stackaddr69 = ptrtoint ptr %stack68 to i64
  %v70 = load i64, ptr %slot12, align 8
  %cmp71 = icmp ult i64 %stackaddr69, %v70
  %cv72 = zext i1 %cmp71 to i64
  store i64 %cv72, ptr %slot13, align 8
  %v73 = load i64, ptr %slot13, align 8
  %cond74 = icmp ne i64 %v73, 0
  br i1 %cond74, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v75 = load i64, ptr %slot1, align 8
  %p76 = inttoptr i64 %v75 to ptr
  call void @myl_qbe_fail_frame(ptr %p76) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v77 = load i64, ptr %slot2, align 8
  %v78 = load i64, ptr %slot4, align 8
  %p79 = inttoptr i64 %v78 to ptr
  store i64 %v77, ptr %p79, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v80 = load i64, ptr %slot4, align 8
  %p81 = inttoptr i64 %v80 to ptr
  %ld82 = load i64, ptr %p81, align 8, !alias.scope !3, !noalias !4
  store i64 %ld82, ptr %slot14, align 8
  %v83 = load i64, ptr %slot14, align 8
  %v84 = load i64, ptr %slot6, align 8
  %p85 = inttoptr i64 %v84 to ptr
  store i64 %v83, ptr %p85, align 8, !alias.scope !3, !noalias !4
  %v86 = load i64, ptr %slot6, align 8
  %p87 = inttoptr i64 %v86 to ptr
  %ld88 = load i64, ptr %p87, align 8, !alias.scope !3, !noalias !4
  store i64 %ld88, ptr %slot15, align 8
  %v89 = load i64, ptr %slot15, align 8
  %op90 = add i64 %v89, 328
  store i64 %op90, ptr %slot16, align 8
  %v91 = load i64, ptr %slot16, align 8
  %v92 = load i64, ptr %slot6, align 8
  %p93 = inttoptr i64 %v92 to ptr
  store i64 %v91, ptr %p93, align 8, !alias.scope !3, !noalias !4
  %v94 = load i64, ptr %slot6, align 8
  %p95 = inttoptr i64 %v94 to ptr
  %ld96 = load i64, ptr %p95, align 8, !alias.scope !3, !noalias !4
  store i64 %ld96, ptr %slot17, align 8
  %v97 = load i64, ptr %slot17, align 8
  %op98 = add i64 %v97, 0
  store i64 %op98, ptr %slot18, align 8
  %v99 = load i64, ptr %slot18, align 8
  %v100 = load i64, ptr %slot6, align 8
  %p101 = inttoptr i64 %v100 to ptr
  store i64 %v99, ptr %p101, align 8, !alias.scope !3, !noalias !4
  %v102 = load i64, ptr %slot6, align 8
  %p103 = inttoptr i64 %v102 to ptr
  %ld104 = load i64, ptr %p103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld104, ptr %slot19, align 8
  %v105 = load i64, ptr %slot19, align 8
  %v106 = load i64, ptr %slot5, align 8
  %p107 = inttoptr i64 %v105 to ptr
  %p108 = inttoptr i64 %v106 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p108, ptr %p107, i64 4, i1 false), !alias.scope !10000000
  %v109 = load i64, ptr %slot4, align 8
  %p110 = inttoptr i64 %v109 to ptr
  %ld111 = load i64, ptr %p110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld111, ptr %slot20, align 8
  %v112 = load i64, ptr %slot20, align 8
  %v113 = load i64, ptr %slot6, align 8
  %p114 = inttoptr i64 %v113 to ptr
  store i64 %v112, ptr %p114, align 8, !alias.scope !3, !noalias !4
  %v115 = load i64, ptr %slot7, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 8, ptr %p116, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot6, align 8
  %p118 = inttoptr i64 %v117 to ptr
  %ld119 = load i64, ptr %p118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld119, ptr %slot21, align 8
  %v120 = load i64, ptr %slot7, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %ld122 = load i64, ptr %p121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot22, align 8
  %v123 = load i64, ptr %slot1, align 8
  %v124 = load i64, ptr %slot21, align 8
  %v125 = load i64, ptr %slot22, align 8
  %call126 = call i64 @myl_f_46a59f8862e37daa969cb4df4cc800faed429195ebd08b19eb8f05429bb98d66(i64 %v123, i64 %v124, i64 %v125) nomerge, !dbg !112
  store i64 %call126, ptr %slot23, align 8
  %v127 = load i64, ptr %slot23, align 8
  %v128 = load i64, ptr %slot6, align 8
  %p129 = inttoptr i64 %v128 to ptr
  store i64 %v127, ptr %p129, align 8, !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot5, align 8
  %v131 = load i64, ptr %slot6, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i64 %v130, ptr %p132, align 8, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot8, align 8
  store i64 %v133, ptr %slot24, align 8
  %v134 = load i64, ptr %slot24, align 8
  %p135 = inttoptr i64 %v134 to ptr
  store i32 0, ptr %p135, align 4, !alias.scope !3, !noalias !4
  %v136 = load i64, ptr %slot24, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i32 11, ptr %p137, align 4, !alias.scope !3, !noalias !4
  %v138 = load i64, ptr %slot24, align 8
  %v139 = load i64, ptr %slot7, align 8
  %p140 = inttoptr i64 %v139 to ptr
  store i64 %v138, ptr %p140, align 8, !alias.scope !3, !noalias !4
  %v141 = load i64, ptr %slot7, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %ld143 = load i64, ptr %p142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld143, ptr %slot25, align 8
  %v144 = load i64, ptr %slot6, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld146, ptr %slot26, align 8
  %v147 = load i64, ptr %slot26, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i32, ptr %p148, align 4, !alias.scope !3, !noalias !4
  %ext150 = zext i32 %ld149 to i64
  store i64 %ext150, ptr %slot27, align 8
  %v151 = load i64, ptr %slot25, align 8
  %p152 = inttoptr i64 %v151 to ptr
  %ld153 = load i32, ptr %p152, align 4, !alias.scope !3, !noalias !4
  %ext154 = zext i32 %ld153 to i64
  store i64 %ext154, ptr %slot28, align 8
  %v155 = load i64, ptr %slot27, align 8
  %v156 = load i64, ptr %slot28, align 8
  %cmp157 = icmp eq i64 %v155, %v156
  %cv158 = zext i1 %cmp157 to i64
  store i64 %cv158, ptr %slot29, align 8
  %v159 = load i64, ptr %slot29, align 8
  %v160 = load i64, ptr %slot6, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i64 %v159, ptr %p161, align 8, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot6, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld164, ptr %slot30, align 8
  %v165 = load i64, ptr %slot30, align 8
  %cond166 = icmp ne i64 %v165, 0
  br i1 %cond166, label %bb_next52, label %bb_i17
bb_next52:
  %v167 = load i64, ptr %slot4, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %ld169 = load i64, ptr %p168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld169, ptr %slot31, align 8
  %v170 = load i64, ptr %slot31, align 8
  %v171 = load i64, ptr %slot6, align 8
  %p172 = inttoptr i64 %v171 to ptr
  store i64 %v170, ptr %p172, align 8, !alias.scope !3, !noalias !4
  %v173 = load i64, ptr %slot7, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i64 22, ptr %p174, align 8, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot6, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %ld177 = load i64, ptr %p176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld177, ptr %slot32, align 8
  %v178 = load i64, ptr %slot7, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot33, align 8
  %v181 = load i64, ptr %slot1, align 8
  %v182 = load i64, ptr %slot32, align 8
  %v183 = load i64, ptr %slot33, align 8
  %call184 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v181, i64 %v182, i64 %v183) nomerge, !dbg !114
  store i64 %call184, ptr %slot34, align 8
  %v185 = load i64, ptr %slot34, align 8
  %v186 = load i64, ptr %slot6, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  br label %bb_i25
bb_i17:
  %v188 = load i64, ptr %slot5, align 8
  %v189 = load i64, ptr %slot6, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i64 %v188, ptr %p190, align 8, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot9, align 8
  store i64 %v191, ptr %slot35, align 8
  %v192 = load i64, ptr %slot35, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i32 0, ptr %p193, align 4, !alias.scope !3, !noalias !4
  %v194 = load i64, ptr %slot35, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i32 6, ptr %p195, align 4, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot35, align 8
  %v197 = load i64, ptr %slot7, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot7, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot36, align 8
  %v202 = load i64, ptr %slot6, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i64, ptr %p203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld204, ptr %slot37, align 8
  %v205 = load i64, ptr %slot37, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i32, ptr %p206, align 4, !alias.scope !3, !noalias !4
  %ext208 = zext i32 %ld207 to i64
  store i64 %ext208, ptr %slot38, align 8
  %v209 = load i64, ptr %slot36, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i32, ptr %p210, align 4, !alias.scope !3, !noalias !4
  %ext212 = zext i32 %ld211 to i64
  store i64 %ext212, ptr %slot39, align 8
  %v213 = load i64, ptr %slot38, align 8
  %v214 = load i64, ptr %slot39, align 8
  %cmp215 = icmp eq i64 %v213, %v214
  %cv216 = zext i1 %cmp215 to i64
  store i64 %cv216, ptr %slot40, align 8
  %v217 = load i64, ptr %slot40, align 8
  %v218 = load i64, ptr %slot6, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot6, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot41, align 8
  %v223 = load i64, ptr %slot41, align 8
  %cond224 = icmp ne i64 %v223, 0
  br i1 %cond224, label %bb_next72, label %bb_i25
bb_next72:
  %v225 = load i64, ptr %slot4, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot42, align 8
  %v228 = load i64, ptr %slot42, align 8
  %v229 = load i64, ptr %slot6, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 %v228, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot7, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 23, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot6, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot43, align 8
  %v236 = load i64, ptr %slot7, align 8
  %p237 = inttoptr i64 %v236 to ptr
  %ld238 = load i64, ptr %p237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld238, ptr %slot44, align 8
  %v239 = load i64, ptr %slot1, align 8
  %v240 = load i64, ptr %slot43, align 8
  %v241 = load i64, ptr %slot44, align 8
  %call242 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v239, i64 %v240, i64 %v241) nomerge, !dbg !116
  store i64 %call242, ptr %slot45, align 8
  %v243 = load i64, ptr %slot45, align 8
  %v244 = load i64, ptr %slot6, align 8
  %p245 = inttoptr i64 %v244 to ptr
  store i64 %v243, ptr %p245, align 8, !alias.scope !3, !noalias !4
  br label %bb_i25
bb_i25:
  %v246 = load i64, ptr %slot6, align 8
  %p247 = inttoptr i64 %v246 to ptr
  store i64 0, ptr %p247, align 8, !alias.scope !3, !noalias !4
  %v248 = load i64, ptr %slot6, align 8
  %p249 = inttoptr i64 %v248 to ptr
  %ld250 = load i64, ptr %p249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld250, ptr %slot46, align 8
  %v251 = load i64, ptr %slot46, align 8
  ret i64 %v251
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_46a59f8862e37daa969cb4df4cc800faed429195ebd08b19eb8f05429bb98d66(i64, i64, i64)
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_0a98a34ee8be41a1d3586e6c347d52b63f3195f98c54d38ebc44b9a263168ab2", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_0a98a34ee8be41a1d3586e6c347d52b63f3195f98c54d38ebc44b9a263168ab2", linkageName: "myl_f_0a98a34ee8be41a1d3586e6c347d52b63f3195f98c54d38ebc44b9a263168ab2", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15627862746968514197, i64 0, !"myl_f_0a98a34ee8be41a1d3586e6c347d52b63f3195f98c54d38ebc44b9a263168ab2"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!112 = !DILocation(line: 7, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!114 = !DILocation(line: 15, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!116 = !DILocation(line: 24, column: 0, scope: !117)
