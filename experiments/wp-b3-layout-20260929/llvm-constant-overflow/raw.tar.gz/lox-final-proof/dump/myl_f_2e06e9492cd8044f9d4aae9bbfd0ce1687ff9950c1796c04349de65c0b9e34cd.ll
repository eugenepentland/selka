target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v113 = load i64, ptr %slot1, align 8
  %op114 = add i64 %v113, 32
  store i64 %op114, ptr %slot4, align 8
  %mem115 = alloca i8, i64 40, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot5, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot6, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot7, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot8, align 8
  %mem123 = alloca i8, i64 8, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot9, align 8
  %mem125 = alloca i8, i64 8, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot10, align 8
  %mem127 = alloca i8, i64 40, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot11, align 8
  %mem129 = alloca i8, i64 8, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot12, align 8
  %mem131 = alloca i8, i64 40, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot13, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot14, align 8
  %mem135 = alloca i8, i64 8, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot15, align 8
  %mem137 = alloca i8, i64 8, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot16, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot17, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot18, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot19, align 8
  %mem145 = alloca i8, i64 8, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot20, align 8
  %mem147 = alloca i8, i64 8, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot21, align 8
  %mem149 = alloca i8, i64 40, align 8
  %ptr150 = ptrtoint ptr %mem149 to i64
  store i64 %ptr150, ptr %slot22, align 8
  %v151 = load i64, ptr %slot2, align 8
  %v152 = load i64, ptr %slot14, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 %v151, ptr %p153, align 8, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot3, align 8
  %v155 = load i64, ptr %slot15, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 %v154, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot1, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %call159 = call ptr @myl_qbe_heap(ptr %p158) nomerge, !dbg !110
  %calladdr160 = ptrtoint ptr %call159 to i64
  store i64 %calladdr160, ptr %slot23, align 8
  %v161 = load i64, ptr %slot1, align 8
  %p162 = inttoptr i64 %v161 to ptr
  %call163 = call i64 @myl_qbe_region_mark(ptr %p162) nomerge, !dbg !110
  store i64 %call163, ptr %slot24, align 8
  %v164 = load i64, ptr %slot6, align 8
  %p165 = inttoptr i64 %v164 to ptr
  store i32 0, ptr %p165, align 4, !alias.scope !3, !noalias !4
  %v166 = load i64, ptr %slot7, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i32 0, ptr %p167, align 4, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot8, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i32 0, ptr %p169, align 4, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot9, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i32 0, ptr %p171, align 4, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot10, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i32 0, ptr %p173, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v174 = load i64, ptr %slot21, align 8
  store i64 %v174, ptr %slot25, align 8
  %v175 = load i64, ptr %slot25, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i32 0, ptr %p176, align 4, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot25, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i32 38, ptr %p178, align 4, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot25, align 8
  %v180 = load i64, ptr %slot16, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i64 %v179, ptr %p181, align 8, !alias.scope !3, !noalias !4
  %v182 = load i64, ptr %slot14, align 8
  %p183 = inttoptr i64 %v182 to ptr
  %ld184 = load i64, ptr %p183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld184, ptr %slot26, align 8
  %v185 = load i64, ptr %slot26, align 8
  %v186 = load i64, ptr %slot17, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot17, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld190, ptr %slot27, align 8
  %v191 = load i64, ptr %slot27, align 8
  %op192 = add i64 %v191, 8
  store i64 %op192, ptr %slot28, align 8
  %v193 = load i64, ptr %slot28, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8
  store i64 %ld195, ptr %slot29, align 8
  %v196 = load i64, ptr %slot29, align 8
  %v197 = load i64, ptr %slot17, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot18, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 0, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot14, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i64, ptr %p202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld203, ptr %slot30, align 8
  %v204 = load i64, ptr %slot30, align 8
  %v205 = load i64, ptr %slot19, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i64 %v204, ptr %p206, align 8, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot19, align 8
  %p208 = inttoptr i64 %v207 to ptr
  %ld209 = load i64, ptr %p208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld209, ptr %slot31, align 8
  %v210 = load i64, ptr %slot31, align 8
  %op211 = add i64 %v210, 24
  store i64 %op211, ptr %slot32, align 8
  %v212 = load i64, ptr %slot32, align 8
  %p213 = inttoptr i64 %v212 to ptr
  %ld214 = load i64, ptr %p213, align 8
  store i64 %ld214, ptr %slot33, align 8
  %v215 = load i64, ptr %slot33, align 8
  %v216 = load i64, ptr %slot19, align 8
  %p217 = inttoptr i64 %v216 to ptr
  store i64 %v215, ptr %p217, align 8, !alias.scope !3, !noalias !4
  %v218 = load i64, ptr %slot15, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %ld220 = load i64, ptr %p219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld220, ptr %slot34, align 8
  %v221 = load i64, ptr %slot34, align 8
  %v222 = load i64, ptr %slot20, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i64 %v221, ptr %p223, align 8, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot22, align 8
  store i64 %v224, ptr %slot35, align 8
  %v225 = load i64, ptr %slot35, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 0, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot35, align 8
  %p229 = inttoptr i64 %v227 to ptr
  %gep230 = getelementptr i8, ptr %p229, i64 8
  %op228 = ptrtoint ptr %gep230 to i64
  store i64 %op228, ptr %slot36, align 8
  %v231 = load i64, ptr %slot36, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 0, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot35, align 8
  %p235 = inttoptr i64 %v233 to ptr
  %gep236 = getelementptr i8, ptr %p235, i64 16
  %op234 = ptrtoint ptr %gep236 to i64
  store i64 %op234, ptr %slot37, align 8
  %v237 = load i64, ptr %slot37, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 0, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot35, align 8
  %p241 = inttoptr i64 %v239 to ptr
  %gep242 = getelementptr i8, ptr %p241, i64 24
  %op240 = ptrtoint ptr %gep242 to i64
  store i64 %op240, ptr %slot38, align 8
  %v243 = load i64, ptr %slot38, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i64 0, ptr %p244, align 8, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot35, align 8
  %p247 = inttoptr i64 %v245 to ptr
  %gep248 = getelementptr i8, ptr %p247, i64 32
  %op246 = ptrtoint ptr %gep248 to i64
  store i64 %op246, ptr %slot39, align 8
  %v249 = load i64, ptr %slot39, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 0, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot10, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i32 1, ptr %p252, align 4, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot24, align 8
  store i64 %v253, ptr %slot40, align 8
  %v254 = load i64, ptr %slot16, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %ld256 = load i64, ptr %p255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld256, ptr %slot41, align 8
  %v257 = load i64, ptr %slot35, align 8
  %p259 = inttoptr i64 %v257 to ptr
  %gep260 = getelementptr i8, ptr %p259, i64 0
  %op258 = ptrtoint ptr %gep260 to i64
  store i64 %op258, ptr %slot42, align 8
  %v261 = load i64, ptr %slot41, align 8
  %v262 = load i64, ptr %slot42, align 8
  %p263 = inttoptr i64 %v261 to ptr
  %p264 = inttoptr i64 %v262 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p264, ptr %p263, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot17, align 8
  store i64 %v265, ptr %slot43, align 8
  %v266 = load i64, ptr %slot35, align 8
  %p268 = inttoptr i64 %v266 to ptr
  %gep269 = getelementptr i8, ptr %p268, i64 8
  %op267 = ptrtoint ptr %gep269 to i64
  store i64 %op267, ptr %slot44, align 8
  %v270 = load i64, ptr %slot43, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot45, align 8
  %v273 = load i64, ptr %slot45, align 8
  %v274 = load i64, ptr %slot44, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i64 %v273, ptr %p275, align 8, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot18, align 8
  store i64 %v276, ptr %slot46, align 8
  %v277 = load i64, ptr %slot35, align 8
  %p279 = inttoptr i64 %v277 to ptr
  %gep280 = getelementptr i8, ptr %p279, i64 16
  %op278 = ptrtoint ptr %gep280 to i64
  store i64 %op278, ptr %slot47, align 8
  %v281 = load i64, ptr %slot46, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld283, ptr %slot48, align 8
  %v284 = load i64, ptr %slot48, align 8
  %v285 = load i64, ptr %slot47, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i64 %v284, ptr %p286, align 8, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot19, align 8
  store i64 %v287, ptr %slot49, align 8
  %v288 = load i64, ptr %slot35, align 8
  %p290 = inttoptr i64 %v288 to ptr
  %gep291 = getelementptr i8, ptr %p290, i64 24
  %op289 = ptrtoint ptr %gep291 to i64
  store i64 %op289, ptr %slot50, align 8
  %v292 = load i64, ptr %slot49, align 8
  %p293 = inttoptr i64 %v292 to ptr
  %ld294 = load i64, ptr %p293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld294, ptr %slot51, align 8
  %v295 = load i64, ptr %slot51, align 8
  %v296 = load i64, ptr %slot50, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i64 %v295, ptr %p297, align 8, !alias.scope !3, !noalias !4
  %v298 = load i64, ptr %slot20, align 8
  %p299 = inttoptr i64 %v298 to ptr
  %ld300 = load i64, ptr %p299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld300, ptr %slot52, align 8
  %v301 = load i64, ptr %slot52, align 8
  %v302 = load i64, ptr %slot12, align 8
  %p303 = inttoptr i64 %v302 to ptr
  store i64 %v301, ptr %p303, align 8, !alias.scope !3, !noalias !4
  %v304 = load i64, ptr %slot12, align 8
  store i64 %v304, ptr %slot53, align 8
  %v305 = load i64, ptr %slot35, align 8
  %p307 = inttoptr i64 %v305 to ptr
  %gep308 = getelementptr i8, ptr %p307, i64 32
  %op306 = ptrtoint ptr %gep308 to i64
  store i64 %op306, ptr %slot54, align 8
  %v309 = load i64, ptr %slot20, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %ld311 = load i64, ptr %p310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld311, ptr %slot55, align 8
  %v312 = load i64, ptr %slot55, align 8
  %v313 = load i64, ptr %slot12, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot12, align 8
  store i64 %v315, ptr %slot56, align 8
  store i32 0, ptr %slot57, align 8
  %v316 = load i64, ptr %slot8, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %ld318 = load i32, ptr %p317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld318, ptr %slot58, align 8
  %v319 = load i32, ptr %slot58, align 8
  %op320 = and i32 %v319, 24
  store i32 %op320, ptr %slot58, align 8
  %v321 = load i32, ptr %slot58, align 8
  %cmp322 = icmp eq i32 %v321, 0
  %cv323 = zext i1 %cmp322 to i32
  store i32 %cv323, ptr %slot59, align 8
  %v324 = load i32, ptr %slot57, align 8
  %v325 = load i32, ptr %slot59, align 8
  %op326 = and i32 %v324, %v325
  store i32 %op326, ptr %slot60, align 8
  %v327 = load i32, ptr %slot60, align 8
  %cv328 = zext i32 %v327 to i64
  %cond329 = icmp ne i64 %cv328, 0
  br i1 %cond329, label %bb_rctake54, label %bb_rccopy54
bb_rctake54:
  %v330 = load i64, ptr %slot13, align 8
  store i64 %v330, ptr %slot61, align 8
  %v331 = load i64, ptr %slot24, align 8
  store i64 %v331, ptr %slot62, align 8
  %v332 = load i64, ptr %slot56, align 8
  %v333 = load i64, ptr %slot61, align 8
  %op334 = sub i64 %v332, %v333
  store i64 %op334, ptr %slot63, align 8
  %v335 = load i64, ptr %slot61, align 8
  %v336 = load i64, ptr %slot56, align 8
  %op337 = sub i64 %v335, %v336
  store i64 %op337, ptr %slot64, align 8
  %v338 = load i64, ptr %slot63, align 8
  %cmp339 = icmp ult i64 %v338, 8
  %cv340 = zext i1 %cmp339 to i32
  store i32 %cv340, ptr %slot65, align 8
  %v341 = load i64, ptr %slot64, align 8
  %cmp342 = icmp ult i64 %v341, 8
  %cv343 = zext i1 %cmp342 to i32
  store i32 %cv343, ptr %slot66, align 8
  %v344 = load i32, ptr %slot65, align 8
  %v345 = load i32, ptr %slot66, align 8
  %op346 = or i32 %v344, %v345
  store i32 %op346, ptr %slot67, align 8
  %v347 = load i32, ptr %slot67, align 8
  %cv348 = zext i32 %v347 to i64
  %cond349 = icmp ne i64 %cv348, 0
  br i1 %cond349, label %bb_rcmoveslow63, label %bb_rcmovecheck63
bb_rcmovecheck63:
  %v350 = load i64, ptr %slot56, align 8
  %p352 = inttoptr i64 %v350 to ptr
  %gep353 = getelementptr i8, ptr %p352, i64 0
  %op351 = ptrtoint ptr %gep353 to i64
  store i64 %op351, ptr %slot68, align 8
  %v354 = load i64, ptr %slot68, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %ld356 = load i64, ptr %p355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld356, ptr %slot69, align 8
  %v357 = load i64, ptr %slot69, align 8
  %cmp358 = icmp ne i64 %v357, 0
  %cv359 = zext i1 %cmp358 to i32
  store i32 %cv359, ptr %slot70, align 8
  %v360 = load i32, ptr %slot70, align 8
  %cv361 = zext i32 %v360 to i64
  %cond362 = icmp ne i64 %cv361, 0
  br i1 %cond362, label %bb_rcmoveheader71, label %bb_rcmovenext71
bb_rcmoveheader71:
  %v363 = load i64, ptr %slot69, align 8
  %op364 = sub i64 %v363, 16
  store i64 %op364, ptr %slot71, align 8
  %v365 = load i64, ptr %slot69, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %rgep367 = getelementptr i8, ptr %p366, i64 -16
  %ld368 = load i64, ptr %rgep367, align 8, !alias.scope !9, !noalias !10
  store i64 %ld368, ptr %slot72, align 8
  %v369 = load i64, ptr %slot72, align 8
  %op370 = and i64 %v369, 5764607523034234881
  store i64 %op370, ptr %slot73, align 8
  %v371 = load i64, ptr %slot73, align 8
  %cmp372 = icmp ne i64 %v371, 0
  %cv373 = zext i1 %cmp372 to i32
  store i32 %cv373, ptr %slot74, align 8
  %v374 = load i32, ptr %slot74, align 8
  %cv375 = zext i32 %v374 to i64
  %cond376 = icmp ne i64 %cv375, 0
  br i1 %cond376, label %bb_rcmoveslow63, label %bb_rcmovenext71
bb_rcmovenext71:
  %v377 = load i64, ptr %slot56, align 8
  %v378 = load i64, ptr %slot61, align 8
  %p379 = inttoptr i64 %v377 to ptr
  %p380 = inttoptr i64 %v378 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p380, ptr %p379, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v381 = load i64, ptr %slot56, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 0, ptr %p382, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved63
bb_rcmoveslow63:
  %v383 = load i64, ptr %slot23, align 8
  %v384 = load i64, ptr %slot61, align 8
  %v385 = load i64, ptr %slot56, align 8
  %v386 = load i64, ptr %slot62, align 8
  %cv387 = trunc i64 %v386 to i32
  %call388 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v383, i64 %v384, i64 %v385, i32 %cv387) nomerge, !dbg !112
  store i32 %call388, ptr %slot75, align 8
  %v389 = load i32, ptr %slot75, align 8
  %cv390 = zext i32 %v389 to i64
  %cond391 = icmp ne i64 %cv390, 0
  br i1 %cond391, label %bb_rcsuccess78, label %bb_rcfailure78
bb_rcfailure78:
  %v392 = load i64, ptr %slot23, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %call394 = call i32 @myl_rc_take_failure(ptr %p393) nomerge, !dbg !112
  store i32 %call394, ptr %slot76, align 8
  %v395 = load i64, ptr %slot1, align 8
  %p396 = inttoptr i64 %v395 to ptr
  %v397 = load i32, ptr %slot76, align 8
  %call398 = call i32 @myl_qbe_rc_status(ptr %p396, i32 %v397) nomerge, !dbg !112
  store i32 %call398, ptr %slot77, align 8
  br label %bb_failure
bb_rcsuccess78:
  br label %bb_rcmoved63
bb_rcmoved63:
  %v399 = load i64, ptr %slot9, align 8
  %p400 = inttoptr i64 %v399 to ptr
  store i32 1, ptr %p400, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared54
bb_rccopy54:
  %v401 = load i64, ptr %slot13, align 8
  store i64 %v401, ptr %slot78, align 8
  %v402 = load i64, ptr %slot24, align 8
  store i64 %v402, ptr %slot79, align 8
  %v403 = load i64, ptr %slot56, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ld405 = load i64, ptr %p404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld405, ptr %slot80, align 8
  %v406 = load i64, ptr %slot80, align 8
  %cmp407 = icmp ne i64 %v406, 0
  %cv408 = zext i1 %cmp407 to i32
  store i32 %cv408, ptr %slot81, align 8
  %v409 = load i32, ptr %slot81, align 8
  %cv410 = zext i32 %v409 to i64
  %cond411 = icmp ne i64 %cv410, 0
  br i1 %cond411, label %bb_rcgnn87, label %bb_rcgplain87
bb_rcgnn87:
  %v412 = load i64, ptr %slot80, align 8
  %op413 = sub i64 %v412, 16
  store i64 %op413, ptr %slot82, align 8
  %v414 = load i64, ptr %slot80, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %rgep416 = getelementptr i8, ptr %p415, i64 -16
  %ld417 = load i64, ptr %rgep416, align 8, !alias.scope !9, !noalias !10
  store i64 %ld417, ptr %slot83, align 8
  %v418 = load i64, ptr %slot83, align 8
  %op419 = and i64 %v418, 4611686018427387906
  store i64 %op419, ptr %slot84, align 8
  %v420 = load i64, ptr %slot84, align 8
  %cmp421 = icmp ne i64 %v420, 0
  %cv422 = zext i1 %cmp421 to i32
  store i32 %cv422, ptr %slot85, align 8
  %v423 = load i32, ptr %slot85, align 8
  %cv424 = zext i32 %v423 to i64
  %cond425 = icmp ne i64 %cv424, 0
  br i1 %cond425, label %bb_rcgspecial87, label %bb_rcginc87
bb_rcginc87:
  %v426 = load i64, ptr %slot80, align 8
  %op427 = sub i64 %v426, 32
  store i64 %op427, ptr %slot86, align 8
  %v428 = load i64, ptr %slot80, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %rgep430 = getelementptr i8, ptr %p429, i64 -32
  %ld431 = load i64, ptr %rgep430, align 8, !alias.scope !9, !noalias !10
  store i64 %ld431, ptr %slot87, align 8
  %v432 = load i64, ptr %slot87, align 8
  %op433 = add i64 %v432, 1
  store i64 %op433, ptr %slot88, align 8
  %v434 = load i64, ptr %slot88, align 8
  %cmp435 = icmp eq i64 %v434, 0
  %cv436 = zext i1 %cmp435 to i32
  store i32 %cv436, ptr %slot89, align 8
  %v437 = load i32, ptr %slot89, align 8
  %cv438 = zext i32 %v437 to i64
  %cond439 = icmp ne i64 %cv438, 0
  br i1 %cond439, label %bb_rcglimit87, label %bb_rcgcapacity87
bb_rcglimit87:
  %v440 = load i64, ptr %slot1, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %call442 = call i32 @myl_qbe_rc_status(ptr %p441, i32 2) nomerge, !dbg !112
  store i32 %call442, ptr %slot90, align 8
  br label %bb_failure
bb_rcgcapacity87:
  %v443 = load i64, ptr %slot88, align 8
  %v444 = load i64, ptr %slot80, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %rgep446 = getelementptr i8, ptr %p445, i64 -32
  store i64 %v443, ptr %rgep446, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain87
bb_rcgspecial87:
  %v447 = load i64, ptr %slot83, align 8
  %op448 = and i64 %v447, 4611686018427387904
  store i64 %op448, ptr %slot91, align 8
  %v449 = load i64, ptr %slot91, align 8
  %cmp450 = icmp ne i64 %v449, 0
  %cv451 = zext i1 %cmp450 to i32
  store i32 %cv451, ptr %slot92, align 8
  %v452 = load i32, ptr %slot92, align 8
  %cv453 = zext i32 %v452 to i64
  %cond454 = icmp ne i64 %cv453, 0
  br i1 %cond454, label %bb_rcgslow87, label %bb_rcgplain87
bb_rcgslow87:
  %v455 = load i64, ptr %slot23, align 8
  %v456 = load i64, ptr %slot78, align 8
  %v457 = load i64, ptr %slot56, align 8
  %v458 = load i64, ptr %slot79, align 8
  %cv459 = trunc i64 %v458 to i32
  %call460 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v455, i64 %v456, i64 %v457, i32 %cv459) nomerge, !dbg !112
  store i32 %call460, ptr %slot93, align 8
  %v461 = load i32, ptr %slot93, align 8
  %cv462 = zext i32 %v461 to i64
  %cond463 = icmp ne i64 %cv462, 0
  br i1 %cond463, label %bb_rcsuccess101, label %bb_rcfailure101
bb_rcfailure101:
  %v464 = load i64, ptr %slot23, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %call466 = call i32 @myl_rc_take_failure(ptr %p465) nomerge, !dbg !112
  store i32 %call466, ptr %slot94, align 8
  %v467 = load i64, ptr %slot1, align 8
  %p468 = inttoptr i64 %v467 to ptr
  %v469 = load i32, ptr %slot94, align 8
  %call470 = call i32 @myl_qbe_rc_status(ptr %p468, i32 %v469) nomerge, !dbg !112
  store i32 %call470, ptr %slot95, align 8
  br label %bb_failure
bb_rcsuccess101:
  br label %bb_rcgdone87
bb_rcgplain87:
  %v471 = load i64, ptr %slot80, align 8
  %v472 = load i64, ptr %slot78, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i64 %v471, ptr %p473, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone87
bb_rcgdone87:
  %v474 = load i64, ptr %slot9, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i32 1, ptr %p475, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared54
bb_rcprepared54:
  %v476 = load i64, ptr %slot13, align 8
  store i64 %v476, ptr %slot96, align 8
  %v477 = load i64, ptr %slot96, align 8
  %v478 = load i64, ptr %slot54, align 8
  %p479 = inttoptr i64 %v477 to ptr
  %p480 = inttoptr i64 %v478 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p480, ptr %p479, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v481 = load i64, ptr %slot9, align 8
  %p482 = inttoptr i64 %v481 to ptr
  store i32 0, ptr %p482, align 4, !alias.scope !3, !noalias !4
  %v483 = load i64, ptr %slot35, align 8
  %v484 = load i64, ptr %slot16, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i64 %v483, ptr %p485, align 8, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot16, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %ld488 = load i64, ptr %p487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld488, ptr %slot97, align 8
  %v489 = load i64, ptr %slot11, align 8
  store i64 %v489, ptr %slot98, align 8
  %v490 = load i64, ptr %slot97, align 8
  %v491 = load i64, ptr %slot98, align 8
  %p492 = inttoptr i64 %v490 to ptr
  %p493 = inttoptr i64 %v491 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p493, ptr %p492, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v494 = load i64, ptr %slot7, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i32 2, ptr %p495, align 4, !alias.scope !3, !noalias !4
  %v496 = load i64, ptr %slot6, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i32 1, ptr %p497, align 4, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot98, align 8
  %v499 = load i64, ptr %slot16, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i64 %v498, ptr %p500, align 8, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot16, align 8
  %p502 = inttoptr i64 %v501 to ptr
  %ld503 = load i64, ptr %p502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld503, ptr %slot99, align 8
  %v504 = load i64, ptr %slot16, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i64, ptr %p505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld506, ptr %slot100, align 8
  %v507 = load i64, ptr %slot13, align 8
  store i64 %v507, ptr %slot101, align 8
  %v508 = load i64, ptr %slot24, align 8
  store i64 %v508, ptr %slot102, align 8
  %v509 = load i64, ptr %slot23, align 8
  %v510 = load i64, ptr %slot101, align 8
  %v511 = load i64, ptr %slot100, align 8
  %v512 = load i64, ptr %slot102, align 8
  %cv513 = trunc i64 %v512 to i32
  %call514 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v509, i64 %v510, i64 %v511, i32 %cv513) nomerge, !dbg !114
  store i32 %call514, ptr %slot103, align 8
  %v515 = load i32, ptr %slot103, align 8
  %cv516 = zext i32 %v515 to i64
  %cond517 = icmp ne i64 %cv516, 0
  br i1 %cond517, label %bb_rcsuccess154, label %bb_rcfailure154
bb_rcfailure154:
  %v518 = load i64, ptr %slot23, align 8
  %p519 = inttoptr i64 %v518 to ptr
  %call520 = call i32 @myl_rc_take_failure(ptr %p519) nomerge, !dbg !114
  store i32 %call520, ptr %slot104, align 8
  %v521 = load i64, ptr %slot1, align 8
  %p522 = inttoptr i64 %v521 to ptr
  %v523 = load i32, ptr %slot104, align 8
  %call524 = call i32 @myl_qbe_rc_status(ptr %p522, i32 %v523) nomerge, !dbg !114
  store i32 %call524, ptr %slot105, align 8
  br label %bb_failure
bb_rcsuccess154:
  %v525 = load i64, ptr %slot6, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 0, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %v527 = load i64, ptr %slot9, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i32 1, ptr %p528, align 4, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot13, align 8
  store i64 %v529, ptr %slot106, align 8
  %v530 = load i64, ptr %slot9, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i32 0, ptr %p531, align 4, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot6, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %ld534 = load i32, ptr %p533, align 4, !alias.scope !3, !noalias !4
  store i32 %ld534, ptr %slot107, align 8
  %v535 = load i32, ptr %slot107, align 8
  %cv536 = zext i32 %v535 to i64
  %cond537 = icmp ne i64 %cv536, 0
  br i1 %cond537, label %bb_rcslotdrop164, label %bb_rcslotdone164
bb_rcslotdrop164:
  %v538 = load i64, ptr %slot6, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i32 0, ptr %p539, align 4, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot11, align 8
  store i64 %v540, ptr %slot108, align 8
  %v541 = load i64, ptr %slot7, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i32, ptr %p542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld543, ptr %slot109, align 8
  %v544 = load i32, ptr %slot109, align 8
  %op545 = and i32 %v544, 28
  store i32 %op545, ptr %slot110, align 8
  %v546 = load i32, ptr %slot110, align 8
  %cv547 = zext i32 %v546 to i64
  %cond548 = icmp ne i64 %cv547, 0
  br i1 %cond548, label %bb_rcslotrole164, label %bb_rcslotowner164
bb_rcslotrole164:
  %v549 = load i64, ptr %slot23, align 8
  store i64 %v549, ptr %slot111, align 8
  %v550 = load i64, ptr %slot111, align 8
  %v551 = load i64, ptr %slot108, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v550, i64 %v551) nomerge, !dbg !114
  br label %bb_rcslotdone164
bb_rcslotowner164:
  %v552 = load i64, ptr %slot23, align 8
  store i64 %v552, ptr %slot112, align 8
  %v553 = load i64, ptr %slot112, align 8
  %v554 = load i64, ptr %slot108, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v553, i64 %v554) nomerge, !dbg !114
  br label %bb_rcslotdone164
bb_rcslotdone164:
  %v555 = load i64, ptr %slot106, align 8
  %p556 = inttoptr i64 %v555 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p556, i64 40, i1 false)
  ret void
bb_failure:
  %v557 = load i64, ptr %slot5, align 8
  %p558 = inttoptr i64 %v557 to ptr
  call void @llvm.memset.p0.i64(ptr %p558, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v559 = load i64, ptr %slot5, align 8
  %p560 = inttoptr i64 %v559 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p560, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v561 = load i64, ptr %slot5, align 8
  %p562 = inttoptr i64 %v561 to ptr
  call void @llvm.memset.p0.i64(ptr %p562, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v563 = load i64, ptr %slot5, align 8
  %p564 = inttoptr i64 %v563 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p564, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd", linkageName: "myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4438313779276868166, i64 0, !"myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!112 = !DILocation(line: 8, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!114 = !DILocation(line: 9, column: 0, scope: !115)
