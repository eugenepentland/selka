target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_cdbae2c9e3e74db1cd59bea9ebdf56dd892e43044fee2029b41340b26817caba(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v669 = load i64, ptr %slot1, align 8
  %op670 = add i64 %v669, 32
  store i64 %op670, ptr %slot4, align 8
  %mem671 = alloca i8, i64 8, align 8
  %ptr672 = ptrtoint ptr %mem671 to i64
  store i64 %ptr672, ptr %slot5, align 8
  %mem673 = alloca i8, i64 8, align 8
  %ptr674 = ptrtoint ptr %mem673 to i64
  store i64 %ptr674, ptr %slot6, align 8
  %mem675 = alloca i8, i64 8, align 8
  %ptr676 = ptrtoint ptr %mem675 to i64
  store i64 %ptr676, ptr %slot7, align 8
  %mem677 = alloca i8, i64 8, align 8
  %ptr678 = ptrtoint ptr %mem677 to i64
  store i64 %ptr678, ptr %slot8, align 8
  %mem679 = alloca i8, i64 8, align 8
  %ptr680 = ptrtoint ptr %mem679 to i64
  store i64 %ptr680, ptr %slot9, align 8
  %mem681 = alloca i8, i64 8, align 8
  %ptr682 = ptrtoint ptr %mem681 to i64
  store i64 %ptr682, ptr %slot10, align 8
  %mem683 = alloca i8, i64 8, align 8
  %ptr684 = ptrtoint ptr %mem683 to i64
  store i64 %ptr684, ptr %slot11, align 8
  %mem685 = alloca i8, i64 8, align 8
  %ptr686 = ptrtoint ptr %mem685 to i64
  store i64 %ptr686, ptr %slot12, align 8
  %mem687 = alloca i8, i64 8, align 8
  %ptr688 = ptrtoint ptr %mem687 to i64
  store i64 %ptr688, ptr %slot13, align 8
  %mem689 = alloca i8, i64 8, align 8
  %ptr690 = ptrtoint ptr %mem689 to i64
  store i64 %ptr690, ptr %slot14, align 8
  %mem691 = alloca i8, i64 8, align 8
  %ptr692 = ptrtoint ptr %mem691 to i64
  store i64 %ptr692, ptr %slot15, align 8
  %mem693 = alloca i8, i64 8, align 8
  %ptr694 = ptrtoint ptr %mem693 to i64
  store i64 %ptr694, ptr %slot16, align 8
  %mem695 = alloca i8, i64 112, align 8
  %ptr696 = ptrtoint ptr %mem695 to i64
  store i64 %ptr696, ptr %slot17, align 8
  %mem697 = alloca i8, i64 8, align 8
  %ptr698 = ptrtoint ptr %mem697 to i64
  store i64 %ptr698, ptr %slot18, align 8
  %mem699 = alloca i8, i64 8, align 8
  %ptr700 = ptrtoint ptr %mem699 to i64
  store i64 %ptr700, ptr %slot19, align 8
  %mem701 = alloca i8, i64 8, align 8
  %ptr702 = ptrtoint ptr %mem701 to i64
  store i64 %ptr702, ptr %slot20, align 8
  %mem703 = alloca i8, i64 112, align 8
  %ptr704 = ptrtoint ptr %mem703 to i64
  store i64 %ptr704, ptr %slot21, align 8
  %mem705 = alloca i8, i64 8, align 8
  %ptr706 = ptrtoint ptr %mem705 to i64
  store i64 %ptr706, ptr %slot22, align 8
  %mem707 = alloca i8, i64 8, align 8
  %ptr708 = ptrtoint ptr %mem707 to i64
  store i64 %ptr708, ptr %slot23, align 8
  %mem709 = alloca i8, i64 8, align 8
  %ptr710 = ptrtoint ptr %mem709 to i64
  store i64 %ptr710, ptr %slot24, align 8
  %mem711 = alloca i8, i64 8, align 8
  %ptr712 = ptrtoint ptr %mem711 to i64
  store i64 %ptr712, ptr %slot25, align 8
  %mem713 = alloca i8, i64 64, align 8
  %ptr714 = ptrtoint ptr %mem713 to i64
  store i64 %ptr714, ptr %slot26, align 8
  %mem715 = alloca i8, i64 8, align 8
  %ptr716 = ptrtoint ptr %mem715 to i64
  store i64 %ptr716, ptr %slot27, align 8
  %mem717 = alloca i8, i64 8, align 8
  %ptr718 = ptrtoint ptr %mem717 to i64
  store i64 %ptr718, ptr %slot28, align 8
  %mem719 = alloca i8, i64 8, align 8
  %ptr720 = ptrtoint ptr %mem719 to i64
  store i64 %ptr720, ptr %slot29, align 8
  %mem721 = alloca i8, i64 8, align 8
  %ptr722 = ptrtoint ptr %mem721 to i64
  store i64 %ptr722, ptr %slot30, align 8
  %mem723 = alloca i8, i64 8, align 8
  %ptr724 = ptrtoint ptr %mem723 to i64
  store i64 %ptr724, ptr %slot31, align 8
  %mem725 = alloca i8, i64 8, align 8
  %ptr726 = ptrtoint ptr %mem725 to i64
  store i64 %ptr726, ptr %slot32, align 8
  %mem727 = alloca i8, i64 8, align 8
  %ptr728 = ptrtoint ptr %mem727 to i64
  store i64 %ptr728, ptr %slot33, align 8
  %mem729 = alloca i8, i64 8, align 8
  %ptr730 = ptrtoint ptr %mem729 to i64
  store i64 %ptr730, ptr %slot34, align 8
  %mem731 = alloca i8, i64 8, align 8
  %ptr732 = ptrtoint ptr %mem731 to i64
  store i64 %ptr732, ptr %slot35, align 8
  %mem733 = alloca i8, i64 8, align 8
  %ptr734 = ptrtoint ptr %mem733 to i64
  store i64 %ptr734, ptr %slot36, align 8
  %mem735 = alloca i8, i64 8, align 8
  %ptr736 = ptrtoint ptr %mem735 to i64
  store i64 %ptr736, ptr %slot37, align 8
  %mem737 = alloca i8, i64 8, align 8
  %ptr738 = ptrtoint ptr %mem737 to i64
  store i64 %ptr738, ptr %slot38, align 8
  %mem739 = alloca i8, i64 8, align 8
  %ptr740 = ptrtoint ptr %mem739 to i64
  store i64 %ptr740, ptr %slot39, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem741 = alloca i8, i64 8, align 8
  %ptr742 = ptrtoint ptr %mem741 to i64
  store i64 %ptr742, ptr %slot40, align 8
  %v743 = load i64, ptr %slot1, align 8
  %op744 = add i64 %v743, 64
  store i64 %op744, ptr %slot41, align 8
  %v745 = load i64, ptr %slot41, align 8
  %p746 = inttoptr i64 %v745 to ptr
  %ld747 = load i64, ptr %p746, align 8, !alias.scope !4, !noalias !3
  store i64 %ld747, ptr %slot42, align 8
  %stack748 = call ptr @llvm.stacksave()
  %stackaddr749 = ptrtoint ptr %stack748 to i64
  %v750 = load i64, ptr %slot42, align 8
  %cmp751 = icmp ult i64 %stackaddr749, %v750
  %cv752 = zext i1 %cmp751 to i64
  store i64 %cv752, ptr %slot43, align 8
  %v753 = load i64, ptr %slot43, align 8
  %cond754 = icmp ne i64 %v753, 0
  br i1 %cond754, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v755 = load i64, ptr %slot1, align 8
  %p756 = inttoptr i64 %v755 to ptr
  call void @myl_qbe_fail_frame(ptr %p756) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %mem757 = alloca i8, i64 8, align 8
  %ptr758 = ptrtoint ptr %mem757 to i64
  store i64 %ptr758, ptr %slot44, align 8
  %v759 = load i64, ptr %slot24, align 8
  %p760 = inttoptr i64 %v759 to ptr
  store i64 0, ptr %p760, align 8, !alias.scope !3, !noalias !4
  %v761 = load i64, ptr %slot27, align 8
  %p762 = inttoptr i64 %v761 to ptr
  store i64 0, ptr %p762, align 8, !alias.scope !3, !noalias !4
  %v763 = load i64, ptr %slot28, align 8
  %p764 = inttoptr i64 %v763 to ptr
  store i64 0, ptr %p764, align 8, !alias.scope !3, !noalias !4
  %v765 = load i64, ptr %slot29, align 8
  %p766 = inttoptr i64 %v765 to ptr
  store i64 0, ptr %p766, align 8, !alias.scope !3, !noalias !4
  %v767 = load i64, ptr %slot33, align 8
  %p768 = inttoptr i64 %v767 to ptr
  store i64 0, ptr %p768, align 8, !alias.scope !3, !noalias !4
  %v769 = load i64, ptr %slot2, align 8
  %v770 = load i64, ptr %slot22, align 8
  %p771 = inttoptr i64 %v770 to ptr
  store i64 %v769, ptr %p771, align 8, !alias.scope !3, !noalias !4
  %v772 = load i64, ptr %slot3, align 8
  %v773 = load i64, ptr %slot23, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i64 %v772, ptr %p774, align 8, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot1, align 8
  %p776 = inttoptr i64 %v775 to ptr
  %call777 = call ptr @myl_qbe_heap(ptr %p776) nomerge, !dbg !112
  %calladdr778 = ptrtoint ptr %call777 to i64
  store i64 %calladdr778, ptr %slot45, align 8
  %v779 = load i64, ptr %slot1, align 8
  %p780 = inttoptr i64 %v779 to ptr
  %call781 = call i64 @myl_qbe_region_mark(ptr %p780) nomerge, !dbg !112
  store i64 %call781, ptr %slot46, align 8
  %v782 = load i64, ptr %slot5, align 8
  %p783 = inttoptr i64 %v782 to ptr
  store i32 0, ptr %p783, align 4, !alias.scope !3, !noalias !4
  %v784 = load i64, ptr %slot6, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i32 0, ptr %p785, align 4, !alias.scope !3, !noalias !4
  %v786 = load i64, ptr %slot7, align 8
  %p787 = inttoptr i64 %v786 to ptr
  store i32 0, ptr %p787, align 4, !alias.scope !3, !noalias !4
  %v788 = load i64, ptr %slot8, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i32 0, ptr %p789, align 4, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot9, align 8
  %p791 = inttoptr i64 %v790 to ptr
  store i32 0, ptr %p791, align 4, !alias.scope !3, !noalias !4
  %v792 = load i64, ptr %slot10, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i32 0, ptr %p793, align 4, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot11, align 8
  %p795 = inttoptr i64 %v794 to ptr
  store i32 0, ptr %p795, align 4, !alias.scope !3, !noalias !4
  %v796 = load i64, ptr %slot12, align 8
  %p797 = inttoptr i64 %v796 to ptr
  store i32 0, ptr %p797, align 4, !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot13, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i32 0, ptr %p799, align 4, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot14, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i32 0, ptr %p801, align 4, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot15, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i32 0, ptr %p803, align 4, !alias.scope !3, !noalias !4
  %v804 = load i64, ptr %slot16, align 8
  %p805 = inttoptr i64 %v804 to ptr
  store i32 0, ptr %p805, align 4, !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot6, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i32 2, ptr %p807, align 4, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot8, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i32 2, ptr %p809, align 4, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot10, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i32 2, ptr %p811, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v812 = load i64, ptr %slot22, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i64, ptr %p813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld814, ptr %slot47, align 8
  %v815 = load i64, ptr %slot47, align 8
  %v816 = load i64, ptr %slot35, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot35, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot48, align 8
  %v821 = load i64, ptr %slot48, align 8
  %op822 = add i64 %v821, 0
  store i64 %op822, ptr %slot49, align 8
  %v823 = load i64, ptr %slot49, align 8
  %v824 = load i64, ptr %slot35, align 8
  %p825 = inttoptr i64 %v824 to ptr
  store i64 %v823, ptr %p825, align 8, !alias.scope !3, !noalias !4
  %v826 = load i64, ptr %slot11, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ld828 = load i32, ptr %p827, align 4, !alias.scope !3, !noalias !4
  store i32 %ld828, ptr %slot50, align 8
  %v829 = load i32, ptr %slot50, align 8
  %cv830 = zext i32 %v829 to i64
  %cond831 = icmp ne i64 %cv830, 0
  br i1 %cond831, label %bb_rcslotdrop20, label %bb_rcslotdone20
bb_rcslotdrop20:
  %v832 = load i64, ptr %slot11, align 8
  %p833 = inttoptr i64 %v832 to ptr
  store i32 0, ptr %p833, align 4, !alias.scope !3, !noalias !4
  %v834 = load i64, ptr %slot17, align 8
  store i64 %v834, ptr %slot51, align 8
  %v835 = load i64, ptr %slot12, align 8
  %p836 = inttoptr i64 %v835 to ptr
  %ld837 = load i32, ptr %p836, align 4, !alias.scope !3, !noalias !4
  store i32 %ld837, ptr %slot52, align 8
  %v838 = load i32, ptr %slot52, align 8
  %op839 = and i32 %v838, 28
  store i32 %op839, ptr %slot53, align 8
  %v840 = load i32, ptr %slot53, align 8
  %cv841 = zext i32 %v840 to i64
  %cond842 = icmp ne i64 %cv841, 0
  br i1 %cond842, label %bb_rcslotrole20, label %bb_rcslotowner20
bb_rcslotrole20:
  %v843 = load i64, ptr %slot45, align 8
  store i64 %v843, ptr %slot54, align 8
  %v844 = load i64, ptr %slot54, align 8
  %v845 = load i64, ptr %slot51, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v844, i64 %v845) nomerge, !dbg !114
  br label %bb_rcslotdone20
bb_rcslotowner20:
  %v846 = load i64, ptr %slot45, align 8
  store i64 %v846, ptr %slot55, align 8
  %v847 = load i64, ptr %slot55, align 8
  %v848 = load i64, ptr %slot51, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v847, i64 %v848) nomerge, !dbg !114
  br label %bb_rcslotdone20
bb_rcslotdone20:
  %v849 = load i64, ptr %slot35, align 8
  %p850 = inttoptr i64 %v849 to ptr
  %ld851 = load i64, ptr %p850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld851, ptr %slot56, align 8
  %v852 = load i64, ptr %slot56, align 8
  %op853 = add i64 %v852, 0
  store i64 %op853, ptr %slot57, align 8
  %v854 = load i64, ptr %slot57, align 8
  %p855 = inttoptr i64 %v854 to ptr
  %ld856 = load i64, ptr %p855, align 8, !alias.scope !4, !noalias !3
  store i64 %ld856, ptr %slot58, align 8
  %v857 = load i64, ptr %slot58, align 8
  %v858 = load i64, ptr %slot35, align 8
  %p859 = inttoptr i64 %v858 to ptr
  store i64 %v857, ptr %p859, align 8, !alias.scope !3, !noalias !4
  %v860 = load i64, ptr %slot11, align 8
  %p861 = inttoptr i64 %v860 to ptr
  %ld862 = load i32, ptr %p861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld862, ptr %slot59, align 8
  %v863 = load i32, ptr %slot59, align 8
  %cv864 = zext i32 %v863 to i64
  %cond865 = icmp ne i64 %cv864, 0
  br i1 %cond865, label %bb_rcslotdrop32, label %bb_rcslotdone32
bb_rcslotdrop32:
  %v866 = load i64, ptr %slot11, align 8
  %p867 = inttoptr i64 %v866 to ptr
  store i32 0, ptr %p867, align 4, !alias.scope !3, !noalias !4
  %v868 = load i64, ptr %slot17, align 8
  store i64 %v868, ptr %slot60, align 8
  %v869 = load i64, ptr %slot12, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %ld871 = load i32, ptr %p870, align 4, !alias.scope !3, !noalias !4
  store i32 %ld871, ptr %slot61, align 8
  %v872 = load i32, ptr %slot61, align 8
  %op873 = and i32 %v872, 28
  store i32 %op873, ptr %slot62, align 8
  %v874 = load i32, ptr %slot62, align 8
  %cv875 = zext i32 %v874 to i64
  %cond876 = icmp ne i64 %cv875, 0
  br i1 %cond876, label %bb_rcslotrole32, label %bb_rcslotowner32
bb_rcslotrole32:
  %v877 = load i64, ptr %slot45, align 8
  store i64 %v877, ptr %slot63, align 8
  %v878 = load i64, ptr %slot63, align 8
  %v879 = load i64, ptr %slot60, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v878, i64 %v879) nomerge, !dbg !116
  br label %bb_rcslotdone32
bb_rcslotowner32:
  %v880 = load i64, ptr %slot45, align 8
  store i64 %v880, ptr %slot64, align 8
  %v881 = load i64, ptr %slot64, align 8
  %v882 = load i64, ptr %slot60, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v881, i64 %v882) nomerge, !dbg !116
  br label %bb_rcslotdone32
bb_rcslotdone32:
  %v883 = load i64, ptr %slot35, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %ld885 = load i64, ptr %p884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld885, ptr %slot65, align 8
  %v886 = load i64, ptr %slot65, align 8
  %v887 = load i64, ptr %slot24, align 8
  %p888 = inttoptr i64 %v887 to ptr
  store i64 %v886, ptr %p888, align 8, !alias.scope !3, !noalias !4
  %v889 = load i64, ptr %slot23, align 8
  %p890 = inttoptr i64 %v889 to ptr
  %ld891 = load i64, ptr %p890, align 8, !alias.scope !3, !noalias !4
  store i64 %ld891, ptr %slot66, align 8
  %v892 = load i64, ptr %slot66, align 8
  %v893 = load i64, ptr %slot35, align 8
  %p894 = inttoptr i64 %v893 to ptr
  store i64 %v892, ptr %p894, align 8, !alias.scope !3, !noalias !4
  %v895 = load i64, ptr %slot35, align 8
  %p896 = inttoptr i64 %v895 to ptr
  %ld897 = load i64, ptr %p896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld897, ptr %slot67, align 8
  %v898 = load i64, ptr %slot67, align 8
  %v899 = load i64, ptr %slot25, align 8
  %p900 = inttoptr i64 %v899 to ptr
  store i64 %v898, ptr %p900, align 8, !alias.scope !3, !noalias !4
  %v901 = load i64, ptr %slot25, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %ld903 = load i64, ptr %p902, align 8, !alias.scope !3, !noalias !4
  store i64 %ld903, ptr %slot68, align 8
  %v904 = load i64, ptr %slot68, align 8
  %v905 = load i64, ptr %slot35, align 8
  %p906 = inttoptr i64 %v905 to ptr
  store i64 %v904, ptr %p906, align 8, !alias.scope !3, !noalias !4
  %v907 = load i64, ptr %slot36, align 8
  %p908 = inttoptr i64 %v907 to ptr
  store i64 0, ptr %p908, align 8, !alias.scope !3, !noalias !4
  %v909 = load i64, ptr %slot36, align 8
  %p910 = inttoptr i64 %v909 to ptr
  %ld911 = load i64, ptr %p910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld911, ptr %slot69, align 8
  %v912 = load i64, ptr %slot35, align 8
  %p913 = inttoptr i64 %v912 to ptr
  %ld914 = load i64, ptr %p913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld914, ptr %slot70, align 8
  %v915 = load i64, ptr %slot70, align 8
  %v916 = load i64, ptr %slot69, align 8
  %cmp917 = icmp slt i64 %v915, %v916
  %cv918 = zext i1 %cmp917 to i64
  store i64 %cv918, ptr %slot71, align 8
  %v919 = load i64, ptr %slot71, align 8
  %v920 = load i64, ptr %slot35, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i64 %v919, ptr %p921, align 8, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot35, align 8
  %p923 = inttoptr i64 %v922 to ptr
  %ld924 = load i64, ptr %p923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld924, ptr %slot72, align 8
  %v925 = load i64, ptr %slot72, align 8
  %cond926 = icmp ne i64 %v925, 0
  br i1 %cond926, label %bb_next47, label %bb_i15
bb_next47:
  %v927 = load i64, ptr %slot24, align 8
  %p928 = inttoptr i64 %v927 to ptr
  %ld929 = load i64, ptr %p928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld929, ptr %slot73, align 8
  %v930 = load i64, ptr %slot73, align 8
  %op931 = add i64 %v930, 0
  store i64 %op931, ptr %slot74, align 8
  %v932 = load i64, ptr %slot74, align 8
  %p933 = inttoptr i64 %v932 to ptr
  %ld934 = load i64, ptr %p933, align 8, !alias.scope !6, !noalias !7
  store i64 %ld934, ptr %slot75, align 8
  %v935 = load i64, ptr %slot75, align 8
  %v936 = load i64, ptr %slot35, align 8
  %p937 = inttoptr i64 %v936 to ptr
  store i64 %v935, ptr %p937, align 8, !alias.scope !3, !noalias !4
  %v938 = load i64, ptr %slot35, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %ld940 = load i64, ptr %p939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld940, ptr %slot76, align 8
  %v941 = load i64, ptr %slot76, align 8
  %cmp942 = icmp ugt i64 %v941, 9223372036854775807
  %cv943 = zext i1 %cmp942 to i64
  store i64 %cv943, ptr %slot77, align 8
  %v944 = load i64, ptr %slot77, align 8
  %cond945 = icmp ne i64 %v944, 0
  br i1 %cond945, label %bb_cast_overflow52, label %bb_cast_ok52
bb_cast_overflow52:
  %v946 = load i64, ptr %slot1, align 8
  %p947 = inttoptr i64 %v946 to ptr
  %v948 = load i64, ptr %slot76, align 8
  call void @myl_qbe_fail_cast(ptr %p947, i64 %v948, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok52:
  %v949 = load i64, ptr %slot76, align 8
  %v950 = load i64, ptr %slot35, align 8
  %p951 = inttoptr i64 %v950 to ptr
  store i64 %v949, ptr %p951, align 8, !alias.scope !3, !noalias !4
  %v952 = load i64, ptr %slot25, align 8
  %p953 = inttoptr i64 %v952 to ptr
  %ld954 = load i64, ptr %p953, align 8, !alias.scope !3, !noalias !4
  store i64 %ld954, ptr %slot78, align 8
  %v955 = load i64, ptr %slot78, align 8
  %v956 = load i64, ptr %slot36, align 8
  %p957 = inttoptr i64 %v956 to ptr
  store i64 %v955, ptr %p957, align 8, !alias.scope !3, !noalias !4
  %v958 = load i64, ptr %slot36, align 8
  %p959 = inttoptr i64 %v958 to ptr
  %ld960 = load i64, ptr %p959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld960, ptr %slot79, align 8
  %v961 = load i64, ptr %slot35, align 8
  %p962 = inttoptr i64 %v961 to ptr
  %ld963 = load i64, ptr %p962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld963, ptr %slot80, align 8
  %v964 = load i64, ptr %slot80, align 8
  %v965 = load i64, ptr %slot79, align 8
  %ovpair967 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v964, i64 %v965)
  %op966 = extractvalue { i64, i1 } %ovpair967, 0
  %ov968 = extractvalue { i64, i1 } %ovpair967, 1
  store i64 %op966, ptr %slot81, align 8
  %v969 = load i64, ptr %slot80, align 8
  %v970 = load i64, ptr %slot81, align 8
  %op971 = xor i64 %v969, %v970
  store i64 %op971, ptr %slot82, align 8
  %v972 = load i64, ptr %slot79, align 8
  %v973 = load i64, ptr %slot81, align 8
  %op974 = xor i64 %v972, %v973
  store i64 %op974, ptr %slot83, align 8
  %v975 = load i64, ptr %slot82, align 8
  %v976 = load i64, ptr %slot83, align 8
  %op977 = and i64 %v975, %v976
  store i64 %op977, ptr %slot84, align 8
  %cv978 = zext i1 %ov968 to i64
  store i64 %cv978, ptr %slot85, align 8
  %v979 = load i64, ptr %slot85, align 8
  %cond980 = icmp ne i64 %v979, 0
  br i1 %cond980, label %bb_overflow56, label %bb_checked56
bb_overflow56:
  %v981 = load i64, ptr %slot1, align 8
  %p982 = inttoptr i64 %v981 to ptr
  %v983 = load i64, ptr %slot80, align 8
  %v984 = load i64, ptr %slot79, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p982, i64 0, i64 %v983, i64 %v984, i64 64) nomerge, !dbg !120
  unreachable
bb_checked56:
  %v985 = load i64, ptr %slot81, align 8
  %v986 = load i64, ptr %slot35, align 8
  %p987 = inttoptr i64 %v986 to ptr
  store i64 %v985, ptr %p987, align 8, !alias.scope !3, !noalias !4
  %v988 = load i64, ptr %slot35, align 8
  %p989 = inttoptr i64 %v988 to ptr
  %ld990 = load i64, ptr %p989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld990, ptr %slot86, align 8
  %v991 = load i64, ptr %slot86, align 8
  %v992 = load i64, ptr %slot25, align 8
  %p993 = inttoptr i64 %v992 to ptr
  store i64 %v991, ptr %p993, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v994 = load i64, ptr %slot25, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %ld996 = load i64, ptr %p995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld996, ptr %slot87, align 8
  %v997 = load i64, ptr %slot87, align 8
  %v998 = load i64, ptr %slot35, align 8
  %p999 = inttoptr i64 %v998 to ptr
  store i64 %v997, ptr %p999, align 8, !alias.scope !3, !noalias !4
  %v1000 = load i64, ptr %slot24, align 8
  %p1001 = inttoptr i64 %v1000 to ptr
  %ld1002 = load i64, ptr %p1001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1002, ptr %slot88, align 8
  %v1003 = load i64, ptr %slot35, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  %ld1005 = load i64, ptr %p1004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1005, ptr %slot89, align 8
  %v1006 = load i64, ptr %slot88, align 8
  %p1007 = inttoptr i64 %v1006 to ptr
  %ld1008 = load i64, ptr %p1007, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1008, ptr %slot90, align 8
  %v1009 = load i64, ptr %slot89, align 8
  %v1010 = load i64, ptr %slot90, align 8
  %cmp1011 = icmp ult i64 %v1009, %v1010
  %cv1012 = zext i1 %cmp1011 to i64
  store i64 %cv1012, ptr %slot91, align 8
  %v1013 = load i64, ptr %slot91, align 8
  %cond1014 = icmp ne i64 %v1013, 0
  br i1 %cond1014, label %bb_success68, label %bb_failed68
bb_failed68:
  %v1015 = load i64, ptr %slot1, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %v1017 = load i64, ptr %slot89, align 8
  %v1018 = load i64, ptr %slot90, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1016, i64 %v1017, i64 %v1018) nomerge, !dbg !122
  unreachable
bb_success68:
  %v1019 = load i64, ptr %slot88, align 8
  %op1020 = add i64 %v1019, 32
  store i64 %op1020, ptr %slot92, align 8
  %v1021 = load i64, ptr %slot92, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %ld1023 = load i64, ptr %p1022, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1023, ptr %slot93, align 8
  %v1024 = load i64, ptr %slot89, align 8
  %op1025 = mul i64 %v1024, 112
  store i64 %op1025, ptr %slot94, align 8
  %v1026 = load i64, ptr %slot93, align 8
  %v1027 = load i64, ptr %slot94, align 8
  %op1028 = add i64 %v1026, %v1027
  store i64 %op1028, ptr %slot95, align 8
  %v1029 = load i64, ptr %slot95, align 8
  %v1030 = load i64, ptr %slot35, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  store i64 %v1029, ptr %p1031, align 8, !alias.scope !3, !noalias !4
  %v1032 = load i64, ptr %slot35, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  %ld1034 = load i64, ptr %p1033, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1034, ptr %slot96, align 8
  %v1035 = load i64, ptr %slot21, align 8
  store i64 %v1035, ptr %slot97, align 8
  %v1036 = load i64, ptr %slot45, align 8
  %v1037 = load i64, ptr %slot97, align 8
  %v1038 = load i64, ptr %slot96, align 8
  %call1039 = call i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_loan(i64 %v1036, i64 %v1037, i64 %v1038) nomerge, !dbg !122
  store i32 %call1039, ptr %slot98, align 8
  %v1040 = load i32, ptr %slot98, align 8
  %cv1041 = zext i32 %v1040 to i64
  %cond1042 = icmp ne i64 %cv1041, 0
  br i1 %cond1042, label %bb_rcsuccess76, label %bb_rcfailure76
bb_rcfailure76:
  %v1043 = load i64, ptr %slot45, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  %call1045 = call i32 @myl_rc_take_failure(ptr %p1044) nomerge, !dbg !122
  store i32 %call1045, ptr %slot99, align 8
  %v1046 = load i64, ptr %slot1, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %v1048 = load i32, ptr %slot99, align 8
  %call1049 = call i32 @myl_qbe_rc_status(ptr %p1047, i32 %v1048) nomerge, !dbg !122
  store i32 %call1049, ptr %slot100, align 8
  br label %bb_failure
bb_rcsuccess76:
  %v1050 = load i64, ptr %slot16, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  store i32 2, ptr %p1051, align 4, !alias.scope !3, !noalias !4
  %v1052 = load i64, ptr %slot16, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  store i32 16, ptr %p1053, align 4, !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot15, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  store i32 1, ptr %p1055, align 4, !alias.scope !3, !noalias !4
  %v1056 = load i64, ptr %slot17, align 8
  store i64 %v1056, ptr %slot101, align 8
  %v1057 = load i64, ptr %slot21, align 8
  store i64 %v1057, ptr %slot102, align 8
  %v1058 = load i64, ptr %slot102, align 8
  %v1059 = load i64, ptr %slot101, align 8
  %p1060 = inttoptr i64 %v1058 to ptr
  %p1061 = inttoptr i64 %v1059 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1061, ptr %p1060, i64 112, i1 false), !alias.scope !3, !noalias !4
  %v1062 = load i64, ptr %slot12, align 8
  %p1063 = inttoptr i64 %v1062 to ptr
  store i32 2, ptr %p1063, align 4, !alias.scope !3, !noalias !4
  %v1064 = load i64, ptr %slot16, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %ld1066 = load i32, ptr %p1065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1066, ptr %slot103, align 8
  %v1067 = load i32, ptr %slot103, align 8
  %v1068 = load i64, ptr %slot12, align 8
  %p1069 = inttoptr i64 %v1068 to ptr
  store i32 %v1067, ptr %p1069, align 4, !alias.scope !3, !noalias !4
  %v1070 = load i64, ptr %slot15, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  store i32 0, ptr %p1071, align 4, !alias.scope !3, !noalias !4
  %v1072 = load i64, ptr %slot11, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  store i32 1, ptr %p1073, align 4, !alias.scope !3, !noalias !4
  %v1074 = load i64, ptr %slot101, align 8
  %v1075 = load i64, ptr %slot35, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  store i64 %v1074, ptr %p1076, align 8, !alias.scope !3, !noalias !4
  %v1077 = load i64, ptr %slot35, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  %ld1079 = load i64, ptr %p1078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1079, ptr %slot104, align 8
  %v1080 = load i64, ptr %slot104, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  %ld1082 = load i32, ptr %p1081, align 4, !alias.scope !3, !noalias !4
  %ext1083 = zext i32 %ld1082 to i64
  store i64 %ext1083, ptr %slot105, align 8
  %v1084 = load i64, ptr %slot105, align 8
  %cmp1085 = icmp eq i64 %v1084, 0
  %cv1086 = zext i1 %cmp1085 to i64
  store i64 %cv1086, ptr %slot106, align 8
  %v1087 = load i64, ptr %slot106, align 8
  %cond1088 = icmp ne i64 %v1087, 0
  br i1 %cond1088, label %bb_rcarm92, label %bb_rcarmnext92
bb_rcarm92:
  %v1089 = load i64, ptr %slot11, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  %ld1091 = load i32, ptr %p1090, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1091, ptr %slot107, align 8
  %v1092 = load i32, ptr %slot107, align 8
  %cv1093 = zext i32 %v1092 to i64
  %cond1094 = icmp ne i64 %cv1093, 0
  br i1 %cond1094, label %bb_rcslotdrop95, label %bb_rcslotdone95
bb_rcslotdrop95:
  %v1095 = load i64, ptr %slot11, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  store i32 0, ptr %p1096, align 4, !alias.scope !3, !noalias !4
  %v1097 = load i64, ptr %slot17, align 8
  store i64 %v1097, ptr %slot108, align 8
  %v1098 = load i64, ptr %slot12, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  %ld1100 = load i32, ptr %p1099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1100, ptr %slot109, align 8
  %v1101 = load i32, ptr %slot109, align 8
  %op1102 = and i32 %v1101, 28
  store i32 %op1102, ptr %slot110, align 8
  %v1103 = load i32, ptr %slot110, align 8
  %cv1104 = zext i32 %v1103 to i64
  %cond1105 = icmp ne i64 %cv1104, 0
  br i1 %cond1105, label %bb_rcslotrole95, label %bb_rcslotowner95
bb_rcslotrole95:
  %v1106 = load i64, ptr %slot45, align 8
  store i64 %v1106, ptr %slot111, align 8
  %v1107 = load i64, ptr %slot111, align 8
  %v1108 = load i64, ptr %slot108, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1107, i64 %v1108) nomerge, !dbg !124
  br label %bb_rcslotdone95
bb_rcslotowner95:
  %v1109 = load i64, ptr %slot45, align 8
  store i64 %v1109, ptr %slot112, align 8
  %v1110 = load i64, ptr %slot112, align 8
  %v1111 = load i64, ptr %slot108, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1110, i64 %v1111) nomerge, !dbg !124
  br label %bb_rcslotdone95
bb_rcslotdone95:
  br label %bb_i95
bb_rcarmnext92:
  %v1112 = load i64, ptr %slot105, align 8
  %cmp1113 = icmp eq i64 %v1112, 1
  %cv1114 = zext i1 %cmp1113 to i64
  store i64 %cv1114, ptr %slot113, align 8
  %v1115 = load i64, ptr %slot113, align 8
  %cond1116 = icmp ne i64 %v1115, 0
  br i1 %cond1116, label %bb_rcarm102, label %bb_rcarmnext102
bb_rcarm102:
  %v1117 = load i64, ptr %slot11, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %ld1119 = load i32, ptr %p1118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1119, ptr %slot114, align 8
  %v1120 = load i32, ptr %slot114, align 8
  %cv1121 = zext i32 %v1120 to i64
  %cond1122 = icmp ne i64 %cv1121, 0
  br i1 %cond1122, label %bb_rcslotdrop105, label %bb_rcslotdone105
bb_rcslotdrop105:
  %v1123 = load i64, ptr %slot11, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  store i32 0, ptr %p1124, align 4, !alias.scope !3, !noalias !4
  %v1125 = load i64, ptr %slot17, align 8
  store i64 %v1125, ptr %slot115, align 8
  %v1126 = load i64, ptr %slot12, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  %ld1128 = load i32, ptr %p1127, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1128, ptr %slot116, align 8
  %v1129 = load i32, ptr %slot116, align 8
  %op1130 = and i32 %v1129, 28
  store i32 %op1130, ptr %slot117, align 8
  %v1131 = load i32, ptr %slot117, align 8
  %cv1132 = zext i32 %v1131 to i64
  %cond1133 = icmp ne i64 %cv1132, 0
  br i1 %cond1133, label %bb_rcslotrole105, label %bb_rcslotowner105
bb_rcslotrole105:
  %v1134 = load i64, ptr %slot45, align 8
  store i64 %v1134, ptr %slot118, align 8
  %v1135 = load i64, ptr %slot118, align 8
  %v1136 = load i64, ptr %slot115, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1135, i64 %v1136) nomerge, !dbg !124
  br label %bb_rcslotdone105
bb_rcslotowner105:
  %v1137 = load i64, ptr %slot45, align 8
  store i64 %v1137, ptr %slot119, align 8
  %v1138 = load i64, ptr %slot119, align 8
  %v1139 = load i64, ptr %slot115, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1138, i64 %v1139) nomerge, !dbg !124
  br label %bb_rcslotdone105
bb_rcslotdone105:
  br label %bb_i96
bb_rcarmnext102:
  %v1140 = load i64, ptr %slot105, align 8
  %cmp1141 = icmp eq i64 %v1140, 2
  %cv1142 = zext i1 %cmp1141 to i64
  store i64 %cv1142, ptr %slot120, align 8
  %v1143 = load i64, ptr %slot120, align 8
  %cond1144 = icmp ne i64 %v1143, 0
  br i1 %cond1144, label %bb_rcarm112, label %bb_rcarmnext112
bb_rcarm112:
  %v1145 = load i64, ptr %slot11, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  %ld1147 = load i32, ptr %p1146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1147, ptr %slot121, align 8
  %v1148 = load i32, ptr %slot121, align 8
  %cv1149 = zext i32 %v1148 to i64
  %cond1150 = icmp ne i64 %cv1149, 0
  br i1 %cond1150, label %bb_rcslotdrop115, label %bb_rcslotdone115
bb_rcslotdrop115:
  %v1151 = load i64, ptr %slot11, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  store i32 0, ptr %p1152, align 4, !alias.scope !3, !noalias !4
  %v1153 = load i64, ptr %slot17, align 8
  store i64 %v1153, ptr %slot122, align 8
  %v1154 = load i64, ptr %slot12, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  %ld1156 = load i32, ptr %p1155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1156, ptr %slot123, align 8
  %v1157 = load i32, ptr %slot123, align 8
  %op1158 = and i32 %v1157, 28
  store i32 %op1158, ptr %slot124, align 8
  %v1159 = load i32, ptr %slot124, align 8
  %cv1160 = zext i32 %v1159 to i64
  %cond1161 = icmp ne i64 %cv1160, 0
  br i1 %cond1161, label %bb_rcslotrole115, label %bb_rcslotowner115
bb_rcslotrole115:
  %v1162 = load i64, ptr %slot45, align 8
  store i64 %v1162, ptr %slot125, align 8
  %v1163 = load i64, ptr %slot125, align 8
  %v1164 = load i64, ptr %slot122, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1163, i64 %v1164) nomerge, !dbg !124
  br label %bb_rcslotdone115
bb_rcslotowner115:
  %v1165 = load i64, ptr %slot45, align 8
  store i64 %v1165, ptr %slot126, align 8
  %v1166 = load i64, ptr %slot126, align 8
  %v1167 = load i64, ptr %slot122, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1166, i64 %v1167) nomerge, !dbg !124
  br label %bb_rcslotdone115
bb_rcslotdone115:
  br label %bb_i97
bb_rcarmnext112:
  %v1168 = load i64, ptr %slot105, align 8
  %cmp1169 = icmp eq i64 %v1168, 3
  %cv1170 = zext i1 %cmp1169 to i64
  store i64 %cv1170, ptr %slot127, align 8
  %v1171 = load i64, ptr %slot127, align 8
  %cond1172 = icmp ne i64 %v1171, 0
  br i1 %cond1172, label %bb_rcarm122, label %bb_rcarmnext122
bb_rcarm122:
  %v1173 = load i64, ptr %slot11, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  %ld1175 = load i32, ptr %p1174, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1175, ptr %slot128, align 8
  %v1176 = load i32, ptr %slot128, align 8
  %cv1177 = zext i32 %v1176 to i64
  %cond1178 = icmp ne i64 %cv1177, 0
  br i1 %cond1178, label %bb_rcslotdrop125, label %bb_rcslotdone125
bb_rcslotdrop125:
  %v1179 = load i64, ptr %slot11, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  store i32 0, ptr %p1180, align 4, !alias.scope !3, !noalias !4
  %v1181 = load i64, ptr %slot17, align 8
  store i64 %v1181, ptr %slot129, align 8
  %v1182 = load i64, ptr %slot12, align 8
  %p1183 = inttoptr i64 %v1182 to ptr
  %ld1184 = load i32, ptr %p1183, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1184, ptr %slot130, align 8
  %v1185 = load i32, ptr %slot130, align 8
  %op1186 = and i32 %v1185, 28
  store i32 %op1186, ptr %slot131, align 8
  %v1187 = load i32, ptr %slot131, align 8
  %cv1188 = zext i32 %v1187 to i64
  %cond1189 = icmp ne i64 %cv1188, 0
  br i1 %cond1189, label %bb_rcslotrole125, label %bb_rcslotowner125
bb_rcslotrole125:
  %v1190 = load i64, ptr %slot45, align 8
  store i64 %v1190, ptr %slot132, align 8
  %v1191 = load i64, ptr %slot132, align 8
  %v1192 = load i64, ptr %slot129, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1191, i64 %v1192) nomerge, !dbg !124
  br label %bb_rcslotdone125
bb_rcslotowner125:
  %v1193 = load i64, ptr %slot45, align 8
  store i64 %v1193, ptr %slot133, align 8
  %v1194 = load i64, ptr %slot133, align 8
  %v1195 = load i64, ptr %slot129, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1194, i64 %v1195) nomerge, !dbg !124
  br label %bb_rcslotdone125
bb_rcslotdone125:
  br label %bb_i98
bb_rcarmnext122:
  %v1196 = load i64, ptr %slot105, align 8
  %cmp1197 = icmp eq i64 %v1196, 4
  %cv1198 = zext i1 %cmp1197 to i64
  store i64 %cv1198, ptr %slot134, align 8
  %v1199 = load i64, ptr %slot134, align 8
  %cond1200 = icmp ne i64 %v1199, 0
  br i1 %cond1200, label %bb_rcarm132, label %bb_rcarmnext132
bb_rcarm132:
  %v1201 = load i64, ptr %slot11, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %ld1203 = load i32, ptr %p1202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1203, ptr %slot135, align 8
  %v1204 = load i32, ptr %slot135, align 8
  %cv1205 = zext i32 %v1204 to i64
  %cond1206 = icmp ne i64 %cv1205, 0
  br i1 %cond1206, label %bb_rcslotdrop135, label %bb_rcslotdone135
bb_rcslotdrop135:
  %v1207 = load i64, ptr %slot11, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  store i32 0, ptr %p1208, align 4, !alias.scope !3, !noalias !4
  %v1209 = load i64, ptr %slot17, align 8
  store i64 %v1209, ptr %slot136, align 8
  %v1210 = load i64, ptr %slot12, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  %ld1212 = load i32, ptr %p1211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1212, ptr %slot137, align 8
  %v1213 = load i32, ptr %slot137, align 8
  %op1214 = and i32 %v1213, 28
  store i32 %op1214, ptr %slot138, align 8
  %v1215 = load i32, ptr %slot138, align 8
  %cv1216 = zext i32 %v1215 to i64
  %cond1217 = icmp ne i64 %cv1216, 0
  br i1 %cond1217, label %bb_rcslotrole135, label %bb_rcslotowner135
bb_rcslotrole135:
  %v1218 = load i64, ptr %slot45, align 8
  store i64 %v1218, ptr %slot139, align 8
  %v1219 = load i64, ptr %slot139, align 8
  %v1220 = load i64, ptr %slot136, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1219, i64 %v1220) nomerge, !dbg !124
  br label %bb_rcslotdone135
bb_rcslotowner135:
  %v1221 = load i64, ptr %slot45, align 8
  store i64 %v1221, ptr %slot140, align 8
  %v1222 = load i64, ptr %slot140, align 8
  %v1223 = load i64, ptr %slot136, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1222, i64 %v1223) nomerge, !dbg !124
  br label %bb_rcslotdone135
bb_rcslotdone135:
  br label %bb_i99
bb_rcarmnext132:
  %v1224 = load i64, ptr %slot105, align 8
  %cmp1225 = icmp eq i64 %v1224, 5
  %cv1226 = zext i1 %cmp1225 to i64
  store i64 %cv1226, ptr %slot141, align 8
  %v1227 = load i64, ptr %slot141, align 8
  %cond1228 = icmp ne i64 %v1227, 0
  br i1 %cond1228, label %bb_rcarm142, label %bb_rcarmnext142
bb_rcarm142:
  %v1229 = load i64, ptr %slot11, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  %ld1231 = load i32, ptr %p1230, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1231, ptr %slot142, align 8
  %v1232 = load i32, ptr %slot142, align 8
  %cv1233 = zext i32 %v1232 to i64
  %cond1234 = icmp ne i64 %cv1233, 0
  br i1 %cond1234, label %bb_rcslotdrop145, label %bb_rcslotdone145
bb_rcslotdrop145:
  %v1235 = load i64, ptr %slot11, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  store i32 0, ptr %p1236, align 4, !alias.scope !3, !noalias !4
  %v1237 = load i64, ptr %slot17, align 8
  store i64 %v1237, ptr %slot143, align 8
  %v1238 = load i64, ptr %slot12, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  %ld1240 = load i32, ptr %p1239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1240, ptr %slot144, align 8
  %v1241 = load i32, ptr %slot144, align 8
  %op1242 = and i32 %v1241, 28
  store i32 %op1242, ptr %slot145, align 8
  %v1243 = load i32, ptr %slot145, align 8
  %cv1244 = zext i32 %v1243 to i64
  %cond1245 = icmp ne i64 %cv1244, 0
  br i1 %cond1245, label %bb_rcslotrole145, label %bb_rcslotowner145
bb_rcslotrole145:
  %v1246 = load i64, ptr %slot45, align 8
  store i64 %v1246, ptr %slot146, align 8
  %v1247 = load i64, ptr %slot146, align 8
  %v1248 = load i64, ptr %slot143, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1247, i64 %v1248) nomerge, !dbg !124
  br label %bb_rcslotdone145
bb_rcslotowner145:
  %v1249 = load i64, ptr %slot45, align 8
  store i64 %v1249, ptr %slot147, align 8
  %v1250 = load i64, ptr %slot147, align 8
  %v1251 = load i64, ptr %slot143, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1250, i64 %v1251) nomerge, !dbg !124
  br label %bb_rcslotdone145
bb_rcslotdone145:
  br label %bb_i100
bb_rcarmnext142:
  %v1252 = load i64, ptr %slot105, align 8
  %cmp1253 = icmp eq i64 %v1252, 6
  %cv1254 = zext i1 %cmp1253 to i64
  store i64 %cv1254, ptr %slot148, align 8
  %v1255 = load i64, ptr %slot148, align 8
  %cond1256 = icmp ne i64 %v1255, 0
  br i1 %cond1256, label %bb_rcarm152, label %bb_rcarmnext152
bb_rcarm152:
  %v1257 = load i64, ptr %slot11, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %ld1259 = load i32, ptr %p1258, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1259, ptr %slot149, align 8
  %v1260 = load i32, ptr %slot149, align 8
  %cv1261 = zext i32 %v1260 to i64
  %cond1262 = icmp ne i64 %cv1261, 0
  br i1 %cond1262, label %bb_rcslotdrop155, label %bb_rcslotdone155
bb_rcslotdrop155:
  %v1263 = load i64, ptr %slot11, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  store i32 0, ptr %p1264, align 4, !alias.scope !3, !noalias !4
  %v1265 = load i64, ptr %slot17, align 8
  store i64 %v1265, ptr %slot150, align 8
  %v1266 = load i64, ptr %slot12, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %ld1268 = load i32, ptr %p1267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1268, ptr %slot151, align 8
  %v1269 = load i32, ptr %slot151, align 8
  %op1270 = and i32 %v1269, 28
  store i32 %op1270, ptr %slot152, align 8
  %v1271 = load i32, ptr %slot152, align 8
  %cv1272 = zext i32 %v1271 to i64
  %cond1273 = icmp ne i64 %cv1272, 0
  br i1 %cond1273, label %bb_rcslotrole155, label %bb_rcslotowner155
bb_rcslotrole155:
  %v1274 = load i64, ptr %slot45, align 8
  store i64 %v1274, ptr %slot153, align 8
  %v1275 = load i64, ptr %slot153, align 8
  %v1276 = load i64, ptr %slot150, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1275, i64 %v1276) nomerge, !dbg !124
  br label %bb_rcslotdone155
bb_rcslotowner155:
  %v1277 = load i64, ptr %slot45, align 8
  store i64 %v1277, ptr %slot154, align 8
  %v1278 = load i64, ptr %slot154, align 8
  %v1279 = load i64, ptr %slot150, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1278, i64 %v1279) nomerge, !dbg !124
  br label %bb_rcslotdone155
bb_rcslotdone155:
  br label %bb_i101
bb_rcarmnext152:
  %v1280 = load i64, ptr %slot105, align 8
  %cmp1281 = icmp eq i64 %v1280, 7
  %cv1282 = zext i1 %cmp1281 to i64
  store i64 %cv1282, ptr %slot155, align 8
  %v1283 = load i64, ptr %slot155, align 8
  %cond1284 = icmp ne i64 %v1283, 0
  br i1 %cond1284, label %bb_rcarm162, label %bb_rcarmnext162
bb_rcarm162:
  %v1285 = load i64, ptr %slot11, align 8
  %p1286 = inttoptr i64 %v1285 to ptr
  %ld1287 = load i32, ptr %p1286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1287, ptr %slot156, align 8
  %v1288 = load i32, ptr %slot156, align 8
  %cv1289 = zext i32 %v1288 to i64
  %cond1290 = icmp ne i64 %cv1289, 0
  br i1 %cond1290, label %bb_rcslotdrop165, label %bb_rcslotdone165
bb_rcslotdrop165:
  %v1291 = load i64, ptr %slot11, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  store i32 0, ptr %p1292, align 4, !alias.scope !3, !noalias !4
  %v1293 = load i64, ptr %slot17, align 8
  store i64 %v1293, ptr %slot157, align 8
  %v1294 = load i64, ptr %slot12, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  %ld1296 = load i32, ptr %p1295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1296, ptr %slot158, align 8
  %v1297 = load i32, ptr %slot158, align 8
  %op1298 = and i32 %v1297, 28
  store i32 %op1298, ptr %slot159, align 8
  %v1299 = load i32, ptr %slot159, align 8
  %cv1300 = zext i32 %v1299 to i64
  %cond1301 = icmp ne i64 %cv1300, 0
  br i1 %cond1301, label %bb_rcslotrole165, label %bb_rcslotowner165
bb_rcslotrole165:
  %v1302 = load i64, ptr %slot45, align 8
  store i64 %v1302, ptr %slot160, align 8
  %v1303 = load i64, ptr %slot160, align 8
  %v1304 = load i64, ptr %slot157, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1303, i64 %v1304) nomerge, !dbg !124
  br label %bb_rcslotdone165
bb_rcslotowner165:
  %v1305 = load i64, ptr %slot45, align 8
  store i64 %v1305, ptr %slot161, align 8
  %v1306 = load i64, ptr %slot161, align 8
  %v1307 = load i64, ptr %slot157, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1306, i64 %v1307) nomerge, !dbg !124
  br label %bb_rcslotdone165
bb_rcslotdone165:
  br label %bb_i102
bb_rcarmnext162:
  %v1308 = load i64, ptr %slot105, align 8
  %cmp1309 = icmp eq i64 %v1308, 8
  %cv1310 = zext i1 %cmp1309 to i64
  store i64 %cv1310, ptr %slot162, align 8
  %v1311 = load i64, ptr %slot162, align 8
  %cond1312 = icmp ne i64 %v1311, 0
  br i1 %cond1312, label %bb_rcarm172, label %bb_rcarmnext172
bb_rcarm172:
  %v1313 = load i64, ptr %slot11, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  %ld1315 = load i32, ptr %p1314, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1315, ptr %slot163, align 8
  %v1316 = load i32, ptr %slot163, align 8
  %cv1317 = zext i32 %v1316 to i64
  %cond1318 = icmp ne i64 %cv1317, 0
  br i1 %cond1318, label %bb_rcslotdrop175, label %bb_rcslotdone175
bb_rcslotdrop175:
  %v1319 = load i64, ptr %slot11, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  store i32 0, ptr %p1320, align 4, !alias.scope !3, !noalias !4
  %v1321 = load i64, ptr %slot17, align 8
  store i64 %v1321, ptr %slot164, align 8
  %v1322 = load i64, ptr %slot12, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  %ld1324 = load i32, ptr %p1323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1324, ptr %slot165, align 8
  %v1325 = load i32, ptr %slot165, align 8
  %op1326 = and i32 %v1325, 28
  store i32 %op1326, ptr %slot166, align 8
  %v1327 = load i32, ptr %slot166, align 8
  %cv1328 = zext i32 %v1327 to i64
  %cond1329 = icmp ne i64 %cv1328, 0
  br i1 %cond1329, label %bb_rcslotrole175, label %bb_rcslotowner175
bb_rcslotrole175:
  %v1330 = load i64, ptr %slot45, align 8
  store i64 %v1330, ptr %slot167, align 8
  %v1331 = load i64, ptr %slot167, align 8
  %v1332 = load i64, ptr %slot164, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1331, i64 %v1332) nomerge, !dbg !124
  br label %bb_rcslotdone175
bb_rcslotowner175:
  %v1333 = load i64, ptr %slot45, align 8
  store i64 %v1333, ptr %slot168, align 8
  %v1334 = load i64, ptr %slot168, align 8
  %v1335 = load i64, ptr %slot164, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1334, i64 %v1335) nomerge, !dbg !124
  br label %bb_rcslotdone175
bb_rcslotdone175:
  br label %bb_i103
bb_rcarmnext172:
  %v1336 = load i64, ptr %slot105, align 8
  %cmp1337 = icmp eq i64 %v1336, 9
  %cv1338 = zext i1 %cmp1337 to i64
  store i64 %cv1338, ptr %slot169, align 8
  %v1339 = load i64, ptr %slot169, align 8
  %cond1340 = icmp ne i64 %v1339, 0
  br i1 %cond1340, label %bb_rcarm182, label %bb_rcarmnext182
bb_rcarm182:
  %v1341 = load i64, ptr %slot11, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  %ld1343 = load i32, ptr %p1342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1343, ptr %slot170, align 8
  %v1344 = load i32, ptr %slot170, align 8
  %cv1345 = zext i32 %v1344 to i64
  %cond1346 = icmp ne i64 %cv1345, 0
  br i1 %cond1346, label %bb_rcslotdrop185, label %bb_rcslotdone185
bb_rcslotdrop185:
  %v1347 = load i64, ptr %slot11, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  store i32 0, ptr %p1348, align 4, !alias.scope !3, !noalias !4
  %v1349 = load i64, ptr %slot17, align 8
  store i64 %v1349, ptr %slot171, align 8
  %v1350 = load i64, ptr %slot12, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  %ld1352 = load i32, ptr %p1351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1352, ptr %slot172, align 8
  %v1353 = load i32, ptr %slot172, align 8
  %op1354 = and i32 %v1353, 28
  store i32 %op1354, ptr %slot173, align 8
  %v1355 = load i32, ptr %slot173, align 8
  %cv1356 = zext i32 %v1355 to i64
  %cond1357 = icmp ne i64 %cv1356, 0
  br i1 %cond1357, label %bb_rcslotrole185, label %bb_rcslotowner185
bb_rcslotrole185:
  %v1358 = load i64, ptr %slot45, align 8
  store i64 %v1358, ptr %slot174, align 8
  %v1359 = load i64, ptr %slot174, align 8
  %v1360 = load i64, ptr %slot171, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1359, i64 %v1360) nomerge, !dbg !124
  br label %bb_rcslotdone185
bb_rcslotowner185:
  %v1361 = load i64, ptr %slot45, align 8
  store i64 %v1361, ptr %slot175, align 8
  %v1362 = load i64, ptr %slot175, align 8
  %v1363 = load i64, ptr %slot171, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1362, i64 %v1363) nomerge, !dbg !124
  br label %bb_rcslotdone185
bb_rcslotdone185:
  br label %bb_i104
bb_rcarmnext182:
  %v1364 = load i64, ptr %slot105, align 8
  %cmp1365 = icmp eq i64 %v1364, 10
  %cv1366 = zext i1 %cmp1365 to i64
  store i64 %cv1366, ptr %slot176, align 8
  %v1367 = load i64, ptr %slot176, align 8
  %cond1368 = icmp ne i64 %v1367, 0
  br i1 %cond1368, label %bb_rcarm192, label %bb_rcarmnext192
bb_rcarm192:
  %v1369 = load i64, ptr %slot11, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %ld1371 = load i32, ptr %p1370, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1371, ptr %slot177, align 8
  %v1372 = load i32, ptr %slot177, align 8
  %cv1373 = zext i32 %v1372 to i64
  %cond1374 = icmp ne i64 %cv1373, 0
  br i1 %cond1374, label %bb_rcslotdrop195, label %bb_rcslotdone195
bb_rcslotdrop195:
  %v1375 = load i64, ptr %slot11, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i32 0, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot17, align 8
  store i64 %v1377, ptr %slot178, align 8
  %v1378 = load i64, ptr %slot12, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  %ld1380 = load i32, ptr %p1379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1380, ptr %slot179, align 8
  %v1381 = load i32, ptr %slot179, align 8
  %op1382 = and i32 %v1381, 28
  store i32 %op1382, ptr %slot180, align 8
  %v1383 = load i32, ptr %slot180, align 8
  %cv1384 = zext i32 %v1383 to i64
  %cond1385 = icmp ne i64 %cv1384, 0
  br i1 %cond1385, label %bb_rcslotrole195, label %bb_rcslotowner195
bb_rcslotrole195:
  %v1386 = load i64, ptr %slot45, align 8
  store i64 %v1386, ptr %slot181, align 8
  %v1387 = load i64, ptr %slot181, align 8
  %v1388 = load i64, ptr %slot178, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1387, i64 %v1388) nomerge, !dbg !124
  br label %bb_rcslotdone195
bb_rcslotowner195:
  %v1389 = load i64, ptr %slot45, align 8
  store i64 %v1389, ptr %slot182, align 8
  %v1390 = load i64, ptr %slot182, align 8
  %v1391 = load i64, ptr %slot178, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1390, i64 %v1391) nomerge, !dbg !124
  br label %bb_rcslotdone195
bb_rcslotdone195:
  br label %bb_i105
bb_rcarmnext192:
  %v1392 = load i64, ptr %slot105, align 8
  %cmp1393 = icmp eq i64 %v1392, 11
  %cv1394 = zext i1 %cmp1393 to i64
  store i64 %cv1394, ptr %slot183, align 8
  %v1395 = load i64, ptr %slot183, align 8
  %cond1396 = icmp ne i64 %v1395, 0
  br i1 %cond1396, label %bb_rcarm202, label %bb_rcarmnext202
bb_rcarm202:
  %v1397 = load i64, ptr %slot21, align 8
  store i64 %v1397, ptr %slot184, align 8
  %v1398 = load i64, ptr %slot104, align 8
  %op1399 = add i64 %v1398, 8
  store i64 %op1399, ptr %slot185, align 8
  %v1400 = load i64, ptr %slot46, align 8
  store i64 %v1400, ptr %slot186, align 8
  %v1401 = load i64, ptr %slot45, align 8
  %v1402 = load i64, ptr %slot184, align 8
  %v1403 = load i64, ptr %slot185, align 8
  %v1404 = load i64, ptr %slot186, align 8
  %cv1405 = trunc i64 %v1404 to i32
  %call1406 = call i32 @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_retain(i64 %v1401, i64 %v1402, i64 %v1403, i32 %cv1405) nomerge, !dbg !124
  store i32 %call1406, ptr %slot187, align 8
  %v1407 = load i32, ptr %slot187, align 8
  %cv1408 = zext i32 %v1407 to i64
  %cond1409 = icmp ne i64 %cv1408, 0
  br i1 %cond1409, label %bb_rcsuccess207, label %bb_rcfailure207
bb_rcfailure207:
  %v1410 = load i64, ptr %slot45, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  %call1412 = call i32 @myl_rc_take_failure(ptr %p1411) nomerge, !dbg !124
  store i32 %call1412, ptr %slot188, align 8
  %v1413 = load i64, ptr %slot1, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  %v1415 = load i32, ptr %slot188, align 8
  %call1416 = call i32 @myl_qbe_rc_status(ptr %p1414, i32 %v1415) nomerge, !dbg !124
  store i32 %call1416, ptr %slot189, align 8
  br label %bb_failure
bb_rcsuccess207:
  %v1417 = load i64, ptr %slot16, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  store i32 2, ptr %p1418, align 4, !alias.scope !3, !noalias !4
  %v1419 = load i64, ptr %slot15, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  store i32 1, ptr %p1420, align 4, !alias.scope !3, !noalias !4
  %v1421 = load i64, ptr %slot5, align 8
  %p1422 = inttoptr i64 %v1421 to ptr
  %ld1423 = load i32, ptr %p1422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1423, ptr %slot190, align 8
  %v1424 = load i32, ptr %slot190, align 8
  %cv1425 = zext i32 %v1424 to i64
  %cond1426 = icmp ne i64 %cv1425, 0
  br i1 %cond1426, label %bb_rcslotdrop214, label %bb_rcslotdone214
bb_rcslotdrop214:
  %v1427 = load i64, ptr %slot5, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i32 0, ptr %p1428, align 4, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot26, align 8
  store i64 %v1429, ptr %slot191, align 8
  %v1430 = load i64, ptr %slot6, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  %ld1432 = load i32, ptr %p1431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1432, ptr %slot192, align 8
  %v1433 = load i32, ptr %slot192, align 8
  %op1434 = and i32 %v1433, 28
  store i32 %op1434, ptr %slot193, align 8
  %v1435 = load i32, ptr %slot193, align 8
  %cv1436 = zext i32 %v1435 to i64
  %cond1437 = icmp ne i64 %cv1436, 0
  br i1 %cond1437, label %bb_rcslotrole214, label %bb_rcslotowner214
bb_rcslotrole214:
  %v1438 = load i64, ptr %slot45, align 8
  store i64 %v1438, ptr %slot194, align 8
  %v1439 = load i64, ptr %slot194, align 8
  %v1440 = load i64, ptr %slot191, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v1439, i64 %v1440) nomerge, !dbg !124
  br label %bb_rcslotdone214
bb_rcslotowner214:
  %v1441 = load i64, ptr %slot45, align 8
  store i64 %v1441, ptr %slot195, align 8
  %v1442 = load i64, ptr %slot195, align 8
  %v1443 = load i64, ptr %slot191, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v1442, i64 %v1443) nomerge, !dbg !124
  br label %bb_rcslotdone214
bb_rcslotdone214:
  %v1444 = load i64, ptr %slot184, align 8
  %v1445 = load i64, ptr %slot26, align 8
  %p1446 = inttoptr i64 %v1444 to ptr
  %p1447 = inttoptr i64 %v1445 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1447, ptr %p1446, i64 64, i1 false), !alias.scope !3, !noalias !4
  %v1448 = load i64, ptr %slot15, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  store i32 0, ptr %p1449, align 4, !alias.scope !3, !noalias !4
  %v1450 = load i64, ptr %slot26, align 8
  store i64 %v1450, ptr %slot196, align 8
  %v1451 = load i64, ptr %slot6, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  store i32 2, ptr %p1452, align 4, !alias.scope !3, !noalias !4
  %v1453 = load i64, ptr %slot5, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  store i32 1, ptr %p1454, align 4, !alias.scope !3, !noalias !4
  %v1455 = load i64, ptr %slot11, align 8
  %p1456 = inttoptr i64 %v1455 to ptr
  %ld1457 = load i32, ptr %p1456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1457, ptr %slot197, align 8
  %v1458 = load i32, ptr %slot197, align 8
  %cv1459 = zext i32 %v1458 to i64
  %cond1460 = icmp ne i64 %cv1459, 0
  br i1 %cond1460, label %bb_rcslotdrop227, label %bb_rcslotdone227
bb_rcslotdrop227:
  %v1461 = load i64, ptr %slot11, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  store i32 0, ptr %p1462, align 4, !alias.scope !3, !noalias !4
  %v1463 = load i64, ptr %slot17, align 8
  store i64 %v1463, ptr %slot198, align 8
  %v1464 = load i64, ptr %slot12, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %ld1466 = load i32, ptr %p1465, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1466, ptr %slot199, align 8
  %v1467 = load i32, ptr %slot199, align 8
  %op1468 = and i32 %v1467, 28
  store i32 %op1468, ptr %slot200, align 8
  %v1469 = load i32, ptr %slot200, align 8
  %cv1470 = zext i32 %v1469 to i64
  %cond1471 = icmp ne i64 %cv1470, 0
  br i1 %cond1471, label %bb_rcslotrole227, label %bb_rcslotowner227
bb_rcslotrole227:
  %v1472 = load i64, ptr %slot45, align 8
  store i64 %v1472, ptr %slot201, align 8
  %v1473 = load i64, ptr %slot201, align 8
  %v1474 = load i64, ptr %slot198, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1473, i64 %v1474) nomerge, !dbg !124
  br label %bb_rcslotdone227
bb_rcslotowner227:
  %v1475 = load i64, ptr %slot45, align 8
  store i64 %v1475, ptr %slot202, align 8
  %v1476 = load i64, ptr %slot202, align 8
  %v1477 = load i64, ptr %slot198, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1476, i64 %v1477) nomerge, !dbg !124
  br label %bb_rcslotdone227
bb_rcslotdone227:
  br label %bb_i18
bb_rcarmnext202:
  br label %bb_failure
bb_i18:
  %v1478 = load i64, ptr %slot22, align 8
  %p1479 = inttoptr i64 %v1478 to ptr
  %ld1480 = load i64, ptr %p1479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1480, ptr %slot203, align 8
  %v1481 = load i64, ptr %slot203, align 8
  %v1482 = load i64, ptr %slot35, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  store i64 %v1481, ptr %p1483, align 8, !alias.scope !3, !noalias !4
  %v1484 = load i64, ptr %slot35, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %ld1486 = load i64, ptr %p1485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1486, ptr %slot204, align 8
  %v1487 = load i64, ptr %slot204, align 8
  %op1488 = add i64 %v1487, 80
  store i64 %op1488, ptr %slot205, align 8
  %v1489 = load i64, ptr %slot205, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  %ld1491 = load i64, ptr %p1490, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1491, ptr %slot206, align 8
  %v1492 = load i64, ptr %slot206, align 8
  %v1493 = load i64, ptr %slot35, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  store i64 %v1492, ptr %p1494, align 8, !alias.scope !3, !noalias !4
  %v1495 = load i64, ptr %slot11, align 8
  %p1496 = inttoptr i64 %v1495 to ptr
  %ld1497 = load i32, ptr %p1496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1497, ptr %slot207, align 8
  %v1498 = load i32, ptr %slot207, align 8
  %cv1499 = zext i32 %v1498 to i64
  %cond1500 = icmp ne i64 %cv1499, 0
  br i1 %cond1500, label %bb_rcslotdrop240, label %bb_rcslotdone240
bb_rcslotdrop240:
  %v1501 = load i64, ptr %slot11, align 8
  %p1502 = inttoptr i64 %v1501 to ptr
  store i32 0, ptr %p1502, align 4, !alias.scope !3, !noalias !4
  %v1503 = load i64, ptr %slot17, align 8
  store i64 %v1503, ptr %slot208, align 8
  %v1504 = load i64, ptr %slot12, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  %ld1506 = load i32, ptr %p1505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1506, ptr %slot209, align 8
  %v1507 = load i32, ptr %slot209, align 8
  %op1508 = and i32 %v1507, 28
  store i32 %op1508, ptr %slot210, align 8
  %v1509 = load i32, ptr %slot210, align 8
  %cv1510 = zext i32 %v1509 to i64
  %cond1511 = icmp ne i64 %cv1510, 0
  br i1 %cond1511, label %bb_rcslotrole240, label %bb_rcslotowner240
bb_rcslotrole240:
  %v1512 = load i64, ptr %slot45, align 8
  store i64 %v1512, ptr %slot211, align 8
  %v1513 = load i64, ptr %slot211, align 8
  %v1514 = load i64, ptr %slot208, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1513, i64 %v1514) nomerge, !dbg !126
  br label %bb_rcslotdone240
bb_rcslotowner240:
  %v1515 = load i64, ptr %slot45, align 8
  store i64 %v1515, ptr %slot212, align 8
  %v1516 = load i64, ptr %slot212, align 8
  %v1517 = load i64, ptr %slot208, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1516, i64 %v1517) nomerge, !dbg !126
  br label %bb_rcslotdone240
bb_rcslotdone240:
  %v1518 = load i64, ptr %slot35, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  %ld1520 = load i64, ptr %p1519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1520, ptr %slot213, align 8
  %v1521 = load i64, ptr %slot213, align 8
  %v1522 = load i64, ptr %slot27, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  store i64 %v1521, ptr %p1523, align 8, !alias.scope !3, !noalias !4
  %v1524 = load i64, ptr %slot27, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  %ld1526 = load i64, ptr %p1525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1526, ptr %slot214, align 8
  %v1527 = load i64, ptr %slot214, align 8
  %op1528 = add i64 %v1527, 0
  store i64 %op1528, ptr %slot215, align 8
  %v1529 = load i64, ptr %slot215, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  %ld1531 = load i64, ptr %p1530, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1531, ptr %slot216, align 8
  %v1532 = load i64, ptr %slot216, align 8
  %v1533 = load i64, ptr %slot35, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  store i64 %v1532, ptr %p1534, align 8, !alias.scope !3, !noalias !4
  %v1535 = load i64, ptr %slot35, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  %ld1537 = load i64, ptr %p1536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1537, ptr %slot217, align 8
  %v1538 = load i64, ptr %slot217, align 8
  %cmp1539 = icmp ugt i64 %v1538, 9223372036854775807
  %cv1540 = zext i1 %cmp1539 to i64
  store i64 %cv1540, ptr %slot218, align 8
  %v1541 = load i64, ptr %slot218, align 8
  %cond1542 = icmp ne i64 %v1541, 0
  br i1 %cond1542, label %bb_cast_overflow253, label %bb_cast_ok253
bb_cast_overflow253:
  %v1543 = load i64, ptr %slot1, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  %v1545 = load i64, ptr %slot217, align 8
  call void @myl_qbe_fail_cast(ptr %p1544, i64 %v1545, i64 320) nomerge, !dbg !128
  unreachable
bb_cast_ok253:
  %v1546 = load i64, ptr %slot217, align 8
  %v1547 = load i64, ptr %slot35, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  store i64 %v1546, ptr %p1548, align 8, !alias.scope !3, !noalias !4
  %v1549 = load i64, ptr %slot36, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  store i64 0, ptr %p1550, align 8, !alias.scope !3, !noalias !4
  %v1551 = load i64, ptr %slot36, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %ld1553 = load i64, ptr %p1552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1553, ptr %slot219, align 8
  %v1554 = load i64, ptr %slot35, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  %ld1556 = load i64, ptr %p1555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1556, ptr %slot220, align 8
  %v1557 = load i64, ptr %slot220, align 8
  %v1558 = load i64, ptr %slot219, align 8
  %cmp1559 = icmp sgt i64 %v1557, %v1558
  %cv1560 = zext i1 %cmp1559 to i64
  store i64 %cv1560, ptr %slot221, align 8
  %v1561 = load i64, ptr %slot221, align 8
  %v1562 = load i64, ptr %slot35, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  store i64 %v1561, ptr %p1563, align 8, !alias.scope !3, !noalias !4
  %v1564 = load i64, ptr %slot35, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  %ld1566 = load i64, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1566, ptr %slot222, align 8
  %v1567 = load i64, ptr %slot222, align 8
  %cond1568 = icmp ne i64 %v1567, 0
  br i1 %cond1568, label %bb_next258, label %bb_i93
bb_next258:
  %v1569 = load i64, ptr %slot22, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  %ld1571 = load i64, ptr %p1570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1571, ptr %slot223, align 8
  %v1572 = load i64, ptr %slot223, align 8
  %v1573 = load i64, ptr %slot35, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i64 %v1572, ptr %p1574, align 8, !alias.scope !3, !noalias !4
  %v1575 = load i64, ptr %slot35, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  %ld1577 = load i64, ptr %p1576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1577, ptr %slot224, align 8
  %v1578 = load i64, ptr %slot224, align 8
  %op1579 = add i64 %v1578, 80
  store i64 %op1579, ptr %slot225, align 8
  %v1580 = load i64, ptr %slot225, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  %ld1582 = load i64, ptr %p1581, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1582, ptr %slot226, align 8
  %v1583 = load i64, ptr %slot226, align 8
  %v1584 = load i64, ptr %slot35, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  store i64 %v1583, ptr %p1585, align 8, !alias.scope !3, !noalias !4
  %v1586 = load i64, ptr %slot11, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %ld1588 = load i32, ptr %p1587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1588, ptr %slot227, align 8
  %v1589 = load i32, ptr %slot227, align 8
  %cv1590 = zext i32 %v1589 to i64
  %cond1591 = icmp ne i64 %cv1590, 0
  br i1 %cond1591, label %bb_rcslotdrop264, label %bb_rcslotdone264
bb_rcslotdrop264:
  %v1592 = load i64, ptr %slot11, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  store i32 0, ptr %p1593, align 4, !alias.scope !3, !noalias !4
  %v1594 = load i64, ptr %slot17, align 8
  store i64 %v1594, ptr %slot228, align 8
  %v1595 = load i64, ptr %slot12, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  %ld1597 = load i32, ptr %p1596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1597, ptr %slot229, align 8
  %v1598 = load i32, ptr %slot229, align 8
  %op1599 = and i32 %v1598, 28
  store i32 %op1599, ptr %slot230, align 8
  %v1600 = load i32, ptr %slot230, align 8
  %cv1601 = zext i32 %v1600 to i64
  %cond1602 = icmp ne i64 %cv1601, 0
  br i1 %cond1602, label %bb_rcslotrole264, label %bb_rcslotowner264
bb_rcslotrole264:
  %v1603 = load i64, ptr %slot45, align 8
  store i64 %v1603, ptr %slot231, align 8
  %v1604 = load i64, ptr %slot231, align 8
  %v1605 = load i64, ptr %slot228, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1604, i64 %v1605) nomerge, !dbg !130
  br label %bb_rcslotdone264
bb_rcslotowner264:
  %v1606 = load i64, ptr %slot45, align 8
  store i64 %v1606, ptr %slot232, align 8
  %v1607 = load i64, ptr %slot232, align 8
  %v1608 = load i64, ptr %slot228, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1607, i64 %v1608) nomerge, !dbg !130
  br label %bb_rcslotdone264
bb_rcslotdone264:
  %v1609 = load i64, ptr %slot35, align 8
  %p1610 = inttoptr i64 %v1609 to ptr
  %ld1611 = load i64, ptr %p1610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1611, ptr %slot233, align 8
  %v1612 = load i64, ptr %slot233, align 8
  %v1613 = load i64, ptr %slot29, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i64 %v1612, ptr %p1614, align 8, !alias.scope !3, !noalias !4
  %v1615 = load i64, ptr %slot22, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %ld1617 = load i64, ptr %p1616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1617, ptr %slot234, align 8
  %v1618 = load i64, ptr %slot234, align 8
  %v1619 = load i64, ptr %slot35, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  store i64 %v1618, ptr %p1620, align 8, !alias.scope !3, !noalias !4
  %v1621 = load i64, ptr %slot35, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  %ld1623 = load i64, ptr %p1622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1623, ptr %slot235, align 8
  %v1624 = load i64, ptr %slot235, align 8
  %op1625 = add i64 %v1624, 80
  store i64 %op1625, ptr %slot236, align 8
  %v1626 = load i64, ptr %slot236, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i64, ptr %p1627, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1628, ptr %slot237, align 8
  %v1629 = load i64, ptr %slot237, align 8
  %v1630 = load i64, ptr %slot35, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i64 %v1629, ptr %p1631, align 8, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot11, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i32, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1634, ptr %slot238, align 8
  %v1635 = load i32, ptr %slot238, align 8
  %cv1636 = zext i32 %v1635 to i64
  %cond1637 = icmp ne i64 %cv1636, 0
  br i1 %cond1637, label %bb_rcslotdrop278, label %bb_rcslotdone278
bb_rcslotdrop278:
  %v1638 = load i64, ptr %slot11, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 0, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot17, align 8
  store i64 %v1640, ptr %slot239, align 8
  %v1641 = load i64, ptr %slot12, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i32, ptr %p1642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1643, ptr %slot240, align 8
  %v1644 = load i32, ptr %slot240, align 8
  %op1645 = and i32 %v1644, 28
  store i32 %op1645, ptr %slot241, align 8
  %v1646 = load i32, ptr %slot241, align 8
  %cv1647 = zext i32 %v1646 to i64
  %cond1648 = icmp ne i64 %cv1647, 0
  br i1 %cond1648, label %bb_rcslotrole278, label %bb_rcslotowner278
bb_rcslotrole278:
  %v1649 = load i64, ptr %slot45, align 8
  store i64 %v1649, ptr %slot242, align 8
  %v1650 = load i64, ptr %slot242, align 8
  %v1651 = load i64, ptr %slot239, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1650, i64 %v1651) nomerge, !dbg !132
  br label %bb_rcslotdone278
bb_rcslotowner278:
  %v1652 = load i64, ptr %slot45, align 8
  store i64 %v1652, ptr %slot243, align 8
  %v1653 = load i64, ptr %slot243, align 8
  %v1654 = load i64, ptr %slot239, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1653, i64 %v1654) nomerge, !dbg !132
  br label %bb_rcslotdone278
bb_rcslotdone278:
  %v1655 = load i64, ptr %slot35, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  %ld1657 = load i64, ptr %p1656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1657, ptr %slot244, align 8
  %v1658 = load i64, ptr %slot244, align 8
  %v1659 = load i64, ptr %slot28, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i64 %v1658, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot28, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  %ld1663 = load i64, ptr %p1662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1663, ptr %slot245, align 8
  %v1664 = load i64, ptr %slot245, align 8
  %op1665 = add i64 %v1664, 0
  store i64 %op1665, ptr %slot246, align 8
  %v1666 = load i64, ptr %slot246, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  %ld1668 = load i64, ptr %p1667, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1668, ptr %slot247, align 8
  %v1669 = load i64, ptr %slot247, align 8
  %v1670 = load i64, ptr %slot35, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  store i64 %v1669, ptr %p1671, align 8, !alias.scope !3, !noalias !4
  %v1672 = load i64, ptr %slot35, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %ld1674 = load i64, ptr %p1673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1674, ptr %slot248, align 8
  %v1675 = load i64, ptr %slot248, align 8
  %cmp1676 = icmp ugt i64 %v1675, 9223372036854775807
  %cv1677 = zext i1 %cmp1676 to i64
  store i64 %cv1677, ptr %slot249, align 8
  %v1678 = load i64, ptr %slot249, align 8
  %cond1679 = icmp ne i64 %v1678, 0
  br i1 %cond1679, label %bb_cast_overflow291, label %bb_cast_ok291
bb_cast_overflow291:
  %v1680 = load i64, ptr %slot1, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  %v1682 = load i64, ptr %slot248, align 8
  call void @myl_qbe_fail_cast(ptr %p1681, i64 %v1682, i64 320) nomerge, !dbg !134
  unreachable
bb_cast_ok291:
  %v1683 = load i64, ptr %slot248, align 8
  %v1684 = load i64, ptr %slot35, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  store i64 %v1683, ptr %p1685, align 8, !alias.scope !3, !noalias !4
  %v1686 = load i64, ptr %slot36, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  store i64 1, ptr %p1687, align 8, !alias.scope !3, !noalias !4
  %v1688 = load i64, ptr %slot36, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  %ld1690 = load i64, ptr %p1689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1690, ptr %slot250, align 8
  %v1691 = load i64, ptr %slot35, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %ld1693 = load i64, ptr %p1692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1693, ptr %slot251, align 8
  %v1694 = load i64, ptr %slot251, align 8
  %v1695 = load i64, ptr %slot250, align 8
  %ovpair1697 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1694, i64 %v1695)
  %op1696 = extractvalue { i64, i1 } %ovpair1697, 0
  %ov1698 = extractvalue { i64, i1 } %ovpair1697, 1
  store i64 %op1696, ptr %slot252, align 8
  %cv1699 = zext i1 %ov1698 to i64
  store i64 %cv1699, ptr %slot253, align 8
  %v1700 = load i64, ptr %slot253, align 8
  %cond1701 = icmp ne i64 %v1700, 0
  br i1 %cond1701, label %bb_overflow294, label %bb_checked294
bb_overflow294:
  %v1702 = load i64, ptr %slot1, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  %v1704 = load i64, ptr %slot251, align 8
  %v1705 = load i64, ptr %slot250, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1703, i64 1, i64 %v1704, i64 %v1705, i64 64) nomerge, !dbg !136
  unreachable
bb_checked294:
  %v1706 = load i64, ptr %slot252, align 8
  %v1707 = load i64, ptr %slot35, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  store i64 %v1706, ptr %p1708, align 8, !alias.scope !3, !noalias !4
  %v1709 = load i64, ptr %slot35, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %ld1711 = load i64, ptr %p1710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1711, ptr %slot254, align 8
  %v1712 = load i64, ptr %slot254, align 8
  %v1713 = load i64, ptr %slot30, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  store i64 %v1712, ptr %p1714, align 8, !alias.scope !3, !noalias !4
  %v1715 = load i64, ptr %slot30, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  %ld1717 = load i64, ptr %p1716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1717, ptr %slot255, align 8
  %v1718 = load i64, ptr %slot255, align 8
  %v1719 = load i64, ptr %slot35, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  store i64 %v1718, ptr %p1720, align 8, !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot36, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  store i64 0, ptr %p1722, align 8, !alias.scope !3, !noalias !4
  %v1723 = load i64, ptr %slot36, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  %ld1725 = load i64, ptr %p1724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1725, ptr %slot256, align 8
  %v1726 = load i64, ptr %slot35, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  %ld1728 = load i64, ptr %p1727, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1728, ptr %slot257, align 8
  %v1729 = load i64, ptr %slot257, align 8
  %v1730 = load i64, ptr %slot256, align 8
  %cmp1731 = icmp slt i64 %v1729, %v1730
  %cv1732 = zext i1 %cmp1731 to i64
  store i64 %cv1732, ptr %slot258, align 8
  %v1733 = load i64, ptr %slot258, align 8
  %v1734 = load i64, ptr %slot35, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  store i64 %v1733, ptr %p1735, align 8, !alias.scope !3, !noalias !4
  %v1736 = load i64, ptr %slot35, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %ld1738 = load i64, ptr %p1737, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1738, ptr %slot259, align 8
  %v1739 = load i64, ptr %slot259, align 8
  %cond1740 = icmp ne i64 %v1739, 0
  br i1 %cond1740, label %bb_next302, label %bb_i46
bb_next302:
  %v1741 = load i64, ptr %slot29, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  %ld1743 = load i64, ptr %p1742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1743, ptr %slot260, align 8
  %v1744 = load i64, ptr %slot260, align 8
  %op1745 = add i64 %v1744, 0
  store i64 %op1745, ptr %slot261, align 8
  %v1746 = load i64, ptr %slot261, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %ld1748 = load i64, ptr %p1747, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1748, ptr %slot262, align 8
  %v1749 = load i64, ptr %slot262, align 8
  %v1750 = load i64, ptr %slot35, align 8
  %p1751 = inttoptr i64 %v1750 to ptr
  store i64 %v1749, ptr %p1751, align 8, !alias.scope !3, !noalias !4
  %v1752 = load i64, ptr %slot35, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  %ld1754 = load i64, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1754, ptr %slot263, align 8
  %v1755 = load i64, ptr %slot263, align 8
  %cmp1756 = icmp ugt i64 %v1755, 9223372036854775807
  %cv1757 = zext i1 %cmp1756 to i64
  store i64 %cv1757, ptr %slot264, align 8
  %v1758 = load i64, ptr %slot264, align 8
  %cond1759 = icmp ne i64 %v1758, 0
  br i1 %cond1759, label %bb_cast_overflow307, label %bb_cast_ok307
bb_cast_overflow307:
  %v1760 = load i64, ptr %slot1, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  %v1762 = load i64, ptr %slot263, align 8
  call void @myl_qbe_fail_cast(ptr %p1761, i64 %v1762, i64 320) nomerge, !dbg !138
  unreachable
bb_cast_ok307:
  %v1763 = load i64, ptr %slot263, align 8
  %v1764 = load i64, ptr %slot35, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  store i64 %v1763, ptr %p1765, align 8, !alias.scope !3, !noalias !4
  %v1766 = load i64, ptr %slot30, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  %ld1768 = load i64, ptr %p1767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1768, ptr %slot265, align 8
  %v1769 = load i64, ptr %slot265, align 8
  %v1770 = load i64, ptr %slot36, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  store i64 %v1769, ptr %p1771, align 8, !alias.scope !3, !noalias !4
  %v1772 = load i64, ptr %slot36, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  %ld1774 = load i64, ptr %p1773, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1774, ptr %slot266, align 8
  %v1775 = load i64, ptr %slot35, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  %ld1777 = load i64, ptr %p1776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1777, ptr %slot267, align 8
  %v1778 = load i64, ptr %slot267, align 8
  %v1779 = load i64, ptr %slot266, align 8
  %ovpair1781 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1778, i64 %v1779)
  %op1780 = extractvalue { i64, i1 } %ovpair1781, 0
  %ov1782 = extractvalue { i64, i1 } %ovpair1781, 1
  store i64 %op1780, ptr %slot268, align 8
  %v1783 = load i64, ptr %slot267, align 8
  %v1784 = load i64, ptr %slot268, align 8
  %op1785 = xor i64 %v1783, %v1784
  store i64 %op1785, ptr %slot269, align 8
  %v1786 = load i64, ptr %slot266, align 8
  %v1787 = load i64, ptr %slot268, align 8
  %op1788 = xor i64 %v1786, %v1787
  store i64 %op1788, ptr %slot270, align 8
  %v1789 = load i64, ptr %slot269, align 8
  %v1790 = load i64, ptr %slot270, align 8
  %op1791 = and i64 %v1789, %v1790
  store i64 %op1791, ptr %slot271, align 8
  %cv1792 = zext i1 %ov1782 to i64
  store i64 %cv1792, ptr %slot272, align 8
  %v1793 = load i64, ptr %slot272, align 8
  %cond1794 = icmp ne i64 %v1793, 0
  br i1 %cond1794, label %bb_overflow311, label %bb_checked311
bb_overflow311:
  %v1795 = load i64, ptr %slot1, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  %v1797 = load i64, ptr %slot267, align 8
  %v1798 = load i64, ptr %slot266, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1796, i64 0, i64 %v1797, i64 %v1798, i64 64) nomerge, !dbg !140
  unreachable
bb_checked311:
  %v1799 = load i64, ptr %slot268, align 8
  %v1800 = load i64, ptr %slot35, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  store i64 %v1799, ptr %p1801, align 8, !alias.scope !3, !noalias !4
  %v1802 = load i64, ptr %slot35, align 8
  %p1803 = inttoptr i64 %v1802 to ptr
  %ld1804 = load i64, ptr %p1803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1804, ptr %slot273, align 8
  %v1805 = load i64, ptr %slot273, align 8
  %v1806 = load i64, ptr %slot30, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  store i64 %v1805, ptr %p1807, align 8, !alias.scope !3, !noalias !4
  br label %bb_i46
bb_i46:
  %v1808 = load i64, ptr %slot30, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  %ld1810 = load i64, ptr %p1809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1810, ptr %slot274, align 8
  %v1811 = load i64, ptr %slot274, align 8
  %v1812 = load i64, ptr %slot35, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  store i64 %v1811, ptr %p1813, align 8, !alias.scope !3, !noalias !4
  %v1814 = load i64, ptr %slot29, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  %ld1816 = load i64, ptr %p1815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1816, ptr %slot275, align 8
  %v1817 = load i64, ptr %slot35, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  %ld1819 = load i64, ptr %p1818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1819, ptr %slot276, align 8
  %v1820 = load i64, ptr %slot275, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  %ld1822 = load i64, ptr %p1821, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1822, ptr %slot277, align 8
  %v1823 = load i64, ptr %slot276, align 8
  %v1824 = load i64, ptr %slot277, align 8
  %cmp1825 = icmp ult i64 %v1823, %v1824
  %cv1826 = zext i1 %cmp1825 to i64
  store i64 %cv1826, ptr %slot278, align 8
  %v1827 = load i64, ptr %slot278, align 8
  %cond1828 = icmp ne i64 %v1827, 0
  br i1 %cond1828, label %bb_success323, label %bb_failed323
bb_failed323:
  %v1829 = load i64, ptr %slot1, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  %v1831 = load i64, ptr %slot276, align 8
  %v1832 = load i64, ptr %slot277, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1830, i64 %v1831, i64 %v1832) nomerge, !dbg !142
  unreachable
bb_success323:
  %v1833 = load i64, ptr %slot275, align 8
  %op1834 = add i64 %v1833, 32
  store i64 %op1834, ptr %slot279, align 8
  %v1835 = load i64, ptr %slot279, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  %ld1837 = load i64, ptr %p1836, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1837, ptr %slot280, align 8
  %v1838 = load i64, ptr %slot276, align 8
  %op1839 = mul i64 %v1838, 8
  store i64 %op1839, ptr %slot281, align 8
  %v1840 = load i64, ptr %slot280, align 8
  %v1841 = load i64, ptr %slot281, align 8
  %op1842 = add i64 %v1840, %v1841
  store i64 %op1842, ptr %slot282, align 8
  %v1843 = load i64, ptr %slot44, align 8
  store i64 %v1843, ptr %slot283, align 8
  %v1844 = load i64, ptr %slot282, align 8
  %v1845 = load i64, ptr %slot283, align 8
  %p1846 = inttoptr i64 %v1844 to ptr
  %p1847 = inttoptr i64 %v1845 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1847, ptr %p1846, i64 8, i1 false), !alias.scope !10000000
  %v1848 = load i64, ptr %slot283, align 8
  %v1849 = load i64, ptr %slot35, align 8
  %p1850 = inttoptr i64 %v1849 to ptr
  store i64 %v1848, ptr %p1850, align 8, !alias.scope !3, !noalias !4
  %v1851 = load i64, ptr %slot35, align 8
  %p1852 = inttoptr i64 %v1851 to ptr
  %ld1853 = load i64, ptr %p1852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1853, ptr %slot284, align 8
  %v1854 = load i64, ptr %slot21, align 8
  store i64 %v1854, ptr %slot285, align 8
  %v1855 = load i64, ptr %slot45, align 8
  %v1856 = load i64, ptr %slot285, align 8
  %v1857 = load i64, ptr %slot284, align 8
  %call1858 = call i32 @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_loan(i64 %v1855, i64 %v1856, i64 %v1857) nomerge, !dbg !142
  store i32 %call1858, ptr %slot286, align 8
  %v1859 = load i32, ptr %slot286, align 8
  %cv1860 = zext i32 %v1859 to i64
  %cond1861 = icmp ne i64 %cv1860, 0
  br i1 %cond1861, label %bb_rcsuccess332, label %bb_rcfailure332
bb_rcfailure332:
  %v1862 = load i64, ptr %slot45, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  %call1864 = call i32 @myl_rc_take_failure(ptr %p1863) nomerge, !dbg !142
  store i32 %call1864, ptr %slot287, align 8
  %v1865 = load i64, ptr %slot1, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  %v1867 = load i32, ptr %slot287, align 8
  %call1868 = call i32 @myl_qbe_rc_status(ptr %p1866, i32 %v1867) nomerge, !dbg !142
  store i32 %call1868, ptr %slot288, align 8
  br label %bb_failure
bb_rcsuccess332:
  %v1869 = load i64, ptr %slot16, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  store i32 2, ptr %p1870, align 4, !alias.scope !3, !noalias !4
  %v1871 = load i64, ptr %slot16, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  store i32 16, ptr %p1872, align 4, !alias.scope !3, !noalias !4
  %v1873 = load i64, ptr %slot15, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  store i32 1, ptr %p1874, align 4, !alias.scope !3, !noalias !4
  %v1875 = load i64, ptr %slot17, align 8
  store i64 %v1875, ptr %slot289, align 8
  %v1876 = load i64, ptr %slot21, align 8
  store i64 %v1876, ptr %slot290, align 8
  %v1877 = load i64, ptr %slot290, align 8
  %v1878 = load i64, ptr %slot289, align 8
  %p1879 = inttoptr i64 %v1877 to ptr
  %p1880 = inttoptr i64 %v1878 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1880, ptr %p1879, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1881 = load i64, ptr %slot12, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  store i32 2, ptr %p1882, align 4, !alias.scope !3, !noalias !4
  %v1883 = load i64, ptr %slot16, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  %ld1885 = load i32, ptr %p1884, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1885, ptr %slot291, align 8
  %v1886 = load i32, ptr %slot291, align 8
  %v1887 = load i64, ptr %slot12, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  store i32 %v1886, ptr %p1888, align 4, !alias.scope !3, !noalias !4
  %v1889 = load i64, ptr %slot15, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  store i32 0, ptr %p1890, align 4, !alias.scope !3, !noalias !4
  %v1891 = load i64, ptr %slot11, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  store i32 1, ptr %p1892, align 4, !alias.scope !3, !noalias !4
  %v1893 = load i64, ptr %slot289, align 8
  %v1894 = load i64, ptr %slot35, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  store i64 %v1893, ptr %p1895, align 8, !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot35, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %ld1898 = load i64, ptr %p1897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1898, ptr %slot292, align 8
  %v1899 = load i64, ptr %slot11, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %ld1901 = load i32, ptr %p1900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1901, ptr %slot293, align 8
  %v1902 = load i64, ptr %slot12, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  %ld1904 = load i32, ptr %p1903, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1904, ptr %slot294, align 8
  %v1905 = load i32, ptr %slot294, align 8
  %op1906 = and i32 %v1905, 24
  store i32 %op1906, ptr %slot294, align 8
  %v1907 = load i32, ptr %slot294, align 8
  %cmp1908 = icmp eq i32 %v1907, 0
  %cv1909 = zext i1 %cmp1908 to i32
  store i32 %cv1909, ptr %slot295, align 8
  %v1910 = load i32, ptr %slot293, align 8
  %v1911 = load i32, ptr %slot295, align 8
  %op1912 = and i32 %v1910, %v1911
  store i32 %op1912, ptr %slot296, align 8
  %v1913 = load i32, ptr %slot296, align 8
  %cv1914 = zext i32 %v1913 to i64
  %cond1915 = icmp ne i64 %cv1914, 0
  br i1 %cond1915, label %bb_rctake347, label %bb_rccopy347
bb_rctake347:
  %v1916 = load i64, ptr %slot21, align 8
  store i64 %v1916, ptr %slot297, align 8
  %v1917 = load i64, ptr %slot46, align 8
  store i64 %v1917, ptr %slot298, align 8
  %v1918 = load i64, ptr %slot292, align 8
  %v1919 = load i64, ptr %slot297, align 8
  %op1920 = sub i64 %v1918, %v1919
  store i64 %op1920, ptr %slot299, align 8
  %v1921 = load i64, ptr %slot297, align 8
  %v1922 = load i64, ptr %slot292, align 8
  %op1923 = sub i64 %v1921, %v1922
  store i64 %op1923, ptr %slot300, align 8
  %v1924 = load i64, ptr %slot299, align 8
  %cmp1925 = icmp ult i64 %v1924, 8
  %cv1926 = zext i1 %cmp1925 to i32
  store i32 %cv1926, ptr %slot301, align 8
  %v1927 = load i64, ptr %slot300, align 8
  %cmp1928 = icmp ult i64 %v1927, 8
  %cv1929 = zext i1 %cmp1928 to i32
  store i32 %cv1929, ptr %slot302, align 8
  %v1930 = load i32, ptr %slot301, align 8
  %v1931 = load i32, ptr %slot302, align 8
  %op1932 = or i32 %v1930, %v1931
  store i32 %op1932, ptr %slot303, align 8
  %v1933 = load i32, ptr %slot303, align 8
  %cv1934 = zext i32 %v1933 to i64
  %cond1935 = icmp ne i64 %cv1934, 0
  br i1 %cond1935, label %bb_rcmoveslow356, label %bb_rcmovecheck356
bb_rcmovecheck356:
  %v1936 = load i64, ptr %slot292, align 8
  %op1937 = add i64 %v1936, 0
  store i64 %op1937, ptr %slot304, align 8
  %v1938 = load i64, ptr %slot304, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  %ld1940 = load i64, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1940, ptr %slot305, align 8
  %v1941 = load i64, ptr %slot305, align 8
  %cmp1942 = icmp ne i64 %v1941, 0
  %cv1943 = zext i1 %cmp1942 to i32
  store i32 %cv1943, ptr %slot306, align 8
  %v1944 = load i32, ptr %slot306, align 8
  %cv1945 = zext i32 %v1944 to i64
  %cond1946 = icmp ne i64 %cv1945, 0
  br i1 %cond1946, label %bb_rcmoveheader364, label %bb_rcmovenext364
bb_rcmoveheader364:
  %v1947 = load i64, ptr %slot305, align 8
  %op1948 = sub i64 %v1947, 16
  store i64 %op1948, ptr %slot307, align 8
  %v1949 = load i64, ptr %slot305, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %rgep1951 = getelementptr i8, ptr %p1950, i64 -16
  %ld1952 = load i64, ptr %rgep1951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1952, ptr %slot308, align 8
  %v1953 = load i64, ptr %slot308, align 8
  %op1954 = and i64 %v1953, 5764607523034234881
  store i64 %op1954, ptr %slot309, align 8
  %v1955 = load i64, ptr %slot309, align 8
  %cmp1956 = icmp ne i64 %v1955, 0
  %cv1957 = zext i1 %cmp1956 to i32
  store i32 %cv1957, ptr %slot310, align 8
  %v1958 = load i32, ptr %slot310, align 8
  %cv1959 = zext i32 %v1958 to i64
  %cond1960 = icmp ne i64 %cv1959, 0
  br i1 %cond1960, label %bb_rcmoveslow356, label %bb_rcmovenext364
bb_rcmovenext364:
  %v1961 = load i64, ptr %slot292, align 8
  %v1962 = load i64, ptr %slot297, align 8
  %p1963 = inttoptr i64 %v1961 to ptr
  %p1964 = inttoptr i64 %v1962 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1964, ptr %p1963, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1965 = load i64, ptr %slot292, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  store i64 0, ptr %p1966, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved356
bb_rcmoveslow356:
  %v1967 = load i64, ptr %slot45, align 8
  %v1968 = load i64, ptr %slot297, align 8
  %v1969 = load i64, ptr %slot292, align 8
  %v1970 = load i64, ptr %slot298, align 8
  %cv1971 = trunc i64 %v1970 to i32
  %call1972 = call i32 @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_take(i64 %v1967, i64 %v1968, i64 %v1969, i32 %cv1971) nomerge, !dbg !144
  store i32 %call1972, ptr %slot311, align 8
  %v1973 = load i32, ptr %slot311, align 8
  %cv1974 = zext i32 %v1973 to i64
  %cond1975 = icmp ne i64 %cv1974, 0
  br i1 %cond1975, label %bb_rcsuccess371, label %bb_rcfailure371
bb_rcfailure371:
  %v1976 = load i64, ptr %slot45, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  %call1978 = call i32 @myl_rc_take_failure(ptr %p1977) nomerge, !dbg !144
  store i32 %call1978, ptr %slot312, align 8
  %v1979 = load i64, ptr %slot1, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  %v1981 = load i32, ptr %slot312, align 8
  %call1982 = call i32 @myl_qbe_rc_status(ptr %p1980, i32 %v1981) nomerge, !dbg !144
  store i32 %call1982, ptr %slot313, align 8
  br label %bb_failure
bb_rcsuccess371:
  br label %bb_rcmoved356
bb_rcmoved356:
  %v1983 = load i64, ptr %slot11, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  store i32 0, ptr %p1984, align 4, !alias.scope !3, !noalias !4
  %v1985 = load i64, ptr %slot16, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  store i32 2, ptr %p1986, align 4, !alias.scope !3, !noalias !4
  %v1987 = load i64, ptr %slot15, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  store i32 1, ptr %p1988, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared347
bb_rccopy347:
  %v1989 = load i64, ptr %slot21, align 8
  store i64 %v1989, ptr %slot314, align 8
  %v1990 = load i64, ptr %slot46, align 8
  store i64 %v1990, ptr %slot315, align 8
  %v1991 = load i64, ptr %slot45, align 8
  %v1992 = load i64, ptr %slot314, align 8
  %v1993 = load i64, ptr %slot292, align 8
  %v1994 = load i64, ptr %slot315, align 8
  %cv1995 = trunc i64 %v1994 to i32
  %call1996 = call i32 @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_retain(i64 %v1991, i64 %v1992, i64 %v1993, i32 %cv1995) nomerge, !dbg !144
  store i32 %call1996, ptr %slot316, align 8
  %v1997 = load i32, ptr %slot316, align 8
  %cv1998 = zext i32 %v1997 to i64
  %cond1999 = icmp ne i64 %cv1998, 0
  br i1 %cond1999, label %bb_rcsuccess380, label %bb_rcfailure380
bb_rcfailure380:
  %v2000 = load i64, ptr %slot45, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  %call2002 = call i32 @myl_rc_take_failure(ptr %p2001) nomerge, !dbg !144
  store i32 %call2002, ptr %slot317, align 8
  %v2003 = load i64, ptr %slot1, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  %v2005 = load i32, ptr %slot317, align 8
  %call2006 = call i32 @myl_qbe_rc_status(ptr %p2004, i32 %v2005) nomerge, !dbg !144
  store i32 %call2006, ptr %slot318, align 8
  br label %bb_failure
bb_rcsuccess380:
  %v2007 = load i64, ptr %slot16, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  store i32 2, ptr %p2008, align 4, !alias.scope !3, !noalias !4
  %v2009 = load i64, ptr %slot15, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  store i32 1, ptr %p2010, align 4, !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot11, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  %ld2013 = load i32, ptr %p2012, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2013, ptr %slot319, align 8
  %v2014 = load i32, ptr %slot319, align 8
  %cv2015 = zext i32 %v2014 to i64
  %cond2016 = icmp ne i64 %cv2015, 0
  br i1 %cond2016, label %bb_rcslotdrop387, label %bb_rcslotdone387
bb_rcslotdrop387:
  %v2017 = load i64, ptr %slot11, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  store i32 0, ptr %p2018, align 4, !alias.scope !3, !noalias !4
  %v2019 = load i64, ptr %slot17, align 8
  store i64 %v2019, ptr %slot320, align 8
  %v2020 = load i64, ptr %slot12, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  %ld2022 = load i32, ptr %p2021, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2022, ptr %slot321, align 8
  %v2023 = load i32, ptr %slot321, align 8
  %op2024 = and i32 %v2023, 28
  store i32 %op2024, ptr %slot322, align 8
  %v2025 = load i32, ptr %slot322, align 8
  %cv2026 = zext i32 %v2025 to i64
  %cond2027 = icmp ne i64 %cv2026, 0
  br i1 %cond2027, label %bb_rcslotrole387, label %bb_rcslotowner387
bb_rcslotrole387:
  %v2028 = load i64, ptr %slot45, align 8
  store i64 %v2028, ptr %slot323, align 8
  %v2029 = load i64, ptr %slot323, align 8
  %v2030 = load i64, ptr %slot320, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_unloan(i64 %v2029, i64 %v2030) nomerge, !dbg !144
  br label %bb_rcslotdone387
bb_rcslotowner387:
  %v2031 = load i64, ptr %slot320, align 8
  %p2033 = inttoptr i64 %v2031 to ptr
  %gep2034 = getelementptr i8, ptr %p2033, i64 0
  %op2032 = ptrtoint ptr %gep2034 to i64
  store i64 %op2032, ptr %slot324, align 8
  %v2035 = load i64, ptr %slot45, align 8
  store i64 %v2035, ptr %slot325, align 8
  %v2036 = load i64, ptr %slot324, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  %ld2038 = load i64, ptr %p2037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2038, ptr %slot326, align 8
  %v2039 = load i64, ptr %slot326, align 8
  %cmp2040 = icmp ne i64 %v2039, 0
  %cv2041 = zext i1 %cmp2040 to i32
  store i32 %cv2041, ptr %slot327, align 8
  %v2042 = load i32, ptr %slot327, align 8
  %cv2043 = zext i32 %v2042 to i64
  %cond2044 = icmp ne i64 %cv2043, 0
  br i1 %cond2044, label %bb_rcgnn405, label %bb_rcgdone405
bb_rcgnn405:
  %v2045 = load i64, ptr %slot326, align 8
  %op2046 = sub i64 %v2045, 16
  store i64 %op2046, ptr %slot328, align 8
  %v2047 = load i64, ptr %slot326, align 8
  %p2048 = inttoptr i64 %v2047 to ptr
  %rgep2049 = getelementptr i8, ptr %p2048, i64 -16
  %ld2050 = load i64, ptr %rgep2049, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2050, ptr %slot329, align 8
  %v2051 = load i64, ptr %slot329, align 8
  %op2052 = and i64 %v2051, 4611686018427387906
  store i64 %op2052, ptr %slot330, align 8
  %v2053 = load i64, ptr %slot330, align 8
  %cmp2054 = icmp ne i64 %v2053, 0
  %cv2055 = zext i1 %cmp2054 to i32
  store i32 %cv2055, ptr %slot331, align 8
  %v2056 = load i32, ptr %slot331, align 8
  %cv2057 = zext i32 %v2056 to i64
  %cond2058 = icmp ne i64 %cv2057, 0
  br i1 %cond2058, label %bb_rcgclear405, label %bb_rcgcounted405
bb_rcgcounted405:
  %v2059 = load i64, ptr %slot326, align 8
  %op2060 = sub i64 %v2059, 32
  store i64 %op2060, ptr %slot332, align 8
  %v2061 = load i64, ptr %slot326, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %rgep2063 = getelementptr i8, ptr %p2062, i64 -32
  %ld2064 = load i64, ptr %rgep2063, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2064, ptr %slot333, align 8
  %v2065 = load i64, ptr %slot333, align 8
  %op2066 = sub i64 %v2065, 1
  store i64 %op2066, ptr %slot334, align 8
  %v2067 = load i64, ptr %slot334, align 8
  %cmp2068 = icmp eq i64 %v2067, 0
  %cv2069 = zext i1 %cmp2068 to i32
  store i32 %cv2069, ptr %slot335, align 8
  %v2070 = load i32, ptr %slot335, align 8
  %cv2071 = zext i32 %v2070 to i64
  %cond2072 = icmp ne i64 %cv2071, 0
  br i1 %cond2072, label %bb_rcglast405, label %bb_rcgdec405
bb_rcglast405:
  %v2073 = load i64, ptr %slot326, align 8
  %op2074 = sub i64 %v2073, 24
  store i64 %op2074, ptr %slot336, align 8
  %v2075 = load i64, ptr %slot326, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %rgep2077 = getelementptr i8, ptr %p2076, i64 -24
  %ld2078 = load i64, ptr %rgep2077, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2078, ptr %slot337, align 8
  %v2079 = load i64, ptr %slot337, align 8
  %cmp2080 = icmp ne i64 %v2079, 0
  %cv2081 = zext i1 %cmp2080 to i32
  store i32 %cv2081, ptr %slot338, align 8
  %v2082 = load i32, ptr %slot338, align 8
  %cv2083 = zext i32 %v2082 to i64
  %cond2084 = icmp ne i64 %cv2083, 0
  br i1 %cond2084, label %bb_rcgdec405, label %bb_rcgslow405
bb_rcgslow405:
  %v2085 = load i64, ptr %slot325, align 8
  %v2086 = load i64, ptr %slot324, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v2085, i64 %v2086) nomerge, !dbg !144
  br label %bb_rcgdone405
bb_rcgdec405:
  %v2087 = load i64, ptr %slot334, align 8
  %v2088 = load i64, ptr %slot326, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %rgep2090 = getelementptr i8, ptr %p2089, i64 -32
  store i64 %v2087, ptr %rgep2090, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear405
bb_rcgclear405:
  %v2091 = load i64, ptr %slot324, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  store i64 0, ptr %p2092, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone405
bb_rcgdone405:
  %v2093 = load i64, ptr %slot320, align 8
  %p2094 = inttoptr i64 %v2093 to ptr
  store i64 0, ptr %p2094, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone387
bb_rcslotdone387:
  br label %bb_rcprepared347
bb_rcprepared347:
  %v2095 = load i64, ptr %slot7, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  %ld2097 = load i32, ptr %p2096, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2097, ptr %slot339, align 8
  %v2098 = load i32, ptr %slot339, align 8
  %cv2099 = zext i32 %v2098 to i64
  %cond2100 = icmp ne i64 %cv2099, 0
  br i1 %cond2100, label %bb_rcslotdrop412, label %bb_rcslotdone412
bb_rcslotdrop412:
  %v2101 = load i64, ptr %slot7, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  store i32 0, ptr %p2102, align 4, !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot31, align 8
  store i64 %v2103, ptr %slot340, align 8
  %v2104 = load i64, ptr %slot8, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  %ld2106 = load i32, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2106, ptr %slot341, align 8
  %v2107 = load i32, ptr %slot341, align 8
  %op2108 = and i32 %v2107, 28
  store i32 %op2108, ptr %slot342, align 8
  %v2109 = load i32, ptr %slot342, align 8
  %cv2110 = zext i32 %v2109 to i64
  %cond2111 = icmp ne i64 %cv2110, 0
  br i1 %cond2111, label %bb_rcslotrole412, label %bb_rcslotowner412
bb_rcslotrole412:
  %v2112 = load i64, ptr %slot45, align 8
  store i64 %v2112, ptr %slot343, align 8
  %v2113 = load i64, ptr %slot343, align 8
  %v2114 = load i64, ptr %slot340, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_unloan(i64 %v2113, i64 %v2114) nomerge, !dbg !144
  br label %bb_rcslotdone412
bb_rcslotowner412:
  %v2115 = load i64, ptr %slot340, align 8
  %p2117 = inttoptr i64 %v2115 to ptr
  %gep2118 = getelementptr i8, ptr %p2117, i64 0
  %op2116 = ptrtoint ptr %gep2118 to i64
  store i64 %op2116, ptr %slot344, align 8
  %v2119 = load i64, ptr %slot45, align 8
  store i64 %v2119, ptr %slot345, align 8
  %v2120 = load i64, ptr %slot344, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  %ld2122 = load i64, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2122, ptr %slot346, align 8
  %v2123 = load i64, ptr %slot346, align 8
  %cmp2124 = icmp ne i64 %v2123, 0
  %cv2125 = zext i1 %cmp2124 to i32
  store i32 %cv2125, ptr %slot347, align 8
  %v2126 = load i32, ptr %slot347, align 8
  %cv2127 = zext i32 %v2126 to i64
  %cond2128 = icmp ne i64 %cv2127, 0
  br i1 %cond2128, label %bb_rcgnn430, label %bb_rcgdone430
bb_rcgnn430:
  %v2129 = load i64, ptr %slot346, align 8
  %op2130 = sub i64 %v2129, 16
  store i64 %op2130, ptr %slot348, align 8
  %v2131 = load i64, ptr %slot346, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  %rgep2133 = getelementptr i8, ptr %p2132, i64 -16
  %ld2134 = load i64, ptr %rgep2133, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2134, ptr %slot349, align 8
  %v2135 = load i64, ptr %slot349, align 8
  %op2136 = and i64 %v2135, 4611686018427387906
  store i64 %op2136, ptr %slot350, align 8
  %v2137 = load i64, ptr %slot350, align 8
  %cmp2138 = icmp ne i64 %v2137, 0
  %cv2139 = zext i1 %cmp2138 to i32
  store i32 %cv2139, ptr %slot351, align 8
  %v2140 = load i32, ptr %slot351, align 8
  %cv2141 = zext i32 %v2140 to i64
  %cond2142 = icmp ne i64 %cv2141, 0
  br i1 %cond2142, label %bb_rcgclear430, label %bb_rcgcounted430
bb_rcgcounted430:
  %v2143 = load i64, ptr %slot346, align 8
  %op2144 = sub i64 %v2143, 32
  store i64 %op2144, ptr %slot352, align 8
  %v2145 = load i64, ptr %slot346, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  %rgep2147 = getelementptr i8, ptr %p2146, i64 -32
  %ld2148 = load i64, ptr %rgep2147, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2148, ptr %slot353, align 8
  %v2149 = load i64, ptr %slot353, align 8
  %op2150 = sub i64 %v2149, 1
  store i64 %op2150, ptr %slot354, align 8
  %v2151 = load i64, ptr %slot354, align 8
  %cmp2152 = icmp eq i64 %v2151, 0
  %cv2153 = zext i1 %cmp2152 to i32
  store i32 %cv2153, ptr %slot355, align 8
  %v2154 = load i32, ptr %slot355, align 8
  %cv2155 = zext i32 %v2154 to i64
  %cond2156 = icmp ne i64 %cv2155, 0
  br i1 %cond2156, label %bb_rcglast430, label %bb_rcgdec430
bb_rcglast430:
  %v2157 = load i64, ptr %slot346, align 8
  %op2158 = sub i64 %v2157, 24
  store i64 %op2158, ptr %slot356, align 8
  %v2159 = load i64, ptr %slot346, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  %rgep2161 = getelementptr i8, ptr %p2160, i64 -24
  %ld2162 = load i64, ptr %rgep2161, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2162, ptr %slot357, align 8
  %v2163 = load i64, ptr %slot357, align 8
  %cmp2164 = icmp ne i64 %v2163, 0
  %cv2165 = zext i1 %cmp2164 to i32
  store i32 %cv2165, ptr %slot358, align 8
  %v2166 = load i32, ptr %slot358, align 8
  %cv2167 = zext i32 %v2166 to i64
  %cond2168 = icmp ne i64 %cv2167, 0
  br i1 %cond2168, label %bb_rcgdec430, label %bb_rcgslow430
bb_rcgslow430:
  %v2169 = load i64, ptr %slot345, align 8
  %v2170 = load i64, ptr %slot344, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v2169, i64 %v2170) nomerge, !dbg !144
  br label %bb_rcgdone430
bb_rcgdec430:
  %v2171 = load i64, ptr %slot354, align 8
  %v2172 = load i64, ptr %slot346, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  %rgep2174 = getelementptr i8, ptr %p2173, i64 -32
  store i64 %v2171, ptr %rgep2174, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear430
bb_rcgclear430:
  %v2175 = load i64, ptr %slot344, align 8
  %p2176 = inttoptr i64 %v2175 to ptr
  store i64 0, ptr %p2176, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone430
bb_rcgdone430:
  %v2177 = load i64, ptr %slot340, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  store i64 0, ptr %p2178, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone412
bb_rcslotdone412:
  %v2179 = load i64, ptr %slot31, align 8
  store i64 %v2179, ptr %slot359, align 8
  %v2180 = load i64, ptr %slot21, align 8
  store i64 %v2180, ptr %slot360, align 8
  %v2181 = load i64, ptr %slot360, align 8
  %v2182 = load i64, ptr %slot359, align 8
  %p2183 = inttoptr i64 %v2181 to ptr
  %p2184 = inttoptr i64 %v2182 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2184, ptr %p2183, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2185 = load i64, ptr %slot15, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  store i32 0, ptr %p2186, align 4, !alias.scope !3, !noalias !4
  %v2187 = load i64, ptr %slot8, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  store i32 2, ptr %p2188, align 4, !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot16, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  %ld2191 = load i32, ptr %p2190, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2191, ptr %slot361, align 8
  %v2192 = load i32, ptr %slot361, align 8
  %v2193 = load i64, ptr %slot8, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  store i32 %v2192, ptr %p2194, align 4, !alias.scope !3, !noalias !4
  %v2195 = load i64, ptr %slot7, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  store i32 1, ptr %p2196, align 4, !alias.scope !3, !noalias !4
  %v2197 = load i64, ptr %slot31, align 8
  %v2198 = load i64, ptr %slot35, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  store i64 %v2197, ptr %p2199, align 8, !alias.scope !3, !noalias !4
  %v2200 = load i64, ptr %slot26, align 8
  %v2201 = load i64, ptr %slot36, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  store i64 %v2200, ptr %p2202, align 8, !alias.scope !3, !noalias !4
  %v2203 = load i64, ptr %slot36, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  %ld2205 = load i64, ptr %p2204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2205, ptr %slot362, align 8
  %v2206 = load i64, ptr %slot362, align 8
  %op2207 = add i64 %v2206, 40
  store i64 %op2207, ptr %slot363, align 8
  %v2208 = load i64, ptr %slot363, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  %ld2210 = load i64, ptr %p2209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2210, ptr %slot364, align 8
  %v2211 = load i64, ptr %slot364, align 8
  %v2212 = load i64, ptr %slot36, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  store i64 %v2211, ptr %p2213, align 8, !alias.scope !3, !noalias !4
  %v2214 = load i64, ptr %slot35, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  %ld2216 = load i64, ptr %p2215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2216, ptr %slot365, align 8
  %v2217 = load i64, ptr %slot36, align 8
  %p2218 = inttoptr i64 %v2217 to ptr
  %ld2219 = load i64, ptr %p2218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2219, ptr %slot366, align 8
  %v2220 = load i64, ptr %slot1, align 8
  %v2221 = load i64, ptr %slot365, align 8
  %v2222 = load i64, ptr %slot366, align 8
  %call2223 = call i64 @myl_f_5af755ff39699d4050214e9fdc5e92b763fd42b47cc67a218a0ace498e9cdd61(i64 %v2220, i64 %v2221, i64 %v2222) nomerge, !dbg !146
  store i64 %call2223, ptr %slot367, align 8
  %v2224 = load i64, ptr %slot367, align 8
  %v2225 = load i64, ptr %slot35, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  store i64 %v2224, ptr %p2226, align 8, !alias.scope !3, !noalias !4
  %v2227 = load i64, ptr %slot11, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  %ld2229 = load i32, ptr %p2228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2229, ptr %slot368, align 8
  %v2230 = load i32, ptr %slot368, align 8
  %cv2231 = zext i32 %v2230 to i64
  %cond2232 = icmp ne i64 %cv2231, 0
  br i1 %cond2232, label %bb_rcslotdrop458, label %bb_rcslotdone458
bb_rcslotdrop458:
  %v2233 = load i64, ptr %slot11, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  store i32 0, ptr %p2234, align 4, !alias.scope !3, !noalias !4
  %v2235 = load i64, ptr %slot17, align 8
  store i64 %v2235, ptr %slot369, align 8
  %v2236 = load i64, ptr %slot12, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  %ld2238 = load i32, ptr %p2237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2238, ptr %slot370, align 8
  %v2239 = load i32, ptr %slot370, align 8
  %op2240 = and i32 %v2239, 28
  store i32 %op2240, ptr %slot371, align 8
  %v2241 = load i32, ptr %slot371, align 8
  %cv2242 = zext i32 %v2241 to i64
  %cond2243 = icmp ne i64 %cv2242, 0
  br i1 %cond2243, label %bb_rcslotrole458, label %bb_rcslotowner458
bb_rcslotrole458:
  %v2244 = load i64, ptr %slot45, align 8
  store i64 %v2244, ptr %slot372, align 8
  %v2245 = load i64, ptr %slot372, align 8
  %v2246 = load i64, ptr %slot369, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_unloan(i64 %v2245, i64 %v2246) nomerge, !dbg !146
  br label %bb_rcslotdone458
bb_rcslotowner458:
  %v2247 = load i64, ptr %slot45, align 8
  store i64 %v2247, ptr %slot373, align 8
  %v2248 = load i64, ptr %slot373, align 8
  %v2249 = load i64, ptr %slot369, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_drop(i64 %v2248, i64 %v2249) nomerge, !dbg !146
  br label %bb_rcslotdone458
bb_rcslotdone458:
  %v2250 = load i64, ptr %slot35, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %ld2252 = load i64, ptr %p2251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2252, ptr %slot374, align 8
  %v2253 = load i64, ptr %slot374, align 8
  %v2254 = load i64, ptr %slot32, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  store i64 %v2253, ptr %p2255, align 8, !alias.scope !3, !noalias !4
  %v2256 = load i64, ptr %slot32, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %ld2258 = load i64, ptr %p2257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2258, ptr %slot375, align 8
  %v2259 = load i64, ptr %slot375, align 8
  %v2260 = load i64, ptr %slot35, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  store i64 %v2259, ptr %p2261, align 8, !alias.scope !3, !noalias !4
  %v2262 = load i64, ptr %slot36, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  store i64 18446744073709551615, ptr %p2263, align 8, !alias.scope !3, !noalias !4
  %v2264 = load i64, ptr %slot36, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  %ld2266 = load i64, ptr %p2265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2266, ptr %slot376, align 8
  %v2267 = load i64, ptr %slot35, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %ld2269 = load i64, ptr %p2268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2269, ptr %slot377, align 8
  %v2270 = load i64, ptr %slot377, align 8
  %v2271 = load i64, ptr %slot376, align 8
  %cmp2272 = icmp ne i64 %v2270, %v2271
  %cv2273 = zext i1 %cmp2272 to i64
  store i64 %cv2273, ptr %slot378, align 8
  %v2274 = load i64, ptr %slot378, align 8
  %v2275 = load i64, ptr %slot35, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  store i64 %v2274, ptr %p2276, align 8, !alias.scope !3, !noalias !4
  %v2277 = load i64, ptr %slot35, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %ld2279 = load i64, ptr %p2278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2279, ptr %slot379, align 8
  %v2280 = load i64, ptr %slot379, align 8
  %cond2281 = icmp ne i64 %v2280, 0
  br i1 %cond2281, label %bb_next471, label %bb_i78
bb_next471:
  %v2282 = load i64, ptr %slot31, align 8
  %v2283 = load i64, ptr %slot35, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  store i64 %v2282, ptr %p2284, align 8, !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot35, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %ld2287 = load i64, ptr %p2286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2287, ptr %slot380, align 8
  %v2288 = load i64, ptr %slot380, align 8
  %op2289 = add i64 %v2288, 0
  store i64 %op2289, ptr %slot381, align 8
  %v2290 = load i64, ptr %slot381, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i64, ptr %p2291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2292, ptr %slot382, align 8
  %v2293 = load i64, ptr %slot382, align 8
  %v2294 = load i64, ptr %slot35, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i64 %v2293, ptr %p2295, align 8, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot35, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %ld2298 = load i64, ptr %p2297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2298, ptr %slot383, align 8
  %v2299 = load i64, ptr %slot383, align 8
  %v2300 = load i64, ptr %slot19, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  store i64 %v2299, ptr %p2301, align 8, !alias.scope !3, !noalias !4
  %v2302 = load i64, ptr %slot19, align 8
  store i64 %v2302, ptr %slot384, align 8
  %v2303 = load i64, ptr %slot21, align 8
  store i64 %v2303, ptr %slot385, align 8
  %v2304 = load i64, ptr %slot384, align 8
  %p2305 = inttoptr i64 %v2304 to ptr
  %ld2306 = load i64, ptr %p2305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2306, ptr %slot386, align 8
  %v2307 = load i64, ptr %slot386, align 8
  %cmp2308 = icmp ne i64 %v2307, 0
  %cv2309 = zext i1 %cmp2308 to i32
  store i32 %cv2309, ptr %slot387, align 8
  %v2310 = load i32, ptr %slot387, align 8
  %cv2311 = zext i32 %v2310 to i64
  %cond2312 = icmp ne i64 %cv2311, 0
  br i1 %cond2312, label %bb_rcgnn478, label %bb_rcgstore478
bb_rcgnn478:
  %v2313 = load i64, ptr %slot386, align 8
  %op2314 = sub i64 %v2313, 16
  store i64 %op2314, ptr %slot388, align 8
  %v2315 = load i64, ptr %slot386, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  %rgep2317 = getelementptr i8, ptr %p2316, i64 -16
  %ld2318 = load i64, ptr %rgep2317, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2318, ptr %slot389, align 8
  %v2319 = load i64, ptr %slot389, align 8
  %op2320 = and i64 %v2319, 4611686018427387906
  store i64 %op2320, ptr %slot390, align 8
  %v2321 = load i64, ptr %slot390, align 8
  %cmp2322 = icmp ne i64 %v2321, 0
  %cv2323 = zext i1 %cmp2322 to i32
  store i32 %cv2323, ptr %slot391, align 8
  %v2324 = load i32, ptr %slot391, align 8
  %cv2325 = zext i32 %v2324 to i64
  %cond2326 = icmp ne i64 %cv2325, 0
  br i1 %cond2326, label %bb_rcgstore478, label %bb_rcginc478
bb_rcginc478:
  %v2327 = load i64, ptr %slot386, align 8
  %op2328 = sub i64 %v2327, 24
  store i64 %op2328, ptr %slot392, align 8
  %v2329 = load i64, ptr %slot386, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  %rgep2331 = getelementptr i8, ptr %p2330, i64 -24
  %ld2332 = load i64, ptr %rgep2331, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2332, ptr %slot393, align 8
  %v2333 = load i64, ptr %slot393, align 8
  %op2334 = add i64 %v2333, 1
  store i64 %op2334, ptr %slot394, align 8
  %v2335 = load i64, ptr %slot394, align 8
  %cmp2336 = icmp eq i64 %v2335, 0
  %cv2337 = zext i1 %cmp2336 to i32
  store i32 %cv2337, ptr %slot395, align 8
  %v2338 = load i32, ptr %slot395, align 8
  %cv2339 = zext i32 %v2338 to i64
  %cond2340 = icmp ne i64 %cv2339, 0
  br i1 %cond2340, label %bb_rcglimit478, label %bb_rcgcapacity478
bb_rcglimit478:
  %v2341 = load i64, ptr %slot1, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  %call2343 = call i32 @myl_qbe_rc_status(ptr %p2342, i32 2) nomerge, !dbg !148
  store i32 %call2343, ptr %slot396, align 8
  br label %bb_failure
bb_rcgcapacity478:
  %v2344 = load i64, ptr %slot394, align 8
  %v2345 = load i64, ptr %slot386, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  %rgep2347 = getelementptr i8, ptr %p2346, i64 -24
  store i64 %v2344, ptr %rgep2347, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore478
bb_rcgstore478:
  %v2348 = load i64, ptr %slot386, align 8
  %v2349 = load i64, ptr %slot385, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 %v2348, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot16, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  store i32 2, ptr %p2352, align 4, !alias.scope !3, !noalias !4
  %v2353 = load i64, ptr %slot16, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  store i32 16, ptr %p2354, align 4, !alias.scope !3, !noalias !4
  %v2355 = load i64, ptr %slot15, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i32 1, ptr %p2356, align 4, !alias.scope !3, !noalias !4
  %v2357 = load i64, ptr %slot11, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %ld2359 = load i32, ptr %p2358, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2359, ptr %slot397, align 8
  %v2360 = load i32, ptr %slot397, align 8
  %cv2361 = zext i32 %v2360 to i64
  %cond2362 = icmp ne i64 %cv2361, 0
  br i1 %cond2362, label %bb_rcslotdrop494, label %bb_rcslotdone494
bb_rcslotdrop494:
  %v2363 = load i64, ptr %slot11, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  store i32 0, ptr %p2364, align 4, !alias.scope !3, !noalias !4
  %v2365 = load i64, ptr %slot17, align 8
  store i64 %v2365, ptr %slot398, align 8
  %v2366 = load i64, ptr %slot12, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  %ld2368 = load i32, ptr %p2367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2368, ptr %slot399, align 8
  %v2369 = load i32, ptr %slot399, align 8
  %op2370 = and i32 %v2369, 28
  store i32 %op2370, ptr %slot400, align 8
  %v2371 = load i32, ptr %slot400, align 8
  %cv2372 = zext i32 %v2371 to i64
  %cond2373 = icmp ne i64 %cv2372, 0
  br i1 %cond2373, label %bb_rcslotrole494, label %bb_rcslotowner494
bb_rcslotrole494:
  %v2374 = load i64, ptr %slot45, align 8
  store i64 %v2374, ptr %slot401, align 8
  %v2375 = load i64, ptr %slot401, align 8
  %v2376 = load i64, ptr %slot398, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_unloan(i64 %v2375, i64 %v2376) nomerge, !dbg !148
  br label %bb_rcslotdone494
bb_rcslotowner494:
  %v2377 = load i64, ptr %slot45, align 8
  store i64 %v2377, ptr %slot402, align 8
  %v2378 = load i64, ptr %slot402, align 8
  %v2379 = load i64, ptr %slot398, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_drop(i64 %v2378, i64 %v2379) nomerge, !dbg !148
  br label %bb_rcslotdone494
bb_rcslotdone494:
  %v2380 = load i64, ptr %slot17, align 8
  store i64 %v2380, ptr %slot403, align 8
  %v2381 = load i64, ptr %slot21, align 8
  store i64 %v2381, ptr %slot404, align 8
  %v2382 = load i64, ptr %slot404, align 8
  %v2383 = load i64, ptr %slot403, align 8
  %p2384 = inttoptr i64 %v2382 to ptr
  %p2385 = inttoptr i64 %v2383 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2385, ptr %p2384, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2386 = load i64, ptr %slot12, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  store i32 2, ptr %p2387, align 4, !alias.scope !3, !noalias !4
  %v2388 = load i64, ptr %slot16, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  %ld2390 = load i32, ptr %p2389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2390, ptr %slot405, align 8
  %v2391 = load i32, ptr %slot405, align 8
  %v2392 = load i64, ptr %slot12, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  store i32 %v2391, ptr %p2393, align 4, !alias.scope !3, !noalias !4
  %v2394 = load i64, ptr %slot15, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  store i32 0, ptr %p2395, align 4, !alias.scope !3, !noalias !4
  %v2396 = load i64, ptr %slot11, align 8
  %p2397 = inttoptr i64 %v2396 to ptr
  store i32 1, ptr %p2397, align 4, !alias.scope !3, !noalias !4
  %v2398 = load i64, ptr %slot403, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  %ld2400 = load i64, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2400, ptr %slot406, align 8
  %v2401 = load i64, ptr %slot406, align 8
  %v2402 = load i64, ptr %slot35, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  store i64 %v2401, ptr %p2403, align 8, !alias.scope !3, !noalias !4
  %v2404 = load i64, ptr %slot35, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  %ld2406 = load i64, ptr %p2405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2406, ptr %slot407, align 8
  %v2407 = load i64, ptr %slot407, align 8
  %v2408 = load i64, ptr %slot19, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  store i64 %v2407, ptr %p2409, align 8, !alias.scope !3, !noalias !4
  %v2410 = load i64, ptr %slot19, align 8
  store i64 %v2410, ptr %slot408, align 8
  %v2411 = load i64, ptr %slot11, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  %ld2413 = load i32, ptr %p2412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2413, ptr %slot409, align 8
  %v2414 = load i64, ptr %slot12, align 8
  %p2415 = inttoptr i64 %v2414 to ptr
  %ld2416 = load i32, ptr %p2415, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2416, ptr %slot410, align 8
  %v2417 = load i32, ptr %slot410, align 8
  %op2418 = and i32 %v2417, 24
  store i32 %op2418, ptr %slot410, align 8
  %v2419 = load i32, ptr %slot410, align 8
  %cmp2420 = icmp eq i32 %v2419, 0
  %cv2421 = zext i1 %cmp2420 to i32
  store i32 %cv2421, ptr %slot411, align 8
  %v2422 = load i32, ptr %slot409, align 8
  %v2423 = load i32, ptr %slot411, align 8
  %op2424 = and i32 %v2422, %v2423
  store i32 %op2424, ptr %slot412, align 8
  %v2425 = load i32, ptr %slot412, align 8
  %cv2426 = zext i32 %v2425 to i64
  %cond2427 = icmp ne i64 %cv2426, 0
  br i1 %cond2427, label %bb_rcprivateown518, label %bb_rcprivateloan518
bb_rcprivateown518:
  %v2428 = load i64, ptr %slot21, align 8
  store i64 %v2428, ptr %slot413, align 8
  %v2429 = load i64, ptr %slot46, align 8
  store i64 %v2429, ptr %slot414, align 8
  %v2430 = load i64, ptr %slot408, align 8
  %v2431 = load i64, ptr %slot413, align 8
  %op2432 = sub i64 %v2430, %v2431
  store i64 %op2432, ptr %slot415, align 8
  %v2433 = load i64, ptr %slot413, align 8
  %v2434 = load i64, ptr %slot408, align 8
  %op2435 = sub i64 %v2433, %v2434
  store i64 %op2435, ptr %slot416, align 8
  %v2436 = load i64, ptr %slot415, align 8
  %cmp2437 = icmp ult i64 %v2436, 8
  %cv2438 = zext i1 %cmp2437 to i32
  store i32 %cv2438, ptr %slot417, align 8
  %v2439 = load i64, ptr %slot416, align 8
  %cmp2440 = icmp ult i64 %v2439, 8
  %cv2441 = zext i1 %cmp2440 to i32
  store i32 %cv2441, ptr %slot418, align 8
  %v2442 = load i32, ptr %slot417, align 8
  %v2443 = load i32, ptr %slot418, align 8
  %op2444 = or i32 %v2442, %v2443
  store i32 %op2444, ptr %slot419, align 8
  %v2445 = load i32, ptr %slot419, align 8
  %cv2446 = zext i32 %v2445 to i64
  %cond2447 = icmp ne i64 %cv2446, 0
  br i1 %cond2447, label %bb_rcmoveslow521, label %bb_rcmovecheck521
bb_rcmovecheck521:
  %v2448 = load i64, ptr %slot408, align 8
  %p2450 = inttoptr i64 %v2448 to ptr
  %gep2451 = getelementptr i8, ptr %p2450, i64 0
  %op2449 = ptrtoint ptr %gep2451 to i64
  store i64 %op2449, ptr %slot420, align 8
  %v2452 = load i64, ptr %slot420, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  %ld2454 = load i64, ptr %p2453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2454, ptr %slot421, align 8
  %v2455 = load i64, ptr %slot421, align 8
  %cmp2456 = icmp ne i64 %v2455, 0
  %cv2457 = zext i1 %cmp2456 to i32
  store i32 %cv2457, ptr %slot422, align 8
  %v2458 = load i32, ptr %slot422, align 8
  %cv2459 = zext i32 %v2458 to i64
  %cond2460 = icmp ne i64 %cv2459, 0
  br i1 %cond2460, label %bb_rcmoveheader529, label %bb_rcmovenext529
bb_rcmoveheader529:
  %v2461 = load i64, ptr %slot421, align 8
  %op2462 = sub i64 %v2461, 16
  store i64 %op2462, ptr %slot423, align 8
  %v2463 = load i64, ptr %slot421, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  %rgep2465 = getelementptr i8, ptr %p2464, i64 -16
  %ld2466 = load i64, ptr %rgep2465, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2466, ptr %slot424, align 8
  %v2467 = load i64, ptr %slot424, align 8
  %op2468 = and i64 %v2467, 5764607523034234881
  store i64 %op2468, ptr %slot425, align 8
  %v2469 = load i64, ptr %slot425, align 8
  %cmp2470 = icmp ne i64 %v2469, 0
  %cv2471 = zext i1 %cmp2470 to i32
  store i32 %cv2471, ptr %slot426, align 8
  %v2472 = load i32, ptr %slot426, align 8
  %cv2473 = zext i32 %v2472 to i64
  %cond2474 = icmp ne i64 %cv2473, 0
  br i1 %cond2474, label %bb_rcmoveslow521, label %bb_rcmovenext529
bb_rcmovenext529:
  %v2475 = load i64, ptr %slot408, align 8
  %v2476 = load i64, ptr %slot413, align 8
  %p2477 = inttoptr i64 %v2475 to ptr
  %p2478 = inttoptr i64 %v2476 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2478, ptr %p2477, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2479 = load i64, ptr %slot408, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  store i64 0, ptr %p2480, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved521
bb_rcmoveslow521:
  %v2481 = load i64, ptr %slot45, align 8
  %v2482 = load i64, ptr %slot413, align 8
  %v2483 = load i64, ptr %slot408, align 8
  %v2484 = load i64, ptr %slot414, align 8
  %cv2485 = trunc i64 %v2484 to i32
  %call2486 = call i32 @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_take(i64 %v2481, i64 %v2482, i64 %v2483, i32 %cv2485) nomerge, !dbg !150
  store i32 %call2486, ptr %slot427, align 8
  %v2487 = load i32, ptr %slot427, align 8
  %cv2488 = zext i32 %v2487 to i64
  %cond2489 = icmp ne i64 %cv2488, 0
  br i1 %cond2489, label %bb_rcsuccess536, label %bb_rcfailure536
bb_rcfailure536:
  %v2490 = load i64, ptr %slot45, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  %call2492 = call i32 @myl_rc_take_failure(ptr %p2491) nomerge, !dbg !150
  store i32 %call2492, ptr %slot428, align 8
  %v2493 = load i64, ptr %slot1, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  %v2495 = load i32, ptr %slot428, align 8
  %call2496 = call i32 @myl_qbe_rc_status(ptr %p2494, i32 %v2495) nomerge, !dbg !150
  store i32 %call2496, ptr %slot429, align 8
  br label %bb_failure
bb_rcsuccess536:
  br label %bb_rcmoved521
bb_rcmoved521:
  %v2497 = load i64, ptr %slot11, align 8
  %p2498 = inttoptr i64 %v2497 to ptr
  store i32 0, ptr %p2498, align 4, !alias.scope !3, !noalias !4
  %v2499 = load i64, ptr %slot16, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  store i32 2, ptr %p2500, align 4, !alias.scope !3, !noalias !4
  %v2501 = load i64, ptr %slot15, align 8
  %p2502 = inttoptr i64 %v2501 to ptr
  store i32 1, ptr %p2502, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared518
bb_rcprivateloan518:
  %v2503 = load i64, ptr %slot11, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  %ld2505 = load i32, ptr %p2504, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2505, ptr %slot430, align 8
  %v2506 = load i64, ptr %slot12, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  %ld2508 = load i32, ptr %p2507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2508, ptr %slot431, align 8
  %v2509 = load i32, ptr %slot431, align 8
  %cmp2510 = icmp eq i32 %v2509, 16
  %cv2511 = zext i1 %cmp2510 to i32
  store i32 %cv2511, ptr %slot432, align 8
  %v2512 = load i32, ptr %slot432, align 8
  %v2513 = load i32, ptr %slot430, align 8
  %op2514 = and i32 %v2512, %v2513
  store i32 %op2514, ptr %slot432, align 8
  %v2515 = load i32, ptr %slot432, align 8
  %cv2516 = zext i32 %v2515 to i64
  %cond2517 = icmp ne i64 %cv2516, 0
  br i1 %cond2517, label %bb_rcprivatemove518, label %bb_rcprivatenew518
bb_rcprivatemove518:
  %v2518 = load i64, ptr %slot21, align 8
  store i64 %v2518, ptr %slot433, align 8
  %v2519 = load i64, ptr %slot408, align 8
  %v2520 = load i64, ptr %slot433, align 8
  %p2521 = inttoptr i64 %v2519 to ptr
  %p2522 = inttoptr i64 %v2520 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2522, ptr %p2521, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot408, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  store i64 0, ptr %p2524, align 8, !alias.scope !3, !noalias !4
  %v2525 = load i64, ptr %slot16, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  store i32 2, ptr %p2526, align 4, !alias.scope !3, !noalias !4
  %v2527 = load i64, ptr %slot16, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  store i32 16, ptr %p2528, align 4, !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot15, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  store i32 1, ptr %p2530, align 4, !alias.scope !3, !noalias !4
  %v2531 = load i64, ptr %slot11, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  store i32 0, ptr %p2532, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared518
bb_rcprivatenew518:
  %v2533 = load i64, ptr %slot21, align 8
  store i64 %v2533, ptr %slot434, align 8
  %v2534 = load i64, ptr %slot408, align 8
  %p2535 = inttoptr i64 %v2534 to ptr
  %ld2536 = load i64, ptr %p2535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2536, ptr %slot435, align 8
  %v2537 = load i64, ptr %slot435, align 8
  %cmp2538 = icmp ne i64 %v2537, 0
  %cv2539 = zext i1 %cmp2538 to i32
  store i32 %cv2539, ptr %slot436, align 8
  %v2540 = load i32, ptr %slot436, align 8
  %cv2541 = zext i32 %v2540 to i64
  %cond2542 = icmp ne i64 %cv2541, 0
  br i1 %cond2542, label %bb_rcgnn554, label %bb_rcgstore554
bb_rcgnn554:
  %v2543 = load i64, ptr %slot435, align 8
  %op2544 = sub i64 %v2543, 16
  store i64 %op2544, ptr %slot437, align 8
  %v2545 = load i64, ptr %slot435, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  %rgep2547 = getelementptr i8, ptr %p2546, i64 -16
  %ld2548 = load i64, ptr %rgep2547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2548, ptr %slot438, align 8
  %v2549 = load i64, ptr %slot438, align 8
  %op2550 = and i64 %v2549, 4611686018427387906
  store i64 %op2550, ptr %slot439, align 8
  %v2551 = load i64, ptr %slot439, align 8
  %cmp2552 = icmp ne i64 %v2551, 0
  %cv2553 = zext i1 %cmp2552 to i32
  store i32 %cv2553, ptr %slot440, align 8
  %v2554 = load i32, ptr %slot440, align 8
  %cv2555 = zext i32 %v2554 to i64
  %cond2556 = icmp ne i64 %cv2555, 0
  br i1 %cond2556, label %bb_rcgstore554, label %bb_rcginc554
bb_rcginc554:
  %v2557 = load i64, ptr %slot435, align 8
  %op2558 = sub i64 %v2557, 24
  store i64 %op2558, ptr %slot441, align 8
  %v2559 = load i64, ptr %slot435, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  %rgep2561 = getelementptr i8, ptr %p2560, i64 -24
  %ld2562 = load i64, ptr %rgep2561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2562, ptr %slot442, align 8
  %v2563 = load i64, ptr %slot442, align 8
  %op2564 = add i64 %v2563, 1
  store i64 %op2564, ptr %slot443, align 8
  %v2565 = load i64, ptr %slot443, align 8
  %cmp2566 = icmp eq i64 %v2565, 0
  %cv2567 = zext i1 %cmp2566 to i32
  store i32 %cv2567, ptr %slot444, align 8
  %v2568 = load i32, ptr %slot444, align 8
  %cv2569 = zext i32 %v2568 to i64
  %cond2570 = icmp ne i64 %cv2569, 0
  br i1 %cond2570, label %bb_rcglimit554, label %bb_rcgcapacity554
bb_rcglimit554:
  %v2571 = load i64, ptr %slot1, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  %call2573 = call i32 @myl_qbe_rc_status(ptr %p2572, i32 2) nomerge, !dbg !150
  store i32 %call2573, ptr %slot445, align 8
  br label %bb_failure
bb_rcgcapacity554:
  %v2574 = load i64, ptr %slot443, align 8
  %v2575 = load i64, ptr %slot435, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  %rgep2577 = getelementptr i8, ptr %p2576, i64 -24
  store i64 %v2574, ptr %rgep2577, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore554
bb_rcgstore554:
  %v2578 = load i64, ptr %slot435, align 8
  %v2579 = load i64, ptr %slot434, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  store i64 %v2578, ptr %p2580, align 8, !alias.scope !3, !noalias !4
  %v2581 = load i64, ptr %slot16, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i32 2, ptr %p2582, align 4, !alias.scope !3, !noalias !4
  %v2583 = load i64, ptr %slot16, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  store i32 16, ptr %p2584, align 4, !alias.scope !3, !noalias !4
  %v2585 = load i64, ptr %slot15, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  store i32 1, ptr %p2586, align 4, !alias.scope !3, !noalias !4
  %v2587 = load i64, ptr %slot11, align 8
  %p2588 = inttoptr i64 %v2587 to ptr
  %ld2589 = load i32, ptr %p2588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2589, ptr %slot446, align 8
  %v2590 = load i32, ptr %slot446, align 8
  %cv2591 = zext i32 %v2590 to i64
  %cond2592 = icmp ne i64 %cv2591, 0
  br i1 %cond2592, label %bb_rcslotdrop570, label %bb_rcslotdone570
bb_rcslotdrop570:
  %v2593 = load i64, ptr %slot11, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  store i32 0, ptr %p2594, align 4, !alias.scope !3, !noalias !4
  %v2595 = load i64, ptr %slot17, align 8
  store i64 %v2595, ptr %slot447, align 8
  %v2596 = load i64, ptr %slot12, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  %ld2598 = load i32, ptr %p2597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2598, ptr %slot448, align 8
  %v2599 = load i32, ptr %slot448, align 8
  %op2600 = and i32 %v2599, 28
  store i32 %op2600, ptr %slot449, align 8
  %v2601 = load i32, ptr %slot449, align 8
  %cv2602 = zext i32 %v2601 to i64
  %cond2603 = icmp ne i64 %cv2602, 0
  br i1 %cond2603, label %bb_rcslotrole570, label %bb_rcslotowner570
bb_rcslotrole570:
  %v2604 = load i64, ptr %slot45, align 8
  store i64 %v2604, ptr %slot450, align 8
  %v2605 = load i64, ptr %slot447, align 8
  %p2606 = inttoptr i64 %v2605 to ptr
  %ld2607 = load i64, ptr %p2606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2607, ptr %slot451, align 8
  %v2608 = load i64, ptr %slot451, align 8
  %cmp2609 = icmp ne i64 %v2608, 0
  %cv2610 = zext i1 %cmp2609 to i32
  store i32 %cv2610, ptr %slot452, align 8
  %v2611 = load i32, ptr %slot452, align 8
  %cv2612 = zext i32 %v2611 to i64
  %cond2613 = icmp ne i64 %cv2612, 0
  br i1 %cond2613, label %bb_rcgnn586, label %bb_rcgdone586
bb_rcgnn586:
  %v2614 = load i64, ptr %slot451, align 8
  %op2615 = sub i64 %v2614, 16
  store i64 %op2615, ptr %slot453, align 8
  %v2616 = load i64, ptr %slot451, align 8
  %p2617 = inttoptr i64 %v2616 to ptr
  %rgep2618 = getelementptr i8, ptr %p2617, i64 -16
  %ld2619 = load i64, ptr %rgep2618, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2619, ptr %slot454, align 8
  %v2620 = load i64, ptr %slot454, align 8
  %op2621 = and i64 %v2620, 4611686018427387906
  store i64 %op2621, ptr %slot455, align 8
  %v2622 = load i64, ptr %slot455, align 8
  %cmp2623 = icmp ne i64 %v2622, 0
  %cv2624 = zext i1 %cmp2623 to i32
  store i32 %cv2624, ptr %slot456, align 8
  %v2625 = load i32, ptr %slot456, align 8
  %cv2626 = zext i32 %v2625 to i64
  %cond2627 = icmp ne i64 %cv2626, 0
  br i1 %cond2627, label %bb_rcgclear586, label %bb_rcgcounted586
bb_rcgcounted586:
  %v2628 = load i64, ptr %slot451, align 8
  %op2629 = sub i64 %v2628, 24
  store i64 %op2629, ptr %slot457, align 8
  %v2630 = load i64, ptr %slot451, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  %rgep2632 = getelementptr i8, ptr %p2631, i64 -24
  %ld2633 = load i64, ptr %rgep2632, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2633, ptr %slot458, align 8
  %v2634 = load i64, ptr %slot458, align 8
  %op2635 = sub i64 %v2634, 1
  store i64 %op2635, ptr %slot459, align 8
  %v2636 = load i64, ptr %slot459, align 8
  %cmp2637 = icmp eq i64 %v2636, 0
  %cv2638 = zext i1 %cmp2637 to i32
  store i32 %cv2638, ptr %slot460, align 8
  %v2639 = load i32, ptr %slot460, align 8
  %cv2640 = zext i32 %v2639 to i64
  %cond2641 = icmp ne i64 %cv2640, 0
  br i1 %cond2641, label %bb_rcglast586, label %bb_rcgdec586
bb_rcglast586:
  %v2642 = load i64, ptr %slot451, align 8
  %op2643 = sub i64 %v2642, 32
  store i64 %op2643, ptr %slot461, align 8
  %v2644 = load i64, ptr %slot451, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  %rgep2646 = getelementptr i8, ptr %p2645, i64 -32
  %ld2647 = load i64, ptr %rgep2646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2647, ptr %slot462, align 8
  %v2648 = load i64, ptr %slot462, align 8
  %cmp2649 = icmp ne i64 %v2648, 0
  %cv2650 = zext i1 %cmp2649 to i32
  store i32 %cv2650, ptr %slot463, align 8
  %v2651 = load i32, ptr %slot463, align 8
  %cv2652 = zext i32 %v2651 to i64
  %cond2653 = icmp ne i64 %cv2652, 0
  br i1 %cond2653, label %bb_rcgdec586, label %bb_rcgslow586
bb_rcgslow586:
  %v2654 = load i64, ptr %slot450, align 8
  %v2655 = load i64, ptr %slot447, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64 %v2654, i64 %v2655) nomerge, !dbg !150
  br label %bb_rcgdone586
bb_rcgdec586:
  %v2656 = load i64, ptr %slot459, align 8
  %v2657 = load i64, ptr %slot451, align 8
  %p2658 = inttoptr i64 %v2657 to ptr
  %rgep2659 = getelementptr i8, ptr %p2658, i64 -24
  store i64 %v2656, ptr %rgep2659, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear586
bb_rcgclear586:
  %v2660 = load i64, ptr %slot447, align 8
  %p2661 = inttoptr i64 %v2660 to ptr
  store i64 0, ptr %p2661, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone586
bb_rcgdone586:
  br label %bb_rcslotdone570
bb_rcslotowner570:
  %v2662 = load i64, ptr %slot45, align 8
  store i64 %v2662, ptr %slot464, align 8
  %v2663 = load i64, ptr %slot447, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  %ld2665 = load i64, ptr %p2664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2665, ptr %slot465, align 8
  %v2666 = load i64, ptr %slot465, align 8
  %cmp2667 = icmp ne i64 %v2666, 0
  %cv2668 = zext i1 %cmp2667 to i32
  store i32 %cv2668, ptr %slot466, align 8
  %v2669 = load i32, ptr %slot466, align 8
  %cv2670 = zext i32 %v2669 to i64
  %cond2671 = icmp ne i64 %cv2670, 0
  br i1 %cond2671, label %bb_rcgnn601, label %bb_rcgdone601
bb_rcgnn601:
  %v2672 = load i64, ptr %slot465, align 8
  %op2673 = sub i64 %v2672, 16
  store i64 %op2673, ptr %slot467, align 8
  %v2674 = load i64, ptr %slot465, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  %rgep2676 = getelementptr i8, ptr %p2675, i64 -16
  %ld2677 = load i64, ptr %rgep2676, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2677, ptr %slot468, align 8
  %v2678 = load i64, ptr %slot468, align 8
  %op2679 = and i64 %v2678, 4611686018427387906
  store i64 %op2679, ptr %slot469, align 8
  %v2680 = load i64, ptr %slot469, align 8
  %cmp2681 = icmp ne i64 %v2680, 0
  %cv2682 = zext i1 %cmp2681 to i32
  store i32 %cv2682, ptr %slot470, align 8
  %v2683 = load i32, ptr %slot470, align 8
  %cv2684 = zext i32 %v2683 to i64
  %cond2685 = icmp ne i64 %cv2684, 0
  br i1 %cond2685, label %bb_rcgclear601, label %bb_rcgcounted601
bb_rcgcounted601:
  %v2686 = load i64, ptr %slot465, align 8
  %op2687 = sub i64 %v2686, 32
  store i64 %op2687, ptr %slot471, align 8
  %v2688 = load i64, ptr %slot465, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %rgep2690 = getelementptr i8, ptr %p2689, i64 -32
  %ld2691 = load i64, ptr %rgep2690, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2691, ptr %slot472, align 8
  %v2692 = load i64, ptr %slot472, align 8
  %op2693 = sub i64 %v2692, 1
  store i64 %op2693, ptr %slot473, align 8
  %v2694 = load i64, ptr %slot473, align 8
  %cmp2695 = icmp eq i64 %v2694, 0
  %cv2696 = zext i1 %cmp2695 to i32
  store i32 %cv2696, ptr %slot474, align 8
  %v2697 = load i32, ptr %slot474, align 8
  %cv2698 = zext i32 %v2697 to i64
  %cond2699 = icmp ne i64 %cv2698, 0
  br i1 %cond2699, label %bb_rcglast601, label %bb_rcgdec601
bb_rcglast601:
  %v2700 = load i64, ptr %slot465, align 8
  %op2701 = sub i64 %v2700, 24
  store i64 %op2701, ptr %slot475, align 8
  %v2702 = load i64, ptr %slot465, align 8
  %p2703 = inttoptr i64 %v2702 to ptr
  %rgep2704 = getelementptr i8, ptr %p2703, i64 -24
  %ld2705 = load i64, ptr %rgep2704, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2705, ptr %slot476, align 8
  %v2706 = load i64, ptr %slot476, align 8
  %cmp2707 = icmp ne i64 %v2706, 0
  %cv2708 = zext i1 %cmp2707 to i32
  store i32 %cv2708, ptr %slot477, align 8
  %v2709 = load i32, ptr %slot477, align 8
  %cv2710 = zext i32 %v2709 to i64
  %cond2711 = icmp ne i64 %cv2710, 0
  br i1 %cond2711, label %bb_rcgdec601, label %bb_rcgslow601
bb_rcgslow601:
  %v2712 = load i64, ptr %slot464, align 8
  %v2713 = load i64, ptr %slot447, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v2712, i64 %v2713) nomerge, !dbg !150
  br label %bb_rcgdone601
bb_rcgdec601:
  %v2714 = load i64, ptr %slot473, align 8
  %v2715 = load i64, ptr %slot465, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  %rgep2717 = getelementptr i8, ptr %p2716, i64 -32
  store i64 %v2714, ptr %rgep2717, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear601
bb_rcgclear601:
  %v2718 = load i64, ptr %slot447, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  store i64 0, ptr %p2719, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone601
bb_rcgdone601:
  br label %bb_rcslotdone570
bb_rcslotdone570:
  br label %bb_rcprivateprepared518
bb_rcprivateprepared518:
  %v2720 = load i64, ptr %slot9, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  %ld2722 = load i32, ptr %p2721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2722, ptr %slot478, align 8
  %v2723 = load i32, ptr %slot478, align 8
  %cv2724 = zext i32 %v2723 to i64
  %cond2725 = icmp ne i64 %cv2724, 0
  br i1 %cond2725, label %bb_rcslotdrop608, label %bb_rcslotdone608
bb_rcslotdrop608:
  %v2726 = load i64, ptr %slot9, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i32 0, ptr %p2727, align 4, !alias.scope !3, !noalias !4
  %v2728 = load i64, ptr %slot33, align 8
  store i64 %v2728, ptr %slot479, align 8
  %v2729 = load i64, ptr %slot10, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  %ld2731 = load i32, ptr %p2730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2731, ptr %slot480, align 8
  %v2732 = load i32, ptr %slot480, align 8
  %op2733 = and i32 %v2732, 28
  store i32 %op2733, ptr %slot481, align 8
  %v2734 = load i32, ptr %slot481, align 8
  %cv2735 = zext i32 %v2734 to i64
  %cond2736 = icmp ne i64 %cv2735, 0
  br i1 %cond2736, label %bb_rcslotrole608, label %bb_rcslotowner608
bb_rcslotrole608:
  %v2737 = load i64, ptr %slot45, align 8
  store i64 %v2737, ptr %slot482, align 8
  %v2738 = load i64, ptr %slot479, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %ld2740 = load i64, ptr %p2739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2740, ptr %slot483, align 8
  %v2741 = load i64, ptr %slot483, align 8
  %cmp2742 = icmp ne i64 %v2741, 0
  %cv2743 = zext i1 %cmp2742 to i32
  store i32 %cv2743, ptr %slot484, align 8
  %v2744 = load i32, ptr %slot484, align 8
  %cv2745 = zext i32 %v2744 to i64
  %cond2746 = icmp ne i64 %cv2745, 0
  br i1 %cond2746, label %bb_rcgnn624, label %bb_rcgdone624
bb_rcgnn624:
  %v2747 = load i64, ptr %slot483, align 8
  %op2748 = sub i64 %v2747, 16
  store i64 %op2748, ptr %slot485, align 8
  %v2749 = load i64, ptr %slot483, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  %rgep2751 = getelementptr i8, ptr %p2750, i64 -16
  %ld2752 = load i64, ptr %rgep2751, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2752, ptr %slot486, align 8
  %v2753 = load i64, ptr %slot486, align 8
  %op2754 = and i64 %v2753, 4611686018427387906
  store i64 %op2754, ptr %slot487, align 8
  %v2755 = load i64, ptr %slot487, align 8
  %cmp2756 = icmp ne i64 %v2755, 0
  %cv2757 = zext i1 %cmp2756 to i32
  store i32 %cv2757, ptr %slot488, align 8
  %v2758 = load i32, ptr %slot488, align 8
  %cv2759 = zext i32 %v2758 to i64
  %cond2760 = icmp ne i64 %cv2759, 0
  br i1 %cond2760, label %bb_rcgclear624, label %bb_rcgcounted624
bb_rcgcounted624:
  %v2761 = load i64, ptr %slot483, align 8
  %op2762 = sub i64 %v2761, 24
  store i64 %op2762, ptr %slot489, align 8
  %v2763 = load i64, ptr %slot483, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %rgep2765 = getelementptr i8, ptr %p2764, i64 -24
  %ld2766 = load i64, ptr %rgep2765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2766, ptr %slot490, align 8
  %v2767 = load i64, ptr %slot490, align 8
  %op2768 = sub i64 %v2767, 1
  store i64 %op2768, ptr %slot491, align 8
  %v2769 = load i64, ptr %slot491, align 8
  %cmp2770 = icmp eq i64 %v2769, 0
  %cv2771 = zext i1 %cmp2770 to i32
  store i32 %cv2771, ptr %slot492, align 8
  %v2772 = load i32, ptr %slot492, align 8
  %cv2773 = zext i32 %v2772 to i64
  %cond2774 = icmp ne i64 %cv2773, 0
  br i1 %cond2774, label %bb_rcglast624, label %bb_rcgdec624
bb_rcglast624:
  %v2775 = load i64, ptr %slot483, align 8
  %op2776 = sub i64 %v2775, 32
  store i64 %op2776, ptr %slot493, align 8
  %v2777 = load i64, ptr %slot483, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %rgep2779 = getelementptr i8, ptr %p2778, i64 -32
  %ld2780 = load i64, ptr %rgep2779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2780, ptr %slot494, align 8
  %v2781 = load i64, ptr %slot494, align 8
  %cmp2782 = icmp ne i64 %v2781, 0
  %cv2783 = zext i1 %cmp2782 to i32
  store i32 %cv2783, ptr %slot495, align 8
  %v2784 = load i32, ptr %slot495, align 8
  %cv2785 = zext i32 %v2784 to i64
  %cond2786 = icmp ne i64 %cv2785, 0
  br i1 %cond2786, label %bb_rcgdec624, label %bb_rcgslow624
bb_rcgslow624:
  %v2787 = load i64, ptr %slot482, align 8
  %v2788 = load i64, ptr %slot479, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64 %v2787, i64 %v2788) nomerge, !dbg !150
  br label %bb_rcgdone624
bb_rcgdec624:
  %v2789 = load i64, ptr %slot491, align 8
  %v2790 = load i64, ptr %slot483, align 8
  %p2791 = inttoptr i64 %v2790 to ptr
  %rgep2792 = getelementptr i8, ptr %p2791, i64 -24
  store i64 %v2789, ptr %rgep2792, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear624
bb_rcgclear624:
  %v2793 = load i64, ptr %slot479, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  store i64 0, ptr %p2794, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone624
bb_rcgdone624:
  br label %bb_rcslotdone608
bb_rcslotowner608:
  %v2795 = load i64, ptr %slot45, align 8
  store i64 %v2795, ptr %slot496, align 8
  %v2796 = load i64, ptr %slot479, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  %ld2798 = load i64, ptr %p2797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2798, ptr %slot497, align 8
  %v2799 = load i64, ptr %slot497, align 8
  %cmp2800 = icmp ne i64 %v2799, 0
  %cv2801 = zext i1 %cmp2800 to i32
  store i32 %cv2801, ptr %slot498, align 8
  %v2802 = load i32, ptr %slot498, align 8
  %cv2803 = zext i32 %v2802 to i64
  %cond2804 = icmp ne i64 %cv2803, 0
  br i1 %cond2804, label %bb_rcgnn639, label %bb_rcgdone639
bb_rcgnn639:
  %v2805 = load i64, ptr %slot497, align 8
  %op2806 = sub i64 %v2805, 16
  store i64 %op2806, ptr %slot499, align 8
  %v2807 = load i64, ptr %slot497, align 8
  %p2808 = inttoptr i64 %v2807 to ptr
  %rgep2809 = getelementptr i8, ptr %p2808, i64 -16
  %ld2810 = load i64, ptr %rgep2809, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2810, ptr %slot500, align 8
  %v2811 = load i64, ptr %slot500, align 8
  %op2812 = and i64 %v2811, 4611686018427387906
  store i64 %op2812, ptr %slot501, align 8
  %v2813 = load i64, ptr %slot501, align 8
  %cmp2814 = icmp ne i64 %v2813, 0
  %cv2815 = zext i1 %cmp2814 to i32
  store i32 %cv2815, ptr %slot502, align 8
  %v2816 = load i32, ptr %slot502, align 8
  %cv2817 = zext i32 %v2816 to i64
  %cond2818 = icmp ne i64 %cv2817, 0
  br i1 %cond2818, label %bb_rcgclear639, label %bb_rcgcounted639
bb_rcgcounted639:
  %v2819 = load i64, ptr %slot497, align 8
  %op2820 = sub i64 %v2819, 32
  store i64 %op2820, ptr %slot503, align 8
  %v2821 = load i64, ptr %slot497, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  %rgep2823 = getelementptr i8, ptr %p2822, i64 -32
  %ld2824 = load i64, ptr %rgep2823, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2824, ptr %slot504, align 8
  %v2825 = load i64, ptr %slot504, align 8
  %op2826 = sub i64 %v2825, 1
  store i64 %op2826, ptr %slot505, align 8
  %v2827 = load i64, ptr %slot505, align 8
  %cmp2828 = icmp eq i64 %v2827, 0
  %cv2829 = zext i1 %cmp2828 to i32
  store i32 %cv2829, ptr %slot506, align 8
  %v2830 = load i32, ptr %slot506, align 8
  %cv2831 = zext i32 %v2830 to i64
  %cond2832 = icmp ne i64 %cv2831, 0
  br i1 %cond2832, label %bb_rcglast639, label %bb_rcgdec639
bb_rcglast639:
  %v2833 = load i64, ptr %slot497, align 8
  %op2834 = sub i64 %v2833, 24
  store i64 %op2834, ptr %slot507, align 8
  %v2835 = load i64, ptr %slot497, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  %rgep2837 = getelementptr i8, ptr %p2836, i64 -24
  %ld2838 = load i64, ptr %rgep2837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2838, ptr %slot508, align 8
  %v2839 = load i64, ptr %slot508, align 8
  %cmp2840 = icmp ne i64 %v2839, 0
  %cv2841 = zext i1 %cmp2840 to i32
  store i32 %cv2841, ptr %slot509, align 8
  %v2842 = load i32, ptr %slot509, align 8
  %cv2843 = zext i32 %v2842 to i64
  %cond2844 = icmp ne i64 %cv2843, 0
  br i1 %cond2844, label %bb_rcgdec639, label %bb_rcgslow639
bb_rcgslow639:
  %v2845 = load i64, ptr %slot496, align 8
  %v2846 = load i64, ptr %slot479, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v2845, i64 %v2846) nomerge, !dbg !150
  br label %bb_rcgdone639
bb_rcgdec639:
  %v2847 = load i64, ptr %slot505, align 8
  %v2848 = load i64, ptr %slot497, align 8
  %p2849 = inttoptr i64 %v2848 to ptr
  %rgep2850 = getelementptr i8, ptr %p2849, i64 -32
  store i64 %v2847, ptr %rgep2850, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear639
bb_rcgclear639:
  %v2851 = load i64, ptr %slot479, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  store i64 0, ptr %p2852, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone639
bb_rcgdone639:
  br label %bb_rcslotdone608
bb_rcslotdone608:
  %v2853 = load i64, ptr %slot33, align 8
  store i64 %v2853, ptr %slot510, align 8
  %v2854 = load i64, ptr %slot21, align 8
  store i64 %v2854, ptr %slot511, align 8
  %v2855 = load i64, ptr %slot511, align 8
  %v2856 = load i64, ptr %slot510, align 8
  %p2857 = inttoptr i64 %v2855 to ptr
  %p2858 = inttoptr i64 %v2856 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2858, ptr %p2857, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2859 = load i64, ptr %slot15, align 8
  %p2860 = inttoptr i64 %v2859 to ptr
  store i32 0, ptr %p2860, align 4, !alias.scope !3, !noalias !4
  %v2861 = load i64, ptr %slot10, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  store i32 2, ptr %p2862, align 4, !alias.scope !3, !noalias !4
  %v2863 = load i64, ptr %slot16, align 8
  %p2864 = inttoptr i64 %v2863 to ptr
  %ld2865 = load i32, ptr %p2864, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2865, ptr %slot512, align 8
  %v2866 = load i32, ptr %slot512, align 8
  %v2867 = load i64, ptr %slot10, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  store i32 %v2866, ptr %p2868, align 4, !alias.scope !3, !noalias !4
  %v2869 = load i64, ptr %slot9, align 8
  %p2870 = inttoptr i64 %v2869 to ptr
  store i32 1, ptr %p2870, align 4, !alias.scope !3, !noalias !4
  %v2871 = load i64, ptr %slot32, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  %ld2873 = load i64, ptr %p2872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2873, ptr %slot513, align 8
  %v2874 = load i64, ptr %slot513, align 8
  %v2875 = load i64, ptr %slot35, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  store i64 %v2874, ptr %p2876, align 8, !alias.scope !3, !noalias !4
  %v2877 = load i64, ptr %slot35, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %ld2879 = load i64, ptr %p2878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2879, ptr %slot514, align 8
  %v2880 = load i64, ptr %slot514, align 8
  %v2881 = load i64, ptr %slot34, align 8
  %p2882 = inttoptr i64 %v2881 to ptr
  store i64 %v2880, ptr %p2882, align 8, !alias.scope !3, !noalias !4
  %v2883 = load i64, ptr %slot34, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  %ld2885 = load i64, ptr %p2884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2885, ptr %slot515, align 8
  %v2886 = load i64, ptr %slot515, align 8
  %v2887 = load i64, ptr %slot35, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  store i64 %v2886, ptr %p2888, align 8, !alias.scope !3, !noalias !4
  %v2889 = load i64, ptr %slot36, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  store i64 0, ptr %p2890, align 8, !alias.scope !3, !noalias !4
  %v2891 = load i64, ptr %slot36, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  %ld2893 = load i64, ptr %p2892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2893, ptr %slot516, align 8
  %v2894 = load i64, ptr %slot35, align 8
  %p2895 = inttoptr i64 %v2894 to ptr
  %ld2896 = load i64, ptr %p2895, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2896, ptr %slot517, align 8
  %v2897 = load i64, ptr %slot517, align 8
  %v2898 = load i64, ptr %slot516, align 8
  %cmp2899 = icmp slt i64 %v2897, %v2898
  %cv2900 = zext i1 %cmp2899 to i64
  store i64 %cv2900, ptr %slot518, align 8
  %v2901 = load i64, ptr %slot518, align 8
  %v2902 = load i64, ptr %slot35, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  store i64 %v2901, ptr %p2903, align 8, !alias.scope !3, !noalias !4
  %v2904 = load i64, ptr %slot35, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  %ld2906 = load i64, ptr %p2905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2906, ptr %slot519, align 8
  %v2907 = load i64, ptr %slot519, align 8
  %cond2908 = icmp ne i64 %v2907, 0
  br i1 %cond2908, label %bb_next657, label %bb_i73
bb_next657:
  %v2909 = load i64, ptr %slot33, align 8
  %p2910 = inttoptr i64 %v2909 to ptr
  %ld2911 = load i64, ptr %p2910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2911, ptr %slot520, align 8
  %v2912 = load i64, ptr %slot520, align 8
  %op2913 = add i64 %v2912, 0
  store i64 %op2913, ptr %slot521, align 8
  %v2914 = load i64, ptr %slot521, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  %ld2916 = load i64, ptr %p2915, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2916, ptr %slot522, align 8
  %v2917 = load i64, ptr %slot522, align 8
  %v2918 = load i64, ptr %slot35, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  store i64 %v2917, ptr %p2919, align 8, !alias.scope !3, !noalias !4
  %v2920 = load i64, ptr %slot35, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  %ld2922 = load i64, ptr %p2921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2922, ptr %slot523, align 8
  %v2923 = load i64, ptr %slot523, align 8
  %cmp2924 = icmp ugt i64 %v2923, 9223372036854775807
  %cv2925 = zext i1 %cmp2924 to i64
  store i64 %cv2925, ptr %slot524, align 8
  %v2926 = load i64, ptr %slot524, align 8
  %cond2927 = icmp ne i64 %v2926, 0
  br i1 %cond2927, label %bb_cast_overflow662, label %bb_cast_ok662
bb_cast_overflow662:
  %v2928 = load i64, ptr %slot1, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  %v2930 = load i64, ptr %slot523, align 8
  call void @myl_qbe_fail_cast(ptr %p2929, i64 %v2930, i64 320) nomerge, !dbg !152
  unreachable
bb_cast_ok662:
  %v2931 = load i64, ptr %slot523, align 8
  %v2932 = load i64, ptr %slot35, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  store i64 %v2931, ptr %p2933, align 8, !alias.scope !3, !noalias !4
  %v2934 = load i64, ptr %slot34, align 8
  %p2935 = inttoptr i64 %v2934 to ptr
  %ld2936 = load i64, ptr %p2935, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2936, ptr %slot525, align 8
  %v2937 = load i64, ptr %slot525, align 8
  %v2938 = load i64, ptr %slot36, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  store i64 %v2937, ptr %p2939, align 8, !alias.scope !3, !noalias !4
  %v2940 = load i64, ptr %slot36, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  %ld2942 = load i64, ptr %p2941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2942, ptr %slot526, align 8
  %v2943 = load i64, ptr %slot35, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  %ld2945 = load i64, ptr %p2944, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2945, ptr %slot527, align 8
  %v2946 = load i64, ptr %slot527, align 8
  %v2947 = load i64, ptr %slot526, align 8
  %ovpair2949 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2946, i64 %v2947)
  %op2948 = extractvalue { i64, i1 } %ovpair2949, 0
  %ov2950 = extractvalue { i64, i1 } %ovpair2949, 1
  store i64 %op2948, ptr %slot528, align 8
  %v2951 = load i64, ptr %slot527, align 8
  %v2952 = load i64, ptr %slot528, align 8
  %op2953 = xor i64 %v2951, %v2952
  store i64 %op2953, ptr %slot529, align 8
  %v2954 = load i64, ptr %slot526, align 8
  %v2955 = load i64, ptr %slot528, align 8
  %op2956 = xor i64 %v2954, %v2955
  store i64 %op2956, ptr %slot530, align 8
  %v2957 = load i64, ptr %slot529, align 8
  %v2958 = load i64, ptr %slot530, align 8
  %op2959 = and i64 %v2957, %v2958
  store i64 %op2959, ptr %slot531, align 8
  %cv2960 = zext i1 %ov2950 to i64
  store i64 %cv2960, ptr %slot532, align 8
  %v2961 = load i64, ptr %slot532, align 8
  %cond2962 = icmp ne i64 %v2961, 0
  br i1 %cond2962, label %bb_overflow666, label %bb_checked666
bb_overflow666:
  %v2963 = load i64, ptr %slot1, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  %v2965 = load i64, ptr %slot527, align 8
  %v2966 = load i64, ptr %slot526, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2964, i64 0, i64 %v2965, i64 %v2966, i64 64) nomerge, !dbg !154
  unreachable
bb_checked666:
  %v2967 = load i64, ptr %slot528, align 8
  %v2968 = load i64, ptr %slot35, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  store i64 %v2967, ptr %p2969, align 8, !alias.scope !3, !noalias !4
  %v2970 = load i64, ptr %slot35, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  %ld2972 = load i64, ptr %p2971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2972, ptr %slot533, align 8
  %v2973 = load i64, ptr %slot533, align 8
  %v2974 = load i64, ptr %slot34, align 8
  %p2975 = inttoptr i64 %v2974 to ptr
  store i64 %v2973, ptr %p2975, align 8, !alias.scope !3, !noalias !4
  br label %bb_i73
bb_i73:
  %v2976 = load i64, ptr %slot34, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  %ld2978 = load i64, ptr %p2977, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2978, ptr %slot534, align 8
  %v2979 = load i64, ptr %slot534, align 8
  %v2980 = load i64, ptr %slot35, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  store i64 %v2979, ptr %p2981, align 8, !alias.scope !3, !noalias !4
  %v2982 = load i64, ptr %slot33, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  %ld2984 = load i64, ptr %p2983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2984, ptr %slot535, align 8
  %v2985 = load i64, ptr %slot35, align 8
  %p2986 = inttoptr i64 %v2985 to ptr
  %ld2987 = load i64, ptr %p2986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2987, ptr %slot536, align 8
  %v2988 = load i64, ptr %slot535, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  %ld2990 = load i64, ptr %p2989, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2990, ptr %slot537, align 8
  %v2991 = load i64, ptr %slot536, align 8
  %v2992 = load i64, ptr %slot537, align 8
  %cmp2993 = icmp ult i64 %v2991, %v2992
  %cv2994 = zext i1 %cmp2993 to i64
  store i64 %cv2994, ptr %slot538, align 8
  %v2995 = load i64, ptr %slot538, align 8
  %cond2996 = icmp ne i64 %v2995, 0
  br i1 %cond2996, label %bb_success678, label %bb_failed678
bb_failed678:
  %v2997 = load i64, ptr %slot1, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  %v2999 = load i64, ptr %slot536, align 8
  %v3000 = load i64, ptr %slot537, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2998, i64 %v2999, i64 %v3000) nomerge, !dbg !156
  unreachable
bb_success678:
  %v3001 = load i64, ptr %slot535, align 8
  %op3002 = add i64 %v3001, 32
  store i64 %op3002, ptr %slot539, align 8
  %v3003 = load i64, ptr %slot539, align 8
  %p3004 = inttoptr i64 %v3003 to ptr
  %ld3005 = load i64, ptr %p3004, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3005, ptr %slot540, align 8
  %v3006 = load i64, ptr %slot536, align 8
  %op3007 = mul i64 %v3006, 24
  store i64 %op3007, ptr %slot541, align 8
  %v3008 = load i64, ptr %slot540, align 8
  %v3009 = load i64, ptr %slot541, align 8
  %op3010 = add i64 %v3008, %v3009
  store i64 %op3010, ptr %slot542, align 8
  %v3011 = load i64, ptr %slot542, align 8
  %v3012 = load i64, ptr %slot35, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  store i64 %v3011, ptr %p3013, align 8, !alias.scope !3, !noalias !4
  %v3014 = load i64, ptr %slot35, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  %ld3016 = load i64, ptr %p3015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3016, ptr %slot543, align 8
  %v3017 = load i64, ptr %slot543, align 8
  %op3018 = add i64 %v3017, 8
  store i64 %op3018, ptr %slot544, align 8
  %v3019 = load i64, ptr %slot544, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %ld3021 = load i8, ptr %p3020, align 1, !alias.scope !15, !noalias !16
  %ext3022 = zext i8 %ld3021 to i64
  store i64 %ext3022, ptr %slot545, align 8
  %v3023 = load i64, ptr %slot545, align 8
  %v3024 = load i64, ptr %slot35, align 8
  %p3025 = inttoptr i64 %v3024 to ptr
  store i64 %v3023, ptr %p3025, align 8, !alias.scope !3, !noalias !4
  %v3026 = load i64, ptr %slot35, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %ld3028 = load i64, ptr %p3027, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3028, ptr %slot546, align 8
  %v3029 = load i64, ptr %slot546, align 8
  %op3030 = xor i64 %v3029, 1
  store i64 %op3030, ptr %slot547, align 8
  %v3031 = load i64, ptr %slot547, align 8
  %v3032 = load i64, ptr %slot35, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  store i64 %v3031, ptr %p3033, align 8, !alias.scope !3, !noalias !4
  br label %bb_i79
bb_i78:
  %v3034 = load i64, ptr %slot35, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  store i64 0, ptr %p3035, align 8, !alias.scope !3, !noalias !4
  br label %bb_i79
bb_i79:
  %v3036 = load i64, ptr %slot35, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  %ld3038 = load i64, ptr %p3037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3038, ptr %slot548, align 8
  %v3039 = load i64, ptr %slot548, align 8
  %cond3040 = icmp ne i64 %v3039, 0
  br i1 %cond3040, label %bb_next689, label %bb_i93
bb_next689:
  %v3041 = load i64, ptr %slot22, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  %ld3043 = load i64, ptr %p3042, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3043, ptr %slot549, align 8
  %v3044 = load i64, ptr %slot549, align 8
  %v3045 = load i64, ptr %slot35, align 8
  %p3046 = inttoptr i64 %v3045 to ptr
  store i64 %v3044, ptr %p3046, align 8, !alias.scope !3, !noalias !4
  %v3047 = load i64, ptr %slot26, align 8
  %v3048 = load i64, ptr %slot36, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  store i64 %v3047, ptr %p3049, align 8, !alias.scope !3, !noalias !4
  %v3050 = load i64, ptr %slot36, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %ld3052 = load i64, ptr %p3051, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3052, ptr %slot550, align 8
  %v3053 = load i64, ptr %slot550, align 8
  %op3054 = add i64 %v3053, 0
  store i64 %op3054, ptr %slot551, align 8
  %v3055 = load i64, ptr %slot551, align 8
  %v3056 = load i64, ptr %slot36, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i64 %v3055, ptr %p3057, align 8, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot36, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  %ld3060 = load i64, ptr %p3059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3060, ptr %slot552, align 8
  %v3061 = load i64, ptr %slot552, align 8
  %op3062 = add i64 %v3061, 24
  store i64 %op3062, ptr %slot553, align 8
  %v3063 = load i64, ptr %slot553, align 8
  %p3064 = inttoptr i64 %v3063 to ptr
  %ld3065 = load i64, ptr %p3064, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3065, ptr %slot554, align 8
  %v3066 = load i64, ptr %slot554, align 8
  %v3067 = load i64, ptr %slot36, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  store i64 %v3066, ptr %p3068, align 8, !alias.scope !3, !noalias !4
  %v3069 = load i64, ptr %slot26, align 8
  %v3070 = load i64, ptr %slot37, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  store i64 %v3069, ptr %p3071, align 8, !alias.scope !3, !noalias !4
  %v3072 = load i64, ptr %slot37, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  %ld3074 = load i64, ptr %p3073, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3074, ptr %slot555, align 8
  %v3075 = load i64, ptr %slot555, align 8
  %op3076 = add i64 %v3075, 0
  store i64 %op3076, ptr %slot556, align 8
  %v3077 = load i64, ptr %slot556, align 8
  %v3078 = load i64, ptr %slot37, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  store i64 %v3077, ptr %p3079, align 8, !alias.scope !3, !noalias !4
  %v3080 = load i64, ptr %slot37, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  %ld3082 = load i64, ptr %p3081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3082, ptr %slot557, align 8
  %v3083 = load i64, ptr %slot557, align 8
  %op3084 = add i64 %v3083, 8
  store i64 %op3084, ptr %slot558, align 8
  %v3085 = load i64, ptr %slot558, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  %ld3087 = load i64, ptr %p3086, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3087, ptr %slot559, align 8
  %v3088 = load i64, ptr %slot559, align 8
  %v3089 = load i64, ptr %slot37, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  store i64 %v3088, ptr %p3090, align 8, !alias.scope !3, !noalias !4
  %v3091 = load i64, ptr %slot26, align 8
  %v3092 = load i64, ptr %slot38, align 8
  %p3093 = inttoptr i64 %v3092 to ptr
  store i64 %v3091, ptr %p3093, align 8, !alias.scope !3, !noalias !4
  %v3094 = load i64, ptr %slot38, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  %ld3096 = load i64, ptr %p3095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3096, ptr %slot560, align 8
  %v3097 = load i64, ptr %slot560, align 8
  %op3098 = add i64 %v3097, 0
  store i64 %op3098, ptr %slot561, align 8
  %v3099 = load i64, ptr %slot561, align 8
  %v3100 = load i64, ptr %slot38, align 8
  %p3101 = inttoptr i64 %v3100 to ptr
  store i64 %v3099, ptr %p3101, align 8, !alias.scope !3, !noalias !4
  %v3102 = load i64, ptr %slot38, align 8
  %p3103 = inttoptr i64 %v3102 to ptr
  %ld3104 = load i64, ptr %p3103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3104, ptr %slot562, align 8
  %v3105 = load i64, ptr %slot562, align 8
  %op3106 = add i64 %v3105, 16
  store i64 %op3106, ptr %slot563, align 8
  %v3107 = load i64, ptr %slot563, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  %ld3109 = load i64, ptr %p3108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3109, ptr %slot564, align 8
  %v3110 = load i64, ptr %slot564, align 8
  %v3111 = load i64, ptr %slot38, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  store i64 %v3110, ptr %p3112, align 8, !alias.scope !3, !noalias !4
  %p3113 = inttoptr i64 ptrtoint (ptr @myl_lit_caa7b3678bda3862ff5f83bbb6e47ad1ac08ca1a57df8898f6139dcbfc186bd8 to i64) to ptr
  %ld3114 = load i64, ptr %p3113, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3114, ptr %slot565, align 8
  %v3115 = load i64, ptr %slot565, align 8
  %v3116 = load i64, ptr %slot39, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  store i64 %v3115, ptr %p3117, align 8, !alias.scope !3, !noalias !4
  %v3118 = load i64, ptr %slot39, align 8
  %p3119 = inttoptr i64 %v3118 to ptr
  %ld3120 = load i64, ptr %p3119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3120, ptr %slot566, align 8
  %v3121 = load i64, ptr %slot566, align 8
  %v3122 = load i64, ptr %slot20, align 8
  %p3123 = inttoptr i64 %v3122 to ptr
  store i64 %v3121, ptr %p3123, align 8, !alias.scope !3, !noalias !4
  %v3124 = load i64, ptr %slot20, align 8
  store i64 %v3124, ptr %slot567, align 8
  %v3125 = load i64, ptr %slot21, align 8
  store i64 %v3125, ptr %slot568, align 8
  %v3126 = load i64, ptr %slot567, align 8
  %v3127 = load i64, ptr %slot568, align 8
  %p3128 = inttoptr i64 %v3126 to ptr
  %p3129 = inttoptr i64 %v3127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3129, ptr %p3128, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3130 = load i64, ptr %slot16, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  store i32 2, ptr %p3131, align 4, !alias.scope !3, !noalias !4
  %v3132 = load i64, ptr %slot15, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  store i32 1, ptr %p3133, align 4, !alias.scope !3, !noalias !4
  %v3134 = load i64, ptr %slot18, align 8
  store i64 %v3134, ptr %slot569, align 8
  %v3135 = load i64, ptr %slot21, align 8
  store i64 %v3135, ptr %slot570, align 8
  %v3136 = load i64, ptr %slot570, align 8
  %v3137 = load i64, ptr %slot569, align 8
  %p3138 = inttoptr i64 %v3136 to ptr
  %p3139 = inttoptr i64 %v3137 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3139, ptr %p3138, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3140 = load i64, ptr %slot14, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  store i32 2, ptr %p3141, align 4, !alias.scope !3, !noalias !4
  %v3142 = load i64, ptr %slot16, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %ld3144 = load i32, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3144, ptr %slot571, align 8
  %v3145 = load i32, ptr %slot571, align 8
  %v3146 = load i64, ptr %slot14, align 8
  %p3147 = inttoptr i64 %v3146 to ptr
  store i32 %v3145, ptr %p3147, align 4, !alias.scope !3, !noalias !4
  %v3148 = load i64, ptr %slot15, align 8
  %p3149 = inttoptr i64 %v3148 to ptr
  store i32 0, ptr %p3149, align 4, !alias.scope !3, !noalias !4
  %v3150 = load i64, ptr %slot13, align 8
  %p3151 = inttoptr i64 %v3150 to ptr
  store i32 1, ptr %p3151, align 4, !alias.scope !3, !noalias !4
  %v3152 = load i64, ptr %slot569, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  %ld3154 = load i64, ptr %p3153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3154, ptr %slot572, align 8
  %v3155 = load i64, ptr %slot572, align 8
  %v3156 = load i64, ptr %slot39, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  store i64 %v3155, ptr %p3157, align 8, !alias.scope !3, !noalias !4
  %v3158 = load i64, ptr %slot35, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  %ld3160 = load i64, ptr %p3159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3160, ptr %slot573, align 8
  %v3161 = load i64, ptr %slot36, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  %ld3163 = load i64, ptr %p3162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3163, ptr %slot574, align 8
  %v3164 = load i64, ptr %slot37, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  %ld3166 = load i64, ptr %p3165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3166, ptr %slot575, align 8
  %v3167 = load i64, ptr %slot38, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  %ld3169 = load i64, ptr %p3168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3169, ptr %slot576, align 8
  %v3170 = load i64, ptr %slot39, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  %ld3172 = load i64, ptr %p3171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3172, ptr %slot577, align 8
  %v3173 = load i64, ptr %slot1, align 8
  %v3174 = load i64, ptr %slot573, align 8
  %v3175 = load i64, ptr %slot574, align 8
  %v3176 = load i64, ptr %slot575, align 8
  %v3177 = load i64, ptr %slot576, align 8
  %v3178 = load i64, ptr %slot577, align 8
  %call3179 = call i64 @myl_f_221a865e2532e6706176e23ccf437e4652dc5fbd9266a3d9ce397c9c7007e1f3(i64 %v3173, i64 %v3174, i64 %v3175, i64 %v3176, i64 %v3177, i64 %v3178) nomerge, !dbg !158
  store i64 %call3179, ptr %slot578, align 8
  %v3180 = load i64, ptr %slot578, align 8
  %v3181 = load i64, ptr %slot35, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  store i64 %v3180, ptr %p3182, align 8, !alias.scope !3, !noalias !4
  %v3183 = load i64, ptr %slot11, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  %ld3185 = load i32, ptr %p3184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3185, ptr %slot579, align 8
  %v3186 = load i32, ptr %slot579, align 8
  %cv3187 = zext i32 %v3186 to i64
  %cond3188 = icmp ne i64 %cv3187, 0
  br i1 %cond3188, label %bb_rcslotdrop783, label %bb_rcslotdone783
bb_rcslotdrop783:
  %v3189 = load i64, ptr %slot11, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  store i32 0, ptr %p3190, align 4, !alias.scope !3, !noalias !4
  %v3191 = load i64, ptr %slot17, align 8
  store i64 %v3191, ptr %slot580, align 8
  %v3192 = load i64, ptr %slot12, align 8
  %p3193 = inttoptr i64 %v3192 to ptr
  %ld3194 = load i32, ptr %p3193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3194, ptr %slot581, align 8
  %v3195 = load i32, ptr %slot581, align 8
  %op3196 = and i32 %v3195, 28
  store i32 %op3196, ptr %slot582, align 8
  %v3197 = load i32, ptr %slot582, align 8
  %cv3198 = zext i32 %v3197 to i64
  %cond3199 = icmp ne i64 %cv3198, 0
  br i1 %cond3199, label %bb_rcslotrole783, label %bb_rcslotowner783
bb_rcslotrole783:
  %v3200 = load i64, ptr %slot45, align 8
  store i64 %v3200, ptr %slot583, align 8
  %v3201 = load i64, ptr %slot583, align 8
  %v3202 = load i64, ptr %slot580, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v3201, i64 %v3202) nomerge, !dbg !158
  br label %bb_rcslotdone783
bb_rcslotowner783:
  %v3203 = load i64, ptr %slot45, align 8
  store i64 %v3203, ptr %slot584, align 8
  %v3204 = load i64, ptr %slot584, align 8
  %v3205 = load i64, ptr %slot580, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v3204, i64 %v3205) nomerge, !dbg !158
  br label %bb_rcslotdone783
bb_rcslotdone783:
  %v3206 = load i64, ptr %slot13, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  %ld3208 = load i32, ptr %p3207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3208, ptr %slot585, align 8
  %v3209 = load i32, ptr %slot585, align 8
  %cv3210 = zext i32 %v3209 to i64
  %cond3211 = icmp ne i64 %cv3210, 0
  br i1 %cond3211, label %bb_rcslotdrop792, label %bb_rcslotdone792
bb_rcslotdrop792:
  %v3212 = load i64, ptr %slot13, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  store i32 0, ptr %p3213, align 4, !alias.scope !3, !noalias !4
  %v3214 = load i64, ptr %slot18, align 8
  store i64 %v3214, ptr %slot586, align 8
  %v3215 = load i64, ptr %slot14, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  %ld3217 = load i32, ptr %p3216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3217, ptr %slot587, align 8
  %v3218 = load i32, ptr %slot587, align 8
  %op3219 = and i32 %v3218, 28
  store i32 %op3219, ptr %slot588, align 8
  %v3220 = load i32, ptr %slot588, align 8
  %cv3221 = zext i32 %v3220 to i64
  %cond3222 = icmp ne i64 %cv3221, 0
  br i1 %cond3222, label %bb_rcslotrole792, label %bb_rcslotowner792
bb_rcslotrole792:
  %v3223 = load i64, ptr %slot45, align 8
  store i64 %v3223, ptr %slot589, align 8
  %v3224 = load i64, ptr %slot586, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  %ld3226 = load i64, ptr %p3225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3226, ptr %slot590, align 8
  %v3227 = load i64, ptr %slot590, align 8
  %cmp3228 = icmp ne i64 %v3227, 0
  %cv3229 = zext i1 %cmp3228 to i32
  store i32 %cv3229, ptr %slot591, align 8
  %v3230 = load i32, ptr %slot591, align 8
  %cv3231 = zext i32 %v3230 to i64
  %cond3232 = icmp ne i64 %cv3231, 0
  br i1 %cond3232, label %bb_rcgnn808, label %bb_rcgdone808
bb_rcgnn808:
  %v3233 = load i64, ptr %slot590, align 8
  %op3234 = sub i64 %v3233, 16
  store i64 %op3234, ptr %slot592, align 8
  %v3235 = load i64, ptr %slot590, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  %rgep3237 = getelementptr i8, ptr %p3236, i64 -16
  %ld3238 = load i64, ptr %rgep3237, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3238, ptr %slot593, align 8
  %v3239 = load i64, ptr %slot593, align 8
  %op3240 = and i64 %v3239, 4611686018427387906
  store i64 %op3240, ptr %slot594, align 8
  %v3241 = load i64, ptr %slot594, align 8
  %cmp3242 = icmp ne i64 %v3241, 0
  %cv3243 = zext i1 %cmp3242 to i32
  store i32 %cv3243, ptr %slot595, align 8
  %v3244 = load i32, ptr %slot595, align 8
  %cv3245 = zext i32 %v3244 to i64
  %cond3246 = icmp ne i64 %cv3245, 0
  br i1 %cond3246, label %bb_rcgclear808, label %bb_rcgcounted808
bb_rcgcounted808:
  %v3247 = load i64, ptr %slot590, align 8
  %op3248 = sub i64 %v3247, 24
  store i64 %op3248, ptr %slot596, align 8
  %v3249 = load i64, ptr %slot590, align 8
  %p3250 = inttoptr i64 %v3249 to ptr
  %rgep3251 = getelementptr i8, ptr %p3250, i64 -24
  %ld3252 = load i64, ptr %rgep3251, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3252, ptr %slot597, align 8
  %v3253 = load i64, ptr %slot597, align 8
  %op3254 = sub i64 %v3253, 1
  store i64 %op3254, ptr %slot598, align 8
  %v3255 = load i64, ptr %slot598, align 8
  %cmp3256 = icmp eq i64 %v3255, 0
  %cv3257 = zext i1 %cmp3256 to i32
  store i32 %cv3257, ptr %slot599, align 8
  %v3258 = load i32, ptr %slot599, align 8
  %cv3259 = zext i32 %v3258 to i64
  %cond3260 = icmp ne i64 %cv3259, 0
  br i1 %cond3260, label %bb_rcglast808, label %bb_rcgdec808
bb_rcglast808:
  %v3261 = load i64, ptr %slot590, align 8
  %op3262 = sub i64 %v3261, 32
  store i64 %op3262, ptr %slot600, align 8
  %v3263 = load i64, ptr %slot590, align 8
  %p3264 = inttoptr i64 %v3263 to ptr
  %rgep3265 = getelementptr i8, ptr %p3264, i64 -32
  %ld3266 = load i64, ptr %rgep3265, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3266, ptr %slot601, align 8
  %v3267 = load i64, ptr %slot601, align 8
  %cmp3268 = icmp ne i64 %v3267, 0
  %cv3269 = zext i1 %cmp3268 to i32
  store i32 %cv3269, ptr %slot602, align 8
  %v3270 = load i32, ptr %slot602, align 8
  %cv3271 = zext i32 %v3270 to i64
  %cond3272 = icmp ne i64 %cv3271, 0
  br i1 %cond3272, label %bb_rcgdec808, label %bb_rcgslow808
bb_rcgslow808:
  %v3273 = load i64, ptr %slot589, align 8
  %v3274 = load i64, ptr %slot586, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3273, i64 %v3274) nomerge, !dbg !158
  br label %bb_rcgdone808
bb_rcgdec808:
  %v3275 = load i64, ptr %slot598, align 8
  %v3276 = load i64, ptr %slot590, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  %rgep3278 = getelementptr i8, ptr %p3277, i64 -24
  store i64 %v3275, ptr %rgep3278, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear808
bb_rcgclear808:
  %v3279 = load i64, ptr %slot586, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  store i64 0, ptr %p3280, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone808
bb_rcgdone808:
  br label %bb_rcslotdone792
bb_rcslotowner792:
  %v3281 = load i64, ptr %slot45, align 8
  store i64 %v3281, ptr %slot603, align 8
  %v3282 = load i64, ptr %slot586, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %ld3284 = load i64, ptr %p3283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3284, ptr %slot604, align 8
  %v3285 = load i64, ptr %slot604, align 8
  %cmp3286 = icmp ne i64 %v3285, 0
  %cv3287 = zext i1 %cmp3286 to i32
  store i32 %cv3287, ptr %slot605, align 8
  %v3288 = load i32, ptr %slot605, align 8
  %cv3289 = zext i32 %v3288 to i64
  %cond3290 = icmp ne i64 %cv3289, 0
  br i1 %cond3290, label %bb_rcgnn823, label %bb_rcgdone823
bb_rcgnn823:
  %v3291 = load i64, ptr %slot604, align 8
  %op3292 = sub i64 %v3291, 16
  store i64 %op3292, ptr %slot606, align 8
  %v3293 = load i64, ptr %slot604, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  %rgep3295 = getelementptr i8, ptr %p3294, i64 -16
  %ld3296 = load i64, ptr %rgep3295, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3296, ptr %slot607, align 8
  %v3297 = load i64, ptr %slot607, align 8
  %op3298 = and i64 %v3297, 4611686018427387906
  store i64 %op3298, ptr %slot608, align 8
  %v3299 = load i64, ptr %slot608, align 8
  %cmp3300 = icmp ne i64 %v3299, 0
  %cv3301 = zext i1 %cmp3300 to i32
  store i32 %cv3301, ptr %slot609, align 8
  %v3302 = load i32, ptr %slot609, align 8
  %cv3303 = zext i32 %v3302 to i64
  %cond3304 = icmp ne i64 %cv3303, 0
  br i1 %cond3304, label %bb_rcgclear823, label %bb_rcgcounted823
bb_rcgcounted823:
  %v3305 = load i64, ptr %slot604, align 8
  %op3306 = sub i64 %v3305, 32
  store i64 %op3306, ptr %slot610, align 8
  %v3307 = load i64, ptr %slot604, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  %rgep3309 = getelementptr i8, ptr %p3308, i64 -32
  %ld3310 = load i64, ptr %rgep3309, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3310, ptr %slot611, align 8
  %v3311 = load i64, ptr %slot611, align 8
  %op3312 = sub i64 %v3311, 1
  store i64 %op3312, ptr %slot612, align 8
  %v3313 = load i64, ptr %slot612, align 8
  %cmp3314 = icmp eq i64 %v3313, 0
  %cv3315 = zext i1 %cmp3314 to i32
  store i32 %cv3315, ptr %slot613, align 8
  %v3316 = load i32, ptr %slot613, align 8
  %cv3317 = zext i32 %v3316 to i64
  %cond3318 = icmp ne i64 %cv3317, 0
  br i1 %cond3318, label %bb_rcglast823, label %bb_rcgdec823
bb_rcglast823:
  %v3319 = load i64, ptr %slot604, align 8
  %op3320 = sub i64 %v3319, 24
  store i64 %op3320, ptr %slot614, align 8
  %v3321 = load i64, ptr %slot604, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  %rgep3323 = getelementptr i8, ptr %p3322, i64 -24
  %ld3324 = load i64, ptr %rgep3323, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3324, ptr %slot615, align 8
  %v3325 = load i64, ptr %slot615, align 8
  %cmp3326 = icmp ne i64 %v3325, 0
  %cv3327 = zext i1 %cmp3326 to i32
  store i32 %cv3327, ptr %slot616, align 8
  %v3328 = load i32, ptr %slot616, align 8
  %cv3329 = zext i32 %v3328 to i64
  %cond3330 = icmp ne i64 %cv3329, 0
  br i1 %cond3330, label %bb_rcgdec823, label %bb_rcgslow823
bb_rcgslow823:
  %v3331 = load i64, ptr %slot603, align 8
  %v3332 = load i64, ptr %slot586, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3331, i64 %v3332) nomerge, !dbg !158
  br label %bb_rcgdone823
bb_rcgdec823:
  %v3333 = load i64, ptr %slot612, align 8
  %v3334 = load i64, ptr %slot604, align 8
  %p3335 = inttoptr i64 %v3334 to ptr
  %rgep3336 = getelementptr i8, ptr %p3335, i64 -32
  store i64 %v3333, ptr %rgep3336, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear823
bb_rcgclear823:
  %v3337 = load i64, ptr %slot586, align 8
  %p3338 = inttoptr i64 %v3337 to ptr
  store i64 0, ptr %p3338, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone823
bb_rcgdone823:
  br label %bb_rcslotdone792
bb_rcslotdone792:
  br label %bb_i93
bb_i93:
  %v3339 = load i64, ptr %slot5, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  %ld3341 = load i32, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3341, ptr %slot617, align 8
  %v3342 = load i32, ptr %slot617, align 8
  %cv3343 = zext i32 %v3342 to i64
  %cond3344 = icmp ne i64 %cv3343, 0
  br i1 %cond3344, label %bb_rcslotdrop829, label %bb_rcslotdone829
bb_rcslotdrop829:
  %v3345 = load i64, ptr %slot5, align 8
  %p3346 = inttoptr i64 %v3345 to ptr
  store i32 0, ptr %p3346, align 4, !alias.scope !3, !noalias !4
  %v3347 = load i64, ptr %slot26, align 8
  store i64 %v3347, ptr %slot618, align 8
  %v3348 = load i64, ptr %slot6, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  %ld3350 = load i32, ptr %p3349, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3350, ptr %slot619, align 8
  %v3351 = load i32, ptr %slot619, align 8
  %op3352 = and i32 %v3351, 28
  store i32 %op3352, ptr %slot620, align 8
  %v3353 = load i32, ptr %slot620, align 8
  %cv3354 = zext i32 %v3353 to i64
  %cond3355 = icmp ne i64 %cv3354, 0
  br i1 %cond3355, label %bb_rcslotrole829, label %bb_rcslotowner829
bb_rcslotrole829:
  %v3356 = load i64, ptr %slot45, align 8
  store i64 %v3356, ptr %slot621, align 8
  %v3357 = load i64, ptr %slot621, align 8
  %v3358 = load i64, ptr %slot618, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v3357, i64 %v3358) nomerge, !dbg !160
  br label %bb_rcslotdone829
bb_rcslotowner829:
  %v3359 = load i64, ptr %slot45, align 8
  store i64 %v3359, ptr %slot622, align 8
  %v3360 = load i64, ptr %slot622, align 8
  %v3361 = load i64, ptr %slot618, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v3360, i64 %v3361) nomerge, !dbg !160
  br label %bb_rcslotdone829
bb_rcslotdone829:
  br label %bb_i106
bb_i95:
  br label %bb_i106
bb_i96:
  br label %bb_i106
bb_i97:
  br label %bb_i106
bb_i98:
  br label %bb_i106
bb_i99:
  br label %bb_i106
bb_i100:
  br label %bb_i106
bb_i101:
  br label %bb_i106
bb_i102:
  br label %bb_i106
bb_i103:
  br label %bb_i106
bb_i104:
  br label %bb_i106
bb_i105:
  br label %bb_i106
bb_i106:
  %v3362 = load i64, ptr %slot35, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  store i64 0, ptr %p3363, align 8, !alias.scope !3, !noalias !4
  %v3364 = load i64, ptr %slot35, align 8
  %p3365 = inttoptr i64 %v3364 to ptr
  %ld3366 = load i64, ptr %p3365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3366, ptr %slot623, align 8
  %v3367 = load i64, ptr %slot11, align 8
  %p3368 = inttoptr i64 %v3367 to ptr
  %ld3369 = load i32, ptr %p3368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3369, ptr %slot624, align 8
  %v3370 = load i32, ptr %slot624, align 8
  %cv3371 = zext i32 %v3370 to i64
  %cond3372 = icmp ne i64 %cv3371, 0
  br i1 %cond3372, label %bb_rcslotdrop839, label %bb_rcslotdone839
bb_rcslotdrop839:
  %v3373 = load i64, ptr %slot11, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  store i32 0, ptr %p3374, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone839
bb_rcslotdone839:
  %v3375 = load i64, ptr %slot9, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  %ld3377 = load i32, ptr %p3376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3377, ptr %slot625, align 8
  %v3378 = load i32, ptr %slot625, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcslotdrop842, label %bb_rcslotdone842
bb_rcslotdrop842:
  %v3381 = load i64, ptr %slot9, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  store i32 0, ptr %p3382, align 4, !alias.scope !3, !noalias !4
  %v3383 = load i64, ptr %slot33, align 8
  store i64 %v3383, ptr %slot626, align 8
  %v3384 = load i64, ptr %slot10, align 8
  %p3385 = inttoptr i64 %v3384 to ptr
  %ld3386 = load i32, ptr %p3385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3386, ptr %slot627, align 8
  %v3387 = load i32, ptr %slot627, align 8
  %op3388 = and i32 %v3387, 28
  store i32 %op3388, ptr %slot628, align 8
  %v3389 = load i32, ptr %slot628, align 8
  %cv3390 = zext i32 %v3389 to i64
  %cond3391 = icmp ne i64 %cv3390, 0
  br i1 %cond3391, label %bb_rcslotrole842, label %bb_rcslotowner842
bb_rcslotrole842:
  %v3392 = load i64, ptr %slot45, align 8
  store i64 %v3392, ptr %slot629, align 8
  %v3393 = load i64, ptr %slot626, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  %ld3395 = load i64, ptr %p3394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3395, ptr %slot630, align 8
  %v3396 = load i64, ptr %slot630, align 8
  %cmp3397 = icmp ne i64 %v3396, 0
  %cv3398 = zext i1 %cmp3397 to i32
  store i32 %cv3398, ptr %slot631, align 8
  %v3399 = load i32, ptr %slot631, align 8
  %cv3400 = zext i32 %v3399 to i64
  %cond3401 = icmp ne i64 %cv3400, 0
  br i1 %cond3401, label %bb_rcgnn858, label %bb_rcgdone858
bb_rcgnn858:
  %v3402 = load i64, ptr %slot630, align 8
  %op3403 = sub i64 %v3402, 16
  store i64 %op3403, ptr %slot632, align 8
  %v3404 = load i64, ptr %slot630, align 8
  %p3405 = inttoptr i64 %v3404 to ptr
  %rgep3406 = getelementptr i8, ptr %p3405, i64 -16
  %ld3407 = load i64, ptr %rgep3406, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3407, ptr %slot633, align 8
  %v3408 = load i64, ptr %slot633, align 8
  %op3409 = and i64 %v3408, 4611686018427387906
  store i64 %op3409, ptr %slot634, align 8
  %v3410 = load i64, ptr %slot634, align 8
  %cmp3411 = icmp ne i64 %v3410, 0
  %cv3412 = zext i1 %cmp3411 to i32
  store i32 %cv3412, ptr %slot635, align 8
  %v3413 = load i32, ptr %slot635, align 8
  %cv3414 = zext i32 %v3413 to i64
  %cond3415 = icmp ne i64 %cv3414, 0
  br i1 %cond3415, label %bb_rcgclear858, label %bb_rcgcounted858
bb_rcgcounted858:
  %v3416 = load i64, ptr %slot630, align 8
  %op3417 = sub i64 %v3416, 24
  store i64 %op3417, ptr %slot636, align 8
  %v3418 = load i64, ptr %slot630, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  %rgep3420 = getelementptr i8, ptr %p3419, i64 -24
  %ld3421 = load i64, ptr %rgep3420, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3421, ptr %slot637, align 8
  %v3422 = load i64, ptr %slot637, align 8
  %op3423 = sub i64 %v3422, 1
  store i64 %op3423, ptr %slot638, align 8
  %v3424 = load i64, ptr %slot638, align 8
  %cmp3425 = icmp eq i64 %v3424, 0
  %cv3426 = zext i1 %cmp3425 to i32
  store i32 %cv3426, ptr %slot639, align 8
  %v3427 = load i32, ptr %slot639, align 8
  %cv3428 = zext i32 %v3427 to i64
  %cond3429 = icmp ne i64 %cv3428, 0
  br i1 %cond3429, label %bb_rcglast858, label %bb_rcgdec858
bb_rcglast858:
  %v3430 = load i64, ptr %slot630, align 8
  %op3431 = sub i64 %v3430, 32
  store i64 %op3431, ptr %slot640, align 8
  %v3432 = load i64, ptr %slot630, align 8
  %p3433 = inttoptr i64 %v3432 to ptr
  %rgep3434 = getelementptr i8, ptr %p3433, i64 -32
  %ld3435 = load i64, ptr %rgep3434, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3435, ptr %slot641, align 8
  %v3436 = load i64, ptr %slot641, align 8
  %cmp3437 = icmp ne i64 %v3436, 0
  %cv3438 = zext i1 %cmp3437 to i32
  store i32 %cv3438, ptr %slot642, align 8
  %v3439 = load i32, ptr %slot642, align 8
  %cv3440 = zext i32 %v3439 to i64
  %cond3441 = icmp ne i64 %cv3440, 0
  br i1 %cond3441, label %bb_rcgdec858, label %bb_rcgslow858
bb_rcgslow858:
  %v3442 = load i64, ptr %slot629, align 8
  %v3443 = load i64, ptr %slot626, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64 %v3442, i64 %v3443) nomerge, !dbg !162
  br label %bb_rcgdone858
bb_rcgdec858:
  %v3444 = load i64, ptr %slot638, align 8
  %v3445 = load i64, ptr %slot630, align 8
  %p3446 = inttoptr i64 %v3445 to ptr
  %rgep3447 = getelementptr i8, ptr %p3446, i64 -24
  store i64 %v3444, ptr %rgep3447, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear858
bb_rcgclear858:
  %v3448 = load i64, ptr %slot626, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  store i64 0, ptr %p3449, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone858
bb_rcgdone858:
  br label %bb_rcslotdone842
bb_rcslotowner842:
  %v3450 = load i64, ptr %slot45, align 8
  store i64 %v3450, ptr %slot643, align 8
  %v3451 = load i64, ptr %slot626, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  %ld3453 = load i64, ptr %p3452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3453, ptr %slot644, align 8
  %v3454 = load i64, ptr %slot644, align 8
  %cmp3455 = icmp ne i64 %v3454, 0
  %cv3456 = zext i1 %cmp3455 to i32
  store i32 %cv3456, ptr %slot645, align 8
  %v3457 = load i32, ptr %slot645, align 8
  %cv3458 = zext i32 %v3457 to i64
  %cond3459 = icmp ne i64 %cv3458, 0
  br i1 %cond3459, label %bb_rcgnn873, label %bb_rcgdone873
bb_rcgnn873:
  %v3460 = load i64, ptr %slot644, align 8
  %op3461 = sub i64 %v3460, 16
  store i64 %op3461, ptr %slot646, align 8
  %v3462 = load i64, ptr %slot644, align 8
  %p3463 = inttoptr i64 %v3462 to ptr
  %rgep3464 = getelementptr i8, ptr %p3463, i64 -16
  %ld3465 = load i64, ptr %rgep3464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3465, ptr %slot647, align 8
  %v3466 = load i64, ptr %slot647, align 8
  %op3467 = and i64 %v3466, 4611686018427387906
  store i64 %op3467, ptr %slot648, align 8
  %v3468 = load i64, ptr %slot648, align 8
  %cmp3469 = icmp ne i64 %v3468, 0
  %cv3470 = zext i1 %cmp3469 to i32
  store i32 %cv3470, ptr %slot649, align 8
  %v3471 = load i32, ptr %slot649, align 8
  %cv3472 = zext i32 %v3471 to i64
  %cond3473 = icmp ne i64 %cv3472, 0
  br i1 %cond3473, label %bb_rcgclear873, label %bb_rcgcounted873
bb_rcgcounted873:
  %v3474 = load i64, ptr %slot644, align 8
  %op3475 = sub i64 %v3474, 32
  store i64 %op3475, ptr %slot650, align 8
  %v3476 = load i64, ptr %slot644, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  %rgep3478 = getelementptr i8, ptr %p3477, i64 -32
  %ld3479 = load i64, ptr %rgep3478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3479, ptr %slot651, align 8
  %v3480 = load i64, ptr %slot651, align 8
  %op3481 = sub i64 %v3480, 1
  store i64 %op3481, ptr %slot652, align 8
  %v3482 = load i64, ptr %slot652, align 8
  %cmp3483 = icmp eq i64 %v3482, 0
  %cv3484 = zext i1 %cmp3483 to i32
  store i32 %cv3484, ptr %slot653, align 8
  %v3485 = load i32, ptr %slot653, align 8
  %cv3486 = zext i32 %v3485 to i64
  %cond3487 = icmp ne i64 %cv3486, 0
  br i1 %cond3487, label %bb_rcglast873, label %bb_rcgdec873
bb_rcglast873:
  %v3488 = load i64, ptr %slot644, align 8
  %op3489 = sub i64 %v3488, 24
  store i64 %op3489, ptr %slot654, align 8
  %v3490 = load i64, ptr %slot644, align 8
  %p3491 = inttoptr i64 %v3490 to ptr
  %rgep3492 = getelementptr i8, ptr %p3491, i64 -24
  %ld3493 = load i64, ptr %rgep3492, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3493, ptr %slot655, align 8
  %v3494 = load i64, ptr %slot655, align 8
  %cmp3495 = icmp ne i64 %v3494, 0
  %cv3496 = zext i1 %cmp3495 to i32
  store i32 %cv3496, ptr %slot656, align 8
  %v3497 = load i32, ptr %slot656, align 8
  %cv3498 = zext i32 %v3497 to i64
  %cond3499 = icmp ne i64 %cv3498, 0
  br i1 %cond3499, label %bb_rcgdec873, label %bb_rcgslow873
bb_rcgslow873:
  %v3500 = load i64, ptr %slot643, align 8
  %v3501 = load i64, ptr %slot626, align 8
  call void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64 %v3500, i64 %v3501) nomerge, !dbg !162
  br label %bb_rcgdone873
bb_rcgdec873:
  %v3502 = load i64, ptr %slot652, align 8
  %v3503 = load i64, ptr %slot644, align 8
  %p3504 = inttoptr i64 %v3503 to ptr
  %rgep3505 = getelementptr i8, ptr %p3504, i64 -32
  store i64 %v3502, ptr %rgep3505, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear873
bb_rcgclear873:
  %v3506 = load i64, ptr %slot626, align 8
  %p3507 = inttoptr i64 %v3506 to ptr
  store i64 0, ptr %p3507, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone873
bb_rcgdone873:
  br label %bb_rcslotdone842
bb_rcslotdone842:
  %v3508 = load i64, ptr %slot7, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  %ld3510 = load i32, ptr %p3509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3510, ptr %slot657, align 8
  %v3511 = load i32, ptr %slot657, align 8
  %cv3512 = zext i32 %v3511 to i64
  %cond3513 = icmp ne i64 %cv3512, 0
  br i1 %cond3513, label %bb_rcslotdrop879, label %bb_rcslotdone879
bb_rcslotdrop879:
  %v3514 = load i64, ptr %slot7, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  store i32 0, ptr %p3515, align 4, !alias.scope !3, !noalias !4
  %v3516 = load i64, ptr %slot31, align 8
  store i64 %v3516, ptr %slot658, align 8
  %v3517 = load i64, ptr %slot8, align 8
  %p3518 = inttoptr i64 %v3517 to ptr
  %ld3519 = load i32, ptr %p3518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3519, ptr %slot659, align 8
  %v3520 = load i32, ptr %slot659, align 8
  %op3521 = and i32 %v3520, 28
  store i32 %op3521, ptr %slot660, align 8
  %v3522 = load i32, ptr %slot660, align 8
  %cv3523 = zext i32 %v3522 to i64
  %cond3524 = icmp ne i64 %cv3523, 0
  br i1 %cond3524, label %bb_rcslotrole879, label %bb_rcslotowner879
bb_rcslotrole879:
  %v3525 = load i64, ptr %slot45, align 8
  store i64 %v3525, ptr %slot661, align 8
  %v3526 = load i64, ptr %slot661, align 8
  %v3527 = load i64, ptr %slot658, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_unloan(i64 %v3526, i64 %v3527) nomerge, !dbg !162
  br label %bb_rcslotdone879
bb_rcslotowner879:
  %v3528 = load i64, ptr %slot45, align 8
  store i64 %v3528, ptr %slot662, align 8
  %v3529 = load i64, ptr %slot662, align 8
  %v3530 = load i64, ptr %slot658, align 8
  call void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_drop(i64 %v3529, i64 %v3530) nomerge, !dbg !162
  br label %bb_rcslotdone879
bb_rcslotdone879:
  %v3531 = load i64, ptr %slot5, align 8
  %p3532 = inttoptr i64 %v3531 to ptr
  %ld3533 = load i32, ptr %p3532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3533, ptr %slot663, align 8
  %v3534 = load i32, ptr %slot663, align 8
  %cv3535 = zext i32 %v3534 to i64
  %cond3536 = icmp ne i64 %cv3535, 0
  br i1 %cond3536, label %bb_rcslotdrop999, label %bb_rcslotdone999
bb_rcslotdrop999:
  %v3537 = load i64, ptr %slot5, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  store i32 0, ptr %p3538, align 4, !alias.scope !3, !noalias !4
  %v3539 = load i64, ptr %slot26, align 8
  store i64 %v3539, ptr %slot664, align 8
  %v3540 = load i64, ptr %slot6, align 8
  %p3541 = inttoptr i64 %v3540 to ptr
  %ld3542 = load i32, ptr %p3541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3542, ptr %slot665, align 8
  %v3543 = load i32, ptr %slot665, align 8
  %op3544 = and i32 %v3543, 28
  store i32 %op3544, ptr %slot666, align 8
  %v3545 = load i32, ptr %slot666, align 8
  %cv3546 = zext i32 %v3545 to i64
  %cond3547 = icmp ne i64 %cv3546, 0
  br i1 %cond3547, label %bb_rcslotrole999, label %bb_rcslotowner999
bb_rcslotrole999:
  %v3548 = load i64, ptr %slot45, align 8
  store i64 %v3548, ptr %slot667, align 8
  %v3549 = load i64, ptr %slot667, align 8
  %v3550 = load i64, ptr %slot664, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v3549, i64 %v3550) nomerge, !dbg !162
  br label %bb_rcslotdone999
bb_rcslotowner999:
  %v3551 = load i64, ptr %slot45, align 8
  store i64 %v3551, ptr %slot668, align 8
  %v3552 = load i64, ptr %slot668, align 8
  %v3553 = load i64, ptr %slot664, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v3552, i64 %v3553) nomerge, !dbg !162
  br label %bb_rcslotdone999
bb_rcslotdone999:
  %v3554 = load i64, ptr %slot623, align 8
  ret i64 %v3554
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_caa7b3678bda3862ff5f83bbb6e47ad1ac08ca1a57df8898f6139dcbfc186bd8 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_221a865e2532e6706176e23ccf437e4652dc5fbd9266a3d9ce397c9c7007e1f3(i64, i64, i64, i64, i64, i64)
declare i64 @myl_f_5af755ff39699d4050214e9fdc5e92b763fd42b47cc67a218a0ace498e9cdd61(i64, i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_drop(i64, i64)
declare i32 @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_take(i64, i64, i64, i32)
declare void @myl_t_6ca6a55fd7129253c6cb738ea64c8096d2b0f5f9b7360c64284a24d905432871_rcg_unloan(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_loan(i64, i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_drop(i64, i64)
declare i32 @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_loan(i64, i64, i64)
declare i32 @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_take(i64, i64, i64, i32)
declare void @myl_t_9810a68554a8970d3cd155f54d76f0113bb83511ee84db16f53873095a93cd8e_rcg_unloan(i64, i64)
declare void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64, i64)
declare i32 @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11, !14}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11, !14}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5, !14}
!14 = distinct !{!14, !0, !"element 24v"}
!15 = !{!14}
!16 = !{!1, !5, !11}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_cdbae2c9e3e74db1cd59bea9ebdf56dd892e43044fee2029b41340b26817caba", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_cdbae2c9e3e74db1cd59bea9ebdf56dd892e43044fee2029b41340b26817caba", linkageName: "myl_f_cdbae2c9e3e74db1cd59bea9ebdf56dd892e43044fee2029b41340b26817caba", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16359390250982944197, i64 0, !"myl_f_cdbae2c9e3e74db1cd59bea9ebdf56dd892e43044fee2029b41340b26817caba"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!126 = !DILocation(line: 20, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!128 = !DILocation(line: 23, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!130 = !DILocation(line: 28, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!132 = !DILocation(line: 31, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!134 = !DILocation(line: 34, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!136 = !DILocation(line: 36, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!138 = !DILocation(line: 43, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!140 = !DILocation(line: 45, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!142 = !DILocation(line: 48, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!144 = !DILocation(line: 50, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!146 = !DILocation(line: 54, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!148 = !DILocation(line: 61, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!150 = !DILocation(line: 62, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!152 = !DILocation(line: 70, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!154 = !DILocation(line: 72, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!156 = !DILocation(line: 75, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!158 = !DILocation(line: 92, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647287)
!160 = !DILocation(line: 94, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647399)
!162 = !DILocation(line: 108, column: 0, scope: !163)
