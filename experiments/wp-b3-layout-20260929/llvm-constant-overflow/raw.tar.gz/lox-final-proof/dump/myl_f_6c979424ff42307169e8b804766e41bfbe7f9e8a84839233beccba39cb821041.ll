target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_6c979424ff42307169e8b804766e41bfbe7f9e8a84839233beccba39cb821041(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v24 = load i64, ptr %slot1, align 8
  %op25 = add i64 %v24, 32
  store i64 %op25, ptr %slot3, align 8
  %mem26 = alloca i8, i64 8, align 8
  %ptr27 = ptrtoint ptr %mem26 to i64
  store i64 %ptr27, ptr %slot4, align 8
  %mem28 = alloca i8, i64 8, align 8
  %ptr29 = ptrtoint ptr %mem28 to i64
  store i64 %ptr29, ptr %slot5, align 8
  %mem30 = alloca i8, i64 8, align 8
  %ptr31 = ptrtoint ptr %mem30 to i64
  store i64 %ptr31, ptr %slot6, align 8
  %mem32 = alloca i8, i64 8, align 8
  %ptr33 = ptrtoint ptr %mem32 to i64
  store i64 %ptr33, ptr %slot7, align 8
  %mem34 = alloca i8, i64 8, align 8
  %ptr35 = ptrtoint ptr %mem34 to i64
  store i64 %ptr35, ptr %slot8, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem36 = alloca i8, i64 8, align 8
  %ptr37 = ptrtoint ptr %mem36 to i64
  store i64 %ptr37, ptr %slot9, align 8
  %v38 = load i64, ptr %slot1, align 8
  %op39 = add i64 %v38, 64
  store i64 %op39, ptr %slot10, align 8
  %v40 = load i64, ptr %slot10, align 8
  %p41 = inttoptr i64 %v40 to ptr
  %ld42 = load i64, ptr %p41, align 8, !alias.scope !4, !noalias !3
  store i64 %ld42, ptr %slot11, align 8
  %stack43 = call ptr @llvm.stacksave()
  %stackaddr44 = ptrtoint ptr %stack43 to i64
  %v45 = load i64, ptr %slot11, align 8
  %cmp46 = icmp ult i64 %stackaddr44, %v45
  %cv47 = zext i1 %cmp46 to i64
  store i64 %cv47, ptr %slot12, align 8
  %v48 = load i64, ptr %slot12, align 8
  %cond49 = icmp ne i64 %v48, 0
  br i1 %cond49, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v50 = load i64, ptr %slot1, align 8
  %p51 = inttoptr i64 %v50 to ptr
  call void @myl_qbe_fail_frame(ptr %p51) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v52 = load i64, ptr %slot2, align 8
  %v53 = load i64, ptr %slot4, align 8
  %p54 = inttoptr i64 %v53 to ptr
  store i64 %v52, ptr %p54, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v55 = load i64, ptr %slot4, align 8
  %p56 = inttoptr i64 %v55 to ptr
  %ld57 = load i64, ptr %p56, align 8, !alias.scope !3, !noalias !4
  store i64 %ld57, ptr %slot13, align 8
  %v58 = load i64, ptr %slot13, align 8
  %v59 = load i64, ptr %slot6, align 8
  %p60 = inttoptr i64 %v59 to ptr
  store i64 %v58, ptr %p60, align 8, !alias.scope !3, !noalias !4
  %v61 = load i64, ptr %slot6, align 8
  %p62 = inttoptr i64 %v61 to ptr
  %ld63 = load i64, ptr %p62, align 8, !alias.scope !3, !noalias !4
  store i64 %ld63, ptr %slot14, align 8
  %v64 = load i64, ptr %slot1, align 8
  %v65 = load i64, ptr %slot14, align 8
  %call66 = call i64 @myl_f_ac13903736ec769eb48562470a853500b22f5a923e609913526776729a9c5281(i64 %v64, i64 %v65) nomerge, !dbg !112
  store i64 %call66, ptr %slot15, align 8
  %v67 = load i64, ptr %slot15, align 8
  %v68 = load i64, ptr %slot6, align 8
  %p69 = inttoptr i64 %v68 to ptr
  store i64 %v67, ptr %p69, align 8, !alias.scope !3, !noalias !4
  %v70 = load i64, ptr %slot6, align 8
  %p71 = inttoptr i64 %v70 to ptr
  %ld72 = load i64, ptr %p71, align 8, !alias.scope !3, !noalias !4
  store i64 %ld72, ptr %slot16, align 8
  %v73 = load i64, ptr %slot16, align 8
  %v74 = load i64, ptr %slot5, align 8
  %p75 = inttoptr i64 %v74 to ptr
  store i64 %v73, ptr %p75, align 8, !alias.scope !3, !noalias !4
  %v76 = load i64, ptr %slot4, align 8
  %p77 = inttoptr i64 %v76 to ptr
  %ld78 = load i64, ptr %p77, align 8, !alias.scope !3, !noalias !4
  store i64 %ld78, ptr %slot17, align 8
  %v79 = load i64, ptr %slot17, align 8
  %v80 = load i64, ptr %slot6, align 8
  %p81 = inttoptr i64 %v80 to ptr
  store i64 %v79, ptr %p81, align 8, !alias.scope !3, !noalias !4
  %v82 = load i64, ptr %slot7, align 8
  %p83 = inttoptr i64 %v82 to ptr
  store i64 28, ptr %p83, align 8, !alias.scope !3, !noalias !4
  %v84 = load i64, ptr %slot5, align 8
  %p85 = inttoptr i64 %v84 to ptr
  %ld86 = load i64, ptr %p85, align 8, !alias.scope !3, !noalias !4
  store i64 %ld86, ptr %slot18, align 8
  %v87 = load i64, ptr %slot18, align 8
  %v88 = load i64, ptr %slot8, align 8
  %p89 = inttoptr i64 %v88 to ptr
  store i64 %v87, ptr %p89, align 8, !alias.scope !3, !noalias !4
  %v90 = load i64, ptr %slot6, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !3, !noalias !4
  store i64 %ld92, ptr %slot19, align 8
  %v93 = load i64, ptr %slot7, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %ld95 = load i64, ptr %p94, align 8, !alias.scope !3, !noalias !4
  store i64 %ld95, ptr %slot20, align 8
  %v96 = load i64, ptr %slot8, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot21, align 8
  %v99 = load i64, ptr %slot1, align 8
  %v100 = load i64, ptr %slot19, align 8
  %v101 = load i64, ptr %slot20, align 8
  %v102 = load i64, ptr %slot21, align 8
  %call103 = call i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64 %v99, i64 %v100, i64 %v101, i64 %v102) nomerge, !dbg !114
  store i64 %call103, ptr %slot22, align 8
  %v104 = load i64, ptr %slot22, align 8
  %v105 = load i64, ptr %slot6, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i64 %v104, ptr %p106, align 8, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot6, align 8
  %p108 = inttoptr i64 %v107 to ptr
  store i64 0, ptr %p108, align 8, !alias.scope !3, !noalias !4
  %v109 = load i64, ptr %slot6, align 8
  %p110 = inttoptr i64 %v109 to ptr
  %ld111 = load i64, ptr %p110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld111, ptr %slot23, align 8
  %v112 = load i64, ptr %slot23, align 8
  ret i64 %v112
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare i64 @myl_f_ac13903736ec769eb48562470a853500b22f5a923e609913526776729a9c5281(i64, i64)
declare i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_6c979424ff42307169e8b804766e41bfbe7f9e8a84839233beccba39cb821041", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_6c979424ff42307169e8b804766e41bfbe7f9e8a84839233beccba39cb821041", linkageName: "myl_f_6c979424ff42307169e8b804766e41bfbe7f9e8a84839233beccba39cb821041", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1235385729166682466, i64 0, !"myl_f_6c979424ff42307169e8b804766e41bfbe7f9e8a84839233beccba39cb821041"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!114 = !DILocation(line: 7, column: 0, scope: !115)
