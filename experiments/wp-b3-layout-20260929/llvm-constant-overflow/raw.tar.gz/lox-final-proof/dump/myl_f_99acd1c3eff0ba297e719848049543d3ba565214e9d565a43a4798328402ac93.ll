target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_99acd1c3eff0ba297e719848049543d3ba565214e9d565a43a4798328402ac93(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca double, align 8
  %slot24 = alloca double, align 8
  %slot25 = alloca double, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v28 = load i64, ptr %slot1, align 8
  %op29 = add i64 %v28, 32
  store i64 %op29, ptr %slot3, align 8
  %mem30 = alloca i8, i64 8, align 8
  %ptr31 = ptrtoint ptr %mem30 to i64
  store i64 %ptr31, ptr %slot4, align 8
  %mem32 = alloca i8, i64 8, align 8
  %ptr33 = ptrtoint ptr %mem32 to i64
  store i64 %ptr33, ptr %slot5, align 8
  %mem34 = alloca i8, i64 8, align 8
  %ptr35 = ptrtoint ptr %mem34 to i64
  store i64 %ptr35, ptr %slot6, align 8
  %mem36 = alloca i8, i64 8, align 8
  %ptr37 = ptrtoint ptr %mem36 to i64
  store i64 %ptr37, ptr %slot7, align 8
  %mem38 = alloca i8, i64 8, align 8
  %ptr39 = ptrtoint ptr %mem38 to i64
  store i64 %ptr39, ptr %slot8, align 8
  %v40 = load i64, ptr %slot2, align 8
  %v41 = load i64, ptr %slot4, align 8
  %p42 = inttoptr i64 %v41 to ptr
  store i64 %v40, ptr %p42, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v43 = load i64, ptr %slot4, align 8
  %p44 = inttoptr i64 %v43 to ptr
  %ld45 = load i64, ptr %p44, align 8, !alias.scope !3, !noalias !4
  store i64 %ld45, ptr %slot9, align 8
  %v46 = load i64, ptr %slot9, align 8
  %v47 = load i64, ptr %slot7, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 %v46, ptr %p48, align 8, !alias.scope !3, !noalias !4
  %v49 = load i64, ptr %slot7, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ld51 = load i64, ptr %p50, align 8, !alias.scope !3, !noalias !4
  store i64 %ld51, ptr %slot10, align 8
  %v52 = load i64, ptr %slot10, align 8
  %op53 = add i64 %v52, 0
  store i64 %op53, ptr %slot11, align 8
  %v54 = load i64, ptr %slot11, align 8
  %p55 = inttoptr i64 %v54 to ptr
  %ld56 = load i64, ptr %p55, align 8, !alias.scope !4, !noalias !3
  store i64 %ld56, ptr %slot12, align 8
  %v57 = load i64, ptr %slot12, align 8
  %v58 = load i64, ptr %slot7, align 8
  %p59 = inttoptr i64 %v58 to ptr
  store i64 %v57, ptr %p59, align 8, !alias.scope !3, !noalias !4
  %v60 = load i64, ptr %slot7, align 8
  %p61 = inttoptr i64 %v60 to ptr
  %ld62 = load i64, ptr %p61, align 8, !alias.scope !3, !noalias !4
  store i64 %ld62, ptr %slot13, align 8
  %v63 = load i64, ptr %slot1, align 8
  %p64 = inttoptr i64 %v63 to ptr
  %v65 = load i64, ptr %slot13, align 8
  %call66 = call i64 @myl_qbe_float_unary(ptr %p64, i64 10, i64 %v65) nomerge, !dbg !110
  store i64 %call66, ptr %slot14, align 8
  %v67 = load i64, ptr %slot14, align 8
  %v68 = load i64, ptr %slot7, align 8
  %p69 = inttoptr i64 %v68 to ptr
  store i64 %v67, ptr %p69, align 8, !alias.scope !3, !noalias !4
  %v70 = load i64, ptr %slot7, align 8
  %p71 = inttoptr i64 %v70 to ptr
  %ld72 = load i64, ptr %p71, align 8, !alias.scope !3, !noalias !4
  store i64 %ld72, ptr %slot15, align 8
  %v73 = load i64, ptr %slot5, align 8
  store i64 %v73, ptr %slot16, align 8
  %v74 = load i64, ptr %slot15, align 8
  %v75 = load i64, ptr %slot16, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 %v74, ptr %p76, align 8, !alias.scope !3, !noalias !4
  %v77 = load i64, ptr %slot7, align 8
  %p78 = inttoptr i64 %v77 to ptr
  store i64 4741671816366391296, ptr %p78, align 8, !alias.scope !3, !noalias !4
  %v79 = load i64, ptr %slot7, align 8
  %p80 = inttoptr i64 %v79 to ptr
  %ld81 = load i64, ptr %p80, align 8, !alias.scope !3, !noalias !4
  store i64 %ld81, ptr %slot17, align 8
  %v82 = load i64, ptr %slot6, align 8
  store i64 %v82, ptr %slot18, align 8
  %v83 = load i64, ptr %slot17, align 8
  %v84 = load i64, ptr %slot18, align 8
  %p85 = inttoptr i64 %v84 to ptr
  store i64 %v83, ptr %p85, align 8, !alias.scope !3, !noalias !4
  %v86 = load i64, ptr %slot5, align 8
  %p87 = inttoptr i64 %v86 to ptr
  %ld88 = load i64, ptr %p87, align 8, !alias.scope !3, !noalias !4
  store i64 %ld88, ptr %slot19, align 8
  %v89 = load i64, ptr %slot19, align 8
  %v90 = load i64, ptr %slot7, align 8
  %p91 = inttoptr i64 %v90 to ptr
  store i64 %v89, ptr %p91, align 8, !alias.scope !3, !noalias !4
  %v92 = load i64, ptr %slot6, align 8
  %p93 = inttoptr i64 %v92 to ptr
  %ld94 = load i64, ptr %p93, align 8, !alias.scope !3, !noalias !4
  store i64 %ld94, ptr %slot20, align 8
  %v95 = load i64, ptr %slot20, align 8
  %v96 = load i64, ptr %slot8, align 8
  %p97 = inttoptr i64 %v96 to ptr
  store i64 %v95, ptr %p97, align 8, !alias.scope !3, !noalias !4
  %v98 = load i64, ptr %slot8, align 8
  %p99 = inttoptr i64 %v98 to ptr
  %ld100 = load i64, ptr %p99, align 8, !alias.scope !3, !noalias !4
  store i64 %ld100, ptr %slot21, align 8
  %v101 = load i64, ptr %slot7, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %ld103 = load i64, ptr %p102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld103, ptr %slot22, align 8
  %v104 = load i64, ptr %slot22, align 8
  %cast105 = bitcast i64 %v104 to double
  store double %cast105, ptr %slot23, align 8
  %v106 = load i64, ptr %slot21, align 8
  %cast107 = bitcast i64 %v106 to double
  store double %cast107, ptr %slot24, align 8
  %v108 = load double, ptr %slot23, align 8
  %v109 = load double, ptr %slot24, align 8
  %op110 = fdiv double %v108, %v109
  store double %op110, ptr %slot25, align 8
  %v111 = load double, ptr %slot25, align 8
  %cast112 = bitcast double %v111 to i64
  store i64 %cast112, ptr %slot26, align 8
  %v113 = load i64, ptr %slot26, align 8
  %v114 = load i64, ptr %slot7, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 %v113, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot7, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot27, align 8
  %v119 = load i64, ptr %slot27, align 8
  ret i64 %v119
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare i64 @myl_qbe_float_unary(ptr, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_99acd1c3eff0ba297e719848049543d3ba565214e9d565a43a4798328402ac93", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_99acd1c3eff0ba297e719848049543d3ba565214e9d565a43a4798328402ac93", linkageName: "myl_f_99acd1c3eff0ba297e719848049543d3ba565214e9d565a43a4798328402ac93", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3033582971530227219, i64 0, !"myl_f_99acd1c3eff0ba297e719848049543d3ba565214e9d565a43a4798328402ac93"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
