target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_8a9892bcaf1d54845365507fdbe66f11290e39bbcea0301e2767f370744c950d(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %callresult239 = alloca [24 x i8], align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v472 = load i64, ptr %slot1, align 8
  %op473 = add i64 %v472, 32
  store i64 %op473, ptr %slot4, align 8
  %mem474 = alloca i8, i64 24, align 8
  %ptr475 = ptrtoint ptr %mem474 to i64
  store i64 %ptr475, ptr %slot5, align 8
  %mem476 = alloca i8, i64 8, align 8
  %ptr477 = ptrtoint ptr %mem476 to i64
  store i64 %ptr477, ptr %slot6, align 8
  %mem478 = alloca i8, i64 8, align 8
  %ptr479 = ptrtoint ptr %mem478 to i64
  store i64 %ptr479, ptr %slot7, align 8
  %mem480 = alloca i8, i64 8, align 8
  %ptr481 = ptrtoint ptr %mem480 to i64
  store i64 %ptr481, ptr %slot8, align 8
  %mem482 = alloca i8, i64 8, align 8
  %ptr483 = ptrtoint ptr %mem482 to i64
  store i64 %ptr483, ptr %slot9, align 8
  %mem484 = alloca i8, i64 8, align 8
  %ptr485 = ptrtoint ptr %mem484 to i64
  store i64 %ptr485, ptr %slot10, align 8
  %mem486 = alloca i8, i64 8, align 8
  %ptr487 = ptrtoint ptr %mem486 to i64
  store i64 %ptr487, ptr %slot11, align 8
  %mem488 = alloca i8, i64 8, align 8
  %ptr489 = ptrtoint ptr %mem488 to i64
  store i64 %ptr489, ptr %slot12, align 8
  %mem490 = alloca i8, i64 304, align 8
  %ptr491 = ptrtoint ptr %mem490 to i64
  store i64 %ptr491, ptr %slot13, align 8
  %mem492 = alloca i8, i64 8, align 8
  %ptr493 = ptrtoint ptr %mem492 to i64
  store i64 %ptr493, ptr %slot14, align 8
  %mem494 = alloca i8, i64 304, align 8
  %ptr495 = ptrtoint ptr %mem494 to i64
  store i64 %ptr495, ptr %slot15, align 8
  %mem496 = alloca i8, i64 8, align 8
  %ptr497 = ptrtoint ptr %mem496 to i64
  store i64 %ptr497, ptr %slot16, align 8
  %mem498 = alloca i8, i64 8, align 8
  %ptr499 = ptrtoint ptr %mem498 to i64
  store i64 %ptr499, ptr %slot17, align 8
  %mem500 = alloca i8, i64 8, align 8
  %ptr501 = ptrtoint ptr %mem500 to i64
  store i64 %ptr501, ptr %slot18, align 8
  %mem502 = alloca i8, i64 8, align 8
  %ptr503 = ptrtoint ptr %mem502 to i64
  store i64 %ptr503, ptr %slot19, align 8
  %mem504 = alloca i8, i64 8, align 8
  %ptr505 = ptrtoint ptr %mem504 to i64
  store i64 %ptr505, ptr %slot20, align 8
  %mem506 = alloca i8, i64 8, align 8
  %ptr507 = ptrtoint ptr %mem506 to i64
  store i64 %ptr507, ptr %slot21, align 8
  %mem508 = alloca i8, i64 8, align 8
  %ptr509 = ptrtoint ptr %mem508 to i64
  store i64 %ptr509, ptr %slot22, align 8
  %mem510 = alloca i8, i64 8, align 8
  %ptr511 = ptrtoint ptr %mem510 to i64
  store i64 %ptr511, ptr %slot23, align 8
  %mem512 = alloca i8, i64 8, align 8
  %ptr513 = ptrtoint ptr %mem512 to i64
  store i64 %ptr513, ptr %slot24, align 8
  %mem514 = alloca i8, i64 8, align 8
  %ptr515 = ptrtoint ptr %mem514 to i64
  store i64 %ptr515, ptr %slot25, align 8
  %mem516 = alloca i8, i64 8, align 8
  %ptr517 = ptrtoint ptr %mem516 to i64
  store i64 %ptr517, ptr %slot26, align 8
  %mem518 = alloca i8, i64 24, align 8
  %ptr519 = ptrtoint ptr %mem518 to i64
  store i64 %ptr519, ptr %slot27, align 8
  %mem520 = alloca i8, i64 8, align 8
  %ptr521 = ptrtoint ptr %mem520 to i64
  store i64 %ptr521, ptr %slot28, align 8
  %mem522 = alloca i8, i64 24, align 8
  %ptr523 = ptrtoint ptr %mem522 to i64
  store i64 %ptr523, ptr %slot29, align 8
  %mem524 = alloca i8, i64 8, align 8
  %ptr525 = ptrtoint ptr %mem524 to i64
  store i64 %ptr525, ptr %slot30, align 8
  %mem526 = alloca i8, i64 24, align 8
  %ptr527 = ptrtoint ptr %mem526 to i64
  store i64 %ptr527, ptr %slot31, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem528 = alloca i8, i64 8, align 8
  %ptr529 = ptrtoint ptr %mem528 to i64
  store i64 %ptr529, ptr %slot32, align 8
  %v530 = load i64, ptr %slot1, align 8
  %op531 = add i64 %v530, 64
  store i64 %op531, ptr %slot33, align 8
  %v532 = load i64, ptr %slot33, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %ld534 = load i64, ptr %p533, align 8, !alias.scope !4, !noalias !3
  store i64 %ld534, ptr %slot34, align 8
  %stack535 = call ptr @llvm.stacksave()
  %stackaddr536 = ptrtoint ptr %stack535 to i64
  %v537 = load i64, ptr %slot34, align 8
  %cmp538 = icmp ult i64 %stackaddr536, %v537
  %cv539 = zext i1 %cmp538 to i64
  store i64 %cv539, ptr %slot35, align 8
  %v540 = load i64, ptr %slot35, align 8
  %cond541 = icmp ne i64 %v540, 0
  br i1 %cond541, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v542 = load i64, ptr %slot1, align 8
  %p543 = inttoptr i64 %v542 to ptr
  call void @myl_qbe_fail_frame(ptr %p543) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v544 = load i64, ptr %slot18, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i64 0, ptr %p545, align 8, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot20, align 8
  %p547 = inttoptr i64 %v546 to ptr
  store i64 0, ptr %p547, align 8, !alias.scope !3, !noalias !4
  %v548 = load i64, ptr %slot2, align 8
  %v549 = load i64, ptr %slot16, align 8
  %p550 = inttoptr i64 %v549 to ptr
  store i64 %v548, ptr %p550, align 8, !alias.scope !3, !noalias !4
  %v551 = load i64, ptr %slot3, align 8
  %v552 = load i64, ptr %slot17, align 8
  %p553 = inttoptr i64 %v552 to ptr
  store i64 %v551, ptr %p553, align 8, !alias.scope !3, !noalias !4
  %v554 = load i64, ptr %slot1, align 8
  %p555 = inttoptr i64 %v554 to ptr
  %call556 = call ptr @myl_qbe_heap(ptr %p555) nomerge, !dbg !112
  %calladdr557 = ptrtoint ptr %call556 to i64
  store i64 %calladdr557, ptr %slot36, align 8
  %v558 = load i64, ptr %slot1, align 8
  %p559 = inttoptr i64 %v558 to ptr
  %call560 = call i64 @myl_qbe_region_mark(ptr %p559) nomerge, !dbg !112
  store i64 %call560, ptr %slot37, align 8
  %v561 = load i64, ptr %slot6, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i32 0, ptr %p562, align 4, !alias.scope !3, !noalias !4
  %v563 = load i64, ptr %slot7, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 0, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot8, align 8
  %p566 = inttoptr i64 %v565 to ptr
  store i32 0, ptr %p566, align 4, !alias.scope !3, !noalias !4
  %v567 = load i64, ptr %slot9, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i32 0, ptr %p568, align 4, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot10, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i32 0, ptr %p570, align 4, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot11, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i32 0, ptr %p572, align 4, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot12, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i32 0, ptr %p574, align 4, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot7, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i32 2, ptr %p576, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v577 = load i64, ptr %slot16, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld579, ptr %slot38, align 8
  %v580 = load i64, ptr %slot38, align 8
  %v581 = load i64, ptr %slot25, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 %v580, ptr %p582, align 8, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot25, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot39, align 8
  %v586 = load i64, ptr %slot39, align 8
  %op587 = add i64 %v586, 0
  store i64 %op587, ptr %slot40, align 8
  %v588 = load i64, ptr %slot40, align 8
  %v589 = load i64, ptr %slot25, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i64 %v588, ptr %p590, align 8, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot8, align 8
  %p592 = inttoptr i64 %v591 to ptr
  %ld593 = load i32, ptr %p592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld593, ptr %slot41, align 8
  %v594 = load i32, ptr %slot41, align 8
  %cv595 = zext i32 %v594 to i64
  %cond596 = icmp ne i64 %cv595, 0
  br i1 %cond596, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v597 = load i64, ptr %slot8, align 8
  %p598 = inttoptr i64 %v597 to ptr
  store i32 0, ptr %p598, align 4, !alias.scope !3, !noalias !4
  %v599 = load i64, ptr %slot13, align 8
  store i64 %v599, ptr %slot42, align 8
  %v600 = load i64, ptr %slot9, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %ld602 = load i32, ptr %p601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld602, ptr %slot43, align 8
  %v603 = load i32, ptr %slot43, align 8
  %op604 = and i32 %v603, 28
  store i32 %op604, ptr %slot44, align 8
  %v605 = load i32, ptr %slot44, align 8
  %cv606 = zext i32 %v605 to i64
  %cond607 = icmp ne i64 %cv606, 0
  br i1 %cond607, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v608 = load i64, ptr %slot36, align 8
  store i64 %v608, ptr %slot45, align 8
  %v609 = load i64, ptr %slot45, align 8
  %v610 = load i64, ptr %slot42, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v609, i64 %v610) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v611 = load i64, ptr %slot36, align 8
  store i64 %v611, ptr %slot46, align 8
  %v612 = load i64, ptr %slot46, align 8
  %v613 = load i64, ptr %slot42, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v612, i64 %v613) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v614 = load i64, ptr %slot25, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %ld616 = load i64, ptr %p615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld616, ptr %slot47, align 8
  %v617 = load i64, ptr %slot47, align 8
  %op618 = add i64 %v617, 16
  store i64 %op618, ptr %slot48, align 8
  %v619 = load i64, ptr %slot48, align 8
  %p620 = inttoptr i64 %v619 to ptr
  %ld621 = load i64, ptr %p620, align 8, !alias.scope !4, !noalias !3
  store i64 %ld621, ptr %slot49, align 8
  %v622 = load i64, ptr %slot49, align 8
  %v623 = load i64, ptr %slot25, align 8
  %p624 = inttoptr i64 %v623 to ptr
  store i64 %v622, ptr %p624, align 8, !alias.scope !3, !noalias !4
  %v625 = load i64, ptr %slot8, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ld627 = load i32, ptr %p626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld627, ptr %slot50, align 8
  %v628 = load i32, ptr %slot50, align 8
  %cv629 = zext i32 %v628 to i64
  %cond630 = icmp ne i64 %cv629, 0
  br i1 %cond630, label %bb_rcslotdrop27, label %bb_rcslotdone27
bb_rcslotdrop27:
  %v631 = load i64, ptr %slot8, align 8
  %p632 = inttoptr i64 %v631 to ptr
  store i32 0, ptr %p632, align 4, !alias.scope !3, !noalias !4
  %v633 = load i64, ptr %slot13, align 8
  store i64 %v633, ptr %slot51, align 8
  %v634 = load i64, ptr %slot9, align 8
  %p635 = inttoptr i64 %v634 to ptr
  %ld636 = load i32, ptr %p635, align 4, !alias.scope !3, !noalias !4
  store i32 %ld636, ptr %slot52, align 8
  %v637 = load i32, ptr %slot52, align 8
  %op638 = and i32 %v637, 28
  store i32 %op638, ptr %slot53, align 8
  %v639 = load i32, ptr %slot53, align 8
  %cv640 = zext i32 %v639 to i64
  %cond641 = icmp ne i64 %cv640, 0
  br i1 %cond641, label %bb_rcslotrole27, label %bb_rcslotowner27
bb_rcslotrole27:
  %v642 = load i64, ptr %slot36, align 8
  store i64 %v642, ptr %slot54, align 8
  %v643 = load i64, ptr %slot54, align 8
  %v644 = load i64, ptr %slot51, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v643, i64 %v644) nomerge, !dbg !116
  br label %bb_rcslotdone27
bb_rcslotowner27:
  %v645 = load i64, ptr %slot36, align 8
  store i64 %v645, ptr %slot55, align 8
  %v646 = load i64, ptr %slot55, align 8
  %v647 = load i64, ptr %slot51, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v646, i64 %v647) nomerge, !dbg !116
  br label %bb_rcslotdone27
bb_rcslotdone27:
  %v648 = load i64, ptr %slot25, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i64, ptr %p649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld650, ptr %slot56, align 8
  %v651 = load i64, ptr %slot56, align 8
  %v652 = load i64, ptr %slot18, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i64 %v651, ptr %p653, align 8, !alias.scope !3, !noalias !4
  %v654 = load i64, ptr %slot17, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i64, ptr %p655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld656, ptr %slot57, align 8
  %v657 = load i64, ptr %slot57, align 8
  %v658 = load i64, ptr %slot25, align 8
  %p659 = inttoptr i64 %v658 to ptr
  store i64 %v657, ptr %p659, align 8, !alias.scope !3, !noalias !4
  %v660 = load i64, ptr %slot25, align 8
  %p661 = inttoptr i64 %v660 to ptr
  %ld662 = load i64, ptr %p661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld662, ptr %slot58, align 8
  %v663 = load i64, ptr %slot58, align 8
  %v664 = load i64, ptr %slot19, align 8
  %p665 = inttoptr i64 %v664 to ptr
  store i64 %v663, ptr %p665, align 8, !alias.scope !3, !noalias !4
  %v666 = load i64, ptr %slot19, align 8
  %p667 = inttoptr i64 %v666 to ptr
  %ld668 = load i64, ptr %p667, align 8, !alias.scope !3, !noalias !4
  store i64 %ld668, ptr %slot59, align 8
  %v669 = load i64, ptr %slot59, align 8
  %v670 = load i64, ptr %slot25, align 8
  %p671 = inttoptr i64 %v670 to ptr
  store i64 %v669, ptr %p671, align 8, !alias.scope !3, !noalias !4
  %v672 = load i64, ptr %slot26, align 8
  %p673 = inttoptr i64 %v672 to ptr
  store i64 0, ptr %p673, align 8, !alias.scope !3, !noalias !4
  %v674 = load i64, ptr %slot26, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %ld676 = load i64, ptr %p675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld676, ptr %slot60, align 8
  %v677 = load i64, ptr %slot25, align 8
  %p678 = inttoptr i64 %v677 to ptr
  %ld679 = load i64, ptr %p678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld679, ptr %slot61, align 8
  %v680 = load i64, ptr %slot61, align 8
  %v681 = load i64, ptr %slot60, align 8
  %cmp682 = icmp slt i64 %v680, %v681
  %cv683 = zext i1 %cmp682 to i64
  store i64 %cv683, ptr %slot62, align 8
  %v684 = load i64, ptr %slot62, align 8
  %v685 = load i64, ptr %slot25, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i64 %v684, ptr %p686, align 8, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot25, align 8
  %p688 = inttoptr i64 %v687 to ptr
  %ld689 = load i64, ptr %p688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld689, ptr %slot63, align 8
  %v690 = load i64, ptr %slot63, align 8
  %cond691 = icmp ne i64 %v690, 0
  br i1 %cond691, label %bb_next42, label %bb_i15
bb_next42:
  %v692 = load i64, ptr %slot18, align 8
  %p693 = inttoptr i64 %v692 to ptr
  %ld694 = load i64, ptr %p693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld694, ptr %slot64, align 8
  %v695 = load i64, ptr %slot64, align 8
  %op696 = add i64 %v695, 0
  store i64 %op696, ptr %slot65, align 8
  %v697 = load i64, ptr %slot65, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i64, ptr %p698, align 8, !alias.scope !6, !noalias !7
  store i64 %ld699, ptr %slot66, align 8
  %v700 = load i64, ptr %slot66, align 8
  %v701 = load i64, ptr %slot25, align 8
  %p702 = inttoptr i64 %v701 to ptr
  store i64 %v700, ptr %p702, align 8, !alias.scope !3, !noalias !4
  %v703 = load i64, ptr %slot25, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %ld705 = load i64, ptr %p704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld705, ptr %slot67, align 8
  %v706 = load i64, ptr %slot67, align 8
  %cmp707 = icmp ugt i64 %v706, 9223372036854775807
  %cv708 = zext i1 %cmp707 to i64
  store i64 %cv708, ptr %slot68, align 8
  %v709 = load i64, ptr %slot68, align 8
  %cond710 = icmp ne i64 %v709, 0
  br i1 %cond710, label %bb_cast_overflow47, label %bb_cast_ok47
bb_cast_overflow47:
  %v711 = load i64, ptr %slot1, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %v713 = load i64, ptr %slot67, align 8
  call void @myl_qbe_fail_cast(ptr %p712, i64 %v713, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok47:
  %v714 = load i64, ptr %slot67, align 8
  %v715 = load i64, ptr %slot25, align 8
  %p716 = inttoptr i64 %v715 to ptr
  store i64 %v714, ptr %p716, align 8, !alias.scope !3, !noalias !4
  %v717 = load i64, ptr %slot19, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %ld719 = load i64, ptr %p718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld719, ptr %slot69, align 8
  %v720 = load i64, ptr %slot69, align 8
  %v721 = load i64, ptr %slot26, align 8
  %p722 = inttoptr i64 %v721 to ptr
  store i64 %v720, ptr %p722, align 8, !alias.scope !3, !noalias !4
  %v723 = load i64, ptr %slot26, align 8
  %p724 = inttoptr i64 %v723 to ptr
  %ld725 = load i64, ptr %p724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld725, ptr %slot70, align 8
  %v726 = load i64, ptr %slot25, align 8
  %p727 = inttoptr i64 %v726 to ptr
  %ld728 = load i64, ptr %p727, align 8, !alias.scope !3, !noalias !4
  store i64 %ld728, ptr %slot71, align 8
  %v729 = load i64, ptr %slot71, align 8
  %v730 = load i64, ptr %slot70, align 8
  %ovpair732 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v729, i64 %v730)
  %op731 = extractvalue { i64, i1 } %ovpair732, 0
  %ov733 = extractvalue { i64, i1 } %ovpair732, 1
  store i64 %op731, ptr %slot72, align 8
  %v734 = load i64, ptr %slot71, align 8
  %v735 = load i64, ptr %slot72, align 8
  %op736 = xor i64 %v734, %v735
  store i64 %op736, ptr %slot73, align 8
  %v737 = load i64, ptr %slot70, align 8
  %v738 = load i64, ptr %slot72, align 8
  %op739 = xor i64 %v737, %v738
  store i64 %op739, ptr %slot74, align 8
  %v740 = load i64, ptr %slot73, align 8
  %v741 = load i64, ptr %slot74, align 8
  %op742 = and i64 %v740, %v741
  store i64 %op742, ptr %slot75, align 8
  %cv743 = zext i1 %ov733 to i64
  store i64 %cv743, ptr %slot76, align 8
  %v744 = load i64, ptr %slot76, align 8
  %cond745 = icmp ne i64 %v744, 0
  br i1 %cond745, label %bb_overflow51, label %bb_checked51
bb_overflow51:
  %v746 = load i64, ptr %slot1, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %v748 = load i64, ptr %slot71, align 8
  %v749 = load i64, ptr %slot70, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p747, i64 0, i64 %v748, i64 %v749, i64 64) nomerge, !dbg !120
  unreachable
bb_checked51:
  %v750 = load i64, ptr %slot72, align 8
  %v751 = load i64, ptr %slot25, align 8
  %p752 = inttoptr i64 %v751 to ptr
  store i64 %v750, ptr %p752, align 8, !alias.scope !3, !noalias !4
  %v753 = load i64, ptr %slot25, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %ld755 = load i64, ptr %p754, align 8, !alias.scope !3, !noalias !4
  store i64 %ld755, ptr %slot77, align 8
  %v756 = load i64, ptr %slot77, align 8
  %v757 = load i64, ptr %slot19, align 8
  %p758 = inttoptr i64 %v757 to ptr
  store i64 %v756, ptr %p758, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v759 = load i64, ptr %slot19, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %ld761 = load i64, ptr %p760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld761, ptr %slot78, align 8
  %v762 = load i64, ptr %slot78, align 8
  %v763 = load i64, ptr %slot25, align 8
  %p764 = inttoptr i64 %v763 to ptr
  store i64 %v762, ptr %p764, align 8, !alias.scope !3, !noalias !4
  %v765 = load i64, ptr %slot18, align 8
  %p766 = inttoptr i64 %v765 to ptr
  %ld767 = load i64, ptr %p766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld767, ptr %slot79, align 8
  %v768 = load i64, ptr %slot25, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %ld770 = load i64, ptr %p769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld770, ptr %slot80, align 8
  %v771 = load i64, ptr %slot79, align 8
  %p772 = inttoptr i64 %v771 to ptr
  %ld773 = load i64, ptr %p772, align 8, !alias.scope !6, !noalias !7
  store i64 %ld773, ptr %slot81, align 8
  %v774 = load i64, ptr %slot80, align 8
  %v775 = load i64, ptr %slot81, align 8
  %cmp776 = icmp ult i64 %v774, %v775
  %cv777 = zext i1 %cmp776 to i64
  store i64 %cv777, ptr %slot82, align 8
  %v778 = load i64, ptr %slot82, align 8
  %cond779 = icmp ne i64 %v778, 0
  br i1 %cond779, label %bb_success63, label %bb_failed63
bb_failed63:
  %v780 = load i64, ptr %slot1, align 8
  %p781 = inttoptr i64 %v780 to ptr
  %v782 = load i64, ptr %slot80, align 8
  %v783 = load i64, ptr %slot81, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p781, i64 %v782, i64 %v783) nomerge, !dbg !122
  unreachable
bb_success63:
  %v784 = load i64, ptr %slot79, align 8
  %op785 = add i64 %v784, 32
  store i64 %op785, ptr %slot83, align 8
  %v786 = load i64, ptr %slot83, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i64, ptr %p787, align 8, !alias.scope !6, !noalias !7
  store i64 %ld788, ptr %slot84, align 8
  %v789 = load i64, ptr %slot80, align 8
  %op790 = mul i64 %v789, 80
  store i64 %op790, ptr %slot85, align 8
  %v791 = load i64, ptr %slot84, align 8
  %v792 = load i64, ptr %slot85, align 8
  %op793 = add i64 %v791, %v792
  store i64 %op793, ptr %slot86, align 8
  %v794 = load i64, ptr %slot86, align 8
  %v795 = load i64, ptr %slot25, align 8
  %p796 = inttoptr i64 %v795 to ptr
  store i64 %v794, ptr %p796, align 8, !alias.scope !3, !noalias !4
  %v797 = load i64, ptr %slot25, align 8
  %p798 = inttoptr i64 %v797 to ptr
  %ld799 = load i64, ptr %p798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld799, ptr %slot87, align 8
  %v800 = load i64, ptr %slot15, align 8
  store i64 %v800, ptr %slot88, align 8
  %v801 = load i64, ptr %slot36, align 8
  %v802 = load i64, ptr %slot88, align 8
  %v803 = load i64, ptr %slot87, align 8
  %call804 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64 %v801, i64 %v802, i64 %v803) nomerge, !dbg !122
  store i32 %call804, ptr %slot89, align 8
  %v805 = load i32, ptr %slot89, align 8
  %cv806 = zext i32 %v805 to i64
  %cond807 = icmp ne i64 %cv806, 0
  br i1 %cond807, label %bb_rcsuccess71, label %bb_rcfailure71
bb_rcfailure71:
  %v808 = load i64, ptr %slot36, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %call810 = call i32 @myl_rc_take_failure(ptr %p809) nomerge, !dbg !122
  store i32 %call810, ptr %slot90, align 8
  %v811 = load i64, ptr %slot1, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %v813 = load i32, ptr %slot90, align 8
  %call814 = call i32 @myl_qbe_rc_status(ptr %p812, i32 %v813) nomerge, !dbg !122
  store i32 %call814, ptr %slot91, align 8
  br label %bb_failure
bb_rcsuccess71:
  %v815 = load i64, ptr %slot11, align 8
  %p816 = inttoptr i64 %v815 to ptr
  store i32 2, ptr %p816, align 4, !alias.scope !3, !noalias !4
  %v817 = load i64, ptr %slot11, align 8
  %p818 = inttoptr i64 %v817 to ptr
  store i32 16, ptr %p818, align 4, !alias.scope !3, !noalias !4
  %v819 = load i64, ptr %slot10, align 8
  %p820 = inttoptr i64 %v819 to ptr
  store i32 1, ptr %p820, align 4, !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot13, align 8
  store i64 %v821, ptr %slot92, align 8
  %v822 = load i64, ptr %slot15, align 8
  store i64 %v822, ptr %slot93, align 8
  %v823 = load i64, ptr %slot93, align 8
  %v824 = load i64, ptr %slot92, align 8
  %p825 = inttoptr i64 %v823 to ptr
  %p826 = inttoptr i64 %v824 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p826, ptr %p825, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v827 = load i64, ptr %slot9, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i32 2, ptr %p828, align 4, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot11, align 8
  %p830 = inttoptr i64 %v829 to ptr
  %ld831 = load i32, ptr %p830, align 4, !alias.scope !3, !noalias !4
  store i32 %ld831, ptr %slot94, align 8
  %v832 = load i32, ptr %slot94, align 8
  %v833 = load i64, ptr %slot9, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i32 %v832, ptr %p834, align 4, !alias.scope !3, !noalias !4
  %v835 = load i64, ptr %slot10, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i32 0, ptr %p836, align 4, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot8, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i32 1, ptr %p838, align 4, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot92, align 8
  %v840 = load i64, ptr %slot25, align 8
  %p841 = inttoptr i64 %v840 to ptr
  store i64 %v839, ptr %p841, align 8, !alias.scope !3, !noalias !4
  %v842 = load i64, ptr %slot25, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %ld844 = load i64, ptr %p843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld844, ptr %slot95, align 8
  %v845 = load i64, ptr %slot95, align 8
  %op846 = add i64 %v845, 56
  store i64 %op846, ptr %slot96, align 8
  %v847 = load i64, ptr %slot96, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %ld849 = load i64, ptr %p848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld849, ptr %slot97, align 8
  %v850 = load i64, ptr %slot97, align 8
  %v851 = load i64, ptr %slot25, align 8
  %p852 = inttoptr i64 %v851 to ptr
  store i64 %v850, ptr %p852, align 8, !alias.scope !3, !noalias !4
  %v853 = load i64, ptr %slot25, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %ld855 = load i64, ptr %p854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld855, ptr %slot98, align 8
  %v856 = load i64, ptr %slot98, align 8
  %v857 = load i64, ptr %slot14, align 8
  %p858 = inttoptr i64 %v857 to ptr
  store i64 %v856, ptr %p858, align 8, !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot14, align 8
  store i64 %v859, ptr %slot99, align 8
  %v860 = load i64, ptr %slot15, align 8
  store i64 %v860, ptr %slot100, align 8
  %v861 = load i64, ptr %slot99, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %ld863 = load i64, ptr %p862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld863, ptr %slot101, align 8
  %v864 = load i64, ptr %slot101, align 8
  %cmp865 = icmp ne i64 %v864, 0
  %cv866 = zext i1 %cmp865 to i32
  store i32 %cv866, ptr %slot102, align 8
  %v867 = load i32, ptr %slot102, align 8
  %cv868 = zext i32 %v867 to i64
  %cond869 = icmp ne i64 %cv868, 0
  br i1 %cond869, label %bb_rcgnn92, label %bb_rcgstore92
bb_rcgnn92:
  %v870 = load i64, ptr %slot101, align 8
  %op871 = sub i64 %v870, 16
  store i64 %op871, ptr %slot103, align 8
  %v872 = load i64, ptr %slot101, align 8
  %p873 = inttoptr i64 %v872 to ptr
  %rgep874 = getelementptr i8, ptr %p873, i64 -16
  %ld875 = load i64, ptr %rgep874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld875, ptr %slot104, align 8
  %v876 = load i64, ptr %slot104, align 8
  %op877 = and i64 %v876, 4611686018427387906
  store i64 %op877, ptr %slot105, align 8
  %v878 = load i64, ptr %slot105, align 8
  %cmp879 = icmp ne i64 %v878, 0
  %cv880 = zext i1 %cmp879 to i32
  store i32 %cv880, ptr %slot106, align 8
  %v881 = load i32, ptr %slot106, align 8
  %cv882 = zext i32 %v881 to i64
  %cond883 = icmp ne i64 %cv882, 0
  br i1 %cond883, label %bb_rcgstore92, label %bb_rcginc92
bb_rcginc92:
  %v884 = load i64, ptr %slot101, align 8
  %op885 = sub i64 %v884, 24
  store i64 %op885, ptr %slot107, align 8
  %v886 = load i64, ptr %slot101, align 8
  %p887 = inttoptr i64 %v886 to ptr
  %rgep888 = getelementptr i8, ptr %p887, i64 -24
  %ld889 = load i64, ptr %rgep888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld889, ptr %slot108, align 8
  %v890 = load i64, ptr %slot108, align 8
  %op891 = add i64 %v890, 1
  store i64 %op891, ptr %slot109, align 8
  %v892 = load i64, ptr %slot109, align 8
  %cmp893 = icmp eq i64 %v892, 0
  %cv894 = zext i1 %cmp893 to i32
  store i32 %cv894, ptr %slot110, align 8
  %v895 = load i32, ptr %slot110, align 8
  %cv896 = zext i32 %v895 to i64
  %cond897 = icmp ne i64 %cv896, 0
  br i1 %cond897, label %bb_rcglimit92, label %bb_rcgcapacity92
bb_rcglimit92:
  %v898 = load i64, ptr %slot1, align 8
  %p899 = inttoptr i64 %v898 to ptr
  %call900 = call i32 @myl_qbe_rc_status(ptr %p899, i32 2) nomerge, !dbg !124
  store i32 %call900, ptr %slot111, align 8
  br label %bb_failure
bb_rcgcapacity92:
  %v901 = load i64, ptr %slot109, align 8
  %v902 = load i64, ptr %slot101, align 8
  %p903 = inttoptr i64 %v902 to ptr
  %rgep904 = getelementptr i8, ptr %p903, i64 -24
  store i64 %v901, ptr %rgep904, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore92
bb_rcgstore92:
  %v905 = load i64, ptr %slot101, align 8
  %v906 = load i64, ptr %slot100, align 8
  %p907 = inttoptr i64 %v906 to ptr
  store i64 %v905, ptr %p907, align 8, !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot11, align 8
  %p909 = inttoptr i64 %v908 to ptr
  store i32 2, ptr %p909, align 4, !alias.scope !3, !noalias !4
  %v910 = load i64, ptr %slot11, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i32 16, ptr %p911, align 4, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot10, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i32 1, ptr %p913, align 4, !alias.scope !3, !noalias !4
  %v914 = load i64, ptr %slot8, align 8
  %p915 = inttoptr i64 %v914 to ptr
  %ld916 = load i32, ptr %p915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld916, ptr %slot112, align 8
  %v917 = load i32, ptr %slot112, align 8
  %cv918 = zext i32 %v917 to i64
  %cond919 = icmp ne i64 %cv918, 0
  br i1 %cond919, label %bb_rcslotdrop108, label %bb_rcslotdone108
bb_rcslotdrop108:
  %v920 = load i64, ptr %slot8, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i32 0, ptr %p921, align 4, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot13, align 8
  store i64 %v922, ptr %slot113, align 8
  %v923 = load i64, ptr %slot9, align 8
  %p924 = inttoptr i64 %v923 to ptr
  %ld925 = load i32, ptr %p924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld925, ptr %slot114, align 8
  %v926 = load i32, ptr %slot114, align 8
  %op927 = and i32 %v926, 28
  store i32 %op927, ptr %slot115, align 8
  %v928 = load i32, ptr %slot115, align 8
  %cv929 = zext i32 %v928 to i64
  %cond930 = icmp ne i64 %cv929, 0
  br i1 %cond930, label %bb_rcslotrole108, label %bb_rcslotowner108
bb_rcslotrole108:
  %v931 = load i64, ptr %slot36, align 8
  store i64 %v931, ptr %slot116, align 8
  %v932 = load i64, ptr %slot116, align 8
  %v933 = load i64, ptr %slot113, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v932, i64 %v933) nomerge, !dbg !124
  br label %bb_rcslotdone108
bb_rcslotowner108:
  %v934 = load i64, ptr %slot36, align 8
  store i64 %v934, ptr %slot117, align 8
  %v935 = load i64, ptr %slot117, align 8
  %v936 = load i64, ptr %slot113, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v935, i64 %v936) nomerge, !dbg !124
  br label %bb_rcslotdone108
bb_rcslotdone108:
  %v937 = load i64, ptr %slot13, align 8
  store i64 %v937, ptr %slot118, align 8
  %v938 = load i64, ptr %slot15, align 8
  store i64 %v938, ptr %slot119, align 8
  %v939 = load i64, ptr %slot119, align 8
  %v940 = load i64, ptr %slot118, align 8
  %p941 = inttoptr i64 %v939 to ptr
  %p942 = inttoptr i64 %v940 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p942, ptr %p941, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v943 = load i64, ptr %slot9, align 8
  %p944 = inttoptr i64 %v943 to ptr
  store i32 2, ptr %p944, align 4, !alias.scope !3, !noalias !4
  %v945 = load i64, ptr %slot11, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %ld947 = load i32, ptr %p946, align 4, !alias.scope !3, !noalias !4
  store i32 %ld947, ptr %slot120, align 8
  %v948 = load i32, ptr %slot120, align 8
  %v949 = load i64, ptr %slot9, align 8
  %p950 = inttoptr i64 %v949 to ptr
  store i32 %v948, ptr %p950, align 4, !alias.scope !3, !noalias !4
  %v951 = load i64, ptr %slot10, align 8
  %p952 = inttoptr i64 %v951 to ptr
  store i32 0, ptr %p952, align 4, !alias.scope !3, !noalias !4
  %v953 = load i64, ptr %slot8, align 8
  %p954 = inttoptr i64 %v953 to ptr
  store i32 1, ptr %p954, align 4, !alias.scope !3, !noalias !4
  %v955 = load i64, ptr %slot118, align 8
  %p956 = inttoptr i64 %v955 to ptr
  %ld957 = load i64, ptr %p956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld957, ptr %slot121, align 8
  %v958 = load i64, ptr %slot121, align 8
  %v959 = load i64, ptr %slot25, align 8
  %p960 = inttoptr i64 %v959 to ptr
  store i64 %v958, ptr %p960, align 8, !alias.scope !3, !noalias !4
  %v961 = load i64, ptr %slot25, align 8
  %p962 = inttoptr i64 %v961 to ptr
  %ld963 = load i64, ptr %p962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld963, ptr %slot122, align 8
  %v964 = load i64, ptr %slot15, align 8
  store i64 %v964, ptr %slot123, align 8
  %v965 = load i64, ptr %slot122, align 8
  %cmp966 = icmp ne i64 %v965, 0
  %cv967 = zext i1 %cmp966 to i32
  store i32 %cv967, ptr %slot124, align 8
  %v968 = load i32, ptr %slot124, align 8
  %cv969 = zext i32 %v968 to i64
  %cond970 = icmp ne i64 %cv969, 0
  br i1 %cond970, label %bb_rcgnn128, label %bb_rcgstore128
bb_rcgnn128:
  %v971 = load i64, ptr %slot122, align 8
  %op972 = sub i64 %v971, 16
  store i64 %op972, ptr %slot125, align 8
  %v973 = load i64, ptr %slot122, align 8
  %p974 = inttoptr i64 %v973 to ptr
  %rgep975 = getelementptr i8, ptr %p974, i64 -16
  %ld976 = load i64, ptr %rgep975, align 8, !alias.scope !9, !noalias !10
  store i64 %ld976, ptr %slot126, align 8
  %v977 = load i64, ptr %slot126, align 8
  %op978 = and i64 %v977, 4611686018427387906
  store i64 %op978, ptr %slot127, align 8
  %v979 = load i64, ptr %slot127, align 8
  %cmp980 = icmp ne i64 %v979, 0
  %cv981 = zext i1 %cmp980 to i32
  store i32 %cv981, ptr %slot128, align 8
  %v982 = load i32, ptr %slot128, align 8
  %cv983 = zext i32 %v982 to i64
  %cond984 = icmp ne i64 %cv983, 0
  br i1 %cond984, label %bb_rcgstore128, label %bb_rcginc128
bb_rcginc128:
  %v985 = load i64, ptr %slot122, align 8
  %op986 = sub i64 %v985, 24
  store i64 %op986, ptr %slot129, align 8
  %v987 = load i64, ptr %slot122, align 8
  %p988 = inttoptr i64 %v987 to ptr
  %rgep989 = getelementptr i8, ptr %p988, i64 -24
  %ld990 = load i64, ptr %rgep989, align 8, !alias.scope !9, !noalias !10
  store i64 %ld990, ptr %slot130, align 8
  %v991 = load i64, ptr %slot130, align 8
  %op992 = add i64 %v991, 1
  store i64 %op992, ptr %slot131, align 8
  %v993 = load i64, ptr %slot131, align 8
  %cmp994 = icmp eq i64 %v993, 0
  %cv995 = zext i1 %cmp994 to i32
  store i32 %cv995, ptr %slot132, align 8
  %v996 = load i32, ptr %slot132, align 8
  %cv997 = zext i32 %v996 to i64
  %cond998 = icmp ne i64 %cv997, 0
  br i1 %cond998, label %bb_rcglimit128, label %bb_rcgcapacity128
bb_rcglimit128:
  %v999 = load i64, ptr %slot1, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  %call1001 = call i32 @myl_qbe_rc_status(ptr %p1000, i32 2) nomerge, !dbg !126
  store i32 %call1001, ptr %slot133, align 8
  br label %bb_failure
bb_rcgcapacity128:
  %v1002 = load i64, ptr %slot131, align 8
  %v1003 = load i64, ptr %slot122, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  %rgep1005 = getelementptr i8, ptr %p1004, i64 -24
  store i64 %v1002, ptr %rgep1005, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore128
bb_rcgstore128:
  %v1006 = load i64, ptr %slot122, align 8
  %v1007 = load i64, ptr %slot123, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  store i64 %v1006, ptr %p1008, align 8, !alias.scope !3, !noalias !4
  %v1009 = load i64, ptr %slot11, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  store i32 2, ptr %p1010, align 4, !alias.scope !3, !noalias !4
  %v1011 = load i64, ptr %slot11, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  store i32 8, ptr %p1012, align 4, !alias.scope !3, !noalias !4
  %v1013 = load i64, ptr %slot10, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  store i32 1, ptr %p1014, align 4, !alias.scope !3, !noalias !4
  %v1015 = load i64, ptr %slot8, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %ld1017 = load i32, ptr %p1016, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1017, ptr %slot134, align 8
  %v1018 = load i32, ptr %slot134, align 8
  %cv1019 = zext i32 %v1018 to i64
  %cond1020 = icmp ne i64 %cv1019, 0
  br i1 %cond1020, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v1021 = load i64, ptr %slot8, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  store i32 0, ptr %p1022, align 4, !alias.scope !3, !noalias !4
  %v1023 = load i64, ptr %slot13, align 8
  store i64 %v1023, ptr %slot135, align 8
  %v1024 = load i64, ptr %slot9, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  %ld1026 = load i32, ptr %p1025, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1026, ptr %slot136, align 8
  %v1027 = load i32, ptr %slot136, align 8
  %op1028 = and i32 %v1027, 28
  store i32 %op1028, ptr %slot137, align 8
  %v1029 = load i32, ptr %slot137, align 8
  %cv1030 = zext i32 %v1029 to i64
  %cond1031 = icmp ne i64 %cv1030, 0
  br i1 %cond1031, label %bb_rcslotrole144, label %bb_rcslotowner144
bb_rcslotrole144:
  %v1032 = load i64, ptr %slot36, align 8
  store i64 %v1032, ptr %slot138, align 8
  %v1033 = load i64, ptr %slot135, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  %ld1035 = load i64, ptr %p1034, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1035, ptr %slot139, align 8
  %v1036 = load i64, ptr %slot139, align 8
  %cmp1037 = icmp ne i64 %v1036, 0
  %cv1038 = zext i1 %cmp1037 to i32
  store i32 %cv1038, ptr %slot140, align 8
  %v1039 = load i32, ptr %slot140, align 8
  %cv1040 = zext i32 %v1039 to i64
  %cond1041 = icmp ne i64 %cv1040, 0
  br i1 %cond1041, label %bb_rcgnn160, label %bb_rcgdone160
bb_rcgnn160:
  %v1042 = load i64, ptr %slot139, align 8
  %op1043 = sub i64 %v1042, 16
  store i64 %op1043, ptr %slot141, align 8
  %v1044 = load i64, ptr %slot139, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  %rgep1046 = getelementptr i8, ptr %p1045, i64 -16
  %ld1047 = load i64, ptr %rgep1046, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1047, ptr %slot142, align 8
  %v1048 = load i64, ptr %slot142, align 8
  %op1049 = and i64 %v1048, 4611686018427387906
  store i64 %op1049, ptr %slot143, align 8
  %v1050 = load i64, ptr %slot143, align 8
  %cmp1051 = icmp ne i64 %v1050, 0
  %cv1052 = zext i1 %cmp1051 to i32
  store i32 %cv1052, ptr %slot144, align 8
  %v1053 = load i32, ptr %slot144, align 8
  %cv1054 = zext i32 %v1053 to i64
  %cond1055 = icmp ne i64 %cv1054, 0
  br i1 %cond1055, label %bb_rcgclear160, label %bb_rcgcounted160
bb_rcgcounted160:
  %v1056 = load i64, ptr %slot139, align 8
  %op1057 = sub i64 %v1056, 24
  store i64 %op1057, ptr %slot145, align 8
  %v1058 = load i64, ptr %slot139, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %rgep1060 = getelementptr i8, ptr %p1059, i64 -24
  %ld1061 = load i64, ptr %rgep1060, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1061, ptr %slot146, align 8
  %v1062 = load i64, ptr %slot146, align 8
  %op1063 = sub i64 %v1062, 1
  store i64 %op1063, ptr %slot147, align 8
  %v1064 = load i64, ptr %slot147, align 8
  %cmp1065 = icmp eq i64 %v1064, 0
  %cv1066 = zext i1 %cmp1065 to i32
  store i32 %cv1066, ptr %slot148, align 8
  %v1067 = load i32, ptr %slot148, align 8
  %cv1068 = zext i32 %v1067 to i64
  %cond1069 = icmp ne i64 %cv1068, 0
  br i1 %cond1069, label %bb_rcglast160, label %bb_rcgdec160
bb_rcglast160:
  %v1070 = load i64, ptr %slot139, align 8
  %op1071 = sub i64 %v1070, 32
  store i64 %op1071, ptr %slot149, align 8
  %v1072 = load i64, ptr %slot139, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %rgep1074 = getelementptr i8, ptr %p1073, i64 -32
  %ld1075 = load i64, ptr %rgep1074, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1075, ptr %slot150, align 8
  %v1076 = load i64, ptr %slot150, align 8
  %cmp1077 = icmp ne i64 %v1076, 0
  %cv1078 = zext i1 %cmp1077 to i32
  store i32 %cv1078, ptr %slot151, align 8
  %v1079 = load i32, ptr %slot151, align 8
  %cv1080 = zext i32 %v1079 to i64
  %cond1081 = icmp ne i64 %cv1080, 0
  br i1 %cond1081, label %bb_rcgdec160, label %bb_rcgslow160
bb_rcgslow160:
  %v1082 = load i64, ptr %slot138, align 8
  %v1083 = load i64, ptr %slot135, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1082, i64 %v1083) nomerge, !dbg !126
  br label %bb_rcgdone160
bb_rcgdec160:
  %v1084 = load i64, ptr %slot147, align 8
  %v1085 = load i64, ptr %slot139, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  %rgep1087 = getelementptr i8, ptr %p1086, i64 -24
  store i64 %v1084, ptr %rgep1087, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear160
bb_rcgclear160:
  %v1088 = load i64, ptr %slot135, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  store i64 0, ptr %p1089, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone160
bb_rcgdone160:
  br label %bb_rcslotdone144
bb_rcslotowner144:
  %v1090 = load i64, ptr %slot36, align 8
  store i64 %v1090, ptr %slot152, align 8
  %v1091 = load i64, ptr %slot135, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  %ld1093 = load i64, ptr %p1092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1093, ptr %slot153, align 8
  %v1094 = load i64, ptr %slot153, align 8
  %cmp1095 = icmp ne i64 %v1094, 0
  %cv1096 = zext i1 %cmp1095 to i32
  store i32 %cv1096, ptr %slot154, align 8
  %v1097 = load i32, ptr %slot154, align 8
  %cv1098 = zext i32 %v1097 to i64
  %cond1099 = icmp ne i64 %cv1098, 0
  br i1 %cond1099, label %bb_rcgnn175, label %bb_rcgdone175
bb_rcgnn175:
  %v1100 = load i64, ptr %slot153, align 8
  %op1101 = sub i64 %v1100, 16
  store i64 %op1101, ptr %slot155, align 8
  %v1102 = load i64, ptr %slot153, align 8
  %p1103 = inttoptr i64 %v1102 to ptr
  %rgep1104 = getelementptr i8, ptr %p1103, i64 -16
  %ld1105 = load i64, ptr %rgep1104, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1105, ptr %slot156, align 8
  %v1106 = load i64, ptr %slot156, align 8
  %op1107 = and i64 %v1106, 4611686018427387906
  store i64 %op1107, ptr %slot157, align 8
  %v1108 = load i64, ptr %slot157, align 8
  %cmp1109 = icmp ne i64 %v1108, 0
  %cv1110 = zext i1 %cmp1109 to i32
  store i32 %cv1110, ptr %slot158, align 8
  %v1111 = load i32, ptr %slot158, align 8
  %cv1112 = zext i32 %v1111 to i64
  %cond1113 = icmp ne i64 %cv1112, 0
  br i1 %cond1113, label %bb_rcgclear175, label %bb_rcgcounted175
bb_rcgcounted175:
  %v1114 = load i64, ptr %slot153, align 8
  %op1115 = sub i64 %v1114, 32
  store i64 %op1115, ptr %slot159, align 8
  %v1116 = load i64, ptr %slot153, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  %rgep1118 = getelementptr i8, ptr %p1117, i64 -32
  %ld1119 = load i64, ptr %rgep1118, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1119, ptr %slot160, align 8
  %v1120 = load i64, ptr %slot160, align 8
  %op1121 = sub i64 %v1120, 1
  store i64 %op1121, ptr %slot161, align 8
  %v1122 = load i64, ptr %slot161, align 8
  %cmp1123 = icmp eq i64 %v1122, 0
  %cv1124 = zext i1 %cmp1123 to i32
  store i32 %cv1124, ptr %slot162, align 8
  %v1125 = load i32, ptr %slot162, align 8
  %cv1126 = zext i32 %v1125 to i64
  %cond1127 = icmp ne i64 %cv1126, 0
  br i1 %cond1127, label %bb_rcglast175, label %bb_rcgdec175
bb_rcglast175:
  %v1128 = load i64, ptr %slot153, align 8
  %op1129 = sub i64 %v1128, 24
  store i64 %op1129, ptr %slot163, align 8
  %v1130 = load i64, ptr %slot153, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  %rgep1132 = getelementptr i8, ptr %p1131, i64 -24
  %ld1133 = load i64, ptr %rgep1132, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1133, ptr %slot164, align 8
  %v1134 = load i64, ptr %slot164, align 8
  %cmp1135 = icmp ne i64 %v1134, 0
  %cv1136 = zext i1 %cmp1135 to i32
  store i32 %cv1136, ptr %slot165, align 8
  %v1137 = load i32, ptr %slot165, align 8
  %cv1138 = zext i32 %v1137 to i64
  %cond1139 = icmp ne i64 %cv1138, 0
  br i1 %cond1139, label %bb_rcgdec175, label %bb_rcgslow175
bb_rcgslow175:
  %v1140 = load i64, ptr %slot152, align 8
  %v1141 = load i64, ptr %slot135, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1140, i64 %v1141) nomerge, !dbg !126
  br label %bb_rcgdone175
bb_rcgdec175:
  %v1142 = load i64, ptr %slot161, align 8
  %v1143 = load i64, ptr %slot153, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  %rgep1145 = getelementptr i8, ptr %p1144, i64 -32
  store i64 %v1142, ptr %rgep1145, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear175
bb_rcgclear175:
  %v1146 = load i64, ptr %slot135, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i64 0, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone175
bb_rcgdone175:
  br label %bb_rcslotdone144
bb_rcslotdone144:
  %v1148 = load i64, ptr %slot13, align 8
  store i64 %v1148, ptr %slot166, align 8
  %v1149 = load i64, ptr %slot15, align 8
  store i64 %v1149, ptr %slot167, align 8
  %v1150 = load i64, ptr %slot167, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i64, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1152, ptr %slot168, align 8
  %v1153 = load i64, ptr %slot168, align 8
  %v1154 = load i64, ptr %slot166, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i64 %v1153, ptr %p1155, align 8, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot9, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  store i32 2, ptr %p1157, align 4, !alias.scope !3, !noalias !4
  %v1158 = load i64, ptr %slot9, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  store i32 8, ptr %p1159, align 4, !alias.scope !3, !noalias !4
  %v1160 = load i64, ptr %slot8, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  store i32 1, ptr %p1161, align 4, !alias.scope !3, !noalias !4
  %v1162 = load i64, ptr %slot10, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  store i32 0, ptr %p1163, align 4, !alias.scope !3, !noalias !4
  %v1164 = load i64, ptr %slot168, align 8
  %v1165 = load i64, ptr %slot25, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  store i64 %v1164, ptr %p1166, align 8, !alias.scope !3, !noalias !4
  %v1167 = load i64, ptr %slot15, align 8
  store i64 %v1167, ptr %slot169, align 8
  %v1168 = load i64, ptr %slot25, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %ld1170 = load i64, ptr %p1169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1170, ptr %slot170, align 8
  %v1171 = load i64, ptr %slot170, align 8
  %v1172 = load i64, ptr %slot169, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i64 %v1171, ptr %p1173, align 8, !alias.scope !3, !noalias !4
  %v1174 = load i64, ptr %slot11, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  store i32 2, ptr %p1175, align 4, !alias.scope !3, !noalias !4
  %v1176 = load i64, ptr %slot11, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i32 8, ptr %p1177, align 4, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot10, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  store i32 1, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  %v1180 = load i64, ptr %slot8, align 8
  %p1181 = inttoptr i64 %v1180 to ptr
  store i32 0, ptr %p1181, align 4, !alias.scope !3, !noalias !4
  %v1182 = load i64, ptr %slot6, align 8
  %p1183 = inttoptr i64 %v1182 to ptr
  %ld1184 = load i32, ptr %p1183, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1184, ptr %slot171, align 8
  %v1185 = load i32, ptr %slot171, align 8
  %cv1186 = zext i32 %v1185 to i64
  %cond1187 = icmp ne i64 %cv1186, 0
  br i1 %cond1187, label %bb_rcslotdrop194, label %bb_rcslotdone194
bb_rcslotdrop194:
  %v1188 = load i64, ptr %slot6, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  store i32 0, ptr %p1189, align 4, !alias.scope !3, !noalias !4
  %v1190 = load i64, ptr %slot20, align 8
  store i64 %v1190, ptr %slot172, align 8
  %v1191 = load i64, ptr %slot7, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %ld1193 = load i32, ptr %p1192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1193, ptr %slot173, align 8
  %v1194 = load i32, ptr %slot173, align 8
  %op1195 = and i32 %v1194, 28
  store i32 %op1195, ptr %slot174, align 8
  %v1196 = load i32, ptr %slot174, align 8
  %cv1197 = zext i32 %v1196 to i64
  %cond1198 = icmp ne i64 %cv1197, 0
  br i1 %cond1198, label %bb_rcslotrole194, label %bb_rcslotowner194
bb_rcslotrole194:
  %v1199 = load i64, ptr %slot36, align 8
  store i64 %v1199, ptr %slot175, align 8
  %v1200 = load i64, ptr %slot172, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  %ld1202 = load i64, ptr %p1201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1202, ptr %slot176, align 8
  %v1203 = load i64, ptr %slot176, align 8
  %cmp1204 = icmp ne i64 %v1203, 0
  %cv1205 = zext i1 %cmp1204 to i32
  store i32 %cv1205, ptr %slot177, align 8
  %v1206 = load i32, ptr %slot177, align 8
  %cv1207 = zext i32 %v1206 to i64
  %cond1208 = icmp ne i64 %cv1207, 0
  br i1 %cond1208, label %bb_rcgnn210, label %bb_rcgdone210
bb_rcgnn210:
  %v1209 = load i64, ptr %slot176, align 8
  %op1210 = sub i64 %v1209, 16
  store i64 %op1210, ptr %slot178, align 8
  %v1211 = load i64, ptr %slot176, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  %rgep1213 = getelementptr i8, ptr %p1212, i64 -16
  %ld1214 = load i64, ptr %rgep1213, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1214, ptr %slot179, align 8
  %v1215 = load i64, ptr %slot179, align 8
  %op1216 = and i64 %v1215, 4611686018427387906
  store i64 %op1216, ptr %slot180, align 8
  %v1217 = load i64, ptr %slot180, align 8
  %cmp1218 = icmp ne i64 %v1217, 0
  %cv1219 = zext i1 %cmp1218 to i32
  store i32 %cv1219, ptr %slot181, align 8
  %v1220 = load i32, ptr %slot181, align 8
  %cv1221 = zext i32 %v1220 to i64
  %cond1222 = icmp ne i64 %cv1221, 0
  br i1 %cond1222, label %bb_rcgclear210, label %bb_rcgcounted210
bb_rcgcounted210:
  %v1223 = load i64, ptr %slot176, align 8
  %op1224 = sub i64 %v1223, 24
  store i64 %op1224, ptr %slot182, align 8
  %v1225 = load i64, ptr %slot176, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  %rgep1227 = getelementptr i8, ptr %p1226, i64 -24
  %ld1228 = load i64, ptr %rgep1227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1228, ptr %slot183, align 8
  %v1229 = load i64, ptr %slot183, align 8
  %op1230 = sub i64 %v1229, 1
  store i64 %op1230, ptr %slot184, align 8
  %v1231 = load i64, ptr %slot184, align 8
  %cmp1232 = icmp eq i64 %v1231, 0
  %cv1233 = zext i1 %cmp1232 to i32
  store i32 %cv1233, ptr %slot185, align 8
  %v1234 = load i32, ptr %slot185, align 8
  %cv1235 = zext i32 %v1234 to i64
  %cond1236 = icmp ne i64 %cv1235, 0
  br i1 %cond1236, label %bb_rcglast210, label %bb_rcgdec210
bb_rcglast210:
  %v1237 = load i64, ptr %slot176, align 8
  %op1238 = sub i64 %v1237, 32
  store i64 %op1238, ptr %slot186, align 8
  %v1239 = load i64, ptr %slot176, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %rgep1241 = getelementptr i8, ptr %p1240, i64 -32
  %ld1242 = load i64, ptr %rgep1241, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1242, ptr %slot187, align 8
  %v1243 = load i64, ptr %slot187, align 8
  %cmp1244 = icmp ne i64 %v1243, 0
  %cv1245 = zext i1 %cmp1244 to i32
  store i32 %cv1245, ptr %slot188, align 8
  %v1246 = load i32, ptr %slot188, align 8
  %cv1247 = zext i32 %v1246 to i64
  %cond1248 = icmp ne i64 %cv1247, 0
  br i1 %cond1248, label %bb_rcgdec210, label %bb_rcgslow210
bb_rcgslow210:
  %v1249 = load i64, ptr %slot175, align 8
  %v1250 = load i64, ptr %slot172, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1249, i64 %v1250) nomerge, !dbg !126
  br label %bb_rcgdone210
bb_rcgdec210:
  %v1251 = load i64, ptr %slot184, align 8
  %v1252 = load i64, ptr %slot176, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  %rgep1254 = getelementptr i8, ptr %p1253, i64 -24
  store i64 %v1251, ptr %rgep1254, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear210
bb_rcgclear210:
  %v1255 = load i64, ptr %slot172, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  store i64 0, ptr %p1256, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone210
bb_rcgdone210:
  br label %bb_rcslotdone194
bb_rcslotowner194:
  %v1257 = load i64, ptr %slot36, align 8
  store i64 %v1257, ptr %slot189, align 8
  %v1258 = load i64, ptr %slot172, align 8
  %p1259 = inttoptr i64 %v1258 to ptr
  %ld1260 = load i64, ptr %p1259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1260, ptr %slot190, align 8
  %v1261 = load i64, ptr %slot190, align 8
  %cmp1262 = icmp ne i64 %v1261, 0
  %cv1263 = zext i1 %cmp1262 to i32
  store i32 %cv1263, ptr %slot191, align 8
  %v1264 = load i32, ptr %slot191, align 8
  %cv1265 = zext i32 %v1264 to i64
  %cond1266 = icmp ne i64 %cv1265, 0
  br i1 %cond1266, label %bb_rcgnn225, label %bb_rcgdone225
bb_rcgnn225:
  %v1267 = load i64, ptr %slot190, align 8
  %op1268 = sub i64 %v1267, 16
  store i64 %op1268, ptr %slot192, align 8
  %v1269 = load i64, ptr %slot190, align 8
  %p1270 = inttoptr i64 %v1269 to ptr
  %rgep1271 = getelementptr i8, ptr %p1270, i64 -16
  %ld1272 = load i64, ptr %rgep1271, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1272, ptr %slot193, align 8
  %v1273 = load i64, ptr %slot193, align 8
  %op1274 = and i64 %v1273, 4611686018427387906
  store i64 %op1274, ptr %slot194, align 8
  %v1275 = load i64, ptr %slot194, align 8
  %cmp1276 = icmp ne i64 %v1275, 0
  %cv1277 = zext i1 %cmp1276 to i32
  store i32 %cv1277, ptr %slot195, align 8
  %v1278 = load i32, ptr %slot195, align 8
  %cv1279 = zext i32 %v1278 to i64
  %cond1280 = icmp ne i64 %cv1279, 0
  br i1 %cond1280, label %bb_rcgclear225, label %bb_rcgcounted225
bb_rcgcounted225:
  %v1281 = load i64, ptr %slot190, align 8
  %op1282 = sub i64 %v1281, 32
  store i64 %op1282, ptr %slot196, align 8
  %v1283 = load i64, ptr %slot190, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  %rgep1285 = getelementptr i8, ptr %p1284, i64 -32
  %ld1286 = load i64, ptr %rgep1285, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1286, ptr %slot197, align 8
  %v1287 = load i64, ptr %slot197, align 8
  %op1288 = sub i64 %v1287, 1
  store i64 %op1288, ptr %slot198, align 8
  %v1289 = load i64, ptr %slot198, align 8
  %cmp1290 = icmp eq i64 %v1289, 0
  %cv1291 = zext i1 %cmp1290 to i32
  store i32 %cv1291, ptr %slot199, align 8
  %v1292 = load i32, ptr %slot199, align 8
  %cv1293 = zext i32 %v1292 to i64
  %cond1294 = icmp ne i64 %cv1293, 0
  br i1 %cond1294, label %bb_rcglast225, label %bb_rcgdec225
bb_rcglast225:
  %v1295 = load i64, ptr %slot190, align 8
  %op1296 = sub i64 %v1295, 24
  store i64 %op1296, ptr %slot200, align 8
  %v1297 = load i64, ptr %slot190, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %rgep1299 = getelementptr i8, ptr %p1298, i64 -24
  %ld1300 = load i64, ptr %rgep1299, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1300, ptr %slot201, align 8
  %v1301 = load i64, ptr %slot201, align 8
  %cmp1302 = icmp ne i64 %v1301, 0
  %cv1303 = zext i1 %cmp1302 to i32
  store i32 %cv1303, ptr %slot202, align 8
  %v1304 = load i32, ptr %slot202, align 8
  %cv1305 = zext i32 %v1304 to i64
  %cond1306 = icmp ne i64 %cv1305, 0
  br i1 %cond1306, label %bb_rcgdec225, label %bb_rcgslow225
bb_rcgslow225:
  %v1307 = load i64, ptr %slot189, align 8
  %v1308 = load i64, ptr %slot172, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1307, i64 %v1308) nomerge, !dbg !126
  br label %bb_rcgdone225
bb_rcgdec225:
  %v1309 = load i64, ptr %slot198, align 8
  %v1310 = load i64, ptr %slot190, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  %rgep1312 = getelementptr i8, ptr %p1311, i64 -32
  store i64 %v1309, ptr %rgep1312, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear225
bb_rcgclear225:
  %v1313 = load i64, ptr %slot172, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  store i64 0, ptr %p1314, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone225
bb_rcgdone225:
  br label %bb_rcslotdone194
bb_rcslotdone194:
  %v1315 = load i64, ptr %slot20, align 8
  store i64 %v1315, ptr %slot203, align 8
  %v1316 = load i64, ptr %slot169, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  %ld1318 = load i64, ptr %p1317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1318, ptr %slot204, align 8
  %v1319 = load i64, ptr %slot204, align 8
  %v1320 = load i64, ptr %slot203, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i64 %v1319, ptr %p1321, align 8, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot7, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  store i32 2, ptr %p1323, align 4, !alias.scope !3, !noalias !4
  %v1324 = load i64, ptr %slot7, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  store i32 8, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  %v1326 = load i64, ptr %slot6, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  store i32 1, ptr %p1327, align 4, !alias.scope !3, !noalias !4
  %v1328 = load i64, ptr %slot10, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 0, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot25, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  store i64 0, ptr %p1331, align 8, !alias.scope !3, !noalias !4
  %v1332 = load i64, ptr %slot25, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  %ld1334 = load i64, ptr %p1333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1334, ptr %slot205, align 8
  %v1335 = load i64, ptr %slot205, align 8
  %v1336 = load i64, ptr %slot21, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i64 %v1335, ptr %p1337, align 8, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot20, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  %ld1340 = load i64, ptr %p1339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1340, ptr %slot206, align 8
  %v1341 = load i64, ptr %slot206, align 8
  %op1342 = add i64 %v1341, 0
  store i64 %op1342, ptr %slot207, align 8
  %v1343 = load i64, ptr %slot207, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  %ld1345 = load i64, ptr %p1344, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1345, ptr %slot208, align 8
  %v1346 = load i64, ptr %slot208, align 8
  %v1347 = load i64, ptr %slot25, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  store i64 %v1346, ptr %p1348, align 8, !alias.scope !3, !noalias !4
  %v1349 = load i64, ptr %slot25, align 8
  %p1350 = inttoptr i64 %v1349 to ptr
  %ld1351 = load i64, ptr %p1350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1351, ptr %slot209, align 8
  %v1352 = load i64, ptr %slot209, align 8
  %cmp1353 = icmp ugt i64 %v1352, 9223372036854775807
  %cv1354 = zext i1 %cmp1353 to i64
  store i64 %cv1354, ptr %slot210, align 8
  %v1355 = load i64, ptr %slot210, align 8
  %cond1356 = icmp ne i64 %v1355, 0
  br i1 %cond1356, label %bb_cast_overflow241, label %bb_cast_ok241
bb_cast_overflow241:
  %v1357 = load i64, ptr %slot1, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  %v1359 = load i64, ptr %slot209, align 8
  call void @myl_qbe_fail_cast(ptr %p1358, i64 %v1359, i64 320) nomerge, !dbg !128
  unreachable
bb_cast_ok241:
  %v1360 = load i64, ptr %slot209, align 8
  %v1361 = load i64, ptr %slot25, align 8
  %p1362 = inttoptr i64 %v1361 to ptr
  store i64 %v1360, ptr %p1362, align 8, !alias.scope !3, !noalias !4
  %v1363 = load i64, ptr %slot25, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  %ld1365 = load i64, ptr %p1364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1365, ptr %slot211, align 8
  %v1366 = load i64, ptr %slot211, align 8
  %v1367 = load i64, ptr %slot22, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  store i64 %v1366, ptr %p1368, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i24:
  %v1369 = load i64, ptr %slot21, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %ld1371 = load i64, ptr %p1370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1371, ptr %slot212, align 8
  %v1372 = load i64, ptr %slot212, align 8
  %v1373 = load i64, ptr %slot25, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i64 %v1372, ptr %p1374, align 8, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot22, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i64, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1377, ptr %slot213, align 8
  %v1378 = load i64, ptr %slot213, align 8
  %v1379 = load i64, ptr %slot26, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i64 %v1378, ptr %p1380, align 8, !alias.scope !3, !noalias !4
  %v1381 = load i64, ptr %slot26, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  %ld1383 = load i64, ptr %p1382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1383, ptr %slot214, align 8
  %v1384 = load i64, ptr %slot25, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  %ld1386 = load i64, ptr %p1385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1386, ptr %slot215, align 8
  %v1387 = load i64, ptr %slot215, align 8
  %v1388 = load i64, ptr %slot214, align 8
  %cmp1389 = icmp slt i64 %v1387, %v1388
  %cv1390 = zext i1 %cmp1389 to i64
  store i64 %cv1390, ptr %slot216, align 8
  %v1391 = load i64, ptr %slot216, align 8
  %v1392 = load i64, ptr %slot25, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i64 %v1391, ptr %p1393, align 8, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot25, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  %ld1396 = load i64, ptr %p1395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1396, ptr %slot217, align 8
  %v1397 = load i64, ptr %slot217, align 8
  %cond1398 = icmp ne i64 %v1397, 0
  br i1 %cond1398, label %bb_next249, label %bb_i56
bb_next249:
  %v1399 = load i64, ptr %slot22, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %ld1401 = load i64, ptr %p1400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1401, ptr %slot218, align 8
  %v1402 = load i64, ptr %slot218, align 8
  %v1403 = load i64, ptr %slot25, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  store i64 %v1402, ptr %p1404, align 8, !alias.scope !3, !noalias !4
  %v1405 = load i64, ptr %slot20, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  %ld1407 = load i64, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1407, ptr %slot219, align 8
  %v1408 = load i64, ptr %slot25, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i64, ptr %p1409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1410, ptr %slot220, align 8
  %v1411 = load i64, ptr %slot219, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i64, ptr %p1412, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1413, ptr %slot221, align 8
  %v1414 = load i64, ptr %slot221, align 8
  %v1415 = load i64, ptr %slot220, align 8
  %cmp1416 = icmp eq i64 %v1414, %v1415
  %cv1417 = zext i1 %cmp1416 to i64
  store i64 %cv1417, ptr %slot222, align 8
  %v1418 = load i64, ptr %slot222, align 8
  %cond1419 = icmp ne i64 %v1418, 0
  br i1 %cond1419, label %bb_success254, label %bb_failed254
bb_failed254:
  %v1420 = load i64, ptr %slot1, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  call void @myl_qbe_fail_iteration(ptr %p1421) nomerge, !dbg !130
  unreachable
bb_success254:
  %v1422 = load i64, ptr %slot25, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i64 0, ptr %p1423, align 8, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot21, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  %ld1426 = load i64, ptr %p1425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1426, ptr %slot223, align 8
  %v1427 = load i64, ptr %slot223, align 8
  %v1428 = load i64, ptr %slot25, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  store i64 %v1427, ptr %p1429, align 8, !alias.scope !3, !noalias !4
  %v1430 = load i64, ptr %slot20, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  %ld1432 = load i64, ptr %p1431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1432, ptr %slot224, align 8
  %v1433 = load i64, ptr %slot25, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  %ld1435 = load i64, ptr %p1434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1435, ptr %slot225, align 8
  %v1436 = load i64, ptr %slot224, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  %ld1438 = load i64, ptr %p1437, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1438, ptr %slot226, align 8
  %v1439 = load i64, ptr %slot225, align 8
  %v1440 = load i64, ptr %slot226, align 8
  %cmp1441 = icmp ult i64 %v1439, %v1440
  %cv1442 = zext i1 %cmp1441 to i64
  store i64 %cv1442, ptr %slot227, align 8
  %v1443 = load i64, ptr %slot227, align 8
  %cond1444 = icmp ne i64 %v1443, 0
  br i1 %cond1444, label %bb_success261, label %bb_failed261
bb_failed261:
  %v1445 = load i64, ptr %slot1, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  %v1447 = load i64, ptr %slot225, align 8
  %v1448 = load i64, ptr %slot226, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1446, i64 %v1447, i64 %v1448) nomerge, !dbg !132
  unreachable
bb_success261:
  %v1449 = load i64, ptr %slot224, align 8
  %op1450 = add i64 %v1449, 32
  store i64 %op1450, ptr %slot228, align 8
  %v1451 = load i64, ptr %slot228, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  %ld1453 = load i64, ptr %p1452, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1453, ptr %slot229, align 8
  %v1454 = load i64, ptr %slot225, align 8
  %op1455 = mul i64 %v1454, 8
  store i64 %op1455, ptr %slot230, align 8
  %v1456 = load i64, ptr %slot229, align 8
  %v1457 = load i64, ptr %slot230, align 8
  %op1458 = add i64 %v1456, %v1457
  store i64 %op1458, ptr %slot231, align 8
  %v1459 = load i64, ptr %slot229, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %v1461 = load i64, ptr %slot230, align 8
  %egep1462 = getelementptr i8, ptr %p1460, i64 %v1461
  %ld1463 = load i64, ptr %egep1462, align 8, !alias.scope !12, !noalias !13
  store i64 %ld1463, ptr %slot232, align 8
  %v1464 = load i64, ptr %slot232, align 8
  %v1465 = load i64, ptr %slot25, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i64 %v1464, ptr %p1466, align 8, !alias.scope !3, !noalias !4
  %v1467 = load i64, ptr %slot25, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  %ld1469 = load i64, ptr %p1468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1469, ptr %slot233, align 8
  %v1470 = load i64, ptr %slot233, align 8
  %v1471 = load i64, ptr %slot23, align 8
  %p1472 = inttoptr i64 %v1471 to ptr
  store i64 %v1470, ptr %p1472, align 8, !alias.scope !3, !noalias !4
  %v1473 = load i64, ptr %slot16, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  %ld1475 = load i64, ptr %p1474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1475, ptr %slot234, align 8
  %v1476 = load i64, ptr %slot234, align 8
  %v1477 = load i64, ptr %slot25, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  store i64 %v1476, ptr %p1478, align 8, !alias.scope !3, !noalias !4
  %v1479 = load i64, ptr %slot23, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  %ld1481 = load i64, ptr %p1480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1481, ptr %slot235, align 8
  %v1482 = load i64, ptr %slot235, align 8
  %v1483 = load i64, ptr %slot26, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  store i64 %v1482, ptr %p1484, align 8, !alias.scope !3, !noalias !4
  %v1485 = load i64, ptr %slot25, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  %ld1487 = load i64, ptr %p1486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1487, ptr %slot236, align 8
  %v1488 = load i64, ptr %slot26, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  %ld1490 = load i64, ptr %p1489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1490, ptr %slot237, align 8
  %v1491 = load i64, ptr %slot1, align 8
  %v1492 = load i64, ptr %slot236, align 8
  %v1493 = load i64, ptr %slot237, align 8
  call void @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806(ptr sret([24 x i8]) align 8 %callresult239, i64 %v1491, i64 %v1492, i64 %v1493) nomerge, !dbg !134
  %addr1494 = ptrtoint ptr %callresult239 to i64
  store i64 %addr1494, ptr %slot238, align 8
  %v1495 = load i64, ptr %slot238, align 8
  %v1496 = load i64, ptr %slot25, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  store i64 %v1495, ptr %p1497, align 8, !alias.scope !3, !noalias !4
  %v1498 = load i64, ptr %slot25, align 8
  %p1499 = inttoptr i64 %v1498 to ptr
  %ld1500 = load i64, ptr %p1499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1500, ptr %slot240, align 8
  %v1501 = load i64, ptr %slot15, align 8
  store i64 %v1501, ptr %slot241, align 8
  %v1502 = load i64, ptr %slot240, align 8
  %v1503 = load i64, ptr %slot241, align 8
  %p1504 = inttoptr i64 %v1502 to ptr
  %p1505 = inttoptr i64 %v1503 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1505, ptr %p1504, i64 24, i1 false)
  %v1506 = load i64, ptr %slot11, align 8
  %p1507 = inttoptr i64 %v1506 to ptr
  store i32 2, ptr %p1507, align 4, !alias.scope !3, !noalias !4
  %v1508 = load i64, ptr %slot10, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  store i32 1, ptr %p1509, align 4, !alias.scope !3, !noalias !4
  %v1510 = load i64, ptr %slot8, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  %ld1512 = load i32, ptr %p1511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1512, ptr %slot242, align 8
  %v1513 = load i32, ptr %slot242, align 8
  %cv1514 = zext i32 %v1513 to i64
  %cond1515 = icmp ne i64 %cv1514, 0
  br i1 %cond1515, label %bb_rcslotdrop279, label %bb_rcslotdone279
bb_rcslotdrop279:
  %v1516 = load i64, ptr %slot8, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  store i32 0, ptr %p1517, align 4, !alias.scope !3, !noalias !4
  %v1518 = load i64, ptr %slot13, align 8
  store i64 %v1518, ptr %slot243, align 8
  %v1519 = load i64, ptr %slot9, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  %ld1521 = load i32, ptr %p1520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1521, ptr %slot244, align 8
  %v1522 = load i32, ptr %slot244, align 8
  %op1523 = and i32 %v1522, 28
  store i32 %op1523, ptr %slot245, align 8
  %v1524 = load i32, ptr %slot245, align 8
  %cv1525 = zext i32 %v1524 to i64
  %cond1526 = icmp ne i64 %cv1525, 0
  br i1 %cond1526, label %bb_rcslotrole279, label %bb_rcslotowner279
bb_rcslotrole279:
  %v1527 = load i64, ptr %slot36, align 8
  store i64 %v1527, ptr %slot246, align 8
  %v1528 = load i64, ptr %slot246, align 8
  %v1529 = load i64, ptr %slot243, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1528, i64 %v1529) nomerge, !dbg !134
  br label %bb_rcslotdone279
bb_rcslotowner279:
  %v1530 = load i64, ptr %slot36, align 8
  store i64 %v1530, ptr %slot247, align 8
  %v1531 = load i64, ptr %slot247, align 8
  %v1532 = load i64, ptr %slot243, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1531, i64 %v1532) nomerge, !dbg !134
  br label %bb_rcslotdone279
bb_rcslotdone279:
  %v1533 = load i64, ptr %slot13, align 8
  store i64 %v1533, ptr %slot248, align 8
  %v1534 = load i64, ptr %slot15, align 8
  store i64 %v1534, ptr %slot249, align 8
  %v1535 = load i64, ptr %slot249, align 8
  %v1536 = load i64, ptr %slot248, align 8
  %p1537 = inttoptr i64 %v1535 to ptr
  %p1538 = inttoptr i64 %v1536 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1538, ptr %p1537, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1539 = load i64, ptr %slot9, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  store i32 2, ptr %p1540, align 4, !alias.scope !3, !noalias !4
  %v1541 = load i64, ptr %slot11, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  %ld1543 = load i32, ptr %p1542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1543, ptr %slot250, align 8
  %v1544 = load i32, ptr %slot250, align 8
  %v1545 = load i64, ptr %slot9, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  store i32 %v1544, ptr %p1546, align 4, !alias.scope !3, !noalias !4
  %v1547 = load i64, ptr %slot10, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  store i32 0, ptr %p1548, align 4, !alias.scope !3, !noalias !4
  %v1549 = load i64, ptr %slot8, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  store i32 1, ptr %p1550, align 4, !alias.scope !3, !noalias !4
  %v1551 = load i64, ptr %slot248, align 8
  %v1552 = load i64, ptr %slot25, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  store i64 %v1551, ptr %p1553, align 8, !alias.scope !3, !noalias !4
  %v1554 = load i64, ptr %slot25, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  %ld1556 = load i64, ptr %p1555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1556, ptr %slot251, align 8
  %v1557 = load i64, ptr %slot251, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  %ld1559 = load i32, ptr %p1558, align 4, !alias.scope !3, !noalias !4
  %ext1560 = zext i32 %ld1559 to i64
  store i64 %ext1560, ptr %slot252, align 8
  %v1561 = load i64, ptr %slot252, align 8
  %cmp1562 = icmp eq i64 %v1561, 0
  %cv1563 = zext i1 %cmp1562 to i64
  store i64 %cv1563, ptr %slot253, align 8
  %v1564 = load i64, ptr %slot253, align 8
  %cond1565 = icmp ne i64 %v1564, 0
  br i1 %cond1565, label %bb_rctryok295, label %bb_rctryerror295
bb_rctryerror295:
  %p1566 = inttoptr i64 ptrtoint (ptr @myl_f_8a9892bcaf1d54845365507fdbe66f11290e39bbcea0301e2767f370744c950d_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1566, i64 12884901925) "call-inline-cost"="0", !dbg !136
  %v1567 = load i64, ptr %slot251, align 8
  %op1568 = add i64 %v1567, 8
  store i64 %op1568, ptr %slot254, align 8
  %v1569 = load i64, ptr %slot27, align 8
  store i64 %v1569, ptr %slot255, align 8
  %v1570 = load i64, ptr %slot255, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  store i64 0, ptr %p1571, align 8, !alias.scope !3, !noalias !4
  %v1572 = load i64, ptr %slot255, align 8
  %p1574 = inttoptr i64 %v1572 to ptr
  %gep1575 = getelementptr i8, ptr %p1574, i64 8
  %op1573 = ptrtoint ptr %gep1575 to i64
  store i64 %op1573, ptr %slot256, align 8
  %v1576 = load i64, ptr %slot256, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  store i64 0, ptr %p1577, align 8, !alias.scope !3, !noalias !4
  %v1578 = load i64, ptr %slot255, align 8
  %p1580 = inttoptr i64 %v1578 to ptr
  %gep1581 = getelementptr i8, ptr %p1580, i64 16
  %op1579 = ptrtoint ptr %gep1581 to i64
  store i64 %op1579, ptr %slot257, align 8
  %v1582 = load i64, ptr %slot257, align 8
  %p1583 = inttoptr i64 %v1582 to ptr
  store i64 0, ptr %p1583, align 8, !alias.scope !3, !noalias !4
  %v1584 = load i64, ptr %slot255, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  store i32 1, ptr %p1585, align 4, !alias.scope !3, !noalias !4
  %v1586 = load i64, ptr %slot255, align 8
  %p1588 = inttoptr i64 %v1586 to ptr
  %gep1589 = getelementptr i8, ptr %p1588, i64 8
  %op1587 = ptrtoint ptr %gep1589 to i64
  store i64 %op1587, ptr %slot258, align 8
  %v1590 = load i64, ptr %slot12, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  store i32 1, ptr %p1591, align 4, !alias.scope !3, !noalias !4
  %v1592 = load i64, ptr %slot37, align 8
  store i64 %v1592, ptr %slot259, align 8
  %v1593 = load i64, ptr %slot36, align 8
  %v1594 = load i64, ptr %slot258, align 8
  %v1595 = load i64, ptr %slot254, align 8
  %v1596 = load i64, ptr %slot259, align 8
  %cv1597 = trunc i64 %v1596 to i32
  %call1598 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v1593, i64 %v1594, i64 %v1595, i32 %cv1597) nomerge, !dbg !136
  store i32 %call1598, ptr %slot260, align 8
  %v1599 = load i32, ptr %slot260, align 8
  %cv1600 = zext i32 %v1599 to i64
  %cond1601 = icmp ne i64 %cv1600, 0
  br i1 %cond1601, label %bb_rcsuccess306, label %bb_rcfailure306
bb_rcfailure306:
  %v1602 = load i64, ptr %slot36, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  %call1604 = call i32 @myl_rc_take_failure(ptr %p1603) nomerge, !dbg !136
  store i32 %call1604, ptr %slot261, align 8
  %v1605 = load i64, ptr %slot1, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  %v1607 = load i32, ptr %slot261, align 8
  %call1608 = call i32 @myl_qbe_rc_status(ptr %p1606, i32 %v1607) nomerge, !dbg !136
  store i32 %call1608, ptr %slot262, align 8
  br label %bb_failure
bb_rcsuccess306:
  %v1609 = load i64, ptr %slot255, align 8
  %v1610 = load i64, ptr %slot25, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  store i64 %v1609, ptr %p1611, align 8, !alias.scope !3, !noalias !4
  %v1612 = load i64, ptr %slot25, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  %ld1614 = load i64, ptr %p1613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1614, ptr %slot263, align 8
  %v1615 = load i64, ptr %slot15, align 8
  store i64 %v1615, ptr %slot264, align 8
  %v1616 = load i64, ptr %slot263, align 8
  %v1617 = load i64, ptr %slot264, align 8
  %p1618 = inttoptr i64 %v1616 to ptr
  %p1619 = inttoptr i64 %v1617 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1619, ptr %p1618, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot11, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  store i32 2, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot10, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 1, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot8, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  %ld1626 = load i32, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1626, ptr %slot265, align 8
  %v1627 = load i32, ptr %slot265, align 8
  %cv1628 = zext i32 %v1627 to i64
  %cond1629 = icmp ne i64 %cv1628, 0
  br i1 %cond1629, label %bb_rcslotdrop315, label %bb_rcslotdone315
bb_rcslotdrop315:
  %v1630 = load i64, ptr %slot8, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i32 0, ptr %p1631, align 4, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot13, align 8
  store i64 %v1632, ptr %slot266, align 8
  %v1633 = load i64, ptr %slot9, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  %ld1635 = load i32, ptr %p1634, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1635, ptr %slot267, align 8
  %v1636 = load i32, ptr %slot267, align 8
  %op1637 = and i32 %v1636, 28
  store i32 %op1637, ptr %slot268, align 8
  %v1638 = load i32, ptr %slot268, align 8
  %cv1639 = zext i32 %v1638 to i64
  %cond1640 = icmp ne i64 %cv1639, 0
  br i1 %cond1640, label %bb_rcslotrole315, label %bb_rcslotowner315
bb_rcslotrole315:
  %v1641 = load i64, ptr %slot36, align 8
  store i64 %v1641, ptr %slot269, align 8
  %v1642 = load i64, ptr %slot269, align 8
  %v1643 = load i64, ptr %slot266, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1642, i64 %v1643) nomerge, !dbg !136
  br label %bb_rcslotdone315
bb_rcslotowner315:
  %v1644 = load i64, ptr %slot36, align 8
  store i64 %v1644, ptr %slot270, align 8
  %v1645 = load i64, ptr %slot270, align 8
  %v1646 = load i64, ptr %slot266, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1645, i64 %v1646) nomerge, !dbg !136
  br label %bb_rcslotdone315
bb_rcslotdone315:
  %v1647 = load i64, ptr %slot13, align 8
  store i64 %v1647, ptr %slot271, align 8
  %v1648 = load i64, ptr %slot15, align 8
  store i64 %v1648, ptr %slot272, align 8
  %v1649 = load i64, ptr %slot272, align 8
  %v1650 = load i64, ptr %slot271, align 8
  %p1651 = inttoptr i64 %v1649 to ptr
  %p1652 = inttoptr i64 %v1650 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1652, ptr %p1651, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1653 = load i64, ptr %slot9, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  store i32 2, ptr %p1654, align 4, !alias.scope !3, !noalias !4
  %v1655 = load i64, ptr %slot11, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  %ld1657 = load i32, ptr %p1656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1657, ptr %slot273, align 8
  %v1658 = load i32, ptr %slot273, align 8
  %v1659 = load i64, ptr %slot9, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i32 %v1658, ptr %p1660, align 4, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot10, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  store i32 0, ptr %p1662, align 4, !alias.scope !3, !noalias !4
  %v1663 = load i64, ptr %slot8, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  store i32 1, ptr %p1664, align 4, !alias.scope !3, !noalias !4
  %v1665 = load i64, ptr %slot271, align 8
  %v1666 = load i64, ptr %slot25, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i64 %v1665, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  br label %bb_i39
bb_rctryok295:
  %v1668 = load i64, ptr %slot27, align 8
  store i64 %v1668, ptr %slot274, align 8
  %v1669 = load i64, ptr %slot274, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  store i32 0, ptr %p1670, align 4, !alias.scope !3, !noalias !4
  %v1671 = load i64, ptr %slot12, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  store i32 1, ptr %p1672, align 4, !alias.scope !3, !noalias !4
  %v1673 = load i64, ptr %slot251, align 8
  %op1674 = add i64 %v1673, 8
  store i64 %op1674, ptr %slot275, align 8
  %v1675 = load i64, ptr %slot37, align 8
  store i64 %v1675, ptr %slot276, align 8
  %v1676 = load i64, ptr %slot275, align 8
  %v1677 = load i64, ptr %slot274, align 8
  %p1678 = inttoptr i64 %v1676 to ptr
  %p1679 = inttoptr i64 %v1677 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1679, ptr %p1678, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v1680 = load i64, ptr %slot274, align 8
  %v1681 = load i64, ptr %slot25, align 8
  %p1682 = inttoptr i64 %v1681 to ptr
  store i64 %v1680, ptr %p1682, align 8, !alias.scope !3, !noalias !4
  %v1683 = load i64, ptr %slot8, align 8
  %p1684 = inttoptr i64 %v1683 to ptr
  %ld1685 = load i32, ptr %p1684, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1685, ptr %slot277, align 8
  %v1686 = load i32, ptr %slot277, align 8
  %cv1687 = zext i32 %v1686 to i64
  %cond1688 = icmp ne i64 %cv1687, 0
  br i1 %cond1688, label %bb_rcslotdrop337, label %bb_rcslotdone337
bb_rcslotdrop337:
  %v1689 = load i64, ptr %slot8, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i32 0, ptr %p1690, align 4, !alias.scope !3, !noalias !4
  %v1691 = load i64, ptr %slot13, align 8
  store i64 %v1691, ptr %slot278, align 8
  %v1692 = load i64, ptr %slot9, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  %ld1694 = load i32, ptr %p1693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1694, ptr %slot279, align 8
  %v1695 = load i32, ptr %slot279, align 8
  %op1696 = and i32 %v1695, 28
  store i32 %op1696, ptr %slot280, align 8
  %v1697 = load i32, ptr %slot280, align 8
  %cv1698 = zext i32 %v1697 to i64
  %cond1699 = icmp ne i64 %cv1698, 0
  br i1 %cond1699, label %bb_rcslotrole337, label %bb_rcslotowner337
bb_rcslotrole337:
  %v1700 = load i64, ptr %slot36, align 8
  store i64 %v1700, ptr %slot281, align 8
  %v1701 = load i64, ptr %slot281, align 8
  %v1702 = load i64, ptr %slot278, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1701, i64 %v1702) nomerge, !dbg !136
  br label %bb_rcslotdone337
bb_rcslotowner337:
  %v1703 = load i64, ptr %slot36, align 8
  store i64 %v1703, ptr %slot282, align 8
  %v1704 = load i64, ptr %slot282, align 8
  %v1705 = load i64, ptr %slot278, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1704, i64 %v1705) nomerge, !dbg !136
  br label %bb_rcslotdone337
bb_rcslotdone337:
  br label %bb_i40
bb_i39:
  %v1706 = load i64, ptr %slot25, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  %ld1708 = load i64, ptr %p1707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1708, ptr %slot283, align 8
  %v1709 = load i64, ptr %slot25, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %ld1711 = load i64, ptr %p1710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1711, ptr %slot284, align 8
  %v1712 = load i64, ptr %slot8, align 8
  %p1713 = inttoptr i64 %v1712 to ptr
  %ld1714 = load i32, ptr %p1713, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1714, ptr %slot285, align 8
  %v1715 = load i64, ptr %slot9, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  %ld1717 = load i32, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1717, ptr %slot286, align 8
  %v1718 = load i32, ptr %slot286, align 8
  %op1719 = and i32 %v1718, 24
  store i32 %op1719, ptr %slot286, align 8
  %v1720 = load i32, ptr %slot286, align 8
  %cmp1721 = icmp eq i32 %v1720, 0
  %cv1722 = zext i1 %cmp1721 to i32
  store i32 %cv1722, ptr %slot287, align 8
  %v1723 = load i32, ptr %slot285, align 8
  %v1724 = load i32, ptr %slot287, align 8
  %op1725 = and i32 %v1723, %v1724
  store i32 %op1725, ptr %slot288, align 8
  %v1726 = load i32, ptr %slot288, align 8
  %cv1727 = zext i32 %v1726 to i64
  %cond1728 = icmp ne i64 %cv1727, 0
  br i1 %cond1728, label %bb_rctake346, label %bb_rccopy346
bb_rctake346:
  %v1729 = load i64, ptr %slot15, align 8
  store i64 %v1729, ptr %slot289, align 8
  %v1730 = load i64, ptr %slot37, align 8
  store i64 %v1730, ptr %slot290, align 8
  %v1731 = load i64, ptr %slot36, align 8
  %v1732 = load i64, ptr %slot289, align 8
  %v1733 = load i64, ptr %slot284, align 8
  %v1734 = load i64, ptr %slot290, align 8
  %cv1735 = trunc i64 %v1734 to i32
  %call1736 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v1731, i64 %v1732, i64 %v1733, i32 %cv1735) nomerge, !dbg !138
  store i32 %call1736, ptr %slot291, align 8
  %v1737 = load i32, ptr %slot291, align 8
  %cv1738 = zext i32 %v1737 to i64
  %cond1739 = icmp ne i64 %cv1738, 0
  br i1 %cond1739, label %bb_rcsuccess356, label %bb_rcfailure356
bb_rcfailure356:
  %v1740 = load i64, ptr %slot36, align 8
  %p1741 = inttoptr i64 %v1740 to ptr
  %call1742 = call i32 @myl_rc_take_failure(ptr %p1741) nomerge, !dbg !138
  store i32 %call1742, ptr %slot292, align 8
  %v1743 = load i64, ptr %slot1, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %v1745 = load i32, ptr %slot292, align 8
  %call1746 = call i32 @myl_qbe_rc_status(ptr %p1744, i32 %v1745) nomerge, !dbg !138
  store i32 %call1746, ptr %slot293, align 8
  br label %bb_failure
bb_rcsuccess356:
  %v1747 = load i64, ptr %slot8, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i32 0, ptr %p1748, align 4, !alias.scope !3, !noalias !4
  %v1749 = load i64, ptr %slot11, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  store i32 2, ptr %p1750, align 4, !alias.scope !3, !noalias !4
  %v1751 = load i64, ptr %slot10, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  store i32 1, ptr %p1752, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared346
bb_rccopy346:
  %v1753 = load i64, ptr %slot15, align 8
  store i64 %v1753, ptr %slot294, align 8
  %v1754 = load i64, ptr %slot37, align 8
  store i64 %v1754, ptr %slot295, align 8
  %v1755 = load i64, ptr %slot36, align 8
  %v1756 = load i64, ptr %slot294, align 8
  %v1757 = load i64, ptr %slot284, align 8
  %v1758 = load i64, ptr %slot295, align 8
  %cv1759 = trunc i64 %v1758 to i32
  %call1760 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64 %v1755, i64 %v1756, i64 %v1757, i32 %cv1759) nomerge, !dbg !138
  store i32 %call1760, ptr %slot296, align 8
  %v1761 = load i32, ptr %slot296, align 8
  %cv1762 = zext i32 %v1761 to i64
  %cond1763 = icmp ne i64 %cv1762, 0
  br i1 %cond1763, label %bb_rcsuccess365, label %bb_rcfailure365
bb_rcfailure365:
  %v1764 = load i64, ptr %slot36, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  %call1766 = call i32 @myl_rc_take_failure(ptr %p1765) nomerge, !dbg !138
  store i32 %call1766, ptr %slot297, align 8
  %v1767 = load i64, ptr %slot1, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %v1769 = load i32, ptr %slot297, align 8
  %call1770 = call i32 @myl_qbe_rc_status(ptr %p1768, i32 %v1769) nomerge, !dbg !138
  store i32 %call1770, ptr %slot298, align 8
  br label %bb_failure
bb_rcsuccess365:
  %v1771 = load i64, ptr %slot11, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  store i32 2, ptr %p1772, align 4, !alias.scope !3, !noalias !4
  %v1773 = load i64, ptr %slot10, align 8
  %p1774 = inttoptr i64 %v1773 to ptr
  store i32 1, ptr %p1774, align 4, !alias.scope !3, !noalias !4
  %v1775 = load i64, ptr %slot8, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  %ld1777 = load i32, ptr %p1776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1777, ptr %slot299, align 8
  %v1778 = load i32, ptr %slot299, align 8
  %cv1779 = zext i32 %v1778 to i64
  %cond1780 = icmp ne i64 %cv1779, 0
  br i1 %cond1780, label %bb_rcslotdrop372, label %bb_rcslotdone372
bb_rcslotdrop372:
  %v1781 = load i64, ptr %slot8, align 8
  %p1782 = inttoptr i64 %v1781 to ptr
  store i32 0, ptr %p1782, align 4, !alias.scope !3, !noalias !4
  %v1783 = load i64, ptr %slot13, align 8
  store i64 %v1783, ptr %slot300, align 8
  %v1784 = load i64, ptr %slot9, align 8
  %p1785 = inttoptr i64 %v1784 to ptr
  %ld1786 = load i32, ptr %p1785, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1786, ptr %slot301, align 8
  %v1787 = load i32, ptr %slot301, align 8
  %op1788 = and i32 %v1787, 28
  store i32 %op1788, ptr %slot302, align 8
  %v1789 = load i32, ptr %slot302, align 8
  %cv1790 = zext i32 %v1789 to i64
  %cond1791 = icmp ne i64 %cv1790, 0
  br i1 %cond1791, label %bb_rcslotrole372, label %bb_rcslotowner372
bb_rcslotrole372:
  %v1792 = load i64, ptr %slot36, align 8
  store i64 %v1792, ptr %slot303, align 8
  %v1793 = load i64, ptr %slot303, align 8
  %v1794 = load i64, ptr %slot300, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1793, i64 %v1794) nomerge, !dbg !138
  br label %bb_rcslotdone372
bb_rcslotowner372:
  %v1795 = load i64, ptr %slot36, align 8
  store i64 %v1795, ptr %slot304, align 8
  %v1796 = load i64, ptr %slot304, align 8
  %v1797 = load i64, ptr %slot300, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1796, i64 %v1797) nomerge, !dbg !138
  br label %bb_rcslotdone372
bb_rcslotdone372:
  br label %bb_rcprepared346
bb_rcprepared346:
  %v1798 = load i64, ptr %slot15, align 8
  store i64 %v1798, ptr %slot305, align 8
  %v1799 = load i64, ptr %slot10, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  store i32 0, ptr %p1800, align 4, !alias.scope !3, !noalias !4
  %v1801 = load i64, ptr %slot8, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  %ld1803 = load i32, ptr %p1802, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1803, ptr %slot306, align 8
  %v1804 = load i32, ptr %slot306, align 8
  %cv1805 = zext i32 %v1804 to i64
  %cond1806 = icmp ne i64 %cv1805, 0
  br i1 %cond1806, label %bb_rcslotdrop383, label %bb_rcslotdone383
bb_rcslotdrop383:
  %v1807 = load i64, ptr %slot8, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i32 0, ptr %p1808, align 4, !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot13, align 8
  store i64 %v1809, ptr %slot307, align 8
  %v1810 = load i64, ptr %slot9, align 8
  %p1811 = inttoptr i64 %v1810 to ptr
  %ld1812 = load i32, ptr %p1811, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1812, ptr %slot308, align 8
  %v1813 = load i32, ptr %slot308, align 8
  %op1814 = and i32 %v1813, 28
  store i32 %op1814, ptr %slot309, align 8
  %v1815 = load i32, ptr %slot309, align 8
  %cv1816 = zext i32 %v1815 to i64
  %cond1817 = icmp ne i64 %cv1816, 0
  br i1 %cond1817, label %bb_rcslotrole383, label %bb_rcslotowner383
bb_rcslotrole383:
  %v1818 = load i64, ptr %slot36, align 8
  store i64 %v1818, ptr %slot310, align 8
  %v1819 = load i64, ptr %slot310, align 8
  %v1820 = load i64, ptr %slot307, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1819, i64 %v1820) nomerge, !dbg !138
  br label %bb_rcslotdone383
bb_rcslotowner383:
  %v1821 = load i64, ptr %slot36, align 8
  store i64 %v1821, ptr %slot311, align 8
  %v1822 = load i64, ptr %slot311, align 8
  %v1823 = load i64, ptr %slot307, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1822, i64 %v1823) nomerge, !dbg !138
  br label %bb_rcslotdone383
bb_rcslotdone383:
  %v1824 = load i64, ptr %slot6, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  %ld1826 = load i32, ptr %p1825, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1826, ptr %slot312, align 8
  %v1827 = load i32, ptr %slot312, align 8
  %cv1828 = zext i32 %v1827 to i64
  %cond1829 = icmp ne i64 %cv1828, 0
  br i1 %cond1829, label %bb_rcslotdrop392, label %bb_rcslotdone392
bb_rcslotdrop392:
  %v1830 = load i64, ptr %slot6, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  store i32 0, ptr %p1831, align 4, !alias.scope !3, !noalias !4
  %v1832 = load i64, ptr %slot20, align 8
  store i64 %v1832, ptr %slot313, align 8
  %v1833 = load i64, ptr %slot7, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  %ld1835 = load i32, ptr %p1834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1835, ptr %slot314, align 8
  %v1836 = load i32, ptr %slot314, align 8
  %op1837 = and i32 %v1836, 28
  store i32 %op1837, ptr %slot315, align 8
  %v1838 = load i32, ptr %slot315, align 8
  %cv1839 = zext i32 %v1838 to i64
  %cond1840 = icmp ne i64 %cv1839, 0
  br i1 %cond1840, label %bb_rcslotrole392, label %bb_rcslotowner392
bb_rcslotrole392:
  %v1841 = load i64, ptr %slot36, align 8
  store i64 %v1841, ptr %slot316, align 8
  %v1842 = load i64, ptr %slot313, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  %ld1844 = load i64, ptr %p1843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1844, ptr %slot317, align 8
  %v1845 = load i64, ptr %slot317, align 8
  %cmp1846 = icmp ne i64 %v1845, 0
  %cv1847 = zext i1 %cmp1846 to i32
  store i32 %cv1847, ptr %slot318, align 8
  %v1848 = load i32, ptr %slot318, align 8
  %cv1849 = zext i32 %v1848 to i64
  %cond1850 = icmp ne i64 %cv1849, 0
  br i1 %cond1850, label %bb_rcgnn408, label %bb_rcgdone408
bb_rcgnn408:
  %v1851 = load i64, ptr %slot317, align 8
  %op1852 = sub i64 %v1851, 16
  store i64 %op1852, ptr %slot319, align 8
  %v1853 = load i64, ptr %slot317, align 8
  %p1854 = inttoptr i64 %v1853 to ptr
  %rgep1855 = getelementptr i8, ptr %p1854, i64 -16
  %ld1856 = load i64, ptr %rgep1855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1856, ptr %slot320, align 8
  %v1857 = load i64, ptr %slot320, align 8
  %op1858 = and i64 %v1857, 4611686018427387906
  store i64 %op1858, ptr %slot321, align 8
  %v1859 = load i64, ptr %slot321, align 8
  %cmp1860 = icmp ne i64 %v1859, 0
  %cv1861 = zext i1 %cmp1860 to i32
  store i32 %cv1861, ptr %slot322, align 8
  %v1862 = load i32, ptr %slot322, align 8
  %cv1863 = zext i32 %v1862 to i64
  %cond1864 = icmp ne i64 %cv1863, 0
  br i1 %cond1864, label %bb_rcgclear408, label %bb_rcgcounted408
bb_rcgcounted408:
  %v1865 = load i64, ptr %slot317, align 8
  %op1866 = sub i64 %v1865, 24
  store i64 %op1866, ptr %slot323, align 8
  %v1867 = load i64, ptr %slot317, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  %rgep1869 = getelementptr i8, ptr %p1868, i64 -24
  %ld1870 = load i64, ptr %rgep1869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1870, ptr %slot324, align 8
  %v1871 = load i64, ptr %slot324, align 8
  %op1872 = sub i64 %v1871, 1
  store i64 %op1872, ptr %slot325, align 8
  %v1873 = load i64, ptr %slot325, align 8
  %cmp1874 = icmp eq i64 %v1873, 0
  %cv1875 = zext i1 %cmp1874 to i32
  store i32 %cv1875, ptr %slot326, align 8
  %v1876 = load i32, ptr %slot326, align 8
  %cv1877 = zext i32 %v1876 to i64
  %cond1878 = icmp ne i64 %cv1877, 0
  br i1 %cond1878, label %bb_rcglast408, label %bb_rcgdec408
bb_rcglast408:
  %v1879 = load i64, ptr %slot317, align 8
  %op1880 = sub i64 %v1879, 32
  store i64 %op1880, ptr %slot327, align 8
  %v1881 = load i64, ptr %slot317, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  %rgep1883 = getelementptr i8, ptr %p1882, i64 -32
  %ld1884 = load i64, ptr %rgep1883, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1884, ptr %slot328, align 8
  %v1885 = load i64, ptr %slot328, align 8
  %cmp1886 = icmp ne i64 %v1885, 0
  %cv1887 = zext i1 %cmp1886 to i32
  store i32 %cv1887, ptr %slot329, align 8
  %v1888 = load i32, ptr %slot329, align 8
  %cv1889 = zext i32 %v1888 to i64
  %cond1890 = icmp ne i64 %cv1889, 0
  br i1 %cond1890, label %bb_rcgdec408, label %bb_rcgslow408
bb_rcgslow408:
  %v1891 = load i64, ptr %slot316, align 8
  %v1892 = load i64, ptr %slot313, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1891, i64 %v1892) nomerge, !dbg !138
  br label %bb_rcgdone408
bb_rcgdec408:
  %v1893 = load i64, ptr %slot325, align 8
  %v1894 = load i64, ptr %slot317, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  %rgep1896 = getelementptr i8, ptr %p1895, i64 -24
  store i64 %v1893, ptr %rgep1896, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear408
bb_rcgclear408:
  %v1897 = load i64, ptr %slot313, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  store i64 0, ptr %p1898, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone408
bb_rcgdone408:
  br label %bb_rcslotdone392
bb_rcslotowner392:
  %v1899 = load i64, ptr %slot36, align 8
  store i64 %v1899, ptr %slot330, align 8
  %v1900 = load i64, ptr %slot313, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  %ld1902 = load i64, ptr %p1901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1902, ptr %slot331, align 8
  %v1903 = load i64, ptr %slot331, align 8
  %cmp1904 = icmp ne i64 %v1903, 0
  %cv1905 = zext i1 %cmp1904 to i32
  store i32 %cv1905, ptr %slot332, align 8
  %v1906 = load i32, ptr %slot332, align 8
  %cv1907 = zext i32 %v1906 to i64
  %cond1908 = icmp ne i64 %cv1907, 0
  br i1 %cond1908, label %bb_rcgnn423, label %bb_rcgdone423
bb_rcgnn423:
  %v1909 = load i64, ptr %slot331, align 8
  %op1910 = sub i64 %v1909, 16
  store i64 %op1910, ptr %slot333, align 8
  %v1911 = load i64, ptr %slot331, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  %rgep1913 = getelementptr i8, ptr %p1912, i64 -16
  %ld1914 = load i64, ptr %rgep1913, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1914, ptr %slot334, align 8
  %v1915 = load i64, ptr %slot334, align 8
  %op1916 = and i64 %v1915, 4611686018427387906
  store i64 %op1916, ptr %slot335, align 8
  %v1917 = load i64, ptr %slot335, align 8
  %cmp1918 = icmp ne i64 %v1917, 0
  %cv1919 = zext i1 %cmp1918 to i32
  store i32 %cv1919, ptr %slot336, align 8
  %v1920 = load i32, ptr %slot336, align 8
  %cv1921 = zext i32 %v1920 to i64
  %cond1922 = icmp ne i64 %cv1921, 0
  br i1 %cond1922, label %bb_rcgclear423, label %bb_rcgcounted423
bb_rcgcounted423:
  %v1923 = load i64, ptr %slot331, align 8
  %op1924 = sub i64 %v1923, 32
  store i64 %op1924, ptr %slot337, align 8
  %v1925 = load i64, ptr %slot331, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %rgep1927 = getelementptr i8, ptr %p1926, i64 -32
  %ld1928 = load i64, ptr %rgep1927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1928, ptr %slot338, align 8
  %v1929 = load i64, ptr %slot338, align 8
  %op1930 = sub i64 %v1929, 1
  store i64 %op1930, ptr %slot339, align 8
  %v1931 = load i64, ptr %slot339, align 8
  %cmp1932 = icmp eq i64 %v1931, 0
  %cv1933 = zext i1 %cmp1932 to i32
  store i32 %cv1933, ptr %slot340, align 8
  %v1934 = load i32, ptr %slot340, align 8
  %cv1935 = zext i32 %v1934 to i64
  %cond1936 = icmp ne i64 %cv1935, 0
  br i1 %cond1936, label %bb_rcglast423, label %bb_rcgdec423
bb_rcglast423:
  %v1937 = load i64, ptr %slot331, align 8
  %op1938 = sub i64 %v1937, 24
  store i64 %op1938, ptr %slot341, align 8
  %v1939 = load i64, ptr %slot331, align 8
  %p1940 = inttoptr i64 %v1939 to ptr
  %rgep1941 = getelementptr i8, ptr %p1940, i64 -24
  %ld1942 = load i64, ptr %rgep1941, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1942, ptr %slot342, align 8
  %v1943 = load i64, ptr %slot342, align 8
  %cmp1944 = icmp ne i64 %v1943, 0
  %cv1945 = zext i1 %cmp1944 to i32
  store i32 %cv1945, ptr %slot343, align 8
  %v1946 = load i32, ptr %slot343, align 8
  %cv1947 = zext i32 %v1946 to i64
  %cond1948 = icmp ne i64 %cv1947, 0
  br i1 %cond1948, label %bb_rcgdec423, label %bb_rcgslow423
bb_rcgslow423:
  %v1949 = load i64, ptr %slot330, align 8
  %v1950 = load i64, ptr %slot313, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1949, i64 %v1950) nomerge, !dbg !138
  br label %bb_rcgdone423
bb_rcgdec423:
  %v1951 = load i64, ptr %slot339, align 8
  %v1952 = load i64, ptr %slot331, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  %rgep1954 = getelementptr i8, ptr %p1953, i64 -32
  store i64 %v1951, ptr %rgep1954, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear423
bb_rcgclear423:
  %v1955 = load i64, ptr %slot313, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  store i64 0, ptr %p1956, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone423
bb_rcgdone423:
  br label %bb_rcslotdone392
bb_rcslotdone392:
  %v1957 = load i64, ptr %slot305, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1958, i64 24, i1 false)
  ret void
bb_i40:
  %v1959 = load i64, ptr %slot25, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  %ld1961 = load i64, ptr %p1960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1961, ptr %slot344, align 8
  %v1962 = load i64, ptr %slot344, align 8
  %v1963 = load i64, ptr %slot24, align 8
  %p1964 = inttoptr i64 %v1962 to ptr
  %p1965 = inttoptr i64 %v1963 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1965, ptr %p1964, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v1966 = load i64, ptr %slot24, align 8
  %v1967 = load i64, ptr %slot25, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  store i64 %v1966, ptr %p1968, align 8, !alias.scope !3, !noalias !4
  %v1969 = load i64, ptr %slot28, align 8
  store i64 %v1969, ptr %slot345, align 8
  %v1970 = load i64, ptr %slot345, align 8
  %p1971 = inttoptr i64 %v1970 to ptr
  store i32 0, ptr %p1971, align 4, !alias.scope !3, !noalias !4
  %v1972 = load i64, ptr %slot345, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  store i32 1, ptr %p1973, align 4, !alias.scope !3, !noalias !4
  %v1974 = load i64, ptr %slot345, align 8
  %v1975 = load i64, ptr %slot26, align 8
  %p1976 = inttoptr i64 %v1975 to ptr
  store i64 %v1974, ptr %p1976, align 8, !alias.scope !3, !noalias !4
  %v1977 = load i64, ptr %slot26, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  %ld1979 = load i64, ptr %p1978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1979, ptr %slot346, align 8
  %v1980 = load i64, ptr %slot25, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  %ld1982 = load i64, ptr %p1981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1982, ptr %slot347, align 8
  %v1983 = load i64, ptr %slot347, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  %ld1985 = load i32, ptr %p1984, align 4, !alias.scope !3, !noalias !4
  %ext1986 = zext i32 %ld1985 to i64
  store i64 %ext1986, ptr %slot348, align 8
  %v1987 = load i64, ptr %slot346, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  %ld1989 = load i32, ptr %p1988, align 4, !alias.scope !3, !noalias !4
  %ext1990 = zext i32 %ld1989 to i64
  store i64 %ext1990, ptr %slot349, align 8
  %v1991 = load i64, ptr %slot348, align 8
  %v1992 = load i64, ptr %slot349, align 8
  %cmp1993 = icmp eq i64 %v1991, %v1992
  %cv1994 = zext i1 %cmp1993 to i64
  store i64 %cv1994, ptr %slot350, align 8
  %v1995 = load i64, ptr %slot350, align 8
  %v1996 = load i64, ptr %slot25, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  store i64 %v1995, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  %v1998 = load i64, ptr %slot25, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  %ld2000 = load i64, ptr %p1999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2000, ptr %slot351, align 8
  %v2001 = load i64, ptr %slot351, align 8
  %cond2002 = icmp ne i64 %v2001, 0
  br i1 %cond2002, label %bb_next481, label %bb_i48
bb_next481:
  %v2003 = load i64, ptr %slot24, align 8
  %v2004 = load i64, ptr %slot25, align 8
  %p2005 = inttoptr i64 %v2004 to ptr
  store i64 %v2003, ptr %p2005, align 8, !alias.scope !3, !noalias !4
  %v2006 = load i64, ptr %slot29, align 8
  store i64 %v2006, ptr %slot352, align 8
  %v2007 = load i64, ptr %slot352, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  store i64 0, ptr %p2008, align 8, !alias.scope !3, !noalias !4
  %v2009 = load i64, ptr %slot352, align 8
  %p2011 = inttoptr i64 %v2009 to ptr
  %gep2012 = getelementptr i8, ptr %p2011, i64 8
  %op2010 = ptrtoint ptr %gep2012 to i64
  store i64 %op2010, ptr %slot353, align 8
  %v2013 = load i64, ptr %slot353, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  store i64 0, ptr %p2014, align 8, !alias.scope !3, !noalias !4
  %v2015 = load i64, ptr %slot352, align 8
  %p2017 = inttoptr i64 %v2015 to ptr
  %gep2018 = getelementptr i8, ptr %p2017, i64 16
  %op2016 = ptrtoint ptr %gep2018 to i64
  store i64 %op2016, ptr %slot354, align 8
  %v2019 = load i64, ptr %slot354, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  store i64 0, ptr %p2020, align 8, !alias.scope !3, !noalias !4
  %v2021 = load i64, ptr %slot352, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  store i32 0, ptr %p2022, align 4, !alias.scope !3, !noalias !4
  %v2023 = load i64, ptr %slot12, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i32 1, ptr %p2024, align 4, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot25, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  %ld2027 = load i64, ptr %p2026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2027, ptr %slot355, align 8
  %v2028 = load i64, ptr %slot352, align 8
  %p2030 = inttoptr i64 %v2028 to ptr
  %gep2031 = getelementptr i8, ptr %p2030, i64 8
  %op2029 = ptrtoint ptr %gep2031 to i64
  store i64 %op2029, ptr %slot356, align 8
  %v2032 = load i64, ptr %slot37, align 8
  store i64 %v2032, ptr %slot357, align 8
  %v2033 = load i64, ptr %slot355, align 8
  %v2034 = load i64, ptr %slot356, align 8
  %p2035 = inttoptr i64 %v2033 to ptr
  %p2036 = inttoptr i64 %v2034 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2036, ptr %p2035, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v2037 = load i64, ptr %slot352, align 8
  %v2038 = load i64, ptr %slot25, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  store i64 %v2037, ptr %p2039, align 8, !alias.scope !3, !noalias !4
  %v2040 = load i64, ptr %slot25, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %ld2042 = load i64, ptr %p2041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2042, ptr %slot358, align 8
  %v2043 = load i64, ptr %slot13, align 8
  store i64 %v2043, ptr %slot359, align 8
  %v2044 = load i64, ptr %slot358, align 8
  %v2045 = load i64, ptr %slot359, align 8
  %p2046 = inttoptr i64 %v2044 to ptr
  %p2047 = inttoptr i64 %v2045 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2047, ptr %p2046, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2048 = load i64, ptr %slot9, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  store i32 2, ptr %p2049, align 4, !alias.scope !3, !noalias !4
  %v2050 = load i64, ptr %slot8, align 8
  %p2051 = inttoptr i64 %v2050 to ptr
  store i32 1, ptr %p2051, align 4, !alias.scope !3, !noalias !4
  %v2052 = load i64, ptr %slot359, align 8
  %v2053 = load i64, ptr %slot25, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  store i64 %v2052, ptr %p2054, align 8, !alias.scope !3, !noalias !4
  %v2055 = load i64, ptr %slot25, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  %ld2057 = load i64, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2057, ptr %slot360, align 8
  %v2058 = load i64, ptr %slot25, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  %ld2060 = load i64, ptr %p2059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2060, ptr %slot361, align 8
  %v2061 = load i64, ptr %slot15, align 8
  store i64 %v2061, ptr %slot362, align 8
  %v2062 = load i64, ptr %slot37, align 8
  store i64 %v2062, ptr %slot363, align 8
  %v2063 = load i64, ptr %slot36, align 8
  %v2064 = load i64, ptr %slot362, align 8
  %v2065 = load i64, ptr %slot361, align 8
  %v2066 = load i64, ptr %slot363, align 8
  %cv2067 = trunc i64 %v2066 to i32
  %call2068 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v2063, i64 %v2064, i64 %v2065, i32 %cv2067) nomerge, !dbg !140
  store i32 %call2068, ptr %slot364, align 8
  %v2069 = load i32, ptr %slot364, align 8
  %cv2070 = zext i32 %v2069 to i64
  %cond2071 = icmp ne i64 %cv2070, 0
  br i1 %cond2071, label %bb_rcsuccess498, label %bb_rcfailure498
bb_rcfailure498:
  %v2072 = load i64, ptr %slot36, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  %call2074 = call i32 @myl_rc_take_failure(ptr %p2073) nomerge, !dbg !140
  store i32 %call2074, ptr %slot365, align 8
  %v2075 = load i64, ptr %slot1, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %v2077 = load i32, ptr %slot365, align 8
  %call2078 = call i32 @myl_qbe_rc_status(ptr %p2076, i32 %v2077) nomerge, !dbg !140
  store i32 %call2078, ptr %slot366, align 8
  br label %bb_failure
bb_rcsuccess498:
  %v2079 = load i64, ptr %slot8, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  store i32 0, ptr %p2080, align 4, !alias.scope !3, !noalias !4
  %v2081 = load i64, ptr %slot11, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i32 2, ptr %p2082, align 4, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot10, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  store i32 1, ptr %p2084, align 4, !alias.scope !3, !noalias !4
  %v2085 = load i64, ptr %slot15, align 8
  store i64 %v2085, ptr %slot367, align 8
  %v2086 = load i64, ptr %slot10, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i32 0, ptr %p2087, align 4, !alias.scope !3, !noalias !4
  %v2088 = load i64, ptr %slot8, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %ld2090 = load i32, ptr %p2089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2090, ptr %slot368, align 8
  %v2091 = load i32, ptr %slot368, align 8
  %cv2092 = zext i32 %v2091 to i64
  %cond2093 = icmp ne i64 %cv2092, 0
  br i1 %cond2093, label %bb_rcslotdrop508, label %bb_rcslotdone508
bb_rcslotdrop508:
  %v2094 = load i64, ptr %slot8, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  store i32 0, ptr %p2095, align 4, !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot13, align 8
  store i64 %v2096, ptr %slot369, align 8
  %v2097 = load i64, ptr %slot9, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  %ld2099 = load i32, ptr %p2098, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2099, ptr %slot370, align 8
  %v2100 = load i32, ptr %slot370, align 8
  %op2101 = and i32 %v2100, 28
  store i32 %op2101, ptr %slot371, align 8
  %v2102 = load i32, ptr %slot371, align 8
  %cv2103 = zext i32 %v2102 to i64
  %cond2104 = icmp ne i64 %cv2103, 0
  br i1 %cond2104, label %bb_rcslotrole508, label %bb_rcslotowner508
bb_rcslotrole508:
  %v2105 = load i64, ptr %slot36, align 8
  store i64 %v2105, ptr %slot372, align 8
  %v2106 = load i64, ptr %slot372, align 8
  %v2107 = load i64, ptr %slot369, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2106, i64 %v2107) nomerge, !dbg !140
  br label %bb_rcslotdone508
bb_rcslotowner508:
  %v2108 = load i64, ptr %slot36, align 8
  store i64 %v2108, ptr %slot373, align 8
  %v2109 = load i64, ptr %slot373, align 8
  %v2110 = load i64, ptr %slot369, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2109, i64 %v2110) nomerge, !dbg !140
  br label %bb_rcslotdone508
bb_rcslotdone508:
  %v2111 = load i64, ptr %slot6, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  %ld2113 = load i32, ptr %p2112, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2113, ptr %slot374, align 8
  %v2114 = load i32, ptr %slot374, align 8
  %cv2115 = zext i32 %v2114 to i64
  %cond2116 = icmp ne i64 %cv2115, 0
  br i1 %cond2116, label %bb_rcslotdrop517, label %bb_rcslotdone517
bb_rcslotdrop517:
  %v2117 = load i64, ptr %slot6, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  store i32 0, ptr %p2118, align 4, !alias.scope !3, !noalias !4
  %v2119 = load i64, ptr %slot20, align 8
  store i64 %v2119, ptr %slot375, align 8
  %v2120 = load i64, ptr %slot7, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  %ld2122 = load i32, ptr %p2121, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2122, ptr %slot376, align 8
  %v2123 = load i32, ptr %slot376, align 8
  %op2124 = and i32 %v2123, 28
  store i32 %op2124, ptr %slot377, align 8
  %v2125 = load i32, ptr %slot377, align 8
  %cv2126 = zext i32 %v2125 to i64
  %cond2127 = icmp ne i64 %cv2126, 0
  br i1 %cond2127, label %bb_rcslotrole517, label %bb_rcslotowner517
bb_rcslotrole517:
  %v2128 = load i64, ptr %slot36, align 8
  store i64 %v2128, ptr %slot378, align 8
  %v2129 = load i64, ptr %slot375, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  %ld2131 = load i64, ptr %p2130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2131, ptr %slot379, align 8
  %v2132 = load i64, ptr %slot379, align 8
  %cmp2133 = icmp ne i64 %v2132, 0
  %cv2134 = zext i1 %cmp2133 to i32
  store i32 %cv2134, ptr %slot380, align 8
  %v2135 = load i32, ptr %slot380, align 8
  %cv2136 = zext i32 %v2135 to i64
  %cond2137 = icmp ne i64 %cv2136, 0
  br i1 %cond2137, label %bb_rcgnn533, label %bb_rcgdone533
bb_rcgnn533:
  %v2138 = load i64, ptr %slot379, align 8
  %op2139 = sub i64 %v2138, 16
  store i64 %op2139, ptr %slot381, align 8
  %v2140 = load i64, ptr %slot379, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %rgep2142 = getelementptr i8, ptr %p2141, i64 -16
  %ld2143 = load i64, ptr %rgep2142, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2143, ptr %slot382, align 8
  %v2144 = load i64, ptr %slot382, align 8
  %op2145 = and i64 %v2144, 4611686018427387906
  store i64 %op2145, ptr %slot383, align 8
  %v2146 = load i64, ptr %slot383, align 8
  %cmp2147 = icmp ne i64 %v2146, 0
  %cv2148 = zext i1 %cmp2147 to i32
  store i32 %cv2148, ptr %slot384, align 8
  %v2149 = load i32, ptr %slot384, align 8
  %cv2150 = zext i32 %v2149 to i64
  %cond2151 = icmp ne i64 %cv2150, 0
  br i1 %cond2151, label %bb_rcgclear533, label %bb_rcgcounted533
bb_rcgcounted533:
  %v2152 = load i64, ptr %slot379, align 8
  %op2153 = sub i64 %v2152, 24
  store i64 %op2153, ptr %slot385, align 8
  %v2154 = load i64, ptr %slot379, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  %rgep2156 = getelementptr i8, ptr %p2155, i64 -24
  %ld2157 = load i64, ptr %rgep2156, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2157, ptr %slot386, align 8
  %v2158 = load i64, ptr %slot386, align 8
  %op2159 = sub i64 %v2158, 1
  store i64 %op2159, ptr %slot387, align 8
  %v2160 = load i64, ptr %slot387, align 8
  %cmp2161 = icmp eq i64 %v2160, 0
  %cv2162 = zext i1 %cmp2161 to i32
  store i32 %cv2162, ptr %slot388, align 8
  %v2163 = load i32, ptr %slot388, align 8
  %cv2164 = zext i32 %v2163 to i64
  %cond2165 = icmp ne i64 %cv2164, 0
  br i1 %cond2165, label %bb_rcglast533, label %bb_rcgdec533
bb_rcglast533:
  %v2166 = load i64, ptr %slot379, align 8
  %op2167 = sub i64 %v2166, 32
  store i64 %op2167, ptr %slot389, align 8
  %v2168 = load i64, ptr %slot379, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %rgep2170 = getelementptr i8, ptr %p2169, i64 -32
  %ld2171 = load i64, ptr %rgep2170, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2171, ptr %slot390, align 8
  %v2172 = load i64, ptr %slot390, align 8
  %cmp2173 = icmp ne i64 %v2172, 0
  %cv2174 = zext i1 %cmp2173 to i32
  store i32 %cv2174, ptr %slot391, align 8
  %v2175 = load i32, ptr %slot391, align 8
  %cv2176 = zext i32 %v2175 to i64
  %cond2177 = icmp ne i64 %cv2176, 0
  br i1 %cond2177, label %bb_rcgdec533, label %bb_rcgslow533
bb_rcgslow533:
  %v2178 = load i64, ptr %slot378, align 8
  %v2179 = load i64, ptr %slot375, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2178, i64 %v2179) nomerge, !dbg !140
  br label %bb_rcgdone533
bb_rcgdec533:
  %v2180 = load i64, ptr %slot387, align 8
  %v2181 = load i64, ptr %slot379, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  %rgep2183 = getelementptr i8, ptr %p2182, i64 -24
  store i64 %v2180, ptr %rgep2183, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear533
bb_rcgclear533:
  %v2184 = load i64, ptr %slot375, align 8
  %p2185 = inttoptr i64 %v2184 to ptr
  store i64 0, ptr %p2185, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone533
bb_rcgdone533:
  br label %bb_rcslotdone517
bb_rcslotowner517:
  %v2186 = load i64, ptr %slot36, align 8
  store i64 %v2186, ptr %slot392, align 8
  %v2187 = load i64, ptr %slot375, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  %ld2189 = load i64, ptr %p2188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2189, ptr %slot393, align 8
  %v2190 = load i64, ptr %slot393, align 8
  %cmp2191 = icmp ne i64 %v2190, 0
  %cv2192 = zext i1 %cmp2191 to i32
  store i32 %cv2192, ptr %slot394, align 8
  %v2193 = load i32, ptr %slot394, align 8
  %cv2194 = zext i32 %v2193 to i64
  %cond2195 = icmp ne i64 %cv2194, 0
  br i1 %cond2195, label %bb_rcgnn548, label %bb_rcgdone548
bb_rcgnn548:
  %v2196 = load i64, ptr %slot393, align 8
  %op2197 = sub i64 %v2196, 16
  store i64 %op2197, ptr %slot395, align 8
  %v2198 = load i64, ptr %slot393, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  %rgep2200 = getelementptr i8, ptr %p2199, i64 -16
  %ld2201 = load i64, ptr %rgep2200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2201, ptr %slot396, align 8
  %v2202 = load i64, ptr %slot396, align 8
  %op2203 = and i64 %v2202, 4611686018427387906
  store i64 %op2203, ptr %slot397, align 8
  %v2204 = load i64, ptr %slot397, align 8
  %cmp2205 = icmp ne i64 %v2204, 0
  %cv2206 = zext i1 %cmp2205 to i32
  store i32 %cv2206, ptr %slot398, align 8
  %v2207 = load i32, ptr %slot398, align 8
  %cv2208 = zext i32 %v2207 to i64
  %cond2209 = icmp ne i64 %cv2208, 0
  br i1 %cond2209, label %bb_rcgclear548, label %bb_rcgcounted548
bb_rcgcounted548:
  %v2210 = load i64, ptr %slot393, align 8
  %op2211 = sub i64 %v2210, 32
  store i64 %op2211, ptr %slot399, align 8
  %v2212 = load i64, ptr %slot393, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  %rgep2214 = getelementptr i8, ptr %p2213, i64 -32
  %ld2215 = load i64, ptr %rgep2214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2215, ptr %slot400, align 8
  %v2216 = load i64, ptr %slot400, align 8
  %op2217 = sub i64 %v2216, 1
  store i64 %op2217, ptr %slot401, align 8
  %v2218 = load i64, ptr %slot401, align 8
  %cmp2219 = icmp eq i64 %v2218, 0
  %cv2220 = zext i1 %cmp2219 to i32
  store i32 %cv2220, ptr %slot402, align 8
  %v2221 = load i32, ptr %slot402, align 8
  %cv2222 = zext i32 %v2221 to i64
  %cond2223 = icmp ne i64 %cv2222, 0
  br i1 %cond2223, label %bb_rcglast548, label %bb_rcgdec548
bb_rcglast548:
  %v2224 = load i64, ptr %slot393, align 8
  %op2225 = sub i64 %v2224, 24
  store i64 %op2225, ptr %slot403, align 8
  %v2226 = load i64, ptr %slot393, align 8
  %p2227 = inttoptr i64 %v2226 to ptr
  %rgep2228 = getelementptr i8, ptr %p2227, i64 -24
  %ld2229 = load i64, ptr %rgep2228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2229, ptr %slot404, align 8
  %v2230 = load i64, ptr %slot404, align 8
  %cmp2231 = icmp ne i64 %v2230, 0
  %cv2232 = zext i1 %cmp2231 to i32
  store i32 %cv2232, ptr %slot405, align 8
  %v2233 = load i32, ptr %slot405, align 8
  %cv2234 = zext i32 %v2233 to i64
  %cond2235 = icmp ne i64 %cv2234, 0
  br i1 %cond2235, label %bb_rcgdec548, label %bb_rcgslow548
bb_rcgslow548:
  %v2236 = load i64, ptr %slot392, align 8
  %v2237 = load i64, ptr %slot375, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2236, i64 %v2237) nomerge, !dbg !140
  br label %bb_rcgdone548
bb_rcgdec548:
  %v2238 = load i64, ptr %slot401, align 8
  %v2239 = load i64, ptr %slot393, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  %rgep2241 = getelementptr i8, ptr %p2240, i64 -32
  store i64 %v2238, ptr %rgep2241, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear548
bb_rcgclear548:
  %v2242 = load i64, ptr %slot375, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  store i64 0, ptr %p2243, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone548
bb_rcgdone548:
  br label %bb_rcslotdone517
bb_rcslotdone517:
  %v2244 = load i64, ptr %slot367, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2245, i64 24, i1 false)
  ret void
bb_i48:
  %v2246 = load i64, ptr %slot22, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  %ld2248 = load i64, ptr %p2247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2248, ptr %slot406, align 8
  %v2249 = load i64, ptr %slot406, align 8
  %v2250 = load i64, ptr %slot25, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  store i64 %v2249, ptr %p2251, align 8, !alias.scope !3, !noalias !4
  %v2252 = load i64, ptr %slot20, align 8
  %p2253 = inttoptr i64 %v2252 to ptr
  %ld2254 = load i64, ptr %p2253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2254, ptr %slot407, align 8
  %v2255 = load i64, ptr %slot25, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  %ld2257 = load i64, ptr %p2256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2257, ptr %slot408, align 8
  %v2258 = load i64, ptr %slot407, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  %ld2260 = load i64, ptr %p2259, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2260, ptr %slot409, align 8
  %v2261 = load i64, ptr %slot409, align 8
  %v2262 = load i64, ptr %slot408, align 8
  %cmp2263 = icmp eq i64 %v2261, %v2262
  %cv2264 = zext i1 %cmp2263 to i64
  store i64 %cv2264, ptr %slot410, align 8
  %v2265 = load i64, ptr %slot410, align 8
  %cond2266 = icmp ne i64 %v2265, 0
  br i1 %cond2266, label %bb_success603, label %bb_failed603
bb_failed603:
  %v2267 = load i64, ptr %slot1, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  call void @myl_qbe_fail_iteration(ptr %p2268) nomerge, !dbg !142
  unreachable
bb_success603:
  %v2269 = load i64, ptr %slot25, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  store i64 0, ptr %p2270, align 8, !alias.scope !3, !noalias !4
  %v2271 = load i64, ptr %slot21, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  %ld2273 = load i64, ptr %p2272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2273, ptr %slot411, align 8
  %v2274 = load i64, ptr %slot411, align 8
  %v2275 = load i64, ptr %slot25, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  store i64 %v2274, ptr %p2276, align 8, !alias.scope !3, !noalias !4
  %v2277 = load i64, ptr %slot26, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  store i64 1, ptr %p2278, align 8, !alias.scope !3, !noalias !4
  %v2279 = load i64, ptr %slot26, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  %ld2281 = load i64, ptr %p2280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2281, ptr %slot412, align 8
  %v2282 = load i64, ptr %slot25, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  %ld2284 = load i64, ptr %p2283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2284, ptr %slot413, align 8
  %v2285 = load i64, ptr %slot413, align 8
  %v2286 = load i64, ptr %slot412, align 8
  %ovpair2288 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2285, i64 %v2286)
  %op2287 = extractvalue { i64, i1 } %ovpair2288, 0
  %ov2289 = extractvalue { i64, i1 } %ovpair2288, 1
  store i64 %op2287, ptr %slot414, align 8
  %cv2290 = zext i1 %ov2289 to i64
  store i64 %cv2290, ptr %slot415, align 8
  %v2291 = load i64, ptr %slot415, align 8
  %cond2292 = icmp ne i64 %v2291, 0
  br i1 %cond2292, label %bb_overflow607, label %bb_checked607
bb_overflow607:
  %v2293 = load i64, ptr %slot1, align 8
  %p2294 = inttoptr i64 %v2293 to ptr
  %v2295 = load i64, ptr %slot413, align 8
  %v2296 = load i64, ptr %slot412, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2294, i64 0, i64 %v2295, i64 %v2296, i64 64) nomerge, !dbg !144
  unreachable
bb_checked607:
  %v2297 = load i64, ptr %slot414, align 8
  %v2298 = load i64, ptr %slot25, align 8
  %p2299 = inttoptr i64 %v2298 to ptr
  store i64 %v2297, ptr %p2299, align 8, !alias.scope !3, !noalias !4
  %v2300 = load i64, ptr %slot25, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  %ld2302 = load i64, ptr %p2301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2302, ptr %slot416, align 8
  %v2303 = load i64, ptr %slot416, align 8
  %v2304 = load i64, ptr %slot21, align 8
  %p2305 = inttoptr i64 %v2304 to ptr
  store i64 %v2303, ptr %p2305, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i56:
  %v2306 = load i64, ptr %slot30, align 8
  store i64 %v2306, ptr %slot417, align 8
  %v2307 = load i64, ptr %slot417, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  store i32 0, ptr %p2308, align 4, !alias.scope !3, !noalias !4
  %v2309 = load i64, ptr %slot417, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  store i32 0, ptr %p2310, align 4, !alias.scope !3, !noalias !4
  %v2311 = load i64, ptr %slot417, align 8
  %v2312 = load i64, ptr %slot25, align 8
  %p2313 = inttoptr i64 %v2312 to ptr
  store i64 %v2311, ptr %p2313, align 8, !alias.scope !3, !noalias !4
  %v2314 = load i64, ptr %slot31, align 8
  store i64 %v2314, ptr %slot418, align 8
  %v2315 = load i64, ptr %slot418, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  store i64 0, ptr %p2316, align 8, !alias.scope !3, !noalias !4
  %v2317 = load i64, ptr %slot418, align 8
  %p2319 = inttoptr i64 %v2317 to ptr
  %gep2320 = getelementptr i8, ptr %p2319, i64 8
  %op2318 = ptrtoint ptr %gep2320 to i64
  store i64 %op2318, ptr %slot419, align 8
  %v2321 = load i64, ptr %slot419, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  store i64 0, ptr %p2322, align 8, !alias.scope !3, !noalias !4
  %v2323 = load i64, ptr %slot418, align 8
  %p2325 = inttoptr i64 %v2323 to ptr
  %gep2326 = getelementptr i8, ptr %p2325, i64 16
  %op2324 = ptrtoint ptr %gep2326 to i64
  store i64 %op2324, ptr %slot420, align 8
  %v2327 = load i64, ptr %slot420, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  store i64 0, ptr %p2328, align 8, !alias.scope !3, !noalias !4
  %v2329 = load i64, ptr %slot418, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  store i32 0, ptr %p2330, align 4, !alias.scope !3, !noalias !4
  %v2331 = load i64, ptr %slot12, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i32 1, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  %v2333 = load i64, ptr %slot25, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %ld2335 = load i64, ptr %p2334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2335, ptr %slot421, align 8
  %v2336 = load i64, ptr %slot418, align 8
  %p2338 = inttoptr i64 %v2336 to ptr
  %gep2339 = getelementptr i8, ptr %p2338, i64 8
  %op2337 = ptrtoint ptr %gep2339 to i64
  store i64 %op2337, ptr %slot422, align 8
  %v2340 = load i64, ptr %slot37, align 8
  store i64 %v2340, ptr %slot423, align 8
  %v2341 = load i64, ptr %slot421, align 8
  %v2342 = load i64, ptr %slot422, align 8
  %p2343 = inttoptr i64 %v2341 to ptr
  %p2344 = inttoptr i64 %v2342 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2344, ptr %p2343, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v2345 = load i64, ptr %slot418, align 8
  %v2346 = load i64, ptr %slot25, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  store i64 %v2345, ptr %p2347, align 8, !alias.scope !3, !noalias !4
  %v2348 = load i64, ptr %slot25, align 8
  %p2349 = inttoptr i64 %v2348 to ptr
  %ld2350 = load i64, ptr %p2349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2350, ptr %slot424, align 8
  %v2351 = load i64, ptr %slot13, align 8
  store i64 %v2351, ptr %slot425, align 8
  %v2352 = load i64, ptr %slot424, align 8
  %v2353 = load i64, ptr %slot425, align 8
  %p2354 = inttoptr i64 %v2352 to ptr
  %p2355 = inttoptr i64 %v2353 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2355, ptr %p2354, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2356 = load i64, ptr %slot9, align 8
  %p2357 = inttoptr i64 %v2356 to ptr
  store i32 2, ptr %p2357, align 4, !alias.scope !3, !noalias !4
  %v2358 = load i64, ptr %slot8, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  store i32 1, ptr %p2359, align 4, !alias.scope !3, !noalias !4
  %v2360 = load i64, ptr %slot425, align 8
  %v2361 = load i64, ptr %slot25, align 8
  %p2362 = inttoptr i64 %v2361 to ptr
  store i64 %v2360, ptr %p2362, align 8, !alias.scope !3, !noalias !4
  %v2363 = load i64, ptr %slot25, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  %ld2365 = load i64, ptr %p2364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2365, ptr %slot426, align 8
  %v2366 = load i64, ptr %slot25, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  %ld2368 = load i64, ptr %p2367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2368, ptr %slot427, align 8
  %v2369 = load i64, ptr %slot15, align 8
  store i64 %v2369, ptr %slot428, align 8
  %v2370 = load i64, ptr %slot37, align 8
  store i64 %v2370, ptr %slot429, align 8
  %v2371 = load i64, ptr %slot36, align 8
  %v2372 = load i64, ptr %slot428, align 8
  %v2373 = load i64, ptr %slot427, align 8
  %v2374 = load i64, ptr %slot429, align 8
  %cv2375 = trunc i64 %v2374 to i32
  %call2376 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v2371, i64 %v2372, i64 %v2373, i32 %cv2375) nomerge, !dbg !146
  store i32 %call2376, ptr %slot430, align 8
  %v2377 = load i32, ptr %slot430, align 8
  %cv2378 = zext i32 %v2377 to i64
  %cond2379 = icmp ne i64 %cv2378, 0
  br i1 %cond2379, label %bb_rcsuccess628, label %bb_rcfailure628
bb_rcfailure628:
  %v2380 = load i64, ptr %slot36, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  %call2382 = call i32 @myl_rc_take_failure(ptr %p2381) nomerge, !dbg !146
  store i32 %call2382, ptr %slot431, align 8
  %v2383 = load i64, ptr %slot1, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  %v2385 = load i32, ptr %slot431, align 8
  %call2386 = call i32 @myl_qbe_rc_status(ptr %p2384, i32 %v2385) nomerge, !dbg !146
  store i32 %call2386, ptr %slot432, align 8
  br label %bb_failure
bb_rcsuccess628:
  %v2387 = load i64, ptr %slot8, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  store i32 0, ptr %p2388, align 4, !alias.scope !3, !noalias !4
  %v2389 = load i64, ptr %slot11, align 8
  %p2390 = inttoptr i64 %v2389 to ptr
  store i32 2, ptr %p2390, align 4, !alias.scope !3, !noalias !4
  %v2391 = load i64, ptr %slot10, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  store i32 1, ptr %p2392, align 4, !alias.scope !3, !noalias !4
  %v2393 = load i64, ptr %slot15, align 8
  store i64 %v2393, ptr %slot433, align 8
  %v2394 = load i64, ptr %slot10, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  store i32 0, ptr %p2395, align 4, !alias.scope !3, !noalias !4
  %v2396 = load i64, ptr %slot8, align 8
  %p2397 = inttoptr i64 %v2396 to ptr
  %ld2398 = load i32, ptr %p2397, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2398, ptr %slot434, align 8
  %v2399 = load i32, ptr %slot434, align 8
  %cv2400 = zext i32 %v2399 to i64
  %cond2401 = icmp ne i64 %cv2400, 0
  br i1 %cond2401, label %bb_rcslotdrop638, label %bb_rcslotdone638
bb_rcslotdrop638:
  %v2402 = load i64, ptr %slot8, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  store i32 0, ptr %p2403, align 4, !alias.scope !3, !noalias !4
  %v2404 = load i64, ptr %slot13, align 8
  store i64 %v2404, ptr %slot435, align 8
  %v2405 = load i64, ptr %slot9, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  %ld2407 = load i32, ptr %p2406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2407, ptr %slot436, align 8
  %v2408 = load i32, ptr %slot436, align 8
  %op2409 = and i32 %v2408, 28
  store i32 %op2409, ptr %slot437, align 8
  %v2410 = load i32, ptr %slot437, align 8
  %cv2411 = zext i32 %v2410 to i64
  %cond2412 = icmp ne i64 %cv2411, 0
  br i1 %cond2412, label %bb_rcslotrole638, label %bb_rcslotowner638
bb_rcslotrole638:
  %v2413 = load i64, ptr %slot36, align 8
  store i64 %v2413, ptr %slot438, align 8
  %v2414 = load i64, ptr %slot438, align 8
  %v2415 = load i64, ptr %slot435, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v2414, i64 %v2415) nomerge, !dbg !146
  br label %bb_rcslotdone638
bb_rcslotowner638:
  %v2416 = load i64, ptr %slot36, align 8
  store i64 %v2416, ptr %slot439, align 8
  %v2417 = load i64, ptr %slot439, align 8
  %v2418 = load i64, ptr %slot435, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v2417, i64 %v2418) nomerge, !dbg !146
  br label %bb_rcslotdone638
bb_rcslotdone638:
  %v2419 = load i64, ptr %slot6, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  %ld2421 = load i32, ptr %p2420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2421, ptr %slot440, align 8
  %v2422 = load i32, ptr %slot440, align 8
  %cv2423 = zext i32 %v2422 to i64
  %cond2424 = icmp ne i64 %cv2423, 0
  br i1 %cond2424, label %bb_rcslotdrop647, label %bb_rcslotdone647
bb_rcslotdrop647:
  %v2425 = load i64, ptr %slot6, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  store i32 0, ptr %p2426, align 4, !alias.scope !3, !noalias !4
  %v2427 = load i64, ptr %slot20, align 8
  store i64 %v2427, ptr %slot441, align 8
  %v2428 = load i64, ptr %slot7, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  %ld2430 = load i32, ptr %p2429, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2430, ptr %slot442, align 8
  %v2431 = load i32, ptr %slot442, align 8
  %op2432 = and i32 %v2431, 28
  store i32 %op2432, ptr %slot443, align 8
  %v2433 = load i32, ptr %slot443, align 8
  %cv2434 = zext i32 %v2433 to i64
  %cond2435 = icmp ne i64 %cv2434, 0
  br i1 %cond2435, label %bb_rcslotrole647, label %bb_rcslotowner647
bb_rcslotrole647:
  %v2436 = load i64, ptr %slot36, align 8
  store i64 %v2436, ptr %slot444, align 8
  %v2437 = load i64, ptr %slot441, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  %ld2439 = load i64, ptr %p2438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2439, ptr %slot445, align 8
  %v2440 = load i64, ptr %slot445, align 8
  %cmp2441 = icmp ne i64 %v2440, 0
  %cv2442 = zext i1 %cmp2441 to i32
  store i32 %cv2442, ptr %slot446, align 8
  %v2443 = load i32, ptr %slot446, align 8
  %cv2444 = zext i32 %v2443 to i64
  %cond2445 = icmp ne i64 %cv2444, 0
  br i1 %cond2445, label %bb_rcgnn663, label %bb_rcgdone663
bb_rcgnn663:
  %v2446 = load i64, ptr %slot445, align 8
  %op2447 = sub i64 %v2446, 16
  store i64 %op2447, ptr %slot447, align 8
  %v2448 = load i64, ptr %slot445, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  %rgep2450 = getelementptr i8, ptr %p2449, i64 -16
  %ld2451 = load i64, ptr %rgep2450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2451, ptr %slot448, align 8
  %v2452 = load i64, ptr %slot448, align 8
  %op2453 = and i64 %v2452, 4611686018427387906
  store i64 %op2453, ptr %slot449, align 8
  %v2454 = load i64, ptr %slot449, align 8
  %cmp2455 = icmp ne i64 %v2454, 0
  %cv2456 = zext i1 %cmp2455 to i32
  store i32 %cv2456, ptr %slot450, align 8
  %v2457 = load i32, ptr %slot450, align 8
  %cv2458 = zext i32 %v2457 to i64
  %cond2459 = icmp ne i64 %cv2458, 0
  br i1 %cond2459, label %bb_rcgclear663, label %bb_rcgcounted663
bb_rcgcounted663:
  %v2460 = load i64, ptr %slot445, align 8
  %op2461 = sub i64 %v2460, 24
  store i64 %op2461, ptr %slot451, align 8
  %v2462 = load i64, ptr %slot445, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  %rgep2464 = getelementptr i8, ptr %p2463, i64 -24
  %ld2465 = load i64, ptr %rgep2464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2465, ptr %slot452, align 8
  %v2466 = load i64, ptr %slot452, align 8
  %op2467 = sub i64 %v2466, 1
  store i64 %op2467, ptr %slot453, align 8
  %v2468 = load i64, ptr %slot453, align 8
  %cmp2469 = icmp eq i64 %v2468, 0
  %cv2470 = zext i1 %cmp2469 to i32
  store i32 %cv2470, ptr %slot454, align 8
  %v2471 = load i32, ptr %slot454, align 8
  %cv2472 = zext i32 %v2471 to i64
  %cond2473 = icmp ne i64 %cv2472, 0
  br i1 %cond2473, label %bb_rcglast663, label %bb_rcgdec663
bb_rcglast663:
  %v2474 = load i64, ptr %slot445, align 8
  %op2475 = sub i64 %v2474, 32
  store i64 %op2475, ptr %slot455, align 8
  %v2476 = load i64, ptr %slot445, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  %rgep2478 = getelementptr i8, ptr %p2477, i64 -32
  %ld2479 = load i64, ptr %rgep2478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2479, ptr %slot456, align 8
  %v2480 = load i64, ptr %slot456, align 8
  %cmp2481 = icmp ne i64 %v2480, 0
  %cv2482 = zext i1 %cmp2481 to i32
  store i32 %cv2482, ptr %slot457, align 8
  %v2483 = load i32, ptr %slot457, align 8
  %cv2484 = zext i32 %v2483 to i64
  %cond2485 = icmp ne i64 %cv2484, 0
  br i1 %cond2485, label %bb_rcgdec663, label %bb_rcgslow663
bb_rcgslow663:
  %v2486 = load i64, ptr %slot444, align 8
  %v2487 = load i64, ptr %slot441, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2486, i64 %v2487) nomerge, !dbg !146
  br label %bb_rcgdone663
bb_rcgdec663:
  %v2488 = load i64, ptr %slot453, align 8
  %v2489 = load i64, ptr %slot445, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  %rgep2491 = getelementptr i8, ptr %p2490, i64 -24
  store i64 %v2488, ptr %rgep2491, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear663
bb_rcgclear663:
  %v2492 = load i64, ptr %slot441, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  store i64 0, ptr %p2493, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone663
bb_rcgdone663:
  br label %bb_rcslotdone647
bb_rcslotowner647:
  %v2494 = load i64, ptr %slot36, align 8
  store i64 %v2494, ptr %slot458, align 8
  %v2495 = load i64, ptr %slot441, align 8
  %p2496 = inttoptr i64 %v2495 to ptr
  %ld2497 = load i64, ptr %p2496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2497, ptr %slot459, align 8
  %v2498 = load i64, ptr %slot459, align 8
  %cmp2499 = icmp ne i64 %v2498, 0
  %cv2500 = zext i1 %cmp2499 to i32
  store i32 %cv2500, ptr %slot460, align 8
  %v2501 = load i32, ptr %slot460, align 8
  %cv2502 = zext i32 %v2501 to i64
  %cond2503 = icmp ne i64 %cv2502, 0
  br i1 %cond2503, label %bb_rcgnn678, label %bb_rcgdone678
bb_rcgnn678:
  %v2504 = load i64, ptr %slot459, align 8
  %op2505 = sub i64 %v2504, 16
  store i64 %op2505, ptr %slot461, align 8
  %v2506 = load i64, ptr %slot459, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  %rgep2508 = getelementptr i8, ptr %p2507, i64 -16
  %ld2509 = load i64, ptr %rgep2508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2509, ptr %slot462, align 8
  %v2510 = load i64, ptr %slot462, align 8
  %op2511 = and i64 %v2510, 4611686018427387906
  store i64 %op2511, ptr %slot463, align 8
  %v2512 = load i64, ptr %slot463, align 8
  %cmp2513 = icmp ne i64 %v2512, 0
  %cv2514 = zext i1 %cmp2513 to i32
  store i32 %cv2514, ptr %slot464, align 8
  %v2515 = load i32, ptr %slot464, align 8
  %cv2516 = zext i32 %v2515 to i64
  %cond2517 = icmp ne i64 %cv2516, 0
  br i1 %cond2517, label %bb_rcgclear678, label %bb_rcgcounted678
bb_rcgcounted678:
  %v2518 = load i64, ptr %slot459, align 8
  %op2519 = sub i64 %v2518, 32
  store i64 %op2519, ptr %slot465, align 8
  %v2520 = load i64, ptr %slot459, align 8
  %p2521 = inttoptr i64 %v2520 to ptr
  %rgep2522 = getelementptr i8, ptr %p2521, i64 -32
  %ld2523 = load i64, ptr %rgep2522, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2523, ptr %slot466, align 8
  %v2524 = load i64, ptr %slot466, align 8
  %op2525 = sub i64 %v2524, 1
  store i64 %op2525, ptr %slot467, align 8
  %v2526 = load i64, ptr %slot467, align 8
  %cmp2527 = icmp eq i64 %v2526, 0
  %cv2528 = zext i1 %cmp2527 to i32
  store i32 %cv2528, ptr %slot468, align 8
  %v2529 = load i32, ptr %slot468, align 8
  %cv2530 = zext i32 %v2529 to i64
  %cond2531 = icmp ne i64 %cv2530, 0
  br i1 %cond2531, label %bb_rcglast678, label %bb_rcgdec678
bb_rcglast678:
  %v2532 = load i64, ptr %slot459, align 8
  %op2533 = sub i64 %v2532, 24
  store i64 %op2533, ptr %slot469, align 8
  %v2534 = load i64, ptr %slot459, align 8
  %p2535 = inttoptr i64 %v2534 to ptr
  %rgep2536 = getelementptr i8, ptr %p2535, i64 -24
  %ld2537 = load i64, ptr %rgep2536, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2537, ptr %slot470, align 8
  %v2538 = load i64, ptr %slot470, align 8
  %cmp2539 = icmp ne i64 %v2538, 0
  %cv2540 = zext i1 %cmp2539 to i32
  store i32 %cv2540, ptr %slot471, align 8
  %v2541 = load i32, ptr %slot471, align 8
  %cv2542 = zext i32 %v2541 to i64
  %cond2543 = icmp ne i64 %cv2542, 0
  br i1 %cond2543, label %bb_rcgdec678, label %bb_rcgslow678
bb_rcgslow678:
  %v2544 = load i64, ptr %slot458, align 8
  %v2545 = load i64, ptr %slot441, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2544, i64 %v2545) nomerge, !dbg !146
  br label %bb_rcgdone678
bb_rcgdec678:
  %v2546 = load i64, ptr %slot467, align 8
  %v2547 = load i64, ptr %slot459, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  %rgep2549 = getelementptr i8, ptr %p2548, i64 -32
  store i64 %v2546, ptr %rgep2549, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear678
bb_rcgclear678:
  %v2550 = load i64, ptr %slot441, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  store i64 0, ptr %p2551, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone678
bb_rcgdone678:
  br label %bb_rcslotdone647
bb_rcslotdone647:
  %v2552 = load i64, ptr %slot433, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2553, i64 24, i1 false)
  ret void
bb_failure:
  %v2554 = load i64, ptr %slot5, align 8
  %p2555 = inttoptr i64 %v2554 to ptr
  call void @llvm.memset.p0.i64(ptr %p2555, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !146
  %v2556 = load i64, ptr %slot5, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2557, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v2558 = load i64, ptr %slot5, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  call void @llvm.memset.p0.i64(ptr %p2559, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !146
  %v2560 = load i64, ptr %slot5, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2561, i64 24, i1 false)
  ret void
}

@myl_f_8a9892bcaf1d54845365507fdbe66f11290e39bbcea0301e2767f370744c950d_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_iteration(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64, i64)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64, i64)
declare void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64, i64)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64, i64, i64)
declare void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8a9892bcaf1d54845365507fdbe66f11290e39bbcea0301e2767f370744c950d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8a9892bcaf1d54845365507fdbe66f11290e39bbcea0301e2767f370744c950d", linkageName: "myl_f_8a9892bcaf1d54845365507fdbe66f11290e39bbcea0301e2767f370744c950d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 12203079856745775723, i64 0, !"myl_f_8a9892bcaf1d54845365507fdbe66f11290e39bbcea0301e2767f370744c950d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!126 = !DILocation(line: 19, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!128 = !DILocation(line: 23, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!130 = !DILocation(line: 30, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!132 = !DILocation(line: 33, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!134 = !DILocation(line: 37, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!136 = !DILocation(line: 38, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!138 = !DILocation(line: 40, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!140 = !DILocation(line: 48, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!142 = !DILocation(line: 50, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!144 = !DILocation(line: 54, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!146 = !DILocation(line: 59, column: 0, scope: !147)
