target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v67 = load i64, ptr %slot1, align 8
  %op68 = add i64 %v67, 32
  store i64 %op68, ptr %slot3, align 8
  %mem69 = alloca i8, i64 16, align 8
  %ptr70 = ptrtoint ptr %mem69 to i64
  store i64 %ptr70, ptr %slot4, align 8
  %mem71 = alloca i8, i64 8, align 8
  %ptr72 = ptrtoint ptr %mem71 to i64
  store i64 %ptr72, ptr %slot5, align 8
  %mem73 = alloca i8, i64 8, align 8
  %ptr74 = ptrtoint ptr %mem73 to i64
  store i64 %ptr74, ptr %slot6, align 8
  %mem75 = alloca i8, i64 8, align 8
  %ptr76 = ptrtoint ptr %mem75 to i64
  store i64 %ptr76, ptr %slot7, align 8
  %mem77 = alloca i8, i64 8, align 8
  %ptr78 = ptrtoint ptr %mem77 to i64
  store i64 %ptr78, ptr %slot8, align 8
  %mem79 = alloca i8, i64 8, align 8
  %ptr80 = ptrtoint ptr %mem79 to i64
  store i64 %ptr80, ptr %slot9, align 8
  %mem81 = alloca i8, i64 8, align 8
  %ptr82 = ptrtoint ptr %mem81 to i64
  store i64 %ptr82, ptr %slot10, align 8
  %v83 = load i64, ptr %slot7, align 8
  %p84 = inttoptr i64 %v83 to ptr
  store i64 0, ptr %p84, align 8, !alias.scope !3, !noalias !4
  %v85 = load i64, ptr %slot2, align 8
  %v86 = load i64, ptr %slot5, align 8
  %p87 = inttoptr i64 %v86 to ptr
  store i64 %v85, ptr %p87, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v88 = load i64, ptr %slot5, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !3, !noalias !4
  store i64 %ld90, ptr %slot11, align 8
  %v91 = load i64, ptr %slot11, align 8
  %v92 = load i64, ptr %slot9, align 8
  %p93 = inttoptr i64 %v92 to ptr
  store i64 %v91, ptr %p93, align 8, !alias.scope !3, !noalias !4
  %v94 = load i64, ptr %slot9, align 8
  %p95 = inttoptr i64 %v94 to ptr
  %ld96 = load i64, ptr %p95, align 8, !alias.scope !3, !noalias !4
  store i64 %ld96, ptr %slot12, align 8
  %v97 = load i64, ptr %slot12, align 8
  %op98 = add i64 %v97, 128
  store i64 %op98, ptr %slot13, align 8
  %v99 = load i64, ptr %slot13, align 8
  %p100 = inttoptr i64 %v99 to ptr
  %ld101 = load i64, ptr %p100, align 8, !alias.scope !4, !noalias !3
  store i64 %ld101, ptr %slot14, align 8
  %v102 = load i64, ptr %slot14, align 8
  %v103 = load i64, ptr %slot9, align 8
  %p104 = inttoptr i64 %v103 to ptr
  store i64 %v102, ptr %p104, align 8, !alias.scope !3, !noalias !4
  %v105 = load i64, ptr %slot10, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i64 1, ptr %p106, align 8, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot10, align 8
  %p108 = inttoptr i64 %v107 to ptr
  %ld109 = load i64, ptr %p108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld109, ptr %slot15, align 8
  %v110 = load i64, ptr %slot9, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld112, ptr %slot16, align 8
  %v113 = load i64, ptr %slot16, align 8
  %v114 = load i64, ptr %slot15, align 8
  %ovpair116 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v113, i64 %v114)
  %op115 = extractvalue { i64, i1 } %ovpair116, 0
  %ov117 = extractvalue { i64, i1 } %ovpair116, 1
  store i64 %op115, ptr %slot17, align 8
  %cv118 = zext i1 %ov117 to i64
  store i64 %cv118, ptr %slot18, align 8
  %v119 = load i64, ptr %slot18, align 8
  %cond120 = icmp ne i64 %v119, 0
  br i1 %cond120, label %bb_overflow18, label %bb_checked18
bb_overflow18:
  %v121 = load i64, ptr %slot1, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %v123 = load i64, ptr %slot16, align 8
  %v124 = load i64, ptr %slot15, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p122, i64 1, i64 %v123, i64 %v124, i64 64) nomerge, !dbg !110
  unreachable
bb_checked18:
  %v125 = load i64, ptr %slot17, align 8
  %v126 = load i64, ptr %slot9, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i64 %v125, ptr %p127, align 8, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot9, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i64, ptr %p129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld130, ptr %slot19, align 8
  %v131 = load i64, ptr %slot19, align 8
  %v132 = load i64, ptr %slot6, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i64 %v131, ptr %p133, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot5, align 8
  %p135 = inttoptr i64 %v134 to ptr
  %ld136 = load i64, ptr %p135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld136, ptr %slot20, align 8
  %v137 = load i64, ptr %slot20, align 8
  %v138 = load i64, ptr %slot9, align 8
  %p139 = inttoptr i64 %v138 to ptr
  store i64 %v137, ptr %p139, align 8, !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot5, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i64, ptr %p141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld142, ptr %slot21, align 8
  %v143 = load i64, ptr %slot21, align 8
  %v144 = load i64, ptr %slot9, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 %v143, ptr %p145, align 8, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot5, align 8
  %p147 = inttoptr i64 %v146 to ptr
  %ld148 = load i64, ptr %p147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld148, ptr %slot22, align 8
  %v149 = load i64, ptr %slot22, align 8
  %v150 = load i64, ptr %slot9, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot6, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot23, align 8
  %v155 = load i64, ptr %slot23, align 8
  %v156 = load i64, ptr %slot10, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 %v155, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot5, align 8
  %p159 = inttoptr i64 %v158 to ptr
  %ld160 = load i64, ptr %p159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld160, ptr %slot24, align 8
  %v161 = load i64, ptr %slot24, align 8
  %v162 = load i64, ptr %slot9, align 8
  %p163 = inttoptr i64 %v162 to ptr
  store i64 %v161, ptr %p163, align 8, !alias.scope !3, !noalias !4
  %v164 = load i64, ptr %slot6, align 8
  %p165 = inttoptr i64 %v164 to ptr
  %ld166 = load i64, ptr %p165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld166, ptr %slot25, align 8
  %v167 = load i64, ptr %slot5, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %ld169 = load i64, ptr %p168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld169, ptr %slot26, align 8
  %v170 = load i64, ptr %slot26, align 8
  %op171 = add i64 %v170, 128
  store i64 %op171, ptr %slot27, align 8
  %v172 = load i64, ptr %slot25, align 8
  %v173 = load i64, ptr %slot27, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i64 %v172, ptr %p174, align 8, !alias.scope !4, !noalias !3
  %v175 = load i64, ptr %slot9, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i64 0, ptr %p176, align 8, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot5, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot28, align 8
  %v180 = load i64, ptr %slot28, align 8
  %v181 = load i64, ptr %slot9, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot9, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i64, ptr %p184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld185, ptr %slot29, align 8
  %v186 = load i64, ptr %slot29, align 8
  %op187 = add i64 %v186, 120
  store i64 %op187, ptr %slot30, align 8
  %v188 = load i64, ptr %slot30, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !4, !noalias !3
  store i64 %ld190, ptr %slot31, align 8
  %v191 = load i64, ptr %slot31, align 8
  %v192 = load i64, ptr %slot9, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i64 %v191, ptr %p193, align 8, !alias.scope !3, !noalias !4
  %v194 = load i64, ptr %slot9, align 8
  %p195 = inttoptr i64 %v194 to ptr
  %ld196 = load i64, ptr %p195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld196, ptr %slot32, align 8
  %v197 = load i64, ptr %slot32, align 8
  %v198 = load i64, ptr %slot7, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i64 %v197, ptr %p199, align 8, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot5, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i64, ptr %p201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld202, ptr %slot33, align 8
  %v203 = load i64, ptr %slot33, align 8
  %v204 = load i64, ptr %slot9, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot9, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %ld208 = load i64, ptr %p207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld208, ptr %slot34, align 8
  %v209 = load i64, ptr %slot34, align 8
  %op210 = add i64 %v209, 128
  store i64 %op210, ptr %slot35, align 8
  %v211 = load i64, ptr %slot35, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !4, !noalias !3
  store i64 %ld213, ptr %slot36, align 8
  %v214 = load i64, ptr %slot36, align 8
  %v215 = load i64, ptr %slot9, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot9, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld219, ptr %slot37, align 8
  %v220 = load i64, ptr %slot37, align 8
  %v221 = load i64, ptr %slot8, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i64 %v220, ptr %p222, align 8, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot8, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ld225 = load i64, ptr %p224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld225, ptr %slot38, align 8
  %v226 = load i64, ptr %slot38, align 8
  %v227 = load i64, ptr %slot9, align 8
  %p228 = inttoptr i64 %v227 to ptr
  store i64 %v226, ptr %p228, align 8, !alias.scope !3, !noalias !4
  %v229 = load i64, ptr %slot10, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 0, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot10, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld233, ptr %slot39, align 8
  %v234 = load i64, ptr %slot9, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %ld236 = load i64, ptr %p235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld236, ptr %slot40, align 8
  %v237 = load i64, ptr %slot40, align 8
  %v238 = load i64, ptr %slot39, align 8
  %cmp239 = icmp slt i64 %v237, %v238
  %cv240 = zext i1 %cmp239 to i64
  store i64 %cv240, ptr %slot41, align 8
  %v241 = load i64, ptr %slot41, align 8
  %v242 = load i64, ptr %slot9, align 8
  %p243 = inttoptr i64 %v242 to ptr
  store i64 %v241, ptr %p243, align 8, !alias.scope !3, !noalias !4
  %v244 = load i64, ptr %slot9, align 8
  %p245 = inttoptr i64 %v244 to ptr
  %ld246 = load i64, ptr %p245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld246, ptr %slot42, align 8
  %v247 = load i64, ptr %slot42, align 8
  %cond248 = icmp ne i64 %v247, 0
  br i1 %cond248, label %bb_next62, label %bb_i30
bb_next62:
  %v249 = load i64, ptr %slot7, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %ld251 = load i64, ptr %p250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld251, ptr %slot43, align 8
  %v252 = load i64, ptr %slot43, align 8
  %op253 = add i64 %v252, 0
  store i64 %op253, ptr %slot44, align 8
  %v254 = load i64, ptr %slot44, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %ld256 = load i64, ptr %p255, align 8, !alias.scope !6, !noalias !7
  store i64 %ld256, ptr %slot45, align 8
  %v257 = load i64, ptr %slot45, align 8
  %v258 = load i64, ptr %slot9, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i64 %v257, ptr %p259, align 8, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot9, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i64, ptr %p261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld262, ptr %slot46, align 8
  %v263 = load i64, ptr %slot46, align 8
  %cmp264 = icmp ugt i64 %v263, 9223372036854775807
  %cv265 = zext i1 %cmp264 to i64
  store i64 %cv265, ptr %slot47, align 8
  %v266 = load i64, ptr %slot47, align 8
  %cond267 = icmp ne i64 %v266, 0
  br i1 %cond267, label %bb_cast_overflow67, label %bb_cast_ok67
bb_cast_overflow67:
  %v268 = load i64, ptr %slot1, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %v270 = load i64, ptr %slot46, align 8
  call void @myl_qbe_fail_cast(ptr %p269, i64 %v270, i64 320) nomerge, !dbg !112
  unreachable
bb_cast_ok67:
  %v271 = load i64, ptr %slot46, align 8
  %v272 = load i64, ptr %slot9, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i64 %v271, ptr %p273, align 8, !alias.scope !3, !noalias !4
  %v274 = load i64, ptr %slot8, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot48, align 8
  %v277 = load i64, ptr %slot48, align 8
  %v278 = load i64, ptr %slot10, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 %v277, ptr %p279, align 8, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot10, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot49, align 8
  %v283 = load i64, ptr %slot9, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld285, ptr %slot50, align 8
  %v286 = load i64, ptr %slot50, align 8
  %v287 = load i64, ptr %slot49, align 8
  %ovpair289 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v286, i64 %v287)
  %op288 = extractvalue { i64, i1 } %ovpair289, 0
  %ov290 = extractvalue { i64, i1 } %ovpair289, 1
  store i64 %op288, ptr %slot51, align 8
  %v291 = load i64, ptr %slot50, align 8
  %v292 = load i64, ptr %slot51, align 8
  %op293 = xor i64 %v291, %v292
  store i64 %op293, ptr %slot52, align 8
  %v294 = load i64, ptr %slot49, align 8
  %v295 = load i64, ptr %slot51, align 8
  %op296 = xor i64 %v294, %v295
  store i64 %op296, ptr %slot53, align 8
  %v297 = load i64, ptr %slot52, align 8
  %v298 = load i64, ptr %slot53, align 8
  %op299 = and i64 %v297, %v298
  store i64 %op299, ptr %slot54, align 8
  %cv300 = zext i1 %ov290 to i64
  store i64 %cv300, ptr %slot55, align 8
  %v301 = load i64, ptr %slot55, align 8
  %cond302 = icmp ne i64 %v301, 0
  br i1 %cond302, label %bb_overflow71, label %bb_checked71
bb_overflow71:
  %v303 = load i64, ptr %slot1, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %v305 = load i64, ptr %slot50, align 8
  %v306 = load i64, ptr %slot49, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p304, i64 0, i64 %v305, i64 %v306, i64 64) nomerge, !dbg !114
  unreachable
bb_checked71:
  %v307 = load i64, ptr %slot51, align 8
  %v308 = load i64, ptr %slot9, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 %v307, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot9, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %ld312 = load i64, ptr %p311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld312, ptr %slot56, align 8
  %v313 = load i64, ptr %slot56, align 8
  %v314 = load i64, ptr %slot8, align 8
  %p315 = inttoptr i64 %v314 to ptr
  store i64 %v313, ptr %p315, align 8, !alias.scope !3, !noalias !4
  br label %bb_i30
bb_i30:
  %v316 = load i64, ptr %slot8, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %ld318 = load i64, ptr %p317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld318, ptr %slot57, align 8
  %v319 = load i64, ptr %slot57, align 8
  %v320 = load i64, ptr %slot9, align 8
  %p321 = inttoptr i64 %v320 to ptr
  store i64 %v319, ptr %p321, align 8, !alias.scope !3, !noalias !4
  %v322 = load i64, ptr %slot7, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %ld324 = load i64, ptr %p323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld324, ptr %slot58, align 8
  %v325 = load i64, ptr %slot9, align 8
  %p326 = inttoptr i64 %v325 to ptr
  %ld327 = load i64, ptr %p326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld327, ptr %slot59, align 8
  %v328 = load i64, ptr %slot58, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i64, ptr %p329, align 8, !alias.scope !6, !noalias !7
  store i64 %ld330, ptr %slot60, align 8
  %v331 = load i64, ptr %slot59, align 8
  %v332 = load i64, ptr %slot60, align 8
  %cmp333 = icmp ult i64 %v331, %v332
  %cv334 = zext i1 %cmp333 to i64
  store i64 %cv334, ptr %slot61, align 8
  %v335 = load i64, ptr %slot61, align 8
  %cond336 = icmp ne i64 %v335, 0
  br i1 %cond336, label %bb_success83, label %bb_failed83
bb_failed83:
  %v337 = load i64, ptr %slot1, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %v339 = load i64, ptr %slot59, align 8
  %v340 = load i64, ptr %slot60, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p338, i64 %v339, i64 %v340) nomerge, !dbg !116
  unreachable
bb_success83:
  %v341 = load i64, ptr %slot58, align 8
  %op342 = add i64 %v341, 32
  store i64 %op342, ptr %slot62, align 8
  %v343 = load i64, ptr %slot62, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %ld345 = load i64, ptr %p344, align 8, !alias.scope !6, !noalias !7
  store i64 %ld345, ptr %slot63, align 8
  %v346 = load i64, ptr %slot59, align 8
  %op347 = mul i64 %v346, 16
  store i64 %op347, ptr %slot64, align 8
  %v348 = load i64, ptr %slot63, align 8
  %v349 = load i64, ptr %slot64, align 8
  %op350 = add i64 %v348, %v349
  store i64 %op350, ptr %slot65, align 8
  %v351 = load i64, ptr %slot65, align 8
  %v352 = load i64, ptr %slot9, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i64 %v351, ptr %p353, align 8, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot9, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %ld356 = load i64, ptr %p355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld356, ptr %slot66, align 8
  %v357 = load i64, ptr %slot66, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %ret359 = load { i64, i64 }, ptr %p358, align 8
  ret { i64, i64 } %ret359
bb_failure:
  %v360 = load i64, ptr %slot4, align 8
  %p361 = inttoptr i64 %v360 to ptr
  call void @llvm.memset.p0.i64(ptr %p361, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v362 = load i64, ptr %slot4, align 8
  %p363 = inttoptr i64 %v362 to ptr
  %ret364 = load { i64, i64 }, ptr %p363, align 8
  ret { i64, i64 } %ret364
bb_entry_failure:
  %v365 = load i64, ptr %slot4, align 8
  %p366 = inttoptr i64 %v365 to ptr
  call void @llvm.memset.p0.i64(ptr %p366, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v367 = load i64, ptr %slot4, align 8
  %p368 = inttoptr i64 %v367 to ptr
  %ret369 = load { i64, i64 }, ptr %p368, align 8
  ret { i64, i64 } %ret369
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1", linkageName: "myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15806422781947751454, i64 0, !"myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!110 = !DILocation(line: 4, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!112 = !DILocation(line: 27, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!114 = !DILocation(line: 29, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!116 = !DILocation(line: 32, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!118 = !DILocation(line: 33, column: 0, scope: !119)
