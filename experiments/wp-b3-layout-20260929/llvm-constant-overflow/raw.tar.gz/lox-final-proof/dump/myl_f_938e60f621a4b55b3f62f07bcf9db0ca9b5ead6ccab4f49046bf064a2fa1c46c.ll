target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_938e60f621a4b55b3f62f07bcf9db0ca9b5ead6ccab4f49046bf064a2fa1c46c(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v55 = load i64, ptr %slot1, align 8
  %op56 = add i64 %v55, 32
  store i64 %op56, ptr %slot3, align 8
  %mem57 = alloca i8, i64 8, align 8
  %ptr58 = ptrtoint ptr %mem57 to i64
  store i64 %ptr58, ptr %slot4, align 8
  %mem59 = alloca i8, i64 8, align 8
  %ptr60 = ptrtoint ptr %mem59 to i64
  store i64 %ptr60, ptr %slot5, align 8
  %mem61 = alloca i8, i64 8, align 8
  %ptr62 = ptrtoint ptr %mem61 to i64
  store i64 %ptr62, ptr %slot6, align 8
  %mem63 = alloca i8, i64 8, align 8
  %ptr64 = ptrtoint ptr %mem63 to i64
  store i64 %ptr64, ptr %slot7, align 8
  %mem65 = alloca i8, i64 8, align 8
  %ptr66 = ptrtoint ptr %mem65 to i64
  store i64 %ptr66, ptr %slot8, align 8
  %mem67 = alloca i8, i64 8, align 8
  %ptr68 = ptrtoint ptr %mem67 to i64
  store i64 %ptr68, ptr %slot9, align 8
  %mem69 = alloca i8, i64 8, align 8
  %ptr70 = ptrtoint ptr %mem69 to i64
  store i64 %ptr70, ptr %slot10, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem71 = alloca i8, i64 8, align 8
  %ptr72 = ptrtoint ptr %mem71 to i64
  store i64 %ptr72, ptr %slot11, align 8
  %v73 = load i64, ptr %slot1, align 8
  %op74 = add i64 %v73, 64
  store i64 %op74, ptr %slot12, align 8
  %v75 = load i64, ptr %slot12, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %ld77 = load i64, ptr %p76, align 8, !alias.scope !4, !noalias !3
  store i64 %ld77, ptr %slot13, align 8
  %stack78 = call ptr @llvm.stacksave()
  %stackaddr79 = ptrtoint ptr %stack78 to i64
  %v80 = load i64, ptr %slot13, align 8
  %cmp81 = icmp ult i64 %stackaddr79, %v80
  %cv82 = zext i1 %cmp81 to i64
  store i64 %cv82, ptr %slot14, align 8
  %v83 = load i64, ptr %slot14, align 8
  %cond84 = icmp ne i64 %v83, 0
  br i1 %cond84, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v85 = load i64, ptr %slot1, align 8
  %p86 = inttoptr i64 %v85 to ptr
  call void @myl_qbe_fail_frame(ptr %p86) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v87 = load i64, ptr %slot2, align 8
  %v88 = load i64, ptr %slot4, align 8
  %p89 = inttoptr i64 %v88 to ptr
  store i64 %v87, ptr %p89, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v90 = load i64, ptr %slot4, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !3, !noalias !4
  store i64 %ld92, ptr %slot15, align 8
  %v93 = load i64, ptr %slot15, align 8
  %v94 = load i64, ptr %slot6, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 %v93, ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot6, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot16, align 8
  %v99 = load i64, ptr %slot16, align 8
  %op100 = add i64 %v99, 328
  store i64 %op100, ptr %slot17, align 8
  %v101 = load i64, ptr %slot17, align 8
  %v102 = load i64, ptr %slot6, align 8
  %p103 = inttoptr i64 %v102 to ptr
  store i64 %v101, ptr %p103, align 8, !alias.scope !3, !noalias !4
  %v104 = load i64, ptr %slot6, align 8
  %p105 = inttoptr i64 %v104 to ptr
  %ld106 = load i64, ptr %p105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld106, ptr %slot18, align 8
  %v107 = load i64, ptr %slot18, align 8
  %op108 = add i64 %v107, 0
  store i64 %op108, ptr %slot19, align 8
  %v109 = load i64, ptr %slot19, align 8
  %v110 = load i64, ptr %slot6, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot6, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld114, ptr %slot20, align 8
  %v115 = load i64, ptr %slot20, align 8
  %v116 = load i64, ptr %slot5, align 8
  %p117 = inttoptr i64 %v115 to ptr
  %p118 = inttoptr i64 %v116 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p118, ptr %p117, i64 4, i1 false), !alias.scope !10000000
  %v119 = load i64, ptr %slot5, align 8
  %v120 = load i64, ptr %slot6, align 8
  %p121 = inttoptr i64 %v120 to ptr
  store i64 %v119, ptr %p121, align 8, !alias.scope !3, !noalias !4
  %v122 = load i64, ptr %slot8, align 8
  store i64 %v122, ptr %slot21, align 8
  %v123 = load i64, ptr %slot21, align 8
  %p124 = inttoptr i64 %v123 to ptr
  store i32 0, ptr %p124, align 4, !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot21, align 8
  %p126 = inttoptr i64 %v125 to ptr
  store i32 25, ptr %p126, align 4, !alias.scope !3, !noalias !4
  %v127 = load i64, ptr %slot21, align 8
  %v128 = load i64, ptr %slot7, align 8
  %p129 = inttoptr i64 %v128 to ptr
  store i64 %v127, ptr %p129, align 8, !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot7, align 8
  %p131 = inttoptr i64 %v130 to ptr
  %ld132 = load i64, ptr %p131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld132, ptr %slot22, align 8
  %v133 = load i64, ptr %slot6, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot23, align 8
  %v136 = load i64, ptr %slot23, align 8
  %p137 = inttoptr i64 %v136 to ptr
  %ld138 = load i32, ptr %p137, align 4, !alias.scope !3, !noalias !4
  %ext139 = zext i32 %ld138 to i64
  store i64 %ext139, ptr %slot24, align 8
  %v140 = load i64, ptr %slot22, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i32, ptr %p141, align 4, !alias.scope !3, !noalias !4
  %ext143 = zext i32 %ld142 to i64
  store i64 %ext143, ptr %slot25, align 8
  %v144 = load i64, ptr %slot24, align 8
  %v145 = load i64, ptr %slot25, align 8
  %cmp146 = icmp eq i64 %v144, %v145
  %cv147 = zext i1 %cmp146 to i64
  store i64 %cv147, ptr %slot26, align 8
  %v148 = load i64, ptr %slot26, align 8
  %v149 = load i64, ptr %slot6, align 8
  %p150 = inttoptr i64 %v149 to ptr
  store i64 %v148, ptr %p150, align 8, !alias.scope !3, !noalias !4
  %v151 = load i64, ptr %slot6, align 8
  %p152 = inttoptr i64 %v151 to ptr
  %ld153 = load i64, ptr %p152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld153, ptr %slot27, align 8
  %v154 = load i64, ptr %slot27, align 8
  %cond155 = icmp ne i64 %v154, 0
  br i1 %cond155, label %bb_next39, label %bb_i13
bb_next39:
  %v156 = load i64, ptr %slot4, align 8
  %p157 = inttoptr i64 %v156 to ptr
  %ld158 = load i64, ptr %p157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld158, ptr %slot28, align 8
  %v159 = load i64, ptr %slot28, align 8
  %v160 = load i64, ptr %slot6, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i64 %v159, ptr %p161, align 8, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot7, align 8
  %p163 = inttoptr i64 %v162 to ptr
  store i64 3, ptr %p163, align 8, !alias.scope !3, !noalias !4
  %v164 = load i64, ptr %slot6, align 8
  %p165 = inttoptr i64 %v164 to ptr
  %ld166 = load i64, ptr %p165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld166, ptr %slot29, align 8
  %v167 = load i64, ptr %slot7, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %ld169 = load i64, ptr %p168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld169, ptr %slot30, align 8
  %v170 = load i64, ptr %slot1, align 8
  %v171 = load i64, ptr %slot29, align 8
  %v172 = load i64, ptr %slot30, align 8
  %call173 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v170, i64 %v171, i64 %v172) nomerge, !dbg !112
  store i64 %call173, ptr %slot31, align 8
  %v174 = load i64, ptr %slot31, align 8
  %v175 = load i64, ptr %slot6, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i64 %v174, ptr %p176, align 8, !alias.scope !3, !noalias !4
  br label %bb_i30
bb_i13:
  %v177 = load i64, ptr %slot5, align 8
  %v178 = load i64, ptr %slot6, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i64 %v177, ptr %p179, align 8, !alias.scope !3, !noalias !4
  %v180 = load i64, ptr %slot9, align 8
  store i64 %v180, ptr %slot32, align 8
  %v181 = load i64, ptr %slot32, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i32 0, ptr %p182, align 4, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot32, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i32 29, ptr %p184, align 4, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot32, align 8
  %v186 = load i64, ptr %slot7, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot7, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld190, ptr %slot33, align 8
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot34, align 8
  %v194 = load i64, ptr %slot34, align 8
  %p195 = inttoptr i64 %v194 to ptr
  %ld196 = load i32, ptr %p195, align 4, !alias.scope !3, !noalias !4
  %ext197 = zext i32 %ld196 to i64
  store i64 %ext197, ptr %slot35, align 8
  %v198 = load i64, ptr %slot33, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i32, ptr %p199, align 4, !alias.scope !3, !noalias !4
  %ext201 = zext i32 %ld200 to i64
  store i64 %ext201, ptr %slot36, align 8
  %v202 = load i64, ptr %slot35, align 8
  %v203 = load i64, ptr %slot36, align 8
  %cmp204 = icmp eq i64 %v202, %v203
  %cv205 = zext i1 %cmp204 to i64
  store i64 %cv205, ptr %slot37, align 8
  %v206 = load i64, ptr %slot37, align 8
  %v207 = load i64, ptr %slot6, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i64 %v206, ptr %p208, align 8, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot6, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i64, ptr %p210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld211, ptr %slot38, align 8
  %v212 = load i64, ptr %slot38, align 8
  %cond213 = icmp ne i64 %v212, 0
  br i1 %cond213, label %bb_next59, label %bb_i22
bb_next59:
  %v214 = load i64, ptr %slot4, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot39, align 8
  %v217 = load i64, ptr %slot39, align 8
  %v218 = load i64, ptr %slot6, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot7, align 8
  %p221 = inttoptr i64 %v220 to ptr
  store i64 1, ptr %p221, align 8, !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot6, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %ld224 = load i64, ptr %p223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld224, ptr %slot40, align 8
  %v225 = load i64, ptr %slot7, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot41, align 8
  %v228 = load i64, ptr %slot1, align 8
  %v229 = load i64, ptr %slot40, align 8
  %v230 = load i64, ptr %slot41, align 8
  %call231 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v228, i64 %v229, i64 %v230) nomerge, !dbg !114
  store i64 %call231, ptr %slot42, align 8
  %v232 = load i64, ptr %slot42, align 8
  %v233 = load i64, ptr %slot6, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i64 %v232, ptr %p234, align 8, !alias.scope !3, !noalias !4
  br label %bb_i30
bb_i22:
  %v235 = load i64, ptr %slot5, align 8
  %v236 = load i64, ptr %slot6, align 8
  %p237 = inttoptr i64 %v236 to ptr
  store i64 %v235, ptr %p237, align 8, !alias.scope !3, !noalias !4
  %v238 = load i64, ptr %slot10, align 8
  store i64 %v238, ptr %slot43, align 8
  %v239 = load i64, ptr %slot43, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i32 0, ptr %p240, align 4, !alias.scope !3, !noalias !4
  %v241 = load i64, ptr %slot43, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i32 35, ptr %p242, align 4, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot43, align 8
  %v244 = load i64, ptr %slot7, align 8
  %p245 = inttoptr i64 %v244 to ptr
  store i64 %v243, ptr %p245, align 8, !alias.scope !3, !noalias !4
  %v246 = load i64, ptr %slot7, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld248, ptr %slot44, align 8
  %v249 = load i64, ptr %slot6, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %ld251 = load i64, ptr %p250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld251, ptr %slot45, align 8
  %v252 = load i64, ptr %slot45, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i32, ptr %p253, align 4, !alias.scope !3, !noalias !4
  %ext255 = zext i32 %ld254 to i64
  store i64 %ext255, ptr %slot46, align 8
  %v256 = load i64, ptr %slot44, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i32, ptr %p257, align 4, !alias.scope !3, !noalias !4
  %ext259 = zext i32 %ld258 to i64
  store i64 %ext259, ptr %slot47, align 8
  %v260 = load i64, ptr %slot46, align 8
  %v261 = load i64, ptr %slot47, align 8
  %cmp262 = icmp eq i64 %v260, %v261
  %cv263 = zext i1 %cmp262 to i64
  store i64 %cv263, ptr %slot48, align 8
  %v264 = load i64, ptr %slot48, align 8
  %v265 = load i64, ptr %slot6, align 8
  %p266 = inttoptr i64 %v265 to ptr
  store i64 %v264, ptr %p266, align 8, !alias.scope !3, !noalias !4
  %v267 = load i64, ptr %slot6, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %ld269 = load i64, ptr %p268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld269, ptr %slot49, align 8
  %v270 = load i64, ptr %slot49, align 8
  %cond271 = icmp ne i64 %v270, 0
  br i1 %cond271, label %bb_next79, label %bb_i30
bb_next79:
  %v272 = load i64, ptr %slot4, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %ld274 = load i64, ptr %p273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld274, ptr %slot50, align 8
  %v275 = load i64, ptr %slot50, align 8
  %v276 = load i64, ptr %slot6, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i64 %v275, ptr %p277, align 8, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot7, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 2, ptr %p279, align 8, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot6, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot51, align 8
  %v283 = load i64, ptr %slot7, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld285, ptr %slot52, align 8
  %v286 = load i64, ptr %slot1, align 8
  %v287 = load i64, ptr %slot51, align 8
  %v288 = load i64, ptr %slot52, align 8
  %call289 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v286, i64 %v287, i64 %v288) nomerge, !dbg !116
  store i64 %call289, ptr %slot53, align 8
  %v290 = load i64, ptr %slot53, align 8
  %v291 = load i64, ptr %slot6, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i64 %v290, ptr %p292, align 8, !alias.scope !3, !noalias !4
  br label %bb_i30
bb_i30:
  %v293 = load i64, ptr %slot6, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i64 0, ptr %p294, align 8, !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot6, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %ld297 = load i64, ptr %p296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld297, ptr %slot54, align 8
  %v298 = load i64, ptr %slot54, align 8
  ret i64 %v298
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_938e60f621a4b55b3f62f07bcf9db0ca9b5ead6ccab4f49046bf064a2fa1c46c", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_938e60f621a4b55b3f62f07bcf9db0ca9b5ead6ccab4f49046bf064a2fa1c46c", linkageName: "myl_f_938e60f621a4b55b3f62f07bcf9db0ca9b5ead6ccab4f49046bf064a2fa1c46c", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14069507799753791557, i64 0, !"myl_f_938e60f621a4b55b3f62f07bcf9db0ca9b5ead6ccab4f49046bf064a2fa1c46c"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!112 = !DILocation(line: 11, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!114 = !DILocation(line: 20, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!116 = !DILocation(line: 29, column: 0, scope: !117)
