target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %callresult45 = alloca [40 x i8], align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %callresult110 = alloca [16 x i8], align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %callresult159 = alloca [48 x i8], align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v331 = load i64, ptr %slot1, align 8
  %op332 = add i64 %v331, 32
  store i64 %op332, ptr %slot3, align 8
  %mem333 = alloca i8, i64 16, align 8
  %ptr334 = ptrtoint ptr %mem333 to i64
  store i64 %ptr334, ptr %slot4, align 8
  %mem335 = alloca i8, i64 8, align 8
  %ptr336 = ptrtoint ptr %mem335 to i64
  store i64 %ptr336, ptr %slot5, align 8
  %mem337 = alloca i8, i64 8, align 8
  %ptr338 = ptrtoint ptr %mem337 to i64
  store i64 %ptr338, ptr %slot6, align 8
  %mem339 = alloca i8, i64 8, align 8
  %ptr340 = ptrtoint ptr %mem339 to i64
  store i64 %ptr340, ptr %slot7, align 8
  %mem341 = alloca i8, i64 8, align 8
  %ptr342 = ptrtoint ptr %mem341 to i64
  store i64 %ptr342, ptr %slot8, align 8
  %mem343 = alloca i8, i64 8, align 8
  %ptr344 = ptrtoint ptr %mem343 to i64
  store i64 %ptr344, ptr %slot9, align 8
  %mem345 = alloca i8, i64 8, align 8
  %ptr346 = ptrtoint ptr %mem345 to i64
  store i64 %ptr346, ptr %slot10, align 8
  %mem347 = alloca i8, i64 8, align 8
  %ptr348 = ptrtoint ptr %mem347 to i64
  store i64 %ptr348, ptr %slot11, align 8
  %mem349 = alloca i8, i64 8, align 8
  %ptr350 = ptrtoint ptr %mem349 to i64
  store i64 %ptr350, ptr %slot12, align 8
  %mem351 = alloca i8, i64 8, align 8
  %ptr352 = ptrtoint ptr %mem351 to i64
  store i64 %ptr352, ptr %slot13, align 8
  %mem353 = alloca i8, i64 8, align 8
  %ptr354 = ptrtoint ptr %mem353 to i64
  store i64 %ptr354, ptr %slot14, align 8
  %mem355 = alloca i8, i64 8, align 8
  %ptr356 = ptrtoint ptr %mem355 to i64
  store i64 %ptr356, ptr %slot15, align 8
  %mem357 = alloca i8, i64 312, align 8
  %ptr358 = ptrtoint ptr %mem357 to i64
  store i64 %ptr358, ptr %slot16, align 8
  %mem359 = alloca i8, i64 88, align 8
  %ptr360 = ptrtoint ptr %mem359 to i64
  store i64 %ptr360, ptr %slot17, align 8
  %mem361 = alloca i8, i64 16, align 8
  %ptr362 = ptrtoint ptr %mem361 to i64
  store i64 %ptr362, ptr %slot18, align 8
  %mem363 = alloca i8, i64 8, align 8
  %ptr364 = ptrtoint ptr %mem363 to i64
  store i64 %ptr364, ptr %slot19, align 8
  %mem365 = alloca i8, i64 312, align 8
  %ptr366 = ptrtoint ptr %mem365 to i64
  store i64 %ptr366, ptr %slot20, align 8
  %mem367 = alloca i8, i64 8, align 8
  %ptr368 = ptrtoint ptr %mem367 to i64
  store i64 %ptr368, ptr %slot21, align 8
  %mem369 = alloca i8, i64 40, align 8
  %ptr370 = ptrtoint ptr %mem369 to i64
  store i64 %ptr370, ptr %slot22, align 8
  %mem371 = alloca i8, i64 16, align 8
  %ptr372 = ptrtoint ptr %mem371 to i64
  store i64 %ptr372, ptr %slot23, align 8
  %mem373 = alloca i8, i64 8, align 8
  %ptr374 = ptrtoint ptr %mem373 to i64
  store i64 %ptr374, ptr %slot24, align 8
  %mem375 = alloca i8, i64 8, align 8
  %ptr376 = ptrtoint ptr %mem375 to i64
  store i64 %ptr376, ptr %slot25, align 8
  %mem377 = alloca i8, i64 8, align 8
  %ptr378 = ptrtoint ptr %mem377 to i64
  store i64 %ptr378, ptr %slot26, align 8
  %mem379 = alloca i8, i64 16, align 8
  %ptr380 = ptrtoint ptr %mem379 to i64
  store i64 %ptr380, ptr %slot27, align 8
  %mem381 = alloca i8, i64 312, align 8
  %ptr382 = ptrtoint ptr %mem381 to i64
  store i64 %ptr382, ptr %slot28, align 8
  %mem383 = alloca i8, i64 16, align 8
  %ptr384 = ptrtoint ptr %mem383 to i64
  store i64 %ptr384, ptr %slot29, align 8
  %mem385 = alloca i8, i64 16, align 8
  %ptr386 = ptrtoint ptr %mem385 to i64
  store i64 %ptr386, ptr %slot30, align 8
  %mem387 = alloca i8, i64 312, align 8
  %ptr388 = ptrtoint ptr %mem387 to i64
  store i64 %ptr388, ptr %slot31, align 8
  %mem389 = alloca i8, i64 48, align 8
  %ptr390 = ptrtoint ptr %mem389 to i64
  store i64 %ptr390, ptr %slot32, align 8
  %mem391 = alloca i8, i64 312, align 8
  %ptr392 = ptrtoint ptr %mem391 to i64
  store i64 %ptr392, ptr %slot33, align 8
  %mem393 = alloca i8, i64 312, align 8
  %ptr394 = ptrtoint ptr %mem393 to i64
  store i64 %ptr394, ptr %slot34, align 8
  %mem395 = alloca i8, i64 16, align 8
  %ptr396 = ptrtoint ptr %mem395 to i64
  store i64 %ptr396, ptr %slot35, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem397 = alloca i8, i64 8, align 8
  %ptr398 = ptrtoint ptr %mem397 to i64
  store i64 %ptr398, ptr %slot36, align 8
  %v399 = load i64, ptr %slot1, align 8
  %op400 = add i64 %v399, 64
  store i64 %op400, ptr %slot37, align 8
  %v401 = load i64, ptr %slot37, align 8
  %p402 = inttoptr i64 %v401 to ptr
  %ld403 = load i64, ptr %p402, align 8, !alias.scope !4, !noalias !3
  store i64 %ld403, ptr %slot38, align 8
  %stack404 = call ptr @llvm.stacksave()
  %stackaddr405 = ptrtoint ptr %stack404 to i64
  %v406 = load i64, ptr %slot38, align 8
  %cmp407 = icmp ult i64 %stackaddr405, %v406
  %cv408 = zext i1 %cmp407 to i64
  store i64 %cv408, ptr %slot39, align 8
  %v409 = load i64, ptr %slot39, align 8
  %cond410 = icmp ne i64 %v409, 0
  br i1 %cond410, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v411 = load i64, ptr %slot1, align 8
  %p412 = inttoptr i64 %v411 to ptr
  call void @myl_qbe_fail_frame(ptr %p412) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v413 = load i64, ptr %slot2, align 8
  %v414 = load i64, ptr %slot21, align 8
  %p415 = inttoptr i64 %v414 to ptr
  store i64 %v413, ptr %p415, align 8, !alias.scope !3, !noalias !4
  %v416 = load i64, ptr %slot1, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %call418 = call ptr @myl_qbe_heap(ptr %p417) nomerge, !dbg !112
  %calladdr419 = ptrtoint ptr %call418 to i64
  store i64 %calladdr419, ptr %slot40, align 8
  %v420 = load i64, ptr %slot1, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %call422 = call i64 @myl_qbe_region_mark(ptr %p421) nomerge, !dbg !112
  store i64 %call422, ptr %slot41, align 8
  %v423 = load i64, ptr %slot5, align 8
  %p424 = inttoptr i64 %v423 to ptr
  store i32 0, ptr %p424, align 4, !alias.scope !3, !noalias !4
  %v425 = load i64, ptr %slot6, align 8
  %p426 = inttoptr i64 %v425 to ptr
  store i32 0, ptr %p426, align 4, !alias.scope !3, !noalias !4
  %v427 = load i64, ptr %slot7, align 8
  %p428 = inttoptr i64 %v427 to ptr
  store i32 0, ptr %p428, align 4, !alias.scope !3, !noalias !4
  %v429 = load i64, ptr %slot8, align 8
  %p430 = inttoptr i64 %v429 to ptr
  store i32 0, ptr %p430, align 4, !alias.scope !3, !noalias !4
  %v431 = load i64, ptr %slot9, align 8
  %p432 = inttoptr i64 %v431 to ptr
  store i32 0, ptr %p432, align 4, !alias.scope !3, !noalias !4
  %v433 = load i64, ptr %slot10, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i32 0, ptr %p434, align 4, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot11, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i32 0, ptr %p436, align 4, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot12, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i32 0, ptr %p438, align 4, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot13, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i32 0, ptr %p440, align 4, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot14, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i32 0, ptr %p442, align 4, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot15, align 8
  %p444 = inttoptr i64 %v443 to ptr
  store i32 0, ptr %p444, align 4, !alias.scope !3, !noalias !4
  %v445 = load i64, ptr %slot6, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i32 2, ptr %p446, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v447 = load i64, ptr %slot21, align 8
  %p448 = inttoptr i64 %v447 to ptr
  %ld449 = load i64, ptr %p448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld449, ptr %slot42, align 8
  %v450 = load i64, ptr %slot42, align 8
  %v451 = load i64, ptr %slot24, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i64 %v450, ptr %p452, align 8, !alias.scope !3, !noalias !4
  %v453 = load i64, ptr %slot24, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %ld455 = load i64, ptr %p454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld455, ptr %slot43, align 8
  %v456 = load i64, ptr %slot1, align 8
  %v457 = load i64, ptr %slot43, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult45, i64 %v456, i64 %v457) nomerge, !dbg !114
  %addr458 = ptrtoint ptr %callresult45 to i64
  store i64 %addr458, ptr %slot44, align 8
  %v459 = load i64, ptr %slot44, align 8
  %v460 = load i64, ptr %slot24, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i64 %v459, ptr %p461, align 8, !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot24, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i64, ptr %p463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld464, ptr %slot46, align 8
  %v465 = load i64, ptr %slot20, align 8
  store i64 %v465, ptr %slot47, align 8
  %v466 = load i64, ptr %slot40, align 8
  %v467 = load i64, ptr %slot47, align 8
  %v468 = load i64, ptr %slot46, align 8
  %call469 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v466, i64 %v467, i64 %v468) nomerge, !dbg !114
  store i32 %call469, ptr %slot48, align 8
  %v470 = load i32, ptr %slot48, align 8
  %cv471 = zext i32 %v470 to i64
  %cond472 = icmp ne i64 %cv471, 0
  br i1 %cond472, label %bb_rcsuccess15, label %bb_rcfailure15
bb_rcfailure15:
  %v473 = load i64, ptr %slot40, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %call475 = call i32 @myl_rc_take_failure(ptr %p474) nomerge, !dbg !114
  store i32 %call475, ptr %slot49, align 8
  %v476 = load i64, ptr %slot1, align 8
  %p477 = inttoptr i64 %v476 to ptr
  %v478 = load i32, ptr %slot49, align 8
  %call479 = call i32 @myl_qbe_rc_status(ptr %p477, i32 %v478) nomerge, !dbg !114
  store i32 %call479, ptr %slot50, align 8
  br label %bb_failure
bb_rcsuccess15:
  %v480 = load i64, ptr %slot14, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i32 2, ptr %p481, align 4, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot14, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 16, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot13, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 1, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot7, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %ld488 = load i32, ptr %p487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld488, ptr %slot51, align 8
  %v489 = load i32, ptr %slot51, align 8
  %cv490 = zext i32 %v489 to i64
  %cond491 = icmp ne i64 %cv490, 0
  br i1 %cond491, label %bb_rcslotdrop23, label %bb_rcslotdone23
bb_rcslotdrop23:
  %v492 = load i64, ptr %slot7, align 8
  %p493 = inttoptr i64 %v492 to ptr
  store i32 0, ptr %p493, align 4, !alias.scope !3, !noalias !4
  %v494 = load i64, ptr %slot16, align 8
  store i64 %v494, ptr %slot52, align 8
  %v495 = load i64, ptr %slot8, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %ld497 = load i32, ptr %p496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld497, ptr %slot53, align 8
  %v498 = load i32, ptr %slot53, align 8
  %op499 = and i32 %v498, 28
  store i32 %op499, ptr %slot54, align 8
  %v500 = load i32, ptr %slot54, align 8
  %cv501 = zext i32 %v500 to i64
  %cond502 = icmp ne i64 %cv501, 0
  br i1 %cond502, label %bb_rcslotrole23, label %bb_rcslotowner23
bb_rcslotrole23:
  %v503 = load i64, ptr %slot40, align 8
  store i64 %v503, ptr %slot55, align 8
  %v504 = load i64, ptr %slot55, align 8
  %v505 = load i64, ptr %slot52, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v504, i64 %v505) nomerge, !dbg !114
  br label %bb_rcslotdone23
bb_rcslotowner23:
  %v506 = load i64, ptr %slot40, align 8
  store i64 %v506, ptr %slot56, align 8
  %v507 = load i64, ptr %slot56, align 8
  %v508 = load i64, ptr %slot52, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v507, i64 %v508) nomerge, !dbg !114
  br label %bb_rcslotdone23
bb_rcslotdone23:
  %v509 = load i64, ptr %slot16, align 8
  store i64 %v509, ptr %slot57, align 8
  %v510 = load i64, ptr %slot20, align 8
  store i64 %v510, ptr %slot58, align 8
  %v511 = load i64, ptr %slot58, align 8
  %v512 = load i64, ptr %slot57, align 8
  %p513 = inttoptr i64 %v511 to ptr
  %p514 = inttoptr i64 %v512 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p514, ptr %p513, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v515 = load i64, ptr %slot8, align 8
  %p516 = inttoptr i64 %v515 to ptr
  store i32 2, ptr %p516, align 4, !alias.scope !3, !noalias !4
  %v517 = load i64, ptr %slot14, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ld519 = load i32, ptr %p518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld519, ptr %slot59, align 8
  %v520 = load i32, ptr %slot59, align 8
  %v521 = load i64, ptr %slot8, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i32 %v520, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot13, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 0, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot7, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 1, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %v527 = load i64, ptr %slot57, align 8
  %v528 = load i64, ptr %slot24, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i64 %v527, ptr %p529, align 8, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot24, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot60, align 8
  %v533 = load i64, ptr %slot7, align 8
  %p534 = inttoptr i64 %v533 to ptr
  %ld535 = load i32, ptr %p534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld535, ptr %slot61, align 8
  %v536 = load i64, ptr %slot8, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i32, ptr %p537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld538, ptr %slot62, align 8
  %v539 = load i32, ptr %slot62, align 8
  %op540 = and i32 %v539, 24
  store i32 %op540, ptr %slot62, align 8
  %v541 = load i32, ptr %slot62, align 8
  %cmp542 = icmp eq i32 %v541, 0
  %cv543 = zext i1 %cmp542 to i32
  store i32 %cv543, ptr %slot63, align 8
  %v544 = load i32, ptr %slot61, align 8
  %v545 = load i32, ptr %slot63, align 8
  %op546 = and i32 %v544, %v545
  store i32 %op546, ptr %slot64, align 8
  %v547 = load i32, ptr %slot64, align 8
  %cv548 = zext i32 %v547 to i64
  %cond549 = icmp ne i64 %cv548, 0
  br i1 %cond549, label %bb_rctake39, label %bb_rccopy39
bb_rctake39:
  %v550 = load i64, ptr %slot20, align 8
  store i64 %v550, ptr %slot65, align 8
  %v551 = load i64, ptr %slot41, align 8
  store i64 %v551, ptr %slot66, align 8
  %v552 = load i64, ptr %slot40, align 8
  %v553 = load i64, ptr %slot65, align 8
  %v554 = load i64, ptr %slot60, align 8
  %v555 = load i64, ptr %slot66, align 8
  %cv556 = trunc i64 %v555 to i32
  %call557 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v552, i64 %v553, i64 %v554, i32 %cv556) nomerge, !dbg !116
  store i32 %call557, ptr %slot67, align 8
  %v558 = load i32, ptr %slot67, align 8
  %cv559 = zext i32 %v558 to i64
  %cond560 = icmp ne i64 %cv559, 0
  br i1 %cond560, label %bb_rcsuccess49, label %bb_rcfailure49
bb_rcfailure49:
  %v561 = load i64, ptr %slot40, align 8
  %p562 = inttoptr i64 %v561 to ptr
  %call563 = call i32 @myl_rc_take_failure(ptr %p562) nomerge, !dbg !116
  store i32 %call563, ptr %slot68, align 8
  %v564 = load i64, ptr %slot1, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %v566 = load i32, ptr %slot68, align 8
  %call567 = call i32 @myl_qbe_rc_status(ptr %p565, i32 %v566) nomerge, !dbg !116
  store i32 %call567, ptr %slot69, align 8
  br label %bb_failure
bb_rcsuccess49:
  %v568 = load i64, ptr %slot7, align 8
  %p569 = inttoptr i64 %v568 to ptr
  store i32 0, ptr %p569, align 4, !alias.scope !3, !noalias !4
  %v570 = load i64, ptr %slot14, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i32 2, ptr %p571, align 4, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot13, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i32 1, ptr %p573, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared39
bb_rccopy39:
  %v574 = load i64, ptr %slot20, align 8
  store i64 %v574, ptr %slot70, align 8
  %v575 = load i64, ptr %slot41, align 8
  store i64 %v575, ptr %slot71, align 8
  %v576 = load i64, ptr %slot40, align 8
  %v577 = load i64, ptr %slot70, align 8
  %v578 = load i64, ptr %slot60, align 8
  %v579 = load i64, ptr %slot71, align 8
  %cv580 = trunc i64 %v579 to i32
  %call581 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v576, i64 %v577, i64 %v578, i32 %cv580) nomerge, !dbg !116
  store i32 %call581, ptr %slot72, align 8
  %v582 = load i32, ptr %slot72, align 8
  %cv583 = zext i32 %v582 to i64
  %cond584 = icmp ne i64 %cv583, 0
  br i1 %cond584, label %bb_rcsuccess58, label %bb_rcfailure58
bb_rcfailure58:
  %v585 = load i64, ptr %slot40, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %call587 = call i32 @myl_rc_take_failure(ptr %p586) nomerge, !dbg !116
  store i32 %call587, ptr %slot73, align 8
  %v588 = load i64, ptr %slot1, align 8
  %p589 = inttoptr i64 %v588 to ptr
  %v590 = load i32, ptr %slot73, align 8
  %call591 = call i32 @myl_qbe_rc_status(ptr %p589, i32 %v590) nomerge, !dbg !116
  store i32 %call591, ptr %slot74, align 8
  br label %bb_failure
bb_rcsuccess58:
  %v592 = load i64, ptr %slot14, align 8
  %p593 = inttoptr i64 %v592 to ptr
  store i32 2, ptr %p593, align 4, !alias.scope !3, !noalias !4
  %v594 = load i64, ptr %slot13, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i32 1, ptr %p595, align 4, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot7, align 8
  %p597 = inttoptr i64 %v596 to ptr
  %ld598 = load i32, ptr %p597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld598, ptr %slot75, align 8
  %v599 = load i32, ptr %slot75, align 8
  %cv600 = zext i32 %v599 to i64
  %cond601 = icmp ne i64 %cv600, 0
  br i1 %cond601, label %bb_rcslotdrop65, label %bb_rcslotdone65
bb_rcslotdrop65:
  %v602 = load i64, ptr %slot7, align 8
  %p603 = inttoptr i64 %v602 to ptr
  store i32 0, ptr %p603, align 4, !alias.scope !3, !noalias !4
  %v604 = load i64, ptr %slot16, align 8
  store i64 %v604, ptr %slot76, align 8
  %v605 = load i64, ptr %slot8, align 8
  %p606 = inttoptr i64 %v605 to ptr
  %ld607 = load i32, ptr %p606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld607, ptr %slot77, align 8
  %v608 = load i32, ptr %slot77, align 8
  %op609 = and i32 %v608, 28
  store i32 %op609, ptr %slot78, align 8
  %v610 = load i32, ptr %slot78, align 8
  %cv611 = zext i32 %v610 to i64
  %cond612 = icmp ne i64 %cv611, 0
  br i1 %cond612, label %bb_rcslotrole65, label %bb_rcslotowner65
bb_rcslotrole65:
  %v613 = load i64, ptr %slot40, align 8
  store i64 %v613, ptr %slot79, align 8
  %v614 = load i64, ptr %slot79, align 8
  %v615 = load i64, ptr %slot76, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v614, i64 %v615) nomerge, !dbg !116
  br label %bb_rcslotdone65
bb_rcslotowner65:
  %v616 = load i64, ptr %slot40, align 8
  store i64 %v616, ptr %slot80, align 8
  %v617 = load i64, ptr %slot80, align 8
  %v618 = load i64, ptr %slot76, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v617, i64 %v618) nomerge, !dbg !116
  br label %bb_rcslotdone65
bb_rcslotdone65:
  br label %bb_rcprepared39
bb_rcprepared39:
  %v619 = load i64, ptr %slot5, align 8
  %p620 = inttoptr i64 %v619 to ptr
  %ld621 = load i32, ptr %p620, align 4, !alias.scope !3, !noalias !4
  store i32 %ld621, ptr %slot81, align 8
  %v622 = load i32, ptr %slot81, align 8
  %cv623 = zext i32 %v622 to i64
  %cond624 = icmp ne i64 %cv623, 0
  br i1 %cond624, label %bb_rcslotdrop75, label %bb_rcslotdone75
bb_rcslotdrop75:
  %v625 = load i64, ptr %slot5, align 8
  %p626 = inttoptr i64 %v625 to ptr
  store i32 0, ptr %p626, align 4, !alias.scope !3, !noalias !4
  %v627 = load i64, ptr %slot22, align 8
  store i64 %v627, ptr %slot82, align 8
  %v628 = load i64, ptr %slot6, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %ld630 = load i32, ptr %p629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld630, ptr %slot83, align 8
  %v631 = load i32, ptr %slot83, align 8
  %op632 = and i32 %v631, 28
  store i32 %op632, ptr %slot84, align 8
  %v633 = load i32, ptr %slot84, align 8
  %cv634 = zext i32 %v633 to i64
  %cond635 = icmp ne i64 %cv634, 0
  br i1 %cond635, label %bb_rcslotrole75, label %bb_rcslotowner75
bb_rcslotrole75:
  %v636 = load i64, ptr %slot40, align 8
  store i64 %v636, ptr %slot85, align 8
  %v637 = load i64, ptr %slot85, align 8
  %v638 = load i64, ptr %slot82, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v637, i64 %v638) nomerge, !dbg !116
  br label %bb_rcslotdone75
bb_rcslotowner75:
  %v639 = load i64, ptr %slot40, align 8
  store i64 %v639, ptr %slot86, align 8
  %v640 = load i64, ptr %slot86, align 8
  %v641 = load i64, ptr %slot82, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v640, i64 %v641) nomerge, !dbg !116
  br label %bb_rcslotdone75
bb_rcslotdone75:
  %v642 = load i64, ptr %slot22, align 8
  store i64 %v642, ptr %slot87, align 8
  %v643 = load i64, ptr %slot20, align 8
  store i64 %v643, ptr %slot88, align 8
  %v644 = load i64, ptr %slot88, align 8
  %v645 = load i64, ptr %slot87, align 8
  %p646 = inttoptr i64 %v644 to ptr
  %p647 = inttoptr i64 %v645 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p647, ptr %p646, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v648 = load i64, ptr %slot13, align 8
  %p649 = inttoptr i64 %v648 to ptr
  store i32 0, ptr %p649, align 4, !alias.scope !3, !noalias !4
  %v650 = load i64, ptr %slot6, align 8
  %p651 = inttoptr i64 %v650 to ptr
  store i32 2, ptr %p651, align 4, !alias.scope !3, !noalias !4
  %v652 = load i64, ptr %slot14, align 8
  %p653 = inttoptr i64 %v652 to ptr
  %ld654 = load i32, ptr %p653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld654, ptr %slot89, align 8
  %v655 = load i32, ptr %slot89, align 8
  %v656 = load i64, ptr %slot6, align 8
  %p657 = inttoptr i64 %v656 to ptr
  store i32 %v655, ptr %p657, align 4, !alias.scope !3, !noalias !4
  %v658 = load i64, ptr %slot5, align 8
  %p659 = inttoptr i64 %v658 to ptr
  store i32 1, ptr %p659, align 4, !alias.scope !3, !noalias !4
  %v660 = load i64, ptr %slot27, align 8
  store i64 %v660, ptr %slot90, align 8
  %v661 = load i64, ptr %slot90, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 0, ptr %p662, align 8, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot90, align 8
  %p665 = inttoptr i64 %v663 to ptr
  %gep666 = getelementptr i8, ptr %p665, i64 8
  %op664 = ptrtoint ptr %gep666 to i64
  store i64 %op664, ptr %slot91, align 8
  %v667 = load i64, ptr %slot91, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i64 0, ptr %p668, align 8, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot90, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i32 0, ptr %p670, align 4, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot90, align 8
  %v672 = load i64, ptr %slot24, align 8
  %p673 = inttoptr i64 %v672 to ptr
  store i64 %v671, ptr %p673, align 8, !alias.scope !3, !noalias !4
  %v674 = load i64, ptr %slot24, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %ld676 = load i64, ptr %p675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld676, ptr %slot92, align 8
  %v677 = load i64, ptr %slot92, align 8
  %v678 = load i64, ptr %slot23, align 8
  %p679 = inttoptr i64 %v677 to ptr
  %p680 = inttoptr i64 %v678 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p680, ptr %p679, i64 16, i1 false)
  %v681 = load i64, ptr %slot21, align 8
  %p682 = inttoptr i64 %v681 to ptr
  %ld683 = load i64, ptr %p682, align 8, !alias.scope !3, !noalias !4
  store i64 %ld683, ptr %slot93, align 8
  %v684 = load i64, ptr %slot93, align 8
  %v685 = load i64, ptr %slot24, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i64 %v684, ptr %p686, align 8, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot28, align 8
  store i64 %v687, ptr %slot94, align 8
  %v688 = load i64, ptr %slot94, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i32 0, ptr %p689, align 4, !alias.scope !3, !noalias !4
  %v690 = load i64, ptr %slot94, align 8
  %p691 = inttoptr i64 %v690 to ptr
  store i32 8, ptr %p691, align 4, !alias.scope !3, !noalias !4
  %v692 = load i64, ptr %slot94, align 8
  %v693 = load i64, ptr %slot25, align 8
  %p694 = inttoptr i64 %v693 to ptr
  store i64 %v692, ptr %p694, align 8, !alias.scope !3, !noalias !4
  %v695 = load i64, ptr %slot24, align 8
  %p696 = inttoptr i64 %v695 to ptr
  %ld697 = load i64, ptr %p696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld697, ptr %slot95, align 8
  %v698 = load i64, ptr %slot25, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i64, ptr %p699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld700, ptr %slot96, align 8
  %v701 = load i64, ptr %slot1, align 8
  %v702 = load i64, ptr %slot95, align 8
  %v703 = load i64, ptr %slot96, align 8
  %call704 = call i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64 %v701, i64 %v702, i64 %v703) nomerge, !dbg !118
  store i64 %call704, ptr %slot97, align 8
  %v705 = load i64, ptr %slot97, align 8
  %v706 = load i64, ptr %slot24, align 8
  %p707 = inttoptr i64 %v706 to ptr
  store i64 %v705, ptr %p707, align 8, !alias.scope !3, !noalias !4
  %v708 = load i64, ptr %slot7, align 8
  %p709 = inttoptr i64 %v708 to ptr
  %ld710 = load i32, ptr %p709, align 4, !alias.scope !3, !noalias !4
  store i32 %ld710, ptr %slot98, align 8
  %v711 = load i32, ptr %slot98, align 8
  %cv712 = zext i32 %v711 to i64
  %cond713 = icmp ne i64 %cv712, 0
  br i1 %cond713, label %bb_rcslotdrop99, label %bb_rcslotdone99
bb_rcslotdrop99:
  %v714 = load i64, ptr %slot7, align 8
  %p715 = inttoptr i64 %v714 to ptr
  store i32 0, ptr %p715, align 4, !alias.scope !3, !noalias !4
  %v716 = load i64, ptr %slot16, align 8
  store i64 %v716, ptr %slot99, align 8
  %v717 = load i64, ptr %slot8, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %ld719 = load i32, ptr %p718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld719, ptr %slot100, align 8
  %v720 = load i32, ptr %slot100, align 8
  %op721 = and i32 %v720, 28
  store i32 %op721, ptr %slot101, align 8
  %v722 = load i32, ptr %slot101, align 8
  %cv723 = zext i32 %v722 to i64
  %cond724 = icmp ne i64 %cv723, 0
  br i1 %cond724, label %bb_rcslotrole99, label %bb_rcslotowner99
bb_rcslotrole99:
  %v725 = load i64, ptr %slot40, align 8
  store i64 %v725, ptr %slot102, align 8
  %v726 = load i64, ptr %slot102, align 8
  %v727 = load i64, ptr %slot99, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v726, i64 %v727) nomerge, !dbg !118
  br label %bb_rcslotdone99
bb_rcslotowner99:
  %v728 = load i64, ptr %slot40, align 8
  store i64 %v728, ptr %slot103, align 8
  %v729 = load i64, ptr %slot103, align 8
  %v730 = load i64, ptr %slot99, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v729, i64 %v730) nomerge, !dbg !118
  br label %bb_rcslotdone99
bb_rcslotdone99:
  %v731 = load i64, ptr %slot24, align 8
  %p732 = inttoptr i64 %v731 to ptr
  %ld733 = load i64, ptr %p732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld733, ptr %slot104, align 8
  %v734 = load i64, ptr %slot104, align 8
  %op735 = xor i64 %v734, 1
  store i64 %op735, ptr %slot105, align 8
  %v736 = load i64, ptr %slot105, align 8
  %v737 = load i64, ptr %slot24, align 8
  %p738 = inttoptr i64 %v737 to ptr
  store i64 %v736, ptr %p738, align 8, !alias.scope !3, !noalias !4
  %v739 = load i64, ptr %slot24, align 8
  %p740 = inttoptr i64 %v739 to ptr
  %ld741 = load i64, ptr %p740, align 8, !alias.scope !3, !noalias !4
  store i64 %ld741, ptr %slot106, align 8
  %v742 = load i64, ptr %slot106, align 8
  %cond743 = icmp ne i64 %v742, 0
  br i1 %cond743, label %bb_next109, label %bb_i17
bb_next109:
  %v744 = load i64, ptr %slot21, align 8
  %p745 = inttoptr i64 %v744 to ptr
  %ld746 = load i64, ptr %p745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld746, ptr %slot107, align 8
  %v747 = load i64, ptr %slot107, align 8
  %v748 = load i64, ptr %slot24, align 8
  %p749 = inttoptr i64 %v748 to ptr
  store i64 %v747, ptr %p749, align 8, !alias.scope !3, !noalias !4
  %v750 = load i64, ptr %slot24, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %ld752 = load i64, ptr %p751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld752, ptr %slot108, align 8
  %v753 = load i64, ptr %slot1, align 8
  %v754 = load i64, ptr %slot108, align 8
  %call755 = call { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64 %v753, i64 %v754) nomerge, !dbg !120
  store { i64, i64 } %call755, ptr %callresult110, align 8
  %addr756 = ptrtoint ptr %callresult110 to i64
  store i64 %addr756, ptr %slot109, align 8
  %v757 = load i64, ptr %slot109, align 8
  %v758 = load i64, ptr %slot24, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i64 %v757, ptr %p759, align 8, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot7, align 8
  %p761 = inttoptr i64 %v760 to ptr
  %ld762 = load i32, ptr %p761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld762, ptr %slot111, align 8
  %v763 = load i32, ptr %slot111, align 8
  %cv764 = zext i32 %v763 to i64
  %cond765 = icmp ne i64 %cv764, 0
  br i1 %cond765, label %bb_rcslotdrop114, label %bb_rcslotdone114
bb_rcslotdrop114:
  %v766 = load i64, ptr %slot7, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i32 0, ptr %p767, align 4, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot16, align 8
  store i64 %v768, ptr %slot112, align 8
  %v769 = load i64, ptr %slot8, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %ld771 = load i32, ptr %p770, align 4, !alias.scope !3, !noalias !4
  store i32 %ld771, ptr %slot113, align 8
  %v772 = load i32, ptr %slot113, align 8
  %op773 = and i32 %v772, 28
  store i32 %op773, ptr %slot114, align 8
  %v774 = load i32, ptr %slot114, align 8
  %cv775 = zext i32 %v774 to i64
  %cond776 = icmp ne i64 %cv775, 0
  br i1 %cond776, label %bb_rcslotrole114, label %bb_rcslotowner114
bb_rcslotrole114:
  %v777 = load i64, ptr %slot40, align 8
  store i64 %v777, ptr %slot115, align 8
  %v778 = load i64, ptr %slot115, align 8
  %v779 = load i64, ptr %slot112, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v778, i64 %v779) nomerge, !dbg !120
  br label %bb_rcslotdone114
bb_rcslotowner114:
  %v780 = load i64, ptr %slot40, align 8
  store i64 %v780, ptr %slot116, align 8
  %v781 = load i64, ptr %slot116, align 8
  %v782 = load i64, ptr %slot112, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v781, i64 %v782) nomerge, !dbg !120
  br label %bb_rcslotdone114
bb_rcslotdone114:
  %v783 = load i64, ptr %slot24, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %ld785 = load i64, ptr %p784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld785, ptr %slot117, align 8
  %v786 = load i64, ptr %slot117, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i32, ptr %p787, align 4
  %ext789 = zext i32 %ld788 to i64
  store i64 %ext789, ptr %slot118, align 8
  %v790 = load i64, ptr %slot118, align 8
  %cmp791 = icmp eq i64 %v790, 0
  %cv792 = zext i1 %cmp791 to i64
  store i64 %cv792, ptr %slot119, align 8
  %v793 = load i64, ptr %slot119, align 8
  %cond794 = icmp ne i64 %v793, 0
  br i1 %cond794, label %bb_rctryok122, label %bb_rctryerror122
bb_rctryerror122:
  %p795 = inttoptr i64 ptrtoint (ptr @myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p795, i64 12884901900) "call-inline-cost"="0", !dbg !122
  %v796 = load i64, ptr %slot117, align 8
  %op797 = add i64 %v796, 8
  store i64 %op797, ptr %slot120, align 8
  %v798 = load i64, ptr %slot29, align 8
  store i64 %v798, ptr %slot121, align 8
  %v799 = load i64, ptr %slot121, align 8
  %p800 = inttoptr i64 %v799 to ptr
  store i64 0, ptr %p800, align 8, !alias.scope !3, !noalias !4
  %v801 = load i64, ptr %slot121, align 8
  %p803 = inttoptr i64 %v801 to ptr
  %gep804 = getelementptr i8, ptr %p803, i64 8
  %op802 = ptrtoint ptr %gep804 to i64
  store i64 %op802, ptr %slot122, align 8
  %v805 = load i64, ptr %slot122, align 8
  %p806 = inttoptr i64 %v805 to ptr
  store i64 0, ptr %p806, align 8, !alias.scope !3, !noalias !4
  %v807 = load i64, ptr %slot121, align 8
  %p808 = inttoptr i64 %v807 to ptr
  store i32 1, ptr %p808, align 4, !alias.scope !3, !noalias !4
  %v809 = load i64, ptr %slot121, align 8
  %p811 = inttoptr i64 %v809 to ptr
  %gep812 = getelementptr i8, ptr %p811, i64 8
  %op810 = ptrtoint ptr %gep812 to i64
  store i64 %op810, ptr %slot123, align 8
  %v813 = load i64, ptr %slot15, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i32 1, ptr %p814, align 4, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot41, align 8
  store i64 %v815, ptr %slot124, align 8
  %v816 = load i64, ptr %slot121, align 8
  %v817 = load i64, ptr %slot24, align 8
  %p818 = inttoptr i64 %v817 to ptr
  store i64 %v816, ptr %p818, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_rctryok122:
  %v819 = load i64, ptr %slot29, align 8
  store i64 %v819, ptr %slot125, align 8
  %v820 = load i64, ptr %slot125, align 8
  %p821 = inttoptr i64 %v820 to ptr
  store i64 0, ptr %p821, align 8, !alias.scope !3, !noalias !4
  %v822 = load i64, ptr %slot15, align 8
  %p823 = inttoptr i64 %v822 to ptr
  store i32 1, ptr %p823, align 4, !alias.scope !3, !noalias !4
  %v824 = load i64, ptr %slot117, align 8
  %op825 = add i64 %v824, 8
  store i64 %op825, ptr %slot126, align 8
  %v826 = load i64, ptr %slot41, align 8
  store i64 %v826, ptr %slot127, align 8
  %v827 = load i64, ptr %slot126, align 8
  %p828 = inttoptr i64 %v827 to ptr
  %ld829 = load i64, ptr %p828, align 8
  store i64 %ld829, ptr %slot128, align 8
  %v830 = load i64, ptr %slot128, align 8
  %v831 = load i64, ptr %slot125, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i64 %v830, ptr %p832, align 8, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot125, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %ld835 = load i64, ptr %p834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld835, ptr %slot129, align 8
  %v836 = load i64, ptr %slot129, align 8
  %v837 = load i64, ptr %slot24, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i64 %v836, ptr %p838, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i14:
  %v839 = load i64, ptr %slot24, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i64, ptr %p840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld841, ptr %slot130, align 8
  %v842 = load i64, ptr %slot7, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %ld844 = load i32, ptr %p843, align 4, !alias.scope !3, !noalias !4
  store i32 %ld844, ptr %slot131, align 8
  %v845 = load i32, ptr %slot131, align 8
  %cv846 = zext i32 %v845 to i64
  %cond847 = icmp ne i64 %cv846, 0
  br i1 %cond847, label %bb_rcslotdrop141, label %bb_rcslotdone141
bb_rcslotdrop141:
  %v848 = load i64, ptr %slot7, align 8
  %p849 = inttoptr i64 %v848 to ptr
  store i32 0, ptr %p849, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone141
bb_rcslotdone141:
  %v850 = load i64, ptr %slot5, align 8
  %p851 = inttoptr i64 %v850 to ptr
  %ld852 = load i32, ptr %p851, align 4, !alias.scope !3, !noalias !4
  store i32 %ld852, ptr %slot132, align 8
  %v853 = load i32, ptr %slot132, align 8
  %cv854 = zext i32 %v853 to i64
  %cond855 = icmp ne i64 %cv854, 0
  br i1 %cond855, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v856 = load i64, ptr %slot5, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i32 0, ptr %p857, align 4, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot22, align 8
  store i64 %v858, ptr %slot133, align 8
  %v859 = load i64, ptr %slot6, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %ld861 = load i32, ptr %p860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld861, ptr %slot134, align 8
  %v862 = load i32, ptr %slot134, align 8
  %op863 = and i32 %v862, 28
  store i32 %op863, ptr %slot135, align 8
  %v864 = load i32, ptr %slot135, align 8
  %cv865 = zext i32 %v864 to i64
  %cond866 = icmp ne i64 %cv865, 0
  br i1 %cond866, label %bb_rcslotrole144, label %bb_rcslotowner144
bb_rcslotrole144:
  %v867 = load i64, ptr %slot40, align 8
  store i64 %v867, ptr %slot136, align 8
  %v868 = load i64, ptr %slot136, align 8
  %v869 = load i64, ptr %slot133, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v868, i64 %v869) nomerge, !dbg !124
  br label %bb_rcslotdone144
bb_rcslotowner144:
  %v870 = load i64, ptr %slot40, align 8
  store i64 %v870, ptr %slot137, align 8
  %v871 = load i64, ptr %slot137, align 8
  %v872 = load i64, ptr %slot133, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v871, i64 %v872) nomerge, !dbg !124
  br label %bb_rcslotdone144
bb_rcslotdone144:
  %v873 = load i64, ptr %slot130, align 8
  %p874 = inttoptr i64 %v873 to ptr
  %ret875 = load { i64, i64 }, ptr %p874, align 8
  ret { i64, i64 } %ret875
bb_i15:
  %v876 = load i64, ptr %slot30, align 8
  store i64 %v876, ptr %slot138, align 8
  %v877 = load i64, ptr %slot138, align 8
  %p878 = inttoptr i64 %v877 to ptr
  store i64 0, ptr %p878, align 8, !alias.scope !3, !noalias !4
  %v879 = load i64, ptr %slot138, align 8
  %p881 = inttoptr i64 %v879 to ptr
  %gep882 = getelementptr i8, ptr %p881, i64 8
  %op880 = ptrtoint ptr %gep882 to i64
  store i64 %op880, ptr %slot139, align 8
  %v883 = load i64, ptr %slot139, align 8
  %p884 = inttoptr i64 %v883 to ptr
  store i64 0, ptr %p884, align 8, !alias.scope !3, !noalias !4
  %v885 = load i64, ptr %slot138, align 8
  %p886 = inttoptr i64 %v885 to ptr
  store i32 1, ptr %p886, align 4, !alias.scope !3, !noalias !4
  %v887 = load i64, ptr %slot15, align 8
  %p888 = inttoptr i64 %v887 to ptr
  store i32 1, ptr %p888, align 4, !alias.scope !3, !noalias !4
  %v889 = load i64, ptr %slot24, align 8
  store i64 %v889, ptr %slot140, align 8
  %v890 = load i64, ptr %slot138, align 8
  %p892 = inttoptr i64 %v890 to ptr
  %gep893 = getelementptr i8, ptr %p892, i64 8
  %op891 = ptrtoint ptr %gep893 to i64
  store i64 %op891, ptr %slot141, align 8
  %v894 = load i64, ptr %slot41, align 8
  store i64 %v894, ptr %slot142, align 8
  %v895 = load i64, ptr %slot140, align 8
  %p896 = inttoptr i64 %v895 to ptr
  %ld897 = load i64, ptr %p896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld897, ptr %slot143, align 8
  %v898 = load i64, ptr %slot143, align 8
  %v899 = load i64, ptr %slot141, align 8
  %p900 = inttoptr i64 %v899 to ptr
  store i64 %v898, ptr %p900, align 8, !alias.scope !3, !noalias !4
  %v901 = load i64, ptr %slot138, align 8
  %v902 = load i64, ptr %slot24, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i64 %v901, ptr %p903, align 8, !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot24, align 8
  %p905 = inttoptr i64 %v904 to ptr
  %ld906 = load i64, ptr %p905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld906, ptr %slot144, align 8
  %v907 = load i64, ptr %slot144, align 8
  %v908 = load i64, ptr %slot23, align 8
  %p909 = inttoptr i64 %v907 to ptr
  %p910 = inttoptr i64 %v908 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p910, ptr %p909, i64 16, i1 false)
  br label %bb_i17
bb_i17:
  %v911 = load i64, ptr %slot21, align 8
  %p912 = inttoptr i64 %v911 to ptr
  %ld913 = load i64, ptr %p912, align 8, !alias.scope !3, !noalias !4
  store i64 %ld913, ptr %slot145, align 8
  %v914 = load i64, ptr %slot145, align 8
  %v915 = load i64, ptr %slot24, align 8
  %p916 = inttoptr i64 %v915 to ptr
  store i64 %v914, ptr %p916, align 8, !alias.scope !3, !noalias !4
  %v917 = load i64, ptr %slot31, align 8
  store i64 %v917, ptr %slot146, align 8
  %v918 = load i64, ptr %slot146, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i32 0, ptr %p919, align 4, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot146, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i32 8, ptr %p921, align 4, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot146, align 8
  %v923 = load i64, ptr %slot25, align 8
  %p924 = inttoptr i64 %v923 to ptr
  store i64 %v922, ptr %p924, align 8, !alias.scope !3, !noalias !4
  %p925 = inttoptr i64 ptrtoint (ptr @myl_lit_01b72450c49aa532f72eb3789506f0d955d06fca3165082ccbfd5958e6d56249 to i64) to ptr
  %ld926 = load i64, ptr %p925, align 8, !alias.scope !4, !noalias !3
  store i64 %ld926, ptr %slot147, align 8
  %v927 = load i64, ptr %slot147, align 8
  %v928 = load i64, ptr %slot26, align 8
  %p929 = inttoptr i64 %v928 to ptr
  store i64 %v927, ptr %p929, align 8, !alias.scope !3, !noalias !4
  %v930 = load i64, ptr %slot26, align 8
  %p931 = inttoptr i64 %v930 to ptr
  %ld932 = load i64, ptr %p931, align 8, !alias.scope !3, !noalias !4
  store i64 %ld932, ptr %slot148, align 8
  %v933 = load i64, ptr %slot148, align 8
  %v934 = load i64, ptr %slot19, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i64 %v933, ptr %p935, align 8, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot19, align 8
  store i64 %v936, ptr %slot149, align 8
  %v937 = load i64, ptr %slot20, align 8
  store i64 %v937, ptr %slot150, align 8
  %v938 = load i64, ptr %slot149, align 8
  %v939 = load i64, ptr %slot150, align 8
  %p940 = inttoptr i64 %v938 to ptr
  %p941 = inttoptr i64 %v939 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p941, ptr %p940, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v942 = load i64, ptr %slot14, align 8
  %p943 = inttoptr i64 %v942 to ptr
  store i32 2, ptr %p943, align 4, !alias.scope !3, !noalias !4
  %v944 = load i64, ptr %slot13, align 8
  %p945 = inttoptr i64 %v944 to ptr
  store i32 1, ptr %p945, align 4, !alias.scope !3, !noalias !4
  %v946 = load i64, ptr %slot18, align 8
  store i64 %v946, ptr %slot151, align 8
  %v947 = load i64, ptr %slot20, align 8
  store i64 %v947, ptr %slot152, align 8
  %v948 = load i64, ptr %slot152, align 8
  %v949 = load i64, ptr %slot151, align 8
  %p950 = inttoptr i64 %v948 to ptr
  %p951 = inttoptr i64 %v949 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p951, ptr %p950, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v952 = load i64, ptr %slot12, align 8
  %p953 = inttoptr i64 %v952 to ptr
  store i32 2, ptr %p953, align 4, !alias.scope !3, !noalias !4
  %v954 = load i64, ptr %slot14, align 8
  %p955 = inttoptr i64 %v954 to ptr
  %ld956 = load i32, ptr %p955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld956, ptr %slot153, align 8
  %v957 = load i32, ptr %slot153, align 8
  %v958 = load i64, ptr %slot12, align 8
  %p959 = inttoptr i64 %v958 to ptr
  store i32 %v957, ptr %p959, align 4, !alias.scope !3, !noalias !4
  %v960 = load i64, ptr %slot13, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i32 0, ptr %p961, align 4, !alias.scope !3, !noalias !4
  %v962 = load i64, ptr %slot11, align 8
  %p963 = inttoptr i64 %v962 to ptr
  store i32 1, ptr %p963, align 4, !alias.scope !3, !noalias !4
  %v964 = load i64, ptr %slot151, align 8
  %p965 = inttoptr i64 %v964 to ptr
  %ld966 = load i64, ptr %p965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld966, ptr %slot154, align 8
  %v967 = load i64, ptr %slot154, align 8
  %v968 = load i64, ptr %slot26, align 8
  %p969 = inttoptr i64 %v968 to ptr
  store i64 %v967, ptr %p969, align 8, !alias.scope !3, !noalias !4
  %v970 = load i64, ptr %slot24, align 8
  %p971 = inttoptr i64 %v970 to ptr
  %ld972 = load i64, ptr %p971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld972, ptr %slot155, align 8
  %v973 = load i64, ptr %slot25, align 8
  %p974 = inttoptr i64 %v973 to ptr
  %ld975 = load i64, ptr %p974, align 8, !alias.scope !3, !noalias !4
  store i64 %ld975, ptr %slot156, align 8
  %v976 = load i64, ptr %slot26, align 8
  %p977 = inttoptr i64 %v976 to ptr
  %ld978 = load i64, ptr %p977, align 8, !alias.scope !3, !noalias !4
  store i64 %ld978, ptr %slot157, align 8
  %v979 = load i64, ptr %slot1, align 8
  %v980 = load i64, ptr %slot155, align 8
  %v981 = load i64, ptr %slot156, align 8
  %v982 = load i64, ptr %slot157, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult159, i64 %v979, i64 %v980, i64 %v981, i64 %v982) nomerge, !dbg !126
  %addr983 = ptrtoint ptr %callresult159 to i64
  store i64 %addr983, ptr %slot158, align 8
  %v984 = load i64, ptr %slot158, align 8
  %v985 = load i64, ptr %slot24, align 8
  %p986 = inttoptr i64 %v985 to ptr
  store i64 %v984, ptr %p986, align 8, !alias.scope !3, !noalias !4
  %v987 = load i64, ptr %slot24, align 8
  %p988 = inttoptr i64 %v987 to ptr
  %ld989 = load i64, ptr %p988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld989, ptr %slot160, align 8
  %v990 = load i64, ptr %slot20, align 8
  store i64 %v990, ptr %slot161, align 8
  %v991 = load i64, ptr %slot160, align 8
  %v992 = load i64, ptr %slot161, align 8
  %p993 = inttoptr i64 %v991 to ptr
  %p994 = inttoptr i64 %v992 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p994, ptr %p993, i64 48, i1 false)
  %v995 = load i64, ptr %slot14, align 8
  %p996 = inttoptr i64 %v995 to ptr
  store i32 2, ptr %p996, align 4, !alias.scope !3, !noalias !4
  %v997 = load i64, ptr %slot13, align 8
  %p998 = inttoptr i64 %v997 to ptr
  store i32 1, ptr %p998, align 4, !alias.scope !3, !noalias !4
  %v999 = load i64, ptr %slot7, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  %ld1001 = load i32, ptr %p1000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1001, ptr %slot162, align 8
  %v1002 = load i32, ptr %slot162, align 8
  %cv1003 = zext i32 %v1002 to i64
  %cond1004 = icmp ne i64 %cv1003, 0
  br i1 %cond1004, label %bb_rcslotdrop197, label %bb_rcslotdone197
bb_rcslotdrop197:
  %v1005 = load i64, ptr %slot7, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  store i32 0, ptr %p1006, align 4, !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot16, align 8
  store i64 %v1007, ptr %slot163, align 8
  %v1008 = load i64, ptr %slot8, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  %ld1010 = load i32, ptr %p1009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1010, ptr %slot164, align 8
  %v1011 = load i32, ptr %slot164, align 8
  %op1012 = and i32 %v1011, 28
  store i32 %op1012, ptr %slot165, align 8
  %v1013 = load i32, ptr %slot165, align 8
  %cv1014 = zext i32 %v1013 to i64
  %cond1015 = icmp ne i64 %cv1014, 0
  br i1 %cond1015, label %bb_rcslotrole197, label %bb_rcslotowner197
bb_rcslotrole197:
  %v1016 = load i64, ptr %slot40, align 8
  store i64 %v1016, ptr %slot166, align 8
  %v1017 = load i64, ptr %slot166, align 8
  %v1018 = load i64, ptr %slot163, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1017, i64 %v1018) nomerge, !dbg !126
  br label %bb_rcslotdone197
bb_rcslotowner197:
  %v1019 = load i64, ptr %slot40, align 8
  store i64 %v1019, ptr %slot167, align 8
  %v1020 = load i64, ptr %slot167, align 8
  %v1021 = load i64, ptr %slot163, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1020, i64 %v1021) nomerge, !dbg !126
  br label %bb_rcslotdone197
bb_rcslotdone197:
  %v1022 = load i64, ptr %slot11, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  %ld1024 = load i32, ptr %p1023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1024, ptr %slot168, align 8
  %v1025 = load i32, ptr %slot168, align 8
  %cv1026 = zext i32 %v1025 to i64
  %cond1027 = icmp ne i64 %cv1026, 0
  br i1 %cond1027, label %bb_rcslotdrop206, label %bb_rcslotdone206
bb_rcslotdrop206:
  %v1028 = load i64, ptr %slot11, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  store i32 0, ptr %p1029, align 4, !alias.scope !3, !noalias !4
  %v1030 = load i64, ptr %slot18, align 8
  store i64 %v1030, ptr %slot169, align 8
  %v1031 = load i64, ptr %slot12, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  %ld1033 = load i32, ptr %p1032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1033, ptr %slot170, align 8
  %v1034 = load i32, ptr %slot170, align 8
  %op1035 = and i32 %v1034, 28
  store i32 %op1035, ptr %slot171, align 8
  %v1036 = load i32, ptr %slot171, align 8
  %cv1037 = zext i32 %v1036 to i64
  %cond1038 = icmp ne i64 %cv1037, 0
  br i1 %cond1038, label %bb_rcslotrole206, label %bb_rcslotowner206
bb_rcslotrole206:
  %v1039 = load i64, ptr %slot40, align 8
  store i64 %v1039, ptr %slot172, align 8
  %v1040 = load i64, ptr %slot169, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %ld1042 = load i64, ptr %p1041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1042, ptr %slot173, align 8
  %v1043 = load i64, ptr %slot173, align 8
  %cmp1044 = icmp ne i64 %v1043, 0
  %cv1045 = zext i1 %cmp1044 to i32
  store i32 %cv1045, ptr %slot174, align 8
  %v1046 = load i32, ptr %slot174, align 8
  %cv1047 = zext i32 %v1046 to i64
  %cond1048 = icmp ne i64 %cv1047, 0
  br i1 %cond1048, label %bb_rcgnn222, label %bb_rcgdone222
bb_rcgnn222:
  %v1049 = load i64, ptr %slot173, align 8
  %op1050 = sub i64 %v1049, 16
  store i64 %op1050, ptr %slot175, align 8
  %v1051 = load i64, ptr %slot173, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %rgep1053 = getelementptr i8, ptr %p1052, i64 -16
  %ld1054 = load i64, ptr %rgep1053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1054, ptr %slot176, align 8
  %v1055 = load i64, ptr %slot176, align 8
  %op1056 = and i64 %v1055, 4611686018427387906
  store i64 %op1056, ptr %slot177, align 8
  %v1057 = load i64, ptr %slot177, align 8
  %cmp1058 = icmp ne i64 %v1057, 0
  %cv1059 = zext i1 %cmp1058 to i32
  store i32 %cv1059, ptr %slot178, align 8
  %v1060 = load i32, ptr %slot178, align 8
  %cv1061 = zext i32 %v1060 to i64
  %cond1062 = icmp ne i64 %cv1061, 0
  br i1 %cond1062, label %bb_rcgclear222, label %bb_rcgcounted222
bb_rcgcounted222:
  %v1063 = load i64, ptr %slot173, align 8
  %op1064 = sub i64 %v1063, 24
  store i64 %op1064, ptr %slot179, align 8
  %v1065 = load i64, ptr %slot173, align 8
  %p1066 = inttoptr i64 %v1065 to ptr
  %rgep1067 = getelementptr i8, ptr %p1066, i64 -24
  %ld1068 = load i64, ptr %rgep1067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1068, ptr %slot180, align 8
  %v1069 = load i64, ptr %slot180, align 8
  %op1070 = sub i64 %v1069, 1
  store i64 %op1070, ptr %slot181, align 8
  %v1071 = load i64, ptr %slot181, align 8
  %cmp1072 = icmp eq i64 %v1071, 0
  %cv1073 = zext i1 %cmp1072 to i32
  store i32 %cv1073, ptr %slot182, align 8
  %v1074 = load i32, ptr %slot182, align 8
  %cv1075 = zext i32 %v1074 to i64
  %cond1076 = icmp ne i64 %cv1075, 0
  br i1 %cond1076, label %bb_rcglast222, label %bb_rcgdec222
bb_rcglast222:
  %v1077 = load i64, ptr %slot173, align 8
  %op1078 = sub i64 %v1077, 32
  store i64 %op1078, ptr %slot183, align 8
  %v1079 = load i64, ptr %slot173, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  %rgep1081 = getelementptr i8, ptr %p1080, i64 -32
  %ld1082 = load i64, ptr %rgep1081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1082, ptr %slot184, align 8
  %v1083 = load i64, ptr %slot184, align 8
  %cmp1084 = icmp ne i64 %v1083, 0
  %cv1085 = zext i1 %cmp1084 to i32
  store i32 %cv1085, ptr %slot185, align 8
  %v1086 = load i32, ptr %slot185, align 8
  %cv1087 = zext i32 %v1086 to i64
  %cond1088 = icmp ne i64 %cv1087, 0
  br i1 %cond1088, label %bb_rcgdec222, label %bb_rcgslow222
bb_rcgslow222:
  %v1089 = load i64, ptr %slot172, align 8
  %v1090 = load i64, ptr %slot169, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1089, i64 %v1090) nomerge, !dbg !126
  br label %bb_rcgdone222
bb_rcgdec222:
  %v1091 = load i64, ptr %slot181, align 8
  %v1092 = load i64, ptr %slot173, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %rgep1094 = getelementptr i8, ptr %p1093, i64 -24
  store i64 %v1091, ptr %rgep1094, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear222
bb_rcgclear222:
  %v1095 = load i64, ptr %slot169, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  store i64 0, ptr %p1096, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone222
bb_rcgdone222:
  br label %bb_rcslotdone206
bb_rcslotowner206:
  %v1097 = load i64, ptr %slot40, align 8
  store i64 %v1097, ptr %slot186, align 8
  %v1098 = load i64, ptr %slot169, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  %ld1100 = load i64, ptr %p1099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1100, ptr %slot187, align 8
  %v1101 = load i64, ptr %slot187, align 8
  %cmp1102 = icmp ne i64 %v1101, 0
  %cv1103 = zext i1 %cmp1102 to i32
  store i32 %cv1103, ptr %slot188, align 8
  %v1104 = load i32, ptr %slot188, align 8
  %cv1105 = zext i32 %v1104 to i64
  %cond1106 = icmp ne i64 %cv1105, 0
  br i1 %cond1106, label %bb_rcgnn237, label %bb_rcgdone237
bb_rcgnn237:
  %v1107 = load i64, ptr %slot187, align 8
  %op1108 = sub i64 %v1107, 16
  store i64 %op1108, ptr %slot189, align 8
  %v1109 = load i64, ptr %slot187, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  %rgep1111 = getelementptr i8, ptr %p1110, i64 -16
  %ld1112 = load i64, ptr %rgep1111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1112, ptr %slot190, align 8
  %v1113 = load i64, ptr %slot190, align 8
  %op1114 = and i64 %v1113, 4611686018427387906
  store i64 %op1114, ptr %slot191, align 8
  %v1115 = load i64, ptr %slot191, align 8
  %cmp1116 = icmp ne i64 %v1115, 0
  %cv1117 = zext i1 %cmp1116 to i32
  store i32 %cv1117, ptr %slot192, align 8
  %v1118 = load i32, ptr %slot192, align 8
  %cv1119 = zext i32 %v1118 to i64
  %cond1120 = icmp ne i64 %cv1119, 0
  br i1 %cond1120, label %bb_rcgclear237, label %bb_rcgcounted237
bb_rcgcounted237:
  %v1121 = load i64, ptr %slot187, align 8
  %op1122 = sub i64 %v1121, 32
  store i64 %op1122, ptr %slot193, align 8
  %v1123 = load i64, ptr %slot187, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  %rgep1125 = getelementptr i8, ptr %p1124, i64 -32
  %ld1126 = load i64, ptr %rgep1125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1126, ptr %slot194, align 8
  %v1127 = load i64, ptr %slot194, align 8
  %op1128 = sub i64 %v1127, 1
  store i64 %op1128, ptr %slot195, align 8
  %v1129 = load i64, ptr %slot195, align 8
  %cmp1130 = icmp eq i64 %v1129, 0
  %cv1131 = zext i1 %cmp1130 to i32
  store i32 %cv1131, ptr %slot196, align 8
  %v1132 = load i32, ptr %slot196, align 8
  %cv1133 = zext i32 %v1132 to i64
  %cond1134 = icmp ne i64 %cv1133, 0
  br i1 %cond1134, label %bb_rcglast237, label %bb_rcgdec237
bb_rcglast237:
  %v1135 = load i64, ptr %slot187, align 8
  %op1136 = sub i64 %v1135, 24
  store i64 %op1136, ptr %slot197, align 8
  %v1137 = load i64, ptr %slot187, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %rgep1139 = getelementptr i8, ptr %p1138, i64 -24
  %ld1140 = load i64, ptr %rgep1139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1140, ptr %slot198, align 8
  %v1141 = load i64, ptr %slot198, align 8
  %cmp1142 = icmp ne i64 %v1141, 0
  %cv1143 = zext i1 %cmp1142 to i32
  store i32 %cv1143, ptr %slot199, align 8
  %v1144 = load i32, ptr %slot199, align 8
  %cv1145 = zext i32 %v1144 to i64
  %cond1146 = icmp ne i64 %cv1145, 0
  br i1 %cond1146, label %bb_rcgdec237, label %bb_rcgslow237
bb_rcgslow237:
  %v1147 = load i64, ptr %slot186, align 8
  %v1148 = load i64, ptr %slot169, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1147, i64 %v1148) nomerge, !dbg !126
  br label %bb_rcgdone237
bb_rcgdec237:
  %v1149 = load i64, ptr %slot195, align 8
  %v1150 = load i64, ptr %slot187, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %rgep1152 = getelementptr i8, ptr %p1151, i64 -32
  store i64 %v1149, ptr %rgep1152, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear237
bb_rcgclear237:
  %v1153 = load i64, ptr %slot169, align 8
  %p1154 = inttoptr i64 %v1153 to ptr
  store i64 0, ptr %p1154, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone237
bb_rcgdone237:
  br label %bb_rcslotdone206
bb_rcslotdone206:
  %v1155 = load i64, ptr %slot16, align 8
  store i64 %v1155, ptr %slot200, align 8
  %v1156 = load i64, ptr %slot20, align 8
  store i64 %v1156, ptr %slot201, align 8
  %v1157 = load i64, ptr %slot201, align 8
  %v1158 = load i64, ptr %slot200, align 8
  %p1159 = inttoptr i64 %v1157 to ptr
  %p1160 = inttoptr i64 %v1158 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1160, ptr %p1159, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1161 = load i64, ptr %slot8, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  store i32 2, ptr %p1162, align 4, !alias.scope !3, !noalias !4
  %v1163 = load i64, ptr %slot14, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %ld1165 = load i32, ptr %p1164, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1165, ptr %slot202, align 8
  %v1166 = load i32, ptr %slot202, align 8
  %v1167 = load i64, ptr %slot8, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i32 %v1166, ptr %p1168, align 4, !alias.scope !3, !noalias !4
  %v1169 = load i64, ptr %slot13, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  store i32 0, ptr %p1170, align 4, !alias.scope !3, !noalias !4
  %v1171 = load i64, ptr %slot7, align 8
  %p1172 = inttoptr i64 %v1171 to ptr
  store i32 1, ptr %p1172, align 4, !alias.scope !3, !noalias !4
  %v1173 = load i64, ptr %slot200, align 8
  %v1174 = load i64, ptr %slot24, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  store i64 %v1173, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  %v1176 = load i64, ptr %slot24, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  %ld1178 = load i64, ptr %p1177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1178, ptr %slot203, align 8
  %v1179 = load i64, ptr %slot203, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  %ld1181 = load i32, ptr %p1180, align 4
  %ext1182 = zext i32 %ld1181 to i64
  store i64 %ext1182, ptr %slot204, align 8
  %v1183 = load i64, ptr %slot204, align 8
  %cmp1184 = icmp eq i64 %v1183, 0
  %cv1185 = zext i1 %cmp1184 to i64
  store i64 %cv1185, ptr %slot205, align 8
  %v1186 = load i64, ptr %slot205, align 8
  %cond1187 = icmp ne i64 %v1186, 0
  br i1 %cond1187, label %bb_rctryok250, label %bb_rctryerror250
bb_rctryerror250:
  %p1188 = inttoptr i64 ptrtoint (ptr @myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1188, i64 12884901909) "call-inline-cost"="0", !dbg !128
  %v1189 = load i64, ptr %slot203, align 8
  %op1190 = add i64 %v1189, 8
  store i64 %op1190, ptr %slot206, align 8
  %v1191 = load i64, ptr %slot32, align 8
  store i64 %v1191, ptr %slot207, align 8
  %v1192 = load i64, ptr %slot207, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  store i64 0, ptr %p1193, align 8, !alias.scope !3, !noalias !4
  %v1194 = load i64, ptr %slot207, align 8
  %p1196 = inttoptr i64 %v1194 to ptr
  %gep1197 = getelementptr i8, ptr %p1196, i64 8
  %op1195 = ptrtoint ptr %gep1197 to i64
  store i64 %op1195, ptr %slot208, align 8
  %v1198 = load i64, ptr %slot208, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  store i64 0, ptr %p1199, align 8, !alias.scope !3, !noalias !4
  %v1200 = load i64, ptr %slot207, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  store i32 1, ptr %p1201, align 4, !alias.scope !3, !noalias !4
  %v1202 = load i64, ptr %slot207, align 8
  %p1204 = inttoptr i64 %v1202 to ptr
  %gep1205 = getelementptr i8, ptr %p1204, i64 8
  %op1203 = ptrtoint ptr %gep1205 to i64
  store i64 %op1203, ptr %slot209, align 8
  %v1206 = load i64, ptr %slot15, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  store i32 1, ptr %p1207, align 4, !alias.scope !3, !noalias !4
  %v1208 = load i64, ptr %slot41, align 8
  store i64 %v1208, ptr %slot210, align 8
  %v1209 = load i64, ptr %slot207, align 8
  %v1210 = load i64, ptr %slot24, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i64 %v1209, ptr %p1211, align 8, !alias.scope !3, !noalias !4
  %v1212 = load i64, ptr %slot7, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  %ld1214 = load i32, ptr %p1213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1214, ptr %slot211, align 8
  %v1215 = load i32, ptr %slot211, align 8
  %cv1216 = zext i32 %v1215 to i64
  %cond1217 = icmp ne i64 %cv1216, 0
  br i1 %cond1217, label %bb_rcslotdrop261, label %bb_rcslotdone261
bb_rcslotdrop261:
  %v1218 = load i64, ptr %slot7, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  store i32 0, ptr %p1219, align 4, !alias.scope !3, !noalias !4
  %v1220 = load i64, ptr %slot16, align 8
  store i64 %v1220, ptr %slot212, align 8
  %v1221 = load i64, ptr %slot8, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  %ld1223 = load i32, ptr %p1222, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1223, ptr %slot213, align 8
  %v1224 = load i32, ptr %slot213, align 8
  %op1225 = and i32 %v1224, 28
  store i32 %op1225, ptr %slot214, align 8
  %v1226 = load i32, ptr %slot214, align 8
  %cv1227 = zext i32 %v1226 to i64
  %cond1228 = icmp ne i64 %cv1227, 0
  br i1 %cond1228, label %bb_rcslotrole261, label %bb_rcslotowner261
bb_rcslotrole261:
  %v1229 = load i64, ptr %slot40, align 8
  store i64 %v1229, ptr %slot215, align 8
  %v1230 = load i64, ptr %slot215, align 8
  %v1231 = load i64, ptr %slot212, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v1230, i64 %v1231) nomerge, !dbg !128
  br label %bb_rcslotdone261
bb_rcslotowner261:
  %v1232 = load i64, ptr %slot40, align 8
  store i64 %v1232, ptr %slot216, align 8
  %v1233 = load i64, ptr %slot216, align 8
  %v1234 = load i64, ptr %slot212, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v1233, i64 %v1234) nomerge, !dbg !128
  br label %bb_rcslotdone261
bb_rcslotdone261:
  br label %bb_i23
bb_rctryok250:
  %v1235 = load i64, ptr %slot32, align 8
  store i64 %v1235, ptr %slot217, align 8
  %v1236 = load i64, ptr %slot217, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i64 0, ptr %p1237, align 8, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot217, align 8
  %p1240 = inttoptr i64 %v1238 to ptr
  %gep1241 = getelementptr i8, ptr %p1240, i64 8
  %op1239 = ptrtoint ptr %gep1241 to i64
  store i64 %op1239, ptr %slot218, align 8
  %v1242 = load i64, ptr %slot218, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  store i64 0, ptr %p1243, align 8, !alias.scope !3, !noalias !4
  %v1244 = load i64, ptr %slot217, align 8
  %p1246 = inttoptr i64 %v1244 to ptr
  %gep1247 = getelementptr i8, ptr %p1246, i64 16
  %op1245 = ptrtoint ptr %gep1247 to i64
  store i64 %op1245, ptr %slot219, align 8
  %v1248 = load i64, ptr %slot219, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i64 0, ptr %p1249, align 8, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot217, align 8
  %p1252 = inttoptr i64 %v1250 to ptr
  %gep1253 = getelementptr i8, ptr %p1252, i64 24
  %op1251 = ptrtoint ptr %gep1253 to i64
  store i64 %op1251, ptr %slot220, align 8
  %v1254 = load i64, ptr %slot220, align 8
  %p1255 = inttoptr i64 %v1254 to ptr
  store i64 0, ptr %p1255, align 8, !alias.scope !3, !noalias !4
  %v1256 = load i64, ptr %slot217, align 8
  %p1258 = inttoptr i64 %v1256 to ptr
  %gep1259 = getelementptr i8, ptr %p1258, i64 32
  %op1257 = ptrtoint ptr %gep1259 to i64
  store i64 %op1257, ptr %slot221, align 8
  %v1260 = load i64, ptr %slot221, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  store i64 0, ptr %p1261, align 8, !alias.scope !3, !noalias !4
  %v1262 = load i64, ptr %slot15, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  store i32 1, ptr %p1263, align 4, !alias.scope !3, !noalias !4
  %v1264 = load i64, ptr %slot203, align 8
  %op1265 = add i64 %v1264, 8
  store i64 %op1265, ptr %slot222, align 8
  %v1266 = load i64, ptr %slot41, align 8
  store i64 %v1266, ptr %slot223, align 8
  %v1267 = load i64, ptr %slot40, align 8
  %v1268 = load i64, ptr %slot217, align 8
  %v1269 = load i64, ptr %slot222, align 8
  %v1270 = load i64, ptr %slot223, align 8
  %cv1271 = trunc i64 %v1270 to i32
  %call1272 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v1267, i64 %v1268, i64 %v1269, i32 %cv1271) nomerge, !dbg !128
  store i32 %call1272, ptr %slot224, align 8
  %v1273 = load i32, ptr %slot224, align 8
  %cv1274 = zext i32 %v1273 to i64
  %cond1275 = icmp ne i64 %cv1274, 0
  br i1 %cond1275, label %bb_rcsuccess278, label %bb_rcfailure278
bb_rcfailure278:
  %v1276 = load i64, ptr %slot40, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  %call1278 = call i32 @myl_rc_take_failure(ptr %p1277) nomerge, !dbg !128
  store i32 %call1278, ptr %slot225, align 8
  %v1279 = load i64, ptr %slot1, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  %v1281 = load i32, ptr %slot225, align 8
  %call1282 = call i32 @myl_qbe_rc_status(ptr %p1280, i32 %v1281) nomerge, !dbg !128
  store i32 %call1282, ptr %slot226, align 8
  br label %bb_failure
bb_rcsuccess278:
  %v1283 = load i64, ptr %slot217, align 8
  %v1284 = load i64, ptr %slot24, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  store i64 %v1283, ptr %p1285, align 8, !alias.scope !3, !noalias !4
  %v1286 = load i64, ptr %slot24, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  %ld1288 = load i64, ptr %p1287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1288, ptr %slot227, align 8
  %v1289 = load i64, ptr %slot20, align 8
  store i64 %v1289, ptr %slot228, align 8
  %v1290 = load i64, ptr %slot227, align 8
  %v1291 = load i64, ptr %slot228, align 8
  %p1292 = inttoptr i64 %v1290 to ptr
  %p1293 = inttoptr i64 %v1291 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1293, ptr %p1292, i64 40, i1 false)
  %v1294 = load i64, ptr %slot14, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  store i32 2, ptr %p1295, align 4, !alias.scope !3, !noalias !4
  %v1296 = load i64, ptr %slot13, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  store i32 1, ptr %p1297, align 4, !alias.scope !3, !noalias !4
  %v1298 = load i64, ptr %slot7, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  %ld1300 = load i32, ptr %p1299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1300, ptr %slot229, align 8
  %v1301 = load i32, ptr %slot229, align 8
  %cv1302 = zext i32 %v1301 to i64
  %cond1303 = icmp ne i64 %cv1302, 0
  br i1 %cond1303, label %bb_rcslotdrop287, label %bb_rcslotdone287
bb_rcslotdrop287:
  %v1304 = load i64, ptr %slot7, align 8
  %p1305 = inttoptr i64 %v1304 to ptr
  store i32 0, ptr %p1305, align 4, !alias.scope !3, !noalias !4
  %v1306 = load i64, ptr %slot16, align 8
  store i64 %v1306, ptr %slot230, align 8
  %v1307 = load i64, ptr %slot8, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  %ld1309 = load i32, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1309, ptr %slot231, align 8
  %v1310 = load i32, ptr %slot231, align 8
  %op1311 = and i32 %v1310, 28
  store i32 %op1311, ptr %slot232, align 8
  %v1312 = load i32, ptr %slot232, align 8
  %cv1313 = zext i32 %v1312 to i64
  %cond1314 = icmp ne i64 %cv1313, 0
  br i1 %cond1314, label %bb_rcslotrole287, label %bb_rcslotowner287
bb_rcslotrole287:
  %v1315 = load i64, ptr %slot40, align 8
  store i64 %v1315, ptr %slot233, align 8
  %v1316 = load i64, ptr %slot233, align 8
  %v1317 = load i64, ptr %slot230, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v1316, i64 %v1317) nomerge, !dbg !128
  br label %bb_rcslotdone287
bb_rcslotowner287:
  %v1318 = load i64, ptr %slot40, align 8
  store i64 %v1318, ptr %slot234, align 8
  %v1319 = load i64, ptr %slot234, align 8
  %v1320 = load i64, ptr %slot230, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v1319, i64 %v1320) nomerge, !dbg !128
  br label %bb_rcslotdone287
bb_rcslotdone287:
  %v1321 = load i64, ptr %slot16, align 8
  store i64 %v1321, ptr %slot235, align 8
  %v1322 = load i64, ptr %slot20, align 8
  store i64 %v1322, ptr %slot236, align 8
  %v1323 = load i64, ptr %slot236, align 8
  %v1324 = load i64, ptr %slot235, align 8
  %p1325 = inttoptr i64 %v1323 to ptr
  %p1326 = inttoptr i64 %v1324 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1326, ptr %p1325, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1327 = load i64, ptr %slot8, align 8
  %p1328 = inttoptr i64 %v1327 to ptr
  store i32 2, ptr %p1328, align 4, !alias.scope !3, !noalias !4
  %v1329 = load i64, ptr %slot14, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  %ld1331 = load i32, ptr %p1330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1331, ptr %slot237, align 8
  %v1332 = load i32, ptr %slot237, align 8
  %v1333 = load i64, ptr %slot8, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  store i32 %v1332, ptr %p1334, align 4, !alias.scope !3, !noalias !4
  %v1335 = load i64, ptr %slot13, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  store i32 0, ptr %p1336, align 4, !alias.scope !3, !noalias !4
  %v1337 = load i64, ptr %slot7, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  store i32 1, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  %v1339 = load i64, ptr %slot235, align 8
  %v1340 = load i64, ptr %slot24, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  store i64 %v1339, ptr %p1341, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i23:
  %v1342 = load i64, ptr %slot24, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %ld1344 = load i64, ptr %p1343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1344, ptr %slot238, align 8
  %v1345 = load i64, ptr %slot7, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  %ld1347 = load i32, ptr %p1346, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1347, ptr %slot239, align 8
  %v1348 = load i32, ptr %slot239, align 8
  %cv1349 = zext i32 %v1348 to i64
  %cond1350 = icmp ne i64 %cv1349, 0
  br i1 %cond1350, label %bb_rcslotdrop305, label %bb_rcslotdone305
bb_rcslotdrop305:
  %v1351 = load i64, ptr %slot7, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  store i32 0, ptr %p1352, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone305
bb_rcslotdone305:
  %v1353 = load i64, ptr %slot5, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %ld1355 = load i32, ptr %p1354, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1355, ptr %slot240, align 8
  %v1356 = load i32, ptr %slot240, align 8
  %cv1357 = zext i32 %v1356 to i64
  %cond1358 = icmp ne i64 %cv1357, 0
  br i1 %cond1358, label %bb_rcslotdrop308, label %bb_rcslotdone308
bb_rcslotdrop308:
  %v1359 = load i64, ptr %slot5, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  store i32 0, ptr %p1360, align 4, !alias.scope !3, !noalias !4
  %v1361 = load i64, ptr %slot22, align 8
  store i64 %v1361, ptr %slot241, align 8
  %v1362 = load i64, ptr %slot6, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  %ld1364 = load i32, ptr %p1363, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1364, ptr %slot242, align 8
  %v1365 = load i32, ptr %slot242, align 8
  %op1366 = and i32 %v1365, 28
  store i32 %op1366, ptr %slot243, align 8
  %v1367 = load i32, ptr %slot243, align 8
  %cv1368 = zext i32 %v1367 to i64
  %cond1369 = icmp ne i64 %cv1368, 0
  br i1 %cond1369, label %bb_rcslotrole308, label %bb_rcslotowner308
bb_rcslotrole308:
  %v1370 = load i64, ptr %slot40, align 8
  store i64 %v1370, ptr %slot244, align 8
  %v1371 = load i64, ptr %slot244, align 8
  %v1372 = load i64, ptr %slot241, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1371, i64 %v1372) nomerge, !dbg !130
  br label %bb_rcslotdone308
bb_rcslotowner308:
  %v1373 = load i64, ptr %slot40, align 8
  store i64 %v1373, ptr %slot245, align 8
  %v1374 = load i64, ptr %slot245, align 8
  %v1375 = load i64, ptr %slot241, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1374, i64 %v1375) nomerge, !dbg !130
  br label %bb_rcslotdone308
bb_rcslotdone308:
  %v1376 = load i64, ptr %slot238, align 8
  %p1377 = inttoptr i64 %v1376 to ptr
  %ret1378 = load { i64, i64 }, ptr %p1377, align 8
  ret { i64, i64 } %ret1378
bb_i24:
  %v1379 = load i64, ptr %slot7, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  %ld1381 = load i32, ptr %p1380, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1381, ptr %slot246, align 8
  %v1382 = load i32, ptr %slot246, align 8
  %cv1383 = zext i32 %v1382 to i64
  %cond1384 = icmp ne i64 %cv1383, 0
  br i1 %cond1384, label %bb_rcslotdrop326, label %bb_rcslotdone326
bb_rcslotdrop326:
  %v1385 = load i64, ptr %slot7, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  store i32 0, ptr %p1386, align 4, !alias.scope !3, !noalias !4
  %v1387 = load i64, ptr %slot16, align 8
  store i64 %v1387, ptr %slot247, align 8
  %v1388 = load i64, ptr %slot8, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %ld1390 = load i32, ptr %p1389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1390, ptr %slot248, align 8
  %v1391 = load i32, ptr %slot248, align 8
  %op1392 = and i32 %v1391, 28
  store i32 %op1392, ptr %slot249, align 8
  %v1393 = load i32, ptr %slot249, align 8
  %cv1394 = zext i32 %v1393 to i64
  %cond1395 = icmp ne i64 %cv1394, 0
  br i1 %cond1395, label %bb_rcslotrole326, label %bb_rcslotowner326
bb_rcslotrole326:
  %v1396 = load i64, ptr %slot40, align 8
  store i64 %v1396, ptr %slot250, align 8
  %v1397 = load i64, ptr %slot250, align 8
  %v1398 = load i64, ptr %slot247, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1397, i64 %v1398) nomerge, !dbg !132
  br label %bb_rcslotdone326
bb_rcslotowner326:
  %v1399 = load i64, ptr %slot40, align 8
  store i64 %v1399, ptr %slot251, align 8
  %v1400 = load i64, ptr %slot251, align 8
  %v1401 = load i64, ptr %slot247, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1400, i64 %v1401) nomerge, !dbg !132
  br label %bb_rcslotdone326
bb_rcslotdone326:
  %v1402 = load i64, ptr %slot21, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  %ld1404 = load i64, ptr %p1403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1404, ptr %slot252, align 8
  %v1405 = load i64, ptr %slot252, align 8
  %v1406 = load i64, ptr %slot24, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i64 %v1405, ptr %p1407, align 8, !alias.scope !3, !noalias !4
  %v1408 = load i64, ptr %slot22, align 8
  %v1409 = load i64, ptr %slot25, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  store i64 %v1408, ptr %p1410, align 8, !alias.scope !3, !noalias !4
  %v1411 = load i64, ptr %slot23, align 8
  %v1412 = load i64, ptr %slot26, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  store i64 %v1411, ptr %p1413, align 8, !alias.scope !3, !noalias !4
  %v1414 = load i64, ptr %slot33, align 8
  store i64 %v1414, ptr %slot253, align 8
  %v1415 = load i64, ptr %slot253, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  store i64 0, ptr %p1416, align 8, !alias.scope !3, !noalias !4
  %v1417 = load i64, ptr %slot253, align 8
  %p1419 = inttoptr i64 %v1417 to ptr
  %gep1420 = getelementptr i8, ptr %p1419, i64 8
  %op1418 = ptrtoint ptr %gep1420 to i64
  store i64 %op1418, ptr %slot254, align 8
  %v1421 = load i64, ptr %slot254, align 8
  %p1422 = inttoptr i64 %v1421 to ptr
  store i64 0, ptr %p1422, align 8, !alias.scope !3, !noalias !4
  %v1423 = load i64, ptr %slot253, align 8
  %p1425 = inttoptr i64 %v1423 to ptr
  %gep1426 = getelementptr i8, ptr %p1425, i64 16
  %op1424 = ptrtoint ptr %gep1426 to i64
  store i64 %op1424, ptr %slot255, align 8
  %v1427 = load i64, ptr %slot255, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i64 0, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot253, align 8
  %p1431 = inttoptr i64 %v1429 to ptr
  %gep1432 = getelementptr i8, ptr %p1431, i64 24
  %op1430 = ptrtoint ptr %gep1432 to i64
  store i64 %op1430, ptr %slot256, align 8
  %v1433 = load i64, ptr %slot256, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  store i64 0, ptr %p1434, align 8, !alias.scope !3, !noalias !4
  %v1435 = load i64, ptr %slot253, align 8
  %p1437 = inttoptr i64 %v1435 to ptr
  %gep1438 = getelementptr i8, ptr %p1437, i64 32
  %op1436 = ptrtoint ptr %gep1438 to i64
  store i64 %op1436, ptr %slot257, align 8
  %v1439 = load i64, ptr %slot257, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  store i64 0, ptr %p1440, align 8, !alias.scope !3, !noalias !4
  %v1441 = load i64, ptr %slot253, align 8
  %p1443 = inttoptr i64 %v1441 to ptr
  %gep1444 = getelementptr i8, ptr %p1443, i64 40
  %op1442 = ptrtoint ptr %gep1444 to i64
  store i64 %op1442, ptr %slot258, align 8
  %v1445 = load i64, ptr %slot258, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  store i64 0, ptr %p1446, align 8, !alias.scope !3, !noalias !4
  %v1447 = load i64, ptr %slot253, align 8
  %p1449 = inttoptr i64 %v1447 to ptr
  %gep1450 = getelementptr i8, ptr %p1449, i64 48
  %op1448 = ptrtoint ptr %gep1450 to i64
  store i64 %op1448, ptr %slot259, align 8
  %v1451 = load i64, ptr %slot259, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  store i64 0, ptr %p1452, align 8, !alias.scope !3, !noalias !4
  %v1453 = load i64, ptr %slot15, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  store i32 1, ptr %p1454, align 4, !alias.scope !3, !noalias !4
  %v1455 = load i64, ptr %slot41, align 8
  store i64 %v1455, ptr %slot260, align 8
  %v1456 = load i64, ptr %slot25, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %ld1458 = load i64, ptr %p1457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1458, ptr %slot261, align 8
  %v1459 = load i64, ptr %slot253, align 8
  %p1461 = inttoptr i64 %v1459 to ptr
  %gep1462 = getelementptr i8, ptr %p1461, i64 0
  %op1460 = ptrtoint ptr %gep1462 to i64
  store i64 %op1460, ptr %slot262, align 8
  %v1463 = load i64, ptr %slot25, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  %ld1465 = load i64, ptr %p1464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1465, ptr %slot263, align 8
  %v1466 = load i64, ptr %slot9, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  %ld1468 = load i32, ptr %p1467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1468, ptr %slot264, align 8
  %v1469 = load i64, ptr %slot10, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i32, ptr %p1470, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1471, ptr %slot265, align 8
  %v1472 = load i32, ptr %slot265, align 8
  %op1473 = and i32 %v1472, 24
  store i32 %op1473, ptr %slot265, align 8
  %v1474 = load i32, ptr %slot265, align 8
  %cmp1475 = icmp eq i32 %v1474, 0
  %cv1476 = zext i1 %cmp1475 to i32
  store i32 %cv1476, ptr %slot266, align 8
  %v1477 = load i32, ptr %slot264, align 8
  %v1478 = load i32, ptr %slot266, align 8
  %op1479 = and i32 %v1477, %v1478
  store i32 %op1479, ptr %slot267, align 8
  %v1480 = load i32, ptr %slot267, align 8
  %cv1481 = zext i32 %v1480 to i64
  %cond1482 = icmp ne i64 %cv1481, 0
  br i1 %cond1482, label %bb_rctake347, label %bb_rccopy347
bb_rctake347:
  %v1483 = load i64, ptr %slot20, align 8
  store i64 %v1483, ptr %slot268, align 8
  %v1484 = load i64, ptr %slot41, align 8
  store i64 %v1484, ptr %slot269, align 8
  %v1485 = load i64, ptr %slot40, align 8
  %v1486 = load i64, ptr %slot268, align 8
  %v1487 = load i64, ptr %slot263, align 8
  %v1488 = load i64, ptr %slot269, align 8
  %cv1489 = trunc i64 %v1488 to i32
  %call1490 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v1485, i64 %v1486, i64 %v1487, i32 %cv1489) nomerge, !dbg !134
  store i32 %call1490, ptr %slot270, align 8
  %v1491 = load i32, ptr %slot270, align 8
  %cv1492 = zext i32 %v1491 to i64
  %cond1493 = icmp ne i64 %cv1492, 0
  br i1 %cond1493, label %bb_rcsuccess357, label %bb_rcfailure357
bb_rcfailure357:
  %v1494 = load i64, ptr %slot40, align 8
  %p1495 = inttoptr i64 %v1494 to ptr
  %call1496 = call i32 @myl_rc_take_failure(ptr %p1495) nomerge, !dbg !134
  store i32 %call1496, ptr %slot271, align 8
  %v1497 = load i64, ptr %slot1, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  %v1499 = load i32, ptr %slot271, align 8
  %call1500 = call i32 @myl_qbe_rc_status(ptr %p1498, i32 %v1499) nomerge, !dbg !134
  store i32 %call1500, ptr %slot272, align 8
  br label %bb_failure
bb_rcsuccess357:
  %v1501 = load i64, ptr %slot9, align 8
  %p1502 = inttoptr i64 %v1501 to ptr
  store i32 0, ptr %p1502, align 4, !alias.scope !3, !noalias !4
  %v1503 = load i64, ptr %slot14, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  store i32 2, ptr %p1504, align 4, !alias.scope !3, !noalias !4
  %v1505 = load i64, ptr %slot13, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  store i32 1, ptr %p1506, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared347
bb_rccopy347:
  %v1507 = load i64, ptr %slot20, align 8
  store i64 %v1507, ptr %slot273, align 8
  %v1508 = load i64, ptr %slot41, align 8
  store i64 %v1508, ptr %slot274, align 8
  %v1509 = load i64, ptr %slot40, align 8
  %v1510 = load i64, ptr %slot273, align 8
  %v1511 = load i64, ptr %slot263, align 8
  %v1512 = load i64, ptr %slot274, align 8
  %cv1513 = trunc i64 %v1512 to i32
  %call1514 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v1509, i64 %v1510, i64 %v1511, i32 %cv1513) nomerge, !dbg !134
  store i32 %call1514, ptr %slot275, align 8
  %v1515 = load i32, ptr %slot275, align 8
  %cv1516 = zext i32 %v1515 to i64
  %cond1517 = icmp ne i64 %cv1516, 0
  br i1 %cond1517, label %bb_rcsuccess366, label %bb_rcfailure366
bb_rcfailure366:
  %v1518 = load i64, ptr %slot40, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  %call1520 = call i32 @myl_rc_take_failure(ptr %p1519) nomerge, !dbg !134
  store i32 %call1520, ptr %slot276, align 8
  %v1521 = load i64, ptr %slot1, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  %v1523 = load i32, ptr %slot276, align 8
  %call1524 = call i32 @myl_qbe_rc_status(ptr %p1522, i32 %v1523) nomerge, !dbg !134
  store i32 %call1524, ptr %slot277, align 8
  br label %bb_failure
bb_rcsuccess366:
  %v1525 = load i64, ptr %slot14, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  store i32 2, ptr %p1526, align 4, !alias.scope !3, !noalias !4
  %v1527 = load i64, ptr %slot13, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  store i32 1, ptr %p1528, align 4, !alias.scope !3, !noalias !4
  %v1529 = load i64, ptr %slot9, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  %ld1531 = load i32, ptr %p1530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1531, ptr %slot278, align 8
  %v1532 = load i32, ptr %slot278, align 8
  %cv1533 = zext i32 %v1532 to i64
  %cond1534 = icmp ne i64 %cv1533, 0
  br i1 %cond1534, label %bb_rcslotdrop373, label %bb_rcslotdone373
bb_rcslotdrop373:
  %v1535 = load i64, ptr %slot9, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  store i32 0, ptr %p1536, align 4, !alias.scope !3, !noalias !4
  %v1537 = load i64, ptr %slot17, align 8
  store i64 %v1537, ptr %slot279, align 8
  %v1538 = load i64, ptr %slot10, align 8
  %p1539 = inttoptr i64 %v1538 to ptr
  %ld1540 = load i32, ptr %p1539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1540, ptr %slot280, align 8
  %v1541 = load i32, ptr %slot280, align 8
  %op1542 = and i32 %v1541, 28
  store i32 %op1542, ptr %slot281, align 8
  %v1543 = load i32, ptr %slot281, align 8
  %cv1544 = zext i32 %v1543 to i64
  %cond1545 = icmp ne i64 %cv1544, 0
  br i1 %cond1545, label %bb_rcslotrole373, label %bb_rcslotowner373
bb_rcslotrole373:
  %v1546 = load i64, ptr %slot40, align 8
  store i64 %v1546, ptr %slot282, align 8
  %v1547 = load i64, ptr %slot282, align 8
  %v1548 = load i64, ptr %slot279, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1547, i64 %v1548) nomerge, !dbg !134
  br label %bb_rcslotdone373
bb_rcslotowner373:
  %v1549 = load i64, ptr %slot40, align 8
  store i64 %v1549, ptr %slot283, align 8
  %v1550 = load i64, ptr %slot283, align 8
  %v1551 = load i64, ptr %slot279, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1550, i64 %v1551) nomerge, !dbg !134
  br label %bb_rcslotdone373
bb_rcslotdone373:
  br label %bb_rcprepared347
bb_rcprepared347:
  %v1552 = load i64, ptr %slot20, align 8
  store i64 %v1552, ptr %slot284, align 8
  %v1553 = load i64, ptr %slot284, align 8
  %v1554 = load i64, ptr %slot262, align 8
  %p1555 = inttoptr i64 %v1553 to ptr
  %p1556 = inttoptr i64 %v1554 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1556, ptr %p1555, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1557 = load i64, ptr %slot13, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  store i32 0, ptr %p1558, align 4, !alias.scope !3, !noalias !4
  %v1559 = load i64, ptr %slot26, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %ld1561 = load i64, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1561, ptr %slot285, align 8
  %v1562 = load i64, ptr %slot253, align 8
  %p1564 = inttoptr i64 %v1562 to ptr
  %gep1565 = getelementptr i8, ptr %p1564, i64 40
  %op1563 = ptrtoint ptr %gep1565 to i64
  store i64 %op1563, ptr %slot286, align 8
  %v1566 = load i64, ptr %slot285, align 8
  %v1567 = load i64, ptr %slot286, align 8
  %p1568 = inttoptr i64 %v1566 to ptr
  %p1569 = inttoptr i64 %v1567 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1569, ptr %p1568, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1570 = load i64, ptr %slot253, align 8
  %v1571 = load i64, ptr %slot25, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i64 %v1570, ptr %p1572, align 8, !alias.scope !3, !noalias !4
  %v1573 = load i64, ptr %slot25, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  %ld1575 = load i64, ptr %p1574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1575, ptr %slot287, align 8
  %v1576 = load i64, ptr %slot17, align 8
  store i64 %v1576, ptr %slot288, align 8
  %v1577 = load i64, ptr %slot287, align 8
  %v1578 = load i64, ptr %slot288, align 8
  %p1579 = inttoptr i64 %v1577 to ptr
  %p1580 = inttoptr i64 %v1578 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1580, ptr %p1579, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot10, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  store i32 2, ptr %p1582, align 4, !alias.scope !3, !noalias !4
  %v1583 = load i64, ptr %slot9, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  store i32 1, ptr %p1584, align 4, !alias.scope !3, !noalias !4
  %v1585 = load i64, ptr %slot288, align 8
  %v1586 = load i64, ptr %slot25, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  store i64 %v1585, ptr %p1587, align 8, !alias.scope !3, !noalias !4
  %v1588 = load i64, ptr %slot34, align 8
  store i64 %v1588, ptr %slot289, align 8
  %v1589 = load i64, ptr %slot289, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  call void @llvm.memset.p0.i64(ptr %p1590, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !136
  %v1591 = load i64, ptr %slot289, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i32 6, ptr %p1592, align 4, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot15, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  store i32 1, ptr %p1594, align 4, !alias.scope !3, !noalias !4
  %v1595 = load i64, ptr %slot25, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  %ld1597 = load i64, ptr %p1596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1597, ptr %slot290, align 8
  %v1598 = load i64, ptr %slot289, align 8
  %p1600 = inttoptr i64 %v1598 to ptr
  %gep1601 = getelementptr i8, ptr %p1600, i64 8
  %op1599 = ptrtoint ptr %gep1601 to i64
  store i64 %op1599, ptr %slot291, align 8
  %v1602 = load i64, ptr %slot41, align 8
  store i64 %v1602, ptr %slot292, align 8
  %v1603 = load i64, ptr %slot25, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %ld1605 = load i64, ptr %p1604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1605, ptr %slot293, align 8
  %v1606 = load i64, ptr %slot20, align 8
  store i64 %v1606, ptr %slot294, align 8
  %v1607 = load i64, ptr %slot41, align 8
  store i64 %v1607, ptr %slot295, align 8
  %v1608 = load i64, ptr %slot40, align 8
  %v1609 = load i64, ptr %slot294, align 8
  %v1610 = load i64, ptr %slot293, align 8
  %v1611 = load i64, ptr %slot295, align 8
  %cv1612 = trunc i64 %v1611 to i32
  %call1613 = call i32 @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_take(i64 %v1608, i64 %v1609, i64 %v1610, i32 %cv1612) nomerge, !dbg !136
  store i32 %call1613, ptr %slot296, align 8
  %v1614 = load i32, ptr %slot296, align 8
  %cv1615 = zext i32 %v1614 to i64
  %cond1616 = icmp ne i64 %cv1615, 0
  br i1 %cond1616, label %bb_rcsuccess398, label %bb_rcfailure398
bb_rcfailure398:
  %v1617 = load i64, ptr %slot40, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %call1619 = call i32 @myl_rc_take_failure(ptr %p1618) nomerge, !dbg !136
  store i32 %call1619, ptr %slot297, align 8
  %v1620 = load i64, ptr %slot1, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  %v1622 = load i32, ptr %slot297, align 8
  %call1623 = call i32 @myl_qbe_rc_status(ptr %p1621, i32 %v1622) nomerge, !dbg !136
  store i32 %call1623, ptr %slot298, align 8
  br label %bb_failure
bb_rcsuccess398:
  %v1624 = load i64, ptr %slot9, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i32 0, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot14, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  store i32 2, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  %v1628 = load i64, ptr %slot13, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i32 1, ptr %p1629, align 4, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot20, align 8
  store i64 %v1630, ptr %slot299, align 8
  %v1631 = load i64, ptr %slot299, align 8
  %v1632 = load i64, ptr %slot291, align 8
  %p1633 = inttoptr i64 %v1631 to ptr
  %p1634 = inttoptr i64 %v1632 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1634, ptr %p1633, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1635 = load i64, ptr %slot13, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  store i32 0, ptr %p1636, align 4, !alias.scope !3, !noalias !4
  %v1637 = load i64, ptr %slot289, align 8
  %v1638 = load i64, ptr %slot25, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i64 %v1637, ptr %p1639, align 8, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot25, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  %ld1642 = load i64, ptr %p1641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1642, ptr %slot300, align 8
  %v1643 = load i64, ptr %slot17, align 8
  store i64 %v1643, ptr %slot301, align 8
  %v1644 = load i64, ptr %slot300, align 8
  %v1645 = load i64, ptr %slot301, align 8
  %p1646 = inttoptr i64 %v1644 to ptr
  %p1647 = inttoptr i64 %v1645 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1647, ptr %p1646, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1648 = load i64, ptr %slot10, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  store i32 2, ptr %p1649, align 4, !alias.scope !3, !noalias !4
  %v1650 = load i64, ptr %slot9, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  store i32 1, ptr %p1651, align 4, !alias.scope !3, !noalias !4
  %v1652 = load i64, ptr %slot301, align 8
  %v1653 = load i64, ptr %slot25, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  store i64 %v1652, ptr %p1654, align 8, !alias.scope !3, !noalias !4
  %v1655 = load i64, ptr %slot24, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  %ld1657 = load i64, ptr %p1656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1657, ptr %slot302, align 8
  %v1658 = load i64, ptr %slot25, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  %ld1660 = load i64, ptr %p1659, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1660, ptr %slot303, align 8
  %v1661 = load i64, ptr %slot1, align 8
  %v1662 = load i64, ptr %slot302, align 8
  %v1663 = load i64, ptr %slot303, align 8
  %call1664 = call i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64 %v1661, i64 %v1662, i64 %v1663) nomerge, !dbg !138
  store i64 %call1664, ptr %slot304, align 8
  %v1665 = load i64, ptr %slot304, align 8
  %v1666 = load i64, ptr %slot24, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i64 %v1665, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  %v1668 = load i64, ptr %slot7, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  %ld1670 = load i32, ptr %p1669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1670, ptr %slot305, align 8
  %v1671 = load i32, ptr %slot305, align 8
  %cv1672 = zext i32 %v1671 to i64
  %cond1673 = icmp ne i64 %cv1672, 0
  br i1 %cond1673, label %bb_rcslotdrop415, label %bb_rcslotdone415
bb_rcslotdrop415:
  %v1674 = load i64, ptr %slot7, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i32 0, ptr %p1675, align 4, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot16, align 8
  store i64 %v1676, ptr %slot306, align 8
  %v1677 = load i64, ptr %slot8, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  %ld1679 = load i32, ptr %p1678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1679, ptr %slot307, align 8
  %v1680 = load i32, ptr %slot307, align 8
  %op1681 = and i32 %v1680, 28
  store i32 %op1681, ptr %slot308, align 8
  %v1682 = load i32, ptr %slot308, align 8
  %cv1683 = zext i32 %v1682 to i64
  %cond1684 = icmp ne i64 %cv1683, 0
  br i1 %cond1684, label %bb_rcslotrole415, label %bb_rcslotowner415
bb_rcslotrole415:
  %v1685 = load i64, ptr %slot40, align 8
  store i64 %v1685, ptr %slot309, align 8
  %v1686 = load i64, ptr %slot309, align 8
  %v1687 = load i64, ptr %slot306, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1686, i64 %v1687) nomerge, !dbg !138
  br label %bb_rcslotdone415
bb_rcslotowner415:
  %v1688 = load i64, ptr %slot40, align 8
  store i64 %v1688, ptr %slot310, align 8
  %v1689 = load i64, ptr %slot310, align 8
  %v1690 = load i64, ptr %slot306, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1689, i64 %v1690) nomerge, !dbg !138
  br label %bb_rcslotdone415
bb_rcslotdone415:
  %v1691 = load i64, ptr %slot9, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %ld1693 = load i32, ptr %p1692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1693, ptr %slot311, align 8
  %v1694 = load i32, ptr %slot311, align 8
  %cv1695 = zext i32 %v1694 to i64
  %cond1696 = icmp ne i64 %cv1695, 0
  br i1 %cond1696, label %bb_rcslotdrop424, label %bb_rcslotdone424
bb_rcslotdrop424:
  %v1697 = load i64, ptr %slot9, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  store i32 0, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  %v1699 = load i64, ptr %slot17, align 8
  store i64 %v1699, ptr %slot312, align 8
  %v1700 = load i64, ptr %slot10, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  %ld1702 = load i32, ptr %p1701, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1702, ptr %slot313, align 8
  %v1703 = load i32, ptr %slot313, align 8
  %op1704 = and i32 %v1703, 28
  store i32 %op1704, ptr %slot314, align 8
  %v1705 = load i32, ptr %slot314, align 8
  %cv1706 = zext i32 %v1705 to i64
  %cond1707 = icmp ne i64 %cv1706, 0
  br i1 %cond1707, label %bb_rcslotrole424, label %bb_rcslotowner424
bb_rcslotrole424:
  %v1708 = load i64, ptr %slot40, align 8
  store i64 %v1708, ptr %slot315, align 8
  %v1709 = load i64, ptr %slot315, align 8
  %v1710 = load i64, ptr %slot312, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v1709, i64 %v1710) nomerge, !dbg !138
  br label %bb_rcslotdone424
bb_rcslotowner424:
  %v1711 = load i64, ptr %slot40, align 8
  store i64 %v1711, ptr %slot316, align 8
  %v1712 = load i64, ptr %slot316, align 8
  %v1713 = load i64, ptr %slot312, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v1712, i64 %v1713) nomerge, !dbg !138
  br label %bb_rcslotdone424
bb_rcslotdone424:
  %v1714 = load i64, ptr %slot35, align 8
  store i64 %v1714, ptr %slot317, align 8
  %v1715 = load i64, ptr %slot317, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i64 0, ptr %p1716, align 8, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot317, align 8
  %p1719 = inttoptr i64 %v1717 to ptr
  %gep1720 = getelementptr i8, ptr %p1719, i64 8
  %op1718 = ptrtoint ptr %gep1720 to i64
  store i64 %op1718, ptr %slot318, align 8
  %v1721 = load i64, ptr %slot318, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  store i64 0, ptr %p1722, align 8, !alias.scope !3, !noalias !4
  %v1723 = load i64, ptr %slot317, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i32 0, ptr %p1724, align 4, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot15, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i32 1, ptr %p1726, align 4, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot24, align 8
  store i64 %v1727, ptr %slot319, align 8
  %v1728 = load i64, ptr %slot317, align 8
  %p1730 = inttoptr i64 %v1728 to ptr
  %gep1731 = getelementptr i8, ptr %p1730, i64 8
  %op1729 = ptrtoint ptr %gep1731 to i64
  store i64 %op1729, ptr %slot320, align 8
  %v1732 = load i64, ptr %slot41, align 8
  store i64 %v1732, ptr %slot321, align 8
  %v1733 = load i64, ptr %slot319, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  %ld1735 = load i64, ptr %p1734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1735, ptr %slot322, align 8
  %v1736 = load i64, ptr %slot322, align 8
  %v1737 = load i64, ptr %slot320, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  store i64 %v1736, ptr %p1738, align 8, !alias.scope !3, !noalias !4
  %v1739 = load i64, ptr %slot317, align 8
  %v1740 = load i64, ptr %slot24, align 8
  %p1741 = inttoptr i64 %v1740 to ptr
  store i64 %v1739, ptr %p1741, align 8, !alias.scope !3, !noalias !4
  %v1742 = load i64, ptr %slot24, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %ld1744 = load i64, ptr %p1743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1744, ptr %slot323, align 8
  %v1745 = load i64, ptr %slot7, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  %ld1747 = load i32, ptr %p1746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1747, ptr %slot324, align 8
  %v1748 = load i32, ptr %slot324, align 8
  %cv1749 = zext i32 %v1748 to i64
  %cond1750 = icmp ne i64 %cv1749, 0
  br i1 %cond1750, label %bb_rcslotdrop442, label %bb_rcslotdone442
bb_rcslotdrop442:
  %v1751 = load i64, ptr %slot7, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  store i32 0, ptr %p1752, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone442
bb_rcslotdone442:
  %v1753 = load i64, ptr %slot5, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  %ld1755 = load i32, ptr %p1754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1755, ptr %slot325, align 8
  %v1756 = load i32, ptr %slot325, align 8
  %cv1757 = zext i32 %v1756 to i64
  %cond1758 = icmp ne i64 %cv1757, 0
  br i1 %cond1758, label %bb_rcslotdrop445, label %bb_rcslotdone445
bb_rcslotdrop445:
  %v1759 = load i64, ptr %slot5, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  store i32 0, ptr %p1760, align 4, !alias.scope !3, !noalias !4
  %v1761 = load i64, ptr %slot22, align 8
  store i64 %v1761, ptr %slot326, align 8
  %v1762 = load i64, ptr %slot6, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %ld1764 = load i32, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1764, ptr %slot327, align 8
  %v1765 = load i32, ptr %slot327, align 8
  %op1766 = and i32 %v1765, 28
  store i32 %op1766, ptr %slot328, align 8
  %v1767 = load i32, ptr %slot328, align 8
  %cv1768 = zext i32 %v1767 to i64
  %cond1769 = icmp ne i64 %cv1768, 0
  br i1 %cond1769, label %bb_rcslotrole445, label %bb_rcslotowner445
bb_rcslotrole445:
  %v1770 = load i64, ptr %slot40, align 8
  store i64 %v1770, ptr %slot329, align 8
  %v1771 = load i64, ptr %slot329, align 8
  %v1772 = load i64, ptr %slot326, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1771, i64 %v1772) nomerge, !dbg !140
  br label %bb_rcslotdone445
bb_rcslotowner445:
  %v1773 = load i64, ptr %slot40, align 8
  store i64 %v1773, ptr %slot330, align 8
  %v1774 = load i64, ptr %slot330, align 8
  %v1775 = load i64, ptr %slot326, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1774, i64 %v1775) nomerge, !dbg !140
  br label %bb_rcslotdone445
bb_rcslotdone445:
  %v1776 = load i64, ptr %slot323, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  %ret1778 = load { i64, i64 }, ptr %p1777, align 8
  ret { i64, i64 } %ret1778
bb_failure:
  %v1779 = load i64, ptr %slot4, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  call void @llvm.memset.p0.i64(ptr %p1780, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !140
  %v1781 = load i64, ptr %slot4, align 8
  %p1782 = inttoptr i64 %v1781 to ptr
  %ret1783 = load { i64, i64 }, ptr %p1782, align 8
  ret { i64, i64 } %ret1783
bb_entry_failure:
  %v1784 = load i64, ptr %slot4, align 8
  %p1785 = inttoptr i64 %v1784 to ptr
  call void @llvm.memset.p0.i64(ptr %p1785, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !140
  %v1786 = load i64, ptr %slot4, align 8
  %p1787 = inttoptr i64 %v1786 to ptr
  %ret1788 = load { i64, i64 }, ptr %p1787, align 8
  ret { i64, i64 } %ret1788
}

@myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166_meta = external global i8, align 8
@myl_lit_01b72450c49aa532f72eb3789506f0d955d06fca3165082ccbfd5958e6d56249 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64, i64)
declare i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64, i64, i64)
declare i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64, i64, i64)
declare void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8, i64, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)
declare i32 @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166", linkageName: "myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16569021105801190902, i64 0, !"myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!120 = !DILocation(line: 12, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!124 = !DILocation(line: 15, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!126 = !DILocation(line: 21, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!128 = !DILocation(line: 22, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!130 = !DILocation(line: 24, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!132 = !DILocation(line: 25, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!136 = !DILocation(line: 30, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!138 = !DILocation(line: 31, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!140 = !DILocation(line: 33, column: 0, scope: !141)
