target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_27a3542393b8217ef7be2c940ab8ef189833f24bc415b497a3e940f6e2a55c7c(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v45 = load i64, ptr %slot1, align 8
  %op46 = add i64 %v45, 32
  store i64 %op46, ptr %slot3, align 8
  %mem47 = alloca i8, i64 8, align 8
  %ptr48 = ptrtoint ptr %mem47 to i64
  store i64 %ptr48, ptr %slot4, align 8
  %mem49 = alloca i8, i64 32, align 8
  %ptr50 = ptrtoint ptr %mem49 to i64
  store i64 %ptr50, ptr %slot5, align 8
  %mem51 = alloca i8, i64 8, align 8
  %ptr52 = ptrtoint ptr %mem51 to i64
  store i64 %ptr52, ptr %slot6, align 8
  %mem53 = alloca i8, i64 8, align 8
  %ptr54 = ptrtoint ptr %mem53 to i64
  store i64 %ptr54, ptr %slot7, align 8
  %v55 = load i64, ptr %slot2, align 8
  %v56 = load i64, ptr %slot4, align 8
  %p57 = inttoptr i64 %v56 to ptr
  store i64 %v55, ptr %p57, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v58 = load i64, ptr %slot4, align 8
  %p59 = inttoptr i64 %v58 to ptr
  %ld60 = load i64, ptr %p59, align 8, !alias.scope !3, !noalias !4
  store i64 %ld60, ptr %slot8, align 8
  %v61 = load i64, ptr %slot8, align 8
  %v62 = load i64, ptr %slot6, align 8
  %p63 = inttoptr i64 %v62 to ptr
  store i64 %v61, ptr %p63, align 8, !alias.scope !3, !noalias !4
  %v64 = load i64, ptr %slot6, align 8
  %p65 = inttoptr i64 %v64 to ptr
  %ld66 = load i64, ptr %p65, align 8, !alias.scope !3, !noalias !4
  store i64 %ld66, ptr %slot9, align 8
  %v67 = load i64, ptr %slot5, align 8
  store i64 %v67, ptr %slot10, align 8
  %v68 = load i64, ptr %slot9, align 8
  %v69 = load i64, ptr %slot10, align 8
  %p70 = inttoptr i64 %v68 to ptr
  %p71 = inttoptr i64 %v69 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p71, ptr %p70, i64 32, i1 false), !alias.scope !10000000
  %v72 = load i64, ptr %slot5, align 8
  %v73 = load i64, ptr %slot6, align 8
  %p74 = inttoptr i64 %v73 to ptr
  store i64 %v72, ptr %p74, align 8, !alias.scope !3, !noalias !4
  %v75 = load i64, ptr %slot6, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %ld77 = load i64, ptr %p76, align 8, !alias.scope !3, !noalias !4
  store i64 %ld77, ptr %slot11, align 8
  %v78 = load i64, ptr %slot11, align 8
  %op79 = add i64 %v78, 16
  store i64 %op79, ptr %slot12, align 8
  %v80 = load i64, ptr %slot12, align 8
  %p81 = inttoptr i64 %v80 to ptr
  %ld82 = load i64, ptr %p81, align 8, !alias.scope !3, !noalias !4
  store i64 %ld82, ptr %slot13, align 8
  %v83 = load i64, ptr %slot13, align 8
  %v84 = load i64, ptr %slot6, align 8
  %p85 = inttoptr i64 %v84 to ptr
  store i64 %v83, ptr %p85, align 8, !alias.scope !3, !noalias !4
  %v86 = load i64, ptr %slot5, align 8
  %v87 = load i64, ptr %slot7, align 8
  %p88 = inttoptr i64 %v87 to ptr
  store i64 %v86, ptr %p88, align 8, !alias.scope !3, !noalias !4
  %v89 = load i64, ptr %slot7, align 8
  %p90 = inttoptr i64 %v89 to ptr
  %ld91 = load i64, ptr %p90, align 8, !alias.scope !3, !noalias !4
  store i64 %ld91, ptr %slot14, align 8
  %v92 = load i64, ptr %slot14, align 8
  %op93 = add i64 %v92, 0
  store i64 %op93, ptr %slot15, align 8
  %v94 = load i64, ptr %slot15, align 8
  %p95 = inttoptr i64 %v94 to ptr
  %ld96 = load i64, ptr %p95, align 8, !alias.scope !3, !noalias !4
  store i64 %ld96, ptr %slot16, align 8
  %v97 = load i64, ptr %slot16, align 8
  %v98 = load i64, ptr %slot7, align 8
  %p99 = inttoptr i64 %v98 to ptr
  store i64 %v97, ptr %p99, align 8, !alias.scope !3, !noalias !4
  %v100 = load i64, ptr %slot7, align 8
  %p101 = inttoptr i64 %v100 to ptr
  %ld102 = load i64, ptr %p101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld102, ptr %slot17, align 8
  %v103 = load i64, ptr %slot17, align 8
  %p104 = inttoptr i64 %v103 to ptr
  %ld105 = load i64, ptr %p104, align 8, !alias.scope !6, !noalias !7
  store i64 %ld105, ptr %slot18, align 8
  %v106 = load i64, ptr %slot18, align 8
  %v107 = load i64, ptr %slot7, align 8
  %p108 = inttoptr i64 %v107 to ptr
  store i64 %v106, ptr %p108, align 8, !alias.scope !3, !noalias !4
  %v109 = load i64, ptr %slot7, align 8
  %p110 = inttoptr i64 %v109 to ptr
  %ld111 = load i64, ptr %p110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld111, ptr %slot19, align 8
  %v112 = load i64, ptr %slot6, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld114, ptr %slot20, align 8
  %v115 = load i64, ptr %slot20, align 8
  %v116 = load i64, ptr %slot19, align 8
  %cmp117 = icmp sge i64 %v115, %v116
  %cv118 = zext i1 %cmp117 to i64
  store i64 %cv118, ptr %slot21, align 8
  %v119 = load i64, ptr %slot21, align 8
  %v120 = load i64, ptr %slot6, align 8
  %p121 = inttoptr i64 %v120 to ptr
  store i64 %v119, ptr %p121, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i9:
  %v122 = load i64, ptr %slot6, align 8
  %p123 = inttoptr i64 %v122 to ptr
  %ld124 = load i64, ptr %p123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld124, ptr %slot22, align 8
  %v125 = load i64, ptr %slot22, align 8
  %cond126 = icmp ne i64 %v125, 0
  br i1 %cond126, label %bb_next15, label %bb_i12
bb_next15:
  %v127 = load i64, ptr %slot6, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 0, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot6, align 8
  %p130 = inttoptr i64 %v129 to ptr
  %ld131 = load i64, ptr %p130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld131, ptr %slot23, align 8
  %v132 = load i64, ptr %slot23, align 8
  ret i64 %v132
bb_i12:
  %v133 = load i64, ptr %slot4, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot24, align 8
  %v136 = load i64, ptr %slot24, align 8
  %v137 = load i64, ptr %slot6, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot6, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot25, align 8
  %v142 = load i64, ptr %slot25, align 8
  %op143 = add i64 %v142, 0
  store i64 %op143, ptr %slot26, align 8
  %v144 = load i64, ptr %slot26, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !4, !noalias !3
  store i64 %ld146, ptr %slot27, align 8
  %v147 = load i64, ptr %slot27, align 8
  %v148 = load i64, ptr %slot6, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i64 %v147, ptr %p149, align 8, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot4, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld152, ptr %slot28, align 8
  %v153 = load i64, ptr %slot28, align 8
  %v154 = load i64, ptr %slot7, align 8
  %p155 = inttoptr i64 %v154 to ptr
  store i64 %v153, ptr %p155, align 8, !alias.scope !3, !noalias !4
  %v156 = load i64, ptr %slot7, align 8
  %p157 = inttoptr i64 %v156 to ptr
  %ld158 = load i64, ptr %p157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld158, ptr %slot29, align 8
  %v159 = load i64, ptr %slot29, align 8
  %op160 = add i64 %v159, 16
  store i64 %op160, ptr %slot30, align 8
  %v161 = load i64, ptr %slot30, align 8
  %p162 = inttoptr i64 %v161 to ptr
  %ld163 = load i64, ptr %p162, align 8, !alias.scope !4, !noalias !3
  store i64 %ld163, ptr %slot31, align 8
  %v164 = load i64, ptr %slot31, align 8
  %v165 = load i64, ptr %slot7, align 8
  %p166 = inttoptr i64 %v165 to ptr
  store i64 %v164, ptr %p166, align 8, !alias.scope !3, !noalias !4
  %v167 = load i64, ptr %slot6, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %ld169 = load i64, ptr %p168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld169, ptr %slot32, align 8
  %v170 = load i64, ptr %slot7, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %ld172 = load i64, ptr %p171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld172, ptr %slot33, align 8
  %v173 = load i64, ptr %slot32, align 8
  %p174 = inttoptr i64 %v173 to ptr
  %ld175 = load i64, ptr %p174, align 8, !alias.scope !6, !noalias !7
  store i64 %ld175, ptr %slot34, align 8
  %v176 = load i64, ptr %slot33, align 8
  %op177 = ashr i64 %v176, 63
  store i64 %op177, ptr %slot35, align 8
  %v178 = load i64, ptr %slot35, align 8
  %v179 = load i64, ptr %slot34, align 8
  %op180 = and i64 %v178, %v179
  store i64 %op180, ptr %slot36, align 8
  %v181 = load i64, ptr %slot33, align 8
  %v182 = load i64, ptr %slot36, align 8
  %op183 = add i64 %v181, %v182
  store i64 %op183, ptr %slot37, align 8
  %v184 = load i64, ptr %slot37, align 8
  %v185 = load i64, ptr %slot34, align 8
  %cmp186 = icmp ult i64 %v184, %v185
  %cv187 = zext i1 %cmp186 to i64
  store i64 %cv187, ptr %slot38, align 8
  %v188 = load i64, ptr %slot38, align 8
  %cond189 = icmp ne i64 %v188, 0
  br i1 %cond189, label %bb_success32, label %bb_failed32
bb_failed32:
  %v190 = load i64, ptr %slot1, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %v192 = load i64, ptr %slot33, align 8
  %v193 = load i64, ptr %slot34, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p191, i64 %v192, i64 %v193) nomerge, !dbg !110
  unreachable
bb_success32:
  %v194 = load i64, ptr %slot32, align 8
  %op195 = add i64 %v194, 32
  store i64 %op195, ptr %slot39, align 8
  %v196 = load i64, ptr %slot39, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !6, !noalias !7
  store i64 %ld198, ptr %slot40, align 8
  %v199 = load i64, ptr %slot40, align 8
  %v200 = load i64, ptr %slot37, align 8
  %op201 = add i64 %v199, %v200
  store i64 %op201, ptr %slot41, align 8
  %v202 = load i64, ptr %slot40, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %v204 = load i64, ptr %slot37, align 8
  %egep205 = getelementptr i8, ptr %p203, i64 %v204
  %ld206 = load i8, ptr %egep205, align 1, !alias.scope !12, !noalias !13
  %ext207 = zext i8 %ld206 to i64
  store i64 %ext207, ptr %slot42, align 8
  %v208 = load i64, ptr %slot42, align 8
  %v209 = load i64, ptr %slot6, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 %v208, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot6, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld213, ptr %slot43, align 8
  %v214 = load i64, ptr %slot43, align 8
  %v215 = load i64, ptr %slot6, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 %v214, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot6, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld219, ptr %slot44, align 8
  %v220 = load i64, ptr %slot44, align 8
  ret i64 %v220
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @myl_qbe_fail_index_bounds(ptr, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_27a3542393b8217ef7be2c940ab8ef189833f24bc415b497a3e940f6e2a55c7c", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_27a3542393b8217ef7be2c940ab8ef189833f24bc415b497a3e940f6e2a55c7c", linkageName: "myl_f_27a3542393b8217ef7be2c940ab8ef189833f24bc415b497a3e940f6e2a55c7c", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2355395030241119462, i64 0, !"myl_f_27a3542393b8217ef7be2c940ab8ef189833f24bc415b497a3e940f6e2a55c7c"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!110 = !DILocation(line: 17, column: 0, scope: !111)
