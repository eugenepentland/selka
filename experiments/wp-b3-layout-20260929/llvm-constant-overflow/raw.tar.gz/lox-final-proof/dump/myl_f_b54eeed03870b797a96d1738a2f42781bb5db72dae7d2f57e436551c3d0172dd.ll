target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i32, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i32, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i32, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i32, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i32, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i32, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i32, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i32, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i32, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i32, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i32, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i32, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i32, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i32, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i32, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i32, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i32, align 8
  %slot1172 = alloca i32, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i32, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i32, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i32, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i32, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i32, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i32, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i32, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i32, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i32, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i32, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i32, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i32, align 8
  %slot1232 = alloca i32, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i32, align 8
  %slot1253 = alloca i32, align 8
  %slot1254 = alloca i32, align 8
  %slot1255 = alloca i32, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i32, align 8
  %slot1261 = alloca i32, align 8
  %slot1262 = alloca i32, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i32, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i32, align 8
  %slot1270 = alloca i32, align 8
  %slot1271 = alloca i32, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i32, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i32, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i32, align 8
  %slot1285 = alloca i32, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i32, align 8
  %slot1288 = alloca i32, align 8
  %slot1289 = alloca i32, align 8
  %slot1290 = alloca i32, align 8
  %slot1291 = alloca i32, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i32, align 8
  %slot1294 = alloca i32, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i32, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i64, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i32, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i32, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i32, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i32, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i32, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i32, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i32, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i32, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i32, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i32, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i32, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i32, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1351 = load i64, ptr %slot1, align 8
  %op1352 = add i64 %v1351, 32
  store i64 %op1352, ptr %slot4, align 8
  %mem1353 = alloca i8, i64 16, align 8
  %ptr1354 = ptrtoint ptr %mem1353 to i64
  store i64 %ptr1354, ptr %slot5, align 8
  %mem1355 = alloca i8, i64 8, align 8
  %ptr1356 = ptrtoint ptr %mem1355 to i64
  store i64 %ptr1356, ptr %slot6, align 8
  %mem1357 = alloca i8, i64 8, align 8
  %ptr1358 = ptrtoint ptr %mem1357 to i64
  store i64 %ptr1358, ptr %slot7, align 8
  %mem1359 = alloca i8, i64 8, align 8
  %ptr1360 = ptrtoint ptr %mem1359 to i64
  store i64 %ptr1360, ptr %slot8, align 8
  %mem1361 = alloca i8, i64 8, align 8
  %ptr1362 = ptrtoint ptr %mem1361 to i64
  store i64 %ptr1362, ptr %slot9, align 8
  %mem1363 = alloca i8, i64 8, align 8
  %ptr1364 = ptrtoint ptr %mem1363 to i64
  store i64 %ptr1364, ptr %slot10, align 8
  %mem1365 = alloca i8, i64 8, align 8
  %ptr1366 = ptrtoint ptr %mem1365 to i64
  store i64 %ptr1366, ptr %slot11, align 8
  %mem1367 = alloca i8, i64 208, align 8
  %ptr1368 = ptrtoint ptr %mem1367 to i64
  store i64 %ptr1368, ptr %slot12, align 8
  %mem1369 = alloca i8, i64 8, align 8
  %ptr1370 = ptrtoint ptr %mem1369 to i64
  store i64 %ptr1370, ptr %slot13, align 8
  %mem1371 = alloca i8, i64 208, align 8
  %ptr1372 = ptrtoint ptr %mem1371 to i64
  store i64 %ptr1372, ptr %slot14, align 8
  %mem1373 = alloca i8, i64 8, align 8
  %ptr1374 = ptrtoint ptr %mem1373 to i64
  store i64 %ptr1374, ptr %slot15, align 8
  %mem1375 = alloca i8, i64 8, align 8
  %ptr1376 = ptrtoint ptr %mem1375 to i64
  store i64 %ptr1376, ptr %slot16, align 8
  %mem1377 = alloca i8, i64 8, align 8
  %ptr1378 = ptrtoint ptr %mem1377 to i64
  store i64 %ptr1378, ptr %slot17, align 8
  %mem1379 = alloca i8, i64 8, align 8
  %ptr1380 = ptrtoint ptr %mem1379 to i64
  store i64 %ptr1380, ptr %slot18, align 8
  %mem1381 = alloca i8, i64 16, align 8
  %ptr1382 = ptrtoint ptr %mem1381 to i64
  store i64 %ptr1382, ptr %slot19, align 8
  %mem1383 = alloca i8, i64 8, align 8
  %ptr1384 = ptrtoint ptr %mem1383 to i64
  store i64 %ptr1384, ptr %slot20, align 8
  %mem1385 = alloca i8, i64 8, align 8
  %ptr1386 = ptrtoint ptr %mem1385 to i64
  store i64 %ptr1386, ptr %slot21, align 8
  %mem1387 = alloca i8, i64 16, align 8
  %ptr1388 = ptrtoint ptr %mem1387 to i64
  store i64 %ptr1388, ptr %slot22, align 8
  %mem1389 = alloca i8, i64 16, align 8
  %ptr1390 = ptrtoint ptr %mem1389 to i64
  store i64 %ptr1390, ptr %slot23, align 8
  %mem1391 = alloca i8, i64 16, align 8
  %ptr1392 = ptrtoint ptr %mem1391 to i64
  store i64 %ptr1392, ptr %slot24, align 8
  %mem1393 = alloca i8, i64 16, align 8
  %ptr1394 = ptrtoint ptr %mem1393 to i64
  store i64 %ptr1394, ptr %slot25, align 8
  %mem1395 = alloca i8, i64 16, align 8
  %ptr1396 = ptrtoint ptr %mem1395 to i64
  store i64 %ptr1396, ptr %slot26, align 8
  %mem1397 = alloca i8, i64 16, align 8
  %ptr1398 = ptrtoint ptr %mem1397 to i64
  store i64 %ptr1398, ptr %slot27, align 8
  %mem1399 = alloca i8, i64 16, align 8
  %ptr1400 = ptrtoint ptr %mem1399 to i64
  store i64 %ptr1400, ptr %slot28, align 8
  %mem1401 = alloca i8, i64 16, align 8
  %ptr1402 = ptrtoint ptr %mem1401 to i64
  store i64 %ptr1402, ptr %slot29, align 8
  %mem1403 = alloca i8, i64 16, align 8
  %ptr1404 = ptrtoint ptr %mem1403 to i64
  store i64 %ptr1404, ptr %slot30, align 8
  %mem1405 = alloca i8, i64 16, align 8
  %ptr1406 = ptrtoint ptr %mem1405 to i64
  store i64 %ptr1406, ptr %slot31, align 8
  %v1407 = load i64, ptr %slot17, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  store i64 0, ptr %p1408, align 8, !alias.scope !3, !noalias !4
  %v1409 = load i64, ptr %slot2, align 8
  %v1410 = load i64, ptr %slot15, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  store i64 %v1409, ptr %p1411, align 8, !alias.scope !3, !noalias !4
  %v1412 = load i64, ptr %slot3, align 8
  %v1413 = load i64, ptr %slot16, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  store i64 %v1412, ptr %p1414, align 8, !alias.scope !3, !noalias !4
  %v1415 = load i64, ptr %slot1, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  %call1417 = call ptr @myl_qbe_heap(ptr %p1416) nomerge, !dbg !110
  %calladdr1418 = ptrtoint ptr %call1417 to i64
  store i64 %calladdr1418, ptr %slot32, align 8
  %v1419 = load i64, ptr %slot1, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %call1421 = call i64 @myl_qbe_region_mark(ptr %p1420) nomerge, !dbg !110
  store i64 %call1421, ptr %slot33, align 8
  %v1422 = load i64, ptr %slot6, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i32 0, ptr %p1423, align 4, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot7, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i32 0, ptr %p1425, align 4, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot8, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  store i32 0, ptr %p1427, align 4, !alias.scope !3, !noalias !4
  %v1428 = load i64, ptr %slot9, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  store i32 0, ptr %p1429, align 4, !alias.scope !3, !noalias !4
  %v1430 = load i64, ptr %slot10, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  store i32 0, ptr %p1431, align 4, !alias.scope !3, !noalias !4
  %v1432 = load i64, ptr %slot11, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  store i32 0, ptr %p1433, align 4, !alias.scope !3, !noalias !4
  %v1434 = load i64, ptr %slot6, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  store i32 2, ptr %p1435, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1436 = load i64, ptr %slot15, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  %ld1438 = load i64, ptr %p1437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1438, ptr %slot34, align 8
  %v1439 = load i64, ptr %slot34, align 8
  %v1440 = load i64, ptr %slot20, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  store i64 %v1439, ptr %p1441, align 8, !alias.scope !3, !noalias !4
  %v1442 = load i64, ptr %slot20, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  %ld1444 = load i64, ptr %p1443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1444, ptr %slot35, align 8
  %v1445 = load i64, ptr %slot35, align 8
  %op1446 = add i64 %v1445, 0
  store i64 %op1446, ptr %slot36, align 8
  %v1447 = load i64, ptr %slot36, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  %ld1449 = load i64, ptr %p1448, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1449, ptr %slot37, align 8
  %v1450 = load i64, ptr %slot37, align 8
  %v1451 = load i64, ptr %slot20, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  store i64 %v1450, ptr %p1452, align 8, !alias.scope !3, !noalias !4
  %v1453 = load i64, ptr %slot7, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  %ld1455 = load i32, ptr %p1454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1455, ptr %slot38, align 8
  %v1456 = load i32, ptr %slot38, align 8
  %cv1457 = zext i32 %v1456 to i64
  %cond1458 = icmp ne i64 %cv1457, 0
  br i1 %cond1458, label %bb_rcslotdrop9, label %bb_rcslotdone9
bb_rcslotdrop9:
  %v1459 = load i64, ptr %slot7, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  store i32 0, ptr %p1460, align 4, !alias.scope !3, !noalias !4
  %v1461 = load i64, ptr %slot12, align 8
  store i64 %v1461, ptr %slot39, align 8
  %v1462 = load i64, ptr %slot8, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %ld1464 = load i32, ptr %p1463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1464, ptr %slot40, align 8
  %v1465 = load i32, ptr %slot40, align 8
  %op1466 = and i32 %v1465, 28
  store i32 %op1466, ptr %slot41, align 8
  %v1467 = load i32, ptr %slot41, align 8
  %cv1468 = zext i32 %v1467 to i64
  %cond1469 = icmp ne i64 %cv1468, 0
  br i1 %cond1469, label %bb_rcslotrole9, label %bb_rcslotowner9
bb_rcslotrole9:
  %v1470 = load i64, ptr %slot32, align 8
  store i64 %v1470, ptr %slot42, align 8
  %v1471 = load i64, ptr %slot42, align 8
  %v1472 = load i64, ptr %slot39, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1471, i64 %v1472) nomerge, !dbg !112
  br label %bb_rcslotdone9
bb_rcslotowner9:
  %v1473 = load i64, ptr %slot32, align 8
  store i64 %v1473, ptr %slot43, align 8
  %v1474 = load i64, ptr %slot43, align 8
  %v1475 = load i64, ptr %slot39, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1474, i64 %v1475) nomerge, !dbg !112
  br label %bb_rcslotdone9
bb_rcslotdone9:
  %v1476 = load i64, ptr %slot20, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  %ld1478 = load i64, ptr %p1477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1478, ptr %slot44, align 8
  %v1479 = load i64, ptr %slot44, align 8
  %v1480 = load i64, ptr %slot17, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  store i64 %v1479, ptr %p1481, align 8, !alias.scope !3, !noalias !4
  %v1482 = load i64, ptr %slot16, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  %ld1484 = load i64, ptr %p1483, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1484, ptr %slot45, align 8
  %v1485 = load i64, ptr %slot45, align 8
  %v1486 = load i64, ptr %slot20, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  store i64 %v1485, ptr %p1487, align 8, !alias.scope !3, !noalias !4
  %v1488 = load i64, ptr %slot20, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  %ld1490 = load i64, ptr %p1489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1490, ptr %slot46, align 8
  %v1491 = load i64, ptr %slot46, align 8
  %v1492 = load i64, ptr %slot18, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  store i64 %v1491, ptr %p1493, align 8, !alias.scope !3, !noalias !4
  %v1494 = load i64, ptr %slot18, align 8
  %p1495 = inttoptr i64 %v1494 to ptr
  %ld1496 = load i64, ptr %p1495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1496, ptr %slot47, align 8
  %v1497 = load i64, ptr %slot47, align 8
  %v1498 = load i64, ptr %slot20, align 8
  %p1499 = inttoptr i64 %v1498 to ptr
  store i64 %v1497, ptr %p1499, align 8, !alias.scope !3, !noalias !4
  %v1500 = load i64, ptr %slot21, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  store i64 0, ptr %p1501, align 8, !alias.scope !3, !noalias !4
  %v1502 = load i64, ptr %slot21, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %ld1504 = load i64, ptr %p1503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1504, ptr %slot48, align 8
  %v1505 = load i64, ptr %slot20, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %ld1507 = load i64, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1507, ptr %slot49, align 8
  %v1508 = load i64, ptr %slot49, align 8
  %v1509 = load i64, ptr %slot48, align 8
  %cmp1510 = icmp slt i64 %v1508, %v1509
  %cv1511 = zext i1 %cmp1510 to i64
  store i64 %cv1511, ptr %slot50, align 8
  %v1512 = load i64, ptr %slot50, align 8
  %v1513 = load i64, ptr %slot20, align 8
  %p1514 = inttoptr i64 %v1513 to ptr
  store i64 %v1512, ptr %p1514, align 8, !alias.scope !3, !noalias !4
  %v1515 = load i64, ptr %slot20, align 8
  %p1516 = inttoptr i64 %v1515 to ptr
  %ld1517 = load i64, ptr %p1516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1517, ptr %slot51, align 8
  %v1518 = load i64, ptr %slot51, align 8
  %cond1519 = icmp ne i64 %v1518, 0
  br i1 %cond1519, label %bb_next24, label %bb_i14
bb_next24:
  %v1520 = load i64, ptr %slot17, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  %ld1522 = load i64, ptr %p1521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1522, ptr %slot52, align 8
  %v1523 = load i64, ptr %slot52, align 8
  %op1524 = add i64 %v1523, 0
  store i64 %op1524, ptr %slot53, align 8
  %v1525 = load i64, ptr %slot53, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %ld1527 = load i64, ptr %p1526, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1527, ptr %slot54, align 8
  %v1528 = load i64, ptr %slot54, align 8
  %v1529 = load i64, ptr %slot20, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  store i64 %v1528, ptr %p1530, align 8, !alias.scope !3, !noalias !4
  %v1531 = load i64, ptr %slot20, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  %ld1533 = load i64, ptr %p1532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1533, ptr %slot55, align 8
  %v1534 = load i64, ptr %slot55, align 8
  %cmp1535 = icmp ugt i64 %v1534, 9223372036854775807
  %cv1536 = zext i1 %cmp1535 to i64
  store i64 %cv1536, ptr %slot56, align 8
  %v1537 = load i64, ptr %slot56, align 8
  %cond1538 = icmp ne i64 %v1537, 0
  br i1 %cond1538, label %bb_cast_overflow29, label %bb_cast_ok29
bb_cast_overflow29:
  %v1539 = load i64, ptr %slot1, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  %v1541 = load i64, ptr %slot55, align 8
  call void @myl_qbe_fail_cast(ptr %p1540, i64 %v1541, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok29:
  %v1542 = load i64, ptr %slot55, align 8
  %v1543 = load i64, ptr %slot20, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  store i64 %v1542, ptr %p1544, align 8, !alias.scope !3, !noalias !4
  %v1545 = load i64, ptr %slot18, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  %ld1547 = load i64, ptr %p1546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1547, ptr %slot57, align 8
  %v1548 = load i64, ptr %slot57, align 8
  %v1549 = load i64, ptr %slot21, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  store i64 %v1548, ptr %p1550, align 8, !alias.scope !3, !noalias !4
  %v1551 = load i64, ptr %slot21, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %ld1553 = load i64, ptr %p1552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1553, ptr %slot58, align 8
  %v1554 = load i64, ptr %slot20, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  %ld1556 = load i64, ptr %p1555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1556, ptr %slot59, align 8
  %v1557 = load i64, ptr %slot59, align 8
  %v1558 = load i64, ptr %slot58, align 8
  %ovpair1560 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1557, i64 %v1558)
  %op1559 = extractvalue { i64, i1 } %ovpair1560, 0
  %ov1561 = extractvalue { i64, i1 } %ovpair1560, 1
  store i64 %op1559, ptr %slot60, align 8
  %v1562 = load i64, ptr %slot59, align 8
  %v1563 = load i64, ptr %slot60, align 8
  %op1564 = xor i64 %v1562, %v1563
  store i64 %op1564, ptr %slot61, align 8
  %v1565 = load i64, ptr %slot58, align 8
  %v1566 = load i64, ptr %slot60, align 8
  %op1567 = xor i64 %v1565, %v1566
  store i64 %op1567, ptr %slot62, align 8
  %v1568 = load i64, ptr %slot61, align 8
  %v1569 = load i64, ptr %slot62, align 8
  %op1570 = and i64 %v1568, %v1569
  store i64 %op1570, ptr %slot63, align 8
  %cv1571 = zext i1 %ov1561 to i64
  store i64 %cv1571, ptr %slot64, align 8
  %v1572 = load i64, ptr %slot64, align 8
  %cond1573 = icmp ne i64 %v1572, 0
  br i1 %cond1573, label %bb_overflow33, label %bb_checked33
bb_overflow33:
  %v1574 = load i64, ptr %slot1, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %v1576 = load i64, ptr %slot59, align 8
  %v1577 = load i64, ptr %slot58, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1575, i64 0, i64 %v1576, i64 %v1577, i64 64) nomerge, !dbg !116
  unreachable
bb_checked33:
  %v1578 = load i64, ptr %slot60, align 8
  %v1579 = load i64, ptr %slot20, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  store i64 %v1578, ptr %p1580, align 8, !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot20, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  %ld1583 = load i64, ptr %p1582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1583, ptr %slot65, align 8
  %v1584 = load i64, ptr %slot65, align 8
  %v1585 = load i64, ptr %slot18, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  store i64 %v1584, ptr %p1586, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v1587 = load i64, ptr %slot18, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  %ld1589 = load i64, ptr %p1588, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1589, ptr %slot66, align 8
  %v1590 = load i64, ptr %slot66, align 8
  %v1591 = load i64, ptr %slot20, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i64 %v1590, ptr %p1592, align 8, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot17, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  %ld1595 = load i64, ptr %p1594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1595, ptr %slot67, align 8
  %v1596 = load i64, ptr %slot20, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %ld1598 = load i64, ptr %p1597, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1598, ptr %slot68, align 8
  %v1599 = load i64, ptr %slot67, align 8
  %p1600 = inttoptr i64 %v1599 to ptr
  %ld1601 = load i64, ptr %p1600, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1601, ptr %slot69, align 8
  %v1602 = load i64, ptr %slot68, align 8
  %v1603 = load i64, ptr %slot69, align 8
  %cmp1604 = icmp ult i64 %v1602, %v1603
  %cv1605 = zext i1 %cmp1604 to i64
  store i64 %cv1605, ptr %slot70, align 8
  %v1606 = load i64, ptr %slot70, align 8
  %cond1607 = icmp ne i64 %v1606, 0
  br i1 %cond1607, label %bb_success45, label %bb_failed45
bb_failed45:
  %v1608 = load i64, ptr %slot1, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  %v1610 = load i64, ptr %slot68, align 8
  %v1611 = load i64, ptr %slot69, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1609, i64 %v1610, i64 %v1611) nomerge, !dbg !118
  unreachable
bb_success45:
  %v1612 = load i64, ptr %slot67, align 8
  %op1613 = add i64 %v1612, 32
  store i64 %op1613, ptr %slot71, align 8
  %v1614 = load i64, ptr %slot71, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  %ld1616 = load i64, ptr %p1615, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1616, ptr %slot72, align 8
  %v1617 = load i64, ptr %slot68, align 8
  %op1618 = mul i64 %v1617, 56
  store i64 %op1618, ptr %slot73, align 8
  %v1619 = load i64, ptr %slot72, align 8
  %v1620 = load i64, ptr %slot73, align 8
  %op1621 = add i64 %v1619, %v1620
  store i64 %op1621, ptr %slot74, align 8
  %v1622 = load i64, ptr %slot74, align 8
  %v1623 = load i64, ptr %slot20, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  store i64 %v1622, ptr %p1624, align 8, !alias.scope !3, !noalias !4
  %v1625 = load i64, ptr %slot20, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  %ld1627 = load i64, ptr %p1626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1627, ptr %slot75, align 8
  %v1628 = load i64, ptr %slot75, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  %ld1630 = load i32, ptr %p1629, align 4, !alias.scope !12, !noalias !13
  %ext1631 = zext i32 %ld1630 to i64
  store i64 %ext1631, ptr %slot76, align 8
  %v1632 = load i64, ptr %slot76, align 8
  %cmp1633 = icmp eq i64 %v1632, 0
  %cv1634 = zext i1 %cmp1633 to i64
  store i64 %cv1634, ptr %slot77, align 8
  %v1635 = load i64, ptr %slot77, align 8
  %cond1636 = icmp ne i64 %v1635, 0
  br i1 %cond1636, label %bb_rcarm52, label %bb_rcarmnext52
bb_rcarm52:
  %v1637 = load i64, ptr %slot7, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  %ld1639 = load i32, ptr %p1638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1639, ptr %slot78, align 8
  %v1640 = load i32, ptr %slot78, align 8
  %cv1641 = zext i32 %v1640 to i64
  %cond1642 = icmp ne i64 %cv1641, 0
  br i1 %cond1642, label %bb_rcslotdrop55, label %bb_rcslotdone55
bb_rcslotdrop55:
  %v1643 = load i64, ptr %slot7, align 8
  %p1644 = inttoptr i64 %v1643 to ptr
  store i32 0, ptr %p1644, align 4, !alias.scope !3, !noalias !4
  %v1645 = load i64, ptr %slot12, align 8
  store i64 %v1645, ptr %slot79, align 8
  %v1646 = load i64, ptr %slot8, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  %ld1648 = load i32, ptr %p1647, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1648, ptr %slot80, align 8
  %v1649 = load i32, ptr %slot80, align 8
  %op1650 = and i32 %v1649, 28
  store i32 %op1650, ptr %slot81, align 8
  %v1651 = load i32, ptr %slot81, align 8
  %cv1652 = zext i32 %v1651 to i64
  %cond1653 = icmp ne i64 %cv1652, 0
  br i1 %cond1653, label %bb_rcslotrole55, label %bb_rcslotowner55
bb_rcslotrole55:
  %v1654 = load i64, ptr %slot32, align 8
  store i64 %v1654, ptr %slot82, align 8
  %v1655 = load i64, ptr %slot82, align 8
  %v1656 = load i64, ptr %slot79, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1655, i64 %v1656) nomerge, !dbg !120
  br label %bb_rcslotdone55
bb_rcslotowner55:
  %v1657 = load i64, ptr %slot32, align 8
  store i64 %v1657, ptr %slot83, align 8
  %v1658 = load i64, ptr %slot83, align 8
  %v1659 = load i64, ptr %slot79, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1658, i64 %v1659) nomerge, !dbg !120
  br label %bb_rcslotdone55
bb_rcslotdone55:
  br label %bb_i19
bb_rcarmnext52:
  %v1660 = load i64, ptr %slot76, align 8
  %cmp1661 = icmp eq i64 %v1660, 1
  %cv1662 = zext i1 %cmp1661 to i64
  store i64 %cv1662, ptr %slot84, align 8
  %v1663 = load i64, ptr %slot84, align 8
  %cond1664 = icmp ne i64 %v1663, 0
  br i1 %cond1664, label %bb_rcarm62, label %bb_rcarmnext62
bb_rcarm62:
  %v1665 = load i64, ptr %slot75, align 8
  %op1666 = add i64 %v1665, 8
  store i64 %op1666, ptr %slot85, align 8
  %v1667 = load i64, ptr %slot85, align 8
  %v1668 = load i64, ptr %slot19, align 8
  %p1669 = inttoptr i64 %v1667 to ptr
  %p1670 = inttoptr i64 %v1668 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1670, ptr %p1669, i64 16, i1 false), !alias.scope !10000000
  %v1671 = load i64, ptr %slot7, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  %ld1673 = load i32, ptr %p1672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1673, ptr %slot86, align 8
  %v1674 = load i32, ptr %slot86, align 8
  %cv1675 = zext i32 %v1674 to i64
  %cond1676 = icmp ne i64 %cv1675, 0
  br i1 %cond1676, label %bb_rcslotdrop76, label %bb_rcslotdone76
bb_rcslotdrop76:
  %v1677 = load i64, ptr %slot7, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  store i32 0, ptr %p1678, align 4, !alias.scope !3, !noalias !4
  %v1679 = load i64, ptr %slot12, align 8
  store i64 %v1679, ptr %slot87, align 8
  %v1680 = load i64, ptr %slot8, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  %ld1682 = load i32, ptr %p1681, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1682, ptr %slot88, align 8
  %v1683 = load i32, ptr %slot88, align 8
  %op1684 = and i32 %v1683, 28
  store i32 %op1684, ptr %slot89, align 8
  %v1685 = load i32, ptr %slot89, align 8
  %cv1686 = zext i32 %v1685 to i64
  %cond1687 = icmp ne i64 %cv1686, 0
  br i1 %cond1687, label %bb_rcslotrole76, label %bb_rcslotowner76
bb_rcslotrole76:
  %v1688 = load i64, ptr %slot32, align 8
  store i64 %v1688, ptr %slot90, align 8
  %v1689 = load i64, ptr %slot90, align 8
  %v1690 = load i64, ptr %slot87, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1689, i64 %v1690) nomerge, !dbg !120
  br label %bb_rcslotdone76
bb_rcslotowner76:
  %v1691 = load i64, ptr %slot32, align 8
  store i64 %v1691, ptr %slot91, align 8
  %v1692 = load i64, ptr %slot91, align 8
  %v1693 = load i64, ptr %slot87, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1692, i64 %v1693) nomerge, !dbg !120
  br label %bb_rcslotdone76
bb_rcslotdone76:
  br label %bb_i17
bb_rcarmnext62:
  %v1694 = load i64, ptr %slot76, align 8
  %cmp1695 = icmp eq i64 %v1694, 2
  %cv1696 = zext i1 %cmp1695 to i64
  store i64 %cv1696, ptr %slot92, align 8
  %v1697 = load i64, ptr %slot92, align 8
  %cond1698 = icmp ne i64 %v1697, 0
  br i1 %cond1698, label %bb_rcarm83, label %bb_rcarmnext83
bb_rcarm83:
  %v1699 = load i64, ptr %slot7, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  %ld1701 = load i32, ptr %p1700, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1701, ptr %slot93, align 8
  %v1702 = load i32, ptr %slot93, align 8
  %cv1703 = zext i32 %v1702 to i64
  %cond1704 = icmp ne i64 %cv1703, 0
  br i1 %cond1704, label %bb_rcslotdrop86, label %bb_rcslotdone86
bb_rcslotdrop86:
  %v1705 = load i64, ptr %slot7, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  store i32 0, ptr %p1706, align 4, !alias.scope !3, !noalias !4
  %v1707 = load i64, ptr %slot12, align 8
  store i64 %v1707, ptr %slot94, align 8
  %v1708 = load i64, ptr %slot8, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  %ld1710 = load i32, ptr %p1709, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1710, ptr %slot95, align 8
  %v1711 = load i32, ptr %slot95, align 8
  %op1712 = and i32 %v1711, 28
  store i32 %op1712, ptr %slot96, align 8
  %v1713 = load i32, ptr %slot96, align 8
  %cv1714 = zext i32 %v1713 to i64
  %cond1715 = icmp ne i64 %cv1714, 0
  br i1 %cond1715, label %bb_rcslotrole86, label %bb_rcslotowner86
bb_rcslotrole86:
  %v1716 = load i64, ptr %slot32, align 8
  store i64 %v1716, ptr %slot97, align 8
  %v1717 = load i64, ptr %slot97, align 8
  %v1718 = load i64, ptr %slot94, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1717, i64 %v1718) nomerge, !dbg !120
  br label %bb_rcslotdone86
bb_rcslotowner86:
  %v1719 = load i64, ptr %slot32, align 8
  store i64 %v1719, ptr %slot98, align 8
  %v1720 = load i64, ptr %slot98, align 8
  %v1721 = load i64, ptr %slot94, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1720, i64 %v1721) nomerge, !dbg !120
  br label %bb_rcslotdone86
bb_rcslotdone86:
  br label %bb_i25
bb_rcarmnext83:
  %v1722 = load i64, ptr %slot76, align 8
  %cmp1723 = icmp eq i64 %v1722, 3
  %cv1724 = zext i1 %cmp1723 to i64
  store i64 %cv1724, ptr %slot99, align 8
  %v1725 = load i64, ptr %slot99, align 8
  %cond1726 = icmp ne i64 %v1725, 0
  br i1 %cond1726, label %bb_rcarm93, label %bb_rcarmnext93
bb_rcarm93:
  %v1727 = load i64, ptr %slot7, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  %ld1729 = load i32, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1729, ptr %slot100, align 8
  %v1730 = load i32, ptr %slot100, align 8
  %cv1731 = zext i32 %v1730 to i64
  %cond1732 = icmp ne i64 %cv1731, 0
  br i1 %cond1732, label %bb_rcslotdrop96, label %bb_rcslotdone96
bb_rcslotdrop96:
  %v1733 = load i64, ptr %slot7, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 0, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot12, align 8
  store i64 %v1735, ptr %slot101, align 8
  %v1736 = load i64, ptr %slot8, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %ld1738 = load i32, ptr %p1737, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1738, ptr %slot102, align 8
  %v1739 = load i32, ptr %slot102, align 8
  %op1740 = and i32 %v1739, 28
  store i32 %op1740, ptr %slot103, align 8
  %v1741 = load i32, ptr %slot103, align 8
  %cv1742 = zext i32 %v1741 to i64
  %cond1743 = icmp ne i64 %cv1742, 0
  br i1 %cond1743, label %bb_rcslotrole96, label %bb_rcslotowner96
bb_rcslotrole96:
  %v1744 = load i64, ptr %slot32, align 8
  store i64 %v1744, ptr %slot104, align 8
  %v1745 = load i64, ptr %slot104, align 8
  %v1746 = load i64, ptr %slot101, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1745, i64 %v1746) nomerge, !dbg !120
  br label %bb_rcslotdone96
bb_rcslotowner96:
  %v1747 = load i64, ptr %slot32, align 8
  store i64 %v1747, ptr %slot105, align 8
  %v1748 = load i64, ptr %slot105, align 8
  %v1749 = load i64, ptr %slot101, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1748, i64 %v1749) nomerge, !dbg !120
  br label %bb_rcslotdone96
bb_rcslotdone96:
  br label %bb_i31
bb_rcarmnext93:
  %v1750 = load i64, ptr %slot76, align 8
  %cmp1751 = icmp eq i64 %v1750, 4
  %cv1752 = zext i1 %cmp1751 to i64
  store i64 %cv1752, ptr %slot106, align 8
  %v1753 = load i64, ptr %slot106, align 8
  %cond1754 = icmp ne i64 %v1753, 0
  br i1 %cond1754, label %bb_rcarm103, label %bb_rcarmnext103
bb_rcarm103:
  %v1755 = load i64, ptr %slot7, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  %ld1757 = load i32, ptr %p1756, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1757, ptr %slot107, align 8
  %v1758 = load i32, ptr %slot107, align 8
  %cv1759 = zext i32 %v1758 to i64
  %cond1760 = icmp ne i64 %cv1759, 0
  br i1 %cond1760, label %bb_rcslotdrop106, label %bb_rcslotdone106
bb_rcslotdrop106:
  %v1761 = load i64, ptr %slot7, align 8
  %p1762 = inttoptr i64 %v1761 to ptr
  store i32 0, ptr %p1762, align 4, !alias.scope !3, !noalias !4
  %v1763 = load i64, ptr %slot12, align 8
  store i64 %v1763, ptr %slot108, align 8
  %v1764 = load i64, ptr %slot8, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  %ld1766 = load i32, ptr %p1765, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1766, ptr %slot109, align 8
  %v1767 = load i32, ptr %slot109, align 8
  %op1768 = and i32 %v1767, 28
  store i32 %op1768, ptr %slot110, align 8
  %v1769 = load i32, ptr %slot110, align 8
  %cv1770 = zext i32 %v1769 to i64
  %cond1771 = icmp ne i64 %cv1770, 0
  br i1 %cond1771, label %bb_rcslotrole106, label %bb_rcslotowner106
bb_rcslotrole106:
  %v1772 = load i64, ptr %slot32, align 8
  store i64 %v1772, ptr %slot111, align 8
  %v1773 = load i64, ptr %slot111, align 8
  %v1774 = load i64, ptr %slot108, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1773, i64 %v1774) nomerge, !dbg !120
  br label %bb_rcslotdone106
bb_rcslotowner106:
  %v1775 = load i64, ptr %slot32, align 8
  store i64 %v1775, ptr %slot112, align 8
  %v1776 = load i64, ptr %slot112, align 8
  %v1777 = load i64, ptr %slot108, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1776, i64 %v1777) nomerge, !dbg !120
  br label %bb_rcslotdone106
bb_rcslotdone106:
  br label %bb_i37
bb_rcarmnext103:
  %v1778 = load i64, ptr %slot76, align 8
  %cmp1779 = icmp eq i64 %v1778, 5
  %cv1780 = zext i1 %cmp1779 to i64
  store i64 %cv1780, ptr %slot113, align 8
  %v1781 = load i64, ptr %slot113, align 8
  %cond1782 = icmp ne i64 %v1781, 0
  br i1 %cond1782, label %bb_rcarm113, label %bb_rcarmnext113
bb_rcarm113:
  %v1783 = load i64, ptr %slot7, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  %ld1785 = load i32, ptr %p1784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1785, ptr %slot114, align 8
  %v1786 = load i32, ptr %slot114, align 8
  %cv1787 = zext i32 %v1786 to i64
  %cond1788 = icmp ne i64 %cv1787, 0
  br i1 %cond1788, label %bb_rcslotdrop116, label %bb_rcslotdone116
bb_rcslotdrop116:
  %v1789 = load i64, ptr %slot7, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  store i32 0, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  %v1791 = load i64, ptr %slot12, align 8
  store i64 %v1791, ptr %slot115, align 8
  %v1792 = load i64, ptr %slot8, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %ld1794 = load i32, ptr %p1793, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1794, ptr %slot116, align 8
  %v1795 = load i32, ptr %slot116, align 8
  %op1796 = and i32 %v1795, 28
  store i32 %op1796, ptr %slot117, align 8
  %v1797 = load i32, ptr %slot117, align 8
  %cv1798 = zext i32 %v1797 to i64
  %cond1799 = icmp ne i64 %cv1798, 0
  br i1 %cond1799, label %bb_rcslotrole116, label %bb_rcslotowner116
bb_rcslotrole116:
  %v1800 = load i64, ptr %slot32, align 8
  store i64 %v1800, ptr %slot118, align 8
  %v1801 = load i64, ptr %slot118, align 8
  %v1802 = load i64, ptr %slot115, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1801, i64 %v1802) nomerge, !dbg !120
  br label %bb_rcslotdone116
bb_rcslotowner116:
  %v1803 = load i64, ptr %slot32, align 8
  store i64 %v1803, ptr %slot119, align 8
  %v1804 = load i64, ptr %slot119, align 8
  %v1805 = load i64, ptr %slot115, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1804, i64 %v1805) nomerge, !dbg !120
  br label %bb_rcslotdone116
bb_rcslotdone116:
  br label %bb_i43
bb_rcarmnext113:
  %v1806 = load i64, ptr %slot76, align 8
  %cmp1807 = icmp eq i64 %v1806, 6
  %cv1808 = zext i1 %cmp1807 to i64
  store i64 %cv1808, ptr %slot120, align 8
  %v1809 = load i64, ptr %slot120, align 8
  %cond1810 = icmp ne i64 %v1809, 0
  br i1 %cond1810, label %bb_rcarm123, label %bb_rcarmnext123
bb_rcarm123:
  %v1811 = load i64, ptr %slot7, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %ld1813 = load i32, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1813, ptr %slot121, align 8
  %v1814 = load i32, ptr %slot121, align 8
  %cv1815 = zext i32 %v1814 to i64
  %cond1816 = icmp ne i64 %cv1815, 0
  br i1 %cond1816, label %bb_rcslotdrop126, label %bb_rcslotdone126
bb_rcslotdrop126:
  %v1817 = load i64, ptr %slot7, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i32 0, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot12, align 8
  store i64 %v1819, ptr %slot122, align 8
  %v1820 = load i64, ptr %slot8, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  %ld1822 = load i32, ptr %p1821, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1822, ptr %slot123, align 8
  %v1823 = load i32, ptr %slot123, align 8
  %op1824 = and i32 %v1823, 28
  store i32 %op1824, ptr %slot124, align 8
  %v1825 = load i32, ptr %slot124, align 8
  %cv1826 = zext i32 %v1825 to i64
  %cond1827 = icmp ne i64 %cv1826, 0
  br i1 %cond1827, label %bb_rcslotrole126, label %bb_rcslotowner126
bb_rcslotrole126:
  %v1828 = load i64, ptr %slot32, align 8
  store i64 %v1828, ptr %slot125, align 8
  %v1829 = load i64, ptr %slot125, align 8
  %v1830 = load i64, ptr %slot122, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1829, i64 %v1830) nomerge, !dbg !120
  br label %bb_rcslotdone126
bb_rcslotowner126:
  %v1831 = load i64, ptr %slot32, align 8
  store i64 %v1831, ptr %slot126, align 8
  %v1832 = load i64, ptr %slot126, align 8
  %v1833 = load i64, ptr %slot122, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1832, i64 %v1833) nomerge, !dbg !120
  br label %bb_rcslotdone126
bb_rcslotdone126:
  br label %bb_i49
bb_rcarmnext123:
  %v1834 = load i64, ptr %slot76, align 8
  %cmp1835 = icmp eq i64 %v1834, 7
  %cv1836 = zext i1 %cmp1835 to i64
  store i64 %cv1836, ptr %slot127, align 8
  %v1837 = load i64, ptr %slot127, align 8
  %cond1838 = icmp ne i64 %v1837, 0
  br i1 %cond1838, label %bb_rcarm133, label %bb_rcarmnext133
bb_rcarm133:
  %v1839 = load i64, ptr %slot7, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  %ld1841 = load i32, ptr %p1840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1841, ptr %slot128, align 8
  %v1842 = load i32, ptr %slot128, align 8
  %cv1843 = zext i32 %v1842 to i64
  %cond1844 = icmp ne i64 %cv1843, 0
  br i1 %cond1844, label %bb_rcslotdrop136, label %bb_rcslotdone136
bb_rcslotdrop136:
  %v1845 = load i64, ptr %slot7, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  store i32 0, ptr %p1846, align 4, !alias.scope !3, !noalias !4
  %v1847 = load i64, ptr %slot12, align 8
  store i64 %v1847, ptr %slot129, align 8
  %v1848 = load i64, ptr %slot8, align 8
  %p1849 = inttoptr i64 %v1848 to ptr
  %ld1850 = load i32, ptr %p1849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1850, ptr %slot130, align 8
  %v1851 = load i32, ptr %slot130, align 8
  %op1852 = and i32 %v1851, 28
  store i32 %op1852, ptr %slot131, align 8
  %v1853 = load i32, ptr %slot131, align 8
  %cv1854 = zext i32 %v1853 to i64
  %cond1855 = icmp ne i64 %cv1854, 0
  br i1 %cond1855, label %bb_rcslotrole136, label %bb_rcslotowner136
bb_rcslotrole136:
  %v1856 = load i64, ptr %slot32, align 8
  store i64 %v1856, ptr %slot132, align 8
  %v1857 = load i64, ptr %slot132, align 8
  %v1858 = load i64, ptr %slot129, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1857, i64 %v1858) nomerge, !dbg !120
  br label %bb_rcslotdone136
bb_rcslotowner136:
  %v1859 = load i64, ptr %slot32, align 8
  store i64 %v1859, ptr %slot133, align 8
  %v1860 = load i64, ptr %slot133, align 8
  %v1861 = load i64, ptr %slot129, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1860, i64 %v1861) nomerge, !dbg !120
  br label %bb_rcslotdone136
bb_rcslotdone136:
  br label %bb_i55
bb_rcarmnext133:
  %v1862 = load i64, ptr %slot76, align 8
  %cmp1863 = icmp eq i64 %v1862, 8
  %cv1864 = zext i1 %cmp1863 to i64
  store i64 %cv1864, ptr %slot134, align 8
  %v1865 = load i64, ptr %slot134, align 8
  %cond1866 = icmp ne i64 %v1865, 0
  br i1 %cond1866, label %bb_rcarm143, label %bb_rcarmnext143
bb_rcarm143:
  %v1867 = load i64, ptr %slot7, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  %ld1869 = load i32, ptr %p1868, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1869, ptr %slot135, align 8
  %v1870 = load i32, ptr %slot135, align 8
  %cv1871 = zext i32 %v1870 to i64
  %cond1872 = icmp ne i64 %cv1871, 0
  br i1 %cond1872, label %bb_rcslotdrop146, label %bb_rcslotdone146
bb_rcslotdrop146:
  %v1873 = load i64, ptr %slot7, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  store i32 0, ptr %p1874, align 4, !alias.scope !3, !noalias !4
  %v1875 = load i64, ptr %slot12, align 8
  store i64 %v1875, ptr %slot136, align 8
  %v1876 = load i64, ptr %slot8, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  %ld1878 = load i32, ptr %p1877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1878, ptr %slot137, align 8
  %v1879 = load i32, ptr %slot137, align 8
  %op1880 = and i32 %v1879, 28
  store i32 %op1880, ptr %slot138, align 8
  %v1881 = load i32, ptr %slot138, align 8
  %cv1882 = zext i32 %v1881 to i64
  %cond1883 = icmp ne i64 %cv1882, 0
  br i1 %cond1883, label %bb_rcslotrole146, label %bb_rcslotowner146
bb_rcslotrole146:
  %v1884 = load i64, ptr %slot32, align 8
  store i64 %v1884, ptr %slot139, align 8
  %v1885 = load i64, ptr %slot139, align 8
  %v1886 = load i64, ptr %slot136, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1885, i64 %v1886) nomerge, !dbg !120
  br label %bb_rcslotdone146
bb_rcslotowner146:
  %v1887 = load i64, ptr %slot32, align 8
  store i64 %v1887, ptr %slot140, align 8
  %v1888 = load i64, ptr %slot140, align 8
  %v1889 = load i64, ptr %slot136, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1888, i64 %v1889) nomerge, !dbg !120
  br label %bb_rcslotdone146
bb_rcslotdone146:
  br label %bb_i61
bb_rcarmnext143:
  %v1890 = load i64, ptr %slot76, align 8
  %cmp1891 = icmp eq i64 %v1890, 9
  %cv1892 = zext i1 %cmp1891 to i64
  store i64 %cv1892, ptr %slot141, align 8
  %v1893 = load i64, ptr %slot141, align 8
  %cond1894 = icmp ne i64 %v1893, 0
  br i1 %cond1894, label %bb_rcarm153, label %bb_rcarmnext153
bb_rcarm153:
  %v1895 = load i64, ptr %slot7, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  %ld1897 = load i32, ptr %p1896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1897, ptr %slot142, align 8
  %v1898 = load i32, ptr %slot142, align 8
  %cv1899 = zext i32 %v1898 to i64
  %cond1900 = icmp ne i64 %cv1899, 0
  br i1 %cond1900, label %bb_rcslotdrop156, label %bb_rcslotdone156
bb_rcslotdrop156:
  %v1901 = load i64, ptr %slot7, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  store i32 0, ptr %p1902, align 4, !alias.scope !3, !noalias !4
  %v1903 = load i64, ptr %slot12, align 8
  store i64 %v1903, ptr %slot143, align 8
  %v1904 = load i64, ptr %slot8, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  %ld1906 = load i32, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1906, ptr %slot144, align 8
  %v1907 = load i32, ptr %slot144, align 8
  %op1908 = and i32 %v1907, 28
  store i32 %op1908, ptr %slot145, align 8
  %v1909 = load i32, ptr %slot145, align 8
  %cv1910 = zext i32 %v1909 to i64
  %cond1911 = icmp ne i64 %cv1910, 0
  br i1 %cond1911, label %bb_rcslotrole156, label %bb_rcslotowner156
bb_rcslotrole156:
  %v1912 = load i64, ptr %slot32, align 8
  store i64 %v1912, ptr %slot146, align 8
  %v1913 = load i64, ptr %slot146, align 8
  %v1914 = load i64, ptr %slot143, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1913, i64 %v1914) nomerge, !dbg !120
  br label %bb_rcslotdone156
bb_rcslotowner156:
  %v1915 = load i64, ptr %slot32, align 8
  store i64 %v1915, ptr %slot147, align 8
  %v1916 = load i64, ptr %slot147, align 8
  %v1917 = load i64, ptr %slot143, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1916, i64 %v1917) nomerge, !dbg !120
  br label %bb_rcslotdone156
bb_rcslotdone156:
  br label %bb_i67
bb_rcarmnext153:
  %v1918 = load i64, ptr %slot76, align 8
  %cmp1919 = icmp eq i64 %v1918, 10
  %cv1920 = zext i1 %cmp1919 to i64
  store i64 %cv1920, ptr %slot148, align 8
  %v1921 = load i64, ptr %slot148, align 8
  %cond1922 = icmp ne i64 %v1921, 0
  br i1 %cond1922, label %bb_rcarm163, label %bb_rcarmnext163
bb_rcarm163:
  %v1923 = load i64, ptr %slot7, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  %ld1925 = load i32, ptr %p1924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1925, ptr %slot149, align 8
  %v1926 = load i32, ptr %slot149, align 8
  %cv1927 = zext i32 %v1926 to i64
  %cond1928 = icmp ne i64 %cv1927, 0
  br i1 %cond1928, label %bb_rcslotdrop166, label %bb_rcslotdone166
bb_rcslotdrop166:
  %v1929 = load i64, ptr %slot7, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  store i32 0, ptr %p1930, align 4, !alias.scope !3, !noalias !4
  %v1931 = load i64, ptr %slot12, align 8
  store i64 %v1931, ptr %slot150, align 8
  %v1932 = load i64, ptr %slot8, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  %ld1934 = load i32, ptr %p1933, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1934, ptr %slot151, align 8
  %v1935 = load i32, ptr %slot151, align 8
  %op1936 = and i32 %v1935, 28
  store i32 %op1936, ptr %slot152, align 8
  %v1937 = load i32, ptr %slot152, align 8
  %cv1938 = zext i32 %v1937 to i64
  %cond1939 = icmp ne i64 %cv1938, 0
  br i1 %cond1939, label %bb_rcslotrole166, label %bb_rcslotowner166
bb_rcslotrole166:
  %v1940 = load i64, ptr %slot32, align 8
  store i64 %v1940, ptr %slot153, align 8
  %v1941 = load i64, ptr %slot153, align 8
  %v1942 = load i64, ptr %slot150, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1941, i64 %v1942) nomerge, !dbg !120
  br label %bb_rcslotdone166
bb_rcslotowner166:
  %v1943 = load i64, ptr %slot32, align 8
  store i64 %v1943, ptr %slot154, align 8
  %v1944 = load i64, ptr %slot154, align 8
  %v1945 = load i64, ptr %slot150, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1944, i64 %v1945) nomerge, !dbg !120
  br label %bb_rcslotdone166
bb_rcslotdone166:
  br label %bb_i73
bb_rcarmnext163:
  br label %bb_failure
bb_i17:
  %v1946 = load i64, ptr %slot19, align 8
  %v1947 = load i64, ptr %slot20, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  store i64 %v1946, ptr %p1948, align 8, !alias.scope !3, !noalias !4
  %v1949 = load i64, ptr %slot20, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %ld1951 = load i64, ptr %p1950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1951, ptr %slot155, align 8
  %v1952 = load i64, ptr %slot19, align 8
  store i64 %v1952, ptr %slot156, align 8
  store i32 0, ptr %slot157, align 8
  %v1953 = load i64, ptr %slot6, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  %ld1955 = load i32, ptr %p1954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1955, ptr %slot158, align 8
  %v1956 = load i32, ptr %slot158, align 8
  %op1957 = and i32 %v1956, 24
  store i32 %op1957, ptr %slot158, align 8
  %v1958 = load i32, ptr %slot158, align 8
  %cmp1959 = icmp eq i32 %v1958, 0
  %cv1960 = zext i1 %cmp1959 to i32
  store i32 %cv1960, ptr %slot159, align 8
  %v1961 = load i32, ptr %slot157, align 8
  %v1962 = load i32, ptr %slot159, align 8
  %op1963 = and i32 %v1961, %v1962
  store i32 %op1963, ptr %slot160, align 8
  %v1964 = load i32, ptr %slot160, align 8
  %cv1965 = zext i32 %v1964 to i64
  %cond1966 = icmp ne i64 %cv1965, 0
  br i1 %cond1966, label %bb_rctake175, label %bb_rccopy175
bb_rctake175:
  %v1967 = load i64, ptr %slot14, align 8
  store i64 %v1967, ptr %slot161, align 8
  %v1968 = load i64, ptr %slot33, align 8
  store i64 %v1968, ptr %slot162, align 8
  %v1969 = load i64, ptr %slot156, align 8
  %v1970 = load i64, ptr %slot161, align 8
  %op1971 = sub i64 %v1969, %v1970
  store i64 %op1971, ptr %slot163, align 8
  %v1972 = load i64, ptr %slot161, align 8
  %v1973 = load i64, ptr %slot156, align 8
  %op1974 = sub i64 %v1972, %v1973
  store i64 %op1974, ptr %slot164, align 8
  %v1975 = load i64, ptr %slot163, align 8
  %cmp1976 = icmp ult i64 %v1975, 16
  %cv1977 = zext i1 %cmp1976 to i32
  store i32 %cv1977, ptr %slot165, align 8
  %v1978 = load i64, ptr %slot164, align 8
  %cmp1979 = icmp ult i64 %v1978, 16
  %cv1980 = zext i1 %cmp1979 to i32
  store i32 %cv1980, ptr %slot166, align 8
  %v1981 = load i32, ptr %slot165, align 8
  %v1982 = load i32, ptr %slot166, align 8
  %op1983 = or i32 %v1981, %v1982
  store i32 %op1983, ptr %slot167, align 8
  %v1984 = load i32, ptr %slot167, align 8
  %cv1985 = zext i32 %v1984 to i64
  %cond1986 = icmp ne i64 %cv1985, 0
  br i1 %cond1986, label %bb_rcmoveslow184, label %bb_rcmovecheck184
bb_rcmovecheck184:
  %v1987 = load i64, ptr %slot156, align 8
  %p1989 = inttoptr i64 %v1987 to ptr
  %gep1990 = getelementptr i8, ptr %p1989, i64 0
  %op1988 = ptrtoint ptr %gep1990 to i64
  store i64 %op1988, ptr %slot168, align 8
  %v1991 = load i64, ptr %slot168, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  %ld1993 = load i64, ptr %p1992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1993, ptr %slot169, align 8
  %v1994 = load i64, ptr %slot169, align 8
  %cmp1995 = icmp ne i64 %v1994, 0
  %cv1996 = zext i1 %cmp1995 to i32
  store i32 %cv1996, ptr %slot170, align 8
  %v1997 = load i32, ptr %slot170, align 8
  %cv1998 = zext i32 %v1997 to i64
  %cond1999 = icmp ne i64 %cv1998, 0
  br i1 %cond1999, label %bb_rcmoveheader192, label %bb_rcmovenext192
bb_rcmoveheader192:
  %v2000 = load i64, ptr %slot169, align 8
  %op2001 = sub i64 %v2000, 16
  store i64 %op2001, ptr %slot171, align 8
  %v2002 = load i64, ptr %slot169, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %rgep2004 = getelementptr i8, ptr %p2003, i64 -16
  %ld2005 = load i64, ptr %rgep2004, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2005, ptr %slot172, align 8
  %v2006 = load i64, ptr %slot172, align 8
  %op2007 = and i64 %v2006, 5764607523034234881
  store i64 %op2007, ptr %slot173, align 8
  %v2008 = load i64, ptr %slot173, align 8
  %cmp2009 = icmp ne i64 %v2008, 0
  %cv2010 = zext i1 %cmp2009 to i32
  store i32 %cv2010, ptr %slot174, align 8
  %v2011 = load i32, ptr %slot174, align 8
  %cv2012 = zext i32 %v2011 to i64
  %cond2013 = icmp ne i64 %cv2012, 0
  br i1 %cond2013, label %bb_rcmoveslow184, label %bb_rcmovenext192
bb_rcmovenext192:
  %v2014 = load i64, ptr %slot156, align 8
  %v2015 = load i64, ptr %slot161, align 8
  %p2016 = inttoptr i64 %v2014 to ptr
  %p2017 = inttoptr i64 %v2015 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2017, ptr %p2016, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2018 = load i64, ptr %slot156, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i64 0, ptr %p2019, align 8, !alias.scope !3, !noalias !4
  %v2020 = load i64, ptr %slot156, align 8
  %p2022 = inttoptr i64 %v2020 to ptr
  %gep2023 = getelementptr i8, ptr %p2022, i64 8
  %op2021 = ptrtoint ptr %gep2023 to i64
  store i64 %op2021, ptr %slot175, align 8
  %v2024 = load i64, ptr %slot175, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  store i64 0, ptr %p2025, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved184
bb_rcmoveslow184:
  %v2026 = load i64, ptr %slot32, align 8
  %v2027 = load i64, ptr %slot161, align 8
  %v2028 = load i64, ptr %slot156, align 8
  %v2029 = load i64, ptr %slot162, align 8
  %cv2030 = trunc i64 %v2029 to i32
  %call2031 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v2026, i64 %v2027, i64 %v2028, i32 %cv2030) nomerge, !dbg !122
  store i32 %call2031, ptr %slot176, align 8
  %v2032 = load i32, ptr %slot176, align 8
  %cv2033 = zext i32 %v2032 to i64
  %cond2034 = icmp ne i64 %cv2033, 0
  br i1 %cond2034, label %bb_rcsuccess200, label %bb_rcfailure200
bb_rcfailure200:
  %v2035 = load i64, ptr %slot32, align 8
  %p2036 = inttoptr i64 %v2035 to ptr
  %call2037 = call i32 @myl_rc_take_failure(ptr %p2036) nomerge, !dbg !122
  store i32 %call2037, ptr %slot177, align 8
  %v2038 = load i64, ptr %slot1, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  %v2040 = load i32, ptr %slot177, align 8
  %call2041 = call i32 @myl_qbe_rc_status(ptr %p2039, i32 %v2040) nomerge, !dbg !122
  store i32 %call2041, ptr %slot178, align 8
  br label %bb_failure
bb_rcsuccess200:
  br label %bb_rcmoved184
bb_rcmoved184:
  %v2042 = load i64, ptr %slot10, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  store i32 2, ptr %p2043, align 4, !alias.scope !3, !noalias !4
  %v2044 = load i64, ptr %slot9, align 8
  %p2045 = inttoptr i64 %v2044 to ptr
  store i32 1, ptr %p2045, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared175
bb_rccopy175:
  %v2046 = load i64, ptr %slot14, align 8
  store i64 %v2046, ptr %slot179, align 8
  %v2047 = load i64, ptr %slot33, align 8
  store i64 %v2047, ptr %slot180, align 8
  %v2048 = load i64, ptr %slot32, align 8
  %v2049 = load i64, ptr %slot179, align 8
  %v2050 = load i64, ptr %slot156, align 8
  %v2051 = load i64, ptr %slot180, align 8
  %cv2052 = trunc i64 %v2051 to i32
  %call2053 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_retain(i64 %v2048, i64 %v2049, i64 %v2050, i32 %cv2052) nomerge, !dbg !122
  store i32 %call2053, ptr %slot181, align 8
  %v2054 = load i32, ptr %slot181, align 8
  %cv2055 = zext i32 %v2054 to i64
  %cond2056 = icmp ne i64 %cv2055, 0
  br i1 %cond2056, label %bb_rcsuccess209, label %bb_rcfailure209
bb_rcfailure209:
  %v2057 = load i64, ptr %slot32, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %call2059 = call i32 @myl_rc_take_failure(ptr %p2058) nomerge, !dbg !122
  store i32 %call2059, ptr %slot182, align 8
  %v2060 = load i64, ptr %slot1, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %v2062 = load i32, ptr %slot182, align 8
  %call2063 = call i32 @myl_qbe_rc_status(ptr %p2061, i32 %v2062) nomerge, !dbg !122
  store i32 %call2063, ptr %slot183, align 8
  br label %bb_failure
bb_rcsuccess209:
  %v2064 = load i64, ptr %slot10, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  store i32 2, ptr %p2065, align 4, !alias.scope !3, !noalias !4
  %v2066 = load i64, ptr %slot9, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  store i32 1, ptr %p2067, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared175
bb_rcprepared175:
  %v2068 = load i64, ptr %slot14, align 8
  store i64 %v2068, ptr %slot184, align 8
  %v2069 = load i64, ptr %slot9, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  store i32 0, ptr %p2070, align 4, !alias.scope !3, !noalias !4
  %v2071 = load i64, ptr %slot7, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  %ld2073 = load i32, ptr %p2072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2073, ptr %slot185, align 8
  %v2074 = load i32, ptr %slot185, align 8
  %cv2075 = zext i32 %v2074 to i64
  %cond2076 = icmp ne i64 %cv2075, 0
  br i1 %cond2076, label %bb_rcslotdrop227, label %bb_rcslotdone227
bb_rcslotdrop227:
  %v2077 = load i64, ptr %slot7, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  store i32 0, ptr %p2078, align 4, !alias.scope !3, !noalias !4
  %v2079 = load i64, ptr %slot12, align 8
  store i64 %v2079, ptr %slot186, align 8
  %v2080 = load i64, ptr %slot8, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  %ld2082 = load i32, ptr %p2081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2082, ptr %slot187, align 8
  %v2083 = load i32, ptr %slot187, align 8
  %op2084 = and i32 %v2083, 28
  store i32 %op2084, ptr %slot188, align 8
  %v2085 = load i32, ptr %slot188, align 8
  %cv2086 = zext i32 %v2085 to i64
  %cond2087 = icmp ne i64 %cv2086, 0
  br i1 %cond2087, label %bb_rcslotrole227, label %bb_rcslotowner227
bb_rcslotrole227:
  %v2088 = load i64, ptr %slot32, align 8
  store i64 %v2088, ptr %slot189, align 8
  %v2089 = load i64, ptr %slot189, align 8
  %v2090 = load i64, ptr %slot186, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v2089, i64 %v2090) nomerge, !dbg !122
  br label %bb_rcslotdone227
bb_rcslotowner227:
  %v2091 = load i64, ptr %slot32, align 8
  store i64 %v2091, ptr %slot190, align 8
  %v2092 = load i64, ptr %slot190, align 8
  %v2093 = load i64, ptr %slot186, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v2092, i64 %v2093) nomerge, !dbg !122
  br label %bb_rcslotdone227
bb_rcslotdone227:
  %v2094 = load i64, ptr %slot184, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  %ret2096 = load { i64, i64 }, ptr %p2095, align 8
  ret { i64, i64 } %ret2096
bb_i19:
  %v2097 = load i64, ptr %slot20, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  store i64 0, ptr %p2098, align 8, !alias.scope !3, !noalias !4
  %v2099 = load i64, ptr %slot20, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  %ld2101 = load i64, ptr %p2100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2101, ptr %slot191, align 8
  %v2102 = load i64, ptr %slot191, align 8
  %cond2103 = icmp ne i64 %v2102, 0
  br i1 %cond2103, label %bb_success290, label %bb_failed290
bb_failed290:
  %v2104 = load i64, ptr %slot1, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  call void @myl_qbe_fail_assert(ptr %p2105) nomerge, !dbg !124
  unreachable
bb_success290:
  %p2106 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld2107 = load i64, ptr %p2106, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2107, ptr %slot192, align 8
  %v2108 = load i64, ptr %slot192, align 8
  %v2109 = load i64, ptr %slot20, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  store i64 %v2108, ptr %p2110, align 8, !alias.scope !3, !noalias !4
  %v2111 = load i64, ptr %slot20, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  %ld2113 = load i64, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2113, ptr %slot193, align 8
  %v2114 = load i64, ptr %slot193, align 8
  %v2115 = load i64, ptr %slot13, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i64 %v2114, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot13, align 8
  store i64 %v2117, ptr %slot194, align 8
  %v2118 = load i64, ptr %slot14, align 8
  store i64 %v2118, ptr %slot195, align 8
  %v2119 = load i64, ptr %slot194, align 8
  %v2120 = load i64, ptr %slot195, align 8
  %p2121 = inttoptr i64 %v2119 to ptr
  %p2122 = inttoptr i64 %v2120 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2122, ptr %p2121, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2123 = load i64, ptr %slot10, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  store i32 2, ptr %p2124, align 4, !alias.scope !3, !noalias !4
  %v2125 = load i64, ptr %slot9, align 8
  %p2126 = inttoptr i64 %v2125 to ptr
  store i32 1, ptr %p2126, align 4, !alias.scope !3, !noalias !4
  %v2127 = load i64, ptr %slot12, align 8
  store i64 %v2127, ptr %slot196, align 8
  %v2128 = load i64, ptr %slot14, align 8
  store i64 %v2128, ptr %slot197, align 8
  %v2129 = load i64, ptr %slot197, align 8
  %v2130 = load i64, ptr %slot196, align 8
  %p2131 = inttoptr i64 %v2129 to ptr
  %p2132 = inttoptr i64 %v2130 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2132, ptr %p2131, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2133 = load i64, ptr %slot8, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  store i32 2, ptr %p2134, align 4, !alias.scope !3, !noalias !4
  %v2135 = load i64, ptr %slot10, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  %ld2137 = load i32, ptr %p2136, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2137, ptr %slot198, align 8
  %v2138 = load i32, ptr %slot198, align 8
  %v2139 = load i64, ptr %slot8, align 8
  %p2140 = inttoptr i64 %v2139 to ptr
  store i32 %v2138, ptr %p2140, align 4, !alias.scope !3, !noalias !4
  %v2141 = load i64, ptr %slot9, align 8
  %p2142 = inttoptr i64 %v2141 to ptr
  store i32 0, ptr %p2142, align 4, !alias.scope !3, !noalias !4
  %v2143 = load i64, ptr %slot7, align 8
  %p2144 = inttoptr i64 %v2143 to ptr
  store i32 1, ptr %p2144, align 4, !alias.scope !3, !noalias !4
  %v2145 = load i64, ptr %slot196, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  %ld2147 = load i64, ptr %p2146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2147, ptr %slot199, align 8
  %v2148 = load i64, ptr %slot199, align 8
  %v2149 = load i64, ptr %slot20, align 8
  %p2150 = inttoptr i64 %v2149 to ptr
  store i64 %v2148, ptr %p2150, align 8, !alias.scope !3, !noalias !4
  %v2151 = load i64, ptr %slot21, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i64 0, ptr %p2152, align 8, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot22, align 8
  store i64 %v2153, ptr %slot200, align 8
  %v2154 = load i64, ptr %slot200, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  store i64 0, ptr %p2155, align 8, !alias.scope !3, !noalias !4
  %v2156 = load i64, ptr %slot200, align 8
  %p2158 = inttoptr i64 %v2156 to ptr
  %gep2159 = getelementptr i8, ptr %p2158, i64 8
  %op2157 = ptrtoint ptr %gep2159 to i64
  store i64 %op2157, ptr %slot201, align 8
  %v2160 = load i64, ptr %slot201, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  store i64 0, ptr %p2161, align 8, !alias.scope !3, !noalias !4
  %v2162 = load i64, ptr %slot11, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  store i32 1, ptr %p2163, align 4, !alias.scope !3, !noalias !4
  %v2164 = load i64, ptr %slot33, align 8
  store i64 %v2164, ptr %slot202, align 8
  %v2165 = load i64, ptr %slot20, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %ld2167 = load i64, ptr %p2166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2167, ptr %slot203, align 8
  %v2168 = load i64, ptr %slot203, align 8
  %v2169 = load i64, ptr %slot13, align 8
  %p2170 = inttoptr i64 %v2169 to ptr
  store i64 %v2168, ptr %p2170, align 8, !alias.scope !3, !noalias !4
  %v2171 = load i64, ptr %slot13, align 8
  store i64 %v2171, ptr %slot204, align 8
  %v2172 = load i64, ptr %slot200, align 8
  %p2174 = inttoptr i64 %v2172 to ptr
  %gep2175 = getelementptr i8, ptr %p2174, i64 0
  %op2173 = ptrtoint ptr %gep2175 to i64
  store i64 %op2173, ptr %slot205, align 8
  %v2176 = load i64, ptr %slot20, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i64, ptr %p2177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2178, ptr %slot206, align 8
  %v2179 = load i64, ptr %slot206, align 8
  %v2180 = load i64, ptr %slot13, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i64 %v2179, ptr %p2181, align 8, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot13, align 8
  store i64 %v2182, ptr %slot207, align 8
  %v2183 = load i64, ptr %slot7, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  %ld2185 = load i32, ptr %p2184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2185, ptr %slot208, align 8
  %v2186 = load i64, ptr %slot8, align 8
  %p2187 = inttoptr i64 %v2186 to ptr
  %ld2188 = load i32, ptr %p2187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2188, ptr %slot209, align 8
  %v2189 = load i32, ptr %slot209, align 8
  %op2190 = and i32 %v2189, 24
  store i32 %op2190, ptr %slot209, align 8
  %v2191 = load i32, ptr %slot209, align 8
  %cmp2192 = icmp eq i32 %v2191, 0
  %cv2193 = zext i1 %cmp2192 to i32
  store i32 %cv2193, ptr %slot210, align 8
  %v2194 = load i32, ptr %slot208, align 8
  %v2195 = load i32, ptr %slot210, align 8
  %op2196 = and i32 %v2194, %v2195
  store i32 %op2196, ptr %slot211, align 8
  %v2197 = load i32, ptr %slot211, align 8
  %cv2198 = zext i32 %v2197 to i64
  %cond2199 = icmp ne i64 %cv2198, 0
  br i1 %cond2199, label %bb_rctake317, label %bb_rccopy317
bb_rctake317:
  %v2200 = load i64, ptr %slot14, align 8
  store i64 %v2200, ptr %slot212, align 8
  %v2201 = load i64, ptr %slot33, align 8
  store i64 %v2201, ptr %slot213, align 8
  %v2202 = load i64, ptr %slot207, align 8
  %v2203 = load i64, ptr %slot212, align 8
  %op2204 = sub i64 %v2202, %v2203
  store i64 %op2204, ptr %slot214, align 8
  %v2205 = load i64, ptr %slot212, align 8
  %v2206 = load i64, ptr %slot207, align 8
  %op2207 = sub i64 %v2205, %v2206
  store i64 %op2207, ptr %slot215, align 8
  %v2208 = load i64, ptr %slot214, align 8
  %cmp2209 = icmp ult i64 %v2208, 8
  %cv2210 = zext i1 %cmp2209 to i32
  store i32 %cv2210, ptr %slot216, align 8
  %v2211 = load i64, ptr %slot215, align 8
  %cmp2212 = icmp ult i64 %v2211, 8
  %cv2213 = zext i1 %cmp2212 to i32
  store i32 %cv2213, ptr %slot217, align 8
  %v2214 = load i32, ptr %slot216, align 8
  %v2215 = load i32, ptr %slot217, align 8
  %op2216 = or i32 %v2214, %v2215
  store i32 %op2216, ptr %slot218, align 8
  %v2217 = load i32, ptr %slot218, align 8
  %cv2218 = zext i32 %v2217 to i64
  %cond2219 = icmp ne i64 %cv2218, 0
  br i1 %cond2219, label %bb_rcmoveslow326, label %bb_rcmovecheck326
bb_rcmovecheck326:
  %v2220 = load i64, ptr %slot207, align 8
  %p2222 = inttoptr i64 %v2220 to ptr
  %gep2223 = getelementptr i8, ptr %p2222, i64 0
  %op2221 = ptrtoint ptr %gep2223 to i64
  store i64 %op2221, ptr %slot219, align 8
  %v2224 = load i64, ptr %slot219, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %ld2226 = load i64, ptr %p2225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2226, ptr %slot220, align 8
  %v2227 = load i64, ptr %slot220, align 8
  %cmp2228 = icmp ne i64 %v2227, 0
  %cv2229 = zext i1 %cmp2228 to i32
  store i32 %cv2229, ptr %slot221, align 8
  %v2230 = load i32, ptr %slot221, align 8
  %cv2231 = zext i32 %v2230 to i64
  %cond2232 = icmp ne i64 %cv2231, 0
  br i1 %cond2232, label %bb_rcmoveheader334, label %bb_rcmovenext334
bb_rcmoveheader334:
  %v2233 = load i64, ptr %slot220, align 8
  %op2234 = sub i64 %v2233, 16
  store i64 %op2234, ptr %slot222, align 8
  %v2235 = load i64, ptr %slot220, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %rgep2237 = getelementptr i8, ptr %p2236, i64 -16
  %ld2238 = load i64, ptr %rgep2237, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2238, ptr %slot223, align 8
  %v2239 = load i64, ptr %slot223, align 8
  %op2240 = and i64 %v2239, 5764607523034234881
  store i64 %op2240, ptr %slot224, align 8
  %v2241 = load i64, ptr %slot224, align 8
  %cmp2242 = icmp ne i64 %v2241, 0
  %cv2243 = zext i1 %cmp2242 to i32
  store i32 %cv2243, ptr %slot225, align 8
  %v2244 = load i32, ptr %slot225, align 8
  %cv2245 = zext i32 %v2244 to i64
  %cond2246 = icmp ne i64 %cv2245, 0
  br i1 %cond2246, label %bb_rcmoveslow326, label %bb_rcmovenext334
bb_rcmovenext334:
  %v2247 = load i64, ptr %slot207, align 8
  %v2248 = load i64, ptr %slot212, align 8
  %p2249 = inttoptr i64 %v2247 to ptr
  %p2250 = inttoptr i64 %v2248 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2250, ptr %p2249, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2251 = load i64, ptr %slot207, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i64 0, ptr %p2252, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved326
bb_rcmoveslow326:
  %v2253 = load i64, ptr %slot32, align 8
  %v2254 = load i64, ptr %slot212, align 8
  %v2255 = load i64, ptr %slot207, align 8
  %v2256 = load i64, ptr %slot213, align 8
  %cv2257 = trunc i64 %v2256 to i32
  %call2258 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2253, i64 %v2254, i64 %v2255, i32 %cv2257) nomerge, !dbg !126
  store i32 %call2258, ptr %slot226, align 8
  %v2259 = load i32, ptr %slot226, align 8
  %cv2260 = zext i32 %v2259 to i64
  %cond2261 = icmp ne i64 %cv2260, 0
  br i1 %cond2261, label %bb_rcsuccess341, label %bb_rcfailure341
bb_rcfailure341:
  %v2262 = load i64, ptr %slot32, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  %call2264 = call i32 @myl_rc_take_failure(ptr %p2263) nomerge, !dbg !126
  store i32 %call2264, ptr %slot227, align 8
  %v2265 = load i64, ptr %slot1, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  %v2267 = load i32, ptr %slot227, align 8
  %call2268 = call i32 @myl_qbe_rc_status(ptr %p2266, i32 %v2267) nomerge, !dbg !126
  store i32 %call2268, ptr %slot228, align 8
  br label %bb_failure
bb_rcsuccess341:
  br label %bb_rcmoved326
bb_rcmoved326:
  %v2269 = load i64, ptr %slot7, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  store i32 0, ptr %p2270, align 4, !alias.scope !3, !noalias !4
  %v2271 = load i64, ptr %slot10, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  store i32 2, ptr %p2272, align 4, !alias.scope !3, !noalias !4
  %v2273 = load i64, ptr %slot9, align 8
  %p2274 = inttoptr i64 %v2273 to ptr
  store i32 1, ptr %p2274, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared317
bb_rccopy317:
  %v2275 = load i64, ptr %slot14, align 8
  store i64 %v2275, ptr %slot229, align 8
  %v2276 = load i64, ptr %slot33, align 8
  store i64 %v2276, ptr %slot230, align 8
  %v2277 = load i64, ptr %slot207, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %ld2279 = load i64, ptr %p2278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2279, ptr %slot231, align 8
  %v2280 = load i64, ptr %slot231, align 8
  %cmp2281 = icmp ne i64 %v2280, 0
  %cv2282 = zext i1 %cmp2281 to i32
  store i32 %cv2282, ptr %slot232, align 8
  %v2283 = load i32, ptr %slot232, align 8
  %cv2284 = zext i32 %v2283 to i64
  %cond2285 = icmp ne i64 %cv2284, 0
  br i1 %cond2285, label %bb_rcgnn350, label %bb_rcgplain350
bb_rcgnn350:
  %v2286 = load i64, ptr %slot231, align 8
  %op2287 = sub i64 %v2286, 16
  store i64 %op2287, ptr %slot233, align 8
  %v2288 = load i64, ptr %slot231, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  %rgep2290 = getelementptr i8, ptr %p2289, i64 -16
  %ld2291 = load i64, ptr %rgep2290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2291, ptr %slot234, align 8
  %v2292 = load i64, ptr %slot234, align 8
  %op2293 = and i64 %v2292, 4611686018427387906
  store i64 %op2293, ptr %slot235, align 8
  %v2294 = load i64, ptr %slot235, align 8
  %cmp2295 = icmp ne i64 %v2294, 0
  %cv2296 = zext i1 %cmp2295 to i32
  store i32 %cv2296, ptr %slot236, align 8
  %v2297 = load i32, ptr %slot236, align 8
  %cv2298 = zext i32 %v2297 to i64
  %cond2299 = icmp ne i64 %cv2298, 0
  br i1 %cond2299, label %bb_rcgspecial350, label %bb_rcginc350
bb_rcginc350:
  %v2300 = load i64, ptr %slot231, align 8
  %op2301 = sub i64 %v2300, 32
  store i64 %op2301, ptr %slot237, align 8
  %v2302 = load i64, ptr %slot231, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  %rgep2304 = getelementptr i8, ptr %p2303, i64 -32
  %ld2305 = load i64, ptr %rgep2304, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2305, ptr %slot238, align 8
  %v2306 = load i64, ptr %slot238, align 8
  %op2307 = add i64 %v2306, 1
  store i64 %op2307, ptr %slot239, align 8
  %v2308 = load i64, ptr %slot239, align 8
  %cmp2309 = icmp eq i64 %v2308, 0
  %cv2310 = zext i1 %cmp2309 to i32
  store i32 %cv2310, ptr %slot240, align 8
  %v2311 = load i32, ptr %slot240, align 8
  %cv2312 = zext i32 %v2311 to i64
  %cond2313 = icmp ne i64 %cv2312, 0
  br i1 %cond2313, label %bb_rcglimit350, label %bb_rcgcapacity350
bb_rcglimit350:
  %v2314 = load i64, ptr %slot1, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %call2316 = call i32 @myl_qbe_rc_status(ptr %p2315, i32 2) nomerge, !dbg !126
  store i32 %call2316, ptr %slot241, align 8
  br label %bb_failure
bb_rcgcapacity350:
  %v2317 = load i64, ptr %slot239, align 8
  %v2318 = load i64, ptr %slot231, align 8
  %p2319 = inttoptr i64 %v2318 to ptr
  %rgep2320 = getelementptr i8, ptr %p2319, i64 -32
  store i64 %v2317, ptr %rgep2320, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain350
bb_rcgspecial350:
  %v2321 = load i64, ptr %slot234, align 8
  %op2322 = and i64 %v2321, 4611686018427387904
  store i64 %op2322, ptr %slot242, align 8
  %v2323 = load i64, ptr %slot242, align 8
  %cmp2324 = icmp ne i64 %v2323, 0
  %cv2325 = zext i1 %cmp2324 to i32
  store i32 %cv2325, ptr %slot243, align 8
  %v2326 = load i32, ptr %slot243, align 8
  %cv2327 = zext i32 %v2326 to i64
  %cond2328 = icmp ne i64 %cv2327, 0
  br i1 %cond2328, label %bb_rcgslow350, label %bb_rcgplain350
bb_rcgslow350:
  %v2329 = load i64, ptr %slot32, align 8
  %v2330 = load i64, ptr %slot229, align 8
  %v2331 = load i64, ptr %slot207, align 8
  %v2332 = load i64, ptr %slot230, align 8
  %cv2333 = trunc i64 %v2332 to i32
  %call2334 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v2329, i64 %v2330, i64 %v2331, i32 %cv2333) nomerge, !dbg !126
  store i32 %call2334, ptr %slot244, align 8
  %v2335 = load i32, ptr %slot244, align 8
  %cv2336 = zext i32 %v2335 to i64
  %cond2337 = icmp ne i64 %cv2336, 0
  br i1 %cond2337, label %bb_rcsuccess364, label %bb_rcfailure364
bb_rcfailure364:
  %v2338 = load i64, ptr %slot32, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %call2340 = call i32 @myl_rc_take_failure(ptr %p2339) nomerge, !dbg !126
  store i32 %call2340, ptr %slot245, align 8
  %v2341 = load i64, ptr %slot1, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  %v2343 = load i32, ptr %slot245, align 8
  %call2344 = call i32 @myl_qbe_rc_status(ptr %p2342, i32 %v2343) nomerge, !dbg !126
  store i32 %call2344, ptr %slot246, align 8
  br label %bb_failure
bb_rcsuccess364:
  br label %bb_rcgdone350
bb_rcgplain350:
  %v2345 = load i64, ptr %slot231, align 8
  %v2346 = load i64, ptr %slot229, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  store i64 %v2345, ptr %p2347, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone350
bb_rcgdone350:
  %v2348 = load i64, ptr %slot10, align 8
  %p2349 = inttoptr i64 %v2348 to ptr
  store i32 2, ptr %p2349, align 4, !alias.scope !3, !noalias !4
  %v2350 = load i64, ptr %slot9, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  store i32 1, ptr %p2351, align 4, !alias.scope !3, !noalias !4
  %v2352 = load i64, ptr %slot7, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  %ld2354 = load i32, ptr %p2353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2354, ptr %slot247, align 8
  %v2355 = load i32, ptr %slot247, align 8
  %cv2356 = zext i32 %v2355 to i64
  %cond2357 = icmp ne i64 %cv2356, 0
  br i1 %cond2357, label %bb_rcslotdrop371, label %bb_rcslotdone371
bb_rcslotdrop371:
  %v2358 = load i64, ptr %slot7, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  store i32 0, ptr %p2359, align 4, !alias.scope !3, !noalias !4
  %v2360 = load i64, ptr %slot12, align 8
  store i64 %v2360, ptr %slot248, align 8
  %v2361 = load i64, ptr %slot8, align 8
  %p2362 = inttoptr i64 %v2361 to ptr
  %ld2363 = load i32, ptr %p2362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2363, ptr %slot249, align 8
  %v2364 = load i32, ptr %slot249, align 8
  %op2365 = and i32 %v2364, 28
  store i32 %op2365, ptr %slot250, align 8
  %v2366 = load i32, ptr %slot250, align 8
  %cv2367 = zext i32 %v2366 to i64
  %cond2368 = icmp ne i64 %cv2367, 0
  br i1 %cond2368, label %bb_rcslotrole371, label %bb_rcslotowner371
bb_rcslotrole371:
  %v2369 = load i64, ptr %slot32, align 8
  store i64 %v2369, ptr %slot251, align 8
  %v2370 = load i64, ptr %slot248, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  %ld2372 = load i64, ptr %p2371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2372, ptr %slot252, align 8
  %v2373 = load i64, ptr %slot252, align 8
  %cmp2374 = icmp ne i64 %v2373, 0
  %cv2375 = zext i1 %cmp2374 to i32
  store i32 %cv2375, ptr %slot253, align 8
  %v2376 = load i32, ptr %slot253, align 8
  %cv2377 = zext i32 %v2376 to i64
  %cond2378 = icmp ne i64 %cv2377, 0
  br i1 %cond2378, label %bb_rcgnn387, label %bb_rcgdone387
bb_rcgnn387:
  %v2379 = load i64, ptr %slot252, align 8
  %op2380 = sub i64 %v2379, 16
  store i64 %op2380, ptr %slot254, align 8
  %v2381 = load i64, ptr %slot252, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  %rgep2383 = getelementptr i8, ptr %p2382, i64 -16
  %ld2384 = load i64, ptr %rgep2383, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2384, ptr %slot255, align 8
  %v2385 = load i64, ptr %slot255, align 8
  %op2386 = and i64 %v2385, 4611686018427387906
  store i64 %op2386, ptr %slot256, align 8
  %v2387 = load i64, ptr %slot256, align 8
  %cmp2388 = icmp ne i64 %v2387, 0
  %cv2389 = zext i1 %cmp2388 to i32
  store i32 %cv2389, ptr %slot257, align 8
  %v2390 = load i32, ptr %slot257, align 8
  %cv2391 = zext i32 %v2390 to i64
  %cond2392 = icmp ne i64 %cv2391, 0
  br i1 %cond2392, label %bb_rcgclear387, label %bb_rcgcounted387
bb_rcgcounted387:
  %v2393 = load i64, ptr %slot252, align 8
  %op2394 = sub i64 %v2393, 24
  store i64 %op2394, ptr %slot258, align 8
  %v2395 = load i64, ptr %slot252, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  %rgep2397 = getelementptr i8, ptr %p2396, i64 -24
  %ld2398 = load i64, ptr %rgep2397, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2398, ptr %slot259, align 8
  %v2399 = load i64, ptr %slot259, align 8
  %op2400 = sub i64 %v2399, 1
  store i64 %op2400, ptr %slot260, align 8
  %v2401 = load i64, ptr %slot260, align 8
  %cmp2402 = icmp eq i64 %v2401, 0
  %cv2403 = zext i1 %cmp2402 to i32
  store i32 %cv2403, ptr %slot261, align 8
  %v2404 = load i32, ptr %slot261, align 8
  %cv2405 = zext i32 %v2404 to i64
  %cond2406 = icmp ne i64 %cv2405, 0
  br i1 %cond2406, label %bb_rcglast387, label %bb_rcgdec387
bb_rcglast387:
  %v2407 = load i64, ptr %slot252, align 8
  %op2408 = sub i64 %v2407, 32
  store i64 %op2408, ptr %slot262, align 8
  %v2409 = load i64, ptr %slot252, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  %rgep2411 = getelementptr i8, ptr %p2410, i64 -32
  %ld2412 = load i64, ptr %rgep2411, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2412, ptr %slot263, align 8
  %v2413 = load i64, ptr %slot263, align 8
  %cmp2414 = icmp ne i64 %v2413, 0
  %cv2415 = zext i1 %cmp2414 to i32
  store i32 %cv2415, ptr %slot264, align 8
  %v2416 = load i32, ptr %slot264, align 8
  %cv2417 = zext i32 %v2416 to i64
  %cond2418 = icmp ne i64 %cv2417, 0
  br i1 %cond2418, label %bb_rcgdec387, label %bb_rcgslow387
bb_rcgslow387:
  %v2419 = load i64, ptr %slot251, align 8
  %v2420 = load i64, ptr %slot248, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2419, i64 %v2420) nomerge, !dbg !126
  br label %bb_rcgdone387
bb_rcgdec387:
  %v2421 = load i64, ptr %slot260, align 8
  %v2422 = load i64, ptr %slot252, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  %rgep2424 = getelementptr i8, ptr %p2423, i64 -24
  store i64 %v2421, ptr %rgep2424, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear387
bb_rcgclear387:
  %v2425 = load i64, ptr %slot248, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  store i64 0, ptr %p2426, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone387
bb_rcgdone387:
  br label %bb_rcslotdone371
bb_rcslotowner371:
  %v2427 = load i64, ptr %slot32, align 8
  store i64 %v2427, ptr %slot265, align 8
  %v2428 = load i64, ptr %slot248, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  %ld2430 = load i64, ptr %p2429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2430, ptr %slot266, align 8
  %v2431 = load i64, ptr %slot266, align 8
  %cmp2432 = icmp ne i64 %v2431, 0
  %cv2433 = zext i1 %cmp2432 to i32
  store i32 %cv2433, ptr %slot267, align 8
  %v2434 = load i32, ptr %slot267, align 8
  %cv2435 = zext i32 %v2434 to i64
  %cond2436 = icmp ne i64 %cv2435, 0
  br i1 %cond2436, label %bb_rcgnn402, label %bb_rcgdone402
bb_rcgnn402:
  %v2437 = load i64, ptr %slot266, align 8
  %op2438 = sub i64 %v2437, 16
  store i64 %op2438, ptr %slot268, align 8
  %v2439 = load i64, ptr %slot266, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  %rgep2441 = getelementptr i8, ptr %p2440, i64 -16
  %ld2442 = load i64, ptr %rgep2441, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2442, ptr %slot269, align 8
  %v2443 = load i64, ptr %slot269, align 8
  %op2444 = and i64 %v2443, 4611686018427387906
  store i64 %op2444, ptr %slot270, align 8
  %v2445 = load i64, ptr %slot270, align 8
  %cmp2446 = icmp ne i64 %v2445, 0
  %cv2447 = zext i1 %cmp2446 to i32
  store i32 %cv2447, ptr %slot271, align 8
  %v2448 = load i32, ptr %slot271, align 8
  %cv2449 = zext i32 %v2448 to i64
  %cond2450 = icmp ne i64 %cv2449, 0
  br i1 %cond2450, label %bb_rcgclear402, label %bb_rcgcounted402
bb_rcgcounted402:
  %v2451 = load i64, ptr %slot266, align 8
  %op2452 = sub i64 %v2451, 32
  store i64 %op2452, ptr %slot272, align 8
  %v2453 = load i64, ptr %slot266, align 8
  %p2454 = inttoptr i64 %v2453 to ptr
  %rgep2455 = getelementptr i8, ptr %p2454, i64 -32
  %ld2456 = load i64, ptr %rgep2455, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2456, ptr %slot273, align 8
  %v2457 = load i64, ptr %slot273, align 8
  %op2458 = sub i64 %v2457, 1
  store i64 %op2458, ptr %slot274, align 8
  %v2459 = load i64, ptr %slot274, align 8
  %cmp2460 = icmp eq i64 %v2459, 0
  %cv2461 = zext i1 %cmp2460 to i32
  store i32 %cv2461, ptr %slot275, align 8
  %v2462 = load i32, ptr %slot275, align 8
  %cv2463 = zext i32 %v2462 to i64
  %cond2464 = icmp ne i64 %cv2463, 0
  br i1 %cond2464, label %bb_rcglast402, label %bb_rcgdec402
bb_rcglast402:
  %v2465 = load i64, ptr %slot266, align 8
  %op2466 = sub i64 %v2465, 24
  store i64 %op2466, ptr %slot276, align 8
  %v2467 = load i64, ptr %slot266, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  %rgep2469 = getelementptr i8, ptr %p2468, i64 -24
  %ld2470 = load i64, ptr %rgep2469, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2470, ptr %slot277, align 8
  %v2471 = load i64, ptr %slot277, align 8
  %cmp2472 = icmp ne i64 %v2471, 0
  %cv2473 = zext i1 %cmp2472 to i32
  store i32 %cv2473, ptr %slot278, align 8
  %v2474 = load i32, ptr %slot278, align 8
  %cv2475 = zext i32 %v2474 to i64
  %cond2476 = icmp ne i64 %cv2475, 0
  br i1 %cond2476, label %bb_rcgdec402, label %bb_rcgslow402
bb_rcgslow402:
  %v2477 = load i64, ptr %slot265, align 8
  %v2478 = load i64, ptr %slot248, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2477, i64 %v2478) nomerge, !dbg !126
  br label %bb_rcgdone402
bb_rcgdec402:
  %v2479 = load i64, ptr %slot274, align 8
  %v2480 = load i64, ptr %slot266, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  %rgep2482 = getelementptr i8, ptr %p2481, i64 -32
  store i64 %v2479, ptr %rgep2482, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear402
bb_rcgclear402:
  %v2483 = load i64, ptr %slot248, align 8
  %p2484 = inttoptr i64 %v2483 to ptr
  store i64 0, ptr %p2484, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone402
bb_rcgdone402:
  br label %bb_rcslotdone371
bb_rcslotdone371:
  br label %bb_rcprepared317
bb_rcprepared317:
  %v2485 = load i64, ptr %slot14, align 8
  store i64 %v2485, ptr %slot279, align 8
  %v2486 = load i64, ptr %slot279, align 8
  %v2487 = load i64, ptr %slot205, align 8
  %p2488 = inttoptr i64 %v2486 to ptr
  %p2489 = inttoptr i64 %v2487 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2489, ptr %p2488, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot9, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  store i32 0, ptr %p2491, align 4, !alias.scope !3, !noalias !4
  %v2492 = load i64, ptr %slot21, align 8
  store i64 %v2492, ptr %slot280, align 8
  %v2493 = load i64, ptr %slot200, align 8
  %p2495 = inttoptr i64 %v2493 to ptr
  %gep2496 = getelementptr i8, ptr %p2495, i64 8
  %op2494 = ptrtoint ptr %gep2496 to i64
  store i64 %op2494, ptr %slot281, align 8
  %v2497 = load i64, ptr %slot280, align 8
  %p2498 = inttoptr i64 %v2497 to ptr
  %ld2499 = load i32, ptr %p2498, align 4, !alias.scope !3, !noalias !4
  %ext2500 = zext i32 %ld2499 to i64
  store i64 %ext2500, ptr %slot282, align 8
  %v2501 = load i64, ptr %slot282, align 8
  %cv2502 = trunc i64 %v2501 to i32
  %v2503 = load i64, ptr %slot281, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  store i32 %cv2502, ptr %p2504, align 4, !alias.scope !3, !noalias !4
  %v2505 = load i64, ptr %slot200, align 8
  %v2506 = load i64, ptr %slot20, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  store i64 %v2505, ptr %p2507, align 8, !alias.scope !3, !noalias !4
  %v2508 = load i64, ptr %slot20, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  %ld2510 = load i64, ptr %p2509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2510, ptr %slot283, align 8
  %v2511 = load i64, ptr %slot12, align 8
  store i64 %v2511, ptr %slot284, align 8
  %v2512 = load i64, ptr %slot283, align 8
  %v2513 = load i64, ptr %slot284, align 8
  %p2514 = inttoptr i64 %v2512 to ptr
  %p2515 = inttoptr i64 %v2513 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2515, ptr %p2514, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2516 = load i64, ptr %slot8, align 8
  %p2517 = inttoptr i64 %v2516 to ptr
  store i32 2, ptr %p2517, align 4, !alias.scope !3, !noalias !4
  %v2518 = load i64, ptr %slot7, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  store i32 1, ptr %p2519, align 4, !alias.scope !3, !noalias !4
  %v2520 = load i64, ptr %slot284, align 8
  %v2521 = load i64, ptr %slot20, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i64 %v2520, ptr %p2522, align 8, !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot20, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  %ld2525 = load i64, ptr %p2524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2525, ptr %slot285, align 8
  %v2526 = load i64, ptr %slot20, align 8
  %p2527 = inttoptr i64 %v2526 to ptr
  %ld2528 = load i64, ptr %p2527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2528, ptr %slot286, align 8
  %v2529 = load i64, ptr %slot14, align 8
  store i64 %v2529, ptr %slot287, align 8
  %v2530 = load i64, ptr %slot33, align 8
  store i64 %v2530, ptr %slot288, align 8
  %v2531 = load i64, ptr %slot286, align 8
  %op2532 = add i64 %v2531, 0
  store i64 %op2532, ptr %slot289, align 8
  %v2533 = load i64, ptr %slot289, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  %ld2535 = load i64, ptr %p2534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2535, ptr %slot290, align 8
  %v2536 = load i64, ptr %slot290, align 8
  %cmp2537 = icmp ne i64 %v2536, 0
  %cv2538 = zext i1 %cmp2537 to i32
  store i32 %cv2538, ptr %slot291, align 8
  %v2539 = load i32, ptr %slot291, align 8
  %cv2540 = zext i32 %v2539 to i64
  %cond2541 = icmp ne i64 %cv2540, 0
  br i1 %cond2541, label %bb_rcmoveheader422, label %bb_rcmovenext422
bb_rcmoveheader422:
  %v2542 = load i64, ptr %slot290, align 8
  %op2543 = sub i64 %v2542, 16
  store i64 %op2543, ptr %slot292, align 8
  %v2544 = load i64, ptr %slot290, align 8
  %p2545 = inttoptr i64 %v2544 to ptr
  %rgep2546 = getelementptr i8, ptr %p2545, i64 -16
  %ld2547 = load i64, ptr %rgep2546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2547, ptr %slot293, align 8
  %v2548 = load i64, ptr %slot293, align 8
  %op2549 = and i64 %v2548, 5764607523034234881
  store i64 %op2549, ptr %slot294, align 8
  %v2550 = load i64, ptr %slot294, align 8
  %cmp2551 = icmp ne i64 %v2550, 0
  %cv2552 = zext i1 %cmp2551 to i32
  store i32 %cv2552, ptr %slot295, align 8
  %v2553 = load i32, ptr %slot295, align 8
  %cv2554 = zext i32 %v2553 to i64
  %cond2555 = icmp ne i64 %cv2554, 0
  br i1 %cond2555, label %bb_rcmoveslow419, label %bb_rcmovenext422
bb_rcmovenext422:
  %v2556 = load i64, ptr %slot286, align 8
  %v2557 = load i64, ptr %slot287, align 8
  %p2558 = inttoptr i64 %v2556 to ptr
  %p2559 = inttoptr i64 %v2557 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2559, ptr %p2558, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2560 = load i64, ptr %slot286, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  store i64 0, ptr %p2561, align 8, !alias.scope !3, !noalias !4
  %v2562 = load i64, ptr %slot286, align 8
  %op2563 = add i64 %v2562, 8
  store i64 %op2563, ptr %slot296, align 8
  %v2564 = load i64, ptr %slot296, align 8
  %p2565 = inttoptr i64 %v2564 to ptr
  store i64 0, ptr %p2565, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved419
bb_rcmoveslow419:
  %v2566 = load i64, ptr %slot32, align 8
  %v2567 = load i64, ptr %slot287, align 8
  %v2568 = load i64, ptr %slot286, align 8
  %v2569 = load i64, ptr %slot288, align 8
  %cv2570 = trunc i64 %v2569 to i32
  %call2571 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v2566, i64 %v2567, i64 %v2568, i32 %cv2570) nomerge, !dbg !128
  store i32 %call2571, ptr %slot297, align 8
  %v2572 = load i32, ptr %slot297, align 8
  %cv2573 = zext i32 %v2572 to i64
  %cond2574 = icmp ne i64 %cv2573, 0
  br i1 %cond2574, label %bb_rcsuccess430, label %bb_rcfailure430
bb_rcfailure430:
  %v2575 = load i64, ptr %slot32, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  %call2577 = call i32 @myl_rc_take_failure(ptr %p2576) nomerge, !dbg !128
  store i32 %call2577, ptr %slot298, align 8
  %v2578 = load i64, ptr %slot1, align 8
  %p2579 = inttoptr i64 %v2578 to ptr
  %v2580 = load i32, ptr %slot298, align 8
  %call2581 = call i32 @myl_qbe_rc_status(ptr %p2579, i32 %v2580) nomerge, !dbg !128
  store i32 %call2581, ptr %slot299, align 8
  br label %bb_failure
bb_rcsuccess430:
  br label %bb_rcmoved419
bb_rcmoved419:
  %v2582 = load i64, ptr %slot7, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  store i32 0, ptr %p2583, align 4, !alias.scope !3, !noalias !4
  %v2584 = load i64, ptr %slot10, align 8
  %p2585 = inttoptr i64 %v2584 to ptr
  store i32 2, ptr %p2585, align 4, !alias.scope !3, !noalias !4
  %v2586 = load i64, ptr %slot9, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  store i32 1, ptr %p2587, align 4, !alias.scope !3, !noalias !4
  %v2588 = load i64, ptr %slot14, align 8
  store i64 %v2588, ptr %slot300, align 8
  %v2589 = load i64, ptr %slot9, align 8
  %p2590 = inttoptr i64 %v2589 to ptr
  store i32 0, ptr %p2590, align 4, !alias.scope !3, !noalias !4
  %v2591 = load i64, ptr %slot7, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  %ld2593 = load i32, ptr %p2592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2593, ptr %slot301, align 8
  %v2594 = load i32, ptr %slot301, align 8
  %cv2595 = zext i32 %v2594 to i64
  %cond2596 = icmp ne i64 %cv2595, 0
  br i1 %cond2596, label %bb_rcslotdrop440, label %bb_rcslotdone440
bb_rcslotdrop440:
  %v2597 = load i64, ptr %slot7, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  store i32 0, ptr %p2598, align 4, !alias.scope !3, !noalias !4
  %v2599 = load i64, ptr %slot12, align 8
  store i64 %v2599, ptr %slot302, align 8
  %v2600 = load i64, ptr %slot8, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  %ld2602 = load i32, ptr %p2601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2602, ptr %slot303, align 8
  %v2603 = load i32, ptr %slot303, align 8
  %op2604 = and i32 %v2603, 28
  store i32 %op2604, ptr %slot304, align 8
  %v2605 = load i32, ptr %slot304, align 8
  %cv2606 = zext i32 %v2605 to i64
  %cond2607 = icmp ne i64 %cv2606, 0
  br i1 %cond2607, label %bb_rcslotrole440, label %bb_rcslotowner440
bb_rcslotrole440:
  %v2608 = load i64, ptr %slot32, align 8
  store i64 %v2608, ptr %slot305, align 8
  %v2609 = load i64, ptr %slot305, align 8
  %v2610 = load i64, ptr %slot302, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v2609, i64 %v2610) nomerge, !dbg !128
  br label %bb_rcslotdone440
bb_rcslotowner440:
  %v2611 = load i64, ptr %slot32, align 8
  store i64 %v2611, ptr %slot306, align 8
  %v2612 = load i64, ptr %slot306, align 8
  %v2613 = load i64, ptr %slot302, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v2612, i64 %v2613) nomerge, !dbg !128
  br label %bb_rcslotdone440
bb_rcslotdone440:
  %v2614 = load i64, ptr %slot300, align 8
  %p2615 = inttoptr i64 %v2614 to ptr
  %ret2616 = load { i64, i64 }, ptr %p2615, align 8
  ret { i64, i64 } %ret2616
bb_i25:
  %v2617 = load i64, ptr %slot20, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  store i64 0, ptr %p2618, align 8, !alias.scope !3, !noalias !4
  %v2619 = load i64, ptr %slot20, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  %ld2621 = load i64, ptr %p2620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2621, ptr %slot307, align 8
  %v2622 = load i64, ptr %slot307, align 8
  %cond2623 = icmp ne i64 %v2622, 0
  br i1 %cond2623, label %bb_success503, label %bb_failed503
bb_failed503:
  %v2624 = load i64, ptr %slot1, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  call void @myl_qbe_fail_assert(ptr %p2625) nomerge, !dbg !130
  unreachable
bb_success503:
  %p2626 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld2627 = load i64, ptr %p2626, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2627, ptr %slot308, align 8
  %v2628 = load i64, ptr %slot308, align 8
  %v2629 = load i64, ptr %slot20, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  store i64 %v2628, ptr %p2630, align 8, !alias.scope !3, !noalias !4
  %v2631 = load i64, ptr %slot20, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  %ld2633 = load i64, ptr %p2632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2633, ptr %slot309, align 8
  %v2634 = load i64, ptr %slot309, align 8
  %v2635 = load i64, ptr %slot13, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  store i64 %v2634, ptr %p2636, align 8, !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot13, align 8
  store i64 %v2637, ptr %slot310, align 8
  %v2638 = load i64, ptr %slot14, align 8
  store i64 %v2638, ptr %slot311, align 8
  %v2639 = load i64, ptr %slot310, align 8
  %v2640 = load i64, ptr %slot311, align 8
  %p2641 = inttoptr i64 %v2639 to ptr
  %p2642 = inttoptr i64 %v2640 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2642, ptr %p2641, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2643 = load i64, ptr %slot10, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  store i32 2, ptr %p2644, align 4, !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot9, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  store i32 1, ptr %p2646, align 4, !alias.scope !3, !noalias !4
  %v2647 = load i64, ptr %slot12, align 8
  store i64 %v2647, ptr %slot312, align 8
  %v2648 = load i64, ptr %slot14, align 8
  store i64 %v2648, ptr %slot313, align 8
  %v2649 = load i64, ptr %slot313, align 8
  %v2650 = load i64, ptr %slot312, align 8
  %p2651 = inttoptr i64 %v2649 to ptr
  %p2652 = inttoptr i64 %v2650 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2652, ptr %p2651, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2653 = load i64, ptr %slot8, align 8
  %p2654 = inttoptr i64 %v2653 to ptr
  store i32 2, ptr %p2654, align 4, !alias.scope !3, !noalias !4
  %v2655 = load i64, ptr %slot10, align 8
  %p2656 = inttoptr i64 %v2655 to ptr
  %ld2657 = load i32, ptr %p2656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2657, ptr %slot314, align 8
  %v2658 = load i32, ptr %slot314, align 8
  %v2659 = load i64, ptr %slot8, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  store i32 %v2658, ptr %p2660, align 4, !alias.scope !3, !noalias !4
  %v2661 = load i64, ptr %slot9, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  store i32 0, ptr %p2662, align 4, !alias.scope !3, !noalias !4
  %v2663 = load i64, ptr %slot7, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  store i32 1, ptr %p2664, align 4, !alias.scope !3, !noalias !4
  %v2665 = load i64, ptr %slot312, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  %ld2667 = load i64, ptr %p2666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2667, ptr %slot315, align 8
  %v2668 = load i64, ptr %slot315, align 8
  %v2669 = load i64, ptr %slot20, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  store i64 %v2668, ptr %p2670, align 8, !alias.scope !3, !noalias !4
  %v2671 = load i64, ptr %slot21, align 8
  %p2672 = inttoptr i64 %v2671 to ptr
  store i64 0, ptr %p2672, align 8, !alias.scope !3, !noalias !4
  %v2673 = load i64, ptr %slot23, align 8
  store i64 %v2673, ptr %slot316, align 8
  %v2674 = load i64, ptr %slot316, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  store i64 0, ptr %p2675, align 8, !alias.scope !3, !noalias !4
  %v2676 = load i64, ptr %slot316, align 8
  %p2678 = inttoptr i64 %v2676 to ptr
  %gep2679 = getelementptr i8, ptr %p2678, i64 8
  %op2677 = ptrtoint ptr %gep2679 to i64
  store i64 %op2677, ptr %slot317, align 8
  %v2680 = load i64, ptr %slot317, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  store i64 0, ptr %p2681, align 8, !alias.scope !3, !noalias !4
  %v2682 = load i64, ptr %slot11, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  store i32 1, ptr %p2683, align 4, !alias.scope !3, !noalias !4
  %v2684 = load i64, ptr %slot33, align 8
  store i64 %v2684, ptr %slot318, align 8
  %v2685 = load i64, ptr %slot20, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %ld2687 = load i64, ptr %p2686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2687, ptr %slot319, align 8
  %v2688 = load i64, ptr %slot319, align 8
  %v2689 = load i64, ptr %slot13, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  store i64 %v2688, ptr %p2690, align 8, !alias.scope !3, !noalias !4
  %v2691 = load i64, ptr %slot13, align 8
  store i64 %v2691, ptr %slot320, align 8
  %v2692 = load i64, ptr %slot316, align 8
  %p2694 = inttoptr i64 %v2692 to ptr
  %gep2695 = getelementptr i8, ptr %p2694, i64 0
  %op2693 = ptrtoint ptr %gep2695 to i64
  store i64 %op2693, ptr %slot321, align 8
  %v2696 = load i64, ptr %slot20, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  %ld2698 = load i64, ptr %p2697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2698, ptr %slot322, align 8
  %v2699 = load i64, ptr %slot322, align 8
  %v2700 = load i64, ptr %slot13, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  store i64 %v2699, ptr %p2701, align 8, !alias.scope !3, !noalias !4
  %v2702 = load i64, ptr %slot13, align 8
  store i64 %v2702, ptr %slot323, align 8
  %v2703 = load i64, ptr %slot7, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  %ld2705 = load i32, ptr %p2704, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2705, ptr %slot324, align 8
  %v2706 = load i64, ptr %slot8, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  %ld2708 = load i32, ptr %p2707, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2708, ptr %slot325, align 8
  %v2709 = load i32, ptr %slot325, align 8
  %op2710 = and i32 %v2709, 24
  store i32 %op2710, ptr %slot325, align 8
  %v2711 = load i32, ptr %slot325, align 8
  %cmp2712 = icmp eq i32 %v2711, 0
  %cv2713 = zext i1 %cmp2712 to i32
  store i32 %cv2713, ptr %slot326, align 8
  %v2714 = load i32, ptr %slot324, align 8
  %v2715 = load i32, ptr %slot326, align 8
  %op2716 = and i32 %v2714, %v2715
  store i32 %op2716, ptr %slot327, align 8
  %v2717 = load i32, ptr %slot327, align 8
  %cv2718 = zext i32 %v2717 to i64
  %cond2719 = icmp ne i64 %cv2718, 0
  br i1 %cond2719, label %bb_rctake530, label %bb_rccopy530
bb_rctake530:
  %v2720 = load i64, ptr %slot14, align 8
  store i64 %v2720, ptr %slot328, align 8
  %v2721 = load i64, ptr %slot33, align 8
  store i64 %v2721, ptr %slot329, align 8
  %v2722 = load i64, ptr %slot323, align 8
  %v2723 = load i64, ptr %slot328, align 8
  %op2724 = sub i64 %v2722, %v2723
  store i64 %op2724, ptr %slot330, align 8
  %v2725 = load i64, ptr %slot328, align 8
  %v2726 = load i64, ptr %slot323, align 8
  %op2727 = sub i64 %v2725, %v2726
  store i64 %op2727, ptr %slot331, align 8
  %v2728 = load i64, ptr %slot330, align 8
  %cmp2729 = icmp ult i64 %v2728, 8
  %cv2730 = zext i1 %cmp2729 to i32
  store i32 %cv2730, ptr %slot332, align 8
  %v2731 = load i64, ptr %slot331, align 8
  %cmp2732 = icmp ult i64 %v2731, 8
  %cv2733 = zext i1 %cmp2732 to i32
  store i32 %cv2733, ptr %slot333, align 8
  %v2734 = load i32, ptr %slot332, align 8
  %v2735 = load i32, ptr %slot333, align 8
  %op2736 = or i32 %v2734, %v2735
  store i32 %op2736, ptr %slot334, align 8
  %v2737 = load i32, ptr %slot334, align 8
  %cv2738 = zext i32 %v2737 to i64
  %cond2739 = icmp ne i64 %cv2738, 0
  br i1 %cond2739, label %bb_rcmoveslow539, label %bb_rcmovecheck539
bb_rcmovecheck539:
  %v2740 = load i64, ptr %slot323, align 8
  %p2742 = inttoptr i64 %v2740 to ptr
  %gep2743 = getelementptr i8, ptr %p2742, i64 0
  %op2741 = ptrtoint ptr %gep2743 to i64
  store i64 %op2741, ptr %slot335, align 8
  %v2744 = load i64, ptr %slot335, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  %ld2746 = load i64, ptr %p2745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2746, ptr %slot336, align 8
  %v2747 = load i64, ptr %slot336, align 8
  %cmp2748 = icmp ne i64 %v2747, 0
  %cv2749 = zext i1 %cmp2748 to i32
  store i32 %cv2749, ptr %slot337, align 8
  %v2750 = load i32, ptr %slot337, align 8
  %cv2751 = zext i32 %v2750 to i64
  %cond2752 = icmp ne i64 %cv2751, 0
  br i1 %cond2752, label %bb_rcmoveheader547, label %bb_rcmovenext547
bb_rcmoveheader547:
  %v2753 = load i64, ptr %slot336, align 8
  %op2754 = sub i64 %v2753, 16
  store i64 %op2754, ptr %slot338, align 8
  %v2755 = load i64, ptr %slot336, align 8
  %p2756 = inttoptr i64 %v2755 to ptr
  %rgep2757 = getelementptr i8, ptr %p2756, i64 -16
  %ld2758 = load i64, ptr %rgep2757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2758, ptr %slot339, align 8
  %v2759 = load i64, ptr %slot339, align 8
  %op2760 = and i64 %v2759, 5764607523034234881
  store i64 %op2760, ptr %slot340, align 8
  %v2761 = load i64, ptr %slot340, align 8
  %cmp2762 = icmp ne i64 %v2761, 0
  %cv2763 = zext i1 %cmp2762 to i32
  store i32 %cv2763, ptr %slot341, align 8
  %v2764 = load i32, ptr %slot341, align 8
  %cv2765 = zext i32 %v2764 to i64
  %cond2766 = icmp ne i64 %cv2765, 0
  br i1 %cond2766, label %bb_rcmoveslow539, label %bb_rcmovenext547
bb_rcmovenext547:
  %v2767 = load i64, ptr %slot323, align 8
  %v2768 = load i64, ptr %slot328, align 8
  %p2769 = inttoptr i64 %v2767 to ptr
  %p2770 = inttoptr i64 %v2768 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2770, ptr %p2769, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2771 = load i64, ptr %slot323, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  store i64 0, ptr %p2772, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved539
bb_rcmoveslow539:
  %v2773 = load i64, ptr %slot32, align 8
  %v2774 = load i64, ptr %slot328, align 8
  %v2775 = load i64, ptr %slot323, align 8
  %v2776 = load i64, ptr %slot329, align 8
  %cv2777 = trunc i64 %v2776 to i32
  %call2778 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2773, i64 %v2774, i64 %v2775, i32 %cv2777) nomerge, !dbg !132
  store i32 %call2778, ptr %slot342, align 8
  %v2779 = load i32, ptr %slot342, align 8
  %cv2780 = zext i32 %v2779 to i64
  %cond2781 = icmp ne i64 %cv2780, 0
  br i1 %cond2781, label %bb_rcsuccess554, label %bb_rcfailure554
bb_rcfailure554:
  %v2782 = load i64, ptr %slot32, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  %call2784 = call i32 @myl_rc_take_failure(ptr %p2783) nomerge, !dbg !132
  store i32 %call2784, ptr %slot343, align 8
  %v2785 = load i64, ptr %slot1, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  %v2787 = load i32, ptr %slot343, align 8
  %call2788 = call i32 @myl_qbe_rc_status(ptr %p2786, i32 %v2787) nomerge, !dbg !132
  store i32 %call2788, ptr %slot344, align 8
  br label %bb_failure
bb_rcsuccess554:
  br label %bb_rcmoved539
bb_rcmoved539:
  %v2789 = load i64, ptr %slot7, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  store i32 0, ptr %p2790, align 4, !alias.scope !3, !noalias !4
  %v2791 = load i64, ptr %slot10, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  store i32 2, ptr %p2792, align 4, !alias.scope !3, !noalias !4
  %v2793 = load i64, ptr %slot9, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  store i32 1, ptr %p2794, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared530
bb_rccopy530:
  %v2795 = load i64, ptr %slot14, align 8
  store i64 %v2795, ptr %slot345, align 8
  %v2796 = load i64, ptr %slot33, align 8
  store i64 %v2796, ptr %slot346, align 8
  %v2797 = load i64, ptr %slot323, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %ld2799 = load i64, ptr %p2798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2799, ptr %slot347, align 8
  %v2800 = load i64, ptr %slot347, align 8
  %cmp2801 = icmp ne i64 %v2800, 0
  %cv2802 = zext i1 %cmp2801 to i32
  store i32 %cv2802, ptr %slot348, align 8
  %v2803 = load i32, ptr %slot348, align 8
  %cv2804 = zext i32 %v2803 to i64
  %cond2805 = icmp ne i64 %cv2804, 0
  br i1 %cond2805, label %bb_rcgnn563, label %bb_rcgplain563
bb_rcgnn563:
  %v2806 = load i64, ptr %slot347, align 8
  %op2807 = sub i64 %v2806, 16
  store i64 %op2807, ptr %slot349, align 8
  %v2808 = load i64, ptr %slot347, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  %rgep2810 = getelementptr i8, ptr %p2809, i64 -16
  %ld2811 = load i64, ptr %rgep2810, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2811, ptr %slot350, align 8
  %v2812 = load i64, ptr %slot350, align 8
  %op2813 = and i64 %v2812, 4611686018427387906
  store i64 %op2813, ptr %slot351, align 8
  %v2814 = load i64, ptr %slot351, align 8
  %cmp2815 = icmp ne i64 %v2814, 0
  %cv2816 = zext i1 %cmp2815 to i32
  store i32 %cv2816, ptr %slot352, align 8
  %v2817 = load i32, ptr %slot352, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcgspecial563, label %bb_rcginc563
bb_rcginc563:
  %v2820 = load i64, ptr %slot347, align 8
  %op2821 = sub i64 %v2820, 32
  store i64 %op2821, ptr %slot353, align 8
  %v2822 = load i64, ptr %slot347, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  %rgep2824 = getelementptr i8, ptr %p2823, i64 -32
  %ld2825 = load i64, ptr %rgep2824, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2825, ptr %slot354, align 8
  %v2826 = load i64, ptr %slot354, align 8
  %op2827 = add i64 %v2826, 1
  store i64 %op2827, ptr %slot355, align 8
  %v2828 = load i64, ptr %slot355, align 8
  %cmp2829 = icmp eq i64 %v2828, 0
  %cv2830 = zext i1 %cmp2829 to i32
  store i32 %cv2830, ptr %slot356, align 8
  %v2831 = load i32, ptr %slot356, align 8
  %cv2832 = zext i32 %v2831 to i64
  %cond2833 = icmp ne i64 %cv2832, 0
  br i1 %cond2833, label %bb_rcglimit563, label %bb_rcgcapacity563
bb_rcglimit563:
  %v2834 = load i64, ptr %slot1, align 8
  %p2835 = inttoptr i64 %v2834 to ptr
  %call2836 = call i32 @myl_qbe_rc_status(ptr %p2835, i32 2) nomerge, !dbg !132
  store i32 %call2836, ptr %slot357, align 8
  br label %bb_failure
bb_rcgcapacity563:
  %v2837 = load i64, ptr %slot355, align 8
  %v2838 = load i64, ptr %slot347, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  %rgep2840 = getelementptr i8, ptr %p2839, i64 -32
  store i64 %v2837, ptr %rgep2840, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain563
bb_rcgspecial563:
  %v2841 = load i64, ptr %slot350, align 8
  %op2842 = and i64 %v2841, 4611686018427387904
  store i64 %op2842, ptr %slot358, align 8
  %v2843 = load i64, ptr %slot358, align 8
  %cmp2844 = icmp ne i64 %v2843, 0
  %cv2845 = zext i1 %cmp2844 to i32
  store i32 %cv2845, ptr %slot359, align 8
  %v2846 = load i32, ptr %slot359, align 8
  %cv2847 = zext i32 %v2846 to i64
  %cond2848 = icmp ne i64 %cv2847, 0
  br i1 %cond2848, label %bb_rcgslow563, label %bb_rcgplain563
bb_rcgslow563:
  %v2849 = load i64, ptr %slot32, align 8
  %v2850 = load i64, ptr %slot345, align 8
  %v2851 = load i64, ptr %slot323, align 8
  %v2852 = load i64, ptr %slot346, align 8
  %cv2853 = trunc i64 %v2852 to i32
  %call2854 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v2849, i64 %v2850, i64 %v2851, i32 %cv2853) nomerge, !dbg !132
  store i32 %call2854, ptr %slot360, align 8
  %v2855 = load i32, ptr %slot360, align 8
  %cv2856 = zext i32 %v2855 to i64
  %cond2857 = icmp ne i64 %cv2856, 0
  br i1 %cond2857, label %bb_rcsuccess577, label %bb_rcfailure577
bb_rcfailure577:
  %v2858 = load i64, ptr %slot32, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  %call2860 = call i32 @myl_rc_take_failure(ptr %p2859) nomerge, !dbg !132
  store i32 %call2860, ptr %slot361, align 8
  %v2861 = load i64, ptr %slot1, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  %v2863 = load i32, ptr %slot361, align 8
  %call2864 = call i32 @myl_qbe_rc_status(ptr %p2862, i32 %v2863) nomerge, !dbg !132
  store i32 %call2864, ptr %slot362, align 8
  br label %bb_failure
bb_rcsuccess577:
  br label %bb_rcgdone563
bb_rcgplain563:
  %v2865 = load i64, ptr %slot347, align 8
  %v2866 = load i64, ptr %slot345, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  store i64 %v2865, ptr %p2867, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone563
bb_rcgdone563:
  %v2868 = load i64, ptr %slot10, align 8
  %p2869 = inttoptr i64 %v2868 to ptr
  store i32 2, ptr %p2869, align 4, !alias.scope !3, !noalias !4
  %v2870 = load i64, ptr %slot9, align 8
  %p2871 = inttoptr i64 %v2870 to ptr
  store i32 1, ptr %p2871, align 4, !alias.scope !3, !noalias !4
  %v2872 = load i64, ptr %slot7, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  %ld2874 = load i32, ptr %p2873, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2874, ptr %slot363, align 8
  %v2875 = load i32, ptr %slot363, align 8
  %cv2876 = zext i32 %v2875 to i64
  %cond2877 = icmp ne i64 %cv2876, 0
  br i1 %cond2877, label %bb_rcslotdrop584, label %bb_rcslotdone584
bb_rcslotdrop584:
  %v2878 = load i64, ptr %slot7, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  store i32 0, ptr %p2879, align 4, !alias.scope !3, !noalias !4
  %v2880 = load i64, ptr %slot12, align 8
  store i64 %v2880, ptr %slot364, align 8
  %v2881 = load i64, ptr %slot8, align 8
  %p2882 = inttoptr i64 %v2881 to ptr
  %ld2883 = load i32, ptr %p2882, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2883, ptr %slot365, align 8
  %v2884 = load i32, ptr %slot365, align 8
  %op2885 = and i32 %v2884, 28
  store i32 %op2885, ptr %slot366, align 8
  %v2886 = load i32, ptr %slot366, align 8
  %cv2887 = zext i32 %v2886 to i64
  %cond2888 = icmp ne i64 %cv2887, 0
  br i1 %cond2888, label %bb_rcslotrole584, label %bb_rcslotowner584
bb_rcslotrole584:
  %v2889 = load i64, ptr %slot32, align 8
  store i64 %v2889, ptr %slot367, align 8
  %v2890 = load i64, ptr %slot364, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  %ld2892 = load i64, ptr %p2891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2892, ptr %slot368, align 8
  %v2893 = load i64, ptr %slot368, align 8
  %cmp2894 = icmp ne i64 %v2893, 0
  %cv2895 = zext i1 %cmp2894 to i32
  store i32 %cv2895, ptr %slot369, align 8
  %v2896 = load i32, ptr %slot369, align 8
  %cv2897 = zext i32 %v2896 to i64
  %cond2898 = icmp ne i64 %cv2897, 0
  br i1 %cond2898, label %bb_rcgnn600, label %bb_rcgdone600
bb_rcgnn600:
  %v2899 = load i64, ptr %slot368, align 8
  %op2900 = sub i64 %v2899, 16
  store i64 %op2900, ptr %slot370, align 8
  %v2901 = load i64, ptr %slot368, align 8
  %p2902 = inttoptr i64 %v2901 to ptr
  %rgep2903 = getelementptr i8, ptr %p2902, i64 -16
  %ld2904 = load i64, ptr %rgep2903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2904, ptr %slot371, align 8
  %v2905 = load i64, ptr %slot371, align 8
  %op2906 = and i64 %v2905, 4611686018427387906
  store i64 %op2906, ptr %slot372, align 8
  %v2907 = load i64, ptr %slot372, align 8
  %cmp2908 = icmp ne i64 %v2907, 0
  %cv2909 = zext i1 %cmp2908 to i32
  store i32 %cv2909, ptr %slot373, align 8
  %v2910 = load i32, ptr %slot373, align 8
  %cv2911 = zext i32 %v2910 to i64
  %cond2912 = icmp ne i64 %cv2911, 0
  br i1 %cond2912, label %bb_rcgclear600, label %bb_rcgcounted600
bb_rcgcounted600:
  %v2913 = load i64, ptr %slot368, align 8
  %op2914 = sub i64 %v2913, 24
  store i64 %op2914, ptr %slot374, align 8
  %v2915 = load i64, ptr %slot368, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %rgep2917 = getelementptr i8, ptr %p2916, i64 -24
  %ld2918 = load i64, ptr %rgep2917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2918, ptr %slot375, align 8
  %v2919 = load i64, ptr %slot375, align 8
  %op2920 = sub i64 %v2919, 1
  store i64 %op2920, ptr %slot376, align 8
  %v2921 = load i64, ptr %slot376, align 8
  %cmp2922 = icmp eq i64 %v2921, 0
  %cv2923 = zext i1 %cmp2922 to i32
  store i32 %cv2923, ptr %slot377, align 8
  %v2924 = load i32, ptr %slot377, align 8
  %cv2925 = zext i32 %v2924 to i64
  %cond2926 = icmp ne i64 %cv2925, 0
  br i1 %cond2926, label %bb_rcglast600, label %bb_rcgdec600
bb_rcglast600:
  %v2927 = load i64, ptr %slot368, align 8
  %op2928 = sub i64 %v2927, 32
  store i64 %op2928, ptr %slot378, align 8
  %v2929 = load i64, ptr %slot368, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  %rgep2931 = getelementptr i8, ptr %p2930, i64 -32
  %ld2932 = load i64, ptr %rgep2931, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2932, ptr %slot379, align 8
  %v2933 = load i64, ptr %slot379, align 8
  %cmp2934 = icmp ne i64 %v2933, 0
  %cv2935 = zext i1 %cmp2934 to i32
  store i32 %cv2935, ptr %slot380, align 8
  %v2936 = load i32, ptr %slot380, align 8
  %cv2937 = zext i32 %v2936 to i64
  %cond2938 = icmp ne i64 %cv2937, 0
  br i1 %cond2938, label %bb_rcgdec600, label %bb_rcgslow600
bb_rcgslow600:
  %v2939 = load i64, ptr %slot367, align 8
  %v2940 = load i64, ptr %slot364, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2939, i64 %v2940) nomerge, !dbg !132
  br label %bb_rcgdone600
bb_rcgdec600:
  %v2941 = load i64, ptr %slot376, align 8
  %v2942 = load i64, ptr %slot368, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  %rgep2944 = getelementptr i8, ptr %p2943, i64 -24
  store i64 %v2941, ptr %rgep2944, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear600
bb_rcgclear600:
  %v2945 = load i64, ptr %slot364, align 8
  %p2946 = inttoptr i64 %v2945 to ptr
  store i64 0, ptr %p2946, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone600
bb_rcgdone600:
  br label %bb_rcslotdone584
bb_rcslotowner584:
  %v2947 = load i64, ptr %slot32, align 8
  store i64 %v2947, ptr %slot381, align 8
  %v2948 = load i64, ptr %slot364, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  %ld2950 = load i64, ptr %p2949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2950, ptr %slot382, align 8
  %v2951 = load i64, ptr %slot382, align 8
  %cmp2952 = icmp ne i64 %v2951, 0
  %cv2953 = zext i1 %cmp2952 to i32
  store i32 %cv2953, ptr %slot383, align 8
  %v2954 = load i32, ptr %slot383, align 8
  %cv2955 = zext i32 %v2954 to i64
  %cond2956 = icmp ne i64 %cv2955, 0
  br i1 %cond2956, label %bb_rcgnn615, label %bb_rcgdone615
bb_rcgnn615:
  %v2957 = load i64, ptr %slot382, align 8
  %op2958 = sub i64 %v2957, 16
  store i64 %op2958, ptr %slot384, align 8
  %v2959 = load i64, ptr %slot382, align 8
  %p2960 = inttoptr i64 %v2959 to ptr
  %rgep2961 = getelementptr i8, ptr %p2960, i64 -16
  %ld2962 = load i64, ptr %rgep2961, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2962, ptr %slot385, align 8
  %v2963 = load i64, ptr %slot385, align 8
  %op2964 = and i64 %v2963, 4611686018427387906
  store i64 %op2964, ptr %slot386, align 8
  %v2965 = load i64, ptr %slot386, align 8
  %cmp2966 = icmp ne i64 %v2965, 0
  %cv2967 = zext i1 %cmp2966 to i32
  store i32 %cv2967, ptr %slot387, align 8
  %v2968 = load i32, ptr %slot387, align 8
  %cv2969 = zext i32 %v2968 to i64
  %cond2970 = icmp ne i64 %cv2969, 0
  br i1 %cond2970, label %bb_rcgclear615, label %bb_rcgcounted615
bb_rcgcounted615:
  %v2971 = load i64, ptr %slot382, align 8
  %op2972 = sub i64 %v2971, 32
  store i64 %op2972, ptr %slot388, align 8
  %v2973 = load i64, ptr %slot382, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  %rgep2975 = getelementptr i8, ptr %p2974, i64 -32
  %ld2976 = load i64, ptr %rgep2975, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2976, ptr %slot389, align 8
  %v2977 = load i64, ptr %slot389, align 8
  %op2978 = sub i64 %v2977, 1
  store i64 %op2978, ptr %slot390, align 8
  %v2979 = load i64, ptr %slot390, align 8
  %cmp2980 = icmp eq i64 %v2979, 0
  %cv2981 = zext i1 %cmp2980 to i32
  store i32 %cv2981, ptr %slot391, align 8
  %v2982 = load i32, ptr %slot391, align 8
  %cv2983 = zext i32 %v2982 to i64
  %cond2984 = icmp ne i64 %cv2983, 0
  br i1 %cond2984, label %bb_rcglast615, label %bb_rcgdec615
bb_rcglast615:
  %v2985 = load i64, ptr %slot382, align 8
  %op2986 = sub i64 %v2985, 24
  store i64 %op2986, ptr %slot392, align 8
  %v2987 = load i64, ptr %slot382, align 8
  %p2988 = inttoptr i64 %v2987 to ptr
  %rgep2989 = getelementptr i8, ptr %p2988, i64 -24
  %ld2990 = load i64, ptr %rgep2989, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2990, ptr %slot393, align 8
  %v2991 = load i64, ptr %slot393, align 8
  %cmp2992 = icmp ne i64 %v2991, 0
  %cv2993 = zext i1 %cmp2992 to i32
  store i32 %cv2993, ptr %slot394, align 8
  %v2994 = load i32, ptr %slot394, align 8
  %cv2995 = zext i32 %v2994 to i64
  %cond2996 = icmp ne i64 %cv2995, 0
  br i1 %cond2996, label %bb_rcgdec615, label %bb_rcgslow615
bb_rcgslow615:
  %v2997 = load i64, ptr %slot381, align 8
  %v2998 = load i64, ptr %slot364, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2997, i64 %v2998) nomerge, !dbg !132
  br label %bb_rcgdone615
bb_rcgdec615:
  %v2999 = load i64, ptr %slot390, align 8
  %v3000 = load i64, ptr %slot382, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  %rgep3002 = getelementptr i8, ptr %p3001, i64 -32
  store i64 %v2999, ptr %rgep3002, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear615
bb_rcgclear615:
  %v3003 = load i64, ptr %slot364, align 8
  %p3004 = inttoptr i64 %v3003 to ptr
  store i64 0, ptr %p3004, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone615
bb_rcgdone615:
  br label %bb_rcslotdone584
bb_rcslotdone584:
  br label %bb_rcprepared530
bb_rcprepared530:
  %v3005 = load i64, ptr %slot14, align 8
  store i64 %v3005, ptr %slot395, align 8
  %v3006 = load i64, ptr %slot395, align 8
  %v3007 = load i64, ptr %slot321, align 8
  %p3008 = inttoptr i64 %v3006 to ptr
  %p3009 = inttoptr i64 %v3007 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3009, ptr %p3008, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3010 = load i64, ptr %slot9, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  store i32 0, ptr %p3011, align 4, !alias.scope !3, !noalias !4
  %v3012 = load i64, ptr %slot21, align 8
  store i64 %v3012, ptr %slot396, align 8
  %v3013 = load i64, ptr %slot316, align 8
  %p3015 = inttoptr i64 %v3013 to ptr
  %gep3016 = getelementptr i8, ptr %p3015, i64 8
  %op3014 = ptrtoint ptr %gep3016 to i64
  store i64 %op3014, ptr %slot397, align 8
  %v3017 = load i64, ptr %slot396, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  %ld3019 = load i32, ptr %p3018, align 4, !alias.scope !3, !noalias !4
  %ext3020 = zext i32 %ld3019 to i64
  store i64 %ext3020, ptr %slot398, align 8
  %v3021 = load i64, ptr %slot398, align 8
  %cv3022 = trunc i64 %v3021 to i32
  %v3023 = load i64, ptr %slot397, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  store i32 %cv3022, ptr %p3024, align 4, !alias.scope !3, !noalias !4
  %v3025 = load i64, ptr %slot316, align 8
  %v3026 = load i64, ptr %slot20, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  store i64 %v3025, ptr %p3027, align 8, !alias.scope !3, !noalias !4
  %v3028 = load i64, ptr %slot20, align 8
  %p3029 = inttoptr i64 %v3028 to ptr
  %ld3030 = load i64, ptr %p3029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3030, ptr %slot399, align 8
  %v3031 = load i64, ptr %slot12, align 8
  store i64 %v3031, ptr %slot400, align 8
  %v3032 = load i64, ptr %slot399, align 8
  %v3033 = load i64, ptr %slot400, align 8
  %p3034 = inttoptr i64 %v3032 to ptr
  %p3035 = inttoptr i64 %v3033 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3035, ptr %p3034, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3036 = load i64, ptr %slot8, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  store i32 2, ptr %p3037, align 4, !alias.scope !3, !noalias !4
  %v3038 = load i64, ptr %slot7, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  store i32 1, ptr %p3039, align 4, !alias.scope !3, !noalias !4
  %v3040 = load i64, ptr %slot400, align 8
  %v3041 = load i64, ptr %slot20, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  store i64 %v3040, ptr %p3042, align 8, !alias.scope !3, !noalias !4
  %v3043 = load i64, ptr %slot20, align 8
  %p3044 = inttoptr i64 %v3043 to ptr
  %ld3045 = load i64, ptr %p3044, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3045, ptr %slot401, align 8
  %v3046 = load i64, ptr %slot20, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  %ld3048 = load i64, ptr %p3047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3048, ptr %slot402, align 8
  %v3049 = load i64, ptr %slot14, align 8
  store i64 %v3049, ptr %slot403, align 8
  %v3050 = load i64, ptr %slot33, align 8
  store i64 %v3050, ptr %slot404, align 8
  %v3051 = load i64, ptr %slot402, align 8
  %op3052 = add i64 %v3051, 0
  store i64 %op3052, ptr %slot405, align 8
  %v3053 = load i64, ptr %slot405, align 8
  %p3054 = inttoptr i64 %v3053 to ptr
  %ld3055 = load i64, ptr %p3054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3055, ptr %slot406, align 8
  %v3056 = load i64, ptr %slot406, align 8
  %cmp3057 = icmp ne i64 %v3056, 0
  %cv3058 = zext i1 %cmp3057 to i32
  store i32 %cv3058, ptr %slot407, align 8
  %v3059 = load i32, ptr %slot407, align 8
  %cv3060 = zext i32 %v3059 to i64
  %cond3061 = icmp ne i64 %cv3060, 0
  br i1 %cond3061, label %bb_rcmoveheader635, label %bb_rcmovenext635
bb_rcmoveheader635:
  %v3062 = load i64, ptr %slot406, align 8
  %op3063 = sub i64 %v3062, 16
  store i64 %op3063, ptr %slot408, align 8
  %v3064 = load i64, ptr %slot406, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  %rgep3066 = getelementptr i8, ptr %p3065, i64 -16
  %ld3067 = load i64, ptr %rgep3066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3067, ptr %slot409, align 8
  %v3068 = load i64, ptr %slot409, align 8
  %op3069 = and i64 %v3068, 5764607523034234881
  store i64 %op3069, ptr %slot410, align 8
  %v3070 = load i64, ptr %slot410, align 8
  %cmp3071 = icmp ne i64 %v3070, 0
  %cv3072 = zext i1 %cmp3071 to i32
  store i32 %cv3072, ptr %slot411, align 8
  %v3073 = load i32, ptr %slot411, align 8
  %cv3074 = zext i32 %v3073 to i64
  %cond3075 = icmp ne i64 %cv3074, 0
  br i1 %cond3075, label %bb_rcmoveslow632, label %bb_rcmovenext635
bb_rcmovenext635:
  %v3076 = load i64, ptr %slot402, align 8
  %v3077 = load i64, ptr %slot403, align 8
  %p3078 = inttoptr i64 %v3076 to ptr
  %p3079 = inttoptr i64 %v3077 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3079, ptr %p3078, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3080 = load i64, ptr %slot402, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  store i64 0, ptr %p3081, align 8, !alias.scope !3, !noalias !4
  %v3082 = load i64, ptr %slot402, align 8
  %op3083 = add i64 %v3082, 8
  store i64 %op3083, ptr %slot412, align 8
  %v3084 = load i64, ptr %slot412, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  store i64 0, ptr %p3085, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved632
bb_rcmoveslow632:
  %v3086 = load i64, ptr %slot32, align 8
  %v3087 = load i64, ptr %slot403, align 8
  %v3088 = load i64, ptr %slot402, align 8
  %v3089 = load i64, ptr %slot404, align 8
  %cv3090 = trunc i64 %v3089 to i32
  %call3091 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v3086, i64 %v3087, i64 %v3088, i32 %cv3090) nomerge, !dbg !134
  store i32 %call3091, ptr %slot413, align 8
  %v3092 = load i32, ptr %slot413, align 8
  %cv3093 = zext i32 %v3092 to i64
  %cond3094 = icmp ne i64 %cv3093, 0
  br i1 %cond3094, label %bb_rcsuccess643, label %bb_rcfailure643
bb_rcfailure643:
  %v3095 = load i64, ptr %slot32, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  %call3097 = call i32 @myl_rc_take_failure(ptr %p3096) nomerge, !dbg !134
  store i32 %call3097, ptr %slot414, align 8
  %v3098 = load i64, ptr %slot1, align 8
  %p3099 = inttoptr i64 %v3098 to ptr
  %v3100 = load i32, ptr %slot414, align 8
  %call3101 = call i32 @myl_qbe_rc_status(ptr %p3099, i32 %v3100) nomerge, !dbg !134
  store i32 %call3101, ptr %slot415, align 8
  br label %bb_failure
bb_rcsuccess643:
  br label %bb_rcmoved632
bb_rcmoved632:
  %v3102 = load i64, ptr %slot7, align 8
  %p3103 = inttoptr i64 %v3102 to ptr
  store i32 0, ptr %p3103, align 4, !alias.scope !3, !noalias !4
  %v3104 = load i64, ptr %slot10, align 8
  %p3105 = inttoptr i64 %v3104 to ptr
  store i32 2, ptr %p3105, align 4, !alias.scope !3, !noalias !4
  %v3106 = load i64, ptr %slot9, align 8
  %p3107 = inttoptr i64 %v3106 to ptr
  store i32 1, ptr %p3107, align 4, !alias.scope !3, !noalias !4
  %v3108 = load i64, ptr %slot14, align 8
  store i64 %v3108, ptr %slot416, align 8
  %v3109 = load i64, ptr %slot9, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  store i32 0, ptr %p3110, align 4, !alias.scope !3, !noalias !4
  %v3111 = load i64, ptr %slot7, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  %ld3113 = load i32, ptr %p3112, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3113, ptr %slot417, align 8
  %v3114 = load i32, ptr %slot417, align 8
  %cv3115 = zext i32 %v3114 to i64
  %cond3116 = icmp ne i64 %cv3115, 0
  br i1 %cond3116, label %bb_rcslotdrop653, label %bb_rcslotdone653
bb_rcslotdrop653:
  %v3117 = load i64, ptr %slot7, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  store i32 0, ptr %p3118, align 4, !alias.scope !3, !noalias !4
  %v3119 = load i64, ptr %slot12, align 8
  store i64 %v3119, ptr %slot418, align 8
  %v3120 = load i64, ptr %slot8, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  %ld3122 = load i32, ptr %p3121, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3122, ptr %slot419, align 8
  %v3123 = load i32, ptr %slot419, align 8
  %op3124 = and i32 %v3123, 28
  store i32 %op3124, ptr %slot420, align 8
  %v3125 = load i32, ptr %slot420, align 8
  %cv3126 = zext i32 %v3125 to i64
  %cond3127 = icmp ne i64 %cv3126, 0
  br i1 %cond3127, label %bb_rcslotrole653, label %bb_rcslotowner653
bb_rcslotrole653:
  %v3128 = load i64, ptr %slot32, align 8
  store i64 %v3128, ptr %slot421, align 8
  %v3129 = load i64, ptr %slot421, align 8
  %v3130 = load i64, ptr %slot418, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v3129, i64 %v3130) nomerge, !dbg !134
  br label %bb_rcslotdone653
bb_rcslotowner653:
  %v3131 = load i64, ptr %slot32, align 8
  store i64 %v3131, ptr %slot422, align 8
  %v3132 = load i64, ptr %slot422, align 8
  %v3133 = load i64, ptr %slot418, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v3132, i64 %v3133) nomerge, !dbg !134
  br label %bb_rcslotdone653
bb_rcslotdone653:
  %v3134 = load i64, ptr %slot416, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  %ret3136 = load { i64, i64 }, ptr %p3135, align 8
  ret { i64, i64 } %ret3136
bb_i31:
  %v3137 = load i64, ptr %slot20, align 8
  %p3138 = inttoptr i64 %v3137 to ptr
  store i64 0, ptr %p3138, align 8, !alias.scope !3, !noalias !4
  %v3139 = load i64, ptr %slot20, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  %ld3141 = load i64, ptr %p3140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3141, ptr %slot423, align 8
  %v3142 = load i64, ptr %slot423, align 8
  %cond3143 = icmp ne i64 %v3142, 0
  br i1 %cond3143, label %bb_success716, label %bb_failed716
bb_failed716:
  %v3144 = load i64, ptr %slot1, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  call void @myl_qbe_fail_assert(ptr %p3145) nomerge, !dbg !136
  unreachable
bb_success716:
  %p3146 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld3147 = load i64, ptr %p3146, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3147, ptr %slot424, align 8
  %v3148 = load i64, ptr %slot424, align 8
  %v3149 = load i64, ptr %slot20, align 8
  %p3150 = inttoptr i64 %v3149 to ptr
  store i64 %v3148, ptr %p3150, align 8, !alias.scope !3, !noalias !4
  %v3151 = load i64, ptr %slot20, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %ld3153 = load i64, ptr %p3152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3153, ptr %slot425, align 8
  %v3154 = load i64, ptr %slot425, align 8
  %v3155 = load i64, ptr %slot13, align 8
  %p3156 = inttoptr i64 %v3155 to ptr
  store i64 %v3154, ptr %p3156, align 8, !alias.scope !3, !noalias !4
  %v3157 = load i64, ptr %slot13, align 8
  store i64 %v3157, ptr %slot426, align 8
  %v3158 = load i64, ptr %slot14, align 8
  store i64 %v3158, ptr %slot427, align 8
  %v3159 = load i64, ptr %slot426, align 8
  %v3160 = load i64, ptr %slot427, align 8
  %p3161 = inttoptr i64 %v3159 to ptr
  %p3162 = inttoptr i64 %v3160 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3162, ptr %p3161, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3163 = load i64, ptr %slot10, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  store i32 2, ptr %p3164, align 4, !alias.scope !3, !noalias !4
  %v3165 = load i64, ptr %slot9, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  store i32 1, ptr %p3166, align 4, !alias.scope !3, !noalias !4
  %v3167 = load i64, ptr %slot12, align 8
  store i64 %v3167, ptr %slot428, align 8
  %v3168 = load i64, ptr %slot14, align 8
  store i64 %v3168, ptr %slot429, align 8
  %v3169 = load i64, ptr %slot429, align 8
  %v3170 = load i64, ptr %slot428, align 8
  %p3171 = inttoptr i64 %v3169 to ptr
  %p3172 = inttoptr i64 %v3170 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3172, ptr %p3171, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3173 = load i64, ptr %slot8, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  store i32 2, ptr %p3174, align 4, !alias.scope !3, !noalias !4
  %v3175 = load i64, ptr %slot10, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  %ld3177 = load i32, ptr %p3176, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3177, ptr %slot430, align 8
  %v3178 = load i32, ptr %slot430, align 8
  %v3179 = load i64, ptr %slot8, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  store i32 %v3178, ptr %p3180, align 4, !alias.scope !3, !noalias !4
  %v3181 = load i64, ptr %slot9, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  store i32 0, ptr %p3182, align 4, !alias.scope !3, !noalias !4
  %v3183 = load i64, ptr %slot7, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  store i32 1, ptr %p3184, align 4, !alias.scope !3, !noalias !4
  %v3185 = load i64, ptr %slot428, align 8
  %p3186 = inttoptr i64 %v3185 to ptr
  %ld3187 = load i64, ptr %p3186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3187, ptr %slot431, align 8
  %v3188 = load i64, ptr %slot431, align 8
  %v3189 = load i64, ptr %slot20, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  store i64 %v3188, ptr %p3190, align 8, !alias.scope !3, !noalias !4
  %v3191 = load i64, ptr %slot21, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  store i64 0, ptr %p3192, align 8, !alias.scope !3, !noalias !4
  %v3193 = load i64, ptr %slot24, align 8
  store i64 %v3193, ptr %slot432, align 8
  %v3194 = load i64, ptr %slot432, align 8
  %p3195 = inttoptr i64 %v3194 to ptr
  store i64 0, ptr %p3195, align 8, !alias.scope !3, !noalias !4
  %v3196 = load i64, ptr %slot432, align 8
  %p3198 = inttoptr i64 %v3196 to ptr
  %gep3199 = getelementptr i8, ptr %p3198, i64 8
  %op3197 = ptrtoint ptr %gep3199 to i64
  store i64 %op3197, ptr %slot433, align 8
  %v3200 = load i64, ptr %slot433, align 8
  %p3201 = inttoptr i64 %v3200 to ptr
  store i64 0, ptr %p3201, align 8, !alias.scope !3, !noalias !4
  %v3202 = load i64, ptr %slot11, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  store i32 1, ptr %p3203, align 4, !alias.scope !3, !noalias !4
  %v3204 = load i64, ptr %slot33, align 8
  store i64 %v3204, ptr %slot434, align 8
  %v3205 = load i64, ptr %slot20, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  %ld3207 = load i64, ptr %p3206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3207, ptr %slot435, align 8
  %v3208 = load i64, ptr %slot435, align 8
  %v3209 = load i64, ptr %slot13, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  store i64 %v3208, ptr %p3210, align 8, !alias.scope !3, !noalias !4
  %v3211 = load i64, ptr %slot13, align 8
  store i64 %v3211, ptr %slot436, align 8
  %v3212 = load i64, ptr %slot432, align 8
  %p3214 = inttoptr i64 %v3212 to ptr
  %gep3215 = getelementptr i8, ptr %p3214, i64 0
  %op3213 = ptrtoint ptr %gep3215 to i64
  store i64 %op3213, ptr %slot437, align 8
  %v3216 = load i64, ptr %slot20, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  %ld3218 = load i64, ptr %p3217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3218, ptr %slot438, align 8
  %v3219 = load i64, ptr %slot438, align 8
  %v3220 = load i64, ptr %slot13, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  store i64 %v3219, ptr %p3221, align 8, !alias.scope !3, !noalias !4
  %v3222 = load i64, ptr %slot13, align 8
  store i64 %v3222, ptr %slot439, align 8
  %v3223 = load i64, ptr %slot7, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %ld3225 = load i32, ptr %p3224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3225, ptr %slot440, align 8
  %v3226 = load i64, ptr %slot8, align 8
  %p3227 = inttoptr i64 %v3226 to ptr
  %ld3228 = load i32, ptr %p3227, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3228, ptr %slot441, align 8
  %v3229 = load i32, ptr %slot441, align 8
  %op3230 = and i32 %v3229, 24
  store i32 %op3230, ptr %slot441, align 8
  %v3231 = load i32, ptr %slot441, align 8
  %cmp3232 = icmp eq i32 %v3231, 0
  %cv3233 = zext i1 %cmp3232 to i32
  store i32 %cv3233, ptr %slot442, align 8
  %v3234 = load i32, ptr %slot440, align 8
  %v3235 = load i32, ptr %slot442, align 8
  %op3236 = and i32 %v3234, %v3235
  store i32 %op3236, ptr %slot443, align 8
  %v3237 = load i32, ptr %slot443, align 8
  %cv3238 = zext i32 %v3237 to i64
  %cond3239 = icmp ne i64 %cv3238, 0
  br i1 %cond3239, label %bb_rctake743, label %bb_rccopy743
bb_rctake743:
  %v3240 = load i64, ptr %slot14, align 8
  store i64 %v3240, ptr %slot444, align 8
  %v3241 = load i64, ptr %slot33, align 8
  store i64 %v3241, ptr %slot445, align 8
  %v3242 = load i64, ptr %slot439, align 8
  %v3243 = load i64, ptr %slot444, align 8
  %op3244 = sub i64 %v3242, %v3243
  store i64 %op3244, ptr %slot446, align 8
  %v3245 = load i64, ptr %slot444, align 8
  %v3246 = load i64, ptr %slot439, align 8
  %op3247 = sub i64 %v3245, %v3246
  store i64 %op3247, ptr %slot447, align 8
  %v3248 = load i64, ptr %slot446, align 8
  %cmp3249 = icmp ult i64 %v3248, 8
  %cv3250 = zext i1 %cmp3249 to i32
  store i32 %cv3250, ptr %slot448, align 8
  %v3251 = load i64, ptr %slot447, align 8
  %cmp3252 = icmp ult i64 %v3251, 8
  %cv3253 = zext i1 %cmp3252 to i32
  store i32 %cv3253, ptr %slot449, align 8
  %v3254 = load i32, ptr %slot448, align 8
  %v3255 = load i32, ptr %slot449, align 8
  %op3256 = or i32 %v3254, %v3255
  store i32 %op3256, ptr %slot450, align 8
  %v3257 = load i32, ptr %slot450, align 8
  %cv3258 = zext i32 %v3257 to i64
  %cond3259 = icmp ne i64 %cv3258, 0
  br i1 %cond3259, label %bb_rcmoveslow752, label %bb_rcmovecheck752
bb_rcmovecheck752:
  %v3260 = load i64, ptr %slot439, align 8
  %p3262 = inttoptr i64 %v3260 to ptr
  %gep3263 = getelementptr i8, ptr %p3262, i64 0
  %op3261 = ptrtoint ptr %gep3263 to i64
  store i64 %op3261, ptr %slot451, align 8
  %v3264 = load i64, ptr %slot451, align 8
  %p3265 = inttoptr i64 %v3264 to ptr
  %ld3266 = load i64, ptr %p3265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3266, ptr %slot452, align 8
  %v3267 = load i64, ptr %slot452, align 8
  %cmp3268 = icmp ne i64 %v3267, 0
  %cv3269 = zext i1 %cmp3268 to i32
  store i32 %cv3269, ptr %slot453, align 8
  %v3270 = load i32, ptr %slot453, align 8
  %cv3271 = zext i32 %v3270 to i64
  %cond3272 = icmp ne i64 %cv3271, 0
  br i1 %cond3272, label %bb_rcmoveheader760, label %bb_rcmovenext760
bb_rcmoveheader760:
  %v3273 = load i64, ptr %slot452, align 8
  %op3274 = sub i64 %v3273, 16
  store i64 %op3274, ptr %slot454, align 8
  %v3275 = load i64, ptr %slot452, align 8
  %p3276 = inttoptr i64 %v3275 to ptr
  %rgep3277 = getelementptr i8, ptr %p3276, i64 -16
  %ld3278 = load i64, ptr %rgep3277, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3278, ptr %slot455, align 8
  %v3279 = load i64, ptr %slot455, align 8
  %op3280 = and i64 %v3279, 5764607523034234881
  store i64 %op3280, ptr %slot456, align 8
  %v3281 = load i64, ptr %slot456, align 8
  %cmp3282 = icmp ne i64 %v3281, 0
  %cv3283 = zext i1 %cmp3282 to i32
  store i32 %cv3283, ptr %slot457, align 8
  %v3284 = load i32, ptr %slot457, align 8
  %cv3285 = zext i32 %v3284 to i64
  %cond3286 = icmp ne i64 %cv3285, 0
  br i1 %cond3286, label %bb_rcmoveslow752, label %bb_rcmovenext760
bb_rcmovenext760:
  %v3287 = load i64, ptr %slot439, align 8
  %v3288 = load i64, ptr %slot444, align 8
  %p3289 = inttoptr i64 %v3287 to ptr
  %p3290 = inttoptr i64 %v3288 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3290, ptr %p3289, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3291 = load i64, ptr %slot439, align 8
  %p3292 = inttoptr i64 %v3291 to ptr
  store i64 0, ptr %p3292, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved752
bb_rcmoveslow752:
  %v3293 = load i64, ptr %slot32, align 8
  %v3294 = load i64, ptr %slot444, align 8
  %v3295 = load i64, ptr %slot439, align 8
  %v3296 = load i64, ptr %slot445, align 8
  %cv3297 = trunc i64 %v3296 to i32
  %call3298 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v3293, i64 %v3294, i64 %v3295, i32 %cv3297) nomerge, !dbg !138
  store i32 %call3298, ptr %slot458, align 8
  %v3299 = load i32, ptr %slot458, align 8
  %cv3300 = zext i32 %v3299 to i64
  %cond3301 = icmp ne i64 %cv3300, 0
  br i1 %cond3301, label %bb_rcsuccess767, label %bb_rcfailure767
bb_rcfailure767:
  %v3302 = load i64, ptr %slot32, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  %call3304 = call i32 @myl_rc_take_failure(ptr %p3303) nomerge, !dbg !138
  store i32 %call3304, ptr %slot459, align 8
  %v3305 = load i64, ptr %slot1, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  %v3307 = load i32, ptr %slot459, align 8
  %call3308 = call i32 @myl_qbe_rc_status(ptr %p3306, i32 %v3307) nomerge, !dbg !138
  store i32 %call3308, ptr %slot460, align 8
  br label %bb_failure
bb_rcsuccess767:
  br label %bb_rcmoved752
bb_rcmoved752:
  %v3309 = load i64, ptr %slot7, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  store i32 0, ptr %p3310, align 4, !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot10, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  store i32 2, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  %v3313 = load i64, ptr %slot9, align 8
  %p3314 = inttoptr i64 %v3313 to ptr
  store i32 1, ptr %p3314, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared743
bb_rccopy743:
  %v3315 = load i64, ptr %slot14, align 8
  store i64 %v3315, ptr %slot461, align 8
  %v3316 = load i64, ptr %slot33, align 8
  store i64 %v3316, ptr %slot462, align 8
  %v3317 = load i64, ptr %slot439, align 8
  %p3318 = inttoptr i64 %v3317 to ptr
  %ld3319 = load i64, ptr %p3318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3319, ptr %slot463, align 8
  %v3320 = load i64, ptr %slot463, align 8
  %cmp3321 = icmp ne i64 %v3320, 0
  %cv3322 = zext i1 %cmp3321 to i32
  store i32 %cv3322, ptr %slot464, align 8
  %v3323 = load i32, ptr %slot464, align 8
  %cv3324 = zext i32 %v3323 to i64
  %cond3325 = icmp ne i64 %cv3324, 0
  br i1 %cond3325, label %bb_rcgnn776, label %bb_rcgplain776
bb_rcgnn776:
  %v3326 = load i64, ptr %slot463, align 8
  %op3327 = sub i64 %v3326, 16
  store i64 %op3327, ptr %slot465, align 8
  %v3328 = load i64, ptr %slot463, align 8
  %p3329 = inttoptr i64 %v3328 to ptr
  %rgep3330 = getelementptr i8, ptr %p3329, i64 -16
  %ld3331 = load i64, ptr %rgep3330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3331, ptr %slot466, align 8
  %v3332 = load i64, ptr %slot466, align 8
  %op3333 = and i64 %v3332, 4611686018427387906
  store i64 %op3333, ptr %slot467, align 8
  %v3334 = load i64, ptr %slot467, align 8
  %cmp3335 = icmp ne i64 %v3334, 0
  %cv3336 = zext i1 %cmp3335 to i32
  store i32 %cv3336, ptr %slot468, align 8
  %v3337 = load i32, ptr %slot468, align 8
  %cv3338 = zext i32 %v3337 to i64
  %cond3339 = icmp ne i64 %cv3338, 0
  br i1 %cond3339, label %bb_rcgspecial776, label %bb_rcginc776
bb_rcginc776:
  %v3340 = load i64, ptr %slot463, align 8
  %op3341 = sub i64 %v3340, 32
  store i64 %op3341, ptr %slot469, align 8
  %v3342 = load i64, ptr %slot463, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  %rgep3344 = getelementptr i8, ptr %p3343, i64 -32
  %ld3345 = load i64, ptr %rgep3344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3345, ptr %slot470, align 8
  %v3346 = load i64, ptr %slot470, align 8
  %op3347 = add i64 %v3346, 1
  store i64 %op3347, ptr %slot471, align 8
  %v3348 = load i64, ptr %slot471, align 8
  %cmp3349 = icmp eq i64 %v3348, 0
  %cv3350 = zext i1 %cmp3349 to i32
  store i32 %cv3350, ptr %slot472, align 8
  %v3351 = load i32, ptr %slot472, align 8
  %cv3352 = zext i32 %v3351 to i64
  %cond3353 = icmp ne i64 %cv3352, 0
  br i1 %cond3353, label %bb_rcglimit776, label %bb_rcgcapacity776
bb_rcglimit776:
  %v3354 = load i64, ptr %slot1, align 8
  %p3355 = inttoptr i64 %v3354 to ptr
  %call3356 = call i32 @myl_qbe_rc_status(ptr %p3355, i32 2) nomerge, !dbg !138
  store i32 %call3356, ptr %slot473, align 8
  br label %bb_failure
bb_rcgcapacity776:
  %v3357 = load i64, ptr %slot471, align 8
  %v3358 = load i64, ptr %slot463, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  %rgep3360 = getelementptr i8, ptr %p3359, i64 -32
  store i64 %v3357, ptr %rgep3360, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain776
bb_rcgspecial776:
  %v3361 = load i64, ptr %slot466, align 8
  %op3362 = and i64 %v3361, 4611686018427387904
  store i64 %op3362, ptr %slot474, align 8
  %v3363 = load i64, ptr %slot474, align 8
  %cmp3364 = icmp ne i64 %v3363, 0
  %cv3365 = zext i1 %cmp3364 to i32
  store i32 %cv3365, ptr %slot475, align 8
  %v3366 = load i32, ptr %slot475, align 8
  %cv3367 = zext i32 %v3366 to i64
  %cond3368 = icmp ne i64 %cv3367, 0
  br i1 %cond3368, label %bb_rcgslow776, label %bb_rcgplain776
bb_rcgslow776:
  %v3369 = load i64, ptr %slot32, align 8
  %v3370 = load i64, ptr %slot461, align 8
  %v3371 = load i64, ptr %slot439, align 8
  %v3372 = load i64, ptr %slot462, align 8
  %cv3373 = trunc i64 %v3372 to i32
  %call3374 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v3369, i64 %v3370, i64 %v3371, i32 %cv3373) nomerge, !dbg !138
  store i32 %call3374, ptr %slot476, align 8
  %v3375 = load i32, ptr %slot476, align 8
  %cv3376 = zext i32 %v3375 to i64
  %cond3377 = icmp ne i64 %cv3376, 0
  br i1 %cond3377, label %bb_rcsuccess790, label %bb_rcfailure790
bb_rcfailure790:
  %v3378 = load i64, ptr %slot32, align 8
  %p3379 = inttoptr i64 %v3378 to ptr
  %call3380 = call i32 @myl_rc_take_failure(ptr %p3379) nomerge, !dbg !138
  store i32 %call3380, ptr %slot477, align 8
  %v3381 = load i64, ptr %slot1, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  %v3383 = load i32, ptr %slot477, align 8
  %call3384 = call i32 @myl_qbe_rc_status(ptr %p3382, i32 %v3383) nomerge, !dbg !138
  store i32 %call3384, ptr %slot478, align 8
  br label %bb_failure
bb_rcsuccess790:
  br label %bb_rcgdone776
bb_rcgplain776:
  %v3385 = load i64, ptr %slot463, align 8
  %v3386 = load i64, ptr %slot461, align 8
  %p3387 = inttoptr i64 %v3386 to ptr
  store i64 %v3385, ptr %p3387, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone776
bb_rcgdone776:
  %v3388 = load i64, ptr %slot10, align 8
  %p3389 = inttoptr i64 %v3388 to ptr
  store i32 2, ptr %p3389, align 4, !alias.scope !3, !noalias !4
  %v3390 = load i64, ptr %slot9, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  store i32 1, ptr %p3391, align 4, !alias.scope !3, !noalias !4
  %v3392 = load i64, ptr %slot7, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  %ld3394 = load i32, ptr %p3393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3394, ptr %slot479, align 8
  %v3395 = load i32, ptr %slot479, align 8
  %cv3396 = zext i32 %v3395 to i64
  %cond3397 = icmp ne i64 %cv3396, 0
  br i1 %cond3397, label %bb_rcslotdrop797, label %bb_rcslotdone797
bb_rcslotdrop797:
  %v3398 = load i64, ptr %slot7, align 8
  %p3399 = inttoptr i64 %v3398 to ptr
  store i32 0, ptr %p3399, align 4, !alias.scope !3, !noalias !4
  %v3400 = load i64, ptr %slot12, align 8
  store i64 %v3400, ptr %slot480, align 8
  %v3401 = load i64, ptr %slot8, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  %ld3403 = load i32, ptr %p3402, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3403, ptr %slot481, align 8
  %v3404 = load i32, ptr %slot481, align 8
  %op3405 = and i32 %v3404, 28
  store i32 %op3405, ptr %slot482, align 8
  %v3406 = load i32, ptr %slot482, align 8
  %cv3407 = zext i32 %v3406 to i64
  %cond3408 = icmp ne i64 %cv3407, 0
  br i1 %cond3408, label %bb_rcslotrole797, label %bb_rcslotowner797
bb_rcslotrole797:
  %v3409 = load i64, ptr %slot32, align 8
  store i64 %v3409, ptr %slot483, align 8
  %v3410 = load i64, ptr %slot480, align 8
  %p3411 = inttoptr i64 %v3410 to ptr
  %ld3412 = load i64, ptr %p3411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3412, ptr %slot484, align 8
  %v3413 = load i64, ptr %slot484, align 8
  %cmp3414 = icmp ne i64 %v3413, 0
  %cv3415 = zext i1 %cmp3414 to i32
  store i32 %cv3415, ptr %slot485, align 8
  %v3416 = load i32, ptr %slot485, align 8
  %cv3417 = zext i32 %v3416 to i64
  %cond3418 = icmp ne i64 %cv3417, 0
  br i1 %cond3418, label %bb_rcgnn813, label %bb_rcgdone813
bb_rcgnn813:
  %v3419 = load i64, ptr %slot484, align 8
  %op3420 = sub i64 %v3419, 16
  store i64 %op3420, ptr %slot486, align 8
  %v3421 = load i64, ptr %slot484, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  %rgep3423 = getelementptr i8, ptr %p3422, i64 -16
  %ld3424 = load i64, ptr %rgep3423, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3424, ptr %slot487, align 8
  %v3425 = load i64, ptr %slot487, align 8
  %op3426 = and i64 %v3425, 4611686018427387906
  store i64 %op3426, ptr %slot488, align 8
  %v3427 = load i64, ptr %slot488, align 8
  %cmp3428 = icmp ne i64 %v3427, 0
  %cv3429 = zext i1 %cmp3428 to i32
  store i32 %cv3429, ptr %slot489, align 8
  %v3430 = load i32, ptr %slot489, align 8
  %cv3431 = zext i32 %v3430 to i64
  %cond3432 = icmp ne i64 %cv3431, 0
  br i1 %cond3432, label %bb_rcgclear813, label %bb_rcgcounted813
bb_rcgcounted813:
  %v3433 = load i64, ptr %slot484, align 8
  %op3434 = sub i64 %v3433, 24
  store i64 %op3434, ptr %slot490, align 8
  %v3435 = load i64, ptr %slot484, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  %rgep3437 = getelementptr i8, ptr %p3436, i64 -24
  %ld3438 = load i64, ptr %rgep3437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3438, ptr %slot491, align 8
  %v3439 = load i64, ptr %slot491, align 8
  %op3440 = sub i64 %v3439, 1
  store i64 %op3440, ptr %slot492, align 8
  %v3441 = load i64, ptr %slot492, align 8
  %cmp3442 = icmp eq i64 %v3441, 0
  %cv3443 = zext i1 %cmp3442 to i32
  store i32 %cv3443, ptr %slot493, align 8
  %v3444 = load i32, ptr %slot493, align 8
  %cv3445 = zext i32 %v3444 to i64
  %cond3446 = icmp ne i64 %cv3445, 0
  br i1 %cond3446, label %bb_rcglast813, label %bb_rcgdec813
bb_rcglast813:
  %v3447 = load i64, ptr %slot484, align 8
  %op3448 = sub i64 %v3447, 32
  store i64 %op3448, ptr %slot494, align 8
  %v3449 = load i64, ptr %slot484, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  %rgep3451 = getelementptr i8, ptr %p3450, i64 -32
  %ld3452 = load i64, ptr %rgep3451, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3452, ptr %slot495, align 8
  %v3453 = load i64, ptr %slot495, align 8
  %cmp3454 = icmp ne i64 %v3453, 0
  %cv3455 = zext i1 %cmp3454 to i32
  store i32 %cv3455, ptr %slot496, align 8
  %v3456 = load i32, ptr %slot496, align 8
  %cv3457 = zext i32 %v3456 to i64
  %cond3458 = icmp ne i64 %cv3457, 0
  br i1 %cond3458, label %bb_rcgdec813, label %bb_rcgslow813
bb_rcgslow813:
  %v3459 = load i64, ptr %slot483, align 8
  %v3460 = load i64, ptr %slot480, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3459, i64 %v3460) nomerge, !dbg !138
  br label %bb_rcgdone813
bb_rcgdec813:
  %v3461 = load i64, ptr %slot492, align 8
  %v3462 = load i64, ptr %slot484, align 8
  %p3463 = inttoptr i64 %v3462 to ptr
  %rgep3464 = getelementptr i8, ptr %p3463, i64 -24
  store i64 %v3461, ptr %rgep3464, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear813
bb_rcgclear813:
  %v3465 = load i64, ptr %slot480, align 8
  %p3466 = inttoptr i64 %v3465 to ptr
  store i64 0, ptr %p3466, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone813
bb_rcgdone813:
  br label %bb_rcslotdone797
bb_rcslotowner797:
  %v3467 = load i64, ptr %slot32, align 8
  store i64 %v3467, ptr %slot497, align 8
  %v3468 = load i64, ptr %slot480, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  %ld3470 = load i64, ptr %p3469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3470, ptr %slot498, align 8
  %v3471 = load i64, ptr %slot498, align 8
  %cmp3472 = icmp ne i64 %v3471, 0
  %cv3473 = zext i1 %cmp3472 to i32
  store i32 %cv3473, ptr %slot499, align 8
  %v3474 = load i32, ptr %slot499, align 8
  %cv3475 = zext i32 %v3474 to i64
  %cond3476 = icmp ne i64 %cv3475, 0
  br i1 %cond3476, label %bb_rcgnn828, label %bb_rcgdone828
bb_rcgnn828:
  %v3477 = load i64, ptr %slot498, align 8
  %op3478 = sub i64 %v3477, 16
  store i64 %op3478, ptr %slot500, align 8
  %v3479 = load i64, ptr %slot498, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  %rgep3481 = getelementptr i8, ptr %p3480, i64 -16
  %ld3482 = load i64, ptr %rgep3481, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3482, ptr %slot501, align 8
  %v3483 = load i64, ptr %slot501, align 8
  %op3484 = and i64 %v3483, 4611686018427387906
  store i64 %op3484, ptr %slot502, align 8
  %v3485 = load i64, ptr %slot502, align 8
  %cmp3486 = icmp ne i64 %v3485, 0
  %cv3487 = zext i1 %cmp3486 to i32
  store i32 %cv3487, ptr %slot503, align 8
  %v3488 = load i32, ptr %slot503, align 8
  %cv3489 = zext i32 %v3488 to i64
  %cond3490 = icmp ne i64 %cv3489, 0
  br i1 %cond3490, label %bb_rcgclear828, label %bb_rcgcounted828
bb_rcgcounted828:
  %v3491 = load i64, ptr %slot498, align 8
  %op3492 = sub i64 %v3491, 32
  store i64 %op3492, ptr %slot504, align 8
  %v3493 = load i64, ptr %slot498, align 8
  %p3494 = inttoptr i64 %v3493 to ptr
  %rgep3495 = getelementptr i8, ptr %p3494, i64 -32
  %ld3496 = load i64, ptr %rgep3495, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3496, ptr %slot505, align 8
  %v3497 = load i64, ptr %slot505, align 8
  %op3498 = sub i64 %v3497, 1
  store i64 %op3498, ptr %slot506, align 8
  %v3499 = load i64, ptr %slot506, align 8
  %cmp3500 = icmp eq i64 %v3499, 0
  %cv3501 = zext i1 %cmp3500 to i32
  store i32 %cv3501, ptr %slot507, align 8
  %v3502 = load i32, ptr %slot507, align 8
  %cv3503 = zext i32 %v3502 to i64
  %cond3504 = icmp ne i64 %cv3503, 0
  br i1 %cond3504, label %bb_rcglast828, label %bb_rcgdec828
bb_rcglast828:
  %v3505 = load i64, ptr %slot498, align 8
  %op3506 = sub i64 %v3505, 24
  store i64 %op3506, ptr %slot508, align 8
  %v3507 = load i64, ptr %slot498, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %rgep3509 = getelementptr i8, ptr %p3508, i64 -24
  %ld3510 = load i64, ptr %rgep3509, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3510, ptr %slot509, align 8
  %v3511 = load i64, ptr %slot509, align 8
  %cmp3512 = icmp ne i64 %v3511, 0
  %cv3513 = zext i1 %cmp3512 to i32
  store i32 %cv3513, ptr %slot510, align 8
  %v3514 = load i32, ptr %slot510, align 8
  %cv3515 = zext i32 %v3514 to i64
  %cond3516 = icmp ne i64 %cv3515, 0
  br i1 %cond3516, label %bb_rcgdec828, label %bb_rcgslow828
bb_rcgslow828:
  %v3517 = load i64, ptr %slot497, align 8
  %v3518 = load i64, ptr %slot480, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3517, i64 %v3518) nomerge, !dbg !138
  br label %bb_rcgdone828
bb_rcgdec828:
  %v3519 = load i64, ptr %slot506, align 8
  %v3520 = load i64, ptr %slot498, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  %rgep3522 = getelementptr i8, ptr %p3521, i64 -32
  store i64 %v3519, ptr %rgep3522, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear828
bb_rcgclear828:
  %v3523 = load i64, ptr %slot480, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  store i64 0, ptr %p3524, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone828
bb_rcgdone828:
  br label %bb_rcslotdone797
bb_rcslotdone797:
  br label %bb_rcprepared743
bb_rcprepared743:
  %v3525 = load i64, ptr %slot14, align 8
  store i64 %v3525, ptr %slot511, align 8
  %v3526 = load i64, ptr %slot511, align 8
  %v3527 = load i64, ptr %slot437, align 8
  %p3528 = inttoptr i64 %v3526 to ptr
  %p3529 = inttoptr i64 %v3527 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3529, ptr %p3528, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3530 = load i64, ptr %slot9, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  store i32 0, ptr %p3531, align 4, !alias.scope !3, !noalias !4
  %v3532 = load i64, ptr %slot21, align 8
  store i64 %v3532, ptr %slot512, align 8
  %v3533 = load i64, ptr %slot432, align 8
  %p3535 = inttoptr i64 %v3533 to ptr
  %gep3536 = getelementptr i8, ptr %p3535, i64 8
  %op3534 = ptrtoint ptr %gep3536 to i64
  store i64 %op3534, ptr %slot513, align 8
  %v3537 = load i64, ptr %slot512, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  %ld3539 = load i32, ptr %p3538, align 4, !alias.scope !3, !noalias !4
  %ext3540 = zext i32 %ld3539 to i64
  store i64 %ext3540, ptr %slot514, align 8
  %v3541 = load i64, ptr %slot514, align 8
  %cv3542 = trunc i64 %v3541 to i32
  %v3543 = load i64, ptr %slot513, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  store i32 %cv3542, ptr %p3544, align 4, !alias.scope !3, !noalias !4
  %v3545 = load i64, ptr %slot432, align 8
  %v3546 = load i64, ptr %slot20, align 8
  %p3547 = inttoptr i64 %v3546 to ptr
  store i64 %v3545, ptr %p3547, align 8, !alias.scope !3, !noalias !4
  %v3548 = load i64, ptr %slot20, align 8
  %p3549 = inttoptr i64 %v3548 to ptr
  %ld3550 = load i64, ptr %p3549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3550, ptr %slot515, align 8
  %v3551 = load i64, ptr %slot12, align 8
  store i64 %v3551, ptr %slot516, align 8
  %v3552 = load i64, ptr %slot515, align 8
  %v3553 = load i64, ptr %slot516, align 8
  %p3554 = inttoptr i64 %v3552 to ptr
  %p3555 = inttoptr i64 %v3553 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3555, ptr %p3554, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3556 = load i64, ptr %slot8, align 8
  %p3557 = inttoptr i64 %v3556 to ptr
  store i32 2, ptr %p3557, align 4, !alias.scope !3, !noalias !4
  %v3558 = load i64, ptr %slot7, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  store i32 1, ptr %p3559, align 4, !alias.scope !3, !noalias !4
  %v3560 = load i64, ptr %slot516, align 8
  %v3561 = load i64, ptr %slot20, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  store i64 %v3560, ptr %p3562, align 8, !alias.scope !3, !noalias !4
  %v3563 = load i64, ptr %slot20, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %ld3565 = load i64, ptr %p3564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3565, ptr %slot517, align 8
  %v3566 = load i64, ptr %slot20, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  %ld3568 = load i64, ptr %p3567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3568, ptr %slot518, align 8
  %v3569 = load i64, ptr %slot14, align 8
  store i64 %v3569, ptr %slot519, align 8
  %v3570 = load i64, ptr %slot33, align 8
  store i64 %v3570, ptr %slot520, align 8
  %v3571 = load i64, ptr %slot518, align 8
  %op3572 = add i64 %v3571, 0
  store i64 %op3572, ptr %slot521, align 8
  %v3573 = load i64, ptr %slot521, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  %ld3575 = load i64, ptr %p3574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3575, ptr %slot522, align 8
  %v3576 = load i64, ptr %slot522, align 8
  %cmp3577 = icmp ne i64 %v3576, 0
  %cv3578 = zext i1 %cmp3577 to i32
  store i32 %cv3578, ptr %slot523, align 8
  %v3579 = load i32, ptr %slot523, align 8
  %cv3580 = zext i32 %v3579 to i64
  %cond3581 = icmp ne i64 %cv3580, 0
  br i1 %cond3581, label %bb_rcmoveheader848, label %bb_rcmovenext848
bb_rcmoveheader848:
  %v3582 = load i64, ptr %slot522, align 8
  %op3583 = sub i64 %v3582, 16
  store i64 %op3583, ptr %slot524, align 8
  %v3584 = load i64, ptr %slot522, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  %rgep3586 = getelementptr i8, ptr %p3585, i64 -16
  %ld3587 = load i64, ptr %rgep3586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3587, ptr %slot525, align 8
  %v3588 = load i64, ptr %slot525, align 8
  %op3589 = and i64 %v3588, 5764607523034234881
  store i64 %op3589, ptr %slot526, align 8
  %v3590 = load i64, ptr %slot526, align 8
  %cmp3591 = icmp ne i64 %v3590, 0
  %cv3592 = zext i1 %cmp3591 to i32
  store i32 %cv3592, ptr %slot527, align 8
  %v3593 = load i32, ptr %slot527, align 8
  %cv3594 = zext i32 %v3593 to i64
  %cond3595 = icmp ne i64 %cv3594, 0
  br i1 %cond3595, label %bb_rcmoveslow845, label %bb_rcmovenext848
bb_rcmovenext848:
  %v3596 = load i64, ptr %slot518, align 8
  %v3597 = load i64, ptr %slot519, align 8
  %p3598 = inttoptr i64 %v3596 to ptr
  %p3599 = inttoptr i64 %v3597 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3599, ptr %p3598, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3600 = load i64, ptr %slot518, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  store i64 0, ptr %p3601, align 8, !alias.scope !3, !noalias !4
  %v3602 = load i64, ptr %slot518, align 8
  %op3603 = add i64 %v3602, 8
  store i64 %op3603, ptr %slot528, align 8
  %v3604 = load i64, ptr %slot528, align 8
  %p3605 = inttoptr i64 %v3604 to ptr
  store i64 0, ptr %p3605, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved845
bb_rcmoveslow845:
  %v3606 = load i64, ptr %slot32, align 8
  %v3607 = load i64, ptr %slot519, align 8
  %v3608 = load i64, ptr %slot518, align 8
  %v3609 = load i64, ptr %slot520, align 8
  %cv3610 = trunc i64 %v3609 to i32
  %call3611 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v3606, i64 %v3607, i64 %v3608, i32 %cv3610) nomerge, !dbg !140
  store i32 %call3611, ptr %slot529, align 8
  %v3612 = load i32, ptr %slot529, align 8
  %cv3613 = zext i32 %v3612 to i64
  %cond3614 = icmp ne i64 %cv3613, 0
  br i1 %cond3614, label %bb_rcsuccess856, label %bb_rcfailure856
bb_rcfailure856:
  %v3615 = load i64, ptr %slot32, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  %call3617 = call i32 @myl_rc_take_failure(ptr %p3616) nomerge, !dbg !140
  store i32 %call3617, ptr %slot530, align 8
  %v3618 = load i64, ptr %slot1, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  %v3620 = load i32, ptr %slot530, align 8
  %call3621 = call i32 @myl_qbe_rc_status(ptr %p3619, i32 %v3620) nomerge, !dbg !140
  store i32 %call3621, ptr %slot531, align 8
  br label %bb_failure
bb_rcsuccess856:
  br label %bb_rcmoved845
bb_rcmoved845:
  %v3622 = load i64, ptr %slot7, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  store i32 0, ptr %p3623, align 4, !alias.scope !3, !noalias !4
  %v3624 = load i64, ptr %slot10, align 8
  %p3625 = inttoptr i64 %v3624 to ptr
  store i32 2, ptr %p3625, align 4, !alias.scope !3, !noalias !4
  %v3626 = load i64, ptr %slot9, align 8
  %p3627 = inttoptr i64 %v3626 to ptr
  store i32 1, ptr %p3627, align 4, !alias.scope !3, !noalias !4
  %v3628 = load i64, ptr %slot14, align 8
  store i64 %v3628, ptr %slot532, align 8
  %v3629 = load i64, ptr %slot9, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  store i32 0, ptr %p3630, align 4, !alias.scope !3, !noalias !4
  %v3631 = load i64, ptr %slot7, align 8
  %p3632 = inttoptr i64 %v3631 to ptr
  %ld3633 = load i32, ptr %p3632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3633, ptr %slot533, align 8
  %v3634 = load i32, ptr %slot533, align 8
  %cv3635 = zext i32 %v3634 to i64
  %cond3636 = icmp ne i64 %cv3635, 0
  br i1 %cond3636, label %bb_rcslotdrop866, label %bb_rcslotdone866
bb_rcslotdrop866:
  %v3637 = load i64, ptr %slot7, align 8
  %p3638 = inttoptr i64 %v3637 to ptr
  store i32 0, ptr %p3638, align 4, !alias.scope !3, !noalias !4
  %v3639 = load i64, ptr %slot12, align 8
  store i64 %v3639, ptr %slot534, align 8
  %v3640 = load i64, ptr %slot8, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %ld3642 = load i32, ptr %p3641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3642, ptr %slot535, align 8
  %v3643 = load i32, ptr %slot535, align 8
  %op3644 = and i32 %v3643, 28
  store i32 %op3644, ptr %slot536, align 8
  %v3645 = load i32, ptr %slot536, align 8
  %cv3646 = zext i32 %v3645 to i64
  %cond3647 = icmp ne i64 %cv3646, 0
  br i1 %cond3647, label %bb_rcslotrole866, label %bb_rcslotowner866
bb_rcslotrole866:
  %v3648 = load i64, ptr %slot32, align 8
  store i64 %v3648, ptr %slot537, align 8
  %v3649 = load i64, ptr %slot537, align 8
  %v3650 = load i64, ptr %slot534, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v3649, i64 %v3650) nomerge, !dbg !140
  br label %bb_rcslotdone866
bb_rcslotowner866:
  %v3651 = load i64, ptr %slot32, align 8
  store i64 %v3651, ptr %slot538, align 8
  %v3652 = load i64, ptr %slot538, align 8
  %v3653 = load i64, ptr %slot534, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v3652, i64 %v3653) nomerge, !dbg !140
  br label %bb_rcslotdone866
bb_rcslotdone866:
  %v3654 = load i64, ptr %slot532, align 8
  %p3655 = inttoptr i64 %v3654 to ptr
  %ret3656 = load { i64, i64 }, ptr %p3655, align 8
  ret { i64, i64 } %ret3656
bb_i37:
  %v3657 = load i64, ptr %slot20, align 8
  %p3658 = inttoptr i64 %v3657 to ptr
  store i64 0, ptr %p3658, align 8, !alias.scope !3, !noalias !4
  %v3659 = load i64, ptr %slot20, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  %ld3661 = load i64, ptr %p3660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3661, ptr %slot539, align 8
  %v3662 = load i64, ptr %slot539, align 8
  %cond3663 = icmp ne i64 %v3662, 0
  br i1 %cond3663, label %bb_success929, label %bb_failed929
bb_failed929:
  %v3664 = load i64, ptr %slot1, align 8
  %p3665 = inttoptr i64 %v3664 to ptr
  call void @myl_qbe_fail_assert(ptr %p3665) nomerge, !dbg !142
  unreachable
bb_success929:
  %p3666 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld3667 = load i64, ptr %p3666, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3667, ptr %slot540, align 8
  %v3668 = load i64, ptr %slot540, align 8
  %v3669 = load i64, ptr %slot20, align 8
  %p3670 = inttoptr i64 %v3669 to ptr
  store i64 %v3668, ptr %p3670, align 8, !alias.scope !3, !noalias !4
  %v3671 = load i64, ptr %slot20, align 8
  %p3672 = inttoptr i64 %v3671 to ptr
  %ld3673 = load i64, ptr %p3672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3673, ptr %slot541, align 8
  %v3674 = load i64, ptr %slot541, align 8
  %v3675 = load i64, ptr %slot13, align 8
  %p3676 = inttoptr i64 %v3675 to ptr
  store i64 %v3674, ptr %p3676, align 8, !alias.scope !3, !noalias !4
  %v3677 = load i64, ptr %slot13, align 8
  store i64 %v3677, ptr %slot542, align 8
  %v3678 = load i64, ptr %slot14, align 8
  store i64 %v3678, ptr %slot543, align 8
  %v3679 = load i64, ptr %slot542, align 8
  %v3680 = load i64, ptr %slot543, align 8
  %p3681 = inttoptr i64 %v3679 to ptr
  %p3682 = inttoptr i64 %v3680 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3682, ptr %p3681, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3683 = load i64, ptr %slot10, align 8
  %p3684 = inttoptr i64 %v3683 to ptr
  store i32 2, ptr %p3684, align 4, !alias.scope !3, !noalias !4
  %v3685 = load i64, ptr %slot9, align 8
  %p3686 = inttoptr i64 %v3685 to ptr
  store i32 1, ptr %p3686, align 4, !alias.scope !3, !noalias !4
  %v3687 = load i64, ptr %slot12, align 8
  store i64 %v3687, ptr %slot544, align 8
  %v3688 = load i64, ptr %slot14, align 8
  store i64 %v3688, ptr %slot545, align 8
  %v3689 = load i64, ptr %slot545, align 8
  %v3690 = load i64, ptr %slot544, align 8
  %p3691 = inttoptr i64 %v3689 to ptr
  %p3692 = inttoptr i64 %v3690 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3692, ptr %p3691, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3693 = load i64, ptr %slot8, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  store i32 2, ptr %p3694, align 4, !alias.scope !3, !noalias !4
  %v3695 = load i64, ptr %slot10, align 8
  %p3696 = inttoptr i64 %v3695 to ptr
  %ld3697 = load i32, ptr %p3696, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3697, ptr %slot546, align 8
  %v3698 = load i32, ptr %slot546, align 8
  %v3699 = load i64, ptr %slot8, align 8
  %p3700 = inttoptr i64 %v3699 to ptr
  store i32 %v3698, ptr %p3700, align 4, !alias.scope !3, !noalias !4
  %v3701 = load i64, ptr %slot9, align 8
  %p3702 = inttoptr i64 %v3701 to ptr
  store i32 0, ptr %p3702, align 4, !alias.scope !3, !noalias !4
  %v3703 = load i64, ptr %slot7, align 8
  %p3704 = inttoptr i64 %v3703 to ptr
  store i32 1, ptr %p3704, align 4, !alias.scope !3, !noalias !4
  %v3705 = load i64, ptr %slot544, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  %ld3707 = load i64, ptr %p3706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3707, ptr %slot547, align 8
  %v3708 = load i64, ptr %slot547, align 8
  %v3709 = load i64, ptr %slot20, align 8
  %p3710 = inttoptr i64 %v3709 to ptr
  store i64 %v3708, ptr %p3710, align 8, !alias.scope !3, !noalias !4
  %v3711 = load i64, ptr %slot21, align 8
  %p3712 = inttoptr i64 %v3711 to ptr
  store i64 0, ptr %p3712, align 8, !alias.scope !3, !noalias !4
  %v3713 = load i64, ptr %slot25, align 8
  store i64 %v3713, ptr %slot548, align 8
  %v3714 = load i64, ptr %slot548, align 8
  %p3715 = inttoptr i64 %v3714 to ptr
  store i64 0, ptr %p3715, align 8, !alias.scope !3, !noalias !4
  %v3716 = load i64, ptr %slot548, align 8
  %p3718 = inttoptr i64 %v3716 to ptr
  %gep3719 = getelementptr i8, ptr %p3718, i64 8
  %op3717 = ptrtoint ptr %gep3719 to i64
  store i64 %op3717, ptr %slot549, align 8
  %v3720 = load i64, ptr %slot549, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  store i64 0, ptr %p3721, align 8, !alias.scope !3, !noalias !4
  %v3722 = load i64, ptr %slot11, align 8
  %p3723 = inttoptr i64 %v3722 to ptr
  store i32 1, ptr %p3723, align 4, !alias.scope !3, !noalias !4
  %v3724 = load i64, ptr %slot33, align 8
  store i64 %v3724, ptr %slot550, align 8
  %v3725 = load i64, ptr %slot20, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  %ld3727 = load i64, ptr %p3726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3727, ptr %slot551, align 8
  %v3728 = load i64, ptr %slot551, align 8
  %v3729 = load i64, ptr %slot13, align 8
  %p3730 = inttoptr i64 %v3729 to ptr
  store i64 %v3728, ptr %p3730, align 8, !alias.scope !3, !noalias !4
  %v3731 = load i64, ptr %slot13, align 8
  store i64 %v3731, ptr %slot552, align 8
  %v3732 = load i64, ptr %slot548, align 8
  %p3734 = inttoptr i64 %v3732 to ptr
  %gep3735 = getelementptr i8, ptr %p3734, i64 0
  %op3733 = ptrtoint ptr %gep3735 to i64
  store i64 %op3733, ptr %slot553, align 8
  %v3736 = load i64, ptr %slot20, align 8
  %p3737 = inttoptr i64 %v3736 to ptr
  %ld3738 = load i64, ptr %p3737, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3738, ptr %slot554, align 8
  %v3739 = load i64, ptr %slot554, align 8
  %v3740 = load i64, ptr %slot13, align 8
  %p3741 = inttoptr i64 %v3740 to ptr
  store i64 %v3739, ptr %p3741, align 8, !alias.scope !3, !noalias !4
  %v3742 = load i64, ptr %slot13, align 8
  store i64 %v3742, ptr %slot555, align 8
  %v3743 = load i64, ptr %slot7, align 8
  %p3744 = inttoptr i64 %v3743 to ptr
  %ld3745 = load i32, ptr %p3744, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3745, ptr %slot556, align 8
  %v3746 = load i64, ptr %slot8, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  %ld3748 = load i32, ptr %p3747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3748, ptr %slot557, align 8
  %v3749 = load i32, ptr %slot557, align 8
  %op3750 = and i32 %v3749, 24
  store i32 %op3750, ptr %slot557, align 8
  %v3751 = load i32, ptr %slot557, align 8
  %cmp3752 = icmp eq i32 %v3751, 0
  %cv3753 = zext i1 %cmp3752 to i32
  store i32 %cv3753, ptr %slot558, align 8
  %v3754 = load i32, ptr %slot556, align 8
  %v3755 = load i32, ptr %slot558, align 8
  %op3756 = and i32 %v3754, %v3755
  store i32 %op3756, ptr %slot559, align 8
  %v3757 = load i32, ptr %slot559, align 8
  %cv3758 = zext i32 %v3757 to i64
  %cond3759 = icmp ne i64 %cv3758, 0
  br i1 %cond3759, label %bb_rctake956, label %bb_rccopy956
bb_rctake956:
  %v3760 = load i64, ptr %slot14, align 8
  store i64 %v3760, ptr %slot560, align 8
  %v3761 = load i64, ptr %slot33, align 8
  store i64 %v3761, ptr %slot561, align 8
  %v3762 = load i64, ptr %slot555, align 8
  %v3763 = load i64, ptr %slot560, align 8
  %op3764 = sub i64 %v3762, %v3763
  store i64 %op3764, ptr %slot562, align 8
  %v3765 = load i64, ptr %slot560, align 8
  %v3766 = load i64, ptr %slot555, align 8
  %op3767 = sub i64 %v3765, %v3766
  store i64 %op3767, ptr %slot563, align 8
  %v3768 = load i64, ptr %slot562, align 8
  %cmp3769 = icmp ult i64 %v3768, 8
  %cv3770 = zext i1 %cmp3769 to i32
  store i32 %cv3770, ptr %slot564, align 8
  %v3771 = load i64, ptr %slot563, align 8
  %cmp3772 = icmp ult i64 %v3771, 8
  %cv3773 = zext i1 %cmp3772 to i32
  store i32 %cv3773, ptr %slot565, align 8
  %v3774 = load i32, ptr %slot564, align 8
  %v3775 = load i32, ptr %slot565, align 8
  %op3776 = or i32 %v3774, %v3775
  store i32 %op3776, ptr %slot566, align 8
  %v3777 = load i32, ptr %slot566, align 8
  %cv3778 = zext i32 %v3777 to i64
  %cond3779 = icmp ne i64 %cv3778, 0
  br i1 %cond3779, label %bb_rcmoveslow965, label %bb_rcmovecheck965
bb_rcmovecheck965:
  %v3780 = load i64, ptr %slot555, align 8
  %p3782 = inttoptr i64 %v3780 to ptr
  %gep3783 = getelementptr i8, ptr %p3782, i64 0
  %op3781 = ptrtoint ptr %gep3783 to i64
  store i64 %op3781, ptr %slot567, align 8
  %v3784 = load i64, ptr %slot567, align 8
  %p3785 = inttoptr i64 %v3784 to ptr
  %ld3786 = load i64, ptr %p3785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3786, ptr %slot568, align 8
  %v3787 = load i64, ptr %slot568, align 8
  %cmp3788 = icmp ne i64 %v3787, 0
  %cv3789 = zext i1 %cmp3788 to i32
  store i32 %cv3789, ptr %slot569, align 8
  %v3790 = load i32, ptr %slot569, align 8
  %cv3791 = zext i32 %v3790 to i64
  %cond3792 = icmp ne i64 %cv3791, 0
  br i1 %cond3792, label %bb_rcmoveheader973, label %bb_rcmovenext973
bb_rcmoveheader973:
  %v3793 = load i64, ptr %slot568, align 8
  %op3794 = sub i64 %v3793, 16
  store i64 %op3794, ptr %slot570, align 8
  %v3795 = load i64, ptr %slot568, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  %rgep3797 = getelementptr i8, ptr %p3796, i64 -16
  %ld3798 = load i64, ptr %rgep3797, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3798, ptr %slot571, align 8
  %v3799 = load i64, ptr %slot571, align 8
  %op3800 = and i64 %v3799, 5764607523034234881
  store i64 %op3800, ptr %slot572, align 8
  %v3801 = load i64, ptr %slot572, align 8
  %cmp3802 = icmp ne i64 %v3801, 0
  %cv3803 = zext i1 %cmp3802 to i32
  store i32 %cv3803, ptr %slot573, align 8
  %v3804 = load i32, ptr %slot573, align 8
  %cv3805 = zext i32 %v3804 to i64
  %cond3806 = icmp ne i64 %cv3805, 0
  br i1 %cond3806, label %bb_rcmoveslow965, label %bb_rcmovenext973
bb_rcmovenext973:
  %v3807 = load i64, ptr %slot555, align 8
  %v3808 = load i64, ptr %slot560, align 8
  %p3809 = inttoptr i64 %v3807 to ptr
  %p3810 = inttoptr i64 %v3808 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3810, ptr %p3809, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3811 = load i64, ptr %slot555, align 8
  %p3812 = inttoptr i64 %v3811 to ptr
  store i64 0, ptr %p3812, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved965
bb_rcmoveslow965:
  %v3813 = load i64, ptr %slot32, align 8
  %v3814 = load i64, ptr %slot560, align 8
  %v3815 = load i64, ptr %slot555, align 8
  %v3816 = load i64, ptr %slot561, align 8
  %cv3817 = trunc i64 %v3816 to i32
  %call3818 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v3813, i64 %v3814, i64 %v3815, i32 %cv3817) nomerge, !dbg !144
  store i32 %call3818, ptr %slot574, align 8
  %v3819 = load i32, ptr %slot574, align 8
  %cv3820 = zext i32 %v3819 to i64
  %cond3821 = icmp ne i64 %cv3820, 0
  br i1 %cond3821, label %bb_rcsuccess980, label %bb_rcfailure980
bb_rcfailure980:
  %v3822 = load i64, ptr %slot32, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %call3824 = call i32 @myl_rc_take_failure(ptr %p3823) nomerge, !dbg !144
  store i32 %call3824, ptr %slot575, align 8
  %v3825 = load i64, ptr %slot1, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  %v3827 = load i32, ptr %slot575, align 8
  %call3828 = call i32 @myl_qbe_rc_status(ptr %p3826, i32 %v3827) nomerge, !dbg !144
  store i32 %call3828, ptr %slot576, align 8
  br label %bb_failure
bb_rcsuccess980:
  br label %bb_rcmoved965
bb_rcmoved965:
  %v3829 = load i64, ptr %slot7, align 8
  %p3830 = inttoptr i64 %v3829 to ptr
  store i32 0, ptr %p3830, align 4, !alias.scope !3, !noalias !4
  %v3831 = load i64, ptr %slot10, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  store i32 2, ptr %p3832, align 4, !alias.scope !3, !noalias !4
  %v3833 = load i64, ptr %slot9, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  store i32 1, ptr %p3834, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared956
bb_rccopy956:
  %v3835 = load i64, ptr %slot14, align 8
  store i64 %v3835, ptr %slot577, align 8
  %v3836 = load i64, ptr %slot33, align 8
  store i64 %v3836, ptr %slot578, align 8
  %v3837 = load i64, ptr %slot555, align 8
  %p3838 = inttoptr i64 %v3837 to ptr
  %ld3839 = load i64, ptr %p3838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3839, ptr %slot579, align 8
  %v3840 = load i64, ptr %slot579, align 8
  %cmp3841 = icmp ne i64 %v3840, 0
  %cv3842 = zext i1 %cmp3841 to i32
  store i32 %cv3842, ptr %slot580, align 8
  %v3843 = load i32, ptr %slot580, align 8
  %cv3844 = zext i32 %v3843 to i64
  %cond3845 = icmp ne i64 %cv3844, 0
  br i1 %cond3845, label %bb_rcgnn989, label %bb_rcgplain989
bb_rcgnn989:
  %v3846 = load i64, ptr %slot579, align 8
  %op3847 = sub i64 %v3846, 16
  store i64 %op3847, ptr %slot581, align 8
  %v3848 = load i64, ptr %slot579, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  %rgep3850 = getelementptr i8, ptr %p3849, i64 -16
  %ld3851 = load i64, ptr %rgep3850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3851, ptr %slot582, align 8
  %v3852 = load i64, ptr %slot582, align 8
  %op3853 = and i64 %v3852, 4611686018427387906
  store i64 %op3853, ptr %slot583, align 8
  %v3854 = load i64, ptr %slot583, align 8
  %cmp3855 = icmp ne i64 %v3854, 0
  %cv3856 = zext i1 %cmp3855 to i32
  store i32 %cv3856, ptr %slot584, align 8
  %v3857 = load i32, ptr %slot584, align 8
  %cv3858 = zext i32 %v3857 to i64
  %cond3859 = icmp ne i64 %cv3858, 0
  br i1 %cond3859, label %bb_rcgspecial989, label %bb_rcginc989
bb_rcginc989:
  %v3860 = load i64, ptr %slot579, align 8
  %op3861 = sub i64 %v3860, 32
  store i64 %op3861, ptr %slot585, align 8
  %v3862 = load i64, ptr %slot579, align 8
  %p3863 = inttoptr i64 %v3862 to ptr
  %rgep3864 = getelementptr i8, ptr %p3863, i64 -32
  %ld3865 = load i64, ptr %rgep3864, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3865, ptr %slot586, align 8
  %v3866 = load i64, ptr %slot586, align 8
  %op3867 = add i64 %v3866, 1
  store i64 %op3867, ptr %slot587, align 8
  %v3868 = load i64, ptr %slot587, align 8
  %cmp3869 = icmp eq i64 %v3868, 0
  %cv3870 = zext i1 %cmp3869 to i32
  store i32 %cv3870, ptr %slot588, align 8
  %v3871 = load i32, ptr %slot588, align 8
  %cv3872 = zext i32 %v3871 to i64
  %cond3873 = icmp ne i64 %cv3872, 0
  br i1 %cond3873, label %bb_rcglimit989, label %bb_rcgcapacity989
bb_rcglimit989:
  %v3874 = load i64, ptr %slot1, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  %call3876 = call i32 @myl_qbe_rc_status(ptr %p3875, i32 2) nomerge, !dbg !144
  store i32 %call3876, ptr %slot589, align 8
  br label %bb_failure
bb_rcgcapacity989:
  %v3877 = load i64, ptr %slot587, align 8
  %v3878 = load i64, ptr %slot579, align 8
  %p3879 = inttoptr i64 %v3878 to ptr
  %rgep3880 = getelementptr i8, ptr %p3879, i64 -32
  store i64 %v3877, ptr %rgep3880, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain989
bb_rcgspecial989:
  %v3881 = load i64, ptr %slot582, align 8
  %op3882 = and i64 %v3881, 4611686018427387904
  store i64 %op3882, ptr %slot590, align 8
  %v3883 = load i64, ptr %slot590, align 8
  %cmp3884 = icmp ne i64 %v3883, 0
  %cv3885 = zext i1 %cmp3884 to i32
  store i32 %cv3885, ptr %slot591, align 8
  %v3886 = load i32, ptr %slot591, align 8
  %cv3887 = zext i32 %v3886 to i64
  %cond3888 = icmp ne i64 %cv3887, 0
  br i1 %cond3888, label %bb_rcgslow989, label %bb_rcgplain989
bb_rcgslow989:
  %v3889 = load i64, ptr %slot32, align 8
  %v3890 = load i64, ptr %slot577, align 8
  %v3891 = load i64, ptr %slot555, align 8
  %v3892 = load i64, ptr %slot578, align 8
  %cv3893 = trunc i64 %v3892 to i32
  %call3894 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v3889, i64 %v3890, i64 %v3891, i32 %cv3893) nomerge, !dbg !144
  store i32 %call3894, ptr %slot592, align 8
  %v3895 = load i32, ptr %slot592, align 8
  %cv3896 = zext i32 %v3895 to i64
  %cond3897 = icmp ne i64 %cv3896, 0
  br i1 %cond3897, label %bb_rcsuccess1003, label %bb_rcfailure1003
bb_rcfailure1003:
  %v3898 = load i64, ptr %slot32, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  %call3900 = call i32 @myl_rc_take_failure(ptr %p3899) nomerge, !dbg !144
  store i32 %call3900, ptr %slot593, align 8
  %v3901 = load i64, ptr %slot1, align 8
  %p3902 = inttoptr i64 %v3901 to ptr
  %v3903 = load i32, ptr %slot593, align 8
  %call3904 = call i32 @myl_qbe_rc_status(ptr %p3902, i32 %v3903) nomerge, !dbg !144
  store i32 %call3904, ptr %slot594, align 8
  br label %bb_failure
bb_rcsuccess1003:
  br label %bb_rcgdone989
bb_rcgplain989:
  %v3905 = load i64, ptr %slot579, align 8
  %v3906 = load i64, ptr %slot577, align 8
  %p3907 = inttoptr i64 %v3906 to ptr
  store i64 %v3905, ptr %p3907, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone989
bb_rcgdone989:
  %v3908 = load i64, ptr %slot10, align 8
  %p3909 = inttoptr i64 %v3908 to ptr
  store i32 2, ptr %p3909, align 4, !alias.scope !3, !noalias !4
  %v3910 = load i64, ptr %slot9, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  store i32 1, ptr %p3911, align 4, !alias.scope !3, !noalias !4
  %v3912 = load i64, ptr %slot7, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  %ld3914 = load i32, ptr %p3913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3914, ptr %slot595, align 8
  %v3915 = load i32, ptr %slot595, align 8
  %cv3916 = zext i32 %v3915 to i64
  %cond3917 = icmp ne i64 %cv3916, 0
  br i1 %cond3917, label %bb_rcslotdrop1010, label %bb_rcslotdone1010
bb_rcslotdrop1010:
  %v3918 = load i64, ptr %slot7, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  store i32 0, ptr %p3919, align 4, !alias.scope !3, !noalias !4
  %v3920 = load i64, ptr %slot12, align 8
  store i64 %v3920, ptr %slot596, align 8
  %v3921 = load i64, ptr %slot8, align 8
  %p3922 = inttoptr i64 %v3921 to ptr
  %ld3923 = load i32, ptr %p3922, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3923, ptr %slot597, align 8
  %v3924 = load i32, ptr %slot597, align 8
  %op3925 = and i32 %v3924, 28
  store i32 %op3925, ptr %slot598, align 8
  %v3926 = load i32, ptr %slot598, align 8
  %cv3927 = zext i32 %v3926 to i64
  %cond3928 = icmp ne i64 %cv3927, 0
  br i1 %cond3928, label %bb_rcslotrole1010, label %bb_rcslotowner1010
bb_rcslotrole1010:
  %v3929 = load i64, ptr %slot32, align 8
  store i64 %v3929, ptr %slot599, align 8
  %v3930 = load i64, ptr %slot596, align 8
  %p3931 = inttoptr i64 %v3930 to ptr
  %ld3932 = load i64, ptr %p3931, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3932, ptr %slot600, align 8
  %v3933 = load i64, ptr %slot600, align 8
  %cmp3934 = icmp ne i64 %v3933, 0
  %cv3935 = zext i1 %cmp3934 to i32
  store i32 %cv3935, ptr %slot601, align 8
  %v3936 = load i32, ptr %slot601, align 8
  %cv3937 = zext i32 %v3936 to i64
  %cond3938 = icmp ne i64 %cv3937, 0
  br i1 %cond3938, label %bb_rcgnn1026, label %bb_rcgdone1026
bb_rcgnn1026:
  %v3939 = load i64, ptr %slot600, align 8
  %op3940 = sub i64 %v3939, 16
  store i64 %op3940, ptr %slot602, align 8
  %v3941 = load i64, ptr %slot600, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  %rgep3943 = getelementptr i8, ptr %p3942, i64 -16
  %ld3944 = load i64, ptr %rgep3943, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3944, ptr %slot603, align 8
  %v3945 = load i64, ptr %slot603, align 8
  %op3946 = and i64 %v3945, 4611686018427387906
  store i64 %op3946, ptr %slot604, align 8
  %v3947 = load i64, ptr %slot604, align 8
  %cmp3948 = icmp ne i64 %v3947, 0
  %cv3949 = zext i1 %cmp3948 to i32
  store i32 %cv3949, ptr %slot605, align 8
  %v3950 = load i32, ptr %slot605, align 8
  %cv3951 = zext i32 %v3950 to i64
  %cond3952 = icmp ne i64 %cv3951, 0
  br i1 %cond3952, label %bb_rcgclear1026, label %bb_rcgcounted1026
bb_rcgcounted1026:
  %v3953 = load i64, ptr %slot600, align 8
  %op3954 = sub i64 %v3953, 24
  store i64 %op3954, ptr %slot606, align 8
  %v3955 = load i64, ptr %slot600, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %rgep3957 = getelementptr i8, ptr %p3956, i64 -24
  %ld3958 = load i64, ptr %rgep3957, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3958, ptr %slot607, align 8
  %v3959 = load i64, ptr %slot607, align 8
  %op3960 = sub i64 %v3959, 1
  store i64 %op3960, ptr %slot608, align 8
  %v3961 = load i64, ptr %slot608, align 8
  %cmp3962 = icmp eq i64 %v3961, 0
  %cv3963 = zext i1 %cmp3962 to i32
  store i32 %cv3963, ptr %slot609, align 8
  %v3964 = load i32, ptr %slot609, align 8
  %cv3965 = zext i32 %v3964 to i64
  %cond3966 = icmp ne i64 %cv3965, 0
  br i1 %cond3966, label %bb_rcglast1026, label %bb_rcgdec1026
bb_rcglast1026:
  %v3967 = load i64, ptr %slot600, align 8
  %op3968 = sub i64 %v3967, 32
  store i64 %op3968, ptr %slot610, align 8
  %v3969 = load i64, ptr %slot600, align 8
  %p3970 = inttoptr i64 %v3969 to ptr
  %rgep3971 = getelementptr i8, ptr %p3970, i64 -32
  %ld3972 = load i64, ptr %rgep3971, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3972, ptr %slot611, align 8
  %v3973 = load i64, ptr %slot611, align 8
  %cmp3974 = icmp ne i64 %v3973, 0
  %cv3975 = zext i1 %cmp3974 to i32
  store i32 %cv3975, ptr %slot612, align 8
  %v3976 = load i32, ptr %slot612, align 8
  %cv3977 = zext i32 %v3976 to i64
  %cond3978 = icmp ne i64 %cv3977, 0
  br i1 %cond3978, label %bb_rcgdec1026, label %bb_rcgslow1026
bb_rcgslow1026:
  %v3979 = load i64, ptr %slot599, align 8
  %v3980 = load i64, ptr %slot596, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3979, i64 %v3980) nomerge, !dbg !144
  br label %bb_rcgdone1026
bb_rcgdec1026:
  %v3981 = load i64, ptr %slot608, align 8
  %v3982 = load i64, ptr %slot600, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  %rgep3984 = getelementptr i8, ptr %p3983, i64 -24
  store i64 %v3981, ptr %rgep3984, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1026
bb_rcgclear1026:
  %v3985 = load i64, ptr %slot596, align 8
  %p3986 = inttoptr i64 %v3985 to ptr
  store i64 0, ptr %p3986, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1026
bb_rcgdone1026:
  br label %bb_rcslotdone1010
bb_rcslotowner1010:
  %v3987 = load i64, ptr %slot32, align 8
  store i64 %v3987, ptr %slot613, align 8
  %v3988 = load i64, ptr %slot596, align 8
  %p3989 = inttoptr i64 %v3988 to ptr
  %ld3990 = load i64, ptr %p3989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3990, ptr %slot614, align 8
  %v3991 = load i64, ptr %slot614, align 8
  %cmp3992 = icmp ne i64 %v3991, 0
  %cv3993 = zext i1 %cmp3992 to i32
  store i32 %cv3993, ptr %slot615, align 8
  %v3994 = load i32, ptr %slot615, align 8
  %cv3995 = zext i32 %v3994 to i64
  %cond3996 = icmp ne i64 %cv3995, 0
  br i1 %cond3996, label %bb_rcgnn1041, label %bb_rcgdone1041
bb_rcgnn1041:
  %v3997 = load i64, ptr %slot614, align 8
  %op3998 = sub i64 %v3997, 16
  store i64 %op3998, ptr %slot616, align 8
  %v3999 = load i64, ptr %slot614, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  %rgep4001 = getelementptr i8, ptr %p4000, i64 -16
  %ld4002 = load i64, ptr %rgep4001, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4002, ptr %slot617, align 8
  %v4003 = load i64, ptr %slot617, align 8
  %op4004 = and i64 %v4003, 4611686018427387906
  store i64 %op4004, ptr %slot618, align 8
  %v4005 = load i64, ptr %slot618, align 8
  %cmp4006 = icmp ne i64 %v4005, 0
  %cv4007 = zext i1 %cmp4006 to i32
  store i32 %cv4007, ptr %slot619, align 8
  %v4008 = load i32, ptr %slot619, align 8
  %cv4009 = zext i32 %v4008 to i64
  %cond4010 = icmp ne i64 %cv4009, 0
  br i1 %cond4010, label %bb_rcgclear1041, label %bb_rcgcounted1041
bb_rcgcounted1041:
  %v4011 = load i64, ptr %slot614, align 8
  %op4012 = sub i64 %v4011, 32
  store i64 %op4012, ptr %slot620, align 8
  %v4013 = load i64, ptr %slot614, align 8
  %p4014 = inttoptr i64 %v4013 to ptr
  %rgep4015 = getelementptr i8, ptr %p4014, i64 -32
  %ld4016 = load i64, ptr %rgep4015, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4016, ptr %slot621, align 8
  %v4017 = load i64, ptr %slot621, align 8
  %op4018 = sub i64 %v4017, 1
  store i64 %op4018, ptr %slot622, align 8
  %v4019 = load i64, ptr %slot622, align 8
  %cmp4020 = icmp eq i64 %v4019, 0
  %cv4021 = zext i1 %cmp4020 to i32
  store i32 %cv4021, ptr %slot623, align 8
  %v4022 = load i32, ptr %slot623, align 8
  %cv4023 = zext i32 %v4022 to i64
  %cond4024 = icmp ne i64 %cv4023, 0
  br i1 %cond4024, label %bb_rcglast1041, label %bb_rcgdec1041
bb_rcglast1041:
  %v4025 = load i64, ptr %slot614, align 8
  %op4026 = sub i64 %v4025, 24
  store i64 %op4026, ptr %slot624, align 8
  %v4027 = load i64, ptr %slot614, align 8
  %p4028 = inttoptr i64 %v4027 to ptr
  %rgep4029 = getelementptr i8, ptr %p4028, i64 -24
  %ld4030 = load i64, ptr %rgep4029, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4030, ptr %slot625, align 8
  %v4031 = load i64, ptr %slot625, align 8
  %cmp4032 = icmp ne i64 %v4031, 0
  %cv4033 = zext i1 %cmp4032 to i32
  store i32 %cv4033, ptr %slot626, align 8
  %v4034 = load i32, ptr %slot626, align 8
  %cv4035 = zext i32 %v4034 to i64
  %cond4036 = icmp ne i64 %cv4035, 0
  br i1 %cond4036, label %bb_rcgdec1041, label %bb_rcgslow1041
bb_rcgslow1041:
  %v4037 = load i64, ptr %slot613, align 8
  %v4038 = load i64, ptr %slot596, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4037, i64 %v4038) nomerge, !dbg !144
  br label %bb_rcgdone1041
bb_rcgdec1041:
  %v4039 = load i64, ptr %slot622, align 8
  %v4040 = load i64, ptr %slot614, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %rgep4042 = getelementptr i8, ptr %p4041, i64 -32
  store i64 %v4039, ptr %rgep4042, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1041
bb_rcgclear1041:
  %v4043 = load i64, ptr %slot596, align 8
  %p4044 = inttoptr i64 %v4043 to ptr
  store i64 0, ptr %p4044, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1041
bb_rcgdone1041:
  br label %bb_rcslotdone1010
bb_rcslotdone1010:
  br label %bb_rcprepared956
bb_rcprepared956:
  %v4045 = load i64, ptr %slot14, align 8
  store i64 %v4045, ptr %slot627, align 8
  %v4046 = load i64, ptr %slot627, align 8
  %v4047 = load i64, ptr %slot553, align 8
  %p4048 = inttoptr i64 %v4046 to ptr
  %p4049 = inttoptr i64 %v4047 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4049, ptr %p4048, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4050 = load i64, ptr %slot9, align 8
  %p4051 = inttoptr i64 %v4050 to ptr
  store i32 0, ptr %p4051, align 4, !alias.scope !3, !noalias !4
  %v4052 = load i64, ptr %slot21, align 8
  store i64 %v4052, ptr %slot628, align 8
  %v4053 = load i64, ptr %slot548, align 8
  %p4055 = inttoptr i64 %v4053 to ptr
  %gep4056 = getelementptr i8, ptr %p4055, i64 8
  %op4054 = ptrtoint ptr %gep4056 to i64
  store i64 %op4054, ptr %slot629, align 8
  %v4057 = load i64, ptr %slot628, align 8
  %p4058 = inttoptr i64 %v4057 to ptr
  %ld4059 = load i32, ptr %p4058, align 4, !alias.scope !3, !noalias !4
  %ext4060 = zext i32 %ld4059 to i64
  store i64 %ext4060, ptr %slot630, align 8
  %v4061 = load i64, ptr %slot630, align 8
  %cv4062 = trunc i64 %v4061 to i32
  %v4063 = load i64, ptr %slot629, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  store i32 %cv4062, ptr %p4064, align 4, !alias.scope !3, !noalias !4
  %v4065 = load i64, ptr %slot548, align 8
  %v4066 = load i64, ptr %slot20, align 8
  %p4067 = inttoptr i64 %v4066 to ptr
  store i64 %v4065, ptr %p4067, align 8, !alias.scope !3, !noalias !4
  %v4068 = load i64, ptr %slot20, align 8
  %p4069 = inttoptr i64 %v4068 to ptr
  %ld4070 = load i64, ptr %p4069, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4070, ptr %slot631, align 8
  %v4071 = load i64, ptr %slot12, align 8
  store i64 %v4071, ptr %slot632, align 8
  %v4072 = load i64, ptr %slot631, align 8
  %v4073 = load i64, ptr %slot632, align 8
  %p4074 = inttoptr i64 %v4072 to ptr
  %p4075 = inttoptr i64 %v4073 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4075, ptr %p4074, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4076 = load i64, ptr %slot8, align 8
  %p4077 = inttoptr i64 %v4076 to ptr
  store i32 2, ptr %p4077, align 4, !alias.scope !3, !noalias !4
  %v4078 = load i64, ptr %slot7, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  store i32 1, ptr %p4079, align 4, !alias.scope !3, !noalias !4
  %v4080 = load i64, ptr %slot632, align 8
  %v4081 = load i64, ptr %slot20, align 8
  %p4082 = inttoptr i64 %v4081 to ptr
  store i64 %v4080, ptr %p4082, align 8, !alias.scope !3, !noalias !4
  %v4083 = load i64, ptr %slot20, align 8
  %p4084 = inttoptr i64 %v4083 to ptr
  %ld4085 = load i64, ptr %p4084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4085, ptr %slot633, align 8
  %v4086 = load i64, ptr %slot20, align 8
  %p4087 = inttoptr i64 %v4086 to ptr
  %ld4088 = load i64, ptr %p4087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4088, ptr %slot634, align 8
  %v4089 = load i64, ptr %slot14, align 8
  store i64 %v4089, ptr %slot635, align 8
  %v4090 = load i64, ptr %slot33, align 8
  store i64 %v4090, ptr %slot636, align 8
  %v4091 = load i64, ptr %slot634, align 8
  %op4092 = add i64 %v4091, 0
  store i64 %op4092, ptr %slot637, align 8
  %v4093 = load i64, ptr %slot637, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  %ld4095 = load i64, ptr %p4094, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4095, ptr %slot638, align 8
  %v4096 = load i64, ptr %slot638, align 8
  %cmp4097 = icmp ne i64 %v4096, 0
  %cv4098 = zext i1 %cmp4097 to i32
  store i32 %cv4098, ptr %slot639, align 8
  %v4099 = load i32, ptr %slot639, align 8
  %cv4100 = zext i32 %v4099 to i64
  %cond4101 = icmp ne i64 %cv4100, 0
  br i1 %cond4101, label %bb_rcmoveheader1061, label %bb_rcmovenext1061
bb_rcmoveheader1061:
  %v4102 = load i64, ptr %slot638, align 8
  %op4103 = sub i64 %v4102, 16
  store i64 %op4103, ptr %slot640, align 8
  %v4104 = load i64, ptr %slot638, align 8
  %p4105 = inttoptr i64 %v4104 to ptr
  %rgep4106 = getelementptr i8, ptr %p4105, i64 -16
  %ld4107 = load i64, ptr %rgep4106, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4107, ptr %slot641, align 8
  %v4108 = load i64, ptr %slot641, align 8
  %op4109 = and i64 %v4108, 5764607523034234881
  store i64 %op4109, ptr %slot642, align 8
  %v4110 = load i64, ptr %slot642, align 8
  %cmp4111 = icmp ne i64 %v4110, 0
  %cv4112 = zext i1 %cmp4111 to i32
  store i32 %cv4112, ptr %slot643, align 8
  %v4113 = load i32, ptr %slot643, align 8
  %cv4114 = zext i32 %v4113 to i64
  %cond4115 = icmp ne i64 %cv4114, 0
  br i1 %cond4115, label %bb_rcmoveslow1058, label %bb_rcmovenext1061
bb_rcmovenext1061:
  %v4116 = load i64, ptr %slot634, align 8
  %v4117 = load i64, ptr %slot635, align 8
  %p4118 = inttoptr i64 %v4116 to ptr
  %p4119 = inttoptr i64 %v4117 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4119, ptr %p4118, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4120 = load i64, ptr %slot634, align 8
  %p4121 = inttoptr i64 %v4120 to ptr
  store i64 0, ptr %p4121, align 8, !alias.scope !3, !noalias !4
  %v4122 = load i64, ptr %slot634, align 8
  %op4123 = add i64 %v4122, 8
  store i64 %op4123, ptr %slot644, align 8
  %v4124 = load i64, ptr %slot644, align 8
  %p4125 = inttoptr i64 %v4124 to ptr
  store i64 0, ptr %p4125, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1058
bb_rcmoveslow1058:
  %v4126 = load i64, ptr %slot32, align 8
  %v4127 = load i64, ptr %slot635, align 8
  %v4128 = load i64, ptr %slot634, align 8
  %v4129 = load i64, ptr %slot636, align 8
  %cv4130 = trunc i64 %v4129 to i32
  %call4131 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v4126, i64 %v4127, i64 %v4128, i32 %cv4130) nomerge, !dbg !146
  store i32 %call4131, ptr %slot645, align 8
  %v4132 = load i32, ptr %slot645, align 8
  %cv4133 = zext i32 %v4132 to i64
  %cond4134 = icmp ne i64 %cv4133, 0
  br i1 %cond4134, label %bb_rcsuccess1069, label %bb_rcfailure1069
bb_rcfailure1069:
  %v4135 = load i64, ptr %slot32, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  %call4137 = call i32 @myl_rc_take_failure(ptr %p4136) nomerge, !dbg !146
  store i32 %call4137, ptr %slot646, align 8
  %v4138 = load i64, ptr %slot1, align 8
  %p4139 = inttoptr i64 %v4138 to ptr
  %v4140 = load i32, ptr %slot646, align 8
  %call4141 = call i32 @myl_qbe_rc_status(ptr %p4139, i32 %v4140) nomerge, !dbg !146
  store i32 %call4141, ptr %slot647, align 8
  br label %bb_failure
bb_rcsuccess1069:
  br label %bb_rcmoved1058
bb_rcmoved1058:
  %v4142 = load i64, ptr %slot7, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  store i32 0, ptr %p4143, align 4, !alias.scope !3, !noalias !4
  %v4144 = load i64, ptr %slot10, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  store i32 2, ptr %p4145, align 4, !alias.scope !3, !noalias !4
  %v4146 = load i64, ptr %slot9, align 8
  %p4147 = inttoptr i64 %v4146 to ptr
  store i32 1, ptr %p4147, align 4, !alias.scope !3, !noalias !4
  %v4148 = load i64, ptr %slot14, align 8
  store i64 %v4148, ptr %slot648, align 8
  %v4149 = load i64, ptr %slot9, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  store i32 0, ptr %p4150, align 4, !alias.scope !3, !noalias !4
  %v4151 = load i64, ptr %slot7, align 8
  %p4152 = inttoptr i64 %v4151 to ptr
  %ld4153 = load i32, ptr %p4152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4153, ptr %slot649, align 8
  %v4154 = load i32, ptr %slot649, align 8
  %cv4155 = zext i32 %v4154 to i64
  %cond4156 = icmp ne i64 %cv4155, 0
  br i1 %cond4156, label %bb_rcslotdrop1079, label %bb_rcslotdone1079
bb_rcslotdrop1079:
  %v4157 = load i64, ptr %slot7, align 8
  %p4158 = inttoptr i64 %v4157 to ptr
  store i32 0, ptr %p4158, align 4, !alias.scope !3, !noalias !4
  %v4159 = load i64, ptr %slot12, align 8
  store i64 %v4159, ptr %slot650, align 8
  %v4160 = load i64, ptr %slot8, align 8
  %p4161 = inttoptr i64 %v4160 to ptr
  %ld4162 = load i32, ptr %p4161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4162, ptr %slot651, align 8
  %v4163 = load i32, ptr %slot651, align 8
  %op4164 = and i32 %v4163, 28
  store i32 %op4164, ptr %slot652, align 8
  %v4165 = load i32, ptr %slot652, align 8
  %cv4166 = zext i32 %v4165 to i64
  %cond4167 = icmp ne i64 %cv4166, 0
  br i1 %cond4167, label %bb_rcslotrole1079, label %bb_rcslotowner1079
bb_rcslotrole1079:
  %v4168 = load i64, ptr %slot32, align 8
  store i64 %v4168, ptr %slot653, align 8
  %v4169 = load i64, ptr %slot653, align 8
  %v4170 = load i64, ptr %slot650, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v4169, i64 %v4170) nomerge, !dbg !146
  br label %bb_rcslotdone1079
bb_rcslotowner1079:
  %v4171 = load i64, ptr %slot32, align 8
  store i64 %v4171, ptr %slot654, align 8
  %v4172 = load i64, ptr %slot654, align 8
  %v4173 = load i64, ptr %slot650, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v4172, i64 %v4173) nomerge, !dbg !146
  br label %bb_rcslotdone1079
bb_rcslotdone1079:
  %v4174 = load i64, ptr %slot648, align 8
  %p4175 = inttoptr i64 %v4174 to ptr
  %ret4176 = load { i64, i64 }, ptr %p4175, align 8
  ret { i64, i64 } %ret4176
bb_i43:
  %v4177 = load i64, ptr %slot20, align 8
  %p4178 = inttoptr i64 %v4177 to ptr
  store i64 0, ptr %p4178, align 8, !alias.scope !3, !noalias !4
  %v4179 = load i64, ptr %slot20, align 8
  %p4180 = inttoptr i64 %v4179 to ptr
  %ld4181 = load i64, ptr %p4180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4181, ptr %slot655, align 8
  %v4182 = load i64, ptr %slot655, align 8
  %cond4183 = icmp ne i64 %v4182, 0
  br i1 %cond4183, label %bb_success1142, label %bb_failed1142
bb_failed1142:
  %v4184 = load i64, ptr %slot1, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  call void @myl_qbe_fail_assert(ptr %p4185) nomerge, !dbg !148
  unreachable
bb_success1142:
  %p4186 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld4187 = load i64, ptr %p4186, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4187, ptr %slot656, align 8
  %v4188 = load i64, ptr %slot656, align 8
  %v4189 = load i64, ptr %slot20, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  store i64 %v4188, ptr %p4190, align 8, !alias.scope !3, !noalias !4
  %v4191 = load i64, ptr %slot20, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  %ld4193 = load i64, ptr %p4192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4193, ptr %slot657, align 8
  %v4194 = load i64, ptr %slot657, align 8
  %v4195 = load i64, ptr %slot13, align 8
  %p4196 = inttoptr i64 %v4195 to ptr
  store i64 %v4194, ptr %p4196, align 8, !alias.scope !3, !noalias !4
  %v4197 = load i64, ptr %slot13, align 8
  store i64 %v4197, ptr %slot658, align 8
  %v4198 = load i64, ptr %slot14, align 8
  store i64 %v4198, ptr %slot659, align 8
  %v4199 = load i64, ptr %slot658, align 8
  %v4200 = load i64, ptr %slot659, align 8
  %p4201 = inttoptr i64 %v4199 to ptr
  %p4202 = inttoptr i64 %v4200 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4202, ptr %p4201, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4203 = load i64, ptr %slot10, align 8
  %p4204 = inttoptr i64 %v4203 to ptr
  store i32 2, ptr %p4204, align 4, !alias.scope !3, !noalias !4
  %v4205 = load i64, ptr %slot9, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  store i32 1, ptr %p4206, align 4, !alias.scope !3, !noalias !4
  %v4207 = load i64, ptr %slot12, align 8
  store i64 %v4207, ptr %slot660, align 8
  %v4208 = load i64, ptr %slot14, align 8
  store i64 %v4208, ptr %slot661, align 8
  %v4209 = load i64, ptr %slot661, align 8
  %v4210 = load i64, ptr %slot660, align 8
  %p4211 = inttoptr i64 %v4209 to ptr
  %p4212 = inttoptr i64 %v4210 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4212, ptr %p4211, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4213 = load i64, ptr %slot8, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  store i32 2, ptr %p4214, align 4, !alias.scope !3, !noalias !4
  %v4215 = load i64, ptr %slot10, align 8
  %p4216 = inttoptr i64 %v4215 to ptr
  %ld4217 = load i32, ptr %p4216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4217, ptr %slot662, align 8
  %v4218 = load i32, ptr %slot662, align 8
  %v4219 = load i64, ptr %slot8, align 8
  %p4220 = inttoptr i64 %v4219 to ptr
  store i32 %v4218, ptr %p4220, align 4, !alias.scope !3, !noalias !4
  %v4221 = load i64, ptr %slot9, align 8
  %p4222 = inttoptr i64 %v4221 to ptr
  store i32 0, ptr %p4222, align 4, !alias.scope !3, !noalias !4
  %v4223 = load i64, ptr %slot7, align 8
  %p4224 = inttoptr i64 %v4223 to ptr
  store i32 1, ptr %p4224, align 4, !alias.scope !3, !noalias !4
  %v4225 = load i64, ptr %slot660, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  %ld4227 = load i64, ptr %p4226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4227, ptr %slot663, align 8
  %v4228 = load i64, ptr %slot663, align 8
  %v4229 = load i64, ptr %slot20, align 8
  %p4230 = inttoptr i64 %v4229 to ptr
  store i64 %v4228, ptr %p4230, align 8, !alias.scope !3, !noalias !4
  %v4231 = load i64, ptr %slot21, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  store i64 0, ptr %p4232, align 8, !alias.scope !3, !noalias !4
  %v4233 = load i64, ptr %slot26, align 8
  store i64 %v4233, ptr %slot664, align 8
  %v4234 = load i64, ptr %slot664, align 8
  %p4235 = inttoptr i64 %v4234 to ptr
  store i64 0, ptr %p4235, align 8, !alias.scope !3, !noalias !4
  %v4236 = load i64, ptr %slot664, align 8
  %p4238 = inttoptr i64 %v4236 to ptr
  %gep4239 = getelementptr i8, ptr %p4238, i64 8
  %op4237 = ptrtoint ptr %gep4239 to i64
  store i64 %op4237, ptr %slot665, align 8
  %v4240 = load i64, ptr %slot665, align 8
  %p4241 = inttoptr i64 %v4240 to ptr
  store i64 0, ptr %p4241, align 8, !alias.scope !3, !noalias !4
  %v4242 = load i64, ptr %slot11, align 8
  %p4243 = inttoptr i64 %v4242 to ptr
  store i32 1, ptr %p4243, align 4, !alias.scope !3, !noalias !4
  %v4244 = load i64, ptr %slot33, align 8
  store i64 %v4244, ptr %slot666, align 8
  %v4245 = load i64, ptr %slot20, align 8
  %p4246 = inttoptr i64 %v4245 to ptr
  %ld4247 = load i64, ptr %p4246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4247, ptr %slot667, align 8
  %v4248 = load i64, ptr %slot667, align 8
  %v4249 = load i64, ptr %slot13, align 8
  %p4250 = inttoptr i64 %v4249 to ptr
  store i64 %v4248, ptr %p4250, align 8, !alias.scope !3, !noalias !4
  %v4251 = load i64, ptr %slot13, align 8
  store i64 %v4251, ptr %slot668, align 8
  %v4252 = load i64, ptr %slot664, align 8
  %p4254 = inttoptr i64 %v4252 to ptr
  %gep4255 = getelementptr i8, ptr %p4254, i64 0
  %op4253 = ptrtoint ptr %gep4255 to i64
  store i64 %op4253, ptr %slot669, align 8
  %v4256 = load i64, ptr %slot20, align 8
  %p4257 = inttoptr i64 %v4256 to ptr
  %ld4258 = load i64, ptr %p4257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4258, ptr %slot670, align 8
  %v4259 = load i64, ptr %slot670, align 8
  %v4260 = load i64, ptr %slot13, align 8
  %p4261 = inttoptr i64 %v4260 to ptr
  store i64 %v4259, ptr %p4261, align 8, !alias.scope !3, !noalias !4
  %v4262 = load i64, ptr %slot13, align 8
  store i64 %v4262, ptr %slot671, align 8
  %v4263 = load i64, ptr %slot7, align 8
  %p4264 = inttoptr i64 %v4263 to ptr
  %ld4265 = load i32, ptr %p4264, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4265, ptr %slot672, align 8
  %v4266 = load i64, ptr %slot8, align 8
  %p4267 = inttoptr i64 %v4266 to ptr
  %ld4268 = load i32, ptr %p4267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4268, ptr %slot673, align 8
  %v4269 = load i32, ptr %slot673, align 8
  %op4270 = and i32 %v4269, 24
  store i32 %op4270, ptr %slot673, align 8
  %v4271 = load i32, ptr %slot673, align 8
  %cmp4272 = icmp eq i32 %v4271, 0
  %cv4273 = zext i1 %cmp4272 to i32
  store i32 %cv4273, ptr %slot674, align 8
  %v4274 = load i32, ptr %slot672, align 8
  %v4275 = load i32, ptr %slot674, align 8
  %op4276 = and i32 %v4274, %v4275
  store i32 %op4276, ptr %slot675, align 8
  %v4277 = load i32, ptr %slot675, align 8
  %cv4278 = zext i32 %v4277 to i64
  %cond4279 = icmp ne i64 %cv4278, 0
  br i1 %cond4279, label %bb_rctake1169, label %bb_rccopy1169
bb_rctake1169:
  %v4280 = load i64, ptr %slot14, align 8
  store i64 %v4280, ptr %slot676, align 8
  %v4281 = load i64, ptr %slot33, align 8
  store i64 %v4281, ptr %slot677, align 8
  %v4282 = load i64, ptr %slot671, align 8
  %v4283 = load i64, ptr %slot676, align 8
  %op4284 = sub i64 %v4282, %v4283
  store i64 %op4284, ptr %slot678, align 8
  %v4285 = load i64, ptr %slot676, align 8
  %v4286 = load i64, ptr %slot671, align 8
  %op4287 = sub i64 %v4285, %v4286
  store i64 %op4287, ptr %slot679, align 8
  %v4288 = load i64, ptr %slot678, align 8
  %cmp4289 = icmp ult i64 %v4288, 8
  %cv4290 = zext i1 %cmp4289 to i32
  store i32 %cv4290, ptr %slot680, align 8
  %v4291 = load i64, ptr %slot679, align 8
  %cmp4292 = icmp ult i64 %v4291, 8
  %cv4293 = zext i1 %cmp4292 to i32
  store i32 %cv4293, ptr %slot681, align 8
  %v4294 = load i32, ptr %slot680, align 8
  %v4295 = load i32, ptr %slot681, align 8
  %op4296 = or i32 %v4294, %v4295
  store i32 %op4296, ptr %slot682, align 8
  %v4297 = load i32, ptr %slot682, align 8
  %cv4298 = zext i32 %v4297 to i64
  %cond4299 = icmp ne i64 %cv4298, 0
  br i1 %cond4299, label %bb_rcmoveslow1178, label %bb_rcmovecheck1178
bb_rcmovecheck1178:
  %v4300 = load i64, ptr %slot671, align 8
  %p4302 = inttoptr i64 %v4300 to ptr
  %gep4303 = getelementptr i8, ptr %p4302, i64 0
  %op4301 = ptrtoint ptr %gep4303 to i64
  store i64 %op4301, ptr %slot683, align 8
  %v4304 = load i64, ptr %slot683, align 8
  %p4305 = inttoptr i64 %v4304 to ptr
  %ld4306 = load i64, ptr %p4305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4306, ptr %slot684, align 8
  %v4307 = load i64, ptr %slot684, align 8
  %cmp4308 = icmp ne i64 %v4307, 0
  %cv4309 = zext i1 %cmp4308 to i32
  store i32 %cv4309, ptr %slot685, align 8
  %v4310 = load i32, ptr %slot685, align 8
  %cv4311 = zext i32 %v4310 to i64
  %cond4312 = icmp ne i64 %cv4311, 0
  br i1 %cond4312, label %bb_rcmoveheader1186, label %bb_rcmovenext1186
bb_rcmoveheader1186:
  %v4313 = load i64, ptr %slot684, align 8
  %op4314 = sub i64 %v4313, 16
  store i64 %op4314, ptr %slot686, align 8
  %v4315 = load i64, ptr %slot684, align 8
  %p4316 = inttoptr i64 %v4315 to ptr
  %rgep4317 = getelementptr i8, ptr %p4316, i64 -16
  %ld4318 = load i64, ptr %rgep4317, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4318, ptr %slot687, align 8
  %v4319 = load i64, ptr %slot687, align 8
  %op4320 = and i64 %v4319, 5764607523034234881
  store i64 %op4320, ptr %slot688, align 8
  %v4321 = load i64, ptr %slot688, align 8
  %cmp4322 = icmp ne i64 %v4321, 0
  %cv4323 = zext i1 %cmp4322 to i32
  store i32 %cv4323, ptr %slot689, align 8
  %v4324 = load i32, ptr %slot689, align 8
  %cv4325 = zext i32 %v4324 to i64
  %cond4326 = icmp ne i64 %cv4325, 0
  br i1 %cond4326, label %bb_rcmoveslow1178, label %bb_rcmovenext1186
bb_rcmovenext1186:
  %v4327 = load i64, ptr %slot671, align 8
  %v4328 = load i64, ptr %slot676, align 8
  %p4329 = inttoptr i64 %v4327 to ptr
  %p4330 = inttoptr i64 %v4328 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4330, ptr %p4329, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4331 = load i64, ptr %slot671, align 8
  %p4332 = inttoptr i64 %v4331 to ptr
  store i64 0, ptr %p4332, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1178
bb_rcmoveslow1178:
  %v4333 = load i64, ptr %slot32, align 8
  %v4334 = load i64, ptr %slot676, align 8
  %v4335 = load i64, ptr %slot671, align 8
  %v4336 = load i64, ptr %slot677, align 8
  %cv4337 = trunc i64 %v4336 to i32
  %call4338 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v4333, i64 %v4334, i64 %v4335, i32 %cv4337) nomerge, !dbg !150
  store i32 %call4338, ptr %slot690, align 8
  %v4339 = load i32, ptr %slot690, align 8
  %cv4340 = zext i32 %v4339 to i64
  %cond4341 = icmp ne i64 %cv4340, 0
  br i1 %cond4341, label %bb_rcsuccess1193, label %bb_rcfailure1193
bb_rcfailure1193:
  %v4342 = load i64, ptr %slot32, align 8
  %p4343 = inttoptr i64 %v4342 to ptr
  %call4344 = call i32 @myl_rc_take_failure(ptr %p4343) nomerge, !dbg !150
  store i32 %call4344, ptr %slot691, align 8
  %v4345 = load i64, ptr %slot1, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  %v4347 = load i32, ptr %slot691, align 8
  %call4348 = call i32 @myl_qbe_rc_status(ptr %p4346, i32 %v4347) nomerge, !dbg !150
  store i32 %call4348, ptr %slot692, align 8
  br label %bb_failure
bb_rcsuccess1193:
  br label %bb_rcmoved1178
bb_rcmoved1178:
  %v4349 = load i64, ptr %slot7, align 8
  %p4350 = inttoptr i64 %v4349 to ptr
  store i32 0, ptr %p4350, align 4, !alias.scope !3, !noalias !4
  %v4351 = load i64, ptr %slot10, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  store i32 2, ptr %p4352, align 4, !alias.scope !3, !noalias !4
  %v4353 = load i64, ptr %slot9, align 8
  %p4354 = inttoptr i64 %v4353 to ptr
  store i32 1, ptr %p4354, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1169
bb_rccopy1169:
  %v4355 = load i64, ptr %slot14, align 8
  store i64 %v4355, ptr %slot693, align 8
  %v4356 = load i64, ptr %slot33, align 8
  store i64 %v4356, ptr %slot694, align 8
  %v4357 = load i64, ptr %slot671, align 8
  %p4358 = inttoptr i64 %v4357 to ptr
  %ld4359 = load i64, ptr %p4358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4359, ptr %slot695, align 8
  %v4360 = load i64, ptr %slot695, align 8
  %cmp4361 = icmp ne i64 %v4360, 0
  %cv4362 = zext i1 %cmp4361 to i32
  store i32 %cv4362, ptr %slot696, align 8
  %v4363 = load i32, ptr %slot696, align 8
  %cv4364 = zext i32 %v4363 to i64
  %cond4365 = icmp ne i64 %cv4364, 0
  br i1 %cond4365, label %bb_rcgnn1202, label %bb_rcgplain1202
bb_rcgnn1202:
  %v4366 = load i64, ptr %slot695, align 8
  %op4367 = sub i64 %v4366, 16
  store i64 %op4367, ptr %slot697, align 8
  %v4368 = load i64, ptr %slot695, align 8
  %p4369 = inttoptr i64 %v4368 to ptr
  %rgep4370 = getelementptr i8, ptr %p4369, i64 -16
  %ld4371 = load i64, ptr %rgep4370, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4371, ptr %slot698, align 8
  %v4372 = load i64, ptr %slot698, align 8
  %op4373 = and i64 %v4372, 4611686018427387906
  store i64 %op4373, ptr %slot699, align 8
  %v4374 = load i64, ptr %slot699, align 8
  %cmp4375 = icmp ne i64 %v4374, 0
  %cv4376 = zext i1 %cmp4375 to i32
  store i32 %cv4376, ptr %slot700, align 8
  %v4377 = load i32, ptr %slot700, align 8
  %cv4378 = zext i32 %v4377 to i64
  %cond4379 = icmp ne i64 %cv4378, 0
  br i1 %cond4379, label %bb_rcgspecial1202, label %bb_rcginc1202
bb_rcginc1202:
  %v4380 = load i64, ptr %slot695, align 8
  %op4381 = sub i64 %v4380, 32
  store i64 %op4381, ptr %slot701, align 8
  %v4382 = load i64, ptr %slot695, align 8
  %p4383 = inttoptr i64 %v4382 to ptr
  %rgep4384 = getelementptr i8, ptr %p4383, i64 -32
  %ld4385 = load i64, ptr %rgep4384, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4385, ptr %slot702, align 8
  %v4386 = load i64, ptr %slot702, align 8
  %op4387 = add i64 %v4386, 1
  store i64 %op4387, ptr %slot703, align 8
  %v4388 = load i64, ptr %slot703, align 8
  %cmp4389 = icmp eq i64 %v4388, 0
  %cv4390 = zext i1 %cmp4389 to i32
  store i32 %cv4390, ptr %slot704, align 8
  %v4391 = load i32, ptr %slot704, align 8
  %cv4392 = zext i32 %v4391 to i64
  %cond4393 = icmp ne i64 %cv4392, 0
  br i1 %cond4393, label %bb_rcglimit1202, label %bb_rcgcapacity1202
bb_rcglimit1202:
  %v4394 = load i64, ptr %slot1, align 8
  %p4395 = inttoptr i64 %v4394 to ptr
  %call4396 = call i32 @myl_qbe_rc_status(ptr %p4395, i32 2) nomerge, !dbg !150
  store i32 %call4396, ptr %slot705, align 8
  br label %bb_failure
bb_rcgcapacity1202:
  %v4397 = load i64, ptr %slot703, align 8
  %v4398 = load i64, ptr %slot695, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  %rgep4400 = getelementptr i8, ptr %p4399, i64 -32
  store i64 %v4397, ptr %rgep4400, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1202
bb_rcgspecial1202:
  %v4401 = load i64, ptr %slot698, align 8
  %op4402 = and i64 %v4401, 4611686018427387904
  store i64 %op4402, ptr %slot706, align 8
  %v4403 = load i64, ptr %slot706, align 8
  %cmp4404 = icmp ne i64 %v4403, 0
  %cv4405 = zext i1 %cmp4404 to i32
  store i32 %cv4405, ptr %slot707, align 8
  %v4406 = load i32, ptr %slot707, align 8
  %cv4407 = zext i32 %v4406 to i64
  %cond4408 = icmp ne i64 %cv4407, 0
  br i1 %cond4408, label %bb_rcgslow1202, label %bb_rcgplain1202
bb_rcgslow1202:
  %v4409 = load i64, ptr %slot32, align 8
  %v4410 = load i64, ptr %slot693, align 8
  %v4411 = load i64, ptr %slot671, align 8
  %v4412 = load i64, ptr %slot694, align 8
  %cv4413 = trunc i64 %v4412 to i32
  %call4414 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v4409, i64 %v4410, i64 %v4411, i32 %cv4413) nomerge, !dbg !150
  store i32 %call4414, ptr %slot708, align 8
  %v4415 = load i32, ptr %slot708, align 8
  %cv4416 = zext i32 %v4415 to i64
  %cond4417 = icmp ne i64 %cv4416, 0
  br i1 %cond4417, label %bb_rcsuccess1216, label %bb_rcfailure1216
bb_rcfailure1216:
  %v4418 = load i64, ptr %slot32, align 8
  %p4419 = inttoptr i64 %v4418 to ptr
  %call4420 = call i32 @myl_rc_take_failure(ptr %p4419) nomerge, !dbg !150
  store i32 %call4420, ptr %slot709, align 8
  %v4421 = load i64, ptr %slot1, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  %v4423 = load i32, ptr %slot709, align 8
  %call4424 = call i32 @myl_qbe_rc_status(ptr %p4422, i32 %v4423) nomerge, !dbg !150
  store i32 %call4424, ptr %slot710, align 8
  br label %bb_failure
bb_rcsuccess1216:
  br label %bb_rcgdone1202
bb_rcgplain1202:
  %v4425 = load i64, ptr %slot695, align 8
  %v4426 = load i64, ptr %slot693, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  store i64 %v4425, ptr %p4427, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1202
bb_rcgdone1202:
  %v4428 = load i64, ptr %slot10, align 8
  %p4429 = inttoptr i64 %v4428 to ptr
  store i32 2, ptr %p4429, align 4, !alias.scope !3, !noalias !4
  %v4430 = load i64, ptr %slot9, align 8
  %p4431 = inttoptr i64 %v4430 to ptr
  store i32 1, ptr %p4431, align 4, !alias.scope !3, !noalias !4
  %v4432 = load i64, ptr %slot7, align 8
  %p4433 = inttoptr i64 %v4432 to ptr
  %ld4434 = load i32, ptr %p4433, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4434, ptr %slot711, align 8
  %v4435 = load i32, ptr %slot711, align 8
  %cv4436 = zext i32 %v4435 to i64
  %cond4437 = icmp ne i64 %cv4436, 0
  br i1 %cond4437, label %bb_rcslotdrop1223, label %bb_rcslotdone1223
bb_rcslotdrop1223:
  %v4438 = load i64, ptr %slot7, align 8
  %p4439 = inttoptr i64 %v4438 to ptr
  store i32 0, ptr %p4439, align 4, !alias.scope !3, !noalias !4
  %v4440 = load i64, ptr %slot12, align 8
  store i64 %v4440, ptr %slot712, align 8
  %v4441 = load i64, ptr %slot8, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  %ld4443 = load i32, ptr %p4442, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4443, ptr %slot713, align 8
  %v4444 = load i32, ptr %slot713, align 8
  %op4445 = and i32 %v4444, 28
  store i32 %op4445, ptr %slot714, align 8
  %v4446 = load i32, ptr %slot714, align 8
  %cv4447 = zext i32 %v4446 to i64
  %cond4448 = icmp ne i64 %cv4447, 0
  br i1 %cond4448, label %bb_rcslotrole1223, label %bb_rcslotowner1223
bb_rcslotrole1223:
  %v4449 = load i64, ptr %slot32, align 8
  store i64 %v4449, ptr %slot715, align 8
  %v4450 = load i64, ptr %slot712, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  %ld4452 = load i64, ptr %p4451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4452, ptr %slot716, align 8
  %v4453 = load i64, ptr %slot716, align 8
  %cmp4454 = icmp ne i64 %v4453, 0
  %cv4455 = zext i1 %cmp4454 to i32
  store i32 %cv4455, ptr %slot717, align 8
  %v4456 = load i32, ptr %slot717, align 8
  %cv4457 = zext i32 %v4456 to i64
  %cond4458 = icmp ne i64 %cv4457, 0
  br i1 %cond4458, label %bb_rcgnn1239, label %bb_rcgdone1239
bb_rcgnn1239:
  %v4459 = load i64, ptr %slot716, align 8
  %op4460 = sub i64 %v4459, 16
  store i64 %op4460, ptr %slot718, align 8
  %v4461 = load i64, ptr %slot716, align 8
  %p4462 = inttoptr i64 %v4461 to ptr
  %rgep4463 = getelementptr i8, ptr %p4462, i64 -16
  %ld4464 = load i64, ptr %rgep4463, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4464, ptr %slot719, align 8
  %v4465 = load i64, ptr %slot719, align 8
  %op4466 = and i64 %v4465, 4611686018427387906
  store i64 %op4466, ptr %slot720, align 8
  %v4467 = load i64, ptr %slot720, align 8
  %cmp4468 = icmp ne i64 %v4467, 0
  %cv4469 = zext i1 %cmp4468 to i32
  store i32 %cv4469, ptr %slot721, align 8
  %v4470 = load i32, ptr %slot721, align 8
  %cv4471 = zext i32 %v4470 to i64
  %cond4472 = icmp ne i64 %cv4471, 0
  br i1 %cond4472, label %bb_rcgclear1239, label %bb_rcgcounted1239
bb_rcgcounted1239:
  %v4473 = load i64, ptr %slot716, align 8
  %op4474 = sub i64 %v4473, 24
  store i64 %op4474, ptr %slot722, align 8
  %v4475 = load i64, ptr %slot716, align 8
  %p4476 = inttoptr i64 %v4475 to ptr
  %rgep4477 = getelementptr i8, ptr %p4476, i64 -24
  %ld4478 = load i64, ptr %rgep4477, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4478, ptr %slot723, align 8
  %v4479 = load i64, ptr %slot723, align 8
  %op4480 = sub i64 %v4479, 1
  store i64 %op4480, ptr %slot724, align 8
  %v4481 = load i64, ptr %slot724, align 8
  %cmp4482 = icmp eq i64 %v4481, 0
  %cv4483 = zext i1 %cmp4482 to i32
  store i32 %cv4483, ptr %slot725, align 8
  %v4484 = load i32, ptr %slot725, align 8
  %cv4485 = zext i32 %v4484 to i64
  %cond4486 = icmp ne i64 %cv4485, 0
  br i1 %cond4486, label %bb_rcglast1239, label %bb_rcgdec1239
bb_rcglast1239:
  %v4487 = load i64, ptr %slot716, align 8
  %op4488 = sub i64 %v4487, 32
  store i64 %op4488, ptr %slot726, align 8
  %v4489 = load i64, ptr %slot716, align 8
  %p4490 = inttoptr i64 %v4489 to ptr
  %rgep4491 = getelementptr i8, ptr %p4490, i64 -32
  %ld4492 = load i64, ptr %rgep4491, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4492, ptr %slot727, align 8
  %v4493 = load i64, ptr %slot727, align 8
  %cmp4494 = icmp ne i64 %v4493, 0
  %cv4495 = zext i1 %cmp4494 to i32
  store i32 %cv4495, ptr %slot728, align 8
  %v4496 = load i32, ptr %slot728, align 8
  %cv4497 = zext i32 %v4496 to i64
  %cond4498 = icmp ne i64 %cv4497, 0
  br i1 %cond4498, label %bb_rcgdec1239, label %bb_rcgslow1239
bb_rcgslow1239:
  %v4499 = load i64, ptr %slot715, align 8
  %v4500 = load i64, ptr %slot712, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4499, i64 %v4500) nomerge, !dbg !150
  br label %bb_rcgdone1239
bb_rcgdec1239:
  %v4501 = load i64, ptr %slot724, align 8
  %v4502 = load i64, ptr %slot716, align 8
  %p4503 = inttoptr i64 %v4502 to ptr
  %rgep4504 = getelementptr i8, ptr %p4503, i64 -24
  store i64 %v4501, ptr %rgep4504, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1239
bb_rcgclear1239:
  %v4505 = load i64, ptr %slot712, align 8
  %p4506 = inttoptr i64 %v4505 to ptr
  store i64 0, ptr %p4506, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1239
bb_rcgdone1239:
  br label %bb_rcslotdone1223
bb_rcslotowner1223:
  %v4507 = load i64, ptr %slot32, align 8
  store i64 %v4507, ptr %slot729, align 8
  %v4508 = load i64, ptr %slot712, align 8
  %p4509 = inttoptr i64 %v4508 to ptr
  %ld4510 = load i64, ptr %p4509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4510, ptr %slot730, align 8
  %v4511 = load i64, ptr %slot730, align 8
  %cmp4512 = icmp ne i64 %v4511, 0
  %cv4513 = zext i1 %cmp4512 to i32
  store i32 %cv4513, ptr %slot731, align 8
  %v4514 = load i32, ptr %slot731, align 8
  %cv4515 = zext i32 %v4514 to i64
  %cond4516 = icmp ne i64 %cv4515, 0
  br i1 %cond4516, label %bb_rcgnn1254, label %bb_rcgdone1254
bb_rcgnn1254:
  %v4517 = load i64, ptr %slot730, align 8
  %op4518 = sub i64 %v4517, 16
  store i64 %op4518, ptr %slot732, align 8
  %v4519 = load i64, ptr %slot730, align 8
  %p4520 = inttoptr i64 %v4519 to ptr
  %rgep4521 = getelementptr i8, ptr %p4520, i64 -16
  %ld4522 = load i64, ptr %rgep4521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4522, ptr %slot733, align 8
  %v4523 = load i64, ptr %slot733, align 8
  %op4524 = and i64 %v4523, 4611686018427387906
  store i64 %op4524, ptr %slot734, align 8
  %v4525 = load i64, ptr %slot734, align 8
  %cmp4526 = icmp ne i64 %v4525, 0
  %cv4527 = zext i1 %cmp4526 to i32
  store i32 %cv4527, ptr %slot735, align 8
  %v4528 = load i32, ptr %slot735, align 8
  %cv4529 = zext i32 %v4528 to i64
  %cond4530 = icmp ne i64 %cv4529, 0
  br i1 %cond4530, label %bb_rcgclear1254, label %bb_rcgcounted1254
bb_rcgcounted1254:
  %v4531 = load i64, ptr %slot730, align 8
  %op4532 = sub i64 %v4531, 32
  store i64 %op4532, ptr %slot736, align 8
  %v4533 = load i64, ptr %slot730, align 8
  %p4534 = inttoptr i64 %v4533 to ptr
  %rgep4535 = getelementptr i8, ptr %p4534, i64 -32
  %ld4536 = load i64, ptr %rgep4535, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4536, ptr %slot737, align 8
  %v4537 = load i64, ptr %slot737, align 8
  %op4538 = sub i64 %v4537, 1
  store i64 %op4538, ptr %slot738, align 8
  %v4539 = load i64, ptr %slot738, align 8
  %cmp4540 = icmp eq i64 %v4539, 0
  %cv4541 = zext i1 %cmp4540 to i32
  store i32 %cv4541, ptr %slot739, align 8
  %v4542 = load i32, ptr %slot739, align 8
  %cv4543 = zext i32 %v4542 to i64
  %cond4544 = icmp ne i64 %cv4543, 0
  br i1 %cond4544, label %bb_rcglast1254, label %bb_rcgdec1254
bb_rcglast1254:
  %v4545 = load i64, ptr %slot730, align 8
  %op4546 = sub i64 %v4545, 24
  store i64 %op4546, ptr %slot740, align 8
  %v4547 = load i64, ptr %slot730, align 8
  %p4548 = inttoptr i64 %v4547 to ptr
  %rgep4549 = getelementptr i8, ptr %p4548, i64 -24
  %ld4550 = load i64, ptr %rgep4549, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4550, ptr %slot741, align 8
  %v4551 = load i64, ptr %slot741, align 8
  %cmp4552 = icmp ne i64 %v4551, 0
  %cv4553 = zext i1 %cmp4552 to i32
  store i32 %cv4553, ptr %slot742, align 8
  %v4554 = load i32, ptr %slot742, align 8
  %cv4555 = zext i32 %v4554 to i64
  %cond4556 = icmp ne i64 %cv4555, 0
  br i1 %cond4556, label %bb_rcgdec1254, label %bb_rcgslow1254
bb_rcgslow1254:
  %v4557 = load i64, ptr %slot729, align 8
  %v4558 = load i64, ptr %slot712, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4557, i64 %v4558) nomerge, !dbg !150
  br label %bb_rcgdone1254
bb_rcgdec1254:
  %v4559 = load i64, ptr %slot738, align 8
  %v4560 = load i64, ptr %slot730, align 8
  %p4561 = inttoptr i64 %v4560 to ptr
  %rgep4562 = getelementptr i8, ptr %p4561, i64 -32
  store i64 %v4559, ptr %rgep4562, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1254
bb_rcgclear1254:
  %v4563 = load i64, ptr %slot712, align 8
  %p4564 = inttoptr i64 %v4563 to ptr
  store i64 0, ptr %p4564, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1254
bb_rcgdone1254:
  br label %bb_rcslotdone1223
bb_rcslotdone1223:
  br label %bb_rcprepared1169
bb_rcprepared1169:
  %v4565 = load i64, ptr %slot14, align 8
  store i64 %v4565, ptr %slot743, align 8
  %v4566 = load i64, ptr %slot743, align 8
  %v4567 = load i64, ptr %slot669, align 8
  %p4568 = inttoptr i64 %v4566 to ptr
  %p4569 = inttoptr i64 %v4567 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4569, ptr %p4568, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4570 = load i64, ptr %slot9, align 8
  %p4571 = inttoptr i64 %v4570 to ptr
  store i32 0, ptr %p4571, align 4, !alias.scope !3, !noalias !4
  %v4572 = load i64, ptr %slot21, align 8
  store i64 %v4572, ptr %slot744, align 8
  %v4573 = load i64, ptr %slot664, align 8
  %p4575 = inttoptr i64 %v4573 to ptr
  %gep4576 = getelementptr i8, ptr %p4575, i64 8
  %op4574 = ptrtoint ptr %gep4576 to i64
  store i64 %op4574, ptr %slot745, align 8
  %v4577 = load i64, ptr %slot744, align 8
  %p4578 = inttoptr i64 %v4577 to ptr
  %ld4579 = load i32, ptr %p4578, align 4, !alias.scope !3, !noalias !4
  %ext4580 = zext i32 %ld4579 to i64
  store i64 %ext4580, ptr %slot746, align 8
  %v4581 = load i64, ptr %slot746, align 8
  %cv4582 = trunc i64 %v4581 to i32
  %v4583 = load i64, ptr %slot745, align 8
  %p4584 = inttoptr i64 %v4583 to ptr
  store i32 %cv4582, ptr %p4584, align 4, !alias.scope !3, !noalias !4
  %v4585 = load i64, ptr %slot664, align 8
  %v4586 = load i64, ptr %slot20, align 8
  %p4587 = inttoptr i64 %v4586 to ptr
  store i64 %v4585, ptr %p4587, align 8, !alias.scope !3, !noalias !4
  %v4588 = load i64, ptr %slot20, align 8
  %p4589 = inttoptr i64 %v4588 to ptr
  %ld4590 = load i64, ptr %p4589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4590, ptr %slot747, align 8
  %v4591 = load i64, ptr %slot12, align 8
  store i64 %v4591, ptr %slot748, align 8
  %v4592 = load i64, ptr %slot747, align 8
  %v4593 = load i64, ptr %slot748, align 8
  %p4594 = inttoptr i64 %v4592 to ptr
  %p4595 = inttoptr i64 %v4593 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4595, ptr %p4594, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4596 = load i64, ptr %slot8, align 8
  %p4597 = inttoptr i64 %v4596 to ptr
  store i32 2, ptr %p4597, align 4, !alias.scope !3, !noalias !4
  %v4598 = load i64, ptr %slot7, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  store i32 1, ptr %p4599, align 4, !alias.scope !3, !noalias !4
  %v4600 = load i64, ptr %slot748, align 8
  %v4601 = load i64, ptr %slot20, align 8
  %p4602 = inttoptr i64 %v4601 to ptr
  store i64 %v4600, ptr %p4602, align 8, !alias.scope !3, !noalias !4
  %v4603 = load i64, ptr %slot20, align 8
  %p4604 = inttoptr i64 %v4603 to ptr
  %ld4605 = load i64, ptr %p4604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4605, ptr %slot749, align 8
  %v4606 = load i64, ptr %slot20, align 8
  %p4607 = inttoptr i64 %v4606 to ptr
  %ld4608 = load i64, ptr %p4607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4608, ptr %slot750, align 8
  %v4609 = load i64, ptr %slot14, align 8
  store i64 %v4609, ptr %slot751, align 8
  %v4610 = load i64, ptr %slot33, align 8
  store i64 %v4610, ptr %slot752, align 8
  %v4611 = load i64, ptr %slot750, align 8
  %op4612 = add i64 %v4611, 0
  store i64 %op4612, ptr %slot753, align 8
  %v4613 = load i64, ptr %slot753, align 8
  %p4614 = inttoptr i64 %v4613 to ptr
  %ld4615 = load i64, ptr %p4614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4615, ptr %slot754, align 8
  %v4616 = load i64, ptr %slot754, align 8
  %cmp4617 = icmp ne i64 %v4616, 0
  %cv4618 = zext i1 %cmp4617 to i32
  store i32 %cv4618, ptr %slot755, align 8
  %v4619 = load i32, ptr %slot755, align 8
  %cv4620 = zext i32 %v4619 to i64
  %cond4621 = icmp ne i64 %cv4620, 0
  br i1 %cond4621, label %bb_rcmoveheader1274, label %bb_rcmovenext1274
bb_rcmoveheader1274:
  %v4622 = load i64, ptr %slot754, align 8
  %op4623 = sub i64 %v4622, 16
  store i64 %op4623, ptr %slot756, align 8
  %v4624 = load i64, ptr %slot754, align 8
  %p4625 = inttoptr i64 %v4624 to ptr
  %rgep4626 = getelementptr i8, ptr %p4625, i64 -16
  %ld4627 = load i64, ptr %rgep4626, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4627, ptr %slot757, align 8
  %v4628 = load i64, ptr %slot757, align 8
  %op4629 = and i64 %v4628, 5764607523034234881
  store i64 %op4629, ptr %slot758, align 8
  %v4630 = load i64, ptr %slot758, align 8
  %cmp4631 = icmp ne i64 %v4630, 0
  %cv4632 = zext i1 %cmp4631 to i32
  store i32 %cv4632, ptr %slot759, align 8
  %v4633 = load i32, ptr %slot759, align 8
  %cv4634 = zext i32 %v4633 to i64
  %cond4635 = icmp ne i64 %cv4634, 0
  br i1 %cond4635, label %bb_rcmoveslow1271, label %bb_rcmovenext1274
bb_rcmovenext1274:
  %v4636 = load i64, ptr %slot750, align 8
  %v4637 = load i64, ptr %slot751, align 8
  %p4638 = inttoptr i64 %v4636 to ptr
  %p4639 = inttoptr i64 %v4637 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4639, ptr %p4638, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4640 = load i64, ptr %slot750, align 8
  %p4641 = inttoptr i64 %v4640 to ptr
  store i64 0, ptr %p4641, align 8, !alias.scope !3, !noalias !4
  %v4642 = load i64, ptr %slot750, align 8
  %op4643 = add i64 %v4642, 8
  store i64 %op4643, ptr %slot760, align 8
  %v4644 = load i64, ptr %slot760, align 8
  %p4645 = inttoptr i64 %v4644 to ptr
  store i64 0, ptr %p4645, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1271
bb_rcmoveslow1271:
  %v4646 = load i64, ptr %slot32, align 8
  %v4647 = load i64, ptr %slot751, align 8
  %v4648 = load i64, ptr %slot750, align 8
  %v4649 = load i64, ptr %slot752, align 8
  %cv4650 = trunc i64 %v4649 to i32
  %call4651 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v4646, i64 %v4647, i64 %v4648, i32 %cv4650) nomerge, !dbg !152
  store i32 %call4651, ptr %slot761, align 8
  %v4652 = load i32, ptr %slot761, align 8
  %cv4653 = zext i32 %v4652 to i64
  %cond4654 = icmp ne i64 %cv4653, 0
  br i1 %cond4654, label %bb_rcsuccess1282, label %bb_rcfailure1282
bb_rcfailure1282:
  %v4655 = load i64, ptr %slot32, align 8
  %p4656 = inttoptr i64 %v4655 to ptr
  %call4657 = call i32 @myl_rc_take_failure(ptr %p4656) nomerge, !dbg !152
  store i32 %call4657, ptr %slot762, align 8
  %v4658 = load i64, ptr %slot1, align 8
  %p4659 = inttoptr i64 %v4658 to ptr
  %v4660 = load i32, ptr %slot762, align 8
  %call4661 = call i32 @myl_qbe_rc_status(ptr %p4659, i32 %v4660) nomerge, !dbg !152
  store i32 %call4661, ptr %slot763, align 8
  br label %bb_failure
bb_rcsuccess1282:
  br label %bb_rcmoved1271
bb_rcmoved1271:
  %v4662 = load i64, ptr %slot7, align 8
  %p4663 = inttoptr i64 %v4662 to ptr
  store i32 0, ptr %p4663, align 4, !alias.scope !3, !noalias !4
  %v4664 = load i64, ptr %slot10, align 8
  %p4665 = inttoptr i64 %v4664 to ptr
  store i32 2, ptr %p4665, align 4, !alias.scope !3, !noalias !4
  %v4666 = load i64, ptr %slot9, align 8
  %p4667 = inttoptr i64 %v4666 to ptr
  store i32 1, ptr %p4667, align 4, !alias.scope !3, !noalias !4
  %v4668 = load i64, ptr %slot14, align 8
  store i64 %v4668, ptr %slot764, align 8
  %v4669 = load i64, ptr %slot9, align 8
  %p4670 = inttoptr i64 %v4669 to ptr
  store i32 0, ptr %p4670, align 4, !alias.scope !3, !noalias !4
  %v4671 = load i64, ptr %slot7, align 8
  %p4672 = inttoptr i64 %v4671 to ptr
  %ld4673 = load i32, ptr %p4672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4673, ptr %slot765, align 8
  %v4674 = load i32, ptr %slot765, align 8
  %cv4675 = zext i32 %v4674 to i64
  %cond4676 = icmp ne i64 %cv4675, 0
  br i1 %cond4676, label %bb_rcslotdrop1292, label %bb_rcslotdone1292
bb_rcslotdrop1292:
  %v4677 = load i64, ptr %slot7, align 8
  %p4678 = inttoptr i64 %v4677 to ptr
  store i32 0, ptr %p4678, align 4, !alias.scope !3, !noalias !4
  %v4679 = load i64, ptr %slot12, align 8
  store i64 %v4679, ptr %slot766, align 8
  %v4680 = load i64, ptr %slot8, align 8
  %p4681 = inttoptr i64 %v4680 to ptr
  %ld4682 = load i32, ptr %p4681, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4682, ptr %slot767, align 8
  %v4683 = load i32, ptr %slot767, align 8
  %op4684 = and i32 %v4683, 28
  store i32 %op4684, ptr %slot768, align 8
  %v4685 = load i32, ptr %slot768, align 8
  %cv4686 = zext i32 %v4685 to i64
  %cond4687 = icmp ne i64 %cv4686, 0
  br i1 %cond4687, label %bb_rcslotrole1292, label %bb_rcslotowner1292
bb_rcslotrole1292:
  %v4688 = load i64, ptr %slot32, align 8
  store i64 %v4688, ptr %slot769, align 8
  %v4689 = load i64, ptr %slot769, align 8
  %v4690 = load i64, ptr %slot766, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v4689, i64 %v4690) nomerge, !dbg !152
  br label %bb_rcslotdone1292
bb_rcslotowner1292:
  %v4691 = load i64, ptr %slot32, align 8
  store i64 %v4691, ptr %slot770, align 8
  %v4692 = load i64, ptr %slot770, align 8
  %v4693 = load i64, ptr %slot766, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v4692, i64 %v4693) nomerge, !dbg !152
  br label %bb_rcslotdone1292
bb_rcslotdone1292:
  %v4694 = load i64, ptr %slot764, align 8
  %p4695 = inttoptr i64 %v4694 to ptr
  %ret4696 = load { i64, i64 }, ptr %p4695, align 8
  ret { i64, i64 } %ret4696
bb_i49:
  %v4697 = load i64, ptr %slot20, align 8
  %p4698 = inttoptr i64 %v4697 to ptr
  store i64 0, ptr %p4698, align 8, !alias.scope !3, !noalias !4
  %v4699 = load i64, ptr %slot20, align 8
  %p4700 = inttoptr i64 %v4699 to ptr
  %ld4701 = load i64, ptr %p4700, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4701, ptr %slot771, align 8
  %v4702 = load i64, ptr %slot771, align 8
  %cond4703 = icmp ne i64 %v4702, 0
  br i1 %cond4703, label %bb_success1355, label %bb_failed1355
bb_failed1355:
  %v4704 = load i64, ptr %slot1, align 8
  %p4705 = inttoptr i64 %v4704 to ptr
  call void @myl_qbe_fail_assert(ptr %p4705) nomerge, !dbg !154
  unreachable
bb_success1355:
  %p4706 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld4707 = load i64, ptr %p4706, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4707, ptr %slot772, align 8
  %v4708 = load i64, ptr %slot772, align 8
  %v4709 = load i64, ptr %slot20, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  store i64 %v4708, ptr %p4710, align 8, !alias.scope !3, !noalias !4
  %v4711 = load i64, ptr %slot20, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  %ld4713 = load i64, ptr %p4712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4713, ptr %slot773, align 8
  %v4714 = load i64, ptr %slot773, align 8
  %v4715 = load i64, ptr %slot13, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  store i64 %v4714, ptr %p4716, align 8, !alias.scope !3, !noalias !4
  %v4717 = load i64, ptr %slot13, align 8
  store i64 %v4717, ptr %slot774, align 8
  %v4718 = load i64, ptr %slot14, align 8
  store i64 %v4718, ptr %slot775, align 8
  %v4719 = load i64, ptr %slot774, align 8
  %v4720 = load i64, ptr %slot775, align 8
  %p4721 = inttoptr i64 %v4719 to ptr
  %p4722 = inttoptr i64 %v4720 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4722, ptr %p4721, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4723 = load i64, ptr %slot10, align 8
  %p4724 = inttoptr i64 %v4723 to ptr
  store i32 2, ptr %p4724, align 4, !alias.scope !3, !noalias !4
  %v4725 = load i64, ptr %slot9, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  store i32 1, ptr %p4726, align 4, !alias.scope !3, !noalias !4
  %v4727 = load i64, ptr %slot12, align 8
  store i64 %v4727, ptr %slot776, align 8
  %v4728 = load i64, ptr %slot14, align 8
  store i64 %v4728, ptr %slot777, align 8
  %v4729 = load i64, ptr %slot777, align 8
  %v4730 = load i64, ptr %slot776, align 8
  %p4731 = inttoptr i64 %v4729 to ptr
  %p4732 = inttoptr i64 %v4730 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4732, ptr %p4731, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4733 = load i64, ptr %slot8, align 8
  %p4734 = inttoptr i64 %v4733 to ptr
  store i32 2, ptr %p4734, align 4, !alias.scope !3, !noalias !4
  %v4735 = load i64, ptr %slot10, align 8
  %p4736 = inttoptr i64 %v4735 to ptr
  %ld4737 = load i32, ptr %p4736, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4737, ptr %slot778, align 8
  %v4738 = load i32, ptr %slot778, align 8
  %v4739 = load i64, ptr %slot8, align 8
  %p4740 = inttoptr i64 %v4739 to ptr
  store i32 %v4738, ptr %p4740, align 4, !alias.scope !3, !noalias !4
  %v4741 = load i64, ptr %slot9, align 8
  %p4742 = inttoptr i64 %v4741 to ptr
  store i32 0, ptr %p4742, align 4, !alias.scope !3, !noalias !4
  %v4743 = load i64, ptr %slot7, align 8
  %p4744 = inttoptr i64 %v4743 to ptr
  store i32 1, ptr %p4744, align 4, !alias.scope !3, !noalias !4
  %v4745 = load i64, ptr %slot776, align 8
  %p4746 = inttoptr i64 %v4745 to ptr
  %ld4747 = load i64, ptr %p4746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4747, ptr %slot779, align 8
  %v4748 = load i64, ptr %slot779, align 8
  %v4749 = load i64, ptr %slot20, align 8
  %p4750 = inttoptr i64 %v4749 to ptr
  store i64 %v4748, ptr %p4750, align 8, !alias.scope !3, !noalias !4
  %v4751 = load i64, ptr %slot21, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  store i64 0, ptr %p4752, align 8, !alias.scope !3, !noalias !4
  %v4753 = load i64, ptr %slot27, align 8
  store i64 %v4753, ptr %slot780, align 8
  %v4754 = load i64, ptr %slot780, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  store i64 0, ptr %p4755, align 8, !alias.scope !3, !noalias !4
  %v4756 = load i64, ptr %slot780, align 8
  %p4758 = inttoptr i64 %v4756 to ptr
  %gep4759 = getelementptr i8, ptr %p4758, i64 8
  %op4757 = ptrtoint ptr %gep4759 to i64
  store i64 %op4757, ptr %slot781, align 8
  %v4760 = load i64, ptr %slot781, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  store i64 0, ptr %p4761, align 8, !alias.scope !3, !noalias !4
  %v4762 = load i64, ptr %slot11, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  store i32 1, ptr %p4763, align 4, !alias.scope !3, !noalias !4
  %v4764 = load i64, ptr %slot33, align 8
  store i64 %v4764, ptr %slot782, align 8
  %v4765 = load i64, ptr %slot20, align 8
  %p4766 = inttoptr i64 %v4765 to ptr
  %ld4767 = load i64, ptr %p4766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4767, ptr %slot783, align 8
  %v4768 = load i64, ptr %slot783, align 8
  %v4769 = load i64, ptr %slot13, align 8
  %p4770 = inttoptr i64 %v4769 to ptr
  store i64 %v4768, ptr %p4770, align 8, !alias.scope !3, !noalias !4
  %v4771 = load i64, ptr %slot13, align 8
  store i64 %v4771, ptr %slot784, align 8
  %v4772 = load i64, ptr %slot780, align 8
  %p4774 = inttoptr i64 %v4772 to ptr
  %gep4775 = getelementptr i8, ptr %p4774, i64 0
  %op4773 = ptrtoint ptr %gep4775 to i64
  store i64 %op4773, ptr %slot785, align 8
  %v4776 = load i64, ptr %slot20, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %ld4778 = load i64, ptr %p4777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4778, ptr %slot786, align 8
  %v4779 = load i64, ptr %slot786, align 8
  %v4780 = load i64, ptr %slot13, align 8
  %p4781 = inttoptr i64 %v4780 to ptr
  store i64 %v4779, ptr %p4781, align 8, !alias.scope !3, !noalias !4
  %v4782 = load i64, ptr %slot13, align 8
  store i64 %v4782, ptr %slot787, align 8
  %v4783 = load i64, ptr %slot7, align 8
  %p4784 = inttoptr i64 %v4783 to ptr
  %ld4785 = load i32, ptr %p4784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4785, ptr %slot788, align 8
  %v4786 = load i64, ptr %slot8, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  %ld4788 = load i32, ptr %p4787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4788, ptr %slot789, align 8
  %v4789 = load i32, ptr %slot789, align 8
  %op4790 = and i32 %v4789, 24
  store i32 %op4790, ptr %slot789, align 8
  %v4791 = load i32, ptr %slot789, align 8
  %cmp4792 = icmp eq i32 %v4791, 0
  %cv4793 = zext i1 %cmp4792 to i32
  store i32 %cv4793, ptr %slot790, align 8
  %v4794 = load i32, ptr %slot788, align 8
  %v4795 = load i32, ptr %slot790, align 8
  %op4796 = and i32 %v4794, %v4795
  store i32 %op4796, ptr %slot791, align 8
  %v4797 = load i32, ptr %slot791, align 8
  %cv4798 = zext i32 %v4797 to i64
  %cond4799 = icmp ne i64 %cv4798, 0
  br i1 %cond4799, label %bb_rctake1382, label %bb_rccopy1382
bb_rctake1382:
  %v4800 = load i64, ptr %slot14, align 8
  store i64 %v4800, ptr %slot792, align 8
  %v4801 = load i64, ptr %slot33, align 8
  store i64 %v4801, ptr %slot793, align 8
  %v4802 = load i64, ptr %slot787, align 8
  %v4803 = load i64, ptr %slot792, align 8
  %op4804 = sub i64 %v4802, %v4803
  store i64 %op4804, ptr %slot794, align 8
  %v4805 = load i64, ptr %slot792, align 8
  %v4806 = load i64, ptr %slot787, align 8
  %op4807 = sub i64 %v4805, %v4806
  store i64 %op4807, ptr %slot795, align 8
  %v4808 = load i64, ptr %slot794, align 8
  %cmp4809 = icmp ult i64 %v4808, 8
  %cv4810 = zext i1 %cmp4809 to i32
  store i32 %cv4810, ptr %slot796, align 8
  %v4811 = load i64, ptr %slot795, align 8
  %cmp4812 = icmp ult i64 %v4811, 8
  %cv4813 = zext i1 %cmp4812 to i32
  store i32 %cv4813, ptr %slot797, align 8
  %v4814 = load i32, ptr %slot796, align 8
  %v4815 = load i32, ptr %slot797, align 8
  %op4816 = or i32 %v4814, %v4815
  store i32 %op4816, ptr %slot798, align 8
  %v4817 = load i32, ptr %slot798, align 8
  %cv4818 = zext i32 %v4817 to i64
  %cond4819 = icmp ne i64 %cv4818, 0
  br i1 %cond4819, label %bb_rcmoveslow1391, label %bb_rcmovecheck1391
bb_rcmovecheck1391:
  %v4820 = load i64, ptr %slot787, align 8
  %p4822 = inttoptr i64 %v4820 to ptr
  %gep4823 = getelementptr i8, ptr %p4822, i64 0
  %op4821 = ptrtoint ptr %gep4823 to i64
  store i64 %op4821, ptr %slot799, align 8
  %v4824 = load i64, ptr %slot799, align 8
  %p4825 = inttoptr i64 %v4824 to ptr
  %ld4826 = load i64, ptr %p4825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4826, ptr %slot800, align 8
  %v4827 = load i64, ptr %slot800, align 8
  %cmp4828 = icmp ne i64 %v4827, 0
  %cv4829 = zext i1 %cmp4828 to i32
  store i32 %cv4829, ptr %slot801, align 8
  %v4830 = load i32, ptr %slot801, align 8
  %cv4831 = zext i32 %v4830 to i64
  %cond4832 = icmp ne i64 %cv4831, 0
  br i1 %cond4832, label %bb_rcmoveheader1399, label %bb_rcmovenext1399
bb_rcmoveheader1399:
  %v4833 = load i64, ptr %slot800, align 8
  %op4834 = sub i64 %v4833, 16
  store i64 %op4834, ptr %slot802, align 8
  %v4835 = load i64, ptr %slot800, align 8
  %p4836 = inttoptr i64 %v4835 to ptr
  %rgep4837 = getelementptr i8, ptr %p4836, i64 -16
  %ld4838 = load i64, ptr %rgep4837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4838, ptr %slot803, align 8
  %v4839 = load i64, ptr %slot803, align 8
  %op4840 = and i64 %v4839, 5764607523034234881
  store i64 %op4840, ptr %slot804, align 8
  %v4841 = load i64, ptr %slot804, align 8
  %cmp4842 = icmp ne i64 %v4841, 0
  %cv4843 = zext i1 %cmp4842 to i32
  store i32 %cv4843, ptr %slot805, align 8
  %v4844 = load i32, ptr %slot805, align 8
  %cv4845 = zext i32 %v4844 to i64
  %cond4846 = icmp ne i64 %cv4845, 0
  br i1 %cond4846, label %bb_rcmoveslow1391, label %bb_rcmovenext1399
bb_rcmovenext1399:
  %v4847 = load i64, ptr %slot787, align 8
  %v4848 = load i64, ptr %slot792, align 8
  %p4849 = inttoptr i64 %v4847 to ptr
  %p4850 = inttoptr i64 %v4848 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4850, ptr %p4849, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4851 = load i64, ptr %slot787, align 8
  %p4852 = inttoptr i64 %v4851 to ptr
  store i64 0, ptr %p4852, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1391
bb_rcmoveslow1391:
  %v4853 = load i64, ptr %slot32, align 8
  %v4854 = load i64, ptr %slot792, align 8
  %v4855 = load i64, ptr %slot787, align 8
  %v4856 = load i64, ptr %slot793, align 8
  %cv4857 = trunc i64 %v4856 to i32
  %call4858 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v4853, i64 %v4854, i64 %v4855, i32 %cv4857) nomerge, !dbg !156
  store i32 %call4858, ptr %slot806, align 8
  %v4859 = load i32, ptr %slot806, align 8
  %cv4860 = zext i32 %v4859 to i64
  %cond4861 = icmp ne i64 %cv4860, 0
  br i1 %cond4861, label %bb_rcsuccess1406, label %bb_rcfailure1406
bb_rcfailure1406:
  %v4862 = load i64, ptr %slot32, align 8
  %p4863 = inttoptr i64 %v4862 to ptr
  %call4864 = call i32 @myl_rc_take_failure(ptr %p4863) nomerge, !dbg !156
  store i32 %call4864, ptr %slot807, align 8
  %v4865 = load i64, ptr %slot1, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  %v4867 = load i32, ptr %slot807, align 8
  %call4868 = call i32 @myl_qbe_rc_status(ptr %p4866, i32 %v4867) nomerge, !dbg !156
  store i32 %call4868, ptr %slot808, align 8
  br label %bb_failure
bb_rcsuccess1406:
  br label %bb_rcmoved1391
bb_rcmoved1391:
  %v4869 = load i64, ptr %slot7, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  store i32 0, ptr %p4870, align 4, !alias.scope !3, !noalias !4
  %v4871 = load i64, ptr %slot10, align 8
  %p4872 = inttoptr i64 %v4871 to ptr
  store i32 2, ptr %p4872, align 4, !alias.scope !3, !noalias !4
  %v4873 = load i64, ptr %slot9, align 8
  %p4874 = inttoptr i64 %v4873 to ptr
  store i32 1, ptr %p4874, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1382
bb_rccopy1382:
  %v4875 = load i64, ptr %slot14, align 8
  store i64 %v4875, ptr %slot809, align 8
  %v4876 = load i64, ptr %slot33, align 8
  store i64 %v4876, ptr %slot810, align 8
  %v4877 = load i64, ptr %slot787, align 8
  %p4878 = inttoptr i64 %v4877 to ptr
  %ld4879 = load i64, ptr %p4878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4879, ptr %slot811, align 8
  %v4880 = load i64, ptr %slot811, align 8
  %cmp4881 = icmp ne i64 %v4880, 0
  %cv4882 = zext i1 %cmp4881 to i32
  store i32 %cv4882, ptr %slot812, align 8
  %v4883 = load i32, ptr %slot812, align 8
  %cv4884 = zext i32 %v4883 to i64
  %cond4885 = icmp ne i64 %cv4884, 0
  br i1 %cond4885, label %bb_rcgnn1415, label %bb_rcgplain1415
bb_rcgnn1415:
  %v4886 = load i64, ptr %slot811, align 8
  %op4887 = sub i64 %v4886, 16
  store i64 %op4887, ptr %slot813, align 8
  %v4888 = load i64, ptr %slot811, align 8
  %p4889 = inttoptr i64 %v4888 to ptr
  %rgep4890 = getelementptr i8, ptr %p4889, i64 -16
  %ld4891 = load i64, ptr %rgep4890, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4891, ptr %slot814, align 8
  %v4892 = load i64, ptr %slot814, align 8
  %op4893 = and i64 %v4892, 4611686018427387906
  store i64 %op4893, ptr %slot815, align 8
  %v4894 = load i64, ptr %slot815, align 8
  %cmp4895 = icmp ne i64 %v4894, 0
  %cv4896 = zext i1 %cmp4895 to i32
  store i32 %cv4896, ptr %slot816, align 8
  %v4897 = load i32, ptr %slot816, align 8
  %cv4898 = zext i32 %v4897 to i64
  %cond4899 = icmp ne i64 %cv4898, 0
  br i1 %cond4899, label %bb_rcgspecial1415, label %bb_rcginc1415
bb_rcginc1415:
  %v4900 = load i64, ptr %slot811, align 8
  %op4901 = sub i64 %v4900, 32
  store i64 %op4901, ptr %slot817, align 8
  %v4902 = load i64, ptr %slot811, align 8
  %p4903 = inttoptr i64 %v4902 to ptr
  %rgep4904 = getelementptr i8, ptr %p4903, i64 -32
  %ld4905 = load i64, ptr %rgep4904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4905, ptr %slot818, align 8
  %v4906 = load i64, ptr %slot818, align 8
  %op4907 = add i64 %v4906, 1
  store i64 %op4907, ptr %slot819, align 8
  %v4908 = load i64, ptr %slot819, align 8
  %cmp4909 = icmp eq i64 %v4908, 0
  %cv4910 = zext i1 %cmp4909 to i32
  store i32 %cv4910, ptr %slot820, align 8
  %v4911 = load i32, ptr %slot820, align 8
  %cv4912 = zext i32 %v4911 to i64
  %cond4913 = icmp ne i64 %cv4912, 0
  br i1 %cond4913, label %bb_rcglimit1415, label %bb_rcgcapacity1415
bb_rcglimit1415:
  %v4914 = load i64, ptr %slot1, align 8
  %p4915 = inttoptr i64 %v4914 to ptr
  %call4916 = call i32 @myl_qbe_rc_status(ptr %p4915, i32 2) nomerge, !dbg !156
  store i32 %call4916, ptr %slot821, align 8
  br label %bb_failure
bb_rcgcapacity1415:
  %v4917 = load i64, ptr %slot819, align 8
  %v4918 = load i64, ptr %slot811, align 8
  %p4919 = inttoptr i64 %v4918 to ptr
  %rgep4920 = getelementptr i8, ptr %p4919, i64 -32
  store i64 %v4917, ptr %rgep4920, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1415
bb_rcgspecial1415:
  %v4921 = load i64, ptr %slot814, align 8
  %op4922 = and i64 %v4921, 4611686018427387904
  store i64 %op4922, ptr %slot822, align 8
  %v4923 = load i64, ptr %slot822, align 8
  %cmp4924 = icmp ne i64 %v4923, 0
  %cv4925 = zext i1 %cmp4924 to i32
  store i32 %cv4925, ptr %slot823, align 8
  %v4926 = load i32, ptr %slot823, align 8
  %cv4927 = zext i32 %v4926 to i64
  %cond4928 = icmp ne i64 %cv4927, 0
  br i1 %cond4928, label %bb_rcgslow1415, label %bb_rcgplain1415
bb_rcgslow1415:
  %v4929 = load i64, ptr %slot32, align 8
  %v4930 = load i64, ptr %slot809, align 8
  %v4931 = load i64, ptr %slot787, align 8
  %v4932 = load i64, ptr %slot810, align 8
  %cv4933 = trunc i64 %v4932 to i32
  %call4934 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v4929, i64 %v4930, i64 %v4931, i32 %cv4933) nomerge, !dbg !156
  store i32 %call4934, ptr %slot824, align 8
  %v4935 = load i32, ptr %slot824, align 8
  %cv4936 = zext i32 %v4935 to i64
  %cond4937 = icmp ne i64 %cv4936, 0
  br i1 %cond4937, label %bb_rcsuccess1429, label %bb_rcfailure1429
bb_rcfailure1429:
  %v4938 = load i64, ptr %slot32, align 8
  %p4939 = inttoptr i64 %v4938 to ptr
  %call4940 = call i32 @myl_rc_take_failure(ptr %p4939) nomerge, !dbg !156
  store i32 %call4940, ptr %slot825, align 8
  %v4941 = load i64, ptr %slot1, align 8
  %p4942 = inttoptr i64 %v4941 to ptr
  %v4943 = load i32, ptr %slot825, align 8
  %call4944 = call i32 @myl_qbe_rc_status(ptr %p4942, i32 %v4943) nomerge, !dbg !156
  store i32 %call4944, ptr %slot826, align 8
  br label %bb_failure
bb_rcsuccess1429:
  br label %bb_rcgdone1415
bb_rcgplain1415:
  %v4945 = load i64, ptr %slot811, align 8
  %v4946 = load i64, ptr %slot809, align 8
  %p4947 = inttoptr i64 %v4946 to ptr
  store i64 %v4945, ptr %p4947, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1415
bb_rcgdone1415:
  %v4948 = load i64, ptr %slot10, align 8
  %p4949 = inttoptr i64 %v4948 to ptr
  store i32 2, ptr %p4949, align 4, !alias.scope !3, !noalias !4
  %v4950 = load i64, ptr %slot9, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  store i32 1, ptr %p4951, align 4, !alias.scope !3, !noalias !4
  %v4952 = load i64, ptr %slot7, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %ld4954 = load i32, ptr %p4953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4954, ptr %slot827, align 8
  %v4955 = load i32, ptr %slot827, align 8
  %cv4956 = zext i32 %v4955 to i64
  %cond4957 = icmp ne i64 %cv4956, 0
  br i1 %cond4957, label %bb_rcslotdrop1436, label %bb_rcslotdone1436
bb_rcslotdrop1436:
  %v4958 = load i64, ptr %slot7, align 8
  %p4959 = inttoptr i64 %v4958 to ptr
  store i32 0, ptr %p4959, align 4, !alias.scope !3, !noalias !4
  %v4960 = load i64, ptr %slot12, align 8
  store i64 %v4960, ptr %slot828, align 8
  %v4961 = load i64, ptr %slot8, align 8
  %p4962 = inttoptr i64 %v4961 to ptr
  %ld4963 = load i32, ptr %p4962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4963, ptr %slot829, align 8
  %v4964 = load i32, ptr %slot829, align 8
  %op4965 = and i32 %v4964, 28
  store i32 %op4965, ptr %slot830, align 8
  %v4966 = load i32, ptr %slot830, align 8
  %cv4967 = zext i32 %v4966 to i64
  %cond4968 = icmp ne i64 %cv4967, 0
  br i1 %cond4968, label %bb_rcslotrole1436, label %bb_rcslotowner1436
bb_rcslotrole1436:
  %v4969 = load i64, ptr %slot32, align 8
  store i64 %v4969, ptr %slot831, align 8
  %v4970 = load i64, ptr %slot828, align 8
  %p4971 = inttoptr i64 %v4970 to ptr
  %ld4972 = load i64, ptr %p4971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4972, ptr %slot832, align 8
  %v4973 = load i64, ptr %slot832, align 8
  %cmp4974 = icmp ne i64 %v4973, 0
  %cv4975 = zext i1 %cmp4974 to i32
  store i32 %cv4975, ptr %slot833, align 8
  %v4976 = load i32, ptr %slot833, align 8
  %cv4977 = zext i32 %v4976 to i64
  %cond4978 = icmp ne i64 %cv4977, 0
  br i1 %cond4978, label %bb_rcgnn1452, label %bb_rcgdone1452
bb_rcgnn1452:
  %v4979 = load i64, ptr %slot832, align 8
  %op4980 = sub i64 %v4979, 16
  store i64 %op4980, ptr %slot834, align 8
  %v4981 = load i64, ptr %slot832, align 8
  %p4982 = inttoptr i64 %v4981 to ptr
  %rgep4983 = getelementptr i8, ptr %p4982, i64 -16
  %ld4984 = load i64, ptr %rgep4983, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4984, ptr %slot835, align 8
  %v4985 = load i64, ptr %slot835, align 8
  %op4986 = and i64 %v4985, 4611686018427387906
  store i64 %op4986, ptr %slot836, align 8
  %v4987 = load i64, ptr %slot836, align 8
  %cmp4988 = icmp ne i64 %v4987, 0
  %cv4989 = zext i1 %cmp4988 to i32
  store i32 %cv4989, ptr %slot837, align 8
  %v4990 = load i32, ptr %slot837, align 8
  %cv4991 = zext i32 %v4990 to i64
  %cond4992 = icmp ne i64 %cv4991, 0
  br i1 %cond4992, label %bb_rcgclear1452, label %bb_rcgcounted1452
bb_rcgcounted1452:
  %v4993 = load i64, ptr %slot832, align 8
  %op4994 = sub i64 %v4993, 24
  store i64 %op4994, ptr %slot838, align 8
  %v4995 = load i64, ptr %slot832, align 8
  %p4996 = inttoptr i64 %v4995 to ptr
  %rgep4997 = getelementptr i8, ptr %p4996, i64 -24
  %ld4998 = load i64, ptr %rgep4997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4998, ptr %slot839, align 8
  %v4999 = load i64, ptr %slot839, align 8
  %op5000 = sub i64 %v4999, 1
  store i64 %op5000, ptr %slot840, align 8
  %v5001 = load i64, ptr %slot840, align 8
  %cmp5002 = icmp eq i64 %v5001, 0
  %cv5003 = zext i1 %cmp5002 to i32
  store i32 %cv5003, ptr %slot841, align 8
  %v5004 = load i32, ptr %slot841, align 8
  %cv5005 = zext i32 %v5004 to i64
  %cond5006 = icmp ne i64 %cv5005, 0
  br i1 %cond5006, label %bb_rcglast1452, label %bb_rcgdec1452
bb_rcglast1452:
  %v5007 = load i64, ptr %slot832, align 8
  %op5008 = sub i64 %v5007, 32
  store i64 %op5008, ptr %slot842, align 8
  %v5009 = load i64, ptr %slot832, align 8
  %p5010 = inttoptr i64 %v5009 to ptr
  %rgep5011 = getelementptr i8, ptr %p5010, i64 -32
  %ld5012 = load i64, ptr %rgep5011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5012, ptr %slot843, align 8
  %v5013 = load i64, ptr %slot843, align 8
  %cmp5014 = icmp ne i64 %v5013, 0
  %cv5015 = zext i1 %cmp5014 to i32
  store i32 %cv5015, ptr %slot844, align 8
  %v5016 = load i32, ptr %slot844, align 8
  %cv5017 = zext i32 %v5016 to i64
  %cond5018 = icmp ne i64 %cv5017, 0
  br i1 %cond5018, label %bb_rcgdec1452, label %bb_rcgslow1452
bb_rcgslow1452:
  %v5019 = load i64, ptr %slot831, align 8
  %v5020 = load i64, ptr %slot828, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5019, i64 %v5020) nomerge, !dbg !156
  br label %bb_rcgdone1452
bb_rcgdec1452:
  %v5021 = load i64, ptr %slot840, align 8
  %v5022 = load i64, ptr %slot832, align 8
  %p5023 = inttoptr i64 %v5022 to ptr
  %rgep5024 = getelementptr i8, ptr %p5023, i64 -24
  store i64 %v5021, ptr %rgep5024, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1452
bb_rcgclear1452:
  %v5025 = load i64, ptr %slot828, align 8
  %p5026 = inttoptr i64 %v5025 to ptr
  store i64 0, ptr %p5026, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1452
bb_rcgdone1452:
  br label %bb_rcslotdone1436
bb_rcslotowner1436:
  %v5027 = load i64, ptr %slot32, align 8
  store i64 %v5027, ptr %slot845, align 8
  %v5028 = load i64, ptr %slot828, align 8
  %p5029 = inttoptr i64 %v5028 to ptr
  %ld5030 = load i64, ptr %p5029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5030, ptr %slot846, align 8
  %v5031 = load i64, ptr %slot846, align 8
  %cmp5032 = icmp ne i64 %v5031, 0
  %cv5033 = zext i1 %cmp5032 to i32
  store i32 %cv5033, ptr %slot847, align 8
  %v5034 = load i32, ptr %slot847, align 8
  %cv5035 = zext i32 %v5034 to i64
  %cond5036 = icmp ne i64 %cv5035, 0
  br i1 %cond5036, label %bb_rcgnn1467, label %bb_rcgdone1467
bb_rcgnn1467:
  %v5037 = load i64, ptr %slot846, align 8
  %op5038 = sub i64 %v5037, 16
  store i64 %op5038, ptr %slot848, align 8
  %v5039 = load i64, ptr %slot846, align 8
  %p5040 = inttoptr i64 %v5039 to ptr
  %rgep5041 = getelementptr i8, ptr %p5040, i64 -16
  %ld5042 = load i64, ptr %rgep5041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5042, ptr %slot849, align 8
  %v5043 = load i64, ptr %slot849, align 8
  %op5044 = and i64 %v5043, 4611686018427387906
  store i64 %op5044, ptr %slot850, align 8
  %v5045 = load i64, ptr %slot850, align 8
  %cmp5046 = icmp ne i64 %v5045, 0
  %cv5047 = zext i1 %cmp5046 to i32
  store i32 %cv5047, ptr %slot851, align 8
  %v5048 = load i32, ptr %slot851, align 8
  %cv5049 = zext i32 %v5048 to i64
  %cond5050 = icmp ne i64 %cv5049, 0
  br i1 %cond5050, label %bb_rcgclear1467, label %bb_rcgcounted1467
bb_rcgcounted1467:
  %v5051 = load i64, ptr %slot846, align 8
  %op5052 = sub i64 %v5051, 32
  store i64 %op5052, ptr %slot852, align 8
  %v5053 = load i64, ptr %slot846, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  %rgep5055 = getelementptr i8, ptr %p5054, i64 -32
  %ld5056 = load i64, ptr %rgep5055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5056, ptr %slot853, align 8
  %v5057 = load i64, ptr %slot853, align 8
  %op5058 = sub i64 %v5057, 1
  store i64 %op5058, ptr %slot854, align 8
  %v5059 = load i64, ptr %slot854, align 8
  %cmp5060 = icmp eq i64 %v5059, 0
  %cv5061 = zext i1 %cmp5060 to i32
  store i32 %cv5061, ptr %slot855, align 8
  %v5062 = load i32, ptr %slot855, align 8
  %cv5063 = zext i32 %v5062 to i64
  %cond5064 = icmp ne i64 %cv5063, 0
  br i1 %cond5064, label %bb_rcglast1467, label %bb_rcgdec1467
bb_rcglast1467:
  %v5065 = load i64, ptr %slot846, align 8
  %op5066 = sub i64 %v5065, 24
  store i64 %op5066, ptr %slot856, align 8
  %v5067 = load i64, ptr %slot846, align 8
  %p5068 = inttoptr i64 %v5067 to ptr
  %rgep5069 = getelementptr i8, ptr %p5068, i64 -24
  %ld5070 = load i64, ptr %rgep5069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5070, ptr %slot857, align 8
  %v5071 = load i64, ptr %slot857, align 8
  %cmp5072 = icmp ne i64 %v5071, 0
  %cv5073 = zext i1 %cmp5072 to i32
  store i32 %cv5073, ptr %slot858, align 8
  %v5074 = load i32, ptr %slot858, align 8
  %cv5075 = zext i32 %v5074 to i64
  %cond5076 = icmp ne i64 %cv5075, 0
  br i1 %cond5076, label %bb_rcgdec1467, label %bb_rcgslow1467
bb_rcgslow1467:
  %v5077 = load i64, ptr %slot845, align 8
  %v5078 = load i64, ptr %slot828, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5077, i64 %v5078) nomerge, !dbg !156
  br label %bb_rcgdone1467
bb_rcgdec1467:
  %v5079 = load i64, ptr %slot854, align 8
  %v5080 = load i64, ptr %slot846, align 8
  %p5081 = inttoptr i64 %v5080 to ptr
  %rgep5082 = getelementptr i8, ptr %p5081, i64 -32
  store i64 %v5079, ptr %rgep5082, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1467
bb_rcgclear1467:
  %v5083 = load i64, ptr %slot828, align 8
  %p5084 = inttoptr i64 %v5083 to ptr
  store i64 0, ptr %p5084, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1467
bb_rcgdone1467:
  br label %bb_rcslotdone1436
bb_rcslotdone1436:
  br label %bb_rcprepared1382
bb_rcprepared1382:
  %v5085 = load i64, ptr %slot14, align 8
  store i64 %v5085, ptr %slot859, align 8
  %v5086 = load i64, ptr %slot859, align 8
  %v5087 = load i64, ptr %slot785, align 8
  %p5088 = inttoptr i64 %v5086 to ptr
  %p5089 = inttoptr i64 %v5087 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5089, ptr %p5088, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5090 = load i64, ptr %slot9, align 8
  %p5091 = inttoptr i64 %v5090 to ptr
  store i32 0, ptr %p5091, align 4, !alias.scope !3, !noalias !4
  %v5092 = load i64, ptr %slot21, align 8
  store i64 %v5092, ptr %slot860, align 8
  %v5093 = load i64, ptr %slot780, align 8
  %p5095 = inttoptr i64 %v5093 to ptr
  %gep5096 = getelementptr i8, ptr %p5095, i64 8
  %op5094 = ptrtoint ptr %gep5096 to i64
  store i64 %op5094, ptr %slot861, align 8
  %v5097 = load i64, ptr %slot860, align 8
  %p5098 = inttoptr i64 %v5097 to ptr
  %ld5099 = load i32, ptr %p5098, align 4, !alias.scope !3, !noalias !4
  %ext5100 = zext i32 %ld5099 to i64
  store i64 %ext5100, ptr %slot862, align 8
  %v5101 = load i64, ptr %slot862, align 8
  %cv5102 = trunc i64 %v5101 to i32
  %v5103 = load i64, ptr %slot861, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  store i32 %cv5102, ptr %p5104, align 4, !alias.scope !3, !noalias !4
  %v5105 = load i64, ptr %slot780, align 8
  %v5106 = load i64, ptr %slot20, align 8
  %p5107 = inttoptr i64 %v5106 to ptr
  store i64 %v5105, ptr %p5107, align 8, !alias.scope !3, !noalias !4
  %v5108 = load i64, ptr %slot20, align 8
  %p5109 = inttoptr i64 %v5108 to ptr
  %ld5110 = load i64, ptr %p5109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5110, ptr %slot863, align 8
  %v5111 = load i64, ptr %slot12, align 8
  store i64 %v5111, ptr %slot864, align 8
  %v5112 = load i64, ptr %slot863, align 8
  %v5113 = load i64, ptr %slot864, align 8
  %p5114 = inttoptr i64 %v5112 to ptr
  %p5115 = inttoptr i64 %v5113 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5115, ptr %p5114, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5116 = load i64, ptr %slot8, align 8
  %p5117 = inttoptr i64 %v5116 to ptr
  store i32 2, ptr %p5117, align 4, !alias.scope !3, !noalias !4
  %v5118 = load i64, ptr %slot7, align 8
  %p5119 = inttoptr i64 %v5118 to ptr
  store i32 1, ptr %p5119, align 4, !alias.scope !3, !noalias !4
  %v5120 = load i64, ptr %slot864, align 8
  %v5121 = load i64, ptr %slot20, align 8
  %p5122 = inttoptr i64 %v5121 to ptr
  store i64 %v5120, ptr %p5122, align 8, !alias.scope !3, !noalias !4
  %v5123 = load i64, ptr %slot20, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  %ld5125 = load i64, ptr %p5124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5125, ptr %slot865, align 8
  %v5126 = load i64, ptr %slot20, align 8
  %p5127 = inttoptr i64 %v5126 to ptr
  %ld5128 = load i64, ptr %p5127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5128, ptr %slot866, align 8
  %v5129 = load i64, ptr %slot14, align 8
  store i64 %v5129, ptr %slot867, align 8
  %v5130 = load i64, ptr %slot33, align 8
  store i64 %v5130, ptr %slot868, align 8
  %v5131 = load i64, ptr %slot866, align 8
  %op5132 = add i64 %v5131, 0
  store i64 %op5132, ptr %slot869, align 8
  %v5133 = load i64, ptr %slot869, align 8
  %p5134 = inttoptr i64 %v5133 to ptr
  %ld5135 = load i64, ptr %p5134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5135, ptr %slot870, align 8
  %v5136 = load i64, ptr %slot870, align 8
  %cmp5137 = icmp ne i64 %v5136, 0
  %cv5138 = zext i1 %cmp5137 to i32
  store i32 %cv5138, ptr %slot871, align 8
  %v5139 = load i32, ptr %slot871, align 8
  %cv5140 = zext i32 %v5139 to i64
  %cond5141 = icmp ne i64 %cv5140, 0
  br i1 %cond5141, label %bb_rcmoveheader1487, label %bb_rcmovenext1487
bb_rcmoveheader1487:
  %v5142 = load i64, ptr %slot870, align 8
  %op5143 = sub i64 %v5142, 16
  store i64 %op5143, ptr %slot872, align 8
  %v5144 = load i64, ptr %slot870, align 8
  %p5145 = inttoptr i64 %v5144 to ptr
  %rgep5146 = getelementptr i8, ptr %p5145, i64 -16
  %ld5147 = load i64, ptr %rgep5146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5147, ptr %slot873, align 8
  %v5148 = load i64, ptr %slot873, align 8
  %op5149 = and i64 %v5148, 5764607523034234881
  store i64 %op5149, ptr %slot874, align 8
  %v5150 = load i64, ptr %slot874, align 8
  %cmp5151 = icmp ne i64 %v5150, 0
  %cv5152 = zext i1 %cmp5151 to i32
  store i32 %cv5152, ptr %slot875, align 8
  %v5153 = load i32, ptr %slot875, align 8
  %cv5154 = zext i32 %v5153 to i64
  %cond5155 = icmp ne i64 %cv5154, 0
  br i1 %cond5155, label %bb_rcmoveslow1484, label %bb_rcmovenext1487
bb_rcmovenext1487:
  %v5156 = load i64, ptr %slot866, align 8
  %v5157 = load i64, ptr %slot867, align 8
  %p5158 = inttoptr i64 %v5156 to ptr
  %p5159 = inttoptr i64 %v5157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5159, ptr %p5158, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5160 = load i64, ptr %slot866, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  store i64 0, ptr %p5161, align 8, !alias.scope !3, !noalias !4
  %v5162 = load i64, ptr %slot866, align 8
  %op5163 = add i64 %v5162, 8
  store i64 %op5163, ptr %slot876, align 8
  %v5164 = load i64, ptr %slot876, align 8
  %p5165 = inttoptr i64 %v5164 to ptr
  store i64 0, ptr %p5165, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1484
bb_rcmoveslow1484:
  %v5166 = load i64, ptr %slot32, align 8
  %v5167 = load i64, ptr %slot867, align 8
  %v5168 = load i64, ptr %slot866, align 8
  %v5169 = load i64, ptr %slot868, align 8
  %cv5170 = trunc i64 %v5169 to i32
  %call5171 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v5166, i64 %v5167, i64 %v5168, i32 %cv5170) nomerge, !dbg !158
  store i32 %call5171, ptr %slot877, align 8
  %v5172 = load i32, ptr %slot877, align 8
  %cv5173 = zext i32 %v5172 to i64
  %cond5174 = icmp ne i64 %cv5173, 0
  br i1 %cond5174, label %bb_rcsuccess1495, label %bb_rcfailure1495
bb_rcfailure1495:
  %v5175 = load i64, ptr %slot32, align 8
  %p5176 = inttoptr i64 %v5175 to ptr
  %call5177 = call i32 @myl_rc_take_failure(ptr %p5176) nomerge, !dbg !158
  store i32 %call5177, ptr %slot878, align 8
  %v5178 = load i64, ptr %slot1, align 8
  %p5179 = inttoptr i64 %v5178 to ptr
  %v5180 = load i32, ptr %slot878, align 8
  %call5181 = call i32 @myl_qbe_rc_status(ptr %p5179, i32 %v5180) nomerge, !dbg !158
  store i32 %call5181, ptr %slot879, align 8
  br label %bb_failure
bb_rcsuccess1495:
  br label %bb_rcmoved1484
bb_rcmoved1484:
  %v5182 = load i64, ptr %slot7, align 8
  %p5183 = inttoptr i64 %v5182 to ptr
  store i32 0, ptr %p5183, align 4, !alias.scope !3, !noalias !4
  %v5184 = load i64, ptr %slot10, align 8
  %p5185 = inttoptr i64 %v5184 to ptr
  store i32 2, ptr %p5185, align 4, !alias.scope !3, !noalias !4
  %v5186 = load i64, ptr %slot9, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  store i32 1, ptr %p5187, align 4, !alias.scope !3, !noalias !4
  %v5188 = load i64, ptr %slot14, align 8
  store i64 %v5188, ptr %slot880, align 8
  %v5189 = load i64, ptr %slot9, align 8
  %p5190 = inttoptr i64 %v5189 to ptr
  store i32 0, ptr %p5190, align 4, !alias.scope !3, !noalias !4
  %v5191 = load i64, ptr %slot7, align 8
  %p5192 = inttoptr i64 %v5191 to ptr
  %ld5193 = load i32, ptr %p5192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5193, ptr %slot881, align 8
  %v5194 = load i32, ptr %slot881, align 8
  %cv5195 = zext i32 %v5194 to i64
  %cond5196 = icmp ne i64 %cv5195, 0
  br i1 %cond5196, label %bb_rcslotdrop1505, label %bb_rcslotdone1505
bb_rcslotdrop1505:
  %v5197 = load i64, ptr %slot7, align 8
  %p5198 = inttoptr i64 %v5197 to ptr
  store i32 0, ptr %p5198, align 4, !alias.scope !3, !noalias !4
  %v5199 = load i64, ptr %slot12, align 8
  store i64 %v5199, ptr %slot882, align 8
  %v5200 = load i64, ptr %slot8, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  %ld5202 = load i32, ptr %p5201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5202, ptr %slot883, align 8
  %v5203 = load i32, ptr %slot883, align 8
  %op5204 = and i32 %v5203, 28
  store i32 %op5204, ptr %slot884, align 8
  %v5205 = load i32, ptr %slot884, align 8
  %cv5206 = zext i32 %v5205 to i64
  %cond5207 = icmp ne i64 %cv5206, 0
  br i1 %cond5207, label %bb_rcslotrole1505, label %bb_rcslotowner1505
bb_rcslotrole1505:
  %v5208 = load i64, ptr %slot32, align 8
  store i64 %v5208, ptr %slot885, align 8
  %v5209 = load i64, ptr %slot885, align 8
  %v5210 = load i64, ptr %slot882, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v5209, i64 %v5210) nomerge, !dbg !158
  br label %bb_rcslotdone1505
bb_rcslotowner1505:
  %v5211 = load i64, ptr %slot32, align 8
  store i64 %v5211, ptr %slot886, align 8
  %v5212 = load i64, ptr %slot886, align 8
  %v5213 = load i64, ptr %slot882, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v5212, i64 %v5213) nomerge, !dbg !158
  br label %bb_rcslotdone1505
bb_rcslotdone1505:
  %v5214 = load i64, ptr %slot880, align 8
  %p5215 = inttoptr i64 %v5214 to ptr
  %ret5216 = load { i64, i64 }, ptr %p5215, align 8
  ret { i64, i64 } %ret5216
bb_i55:
  %v5217 = load i64, ptr %slot20, align 8
  %p5218 = inttoptr i64 %v5217 to ptr
  store i64 0, ptr %p5218, align 8, !alias.scope !3, !noalias !4
  %v5219 = load i64, ptr %slot20, align 8
  %p5220 = inttoptr i64 %v5219 to ptr
  %ld5221 = load i64, ptr %p5220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5221, ptr %slot887, align 8
  %v5222 = load i64, ptr %slot887, align 8
  %cond5223 = icmp ne i64 %v5222, 0
  br i1 %cond5223, label %bb_success1568, label %bb_failed1568
bb_failed1568:
  %v5224 = load i64, ptr %slot1, align 8
  %p5225 = inttoptr i64 %v5224 to ptr
  call void @myl_qbe_fail_assert(ptr %p5225) nomerge, !dbg !160
  unreachable
bb_success1568:
  %p5226 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld5227 = load i64, ptr %p5226, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5227, ptr %slot888, align 8
  %v5228 = load i64, ptr %slot888, align 8
  %v5229 = load i64, ptr %slot20, align 8
  %p5230 = inttoptr i64 %v5229 to ptr
  store i64 %v5228, ptr %p5230, align 8, !alias.scope !3, !noalias !4
  %v5231 = load i64, ptr %slot20, align 8
  %p5232 = inttoptr i64 %v5231 to ptr
  %ld5233 = load i64, ptr %p5232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5233, ptr %slot889, align 8
  %v5234 = load i64, ptr %slot889, align 8
  %v5235 = load i64, ptr %slot13, align 8
  %p5236 = inttoptr i64 %v5235 to ptr
  store i64 %v5234, ptr %p5236, align 8, !alias.scope !3, !noalias !4
  %v5237 = load i64, ptr %slot13, align 8
  store i64 %v5237, ptr %slot890, align 8
  %v5238 = load i64, ptr %slot14, align 8
  store i64 %v5238, ptr %slot891, align 8
  %v5239 = load i64, ptr %slot890, align 8
  %v5240 = load i64, ptr %slot891, align 8
  %p5241 = inttoptr i64 %v5239 to ptr
  %p5242 = inttoptr i64 %v5240 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5242, ptr %p5241, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5243 = load i64, ptr %slot10, align 8
  %p5244 = inttoptr i64 %v5243 to ptr
  store i32 2, ptr %p5244, align 4, !alias.scope !3, !noalias !4
  %v5245 = load i64, ptr %slot9, align 8
  %p5246 = inttoptr i64 %v5245 to ptr
  store i32 1, ptr %p5246, align 4, !alias.scope !3, !noalias !4
  %v5247 = load i64, ptr %slot12, align 8
  store i64 %v5247, ptr %slot892, align 8
  %v5248 = load i64, ptr %slot14, align 8
  store i64 %v5248, ptr %slot893, align 8
  %v5249 = load i64, ptr %slot893, align 8
  %v5250 = load i64, ptr %slot892, align 8
  %p5251 = inttoptr i64 %v5249 to ptr
  %p5252 = inttoptr i64 %v5250 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5252, ptr %p5251, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5253 = load i64, ptr %slot8, align 8
  %p5254 = inttoptr i64 %v5253 to ptr
  store i32 2, ptr %p5254, align 4, !alias.scope !3, !noalias !4
  %v5255 = load i64, ptr %slot10, align 8
  %p5256 = inttoptr i64 %v5255 to ptr
  %ld5257 = load i32, ptr %p5256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5257, ptr %slot894, align 8
  %v5258 = load i32, ptr %slot894, align 8
  %v5259 = load i64, ptr %slot8, align 8
  %p5260 = inttoptr i64 %v5259 to ptr
  store i32 %v5258, ptr %p5260, align 4, !alias.scope !3, !noalias !4
  %v5261 = load i64, ptr %slot9, align 8
  %p5262 = inttoptr i64 %v5261 to ptr
  store i32 0, ptr %p5262, align 4, !alias.scope !3, !noalias !4
  %v5263 = load i64, ptr %slot7, align 8
  %p5264 = inttoptr i64 %v5263 to ptr
  store i32 1, ptr %p5264, align 4, !alias.scope !3, !noalias !4
  %v5265 = load i64, ptr %slot892, align 8
  %p5266 = inttoptr i64 %v5265 to ptr
  %ld5267 = load i64, ptr %p5266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5267, ptr %slot895, align 8
  %v5268 = load i64, ptr %slot895, align 8
  %v5269 = load i64, ptr %slot20, align 8
  %p5270 = inttoptr i64 %v5269 to ptr
  store i64 %v5268, ptr %p5270, align 8, !alias.scope !3, !noalias !4
  %v5271 = load i64, ptr %slot21, align 8
  %p5272 = inttoptr i64 %v5271 to ptr
  store i64 0, ptr %p5272, align 8, !alias.scope !3, !noalias !4
  %v5273 = load i64, ptr %slot28, align 8
  store i64 %v5273, ptr %slot896, align 8
  %v5274 = load i64, ptr %slot896, align 8
  %p5275 = inttoptr i64 %v5274 to ptr
  store i64 0, ptr %p5275, align 8, !alias.scope !3, !noalias !4
  %v5276 = load i64, ptr %slot896, align 8
  %p5278 = inttoptr i64 %v5276 to ptr
  %gep5279 = getelementptr i8, ptr %p5278, i64 8
  %op5277 = ptrtoint ptr %gep5279 to i64
  store i64 %op5277, ptr %slot897, align 8
  %v5280 = load i64, ptr %slot897, align 8
  %p5281 = inttoptr i64 %v5280 to ptr
  store i64 0, ptr %p5281, align 8, !alias.scope !3, !noalias !4
  %v5282 = load i64, ptr %slot11, align 8
  %p5283 = inttoptr i64 %v5282 to ptr
  store i32 1, ptr %p5283, align 4, !alias.scope !3, !noalias !4
  %v5284 = load i64, ptr %slot33, align 8
  store i64 %v5284, ptr %slot898, align 8
  %v5285 = load i64, ptr %slot20, align 8
  %p5286 = inttoptr i64 %v5285 to ptr
  %ld5287 = load i64, ptr %p5286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5287, ptr %slot899, align 8
  %v5288 = load i64, ptr %slot899, align 8
  %v5289 = load i64, ptr %slot13, align 8
  %p5290 = inttoptr i64 %v5289 to ptr
  store i64 %v5288, ptr %p5290, align 8, !alias.scope !3, !noalias !4
  %v5291 = load i64, ptr %slot13, align 8
  store i64 %v5291, ptr %slot900, align 8
  %v5292 = load i64, ptr %slot896, align 8
  %p5294 = inttoptr i64 %v5292 to ptr
  %gep5295 = getelementptr i8, ptr %p5294, i64 0
  %op5293 = ptrtoint ptr %gep5295 to i64
  store i64 %op5293, ptr %slot901, align 8
  %v5296 = load i64, ptr %slot20, align 8
  %p5297 = inttoptr i64 %v5296 to ptr
  %ld5298 = load i64, ptr %p5297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5298, ptr %slot902, align 8
  %v5299 = load i64, ptr %slot902, align 8
  %v5300 = load i64, ptr %slot13, align 8
  %p5301 = inttoptr i64 %v5300 to ptr
  store i64 %v5299, ptr %p5301, align 8, !alias.scope !3, !noalias !4
  %v5302 = load i64, ptr %slot13, align 8
  store i64 %v5302, ptr %slot903, align 8
  %v5303 = load i64, ptr %slot7, align 8
  %p5304 = inttoptr i64 %v5303 to ptr
  %ld5305 = load i32, ptr %p5304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5305, ptr %slot904, align 8
  %v5306 = load i64, ptr %slot8, align 8
  %p5307 = inttoptr i64 %v5306 to ptr
  %ld5308 = load i32, ptr %p5307, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5308, ptr %slot905, align 8
  %v5309 = load i32, ptr %slot905, align 8
  %op5310 = and i32 %v5309, 24
  store i32 %op5310, ptr %slot905, align 8
  %v5311 = load i32, ptr %slot905, align 8
  %cmp5312 = icmp eq i32 %v5311, 0
  %cv5313 = zext i1 %cmp5312 to i32
  store i32 %cv5313, ptr %slot906, align 8
  %v5314 = load i32, ptr %slot904, align 8
  %v5315 = load i32, ptr %slot906, align 8
  %op5316 = and i32 %v5314, %v5315
  store i32 %op5316, ptr %slot907, align 8
  %v5317 = load i32, ptr %slot907, align 8
  %cv5318 = zext i32 %v5317 to i64
  %cond5319 = icmp ne i64 %cv5318, 0
  br i1 %cond5319, label %bb_rctake1595, label %bb_rccopy1595
bb_rctake1595:
  %v5320 = load i64, ptr %slot14, align 8
  store i64 %v5320, ptr %slot908, align 8
  %v5321 = load i64, ptr %slot33, align 8
  store i64 %v5321, ptr %slot909, align 8
  %v5322 = load i64, ptr %slot903, align 8
  %v5323 = load i64, ptr %slot908, align 8
  %op5324 = sub i64 %v5322, %v5323
  store i64 %op5324, ptr %slot910, align 8
  %v5325 = load i64, ptr %slot908, align 8
  %v5326 = load i64, ptr %slot903, align 8
  %op5327 = sub i64 %v5325, %v5326
  store i64 %op5327, ptr %slot911, align 8
  %v5328 = load i64, ptr %slot910, align 8
  %cmp5329 = icmp ult i64 %v5328, 8
  %cv5330 = zext i1 %cmp5329 to i32
  store i32 %cv5330, ptr %slot912, align 8
  %v5331 = load i64, ptr %slot911, align 8
  %cmp5332 = icmp ult i64 %v5331, 8
  %cv5333 = zext i1 %cmp5332 to i32
  store i32 %cv5333, ptr %slot913, align 8
  %v5334 = load i32, ptr %slot912, align 8
  %v5335 = load i32, ptr %slot913, align 8
  %op5336 = or i32 %v5334, %v5335
  store i32 %op5336, ptr %slot914, align 8
  %v5337 = load i32, ptr %slot914, align 8
  %cv5338 = zext i32 %v5337 to i64
  %cond5339 = icmp ne i64 %cv5338, 0
  br i1 %cond5339, label %bb_rcmoveslow1604, label %bb_rcmovecheck1604
bb_rcmovecheck1604:
  %v5340 = load i64, ptr %slot903, align 8
  %p5342 = inttoptr i64 %v5340 to ptr
  %gep5343 = getelementptr i8, ptr %p5342, i64 0
  %op5341 = ptrtoint ptr %gep5343 to i64
  store i64 %op5341, ptr %slot915, align 8
  %v5344 = load i64, ptr %slot915, align 8
  %p5345 = inttoptr i64 %v5344 to ptr
  %ld5346 = load i64, ptr %p5345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5346, ptr %slot916, align 8
  %v5347 = load i64, ptr %slot916, align 8
  %cmp5348 = icmp ne i64 %v5347, 0
  %cv5349 = zext i1 %cmp5348 to i32
  store i32 %cv5349, ptr %slot917, align 8
  %v5350 = load i32, ptr %slot917, align 8
  %cv5351 = zext i32 %v5350 to i64
  %cond5352 = icmp ne i64 %cv5351, 0
  br i1 %cond5352, label %bb_rcmoveheader1612, label %bb_rcmovenext1612
bb_rcmoveheader1612:
  %v5353 = load i64, ptr %slot916, align 8
  %op5354 = sub i64 %v5353, 16
  store i64 %op5354, ptr %slot918, align 8
  %v5355 = load i64, ptr %slot916, align 8
  %p5356 = inttoptr i64 %v5355 to ptr
  %rgep5357 = getelementptr i8, ptr %p5356, i64 -16
  %ld5358 = load i64, ptr %rgep5357, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5358, ptr %slot919, align 8
  %v5359 = load i64, ptr %slot919, align 8
  %op5360 = and i64 %v5359, 5764607523034234881
  store i64 %op5360, ptr %slot920, align 8
  %v5361 = load i64, ptr %slot920, align 8
  %cmp5362 = icmp ne i64 %v5361, 0
  %cv5363 = zext i1 %cmp5362 to i32
  store i32 %cv5363, ptr %slot921, align 8
  %v5364 = load i32, ptr %slot921, align 8
  %cv5365 = zext i32 %v5364 to i64
  %cond5366 = icmp ne i64 %cv5365, 0
  br i1 %cond5366, label %bb_rcmoveslow1604, label %bb_rcmovenext1612
bb_rcmovenext1612:
  %v5367 = load i64, ptr %slot903, align 8
  %v5368 = load i64, ptr %slot908, align 8
  %p5369 = inttoptr i64 %v5367 to ptr
  %p5370 = inttoptr i64 %v5368 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5370, ptr %p5369, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5371 = load i64, ptr %slot903, align 8
  %p5372 = inttoptr i64 %v5371 to ptr
  store i64 0, ptr %p5372, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1604
bb_rcmoveslow1604:
  %v5373 = load i64, ptr %slot32, align 8
  %v5374 = load i64, ptr %slot908, align 8
  %v5375 = load i64, ptr %slot903, align 8
  %v5376 = load i64, ptr %slot909, align 8
  %cv5377 = trunc i64 %v5376 to i32
  %call5378 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v5373, i64 %v5374, i64 %v5375, i32 %cv5377) nomerge, !dbg !162
  store i32 %call5378, ptr %slot922, align 8
  %v5379 = load i32, ptr %slot922, align 8
  %cv5380 = zext i32 %v5379 to i64
  %cond5381 = icmp ne i64 %cv5380, 0
  br i1 %cond5381, label %bb_rcsuccess1619, label %bb_rcfailure1619
bb_rcfailure1619:
  %v5382 = load i64, ptr %slot32, align 8
  %p5383 = inttoptr i64 %v5382 to ptr
  %call5384 = call i32 @myl_rc_take_failure(ptr %p5383) nomerge, !dbg !162
  store i32 %call5384, ptr %slot923, align 8
  %v5385 = load i64, ptr %slot1, align 8
  %p5386 = inttoptr i64 %v5385 to ptr
  %v5387 = load i32, ptr %slot923, align 8
  %call5388 = call i32 @myl_qbe_rc_status(ptr %p5386, i32 %v5387) nomerge, !dbg !162
  store i32 %call5388, ptr %slot924, align 8
  br label %bb_failure
bb_rcsuccess1619:
  br label %bb_rcmoved1604
bb_rcmoved1604:
  %v5389 = load i64, ptr %slot7, align 8
  %p5390 = inttoptr i64 %v5389 to ptr
  store i32 0, ptr %p5390, align 4, !alias.scope !3, !noalias !4
  %v5391 = load i64, ptr %slot10, align 8
  %p5392 = inttoptr i64 %v5391 to ptr
  store i32 2, ptr %p5392, align 4, !alias.scope !3, !noalias !4
  %v5393 = load i64, ptr %slot9, align 8
  %p5394 = inttoptr i64 %v5393 to ptr
  store i32 1, ptr %p5394, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1595
bb_rccopy1595:
  %v5395 = load i64, ptr %slot14, align 8
  store i64 %v5395, ptr %slot925, align 8
  %v5396 = load i64, ptr %slot33, align 8
  store i64 %v5396, ptr %slot926, align 8
  %v5397 = load i64, ptr %slot903, align 8
  %p5398 = inttoptr i64 %v5397 to ptr
  %ld5399 = load i64, ptr %p5398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5399, ptr %slot927, align 8
  %v5400 = load i64, ptr %slot927, align 8
  %cmp5401 = icmp ne i64 %v5400, 0
  %cv5402 = zext i1 %cmp5401 to i32
  store i32 %cv5402, ptr %slot928, align 8
  %v5403 = load i32, ptr %slot928, align 8
  %cv5404 = zext i32 %v5403 to i64
  %cond5405 = icmp ne i64 %cv5404, 0
  br i1 %cond5405, label %bb_rcgnn1628, label %bb_rcgplain1628
bb_rcgnn1628:
  %v5406 = load i64, ptr %slot927, align 8
  %op5407 = sub i64 %v5406, 16
  store i64 %op5407, ptr %slot929, align 8
  %v5408 = load i64, ptr %slot927, align 8
  %p5409 = inttoptr i64 %v5408 to ptr
  %rgep5410 = getelementptr i8, ptr %p5409, i64 -16
  %ld5411 = load i64, ptr %rgep5410, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5411, ptr %slot930, align 8
  %v5412 = load i64, ptr %slot930, align 8
  %op5413 = and i64 %v5412, 4611686018427387906
  store i64 %op5413, ptr %slot931, align 8
  %v5414 = load i64, ptr %slot931, align 8
  %cmp5415 = icmp ne i64 %v5414, 0
  %cv5416 = zext i1 %cmp5415 to i32
  store i32 %cv5416, ptr %slot932, align 8
  %v5417 = load i32, ptr %slot932, align 8
  %cv5418 = zext i32 %v5417 to i64
  %cond5419 = icmp ne i64 %cv5418, 0
  br i1 %cond5419, label %bb_rcgspecial1628, label %bb_rcginc1628
bb_rcginc1628:
  %v5420 = load i64, ptr %slot927, align 8
  %op5421 = sub i64 %v5420, 32
  store i64 %op5421, ptr %slot933, align 8
  %v5422 = load i64, ptr %slot927, align 8
  %p5423 = inttoptr i64 %v5422 to ptr
  %rgep5424 = getelementptr i8, ptr %p5423, i64 -32
  %ld5425 = load i64, ptr %rgep5424, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5425, ptr %slot934, align 8
  %v5426 = load i64, ptr %slot934, align 8
  %op5427 = add i64 %v5426, 1
  store i64 %op5427, ptr %slot935, align 8
  %v5428 = load i64, ptr %slot935, align 8
  %cmp5429 = icmp eq i64 %v5428, 0
  %cv5430 = zext i1 %cmp5429 to i32
  store i32 %cv5430, ptr %slot936, align 8
  %v5431 = load i32, ptr %slot936, align 8
  %cv5432 = zext i32 %v5431 to i64
  %cond5433 = icmp ne i64 %cv5432, 0
  br i1 %cond5433, label %bb_rcglimit1628, label %bb_rcgcapacity1628
bb_rcglimit1628:
  %v5434 = load i64, ptr %slot1, align 8
  %p5435 = inttoptr i64 %v5434 to ptr
  %call5436 = call i32 @myl_qbe_rc_status(ptr %p5435, i32 2) nomerge, !dbg !162
  store i32 %call5436, ptr %slot937, align 8
  br label %bb_failure
bb_rcgcapacity1628:
  %v5437 = load i64, ptr %slot935, align 8
  %v5438 = load i64, ptr %slot927, align 8
  %p5439 = inttoptr i64 %v5438 to ptr
  %rgep5440 = getelementptr i8, ptr %p5439, i64 -32
  store i64 %v5437, ptr %rgep5440, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1628
bb_rcgspecial1628:
  %v5441 = load i64, ptr %slot930, align 8
  %op5442 = and i64 %v5441, 4611686018427387904
  store i64 %op5442, ptr %slot938, align 8
  %v5443 = load i64, ptr %slot938, align 8
  %cmp5444 = icmp ne i64 %v5443, 0
  %cv5445 = zext i1 %cmp5444 to i32
  store i32 %cv5445, ptr %slot939, align 8
  %v5446 = load i32, ptr %slot939, align 8
  %cv5447 = zext i32 %v5446 to i64
  %cond5448 = icmp ne i64 %cv5447, 0
  br i1 %cond5448, label %bb_rcgslow1628, label %bb_rcgplain1628
bb_rcgslow1628:
  %v5449 = load i64, ptr %slot32, align 8
  %v5450 = load i64, ptr %slot925, align 8
  %v5451 = load i64, ptr %slot903, align 8
  %v5452 = load i64, ptr %slot926, align 8
  %cv5453 = trunc i64 %v5452 to i32
  %call5454 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v5449, i64 %v5450, i64 %v5451, i32 %cv5453) nomerge, !dbg !162
  store i32 %call5454, ptr %slot940, align 8
  %v5455 = load i32, ptr %slot940, align 8
  %cv5456 = zext i32 %v5455 to i64
  %cond5457 = icmp ne i64 %cv5456, 0
  br i1 %cond5457, label %bb_rcsuccess1642, label %bb_rcfailure1642
bb_rcfailure1642:
  %v5458 = load i64, ptr %slot32, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  %call5460 = call i32 @myl_rc_take_failure(ptr %p5459) nomerge, !dbg !162
  store i32 %call5460, ptr %slot941, align 8
  %v5461 = load i64, ptr %slot1, align 8
  %p5462 = inttoptr i64 %v5461 to ptr
  %v5463 = load i32, ptr %slot941, align 8
  %call5464 = call i32 @myl_qbe_rc_status(ptr %p5462, i32 %v5463) nomerge, !dbg !162
  store i32 %call5464, ptr %slot942, align 8
  br label %bb_failure
bb_rcsuccess1642:
  br label %bb_rcgdone1628
bb_rcgplain1628:
  %v5465 = load i64, ptr %slot927, align 8
  %v5466 = load i64, ptr %slot925, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  store i64 %v5465, ptr %p5467, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1628
bb_rcgdone1628:
  %v5468 = load i64, ptr %slot10, align 8
  %p5469 = inttoptr i64 %v5468 to ptr
  store i32 2, ptr %p5469, align 4, !alias.scope !3, !noalias !4
  %v5470 = load i64, ptr %slot9, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  store i32 1, ptr %p5471, align 4, !alias.scope !3, !noalias !4
  %v5472 = load i64, ptr %slot7, align 8
  %p5473 = inttoptr i64 %v5472 to ptr
  %ld5474 = load i32, ptr %p5473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5474, ptr %slot943, align 8
  %v5475 = load i32, ptr %slot943, align 8
  %cv5476 = zext i32 %v5475 to i64
  %cond5477 = icmp ne i64 %cv5476, 0
  br i1 %cond5477, label %bb_rcslotdrop1649, label %bb_rcslotdone1649
bb_rcslotdrop1649:
  %v5478 = load i64, ptr %slot7, align 8
  %p5479 = inttoptr i64 %v5478 to ptr
  store i32 0, ptr %p5479, align 4, !alias.scope !3, !noalias !4
  %v5480 = load i64, ptr %slot12, align 8
  store i64 %v5480, ptr %slot944, align 8
  %v5481 = load i64, ptr %slot8, align 8
  %p5482 = inttoptr i64 %v5481 to ptr
  %ld5483 = load i32, ptr %p5482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5483, ptr %slot945, align 8
  %v5484 = load i32, ptr %slot945, align 8
  %op5485 = and i32 %v5484, 28
  store i32 %op5485, ptr %slot946, align 8
  %v5486 = load i32, ptr %slot946, align 8
  %cv5487 = zext i32 %v5486 to i64
  %cond5488 = icmp ne i64 %cv5487, 0
  br i1 %cond5488, label %bb_rcslotrole1649, label %bb_rcslotowner1649
bb_rcslotrole1649:
  %v5489 = load i64, ptr %slot32, align 8
  store i64 %v5489, ptr %slot947, align 8
  %v5490 = load i64, ptr %slot944, align 8
  %p5491 = inttoptr i64 %v5490 to ptr
  %ld5492 = load i64, ptr %p5491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5492, ptr %slot948, align 8
  %v5493 = load i64, ptr %slot948, align 8
  %cmp5494 = icmp ne i64 %v5493, 0
  %cv5495 = zext i1 %cmp5494 to i32
  store i32 %cv5495, ptr %slot949, align 8
  %v5496 = load i32, ptr %slot949, align 8
  %cv5497 = zext i32 %v5496 to i64
  %cond5498 = icmp ne i64 %cv5497, 0
  br i1 %cond5498, label %bb_rcgnn1665, label %bb_rcgdone1665
bb_rcgnn1665:
  %v5499 = load i64, ptr %slot948, align 8
  %op5500 = sub i64 %v5499, 16
  store i64 %op5500, ptr %slot950, align 8
  %v5501 = load i64, ptr %slot948, align 8
  %p5502 = inttoptr i64 %v5501 to ptr
  %rgep5503 = getelementptr i8, ptr %p5502, i64 -16
  %ld5504 = load i64, ptr %rgep5503, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5504, ptr %slot951, align 8
  %v5505 = load i64, ptr %slot951, align 8
  %op5506 = and i64 %v5505, 4611686018427387906
  store i64 %op5506, ptr %slot952, align 8
  %v5507 = load i64, ptr %slot952, align 8
  %cmp5508 = icmp ne i64 %v5507, 0
  %cv5509 = zext i1 %cmp5508 to i32
  store i32 %cv5509, ptr %slot953, align 8
  %v5510 = load i32, ptr %slot953, align 8
  %cv5511 = zext i32 %v5510 to i64
  %cond5512 = icmp ne i64 %cv5511, 0
  br i1 %cond5512, label %bb_rcgclear1665, label %bb_rcgcounted1665
bb_rcgcounted1665:
  %v5513 = load i64, ptr %slot948, align 8
  %op5514 = sub i64 %v5513, 24
  store i64 %op5514, ptr %slot954, align 8
  %v5515 = load i64, ptr %slot948, align 8
  %p5516 = inttoptr i64 %v5515 to ptr
  %rgep5517 = getelementptr i8, ptr %p5516, i64 -24
  %ld5518 = load i64, ptr %rgep5517, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5518, ptr %slot955, align 8
  %v5519 = load i64, ptr %slot955, align 8
  %op5520 = sub i64 %v5519, 1
  store i64 %op5520, ptr %slot956, align 8
  %v5521 = load i64, ptr %slot956, align 8
  %cmp5522 = icmp eq i64 %v5521, 0
  %cv5523 = zext i1 %cmp5522 to i32
  store i32 %cv5523, ptr %slot957, align 8
  %v5524 = load i32, ptr %slot957, align 8
  %cv5525 = zext i32 %v5524 to i64
  %cond5526 = icmp ne i64 %cv5525, 0
  br i1 %cond5526, label %bb_rcglast1665, label %bb_rcgdec1665
bb_rcglast1665:
  %v5527 = load i64, ptr %slot948, align 8
  %op5528 = sub i64 %v5527, 32
  store i64 %op5528, ptr %slot958, align 8
  %v5529 = load i64, ptr %slot948, align 8
  %p5530 = inttoptr i64 %v5529 to ptr
  %rgep5531 = getelementptr i8, ptr %p5530, i64 -32
  %ld5532 = load i64, ptr %rgep5531, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5532, ptr %slot959, align 8
  %v5533 = load i64, ptr %slot959, align 8
  %cmp5534 = icmp ne i64 %v5533, 0
  %cv5535 = zext i1 %cmp5534 to i32
  store i32 %cv5535, ptr %slot960, align 8
  %v5536 = load i32, ptr %slot960, align 8
  %cv5537 = zext i32 %v5536 to i64
  %cond5538 = icmp ne i64 %cv5537, 0
  br i1 %cond5538, label %bb_rcgdec1665, label %bb_rcgslow1665
bb_rcgslow1665:
  %v5539 = load i64, ptr %slot947, align 8
  %v5540 = load i64, ptr %slot944, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5539, i64 %v5540) nomerge, !dbg !162
  br label %bb_rcgdone1665
bb_rcgdec1665:
  %v5541 = load i64, ptr %slot956, align 8
  %v5542 = load i64, ptr %slot948, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  %rgep5544 = getelementptr i8, ptr %p5543, i64 -24
  store i64 %v5541, ptr %rgep5544, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1665
bb_rcgclear1665:
  %v5545 = load i64, ptr %slot944, align 8
  %p5546 = inttoptr i64 %v5545 to ptr
  store i64 0, ptr %p5546, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1665
bb_rcgdone1665:
  br label %bb_rcslotdone1649
bb_rcslotowner1649:
  %v5547 = load i64, ptr %slot32, align 8
  store i64 %v5547, ptr %slot961, align 8
  %v5548 = load i64, ptr %slot944, align 8
  %p5549 = inttoptr i64 %v5548 to ptr
  %ld5550 = load i64, ptr %p5549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5550, ptr %slot962, align 8
  %v5551 = load i64, ptr %slot962, align 8
  %cmp5552 = icmp ne i64 %v5551, 0
  %cv5553 = zext i1 %cmp5552 to i32
  store i32 %cv5553, ptr %slot963, align 8
  %v5554 = load i32, ptr %slot963, align 8
  %cv5555 = zext i32 %v5554 to i64
  %cond5556 = icmp ne i64 %cv5555, 0
  br i1 %cond5556, label %bb_rcgnn1680, label %bb_rcgdone1680
bb_rcgnn1680:
  %v5557 = load i64, ptr %slot962, align 8
  %op5558 = sub i64 %v5557, 16
  store i64 %op5558, ptr %slot964, align 8
  %v5559 = load i64, ptr %slot962, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  %rgep5561 = getelementptr i8, ptr %p5560, i64 -16
  %ld5562 = load i64, ptr %rgep5561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5562, ptr %slot965, align 8
  %v5563 = load i64, ptr %slot965, align 8
  %op5564 = and i64 %v5563, 4611686018427387906
  store i64 %op5564, ptr %slot966, align 8
  %v5565 = load i64, ptr %slot966, align 8
  %cmp5566 = icmp ne i64 %v5565, 0
  %cv5567 = zext i1 %cmp5566 to i32
  store i32 %cv5567, ptr %slot967, align 8
  %v5568 = load i32, ptr %slot967, align 8
  %cv5569 = zext i32 %v5568 to i64
  %cond5570 = icmp ne i64 %cv5569, 0
  br i1 %cond5570, label %bb_rcgclear1680, label %bb_rcgcounted1680
bb_rcgcounted1680:
  %v5571 = load i64, ptr %slot962, align 8
  %op5572 = sub i64 %v5571, 32
  store i64 %op5572, ptr %slot968, align 8
  %v5573 = load i64, ptr %slot962, align 8
  %p5574 = inttoptr i64 %v5573 to ptr
  %rgep5575 = getelementptr i8, ptr %p5574, i64 -32
  %ld5576 = load i64, ptr %rgep5575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5576, ptr %slot969, align 8
  %v5577 = load i64, ptr %slot969, align 8
  %op5578 = sub i64 %v5577, 1
  store i64 %op5578, ptr %slot970, align 8
  %v5579 = load i64, ptr %slot970, align 8
  %cmp5580 = icmp eq i64 %v5579, 0
  %cv5581 = zext i1 %cmp5580 to i32
  store i32 %cv5581, ptr %slot971, align 8
  %v5582 = load i32, ptr %slot971, align 8
  %cv5583 = zext i32 %v5582 to i64
  %cond5584 = icmp ne i64 %cv5583, 0
  br i1 %cond5584, label %bb_rcglast1680, label %bb_rcgdec1680
bb_rcglast1680:
  %v5585 = load i64, ptr %slot962, align 8
  %op5586 = sub i64 %v5585, 24
  store i64 %op5586, ptr %slot972, align 8
  %v5587 = load i64, ptr %slot962, align 8
  %p5588 = inttoptr i64 %v5587 to ptr
  %rgep5589 = getelementptr i8, ptr %p5588, i64 -24
  %ld5590 = load i64, ptr %rgep5589, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5590, ptr %slot973, align 8
  %v5591 = load i64, ptr %slot973, align 8
  %cmp5592 = icmp ne i64 %v5591, 0
  %cv5593 = zext i1 %cmp5592 to i32
  store i32 %cv5593, ptr %slot974, align 8
  %v5594 = load i32, ptr %slot974, align 8
  %cv5595 = zext i32 %v5594 to i64
  %cond5596 = icmp ne i64 %cv5595, 0
  br i1 %cond5596, label %bb_rcgdec1680, label %bb_rcgslow1680
bb_rcgslow1680:
  %v5597 = load i64, ptr %slot961, align 8
  %v5598 = load i64, ptr %slot944, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5597, i64 %v5598) nomerge, !dbg !162
  br label %bb_rcgdone1680
bb_rcgdec1680:
  %v5599 = load i64, ptr %slot970, align 8
  %v5600 = load i64, ptr %slot962, align 8
  %p5601 = inttoptr i64 %v5600 to ptr
  %rgep5602 = getelementptr i8, ptr %p5601, i64 -32
  store i64 %v5599, ptr %rgep5602, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1680
bb_rcgclear1680:
  %v5603 = load i64, ptr %slot944, align 8
  %p5604 = inttoptr i64 %v5603 to ptr
  store i64 0, ptr %p5604, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1680
bb_rcgdone1680:
  br label %bb_rcslotdone1649
bb_rcslotdone1649:
  br label %bb_rcprepared1595
bb_rcprepared1595:
  %v5605 = load i64, ptr %slot14, align 8
  store i64 %v5605, ptr %slot975, align 8
  %v5606 = load i64, ptr %slot975, align 8
  %v5607 = load i64, ptr %slot901, align 8
  %p5608 = inttoptr i64 %v5606 to ptr
  %p5609 = inttoptr i64 %v5607 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5609, ptr %p5608, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5610 = load i64, ptr %slot9, align 8
  %p5611 = inttoptr i64 %v5610 to ptr
  store i32 0, ptr %p5611, align 4, !alias.scope !3, !noalias !4
  %v5612 = load i64, ptr %slot21, align 8
  store i64 %v5612, ptr %slot976, align 8
  %v5613 = load i64, ptr %slot896, align 8
  %p5615 = inttoptr i64 %v5613 to ptr
  %gep5616 = getelementptr i8, ptr %p5615, i64 8
  %op5614 = ptrtoint ptr %gep5616 to i64
  store i64 %op5614, ptr %slot977, align 8
  %v5617 = load i64, ptr %slot976, align 8
  %p5618 = inttoptr i64 %v5617 to ptr
  %ld5619 = load i32, ptr %p5618, align 4, !alias.scope !3, !noalias !4
  %ext5620 = zext i32 %ld5619 to i64
  store i64 %ext5620, ptr %slot978, align 8
  %v5621 = load i64, ptr %slot978, align 8
  %cv5622 = trunc i64 %v5621 to i32
  %v5623 = load i64, ptr %slot977, align 8
  %p5624 = inttoptr i64 %v5623 to ptr
  store i32 %cv5622, ptr %p5624, align 4, !alias.scope !3, !noalias !4
  %v5625 = load i64, ptr %slot896, align 8
  %v5626 = load i64, ptr %slot20, align 8
  %p5627 = inttoptr i64 %v5626 to ptr
  store i64 %v5625, ptr %p5627, align 8, !alias.scope !3, !noalias !4
  %v5628 = load i64, ptr %slot20, align 8
  %p5629 = inttoptr i64 %v5628 to ptr
  %ld5630 = load i64, ptr %p5629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5630, ptr %slot979, align 8
  %v5631 = load i64, ptr %slot12, align 8
  store i64 %v5631, ptr %slot980, align 8
  %v5632 = load i64, ptr %slot979, align 8
  %v5633 = load i64, ptr %slot980, align 8
  %p5634 = inttoptr i64 %v5632 to ptr
  %p5635 = inttoptr i64 %v5633 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5635, ptr %p5634, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5636 = load i64, ptr %slot8, align 8
  %p5637 = inttoptr i64 %v5636 to ptr
  store i32 2, ptr %p5637, align 4, !alias.scope !3, !noalias !4
  %v5638 = load i64, ptr %slot7, align 8
  %p5639 = inttoptr i64 %v5638 to ptr
  store i32 1, ptr %p5639, align 4, !alias.scope !3, !noalias !4
  %v5640 = load i64, ptr %slot980, align 8
  %v5641 = load i64, ptr %slot20, align 8
  %p5642 = inttoptr i64 %v5641 to ptr
  store i64 %v5640, ptr %p5642, align 8, !alias.scope !3, !noalias !4
  %v5643 = load i64, ptr %slot20, align 8
  %p5644 = inttoptr i64 %v5643 to ptr
  %ld5645 = load i64, ptr %p5644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5645, ptr %slot981, align 8
  %v5646 = load i64, ptr %slot20, align 8
  %p5647 = inttoptr i64 %v5646 to ptr
  %ld5648 = load i64, ptr %p5647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5648, ptr %slot982, align 8
  %v5649 = load i64, ptr %slot14, align 8
  store i64 %v5649, ptr %slot983, align 8
  %v5650 = load i64, ptr %slot33, align 8
  store i64 %v5650, ptr %slot984, align 8
  %v5651 = load i64, ptr %slot982, align 8
  %op5652 = add i64 %v5651, 0
  store i64 %op5652, ptr %slot985, align 8
  %v5653 = load i64, ptr %slot985, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  %ld5655 = load i64, ptr %p5654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5655, ptr %slot986, align 8
  %v5656 = load i64, ptr %slot986, align 8
  %cmp5657 = icmp ne i64 %v5656, 0
  %cv5658 = zext i1 %cmp5657 to i32
  store i32 %cv5658, ptr %slot987, align 8
  %v5659 = load i32, ptr %slot987, align 8
  %cv5660 = zext i32 %v5659 to i64
  %cond5661 = icmp ne i64 %cv5660, 0
  br i1 %cond5661, label %bb_rcmoveheader1700, label %bb_rcmovenext1700
bb_rcmoveheader1700:
  %v5662 = load i64, ptr %slot986, align 8
  %op5663 = sub i64 %v5662, 16
  store i64 %op5663, ptr %slot988, align 8
  %v5664 = load i64, ptr %slot986, align 8
  %p5665 = inttoptr i64 %v5664 to ptr
  %rgep5666 = getelementptr i8, ptr %p5665, i64 -16
  %ld5667 = load i64, ptr %rgep5666, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5667, ptr %slot989, align 8
  %v5668 = load i64, ptr %slot989, align 8
  %op5669 = and i64 %v5668, 5764607523034234881
  store i64 %op5669, ptr %slot990, align 8
  %v5670 = load i64, ptr %slot990, align 8
  %cmp5671 = icmp ne i64 %v5670, 0
  %cv5672 = zext i1 %cmp5671 to i32
  store i32 %cv5672, ptr %slot991, align 8
  %v5673 = load i32, ptr %slot991, align 8
  %cv5674 = zext i32 %v5673 to i64
  %cond5675 = icmp ne i64 %cv5674, 0
  br i1 %cond5675, label %bb_rcmoveslow1697, label %bb_rcmovenext1700
bb_rcmovenext1700:
  %v5676 = load i64, ptr %slot982, align 8
  %v5677 = load i64, ptr %slot983, align 8
  %p5678 = inttoptr i64 %v5676 to ptr
  %p5679 = inttoptr i64 %v5677 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5679, ptr %p5678, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5680 = load i64, ptr %slot982, align 8
  %p5681 = inttoptr i64 %v5680 to ptr
  store i64 0, ptr %p5681, align 8, !alias.scope !3, !noalias !4
  %v5682 = load i64, ptr %slot982, align 8
  %op5683 = add i64 %v5682, 8
  store i64 %op5683, ptr %slot992, align 8
  %v5684 = load i64, ptr %slot992, align 8
  %p5685 = inttoptr i64 %v5684 to ptr
  store i64 0, ptr %p5685, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1697
bb_rcmoveslow1697:
  %v5686 = load i64, ptr %slot32, align 8
  %v5687 = load i64, ptr %slot983, align 8
  %v5688 = load i64, ptr %slot982, align 8
  %v5689 = load i64, ptr %slot984, align 8
  %cv5690 = trunc i64 %v5689 to i32
  %call5691 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v5686, i64 %v5687, i64 %v5688, i32 %cv5690) nomerge, !dbg !164
  store i32 %call5691, ptr %slot993, align 8
  %v5692 = load i32, ptr %slot993, align 8
  %cv5693 = zext i32 %v5692 to i64
  %cond5694 = icmp ne i64 %cv5693, 0
  br i1 %cond5694, label %bb_rcsuccess1708, label %bb_rcfailure1708
bb_rcfailure1708:
  %v5695 = load i64, ptr %slot32, align 8
  %p5696 = inttoptr i64 %v5695 to ptr
  %call5697 = call i32 @myl_rc_take_failure(ptr %p5696) nomerge, !dbg !164
  store i32 %call5697, ptr %slot994, align 8
  %v5698 = load i64, ptr %slot1, align 8
  %p5699 = inttoptr i64 %v5698 to ptr
  %v5700 = load i32, ptr %slot994, align 8
  %call5701 = call i32 @myl_qbe_rc_status(ptr %p5699, i32 %v5700) nomerge, !dbg !164
  store i32 %call5701, ptr %slot995, align 8
  br label %bb_failure
bb_rcsuccess1708:
  br label %bb_rcmoved1697
bb_rcmoved1697:
  %v5702 = load i64, ptr %slot7, align 8
  %p5703 = inttoptr i64 %v5702 to ptr
  store i32 0, ptr %p5703, align 4, !alias.scope !3, !noalias !4
  %v5704 = load i64, ptr %slot10, align 8
  %p5705 = inttoptr i64 %v5704 to ptr
  store i32 2, ptr %p5705, align 4, !alias.scope !3, !noalias !4
  %v5706 = load i64, ptr %slot9, align 8
  %p5707 = inttoptr i64 %v5706 to ptr
  store i32 1, ptr %p5707, align 4, !alias.scope !3, !noalias !4
  %v5708 = load i64, ptr %slot14, align 8
  store i64 %v5708, ptr %slot996, align 8
  %v5709 = load i64, ptr %slot9, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  store i32 0, ptr %p5710, align 4, !alias.scope !3, !noalias !4
  %v5711 = load i64, ptr %slot7, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  %ld5713 = load i32, ptr %p5712, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5713, ptr %slot997, align 8
  %v5714 = load i32, ptr %slot997, align 8
  %cv5715 = zext i32 %v5714 to i64
  %cond5716 = icmp ne i64 %cv5715, 0
  br i1 %cond5716, label %bb_rcslotdrop1718, label %bb_rcslotdone1718
bb_rcslotdrop1718:
  %v5717 = load i64, ptr %slot7, align 8
  %p5718 = inttoptr i64 %v5717 to ptr
  store i32 0, ptr %p5718, align 4, !alias.scope !3, !noalias !4
  %v5719 = load i64, ptr %slot12, align 8
  store i64 %v5719, ptr %slot998, align 8
  %v5720 = load i64, ptr %slot8, align 8
  %p5721 = inttoptr i64 %v5720 to ptr
  %ld5722 = load i32, ptr %p5721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5722, ptr %slot999, align 8
  %v5723 = load i32, ptr %slot999, align 8
  %op5724 = and i32 %v5723, 28
  store i32 %op5724, ptr %slot1000, align 8
  %v5725 = load i32, ptr %slot1000, align 8
  %cv5726 = zext i32 %v5725 to i64
  %cond5727 = icmp ne i64 %cv5726, 0
  br i1 %cond5727, label %bb_rcslotrole1718, label %bb_rcslotowner1718
bb_rcslotrole1718:
  %v5728 = load i64, ptr %slot32, align 8
  store i64 %v5728, ptr %slot1001, align 8
  %v5729 = load i64, ptr %slot1001, align 8
  %v5730 = load i64, ptr %slot998, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v5729, i64 %v5730) nomerge, !dbg !164
  br label %bb_rcslotdone1718
bb_rcslotowner1718:
  %v5731 = load i64, ptr %slot32, align 8
  store i64 %v5731, ptr %slot1002, align 8
  %v5732 = load i64, ptr %slot1002, align 8
  %v5733 = load i64, ptr %slot998, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v5732, i64 %v5733) nomerge, !dbg !164
  br label %bb_rcslotdone1718
bb_rcslotdone1718:
  %v5734 = load i64, ptr %slot996, align 8
  %p5735 = inttoptr i64 %v5734 to ptr
  %ret5736 = load { i64, i64 }, ptr %p5735, align 8
  ret { i64, i64 } %ret5736
bb_i61:
  %v5737 = load i64, ptr %slot20, align 8
  %p5738 = inttoptr i64 %v5737 to ptr
  store i64 0, ptr %p5738, align 8, !alias.scope !3, !noalias !4
  %v5739 = load i64, ptr %slot20, align 8
  %p5740 = inttoptr i64 %v5739 to ptr
  %ld5741 = load i64, ptr %p5740, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5741, ptr %slot1003, align 8
  %v5742 = load i64, ptr %slot1003, align 8
  %cond5743 = icmp ne i64 %v5742, 0
  br i1 %cond5743, label %bb_success1781, label %bb_failed1781
bb_failed1781:
  %v5744 = load i64, ptr %slot1, align 8
  %p5745 = inttoptr i64 %v5744 to ptr
  call void @myl_qbe_fail_assert(ptr %p5745) nomerge, !dbg !166
  unreachable
bb_success1781:
  %p5746 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld5747 = load i64, ptr %p5746, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5747, ptr %slot1004, align 8
  %v5748 = load i64, ptr %slot1004, align 8
  %v5749 = load i64, ptr %slot20, align 8
  %p5750 = inttoptr i64 %v5749 to ptr
  store i64 %v5748, ptr %p5750, align 8, !alias.scope !3, !noalias !4
  %v5751 = load i64, ptr %slot20, align 8
  %p5752 = inttoptr i64 %v5751 to ptr
  %ld5753 = load i64, ptr %p5752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5753, ptr %slot1005, align 8
  %v5754 = load i64, ptr %slot1005, align 8
  %v5755 = load i64, ptr %slot13, align 8
  %p5756 = inttoptr i64 %v5755 to ptr
  store i64 %v5754, ptr %p5756, align 8, !alias.scope !3, !noalias !4
  %v5757 = load i64, ptr %slot13, align 8
  store i64 %v5757, ptr %slot1006, align 8
  %v5758 = load i64, ptr %slot14, align 8
  store i64 %v5758, ptr %slot1007, align 8
  %v5759 = load i64, ptr %slot1006, align 8
  %v5760 = load i64, ptr %slot1007, align 8
  %p5761 = inttoptr i64 %v5759 to ptr
  %p5762 = inttoptr i64 %v5760 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5762, ptr %p5761, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5763 = load i64, ptr %slot10, align 8
  %p5764 = inttoptr i64 %v5763 to ptr
  store i32 2, ptr %p5764, align 4, !alias.scope !3, !noalias !4
  %v5765 = load i64, ptr %slot9, align 8
  %p5766 = inttoptr i64 %v5765 to ptr
  store i32 1, ptr %p5766, align 4, !alias.scope !3, !noalias !4
  %v5767 = load i64, ptr %slot12, align 8
  store i64 %v5767, ptr %slot1008, align 8
  %v5768 = load i64, ptr %slot14, align 8
  store i64 %v5768, ptr %slot1009, align 8
  %v5769 = load i64, ptr %slot1009, align 8
  %v5770 = load i64, ptr %slot1008, align 8
  %p5771 = inttoptr i64 %v5769 to ptr
  %p5772 = inttoptr i64 %v5770 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5772, ptr %p5771, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5773 = load i64, ptr %slot8, align 8
  %p5774 = inttoptr i64 %v5773 to ptr
  store i32 2, ptr %p5774, align 4, !alias.scope !3, !noalias !4
  %v5775 = load i64, ptr %slot10, align 8
  %p5776 = inttoptr i64 %v5775 to ptr
  %ld5777 = load i32, ptr %p5776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5777, ptr %slot1010, align 8
  %v5778 = load i32, ptr %slot1010, align 8
  %v5779 = load i64, ptr %slot8, align 8
  %p5780 = inttoptr i64 %v5779 to ptr
  store i32 %v5778, ptr %p5780, align 4, !alias.scope !3, !noalias !4
  %v5781 = load i64, ptr %slot9, align 8
  %p5782 = inttoptr i64 %v5781 to ptr
  store i32 0, ptr %p5782, align 4, !alias.scope !3, !noalias !4
  %v5783 = load i64, ptr %slot7, align 8
  %p5784 = inttoptr i64 %v5783 to ptr
  store i32 1, ptr %p5784, align 4, !alias.scope !3, !noalias !4
  %v5785 = load i64, ptr %slot1008, align 8
  %p5786 = inttoptr i64 %v5785 to ptr
  %ld5787 = load i64, ptr %p5786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5787, ptr %slot1011, align 8
  %v5788 = load i64, ptr %slot1011, align 8
  %v5789 = load i64, ptr %slot20, align 8
  %p5790 = inttoptr i64 %v5789 to ptr
  store i64 %v5788, ptr %p5790, align 8, !alias.scope !3, !noalias !4
  %v5791 = load i64, ptr %slot21, align 8
  %p5792 = inttoptr i64 %v5791 to ptr
  store i64 0, ptr %p5792, align 8, !alias.scope !3, !noalias !4
  %v5793 = load i64, ptr %slot29, align 8
  store i64 %v5793, ptr %slot1012, align 8
  %v5794 = load i64, ptr %slot1012, align 8
  %p5795 = inttoptr i64 %v5794 to ptr
  store i64 0, ptr %p5795, align 8, !alias.scope !3, !noalias !4
  %v5796 = load i64, ptr %slot1012, align 8
  %p5798 = inttoptr i64 %v5796 to ptr
  %gep5799 = getelementptr i8, ptr %p5798, i64 8
  %op5797 = ptrtoint ptr %gep5799 to i64
  store i64 %op5797, ptr %slot1013, align 8
  %v5800 = load i64, ptr %slot1013, align 8
  %p5801 = inttoptr i64 %v5800 to ptr
  store i64 0, ptr %p5801, align 8, !alias.scope !3, !noalias !4
  %v5802 = load i64, ptr %slot11, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  store i32 1, ptr %p5803, align 4, !alias.scope !3, !noalias !4
  %v5804 = load i64, ptr %slot33, align 8
  store i64 %v5804, ptr %slot1014, align 8
  %v5805 = load i64, ptr %slot20, align 8
  %p5806 = inttoptr i64 %v5805 to ptr
  %ld5807 = load i64, ptr %p5806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5807, ptr %slot1015, align 8
  %v5808 = load i64, ptr %slot1015, align 8
  %v5809 = load i64, ptr %slot13, align 8
  %p5810 = inttoptr i64 %v5809 to ptr
  store i64 %v5808, ptr %p5810, align 8, !alias.scope !3, !noalias !4
  %v5811 = load i64, ptr %slot13, align 8
  store i64 %v5811, ptr %slot1016, align 8
  %v5812 = load i64, ptr %slot1012, align 8
  %p5814 = inttoptr i64 %v5812 to ptr
  %gep5815 = getelementptr i8, ptr %p5814, i64 0
  %op5813 = ptrtoint ptr %gep5815 to i64
  store i64 %op5813, ptr %slot1017, align 8
  %v5816 = load i64, ptr %slot20, align 8
  %p5817 = inttoptr i64 %v5816 to ptr
  %ld5818 = load i64, ptr %p5817, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5818, ptr %slot1018, align 8
  %v5819 = load i64, ptr %slot1018, align 8
  %v5820 = load i64, ptr %slot13, align 8
  %p5821 = inttoptr i64 %v5820 to ptr
  store i64 %v5819, ptr %p5821, align 8, !alias.scope !3, !noalias !4
  %v5822 = load i64, ptr %slot13, align 8
  store i64 %v5822, ptr %slot1019, align 8
  %v5823 = load i64, ptr %slot7, align 8
  %p5824 = inttoptr i64 %v5823 to ptr
  %ld5825 = load i32, ptr %p5824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5825, ptr %slot1020, align 8
  %v5826 = load i64, ptr %slot8, align 8
  %p5827 = inttoptr i64 %v5826 to ptr
  %ld5828 = load i32, ptr %p5827, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5828, ptr %slot1021, align 8
  %v5829 = load i32, ptr %slot1021, align 8
  %op5830 = and i32 %v5829, 24
  store i32 %op5830, ptr %slot1021, align 8
  %v5831 = load i32, ptr %slot1021, align 8
  %cmp5832 = icmp eq i32 %v5831, 0
  %cv5833 = zext i1 %cmp5832 to i32
  store i32 %cv5833, ptr %slot1022, align 8
  %v5834 = load i32, ptr %slot1020, align 8
  %v5835 = load i32, ptr %slot1022, align 8
  %op5836 = and i32 %v5834, %v5835
  store i32 %op5836, ptr %slot1023, align 8
  %v5837 = load i32, ptr %slot1023, align 8
  %cv5838 = zext i32 %v5837 to i64
  %cond5839 = icmp ne i64 %cv5838, 0
  br i1 %cond5839, label %bb_rctake1808, label %bb_rccopy1808
bb_rctake1808:
  %v5840 = load i64, ptr %slot14, align 8
  store i64 %v5840, ptr %slot1024, align 8
  %v5841 = load i64, ptr %slot33, align 8
  store i64 %v5841, ptr %slot1025, align 8
  %v5842 = load i64, ptr %slot1019, align 8
  %v5843 = load i64, ptr %slot1024, align 8
  %op5844 = sub i64 %v5842, %v5843
  store i64 %op5844, ptr %slot1026, align 8
  %v5845 = load i64, ptr %slot1024, align 8
  %v5846 = load i64, ptr %slot1019, align 8
  %op5847 = sub i64 %v5845, %v5846
  store i64 %op5847, ptr %slot1027, align 8
  %v5848 = load i64, ptr %slot1026, align 8
  %cmp5849 = icmp ult i64 %v5848, 8
  %cv5850 = zext i1 %cmp5849 to i32
  store i32 %cv5850, ptr %slot1028, align 8
  %v5851 = load i64, ptr %slot1027, align 8
  %cmp5852 = icmp ult i64 %v5851, 8
  %cv5853 = zext i1 %cmp5852 to i32
  store i32 %cv5853, ptr %slot1029, align 8
  %v5854 = load i32, ptr %slot1028, align 8
  %v5855 = load i32, ptr %slot1029, align 8
  %op5856 = or i32 %v5854, %v5855
  store i32 %op5856, ptr %slot1030, align 8
  %v5857 = load i32, ptr %slot1030, align 8
  %cv5858 = zext i32 %v5857 to i64
  %cond5859 = icmp ne i64 %cv5858, 0
  br i1 %cond5859, label %bb_rcmoveslow1817, label %bb_rcmovecheck1817
bb_rcmovecheck1817:
  %v5860 = load i64, ptr %slot1019, align 8
  %p5862 = inttoptr i64 %v5860 to ptr
  %gep5863 = getelementptr i8, ptr %p5862, i64 0
  %op5861 = ptrtoint ptr %gep5863 to i64
  store i64 %op5861, ptr %slot1031, align 8
  %v5864 = load i64, ptr %slot1031, align 8
  %p5865 = inttoptr i64 %v5864 to ptr
  %ld5866 = load i64, ptr %p5865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5866, ptr %slot1032, align 8
  %v5867 = load i64, ptr %slot1032, align 8
  %cmp5868 = icmp ne i64 %v5867, 0
  %cv5869 = zext i1 %cmp5868 to i32
  store i32 %cv5869, ptr %slot1033, align 8
  %v5870 = load i32, ptr %slot1033, align 8
  %cv5871 = zext i32 %v5870 to i64
  %cond5872 = icmp ne i64 %cv5871, 0
  br i1 %cond5872, label %bb_rcmoveheader1825, label %bb_rcmovenext1825
bb_rcmoveheader1825:
  %v5873 = load i64, ptr %slot1032, align 8
  %op5874 = sub i64 %v5873, 16
  store i64 %op5874, ptr %slot1034, align 8
  %v5875 = load i64, ptr %slot1032, align 8
  %p5876 = inttoptr i64 %v5875 to ptr
  %rgep5877 = getelementptr i8, ptr %p5876, i64 -16
  %ld5878 = load i64, ptr %rgep5877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5878, ptr %slot1035, align 8
  %v5879 = load i64, ptr %slot1035, align 8
  %op5880 = and i64 %v5879, 5764607523034234881
  store i64 %op5880, ptr %slot1036, align 8
  %v5881 = load i64, ptr %slot1036, align 8
  %cmp5882 = icmp ne i64 %v5881, 0
  %cv5883 = zext i1 %cmp5882 to i32
  store i32 %cv5883, ptr %slot1037, align 8
  %v5884 = load i32, ptr %slot1037, align 8
  %cv5885 = zext i32 %v5884 to i64
  %cond5886 = icmp ne i64 %cv5885, 0
  br i1 %cond5886, label %bb_rcmoveslow1817, label %bb_rcmovenext1825
bb_rcmovenext1825:
  %v5887 = load i64, ptr %slot1019, align 8
  %v5888 = load i64, ptr %slot1024, align 8
  %p5889 = inttoptr i64 %v5887 to ptr
  %p5890 = inttoptr i64 %v5888 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5890, ptr %p5889, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5891 = load i64, ptr %slot1019, align 8
  %p5892 = inttoptr i64 %v5891 to ptr
  store i64 0, ptr %p5892, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1817
bb_rcmoveslow1817:
  %v5893 = load i64, ptr %slot32, align 8
  %v5894 = load i64, ptr %slot1024, align 8
  %v5895 = load i64, ptr %slot1019, align 8
  %v5896 = load i64, ptr %slot1025, align 8
  %cv5897 = trunc i64 %v5896 to i32
  %call5898 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v5893, i64 %v5894, i64 %v5895, i32 %cv5897) nomerge, !dbg !168
  store i32 %call5898, ptr %slot1038, align 8
  %v5899 = load i32, ptr %slot1038, align 8
  %cv5900 = zext i32 %v5899 to i64
  %cond5901 = icmp ne i64 %cv5900, 0
  br i1 %cond5901, label %bb_rcsuccess1832, label %bb_rcfailure1832
bb_rcfailure1832:
  %v5902 = load i64, ptr %slot32, align 8
  %p5903 = inttoptr i64 %v5902 to ptr
  %call5904 = call i32 @myl_rc_take_failure(ptr %p5903) nomerge, !dbg !168
  store i32 %call5904, ptr %slot1039, align 8
  %v5905 = load i64, ptr %slot1, align 8
  %p5906 = inttoptr i64 %v5905 to ptr
  %v5907 = load i32, ptr %slot1039, align 8
  %call5908 = call i32 @myl_qbe_rc_status(ptr %p5906, i32 %v5907) nomerge, !dbg !168
  store i32 %call5908, ptr %slot1040, align 8
  br label %bb_failure
bb_rcsuccess1832:
  br label %bb_rcmoved1817
bb_rcmoved1817:
  %v5909 = load i64, ptr %slot7, align 8
  %p5910 = inttoptr i64 %v5909 to ptr
  store i32 0, ptr %p5910, align 4, !alias.scope !3, !noalias !4
  %v5911 = load i64, ptr %slot10, align 8
  %p5912 = inttoptr i64 %v5911 to ptr
  store i32 2, ptr %p5912, align 4, !alias.scope !3, !noalias !4
  %v5913 = load i64, ptr %slot9, align 8
  %p5914 = inttoptr i64 %v5913 to ptr
  store i32 1, ptr %p5914, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1808
bb_rccopy1808:
  %v5915 = load i64, ptr %slot14, align 8
  store i64 %v5915, ptr %slot1041, align 8
  %v5916 = load i64, ptr %slot33, align 8
  store i64 %v5916, ptr %slot1042, align 8
  %v5917 = load i64, ptr %slot1019, align 8
  %p5918 = inttoptr i64 %v5917 to ptr
  %ld5919 = load i64, ptr %p5918, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5919, ptr %slot1043, align 8
  %v5920 = load i64, ptr %slot1043, align 8
  %cmp5921 = icmp ne i64 %v5920, 0
  %cv5922 = zext i1 %cmp5921 to i32
  store i32 %cv5922, ptr %slot1044, align 8
  %v5923 = load i32, ptr %slot1044, align 8
  %cv5924 = zext i32 %v5923 to i64
  %cond5925 = icmp ne i64 %cv5924, 0
  br i1 %cond5925, label %bb_rcgnn1841, label %bb_rcgplain1841
bb_rcgnn1841:
  %v5926 = load i64, ptr %slot1043, align 8
  %op5927 = sub i64 %v5926, 16
  store i64 %op5927, ptr %slot1045, align 8
  %v5928 = load i64, ptr %slot1043, align 8
  %p5929 = inttoptr i64 %v5928 to ptr
  %rgep5930 = getelementptr i8, ptr %p5929, i64 -16
  %ld5931 = load i64, ptr %rgep5930, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5931, ptr %slot1046, align 8
  %v5932 = load i64, ptr %slot1046, align 8
  %op5933 = and i64 %v5932, 4611686018427387906
  store i64 %op5933, ptr %slot1047, align 8
  %v5934 = load i64, ptr %slot1047, align 8
  %cmp5935 = icmp ne i64 %v5934, 0
  %cv5936 = zext i1 %cmp5935 to i32
  store i32 %cv5936, ptr %slot1048, align 8
  %v5937 = load i32, ptr %slot1048, align 8
  %cv5938 = zext i32 %v5937 to i64
  %cond5939 = icmp ne i64 %cv5938, 0
  br i1 %cond5939, label %bb_rcgspecial1841, label %bb_rcginc1841
bb_rcginc1841:
  %v5940 = load i64, ptr %slot1043, align 8
  %op5941 = sub i64 %v5940, 32
  store i64 %op5941, ptr %slot1049, align 8
  %v5942 = load i64, ptr %slot1043, align 8
  %p5943 = inttoptr i64 %v5942 to ptr
  %rgep5944 = getelementptr i8, ptr %p5943, i64 -32
  %ld5945 = load i64, ptr %rgep5944, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5945, ptr %slot1050, align 8
  %v5946 = load i64, ptr %slot1050, align 8
  %op5947 = add i64 %v5946, 1
  store i64 %op5947, ptr %slot1051, align 8
  %v5948 = load i64, ptr %slot1051, align 8
  %cmp5949 = icmp eq i64 %v5948, 0
  %cv5950 = zext i1 %cmp5949 to i32
  store i32 %cv5950, ptr %slot1052, align 8
  %v5951 = load i32, ptr %slot1052, align 8
  %cv5952 = zext i32 %v5951 to i64
  %cond5953 = icmp ne i64 %cv5952, 0
  br i1 %cond5953, label %bb_rcglimit1841, label %bb_rcgcapacity1841
bb_rcglimit1841:
  %v5954 = load i64, ptr %slot1, align 8
  %p5955 = inttoptr i64 %v5954 to ptr
  %call5956 = call i32 @myl_qbe_rc_status(ptr %p5955, i32 2) nomerge, !dbg !168
  store i32 %call5956, ptr %slot1053, align 8
  br label %bb_failure
bb_rcgcapacity1841:
  %v5957 = load i64, ptr %slot1051, align 8
  %v5958 = load i64, ptr %slot1043, align 8
  %p5959 = inttoptr i64 %v5958 to ptr
  %rgep5960 = getelementptr i8, ptr %p5959, i64 -32
  store i64 %v5957, ptr %rgep5960, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1841
bb_rcgspecial1841:
  %v5961 = load i64, ptr %slot1046, align 8
  %op5962 = and i64 %v5961, 4611686018427387904
  store i64 %op5962, ptr %slot1054, align 8
  %v5963 = load i64, ptr %slot1054, align 8
  %cmp5964 = icmp ne i64 %v5963, 0
  %cv5965 = zext i1 %cmp5964 to i32
  store i32 %cv5965, ptr %slot1055, align 8
  %v5966 = load i32, ptr %slot1055, align 8
  %cv5967 = zext i32 %v5966 to i64
  %cond5968 = icmp ne i64 %cv5967, 0
  br i1 %cond5968, label %bb_rcgslow1841, label %bb_rcgplain1841
bb_rcgslow1841:
  %v5969 = load i64, ptr %slot32, align 8
  %v5970 = load i64, ptr %slot1041, align 8
  %v5971 = load i64, ptr %slot1019, align 8
  %v5972 = load i64, ptr %slot1042, align 8
  %cv5973 = trunc i64 %v5972 to i32
  %call5974 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v5969, i64 %v5970, i64 %v5971, i32 %cv5973) nomerge, !dbg !168
  store i32 %call5974, ptr %slot1056, align 8
  %v5975 = load i32, ptr %slot1056, align 8
  %cv5976 = zext i32 %v5975 to i64
  %cond5977 = icmp ne i64 %cv5976, 0
  br i1 %cond5977, label %bb_rcsuccess1855, label %bb_rcfailure1855
bb_rcfailure1855:
  %v5978 = load i64, ptr %slot32, align 8
  %p5979 = inttoptr i64 %v5978 to ptr
  %call5980 = call i32 @myl_rc_take_failure(ptr %p5979) nomerge, !dbg !168
  store i32 %call5980, ptr %slot1057, align 8
  %v5981 = load i64, ptr %slot1, align 8
  %p5982 = inttoptr i64 %v5981 to ptr
  %v5983 = load i32, ptr %slot1057, align 8
  %call5984 = call i32 @myl_qbe_rc_status(ptr %p5982, i32 %v5983) nomerge, !dbg !168
  store i32 %call5984, ptr %slot1058, align 8
  br label %bb_failure
bb_rcsuccess1855:
  br label %bb_rcgdone1841
bb_rcgplain1841:
  %v5985 = load i64, ptr %slot1043, align 8
  %v5986 = load i64, ptr %slot1041, align 8
  %p5987 = inttoptr i64 %v5986 to ptr
  store i64 %v5985, ptr %p5987, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1841
bb_rcgdone1841:
  %v5988 = load i64, ptr %slot10, align 8
  %p5989 = inttoptr i64 %v5988 to ptr
  store i32 2, ptr %p5989, align 4, !alias.scope !3, !noalias !4
  %v5990 = load i64, ptr %slot9, align 8
  %p5991 = inttoptr i64 %v5990 to ptr
  store i32 1, ptr %p5991, align 4, !alias.scope !3, !noalias !4
  %v5992 = load i64, ptr %slot7, align 8
  %p5993 = inttoptr i64 %v5992 to ptr
  %ld5994 = load i32, ptr %p5993, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5994, ptr %slot1059, align 8
  %v5995 = load i32, ptr %slot1059, align 8
  %cv5996 = zext i32 %v5995 to i64
  %cond5997 = icmp ne i64 %cv5996, 0
  br i1 %cond5997, label %bb_rcslotdrop1862, label %bb_rcslotdone1862
bb_rcslotdrop1862:
  %v5998 = load i64, ptr %slot7, align 8
  %p5999 = inttoptr i64 %v5998 to ptr
  store i32 0, ptr %p5999, align 4, !alias.scope !3, !noalias !4
  %v6000 = load i64, ptr %slot12, align 8
  store i64 %v6000, ptr %slot1060, align 8
  %v6001 = load i64, ptr %slot8, align 8
  %p6002 = inttoptr i64 %v6001 to ptr
  %ld6003 = load i32, ptr %p6002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6003, ptr %slot1061, align 8
  %v6004 = load i32, ptr %slot1061, align 8
  %op6005 = and i32 %v6004, 28
  store i32 %op6005, ptr %slot1062, align 8
  %v6006 = load i32, ptr %slot1062, align 8
  %cv6007 = zext i32 %v6006 to i64
  %cond6008 = icmp ne i64 %cv6007, 0
  br i1 %cond6008, label %bb_rcslotrole1862, label %bb_rcslotowner1862
bb_rcslotrole1862:
  %v6009 = load i64, ptr %slot32, align 8
  store i64 %v6009, ptr %slot1063, align 8
  %v6010 = load i64, ptr %slot1060, align 8
  %p6011 = inttoptr i64 %v6010 to ptr
  %ld6012 = load i64, ptr %p6011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6012, ptr %slot1064, align 8
  %v6013 = load i64, ptr %slot1064, align 8
  %cmp6014 = icmp ne i64 %v6013, 0
  %cv6015 = zext i1 %cmp6014 to i32
  store i32 %cv6015, ptr %slot1065, align 8
  %v6016 = load i32, ptr %slot1065, align 8
  %cv6017 = zext i32 %v6016 to i64
  %cond6018 = icmp ne i64 %cv6017, 0
  br i1 %cond6018, label %bb_rcgnn1878, label %bb_rcgdone1878
bb_rcgnn1878:
  %v6019 = load i64, ptr %slot1064, align 8
  %op6020 = sub i64 %v6019, 16
  store i64 %op6020, ptr %slot1066, align 8
  %v6021 = load i64, ptr %slot1064, align 8
  %p6022 = inttoptr i64 %v6021 to ptr
  %rgep6023 = getelementptr i8, ptr %p6022, i64 -16
  %ld6024 = load i64, ptr %rgep6023, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6024, ptr %slot1067, align 8
  %v6025 = load i64, ptr %slot1067, align 8
  %op6026 = and i64 %v6025, 4611686018427387906
  store i64 %op6026, ptr %slot1068, align 8
  %v6027 = load i64, ptr %slot1068, align 8
  %cmp6028 = icmp ne i64 %v6027, 0
  %cv6029 = zext i1 %cmp6028 to i32
  store i32 %cv6029, ptr %slot1069, align 8
  %v6030 = load i32, ptr %slot1069, align 8
  %cv6031 = zext i32 %v6030 to i64
  %cond6032 = icmp ne i64 %cv6031, 0
  br i1 %cond6032, label %bb_rcgclear1878, label %bb_rcgcounted1878
bb_rcgcounted1878:
  %v6033 = load i64, ptr %slot1064, align 8
  %op6034 = sub i64 %v6033, 24
  store i64 %op6034, ptr %slot1070, align 8
  %v6035 = load i64, ptr %slot1064, align 8
  %p6036 = inttoptr i64 %v6035 to ptr
  %rgep6037 = getelementptr i8, ptr %p6036, i64 -24
  %ld6038 = load i64, ptr %rgep6037, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6038, ptr %slot1071, align 8
  %v6039 = load i64, ptr %slot1071, align 8
  %op6040 = sub i64 %v6039, 1
  store i64 %op6040, ptr %slot1072, align 8
  %v6041 = load i64, ptr %slot1072, align 8
  %cmp6042 = icmp eq i64 %v6041, 0
  %cv6043 = zext i1 %cmp6042 to i32
  store i32 %cv6043, ptr %slot1073, align 8
  %v6044 = load i32, ptr %slot1073, align 8
  %cv6045 = zext i32 %v6044 to i64
  %cond6046 = icmp ne i64 %cv6045, 0
  br i1 %cond6046, label %bb_rcglast1878, label %bb_rcgdec1878
bb_rcglast1878:
  %v6047 = load i64, ptr %slot1064, align 8
  %op6048 = sub i64 %v6047, 32
  store i64 %op6048, ptr %slot1074, align 8
  %v6049 = load i64, ptr %slot1064, align 8
  %p6050 = inttoptr i64 %v6049 to ptr
  %rgep6051 = getelementptr i8, ptr %p6050, i64 -32
  %ld6052 = load i64, ptr %rgep6051, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6052, ptr %slot1075, align 8
  %v6053 = load i64, ptr %slot1075, align 8
  %cmp6054 = icmp ne i64 %v6053, 0
  %cv6055 = zext i1 %cmp6054 to i32
  store i32 %cv6055, ptr %slot1076, align 8
  %v6056 = load i32, ptr %slot1076, align 8
  %cv6057 = zext i32 %v6056 to i64
  %cond6058 = icmp ne i64 %cv6057, 0
  br i1 %cond6058, label %bb_rcgdec1878, label %bb_rcgslow1878
bb_rcgslow1878:
  %v6059 = load i64, ptr %slot1063, align 8
  %v6060 = load i64, ptr %slot1060, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6059, i64 %v6060) nomerge, !dbg !168
  br label %bb_rcgdone1878
bb_rcgdec1878:
  %v6061 = load i64, ptr %slot1072, align 8
  %v6062 = load i64, ptr %slot1064, align 8
  %p6063 = inttoptr i64 %v6062 to ptr
  %rgep6064 = getelementptr i8, ptr %p6063, i64 -24
  store i64 %v6061, ptr %rgep6064, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1878
bb_rcgclear1878:
  %v6065 = load i64, ptr %slot1060, align 8
  %p6066 = inttoptr i64 %v6065 to ptr
  store i64 0, ptr %p6066, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1878
bb_rcgdone1878:
  br label %bb_rcslotdone1862
bb_rcslotowner1862:
  %v6067 = load i64, ptr %slot32, align 8
  store i64 %v6067, ptr %slot1077, align 8
  %v6068 = load i64, ptr %slot1060, align 8
  %p6069 = inttoptr i64 %v6068 to ptr
  %ld6070 = load i64, ptr %p6069, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6070, ptr %slot1078, align 8
  %v6071 = load i64, ptr %slot1078, align 8
  %cmp6072 = icmp ne i64 %v6071, 0
  %cv6073 = zext i1 %cmp6072 to i32
  store i32 %cv6073, ptr %slot1079, align 8
  %v6074 = load i32, ptr %slot1079, align 8
  %cv6075 = zext i32 %v6074 to i64
  %cond6076 = icmp ne i64 %cv6075, 0
  br i1 %cond6076, label %bb_rcgnn1893, label %bb_rcgdone1893
bb_rcgnn1893:
  %v6077 = load i64, ptr %slot1078, align 8
  %op6078 = sub i64 %v6077, 16
  store i64 %op6078, ptr %slot1080, align 8
  %v6079 = load i64, ptr %slot1078, align 8
  %p6080 = inttoptr i64 %v6079 to ptr
  %rgep6081 = getelementptr i8, ptr %p6080, i64 -16
  %ld6082 = load i64, ptr %rgep6081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6082, ptr %slot1081, align 8
  %v6083 = load i64, ptr %slot1081, align 8
  %op6084 = and i64 %v6083, 4611686018427387906
  store i64 %op6084, ptr %slot1082, align 8
  %v6085 = load i64, ptr %slot1082, align 8
  %cmp6086 = icmp ne i64 %v6085, 0
  %cv6087 = zext i1 %cmp6086 to i32
  store i32 %cv6087, ptr %slot1083, align 8
  %v6088 = load i32, ptr %slot1083, align 8
  %cv6089 = zext i32 %v6088 to i64
  %cond6090 = icmp ne i64 %cv6089, 0
  br i1 %cond6090, label %bb_rcgclear1893, label %bb_rcgcounted1893
bb_rcgcounted1893:
  %v6091 = load i64, ptr %slot1078, align 8
  %op6092 = sub i64 %v6091, 32
  store i64 %op6092, ptr %slot1084, align 8
  %v6093 = load i64, ptr %slot1078, align 8
  %p6094 = inttoptr i64 %v6093 to ptr
  %rgep6095 = getelementptr i8, ptr %p6094, i64 -32
  %ld6096 = load i64, ptr %rgep6095, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6096, ptr %slot1085, align 8
  %v6097 = load i64, ptr %slot1085, align 8
  %op6098 = sub i64 %v6097, 1
  store i64 %op6098, ptr %slot1086, align 8
  %v6099 = load i64, ptr %slot1086, align 8
  %cmp6100 = icmp eq i64 %v6099, 0
  %cv6101 = zext i1 %cmp6100 to i32
  store i32 %cv6101, ptr %slot1087, align 8
  %v6102 = load i32, ptr %slot1087, align 8
  %cv6103 = zext i32 %v6102 to i64
  %cond6104 = icmp ne i64 %cv6103, 0
  br i1 %cond6104, label %bb_rcglast1893, label %bb_rcgdec1893
bb_rcglast1893:
  %v6105 = load i64, ptr %slot1078, align 8
  %op6106 = sub i64 %v6105, 24
  store i64 %op6106, ptr %slot1088, align 8
  %v6107 = load i64, ptr %slot1078, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  %rgep6109 = getelementptr i8, ptr %p6108, i64 -24
  %ld6110 = load i64, ptr %rgep6109, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6110, ptr %slot1089, align 8
  %v6111 = load i64, ptr %slot1089, align 8
  %cmp6112 = icmp ne i64 %v6111, 0
  %cv6113 = zext i1 %cmp6112 to i32
  store i32 %cv6113, ptr %slot1090, align 8
  %v6114 = load i32, ptr %slot1090, align 8
  %cv6115 = zext i32 %v6114 to i64
  %cond6116 = icmp ne i64 %cv6115, 0
  br i1 %cond6116, label %bb_rcgdec1893, label %bb_rcgslow1893
bb_rcgslow1893:
  %v6117 = load i64, ptr %slot1077, align 8
  %v6118 = load i64, ptr %slot1060, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6117, i64 %v6118) nomerge, !dbg !168
  br label %bb_rcgdone1893
bb_rcgdec1893:
  %v6119 = load i64, ptr %slot1086, align 8
  %v6120 = load i64, ptr %slot1078, align 8
  %p6121 = inttoptr i64 %v6120 to ptr
  %rgep6122 = getelementptr i8, ptr %p6121, i64 -32
  store i64 %v6119, ptr %rgep6122, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1893
bb_rcgclear1893:
  %v6123 = load i64, ptr %slot1060, align 8
  %p6124 = inttoptr i64 %v6123 to ptr
  store i64 0, ptr %p6124, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1893
bb_rcgdone1893:
  br label %bb_rcslotdone1862
bb_rcslotdone1862:
  br label %bb_rcprepared1808
bb_rcprepared1808:
  %v6125 = load i64, ptr %slot14, align 8
  store i64 %v6125, ptr %slot1091, align 8
  %v6126 = load i64, ptr %slot1091, align 8
  %v6127 = load i64, ptr %slot1017, align 8
  %p6128 = inttoptr i64 %v6126 to ptr
  %p6129 = inttoptr i64 %v6127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6129, ptr %p6128, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6130 = load i64, ptr %slot9, align 8
  %p6131 = inttoptr i64 %v6130 to ptr
  store i32 0, ptr %p6131, align 4, !alias.scope !3, !noalias !4
  %v6132 = load i64, ptr %slot21, align 8
  store i64 %v6132, ptr %slot1092, align 8
  %v6133 = load i64, ptr %slot1012, align 8
  %p6135 = inttoptr i64 %v6133 to ptr
  %gep6136 = getelementptr i8, ptr %p6135, i64 8
  %op6134 = ptrtoint ptr %gep6136 to i64
  store i64 %op6134, ptr %slot1093, align 8
  %v6137 = load i64, ptr %slot1092, align 8
  %p6138 = inttoptr i64 %v6137 to ptr
  %ld6139 = load i32, ptr %p6138, align 4, !alias.scope !3, !noalias !4
  %ext6140 = zext i32 %ld6139 to i64
  store i64 %ext6140, ptr %slot1094, align 8
  %v6141 = load i64, ptr %slot1094, align 8
  %cv6142 = trunc i64 %v6141 to i32
  %v6143 = load i64, ptr %slot1093, align 8
  %p6144 = inttoptr i64 %v6143 to ptr
  store i32 %cv6142, ptr %p6144, align 4, !alias.scope !3, !noalias !4
  %v6145 = load i64, ptr %slot1012, align 8
  %v6146 = load i64, ptr %slot20, align 8
  %p6147 = inttoptr i64 %v6146 to ptr
  store i64 %v6145, ptr %p6147, align 8, !alias.scope !3, !noalias !4
  %v6148 = load i64, ptr %slot20, align 8
  %p6149 = inttoptr i64 %v6148 to ptr
  %ld6150 = load i64, ptr %p6149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6150, ptr %slot1095, align 8
  %v6151 = load i64, ptr %slot12, align 8
  store i64 %v6151, ptr %slot1096, align 8
  %v6152 = load i64, ptr %slot1095, align 8
  %v6153 = load i64, ptr %slot1096, align 8
  %p6154 = inttoptr i64 %v6152 to ptr
  %p6155 = inttoptr i64 %v6153 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6155, ptr %p6154, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6156 = load i64, ptr %slot8, align 8
  %p6157 = inttoptr i64 %v6156 to ptr
  store i32 2, ptr %p6157, align 4, !alias.scope !3, !noalias !4
  %v6158 = load i64, ptr %slot7, align 8
  %p6159 = inttoptr i64 %v6158 to ptr
  store i32 1, ptr %p6159, align 4, !alias.scope !3, !noalias !4
  %v6160 = load i64, ptr %slot1096, align 8
  %v6161 = load i64, ptr %slot20, align 8
  %p6162 = inttoptr i64 %v6161 to ptr
  store i64 %v6160, ptr %p6162, align 8, !alias.scope !3, !noalias !4
  %v6163 = load i64, ptr %slot20, align 8
  %p6164 = inttoptr i64 %v6163 to ptr
  %ld6165 = load i64, ptr %p6164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6165, ptr %slot1097, align 8
  %v6166 = load i64, ptr %slot20, align 8
  %p6167 = inttoptr i64 %v6166 to ptr
  %ld6168 = load i64, ptr %p6167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6168, ptr %slot1098, align 8
  %v6169 = load i64, ptr %slot14, align 8
  store i64 %v6169, ptr %slot1099, align 8
  %v6170 = load i64, ptr %slot33, align 8
  store i64 %v6170, ptr %slot1100, align 8
  %v6171 = load i64, ptr %slot1098, align 8
  %op6172 = add i64 %v6171, 0
  store i64 %op6172, ptr %slot1101, align 8
  %v6173 = load i64, ptr %slot1101, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  %ld6175 = load i64, ptr %p6174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6175, ptr %slot1102, align 8
  %v6176 = load i64, ptr %slot1102, align 8
  %cmp6177 = icmp ne i64 %v6176, 0
  %cv6178 = zext i1 %cmp6177 to i32
  store i32 %cv6178, ptr %slot1103, align 8
  %v6179 = load i32, ptr %slot1103, align 8
  %cv6180 = zext i32 %v6179 to i64
  %cond6181 = icmp ne i64 %cv6180, 0
  br i1 %cond6181, label %bb_rcmoveheader1913, label %bb_rcmovenext1913
bb_rcmoveheader1913:
  %v6182 = load i64, ptr %slot1102, align 8
  %op6183 = sub i64 %v6182, 16
  store i64 %op6183, ptr %slot1104, align 8
  %v6184 = load i64, ptr %slot1102, align 8
  %p6185 = inttoptr i64 %v6184 to ptr
  %rgep6186 = getelementptr i8, ptr %p6185, i64 -16
  %ld6187 = load i64, ptr %rgep6186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6187, ptr %slot1105, align 8
  %v6188 = load i64, ptr %slot1105, align 8
  %op6189 = and i64 %v6188, 5764607523034234881
  store i64 %op6189, ptr %slot1106, align 8
  %v6190 = load i64, ptr %slot1106, align 8
  %cmp6191 = icmp ne i64 %v6190, 0
  %cv6192 = zext i1 %cmp6191 to i32
  store i32 %cv6192, ptr %slot1107, align 8
  %v6193 = load i32, ptr %slot1107, align 8
  %cv6194 = zext i32 %v6193 to i64
  %cond6195 = icmp ne i64 %cv6194, 0
  br i1 %cond6195, label %bb_rcmoveslow1910, label %bb_rcmovenext1913
bb_rcmovenext1913:
  %v6196 = load i64, ptr %slot1098, align 8
  %v6197 = load i64, ptr %slot1099, align 8
  %p6198 = inttoptr i64 %v6196 to ptr
  %p6199 = inttoptr i64 %v6197 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6199, ptr %p6198, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6200 = load i64, ptr %slot1098, align 8
  %p6201 = inttoptr i64 %v6200 to ptr
  store i64 0, ptr %p6201, align 8, !alias.scope !3, !noalias !4
  %v6202 = load i64, ptr %slot1098, align 8
  %op6203 = add i64 %v6202, 8
  store i64 %op6203, ptr %slot1108, align 8
  %v6204 = load i64, ptr %slot1108, align 8
  %p6205 = inttoptr i64 %v6204 to ptr
  store i64 0, ptr %p6205, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1910
bb_rcmoveslow1910:
  %v6206 = load i64, ptr %slot32, align 8
  %v6207 = load i64, ptr %slot1099, align 8
  %v6208 = load i64, ptr %slot1098, align 8
  %v6209 = load i64, ptr %slot1100, align 8
  %cv6210 = trunc i64 %v6209 to i32
  %call6211 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v6206, i64 %v6207, i64 %v6208, i32 %cv6210) nomerge, !dbg !170
  store i32 %call6211, ptr %slot1109, align 8
  %v6212 = load i32, ptr %slot1109, align 8
  %cv6213 = zext i32 %v6212 to i64
  %cond6214 = icmp ne i64 %cv6213, 0
  br i1 %cond6214, label %bb_rcsuccess1921, label %bb_rcfailure1921
bb_rcfailure1921:
  %v6215 = load i64, ptr %slot32, align 8
  %p6216 = inttoptr i64 %v6215 to ptr
  %call6217 = call i32 @myl_rc_take_failure(ptr %p6216) nomerge, !dbg !170
  store i32 %call6217, ptr %slot1110, align 8
  %v6218 = load i64, ptr %slot1, align 8
  %p6219 = inttoptr i64 %v6218 to ptr
  %v6220 = load i32, ptr %slot1110, align 8
  %call6221 = call i32 @myl_qbe_rc_status(ptr %p6219, i32 %v6220) nomerge, !dbg !170
  store i32 %call6221, ptr %slot1111, align 8
  br label %bb_failure
bb_rcsuccess1921:
  br label %bb_rcmoved1910
bb_rcmoved1910:
  %v6222 = load i64, ptr %slot7, align 8
  %p6223 = inttoptr i64 %v6222 to ptr
  store i32 0, ptr %p6223, align 4, !alias.scope !3, !noalias !4
  %v6224 = load i64, ptr %slot10, align 8
  %p6225 = inttoptr i64 %v6224 to ptr
  store i32 2, ptr %p6225, align 4, !alias.scope !3, !noalias !4
  %v6226 = load i64, ptr %slot9, align 8
  %p6227 = inttoptr i64 %v6226 to ptr
  store i32 1, ptr %p6227, align 4, !alias.scope !3, !noalias !4
  %v6228 = load i64, ptr %slot14, align 8
  store i64 %v6228, ptr %slot1112, align 8
  %v6229 = load i64, ptr %slot9, align 8
  %p6230 = inttoptr i64 %v6229 to ptr
  store i32 0, ptr %p6230, align 4, !alias.scope !3, !noalias !4
  %v6231 = load i64, ptr %slot7, align 8
  %p6232 = inttoptr i64 %v6231 to ptr
  %ld6233 = load i32, ptr %p6232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6233, ptr %slot1113, align 8
  %v6234 = load i32, ptr %slot1113, align 8
  %cv6235 = zext i32 %v6234 to i64
  %cond6236 = icmp ne i64 %cv6235, 0
  br i1 %cond6236, label %bb_rcslotdrop1931, label %bb_rcslotdone1931
bb_rcslotdrop1931:
  %v6237 = load i64, ptr %slot7, align 8
  %p6238 = inttoptr i64 %v6237 to ptr
  store i32 0, ptr %p6238, align 4, !alias.scope !3, !noalias !4
  %v6239 = load i64, ptr %slot12, align 8
  store i64 %v6239, ptr %slot1114, align 8
  %v6240 = load i64, ptr %slot8, align 8
  %p6241 = inttoptr i64 %v6240 to ptr
  %ld6242 = load i32, ptr %p6241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6242, ptr %slot1115, align 8
  %v6243 = load i32, ptr %slot1115, align 8
  %op6244 = and i32 %v6243, 28
  store i32 %op6244, ptr %slot1116, align 8
  %v6245 = load i32, ptr %slot1116, align 8
  %cv6246 = zext i32 %v6245 to i64
  %cond6247 = icmp ne i64 %cv6246, 0
  br i1 %cond6247, label %bb_rcslotrole1931, label %bb_rcslotowner1931
bb_rcslotrole1931:
  %v6248 = load i64, ptr %slot32, align 8
  store i64 %v6248, ptr %slot1117, align 8
  %v6249 = load i64, ptr %slot1117, align 8
  %v6250 = load i64, ptr %slot1114, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v6249, i64 %v6250) nomerge, !dbg !170
  br label %bb_rcslotdone1931
bb_rcslotowner1931:
  %v6251 = load i64, ptr %slot32, align 8
  store i64 %v6251, ptr %slot1118, align 8
  %v6252 = load i64, ptr %slot1118, align 8
  %v6253 = load i64, ptr %slot1114, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v6252, i64 %v6253) nomerge, !dbg !170
  br label %bb_rcslotdone1931
bb_rcslotdone1931:
  %v6254 = load i64, ptr %slot1112, align 8
  %p6255 = inttoptr i64 %v6254 to ptr
  %ret6256 = load { i64, i64 }, ptr %p6255, align 8
  ret { i64, i64 } %ret6256
bb_i67:
  %v6257 = load i64, ptr %slot20, align 8
  %p6258 = inttoptr i64 %v6257 to ptr
  store i64 0, ptr %p6258, align 8, !alias.scope !3, !noalias !4
  %v6259 = load i64, ptr %slot20, align 8
  %p6260 = inttoptr i64 %v6259 to ptr
  %ld6261 = load i64, ptr %p6260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6261, ptr %slot1119, align 8
  %v6262 = load i64, ptr %slot1119, align 8
  %cond6263 = icmp ne i64 %v6262, 0
  br i1 %cond6263, label %bb_success1994, label %bb_failed1994
bb_failed1994:
  %v6264 = load i64, ptr %slot1, align 8
  %p6265 = inttoptr i64 %v6264 to ptr
  call void @myl_qbe_fail_assert(ptr %p6265) nomerge, !dbg !172
  unreachable
bb_success1994:
  %p6266 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld6267 = load i64, ptr %p6266, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6267, ptr %slot1120, align 8
  %v6268 = load i64, ptr %slot1120, align 8
  %v6269 = load i64, ptr %slot20, align 8
  %p6270 = inttoptr i64 %v6269 to ptr
  store i64 %v6268, ptr %p6270, align 8, !alias.scope !3, !noalias !4
  %v6271 = load i64, ptr %slot20, align 8
  %p6272 = inttoptr i64 %v6271 to ptr
  %ld6273 = load i64, ptr %p6272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6273, ptr %slot1121, align 8
  %v6274 = load i64, ptr %slot1121, align 8
  %v6275 = load i64, ptr %slot13, align 8
  %p6276 = inttoptr i64 %v6275 to ptr
  store i64 %v6274, ptr %p6276, align 8, !alias.scope !3, !noalias !4
  %v6277 = load i64, ptr %slot13, align 8
  store i64 %v6277, ptr %slot1122, align 8
  %v6278 = load i64, ptr %slot14, align 8
  store i64 %v6278, ptr %slot1123, align 8
  %v6279 = load i64, ptr %slot1122, align 8
  %v6280 = load i64, ptr %slot1123, align 8
  %p6281 = inttoptr i64 %v6279 to ptr
  %p6282 = inttoptr i64 %v6280 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6282, ptr %p6281, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6283 = load i64, ptr %slot10, align 8
  %p6284 = inttoptr i64 %v6283 to ptr
  store i32 2, ptr %p6284, align 4, !alias.scope !3, !noalias !4
  %v6285 = load i64, ptr %slot9, align 8
  %p6286 = inttoptr i64 %v6285 to ptr
  store i32 1, ptr %p6286, align 4, !alias.scope !3, !noalias !4
  %v6287 = load i64, ptr %slot12, align 8
  store i64 %v6287, ptr %slot1124, align 8
  %v6288 = load i64, ptr %slot14, align 8
  store i64 %v6288, ptr %slot1125, align 8
  %v6289 = load i64, ptr %slot1125, align 8
  %v6290 = load i64, ptr %slot1124, align 8
  %p6291 = inttoptr i64 %v6289 to ptr
  %p6292 = inttoptr i64 %v6290 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6292, ptr %p6291, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6293 = load i64, ptr %slot8, align 8
  %p6294 = inttoptr i64 %v6293 to ptr
  store i32 2, ptr %p6294, align 4, !alias.scope !3, !noalias !4
  %v6295 = load i64, ptr %slot10, align 8
  %p6296 = inttoptr i64 %v6295 to ptr
  %ld6297 = load i32, ptr %p6296, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6297, ptr %slot1126, align 8
  %v6298 = load i32, ptr %slot1126, align 8
  %v6299 = load i64, ptr %slot8, align 8
  %p6300 = inttoptr i64 %v6299 to ptr
  store i32 %v6298, ptr %p6300, align 4, !alias.scope !3, !noalias !4
  %v6301 = load i64, ptr %slot9, align 8
  %p6302 = inttoptr i64 %v6301 to ptr
  store i32 0, ptr %p6302, align 4, !alias.scope !3, !noalias !4
  %v6303 = load i64, ptr %slot7, align 8
  %p6304 = inttoptr i64 %v6303 to ptr
  store i32 1, ptr %p6304, align 4, !alias.scope !3, !noalias !4
  %v6305 = load i64, ptr %slot1124, align 8
  %p6306 = inttoptr i64 %v6305 to ptr
  %ld6307 = load i64, ptr %p6306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6307, ptr %slot1127, align 8
  %v6308 = load i64, ptr %slot1127, align 8
  %v6309 = load i64, ptr %slot20, align 8
  %p6310 = inttoptr i64 %v6309 to ptr
  store i64 %v6308, ptr %p6310, align 8, !alias.scope !3, !noalias !4
  %v6311 = load i64, ptr %slot21, align 8
  %p6312 = inttoptr i64 %v6311 to ptr
  store i64 0, ptr %p6312, align 8, !alias.scope !3, !noalias !4
  %v6313 = load i64, ptr %slot30, align 8
  store i64 %v6313, ptr %slot1128, align 8
  %v6314 = load i64, ptr %slot1128, align 8
  %p6315 = inttoptr i64 %v6314 to ptr
  store i64 0, ptr %p6315, align 8, !alias.scope !3, !noalias !4
  %v6316 = load i64, ptr %slot1128, align 8
  %p6318 = inttoptr i64 %v6316 to ptr
  %gep6319 = getelementptr i8, ptr %p6318, i64 8
  %op6317 = ptrtoint ptr %gep6319 to i64
  store i64 %op6317, ptr %slot1129, align 8
  %v6320 = load i64, ptr %slot1129, align 8
  %p6321 = inttoptr i64 %v6320 to ptr
  store i64 0, ptr %p6321, align 8, !alias.scope !3, !noalias !4
  %v6322 = load i64, ptr %slot11, align 8
  %p6323 = inttoptr i64 %v6322 to ptr
  store i32 1, ptr %p6323, align 4, !alias.scope !3, !noalias !4
  %v6324 = load i64, ptr %slot33, align 8
  store i64 %v6324, ptr %slot1130, align 8
  %v6325 = load i64, ptr %slot20, align 8
  %p6326 = inttoptr i64 %v6325 to ptr
  %ld6327 = load i64, ptr %p6326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6327, ptr %slot1131, align 8
  %v6328 = load i64, ptr %slot1131, align 8
  %v6329 = load i64, ptr %slot13, align 8
  %p6330 = inttoptr i64 %v6329 to ptr
  store i64 %v6328, ptr %p6330, align 8, !alias.scope !3, !noalias !4
  %v6331 = load i64, ptr %slot13, align 8
  store i64 %v6331, ptr %slot1132, align 8
  %v6332 = load i64, ptr %slot1128, align 8
  %p6334 = inttoptr i64 %v6332 to ptr
  %gep6335 = getelementptr i8, ptr %p6334, i64 0
  %op6333 = ptrtoint ptr %gep6335 to i64
  store i64 %op6333, ptr %slot1133, align 8
  %v6336 = load i64, ptr %slot20, align 8
  %p6337 = inttoptr i64 %v6336 to ptr
  %ld6338 = load i64, ptr %p6337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6338, ptr %slot1134, align 8
  %v6339 = load i64, ptr %slot1134, align 8
  %v6340 = load i64, ptr %slot13, align 8
  %p6341 = inttoptr i64 %v6340 to ptr
  store i64 %v6339, ptr %p6341, align 8, !alias.scope !3, !noalias !4
  %v6342 = load i64, ptr %slot13, align 8
  store i64 %v6342, ptr %slot1135, align 8
  %v6343 = load i64, ptr %slot7, align 8
  %p6344 = inttoptr i64 %v6343 to ptr
  %ld6345 = load i32, ptr %p6344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6345, ptr %slot1136, align 8
  %v6346 = load i64, ptr %slot8, align 8
  %p6347 = inttoptr i64 %v6346 to ptr
  %ld6348 = load i32, ptr %p6347, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6348, ptr %slot1137, align 8
  %v6349 = load i32, ptr %slot1137, align 8
  %op6350 = and i32 %v6349, 24
  store i32 %op6350, ptr %slot1137, align 8
  %v6351 = load i32, ptr %slot1137, align 8
  %cmp6352 = icmp eq i32 %v6351, 0
  %cv6353 = zext i1 %cmp6352 to i32
  store i32 %cv6353, ptr %slot1138, align 8
  %v6354 = load i32, ptr %slot1136, align 8
  %v6355 = load i32, ptr %slot1138, align 8
  %op6356 = and i32 %v6354, %v6355
  store i32 %op6356, ptr %slot1139, align 8
  %v6357 = load i32, ptr %slot1139, align 8
  %cv6358 = zext i32 %v6357 to i64
  %cond6359 = icmp ne i64 %cv6358, 0
  br i1 %cond6359, label %bb_rctake2021, label %bb_rccopy2021
bb_rctake2021:
  %v6360 = load i64, ptr %slot14, align 8
  store i64 %v6360, ptr %slot1140, align 8
  %v6361 = load i64, ptr %slot33, align 8
  store i64 %v6361, ptr %slot1141, align 8
  %v6362 = load i64, ptr %slot1135, align 8
  %v6363 = load i64, ptr %slot1140, align 8
  %op6364 = sub i64 %v6362, %v6363
  store i64 %op6364, ptr %slot1142, align 8
  %v6365 = load i64, ptr %slot1140, align 8
  %v6366 = load i64, ptr %slot1135, align 8
  %op6367 = sub i64 %v6365, %v6366
  store i64 %op6367, ptr %slot1143, align 8
  %v6368 = load i64, ptr %slot1142, align 8
  %cmp6369 = icmp ult i64 %v6368, 8
  %cv6370 = zext i1 %cmp6369 to i32
  store i32 %cv6370, ptr %slot1144, align 8
  %v6371 = load i64, ptr %slot1143, align 8
  %cmp6372 = icmp ult i64 %v6371, 8
  %cv6373 = zext i1 %cmp6372 to i32
  store i32 %cv6373, ptr %slot1145, align 8
  %v6374 = load i32, ptr %slot1144, align 8
  %v6375 = load i32, ptr %slot1145, align 8
  %op6376 = or i32 %v6374, %v6375
  store i32 %op6376, ptr %slot1146, align 8
  %v6377 = load i32, ptr %slot1146, align 8
  %cv6378 = zext i32 %v6377 to i64
  %cond6379 = icmp ne i64 %cv6378, 0
  br i1 %cond6379, label %bb_rcmoveslow2030, label %bb_rcmovecheck2030
bb_rcmovecheck2030:
  %v6380 = load i64, ptr %slot1135, align 8
  %p6382 = inttoptr i64 %v6380 to ptr
  %gep6383 = getelementptr i8, ptr %p6382, i64 0
  %op6381 = ptrtoint ptr %gep6383 to i64
  store i64 %op6381, ptr %slot1147, align 8
  %v6384 = load i64, ptr %slot1147, align 8
  %p6385 = inttoptr i64 %v6384 to ptr
  %ld6386 = load i64, ptr %p6385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6386, ptr %slot1148, align 8
  %v6387 = load i64, ptr %slot1148, align 8
  %cmp6388 = icmp ne i64 %v6387, 0
  %cv6389 = zext i1 %cmp6388 to i32
  store i32 %cv6389, ptr %slot1149, align 8
  %v6390 = load i32, ptr %slot1149, align 8
  %cv6391 = zext i32 %v6390 to i64
  %cond6392 = icmp ne i64 %cv6391, 0
  br i1 %cond6392, label %bb_rcmoveheader2038, label %bb_rcmovenext2038
bb_rcmoveheader2038:
  %v6393 = load i64, ptr %slot1148, align 8
  %op6394 = sub i64 %v6393, 16
  store i64 %op6394, ptr %slot1150, align 8
  %v6395 = load i64, ptr %slot1148, align 8
  %p6396 = inttoptr i64 %v6395 to ptr
  %rgep6397 = getelementptr i8, ptr %p6396, i64 -16
  %ld6398 = load i64, ptr %rgep6397, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6398, ptr %slot1151, align 8
  %v6399 = load i64, ptr %slot1151, align 8
  %op6400 = and i64 %v6399, 5764607523034234881
  store i64 %op6400, ptr %slot1152, align 8
  %v6401 = load i64, ptr %slot1152, align 8
  %cmp6402 = icmp ne i64 %v6401, 0
  %cv6403 = zext i1 %cmp6402 to i32
  store i32 %cv6403, ptr %slot1153, align 8
  %v6404 = load i32, ptr %slot1153, align 8
  %cv6405 = zext i32 %v6404 to i64
  %cond6406 = icmp ne i64 %cv6405, 0
  br i1 %cond6406, label %bb_rcmoveslow2030, label %bb_rcmovenext2038
bb_rcmovenext2038:
  %v6407 = load i64, ptr %slot1135, align 8
  %v6408 = load i64, ptr %slot1140, align 8
  %p6409 = inttoptr i64 %v6407 to ptr
  %p6410 = inttoptr i64 %v6408 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6410, ptr %p6409, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6411 = load i64, ptr %slot1135, align 8
  %p6412 = inttoptr i64 %v6411 to ptr
  store i64 0, ptr %p6412, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2030
bb_rcmoveslow2030:
  %v6413 = load i64, ptr %slot32, align 8
  %v6414 = load i64, ptr %slot1140, align 8
  %v6415 = load i64, ptr %slot1135, align 8
  %v6416 = load i64, ptr %slot1141, align 8
  %cv6417 = trunc i64 %v6416 to i32
  %call6418 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v6413, i64 %v6414, i64 %v6415, i32 %cv6417) nomerge, !dbg !174
  store i32 %call6418, ptr %slot1154, align 8
  %v6419 = load i32, ptr %slot1154, align 8
  %cv6420 = zext i32 %v6419 to i64
  %cond6421 = icmp ne i64 %cv6420, 0
  br i1 %cond6421, label %bb_rcsuccess2045, label %bb_rcfailure2045
bb_rcfailure2045:
  %v6422 = load i64, ptr %slot32, align 8
  %p6423 = inttoptr i64 %v6422 to ptr
  %call6424 = call i32 @myl_rc_take_failure(ptr %p6423) nomerge, !dbg !174
  store i32 %call6424, ptr %slot1155, align 8
  %v6425 = load i64, ptr %slot1, align 8
  %p6426 = inttoptr i64 %v6425 to ptr
  %v6427 = load i32, ptr %slot1155, align 8
  %call6428 = call i32 @myl_qbe_rc_status(ptr %p6426, i32 %v6427) nomerge, !dbg !174
  store i32 %call6428, ptr %slot1156, align 8
  br label %bb_failure
bb_rcsuccess2045:
  br label %bb_rcmoved2030
bb_rcmoved2030:
  %v6429 = load i64, ptr %slot7, align 8
  %p6430 = inttoptr i64 %v6429 to ptr
  store i32 0, ptr %p6430, align 4, !alias.scope !3, !noalias !4
  %v6431 = load i64, ptr %slot10, align 8
  %p6432 = inttoptr i64 %v6431 to ptr
  store i32 2, ptr %p6432, align 4, !alias.scope !3, !noalias !4
  %v6433 = load i64, ptr %slot9, align 8
  %p6434 = inttoptr i64 %v6433 to ptr
  store i32 1, ptr %p6434, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2021
bb_rccopy2021:
  %v6435 = load i64, ptr %slot14, align 8
  store i64 %v6435, ptr %slot1157, align 8
  %v6436 = load i64, ptr %slot33, align 8
  store i64 %v6436, ptr %slot1158, align 8
  %v6437 = load i64, ptr %slot1135, align 8
  %p6438 = inttoptr i64 %v6437 to ptr
  %ld6439 = load i64, ptr %p6438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6439, ptr %slot1159, align 8
  %v6440 = load i64, ptr %slot1159, align 8
  %cmp6441 = icmp ne i64 %v6440, 0
  %cv6442 = zext i1 %cmp6441 to i32
  store i32 %cv6442, ptr %slot1160, align 8
  %v6443 = load i32, ptr %slot1160, align 8
  %cv6444 = zext i32 %v6443 to i64
  %cond6445 = icmp ne i64 %cv6444, 0
  br i1 %cond6445, label %bb_rcgnn2054, label %bb_rcgplain2054
bb_rcgnn2054:
  %v6446 = load i64, ptr %slot1159, align 8
  %op6447 = sub i64 %v6446, 16
  store i64 %op6447, ptr %slot1161, align 8
  %v6448 = load i64, ptr %slot1159, align 8
  %p6449 = inttoptr i64 %v6448 to ptr
  %rgep6450 = getelementptr i8, ptr %p6449, i64 -16
  %ld6451 = load i64, ptr %rgep6450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6451, ptr %slot1162, align 8
  %v6452 = load i64, ptr %slot1162, align 8
  %op6453 = and i64 %v6452, 4611686018427387906
  store i64 %op6453, ptr %slot1163, align 8
  %v6454 = load i64, ptr %slot1163, align 8
  %cmp6455 = icmp ne i64 %v6454, 0
  %cv6456 = zext i1 %cmp6455 to i32
  store i32 %cv6456, ptr %slot1164, align 8
  %v6457 = load i32, ptr %slot1164, align 8
  %cv6458 = zext i32 %v6457 to i64
  %cond6459 = icmp ne i64 %cv6458, 0
  br i1 %cond6459, label %bb_rcgspecial2054, label %bb_rcginc2054
bb_rcginc2054:
  %v6460 = load i64, ptr %slot1159, align 8
  %op6461 = sub i64 %v6460, 32
  store i64 %op6461, ptr %slot1165, align 8
  %v6462 = load i64, ptr %slot1159, align 8
  %p6463 = inttoptr i64 %v6462 to ptr
  %rgep6464 = getelementptr i8, ptr %p6463, i64 -32
  %ld6465 = load i64, ptr %rgep6464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6465, ptr %slot1166, align 8
  %v6466 = load i64, ptr %slot1166, align 8
  %op6467 = add i64 %v6466, 1
  store i64 %op6467, ptr %slot1167, align 8
  %v6468 = load i64, ptr %slot1167, align 8
  %cmp6469 = icmp eq i64 %v6468, 0
  %cv6470 = zext i1 %cmp6469 to i32
  store i32 %cv6470, ptr %slot1168, align 8
  %v6471 = load i32, ptr %slot1168, align 8
  %cv6472 = zext i32 %v6471 to i64
  %cond6473 = icmp ne i64 %cv6472, 0
  br i1 %cond6473, label %bb_rcglimit2054, label %bb_rcgcapacity2054
bb_rcglimit2054:
  %v6474 = load i64, ptr %slot1, align 8
  %p6475 = inttoptr i64 %v6474 to ptr
  %call6476 = call i32 @myl_qbe_rc_status(ptr %p6475, i32 2) nomerge, !dbg !174
  store i32 %call6476, ptr %slot1169, align 8
  br label %bb_failure
bb_rcgcapacity2054:
  %v6477 = load i64, ptr %slot1167, align 8
  %v6478 = load i64, ptr %slot1159, align 8
  %p6479 = inttoptr i64 %v6478 to ptr
  %rgep6480 = getelementptr i8, ptr %p6479, i64 -32
  store i64 %v6477, ptr %rgep6480, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2054
bb_rcgspecial2054:
  %v6481 = load i64, ptr %slot1162, align 8
  %op6482 = and i64 %v6481, 4611686018427387904
  store i64 %op6482, ptr %slot1170, align 8
  %v6483 = load i64, ptr %slot1170, align 8
  %cmp6484 = icmp ne i64 %v6483, 0
  %cv6485 = zext i1 %cmp6484 to i32
  store i32 %cv6485, ptr %slot1171, align 8
  %v6486 = load i32, ptr %slot1171, align 8
  %cv6487 = zext i32 %v6486 to i64
  %cond6488 = icmp ne i64 %cv6487, 0
  br i1 %cond6488, label %bb_rcgslow2054, label %bb_rcgplain2054
bb_rcgslow2054:
  %v6489 = load i64, ptr %slot32, align 8
  %v6490 = load i64, ptr %slot1157, align 8
  %v6491 = load i64, ptr %slot1135, align 8
  %v6492 = load i64, ptr %slot1158, align 8
  %cv6493 = trunc i64 %v6492 to i32
  %call6494 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v6489, i64 %v6490, i64 %v6491, i32 %cv6493) nomerge, !dbg !174
  store i32 %call6494, ptr %slot1172, align 8
  %v6495 = load i32, ptr %slot1172, align 8
  %cv6496 = zext i32 %v6495 to i64
  %cond6497 = icmp ne i64 %cv6496, 0
  br i1 %cond6497, label %bb_rcsuccess2068, label %bb_rcfailure2068
bb_rcfailure2068:
  %v6498 = load i64, ptr %slot32, align 8
  %p6499 = inttoptr i64 %v6498 to ptr
  %call6500 = call i32 @myl_rc_take_failure(ptr %p6499) nomerge, !dbg !174
  store i32 %call6500, ptr %slot1173, align 8
  %v6501 = load i64, ptr %slot1, align 8
  %p6502 = inttoptr i64 %v6501 to ptr
  %v6503 = load i32, ptr %slot1173, align 8
  %call6504 = call i32 @myl_qbe_rc_status(ptr %p6502, i32 %v6503) nomerge, !dbg !174
  store i32 %call6504, ptr %slot1174, align 8
  br label %bb_failure
bb_rcsuccess2068:
  br label %bb_rcgdone2054
bb_rcgplain2054:
  %v6505 = load i64, ptr %slot1159, align 8
  %v6506 = load i64, ptr %slot1157, align 8
  %p6507 = inttoptr i64 %v6506 to ptr
  store i64 %v6505, ptr %p6507, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2054
bb_rcgdone2054:
  %v6508 = load i64, ptr %slot10, align 8
  %p6509 = inttoptr i64 %v6508 to ptr
  store i32 2, ptr %p6509, align 4, !alias.scope !3, !noalias !4
  %v6510 = load i64, ptr %slot9, align 8
  %p6511 = inttoptr i64 %v6510 to ptr
  store i32 1, ptr %p6511, align 4, !alias.scope !3, !noalias !4
  %v6512 = load i64, ptr %slot7, align 8
  %p6513 = inttoptr i64 %v6512 to ptr
  %ld6514 = load i32, ptr %p6513, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6514, ptr %slot1175, align 8
  %v6515 = load i32, ptr %slot1175, align 8
  %cv6516 = zext i32 %v6515 to i64
  %cond6517 = icmp ne i64 %cv6516, 0
  br i1 %cond6517, label %bb_rcslotdrop2075, label %bb_rcslotdone2075
bb_rcslotdrop2075:
  %v6518 = load i64, ptr %slot7, align 8
  %p6519 = inttoptr i64 %v6518 to ptr
  store i32 0, ptr %p6519, align 4, !alias.scope !3, !noalias !4
  %v6520 = load i64, ptr %slot12, align 8
  store i64 %v6520, ptr %slot1176, align 8
  %v6521 = load i64, ptr %slot8, align 8
  %p6522 = inttoptr i64 %v6521 to ptr
  %ld6523 = load i32, ptr %p6522, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6523, ptr %slot1177, align 8
  %v6524 = load i32, ptr %slot1177, align 8
  %op6525 = and i32 %v6524, 28
  store i32 %op6525, ptr %slot1178, align 8
  %v6526 = load i32, ptr %slot1178, align 8
  %cv6527 = zext i32 %v6526 to i64
  %cond6528 = icmp ne i64 %cv6527, 0
  br i1 %cond6528, label %bb_rcslotrole2075, label %bb_rcslotowner2075
bb_rcslotrole2075:
  %v6529 = load i64, ptr %slot32, align 8
  store i64 %v6529, ptr %slot1179, align 8
  %v6530 = load i64, ptr %slot1176, align 8
  %p6531 = inttoptr i64 %v6530 to ptr
  %ld6532 = load i64, ptr %p6531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6532, ptr %slot1180, align 8
  %v6533 = load i64, ptr %slot1180, align 8
  %cmp6534 = icmp ne i64 %v6533, 0
  %cv6535 = zext i1 %cmp6534 to i32
  store i32 %cv6535, ptr %slot1181, align 8
  %v6536 = load i32, ptr %slot1181, align 8
  %cv6537 = zext i32 %v6536 to i64
  %cond6538 = icmp ne i64 %cv6537, 0
  br i1 %cond6538, label %bb_rcgnn2091, label %bb_rcgdone2091
bb_rcgnn2091:
  %v6539 = load i64, ptr %slot1180, align 8
  %op6540 = sub i64 %v6539, 16
  store i64 %op6540, ptr %slot1182, align 8
  %v6541 = load i64, ptr %slot1180, align 8
  %p6542 = inttoptr i64 %v6541 to ptr
  %rgep6543 = getelementptr i8, ptr %p6542, i64 -16
  %ld6544 = load i64, ptr %rgep6543, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6544, ptr %slot1183, align 8
  %v6545 = load i64, ptr %slot1183, align 8
  %op6546 = and i64 %v6545, 4611686018427387906
  store i64 %op6546, ptr %slot1184, align 8
  %v6547 = load i64, ptr %slot1184, align 8
  %cmp6548 = icmp ne i64 %v6547, 0
  %cv6549 = zext i1 %cmp6548 to i32
  store i32 %cv6549, ptr %slot1185, align 8
  %v6550 = load i32, ptr %slot1185, align 8
  %cv6551 = zext i32 %v6550 to i64
  %cond6552 = icmp ne i64 %cv6551, 0
  br i1 %cond6552, label %bb_rcgclear2091, label %bb_rcgcounted2091
bb_rcgcounted2091:
  %v6553 = load i64, ptr %slot1180, align 8
  %op6554 = sub i64 %v6553, 24
  store i64 %op6554, ptr %slot1186, align 8
  %v6555 = load i64, ptr %slot1180, align 8
  %p6556 = inttoptr i64 %v6555 to ptr
  %rgep6557 = getelementptr i8, ptr %p6556, i64 -24
  %ld6558 = load i64, ptr %rgep6557, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6558, ptr %slot1187, align 8
  %v6559 = load i64, ptr %slot1187, align 8
  %op6560 = sub i64 %v6559, 1
  store i64 %op6560, ptr %slot1188, align 8
  %v6561 = load i64, ptr %slot1188, align 8
  %cmp6562 = icmp eq i64 %v6561, 0
  %cv6563 = zext i1 %cmp6562 to i32
  store i32 %cv6563, ptr %slot1189, align 8
  %v6564 = load i32, ptr %slot1189, align 8
  %cv6565 = zext i32 %v6564 to i64
  %cond6566 = icmp ne i64 %cv6565, 0
  br i1 %cond6566, label %bb_rcglast2091, label %bb_rcgdec2091
bb_rcglast2091:
  %v6567 = load i64, ptr %slot1180, align 8
  %op6568 = sub i64 %v6567, 32
  store i64 %op6568, ptr %slot1190, align 8
  %v6569 = load i64, ptr %slot1180, align 8
  %p6570 = inttoptr i64 %v6569 to ptr
  %rgep6571 = getelementptr i8, ptr %p6570, i64 -32
  %ld6572 = load i64, ptr %rgep6571, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6572, ptr %slot1191, align 8
  %v6573 = load i64, ptr %slot1191, align 8
  %cmp6574 = icmp ne i64 %v6573, 0
  %cv6575 = zext i1 %cmp6574 to i32
  store i32 %cv6575, ptr %slot1192, align 8
  %v6576 = load i32, ptr %slot1192, align 8
  %cv6577 = zext i32 %v6576 to i64
  %cond6578 = icmp ne i64 %cv6577, 0
  br i1 %cond6578, label %bb_rcgdec2091, label %bb_rcgslow2091
bb_rcgslow2091:
  %v6579 = load i64, ptr %slot1179, align 8
  %v6580 = load i64, ptr %slot1176, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6579, i64 %v6580) nomerge, !dbg !174
  br label %bb_rcgdone2091
bb_rcgdec2091:
  %v6581 = load i64, ptr %slot1188, align 8
  %v6582 = load i64, ptr %slot1180, align 8
  %p6583 = inttoptr i64 %v6582 to ptr
  %rgep6584 = getelementptr i8, ptr %p6583, i64 -24
  store i64 %v6581, ptr %rgep6584, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2091
bb_rcgclear2091:
  %v6585 = load i64, ptr %slot1176, align 8
  %p6586 = inttoptr i64 %v6585 to ptr
  store i64 0, ptr %p6586, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2091
bb_rcgdone2091:
  br label %bb_rcslotdone2075
bb_rcslotowner2075:
  %v6587 = load i64, ptr %slot32, align 8
  store i64 %v6587, ptr %slot1193, align 8
  %v6588 = load i64, ptr %slot1176, align 8
  %p6589 = inttoptr i64 %v6588 to ptr
  %ld6590 = load i64, ptr %p6589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6590, ptr %slot1194, align 8
  %v6591 = load i64, ptr %slot1194, align 8
  %cmp6592 = icmp ne i64 %v6591, 0
  %cv6593 = zext i1 %cmp6592 to i32
  store i32 %cv6593, ptr %slot1195, align 8
  %v6594 = load i32, ptr %slot1195, align 8
  %cv6595 = zext i32 %v6594 to i64
  %cond6596 = icmp ne i64 %cv6595, 0
  br i1 %cond6596, label %bb_rcgnn2106, label %bb_rcgdone2106
bb_rcgnn2106:
  %v6597 = load i64, ptr %slot1194, align 8
  %op6598 = sub i64 %v6597, 16
  store i64 %op6598, ptr %slot1196, align 8
  %v6599 = load i64, ptr %slot1194, align 8
  %p6600 = inttoptr i64 %v6599 to ptr
  %rgep6601 = getelementptr i8, ptr %p6600, i64 -16
  %ld6602 = load i64, ptr %rgep6601, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6602, ptr %slot1197, align 8
  %v6603 = load i64, ptr %slot1197, align 8
  %op6604 = and i64 %v6603, 4611686018427387906
  store i64 %op6604, ptr %slot1198, align 8
  %v6605 = load i64, ptr %slot1198, align 8
  %cmp6606 = icmp ne i64 %v6605, 0
  %cv6607 = zext i1 %cmp6606 to i32
  store i32 %cv6607, ptr %slot1199, align 8
  %v6608 = load i32, ptr %slot1199, align 8
  %cv6609 = zext i32 %v6608 to i64
  %cond6610 = icmp ne i64 %cv6609, 0
  br i1 %cond6610, label %bb_rcgclear2106, label %bb_rcgcounted2106
bb_rcgcounted2106:
  %v6611 = load i64, ptr %slot1194, align 8
  %op6612 = sub i64 %v6611, 32
  store i64 %op6612, ptr %slot1200, align 8
  %v6613 = load i64, ptr %slot1194, align 8
  %p6614 = inttoptr i64 %v6613 to ptr
  %rgep6615 = getelementptr i8, ptr %p6614, i64 -32
  %ld6616 = load i64, ptr %rgep6615, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6616, ptr %slot1201, align 8
  %v6617 = load i64, ptr %slot1201, align 8
  %op6618 = sub i64 %v6617, 1
  store i64 %op6618, ptr %slot1202, align 8
  %v6619 = load i64, ptr %slot1202, align 8
  %cmp6620 = icmp eq i64 %v6619, 0
  %cv6621 = zext i1 %cmp6620 to i32
  store i32 %cv6621, ptr %slot1203, align 8
  %v6622 = load i32, ptr %slot1203, align 8
  %cv6623 = zext i32 %v6622 to i64
  %cond6624 = icmp ne i64 %cv6623, 0
  br i1 %cond6624, label %bb_rcglast2106, label %bb_rcgdec2106
bb_rcglast2106:
  %v6625 = load i64, ptr %slot1194, align 8
  %op6626 = sub i64 %v6625, 24
  store i64 %op6626, ptr %slot1204, align 8
  %v6627 = load i64, ptr %slot1194, align 8
  %p6628 = inttoptr i64 %v6627 to ptr
  %rgep6629 = getelementptr i8, ptr %p6628, i64 -24
  %ld6630 = load i64, ptr %rgep6629, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6630, ptr %slot1205, align 8
  %v6631 = load i64, ptr %slot1205, align 8
  %cmp6632 = icmp ne i64 %v6631, 0
  %cv6633 = zext i1 %cmp6632 to i32
  store i32 %cv6633, ptr %slot1206, align 8
  %v6634 = load i32, ptr %slot1206, align 8
  %cv6635 = zext i32 %v6634 to i64
  %cond6636 = icmp ne i64 %cv6635, 0
  br i1 %cond6636, label %bb_rcgdec2106, label %bb_rcgslow2106
bb_rcgslow2106:
  %v6637 = load i64, ptr %slot1193, align 8
  %v6638 = load i64, ptr %slot1176, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6637, i64 %v6638) nomerge, !dbg !174
  br label %bb_rcgdone2106
bb_rcgdec2106:
  %v6639 = load i64, ptr %slot1202, align 8
  %v6640 = load i64, ptr %slot1194, align 8
  %p6641 = inttoptr i64 %v6640 to ptr
  %rgep6642 = getelementptr i8, ptr %p6641, i64 -32
  store i64 %v6639, ptr %rgep6642, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2106
bb_rcgclear2106:
  %v6643 = load i64, ptr %slot1176, align 8
  %p6644 = inttoptr i64 %v6643 to ptr
  store i64 0, ptr %p6644, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2106
bb_rcgdone2106:
  br label %bb_rcslotdone2075
bb_rcslotdone2075:
  br label %bb_rcprepared2021
bb_rcprepared2021:
  %v6645 = load i64, ptr %slot14, align 8
  store i64 %v6645, ptr %slot1207, align 8
  %v6646 = load i64, ptr %slot1207, align 8
  %v6647 = load i64, ptr %slot1133, align 8
  %p6648 = inttoptr i64 %v6646 to ptr
  %p6649 = inttoptr i64 %v6647 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6649, ptr %p6648, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6650 = load i64, ptr %slot9, align 8
  %p6651 = inttoptr i64 %v6650 to ptr
  store i32 0, ptr %p6651, align 4, !alias.scope !3, !noalias !4
  %v6652 = load i64, ptr %slot21, align 8
  store i64 %v6652, ptr %slot1208, align 8
  %v6653 = load i64, ptr %slot1128, align 8
  %p6655 = inttoptr i64 %v6653 to ptr
  %gep6656 = getelementptr i8, ptr %p6655, i64 8
  %op6654 = ptrtoint ptr %gep6656 to i64
  store i64 %op6654, ptr %slot1209, align 8
  %v6657 = load i64, ptr %slot1208, align 8
  %p6658 = inttoptr i64 %v6657 to ptr
  %ld6659 = load i32, ptr %p6658, align 4, !alias.scope !3, !noalias !4
  %ext6660 = zext i32 %ld6659 to i64
  store i64 %ext6660, ptr %slot1210, align 8
  %v6661 = load i64, ptr %slot1210, align 8
  %cv6662 = trunc i64 %v6661 to i32
  %v6663 = load i64, ptr %slot1209, align 8
  %p6664 = inttoptr i64 %v6663 to ptr
  store i32 %cv6662, ptr %p6664, align 4, !alias.scope !3, !noalias !4
  %v6665 = load i64, ptr %slot1128, align 8
  %v6666 = load i64, ptr %slot20, align 8
  %p6667 = inttoptr i64 %v6666 to ptr
  store i64 %v6665, ptr %p6667, align 8, !alias.scope !3, !noalias !4
  %v6668 = load i64, ptr %slot20, align 8
  %p6669 = inttoptr i64 %v6668 to ptr
  %ld6670 = load i64, ptr %p6669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6670, ptr %slot1211, align 8
  %v6671 = load i64, ptr %slot12, align 8
  store i64 %v6671, ptr %slot1212, align 8
  %v6672 = load i64, ptr %slot1211, align 8
  %v6673 = load i64, ptr %slot1212, align 8
  %p6674 = inttoptr i64 %v6672 to ptr
  %p6675 = inttoptr i64 %v6673 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6675, ptr %p6674, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6676 = load i64, ptr %slot8, align 8
  %p6677 = inttoptr i64 %v6676 to ptr
  store i32 2, ptr %p6677, align 4, !alias.scope !3, !noalias !4
  %v6678 = load i64, ptr %slot7, align 8
  %p6679 = inttoptr i64 %v6678 to ptr
  store i32 1, ptr %p6679, align 4, !alias.scope !3, !noalias !4
  %v6680 = load i64, ptr %slot1212, align 8
  %v6681 = load i64, ptr %slot20, align 8
  %p6682 = inttoptr i64 %v6681 to ptr
  store i64 %v6680, ptr %p6682, align 8, !alias.scope !3, !noalias !4
  %v6683 = load i64, ptr %slot20, align 8
  %p6684 = inttoptr i64 %v6683 to ptr
  %ld6685 = load i64, ptr %p6684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6685, ptr %slot1213, align 8
  %v6686 = load i64, ptr %slot20, align 8
  %p6687 = inttoptr i64 %v6686 to ptr
  %ld6688 = load i64, ptr %p6687, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6688, ptr %slot1214, align 8
  %v6689 = load i64, ptr %slot14, align 8
  store i64 %v6689, ptr %slot1215, align 8
  %v6690 = load i64, ptr %slot33, align 8
  store i64 %v6690, ptr %slot1216, align 8
  %v6691 = load i64, ptr %slot1214, align 8
  %op6692 = add i64 %v6691, 0
  store i64 %op6692, ptr %slot1217, align 8
  %v6693 = load i64, ptr %slot1217, align 8
  %p6694 = inttoptr i64 %v6693 to ptr
  %ld6695 = load i64, ptr %p6694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6695, ptr %slot1218, align 8
  %v6696 = load i64, ptr %slot1218, align 8
  %cmp6697 = icmp ne i64 %v6696, 0
  %cv6698 = zext i1 %cmp6697 to i32
  store i32 %cv6698, ptr %slot1219, align 8
  %v6699 = load i32, ptr %slot1219, align 8
  %cv6700 = zext i32 %v6699 to i64
  %cond6701 = icmp ne i64 %cv6700, 0
  br i1 %cond6701, label %bb_rcmoveheader2126, label %bb_rcmovenext2126
bb_rcmoveheader2126:
  %v6702 = load i64, ptr %slot1218, align 8
  %op6703 = sub i64 %v6702, 16
  store i64 %op6703, ptr %slot1220, align 8
  %v6704 = load i64, ptr %slot1218, align 8
  %p6705 = inttoptr i64 %v6704 to ptr
  %rgep6706 = getelementptr i8, ptr %p6705, i64 -16
  %ld6707 = load i64, ptr %rgep6706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6707, ptr %slot1221, align 8
  %v6708 = load i64, ptr %slot1221, align 8
  %op6709 = and i64 %v6708, 5764607523034234881
  store i64 %op6709, ptr %slot1222, align 8
  %v6710 = load i64, ptr %slot1222, align 8
  %cmp6711 = icmp ne i64 %v6710, 0
  %cv6712 = zext i1 %cmp6711 to i32
  store i32 %cv6712, ptr %slot1223, align 8
  %v6713 = load i32, ptr %slot1223, align 8
  %cv6714 = zext i32 %v6713 to i64
  %cond6715 = icmp ne i64 %cv6714, 0
  br i1 %cond6715, label %bb_rcmoveslow2123, label %bb_rcmovenext2126
bb_rcmovenext2126:
  %v6716 = load i64, ptr %slot1214, align 8
  %v6717 = load i64, ptr %slot1215, align 8
  %p6718 = inttoptr i64 %v6716 to ptr
  %p6719 = inttoptr i64 %v6717 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6719, ptr %p6718, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6720 = load i64, ptr %slot1214, align 8
  %p6721 = inttoptr i64 %v6720 to ptr
  store i64 0, ptr %p6721, align 8, !alias.scope !3, !noalias !4
  %v6722 = load i64, ptr %slot1214, align 8
  %op6723 = add i64 %v6722, 8
  store i64 %op6723, ptr %slot1224, align 8
  %v6724 = load i64, ptr %slot1224, align 8
  %p6725 = inttoptr i64 %v6724 to ptr
  store i64 0, ptr %p6725, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2123
bb_rcmoveslow2123:
  %v6726 = load i64, ptr %slot32, align 8
  %v6727 = load i64, ptr %slot1215, align 8
  %v6728 = load i64, ptr %slot1214, align 8
  %v6729 = load i64, ptr %slot1216, align 8
  %cv6730 = trunc i64 %v6729 to i32
  %call6731 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v6726, i64 %v6727, i64 %v6728, i32 %cv6730) nomerge, !dbg !176
  store i32 %call6731, ptr %slot1225, align 8
  %v6732 = load i32, ptr %slot1225, align 8
  %cv6733 = zext i32 %v6732 to i64
  %cond6734 = icmp ne i64 %cv6733, 0
  br i1 %cond6734, label %bb_rcsuccess2134, label %bb_rcfailure2134
bb_rcfailure2134:
  %v6735 = load i64, ptr %slot32, align 8
  %p6736 = inttoptr i64 %v6735 to ptr
  %call6737 = call i32 @myl_rc_take_failure(ptr %p6736) nomerge, !dbg !176
  store i32 %call6737, ptr %slot1226, align 8
  %v6738 = load i64, ptr %slot1, align 8
  %p6739 = inttoptr i64 %v6738 to ptr
  %v6740 = load i32, ptr %slot1226, align 8
  %call6741 = call i32 @myl_qbe_rc_status(ptr %p6739, i32 %v6740) nomerge, !dbg !176
  store i32 %call6741, ptr %slot1227, align 8
  br label %bb_failure
bb_rcsuccess2134:
  br label %bb_rcmoved2123
bb_rcmoved2123:
  %v6742 = load i64, ptr %slot7, align 8
  %p6743 = inttoptr i64 %v6742 to ptr
  store i32 0, ptr %p6743, align 4, !alias.scope !3, !noalias !4
  %v6744 = load i64, ptr %slot10, align 8
  %p6745 = inttoptr i64 %v6744 to ptr
  store i32 2, ptr %p6745, align 4, !alias.scope !3, !noalias !4
  %v6746 = load i64, ptr %slot9, align 8
  %p6747 = inttoptr i64 %v6746 to ptr
  store i32 1, ptr %p6747, align 4, !alias.scope !3, !noalias !4
  %v6748 = load i64, ptr %slot14, align 8
  store i64 %v6748, ptr %slot1228, align 8
  %v6749 = load i64, ptr %slot9, align 8
  %p6750 = inttoptr i64 %v6749 to ptr
  store i32 0, ptr %p6750, align 4, !alias.scope !3, !noalias !4
  %v6751 = load i64, ptr %slot7, align 8
  %p6752 = inttoptr i64 %v6751 to ptr
  %ld6753 = load i32, ptr %p6752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6753, ptr %slot1229, align 8
  %v6754 = load i32, ptr %slot1229, align 8
  %cv6755 = zext i32 %v6754 to i64
  %cond6756 = icmp ne i64 %cv6755, 0
  br i1 %cond6756, label %bb_rcslotdrop2144, label %bb_rcslotdone2144
bb_rcslotdrop2144:
  %v6757 = load i64, ptr %slot7, align 8
  %p6758 = inttoptr i64 %v6757 to ptr
  store i32 0, ptr %p6758, align 4, !alias.scope !3, !noalias !4
  %v6759 = load i64, ptr %slot12, align 8
  store i64 %v6759, ptr %slot1230, align 8
  %v6760 = load i64, ptr %slot8, align 8
  %p6761 = inttoptr i64 %v6760 to ptr
  %ld6762 = load i32, ptr %p6761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6762, ptr %slot1231, align 8
  %v6763 = load i32, ptr %slot1231, align 8
  %op6764 = and i32 %v6763, 28
  store i32 %op6764, ptr %slot1232, align 8
  %v6765 = load i32, ptr %slot1232, align 8
  %cv6766 = zext i32 %v6765 to i64
  %cond6767 = icmp ne i64 %cv6766, 0
  br i1 %cond6767, label %bb_rcslotrole2144, label %bb_rcslotowner2144
bb_rcslotrole2144:
  %v6768 = load i64, ptr %slot32, align 8
  store i64 %v6768, ptr %slot1233, align 8
  %v6769 = load i64, ptr %slot1233, align 8
  %v6770 = load i64, ptr %slot1230, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v6769, i64 %v6770) nomerge, !dbg !176
  br label %bb_rcslotdone2144
bb_rcslotowner2144:
  %v6771 = load i64, ptr %slot32, align 8
  store i64 %v6771, ptr %slot1234, align 8
  %v6772 = load i64, ptr %slot1234, align 8
  %v6773 = load i64, ptr %slot1230, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v6772, i64 %v6773) nomerge, !dbg !176
  br label %bb_rcslotdone2144
bb_rcslotdone2144:
  %v6774 = load i64, ptr %slot1228, align 8
  %p6775 = inttoptr i64 %v6774 to ptr
  %ret6776 = load { i64, i64 }, ptr %p6775, align 8
  ret { i64, i64 } %ret6776
bb_i73:
  %v6777 = load i64, ptr %slot20, align 8
  %p6778 = inttoptr i64 %v6777 to ptr
  store i64 0, ptr %p6778, align 8, !alias.scope !3, !noalias !4
  %v6779 = load i64, ptr %slot20, align 8
  %p6780 = inttoptr i64 %v6779 to ptr
  %ld6781 = load i64, ptr %p6780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6781, ptr %slot1235, align 8
  %v6782 = load i64, ptr %slot1235, align 8
  %cond6783 = icmp ne i64 %v6782, 0
  br i1 %cond6783, label %bb_success2207, label %bb_failed2207
bb_failed2207:
  %v6784 = load i64, ptr %slot1, align 8
  %p6785 = inttoptr i64 %v6784 to ptr
  call void @myl_qbe_fail_assert(ptr %p6785) nomerge, !dbg !178
  unreachable
bb_success2207:
  %p6786 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld6787 = load i64, ptr %p6786, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6787, ptr %slot1236, align 8
  %v6788 = load i64, ptr %slot1236, align 8
  %v6789 = load i64, ptr %slot20, align 8
  %p6790 = inttoptr i64 %v6789 to ptr
  store i64 %v6788, ptr %p6790, align 8, !alias.scope !3, !noalias !4
  %v6791 = load i64, ptr %slot20, align 8
  %p6792 = inttoptr i64 %v6791 to ptr
  %ld6793 = load i64, ptr %p6792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6793, ptr %slot1237, align 8
  %v6794 = load i64, ptr %slot1237, align 8
  %v6795 = load i64, ptr %slot13, align 8
  %p6796 = inttoptr i64 %v6795 to ptr
  store i64 %v6794, ptr %p6796, align 8, !alias.scope !3, !noalias !4
  %v6797 = load i64, ptr %slot13, align 8
  store i64 %v6797, ptr %slot1238, align 8
  %v6798 = load i64, ptr %slot14, align 8
  store i64 %v6798, ptr %slot1239, align 8
  %v6799 = load i64, ptr %slot1238, align 8
  %v6800 = load i64, ptr %slot1239, align 8
  %p6801 = inttoptr i64 %v6799 to ptr
  %p6802 = inttoptr i64 %v6800 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6802, ptr %p6801, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6803 = load i64, ptr %slot10, align 8
  %p6804 = inttoptr i64 %v6803 to ptr
  store i32 2, ptr %p6804, align 4, !alias.scope !3, !noalias !4
  %v6805 = load i64, ptr %slot9, align 8
  %p6806 = inttoptr i64 %v6805 to ptr
  store i32 1, ptr %p6806, align 4, !alias.scope !3, !noalias !4
  %v6807 = load i64, ptr %slot12, align 8
  store i64 %v6807, ptr %slot1240, align 8
  %v6808 = load i64, ptr %slot14, align 8
  store i64 %v6808, ptr %slot1241, align 8
  %v6809 = load i64, ptr %slot1241, align 8
  %v6810 = load i64, ptr %slot1240, align 8
  %p6811 = inttoptr i64 %v6809 to ptr
  %p6812 = inttoptr i64 %v6810 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6812, ptr %p6811, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6813 = load i64, ptr %slot8, align 8
  %p6814 = inttoptr i64 %v6813 to ptr
  store i32 2, ptr %p6814, align 4, !alias.scope !3, !noalias !4
  %v6815 = load i64, ptr %slot10, align 8
  %p6816 = inttoptr i64 %v6815 to ptr
  %ld6817 = load i32, ptr %p6816, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6817, ptr %slot1242, align 8
  %v6818 = load i32, ptr %slot1242, align 8
  %v6819 = load i64, ptr %slot8, align 8
  %p6820 = inttoptr i64 %v6819 to ptr
  store i32 %v6818, ptr %p6820, align 4, !alias.scope !3, !noalias !4
  %v6821 = load i64, ptr %slot9, align 8
  %p6822 = inttoptr i64 %v6821 to ptr
  store i32 0, ptr %p6822, align 4, !alias.scope !3, !noalias !4
  %v6823 = load i64, ptr %slot7, align 8
  %p6824 = inttoptr i64 %v6823 to ptr
  store i32 1, ptr %p6824, align 4, !alias.scope !3, !noalias !4
  %v6825 = load i64, ptr %slot1240, align 8
  %p6826 = inttoptr i64 %v6825 to ptr
  %ld6827 = load i64, ptr %p6826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6827, ptr %slot1243, align 8
  %v6828 = load i64, ptr %slot1243, align 8
  %v6829 = load i64, ptr %slot20, align 8
  %p6830 = inttoptr i64 %v6829 to ptr
  store i64 %v6828, ptr %p6830, align 8, !alias.scope !3, !noalias !4
  %v6831 = load i64, ptr %slot21, align 8
  %p6832 = inttoptr i64 %v6831 to ptr
  store i64 0, ptr %p6832, align 8, !alias.scope !3, !noalias !4
  %v6833 = load i64, ptr %slot31, align 8
  store i64 %v6833, ptr %slot1244, align 8
  %v6834 = load i64, ptr %slot1244, align 8
  %p6835 = inttoptr i64 %v6834 to ptr
  store i64 0, ptr %p6835, align 8, !alias.scope !3, !noalias !4
  %v6836 = load i64, ptr %slot1244, align 8
  %p6838 = inttoptr i64 %v6836 to ptr
  %gep6839 = getelementptr i8, ptr %p6838, i64 8
  %op6837 = ptrtoint ptr %gep6839 to i64
  store i64 %op6837, ptr %slot1245, align 8
  %v6840 = load i64, ptr %slot1245, align 8
  %p6841 = inttoptr i64 %v6840 to ptr
  store i64 0, ptr %p6841, align 8, !alias.scope !3, !noalias !4
  %v6842 = load i64, ptr %slot11, align 8
  %p6843 = inttoptr i64 %v6842 to ptr
  store i32 1, ptr %p6843, align 4, !alias.scope !3, !noalias !4
  %v6844 = load i64, ptr %slot33, align 8
  store i64 %v6844, ptr %slot1246, align 8
  %v6845 = load i64, ptr %slot20, align 8
  %p6846 = inttoptr i64 %v6845 to ptr
  %ld6847 = load i64, ptr %p6846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6847, ptr %slot1247, align 8
  %v6848 = load i64, ptr %slot1247, align 8
  %v6849 = load i64, ptr %slot13, align 8
  %p6850 = inttoptr i64 %v6849 to ptr
  store i64 %v6848, ptr %p6850, align 8, !alias.scope !3, !noalias !4
  %v6851 = load i64, ptr %slot13, align 8
  store i64 %v6851, ptr %slot1248, align 8
  %v6852 = load i64, ptr %slot1244, align 8
  %p6854 = inttoptr i64 %v6852 to ptr
  %gep6855 = getelementptr i8, ptr %p6854, i64 0
  %op6853 = ptrtoint ptr %gep6855 to i64
  store i64 %op6853, ptr %slot1249, align 8
  %v6856 = load i64, ptr %slot20, align 8
  %p6857 = inttoptr i64 %v6856 to ptr
  %ld6858 = load i64, ptr %p6857, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6858, ptr %slot1250, align 8
  %v6859 = load i64, ptr %slot1250, align 8
  %v6860 = load i64, ptr %slot13, align 8
  %p6861 = inttoptr i64 %v6860 to ptr
  store i64 %v6859, ptr %p6861, align 8, !alias.scope !3, !noalias !4
  %v6862 = load i64, ptr %slot13, align 8
  store i64 %v6862, ptr %slot1251, align 8
  %v6863 = load i64, ptr %slot7, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  %ld6865 = load i32, ptr %p6864, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6865, ptr %slot1252, align 8
  %v6866 = load i64, ptr %slot8, align 8
  %p6867 = inttoptr i64 %v6866 to ptr
  %ld6868 = load i32, ptr %p6867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6868, ptr %slot1253, align 8
  %v6869 = load i32, ptr %slot1253, align 8
  %op6870 = and i32 %v6869, 24
  store i32 %op6870, ptr %slot1253, align 8
  %v6871 = load i32, ptr %slot1253, align 8
  %cmp6872 = icmp eq i32 %v6871, 0
  %cv6873 = zext i1 %cmp6872 to i32
  store i32 %cv6873, ptr %slot1254, align 8
  %v6874 = load i32, ptr %slot1252, align 8
  %v6875 = load i32, ptr %slot1254, align 8
  %op6876 = and i32 %v6874, %v6875
  store i32 %op6876, ptr %slot1255, align 8
  %v6877 = load i32, ptr %slot1255, align 8
  %cv6878 = zext i32 %v6877 to i64
  %cond6879 = icmp ne i64 %cv6878, 0
  br i1 %cond6879, label %bb_rctake2234, label %bb_rccopy2234
bb_rctake2234:
  %v6880 = load i64, ptr %slot14, align 8
  store i64 %v6880, ptr %slot1256, align 8
  %v6881 = load i64, ptr %slot33, align 8
  store i64 %v6881, ptr %slot1257, align 8
  %v6882 = load i64, ptr %slot1251, align 8
  %v6883 = load i64, ptr %slot1256, align 8
  %op6884 = sub i64 %v6882, %v6883
  store i64 %op6884, ptr %slot1258, align 8
  %v6885 = load i64, ptr %slot1256, align 8
  %v6886 = load i64, ptr %slot1251, align 8
  %op6887 = sub i64 %v6885, %v6886
  store i64 %op6887, ptr %slot1259, align 8
  %v6888 = load i64, ptr %slot1258, align 8
  %cmp6889 = icmp ult i64 %v6888, 8
  %cv6890 = zext i1 %cmp6889 to i32
  store i32 %cv6890, ptr %slot1260, align 8
  %v6891 = load i64, ptr %slot1259, align 8
  %cmp6892 = icmp ult i64 %v6891, 8
  %cv6893 = zext i1 %cmp6892 to i32
  store i32 %cv6893, ptr %slot1261, align 8
  %v6894 = load i32, ptr %slot1260, align 8
  %v6895 = load i32, ptr %slot1261, align 8
  %op6896 = or i32 %v6894, %v6895
  store i32 %op6896, ptr %slot1262, align 8
  %v6897 = load i32, ptr %slot1262, align 8
  %cv6898 = zext i32 %v6897 to i64
  %cond6899 = icmp ne i64 %cv6898, 0
  br i1 %cond6899, label %bb_rcmoveslow2243, label %bb_rcmovecheck2243
bb_rcmovecheck2243:
  %v6900 = load i64, ptr %slot1251, align 8
  %p6902 = inttoptr i64 %v6900 to ptr
  %gep6903 = getelementptr i8, ptr %p6902, i64 0
  %op6901 = ptrtoint ptr %gep6903 to i64
  store i64 %op6901, ptr %slot1263, align 8
  %v6904 = load i64, ptr %slot1263, align 8
  %p6905 = inttoptr i64 %v6904 to ptr
  %ld6906 = load i64, ptr %p6905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6906, ptr %slot1264, align 8
  %v6907 = load i64, ptr %slot1264, align 8
  %cmp6908 = icmp ne i64 %v6907, 0
  %cv6909 = zext i1 %cmp6908 to i32
  store i32 %cv6909, ptr %slot1265, align 8
  %v6910 = load i32, ptr %slot1265, align 8
  %cv6911 = zext i32 %v6910 to i64
  %cond6912 = icmp ne i64 %cv6911, 0
  br i1 %cond6912, label %bb_rcmoveheader2251, label %bb_rcmovenext2251
bb_rcmoveheader2251:
  %v6913 = load i64, ptr %slot1264, align 8
  %op6914 = sub i64 %v6913, 16
  store i64 %op6914, ptr %slot1266, align 8
  %v6915 = load i64, ptr %slot1264, align 8
  %p6916 = inttoptr i64 %v6915 to ptr
  %rgep6917 = getelementptr i8, ptr %p6916, i64 -16
  %ld6918 = load i64, ptr %rgep6917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6918, ptr %slot1267, align 8
  %v6919 = load i64, ptr %slot1267, align 8
  %op6920 = and i64 %v6919, 5764607523034234881
  store i64 %op6920, ptr %slot1268, align 8
  %v6921 = load i64, ptr %slot1268, align 8
  %cmp6922 = icmp ne i64 %v6921, 0
  %cv6923 = zext i1 %cmp6922 to i32
  store i32 %cv6923, ptr %slot1269, align 8
  %v6924 = load i32, ptr %slot1269, align 8
  %cv6925 = zext i32 %v6924 to i64
  %cond6926 = icmp ne i64 %cv6925, 0
  br i1 %cond6926, label %bb_rcmoveslow2243, label %bb_rcmovenext2251
bb_rcmovenext2251:
  %v6927 = load i64, ptr %slot1251, align 8
  %v6928 = load i64, ptr %slot1256, align 8
  %p6929 = inttoptr i64 %v6927 to ptr
  %p6930 = inttoptr i64 %v6928 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6930, ptr %p6929, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6931 = load i64, ptr %slot1251, align 8
  %p6932 = inttoptr i64 %v6931 to ptr
  store i64 0, ptr %p6932, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2243
bb_rcmoveslow2243:
  %v6933 = load i64, ptr %slot32, align 8
  %v6934 = load i64, ptr %slot1256, align 8
  %v6935 = load i64, ptr %slot1251, align 8
  %v6936 = load i64, ptr %slot1257, align 8
  %cv6937 = trunc i64 %v6936 to i32
  %call6938 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v6933, i64 %v6934, i64 %v6935, i32 %cv6937) nomerge, !dbg !180
  store i32 %call6938, ptr %slot1270, align 8
  %v6939 = load i32, ptr %slot1270, align 8
  %cv6940 = zext i32 %v6939 to i64
  %cond6941 = icmp ne i64 %cv6940, 0
  br i1 %cond6941, label %bb_rcsuccess2258, label %bb_rcfailure2258
bb_rcfailure2258:
  %v6942 = load i64, ptr %slot32, align 8
  %p6943 = inttoptr i64 %v6942 to ptr
  %call6944 = call i32 @myl_rc_take_failure(ptr %p6943) nomerge, !dbg !180
  store i32 %call6944, ptr %slot1271, align 8
  %v6945 = load i64, ptr %slot1, align 8
  %p6946 = inttoptr i64 %v6945 to ptr
  %v6947 = load i32, ptr %slot1271, align 8
  %call6948 = call i32 @myl_qbe_rc_status(ptr %p6946, i32 %v6947) nomerge, !dbg !180
  store i32 %call6948, ptr %slot1272, align 8
  br label %bb_failure
bb_rcsuccess2258:
  br label %bb_rcmoved2243
bb_rcmoved2243:
  %v6949 = load i64, ptr %slot7, align 8
  %p6950 = inttoptr i64 %v6949 to ptr
  store i32 0, ptr %p6950, align 4, !alias.scope !3, !noalias !4
  %v6951 = load i64, ptr %slot10, align 8
  %p6952 = inttoptr i64 %v6951 to ptr
  store i32 2, ptr %p6952, align 4, !alias.scope !3, !noalias !4
  %v6953 = load i64, ptr %slot9, align 8
  %p6954 = inttoptr i64 %v6953 to ptr
  store i32 1, ptr %p6954, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2234
bb_rccopy2234:
  %v6955 = load i64, ptr %slot14, align 8
  store i64 %v6955, ptr %slot1273, align 8
  %v6956 = load i64, ptr %slot33, align 8
  store i64 %v6956, ptr %slot1274, align 8
  %v6957 = load i64, ptr %slot1251, align 8
  %p6958 = inttoptr i64 %v6957 to ptr
  %ld6959 = load i64, ptr %p6958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6959, ptr %slot1275, align 8
  %v6960 = load i64, ptr %slot1275, align 8
  %cmp6961 = icmp ne i64 %v6960, 0
  %cv6962 = zext i1 %cmp6961 to i32
  store i32 %cv6962, ptr %slot1276, align 8
  %v6963 = load i32, ptr %slot1276, align 8
  %cv6964 = zext i32 %v6963 to i64
  %cond6965 = icmp ne i64 %cv6964, 0
  br i1 %cond6965, label %bb_rcgnn2267, label %bb_rcgplain2267
bb_rcgnn2267:
  %v6966 = load i64, ptr %slot1275, align 8
  %op6967 = sub i64 %v6966, 16
  store i64 %op6967, ptr %slot1277, align 8
  %v6968 = load i64, ptr %slot1275, align 8
  %p6969 = inttoptr i64 %v6968 to ptr
  %rgep6970 = getelementptr i8, ptr %p6969, i64 -16
  %ld6971 = load i64, ptr %rgep6970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6971, ptr %slot1278, align 8
  %v6972 = load i64, ptr %slot1278, align 8
  %op6973 = and i64 %v6972, 4611686018427387906
  store i64 %op6973, ptr %slot1279, align 8
  %v6974 = load i64, ptr %slot1279, align 8
  %cmp6975 = icmp ne i64 %v6974, 0
  %cv6976 = zext i1 %cmp6975 to i32
  store i32 %cv6976, ptr %slot1280, align 8
  %v6977 = load i32, ptr %slot1280, align 8
  %cv6978 = zext i32 %v6977 to i64
  %cond6979 = icmp ne i64 %cv6978, 0
  br i1 %cond6979, label %bb_rcgspecial2267, label %bb_rcginc2267
bb_rcginc2267:
  %v6980 = load i64, ptr %slot1275, align 8
  %op6981 = sub i64 %v6980, 32
  store i64 %op6981, ptr %slot1281, align 8
  %v6982 = load i64, ptr %slot1275, align 8
  %p6983 = inttoptr i64 %v6982 to ptr
  %rgep6984 = getelementptr i8, ptr %p6983, i64 -32
  %ld6985 = load i64, ptr %rgep6984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6985, ptr %slot1282, align 8
  %v6986 = load i64, ptr %slot1282, align 8
  %op6987 = add i64 %v6986, 1
  store i64 %op6987, ptr %slot1283, align 8
  %v6988 = load i64, ptr %slot1283, align 8
  %cmp6989 = icmp eq i64 %v6988, 0
  %cv6990 = zext i1 %cmp6989 to i32
  store i32 %cv6990, ptr %slot1284, align 8
  %v6991 = load i32, ptr %slot1284, align 8
  %cv6992 = zext i32 %v6991 to i64
  %cond6993 = icmp ne i64 %cv6992, 0
  br i1 %cond6993, label %bb_rcglimit2267, label %bb_rcgcapacity2267
bb_rcglimit2267:
  %v6994 = load i64, ptr %slot1, align 8
  %p6995 = inttoptr i64 %v6994 to ptr
  %call6996 = call i32 @myl_qbe_rc_status(ptr %p6995, i32 2) nomerge, !dbg !180
  store i32 %call6996, ptr %slot1285, align 8
  br label %bb_failure
bb_rcgcapacity2267:
  %v6997 = load i64, ptr %slot1283, align 8
  %v6998 = load i64, ptr %slot1275, align 8
  %p6999 = inttoptr i64 %v6998 to ptr
  %rgep7000 = getelementptr i8, ptr %p6999, i64 -32
  store i64 %v6997, ptr %rgep7000, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2267
bb_rcgspecial2267:
  %v7001 = load i64, ptr %slot1278, align 8
  %op7002 = and i64 %v7001, 4611686018427387904
  store i64 %op7002, ptr %slot1286, align 8
  %v7003 = load i64, ptr %slot1286, align 8
  %cmp7004 = icmp ne i64 %v7003, 0
  %cv7005 = zext i1 %cmp7004 to i32
  store i32 %cv7005, ptr %slot1287, align 8
  %v7006 = load i32, ptr %slot1287, align 8
  %cv7007 = zext i32 %v7006 to i64
  %cond7008 = icmp ne i64 %cv7007, 0
  br i1 %cond7008, label %bb_rcgslow2267, label %bb_rcgplain2267
bb_rcgslow2267:
  %v7009 = load i64, ptr %slot32, align 8
  %v7010 = load i64, ptr %slot1273, align 8
  %v7011 = load i64, ptr %slot1251, align 8
  %v7012 = load i64, ptr %slot1274, align 8
  %cv7013 = trunc i64 %v7012 to i32
  %call7014 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v7009, i64 %v7010, i64 %v7011, i32 %cv7013) nomerge, !dbg !180
  store i32 %call7014, ptr %slot1288, align 8
  %v7015 = load i32, ptr %slot1288, align 8
  %cv7016 = zext i32 %v7015 to i64
  %cond7017 = icmp ne i64 %cv7016, 0
  br i1 %cond7017, label %bb_rcsuccess2281, label %bb_rcfailure2281
bb_rcfailure2281:
  %v7018 = load i64, ptr %slot32, align 8
  %p7019 = inttoptr i64 %v7018 to ptr
  %call7020 = call i32 @myl_rc_take_failure(ptr %p7019) nomerge, !dbg !180
  store i32 %call7020, ptr %slot1289, align 8
  %v7021 = load i64, ptr %slot1, align 8
  %p7022 = inttoptr i64 %v7021 to ptr
  %v7023 = load i32, ptr %slot1289, align 8
  %call7024 = call i32 @myl_qbe_rc_status(ptr %p7022, i32 %v7023) nomerge, !dbg !180
  store i32 %call7024, ptr %slot1290, align 8
  br label %bb_failure
bb_rcsuccess2281:
  br label %bb_rcgdone2267
bb_rcgplain2267:
  %v7025 = load i64, ptr %slot1275, align 8
  %v7026 = load i64, ptr %slot1273, align 8
  %p7027 = inttoptr i64 %v7026 to ptr
  store i64 %v7025, ptr %p7027, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2267
bb_rcgdone2267:
  %v7028 = load i64, ptr %slot10, align 8
  %p7029 = inttoptr i64 %v7028 to ptr
  store i32 2, ptr %p7029, align 4, !alias.scope !3, !noalias !4
  %v7030 = load i64, ptr %slot9, align 8
  %p7031 = inttoptr i64 %v7030 to ptr
  store i32 1, ptr %p7031, align 4, !alias.scope !3, !noalias !4
  %v7032 = load i64, ptr %slot7, align 8
  %p7033 = inttoptr i64 %v7032 to ptr
  %ld7034 = load i32, ptr %p7033, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7034, ptr %slot1291, align 8
  %v7035 = load i32, ptr %slot1291, align 8
  %cv7036 = zext i32 %v7035 to i64
  %cond7037 = icmp ne i64 %cv7036, 0
  br i1 %cond7037, label %bb_rcslotdrop2288, label %bb_rcslotdone2288
bb_rcslotdrop2288:
  %v7038 = load i64, ptr %slot7, align 8
  %p7039 = inttoptr i64 %v7038 to ptr
  store i32 0, ptr %p7039, align 4, !alias.scope !3, !noalias !4
  %v7040 = load i64, ptr %slot12, align 8
  store i64 %v7040, ptr %slot1292, align 8
  %v7041 = load i64, ptr %slot8, align 8
  %p7042 = inttoptr i64 %v7041 to ptr
  %ld7043 = load i32, ptr %p7042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7043, ptr %slot1293, align 8
  %v7044 = load i32, ptr %slot1293, align 8
  %op7045 = and i32 %v7044, 28
  store i32 %op7045, ptr %slot1294, align 8
  %v7046 = load i32, ptr %slot1294, align 8
  %cv7047 = zext i32 %v7046 to i64
  %cond7048 = icmp ne i64 %cv7047, 0
  br i1 %cond7048, label %bb_rcslotrole2288, label %bb_rcslotowner2288
bb_rcslotrole2288:
  %v7049 = load i64, ptr %slot32, align 8
  store i64 %v7049, ptr %slot1295, align 8
  %v7050 = load i64, ptr %slot1292, align 8
  %p7051 = inttoptr i64 %v7050 to ptr
  %ld7052 = load i64, ptr %p7051, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7052, ptr %slot1296, align 8
  %v7053 = load i64, ptr %slot1296, align 8
  %cmp7054 = icmp ne i64 %v7053, 0
  %cv7055 = zext i1 %cmp7054 to i32
  store i32 %cv7055, ptr %slot1297, align 8
  %v7056 = load i32, ptr %slot1297, align 8
  %cv7057 = zext i32 %v7056 to i64
  %cond7058 = icmp ne i64 %cv7057, 0
  br i1 %cond7058, label %bb_rcgnn2304, label %bb_rcgdone2304
bb_rcgnn2304:
  %v7059 = load i64, ptr %slot1296, align 8
  %op7060 = sub i64 %v7059, 16
  store i64 %op7060, ptr %slot1298, align 8
  %v7061 = load i64, ptr %slot1296, align 8
  %p7062 = inttoptr i64 %v7061 to ptr
  %rgep7063 = getelementptr i8, ptr %p7062, i64 -16
  %ld7064 = load i64, ptr %rgep7063, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7064, ptr %slot1299, align 8
  %v7065 = load i64, ptr %slot1299, align 8
  %op7066 = and i64 %v7065, 4611686018427387906
  store i64 %op7066, ptr %slot1300, align 8
  %v7067 = load i64, ptr %slot1300, align 8
  %cmp7068 = icmp ne i64 %v7067, 0
  %cv7069 = zext i1 %cmp7068 to i32
  store i32 %cv7069, ptr %slot1301, align 8
  %v7070 = load i32, ptr %slot1301, align 8
  %cv7071 = zext i32 %v7070 to i64
  %cond7072 = icmp ne i64 %cv7071, 0
  br i1 %cond7072, label %bb_rcgclear2304, label %bb_rcgcounted2304
bb_rcgcounted2304:
  %v7073 = load i64, ptr %slot1296, align 8
  %op7074 = sub i64 %v7073, 24
  store i64 %op7074, ptr %slot1302, align 8
  %v7075 = load i64, ptr %slot1296, align 8
  %p7076 = inttoptr i64 %v7075 to ptr
  %rgep7077 = getelementptr i8, ptr %p7076, i64 -24
  %ld7078 = load i64, ptr %rgep7077, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7078, ptr %slot1303, align 8
  %v7079 = load i64, ptr %slot1303, align 8
  %op7080 = sub i64 %v7079, 1
  store i64 %op7080, ptr %slot1304, align 8
  %v7081 = load i64, ptr %slot1304, align 8
  %cmp7082 = icmp eq i64 %v7081, 0
  %cv7083 = zext i1 %cmp7082 to i32
  store i32 %cv7083, ptr %slot1305, align 8
  %v7084 = load i32, ptr %slot1305, align 8
  %cv7085 = zext i32 %v7084 to i64
  %cond7086 = icmp ne i64 %cv7085, 0
  br i1 %cond7086, label %bb_rcglast2304, label %bb_rcgdec2304
bb_rcglast2304:
  %v7087 = load i64, ptr %slot1296, align 8
  %op7088 = sub i64 %v7087, 32
  store i64 %op7088, ptr %slot1306, align 8
  %v7089 = load i64, ptr %slot1296, align 8
  %p7090 = inttoptr i64 %v7089 to ptr
  %rgep7091 = getelementptr i8, ptr %p7090, i64 -32
  %ld7092 = load i64, ptr %rgep7091, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7092, ptr %slot1307, align 8
  %v7093 = load i64, ptr %slot1307, align 8
  %cmp7094 = icmp ne i64 %v7093, 0
  %cv7095 = zext i1 %cmp7094 to i32
  store i32 %cv7095, ptr %slot1308, align 8
  %v7096 = load i32, ptr %slot1308, align 8
  %cv7097 = zext i32 %v7096 to i64
  %cond7098 = icmp ne i64 %cv7097, 0
  br i1 %cond7098, label %bb_rcgdec2304, label %bb_rcgslow2304
bb_rcgslow2304:
  %v7099 = load i64, ptr %slot1295, align 8
  %v7100 = load i64, ptr %slot1292, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7099, i64 %v7100) nomerge, !dbg !180
  br label %bb_rcgdone2304
bb_rcgdec2304:
  %v7101 = load i64, ptr %slot1304, align 8
  %v7102 = load i64, ptr %slot1296, align 8
  %p7103 = inttoptr i64 %v7102 to ptr
  %rgep7104 = getelementptr i8, ptr %p7103, i64 -24
  store i64 %v7101, ptr %rgep7104, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2304
bb_rcgclear2304:
  %v7105 = load i64, ptr %slot1292, align 8
  %p7106 = inttoptr i64 %v7105 to ptr
  store i64 0, ptr %p7106, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2304
bb_rcgdone2304:
  br label %bb_rcslotdone2288
bb_rcslotowner2288:
  %v7107 = load i64, ptr %slot32, align 8
  store i64 %v7107, ptr %slot1309, align 8
  %v7108 = load i64, ptr %slot1292, align 8
  %p7109 = inttoptr i64 %v7108 to ptr
  %ld7110 = load i64, ptr %p7109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7110, ptr %slot1310, align 8
  %v7111 = load i64, ptr %slot1310, align 8
  %cmp7112 = icmp ne i64 %v7111, 0
  %cv7113 = zext i1 %cmp7112 to i32
  store i32 %cv7113, ptr %slot1311, align 8
  %v7114 = load i32, ptr %slot1311, align 8
  %cv7115 = zext i32 %v7114 to i64
  %cond7116 = icmp ne i64 %cv7115, 0
  br i1 %cond7116, label %bb_rcgnn2319, label %bb_rcgdone2319
bb_rcgnn2319:
  %v7117 = load i64, ptr %slot1310, align 8
  %op7118 = sub i64 %v7117, 16
  store i64 %op7118, ptr %slot1312, align 8
  %v7119 = load i64, ptr %slot1310, align 8
  %p7120 = inttoptr i64 %v7119 to ptr
  %rgep7121 = getelementptr i8, ptr %p7120, i64 -16
  %ld7122 = load i64, ptr %rgep7121, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7122, ptr %slot1313, align 8
  %v7123 = load i64, ptr %slot1313, align 8
  %op7124 = and i64 %v7123, 4611686018427387906
  store i64 %op7124, ptr %slot1314, align 8
  %v7125 = load i64, ptr %slot1314, align 8
  %cmp7126 = icmp ne i64 %v7125, 0
  %cv7127 = zext i1 %cmp7126 to i32
  store i32 %cv7127, ptr %slot1315, align 8
  %v7128 = load i32, ptr %slot1315, align 8
  %cv7129 = zext i32 %v7128 to i64
  %cond7130 = icmp ne i64 %cv7129, 0
  br i1 %cond7130, label %bb_rcgclear2319, label %bb_rcgcounted2319
bb_rcgcounted2319:
  %v7131 = load i64, ptr %slot1310, align 8
  %op7132 = sub i64 %v7131, 32
  store i64 %op7132, ptr %slot1316, align 8
  %v7133 = load i64, ptr %slot1310, align 8
  %p7134 = inttoptr i64 %v7133 to ptr
  %rgep7135 = getelementptr i8, ptr %p7134, i64 -32
  %ld7136 = load i64, ptr %rgep7135, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7136, ptr %slot1317, align 8
  %v7137 = load i64, ptr %slot1317, align 8
  %op7138 = sub i64 %v7137, 1
  store i64 %op7138, ptr %slot1318, align 8
  %v7139 = load i64, ptr %slot1318, align 8
  %cmp7140 = icmp eq i64 %v7139, 0
  %cv7141 = zext i1 %cmp7140 to i32
  store i32 %cv7141, ptr %slot1319, align 8
  %v7142 = load i32, ptr %slot1319, align 8
  %cv7143 = zext i32 %v7142 to i64
  %cond7144 = icmp ne i64 %cv7143, 0
  br i1 %cond7144, label %bb_rcglast2319, label %bb_rcgdec2319
bb_rcglast2319:
  %v7145 = load i64, ptr %slot1310, align 8
  %op7146 = sub i64 %v7145, 24
  store i64 %op7146, ptr %slot1320, align 8
  %v7147 = load i64, ptr %slot1310, align 8
  %p7148 = inttoptr i64 %v7147 to ptr
  %rgep7149 = getelementptr i8, ptr %p7148, i64 -24
  %ld7150 = load i64, ptr %rgep7149, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7150, ptr %slot1321, align 8
  %v7151 = load i64, ptr %slot1321, align 8
  %cmp7152 = icmp ne i64 %v7151, 0
  %cv7153 = zext i1 %cmp7152 to i32
  store i32 %cv7153, ptr %slot1322, align 8
  %v7154 = load i32, ptr %slot1322, align 8
  %cv7155 = zext i32 %v7154 to i64
  %cond7156 = icmp ne i64 %cv7155, 0
  br i1 %cond7156, label %bb_rcgdec2319, label %bb_rcgslow2319
bb_rcgslow2319:
  %v7157 = load i64, ptr %slot1309, align 8
  %v7158 = load i64, ptr %slot1292, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7157, i64 %v7158) nomerge, !dbg !180
  br label %bb_rcgdone2319
bb_rcgdec2319:
  %v7159 = load i64, ptr %slot1318, align 8
  %v7160 = load i64, ptr %slot1310, align 8
  %p7161 = inttoptr i64 %v7160 to ptr
  %rgep7162 = getelementptr i8, ptr %p7161, i64 -32
  store i64 %v7159, ptr %rgep7162, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2319
bb_rcgclear2319:
  %v7163 = load i64, ptr %slot1292, align 8
  %p7164 = inttoptr i64 %v7163 to ptr
  store i64 0, ptr %p7164, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2319
bb_rcgdone2319:
  br label %bb_rcslotdone2288
bb_rcslotdone2288:
  br label %bb_rcprepared2234
bb_rcprepared2234:
  %v7165 = load i64, ptr %slot14, align 8
  store i64 %v7165, ptr %slot1323, align 8
  %v7166 = load i64, ptr %slot1323, align 8
  %v7167 = load i64, ptr %slot1249, align 8
  %p7168 = inttoptr i64 %v7166 to ptr
  %p7169 = inttoptr i64 %v7167 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7169, ptr %p7168, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7170 = load i64, ptr %slot9, align 8
  %p7171 = inttoptr i64 %v7170 to ptr
  store i32 0, ptr %p7171, align 4, !alias.scope !3, !noalias !4
  %v7172 = load i64, ptr %slot21, align 8
  store i64 %v7172, ptr %slot1324, align 8
  %v7173 = load i64, ptr %slot1244, align 8
  %p7175 = inttoptr i64 %v7173 to ptr
  %gep7176 = getelementptr i8, ptr %p7175, i64 8
  %op7174 = ptrtoint ptr %gep7176 to i64
  store i64 %op7174, ptr %slot1325, align 8
  %v7177 = load i64, ptr %slot1324, align 8
  %p7178 = inttoptr i64 %v7177 to ptr
  %ld7179 = load i32, ptr %p7178, align 4, !alias.scope !3, !noalias !4
  %ext7180 = zext i32 %ld7179 to i64
  store i64 %ext7180, ptr %slot1326, align 8
  %v7181 = load i64, ptr %slot1326, align 8
  %cv7182 = trunc i64 %v7181 to i32
  %v7183 = load i64, ptr %slot1325, align 8
  %p7184 = inttoptr i64 %v7183 to ptr
  store i32 %cv7182, ptr %p7184, align 4, !alias.scope !3, !noalias !4
  %v7185 = load i64, ptr %slot1244, align 8
  %v7186 = load i64, ptr %slot20, align 8
  %p7187 = inttoptr i64 %v7186 to ptr
  store i64 %v7185, ptr %p7187, align 8, !alias.scope !3, !noalias !4
  %v7188 = load i64, ptr %slot20, align 8
  %p7189 = inttoptr i64 %v7188 to ptr
  %ld7190 = load i64, ptr %p7189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7190, ptr %slot1327, align 8
  %v7191 = load i64, ptr %slot12, align 8
  store i64 %v7191, ptr %slot1328, align 8
  %v7192 = load i64, ptr %slot1327, align 8
  %v7193 = load i64, ptr %slot1328, align 8
  %p7194 = inttoptr i64 %v7192 to ptr
  %p7195 = inttoptr i64 %v7193 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7195, ptr %p7194, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v7196 = load i64, ptr %slot8, align 8
  %p7197 = inttoptr i64 %v7196 to ptr
  store i32 2, ptr %p7197, align 4, !alias.scope !3, !noalias !4
  %v7198 = load i64, ptr %slot7, align 8
  %p7199 = inttoptr i64 %v7198 to ptr
  store i32 1, ptr %p7199, align 4, !alias.scope !3, !noalias !4
  %v7200 = load i64, ptr %slot1328, align 8
  %v7201 = load i64, ptr %slot20, align 8
  %p7202 = inttoptr i64 %v7201 to ptr
  store i64 %v7200, ptr %p7202, align 8, !alias.scope !3, !noalias !4
  %v7203 = load i64, ptr %slot20, align 8
  %p7204 = inttoptr i64 %v7203 to ptr
  %ld7205 = load i64, ptr %p7204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7205, ptr %slot1329, align 8
  %v7206 = load i64, ptr %slot20, align 8
  %p7207 = inttoptr i64 %v7206 to ptr
  %ld7208 = load i64, ptr %p7207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7208, ptr %slot1330, align 8
  %v7209 = load i64, ptr %slot14, align 8
  store i64 %v7209, ptr %slot1331, align 8
  %v7210 = load i64, ptr %slot33, align 8
  store i64 %v7210, ptr %slot1332, align 8
  %v7211 = load i64, ptr %slot1330, align 8
  %op7212 = add i64 %v7211, 0
  store i64 %op7212, ptr %slot1333, align 8
  %v7213 = load i64, ptr %slot1333, align 8
  %p7214 = inttoptr i64 %v7213 to ptr
  %ld7215 = load i64, ptr %p7214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7215, ptr %slot1334, align 8
  %v7216 = load i64, ptr %slot1334, align 8
  %cmp7217 = icmp ne i64 %v7216, 0
  %cv7218 = zext i1 %cmp7217 to i32
  store i32 %cv7218, ptr %slot1335, align 8
  %v7219 = load i32, ptr %slot1335, align 8
  %cv7220 = zext i32 %v7219 to i64
  %cond7221 = icmp ne i64 %cv7220, 0
  br i1 %cond7221, label %bb_rcmoveheader2339, label %bb_rcmovenext2339
bb_rcmoveheader2339:
  %v7222 = load i64, ptr %slot1334, align 8
  %op7223 = sub i64 %v7222, 16
  store i64 %op7223, ptr %slot1336, align 8
  %v7224 = load i64, ptr %slot1334, align 8
  %p7225 = inttoptr i64 %v7224 to ptr
  %rgep7226 = getelementptr i8, ptr %p7225, i64 -16
  %ld7227 = load i64, ptr %rgep7226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7227, ptr %slot1337, align 8
  %v7228 = load i64, ptr %slot1337, align 8
  %op7229 = and i64 %v7228, 5764607523034234881
  store i64 %op7229, ptr %slot1338, align 8
  %v7230 = load i64, ptr %slot1338, align 8
  %cmp7231 = icmp ne i64 %v7230, 0
  %cv7232 = zext i1 %cmp7231 to i32
  store i32 %cv7232, ptr %slot1339, align 8
  %v7233 = load i32, ptr %slot1339, align 8
  %cv7234 = zext i32 %v7233 to i64
  %cond7235 = icmp ne i64 %cv7234, 0
  br i1 %cond7235, label %bb_rcmoveslow2336, label %bb_rcmovenext2339
bb_rcmovenext2339:
  %v7236 = load i64, ptr %slot1330, align 8
  %v7237 = load i64, ptr %slot1331, align 8
  %p7238 = inttoptr i64 %v7236 to ptr
  %p7239 = inttoptr i64 %v7237 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7239, ptr %p7238, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v7240 = load i64, ptr %slot1330, align 8
  %p7241 = inttoptr i64 %v7240 to ptr
  store i64 0, ptr %p7241, align 8, !alias.scope !3, !noalias !4
  %v7242 = load i64, ptr %slot1330, align 8
  %op7243 = add i64 %v7242, 8
  store i64 %op7243, ptr %slot1340, align 8
  %v7244 = load i64, ptr %slot1340, align 8
  %p7245 = inttoptr i64 %v7244 to ptr
  store i64 0, ptr %p7245, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2336
bb_rcmoveslow2336:
  %v7246 = load i64, ptr %slot32, align 8
  %v7247 = load i64, ptr %slot1331, align 8
  %v7248 = load i64, ptr %slot1330, align 8
  %v7249 = load i64, ptr %slot1332, align 8
  %cv7250 = trunc i64 %v7249 to i32
  %call7251 = call i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64 %v7246, i64 %v7247, i64 %v7248, i32 %cv7250) nomerge, !dbg !182
  store i32 %call7251, ptr %slot1341, align 8
  %v7252 = load i32, ptr %slot1341, align 8
  %cv7253 = zext i32 %v7252 to i64
  %cond7254 = icmp ne i64 %cv7253, 0
  br i1 %cond7254, label %bb_rcsuccess2347, label %bb_rcfailure2347
bb_rcfailure2347:
  %v7255 = load i64, ptr %slot32, align 8
  %p7256 = inttoptr i64 %v7255 to ptr
  %call7257 = call i32 @myl_rc_take_failure(ptr %p7256) nomerge, !dbg !182
  store i32 %call7257, ptr %slot1342, align 8
  %v7258 = load i64, ptr %slot1, align 8
  %p7259 = inttoptr i64 %v7258 to ptr
  %v7260 = load i32, ptr %slot1342, align 8
  %call7261 = call i32 @myl_qbe_rc_status(ptr %p7259, i32 %v7260) nomerge, !dbg !182
  store i32 %call7261, ptr %slot1343, align 8
  br label %bb_failure
bb_rcsuccess2347:
  br label %bb_rcmoved2336
bb_rcmoved2336:
  %v7262 = load i64, ptr %slot7, align 8
  %p7263 = inttoptr i64 %v7262 to ptr
  store i32 0, ptr %p7263, align 4, !alias.scope !3, !noalias !4
  %v7264 = load i64, ptr %slot10, align 8
  %p7265 = inttoptr i64 %v7264 to ptr
  store i32 2, ptr %p7265, align 4, !alias.scope !3, !noalias !4
  %v7266 = load i64, ptr %slot9, align 8
  %p7267 = inttoptr i64 %v7266 to ptr
  store i32 1, ptr %p7267, align 4, !alias.scope !3, !noalias !4
  %v7268 = load i64, ptr %slot14, align 8
  store i64 %v7268, ptr %slot1344, align 8
  %v7269 = load i64, ptr %slot9, align 8
  %p7270 = inttoptr i64 %v7269 to ptr
  store i32 0, ptr %p7270, align 4, !alias.scope !3, !noalias !4
  %v7271 = load i64, ptr %slot7, align 8
  %p7272 = inttoptr i64 %v7271 to ptr
  %ld7273 = load i32, ptr %p7272, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7273, ptr %slot1345, align 8
  %v7274 = load i32, ptr %slot1345, align 8
  %cv7275 = zext i32 %v7274 to i64
  %cond7276 = icmp ne i64 %cv7275, 0
  br i1 %cond7276, label %bb_rcslotdrop2357, label %bb_rcslotdone2357
bb_rcslotdrop2357:
  %v7277 = load i64, ptr %slot7, align 8
  %p7278 = inttoptr i64 %v7277 to ptr
  store i32 0, ptr %p7278, align 4, !alias.scope !3, !noalias !4
  %v7279 = load i64, ptr %slot12, align 8
  store i64 %v7279, ptr %slot1346, align 8
  %v7280 = load i64, ptr %slot8, align 8
  %p7281 = inttoptr i64 %v7280 to ptr
  %ld7282 = load i32, ptr %p7281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7282, ptr %slot1347, align 8
  %v7283 = load i32, ptr %slot1347, align 8
  %op7284 = and i32 %v7283, 28
  store i32 %op7284, ptr %slot1348, align 8
  %v7285 = load i32, ptr %slot1348, align 8
  %cv7286 = zext i32 %v7285 to i64
  %cond7287 = icmp ne i64 %cv7286, 0
  br i1 %cond7287, label %bb_rcslotrole2357, label %bb_rcslotowner2357
bb_rcslotrole2357:
  %v7288 = load i64, ptr %slot32, align 8
  store i64 %v7288, ptr %slot1349, align 8
  %v7289 = load i64, ptr %slot1349, align 8
  %v7290 = load i64, ptr %slot1346, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v7289, i64 %v7290) nomerge, !dbg !182
  br label %bb_rcslotdone2357
bb_rcslotowner2357:
  %v7291 = load i64, ptr %slot32, align 8
  store i64 %v7291, ptr %slot1350, align 8
  %v7292 = load i64, ptr %slot1350, align 8
  %v7293 = load i64, ptr %slot1346, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v7292, i64 %v7293) nomerge, !dbg !182
  br label %bb_rcslotdone2357
bb_rcslotdone2357:
  %v7294 = load i64, ptr %slot1344, align 8
  %p7295 = inttoptr i64 %v7294 to ptr
  %ret7296 = load { i64, i64 }, ptr %p7295, align 8
  ret { i64, i64 } %ret7296
bb_failure:
  %v7297 = load i64, ptr %slot5, align 8
  %p7298 = inttoptr i64 %v7297 to ptr
  call void @llvm.memset.p0.i64(ptr %p7298, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !182
  %v7299 = load i64, ptr %slot5, align 8
  %p7300 = inttoptr i64 %v7299 to ptr
  %ret7301 = load { i64, i64 }, ptr %p7300, align 8
  ret { i64, i64 } %ret7301
bb_entry_failure:
  %v7302 = load i64, ptr %slot5, align 8
  %p7303 = inttoptr i64 %v7302 to ptr
  call void @llvm.memset.p0.i64(ptr %p7303, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !182
  %v7304 = load i64, ptr %slot5, align 8
  %p7305 = inttoptr i64 %v7304 to ptr
  %ret7306 = load { i64, i64 }, ptr %p7305, align 8
  ret { i64, i64 } %ret7306
}

@myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64, i64)
declare i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_take(i64, i64, i64, i32)
declare void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd", linkageName: "myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3328754423960730623, i64 0, !"myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!114 = !DILocation(line: 11, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!118 = !DILocation(line: 16, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!120 = !DILocation(line: 17, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!122 = !DILocation(line: 19, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!124 = !DILocation(line: 21, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!126 = !DILocation(line: 24, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!128 = !DILocation(line: 25, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!130 = !DILocation(line: 27, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!132 = !DILocation(line: 30, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!134 = !DILocation(line: 31, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!136 = !DILocation(line: 33, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!138 = !DILocation(line: 36, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!140 = !DILocation(line: 37, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!142 = !DILocation(line: 39, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!144 = !DILocation(line: 42, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!146 = !DILocation(line: 43, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!148 = !DILocation(line: 45, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!150 = !DILocation(line: 48, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!152 = !DILocation(line: 49, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!154 = !DILocation(line: 51, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!156 = !DILocation(line: 54, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!158 = !DILocation(line: 55, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!160 = !DILocation(line: 57, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!162 = !DILocation(line: 60, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!164 = !DILocation(line: 61, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!166 = !DILocation(line: 63, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!168 = !DILocation(line: 66, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!170 = !DILocation(line: 67, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!172 = !DILocation(line: 69, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!174 = !DILocation(line: 72, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!176 = !DILocation(line: 73, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!178 = !DILocation(line: 75, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!180 = !DILocation(line: 78, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!182 = !DILocation(line: 79, column: 0, scope: !183)
