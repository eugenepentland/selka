target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_690c75f45428516b3ec0bdb8ee8a81e39a36557931bad6d619ef1296aa9a4a4d(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v118 = load i64, ptr %slot1, align 8
  %op119 = add i64 %v118, 32
  store i64 %op119, ptr %slot4, align 8
  %mem120 = alloca i8, i64 16, align 8
  %ptr121 = ptrtoint ptr %mem120 to i64
  store i64 %ptr121, ptr %slot5, align 8
  %mem122 = alloca i8, i64 8, align 8
  %ptr123 = ptrtoint ptr %mem122 to i64
  store i64 %ptr123, ptr %slot6, align 8
  %mem124 = alloca i8, i64 8, align 8
  %ptr125 = ptrtoint ptr %mem124 to i64
  store i64 %ptr125, ptr %slot7, align 8
  %mem126 = alloca i8, i64 8, align 8
  %ptr127 = ptrtoint ptr %mem126 to i64
  store i64 %ptr127, ptr %slot8, align 8
  %mem128 = alloca i8, i64 8, align 8
  %ptr129 = ptrtoint ptr %mem128 to i64
  store i64 %ptr129, ptr %slot9, align 8
  %mem130 = alloca i8, i64 8, align 8
  %ptr131 = ptrtoint ptr %mem130 to i64
  store i64 %ptr131, ptr %slot10, align 8
  %mem132 = alloca i8, i64 8, align 8
  %ptr133 = ptrtoint ptr %mem132 to i64
  store i64 %ptr133, ptr %slot11, align 8
  %mem134 = alloca i8, i64 8, align 8
  %ptr135 = ptrtoint ptr %mem134 to i64
  store i64 %ptr135, ptr %slot12, align 8
  %mem136 = alloca i8, i64 16, align 8
  %ptr137 = ptrtoint ptr %mem136 to i64
  store i64 %ptr137, ptr %slot13, align 8
  %mem138 = alloca i8, i64 16, align 8
  %ptr139 = ptrtoint ptr %mem138 to i64
  store i64 %ptr139, ptr %slot14, align 8
  %mem140 = alloca i8, i64 16, align 8
  %ptr141 = ptrtoint ptr %mem140 to i64
  store i64 %ptr141, ptr %slot15, align 8
  %mem142 = alloca i8, i64 16, align 8
  %ptr143 = ptrtoint ptr %mem142 to i64
  store i64 %ptr143, ptr %slot16, align 8
  %mem144 = alloca i8, i64 16, align 8
  %ptr145 = ptrtoint ptr %mem144 to i64
  store i64 %ptr145, ptr %slot17, align 8
  %mem146 = alloca i8, i64 16, align 8
  %ptr147 = ptrtoint ptr %mem146 to i64
  store i64 %ptr147, ptr %slot18, align 8
  %mem148 = alloca i8, i64 16, align 8
  %ptr149 = ptrtoint ptr %mem148 to i64
  store i64 %ptr149, ptr %slot19, align 8
  %mem150 = alloca i8, i64 16, align 8
  %ptr151 = ptrtoint ptr %mem150 to i64
  store i64 %ptr151, ptr %slot20, align 8
  %mem152 = alloca i8, i64 16, align 8
  %ptr153 = ptrtoint ptr %mem152 to i64
  store i64 %ptr153, ptr %slot21, align 8
  %mem154 = alloca i8, i64 16, align 8
  %ptr155 = ptrtoint ptr %mem154 to i64
  store i64 %ptr155, ptr %slot22, align 8
  %mem156 = alloca i8, i64 16, align 8
  %ptr157 = ptrtoint ptr %mem156 to i64
  store i64 %ptr157, ptr %slot23, align 8
  %mem158 = alloca i8, i64 16, align 8
  %ptr159 = ptrtoint ptr %mem158 to i64
  store i64 %ptr159, ptr %slot24, align 8
  %mem160 = alloca i8, i64 16, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot25, align 8
  %mem162 = alloca i8, i64 16, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot26, align 8
  %v164 = load i64, ptr %slot9, align 8
  %p165 = inttoptr i64 %v164 to ptr
  store i64 0, ptr %p165, align 8, !alias.scope !3, !noalias !4
  %v166 = load i64, ptr %slot2, align 8
  %v167 = load i64, ptr %slot6, align 8
  %p168 = inttoptr i64 %v167 to ptr
  store i64 %v166, ptr %p168, align 8, !alias.scope !3, !noalias !4
  %v169 = load i64, ptr %slot3, align 8
  %v170 = load i64, ptr %slot7, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i64 %v169, ptr %p171, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v172 = load i64, ptr %slot7, align 8
  %p173 = inttoptr i64 %v172 to ptr
  %ld174 = load i64, ptr %p173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld174, ptr %slot27, align 8
  %v175 = load i64, ptr %slot27, align 8
  %v176 = load i64, ptr %slot11, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i64 %v175, ptr %p177, align 8, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot11, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot28, align 8
  %v181 = load i64, ptr %slot28, align 8
  %p182 = inttoptr i64 %v181 to ptr
  %ld183 = load i32, ptr %p182, align 4, !alias.scope !4, !noalias !3
  %ext184 = zext i32 %ld183 to i64
  store i64 %ext184, ptr %slot29, align 8
  %v185 = load i64, ptr %slot29, align 8
  %cmp186 = icmp eq i64 %v185, 0
  %cv187 = zext i1 %cmp186 to i64
  store i64 %cv187, ptr %slot30, align 8
  %v188 = load i64, ptr %slot30, align 8
  %cond189 = icmp ne i64 %v188, 0
  br i1 %cond189, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i42
bb_armnext3:
  %v190 = load i64, ptr %slot29, align 8
  %cmp191 = icmp eq i64 %v190, 1
  %cv192 = zext i1 %cmp191 to i64
  store i64 %cv192, ptr %slot31, align 8
  %v193 = load i64, ptr %slot31, align 8
  %cond194 = icmp ne i64 %v193, 0
  br i1 %cond194, label %bb_arm4, label %bb_armnext4
bb_arm4:
  br label %bb_i44
bb_armnext4:
  %v195 = load i64, ptr %slot29, align 8
  %cmp196 = icmp eq i64 %v195, 2
  %cv197 = zext i1 %cmp196 to i64
  store i64 %cv197, ptr %slot32, align 8
  %v198 = load i64, ptr %slot32, align 8
  %cond199 = icmp ne i64 %v198, 0
  br i1 %cond199, label %bb_arm5, label %bb_armnext5
bb_arm5:
  br label %bb_i46
bb_armnext5:
  %v200 = load i64, ptr %slot29, align 8
  %cmp201 = icmp eq i64 %v200, 3
  %cv202 = zext i1 %cmp201 to i64
  store i64 %cv202, ptr %slot33, align 8
  %v203 = load i64, ptr %slot33, align 8
  %cond204 = icmp ne i64 %v203, 0
  br i1 %cond204, label %bb_arm6, label %bb_armnext6
bb_arm6:
  %v205 = load i64, ptr %slot28, align 8
  %op206 = add i64 %v205, 8
  store i64 %op206, ptr %slot34, align 8
  %v207 = load i64, ptr %slot34, align 8
  %p208 = inttoptr i64 %v207 to ptr
  %ld209 = load i64, ptr %p208, align 8, !alias.scope !4, !noalias !3
  store i64 %ld209, ptr %slot35, align 8
  %v210 = load i64, ptr %slot35, align 8
  %v211 = load i64, ptr %slot8, align 8
  %p212 = inttoptr i64 %v211 to ptr
  store i64 %v210, ptr %p212, align 8, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_armnext6:
  br label %bb_failure
bb_i2:
  %v213 = load i64, ptr %slot6, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i64, ptr %p214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld215, ptr %slot36, align 8
  %v216 = load i64, ptr %slot36, align 8
  %v217 = load i64, ptr %slot11, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 %v216, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot11, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot37, align 8
  %v222 = load i64, ptr %slot37, align 8
  %op223 = add i64 %v222, 0
  store i64 %op223, ptr %slot38, align 8
  %v224 = load i64, ptr %slot38, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i64, ptr %p225, align 8, !alias.scope !4, !noalias !3
  store i64 %ld226, ptr %slot39, align 8
  %v227 = load i64, ptr %slot39, align 8
  %v228 = load i64, ptr %slot11, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i64 %v227, ptr %p229, align 8, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot11, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot40, align 8
  %v233 = load i64, ptr %slot9, align 8
  store i64 %v233, ptr %slot41, align 8
  %v234 = load i64, ptr %slot40, align 8
  %v235 = load i64, ptr %slot41, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i64 %v234, ptr %p236, align 8, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot8, align 8
  %p238 = inttoptr i64 %v237 to ptr
  %ld239 = load i64, ptr %p238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld239, ptr %slot42, align 8
  %v240 = load i64, ptr %slot42, align 8
  %v241 = load i64, ptr %slot11, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i64 %v240, ptr %p242, align 8, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot11, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot43, align 8
  %v246 = load i64, ptr %slot10, align 8
  store i64 %v246, ptr %slot44, align 8
  %v247 = load i64, ptr %slot43, align 8
  %v248 = load i64, ptr %slot44, align 8
  %p249 = inttoptr i64 %v248 to ptr
  store i64 %v247, ptr %p249, align 8, !alias.scope !3, !noalias !4
  %v250 = load i64, ptr %slot10, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %ld252 = load i64, ptr %p251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld252, ptr %slot45, align 8
  %v253 = load i64, ptr %slot45, align 8
  %v254 = load i64, ptr %slot11, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i64 %v253, ptr %p255, align 8, !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot12, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i64 0, ptr %p257, align 8, !alias.scope !3, !noalias !4
  %v258 = load i64, ptr %slot12, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot46, align 8
  %v261 = load i64, ptr %slot11, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i64, ptr %p262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld263, ptr %slot47, align 8
  %v264 = load i64, ptr %slot47, align 8
  %v265 = load i64, ptr %slot46, align 8
  %cmp266 = icmp slt i64 %v264, %v265
  %cv267 = zext i1 %cmp266 to i64
  store i64 %cv267, ptr %slot48, align 8
  %v268 = load i64, ptr %slot48, align 8
  %v269 = load i64, ptr %slot11, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot11, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot49, align 8
  %v274 = load i64, ptr %slot49, align 8
  %cond275 = icmp ne i64 %v274, 0
  br i1 %cond275, label %bb_next23, label %bb_i16
bb_next23:
  %v276 = load i64, ptr %slot9, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i64, ptr %p277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot50, align 8
  %v279 = load i64, ptr %slot50, align 8
  %op280 = add i64 %v279, 0
  store i64 %op280, ptr %slot51, align 8
  %v281 = load i64, ptr %slot51, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !6, !noalias !7
  store i64 %ld283, ptr %slot52, align 8
  %v284 = load i64, ptr %slot52, align 8
  %v285 = load i64, ptr %slot11, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i64 %v284, ptr %p286, align 8, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot11, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot53, align 8
  %v290 = load i64, ptr %slot53, align 8
  %cmp291 = icmp ugt i64 %v290, 9223372036854775807
  %cv292 = zext i1 %cmp291 to i64
  store i64 %cv292, ptr %slot54, align 8
  %v293 = load i64, ptr %slot54, align 8
  %cond294 = icmp ne i64 %v293, 0
  br i1 %cond294, label %bb_cast_overflow28, label %bb_cast_ok28
bb_cast_overflow28:
  %v295 = load i64, ptr %slot1, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %v297 = load i64, ptr %slot53, align 8
  call void @myl_qbe_fail_cast(ptr %p296, i64 %v297, i64 320) nomerge, !dbg !110
  unreachable
bb_cast_ok28:
  %v298 = load i64, ptr %slot53, align 8
  %v299 = load i64, ptr %slot11, align 8
  %p300 = inttoptr i64 %v299 to ptr
  store i64 %v298, ptr %p300, align 8, !alias.scope !3, !noalias !4
  %v301 = load i64, ptr %slot10, align 8
  %p302 = inttoptr i64 %v301 to ptr
  %ld303 = load i64, ptr %p302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld303, ptr %slot55, align 8
  %v304 = load i64, ptr %slot55, align 8
  %v305 = load i64, ptr %slot12, align 8
  %p306 = inttoptr i64 %v305 to ptr
  store i64 %v304, ptr %p306, align 8, !alias.scope !3, !noalias !4
  %v307 = load i64, ptr %slot12, align 8
  %p308 = inttoptr i64 %v307 to ptr
  %ld309 = load i64, ptr %p308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld309, ptr %slot56, align 8
  %v310 = load i64, ptr %slot11, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %ld312 = load i64, ptr %p311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld312, ptr %slot57, align 8
  %v313 = load i64, ptr %slot57, align 8
  %v314 = load i64, ptr %slot56, align 8
  %ovpair316 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v313, i64 %v314)
  %op315 = extractvalue { i64, i1 } %ovpair316, 0
  %ov317 = extractvalue { i64, i1 } %ovpair316, 1
  store i64 %op315, ptr %slot58, align 8
  %v318 = load i64, ptr %slot57, align 8
  %v319 = load i64, ptr %slot58, align 8
  %op320 = xor i64 %v318, %v319
  store i64 %op320, ptr %slot59, align 8
  %v321 = load i64, ptr %slot56, align 8
  %v322 = load i64, ptr %slot58, align 8
  %op323 = xor i64 %v321, %v322
  store i64 %op323, ptr %slot60, align 8
  %v324 = load i64, ptr %slot59, align 8
  %v325 = load i64, ptr %slot60, align 8
  %op326 = and i64 %v324, %v325
  store i64 %op326, ptr %slot61, align 8
  %cv327 = zext i1 %ov317 to i64
  store i64 %cv327, ptr %slot62, align 8
  %v328 = load i64, ptr %slot62, align 8
  %cond329 = icmp ne i64 %v328, 0
  br i1 %cond329, label %bb_overflow32, label %bb_checked32
bb_overflow32:
  %v330 = load i64, ptr %slot1, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %v332 = load i64, ptr %slot57, align 8
  %v333 = load i64, ptr %slot56, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p331, i64 0, i64 %v332, i64 %v333, i64 64) nomerge, !dbg !112
  unreachable
bb_checked32:
  %v334 = load i64, ptr %slot58, align 8
  %v335 = load i64, ptr %slot11, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 %v334, ptr %p336, align 8, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot11, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot63, align 8
  %v340 = load i64, ptr %slot10, align 8
  store i64 %v340, ptr %slot64, align 8
  %v341 = load i64, ptr %slot63, align 8
  %v342 = load i64, ptr %slot64, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i64 %v341, ptr %p343, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i16:
  %v344 = load i64, ptr %slot10, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %ld346 = load i64, ptr %p345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld346, ptr %slot65, align 8
  %v347 = load i64, ptr %slot65, align 8
  %v348 = load i64, ptr %slot11, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i64 %v347, ptr %p349, align 8, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot9, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot66, align 8
  %v353 = load i64, ptr %slot11, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %ld355 = load i64, ptr %p354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld355, ptr %slot67, align 8
  %v356 = load i64, ptr %slot66, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i64, ptr %p357, align 8, !alias.scope !6, !noalias !7
  store i64 %ld358, ptr %slot68, align 8
  %v359 = load i64, ptr %slot67, align 8
  %v360 = load i64, ptr %slot68, align 8
  %cmp361 = icmp ult i64 %v359, %v360
  %cv362 = zext i1 %cmp361 to i64
  store i64 %cv362, ptr %slot69, align 8
  %v363 = load i64, ptr %slot69, align 8
  %cond364 = icmp ne i64 %v363, 0
  br i1 %cond364, label %bb_success45, label %bb_failed45
bb_failed45:
  %v365 = load i64, ptr %slot1, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %v367 = load i64, ptr %slot67, align 8
  %v368 = load i64, ptr %slot68, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p366, i64 %v367, i64 %v368) nomerge, !dbg !114
  unreachable
bb_success45:
  %v369 = load i64, ptr %slot66, align 8
  %op370 = add i64 %v369, 32
  store i64 %op370, ptr %slot70, align 8
  %v371 = load i64, ptr %slot70, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !6, !noalias !7
  store i64 %ld373, ptr %slot71, align 8
  %v374 = load i64, ptr %slot67, align 8
  %op375 = mul i64 %v374, 56
  store i64 %op375, ptr %slot72, align 8
  %v376 = load i64, ptr %slot71, align 8
  %v377 = load i64, ptr %slot72, align 8
  %op378 = add i64 %v376, %v377
  store i64 %op378, ptr %slot73, align 8
  %v379 = load i64, ptr %slot73, align 8
  %v380 = load i64, ptr %slot11, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i64 %v379, ptr %p381, align 8, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot11, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i64, ptr %p383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld384, ptr %slot74, align 8
  %v385 = load i64, ptr %slot74, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %ld387 = load i32, ptr %p386, align 4, !alias.scope !12, !noalias !13
  %ext388 = zext i32 %ld387 to i64
  store i64 %ext388, ptr %slot75, align 8
  %v389 = load i64, ptr %slot75, align 8
  %cmp390 = icmp eq i64 %v389, 0
  %cv391 = zext i1 %cmp390 to i64
  store i64 %cv391, ptr %slot76, align 8
  %v392 = load i64, ptr %slot76, align 8
  %cond393 = icmp ne i64 %v392, 0
  br i1 %cond393, label %bb_arm52, label %bb_armnext52
bb_arm52:
  br label %bb_i22
bb_armnext52:
  %v394 = load i64, ptr %slot75, align 8
  %cmp395 = icmp eq i64 %v394, 1
  %cv396 = zext i1 %cmp395 to i64
  store i64 %cv396, ptr %slot77, align 8
  %v397 = load i64, ptr %slot77, align 8
  %cond398 = icmp ne i64 %v397, 0
  br i1 %cond398, label %bb_arm53, label %bb_armnext53
bb_arm53:
  br label %bb_i24
bb_armnext53:
  %v399 = load i64, ptr %slot75, align 8
  %cmp400 = icmp eq i64 %v399, 2
  %cv401 = zext i1 %cmp400 to i64
  store i64 %cv401, ptr %slot78, align 8
  %v402 = load i64, ptr %slot78, align 8
  %cond403 = icmp ne i64 %v402, 0
  br i1 %cond403, label %bb_arm54, label %bb_armnext54
bb_arm54:
  br label %bb_i26
bb_armnext54:
  %v404 = load i64, ptr %slot75, align 8
  %cmp405 = icmp eq i64 %v404, 3
  %cv406 = zext i1 %cmp405 to i64
  store i64 %cv406, ptr %slot79, align 8
  %v407 = load i64, ptr %slot79, align 8
  %cond408 = icmp ne i64 %v407, 0
  br i1 %cond408, label %bb_arm55, label %bb_armnext55
bb_arm55:
  br label %bb_i28
bb_armnext55:
  %v409 = load i64, ptr %slot75, align 8
  %cmp410 = icmp eq i64 %v409, 4
  %cv411 = zext i1 %cmp410 to i64
  store i64 %cv411, ptr %slot80, align 8
  %v412 = load i64, ptr %slot80, align 8
  %cond413 = icmp ne i64 %v412, 0
  br i1 %cond413, label %bb_arm56, label %bb_armnext56
bb_arm56:
  br label %bb_i30
bb_armnext56:
  %v414 = load i64, ptr %slot75, align 8
  %cmp415 = icmp eq i64 %v414, 5
  %cv416 = zext i1 %cmp415 to i64
  store i64 %cv416, ptr %slot81, align 8
  %v417 = load i64, ptr %slot81, align 8
  %cond418 = icmp ne i64 %v417, 0
  br i1 %cond418, label %bb_arm57, label %bb_armnext57
bb_arm57:
  br label %bb_i32
bb_armnext57:
  %v419 = load i64, ptr %slot75, align 8
  %cmp420 = icmp eq i64 %v419, 6
  %cv421 = zext i1 %cmp420 to i64
  store i64 %cv421, ptr %slot82, align 8
  %v422 = load i64, ptr %slot82, align 8
  %cond423 = icmp ne i64 %v422, 0
  br i1 %cond423, label %bb_arm58, label %bb_armnext58
bb_arm58:
  br label %bb_i34
bb_armnext58:
  %v424 = load i64, ptr %slot75, align 8
  %cmp425 = icmp eq i64 %v424, 7
  %cv426 = zext i1 %cmp425 to i64
  store i64 %cv426, ptr %slot83, align 8
  %v427 = load i64, ptr %slot83, align 8
  %cond428 = icmp ne i64 %v427, 0
  br i1 %cond428, label %bb_arm59, label %bb_armnext59
bb_arm59:
  br label %bb_i19
bb_armnext59:
  %v429 = load i64, ptr %slot75, align 8
  %cmp430 = icmp eq i64 %v429, 8
  %cv431 = zext i1 %cmp430 to i64
  store i64 %cv431, ptr %slot84, align 8
  %v432 = load i64, ptr %slot84, align 8
  %cond433 = icmp ne i64 %v432, 0
  br i1 %cond433, label %bb_arm60, label %bb_armnext60
bb_arm60:
  br label %bb_i36
bb_armnext60:
  %v434 = load i64, ptr %slot75, align 8
  %cmp435 = icmp eq i64 %v434, 9
  %cv436 = zext i1 %cmp435 to i64
  store i64 %cv436, ptr %slot85, align 8
  %v437 = load i64, ptr %slot85, align 8
  %cond438 = icmp ne i64 %v437, 0
  br i1 %cond438, label %bb_arm61, label %bb_armnext61
bb_arm61:
  br label %bb_i38
bb_armnext61:
  %v439 = load i64, ptr %slot75, align 8
  %cmp440 = icmp eq i64 %v439, 10
  %cv441 = zext i1 %cmp440 to i64
  store i64 %cv441, ptr %slot86, align 8
  %v442 = load i64, ptr %slot86, align 8
  %cond443 = icmp ne i64 %v442, 0
  br i1 %cond443, label %bb_arm62, label %bb_armnext62
bb_arm62:
  br label %bb_i40
bb_armnext62:
  br label %bb_failure
bb_i19:
  %v444 = load i64, ptr %slot8, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i64, ptr %p445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld446, ptr %slot87, align 8
  %v447 = load i64, ptr %slot87, align 8
  %v448 = load i64, ptr %slot11, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i64 %v447, ptr %p449, align 8, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot13, align 8
  store i64 %v450, ptr %slot88, align 8
  %v451 = load i64, ptr %slot88, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i32 1, ptr %p452, align 4, !alias.scope !3, !noalias !4
  %v453 = load i64, ptr %slot88, align 8
  %p455 = inttoptr i64 %v453 to ptr
  %gep456 = getelementptr i8, ptr %p455, i64 8
  %op454 = ptrtoint ptr %gep456 to i64
  store i64 %op454, ptr %slot89, align 8
  %v457 = load i64, ptr %slot11, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %ld459 = load i64, ptr %p458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld459, ptr %slot90, align 8
  %v460 = load i64, ptr %slot90, align 8
  %v461 = load i64, ptr %slot89, align 8
  %p462 = inttoptr i64 %v461 to ptr
  store i64 %v460, ptr %p462, align 8, !alias.scope !3, !noalias !4
  %v463 = load i64, ptr %slot88, align 8
  %v464 = load i64, ptr %slot11, align 8
  %p465 = inttoptr i64 %v464 to ptr
  store i64 %v463, ptr %p465, align 8, !alias.scope !3, !noalias !4
  %v466 = load i64, ptr %slot11, align 8
  %p467 = inttoptr i64 %v466 to ptr
  %ld468 = load i64, ptr %p467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld468, ptr %slot91, align 8
  %v469 = load i64, ptr %slot91, align 8
  %p470 = inttoptr i64 %v469 to ptr
  %ret471 = load { i64, i64 }, ptr %p470, align 8
  ret { i64, i64 } %ret471
bb_i22:
  %v472 = load i64, ptr %slot14, align 8
  store i64 %v472, ptr %slot92, align 8
  %v473 = load i64, ptr %slot92, align 8
  %p474 = inttoptr i64 %v473 to ptr
  store i32 0, ptr %p474, align 4, !alias.scope !3, !noalias !4
  %v475 = load i64, ptr %slot92, align 8
  %v476 = load i64, ptr %slot11, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i64 %v475, ptr %p477, align 8, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot11, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %ld480 = load i64, ptr %p479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld480, ptr %slot93, align 8
  %v481 = load i64, ptr %slot93, align 8
  %p482 = inttoptr i64 %v481 to ptr
  %ret483 = load { i64, i64 }, ptr %p482, align 8
  ret { i64, i64 } %ret483
bb_i24:
  %v484 = load i64, ptr %slot15, align 8
  store i64 %v484, ptr %slot94, align 8
  %v485 = load i64, ptr %slot94, align 8
  %p486 = inttoptr i64 %v485 to ptr
  store i32 0, ptr %p486, align 4, !alias.scope !3, !noalias !4
  %v487 = load i64, ptr %slot94, align 8
  %v488 = load i64, ptr %slot11, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i64 %v487, ptr %p489, align 8, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot11, align 8
  %p491 = inttoptr i64 %v490 to ptr
  %ld492 = load i64, ptr %p491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld492, ptr %slot95, align 8
  %v493 = load i64, ptr %slot95, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %ret495 = load { i64, i64 }, ptr %p494, align 8
  ret { i64, i64 } %ret495
bb_i26:
  %v496 = load i64, ptr %slot16, align 8
  store i64 %v496, ptr %slot96, align 8
  %v497 = load i64, ptr %slot96, align 8
  %p498 = inttoptr i64 %v497 to ptr
  store i32 0, ptr %p498, align 4, !alias.scope !3, !noalias !4
  %v499 = load i64, ptr %slot96, align 8
  %v500 = load i64, ptr %slot11, align 8
  %p501 = inttoptr i64 %v500 to ptr
  store i64 %v499, ptr %p501, align 8, !alias.scope !3, !noalias !4
  %v502 = load i64, ptr %slot11, align 8
  %p503 = inttoptr i64 %v502 to ptr
  %ld504 = load i64, ptr %p503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld504, ptr %slot97, align 8
  %v505 = load i64, ptr %slot97, align 8
  %p506 = inttoptr i64 %v505 to ptr
  %ret507 = load { i64, i64 }, ptr %p506, align 8
  ret { i64, i64 } %ret507
bb_i28:
  %v508 = load i64, ptr %slot17, align 8
  store i64 %v508, ptr %slot98, align 8
  %v509 = load i64, ptr %slot98, align 8
  %p510 = inttoptr i64 %v509 to ptr
  store i32 0, ptr %p510, align 4, !alias.scope !3, !noalias !4
  %v511 = load i64, ptr %slot98, align 8
  %v512 = load i64, ptr %slot11, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i64 %v511, ptr %p513, align 8, !alias.scope !3, !noalias !4
  %v514 = load i64, ptr %slot11, align 8
  %p515 = inttoptr i64 %v514 to ptr
  %ld516 = load i64, ptr %p515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld516, ptr %slot99, align 8
  %v517 = load i64, ptr %slot99, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ret519 = load { i64, i64 }, ptr %p518, align 8
  ret { i64, i64 } %ret519
bb_i30:
  %v520 = load i64, ptr %slot18, align 8
  store i64 %v520, ptr %slot100, align 8
  %v521 = load i64, ptr %slot100, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i32 0, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot100, align 8
  %v524 = load i64, ptr %slot11, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 %v523, ptr %p525, align 8, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot11, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot101, align 8
  %v529 = load i64, ptr %slot101, align 8
  %p530 = inttoptr i64 %v529 to ptr
  %ret531 = load { i64, i64 }, ptr %p530, align 8
  ret { i64, i64 } %ret531
bb_i32:
  %v532 = load i64, ptr %slot19, align 8
  store i64 %v532, ptr %slot102, align 8
  %v533 = load i64, ptr %slot102, align 8
  %p534 = inttoptr i64 %v533 to ptr
  store i32 0, ptr %p534, align 4, !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot102, align 8
  %v536 = load i64, ptr %slot11, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i64 %v535, ptr %p537, align 8, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot11, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld540, ptr %slot103, align 8
  %v541 = load i64, ptr %slot103, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ret543 = load { i64, i64 }, ptr %p542, align 8
  ret { i64, i64 } %ret543
bb_i34:
  %v544 = load i64, ptr %slot20, align 8
  store i64 %v544, ptr %slot104, align 8
  %v545 = load i64, ptr %slot104, align 8
  %p546 = inttoptr i64 %v545 to ptr
  store i32 0, ptr %p546, align 4, !alias.scope !3, !noalias !4
  %v547 = load i64, ptr %slot104, align 8
  %v548 = load i64, ptr %slot11, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i64 %v547, ptr %p549, align 8, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot11, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot105, align 8
  %v553 = load i64, ptr %slot105, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ret555 = load { i64, i64 }, ptr %p554, align 8
  ret { i64, i64 } %ret555
bb_i36:
  %v556 = load i64, ptr %slot21, align 8
  store i64 %v556, ptr %slot106, align 8
  %v557 = load i64, ptr %slot106, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i32 0, ptr %p558, align 4, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot106, align 8
  %v560 = load i64, ptr %slot11, align 8
  %p561 = inttoptr i64 %v560 to ptr
  store i64 %v559, ptr %p561, align 8, !alias.scope !3, !noalias !4
  %v562 = load i64, ptr %slot11, align 8
  %p563 = inttoptr i64 %v562 to ptr
  %ld564 = load i64, ptr %p563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld564, ptr %slot107, align 8
  %v565 = load i64, ptr %slot107, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %ret567 = load { i64, i64 }, ptr %p566, align 8
  ret { i64, i64 } %ret567
bb_i38:
  %v568 = load i64, ptr %slot22, align 8
  store i64 %v568, ptr %slot108, align 8
  %v569 = load i64, ptr %slot108, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i32 0, ptr %p570, align 4, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot108, align 8
  %v572 = load i64, ptr %slot11, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i64 %v571, ptr %p573, align 8, !alias.scope !3, !noalias !4
  %v574 = load i64, ptr %slot11, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %ld576 = load i64, ptr %p575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld576, ptr %slot109, align 8
  %v577 = load i64, ptr %slot109, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ret579 = load { i64, i64 }, ptr %p578, align 8
  ret { i64, i64 } %ret579
bb_i40:
  %v580 = load i64, ptr %slot23, align 8
  store i64 %v580, ptr %slot110, align 8
  %v581 = load i64, ptr %slot110, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i32 0, ptr %p582, align 4, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot110, align 8
  %v584 = load i64, ptr %slot11, align 8
  %p585 = inttoptr i64 %v584 to ptr
  store i64 %v583, ptr %p585, align 8, !alias.scope !3, !noalias !4
  %v586 = load i64, ptr %slot11, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %ld588 = load i64, ptr %p587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld588, ptr %slot111, align 8
  %v589 = load i64, ptr %slot111, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ret591 = load { i64, i64 }, ptr %p590, align 8
  ret { i64, i64 } %ret591
bb_i42:
  %v592 = load i64, ptr %slot24, align 8
  store i64 %v592, ptr %slot112, align 8
  %v593 = load i64, ptr %slot112, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i32 0, ptr %p594, align 4, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot112, align 8
  %v596 = load i64, ptr %slot11, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i64 %v595, ptr %p597, align 8, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot11, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i64, ptr %p599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld600, ptr %slot113, align 8
  %v601 = load i64, ptr %slot113, align 8
  %p602 = inttoptr i64 %v601 to ptr
  %ret603 = load { i64, i64 }, ptr %p602, align 8
  ret { i64, i64 } %ret603
bb_i44:
  %v604 = load i64, ptr %slot25, align 8
  store i64 %v604, ptr %slot114, align 8
  %v605 = load i64, ptr %slot114, align 8
  %p606 = inttoptr i64 %v605 to ptr
  store i32 0, ptr %p606, align 4, !alias.scope !3, !noalias !4
  %v607 = load i64, ptr %slot114, align 8
  %v608 = load i64, ptr %slot11, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i64 %v607, ptr %p609, align 8, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot11, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i64, ptr %p611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld612, ptr %slot115, align 8
  %v613 = load i64, ptr %slot115, align 8
  %p614 = inttoptr i64 %v613 to ptr
  %ret615 = load { i64, i64 }, ptr %p614, align 8
  ret { i64, i64 } %ret615
bb_i46:
  %v616 = load i64, ptr %slot26, align 8
  store i64 %v616, ptr %slot116, align 8
  %v617 = load i64, ptr %slot116, align 8
  %p618 = inttoptr i64 %v617 to ptr
  store i32 0, ptr %p618, align 4, !alias.scope !3, !noalias !4
  %v619 = load i64, ptr %slot116, align 8
  %v620 = load i64, ptr %slot11, align 8
  %p621 = inttoptr i64 %v620 to ptr
  store i64 %v619, ptr %p621, align 8, !alias.scope !3, !noalias !4
  %v622 = load i64, ptr %slot11, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %ld624 = load i64, ptr %p623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld624, ptr %slot117, align 8
  %v625 = load i64, ptr %slot117, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ret627 = load { i64, i64 }, ptr %p626, align 8
  ret { i64, i64 } %ret627
bb_failure:
  %v628 = load i64, ptr %slot5, align 8
  %p629 = inttoptr i64 %v628 to ptr
  call void @llvm.memset.p0.i64(ptr %p629, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v630 = load i64, ptr %slot5, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ret632 = load { i64, i64 }, ptr %p631, align 8
  ret { i64, i64 } %ret632
bb_entry_failure:
  %v633 = load i64, ptr %slot5, align 8
  %p634 = inttoptr i64 %v633 to ptr
  call void @llvm.memset.p0.i64(ptr %p634, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v635 = load i64, ptr %slot5, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ret637 = load { i64, i64 }, ptr %p636, align 8
  ret { i64, i64 } %ret637
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_690c75f45428516b3ec0bdb8ee8a81e39a36557931bad6d619ef1296aa9a4a4d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_690c75f45428516b3ec0bdb8ee8a81e39a36557931bad6d619ef1296aa9a4a4d", linkageName: "myl_f_690c75f45428516b3ec0bdb8ee8a81e39a36557931bad6d619ef1296aa9a4a4d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16953555553692525292, i64 0, !"myl_f_690c75f45428516b3ec0bdb8ee8a81e39a36557931bad6d619ef1296aa9a4a4d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!112 = !DILocation(line: 15, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!114 = !DILocation(line: 18, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!116 = !DILocation(line: 48, column: 0, scope: !117)
