target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_71ea48641dc5c777ef92140af4472fec734ec8a47d82f97f10e85322e334bbd0(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v31 = load i64, ptr %slot1, align 8
  %op32 = add i64 %v31, 32
  store i64 %op32, ptr %slot3, align 8
  %mem33 = alloca i8, i64 8, align 8
  %ptr34 = ptrtoint ptr %mem33 to i64
  store i64 %ptr34, ptr %slot4, align 8
  %mem35 = alloca i8, i64 8, align 8
  %ptr36 = ptrtoint ptr %mem35 to i64
  store i64 %ptr36, ptr %slot5, align 8
  %v37 = load i64, ptr %slot2, align 8
  %v38 = load i64, ptr %slot4, align 8
  %p39 = inttoptr i64 %v38 to ptr
  store i64 %v37, ptr %p39, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v40 = load i64, ptr %slot4, align 8
  %p41 = inttoptr i64 %v40 to ptr
  %ld42 = load i64, ptr %p41, align 8, !alias.scope !3, !noalias !4
  store i64 %ld42, ptr %slot6, align 8
  %v43 = load i64, ptr %slot6, align 8
  %v44 = load i64, ptr %slot5, align 8
  %p45 = inttoptr i64 %v44 to ptr
  store i64 %v43, ptr %p45, align 8, !alias.scope !3, !noalias !4
  %v46 = load i64, ptr %slot5, align 8
  %p47 = inttoptr i64 %v46 to ptr
  %ld48 = load i64, ptr %p47, align 8, !alias.scope !3, !noalias !4
  store i64 %ld48, ptr %slot7, align 8
  %v49 = load i64, ptr %slot7, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ld51 = load i32, ptr %p50, align 4, !alias.scope !4, !noalias !3
  %ext52 = zext i32 %ld51 to i64
  store i64 %ext52, ptr %slot8, align 8
  %v53 = load i64, ptr %slot8, align 8
  %cmp54 = icmp eq i64 %v53, 0
  %cv55 = zext i1 %cmp54 to i64
  store i64 %cv55, ptr %slot9, align 8
  %v56 = load i64, ptr %slot9, align 8
  %cond57 = icmp ne i64 %v56, 0
  br i1 %cond57, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i2
bb_armnext3:
  %v58 = load i64, ptr %slot8, align 8
  %cmp59 = icmp eq i64 %v58, 1
  %cv60 = zext i1 %cmp59 to i64
  store i64 %cv60, ptr %slot10, align 8
  %v61 = load i64, ptr %slot10, align 8
  %cond62 = icmp ne i64 %v61, 0
  br i1 %cond62, label %bb_arm4, label %bb_armnext4
bb_arm4:
  br label %bb_i4
bb_armnext4:
  %v63 = load i64, ptr %slot8, align 8
  %cmp64 = icmp eq i64 %v63, 2
  %cv65 = zext i1 %cmp64 to i64
  store i64 %cv65, ptr %slot11, align 8
  %v66 = load i64, ptr %slot11, align 8
  %cond67 = icmp ne i64 %v66, 0
  br i1 %cond67, label %bb_arm5, label %bb_armnext5
bb_arm5:
  br label %bb_i6
bb_armnext5:
  %v68 = load i64, ptr %slot8, align 8
  %cmp69 = icmp eq i64 %v68, 3
  %cv70 = zext i1 %cmp69 to i64
  store i64 %cv70, ptr %slot12, align 8
  %v71 = load i64, ptr %slot12, align 8
  %cond72 = icmp ne i64 %v71, 0
  br i1 %cond72, label %bb_arm6, label %bb_armnext6
bb_arm6:
  br label %bb_i8
bb_armnext6:
  %v73 = load i64, ptr %slot8, align 8
  %cmp74 = icmp eq i64 %v73, 4
  %cv75 = zext i1 %cmp74 to i64
  store i64 %cv75, ptr %slot13, align 8
  %v76 = load i64, ptr %slot13, align 8
  %cond77 = icmp ne i64 %v76, 0
  br i1 %cond77, label %bb_arm7, label %bb_armnext7
bb_arm7:
  br label %bb_i10
bb_armnext7:
  %v78 = load i64, ptr %slot8, align 8
  %cmp79 = icmp eq i64 %v78, 5
  %cv80 = zext i1 %cmp79 to i64
  store i64 %cv80, ptr %slot14, align 8
  %v81 = load i64, ptr %slot14, align 8
  %cond82 = icmp ne i64 %v81, 0
  br i1 %cond82, label %bb_arm8, label %bb_armnext8
bb_arm8:
  br label %bb_i12
bb_armnext8:
  %v83 = load i64, ptr %slot8, align 8
  %cmp84 = icmp eq i64 %v83, 6
  %cv85 = zext i1 %cmp84 to i64
  store i64 %cv85, ptr %slot15, align 8
  %v86 = load i64, ptr %slot15, align 8
  %cond87 = icmp ne i64 %v86, 0
  br i1 %cond87, label %bb_arm9, label %bb_armnext9
bb_arm9:
  br label %bb_i14
bb_armnext9:
  %v88 = load i64, ptr %slot8, align 8
  %cmp89 = icmp eq i64 %v88, 7
  %cv90 = zext i1 %cmp89 to i64
  store i64 %cv90, ptr %slot16, align 8
  %v91 = load i64, ptr %slot16, align 8
  %cond92 = icmp ne i64 %v91, 0
  br i1 %cond92, label %bb_arm10, label %bb_armnext10
bb_arm10:
  br label %bb_i16
bb_armnext10:
  %v93 = load i64, ptr %slot8, align 8
  %cmp94 = icmp eq i64 %v93, 8
  %cv95 = zext i1 %cmp94 to i64
  store i64 %cv95, ptr %slot17, align 8
  %v96 = load i64, ptr %slot17, align 8
  %cond97 = icmp ne i64 %v96, 0
  br i1 %cond97, label %bb_arm11, label %bb_armnext11
bb_arm11:
  br label %bb_i18
bb_armnext11:
  %v98 = load i64, ptr %slot8, align 8
  %cmp99 = icmp eq i64 %v98, 9
  %cv100 = zext i1 %cmp99 to i64
  store i64 %cv100, ptr %slot18, align 8
  %v101 = load i64, ptr %slot18, align 8
  %cond102 = icmp ne i64 %v101, 0
  br i1 %cond102, label %bb_arm12, label %bb_armnext12
bb_arm12:
  br label %bb_i20
bb_armnext12:
  %v103 = load i64, ptr %slot8, align 8
  %cmp104 = icmp eq i64 %v103, 10
  %cv105 = zext i1 %cmp104 to i64
  store i64 %cv105, ptr %slot19, align 8
  %v106 = load i64, ptr %slot19, align 8
  %cond107 = icmp ne i64 %v106, 0
  br i1 %cond107, label %bb_arm13, label %bb_armnext13
bb_arm13:
  br label %bb_i22
bb_armnext13:
  br label %bb_failure
bb_i2:
  %v108 = load i64, ptr %slot5, align 8
  %p109 = inttoptr i64 %v108 to ptr
  store i64 1, ptr %p109, align 8, !alias.scope !3, !noalias !4
  %v110 = load i64, ptr %slot5, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld112, ptr %slot20, align 8
  %v113 = load i64, ptr %slot20, align 8
  ret i64 %v113
bb_i4:
  %v114 = load i64, ptr %slot5, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 0, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot5, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot21, align 8
  %v119 = load i64, ptr %slot21, align 8
  ret i64 %v119
bb_i6:
  %v120 = load i64, ptr %slot5, align 8
  %p121 = inttoptr i64 %v120 to ptr
  store i64 0, ptr %p121, align 8, !alias.scope !3, !noalias !4
  %v122 = load i64, ptr %slot5, align 8
  %p123 = inttoptr i64 %v122 to ptr
  %ld124 = load i64, ptr %p123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld124, ptr %slot22, align 8
  %v125 = load i64, ptr %slot22, align 8
  ret i64 %v125
bb_i8:
  %v126 = load i64, ptr %slot5, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i64 0, ptr %p127, align 8, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot5, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i64, ptr %p129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld130, ptr %slot23, align 8
  %v131 = load i64, ptr %slot23, align 8
  ret i64 %v131
bb_i10:
  %v132 = load i64, ptr %slot5, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i64 0, ptr %p133, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot5, align 8
  %p135 = inttoptr i64 %v134 to ptr
  %ld136 = load i64, ptr %p135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld136, ptr %slot24, align 8
  %v137 = load i64, ptr %slot24, align 8
  ret i64 %v137
bb_i12:
  %v138 = load i64, ptr %slot5, align 8
  %p139 = inttoptr i64 %v138 to ptr
  store i64 0, ptr %p139, align 8, !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot5, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i64, ptr %p141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld142, ptr %slot25, align 8
  %v143 = load i64, ptr %slot25, align 8
  ret i64 %v143
bb_i14:
  %v144 = load i64, ptr %slot5, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 0, ptr %p145, align 8, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot5, align 8
  %p147 = inttoptr i64 %v146 to ptr
  %ld148 = load i64, ptr %p147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld148, ptr %slot26, align 8
  %v149 = load i64, ptr %slot26, align 8
  ret i64 %v149
bb_i16:
  %v150 = load i64, ptr %slot5, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 0, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot5, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot27, align 8
  %v155 = load i64, ptr %slot27, align 8
  ret i64 %v155
bb_i18:
  %v156 = load i64, ptr %slot5, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 0, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot5, align 8
  %p159 = inttoptr i64 %v158 to ptr
  %ld160 = load i64, ptr %p159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld160, ptr %slot28, align 8
  %v161 = load i64, ptr %slot28, align 8
  ret i64 %v161
bb_i20:
  %v162 = load i64, ptr %slot5, align 8
  %p163 = inttoptr i64 %v162 to ptr
  store i64 0, ptr %p163, align 8, !alias.scope !3, !noalias !4
  %v164 = load i64, ptr %slot5, align 8
  %p165 = inttoptr i64 %v164 to ptr
  %ld166 = load i64, ptr %p165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld166, ptr %slot29, align 8
  %v167 = load i64, ptr %slot29, align 8
  ret i64 %v167
bb_i22:
  %v168 = load i64, ptr %slot5, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i64 0, ptr %p169, align 8, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot5, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %ld172 = load i64, ptr %p171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld172, ptr %slot30, align 8
  %v173 = load i64, ptr %slot30, align 8
  ret i64 %v173
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_71ea48641dc5c777ef92140af4472fec734ec8a47d82f97f10e85322e334bbd0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_71ea48641dc5c777ef92140af4472fec734ec8a47d82f97f10e85322e334bbd0", linkageName: "myl_f_71ea48641dc5c777ef92140af4472fec734ec8a47d82f97f10e85322e334bbd0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 18366596870515053575, i64 0, !"myl_f_71ea48641dc5c777ef92140af4472fec734ec8a47d82f97f10e85322e334bbd0"}
