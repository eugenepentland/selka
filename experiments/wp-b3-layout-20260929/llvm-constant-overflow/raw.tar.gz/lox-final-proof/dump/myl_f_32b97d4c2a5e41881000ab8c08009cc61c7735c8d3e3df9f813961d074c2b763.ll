target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %callresult75 = alloca [24 x i8], align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v183 = load i64, ptr %slot1, align 8
  %op184 = add i64 %v183, 32
  store i64 %op184, ptr %slot5, align 8
  %mem185 = alloca i8, i64 24, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot6, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot7, align 8
  %mem189 = alloca i8, i64 8, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot8, align 8
  %mem191 = alloca i8, i64 8, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot9, align 8
  %mem193 = alloca i8, i64 8, align 8
  %ptr194 = ptrtoint ptr %mem193 to i64
  store i64 %ptr194, ptr %slot10, align 8
  %mem195 = alloca i8, i64 8, align 8
  %ptr196 = ptrtoint ptr %mem195 to i64
  store i64 %ptr196, ptr %slot11, align 8
  %mem197 = alloca i8, i64 8, align 8
  %ptr198 = ptrtoint ptr %mem197 to i64
  store i64 %ptr198, ptr %slot12, align 8
  %mem199 = alloca i8, i64 8, align 8
  %ptr200 = ptrtoint ptr %mem199 to i64
  store i64 %ptr200, ptr %slot13, align 8
  %mem201 = alloca i8, i64 8, align 8
  %ptr202 = ptrtoint ptr %mem201 to i64
  store i64 %ptr202, ptr %slot14, align 8
  %mem203 = alloca i8, i64 8, align 8
  %ptr204 = ptrtoint ptr %mem203 to i64
  store i64 %ptr204, ptr %slot15, align 8
  %mem205 = alloca i8, i64 8, align 8
  %ptr206 = ptrtoint ptr %mem205 to i64
  store i64 %ptr206, ptr %slot16, align 8
  %mem207 = alloca i8, i64 304, align 8
  %ptr208 = ptrtoint ptr %mem207 to i64
  store i64 %ptr208, ptr %slot17, align 8
  %mem209 = alloca i8, i64 304, align 8
  %ptr210 = ptrtoint ptr %mem209 to i64
  store i64 %ptr210, ptr %slot18, align 8
  %mem211 = alloca i8, i64 8, align 8
  %ptr212 = ptrtoint ptr %mem211 to i64
  store i64 %ptr212, ptr %slot19, align 8
  %mem213 = alloca i8, i64 8, align 8
  %ptr214 = ptrtoint ptr %mem213 to i64
  store i64 %ptr214, ptr %slot20, align 8
  %mem215 = alloca i8, i64 8, align 8
  %ptr216 = ptrtoint ptr %mem215 to i64
  store i64 %ptr216, ptr %slot21, align 8
  %mem217 = alloca i8, i64 208, align 8
  %ptr218 = ptrtoint ptr %mem217 to i64
  store i64 %ptr218, ptr %slot22, align 8
  %mem219 = alloca i8, i64 24, align 8
  %ptr220 = ptrtoint ptr %mem219 to i64
  store i64 %ptr220, ptr %slot23, align 8
  %mem221 = alloca i8, i64 208, align 8
  %ptr222 = ptrtoint ptr %mem221 to i64
  store i64 %ptr222, ptr %slot24, align 8
  %mem223 = alloca i8, i64 8, align 8
  %ptr224 = ptrtoint ptr %mem223 to i64
  store i64 %ptr224, ptr %slot25, align 8
  %mem225 = alloca i8, i64 8, align 8
  %ptr226 = ptrtoint ptr %mem225 to i64
  store i64 %ptr226, ptr %slot26, align 8
  %mem227 = alloca i8, i64 8, align 8
  %ptr228 = ptrtoint ptr %mem227 to i64
  store i64 %ptr228, ptr %slot27, align 8
  %mem229 = alloca i8, i64 8, align 8
  %ptr230 = ptrtoint ptr %mem229 to i64
  store i64 %ptr230, ptr %slot28, align 8
  %mem231 = alloca i8, i64 304, align 8
  %ptr232 = ptrtoint ptr %mem231 to i64
  store i64 %ptr232, ptr %slot29, align 8
  %mem233 = alloca i8, i64 208, align 8
  %ptr234 = ptrtoint ptr %mem233 to i64
  store i64 %ptr234, ptr %slot30, align 8
  %mem235 = alloca i8, i64 304, align 8
  %ptr236 = ptrtoint ptr %mem235 to i64
  store i64 %ptr236, ptr %slot31, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem237 = alloca i8, i64 8, align 8
  %ptr238 = ptrtoint ptr %mem237 to i64
  store i64 %ptr238, ptr %slot32, align 8
  %v239 = load i64, ptr %slot1, align 8
  %op240 = add i64 %v239, 64
  store i64 %op240, ptr %slot33, align 8
  %v241 = load i64, ptr %slot33, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !4, !noalias !3
  store i64 %ld243, ptr %slot34, align 8
  %stack244 = call ptr @llvm.stacksave()
  %stackaddr245 = ptrtoint ptr %stack244 to i64
  %v246 = load i64, ptr %slot34, align 8
  %cmp247 = icmp ult i64 %stackaddr245, %v246
  %cv248 = zext i1 %cmp247 to i64
  store i64 %cv248, ptr %slot35, align 8
  %v249 = load i64, ptr %slot35, align 8
  %cond250 = icmp ne i64 %v249, 0
  br i1 %cond250, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v251 = load i64, ptr %slot1, align 8
  %p252 = inttoptr i64 %v251 to ptr
  call void @myl_qbe_fail_frame(ptr %p252) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v253 = load i64, ptr %slot2, align 8
  %v254 = load i64, ptr %slot19, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i64 %v253, ptr %p255, align 8, !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot3, align 8
  %v257 = load i64, ptr %slot20, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i64 %v256, ptr %p258, align 8, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot4, align 8
  %v260 = load i64, ptr %slot21, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i64 %v259, ptr %p261, align 8, !alias.scope !3, !noalias !4
  %v262 = load i64, ptr %slot1, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %call264 = call ptr @myl_qbe_heap(ptr %p263) nomerge, !dbg !112
  %calladdr265 = ptrtoint ptr %call264 to i64
  store i64 %calladdr265, ptr %slot36, align 8
  %v266 = load i64, ptr %slot1, align 8
  %p267 = inttoptr i64 %v266 to ptr
  %call268 = call i64 @myl_qbe_region_mark(ptr %p267) nomerge, !dbg !112
  store i64 %call268, ptr %slot37, align 8
  %v269 = load i64, ptr %slot7, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i32 0, ptr %p270, align 4, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot8, align 8
  %p272 = inttoptr i64 %v271 to ptr
  store i32 0, ptr %p272, align 4, !alias.scope !3, !noalias !4
  %v273 = load i64, ptr %slot9, align 8
  %p274 = inttoptr i64 %v273 to ptr
  store i32 0, ptr %p274, align 4, !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot10, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i32 0, ptr %p276, align 4, !alias.scope !3, !noalias !4
  %v277 = load i64, ptr %slot11, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i32 0, ptr %p278, align 4, !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot12, align 8
  %p280 = inttoptr i64 %v279 to ptr
  store i32 0, ptr %p280, align 4, !alias.scope !3, !noalias !4
  %v281 = load i64, ptr %slot13, align 8
  %p282 = inttoptr i64 %v281 to ptr
  store i32 0, ptr %p282, align 4, !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot14, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i32 0, ptr %p284, align 4, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot15, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i32 0, ptr %p286, align 4, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot16, align 8
  %p288 = inttoptr i64 %v287 to ptr
  store i32 0, ptr %p288, align 4, !alias.scope !3, !noalias !4
  %v289 = load i64, ptr %slot8, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i32 2, ptr %p290, align 4, !alias.scope !3, !noalias !4
  %v291 = load i64, ptr %slot10, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i32 2, ptr %p292, align 4, !alias.scope !3, !noalias !4
  %v293 = load i64, ptr %slot12, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i32 2, ptr %p294, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v295 = load i64, ptr %slot19, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %ld297 = load i64, ptr %p296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld297, ptr %slot38, align 8
  %v298 = load i64, ptr %slot38, align 8
  %v299 = load i64, ptr %slot29, align 8
  %p300 = inttoptr i64 %v298 to ptr
  %p301 = inttoptr i64 %v299 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p301, ptr %p300, i64 304, i1 false), !alias.scope !10000000
  %v302 = load i64, ptr %slot29, align 8
  %v303 = load i64, ptr %slot25, align 8
  %p304 = inttoptr i64 %v303 to ptr
  store i64 %v302, ptr %p304, align 8, !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot25, align 8
  %p306 = inttoptr i64 %v305 to ptr
  %ld307 = load i64, ptr %p306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld307, ptr %slot39, align 8
  %v308 = load i64, ptr %slot39, align 8
  %op309 = add i64 %v308, 32
  store i64 %op309, ptr %slot40, align 8
  %v310 = load i64, ptr %slot40, align 8
  %v311 = load i64, ptr %slot25, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i64 %v310, ptr %p312, align 8, !alias.scope !3, !noalias !4
  %v313 = load i64, ptr %slot7, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i32, ptr %p314, align 4, !alias.scope !3, !noalias !4
  store i32 %ld315, ptr %slot41, align 8
  %v316 = load i32, ptr %slot41, align 8
  %cv317 = zext i32 %v316 to i64
  %cond318 = icmp ne i64 %cv317, 0
  br i1 %cond318, label %bb_rcslotdrop20, label %bb_rcslotdone20
bb_rcslotdrop20:
  %v319 = load i64, ptr %slot7, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 0, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot22, align 8
  store i64 %v321, ptr %slot42, align 8
  %v322 = load i64, ptr %slot8, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %ld324 = load i32, ptr %p323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld324, ptr %slot43, align 8
  %v325 = load i32, ptr %slot43, align 8
  %op326 = and i32 %v325, 28
  store i32 %op326, ptr %slot44, align 8
  %v327 = load i32, ptr %slot44, align 8
  %cv328 = zext i32 %v327 to i64
  %cond329 = icmp ne i64 %cv328, 0
  br i1 %cond329, label %bb_rcslotrole20, label %bb_rcslotowner20
bb_rcslotrole20:
  %v330 = load i64, ptr %slot36, align 8
  store i64 %v330, ptr %slot45, align 8
  %v331 = load i64, ptr %slot45, align 8
  %v332 = load i64, ptr %slot42, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v331, i64 %v332) nomerge, !dbg !114
  br label %bb_rcslotdone20
bb_rcslotowner20:
  %v333 = load i64, ptr %slot36, align 8
  store i64 %v333, ptr %slot46, align 8
  %v334 = load i64, ptr %slot46, align 8
  %v335 = load i64, ptr %slot42, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v334, i64 %v335) nomerge, !dbg !114
  br label %bb_rcslotdone20
bb_rcslotdone20:
  %v336 = load i64, ptr %slot19, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %ld338 = load i64, ptr %p337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld338, ptr %slot47, align 8
  %v339 = load i64, ptr %slot47, align 8
  %op340 = add i64 %v339, 32
  store i64 %op340, ptr %slot48, align 8
  %v341 = load i64, ptr %slot22, align 8
  store i64 %v341, ptr %slot49, align 8
  %v342 = load i64, ptr %slot48, align 8
  %v343 = load i64, ptr %slot49, align 8
  %p344 = inttoptr i64 %v342 to ptr
  %p345 = inttoptr i64 %v343 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p345, ptr %p344, i64 208, i1 false), !alias.scope !10000000
  %v346 = load i64, ptr %slot48, align 8
  %p347 = inttoptr i64 %v346 to ptr
  call void @llvm.memset.p0.i64(ptr %p347, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !114
  %v348 = load i64, ptr %slot7, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i32 1, ptr %p349, align 4, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot22, align 8
  %v351 = load i64, ptr %slot25, align 8
  %p352 = inttoptr i64 %v351 to ptr
  store i64 %v350, ptr %p352, align 8, !alias.scope !3, !noalias !4
  %v353 = load i64, ptr %slot22, align 8
  %v354 = load i64, ptr %slot26, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i64 %v353, ptr %p355, align 8, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot22, align 8
  %v357 = load i64, ptr %slot30, align 8
  %p358 = inttoptr i64 %v356 to ptr
  %p359 = inttoptr i64 %v357 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p359, ptr %p358, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot30, align 8
  %v361 = load i64, ptr %slot27, align 8
  %p362 = inttoptr i64 %v361 to ptr
  store i64 %v360, ptr %p362, align 8, !alias.scope !3, !noalias !4
  %v363 = load i64, ptr %slot27, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i64, ptr %p364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld365, ptr %slot50, align 8
  %v366 = load i64, ptr %slot50, align 8
  %op367 = add i64 %v366, 168
  store i64 %op367, ptr %slot51, align 8
  %v368 = load i64, ptr %slot51, align 8
  %p369 = inttoptr i64 %v368 to ptr
  %ld370 = load i64, ptr %p369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld370, ptr %slot52, align 8
  %v371 = load i64, ptr %slot52, align 8
  %v372 = load i64, ptr %slot27, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i64 %v371, ptr %p373, align 8, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot21, align 8
  %p375 = inttoptr i64 %v374 to ptr
  %ld376 = load i64, ptr %p375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld376, ptr %slot53, align 8
  %v377 = load i64, ptr %slot53, align 8
  %v378 = load i64, ptr %slot28, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i64 %v377, ptr %p379, align 8, !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot26, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot54, align 8
  %v383 = load i64, ptr %slot27, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot55, align 8
  %v386 = load i64, ptr %slot28, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot56, align 8
  %v389 = load i64, ptr %slot1, align 8
  %v390 = load i64, ptr %slot54, align 8
  %v391 = load i64, ptr %slot55, align 8
  %v392 = load i64, ptr %slot56, align 8
  %call393 = call i64 @myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c(i64 %v389, i64 %v390, i64 %v391, i64 %v392) nomerge, !dbg !116
  store i64 %call393, ptr %slot57, align 8
  %v394 = load i64, ptr %slot57, align 8
  %v395 = load i64, ptr %slot26, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i64 %v394, ptr %p396, align 8, !alias.scope !3, !noalias !4
  %v397 = load i64, ptr %slot25, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot58, align 8
  %v400 = load i64, ptr %slot26, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %ld402 = load i64, ptr %p401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld402, ptr %slot59, align 8
  %v403 = load i64, ptr %slot1, align 8
  %v404 = load i64, ptr %slot58, align 8
  %v405 = load i64, ptr %slot59, align 8
  %call406 = call i64 @myl_f_6fe10fdc09b87fb76dc6a5a2a43c5948fb938a942549e3f0f2e42c18a951ae5b(i64 %v403, i64 %v404, i64 %v405) nomerge, !dbg !118
  store i64 %call406, ptr %slot60, align 8
  %v407 = load i64, ptr %slot60, align 8
  %v408 = load i64, ptr %slot25, align 8
  %p409 = inttoptr i64 %v408 to ptr
  store i64 %v407, ptr %p409, align 8, !alias.scope !3, !noalias !4
  %v410 = load i64, ptr %slot13, align 8
  %p411 = inttoptr i64 %v410 to ptr
  %ld412 = load i32, ptr %p411, align 4, !alias.scope !3, !noalias !4
  store i32 %ld412, ptr %slot61, align 8
  %v413 = load i32, ptr %slot61, align 8
  %cv414 = zext i32 %v413 to i64
  %cond415 = icmp ne i64 %cv414, 0
  br i1 %cond415, label %bb_rcslotdrop62, label %bb_rcslotdone62
bb_rcslotdrop62:
  %v416 = load i64, ptr %slot13, align 8
  %p417 = inttoptr i64 %v416 to ptr
  store i32 0, ptr %p417, align 4, !alias.scope !3, !noalias !4
  %v418 = load i64, ptr %slot17, align 8
  store i64 %v418, ptr %slot62, align 8
  %v419 = load i64, ptr %slot14, align 8
  %p420 = inttoptr i64 %v419 to ptr
  %ld421 = load i32, ptr %p420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld421, ptr %slot63, align 8
  %v422 = load i32, ptr %slot63, align 8
  %op423 = and i32 %v422, 28
  store i32 %op423, ptr %slot64, align 8
  %v424 = load i32, ptr %slot64, align 8
  %cv425 = zext i32 %v424 to i64
  %cond426 = icmp ne i64 %cv425, 0
  br i1 %cond426, label %bb_rcslotrole62, label %bb_rcslotowner62
bb_rcslotrole62:
  %v427 = load i64, ptr %slot36, align 8
  store i64 %v427, ptr %slot65, align 8
  %v428 = load i64, ptr %slot65, align 8
  %v429 = load i64, ptr %slot62, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v428, i64 %v429) nomerge, !dbg !118
  br label %bb_rcslotdone62
bb_rcslotowner62:
  %v430 = load i64, ptr %slot36, align 8
  store i64 %v430, ptr %slot66, align 8
  %v431 = load i64, ptr %slot66, align 8
  %v432 = load i64, ptr %slot62, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v431, i64 %v432) nomerge, !dbg !118
  br label %bb_rcslotdone62
bb_rcslotdone62:
  %v433 = load i64, ptr %slot19, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %ld435 = load i64, ptr %p434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld435, ptr %slot67, align 8
  %v436 = load i64, ptr %slot67, align 8
  %op437 = add i64 %v436, 32
  store i64 %op437, ptr %slot68, align 8
  %v438 = load i64, ptr %slot22, align 8
  store i64 %v438, ptr %slot69, align 8
  %v439 = load i64, ptr %slot69, align 8
  %v440 = load i64, ptr %slot68, align 8
  %p441 = inttoptr i64 %v439 to ptr
  %p442 = inttoptr i64 %v440 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p442, ptr %p441, i64 208, i1 false), !alias.scope !10000000
  %v443 = load i64, ptr %slot69, align 8
  %p444 = inttoptr i64 %v443 to ptr
  call void @llvm.memset.p0.i64(ptr %p444, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v445 = load i64, ptr %slot7, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i32 0, ptr %p446, align 4, !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot25, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i64 0, ptr %p448, align 8, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot19, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %ld451 = load i64, ptr %p450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld451, ptr %slot70, align 8
  %v452 = load i64, ptr %slot70, align 8
  %v453 = load i64, ptr %slot25, align 8
  %p454 = inttoptr i64 %v453 to ptr
  store i64 %v452, ptr %p454, align 8, !alias.scope !3, !noalias !4
  %v455 = load i64, ptr %slot20, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %ld457 = load i64, ptr %p456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld457, ptr %slot71, align 8
  %v458 = load i64, ptr %slot71, align 8
  %v459 = load i64, ptr %slot26, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i64 %v458, ptr %p460, align 8, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot25, align 8
  %p462 = inttoptr i64 %v461 to ptr
  %ld463 = load i64, ptr %p462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld463, ptr %slot72, align 8
  %v464 = load i64, ptr %slot26, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i64, ptr %p465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld466, ptr %slot73, align 8
  %v467 = load i64, ptr %slot1, align 8
  %v468 = load i64, ptr %slot72, align 8
  %v469 = load i64, ptr %slot73, align 8
  call void @myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788(ptr sret([24 x i8]) align 8 %callresult75, i64 %v467, i64 %v468, i64 %v469) nomerge, !dbg !122
  %addr470 = ptrtoint ptr %callresult75 to i64
  store i64 %addr470, ptr %slot74, align 8
  %v471 = load i64, ptr %slot74, align 8
  %v472 = load i64, ptr %slot25, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i64 %v471, ptr %p473, align 8, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot25, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld476, ptr %slot76, align 8
  %v477 = load i64, ptr %slot18, align 8
  store i64 %v477, ptr %slot77, align 8
  %v478 = load i64, ptr %slot76, align 8
  %v479 = load i64, ptr %slot77, align 8
  %p480 = inttoptr i64 %v478 to ptr
  %p481 = inttoptr i64 %v479 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p481, ptr %p480, i64 24, i1 false)
  %v482 = load i64, ptr %slot16, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 2, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot15, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 1, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot13, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %ld488 = load i32, ptr %p487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld488, ptr %slot78, align 8
  %v489 = load i32, ptr %slot78, align 8
  %cv490 = zext i32 %v489 to i64
  %cond491 = icmp ne i64 %cv490, 0
  br i1 %cond491, label %bb_rcslotdrop84, label %bb_rcslotdone84
bb_rcslotdrop84:
  %v492 = load i64, ptr %slot13, align 8
  %p493 = inttoptr i64 %v492 to ptr
  store i32 0, ptr %p493, align 4, !alias.scope !3, !noalias !4
  %v494 = load i64, ptr %slot17, align 8
  store i64 %v494, ptr %slot79, align 8
  %v495 = load i64, ptr %slot14, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %ld497 = load i32, ptr %p496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld497, ptr %slot80, align 8
  %v498 = load i32, ptr %slot80, align 8
  %op499 = and i32 %v498, 28
  store i32 %op499, ptr %slot81, align 8
  %v500 = load i32, ptr %slot81, align 8
  %cv501 = zext i32 %v500 to i64
  %cond502 = icmp ne i64 %cv501, 0
  br i1 %cond502, label %bb_rcslotrole84, label %bb_rcslotowner84
bb_rcslotrole84:
  %v503 = load i64, ptr %slot36, align 8
  store i64 %v503, ptr %slot82, align 8
  %v504 = load i64, ptr %slot82, align 8
  %v505 = load i64, ptr %slot79, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v504, i64 %v505) nomerge, !dbg !122
  br label %bb_rcslotdone84
bb_rcslotowner84:
  %v506 = load i64, ptr %slot36, align 8
  store i64 %v506, ptr %slot83, align 8
  %v507 = load i64, ptr %slot83, align 8
  %v508 = load i64, ptr %slot79, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v507, i64 %v508) nomerge, !dbg !122
  br label %bb_rcslotdone84
bb_rcslotdone84:
  %v509 = load i64, ptr %slot17, align 8
  store i64 %v509, ptr %slot84, align 8
  %v510 = load i64, ptr %slot18, align 8
  store i64 %v510, ptr %slot85, align 8
  %v511 = load i64, ptr %slot85, align 8
  %v512 = load i64, ptr %slot84, align 8
  %p513 = inttoptr i64 %v511 to ptr
  %p514 = inttoptr i64 %v512 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p514, ptr %p513, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v515 = load i64, ptr %slot14, align 8
  %p516 = inttoptr i64 %v515 to ptr
  store i32 2, ptr %p516, align 4, !alias.scope !3, !noalias !4
  %v517 = load i64, ptr %slot16, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ld519 = load i32, ptr %p518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld519, ptr %slot86, align 8
  %v520 = load i32, ptr %slot86, align 8
  %v521 = load i64, ptr %slot14, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i32 %v520, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot15, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 0, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot13, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 1, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %v527 = load i64, ptr %slot84, align 8
  %v528 = load i64, ptr %slot25, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i64 %v527, ptr %p529, align 8, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot25, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot87, align 8
  %v533 = load i64, ptr %slot18, align 8
  store i64 %v533, ptr %slot88, align 8
  %v534 = load i64, ptr %slot37, align 8
  store i64 %v534, ptr %slot89, align 8
  %v535 = load i64, ptr %slot36, align 8
  %v536 = load i64, ptr %slot88, align 8
  %v537 = load i64, ptr %slot87, align 8
  %v538 = load i64, ptr %slot89, align 8
  %cv539 = trunc i64 %v538 to i32
  %call540 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v535, i64 %v536, i64 %v537, i32 %cv539) nomerge, !dbg !124
  store i32 %call540, ptr %slot90, align 8
  %v541 = load i32, ptr %slot90, align 8
  %cv542 = zext i32 %v541 to i64
  %cond543 = icmp ne i64 %cv542, 0
  br i1 %cond543, label %bb_rcsuccess103, label %bb_rcfailure103
bb_rcfailure103:
  %v544 = load i64, ptr %slot36, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %call546 = call i32 @myl_rc_take_failure(ptr %p545) nomerge, !dbg !124
  store i32 %call546, ptr %slot91, align 8
  %v547 = load i64, ptr %slot1, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %v549 = load i32, ptr %slot91, align 8
  %call550 = call i32 @myl_qbe_rc_status(ptr %p548, i32 %v549) nomerge, !dbg !124
  store i32 %call550, ptr %slot92, align 8
  br label %bb_failure
bb_rcsuccess103:
  %v551 = load i64, ptr %slot13, align 8
  %p552 = inttoptr i64 %v551 to ptr
  store i32 0, ptr %p552, align 4, !alias.scope !3, !noalias !4
  %v553 = load i64, ptr %slot16, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i32 2, ptr %p554, align 4, !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot15, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i32 1, ptr %p556, align 4, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot9, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i32, ptr %p558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld559, ptr %slot93, align 8
  %v560 = load i32, ptr %slot93, align 8
  %cv561 = zext i32 %v560 to i64
  %cond562 = icmp ne i64 %cv561, 0
  br i1 %cond562, label %bb_rcslotdrop112, label %bb_rcslotdone112
bb_rcslotdrop112:
  %v563 = load i64, ptr %slot9, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 0, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot23, align 8
  store i64 %v565, ptr %slot94, align 8
  %v566 = load i64, ptr %slot10, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i32, ptr %p567, align 4, !alias.scope !3, !noalias !4
  store i32 %ld568, ptr %slot95, align 8
  %v569 = load i32, ptr %slot95, align 8
  %op570 = and i32 %v569, 28
  store i32 %op570, ptr %slot96, align 8
  %v571 = load i32, ptr %slot96, align 8
  %cv572 = zext i32 %v571 to i64
  %cond573 = icmp ne i64 %cv572, 0
  br i1 %cond573, label %bb_rcslotrole112, label %bb_rcslotowner112
bb_rcslotrole112:
  %v574 = load i64, ptr %slot36, align 8
  store i64 %v574, ptr %slot97, align 8
  %v575 = load i64, ptr %slot97, align 8
  %v576 = load i64, ptr %slot94, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v575, i64 %v576) nomerge, !dbg !124
  br label %bb_rcslotdone112
bb_rcslotowner112:
  %v577 = load i64, ptr %slot36, align 8
  store i64 %v577, ptr %slot98, align 8
  %v578 = load i64, ptr %slot98, align 8
  %v579 = load i64, ptr %slot94, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v578, i64 %v579) nomerge, !dbg !124
  br label %bb_rcslotdone112
bb_rcslotdone112:
  %v580 = load i64, ptr %slot23, align 8
  store i64 %v580, ptr %slot99, align 8
  %v581 = load i64, ptr %slot18, align 8
  store i64 %v581, ptr %slot100, align 8
  %v582 = load i64, ptr %slot100, align 8
  %v583 = load i64, ptr %slot99, align 8
  %p584 = inttoptr i64 %v582 to ptr
  %p585 = inttoptr i64 %v583 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p585, ptr %p584, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v586 = load i64, ptr %slot15, align 8
  %p587 = inttoptr i64 %v586 to ptr
  store i32 0, ptr %p587, align 4, !alias.scope !3, !noalias !4
  %v588 = load i64, ptr %slot10, align 8
  %p589 = inttoptr i64 %v588 to ptr
  store i32 2, ptr %p589, align 4, !alias.scope !3, !noalias !4
  %v590 = load i64, ptr %slot16, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %ld592 = load i32, ptr %p591, align 4, !alias.scope !3, !noalias !4
  store i32 %ld592, ptr %slot101, align 8
  %v593 = load i32, ptr %slot101, align 8
  %v594 = load i64, ptr %slot10, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i32 %v593, ptr %p595, align 4, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot9, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i32 1, ptr %p597, align 4, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot19, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i64, ptr %p599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld600, ptr %slot102, align 8
  %v601 = load i64, ptr %slot102, align 8
  %v602 = load i64, ptr %slot31, align 8
  %p603 = inttoptr i64 %v601 to ptr
  %p604 = inttoptr i64 %v602 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p604, ptr %p603, i64 304, i1 false), !alias.scope !10000000
  %v605 = load i64, ptr %slot31, align 8
  %v606 = load i64, ptr %slot25, align 8
  %p607 = inttoptr i64 %v606 to ptr
  store i64 %v605, ptr %p607, align 8, !alias.scope !3, !noalias !4
  %v608 = load i64, ptr %slot25, align 8
  %p609 = inttoptr i64 %v608 to ptr
  %ld610 = load i64, ptr %p609, align 8, !alias.scope !3, !noalias !4
  store i64 %ld610, ptr %slot103, align 8
  %v611 = load i64, ptr %slot103, align 8
  %op612 = add i64 %v611, 32
  store i64 %op612, ptr %slot104, align 8
  %v613 = load i64, ptr %slot104, align 8
  %v614 = load i64, ptr %slot25, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i64 %v613, ptr %p615, align 8, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot11, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i32, ptr %p617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld618, ptr %slot105, align 8
  %v619 = load i32, ptr %slot105, align 8
  %cv620 = zext i32 %v619 to i64
  %cond621 = icmp ne i64 %cv620, 0
  br i1 %cond621, label %bb_rcslotdrop131, label %bb_rcslotdone131
bb_rcslotdrop131:
  %v622 = load i64, ptr %slot11, align 8
  %p623 = inttoptr i64 %v622 to ptr
  store i32 0, ptr %p623, align 4, !alias.scope !3, !noalias !4
  %v624 = load i64, ptr %slot24, align 8
  store i64 %v624, ptr %slot106, align 8
  %v625 = load i64, ptr %slot12, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ld627 = load i32, ptr %p626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld627, ptr %slot107, align 8
  %v628 = load i32, ptr %slot107, align 8
  %op629 = and i32 %v628, 28
  store i32 %op629, ptr %slot108, align 8
  %v630 = load i32, ptr %slot108, align 8
  %cv631 = zext i32 %v630 to i64
  %cond632 = icmp ne i64 %cv631, 0
  br i1 %cond632, label %bb_rcslotrole131, label %bb_rcslotowner131
bb_rcslotrole131:
  %v633 = load i64, ptr %slot36, align 8
  store i64 %v633, ptr %slot109, align 8
  %v634 = load i64, ptr %slot109, align 8
  %v635 = load i64, ptr %slot106, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v634, i64 %v635) nomerge, !dbg !126
  br label %bb_rcslotdone131
bb_rcslotowner131:
  %v636 = load i64, ptr %slot36, align 8
  store i64 %v636, ptr %slot110, align 8
  %v637 = load i64, ptr %slot110, align 8
  %v638 = load i64, ptr %slot106, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v637, i64 %v638) nomerge, !dbg !126
  br label %bb_rcslotdone131
bb_rcslotdone131:
  %v639 = load i64, ptr %slot19, align 8
  %p640 = inttoptr i64 %v639 to ptr
  %ld641 = load i64, ptr %p640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld641, ptr %slot111, align 8
  %v642 = load i64, ptr %slot111, align 8
  %op643 = add i64 %v642, 32
  store i64 %op643, ptr %slot112, align 8
  %v644 = load i64, ptr %slot24, align 8
  store i64 %v644, ptr %slot113, align 8
  %v645 = load i64, ptr %slot112, align 8
  %v646 = load i64, ptr %slot113, align 8
  %p647 = inttoptr i64 %v645 to ptr
  %p648 = inttoptr i64 %v646 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p648, ptr %p647, i64 208, i1 false), !alias.scope !10000000
  %v649 = load i64, ptr %slot112, align 8
  %p650 = inttoptr i64 %v649 to ptr
  call void @llvm.memset.p0.i64(ptr %p650, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !126
  %v651 = load i64, ptr %slot11, align 8
  %p652 = inttoptr i64 %v651 to ptr
  store i32 1, ptr %p652, align 4, !alias.scope !3, !noalias !4
  %v653 = load i64, ptr %slot24, align 8
  %v654 = load i64, ptr %slot25, align 8
  %p655 = inttoptr i64 %v654 to ptr
  store i64 %v653, ptr %p655, align 8, !alias.scope !3, !noalias !4
  %v656 = load i64, ptr %slot25, align 8
  %p657 = inttoptr i64 %v656 to ptr
  %ld658 = load i64, ptr %p657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld658, ptr %slot114, align 8
  %v659 = load i64, ptr %slot1, align 8
  %v660 = load i64, ptr %slot114, align 8
  %call661 = call i64 @myl_f_448f060fb6f29ea6a9164d3fd28db134abf5c67c6d4955b6c7d5a3d5aa27f16e(i64 %v659, i64 %v660) nomerge, !dbg !128
  store i64 %call661, ptr %slot115, align 8
  %v662 = load i64, ptr %slot115, align 8
  %v663 = load i64, ptr %slot25, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i64 %v662, ptr %p664, align 8, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot13, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %ld667 = load i32, ptr %p666, align 4, !alias.scope !3, !noalias !4
  store i32 %ld667, ptr %slot116, align 8
  %v668 = load i32, ptr %slot116, align 8
  %cv669 = zext i32 %v668 to i64
  %cond670 = icmp ne i64 %cv669, 0
  br i1 %cond670, label %bb_rcslotdrop146, label %bb_rcslotdone146
bb_rcslotdrop146:
  %v671 = load i64, ptr %slot13, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i32 0, ptr %p672, align 4, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot17, align 8
  store i64 %v673, ptr %slot117, align 8
  %v674 = load i64, ptr %slot14, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %ld676 = load i32, ptr %p675, align 4, !alias.scope !3, !noalias !4
  store i32 %ld676, ptr %slot118, align 8
  %v677 = load i32, ptr %slot118, align 8
  %op678 = and i32 %v677, 28
  store i32 %op678, ptr %slot119, align 8
  %v679 = load i32, ptr %slot119, align 8
  %cv680 = zext i32 %v679 to i64
  %cond681 = icmp ne i64 %cv680, 0
  br i1 %cond681, label %bb_rcslotrole146, label %bb_rcslotowner146
bb_rcslotrole146:
  %v682 = load i64, ptr %slot36, align 8
  store i64 %v682, ptr %slot120, align 8
  %v683 = load i64, ptr %slot120, align 8
  %v684 = load i64, ptr %slot117, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v683, i64 %v684) nomerge, !dbg !128
  br label %bb_rcslotdone146
bb_rcslotowner146:
  %v685 = load i64, ptr %slot36, align 8
  store i64 %v685, ptr %slot121, align 8
  %v686 = load i64, ptr %slot121, align 8
  %v687 = load i64, ptr %slot117, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v686, i64 %v687) nomerge, !dbg !128
  br label %bb_rcslotdone146
bb_rcslotdone146:
  %v688 = load i64, ptr %slot19, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot122, align 8
  %v691 = load i64, ptr %slot122, align 8
  %op692 = add i64 %v691, 32
  store i64 %op692, ptr %slot123, align 8
  %v693 = load i64, ptr %slot24, align 8
  store i64 %v693, ptr %slot124, align 8
  %v694 = load i64, ptr %slot124, align 8
  %v695 = load i64, ptr %slot123, align 8
  %p696 = inttoptr i64 %v694 to ptr
  %p697 = inttoptr i64 %v695 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p697, ptr %p696, i64 208, i1 false), !alias.scope !10000000
  %v698 = load i64, ptr %slot124, align 8
  %p699 = inttoptr i64 %v698 to ptr
  call void @llvm.memset.p0.i64(ptr %p699, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !130
  %v700 = load i64, ptr %slot11, align 8
  %p701 = inttoptr i64 %v700 to ptr
  store i32 0, ptr %p701, align 4, !alias.scope !3, !noalias !4
  %v702 = load i64, ptr %slot25, align 8
  %p703 = inttoptr i64 %v702 to ptr
  store i64 0, ptr %p703, align 8, !alias.scope !3, !noalias !4
  %v704 = load i64, ptr %slot23, align 8
  store i64 %v704, ptr %slot125, align 8
  %v705 = load i64, ptr %slot9, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %ld707 = load i32, ptr %p706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld707, ptr %slot126, align 8
  %v708 = load i64, ptr %slot10, align 8
  %p709 = inttoptr i64 %v708 to ptr
  %ld710 = load i32, ptr %p709, align 4, !alias.scope !3, !noalias !4
  store i32 %ld710, ptr %slot127, align 8
  %v711 = load i32, ptr %slot127, align 8
  %op712 = and i32 %v711, 24
  store i32 %op712, ptr %slot127, align 8
  %v713 = load i32, ptr %slot127, align 8
  %cmp714 = icmp eq i32 %v713, 0
  %cv715 = zext i1 %cmp714 to i32
  store i32 %cv715, ptr %slot128, align 8
  %v716 = load i32, ptr %slot126, align 8
  %v717 = load i32, ptr %slot128, align 8
  %op718 = and i32 %v716, %v717
  store i32 %op718, ptr %slot129, align 8
  %v719 = load i32, ptr %slot129, align 8
  %cv720 = zext i32 %v719 to i64
  %cond721 = icmp ne i64 %cv720, 0
  br i1 %cond721, label %bb_rctake158, label %bb_rccopy158
bb_rctake158:
  %v722 = load i64, ptr %slot18, align 8
  store i64 %v722, ptr %slot130, align 8
  %v723 = load i64, ptr %slot37, align 8
  store i64 %v723, ptr %slot131, align 8
  %v724 = load i64, ptr %slot36, align 8
  %v725 = load i64, ptr %slot130, align 8
  %v726 = load i64, ptr %slot125, align 8
  %v727 = load i64, ptr %slot131, align 8
  %cv728 = trunc i64 %v727 to i32
  %call729 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v724, i64 %v725, i64 %v726, i32 %cv728) nomerge, !dbg !132
  store i32 %call729, ptr %slot132, align 8
  %v730 = load i32, ptr %slot132, align 8
  %cv731 = zext i32 %v730 to i64
  %cond732 = icmp ne i64 %cv731, 0
  br i1 %cond732, label %bb_rcsuccess168, label %bb_rcfailure168
bb_rcfailure168:
  %v733 = load i64, ptr %slot36, align 8
  %p734 = inttoptr i64 %v733 to ptr
  %call735 = call i32 @myl_rc_take_failure(ptr %p734) nomerge, !dbg !132
  store i32 %call735, ptr %slot133, align 8
  %v736 = load i64, ptr %slot1, align 8
  %p737 = inttoptr i64 %v736 to ptr
  %v738 = load i32, ptr %slot133, align 8
  %call739 = call i32 @myl_qbe_rc_status(ptr %p737, i32 %v738) nomerge, !dbg !132
  store i32 %call739, ptr %slot134, align 8
  br label %bb_failure
bb_rcsuccess168:
  %v740 = load i64, ptr %slot9, align 8
  %p741 = inttoptr i64 %v740 to ptr
  store i32 0, ptr %p741, align 4, !alias.scope !3, !noalias !4
  %v742 = load i64, ptr %slot16, align 8
  %p743 = inttoptr i64 %v742 to ptr
  store i32 2, ptr %p743, align 4, !alias.scope !3, !noalias !4
  %v744 = load i64, ptr %slot15, align 8
  %p745 = inttoptr i64 %v744 to ptr
  store i32 1, ptr %p745, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared158
bb_rccopy158:
  %v746 = load i64, ptr %slot18, align 8
  store i64 %v746, ptr %slot135, align 8
  %v747 = load i64, ptr %slot37, align 8
  store i64 %v747, ptr %slot136, align 8
  %v748 = load i64, ptr %slot36, align 8
  %v749 = load i64, ptr %slot135, align 8
  %v750 = load i64, ptr %slot125, align 8
  %v751 = load i64, ptr %slot136, align 8
  %cv752 = trunc i64 %v751 to i32
  %call753 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64 %v748, i64 %v749, i64 %v750, i32 %cv752) nomerge, !dbg !132
  store i32 %call753, ptr %slot137, align 8
  %v754 = load i32, ptr %slot137, align 8
  %cv755 = zext i32 %v754 to i64
  %cond756 = icmp ne i64 %cv755, 0
  br i1 %cond756, label %bb_rcsuccess177, label %bb_rcfailure177
bb_rcfailure177:
  %v757 = load i64, ptr %slot36, align 8
  %p758 = inttoptr i64 %v757 to ptr
  %call759 = call i32 @myl_rc_take_failure(ptr %p758) nomerge, !dbg !132
  store i32 %call759, ptr %slot138, align 8
  %v760 = load i64, ptr %slot1, align 8
  %p761 = inttoptr i64 %v760 to ptr
  %v762 = load i32, ptr %slot138, align 8
  %call763 = call i32 @myl_qbe_rc_status(ptr %p761, i32 %v762) nomerge, !dbg !132
  store i32 %call763, ptr %slot139, align 8
  br label %bb_failure
bb_rcsuccess177:
  %v764 = load i64, ptr %slot16, align 8
  %p765 = inttoptr i64 %v764 to ptr
  store i32 2, ptr %p765, align 4, !alias.scope !3, !noalias !4
  %v766 = load i64, ptr %slot15, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i32 1, ptr %p767, align 4, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot9, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %ld770 = load i32, ptr %p769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld770, ptr %slot140, align 8
  %v771 = load i32, ptr %slot140, align 8
  %cv772 = zext i32 %v771 to i64
  %cond773 = icmp ne i64 %cv772, 0
  br i1 %cond773, label %bb_rcslotdrop184, label %bb_rcslotdone184
bb_rcslotdrop184:
  %v774 = load i64, ptr %slot9, align 8
  %p775 = inttoptr i64 %v774 to ptr
  store i32 0, ptr %p775, align 4, !alias.scope !3, !noalias !4
  %v776 = load i64, ptr %slot23, align 8
  store i64 %v776, ptr %slot141, align 8
  %v777 = load i64, ptr %slot10, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i32, ptr %p778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld779, ptr %slot142, align 8
  %v780 = load i32, ptr %slot142, align 8
  %op781 = and i32 %v780, 28
  store i32 %op781, ptr %slot143, align 8
  %v782 = load i32, ptr %slot143, align 8
  %cv783 = zext i32 %v782 to i64
  %cond784 = icmp ne i64 %cv783, 0
  br i1 %cond784, label %bb_rcslotrole184, label %bb_rcslotowner184
bb_rcslotrole184:
  %v785 = load i64, ptr %slot36, align 8
  store i64 %v785, ptr %slot144, align 8
  %v786 = load i64, ptr %slot144, align 8
  %v787 = load i64, ptr %slot141, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v786, i64 %v787) nomerge, !dbg !132
  br label %bb_rcslotdone184
bb_rcslotowner184:
  %v788 = load i64, ptr %slot36, align 8
  store i64 %v788, ptr %slot145, align 8
  %v789 = load i64, ptr %slot145, align 8
  %v790 = load i64, ptr %slot141, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v789, i64 %v790) nomerge, !dbg !132
  br label %bb_rcslotdone184
bb_rcslotdone184:
  br label %bb_rcprepared158
bb_rcprepared158:
  %v791 = load i64, ptr %slot17, align 8
  store i64 %v791, ptr %slot146, align 8
  %v792 = load i64, ptr %slot18, align 8
  store i64 %v792, ptr %slot147, align 8
  %v793 = load i64, ptr %slot147, align 8
  %v794 = load i64, ptr %slot146, align 8
  %p795 = inttoptr i64 %v793 to ptr
  %p796 = inttoptr i64 %v794 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p796, ptr %p795, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v797 = load i64, ptr %slot14, align 8
  %p798 = inttoptr i64 %v797 to ptr
  store i32 2, ptr %p798, align 4, !alias.scope !3, !noalias !4
  %v799 = load i64, ptr %slot16, align 8
  %p800 = inttoptr i64 %v799 to ptr
  %ld801 = load i32, ptr %p800, align 4, !alias.scope !3, !noalias !4
  store i32 %ld801, ptr %slot148, align 8
  %v802 = load i32, ptr %slot148, align 8
  %v803 = load i64, ptr %slot14, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i32 %v802, ptr %p804, align 4, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot15, align 8
  %p806 = inttoptr i64 %v805 to ptr
  store i32 0, ptr %p806, align 4, !alias.scope !3, !noalias !4
  %v807 = load i64, ptr %slot13, align 8
  %p808 = inttoptr i64 %v807 to ptr
  store i32 1, ptr %p808, align 4, !alias.scope !3, !noalias !4
  %v809 = load i64, ptr %slot146, align 8
  %v810 = load i64, ptr %slot25, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i64 %v809, ptr %p811, align 8, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot25, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i64, ptr %p813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld814, ptr %slot149, align 8
  %v815 = load i64, ptr %slot149, align 8
  %p816 = inttoptr i64 %v815 to ptr
  %ld817 = load i32, ptr %p816, align 4, !alias.scope !3, !noalias !4
  %ext818 = zext i32 %ld817 to i64
  store i64 %ext818, ptr %slot150, align 8
  %v819 = load i64, ptr %slot150, align 8
  %cmp820 = icmp eq i64 %v819, 1
  %cv821 = zext i1 %cmp820 to i64
  store i64 %cv821, ptr %slot151, align 8
  %v822 = load i64, ptr %slot151, align 8
  %cond823 = icmp ne i64 %v822, 0
  br i1 %cond823, label %bb_errtrace201, label %bb_errtraced201
bb_errtrace201:
  %p824 = inttoptr i64 ptrtoint (ptr @myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p824, i64 8589934642) "call-inline-cost"="0", !dbg !134
  br label %bb_errtraced201
bb_errtraced201:
  %v825 = load i64, ptr %slot25, align 8
  %p826 = inttoptr i64 %v825 to ptr
  %ld827 = load i64, ptr %p826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld827, ptr %slot152, align 8
  %v828 = load i64, ptr %slot18, align 8
  store i64 %v828, ptr %slot153, align 8
  %v829 = load i64, ptr %slot37, align 8
  store i64 %v829, ptr %slot154, align 8
  %v830 = load i64, ptr %slot36, align 8
  %v831 = load i64, ptr %slot153, align 8
  %v832 = load i64, ptr %slot152, align 8
  %v833 = load i64, ptr %slot154, align 8
  %cv834 = trunc i64 %v833 to i32
  %call835 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v830, i64 %v831, i64 %v832, i32 %cv834) nomerge, !dbg !134
  store i32 %call835, ptr %slot155, align 8
  %v836 = load i32, ptr %slot155, align 8
  %cv837 = zext i32 %v836 to i64
  %cond838 = icmp ne i64 %cv837, 0
  br i1 %cond838, label %bb_rcsuccess206, label %bb_rcfailure206
bb_rcfailure206:
  %v839 = load i64, ptr %slot36, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %call841 = call i32 @myl_rc_take_failure(ptr %p840) nomerge, !dbg !134
  store i32 %call841, ptr %slot156, align 8
  %v842 = load i64, ptr %slot1, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %v844 = load i32, ptr %slot156, align 8
  %call845 = call i32 @myl_qbe_rc_status(ptr %p843, i32 %v844) nomerge, !dbg !134
  store i32 %call845, ptr %slot157, align 8
  br label %bb_failure
bb_rcsuccess206:
  %v846 = load i64, ptr %slot13, align 8
  %p847 = inttoptr i64 %v846 to ptr
  store i32 0, ptr %p847, align 4, !alias.scope !3, !noalias !4
  %v848 = load i64, ptr %slot16, align 8
  %p849 = inttoptr i64 %v848 to ptr
  store i32 2, ptr %p849, align 4, !alias.scope !3, !noalias !4
  %v850 = load i64, ptr %slot15, align 8
  %p851 = inttoptr i64 %v850 to ptr
  store i32 1, ptr %p851, align 4, !alias.scope !3, !noalias !4
  %v852 = load i64, ptr %slot18, align 8
  store i64 %v852, ptr %slot158, align 8
  %v853 = load i64, ptr %slot15, align 8
  %p854 = inttoptr i64 %v853 to ptr
  store i32 0, ptr %p854, align 4, !alias.scope !3, !noalias !4
  %v855 = load i64, ptr %slot13, align 8
  %p856 = inttoptr i64 %v855 to ptr
  %ld857 = load i32, ptr %p856, align 4, !alias.scope !3, !noalias !4
  store i32 %ld857, ptr %slot159, align 8
  %v858 = load i32, ptr %slot159, align 8
  %cv859 = zext i32 %v858 to i64
  %cond860 = icmp ne i64 %cv859, 0
  br i1 %cond860, label %bb_rcslotdrop216, label %bb_rcslotdone216
bb_rcslotdrop216:
  %v861 = load i64, ptr %slot13, align 8
  %p862 = inttoptr i64 %v861 to ptr
  store i32 0, ptr %p862, align 4, !alias.scope !3, !noalias !4
  %v863 = load i64, ptr %slot17, align 8
  store i64 %v863, ptr %slot160, align 8
  %v864 = load i64, ptr %slot14, align 8
  %p865 = inttoptr i64 %v864 to ptr
  %ld866 = load i32, ptr %p865, align 4, !alias.scope !3, !noalias !4
  store i32 %ld866, ptr %slot161, align 8
  %v867 = load i32, ptr %slot161, align 8
  %op868 = and i32 %v867, 28
  store i32 %op868, ptr %slot162, align 8
  %v869 = load i32, ptr %slot162, align 8
  %cv870 = zext i32 %v869 to i64
  %cond871 = icmp ne i64 %cv870, 0
  br i1 %cond871, label %bb_rcslotrole216, label %bb_rcslotowner216
bb_rcslotrole216:
  %v872 = load i64, ptr %slot36, align 8
  store i64 %v872, ptr %slot163, align 8
  %v873 = load i64, ptr %slot163, align 8
  %v874 = load i64, ptr %slot160, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v873, i64 %v874) nomerge, !dbg !134
  br label %bb_rcslotdone216
bb_rcslotowner216:
  %v875 = load i64, ptr %slot36, align 8
  store i64 %v875, ptr %slot164, align 8
  %v876 = load i64, ptr %slot164, align 8
  %v877 = load i64, ptr %slot160, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v876, i64 %v877) nomerge, !dbg !134
  br label %bb_rcslotdone216
bb_rcslotdone216:
  %v878 = load i64, ptr %slot11, align 8
  %p879 = inttoptr i64 %v878 to ptr
  %ld880 = load i32, ptr %p879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld880, ptr %slot165, align 8
  %v881 = load i32, ptr %slot165, align 8
  %cv882 = zext i32 %v881 to i64
  %cond883 = icmp ne i64 %cv882, 0
  br i1 %cond883, label %bb_rcslotdrop243, label %bb_rcslotdone243
bb_rcslotdrop243:
  %v884 = load i64, ptr %slot11, align 8
  %p885 = inttoptr i64 %v884 to ptr
  store i32 0, ptr %p885, align 4, !alias.scope !3, !noalias !4
  %v886 = load i64, ptr %slot24, align 8
  store i64 %v886, ptr %slot166, align 8
  %v887 = load i64, ptr %slot12, align 8
  %p888 = inttoptr i64 %v887 to ptr
  %ld889 = load i32, ptr %p888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld889, ptr %slot167, align 8
  %v890 = load i32, ptr %slot167, align 8
  %op891 = and i32 %v890, 28
  store i32 %op891, ptr %slot168, align 8
  %v892 = load i32, ptr %slot168, align 8
  %cv893 = zext i32 %v892 to i64
  %cond894 = icmp ne i64 %cv893, 0
  br i1 %cond894, label %bb_rcslotrole243, label %bb_rcslotowner243
bb_rcslotrole243:
  %v895 = load i64, ptr %slot36, align 8
  store i64 %v895, ptr %slot169, align 8
  %v896 = load i64, ptr %slot169, align 8
  %v897 = load i64, ptr %slot166, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v896, i64 %v897) nomerge, !dbg !134
  br label %bb_rcslotdone243
bb_rcslotowner243:
  %v898 = load i64, ptr %slot36, align 8
  store i64 %v898, ptr %slot170, align 8
  %v899 = load i64, ptr %slot170, align 8
  %v900 = load i64, ptr %slot166, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v899, i64 %v900) nomerge, !dbg !134
  br label %bb_rcslotdone243
bb_rcslotdone243:
  %v901 = load i64, ptr %slot9, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %ld903 = load i32, ptr %p902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld903, ptr %slot171, align 8
  %v904 = load i32, ptr %slot171, align 8
  %cv905 = zext i32 %v904 to i64
  %cond906 = icmp ne i64 %cv905, 0
  br i1 %cond906, label %bb_rcslotdrop252, label %bb_rcslotdone252
bb_rcslotdrop252:
  %v907 = load i64, ptr %slot9, align 8
  %p908 = inttoptr i64 %v907 to ptr
  store i32 0, ptr %p908, align 4, !alias.scope !3, !noalias !4
  %v909 = load i64, ptr %slot23, align 8
  store i64 %v909, ptr %slot172, align 8
  %v910 = load i64, ptr %slot10, align 8
  %p911 = inttoptr i64 %v910 to ptr
  %ld912 = load i32, ptr %p911, align 4, !alias.scope !3, !noalias !4
  store i32 %ld912, ptr %slot173, align 8
  %v913 = load i32, ptr %slot173, align 8
  %op914 = and i32 %v913, 28
  store i32 %op914, ptr %slot174, align 8
  %v915 = load i32, ptr %slot174, align 8
  %cv916 = zext i32 %v915 to i64
  %cond917 = icmp ne i64 %cv916, 0
  br i1 %cond917, label %bb_rcslotrole252, label %bb_rcslotowner252
bb_rcslotrole252:
  %v918 = load i64, ptr %slot36, align 8
  store i64 %v918, ptr %slot175, align 8
  %v919 = load i64, ptr %slot175, align 8
  %v920 = load i64, ptr %slot172, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v919, i64 %v920) nomerge, !dbg !134
  br label %bb_rcslotdone252
bb_rcslotowner252:
  %v921 = load i64, ptr %slot36, align 8
  store i64 %v921, ptr %slot176, align 8
  %v922 = load i64, ptr %slot176, align 8
  %v923 = load i64, ptr %slot172, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v922, i64 %v923) nomerge, !dbg !134
  br label %bb_rcslotdone252
bb_rcslotdone252:
  %v924 = load i64, ptr %slot7, align 8
  %p925 = inttoptr i64 %v924 to ptr
  %ld926 = load i32, ptr %p925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld926, ptr %slot177, align 8
  %v927 = load i32, ptr %slot177, align 8
  %cv928 = zext i32 %v927 to i64
  %cond929 = icmp ne i64 %cv928, 0
  br i1 %cond929, label %bb_rcslotdrop279, label %bb_rcslotdone279
bb_rcslotdrop279:
  %v930 = load i64, ptr %slot7, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i32 0, ptr %p931, align 4, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot22, align 8
  store i64 %v932, ptr %slot178, align 8
  %v933 = load i64, ptr %slot8, align 8
  %p934 = inttoptr i64 %v933 to ptr
  %ld935 = load i32, ptr %p934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld935, ptr %slot179, align 8
  %v936 = load i32, ptr %slot179, align 8
  %op937 = and i32 %v936, 28
  store i32 %op937, ptr %slot180, align 8
  %v938 = load i32, ptr %slot180, align 8
  %cv939 = zext i32 %v938 to i64
  %cond940 = icmp ne i64 %cv939, 0
  br i1 %cond940, label %bb_rcslotrole279, label %bb_rcslotowner279
bb_rcslotrole279:
  %v941 = load i64, ptr %slot36, align 8
  store i64 %v941, ptr %slot181, align 8
  %v942 = load i64, ptr %slot181, align 8
  %v943 = load i64, ptr %slot178, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v942, i64 %v943) nomerge, !dbg !134
  br label %bb_rcslotdone279
bb_rcslotowner279:
  %v944 = load i64, ptr %slot36, align 8
  store i64 %v944, ptr %slot182, align 8
  %v945 = load i64, ptr %slot182, align 8
  %v946 = load i64, ptr %slot178, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v945, i64 %v946) nomerge, !dbg !134
  br label %bb_rcslotdone279
bb_rcslotdone279:
  %v947 = load i64, ptr %slot158, align 8
  %p948 = inttoptr i64 %v947 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p948, i64 24, i1 false)
  ret void
bb_failure:
  %v949 = load i64, ptr %slot6, align 8
  %p950 = inttoptr i64 %v949 to ptr
  call void @llvm.memset.p0.i64(ptr %p950, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v951 = load i64, ptr %slot6, align 8
  %p952 = inttoptr i64 %v951 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p952, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v953 = load i64, ptr %slot6, align 8
  %p954 = inttoptr i64 %v953 to ptr
  call void @llvm.memset.p0.i64(ptr %p954, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v955 = load i64, ptr %slot6, align 8
  %p956 = inttoptr i64 %v955 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p956, i64 24, i1 false)
  ret void
}

@myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c(i64, i64, i64, i64)
declare i64 @myl_f_448f060fb6f29ea6a9164d3fd28db134abf5c67c6d4955b6c7d5a3d5aa27f16e(i64, i64)
declare i64 @myl_f_6fe10fdc09b87fb76dc6a5a2a43c5948fb938a942549e3f0f2e42c18a951ae5b(i64, i64, i64)
declare void @myl_f_82db81cbf039d56a0d5a834fd6bf7f684d61381ad6e90659c4e405c77abb1788(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64, i64)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763", linkageName: "myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2647888323009937736, i64 0, !"myl_f_32b97d4c2a5e41881000ab8c08009cc61c7735c8d3e3df9f813961d074c2b763"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!116 = !DILocation(line: 10, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!118 = !DILocation(line: 11, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!120 = !DILocation(line: 23, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!122 = !DILocation(line: 28, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!124 = !DILocation(line: 29, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!126 = !DILocation(line: 31, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!128 = !DILocation(line: 35, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!130 = !DILocation(line: 47, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!132 = !DILocation(line: 50, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!134 = !DILocation(line: 51, column: 0, scope: !135)
