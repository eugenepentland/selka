target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %callresult55 = alloca [16 x i8], align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %callresult113 = alloca [16 x i8], align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %callresult171 = alloca [16 x i8], align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %callresult229 = alloca [16 x i8], align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %callresult287 = alloca [16 x i8], align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %callresult345 = alloca [16 x i8], align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %callresult712 = alloca [16 x i8], align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v755 = load i64, ptr %slot1, align 8
  %op756 = add i64 %v755, 32
  store i64 %op756, ptr %slot3, align 8
  %mem757 = alloca i8, i64 16, align 8
  %ptr758 = ptrtoint ptr %mem757 to i64
  store i64 %ptr758, ptr %slot4, align 8
  %mem759 = alloca i8, i64 8, align 8
  %ptr760 = ptrtoint ptr %mem759 to i64
  store i64 %ptr760, ptr %slot5, align 8
  %mem761 = alloca i8, i64 8, align 8
  %ptr762 = ptrtoint ptr %mem761 to i64
  store i64 %ptr762, ptr %slot6, align 8
  %mem763 = alloca i8, i64 8, align 8
  %ptr764 = ptrtoint ptr %mem763 to i64
  store i64 %ptr764, ptr %slot7, align 8
  %mem765 = alloca i8, i64 8, align 8
  %ptr766 = ptrtoint ptr %mem765 to i64
  store i64 %ptr766, ptr %slot8, align 8
  %mem767 = alloca i8, i64 8, align 8
  %ptr768 = ptrtoint ptr %mem767 to i64
  store i64 %ptr768, ptr %slot9, align 8
  %mem769 = alloca i8, i64 8, align 8
  %ptr770 = ptrtoint ptr %mem769 to i64
  store i64 %ptr770, ptr %slot10, align 8
  %mem771 = alloca i8, i64 8, align 8
  %ptr772 = ptrtoint ptr %mem771 to i64
  store i64 %ptr772, ptr %slot11, align 8
  %mem773 = alloca i8, i64 8, align 8
  %ptr774 = ptrtoint ptr %mem773 to i64
  store i64 %ptr774, ptr %slot12, align 8
  %mem775 = alloca i8, i64 8, align 8
  %ptr776 = ptrtoint ptr %mem775 to i64
  store i64 %ptr776, ptr %slot13, align 8
  %mem777 = alloca i8, i64 312, align 8
  %ptr778 = ptrtoint ptr %mem777 to i64
  store i64 %ptr778, ptr %slot14, align 8
  %mem779 = alloca i8, i64 88, align 8
  %ptr780 = ptrtoint ptr %mem779 to i64
  store i64 %ptr780, ptr %slot15, align 8
  %mem781 = alloca i8, i64 8, align 8
  %ptr782 = ptrtoint ptr %mem781 to i64
  store i64 %ptr782, ptr %slot16, align 8
  %mem783 = alloca i8, i64 8, align 8
  %ptr784 = ptrtoint ptr %mem783 to i64
  store i64 %ptr784, ptr %slot17, align 8
  %mem785 = alloca i8, i64 312, align 8
  %ptr786 = ptrtoint ptr %mem785 to i64
  store i64 %ptr786, ptr %slot18, align 8
  %mem787 = alloca i8, i64 8, align 8
  %ptr788 = ptrtoint ptr %mem787 to i64
  store i64 %ptr788, ptr %slot19, align 8
  %mem789 = alloca i8, i64 8, align 8
  %ptr790 = ptrtoint ptr %mem789 to i64
  store i64 %ptr790, ptr %slot20, align 8
  %mem791 = alloca i8, i64 8, align 8
  %ptr792 = ptrtoint ptr %mem791 to i64
  store i64 %ptr792, ptr %slot21, align 8
  %mem793 = alloca i8, i64 8, align 8
  %ptr794 = ptrtoint ptr %mem793 to i64
  store i64 %ptr794, ptr %slot22, align 8
  %mem795 = alloca i8, i64 8, align 8
  %ptr796 = ptrtoint ptr %mem795 to i64
  store i64 %ptr796, ptr %slot23, align 8
  %mem797 = alloca i8, i64 312, align 8
  %ptr798 = ptrtoint ptr %mem797 to i64
  store i64 %ptr798, ptr %slot24, align 8
  %mem799 = alloca i8, i64 312, align 8
  %ptr800 = ptrtoint ptr %mem799 to i64
  store i64 %ptr800, ptr %slot25, align 8
  %mem801 = alloca i8, i64 312, align 8
  %ptr802 = ptrtoint ptr %mem801 to i64
  store i64 %ptr802, ptr %slot26, align 8
  %mem803 = alloca i8, i64 312, align 8
  %ptr804 = ptrtoint ptr %mem803 to i64
  store i64 %ptr804, ptr %slot27, align 8
  %mem805 = alloca i8, i64 312, align 8
  %ptr806 = ptrtoint ptr %mem805 to i64
  store i64 %ptr806, ptr %slot28, align 8
  %mem807 = alloca i8, i64 312, align 8
  %ptr808 = ptrtoint ptr %mem807 to i64
  store i64 %ptr808, ptr %slot29, align 8
  %mem809 = alloca i8, i64 16, align 8
  %ptr810 = ptrtoint ptr %mem809 to i64
  store i64 %ptr810, ptr %slot30, align 8
  %mem811 = alloca i8, i64 312, align 8
  %ptr812 = ptrtoint ptr %mem811 to i64
  store i64 %ptr812, ptr %slot31, align 8
  %mem813 = alloca i8, i64 312, align 8
  %ptr814 = ptrtoint ptr %mem813 to i64
  store i64 %ptr814, ptr %slot32, align 8
  %mem815 = alloca i8, i64 16, align 8
  %ptr816 = ptrtoint ptr %mem815 to i64
  store i64 %ptr816, ptr %slot33, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem817 = alloca i8, i64 8, align 8
  %ptr818 = ptrtoint ptr %mem817 to i64
  store i64 %ptr818, ptr %slot34, align 8
  %v819 = load i64, ptr %slot1, align 8
  %op820 = add i64 %v819, 64
  store i64 %op820, ptr %slot35, align 8
  %v821 = load i64, ptr %slot35, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ld823 = load i64, ptr %p822, align 8, !alias.scope !4, !noalias !3
  store i64 %ld823, ptr %slot36, align 8
  %stack824 = call ptr @llvm.stacksave()
  %stackaddr825 = ptrtoint ptr %stack824 to i64
  %v826 = load i64, ptr %slot36, align 8
  %cmp827 = icmp ult i64 %stackaddr825, %v826
  %cv828 = zext i1 %cmp827 to i64
  store i64 %cv828, ptr %slot37, align 8
  %v829 = load i64, ptr %slot37, align 8
  %cond830 = icmp ne i64 %v829, 0
  br i1 %cond830, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v831 = load i64, ptr %slot1, align 8
  %p832 = inttoptr i64 %v831 to ptr
  call void @myl_qbe_fail_frame(ptr %p832) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v833 = load i64, ptr %slot20, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i64 0, ptr %p834, align 8, !alias.scope !3, !noalias !4
  %v835 = load i64, ptr %slot2, align 8
  %v836 = load i64, ptr %slot19, align 8
  %p837 = inttoptr i64 %v836 to ptr
  store i64 %v835, ptr %p837, align 8, !alias.scope !3, !noalias !4
  %v838 = load i64, ptr %slot1, align 8
  %p839 = inttoptr i64 %v838 to ptr
  %call840 = call ptr @myl_qbe_heap(ptr %p839) nomerge, !dbg !112
  %calladdr841 = ptrtoint ptr %call840 to i64
  store i64 %calladdr841, ptr %slot38, align 8
  %v842 = load i64, ptr %slot1, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %call844 = call i64 @myl_qbe_region_mark(ptr %p843) nomerge, !dbg !112
  store i64 %call844, ptr %slot39, align 8
  %v845 = load i64, ptr %slot5, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i32 0, ptr %p846, align 4, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot6, align 8
  %p848 = inttoptr i64 %v847 to ptr
  store i32 0, ptr %p848, align 4, !alias.scope !3, !noalias !4
  %v849 = load i64, ptr %slot7, align 8
  %p850 = inttoptr i64 %v849 to ptr
  store i32 0, ptr %p850, align 4, !alias.scope !3, !noalias !4
  %v851 = load i64, ptr %slot8, align 8
  %p852 = inttoptr i64 %v851 to ptr
  store i32 0, ptr %p852, align 4, !alias.scope !3, !noalias !4
  %v853 = load i64, ptr %slot9, align 8
  %p854 = inttoptr i64 %v853 to ptr
  store i32 0, ptr %p854, align 4, !alias.scope !3, !noalias !4
  %v855 = load i64, ptr %slot10, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i32 0, ptr %p856, align 4, !alias.scope !3, !noalias !4
  %v857 = load i64, ptr %slot11, align 8
  %p858 = inttoptr i64 %v857 to ptr
  store i32 0, ptr %p858, align 4, !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot12, align 8
  %p860 = inttoptr i64 %v859 to ptr
  store i32 0, ptr %p860, align 4, !alias.scope !3, !noalias !4
  %v861 = load i64, ptr %slot13, align 8
  %p862 = inttoptr i64 %v861 to ptr
  store i32 0, ptr %p862, align 4, !alias.scope !3, !noalias !4
  %v863 = load i64, ptr %slot6, align 8
  %p864 = inttoptr i64 %v863 to ptr
  store i32 2, ptr %p864, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v865 = load i64, ptr %slot19, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i64, ptr %p866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld867, ptr %slot40, align 8
  %v868 = load i64, ptr %slot40, align 8
  %v869 = load i64, ptr %slot21, align 8
  %p870 = inttoptr i64 %v869 to ptr
  store i64 %v868, ptr %p870, align 8, !alias.scope !3, !noalias !4
  %v871 = load i64, ptr %slot24, align 8
  store i64 %v871, ptr %slot41, align 8
  %v872 = load i64, ptr %slot41, align 8
  %p873 = inttoptr i64 %v872 to ptr
  store i32 0, ptr %p873, align 4, !alias.scope !3, !noalias !4
  %v874 = load i64, ptr %slot41, align 8
  %p875 = inttoptr i64 %v874 to ptr
  store i32 26, ptr %p875, align 4, !alias.scope !3, !noalias !4
  %v876 = load i64, ptr %slot41, align 8
  %v877 = load i64, ptr %slot22, align 8
  %p878 = inttoptr i64 %v877 to ptr
  store i64 %v876, ptr %p878, align 8, !alias.scope !3, !noalias !4
  %v879 = load i64, ptr %slot21, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %ld881 = load i64, ptr %p880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld881, ptr %slot42, align 8
  %v882 = load i64, ptr %slot22, align 8
  %p883 = inttoptr i64 %v882 to ptr
  %ld884 = load i64, ptr %p883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld884, ptr %slot43, align 8
  %v885 = load i64, ptr %slot1, align 8
  %v886 = load i64, ptr %slot42, align 8
  %v887 = load i64, ptr %slot43, align 8
  %call888 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v885, i64 %v886, i64 %v887) nomerge, !dbg !114
  store i64 %call888, ptr %slot44, align 8
  %v889 = load i64, ptr %slot44, align 8
  %v890 = load i64, ptr %slot21, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i64 %v889, ptr %p891, align 8, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot7, align 8
  %p893 = inttoptr i64 %v892 to ptr
  %ld894 = load i32, ptr %p893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld894, ptr %slot45, align 8
  %v895 = load i32, ptr %slot45, align 8
  %cv896 = zext i32 %v895 to i64
  %cond897 = icmp ne i64 %cv896, 0
  br i1 %cond897, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v898 = load i64, ptr %slot7, align 8
  %p899 = inttoptr i64 %v898 to ptr
  store i32 0, ptr %p899, align 4, !alias.scope !3, !noalias !4
  %v900 = load i64, ptr %slot14, align 8
  store i64 %v900, ptr %slot46, align 8
  %v901 = load i64, ptr %slot8, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %ld903 = load i32, ptr %p902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld903, ptr %slot47, align 8
  %v904 = load i32, ptr %slot47, align 8
  %op905 = and i32 %v904, 28
  store i32 %op905, ptr %slot48, align 8
  %v906 = load i32, ptr %slot48, align 8
  %cv907 = zext i32 %v906 to i64
  %cond908 = icmp ne i64 %cv907, 0
  br i1 %cond908, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v909 = load i64, ptr %slot38, align 8
  store i64 %v909, ptr %slot49, align 8
  %v910 = load i64, ptr %slot49, align 8
  %v911 = load i64, ptr %slot46, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v910, i64 %v911) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v912 = load i64, ptr %slot38, align 8
  store i64 %v912, ptr %slot50, align 8
  %v913 = load i64, ptr %slot50, align 8
  %v914 = load i64, ptr %slot46, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v913, i64 %v914) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v915 = load i64, ptr %slot21, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %ld917 = load i64, ptr %p916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld917, ptr %slot51, align 8
  %v918 = load i64, ptr %slot51, align 8
  %cond919 = icmp ne i64 %v918, 0
  br i1 %cond919, label %bb_next24, label %bb_i7
bb_next24:
  %v920 = load i64, ptr %slot19, align 8
  %p921 = inttoptr i64 %v920 to ptr
  %ld922 = load i64, ptr %p921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld922, ptr %slot52, align 8
  %v923 = load i64, ptr %slot52, align 8
  %v924 = load i64, ptr %slot21, align 8
  %p925 = inttoptr i64 %v924 to ptr
  store i64 %v923, ptr %p925, align 8, !alias.scope !3, !noalias !4
  %v926 = load i64, ptr %slot21, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i64, ptr %p927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld928, ptr %slot53, align 8
  %v929 = load i64, ptr %slot1, align 8
  %v930 = load i64, ptr %slot53, align 8
  %call931 = call { i64, i64 } @myl_f_c75868580de8a50d8a792a8a996aae0a3ad208c1ff95b19e5793cb5a5af05750(i64 %v929, i64 %v930) nomerge, !dbg !116
  store { i64, i64 } %call931, ptr %callresult55, align 8
  %addr932 = ptrtoint ptr %callresult55 to i64
  store i64 %addr932, ptr %slot54, align 8
  %v933 = load i64, ptr %slot54, align 8
  %v934 = load i64, ptr %slot21, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i64 %v933, ptr %p935, align 8, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot7, align 8
  %p937 = inttoptr i64 %v936 to ptr
  %ld938 = load i32, ptr %p937, align 4, !alias.scope !3, !noalias !4
  store i32 %ld938, ptr %slot56, align 8
  %v939 = load i32, ptr %slot56, align 8
  %cv940 = zext i32 %v939 to i64
  %cond941 = icmp ne i64 %cv940, 0
  br i1 %cond941, label %bb_rcslotdrop29, label %bb_rcslotdone29
bb_rcslotdrop29:
  %v942 = load i64, ptr %slot7, align 8
  %p943 = inttoptr i64 %v942 to ptr
  store i32 0, ptr %p943, align 4, !alias.scope !3, !noalias !4
  %v944 = load i64, ptr %slot14, align 8
  store i64 %v944, ptr %slot57, align 8
  %v945 = load i64, ptr %slot8, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %ld947 = load i32, ptr %p946, align 4, !alias.scope !3, !noalias !4
  store i32 %ld947, ptr %slot58, align 8
  %v948 = load i32, ptr %slot58, align 8
  %op949 = and i32 %v948, 28
  store i32 %op949, ptr %slot59, align 8
  %v950 = load i32, ptr %slot59, align 8
  %cv951 = zext i32 %v950 to i64
  %cond952 = icmp ne i64 %cv951, 0
  br i1 %cond952, label %bb_rcslotrole29, label %bb_rcslotowner29
bb_rcslotrole29:
  %v953 = load i64, ptr %slot38, align 8
  store i64 %v953, ptr %slot60, align 8
  %v954 = load i64, ptr %slot60, align 8
  %v955 = load i64, ptr %slot57, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v954, i64 %v955) nomerge, !dbg !116
  br label %bb_rcslotdone29
bb_rcslotowner29:
  %v956 = load i64, ptr %slot38, align 8
  store i64 %v956, ptr %slot61, align 8
  %v957 = load i64, ptr %slot61, align 8
  %v958 = load i64, ptr %slot57, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v957, i64 %v958) nomerge, !dbg !116
  br label %bb_rcslotdone29
bb_rcslotdone29:
  %v959 = load i64, ptr %slot21, align 8
  %p960 = inttoptr i64 %v959 to ptr
  %ld961 = load i64, ptr %p960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld961, ptr %slot62, align 8
  %v962 = load i64, ptr %slot62, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ld964 = load i32, ptr %p963, align 4
  %ext965 = zext i32 %ld964 to i64
  store i64 %ext965, ptr %slot63, align 8
  %v966 = load i64, ptr %slot63, align 8
  %cmp967 = icmp eq i64 %v966, 1
  %cv968 = zext i1 %cmp967 to i64
  store i64 %cv968, ptr %slot64, align 8
  %v969 = load i64, ptr %slot64, align 8
  %cond970 = icmp ne i64 %v969, 0
  br i1 %cond970, label %bb_errtrace38, label %bb_errtraced38
bb_errtrace38:
  %p971 = inttoptr i64 ptrtoint (ptr @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p971, i64 8589934598) "call-inline-cost"="0", !dbg !118
  br label %bb_errtraced38
bb_errtraced38:
  %v972 = load i64, ptr %slot7, align 8
  %p973 = inttoptr i64 %v972 to ptr
  %ld974 = load i32, ptr %p973, align 4, !alias.scope !3, !noalias !4
  store i32 %ld974, ptr %slot65, align 8
  %v975 = load i32, ptr %slot65, align 8
  %cv976 = zext i32 %v975 to i64
  %cond977 = icmp ne i64 %cv976, 0
  br i1 %cond977, label %bb_rcslotdrop41, label %bb_rcslotdone41
bb_rcslotdrop41:
  %v978 = load i64, ptr %slot7, align 8
  %p979 = inttoptr i64 %v978 to ptr
  store i32 0, ptr %p979, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone41
bb_rcslotdone41:
  %v980 = load i64, ptr %slot5, align 8
  %p981 = inttoptr i64 %v980 to ptr
  %ld982 = load i32, ptr %p981, align 4, !alias.scope !3, !noalias !4
  store i32 %ld982, ptr %slot66, align 8
  %v983 = load i32, ptr %slot66, align 8
  %cv984 = zext i32 %v983 to i64
  %cond985 = icmp ne i64 %cv984, 0
  br i1 %cond985, label %bb_rcslotdrop44, label %bb_rcslotdone44
bb_rcslotdrop44:
  %v986 = load i64, ptr %slot5, align 8
  %p987 = inttoptr i64 %v986 to ptr
  store i32 0, ptr %p987, align 4, !alias.scope !3, !noalias !4
  %v988 = load i64, ptr %slot20, align 8
  store i64 %v988, ptr %slot67, align 8
  %v989 = load i64, ptr %slot6, align 8
  %p990 = inttoptr i64 %v989 to ptr
  %ld991 = load i32, ptr %p990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld991, ptr %slot68, align 8
  %v992 = load i32, ptr %slot68, align 8
  %op993 = and i32 %v992, 28
  store i32 %op993, ptr %slot69, align 8
  %v994 = load i32, ptr %slot69, align 8
  %cv995 = zext i32 %v994 to i64
  %cond996 = icmp ne i64 %cv995, 0
  br i1 %cond996, label %bb_rcslotrole44, label %bb_rcslotowner44
bb_rcslotrole44:
  %v997 = load i64, ptr %slot38, align 8
  store i64 %v997, ptr %slot70, align 8
  %v998 = load i64, ptr %slot67, align 8
  %p999 = inttoptr i64 %v998 to ptr
  %ld1000 = load i64, ptr %p999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1000, ptr %slot71, align 8
  %v1001 = load i64, ptr %slot71, align 8
  %cmp1002 = icmp ne i64 %v1001, 0
  %cv1003 = zext i1 %cmp1002 to i32
  store i32 %cv1003, ptr %slot72, align 8
  %v1004 = load i32, ptr %slot72, align 8
  %cv1005 = zext i32 %v1004 to i64
  %cond1006 = icmp ne i64 %cv1005, 0
  br i1 %cond1006, label %bb_rcgnn60, label %bb_rcgdone60
bb_rcgnn60:
  %v1007 = load i64, ptr %slot71, align 8
  %op1008 = sub i64 %v1007, 16
  store i64 %op1008, ptr %slot73, align 8
  %v1009 = load i64, ptr %slot71, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  %rgep1011 = getelementptr i8, ptr %p1010, i64 -16
  %ld1012 = load i64, ptr %rgep1011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1012, ptr %slot74, align 8
  %v1013 = load i64, ptr %slot74, align 8
  %op1014 = and i64 %v1013, 4611686018427387906
  store i64 %op1014, ptr %slot75, align 8
  %v1015 = load i64, ptr %slot75, align 8
  %cmp1016 = icmp ne i64 %v1015, 0
  %cv1017 = zext i1 %cmp1016 to i32
  store i32 %cv1017, ptr %slot76, align 8
  %v1018 = load i32, ptr %slot76, align 8
  %cv1019 = zext i32 %v1018 to i64
  %cond1020 = icmp ne i64 %cv1019, 0
  br i1 %cond1020, label %bb_rcgclear60, label %bb_rcgcounted60
bb_rcgcounted60:
  %v1021 = load i64, ptr %slot71, align 8
  %op1022 = sub i64 %v1021, 24
  store i64 %op1022, ptr %slot77, align 8
  %v1023 = load i64, ptr %slot71, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  %rgep1025 = getelementptr i8, ptr %p1024, i64 -24
  %ld1026 = load i64, ptr %rgep1025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1026, ptr %slot78, align 8
  %v1027 = load i64, ptr %slot78, align 8
  %op1028 = sub i64 %v1027, 1
  store i64 %op1028, ptr %slot79, align 8
  %v1029 = load i64, ptr %slot79, align 8
  %cmp1030 = icmp eq i64 %v1029, 0
  %cv1031 = zext i1 %cmp1030 to i32
  store i32 %cv1031, ptr %slot80, align 8
  %v1032 = load i32, ptr %slot80, align 8
  %cv1033 = zext i32 %v1032 to i64
  %cond1034 = icmp ne i64 %cv1033, 0
  br i1 %cond1034, label %bb_rcglast60, label %bb_rcgdec60
bb_rcglast60:
  %v1035 = load i64, ptr %slot71, align 8
  %op1036 = sub i64 %v1035, 32
  store i64 %op1036, ptr %slot81, align 8
  %v1037 = load i64, ptr %slot71, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  %rgep1039 = getelementptr i8, ptr %p1038, i64 -32
  %ld1040 = load i64, ptr %rgep1039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1040, ptr %slot82, align 8
  %v1041 = load i64, ptr %slot82, align 8
  %cmp1042 = icmp ne i64 %v1041, 0
  %cv1043 = zext i1 %cmp1042 to i32
  store i32 %cv1043, ptr %slot83, align 8
  %v1044 = load i32, ptr %slot83, align 8
  %cv1045 = zext i32 %v1044 to i64
  %cond1046 = icmp ne i64 %cv1045, 0
  br i1 %cond1046, label %bb_rcgdec60, label %bb_rcgslow60
bb_rcgslow60:
  %v1047 = load i64, ptr %slot70, align 8
  %v1048 = load i64, ptr %slot67, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1047, i64 %v1048) nomerge, !dbg !118
  br label %bb_rcgdone60
bb_rcgdec60:
  %v1049 = load i64, ptr %slot79, align 8
  %v1050 = load i64, ptr %slot71, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  %rgep1052 = getelementptr i8, ptr %p1051, i64 -24
  store i64 %v1049, ptr %rgep1052, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear60
bb_rcgclear60:
  %v1053 = load i64, ptr %slot67, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i64 0, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone60
bb_rcgdone60:
  br label %bb_rcslotdone44
bb_rcslotowner44:
  %v1055 = load i64, ptr %slot38, align 8
  store i64 %v1055, ptr %slot84, align 8
  %v1056 = load i64, ptr %slot67, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  %ld1058 = load i64, ptr %p1057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1058, ptr %slot85, align 8
  %v1059 = load i64, ptr %slot85, align 8
  %cmp1060 = icmp ne i64 %v1059, 0
  %cv1061 = zext i1 %cmp1060 to i32
  store i32 %cv1061, ptr %slot86, align 8
  %v1062 = load i32, ptr %slot86, align 8
  %cv1063 = zext i32 %v1062 to i64
  %cond1064 = icmp ne i64 %cv1063, 0
  br i1 %cond1064, label %bb_rcgnn75, label %bb_rcgdone75
bb_rcgnn75:
  %v1065 = load i64, ptr %slot85, align 8
  %op1066 = sub i64 %v1065, 16
  store i64 %op1066, ptr %slot87, align 8
  %v1067 = load i64, ptr %slot85, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  %rgep1069 = getelementptr i8, ptr %p1068, i64 -16
  %ld1070 = load i64, ptr %rgep1069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1070, ptr %slot88, align 8
  %v1071 = load i64, ptr %slot88, align 8
  %op1072 = and i64 %v1071, 4611686018427387906
  store i64 %op1072, ptr %slot89, align 8
  %v1073 = load i64, ptr %slot89, align 8
  %cmp1074 = icmp ne i64 %v1073, 0
  %cv1075 = zext i1 %cmp1074 to i32
  store i32 %cv1075, ptr %slot90, align 8
  %v1076 = load i32, ptr %slot90, align 8
  %cv1077 = zext i32 %v1076 to i64
  %cond1078 = icmp ne i64 %cv1077, 0
  br i1 %cond1078, label %bb_rcgclear75, label %bb_rcgcounted75
bb_rcgcounted75:
  %v1079 = load i64, ptr %slot85, align 8
  %op1080 = sub i64 %v1079, 32
  store i64 %op1080, ptr %slot91, align 8
  %v1081 = load i64, ptr %slot85, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  %rgep1083 = getelementptr i8, ptr %p1082, i64 -32
  %ld1084 = load i64, ptr %rgep1083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1084, ptr %slot92, align 8
  %v1085 = load i64, ptr %slot92, align 8
  %op1086 = sub i64 %v1085, 1
  store i64 %op1086, ptr %slot93, align 8
  %v1087 = load i64, ptr %slot93, align 8
  %cmp1088 = icmp eq i64 %v1087, 0
  %cv1089 = zext i1 %cmp1088 to i32
  store i32 %cv1089, ptr %slot94, align 8
  %v1090 = load i32, ptr %slot94, align 8
  %cv1091 = zext i32 %v1090 to i64
  %cond1092 = icmp ne i64 %cv1091, 0
  br i1 %cond1092, label %bb_rcglast75, label %bb_rcgdec75
bb_rcglast75:
  %v1093 = load i64, ptr %slot85, align 8
  %op1094 = sub i64 %v1093, 24
  store i64 %op1094, ptr %slot95, align 8
  %v1095 = load i64, ptr %slot85, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  %rgep1097 = getelementptr i8, ptr %p1096, i64 -24
  %ld1098 = load i64, ptr %rgep1097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1098, ptr %slot96, align 8
  %v1099 = load i64, ptr %slot96, align 8
  %cmp1100 = icmp ne i64 %v1099, 0
  %cv1101 = zext i1 %cmp1100 to i32
  store i32 %cv1101, ptr %slot97, align 8
  %v1102 = load i32, ptr %slot97, align 8
  %cv1103 = zext i32 %v1102 to i64
  %cond1104 = icmp ne i64 %cv1103, 0
  br i1 %cond1104, label %bb_rcgdec75, label %bb_rcgslow75
bb_rcgslow75:
  %v1105 = load i64, ptr %slot84, align 8
  %v1106 = load i64, ptr %slot67, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1105, i64 %v1106) nomerge, !dbg !118
  br label %bb_rcgdone75
bb_rcgdec75:
  %v1107 = load i64, ptr %slot93, align 8
  %v1108 = load i64, ptr %slot85, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %rgep1110 = getelementptr i8, ptr %p1109, i64 -32
  store i64 %v1107, ptr %rgep1110, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear75
bb_rcgclear75:
  %v1111 = load i64, ptr %slot67, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i64 0, ptr %p1112, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone75
bb_rcgdone75:
  br label %bb_rcslotdone44
bb_rcslotdone44:
  %v1113 = load i64, ptr %slot62, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  %ret1115 = load { i64, i64 }, ptr %p1114, align 8
  ret { i64, i64 } %ret1115
bb_i7:
  %v1116 = load i64, ptr %slot19, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  %ld1118 = load i64, ptr %p1117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1118, ptr %slot98, align 8
  %v1119 = load i64, ptr %slot98, align 8
  %v1120 = load i64, ptr %slot21, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  store i64 %v1119, ptr %p1121, align 8, !alias.scope !3, !noalias !4
  %v1122 = load i64, ptr %slot25, align 8
  store i64 %v1122, ptr %slot99, align 8
  %v1123 = load i64, ptr %slot99, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  store i32 0, ptr %p1124, align 4, !alias.scope !3, !noalias !4
  %v1125 = load i64, ptr %slot99, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  store i32 28, ptr %p1126, align 4, !alias.scope !3, !noalias !4
  %v1127 = load i64, ptr %slot99, align 8
  %v1128 = load i64, ptr %slot22, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  store i64 %v1127, ptr %p1129, align 8, !alias.scope !3, !noalias !4
  %v1130 = load i64, ptr %slot21, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  %ld1132 = load i64, ptr %p1131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1132, ptr %slot100, align 8
  %v1133 = load i64, ptr %slot22, align 8
  %p1134 = inttoptr i64 %v1133 to ptr
  %ld1135 = load i64, ptr %p1134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1135, ptr %slot101, align 8
  %v1136 = load i64, ptr %slot1, align 8
  %v1137 = load i64, ptr %slot100, align 8
  %v1138 = load i64, ptr %slot101, align 8
  %call1139 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v1136, i64 %v1137, i64 %v1138) nomerge, !dbg !120
  store i64 %call1139, ptr %slot102, align 8
  %v1140 = load i64, ptr %slot102, align 8
  %v1141 = load i64, ptr %slot21, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  store i64 %v1140, ptr %p1142, align 8, !alias.scope !3, !noalias !4
  %v1143 = load i64, ptr %slot7, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  %ld1145 = load i32, ptr %p1144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1145, ptr %slot103, align 8
  %v1146 = load i32, ptr %slot103, align 8
  %cv1147 = zext i32 %v1146 to i64
  %cond1148 = icmp ne i64 %cv1147, 0
  br i1 %cond1148, label %bb_rcslotdrop95, label %bb_rcslotdone95
bb_rcslotdrop95:
  %v1149 = load i64, ptr %slot7, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  store i32 0, ptr %p1150, align 4, !alias.scope !3, !noalias !4
  %v1151 = load i64, ptr %slot14, align 8
  store i64 %v1151, ptr %slot104, align 8
  %v1152 = load i64, ptr %slot8, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  %ld1154 = load i32, ptr %p1153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1154, ptr %slot105, align 8
  %v1155 = load i32, ptr %slot105, align 8
  %op1156 = and i32 %v1155, 28
  store i32 %op1156, ptr %slot106, align 8
  %v1157 = load i32, ptr %slot106, align 8
  %cv1158 = zext i32 %v1157 to i64
  %cond1159 = icmp ne i64 %cv1158, 0
  br i1 %cond1159, label %bb_rcslotrole95, label %bb_rcslotowner95
bb_rcslotrole95:
  %v1160 = load i64, ptr %slot38, align 8
  store i64 %v1160, ptr %slot107, align 8
  %v1161 = load i64, ptr %slot107, align 8
  %v1162 = load i64, ptr %slot104, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1161, i64 %v1162) nomerge, !dbg !120
  br label %bb_rcslotdone95
bb_rcslotowner95:
  %v1163 = load i64, ptr %slot38, align 8
  store i64 %v1163, ptr %slot108, align 8
  %v1164 = load i64, ptr %slot108, align 8
  %v1165 = load i64, ptr %slot104, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1164, i64 %v1165) nomerge, !dbg !120
  br label %bb_rcslotdone95
bb_rcslotdone95:
  %v1166 = load i64, ptr %slot21, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  %ld1168 = load i64, ptr %p1167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1168, ptr %slot109, align 8
  %v1169 = load i64, ptr %slot109, align 8
  %cond1170 = icmp ne i64 %v1169, 0
  br i1 %cond1170, label %bb_next103, label %bb_i14
bb_next103:
  %v1171 = load i64, ptr %slot19, align 8
  %p1172 = inttoptr i64 %v1171 to ptr
  %ld1173 = load i64, ptr %p1172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1173, ptr %slot110, align 8
  %v1174 = load i64, ptr %slot110, align 8
  %v1175 = load i64, ptr %slot21, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  store i64 %v1174, ptr %p1176, align 8, !alias.scope !3, !noalias !4
  %v1177 = load i64, ptr %slot21, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %ld1179 = load i64, ptr %p1178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1179, ptr %slot111, align 8
  %v1180 = load i64, ptr %slot1, align 8
  %v1181 = load i64, ptr %slot111, align 8
  %call1182 = call { i64, i64 } @myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0(i64 %v1180, i64 %v1181) nomerge, !dbg !122
  store { i64, i64 } %call1182, ptr %callresult113, align 8
  %addr1183 = ptrtoint ptr %callresult113 to i64
  store i64 %addr1183, ptr %slot112, align 8
  %v1184 = load i64, ptr %slot112, align 8
  %v1185 = load i64, ptr %slot21, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  store i64 %v1184, ptr %p1186, align 8, !alias.scope !3, !noalias !4
  %v1187 = load i64, ptr %slot7, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i32, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1189, ptr %slot114, align 8
  %v1190 = load i32, ptr %slot114, align 8
  %cv1191 = zext i32 %v1190 to i64
  %cond1192 = icmp ne i64 %cv1191, 0
  br i1 %cond1192, label %bb_rcslotdrop108, label %bb_rcslotdone108
bb_rcslotdrop108:
  %v1193 = load i64, ptr %slot7, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i32 0, ptr %p1194, align 4, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot14, align 8
  store i64 %v1195, ptr %slot115, align 8
  %v1196 = load i64, ptr %slot8, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  %ld1198 = load i32, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1198, ptr %slot116, align 8
  %v1199 = load i32, ptr %slot116, align 8
  %op1200 = and i32 %v1199, 28
  store i32 %op1200, ptr %slot117, align 8
  %v1201 = load i32, ptr %slot117, align 8
  %cv1202 = zext i32 %v1201 to i64
  %cond1203 = icmp ne i64 %cv1202, 0
  br i1 %cond1203, label %bb_rcslotrole108, label %bb_rcslotowner108
bb_rcslotrole108:
  %v1204 = load i64, ptr %slot38, align 8
  store i64 %v1204, ptr %slot118, align 8
  %v1205 = load i64, ptr %slot118, align 8
  %v1206 = load i64, ptr %slot115, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1205, i64 %v1206) nomerge, !dbg !122
  br label %bb_rcslotdone108
bb_rcslotowner108:
  %v1207 = load i64, ptr %slot38, align 8
  store i64 %v1207, ptr %slot119, align 8
  %v1208 = load i64, ptr %slot119, align 8
  %v1209 = load i64, ptr %slot115, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1208, i64 %v1209) nomerge, !dbg !122
  br label %bb_rcslotdone108
bb_rcslotdone108:
  %v1210 = load i64, ptr %slot21, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  %ld1212 = load i64, ptr %p1211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1212, ptr %slot120, align 8
  %v1213 = load i64, ptr %slot120, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i32, ptr %p1214, align 4
  %ext1216 = zext i32 %ld1215 to i64
  store i64 %ext1216, ptr %slot121, align 8
  %v1217 = load i64, ptr %slot121, align 8
  %cmp1218 = icmp eq i64 %v1217, 1
  %cv1219 = zext i1 %cmp1218 to i64
  store i64 %cv1219, ptr %slot122, align 8
  %v1220 = load i64, ptr %slot122, align 8
  %cond1221 = icmp ne i64 %v1220, 0
  br i1 %cond1221, label %bb_errtrace117, label %bb_errtraced117
bb_errtrace117:
  %p1222 = inttoptr i64 ptrtoint (ptr @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1222, i64 8589934605) "call-inline-cost"="0", !dbg !124
  br label %bb_errtraced117
bb_errtraced117:
  %v1223 = load i64, ptr %slot7, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  %ld1225 = load i32, ptr %p1224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1225, ptr %slot123, align 8
  %v1226 = load i32, ptr %slot123, align 8
  %cv1227 = zext i32 %v1226 to i64
  %cond1228 = icmp ne i64 %cv1227, 0
  br i1 %cond1228, label %bb_rcslotdrop120, label %bb_rcslotdone120
bb_rcslotdrop120:
  %v1229 = load i64, ptr %slot7, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  store i32 0, ptr %p1230, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone120
bb_rcslotdone120:
  %v1231 = load i64, ptr %slot5, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  %ld1233 = load i32, ptr %p1232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1233, ptr %slot124, align 8
  %v1234 = load i32, ptr %slot124, align 8
  %cv1235 = zext i32 %v1234 to i64
  %cond1236 = icmp ne i64 %cv1235, 0
  br i1 %cond1236, label %bb_rcslotdrop123, label %bb_rcslotdone123
bb_rcslotdrop123:
  %v1237 = load i64, ptr %slot5, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  store i32 0, ptr %p1238, align 4, !alias.scope !3, !noalias !4
  %v1239 = load i64, ptr %slot20, align 8
  store i64 %v1239, ptr %slot125, align 8
  %v1240 = load i64, ptr %slot6, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  %ld1242 = load i32, ptr %p1241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1242, ptr %slot126, align 8
  %v1243 = load i32, ptr %slot126, align 8
  %op1244 = and i32 %v1243, 28
  store i32 %op1244, ptr %slot127, align 8
  %v1245 = load i32, ptr %slot127, align 8
  %cv1246 = zext i32 %v1245 to i64
  %cond1247 = icmp ne i64 %cv1246, 0
  br i1 %cond1247, label %bb_rcslotrole123, label %bb_rcslotowner123
bb_rcslotrole123:
  %v1248 = load i64, ptr %slot38, align 8
  store i64 %v1248, ptr %slot128, align 8
  %v1249 = load i64, ptr %slot125, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %ld1251 = load i64, ptr %p1250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1251, ptr %slot129, align 8
  %v1252 = load i64, ptr %slot129, align 8
  %cmp1253 = icmp ne i64 %v1252, 0
  %cv1254 = zext i1 %cmp1253 to i32
  store i32 %cv1254, ptr %slot130, align 8
  %v1255 = load i32, ptr %slot130, align 8
  %cv1256 = zext i32 %v1255 to i64
  %cond1257 = icmp ne i64 %cv1256, 0
  br i1 %cond1257, label %bb_rcgnn139, label %bb_rcgdone139
bb_rcgnn139:
  %v1258 = load i64, ptr %slot129, align 8
  %op1259 = sub i64 %v1258, 16
  store i64 %op1259, ptr %slot131, align 8
  %v1260 = load i64, ptr %slot129, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  %rgep1262 = getelementptr i8, ptr %p1261, i64 -16
  %ld1263 = load i64, ptr %rgep1262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1263, ptr %slot132, align 8
  %v1264 = load i64, ptr %slot132, align 8
  %op1265 = and i64 %v1264, 4611686018427387906
  store i64 %op1265, ptr %slot133, align 8
  %v1266 = load i64, ptr %slot133, align 8
  %cmp1267 = icmp ne i64 %v1266, 0
  %cv1268 = zext i1 %cmp1267 to i32
  store i32 %cv1268, ptr %slot134, align 8
  %v1269 = load i32, ptr %slot134, align 8
  %cv1270 = zext i32 %v1269 to i64
  %cond1271 = icmp ne i64 %cv1270, 0
  br i1 %cond1271, label %bb_rcgclear139, label %bb_rcgcounted139
bb_rcgcounted139:
  %v1272 = load i64, ptr %slot129, align 8
  %op1273 = sub i64 %v1272, 24
  store i64 %op1273, ptr %slot135, align 8
  %v1274 = load i64, ptr %slot129, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  %rgep1276 = getelementptr i8, ptr %p1275, i64 -24
  %ld1277 = load i64, ptr %rgep1276, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1277, ptr %slot136, align 8
  %v1278 = load i64, ptr %slot136, align 8
  %op1279 = sub i64 %v1278, 1
  store i64 %op1279, ptr %slot137, align 8
  %v1280 = load i64, ptr %slot137, align 8
  %cmp1281 = icmp eq i64 %v1280, 0
  %cv1282 = zext i1 %cmp1281 to i32
  store i32 %cv1282, ptr %slot138, align 8
  %v1283 = load i32, ptr %slot138, align 8
  %cv1284 = zext i32 %v1283 to i64
  %cond1285 = icmp ne i64 %cv1284, 0
  br i1 %cond1285, label %bb_rcglast139, label %bb_rcgdec139
bb_rcglast139:
  %v1286 = load i64, ptr %slot129, align 8
  %op1287 = sub i64 %v1286, 32
  store i64 %op1287, ptr %slot139, align 8
  %v1288 = load i64, ptr %slot129, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %rgep1290 = getelementptr i8, ptr %p1289, i64 -32
  %ld1291 = load i64, ptr %rgep1290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1291, ptr %slot140, align 8
  %v1292 = load i64, ptr %slot140, align 8
  %cmp1293 = icmp ne i64 %v1292, 0
  %cv1294 = zext i1 %cmp1293 to i32
  store i32 %cv1294, ptr %slot141, align 8
  %v1295 = load i32, ptr %slot141, align 8
  %cv1296 = zext i32 %v1295 to i64
  %cond1297 = icmp ne i64 %cv1296, 0
  br i1 %cond1297, label %bb_rcgdec139, label %bb_rcgslow139
bb_rcgslow139:
  %v1298 = load i64, ptr %slot128, align 8
  %v1299 = load i64, ptr %slot125, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1298, i64 %v1299) nomerge, !dbg !124
  br label %bb_rcgdone139
bb_rcgdec139:
  %v1300 = load i64, ptr %slot137, align 8
  %v1301 = load i64, ptr %slot129, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  %rgep1303 = getelementptr i8, ptr %p1302, i64 -24
  store i64 %v1300, ptr %rgep1303, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear139
bb_rcgclear139:
  %v1304 = load i64, ptr %slot125, align 8
  %p1305 = inttoptr i64 %v1304 to ptr
  store i64 0, ptr %p1305, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone139
bb_rcgdone139:
  br label %bb_rcslotdone123
bb_rcslotowner123:
  %v1306 = load i64, ptr %slot38, align 8
  store i64 %v1306, ptr %slot142, align 8
  %v1307 = load i64, ptr %slot125, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  %ld1309 = load i64, ptr %p1308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1309, ptr %slot143, align 8
  %v1310 = load i64, ptr %slot143, align 8
  %cmp1311 = icmp ne i64 %v1310, 0
  %cv1312 = zext i1 %cmp1311 to i32
  store i32 %cv1312, ptr %slot144, align 8
  %v1313 = load i32, ptr %slot144, align 8
  %cv1314 = zext i32 %v1313 to i64
  %cond1315 = icmp ne i64 %cv1314, 0
  br i1 %cond1315, label %bb_rcgnn154, label %bb_rcgdone154
bb_rcgnn154:
  %v1316 = load i64, ptr %slot143, align 8
  %op1317 = sub i64 %v1316, 16
  store i64 %op1317, ptr %slot145, align 8
  %v1318 = load i64, ptr %slot143, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  %rgep1320 = getelementptr i8, ptr %p1319, i64 -16
  %ld1321 = load i64, ptr %rgep1320, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1321, ptr %slot146, align 8
  %v1322 = load i64, ptr %slot146, align 8
  %op1323 = and i64 %v1322, 4611686018427387906
  store i64 %op1323, ptr %slot147, align 8
  %v1324 = load i64, ptr %slot147, align 8
  %cmp1325 = icmp ne i64 %v1324, 0
  %cv1326 = zext i1 %cmp1325 to i32
  store i32 %cv1326, ptr %slot148, align 8
  %v1327 = load i32, ptr %slot148, align 8
  %cv1328 = zext i32 %v1327 to i64
  %cond1329 = icmp ne i64 %cv1328, 0
  br i1 %cond1329, label %bb_rcgclear154, label %bb_rcgcounted154
bb_rcgcounted154:
  %v1330 = load i64, ptr %slot143, align 8
  %op1331 = sub i64 %v1330, 32
  store i64 %op1331, ptr %slot149, align 8
  %v1332 = load i64, ptr %slot143, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  %rgep1334 = getelementptr i8, ptr %p1333, i64 -32
  %ld1335 = load i64, ptr %rgep1334, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1335, ptr %slot150, align 8
  %v1336 = load i64, ptr %slot150, align 8
  %op1337 = sub i64 %v1336, 1
  store i64 %op1337, ptr %slot151, align 8
  %v1338 = load i64, ptr %slot151, align 8
  %cmp1339 = icmp eq i64 %v1338, 0
  %cv1340 = zext i1 %cmp1339 to i32
  store i32 %cv1340, ptr %slot152, align 8
  %v1341 = load i32, ptr %slot152, align 8
  %cv1342 = zext i32 %v1341 to i64
  %cond1343 = icmp ne i64 %cv1342, 0
  br i1 %cond1343, label %bb_rcglast154, label %bb_rcgdec154
bb_rcglast154:
  %v1344 = load i64, ptr %slot143, align 8
  %op1345 = sub i64 %v1344, 24
  store i64 %op1345, ptr %slot153, align 8
  %v1346 = load i64, ptr %slot143, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %rgep1348 = getelementptr i8, ptr %p1347, i64 -24
  %ld1349 = load i64, ptr %rgep1348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1349, ptr %slot154, align 8
  %v1350 = load i64, ptr %slot154, align 8
  %cmp1351 = icmp ne i64 %v1350, 0
  %cv1352 = zext i1 %cmp1351 to i32
  store i32 %cv1352, ptr %slot155, align 8
  %v1353 = load i32, ptr %slot155, align 8
  %cv1354 = zext i32 %v1353 to i64
  %cond1355 = icmp ne i64 %cv1354, 0
  br i1 %cond1355, label %bb_rcgdec154, label %bb_rcgslow154
bb_rcgslow154:
  %v1356 = load i64, ptr %slot142, align 8
  %v1357 = load i64, ptr %slot125, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1356, i64 %v1357) nomerge, !dbg !124
  br label %bb_rcgdone154
bb_rcgdec154:
  %v1358 = load i64, ptr %slot151, align 8
  %v1359 = load i64, ptr %slot143, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  %rgep1361 = getelementptr i8, ptr %p1360, i64 -32
  store i64 %v1358, ptr %rgep1361, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear154
bb_rcgclear154:
  %v1362 = load i64, ptr %slot125, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  store i64 0, ptr %p1363, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone154
bb_rcgdone154:
  br label %bb_rcslotdone123
bb_rcslotdone123:
  %v1364 = load i64, ptr %slot120, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  %ret1366 = load { i64, i64 }, ptr %p1365, align 8
  ret { i64, i64 } %ret1366
bb_i14:
  %v1367 = load i64, ptr %slot19, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  %ld1369 = load i64, ptr %p1368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1369, ptr %slot156, align 8
  %v1370 = load i64, ptr %slot156, align 8
  %v1371 = load i64, ptr %slot21, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i64 %v1370, ptr %p1372, align 8, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot26, align 8
  store i64 %v1373, ptr %slot157, align 8
  %v1374 = load i64, ptr %slot157, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  store i32 0, ptr %p1375, align 4, !alias.scope !3, !noalias !4
  %v1376 = load i64, ptr %slot157, align 8
  %p1377 = inttoptr i64 %v1376 to ptr
  store i32 31, ptr %p1377, align 4, !alias.scope !3, !noalias !4
  %v1378 = load i64, ptr %slot157, align 8
  %v1379 = load i64, ptr %slot22, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i64 %v1378, ptr %p1380, align 8, !alias.scope !3, !noalias !4
  %v1381 = load i64, ptr %slot21, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  %ld1383 = load i64, ptr %p1382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1383, ptr %slot158, align 8
  %v1384 = load i64, ptr %slot22, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  %ld1386 = load i64, ptr %p1385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1386, ptr %slot159, align 8
  %v1387 = load i64, ptr %slot1, align 8
  %v1388 = load i64, ptr %slot158, align 8
  %v1389 = load i64, ptr %slot159, align 8
  %call1390 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v1387, i64 %v1388, i64 %v1389) nomerge, !dbg !126
  store i64 %call1390, ptr %slot160, align 8
  %v1391 = load i64, ptr %slot160, align 8
  %v1392 = load i64, ptr %slot21, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i64 %v1391, ptr %p1393, align 8, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot7, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  %ld1396 = load i32, ptr %p1395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1396, ptr %slot161, align 8
  %v1397 = load i32, ptr %slot161, align 8
  %cv1398 = zext i32 %v1397 to i64
  %cond1399 = icmp ne i64 %cv1398, 0
  br i1 %cond1399, label %bb_rcslotdrop174, label %bb_rcslotdone174
bb_rcslotdrop174:
  %v1400 = load i64, ptr %slot7, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 0, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot14, align 8
  store i64 %v1402, ptr %slot162, align 8
  %v1403 = load i64, ptr %slot8, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  %ld1405 = load i32, ptr %p1404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1405, ptr %slot163, align 8
  %v1406 = load i32, ptr %slot163, align 8
  %op1407 = and i32 %v1406, 28
  store i32 %op1407, ptr %slot164, align 8
  %v1408 = load i32, ptr %slot164, align 8
  %cv1409 = zext i32 %v1408 to i64
  %cond1410 = icmp ne i64 %cv1409, 0
  br i1 %cond1410, label %bb_rcslotrole174, label %bb_rcslotowner174
bb_rcslotrole174:
  %v1411 = load i64, ptr %slot38, align 8
  store i64 %v1411, ptr %slot165, align 8
  %v1412 = load i64, ptr %slot165, align 8
  %v1413 = load i64, ptr %slot162, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1412, i64 %v1413) nomerge, !dbg !126
  br label %bb_rcslotdone174
bb_rcslotowner174:
  %v1414 = load i64, ptr %slot38, align 8
  store i64 %v1414, ptr %slot166, align 8
  %v1415 = load i64, ptr %slot166, align 8
  %v1416 = load i64, ptr %slot162, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1415, i64 %v1416) nomerge, !dbg !126
  br label %bb_rcslotdone174
bb_rcslotdone174:
  %v1417 = load i64, ptr %slot21, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  %ld1419 = load i64, ptr %p1418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1419, ptr %slot167, align 8
  %v1420 = load i64, ptr %slot167, align 8
  %cond1421 = icmp ne i64 %v1420, 0
  br i1 %cond1421, label %bb_next182, label %bb_i21
bb_next182:
  %v1422 = load i64, ptr %slot19, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  %ld1424 = load i64, ptr %p1423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1424, ptr %slot168, align 8
  %v1425 = load i64, ptr %slot168, align 8
  %v1426 = load i64, ptr %slot21, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  store i64 %v1425, ptr %p1427, align 8, !alias.scope !3, !noalias !4
  %v1428 = load i64, ptr %slot21, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  %ld1430 = load i64, ptr %p1429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1430, ptr %slot169, align 8
  %v1431 = load i64, ptr %slot1, align 8
  %v1432 = load i64, ptr %slot169, align 8
  %call1433 = call { i64, i64 } @myl_f_3ef605d87069af79e10307d85e24cc1def519b618d8c48a20828cacd99a2f11b(i64 %v1431, i64 %v1432) nomerge, !dbg !128
  store { i64, i64 } %call1433, ptr %callresult171, align 8
  %addr1434 = ptrtoint ptr %callresult171 to i64
  store i64 %addr1434, ptr %slot170, align 8
  %v1435 = load i64, ptr %slot170, align 8
  %v1436 = load i64, ptr %slot21, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  store i64 %v1435, ptr %p1437, align 8, !alias.scope !3, !noalias !4
  %v1438 = load i64, ptr %slot7, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  %ld1440 = load i32, ptr %p1439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1440, ptr %slot172, align 8
  %v1441 = load i32, ptr %slot172, align 8
  %cv1442 = zext i32 %v1441 to i64
  %cond1443 = icmp ne i64 %cv1442, 0
  br i1 %cond1443, label %bb_rcslotdrop187, label %bb_rcslotdone187
bb_rcslotdrop187:
  %v1444 = load i64, ptr %slot7, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i32 0, ptr %p1445, align 4, !alias.scope !3, !noalias !4
  %v1446 = load i64, ptr %slot14, align 8
  store i64 %v1446, ptr %slot173, align 8
  %v1447 = load i64, ptr %slot8, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  %ld1449 = load i32, ptr %p1448, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1449, ptr %slot174, align 8
  %v1450 = load i32, ptr %slot174, align 8
  %op1451 = and i32 %v1450, 28
  store i32 %op1451, ptr %slot175, align 8
  %v1452 = load i32, ptr %slot175, align 8
  %cv1453 = zext i32 %v1452 to i64
  %cond1454 = icmp ne i64 %cv1453, 0
  br i1 %cond1454, label %bb_rcslotrole187, label %bb_rcslotowner187
bb_rcslotrole187:
  %v1455 = load i64, ptr %slot38, align 8
  store i64 %v1455, ptr %slot176, align 8
  %v1456 = load i64, ptr %slot176, align 8
  %v1457 = load i64, ptr %slot173, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1456, i64 %v1457) nomerge, !dbg !128
  br label %bb_rcslotdone187
bb_rcslotowner187:
  %v1458 = load i64, ptr %slot38, align 8
  store i64 %v1458, ptr %slot177, align 8
  %v1459 = load i64, ptr %slot177, align 8
  %v1460 = load i64, ptr %slot173, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1459, i64 %v1460) nomerge, !dbg !128
  br label %bb_rcslotdone187
bb_rcslotdone187:
  %v1461 = load i64, ptr %slot21, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  %ld1463 = load i64, ptr %p1462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1463, ptr %slot178, align 8
  %v1464 = load i64, ptr %slot178, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %ld1466 = load i32, ptr %p1465, align 4
  %ext1467 = zext i32 %ld1466 to i64
  store i64 %ext1467, ptr %slot179, align 8
  %v1468 = load i64, ptr %slot179, align 8
  %cmp1469 = icmp eq i64 %v1468, 1
  %cv1470 = zext i1 %cmp1469 to i64
  store i64 %cv1470, ptr %slot180, align 8
  %v1471 = load i64, ptr %slot180, align 8
  %cond1472 = icmp ne i64 %v1471, 0
  br i1 %cond1472, label %bb_errtrace196, label %bb_errtraced196
bb_errtrace196:
  %p1473 = inttoptr i64 ptrtoint (ptr @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1473, i64 8589934612) "call-inline-cost"="0", !dbg !130
  br label %bb_errtraced196
bb_errtraced196:
  %v1474 = load i64, ptr %slot7, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  %ld1476 = load i32, ptr %p1475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1476, ptr %slot181, align 8
  %v1477 = load i32, ptr %slot181, align 8
  %cv1478 = zext i32 %v1477 to i64
  %cond1479 = icmp ne i64 %cv1478, 0
  br i1 %cond1479, label %bb_rcslotdrop199, label %bb_rcslotdone199
bb_rcslotdrop199:
  %v1480 = load i64, ptr %slot7, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  store i32 0, ptr %p1481, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone199
bb_rcslotdone199:
  %v1482 = load i64, ptr %slot5, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  %ld1484 = load i32, ptr %p1483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1484, ptr %slot182, align 8
  %v1485 = load i32, ptr %slot182, align 8
  %cv1486 = zext i32 %v1485 to i64
  %cond1487 = icmp ne i64 %cv1486, 0
  br i1 %cond1487, label %bb_rcslotdrop202, label %bb_rcslotdone202
bb_rcslotdrop202:
  %v1488 = load i64, ptr %slot5, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  store i32 0, ptr %p1489, align 4, !alias.scope !3, !noalias !4
  %v1490 = load i64, ptr %slot20, align 8
  store i64 %v1490, ptr %slot183, align 8
  %v1491 = load i64, ptr %slot6, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  %ld1493 = load i32, ptr %p1492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1493, ptr %slot184, align 8
  %v1494 = load i32, ptr %slot184, align 8
  %op1495 = and i32 %v1494, 28
  store i32 %op1495, ptr %slot185, align 8
  %v1496 = load i32, ptr %slot185, align 8
  %cv1497 = zext i32 %v1496 to i64
  %cond1498 = icmp ne i64 %cv1497, 0
  br i1 %cond1498, label %bb_rcslotrole202, label %bb_rcslotowner202
bb_rcslotrole202:
  %v1499 = load i64, ptr %slot38, align 8
  store i64 %v1499, ptr %slot186, align 8
  %v1500 = load i64, ptr %slot183, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  %ld1502 = load i64, ptr %p1501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1502, ptr %slot187, align 8
  %v1503 = load i64, ptr %slot187, align 8
  %cmp1504 = icmp ne i64 %v1503, 0
  %cv1505 = zext i1 %cmp1504 to i32
  store i32 %cv1505, ptr %slot188, align 8
  %v1506 = load i32, ptr %slot188, align 8
  %cv1507 = zext i32 %v1506 to i64
  %cond1508 = icmp ne i64 %cv1507, 0
  br i1 %cond1508, label %bb_rcgnn218, label %bb_rcgdone218
bb_rcgnn218:
  %v1509 = load i64, ptr %slot187, align 8
  %op1510 = sub i64 %v1509, 16
  store i64 %op1510, ptr %slot189, align 8
  %v1511 = load i64, ptr %slot187, align 8
  %p1512 = inttoptr i64 %v1511 to ptr
  %rgep1513 = getelementptr i8, ptr %p1512, i64 -16
  %ld1514 = load i64, ptr %rgep1513, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1514, ptr %slot190, align 8
  %v1515 = load i64, ptr %slot190, align 8
  %op1516 = and i64 %v1515, 4611686018427387906
  store i64 %op1516, ptr %slot191, align 8
  %v1517 = load i64, ptr %slot191, align 8
  %cmp1518 = icmp ne i64 %v1517, 0
  %cv1519 = zext i1 %cmp1518 to i32
  store i32 %cv1519, ptr %slot192, align 8
  %v1520 = load i32, ptr %slot192, align 8
  %cv1521 = zext i32 %v1520 to i64
  %cond1522 = icmp ne i64 %cv1521, 0
  br i1 %cond1522, label %bb_rcgclear218, label %bb_rcgcounted218
bb_rcgcounted218:
  %v1523 = load i64, ptr %slot187, align 8
  %op1524 = sub i64 %v1523, 24
  store i64 %op1524, ptr %slot193, align 8
  %v1525 = load i64, ptr %slot187, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %rgep1527 = getelementptr i8, ptr %p1526, i64 -24
  %ld1528 = load i64, ptr %rgep1527, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1528, ptr %slot194, align 8
  %v1529 = load i64, ptr %slot194, align 8
  %op1530 = sub i64 %v1529, 1
  store i64 %op1530, ptr %slot195, align 8
  %v1531 = load i64, ptr %slot195, align 8
  %cmp1532 = icmp eq i64 %v1531, 0
  %cv1533 = zext i1 %cmp1532 to i32
  store i32 %cv1533, ptr %slot196, align 8
  %v1534 = load i32, ptr %slot196, align 8
  %cv1535 = zext i32 %v1534 to i64
  %cond1536 = icmp ne i64 %cv1535, 0
  br i1 %cond1536, label %bb_rcglast218, label %bb_rcgdec218
bb_rcglast218:
  %v1537 = load i64, ptr %slot187, align 8
  %op1538 = sub i64 %v1537, 32
  store i64 %op1538, ptr %slot197, align 8
  %v1539 = load i64, ptr %slot187, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  %rgep1541 = getelementptr i8, ptr %p1540, i64 -32
  %ld1542 = load i64, ptr %rgep1541, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1542, ptr %slot198, align 8
  %v1543 = load i64, ptr %slot198, align 8
  %cmp1544 = icmp ne i64 %v1543, 0
  %cv1545 = zext i1 %cmp1544 to i32
  store i32 %cv1545, ptr %slot199, align 8
  %v1546 = load i32, ptr %slot199, align 8
  %cv1547 = zext i32 %v1546 to i64
  %cond1548 = icmp ne i64 %cv1547, 0
  br i1 %cond1548, label %bb_rcgdec218, label %bb_rcgslow218
bb_rcgslow218:
  %v1549 = load i64, ptr %slot186, align 8
  %v1550 = load i64, ptr %slot183, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1549, i64 %v1550) nomerge, !dbg !130
  br label %bb_rcgdone218
bb_rcgdec218:
  %v1551 = load i64, ptr %slot195, align 8
  %v1552 = load i64, ptr %slot187, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  %rgep1554 = getelementptr i8, ptr %p1553, i64 -24
  store i64 %v1551, ptr %rgep1554, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear218
bb_rcgclear218:
  %v1555 = load i64, ptr %slot183, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  store i64 0, ptr %p1556, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone218
bb_rcgdone218:
  br label %bb_rcslotdone202
bb_rcslotowner202:
  %v1557 = load i64, ptr %slot38, align 8
  store i64 %v1557, ptr %slot200, align 8
  %v1558 = load i64, ptr %slot183, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  %ld1560 = load i64, ptr %p1559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1560, ptr %slot201, align 8
  %v1561 = load i64, ptr %slot201, align 8
  %cmp1562 = icmp ne i64 %v1561, 0
  %cv1563 = zext i1 %cmp1562 to i32
  store i32 %cv1563, ptr %slot202, align 8
  %v1564 = load i32, ptr %slot202, align 8
  %cv1565 = zext i32 %v1564 to i64
  %cond1566 = icmp ne i64 %cv1565, 0
  br i1 %cond1566, label %bb_rcgnn233, label %bb_rcgdone233
bb_rcgnn233:
  %v1567 = load i64, ptr %slot201, align 8
  %op1568 = sub i64 %v1567, 16
  store i64 %op1568, ptr %slot203, align 8
  %v1569 = load i64, ptr %slot201, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  %rgep1571 = getelementptr i8, ptr %p1570, i64 -16
  %ld1572 = load i64, ptr %rgep1571, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1572, ptr %slot204, align 8
  %v1573 = load i64, ptr %slot204, align 8
  %op1574 = and i64 %v1573, 4611686018427387906
  store i64 %op1574, ptr %slot205, align 8
  %v1575 = load i64, ptr %slot205, align 8
  %cmp1576 = icmp ne i64 %v1575, 0
  %cv1577 = zext i1 %cmp1576 to i32
  store i32 %cv1577, ptr %slot206, align 8
  %v1578 = load i32, ptr %slot206, align 8
  %cv1579 = zext i32 %v1578 to i64
  %cond1580 = icmp ne i64 %cv1579, 0
  br i1 %cond1580, label %bb_rcgclear233, label %bb_rcgcounted233
bb_rcgcounted233:
  %v1581 = load i64, ptr %slot201, align 8
  %op1582 = sub i64 %v1581, 32
  store i64 %op1582, ptr %slot207, align 8
  %v1583 = load i64, ptr %slot201, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %rgep1585 = getelementptr i8, ptr %p1584, i64 -32
  %ld1586 = load i64, ptr %rgep1585, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1586, ptr %slot208, align 8
  %v1587 = load i64, ptr %slot208, align 8
  %op1588 = sub i64 %v1587, 1
  store i64 %op1588, ptr %slot209, align 8
  %v1589 = load i64, ptr %slot209, align 8
  %cmp1590 = icmp eq i64 %v1589, 0
  %cv1591 = zext i1 %cmp1590 to i32
  store i32 %cv1591, ptr %slot210, align 8
  %v1592 = load i32, ptr %slot210, align 8
  %cv1593 = zext i32 %v1592 to i64
  %cond1594 = icmp ne i64 %cv1593, 0
  br i1 %cond1594, label %bb_rcglast233, label %bb_rcgdec233
bb_rcglast233:
  %v1595 = load i64, ptr %slot201, align 8
  %op1596 = sub i64 %v1595, 24
  store i64 %op1596, ptr %slot211, align 8
  %v1597 = load i64, ptr %slot201, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  %rgep1599 = getelementptr i8, ptr %p1598, i64 -24
  %ld1600 = load i64, ptr %rgep1599, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1600, ptr %slot212, align 8
  %v1601 = load i64, ptr %slot212, align 8
  %cmp1602 = icmp ne i64 %v1601, 0
  %cv1603 = zext i1 %cmp1602 to i32
  store i32 %cv1603, ptr %slot213, align 8
  %v1604 = load i32, ptr %slot213, align 8
  %cv1605 = zext i32 %v1604 to i64
  %cond1606 = icmp ne i64 %cv1605, 0
  br i1 %cond1606, label %bb_rcgdec233, label %bb_rcgslow233
bb_rcgslow233:
  %v1607 = load i64, ptr %slot200, align 8
  %v1608 = load i64, ptr %slot183, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1607, i64 %v1608) nomerge, !dbg !130
  br label %bb_rcgdone233
bb_rcgdec233:
  %v1609 = load i64, ptr %slot209, align 8
  %v1610 = load i64, ptr %slot201, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  %rgep1612 = getelementptr i8, ptr %p1611, i64 -32
  store i64 %v1609, ptr %rgep1612, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear233
bb_rcgclear233:
  %v1613 = load i64, ptr %slot183, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i64 0, ptr %p1614, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone233
bb_rcgdone233:
  br label %bb_rcslotdone202
bb_rcslotdone202:
  %v1615 = load i64, ptr %slot178, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %ret1617 = load { i64, i64 }, ptr %p1616, align 8
  ret { i64, i64 } %ret1617
bb_i21:
  %v1618 = load i64, ptr %slot19, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  %ld1620 = load i64, ptr %p1619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1620, ptr %slot214, align 8
  %v1621 = load i64, ptr %slot214, align 8
  %v1622 = load i64, ptr %slot21, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i64 %v1621, ptr %p1623, align 8, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot27, align 8
  store i64 %v1624, ptr %slot215, align 8
  %v1625 = load i64, ptr %slot215, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  store i32 0, ptr %p1626, align 4, !alias.scope !3, !noalias !4
  %v1627 = load i64, ptr %slot215, align 8
  %p1628 = inttoptr i64 %v1627 to ptr
  store i32 32, ptr %p1628, align 4, !alias.scope !3, !noalias !4
  %v1629 = load i64, ptr %slot215, align 8
  %v1630 = load i64, ptr %slot22, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i64 %v1629, ptr %p1631, align 8, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot21, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i64, ptr %p1633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1634, ptr %slot216, align 8
  %v1635 = load i64, ptr %slot22, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %ld1637 = load i64, ptr %p1636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1637, ptr %slot217, align 8
  %v1638 = load i64, ptr %slot1, align 8
  %v1639 = load i64, ptr %slot216, align 8
  %v1640 = load i64, ptr %slot217, align 8
  %call1641 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v1638, i64 %v1639, i64 %v1640) nomerge, !dbg !132
  store i64 %call1641, ptr %slot218, align 8
  %v1642 = load i64, ptr %slot218, align 8
  %v1643 = load i64, ptr %slot21, align 8
  %p1644 = inttoptr i64 %v1643 to ptr
  store i64 %v1642, ptr %p1644, align 8, !alias.scope !3, !noalias !4
  %v1645 = load i64, ptr %slot7, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  %ld1647 = load i32, ptr %p1646, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1647, ptr %slot219, align 8
  %v1648 = load i32, ptr %slot219, align 8
  %cv1649 = zext i32 %v1648 to i64
  %cond1650 = icmp ne i64 %cv1649, 0
  br i1 %cond1650, label %bb_rcslotdrop253, label %bb_rcslotdone253
bb_rcslotdrop253:
  %v1651 = load i64, ptr %slot7, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  store i32 0, ptr %p1652, align 4, !alias.scope !3, !noalias !4
  %v1653 = load i64, ptr %slot14, align 8
  store i64 %v1653, ptr %slot220, align 8
  %v1654 = load i64, ptr %slot8, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  %ld1656 = load i32, ptr %p1655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1656, ptr %slot221, align 8
  %v1657 = load i32, ptr %slot221, align 8
  %op1658 = and i32 %v1657, 28
  store i32 %op1658, ptr %slot222, align 8
  %v1659 = load i32, ptr %slot222, align 8
  %cv1660 = zext i32 %v1659 to i64
  %cond1661 = icmp ne i64 %cv1660, 0
  br i1 %cond1661, label %bb_rcslotrole253, label %bb_rcslotowner253
bb_rcslotrole253:
  %v1662 = load i64, ptr %slot38, align 8
  store i64 %v1662, ptr %slot223, align 8
  %v1663 = load i64, ptr %slot223, align 8
  %v1664 = load i64, ptr %slot220, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1663, i64 %v1664) nomerge, !dbg !132
  br label %bb_rcslotdone253
bb_rcslotowner253:
  %v1665 = load i64, ptr %slot38, align 8
  store i64 %v1665, ptr %slot224, align 8
  %v1666 = load i64, ptr %slot224, align 8
  %v1667 = load i64, ptr %slot220, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1666, i64 %v1667) nomerge, !dbg !132
  br label %bb_rcslotdone253
bb_rcslotdone253:
  %v1668 = load i64, ptr %slot21, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  %ld1670 = load i64, ptr %p1669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1670, ptr %slot225, align 8
  %v1671 = load i64, ptr %slot225, align 8
  %cond1672 = icmp ne i64 %v1671, 0
  br i1 %cond1672, label %bb_next261, label %bb_i28
bb_next261:
  %v1673 = load i64, ptr %slot19, align 8
  %p1674 = inttoptr i64 %v1673 to ptr
  %ld1675 = load i64, ptr %p1674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1675, ptr %slot226, align 8
  %v1676 = load i64, ptr %slot226, align 8
  %v1677 = load i64, ptr %slot21, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  store i64 %v1676, ptr %p1678, align 8, !alias.scope !3, !noalias !4
  %v1679 = load i64, ptr %slot21, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %ld1681 = load i64, ptr %p1680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1681, ptr %slot227, align 8
  %v1682 = load i64, ptr %slot1, align 8
  %v1683 = load i64, ptr %slot227, align 8
  %call1684 = call { i64, i64 } @myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166(i64 %v1682, i64 %v1683) nomerge, !dbg !134
  store { i64, i64 } %call1684, ptr %callresult229, align 8
  %addr1685 = ptrtoint ptr %callresult229 to i64
  store i64 %addr1685, ptr %slot228, align 8
  %v1686 = load i64, ptr %slot228, align 8
  %v1687 = load i64, ptr %slot21, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  store i64 %v1686, ptr %p1688, align 8, !alias.scope !3, !noalias !4
  %v1689 = load i64, ptr %slot7, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  %ld1691 = load i32, ptr %p1690, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1691, ptr %slot230, align 8
  %v1692 = load i32, ptr %slot230, align 8
  %cv1693 = zext i32 %v1692 to i64
  %cond1694 = icmp ne i64 %cv1693, 0
  br i1 %cond1694, label %bb_rcslotdrop266, label %bb_rcslotdone266
bb_rcslotdrop266:
  %v1695 = load i64, ptr %slot7, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  store i32 0, ptr %p1696, align 4, !alias.scope !3, !noalias !4
  %v1697 = load i64, ptr %slot14, align 8
  store i64 %v1697, ptr %slot231, align 8
  %v1698 = load i64, ptr %slot8, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  %ld1700 = load i32, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1700, ptr %slot232, align 8
  %v1701 = load i32, ptr %slot232, align 8
  %op1702 = and i32 %v1701, 28
  store i32 %op1702, ptr %slot233, align 8
  %v1703 = load i32, ptr %slot233, align 8
  %cv1704 = zext i32 %v1703 to i64
  %cond1705 = icmp ne i64 %cv1704, 0
  br i1 %cond1705, label %bb_rcslotrole266, label %bb_rcslotowner266
bb_rcslotrole266:
  %v1706 = load i64, ptr %slot38, align 8
  store i64 %v1706, ptr %slot234, align 8
  %v1707 = load i64, ptr %slot234, align 8
  %v1708 = load i64, ptr %slot231, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1707, i64 %v1708) nomerge, !dbg !134
  br label %bb_rcslotdone266
bb_rcslotowner266:
  %v1709 = load i64, ptr %slot38, align 8
  store i64 %v1709, ptr %slot235, align 8
  %v1710 = load i64, ptr %slot235, align 8
  %v1711 = load i64, ptr %slot231, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1710, i64 %v1711) nomerge, !dbg !134
  br label %bb_rcslotdone266
bb_rcslotdone266:
  %v1712 = load i64, ptr %slot21, align 8
  %p1713 = inttoptr i64 %v1712 to ptr
  %ld1714 = load i64, ptr %p1713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1714, ptr %slot236, align 8
  %v1715 = load i64, ptr %slot236, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  %ld1717 = load i32, ptr %p1716, align 4
  %ext1718 = zext i32 %ld1717 to i64
  store i64 %ext1718, ptr %slot237, align 8
  %v1719 = load i64, ptr %slot237, align 8
  %cmp1720 = icmp eq i64 %v1719, 1
  %cv1721 = zext i1 %cmp1720 to i64
  store i64 %cv1721, ptr %slot238, align 8
  %v1722 = load i64, ptr %slot238, align 8
  %cond1723 = icmp ne i64 %v1722, 0
  br i1 %cond1723, label %bb_errtrace275, label %bb_errtraced275
bb_errtrace275:
  %p1724 = inttoptr i64 ptrtoint (ptr @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1724, i64 8589934619) "call-inline-cost"="0", !dbg !136
  br label %bb_errtraced275
bb_errtraced275:
  %v1725 = load i64, ptr %slot7, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  %ld1727 = load i32, ptr %p1726, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1727, ptr %slot239, align 8
  %v1728 = load i32, ptr %slot239, align 8
  %cv1729 = zext i32 %v1728 to i64
  %cond1730 = icmp ne i64 %cv1729, 0
  br i1 %cond1730, label %bb_rcslotdrop278, label %bb_rcslotdone278
bb_rcslotdrop278:
  %v1731 = load i64, ptr %slot7, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i32 0, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone278
bb_rcslotdone278:
  %v1733 = load i64, ptr %slot5, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  %ld1735 = load i32, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1735, ptr %slot240, align 8
  %v1736 = load i32, ptr %slot240, align 8
  %cv1737 = zext i32 %v1736 to i64
  %cond1738 = icmp ne i64 %cv1737, 0
  br i1 %cond1738, label %bb_rcslotdrop281, label %bb_rcslotdone281
bb_rcslotdrop281:
  %v1739 = load i64, ptr %slot5, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i32 0, ptr %p1740, align 4, !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot20, align 8
  store i64 %v1741, ptr %slot241, align 8
  %v1742 = load i64, ptr %slot6, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %ld1744 = load i32, ptr %p1743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1744, ptr %slot242, align 8
  %v1745 = load i32, ptr %slot242, align 8
  %op1746 = and i32 %v1745, 28
  store i32 %op1746, ptr %slot243, align 8
  %v1747 = load i32, ptr %slot243, align 8
  %cv1748 = zext i32 %v1747 to i64
  %cond1749 = icmp ne i64 %cv1748, 0
  br i1 %cond1749, label %bb_rcslotrole281, label %bb_rcslotowner281
bb_rcslotrole281:
  %v1750 = load i64, ptr %slot38, align 8
  store i64 %v1750, ptr %slot244, align 8
  %v1751 = load i64, ptr %slot241, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  %ld1753 = load i64, ptr %p1752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1753, ptr %slot245, align 8
  %v1754 = load i64, ptr %slot245, align 8
  %cmp1755 = icmp ne i64 %v1754, 0
  %cv1756 = zext i1 %cmp1755 to i32
  store i32 %cv1756, ptr %slot246, align 8
  %v1757 = load i32, ptr %slot246, align 8
  %cv1758 = zext i32 %v1757 to i64
  %cond1759 = icmp ne i64 %cv1758, 0
  br i1 %cond1759, label %bb_rcgnn297, label %bb_rcgdone297
bb_rcgnn297:
  %v1760 = load i64, ptr %slot245, align 8
  %op1761 = sub i64 %v1760, 16
  store i64 %op1761, ptr %slot247, align 8
  %v1762 = load i64, ptr %slot245, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %rgep1764 = getelementptr i8, ptr %p1763, i64 -16
  %ld1765 = load i64, ptr %rgep1764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1765, ptr %slot248, align 8
  %v1766 = load i64, ptr %slot248, align 8
  %op1767 = and i64 %v1766, 4611686018427387906
  store i64 %op1767, ptr %slot249, align 8
  %v1768 = load i64, ptr %slot249, align 8
  %cmp1769 = icmp ne i64 %v1768, 0
  %cv1770 = zext i1 %cmp1769 to i32
  store i32 %cv1770, ptr %slot250, align 8
  %v1771 = load i32, ptr %slot250, align 8
  %cv1772 = zext i32 %v1771 to i64
  %cond1773 = icmp ne i64 %cv1772, 0
  br i1 %cond1773, label %bb_rcgclear297, label %bb_rcgcounted297
bb_rcgcounted297:
  %v1774 = load i64, ptr %slot245, align 8
  %op1775 = sub i64 %v1774, 24
  store i64 %op1775, ptr %slot251, align 8
  %v1776 = load i64, ptr %slot245, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  %rgep1778 = getelementptr i8, ptr %p1777, i64 -24
  %ld1779 = load i64, ptr %rgep1778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1779, ptr %slot252, align 8
  %v1780 = load i64, ptr %slot252, align 8
  %op1781 = sub i64 %v1780, 1
  store i64 %op1781, ptr %slot253, align 8
  %v1782 = load i64, ptr %slot253, align 8
  %cmp1783 = icmp eq i64 %v1782, 0
  %cv1784 = zext i1 %cmp1783 to i32
  store i32 %cv1784, ptr %slot254, align 8
  %v1785 = load i32, ptr %slot254, align 8
  %cv1786 = zext i32 %v1785 to i64
  %cond1787 = icmp ne i64 %cv1786, 0
  br i1 %cond1787, label %bb_rcglast297, label %bb_rcgdec297
bb_rcglast297:
  %v1788 = load i64, ptr %slot245, align 8
  %op1789 = sub i64 %v1788, 32
  store i64 %op1789, ptr %slot255, align 8
  %v1790 = load i64, ptr %slot245, align 8
  %p1791 = inttoptr i64 %v1790 to ptr
  %rgep1792 = getelementptr i8, ptr %p1791, i64 -32
  %ld1793 = load i64, ptr %rgep1792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1793, ptr %slot256, align 8
  %v1794 = load i64, ptr %slot256, align 8
  %cmp1795 = icmp ne i64 %v1794, 0
  %cv1796 = zext i1 %cmp1795 to i32
  store i32 %cv1796, ptr %slot257, align 8
  %v1797 = load i32, ptr %slot257, align 8
  %cv1798 = zext i32 %v1797 to i64
  %cond1799 = icmp ne i64 %cv1798, 0
  br i1 %cond1799, label %bb_rcgdec297, label %bb_rcgslow297
bb_rcgslow297:
  %v1800 = load i64, ptr %slot244, align 8
  %v1801 = load i64, ptr %slot241, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1800, i64 %v1801) nomerge, !dbg !136
  br label %bb_rcgdone297
bb_rcgdec297:
  %v1802 = load i64, ptr %slot253, align 8
  %v1803 = load i64, ptr %slot245, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %rgep1805 = getelementptr i8, ptr %p1804, i64 -24
  store i64 %v1802, ptr %rgep1805, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear297
bb_rcgclear297:
  %v1806 = load i64, ptr %slot241, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  store i64 0, ptr %p1807, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone297
bb_rcgdone297:
  br label %bb_rcslotdone281
bb_rcslotowner281:
  %v1808 = load i64, ptr %slot38, align 8
  store i64 %v1808, ptr %slot258, align 8
  %v1809 = load i64, ptr %slot241, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  %ld1811 = load i64, ptr %p1810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1811, ptr %slot259, align 8
  %v1812 = load i64, ptr %slot259, align 8
  %cmp1813 = icmp ne i64 %v1812, 0
  %cv1814 = zext i1 %cmp1813 to i32
  store i32 %cv1814, ptr %slot260, align 8
  %v1815 = load i32, ptr %slot260, align 8
  %cv1816 = zext i32 %v1815 to i64
  %cond1817 = icmp ne i64 %cv1816, 0
  br i1 %cond1817, label %bb_rcgnn312, label %bb_rcgdone312
bb_rcgnn312:
  %v1818 = load i64, ptr %slot259, align 8
  %op1819 = sub i64 %v1818, 16
  store i64 %op1819, ptr %slot261, align 8
  %v1820 = load i64, ptr %slot259, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  %rgep1822 = getelementptr i8, ptr %p1821, i64 -16
  %ld1823 = load i64, ptr %rgep1822, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1823, ptr %slot262, align 8
  %v1824 = load i64, ptr %slot262, align 8
  %op1825 = and i64 %v1824, 4611686018427387906
  store i64 %op1825, ptr %slot263, align 8
  %v1826 = load i64, ptr %slot263, align 8
  %cmp1827 = icmp ne i64 %v1826, 0
  %cv1828 = zext i1 %cmp1827 to i32
  store i32 %cv1828, ptr %slot264, align 8
  %v1829 = load i32, ptr %slot264, align 8
  %cv1830 = zext i32 %v1829 to i64
  %cond1831 = icmp ne i64 %cv1830, 0
  br i1 %cond1831, label %bb_rcgclear312, label %bb_rcgcounted312
bb_rcgcounted312:
  %v1832 = load i64, ptr %slot259, align 8
  %op1833 = sub i64 %v1832, 32
  store i64 %op1833, ptr %slot265, align 8
  %v1834 = load i64, ptr %slot259, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  %rgep1836 = getelementptr i8, ptr %p1835, i64 -32
  %ld1837 = load i64, ptr %rgep1836, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1837, ptr %slot266, align 8
  %v1838 = load i64, ptr %slot266, align 8
  %op1839 = sub i64 %v1838, 1
  store i64 %op1839, ptr %slot267, align 8
  %v1840 = load i64, ptr %slot267, align 8
  %cmp1841 = icmp eq i64 %v1840, 0
  %cv1842 = zext i1 %cmp1841 to i32
  store i32 %cv1842, ptr %slot268, align 8
  %v1843 = load i32, ptr %slot268, align 8
  %cv1844 = zext i32 %v1843 to i64
  %cond1845 = icmp ne i64 %cv1844, 0
  br i1 %cond1845, label %bb_rcglast312, label %bb_rcgdec312
bb_rcglast312:
  %v1846 = load i64, ptr %slot259, align 8
  %op1847 = sub i64 %v1846, 24
  store i64 %op1847, ptr %slot269, align 8
  %v1848 = load i64, ptr %slot259, align 8
  %p1849 = inttoptr i64 %v1848 to ptr
  %rgep1850 = getelementptr i8, ptr %p1849, i64 -24
  %ld1851 = load i64, ptr %rgep1850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1851, ptr %slot270, align 8
  %v1852 = load i64, ptr %slot270, align 8
  %cmp1853 = icmp ne i64 %v1852, 0
  %cv1854 = zext i1 %cmp1853 to i32
  store i32 %cv1854, ptr %slot271, align 8
  %v1855 = load i32, ptr %slot271, align 8
  %cv1856 = zext i32 %v1855 to i64
  %cond1857 = icmp ne i64 %cv1856, 0
  br i1 %cond1857, label %bb_rcgdec312, label %bb_rcgslow312
bb_rcgslow312:
  %v1858 = load i64, ptr %slot258, align 8
  %v1859 = load i64, ptr %slot241, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1858, i64 %v1859) nomerge, !dbg !136
  br label %bb_rcgdone312
bb_rcgdec312:
  %v1860 = load i64, ptr %slot267, align 8
  %v1861 = load i64, ptr %slot259, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  %rgep1863 = getelementptr i8, ptr %p1862, i64 -32
  store i64 %v1860, ptr %rgep1863, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear312
bb_rcgclear312:
  %v1864 = load i64, ptr %slot241, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  store i64 0, ptr %p1865, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone312
bb_rcgdone312:
  br label %bb_rcslotdone281
bb_rcslotdone281:
  %v1866 = load i64, ptr %slot236, align 8
  %p1867 = inttoptr i64 %v1866 to ptr
  %ret1868 = load { i64, i64 }, ptr %p1867, align 8
  ret { i64, i64 } %ret1868
bb_i28:
  %v1869 = load i64, ptr %slot19, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  %ld1871 = load i64, ptr %p1870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1871, ptr %slot272, align 8
  %v1872 = load i64, ptr %slot272, align 8
  %v1873 = load i64, ptr %slot21, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  store i64 %v1872, ptr %p1874, align 8, !alias.scope !3, !noalias !4
  %v1875 = load i64, ptr %slot28, align 8
  store i64 %v1875, ptr %slot273, align 8
  %v1876 = load i64, ptr %slot273, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i32 0, ptr %p1877, align 4, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot273, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  store i32 37, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  %v1880 = load i64, ptr %slot273, align 8
  %v1881 = load i64, ptr %slot22, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  store i64 %v1880, ptr %p1882, align 8, !alias.scope !3, !noalias !4
  %v1883 = load i64, ptr %slot21, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  %ld1885 = load i64, ptr %p1884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1885, ptr %slot274, align 8
  %v1886 = load i64, ptr %slot22, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  %ld1888 = load i64, ptr %p1887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1888, ptr %slot275, align 8
  %v1889 = load i64, ptr %slot1, align 8
  %v1890 = load i64, ptr %slot274, align 8
  %v1891 = load i64, ptr %slot275, align 8
  %call1892 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v1889, i64 %v1890, i64 %v1891) nomerge, !dbg !138
  store i64 %call1892, ptr %slot276, align 8
  %v1893 = load i64, ptr %slot276, align 8
  %v1894 = load i64, ptr %slot21, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  store i64 %v1893, ptr %p1895, align 8, !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot7, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %ld1898 = load i32, ptr %p1897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1898, ptr %slot277, align 8
  %v1899 = load i32, ptr %slot277, align 8
  %cv1900 = zext i32 %v1899 to i64
  %cond1901 = icmp ne i64 %cv1900, 0
  br i1 %cond1901, label %bb_rcslotdrop332, label %bb_rcslotdone332
bb_rcslotdrop332:
  %v1902 = load i64, ptr %slot7, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  store i32 0, ptr %p1903, align 4, !alias.scope !3, !noalias !4
  %v1904 = load i64, ptr %slot14, align 8
  store i64 %v1904, ptr %slot278, align 8
  %v1905 = load i64, ptr %slot8, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  %ld1907 = load i32, ptr %p1906, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1907, ptr %slot279, align 8
  %v1908 = load i32, ptr %slot279, align 8
  %op1909 = and i32 %v1908, 28
  store i32 %op1909, ptr %slot280, align 8
  %v1910 = load i32, ptr %slot280, align 8
  %cv1911 = zext i32 %v1910 to i64
  %cond1912 = icmp ne i64 %cv1911, 0
  br i1 %cond1912, label %bb_rcslotrole332, label %bb_rcslotowner332
bb_rcslotrole332:
  %v1913 = load i64, ptr %slot38, align 8
  store i64 %v1913, ptr %slot281, align 8
  %v1914 = load i64, ptr %slot281, align 8
  %v1915 = load i64, ptr %slot278, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1914, i64 %v1915) nomerge, !dbg !138
  br label %bb_rcslotdone332
bb_rcslotowner332:
  %v1916 = load i64, ptr %slot38, align 8
  store i64 %v1916, ptr %slot282, align 8
  %v1917 = load i64, ptr %slot282, align 8
  %v1918 = load i64, ptr %slot278, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1917, i64 %v1918) nomerge, !dbg !138
  br label %bb_rcslotdone332
bb_rcslotdone332:
  %v1919 = load i64, ptr %slot21, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i64, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1921, ptr %slot283, align 8
  %v1922 = load i64, ptr %slot283, align 8
  %cond1923 = icmp ne i64 %v1922, 0
  br i1 %cond1923, label %bb_next340, label %bb_i35
bb_next340:
  %v1924 = load i64, ptr %slot19, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %ld1926 = load i64, ptr %p1925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1926, ptr %slot284, align 8
  %v1927 = load i64, ptr %slot284, align 8
  %v1928 = load i64, ptr %slot21, align 8
  %p1929 = inttoptr i64 %v1928 to ptr
  store i64 %v1927, ptr %p1929, align 8, !alias.scope !3, !noalias !4
  %v1930 = load i64, ptr %slot21, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  %ld1932 = load i64, ptr %p1931, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1932, ptr %slot285, align 8
  %v1933 = load i64, ptr %slot1, align 8
  %v1934 = load i64, ptr %slot285, align 8
  %call1935 = call { i64, i64 } @myl_f_3d0ed1b0d0b04076bd3cd0e8349ea2cfddbbd0b8a1ecec907313fe976375cba2(i64 %v1933, i64 %v1934) nomerge, !dbg !140
  store { i64, i64 } %call1935, ptr %callresult287, align 8
  %addr1936 = ptrtoint ptr %callresult287 to i64
  store i64 %addr1936, ptr %slot286, align 8
  %v1937 = load i64, ptr %slot286, align 8
  %v1938 = load i64, ptr %slot21, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  store i64 %v1937, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  %v1940 = load i64, ptr %slot7, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  %ld1942 = load i32, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1942, ptr %slot288, align 8
  %v1943 = load i32, ptr %slot288, align 8
  %cv1944 = zext i32 %v1943 to i64
  %cond1945 = icmp ne i64 %cv1944, 0
  br i1 %cond1945, label %bb_rcslotdrop345, label %bb_rcslotdone345
bb_rcslotdrop345:
  %v1946 = load i64, ptr %slot7, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  store i32 0, ptr %p1947, align 4, !alias.scope !3, !noalias !4
  %v1948 = load i64, ptr %slot14, align 8
  store i64 %v1948, ptr %slot289, align 8
  %v1949 = load i64, ptr %slot8, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %ld1951 = load i32, ptr %p1950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1951, ptr %slot290, align 8
  %v1952 = load i32, ptr %slot290, align 8
  %op1953 = and i32 %v1952, 28
  store i32 %op1953, ptr %slot291, align 8
  %v1954 = load i32, ptr %slot291, align 8
  %cv1955 = zext i32 %v1954 to i64
  %cond1956 = icmp ne i64 %cv1955, 0
  br i1 %cond1956, label %bb_rcslotrole345, label %bb_rcslotowner345
bb_rcslotrole345:
  %v1957 = load i64, ptr %slot38, align 8
  store i64 %v1957, ptr %slot292, align 8
  %v1958 = load i64, ptr %slot292, align 8
  %v1959 = load i64, ptr %slot289, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1958, i64 %v1959) nomerge, !dbg !140
  br label %bb_rcslotdone345
bb_rcslotowner345:
  %v1960 = load i64, ptr %slot38, align 8
  store i64 %v1960, ptr %slot293, align 8
  %v1961 = load i64, ptr %slot293, align 8
  %v1962 = load i64, ptr %slot289, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1961, i64 %v1962) nomerge, !dbg !140
  br label %bb_rcslotdone345
bb_rcslotdone345:
  %v1963 = load i64, ptr %slot21, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  %ld1965 = load i64, ptr %p1964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1965, ptr %slot294, align 8
  %v1966 = load i64, ptr %slot294, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  %ld1968 = load i32, ptr %p1967, align 4
  %ext1969 = zext i32 %ld1968 to i64
  store i64 %ext1969, ptr %slot295, align 8
  %v1970 = load i64, ptr %slot295, align 8
  %cmp1971 = icmp eq i64 %v1970, 1
  %cv1972 = zext i1 %cmp1971 to i64
  store i64 %cv1972, ptr %slot296, align 8
  %v1973 = load i64, ptr %slot296, align 8
  %cond1974 = icmp ne i64 %v1973, 0
  br i1 %cond1974, label %bb_errtrace354, label %bb_errtraced354
bb_errtrace354:
  %p1975 = inttoptr i64 ptrtoint (ptr @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1975, i64 8589934626) "call-inline-cost"="0", !dbg !142
  br label %bb_errtraced354
bb_errtraced354:
  %v1976 = load i64, ptr %slot7, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  %ld1978 = load i32, ptr %p1977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1978, ptr %slot297, align 8
  %v1979 = load i32, ptr %slot297, align 8
  %cv1980 = zext i32 %v1979 to i64
  %cond1981 = icmp ne i64 %cv1980, 0
  br i1 %cond1981, label %bb_rcslotdrop357, label %bb_rcslotdone357
bb_rcslotdrop357:
  %v1982 = load i64, ptr %slot7, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  store i32 0, ptr %p1983, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone357
bb_rcslotdone357:
  %v1984 = load i64, ptr %slot5, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  %ld1986 = load i32, ptr %p1985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1986, ptr %slot298, align 8
  %v1987 = load i32, ptr %slot298, align 8
  %cv1988 = zext i32 %v1987 to i64
  %cond1989 = icmp ne i64 %cv1988, 0
  br i1 %cond1989, label %bb_rcslotdrop360, label %bb_rcslotdone360
bb_rcslotdrop360:
  %v1990 = load i64, ptr %slot5, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  store i32 0, ptr %p1991, align 4, !alias.scope !3, !noalias !4
  %v1992 = load i64, ptr %slot20, align 8
  store i64 %v1992, ptr %slot299, align 8
  %v1993 = load i64, ptr %slot6, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  %ld1995 = load i32, ptr %p1994, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1995, ptr %slot300, align 8
  %v1996 = load i32, ptr %slot300, align 8
  %op1997 = and i32 %v1996, 28
  store i32 %op1997, ptr %slot301, align 8
  %v1998 = load i32, ptr %slot301, align 8
  %cv1999 = zext i32 %v1998 to i64
  %cond2000 = icmp ne i64 %cv1999, 0
  br i1 %cond2000, label %bb_rcslotrole360, label %bb_rcslotowner360
bb_rcslotrole360:
  %v2001 = load i64, ptr %slot38, align 8
  store i64 %v2001, ptr %slot302, align 8
  %v2002 = load i64, ptr %slot299, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %ld2004 = load i64, ptr %p2003, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2004, ptr %slot303, align 8
  %v2005 = load i64, ptr %slot303, align 8
  %cmp2006 = icmp ne i64 %v2005, 0
  %cv2007 = zext i1 %cmp2006 to i32
  store i32 %cv2007, ptr %slot304, align 8
  %v2008 = load i32, ptr %slot304, align 8
  %cv2009 = zext i32 %v2008 to i64
  %cond2010 = icmp ne i64 %cv2009, 0
  br i1 %cond2010, label %bb_rcgnn376, label %bb_rcgdone376
bb_rcgnn376:
  %v2011 = load i64, ptr %slot303, align 8
  %op2012 = sub i64 %v2011, 16
  store i64 %op2012, ptr %slot305, align 8
  %v2013 = load i64, ptr %slot303, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  %rgep2015 = getelementptr i8, ptr %p2014, i64 -16
  %ld2016 = load i64, ptr %rgep2015, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2016, ptr %slot306, align 8
  %v2017 = load i64, ptr %slot306, align 8
  %op2018 = and i64 %v2017, 4611686018427387906
  store i64 %op2018, ptr %slot307, align 8
  %v2019 = load i64, ptr %slot307, align 8
  %cmp2020 = icmp ne i64 %v2019, 0
  %cv2021 = zext i1 %cmp2020 to i32
  store i32 %cv2021, ptr %slot308, align 8
  %v2022 = load i32, ptr %slot308, align 8
  %cv2023 = zext i32 %v2022 to i64
  %cond2024 = icmp ne i64 %cv2023, 0
  br i1 %cond2024, label %bb_rcgclear376, label %bb_rcgcounted376
bb_rcgcounted376:
  %v2025 = load i64, ptr %slot303, align 8
  %op2026 = sub i64 %v2025, 24
  store i64 %op2026, ptr %slot309, align 8
  %v2027 = load i64, ptr %slot303, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  %rgep2029 = getelementptr i8, ptr %p2028, i64 -24
  %ld2030 = load i64, ptr %rgep2029, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2030, ptr %slot310, align 8
  %v2031 = load i64, ptr %slot310, align 8
  %op2032 = sub i64 %v2031, 1
  store i64 %op2032, ptr %slot311, align 8
  %v2033 = load i64, ptr %slot311, align 8
  %cmp2034 = icmp eq i64 %v2033, 0
  %cv2035 = zext i1 %cmp2034 to i32
  store i32 %cv2035, ptr %slot312, align 8
  %v2036 = load i32, ptr %slot312, align 8
  %cv2037 = zext i32 %v2036 to i64
  %cond2038 = icmp ne i64 %cv2037, 0
  br i1 %cond2038, label %bb_rcglast376, label %bb_rcgdec376
bb_rcglast376:
  %v2039 = load i64, ptr %slot303, align 8
  %op2040 = sub i64 %v2039, 32
  store i64 %op2040, ptr %slot313, align 8
  %v2041 = load i64, ptr %slot303, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  %rgep2043 = getelementptr i8, ptr %p2042, i64 -32
  %ld2044 = load i64, ptr %rgep2043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2044, ptr %slot314, align 8
  %v2045 = load i64, ptr %slot314, align 8
  %cmp2046 = icmp ne i64 %v2045, 0
  %cv2047 = zext i1 %cmp2046 to i32
  store i32 %cv2047, ptr %slot315, align 8
  %v2048 = load i32, ptr %slot315, align 8
  %cv2049 = zext i32 %v2048 to i64
  %cond2050 = icmp ne i64 %cv2049, 0
  br i1 %cond2050, label %bb_rcgdec376, label %bb_rcgslow376
bb_rcgslow376:
  %v2051 = load i64, ptr %slot302, align 8
  %v2052 = load i64, ptr %slot299, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2051, i64 %v2052) nomerge, !dbg !142
  br label %bb_rcgdone376
bb_rcgdec376:
  %v2053 = load i64, ptr %slot311, align 8
  %v2054 = load i64, ptr %slot303, align 8
  %p2055 = inttoptr i64 %v2054 to ptr
  %rgep2056 = getelementptr i8, ptr %p2055, i64 -24
  store i64 %v2053, ptr %rgep2056, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear376
bb_rcgclear376:
  %v2057 = load i64, ptr %slot299, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  store i64 0, ptr %p2058, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone376
bb_rcgdone376:
  br label %bb_rcslotdone360
bb_rcslotowner360:
  %v2059 = load i64, ptr %slot38, align 8
  store i64 %v2059, ptr %slot316, align 8
  %v2060 = load i64, ptr %slot299, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %ld2062 = load i64, ptr %p2061, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2062, ptr %slot317, align 8
  %v2063 = load i64, ptr %slot317, align 8
  %cmp2064 = icmp ne i64 %v2063, 0
  %cv2065 = zext i1 %cmp2064 to i32
  store i32 %cv2065, ptr %slot318, align 8
  %v2066 = load i32, ptr %slot318, align 8
  %cv2067 = zext i32 %v2066 to i64
  %cond2068 = icmp ne i64 %cv2067, 0
  br i1 %cond2068, label %bb_rcgnn391, label %bb_rcgdone391
bb_rcgnn391:
  %v2069 = load i64, ptr %slot317, align 8
  %op2070 = sub i64 %v2069, 16
  store i64 %op2070, ptr %slot319, align 8
  %v2071 = load i64, ptr %slot317, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  %rgep2073 = getelementptr i8, ptr %p2072, i64 -16
  %ld2074 = load i64, ptr %rgep2073, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2074, ptr %slot320, align 8
  %v2075 = load i64, ptr %slot320, align 8
  %op2076 = and i64 %v2075, 4611686018427387906
  store i64 %op2076, ptr %slot321, align 8
  %v2077 = load i64, ptr %slot321, align 8
  %cmp2078 = icmp ne i64 %v2077, 0
  %cv2079 = zext i1 %cmp2078 to i32
  store i32 %cv2079, ptr %slot322, align 8
  %v2080 = load i32, ptr %slot322, align 8
  %cv2081 = zext i32 %v2080 to i64
  %cond2082 = icmp ne i64 %cv2081, 0
  br i1 %cond2082, label %bb_rcgclear391, label %bb_rcgcounted391
bb_rcgcounted391:
  %v2083 = load i64, ptr %slot317, align 8
  %op2084 = sub i64 %v2083, 32
  store i64 %op2084, ptr %slot323, align 8
  %v2085 = load i64, ptr %slot317, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  %rgep2087 = getelementptr i8, ptr %p2086, i64 -32
  %ld2088 = load i64, ptr %rgep2087, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2088, ptr %slot324, align 8
  %v2089 = load i64, ptr %slot324, align 8
  %op2090 = sub i64 %v2089, 1
  store i64 %op2090, ptr %slot325, align 8
  %v2091 = load i64, ptr %slot325, align 8
  %cmp2092 = icmp eq i64 %v2091, 0
  %cv2093 = zext i1 %cmp2092 to i32
  store i32 %cv2093, ptr %slot326, align 8
  %v2094 = load i32, ptr %slot326, align 8
  %cv2095 = zext i32 %v2094 to i64
  %cond2096 = icmp ne i64 %cv2095, 0
  br i1 %cond2096, label %bb_rcglast391, label %bb_rcgdec391
bb_rcglast391:
  %v2097 = load i64, ptr %slot317, align 8
  %op2098 = sub i64 %v2097, 24
  store i64 %op2098, ptr %slot327, align 8
  %v2099 = load i64, ptr %slot317, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  %rgep2101 = getelementptr i8, ptr %p2100, i64 -24
  %ld2102 = load i64, ptr %rgep2101, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2102, ptr %slot328, align 8
  %v2103 = load i64, ptr %slot328, align 8
  %cmp2104 = icmp ne i64 %v2103, 0
  %cv2105 = zext i1 %cmp2104 to i32
  store i32 %cv2105, ptr %slot329, align 8
  %v2106 = load i32, ptr %slot329, align 8
  %cv2107 = zext i32 %v2106 to i64
  %cond2108 = icmp ne i64 %cv2107, 0
  br i1 %cond2108, label %bb_rcgdec391, label %bb_rcgslow391
bb_rcgslow391:
  %v2109 = load i64, ptr %slot316, align 8
  %v2110 = load i64, ptr %slot299, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2109, i64 %v2110) nomerge, !dbg !142
  br label %bb_rcgdone391
bb_rcgdec391:
  %v2111 = load i64, ptr %slot325, align 8
  %v2112 = load i64, ptr %slot317, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  %rgep2114 = getelementptr i8, ptr %p2113, i64 -32
  store i64 %v2111, ptr %rgep2114, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear391
bb_rcgclear391:
  %v2115 = load i64, ptr %slot299, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i64 0, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone391
bb_rcgdone391:
  br label %bb_rcslotdone360
bb_rcslotdone360:
  %v2117 = load i64, ptr %slot294, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  %ret2119 = load { i64, i64 }, ptr %p2118, align 8
  ret { i64, i64 } %ret2119
bb_i35:
  %v2120 = load i64, ptr %slot19, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  %ld2122 = load i64, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2122, ptr %slot330, align 8
  %v2123 = load i64, ptr %slot330, align 8
  %v2124 = load i64, ptr %slot21, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  store i64 %v2123, ptr %p2125, align 8, !alias.scope !3, !noalias !4
  %v2126 = load i64, ptr %slot29, align 8
  store i64 %v2126, ptr %slot331, align 8
  %v2127 = load i64, ptr %slot331, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  store i32 0, ptr %p2128, align 4, !alias.scope !3, !noalias !4
  %v2129 = load i64, ptr %slot331, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  store i32 2, ptr %p2130, align 4, !alias.scope !3, !noalias !4
  %v2131 = load i64, ptr %slot331, align 8
  %v2132 = load i64, ptr %slot22, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  store i64 %v2131, ptr %p2133, align 8, !alias.scope !3, !noalias !4
  %v2134 = load i64, ptr %slot21, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  %ld2136 = load i64, ptr %p2135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2136, ptr %slot332, align 8
  %v2137 = load i64, ptr %slot22, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  %ld2139 = load i64, ptr %p2138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2139, ptr %slot333, align 8
  %v2140 = load i64, ptr %slot1, align 8
  %v2141 = load i64, ptr %slot332, align 8
  %v2142 = load i64, ptr %slot333, align 8
  %call2143 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v2140, i64 %v2141, i64 %v2142) nomerge, !dbg !144
  store i64 %call2143, ptr %slot334, align 8
  %v2144 = load i64, ptr %slot334, align 8
  %v2145 = load i64, ptr %slot21, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  store i64 %v2144, ptr %p2146, align 8, !alias.scope !3, !noalias !4
  %v2147 = load i64, ptr %slot7, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  %ld2149 = load i32, ptr %p2148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2149, ptr %slot335, align 8
  %v2150 = load i32, ptr %slot335, align 8
  %cv2151 = zext i32 %v2150 to i64
  %cond2152 = icmp ne i64 %cv2151, 0
  br i1 %cond2152, label %bb_rcslotdrop411, label %bb_rcslotdone411
bb_rcslotdrop411:
  %v2153 = load i64, ptr %slot7, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  store i32 0, ptr %p2154, align 4, !alias.scope !3, !noalias !4
  %v2155 = load i64, ptr %slot14, align 8
  store i64 %v2155, ptr %slot336, align 8
  %v2156 = load i64, ptr %slot8, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  %ld2158 = load i32, ptr %p2157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2158, ptr %slot337, align 8
  %v2159 = load i32, ptr %slot337, align 8
  %op2160 = and i32 %v2159, 28
  store i32 %op2160, ptr %slot338, align 8
  %v2161 = load i32, ptr %slot338, align 8
  %cv2162 = zext i32 %v2161 to i64
  %cond2163 = icmp ne i64 %cv2162, 0
  br i1 %cond2163, label %bb_rcslotrole411, label %bb_rcslotowner411
bb_rcslotrole411:
  %v2164 = load i64, ptr %slot38, align 8
  store i64 %v2164, ptr %slot339, align 8
  %v2165 = load i64, ptr %slot339, align 8
  %v2166 = load i64, ptr %slot336, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2165, i64 %v2166) nomerge, !dbg !144
  br label %bb_rcslotdone411
bb_rcslotowner411:
  %v2167 = load i64, ptr %slot38, align 8
  store i64 %v2167, ptr %slot340, align 8
  %v2168 = load i64, ptr %slot340, align 8
  %v2169 = load i64, ptr %slot336, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2168, i64 %v2169) nomerge, !dbg !144
  br label %bb_rcslotdone411
bb_rcslotdone411:
  %v2170 = load i64, ptr %slot21, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  %ld2172 = load i64, ptr %p2171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2172, ptr %slot341, align 8
  %v2173 = load i64, ptr %slot341, align 8
  %cond2174 = icmp ne i64 %v2173, 0
  br i1 %cond2174, label %bb_next419, label %bb_i54
bb_next419:
  %v2175 = load i64, ptr %slot19, align 8
  %p2176 = inttoptr i64 %v2175 to ptr
  %ld2177 = load i64, ptr %p2176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2177, ptr %slot342, align 8
  %v2178 = load i64, ptr %slot342, align 8
  %v2179 = load i64, ptr %slot21, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  store i64 %v2178, ptr %p2180, align 8, !alias.scope !3, !noalias !4
  %v2181 = load i64, ptr %slot21, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  %ld2183 = load i64, ptr %p2182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2183, ptr %slot343, align 8
  %v2184 = load i64, ptr %slot1, align 8
  %v2185 = load i64, ptr %slot343, align 8
  %call2186 = call { i64, i64 } @myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425(i64 %v2184, i64 %v2185) nomerge, !dbg !146
  store { i64, i64 } %call2186, ptr %callresult345, align 8
  %addr2187 = ptrtoint ptr %callresult345 to i64
  store i64 %addr2187, ptr %slot344, align 8
  %v2188 = load i64, ptr %slot344, align 8
  %v2189 = load i64, ptr %slot21, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  store i64 %v2188, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  %v2191 = load i64, ptr %slot21, align 8
  %p2192 = inttoptr i64 %v2191 to ptr
  %ld2193 = load i64, ptr %p2192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2193, ptr %slot346, align 8
  %v2194 = load i64, ptr %slot18, align 8
  store i64 %v2194, ptr %slot347, align 8
  %v2195 = load i64, ptr %slot346, align 8
  %v2196 = load i64, ptr %slot347, align 8
  %p2197 = inttoptr i64 %v2195 to ptr
  %p2198 = inttoptr i64 %v2196 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2198, ptr %p2197, i64 16, i1 false)
  %v2199 = load i64, ptr %slot12, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  store i32 2, ptr %p2200, align 4, !alias.scope !3, !noalias !4
  %v2201 = load i64, ptr %slot11, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  store i32 1, ptr %p2202, align 4, !alias.scope !3, !noalias !4
  %v2203 = load i64, ptr %slot7, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  %ld2205 = load i32, ptr %p2204, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2205, ptr %slot348, align 8
  %v2206 = load i32, ptr %slot348, align 8
  %cv2207 = zext i32 %v2206 to i64
  %cond2208 = icmp ne i64 %cv2207, 0
  br i1 %cond2208, label %bb_rcslotdrop428, label %bb_rcslotdone428
bb_rcslotdrop428:
  %v2209 = load i64, ptr %slot7, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  store i32 0, ptr %p2210, align 4, !alias.scope !3, !noalias !4
  %v2211 = load i64, ptr %slot14, align 8
  store i64 %v2211, ptr %slot349, align 8
  %v2212 = load i64, ptr %slot8, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  %ld2214 = load i32, ptr %p2213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2214, ptr %slot350, align 8
  %v2215 = load i32, ptr %slot350, align 8
  %op2216 = and i32 %v2215, 28
  store i32 %op2216, ptr %slot351, align 8
  %v2217 = load i32, ptr %slot351, align 8
  %cv2218 = zext i32 %v2217 to i64
  %cond2219 = icmp ne i64 %cv2218, 0
  br i1 %cond2219, label %bb_rcslotrole428, label %bb_rcslotowner428
bb_rcslotrole428:
  %v2220 = load i64, ptr %slot38, align 8
  store i64 %v2220, ptr %slot352, align 8
  %v2221 = load i64, ptr %slot352, align 8
  %v2222 = load i64, ptr %slot349, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2221, i64 %v2222) nomerge, !dbg !146
  br label %bb_rcslotdone428
bb_rcslotowner428:
  %v2223 = load i64, ptr %slot38, align 8
  store i64 %v2223, ptr %slot353, align 8
  %v2224 = load i64, ptr %slot353, align 8
  %v2225 = load i64, ptr %slot349, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2224, i64 %v2225) nomerge, !dbg !146
  br label %bb_rcslotdone428
bb_rcslotdone428:
  %v2226 = load i64, ptr %slot14, align 8
  store i64 %v2226, ptr %slot354, align 8
  %v2227 = load i64, ptr %slot18, align 8
  store i64 %v2227, ptr %slot355, align 8
  %v2228 = load i64, ptr %slot355, align 8
  %v2229 = load i64, ptr %slot354, align 8
  %p2230 = inttoptr i64 %v2228 to ptr
  %p2231 = inttoptr i64 %v2229 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2231, ptr %p2230, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2232 = load i64, ptr %slot8, align 8
  %p2233 = inttoptr i64 %v2232 to ptr
  store i32 2, ptr %p2233, align 4, !alias.scope !3, !noalias !4
  %v2234 = load i64, ptr %slot12, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  %ld2236 = load i32, ptr %p2235, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2236, ptr %slot356, align 8
  %v2237 = load i32, ptr %slot356, align 8
  %v2238 = load i64, ptr %slot8, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  store i32 %v2237, ptr %p2239, align 4, !alias.scope !3, !noalias !4
  %v2240 = load i64, ptr %slot11, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  store i32 0, ptr %p2241, align 4, !alias.scope !3, !noalias !4
  %v2242 = load i64, ptr %slot7, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  store i32 1, ptr %p2243, align 4, !alias.scope !3, !noalias !4
  %v2244 = load i64, ptr %slot354, align 8
  %v2245 = load i64, ptr %slot21, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  store i64 %v2244, ptr %p2246, align 8, !alias.scope !3, !noalias !4
  %v2247 = load i64, ptr %slot21, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  %ld2249 = load i64, ptr %p2248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2249, ptr %slot357, align 8
  %v2250 = load i64, ptr %slot357, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %ld2252 = load i32, ptr %p2251, align 4
  %ext2253 = zext i32 %ld2252 to i64
  store i64 %ext2253, ptr %slot358, align 8
  %v2254 = load i64, ptr %slot358, align 8
  %cmp2255 = icmp eq i64 %v2254, 0
  %cv2256 = zext i1 %cmp2255 to i64
  store i64 %cv2256, ptr %slot359, align 8
  %v2257 = load i64, ptr %slot359, align 8
  %cond2258 = icmp ne i64 %v2257, 0
  br i1 %cond2258, label %bb_rctryok444, label %bb_rctryerror444
bb_rctryerror444:
  %p2259 = inttoptr i64 ptrtoint (ptr @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2259, i64 12884901929) "call-inline-cost"="0", !dbg !148
  %v2260 = load i64, ptr %slot357, align 8
  %op2261 = add i64 %v2260, 8
  store i64 %op2261, ptr %slot360, align 8
  %v2262 = load i64, ptr %slot30, align 8
  store i64 %v2262, ptr %slot361, align 8
  %v2263 = load i64, ptr %slot361, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i64 0, ptr %p2264, align 8, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot361, align 8
  %p2267 = inttoptr i64 %v2265 to ptr
  %gep2268 = getelementptr i8, ptr %p2267, i64 8
  %op2266 = ptrtoint ptr %gep2268 to i64
  store i64 %op2266, ptr %slot362, align 8
  %v2269 = load i64, ptr %slot362, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  store i64 0, ptr %p2270, align 8, !alias.scope !3, !noalias !4
  %v2271 = load i64, ptr %slot361, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  store i32 1, ptr %p2272, align 4, !alias.scope !3, !noalias !4
  %v2273 = load i64, ptr %slot361, align 8
  %p2275 = inttoptr i64 %v2273 to ptr
  %gep2276 = getelementptr i8, ptr %p2275, i64 8
  %op2274 = ptrtoint ptr %gep2276 to i64
  store i64 %op2274, ptr %slot363, align 8
  %v2277 = load i64, ptr %slot13, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  store i32 1, ptr %p2278, align 4, !alias.scope !3, !noalias !4
  %v2279 = load i64, ptr %slot39, align 8
  store i64 %v2279, ptr %slot364, align 8
  %v2280 = load i64, ptr %slot361, align 8
  %v2281 = load i64, ptr %slot21, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  store i64 %v2280, ptr %p2282, align 8, !alias.scope !3, !noalias !4
  %v2283 = load i64, ptr %slot7, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  %ld2285 = load i32, ptr %p2284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2285, ptr %slot365, align 8
  %v2286 = load i32, ptr %slot365, align 8
  %cv2287 = zext i32 %v2286 to i64
  %cond2288 = icmp ne i64 %cv2287, 0
  br i1 %cond2288, label %bb_rcslotdrop455, label %bb_rcslotdone455
bb_rcslotdrop455:
  %v2289 = load i64, ptr %slot7, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  store i32 0, ptr %p2290, align 4, !alias.scope !3, !noalias !4
  %v2291 = load i64, ptr %slot14, align 8
  store i64 %v2291, ptr %slot366, align 8
  %v2292 = load i64, ptr %slot8, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  %ld2294 = load i32, ptr %p2293, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2294, ptr %slot367, align 8
  %v2295 = load i32, ptr %slot367, align 8
  %op2296 = and i32 %v2295, 28
  store i32 %op2296, ptr %slot368, align 8
  %v2297 = load i32, ptr %slot368, align 8
  %cv2298 = zext i32 %v2297 to i64
  %cond2299 = icmp ne i64 %cv2298, 0
  br i1 %cond2299, label %bb_rcslotrole455, label %bb_rcslotowner455
bb_rcslotrole455:
  %v2300 = load i64, ptr %slot38, align 8
  store i64 %v2300, ptr %slot369, align 8
  %v2301 = load i64, ptr %slot369, align 8
  %v2302 = load i64, ptr %slot366, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_unloan(i64 %v2301, i64 %v2302) nomerge, !dbg !148
  br label %bb_rcslotdone455
bb_rcslotowner455:
  %v2303 = load i64, ptr %slot38, align 8
  store i64 %v2303, ptr %slot370, align 8
  %v2304 = load i64, ptr %slot370, align 8
  %v2305 = load i64, ptr %slot366, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_drop(i64 %v2304, i64 %v2305) nomerge, !dbg !148
  br label %bb_rcslotdone455
bb_rcslotdone455:
  br label %bb_i43
bb_rctryok444:
  %v2306 = load i64, ptr %slot30, align 8
  store i64 %v2306, ptr %slot371, align 8
  %v2307 = load i64, ptr %slot371, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  store i64 0, ptr %p2308, align 8, !alias.scope !3, !noalias !4
  %v2309 = load i64, ptr %slot13, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  store i32 1, ptr %p2310, align 4, !alias.scope !3, !noalias !4
  %v2311 = load i64, ptr %slot357, align 8
  %op2312 = add i64 %v2311, 8
  store i64 %op2312, ptr %slot372, align 8
  %v2313 = load i64, ptr %slot39, align 8
  store i64 %v2313, ptr %slot373, align 8
  %v2314 = load i64, ptr %slot372, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %ld2316 = load i64, ptr %p2315, align 8
  store i64 %ld2316, ptr %slot374, align 8
  %v2317 = load i64, ptr %slot374, align 8
  %cmp2318 = icmp ne i64 %v2317, 0
  %cv2319 = zext i1 %cmp2318 to i32
  store i32 %cv2319, ptr %slot375, align 8
  %v2320 = load i32, ptr %slot375, align 8
  %cv2321 = zext i32 %v2320 to i64
  %cond2322 = icmp ne i64 %cv2321, 0
  br i1 %cond2322, label %bb_rcgnn468, label %bb_rcgplain468
bb_rcgnn468:
  %v2323 = load i64, ptr %slot374, align 8
  %op2324 = sub i64 %v2323, 16
  store i64 %op2324, ptr %slot376, align 8
  %v2325 = load i64, ptr %slot374, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  %rgep2327 = getelementptr i8, ptr %p2326, i64 -16
  %ld2328 = load i64, ptr %rgep2327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2328, ptr %slot377, align 8
  %v2329 = load i64, ptr %slot377, align 8
  %op2330 = and i64 %v2329, 4611686018427387906
  store i64 %op2330, ptr %slot378, align 8
  %v2331 = load i64, ptr %slot378, align 8
  %cmp2332 = icmp ne i64 %v2331, 0
  %cv2333 = zext i1 %cmp2332 to i32
  store i32 %cv2333, ptr %slot379, align 8
  %v2334 = load i32, ptr %slot379, align 8
  %cv2335 = zext i32 %v2334 to i64
  %cond2336 = icmp ne i64 %cv2335, 0
  br i1 %cond2336, label %bb_rcgspecial468, label %bb_rcginc468
bb_rcginc468:
  %v2337 = load i64, ptr %slot374, align 8
  %op2338 = sub i64 %v2337, 32
  store i64 %op2338, ptr %slot380, align 8
  %v2339 = load i64, ptr %slot374, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  %rgep2341 = getelementptr i8, ptr %p2340, i64 -32
  %ld2342 = load i64, ptr %rgep2341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2342, ptr %slot381, align 8
  %v2343 = load i64, ptr %slot381, align 8
  %op2344 = add i64 %v2343, 1
  store i64 %op2344, ptr %slot382, align 8
  %v2345 = load i64, ptr %slot382, align 8
  %cmp2346 = icmp eq i64 %v2345, 0
  %cv2347 = zext i1 %cmp2346 to i32
  store i32 %cv2347, ptr %slot383, align 8
  %v2348 = load i32, ptr %slot383, align 8
  %cv2349 = zext i32 %v2348 to i64
  %cond2350 = icmp ne i64 %cv2349, 0
  br i1 %cond2350, label %bb_rcglimit468, label %bb_rcgcapacity468
bb_rcglimit468:
  %v2351 = load i64, ptr %slot1, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %call2353 = call i32 @myl_qbe_rc_status(ptr %p2352, i32 2) nomerge, !dbg !148
  store i32 %call2353, ptr %slot384, align 8
  br label %bb_failure
bb_rcgcapacity468:
  %v2354 = load i64, ptr %slot382, align 8
  %v2355 = load i64, ptr %slot374, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  %rgep2357 = getelementptr i8, ptr %p2356, i64 -32
  store i64 %v2354, ptr %rgep2357, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain468
bb_rcgspecial468:
  %v2358 = load i64, ptr %slot377, align 8
  %op2359 = and i64 %v2358, 4611686018427387904
  store i64 %op2359, ptr %slot385, align 8
  %v2360 = load i64, ptr %slot385, align 8
  %cmp2361 = icmp ne i64 %v2360, 0
  %cv2362 = zext i1 %cmp2361 to i32
  store i32 %cv2362, ptr %slot386, align 8
  %v2363 = load i32, ptr %slot386, align 8
  %cv2364 = zext i32 %v2363 to i64
  %cond2365 = icmp ne i64 %cv2364, 0
  br i1 %cond2365, label %bb_rcgslow468, label %bb_rcgplain468
bb_rcgslow468:
  %v2366 = load i64, ptr %slot38, align 8
  %v2367 = load i64, ptr %slot371, align 8
  %v2368 = load i64, ptr %slot372, align 8
  %v2369 = load i64, ptr %slot373, align 8
  %cv2370 = trunc i64 %v2369 to i32
  %call2371 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v2366, i64 %v2367, i64 %v2368, i32 %cv2370) nomerge, !dbg !148
  store i32 %call2371, ptr %slot387, align 8
  %v2372 = load i32, ptr %slot387, align 8
  %cv2373 = zext i32 %v2372 to i64
  %cond2374 = icmp ne i64 %cv2373, 0
  br i1 %cond2374, label %bb_rcsuccess482, label %bb_rcfailure482
bb_rcfailure482:
  %v2375 = load i64, ptr %slot38, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  %call2377 = call i32 @myl_rc_take_failure(ptr %p2376) nomerge, !dbg !148
  store i32 %call2377, ptr %slot388, align 8
  %v2378 = load i64, ptr %slot1, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  %v2380 = load i32, ptr %slot388, align 8
  %call2381 = call i32 @myl_qbe_rc_status(ptr %p2379, i32 %v2380) nomerge, !dbg !148
  store i32 %call2381, ptr %slot389, align 8
  br label %bb_failure
bb_rcsuccess482:
  br label %bb_rcgdone468
bb_rcgplain468:
  %v2382 = load i64, ptr %slot374, align 8
  %v2383 = load i64, ptr %slot371, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  store i64 %v2382, ptr %p2384, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone468
bb_rcgdone468:
  %v2385 = load i64, ptr %slot371, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  %ld2387 = load i64, ptr %p2386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2387, ptr %slot390, align 8
  %v2388 = load i64, ptr %slot390, align 8
  %v2389 = load i64, ptr %slot21, align 8
  %p2390 = inttoptr i64 %v2389 to ptr
  store i64 %v2388, ptr %p2390, align 8, !alias.scope !3, !noalias !4
  %v2391 = load i64, ptr %slot21, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  %ld2393 = load i64, ptr %p2392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2393, ptr %slot391, align 8
  %v2394 = load i64, ptr %slot391, align 8
  %v2395 = load i64, ptr %slot16, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  store i64 %v2394, ptr %p2396, align 8, !alias.scope !3, !noalias !4
  %v2397 = load i64, ptr %slot16, align 8
  store i64 %v2397, ptr %slot392, align 8
  %v2398 = load i64, ptr %slot18, align 8
  store i64 %v2398, ptr %slot393, align 8
  %v2399 = load i64, ptr %slot392, align 8
  %v2400 = load i64, ptr %slot393, align 8
  %p2401 = inttoptr i64 %v2399 to ptr
  %p2402 = inttoptr i64 %v2400 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2402, ptr %p2401, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2403 = load i64, ptr %slot12, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  store i32 2, ptr %p2404, align 4, !alias.scope !3, !noalias !4
  %v2405 = load i64, ptr %slot11, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  store i32 1, ptr %p2406, align 4, !alias.scope !3, !noalias !4
  %v2407 = load i64, ptr %slot7, align 8
  %p2408 = inttoptr i64 %v2407 to ptr
  %ld2409 = load i32, ptr %p2408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2409, ptr %slot394, align 8
  %v2410 = load i32, ptr %slot394, align 8
  %cv2411 = zext i32 %v2410 to i64
  %cond2412 = icmp ne i64 %cv2411, 0
  br i1 %cond2412, label %bb_rcslotdrop493, label %bb_rcslotdone493
bb_rcslotdrop493:
  %v2413 = load i64, ptr %slot7, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  store i32 0, ptr %p2414, align 4, !alias.scope !3, !noalias !4
  %v2415 = load i64, ptr %slot14, align 8
  store i64 %v2415, ptr %slot395, align 8
  %v2416 = load i64, ptr %slot8, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  %ld2418 = load i32, ptr %p2417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2418, ptr %slot396, align 8
  %v2419 = load i32, ptr %slot396, align 8
  %op2420 = and i32 %v2419, 28
  store i32 %op2420, ptr %slot397, align 8
  %v2421 = load i32, ptr %slot397, align 8
  %cv2422 = zext i32 %v2421 to i64
  %cond2423 = icmp ne i64 %cv2422, 0
  br i1 %cond2423, label %bb_rcslotrole493, label %bb_rcslotowner493
bb_rcslotrole493:
  %v2424 = load i64, ptr %slot38, align 8
  store i64 %v2424, ptr %slot398, align 8
  %v2425 = load i64, ptr %slot398, align 8
  %v2426 = load i64, ptr %slot395, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_unloan(i64 %v2425, i64 %v2426) nomerge, !dbg !148
  br label %bb_rcslotdone493
bb_rcslotowner493:
  %v2427 = load i64, ptr %slot38, align 8
  store i64 %v2427, ptr %slot399, align 8
  %v2428 = load i64, ptr %slot399, align 8
  %v2429 = load i64, ptr %slot395, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_drop(i64 %v2428, i64 %v2429) nomerge, !dbg !148
  br label %bb_rcslotdone493
bb_rcslotdone493:
  %v2430 = load i64, ptr %slot14, align 8
  store i64 %v2430, ptr %slot400, align 8
  %v2431 = load i64, ptr %slot18, align 8
  store i64 %v2431, ptr %slot401, align 8
  %v2432 = load i64, ptr %slot401, align 8
  %v2433 = load i64, ptr %slot400, align 8
  %p2434 = inttoptr i64 %v2432 to ptr
  %p2435 = inttoptr i64 %v2433 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2435, ptr %p2434, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2436 = load i64, ptr %slot8, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  store i32 2, ptr %p2437, align 4, !alias.scope !3, !noalias !4
  %v2438 = load i64, ptr %slot12, align 8
  %p2439 = inttoptr i64 %v2438 to ptr
  %ld2440 = load i32, ptr %p2439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2440, ptr %slot402, align 8
  %v2441 = load i32, ptr %slot402, align 8
  %v2442 = load i64, ptr %slot8, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  store i32 %v2441, ptr %p2443, align 4, !alias.scope !3, !noalias !4
  %v2444 = load i64, ptr %slot11, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  store i32 0, ptr %p2445, align 4, !alias.scope !3, !noalias !4
  %v2446 = load i64, ptr %slot7, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  store i32 1, ptr %p2447, align 4, !alias.scope !3, !noalias !4
  %v2448 = load i64, ptr %slot400, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  %ld2450 = load i64, ptr %p2449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2450, ptr %slot403, align 8
  %v2451 = load i64, ptr %slot403, align 8
  %v2452 = load i64, ptr %slot21, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  store i64 %v2451, ptr %p2453, align 8, !alias.scope !3, !noalias !4
  br label %bb_i44
bb_i43:
  %v2454 = load i64, ptr %slot21, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %ld2456 = load i64, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2456, ptr %slot404, align 8
  %v2457 = load i64, ptr %slot7, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  %ld2459 = load i32, ptr %p2458, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2459, ptr %slot405, align 8
  %v2460 = load i32, ptr %slot405, align 8
  %cv2461 = zext i32 %v2460 to i64
  %cond2462 = icmp ne i64 %cv2461, 0
  br i1 %cond2462, label %bb_rcslotdrop512, label %bb_rcslotdone512
bb_rcslotdrop512:
  %v2463 = load i64, ptr %slot7, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  store i32 0, ptr %p2464, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone512
bb_rcslotdone512:
  %v2465 = load i64, ptr %slot5, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  %ld2467 = load i32, ptr %p2466, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2467, ptr %slot406, align 8
  %v2468 = load i32, ptr %slot406, align 8
  %cv2469 = zext i32 %v2468 to i64
  %cond2470 = icmp ne i64 %cv2469, 0
  br i1 %cond2470, label %bb_rcslotdrop515, label %bb_rcslotdone515
bb_rcslotdrop515:
  %v2471 = load i64, ptr %slot5, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  store i32 0, ptr %p2472, align 4, !alias.scope !3, !noalias !4
  %v2473 = load i64, ptr %slot20, align 8
  store i64 %v2473, ptr %slot407, align 8
  %v2474 = load i64, ptr %slot6, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  %ld2476 = load i32, ptr %p2475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2476, ptr %slot408, align 8
  %v2477 = load i32, ptr %slot408, align 8
  %op2478 = and i32 %v2477, 28
  store i32 %op2478, ptr %slot409, align 8
  %v2479 = load i32, ptr %slot409, align 8
  %cv2480 = zext i32 %v2479 to i64
  %cond2481 = icmp ne i64 %cv2480, 0
  br i1 %cond2481, label %bb_rcslotrole515, label %bb_rcslotowner515
bb_rcslotrole515:
  %v2482 = load i64, ptr %slot38, align 8
  store i64 %v2482, ptr %slot410, align 8
  %v2483 = load i64, ptr %slot407, align 8
  %p2484 = inttoptr i64 %v2483 to ptr
  %ld2485 = load i64, ptr %p2484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2485, ptr %slot411, align 8
  %v2486 = load i64, ptr %slot411, align 8
  %cmp2487 = icmp ne i64 %v2486, 0
  %cv2488 = zext i1 %cmp2487 to i32
  store i32 %cv2488, ptr %slot412, align 8
  %v2489 = load i32, ptr %slot412, align 8
  %cv2490 = zext i32 %v2489 to i64
  %cond2491 = icmp ne i64 %cv2490, 0
  br i1 %cond2491, label %bb_rcgnn531, label %bb_rcgdone531
bb_rcgnn531:
  %v2492 = load i64, ptr %slot411, align 8
  %op2493 = sub i64 %v2492, 16
  store i64 %op2493, ptr %slot413, align 8
  %v2494 = load i64, ptr %slot411, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  %rgep2496 = getelementptr i8, ptr %p2495, i64 -16
  %ld2497 = load i64, ptr %rgep2496, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2497, ptr %slot414, align 8
  %v2498 = load i64, ptr %slot414, align 8
  %op2499 = and i64 %v2498, 4611686018427387906
  store i64 %op2499, ptr %slot415, align 8
  %v2500 = load i64, ptr %slot415, align 8
  %cmp2501 = icmp ne i64 %v2500, 0
  %cv2502 = zext i1 %cmp2501 to i32
  store i32 %cv2502, ptr %slot416, align 8
  %v2503 = load i32, ptr %slot416, align 8
  %cv2504 = zext i32 %v2503 to i64
  %cond2505 = icmp ne i64 %cv2504, 0
  br i1 %cond2505, label %bb_rcgclear531, label %bb_rcgcounted531
bb_rcgcounted531:
  %v2506 = load i64, ptr %slot411, align 8
  %op2507 = sub i64 %v2506, 24
  store i64 %op2507, ptr %slot417, align 8
  %v2508 = load i64, ptr %slot411, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  %rgep2510 = getelementptr i8, ptr %p2509, i64 -24
  %ld2511 = load i64, ptr %rgep2510, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2511, ptr %slot418, align 8
  %v2512 = load i64, ptr %slot418, align 8
  %op2513 = sub i64 %v2512, 1
  store i64 %op2513, ptr %slot419, align 8
  %v2514 = load i64, ptr %slot419, align 8
  %cmp2515 = icmp eq i64 %v2514, 0
  %cv2516 = zext i1 %cmp2515 to i32
  store i32 %cv2516, ptr %slot420, align 8
  %v2517 = load i32, ptr %slot420, align 8
  %cv2518 = zext i32 %v2517 to i64
  %cond2519 = icmp ne i64 %cv2518, 0
  br i1 %cond2519, label %bb_rcglast531, label %bb_rcgdec531
bb_rcglast531:
  %v2520 = load i64, ptr %slot411, align 8
  %op2521 = sub i64 %v2520, 32
  store i64 %op2521, ptr %slot421, align 8
  %v2522 = load i64, ptr %slot411, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  %rgep2524 = getelementptr i8, ptr %p2523, i64 -32
  %ld2525 = load i64, ptr %rgep2524, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2525, ptr %slot422, align 8
  %v2526 = load i64, ptr %slot422, align 8
  %cmp2527 = icmp ne i64 %v2526, 0
  %cv2528 = zext i1 %cmp2527 to i32
  store i32 %cv2528, ptr %slot423, align 8
  %v2529 = load i32, ptr %slot423, align 8
  %cv2530 = zext i32 %v2529 to i64
  %cond2531 = icmp ne i64 %cv2530, 0
  br i1 %cond2531, label %bb_rcgdec531, label %bb_rcgslow531
bb_rcgslow531:
  %v2532 = load i64, ptr %slot410, align 8
  %v2533 = load i64, ptr %slot407, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2532, i64 %v2533) nomerge, !dbg !150
  br label %bb_rcgdone531
bb_rcgdec531:
  %v2534 = load i64, ptr %slot419, align 8
  %v2535 = load i64, ptr %slot411, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  %rgep2537 = getelementptr i8, ptr %p2536, i64 -24
  store i64 %v2534, ptr %rgep2537, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear531
bb_rcgclear531:
  %v2538 = load i64, ptr %slot407, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  store i64 0, ptr %p2539, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone531
bb_rcgdone531:
  br label %bb_rcslotdone515
bb_rcslotowner515:
  %v2540 = load i64, ptr %slot38, align 8
  store i64 %v2540, ptr %slot424, align 8
  %v2541 = load i64, ptr %slot407, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  %ld2543 = load i64, ptr %p2542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2543, ptr %slot425, align 8
  %v2544 = load i64, ptr %slot425, align 8
  %cmp2545 = icmp ne i64 %v2544, 0
  %cv2546 = zext i1 %cmp2545 to i32
  store i32 %cv2546, ptr %slot426, align 8
  %v2547 = load i32, ptr %slot426, align 8
  %cv2548 = zext i32 %v2547 to i64
  %cond2549 = icmp ne i64 %cv2548, 0
  br i1 %cond2549, label %bb_rcgnn546, label %bb_rcgdone546
bb_rcgnn546:
  %v2550 = load i64, ptr %slot425, align 8
  %op2551 = sub i64 %v2550, 16
  store i64 %op2551, ptr %slot427, align 8
  %v2552 = load i64, ptr %slot425, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  %rgep2554 = getelementptr i8, ptr %p2553, i64 -16
  %ld2555 = load i64, ptr %rgep2554, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2555, ptr %slot428, align 8
  %v2556 = load i64, ptr %slot428, align 8
  %op2557 = and i64 %v2556, 4611686018427387906
  store i64 %op2557, ptr %slot429, align 8
  %v2558 = load i64, ptr %slot429, align 8
  %cmp2559 = icmp ne i64 %v2558, 0
  %cv2560 = zext i1 %cmp2559 to i32
  store i32 %cv2560, ptr %slot430, align 8
  %v2561 = load i32, ptr %slot430, align 8
  %cv2562 = zext i32 %v2561 to i64
  %cond2563 = icmp ne i64 %cv2562, 0
  br i1 %cond2563, label %bb_rcgclear546, label %bb_rcgcounted546
bb_rcgcounted546:
  %v2564 = load i64, ptr %slot425, align 8
  %op2565 = sub i64 %v2564, 32
  store i64 %op2565, ptr %slot431, align 8
  %v2566 = load i64, ptr %slot425, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  %rgep2568 = getelementptr i8, ptr %p2567, i64 -32
  %ld2569 = load i64, ptr %rgep2568, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2569, ptr %slot432, align 8
  %v2570 = load i64, ptr %slot432, align 8
  %op2571 = sub i64 %v2570, 1
  store i64 %op2571, ptr %slot433, align 8
  %v2572 = load i64, ptr %slot433, align 8
  %cmp2573 = icmp eq i64 %v2572, 0
  %cv2574 = zext i1 %cmp2573 to i32
  store i32 %cv2574, ptr %slot434, align 8
  %v2575 = load i32, ptr %slot434, align 8
  %cv2576 = zext i32 %v2575 to i64
  %cond2577 = icmp ne i64 %cv2576, 0
  br i1 %cond2577, label %bb_rcglast546, label %bb_rcgdec546
bb_rcglast546:
  %v2578 = load i64, ptr %slot425, align 8
  %op2579 = sub i64 %v2578, 24
  store i64 %op2579, ptr %slot435, align 8
  %v2580 = load i64, ptr %slot425, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  %rgep2582 = getelementptr i8, ptr %p2581, i64 -24
  %ld2583 = load i64, ptr %rgep2582, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2583, ptr %slot436, align 8
  %v2584 = load i64, ptr %slot436, align 8
  %cmp2585 = icmp ne i64 %v2584, 0
  %cv2586 = zext i1 %cmp2585 to i32
  store i32 %cv2586, ptr %slot437, align 8
  %v2587 = load i32, ptr %slot437, align 8
  %cv2588 = zext i32 %v2587 to i64
  %cond2589 = icmp ne i64 %cv2588, 0
  br i1 %cond2589, label %bb_rcgdec546, label %bb_rcgslow546
bb_rcgslow546:
  %v2590 = load i64, ptr %slot424, align 8
  %v2591 = load i64, ptr %slot407, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2590, i64 %v2591) nomerge, !dbg !150
  br label %bb_rcgdone546
bb_rcgdec546:
  %v2592 = load i64, ptr %slot433, align 8
  %v2593 = load i64, ptr %slot425, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  %rgep2595 = getelementptr i8, ptr %p2594, i64 -32
  store i64 %v2592, ptr %rgep2595, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear546
bb_rcgclear546:
  %v2596 = load i64, ptr %slot407, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  store i64 0, ptr %p2597, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone546
bb_rcgdone546:
  br label %bb_rcslotdone515
bb_rcslotdone515:
  %v2598 = load i64, ptr %slot404, align 8
  %p2599 = inttoptr i64 %v2598 to ptr
  %ret2600 = load { i64, i64 }, ptr %p2599, align 8
  ret { i64, i64 } %ret2600
bb_i44:
  %v2601 = load i64, ptr %slot21, align 8
  %p2602 = inttoptr i64 %v2601 to ptr
  %ld2603 = load i64, ptr %p2602, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2603, ptr %slot438, align 8
  %v2604 = load i64, ptr %slot438, align 8
  %v2605 = load i64, ptr %slot16, align 8
  %p2606 = inttoptr i64 %v2605 to ptr
  store i64 %v2604, ptr %p2606, align 8, !alias.scope !3, !noalias !4
  %v2607 = load i64, ptr %slot16, align 8
  store i64 %v2607, ptr %slot439, align 8
  %v2608 = load i64, ptr %slot7, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  %ld2610 = load i32, ptr %p2609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2610, ptr %slot440, align 8
  %v2611 = load i64, ptr %slot8, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %ld2613 = load i32, ptr %p2612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2613, ptr %slot441, align 8
  %v2614 = load i32, ptr %slot441, align 8
  %op2615 = and i32 %v2614, 24
  store i32 %op2615, ptr %slot441, align 8
  %v2616 = load i32, ptr %slot441, align 8
  %cmp2617 = icmp eq i32 %v2616, 0
  %cv2618 = zext i1 %cmp2617 to i32
  store i32 %cv2618, ptr %slot442, align 8
  %v2619 = load i32, ptr %slot440, align 8
  %v2620 = load i32, ptr %slot442, align 8
  %op2621 = and i32 %v2619, %v2620
  store i32 %op2621, ptr %slot443, align 8
  %v2622 = load i32, ptr %slot443, align 8
  %cv2623 = zext i32 %v2622 to i64
  %cond2624 = icmp ne i64 %cv2623, 0
  br i1 %cond2624, label %bb_rctake561, label %bb_rccopy561
bb_rctake561:
  %v2625 = load i64, ptr %slot18, align 8
  store i64 %v2625, ptr %slot444, align 8
  %v2626 = load i64, ptr %slot39, align 8
  store i64 %v2626, ptr %slot445, align 8
  %v2627 = load i64, ptr %slot439, align 8
  %v2628 = load i64, ptr %slot444, align 8
  %op2629 = sub i64 %v2627, %v2628
  store i64 %op2629, ptr %slot446, align 8
  %v2630 = load i64, ptr %slot444, align 8
  %v2631 = load i64, ptr %slot439, align 8
  %op2632 = sub i64 %v2630, %v2631
  store i64 %op2632, ptr %slot447, align 8
  %v2633 = load i64, ptr %slot446, align 8
  %cmp2634 = icmp ult i64 %v2633, 8
  %cv2635 = zext i1 %cmp2634 to i32
  store i32 %cv2635, ptr %slot448, align 8
  %v2636 = load i64, ptr %slot447, align 8
  %cmp2637 = icmp ult i64 %v2636, 8
  %cv2638 = zext i1 %cmp2637 to i32
  store i32 %cv2638, ptr %slot449, align 8
  %v2639 = load i32, ptr %slot448, align 8
  %v2640 = load i32, ptr %slot449, align 8
  %op2641 = or i32 %v2639, %v2640
  store i32 %op2641, ptr %slot450, align 8
  %v2642 = load i32, ptr %slot450, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcmoveslow570, label %bb_rcmovecheck570
bb_rcmovecheck570:
  %v2645 = load i64, ptr %slot439, align 8
  %p2647 = inttoptr i64 %v2645 to ptr
  %gep2648 = getelementptr i8, ptr %p2647, i64 0
  %op2646 = ptrtoint ptr %gep2648 to i64
  store i64 %op2646, ptr %slot451, align 8
  %v2649 = load i64, ptr %slot451, align 8
  %p2650 = inttoptr i64 %v2649 to ptr
  %ld2651 = load i64, ptr %p2650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2651, ptr %slot452, align 8
  %v2652 = load i64, ptr %slot452, align 8
  %cmp2653 = icmp ne i64 %v2652, 0
  %cv2654 = zext i1 %cmp2653 to i32
  store i32 %cv2654, ptr %slot453, align 8
  %v2655 = load i32, ptr %slot453, align 8
  %cv2656 = zext i32 %v2655 to i64
  %cond2657 = icmp ne i64 %cv2656, 0
  br i1 %cond2657, label %bb_rcmoveheader578, label %bb_rcmovenext578
bb_rcmoveheader578:
  %v2658 = load i64, ptr %slot452, align 8
  %op2659 = sub i64 %v2658, 16
  store i64 %op2659, ptr %slot454, align 8
  %v2660 = load i64, ptr %slot452, align 8
  %p2661 = inttoptr i64 %v2660 to ptr
  %rgep2662 = getelementptr i8, ptr %p2661, i64 -16
  %ld2663 = load i64, ptr %rgep2662, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2663, ptr %slot455, align 8
  %v2664 = load i64, ptr %slot455, align 8
  %op2665 = and i64 %v2664, 5764607523034234881
  store i64 %op2665, ptr %slot456, align 8
  %v2666 = load i64, ptr %slot456, align 8
  %cmp2667 = icmp ne i64 %v2666, 0
  %cv2668 = zext i1 %cmp2667 to i32
  store i32 %cv2668, ptr %slot457, align 8
  %v2669 = load i32, ptr %slot457, align 8
  %cv2670 = zext i32 %v2669 to i64
  %cond2671 = icmp ne i64 %cv2670, 0
  br i1 %cond2671, label %bb_rcmoveslow570, label %bb_rcmovenext578
bb_rcmovenext578:
  %v2672 = load i64, ptr %slot439, align 8
  %v2673 = load i64, ptr %slot444, align 8
  %p2674 = inttoptr i64 %v2672 to ptr
  %p2675 = inttoptr i64 %v2673 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2675, ptr %p2674, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2676 = load i64, ptr %slot439, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i64 0, ptr %p2677, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved570
bb_rcmoveslow570:
  %v2678 = load i64, ptr %slot38, align 8
  %v2679 = load i64, ptr %slot444, align 8
  %v2680 = load i64, ptr %slot439, align 8
  %v2681 = load i64, ptr %slot445, align 8
  %cv2682 = trunc i64 %v2681 to i32
  %call2683 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v2678, i64 %v2679, i64 %v2680, i32 %cv2682) nomerge, !dbg !152
  store i32 %call2683, ptr %slot458, align 8
  %v2684 = load i32, ptr %slot458, align 8
  %cv2685 = zext i32 %v2684 to i64
  %cond2686 = icmp ne i64 %cv2685, 0
  br i1 %cond2686, label %bb_rcsuccess585, label %bb_rcfailure585
bb_rcfailure585:
  %v2687 = load i64, ptr %slot38, align 8
  %p2688 = inttoptr i64 %v2687 to ptr
  %call2689 = call i32 @myl_rc_take_failure(ptr %p2688) nomerge, !dbg !152
  store i32 %call2689, ptr %slot459, align 8
  %v2690 = load i64, ptr %slot1, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %v2692 = load i32, ptr %slot459, align 8
  %call2693 = call i32 @myl_qbe_rc_status(ptr %p2691, i32 %v2692) nomerge, !dbg !152
  store i32 %call2693, ptr %slot460, align 8
  br label %bb_failure
bb_rcsuccess585:
  br label %bb_rcmoved570
bb_rcmoved570:
  %v2694 = load i64, ptr %slot7, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  store i32 0, ptr %p2695, align 4, !alias.scope !3, !noalias !4
  %v2696 = load i64, ptr %slot12, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  store i32 2, ptr %p2697, align 4, !alias.scope !3, !noalias !4
  %v2698 = load i64, ptr %slot11, align 8
  %p2699 = inttoptr i64 %v2698 to ptr
  store i32 1, ptr %p2699, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared561
bb_rccopy561:
  %v2700 = load i64, ptr %slot18, align 8
  store i64 %v2700, ptr %slot461, align 8
  %v2701 = load i64, ptr %slot39, align 8
  store i64 %v2701, ptr %slot462, align 8
  %v2702 = load i64, ptr %slot439, align 8
  %p2703 = inttoptr i64 %v2702 to ptr
  %ld2704 = load i64, ptr %p2703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2704, ptr %slot463, align 8
  %v2705 = load i64, ptr %slot463, align 8
  %cmp2706 = icmp ne i64 %v2705, 0
  %cv2707 = zext i1 %cmp2706 to i32
  store i32 %cv2707, ptr %slot464, align 8
  %v2708 = load i32, ptr %slot464, align 8
  %cv2709 = zext i32 %v2708 to i64
  %cond2710 = icmp ne i64 %cv2709, 0
  br i1 %cond2710, label %bb_rcgnn594, label %bb_rcgplain594
bb_rcgnn594:
  %v2711 = load i64, ptr %slot463, align 8
  %op2712 = sub i64 %v2711, 16
  store i64 %op2712, ptr %slot465, align 8
  %v2713 = load i64, ptr %slot463, align 8
  %p2714 = inttoptr i64 %v2713 to ptr
  %rgep2715 = getelementptr i8, ptr %p2714, i64 -16
  %ld2716 = load i64, ptr %rgep2715, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2716, ptr %slot466, align 8
  %v2717 = load i64, ptr %slot466, align 8
  %op2718 = and i64 %v2717, 4611686018427387906
  store i64 %op2718, ptr %slot467, align 8
  %v2719 = load i64, ptr %slot467, align 8
  %cmp2720 = icmp ne i64 %v2719, 0
  %cv2721 = zext i1 %cmp2720 to i32
  store i32 %cv2721, ptr %slot468, align 8
  %v2722 = load i32, ptr %slot468, align 8
  %cv2723 = zext i32 %v2722 to i64
  %cond2724 = icmp ne i64 %cv2723, 0
  br i1 %cond2724, label %bb_rcgspecial594, label %bb_rcginc594
bb_rcginc594:
  %v2725 = load i64, ptr %slot463, align 8
  %op2726 = sub i64 %v2725, 32
  store i64 %op2726, ptr %slot469, align 8
  %v2727 = load i64, ptr %slot463, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  %rgep2729 = getelementptr i8, ptr %p2728, i64 -32
  %ld2730 = load i64, ptr %rgep2729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2730, ptr %slot470, align 8
  %v2731 = load i64, ptr %slot470, align 8
  %op2732 = add i64 %v2731, 1
  store i64 %op2732, ptr %slot471, align 8
  %v2733 = load i64, ptr %slot471, align 8
  %cmp2734 = icmp eq i64 %v2733, 0
  %cv2735 = zext i1 %cmp2734 to i32
  store i32 %cv2735, ptr %slot472, align 8
  %v2736 = load i32, ptr %slot472, align 8
  %cv2737 = zext i32 %v2736 to i64
  %cond2738 = icmp ne i64 %cv2737, 0
  br i1 %cond2738, label %bb_rcglimit594, label %bb_rcgcapacity594
bb_rcglimit594:
  %v2739 = load i64, ptr %slot1, align 8
  %p2740 = inttoptr i64 %v2739 to ptr
  %call2741 = call i32 @myl_qbe_rc_status(ptr %p2740, i32 2) nomerge, !dbg !152
  store i32 %call2741, ptr %slot473, align 8
  br label %bb_failure
bb_rcgcapacity594:
  %v2742 = load i64, ptr %slot471, align 8
  %v2743 = load i64, ptr %slot463, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  %rgep2745 = getelementptr i8, ptr %p2744, i64 -32
  store i64 %v2742, ptr %rgep2745, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain594
bb_rcgspecial594:
  %v2746 = load i64, ptr %slot466, align 8
  %op2747 = and i64 %v2746, 4611686018427387904
  store i64 %op2747, ptr %slot474, align 8
  %v2748 = load i64, ptr %slot474, align 8
  %cmp2749 = icmp ne i64 %v2748, 0
  %cv2750 = zext i1 %cmp2749 to i32
  store i32 %cv2750, ptr %slot475, align 8
  %v2751 = load i32, ptr %slot475, align 8
  %cv2752 = zext i32 %v2751 to i64
  %cond2753 = icmp ne i64 %cv2752, 0
  br i1 %cond2753, label %bb_rcgslow594, label %bb_rcgplain594
bb_rcgslow594:
  %v2754 = load i64, ptr %slot38, align 8
  %v2755 = load i64, ptr %slot461, align 8
  %v2756 = load i64, ptr %slot439, align 8
  %v2757 = load i64, ptr %slot462, align 8
  %cv2758 = trunc i64 %v2757 to i32
  %call2759 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v2754, i64 %v2755, i64 %v2756, i32 %cv2758) nomerge, !dbg !152
  store i32 %call2759, ptr %slot476, align 8
  %v2760 = load i32, ptr %slot476, align 8
  %cv2761 = zext i32 %v2760 to i64
  %cond2762 = icmp ne i64 %cv2761, 0
  br i1 %cond2762, label %bb_rcsuccess608, label %bb_rcfailure608
bb_rcfailure608:
  %v2763 = load i64, ptr %slot38, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %call2765 = call i32 @myl_rc_take_failure(ptr %p2764) nomerge, !dbg !152
  store i32 %call2765, ptr %slot477, align 8
  %v2766 = load i64, ptr %slot1, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  %v2768 = load i32, ptr %slot477, align 8
  %call2769 = call i32 @myl_qbe_rc_status(ptr %p2767, i32 %v2768) nomerge, !dbg !152
  store i32 %call2769, ptr %slot478, align 8
  br label %bb_failure
bb_rcsuccess608:
  br label %bb_rcgdone594
bb_rcgplain594:
  %v2770 = load i64, ptr %slot463, align 8
  %v2771 = load i64, ptr %slot461, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  store i64 %v2770, ptr %p2772, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone594
bb_rcgdone594:
  %v2773 = load i64, ptr %slot12, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i32 2, ptr %p2774, align 4, !alias.scope !3, !noalias !4
  %v2775 = load i64, ptr %slot11, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  store i32 1, ptr %p2776, align 4, !alias.scope !3, !noalias !4
  %v2777 = load i64, ptr %slot7, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %ld2779 = load i32, ptr %p2778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2779, ptr %slot479, align 8
  %v2780 = load i32, ptr %slot479, align 8
  %cv2781 = zext i32 %v2780 to i64
  %cond2782 = icmp ne i64 %cv2781, 0
  br i1 %cond2782, label %bb_rcslotdrop615, label %bb_rcslotdone615
bb_rcslotdrop615:
  %v2783 = load i64, ptr %slot7, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  store i32 0, ptr %p2784, align 4, !alias.scope !3, !noalias !4
  %v2785 = load i64, ptr %slot14, align 8
  store i64 %v2785, ptr %slot480, align 8
  %v2786 = load i64, ptr %slot8, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  %ld2788 = load i32, ptr %p2787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2788, ptr %slot481, align 8
  %v2789 = load i32, ptr %slot481, align 8
  %op2790 = and i32 %v2789, 28
  store i32 %op2790, ptr %slot482, align 8
  %v2791 = load i32, ptr %slot482, align 8
  %cv2792 = zext i32 %v2791 to i64
  %cond2793 = icmp ne i64 %cv2792, 0
  br i1 %cond2793, label %bb_rcslotrole615, label %bb_rcslotowner615
bb_rcslotrole615:
  %v2794 = load i64, ptr %slot38, align 8
  store i64 %v2794, ptr %slot483, align 8
  %v2795 = load i64, ptr %slot480, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  %ld2797 = load i64, ptr %p2796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2797, ptr %slot484, align 8
  %v2798 = load i64, ptr %slot484, align 8
  %cmp2799 = icmp ne i64 %v2798, 0
  %cv2800 = zext i1 %cmp2799 to i32
  store i32 %cv2800, ptr %slot485, align 8
  %v2801 = load i32, ptr %slot485, align 8
  %cv2802 = zext i32 %v2801 to i64
  %cond2803 = icmp ne i64 %cv2802, 0
  br i1 %cond2803, label %bb_rcgnn631, label %bb_rcgdone631
bb_rcgnn631:
  %v2804 = load i64, ptr %slot484, align 8
  %op2805 = sub i64 %v2804, 16
  store i64 %op2805, ptr %slot486, align 8
  %v2806 = load i64, ptr %slot484, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  %rgep2808 = getelementptr i8, ptr %p2807, i64 -16
  %ld2809 = load i64, ptr %rgep2808, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2809, ptr %slot487, align 8
  %v2810 = load i64, ptr %slot487, align 8
  %op2811 = and i64 %v2810, 4611686018427387906
  store i64 %op2811, ptr %slot488, align 8
  %v2812 = load i64, ptr %slot488, align 8
  %cmp2813 = icmp ne i64 %v2812, 0
  %cv2814 = zext i1 %cmp2813 to i32
  store i32 %cv2814, ptr %slot489, align 8
  %v2815 = load i32, ptr %slot489, align 8
  %cv2816 = zext i32 %v2815 to i64
  %cond2817 = icmp ne i64 %cv2816, 0
  br i1 %cond2817, label %bb_rcgclear631, label %bb_rcgcounted631
bb_rcgcounted631:
  %v2818 = load i64, ptr %slot484, align 8
  %op2819 = sub i64 %v2818, 24
  store i64 %op2819, ptr %slot490, align 8
  %v2820 = load i64, ptr %slot484, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  %rgep2822 = getelementptr i8, ptr %p2821, i64 -24
  %ld2823 = load i64, ptr %rgep2822, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2823, ptr %slot491, align 8
  %v2824 = load i64, ptr %slot491, align 8
  %op2825 = sub i64 %v2824, 1
  store i64 %op2825, ptr %slot492, align 8
  %v2826 = load i64, ptr %slot492, align 8
  %cmp2827 = icmp eq i64 %v2826, 0
  %cv2828 = zext i1 %cmp2827 to i32
  store i32 %cv2828, ptr %slot493, align 8
  %v2829 = load i32, ptr %slot493, align 8
  %cv2830 = zext i32 %v2829 to i64
  %cond2831 = icmp ne i64 %cv2830, 0
  br i1 %cond2831, label %bb_rcglast631, label %bb_rcgdec631
bb_rcglast631:
  %v2832 = load i64, ptr %slot484, align 8
  %op2833 = sub i64 %v2832, 32
  store i64 %op2833, ptr %slot494, align 8
  %v2834 = load i64, ptr %slot484, align 8
  %p2835 = inttoptr i64 %v2834 to ptr
  %rgep2836 = getelementptr i8, ptr %p2835, i64 -32
  %ld2837 = load i64, ptr %rgep2836, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2837, ptr %slot495, align 8
  %v2838 = load i64, ptr %slot495, align 8
  %cmp2839 = icmp ne i64 %v2838, 0
  %cv2840 = zext i1 %cmp2839 to i32
  store i32 %cv2840, ptr %slot496, align 8
  %v2841 = load i32, ptr %slot496, align 8
  %cv2842 = zext i32 %v2841 to i64
  %cond2843 = icmp ne i64 %cv2842, 0
  br i1 %cond2843, label %bb_rcgdec631, label %bb_rcgslow631
bb_rcgslow631:
  %v2844 = load i64, ptr %slot483, align 8
  %v2845 = load i64, ptr %slot480, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2844, i64 %v2845) nomerge, !dbg !152
  br label %bb_rcgdone631
bb_rcgdec631:
  %v2846 = load i64, ptr %slot492, align 8
  %v2847 = load i64, ptr %slot484, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %rgep2849 = getelementptr i8, ptr %p2848, i64 -24
  store i64 %v2846, ptr %rgep2849, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear631
bb_rcgclear631:
  %v2850 = load i64, ptr %slot480, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  store i64 0, ptr %p2851, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone631
bb_rcgdone631:
  br label %bb_rcslotdone615
bb_rcslotowner615:
  %v2852 = load i64, ptr %slot38, align 8
  store i64 %v2852, ptr %slot497, align 8
  %v2853 = load i64, ptr %slot480, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  %ld2855 = load i64, ptr %p2854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2855, ptr %slot498, align 8
  %v2856 = load i64, ptr %slot498, align 8
  %cmp2857 = icmp ne i64 %v2856, 0
  %cv2858 = zext i1 %cmp2857 to i32
  store i32 %cv2858, ptr %slot499, align 8
  %v2859 = load i32, ptr %slot499, align 8
  %cv2860 = zext i32 %v2859 to i64
  %cond2861 = icmp ne i64 %cv2860, 0
  br i1 %cond2861, label %bb_rcgnn646, label %bb_rcgdone646
bb_rcgnn646:
  %v2862 = load i64, ptr %slot498, align 8
  %op2863 = sub i64 %v2862, 16
  store i64 %op2863, ptr %slot500, align 8
  %v2864 = load i64, ptr %slot498, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  %rgep2866 = getelementptr i8, ptr %p2865, i64 -16
  %ld2867 = load i64, ptr %rgep2866, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2867, ptr %slot501, align 8
  %v2868 = load i64, ptr %slot501, align 8
  %op2869 = and i64 %v2868, 4611686018427387906
  store i64 %op2869, ptr %slot502, align 8
  %v2870 = load i64, ptr %slot502, align 8
  %cmp2871 = icmp ne i64 %v2870, 0
  %cv2872 = zext i1 %cmp2871 to i32
  store i32 %cv2872, ptr %slot503, align 8
  %v2873 = load i32, ptr %slot503, align 8
  %cv2874 = zext i32 %v2873 to i64
  %cond2875 = icmp ne i64 %cv2874, 0
  br i1 %cond2875, label %bb_rcgclear646, label %bb_rcgcounted646
bb_rcgcounted646:
  %v2876 = load i64, ptr %slot498, align 8
  %op2877 = sub i64 %v2876, 32
  store i64 %op2877, ptr %slot504, align 8
  %v2878 = load i64, ptr %slot498, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  %rgep2880 = getelementptr i8, ptr %p2879, i64 -32
  %ld2881 = load i64, ptr %rgep2880, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2881, ptr %slot505, align 8
  %v2882 = load i64, ptr %slot505, align 8
  %op2883 = sub i64 %v2882, 1
  store i64 %op2883, ptr %slot506, align 8
  %v2884 = load i64, ptr %slot506, align 8
  %cmp2885 = icmp eq i64 %v2884, 0
  %cv2886 = zext i1 %cmp2885 to i32
  store i32 %cv2886, ptr %slot507, align 8
  %v2887 = load i32, ptr %slot507, align 8
  %cv2888 = zext i32 %v2887 to i64
  %cond2889 = icmp ne i64 %cv2888, 0
  br i1 %cond2889, label %bb_rcglast646, label %bb_rcgdec646
bb_rcglast646:
  %v2890 = load i64, ptr %slot498, align 8
  %op2891 = sub i64 %v2890, 24
  store i64 %op2891, ptr %slot508, align 8
  %v2892 = load i64, ptr %slot498, align 8
  %p2893 = inttoptr i64 %v2892 to ptr
  %rgep2894 = getelementptr i8, ptr %p2893, i64 -24
  %ld2895 = load i64, ptr %rgep2894, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2895, ptr %slot509, align 8
  %v2896 = load i64, ptr %slot509, align 8
  %cmp2897 = icmp ne i64 %v2896, 0
  %cv2898 = zext i1 %cmp2897 to i32
  store i32 %cv2898, ptr %slot510, align 8
  %v2899 = load i32, ptr %slot510, align 8
  %cv2900 = zext i32 %v2899 to i64
  %cond2901 = icmp ne i64 %cv2900, 0
  br i1 %cond2901, label %bb_rcgdec646, label %bb_rcgslow646
bb_rcgslow646:
  %v2902 = load i64, ptr %slot497, align 8
  %v2903 = load i64, ptr %slot480, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2902, i64 %v2903) nomerge, !dbg !152
  br label %bb_rcgdone646
bb_rcgdec646:
  %v2904 = load i64, ptr %slot506, align 8
  %v2905 = load i64, ptr %slot498, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  %rgep2907 = getelementptr i8, ptr %p2906, i64 -32
  store i64 %v2904, ptr %rgep2907, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear646
bb_rcgclear646:
  %v2908 = load i64, ptr %slot480, align 8
  %p2909 = inttoptr i64 %v2908 to ptr
  store i64 0, ptr %p2909, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone646
bb_rcgdone646:
  br label %bb_rcslotdone615
bb_rcslotdone615:
  br label %bb_rcprepared561
bb_rcprepared561:
  %v2910 = load i64, ptr %slot5, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  %ld2912 = load i32, ptr %p2911, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2912, ptr %slot511, align 8
  %v2913 = load i32, ptr %slot511, align 8
  %cv2914 = zext i32 %v2913 to i64
  %cond2915 = icmp ne i64 %cv2914, 0
  br i1 %cond2915, label %bb_rcslotdrop653, label %bb_rcslotdone653
bb_rcslotdrop653:
  %v2916 = load i64, ptr %slot5, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  store i32 0, ptr %p2917, align 4, !alias.scope !3, !noalias !4
  %v2918 = load i64, ptr %slot20, align 8
  store i64 %v2918, ptr %slot512, align 8
  %v2919 = load i64, ptr %slot6, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  %ld2921 = load i32, ptr %p2920, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2921, ptr %slot513, align 8
  %v2922 = load i32, ptr %slot513, align 8
  %op2923 = and i32 %v2922, 28
  store i32 %op2923, ptr %slot514, align 8
  %v2924 = load i32, ptr %slot514, align 8
  %cv2925 = zext i32 %v2924 to i64
  %cond2926 = icmp ne i64 %cv2925, 0
  br i1 %cond2926, label %bb_rcslotrole653, label %bb_rcslotowner653
bb_rcslotrole653:
  %v2927 = load i64, ptr %slot38, align 8
  store i64 %v2927, ptr %slot515, align 8
  %v2928 = load i64, ptr %slot512, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  %ld2930 = load i64, ptr %p2929, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2930, ptr %slot516, align 8
  %v2931 = load i64, ptr %slot516, align 8
  %cmp2932 = icmp ne i64 %v2931, 0
  %cv2933 = zext i1 %cmp2932 to i32
  store i32 %cv2933, ptr %slot517, align 8
  %v2934 = load i32, ptr %slot517, align 8
  %cv2935 = zext i32 %v2934 to i64
  %cond2936 = icmp ne i64 %cv2935, 0
  br i1 %cond2936, label %bb_rcgnn669, label %bb_rcgdone669
bb_rcgnn669:
  %v2937 = load i64, ptr %slot516, align 8
  %op2938 = sub i64 %v2937, 16
  store i64 %op2938, ptr %slot518, align 8
  %v2939 = load i64, ptr %slot516, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  %rgep2941 = getelementptr i8, ptr %p2940, i64 -16
  %ld2942 = load i64, ptr %rgep2941, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2942, ptr %slot519, align 8
  %v2943 = load i64, ptr %slot519, align 8
  %op2944 = and i64 %v2943, 4611686018427387906
  store i64 %op2944, ptr %slot520, align 8
  %v2945 = load i64, ptr %slot520, align 8
  %cmp2946 = icmp ne i64 %v2945, 0
  %cv2947 = zext i1 %cmp2946 to i32
  store i32 %cv2947, ptr %slot521, align 8
  %v2948 = load i32, ptr %slot521, align 8
  %cv2949 = zext i32 %v2948 to i64
  %cond2950 = icmp ne i64 %cv2949, 0
  br i1 %cond2950, label %bb_rcgclear669, label %bb_rcgcounted669
bb_rcgcounted669:
  %v2951 = load i64, ptr %slot516, align 8
  %op2952 = sub i64 %v2951, 24
  store i64 %op2952, ptr %slot522, align 8
  %v2953 = load i64, ptr %slot516, align 8
  %p2954 = inttoptr i64 %v2953 to ptr
  %rgep2955 = getelementptr i8, ptr %p2954, i64 -24
  %ld2956 = load i64, ptr %rgep2955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2956, ptr %slot523, align 8
  %v2957 = load i64, ptr %slot523, align 8
  %op2958 = sub i64 %v2957, 1
  store i64 %op2958, ptr %slot524, align 8
  %v2959 = load i64, ptr %slot524, align 8
  %cmp2960 = icmp eq i64 %v2959, 0
  %cv2961 = zext i1 %cmp2960 to i32
  store i32 %cv2961, ptr %slot525, align 8
  %v2962 = load i32, ptr %slot525, align 8
  %cv2963 = zext i32 %v2962 to i64
  %cond2964 = icmp ne i64 %cv2963, 0
  br i1 %cond2964, label %bb_rcglast669, label %bb_rcgdec669
bb_rcglast669:
  %v2965 = load i64, ptr %slot516, align 8
  %op2966 = sub i64 %v2965, 32
  store i64 %op2966, ptr %slot526, align 8
  %v2967 = load i64, ptr %slot516, align 8
  %p2968 = inttoptr i64 %v2967 to ptr
  %rgep2969 = getelementptr i8, ptr %p2968, i64 -32
  %ld2970 = load i64, ptr %rgep2969, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2970, ptr %slot527, align 8
  %v2971 = load i64, ptr %slot527, align 8
  %cmp2972 = icmp ne i64 %v2971, 0
  %cv2973 = zext i1 %cmp2972 to i32
  store i32 %cv2973, ptr %slot528, align 8
  %v2974 = load i32, ptr %slot528, align 8
  %cv2975 = zext i32 %v2974 to i64
  %cond2976 = icmp ne i64 %cv2975, 0
  br i1 %cond2976, label %bb_rcgdec669, label %bb_rcgslow669
bb_rcgslow669:
  %v2977 = load i64, ptr %slot515, align 8
  %v2978 = load i64, ptr %slot512, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2977, i64 %v2978) nomerge, !dbg !152
  br label %bb_rcgdone669
bb_rcgdec669:
  %v2979 = load i64, ptr %slot524, align 8
  %v2980 = load i64, ptr %slot516, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  %rgep2982 = getelementptr i8, ptr %p2981, i64 -24
  store i64 %v2979, ptr %rgep2982, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear669
bb_rcgclear669:
  %v2983 = load i64, ptr %slot512, align 8
  %p2984 = inttoptr i64 %v2983 to ptr
  store i64 0, ptr %p2984, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone669
bb_rcgdone669:
  br label %bb_rcslotdone653
bb_rcslotowner653:
  %v2985 = load i64, ptr %slot38, align 8
  store i64 %v2985, ptr %slot529, align 8
  %v2986 = load i64, ptr %slot512, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  %ld2988 = load i64, ptr %p2987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2988, ptr %slot530, align 8
  %v2989 = load i64, ptr %slot530, align 8
  %cmp2990 = icmp ne i64 %v2989, 0
  %cv2991 = zext i1 %cmp2990 to i32
  store i32 %cv2991, ptr %slot531, align 8
  %v2992 = load i32, ptr %slot531, align 8
  %cv2993 = zext i32 %v2992 to i64
  %cond2994 = icmp ne i64 %cv2993, 0
  br i1 %cond2994, label %bb_rcgnn684, label %bb_rcgdone684
bb_rcgnn684:
  %v2995 = load i64, ptr %slot530, align 8
  %op2996 = sub i64 %v2995, 16
  store i64 %op2996, ptr %slot532, align 8
  %v2997 = load i64, ptr %slot530, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  %rgep2999 = getelementptr i8, ptr %p2998, i64 -16
  %ld3000 = load i64, ptr %rgep2999, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3000, ptr %slot533, align 8
  %v3001 = load i64, ptr %slot533, align 8
  %op3002 = and i64 %v3001, 4611686018427387906
  store i64 %op3002, ptr %slot534, align 8
  %v3003 = load i64, ptr %slot534, align 8
  %cmp3004 = icmp ne i64 %v3003, 0
  %cv3005 = zext i1 %cmp3004 to i32
  store i32 %cv3005, ptr %slot535, align 8
  %v3006 = load i32, ptr %slot535, align 8
  %cv3007 = zext i32 %v3006 to i64
  %cond3008 = icmp ne i64 %cv3007, 0
  br i1 %cond3008, label %bb_rcgclear684, label %bb_rcgcounted684
bb_rcgcounted684:
  %v3009 = load i64, ptr %slot530, align 8
  %op3010 = sub i64 %v3009, 32
  store i64 %op3010, ptr %slot536, align 8
  %v3011 = load i64, ptr %slot530, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  %rgep3013 = getelementptr i8, ptr %p3012, i64 -32
  %ld3014 = load i64, ptr %rgep3013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3014, ptr %slot537, align 8
  %v3015 = load i64, ptr %slot537, align 8
  %op3016 = sub i64 %v3015, 1
  store i64 %op3016, ptr %slot538, align 8
  %v3017 = load i64, ptr %slot538, align 8
  %cmp3018 = icmp eq i64 %v3017, 0
  %cv3019 = zext i1 %cmp3018 to i32
  store i32 %cv3019, ptr %slot539, align 8
  %v3020 = load i32, ptr %slot539, align 8
  %cv3021 = zext i32 %v3020 to i64
  %cond3022 = icmp ne i64 %cv3021, 0
  br i1 %cond3022, label %bb_rcglast684, label %bb_rcgdec684
bb_rcglast684:
  %v3023 = load i64, ptr %slot530, align 8
  %op3024 = sub i64 %v3023, 24
  store i64 %op3024, ptr %slot540, align 8
  %v3025 = load i64, ptr %slot530, align 8
  %p3026 = inttoptr i64 %v3025 to ptr
  %rgep3027 = getelementptr i8, ptr %p3026, i64 -24
  %ld3028 = load i64, ptr %rgep3027, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3028, ptr %slot541, align 8
  %v3029 = load i64, ptr %slot541, align 8
  %cmp3030 = icmp ne i64 %v3029, 0
  %cv3031 = zext i1 %cmp3030 to i32
  store i32 %cv3031, ptr %slot542, align 8
  %v3032 = load i32, ptr %slot542, align 8
  %cv3033 = zext i32 %v3032 to i64
  %cond3034 = icmp ne i64 %cv3033, 0
  br i1 %cond3034, label %bb_rcgdec684, label %bb_rcgslow684
bb_rcgslow684:
  %v3035 = load i64, ptr %slot529, align 8
  %v3036 = load i64, ptr %slot512, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3035, i64 %v3036) nomerge, !dbg !152
  br label %bb_rcgdone684
bb_rcgdec684:
  %v3037 = load i64, ptr %slot538, align 8
  %v3038 = load i64, ptr %slot530, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  %rgep3040 = getelementptr i8, ptr %p3039, i64 -32
  store i64 %v3037, ptr %rgep3040, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear684
bb_rcgclear684:
  %v3041 = load i64, ptr %slot512, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  store i64 0, ptr %p3042, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone684
bb_rcgdone684:
  br label %bb_rcslotdone653
bb_rcslotdone653:
  %v3043 = load i64, ptr %slot20, align 8
  store i64 %v3043, ptr %slot543, align 8
  %v3044 = load i64, ptr %slot18, align 8
  store i64 %v3044, ptr %slot544, align 8
  %v3045 = load i64, ptr %slot544, align 8
  %v3046 = load i64, ptr %slot543, align 8
  %p3047 = inttoptr i64 %v3045 to ptr
  %p3048 = inttoptr i64 %v3046 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3048, ptr %p3047, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3049 = load i64, ptr %slot11, align 8
  %p3050 = inttoptr i64 %v3049 to ptr
  store i32 0, ptr %p3050, align 4, !alias.scope !3, !noalias !4
  %v3051 = load i64, ptr %slot6, align 8
  %p3052 = inttoptr i64 %v3051 to ptr
  store i32 2, ptr %p3052, align 4, !alias.scope !3, !noalias !4
  %v3053 = load i64, ptr %slot12, align 8
  %p3054 = inttoptr i64 %v3053 to ptr
  %ld3055 = load i32, ptr %p3054, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3055, ptr %slot545, align 8
  %v3056 = load i32, ptr %slot545, align 8
  %v3057 = load i64, ptr %slot6, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  store i32 %v3056, ptr %p3058, align 4, !alias.scope !3, !noalias !4
  %v3059 = load i64, ptr %slot5, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  store i32 1, ptr %p3060, align 4, !alias.scope !3, !noalias !4
  %v3061 = load i64, ptr %slot19, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  %ld3063 = load i64, ptr %p3062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3063, ptr %slot546, align 8
  %v3064 = load i64, ptr %slot546, align 8
  %v3065 = load i64, ptr %slot21, align 8
  %p3066 = inttoptr i64 %v3065 to ptr
  store i64 %v3064, ptr %p3066, align 8, !alias.scope !3, !noalias !4
  %v3067 = load i64, ptr %slot20, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  %ld3069 = load i64, ptr %p3068, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3069, ptr %slot547, align 8
  %v3070 = load i64, ptr %slot547, align 8
  %v3071 = load i64, ptr %slot22, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  store i64 %v3070, ptr %p3072, align 8, !alias.scope !3, !noalias !4
  %v3073 = load i64, ptr %slot23, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  store i64 0, ptr %p3074, align 8, !alias.scope !3, !noalias !4
  %v3075 = load i64, ptr %slot31, align 8
  store i64 %v3075, ptr %slot548, align 8
  %v3076 = load i64, ptr %slot548, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  store i64 0, ptr %p3077, align 8, !alias.scope !3, !noalias !4
  %v3078 = load i64, ptr %slot548, align 8
  %p3080 = inttoptr i64 %v3078 to ptr
  %gep3081 = getelementptr i8, ptr %p3080, i64 8
  %op3079 = ptrtoint ptr %gep3081 to i64
  store i64 %op3079, ptr %slot549, align 8
  %v3082 = load i64, ptr %slot549, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  store i64 0, ptr %p3083, align 8, !alias.scope !3, !noalias !4
  %v3084 = load i64, ptr %slot13, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  store i32 1, ptr %p3085, align 4, !alias.scope !3, !noalias !4
  %v3086 = load i64, ptr %slot39, align 8
  store i64 %v3086, ptr %slot550, align 8
  %v3087 = load i64, ptr %slot22, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %ld3089 = load i64, ptr %p3088, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3089, ptr %slot551, align 8
  %v3090 = load i64, ptr %slot551, align 8
  %v3091 = load i64, ptr %slot17, align 8
  %p3092 = inttoptr i64 %v3091 to ptr
  store i64 %v3090, ptr %p3092, align 8, !alias.scope !3, !noalias !4
  %v3093 = load i64, ptr %slot17, align 8
  store i64 %v3093, ptr %slot552, align 8
  %v3094 = load i64, ptr %slot548, align 8
  %p3096 = inttoptr i64 %v3094 to ptr
  %gep3097 = getelementptr i8, ptr %p3096, i64 0
  %op3095 = ptrtoint ptr %gep3097 to i64
  store i64 %op3095, ptr %slot553, align 8
  %v3098 = load i64, ptr %slot22, align 8
  %p3099 = inttoptr i64 %v3098 to ptr
  %ld3100 = load i64, ptr %p3099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3100, ptr %slot554, align 8
  %v3101 = load i64, ptr %slot554, align 8
  %v3102 = load i64, ptr %slot17, align 8
  %p3103 = inttoptr i64 %v3102 to ptr
  store i64 %v3101, ptr %p3103, align 8, !alias.scope !3, !noalias !4
  %v3104 = load i64, ptr %slot17, align 8
  store i64 %v3104, ptr %slot555, align 8
  %v3105 = load i64, ptr %slot9, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  %ld3107 = load i32, ptr %p3106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3107, ptr %slot556, align 8
  %v3108 = load i64, ptr %slot10, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  %ld3110 = load i32, ptr %p3109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3110, ptr %slot557, align 8
  %v3111 = load i32, ptr %slot557, align 8
  %op3112 = and i32 %v3111, 24
  store i32 %op3112, ptr %slot557, align 8
  %v3113 = load i32, ptr %slot557, align 8
  %cmp3114 = icmp eq i32 %v3113, 0
  %cv3115 = zext i1 %cmp3114 to i32
  store i32 %cv3115, ptr %slot558, align 8
  %v3116 = load i32, ptr %slot556, align 8
  %v3117 = load i32, ptr %slot558, align 8
  %op3118 = and i32 %v3116, %v3117
  store i32 %op3118, ptr %slot559, align 8
  %v3119 = load i32, ptr %slot559, align 8
  %cv3120 = zext i32 %v3119 to i64
  %cond3121 = icmp ne i64 %cv3120, 0
  br i1 %cond3121, label %bb_rctake707, label %bb_rccopy707
bb_rctake707:
  %v3122 = load i64, ptr %slot18, align 8
  store i64 %v3122, ptr %slot560, align 8
  %v3123 = load i64, ptr %slot39, align 8
  store i64 %v3123, ptr %slot561, align 8
  %v3124 = load i64, ptr %slot555, align 8
  %v3125 = load i64, ptr %slot560, align 8
  %op3126 = sub i64 %v3124, %v3125
  store i64 %op3126, ptr %slot562, align 8
  %v3127 = load i64, ptr %slot560, align 8
  %v3128 = load i64, ptr %slot555, align 8
  %op3129 = sub i64 %v3127, %v3128
  store i64 %op3129, ptr %slot563, align 8
  %v3130 = load i64, ptr %slot562, align 8
  %cmp3131 = icmp ult i64 %v3130, 8
  %cv3132 = zext i1 %cmp3131 to i32
  store i32 %cv3132, ptr %slot564, align 8
  %v3133 = load i64, ptr %slot563, align 8
  %cmp3134 = icmp ult i64 %v3133, 8
  %cv3135 = zext i1 %cmp3134 to i32
  store i32 %cv3135, ptr %slot565, align 8
  %v3136 = load i32, ptr %slot564, align 8
  %v3137 = load i32, ptr %slot565, align 8
  %op3138 = or i32 %v3136, %v3137
  store i32 %op3138, ptr %slot566, align 8
  %v3139 = load i32, ptr %slot566, align 8
  %cv3140 = zext i32 %v3139 to i64
  %cond3141 = icmp ne i64 %cv3140, 0
  br i1 %cond3141, label %bb_rcmoveslow716, label %bb_rcmovecheck716
bb_rcmovecheck716:
  %v3142 = load i64, ptr %slot555, align 8
  %p3144 = inttoptr i64 %v3142 to ptr
  %gep3145 = getelementptr i8, ptr %p3144, i64 0
  %op3143 = ptrtoint ptr %gep3145 to i64
  store i64 %op3143, ptr %slot567, align 8
  %v3146 = load i64, ptr %slot567, align 8
  %p3147 = inttoptr i64 %v3146 to ptr
  %ld3148 = load i64, ptr %p3147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3148, ptr %slot568, align 8
  %v3149 = load i64, ptr %slot568, align 8
  %cmp3150 = icmp ne i64 %v3149, 0
  %cv3151 = zext i1 %cmp3150 to i32
  store i32 %cv3151, ptr %slot569, align 8
  %v3152 = load i32, ptr %slot569, align 8
  %cv3153 = zext i32 %v3152 to i64
  %cond3154 = icmp ne i64 %cv3153, 0
  br i1 %cond3154, label %bb_rcmoveheader724, label %bb_rcmovenext724
bb_rcmoveheader724:
  %v3155 = load i64, ptr %slot568, align 8
  %op3156 = sub i64 %v3155, 16
  store i64 %op3156, ptr %slot570, align 8
  %v3157 = load i64, ptr %slot568, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  %rgep3159 = getelementptr i8, ptr %p3158, i64 -16
  %ld3160 = load i64, ptr %rgep3159, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3160, ptr %slot571, align 8
  %v3161 = load i64, ptr %slot571, align 8
  %op3162 = and i64 %v3161, 5764607523034234881
  store i64 %op3162, ptr %slot572, align 8
  %v3163 = load i64, ptr %slot572, align 8
  %cmp3164 = icmp ne i64 %v3163, 0
  %cv3165 = zext i1 %cmp3164 to i32
  store i32 %cv3165, ptr %slot573, align 8
  %v3166 = load i32, ptr %slot573, align 8
  %cv3167 = zext i32 %v3166 to i64
  %cond3168 = icmp ne i64 %cv3167, 0
  br i1 %cond3168, label %bb_rcmoveslow716, label %bb_rcmovenext724
bb_rcmovenext724:
  %v3169 = load i64, ptr %slot555, align 8
  %v3170 = load i64, ptr %slot560, align 8
  %p3171 = inttoptr i64 %v3169 to ptr
  %p3172 = inttoptr i64 %v3170 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3172, ptr %p3171, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3173 = load i64, ptr %slot555, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  store i64 0, ptr %p3174, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved716
bb_rcmoveslow716:
  %v3175 = load i64, ptr %slot38, align 8
  %v3176 = load i64, ptr %slot560, align 8
  %v3177 = load i64, ptr %slot555, align 8
  %v3178 = load i64, ptr %slot561, align 8
  %cv3179 = trunc i64 %v3178 to i32
  %call3180 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v3175, i64 %v3176, i64 %v3177, i32 %cv3179) nomerge, !dbg !154
  store i32 %call3180, ptr %slot574, align 8
  %v3181 = load i32, ptr %slot574, align 8
  %cv3182 = zext i32 %v3181 to i64
  %cond3183 = icmp ne i64 %cv3182, 0
  br i1 %cond3183, label %bb_rcsuccess731, label %bb_rcfailure731
bb_rcfailure731:
  %v3184 = load i64, ptr %slot38, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  %call3186 = call i32 @myl_rc_take_failure(ptr %p3185) nomerge, !dbg !154
  store i32 %call3186, ptr %slot575, align 8
  %v3187 = load i64, ptr %slot1, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  %v3189 = load i32, ptr %slot575, align 8
  %call3190 = call i32 @myl_qbe_rc_status(ptr %p3188, i32 %v3189) nomerge, !dbg !154
  store i32 %call3190, ptr %slot576, align 8
  br label %bb_failure
bb_rcsuccess731:
  br label %bb_rcmoved716
bb_rcmoved716:
  %v3191 = load i64, ptr %slot9, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  store i32 0, ptr %p3192, align 4, !alias.scope !3, !noalias !4
  %v3193 = load i64, ptr %slot12, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  store i32 2, ptr %p3194, align 4, !alias.scope !3, !noalias !4
  %v3195 = load i64, ptr %slot11, align 8
  %p3196 = inttoptr i64 %v3195 to ptr
  store i32 1, ptr %p3196, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared707
bb_rccopy707:
  %v3197 = load i64, ptr %slot18, align 8
  store i64 %v3197, ptr %slot577, align 8
  %v3198 = load i64, ptr %slot39, align 8
  store i64 %v3198, ptr %slot578, align 8
  %v3199 = load i64, ptr %slot555, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  %ld3201 = load i64, ptr %p3200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3201, ptr %slot579, align 8
  %v3202 = load i64, ptr %slot579, align 8
  %cmp3203 = icmp ne i64 %v3202, 0
  %cv3204 = zext i1 %cmp3203 to i32
  store i32 %cv3204, ptr %slot580, align 8
  %v3205 = load i32, ptr %slot580, align 8
  %cv3206 = zext i32 %v3205 to i64
  %cond3207 = icmp ne i64 %cv3206, 0
  br i1 %cond3207, label %bb_rcgnn740, label %bb_rcgplain740
bb_rcgnn740:
  %v3208 = load i64, ptr %slot579, align 8
  %op3209 = sub i64 %v3208, 16
  store i64 %op3209, ptr %slot581, align 8
  %v3210 = load i64, ptr %slot579, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  %rgep3212 = getelementptr i8, ptr %p3211, i64 -16
  %ld3213 = load i64, ptr %rgep3212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3213, ptr %slot582, align 8
  %v3214 = load i64, ptr %slot582, align 8
  %op3215 = and i64 %v3214, 4611686018427387906
  store i64 %op3215, ptr %slot583, align 8
  %v3216 = load i64, ptr %slot583, align 8
  %cmp3217 = icmp ne i64 %v3216, 0
  %cv3218 = zext i1 %cmp3217 to i32
  store i32 %cv3218, ptr %slot584, align 8
  %v3219 = load i32, ptr %slot584, align 8
  %cv3220 = zext i32 %v3219 to i64
  %cond3221 = icmp ne i64 %cv3220, 0
  br i1 %cond3221, label %bb_rcgspecial740, label %bb_rcginc740
bb_rcginc740:
  %v3222 = load i64, ptr %slot579, align 8
  %op3223 = sub i64 %v3222, 32
  store i64 %op3223, ptr %slot585, align 8
  %v3224 = load i64, ptr %slot579, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  %rgep3226 = getelementptr i8, ptr %p3225, i64 -32
  %ld3227 = load i64, ptr %rgep3226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3227, ptr %slot586, align 8
  %v3228 = load i64, ptr %slot586, align 8
  %op3229 = add i64 %v3228, 1
  store i64 %op3229, ptr %slot587, align 8
  %v3230 = load i64, ptr %slot587, align 8
  %cmp3231 = icmp eq i64 %v3230, 0
  %cv3232 = zext i1 %cmp3231 to i32
  store i32 %cv3232, ptr %slot588, align 8
  %v3233 = load i32, ptr %slot588, align 8
  %cv3234 = zext i32 %v3233 to i64
  %cond3235 = icmp ne i64 %cv3234, 0
  br i1 %cond3235, label %bb_rcglimit740, label %bb_rcgcapacity740
bb_rcglimit740:
  %v3236 = load i64, ptr %slot1, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  %call3238 = call i32 @myl_qbe_rc_status(ptr %p3237, i32 2) nomerge, !dbg !154
  store i32 %call3238, ptr %slot589, align 8
  br label %bb_failure
bb_rcgcapacity740:
  %v3239 = load i64, ptr %slot587, align 8
  %v3240 = load i64, ptr %slot579, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  %rgep3242 = getelementptr i8, ptr %p3241, i64 -32
  store i64 %v3239, ptr %rgep3242, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain740
bb_rcgspecial740:
  %v3243 = load i64, ptr %slot582, align 8
  %op3244 = and i64 %v3243, 4611686018427387904
  store i64 %op3244, ptr %slot590, align 8
  %v3245 = load i64, ptr %slot590, align 8
  %cmp3246 = icmp ne i64 %v3245, 0
  %cv3247 = zext i1 %cmp3246 to i32
  store i32 %cv3247, ptr %slot591, align 8
  %v3248 = load i32, ptr %slot591, align 8
  %cv3249 = zext i32 %v3248 to i64
  %cond3250 = icmp ne i64 %cv3249, 0
  br i1 %cond3250, label %bb_rcgslow740, label %bb_rcgplain740
bb_rcgslow740:
  %v3251 = load i64, ptr %slot38, align 8
  %v3252 = load i64, ptr %slot577, align 8
  %v3253 = load i64, ptr %slot555, align 8
  %v3254 = load i64, ptr %slot578, align 8
  %cv3255 = trunc i64 %v3254 to i32
  %call3256 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v3251, i64 %v3252, i64 %v3253, i32 %cv3255) nomerge, !dbg !154
  store i32 %call3256, ptr %slot592, align 8
  %v3257 = load i32, ptr %slot592, align 8
  %cv3258 = zext i32 %v3257 to i64
  %cond3259 = icmp ne i64 %cv3258, 0
  br i1 %cond3259, label %bb_rcsuccess754, label %bb_rcfailure754
bb_rcfailure754:
  %v3260 = load i64, ptr %slot38, align 8
  %p3261 = inttoptr i64 %v3260 to ptr
  %call3262 = call i32 @myl_rc_take_failure(ptr %p3261) nomerge, !dbg !154
  store i32 %call3262, ptr %slot593, align 8
  %v3263 = load i64, ptr %slot1, align 8
  %p3264 = inttoptr i64 %v3263 to ptr
  %v3265 = load i32, ptr %slot593, align 8
  %call3266 = call i32 @myl_qbe_rc_status(ptr %p3264, i32 %v3265) nomerge, !dbg !154
  store i32 %call3266, ptr %slot594, align 8
  br label %bb_failure
bb_rcsuccess754:
  br label %bb_rcgdone740
bb_rcgplain740:
  %v3267 = load i64, ptr %slot579, align 8
  %v3268 = load i64, ptr %slot577, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  store i64 %v3267, ptr %p3269, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone740
bb_rcgdone740:
  %v3270 = load i64, ptr %slot12, align 8
  %p3271 = inttoptr i64 %v3270 to ptr
  store i32 2, ptr %p3271, align 4, !alias.scope !3, !noalias !4
  %v3272 = load i64, ptr %slot11, align 8
  %p3273 = inttoptr i64 %v3272 to ptr
  store i32 1, ptr %p3273, align 4, !alias.scope !3, !noalias !4
  %v3274 = load i64, ptr %slot9, align 8
  %p3275 = inttoptr i64 %v3274 to ptr
  %ld3276 = load i32, ptr %p3275, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3276, ptr %slot595, align 8
  %v3277 = load i32, ptr %slot595, align 8
  %cv3278 = zext i32 %v3277 to i64
  %cond3279 = icmp ne i64 %cv3278, 0
  br i1 %cond3279, label %bb_rcslotdrop761, label %bb_rcslotdone761
bb_rcslotdrop761:
  %v3280 = load i64, ptr %slot9, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  store i32 0, ptr %p3281, align 4, !alias.scope !3, !noalias !4
  %v3282 = load i64, ptr %slot15, align 8
  store i64 %v3282, ptr %slot596, align 8
  %v3283 = load i64, ptr %slot10, align 8
  %p3284 = inttoptr i64 %v3283 to ptr
  %ld3285 = load i32, ptr %p3284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3285, ptr %slot597, align 8
  %v3286 = load i32, ptr %slot597, align 8
  %op3287 = and i32 %v3286, 28
  store i32 %op3287, ptr %slot598, align 8
  %v3288 = load i32, ptr %slot598, align 8
  %cv3289 = zext i32 %v3288 to i64
  %cond3290 = icmp ne i64 %cv3289, 0
  br i1 %cond3290, label %bb_rcslotrole761, label %bb_rcslotowner761
bb_rcslotrole761:
  %v3291 = load i64, ptr %slot38, align 8
  store i64 %v3291, ptr %slot599, align 8
  %v3292 = load i64, ptr %slot596, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  %ld3294 = load i64, ptr %p3293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3294, ptr %slot600, align 8
  %v3295 = load i64, ptr %slot600, align 8
  %cmp3296 = icmp ne i64 %v3295, 0
  %cv3297 = zext i1 %cmp3296 to i32
  store i32 %cv3297, ptr %slot601, align 8
  %v3298 = load i32, ptr %slot601, align 8
  %cv3299 = zext i32 %v3298 to i64
  %cond3300 = icmp ne i64 %cv3299, 0
  br i1 %cond3300, label %bb_rcgnn777, label %bb_rcgdone777
bb_rcgnn777:
  %v3301 = load i64, ptr %slot600, align 8
  %op3302 = sub i64 %v3301, 16
  store i64 %op3302, ptr %slot602, align 8
  %v3303 = load i64, ptr %slot600, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  %rgep3305 = getelementptr i8, ptr %p3304, i64 -16
  %ld3306 = load i64, ptr %rgep3305, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3306, ptr %slot603, align 8
  %v3307 = load i64, ptr %slot603, align 8
  %op3308 = and i64 %v3307, 4611686018427387906
  store i64 %op3308, ptr %slot604, align 8
  %v3309 = load i64, ptr %slot604, align 8
  %cmp3310 = icmp ne i64 %v3309, 0
  %cv3311 = zext i1 %cmp3310 to i32
  store i32 %cv3311, ptr %slot605, align 8
  %v3312 = load i32, ptr %slot605, align 8
  %cv3313 = zext i32 %v3312 to i64
  %cond3314 = icmp ne i64 %cv3313, 0
  br i1 %cond3314, label %bb_rcgclear777, label %bb_rcgcounted777
bb_rcgcounted777:
  %v3315 = load i64, ptr %slot600, align 8
  %op3316 = sub i64 %v3315, 24
  store i64 %op3316, ptr %slot606, align 8
  %v3317 = load i64, ptr %slot600, align 8
  %p3318 = inttoptr i64 %v3317 to ptr
  %rgep3319 = getelementptr i8, ptr %p3318, i64 -24
  %ld3320 = load i64, ptr %rgep3319, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3320, ptr %slot607, align 8
  %v3321 = load i64, ptr %slot607, align 8
  %op3322 = sub i64 %v3321, 1
  store i64 %op3322, ptr %slot608, align 8
  %v3323 = load i64, ptr %slot608, align 8
  %cmp3324 = icmp eq i64 %v3323, 0
  %cv3325 = zext i1 %cmp3324 to i32
  store i32 %cv3325, ptr %slot609, align 8
  %v3326 = load i32, ptr %slot609, align 8
  %cv3327 = zext i32 %v3326 to i64
  %cond3328 = icmp ne i64 %cv3327, 0
  br i1 %cond3328, label %bb_rcglast777, label %bb_rcgdec777
bb_rcglast777:
  %v3329 = load i64, ptr %slot600, align 8
  %op3330 = sub i64 %v3329, 32
  store i64 %op3330, ptr %slot610, align 8
  %v3331 = load i64, ptr %slot600, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  %rgep3333 = getelementptr i8, ptr %p3332, i64 -32
  %ld3334 = load i64, ptr %rgep3333, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3334, ptr %slot611, align 8
  %v3335 = load i64, ptr %slot611, align 8
  %cmp3336 = icmp ne i64 %v3335, 0
  %cv3337 = zext i1 %cmp3336 to i32
  store i32 %cv3337, ptr %slot612, align 8
  %v3338 = load i32, ptr %slot612, align 8
  %cv3339 = zext i32 %v3338 to i64
  %cond3340 = icmp ne i64 %cv3339, 0
  br i1 %cond3340, label %bb_rcgdec777, label %bb_rcgslow777
bb_rcgslow777:
  %v3341 = load i64, ptr %slot599, align 8
  %v3342 = load i64, ptr %slot596, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3341, i64 %v3342) nomerge, !dbg !154
  br label %bb_rcgdone777
bb_rcgdec777:
  %v3343 = load i64, ptr %slot608, align 8
  %v3344 = load i64, ptr %slot600, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  %rgep3346 = getelementptr i8, ptr %p3345, i64 -24
  store i64 %v3343, ptr %rgep3346, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear777
bb_rcgclear777:
  %v3347 = load i64, ptr %slot596, align 8
  %p3348 = inttoptr i64 %v3347 to ptr
  store i64 0, ptr %p3348, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone777
bb_rcgdone777:
  br label %bb_rcslotdone761
bb_rcslotowner761:
  %v3349 = load i64, ptr %slot38, align 8
  store i64 %v3349, ptr %slot613, align 8
  %v3350 = load i64, ptr %slot596, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  %ld3352 = load i64, ptr %p3351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3352, ptr %slot614, align 8
  %v3353 = load i64, ptr %slot614, align 8
  %cmp3354 = icmp ne i64 %v3353, 0
  %cv3355 = zext i1 %cmp3354 to i32
  store i32 %cv3355, ptr %slot615, align 8
  %v3356 = load i32, ptr %slot615, align 8
  %cv3357 = zext i32 %v3356 to i64
  %cond3358 = icmp ne i64 %cv3357, 0
  br i1 %cond3358, label %bb_rcgnn792, label %bb_rcgdone792
bb_rcgnn792:
  %v3359 = load i64, ptr %slot614, align 8
  %op3360 = sub i64 %v3359, 16
  store i64 %op3360, ptr %slot616, align 8
  %v3361 = load i64, ptr %slot614, align 8
  %p3362 = inttoptr i64 %v3361 to ptr
  %rgep3363 = getelementptr i8, ptr %p3362, i64 -16
  %ld3364 = load i64, ptr %rgep3363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3364, ptr %slot617, align 8
  %v3365 = load i64, ptr %slot617, align 8
  %op3366 = and i64 %v3365, 4611686018427387906
  store i64 %op3366, ptr %slot618, align 8
  %v3367 = load i64, ptr %slot618, align 8
  %cmp3368 = icmp ne i64 %v3367, 0
  %cv3369 = zext i1 %cmp3368 to i32
  store i32 %cv3369, ptr %slot619, align 8
  %v3370 = load i32, ptr %slot619, align 8
  %cv3371 = zext i32 %v3370 to i64
  %cond3372 = icmp ne i64 %cv3371, 0
  br i1 %cond3372, label %bb_rcgclear792, label %bb_rcgcounted792
bb_rcgcounted792:
  %v3373 = load i64, ptr %slot614, align 8
  %op3374 = sub i64 %v3373, 32
  store i64 %op3374, ptr %slot620, align 8
  %v3375 = load i64, ptr %slot614, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  %rgep3377 = getelementptr i8, ptr %p3376, i64 -32
  %ld3378 = load i64, ptr %rgep3377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3378, ptr %slot621, align 8
  %v3379 = load i64, ptr %slot621, align 8
  %op3380 = sub i64 %v3379, 1
  store i64 %op3380, ptr %slot622, align 8
  %v3381 = load i64, ptr %slot622, align 8
  %cmp3382 = icmp eq i64 %v3381, 0
  %cv3383 = zext i1 %cmp3382 to i32
  store i32 %cv3383, ptr %slot623, align 8
  %v3384 = load i32, ptr %slot623, align 8
  %cv3385 = zext i32 %v3384 to i64
  %cond3386 = icmp ne i64 %cv3385, 0
  br i1 %cond3386, label %bb_rcglast792, label %bb_rcgdec792
bb_rcglast792:
  %v3387 = load i64, ptr %slot614, align 8
  %op3388 = sub i64 %v3387, 24
  store i64 %op3388, ptr %slot624, align 8
  %v3389 = load i64, ptr %slot614, align 8
  %p3390 = inttoptr i64 %v3389 to ptr
  %rgep3391 = getelementptr i8, ptr %p3390, i64 -24
  %ld3392 = load i64, ptr %rgep3391, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3392, ptr %slot625, align 8
  %v3393 = load i64, ptr %slot625, align 8
  %cmp3394 = icmp ne i64 %v3393, 0
  %cv3395 = zext i1 %cmp3394 to i32
  store i32 %cv3395, ptr %slot626, align 8
  %v3396 = load i32, ptr %slot626, align 8
  %cv3397 = zext i32 %v3396 to i64
  %cond3398 = icmp ne i64 %cv3397, 0
  br i1 %cond3398, label %bb_rcgdec792, label %bb_rcgslow792
bb_rcgslow792:
  %v3399 = load i64, ptr %slot613, align 8
  %v3400 = load i64, ptr %slot596, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3399, i64 %v3400) nomerge, !dbg !154
  br label %bb_rcgdone792
bb_rcgdec792:
  %v3401 = load i64, ptr %slot622, align 8
  %v3402 = load i64, ptr %slot614, align 8
  %p3403 = inttoptr i64 %v3402 to ptr
  %rgep3404 = getelementptr i8, ptr %p3403, i64 -32
  store i64 %v3401, ptr %rgep3404, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear792
bb_rcgclear792:
  %v3405 = load i64, ptr %slot596, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  store i64 0, ptr %p3406, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone792
bb_rcgdone792:
  br label %bb_rcslotdone761
bb_rcslotdone761:
  br label %bb_rcprepared707
bb_rcprepared707:
  %v3407 = load i64, ptr %slot18, align 8
  store i64 %v3407, ptr %slot627, align 8
  %v3408 = load i64, ptr %slot627, align 8
  %v3409 = load i64, ptr %slot553, align 8
  %p3410 = inttoptr i64 %v3408 to ptr
  %p3411 = inttoptr i64 %v3409 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3411, ptr %p3410, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3412 = load i64, ptr %slot11, align 8
  %p3413 = inttoptr i64 %v3412 to ptr
  store i32 0, ptr %p3413, align 4, !alias.scope !3, !noalias !4
  %v3414 = load i64, ptr %slot23, align 8
  store i64 %v3414, ptr %slot628, align 8
  %v3415 = load i64, ptr %slot548, align 8
  %p3417 = inttoptr i64 %v3415 to ptr
  %gep3418 = getelementptr i8, ptr %p3417, i64 8
  %op3416 = ptrtoint ptr %gep3418 to i64
  store i64 %op3416, ptr %slot629, align 8
  %v3419 = load i64, ptr %slot628, align 8
  %p3420 = inttoptr i64 %v3419 to ptr
  %ld3421 = load i64, ptr %p3420, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3421, ptr %slot630, align 8
  %v3422 = load i64, ptr %slot630, align 8
  %v3423 = load i64, ptr %slot629, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  store i64 %v3422, ptr %p3424, align 8, !alias.scope !3, !noalias !4
  %v3425 = load i64, ptr %slot548, align 8
  %v3426 = load i64, ptr %slot22, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  store i64 %v3425, ptr %p3427, align 8, !alias.scope !3, !noalias !4
  %v3428 = load i64, ptr %slot22, align 8
  %p3429 = inttoptr i64 %v3428 to ptr
  %ld3430 = load i64, ptr %p3429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3430, ptr %slot631, align 8
  %v3431 = load i64, ptr %slot15, align 8
  store i64 %v3431, ptr %slot632, align 8
  %v3432 = load i64, ptr %slot631, align 8
  %v3433 = load i64, ptr %slot632, align 8
  %p3434 = inttoptr i64 %v3432 to ptr
  %p3435 = inttoptr i64 %v3433 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3435, ptr %p3434, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3436 = load i64, ptr %slot10, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  store i32 2, ptr %p3437, align 4, !alias.scope !3, !noalias !4
  %v3438 = load i64, ptr %slot9, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  store i32 1, ptr %p3439, align 4, !alias.scope !3, !noalias !4
  %v3440 = load i64, ptr %slot632, align 8
  %v3441 = load i64, ptr %slot22, align 8
  %p3442 = inttoptr i64 %v3441 to ptr
  store i64 %v3440, ptr %p3442, align 8, !alias.scope !3, !noalias !4
  %v3443 = load i64, ptr %slot32, align 8
  store i64 %v3443, ptr %slot633, align 8
  %v3444 = load i64, ptr %slot633, align 8
  %p3445 = inttoptr i64 %v3444 to ptr
  call void @llvm.memset.p0.i64(ptr %p3445, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !156
  %v3446 = load i64, ptr %slot633, align 8
  %p3447 = inttoptr i64 %v3446 to ptr
  store i32 0, ptr %p3447, align 4, !alias.scope !3, !noalias !4
  %v3448 = load i64, ptr %slot13, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  store i32 1, ptr %p3449, align 4, !alias.scope !3, !noalias !4
  %v3450 = load i64, ptr %slot22, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %ld3452 = load i64, ptr %p3451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3452, ptr %slot634, align 8
  %v3453 = load i64, ptr %slot633, align 8
  %p3455 = inttoptr i64 %v3453 to ptr
  %gep3456 = getelementptr i8, ptr %p3455, i64 8
  %op3454 = ptrtoint ptr %gep3456 to i64
  store i64 %op3454, ptr %slot635, align 8
  %v3457 = load i64, ptr %slot39, align 8
  store i64 %v3457, ptr %slot636, align 8
  %v3458 = load i64, ptr %slot22, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  %ld3460 = load i64, ptr %p3459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3460, ptr %slot637, align 8
  %v3461 = load i64, ptr %slot18, align 8
  store i64 %v3461, ptr %slot638, align 8
  %v3462 = load i64, ptr %slot39, align 8
  store i64 %v3462, ptr %slot639, align 8
  %v3463 = load i64, ptr %slot637, align 8
  %op3464 = add i64 %v3463, 0
  store i64 %op3464, ptr %slot640, align 8
  %v3465 = load i64, ptr %slot640, align 8
  %p3466 = inttoptr i64 %v3465 to ptr
  %ld3467 = load i64, ptr %p3466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3467, ptr %slot641, align 8
  %v3468 = load i64, ptr %slot641, align 8
  %cmp3469 = icmp ne i64 %v3468, 0
  %cv3470 = zext i1 %cmp3469 to i32
  store i32 %cv3470, ptr %slot642, align 8
  %v3471 = load i32, ptr %slot642, align 8
  %cv3472 = zext i32 %v3471 to i64
  %cond3473 = icmp ne i64 %cv3472, 0
  br i1 %cond3473, label %bb_rcmoveheader817, label %bb_rcmovenext817
bb_rcmoveheader817:
  %v3474 = load i64, ptr %slot641, align 8
  %op3475 = sub i64 %v3474, 16
  store i64 %op3475, ptr %slot643, align 8
  %v3476 = load i64, ptr %slot641, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  %rgep3478 = getelementptr i8, ptr %p3477, i64 -16
  %ld3479 = load i64, ptr %rgep3478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3479, ptr %slot644, align 8
  %v3480 = load i64, ptr %slot644, align 8
  %op3481 = and i64 %v3480, 5764607523034234881
  store i64 %op3481, ptr %slot645, align 8
  %v3482 = load i64, ptr %slot645, align 8
  %cmp3483 = icmp ne i64 %v3482, 0
  %cv3484 = zext i1 %cmp3483 to i32
  store i32 %cv3484, ptr %slot646, align 8
  %v3485 = load i32, ptr %slot646, align 8
  %cv3486 = zext i32 %v3485 to i64
  %cond3487 = icmp ne i64 %cv3486, 0
  br i1 %cond3487, label %bb_rcmoveslow814, label %bb_rcmovenext817
bb_rcmovenext817:
  %v3488 = load i64, ptr %slot637, align 8
  %v3489 = load i64, ptr %slot638, align 8
  %p3490 = inttoptr i64 %v3488 to ptr
  %p3491 = inttoptr i64 %v3489 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3491, ptr %p3490, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3492 = load i64, ptr %slot637, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  store i64 0, ptr %p3493, align 8, !alias.scope !3, !noalias !4
  %v3494 = load i64, ptr %slot637, align 8
  %op3495 = add i64 %v3494, 8
  store i64 %op3495, ptr %slot647, align 8
  %v3496 = load i64, ptr %slot647, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  store i64 0, ptr %p3497, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved814
bb_rcmoveslow814:
  %v3498 = load i64, ptr %slot38, align 8
  %v3499 = load i64, ptr %slot638, align 8
  %v3500 = load i64, ptr %slot637, align 8
  %v3501 = load i64, ptr %slot639, align 8
  %cv3502 = trunc i64 %v3501 to i32
  %call3503 = call i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_take(i64 %v3498, i64 %v3499, i64 %v3500, i32 %cv3502) nomerge, !dbg !156
  store i32 %call3503, ptr %slot648, align 8
  %v3504 = load i32, ptr %slot648, align 8
  %cv3505 = zext i32 %v3504 to i64
  %cond3506 = icmp ne i64 %cv3505, 0
  br i1 %cond3506, label %bb_rcsuccess825, label %bb_rcfailure825
bb_rcfailure825:
  %v3507 = load i64, ptr %slot38, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %call3509 = call i32 @myl_rc_take_failure(ptr %p3508) nomerge, !dbg !156
  store i32 %call3509, ptr %slot649, align 8
  %v3510 = load i64, ptr %slot1, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  %v3512 = load i32, ptr %slot649, align 8
  %call3513 = call i32 @myl_qbe_rc_status(ptr %p3511, i32 %v3512) nomerge, !dbg !156
  store i32 %call3513, ptr %slot650, align 8
  br label %bb_failure
bb_rcsuccess825:
  br label %bb_rcmoved814
bb_rcmoved814:
  %v3514 = load i64, ptr %slot9, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  store i32 0, ptr %p3515, align 4, !alias.scope !3, !noalias !4
  %v3516 = load i64, ptr %slot12, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  store i32 2, ptr %p3517, align 4, !alias.scope !3, !noalias !4
  %v3518 = load i64, ptr %slot11, align 8
  %p3519 = inttoptr i64 %v3518 to ptr
  store i32 1, ptr %p3519, align 4, !alias.scope !3, !noalias !4
  %v3520 = load i64, ptr %slot18, align 8
  store i64 %v3520, ptr %slot651, align 8
  %v3521 = load i64, ptr %slot651, align 8
  %v3522 = load i64, ptr %slot635, align 8
  %p3523 = inttoptr i64 %v3521 to ptr
  %p3524 = inttoptr i64 %v3522 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3524, ptr %p3523, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3525 = load i64, ptr %slot11, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  store i32 0, ptr %p3526, align 4, !alias.scope !3, !noalias !4
  %v3527 = load i64, ptr %slot633, align 8
  %v3528 = load i64, ptr %slot22, align 8
  %p3529 = inttoptr i64 %v3528 to ptr
  store i64 %v3527, ptr %p3529, align 8, !alias.scope !3, !noalias !4
  %v3530 = load i64, ptr %slot22, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  %ld3532 = load i64, ptr %p3531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3532, ptr %slot652, align 8
  %v3533 = load i64, ptr %slot15, align 8
  store i64 %v3533, ptr %slot653, align 8
  %v3534 = load i64, ptr %slot652, align 8
  %v3535 = load i64, ptr %slot653, align 8
  %p3536 = inttoptr i64 %v3534 to ptr
  %p3537 = inttoptr i64 %v3535 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3537, ptr %p3536, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3538 = load i64, ptr %slot10, align 8
  %p3539 = inttoptr i64 %v3538 to ptr
  store i32 2, ptr %p3539, align 4, !alias.scope !3, !noalias !4
  %v3540 = load i64, ptr %slot9, align 8
  %p3541 = inttoptr i64 %v3540 to ptr
  store i32 1, ptr %p3541, align 4, !alias.scope !3, !noalias !4
  %v3542 = load i64, ptr %slot653, align 8
  %v3543 = load i64, ptr %slot22, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  store i64 %v3542, ptr %p3544, align 8, !alias.scope !3, !noalias !4
  %v3545 = load i64, ptr %slot21, align 8
  %p3546 = inttoptr i64 %v3545 to ptr
  %ld3547 = load i64, ptr %p3546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3547, ptr %slot654, align 8
  %v3548 = load i64, ptr %slot22, align 8
  %p3549 = inttoptr i64 %v3548 to ptr
  %ld3550 = load i64, ptr %p3549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3550, ptr %slot655, align 8
  %v3551 = load i64, ptr %slot1, align 8
  %v3552 = load i64, ptr %slot654, align 8
  %v3553 = load i64, ptr %slot655, align 8
  %call3554 = call i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64 %v3551, i64 %v3552, i64 %v3553) nomerge, !dbg !158
  store i64 %call3554, ptr %slot656, align 8
  %v3555 = load i64, ptr %slot656, align 8
  %v3556 = load i64, ptr %slot21, align 8
  %p3557 = inttoptr i64 %v3556 to ptr
  store i64 %v3555, ptr %p3557, align 8, !alias.scope !3, !noalias !4
  %v3558 = load i64, ptr %slot7, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  %ld3560 = load i32, ptr %p3559, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3560, ptr %slot657, align 8
  %v3561 = load i32, ptr %slot657, align 8
  %cv3562 = zext i32 %v3561 to i64
  %cond3563 = icmp ne i64 %cv3562, 0
  br i1 %cond3563, label %bb_rcslotdrop842, label %bb_rcslotdone842
bb_rcslotdrop842:
  %v3564 = load i64, ptr %slot7, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  store i32 0, ptr %p3565, align 4, !alias.scope !3, !noalias !4
  %v3566 = load i64, ptr %slot14, align 8
  store i64 %v3566, ptr %slot658, align 8
  %v3567 = load i64, ptr %slot8, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  %ld3569 = load i32, ptr %p3568, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3569, ptr %slot659, align 8
  %v3570 = load i32, ptr %slot659, align 8
  %op3571 = and i32 %v3570, 28
  store i32 %op3571, ptr %slot660, align 8
  %v3572 = load i32, ptr %slot660, align 8
  %cv3573 = zext i32 %v3572 to i64
  %cond3574 = icmp ne i64 %cv3573, 0
  br i1 %cond3574, label %bb_rcslotrole842, label %bb_rcslotowner842
bb_rcslotrole842:
  %v3575 = load i64, ptr %slot38, align 8
  store i64 %v3575, ptr %slot661, align 8
  %v3576 = load i64, ptr %slot661, align 8
  %v3577 = load i64, ptr %slot658, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3576, i64 %v3577) nomerge, !dbg !158
  br label %bb_rcslotdone842
bb_rcslotowner842:
  %v3578 = load i64, ptr %slot38, align 8
  store i64 %v3578, ptr %slot662, align 8
  %v3579 = load i64, ptr %slot662, align 8
  %v3580 = load i64, ptr %slot658, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3579, i64 %v3580) nomerge, !dbg !158
  br label %bb_rcslotdone842
bb_rcslotdone842:
  %v3581 = load i64, ptr %slot9, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  %ld3583 = load i32, ptr %p3582, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3583, ptr %slot663, align 8
  %v3584 = load i32, ptr %slot663, align 8
  %cv3585 = zext i32 %v3584 to i64
  %cond3586 = icmp ne i64 %cv3585, 0
  br i1 %cond3586, label %bb_rcslotdrop851, label %bb_rcslotdone851
bb_rcslotdrop851:
  %v3587 = load i64, ptr %slot9, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  store i32 0, ptr %p3588, align 4, !alias.scope !3, !noalias !4
  %v3589 = load i64, ptr %slot15, align 8
  store i64 %v3589, ptr %slot664, align 8
  %v3590 = load i64, ptr %slot10, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  %ld3592 = load i32, ptr %p3591, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3592, ptr %slot665, align 8
  %v3593 = load i32, ptr %slot665, align 8
  %op3594 = and i32 %v3593, 28
  store i32 %op3594, ptr %slot666, align 8
  %v3595 = load i32, ptr %slot666, align 8
  %cv3596 = zext i32 %v3595 to i64
  %cond3597 = icmp ne i64 %cv3596, 0
  br i1 %cond3597, label %bb_rcslotrole851, label %bb_rcslotowner851
bb_rcslotrole851:
  %v3598 = load i64, ptr %slot38, align 8
  store i64 %v3598, ptr %slot667, align 8
  %v3599 = load i64, ptr %slot667, align 8
  %v3600 = load i64, ptr %slot664, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v3599, i64 %v3600) nomerge, !dbg !158
  br label %bb_rcslotdone851
bb_rcslotowner851:
  %v3601 = load i64, ptr %slot38, align 8
  store i64 %v3601, ptr %slot668, align 8
  %v3602 = load i64, ptr %slot668, align 8
  %v3603 = load i64, ptr %slot664, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v3602, i64 %v3603) nomerge, !dbg !158
  br label %bb_rcslotdone851
bb_rcslotdone851:
  %v3604 = load i64, ptr %slot33, align 8
  store i64 %v3604, ptr %slot669, align 8
  %v3605 = load i64, ptr %slot669, align 8
  %p3606 = inttoptr i64 %v3605 to ptr
  store i64 0, ptr %p3606, align 8, !alias.scope !3, !noalias !4
  %v3607 = load i64, ptr %slot669, align 8
  %p3609 = inttoptr i64 %v3607 to ptr
  %gep3610 = getelementptr i8, ptr %p3609, i64 8
  %op3608 = ptrtoint ptr %gep3610 to i64
  store i64 %op3608, ptr %slot670, align 8
  %v3611 = load i64, ptr %slot670, align 8
  %p3612 = inttoptr i64 %v3611 to ptr
  store i64 0, ptr %p3612, align 8, !alias.scope !3, !noalias !4
  %v3613 = load i64, ptr %slot669, align 8
  %p3614 = inttoptr i64 %v3613 to ptr
  store i32 0, ptr %p3614, align 4, !alias.scope !3, !noalias !4
  %v3615 = load i64, ptr %slot13, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  store i32 1, ptr %p3616, align 4, !alias.scope !3, !noalias !4
  %v3617 = load i64, ptr %slot21, align 8
  store i64 %v3617, ptr %slot671, align 8
  %v3618 = load i64, ptr %slot669, align 8
  %p3620 = inttoptr i64 %v3618 to ptr
  %gep3621 = getelementptr i8, ptr %p3620, i64 8
  %op3619 = ptrtoint ptr %gep3621 to i64
  store i64 %op3619, ptr %slot672, align 8
  %v3622 = load i64, ptr %slot39, align 8
  store i64 %v3622, ptr %slot673, align 8
  %v3623 = load i64, ptr %slot671, align 8
  %p3624 = inttoptr i64 %v3623 to ptr
  %ld3625 = load i64, ptr %p3624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3625, ptr %slot674, align 8
  %v3626 = load i64, ptr %slot674, align 8
  %v3627 = load i64, ptr %slot672, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  store i64 %v3626, ptr %p3628, align 8, !alias.scope !3, !noalias !4
  %v3629 = load i64, ptr %slot669, align 8
  %v3630 = load i64, ptr %slot21, align 8
  %p3631 = inttoptr i64 %v3630 to ptr
  store i64 %v3629, ptr %p3631, align 8, !alias.scope !3, !noalias !4
  %v3632 = load i64, ptr %slot21, align 8
  %p3633 = inttoptr i64 %v3632 to ptr
  %ld3634 = load i64, ptr %p3633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3634, ptr %slot675, align 8
  %v3635 = load i64, ptr %slot7, align 8
  %p3636 = inttoptr i64 %v3635 to ptr
  %ld3637 = load i32, ptr %p3636, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3637, ptr %slot676, align 8
  %v3638 = load i32, ptr %slot676, align 8
  %cv3639 = zext i32 %v3638 to i64
  %cond3640 = icmp ne i64 %cv3639, 0
  br i1 %cond3640, label %bb_rcslotdrop869, label %bb_rcslotdone869
bb_rcslotdrop869:
  %v3641 = load i64, ptr %slot7, align 8
  %p3642 = inttoptr i64 %v3641 to ptr
  store i32 0, ptr %p3642, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone869
bb_rcslotdone869:
  %v3643 = load i64, ptr %slot5, align 8
  %p3644 = inttoptr i64 %v3643 to ptr
  %ld3645 = load i32, ptr %p3644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3645, ptr %slot677, align 8
  %v3646 = load i32, ptr %slot677, align 8
  %cv3647 = zext i32 %v3646 to i64
  %cond3648 = icmp ne i64 %cv3647, 0
  br i1 %cond3648, label %bb_rcslotdrop872, label %bb_rcslotdone872
bb_rcslotdrop872:
  %v3649 = load i64, ptr %slot5, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  store i32 0, ptr %p3650, align 4, !alias.scope !3, !noalias !4
  %v3651 = load i64, ptr %slot20, align 8
  store i64 %v3651, ptr %slot678, align 8
  %v3652 = load i64, ptr %slot6, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  %ld3654 = load i32, ptr %p3653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3654, ptr %slot679, align 8
  %v3655 = load i32, ptr %slot679, align 8
  %op3656 = and i32 %v3655, 28
  store i32 %op3656, ptr %slot680, align 8
  %v3657 = load i32, ptr %slot680, align 8
  %cv3658 = zext i32 %v3657 to i64
  %cond3659 = icmp ne i64 %cv3658, 0
  br i1 %cond3659, label %bb_rcslotrole872, label %bb_rcslotowner872
bb_rcslotrole872:
  %v3660 = load i64, ptr %slot38, align 8
  store i64 %v3660, ptr %slot681, align 8
  %v3661 = load i64, ptr %slot678, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %ld3663 = load i64, ptr %p3662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3663, ptr %slot682, align 8
  %v3664 = load i64, ptr %slot682, align 8
  %cmp3665 = icmp ne i64 %v3664, 0
  %cv3666 = zext i1 %cmp3665 to i32
  store i32 %cv3666, ptr %slot683, align 8
  %v3667 = load i32, ptr %slot683, align 8
  %cv3668 = zext i32 %v3667 to i64
  %cond3669 = icmp ne i64 %cv3668, 0
  br i1 %cond3669, label %bb_rcgnn888, label %bb_rcgdone888
bb_rcgnn888:
  %v3670 = load i64, ptr %slot682, align 8
  %op3671 = sub i64 %v3670, 16
  store i64 %op3671, ptr %slot684, align 8
  %v3672 = load i64, ptr %slot682, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  %rgep3674 = getelementptr i8, ptr %p3673, i64 -16
  %ld3675 = load i64, ptr %rgep3674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3675, ptr %slot685, align 8
  %v3676 = load i64, ptr %slot685, align 8
  %op3677 = and i64 %v3676, 4611686018427387906
  store i64 %op3677, ptr %slot686, align 8
  %v3678 = load i64, ptr %slot686, align 8
  %cmp3679 = icmp ne i64 %v3678, 0
  %cv3680 = zext i1 %cmp3679 to i32
  store i32 %cv3680, ptr %slot687, align 8
  %v3681 = load i32, ptr %slot687, align 8
  %cv3682 = zext i32 %v3681 to i64
  %cond3683 = icmp ne i64 %cv3682, 0
  br i1 %cond3683, label %bb_rcgclear888, label %bb_rcgcounted888
bb_rcgcounted888:
  %v3684 = load i64, ptr %slot682, align 8
  %op3685 = sub i64 %v3684, 24
  store i64 %op3685, ptr %slot688, align 8
  %v3686 = load i64, ptr %slot682, align 8
  %p3687 = inttoptr i64 %v3686 to ptr
  %rgep3688 = getelementptr i8, ptr %p3687, i64 -24
  %ld3689 = load i64, ptr %rgep3688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3689, ptr %slot689, align 8
  %v3690 = load i64, ptr %slot689, align 8
  %op3691 = sub i64 %v3690, 1
  store i64 %op3691, ptr %slot690, align 8
  %v3692 = load i64, ptr %slot690, align 8
  %cmp3693 = icmp eq i64 %v3692, 0
  %cv3694 = zext i1 %cmp3693 to i32
  store i32 %cv3694, ptr %slot691, align 8
  %v3695 = load i32, ptr %slot691, align 8
  %cv3696 = zext i32 %v3695 to i64
  %cond3697 = icmp ne i64 %cv3696, 0
  br i1 %cond3697, label %bb_rcglast888, label %bb_rcgdec888
bb_rcglast888:
  %v3698 = load i64, ptr %slot682, align 8
  %op3699 = sub i64 %v3698, 32
  store i64 %op3699, ptr %slot692, align 8
  %v3700 = load i64, ptr %slot682, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %rgep3702 = getelementptr i8, ptr %p3701, i64 -32
  %ld3703 = load i64, ptr %rgep3702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3703, ptr %slot693, align 8
  %v3704 = load i64, ptr %slot693, align 8
  %cmp3705 = icmp ne i64 %v3704, 0
  %cv3706 = zext i1 %cmp3705 to i32
  store i32 %cv3706, ptr %slot694, align 8
  %v3707 = load i32, ptr %slot694, align 8
  %cv3708 = zext i32 %v3707 to i64
  %cond3709 = icmp ne i64 %cv3708, 0
  br i1 %cond3709, label %bb_rcgdec888, label %bb_rcgslow888
bb_rcgslow888:
  %v3710 = load i64, ptr %slot681, align 8
  %v3711 = load i64, ptr %slot678, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3710, i64 %v3711) nomerge, !dbg !160
  br label %bb_rcgdone888
bb_rcgdec888:
  %v3712 = load i64, ptr %slot690, align 8
  %v3713 = load i64, ptr %slot682, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  %rgep3715 = getelementptr i8, ptr %p3714, i64 -24
  store i64 %v3712, ptr %rgep3715, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear888
bb_rcgclear888:
  %v3716 = load i64, ptr %slot678, align 8
  %p3717 = inttoptr i64 %v3716 to ptr
  store i64 0, ptr %p3717, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone888
bb_rcgdone888:
  br label %bb_rcslotdone872
bb_rcslotowner872:
  %v3718 = load i64, ptr %slot38, align 8
  store i64 %v3718, ptr %slot695, align 8
  %v3719 = load i64, ptr %slot678, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %ld3721 = load i64, ptr %p3720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3721, ptr %slot696, align 8
  %v3722 = load i64, ptr %slot696, align 8
  %cmp3723 = icmp ne i64 %v3722, 0
  %cv3724 = zext i1 %cmp3723 to i32
  store i32 %cv3724, ptr %slot697, align 8
  %v3725 = load i32, ptr %slot697, align 8
  %cv3726 = zext i32 %v3725 to i64
  %cond3727 = icmp ne i64 %cv3726, 0
  br i1 %cond3727, label %bb_rcgnn903, label %bb_rcgdone903
bb_rcgnn903:
  %v3728 = load i64, ptr %slot696, align 8
  %op3729 = sub i64 %v3728, 16
  store i64 %op3729, ptr %slot698, align 8
  %v3730 = load i64, ptr %slot696, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  %rgep3732 = getelementptr i8, ptr %p3731, i64 -16
  %ld3733 = load i64, ptr %rgep3732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3733, ptr %slot699, align 8
  %v3734 = load i64, ptr %slot699, align 8
  %op3735 = and i64 %v3734, 4611686018427387906
  store i64 %op3735, ptr %slot700, align 8
  %v3736 = load i64, ptr %slot700, align 8
  %cmp3737 = icmp ne i64 %v3736, 0
  %cv3738 = zext i1 %cmp3737 to i32
  store i32 %cv3738, ptr %slot701, align 8
  %v3739 = load i32, ptr %slot701, align 8
  %cv3740 = zext i32 %v3739 to i64
  %cond3741 = icmp ne i64 %cv3740, 0
  br i1 %cond3741, label %bb_rcgclear903, label %bb_rcgcounted903
bb_rcgcounted903:
  %v3742 = load i64, ptr %slot696, align 8
  %op3743 = sub i64 %v3742, 32
  store i64 %op3743, ptr %slot702, align 8
  %v3744 = load i64, ptr %slot696, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  %rgep3746 = getelementptr i8, ptr %p3745, i64 -32
  %ld3747 = load i64, ptr %rgep3746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3747, ptr %slot703, align 8
  %v3748 = load i64, ptr %slot703, align 8
  %op3749 = sub i64 %v3748, 1
  store i64 %op3749, ptr %slot704, align 8
  %v3750 = load i64, ptr %slot704, align 8
  %cmp3751 = icmp eq i64 %v3750, 0
  %cv3752 = zext i1 %cmp3751 to i32
  store i32 %cv3752, ptr %slot705, align 8
  %v3753 = load i32, ptr %slot705, align 8
  %cv3754 = zext i32 %v3753 to i64
  %cond3755 = icmp ne i64 %cv3754, 0
  br i1 %cond3755, label %bb_rcglast903, label %bb_rcgdec903
bb_rcglast903:
  %v3756 = load i64, ptr %slot696, align 8
  %op3757 = sub i64 %v3756, 24
  store i64 %op3757, ptr %slot706, align 8
  %v3758 = load i64, ptr %slot696, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  %rgep3760 = getelementptr i8, ptr %p3759, i64 -24
  %ld3761 = load i64, ptr %rgep3760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3761, ptr %slot707, align 8
  %v3762 = load i64, ptr %slot707, align 8
  %cmp3763 = icmp ne i64 %v3762, 0
  %cv3764 = zext i1 %cmp3763 to i32
  store i32 %cv3764, ptr %slot708, align 8
  %v3765 = load i32, ptr %slot708, align 8
  %cv3766 = zext i32 %v3765 to i64
  %cond3767 = icmp ne i64 %cv3766, 0
  br i1 %cond3767, label %bb_rcgdec903, label %bb_rcgslow903
bb_rcgslow903:
  %v3768 = load i64, ptr %slot695, align 8
  %v3769 = load i64, ptr %slot678, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3768, i64 %v3769) nomerge, !dbg !160
  br label %bb_rcgdone903
bb_rcgdec903:
  %v3770 = load i64, ptr %slot704, align 8
  %v3771 = load i64, ptr %slot696, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  %rgep3773 = getelementptr i8, ptr %p3772, i64 -32
  store i64 %v3770, ptr %rgep3773, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear903
bb_rcgclear903:
  %v3774 = load i64, ptr %slot678, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  store i64 0, ptr %p3775, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone903
bb_rcgdone903:
  br label %bb_rcslotdone872
bb_rcslotdone872:
  %v3776 = load i64, ptr %slot675, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  %ret3778 = load { i64, i64 }, ptr %p3777, align 8
  ret { i64, i64 } %ret3778
bb_i54:
  %v3779 = load i64, ptr %slot19, align 8
  %p3780 = inttoptr i64 %v3779 to ptr
  %ld3781 = load i64, ptr %p3780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3781, ptr %slot709, align 8
  %v3782 = load i64, ptr %slot709, align 8
  %v3783 = load i64, ptr %slot21, align 8
  %p3784 = inttoptr i64 %v3783 to ptr
  store i64 %v3782, ptr %p3784, align 8, !alias.scope !3, !noalias !4
  %v3785 = load i64, ptr %slot21, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i64, ptr %p3786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3787, ptr %slot710, align 8
  %v3788 = load i64, ptr %slot1, align 8
  %v3789 = load i64, ptr %slot710, align 8
  %call3790 = call { i64, i64 } @myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a(i64 %v3788, i64 %v3789) nomerge, !dbg !162
  store { i64, i64 } %call3790, ptr %callresult712, align 8
  %addr3791 = ptrtoint ptr %callresult712 to i64
  store i64 %addr3791, ptr %slot711, align 8
  %v3792 = load i64, ptr %slot711, align 8
  %v3793 = load i64, ptr %slot21, align 8
  %p3794 = inttoptr i64 %v3793 to ptr
  store i64 %v3792, ptr %p3794, align 8, !alias.scope !3, !noalias !4
  %v3795 = load i64, ptr %slot7, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  %ld3797 = load i32, ptr %p3796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3797, ptr %slot713, align 8
  %v3798 = load i32, ptr %slot713, align 8
  %cv3799 = zext i32 %v3798 to i64
  %cond3800 = icmp ne i64 %cv3799, 0
  br i1 %cond3800, label %bb_rcslotdrop921, label %bb_rcslotdone921
bb_rcslotdrop921:
  %v3801 = load i64, ptr %slot7, align 8
  %p3802 = inttoptr i64 %v3801 to ptr
  store i32 0, ptr %p3802, align 4, !alias.scope !3, !noalias !4
  %v3803 = load i64, ptr %slot14, align 8
  store i64 %v3803, ptr %slot714, align 8
  %v3804 = load i64, ptr %slot8, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  %ld3806 = load i32, ptr %p3805, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3806, ptr %slot715, align 8
  %v3807 = load i32, ptr %slot715, align 8
  %op3808 = and i32 %v3807, 28
  store i32 %op3808, ptr %slot716, align 8
  %v3809 = load i32, ptr %slot716, align 8
  %cv3810 = zext i32 %v3809 to i64
  %cond3811 = icmp ne i64 %cv3810, 0
  br i1 %cond3811, label %bb_rcslotrole921, label %bb_rcslotowner921
bb_rcslotrole921:
  %v3812 = load i64, ptr %slot38, align 8
  store i64 %v3812, ptr %slot717, align 8
  %v3813 = load i64, ptr %slot717, align 8
  %v3814 = load i64, ptr %slot714, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3813, i64 %v3814) nomerge, !dbg !162
  br label %bb_rcslotdone921
bb_rcslotowner921:
  %v3815 = load i64, ptr %slot38, align 8
  store i64 %v3815, ptr %slot718, align 8
  %v3816 = load i64, ptr %slot718, align 8
  %v3817 = load i64, ptr %slot714, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3816, i64 %v3817) nomerge, !dbg !162
  br label %bb_rcslotdone921
bb_rcslotdone921:
  %v3818 = load i64, ptr %slot21, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  %ld3820 = load i64, ptr %p3819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3820, ptr %slot719, align 8
  %v3821 = load i64, ptr %slot719, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  %ld3823 = load i32, ptr %p3822, align 4
  %ext3824 = zext i32 %ld3823 to i64
  store i64 %ext3824, ptr %slot720, align 8
  %v3825 = load i64, ptr %slot720, align 8
  %cmp3826 = icmp eq i64 %v3825, 1
  %cv3827 = zext i1 %cmp3826 to i64
  store i64 %cv3827, ptr %slot721, align 8
  %v3828 = load i64, ptr %slot721, align 8
  %cond3829 = icmp ne i64 %v3828, 0
  br i1 %cond3829, label %bb_errtrace930, label %bb_errtraced930
bb_errtrace930:
  %p3830 = inttoptr i64 ptrtoint (ptr @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3830, i64 8589934648) "call-inline-cost"="0", !dbg !164
  br label %bb_errtraced930
bb_errtraced930:
  %v3831 = load i64, ptr %slot7, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %ld3833 = load i32, ptr %p3832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3833, ptr %slot722, align 8
  %v3834 = load i32, ptr %slot722, align 8
  %cv3835 = zext i32 %v3834 to i64
  %cond3836 = icmp ne i64 %cv3835, 0
  br i1 %cond3836, label %bb_rcslotdrop933, label %bb_rcslotdone933
bb_rcslotdrop933:
  %v3837 = load i64, ptr %slot7, align 8
  %p3838 = inttoptr i64 %v3837 to ptr
  store i32 0, ptr %p3838, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone933
bb_rcslotdone933:
  %v3839 = load i64, ptr %slot5, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  %ld3841 = load i32, ptr %p3840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3841, ptr %slot723, align 8
  %v3842 = load i32, ptr %slot723, align 8
  %cv3843 = zext i32 %v3842 to i64
  %cond3844 = icmp ne i64 %cv3843, 0
  br i1 %cond3844, label %bb_rcslotdrop936, label %bb_rcslotdone936
bb_rcslotdrop936:
  %v3845 = load i64, ptr %slot5, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  store i32 0, ptr %p3846, align 4, !alias.scope !3, !noalias !4
  %v3847 = load i64, ptr %slot20, align 8
  store i64 %v3847, ptr %slot724, align 8
  %v3848 = load i64, ptr %slot6, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  %ld3850 = load i32, ptr %p3849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3850, ptr %slot725, align 8
  %v3851 = load i32, ptr %slot725, align 8
  %op3852 = and i32 %v3851, 28
  store i32 %op3852, ptr %slot726, align 8
  %v3853 = load i32, ptr %slot726, align 8
  %cv3854 = zext i32 %v3853 to i64
  %cond3855 = icmp ne i64 %cv3854, 0
  br i1 %cond3855, label %bb_rcslotrole936, label %bb_rcslotowner936
bb_rcslotrole936:
  %v3856 = load i64, ptr %slot38, align 8
  store i64 %v3856, ptr %slot727, align 8
  %v3857 = load i64, ptr %slot724, align 8
  %p3858 = inttoptr i64 %v3857 to ptr
  %ld3859 = load i64, ptr %p3858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3859, ptr %slot728, align 8
  %v3860 = load i64, ptr %slot728, align 8
  %cmp3861 = icmp ne i64 %v3860, 0
  %cv3862 = zext i1 %cmp3861 to i32
  store i32 %cv3862, ptr %slot729, align 8
  %v3863 = load i32, ptr %slot729, align 8
  %cv3864 = zext i32 %v3863 to i64
  %cond3865 = icmp ne i64 %cv3864, 0
  br i1 %cond3865, label %bb_rcgnn952, label %bb_rcgdone952
bb_rcgnn952:
  %v3866 = load i64, ptr %slot728, align 8
  %op3867 = sub i64 %v3866, 16
  store i64 %op3867, ptr %slot730, align 8
  %v3868 = load i64, ptr %slot728, align 8
  %p3869 = inttoptr i64 %v3868 to ptr
  %rgep3870 = getelementptr i8, ptr %p3869, i64 -16
  %ld3871 = load i64, ptr %rgep3870, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3871, ptr %slot731, align 8
  %v3872 = load i64, ptr %slot731, align 8
  %op3873 = and i64 %v3872, 4611686018427387906
  store i64 %op3873, ptr %slot732, align 8
  %v3874 = load i64, ptr %slot732, align 8
  %cmp3875 = icmp ne i64 %v3874, 0
  %cv3876 = zext i1 %cmp3875 to i32
  store i32 %cv3876, ptr %slot733, align 8
  %v3877 = load i32, ptr %slot733, align 8
  %cv3878 = zext i32 %v3877 to i64
  %cond3879 = icmp ne i64 %cv3878, 0
  br i1 %cond3879, label %bb_rcgclear952, label %bb_rcgcounted952
bb_rcgcounted952:
  %v3880 = load i64, ptr %slot728, align 8
  %op3881 = sub i64 %v3880, 24
  store i64 %op3881, ptr %slot734, align 8
  %v3882 = load i64, ptr %slot728, align 8
  %p3883 = inttoptr i64 %v3882 to ptr
  %rgep3884 = getelementptr i8, ptr %p3883, i64 -24
  %ld3885 = load i64, ptr %rgep3884, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3885, ptr %slot735, align 8
  %v3886 = load i64, ptr %slot735, align 8
  %op3887 = sub i64 %v3886, 1
  store i64 %op3887, ptr %slot736, align 8
  %v3888 = load i64, ptr %slot736, align 8
  %cmp3889 = icmp eq i64 %v3888, 0
  %cv3890 = zext i1 %cmp3889 to i32
  store i32 %cv3890, ptr %slot737, align 8
  %v3891 = load i32, ptr %slot737, align 8
  %cv3892 = zext i32 %v3891 to i64
  %cond3893 = icmp ne i64 %cv3892, 0
  br i1 %cond3893, label %bb_rcglast952, label %bb_rcgdec952
bb_rcglast952:
  %v3894 = load i64, ptr %slot728, align 8
  %op3895 = sub i64 %v3894, 32
  store i64 %op3895, ptr %slot738, align 8
  %v3896 = load i64, ptr %slot728, align 8
  %p3897 = inttoptr i64 %v3896 to ptr
  %rgep3898 = getelementptr i8, ptr %p3897, i64 -32
  %ld3899 = load i64, ptr %rgep3898, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3899, ptr %slot739, align 8
  %v3900 = load i64, ptr %slot739, align 8
  %cmp3901 = icmp ne i64 %v3900, 0
  %cv3902 = zext i1 %cmp3901 to i32
  store i32 %cv3902, ptr %slot740, align 8
  %v3903 = load i32, ptr %slot740, align 8
  %cv3904 = zext i32 %v3903 to i64
  %cond3905 = icmp ne i64 %cv3904, 0
  br i1 %cond3905, label %bb_rcgdec952, label %bb_rcgslow952
bb_rcgslow952:
  %v3906 = load i64, ptr %slot727, align 8
  %v3907 = load i64, ptr %slot724, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3906, i64 %v3907) nomerge, !dbg !164
  br label %bb_rcgdone952
bb_rcgdec952:
  %v3908 = load i64, ptr %slot736, align 8
  %v3909 = load i64, ptr %slot728, align 8
  %p3910 = inttoptr i64 %v3909 to ptr
  %rgep3911 = getelementptr i8, ptr %p3910, i64 -24
  store i64 %v3908, ptr %rgep3911, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear952
bb_rcgclear952:
  %v3912 = load i64, ptr %slot724, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  store i64 0, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone952
bb_rcgdone952:
  br label %bb_rcslotdone936
bb_rcslotowner936:
  %v3914 = load i64, ptr %slot38, align 8
  store i64 %v3914, ptr %slot741, align 8
  %v3915 = load i64, ptr %slot724, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  %ld3917 = load i64, ptr %p3916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3917, ptr %slot742, align 8
  %v3918 = load i64, ptr %slot742, align 8
  %cmp3919 = icmp ne i64 %v3918, 0
  %cv3920 = zext i1 %cmp3919 to i32
  store i32 %cv3920, ptr %slot743, align 8
  %v3921 = load i32, ptr %slot743, align 8
  %cv3922 = zext i32 %v3921 to i64
  %cond3923 = icmp ne i64 %cv3922, 0
  br i1 %cond3923, label %bb_rcgnn967, label %bb_rcgdone967
bb_rcgnn967:
  %v3924 = load i64, ptr %slot742, align 8
  %op3925 = sub i64 %v3924, 16
  store i64 %op3925, ptr %slot744, align 8
  %v3926 = load i64, ptr %slot742, align 8
  %p3927 = inttoptr i64 %v3926 to ptr
  %rgep3928 = getelementptr i8, ptr %p3927, i64 -16
  %ld3929 = load i64, ptr %rgep3928, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3929, ptr %slot745, align 8
  %v3930 = load i64, ptr %slot745, align 8
  %op3931 = and i64 %v3930, 4611686018427387906
  store i64 %op3931, ptr %slot746, align 8
  %v3932 = load i64, ptr %slot746, align 8
  %cmp3933 = icmp ne i64 %v3932, 0
  %cv3934 = zext i1 %cmp3933 to i32
  store i32 %cv3934, ptr %slot747, align 8
  %v3935 = load i32, ptr %slot747, align 8
  %cv3936 = zext i32 %v3935 to i64
  %cond3937 = icmp ne i64 %cv3936, 0
  br i1 %cond3937, label %bb_rcgclear967, label %bb_rcgcounted967
bb_rcgcounted967:
  %v3938 = load i64, ptr %slot742, align 8
  %op3939 = sub i64 %v3938, 32
  store i64 %op3939, ptr %slot748, align 8
  %v3940 = load i64, ptr %slot742, align 8
  %p3941 = inttoptr i64 %v3940 to ptr
  %rgep3942 = getelementptr i8, ptr %p3941, i64 -32
  %ld3943 = load i64, ptr %rgep3942, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3943, ptr %slot749, align 8
  %v3944 = load i64, ptr %slot749, align 8
  %op3945 = sub i64 %v3944, 1
  store i64 %op3945, ptr %slot750, align 8
  %v3946 = load i64, ptr %slot750, align 8
  %cmp3947 = icmp eq i64 %v3946, 0
  %cv3948 = zext i1 %cmp3947 to i32
  store i32 %cv3948, ptr %slot751, align 8
  %v3949 = load i32, ptr %slot751, align 8
  %cv3950 = zext i32 %v3949 to i64
  %cond3951 = icmp ne i64 %cv3950, 0
  br i1 %cond3951, label %bb_rcglast967, label %bb_rcgdec967
bb_rcglast967:
  %v3952 = load i64, ptr %slot742, align 8
  %op3953 = sub i64 %v3952, 24
  store i64 %op3953, ptr %slot752, align 8
  %v3954 = load i64, ptr %slot742, align 8
  %p3955 = inttoptr i64 %v3954 to ptr
  %rgep3956 = getelementptr i8, ptr %p3955, i64 -24
  %ld3957 = load i64, ptr %rgep3956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3957, ptr %slot753, align 8
  %v3958 = load i64, ptr %slot753, align 8
  %cmp3959 = icmp ne i64 %v3958, 0
  %cv3960 = zext i1 %cmp3959 to i32
  store i32 %cv3960, ptr %slot754, align 8
  %v3961 = load i32, ptr %slot754, align 8
  %cv3962 = zext i32 %v3961 to i64
  %cond3963 = icmp ne i64 %cv3962, 0
  br i1 %cond3963, label %bb_rcgdec967, label %bb_rcgslow967
bb_rcgslow967:
  %v3964 = load i64, ptr %slot741, align 8
  %v3965 = load i64, ptr %slot724, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3964, i64 %v3965) nomerge, !dbg !164
  br label %bb_rcgdone967
bb_rcgdec967:
  %v3966 = load i64, ptr %slot750, align 8
  %v3967 = load i64, ptr %slot742, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  %rgep3969 = getelementptr i8, ptr %p3968, i64 -32
  store i64 %v3966, ptr %rgep3969, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear967
bb_rcgclear967:
  %v3970 = load i64, ptr %slot724, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  store i64 0, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone967
bb_rcgdone967:
  br label %bb_rcslotdone936
bb_rcslotdone936:
  %v3972 = load i64, ptr %slot719, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  %ret3974 = load { i64, i64 }, ptr %p3973, align 8
  ret { i64, i64 } %ret3974
bb_failure:
  %v3975 = load i64, ptr %slot4, align 8
  %p3976 = inttoptr i64 %v3975 to ptr
  call void @llvm.memset.p0.i64(ptr %p3976, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !164
  %v3977 = load i64, ptr %slot4, align 8
  %p3978 = inttoptr i64 %v3977 to ptr
  %ret3979 = load { i64, i64 }, ptr %p3978, align 8
  ret { i64, i64 } %ret3979
bb_entry_failure:
  %v3980 = load i64, ptr %slot4, align 8
  %p3981 = inttoptr i64 %v3980 to ptr
  call void @llvm.memset.p0.i64(ptr %p3981, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !164
  %v3982 = load i64, ptr %slot4, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  %ret3984 = load { i64, i64 }, ptr %p3983, align 8
  ret { i64, i64 } %ret3984
}

@myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_06eb873f931b6af3b9e3c3af09cb8b150ce0a70e7c0f586985752bb1968e9166(i64, i64)
declare { i64, i64 } @myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0(i64, i64)
declare { i64, i64 } @myl_f_3d0ed1b0d0b04076bd3cd0e8349ea2cfddbbd0b8a1ecec907313fe976375cba2(i64, i64)
declare { i64, i64 } @myl_f_3ef605d87069af79e10307d85e24cc1def519b618d8c48a20828cacd99a2f11b(i64, i64)
declare { i64, i64 } @myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a(i64, i64)
declare i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64, i64, i64)
declare { i64, i64 } @myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425(i64, i64)
declare i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64, i64, i64)
declare { i64, i64 } @myl_f_c75868580de8a50d8a792a8a996aae0a3ad208c1ff95b19e5793cb5a5af05750(i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_06005f19782a154db14c3648126bc531b7c6a611fda445b4b8c894526f5c007a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_drop(i64, i64)
declare void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_unloan(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a", linkageName: "myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8546306619315501924, i64 0, !"myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!124 = !DILocation(line: 14, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!126 = !DILocation(line: 17, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!128 = !DILocation(line: 20, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!130 = !DILocation(line: 21, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!132 = !DILocation(line: 24, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!134 = !DILocation(line: 27, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!136 = !DILocation(line: 28, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!138 = !DILocation(line: 31, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!140 = !DILocation(line: 34, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!142 = !DILocation(line: 35, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!144 = !DILocation(line: 38, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!146 = !DILocation(line: 41, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!148 = !DILocation(line: 42, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!150 = !DILocation(line: 44, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!152 = !DILocation(line: 45, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!154 = !DILocation(line: 50, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!156 = !DILocation(line: 51, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!158 = !DILocation(line: 52, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!160 = !DILocation(line: 54, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!162 = !DILocation(line: 56, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!164 = !DILocation(line: 57, column: 0, scope: !165)
