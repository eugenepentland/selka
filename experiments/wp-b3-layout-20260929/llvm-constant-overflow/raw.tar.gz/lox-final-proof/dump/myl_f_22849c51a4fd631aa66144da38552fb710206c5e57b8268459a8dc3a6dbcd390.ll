target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v152 = load i64, ptr %slot1, align 8
  %op153 = add i64 %v152, 32
  store i64 %op153, ptr %slot3, align 8
  %mem154 = alloca i8, i64 8, align 8
  %ptr155 = ptrtoint ptr %mem154 to i64
  store i64 %ptr155, ptr %slot4, align 8
  %mem156 = alloca i8, i64 8, align 8
  %ptr157 = ptrtoint ptr %mem156 to i64
  store i64 %ptr157, ptr %slot5, align 8
  %mem158 = alloca i8, i64 8, align 8
  %ptr159 = ptrtoint ptr %mem158 to i64
  store i64 %ptr159, ptr %slot6, align 8
  %mem160 = alloca i8, i64 8, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot7, align 8
  %mem162 = alloca i8, i64 8, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot8, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot9, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot10, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot11, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot12, align 8
  %v172 = load i64, ptr %slot6, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i64 0, ptr %p173, align 8, !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot8, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i64 0, ptr %p175, align 8, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot2, align 8
  %v177 = load i64, ptr %slot4, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i64 %v176, ptr %p178, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v179 = load i64, ptr %slot4, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld181, ptr %slot13, align 8
  %v182 = load i64, ptr %slot13, align 8
  %v183 = load i64, ptr %slot10, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 %v182, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot10, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %ld187 = load i64, ptr %p186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld187, ptr %slot14, align 8
  %v188 = load i64, ptr %slot14, align 8
  %op189 = add i64 %v188, 24
  store i64 %op189, ptr %slot15, align 8
  %v190 = load i64, ptr %slot15, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i64, ptr %p191, align 8, !alias.scope !4, !noalias !3
  store i64 %ld192, ptr %slot16, align 8
  %v193 = load i64, ptr %slot16, align 8
  %v194 = load i64, ptr %slot10, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 %v193, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot11, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 2, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot11, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot17, align 8
  %v201 = load i64, ptr %slot10, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i64, ptr %p202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld203, ptr %slot18, align 8
  %v204 = load i64, ptr %slot18, align 8
  %v205 = load i64, ptr %slot17, align 8
  %op206 = add i64 %v204, %v205
  store i64 %op206, ptr %slot19, align 8
  %v207 = load i64, ptr %slot18, align 8
  %cmp208 = icmp sgt i64 %v207, 9223372036854775805
  %cv209 = zext i1 %cmp208 to i64
  store i64 %cv209, ptr %slot20, align 8
  %v210 = load i64, ptr %slot20, align 8
  %cond211 = icmp ne i64 %v210, 0
  br i1 %cond211, label %bb_overflow19, label %bb_checked19
bb_overflow19:
  %v212 = load i64, ptr %slot1, align 8
  %p213 = inttoptr i64 %v212 to ptr
  %v214 = load i64, ptr %slot18, align 8
  %v215 = load i64, ptr %slot17, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p213, i64 0, i64 %v214, i64 %v215, i64 64) nomerge, !dbg !110
  unreachable
bb_checked19:
  %v216 = load i64, ptr %slot19, align 8
  %v217 = load i64, ptr %slot10, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 %v216, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot10, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot21, align 8
  %v222 = load i64, ptr %slot21, align 8
  %v223 = load i64, ptr %slot5, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i64 %v222, ptr %p224, align 8, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot4, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot22, align 8
  %v228 = load i64, ptr %slot22, align 8
  %v229 = load i64, ptr %slot10, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 %v228, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot4, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld233, ptr %slot23, align 8
  %v234 = load i64, ptr %slot23, align 8
  %v235 = load i64, ptr %slot10, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i64 %v234, ptr %p236, align 8, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot4, align 8
  %p238 = inttoptr i64 %v237 to ptr
  %ld239 = load i64, ptr %p238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld239, ptr %slot24, align 8
  %v240 = load i64, ptr %slot24, align 8
  %v241 = load i64, ptr %slot10, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i64 %v240, ptr %p242, align 8, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot5, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot25, align 8
  %v246 = load i64, ptr %slot25, align 8
  %v247 = load i64, ptr %slot11, align 8
  %p248 = inttoptr i64 %v247 to ptr
  store i64 %v246, ptr %p248, align 8, !alias.scope !3, !noalias !4
  %v249 = load i64, ptr %slot4, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %ld251 = load i64, ptr %p250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld251, ptr %slot26, align 8
  %v252 = load i64, ptr %slot26, align 8
  %v253 = load i64, ptr %slot10, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i64 %v252, ptr %p254, align 8, !alias.scope !3, !noalias !4
  %v255 = load i64, ptr %slot5, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %ld257 = load i64, ptr %p256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld257, ptr %slot27, align 8
  %v258 = load i64, ptr %slot4, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot28, align 8
  %v261 = load i64, ptr %slot28, align 8
  %op262 = add i64 %v261, 24
  store i64 %op262, ptr %slot29, align 8
  %v263 = load i64, ptr %slot27, align 8
  %v264 = load i64, ptr %slot29, align 8
  %p265 = inttoptr i64 %v264 to ptr
  store i64 %v263, ptr %p265, align 8, !alias.scope !4, !noalias !3
  %v266 = load i64, ptr %slot10, align 8
  %p267 = inttoptr i64 %v266 to ptr
  store i64 0, ptr %p267, align 8, !alias.scope !3, !noalias !4
  %v268 = load i64, ptr %slot4, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %ld270 = load i64, ptr %p269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld270, ptr %slot30, align 8
  %v271 = load i64, ptr %slot30, align 8
  %v272 = load i64, ptr %slot10, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i64 %v271, ptr %p273, align 8, !alias.scope !3, !noalias !4
  %v274 = load i64, ptr %slot10, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot31, align 8
  %v277 = load i64, ptr %slot31, align 8
  %op278 = add i64 %v277, 8
  store i64 %op278, ptr %slot32, align 8
  %v279 = load i64, ptr %slot32, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i64, ptr %p280, align 8, !alias.scope !4, !noalias !3
  store i64 %ld281, ptr %slot33, align 8
  %v282 = load i64, ptr %slot33, align 8
  %v283 = load i64, ptr %slot10, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 %v282, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot10, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i64, ptr %p286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld287, ptr %slot34, align 8
  %v288 = load i64, ptr %slot34, align 8
  %v289 = load i64, ptr %slot6, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i64 %v288, ptr %p290, align 8, !alias.scope !3, !noalias !4
  %v291 = load i64, ptr %slot4, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %ld293 = load i64, ptr %p292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld293, ptr %slot35, align 8
  %v294 = load i64, ptr %slot35, align 8
  %v295 = load i64, ptr %slot10, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i64 %v294, ptr %p296, align 8, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot10, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot36, align 8
  %v300 = load i64, ptr %slot36, align 8
  %op301 = add i64 %v300, 24
  store i64 %op301, ptr %slot37, align 8
  %v302 = load i64, ptr %slot37, align 8
  %p303 = inttoptr i64 %v302 to ptr
  %ld304 = load i64, ptr %p303, align 8, !alias.scope !4, !noalias !3
  store i64 %ld304, ptr %slot38, align 8
  %v305 = load i64, ptr %slot38, align 8
  %v306 = load i64, ptr %slot10, align 8
  %p307 = inttoptr i64 %v306 to ptr
  store i64 %v305, ptr %p307, align 8, !alias.scope !3, !noalias !4
  %v308 = load i64, ptr %slot11, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 2, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot11, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %ld312 = load i64, ptr %p311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld312, ptr %slot39, align 8
  %v313 = load i64, ptr %slot10, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld315, ptr %slot40, align 8
  %v316 = load i64, ptr %slot40, align 8
  %v317 = load i64, ptr %slot39, align 8
  %op318 = sub i64 %v316, %v317
  store i64 %op318, ptr %slot41, align 8
  %v319 = load i64, ptr %slot40, align 8
  %cmp320 = icmp slt i64 %v319, 9223372036854775810
  %cv321 = zext i1 %cmp320 to i64
  store i64 %cv321, ptr %slot42, align 8
  %v322 = load i64, ptr %slot42, align 8
  %cond323 = icmp ne i64 %v322, 0
  br i1 %cond323, label %bb_overflow59, label %bb_checked59
bb_overflow59:
  %v324 = load i64, ptr %slot1, align 8
  %p325 = inttoptr i64 %v324 to ptr
  %v326 = load i64, ptr %slot40, align 8
  %v327 = load i64, ptr %slot39, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p325, i64 1, i64 %v326, i64 %v327, i64 64) nomerge, !dbg !112
  unreachable
bb_checked59:
  %v328 = load i64, ptr %slot41, align 8
  %v329 = load i64, ptr %slot10, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i64 %v328, ptr %p330, align 8, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot10, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %ld333 = load i64, ptr %p332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld333, ptr %slot43, align 8
  %v334 = load i64, ptr %slot43, align 8
  %v335 = load i64, ptr %slot7, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 %v334, ptr %p336, align 8, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot7, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot44, align 8
  %v340 = load i64, ptr %slot44, align 8
  %v341 = load i64, ptr %slot10, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i64 %v340, ptr %p342, align 8, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot11, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i64 0, ptr %p344, align 8, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot11, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld347, ptr %slot45, align 8
  %v348 = load i64, ptr %slot10, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i64, ptr %p349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld350, ptr %slot46, align 8
  %v351 = load i64, ptr %slot46, align 8
  %v352 = load i64, ptr %slot45, align 8
  %cmp353 = icmp slt i64 %v351, %v352
  %cv354 = zext i1 %cmp353 to i64
  store i64 %cv354, ptr %slot47, align 8
  %v355 = load i64, ptr %slot47, align 8
  %v356 = load i64, ptr %slot10, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i64 %v355, ptr %p357, align 8, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot10, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld360, ptr %slot48, align 8
  %v361 = load i64, ptr %slot48, align 8
  %cond362 = icmp ne i64 %v361, 0
  br i1 %cond362, label %bb_next67, label %bb_i32
bb_next67:
  %v363 = load i64, ptr %slot6, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i64, ptr %p364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld365, ptr %slot49, align 8
  %v366 = load i64, ptr %slot49, align 8
  %op367 = add i64 %v366, 0
  store i64 %op367, ptr %slot50, align 8
  %v368 = load i64, ptr %slot50, align 8
  %p369 = inttoptr i64 %v368 to ptr
  %ld370 = load i64, ptr %p369, align 8, !alias.scope !6, !noalias !7
  store i64 %ld370, ptr %slot51, align 8
  %v371 = load i64, ptr %slot51, align 8
  %v372 = load i64, ptr %slot10, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i64 %v371, ptr %p373, align 8, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot10, align 8
  %p375 = inttoptr i64 %v374 to ptr
  %ld376 = load i64, ptr %p375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld376, ptr %slot52, align 8
  %v377 = load i64, ptr %slot52, align 8
  %cmp378 = icmp ugt i64 %v377, 9223372036854775807
  %cv379 = zext i1 %cmp378 to i64
  store i64 %cv379, ptr %slot53, align 8
  %v380 = load i64, ptr %slot53, align 8
  %cond381 = icmp ne i64 %v380, 0
  br i1 %cond381, label %bb_cast_overflow72, label %bb_cast_ok72
bb_cast_overflow72:
  %v382 = load i64, ptr %slot1, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %v384 = load i64, ptr %slot52, align 8
  call void @myl_qbe_fail_cast(ptr %p383, i64 %v384, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok72:
  %v385 = load i64, ptr %slot52, align 8
  %v386 = load i64, ptr %slot10, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i64 %v385, ptr %p387, align 8, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot7, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i64, ptr %p389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld390, ptr %slot54, align 8
  %v391 = load i64, ptr %slot54, align 8
  %v392 = load i64, ptr %slot11, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i64 %v391, ptr %p393, align 8, !alias.scope !3, !noalias !4
  %v394 = load i64, ptr %slot11, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld396, ptr %slot55, align 8
  %v397 = load i64, ptr %slot10, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot56, align 8
  %v400 = load i64, ptr %slot56, align 8
  %v401 = load i64, ptr %slot55, align 8
  %ovpair403 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v400, i64 %v401)
  %op402 = extractvalue { i64, i1 } %ovpair403, 0
  %ov404 = extractvalue { i64, i1 } %ovpair403, 1
  store i64 %op402, ptr %slot57, align 8
  %v405 = load i64, ptr %slot56, align 8
  %v406 = load i64, ptr %slot57, align 8
  %op407 = xor i64 %v405, %v406
  store i64 %op407, ptr %slot58, align 8
  %v408 = load i64, ptr %slot55, align 8
  %v409 = load i64, ptr %slot57, align 8
  %op410 = xor i64 %v408, %v409
  store i64 %op410, ptr %slot59, align 8
  %v411 = load i64, ptr %slot58, align 8
  %v412 = load i64, ptr %slot59, align 8
  %op413 = and i64 %v411, %v412
  store i64 %op413, ptr %slot60, align 8
  %cv414 = zext i1 %ov404 to i64
  store i64 %cv414, ptr %slot61, align 8
  %v415 = load i64, ptr %slot61, align 8
  %cond416 = icmp ne i64 %v415, 0
  br i1 %cond416, label %bb_overflow76, label %bb_checked76
bb_overflow76:
  %v417 = load i64, ptr %slot1, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %v419 = load i64, ptr %slot56, align 8
  %v420 = load i64, ptr %slot55, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p418, i64 0, i64 %v419, i64 %v420, i64 64) nomerge, !dbg !116
  unreachable
bb_checked76:
  %v421 = load i64, ptr %slot57, align 8
  %v422 = load i64, ptr %slot10, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i64 %v421, ptr %p423, align 8, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot10, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %ld426 = load i64, ptr %p425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld426, ptr %slot62, align 8
  %v427 = load i64, ptr %slot62, align 8
  %v428 = load i64, ptr %slot7, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 %v427, ptr %p429, align 8, !alias.scope !3, !noalias !4
  br label %bb_i32
bb_i32:
  %v430 = load i64, ptr %slot7, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot63, align 8
  %v433 = load i64, ptr %slot63, align 8
  %v434 = load i64, ptr %slot10, align 8
  %p435 = inttoptr i64 %v434 to ptr
  store i64 %v433, ptr %p435, align 8, !alias.scope !3, !noalias !4
  %v436 = load i64, ptr %slot6, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %ld438 = load i64, ptr %p437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld438, ptr %slot64, align 8
  %v439 = load i64, ptr %slot10, align 8
  %p440 = inttoptr i64 %v439 to ptr
  %ld441 = load i64, ptr %p440, align 8, !alias.scope !3, !noalias !4
  store i64 %ld441, ptr %slot65, align 8
  %v442 = load i64, ptr %slot64, align 8
  %p443 = inttoptr i64 %v442 to ptr
  %ld444 = load i64, ptr %p443, align 8, !alias.scope !6, !noalias !7
  store i64 %ld444, ptr %slot66, align 8
  %v445 = load i64, ptr %slot65, align 8
  %v446 = load i64, ptr %slot66, align 8
  %cmp447 = icmp ult i64 %v445, %v446
  %cv448 = zext i1 %cmp447 to i64
  store i64 %cv448, ptr %slot67, align 8
  %v449 = load i64, ptr %slot67, align 8
  %cond450 = icmp ne i64 %v449, 0
  br i1 %cond450, label %bb_success88, label %bb_failed88
bb_failed88:
  %v451 = load i64, ptr %slot1, align 8
  %p452 = inttoptr i64 %v451 to ptr
  %v453 = load i64, ptr %slot65, align 8
  %v454 = load i64, ptr %slot66, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p452, i64 %v453, i64 %v454) nomerge, !dbg !118
  unreachable
bb_success88:
  %v455 = load i64, ptr %slot64, align 8
  %op456 = add i64 %v455, 32
  store i64 %op456, ptr %slot68, align 8
  %v457 = load i64, ptr %slot68, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %ld459 = load i64, ptr %p458, align 8, !alias.scope !6, !noalias !7
  store i64 %ld459, ptr %slot69, align 8
  %v460 = load i64, ptr %slot65, align 8
  %op461 = mul i64 %v460, 8
  store i64 %op461, ptr %slot70, align 8
  %v462 = load i64, ptr %slot69, align 8
  %v463 = load i64, ptr %slot70, align 8
  %op464 = add i64 %v462, %v463
  store i64 %op464, ptr %slot71, align 8
  %v465 = load i64, ptr %slot69, align 8
  %p466 = inttoptr i64 %v465 to ptr
  %v467 = load i64, ptr %slot70, align 8
  %egep468 = getelementptr i8, ptr %p466, i64 %v467
  %ld469 = load i64, ptr %egep468, align 8, !alias.scope !12, !noalias !13
  store i64 %ld469, ptr %slot72, align 8
  %v470 = load i64, ptr %slot72, align 8
  %v471 = load i64, ptr %slot10, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i64 %v470, ptr %p472, align 8, !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot11, align 8
  %p474 = inttoptr i64 %v473 to ptr
  store i64 256, ptr %p474, align 8, !alias.scope !3, !noalias !4
  %v475 = load i64, ptr %slot11, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %ld477 = load i64, ptr %p476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld477, ptr %slot73, align 8
  %v478 = load i64, ptr %slot10, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %ld480 = load i64, ptr %p479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld480, ptr %slot74, align 8
  %v481 = load i64, ptr %slot74, align 8
  %v482 = load i64, ptr %slot73, align 8
  %ovpair484 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v481, i64 %v482)
  %op483 = extractvalue { i64, i1 } %ovpair484, 0
  %ov485 = extractvalue { i64, i1 } %ovpair484, 1
  store i64 %op483, ptr %slot75, align 8
  %v486 = load i64, ptr %slot74, align 8
  %op487 = and i64 %v486, 4294967295
  store i64 %op487, ptr %slot76, align 8
  %v488 = load i64, ptr %slot74, align 8
  %op489 = lshr i64 %v488, 32
  store i64 %op489, ptr %slot77, align 8
  %v490 = load i64, ptr %slot73, align 8
  %op491 = and i64 %v490, 4294967295
  store i64 %op491, ptr %slot78, align 8
  %v492 = load i64, ptr %slot73, align 8
  %op493 = lshr i64 %v492, 32
  store i64 %op493, ptr %slot79, align 8
  %v494 = load i64, ptr %slot76, align 8
  %v495 = load i64, ptr %slot78, align 8
  %op496 = mul i64 %v494, %v495
  store i64 %op496, ptr %slot80, align 8
  %v497 = load i64, ptr %slot80, align 8
  %op498 = lshr i64 %v497, 32
  store i64 %op498, ptr %slot81, align 8
  %v499 = load i64, ptr %slot77, align 8
  %v500 = load i64, ptr %slot78, align 8
  %op501 = mul i64 %v499, %v500
  store i64 %op501, ptr %slot82, align 8
  %v502 = load i64, ptr %slot82, align 8
  %v503 = load i64, ptr %slot81, align 8
  %op504 = add i64 %v502, %v503
  store i64 %op504, ptr %slot83, align 8
  %v505 = load i64, ptr %slot83, align 8
  %op506 = and i64 %v505, 4294967295
  store i64 %op506, ptr %slot84, align 8
  %v507 = load i64, ptr %slot83, align 8
  %op508 = lshr i64 %v507, 32
  store i64 %op508, ptr %slot85, align 8
  %v509 = load i64, ptr %slot76, align 8
  %v510 = load i64, ptr %slot79, align 8
  %op511 = mul i64 %v509, %v510
  store i64 %op511, ptr %slot86, align 8
  %v512 = load i64, ptr %slot86, align 8
  %v513 = load i64, ptr %slot84, align 8
  %op514 = add i64 %v512, %v513
  store i64 %op514, ptr %slot87, align 8
  %v515 = load i64, ptr %slot87, align 8
  %op516 = lshr i64 %v515, 32
  store i64 %op516, ptr %slot88, align 8
  %v517 = load i64, ptr %slot77, align 8
  %v518 = load i64, ptr %slot79, align 8
  %op519 = mul i64 %v517, %v518
  store i64 %op519, ptr %slot89, align 8
  %v520 = load i64, ptr %slot89, align 8
  %v521 = load i64, ptr %slot85, align 8
  %op522 = add i64 %v520, %v521
  store i64 %op522, ptr %slot90, align 8
  %v523 = load i64, ptr %slot90, align 8
  %v524 = load i64, ptr %slot88, align 8
  %op525 = add i64 %v523, %v524
  store i64 %op525, ptr %slot91, align 8
  %v526 = load i64, ptr %slot74, align 8
  %cmp527 = icmp slt i64 %v526, 0
  %cv528 = zext i1 %cmp527 to i64
  store i64 %cv528, ptr %slot92, align 8
  %v529 = load i64, ptr %slot73, align 8
  %cmp530 = icmp slt i64 %v529, 0
  %cv531 = zext i1 %cmp530 to i64
  store i64 %cv531, ptr %slot93, align 8
  %v532 = load i64, ptr %slot92, align 8
  %neg533 = sub i64 0, %v532
  store i64 %neg533, ptr %slot94, align 8
  %v534 = load i64, ptr %slot93, align 8
  %neg535 = sub i64 0, %v534
  store i64 %neg535, ptr %slot95, align 8
  %v536 = load i64, ptr %slot73, align 8
  %v537 = load i64, ptr %slot94, align 8
  %op538 = and i64 %v536, %v537
  store i64 %op538, ptr %slot96, align 8
  %v539 = load i64, ptr %slot74, align 8
  %v540 = load i64, ptr %slot95, align 8
  %op541 = and i64 %v539, %v540
  store i64 %op541, ptr %slot97, align 8
  %v542 = load i64, ptr %slot91, align 8
  %v543 = load i64, ptr %slot96, align 8
  %op544 = sub i64 %v542, %v543
  store i64 %op544, ptr %slot98, align 8
  %v545 = load i64, ptr %slot98, align 8
  %v546 = load i64, ptr %slot97, align 8
  %op547 = sub i64 %v545, %v546
  store i64 %op547, ptr %slot98, align 8
  %v548 = load i64, ptr %slot75, align 8
  %op549 = ashr i64 %v548, 63
  store i64 %op549, ptr %slot99, align 8
  %cv550 = zext i1 %ov485 to i64
  store i64 %cv550, ptr %slot100, align 8
  %v551 = load i64, ptr %slot100, align 8
  %cond552 = icmp ne i64 %v551, 0
  br i1 %cond552, label %bb_overflow96, label %bb_checked96
bb_overflow96:
  %v553 = load i64, ptr %slot1, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %v555 = load i64, ptr %slot74, align 8
  %v556 = load i64, ptr %slot73, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p554, i64 2, i64 %v555, i64 %v556, i64 64) nomerge, !dbg !120
  unreachable
bb_checked96:
  %v557 = load i64, ptr %slot75, align 8
  %v558 = load i64, ptr %slot10, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i64 %v557, ptr %p559, align 8, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot4, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot101, align 8
  %v563 = load i64, ptr %slot101, align 8
  %v564 = load i64, ptr %slot11, align 8
  %p565 = inttoptr i64 %v564 to ptr
  store i64 %v563, ptr %p565, align 8, !alias.scope !3, !noalias !4
  %v566 = load i64, ptr %slot11, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i64, ptr %p567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld568, ptr %slot102, align 8
  %v569 = load i64, ptr %slot102, align 8
  %op570 = add i64 %v569, 8
  store i64 %op570, ptr %slot103, align 8
  %v571 = load i64, ptr %slot103, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !4, !noalias !3
  store i64 %ld573, ptr %slot104, align 8
  %v574 = load i64, ptr %slot104, align 8
  %v575 = load i64, ptr %slot11, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot11, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld579, ptr %slot105, align 8
  %v580 = load i64, ptr %slot105, align 8
  %v581 = load i64, ptr %slot8, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 %v580, ptr %p582, align 8, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot4, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot106, align 8
  %v586 = load i64, ptr %slot106, align 8
  %v587 = load i64, ptr %slot11, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i64 %v586, ptr %p588, align 8, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot11, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i64, ptr %p590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld591, ptr %slot107, align 8
  %v592 = load i64, ptr %slot107, align 8
  %op593 = add i64 %v592, 24
  store i64 %op593, ptr %slot108, align 8
  %v594 = load i64, ptr %slot108, align 8
  %p595 = inttoptr i64 %v594 to ptr
  %ld596 = load i64, ptr %p595, align 8, !alias.scope !4, !noalias !3
  store i64 %ld596, ptr %slot109, align 8
  %v597 = load i64, ptr %slot109, align 8
  %v598 = load i64, ptr %slot11, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i64 %v597, ptr %p599, align 8, !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot12, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i64 1, ptr %p601, align 8, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot12, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %ld604 = load i64, ptr %p603, align 8, !alias.scope !3, !noalias !4
  store i64 %ld604, ptr %slot110, align 8
  %v605 = load i64, ptr %slot11, align 8
  %p606 = inttoptr i64 %v605 to ptr
  %ld607 = load i64, ptr %p606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld607, ptr %slot111, align 8
  %v608 = load i64, ptr %slot111, align 8
  %v609 = load i64, ptr %slot110, align 8
  %ovpair611 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v608, i64 %v609)
  %op610 = extractvalue { i64, i1 } %ovpair611, 0
  %ov612 = extractvalue { i64, i1 } %ovpair611, 1
  store i64 %op610, ptr %slot112, align 8
  %cv613 = zext i1 %ov612 to i64
  store i64 %cv613, ptr %slot113, align 8
  %v614 = load i64, ptr %slot113, align 8
  %cond615 = icmp ne i64 %v614, 0
  br i1 %cond615, label %bb_overflow151, label %bb_checked151
bb_overflow151:
  %v616 = load i64, ptr %slot1, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %v618 = load i64, ptr %slot111, align 8
  %v619 = load i64, ptr %slot110, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p617, i64 1, i64 %v618, i64 %v619, i64 64) nomerge, !dbg !122
  unreachable
bb_checked151:
  %v620 = load i64, ptr %slot112, align 8
  %v621 = load i64, ptr %slot11, align 8
  %p622 = inttoptr i64 %v621 to ptr
  store i64 %v620, ptr %p622, align 8, !alias.scope !3, !noalias !4
  %v623 = load i64, ptr %slot11, align 8
  %p624 = inttoptr i64 %v623 to ptr
  %ld625 = load i64, ptr %p624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld625, ptr %slot114, align 8
  %v626 = load i64, ptr %slot114, align 8
  %v627 = load i64, ptr %slot9, align 8
  %p628 = inttoptr i64 %v627 to ptr
  store i64 %v626, ptr %p628, align 8, !alias.scope !3, !noalias !4
  %v629 = load i64, ptr %slot9, align 8
  %p630 = inttoptr i64 %v629 to ptr
  %ld631 = load i64, ptr %p630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld631, ptr %slot115, align 8
  %v632 = load i64, ptr %slot115, align 8
  %v633 = load i64, ptr %slot11, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i64 %v632, ptr %p634, align 8, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot12, align 8
  %p636 = inttoptr i64 %v635 to ptr
  store i64 0, ptr %p636, align 8, !alias.scope !3, !noalias !4
  %v637 = load i64, ptr %slot12, align 8
  %p638 = inttoptr i64 %v637 to ptr
  %ld639 = load i64, ptr %p638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld639, ptr %slot116, align 8
  %v640 = load i64, ptr %slot11, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i64, ptr %p641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld642, ptr %slot117, align 8
  %v643 = load i64, ptr %slot117, align 8
  %v644 = load i64, ptr %slot116, align 8
  %cmp645 = icmp slt i64 %v643, %v644
  %cv646 = zext i1 %cmp645 to i64
  store i64 %cv646, ptr %slot118, align 8
  %v647 = load i64, ptr %slot118, align 8
  %v648 = load i64, ptr %slot11, align 8
  %p649 = inttoptr i64 %v648 to ptr
  store i64 %v647, ptr %p649, align 8, !alias.scope !3, !noalias !4
  %v650 = load i64, ptr %slot11, align 8
  %p651 = inttoptr i64 %v650 to ptr
  %ld652 = load i64, ptr %p651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld652, ptr %slot119, align 8
  %v653 = load i64, ptr %slot119, align 8
  %cond654 = icmp ne i64 %v653, 0
  br i1 %cond654, label %bb_next159, label %bb_i53
bb_next159:
  %v655 = load i64, ptr %slot8, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i64, ptr %p656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld657, ptr %slot120, align 8
  %v658 = load i64, ptr %slot120, align 8
  %op659 = add i64 %v658, 0
  store i64 %op659, ptr %slot121, align 8
  %v660 = load i64, ptr %slot121, align 8
  %p661 = inttoptr i64 %v660 to ptr
  %ld662 = load i64, ptr %p661, align 8, !alias.scope !6, !noalias !7
  store i64 %ld662, ptr %slot122, align 8
  %v663 = load i64, ptr %slot122, align 8
  %v664 = load i64, ptr %slot11, align 8
  %p665 = inttoptr i64 %v664 to ptr
  store i64 %v663, ptr %p665, align 8, !alias.scope !3, !noalias !4
  %v666 = load i64, ptr %slot11, align 8
  %p667 = inttoptr i64 %v666 to ptr
  %ld668 = load i64, ptr %p667, align 8, !alias.scope !3, !noalias !4
  store i64 %ld668, ptr %slot123, align 8
  %v669 = load i64, ptr %slot123, align 8
  %cmp670 = icmp ugt i64 %v669, 9223372036854775807
  %cv671 = zext i1 %cmp670 to i64
  store i64 %cv671, ptr %slot124, align 8
  %v672 = load i64, ptr %slot124, align 8
  %cond673 = icmp ne i64 %v672, 0
  br i1 %cond673, label %bb_cast_overflow164, label %bb_cast_ok164
bb_cast_overflow164:
  %v674 = load i64, ptr %slot1, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %v676 = load i64, ptr %slot123, align 8
  call void @myl_qbe_fail_cast(ptr %p675, i64 %v676, i64 320) nomerge, !dbg !124
  unreachable
bb_cast_ok164:
  %v677 = load i64, ptr %slot123, align 8
  %v678 = load i64, ptr %slot11, align 8
  %p679 = inttoptr i64 %v678 to ptr
  store i64 %v677, ptr %p679, align 8, !alias.scope !3, !noalias !4
  %v680 = load i64, ptr %slot9, align 8
  %p681 = inttoptr i64 %v680 to ptr
  %ld682 = load i64, ptr %p681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld682, ptr %slot125, align 8
  %v683 = load i64, ptr %slot125, align 8
  %v684 = load i64, ptr %slot12, align 8
  %p685 = inttoptr i64 %v684 to ptr
  store i64 %v683, ptr %p685, align 8, !alias.scope !3, !noalias !4
  %v686 = load i64, ptr %slot12, align 8
  %p687 = inttoptr i64 %v686 to ptr
  %ld688 = load i64, ptr %p687, align 8, !alias.scope !3, !noalias !4
  store i64 %ld688, ptr %slot126, align 8
  %v689 = load i64, ptr %slot11, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i64, ptr %p690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld691, ptr %slot127, align 8
  %v692 = load i64, ptr %slot127, align 8
  %v693 = load i64, ptr %slot126, align 8
  %ovpair695 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v692, i64 %v693)
  %op694 = extractvalue { i64, i1 } %ovpair695, 0
  %ov696 = extractvalue { i64, i1 } %ovpair695, 1
  store i64 %op694, ptr %slot128, align 8
  %v697 = load i64, ptr %slot127, align 8
  %v698 = load i64, ptr %slot128, align 8
  %op699 = xor i64 %v697, %v698
  store i64 %op699, ptr %slot129, align 8
  %v700 = load i64, ptr %slot126, align 8
  %v701 = load i64, ptr %slot128, align 8
  %op702 = xor i64 %v700, %v701
  store i64 %op702, ptr %slot130, align 8
  %v703 = load i64, ptr %slot129, align 8
  %v704 = load i64, ptr %slot130, align 8
  %op705 = and i64 %v703, %v704
  store i64 %op705, ptr %slot131, align 8
  %cv706 = zext i1 %ov696 to i64
  store i64 %cv706, ptr %slot132, align 8
  %v707 = load i64, ptr %slot132, align 8
  %cond708 = icmp ne i64 %v707, 0
  br i1 %cond708, label %bb_overflow168, label %bb_checked168
bb_overflow168:
  %v709 = load i64, ptr %slot1, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %v711 = load i64, ptr %slot127, align 8
  %v712 = load i64, ptr %slot126, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p710, i64 0, i64 %v711, i64 %v712, i64 64) nomerge, !dbg !126
  unreachable
bb_checked168:
  %v713 = load i64, ptr %slot128, align 8
  %v714 = load i64, ptr %slot11, align 8
  %p715 = inttoptr i64 %v714 to ptr
  store i64 %v713, ptr %p715, align 8, !alias.scope !3, !noalias !4
  %v716 = load i64, ptr %slot11, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %ld718 = load i64, ptr %p717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld718, ptr %slot133, align 8
  %v719 = load i64, ptr %slot133, align 8
  %v720 = load i64, ptr %slot9, align 8
  %p721 = inttoptr i64 %v720 to ptr
  store i64 %v719, ptr %p721, align 8, !alias.scope !3, !noalias !4
  br label %bb_i53
bb_i53:
  %v722 = load i64, ptr %slot9, align 8
  %p723 = inttoptr i64 %v722 to ptr
  %ld724 = load i64, ptr %p723, align 8, !alias.scope !3, !noalias !4
  store i64 %ld724, ptr %slot134, align 8
  %v725 = load i64, ptr %slot134, align 8
  %v726 = load i64, ptr %slot11, align 8
  %p727 = inttoptr i64 %v726 to ptr
  store i64 %v725, ptr %p727, align 8, !alias.scope !3, !noalias !4
  %v728 = load i64, ptr %slot8, align 8
  %p729 = inttoptr i64 %v728 to ptr
  %ld730 = load i64, ptr %p729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld730, ptr %slot135, align 8
  %v731 = load i64, ptr %slot11, align 8
  %p732 = inttoptr i64 %v731 to ptr
  %ld733 = load i64, ptr %p732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld733, ptr %slot136, align 8
  %v734 = load i64, ptr %slot135, align 8
  %p735 = inttoptr i64 %v734 to ptr
  %ld736 = load i64, ptr %p735, align 8, !alias.scope !6, !noalias !7
  store i64 %ld736, ptr %slot137, align 8
  %v737 = load i64, ptr %slot136, align 8
  %v738 = load i64, ptr %slot137, align 8
  %cmp739 = icmp ult i64 %v737, %v738
  %cv740 = zext i1 %cmp739 to i64
  store i64 %cv740, ptr %slot138, align 8
  %v741 = load i64, ptr %slot138, align 8
  %cond742 = icmp ne i64 %v741, 0
  br i1 %cond742, label %bb_success180, label %bb_failed180
bb_failed180:
  %v743 = load i64, ptr %slot1, align 8
  %p744 = inttoptr i64 %v743 to ptr
  %v745 = load i64, ptr %slot136, align 8
  %v746 = load i64, ptr %slot137, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p744, i64 %v745, i64 %v746) nomerge, !dbg !128
  unreachable
bb_success180:
  %v747 = load i64, ptr %slot135, align 8
  %op748 = add i64 %v747, 32
  store i64 %op748, ptr %slot139, align 8
  %v749 = load i64, ptr %slot139, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %ld751 = load i64, ptr %p750, align 8, !alias.scope !6, !noalias !7
  store i64 %ld751, ptr %slot140, align 8
  %v752 = load i64, ptr %slot136, align 8
  %op753 = mul i64 %v752, 8
  store i64 %op753, ptr %slot141, align 8
  %v754 = load i64, ptr %slot140, align 8
  %v755 = load i64, ptr %slot141, align 8
  %op756 = add i64 %v754, %v755
  store i64 %op756, ptr %slot142, align 8
  %v757 = load i64, ptr %slot140, align 8
  %p758 = inttoptr i64 %v757 to ptr
  %v759 = load i64, ptr %slot141, align 8
  %egep760 = getelementptr i8, ptr %p758, i64 %v759
  %ld761 = load i64, ptr %egep760, align 8, !alias.scope !12, !noalias !13
  store i64 %ld761, ptr %slot143, align 8
  %v762 = load i64, ptr %slot143, align 8
  %v763 = load i64, ptr %slot11, align 8
  %p764 = inttoptr i64 %v763 to ptr
  store i64 %v762, ptr %p764, align 8, !alias.scope !3, !noalias !4
  %v765 = load i64, ptr %slot11, align 8
  %p766 = inttoptr i64 %v765 to ptr
  %ld767 = load i64, ptr %p766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld767, ptr %slot144, align 8
  %v768 = load i64, ptr %slot10, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %ld770 = load i64, ptr %p769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld770, ptr %slot145, align 8
  %v771 = load i64, ptr %slot145, align 8
  %v772 = load i64, ptr %slot144, align 8
  %ovpair774 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v771, i64 %v772)
  %op773 = extractvalue { i64, i1 } %ovpair774, 0
  %ov775 = extractvalue { i64, i1 } %ovpair774, 1
  store i64 %op773, ptr %slot146, align 8
  %v776 = load i64, ptr %slot145, align 8
  %v777 = load i64, ptr %slot146, align 8
  %op778 = xor i64 %v776, %v777
  store i64 %op778, ptr %slot147, align 8
  %v779 = load i64, ptr %slot144, align 8
  %v780 = load i64, ptr %slot146, align 8
  %op781 = xor i64 %v779, %v780
  store i64 %op781, ptr %slot148, align 8
  %v782 = load i64, ptr %slot147, align 8
  %v783 = load i64, ptr %slot148, align 8
  %op784 = and i64 %v782, %v783
  store i64 %op784, ptr %slot149, align 8
  %cv785 = zext i1 %ov775 to i64
  store i64 %cv785, ptr %slot150, align 8
  %v786 = load i64, ptr %slot150, align 8
  %cond787 = icmp ne i64 %v786, 0
  br i1 %cond787, label %bb_overflow188, label %bb_checked188
bb_overflow188:
  %v788 = load i64, ptr %slot1, align 8
  %p789 = inttoptr i64 %v788 to ptr
  %v790 = load i64, ptr %slot145, align 8
  %v791 = load i64, ptr %slot144, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p789, i64 0, i64 %v790, i64 %v791, i64 64) nomerge, !dbg !130
  unreachable
bb_checked188:
  %v792 = load i64, ptr %slot146, align 8
  %v793 = load i64, ptr %slot10, align 8
  %p794 = inttoptr i64 %v793 to ptr
  store i64 %v792, ptr %p794, align 8, !alias.scope !3, !noalias !4
  %v795 = load i64, ptr %slot10, align 8
  %p796 = inttoptr i64 %v795 to ptr
  %ld797 = load i64, ptr %p796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld797, ptr %slot151, align 8
  %v798 = load i64, ptr %slot151, align 8
  ret i64 %v798
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390", linkageName: "myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 250080796135026597, i64 0, !"myl_f_22849c51a4fd631aa66144da38552fb710206c5e57b8268459a8dc3a6dbcd390"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!110 = !DILocation(line: 4, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!112 = !DILocation(line: 22, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!114 = !DILocation(line: 29, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!116 = !DILocation(line: 31, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!118 = !DILocation(line: 34, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!120 = !DILocation(line: 36, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!122 = !DILocation(line: 43, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!124 = !DILocation(line: 50, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!126 = !DILocation(line: 52, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!128 = !DILocation(line: 55, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!130 = !DILocation(line: 56, column: 0, scope: !131)
