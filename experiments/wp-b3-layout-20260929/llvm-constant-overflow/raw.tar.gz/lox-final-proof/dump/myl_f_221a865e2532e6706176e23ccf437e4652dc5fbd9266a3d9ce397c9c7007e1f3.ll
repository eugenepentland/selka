target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_221a865e2532e6706176e23ccf437e4652dc5fbd9266a3d9ce397c9c7007e1f3(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3, i64 %p_a4) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i32, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i32, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i32, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i32, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i32, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i32, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  store i64 %p_a4, ptr %slot6, align 8
  %v1061 = load i64, ptr %slot1, align 8
  %op1062 = add i64 %v1061, 32
  store i64 %op1062, ptr %slot7, align 8
  %mem1063 = alloca i8, i64 8, align 8
  %ptr1064 = ptrtoint ptr %mem1063 to i64
  store i64 %ptr1064, ptr %slot8, align 8
  %mem1065 = alloca i8, i64 8, align 8
  %ptr1066 = ptrtoint ptr %mem1065 to i64
  store i64 %ptr1066, ptr %slot9, align 8
  %mem1067 = alloca i8, i64 8, align 8
  %ptr1068 = ptrtoint ptr %mem1067 to i64
  store i64 %ptr1068, ptr %slot10, align 8
  %mem1069 = alloca i8, i64 8, align 8
  %ptr1070 = ptrtoint ptr %mem1069 to i64
  store i64 %ptr1070, ptr %slot11, align 8
  %mem1071 = alloca i8, i64 8, align 8
  %ptr1072 = ptrtoint ptr %mem1071 to i64
  store i64 %ptr1072, ptr %slot12, align 8
  %mem1073 = alloca i8, i64 8, align 8
  %ptr1074 = ptrtoint ptr %mem1073 to i64
  store i64 %ptr1074, ptr %slot13, align 8
  %mem1075 = alloca i8, i64 8, align 8
  %ptr1076 = ptrtoint ptr %mem1075 to i64
  store i64 %ptr1076, ptr %slot14, align 8
  %mem1077 = alloca i8, i64 8, align 8
  %ptr1078 = ptrtoint ptr %mem1077 to i64
  store i64 %ptr1078, ptr %slot15, align 8
  %mem1079 = alloca i8, i64 8, align 8
  %ptr1080 = ptrtoint ptr %mem1079 to i64
  store i64 %ptr1080, ptr %slot16, align 8
  %mem1081 = alloca i8, i64 8, align 8
  %ptr1082 = ptrtoint ptr %mem1081 to i64
  store i64 %ptr1082, ptr %slot17, align 8
  %mem1083 = alloca i8, i64 8, align 8
  %ptr1084 = ptrtoint ptr %mem1083 to i64
  store i64 %ptr1084, ptr %slot18, align 8
  %mem1085 = alloca i8, i64 8, align 8
  %ptr1086 = ptrtoint ptr %mem1085 to i64
  store i64 %ptr1086, ptr %slot19, align 8
  %mem1087 = alloca i8, i64 8, align 8
  %ptr1088 = ptrtoint ptr %mem1087 to i64
  store i64 %ptr1088, ptr %slot20, align 8
  %mem1089 = alloca i8, i64 8, align 8
  %ptr1090 = ptrtoint ptr %mem1089 to i64
  store i64 %ptr1090, ptr %slot21, align 8
  %mem1091 = alloca i8, i64 104, align 8
  %ptr1092 = ptrtoint ptr %mem1091 to i64
  store i64 %ptr1092, ptr %slot22, align 8
  %mem1093 = alloca i8, i64 40, align 8
  %ptr1094 = ptrtoint ptr %mem1093 to i64
  store i64 %ptr1094, ptr %slot23, align 8
  %mem1095 = alloca i8, i64 8, align 8
  %ptr1096 = ptrtoint ptr %mem1095 to i64
  store i64 %ptr1096, ptr %slot24, align 8
  %mem1097 = alloca i8, i64 8, align 8
  %ptr1098 = ptrtoint ptr %mem1097 to i64
  store i64 %ptr1098, ptr %slot25, align 8
  %mem1099 = alloca i8, i64 104, align 8
  %ptr1100 = ptrtoint ptr %mem1099 to i64
  store i64 %ptr1100, ptr %slot26, align 8
  %mem1101 = alloca i8, i64 8, align 8
  %ptr1102 = ptrtoint ptr %mem1101 to i64
  store i64 %ptr1102, ptr %slot27, align 8
  %mem1103 = alloca i8, i64 8, align 8
  %ptr1104 = ptrtoint ptr %mem1103 to i64
  store i64 %ptr1104, ptr %slot28, align 8
  %mem1105 = alloca i8, i64 8, align 8
  %ptr1106 = ptrtoint ptr %mem1105 to i64
  store i64 %ptr1106, ptr %slot29, align 8
  %mem1107 = alloca i8, i64 8, align 8
  %ptr1108 = ptrtoint ptr %mem1107 to i64
  store i64 %ptr1108, ptr %slot30, align 8
  %mem1109 = alloca i8, i64 8, align 8
  %ptr1110 = ptrtoint ptr %mem1109 to i64
  store i64 %ptr1110, ptr %slot31, align 8
  %mem1111 = alloca i8, i64 8, align 8
  %ptr1112 = ptrtoint ptr %mem1111 to i64
  store i64 %ptr1112, ptr %slot32, align 8
  %mem1113 = alloca i8, i64 8, align 8
  %ptr1114 = ptrtoint ptr %mem1113 to i64
  store i64 %ptr1114, ptr %slot33, align 8
  %mem1115 = alloca i8, i64 8, align 8
  %ptr1116 = ptrtoint ptr %mem1115 to i64
  store i64 %ptr1116, ptr %slot34, align 8
  %mem1117 = alloca i8, i64 40, align 8
  %ptr1118 = ptrtoint ptr %mem1117 to i64
  store i64 %ptr1118, ptr %slot35, align 8
  %mem1119 = alloca i8, i64 8, align 8
  %ptr1120 = ptrtoint ptr %mem1119 to i64
  store i64 %ptr1120, ptr %slot36, align 8
  %mem1121 = alloca i8, i64 8, align 8
  %ptr1122 = ptrtoint ptr %mem1121 to i64
  store i64 %ptr1122, ptr %slot37, align 8
  %mem1123 = alloca i8, i64 8, align 8
  %ptr1124 = ptrtoint ptr %mem1123 to i64
  store i64 %ptr1124, ptr %slot38, align 8
  %mem1125 = alloca i8, i64 8, align 8
  %ptr1126 = ptrtoint ptr %mem1125 to i64
  store i64 %ptr1126, ptr %slot39, align 8
  %mem1127 = alloca i8, i64 8, align 8
  %ptr1128 = ptrtoint ptr %mem1127 to i64
  store i64 %ptr1128, ptr %slot40, align 8
  %mem1129 = alloca i8, i64 104, align 8
  %ptr1130 = ptrtoint ptr %mem1129 to i64
  store i64 %ptr1130, ptr %slot41, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1131 = alloca i8, i64 8, align 8
  %ptr1132 = ptrtoint ptr %mem1131 to i64
  store i64 %ptr1132, ptr %slot42, align 8
  %v1133 = load i64, ptr %slot1, align 8
  %op1134 = add i64 %v1133, 64
  store i64 %op1134, ptr %slot43, align 8
  %v1135 = load i64, ptr %slot43, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  %ld1137 = load i64, ptr %p1136, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1137, ptr %slot44, align 8
  %stack1138 = call ptr @llvm.stacksave()
  %stackaddr1139 = ptrtoint ptr %stack1138 to i64
  %v1140 = load i64, ptr %slot44, align 8
  %cmp1141 = icmp ult i64 %stackaddr1139, %v1140
  %cv1142 = zext i1 %cmp1141 to i64
  store i64 %cv1142, ptr %slot45, align 8
  %v1143 = load i64, ptr %slot45, align 8
  %cond1144 = icmp ne i64 %v1143, 0
  br i1 %cond1144, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1145 = load i64, ptr %slot1, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  call void @myl_qbe_fail_frame(ptr %p1146) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1147 = load i64, ptr %slot32, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  store i64 0, ptr %p1148, align 8, !alias.scope !3, !noalias !4
  %v1149 = load i64, ptr %slot33, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  store i64 0, ptr %p1150, align 8, !alias.scope !3, !noalias !4
  %v1151 = load i64, ptr %slot34, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  store i64 0, ptr %p1152, align 8, !alias.scope !3, !noalias !4
  %v1153 = load i64, ptr %slot2, align 8
  %v1154 = load i64, ptr %slot27, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i64 %v1153, ptr %p1155, align 8, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot3, align 8
  %v1157 = load i64, ptr %slot28, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  store i64 %v1156, ptr %p1158, align 8, !alias.scope !3, !noalias !4
  %v1159 = load i64, ptr %slot4, align 8
  %v1160 = load i64, ptr %slot29, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  store i64 %v1159, ptr %p1161, align 8, !alias.scope !3, !noalias !4
  %v1162 = load i64, ptr %slot5, align 8
  %v1163 = load i64, ptr %slot30, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  store i64 %v1162, ptr %p1164, align 8, !alias.scope !3, !noalias !4
  %v1165 = load i64, ptr %slot6, align 8
  %v1166 = load i64, ptr %slot31, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  store i64 %v1165, ptr %p1167, align 8, !alias.scope !3, !noalias !4
  %v1168 = load i64, ptr %slot1, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %call1170 = call ptr @myl_qbe_heap(ptr %p1169) nomerge, !dbg !112
  %calladdr1171 = ptrtoint ptr %call1170 to i64
  store i64 %calladdr1171, ptr %slot46, align 8
  %v1172 = load i64, ptr %slot1, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  %call1174 = call i64 @myl_qbe_region_mark(ptr %p1173) nomerge, !dbg !112
  store i64 %call1174, ptr %slot47, align 8
  %v1175 = load i64, ptr %slot8, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  store i32 0, ptr %p1176, align 4, !alias.scope !3, !noalias !4
  %v1177 = load i64, ptr %slot9, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  store i32 0, ptr %p1178, align 4, !alias.scope !3, !noalias !4
  %v1179 = load i64, ptr %slot10, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  store i32 0, ptr %p1180, align 4, !alias.scope !3, !noalias !4
  %v1181 = load i64, ptr %slot11, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  store i32 0, ptr %p1182, align 4, !alias.scope !3, !noalias !4
  %v1183 = load i64, ptr %slot12, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  store i32 0, ptr %p1184, align 4, !alias.scope !3, !noalias !4
  %v1185 = load i64, ptr %slot13, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  store i32 0, ptr %p1186, align 4, !alias.scope !3, !noalias !4
  %v1187 = load i64, ptr %slot14, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  store i32 0, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  %v1189 = load i64, ptr %slot15, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  store i32 0, ptr %p1190, align 4, !alias.scope !3, !noalias !4
  %v1191 = load i64, ptr %slot16, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  store i32 0, ptr %p1192, align 4, !alias.scope !3, !noalias !4
  %v1193 = load i64, ptr %slot17, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i32 0, ptr %p1194, align 4, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot18, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  store i32 0, ptr %p1196, align 4, !alias.scope !3, !noalias !4
  %v1197 = load i64, ptr %slot19, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  store i32 0, ptr %p1198, align 4, !alias.scope !3, !noalias !4
  %v1199 = load i64, ptr %slot20, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  store i32 0, ptr %p1200, align 4, !alias.scope !3, !noalias !4
  %v1201 = load i64, ptr %slot21, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  store i32 0, ptr %p1202, align 4, !alias.scope !3, !noalias !4
  %v1203 = load i64, ptr %slot9, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  store i32 2, ptr %p1204, align 4, !alias.scope !3, !noalias !4
  %v1205 = load i64, ptr %slot11, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  store i32 2, ptr %p1206, align 4, !alias.scope !3, !noalias !4
  %v1207 = load i64, ptr %slot13, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  store i32 2, ptr %p1208, align 4, !alias.scope !3, !noalias !4
  %v1209 = load i64, ptr %slot15, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i32 2, ptr %p1210, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1211 = load i64, ptr %slot37, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i64 0, ptr %p1212, align 8, !alias.scope !3, !noalias !4
  %v1213 = load i64, ptr %slot37, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i64, ptr %p1214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1215, ptr %slot48, align 8
  %v1216 = load i64, ptr %slot48, align 8
  %cmp1217 = icmp sge i64 %v1216, 0
  %cv1218 = zext i1 %cmp1217 to i64
  store i64 %cv1218, ptr %slot49, align 8
  %v1219 = load i64, ptr %slot49, align 8
  %cond1220 = icmp ne i64 %v1219, 0
  br i1 %cond1220, label %bb_success18, label %bb_failed18
bb_failed18:
  %v1221 = load i64, ptr %slot1, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1222) nomerge, !dbg !114
  unreachable
bb_success18:
  %v1223 = load i64, ptr %slot46, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  %p1225 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v1226 = load i64, ptr %slot48, align 8
  %call1227 = call ptr @myl_native_list_new(ptr %p1224, ptr %p1225, i64 %v1226) nomerge, !dbg !114
  %calladdr1228 = ptrtoint ptr %call1227 to i64
  store i64 %calladdr1228, ptr %slot50, align 8
  %v1229 = load i64, ptr %slot50, align 8
  %cond1230 = icmp ne i64 %v1229, 0
  br i1 %cond1230, label %bb_success20, label %bb_failed20
bb_failed20:
  %v1231 = load i64, ptr %slot1, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1232) nomerge, !dbg !114
  unreachable
bb_success20:
  %v1233 = load i64, ptr %slot50, align 8
  %v1234 = load i64, ptr %slot37, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  store i64 %v1233, ptr %p1235, align 8, !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot37, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  %ld1238 = load i64, ptr %p1237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1238, ptr %slot51, align 8
  %v1239 = load i64, ptr %slot51, align 8
  %v1240 = load i64, ptr %slot24, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  store i64 %v1239, ptr %p1241, align 8, !alias.scope !3, !noalias !4
  %v1242 = load i64, ptr %slot24, align 8
  store i64 %v1242, ptr %slot52, align 8
  %v1243 = load i64, ptr %slot26, align 8
  store i64 %v1243, ptr %slot53, align 8
  %v1244 = load i64, ptr %slot52, align 8
  %v1245 = load i64, ptr %slot53, align 8
  %p1246 = inttoptr i64 %v1244 to ptr
  %p1247 = inttoptr i64 %v1245 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1247, ptr %p1246, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1248 = load i64, ptr %slot21, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i32 2, ptr %p1249, align 4, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot20, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  store i32 1, ptr %p1251, align 4, !alias.scope !3, !noalias !4
  %v1252 = load i64, ptr %slot22, align 8
  store i64 %v1252, ptr %slot54, align 8
  %v1253 = load i64, ptr %slot26, align 8
  store i64 %v1253, ptr %slot55, align 8
  %v1254 = load i64, ptr %slot55, align 8
  %v1255 = load i64, ptr %slot54, align 8
  %p1256 = inttoptr i64 %v1254 to ptr
  %p1257 = inttoptr i64 %v1255 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1257, ptr %p1256, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1258 = load i64, ptr %slot17, align 8
  %p1259 = inttoptr i64 %v1258 to ptr
  store i32 2, ptr %p1259, align 4, !alias.scope !3, !noalias !4
  %v1260 = load i64, ptr %slot21, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  %ld1262 = load i32, ptr %p1261, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1262, ptr %slot56, align 8
  %v1263 = load i32, ptr %slot56, align 8
  %v1264 = load i64, ptr %slot17, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  store i32 %v1263, ptr %p1265, align 4, !alias.scope !3, !noalias !4
  %v1266 = load i64, ptr %slot20, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  store i32 0, ptr %p1267, align 4, !alias.scope !3, !noalias !4
  %v1268 = load i64, ptr %slot16, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  store i32 1, ptr %p1269, align 4, !alias.scope !3, !noalias !4
  %v1270 = load i64, ptr %slot54, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  %ld1272 = load i64, ptr %p1271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1272, ptr %slot57, align 8
  %v1273 = load i64, ptr %slot57, align 8
  %v1274 = load i64, ptr %slot37, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i64 %v1273, ptr %p1275, align 8, !alias.scope !3, !noalias !4
  %v1276 = load i64, ptr %slot37, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  %ld1278 = load i64, ptr %p1277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1278, ptr %slot58, align 8
  %v1279 = load i64, ptr %slot58, align 8
  %v1280 = load i64, ptr %slot24, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  store i64 %v1279, ptr %p1281, align 8, !alias.scope !3, !noalias !4
  %v1282 = load i64, ptr %slot24, align 8
  store i64 %v1282, ptr %slot59, align 8
  %v1283 = load i64, ptr %slot16, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  %ld1285 = load i32, ptr %p1284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1285, ptr %slot60, align 8
  %v1286 = load i64, ptr %slot17, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  %ld1288 = load i32, ptr %p1287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1288, ptr %slot61, align 8
  %v1289 = load i32, ptr %slot61, align 8
  %op1290 = and i32 %v1289, 24
  store i32 %op1290, ptr %slot61, align 8
  %v1291 = load i32, ptr %slot61, align 8
  %cmp1292 = icmp eq i32 %v1291, 0
  %cv1293 = zext i1 %cmp1292 to i32
  store i32 %cv1293, ptr %slot62, align 8
  %v1294 = load i32, ptr %slot60, align 8
  %v1295 = load i32, ptr %slot62, align 8
  %op1296 = and i32 %v1294, %v1295
  store i32 %op1296, ptr %slot63, align 8
  %v1297 = load i32, ptr %slot63, align 8
  %cv1298 = zext i32 %v1297 to i64
  %cond1299 = icmp ne i64 %cv1298, 0
  br i1 %cond1299, label %bb_rcprivateown43, label %bb_rcprivateloan43
bb_rcprivateown43:
  %v1300 = load i64, ptr %slot26, align 8
  store i64 %v1300, ptr %slot64, align 8
  %v1301 = load i64, ptr %slot47, align 8
  store i64 %v1301, ptr %slot65, align 8
  %v1302 = load i64, ptr %slot59, align 8
  %v1303 = load i64, ptr %slot64, align 8
  %op1304 = sub i64 %v1302, %v1303
  store i64 %op1304, ptr %slot66, align 8
  %v1305 = load i64, ptr %slot64, align 8
  %v1306 = load i64, ptr %slot59, align 8
  %op1307 = sub i64 %v1305, %v1306
  store i64 %op1307, ptr %slot67, align 8
  %v1308 = load i64, ptr %slot66, align 8
  %cmp1309 = icmp ult i64 %v1308, 8
  %cv1310 = zext i1 %cmp1309 to i32
  store i32 %cv1310, ptr %slot68, align 8
  %v1311 = load i64, ptr %slot67, align 8
  %cmp1312 = icmp ult i64 %v1311, 8
  %cv1313 = zext i1 %cmp1312 to i32
  store i32 %cv1313, ptr %slot69, align 8
  %v1314 = load i32, ptr %slot68, align 8
  %v1315 = load i32, ptr %slot69, align 8
  %op1316 = or i32 %v1314, %v1315
  store i32 %op1316, ptr %slot70, align 8
  %v1317 = load i32, ptr %slot70, align 8
  %cv1318 = zext i32 %v1317 to i64
  %cond1319 = icmp ne i64 %cv1318, 0
  br i1 %cond1319, label %bb_rcmoveslow46, label %bb_rcmovecheck46
bb_rcmovecheck46:
  %v1320 = load i64, ptr %slot59, align 8
  %p1322 = inttoptr i64 %v1320 to ptr
  %gep1323 = getelementptr i8, ptr %p1322, i64 0
  %op1321 = ptrtoint ptr %gep1323 to i64
  store i64 %op1321, ptr %slot71, align 8
  %v1324 = load i64, ptr %slot71, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %ld1326 = load i64, ptr %p1325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1326, ptr %slot72, align 8
  %v1327 = load i64, ptr %slot72, align 8
  %cmp1328 = icmp ne i64 %v1327, 0
  %cv1329 = zext i1 %cmp1328 to i32
  store i32 %cv1329, ptr %slot73, align 8
  %v1330 = load i32, ptr %slot73, align 8
  %cv1331 = zext i32 %v1330 to i64
  %cond1332 = icmp ne i64 %cv1331, 0
  br i1 %cond1332, label %bb_rcmoveheader54, label %bb_rcmovenext54
bb_rcmoveheader54:
  %v1333 = load i64, ptr %slot72, align 8
  %op1334 = sub i64 %v1333, 16
  store i64 %op1334, ptr %slot74, align 8
  %v1335 = load i64, ptr %slot72, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  %rgep1337 = getelementptr i8, ptr %p1336, i64 -16
  %ld1338 = load i64, ptr %rgep1337, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1338, ptr %slot75, align 8
  %v1339 = load i64, ptr %slot75, align 8
  %op1340 = and i64 %v1339, 5764607523034234881
  store i64 %op1340, ptr %slot76, align 8
  %v1341 = load i64, ptr %slot76, align 8
  %cmp1342 = icmp ne i64 %v1341, 0
  %cv1343 = zext i1 %cmp1342 to i32
  store i32 %cv1343, ptr %slot77, align 8
  %v1344 = load i32, ptr %slot77, align 8
  %cv1345 = zext i32 %v1344 to i64
  %cond1346 = icmp ne i64 %cv1345, 0
  br i1 %cond1346, label %bb_rcmoveslow46, label %bb_rcmovenext54
bb_rcmovenext54:
  %v1347 = load i64, ptr %slot59, align 8
  %v1348 = load i64, ptr %slot64, align 8
  %p1349 = inttoptr i64 %v1347 to ptr
  %p1350 = inttoptr i64 %v1348 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1350, ptr %p1349, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1351 = load i64, ptr %slot59, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  store i64 0, ptr %p1352, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved46
bb_rcmoveslow46:
  %v1353 = load i64, ptr %slot46, align 8
  %v1354 = load i64, ptr %slot64, align 8
  %v1355 = load i64, ptr %slot59, align 8
  %v1356 = load i64, ptr %slot65, align 8
  %cv1357 = trunc i64 %v1356 to i32
  %call1358 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1353, i64 %v1354, i64 %v1355, i32 %cv1357) nomerge, !dbg !116
  store i32 %call1358, ptr %slot78, align 8
  %v1359 = load i32, ptr %slot78, align 8
  %cv1360 = zext i32 %v1359 to i64
  %cond1361 = icmp ne i64 %cv1360, 0
  br i1 %cond1361, label %bb_rcsuccess61, label %bb_rcfailure61
bb_rcfailure61:
  %v1362 = load i64, ptr %slot46, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  %call1364 = call i32 @myl_rc_take_failure(ptr %p1363) nomerge, !dbg !116
  store i32 %call1364, ptr %slot79, align 8
  %v1365 = load i64, ptr %slot1, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  %v1367 = load i32, ptr %slot79, align 8
  %call1368 = call i32 @myl_qbe_rc_status(ptr %p1366, i32 %v1367) nomerge, !dbg !116
  store i32 %call1368, ptr %slot80, align 8
  br label %bb_failure
bb_rcsuccess61:
  br label %bb_rcmoved46
bb_rcmoved46:
  %v1369 = load i64, ptr %slot16, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  store i32 0, ptr %p1370, align 4, !alias.scope !3, !noalias !4
  %v1371 = load i64, ptr %slot21, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i32 2, ptr %p1372, align 4, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot20, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i32 1, ptr %p1374, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared43
bb_rcprivateloan43:
  %v1375 = load i64, ptr %slot16, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i32, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1377, ptr %slot81, align 8
  %v1378 = load i64, ptr %slot17, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  %ld1380 = load i32, ptr %p1379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1380, ptr %slot82, align 8
  %v1381 = load i32, ptr %slot82, align 8
  %cmp1382 = icmp eq i32 %v1381, 16
  %cv1383 = zext i1 %cmp1382 to i32
  store i32 %cv1383, ptr %slot83, align 8
  %v1384 = load i32, ptr %slot83, align 8
  %v1385 = load i32, ptr %slot81, align 8
  %op1386 = and i32 %v1384, %v1385
  store i32 %op1386, ptr %slot83, align 8
  %v1387 = load i32, ptr %slot83, align 8
  %cv1388 = zext i32 %v1387 to i64
  %cond1389 = icmp ne i64 %cv1388, 0
  br i1 %cond1389, label %bb_rcprivatemove43, label %bb_rcprivatenew43
bb_rcprivatemove43:
  %v1390 = load i64, ptr %slot26, align 8
  store i64 %v1390, ptr %slot84, align 8
  %v1391 = load i64, ptr %slot59, align 8
  %v1392 = load i64, ptr %slot84, align 8
  %p1393 = inttoptr i64 %v1391 to ptr
  %p1394 = inttoptr i64 %v1392 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1394, ptr %p1393, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1395 = load i64, ptr %slot59, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  store i64 0, ptr %p1396, align 8, !alias.scope !3, !noalias !4
  %v1397 = load i64, ptr %slot21, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i32 2, ptr %p1398, align 4, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot21, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  store i32 16, ptr %p1400, align 4, !alias.scope !3, !noalias !4
  %v1401 = load i64, ptr %slot20, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  store i32 1, ptr %p1402, align 4, !alias.scope !3, !noalias !4
  %v1403 = load i64, ptr %slot16, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  store i32 0, ptr %p1404, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared43
bb_rcprivatenew43:
  %v1405 = load i64, ptr %slot26, align 8
  store i64 %v1405, ptr %slot85, align 8
  %v1406 = load i64, ptr %slot59, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  %ld1408 = load i64, ptr %p1407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1408, ptr %slot86, align 8
  %v1409 = load i64, ptr %slot86, align 8
  %cmp1410 = icmp ne i64 %v1409, 0
  %cv1411 = zext i1 %cmp1410 to i32
  store i32 %cv1411, ptr %slot87, align 8
  %v1412 = load i32, ptr %slot87, align 8
  %cv1413 = zext i32 %v1412 to i64
  %cond1414 = icmp ne i64 %cv1413, 0
  br i1 %cond1414, label %bb_rcgnn79, label %bb_rcgstore79
bb_rcgnn79:
  %v1415 = load i64, ptr %slot86, align 8
  %op1416 = sub i64 %v1415, 16
  store i64 %op1416, ptr %slot88, align 8
  %v1417 = load i64, ptr %slot86, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  %rgep1419 = getelementptr i8, ptr %p1418, i64 -16
  %ld1420 = load i64, ptr %rgep1419, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1420, ptr %slot89, align 8
  %v1421 = load i64, ptr %slot89, align 8
  %op1422 = and i64 %v1421, 4611686018427387906
  store i64 %op1422, ptr %slot90, align 8
  %v1423 = load i64, ptr %slot90, align 8
  %cmp1424 = icmp ne i64 %v1423, 0
  %cv1425 = zext i1 %cmp1424 to i32
  store i32 %cv1425, ptr %slot91, align 8
  %v1426 = load i32, ptr %slot91, align 8
  %cv1427 = zext i32 %v1426 to i64
  %cond1428 = icmp ne i64 %cv1427, 0
  br i1 %cond1428, label %bb_rcgstore79, label %bb_rcginc79
bb_rcginc79:
  %v1429 = load i64, ptr %slot86, align 8
  %op1430 = sub i64 %v1429, 24
  store i64 %op1430, ptr %slot92, align 8
  %v1431 = load i64, ptr %slot86, align 8
  %p1432 = inttoptr i64 %v1431 to ptr
  %rgep1433 = getelementptr i8, ptr %p1432, i64 -24
  %ld1434 = load i64, ptr %rgep1433, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1434, ptr %slot93, align 8
  %v1435 = load i64, ptr %slot93, align 8
  %op1436 = add i64 %v1435, 1
  store i64 %op1436, ptr %slot94, align 8
  %v1437 = load i64, ptr %slot94, align 8
  %cmp1438 = icmp eq i64 %v1437, 0
  %cv1439 = zext i1 %cmp1438 to i32
  store i32 %cv1439, ptr %slot95, align 8
  %v1440 = load i32, ptr %slot95, align 8
  %cv1441 = zext i32 %v1440 to i64
  %cond1442 = icmp ne i64 %cv1441, 0
  br i1 %cond1442, label %bb_rcglimit79, label %bb_rcgcapacity79
bb_rcglimit79:
  %v1443 = load i64, ptr %slot1, align 8
  %p1444 = inttoptr i64 %v1443 to ptr
  %call1445 = call i32 @myl_qbe_rc_status(ptr %p1444, i32 2) nomerge, !dbg !116
  store i32 %call1445, ptr %slot96, align 8
  br label %bb_failure
bb_rcgcapacity79:
  %v1446 = load i64, ptr %slot94, align 8
  %v1447 = load i64, ptr %slot86, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  %rgep1449 = getelementptr i8, ptr %p1448, i64 -24
  store i64 %v1446, ptr %rgep1449, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore79
bb_rcgstore79:
  %v1450 = load i64, ptr %slot86, align 8
  %v1451 = load i64, ptr %slot85, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  store i64 %v1450, ptr %p1452, align 8, !alias.scope !3, !noalias !4
  %v1453 = load i64, ptr %slot21, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  store i32 2, ptr %p1454, align 4, !alias.scope !3, !noalias !4
  %v1455 = load i64, ptr %slot21, align 8
  %p1456 = inttoptr i64 %v1455 to ptr
  store i32 16, ptr %p1456, align 4, !alias.scope !3, !noalias !4
  %v1457 = load i64, ptr %slot20, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  store i32 1, ptr %p1458, align 4, !alias.scope !3, !noalias !4
  %v1459 = load i64, ptr %slot16, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %ld1461 = load i32, ptr %p1460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1461, ptr %slot97, align 8
  %v1462 = load i32, ptr %slot97, align 8
  %cv1463 = zext i32 %v1462 to i64
  %cond1464 = icmp ne i64 %cv1463, 0
  br i1 %cond1464, label %bb_rcslotdrop95, label %bb_rcslotdone95
bb_rcslotdrop95:
  %v1465 = load i64, ptr %slot16, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i32 0, ptr %p1466, align 4, !alias.scope !3, !noalias !4
  %v1467 = load i64, ptr %slot22, align 8
  store i64 %v1467, ptr %slot98, align 8
  %v1468 = load i64, ptr %slot17, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  %ld1470 = load i32, ptr %p1469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1470, ptr %slot99, align 8
  %v1471 = load i32, ptr %slot99, align 8
  %op1472 = and i32 %v1471, 28
  store i32 %op1472, ptr %slot100, align 8
  %v1473 = load i32, ptr %slot100, align 8
  %cv1474 = zext i32 %v1473 to i64
  %cond1475 = icmp ne i64 %cv1474, 0
  br i1 %cond1475, label %bb_rcslotrole95, label %bb_rcslotowner95
bb_rcslotrole95:
  %v1476 = load i64, ptr %slot46, align 8
  store i64 %v1476, ptr %slot101, align 8
  %v1477 = load i64, ptr %slot98, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  %ld1479 = load i64, ptr %p1478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1479, ptr %slot102, align 8
  %v1480 = load i64, ptr %slot102, align 8
  %cmp1481 = icmp ne i64 %v1480, 0
  %cv1482 = zext i1 %cmp1481 to i32
  store i32 %cv1482, ptr %slot103, align 8
  %v1483 = load i32, ptr %slot103, align 8
  %cv1484 = zext i32 %v1483 to i64
  %cond1485 = icmp ne i64 %cv1484, 0
  br i1 %cond1485, label %bb_rcgnn111, label %bb_rcgdone111
bb_rcgnn111:
  %v1486 = load i64, ptr %slot102, align 8
  %op1487 = sub i64 %v1486, 16
  store i64 %op1487, ptr %slot104, align 8
  %v1488 = load i64, ptr %slot102, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  %rgep1490 = getelementptr i8, ptr %p1489, i64 -16
  %ld1491 = load i64, ptr %rgep1490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1491, ptr %slot105, align 8
  %v1492 = load i64, ptr %slot105, align 8
  %op1493 = and i64 %v1492, 4611686018427387906
  store i64 %op1493, ptr %slot106, align 8
  %v1494 = load i64, ptr %slot106, align 8
  %cmp1495 = icmp ne i64 %v1494, 0
  %cv1496 = zext i1 %cmp1495 to i32
  store i32 %cv1496, ptr %slot107, align 8
  %v1497 = load i32, ptr %slot107, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcgclear111, label %bb_rcgcounted111
bb_rcgcounted111:
  %v1500 = load i64, ptr %slot102, align 8
  %op1501 = sub i64 %v1500, 24
  store i64 %op1501, ptr %slot108, align 8
  %v1502 = load i64, ptr %slot102, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %rgep1504 = getelementptr i8, ptr %p1503, i64 -24
  %ld1505 = load i64, ptr %rgep1504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1505, ptr %slot109, align 8
  %v1506 = load i64, ptr %slot109, align 8
  %op1507 = sub i64 %v1506, 1
  store i64 %op1507, ptr %slot110, align 8
  %v1508 = load i64, ptr %slot110, align 8
  %cmp1509 = icmp eq i64 %v1508, 0
  %cv1510 = zext i1 %cmp1509 to i32
  store i32 %cv1510, ptr %slot111, align 8
  %v1511 = load i32, ptr %slot111, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcglast111, label %bb_rcgdec111
bb_rcglast111:
  %v1514 = load i64, ptr %slot102, align 8
  %op1515 = sub i64 %v1514, 32
  store i64 %op1515, ptr %slot112, align 8
  %v1516 = load i64, ptr %slot102, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %rgep1518 = getelementptr i8, ptr %p1517, i64 -32
  %ld1519 = load i64, ptr %rgep1518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1519, ptr %slot113, align 8
  %v1520 = load i64, ptr %slot113, align 8
  %cmp1521 = icmp ne i64 %v1520, 0
  %cv1522 = zext i1 %cmp1521 to i32
  store i32 %cv1522, ptr %slot114, align 8
  %v1523 = load i32, ptr %slot114, align 8
  %cv1524 = zext i32 %v1523 to i64
  %cond1525 = icmp ne i64 %cv1524, 0
  br i1 %cond1525, label %bb_rcgdec111, label %bb_rcgslow111
bb_rcgslow111:
  %v1526 = load i64, ptr %slot101, align 8
  %v1527 = load i64, ptr %slot98, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1526, i64 %v1527) nomerge, !dbg !116
  br label %bb_rcgdone111
bb_rcgdec111:
  %v1528 = load i64, ptr %slot110, align 8
  %v1529 = load i64, ptr %slot102, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  %rgep1531 = getelementptr i8, ptr %p1530, i64 -24
  store i64 %v1528, ptr %rgep1531, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear111
bb_rcgclear111:
  %v1532 = load i64, ptr %slot98, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  store i64 0, ptr %p1533, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone111
bb_rcgdone111:
  br label %bb_rcslotdone95
bb_rcslotowner95:
  %v1534 = load i64, ptr %slot46, align 8
  store i64 %v1534, ptr %slot115, align 8
  %v1535 = load i64, ptr %slot98, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  %ld1537 = load i64, ptr %p1536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1537, ptr %slot116, align 8
  %v1538 = load i64, ptr %slot116, align 8
  %cmp1539 = icmp ne i64 %v1538, 0
  %cv1540 = zext i1 %cmp1539 to i32
  store i32 %cv1540, ptr %slot117, align 8
  %v1541 = load i32, ptr %slot117, align 8
  %cv1542 = zext i32 %v1541 to i64
  %cond1543 = icmp ne i64 %cv1542, 0
  br i1 %cond1543, label %bb_rcgnn126, label %bb_rcgdone126
bb_rcgnn126:
  %v1544 = load i64, ptr %slot116, align 8
  %op1545 = sub i64 %v1544, 16
  store i64 %op1545, ptr %slot118, align 8
  %v1546 = load i64, ptr %slot116, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  %rgep1548 = getelementptr i8, ptr %p1547, i64 -16
  %ld1549 = load i64, ptr %rgep1548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1549, ptr %slot119, align 8
  %v1550 = load i64, ptr %slot119, align 8
  %op1551 = and i64 %v1550, 4611686018427387906
  store i64 %op1551, ptr %slot120, align 8
  %v1552 = load i64, ptr %slot120, align 8
  %cmp1553 = icmp ne i64 %v1552, 0
  %cv1554 = zext i1 %cmp1553 to i32
  store i32 %cv1554, ptr %slot121, align 8
  %v1555 = load i32, ptr %slot121, align 8
  %cv1556 = zext i32 %v1555 to i64
  %cond1557 = icmp ne i64 %cv1556, 0
  br i1 %cond1557, label %bb_rcgclear126, label %bb_rcgcounted126
bb_rcgcounted126:
  %v1558 = load i64, ptr %slot116, align 8
  %op1559 = sub i64 %v1558, 32
  store i64 %op1559, ptr %slot122, align 8
  %v1560 = load i64, ptr %slot116, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  %rgep1562 = getelementptr i8, ptr %p1561, i64 -32
  %ld1563 = load i64, ptr %rgep1562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1563, ptr %slot123, align 8
  %v1564 = load i64, ptr %slot123, align 8
  %op1565 = sub i64 %v1564, 1
  store i64 %op1565, ptr %slot124, align 8
  %v1566 = load i64, ptr %slot124, align 8
  %cmp1567 = icmp eq i64 %v1566, 0
  %cv1568 = zext i1 %cmp1567 to i32
  store i32 %cv1568, ptr %slot125, align 8
  %v1569 = load i32, ptr %slot125, align 8
  %cv1570 = zext i32 %v1569 to i64
  %cond1571 = icmp ne i64 %cv1570, 0
  br i1 %cond1571, label %bb_rcglast126, label %bb_rcgdec126
bb_rcglast126:
  %v1572 = load i64, ptr %slot116, align 8
  %op1573 = sub i64 %v1572, 24
  store i64 %op1573, ptr %slot126, align 8
  %v1574 = load i64, ptr %slot116, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %rgep1576 = getelementptr i8, ptr %p1575, i64 -24
  %ld1577 = load i64, ptr %rgep1576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1577, ptr %slot127, align 8
  %v1578 = load i64, ptr %slot127, align 8
  %cmp1579 = icmp ne i64 %v1578, 0
  %cv1580 = zext i1 %cmp1579 to i32
  store i32 %cv1580, ptr %slot128, align 8
  %v1581 = load i32, ptr %slot128, align 8
  %cv1582 = zext i32 %v1581 to i64
  %cond1583 = icmp ne i64 %cv1582, 0
  br i1 %cond1583, label %bb_rcgdec126, label %bb_rcgslow126
bb_rcgslow126:
  %v1584 = load i64, ptr %slot115, align 8
  %v1585 = load i64, ptr %slot98, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1584, i64 %v1585) nomerge, !dbg !116
  br label %bb_rcgdone126
bb_rcgdec126:
  %v1586 = load i64, ptr %slot124, align 8
  %v1587 = load i64, ptr %slot116, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  %rgep1589 = getelementptr i8, ptr %p1588, i64 -32
  store i64 %v1586, ptr %rgep1589, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear126
bb_rcgclear126:
  %v1590 = load i64, ptr %slot98, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  store i64 0, ptr %p1591, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone126
bb_rcgdone126:
  br label %bb_rcslotdone95
bb_rcslotdone95:
  br label %bb_rcprivateprepared43
bb_rcprivateprepared43:
  %v1592 = load i64, ptr %slot8, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  %ld1594 = load i32, ptr %p1593, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1594, ptr %slot129, align 8
  %v1595 = load i32, ptr %slot129, align 8
  %cv1596 = zext i32 %v1595 to i64
  %cond1597 = icmp ne i64 %cv1596, 0
  br i1 %cond1597, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v1598 = load i64, ptr %slot8, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  store i32 0, ptr %p1599, align 4, !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot32, align 8
  store i64 %v1600, ptr %slot130, align 8
  %v1601 = load i64, ptr %slot9, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  %ld1603 = load i32, ptr %p1602, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1603, ptr %slot131, align 8
  %v1604 = load i32, ptr %slot131, align 8
  %op1605 = and i32 %v1604, 28
  store i32 %op1605, ptr %slot132, align 8
  %v1606 = load i32, ptr %slot132, align 8
  %cv1607 = zext i32 %v1606 to i64
  %cond1608 = icmp ne i64 %cv1607, 0
  br i1 %cond1608, label %bb_rcslotrole133, label %bb_rcslotowner133
bb_rcslotrole133:
  %v1609 = load i64, ptr %slot46, align 8
  store i64 %v1609, ptr %slot133, align 8
  %v1610 = load i64, ptr %slot130, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  %ld1612 = load i64, ptr %p1611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1612, ptr %slot134, align 8
  %v1613 = load i64, ptr %slot134, align 8
  %cmp1614 = icmp ne i64 %v1613, 0
  %cv1615 = zext i1 %cmp1614 to i32
  store i32 %cv1615, ptr %slot135, align 8
  %v1616 = load i32, ptr %slot135, align 8
  %cv1617 = zext i32 %v1616 to i64
  %cond1618 = icmp ne i64 %cv1617, 0
  br i1 %cond1618, label %bb_rcgnn149, label %bb_rcgdone149
bb_rcgnn149:
  %v1619 = load i64, ptr %slot134, align 8
  %op1620 = sub i64 %v1619, 16
  store i64 %op1620, ptr %slot136, align 8
  %v1621 = load i64, ptr %slot134, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  %rgep1623 = getelementptr i8, ptr %p1622, i64 -16
  %ld1624 = load i64, ptr %rgep1623, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1624, ptr %slot137, align 8
  %v1625 = load i64, ptr %slot137, align 8
  %op1626 = and i64 %v1625, 4611686018427387906
  store i64 %op1626, ptr %slot138, align 8
  %v1627 = load i64, ptr %slot138, align 8
  %cmp1628 = icmp ne i64 %v1627, 0
  %cv1629 = zext i1 %cmp1628 to i32
  store i32 %cv1629, ptr %slot139, align 8
  %v1630 = load i32, ptr %slot139, align 8
  %cv1631 = zext i32 %v1630 to i64
  %cond1632 = icmp ne i64 %cv1631, 0
  br i1 %cond1632, label %bb_rcgclear149, label %bb_rcgcounted149
bb_rcgcounted149:
  %v1633 = load i64, ptr %slot134, align 8
  %op1634 = sub i64 %v1633, 24
  store i64 %op1634, ptr %slot140, align 8
  %v1635 = load i64, ptr %slot134, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %rgep1637 = getelementptr i8, ptr %p1636, i64 -24
  %ld1638 = load i64, ptr %rgep1637, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1638, ptr %slot141, align 8
  %v1639 = load i64, ptr %slot141, align 8
  %op1640 = sub i64 %v1639, 1
  store i64 %op1640, ptr %slot142, align 8
  %v1641 = load i64, ptr %slot142, align 8
  %cmp1642 = icmp eq i64 %v1641, 0
  %cv1643 = zext i1 %cmp1642 to i32
  store i32 %cv1643, ptr %slot143, align 8
  %v1644 = load i32, ptr %slot143, align 8
  %cv1645 = zext i32 %v1644 to i64
  %cond1646 = icmp ne i64 %cv1645, 0
  br i1 %cond1646, label %bb_rcglast149, label %bb_rcgdec149
bb_rcglast149:
  %v1647 = load i64, ptr %slot134, align 8
  %op1648 = sub i64 %v1647, 32
  store i64 %op1648, ptr %slot144, align 8
  %v1649 = load i64, ptr %slot134, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  %rgep1651 = getelementptr i8, ptr %p1650, i64 -32
  %ld1652 = load i64, ptr %rgep1651, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1652, ptr %slot145, align 8
  %v1653 = load i64, ptr %slot145, align 8
  %cmp1654 = icmp ne i64 %v1653, 0
  %cv1655 = zext i1 %cmp1654 to i32
  store i32 %cv1655, ptr %slot146, align 8
  %v1656 = load i32, ptr %slot146, align 8
  %cv1657 = zext i32 %v1656 to i64
  %cond1658 = icmp ne i64 %cv1657, 0
  br i1 %cond1658, label %bb_rcgdec149, label %bb_rcgslow149
bb_rcgslow149:
  %v1659 = load i64, ptr %slot133, align 8
  %v1660 = load i64, ptr %slot130, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1659, i64 %v1660) nomerge, !dbg !116
  br label %bb_rcgdone149
bb_rcgdec149:
  %v1661 = load i64, ptr %slot142, align 8
  %v1662 = load i64, ptr %slot134, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  %rgep1664 = getelementptr i8, ptr %p1663, i64 -24
  store i64 %v1661, ptr %rgep1664, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear149
bb_rcgclear149:
  %v1665 = load i64, ptr %slot130, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  store i64 0, ptr %p1666, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone149
bb_rcgdone149:
  br label %bb_rcslotdone133
bb_rcslotowner133:
  %v1667 = load i64, ptr %slot46, align 8
  store i64 %v1667, ptr %slot147, align 8
  %v1668 = load i64, ptr %slot130, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  %ld1670 = load i64, ptr %p1669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1670, ptr %slot148, align 8
  %v1671 = load i64, ptr %slot148, align 8
  %cmp1672 = icmp ne i64 %v1671, 0
  %cv1673 = zext i1 %cmp1672 to i32
  store i32 %cv1673, ptr %slot149, align 8
  %v1674 = load i32, ptr %slot149, align 8
  %cv1675 = zext i32 %v1674 to i64
  %cond1676 = icmp ne i64 %cv1675, 0
  br i1 %cond1676, label %bb_rcgnn164, label %bb_rcgdone164
bb_rcgnn164:
  %v1677 = load i64, ptr %slot148, align 8
  %op1678 = sub i64 %v1677, 16
  store i64 %op1678, ptr %slot150, align 8
  %v1679 = load i64, ptr %slot148, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %rgep1681 = getelementptr i8, ptr %p1680, i64 -16
  %ld1682 = load i64, ptr %rgep1681, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1682, ptr %slot151, align 8
  %v1683 = load i64, ptr %slot151, align 8
  %op1684 = and i64 %v1683, 4611686018427387906
  store i64 %op1684, ptr %slot152, align 8
  %v1685 = load i64, ptr %slot152, align 8
  %cmp1686 = icmp ne i64 %v1685, 0
  %cv1687 = zext i1 %cmp1686 to i32
  store i32 %cv1687, ptr %slot153, align 8
  %v1688 = load i32, ptr %slot153, align 8
  %cv1689 = zext i32 %v1688 to i64
  %cond1690 = icmp ne i64 %cv1689, 0
  br i1 %cond1690, label %bb_rcgclear164, label %bb_rcgcounted164
bb_rcgcounted164:
  %v1691 = load i64, ptr %slot148, align 8
  %op1692 = sub i64 %v1691, 32
  store i64 %op1692, ptr %slot154, align 8
  %v1693 = load i64, ptr %slot148, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  %rgep1695 = getelementptr i8, ptr %p1694, i64 -32
  %ld1696 = load i64, ptr %rgep1695, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1696, ptr %slot155, align 8
  %v1697 = load i64, ptr %slot155, align 8
  %op1698 = sub i64 %v1697, 1
  store i64 %op1698, ptr %slot156, align 8
  %v1699 = load i64, ptr %slot156, align 8
  %cmp1700 = icmp eq i64 %v1699, 0
  %cv1701 = zext i1 %cmp1700 to i32
  store i32 %cv1701, ptr %slot157, align 8
  %v1702 = load i32, ptr %slot157, align 8
  %cv1703 = zext i32 %v1702 to i64
  %cond1704 = icmp ne i64 %cv1703, 0
  br i1 %cond1704, label %bb_rcglast164, label %bb_rcgdec164
bb_rcglast164:
  %v1705 = load i64, ptr %slot148, align 8
  %op1706 = sub i64 %v1705, 24
  store i64 %op1706, ptr %slot158, align 8
  %v1707 = load i64, ptr %slot148, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  %rgep1709 = getelementptr i8, ptr %p1708, i64 -24
  %ld1710 = load i64, ptr %rgep1709, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1710, ptr %slot159, align 8
  %v1711 = load i64, ptr %slot159, align 8
  %cmp1712 = icmp ne i64 %v1711, 0
  %cv1713 = zext i1 %cmp1712 to i32
  store i32 %cv1713, ptr %slot160, align 8
  %v1714 = load i32, ptr %slot160, align 8
  %cv1715 = zext i32 %v1714 to i64
  %cond1716 = icmp ne i64 %cv1715, 0
  br i1 %cond1716, label %bb_rcgdec164, label %bb_rcgslow164
bb_rcgslow164:
  %v1717 = load i64, ptr %slot147, align 8
  %v1718 = load i64, ptr %slot130, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1717, i64 %v1718) nomerge, !dbg !116
  br label %bb_rcgdone164
bb_rcgdec164:
  %v1719 = load i64, ptr %slot156, align 8
  %v1720 = load i64, ptr %slot148, align 8
  %p1721 = inttoptr i64 %v1720 to ptr
  %rgep1722 = getelementptr i8, ptr %p1721, i64 -32
  store i64 %v1719, ptr %rgep1722, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear164
bb_rcgclear164:
  %v1723 = load i64, ptr %slot130, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i64 0, ptr %p1724, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone164
bb_rcgdone164:
  br label %bb_rcslotdone133
bb_rcslotdone133:
  %v1725 = load i64, ptr %slot32, align 8
  store i64 %v1725, ptr %slot161, align 8
  %v1726 = load i64, ptr %slot26, align 8
  store i64 %v1726, ptr %slot162, align 8
  %v1727 = load i64, ptr %slot162, align 8
  %v1728 = load i64, ptr %slot161, align 8
  %p1729 = inttoptr i64 %v1727 to ptr
  %p1730 = inttoptr i64 %v1728 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1730, ptr %p1729, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot20, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i32 0, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  %v1733 = load i64, ptr %slot9, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 2, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot21, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  %ld1737 = load i32, ptr %p1736, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1737, ptr %slot163, align 8
  %v1738 = load i32, ptr %slot163, align 8
  %v1739 = load i64, ptr %slot9, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i32 %v1738, ptr %p1740, align 4, !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot8, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i32 1, ptr %p1742, align 4, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot32, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %ld1745 = load i64, ptr %p1744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1745, ptr %slot164, align 8
  %v1746 = load i64, ptr %slot164, align 8
  %v1747 = load i64, ptr %slot37, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i64 %v1746, ptr %p1748, align 8, !alias.scope !3, !noalias !4
  %v1749 = load i64, ptr %slot37, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i64, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1751, ptr %slot165, align 8
  %v1752 = load i64, ptr %slot165, align 8
  %v1753 = load i64, ptr %slot24, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  store i64 %v1752, ptr %p1754, align 8, !alias.scope !3, !noalias !4
  %v1755 = load i64, ptr %slot24, align 8
  store i64 %v1755, ptr %slot166, align 8
  %v1756 = load i64, ptr %slot16, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  %ld1758 = load i32, ptr %p1757, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1758, ptr %slot167, align 8
  %v1759 = load i64, ptr %slot17, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  %ld1761 = load i32, ptr %p1760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1761, ptr %slot168, align 8
  %v1762 = load i32, ptr %slot168, align 8
  %op1763 = and i32 %v1762, 24
  store i32 %op1763, ptr %slot168, align 8
  %v1764 = load i32, ptr %slot168, align 8
  %cmp1765 = icmp eq i32 %v1764, 0
  %cv1766 = zext i1 %cmp1765 to i32
  store i32 %cv1766, ptr %slot169, align 8
  %v1767 = load i32, ptr %slot167, align 8
  %v1768 = load i32, ptr %slot169, align 8
  %op1769 = and i32 %v1767, %v1768
  store i32 %op1769, ptr %slot170, align 8
  %v1770 = load i32, ptr %slot170, align 8
  %cv1771 = zext i32 %v1770 to i64
  %cond1772 = icmp ne i64 %cv1771, 0
  br i1 %cond1772, label %bb_rctake178, label %bb_rccopy178
bb_rctake178:
  %v1773 = load i64, ptr %slot26, align 8
  store i64 %v1773, ptr %slot171, align 8
  %v1774 = load i64, ptr %slot47, align 8
  store i64 %v1774, ptr %slot172, align 8
  %v1775 = load i64, ptr %slot166, align 8
  %v1776 = load i64, ptr %slot171, align 8
  %op1777 = sub i64 %v1775, %v1776
  store i64 %op1777, ptr %slot173, align 8
  %v1778 = load i64, ptr %slot171, align 8
  %v1779 = load i64, ptr %slot166, align 8
  %op1780 = sub i64 %v1778, %v1779
  store i64 %op1780, ptr %slot174, align 8
  %v1781 = load i64, ptr %slot173, align 8
  %cmp1782 = icmp ult i64 %v1781, 8
  %cv1783 = zext i1 %cmp1782 to i32
  store i32 %cv1783, ptr %slot175, align 8
  %v1784 = load i64, ptr %slot174, align 8
  %cmp1785 = icmp ult i64 %v1784, 8
  %cv1786 = zext i1 %cmp1785 to i32
  store i32 %cv1786, ptr %slot176, align 8
  %v1787 = load i32, ptr %slot175, align 8
  %v1788 = load i32, ptr %slot176, align 8
  %op1789 = or i32 %v1787, %v1788
  store i32 %op1789, ptr %slot177, align 8
  %v1790 = load i32, ptr %slot177, align 8
  %cv1791 = zext i32 %v1790 to i64
  %cond1792 = icmp ne i64 %cv1791, 0
  br i1 %cond1792, label %bb_rcmoveslow187, label %bb_rcmovecheck187
bb_rcmovecheck187:
  %v1793 = load i64, ptr %slot166, align 8
  %p1795 = inttoptr i64 %v1793 to ptr
  %gep1796 = getelementptr i8, ptr %p1795, i64 0
  %op1794 = ptrtoint ptr %gep1796 to i64
  store i64 %op1794, ptr %slot178, align 8
  %v1797 = load i64, ptr %slot178, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  %ld1799 = load i64, ptr %p1798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1799, ptr %slot179, align 8
  %v1800 = load i64, ptr %slot179, align 8
  %cmp1801 = icmp ne i64 %v1800, 0
  %cv1802 = zext i1 %cmp1801 to i32
  store i32 %cv1802, ptr %slot180, align 8
  %v1803 = load i32, ptr %slot180, align 8
  %cv1804 = zext i32 %v1803 to i64
  %cond1805 = icmp ne i64 %cv1804, 0
  br i1 %cond1805, label %bb_rcmoveheader195, label %bb_rcmovenext195
bb_rcmoveheader195:
  %v1806 = load i64, ptr %slot179, align 8
  %op1807 = sub i64 %v1806, 16
  store i64 %op1807, ptr %slot181, align 8
  %v1808 = load i64, ptr %slot179, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  %rgep1810 = getelementptr i8, ptr %p1809, i64 -16
  %ld1811 = load i64, ptr %rgep1810, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1811, ptr %slot182, align 8
  %v1812 = load i64, ptr %slot182, align 8
  %op1813 = and i64 %v1812, 5764607523034234881
  store i64 %op1813, ptr %slot183, align 8
  %v1814 = load i64, ptr %slot183, align 8
  %cmp1815 = icmp ne i64 %v1814, 0
  %cv1816 = zext i1 %cmp1815 to i32
  store i32 %cv1816, ptr %slot184, align 8
  %v1817 = load i32, ptr %slot184, align 8
  %cv1818 = zext i32 %v1817 to i64
  %cond1819 = icmp ne i64 %cv1818, 0
  br i1 %cond1819, label %bb_rcmoveslow187, label %bb_rcmovenext195
bb_rcmovenext195:
  %v1820 = load i64, ptr %slot166, align 8
  %v1821 = load i64, ptr %slot171, align 8
  %p1822 = inttoptr i64 %v1820 to ptr
  %p1823 = inttoptr i64 %v1821 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1823, ptr %p1822, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1824 = load i64, ptr %slot166, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  store i64 0, ptr %p1825, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved187
bb_rcmoveslow187:
  %v1826 = load i64, ptr %slot46, align 8
  %v1827 = load i64, ptr %slot171, align 8
  %v1828 = load i64, ptr %slot166, align 8
  %v1829 = load i64, ptr %slot172, align 8
  %cv1830 = trunc i64 %v1829 to i32
  %call1831 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1826, i64 %v1827, i64 %v1828, i32 %cv1830) nomerge, !dbg !118
  store i32 %call1831, ptr %slot185, align 8
  %v1832 = load i32, ptr %slot185, align 8
  %cv1833 = zext i32 %v1832 to i64
  %cond1834 = icmp ne i64 %cv1833, 0
  br i1 %cond1834, label %bb_rcsuccess202, label %bb_rcfailure202
bb_rcfailure202:
  %v1835 = load i64, ptr %slot46, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  %call1837 = call i32 @myl_rc_take_failure(ptr %p1836) nomerge, !dbg !118
  store i32 %call1837, ptr %slot186, align 8
  %v1838 = load i64, ptr %slot1, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  %v1840 = load i32, ptr %slot186, align 8
  %call1841 = call i32 @myl_qbe_rc_status(ptr %p1839, i32 %v1840) nomerge, !dbg !118
  store i32 %call1841, ptr %slot187, align 8
  br label %bb_failure
bb_rcsuccess202:
  br label %bb_rcmoved187
bb_rcmoved187:
  %v1842 = load i64, ptr %slot16, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  store i32 0, ptr %p1843, align 4, !alias.scope !3, !noalias !4
  %v1844 = load i64, ptr %slot21, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  store i32 2, ptr %p1845, align 4, !alias.scope !3, !noalias !4
  %v1846 = load i64, ptr %slot20, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  store i32 1, ptr %p1847, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared178
bb_rccopy178:
  %v1848 = load i64, ptr %slot26, align 8
  store i64 %v1848, ptr %slot188, align 8
  %v1849 = load i64, ptr %slot47, align 8
  store i64 %v1849, ptr %slot189, align 8
  %v1850 = load i64, ptr %slot166, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  %ld1852 = load i64, ptr %p1851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1852, ptr %slot190, align 8
  %v1853 = load i64, ptr %slot190, align 8
  %cmp1854 = icmp ne i64 %v1853, 0
  %cv1855 = zext i1 %cmp1854 to i32
  store i32 %cv1855, ptr %slot191, align 8
  %v1856 = load i32, ptr %slot191, align 8
  %cv1857 = zext i32 %v1856 to i64
  %cond1858 = icmp ne i64 %cv1857, 0
  br i1 %cond1858, label %bb_rcgnn211, label %bb_rcgplain211
bb_rcgnn211:
  %v1859 = load i64, ptr %slot190, align 8
  %op1860 = sub i64 %v1859, 16
  store i64 %op1860, ptr %slot192, align 8
  %v1861 = load i64, ptr %slot190, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  %rgep1863 = getelementptr i8, ptr %p1862, i64 -16
  %ld1864 = load i64, ptr %rgep1863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1864, ptr %slot193, align 8
  %v1865 = load i64, ptr %slot193, align 8
  %op1866 = and i64 %v1865, 4611686018427387906
  store i64 %op1866, ptr %slot194, align 8
  %v1867 = load i64, ptr %slot194, align 8
  %cmp1868 = icmp ne i64 %v1867, 0
  %cv1869 = zext i1 %cmp1868 to i32
  store i32 %cv1869, ptr %slot195, align 8
  %v1870 = load i32, ptr %slot195, align 8
  %cv1871 = zext i32 %v1870 to i64
  %cond1872 = icmp ne i64 %cv1871, 0
  br i1 %cond1872, label %bb_rcgspecial211, label %bb_rcginc211
bb_rcginc211:
  %v1873 = load i64, ptr %slot190, align 8
  %op1874 = sub i64 %v1873, 32
  store i64 %op1874, ptr %slot196, align 8
  %v1875 = load i64, ptr %slot190, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  %rgep1877 = getelementptr i8, ptr %p1876, i64 -32
  %ld1878 = load i64, ptr %rgep1877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1878, ptr %slot197, align 8
  %v1879 = load i64, ptr %slot197, align 8
  %op1880 = add i64 %v1879, 1
  store i64 %op1880, ptr %slot198, align 8
  %v1881 = load i64, ptr %slot198, align 8
  %cmp1882 = icmp eq i64 %v1881, 0
  %cv1883 = zext i1 %cmp1882 to i32
  store i32 %cv1883, ptr %slot199, align 8
  %v1884 = load i32, ptr %slot199, align 8
  %cv1885 = zext i32 %v1884 to i64
  %cond1886 = icmp ne i64 %cv1885, 0
  br i1 %cond1886, label %bb_rcglimit211, label %bb_rcgcapacity211
bb_rcglimit211:
  %v1887 = load i64, ptr %slot1, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  %call1889 = call i32 @myl_qbe_rc_status(ptr %p1888, i32 2) nomerge, !dbg !118
  store i32 %call1889, ptr %slot200, align 8
  br label %bb_failure
bb_rcgcapacity211:
  %v1890 = load i64, ptr %slot198, align 8
  %v1891 = load i64, ptr %slot190, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %rgep1893 = getelementptr i8, ptr %p1892, i64 -32
  store i64 %v1890, ptr %rgep1893, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain211
bb_rcgspecial211:
  %v1894 = load i64, ptr %slot193, align 8
  %op1895 = and i64 %v1894, 4611686018427387904
  store i64 %op1895, ptr %slot201, align 8
  %v1896 = load i64, ptr %slot201, align 8
  %cmp1897 = icmp ne i64 %v1896, 0
  %cv1898 = zext i1 %cmp1897 to i32
  store i32 %cv1898, ptr %slot202, align 8
  %v1899 = load i32, ptr %slot202, align 8
  %cv1900 = zext i32 %v1899 to i64
  %cond1901 = icmp ne i64 %cv1900, 0
  br i1 %cond1901, label %bb_rcgslow211, label %bb_rcgplain211
bb_rcgslow211:
  %v1902 = load i64, ptr %slot46, align 8
  %v1903 = load i64, ptr %slot188, align 8
  %v1904 = load i64, ptr %slot166, align 8
  %v1905 = load i64, ptr %slot189, align 8
  %cv1906 = trunc i64 %v1905 to i32
  %call1907 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v1902, i64 %v1903, i64 %v1904, i32 %cv1906) nomerge, !dbg !118
  store i32 %call1907, ptr %slot203, align 8
  %v1908 = load i32, ptr %slot203, align 8
  %cv1909 = zext i32 %v1908 to i64
  %cond1910 = icmp ne i64 %cv1909, 0
  br i1 %cond1910, label %bb_rcsuccess225, label %bb_rcfailure225
bb_rcfailure225:
  %v1911 = load i64, ptr %slot46, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  %call1913 = call i32 @myl_rc_take_failure(ptr %p1912) nomerge, !dbg !118
  store i32 %call1913, ptr %slot204, align 8
  %v1914 = load i64, ptr %slot1, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  %v1916 = load i32, ptr %slot204, align 8
  %call1917 = call i32 @myl_qbe_rc_status(ptr %p1915, i32 %v1916) nomerge, !dbg !118
  store i32 %call1917, ptr %slot205, align 8
  br label %bb_failure
bb_rcsuccess225:
  br label %bb_rcgdone211
bb_rcgplain211:
  %v1918 = load i64, ptr %slot190, align 8
  %v1919 = load i64, ptr %slot188, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  store i64 %v1918, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone211
bb_rcgdone211:
  %v1921 = load i64, ptr %slot21, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  store i32 2, ptr %p1922, align 4, !alias.scope !3, !noalias !4
  %v1923 = load i64, ptr %slot20, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  store i32 1, ptr %p1924, align 4, !alias.scope !3, !noalias !4
  %v1925 = load i64, ptr %slot16, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %ld1927 = load i32, ptr %p1926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1927, ptr %slot206, align 8
  %v1928 = load i32, ptr %slot206, align 8
  %cv1929 = zext i32 %v1928 to i64
  %cond1930 = icmp ne i64 %cv1929, 0
  br i1 %cond1930, label %bb_rcslotdrop232, label %bb_rcslotdone232
bb_rcslotdrop232:
  %v1931 = load i64, ptr %slot16, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  store i32 0, ptr %p1932, align 4, !alias.scope !3, !noalias !4
  %v1933 = load i64, ptr %slot22, align 8
  store i64 %v1933, ptr %slot207, align 8
  %v1934 = load i64, ptr %slot17, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  %ld1936 = load i32, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1936, ptr %slot208, align 8
  %v1937 = load i32, ptr %slot208, align 8
  %op1938 = and i32 %v1937, 28
  store i32 %op1938, ptr %slot209, align 8
  %v1939 = load i32, ptr %slot209, align 8
  %cv1940 = zext i32 %v1939 to i64
  %cond1941 = icmp ne i64 %cv1940, 0
  br i1 %cond1941, label %bb_rcslotrole232, label %bb_rcslotowner232
bb_rcslotrole232:
  %v1942 = load i64, ptr %slot46, align 8
  store i64 %v1942, ptr %slot210, align 8
  %v1943 = load i64, ptr %slot207, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  %ld1945 = load i64, ptr %p1944, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1945, ptr %slot211, align 8
  %v1946 = load i64, ptr %slot211, align 8
  %cmp1947 = icmp ne i64 %v1946, 0
  %cv1948 = zext i1 %cmp1947 to i32
  store i32 %cv1948, ptr %slot212, align 8
  %v1949 = load i32, ptr %slot212, align 8
  %cv1950 = zext i32 %v1949 to i64
  %cond1951 = icmp ne i64 %cv1950, 0
  br i1 %cond1951, label %bb_rcgnn248, label %bb_rcgdone248
bb_rcgnn248:
  %v1952 = load i64, ptr %slot211, align 8
  %op1953 = sub i64 %v1952, 16
  store i64 %op1953, ptr %slot213, align 8
  %v1954 = load i64, ptr %slot211, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  %rgep1956 = getelementptr i8, ptr %p1955, i64 -16
  %ld1957 = load i64, ptr %rgep1956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1957, ptr %slot214, align 8
  %v1958 = load i64, ptr %slot214, align 8
  %op1959 = and i64 %v1958, 4611686018427387906
  store i64 %op1959, ptr %slot215, align 8
  %v1960 = load i64, ptr %slot215, align 8
  %cmp1961 = icmp ne i64 %v1960, 0
  %cv1962 = zext i1 %cmp1961 to i32
  store i32 %cv1962, ptr %slot216, align 8
  %v1963 = load i32, ptr %slot216, align 8
  %cv1964 = zext i32 %v1963 to i64
  %cond1965 = icmp ne i64 %cv1964, 0
  br i1 %cond1965, label %bb_rcgclear248, label %bb_rcgcounted248
bb_rcgcounted248:
  %v1966 = load i64, ptr %slot211, align 8
  %op1967 = sub i64 %v1966, 24
  store i64 %op1967, ptr %slot217, align 8
  %v1968 = load i64, ptr %slot211, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  %rgep1970 = getelementptr i8, ptr %p1969, i64 -24
  %ld1971 = load i64, ptr %rgep1970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1971, ptr %slot218, align 8
  %v1972 = load i64, ptr %slot218, align 8
  %op1973 = sub i64 %v1972, 1
  store i64 %op1973, ptr %slot219, align 8
  %v1974 = load i64, ptr %slot219, align 8
  %cmp1975 = icmp eq i64 %v1974, 0
  %cv1976 = zext i1 %cmp1975 to i32
  store i32 %cv1976, ptr %slot220, align 8
  %v1977 = load i32, ptr %slot220, align 8
  %cv1978 = zext i32 %v1977 to i64
  %cond1979 = icmp ne i64 %cv1978, 0
  br i1 %cond1979, label %bb_rcglast248, label %bb_rcgdec248
bb_rcglast248:
  %v1980 = load i64, ptr %slot211, align 8
  %op1981 = sub i64 %v1980, 32
  store i64 %op1981, ptr %slot221, align 8
  %v1982 = load i64, ptr %slot211, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  %rgep1984 = getelementptr i8, ptr %p1983, i64 -32
  %ld1985 = load i64, ptr %rgep1984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1985, ptr %slot222, align 8
  %v1986 = load i64, ptr %slot222, align 8
  %cmp1987 = icmp ne i64 %v1986, 0
  %cv1988 = zext i1 %cmp1987 to i32
  store i32 %cv1988, ptr %slot223, align 8
  %v1989 = load i32, ptr %slot223, align 8
  %cv1990 = zext i32 %v1989 to i64
  %cond1991 = icmp ne i64 %cv1990, 0
  br i1 %cond1991, label %bb_rcgdec248, label %bb_rcgslow248
bb_rcgslow248:
  %v1992 = load i64, ptr %slot210, align 8
  %v1993 = load i64, ptr %slot207, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1992, i64 %v1993) nomerge, !dbg !118
  br label %bb_rcgdone248
bb_rcgdec248:
  %v1994 = load i64, ptr %slot219, align 8
  %v1995 = load i64, ptr %slot211, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  %rgep1997 = getelementptr i8, ptr %p1996, i64 -24
  store i64 %v1994, ptr %rgep1997, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear248
bb_rcgclear248:
  %v1998 = load i64, ptr %slot207, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  store i64 0, ptr %p1999, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone248
bb_rcgdone248:
  br label %bb_rcslotdone232
bb_rcslotowner232:
  %v2000 = load i64, ptr %slot46, align 8
  store i64 %v2000, ptr %slot224, align 8
  %v2001 = load i64, ptr %slot207, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  %ld2003 = load i64, ptr %p2002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2003, ptr %slot225, align 8
  %v2004 = load i64, ptr %slot225, align 8
  %cmp2005 = icmp ne i64 %v2004, 0
  %cv2006 = zext i1 %cmp2005 to i32
  store i32 %cv2006, ptr %slot226, align 8
  %v2007 = load i32, ptr %slot226, align 8
  %cv2008 = zext i32 %v2007 to i64
  %cond2009 = icmp ne i64 %cv2008, 0
  br i1 %cond2009, label %bb_rcgnn263, label %bb_rcgdone263
bb_rcgnn263:
  %v2010 = load i64, ptr %slot225, align 8
  %op2011 = sub i64 %v2010, 16
  store i64 %op2011, ptr %slot227, align 8
  %v2012 = load i64, ptr %slot225, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  %rgep2014 = getelementptr i8, ptr %p2013, i64 -16
  %ld2015 = load i64, ptr %rgep2014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2015, ptr %slot228, align 8
  %v2016 = load i64, ptr %slot228, align 8
  %op2017 = and i64 %v2016, 4611686018427387906
  store i64 %op2017, ptr %slot229, align 8
  %v2018 = load i64, ptr %slot229, align 8
  %cmp2019 = icmp ne i64 %v2018, 0
  %cv2020 = zext i1 %cmp2019 to i32
  store i32 %cv2020, ptr %slot230, align 8
  %v2021 = load i32, ptr %slot230, align 8
  %cv2022 = zext i32 %v2021 to i64
  %cond2023 = icmp ne i64 %cv2022, 0
  br i1 %cond2023, label %bb_rcgclear263, label %bb_rcgcounted263
bb_rcgcounted263:
  %v2024 = load i64, ptr %slot225, align 8
  %op2025 = sub i64 %v2024, 32
  store i64 %op2025, ptr %slot231, align 8
  %v2026 = load i64, ptr %slot225, align 8
  %p2027 = inttoptr i64 %v2026 to ptr
  %rgep2028 = getelementptr i8, ptr %p2027, i64 -32
  %ld2029 = load i64, ptr %rgep2028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2029, ptr %slot232, align 8
  %v2030 = load i64, ptr %slot232, align 8
  %op2031 = sub i64 %v2030, 1
  store i64 %op2031, ptr %slot233, align 8
  %v2032 = load i64, ptr %slot233, align 8
  %cmp2033 = icmp eq i64 %v2032, 0
  %cv2034 = zext i1 %cmp2033 to i32
  store i32 %cv2034, ptr %slot234, align 8
  %v2035 = load i32, ptr %slot234, align 8
  %cv2036 = zext i32 %v2035 to i64
  %cond2037 = icmp ne i64 %cv2036, 0
  br i1 %cond2037, label %bb_rcglast263, label %bb_rcgdec263
bb_rcglast263:
  %v2038 = load i64, ptr %slot225, align 8
  %op2039 = sub i64 %v2038, 24
  store i64 %op2039, ptr %slot235, align 8
  %v2040 = load i64, ptr %slot225, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %rgep2042 = getelementptr i8, ptr %p2041, i64 -24
  %ld2043 = load i64, ptr %rgep2042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2043, ptr %slot236, align 8
  %v2044 = load i64, ptr %slot236, align 8
  %cmp2045 = icmp ne i64 %v2044, 0
  %cv2046 = zext i1 %cmp2045 to i32
  store i32 %cv2046, ptr %slot237, align 8
  %v2047 = load i32, ptr %slot237, align 8
  %cv2048 = zext i32 %v2047 to i64
  %cond2049 = icmp ne i64 %cv2048, 0
  br i1 %cond2049, label %bb_rcgdec263, label %bb_rcgslow263
bb_rcgslow263:
  %v2050 = load i64, ptr %slot224, align 8
  %v2051 = load i64, ptr %slot207, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2050, i64 %v2051) nomerge, !dbg !118
  br label %bb_rcgdone263
bb_rcgdec263:
  %v2052 = load i64, ptr %slot233, align 8
  %v2053 = load i64, ptr %slot225, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  %rgep2055 = getelementptr i8, ptr %p2054, i64 -32
  store i64 %v2052, ptr %rgep2055, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear263
bb_rcgclear263:
  %v2056 = load i64, ptr %slot207, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  store i64 0, ptr %p2057, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone263
bb_rcgdone263:
  br label %bb_rcslotdone232
bb_rcslotdone232:
  br label %bb_rcprepared178
bb_rcprepared178:
  %v2058 = load i64, ptr %slot10, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  %ld2060 = load i32, ptr %p2059, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2060, ptr %slot238, align 8
  %v2061 = load i32, ptr %slot238, align 8
  %cv2062 = zext i32 %v2061 to i64
  %cond2063 = icmp ne i64 %cv2062, 0
  br i1 %cond2063, label %bb_rcslotdrop270, label %bb_rcslotdone270
bb_rcslotdrop270:
  %v2064 = load i64, ptr %slot10, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  store i32 0, ptr %p2065, align 4, !alias.scope !3, !noalias !4
  %v2066 = load i64, ptr %slot33, align 8
  store i64 %v2066, ptr %slot239, align 8
  %v2067 = load i64, ptr %slot11, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %ld2069 = load i32, ptr %p2068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2069, ptr %slot240, align 8
  %v2070 = load i32, ptr %slot240, align 8
  %op2071 = and i32 %v2070, 28
  store i32 %op2071, ptr %slot241, align 8
  %v2072 = load i32, ptr %slot241, align 8
  %cv2073 = zext i32 %v2072 to i64
  %cond2074 = icmp ne i64 %cv2073, 0
  br i1 %cond2074, label %bb_rcslotrole270, label %bb_rcslotowner270
bb_rcslotrole270:
  %v2075 = load i64, ptr %slot46, align 8
  store i64 %v2075, ptr %slot242, align 8
  %v2076 = load i64, ptr %slot239, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  %ld2078 = load i64, ptr %p2077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2078, ptr %slot243, align 8
  %v2079 = load i64, ptr %slot243, align 8
  %cmp2080 = icmp ne i64 %v2079, 0
  %cv2081 = zext i1 %cmp2080 to i32
  store i32 %cv2081, ptr %slot244, align 8
  %v2082 = load i32, ptr %slot244, align 8
  %cv2083 = zext i32 %v2082 to i64
  %cond2084 = icmp ne i64 %cv2083, 0
  br i1 %cond2084, label %bb_rcgnn286, label %bb_rcgdone286
bb_rcgnn286:
  %v2085 = load i64, ptr %slot243, align 8
  %op2086 = sub i64 %v2085, 16
  store i64 %op2086, ptr %slot245, align 8
  %v2087 = load i64, ptr %slot243, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  %rgep2089 = getelementptr i8, ptr %p2088, i64 -16
  %ld2090 = load i64, ptr %rgep2089, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2090, ptr %slot246, align 8
  %v2091 = load i64, ptr %slot246, align 8
  %op2092 = and i64 %v2091, 4611686018427387906
  store i64 %op2092, ptr %slot247, align 8
  %v2093 = load i64, ptr %slot247, align 8
  %cmp2094 = icmp ne i64 %v2093, 0
  %cv2095 = zext i1 %cmp2094 to i32
  store i32 %cv2095, ptr %slot248, align 8
  %v2096 = load i32, ptr %slot248, align 8
  %cv2097 = zext i32 %v2096 to i64
  %cond2098 = icmp ne i64 %cv2097, 0
  br i1 %cond2098, label %bb_rcgclear286, label %bb_rcgcounted286
bb_rcgcounted286:
  %v2099 = load i64, ptr %slot243, align 8
  %op2100 = sub i64 %v2099, 24
  store i64 %op2100, ptr %slot249, align 8
  %v2101 = load i64, ptr %slot243, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  %rgep2103 = getelementptr i8, ptr %p2102, i64 -24
  %ld2104 = load i64, ptr %rgep2103, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2104, ptr %slot250, align 8
  %v2105 = load i64, ptr %slot250, align 8
  %op2106 = sub i64 %v2105, 1
  store i64 %op2106, ptr %slot251, align 8
  %v2107 = load i64, ptr %slot251, align 8
  %cmp2108 = icmp eq i64 %v2107, 0
  %cv2109 = zext i1 %cmp2108 to i32
  store i32 %cv2109, ptr %slot252, align 8
  %v2110 = load i32, ptr %slot252, align 8
  %cv2111 = zext i32 %v2110 to i64
  %cond2112 = icmp ne i64 %cv2111, 0
  br i1 %cond2112, label %bb_rcglast286, label %bb_rcgdec286
bb_rcglast286:
  %v2113 = load i64, ptr %slot243, align 8
  %op2114 = sub i64 %v2113, 32
  store i64 %op2114, ptr %slot253, align 8
  %v2115 = load i64, ptr %slot243, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  %rgep2117 = getelementptr i8, ptr %p2116, i64 -32
  %ld2118 = load i64, ptr %rgep2117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2118, ptr %slot254, align 8
  %v2119 = load i64, ptr %slot254, align 8
  %cmp2120 = icmp ne i64 %v2119, 0
  %cv2121 = zext i1 %cmp2120 to i32
  store i32 %cv2121, ptr %slot255, align 8
  %v2122 = load i32, ptr %slot255, align 8
  %cv2123 = zext i32 %v2122 to i64
  %cond2124 = icmp ne i64 %cv2123, 0
  br i1 %cond2124, label %bb_rcgdec286, label %bb_rcgslow286
bb_rcgslow286:
  %v2125 = load i64, ptr %slot242, align 8
  %v2126 = load i64, ptr %slot239, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2125, i64 %v2126) nomerge, !dbg !118
  br label %bb_rcgdone286
bb_rcgdec286:
  %v2127 = load i64, ptr %slot251, align 8
  %v2128 = load i64, ptr %slot243, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  %rgep2130 = getelementptr i8, ptr %p2129, i64 -24
  store i64 %v2127, ptr %rgep2130, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear286
bb_rcgclear286:
  %v2131 = load i64, ptr %slot239, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  store i64 0, ptr %p2132, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone286
bb_rcgdone286:
  br label %bb_rcslotdone270
bb_rcslotowner270:
  %v2133 = load i64, ptr %slot46, align 8
  store i64 %v2133, ptr %slot256, align 8
  %v2134 = load i64, ptr %slot239, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  %ld2136 = load i64, ptr %p2135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2136, ptr %slot257, align 8
  %v2137 = load i64, ptr %slot257, align 8
  %cmp2138 = icmp ne i64 %v2137, 0
  %cv2139 = zext i1 %cmp2138 to i32
  store i32 %cv2139, ptr %slot258, align 8
  %v2140 = load i32, ptr %slot258, align 8
  %cv2141 = zext i32 %v2140 to i64
  %cond2142 = icmp ne i64 %cv2141, 0
  br i1 %cond2142, label %bb_rcgnn301, label %bb_rcgdone301
bb_rcgnn301:
  %v2143 = load i64, ptr %slot257, align 8
  %op2144 = sub i64 %v2143, 16
  store i64 %op2144, ptr %slot259, align 8
  %v2145 = load i64, ptr %slot257, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  %rgep2147 = getelementptr i8, ptr %p2146, i64 -16
  %ld2148 = load i64, ptr %rgep2147, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2148, ptr %slot260, align 8
  %v2149 = load i64, ptr %slot260, align 8
  %op2150 = and i64 %v2149, 4611686018427387906
  store i64 %op2150, ptr %slot261, align 8
  %v2151 = load i64, ptr %slot261, align 8
  %cmp2152 = icmp ne i64 %v2151, 0
  %cv2153 = zext i1 %cmp2152 to i32
  store i32 %cv2153, ptr %slot262, align 8
  %v2154 = load i32, ptr %slot262, align 8
  %cv2155 = zext i32 %v2154 to i64
  %cond2156 = icmp ne i64 %cv2155, 0
  br i1 %cond2156, label %bb_rcgclear301, label %bb_rcgcounted301
bb_rcgcounted301:
  %v2157 = load i64, ptr %slot257, align 8
  %op2158 = sub i64 %v2157, 32
  store i64 %op2158, ptr %slot263, align 8
  %v2159 = load i64, ptr %slot257, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  %rgep2161 = getelementptr i8, ptr %p2160, i64 -32
  %ld2162 = load i64, ptr %rgep2161, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2162, ptr %slot264, align 8
  %v2163 = load i64, ptr %slot264, align 8
  %op2164 = sub i64 %v2163, 1
  store i64 %op2164, ptr %slot265, align 8
  %v2165 = load i64, ptr %slot265, align 8
  %cmp2166 = icmp eq i64 %v2165, 0
  %cv2167 = zext i1 %cmp2166 to i32
  store i32 %cv2167, ptr %slot266, align 8
  %v2168 = load i32, ptr %slot266, align 8
  %cv2169 = zext i32 %v2168 to i64
  %cond2170 = icmp ne i64 %cv2169, 0
  br i1 %cond2170, label %bb_rcglast301, label %bb_rcgdec301
bb_rcglast301:
  %v2171 = load i64, ptr %slot257, align 8
  %op2172 = sub i64 %v2171, 24
  store i64 %op2172, ptr %slot267, align 8
  %v2173 = load i64, ptr %slot257, align 8
  %p2174 = inttoptr i64 %v2173 to ptr
  %rgep2175 = getelementptr i8, ptr %p2174, i64 -24
  %ld2176 = load i64, ptr %rgep2175, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2176, ptr %slot268, align 8
  %v2177 = load i64, ptr %slot268, align 8
  %cmp2178 = icmp ne i64 %v2177, 0
  %cv2179 = zext i1 %cmp2178 to i32
  store i32 %cv2179, ptr %slot269, align 8
  %v2180 = load i32, ptr %slot269, align 8
  %cv2181 = zext i32 %v2180 to i64
  %cond2182 = icmp ne i64 %cv2181, 0
  br i1 %cond2182, label %bb_rcgdec301, label %bb_rcgslow301
bb_rcgslow301:
  %v2183 = load i64, ptr %slot256, align 8
  %v2184 = load i64, ptr %slot239, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2183, i64 %v2184) nomerge, !dbg !118
  br label %bb_rcgdone301
bb_rcgdec301:
  %v2185 = load i64, ptr %slot265, align 8
  %v2186 = load i64, ptr %slot257, align 8
  %p2187 = inttoptr i64 %v2186 to ptr
  %rgep2188 = getelementptr i8, ptr %p2187, i64 -32
  store i64 %v2185, ptr %rgep2188, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear301
bb_rcgclear301:
  %v2189 = load i64, ptr %slot239, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  store i64 0, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone301
bb_rcgdone301:
  br label %bb_rcslotdone270
bb_rcslotdone270:
  %v2191 = load i64, ptr %slot33, align 8
  store i64 %v2191, ptr %slot270, align 8
  %v2192 = load i64, ptr %slot26, align 8
  store i64 %v2192, ptr %slot271, align 8
  %v2193 = load i64, ptr %slot271, align 8
  %v2194 = load i64, ptr %slot270, align 8
  %p2195 = inttoptr i64 %v2193 to ptr
  %p2196 = inttoptr i64 %v2194 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2196, ptr %p2195, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2197 = load i64, ptr %slot20, align 8
  %p2198 = inttoptr i64 %v2197 to ptr
  store i32 0, ptr %p2198, align 4, !alias.scope !3, !noalias !4
  %v2199 = load i64, ptr %slot11, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  store i32 2, ptr %p2200, align 4, !alias.scope !3, !noalias !4
  %v2201 = load i64, ptr %slot21, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  %ld2203 = load i32, ptr %p2202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2203, ptr %slot272, align 8
  %v2204 = load i32, ptr %slot272, align 8
  %v2205 = load i64, ptr %slot11, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  store i32 %v2204, ptr %p2206, align 4, !alias.scope !3, !noalias !4
  %v2207 = load i64, ptr %slot10, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  store i32 1, ptr %p2208, align 4, !alias.scope !3, !noalias !4
  %v2209 = load i64, ptr %slot8, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  %ld2211 = load i32, ptr %p2210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2211, ptr %slot273, align 8
  %v2212 = load i32, ptr %slot273, align 8
  %cv2213 = zext i32 %v2212 to i64
  %cond2214 = icmp ne i64 %cv2213, 0
  br i1 %cond2214, label %bb_rcslotdrop314, label %bb_rcslotdone314
bb_rcslotdrop314:
  %v2215 = load i64, ptr %slot8, align 8
  %p2216 = inttoptr i64 %v2215 to ptr
  store i32 0, ptr %p2216, align 4, !alias.scope !3, !noalias !4
  %v2217 = load i64, ptr %slot32, align 8
  store i64 %v2217, ptr %slot274, align 8
  %v2218 = load i64, ptr %slot9, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  %ld2220 = load i32, ptr %p2219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2220, ptr %slot275, align 8
  %v2221 = load i32, ptr %slot275, align 8
  %op2222 = and i32 %v2221, 28
  store i32 %op2222, ptr %slot276, align 8
  %v2223 = load i32, ptr %slot276, align 8
  %cv2224 = zext i32 %v2223 to i64
  %cond2225 = icmp ne i64 %cv2224, 0
  br i1 %cond2225, label %bb_rcslotrole314, label %bb_rcslotowner314
bb_rcslotrole314:
  %v2226 = load i64, ptr %slot46, align 8
  store i64 %v2226, ptr %slot277, align 8
  %v2227 = load i64, ptr %slot274, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  %ld2229 = load i64, ptr %p2228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2229, ptr %slot278, align 8
  %v2230 = load i64, ptr %slot278, align 8
  %cmp2231 = icmp ne i64 %v2230, 0
  %cv2232 = zext i1 %cmp2231 to i32
  store i32 %cv2232, ptr %slot279, align 8
  %v2233 = load i32, ptr %slot279, align 8
  %cv2234 = zext i32 %v2233 to i64
  %cond2235 = icmp ne i64 %cv2234, 0
  br i1 %cond2235, label %bb_rcgnn330, label %bb_rcgdone330
bb_rcgnn330:
  %v2236 = load i64, ptr %slot278, align 8
  %op2237 = sub i64 %v2236, 16
  store i64 %op2237, ptr %slot280, align 8
  %v2238 = load i64, ptr %slot278, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  %rgep2240 = getelementptr i8, ptr %p2239, i64 -16
  %ld2241 = load i64, ptr %rgep2240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2241, ptr %slot281, align 8
  %v2242 = load i64, ptr %slot281, align 8
  %op2243 = and i64 %v2242, 4611686018427387906
  store i64 %op2243, ptr %slot282, align 8
  %v2244 = load i64, ptr %slot282, align 8
  %cmp2245 = icmp ne i64 %v2244, 0
  %cv2246 = zext i1 %cmp2245 to i32
  store i32 %cv2246, ptr %slot283, align 8
  %v2247 = load i32, ptr %slot283, align 8
  %cv2248 = zext i32 %v2247 to i64
  %cond2249 = icmp ne i64 %cv2248, 0
  br i1 %cond2249, label %bb_rcgclear330, label %bb_rcgcounted330
bb_rcgcounted330:
  %v2250 = load i64, ptr %slot278, align 8
  %op2251 = sub i64 %v2250, 24
  store i64 %op2251, ptr %slot284, align 8
  %v2252 = load i64, ptr %slot278, align 8
  %p2253 = inttoptr i64 %v2252 to ptr
  %rgep2254 = getelementptr i8, ptr %p2253, i64 -24
  %ld2255 = load i64, ptr %rgep2254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2255, ptr %slot285, align 8
  %v2256 = load i64, ptr %slot285, align 8
  %op2257 = sub i64 %v2256, 1
  store i64 %op2257, ptr %slot286, align 8
  %v2258 = load i64, ptr %slot286, align 8
  %cmp2259 = icmp eq i64 %v2258, 0
  %cv2260 = zext i1 %cmp2259 to i32
  store i32 %cv2260, ptr %slot287, align 8
  %v2261 = load i32, ptr %slot287, align 8
  %cv2262 = zext i32 %v2261 to i64
  %cond2263 = icmp ne i64 %cv2262, 0
  br i1 %cond2263, label %bb_rcglast330, label %bb_rcgdec330
bb_rcglast330:
  %v2264 = load i64, ptr %slot278, align 8
  %op2265 = sub i64 %v2264, 32
  store i64 %op2265, ptr %slot288, align 8
  %v2266 = load i64, ptr %slot278, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  %rgep2268 = getelementptr i8, ptr %p2267, i64 -32
  %ld2269 = load i64, ptr %rgep2268, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2269, ptr %slot289, align 8
  %v2270 = load i64, ptr %slot289, align 8
  %cmp2271 = icmp ne i64 %v2270, 0
  %cv2272 = zext i1 %cmp2271 to i32
  store i32 %cv2272, ptr %slot290, align 8
  %v2273 = load i32, ptr %slot290, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcgdec330, label %bb_rcgslow330
bb_rcgslow330:
  %v2276 = load i64, ptr %slot277, align 8
  %v2277 = load i64, ptr %slot274, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2276, i64 %v2277) nomerge, !dbg !118
  br label %bb_rcgdone330
bb_rcgdec330:
  %v2278 = load i64, ptr %slot286, align 8
  %v2279 = load i64, ptr %slot278, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  %rgep2281 = getelementptr i8, ptr %p2280, i64 -24
  store i64 %v2278, ptr %rgep2281, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear330
bb_rcgclear330:
  %v2282 = load i64, ptr %slot274, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  store i64 0, ptr %p2283, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone330
bb_rcgdone330:
  br label %bb_rcslotdone314
bb_rcslotowner314:
  %v2284 = load i64, ptr %slot46, align 8
  store i64 %v2284, ptr %slot291, align 8
  %v2285 = load i64, ptr %slot274, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %ld2287 = load i64, ptr %p2286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2287, ptr %slot292, align 8
  %v2288 = load i64, ptr %slot292, align 8
  %cmp2289 = icmp ne i64 %v2288, 0
  %cv2290 = zext i1 %cmp2289 to i32
  store i32 %cv2290, ptr %slot293, align 8
  %v2291 = load i32, ptr %slot293, align 8
  %cv2292 = zext i32 %v2291 to i64
  %cond2293 = icmp ne i64 %cv2292, 0
  br i1 %cond2293, label %bb_rcgnn345, label %bb_rcgdone345
bb_rcgnn345:
  %v2294 = load i64, ptr %slot292, align 8
  %op2295 = sub i64 %v2294, 16
  store i64 %op2295, ptr %slot294, align 8
  %v2296 = load i64, ptr %slot292, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %rgep2298 = getelementptr i8, ptr %p2297, i64 -16
  %ld2299 = load i64, ptr %rgep2298, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2299, ptr %slot295, align 8
  %v2300 = load i64, ptr %slot295, align 8
  %op2301 = and i64 %v2300, 4611686018427387906
  store i64 %op2301, ptr %slot296, align 8
  %v2302 = load i64, ptr %slot296, align 8
  %cmp2303 = icmp ne i64 %v2302, 0
  %cv2304 = zext i1 %cmp2303 to i32
  store i32 %cv2304, ptr %slot297, align 8
  %v2305 = load i32, ptr %slot297, align 8
  %cv2306 = zext i32 %v2305 to i64
  %cond2307 = icmp ne i64 %cv2306, 0
  br i1 %cond2307, label %bb_rcgclear345, label %bb_rcgcounted345
bb_rcgcounted345:
  %v2308 = load i64, ptr %slot292, align 8
  %op2309 = sub i64 %v2308, 32
  store i64 %op2309, ptr %slot298, align 8
  %v2310 = load i64, ptr %slot292, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  %rgep2312 = getelementptr i8, ptr %p2311, i64 -32
  %ld2313 = load i64, ptr %rgep2312, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2313, ptr %slot299, align 8
  %v2314 = load i64, ptr %slot299, align 8
  %op2315 = sub i64 %v2314, 1
  store i64 %op2315, ptr %slot300, align 8
  %v2316 = load i64, ptr %slot300, align 8
  %cmp2317 = icmp eq i64 %v2316, 0
  %cv2318 = zext i1 %cmp2317 to i32
  store i32 %cv2318, ptr %slot301, align 8
  %v2319 = load i32, ptr %slot301, align 8
  %cv2320 = zext i32 %v2319 to i64
  %cond2321 = icmp ne i64 %cv2320, 0
  br i1 %cond2321, label %bb_rcglast345, label %bb_rcgdec345
bb_rcglast345:
  %v2322 = load i64, ptr %slot292, align 8
  %op2323 = sub i64 %v2322, 24
  store i64 %op2323, ptr %slot302, align 8
  %v2324 = load i64, ptr %slot292, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %rgep2326 = getelementptr i8, ptr %p2325, i64 -24
  %ld2327 = load i64, ptr %rgep2326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2327, ptr %slot303, align 8
  %v2328 = load i64, ptr %slot303, align 8
  %cmp2329 = icmp ne i64 %v2328, 0
  %cv2330 = zext i1 %cmp2329 to i32
  store i32 %cv2330, ptr %slot304, align 8
  %v2331 = load i32, ptr %slot304, align 8
  %cv2332 = zext i32 %v2331 to i64
  %cond2333 = icmp ne i64 %cv2332, 0
  br i1 %cond2333, label %bb_rcgdec345, label %bb_rcgslow345
bb_rcgslow345:
  %v2334 = load i64, ptr %slot291, align 8
  %v2335 = load i64, ptr %slot274, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2334, i64 %v2335) nomerge, !dbg !118
  br label %bb_rcgdone345
bb_rcgdec345:
  %v2336 = load i64, ptr %slot300, align 8
  %v2337 = load i64, ptr %slot292, align 8
  %p2338 = inttoptr i64 %v2337 to ptr
  %rgep2339 = getelementptr i8, ptr %p2338, i64 -32
  store i64 %v2336, ptr %rgep2339, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear345
bb_rcgclear345:
  %v2340 = load i64, ptr %slot274, align 8
  %p2341 = inttoptr i64 %v2340 to ptr
  store i64 0, ptr %p2341, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone345
bb_rcgdone345:
  br label %bb_rcslotdone314
bb_rcslotdone314:
  %v2342 = load i64, ptr %slot33, align 8
  %p2343 = inttoptr i64 %v2342 to ptr
  %ld2344 = load i64, ptr %p2343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2344, ptr %slot305, align 8
  %v2345 = load i64, ptr %slot305, align 8
  %v2346 = load i64, ptr %slot37, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  store i64 %v2345, ptr %p2347, align 8, !alias.scope !3, !noalias !4
  %v2348 = load i64, ptr %slot37, align 8
  %p2349 = inttoptr i64 %v2348 to ptr
  %ld2350 = load i64, ptr %p2349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2350, ptr %slot306, align 8
  %v2351 = load i64, ptr %slot1, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %v2353 = load i64, ptr %slot306, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  %call2355 = call ptr @myl_qbe_bytes_from_list(ptr %p2352, ptr %p2354) nomerge, !dbg !120
  %calladdr2356 = ptrtoint ptr %call2355 to i64
  store i64 %calladdr2356, ptr %slot307, align 8
  %v2357 = load i64, ptr %slot307, align 8
  %v2358 = load i64, ptr %slot37, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  store i64 %v2357, ptr %p2359, align 8, !alias.scope !3, !noalias !4
  %v2360 = load i64, ptr %slot37, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  %ld2362 = load i64, ptr %p2361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2362, ptr %slot308, align 8
  %v2363 = load i64, ptr %slot308, align 8
  %v2364 = load i64, ptr %slot24, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  store i64 %v2363, ptr %p2365, align 8, !alias.scope !3, !noalias !4
  %v2366 = load i64, ptr %slot24, align 8
  store i64 %v2366, ptr %slot309, align 8
  %v2367 = load i64, ptr %slot26, align 8
  store i64 %v2367, ptr %slot310, align 8
  %v2368 = load i64, ptr %slot309, align 8
  %v2369 = load i64, ptr %slot310, align 8
  %p2370 = inttoptr i64 %v2368 to ptr
  %p2371 = inttoptr i64 %v2369 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2371, ptr %p2370, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2372 = load i64, ptr %slot21, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  store i32 2, ptr %p2373, align 4, !alias.scope !3, !noalias !4
  %v2374 = load i64, ptr %slot20, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  store i32 1, ptr %p2375, align 4, !alias.scope !3, !noalias !4
  %v2376 = load i64, ptr %slot16, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  %ld2378 = load i32, ptr %p2377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2378, ptr %slot311, align 8
  %v2379 = load i32, ptr %slot311, align 8
  %cv2380 = zext i32 %v2379 to i64
  %cond2381 = icmp ne i64 %cv2380, 0
  br i1 %cond2381, label %bb_rcslotdrop359, label %bb_rcslotdone359
bb_rcslotdrop359:
  %v2382 = load i64, ptr %slot16, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  store i32 0, ptr %p2383, align 4, !alias.scope !3, !noalias !4
  %v2384 = load i64, ptr %slot22, align 8
  store i64 %v2384, ptr %slot312, align 8
  %v2385 = load i64, ptr %slot17, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  %ld2387 = load i32, ptr %p2386, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2387, ptr %slot313, align 8
  %v2388 = load i32, ptr %slot313, align 8
  %op2389 = and i32 %v2388, 28
  store i32 %op2389, ptr %slot314, align 8
  %v2390 = load i32, ptr %slot314, align 8
  %cv2391 = zext i32 %v2390 to i64
  %cond2392 = icmp ne i64 %cv2391, 0
  br i1 %cond2392, label %bb_rcslotrole359, label %bb_rcslotowner359
bb_rcslotrole359:
  %v2393 = load i64, ptr %slot46, align 8
  store i64 %v2393, ptr %slot315, align 8
  %v2394 = load i64, ptr %slot312, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %ld2396 = load i64, ptr %p2395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2396, ptr %slot316, align 8
  %v2397 = load i64, ptr %slot316, align 8
  %cmp2398 = icmp ne i64 %v2397, 0
  %cv2399 = zext i1 %cmp2398 to i32
  store i32 %cv2399, ptr %slot317, align 8
  %v2400 = load i32, ptr %slot317, align 8
  %cv2401 = zext i32 %v2400 to i64
  %cond2402 = icmp ne i64 %cv2401, 0
  br i1 %cond2402, label %bb_rcgnn375, label %bb_rcgdone375
bb_rcgnn375:
  %v2403 = load i64, ptr %slot316, align 8
  %op2404 = sub i64 %v2403, 16
  store i64 %op2404, ptr %slot318, align 8
  %v2405 = load i64, ptr %slot316, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  %rgep2407 = getelementptr i8, ptr %p2406, i64 -16
  %ld2408 = load i64, ptr %rgep2407, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2408, ptr %slot319, align 8
  %v2409 = load i64, ptr %slot319, align 8
  %op2410 = and i64 %v2409, 4611686018427387906
  store i64 %op2410, ptr %slot320, align 8
  %v2411 = load i64, ptr %slot320, align 8
  %cmp2412 = icmp ne i64 %v2411, 0
  %cv2413 = zext i1 %cmp2412 to i32
  store i32 %cv2413, ptr %slot321, align 8
  %v2414 = load i32, ptr %slot321, align 8
  %cv2415 = zext i32 %v2414 to i64
  %cond2416 = icmp ne i64 %cv2415, 0
  br i1 %cond2416, label %bb_rcgclear375, label %bb_rcgcounted375
bb_rcgcounted375:
  %v2417 = load i64, ptr %slot316, align 8
  %op2418 = sub i64 %v2417, 24
  store i64 %op2418, ptr %slot322, align 8
  %v2419 = load i64, ptr %slot316, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  %rgep2421 = getelementptr i8, ptr %p2420, i64 -24
  %ld2422 = load i64, ptr %rgep2421, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2422, ptr %slot323, align 8
  %v2423 = load i64, ptr %slot323, align 8
  %op2424 = sub i64 %v2423, 1
  store i64 %op2424, ptr %slot324, align 8
  %v2425 = load i64, ptr %slot324, align 8
  %cmp2426 = icmp eq i64 %v2425, 0
  %cv2427 = zext i1 %cmp2426 to i32
  store i32 %cv2427, ptr %slot325, align 8
  %v2428 = load i32, ptr %slot325, align 8
  %cv2429 = zext i32 %v2428 to i64
  %cond2430 = icmp ne i64 %cv2429, 0
  br i1 %cond2430, label %bb_rcglast375, label %bb_rcgdec375
bb_rcglast375:
  %v2431 = load i64, ptr %slot316, align 8
  %op2432 = sub i64 %v2431, 32
  store i64 %op2432, ptr %slot326, align 8
  %v2433 = load i64, ptr %slot316, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  %rgep2435 = getelementptr i8, ptr %p2434, i64 -32
  %ld2436 = load i64, ptr %rgep2435, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2436, ptr %slot327, align 8
  %v2437 = load i64, ptr %slot327, align 8
  %cmp2438 = icmp ne i64 %v2437, 0
  %cv2439 = zext i1 %cmp2438 to i32
  store i32 %cv2439, ptr %slot328, align 8
  %v2440 = load i32, ptr %slot328, align 8
  %cv2441 = zext i32 %v2440 to i64
  %cond2442 = icmp ne i64 %cv2441, 0
  br i1 %cond2442, label %bb_rcgdec375, label %bb_rcgslow375
bb_rcgslow375:
  %v2443 = load i64, ptr %slot315, align 8
  %v2444 = load i64, ptr %slot312, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2443, i64 %v2444) nomerge, !dbg !120
  br label %bb_rcgdone375
bb_rcgdec375:
  %v2445 = load i64, ptr %slot324, align 8
  %v2446 = load i64, ptr %slot316, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  %rgep2448 = getelementptr i8, ptr %p2447, i64 -24
  store i64 %v2445, ptr %rgep2448, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear375
bb_rcgclear375:
  %v2449 = load i64, ptr %slot312, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  store i64 0, ptr %p2450, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone375
bb_rcgdone375:
  br label %bb_rcslotdone359
bb_rcslotowner359:
  %v2451 = load i64, ptr %slot46, align 8
  store i64 %v2451, ptr %slot329, align 8
  %v2452 = load i64, ptr %slot312, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  %ld2454 = load i64, ptr %p2453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2454, ptr %slot330, align 8
  %v2455 = load i64, ptr %slot330, align 8
  %cmp2456 = icmp ne i64 %v2455, 0
  %cv2457 = zext i1 %cmp2456 to i32
  store i32 %cv2457, ptr %slot331, align 8
  %v2458 = load i32, ptr %slot331, align 8
  %cv2459 = zext i32 %v2458 to i64
  %cond2460 = icmp ne i64 %cv2459, 0
  br i1 %cond2460, label %bb_rcgnn390, label %bb_rcgdone390
bb_rcgnn390:
  %v2461 = load i64, ptr %slot330, align 8
  %op2462 = sub i64 %v2461, 16
  store i64 %op2462, ptr %slot332, align 8
  %v2463 = load i64, ptr %slot330, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  %rgep2465 = getelementptr i8, ptr %p2464, i64 -16
  %ld2466 = load i64, ptr %rgep2465, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2466, ptr %slot333, align 8
  %v2467 = load i64, ptr %slot333, align 8
  %op2468 = and i64 %v2467, 4611686018427387906
  store i64 %op2468, ptr %slot334, align 8
  %v2469 = load i64, ptr %slot334, align 8
  %cmp2470 = icmp ne i64 %v2469, 0
  %cv2471 = zext i1 %cmp2470 to i32
  store i32 %cv2471, ptr %slot335, align 8
  %v2472 = load i32, ptr %slot335, align 8
  %cv2473 = zext i32 %v2472 to i64
  %cond2474 = icmp ne i64 %cv2473, 0
  br i1 %cond2474, label %bb_rcgclear390, label %bb_rcgcounted390
bb_rcgcounted390:
  %v2475 = load i64, ptr %slot330, align 8
  %op2476 = sub i64 %v2475, 32
  store i64 %op2476, ptr %slot336, align 8
  %v2477 = load i64, ptr %slot330, align 8
  %p2478 = inttoptr i64 %v2477 to ptr
  %rgep2479 = getelementptr i8, ptr %p2478, i64 -32
  %ld2480 = load i64, ptr %rgep2479, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2480, ptr %slot337, align 8
  %v2481 = load i64, ptr %slot337, align 8
  %op2482 = sub i64 %v2481, 1
  store i64 %op2482, ptr %slot338, align 8
  %v2483 = load i64, ptr %slot338, align 8
  %cmp2484 = icmp eq i64 %v2483, 0
  %cv2485 = zext i1 %cmp2484 to i32
  store i32 %cv2485, ptr %slot339, align 8
  %v2486 = load i32, ptr %slot339, align 8
  %cv2487 = zext i32 %v2486 to i64
  %cond2488 = icmp ne i64 %cv2487, 0
  br i1 %cond2488, label %bb_rcglast390, label %bb_rcgdec390
bb_rcglast390:
  %v2489 = load i64, ptr %slot330, align 8
  %op2490 = sub i64 %v2489, 24
  store i64 %op2490, ptr %slot340, align 8
  %v2491 = load i64, ptr %slot330, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  %rgep2493 = getelementptr i8, ptr %p2492, i64 -24
  %ld2494 = load i64, ptr %rgep2493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2494, ptr %slot341, align 8
  %v2495 = load i64, ptr %slot341, align 8
  %cmp2496 = icmp ne i64 %v2495, 0
  %cv2497 = zext i1 %cmp2496 to i32
  store i32 %cv2497, ptr %slot342, align 8
  %v2498 = load i32, ptr %slot342, align 8
  %cv2499 = zext i32 %v2498 to i64
  %cond2500 = icmp ne i64 %cv2499, 0
  br i1 %cond2500, label %bb_rcgdec390, label %bb_rcgslow390
bb_rcgslow390:
  %v2501 = load i64, ptr %slot329, align 8
  %v2502 = load i64, ptr %slot312, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2501, i64 %v2502) nomerge, !dbg !120
  br label %bb_rcgdone390
bb_rcgdec390:
  %v2503 = load i64, ptr %slot338, align 8
  %v2504 = load i64, ptr %slot330, align 8
  %p2505 = inttoptr i64 %v2504 to ptr
  %rgep2506 = getelementptr i8, ptr %p2505, i64 -32
  store i64 %v2503, ptr %rgep2506, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear390
bb_rcgclear390:
  %v2507 = load i64, ptr %slot312, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  store i64 0, ptr %p2508, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone390
bb_rcgdone390:
  br label %bb_rcslotdone359
bb_rcslotdone359:
  %v2509 = load i64, ptr %slot22, align 8
  store i64 %v2509, ptr %slot343, align 8
  %v2510 = load i64, ptr %slot26, align 8
  store i64 %v2510, ptr %slot344, align 8
  %v2511 = load i64, ptr %slot344, align 8
  %v2512 = load i64, ptr %slot343, align 8
  %p2513 = inttoptr i64 %v2511 to ptr
  %p2514 = inttoptr i64 %v2512 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2514, ptr %p2513, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2515 = load i64, ptr %slot17, align 8
  %p2516 = inttoptr i64 %v2515 to ptr
  store i32 2, ptr %p2516, align 4, !alias.scope !3, !noalias !4
  %v2517 = load i64, ptr %slot21, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  %ld2519 = load i32, ptr %p2518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2519, ptr %slot345, align 8
  %v2520 = load i32, ptr %slot345, align 8
  %v2521 = load i64, ptr %slot17, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i32 %v2520, ptr %p2522, align 4, !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot20, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  store i32 0, ptr %p2524, align 4, !alias.scope !3, !noalias !4
  %v2525 = load i64, ptr %slot16, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  store i32 1, ptr %p2526, align 4, !alias.scope !3, !noalias !4
  %v2527 = load i64, ptr %slot343, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  %ld2529 = load i64, ptr %p2528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2529, ptr %slot346, align 8
  %v2530 = load i64, ptr %slot346, align 8
  %v2531 = load i64, ptr %slot37, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  store i64 %v2530, ptr %p2532, align 8, !alias.scope !3, !noalias !4
  %v2533 = load i64, ptr %slot37, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  %ld2535 = load i64, ptr %p2534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2535, ptr %slot347, align 8
  %v2536 = load i64, ptr %slot347, align 8
  %v2537 = load i64, ptr %slot24, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i64 %v2536, ptr %p2538, align 8, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot24, align 8
  store i64 %v2539, ptr %slot348, align 8
  %v2540 = load i64, ptr %slot16, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  %ld2542 = load i32, ptr %p2541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2542, ptr %slot349, align 8
  %v2543 = load i64, ptr %slot17, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  %ld2545 = load i32, ptr %p2544, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2545, ptr %slot350, align 8
  %v2546 = load i32, ptr %slot350, align 8
  %op2547 = and i32 %v2546, 24
  store i32 %op2547, ptr %slot350, align 8
  %v2548 = load i32, ptr %slot350, align 8
  %cmp2549 = icmp eq i32 %v2548, 0
  %cv2550 = zext i1 %cmp2549 to i32
  store i32 %cv2550, ptr %slot351, align 8
  %v2551 = load i32, ptr %slot349, align 8
  %v2552 = load i32, ptr %slot351, align 8
  %op2553 = and i32 %v2551, %v2552
  store i32 %op2553, ptr %slot352, align 8
  %v2554 = load i32, ptr %slot352, align 8
  %cv2555 = zext i32 %v2554 to i64
  %cond2556 = icmp ne i64 %cv2555, 0
  br i1 %cond2556, label %bb_rctake405, label %bb_rccopy405
bb_rctake405:
  %v2557 = load i64, ptr %slot26, align 8
  store i64 %v2557, ptr %slot353, align 8
  %v2558 = load i64, ptr %slot47, align 8
  store i64 %v2558, ptr %slot354, align 8
  %v2559 = load i64, ptr %slot348, align 8
  %v2560 = load i64, ptr %slot353, align 8
  %op2561 = sub i64 %v2559, %v2560
  store i64 %op2561, ptr %slot355, align 8
  %v2562 = load i64, ptr %slot353, align 8
  %v2563 = load i64, ptr %slot348, align 8
  %op2564 = sub i64 %v2562, %v2563
  store i64 %op2564, ptr %slot356, align 8
  %v2565 = load i64, ptr %slot355, align 8
  %cmp2566 = icmp ult i64 %v2565, 8
  %cv2567 = zext i1 %cmp2566 to i32
  store i32 %cv2567, ptr %slot357, align 8
  %v2568 = load i64, ptr %slot356, align 8
  %cmp2569 = icmp ult i64 %v2568, 8
  %cv2570 = zext i1 %cmp2569 to i32
  store i32 %cv2570, ptr %slot358, align 8
  %v2571 = load i32, ptr %slot357, align 8
  %v2572 = load i32, ptr %slot358, align 8
  %op2573 = or i32 %v2571, %v2572
  store i32 %op2573, ptr %slot359, align 8
  %v2574 = load i32, ptr %slot359, align 8
  %cv2575 = zext i32 %v2574 to i64
  %cond2576 = icmp ne i64 %cv2575, 0
  br i1 %cond2576, label %bb_rcmoveslow414, label %bb_rcmovecheck414
bb_rcmovecheck414:
  %v2577 = load i64, ptr %slot348, align 8
  %p2579 = inttoptr i64 %v2577 to ptr
  %gep2580 = getelementptr i8, ptr %p2579, i64 0
  %op2578 = ptrtoint ptr %gep2580 to i64
  store i64 %op2578, ptr %slot360, align 8
  %v2581 = load i64, ptr %slot360, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  %ld2583 = load i64, ptr %p2582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2583, ptr %slot361, align 8
  %v2584 = load i64, ptr %slot361, align 8
  %cmp2585 = icmp ne i64 %v2584, 0
  %cv2586 = zext i1 %cmp2585 to i32
  store i32 %cv2586, ptr %slot362, align 8
  %v2587 = load i32, ptr %slot362, align 8
  %cv2588 = zext i32 %v2587 to i64
  %cond2589 = icmp ne i64 %cv2588, 0
  br i1 %cond2589, label %bb_rcmoveheader422, label %bb_rcmovenext422
bb_rcmoveheader422:
  %v2590 = load i64, ptr %slot361, align 8
  %op2591 = sub i64 %v2590, 16
  store i64 %op2591, ptr %slot363, align 8
  %v2592 = load i64, ptr %slot361, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  %rgep2594 = getelementptr i8, ptr %p2593, i64 -16
  %ld2595 = load i64, ptr %rgep2594, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2595, ptr %slot364, align 8
  %v2596 = load i64, ptr %slot364, align 8
  %op2597 = and i64 %v2596, 5764607523034234881
  store i64 %op2597, ptr %slot365, align 8
  %v2598 = load i64, ptr %slot365, align 8
  %cmp2599 = icmp ne i64 %v2598, 0
  %cv2600 = zext i1 %cmp2599 to i32
  store i32 %cv2600, ptr %slot366, align 8
  %v2601 = load i32, ptr %slot366, align 8
  %cv2602 = zext i32 %v2601 to i64
  %cond2603 = icmp ne i64 %cv2602, 0
  br i1 %cond2603, label %bb_rcmoveslow414, label %bb_rcmovenext422
bb_rcmovenext422:
  %v2604 = load i64, ptr %slot348, align 8
  %v2605 = load i64, ptr %slot353, align 8
  %p2606 = inttoptr i64 %v2604 to ptr
  %p2607 = inttoptr i64 %v2605 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2607, ptr %p2606, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2608 = load i64, ptr %slot348, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  store i64 0, ptr %p2609, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved414
bb_rcmoveslow414:
  %v2610 = load i64, ptr %slot46, align 8
  %v2611 = load i64, ptr %slot353, align 8
  %v2612 = load i64, ptr %slot348, align 8
  %v2613 = load i64, ptr %slot354, align 8
  %cv2614 = trunc i64 %v2613 to i32
  %call2615 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v2610, i64 %v2611, i64 %v2612, i32 %cv2614) nomerge, !dbg !122
  store i32 %call2615, ptr %slot367, align 8
  %v2616 = load i32, ptr %slot367, align 8
  %cv2617 = zext i32 %v2616 to i64
  %cond2618 = icmp ne i64 %cv2617, 0
  br i1 %cond2618, label %bb_rcsuccess429, label %bb_rcfailure429
bb_rcfailure429:
  %v2619 = load i64, ptr %slot46, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  %call2621 = call i32 @myl_rc_take_failure(ptr %p2620) nomerge, !dbg !122
  store i32 %call2621, ptr %slot368, align 8
  %v2622 = load i64, ptr %slot1, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %v2624 = load i32, ptr %slot368, align 8
  %call2625 = call i32 @myl_qbe_rc_status(ptr %p2623, i32 %v2624) nomerge, !dbg !122
  store i32 %call2625, ptr %slot369, align 8
  br label %bb_failure
bb_rcsuccess429:
  br label %bb_rcmoved414
bb_rcmoved414:
  %v2626 = load i64, ptr %slot16, align 8
  %p2627 = inttoptr i64 %v2626 to ptr
  store i32 0, ptr %p2627, align 4, !alias.scope !3, !noalias !4
  %v2628 = load i64, ptr %slot21, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  store i32 2, ptr %p2629, align 4, !alias.scope !3, !noalias !4
  %v2630 = load i64, ptr %slot20, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  store i32 1, ptr %p2631, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared405
bb_rccopy405:
  %v2632 = load i64, ptr %slot26, align 8
  store i64 %v2632, ptr %slot370, align 8
  %v2633 = load i64, ptr %slot47, align 8
  store i64 %v2633, ptr %slot371, align 8
  %v2634 = load i64, ptr %slot348, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  %ld2636 = load i64, ptr %p2635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2636, ptr %slot372, align 8
  %v2637 = load i64, ptr %slot372, align 8
  %cmp2638 = icmp ne i64 %v2637, 0
  %cv2639 = zext i1 %cmp2638 to i32
  store i32 %cv2639, ptr %slot373, align 8
  %v2640 = load i32, ptr %slot373, align 8
  %cv2641 = zext i32 %v2640 to i64
  %cond2642 = icmp ne i64 %cv2641, 0
  br i1 %cond2642, label %bb_rcgnn438, label %bb_rcgplain438
bb_rcgnn438:
  %v2643 = load i64, ptr %slot372, align 8
  %op2644 = sub i64 %v2643, 16
  store i64 %op2644, ptr %slot374, align 8
  %v2645 = load i64, ptr %slot372, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  %rgep2647 = getelementptr i8, ptr %p2646, i64 -16
  %ld2648 = load i64, ptr %rgep2647, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2648, ptr %slot375, align 8
  %v2649 = load i64, ptr %slot375, align 8
  %op2650 = and i64 %v2649, 4611686018427387906
  store i64 %op2650, ptr %slot376, align 8
  %v2651 = load i64, ptr %slot376, align 8
  %cmp2652 = icmp ne i64 %v2651, 0
  %cv2653 = zext i1 %cmp2652 to i32
  store i32 %cv2653, ptr %slot377, align 8
  %v2654 = load i32, ptr %slot377, align 8
  %cv2655 = zext i32 %v2654 to i64
  %cond2656 = icmp ne i64 %cv2655, 0
  br i1 %cond2656, label %bb_rcgspecial438, label %bb_rcginc438
bb_rcginc438:
  %v2657 = load i64, ptr %slot372, align 8
  %op2658 = sub i64 %v2657, 32
  store i64 %op2658, ptr %slot378, align 8
  %v2659 = load i64, ptr %slot372, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  %rgep2661 = getelementptr i8, ptr %p2660, i64 -32
  %ld2662 = load i64, ptr %rgep2661, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2662, ptr %slot379, align 8
  %v2663 = load i64, ptr %slot379, align 8
  %op2664 = add i64 %v2663, 1
  store i64 %op2664, ptr %slot380, align 8
  %v2665 = load i64, ptr %slot380, align 8
  %cmp2666 = icmp eq i64 %v2665, 0
  %cv2667 = zext i1 %cmp2666 to i32
  store i32 %cv2667, ptr %slot381, align 8
  %v2668 = load i32, ptr %slot381, align 8
  %cv2669 = zext i32 %v2668 to i64
  %cond2670 = icmp ne i64 %cv2669, 0
  br i1 %cond2670, label %bb_rcglimit438, label %bb_rcgcapacity438
bb_rcglimit438:
  %v2671 = load i64, ptr %slot1, align 8
  %p2672 = inttoptr i64 %v2671 to ptr
  %call2673 = call i32 @myl_qbe_rc_status(ptr %p2672, i32 2) nomerge, !dbg !122
  store i32 %call2673, ptr %slot382, align 8
  br label %bb_failure
bb_rcgcapacity438:
  %v2674 = load i64, ptr %slot380, align 8
  %v2675 = load i64, ptr %slot372, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  %rgep2677 = getelementptr i8, ptr %p2676, i64 -32
  store i64 %v2674, ptr %rgep2677, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain438
bb_rcgspecial438:
  %v2678 = load i64, ptr %slot375, align 8
  %op2679 = and i64 %v2678, 4611686018427387904
  store i64 %op2679, ptr %slot383, align 8
  %v2680 = load i64, ptr %slot383, align 8
  %cmp2681 = icmp ne i64 %v2680, 0
  %cv2682 = zext i1 %cmp2681 to i32
  store i32 %cv2682, ptr %slot384, align 8
  %v2683 = load i32, ptr %slot384, align 8
  %cv2684 = zext i32 %v2683 to i64
  %cond2685 = icmp ne i64 %cv2684, 0
  br i1 %cond2685, label %bb_rcgslow438, label %bb_rcgplain438
bb_rcgslow438:
  %v2686 = load i64, ptr %slot46, align 8
  %v2687 = load i64, ptr %slot370, align 8
  %v2688 = load i64, ptr %slot348, align 8
  %v2689 = load i64, ptr %slot371, align 8
  %cv2690 = trunc i64 %v2689 to i32
  %call2691 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64 %v2686, i64 %v2687, i64 %v2688, i32 %cv2690) nomerge, !dbg !122
  store i32 %call2691, ptr %slot385, align 8
  %v2692 = load i32, ptr %slot385, align 8
  %cv2693 = zext i32 %v2692 to i64
  %cond2694 = icmp ne i64 %cv2693, 0
  br i1 %cond2694, label %bb_rcsuccess452, label %bb_rcfailure452
bb_rcfailure452:
  %v2695 = load i64, ptr %slot46, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  %call2697 = call i32 @myl_rc_take_failure(ptr %p2696) nomerge, !dbg !122
  store i32 %call2697, ptr %slot386, align 8
  %v2698 = load i64, ptr %slot1, align 8
  %p2699 = inttoptr i64 %v2698 to ptr
  %v2700 = load i32, ptr %slot386, align 8
  %call2701 = call i32 @myl_qbe_rc_status(ptr %p2699, i32 %v2700) nomerge, !dbg !122
  store i32 %call2701, ptr %slot387, align 8
  br label %bb_failure
bb_rcsuccess452:
  br label %bb_rcgdone438
bb_rcgplain438:
  %v2702 = load i64, ptr %slot372, align 8
  %v2703 = load i64, ptr %slot370, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  store i64 %v2702, ptr %p2704, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone438
bb_rcgdone438:
  %v2705 = load i64, ptr %slot21, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  store i32 2, ptr %p2706, align 4, !alias.scope !3, !noalias !4
  %v2707 = load i64, ptr %slot20, align 8
  %p2708 = inttoptr i64 %v2707 to ptr
  store i32 1, ptr %p2708, align 4, !alias.scope !3, !noalias !4
  %v2709 = load i64, ptr %slot16, align 8
  %p2710 = inttoptr i64 %v2709 to ptr
  %ld2711 = load i32, ptr %p2710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2711, ptr %slot388, align 8
  %v2712 = load i32, ptr %slot388, align 8
  %cv2713 = zext i32 %v2712 to i64
  %cond2714 = icmp ne i64 %cv2713, 0
  br i1 %cond2714, label %bb_rcslotdrop459, label %bb_rcslotdone459
bb_rcslotdrop459:
  %v2715 = load i64, ptr %slot16, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  store i32 0, ptr %p2716, align 4, !alias.scope !3, !noalias !4
  %v2717 = load i64, ptr %slot22, align 8
  store i64 %v2717, ptr %slot389, align 8
  %v2718 = load i64, ptr %slot17, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  %ld2720 = load i32, ptr %p2719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2720, ptr %slot390, align 8
  %v2721 = load i32, ptr %slot390, align 8
  %op2722 = and i32 %v2721, 28
  store i32 %op2722, ptr %slot391, align 8
  %v2723 = load i32, ptr %slot391, align 8
  %cv2724 = zext i32 %v2723 to i64
  %cond2725 = icmp ne i64 %cv2724, 0
  br i1 %cond2725, label %bb_rcslotrole459, label %bb_rcslotowner459
bb_rcslotrole459:
  %v2726 = load i64, ptr %slot46, align 8
  store i64 %v2726, ptr %slot392, align 8
  %v2727 = load i64, ptr %slot389, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  %ld2729 = load i64, ptr %p2728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2729, ptr %slot393, align 8
  %v2730 = load i64, ptr %slot393, align 8
  %cmp2731 = icmp ne i64 %v2730, 0
  %cv2732 = zext i1 %cmp2731 to i32
  store i32 %cv2732, ptr %slot394, align 8
  %v2733 = load i32, ptr %slot394, align 8
  %cv2734 = zext i32 %v2733 to i64
  %cond2735 = icmp ne i64 %cv2734, 0
  br i1 %cond2735, label %bb_rcgnn475, label %bb_rcgdone475
bb_rcgnn475:
  %v2736 = load i64, ptr %slot393, align 8
  %op2737 = sub i64 %v2736, 16
  store i64 %op2737, ptr %slot395, align 8
  %v2738 = load i64, ptr %slot393, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %rgep2740 = getelementptr i8, ptr %p2739, i64 -16
  %ld2741 = load i64, ptr %rgep2740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2741, ptr %slot396, align 8
  %v2742 = load i64, ptr %slot396, align 8
  %op2743 = and i64 %v2742, 4611686018427387906
  store i64 %op2743, ptr %slot397, align 8
  %v2744 = load i64, ptr %slot397, align 8
  %cmp2745 = icmp ne i64 %v2744, 0
  %cv2746 = zext i1 %cmp2745 to i32
  store i32 %cv2746, ptr %slot398, align 8
  %v2747 = load i32, ptr %slot398, align 8
  %cv2748 = zext i32 %v2747 to i64
  %cond2749 = icmp ne i64 %cv2748, 0
  br i1 %cond2749, label %bb_rcgclear475, label %bb_rcgcounted475
bb_rcgcounted475:
  %v2750 = load i64, ptr %slot393, align 8
  %op2751 = sub i64 %v2750, 24
  store i64 %op2751, ptr %slot399, align 8
  %v2752 = load i64, ptr %slot393, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %rgep2754 = getelementptr i8, ptr %p2753, i64 -24
  %ld2755 = load i64, ptr %rgep2754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2755, ptr %slot400, align 8
  %v2756 = load i64, ptr %slot400, align 8
  %op2757 = sub i64 %v2756, 1
  store i64 %op2757, ptr %slot401, align 8
  %v2758 = load i64, ptr %slot401, align 8
  %cmp2759 = icmp eq i64 %v2758, 0
  %cv2760 = zext i1 %cmp2759 to i32
  store i32 %cv2760, ptr %slot402, align 8
  %v2761 = load i32, ptr %slot402, align 8
  %cv2762 = zext i32 %v2761 to i64
  %cond2763 = icmp ne i64 %cv2762, 0
  br i1 %cond2763, label %bb_rcglast475, label %bb_rcgdec475
bb_rcglast475:
  %v2764 = load i64, ptr %slot393, align 8
  %op2765 = sub i64 %v2764, 32
  store i64 %op2765, ptr %slot403, align 8
  %v2766 = load i64, ptr %slot393, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  %rgep2768 = getelementptr i8, ptr %p2767, i64 -32
  %ld2769 = load i64, ptr %rgep2768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2769, ptr %slot404, align 8
  %v2770 = load i64, ptr %slot404, align 8
  %cmp2771 = icmp ne i64 %v2770, 0
  %cv2772 = zext i1 %cmp2771 to i32
  store i32 %cv2772, ptr %slot405, align 8
  %v2773 = load i32, ptr %slot405, align 8
  %cv2774 = zext i32 %v2773 to i64
  %cond2775 = icmp ne i64 %cv2774, 0
  br i1 %cond2775, label %bb_rcgdec475, label %bb_rcgslow475
bb_rcgslow475:
  %v2776 = load i64, ptr %slot392, align 8
  %v2777 = load i64, ptr %slot389, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2776, i64 %v2777) nomerge, !dbg !122
  br label %bb_rcgdone475
bb_rcgdec475:
  %v2778 = load i64, ptr %slot401, align 8
  %v2779 = load i64, ptr %slot393, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  %rgep2781 = getelementptr i8, ptr %p2780, i64 -24
  store i64 %v2778, ptr %rgep2781, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear475
bb_rcgclear475:
  %v2782 = load i64, ptr %slot389, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i64 0, ptr %p2783, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone475
bb_rcgdone475:
  br label %bb_rcslotdone459
bb_rcslotowner459:
  %v2784 = load i64, ptr %slot46, align 8
  store i64 %v2784, ptr %slot406, align 8
  %v2785 = load i64, ptr %slot389, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  %ld2787 = load i64, ptr %p2786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2787, ptr %slot407, align 8
  %v2788 = load i64, ptr %slot407, align 8
  %cmp2789 = icmp ne i64 %v2788, 0
  %cv2790 = zext i1 %cmp2789 to i32
  store i32 %cv2790, ptr %slot408, align 8
  %v2791 = load i32, ptr %slot408, align 8
  %cv2792 = zext i32 %v2791 to i64
  %cond2793 = icmp ne i64 %cv2792, 0
  br i1 %cond2793, label %bb_rcgnn490, label %bb_rcgdone490
bb_rcgnn490:
  %v2794 = load i64, ptr %slot407, align 8
  %op2795 = sub i64 %v2794, 16
  store i64 %op2795, ptr %slot409, align 8
  %v2796 = load i64, ptr %slot407, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  %rgep2798 = getelementptr i8, ptr %p2797, i64 -16
  %ld2799 = load i64, ptr %rgep2798, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2799, ptr %slot410, align 8
  %v2800 = load i64, ptr %slot410, align 8
  %op2801 = and i64 %v2800, 4611686018427387906
  store i64 %op2801, ptr %slot411, align 8
  %v2802 = load i64, ptr %slot411, align 8
  %cmp2803 = icmp ne i64 %v2802, 0
  %cv2804 = zext i1 %cmp2803 to i32
  store i32 %cv2804, ptr %slot412, align 8
  %v2805 = load i32, ptr %slot412, align 8
  %cv2806 = zext i32 %v2805 to i64
  %cond2807 = icmp ne i64 %cv2806, 0
  br i1 %cond2807, label %bb_rcgclear490, label %bb_rcgcounted490
bb_rcgcounted490:
  %v2808 = load i64, ptr %slot407, align 8
  %op2809 = sub i64 %v2808, 32
  store i64 %op2809, ptr %slot413, align 8
  %v2810 = load i64, ptr %slot407, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  %rgep2812 = getelementptr i8, ptr %p2811, i64 -32
  %ld2813 = load i64, ptr %rgep2812, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2813, ptr %slot414, align 8
  %v2814 = load i64, ptr %slot414, align 8
  %op2815 = sub i64 %v2814, 1
  store i64 %op2815, ptr %slot415, align 8
  %v2816 = load i64, ptr %slot415, align 8
  %cmp2817 = icmp eq i64 %v2816, 0
  %cv2818 = zext i1 %cmp2817 to i32
  store i32 %cv2818, ptr %slot416, align 8
  %v2819 = load i32, ptr %slot416, align 8
  %cv2820 = zext i32 %v2819 to i64
  %cond2821 = icmp ne i64 %cv2820, 0
  br i1 %cond2821, label %bb_rcglast490, label %bb_rcgdec490
bb_rcglast490:
  %v2822 = load i64, ptr %slot407, align 8
  %op2823 = sub i64 %v2822, 24
  store i64 %op2823, ptr %slot417, align 8
  %v2824 = load i64, ptr %slot407, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  %rgep2826 = getelementptr i8, ptr %p2825, i64 -24
  %ld2827 = load i64, ptr %rgep2826, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2827, ptr %slot418, align 8
  %v2828 = load i64, ptr %slot418, align 8
  %cmp2829 = icmp ne i64 %v2828, 0
  %cv2830 = zext i1 %cmp2829 to i32
  store i32 %cv2830, ptr %slot419, align 8
  %v2831 = load i32, ptr %slot419, align 8
  %cv2832 = zext i32 %v2831 to i64
  %cond2833 = icmp ne i64 %cv2832, 0
  br i1 %cond2833, label %bb_rcgdec490, label %bb_rcgslow490
bb_rcgslow490:
  %v2834 = load i64, ptr %slot406, align 8
  %v2835 = load i64, ptr %slot389, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2834, i64 %v2835) nomerge, !dbg !122
  br label %bb_rcgdone490
bb_rcgdec490:
  %v2836 = load i64, ptr %slot415, align 8
  %v2837 = load i64, ptr %slot407, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  %rgep2839 = getelementptr i8, ptr %p2838, i64 -32
  store i64 %v2836, ptr %rgep2839, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear490
bb_rcgclear490:
  %v2840 = load i64, ptr %slot389, align 8
  %p2841 = inttoptr i64 %v2840 to ptr
  store i64 0, ptr %p2841, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone490
bb_rcgdone490:
  br label %bb_rcslotdone459
bb_rcslotdone459:
  br label %bb_rcprepared405
bb_rcprepared405:
  %v2842 = load i64, ptr %slot12, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  %ld2844 = load i32, ptr %p2843, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2844, ptr %slot420, align 8
  %v2845 = load i32, ptr %slot420, align 8
  %cv2846 = zext i32 %v2845 to i64
  %cond2847 = icmp ne i64 %cv2846, 0
  br i1 %cond2847, label %bb_rcslotdrop497, label %bb_rcslotdone497
bb_rcslotdrop497:
  %v2848 = load i64, ptr %slot12, align 8
  %p2849 = inttoptr i64 %v2848 to ptr
  store i32 0, ptr %p2849, align 4, !alias.scope !3, !noalias !4
  %v2850 = load i64, ptr %slot34, align 8
  store i64 %v2850, ptr %slot421, align 8
  %v2851 = load i64, ptr %slot13, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  %ld2853 = load i32, ptr %p2852, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2853, ptr %slot422, align 8
  %v2854 = load i32, ptr %slot422, align 8
  %op2855 = and i32 %v2854, 28
  store i32 %op2855, ptr %slot423, align 8
  %v2856 = load i32, ptr %slot423, align 8
  %cv2857 = zext i32 %v2856 to i64
  %cond2858 = icmp ne i64 %cv2857, 0
  br i1 %cond2858, label %bb_rcslotrole497, label %bb_rcslotowner497
bb_rcslotrole497:
  %v2859 = load i64, ptr %slot46, align 8
  store i64 %v2859, ptr %slot424, align 8
  %v2860 = load i64, ptr %slot421, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  %ld2862 = load i64, ptr %p2861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2862, ptr %slot425, align 8
  %v2863 = load i64, ptr %slot425, align 8
  %cmp2864 = icmp ne i64 %v2863, 0
  %cv2865 = zext i1 %cmp2864 to i32
  store i32 %cv2865, ptr %slot426, align 8
  %v2866 = load i32, ptr %slot426, align 8
  %cv2867 = zext i32 %v2866 to i64
  %cond2868 = icmp ne i64 %cv2867, 0
  br i1 %cond2868, label %bb_rcgnn513, label %bb_rcgdone513
bb_rcgnn513:
  %v2869 = load i64, ptr %slot425, align 8
  %op2870 = sub i64 %v2869, 16
  store i64 %op2870, ptr %slot427, align 8
  %v2871 = load i64, ptr %slot425, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  %rgep2873 = getelementptr i8, ptr %p2872, i64 -16
  %ld2874 = load i64, ptr %rgep2873, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2874, ptr %slot428, align 8
  %v2875 = load i64, ptr %slot428, align 8
  %op2876 = and i64 %v2875, 4611686018427387906
  store i64 %op2876, ptr %slot429, align 8
  %v2877 = load i64, ptr %slot429, align 8
  %cmp2878 = icmp ne i64 %v2877, 0
  %cv2879 = zext i1 %cmp2878 to i32
  store i32 %cv2879, ptr %slot430, align 8
  %v2880 = load i32, ptr %slot430, align 8
  %cv2881 = zext i32 %v2880 to i64
  %cond2882 = icmp ne i64 %cv2881, 0
  br i1 %cond2882, label %bb_rcgclear513, label %bb_rcgcounted513
bb_rcgcounted513:
  %v2883 = load i64, ptr %slot425, align 8
  %op2884 = sub i64 %v2883, 24
  store i64 %op2884, ptr %slot431, align 8
  %v2885 = load i64, ptr %slot425, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  %rgep2887 = getelementptr i8, ptr %p2886, i64 -24
  %ld2888 = load i64, ptr %rgep2887, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2888, ptr %slot432, align 8
  %v2889 = load i64, ptr %slot432, align 8
  %op2890 = sub i64 %v2889, 1
  store i64 %op2890, ptr %slot433, align 8
  %v2891 = load i64, ptr %slot433, align 8
  %cmp2892 = icmp eq i64 %v2891, 0
  %cv2893 = zext i1 %cmp2892 to i32
  store i32 %cv2893, ptr %slot434, align 8
  %v2894 = load i32, ptr %slot434, align 8
  %cv2895 = zext i32 %v2894 to i64
  %cond2896 = icmp ne i64 %cv2895, 0
  br i1 %cond2896, label %bb_rcglast513, label %bb_rcgdec513
bb_rcglast513:
  %v2897 = load i64, ptr %slot425, align 8
  %op2898 = sub i64 %v2897, 32
  store i64 %op2898, ptr %slot435, align 8
  %v2899 = load i64, ptr %slot425, align 8
  %p2900 = inttoptr i64 %v2899 to ptr
  %rgep2901 = getelementptr i8, ptr %p2900, i64 -32
  %ld2902 = load i64, ptr %rgep2901, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2902, ptr %slot436, align 8
  %v2903 = load i64, ptr %slot436, align 8
  %cmp2904 = icmp ne i64 %v2903, 0
  %cv2905 = zext i1 %cmp2904 to i32
  store i32 %cv2905, ptr %slot437, align 8
  %v2906 = load i32, ptr %slot437, align 8
  %cv2907 = zext i32 %v2906 to i64
  %cond2908 = icmp ne i64 %cv2907, 0
  br i1 %cond2908, label %bb_rcgdec513, label %bb_rcgslow513
bb_rcgslow513:
  %v2909 = load i64, ptr %slot424, align 8
  %v2910 = load i64, ptr %slot421, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2909, i64 %v2910) nomerge, !dbg !122
  br label %bb_rcgdone513
bb_rcgdec513:
  %v2911 = load i64, ptr %slot433, align 8
  %v2912 = load i64, ptr %slot425, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  %rgep2914 = getelementptr i8, ptr %p2913, i64 -24
  store i64 %v2911, ptr %rgep2914, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear513
bb_rcgclear513:
  %v2915 = load i64, ptr %slot421, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  store i64 0, ptr %p2916, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone513
bb_rcgdone513:
  br label %bb_rcslotdone497
bb_rcslotowner497:
  %v2917 = load i64, ptr %slot46, align 8
  store i64 %v2917, ptr %slot438, align 8
  %v2918 = load i64, ptr %slot421, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  %ld2920 = load i64, ptr %p2919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2920, ptr %slot439, align 8
  %v2921 = load i64, ptr %slot439, align 8
  %cmp2922 = icmp ne i64 %v2921, 0
  %cv2923 = zext i1 %cmp2922 to i32
  store i32 %cv2923, ptr %slot440, align 8
  %v2924 = load i32, ptr %slot440, align 8
  %cv2925 = zext i32 %v2924 to i64
  %cond2926 = icmp ne i64 %cv2925, 0
  br i1 %cond2926, label %bb_rcgnn528, label %bb_rcgdone528
bb_rcgnn528:
  %v2927 = load i64, ptr %slot439, align 8
  %op2928 = sub i64 %v2927, 16
  store i64 %op2928, ptr %slot441, align 8
  %v2929 = load i64, ptr %slot439, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  %rgep2931 = getelementptr i8, ptr %p2930, i64 -16
  %ld2932 = load i64, ptr %rgep2931, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2932, ptr %slot442, align 8
  %v2933 = load i64, ptr %slot442, align 8
  %op2934 = and i64 %v2933, 4611686018427387906
  store i64 %op2934, ptr %slot443, align 8
  %v2935 = load i64, ptr %slot443, align 8
  %cmp2936 = icmp ne i64 %v2935, 0
  %cv2937 = zext i1 %cmp2936 to i32
  store i32 %cv2937, ptr %slot444, align 8
  %v2938 = load i32, ptr %slot444, align 8
  %cv2939 = zext i32 %v2938 to i64
  %cond2940 = icmp ne i64 %cv2939, 0
  br i1 %cond2940, label %bb_rcgclear528, label %bb_rcgcounted528
bb_rcgcounted528:
  %v2941 = load i64, ptr %slot439, align 8
  %op2942 = sub i64 %v2941, 32
  store i64 %op2942, ptr %slot445, align 8
  %v2943 = load i64, ptr %slot439, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  %rgep2945 = getelementptr i8, ptr %p2944, i64 -32
  %ld2946 = load i64, ptr %rgep2945, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2946, ptr %slot446, align 8
  %v2947 = load i64, ptr %slot446, align 8
  %op2948 = sub i64 %v2947, 1
  store i64 %op2948, ptr %slot447, align 8
  %v2949 = load i64, ptr %slot447, align 8
  %cmp2950 = icmp eq i64 %v2949, 0
  %cv2951 = zext i1 %cmp2950 to i32
  store i32 %cv2951, ptr %slot448, align 8
  %v2952 = load i32, ptr %slot448, align 8
  %cv2953 = zext i32 %v2952 to i64
  %cond2954 = icmp ne i64 %cv2953, 0
  br i1 %cond2954, label %bb_rcglast528, label %bb_rcgdec528
bb_rcglast528:
  %v2955 = load i64, ptr %slot439, align 8
  %op2956 = sub i64 %v2955, 24
  store i64 %op2956, ptr %slot449, align 8
  %v2957 = load i64, ptr %slot439, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  %rgep2959 = getelementptr i8, ptr %p2958, i64 -24
  %ld2960 = load i64, ptr %rgep2959, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2960, ptr %slot450, align 8
  %v2961 = load i64, ptr %slot450, align 8
  %cmp2962 = icmp ne i64 %v2961, 0
  %cv2963 = zext i1 %cmp2962 to i32
  store i32 %cv2963, ptr %slot451, align 8
  %v2964 = load i32, ptr %slot451, align 8
  %cv2965 = zext i32 %v2964 to i64
  %cond2966 = icmp ne i64 %cv2965, 0
  br i1 %cond2966, label %bb_rcgdec528, label %bb_rcgslow528
bb_rcgslow528:
  %v2967 = load i64, ptr %slot438, align 8
  %v2968 = load i64, ptr %slot421, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2967, i64 %v2968) nomerge, !dbg !122
  br label %bb_rcgdone528
bb_rcgdec528:
  %v2969 = load i64, ptr %slot447, align 8
  %v2970 = load i64, ptr %slot439, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  %rgep2972 = getelementptr i8, ptr %p2971, i64 -32
  store i64 %v2969, ptr %rgep2972, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear528
bb_rcgclear528:
  %v2973 = load i64, ptr %slot421, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  store i64 0, ptr %p2974, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone528
bb_rcgdone528:
  br label %bb_rcslotdone497
bb_rcslotdone497:
  %v2975 = load i64, ptr %slot34, align 8
  store i64 %v2975, ptr %slot452, align 8
  %v2976 = load i64, ptr %slot26, align 8
  store i64 %v2976, ptr %slot453, align 8
  %v2977 = load i64, ptr %slot453, align 8
  %v2978 = load i64, ptr %slot452, align 8
  %p2979 = inttoptr i64 %v2977 to ptr
  %p2980 = inttoptr i64 %v2978 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2980, ptr %p2979, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2981 = load i64, ptr %slot20, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  store i32 0, ptr %p2982, align 4, !alias.scope !3, !noalias !4
  %v2983 = load i64, ptr %slot13, align 8
  %p2984 = inttoptr i64 %v2983 to ptr
  store i32 2, ptr %p2984, align 4, !alias.scope !3, !noalias !4
  %v2985 = load i64, ptr %slot21, align 8
  %p2986 = inttoptr i64 %v2985 to ptr
  %ld2987 = load i32, ptr %p2986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2987, ptr %slot454, align 8
  %v2988 = load i32, ptr %slot454, align 8
  %v2989 = load i64, ptr %slot13, align 8
  %p2990 = inttoptr i64 %v2989 to ptr
  store i32 %v2988, ptr %p2990, align 4, !alias.scope !3, !noalias !4
  %v2991 = load i64, ptr %slot12, align 8
  %p2992 = inttoptr i64 %v2991 to ptr
  store i32 1, ptr %p2992, align 4, !alias.scope !3, !noalias !4
  %v2993 = load i64, ptr %slot10, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  %ld2995 = load i32, ptr %p2994, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2995, ptr %slot455, align 8
  %v2996 = load i32, ptr %slot455, align 8
  %cv2997 = zext i32 %v2996 to i64
  %cond2998 = icmp ne i64 %cv2997, 0
  br i1 %cond2998, label %bb_rcslotdrop541, label %bb_rcslotdone541
bb_rcslotdrop541:
  %v2999 = load i64, ptr %slot10, align 8
  %p3000 = inttoptr i64 %v2999 to ptr
  store i32 0, ptr %p3000, align 4, !alias.scope !3, !noalias !4
  %v3001 = load i64, ptr %slot33, align 8
  store i64 %v3001, ptr %slot456, align 8
  %v3002 = load i64, ptr %slot11, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  %ld3004 = load i32, ptr %p3003, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3004, ptr %slot457, align 8
  %v3005 = load i32, ptr %slot457, align 8
  %op3006 = and i32 %v3005, 28
  store i32 %op3006, ptr %slot458, align 8
  %v3007 = load i32, ptr %slot458, align 8
  %cv3008 = zext i32 %v3007 to i64
  %cond3009 = icmp ne i64 %cv3008, 0
  br i1 %cond3009, label %bb_rcslotrole541, label %bb_rcslotowner541
bb_rcslotrole541:
  %v3010 = load i64, ptr %slot46, align 8
  store i64 %v3010, ptr %slot459, align 8
  %v3011 = load i64, ptr %slot456, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  %ld3013 = load i64, ptr %p3012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3013, ptr %slot460, align 8
  %v3014 = load i64, ptr %slot460, align 8
  %cmp3015 = icmp ne i64 %v3014, 0
  %cv3016 = zext i1 %cmp3015 to i32
  store i32 %cv3016, ptr %slot461, align 8
  %v3017 = load i32, ptr %slot461, align 8
  %cv3018 = zext i32 %v3017 to i64
  %cond3019 = icmp ne i64 %cv3018, 0
  br i1 %cond3019, label %bb_rcgnn557, label %bb_rcgdone557
bb_rcgnn557:
  %v3020 = load i64, ptr %slot460, align 8
  %op3021 = sub i64 %v3020, 16
  store i64 %op3021, ptr %slot462, align 8
  %v3022 = load i64, ptr %slot460, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  %rgep3024 = getelementptr i8, ptr %p3023, i64 -16
  %ld3025 = load i64, ptr %rgep3024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3025, ptr %slot463, align 8
  %v3026 = load i64, ptr %slot463, align 8
  %op3027 = and i64 %v3026, 4611686018427387906
  store i64 %op3027, ptr %slot464, align 8
  %v3028 = load i64, ptr %slot464, align 8
  %cmp3029 = icmp ne i64 %v3028, 0
  %cv3030 = zext i1 %cmp3029 to i32
  store i32 %cv3030, ptr %slot465, align 8
  %v3031 = load i32, ptr %slot465, align 8
  %cv3032 = zext i32 %v3031 to i64
  %cond3033 = icmp ne i64 %cv3032, 0
  br i1 %cond3033, label %bb_rcgclear557, label %bb_rcgcounted557
bb_rcgcounted557:
  %v3034 = load i64, ptr %slot460, align 8
  %op3035 = sub i64 %v3034, 24
  store i64 %op3035, ptr %slot466, align 8
  %v3036 = load i64, ptr %slot460, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  %rgep3038 = getelementptr i8, ptr %p3037, i64 -24
  %ld3039 = load i64, ptr %rgep3038, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3039, ptr %slot467, align 8
  %v3040 = load i64, ptr %slot467, align 8
  %op3041 = sub i64 %v3040, 1
  store i64 %op3041, ptr %slot468, align 8
  %v3042 = load i64, ptr %slot468, align 8
  %cmp3043 = icmp eq i64 %v3042, 0
  %cv3044 = zext i1 %cmp3043 to i32
  store i32 %cv3044, ptr %slot469, align 8
  %v3045 = load i32, ptr %slot469, align 8
  %cv3046 = zext i32 %v3045 to i64
  %cond3047 = icmp ne i64 %cv3046, 0
  br i1 %cond3047, label %bb_rcglast557, label %bb_rcgdec557
bb_rcglast557:
  %v3048 = load i64, ptr %slot460, align 8
  %op3049 = sub i64 %v3048, 32
  store i64 %op3049, ptr %slot470, align 8
  %v3050 = load i64, ptr %slot460, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %rgep3052 = getelementptr i8, ptr %p3051, i64 -32
  %ld3053 = load i64, ptr %rgep3052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3053, ptr %slot471, align 8
  %v3054 = load i64, ptr %slot471, align 8
  %cmp3055 = icmp ne i64 %v3054, 0
  %cv3056 = zext i1 %cmp3055 to i32
  store i32 %cv3056, ptr %slot472, align 8
  %v3057 = load i32, ptr %slot472, align 8
  %cv3058 = zext i32 %v3057 to i64
  %cond3059 = icmp ne i64 %cv3058, 0
  br i1 %cond3059, label %bb_rcgdec557, label %bb_rcgslow557
bb_rcgslow557:
  %v3060 = load i64, ptr %slot459, align 8
  %v3061 = load i64, ptr %slot456, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3060, i64 %v3061) nomerge, !dbg !122
  br label %bb_rcgdone557
bb_rcgdec557:
  %v3062 = load i64, ptr %slot468, align 8
  %v3063 = load i64, ptr %slot460, align 8
  %p3064 = inttoptr i64 %v3063 to ptr
  %rgep3065 = getelementptr i8, ptr %p3064, i64 -24
  store i64 %v3062, ptr %rgep3065, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear557
bb_rcgclear557:
  %v3066 = load i64, ptr %slot456, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  store i64 0, ptr %p3067, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone557
bb_rcgdone557:
  br label %bb_rcslotdone541
bb_rcslotowner541:
  %v3068 = load i64, ptr %slot46, align 8
  store i64 %v3068, ptr %slot473, align 8
  %v3069 = load i64, ptr %slot456, align 8
  %p3070 = inttoptr i64 %v3069 to ptr
  %ld3071 = load i64, ptr %p3070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3071, ptr %slot474, align 8
  %v3072 = load i64, ptr %slot474, align 8
  %cmp3073 = icmp ne i64 %v3072, 0
  %cv3074 = zext i1 %cmp3073 to i32
  store i32 %cv3074, ptr %slot475, align 8
  %v3075 = load i32, ptr %slot475, align 8
  %cv3076 = zext i32 %v3075 to i64
  %cond3077 = icmp ne i64 %cv3076, 0
  br i1 %cond3077, label %bb_rcgnn572, label %bb_rcgdone572
bb_rcgnn572:
  %v3078 = load i64, ptr %slot474, align 8
  %op3079 = sub i64 %v3078, 16
  store i64 %op3079, ptr %slot476, align 8
  %v3080 = load i64, ptr %slot474, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  %rgep3082 = getelementptr i8, ptr %p3081, i64 -16
  %ld3083 = load i64, ptr %rgep3082, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3083, ptr %slot477, align 8
  %v3084 = load i64, ptr %slot477, align 8
  %op3085 = and i64 %v3084, 4611686018427387906
  store i64 %op3085, ptr %slot478, align 8
  %v3086 = load i64, ptr %slot478, align 8
  %cmp3087 = icmp ne i64 %v3086, 0
  %cv3088 = zext i1 %cmp3087 to i32
  store i32 %cv3088, ptr %slot479, align 8
  %v3089 = load i32, ptr %slot479, align 8
  %cv3090 = zext i32 %v3089 to i64
  %cond3091 = icmp ne i64 %cv3090, 0
  br i1 %cond3091, label %bb_rcgclear572, label %bb_rcgcounted572
bb_rcgcounted572:
  %v3092 = load i64, ptr %slot474, align 8
  %op3093 = sub i64 %v3092, 32
  store i64 %op3093, ptr %slot480, align 8
  %v3094 = load i64, ptr %slot474, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  %rgep3096 = getelementptr i8, ptr %p3095, i64 -32
  %ld3097 = load i64, ptr %rgep3096, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3097, ptr %slot481, align 8
  %v3098 = load i64, ptr %slot481, align 8
  %op3099 = sub i64 %v3098, 1
  store i64 %op3099, ptr %slot482, align 8
  %v3100 = load i64, ptr %slot482, align 8
  %cmp3101 = icmp eq i64 %v3100, 0
  %cv3102 = zext i1 %cmp3101 to i32
  store i32 %cv3102, ptr %slot483, align 8
  %v3103 = load i32, ptr %slot483, align 8
  %cv3104 = zext i32 %v3103 to i64
  %cond3105 = icmp ne i64 %cv3104, 0
  br i1 %cond3105, label %bb_rcglast572, label %bb_rcgdec572
bb_rcglast572:
  %v3106 = load i64, ptr %slot474, align 8
  %op3107 = sub i64 %v3106, 24
  store i64 %op3107, ptr %slot484, align 8
  %v3108 = load i64, ptr %slot474, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  %rgep3110 = getelementptr i8, ptr %p3109, i64 -24
  %ld3111 = load i64, ptr %rgep3110, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3111, ptr %slot485, align 8
  %v3112 = load i64, ptr %slot485, align 8
  %cmp3113 = icmp ne i64 %v3112, 0
  %cv3114 = zext i1 %cmp3113 to i32
  store i32 %cv3114, ptr %slot486, align 8
  %v3115 = load i32, ptr %slot486, align 8
  %cv3116 = zext i32 %v3115 to i64
  %cond3117 = icmp ne i64 %cv3116, 0
  br i1 %cond3117, label %bb_rcgdec572, label %bb_rcgslow572
bb_rcgslow572:
  %v3118 = load i64, ptr %slot473, align 8
  %v3119 = load i64, ptr %slot456, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3118, i64 %v3119) nomerge, !dbg !122
  br label %bb_rcgdone572
bb_rcgdec572:
  %v3120 = load i64, ptr %slot482, align 8
  %v3121 = load i64, ptr %slot474, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  %rgep3123 = getelementptr i8, ptr %p3122, i64 -32
  store i64 %v3120, ptr %rgep3123, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear572
bb_rcgclear572:
  %v3124 = load i64, ptr %slot456, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  store i64 0, ptr %p3125, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone572
bb_rcgdone572:
  br label %bb_rcslotdone541
bb_rcslotdone541:
  %p3126 = inttoptr i64 ptrtoint (ptr @myl_lit_5662f6395b11b677b0daae7bfe3ecb88b069643a0ef5f974b5bbee38efae20c0 to i64) to ptr
  %ld3127 = load i64, ptr %p3126, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3127, ptr %slot487, align 8
  %v3128 = load i64, ptr %slot487, align 8
  %v3129 = load i64, ptr %slot37, align 8
  %p3130 = inttoptr i64 %v3129 to ptr
  store i64 %v3128, ptr %p3130, align 8, !alias.scope !3, !noalias !4
  %v3131 = load i64, ptr %slot37, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  %ld3133 = load i64, ptr %p3132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3133, ptr %slot488, align 8
  %v3134 = load i64, ptr %slot488, align 8
  %v3135 = load i64, ptr %slot24, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  store i64 %v3134, ptr %p3136, align 8, !alias.scope !3, !noalias !4
  %v3137 = load i64, ptr %slot24, align 8
  store i64 %v3137, ptr %slot489, align 8
  %v3138 = load i64, ptr %slot26, align 8
  store i64 %v3138, ptr %slot490, align 8
  %v3139 = load i64, ptr %slot489, align 8
  %v3140 = load i64, ptr %slot490, align 8
  %p3141 = inttoptr i64 %v3139 to ptr
  %p3142 = inttoptr i64 %v3140 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3142, ptr %p3141, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3143 = load i64, ptr %slot21, align 8
  %p3144 = inttoptr i64 %v3143 to ptr
  store i32 2, ptr %p3144, align 4, !alias.scope !3, !noalias !4
  %v3145 = load i64, ptr %slot20, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  store i32 1, ptr %p3146, align 4, !alias.scope !3, !noalias !4
  %v3147 = load i64, ptr %slot22, align 8
  store i64 %v3147, ptr %slot491, align 8
  %v3148 = load i64, ptr %slot26, align 8
  store i64 %v3148, ptr %slot492, align 8
  %v3149 = load i64, ptr %slot492, align 8
  %v3150 = load i64, ptr %slot491, align 8
  %p3151 = inttoptr i64 %v3149 to ptr
  %p3152 = inttoptr i64 %v3150 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3152, ptr %p3151, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3153 = load i64, ptr %slot17, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  store i32 2, ptr %p3154, align 4, !alias.scope !3, !noalias !4
  %v3155 = load i64, ptr %slot21, align 8
  %p3156 = inttoptr i64 %v3155 to ptr
  %ld3157 = load i32, ptr %p3156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3157, ptr %slot493, align 8
  %v3158 = load i32, ptr %slot493, align 8
  %v3159 = load i64, ptr %slot17, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  store i32 %v3158, ptr %p3160, align 4, !alias.scope !3, !noalias !4
  %v3161 = load i64, ptr %slot20, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  store i32 0, ptr %p3162, align 4, !alias.scope !3, !noalias !4
  %v3163 = load i64, ptr %slot16, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  store i32 1, ptr %p3164, align 4, !alias.scope !3, !noalias !4
  %v3165 = load i64, ptr %slot491, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %ld3167 = load i64, ptr %p3166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3167, ptr %slot494, align 8
  %v3168 = load i64, ptr %slot494, align 8
  %v3169 = load i64, ptr %slot37, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  store i64 %v3168, ptr %p3170, align 8, !alias.scope !3, !noalias !4
  %v3171 = load i64, ptr %slot34, align 8
  store i64 %v3171, ptr %slot495, align 8
  %v3172 = load i64, ptr %slot13, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  store i32 2, ptr %p3173, align 4, !alias.scope !3, !noalias !4
  %v3174 = load i64, ptr %slot495, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  %ld3176 = load i64, ptr %p3175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3176, ptr %slot496, align 8
  %v3177 = load i64, ptr %slot496, align 8
  %cmp3178 = icmp ne i64 %v3177, 0
  %cv3179 = zext i1 %cmp3178 to i32
  store i32 %cv3179, ptr %slot497, align 8
  %v3180 = load i32, ptr %slot497, align 8
  %cv3181 = zext i32 %v3180 to i64
  %cond3182 = icmp ne i64 %cv3181, 0
  br i1 %cond3182, label %bb_rcguniquenn595, label %bb_rcgunique595
bb_rcguniquenn595:
  %v3183 = load i64, ptr %slot496, align 8
  %op3184 = sub i64 %v3183, 16
  store i64 %op3184, ptr %slot498, align 8
  %v3185 = load i64, ptr %slot496, align 8
  %p3186 = inttoptr i64 %v3185 to ptr
  %rgep3187 = getelementptr i8, ptr %p3186, i64 -16
  %ld3188 = load i64, ptr %rgep3187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3188, ptr %slot499, align 8
  %v3189 = load i64, ptr %slot499, align 8
  %op3190 = and i64 %v3189, 6917529027641081858
  store i64 %op3190, ptr %slot500, align 8
  %v3191 = load i64, ptr %slot500, align 8
  %cmp3192 = icmp ne i64 %v3191, 0
  %cv3193 = zext i1 %cmp3192 to i32
  store i32 %cv3193, ptr %slot501, align 8
  %v3194 = load i32, ptr %slot501, align 8
  %cv3195 = zext i32 %v3194 to i64
  %cond3196 = icmp ne i64 %cv3195, 0
  br i1 %cond3196, label %bb_rcguniqueslow595, label %bb_rcguniquecount595
bb_rcguniquecount595:
  %v3197 = load i64, ptr %slot496, align 8
  %op3198 = sub i64 %v3197, 32
  store i64 %op3198, ptr %slot502, align 8
  %v3199 = load i64, ptr %slot496, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  %rgep3201 = getelementptr i8, ptr %p3200, i64 -32
  %ld3202 = load i64, ptr %rgep3201, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3202, ptr %slot503, align 8
  %v3203 = load i64, ptr %slot503, align 8
  %cmp3204 = icmp ult i64 %v3203, 2
  %cv3205 = zext i1 %cmp3204 to i32
  store i32 %cv3205, ptr %slot504, align 8
  %v3206 = load i32, ptr %slot504, align 8
  %cv3207 = zext i32 %v3206 to i64
  %cond3208 = icmp ne i64 %cv3207, 0
  br i1 %cond3208, label %bb_rcgunique595, label %bb_rcguniqueslow595
bb_rcguniqueslow595:
  %v3209 = load i64, ptr %slot1, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  %p3211 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v3212 = load i64, ptr %slot495, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %v3214 = load i64, ptr %slot12, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  %call3216 = call i32 @myl_qbe_rc_unique_local(ptr %p3210, ptr %p3211, ptr %p3213, ptr %p3215) nomerge, !dbg !124
  store i32 %call3216, ptr %slot505, align 8
  %v3217 = load i32, ptr %slot505, align 8
  %cv3218 = zext i32 %v3217 to i64
  %cond3219 = icmp ne i64 %cv3218, 0
  br i1 %cond3219, label %bb_rcunique606, label %bb_failure
bb_rcunique606:
  br label %bb_rcgunique595
bb_rcgunique595:
  %v3220 = load i64, ptr %slot34, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  %ld3222 = load i64, ptr %p3221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3222, ptr %slot506, align 8
  %v3223 = load i64, ptr %slot37, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %ld3225 = load i64, ptr %p3224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3225, ptr %slot507, align 8
  %v3226 = load i64, ptr %slot46, align 8
  %p3227 = inttoptr i64 %v3226 to ptr
  %v3228 = load i64, ptr %slot506, align 8
  %p3229 = inttoptr i64 %v3228 to ptr
  %v3230 = load i64, ptr %slot507, align 8
  %p3231 = inttoptr i64 %v3230 to ptr
  %call3232 = call i32 @myl_native_bytes_buffer_append_utf8(ptr %p3227, ptr %p3229, ptr %p3231) nomerge, !dbg !124
  store i32 %call3232, ptr %slot508, align 8
  %v3233 = load i32, ptr %slot508, align 8
  %ext3234 = zext i32 %v3233 to i64
  store i64 %ext3234, ptr %slot509, align 8
  %v3235 = load i64, ptr %slot509, align 8
  %cmp3236 = icmp ne i64 %v3235, 0
  %cv3237 = zext i1 %cmp3236 to i64
  store i64 %cv3237, ptr %slot510, align 8
  %v3238 = load i64, ptr %slot510, align 8
  %cond3239 = icmp ne i64 %v3238, 0
  br i1 %cond3239, label %bb_success613, label %bb_failed613
bb_failed613:
  %v3240 = load i64, ptr %slot1, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3241) nomerge, !dbg !124
  unreachable
bb_success613:
  %v3242 = load i32, ptr %slot508, align 8
  %cmp3243 = icmp eq i32 %v3242, 1
  %cv3244 = zext i1 %cmp3243 to i32
  store i32 %cv3244, ptr %slot511, align 8
  %v3245 = load i32, ptr %slot511, align 8
  %ext3246 = zext i32 %v3245 to i64
  store i64 %ext3246, ptr %slot512, align 8
  %v3247 = load i64, ptr %slot512, align 8
  %v3248 = load i64, ptr %slot37, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  store i64 %v3247, ptr %p3249, align 8, !alias.scope !3, !noalias !4
  %v3250 = load i64, ptr %slot16, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  %ld3252 = load i32, ptr %p3251, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3252, ptr %slot513, align 8
  %v3253 = load i32, ptr %slot513, align 8
  %cv3254 = zext i32 %v3253 to i64
  %cond3255 = icmp ne i64 %cv3254, 0
  br i1 %cond3255, label %bb_rcslotdrop618, label %bb_rcslotdone618
bb_rcslotdrop618:
  %v3256 = load i64, ptr %slot16, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  store i32 0, ptr %p3257, align 4, !alias.scope !3, !noalias !4
  %v3258 = load i64, ptr %slot22, align 8
  store i64 %v3258, ptr %slot514, align 8
  %v3259 = load i64, ptr %slot17, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  %ld3261 = load i32, ptr %p3260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3261, ptr %slot515, align 8
  %v3262 = load i32, ptr %slot515, align 8
  %op3263 = and i32 %v3262, 28
  store i32 %op3263, ptr %slot516, align 8
  %v3264 = load i32, ptr %slot516, align 8
  %cv3265 = zext i32 %v3264 to i64
  %cond3266 = icmp ne i64 %cv3265, 0
  br i1 %cond3266, label %bb_rcslotrole618, label %bb_rcslotowner618
bb_rcslotrole618:
  %v3267 = load i64, ptr %slot46, align 8
  store i64 %v3267, ptr %slot517, align 8
  %v3268 = load i64, ptr %slot514, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %ld3270 = load i64, ptr %p3269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3270, ptr %slot518, align 8
  %v3271 = load i64, ptr %slot518, align 8
  %cmp3272 = icmp ne i64 %v3271, 0
  %cv3273 = zext i1 %cmp3272 to i32
  store i32 %cv3273, ptr %slot519, align 8
  %v3274 = load i32, ptr %slot519, align 8
  %cv3275 = zext i32 %v3274 to i64
  %cond3276 = icmp ne i64 %cv3275, 0
  br i1 %cond3276, label %bb_rcgnn634, label %bb_rcgdone634
bb_rcgnn634:
  %v3277 = load i64, ptr %slot518, align 8
  %op3278 = sub i64 %v3277, 16
  store i64 %op3278, ptr %slot520, align 8
  %v3279 = load i64, ptr %slot518, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  %rgep3281 = getelementptr i8, ptr %p3280, i64 -16
  %ld3282 = load i64, ptr %rgep3281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3282, ptr %slot521, align 8
  %v3283 = load i64, ptr %slot521, align 8
  %op3284 = and i64 %v3283, 4611686018427387906
  store i64 %op3284, ptr %slot522, align 8
  %v3285 = load i64, ptr %slot522, align 8
  %cmp3286 = icmp ne i64 %v3285, 0
  %cv3287 = zext i1 %cmp3286 to i32
  store i32 %cv3287, ptr %slot523, align 8
  %v3288 = load i32, ptr %slot523, align 8
  %cv3289 = zext i32 %v3288 to i64
  %cond3290 = icmp ne i64 %cv3289, 0
  br i1 %cond3290, label %bb_rcgclear634, label %bb_rcgcounted634
bb_rcgcounted634:
  %v3291 = load i64, ptr %slot518, align 8
  %op3292 = sub i64 %v3291, 24
  store i64 %op3292, ptr %slot524, align 8
  %v3293 = load i64, ptr %slot518, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  %rgep3295 = getelementptr i8, ptr %p3294, i64 -24
  %ld3296 = load i64, ptr %rgep3295, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3296, ptr %slot525, align 8
  %v3297 = load i64, ptr %slot525, align 8
  %op3298 = sub i64 %v3297, 1
  store i64 %op3298, ptr %slot526, align 8
  %v3299 = load i64, ptr %slot526, align 8
  %cmp3300 = icmp eq i64 %v3299, 0
  %cv3301 = zext i1 %cmp3300 to i32
  store i32 %cv3301, ptr %slot527, align 8
  %v3302 = load i32, ptr %slot527, align 8
  %cv3303 = zext i32 %v3302 to i64
  %cond3304 = icmp ne i64 %cv3303, 0
  br i1 %cond3304, label %bb_rcglast634, label %bb_rcgdec634
bb_rcglast634:
  %v3305 = load i64, ptr %slot518, align 8
  %op3306 = sub i64 %v3305, 32
  store i64 %op3306, ptr %slot528, align 8
  %v3307 = load i64, ptr %slot518, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  %rgep3309 = getelementptr i8, ptr %p3308, i64 -32
  %ld3310 = load i64, ptr %rgep3309, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3310, ptr %slot529, align 8
  %v3311 = load i64, ptr %slot529, align 8
  %cmp3312 = icmp ne i64 %v3311, 0
  %cv3313 = zext i1 %cmp3312 to i32
  store i32 %cv3313, ptr %slot530, align 8
  %v3314 = load i32, ptr %slot530, align 8
  %cv3315 = zext i32 %v3314 to i64
  %cond3316 = icmp ne i64 %cv3315, 0
  br i1 %cond3316, label %bb_rcgdec634, label %bb_rcgslow634
bb_rcgslow634:
  %v3317 = load i64, ptr %slot517, align 8
  %v3318 = load i64, ptr %slot514, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v3317, i64 %v3318) nomerge, !dbg !124
  br label %bb_rcgdone634
bb_rcgdec634:
  %v3319 = load i64, ptr %slot526, align 8
  %v3320 = load i64, ptr %slot518, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  %rgep3322 = getelementptr i8, ptr %p3321, i64 -24
  store i64 %v3319, ptr %rgep3322, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear634
bb_rcgclear634:
  %v3323 = load i64, ptr %slot514, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  store i64 0, ptr %p3324, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone634
bb_rcgdone634:
  br label %bb_rcslotdone618
bb_rcslotowner618:
  %v3325 = load i64, ptr %slot46, align 8
  store i64 %v3325, ptr %slot531, align 8
  %v3326 = load i64, ptr %slot514, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  %ld3328 = load i64, ptr %p3327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3328, ptr %slot532, align 8
  %v3329 = load i64, ptr %slot532, align 8
  %cmp3330 = icmp ne i64 %v3329, 0
  %cv3331 = zext i1 %cmp3330 to i32
  store i32 %cv3331, ptr %slot533, align 8
  %v3332 = load i32, ptr %slot533, align 8
  %cv3333 = zext i32 %v3332 to i64
  %cond3334 = icmp ne i64 %cv3333, 0
  br i1 %cond3334, label %bb_rcgnn649, label %bb_rcgdone649
bb_rcgnn649:
  %v3335 = load i64, ptr %slot532, align 8
  %op3336 = sub i64 %v3335, 16
  store i64 %op3336, ptr %slot534, align 8
  %v3337 = load i64, ptr %slot532, align 8
  %p3338 = inttoptr i64 %v3337 to ptr
  %rgep3339 = getelementptr i8, ptr %p3338, i64 -16
  %ld3340 = load i64, ptr %rgep3339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3340, ptr %slot535, align 8
  %v3341 = load i64, ptr %slot535, align 8
  %op3342 = and i64 %v3341, 4611686018427387906
  store i64 %op3342, ptr %slot536, align 8
  %v3343 = load i64, ptr %slot536, align 8
  %cmp3344 = icmp ne i64 %v3343, 0
  %cv3345 = zext i1 %cmp3344 to i32
  store i32 %cv3345, ptr %slot537, align 8
  %v3346 = load i32, ptr %slot537, align 8
  %cv3347 = zext i32 %v3346 to i64
  %cond3348 = icmp ne i64 %cv3347, 0
  br i1 %cond3348, label %bb_rcgclear649, label %bb_rcgcounted649
bb_rcgcounted649:
  %v3349 = load i64, ptr %slot532, align 8
  %op3350 = sub i64 %v3349, 32
  store i64 %op3350, ptr %slot538, align 8
  %v3351 = load i64, ptr %slot532, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  %rgep3353 = getelementptr i8, ptr %p3352, i64 -32
  %ld3354 = load i64, ptr %rgep3353, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3354, ptr %slot539, align 8
  %v3355 = load i64, ptr %slot539, align 8
  %op3356 = sub i64 %v3355, 1
  store i64 %op3356, ptr %slot540, align 8
  %v3357 = load i64, ptr %slot540, align 8
  %cmp3358 = icmp eq i64 %v3357, 0
  %cv3359 = zext i1 %cmp3358 to i32
  store i32 %cv3359, ptr %slot541, align 8
  %v3360 = load i32, ptr %slot541, align 8
  %cv3361 = zext i32 %v3360 to i64
  %cond3362 = icmp ne i64 %cv3361, 0
  br i1 %cond3362, label %bb_rcglast649, label %bb_rcgdec649
bb_rcglast649:
  %v3363 = load i64, ptr %slot532, align 8
  %op3364 = sub i64 %v3363, 24
  store i64 %op3364, ptr %slot542, align 8
  %v3365 = load i64, ptr %slot532, align 8
  %p3366 = inttoptr i64 %v3365 to ptr
  %rgep3367 = getelementptr i8, ptr %p3366, i64 -24
  %ld3368 = load i64, ptr %rgep3367, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3368, ptr %slot543, align 8
  %v3369 = load i64, ptr %slot543, align 8
  %cmp3370 = icmp ne i64 %v3369, 0
  %cv3371 = zext i1 %cmp3370 to i32
  store i32 %cv3371, ptr %slot544, align 8
  %v3372 = load i32, ptr %slot544, align 8
  %cv3373 = zext i32 %v3372 to i64
  %cond3374 = icmp ne i64 %cv3373, 0
  br i1 %cond3374, label %bb_rcgdec649, label %bb_rcgslow649
bb_rcgslow649:
  %v3375 = load i64, ptr %slot531, align 8
  %v3376 = load i64, ptr %slot514, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v3375, i64 %v3376) nomerge, !dbg !124
  br label %bb_rcgdone649
bb_rcgdec649:
  %v3377 = load i64, ptr %slot540, align 8
  %v3378 = load i64, ptr %slot532, align 8
  %p3379 = inttoptr i64 %v3378 to ptr
  %rgep3380 = getelementptr i8, ptr %p3379, i64 -32
  store i64 %v3377, ptr %rgep3380, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear649
bb_rcgclear649:
  %v3381 = load i64, ptr %slot514, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  store i64 0, ptr %p3382, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone649
bb_rcgdone649:
  br label %bb_rcslotdone618
bb_rcslotdone618:
  %v3383 = load i64, ptr %slot28, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %ld3385 = load i64, ptr %p3384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3385, ptr %slot545, align 8
  %v3386 = load i64, ptr %slot545, align 8
  %v3387 = load i64, ptr %slot37, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  store i64 %v3386, ptr %p3388, align 8, !alias.scope !3, !noalias !4
  %v3389 = load i64, ptr %slot34, align 8
  store i64 %v3389, ptr %slot546, align 8
  %v3390 = load i64, ptr %slot13, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  store i32 2, ptr %p3391, align 4, !alias.scope !3, !noalias !4
  %v3392 = load i64, ptr %slot546, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  %ld3394 = load i64, ptr %p3393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3394, ptr %slot547, align 8
  %v3395 = load i64, ptr %slot547, align 8
  %cmp3396 = icmp ne i64 %v3395, 0
  %cv3397 = zext i1 %cmp3396 to i32
  store i32 %cv3397, ptr %slot548, align 8
  %v3398 = load i32, ptr %slot548, align 8
  %cv3399 = zext i32 %v3398 to i64
  %cond3400 = icmp ne i64 %cv3399, 0
  br i1 %cond3400, label %bb_rcguniquenn657, label %bb_rcgunique657
bb_rcguniquenn657:
  %v3401 = load i64, ptr %slot547, align 8
  %op3402 = sub i64 %v3401, 16
  store i64 %op3402, ptr %slot549, align 8
  %v3403 = load i64, ptr %slot547, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  %rgep3405 = getelementptr i8, ptr %p3404, i64 -16
  %ld3406 = load i64, ptr %rgep3405, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3406, ptr %slot550, align 8
  %v3407 = load i64, ptr %slot550, align 8
  %op3408 = and i64 %v3407, 6917529027641081858
  store i64 %op3408, ptr %slot551, align 8
  %v3409 = load i64, ptr %slot551, align 8
  %cmp3410 = icmp ne i64 %v3409, 0
  %cv3411 = zext i1 %cmp3410 to i32
  store i32 %cv3411, ptr %slot552, align 8
  %v3412 = load i32, ptr %slot552, align 8
  %cv3413 = zext i32 %v3412 to i64
  %cond3414 = icmp ne i64 %cv3413, 0
  br i1 %cond3414, label %bb_rcguniqueslow657, label %bb_rcguniquecount657
bb_rcguniquecount657:
  %v3415 = load i64, ptr %slot547, align 8
  %op3416 = sub i64 %v3415, 32
  store i64 %op3416, ptr %slot553, align 8
  %v3417 = load i64, ptr %slot547, align 8
  %p3418 = inttoptr i64 %v3417 to ptr
  %rgep3419 = getelementptr i8, ptr %p3418, i64 -32
  %ld3420 = load i64, ptr %rgep3419, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3420, ptr %slot554, align 8
  %v3421 = load i64, ptr %slot554, align 8
  %cmp3422 = icmp ult i64 %v3421, 2
  %cv3423 = zext i1 %cmp3422 to i32
  store i32 %cv3423, ptr %slot555, align 8
  %v3424 = load i32, ptr %slot555, align 8
  %cv3425 = zext i32 %v3424 to i64
  %cond3426 = icmp ne i64 %cv3425, 0
  br i1 %cond3426, label %bb_rcgunique657, label %bb_rcguniqueslow657
bb_rcguniqueslow657:
  %v3427 = load i64, ptr %slot1, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  %p3429 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v3430 = load i64, ptr %slot546, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %v3432 = load i64, ptr %slot12, align 8
  %p3433 = inttoptr i64 %v3432 to ptr
  %call3434 = call i32 @myl_qbe_rc_unique_local(ptr %p3428, ptr %p3429, ptr %p3431, ptr %p3433) nomerge, !dbg !126
  store i32 %call3434, ptr %slot556, align 8
  %v3435 = load i32, ptr %slot556, align 8
  %cv3436 = zext i32 %v3435 to i64
  %cond3437 = icmp ne i64 %cv3436, 0
  br i1 %cond3437, label %bb_rcunique668, label %bb_failure
bb_rcunique668:
  br label %bb_rcgunique657
bb_rcgunique657:
  %v3438 = load i64, ptr %slot34, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  %ld3440 = load i64, ptr %p3439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3440, ptr %slot557, align 8
  %v3441 = load i64, ptr %slot37, align 8
  %p3442 = inttoptr i64 %v3441 to ptr
  %ld3443 = load i64, ptr %p3442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3443, ptr %slot558, align 8
  %v3444 = load i64, ptr %slot46, align 8
  %p3445 = inttoptr i64 %v3444 to ptr
  %v3446 = load i64, ptr %slot557, align 8
  %p3447 = inttoptr i64 %v3446 to ptr
  %v3448 = load i64, ptr %slot558, align 8
  %call3449 = call i32 @myl_native_bytes_buffer_append_int(ptr %p3445, ptr %p3447, i64 %v3448) nomerge, !dbg !126
  store i32 %call3449, ptr %slot559, align 8
  %v3450 = load i32, ptr %slot559, align 8
  %ext3451 = zext i32 %v3450 to i64
  store i64 %ext3451, ptr %slot560, align 8
  %v3452 = load i64, ptr %slot560, align 8
  %cmp3453 = icmp ne i64 %v3452, 0
  %cv3454 = zext i1 %cmp3453 to i64
  store i64 %cv3454, ptr %slot561, align 8
  %v3455 = load i64, ptr %slot561, align 8
  %cond3456 = icmp ne i64 %v3455, 0
  br i1 %cond3456, label %bb_success675, label %bb_failed675
bb_failed675:
  %v3457 = load i64, ptr %slot1, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3458) nomerge, !dbg !126
  unreachable
bb_success675:
  %v3459 = load i32, ptr %slot559, align 8
  %cmp3460 = icmp eq i32 %v3459, 1
  %cv3461 = zext i1 %cmp3460 to i32
  store i32 %cv3461, ptr %slot562, align 8
  %v3462 = load i32, ptr %slot562, align 8
  %ext3463 = zext i32 %v3462 to i64
  store i64 %ext3463, ptr %slot563, align 8
  %v3464 = load i64, ptr %slot563, align 8
  %v3465 = load i64, ptr %slot37, align 8
  %p3466 = inttoptr i64 %v3465 to ptr
  store i64 %v3464, ptr %p3466, align 8, !alias.scope !3, !noalias !4
  %p3467 = inttoptr i64 ptrtoint (ptr @myl_lit_fa02b127f24cd2fef24f5d2060cd84bdf051b7536e5617126089d85771637db3 to i64) to ptr
  %ld3468 = load i64, ptr %p3467, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3468, ptr %slot564, align 8
  %v3469 = load i64, ptr %slot564, align 8
  %v3470 = load i64, ptr %slot37, align 8
  %p3471 = inttoptr i64 %v3470 to ptr
  store i64 %v3469, ptr %p3471, align 8, !alias.scope !3, !noalias !4
  %v3472 = load i64, ptr %slot37, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %ld3474 = load i64, ptr %p3473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3474, ptr %slot565, align 8
  %v3475 = load i64, ptr %slot565, align 8
  %v3476 = load i64, ptr %slot24, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  store i64 %v3475, ptr %p3477, align 8, !alias.scope !3, !noalias !4
  %v3478 = load i64, ptr %slot24, align 8
  store i64 %v3478, ptr %slot566, align 8
  %v3479 = load i64, ptr %slot26, align 8
  store i64 %v3479, ptr %slot567, align 8
  %v3480 = load i64, ptr %slot566, align 8
  %v3481 = load i64, ptr %slot567, align 8
  %p3482 = inttoptr i64 %v3480 to ptr
  %p3483 = inttoptr i64 %v3481 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3483, ptr %p3482, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3484 = load i64, ptr %slot21, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  store i32 2, ptr %p3485, align 4, !alias.scope !3, !noalias !4
  %v3486 = load i64, ptr %slot20, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  store i32 1, ptr %p3487, align 4, !alias.scope !3, !noalias !4
  %v3488 = load i64, ptr %slot22, align 8
  store i64 %v3488, ptr %slot568, align 8
  %v3489 = load i64, ptr %slot26, align 8
  store i64 %v3489, ptr %slot569, align 8
  %v3490 = load i64, ptr %slot569, align 8
  %v3491 = load i64, ptr %slot568, align 8
  %p3492 = inttoptr i64 %v3490 to ptr
  %p3493 = inttoptr i64 %v3491 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3493, ptr %p3492, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3494 = load i64, ptr %slot17, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  store i32 2, ptr %p3495, align 4, !alias.scope !3, !noalias !4
  %v3496 = load i64, ptr %slot21, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  %ld3498 = load i32, ptr %p3497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3498, ptr %slot570, align 8
  %v3499 = load i32, ptr %slot570, align 8
  %v3500 = load i64, ptr %slot17, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  store i32 %v3499, ptr %p3501, align 4, !alias.scope !3, !noalias !4
  %v3502 = load i64, ptr %slot20, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  store i32 0, ptr %p3503, align 4, !alias.scope !3, !noalias !4
  %v3504 = load i64, ptr %slot16, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  store i32 1, ptr %p3505, align 4, !alias.scope !3, !noalias !4
  %v3506 = load i64, ptr %slot568, align 8
  %p3507 = inttoptr i64 %v3506 to ptr
  %ld3508 = load i64, ptr %p3507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3508, ptr %slot571, align 8
  %v3509 = load i64, ptr %slot571, align 8
  %v3510 = load i64, ptr %slot37, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  store i64 %v3509, ptr %p3511, align 8, !alias.scope !3, !noalias !4
  %v3512 = load i64, ptr %slot34, align 8
  store i64 %v3512, ptr %slot572, align 8
  %v3513 = load i64, ptr %slot13, align 8
  %p3514 = inttoptr i64 %v3513 to ptr
  store i32 2, ptr %p3514, align 4, !alias.scope !3, !noalias !4
  %v3515 = load i64, ptr %slot572, align 8
  %p3516 = inttoptr i64 %v3515 to ptr
  %ld3517 = load i64, ptr %p3516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3517, ptr %slot573, align 8
  %v3518 = load i64, ptr %slot573, align 8
  %cmp3519 = icmp ne i64 %v3518, 0
  %cv3520 = zext i1 %cmp3519 to i32
  store i32 %cv3520, ptr %slot574, align 8
  %v3521 = load i32, ptr %slot574, align 8
  %cv3522 = zext i32 %v3521 to i64
  %cond3523 = icmp ne i64 %cv3522, 0
  br i1 %cond3523, label %bb_rcguniquenn697, label %bb_rcgunique697
bb_rcguniquenn697:
  %v3524 = load i64, ptr %slot573, align 8
  %op3525 = sub i64 %v3524, 16
  store i64 %op3525, ptr %slot575, align 8
  %v3526 = load i64, ptr %slot573, align 8
  %p3527 = inttoptr i64 %v3526 to ptr
  %rgep3528 = getelementptr i8, ptr %p3527, i64 -16
  %ld3529 = load i64, ptr %rgep3528, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3529, ptr %slot576, align 8
  %v3530 = load i64, ptr %slot576, align 8
  %op3531 = and i64 %v3530, 6917529027641081858
  store i64 %op3531, ptr %slot577, align 8
  %v3532 = load i64, ptr %slot577, align 8
  %cmp3533 = icmp ne i64 %v3532, 0
  %cv3534 = zext i1 %cmp3533 to i32
  store i32 %cv3534, ptr %slot578, align 8
  %v3535 = load i32, ptr %slot578, align 8
  %cv3536 = zext i32 %v3535 to i64
  %cond3537 = icmp ne i64 %cv3536, 0
  br i1 %cond3537, label %bb_rcguniqueslow697, label %bb_rcguniquecount697
bb_rcguniquecount697:
  %v3538 = load i64, ptr %slot573, align 8
  %op3539 = sub i64 %v3538, 32
  store i64 %op3539, ptr %slot579, align 8
  %v3540 = load i64, ptr %slot573, align 8
  %p3541 = inttoptr i64 %v3540 to ptr
  %rgep3542 = getelementptr i8, ptr %p3541, i64 -32
  %ld3543 = load i64, ptr %rgep3542, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3543, ptr %slot580, align 8
  %v3544 = load i64, ptr %slot580, align 8
  %cmp3545 = icmp ult i64 %v3544, 2
  %cv3546 = zext i1 %cmp3545 to i32
  store i32 %cv3546, ptr %slot581, align 8
  %v3547 = load i32, ptr %slot581, align 8
  %cv3548 = zext i32 %v3547 to i64
  %cond3549 = icmp ne i64 %cv3548, 0
  br i1 %cond3549, label %bb_rcgunique697, label %bb_rcguniqueslow697
bb_rcguniqueslow697:
  %v3550 = load i64, ptr %slot1, align 8
  %p3551 = inttoptr i64 %v3550 to ptr
  %p3552 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v3553 = load i64, ptr %slot572, align 8
  %p3554 = inttoptr i64 %v3553 to ptr
  %v3555 = load i64, ptr %slot12, align 8
  %p3556 = inttoptr i64 %v3555 to ptr
  %call3557 = call i32 @myl_qbe_rc_unique_local(ptr %p3551, ptr %p3552, ptr %p3554, ptr %p3556) nomerge, !dbg !128
  store i32 %call3557, ptr %slot582, align 8
  %v3558 = load i32, ptr %slot582, align 8
  %cv3559 = zext i32 %v3558 to i64
  %cond3560 = icmp ne i64 %cv3559, 0
  br i1 %cond3560, label %bb_rcunique708, label %bb_failure
bb_rcunique708:
  br label %bb_rcgunique697
bb_rcgunique697:
  %v3561 = load i64, ptr %slot34, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  %ld3563 = load i64, ptr %p3562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3563, ptr %slot583, align 8
  %v3564 = load i64, ptr %slot37, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  %ld3566 = load i64, ptr %p3565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3566, ptr %slot584, align 8
  %v3567 = load i64, ptr %slot46, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  %v3569 = load i64, ptr %slot583, align 8
  %p3570 = inttoptr i64 %v3569 to ptr
  %v3571 = load i64, ptr %slot584, align 8
  %p3572 = inttoptr i64 %v3571 to ptr
  %call3573 = call i32 @myl_native_bytes_buffer_append_utf8(ptr %p3568, ptr %p3570, ptr %p3572) nomerge, !dbg !128
  store i32 %call3573, ptr %slot585, align 8
  %v3574 = load i32, ptr %slot585, align 8
  %ext3575 = zext i32 %v3574 to i64
  store i64 %ext3575, ptr %slot586, align 8
  %v3576 = load i64, ptr %slot586, align 8
  %cmp3577 = icmp ne i64 %v3576, 0
  %cv3578 = zext i1 %cmp3577 to i64
  store i64 %cv3578, ptr %slot587, align 8
  %v3579 = load i64, ptr %slot587, align 8
  %cond3580 = icmp ne i64 %v3579, 0
  br i1 %cond3580, label %bb_success715, label %bb_failed715
bb_failed715:
  %v3581 = load i64, ptr %slot1, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3582) nomerge, !dbg !128
  unreachable
bb_success715:
  %v3583 = load i32, ptr %slot585, align 8
  %cmp3584 = icmp eq i32 %v3583, 1
  %cv3585 = zext i1 %cmp3584 to i32
  store i32 %cv3585, ptr %slot588, align 8
  %v3586 = load i32, ptr %slot588, align 8
  %ext3587 = zext i32 %v3586 to i64
  store i64 %ext3587, ptr %slot589, align 8
  %v3588 = load i64, ptr %slot589, align 8
  %v3589 = load i64, ptr %slot37, align 8
  %p3590 = inttoptr i64 %v3589 to ptr
  store i64 %v3588, ptr %p3590, align 8, !alias.scope !3, !noalias !4
  %v3591 = load i64, ptr %slot16, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  %ld3593 = load i32, ptr %p3592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3593, ptr %slot590, align 8
  %v3594 = load i32, ptr %slot590, align 8
  %cv3595 = zext i32 %v3594 to i64
  %cond3596 = icmp ne i64 %cv3595, 0
  br i1 %cond3596, label %bb_rcslotdrop720, label %bb_rcslotdone720
bb_rcslotdrop720:
  %v3597 = load i64, ptr %slot16, align 8
  %p3598 = inttoptr i64 %v3597 to ptr
  store i32 0, ptr %p3598, align 4, !alias.scope !3, !noalias !4
  %v3599 = load i64, ptr %slot22, align 8
  store i64 %v3599, ptr %slot591, align 8
  %v3600 = load i64, ptr %slot17, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  %ld3602 = load i32, ptr %p3601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3602, ptr %slot592, align 8
  %v3603 = load i32, ptr %slot592, align 8
  %op3604 = and i32 %v3603, 28
  store i32 %op3604, ptr %slot593, align 8
  %v3605 = load i32, ptr %slot593, align 8
  %cv3606 = zext i32 %v3605 to i64
  %cond3607 = icmp ne i64 %cv3606, 0
  br i1 %cond3607, label %bb_rcslotrole720, label %bb_rcslotowner720
bb_rcslotrole720:
  %v3608 = load i64, ptr %slot46, align 8
  store i64 %v3608, ptr %slot594, align 8
  %v3609 = load i64, ptr %slot591, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  %ld3611 = load i64, ptr %p3610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3611, ptr %slot595, align 8
  %v3612 = load i64, ptr %slot595, align 8
  %cmp3613 = icmp ne i64 %v3612, 0
  %cv3614 = zext i1 %cmp3613 to i32
  store i32 %cv3614, ptr %slot596, align 8
  %v3615 = load i32, ptr %slot596, align 8
  %cv3616 = zext i32 %v3615 to i64
  %cond3617 = icmp ne i64 %cv3616, 0
  br i1 %cond3617, label %bb_rcgnn736, label %bb_rcgdone736
bb_rcgnn736:
  %v3618 = load i64, ptr %slot595, align 8
  %op3619 = sub i64 %v3618, 16
  store i64 %op3619, ptr %slot597, align 8
  %v3620 = load i64, ptr %slot595, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %rgep3622 = getelementptr i8, ptr %p3621, i64 -16
  %ld3623 = load i64, ptr %rgep3622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3623, ptr %slot598, align 8
  %v3624 = load i64, ptr %slot598, align 8
  %op3625 = and i64 %v3624, 4611686018427387906
  store i64 %op3625, ptr %slot599, align 8
  %v3626 = load i64, ptr %slot599, align 8
  %cmp3627 = icmp ne i64 %v3626, 0
  %cv3628 = zext i1 %cmp3627 to i32
  store i32 %cv3628, ptr %slot600, align 8
  %v3629 = load i32, ptr %slot600, align 8
  %cv3630 = zext i32 %v3629 to i64
  %cond3631 = icmp ne i64 %cv3630, 0
  br i1 %cond3631, label %bb_rcgclear736, label %bb_rcgcounted736
bb_rcgcounted736:
  %v3632 = load i64, ptr %slot595, align 8
  %op3633 = sub i64 %v3632, 24
  store i64 %op3633, ptr %slot601, align 8
  %v3634 = load i64, ptr %slot595, align 8
  %p3635 = inttoptr i64 %v3634 to ptr
  %rgep3636 = getelementptr i8, ptr %p3635, i64 -24
  %ld3637 = load i64, ptr %rgep3636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3637, ptr %slot602, align 8
  %v3638 = load i64, ptr %slot602, align 8
  %op3639 = sub i64 %v3638, 1
  store i64 %op3639, ptr %slot603, align 8
  %v3640 = load i64, ptr %slot603, align 8
  %cmp3641 = icmp eq i64 %v3640, 0
  %cv3642 = zext i1 %cmp3641 to i32
  store i32 %cv3642, ptr %slot604, align 8
  %v3643 = load i32, ptr %slot604, align 8
  %cv3644 = zext i32 %v3643 to i64
  %cond3645 = icmp ne i64 %cv3644, 0
  br i1 %cond3645, label %bb_rcglast736, label %bb_rcgdec736
bb_rcglast736:
  %v3646 = load i64, ptr %slot595, align 8
  %op3647 = sub i64 %v3646, 32
  store i64 %op3647, ptr %slot605, align 8
  %v3648 = load i64, ptr %slot595, align 8
  %p3649 = inttoptr i64 %v3648 to ptr
  %rgep3650 = getelementptr i8, ptr %p3649, i64 -32
  %ld3651 = load i64, ptr %rgep3650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3651, ptr %slot606, align 8
  %v3652 = load i64, ptr %slot606, align 8
  %cmp3653 = icmp ne i64 %v3652, 0
  %cv3654 = zext i1 %cmp3653 to i32
  store i32 %cv3654, ptr %slot607, align 8
  %v3655 = load i32, ptr %slot607, align 8
  %cv3656 = zext i32 %v3655 to i64
  %cond3657 = icmp ne i64 %cv3656, 0
  br i1 %cond3657, label %bb_rcgdec736, label %bb_rcgslow736
bb_rcgslow736:
  %v3658 = load i64, ptr %slot594, align 8
  %v3659 = load i64, ptr %slot591, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v3658, i64 %v3659) nomerge, !dbg !128
  br label %bb_rcgdone736
bb_rcgdec736:
  %v3660 = load i64, ptr %slot603, align 8
  %v3661 = load i64, ptr %slot595, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %rgep3663 = getelementptr i8, ptr %p3662, i64 -24
  store i64 %v3660, ptr %rgep3663, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear736
bb_rcgclear736:
  %v3664 = load i64, ptr %slot591, align 8
  %p3665 = inttoptr i64 %v3664 to ptr
  store i64 0, ptr %p3665, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone736
bb_rcgdone736:
  br label %bb_rcslotdone720
bb_rcslotowner720:
  %v3666 = load i64, ptr %slot46, align 8
  store i64 %v3666, ptr %slot608, align 8
  %v3667 = load i64, ptr %slot591, align 8
  %p3668 = inttoptr i64 %v3667 to ptr
  %ld3669 = load i64, ptr %p3668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3669, ptr %slot609, align 8
  %v3670 = load i64, ptr %slot609, align 8
  %cmp3671 = icmp ne i64 %v3670, 0
  %cv3672 = zext i1 %cmp3671 to i32
  store i32 %cv3672, ptr %slot610, align 8
  %v3673 = load i32, ptr %slot610, align 8
  %cv3674 = zext i32 %v3673 to i64
  %cond3675 = icmp ne i64 %cv3674, 0
  br i1 %cond3675, label %bb_rcgnn751, label %bb_rcgdone751
bb_rcgnn751:
  %v3676 = load i64, ptr %slot609, align 8
  %op3677 = sub i64 %v3676, 16
  store i64 %op3677, ptr %slot611, align 8
  %v3678 = load i64, ptr %slot609, align 8
  %p3679 = inttoptr i64 %v3678 to ptr
  %rgep3680 = getelementptr i8, ptr %p3679, i64 -16
  %ld3681 = load i64, ptr %rgep3680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3681, ptr %slot612, align 8
  %v3682 = load i64, ptr %slot612, align 8
  %op3683 = and i64 %v3682, 4611686018427387906
  store i64 %op3683, ptr %slot613, align 8
  %v3684 = load i64, ptr %slot613, align 8
  %cmp3685 = icmp ne i64 %v3684, 0
  %cv3686 = zext i1 %cmp3685 to i32
  store i32 %cv3686, ptr %slot614, align 8
  %v3687 = load i32, ptr %slot614, align 8
  %cv3688 = zext i32 %v3687 to i64
  %cond3689 = icmp ne i64 %cv3688, 0
  br i1 %cond3689, label %bb_rcgclear751, label %bb_rcgcounted751
bb_rcgcounted751:
  %v3690 = load i64, ptr %slot609, align 8
  %op3691 = sub i64 %v3690, 32
  store i64 %op3691, ptr %slot615, align 8
  %v3692 = load i64, ptr %slot609, align 8
  %p3693 = inttoptr i64 %v3692 to ptr
  %rgep3694 = getelementptr i8, ptr %p3693, i64 -32
  %ld3695 = load i64, ptr %rgep3694, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3695, ptr %slot616, align 8
  %v3696 = load i64, ptr %slot616, align 8
  %op3697 = sub i64 %v3696, 1
  store i64 %op3697, ptr %slot617, align 8
  %v3698 = load i64, ptr %slot617, align 8
  %cmp3699 = icmp eq i64 %v3698, 0
  %cv3700 = zext i1 %cmp3699 to i32
  store i32 %cv3700, ptr %slot618, align 8
  %v3701 = load i32, ptr %slot618, align 8
  %cv3702 = zext i32 %v3701 to i64
  %cond3703 = icmp ne i64 %cv3702, 0
  br i1 %cond3703, label %bb_rcglast751, label %bb_rcgdec751
bb_rcglast751:
  %v3704 = load i64, ptr %slot609, align 8
  %op3705 = sub i64 %v3704, 24
  store i64 %op3705, ptr %slot619, align 8
  %v3706 = load i64, ptr %slot609, align 8
  %p3707 = inttoptr i64 %v3706 to ptr
  %rgep3708 = getelementptr i8, ptr %p3707, i64 -24
  %ld3709 = load i64, ptr %rgep3708, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3709, ptr %slot620, align 8
  %v3710 = load i64, ptr %slot620, align 8
  %cmp3711 = icmp ne i64 %v3710, 0
  %cv3712 = zext i1 %cmp3711 to i32
  store i32 %cv3712, ptr %slot621, align 8
  %v3713 = load i32, ptr %slot621, align 8
  %cv3714 = zext i32 %v3713 to i64
  %cond3715 = icmp ne i64 %cv3714, 0
  br i1 %cond3715, label %bb_rcgdec751, label %bb_rcgslow751
bb_rcgslow751:
  %v3716 = load i64, ptr %slot608, align 8
  %v3717 = load i64, ptr %slot591, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v3716, i64 %v3717) nomerge, !dbg !128
  br label %bb_rcgdone751
bb_rcgdec751:
  %v3718 = load i64, ptr %slot617, align 8
  %v3719 = load i64, ptr %slot609, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %rgep3721 = getelementptr i8, ptr %p3720, i64 -32
  store i64 %v3718, ptr %rgep3721, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear751
bb_rcgclear751:
  %v3722 = load i64, ptr %slot591, align 8
  %p3723 = inttoptr i64 %v3722 to ptr
  store i64 0, ptr %p3723, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone751
bb_rcgdone751:
  br label %bb_rcslotdone720
bb_rcslotdone720:
  %v3724 = load i64, ptr %slot27, align 8
  %p3725 = inttoptr i64 %v3724 to ptr
  %ld3726 = load i64, ptr %p3725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3726, ptr %slot622, align 8
  %v3727 = load i64, ptr %slot622, align 8
  %v3728 = load i64, ptr %slot37, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  store i64 %v3727, ptr %p3729, align 8, !alias.scope !3, !noalias !4
  %v3730 = load i64, ptr %slot37, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  %ld3732 = load i64, ptr %p3731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3732, ptr %slot623, align 8
  %v3733 = load i64, ptr %slot623, align 8
  %op3734 = add i64 %v3733, 32
  store i64 %op3734, ptr %slot624, align 8
  %v3735 = load i64, ptr %slot624, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  %ld3737 = load i64, ptr %p3736, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3737, ptr %slot625, align 8
  %v3738 = load i64, ptr %slot625, align 8
  %v3739 = load i64, ptr %slot37, align 8
  %p3740 = inttoptr i64 %v3739 to ptr
  store i64 %v3738, ptr %p3740, align 8, !alias.scope !3, !noalias !4
  %v3741 = load i64, ptr %slot16, align 8
  %p3742 = inttoptr i64 %v3741 to ptr
  %ld3743 = load i32, ptr %p3742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3743, ptr %slot626, align 8
  %v3744 = load i32, ptr %slot626, align 8
  %cv3745 = zext i32 %v3744 to i64
  %cond3746 = icmp ne i64 %cv3745, 0
  br i1 %cond3746, label %bb_rcslotdrop761, label %bb_rcslotdone761
bb_rcslotdrop761:
  %v3747 = load i64, ptr %slot16, align 8
  %p3748 = inttoptr i64 %v3747 to ptr
  store i32 0, ptr %p3748, align 4, !alias.scope !3, !noalias !4
  %v3749 = load i64, ptr %slot22, align 8
  store i64 %v3749, ptr %slot627, align 8
  %v3750 = load i64, ptr %slot17, align 8
  %p3751 = inttoptr i64 %v3750 to ptr
  %ld3752 = load i32, ptr %p3751, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3752, ptr %slot628, align 8
  %v3753 = load i32, ptr %slot628, align 8
  %op3754 = and i32 %v3753, 28
  store i32 %op3754, ptr %slot629, align 8
  %v3755 = load i32, ptr %slot629, align 8
  %cv3756 = zext i32 %v3755 to i64
  %cond3757 = icmp ne i64 %cv3756, 0
  br i1 %cond3757, label %bb_rcslotrole761, label %bb_rcslotowner761
bb_rcslotrole761:
  %v3758 = load i64, ptr %slot46, align 8
  store i64 %v3758, ptr %slot630, align 8
  %v3759 = load i64, ptr %slot630, align 8
  %v3760 = load i64, ptr %slot627, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v3759, i64 %v3760) nomerge, !dbg !130
  br label %bb_rcslotdone761
bb_rcslotowner761:
  %v3761 = load i64, ptr %slot46, align 8
  store i64 %v3761, ptr %slot631, align 8
  %v3762 = load i64, ptr %slot631, align 8
  %v3763 = load i64, ptr %slot627, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v3762, i64 %v3763) nomerge, !dbg !130
  br label %bb_rcslotdone761
bb_rcslotdone761:
  %v3764 = load i64, ptr %slot29, align 8
  %p3765 = inttoptr i64 %v3764 to ptr
  %ld3766 = load i64, ptr %p3765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3766, ptr %slot632, align 8
  %v3767 = load i64, ptr %slot632, align 8
  %v3768 = load i64, ptr %slot38, align 8
  %p3769 = inttoptr i64 %v3768 to ptr
  store i64 %v3767, ptr %p3769, align 8, !alias.scope !3, !noalias !4
  %v3770 = load i64, ptr %slot29, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  %ld3772 = load i64, ptr %p3771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3772, ptr %slot633, align 8
  %v3773 = load i64, ptr %slot633, align 8
  %v3774 = load i64, ptr %slot39, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  store i64 %v3773, ptr %p3775, align 8, !alias.scope !3, !noalias !4
  %v3776 = load i64, ptr %slot30, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  %ld3778 = load i64, ptr %p3777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3778, ptr %slot634, align 8
  %v3779 = load i64, ptr %slot634, align 8
  %v3780 = load i64, ptr %slot40, align 8
  %p3781 = inttoptr i64 %v3780 to ptr
  store i64 %v3779, ptr %p3781, align 8, !alias.scope !3, !noalias !4
  %v3782 = load i64, ptr %slot40, align 8
  %p3783 = inttoptr i64 %v3782 to ptr
  %ld3784 = load i64, ptr %p3783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3784, ptr %slot635, align 8
  %v3785 = load i64, ptr %slot39, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i64, ptr %p3786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3787, ptr %slot636, align 8
  %v3788 = load i64, ptr %slot636, align 8
  %v3789 = load i64, ptr %slot635, align 8
  %ovpair3791 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3788, i64 %v3789)
  %op3790 = extractvalue { i64, i1 } %ovpair3791, 0
  %ov3792 = extractvalue { i64, i1 } %ovpair3791, 1
  store i64 %op3790, ptr %slot637, align 8
  %v3793 = load i64, ptr %slot636, align 8
  %v3794 = load i64, ptr %slot637, align 8
  %op3795 = xor i64 %v3793, %v3794
  store i64 %op3795, ptr %slot638, align 8
  %v3796 = load i64, ptr %slot635, align 8
  %v3797 = load i64, ptr %slot637, align 8
  %op3798 = xor i64 %v3796, %v3797
  store i64 %op3798, ptr %slot639, align 8
  %v3799 = load i64, ptr %slot638, align 8
  %v3800 = load i64, ptr %slot639, align 8
  %op3801 = and i64 %v3799, %v3800
  store i64 %op3801, ptr %slot640, align 8
  %cv3802 = zext i1 %ov3792 to i64
  store i64 %cv3802, ptr %slot641, align 8
  %v3803 = load i64, ptr %slot641, align 8
  %cond3804 = icmp ne i64 %v3803, 0
  br i1 %cond3804, label %bb_overflow773, label %bb_checked773
bb_overflow773:
  %v3805 = load i64, ptr %slot1, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %v3807 = load i64, ptr %slot636, align 8
  %v3808 = load i64, ptr %slot635, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3806, i64 0, i64 %v3807, i64 %v3808, i64 64) nomerge, !dbg !132
  unreachable
bb_checked773:
  %v3809 = load i64, ptr %slot637, align 8
  %v3810 = load i64, ptr %slot39, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  store i64 %v3809, ptr %p3811, align 8, !alias.scope !3, !noalias !4
  %v3812 = load i64, ptr %slot34, align 8
  store i64 %v3812, ptr %slot642, align 8
  %v3813 = load i64, ptr %slot13, align 8
  %p3814 = inttoptr i64 %v3813 to ptr
  store i32 2, ptr %p3814, align 4, !alias.scope !3, !noalias !4
  %v3815 = load i64, ptr %slot642, align 8
  %p3816 = inttoptr i64 %v3815 to ptr
  %ld3817 = load i64, ptr %p3816, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3817, ptr %slot643, align 8
  %v3818 = load i64, ptr %slot643, align 8
  %cmp3819 = icmp ne i64 %v3818, 0
  %cv3820 = zext i1 %cmp3819 to i32
  store i32 %cv3820, ptr %slot644, align 8
  %v3821 = load i32, ptr %slot644, align 8
  %cv3822 = zext i32 %v3821 to i64
  %cond3823 = icmp ne i64 %cv3822, 0
  br i1 %cond3823, label %bb_rcguniquenn781, label %bb_rcgunique781
bb_rcguniquenn781:
  %v3824 = load i64, ptr %slot643, align 8
  %op3825 = sub i64 %v3824, 16
  store i64 %op3825, ptr %slot645, align 8
  %v3826 = load i64, ptr %slot643, align 8
  %p3827 = inttoptr i64 %v3826 to ptr
  %rgep3828 = getelementptr i8, ptr %p3827, i64 -16
  %ld3829 = load i64, ptr %rgep3828, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3829, ptr %slot646, align 8
  %v3830 = load i64, ptr %slot646, align 8
  %op3831 = and i64 %v3830, 6917529027641081858
  store i64 %op3831, ptr %slot647, align 8
  %v3832 = load i64, ptr %slot647, align 8
  %cmp3833 = icmp ne i64 %v3832, 0
  %cv3834 = zext i1 %cmp3833 to i32
  store i32 %cv3834, ptr %slot648, align 8
  %v3835 = load i32, ptr %slot648, align 8
  %cv3836 = zext i32 %v3835 to i64
  %cond3837 = icmp ne i64 %cv3836, 0
  br i1 %cond3837, label %bb_rcguniqueslow781, label %bb_rcguniquecount781
bb_rcguniquecount781:
  %v3838 = load i64, ptr %slot643, align 8
  %op3839 = sub i64 %v3838, 32
  store i64 %op3839, ptr %slot649, align 8
  %v3840 = load i64, ptr %slot643, align 8
  %p3841 = inttoptr i64 %v3840 to ptr
  %rgep3842 = getelementptr i8, ptr %p3841, i64 -32
  %ld3843 = load i64, ptr %rgep3842, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3843, ptr %slot650, align 8
  %v3844 = load i64, ptr %slot650, align 8
  %cmp3845 = icmp ult i64 %v3844, 2
  %cv3846 = zext i1 %cmp3845 to i32
  store i32 %cv3846, ptr %slot651, align 8
  %v3847 = load i32, ptr %slot651, align 8
  %cv3848 = zext i32 %v3847 to i64
  %cond3849 = icmp ne i64 %cv3848, 0
  br i1 %cond3849, label %bb_rcgunique781, label %bb_rcguniqueslow781
bb_rcguniqueslow781:
  %v3850 = load i64, ptr %slot1, align 8
  %p3851 = inttoptr i64 %v3850 to ptr
  %p3852 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v3853 = load i64, ptr %slot642, align 8
  %p3854 = inttoptr i64 %v3853 to ptr
  %v3855 = load i64, ptr %slot12, align 8
  %p3856 = inttoptr i64 %v3855 to ptr
  %call3857 = call i32 @myl_qbe_rc_unique_local(ptr %p3851, ptr %p3852, ptr %p3854, ptr %p3856) nomerge, !dbg !134
  store i32 %call3857, ptr %slot652, align 8
  %v3858 = load i32, ptr %slot652, align 8
  %cv3859 = zext i32 %v3858 to i64
  %cond3860 = icmp ne i64 %cv3859, 0
  br i1 %cond3860, label %bb_rcunique792, label %bb_failure
bb_rcunique792:
  br label %bb_rcgunique781
bb_rcgunique781:
  %v3861 = load i64, ptr %slot34, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  %ld3863 = load i64, ptr %p3862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3863, ptr %slot653, align 8
  %v3864 = load i64, ptr %slot37, align 8
  %p3865 = inttoptr i64 %v3864 to ptr
  %ld3866 = load i64, ptr %p3865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3866, ptr %slot654, align 8
  %v3867 = load i64, ptr %slot38, align 8
  %p3868 = inttoptr i64 %v3867 to ptr
  %ld3869 = load i64, ptr %p3868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3869, ptr %slot655, align 8
  %v3870 = load i64, ptr %slot39, align 8
  %p3871 = inttoptr i64 %v3870 to ptr
  %ld3872 = load i64, ptr %p3871, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3872, ptr %slot656, align 8
  %v3873 = load i64, ptr %slot653, align 8
  %op3874 = add i64 %v3873, 8
  store i64 %op3874, ptr %slot657, align 8
  %v3875 = load i64, ptr %slot655, align 8
  %cmp3876 = icmp sge i64 %v3875, 0
  %cv3877 = zext i1 %cmp3876 to i64
  store i64 %cv3877, ptr %slot658, align 8
  %v3878 = load i64, ptr %slot658, align 8
  %cond3879 = icmp ne i64 %v3878, 0
  br i1 %cond3879, label %bb_buf_start798, label %bb_buf_refused798
bb_buf_start798:
  %v3880 = load i64, ptr %slot655, align 8
  %v3881 = load i64, ptr %slot656, align 8
  %cmp3882 = icmp sle i64 %v3880, %v3881
  %cv3883 = zext i1 %cmp3882 to i64
  store i64 %cv3883, ptr %slot659, align 8
  %v3884 = load i64, ptr %slot659, align 8
  %cond3885 = icmp ne i64 %v3884, 0
  br i1 %cond3885, label %bb_buf_order798, label %bb_buf_refused798
bb_buf_order798:
  %v3886 = load i64, ptr %slot654, align 8
  %p3887 = inttoptr i64 %v3886 to ptr
  %ld3888 = load i64, ptr %p3887, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3888, ptr %slot660, align 8
  %v3889 = load i64, ptr %slot656, align 8
  %v3890 = load i64, ptr %slot660, align 8
  %cmp3891 = icmp ule i64 %v3889, %v3890
  %cv3892 = zext i1 %cmp3891 to i64
  store i64 %cv3892, ptr %slot661, align 8
  %v3893 = load i64, ptr %slot661, align 8
  %cond3894 = icmp ne i64 %v3893, 0
  br i1 %cond3894, label %bb_buf_bound798, label %bb_buf_refused798
bb_buf_bound798:
  %v3895 = load i64, ptr %slot653, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  %ld3897 = load i64, ptr %p3896, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3897, ptr %slot662, align 8
  %v3898 = load i64, ptr %slot657, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  %ld3900 = load i64, ptr %p3899, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3900, ptr %slot663, align 8
  %v3901 = load i64, ptr %slot656, align 8
  %v3902 = load i64, ptr %slot655, align 8
  %op3903 = sub i64 %v3901, %v3902
  store i64 %op3903, ptr %slot664, align 8
  %v3904 = load i64, ptr %slot663, align 8
  %v3905 = load i64, ptr %slot662, align 8
  %op3906 = sub i64 %v3904, %v3905
  store i64 %op3906, ptr %slot665, align 8
  %v3907 = load i64, ptr %slot664, align 8
  %v3908 = load i64, ptr %slot665, align 8
  %cmp3909 = icmp ult i64 %v3907, %v3908
  %cv3910 = zext i1 %cmp3909 to i64
  store i64 %cv3910, ptr %slot666, align 8
  %v3911 = load i64, ptr %slot666, align 8
  %cond3912 = icmp ne i64 %v3911, 0
  br i1 %cond3912, label %bb_buf_fast798, label %bb_buf_slow798
bb_buf_slow798:
  %v3913 = load i64, ptr %slot46, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  %v3915 = load i64, ptr %slot653, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  %v3917 = load i64, ptr %slot654, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  %v3919 = load i64, ptr %slot655, align 8
  %v3920 = load i64, ptr %slot656, align 8
  %call3921 = call i32 @myl_native_bytes_buffer_append_range(ptr %p3914, ptr %p3916, ptr %p3918, i64 %v3919, i64 %v3920) nomerge, !dbg !134
  store i32 %call3921, ptr %slot667, align 8
  %v3922 = load i32, ptr %slot667, align 8
  %ext3923 = zext i32 %v3922 to i64
  store i64 %ext3923, ptr %slot668, align 8
  %v3924 = load i64, ptr %slot668, align 8
  %cmp3925 = icmp ne i64 %v3924, 0
  %cv3926 = zext i1 %cmp3925 to i64
  store i64 %cv3926, ptr %slot669, align 8
  %v3927 = load i64, ptr %slot669, align 8
  %cond3928 = icmp ne i64 %v3927, 0
  br i1 %cond3928, label %bb_success812, label %bb_failed812
bb_failed812:
  %v3929 = load i64, ptr %slot1, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3930) nomerge, !dbg !134
  unreachable
bb_success812:
  %v3931 = load i32, ptr %slot667, align 8
  %cmp3932 = icmp eq i32 %v3931, 1
  %cv3933 = zext i1 %cmp3932 to i32
  store i32 %cv3933, ptr %slot670, align 8
  %v3934 = load i32, ptr %slot670, align 8
  %ext3935 = zext i32 %v3934 to i64
  store i64 %ext3935, ptr %slot671, align 8
  %v3936 = load i64, ptr %slot671, align 8
  %v3937 = load i64, ptr %slot37, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  store i64 %v3936, ptr %p3938, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done798
bb_buf_fast798:
  %v3939 = load i64, ptr %slot653, align 8
  %op3940 = add i64 %v3939, 32
  store i64 %op3940, ptr %slot672, align 8
  %v3941 = load i64, ptr %slot654, align 8
  %op3942 = add i64 %v3941, 32
  store i64 %op3942, ptr %slot673, align 8
  %v3943 = load i64, ptr %slot672, align 8
  %p3944 = inttoptr i64 %v3943 to ptr
  %ld3945 = load i64, ptr %p3944, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3945, ptr %slot674, align 8
  %v3946 = load i64, ptr %slot674, align 8
  %v3947 = load i64, ptr %slot662, align 8
  %op3948 = add i64 %v3946, %v3947
  store i64 %op3948, ptr %slot675, align 8
  %v3949 = load i64, ptr %slot673, align 8
  %p3950 = inttoptr i64 %v3949 to ptr
  %ld3951 = load i64, ptr %p3950, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3951, ptr %slot676, align 8
  %v3952 = load i64, ptr %slot676, align 8
  %v3953 = load i64, ptr %slot655, align 8
  %op3954 = add i64 %v3952, %v3953
  store i64 %op3954, ptr %slot677, align 8
  %v3955 = load i64, ptr %slot675, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %v3957 = load i64, ptr %slot677, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  %v3959 = load i64, ptr %slot664, align 8
  call void @myl_native_bytes_copy_octets(ptr %p3956, ptr %p3958, i64 %v3959) nomerge, !dbg !134
  %v3960 = load i64, ptr %slot662, align 8
  %v3961 = load i64, ptr %slot664, align 8
  %op3962 = add i64 %v3960, %v3961
  store i64 %op3962, ptr %slot678, align 8
  %v3963 = load i64, ptr %slot678, align 8
  %v3964 = load i64, ptr %slot653, align 8
  %p3965 = inttoptr i64 %v3964 to ptr
  store i64 %v3963, ptr %p3965, align 8, !alias.scope !6, !noalias !7
  %v3966 = load i64, ptr %slot37, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  store i64 1, ptr %p3967, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done798
bb_buf_refused798:
  %v3968 = load i64, ptr %slot37, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  store i64 0, ptr %p3969, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done798
bb_buf_done798:
  %v3970 = load i64, ptr %slot16, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  %ld3972 = load i32, ptr %p3971, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3972, ptr %slot679, align 8
  %v3973 = load i32, ptr %slot679, align 8
  %cv3974 = zext i32 %v3973 to i64
  %cond3975 = icmp ne i64 %cv3974, 0
  br i1 %cond3975, label %bb_rcslotdrop824, label %bb_rcslotdone824
bb_rcslotdrop824:
  %v3976 = load i64, ptr %slot16, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  store i32 0, ptr %p3977, align 4, !alias.scope !3, !noalias !4
  %v3978 = load i64, ptr %slot22, align 8
  store i64 %v3978, ptr %slot680, align 8
  %v3979 = load i64, ptr %slot17, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  %ld3981 = load i32, ptr %p3980, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3981, ptr %slot681, align 8
  %v3982 = load i32, ptr %slot681, align 8
  %op3983 = and i32 %v3982, 28
  store i32 %op3983, ptr %slot682, align 8
  %v3984 = load i32, ptr %slot682, align 8
  %cv3985 = zext i32 %v3984 to i64
  %cond3986 = icmp ne i64 %cv3985, 0
  br i1 %cond3986, label %bb_rcslotrole824, label %bb_rcslotowner824
bb_rcslotrole824:
  %v3987 = load i64, ptr %slot46, align 8
  store i64 %v3987, ptr %slot683, align 8
  %v3988 = load i64, ptr %slot680, align 8
  %p3989 = inttoptr i64 %v3988 to ptr
  %ld3990 = load i64, ptr %p3989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3990, ptr %slot684, align 8
  %v3991 = load i64, ptr %slot684, align 8
  %cmp3992 = icmp ne i64 %v3991, 0
  %cv3993 = zext i1 %cmp3992 to i32
  store i32 %cv3993, ptr %slot685, align 8
  %v3994 = load i32, ptr %slot685, align 8
  %cv3995 = zext i32 %v3994 to i64
  %cond3996 = icmp ne i64 %cv3995, 0
  br i1 %cond3996, label %bb_rcgnn840, label %bb_rcgdone840
bb_rcgnn840:
  %v3997 = load i64, ptr %slot684, align 8
  %op3998 = sub i64 %v3997, 16
  store i64 %op3998, ptr %slot686, align 8
  %v3999 = load i64, ptr %slot684, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  %rgep4001 = getelementptr i8, ptr %p4000, i64 -16
  %ld4002 = load i64, ptr %rgep4001, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4002, ptr %slot687, align 8
  %v4003 = load i64, ptr %slot687, align 8
  %op4004 = and i64 %v4003, 4611686018427387906
  store i64 %op4004, ptr %slot688, align 8
  %v4005 = load i64, ptr %slot688, align 8
  %cmp4006 = icmp ne i64 %v4005, 0
  %cv4007 = zext i1 %cmp4006 to i32
  store i32 %cv4007, ptr %slot689, align 8
  %v4008 = load i32, ptr %slot689, align 8
  %cv4009 = zext i32 %v4008 to i64
  %cond4010 = icmp ne i64 %cv4009, 0
  br i1 %cond4010, label %bb_rcgclear840, label %bb_rcgcounted840
bb_rcgcounted840:
  %v4011 = load i64, ptr %slot684, align 8
  %op4012 = sub i64 %v4011, 24
  store i64 %op4012, ptr %slot690, align 8
  %v4013 = load i64, ptr %slot684, align 8
  %p4014 = inttoptr i64 %v4013 to ptr
  %rgep4015 = getelementptr i8, ptr %p4014, i64 -24
  %ld4016 = load i64, ptr %rgep4015, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4016, ptr %slot691, align 8
  %v4017 = load i64, ptr %slot691, align 8
  %op4018 = sub i64 %v4017, 1
  store i64 %op4018, ptr %slot692, align 8
  %v4019 = load i64, ptr %slot692, align 8
  %cmp4020 = icmp eq i64 %v4019, 0
  %cv4021 = zext i1 %cmp4020 to i32
  store i32 %cv4021, ptr %slot693, align 8
  %v4022 = load i32, ptr %slot693, align 8
  %cv4023 = zext i32 %v4022 to i64
  %cond4024 = icmp ne i64 %cv4023, 0
  br i1 %cond4024, label %bb_rcglast840, label %bb_rcgdec840
bb_rcglast840:
  %v4025 = load i64, ptr %slot684, align 8
  %op4026 = sub i64 %v4025, 32
  store i64 %op4026, ptr %slot694, align 8
  %v4027 = load i64, ptr %slot684, align 8
  %p4028 = inttoptr i64 %v4027 to ptr
  %rgep4029 = getelementptr i8, ptr %p4028, i64 -32
  %ld4030 = load i64, ptr %rgep4029, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4030, ptr %slot695, align 8
  %v4031 = load i64, ptr %slot695, align 8
  %cmp4032 = icmp ne i64 %v4031, 0
  %cv4033 = zext i1 %cmp4032 to i32
  store i32 %cv4033, ptr %slot696, align 8
  %v4034 = load i32, ptr %slot696, align 8
  %cv4035 = zext i32 %v4034 to i64
  %cond4036 = icmp ne i64 %cv4035, 0
  br i1 %cond4036, label %bb_rcgdec840, label %bb_rcgslow840
bb_rcgslow840:
  %v4037 = load i64, ptr %slot683, align 8
  %v4038 = load i64, ptr %slot680, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4037, i64 %v4038) nomerge, !dbg !134
  br label %bb_rcgdone840
bb_rcgdec840:
  %v4039 = load i64, ptr %slot692, align 8
  %v4040 = load i64, ptr %slot684, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %rgep4042 = getelementptr i8, ptr %p4041, i64 -24
  store i64 %v4039, ptr %rgep4042, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear840
bb_rcgclear840:
  %v4043 = load i64, ptr %slot680, align 8
  %p4044 = inttoptr i64 %v4043 to ptr
  store i64 0, ptr %p4044, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone840
bb_rcgdone840:
  br label %bb_rcslotdone824
bb_rcslotowner824:
  %v4045 = load i64, ptr %slot46, align 8
  store i64 %v4045, ptr %slot697, align 8
  %v4046 = load i64, ptr %slot680, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  %ld4048 = load i64, ptr %p4047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4048, ptr %slot698, align 8
  %v4049 = load i64, ptr %slot698, align 8
  %cmp4050 = icmp ne i64 %v4049, 0
  %cv4051 = zext i1 %cmp4050 to i32
  store i32 %cv4051, ptr %slot699, align 8
  %v4052 = load i32, ptr %slot699, align 8
  %cv4053 = zext i32 %v4052 to i64
  %cond4054 = icmp ne i64 %cv4053, 0
  br i1 %cond4054, label %bb_rcgnn855, label %bb_rcgdone855
bb_rcgnn855:
  %v4055 = load i64, ptr %slot698, align 8
  %op4056 = sub i64 %v4055, 16
  store i64 %op4056, ptr %slot700, align 8
  %v4057 = load i64, ptr %slot698, align 8
  %p4058 = inttoptr i64 %v4057 to ptr
  %rgep4059 = getelementptr i8, ptr %p4058, i64 -16
  %ld4060 = load i64, ptr %rgep4059, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4060, ptr %slot701, align 8
  %v4061 = load i64, ptr %slot701, align 8
  %op4062 = and i64 %v4061, 4611686018427387906
  store i64 %op4062, ptr %slot702, align 8
  %v4063 = load i64, ptr %slot702, align 8
  %cmp4064 = icmp ne i64 %v4063, 0
  %cv4065 = zext i1 %cmp4064 to i32
  store i32 %cv4065, ptr %slot703, align 8
  %v4066 = load i32, ptr %slot703, align 8
  %cv4067 = zext i32 %v4066 to i64
  %cond4068 = icmp ne i64 %cv4067, 0
  br i1 %cond4068, label %bb_rcgclear855, label %bb_rcgcounted855
bb_rcgcounted855:
  %v4069 = load i64, ptr %slot698, align 8
  %op4070 = sub i64 %v4069, 32
  store i64 %op4070, ptr %slot704, align 8
  %v4071 = load i64, ptr %slot698, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  %rgep4073 = getelementptr i8, ptr %p4072, i64 -32
  %ld4074 = load i64, ptr %rgep4073, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4074, ptr %slot705, align 8
  %v4075 = load i64, ptr %slot705, align 8
  %op4076 = sub i64 %v4075, 1
  store i64 %op4076, ptr %slot706, align 8
  %v4077 = load i64, ptr %slot706, align 8
  %cmp4078 = icmp eq i64 %v4077, 0
  %cv4079 = zext i1 %cmp4078 to i32
  store i32 %cv4079, ptr %slot707, align 8
  %v4080 = load i32, ptr %slot707, align 8
  %cv4081 = zext i32 %v4080 to i64
  %cond4082 = icmp ne i64 %cv4081, 0
  br i1 %cond4082, label %bb_rcglast855, label %bb_rcgdec855
bb_rcglast855:
  %v4083 = load i64, ptr %slot698, align 8
  %op4084 = sub i64 %v4083, 24
  store i64 %op4084, ptr %slot708, align 8
  %v4085 = load i64, ptr %slot698, align 8
  %p4086 = inttoptr i64 %v4085 to ptr
  %rgep4087 = getelementptr i8, ptr %p4086, i64 -24
  %ld4088 = load i64, ptr %rgep4087, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4088, ptr %slot709, align 8
  %v4089 = load i64, ptr %slot709, align 8
  %cmp4090 = icmp ne i64 %v4089, 0
  %cv4091 = zext i1 %cmp4090 to i32
  store i32 %cv4091, ptr %slot710, align 8
  %v4092 = load i32, ptr %slot710, align 8
  %cv4093 = zext i32 %v4092 to i64
  %cond4094 = icmp ne i64 %cv4093, 0
  br i1 %cond4094, label %bb_rcgdec855, label %bb_rcgslow855
bb_rcgslow855:
  %v4095 = load i64, ptr %slot697, align 8
  %v4096 = load i64, ptr %slot680, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4095, i64 %v4096) nomerge, !dbg !134
  br label %bb_rcgdone855
bb_rcgdec855:
  %v4097 = load i64, ptr %slot706, align 8
  %v4098 = load i64, ptr %slot698, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  %rgep4100 = getelementptr i8, ptr %p4099, i64 -32
  store i64 %v4097, ptr %rgep4100, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear855
bb_rcgclear855:
  %v4101 = load i64, ptr %slot680, align 8
  %p4102 = inttoptr i64 %v4101 to ptr
  store i64 0, ptr %p4102, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone855
bb_rcgdone855:
  br label %bb_rcslotdone824
bb_rcslotdone824:
  %p4103 = inttoptr i64 ptrtoint (ptr @myl_lit_fa55d6d54293b9059e02e93d4295af8aaa9991f37463269983996a41e5ac7cae to i64) to ptr
  %ld4104 = load i64, ptr %p4103, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4104, ptr %slot711, align 8
  %v4105 = load i64, ptr %slot711, align 8
  %v4106 = load i64, ptr %slot37, align 8
  %p4107 = inttoptr i64 %v4106 to ptr
  store i64 %v4105, ptr %p4107, align 8, !alias.scope !3, !noalias !4
  %v4108 = load i64, ptr %slot37, align 8
  %p4109 = inttoptr i64 %v4108 to ptr
  %ld4110 = load i64, ptr %p4109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4110, ptr %slot712, align 8
  %v4111 = load i64, ptr %slot712, align 8
  %v4112 = load i64, ptr %slot24, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  store i64 %v4111, ptr %p4113, align 8, !alias.scope !3, !noalias !4
  %v4114 = load i64, ptr %slot24, align 8
  store i64 %v4114, ptr %slot713, align 8
  %v4115 = load i64, ptr %slot26, align 8
  store i64 %v4115, ptr %slot714, align 8
  %v4116 = load i64, ptr %slot713, align 8
  %v4117 = load i64, ptr %slot714, align 8
  %p4118 = inttoptr i64 %v4116 to ptr
  %p4119 = inttoptr i64 %v4117 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4119, ptr %p4118, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4120 = load i64, ptr %slot21, align 8
  %p4121 = inttoptr i64 %v4120 to ptr
  store i32 2, ptr %p4121, align 4, !alias.scope !3, !noalias !4
  %v4122 = load i64, ptr %slot20, align 8
  %p4123 = inttoptr i64 %v4122 to ptr
  store i32 1, ptr %p4123, align 4, !alias.scope !3, !noalias !4
  %v4124 = load i64, ptr %slot22, align 8
  store i64 %v4124, ptr %slot715, align 8
  %v4125 = load i64, ptr %slot26, align 8
  store i64 %v4125, ptr %slot716, align 8
  %v4126 = load i64, ptr %slot716, align 8
  %v4127 = load i64, ptr %slot715, align 8
  %p4128 = inttoptr i64 %v4126 to ptr
  %p4129 = inttoptr i64 %v4127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4129, ptr %p4128, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4130 = load i64, ptr %slot17, align 8
  %p4131 = inttoptr i64 %v4130 to ptr
  store i32 2, ptr %p4131, align 4, !alias.scope !3, !noalias !4
  %v4132 = load i64, ptr %slot21, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  %ld4134 = load i32, ptr %p4133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4134, ptr %slot717, align 8
  %v4135 = load i32, ptr %slot717, align 8
  %v4136 = load i64, ptr %slot17, align 8
  %p4137 = inttoptr i64 %v4136 to ptr
  store i32 %v4135, ptr %p4137, align 4, !alias.scope !3, !noalias !4
  %v4138 = load i64, ptr %slot20, align 8
  %p4139 = inttoptr i64 %v4138 to ptr
  store i32 0, ptr %p4139, align 4, !alias.scope !3, !noalias !4
  %v4140 = load i64, ptr %slot16, align 8
  %p4141 = inttoptr i64 %v4140 to ptr
  store i32 1, ptr %p4141, align 4, !alias.scope !3, !noalias !4
  %v4142 = load i64, ptr %slot715, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  %ld4144 = load i64, ptr %p4143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4144, ptr %slot718, align 8
  %v4145 = load i64, ptr %slot718, align 8
  %v4146 = load i64, ptr %slot37, align 8
  %p4147 = inttoptr i64 %v4146 to ptr
  store i64 %v4145, ptr %p4147, align 8, !alias.scope !3, !noalias !4
  %v4148 = load i64, ptr %slot34, align 8
  store i64 %v4148, ptr %slot719, align 8
  %v4149 = load i64, ptr %slot13, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  store i32 2, ptr %p4150, align 4, !alias.scope !3, !noalias !4
  %v4151 = load i64, ptr %slot719, align 8
  %p4152 = inttoptr i64 %v4151 to ptr
  %ld4153 = load i64, ptr %p4152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4153, ptr %slot720, align 8
  %v4154 = load i64, ptr %slot720, align 8
  %cmp4155 = icmp ne i64 %v4154, 0
  %cv4156 = zext i1 %cmp4155 to i32
  store i32 %cv4156, ptr %slot721, align 8
  %v4157 = load i32, ptr %slot721, align 8
  %cv4158 = zext i32 %v4157 to i64
  %cond4159 = icmp ne i64 %cv4158, 0
  br i1 %cond4159, label %bb_rcguniquenn878, label %bb_rcgunique878
bb_rcguniquenn878:
  %v4160 = load i64, ptr %slot720, align 8
  %op4161 = sub i64 %v4160, 16
  store i64 %op4161, ptr %slot722, align 8
  %v4162 = load i64, ptr %slot720, align 8
  %p4163 = inttoptr i64 %v4162 to ptr
  %rgep4164 = getelementptr i8, ptr %p4163, i64 -16
  %ld4165 = load i64, ptr %rgep4164, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4165, ptr %slot723, align 8
  %v4166 = load i64, ptr %slot723, align 8
  %op4167 = and i64 %v4166, 6917529027641081858
  store i64 %op4167, ptr %slot724, align 8
  %v4168 = load i64, ptr %slot724, align 8
  %cmp4169 = icmp ne i64 %v4168, 0
  %cv4170 = zext i1 %cmp4169 to i32
  store i32 %cv4170, ptr %slot725, align 8
  %v4171 = load i32, ptr %slot725, align 8
  %cv4172 = zext i32 %v4171 to i64
  %cond4173 = icmp ne i64 %cv4172, 0
  br i1 %cond4173, label %bb_rcguniqueslow878, label %bb_rcguniquecount878
bb_rcguniquecount878:
  %v4174 = load i64, ptr %slot720, align 8
  %op4175 = sub i64 %v4174, 32
  store i64 %op4175, ptr %slot726, align 8
  %v4176 = load i64, ptr %slot720, align 8
  %p4177 = inttoptr i64 %v4176 to ptr
  %rgep4178 = getelementptr i8, ptr %p4177, i64 -32
  %ld4179 = load i64, ptr %rgep4178, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4179, ptr %slot727, align 8
  %v4180 = load i64, ptr %slot727, align 8
  %cmp4181 = icmp ult i64 %v4180, 2
  %cv4182 = zext i1 %cmp4181 to i32
  store i32 %cv4182, ptr %slot728, align 8
  %v4183 = load i32, ptr %slot728, align 8
  %cv4184 = zext i32 %v4183 to i64
  %cond4185 = icmp ne i64 %cv4184, 0
  br i1 %cond4185, label %bb_rcgunique878, label %bb_rcguniqueslow878
bb_rcguniqueslow878:
  %v4186 = load i64, ptr %slot1, align 8
  %p4187 = inttoptr i64 %v4186 to ptr
  %p4188 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v4189 = load i64, ptr %slot719, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  %v4191 = load i64, ptr %slot12, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  %call4193 = call i32 @myl_qbe_rc_unique_local(ptr %p4187, ptr %p4188, ptr %p4190, ptr %p4192) nomerge, !dbg !136
  store i32 %call4193, ptr %slot729, align 8
  %v4194 = load i32, ptr %slot729, align 8
  %cv4195 = zext i32 %v4194 to i64
  %cond4196 = icmp ne i64 %cv4195, 0
  br i1 %cond4196, label %bb_rcunique889, label %bb_failure
bb_rcunique889:
  br label %bb_rcgunique878
bb_rcgunique878:
  %v4197 = load i64, ptr %slot34, align 8
  %p4198 = inttoptr i64 %v4197 to ptr
  %ld4199 = load i64, ptr %p4198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4199, ptr %slot730, align 8
  %v4200 = load i64, ptr %slot37, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  %ld4202 = load i64, ptr %p4201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4202, ptr %slot731, align 8
  %v4203 = load i64, ptr %slot46, align 8
  %p4204 = inttoptr i64 %v4203 to ptr
  %v4205 = load i64, ptr %slot730, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  %v4207 = load i64, ptr %slot731, align 8
  %p4208 = inttoptr i64 %v4207 to ptr
  %call4209 = call i32 @myl_native_bytes_buffer_append_utf8(ptr %p4204, ptr %p4206, ptr %p4208) nomerge, !dbg !136
  store i32 %call4209, ptr %slot732, align 8
  %v4210 = load i32, ptr %slot732, align 8
  %ext4211 = zext i32 %v4210 to i64
  store i64 %ext4211, ptr %slot733, align 8
  %v4212 = load i64, ptr %slot733, align 8
  %cmp4213 = icmp ne i64 %v4212, 0
  %cv4214 = zext i1 %cmp4213 to i64
  store i64 %cv4214, ptr %slot734, align 8
  %v4215 = load i64, ptr %slot734, align 8
  %cond4216 = icmp ne i64 %v4215, 0
  br i1 %cond4216, label %bb_success896, label %bb_failed896
bb_failed896:
  %v4217 = load i64, ptr %slot1, align 8
  %p4218 = inttoptr i64 %v4217 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4218) nomerge, !dbg !136
  unreachable
bb_success896:
  %v4219 = load i32, ptr %slot732, align 8
  %cmp4220 = icmp eq i32 %v4219, 1
  %cv4221 = zext i1 %cmp4220 to i32
  store i32 %cv4221, ptr %slot735, align 8
  %v4222 = load i32, ptr %slot735, align 8
  %ext4223 = zext i32 %v4222 to i64
  store i64 %ext4223, ptr %slot736, align 8
  %v4224 = load i64, ptr %slot736, align 8
  %v4225 = load i64, ptr %slot37, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  store i64 %v4224, ptr %p4226, align 8, !alias.scope !3, !noalias !4
  %v4227 = load i64, ptr %slot16, align 8
  %p4228 = inttoptr i64 %v4227 to ptr
  %ld4229 = load i32, ptr %p4228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4229, ptr %slot737, align 8
  %v4230 = load i32, ptr %slot737, align 8
  %cv4231 = zext i32 %v4230 to i64
  %cond4232 = icmp ne i64 %cv4231, 0
  br i1 %cond4232, label %bb_rcslotdrop901, label %bb_rcslotdone901
bb_rcslotdrop901:
  %v4233 = load i64, ptr %slot16, align 8
  %p4234 = inttoptr i64 %v4233 to ptr
  store i32 0, ptr %p4234, align 4, !alias.scope !3, !noalias !4
  %v4235 = load i64, ptr %slot22, align 8
  store i64 %v4235, ptr %slot738, align 8
  %v4236 = load i64, ptr %slot17, align 8
  %p4237 = inttoptr i64 %v4236 to ptr
  %ld4238 = load i32, ptr %p4237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4238, ptr %slot739, align 8
  %v4239 = load i32, ptr %slot739, align 8
  %op4240 = and i32 %v4239, 28
  store i32 %op4240, ptr %slot740, align 8
  %v4241 = load i32, ptr %slot740, align 8
  %cv4242 = zext i32 %v4241 to i64
  %cond4243 = icmp ne i64 %cv4242, 0
  br i1 %cond4243, label %bb_rcslotrole901, label %bb_rcslotowner901
bb_rcslotrole901:
  %v4244 = load i64, ptr %slot46, align 8
  store i64 %v4244, ptr %slot741, align 8
  %v4245 = load i64, ptr %slot738, align 8
  %p4246 = inttoptr i64 %v4245 to ptr
  %ld4247 = load i64, ptr %p4246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4247, ptr %slot742, align 8
  %v4248 = load i64, ptr %slot742, align 8
  %cmp4249 = icmp ne i64 %v4248, 0
  %cv4250 = zext i1 %cmp4249 to i32
  store i32 %cv4250, ptr %slot743, align 8
  %v4251 = load i32, ptr %slot743, align 8
  %cv4252 = zext i32 %v4251 to i64
  %cond4253 = icmp ne i64 %cv4252, 0
  br i1 %cond4253, label %bb_rcgnn917, label %bb_rcgdone917
bb_rcgnn917:
  %v4254 = load i64, ptr %slot742, align 8
  %op4255 = sub i64 %v4254, 16
  store i64 %op4255, ptr %slot744, align 8
  %v4256 = load i64, ptr %slot742, align 8
  %p4257 = inttoptr i64 %v4256 to ptr
  %rgep4258 = getelementptr i8, ptr %p4257, i64 -16
  %ld4259 = load i64, ptr %rgep4258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4259, ptr %slot745, align 8
  %v4260 = load i64, ptr %slot745, align 8
  %op4261 = and i64 %v4260, 4611686018427387906
  store i64 %op4261, ptr %slot746, align 8
  %v4262 = load i64, ptr %slot746, align 8
  %cmp4263 = icmp ne i64 %v4262, 0
  %cv4264 = zext i1 %cmp4263 to i32
  store i32 %cv4264, ptr %slot747, align 8
  %v4265 = load i32, ptr %slot747, align 8
  %cv4266 = zext i32 %v4265 to i64
  %cond4267 = icmp ne i64 %cv4266, 0
  br i1 %cond4267, label %bb_rcgclear917, label %bb_rcgcounted917
bb_rcgcounted917:
  %v4268 = load i64, ptr %slot742, align 8
  %op4269 = sub i64 %v4268, 24
  store i64 %op4269, ptr %slot748, align 8
  %v4270 = load i64, ptr %slot742, align 8
  %p4271 = inttoptr i64 %v4270 to ptr
  %rgep4272 = getelementptr i8, ptr %p4271, i64 -24
  %ld4273 = load i64, ptr %rgep4272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4273, ptr %slot749, align 8
  %v4274 = load i64, ptr %slot749, align 8
  %op4275 = sub i64 %v4274, 1
  store i64 %op4275, ptr %slot750, align 8
  %v4276 = load i64, ptr %slot750, align 8
  %cmp4277 = icmp eq i64 %v4276, 0
  %cv4278 = zext i1 %cmp4277 to i32
  store i32 %cv4278, ptr %slot751, align 8
  %v4279 = load i32, ptr %slot751, align 8
  %cv4280 = zext i32 %v4279 to i64
  %cond4281 = icmp ne i64 %cv4280, 0
  br i1 %cond4281, label %bb_rcglast917, label %bb_rcgdec917
bb_rcglast917:
  %v4282 = load i64, ptr %slot742, align 8
  %op4283 = sub i64 %v4282, 32
  store i64 %op4283, ptr %slot752, align 8
  %v4284 = load i64, ptr %slot742, align 8
  %p4285 = inttoptr i64 %v4284 to ptr
  %rgep4286 = getelementptr i8, ptr %p4285, i64 -32
  %ld4287 = load i64, ptr %rgep4286, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4287, ptr %slot753, align 8
  %v4288 = load i64, ptr %slot753, align 8
  %cmp4289 = icmp ne i64 %v4288, 0
  %cv4290 = zext i1 %cmp4289 to i32
  store i32 %cv4290, ptr %slot754, align 8
  %v4291 = load i32, ptr %slot754, align 8
  %cv4292 = zext i32 %v4291 to i64
  %cond4293 = icmp ne i64 %cv4292, 0
  br i1 %cond4293, label %bb_rcgdec917, label %bb_rcgslow917
bb_rcgslow917:
  %v4294 = load i64, ptr %slot741, align 8
  %v4295 = load i64, ptr %slot738, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v4294, i64 %v4295) nomerge, !dbg !136
  br label %bb_rcgdone917
bb_rcgdec917:
  %v4296 = load i64, ptr %slot750, align 8
  %v4297 = load i64, ptr %slot742, align 8
  %p4298 = inttoptr i64 %v4297 to ptr
  %rgep4299 = getelementptr i8, ptr %p4298, i64 -24
  store i64 %v4296, ptr %rgep4299, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear917
bb_rcgclear917:
  %v4300 = load i64, ptr %slot738, align 8
  %p4301 = inttoptr i64 %v4300 to ptr
  store i64 0, ptr %p4301, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone917
bb_rcgdone917:
  br label %bb_rcslotdone901
bb_rcslotowner901:
  %v4302 = load i64, ptr %slot46, align 8
  store i64 %v4302, ptr %slot755, align 8
  %v4303 = load i64, ptr %slot738, align 8
  %p4304 = inttoptr i64 %v4303 to ptr
  %ld4305 = load i64, ptr %p4304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4305, ptr %slot756, align 8
  %v4306 = load i64, ptr %slot756, align 8
  %cmp4307 = icmp ne i64 %v4306, 0
  %cv4308 = zext i1 %cmp4307 to i32
  store i32 %cv4308, ptr %slot757, align 8
  %v4309 = load i32, ptr %slot757, align 8
  %cv4310 = zext i32 %v4309 to i64
  %cond4311 = icmp ne i64 %cv4310, 0
  br i1 %cond4311, label %bb_rcgnn932, label %bb_rcgdone932
bb_rcgnn932:
  %v4312 = load i64, ptr %slot756, align 8
  %op4313 = sub i64 %v4312, 16
  store i64 %op4313, ptr %slot758, align 8
  %v4314 = load i64, ptr %slot756, align 8
  %p4315 = inttoptr i64 %v4314 to ptr
  %rgep4316 = getelementptr i8, ptr %p4315, i64 -16
  %ld4317 = load i64, ptr %rgep4316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4317, ptr %slot759, align 8
  %v4318 = load i64, ptr %slot759, align 8
  %op4319 = and i64 %v4318, 4611686018427387906
  store i64 %op4319, ptr %slot760, align 8
  %v4320 = load i64, ptr %slot760, align 8
  %cmp4321 = icmp ne i64 %v4320, 0
  %cv4322 = zext i1 %cmp4321 to i32
  store i32 %cv4322, ptr %slot761, align 8
  %v4323 = load i32, ptr %slot761, align 8
  %cv4324 = zext i32 %v4323 to i64
  %cond4325 = icmp ne i64 %cv4324, 0
  br i1 %cond4325, label %bb_rcgclear932, label %bb_rcgcounted932
bb_rcgcounted932:
  %v4326 = load i64, ptr %slot756, align 8
  %op4327 = sub i64 %v4326, 32
  store i64 %op4327, ptr %slot762, align 8
  %v4328 = load i64, ptr %slot756, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  %rgep4330 = getelementptr i8, ptr %p4329, i64 -32
  %ld4331 = load i64, ptr %rgep4330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4331, ptr %slot763, align 8
  %v4332 = load i64, ptr %slot763, align 8
  %op4333 = sub i64 %v4332, 1
  store i64 %op4333, ptr %slot764, align 8
  %v4334 = load i64, ptr %slot764, align 8
  %cmp4335 = icmp eq i64 %v4334, 0
  %cv4336 = zext i1 %cmp4335 to i32
  store i32 %cv4336, ptr %slot765, align 8
  %v4337 = load i32, ptr %slot765, align 8
  %cv4338 = zext i32 %v4337 to i64
  %cond4339 = icmp ne i64 %cv4338, 0
  br i1 %cond4339, label %bb_rcglast932, label %bb_rcgdec932
bb_rcglast932:
  %v4340 = load i64, ptr %slot756, align 8
  %op4341 = sub i64 %v4340, 24
  store i64 %op4341, ptr %slot766, align 8
  %v4342 = load i64, ptr %slot756, align 8
  %p4343 = inttoptr i64 %v4342 to ptr
  %rgep4344 = getelementptr i8, ptr %p4343, i64 -24
  %ld4345 = load i64, ptr %rgep4344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4345, ptr %slot767, align 8
  %v4346 = load i64, ptr %slot767, align 8
  %cmp4347 = icmp ne i64 %v4346, 0
  %cv4348 = zext i1 %cmp4347 to i32
  store i32 %cv4348, ptr %slot768, align 8
  %v4349 = load i32, ptr %slot768, align 8
  %cv4350 = zext i32 %v4349 to i64
  %cond4351 = icmp ne i64 %cv4350, 0
  br i1 %cond4351, label %bb_rcgdec932, label %bb_rcgslow932
bb_rcgslow932:
  %v4352 = load i64, ptr %slot755, align 8
  %v4353 = load i64, ptr %slot738, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v4352, i64 %v4353) nomerge, !dbg !136
  br label %bb_rcgdone932
bb_rcgdec932:
  %v4354 = load i64, ptr %slot764, align 8
  %v4355 = load i64, ptr %slot756, align 8
  %p4356 = inttoptr i64 %v4355 to ptr
  %rgep4357 = getelementptr i8, ptr %p4356, i64 -32
  store i64 %v4354, ptr %rgep4357, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear932
bb_rcgclear932:
  %v4358 = load i64, ptr %slot738, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  store i64 0, ptr %p4359, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone932
bb_rcgdone932:
  br label %bb_rcslotdone901
bb_rcslotdone901:
  %v4360 = load i64, ptr %slot31, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  %ld4362 = load i64, ptr %p4361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4362, ptr %slot769, align 8
  %v4363 = load i64, ptr %slot769, align 8
  %v4364 = load i64, ptr %slot37, align 8
  %p4365 = inttoptr i64 %v4364 to ptr
  store i64 %v4363, ptr %p4365, align 8, !alias.scope !3, !noalias !4
  %v4366 = load i64, ptr %slot38, align 8
  %p4367 = inttoptr i64 %v4366 to ptr
  store i64 0, ptr %p4367, align 8, !alias.scope !3, !noalias !4
  %v4368 = load i64, ptr %slot31, align 8
  %p4369 = inttoptr i64 %v4368 to ptr
  %ld4370 = load i64, ptr %p4369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4370, ptr %slot770, align 8
  %v4371 = load i64, ptr %slot770, align 8
  %v4372 = load i64, ptr %slot39, align 8
  %p4373 = inttoptr i64 %v4372 to ptr
  store i64 %v4371, ptr %p4373, align 8, !alias.scope !3, !noalias !4
  %v4374 = load i64, ptr %slot39, align 8
  %p4375 = inttoptr i64 %v4374 to ptr
  %ld4376 = load i64, ptr %p4375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4376, ptr %slot771, align 8
  %v4377 = load i64, ptr %slot771, align 8
  %p4378 = inttoptr i64 %v4377 to ptr
  %ld4379 = load i64, ptr %p4378, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4379, ptr %slot772, align 8
  %v4380 = load i64, ptr %slot772, align 8
  %v4381 = load i64, ptr %slot39, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  store i64 %v4380, ptr %p4382, align 8, !alias.scope !3, !noalias !4
  %v4383 = load i64, ptr %slot34, align 8
  store i64 %v4383, ptr %slot773, align 8
  %v4384 = load i64, ptr %slot13, align 8
  %p4385 = inttoptr i64 %v4384 to ptr
  store i32 2, ptr %p4385, align 4, !alias.scope !3, !noalias !4
  %v4386 = load i64, ptr %slot773, align 8
  %p4387 = inttoptr i64 %v4386 to ptr
  %ld4388 = load i64, ptr %p4387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4388, ptr %slot774, align 8
  %v4389 = load i64, ptr %slot774, align 8
  %cmp4390 = icmp ne i64 %v4389, 0
  %cv4391 = zext i1 %cmp4390 to i32
  store i32 %cv4391, ptr %slot775, align 8
  %v4392 = load i32, ptr %slot775, align 8
  %cv4393 = zext i32 %v4392 to i64
  %cond4394 = icmp ne i64 %cv4393, 0
  br i1 %cond4394, label %bb_rcguniquenn980, label %bb_rcgunique980
bb_rcguniquenn980:
  %v4395 = load i64, ptr %slot774, align 8
  %op4396 = sub i64 %v4395, 16
  store i64 %op4396, ptr %slot776, align 8
  %v4397 = load i64, ptr %slot774, align 8
  %p4398 = inttoptr i64 %v4397 to ptr
  %rgep4399 = getelementptr i8, ptr %p4398, i64 -16
  %ld4400 = load i64, ptr %rgep4399, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4400, ptr %slot777, align 8
  %v4401 = load i64, ptr %slot777, align 8
  %op4402 = and i64 %v4401, 6917529027641081858
  store i64 %op4402, ptr %slot778, align 8
  %v4403 = load i64, ptr %slot778, align 8
  %cmp4404 = icmp ne i64 %v4403, 0
  %cv4405 = zext i1 %cmp4404 to i32
  store i32 %cv4405, ptr %slot779, align 8
  %v4406 = load i32, ptr %slot779, align 8
  %cv4407 = zext i32 %v4406 to i64
  %cond4408 = icmp ne i64 %cv4407, 0
  br i1 %cond4408, label %bb_rcguniqueslow980, label %bb_rcguniquecount980
bb_rcguniquecount980:
  %v4409 = load i64, ptr %slot774, align 8
  %op4410 = sub i64 %v4409, 32
  store i64 %op4410, ptr %slot780, align 8
  %v4411 = load i64, ptr %slot774, align 8
  %p4412 = inttoptr i64 %v4411 to ptr
  %rgep4413 = getelementptr i8, ptr %p4412, i64 -32
  %ld4414 = load i64, ptr %rgep4413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4414, ptr %slot781, align 8
  %v4415 = load i64, ptr %slot781, align 8
  %cmp4416 = icmp ult i64 %v4415, 2
  %cv4417 = zext i1 %cmp4416 to i32
  store i32 %cv4417, ptr %slot782, align 8
  %v4418 = load i32, ptr %slot782, align 8
  %cv4419 = zext i32 %v4418 to i64
  %cond4420 = icmp ne i64 %cv4419, 0
  br i1 %cond4420, label %bb_rcgunique980, label %bb_rcguniqueslow980
bb_rcguniqueslow980:
  %v4421 = load i64, ptr %slot1, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  %p4423 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v4424 = load i64, ptr %slot773, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  %v4426 = load i64, ptr %slot12, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  %call4428 = call i32 @myl_qbe_rc_unique_local(ptr %p4422, ptr %p4423, ptr %p4425, ptr %p4427) nomerge, !dbg !138
  store i32 %call4428, ptr %slot783, align 8
  %v4429 = load i32, ptr %slot783, align 8
  %cv4430 = zext i32 %v4429 to i64
  %cond4431 = icmp ne i64 %cv4430, 0
  br i1 %cond4431, label %bb_rcunique991, label %bb_failure
bb_rcunique991:
  br label %bb_rcgunique980
bb_rcgunique980:
  %v4432 = load i64, ptr %slot34, align 8
  %p4433 = inttoptr i64 %v4432 to ptr
  %ld4434 = load i64, ptr %p4433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4434, ptr %slot784, align 8
  %v4435 = load i64, ptr %slot37, align 8
  %p4436 = inttoptr i64 %v4435 to ptr
  %ld4437 = load i64, ptr %p4436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4437, ptr %slot785, align 8
  %v4438 = load i64, ptr %slot38, align 8
  %p4439 = inttoptr i64 %v4438 to ptr
  %ld4440 = load i64, ptr %p4439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4440, ptr %slot786, align 8
  %v4441 = load i64, ptr %slot39, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  %ld4443 = load i64, ptr %p4442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4443, ptr %slot787, align 8
  %v4444 = load i64, ptr %slot784, align 8
  %op4445 = add i64 %v4444, 8
  store i64 %op4445, ptr %slot788, align 8
  %v4446 = load i64, ptr %slot786, align 8
  %cmp4447 = icmp sge i64 %v4446, 0
  %cv4448 = zext i1 %cmp4447 to i64
  store i64 %cv4448, ptr %slot789, align 8
  %v4449 = load i64, ptr %slot789, align 8
  %cond4450 = icmp ne i64 %v4449, 0
  br i1 %cond4450, label %bb_buf_start997, label %bb_buf_refused997
bb_buf_start997:
  %v4451 = load i64, ptr %slot786, align 8
  %v4452 = load i64, ptr %slot787, align 8
  %cmp4453 = icmp sle i64 %v4451, %v4452
  %cv4454 = zext i1 %cmp4453 to i64
  store i64 %cv4454, ptr %slot790, align 8
  %v4455 = load i64, ptr %slot790, align 8
  %cond4456 = icmp ne i64 %v4455, 0
  br i1 %cond4456, label %bb_buf_order997, label %bb_buf_refused997
bb_buf_order997:
  %v4457 = load i64, ptr %slot785, align 8
  %p4458 = inttoptr i64 %v4457 to ptr
  %ld4459 = load i64, ptr %p4458, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4459, ptr %slot791, align 8
  %v4460 = load i64, ptr %slot787, align 8
  %v4461 = load i64, ptr %slot791, align 8
  %cmp4462 = icmp ule i64 %v4460, %v4461
  %cv4463 = zext i1 %cmp4462 to i64
  store i64 %cv4463, ptr %slot792, align 8
  %v4464 = load i64, ptr %slot792, align 8
  %cond4465 = icmp ne i64 %v4464, 0
  br i1 %cond4465, label %bb_buf_bound997, label %bb_buf_refused997
bb_buf_bound997:
  %v4466 = load i64, ptr %slot784, align 8
  %p4467 = inttoptr i64 %v4466 to ptr
  %ld4468 = load i64, ptr %p4467, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4468, ptr %slot793, align 8
  %v4469 = load i64, ptr %slot788, align 8
  %p4470 = inttoptr i64 %v4469 to ptr
  %ld4471 = load i64, ptr %p4470, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4471, ptr %slot794, align 8
  %v4472 = load i64, ptr %slot787, align 8
  %v4473 = load i64, ptr %slot786, align 8
  %op4474 = sub i64 %v4472, %v4473
  store i64 %op4474, ptr %slot795, align 8
  %v4475 = load i64, ptr %slot794, align 8
  %v4476 = load i64, ptr %slot793, align 8
  %op4477 = sub i64 %v4475, %v4476
  store i64 %op4477, ptr %slot796, align 8
  %v4478 = load i64, ptr %slot795, align 8
  %v4479 = load i64, ptr %slot796, align 8
  %cmp4480 = icmp ult i64 %v4478, %v4479
  %cv4481 = zext i1 %cmp4480 to i64
  store i64 %cv4481, ptr %slot797, align 8
  %v4482 = load i64, ptr %slot797, align 8
  %cond4483 = icmp ne i64 %v4482, 0
  br i1 %cond4483, label %bb_buf_fast997, label %bb_buf_slow997
bb_buf_slow997:
  %v4484 = load i64, ptr %slot46, align 8
  %p4485 = inttoptr i64 %v4484 to ptr
  %v4486 = load i64, ptr %slot784, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  %v4488 = load i64, ptr %slot785, align 8
  %p4489 = inttoptr i64 %v4488 to ptr
  %v4490 = load i64, ptr %slot786, align 8
  %v4491 = load i64, ptr %slot787, align 8
  %call4492 = call i32 @myl_native_bytes_buffer_append_range(ptr %p4485, ptr %p4487, ptr %p4489, i64 %v4490, i64 %v4491) nomerge, !dbg !138
  store i32 %call4492, ptr %slot798, align 8
  %v4493 = load i32, ptr %slot798, align 8
  %ext4494 = zext i32 %v4493 to i64
  store i64 %ext4494, ptr %slot799, align 8
  %v4495 = load i64, ptr %slot799, align 8
  %cmp4496 = icmp ne i64 %v4495, 0
  %cv4497 = zext i1 %cmp4496 to i64
  store i64 %cv4497, ptr %slot800, align 8
  %v4498 = load i64, ptr %slot800, align 8
  %cond4499 = icmp ne i64 %v4498, 0
  br i1 %cond4499, label %bb_success1011, label %bb_failed1011
bb_failed1011:
  %v4500 = load i64, ptr %slot1, align 8
  %p4501 = inttoptr i64 %v4500 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4501) nomerge, !dbg !138
  unreachable
bb_success1011:
  %v4502 = load i32, ptr %slot798, align 8
  %cmp4503 = icmp eq i32 %v4502, 1
  %cv4504 = zext i1 %cmp4503 to i32
  store i32 %cv4504, ptr %slot801, align 8
  %v4505 = load i32, ptr %slot801, align 8
  %ext4506 = zext i32 %v4505 to i64
  store i64 %ext4506, ptr %slot802, align 8
  %v4507 = load i64, ptr %slot802, align 8
  %v4508 = load i64, ptr %slot37, align 8
  %p4509 = inttoptr i64 %v4508 to ptr
  store i64 %v4507, ptr %p4509, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done997
bb_buf_fast997:
  %v4510 = load i64, ptr %slot784, align 8
  %op4511 = add i64 %v4510, 32
  store i64 %op4511, ptr %slot803, align 8
  %v4512 = load i64, ptr %slot785, align 8
  %op4513 = add i64 %v4512, 32
  store i64 %op4513, ptr %slot804, align 8
  %v4514 = load i64, ptr %slot803, align 8
  %p4515 = inttoptr i64 %v4514 to ptr
  %ld4516 = load i64, ptr %p4515, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4516, ptr %slot805, align 8
  %v4517 = load i64, ptr %slot805, align 8
  %v4518 = load i64, ptr %slot793, align 8
  %op4519 = add i64 %v4517, %v4518
  store i64 %op4519, ptr %slot806, align 8
  %v4520 = load i64, ptr %slot804, align 8
  %p4521 = inttoptr i64 %v4520 to ptr
  %ld4522 = load i64, ptr %p4521, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4522, ptr %slot807, align 8
  %v4523 = load i64, ptr %slot807, align 8
  %v4524 = load i64, ptr %slot786, align 8
  %op4525 = add i64 %v4523, %v4524
  store i64 %op4525, ptr %slot808, align 8
  %v4526 = load i64, ptr %slot806, align 8
  %p4527 = inttoptr i64 %v4526 to ptr
  %v4528 = load i64, ptr %slot808, align 8
  %p4529 = inttoptr i64 %v4528 to ptr
  %v4530 = load i64, ptr %slot795, align 8
  call void @myl_native_bytes_copy_octets(ptr %p4527, ptr %p4529, i64 %v4530) nomerge, !dbg !138
  %v4531 = load i64, ptr %slot793, align 8
  %v4532 = load i64, ptr %slot795, align 8
  %op4533 = add i64 %v4531, %v4532
  store i64 %op4533, ptr %slot809, align 8
  %v4534 = load i64, ptr %slot809, align 8
  %v4535 = load i64, ptr %slot784, align 8
  %p4536 = inttoptr i64 %v4535 to ptr
  store i64 %v4534, ptr %p4536, align 8, !alias.scope !6, !noalias !7
  %v4537 = load i64, ptr %slot37, align 8
  %p4538 = inttoptr i64 %v4537 to ptr
  store i64 1, ptr %p4538, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done997
bb_buf_refused997:
  %v4539 = load i64, ptr %slot37, align 8
  %p4540 = inttoptr i64 %v4539 to ptr
  store i64 0, ptr %p4540, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done997
bb_buf_done997:
  %v4541 = load i64, ptr %slot16, align 8
  %p4542 = inttoptr i64 %v4541 to ptr
  %ld4543 = load i32, ptr %p4542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4543, ptr %slot810, align 8
  %v4544 = load i32, ptr %slot810, align 8
  %cv4545 = zext i32 %v4544 to i64
  %cond4546 = icmp ne i64 %cv4545, 0
  br i1 %cond4546, label %bb_rcslotdrop1023, label %bb_rcslotdone1023
bb_rcslotdrop1023:
  %v4547 = load i64, ptr %slot16, align 8
  %p4548 = inttoptr i64 %v4547 to ptr
  store i32 0, ptr %p4548, align 4, !alias.scope !3, !noalias !4
  %v4549 = load i64, ptr %slot22, align 8
  store i64 %v4549, ptr %slot811, align 8
  %v4550 = load i64, ptr %slot17, align 8
  %p4551 = inttoptr i64 %v4550 to ptr
  %ld4552 = load i32, ptr %p4551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4552, ptr %slot812, align 8
  %v4553 = load i32, ptr %slot812, align 8
  %op4554 = and i32 %v4553, 28
  store i32 %op4554, ptr %slot813, align 8
  %v4555 = load i32, ptr %slot813, align 8
  %cv4556 = zext i32 %v4555 to i64
  %cond4557 = icmp ne i64 %cv4556, 0
  br i1 %cond4557, label %bb_rcslotrole1023, label %bb_rcslotowner1023
bb_rcslotrole1023:
  %v4558 = load i64, ptr %slot46, align 8
  store i64 %v4558, ptr %slot814, align 8
  %v4559 = load i64, ptr %slot811, align 8
  %p4560 = inttoptr i64 %v4559 to ptr
  %ld4561 = load i64, ptr %p4560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4561, ptr %slot815, align 8
  %v4562 = load i64, ptr %slot815, align 8
  %cmp4563 = icmp ne i64 %v4562, 0
  %cv4564 = zext i1 %cmp4563 to i32
  store i32 %cv4564, ptr %slot816, align 8
  %v4565 = load i32, ptr %slot816, align 8
  %cv4566 = zext i32 %v4565 to i64
  %cond4567 = icmp ne i64 %cv4566, 0
  br i1 %cond4567, label %bb_rcgnn1039, label %bb_rcgdone1039
bb_rcgnn1039:
  %v4568 = load i64, ptr %slot815, align 8
  %op4569 = sub i64 %v4568, 16
  store i64 %op4569, ptr %slot817, align 8
  %v4570 = load i64, ptr %slot815, align 8
  %p4571 = inttoptr i64 %v4570 to ptr
  %rgep4572 = getelementptr i8, ptr %p4571, i64 -16
  %ld4573 = load i64, ptr %rgep4572, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4573, ptr %slot818, align 8
  %v4574 = load i64, ptr %slot818, align 8
  %op4575 = and i64 %v4574, 4611686018427387906
  store i64 %op4575, ptr %slot819, align 8
  %v4576 = load i64, ptr %slot819, align 8
  %cmp4577 = icmp ne i64 %v4576, 0
  %cv4578 = zext i1 %cmp4577 to i32
  store i32 %cv4578, ptr %slot820, align 8
  %v4579 = load i32, ptr %slot820, align 8
  %cv4580 = zext i32 %v4579 to i64
  %cond4581 = icmp ne i64 %cv4580, 0
  br i1 %cond4581, label %bb_rcgclear1039, label %bb_rcgcounted1039
bb_rcgcounted1039:
  %v4582 = load i64, ptr %slot815, align 8
  %op4583 = sub i64 %v4582, 24
  store i64 %op4583, ptr %slot821, align 8
  %v4584 = load i64, ptr %slot815, align 8
  %p4585 = inttoptr i64 %v4584 to ptr
  %rgep4586 = getelementptr i8, ptr %p4585, i64 -24
  %ld4587 = load i64, ptr %rgep4586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4587, ptr %slot822, align 8
  %v4588 = load i64, ptr %slot822, align 8
  %op4589 = sub i64 %v4588, 1
  store i64 %op4589, ptr %slot823, align 8
  %v4590 = load i64, ptr %slot823, align 8
  %cmp4591 = icmp eq i64 %v4590, 0
  %cv4592 = zext i1 %cmp4591 to i32
  store i32 %cv4592, ptr %slot824, align 8
  %v4593 = load i32, ptr %slot824, align 8
  %cv4594 = zext i32 %v4593 to i64
  %cond4595 = icmp ne i64 %cv4594, 0
  br i1 %cond4595, label %bb_rcglast1039, label %bb_rcgdec1039
bb_rcglast1039:
  %v4596 = load i64, ptr %slot815, align 8
  %op4597 = sub i64 %v4596, 32
  store i64 %op4597, ptr %slot825, align 8
  %v4598 = load i64, ptr %slot815, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %rgep4600 = getelementptr i8, ptr %p4599, i64 -32
  %ld4601 = load i64, ptr %rgep4600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4601, ptr %slot826, align 8
  %v4602 = load i64, ptr %slot826, align 8
  %cmp4603 = icmp ne i64 %v4602, 0
  %cv4604 = zext i1 %cmp4603 to i32
  store i32 %cv4604, ptr %slot827, align 8
  %v4605 = load i32, ptr %slot827, align 8
  %cv4606 = zext i32 %v4605 to i64
  %cond4607 = icmp ne i64 %cv4606, 0
  br i1 %cond4607, label %bb_rcgdec1039, label %bb_rcgslow1039
bb_rcgslow1039:
  %v4608 = load i64, ptr %slot814, align 8
  %v4609 = load i64, ptr %slot811, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4608, i64 %v4609) nomerge, !dbg !138
  br label %bb_rcgdone1039
bb_rcgdec1039:
  %v4610 = load i64, ptr %slot823, align 8
  %v4611 = load i64, ptr %slot815, align 8
  %p4612 = inttoptr i64 %v4611 to ptr
  %rgep4613 = getelementptr i8, ptr %p4612, i64 -24
  store i64 %v4610, ptr %rgep4613, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1039
bb_rcgclear1039:
  %v4614 = load i64, ptr %slot811, align 8
  %p4615 = inttoptr i64 %v4614 to ptr
  store i64 0, ptr %p4615, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1039
bb_rcgdone1039:
  br label %bb_rcslotdone1023
bb_rcslotowner1023:
  %v4616 = load i64, ptr %slot46, align 8
  store i64 %v4616, ptr %slot828, align 8
  %v4617 = load i64, ptr %slot811, align 8
  %p4618 = inttoptr i64 %v4617 to ptr
  %ld4619 = load i64, ptr %p4618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4619, ptr %slot829, align 8
  %v4620 = load i64, ptr %slot829, align 8
  %cmp4621 = icmp ne i64 %v4620, 0
  %cv4622 = zext i1 %cmp4621 to i32
  store i32 %cv4622, ptr %slot830, align 8
  %v4623 = load i32, ptr %slot830, align 8
  %cv4624 = zext i32 %v4623 to i64
  %cond4625 = icmp ne i64 %cv4624, 0
  br i1 %cond4625, label %bb_rcgnn1054, label %bb_rcgdone1054
bb_rcgnn1054:
  %v4626 = load i64, ptr %slot829, align 8
  %op4627 = sub i64 %v4626, 16
  store i64 %op4627, ptr %slot831, align 8
  %v4628 = load i64, ptr %slot829, align 8
  %p4629 = inttoptr i64 %v4628 to ptr
  %rgep4630 = getelementptr i8, ptr %p4629, i64 -16
  %ld4631 = load i64, ptr %rgep4630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4631, ptr %slot832, align 8
  %v4632 = load i64, ptr %slot832, align 8
  %op4633 = and i64 %v4632, 4611686018427387906
  store i64 %op4633, ptr %slot833, align 8
  %v4634 = load i64, ptr %slot833, align 8
  %cmp4635 = icmp ne i64 %v4634, 0
  %cv4636 = zext i1 %cmp4635 to i32
  store i32 %cv4636, ptr %slot834, align 8
  %v4637 = load i32, ptr %slot834, align 8
  %cv4638 = zext i32 %v4637 to i64
  %cond4639 = icmp ne i64 %cv4638, 0
  br i1 %cond4639, label %bb_rcgclear1054, label %bb_rcgcounted1054
bb_rcgcounted1054:
  %v4640 = load i64, ptr %slot829, align 8
  %op4641 = sub i64 %v4640, 32
  store i64 %op4641, ptr %slot835, align 8
  %v4642 = load i64, ptr %slot829, align 8
  %p4643 = inttoptr i64 %v4642 to ptr
  %rgep4644 = getelementptr i8, ptr %p4643, i64 -32
  %ld4645 = load i64, ptr %rgep4644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4645, ptr %slot836, align 8
  %v4646 = load i64, ptr %slot836, align 8
  %op4647 = sub i64 %v4646, 1
  store i64 %op4647, ptr %slot837, align 8
  %v4648 = load i64, ptr %slot837, align 8
  %cmp4649 = icmp eq i64 %v4648, 0
  %cv4650 = zext i1 %cmp4649 to i32
  store i32 %cv4650, ptr %slot838, align 8
  %v4651 = load i32, ptr %slot838, align 8
  %cv4652 = zext i32 %v4651 to i64
  %cond4653 = icmp ne i64 %cv4652, 0
  br i1 %cond4653, label %bb_rcglast1054, label %bb_rcgdec1054
bb_rcglast1054:
  %v4654 = load i64, ptr %slot829, align 8
  %op4655 = sub i64 %v4654, 24
  store i64 %op4655, ptr %slot839, align 8
  %v4656 = load i64, ptr %slot829, align 8
  %p4657 = inttoptr i64 %v4656 to ptr
  %rgep4658 = getelementptr i8, ptr %p4657, i64 -24
  %ld4659 = load i64, ptr %rgep4658, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4659, ptr %slot840, align 8
  %v4660 = load i64, ptr %slot840, align 8
  %cmp4661 = icmp ne i64 %v4660, 0
  %cv4662 = zext i1 %cmp4661 to i32
  store i32 %cv4662, ptr %slot841, align 8
  %v4663 = load i32, ptr %slot841, align 8
  %cv4664 = zext i32 %v4663 to i64
  %cond4665 = icmp ne i64 %cv4664, 0
  br i1 %cond4665, label %bb_rcgdec1054, label %bb_rcgslow1054
bb_rcgslow1054:
  %v4666 = load i64, ptr %slot828, align 8
  %v4667 = load i64, ptr %slot811, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4666, i64 %v4667) nomerge, !dbg !138
  br label %bb_rcgdone1054
bb_rcgdec1054:
  %v4668 = load i64, ptr %slot837, align 8
  %v4669 = load i64, ptr %slot829, align 8
  %p4670 = inttoptr i64 %v4669 to ptr
  %rgep4671 = getelementptr i8, ptr %p4670, i64 -32
  store i64 %v4668, ptr %rgep4671, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1054
bb_rcgclear1054:
  %v4672 = load i64, ptr %slot811, align 8
  %p4673 = inttoptr i64 %v4672 to ptr
  store i64 0, ptr %p4673, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1054
bb_rcgdone1054:
  br label %bb_rcslotdone1023
bb_rcslotdone1023:
  %v4674 = load i64, ptr %slot27, align 8
  %p4675 = inttoptr i64 %v4674 to ptr
  %ld4676 = load i64, ptr %p4675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4676, ptr %slot842, align 8
  %v4677 = load i64, ptr %slot842, align 8
  %v4678 = load i64, ptr %slot41, align 8
  %p4679 = inttoptr i64 %v4677 to ptr
  %p4680 = inttoptr i64 %v4678 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4680, ptr %p4679, i64 104, i1 false), !alias.scope !10000000
  %v4681 = load i64, ptr %slot41, align 8
  %v4682 = load i64, ptr %slot37, align 8
  %p4683 = inttoptr i64 %v4682 to ptr
  store i64 %v4681, ptr %p4683, align 8, !alias.scope !3, !noalias !4
  %v4684 = load i64, ptr %slot37, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  %ld4686 = load i64, ptr %p4685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4686, ptr %slot843, align 8
  %v4687 = load i64, ptr %slot843, align 8
  %op4688 = add i64 %v4687, 40
  store i64 %op4688, ptr %slot844, align 8
  %v4689 = load i64, ptr %slot844, align 8
  %v4690 = load i64, ptr %slot37, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  store i64 %v4689, ptr %p4691, align 8, !alias.scope !3, !noalias !4
  %v4692 = load i64, ptr %slot14, align 8
  %p4693 = inttoptr i64 %v4692 to ptr
  %ld4694 = load i32, ptr %p4693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4694, ptr %slot845, align 8
  %v4695 = load i32, ptr %slot845, align 8
  %cv4696 = zext i32 %v4695 to i64
  %cond4697 = icmp ne i64 %cv4696, 0
  br i1 %cond4697, label %bb_rcslotdrop1063, label %bb_rcslotdone1063
bb_rcslotdrop1063:
  %v4698 = load i64, ptr %slot14, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  store i32 0, ptr %p4699, align 4, !alias.scope !3, !noalias !4
  %v4700 = load i64, ptr %slot35, align 8
  store i64 %v4700, ptr %slot846, align 8
  %v4701 = load i64, ptr %slot15, align 8
  %p4702 = inttoptr i64 %v4701 to ptr
  %ld4703 = load i32, ptr %p4702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4703, ptr %slot847, align 8
  %v4704 = load i32, ptr %slot847, align 8
  %op4705 = and i32 %v4704, 28
  store i32 %op4705, ptr %slot848, align 8
  %v4706 = load i32, ptr %slot848, align 8
  %cv4707 = zext i32 %v4706 to i64
  %cond4708 = icmp ne i64 %cv4707, 0
  br i1 %cond4708, label %bb_rcslotrole1063, label %bb_rcslotowner1063
bb_rcslotrole1063:
  %v4709 = load i64, ptr %slot46, align 8
  store i64 %v4709, ptr %slot849, align 8
  %v4710 = load i64, ptr %slot849, align 8
  %v4711 = load i64, ptr %slot846, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v4710, i64 %v4711) nomerge, !dbg !140
  br label %bb_rcslotdone1063
bb_rcslotowner1063:
  %v4712 = load i64, ptr %slot46, align 8
  store i64 %v4712, ptr %slot850, align 8
  %v4713 = load i64, ptr %slot850, align 8
  %v4714 = load i64, ptr %slot846, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v4713, i64 %v4714) nomerge, !dbg !140
  br label %bb_rcslotdone1063
bb_rcslotdone1063:
  %v4715 = load i64, ptr %slot27, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  %ld4717 = load i64, ptr %p4716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4717, ptr %slot851, align 8
  %v4718 = load i64, ptr %slot851, align 8
  %op4719 = add i64 %v4718, 40
  store i64 %op4719, ptr %slot852, align 8
  %v4720 = load i64, ptr %slot35, align 8
  store i64 %v4720, ptr %slot853, align 8
  %v4721 = load i64, ptr %slot852, align 8
  %v4722 = load i64, ptr %slot853, align 8
  %p4723 = inttoptr i64 %v4721 to ptr
  %p4724 = inttoptr i64 %v4722 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4724, ptr %p4723, i64 40, i1 false), !alias.scope !10000000
  %v4725 = load i64, ptr %slot852, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  store i64 0, ptr %p4726, align 8, !alias.scope !4, !noalias !3
  %v4727 = load i64, ptr %slot852, align 8
  %op4728 = add i64 %v4727, 8
  store i64 %op4728, ptr %slot854, align 8
  %v4729 = load i64, ptr %slot854, align 8
  %p4730 = inttoptr i64 %v4729 to ptr
  store i64 0, ptr %p4730, align 8, !alias.scope !4, !noalias !3
  %v4731 = load i64, ptr %slot852, align 8
  %op4732 = add i64 %v4731, 16
  store i64 %op4732, ptr %slot855, align 8
  %v4733 = load i64, ptr %slot855, align 8
  %p4734 = inttoptr i64 %v4733 to ptr
  store i64 0, ptr %p4734, align 8, !alias.scope !4, !noalias !3
  %v4735 = load i64, ptr %slot852, align 8
  %op4736 = add i64 %v4735, 24
  store i64 %op4736, ptr %slot856, align 8
  %v4737 = load i64, ptr %slot856, align 8
  %p4738 = inttoptr i64 %v4737 to ptr
  store i64 0, ptr %p4738, align 8, !alias.scope !4, !noalias !3
  %v4739 = load i64, ptr %slot852, align 8
  %op4740 = add i64 %v4739, 32
  store i64 %op4740, ptr %slot857, align 8
  %v4741 = load i64, ptr %slot857, align 8
  %p4742 = inttoptr i64 %v4741 to ptr
  store i64 0, ptr %p4742, align 8, !alias.scope !4, !noalias !3
  %v4743 = load i64, ptr %slot14, align 8
  %p4744 = inttoptr i64 %v4743 to ptr
  store i32 1, ptr %p4744, align 4, !alias.scope !3, !noalias !4
  %v4745 = load i64, ptr %slot35, align 8
  %v4746 = load i64, ptr %slot37, align 8
  %p4747 = inttoptr i64 %v4746 to ptr
  store i64 %v4745, ptr %p4747, align 8, !alias.scope !3, !noalias !4
  %v4748 = load i64, ptr %slot34, align 8
  %p4749 = inttoptr i64 %v4748 to ptr
  %ld4750 = load i64, ptr %p4749, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4750, ptr %slot858, align 8
  %v4751 = load i64, ptr %slot858, align 8
  %v4752 = load i64, ptr %slot38, align 8
  %p4753 = inttoptr i64 %v4752 to ptr
  store i64 %v4751, ptr %p4753, align 8, !alias.scope !3, !noalias !4
  %v4754 = load i64, ptr %slot38, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  %ld4756 = load i64, ptr %p4755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4756, ptr %slot859, align 8
  %v4757 = load i64, ptr %slot1, align 8
  %p4758 = inttoptr i64 %v4757 to ptr
  %v4759 = load i64, ptr %slot859, align 8
  %p4760 = inttoptr i64 %v4759 to ptr
  %call4761 = call ptr @myl_qbe_bytes_snapshot(ptr %p4758, ptr %p4760) nomerge, !dbg !142
  %calladdr4762 = ptrtoint ptr %call4761 to i64
  store i64 %calladdr4762, ptr %slot860, align 8
  %v4763 = load i64, ptr %slot860, align 8
  %v4764 = load i64, ptr %slot38, align 8
  %p4765 = inttoptr i64 %v4764 to ptr
  store i64 %v4763, ptr %p4765, align 8, !alias.scope !3, !noalias !4
  %v4766 = load i64, ptr %slot38, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  %ld4768 = load i64, ptr %p4767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4768, ptr %slot861, align 8
  %v4769 = load i64, ptr %slot861, align 8
  %v4770 = load i64, ptr %slot25, align 8
  %p4771 = inttoptr i64 %v4770 to ptr
  store i64 %v4769, ptr %p4771, align 8, !alias.scope !3, !noalias !4
  %v4772 = load i64, ptr %slot25, align 8
  store i64 %v4772, ptr %slot862, align 8
  %v4773 = load i64, ptr %slot26, align 8
  store i64 %v4773, ptr %slot863, align 8
  %v4774 = load i64, ptr %slot862, align 8
  %v4775 = load i64, ptr %slot863, align 8
  %p4776 = inttoptr i64 %v4774 to ptr
  %p4777 = inttoptr i64 %v4775 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4777, ptr %p4776, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4778 = load i64, ptr %slot21, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  store i32 2, ptr %p4779, align 4, !alias.scope !3, !noalias !4
  %v4780 = load i64, ptr %slot20, align 8
  %p4781 = inttoptr i64 %v4780 to ptr
  store i32 1, ptr %p4781, align 4, !alias.scope !3, !noalias !4
  %v4782 = load i64, ptr %slot18, align 8
  %p4783 = inttoptr i64 %v4782 to ptr
  %ld4784 = load i32, ptr %p4783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4784, ptr %slot864, align 8
  %v4785 = load i32, ptr %slot864, align 8
  %cv4786 = zext i32 %v4785 to i64
  %cond4787 = icmp ne i64 %cv4786, 0
  br i1 %cond4787, label %bb_rcslotdrop1088, label %bb_rcslotdone1088
bb_rcslotdrop1088:
  %v4788 = load i64, ptr %slot18, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  store i32 0, ptr %p4789, align 4, !alias.scope !3, !noalias !4
  %v4790 = load i64, ptr %slot23, align 8
  store i64 %v4790, ptr %slot865, align 8
  %v4791 = load i64, ptr %slot19, align 8
  %p4792 = inttoptr i64 %v4791 to ptr
  %ld4793 = load i32, ptr %p4792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4793, ptr %slot866, align 8
  %v4794 = load i32, ptr %slot866, align 8
  %op4795 = and i32 %v4794, 28
  store i32 %op4795, ptr %slot867, align 8
  %v4796 = load i32, ptr %slot867, align 8
  %cv4797 = zext i32 %v4796 to i64
  %cond4798 = icmp ne i64 %cv4797, 0
  br i1 %cond4798, label %bb_rcslotrole1088, label %bb_rcslotowner1088
bb_rcslotrole1088:
  %v4799 = load i64, ptr %slot46, align 8
  store i64 %v4799, ptr %slot868, align 8
  %v4800 = load i64, ptr %slot865, align 8
  %p4801 = inttoptr i64 %v4800 to ptr
  %ld4802 = load i64, ptr %p4801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4802, ptr %slot869, align 8
  %v4803 = load i64, ptr %slot869, align 8
  %cmp4804 = icmp ne i64 %v4803, 0
  %cv4805 = zext i1 %cmp4804 to i32
  store i32 %cv4805, ptr %slot870, align 8
  %v4806 = load i32, ptr %slot870, align 8
  %cv4807 = zext i32 %v4806 to i64
  %cond4808 = icmp ne i64 %cv4807, 0
  br i1 %cond4808, label %bb_rcgnn1104, label %bb_rcgdone1104
bb_rcgnn1104:
  %v4809 = load i64, ptr %slot869, align 8
  %op4810 = sub i64 %v4809, 16
  store i64 %op4810, ptr %slot871, align 8
  %v4811 = load i64, ptr %slot869, align 8
  %p4812 = inttoptr i64 %v4811 to ptr
  %rgep4813 = getelementptr i8, ptr %p4812, i64 -16
  %ld4814 = load i64, ptr %rgep4813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4814, ptr %slot872, align 8
  %v4815 = load i64, ptr %slot872, align 8
  %op4816 = and i64 %v4815, 4611686018427387906
  store i64 %op4816, ptr %slot873, align 8
  %v4817 = load i64, ptr %slot873, align 8
  %cmp4818 = icmp ne i64 %v4817, 0
  %cv4819 = zext i1 %cmp4818 to i32
  store i32 %cv4819, ptr %slot874, align 8
  %v4820 = load i32, ptr %slot874, align 8
  %cv4821 = zext i32 %v4820 to i64
  %cond4822 = icmp ne i64 %cv4821, 0
  br i1 %cond4822, label %bb_rcgclear1104, label %bb_rcgcounted1104
bb_rcgcounted1104:
  %v4823 = load i64, ptr %slot869, align 8
  %op4824 = sub i64 %v4823, 24
  store i64 %op4824, ptr %slot875, align 8
  %v4825 = load i64, ptr %slot869, align 8
  %p4826 = inttoptr i64 %v4825 to ptr
  %rgep4827 = getelementptr i8, ptr %p4826, i64 -24
  %ld4828 = load i64, ptr %rgep4827, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4828, ptr %slot876, align 8
  %v4829 = load i64, ptr %slot876, align 8
  %op4830 = sub i64 %v4829, 1
  store i64 %op4830, ptr %slot877, align 8
  %v4831 = load i64, ptr %slot877, align 8
  %cmp4832 = icmp eq i64 %v4831, 0
  %cv4833 = zext i1 %cmp4832 to i32
  store i32 %cv4833, ptr %slot878, align 8
  %v4834 = load i32, ptr %slot878, align 8
  %cv4835 = zext i32 %v4834 to i64
  %cond4836 = icmp ne i64 %cv4835, 0
  br i1 %cond4836, label %bb_rcglast1104, label %bb_rcgdec1104
bb_rcglast1104:
  %v4837 = load i64, ptr %slot869, align 8
  %op4838 = sub i64 %v4837, 32
  store i64 %op4838, ptr %slot879, align 8
  %v4839 = load i64, ptr %slot869, align 8
  %p4840 = inttoptr i64 %v4839 to ptr
  %rgep4841 = getelementptr i8, ptr %p4840, i64 -32
  %ld4842 = load i64, ptr %rgep4841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4842, ptr %slot880, align 8
  %v4843 = load i64, ptr %slot880, align 8
  %cmp4844 = icmp ne i64 %v4843, 0
  %cv4845 = zext i1 %cmp4844 to i32
  store i32 %cv4845, ptr %slot881, align 8
  %v4846 = load i32, ptr %slot881, align 8
  %cv4847 = zext i32 %v4846 to i64
  %cond4848 = icmp ne i64 %cv4847, 0
  br i1 %cond4848, label %bb_rcgdec1104, label %bb_rcgslow1104
bb_rcgslow1104:
  %v4849 = load i64, ptr %slot868, align 8
  %v4850 = load i64, ptr %slot865, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v4849, i64 %v4850) nomerge, !dbg !142
  br label %bb_rcgdone1104
bb_rcgdec1104:
  %v4851 = load i64, ptr %slot877, align 8
  %v4852 = load i64, ptr %slot869, align 8
  %p4853 = inttoptr i64 %v4852 to ptr
  %rgep4854 = getelementptr i8, ptr %p4853, i64 -24
  store i64 %v4851, ptr %rgep4854, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1104
bb_rcgclear1104:
  %v4855 = load i64, ptr %slot865, align 8
  %p4856 = inttoptr i64 %v4855 to ptr
  store i64 0, ptr %p4856, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1104
bb_rcgdone1104:
  br label %bb_rcslotdone1088
bb_rcslotowner1088:
  %v4857 = load i64, ptr %slot46, align 8
  store i64 %v4857, ptr %slot882, align 8
  %v4858 = load i64, ptr %slot865, align 8
  %p4859 = inttoptr i64 %v4858 to ptr
  %ld4860 = load i64, ptr %p4859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4860, ptr %slot883, align 8
  %v4861 = load i64, ptr %slot883, align 8
  %cmp4862 = icmp ne i64 %v4861, 0
  %cv4863 = zext i1 %cmp4862 to i32
  store i32 %cv4863, ptr %slot884, align 8
  %v4864 = load i32, ptr %slot884, align 8
  %cv4865 = zext i32 %v4864 to i64
  %cond4866 = icmp ne i64 %cv4865, 0
  br i1 %cond4866, label %bb_rcgnn1119, label %bb_rcgdone1119
bb_rcgnn1119:
  %v4867 = load i64, ptr %slot883, align 8
  %op4868 = sub i64 %v4867, 16
  store i64 %op4868, ptr %slot885, align 8
  %v4869 = load i64, ptr %slot883, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  %rgep4871 = getelementptr i8, ptr %p4870, i64 -16
  %ld4872 = load i64, ptr %rgep4871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4872, ptr %slot886, align 8
  %v4873 = load i64, ptr %slot886, align 8
  %op4874 = and i64 %v4873, 4611686018427387906
  store i64 %op4874, ptr %slot887, align 8
  %v4875 = load i64, ptr %slot887, align 8
  %cmp4876 = icmp ne i64 %v4875, 0
  %cv4877 = zext i1 %cmp4876 to i32
  store i32 %cv4877, ptr %slot888, align 8
  %v4878 = load i32, ptr %slot888, align 8
  %cv4879 = zext i32 %v4878 to i64
  %cond4880 = icmp ne i64 %cv4879, 0
  br i1 %cond4880, label %bb_rcgclear1119, label %bb_rcgcounted1119
bb_rcgcounted1119:
  %v4881 = load i64, ptr %slot883, align 8
  %op4882 = sub i64 %v4881, 32
  store i64 %op4882, ptr %slot889, align 8
  %v4883 = load i64, ptr %slot883, align 8
  %p4884 = inttoptr i64 %v4883 to ptr
  %rgep4885 = getelementptr i8, ptr %p4884, i64 -32
  %ld4886 = load i64, ptr %rgep4885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4886, ptr %slot890, align 8
  %v4887 = load i64, ptr %slot890, align 8
  %op4888 = sub i64 %v4887, 1
  store i64 %op4888, ptr %slot891, align 8
  %v4889 = load i64, ptr %slot891, align 8
  %cmp4890 = icmp eq i64 %v4889, 0
  %cv4891 = zext i1 %cmp4890 to i32
  store i32 %cv4891, ptr %slot892, align 8
  %v4892 = load i32, ptr %slot892, align 8
  %cv4893 = zext i32 %v4892 to i64
  %cond4894 = icmp ne i64 %cv4893, 0
  br i1 %cond4894, label %bb_rcglast1119, label %bb_rcgdec1119
bb_rcglast1119:
  %v4895 = load i64, ptr %slot883, align 8
  %op4896 = sub i64 %v4895, 24
  store i64 %op4896, ptr %slot893, align 8
  %v4897 = load i64, ptr %slot883, align 8
  %p4898 = inttoptr i64 %v4897 to ptr
  %rgep4899 = getelementptr i8, ptr %p4898, i64 -24
  %ld4900 = load i64, ptr %rgep4899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4900, ptr %slot894, align 8
  %v4901 = load i64, ptr %slot894, align 8
  %cmp4902 = icmp ne i64 %v4901, 0
  %cv4903 = zext i1 %cmp4902 to i32
  store i32 %cv4903, ptr %slot895, align 8
  %v4904 = load i32, ptr %slot895, align 8
  %cv4905 = zext i32 %v4904 to i64
  %cond4906 = icmp ne i64 %cv4905, 0
  br i1 %cond4906, label %bb_rcgdec1119, label %bb_rcgslow1119
bb_rcgslow1119:
  %v4907 = load i64, ptr %slot882, align 8
  %v4908 = load i64, ptr %slot865, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v4907, i64 %v4908) nomerge, !dbg !142
  br label %bb_rcgdone1119
bb_rcgdec1119:
  %v4909 = load i64, ptr %slot891, align 8
  %v4910 = load i64, ptr %slot883, align 8
  %p4911 = inttoptr i64 %v4910 to ptr
  %rgep4912 = getelementptr i8, ptr %p4911, i64 -32
  store i64 %v4909, ptr %rgep4912, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1119
bb_rcgclear1119:
  %v4913 = load i64, ptr %slot865, align 8
  %p4914 = inttoptr i64 %v4913 to ptr
  store i64 0, ptr %p4914, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1119
bb_rcgdone1119:
  br label %bb_rcslotdone1088
bb_rcslotdone1088:
  %v4915 = load i64, ptr %slot23, align 8
  store i64 %v4915, ptr %slot896, align 8
  %v4916 = load i64, ptr %slot26, align 8
  store i64 %v4916, ptr %slot897, align 8
  %v4917 = load i64, ptr %slot897, align 8
  %v4918 = load i64, ptr %slot896, align 8
  %p4919 = inttoptr i64 %v4917 to ptr
  %p4920 = inttoptr i64 %v4918 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4920, ptr %p4919, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4921 = load i64, ptr %slot19, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  store i32 2, ptr %p4922, align 4, !alias.scope !3, !noalias !4
  %v4923 = load i64, ptr %slot21, align 8
  %p4924 = inttoptr i64 %v4923 to ptr
  %ld4925 = load i32, ptr %p4924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4925, ptr %slot898, align 8
  %v4926 = load i32, ptr %slot898, align 8
  %v4927 = load i64, ptr %slot19, align 8
  %p4928 = inttoptr i64 %v4927 to ptr
  store i32 %v4926, ptr %p4928, align 4, !alias.scope !3, !noalias !4
  %v4929 = load i64, ptr %slot20, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  store i32 0, ptr %p4930, align 4, !alias.scope !3, !noalias !4
  %v4931 = load i64, ptr %slot18, align 8
  %p4932 = inttoptr i64 %v4931 to ptr
  store i32 1, ptr %p4932, align 4, !alias.scope !3, !noalias !4
  %v4933 = load i64, ptr %slot896, align 8
  %p4934 = inttoptr i64 %v4933 to ptr
  %ld4935 = load i64, ptr %p4934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4935, ptr %slot899, align 8
  %v4936 = load i64, ptr %slot899, align 8
  %v4937 = load i64, ptr %slot38, align 8
  %p4938 = inttoptr i64 %v4937 to ptr
  store i64 %v4936, ptr %p4938, align 8, !alias.scope !3, !noalias !4
  %v4939 = load i64, ptr %slot37, align 8
  %p4940 = inttoptr i64 %v4939 to ptr
  %ld4941 = load i64, ptr %p4940, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4941, ptr %slot900, align 8
  %v4942 = load i64, ptr %slot38, align 8
  %p4943 = inttoptr i64 %v4942 to ptr
  %ld4944 = load i64, ptr %p4943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4944, ptr %slot901, align 8
  %v4945 = load i64, ptr %slot1, align 8
  %v4946 = load i64, ptr %slot900, align 8
  %v4947 = load i64, ptr %slot901, align 8
  %call4948 = call i64 @myl_f_ce937c0a67fd59c0f261e0a4ab35ebce3e2c051d9627ea0c05a57eafb505b71f(i64 %v4945, i64 %v4946, i64 %v4947) nomerge, !dbg !144
  store i64 %call4948, ptr %slot902, align 8
  %v4949 = load i64, ptr %slot902, align 8
  %v4950 = load i64, ptr %slot37, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  store i64 %v4949, ptr %p4951, align 8, !alias.scope !3, !noalias !4
  %v4952 = load i64, ptr %slot16, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %ld4954 = load i32, ptr %p4953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4954, ptr %slot903, align 8
  %v4955 = load i32, ptr %slot903, align 8
  %cv4956 = zext i32 %v4955 to i64
  %cond4957 = icmp ne i64 %cv4956, 0
  br i1 %cond4957, label %bb_rcslotdrop1137, label %bb_rcslotdone1137
bb_rcslotdrop1137:
  %v4958 = load i64, ptr %slot16, align 8
  %p4959 = inttoptr i64 %v4958 to ptr
  store i32 0, ptr %p4959, align 4, !alias.scope !3, !noalias !4
  %v4960 = load i64, ptr %slot22, align 8
  store i64 %v4960, ptr %slot904, align 8
  %v4961 = load i64, ptr %slot17, align 8
  %p4962 = inttoptr i64 %v4961 to ptr
  %ld4963 = load i32, ptr %p4962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4963, ptr %slot905, align 8
  %v4964 = load i32, ptr %slot905, align 8
  %op4965 = and i32 %v4964, 28
  store i32 %op4965, ptr %slot906, align 8
  %v4966 = load i32, ptr %slot906, align 8
  %cv4967 = zext i32 %v4966 to i64
  %cond4968 = icmp ne i64 %cv4967, 0
  br i1 %cond4968, label %bb_rcslotrole1137, label %bb_rcslotowner1137
bb_rcslotrole1137:
  %v4969 = load i64, ptr %slot46, align 8
  store i64 %v4969, ptr %slot907, align 8
  %v4970 = load i64, ptr %slot907, align 8
  %v4971 = load i64, ptr %slot904, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v4970, i64 %v4971) nomerge, !dbg !144
  br label %bb_rcslotdone1137
bb_rcslotowner1137:
  %v4972 = load i64, ptr %slot46, align 8
  store i64 %v4972, ptr %slot908, align 8
  %v4973 = load i64, ptr %slot908, align 8
  %v4974 = load i64, ptr %slot904, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v4973, i64 %v4974) nomerge, !dbg !144
  br label %bb_rcslotdone1137
bb_rcslotdone1137:
  %v4975 = load i64, ptr %slot18, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  %ld4977 = load i32, ptr %p4976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4977, ptr %slot909, align 8
  %v4978 = load i32, ptr %slot909, align 8
  %cv4979 = zext i32 %v4978 to i64
  %cond4980 = icmp ne i64 %cv4979, 0
  br i1 %cond4980, label %bb_rcslotdrop1146, label %bb_rcslotdone1146
bb_rcslotdrop1146:
  %v4981 = load i64, ptr %slot18, align 8
  %p4982 = inttoptr i64 %v4981 to ptr
  store i32 0, ptr %p4982, align 4, !alias.scope !3, !noalias !4
  %v4983 = load i64, ptr %slot23, align 8
  store i64 %v4983, ptr %slot910, align 8
  %v4984 = load i64, ptr %slot19, align 8
  %p4985 = inttoptr i64 %v4984 to ptr
  %ld4986 = load i32, ptr %p4985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4986, ptr %slot911, align 8
  %v4987 = load i32, ptr %slot911, align 8
  %op4988 = and i32 %v4987, 28
  store i32 %op4988, ptr %slot912, align 8
  %v4989 = load i32, ptr %slot912, align 8
  %cv4990 = zext i32 %v4989 to i64
  %cond4991 = icmp ne i64 %cv4990, 0
  br i1 %cond4991, label %bb_rcslotrole1146, label %bb_rcslotowner1146
bb_rcslotrole1146:
  %v4992 = load i64, ptr %slot46, align 8
  store i64 %v4992, ptr %slot913, align 8
  %v4993 = load i64, ptr %slot910, align 8
  %p4994 = inttoptr i64 %v4993 to ptr
  %ld4995 = load i64, ptr %p4994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4995, ptr %slot914, align 8
  %v4996 = load i64, ptr %slot914, align 8
  %cmp4997 = icmp ne i64 %v4996, 0
  %cv4998 = zext i1 %cmp4997 to i32
  store i32 %cv4998, ptr %slot915, align 8
  %v4999 = load i32, ptr %slot915, align 8
  %cv5000 = zext i32 %v4999 to i64
  %cond5001 = icmp ne i64 %cv5000, 0
  br i1 %cond5001, label %bb_rcgnn1162, label %bb_rcgdone1162
bb_rcgnn1162:
  %v5002 = load i64, ptr %slot914, align 8
  %op5003 = sub i64 %v5002, 16
  store i64 %op5003, ptr %slot916, align 8
  %v5004 = load i64, ptr %slot914, align 8
  %p5005 = inttoptr i64 %v5004 to ptr
  %rgep5006 = getelementptr i8, ptr %p5005, i64 -16
  %ld5007 = load i64, ptr %rgep5006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5007, ptr %slot917, align 8
  %v5008 = load i64, ptr %slot917, align 8
  %op5009 = and i64 %v5008, 4611686018427387906
  store i64 %op5009, ptr %slot918, align 8
  %v5010 = load i64, ptr %slot918, align 8
  %cmp5011 = icmp ne i64 %v5010, 0
  %cv5012 = zext i1 %cmp5011 to i32
  store i32 %cv5012, ptr %slot919, align 8
  %v5013 = load i32, ptr %slot919, align 8
  %cv5014 = zext i32 %v5013 to i64
  %cond5015 = icmp ne i64 %cv5014, 0
  br i1 %cond5015, label %bb_rcgclear1162, label %bb_rcgcounted1162
bb_rcgcounted1162:
  %v5016 = load i64, ptr %slot914, align 8
  %op5017 = sub i64 %v5016, 24
  store i64 %op5017, ptr %slot920, align 8
  %v5018 = load i64, ptr %slot914, align 8
  %p5019 = inttoptr i64 %v5018 to ptr
  %rgep5020 = getelementptr i8, ptr %p5019, i64 -24
  %ld5021 = load i64, ptr %rgep5020, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5021, ptr %slot921, align 8
  %v5022 = load i64, ptr %slot921, align 8
  %op5023 = sub i64 %v5022, 1
  store i64 %op5023, ptr %slot922, align 8
  %v5024 = load i64, ptr %slot922, align 8
  %cmp5025 = icmp eq i64 %v5024, 0
  %cv5026 = zext i1 %cmp5025 to i32
  store i32 %cv5026, ptr %slot923, align 8
  %v5027 = load i32, ptr %slot923, align 8
  %cv5028 = zext i32 %v5027 to i64
  %cond5029 = icmp ne i64 %cv5028, 0
  br i1 %cond5029, label %bb_rcglast1162, label %bb_rcgdec1162
bb_rcglast1162:
  %v5030 = load i64, ptr %slot914, align 8
  %op5031 = sub i64 %v5030, 32
  store i64 %op5031, ptr %slot924, align 8
  %v5032 = load i64, ptr %slot914, align 8
  %p5033 = inttoptr i64 %v5032 to ptr
  %rgep5034 = getelementptr i8, ptr %p5033, i64 -32
  %ld5035 = load i64, ptr %rgep5034, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5035, ptr %slot925, align 8
  %v5036 = load i64, ptr %slot925, align 8
  %cmp5037 = icmp ne i64 %v5036, 0
  %cv5038 = zext i1 %cmp5037 to i32
  store i32 %cv5038, ptr %slot926, align 8
  %v5039 = load i32, ptr %slot926, align 8
  %cv5040 = zext i32 %v5039 to i64
  %cond5041 = icmp ne i64 %cv5040, 0
  br i1 %cond5041, label %bb_rcgdec1162, label %bb_rcgslow1162
bb_rcgslow1162:
  %v5042 = load i64, ptr %slot913, align 8
  %v5043 = load i64, ptr %slot910, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5042, i64 %v5043) nomerge, !dbg !144
  br label %bb_rcgdone1162
bb_rcgdec1162:
  %v5044 = load i64, ptr %slot922, align 8
  %v5045 = load i64, ptr %slot914, align 8
  %p5046 = inttoptr i64 %v5045 to ptr
  %rgep5047 = getelementptr i8, ptr %p5046, i64 -24
  store i64 %v5044, ptr %rgep5047, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1162
bb_rcgclear1162:
  %v5048 = load i64, ptr %slot910, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  store i64 0, ptr %p5049, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1162
bb_rcgdone1162:
  br label %bb_rcslotdone1146
bb_rcslotowner1146:
  %v5050 = load i64, ptr %slot46, align 8
  store i64 %v5050, ptr %slot927, align 8
  %v5051 = load i64, ptr %slot910, align 8
  %p5052 = inttoptr i64 %v5051 to ptr
  %ld5053 = load i64, ptr %p5052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5053, ptr %slot928, align 8
  %v5054 = load i64, ptr %slot928, align 8
  %cmp5055 = icmp ne i64 %v5054, 0
  %cv5056 = zext i1 %cmp5055 to i32
  store i32 %cv5056, ptr %slot929, align 8
  %v5057 = load i32, ptr %slot929, align 8
  %cv5058 = zext i32 %v5057 to i64
  %cond5059 = icmp ne i64 %cv5058, 0
  br i1 %cond5059, label %bb_rcgnn1177, label %bb_rcgdone1177
bb_rcgnn1177:
  %v5060 = load i64, ptr %slot928, align 8
  %op5061 = sub i64 %v5060, 16
  store i64 %op5061, ptr %slot930, align 8
  %v5062 = load i64, ptr %slot928, align 8
  %p5063 = inttoptr i64 %v5062 to ptr
  %rgep5064 = getelementptr i8, ptr %p5063, i64 -16
  %ld5065 = load i64, ptr %rgep5064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5065, ptr %slot931, align 8
  %v5066 = load i64, ptr %slot931, align 8
  %op5067 = and i64 %v5066, 4611686018427387906
  store i64 %op5067, ptr %slot932, align 8
  %v5068 = load i64, ptr %slot932, align 8
  %cmp5069 = icmp ne i64 %v5068, 0
  %cv5070 = zext i1 %cmp5069 to i32
  store i32 %cv5070, ptr %slot933, align 8
  %v5071 = load i32, ptr %slot933, align 8
  %cv5072 = zext i32 %v5071 to i64
  %cond5073 = icmp ne i64 %cv5072, 0
  br i1 %cond5073, label %bb_rcgclear1177, label %bb_rcgcounted1177
bb_rcgcounted1177:
  %v5074 = load i64, ptr %slot928, align 8
  %op5075 = sub i64 %v5074, 32
  store i64 %op5075, ptr %slot934, align 8
  %v5076 = load i64, ptr %slot928, align 8
  %p5077 = inttoptr i64 %v5076 to ptr
  %rgep5078 = getelementptr i8, ptr %p5077, i64 -32
  %ld5079 = load i64, ptr %rgep5078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5079, ptr %slot935, align 8
  %v5080 = load i64, ptr %slot935, align 8
  %op5081 = sub i64 %v5080, 1
  store i64 %op5081, ptr %slot936, align 8
  %v5082 = load i64, ptr %slot936, align 8
  %cmp5083 = icmp eq i64 %v5082, 0
  %cv5084 = zext i1 %cmp5083 to i32
  store i32 %cv5084, ptr %slot937, align 8
  %v5085 = load i32, ptr %slot937, align 8
  %cv5086 = zext i32 %v5085 to i64
  %cond5087 = icmp ne i64 %cv5086, 0
  br i1 %cond5087, label %bb_rcglast1177, label %bb_rcgdec1177
bb_rcglast1177:
  %v5088 = load i64, ptr %slot928, align 8
  %op5089 = sub i64 %v5088, 24
  store i64 %op5089, ptr %slot938, align 8
  %v5090 = load i64, ptr %slot928, align 8
  %p5091 = inttoptr i64 %v5090 to ptr
  %rgep5092 = getelementptr i8, ptr %p5091, i64 -24
  %ld5093 = load i64, ptr %rgep5092, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5093, ptr %slot939, align 8
  %v5094 = load i64, ptr %slot939, align 8
  %cmp5095 = icmp ne i64 %v5094, 0
  %cv5096 = zext i1 %cmp5095 to i32
  store i32 %cv5096, ptr %slot940, align 8
  %v5097 = load i32, ptr %slot940, align 8
  %cv5098 = zext i32 %v5097 to i64
  %cond5099 = icmp ne i64 %cv5098, 0
  br i1 %cond5099, label %bb_rcgdec1177, label %bb_rcgslow1177
bb_rcgslow1177:
  %v5100 = load i64, ptr %slot927, align 8
  %v5101 = load i64, ptr %slot910, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5100, i64 %v5101) nomerge, !dbg !144
  br label %bb_rcgdone1177
bb_rcgdec1177:
  %v5102 = load i64, ptr %slot936, align 8
  %v5103 = load i64, ptr %slot928, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  %rgep5105 = getelementptr i8, ptr %p5104, i64 -32
  store i64 %v5102, ptr %rgep5105, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1177
bb_rcgclear1177:
  %v5106 = load i64, ptr %slot910, align 8
  %p5107 = inttoptr i64 %v5106 to ptr
  store i64 0, ptr %p5107, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1177
bb_rcgdone1177:
  br label %bb_rcslotdone1146
bb_rcslotdone1146:
  %v5108 = load i64, ptr %slot27, align 8
  %p5109 = inttoptr i64 %v5108 to ptr
  %ld5110 = load i64, ptr %p5109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5110, ptr %slot941, align 8
  %v5111 = load i64, ptr %slot941, align 8
  %op5112 = add i64 %v5111, 40
  store i64 %op5112, ptr %slot942, align 8
  %v5113 = load i64, ptr %slot35, align 8
  store i64 %v5113, ptr %slot943, align 8
  %v5114 = load i64, ptr %slot943, align 8
  %v5115 = load i64, ptr %slot942, align 8
  %p5116 = inttoptr i64 %v5114 to ptr
  %p5117 = inttoptr i64 %v5115 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5117, ptr %p5116, i64 40, i1 false), !alias.scope !10000000
  %v5118 = load i64, ptr %slot943, align 8
  %p5119 = inttoptr i64 %v5118 to ptr
  store i64 0, ptr %p5119, align 8, !alias.scope !3, !noalias !4
  %v5120 = load i64, ptr %slot943, align 8
  %p5122 = inttoptr i64 %v5120 to ptr
  %gep5123 = getelementptr i8, ptr %p5122, i64 8
  %op5121 = ptrtoint ptr %gep5123 to i64
  store i64 %op5121, ptr %slot944, align 8
  %v5124 = load i64, ptr %slot944, align 8
  %p5125 = inttoptr i64 %v5124 to ptr
  store i64 0, ptr %p5125, align 8, !alias.scope !3, !noalias !4
  %v5126 = load i64, ptr %slot943, align 8
  %p5128 = inttoptr i64 %v5126 to ptr
  %gep5129 = getelementptr i8, ptr %p5128, i64 16
  %op5127 = ptrtoint ptr %gep5129 to i64
  store i64 %op5127, ptr %slot945, align 8
  %v5130 = load i64, ptr %slot945, align 8
  %p5131 = inttoptr i64 %v5130 to ptr
  store i64 0, ptr %p5131, align 8, !alias.scope !3, !noalias !4
  %v5132 = load i64, ptr %slot943, align 8
  %p5134 = inttoptr i64 %v5132 to ptr
  %gep5135 = getelementptr i8, ptr %p5134, i64 24
  %op5133 = ptrtoint ptr %gep5135 to i64
  store i64 %op5133, ptr %slot946, align 8
  %v5136 = load i64, ptr %slot946, align 8
  %p5137 = inttoptr i64 %v5136 to ptr
  store i64 0, ptr %p5137, align 8, !alias.scope !3, !noalias !4
  %v5138 = load i64, ptr %slot943, align 8
  %p5140 = inttoptr i64 %v5138 to ptr
  %gep5141 = getelementptr i8, ptr %p5140, i64 32
  %op5139 = ptrtoint ptr %gep5141 to i64
  store i64 %op5139, ptr %slot947, align 8
  %v5142 = load i64, ptr %slot947, align 8
  %p5143 = inttoptr i64 %v5142 to ptr
  store i64 0, ptr %p5143, align 8, !alias.scope !3, !noalias !4
  %v5144 = load i64, ptr %slot14, align 8
  %p5145 = inttoptr i64 %v5144 to ptr
  store i32 0, ptr %p5145, align 4, !alias.scope !3, !noalias !4
  %v5146 = load i64, ptr %slot37, align 8
  %p5147 = inttoptr i64 %v5146 to ptr
  store i64 0, ptr %p5147, align 8, !alias.scope !3, !noalias !4
  %v5148 = load i64, ptr %slot37, align 8
  %p5149 = inttoptr i64 %v5148 to ptr
  store i64 1, ptr %p5149, align 8, !alias.scope !3, !noalias !4
  %v5150 = load i64, ptr %slot37, align 8
  %p5151 = inttoptr i64 %v5150 to ptr
  %ld5152 = load i64, ptr %p5151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5152, ptr %slot948, align 8
  %v5153 = load i64, ptr %slot948, align 8
  %v5154 = load i64, ptr %slot36, align 8
  %p5155 = inttoptr i64 %v5154 to ptr
  store i64 %v5153, ptr %p5155, align 8, !alias.scope !3, !noalias !4
  %v5156 = load i64, ptr %slot27, align 8
  %p5157 = inttoptr i64 %v5156 to ptr
  %ld5158 = load i64, ptr %p5157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5158, ptr %slot949, align 8
  %v5159 = load i64, ptr %slot949, align 8
  %v5160 = load i64, ptr %slot37, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  store i64 %v5159, ptr %p5161, align 8, !alias.scope !3, !noalias !4
  %v5162 = load i64, ptr %slot27, align 8
  %p5163 = inttoptr i64 %v5162 to ptr
  %ld5164 = load i64, ptr %p5163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5164, ptr %slot950, align 8
  %v5165 = load i64, ptr %slot950, align 8
  %v5166 = load i64, ptr %slot37, align 8
  %p5167 = inttoptr i64 %v5166 to ptr
  store i64 %v5165, ptr %p5167, align 8, !alias.scope !3, !noalias !4
  %v5168 = load i64, ptr %slot27, align 8
  %p5169 = inttoptr i64 %v5168 to ptr
  %ld5170 = load i64, ptr %p5169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5170, ptr %slot951, align 8
  %v5171 = load i64, ptr %slot951, align 8
  %v5172 = load i64, ptr %slot37, align 8
  %p5173 = inttoptr i64 %v5172 to ptr
  store i64 %v5171, ptr %p5173, align 8, !alias.scope !3, !noalias !4
  %v5174 = load i64, ptr %slot36, align 8
  %p5175 = inttoptr i64 %v5174 to ptr
  %ld5176 = load i64, ptr %p5175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5176, ptr %slot952, align 8
  %v5177 = load i64, ptr %slot952, align 8
  %v5178 = load i64, ptr %slot38, align 8
  %p5179 = inttoptr i64 %v5178 to ptr
  store i64 %v5177, ptr %p5179, align 8, !alias.scope !3, !noalias !4
  %v5180 = load i64, ptr %slot27, align 8
  %p5181 = inttoptr i64 %v5180 to ptr
  %ld5182 = load i64, ptr %p5181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5182, ptr %slot953, align 8
  %v5183 = load i64, ptr %slot953, align 8
  %v5184 = load i64, ptr %slot37, align 8
  %p5185 = inttoptr i64 %v5184 to ptr
  store i64 %v5183, ptr %p5185, align 8, !alias.scope !3, !noalias !4
  %v5186 = load i64, ptr %slot36, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  %ld5188 = load i64, ptr %p5187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5188, ptr %slot954, align 8
  %v5189 = load i64, ptr %slot27, align 8
  %p5190 = inttoptr i64 %v5189 to ptr
  %ld5191 = load i64, ptr %p5190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5191, ptr %slot955, align 8
  %v5192 = load i64, ptr %slot955, align 8
  %op5193 = add i64 %v5192, 96
  store i64 %op5193, ptr %slot956, align 8
  %v5194 = load i64, ptr %slot954, align 8
  %cv5195 = trunc i64 %v5194 to i8
  %v5196 = load i64, ptr %slot956, align 8
  %p5197 = inttoptr i64 %v5196 to ptr
  store i8 %cv5195, ptr %p5197, align 1, !alias.scope !4, !noalias !3
  %v5198 = load i64, ptr %slot37, align 8
  %p5199 = inttoptr i64 %v5198 to ptr
  store i64 0, ptr %p5199, align 8, !alias.scope !3, !noalias !4
  %v5200 = load i64, ptr %slot37, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  store i64 0, ptr %p5201, align 8, !alias.scope !3, !noalias !4
  %v5202 = load i64, ptr %slot37, align 8
  %p5203 = inttoptr i64 %v5202 to ptr
  %ld5204 = load i64, ptr %p5203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5204, ptr %slot957, align 8
  %v5205 = load i64, ptr %slot16, align 8
  %p5206 = inttoptr i64 %v5205 to ptr
  %ld5207 = load i32, ptr %p5206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5207, ptr %slot958, align 8
  %v5208 = load i32, ptr %slot958, align 8
  %cv5209 = zext i32 %v5208 to i64
  %cond5210 = icmp ne i64 %cv5209, 0
  br i1 %cond5210, label %bb_rcslotdrop1201, label %bb_rcslotdone1201
bb_rcslotdrop1201:
  %v5211 = load i64, ptr %slot16, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  store i32 0, ptr %p5212, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1201
bb_rcslotdone1201:
  %v5213 = load i64, ptr %slot14, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  %ld5215 = load i32, ptr %p5214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5215, ptr %slot959, align 8
  %v5216 = load i32, ptr %slot959, align 8
  %cv5217 = zext i32 %v5216 to i64
  %cond5218 = icmp ne i64 %cv5217, 0
  br i1 %cond5218, label %bb_rcslotdrop1231, label %bb_rcslotdone1231
bb_rcslotdrop1231:
  %v5219 = load i64, ptr %slot14, align 8
  %p5220 = inttoptr i64 %v5219 to ptr
  store i32 0, ptr %p5220, align 4, !alias.scope !3, !noalias !4
  %v5221 = load i64, ptr %slot35, align 8
  store i64 %v5221, ptr %slot960, align 8
  %v5222 = load i64, ptr %slot15, align 8
  %p5223 = inttoptr i64 %v5222 to ptr
  %ld5224 = load i32, ptr %p5223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5224, ptr %slot961, align 8
  %v5225 = load i32, ptr %slot961, align 8
  %op5226 = and i32 %v5225, 28
  store i32 %op5226, ptr %slot962, align 8
  %v5227 = load i32, ptr %slot962, align 8
  %cv5228 = zext i32 %v5227 to i64
  %cond5229 = icmp ne i64 %cv5228, 0
  br i1 %cond5229, label %bb_rcslotrole1231, label %bb_rcslotowner1231
bb_rcslotrole1231:
  %v5230 = load i64, ptr %slot46, align 8
  store i64 %v5230, ptr %slot963, align 8
  %v5231 = load i64, ptr %slot963, align 8
  %v5232 = load i64, ptr %slot960, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v5231, i64 %v5232) nomerge, !dbg !146
  br label %bb_rcslotdone1231
bb_rcslotowner1231:
  %v5233 = load i64, ptr %slot46, align 8
  store i64 %v5233, ptr %slot964, align 8
  %v5234 = load i64, ptr %slot964, align 8
  %v5235 = load i64, ptr %slot960, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v5234, i64 %v5235) nomerge, !dbg !146
  br label %bb_rcslotdone1231
bb_rcslotdone1231:
  %v5236 = load i64, ptr %slot12, align 8
  %p5237 = inttoptr i64 %v5236 to ptr
  %ld5238 = load i32, ptr %p5237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5238, ptr %slot965, align 8
  %v5239 = load i32, ptr %slot965, align 8
  %cv5240 = zext i32 %v5239 to i64
  %cond5241 = icmp ne i64 %cv5240, 0
  br i1 %cond5241, label %bb_rcslotdrop1240, label %bb_rcslotdone1240
bb_rcslotdrop1240:
  %v5242 = load i64, ptr %slot12, align 8
  %p5243 = inttoptr i64 %v5242 to ptr
  store i32 0, ptr %p5243, align 4, !alias.scope !3, !noalias !4
  %v5244 = load i64, ptr %slot34, align 8
  store i64 %v5244, ptr %slot966, align 8
  %v5245 = load i64, ptr %slot13, align 8
  %p5246 = inttoptr i64 %v5245 to ptr
  %ld5247 = load i32, ptr %p5246, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5247, ptr %slot967, align 8
  %v5248 = load i32, ptr %slot967, align 8
  %op5249 = and i32 %v5248, 28
  store i32 %op5249, ptr %slot968, align 8
  %v5250 = load i32, ptr %slot968, align 8
  %cv5251 = zext i32 %v5250 to i64
  %cond5252 = icmp ne i64 %cv5251, 0
  br i1 %cond5252, label %bb_rcslotrole1240, label %bb_rcslotowner1240
bb_rcslotrole1240:
  %v5253 = load i64, ptr %slot46, align 8
  store i64 %v5253, ptr %slot969, align 8
  %v5254 = load i64, ptr %slot966, align 8
  %p5255 = inttoptr i64 %v5254 to ptr
  %ld5256 = load i64, ptr %p5255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5256, ptr %slot970, align 8
  %v5257 = load i64, ptr %slot970, align 8
  %cmp5258 = icmp ne i64 %v5257, 0
  %cv5259 = zext i1 %cmp5258 to i32
  store i32 %cv5259, ptr %slot971, align 8
  %v5260 = load i32, ptr %slot971, align 8
  %cv5261 = zext i32 %v5260 to i64
  %cond5262 = icmp ne i64 %cv5261, 0
  br i1 %cond5262, label %bb_rcgnn1256, label %bb_rcgdone1256
bb_rcgnn1256:
  %v5263 = load i64, ptr %slot970, align 8
  %op5264 = sub i64 %v5263, 16
  store i64 %op5264, ptr %slot972, align 8
  %v5265 = load i64, ptr %slot970, align 8
  %p5266 = inttoptr i64 %v5265 to ptr
  %rgep5267 = getelementptr i8, ptr %p5266, i64 -16
  %ld5268 = load i64, ptr %rgep5267, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5268, ptr %slot973, align 8
  %v5269 = load i64, ptr %slot973, align 8
  %op5270 = and i64 %v5269, 4611686018427387906
  store i64 %op5270, ptr %slot974, align 8
  %v5271 = load i64, ptr %slot974, align 8
  %cmp5272 = icmp ne i64 %v5271, 0
  %cv5273 = zext i1 %cmp5272 to i32
  store i32 %cv5273, ptr %slot975, align 8
  %v5274 = load i32, ptr %slot975, align 8
  %cv5275 = zext i32 %v5274 to i64
  %cond5276 = icmp ne i64 %cv5275, 0
  br i1 %cond5276, label %bb_rcgclear1256, label %bb_rcgcounted1256
bb_rcgcounted1256:
  %v5277 = load i64, ptr %slot970, align 8
  %op5278 = sub i64 %v5277, 24
  store i64 %op5278, ptr %slot976, align 8
  %v5279 = load i64, ptr %slot970, align 8
  %p5280 = inttoptr i64 %v5279 to ptr
  %rgep5281 = getelementptr i8, ptr %p5280, i64 -24
  %ld5282 = load i64, ptr %rgep5281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5282, ptr %slot977, align 8
  %v5283 = load i64, ptr %slot977, align 8
  %op5284 = sub i64 %v5283, 1
  store i64 %op5284, ptr %slot978, align 8
  %v5285 = load i64, ptr %slot978, align 8
  %cmp5286 = icmp eq i64 %v5285, 0
  %cv5287 = zext i1 %cmp5286 to i32
  store i32 %cv5287, ptr %slot979, align 8
  %v5288 = load i32, ptr %slot979, align 8
  %cv5289 = zext i32 %v5288 to i64
  %cond5290 = icmp ne i64 %cv5289, 0
  br i1 %cond5290, label %bb_rcglast1256, label %bb_rcgdec1256
bb_rcglast1256:
  %v5291 = load i64, ptr %slot970, align 8
  %op5292 = sub i64 %v5291, 32
  store i64 %op5292, ptr %slot980, align 8
  %v5293 = load i64, ptr %slot970, align 8
  %p5294 = inttoptr i64 %v5293 to ptr
  %rgep5295 = getelementptr i8, ptr %p5294, i64 -32
  %ld5296 = load i64, ptr %rgep5295, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5296, ptr %slot981, align 8
  %v5297 = load i64, ptr %slot981, align 8
  %cmp5298 = icmp ne i64 %v5297, 0
  %cv5299 = zext i1 %cmp5298 to i32
  store i32 %cv5299, ptr %slot982, align 8
  %v5300 = load i32, ptr %slot982, align 8
  %cv5301 = zext i32 %v5300 to i64
  %cond5302 = icmp ne i64 %cv5301, 0
  br i1 %cond5302, label %bb_rcgdec1256, label %bb_rcgslow1256
bb_rcgslow1256:
  %v5303 = load i64, ptr %slot969, align 8
  %v5304 = load i64, ptr %slot966, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v5303, i64 %v5304) nomerge, !dbg !146
  br label %bb_rcgdone1256
bb_rcgdec1256:
  %v5305 = load i64, ptr %slot978, align 8
  %v5306 = load i64, ptr %slot970, align 8
  %p5307 = inttoptr i64 %v5306 to ptr
  %rgep5308 = getelementptr i8, ptr %p5307, i64 -24
  store i64 %v5305, ptr %rgep5308, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1256
bb_rcgclear1256:
  %v5309 = load i64, ptr %slot966, align 8
  %p5310 = inttoptr i64 %v5309 to ptr
  store i64 0, ptr %p5310, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1256
bb_rcgdone1256:
  br label %bb_rcslotdone1240
bb_rcslotowner1240:
  %v5311 = load i64, ptr %slot46, align 8
  store i64 %v5311, ptr %slot983, align 8
  %v5312 = load i64, ptr %slot966, align 8
  %p5313 = inttoptr i64 %v5312 to ptr
  %ld5314 = load i64, ptr %p5313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5314, ptr %slot984, align 8
  %v5315 = load i64, ptr %slot984, align 8
  %cmp5316 = icmp ne i64 %v5315, 0
  %cv5317 = zext i1 %cmp5316 to i32
  store i32 %cv5317, ptr %slot985, align 8
  %v5318 = load i32, ptr %slot985, align 8
  %cv5319 = zext i32 %v5318 to i64
  %cond5320 = icmp ne i64 %cv5319, 0
  br i1 %cond5320, label %bb_rcgnn1271, label %bb_rcgdone1271
bb_rcgnn1271:
  %v5321 = load i64, ptr %slot984, align 8
  %op5322 = sub i64 %v5321, 16
  store i64 %op5322, ptr %slot986, align 8
  %v5323 = load i64, ptr %slot984, align 8
  %p5324 = inttoptr i64 %v5323 to ptr
  %rgep5325 = getelementptr i8, ptr %p5324, i64 -16
  %ld5326 = load i64, ptr %rgep5325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5326, ptr %slot987, align 8
  %v5327 = load i64, ptr %slot987, align 8
  %op5328 = and i64 %v5327, 4611686018427387906
  store i64 %op5328, ptr %slot988, align 8
  %v5329 = load i64, ptr %slot988, align 8
  %cmp5330 = icmp ne i64 %v5329, 0
  %cv5331 = zext i1 %cmp5330 to i32
  store i32 %cv5331, ptr %slot989, align 8
  %v5332 = load i32, ptr %slot989, align 8
  %cv5333 = zext i32 %v5332 to i64
  %cond5334 = icmp ne i64 %cv5333, 0
  br i1 %cond5334, label %bb_rcgclear1271, label %bb_rcgcounted1271
bb_rcgcounted1271:
  %v5335 = load i64, ptr %slot984, align 8
  %op5336 = sub i64 %v5335, 32
  store i64 %op5336, ptr %slot990, align 8
  %v5337 = load i64, ptr %slot984, align 8
  %p5338 = inttoptr i64 %v5337 to ptr
  %rgep5339 = getelementptr i8, ptr %p5338, i64 -32
  %ld5340 = load i64, ptr %rgep5339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5340, ptr %slot991, align 8
  %v5341 = load i64, ptr %slot991, align 8
  %op5342 = sub i64 %v5341, 1
  store i64 %op5342, ptr %slot992, align 8
  %v5343 = load i64, ptr %slot992, align 8
  %cmp5344 = icmp eq i64 %v5343, 0
  %cv5345 = zext i1 %cmp5344 to i32
  store i32 %cv5345, ptr %slot993, align 8
  %v5346 = load i32, ptr %slot993, align 8
  %cv5347 = zext i32 %v5346 to i64
  %cond5348 = icmp ne i64 %cv5347, 0
  br i1 %cond5348, label %bb_rcglast1271, label %bb_rcgdec1271
bb_rcglast1271:
  %v5349 = load i64, ptr %slot984, align 8
  %op5350 = sub i64 %v5349, 24
  store i64 %op5350, ptr %slot994, align 8
  %v5351 = load i64, ptr %slot984, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  %rgep5353 = getelementptr i8, ptr %p5352, i64 -24
  %ld5354 = load i64, ptr %rgep5353, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5354, ptr %slot995, align 8
  %v5355 = load i64, ptr %slot995, align 8
  %cmp5356 = icmp ne i64 %v5355, 0
  %cv5357 = zext i1 %cmp5356 to i32
  store i32 %cv5357, ptr %slot996, align 8
  %v5358 = load i32, ptr %slot996, align 8
  %cv5359 = zext i32 %v5358 to i64
  %cond5360 = icmp ne i64 %cv5359, 0
  br i1 %cond5360, label %bb_rcgdec1271, label %bb_rcgslow1271
bb_rcgslow1271:
  %v5361 = load i64, ptr %slot983, align 8
  %v5362 = load i64, ptr %slot966, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v5361, i64 %v5362) nomerge, !dbg !146
  br label %bb_rcgdone1271
bb_rcgdec1271:
  %v5363 = load i64, ptr %slot992, align 8
  %v5364 = load i64, ptr %slot984, align 8
  %p5365 = inttoptr i64 %v5364 to ptr
  %rgep5366 = getelementptr i8, ptr %p5365, i64 -32
  store i64 %v5363, ptr %rgep5366, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1271
bb_rcgclear1271:
  %v5367 = load i64, ptr %slot966, align 8
  %p5368 = inttoptr i64 %v5367 to ptr
  store i64 0, ptr %p5368, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1271
bb_rcgdone1271:
  br label %bb_rcslotdone1240
bb_rcslotdone1240:
  %v5369 = load i64, ptr %slot10, align 8
  %p5370 = inttoptr i64 %v5369 to ptr
  %ld5371 = load i32, ptr %p5370, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5371, ptr %slot997, align 8
  %v5372 = load i32, ptr %slot997, align 8
  %cv5373 = zext i32 %v5372 to i64
  %cond5374 = icmp ne i64 %cv5373, 0
  br i1 %cond5374, label %bb_rcslotdrop1277, label %bb_rcslotdone1277
bb_rcslotdrop1277:
  %v5375 = load i64, ptr %slot10, align 8
  %p5376 = inttoptr i64 %v5375 to ptr
  store i32 0, ptr %p5376, align 4, !alias.scope !3, !noalias !4
  %v5377 = load i64, ptr %slot33, align 8
  store i64 %v5377, ptr %slot998, align 8
  %v5378 = load i64, ptr %slot11, align 8
  %p5379 = inttoptr i64 %v5378 to ptr
  %ld5380 = load i32, ptr %p5379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5380, ptr %slot999, align 8
  %v5381 = load i32, ptr %slot999, align 8
  %op5382 = and i32 %v5381, 28
  store i32 %op5382, ptr %slot1000, align 8
  %v5383 = load i32, ptr %slot1000, align 8
  %cv5384 = zext i32 %v5383 to i64
  %cond5385 = icmp ne i64 %cv5384, 0
  br i1 %cond5385, label %bb_rcslotrole1277, label %bb_rcslotowner1277
bb_rcslotrole1277:
  %v5386 = load i64, ptr %slot46, align 8
  store i64 %v5386, ptr %slot1001, align 8
  %v5387 = load i64, ptr %slot998, align 8
  %p5388 = inttoptr i64 %v5387 to ptr
  %ld5389 = load i64, ptr %p5388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5389, ptr %slot1002, align 8
  %v5390 = load i64, ptr %slot1002, align 8
  %cmp5391 = icmp ne i64 %v5390, 0
  %cv5392 = zext i1 %cmp5391 to i32
  store i32 %cv5392, ptr %slot1003, align 8
  %v5393 = load i32, ptr %slot1003, align 8
  %cv5394 = zext i32 %v5393 to i64
  %cond5395 = icmp ne i64 %cv5394, 0
  br i1 %cond5395, label %bb_rcgnn1293, label %bb_rcgdone1293
bb_rcgnn1293:
  %v5396 = load i64, ptr %slot1002, align 8
  %op5397 = sub i64 %v5396, 16
  store i64 %op5397, ptr %slot1004, align 8
  %v5398 = load i64, ptr %slot1002, align 8
  %p5399 = inttoptr i64 %v5398 to ptr
  %rgep5400 = getelementptr i8, ptr %p5399, i64 -16
  %ld5401 = load i64, ptr %rgep5400, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5401, ptr %slot1005, align 8
  %v5402 = load i64, ptr %slot1005, align 8
  %op5403 = and i64 %v5402, 4611686018427387906
  store i64 %op5403, ptr %slot1006, align 8
  %v5404 = load i64, ptr %slot1006, align 8
  %cmp5405 = icmp ne i64 %v5404, 0
  %cv5406 = zext i1 %cmp5405 to i32
  store i32 %cv5406, ptr %slot1007, align 8
  %v5407 = load i32, ptr %slot1007, align 8
  %cv5408 = zext i32 %v5407 to i64
  %cond5409 = icmp ne i64 %cv5408, 0
  br i1 %cond5409, label %bb_rcgclear1293, label %bb_rcgcounted1293
bb_rcgcounted1293:
  %v5410 = load i64, ptr %slot1002, align 8
  %op5411 = sub i64 %v5410, 24
  store i64 %op5411, ptr %slot1008, align 8
  %v5412 = load i64, ptr %slot1002, align 8
  %p5413 = inttoptr i64 %v5412 to ptr
  %rgep5414 = getelementptr i8, ptr %p5413, i64 -24
  %ld5415 = load i64, ptr %rgep5414, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5415, ptr %slot1009, align 8
  %v5416 = load i64, ptr %slot1009, align 8
  %op5417 = sub i64 %v5416, 1
  store i64 %op5417, ptr %slot1010, align 8
  %v5418 = load i64, ptr %slot1010, align 8
  %cmp5419 = icmp eq i64 %v5418, 0
  %cv5420 = zext i1 %cmp5419 to i32
  store i32 %cv5420, ptr %slot1011, align 8
  %v5421 = load i32, ptr %slot1011, align 8
  %cv5422 = zext i32 %v5421 to i64
  %cond5423 = icmp ne i64 %cv5422, 0
  br i1 %cond5423, label %bb_rcglast1293, label %bb_rcgdec1293
bb_rcglast1293:
  %v5424 = load i64, ptr %slot1002, align 8
  %op5425 = sub i64 %v5424, 32
  store i64 %op5425, ptr %slot1012, align 8
  %v5426 = load i64, ptr %slot1002, align 8
  %p5427 = inttoptr i64 %v5426 to ptr
  %rgep5428 = getelementptr i8, ptr %p5427, i64 -32
  %ld5429 = load i64, ptr %rgep5428, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5429, ptr %slot1013, align 8
  %v5430 = load i64, ptr %slot1013, align 8
  %cmp5431 = icmp ne i64 %v5430, 0
  %cv5432 = zext i1 %cmp5431 to i32
  store i32 %cv5432, ptr %slot1014, align 8
  %v5433 = load i32, ptr %slot1014, align 8
  %cv5434 = zext i32 %v5433 to i64
  %cond5435 = icmp ne i64 %cv5434, 0
  br i1 %cond5435, label %bb_rcgdec1293, label %bb_rcgslow1293
bb_rcgslow1293:
  %v5436 = load i64, ptr %slot1001, align 8
  %v5437 = load i64, ptr %slot998, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5436, i64 %v5437) nomerge, !dbg !146
  br label %bb_rcgdone1293
bb_rcgdec1293:
  %v5438 = load i64, ptr %slot1010, align 8
  %v5439 = load i64, ptr %slot1002, align 8
  %p5440 = inttoptr i64 %v5439 to ptr
  %rgep5441 = getelementptr i8, ptr %p5440, i64 -24
  store i64 %v5438, ptr %rgep5441, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1293
bb_rcgclear1293:
  %v5442 = load i64, ptr %slot998, align 8
  %p5443 = inttoptr i64 %v5442 to ptr
  store i64 0, ptr %p5443, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1293
bb_rcgdone1293:
  br label %bb_rcslotdone1277
bb_rcslotowner1277:
  %v5444 = load i64, ptr %slot46, align 8
  store i64 %v5444, ptr %slot1015, align 8
  %v5445 = load i64, ptr %slot998, align 8
  %p5446 = inttoptr i64 %v5445 to ptr
  %ld5447 = load i64, ptr %p5446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5447, ptr %slot1016, align 8
  %v5448 = load i64, ptr %slot1016, align 8
  %cmp5449 = icmp ne i64 %v5448, 0
  %cv5450 = zext i1 %cmp5449 to i32
  store i32 %cv5450, ptr %slot1017, align 8
  %v5451 = load i32, ptr %slot1017, align 8
  %cv5452 = zext i32 %v5451 to i64
  %cond5453 = icmp ne i64 %cv5452, 0
  br i1 %cond5453, label %bb_rcgnn1308, label %bb_rcgdone1308
bb_rcgnn1308:
  %v5454 = load i64, ptr %slot1016, align 8
  %op5455 = sub i64 %v5454, 16
  store i64 %op5455, ptr %slot1018, align 8
  %v5456 = load i64, ptr %slot1016, align 8
  %p5457 = inttoptr i64 %v5456 to ptr
  %rgep5458 = getelementptr i8, ptr %p5457, i64 -16
  %ld5459 = load i64, ptr %rgep5458, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5459, ptr %slot1019, align 8
  %v5460 = load i64, ptr %slot1019, align 8
  %op5461 = and i64 %v5460, 4611686018427387906
  store i64 %op5461, ptr %slot1020, align 8
  %v5462 = load i64, ptr %slot1020, align 8
  %cmp5463 = icmp ne i64 %v5462, 0
  %cv5464 = zext i1 %cmp5463 to i32
  store i32 %cv5464, ptr %slot1021, align 8
  %v5465 = load i32, ptr %slot1021, align 8
  %cv5466 = zext i32 %v5465 to i64
  %cond5467 = icmp ne i64 %cv5466, 0
  br i1 %cond5467, label %bb_rcgclear1308, label %bb_rcgcounted1308
bb_rcgcounted1308:
  %v5468 = load i64, ptr %slot1016, align 8
  %op5469 = sub i64 %v5468, 32
  store i64 %op5469, ptr %slot1022, align 8
  %v5470 = load i64, ptr %slot1016, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  %rgep5472 = getelementptr i8, ptr %p5471, i64 -32
  %ld5473 = load i64, ptr %rgep5472, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5473, ptr %slot1023, align 8
  %v5474 = load i64, ptr %slot1023, align 8
  %op5475 = sub i64 %v5474, 1
  store i64 %op5475, ptr %slot1024, align 8
  %v5476 = load i64, ptr %slot1024, align 8
  %cmp5477 = icmp eq i64 %v5476, 0
  %cv5478 = zext i1 %cmp5477 to i32
  store i32 %cv5478, ptr %slot1025, align 8
  %v5479 = load i32, ptr %slot1025, align 8
  %cv5480 = zext i32 %v5479 to i64
  %cond5481 = icmp ne i64 %cv5480, 0
  br i1 %cond5481, label %bb_rcglast1308, label %bb_rcgdec1308
bb_rcglast1308:
  %v5482 = load i64, ptr %slot1016, align 8
  %op5483 = sub i64 %v5482, 24
  store i64 %op5483, ptr %slot1026, align 8
  %v5484 = load i64, ptr %slot1016, align 8
  %p5485 = inttoptr i64 %v5484 to ptr
  %rgep5486 = getelementptr i8, ptr %p5485, i64 -24
  %ld5487 = load i64, ptr %rgep5486, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5487, ptr %slot1027, align 8
  %v5488 = load i64, ptr %slot1027, align 8
  %cmp5489 = icmp ne i64 %v5488, 0
  %cv5490 = zext i1 %cmp5489 to i32
  store i32 %cv5490, ptr %slot1028, align 8
  %v5491 = load i32, ptr %slot1028, align 8
  %cv5492 = zext i32 %v5491 to i64
  %cond5493 = icmp ne i64 %cv5492, 0
  br i1 %cond5493, label %bb_rcgdec1308, label %bb_rcgslow1308
bb_rcgslow1308:
  %v5494 = load i64, ptr %slot1015, align 8
  %v5495 = load i64, ptr %slot998, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5494, i64 %v5495) nomerge, !dbg !146
  br label %bb_rcgdone1308
bb_rcgdec1308:
  %v5496 = load i64, ptr %slot1024, align 8
  %v5497 = load i64, ptr %slot1016, align 8
  %p5498 = inttoptr i64 %v5497 to ptr
  %rgep5499 = getelementptr i8, ptr %p5498, i64 -32
  store i64 %v5496, ptr %rgep5499, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1308
bb_rcgclear1308:
  %v5500 = load i64, ptr %slot998, align 8
  %p5501 = inttoptr i64 %v5500 to ptr
  store i64 0, ptr %p5501, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1308
bb_rcgdone1308:
  br label %bb_rcslotdone1277
bb_rcslotdone1277:
  %v5502 = load i64, ptr %slot8, align 8
  %p5503 = inttoptr i64 %v5502 to ptr
  %ld5504 = load i32, ptr %p5503, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5504, ptr %slot1029, align 8
  %v5505 = load i32, ptr %slot1029, align 8
  %cv5506 = zext i32 %v5505 to i64
  %cond5507 = icmp ne i64 %cv5506, 0
  br i1 %cond5507, label %bb_rcslotdrop1314, label %bb_rcslotdone1314
bb_rcslotdrop1314:
  %v5508 = load i64, ptr %slot8, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  store i32 0, ptr %p5509, align 4, !alias.scope !3, !noalias !4
  %v5510 = load i64, ptr %slot32, align 8
  store i64 %v5510, ptr %slot1030, align 8
  %v5511 = load i64, ptr %slot9, align 8
  %p5512 = inttoptr i64 %v5511 to ptr
  %ld5513 = load i32, ptr %p5512, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5513, ptr %slot1031, align 8
  %v5514 = load i32, ptr %slot1031, align 8
  %op5515 = and i32 %v5514, 28
  store i32 %op5515, ptr %slot1032, align 8
  %v5516 = load i32, ptr %slot1032, align 8
  %cv5517 = zext i32 %v5516 to i64
  %cond5518 = icmp ne i64 %cv5517, 0
  br i1 %cond5518, label %bb_rcslotrole1314, label %bb_rcslotowner1314
bb_rcslotrole1314:
  %v5519 = load i64, ptr %slot46, align 8
  store i64 %v5519, ptr %slot1033, align 8
  %v5520 = load i64, ptr %slot1030, align 8
  %p5521 = inttoptr i64 %v5520 to ptr
  %ld5522 = load i64, ptr %p5521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5522, ptr %slot1034, align 8
  %v5523 = load i64, ptr %slot1034, align 8
  %cmp5524 = icmp ne i64 %v5523, 0
  %cv5525 = zext i1 %cmp5524 to i32
  store i32 %cv5525, ptr %slot1035, align 8
  %v5526 = load i32, ptr %slot1035, align 8
  %cv5527 = zext i32 %v5526 to i64
  %cond5528 = icmp ne i64 %cv5527, 0
  br i1 %cond5528, label %bb_rcgnn1330, label %bb_rcgdone1330
bb_rcgnn1330:
  %v5529 = load i64, ptr %slot1034, align 8
  %op5530 = sub i64 %v5529, 16
  store i64 %op5530, ptr %slot1036, align 8
  %v5531 = load i64, ptr %slot1034, align 8
  %p5532 = inttoptr i64 %v5531 to ptr
  %rgep5533 = getelementptr i8, ptr %p5532, i64 -16
  %ld5534 = load i64, ptr %rgep5533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5534, ptr %slot1037, align 8
  %v5535 = load i64, ptr %slot1037, align 8
  %op5536 = and i64 %v5535, 4611686018427387906
  store i64 %op5536, ptr %slot1038, align 8
  %v5537 = load i64, ptr %slot1038, align 8
  %cmp5538 = icmp ne i64 %v5537, 0
  %cv5539 = zext i1 %cmp5538 to i32
  store i32 %cv5539, ptr %slot1039, align 8
  %v5540 = load i32, ptr %slot1039, align 8
  %cv5541 = zext i32 %v5540 to i64
  %cond5542 = icmp ne i64 %cv5541, 0
  br i1 %cond5542, label %bb_rcgclear1330, label %bb_rcgcounted1330
bb_rcgcounted1330:
  %v5543 = load i64, ptr %slot1034, align 8
  %op5544 = sub i64 %v5543, 24
  store i64 %op5544, ptr %slot1040, align 8
  %v5545 = load i64, ptr %slot1034, align 8
  %p5546 = inttoptr i64 %v5545 to ptr
  %rgep5547 = getelementptr i8, ptr %p5546, i64 -24
  %ld5548 = load i64, ptr %rgep5547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5548, ptr %slot1041, align 8
  %v5549 = load i64, ptr %slot1041, align 8
  %op5550 = sub i64 %v5549, 1
  store i64 %op5550, ptr %slot1042, align 8
  %v5551 = load i64, ptr %slot1042, align 8
  %cmp5552 = icmp eq i64 %v5551, 0
  %cv5553 = zext i1 %cmp5552 to i32
  store i32 %cv5553, ptr %slot1043, align 8
  %v5554 = load i32, ptr %slot1043, align 8
  %cv5555 = zext i32 %v5554 to i64
  %cond5556 = icmp ne i64 %cv5555, 0
  br i1 %cond5556, label %bb_rcglast1330, label %bb_rcgdec1330
bb_rcglast1330:
  %v5557 = load i64, ptr %slot1034, align 8
  %op5558 = sub i64 %v5557, 32
  store i64 %op5558, ptr %slot1044, align 8
  %v5559 = load i64, ptr %slot1034, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  %rgep5561 = getelementptr i8, ptr %p5560, i64 -32
  %ld5562 = load i64, ptr %rgep5561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5562, ptr %slot1045, align 8
  %v5563 = load i64, ptr %slot1045, align 8
  %cmp5564 = icmp ne i64 %v5563, 0
  %cv5565 = zext i1 %cmp5564 to i32
  store i32 %cv5565, ptr %slot1046, align 8
  %v5566 = load i32, ptr %slot1046, align 8
  %cv5567 = zext i32 %v5566 to i64
  %cond5568 = icmp ne i64 %cv5567, 0
  br i1 %cond5568, label %bb_rcgdec1330, label %bb_rcgslow1330
bb_rcgslow1330:
  %v5569 = load i64, ptr %slot1033, align 8
  %v5570 = load i64, ptr %slot1030, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5569, i64 %v5570) nomerge, !dbg !146
  br label %bb_rcgdone1330
bb_rcgdec1330:
  %v5571 = load i64, ptr %slot1042, align 8
  %v5572 = load i64, ptr %slot1034, align 8
  %p5573 = inttoptr i64 %v5572 to ptr
  %rgep5574 = getelementptr i8, ptr %p5573, i64 -24
  store i64 %v5571, ptr %rgep5574, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1330
bb_rcgclear1330:
  %v5575 = load i64, ptr %slot1030, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  store i64 0, ptr %p5576, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1330
bb_rcgdone1330:
  br label %bb_rcslotdone1314
bb_rcslotowner1314:
  %v5577 = load i64, ptr %slot46, align 8
  store i64 %v5577, ptr %slot1047, align 8
  %v5578 = load i64, ptr %slot1030, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  %ld5580 = load i64, ptr %p5579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5580, ptr %slot1048, align 8
  %v5581 = load i64, ptr %slot1048, align 8
  %cmp5582 = icmp ne i64 %v5581, 0
  %cv5583 = zext i1 %cmp5582 to i32
  store i32 %cv5583, ptr %slot1049, align 8
  %v5584 = load i32, ptr %slot1049, align 8
  %cv5585 = zext i32 %v5584 to i64
  %cond5586 = icmp ne i64 %cv5585, 0
  br i1 %cond5586, label %bb_rcgnn1345, label %bb_rcgdone1345
bb_rcgnn1345:
  %v5587 = load i64, ptr %slot1048, align 8
  %op5588 = sub i64 %v5587, 16
  store i64 %op5588, ptr %slot1050, align 8
  %v5589 = load i64, ptr %slot1048, align 8
  %p5590 = inttoptr i64 %v5589 to ptr
  %rgep5591 = getelementptr i8, ptr %p5590, i64 -16
  %ld5592 = load i64, ptr %rgep5591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5592, ptr %slot1051, align 8
  %v5593 = load i64, ptr %slot1051, align 8
  %op5594 = and i64 %v5593, 4611686018427387906
  store i64 %op5594, ptr %slot1052, align 8
  %v5595 = load i64, ptr %slot1052, align 8
  %cmp5596 = icmp ne i64 %v5595, 0
  %cv5597 = zext i1 %cmp5596 to i32
  store i32 %cv5597, ptr %slot1053, align 8
  %v5598 = load i32, ptr %slot1053, align 8
  %cv5599 = zext i32 %v5598 to i64
  %cond5600 = icmp ne i64 %cv5599, 0
  br i1 %cond5600, label %bb_rcgclear1345, label %bb_rcgcounted1345
bb_rcgcounted1345:
  %v5601 = load i64, ptr %slot1048, align 8
  %op5602 = sub i64 %v5601, 32
  store i64 %op5602, ptr %slot1054, align 8
  %v5603 = load i64, ptr %slot1048, align 8
  %p5604 = inttoptr i64 %v5603 to ptr
  %rgep5605 = getelementptr i8, ptr %p5604, i64 -32
  %ld5606 = load i64, ptr %rgep5605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5606, ptr %slot1055, align 8
  %v5607 = load i64, ptr %slot1055, align 8
  %op5608 = sub i64 %v5607, 1
  store i64 %op5608, ptr %slot1056, align 8
  %v5609 = load i64, ptr %slot1056, align 8
  %cmp5610 = icmp eq i64 %v5609, 0
  %cv5611 = zext i1 %cmp5610 to i32
  store i32 %cv5611, ptr %slot1057, align 8
  %v5612 = load i32, ptr %slot1057, align 8
  %cv5613 = zext i32 %v5612 to i64
  %cond5614 = icmp ne i64 %cv5613, 0
  br i1 %cond5614, label %bb_rcglast1345, label %bb_rcgdec1345
bb_rcglast1345:
  %v5615 = load i64, ptr %slot1048, align 8
  %op5616 = sub i64 %v5615, 24
  store i64 %op5616, ptr %slot1058, align 8
  %v5617 = load i64, ptr %slot1048, align 8
  %p5618 = inttoptr i64 %v5617 to ptr
  %rgep5619 = getelementptr i8, ptr %p5618, i64 -24
  %ld5620 = load i64, ptr %rgep5619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5620, ptr %slot1059, align 8
  %v5621 = load i64, ptr %slot1059, align 8
  %cmp5622 = icmp ne i64 %v5621, 0
  %cv5623 = zext i1 %cmp5622 to i32
  store i32 %cv5623, ptr %slot1060, align 8
  %v5624 = load i32, ptr %slot1060, align 8
  %cv5625 = zext i32 %v5624 to i64
  %cond5626 = icmp ne i64 %cv5625, 0
  br i1 %cond5626, label %bb_rcgdec1345, label %bb_rcgslow1345
bb_rcgslow1345:
  %v5627 = load i64, ptr %slot1047, align 8
  %v5628 = load i64, ptr %slot1030, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5627, i64 %v5628) nomerge, !dbg !146
  br label %bb_rcgdone1345
bb_rcgdec1345:
  %v5629 = load i64, ptr %slot1056, align 8
  %v5630 = load i64, ptr %slot1048, align 8
  %p5631 = inttoptr i64 %v5630 to ptr
  %rgep5632 = getelementptr i8, ptr %p5631, i64 -32
  store i64 %v5629, ptr %rgep5632, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1345
bb_rcgclear1345:
  %v5633 = load i64, ptr %slot1030, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  store i64 0, ptr %p5634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1345
bb_rcgdone1345:
  br label %bb_rcslotdone1314
bb_rcslotdone1314:
  %v5635 = load i64, ptr %slot957, align 8
  ret i64 %v5635
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_5662f6395b11b677b0daae7bfe3ecb88b069643a0ef5f974b5bbee38efae20c0 = external global i8, align 8
@myl_lit_fa02b127f24cd2fef24f5d2060cd84bdf051b7536e5617126089d85771637db3 = external global i8, align 8
@myl_lit_fa55d6d54293b9059e02e93d4295af8aaa9991f37463269983996a41e5ac7cae = external global i8, align 8
@myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 = external global i8, align 8
@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_ce937c0a67fd59c0f261e0a4ab35ebce3e2c051d9627ea0c05a57eafb505b71f(i64, i64, i64)
declare i32 @myl_native_bytes_buffer_append_int(ptr, ptr, i64)
declare i32 @myl_native_bytes_buffer_append_range(ptr, ptr, ptr, i64, i64)
declare i32 @myl_native_bytes_buffer_append_utf8(ptr, ptr, ptr)
declare void @myl_native_bytes_copy_octets(ptr, ptr, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare ptr @myl_qbe_bytes_from_list(ptr, ptr)
declare ptr @myl_qbe_bytes_snapshot(ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64, i64)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64, i64, i64, i32)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_221a865e2532e6706176e23ccf437e4652dc5fbd9266a3d9ce397c9c7007e1f3", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_221a865e2532e6706176e23ccf437e4652dc5fbd9266a3d9ce397c9c7007e1f3", linkageName: "myl_f_221a865e2532e6706176e23ccf437e4652dc5fbd9266a3d9ce397c9c7007e1f3", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7927566520071727989, i64 0, !"myl_f_221a865e2532e6706176e23ccf437e4652dc5fbd9266a3d9ce397c9c7007e1f3"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!124 = !DILocation(line: 11, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!126 = !DILocation(line: 14, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!130 = !DILocation(line: 20, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!132 = !DILocation(line: 24, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!134 = !DILocation(line: 25, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!136 = !DILocation(line: 28, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!138 = !DILocation(line: 34, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!140 = !DILocation(line: 37, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!142 = !DILocation(line: 42, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!144 = !DILocation(line: 43, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!146 = !DILocation(line: 71, column: 0, scope: !147)
