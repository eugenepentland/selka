target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %callresult48 = alloca [56 x i8], align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %callresult88 = alloca [24 x i8], align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %callresult377 = alloca [24 x i8], align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %callresult721 = alloca [24 x i8], align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v819 = load i64, ptr %slot1, align 8
  %op820 = add i64 %v819, 32
  store i64 %op820, ptr %slot4, align 8
  %mem821 = alloca i8, i64 24, align 8
  %ptr822 = ptrtoint ptr %mem821 to i64
  store i64 %ptr822, ptr %slot5, align 8
  %mem823 = alloca i8, i64 8, align 8
  %ptr824 = ptrtoint ptr %mem823 to i64
  store i64 %ptr824, ptr %slot6, align 8
  %mem825 = alloca i8, i64 8, align 8
  %ptr826 = ptrtoint ptr %mem825 to i64
  store i64 %ptr826, ptr %slot7, align 8
  %mem827 = alloca i8, i64 8, align 8
  %ptr828 = ptrtoint ptr %mem827 to i64
  store i64 %ptr828, ptr %slot8, align 8
  %mem829 = alloca i8, i64 8, align 8
  %ptr830 = ptrtoint ptr %mem829 to i64
  store i64 %ptr830, ptr %slot9, align 8
  %mem831 = alloca i8, i64 8, align 8
  %ptr832 = ptrtoint ptr %mem831 to i64
  store i64 %ptr832, ptr %slot10, align 8
  %mem833 = alloca i8, i64 8, align 8
  %ptr834 = ptrtoint ptr %mem833 to i64
  store i64 %ptr834, ptr %slot11, align 8
  %mem835 = alloca i8, i64 8, align 8
  %ptr836 = ptrtoint ptr %mem835 to i64
  store i64 %ptr836, ptr %slot12, align 8
  %mem837 = alloca i8, i64 8, align 8
  %ptr838 = ptrtoint ptr %mem837 to i64
  store i64 %ptr838, ptr %slot13, align 8
  %mem839 = alloca i8, i64 8, align 8
  %ptr840 = ptrtoint ptr %mem839 to i64
  store i64 %ptr840, ptr %slot14, align 8
  %mem841 = alloca i8, i64 8, align 8
  %ptr842 = ptrtoint ptr %mem841 to i64
  store i64 %ptr842, ptr %slot15, align 8
  %mem843 = alloca i8, i64 8, align 8
  %ptr844 = ptrtoint ptr %mem843 to i64
  store i64 %ptr844, ptr %slot16, align 8
  %mem845 = alloca i8, i64 8, align 8
  %ptr846 = ptrtoint ptr %mem845 to i64
  store i64 %ptr846, ptr %slot17, align 8
  %mem847 = alloca i8, i64 8, align 8
  %ptr848 = ptrtoint ptr %mem847 to i64
  store i64 %ptr848, ptr %slot18, align 8
  %mem849 = alloca i8, i64 304, align 8
  %ptr850 = ptrtoint ptr %mem849 to i64
  store i64 %ptr850, ptr %slot19, align 8
  %mem851 = alloca i8, i64 56, align 8
  %ptr852 = ptrtoint ptr %mem851 to i64
  store i64 %ptr852, ptr %slot20, align 8
  %mem853 = alloca i8, i64 8, align 8
  %ptr854 = ptrtoint ptr %mem853 to i64
  store i64 %ptr854, ptr %slot21, align 8
  %mem855 = alloca i8, i64 8, align 8
  %ptr856 = ptrtoint ptr %mem855 to i64
  store i64 %ptr856, ptr %slot22, align 8
  %mem857 = alloca i8, i64 304, align 8
  %ptr858 = ptrtoint ptr %mem857 to i64
  store i64 %ptr858, ptr %slot23, align 8
  %mem859 = alloca i8, i64 8, align 8
  %ptr860 = ptrtoint ptr %mem859 to i64
  store i64 %ptr860, ptr %slot24, align 8
  %mem861 = alloca i8, i64 8, align 8
  %ptr862 = ptrtoint ptr %mem861 to i64
  store i64 %ptr862, ptr %slot25, align 8
  %mem863 = alloca i8, i64 56, align 8
  %ptr864 = ptrtoint ptr %mem863 to i64
  store i64 %ptr864, ptr %slot26, align 8
  %mem865 = alloca i8, i64 8, align 8
  %ptr866 = ptrtoint ptr %mem865 to i64
  store i64 %ptr866, ptr %slot27, align 8
  %mem867 = alloca i8, i64 8, align 8
  %ptr868 = ptrtoint ptr %mem867 to i64
  store i64 %ptr868, ptr %slot28, align 8
  %mem869 = alloca i8, i64 8, align 8
  %ptr870 = ptrtoint ptr %mem869 to i64
  store i64 %ptr870, ptr %slot29, align 8
  %mem871 = alloca i8, i64 8, align 8
  %ptr872 = ptrtoint ptr %mem871 to i64
  store i64 %ptr872, ptr %slot30, align 8
  %mem873 = alloca i8, i64 8, align 8
  %ptr874 = ptrtoint ptr %mem873 to i64
  store i64 %ptr874, ptr %slot31, align 8
  %mem875 = alloca i8, i64 8, align 8
  %ptr876 = ptrtoint ptr %mem875 to i64
  store i64 %ptr876, ptr %slot32, align 8
  %mem877 = alloca i8, i64 8, align 8
  %ptr878 = ptrtoint ptr %mem877 to i64
  store i64 %ptr878, ptr %slot33, align 8
  %mem879 = alloca i8, i64 8, align 8
  %ptr880 = ptrtoint ptr %mem879 to i64
  store i64 %ptr880, ptr %slot34, align 8
  %mem881 = alloca i8, i64 24, align 8
  %ptr882 = ptrtoint ptr %mem881 to i64
  store i64 %ptr882, ptr %slot35, align 8
  %mem883 = alloca i8, i64 24, align 8
  %ptr884 = ptrtoint ptr %mem883 to i64
  store i64 %ptr884, ptr %slot36, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem885 = alloca i8, i64 8, align 8
  %ptr886 = ptrtoint ptr %mem885 to i64
  store i64 %ptr886, ptr %slot37, align 8
  %v887 = load i64, ptr %slot1, align 8
  %op888 = add i64 %v887, 64
  store i64 %op888, ptr %slot38, align 8
  %v889 = load i64, ptr %slot38, align 8
  %p890 = inttoptr i64 %v889 to ptr
  %ld891 = load i64, ptr %p890, align 8, !alias.scope !4, !noalias !3
  store i64 %ld891, ptr %slot39, align 8
  %stack892 = call ptr @llvm.stacksave()
  %stackaddr893 = ptrtoint ptr %stack892 to i64
  %v894 = load i64, ptr %slot39, align 8
  %cmp895 = icmp ult i64 %stackaddr893, %v894
  %cv896 = zext i1 %cmp895 to i64
  store i64 %cv896, ptr %slot40, align 8
  %v897 = load i64, ptr %slot40, align 8
  %cond898 = icmp ne i64 %v897, 0
  br i1 %cond898, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v899 = load i64, ptr %slot1, align 8
  %p900 = inttoptr i64 %v899 to ptr
  call void @myl_qbe_fail_frame(ptr %p900) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v901 = load i64, ptr %slot27, align 8
  %p902 = inttoptr i64 %v901 to ptr
  store i64 0, ptr %p902, align 8, !alias.scope !3, !noalias !4
  %v903 = load i64, ptr %slot31, align 8
  %p904 = inttoptr i64 %v903 to ptr
  store i64 0, ptr %p904, align 8, !alias.scope !3, !noalias !4
  %v905 = load i64, ptr %slot2, align 8
  %v906 = load i64, ptr %slot24, align 8
  %p907 = inttoptr i64 %v906 to ptr
  store i64 %v905, ptr %p907, align 8, !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot3, align 8
  %v909 = load i64, ptr %slot25, align 8
  %p910 = inttoptr i64 %v909 to ptr
  store i64 %v908, ptr %p910, align 8, !alias.scope !3, !noalias !4
  %v911 = load i64, ptr %slot1, align 8
  %p912 = inttoptr i64 %v911 to ptr
  %call913 = call ptr @myl_qbe_heap(ptr %p912) nomerge, !dbg !112
  %calladdr914 = ptrtoint ptr %call913 to i64
  store i64 %calladdr914, ptr %slot41, align 8
  %v915 = load i64, ptr %slot1, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %call917 = call i64 @myl_qbe_region_mark(ptr %p916) nomerge, !dbg !112
  store i64 %call917, ptr %slot42, align 8
  %v918 = load i64, ptr %slot6, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i32 0, ptr %p919, align 4, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot7, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i32 0, ptr %p921, align 4, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot8, align 8
  %p923 = inttoptr i64 %v922 to ptr
  store i32 0, ptr %p923, align 4, !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot9, align 8
  %p925 = inttoptr i64 %v924 to ptr
  store i32 0, ptr %p925, align 4, !alias.scope !3, !noalias !4
  %v926 = load i64, ptr %slot10, align 8
  %p927 = inttoptr i64 %v926 to ptr
  store i32 0, ptr %p927, align 4, !alias.scope !3, !noalias !4
  %v928 = load i64, ptr %slot11, align 8
  %p929 = inttoptr i64 %v928 to ptr
  store i32 0, ptr %p929, align 4, !alias.scope !3, !noalias !4
  %v930 = load i64, ptr %slot12, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i32 0, ptr %p931, align 4, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot13, align 8
  %p933 = inttoptr i64 %v932 to ptr
  store i32 0, ptr %p933, align 4, !alias.scope !3, !noalias !4
  %v934 = load i64, ptr %slot14, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i32 0, ptr %p935, align 4, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot15, align 8
  %p937 = inttoptr i64 %v936 to ptr
  store i32 0, ptr %p937, align 4, !alias.scope !3, !noalias !4
  %v938 = load i64, ptr %slot16, align 8
  %p939 = inttoptr i64 %v938 to ptr
  store i32 0, ptr %p939, align 4, !alias.scope !3, !noalias !4
  %v940 = load i64, ptr %slot17, align 8
  %p941 = inttoptr i64 %v940 to ptr
  store i32 0, ptr %p941, align 4, !alias.scope !3, !noalias !4
  %v942 = load i64, ptr %slot18, align 8
  %p943 = inttoptr i64 %v942 to ptr
  store i32 0, ptr %p943, align 4, !alias.scope !3, !noalias !4
  %v944 = load i64, ptr %slot7, align 8
  %p945 = inttoptr i64 %v944 to ptr
  store i32 2, ptr %p945, align 4, !alias.scope !3, !noalias !4
  %v946 = load i64, ptr %slot9, align 8
  %p947 = inttoptr i64 %v946 to ptr
  store i32 2, ptr %p947, align 4, !alias.scope !3, !noalias !4
  %v948 = load i64, ptr %slot11, align 8
  %p949 = inttoptr i64 %v948 to ptr
  store i32 2, ptr %p949, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v950 = load i64, ptr %slot24, align 8
  %p951 = inttoptr i64 %v950 to ptr
  %ld952 = load i64, ptr %p951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld952, ptr %slot43, align 8
  %v953 = load i64, ptr %slot43, align 8
  %v954 = load i64, ptr %slot32, align 8
  %p955 = inttoptr i64 %v954 to ptr
  store i64 %v953, ptr %p955, align 8, !alias.scope !3, !noalias !4
  %v956 = load i64, ptr %slot25, align 8
  %p957 = inttoptr i64 %v956 to ptr
  %ld958 = load i64, ptr %p957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld958, ptr %slot44, align 8
  %v959 = load i64, ptr %slot44, align 8
  %v960 = load i64, ptr %slot33, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i64 %v959, ptr %p961, align 8, !alias.scope !3, !noalias !4
  %v962 = load i64, ptr %slot32, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ld964 = load i64, ptr %p963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld964, ptr %slot45, align 8
  %v965 = load i64, ptr %slot33, align 8
  %p966 = inttoptr i64 %v965 to ptr
  %ld967 = load i64, ptr %p966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld967, ptr %slot46, align 8
  %v968 = load i64, ptr %slot1, align 8
  %v969 = load i64, ptr %slot45, align 8
  %v970 = load i64, ptr %slot46, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult48, i64 %v968, i64 %v969, i64 %v970) nomerge, !dbg !114
  %addr971 = ptrtoint ptr %callresult48 to i64
  store i64 %addr971, ptr %slot47, align 8
  %v972 = load i64, ptr %slot47, align 8
  %v973 = load i64, ptr %slot32, align 8
  %p974 = inttoptr i64 %v973 to ptr
  store i64 %v972, ptr %p974, align 8, !alias.scope !3, !noalias !4
  %v975 = load i64, ptr %slot32, align 8
  %p976 = inttoptr i64 %v975 to ptr
  %ld977 = load i64, ptr %p976, align 8, !alias.scope !3, !noalias !4
  store i64 %ld977, ptr %slot49, align 8
  %v978 = load i64, ptr %slot23, align 8
  store i64 %v978, ptr %slot50, align 8
  %v979 = load i64, ptr %slot49, align 8
  %v980 = load i64, ptr %slot50, align 8
  %p981 = inttoptr i64 %v979 to ptr
  %p982 = inttoptr i64 %v980 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p982, ptr %p981, i64 56, i1 false)
  %v983 = load i64, ptr %slot17, align 8
  %p984 = inttoptr i64 %v983 to ptr
  store i32 2, ptr %p984, align 4, !alias.scope !3, !noalias !4
  %v985 = load i64, ptr %slot16, align 8
  %p986 = inttoptr i64 %v985 to ptr
  store i32 1, ptr %p986, align 4, !alias.scope !3, !noalias !4
  %v987 = load i64, ptr %slot12, align 8
  %p988 = inttoptr i64 %v987 to ptr
  %ld989 = load i32, ptr %p988, align 4, !alias.scope !3, !noalias !4
  store i32 %ld989, ptr %slot51, align 8
  %v990 = load i32, ptr %slot51, align 8
  %cv991 = zext i32 %v990 to i64
  %cond992 = icmp ne i64 %cv991, 0
  br i1 %cond992, label %bb_rcslotdrop22, label %bb_rcslotdone22
bb_rcslotdrop22:
  %v993 = load i64, ptr %slot12, align 8
  %p994 = inttoptr i64 %v993 to ptr
  store i32 0, ptr %p994, align 4, !alias.scope !3, !noalias !4
  %v995 = load i64, ptr %slot19, align 8
  store i64 %v995, ptr %slot52, align 8
  %v996 = load i64, ptr %slot13, align 8
  %p997 = inttoptr i64 %v996 to ptr
  %ld998 = load i32, ptr %p997, align 4, !alias.scope !3, !noalias !4
  store i32 %ld998, ptr %slot53, align 8
  %v999 = load i32, ptr %slot53, align 8
  %op1000 = and i32 %v999, 28
  store i32 %op1000, ptr %slot54, align 8
  %v1001 = load i32, ptr %slot54, align 8
  %cv1002 = zext i32 %v1001 to i64
  %cond1003 = icmp ne i64 %cv1002, 0
  br i1 %cond1003, label %bb_rcslotrole22, label %bb_rcslotowner22
bb_rcslotrole22:
  %v1004 = load i64, ptr %slot41, align 8
  store i64 %v1004, ptr %slot55, align 8
  %v1005 = load i64, ptr %slot55, align 8
  %v1006 = load i64, ptr %slot52, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1005, i64 %v1006) nomerge, !dbg !114
  br label %bb_rcslotdone22
bb_rcslotowner22:
  %v1007 = load i64, ptr %slot41, align 8
  store i64 %v1007, ptr %slot56, align 8
  %v1008 = load i64, ptr %slot56, align 8
  %v1009 = load i64, ptr %slot52, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1008, i64 %v1009) nomerge, !dbg !114
  br label %bb_rcslotdone22
bb_rcslotdone22:
  %v1010 = load i64, ptr %slot19, align 8
  store i64 %v1010, ptr %slot57, align 8
  %v1011 = load i64, ptr %slot23, align 8
  store i64 %v1011, ptr %slot58, align 8
  %v1012 = load i64, ptr %slot58, align 8
  %v1013 = load i64, ptr %slot57, align 8
  %p1014 = inttoptr i64 %v1012 to ptr
  %p1015 = inttoptr i64 %v1013 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1015, ptr %p1014, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1016 = load i64, ptr %slot13, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  store i32 2, ptr %p1017, align 4, !alias.scope !3, !noalias !4
  %v1018 = load i64, ptr %slot17, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  %ld1020 = load i32, ptr %p1019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1020, ptr %slot59, align 8
  %v1021 = load i32, ptr %slot59, align 8
  %v1022 = load i64, ptr %slot13, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  store i32 %v1021, ptr %p1023, align 4, !alias.scope !3, !noalias !4
  %v1024 = load i64, ptr %slot16, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  store i32 0, ptr %p1025, align 4, !alias.scope !3, !noalias !4
  %v1026 = load i64, ptr %slot12, align 8
  %p1027 = inttoptr i64 %v1026 to ptr
  store i32 1, ptr %p1027, align 4, !alias.scope !3, !noalias !4
  %v1028 = load i64, ptr %slot57, align 8
  %v1029 = load i64, ptr %slot32, align 8
  %p1030 = inttoptr i64 %v1029 to ptr
  store i64 %v1028, ptr %p1030, align 8, !alias.scope !3, !noalias !4
  %v1031 = load i64, ptr %slot32, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  %ld1033 = load i64, ptr %p1032, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1033, ptr %slot60, align 8
  %v1034 = load i64, ptr %slot23, align 8
  store i64 %v1034, ptr %slot61, align 8
  %v1035 = load i64, ptr %slot42, align 8
  store i64 %v1035, ptr %slot62, align 8
  %v1036 = load i64, ptr %slot41, align 8
  %v1037 = load i64, ptr %slot61, align 8
  %v1038 = load i64, ptr %slot60, align 8
  %v1039 = load i64, ptr %slot62, align 8
  %cv1040 = trunc i64 %v1039 to i32
  %call1041 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v1036, i64 %v1037, i64 %v1038, i32 %cv1040) nomerge, !dbg !116
  store i32 %call1041, ptr %slot63, align 8
  %v1042 = load i32, ptr %slot63, align 8
  %cv1043 = zext i32 %v1042 to i64
  %cond1044 = icmp ne i64 %cv1043, 0
  br i1 %cond1044, label %bb_rcsuccess41, label %bb_rcfailure41
bb_rcfailure41:
  %v1045 = load i64, ptr %slot41, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  %call1047 = call i32 @myl_rc_take_failure(ptr %p1046) nomerge, !dbg !116
  store i32 %call1047, ptr %slot64, align 8
  %v1048 = load i64, ptr %slot1, align 8
  %p1049 = inttoptr i64 %v1048 to ptr
  %v1050 = load i32, ptr %slot64, align 8
  %call1051 = call i32 @myl_qbe_rc_status(ptr %p1049, i32 %v1050) nomerge, !dbg !116
  store i32 %call1051, ptr %slot65, align 8
  br label %bb_failure
bb_rcsuccess41:
  %v1052 = load i64, ptr %slot12, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  store i32 0, ptr %p1053, align 4, !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot17, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  store i32 2, ptr %p1055, align 4, !alias.scope !3, !noalias !4
  %v1056 = load i64, ptr %slot16, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  store i32 1, ptr %p1057, align 4, !alias.scope !3, !noalias !4
  %v1058 = load i64, ptr %slot6, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %ld1060 = load i32, ptr %p1059, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1060, ptr %slot66, align 8
  %v1061 = load i32, ptr %slot66, align 8
  %cv1062 = zext i32 %v1061 to i64
  %cond1063 = icmp ne i64 %cv1062, 0
  br i1 %cond1063, label %bb_rcslotdrop50, label %bb_rcslotdone50
bb_rcslotdrop50:
  %v1064 = load i64, ptr %slot6, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  store i32 0, ptr %p1065, align 4, !alias.scope !3, !noalias !4
  %v1066 = load i64, ptr %slot26, align 8
  store i64 %v1066, ptr %slot67, align 8
  %v1067 = load i64, ptr %slot7, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  %ld1069 = load i32, ptr %p1068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1069, ptr %slot68, align 8
  %v1070 = load i32, ptr %slot68, align 8
  %op1071 = and i32 %v1070, 28
  store i32 %op1071, ptr %slot69, align 8
  %v1072 = load i32, ptr %slot69, align 8
  %cv1073 = zext i32 %v1072 to i64
  %cond1074 = icmp ne i64 %cv1073, 0
  br i1 %cond1074, label %bb_rcslotrole50, label %bb_rcslotowner50
bb_rcslotrole50:
  %v1075 = load i64, ptr %slot41, align 8
  store i64 %v1075, ptr %slot70, align 8
  %v1076 = load i64, ptr %slot70, align 8
  %v1077 = load i64, ptr %slot67, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1076, i64 %v1077) nomerge, !dbg !116
  br label %bb_rcslotdone50
bb_rcslotowner50:
  %v1078 = load i64, ptr %slot41, align 8
  store i64 %v1078, ptr %slot71, align 8
  %v1079 = load i64, ptr %slot71, align 8
  %v1080 = load i64, ptr %slot67, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1079, i64 %v1080) nomerge, !dbg !116
  br label %bb_rcslotdone50
bb_rcslotdone50:
  %v1081 = load i64, ptr %slot26, align 8
  store i64 %v1081, ptr %slot72, align 8
  %v1082 = load i64, ptr %slot23, align 8
  store i64 %v1082, ptr %slot73, align 8
  %v1083 = load i64, ptr %slot73, align 8
  %v1084 = load i64, ptr %slot72, align 8
  %p1085 = inttoptr i64 %v1083 to ptr
  %p1086 = inttoptr i64 %v1084 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1086, ptr %p1085, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1087 = load i64, ptr %slot16, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  store i32 0, ptr %p1088, align 4, !alias.scope !3, !noalias !4
  %v1089 = load i64, ptr %slot7, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  store i32 2, ptr %p1090, align 4, !alias.scope !3, !noalias !4
  %v1091 = load i64, ptr %slot17, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  %ld1093 = load i32, ptr %p1092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1093, ptr %slot74, align 8
  %v1094 = load i32, ptr %slot74, align 8
  %v1095 = load i64, ptr %slot7, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  store i32 %v1094, ptr %p1096, align 4, !alias.scope !3, !noalias !4
  %v1097 = load i64, ptr %slot6, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  store i32 1, ptr %p1098, align 4, !alias.scope !3, !noalias !4
  %v1099 = load i64, ptr %slot24, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  %ld1101 = load i64, ptr %p1100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1101, ptr %slot75, align 8
  %v1102 = load i64, ptr %slot75, align 8
  %v1103 = load i64, ptr %slot32, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  store i64 %v1102, ptr %p1104, align 8, !alias.scope !3, !noalias !4
  %v1105 = load i64, ptr %slot26, align 8
  %v1106 = load i64, ptr %slot33, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  store i64 %v1105, ptr %p1107, align 8, !alias.scope !3, !noalias !4
  %v1108 = load i64, ptr %slot33, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %ld1110 = load i64, ptr %p1109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1110, ptr %slot76, align 8
  %v1111 = load i64, ptr %slot76, align 8
  %op1112 = add i64 %v1111, 0
  store i64 %op1112, ptr %slot77, align 8
  %v1113 = load i64, ptr %slot77, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  %ld1115 = load i64, ptr %p1114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1115, ptr %slot78, align 8
  %v1116 = load i64, ptr %slot78, align 8
  %v1117 = load i64, ptr %slot33, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  store i64 %v1116, ptr %p1118, align 8, !alias.scope !3, !noalias !4
  %v1119 = load i64, ptr %slot14, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  %ld1121 = load i32, ptr %p1120, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1121, ptr %slot79, align 8
  %v1122 = load i32, ptr %slot79, align 8
  %cv1123 = zext i32 %v1122 to i64
  %cond1124 = icmp ne i64 %cv1123, 0
  br i1 %cond1124, label %bb_rcslotdrop70, label %bb_rcslotdone70
bb_rcslotdrop70:
  %v1125 = load i64, ptr %slot14, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  store i32 0, ptr %p1126, align 4, !alias.scope !3, !noalias !4
  %v1127 = load i64, ptr %slot20, align 8
  store i64 %v1127, ptr %slot80, align 8
  %v1128 = load i64, ptr %slot15, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %ld1130 = load i32, ptr %p1129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1130, ptr %slot81, align 8
  %v1131 = load i32, ptr %slot81, align 8
  %op1132 = and i32 %v1131, 28
  store i32 %op1132, ptr %slot82, align 8
  %v1133 = load i32, ptr %slot82, align 8
  %cv1134 = zext i32 %v1133 to i64
  %cond1135 = icmp ne i64 %cv1134, 0
  br i1 %cond1135, label %bb_rcslotrole70, label %bb_rcslotowner70
bb_rcslotrole70:
  %v1136 = load i64, ptr %slot41, align 8
  store i64 %v1136, ptr %slot83, align 8
  %v1137 = load i64, ptr %slot83, align 8
  %v1138 = load i64, ptr %slot80, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1137, i64 %v1138) nomerge, !dbg !118
  br label %bb_rcslotdone70
bb_rcslotowner70:
  %v1139 = load i64, ptr %slot41, align 8
  store i64 %v1139, ptr %slot84, align 8
  %v1140 = load i64, ptr %slot84, align 8
  %v1141 = load i64, ptr %slot80, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1140, i64 %v1141) nomerge, !dbg !118
  br label %bb_rcslotdone70
bb_rcslotdone70:
  %v1142 = load i64, ptr %slot32, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %ld1144 = load i64, ptr %p1143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1144, ptr %slot85, align 8
  %v1145 = load i64, ptr %slot33, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  %ld1147 = load i64, ptr %p1146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1147, ptr %slot86, align 8
  %v1148 = load i64, ptr %slot1, align 8
  %v1149 = load i64, ptr %slot85, align 8
  %v1150 = load i64, ptr %slot86, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult88, i64 %v1148, i64 %v1149, i64 %v1150) nomerge, !dbg !120
  %addr1151 = ptrtoint ptr %callresult88 to i64
  store i64 %addr1151, ptr %slot87, align 8
  %v1152 = load i64, ptr %slot87, align 8
  %v1153 = load i64, ptr %slot32, align 8
  %p1154 = inttoptr i64 %v1153 to ptr
  store i64 %v1152, ptr %p1154, align 8, !alias.scope !3, !noalias !4
  %v1155 = load i64, ptr %slot32, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  %ld1157 = load i64, ptr %p1156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1157, ptr %slot89, align 8
  %v1158 = load i64, ptr %slot23, align 8
  store i64 %v1158, ptr %slot90, align 8
  %v1159 = load i64, ptr %slot89, align 8
  %v1160 = load i64, ptr %slot90, align 8
  %p1161 = inttoptr i64 %v1159 to ptr
  %p1162 = inttoptr i64 %v1160 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1162, ptr %p1161, i64 24, i1 false)
  %v1163 = load i64, ptr %slot17, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  store i32 2, ptr %p1164, align 4, !alias.scope !3, !noalias !4
  %v1165 = load i64, ptr %slot16, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  store i32 1, ptr %p1166, align 4, !alias.scope !3, !noalias !4
  %v1167 = load i64, ptr %slot12, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  %ld1169 = load i32, ptr %p1168, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1169, ptr %slot91, align 8
  %v1170 = load i32, ptr %slot91, align 8
  %cv1171 = zext i32 %v1170 to i64
  %cond1172 = icmp ne i64 %cv1171, 0
  br i1 %cond1172, label %bb_rcslotdrop86, label %bb_rcslotdone86
bb_rcslotdrop86:
  %v1173 = load i64, ptr %slot12, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  store i32 0, ptr %p1174, align 4, !alias.scope !3, !noalias !4
  %v1175 = load i64, ptr %slot19, align 8
  store i64 %v1175, ptr %slot92, align 8
  %v1176 = load i64, ptr %slot13, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  %ld1178 = load i32, ptr %p1177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1178, ptr %slot93, align 8
  %v1179 = load i32, ptr %slot93, align 8
  %op1180 = and i32 %v1179, 28
  store i32 %op1180, ptr %slot94, align 8
  %v1181 = load i32, ptr %slot94, align 8
  %cv1182 = zext i32 %v1181 to i64
  %cond1183 = icmp ne i64 %cv1182, 0
  br i1 %cond1183, label %bb_rcslotrole86, label %bb_rcslotowner86
bb_rcslotrole86:
  %v1184 = load i64, ptr %slot41, align 8
  store i64 %v1184, ptr %slot95, align 8
  %v1185 = load i64, ptr %slot95, align 8
  %v1186 = load i64, ptr %slot92, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1185, i64 %v1186) nomerge, !dbg !120
  br label %bb_rcslotdone86
bb_rcslotowner86:
  %v1187 = load i64, ptr %slot41, align 8
  store i64 %v1187, ptr %slot96, align 8
  %v1188 = load i64, ptr %slot96, align 8
  %v1189 = load i64, ptr %slot92, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1188, i64 %v1189) nomerge, !dbg !120
  br label %bb_rcslotdone86
bb_rcslotdone86:
  %v1190 = load i64, ptr %slot19, align 8
  store i64 %v1190, ptr %slot97, align 8
  %v1191 = load i64, ptr %slot23, align 8
  store i64 %v1191, ptr %slot98, align 8
  %v1192 = load i64, ptr %slot98, align 8
  %v1193 = load i64, ptr %slot97, align 8
  %p1194 = inttoptr i64 %v1192 to ptr
  %p1195 = inttoptr i64 %v1193 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1195, ptr %p1194, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1196 = load i64, ptr %slot13, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  store i32 2, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  %v1198 = load i64, ptr %slot17, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  %ld1200 = load i32, ptr %p1199, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1200, ptr %slot99, align 8
  %v1201 = load i32, ptr %slot99, align 8
  %v1202 = load i64, ptr %slot13, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  store i32 %v1201, ptr %p1203, align 4, !alias.scope !3, !noalias !4
  %v1204 = load i64, ptr %slot16, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  store i32 0, ptr %p1205, align 4, !alias.scope !3, !noalias !4
  %v1206 = load i64, ptr %slot12, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  store i32 1, ptr %p1207, align 4, !alias.scope !3, !noalias !4
  %v1208 = load i64, ptr %slot97, align 8
  %v1209 = load i64, ptr %slot32, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i64 %v1208, ptr %p1210, align 8, !alias.scope !3, !noalias !4
  %v1211 = load i64, ptr %slot32, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  %ld1213 = load i64, ptr %p1212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1213, ptr %slot100, align 8
  %v1214 = load i64, ptr %slot100, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  %ld1216 = load i32, ptr %p1215, align 4, !alias.scope !3, !noalias !4
  %ext1217 = zext i32 %ld1216 to i64
  store i64 %ext1217, ptr %slot101, align 8
  %v1218 = load i64, ptr %slot101, align 8
  %cmp1219 = icmp eq i64 %v1218, 0
  %cv1220 = zext i1 %cmp1219 to i64
  store i64 %cv1220, ptr %slot102, align 8
  %v1221 = load i64, ptr %slot102, align 8
  %cond1222 = icmp ne i64 %v1221, 0
  br i1 %cond1222, label %bb_rctryok102, label %bb_rctryerror102
bb_rctryerror102:
  %p1223 = inttoptr i64 ptrtoint (ptr @myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1223, i64 12884901896) "call-inline-cost"="0", !dbg !122
  %v1224 = load i64, ptr %slot100, align 8
  %op1225 = add i64 %v1224, 8
  store i64 %op1225, ptr %slot103, align 8
  %v1226 = load i64, ptr %slot35, align 8
  store i64 %v1226, ptr %slot104, align 8
  %v1227 = load i64, ptr %slot104, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  store i64 0, ptr %p1228, align 8, !alias.scope !3, !noalias !4
  %v1229 = load i64, ptr %slot104, align 8
  %p1231 = inttoptr i64 %v1229 to ptr
  %gep1232 = getelementptr i8, ptr %p1231, i64 8
  %op1230 = ptrtoint ptr %gep1232 to i64
  store i64 %op1230, ptr %slot105, align 8
  %v1233 = load i64, ptr %slot105, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  store i64 0, ptr %p1234, align 8, !alias.scope !3, !noalias !4
  %v1235 = load i64, ptr %slot104, align 8
  %p1237 = inttoptr i64 %v1235 to ptr
  %gep1238 = getelementptr i8, ptr %p1237, i64 16
  %op1236 = ptrtoint ptr %gep1238 to i64
  store i64 %op1236, ptr %slot106, align 8
  %v1239 = load i64, ptr %slot106, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  store i64 0, ptr %p1240, align 8, !alias.scope !3, !noalias !4
  %v1241 = load i64, ptr %slot104, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  store i32 1, ptr %p1242, align 4, !alias.scope !3, !noalias !4
  %v1243 = load i64, ptr %slot104, align 8
  %p1245 = inttoptr i64 %v1243 to ptr
  %gep1246 = getelementptr i8, ptr %p1245, i64 8
  %op1244 = ptrtoint ptr %gep1246 to i64
  store i64 %op1244, ptr %slot107, align 8
  %v1247 = load i64, ptr %slot18, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  store i32 1, ptr %p1248, align 4, !alias.scope !3, !noalias !4
  %v1249 = load i64, ptr %slot42, align 8
  store i64 %v1249, ptr %slot108, align 8
  %v1250 = load i64, ptr %slot41, align 8
  %v1251 = load i64, ptr %slot107, align 8
  %v1252 = load i64, ptr %slot103, align 8
  %v1253 = load i64, ptr %slot108, align 8
  %cv1254 = trunc i64 %v1253 to i32
  %call1255 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v1250, i64 %v1251, i64 %v1252, i32 %cv1254) nomerge, !dbg !122
  store i32 %call1255, ptr %slot109, align 8
  %v1256 = load i32, ptr %slot109, align 8
  %cv1257 = zext i32 %v1256 to i64
  %cond1258 = icmp ne i64 %cv1257, 0
  br i1 %cond1258, label %bb_rcsuccess113, label %bb_rcfailure113
bb_rcfailure113:
  %v1259 = load i64, ptr %slot41, align 8
  %p1260 = inttoptr i64 %v1259 to ptr
  %call1261 = call i32 @myl_rc_take_failure(ptr %p1260) nomerge, !dbg !122
  store i32 %call1261, ptr %slot110, align 8
  %v1262 = load i64, ptr %slot1, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %v1264 = load i32, ptr %slot110, align 8
  %call1265 = call i32 @myl_qbe_rc_status(ptr %p1263, i32 %v1264) nomerge, !dbg !122
  store i32 %call1265, ptr %slot111, align 8
  br label %bb_failure
bb_rcsuccess113:
  %v1266 = load i64, ptr %slot104, align 8
  %v1267 = load i64, ptr %slot32, align 8
  %p1268 = inttoptr i64 %v1267 to ptr
  store i64 %v1266, ptr %p1268, align 8, !alias.scope !3, !noalias !4
  %v1269 = load i64, ptr %slot32, align 8
  %p1270 = inttoptr i64 %v1269 to ptr
  %ld1271 = load i64, ptr %p1270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1271, ptr %slot112, align 8
  %v1272 = load i64, ptr %slot23, align 8
  store i64 %v1272, ptr %slot113, align 8
  %v1273 = load i64, ptr %slot112, align 8
  %v1274 = load i64, ptr %slot113, align 8
  %p1275 = inttoptr i64 %v1273 to ptr
  %p1276 = inttoptr i64 %v1274 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1276, ptr %p1275, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1277 = load i64, ptr %slot17, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  store i32 2, ptr %p1278, align 4, !alias.scope !3, !noalias !4
  %v1279 = load i64, ptr %slot16, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  store i32 1, ptr %p1280, align 4, !alias.scope !3, !noalias !4
  %v1281 = load i64, ptr %slot12, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  %ld1283 = load i32, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1283, ptr %slot114, align 8
  %v1284 = load i32, ptr %slot114, align 8
  %cv1285 = zext i32 %v1284 to i64
  %cond1286 = icmp ne i64 %cv1285, 0
  br i1 %cond1286, label %bb_rcslotdrop122, label %bb_rcslotdone122
bb_rcslotdrop122:
  %v1287 = load i64, ptr %slot12, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i32 0, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot19, align 8
  store i64 %v1289, ptr %slot115, align 8
  %v1290 = load i64, ptr %slot13, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  %ld1292 = load i32, ptr %p1291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1292, ptr %slot116, align 8
  %v1293 = load i32, ptr %slot116, align 8
  %op1294 = and i32 %v1293, 28
  store i32 %op1294, ptr %slot117, align 8
  %v1295 = load i32, ptr %slot117, align 8
  %cv1296 = zext i32 %v1295 to i64
  %cond1297 = icmp ne i64 %cv1296, 0
  br i1 %cond1297, label %bb_rcslotrole122, label %bb_rcslotowner122
bb_rcslotrole122:
  %v1298 = load i64, ptr %slot41, align 8
  store i64 %v1298, ptr %slot118, align 8
  %v1299 = load i64, ptr %slot118, align 8
  %v1300 = load i64, ptr %slot115, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1299, i64 %v1300) nomerge, !dbg !122
  br label %bb_rcslotdone122
bb_rcslotowner122:
  %v1301 = load i64, ptr %slot41, align 8
  store i64 %v1301, ptr %slot119, align 8
  %v1302 = load i64, ptr %slot119, align 8
  %v1303 = load i64, ptr %slot115, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1302, i64 %v1303) nomerge, !dbg !122
  br label %bb_rcslotdone122
bb_rcslotdone122:
  %v1304 = load i64, ptr %slot19, align 8
  store i64 %v1304, ptr %slot120, align 8
  %v1305 = load i64, ptr %slot23, align 8
  store i64 %v1305, ptr %slot121, align 8
  %v1306 = load i64, ptr %slot121, align 8
  %v1307 = load i64, ptr %slot120, align 8
  %p1308 = inttoptr i64 %v1306 to ptr
  %p1309 = inttoptr i64 %v1307 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1309, ptr %p1308, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1310 = load i64, ptr %slot13, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  store i32 2, ptr %p1311, align 4, !alias.scope !3, !noalias !4
  %v1312 = load i64, ptr %slot17, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  %ld1314 = load i32, ptr %p1313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1314, ptr %slot122, align 8
  %v1315 = load i32, ptr %slot122, align 8
  %v1316 = load i64, ptr %slot13, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  store i32 %v1315, ptr %p1317, align 4, !alias.scope !3, !noalias !4
  %v1318 = load i64, ptr %slot16, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i32 0, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  %v1320 = load i64, ptr %slot12, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i32 1, ptr %p1321, align 4, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot120, align 8
  %v1323 = load i64, ptr %slot32, align 8
  %p1324 = inttoptr i64 %v1323 to ptr
  store i64 %v1322, ptr %p1324, align 8, !alias.scope !3, !noalias !4
  br label %bb_i10
bb_rctryok102:
  %v1325 = load i64, ptr %slot35, align 8
  store i64 %v1325, ptr %slot123, align 8
  %v1326 = load i64, ptr %slot18, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  store i32 1, ptr %p1327, align 4, !alias.scope !3, !noalias !4
  %v1328 = load i64, ptr %slot100, align 8
  %op1329 = add i64 %v1328, 8
  store i64 %op1329, ptr %slot124, align 8
  %v1330 = load i64, ptr %slot42, align 8
  store i64 %v1330, ptr %slot125, align 8
  store i64 0, ptr %slot126, align 8
  store i64 0, ptr %slot127, align 8
  %v1331 = load i64, ptr %slot127, align 8
  %v1332 = load i64, ptr %slot32, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i64 %v1331, ptr %p1333, align 8, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot12, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  %ld1336 = load i32, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1336, ptr %slot128, align 8
  %v1337 = load i32, ptr %slot128, align 8
  %cv1338 = zext i32 %v1337 to i64
  %cond1339 = icmp ne i64 %cv1338, 0
  br i1 %cond1339, label %bb_rcslotdrop146, label %bb_rcslotdone146
bb_rcslotdrop146:
  %v1340 = load i64, ptr %slot12, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  store i32 0, ptr %p1341, align 4, !alias.scope !3, !noalias !4
  %v1342 = load i64, ptr %slot19, align 8
  store i64 %v1342, ptr %slot129, align 8
  %v1343 = load i64, ptr %slot13, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  %ld1345 = load i32, ptr %p1344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1345, ptr %slot130, align 8
  %v1346 = load i32, ptr %slot130, align 8
  %op1347 = and i32 %v1346, 28
  store i32 %op1347, ptr %slot131, align 8
  %v1348 = load i32, ptr %slot131, align 8
  %cv1349 = zext i32 %v1348 to i64
  %cond1350 = icmp ne i64 %cv1349, 0
  br i1 %cond1350, label %bb_rcslotrole146, label %bb_rcslotowner146
bb_rcslotrole146:
  %v1351 = load i64, ptr %slot41, align 8
  store i64 %v1351, ptr %slot132, align 8
  %v1352 = load i64, ptr %slot132, align 8
  %v1353 = load i64, ptr %slot129, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1352, i64 %v1353) nomerge, !dbg !122
  br label %bb_rcslotdone146
bb_rcslotowner146:
  %v1354 = load i64, ptr %slot41, align 8
  store i64 %v1354, ptr %slot133, align 8
  %v1355 = load i64, ptr %slot133, align 8
  %v1356 = load i64, ptr %slot129, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1355, i64 %v1356) nomerge, !dbg !122
  br label %bb_rcslotdone146
bb_rcslotdone146:
  br label %bb_i11
bb_i10:
  %v1357 = load i64, ptr %slot32, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  %ld1359 = load i64, ptr %p1358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1359, ptr %slot134, align 8
  %v1360 = load i64, ptr %slot32, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  %ld1362 = load i64, ptr %p1361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1362, ptr %slot135, align 8
  %v1363 = load i64, ptr %slot12, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  %ld1365 = load i32, ptr %p1364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1365, ptr %slot136, align 8
  %v1366 = load i64, ptr %slot13, align 8
  %p1367 = inttoptr i64 %v1366 to ptr
  %ld1368 = load i32, ptr %p1367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1368, ptr %slot137, align 8
  %v1369 = load i32, ptr %slot137, align 8
  %op1370 = and i32 %v1369, 24
  store i32 %op1370, ptr %slot137, align 8
  %v1371 = load i32, ptr %slot137, align 8
  %cmp1372 = icmp eq i32 %v1371, 0
  %cv1373 = zext i1 %cmp1372 to i32
  store i32 %cv1373, ptr %slot138, align 8
  %v1374 = load i32, ptr %slot136, align 8
  %v1375 = load i32, ptr %slot138, align 8
  %op1376 = and i32 %v1374, %v1375
  store i32 %op1376, ptr %slot139, align 8
  %v1377 = load i32, ptr %slot139, align 8
  %cv1378 = zext i32 %v1377 to i64
  %cond1379 = icmp ne i64 %cv1378, 0
  br i1 %cond1379, label %bb_rctake155, label %bb_rccopy155
bb_rctake155:
  %v1380 = load i64, ptr %slot23, align 8
  store i64 %v1380, ptr %slot140, align 8
  %v1381 = load i64, ptr %slot42, align 8
  store i64 %v1381, ptr %slot141, align 8
  %v1382 = load i64, ptr %slot41, align 8
  %v1383 = load i64, ptr %slot140, align 8
  %v1384 = load i64, ptr %slot135, align 8
  %v1385 = load i64, ptr %slot141, align 8
  %cv1386 = trunc i64 %v1385 to i32
  %call1387 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v1382, i64 %v1383, i64 %v1384, i32 %cv1386) nomerge, !dbg !124
  store i32 %call1387, ptr %slot142, align 8
  %v1388 = load i32, ptr %slot142, align 8
  %cv1389 = zext i32 %v1388 to i64
  %cond1390 = icmp ne i64 %cv1389, 0
  br i1 %cond1390, label %bb_rcsuccess165, label %bb_rcfailure165
bb_rcfailure165:
  %v1391 = load i64, ptr %slot41, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %call1393 = call i32 @myl_rc_take_failure(ptr %p1392) nomerge, !dbg !124
  store i32 %call1393, ptr %slot143, align 8
  %v1394 = load i64, ptr %slot1, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  %v1396 = load i32, ptr %slot143, align 8
  %call1397 = call i32 @myl_qbe_rc_status(ptr %p1395, i32 %v1396) nomerge, !dbg !124
  store i32 %call1397, ptr %slot144, align 8
  br label %bb_failure
bb_rcsuccess165:
  %v1398 = load i64, ptr %slot12, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  store i32 0, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  %v1400 = load i64, ptr %slot17, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 2, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot16, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  store i32 1, ptr %p1403, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared155
bb_rccopy155:
  %v1404 = load i64, ptr %slot23, align 8
  store i64 %v1404, ptr %slot145, align 8
  %v1405 = load i64, ptr %slot42, align 8
  store i64 %v1405, ptr %slot146, align 8
  %v1406 = load i64, ptr %slot41, align 8
  %v1407 = load i64, ptr %slot145, align 8
  %v1408 = load i64, ptr %slot135, align 8
  %v1409 = load i64, ptr %slot146, align 8
  %cv1410 = trunc i64 %v1409 to i32
  %call1411 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v1406, i64 %v1407, i64 %v1408, i32 %cv1410) nomerge, !dbg !124
  store i32 %call1411, ptr %slot147, align 8
  %v1412 = load i32, ptr %slot147, align 8
  %cv1413 = zext i32 %v1412 to i64
  %cond1414 = icmp ne i64 %cv1413, 0
  br i1 %cond1414, label %bb_rcsuccess174, label %bb_rcfailure174
bb_rcfailure174:
  %v1415 = load i64, ptr %slot41, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  %call1417 = call i32 @myl_rc_take_failure(ptr %p1416) nomerge, !dbg !124
  store i32 %call1417, ptr %slot148, align 8
  %v1418 = load i64, ptr %slot1, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  %v1420 = load i32, ptr %slot148, align 8
  %call1421 = call i32 @myl_qbe_rc_status(ptr %p1419, i32 %v1420) nomerge, !dbg !124
  store i32 %call1421, ptr %slot149, align 8
  br label %bb_failure
bb_rcsuccess174:
  %v1422 = load i64, ptr %slot17, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i32 2, ptr %p1423, align 4, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot16, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i32 1, ptr %p1425, align 4, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot12, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  %ld1428 = load i32, ptr %p1427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1428, ptr %slot150, align 8
  %v1429 = load i32, ptr %slot150, align 8
  %cv1430 = zext i32 %v1429 to i64
  %cond1431 = icmp ne i64 %cv1430, 0
  br i1 %cond1431, label %bb_rcslotdrop181, label %bb_rcslotdone181
bb_rcslotdrop181:
  %v1432 = load i64, ptr %slot12, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  store i32 0, ptr %p1433, align 4, !alias.scope !3, !noalias !4
  %v1434 = load i64, ptr %slot19, align 8
  store i64 %v1434, ptr %slot151, align 8
  %v1435 = load i64, ptr %slot13, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  %ld1437 = load i32, ptr %p1436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1437, ptr %slot152, align 8
  %v1438 = load i32, ptr %slot152, align 8
  %op1439 = and i32 %v1438, 28
  store i32 %op1439, ptr %slot153, align 8
  %v1440 = load i32, ptr %slot153, align 8
  %cv1441 = zext i32 %v1440 to i64
  %cond1442 = icmp ne i64 %cv1441, 0
  br i1 %cond1442, label %bb_rcslotrole181, label %bb_rcslotowner181
bb_rcslotrole181:
  %v1443 = load i64, ptr %slot41, align 8
  store i64 %v1443, ptr %slot154, align 8
  %v1444 = load i64, ptr %slot154, align 8
  %v1445 = load i64, ptr %slot151, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1444, i64 %v1445) nomerge, !dbg !124
  br label %bb_rcslotdone181
bb_rcslotowner181:
  %v1446 = load i64, ptr %slot41, align 8
  store i64 %v1446, ptr %slot155, align 8
  %v1447 = load i64, ptr %slot155, align 8
  %v1448 = load i64, ptr %slot151, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1447, i64 %v1448) nomerge, !dbg !124
  br label %bb_rcslotdone181
bb_rcslotdone181:
  br label %bb_rcprepared155
bb_rcprepared155:
  %v1449 = load i64, ptr %slot23, align 8
  store i64 %v1449, ptr %slot156, align 8
  %v1450 = load i64, ptr %slot16, align 8
  %p1451 = inttoptr i64 %v1450 to ptr
  store i32 0, ptr %p1451, align 4, !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot12, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  %ld1454 = load i32, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1454, ptr %slot157, align 8
  %v1455 = load i32, ptr %slot157, align 8
  %cv1456 = zext i32 %v1455 to i64
  %cond1457 = icmp ne i64 %cv1456, 0
  br i1 %cond1457, label %bb_rcslotdrop192, label %bb_rcslotdone192
bb_rcslotdrop192:
  %v1458 = load i64, ptr %slot12, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i32 0, ptr %p1459, align 4, !alias.scope !3, !noalias !4
  %v1460 = load i64, ptr %slot19, align 8
  store i64 %v1460, ptr %slot158, align 8
  %v1461 = load i64, ptr %slot13, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  %ld1463 = load i32, ptr %p1462, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1463, ptr %slot159, align 8
  %v1464 = load i32, ptr %slot159, align 8
  %op1465 = and i32 %v1464, 28
  store i32 %op1465, ptr %slot160, align 8
  %v1466 = load i32, ptr %slot160, align 8
  %cv1467 = zext i32 %v1466 to i64
  %cond1468 = icmp ne i64 %cv1467, 0
  br i1 %cond1468, label %bb_rcslotrole192, label %bb_rcslotowner192
bb_rcslotrole192:
  %v1469 = load i64, ptr %slot41, align 8
  store i64 %v1469, ptr %slot161, align 8
  %v1470 = load i64, ptr %slot161, align 8
  %v1471 = load i64, ptr %slot158, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1470, i64 %v1471) nomerge, !dbg !124
  br label %bb_rcslotdone192
bb_rcslotowner192:
  %v1472 = load i64, ptr %slot41, align 8
  store i64 %v1472, ptr %slot162, align 8
  %v1473 = load i64, ptr %slot162, align 8
  %v1474 = load i64, ptr %slot158, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1473, i64 %v1474) nomerge, !dbg !124
  br label %bb_rcslotdone192
bb_rcslotdone192:
  %v1475 = load i64, ptr %slot10, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ld1477 = load i32, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1477, ptr %slot163, align 8
  %v1478 = load i32, ptr %slot163, align 8
  %cv1479 = zext i32 %v1478 to i64
  %cond1480 = icmp ne i64 %cv1479, 0
  br i1 %cond1480, label %bb_rcslotdrop201, label %bb_rcslotdone201
bb_rcslotdrop201:
  %v1481 = load i64, ptr %slot10, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i32 0, ptr %p1482, align 4, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot31, align 8
  store i64 %v1483, ptr %slot164, align 8
  %v1484 = load i64, ptr %slot11, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %ld1486 = load i32, ptr %p1485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1486, ptr %slot165, align 8
  %v1487 = load i32, ptr %slot165, align 8
  %op1488 = and i32 %v1487, 28
  store i32 %op1488, ptr %slot166, align 8
  %v1489 = load i32, ptr %slot166, align 8
  %cv1490 = zext i32 %v1489 to i64
  %cond1491 = icmp ne i64 %cv1490, 0
  br i1 %cond1491, label %bb_rcslotrole201, label %bb_rcslotowner201
bb_rcslotrole201:
  %v1492 = load i64, ptr %slot41, align 8
  store i64 %v1492, ptr %slot167, align 8
  %v1493 = load i64, ptr %slot164, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  %ld1495 = load i64, ptr %p1494, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1495, ptr %slot168, align 8
  %v1496 = load i64, ptr %slot168, align 8
  %cmp1497 = icmp ne i64 %v1496, 0
  %cv1498 = zext i1 %cmp1497 to i32
  store i32 %cv1498, ptr %slot169, align 8
  %v1499 = load i32, ptr %slot169, align 8
  %cv1500 = zext i32 %v1499 to i64
  %cond1501 = icmp ne i64 %cv1500, 0
  br i1 %cond1501, label %bb_rcgnn217, label %bb_rcgdone217
bb_rcgnn217:
  %v1502 = load i64, ptr %slot168, align 8
  %op1503 = sub i64 %v1502, 16
  store i64 %op1503, ptr %slot170, align 8
  %v1504 = load i64, ptr %slot168, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  %rgep1506 = getelementptr i8, ptr %p1505, i64 -16
  %ld1507 = load i64, ptr %rgep1506, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1507, ptr %slot171, align 8
  %v1508 = load i64, ptr %slot171, align 8
  %op1509 = and i64 %v1508, 4611686018427387906
  store i64 %op1509, ptr %slot172, align 8
  %v1510 = load i64, ptr %slot172, align 8
  %cmp1511 = icmp ne i64 %v1510, 0
  %cv1512 = zext i1 %cmp1511 to i32
  store i32 %cv1512, ptr %slot173, align 8
  %v1513 = load i32, ptr %slot173, align 8
  %cv1514 = zext i32 %v1513 to i64
  %cond1515 = icmp ne i64 %cv1514, 0
  br i1 %cond1515, label %bb_rcgclear217, label %bb_rcgcounted217
bb_rcgcounted217:
  %v1516 = load i64, ptr %slot168, align 8
  %op1517 = sub i64 %v1516, 24
  store i64 %op1517, ptr %slot174, align 8
  %v1518 = load i64, ptr %slot168, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  %rgep1520 = getelementptr i8, ptr %p1519, i64 -24
  %ld1521 = load i64, ptr %rgep1520, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1521, ptr %slot175, align 8
  %v1522 = load i64, ptr %slot175, align 8
  %op1523 = sub i64 %v1522, 1
  store i64 %op1523, ptr %slot176, align 8
  %v1524 = load i64, ptr %slot176, align 8
  %cmp1525 = icmp eq i64 %v1524, 0
  %cv1526 = zext i1 %cmp1525 to i32
  store i32 %cv1526, ptr %slot177, align 8
  %v1527 = load i32, ptr %slot177, align 8
  %cv1528 = zext i32 %v1527 to i64
  %cond1529 = icmp ne i64 %cv1528, 0
  br i1 %cond1529, label %bb_rcglast217, label %bb_rcgdec217
bb_rcglast217:
  %v1530 = load i64, ptr %slot168, align 8
  %op1531 = sub i64 %v1530, 32
  store i64 %op1531, ptr %slot178, align 8
  %v1532 = load i64, ptr %slot168, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  %rgep1534 = getelementptr i8, ptr %p1533, i64 -32
  %ld1535 = load i64, ptr %rgep1534, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1535, ptr %slot179, align 8
  %v1536 = load i64, ptr %slot179, align 8
  %cmp1537 = icmp ne i64 %v1536, 0
  %cv1538 = zext i1 %cmp1537 to i32
  store i32 %cv1538, ptr %slot180, align 8
  %v1539 = load i32, ptr %slot180, align 8
  %cv1540 = zext i32 %v1539 to i64
  %cond1541 = icmp ne i64 %cv1540, 0
  br i1 %cond1541, label %bb_rcgdec217, label %bb_rcgslow217
bb_rcgslow217:
  %v1542 = load i64, ptr %slot167, align 8
  %v1543 = load i64, ptr %slot164, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1542, i64 %v1543) nomerge, !dbg !124
  br label %bb_rcgdone217
bb_rcgdec217:
  %v1544 = load i64, ptr %slot176, align 8
  %v1545 = load i64, ptr %slot168, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  %rgep1547 = getelementptr i8, ptr %p1546, i64 -24
  store i64 %v1544, ptr %rgep1547, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear217
bb_rcgclear217:
  %v1548 = load i64, ptr %slot164, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  store i64 0, ptr %p1549, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone217
bb_rcgdone217:
  br label %bb_rcslotdone201
bb_rcslotowner201:
  %v1550 = load i64, ptr %slot41, align 8
  store i64 %v1550, ptr %slot181, align 8
  %v1551 = load i64, ptr %slot164, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %ld1553 = load i64, ptr %p1552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1553, ptr %slot182, align 8
  %v1554 = load i64, ptr %slot182, align 8
  %cmp1555 = icmp ne i64 %v1554, 0
  %cv1556 = zext i1 %cmp1555 to i32
  store i32 %cv1556, ptr %slot183, align 8
  %v1557 = load i32, ptr %slot183, align 8
  %cv1558 = zext i32 %v1557 to i64
  %cond1559 = icmp ne i64 %cv1558, 0
  br i1 %cond1559, label %bb_rcgnn232, label %bb_rcgdone232
bb_rcgnn232:
  %v1560 = load i64, ptr %slot182, align 8
  %op1561 = sub i64 %v1560, 16
  store i64 %op1561, ptr %slot184, align 8
  %v1562 = load i64, ptr %slot182, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  %rgep1564 = getelementptr i8, ptr %p1563, i64 -16
  %ld1565 = load i64, ptr %rgep1564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1565, ptr %slot185, align 8
  %v1566 = load i64, ptr %slot185, align 8
  %op1567 = and i64 %v1566, 4611686018427387906
  store i64 %op1567, ptr %slot186, align 8
  %v1568 = load i64, ptr %slot186, align 8
  %cmp1569 = icmp ne i64 %v1568, 0
  %cv1570 = zext i1 %cmp1569 to i32
  store i32 %cv1570, ptr %slot187, align 8
  %v1571 = load i32, ptr %slot187, align 8
  %cv1572 = zext i32 %v1571 to i64
  %cond1573 = icmp ne i64 %cv1572, 0
  br i1 %cond1573, label %bb_rcgclear232, label %bb_rcgcounted232
bb_rcgcounted232:
  %v1574 = load i64, ptr %slot182, align 8
  %op1575 = sub i64 %v1574, 32
  store i64 %op1575, ptr %slot188, align 8
  %v1576 = load i64, ptr %slot182, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  %rgep1578 = getelementptr i8, ptr %p1577, i64 -32
  %ld1579 = load i64, ptr %rgep1578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1579, ptr %slot189, align 8
  %v1580 = load i64, ptr %slot189, align 8
  %op1581 = sub i64 %v1580, 1
  store i64 %op1581, ptr %slot190, align 8
  %v1582 = load i64, ptr %slot190, align 8
  %cmp1583 = icmp eq i64 %v1582, 0
  %cv1584 = zext i1 %cmp1583 to i32
  store i32 %cv1584, ptr %slot191, align 8
  %v1585 = load i32, ptr %slot191, align 8
  %cv1586 = zext i32 %v1585 to i64
  %cond1587 = icmp ne i64 %cv1586, 0
  br i1 %cond1587, label %bb_rcglast232, label %bb_rcgdec232
bb_rcglast232:
  %v1588 = load i64, ptr %slot182, align 8
  %op1589 = sub i64 %v1588, 24
  store i64 %op1589, ptr %slot192, align 8
  %v1590 = load i64, ptr %slot182, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  %rgep1592 = getelementptr i8, ptr %p1591, i64 -24
  %ld1593 = load i64, ptr %rgep1592, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1593, ptr %slot193, align 8
  %v1594 = load i64, ptr %slot193, align 8
  %cmp1595 = icmp ne i64 %v1594, 0
  %cv1596 = zext i1 %cmp1595 to i32
  store i32 %cv1596, ptr %slot194, align 8
  %v1597 = load i32, ptr %slot194, align 8
  %cv1598 = zext i32 %v1597 to i64
  %cond1599 = icmp ne i64 %cv1598, 0
  br i1 %cond1599, label %bb_rcgdec232, label %bb_rcgslow232
bb_rcgslow232:
  %v1600 = load i64, ptr %slot181, align 8
  %v1601 = load i64, ptr %slot164, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1600, i64 %v1601) nomerge, !dbg !124
  br label %bb_rcgdone232
bb_rcgdec232:
  %v1602 = load i64, ptr %slot190, align 8
  %v1603 = load i64, ptr %slot182, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %rgep1605 = getelementptr i8, ptr %p1604, i64 -32
  store i64 %v1602, ptr %rgep1605, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear232
bb_rcgclear232:
  %v1606 = load i64, ptr %slot164, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  store i64 0, ptr %p1607, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone232
bb_rcgdone232:
  br label %bb_rcslotdone201
bb_rcslotdone201:
  %v1608 = load i64, ptr %slot8, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  %ld1610 = load i32, ptr %p1609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1610, ptr %slot195, align 8
  %v1611 = load i32, ptr %slot195, align 8
  %cv1612 = zext i32 %v1611 to i64
  %cond1613 = icmp ne i64 %cv1612, 0
  br i1 %cond1613, label %bb_rcslotdrop238, label %bb_rcslotdone238
bb_rcslotdrop238:
  %v1614 = load i64, ptr %slot8, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i32 0, ptr %p1615, align 4, !alias.scope !3, !noalias !4
  %v1616 = load i64, ptr %slot27, align 8
  store i64 %v1616, ptr %slot196, align 8
  %v1617 = load i64, ptr %slot9, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %ld1619 = load i32, ptr %p1618, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1619, ptr %slot197, align 8
  %v1620 = load i32, ptr %slot197, align 8
  %op1621 = and i32 %v1620, 28
  store i32 %op1621, ptr %slot198, align 8
  %v1622 = load i32, ptr %slot198, align 8
  %cv1623 = zext i32 %v1622 to i64
  %cond1624 = icmp ne i64 %cv1623, 0
  br i1 %cond1624, label %bb_rcslotrole238, label %bb_rcslotowner238
bb_rcslotrole238:
  %v1625 = load i64, ptr %slot41, align 8
  store i64 %v1625, ptr %slot199, align 8
  %v1626 = load i64, ptr %slot196, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i64, ptr %p1627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1628, ptr %slot200, align 8
  %v1629 = load i64, ptr %slot200, align 8
  %cmp1630 = icmp ne i64 %v1629, 0
  %cv1631 = zext i1 %cmp1630 to i32
  store i32 %cv1631, ptr %slot201, align 8
  %v1632 = load i32, ptr %slot201, align 8
  %cv1633 = zext i32 %v1632 to i64
  %cond1634 = icmp ne i64 %cv1633, 0
  br i1 %cond1634, label %bb_rcgnn254, label %bb_rcgdone254
bb_rcgnn254:
  %v1635 = load i64, ptr %slot200, align 8
  %op1636 = sub i64 %v1635, 16
  store i64 %op1636, ptr %slot202, align 8
  %v1637 = load i64, ptr %slot200, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  %rgep1639 = getelementptr i8, ptr %p1638, i64 -16
  %ld1640 = load i64, ptr %rgep1639, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1640, ptr %slot203, align 8
  %v1641 = load i64, ptr %slot203, align 8
  %op1642 = and i64 %v1641, 4611686018427387906
  store i64 %op1642, ptr %slot204, align 8
  %v1643 = load i64, ptr %slot204, align 8
  %cmp1644 = icmp ne i64 %v1643, 0
  %cv1645 = zext i1 %cmp1644 to i32
  store i32 %cv1645, ptr %slot205, align 8
  %v1646 = load i32, ptr %slot205, align 8
  %cv1647 = zext i32 %v1646 to i64
  %cond1648 = icmp ne i64 %cv1647, 0
  br i1 %cond1648, label %bb_rcgclear254, label %bb_rcgcounted254
bb_rcgcounted254:
  %v1649 = load i64, ptr %slot200, align 8
  %op1650 = sub i64 %v1649, 24
  store i64 %op1650, ptr %slot206, align 8
  %v1651 = load i64, ptr %slot200, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  %rgep1653 = getelementptr i8, ptr %p1652, i64 -24
  %ld1654 = load i64, ptr %rgep1653, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1654, ptr %slot207, align 8
  %v1655 = load i64, ptr %slot207, align 8
  %op1656 = sub i64 %v1655, 1
  store i64 %op1656, ptr %slot208, align 8
  %v1657 = load i64, ptr %slot208, align 8
  %cmp1658 = icmp eq i64 %v1657, 0
  %cv1659 = zext i1 %cmp1658 to i32
  store i32 %cv1659, ptr %slot209, align 8
  %v1660 = load i32, ptr %slot209, align 8
  %cv1661 = zext i32 %v1660 to i64
  %cond1662 = icmp ne i64 %cv1661, 0
  br i1 %cond1662, label %bb_rcglast254, label %bb_rcgdec254
bb_rcglast254:
  %v1663 = load i64, ptr %slot200, align 8
  %op1664 = sub i64 %v1663, 32
  store i64 %op1664, ptr %slot210, align 8
  %v1665 = load i64, ptr %slot200, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  %rgep1667 = getelementptr i8, ptr %p1666, i64 -32
  %ld1668 = load i64, ptr %rgep1667, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1668, ptr %slot211, align 8
  %v1669 = load i64, ptr %slot211, align 8
  %cmp1670 = icmp ne i64 %v1669, 0
  %cv1671 = zext i1 %cmp1670 to i32
  store i32 %cv1671, ptr %slot212, align 8
  %v1672 = load i32, ptr %slot212, align 8
  %cv1673 = zext i32 %v1672 to i64
  %cond1674 = icmp ne i64 %cv1673, 0
  br i1 %cond1674, label %bb_rcgdec254, label %bb_rcgslow254
bb_rcgslow254:
  %v1675 = load i64, ptr %slot199, align 8
  %v1676 = load i64, ptr %slot196, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1675, i64 %v1676) nomerge, !dbg !124
  br label %bb_rcgdone254
bb_rcgdec254:
  %v1677 = load i64, ptr %slot208, align 8
  %v1678 = load i64, ptr %slot200, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  %rgep1680 = getelementptr i8, ptr %p1679, i64 -24
  store i64 %v1677, ptr %rgep1680, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear254
bb_rcgclear254:
  %v1681 = load i64, ptr %slot196, align 8
  %p1682 = inttoptr i64 %v1681 to ptr
  store i64 0, ptr %p1682, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone254
bb_rcgdone254:
  br label %bb_rcslotdone238
bb_rcslotowner238:
  %v1683 = load i64, ptr %slot41, align 8
  store i64 %v1683, ptr %slot213, align 8
  %v1684 = load i64, ptr %slot196, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  %ld1686 = load i64, ptr %p1685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1686, ptr %slot214, align 8
  %v1687 = load i64, ptr %slot214, align 8
  %cmp1688 = icmp ne i64 %v1687, 0
  %cv1689 = zext i1 %cmp1688 to i32
  store i32 %cv1689, ptr %slot215, align 8
  %v1690 = load i32, ptr %slot215, align 8
  %cv1691 = zext i32 %v1690 to i64
  %cond1692 = icmp ne i64 %cv1691, 0
  br i1 %cond1692, label %bb_rcgnn269, label %bb_rcgdone269
bb_rcgnn269:
  %v1693 = load i64, ptr %slot214, align 8
  %op1694 = sub i64 %v1693, 16
  store i64 %op1694, ptr %slot216, align 8
  %v1695 = load i64, ptr %slot214, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  %rgep1697 = getelementptr i8, ptr %p1696, i64 -16
  %ld1698 = load i64, ptr %rgep1697, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1698, ptr %slot217, align 8
  %v1699 = load i64, ptr %slot217, align 8
  %op1700 = and i64 %v1699, 4611686018427387906
  store i64 %op1700, ptr %slot218, align 8
  %v1701 = load i64, ptr %slot218, align 8
  %cmp1702 = icmp ne i64 %v1701, 0
  %cv1703 = zext i1 %cmp1702 to i32
  store i32 %cv1703, ptr %slot219, align 8
  %v1704 = load i32, ptr %slot219, align 8
  %cv1705 = zext i32 %v1704 to i64
  %cond1706 = icmp ne i64 %cv1705, 0
  br i1 %cond1706, label %bb_rcgclear269, label %bb_rcgcounted269
bb_rcgcounted269:
  %v1707 = load i64, ptr %slot214, align 8
  %op1708 = sub i64 %v1707, 32
  store i64 %op1708, ptr %slot220, align 8
  %v1709 = load i64, ptr %slot214, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %rgep1711 = getelementptr i8, ptr %p1710, i64 -32
  %ld1712 = load i64, ptr %rgep1711, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1712, ptr %slot221, align 8
  %v1713 = load i64, ptr %slot221, align 8
  %op1714 = sub i64 %v1713, 1
  store i64 %op1714, ptr %slot222, align 8
  %v1715 = load i64, ptr %slot222, align 8
  %cmp1716 = icmp eq i64 %v1715, 0
  %cv1717 = zext i1 %cmp1716 to i32
  store i32 %cv1717, ptr %slot223, align 8
  %v1718 = load i32, ptr %slot223, align 8
  %cv1719 = zext i32 %v1718 to i64
  %cond1720 = icmp ne i64 %cv1719, 0
  br i1 %cond1720, label %bb_rcglast269, label %bb_rcgdec269
bb_rcglast269:
  %v1721 = load i64, ptr %slot214, align 8
  %op1722 = sub i64 %v1721, 24
  store i64 %op1722, ptr %slot224, align 8
  %v1723 = load i64, ptr %slot214, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  %rgep1725 = getelementptr i8, ptr %p1724, i64 -24
  %ld1726 = load i64, ptr %rgep1725, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1726, ptr %slot225, align 8
  %v1727 = load i64, ptr %slot225, align 8
  %cmp1728 = icmp ne i64 %v1727, 0
  %cv1729 = zext i1 %cmp1728 to i32
  store i32 %cv1729, ptr %slot226, align 8
  %v1730 = load i32, ptr %slot226, align 8
  %cv1731 = zext i32 %v1730 to i64
  %cond1732 = icmp ne i64 %cv1731, 0
  br i1 %cond1732, label %bb_rcgdec269, label %bb_rcgslow269
bb_rcgslow269:
  %v1733 = load i64, ptr %slot213, align 8
  %v1734 = load i64, ptr %slot196, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1733, i64 %v1734) nomerge, !dbg !124
  br label %bb_rcgdone269
bb_rcgdec269:
  %v1735 = load i64, ptr %slot222, align 8
  %v1736 = load i64, ptr %slot214, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %rgep1738 = getelementptr i8, ptr %p1737, i64 -32
  store i64 %v1735, ptr %rgep1738, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear269
bb_rcgclear269:
  %v1739 = load i64, ptr %slot196, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i64 0, ptr %p1740, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone269
bb_rcgdone269:
  br label %bb_rcslotdone238
bb_rcslotdone238:
  %v1741 = load i64, ptr %slot6, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  %ld1743 = load i32, ptr %p1742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1743, ptr %slot227, align 8
  %v1744 = load i32, ptr %slot227, align 8
  %cv1745 = zext i32 %v1744 to i64
  %cond1746 = icmp ne i64 %cv1745, 0
  br i1 %cond1746, label %bb_rcslotdrop275, label %bb_rcslotdone275
bb_rcslotdrop275:
  %v1747 = load i64, ptr %slot6, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i32 0, ptr %p1748, align 4, !alias.scope !3, !noalias !4
  %v1749 = load i64, ptr %slot26, align 8
  store i64 %v1749, ptr %slot228, align 8
  %v1750 = load i64, ptr %slot7, align 8
  %p1751 = inttoptr i64 %v1750 to ptr
  %ld1752 = load i32, ptr %p1751, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1752, ptr %slot229, align 8
  %v1753 = load i32, ptr %slot229, align 8
  %op1754 = and i32 %v1753, 28
  store i32 %op1754, ptr %slot230, align 8
  %v1755 = load i32, ptr %slot230, align 8
  %cv1756 = zext i32 %v1755 to i64
  %cond1757 = icmp ne i64 %cv1756, 0
  br i1 %cond1757, label %bb_rcslotrole275, label %bb_rcslotowner275
bb_rcslotrole275:
  %v1758 = load i64, ptr %slot41, align 8
  store i64 %v1758, ptr %slot231, align 8
  %v1759 = load i64, ptr %slot231, align 8
  %v1760 = load i64, ptr %slot228, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1759, i64 %v1760) nomerge, !dbg !124
  br label %bb_rcslotdone275
bb_rcslotowner275:
  %v1761 = load i64, ptr %slot41, align 8
  store i64 %v1761, ptr %slot232, align 8
  %v1762 = load i64, ptr %slot232, align 8
  %v1763 = load i64, ptr %slot228, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1762, i64 %v1763) nomerge, !dbg !124
  br label %bb_rcslotdone275
bb_rcslotdone275:
  %v1764 = load i64, ptr %slot156, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1765, i64 24, i1 false)
  ret void
bb_i11:
  %v1766 = load i64, ptr %slot26, align 8
  %v1767 = load i64, ptr %slot32, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  store i64 %v1766, ptr %p1768, align 8, !alias.scope !3, !noalias !4
  %v1769 = load i64, ptr %slot32, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  %ld1771 = load i64, ptr %p1770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1771, ptr %slot233, align 8
  %v1772 = load i64, ptr %slot233, align 8
  %op1773 = add i64 %v1772, 48
  store i64 %op1773, ptr %slot234, align 8
  %v1774 = load i64, ptr %slot234, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  %ld1776 = load i64, ptr %p1775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1776, ptr %slot235, align 8
  %v1777 = load i64, ptr %slot235, align 8
  %v1778 = load i64, ptr %slot32, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i64 %v1777, ptr %p1779, align 8, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot32, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i64, ptr %p1781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1782, ptr %slot236, align 8
  %v1783 = load i64, ptr %slot236, align 8
  %v1784 = load i64, ptr %slot21, align 8
  %p1785 = inttoptr i64 %v1784 to ptr
  store i64 %v1783, ptr %p1785, align 8, !alias.scope !3, !noalias !4
  %v1786 = load i64, ptr %slot21, align 8
  store i64 %v1786, ptr %slot237, align 8
  %v1787 = load i64, ptr %slot23, align 8
  store i64 %v1787, ptr %slot238, align 8
  %v1788 = load i64, ptr %slot237, align 8
  %p1789 = inttoptr i64 %v1788 to ptr
  %ld1790 = load i64, ptr %p1789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1790, ptr %slot239, align 8
  %v1791 = load i64, ptr %slot239, align 8
  %cmp1792 = icmp ne i64 %v1791, 0
  %cv1793 = zext i1 %cmp1792 to i32
  store i32 %cv1793, ptr %slot240, align 8
  %v1794 = load i32, ptr %slot240, align 8
  %cv1795 = zext i32 %v1794 to i64
  %cond1796 = icmp ne i64 %cv1795, 0
  br i1 %cond1796, label %bb_rcgnn298, label %bb_rcgstore298
bb_rcgnn298:
  %v1797 = load i64, ptr %slot239, align 8
  %op1798 = sub i64 %v1797, 16
  store i64 %op1798, ptr %slot241, align 8
  %v1799 = load i64, ptr %slot239, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  %rgep1801 = getelementptr i8, ptr %p1800, i64 -16
  %ld1802 = load i64, ptr %rgep1801, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1802, ptr %slot242, align 8
  %v1803 = load i64, ptr %slot242, align 8
  %op1804 = and i64 %v1803, 4611686018427387906
  store i64 %op1804, ptr %slot243, align 8
  %v1805 = load i64, ptr %slot243, align 8
  %cmp1806 = icmp ne i64 %v1805, 0
  %cv1807 = zext i1 %cmp1806 to i32
  store i32 %cv1807, ptr %slot244, align 8
  %v1808 = load i32, ptr %slot244, align 8
  %cv1809 = zext i32 %v1808 to i64
  %cond1810 = icmp ne i64 %cv1809, 0
  br i1 %cond1810, label %bb_rcgstore298, label %bb_rcginc298
bb_rcginc298:
  %v1811 = load i64, ptr %slot239, align 8
  %op1812 = sub i64 %v1811, 24
  store i64 %op1812, ptr %slot245, align 8
  %v1813 = load i64, ptr %slot239, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  %rgep1815 = getelementptr i8, ptr %p1814, i64 -24
  %ld1816 = load i64, ptr %rgep1815, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1816, ptr %slot246, align 8
  %v1817 = load i64, ptr %slot246, align 8
  %op1818 = add i64 %v1817, 1
  store i64 %op1818, ptr %slot247, align 8
  %v1819 = load i64, ptr %slot247, align 8
  %cmp1820 = icmp eq i64 %v1819, 0
  %cv1821 = zext i1 %cmp1820 to i32
  store i32 %cv1821, ptr %slot248, align 8
  %v1822 = load i32, ptr %slot248, align 8
  %cv1823 = zext i32 %v1822 to i64
  %cond1824 = icmp ne i64 %cv1823, 0
  br i1 %cond1824, label %bb_rcglimit298, label %bb_rcgcapacity298
bb_rcglimit298:
  %v1825 = load i64, ptr %slot1, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %call1827 = call i32 @myl_qbe_rc_status(ptr %p1826, i32 2) nomerge, !dbg !126
  store i32 %call1827, ptr %slot249, align 8
  br label %bb_failure
bb_rcgcapacity298:
  %v1828 = load i64, ptr %slot247, align 8
  %v1829 = load i64, ptr %slot239, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  %rgep1831 = getelementptr i8, ptr %p1830, i64 -24
  store i64 %v1828, ptr %rgep1831, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore298
bb_rcgstore298:
  %v1832 = load i64, ptr %slot239, align 8
  %v1833 = load i64, ptr %slot238, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  store i64 %v1832, ptr %p1834, align 8, !alias.scope !3, !noalias !4
  %v1835 = load i64, ptr %slot17, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  store i32 2, ptr %p1836, align 4, !alias.scope !3, !noalias !4
  %v1837 = load i64, ptr %slot17, align 8
  %p1838 = inttoptr i64 %v1837 to ptr
  store i32 16, ptr %p1838, align 4, !alias.scope !3, !noalias !4
  %v1839 = load i64, ptr %slot16, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  store i32 1, ptr %p1840, align 4, !alias.scope !3, !noalias !4
  %v1841 = load i64, ptr %slot12, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %ld1843 = load i32, ptr %p1842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1843, ptr %slot250, align 8
  %v1844 = load i32, ptr %slot250, align 8
  %cv1845 = zext i32 %v1844 to i64
  %cond1846 = icmp ne i64 %cv1845, 0
  br i1 %cond1846, label %bb_rcslotdrop314, label %bb_rcslotdone314
bb_rcslotdrop314:
  %v1847 = load i64, ptr %slot12, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  store i32 0, ptr %p1848, align 4, !alias.scope !3, !noalias !4
  %v1849 = load i64, ptr %slot19, align 8
  store i64 %v1849, ptr %slot251, align 8
  %v1850 = load i64, ptr %slot13, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  %ld1852 = load i32, ptr %p1851, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1852, ptr %slot252, align 8
  %v1853 = load i32, ptr %slot252, align 8
  %op1854 = and i32 %v1853, 28
  store i32 %op1854, ptr %slot253, align 8
  %v1855 = load i32, ptr %slot253, align 8
  %cv1856 = zext i32 %v1855 to i64
  %cond1857 = icmp ne i64 %cv1856, 0
  br i1 %cond1857, label %bb_rcslotrole314, label %bb_rcslotowner314
bb_rcslotrole314:
  %v1858 = load i64, ptr %slot41, align 8
  store i64 %v1858, ptr %slot254, align 8
  %v1859 = load i64, ptr %slot254, align 8
  %v1860 = load i64, ptr %slot251, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1859, i64 %v1860) nomerge, !dbg !126
  br label %bb_rcslotdone314
bb_rcslotowner314:
  %v1861 = load i64, ptr %slot41, align 8
  store i64 %v1861, ptr %slot255, align 8
  %v1862 = load i64, ptr %slot255, align 8
  %v1863 = load i64, ptr %slot251, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1862, i64 %v1863) nomerge, !dbg !126
  br label %bb_rcslotdone314
bb_rcslotdone314:
  %v1864 = load i64, ptr %slot19, align 8
  store i64 %v1864, ptr %slot256, align 8
  %v1865 = load i64, ptr %slot23, align 8
  store i64 %v1865, ptr %slot257, align 8
  %v1866 = load i64, ptr %slot257, align 8
  %v1867 = load i64, ptr %slot256, align 8
  %p1868 = inttoptr i64 %v1866 to ptr
  %p1869 = inttoptr i64 %v1867 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1869, ptr %p1868, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1870 = load i64, ptr %slot13, align 8
  %p1871 = inttoptr i64 %v1870 to ptr
  store i32 2, ptr %p1871, align 4, !alias.scope !3, !noalias !4
  %v1872 = load i64, ptr %slot17, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  %ld1874 = load i32, ptr %p1873, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1874, ptr %slot258, align 8
  %v1875 = load i32, ptr %slot258, align 8
  %v1876 = load i64, ptr %slot13, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i32 %v1875, ptr %p1877, align 4, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot16, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  store i32 0, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  %v1880 = load i64, ptr %slot12, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  store i32 1, ptr %p1881, align 4, !alias.scope !3, !noalias !4
  %v1882 = load i64, ptr %slot256, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  %ld1884 = load i64, ptr %p1883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1884, ptr %slot259, align 8
  %v1885 = load i64, ptr %slot259, align 8
  %v1886 = load i64, ptr %slot32, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i64 %v1885, ptr %p1887, align 8, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot32, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  %ld1890 = load i64, ptr %p1889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1890, ptr %slot260, align 8
  %v1891 = load i64, ptr %slot23, align 8
  store i64 %v1891, ptr %slot261, align 8
  %v1892 = load i64, ptr %slot260, align 8
  %cmp1893 = icmp ne i64 %v1892, 0
  %cv1894 = zext i1 %cmp1893 to i32
  store i32 %cv1894, ptr %slot262, align 8
  %v1895 = load i32, ptr %slot262, align 8
  %cv1896 = zext i32 %v1895 to i64
  %cond1897 = icmp ne i64 %cv1896, 0
  br i1 %cond1897, label %bb_rcgnn334, label %bb_rcgstore334
bb_rcgnn334:
  %v1898 = load i64, ptr %slot260, align 8
  %op1899 = sub i64 %v1898, 16
  store i64 %op1899, ptr %slot263, align 8
  %v1900 = load i64, ptr %slot260, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  %rgep1902 = getelementptr i8, ptr %p1901, i64 -16
  %ld1903 = load i64, ptr %rgep1902, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1903, ptr %slot264, align 8
  %v1904 = load i64, ptr %slot264, align 8
  %op1905 = and i64 %v1904, 4611686018427387906
  store i64 %op1905, ptr %slot265, align 8
  %v1906 = load i64, ptr %slot265, align 8
  %cmp1907 = icmp ne i64 %v1906, 0
  %cv1908 = zext i1 %cmp1907 to i32
  store i32 %cv1908, ptr %slot266, align 8
  %v1909 = load i32, ptr %slot266, align 8
  %cv1910 = zext i32 %v1909 to i64
  %cond1911 = icmp ne i64 %cv1910, 0
  br i1 %cond1911, label %bb_rcgstore334, label %bb_rcginc334
bb_rcginc334:
  %v1912 = load i64, ptr %slot260, align 8
  %op1913 = sub i64 %v1912, 24
  store i64 %op1913, ptr %slot267, align 8
  %v1914 = load i64, ptr %slot260, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  %rgep1916 = getelementptr i8, ptr %p1915, i64 -24
  %ld1917 = load i64, ptr %rgep1916, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1917, ptr %slot268, align 8
  %v1918 = load i64, ptr %slot268, align 8
  %op1919 = add i64 %v1918, 1
  store i64 %op1919, ptr %slot269, align 8
  %v1920 = load i64, ptr %slot269, align 8
  %cmp1921 = icmp eq i64 %v1920, 0
  %cv1922 = zext i1 %cmp1921 to i32
  store i32 %cv1922, ptr %slot270, align 8
  %v1923 = load i32, ptr %slot270, align 8
  %cv1924 = zext i32 %v1923 to i64
  %cond1925 = icmp ne i64 %cv1924, 0
  br i1 %cond1925, label %bb_rcglimit334, label %bb_rcgcapacity334
bb_rcglimit334:
  %v1926 = load i64, ptr %slot1, align 8
  %p1927 = inttoptr i64 %v1926 to ptr
  %call1928 = call i32 @myl_qbe_rc_status(ptr %p1927, i32 2) nomerge, !dbg !128
  store i32 %call1928, ptr %slot271, align 8
  br label %bb_failure
bb_rcgcapacity334:
  %v1929 = load i64, ptr %slot269, align 8
  %v1930 = load i64, ptr %slot260, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  %rgep1932 = getelementptr i8, ptr %p1931, i64 -24
  store i64 %v1929, ptr %rgep1932, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore334
bb_rcgstore334:
  %v1933 = load i64, ptr %slot260, align 8
  %v1934 = load i64, ptr %slot261, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  store i64 %v1933, ptr %p1935, align 8, !alias.scope !3, !noalias !4
  %v1936 = load i64, ptr %slot17, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  store i32 2, ptr %p1937, align 4, !alias.scope !3, !noalias !4
  %v1938 = load i64, ptr %slot17, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  store i32 8, ptr %p1939, align 4, !alias.scope !3, !noalias !4
  %v1940 = load i64, ptr %slot16, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  store i32 1, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  %v1942 = load i64, ptr %slot12, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %ld1944 = load i32, ptr %p1943, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1944, ptr %slot272, align 8
  %v1945 = load i32, ptr %slot272, align 8
  %cv1946 = zext i32 %v1945 to i64
  %cond1947 = icmp ne i64 %cv1946, 0
  br i1 %cond1947, label %bb_rcslotdrop350, label %bb_rcslotdone350
bb_rcslotdrop350:
  %v1948 = load i64, ptr %slot12, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  store i32 0, ptr %p1949, align 4, !alias.scope !3, !noalias !4
  %v1950 = load i64, ptr %slot19, align 8
  store i64 %v1950, ptr %slot273, align 8
  %v1951 = load i64, ptr %slot13, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  %ld1953 = load i32, ptr %p1952, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1953, ptr %slot274, align 8
  %v1954 = load i32, ptr %slot274, align 8
  %op1955 = and i32 %v1954, 28
  store i32 %op1955, ptr %slot275, align 8
  %v1956 = load i32, ptr %slot275, align 8
  %cv1957 = zext i32 %v1956 to i64
  %cond1958 = icmp ne i64 %cv1957, 0
  br i1 %cond1958, label %bb_rcslotrole350, label %bb_rcslotowner350
bb_rcslotrole350:
  %v1959 = load i64, ptr %slot41, align 8
  store i64 %v1959, ptr %slot276, align 8
  %v1960 = load i64, ptr %slot273, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  %ld1962 = load i64, ptr %p1961, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1962, ptr %slot277, align 8
  %v1963 = load i64, ptr %slot277, align 8
  %cmp1964 = icmp ne i64 %v1963, 0
  %cv1965 = zext i1 %cmp1964 to i32
  store i32 %cv1965, ptr %slot278, align 8
  %v1966 = load i32, ptr %slot278, align 8
  %cv1967 = zext i32 %v1966 to i64
  %cond1968 = icmp ne i64 %cv1967, 0
  br i1 %cond1968, label %bb_rcgnn366, label %bb_rcgdone366
bb_rcgnn366:
  %v1969 = load i64, ptr %slot277, align 8
  %op1970 = sub i64 %v1969, 16
  store i64 %op1970, ptr %slot279, align 8
  %v1971 = load i64, ptr %slot277, align 8
  %p1972 = inttoptr i64 %v1971 to ptr
  %rgep1973 = getelementptr i8, ptr %p1972, i64 -16
  %ld1974 = load i64, ptr %rgep1973, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1974, ptr %slot280, align 8
  %v1975 = load i64, ptr %slot280, align 8
  %op1976 = and i64 %v1975, 4611686018427387906
  store i64 %op1976, ptr %slot281, align 8
  %v1977 = load i64, ptr %slot281, align 8
  %cmp1978 = icmp ne i64 %v1977, 0
  %cv1979 = zext i1 %cmp1978 to i32
  store i32 %cv1979, ptr %slot282, align 8
  %v1980 = load i32, ptr %slot282, align 8
  %cv1981 = zext i32 %v1980 to i64
  %cond1982 = icmp ne i64 %cv1981, 0
  br i1 %cond1982, label %bb_rcgclear366, label %bb_rcgcounted366
bb_rcgcounted366:
  %v1983 = load i64, ptr %slot277, align 8
  %op1984 = sub i64 %v1983, 24
  store i64 %op1984, ptr %slot283, align 8
  %v1985 = load i64, ptr %slot277, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  %rgep1987 = getelementptr i8, ptr %p1986, i64 -24
  %ld1988 = load i64, ptr %rgep1987, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1988, ptr %slot284, align 8
  %v1989 = load i64, ptr %slot284, align 8
  %op1990 = sub i64 %v1989, 1
  store i64 %op1990, ptr %slot285, align 8
  %v1991 = load i64, ptr %slot285, align 8
  %cmp1992 = icmp eq i64 %v1991, 0
  %cv1993 = zext i1 %cmp1992 to i32
  store i32 %cv1993, ptr %slot286, align 8
  %v1994 = load i32, ptr %slot286, align 8
  %cv1995 = zext i32 %v1994 to i64
  %cond1996 = icmp ne i64 %cv1995, 0
  br i1 %cond1996, label %bb_rcglast366, label %bb_rcgdec366
bb_rcglast366:
  %v1997 = load i64, ptr %slot277, align 8
  %op1998 = sub i64 %v1997, 32
  store i64 %op1998, ptr %slot287, align 8
  %v1999 = load i64, ptr %slot277, align 8
  %p2000 = inttoptr i64 %v1999 to ptr
  %rgep2001 = getelementptr i8, ptr %p2000, i64 -32
  %ld2002 = load i64, ptr %rgep2001, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2002, ptr %slot288, align 8
  %v2003 = load i64, ptr %slot288, align 8
  %cmp2004 = icmp ne i64 %v2003, 0
  %cv2005 = zext i1 %cmp2004 to i32
  store i32 %cv2005, ptr %slot289, align 8
  %v2006 = load i32, ptr %slot289, align 8
  %cv2007 = zext i32 %v2006 to i64
  %cond2008 = icmp ne i64 %cv2007, 0
  br i1 %cond2008, label %bb_rcgdec366, label %bb_rcgslow366
bb_rcgslow366:
  %v2009 = load i64, ptr %slot276, align 8
  %v2010 = load i64, ptr %slot273, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2009, i64 %v2010) nomerge, !dbg !128
  br label %bb_rcgdone366
bb_rcgdec366:
  %v2011 = load i64, ptr %slot285, align 8
  %v2012 = load i64, ptr %slot277, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  %rgep2014 = getelementptr i8, ptr %p2013, i64 -24
  store i64 %v2011, ptr %rgep2014, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear366
bb_rcgclear366:
  %v2015 = load i64, ptr %slot273, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  store i64 0, ptr %p2016, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone366
bb_rcgdone366:
  br label %bb_rcslotdone350
bb_rcslotowner350:
  %v2017 = load i64, ptr %slot41, align 8
  store i64 %v2017, ptr %slot290, align 8
  %v2018 = load i64, ptr %slot273, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  %ld2020 = load i64, ptr %p2019, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2020, ptr %slot291, align 8
  %v2021 = load i64, ptr %slot291, align 8
  %cmp2022 = icmp ne i64 %v2021, 0
  %cv2023 = zext i1 %cmp2022 to i32
  store i32 %cv2023, ptr %slot292, align 8
  %v2024 = load i32, ptr %slot292, align 8
  %cv2025 = zext i32 %v2024 to i64
  %cond2026 = icmp ne i64 %cv2025, 0
  br i1 %cond2026, label %bb_rcgnn381, label %bb_rcgdone381
bb_rcgnn381:
  %v2027 = load i64, ptr %slot291, align 8
  %op2028 = sub i64 %v2027, 16
  store i64 %op2028, ptr %slot293, align 8
  %v2029 = load i64, ptr %slot291, align 8
  %p2030 = inttoptr i64 %v2029 to ptr
  %rgep2031 = getelementptr i8, ptr %p2030, i64 -16
  %ld2032 = load i64, ptr %rgep2031, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2032, ptr %slot294, align 8
  %v2033 = load i64, ptr %slot294, align 8
  %op2034 = and i64 %v2033, 4611686018427387906
  store i64 %op2034, ptr %slot295, align 8
  %v2035 = load i64, ptr %slot295, align 8
  %cmp2036 = icmp ne i64 %v2035, 0
  %cv2037 = zext i1 %cmp2036 to i32
  store i32 %cv2037, ptr %slot296, align 8
  %v2038 = load i32, ptr %slot296, align 8
  %cv2039 = zext i32 %v2038 to i64
  %cond2040 = icmp ne i64 %cv2039, 0
  br i1 %cond2040, label %bb_rcgclear381, label %bb_rcgcounted381
bb_rcgcounted381:
  %v2041 = load i64, ptr %slot291, align 8
  %op2042 = sub i64 %v2041, 32
  store i64 %op2042, ptr %slot297, align 8
  %v2043 = load i64, ptr %slot291, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %rgep2045 = getelementptr i8, ptr %p2044, i64 -32
  %ld2046 = load i64, ptr %rgep2045, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2046, ptr %slot298, align 8
  %v2047 = load i64, ptr %slot298, align 8
  %op2048 = sub i64 %v2047, 1
  store i64 %op2048, ptr %slot299, align 8
  %v2049 = load i64, ptr %slot299, align 8
  %cmp2050 = icmp eq i64 %v2049, 0
  %cv2051 = zext i1 %cmp2050 to i32
  store i32 %cv2051, ptr %slot300, align 8
  %v2052 = load i32, ptr %slot300, align 8
  %cv2053 = zext i32 %v2052 to i64
  %cond2054 = icmp ne i64 %cv2053, 0
  br i1 %cond2054, label %bb_rcglast381, label %bb_rcgdec381
bb_rcglast381:
  %v2055 = load i64, ptr %slot291, align 8
  %op2056 = sub i64 %v2055, 24
  store i64 %op2056, ptr %slot301, align 8
  %v2057 = load i64, ptr %slot291, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %rgep2059 = getelementptr i8, ptr %p2058, i64 -24
  %ld2060 = load i64, ptr %rgep2059, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2060, ptr %slot302, align 8
  %v2061 = load i64, ptr %slot302, align 8
  %cmp2062 = icmp ne i64 %v2061, 0
  %cv2063 = zext i1 %cmp2062 to i32
  store i32 %cv2063, ptr %slot303, align 8
  %v2064 = load i32, ptr %slot303, align 8
  %cv2065 = zext i32 %v2064 to i64
  %cond2066 = icmp ne i64 %cv2065, 0
  br i1 %cond2066, label %bb_rcgdec381, label %bb_rcgslow381
bb_rcgslow381:
  %v2067 = load i64, ptr %slot290, align 8
  %v2068 = load i64, ptr %slot273, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2067, i64 %v2068) nomerge, !dbg !128
  br label %bb_rcgdone381
bb_rcgdec381:
  %v2069 = load i64, ptr %slot299, align 8
  %v2070 = load i64, ptr %slot291, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  %rgep2072 = getelementptr i8, ptr %p2071, i64 -32
  store i64 %v2069, ptr %rgep2072, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear381
bb_rcgclear381:
  %v2073 = load i64, ptr %slot273, align 8
  %p2074 = inttoptr i64 %v2073 to ptr
  store i64 0, ptr %p2074, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone381
bb_rcgdone381:
  br label %bb_rcslotdone350
bb_rcslotdone350:
  %v2075 = load i64, ptr %slot19, align 8
  store i64 %v2075, ptr %slot304, align 8
  %v2076 = load i64, ptr %slot23, align 8
  store i64 %v2076, ptr %slot305, align 8
  %v2077 = load i64, ptr %slot305, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  %ld2079 = load i64, ptr %p2078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2079, ptr %slot306, align 8
  %v2080 = load i64, ptr %slot306, align 8
  %v2081 = load i64, ptr %slot304, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i64 %v2080, ptr %p2082, align 8, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot13, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  store i32 2, ptr %p2084, align 4, !alias.scope !3, !noalias !4
  %v2085 = load i64, ptr %slot13, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  store i32 8, ptr %p2086, align 4, !alias.scope !3, !noalias !4
  %v2087 = load i64, ptr %slot12, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  store i32 1, ptr %p2088, align 4, !alias.scope !3, !noalias !4
  %v2089 = load i64, ptr %slot16, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  store i32 0, ptr %p2090, align 4, !alias.scope !3, !noalias !4
  %v2091 = load i64, ptr %slot306, align 8
  %v2092 = load i64, ptr %slot32, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  store i64 %v2091, ptr %p2093, align 8, !alias.scope !3, !noalias !4
  %v2094 = load i64, ptr %slot23, align 8
  store i64 %v2094, ptr %slot307, align 8
  %v2095 = load i64, ptr %slot32, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  %ld2097 = load i64, ptr %p2096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2097, ptr %slot308, align 8
  %v2098 = load i64, ptr %slot308, align 8
  %v2099 = load i64, ptr %slot307, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  store i64 %v2098, ptr %p2100, align 8, !alias.scope !3, !noalias !4
  %v2101 = load i64, ptr %slot17, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  store i32 2, ptr %p2102, align 4, !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot17, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  store i32 8, ptr %p2104, align 4, !alias.scope !3, !noalias !4
  %v2105 = load i64, ptr %slot16, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  store i32 1, ptr %p2106, align 4, !alias.scope !3, !noalias !4
  %v2107 = load i64, ptr %slot12, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  store i32 0, ptr %p2108, align 4, !alias.scope !3, !noalias !4
  %v2109 = load i64, ptr %slot8, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  %ld2111 = load i32, ptr %p2110, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2111, ptr %slot309, align 8
  %v2112 = load i32, ptr %slot309, align 8
  %cv2113 = zext i32 %v2112 to i64
  %cond2114 = icmp ne i64 %cv2113, 0
  br i1 %cond2114, label %bb_rcslotdrop400, label %bb_rcslotdone400
bb_rcslotdrop400:
  %v2115 = load i64, ptr %slot8, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i32 0, ptr %p2116, align 4, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot27, align 8
  store i64 %v2117, ptr %slot310, align 8
  %v2118 = load i64, ptr %slot9, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  %ld2120 = load i32, ptr %p2119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2120, ptr %slot311, align 8
  %v2121 = load i32, ptr %slot311, align 8
  %op2122 = and i32 %v2121, 28
  store i32 %op2122, ptr %slot312, align 8
  %v2123 = load i32, ptr %slot312, align 8
  %cv2124 = zext i32 %v2123 to i64
  %cond2125 = icmp ne i64 %cv2124, 0
  br i1 %cond2125, label %bb_rcslotrole400, label %bb_rcslotowner400
bb_rcslotrole400:
  %v2126 = load i64, ptr %slot41, align 8
  store i64 %v2126, ptr %slot313, align 8
  %v2127 = load i64, ptr %slot310, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  %ld2129 = load i64, ptr %p2128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2129, ptr %slot314, align 8
  %v2130 = load i64, ptr %slot314, align 8
  %cmp2131 = icmp ne i64 %v2130, 0
  %cv2132 = zext i1 %cmp2131 to i32
  store i32 %cv2132, ptr %slot315, align 8
  %v2133 = load i32, ptr %slot315, align 8
  %cv2134 = zext i32 %v2133 to i64
  %cond2135 = icmp ne i64 %cv2134, 0
  br i1 %cond2135, label %bb_rcgnn416, label %bb_rcgdone416
bb_rcgnn416:
  %v2136 = load i64, ptr %slot314, align 8
  %op2137 = sub i64 %v2136, 16
  store i64 %op2137, ptr %slot316, align 8
  %v2138 = load i64, ptr %slot314, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  %rgep2140 = getelementptr i8, ptr %p2139, i64 -16
  %ld2141 = load i64, ptr %rgep2140, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2141, ptr %slot317, align 8
  %v2142 = load i64, ptr %slot317, align 8
  %op2143 = and i64 %v2142, 4611686018427387906
  store i64 %op2143, ptr %slot318, align 8
  %v2144 = load i64, ptr %slot318, align 8
  %cmp2145 = icmp ne i64 %v2144, 0
  %cv2146 = zext i1 %cmp2145 to i32
  store i32 %cv2146, ptr %slot319, align 8
  %v2147 = load i32, ptr %slot319, align 8
  %cv2148 = zext i32 %v2147 to i64
  %cond2149 = icmp ne i64 %cv2148, 0
  br i1 %cond2149, label %bb_rcgclear416, label %bb_rcgcounted416
bb_rcgcounted416:
  %v2150 = load i64, ptr %slot314, align 8
  %op2151 = sub i64 %v2150, 24
  store i64 %op2151, ptr %slot320, align 8
  %v2152 = load i64, ptr %slot314, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  %rgep2154 = getelementptr i8, ptr %p2153, i64 -24
  %ld2155 = load i64, ptr %rgep2154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2155, ptr %slot321, align 8
  %v2156 = load i64, ptr %slot321, align 8
  %op2157 = sub i64 %v2156, 1
  store i64 %op2157, ptr %slot322, align 8
  %v2158 = load i64, ptr %slot322, align 8
  %cmp2159 = icmp eq i64 %v2158, 0
  %cv2160 = zext i1 %cmp2159 to i32
  store i32 %cv2160, ptr %slot323, align 8
  %v2161 = load i32, ptr %slot323, align 8
  %cv2162 = zext i32 %v2161 to i64
  %cond2163 = icmp ne i64 %cv2162, 0
  br i1 %cond2163, label %bb_rcglast416, label %bb_rcgdec416
bb_rcglast416:
  %v2164 = load i64, ptr %slot314, align 8
  %op2165 = sub i64 %v2164, 32
  store i64 %op2165, ptr %slot324, align 8
  %v2166 = load i64, ptr %slot314, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %rgep2168 = getelementptr i8, ptr %p2167, i64 -32
  %ld2169 = load i64, ptr %rgep2168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2169, ptr %slot325, align 8
  %v2170 = load i64, ptr %slot325, align 8
  %cmp2171 = icmp ne i64 %v2170, 0
  %cv2172 = zext i1 %cmp2171 to i32
  store i32 %cv2172, ptr %slot326, align 8
  %v2173 = load i32, ptr %slot326, align 8
  %cv2174 = zext i32 %v2173 to i64
  %cond2175 = icmp ne i64 %cv2174, 0
  br i1 %cond2175, label %bb_rcgdec416, label %bb_rcgslow416
bb_rcgslow416:
  %v2176 = load i64, ptr %slot313, align 8
  %v2177 = load i64, ptr %slot310, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2176, i64 %v2177) nomerge, !dbg !128
  br label %bb_rcgdone416
bb_rcgdec416:
  %v2178 = load i64, ptr %slot322, align 8
  %v2179 = load i64, ptr %slot314, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  %rgep2181 = getelementptr i8, ptr %p2180, i64 -24
  store i64 %v2178, ptr %rgep2181, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear416
bb_rcgclear416:
  %v2182 = load i64, ptr %slot310, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i64 0, ptr %p2183, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone416
bb_rcgdone416:
  br label %bb_rcslotdone400
bb_rcslotowner400:
  %v2184 = load i64, ptr %slot41, align 8
  store i64 %v2184, ptr %slot327, align 8
  %v2185 = load i64, ptr %slot310, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %ld2187 = load i64, ptr %p2186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2187, ptr %slot328, align 8
  %v2188 = load i64, ptr %slot328, align 8
  %cmp2189 = icmp ne i64 %v2188, 0
  %cv2190 = zext i1 %cmp2189 to i32
  store i32 %cv2190, ptr %slot329, align 8
  %v2191 = load i32, ptr %slot329, align 8
  %cv2192 = zext i32 %v2191 to i64
  %cond2193 = icmp ne i64 %cv2192, 0
  br i1 %cond2193, label %bb_rcgnn431, label %bb_rcgdone431
bb_rcgnn431:
  %v2194 = load i64, ptr %slot328, align 8
  %op2195 = sub i64 %v2194, 16
  store i64 %op2195, ptr %slot330, align 8
  %v2196 = load i64, ptr %slot328, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %rgep2198 = getelementptr i8, ptr %p2197, i64 -16
  %ld2199 = load i64, ptr %rgep2198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2199, ptr %slot331, align 8
  %v2200 = load i64, ptr %slot331, align 8
  %op2201 = and i64 %v2200, 4611686018427387906
  store i64 %op2201, ptr %slot332, align 8
  %v2202 = load i64, ptr %slot332, align 8
  %cmp2203 = icmp ne i64 %v2202, 0
  %cv2204 = zext i1 %cmp2203 to i32
  store i32 %cv2204, ptr %slot333, align 8
  %v2205 = load i32, ptr %slot333, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcgclear431, label %bb_rcgcounted431
bb_rcgcounted431:
  %v2208 = load i64, ptr %slot328, align 8
  %op2209 = sub i64 %v2208, 32
  store i64 %op2209, ptr %slot334, align 8
  %v2210 = load i64, ptr %slot328, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  %rgep2212 = getelementptr i8, ptr %p2211, i64 -32
  %ld2213 = load i64, ptr %rgep2212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2213, ptr %slot335, align 8
  %v2214 = load i64, ptr %slot335, align 8
  %op2215 = sub i64 %v2214, 1
  store i64 %op2215, ptr %slot336, align 8
  %v2216 = load i64, ptr %slot336, align 8
  %cmp2217 = icmp eq i64 %v2216, 0
  %cv2218 = zext i1 %cmp2217 to i32
  store i32 %cv2218, ptr %slot337, align 8
  %v2219 = load i32, ptr %slot337, align 8
  %cv2220 = zext i32 %v2219 to i64
  %cond2221 = icmp ne i64 %cv2220, 0
  br i1 %cond2221, label %bb_rcglast431, label %bb_rcgdec431
bb_rcglast431:
  %v2222 = load i64, ptr %slot328, align 8
  %op2223 = sub i64 %v2222, 24
  store i64 %op2223, ptr %slot338, align 8
  %v2224 = load i64, ptr %slot328, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %rgep2226 = getelementptr i8, ptr %p2225, i64 -24
  %ld2227 = load i64, ptr %rgep2226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2227, ptr %slot339, align 8
  %v2228 = load i64, ptr %slot339, align 8
  %cmp2229 = icmp ne i64 %v2228, 0
  %cv2230 = zext i1 %cmp2229 to i32
  store i32 %cv2230, ptr %slot340, align 8
  %v2231 = load i32, ptr %slot340, align 8
  %cv2232 = zext i32 %v2231 to i64
  %cond2233 = icmp ne i64 %cv2232, 0
  br i1 %cond2233, label %bb_rcgdec431, label %bb_rcgslow431
bb_rcgslow431:
  %v2234 = load i64, ptr %slot327, align 8
  %v2235 = load i64, ptr %slot310, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2234, i64 %v2235) nomerge, !dbg !128
  br label %bb_rcgdone431
bb_rcgdec431:
  %v2236 = load i64, ptr %slot336, align 8
  %v2237 = load i64, ptr %slot328, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  %rgep2239 = getelementptr i8, ptr %p2238, i64 -32
  store i64 %v2236, ptr %rgep2239, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear431
bb_rcgclear431:
  %v2240 = load i64, ptr %slot310, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  store i64 0, ptr %p2241, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone431
bb_rcgdone431:
  br label %bb_rcslotdone400
bb_rcslotdone400:
  %v2242 = load i64, ptr %slot27, align 8
  store i64 %v2242, ptr %slot341, align 8
  %v2243 = load i64, ptr %slot307, align 8
  %p2244 = inttoptr i64 %v2243 to ptr
  %ld2245 = load i64, ptr %p2244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2245, ptr %slot342, align 8
  %v2246 = load i64, ptr %slot342, align 8
  %v2247 = load i64, ptr %slot341, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  store i64 %v2246, ptr %p2248, align 8, !alias.scope !3, !noalias !4
  %v2249 = load i64, ptr %slot9, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  store i32 2, ptr %p2250, align 4, !alias.scope !3, !noalias !4
  %v2251 = load i64, ptr %slot9, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i32 8, ptr %p2252, align 4, !alias.scope !3, !noalias !4
  %v2253 = load i64, ptr %slot8, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i32 1, ptr %p2254, align 4, !alias.scope !3, !noalias !4
  %v2255 = load i64, ptr %slot16, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  store i32 0, ptr %p2256, align 4, !alias.scope !3, !noalias !4
  %v2257 = load i64, ptr %slot32, align 8
  %p2258 = inttoptr i64 %v2257 to ptr
  store i64 0, ptr %p2258, align 8, !alias.scope !3, !noalias !4
  %v2259 = load i64, ptr %slot32, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  %ld2261 = load i64, ptr %p2260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2261, ptr %slot343, align 8
  %v2262 = load i64, ptr %slot343, align 8
  %v2263 = load i64, ptr %slot28, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i64 %v2262, ptr %p2264, align 8, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot27, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  %ld2267 = load i64, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2267, ptr %slot344, align 8
  %v2268 = load i64, ptr %slot344, align 8
  %op2269 = add i64 %v2268, 0
  store i64 %op2269, ptr %slot345, align 8
  %v2270 = load i64, ptr %slot345, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  %ld2272 = load i64, ptr %p2271, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2272, ptr %slot346, align 8
  %v2273 = load i64, ptr %slot346, align 8
  %v2274 = load i64, ptr %slot32, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  store i64 %v2273, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  %v2276 = load i64, ptr %slot32, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %ld2278 = load i64, ptr %p2277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2278, ptr %slot347, align 8
  %v2279 = load i64, ptr %slot347, align 8
  %cmp2280 = icmp ugt i64 %v2279, 9223372036854775807
  %cv2281 = zext i1 %cmp2280 to i64
  store i64 %cv2281, ptr %slot348, align 8
  %v2282 = load i64, ptr %slot348, align 8
  %cond2283 = icmp ne i64 %v2282, 0
  br i1 %cond2283, label %bb_cast_overflow447, label %bb_cast_ok447
bb_cast_overflow447:
  %v2284 = load i64, ptr %slot1, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  %v2286 = load i64, ptr %slot347, align 8
  call void @myl_qbe_fail_cast(ptr %p2285, i64 %v2286, i64 320) nomerge, !dbg !130
  unreachable
bb_cast_ok447:
  %v2287 = load i64, ptr %slot347, align 8
  %v2288 = load i64, ptr %slot32, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i64 %v2287, ptr %p2289, align 8, !alias.scope !3, !noalias !4
  %v2290 = load i64, ptr %slot32, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i64, ptr %p2291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2292, ptr %slot349, align 8
  %v2293 = load i64, ptr %slot349, align 8
  %v2294 = load i64, ptr %slot29, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i64 %v2293, ptr %p2295, align 8, !alias.scope !3, !noalias !4
  br label %bb_i20
bb_i20:
  %v2296 = load i64, ptr %slot28, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %ld2298 = load i64, ptr %p2297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2298, ptr %slot350, align 8
  %v2299 = load i64, ptr %slot350, align 8
  %v2300 = load i64, ptr %slot32, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  store i64 %v2299, ptr %p2301, align 8, !alias.scope !3, !noalias !4
  %v2302 = load i64, ptr %slot29, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  %ld2304 = load i64, ptr %p2303, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2304, ptr %slot351, align 8
  %v2305 = load i64, ptr %slot351, align 8
  %v2306 = load i64, ptr %slot33, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  store i64 %v2305, ptr %p2307, align 8, !alias.scope !3, !noalias !4
  %v2308 = load i64, ptr %slot33, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  %ld2310 = load i64, ptr %p2309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2310, ptr %slot352, align 8
  %v2311 = load i64, ptr %slot32, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %ld2313 = load i64, ptr %p2312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2313, ptr %slot353, align 8
  %v2314 = load i64, ptr %slot353, align 8
  %v2315 = load i64, ptr %slot352, align 8
  %cmp2316 = icmp slt i64 %v2314, %v2315
  %cv2317 = zext i1 %cmp2316 to i64
  store i64 %cv2317, ptr %slot354, align 8
  %v2318 = load i64, ptr %slot354, align 8
  %v2319 = load i64, ptr %slot32, align 8
  %p2320 = inttoptr i64 %v2319 to ptr
  store i64 %v2318, ptr %p2320, align 8, !alias.scope !3, !noalias !4
  %v2321 = load i64, ptr %slot32, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  %ld2323 = load i64, ptr %p2322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2323, ptr %slot355, align 8
  %v2324 = load i64, ptr %slot355, align 8
  %cond2325 = icmp ne i64 %v2324, 0
  br i1 %cond2325, label %bb_next455, label %bb_i45
bb_next455:
  %v2326 = load i64, ptr %slot29, align 8
  %p2327 = inttoptr i64 %v2326 to ptr
  %ld2328 = load i64, ptr %p2327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2328, ptr %slot356, align 8
  %v2329 = load i64, ptr %slot356, align 8
  %v2330 = load i64, ptr %slot32, align 8
  %p2331 = inttoptr i64 %v2330 to ptr
  store i64 %v2329, ptr %p2331, align 8, !alias.scope !3, !noalias !4
  %v2332 = load i64, ptr %slot27, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  %ld2334 = load i64, ptr %p2333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2334, ptr %slot357, align 8
  %v2335 = load i64, ptr %slot32, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  %ld2337 = load i64, ptr %p2336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2337, ptr %slot358, align 8
  %v2338 = load i64, ptr %slot357, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %ld2340 = load i64, ptr %p2339, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2340, ptr %slot359, align 8
  %v2341 = load i64, ptr %slot359, align 8
  %v2342 = load i64, ptr %slot358, align 8
  %cmp2343 = icmp eq i64 %v2341, %v2342
  %cv2344 = zext i1 %cmp2343 to i64
  store i64 %cv2344, ptr %slot360, align 8
  %v2345 = load i64, ptr %slot360, align 8
  %cond2346 = icmp ne i64 %v2345, 0
  br i1 %cond2346, label %bb_success460, label %bb_failed460
bb_failed460:
  %v2347 = load i64, ptr %slot1, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  call void @myl_qbe_fail_iteration(ptr %p2348) nomerge, !dbg !132
  unreachable
bb_success460:
  %v2349 = load i64, ptr %slot32, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 0, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot28, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %ld2353 = load i64, ptr %p2352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2353, ptr %slot361, align 8
  %v2354 = load i64, ptr %slot361, align 8
  %v2355 = load i64, ptr %slot32, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i64 %v2354, ptr %p2356, align 8, !alias.scope !3, !noalias !4
  %v2357 = load i64, ptr %slot27, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %ld2359 = load i64, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2359, ptr %slot362, align 8
  %v2360 = load i64, ptr %slot32, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  %ld2362 = load i64, ptr %p2361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2362, ptr %slot363, align 8
  %v2363 = load i64, ptr %slot362, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  %ld2365 = load i64, ptr %p2364, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2365, ptr %slot364, align 8
  %v2366 = load i64, ptr %slot363, align 8
  %v2367 = load i64, ptr %slot364, align 8
  %cmp2368 = icmp ult i64 %v2366, %v2367
  %cv2369 = zext i1 %cmp2368 to i64
  store i64 %cv2369, ptr %slot365, align 8
  %v2370 = load i64, ptr %slot365, align 8
  %cond2371 = icmp ne i64 %v2370, 0
  br i1 %cond2371, label %bb_success467, label %bb_failed467
bb_failed467:
  %v2372 = load i64, ptr %slot1, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %v2374 = load i64, ptr %slot363, align 8
  %v2375 = load i64, ptr %slot364, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2373, i64 %v2374, i64 %v2375) nomerge, !dbg !134
  unreachable
bb_success467:
  %v2376 = load i64, ptr %slot362, align 8
  %op2377 = add i64 %v2376, 32
  store i64 %op2377, ptr %slot366, align 8
  %v2378 = load i64, ptr %slot366, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  %ld2380 = load i64, ptr %p2379, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2380, ptr %slot367, align 8
  %v2381 = load i64, ptr %slot363, align 8
  %op2382 = mul i64 %v2381, 8
  store i64 %op2382, ptr %slot368, align 8
  %v2383 = load i64, ptr %slot367, align 8
  %v2384 = load i64, ptr %slot368, align 8
  %op2385 = add i64 %v2383, %v2384
  store i64 %op2385, ptr %slot369, align 8
  %v2386 = load i64, ptr %slot367, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  %v2388 = load i64, ptr %slot368, align 8
  %egep2389 = getelementptr i8, ptr %p2387, i64 %v2388
  %ld2390 = load i64, ptr %egep2389, align 8, !alias.scope !12, !noalias !13
  store i64 %ld2390, ptr %slot370, align 8
  %v2391 = load i64, ptr %slot370, align 8
  %v2392 = load i64, ptr %slot32, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  store i64 %v2391, ptr %p2393, align 8, !alias.scope !3, !noalias !4
  %v2394 = load i64, ptr %slot32, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %ld2396 = load i64, ptr %p2395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2396, ptr %slot371, align 8
  %v2397 = load i64, ptr %slot371, align 8
  %v2398 = load i64, ptr %slot30, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 %v2397, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot24, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %ld2402 = load i64, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2402, ptr %slot372, align 8
  %v2403 = load i64, ptr %slot372, align 8
  %v2404 = load i64, ptr %slot32, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  store i64 %v2403, ptr %p2405, align 8, !alias.scope !3, !noalias !4
  %v2406 = load i64, ptr %slot30, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  %ld2408 = load i64, ptr %p2407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2408, ptr %slot373, align 8
  %v2409 = load i64, ptr %slot373, align 8
  %v2410 = load i64, ptr %slot33, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  store i64 %v2409, ptr %p2411, align 8, !alias.scope !3, !noalias !4
  %v2412 = load i64, ptr %slot32, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  %ld2414 = load i64, ptr %p2413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2414, ptr %slot374, align 8
  %v2415 = load i64, ptr %slot33, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  %ld2417 = load i64, ptr %p2416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2417, ptr %slot375, align 8
  %v2418 = load i64, ptr %slot1, align 8
  %v2419 = load i64, ptr %slot374, align 8
  %v2420 = load i64, ptr %slot375, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult377, i64 %v2418, i64 %v2419, i64 %v2420) nomerge, !dbg !136
  %addr2421 = ptrtoint ptr %callresult377 to i64
  store i64 %addr2421, ptr %slot376, align 8
  %v2422 = load i64, ptr %slot376, align 8
  %v2423 = load i64, ptr %slot32, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  store i64 %v2422, ptr %p2424, align 8, !alias.scope !3, !noalias !4
  %v2425 = load i64, ptr %slot32, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %ld2427 = load i64, ptr %p2426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2427, ptr %slot378, align 8
  %v2428 = load i64, ptr %slot23, align 8
  store i64 %v2428, ptr %slot379, align 8
  %v2429 = load i64, ptr %slot378, align 8
  %v2430 = load i64, ptr %slot379, align 8
  %p2431 = inttoptr i64 %v2429 to ptr
  %p2432 = inttoptr i64 %v2430 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2432, ptr %p2431, i64 24, i1 false)
  %v2433 = load i64, ptr %slot17, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  store i32 2, ptr %p2434, align 4, !alias.scope !3, !noalias !4
  %v2435 = load i64, ptr %slot16, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  store i32 1, ptr %p2436, align 4, !alias.scope !3, !noalias !4
  %v2437 = load i64, ptr %slot12, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  %ld2439 = load i32, ptr %p2438, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2439, ptr %slot380, align 8
  %v2440 = load i32, ptr %slot380, align 8
  %cv2441 = zext i32 %v2440 to i64
  %cond2442 = icmp ne i64 %cv2441, 0
  br i1 %cond2442, label %bb_rcslotdrop485, label %bb_rcslotdone485
bb_rcslotdrop485:
  %v2443 = load i64, ptr %slot12, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  store i32 0, ptr %p2444, align 4, !alias.scope !3, !noalias !4
  %v2445 = load i64, ptr %slot19, align 8
  store i64 %v2445, ptr %slot381, align 8
  %v2446 = load i64, ptr %slot13, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  %ld2448 = load i32, ptr %p2447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2448, ptr %slot382, align 8
  %v2449 = load i32, ptr %slot382, align 8
  %op2450 = and i32 %v2449, 28
  store i32 %op2450, ptr %slot383, align 8
  %v2451 = load i32, ptr %slot383, align 8
  %cv2452 = zext i32 %v2451 to i64
  %cond2453 = icmp ne i64 %cv2452, 0
  br i1 %cond2453, label %bb_rcslotrole485, label %bb_rcslotowner485
bb_rcslotrole485:
  %v2454 = load i64, ptr %slot41, align 8
  store i64 %v2454, ptr %slot384, align 8
  %v2455 = load i64, ptr %slot384, align 8
  %v2456 = load i64, ptr %slot381, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2455, i64 %v2456) nomerge, !dbg !136
  br label %bb_rcslotdone485
bb_rcslotowner485:
  %v2457 = load i64, ptr %slot41, align 8
  store i64 %v2457, ptr %slot385, align 8
  %v2458 = load i64, ptr %slot385, align 8
  %v2459 = load i64, ptr %slot381, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2458, i64 %v2459) nomerge, !dbg !136
  br label %bb_rcslotdone485
bb_rcslotdone485:
  %v2460 = load i64, ptr %slot19, align 8
  store i64 %v2460, ptr %slot386, align 8
  %v2461 = load i64, ptr %slot23, align 8
  store i64 %v2461, ptr %slot387, align 8
  %v2462 = load i64, ptr %slot387, align 8
  %v2463 = load i64, ptr %slot386, align 8
  %p2464 = inttoptr i64 %v2462 to ptr
  %p2465 = inttoptr i64 %v2463 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2465, ptr %p2464, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2466 = load i64, ptr %slot13, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  store i32 2, ptr %p2467, align 4, !alias.scope !3, !noalias !4
  %v2468 = load i64, ptr %slot17, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  %ld2470 = load i32, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2470, ptr %slot388, align 8
  %v2471 = load i32, ptr %slot388, align 8
  %v2472 = load i64, ptr %slot13, align 8
  %p2473 = inttoptr i64 %v2472 to ptr
  store i32 %v2471, ptr %p2473, align 4, !alias.scope !3, !noalias !4
  %v2474 = load i64, ptr %slot16, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  store i32 0, ptr %p2475, align 4, !alias.scope !3, !noalias !4
  %v2476 = load i64, ptr %slot12, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  store i32 1, ptr %p2477, align 4, !alias.scope !3, !noalias !4
  %v2478 = load i64, ptr %slot386, align 8
  %v2479 = load i64, ptr %slot32, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  store i64 %v2478, ptr %p2480, align 8, !alias.scope !3, !noalias !4
  %v2481 = load i64, ptr %slot32, align 8
  %p2482 = inttoptr i64 %v2481 to ptr
  %ld2483 = load i64, ptr %p2482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2483, ptr %slot389, align 8
  %v2484 = load i64, ptr %slot389, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  %ld2486 = load i32, ptr %p2485, align 4, !alias.scope !3, !noalias !4
  %ext2487 = zext i32 %ld2486 to i64
  store i64 %ext2487, ptr %slot390, align 8
  %v2488 = load i64, ptr %slot390, align 8
  %cmp2489 = icmp eq i64 %v2488, 0
  %cv2490 = zext i1 %cmp2489 to i64
  store i64 %cv2490, ptr %slot391, align 8
  %v2491 = load i64, ptr %slot391, align 8
  %cond2492 = icmp ne i64 %v2491, 0
  br i1 %cond2492, label %bb_rctryok501, label %bb_rctryerror501
bb_rctryerror501:
  %p2493 = inttoptr i64 ptrtoint (ptr @myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2493, i64 12884901921) "call-inline-cost"="0", !dbg !138
  %v2494 = load i64, ptr %slot389, align 8
  %op2495 = add i64 %v2494, 8
  store i64 %op2495, ptr %slot392, align 8
  %v2496 = load i64, ptr %slot36, align 8
  store i64 %v2496, ptr %slot393, align 8
  %v2497 = load i64, ptr %slot393, align 8
  %p2498 = inttoptr i64 %v2497 to ptr
  store i64 0, ptr %p2498, align 8, !alias.scope !3, !noalias !4
  %v2499 = load i64, ptr %slot393, align 8
  %p2501 = inttoptr i64 %v2499 to ptr
  %gep2502 = getelementptr i8, ptr %p2501, i64 8
  %op2500 = ptrtoint ptr %gep2502 to i64
  store i64 %op2500, ptr %slot394, align 8
  %v2503 = load i64, ptr %slot394, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  store i64 0, ptr %p2504, align 8, !alias.scope !3, !noalias !4
  %v2505 = load i64, ptr %slot393, align 8
  %p2507 = inttoptr i64 %v2505 to ptr
  %gep2508 = getelementptr i8, ptr %p2507, i64 16
  %op2506 = ptrtoint ptr %gep2508 to i64
  store i64 %op2506, ptr %slot395, align 8
  %v2509 = load i64, ptr %slot395, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  store i64 0, ptr %p2510, align 8, !alias.scope !3, !noalias !4
  %v2511 = load i64, ptr %slot393, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  store i32 1, ptr %p2512, align 4, !alias.scope !3, !noalias !4
  %v2513 = load i64, ptr %slot393, align 8
  %p2515 = inttoptr i64 %v2513 to ptr
  %gep2516 = getelementptr i8, ptr %p2515, i64 8
  %op2514 = ptrtoint ptr %gep2516 to i64
  store i64 %op2514, ptr %slot396, align 8
  %v2517 = load i64, ptr %slot18, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  store i32 1, ptr %p2518, align 4, !alias.scope !3, !noalias !4
  %v2519 = load i64, ptr %slot42, align 8
  store i64 %v2519, ptr %slot397, align 8
  %v2520 = load i64, ptr %slot41, align 8
  %v2521 = load i64, ptr %slot396, align 8
  %v2522 = load i64, ptr %slot392, align 8
  %v2523 = load i64, ptr %slot397, align 8
  %cv2524 = trunc i64 %v2523 to i32
  %call2525 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v2520, i64 %v2521, i64 %v2522, i32 %cv2524) nomerge, !dbg !138
  store i32 %call2525, ptr %slot398, align 8
  %v2526 = load i32, ptr %slot398, align 8
  %cv2527 = zext i32 %v2526 to i64
  %cond2528 = icmp ne i64 %cv2527, 0
  br i1 %cond2528, label %bb_rcsuccess512, label %bb_rcfailure512
bb_rcfailure512:
  %v2529 = load i64, ptr %slot41, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %call2531 = call i32 @myl_rc_take_failure(ptr %p2530) nomerge, !dbg !138
  store i32 %call2531, ptr %slot399, align 8
  %v2532 = load i64, ptr %slot1, align 8
  %p2533 = inttoptr i64 %v2532 to ptr
  %v2534 = load i32, ptr %slot399, align 8
  %call2535 = call i32 @myl_qbe_rc_status(ptr %p2533, i32 %v2534) nomerge, !dbg !138
  store i32 %call2535, ptr %slot400, align 8
  br label %bb_failure
bb_rcsuccess512:
  %v2536 = load i64, ptr %slot393, align 8
  %v2537 = load i64, ptr %slot32, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i64 %v2536, ptr %p2538, align 8, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot32, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  %ld2541 = load i64, ptr %p2540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2541, ptr %slot401, align 8
  %v2542 = load i64, ptr %slot23, align 8
  store i64 %v2542, ptr %slot402, align 8
  %v2543 = load i64, ptr %slot401, align 8
  %v2544 = load i64, ptr %slot402, align 8
  %p2545 = inttoptr i64 %v2543 to ptr
  %p2546 = inttoptr i64 %v2544 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2546, ptr %p2545, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2547 = load i64, ptr %slot17, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  store i32 2, ptr %p2548, align 4, !alias.scope !3, !noalias !4
  %v2549 = load i64, ptr %slot16, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  store i32 1, ptr %p2550, align 4, !alias.scope !3, !noalias !4
  %v2551 = load i64, ptr %slot12, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %ld2553 = load i32, ptr %p2552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2553, ptr %slot403, align 8
  %v2554 = load i32, ptr %slot403, align 8
  %cv2555 = zext i32 %v2554 to i64
  %cond2556 = icmp ne i64 %cv2555, 0
  br i1 %cond2556, label %bb_rcslotdrop521, label %bb_rcslotdone521
bb_rcslotdrop521:
  %v2557 = load i64, ptr %slot12, align 8
  %p2558 = inttoptr i64 %v2557 to ptr
  store i32 0, ptr %p2558, align 4, !alias.scope !3, !noalias !4
  %v2559 = load i64, ptr %slot19, align 8
  store i64 %v2559, ptr %slot404, align 8
  %v2560 = load i64, ptr %slot13, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %ld2562 = load i32, ptr %p2561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2562, ptr %slot405, align 8
  %v2563 = load i32, ptr %slot405, align 8
  %op2564 = and i32 %v2563, 28
  store i32 %op2564, ptr %slot406, align 8
  %v2565 = load i32, ptr %slot406, align 8
  %cv2566 = zext i32 %v2565 to i64
  %cond2567 = icmp ne i64 %cv2566, 0
  br i1 %cond2567, label %bb_rcslotrole521, label %bb_rcslotowner521
bb_rcslotrole521:
  %v2568 = load i64, ptr %slot41, align 8
  store i64 %v2568, ptr %slot407, align 8
  %v2569 = load i64, ptr %slot407, align 8
  %v2570 = load i64, ptr %slot404, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2569, i64 %v2570) nomerge, !dbg !138
  br label %bb_rcslotdone521
bb_rcslotowner521:
  %v2571 = load i64, ptr %slot41, align 8
  store i64 %v2571, ptr %slot408, align 8
  %v2572 = load i64, ptr %slot408, align 8
  %v2573 = load i64, ptr %slot404, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2572, i64 %v2573) nomerge, !dbg !138
  br label %bb_rcslotdone521
bb_rcslotdone521:
  %v2574 = load i64, ptr %slot19, align 8
  store i64 %v2574, ptr %slot409, align 8
  %v2575 = load i64, ptr %slot23, align 8
  store i64 %v2575, ptr %slot410, align 8
  %v2576 = load i64, ptr %slot410, align 8
  %v2577 = load i64, ptr %slot409, align 8
  %p2578 = inttoptr i64 %v2576 to ptr
  %p2579 = inttoptr i64 %v2577 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2579, ptr %p2578, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2580 = load i64, ptr %slot13, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  store i32 2, ptr %p2581, align 4, !alias.scope !3, !noalias !4
  %v2582 = load i64, ptr %slot17, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  %ld2584 = load i32, ptr %p2583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2584, ptr %slot411, align 8
  %v2585 = load i32, ptr %slot411, align 8
  %v2586 = load i64, ptr %slot13, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  store i32 %v2585, ptr %p2587, align 4, !alias.scope !3, !noalias !4
  %v2588 = load i64, ptr %slot16, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  store i32 0, ptr %p2589, align 4, !alias.scope !3, !noalias !4
  %v2590 = load i64, ptr %slot12, align 8
  %p2591 = inttoptr i64 %v2590 to ptr
  store i32 1, ptr %p2591, align 4, !alias.scope !3, !noalias !4
  %v2592 = load i64, ptr %slot409, align 8
  %v2593 = load i64, ptr %slot32, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  store i64 %v2592, ptr %p2594, align 8, !alias.scope !3, !noalias !4
  br label %bb_i35
bb_rctryok501:
  %v2595 = load i64, ptr %slot36, align 8
  store i64 %v2595, ptr %slot412, align 8
  %v2596 = load i64, ptr %slot18, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  store i32 1, ptr %p2597, align 4, !alias.scope !3, !noalias !4
  %v2598 = load i64, ptr %slot389, align 8
  %op2599 = add i64 %v2598, 8
  store i64 %op2599, ptr %slot413, align 8
  %v2600 = load i64, ptr %slot42, align 8
  store i64 %v2600, ptr %slot414, align 8
  store i64 0, ptr %slot415, align 8
  store i64 0, ptr %slot416, align 8
  %v2601 = load i64, ptr %slot416, align 8
  %v2602 = load i64, ptr %slot32, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  store i64 %v2601, ptr %p2603, align 8, !alias.scope !3, !noalias !4
  %v2604 = load i64, ptr %slot12, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  %ld2606 = load i32, ptr %p2605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2606, ptr %slot417, align 8
  %v2607 = load i32, ptr %slot417, align 8
  %cv2608 = zext i32 %v2607 to i64
  %cond2609 = icmp ne i64 %cv2608, 0
  br i1 %cond2609, label %bb_rcslotdrop545, label %bb_rcslotdone545
bb_rcslotdrop545:
  %v2610 = load i64, ptr %slot12, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i32 0, ptr %p2611, align 4, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot19, align 8
  store i64 %v2612, ptr %slot418, align 8
  %v2613 = load i64, ptr %slot13, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  %ld2615 = load i32, ptr %p2614, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2615, ptr %slot419, align 8
  %v2616 = load i32, ptr %slot419, align 8
  %op2617 = and i32 %v2616, 28
  store i32 %op2617, ptr %slot420, align 8
  %v2618 = load i32, ptr %slot420, align 8
  %cv2619 = zext i32 %v2618 to i64
  %cond2620 = icmp ne i64 %cv2619, 0
  br i1 %cond2620, label %bb_rcslotrole545, label %bb_rcslotowner545
bb_rcslotrole545:
  %v2621 = load i64, ptr %slot41, align 8
  store i64 %v2621, ptr %slot421, align 8
  %v2622 = load i64, ptr %slot421, align 8
  %v2623 = load i64, ptr %slot418, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2622, i64 %v2623) nomerge, !dbg !138
  br label %bb_rcslotdone545
bb_rcslotowner545:
  %v2624 = load i64, ptr %slot41, align 8
  store i64 %v2624, ptr %slot422, align 8
  %v2625 = load i64, ptr %slot422, align 8
  %v2626 = load i64, ptr %slot418, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2625, i64 %v2626) nomerge, !dbg !138
  br label %bb_rcslotdone545
bb_rcslotdone545:
  br label %bb_i36
bb_i35:
  %v2627 = load i64, ptr %slot32, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  %ld2629 = load i64, ptr %p2628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2629, ptr %slot423, align 8
  %v2630 = load i64, ptr %slot32, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  %ld2632 = load i64, ptr %p2631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2632, ptr %slot424, align 8
  %v2633 = load i64, ptr %slot12, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  %ld2635 = load i32, ptr %p2634, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2635, ptr %slot425, align 8
  %v2636 = load i64, ptr %slot13, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  %ld2638 = load i32, ptr %p2637, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2638, ptr %slot426, align 8
  %v2639 = load i32, ptr %slot426, align 8
  %op2640 = and i32 %v2639, 24
  store i32 %op2640, ptr %slot426, align 8
  %v2641 = load i32, ptr %slot426, align 8
  %cmp2642 = icmp eq i32 %v2641, 0
  %cv2643 = zext i1 %cmp2642 to i32
  store i32 %cv2643, ptr %slot427, align 8
  %v2644 = load i32, ptr %slot425, align 8
  %v2645 = load i32, ptr %slot427, align 8
  %op2646 = and i32 %v2644, %v2645
  store i32 %op2646, ptr %slot428, align 8
  %v2647 = load i32, ptr %slot428, align 8
  %cv2648 = zext i32 %v2647 to i64
  %cond2649 = icmp ne i64 %cv2648, 0
  br i1 %cond2649, label %bb_rctake554, label %bb_rccopy554
bb_rctake554:
  %v2650 = load i64, ptr %slot23, align 8
  store i64 %v2650, ptr %slot429, align 8
  %v2651 = load i64, ptr %slot42, align 8
  store i64 %v2651, ptr %slot430, align 8
  %v2652 = load i64, ptr %slot41, align 8
  %v2653 = load i64, ptr %slot429, align 8
  %v2654 = load i64, ptr %slot424, align 8
  %v2655 = load i64, ptr %slot430, align 8
  %cv2656 = trunc i64 %v2655 to i32
  %call2657 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v2652, i64 %v2653, i64 %v2654, i32 %cv2656) nomerge, !dbg !140
  store i32 %call2657, ptr %slot431, align 8
  %v2658 = load i32, ptr %slot431, align 8
  %cv2659 = zext i32 %v2658 to i64
  %cond2660 = icmp ne i64 %cv2659, 0
  br i1 %cond2660, label %bb_rcsuccess564, label %bb_rcfailure564
bb_rcfailure564:
  %v2661 = load i64, ptr %slot41, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %call2663 = call i32 @myl_rc_take_failure(ptr %p2662) nomerge, !dbg !140
  store i32 %call2663, ptr %slot432, align 8
  %v2664 = load i64, ptr %slot1, align 8
  %p2665 = inttoptr i64 %v2664 to ptr
  %v2666 = load i32, ptr %slot432, align 8
  %call2667 = call i32 @myl_qbe_rc_status(ptr %p2665, i32 %v2666) nomerge, !dbg !140
  store i32 %call2667, ptr %slot433, align 8
  br label %bb_failure
bb_rcsuccess564:
  %v2668 = load i64, ptr %slot12, align 8
  %p2669 = inttoptr i64 %v2668 to ptr
  store i32 0, ptr %p2669, align 4, !alias.scope !3, !noalias !4
  %v2670 = load i64, ptr %slot17, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  store i32 2, ptr %p2671, align 4, !alias.scope !3, !noalias !4
  %v2672 = load i64, ptr %slot16, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  store i32 1, ptr %p2673, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared554
bb_rccopy554:
  %v2674 = load i64, ptr %slot23, align 8
  store i64 %v2674, ptr %slot434, align 8
  %v2675 = load i64, ptr %slot42, align 8
  store i64 %v2675, ptr %slot435, align 8
  %v2676 = load i64, ptr %slot41, align 8
  %v2677 = load i64, ptr %slot434, align 8
  %v2678 = load i64, ptr %slot424, align 8
  %v2679 = load i64, ptr %slot435, align 8
  %cv2680 = trunc i64 %v2679 to i32
  %call2681 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v2676, i64 %v2677, i64 %v2678, i32 %cv2680) nomerge, !dbg !140
  store i32 %call2681, ptr %slot436, align 8
  %v2682 = load i32, ptr %slot436, align 8
  %cv2683 = zext i32 %v2682 to i64
  %cond2684 = icmp ne i64 %cv2683, 0
  br i1 %cond2684, label %bb_rcsuccess573, label %bb_rcfailure573
bb_rcfailure573:
  %v2685 = load i64, ptr %slot41, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %call2687 = call i32 @myl_rc_take_failure(ptr %p2686) nomerge, !dbg !140
  store i32 %call2687, ptr %slot437, align 8
  %v2688 = load i64, ptr %slot1, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %v2690 = load i32, ptr %slot437, align 8
  %call2691 = call i32 @myl_qbe_rc_status(ptr %p2689, i32 %v2690) nomerge, !dbg !140
  store i32 %call2691, ptr %slot438, align 8
  br label %bb_failure
bb_rcsuccess573:
  %v2692 = load i64, ptr %slot17, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  store i32 2, ptr %p2693, align 4, !alias.scope !3, !noalias !4
  %v2694 = load i64, ptr %slot16, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  store i32 1, ptr %p2695, align 4, !alias.scope !3, !noalias !4
  %v2696 = load i64, ptr %slot12, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  %ld2698 = load i32, ptr %p2697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2698, ptr %slot439, align 8
  %v2699 = load i32, ptr %slot439, align 8
  %cv2700 = zext i32 %v2699 to i64
  %cond2701 = icmp ne i64 %cv2700, 0
  br i1 %cond2701, label %bb_rcslotdrop580, label %bb_rcslotdone580
bb_rcslotdrop580:
  %v2702 = load i64, ptr %slot12, align 8
  %p2703 = inttoptr i64 %v2702 to ptr
  store i32 0, ptr %p2703, align 4, !alias.scope !3, !noalias !4
  %v2704 = load i64, ptr %slot19, align 8
  store i64 %v2704, ptr %slot440, align 8
  %v2705 = load i64, ptr %slot13, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  %ld2707 = load i32, ptr %p2706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2707, ptr %slot441, align 8
  %v2708 = load i32, ptr %slot441, align 8
  %op2709 = and i32 %v2708, 28
  store i32 %op2709, ptr %slot442, align 8
  %v2710 = load i32, ptr %slot442, align 8
  %cv2711 = zext i32 %v2710 to i64
  %cond2712 = icmp ne i64 %cv2711, 0
  br i1 %cond2712, label %bb_rcslotrole580, label %bb_rcslotowner580
bb_rcslotrole580:
  %v2713 = load i64, ptr %slot41, align 8
  store i64 %v2713, ptr %slot443, align 8
  %v2714 = load i64, ptr %slot443, align 8
  %v2715 = load i64, ptr %slot440, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2714, i64 %v2715) nomerge, !dbg !140
  br label %bb_rcslotdone580
bb_rcslotowner580:
  %v2716 = load i64, ptr %slot41, align 8
  store i64 %v2716, ptr %slot444, align 8
  %v2717 = load i64, ptr %slot444, align 8
  %v2718 = load i64, ptr %slot440, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2717, i64 %v2718) nomerge, !dbg !140
  br label %bb_rcslotdone580
bb_rcslotdone580:
  br label %bb_rcprepared554
bb_rcprepared554:
  %v2719 = load i64, ptr %slot23, align 8
  store i64 %v2719, ptr %slot445, align 8
  %v2720 = load i64, ptr %slot16, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  store i32 0, ptr %p2721, align 4, !alias.scope !3, !noalias !4
  %v2722 = load i64, ptr %slot12, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  %ld2724 = load i32, ptr %p2723, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2724, ptr %slot446, align 8
  %v2725 = load i32, ptr %slot446, align 8
  %cv2726 = zext i32 %v2725 to i64
  %cond2727 = icmp ne i64 %cv2726, 0
  br i1 %cond2727, label %bb_rcslotdrop591, label %bb_rcslotdone591
bb_rcslotdrop591:
  %v2728 = load i64, ptr %slot12, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  store i32 0, ptr %p2729, align 4, !alias.scope !3, !noalias !4
  %v2730 = load i64, ptr %slot19, align 8
  store i64 %v2730, ptr %slot447, align 8
  %v2731 = load i64, ptr %slot13, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  %ld2733 = load i32, ptr %p2732, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2733, ptr %slot448, align 8
  %v2734 = load i32, ptr %slot448, align 8
  %op2735 = and i32 %v2734, 28
  store i32 %op2735, ptr %slot449, align 8
  %v2736 = load i32, ptr %slot449, align 8
  %cv2737 = zext i32 %v2736 to i64
  %cond2738 = icmp ne i64 %cv2737, 0
  br i1 %cond2738, label %bb_rcslotrole591, label %bb_rcslotowner591
bb_rcslotrole591:
  %v2739 = load i64, ptr %slot41, align 8
  store i64 %v2739, ptr %slot450, align 8
  %v2740 = load i64, ptr %slot450, align 8
  %v2741 = load i64, ptr %slot447, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2740, i64 %v2741) nomerge, !dbg !140
  br label %bb_rcslotdone591
bb_rcslotowner591:
  %v2742 = load i64, ptr %slot41, align 8
  store i64 %v2742, ptr %slot451, align 8
  %v2743 = load i64, ptr %slot451, align 8
  %v2744 = load i64, ptr %slot447, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2743, i64 %v2744) nomerge, !dbg !140
  br label %bb_rcslotdone591
bb_rcslotdone591:
  %v2745 = load i64, ptr %slot10, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  %ld2747 = load i32, ptr %p2746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2747, ptr %slot452, align 8
  %v2748 = load i32, ptr %slot452, align 8
  %cv2749 = zext i32 %v2748 to i64
  %cond2750 = icmp ne i64 %cv2749, 0
  br i1 %cond2750, label %bb_rcslotdrop600, label %bb_rcslotdone600
bb_rcslotdrop600:
  %v2751 = load i64, ptr %slot10, align 8
  %p2752 = inttoptr i64 %v2751 to ptr
  store i32 0, ptr %p2752, align 4, !alias.scope !3, !noalias !4
  %v2753 = load i64, ptr %slot31, align 8
  store i64 %v2753, ptr %slot453, align 8
  %v2754 = load i64, ptr %slot11, align 8
  %p2755 = inttoptr i64 %v2754 to ptr
  %ld2756 = load i32, ptr %p2755, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2756, ptr %slot454, align 8
  %v2757 = load i32, ptr %slot454, align 8
  %op2758 = and i32 %v2757, 28
  store i32 %op2758, ptr %slot455, align 8
  %v2759 = load i32, ptr %slot455, align 8
  %cv2760 = zext i32 %v2759 to i64
  %cond2761 = icmp ne i64 %cv2760, 0
  br i1 %cond2761, label %bb_rcslotrole600, label %bb_rcslotowner600
bb_rcslotrole600:
  %v2762 = load i64, ptr %slot41, align 8
  store i64 %v2762, ptr %slot456, align 8
  %v2763 = load i64, ptr %slot453, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %ld2765 = load i64, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2765, ptr %slot457, align 8
  %v2766 = load i64, ptr %slot457, align 8
  %cmp2767 = icmp ne i64 %v2766, 0
  %cv2768 = zext i1 %cmp2767 to i32
  store i32 %cv2768, ptr %slot458, align 8
  %v2769 = load i32, ptr %slot458, align 8
  %cv2770 = zext i32 %v2769 to i64
  %cond2771 = icmp ne i64 %cv2770, 0
  br i1 %cond2771, label %bb_rcgnn616, label %bb_rcgdone616
bb_rcgnn616:
  %v2772 = load i64, ptr %slot457, align 8
  %op2773 = sub i64 %v2772, 16
  store i64 %op2773, ptr %slot459, align 8
  %v2774 = load i64, ptr %slot457, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  %rgep2776 = getelementptr i8, ptr %p2775, i64 -16
  %ld2777 = load i64, ptr %rgep2776, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2777, ptr %slot460, align 8
  %v2778 = load i64, ptr %slot460, align 8
  %op2779 = and i64 %v2778, 4611686018427387906
  store i64 %op2779, ptr %slot461, align 8
  %v2780 = load i64, ptr %slot461, align 8
  %cmp2781 = icmp ne i64 %v2780, 0
  %cv2782 = zext i1 %cmp2781 to i32
  store i32 %cv2782, ptr %slot462, align 8
  %v2783 = load i32, ptr %slot462, align 8
  %cv2784 = zext i32 %v2783 to i64
  %cond2785 = icmp ne i64 %cv2784, 0
  br i1 %cond2785, label %bb_rcgclear616, label %bb_rcgcounted616
bb_rcgcounted616:
  %v2786 = load i64, ptr %slot457, align 8
  %op2787 = sub i64 %v2786, 24
  store i64 %op2787, ptr %slot463, align 8
  %v2788 = load i64, ptr %slot457, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  %rgep2790 = getelementptr i8, ptr %p2789, i64 -24
  %ld2791 = load i64, ptr %rgep2790, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2791, ptr %slot464, align 8
  %v2792 = load i64, ptr %slot464, align 8
  %op2793 = sub i64 %v2792, 1
  store i64 %op2793, ptr %slot465, align 8
  %v2794 = load i64, ptr %slot465, align 8
  %cmp2795 = icmp eq i64 %v2794, 0
  %cv2796 = zext i1 %cmp2795 to i32
  store i32 %cv2796, ptr %slot466, align 8
  %v2797 = load i32, ptr %slot466, align 8
  %cv2798 = zext i32 %v2797 to i64
  %cond2799 = icmp ne i64 %cv2798, 0
  br i1 %cond2799, label %bb_rcglast616, label %bb_rcgdec616
bb_rcglast616:
  %v2800 = load i64, ptr %slot457, align 8
  %op2801 = sub i64 %v2800, 32
  store i64 %op2801, ptr %slot467, align 8
  %v2802 = load i64, ptr %slot457, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  %rgep2804 = getelementptr i8, ptr %p2803, i64 -32
  %ld2805 = load i64, ptr %rgep2804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2805, ptr %slot468, align 8
  %v2806 = load i64, ptr %slot468, align 8
  %cmp2807 = icmp ne i64 %v2806, 0
  %cv2808 = zext i1 %cmp2807 to i32
  store i32 %cv2808, ptr %slot469, align 8
  %v2809 = load i32, ptr %slot469, align 8
  %cv2810 = zext i32 %v2809 to i64
  %cond2811 = icmp ne i64 %cv2810, 0
  br i1 %cond2811, label %bb_rcgdec616, label %bb_rcgslow616
bb_rcgslow616:
  %v2812 = load i64, ptr %slot456, align 8
  %v2813 = load i64, ptr %slot453, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2812, i64 %v2813) nomerge, !dbg !140
  br label %bb_rcgdone616
bb_rcgdec616:
  %v2814 = load i64, ptr %slot465, align 8
  %v2815 = load i64, ptr %slot457, align 8
  %p2816 = inttoptr i64 %v2815 to ptr
  %rgep2817 = getelementptr i8, ptr %p2816, i64 -24
  store i64 %v2814, ptr %rgep2817, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear616
bb_rcgclear616:
  %v2818 = load i64, ptr %slot453, align 8
  %p2819 = inttoptr i64 %v2818 to ptr
  store i64 0, ptr %p2819, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone616
bb_rcgdone616:
  br label %bb_rcslotdone600
bb_rcslotowner600:
  %v2820 = load i64, ptr %slot41, align 8
  store i64 %v2820, ptr %slot470, align 8
  %v2821 = load i64, ptr %slot453, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  %ld2823 = load i64, ptr %p2822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2823, ptr %slot471, align 8
  %v2824 = load i64, ptr %slot471, align 8
  %cmp2825 = icmp ne i64 %v2824, 0
  %cv2826 = zext i1 %cmp2825 to i32
  store i32 %cv2826, ptr %slot472, align 8
  %v2827 = load i32, ptr %slot472, align 8
  %cv2828 = zext i32 %v2827 to i64
  %cond2829 = icmp ne i64 %cv2828, 0
  br i1 %cond2829, label %bb_rcgnn631, label %bb_rcgdone631
bb_rcgnn631:
  %v2830 = load i64, ptr %slot471, align 8
  %op2831 = sub i64 %v2830, 16
  store i64 %op2831, ptr %slot473, align 8
  %v2832 = load i64, ptr %slot471, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  %rgep2834 = getelementptr i8, ptr %p2833, i64 -16
  %ld2835 = load i64, ptr %rgep2834, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2835, ptr %slot474, align 8
  %v2836 = load i64, ptr %slot474, align 8
  %op2837 = and i64 %v2836, 4611686018427387906
  store i64 %op2837, ptr %slot475, align 8
  %v2838 = load i64, ptr %slot475, align 8
  %cmp2839 = icmp ne i64 %v2838, 0
  %cv2840 = zext i1 %cmp2839 to i32
  store i32 %cv2840, ptr %slot476, align 8
  %v2841 = load i32, ptr %slot476, align 8
  %cv2842 = zext i32 %v2841 to i64
  %cond2843 = icmp ne i64 %cv2842, 0
  br i1 %cond2843, label %bb_rcgclear631, label %bb_rcgcounted631
bb_rcgcounted631:
  %v2844 = load i64, ptr %slot471, align 8
  %op2845 = sub i64 %v2844, 32
  store i64 %op2845, ptr %slot477, align 8
  %v2846 = load i64, ptr %slot471, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  %rgep2848 = getelementptr i8, ptr %p2847, i64 -32
  %ld2849 = load i64, ptr %rgep2848, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2849, ptr %slot478, align 8
  %v2850 = load i64, ptr %slot478, align 8
  %op2851 = sub i64 %v2850, 1
  store i64 %op2851, ptr %slot479, align 8
  %v2852 = load i64, ptr %slot479, align 8
  %cmp2853 = icmp eq i64 %v2852, 0
  %cv2854 = zext i1 %cmp2853 to i32
  store i32 %cv2854, ptr %slot480, align 8
  %v2855 = load i32, ptr %slot480, align 8
  %cv2856 = zext i32 %v2855 to i64
  %cond2857 = icmp ne i64 %cv2856, 0
  br i1 %cond2857, label %bb_rcglast631, label %bb_rcgdec631
bb_rcglast631:
  %v2858 = load i64, ptr %slot471, align 8
  %op2859 = sub i64 %v2858, 24
  store i64 %op2859, ptr %slot481, align 8
  %v2860 = load i64, ptr %slot471, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  %rgep2862 = getelementptr i8, ptr %p2861, i64 -24
  %ld2863 = load i64, ptr %rgep2862, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2863, ptr %slot482, align 8
  %v2864 = load i64, ptr %slot482, align 8
  %cmp2865 = icmp ne i64 %v2864, 0
  %cv2866 = zext i1 %cmp2865 to i32
  store i32 %cv2866, ptr %slot483, align 8
  %v2867 = load i32, ptr %slot483, align 8
  %cv2868 = zext i32 %v2867 to i64
  %cond2869 = icmp ne i64 %cv2868, 0
  br i1 %cond2869, label %bb_rcgdec631, label %bb_rcgslow631
bb_rcgslow631:
  %v2870 = load i64, ptr %slot470, align 8
  %v2871 = load i64, ptr %slot453, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2870, i64 %v2871) nomerge, !dbg !140
  br label %bb_rcgdone631
bb_rcgdec631:
  %v2872 = load i64, ptr %slot479, align 8
  %v2873 = load i64, ptr %slot471, align 8
  %p2874 = inttoptr i64 %v2873 to ptr
  %rgep2875 = getelementptr i8, ptr %p2874, i64 -32
  store i64 %v2872, ptr %rgep2875, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear631
bb_rcgclear631:
  %v2876 = load i64, ptr %slot453, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  store i64 0, ptr %p2877, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone631
bb_rcgdone631:
  br label %bb_rcslotdone600
bb_rcslotdone600:
  %v2878 = load i64, ptr %slot8, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  %ld2880 = load i32, ptr %p2879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2880, ptr %slot484, align 8
  %v2881 = load i32, ptr %slot484, align 8
  %cv2882 = zext i32 %v2881 to i64
  %cond2883 = icmp ne i64 %cv2882, 0
  br i1 %cond2883, label %bb_rcslotdrop637, label %bb_rcslotdone637
bb_rcslotdrop637:
  %v2884 = load i64, ptr %slot8, align 8
  %p2885 = inttoptr i64 %v2884 to ptr
  store i32 0, ptr %p2885, align 4, !alias.scope !3, !noalias !4
  %v2886 = load i64, ptr %slot27, align 8
  store i64 %v2886, ptr %slot485, align 8
  %v2887 = load i64, ptr %slot9, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  %ld2889 = load i32, ptr %p2888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2889, ptr %slot486, align 8
  %v2890 = load i32, ptr %slot486, align 8
  %op2891 = and i32 %v2890, 28
  store i32 %op2891, ptr %slot487, align 8
  %v2892 = load i32, ptr %slot487, align 8
  %cv2893 = zext i32 %v2892 to i64
  %cond2894 = icmp ne i64 %cv2893, 0
  br i1 %cond2894, label %bb_rcslotrole637, label %bb_rcslotowner637
bb_rcslotrole637:
  %v2895 = load i64, ptr %slot41, align 8
  store i64 %v2895, ptr %slot488, align 8
  %v2896 = load i64, ptr %slot485, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  %ld2898 = load i64, ptr %p2897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2898, ptr %slot489, align 8
  %v2899 = load i64, ptr %slot489, align 8
  %cmp2900 = icmp ne i64 %v2899, 0
  %cv2901 = zext i1 %cmp2900 to i32
  store i32 %cv2901, ptr %slot490, align 8
  %v2902 = load i32, ptr %slot490, align 8
  %cv2903 = zext i32 %v2902 to i64
  %cond2904 = icmp ne i64 %cv2903, 0
  br i1 %cond2904, label %bb_rcgnn653, label %bb_rcgdone653
bb_rcgnn653:
  %v2905 = load i64, ptr %slot489, align 8
  %op2906 = sub i64 %v2905, 16
  store i64 %op2906, ptr %slot491, align 8
  %v2907 = load i64, ptr %slot489, align 8
  %p2908 = inttoptr i64 %v2907 to ptr
  %rgep2909 = getelementptr i8, ptr %p2908, i64 -16
  %ld2910 = load i64, ptr %rgep2909, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2910, ptr %slot492, align 8
  %v2911 = load i64, ptr %slot492, align 8
  %op2912 = and i64 %v2911, 4611686018427387906
  store i64 %op2912, ptr %slot493, align 8
  %v2913 = load i64, ptr %slot493, align 8
  %cmp2914 = icmp ne i64 %v2913, 0
  %cv2915 = zext i1 %cmp2914 to i32
  store i32 %cv2915, ptr %slot494, align 8
  %v2916 = load i32, ptr %slot494, align 8
  %cv2917 = zext i32 %v2916 to i64
  %cond2918 = icmp ne i64 %cv2917, 0
  br i1 %cond2918, label %bb_rcgclear653, label %bb_rcgcounted653
bb_rcgcounted653:
  %v2919 = load i64, ptr %slot489, align 8
  %op2920 = sub i64 %v2919, 24
  store i64 %op2920, ptr %slot495, align 8
  %v2921 = load i64, ptr %slot489, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  %rgep2923 = getelementptr i8, ptr %p2922, i64 -24
  %ld2924 = load i64, ptr %rgep2923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2924, ptr %slot496, align 8
  %v2925 = load i64, ptr %slot496, align 8
  %op2926 = sub i64 %v2925, 1
  store i64 %op2926, ptr %slot497, align 8
  %v2927 = load i64, ptr %slot497, align 8
  %cmp2928 = icmp eq i64 %v2927, 0
  %cv2929 = zext i1 %cmp2928 to i32
  store i32 %cv2929, ptr %slot498, align 8
  %v2930 = load i32, ptr %slot498, align 8
  %cv2931 = zext i32 %v2930 to i64
  %cond2932 = icmp ne i64 %cv2931, 0
  br i1 %cond2932, label %bb_rcglast653, label %bb_rcgdec653
bb_rcglast653:
  %v2933 = load i64, ptr %slot489, align 8
  %op2934 = sub i64 %v2933, 32
  store i64 %op2934, ptr %slot499, align 8
  %v2935 = load i64, ptr %slot489, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  %rgep2937 = getelementptr i8, ptr %p2936, i64 -32
  %ld2938 = load i64, ptr %rgep2937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2938, ptr %slot500, align 8
  %v2939 = load i64, ptr %slot500, align 8
  %cmp2940 = icmp ne i64 %v2939, 0
  %cv2941 = zext i1 %cmp2940 to i32
  store i32 %cv2941, ptr %slot501, align 8
  %v2942 = load i32, ptr %slot501, align 8
  %cv2943 = zext i32 %v2942 to i64
  %cond2944 = icmp ne i64 %cv2943, 0
  br i1 %cond2944, label %bb_rcgdec653, label %bb_rcgslow653
bb_rcgslow653:
  %v2945 = load i64, ptr %slot488, align 8
  %v2946 = load i64, ptr %slot485, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2945, i64 %v2946) nomerge, !dbg !140
  br label %bb_rcgdone653
bb_rcgdec653:
  %v2947 = load i64, ptr %slot497, align 8
  %v2948 = load i64, ptr %slot489, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  %rgep2950 = getelementptr i8, ptr %p2949, i64 -24
  store i64 %v2947, ptr %rgep2950, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear653
bb_rcgclear653:
  %v2951 = load i64, ptr %slot485, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  store i64 0, ptr %p2952, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone653
bb_rcgdone653:
  br label %bb_rcslotdone637
bb_rcslotowner637:
  %v2953 = load i64, ptr %slot41, align 8
  store i64 %v2953, ptr %slot502, align 8
  %v2954 = load i64, ptr %slot485, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  %ld2956 = load i64, ptr %p2955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2956, ptr %slot503, align 8
  %v2957 = load i64, ptr %slot503, align 8
  %cmp2958 = icmp ne i64 %v2957, 0
  %cv2959 = zext i1 %cmp2958 to i32
  store i32 %cv2959, ptr %slot504, align 8
  %v2960 = load i32, ptr %slot504, align 8
  %cv2961 = zext i32 %v2960 to i64
  %cond2962 = icmp ne i64 %cv2961, 0
  br i1 %cond2962, label %bb_rcgnn668, label %bb_rcgdone668
bb_rcgnn668:
  %v2963 = load i64, ptr %slot503, align 8
  %op2964 = sub i64 %v2963, 16
  store i64 %op2964, ptr %slot505, align 8
  %v2965 = load i64, ptr %slot503, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  %rgep2967 = getelementptr i8, ptr %p2966, i64 -16
  %ld2968 = load i64, ptr %rgep2967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2968, ptr %slot506, align 8
  %v2969 = load i64, ptr %slot506, align 8
  %op2970 = and i64 %v2969, 4611686018427387906
  store i64 %op2970, ptr %slot507, align 8
  %v2971 = load i64, ptr %slot507, align 8
  %cmp2972 = icmp ne i64 %v2971, 0
  %cv2973 = zext i1 %cmp2972 to i32
  store i32 %cv2973, ptr %slot508, align 8
  %v2974 = load i32, ptr %slot508, align 8
  %cv2975 = zext i32 %v2974 to i64
  %cond2976 = icmp ne i64 %cv2975, 0
  br i1 %cond2976, label %bb_rcgclear668, label %bb_rcgcounted668
bb_rcgcounted668:
  %v2977 = load i64, ptr %slot503, align 8
  %op2978 = sub i64 %v2977, 32
  store i64 %op2978, ptr %slot509, align 8
  %v2979 = load i64, ptr %slot503, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  %rgep2981 = getelementptr i8, ptr %p2980, i64 -32
  %ld2982 = load i64, ptr %rgep2981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2982, ptr %slot510, align 8
  %v2983 = load i64, ptr %slot510, align 8
  %op2984 = sub i64 %v2983, 1
  store i64 %op2984, ptr %slot511, align 8
  %v2985 = load i64, ptr %slot511, align 8
  %cmp2986 = icmp eq i64 %v2985, 0
  %cv2987 = zext i1 %cmp2986 to i32
  store i32 %cv2987, ptr %slot512, align 8
  %v2988 = load i32, ptr %slot512, align 8
  %cv2989 = zext i32 %v2988 to i64
  %cond2990 = icmp ne i64 %cv2989, 0
  br i1 %cond2990, label %bb_rcglast668, label %bb_rcgdec668
bb_rcglast668:
  %v2991 = load i64, ptr %slot503, align 8
  %op2992 = sub i64 %v2991, 24
  store i64 %op2992, ptr %slot513, align 8
  %v2993 = load i64, ptr %slot503, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  %rgep2995 = getelementptr i8, ptr %p2994, i64 -24
  %ld2996 = load i64, ptr %rgep2995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2996, ptr %slot514, align 8
  %v2997 = load i64, ptr %slot514, align 8
  %cmp2998 = icmp ne i64 %v2997, 0
  %cv2999 = zext i1 %cmp2998 to i32
  store i32 %cv2999, ptr %slot515, align 8
  %v3000 = load i32, ptr %slot515, align 8
  %cv3001 = zext i32 %v3000 to i64
  %cond3002 = icmp ne i64 %cv3001, 0
  br i1 %cond3002, label %bb_rcgdec668, label %bb_rcgslow668
bb_rcgslow668:
  %v3003 = load i64, ptr %slot502, align 8
  %v3004 = load i64, ptr %slot485, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3003, i64 %v3004) nomerge, !dbg !140
  br label %bb_rcgdone668
bb_rcgdec668:
  %v3005 = load i64, ptr %slot511, align 8
  %v3006 = load i64, ptr %slot503, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  %rgep3008 = getelementptr i8, ptr %p3007, i64 -32
  store i64 %v3005, ptr %rgep3008, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear668
bb_rcgclear668:
  %v3009 = load i64, ptr %slot485, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  store i64 0, ptr %p3010, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone668
bb_rcgdone668:
  br label %bb_rcslotdone637
bb_rcslotdone637:
  %v3011 = load i64, ptr %slot6, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  %ld3013 = load i32, ptr %p3012, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3013, ptr %slot516, align 8
  %v3014 = load i32, ptr %slot516, align 8
  %cv3015 = zext i32 %v3014 to i64
  %cond3016 = icmp ne i64 %cv3015, 0
  br i1 %cond3016, label %bb_rcslotdrop674, label %bb_rcslotdone674
bb_rcslotdrop674:
  %v3017 = load i64, ptr %slot6, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  store i32 0, ptr %p3018, align 4, !alias.scope !3, !noalias !4
  %v3019 = load i64, ptr %slot26, align 8
  store i64 %v3019, ptr %slot517, align 8
  %v3020 = load i64, ptr %slot7, align 8
  %p3021 = inttoptr i64 %v3020 to ptr
  %ld3022 = load i32, ptr %p3021, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3022, ptr %slot518, align 8
  %v3023 = load i32, ptr %slot518, align 8
  %op3024 = and i32 %v3023, 28
  store i32 %op3024, ptr %slot519, align 8
  %v3025 = load i32, ptr %slot519, align 8
  %cv3026 = zext i32 %v3025 to i64
  %cond3027 = icmp ne i64 %cv3026, 0
  br i1 %cond3027, label %bb_rcslotrole674, label %bb_rcslotowner674
bb_rcslotrole674:
  %v3028 = load i64, ptr %slot41, align 8
  store i64 %v3028, ptr %slot520, align 8
  %v3029 = load i64, ptr %slot520, align 8
  %v3030 = load i64, ptr %slot517, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v3029, i64 %v3030) nomerge, !dbg !140
  br label %bb_rcslotdone674
bb_rcslotowner674:
  %v3031 = load i64, ptr %slot41, align 8
  store i64 %v3031, ptr %slot521, align 8
  %v3032 = load i64, ptr %slot521, align 8
  %v3033 = load i64, ptr %slot517, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v3032, i64 %v3033) nomerge, !dbg !140
  br label %bb_rcslotdone674
bb_rcslotdone674:
  %v3034 = load i64, ptr %slot445, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3035, i64 24, i1 false)
  ret void
bb_i36:
  %v3036 = load i64, ptr %slot29, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  %ld3038 = load i64, ptr %p3037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3038, ptr %slot522, align 8
  %v3039 = load i64, ptr %slot522, align 8
  %v3040 = load i64, ptr %slot32, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  store i64 %v3039, ptr %p3041, align 8, !alias.scope !3, !noalias !4
  %v3042 = load i64, ptr %slot27, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  %ld3044 = load i64, ptr %p3043, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3044, ptr %slot523, align 8
  %v3045 = load i64, ptr %slot32, align 8
  %p3046 = inttoptr i64 %v3045 to ptr
  %ld3047 = load i64, ptr %p3046, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3047, ptr %slot524, align 8
  %v3048 = load i64, ptr %slot523, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %ld3050 = load i64, ptr %p3049, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3050, ptr %slot525, align 8
  %v3051 = load i64, ptr %slot525, align 8
  %v3052 = load i64, ptr %slot524, align 8
  %cmp3053 = icmp eq i64 %v3051, %v3052
  %cv3054 = zext i1 %cmp3053 to i64
  store i64 %cv3054, ptr %slot526, align 8
  %v3055 = load i64, ptr %slot526, align 8
  %cond3056 = icmp ne i64 %v3055, 0
  br i1 %cond3056, label %bb_success695, label %bb_failed695
bb_failed695:
  %v3057 = load i64, ptr %slot1, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  call void @myl_qbe_fail_iteration(ptr %p3058) nomerge, !dbg !142
  unreachable
bb_success695:
  %v3059 = load i64, ptr %slot32, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  store i64 0, ptr %p3060, align 8, !alias.scope !3, !noalias !4
  %v3061 = load i64, ptr %slot28, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  %ld3063 = load i64, ptr %p3062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3063, ptr %slot527, align 8
  %v3064 = load i64, ptr %slot527, align 8
  %v3065 = load i64, ptr %slot32, align 8
  %p3066 = inttoptr i64 %v3065 to ptr
  store i64 %v3064, ptr %p3066, align 8, !alias.scope !3, !noalias !4
  %v3067 = load i64, ptr %slot33, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  store i64 1, ptr %p3068, align 8, !alias.scope !3, !noalias !4
  %v3069 = load i64, ptr %slot33, align 8
  %p3070 = inttoptr i64 %v3069 to ptr
  %ld3071 = load i64, ptr %p3070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3071, ptr %slot528, align 8
  %v3072 = load i64, ptr %slot32, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  %ld3074 = load i64, ptr %p3073, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3074, ptr %slot529, align 8
  %v3075 = load i64, ptr %slot529, align 8
  %v3076 = load i64, ptr %slot528, align 8
  %ovpair3078 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3075, i64 %v3076)
  %op3077 = extractvalue { i64, i1 } %ovpair3078, 0
  %ov3079 = extractvalue { i64, i1 } %ovpair3078, 1
  store i64 %op3077, ptr %slot530, align 8
  %cv3080 = zext i1 %ov3079 to i64
  store i64 %cv3080, ptr %slot531, align 8
  %v3081 = load i64, ptr %slot531, align 8
  %cond3082 = icmp ne i64 %v3081, 0
  br i1 %cond3082, label %bb_overflow699, label %bb_checked699
bb_overflow699:
  %v3083 = load i64, ptr %slot1, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  %v3085 = load i64, ptr %slot529, align 8
  %v3086 = load i64, ptr %slot528, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3084, i64 0, i64 %v3085, i64 %v3086, i64 64) nomerge, !dbg !144
  unreachable
bb_checked699:
  %v3087 = load i64, ptr %slot530, align 8
  %v3088 = load i64, ptr %slot32, align 8
  %p3089 = inttoptr i64 %v3088 to ptr
  store i64 %v3087, ptr %p3089, align 8, !alias.scope !3, !noalias !4
  %v3090 = load i64, ptr %slot32, align 8
  %p3091 = inttoptr i64 %v3090 to ptr
  %ld3092 = load i64, ptr %p3091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3092, ptr %slot532, align 8
  %v3093 = load i64, ptr %slot532, align 8
  %v3094 = load i64, ptr %slot28, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  store i64 %v3093, ptr %p3095, align 8, !alias.scope !3, !noalias !4
  br label %bb_i20
bb_i45:
  %v3096 = load i64, ptr %slot24, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %ld3098 = load i64, ptr %p3097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3098, ptr %slot533, align 8
  %v3099 = load i64, ptr %slot533, align 8
  %v3100 = load i64, ptr %slot32, align 8
  %p3101 = inttoptr i64 %v3100 to ptr
  store i64 %v3099, ptr %p3101, align 8, !alias.scope !3, !noalias !4
  %v3102 = load i64, ptr %slot26, align 8
  %v3103 = load i64, ptr %slot33, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  store i64 %v3102, ptr %p3104, align 8, !alias.scope !3, !noalias !4
  %v3105 = load i64, ptr %slot33, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  %ld3107 = load i64, ptr %p3106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3107, ptr %slot534, align 8
  %v3108 = load i64, ptr %slot534, align 8
  %op3109 = add i64 %v3108, 48
  store i64 %op3109, ptr %slot535, align 8
  %v3110 = load i64, ptr %slot535, align 8
  %p3111 = inttoptr i64 %v3110 to ptr
  %ld3112 = load i64, ptr %p3111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3112, ptr %slot536, align 8
  %v3113 = load i64, ptr %slot536, align 8
  %v3114 = load i64, ptr %slot33, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  store i64 %v3113, ptr %p3115, align 8, !alias.scope !3, !noalias !4
  %v3116 = load i64, ptr %slot33, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  %ld3118 = load i64, ptr %p3117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3118, ptr %slot537, align 8
  %v3119 = load i64, ptr %slot537, align 8
  %v3120 = load i64, ptr %slot22, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i64 %v3119, ptr %p3121, align 8, !alias.scope !3, !noalias !4
  %v3122 = load i64, ptr %slot22, align 8
  store i64 %v3122, ptr %slot538, align 8
  %v3123 = load i64, ptr %slot23, align 8
  store i64 %v3123, ptr %slot539, align 8
  %v3124 = load i64, ptr %slot538, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  %ld3126 = load i64, ptr %p3125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3126, ptr %slot540, align 8
  %v3127 = load i64, ptr %slot540, align 8
  %cmp3128 = icmp ne i64 %v3127, 0
  %cv3129 = zext i1 %cmp3128 to i32
  store i32 %cv3129, ptr %slot541, align 8
  %v3130 = load i32, ptr %slot541, align 8
  %cv3131 = zext i32 %v3130 to i64
  %cond3132 = icmp ne i64 %cv3131, 0
  br i1 %cond3132, label %bb_rcgnn710, label %bb_rcgstore710
bb_rcgnn710:
  %v3133 = load i64, ptr %slot540, align 8
  %op3134 = sub i64 %v3133, 16
  store i64 %op3134, ptr %slot542, align 8
  %v3135 = load i64, ptr %slot540, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  %rgep3137 = getelementptr i8, ptr %p3136, i64 -16
  %ld3138 = load i64, ptr %rgep3137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3138, ptr %slot543, align 8
  %v3139 = load i64, ptr %slot543, align 8
  %op3140 = and i64 %v3139, 4611686018427387906
  store i64 %op3140, ptr %slot544, align 8
  %v3141 = load i64, ptr %slot544, align 8
  %cmp3142 = icmp ne i64 %v3141, 0
  %cv3143 = zext i1 %cmp3142 to i32
  store i32 %cv3143, ptr %slot545, align 8
  %v3144 = load i32, ptr %slot545, align 8
  %cv3145 = zext i32 %v3144 to i64
  %cond3146 = icmp ne i64 %cv3145, 0
  br i1 %cond3146, label %bb_rcgstore710, label %bb_rcginc710
bb_rcginc710:
  %v3147 = load i64, ptr %slot540, align 8
  %op3148 = sub i64 %v3147, 24
  store i64 %op3148, ptr %slot546, align 8
  %v3149 = load i64, ptr %slot540, align 8
  %p3150 = inttoptr i64 %v3149 to ptr
  %rgep3151 = getelementptr i8, ptr %p3150, i64 -24
  %ld3152 = load i64, ptr %rgep3151, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3152, ptr %slot547, align 8
  %v3153 = load i64, ptr %slot547, align 8
  %op3154 = add i64 %v3153, 1
  store i64 %op3154, ptr %slot548, align 8
  %v3155 = load i64, ptr %slot548, align 8
  %cmp3156 = icmp eq i64 %v3155, 0
  %cv3157 = zext i1 %cmp3156 to i32
  store i32 %cv3157, ptr %slot549, align 8
  %v3158 = load i32, ptr %slot549, align 8
  %cv3159 = zext i32 %v3158 to i64
  %cond3160 = icmp ne i64 %cv3159, 0
  br i1 %cond3160, label %bb_rcglimit710, label %bb_rcgcapacity710
bb_rcglimit710:
  %v3161 = load i64, ptr %slot1, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  %call3163 = call i32 @myl_qbe_rc_status(ptr %p3162, i32 2) nomerge, !dbg !146
  store i32 %call3163, ptr %slot550, align 8
  br label %bb_failure
bb_rcgcapacity710:
  %v3164 = load i64, ptr %slot548, align 8
  %v3165 = load i64, ptr %slot540, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %rgep3167 = getelementptr i8, ptr %p3166, i64 -24
  store i64 %v3164, ptr %rgep3167, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore710
bb_rcgstore710:
  %v3168 = load i64, ptr %slot540, align 8
  %v3169 = load i64, ptr %slot539, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  store i64 %v3168, ptr %p3170, align 8, !alias.scope !3, !noalias !4
  %v3171 = load i64, ptr %slot17, align 8
  %p3172 = inttoptr i64 %v3171 to ptr
  store i32 2, ptr %p3172, align 4, !alias.scope !3, !noalias !4
  %v3173 = load i64, ptr %slot17, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  store i32 16, ptr %p3174, align 4, !alias.scope !3, !noalias !4
  %v3175 = load i64, ptr %slot16, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  store i32 1, ptr %p3176, align 4, !alias.scope !3, !noalias !4
  %v3177 = load i64, ptr %slot14, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %ld3179 = load i32, ptr %p3178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3179, ptr %slot551, align 8
  %v3180 = load i32, ptr %slot551, align 8
  %cv3181 = zext i32 %v3180 to i64
  %cond3182 = icmp ne i64 %cv3181, 0
  br i1 %cond3182, label %bb_rcslotdrop726, label %bb_rcslotdone726
bb_rcslotdrop726:
  %v3183 = load i64, ptr %slot14, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  store i32 0, ptr %p3184, align 4, !alias.scope !3, !noalias !4
  %v3185 = load i64, ptr %slot20, align 8
  store i64 %v3185, ptr %slot552, align 8
  %v3186 = load i64, ptr %slot15, align 8
  %p3187 = inttoptr i64 %v3186 to ptr
  %ld3188 = load i32, ptr %p3187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3188, ptr %slot553, align 8
  %v3189 = load i32, ptr %slot553, align 8
  %op3190 = and i32 %v3189, 28
  store i32 %op3190, ptr %slot554, align 8
  %v3191 = load i32, ptr %slot554, align 8
  %cv3192 = zext i32 %v3191 to i64
  %cond3193 = icmp ne i64 %cv3192, 0
  br i1 %cond3193, label %bb_rcslotrole726, label %bb_rcslotowner726
bb_rcslotrole726:
  %v3194 = load i64, ptr %slot41, align 8
  store i64 %v3194, ptr %slot555, align 8
  %v3195 = load i64, ptr %slot555, align 8
  %v3196 = load i64, ptr %slot552, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v3195, i64 %v3196) nomerge, !dbg !146
  br label %bb_rcslotdone726
bb_rcslotowner726:
  %v3197 = load i64, ptr %slot41, align 8
  store i64 %v3197, ptr %slot556, align 8
  %v3198 = load i64, ptr %slot556, align 8
  %v3199 = load i64, ptr %slot552, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v3198, i64 %v3199) nomerge, !dbg !146
  br label %bb_rcslotdone726
bb_rcslotdone726:
  %v3200 = load i64, ptr %slot20, align 8
  store i64 %v3200, ptr %slot557, align 8
  %v3201 = load i64, ptr %slot23, align 8
  store i64 %v3201, ptr %slot558, align 8
  %v3202 = load i64, ptr %slot558, align 8
  %v3203 = load i64, ptr %slot557, align 8
  %p3204 = inttoptr i64 %v3202 to ptr
  %p3205 = inttoptr i64 %v3203 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3205, ptr %p3204, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3206 = load i64, ptr %slot15, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  store i32 2, ptr %p3207, align 4, !alias.scope !3, !noalias !4
  %v3208 = load i64, ptr %slot17, align 8
  %p3209 = inttoptr i64 %v3208 to ptr
  %ld3210 = load i32, ptr %p3209, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3210, ptr %slot559, align 8
  %v3211 = load i32, ptr %slot559, align 8
  %v3212 = load i64, ptr %slot15, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  store i32 %v3211, ptr %p3213, align 4, !alias.scope !3, !noalias !4
  %v3214 = load i64, ptr %slot16, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  store i32 0, ptr %p3215, align 4, !alias.scope !3, !noalias !4
  %v3216 = load i64, ptr %slot14, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  store i32 1, ptr %p3217, align 4, !alias.scope !3, !noalias !4
  %v3218 = load i64, ptr %slot557, align 8
  %p3219 = inttoptr i64 %v3218 to ptr
  %ld3220 = load i64, ptr %p3219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3220, ptr %slot560, align 8
  %v3221 = load i64, ptr %slot560, align 8
  %v3222 = load i64, ptr %slot33, align 8
  %p3223 = inttoptr i64 %v3222 to ptr
  store i64 %v3221, ptr %p3223, align 8, !alias.scope !3, !noalias !4
  %v3224 = load i64, ptr %slot15, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  %ld3226 = load i32, ptr %p3225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3226, ptr %slot561, align 8
  %v3227 = load i32, ptr %slot561, align 8
  %cmp3228 = icmp eq i32 %v3227, 8
  %cv3229 = zext i1 %cmp3228 to i32
  store i32 %cv3229, ptr %slot562, align 8
  %v3230 = load i64, ptr %slot14, align 8
  %p3231 = inttoptr i64 %v3230 to ptr
  %ld3232 = load i32, ptr %p3231, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3232, ptr %slot563, align 8
  %v3233 = load i32, ptr %slot562, align 8
  %v3234 = load i32, ptr %slot563, align 8
  %op3235 = and i32 %v3233, %v3234
  store i32 %op3235, ptr %slot564, align 8
  %v3236 = load i32, ptr %slot564, align 8
  %cv3237 = zext i32 %v3236 to i64
  %cond3238 = icmp ne i64 %cv3237, 0
  br i1 %cond3238, label %bb_rchold742, label %bb_rcordinary742
bb_rchold742:
  %v3239 = load i64, ptr %slot23, align 8
  store i64 %v3239, ptr %slot565, align 8
  %v3240 = load i64, ptr %slot33, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  %ld3242 = load i64, ptr %p3241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3242, ptr %slot566, align 8
  %v3243 = load i64, ptr %slot566, align 8
  %v3244 = load i64, ptr %slot565, align 8
  %p3245 = inttoptr i64 %v3244 to ptr
  store i64 %v3243, ptr %p3245, align 8, !alias.scope !3, !noalias !4
  %v3246 = load i64, ptr %slot17, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  store i32 2, ptr %p3247, align 4, !alias.scope !3, !noalias !4
  %v3248 = load i64, ptr %slot17, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  store i32 8, ptr %p3249, align 4, !alias.scope !3, !noalias !4
  %v3250 = load i64, ptr %slot16, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  store i32 1, ptr %p3251, align 4, !alias.scope !3, !noalias !4
  %v3252 = load i64, ptr %slot14, align 8
  %p3253 = inttoptr i64 %v3252 to ptr
  store i32 0, ptr %p3253, align 4, !alias.scope !3, !noalias !4
  %v3254 = load i64, ptr %slot10, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  %ld3256 = load i32, ptr %p3255, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3256, ptr %slot567, align 8
  %v3257 = load i32, ptr %slot567, align 8
  %cv3258 = zext i32 %v3257 to i64
  %cond3259 = icmp ne i64 %cv3258, 0
  br i1 %cond3259, label %bb_rcslotdrop757, label %bb_rcslotdone757
bb_rcslotdrop757:
  %v3260 = load i64, ptr %slot10, align 8
  %p3261 = inttoptr i64 %v3260 to ptr
  store i32 0, ptr %p3261, align 4, !alias.scope !3, !noalias !4
  %v3262 = load i64, ptr %slot31, align 8
  store i64 %v3262, ptr %slot568, align 8
  %v3263 = load i64, ptr %slot11, align 8
  %p3264 = inttoptr i64 %v3263 to ptr
  %ld3265 = load i32, ptr %p3264, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3265, ptr %slot569, align 8
  %v3266 = load i32, ptr %slot569, align 8
  %op3267 = and i32 %v3266, 28
  store i32 %op3267, ptr %slot570, align 8
  %v3268 = load i32, ptr %slot570, align 8
  %cv3269 = zext i32 %v3268 to i64
  %cond3270 = icmp ne i64 %cv3269, 0
  br i1 %cond3270, label %bb_rcslotrole757, label %bb_rcslotowner757
bb_rcslotrole757:
  %v3271 = load i64, ptr %slot41, align 8
  store i64 %v3271, ptr %slot571, align 8
  %v3272 = load i64, ptr %slot568, align 8
  %p3273 = inttoptr i64 %v3272 to ptr
  %ld3274 = load i64, ptr %p3273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3274, ptr %slot572, align 8
  %v3275 = load i64, ptr %slot572, align 8
  %cmp3276 = icmp ne i64 %v3275, 0
  %cv3277 = zext i1 %cmp3276 to i32
  store i32 %cv3277, ptr %slot573, align 8
  %v3278 = load i32, ptr %slot573, align 8
  %cv3279 = zext i32 %v3278 to i64
  %cond3280 = icmp ne i64 %cv3279, 0
  br i1 %cond3280, label %bb_rcgnn773, label %bb_rcgdone773
bb_rcgnn773:
  %v3281 = load i64, ptr %slot572, align 8
  %op3282 = sub i64 %v3281, 16
  store i64 %op3282, ptr %slot574, align 8
  %v3283 = load i64, ptr %slot572, align 8
  %p3284 = inttoptr i64 %v3283 to ptr
  %rgep3285 = getelementptr i8, ptr %p3284, i64 -16
  %ld3286 = load i64, ptr %rgep3285, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3286, ptr %slot575, align 8
  %v3287 = load i64, ptr %slot575, align 8
  %op3288 = and i64 %v3287, 4611686018427387906
  store i64 %op3288, ptr %slot576, align 8
  %v3289 = load i64, ptr %slot576, align 8
  %cmp3290 = icmp ne i64 %v3289, 0
  %cv3291 = zext i1 %cmp3290 to i32
  store i32 %cv3291, ptr %slot577, align 8
  %v3292 = load i32, ptr %slot577, align 8
  %cv3293 = zext i32 %v3292 to i64
  %cond3294 = icmp ne i64 %cv3293, 0
  br i1 %cond3294, label %bb_rcgclear773, label %bb_rcgcounted773
bb_rcgcounted773:
  %v3295 = load i64, ptr %slot572, align 8
  %op3296 = sub i64 %v3295, 24
  store i64 %op3296, ptr %slot578, align 8
  %v3297 = load i64, ptr %slot572, align 8
  %p3298 = inttoptr i64 %v3297 to ptr
  %rgep3299 = getelementptr i8, ptr %p3298, i64 -24
  %ld3300 = load i64, ptr %rgep3299, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3300, ptr %slot579, align 8
  %v3301 = load i64, ptr %slot579, align 8
  %op3302 = sub i64 %v3301, 1
  store i64 %op3302, ptr %slot580, align 8
  %v3303 = load i64, ptr %slot580, align 8
  %cmp3304 = icmp eq i64 %v3303, 0
  %cv3305 = zext i1 %cmp3304 to i32
  store i32 %cv3305, ptr %slot581, align 8
  %v3306 = load i32, ptr %slot581, align 8
  %cv3307 = zext i32 %v3306 to i64
  %cond3308 = icmp ne i64 %cv3307, 0
  br i1 %cond3308, label %bb_rcglast773, label %bb_rcgdec773
bb_rcglast773:
  %v3309 = load i64, ptr %slot572, align 8
  %op3310 = sub i64 %v3309, 32
  store i64 %op3310, ptr %slot582, align 8
  %v3311 = load i64, ptr %slot572, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  %rgep3313 = getelementptr i8, ptr %p3312, i64 -32
  %ld3314 = load i64, ptr %rgep3313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3314, ptr %slot583, align 8
  %v3315 = load i64, ptr %slot583, align 8
  %cmp3316 = icmp ne i64 %v3315, 0
  %cv3317 = zext i1 %cmp3316 to i32
  store i32 %cv3317, ptr %slot584, align 8
  %v3318 = load i32, ptr %slot584, align 8
  %cv3319 = zext i32 %v3318 to i64
  %cond3320 = icmp ne i64 %cv3319, 0
  br i1 %cond3320, label %bb_rcgdec773, label %bb_rcgslow773
bb_rcgslow773:
  %v3321 = load i64, ptr %slot571, align 8
  %v3322 = load i64, ptr %slot568, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3321, i64 %v3322) nomerge, !dbg !148
  br label %bb_rcgdone773
bb_rcgdec773:
  %v3323 = load i64, ptr %slot580, align 8
  %v3324 = load i64, ptr %slot572, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %rgep3326 = getelementptr i8, ptr %p3325, i64 -24
  store i64 %v3323, ptr %rgep3326, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear773
bb_rcgclear773:
  %v3327 = load i64, ptr %slot568, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  store i64 0, ptr %p3328, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone773
bb_rcgdone773:
  br label %bb_rcslotdone757
bb_rcslotowner757:
  %v3329 = load i64, ptr %slot41, align 8
  store i64 %v3329, ptr %slot585, align 8
  %v3330 = load i64, ptr %slot568, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  %ld3332 = load i64, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3332, ptr %slot586, align 8
  %v3333 = load i64, ptr %slot586, align 8
  %cmp3334 = icmp ne i64 %v3333, 0
  %cv3335 = zext i1 %cmp3334 to i32
  store i32 %cv3335, ptr %slot587, align 8
  %v3336 = load i32, ptr %slot587, align 8
  %cv3337 = zext i32 %v3336 to i64
  %cond3338 = icmp ne i64 %cv3337, 0
  br i1 %cond3338, label %bb_rcgnn788, label %bb_rcgdone788
bb_rcgnn788:
  %v3339 = load i64, ptr %slot586, align 8
  %op3340 = sub i64 %v3339, 16
  store i64 %op3340, ptr %slot588, align 8
  %v3341 = load i64, ptr %slot586, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %rgep3343 = getelementptr i8, ptr %p3342, i64 -16
  %ld3344 = load i64, ptr %rgep3343, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3344, ptr %slot589, align 8
  %v3345 = load i64, ptr %slot589, align 8
  %op3346 = and i64 %v3345, 4611686018427387906
  store i64 %op3346, ptr %slot590, align 8
  %v3347 = load i64, ptr %slot590, align 8
  %cmp3348 = icmp ne i64 %v3347, 0
  %cv3349 = zext i1 %cmp3348 to i32
  store i32 %cv3349, ptr %slot591, align 8
  %v3350 = load i32, ptr %slot591, align 8
  %cv3351 = zext i32 %v3350 to i64
  %cond3352 = icmp ne i64 %cv3351, 0
  br i1 %cond3352, label %bb_rcgclear788, label %bb_rcgcounted788
bb_rcgcounted788:
  %v3353 = load i64, ptr %slot586, align 8
  %op3354 = sub i64 %v3353, 32
  store i64 %op3354, ptr %slot592, align 8
  %v3355 = load i64, ptr %slot586, align 8
  %p3356 = inttoptr i64 %v3355 to ptr
  %rgep3357 = getelementptr i8, ptr %p3356, i64 -32
  %ld3358 = load i64, ptr %rgep3357, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3358, ptr %slot593, align 8
  %v3359 = load i64, ptr %slot593, align 8
  %op3360 = sub i64 %v3359, 1
  store i64 %op3360, ptr %slot594, align 8
  %v3361 = load i64, ptr %slot594, align 8
  %cmp3362 = icmp eq i64 %v3361, 0
  %cv3363 = zext i1 %cmp3362 to i32
  store i32 %cv3363, ptr %slot595, align 8
  %v3364 = load i32, ptr %slot595, align 8
  %cv3365 = zext i32 %v3364 to i64
  %cond3366 = icmp ne i64 %cv3365, 0
  br i1 %cond3366, label %bb_rcglast788, label %bb_rcgdec788
bb_rcglast788:
  %v3367 = load i64, ptr %slot586, align 8
  %op3368 = sub i64 %v3367, 24
  store i64 %op3368, ptr %slot596, align 8
  %v3369 = load i64, ptr %slot586, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %rgep3371 = getelementptr i8, ptr %p3370, i64 -24
  %ld3372 = load i64, ptr %rgep3371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3372, ptr %slot597, align 8
  %v3373 = load i64, ptr %slot597, align 8
  %cmp3374 = icmp ne i64 %v3373, 0
  %cv3375 = zext i1 %cmp3374 to i32
  store i32 %cv3375, ptr %slot598, align 8
  %v3376 = load i32, ptr %slot598, align 8
  %cv3377 = zext i32 %v3376 to i64
  %cond3378 = icmp ne i64 %cv3377, 0
  br i1 %cond3378, label %bb_rcgdec788, label %bb_rcgslow788
bb_rcgslow788:
  %v3379 = load i64, ptr %slot585, align 8
  %v3380 = load i64, ptr %slot568, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3379, i64 %v3380) nomerge, !dbg !148
  br label %bb_rcgdone788
bb_rcgdec788:
  %v3381 = load i64, ptr %slot594, align 8
  %v3382 = load i64, ptr %slot586, align 8
  %p3383 = inttoptr i64 %v3382 to ptr
  %rgep3384 = getelementptr i8, ptr %p3383, i64 -32
  store i64 %v3381, ptr %rgep3384, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear788
bb_rcgclear788:
  %v3385 = load i64, ptr %slot568, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  store i64 0, ptr %p3386, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone788
bb_rcgdone788:
  br label %bb_rcslotdone757
bb_rcslotdone757:
  %v3387 = load i64, ptr %slot31, align 8
  store i64 %v3387, ptr %slot599, align 8
  %v3388 = load i64, ptr %slot565, align 8
  %p3389 = inttoptr i64 %v3388 to ptr
  %ld3390 = load i64, ptr %p3389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3390, ptr %slot600, align 8
  %v3391 = load i64, ptr %slot600, align 8
  %v3392 = load i64, ptr %slot599, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  store i64 %v3391, ptr %p3393, align 8, !alias.scope !3, !noalias !4
  %v3394 = load i64, ptr %slot11, align 8
  %p3395 = inttoptr i64 %v3394 to ptr
  store i32 2, ptr %p3395, align 4, !alias.scope !3, !noalias !4
  %v3396 = load i64, ptr %slot11, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  store i32 8, ptr %p3397, align 4, !alias.scope !3, !noalias !4
  %v3398 = load i64, ptr %slot10, align 8
  %p3399 = inttoptr i64 %v3398 to ptr
  store i32 1, ptr %p3399, align 4, !alias.scope !3, !noalias !4
  %v3400 = load i64, ptr %slot16, align 8
  %p3401 = inttoptr i64 %v3400 to ptr
  store i32 0, ptr %p3401, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined742
bb_rcordinary742:
  %v3402 = load i64, ptr %slot33, align 8
  %p3403 = inttoptr i64 %v3402 to ptr
  %ld3404 = load i64, ptr %p3403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3404, ptr %slot601, align 8
  %v3405 = load i64, ptr %slot601, align 8
  %v3406 = load i64, ptr %slot22, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  store i64 %v3405, ptr %p3407, align 8, !alias.scope !3, !noalias !4
  %v3408 = load i64, ptr %slot22, align 8
  store i64 %v3408, ptr %slot602, align 8
  %v3409 = load i64, ptr %slot14, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  %ld3411 = load i32, ptr %p3410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3411, ptr %slot603, align 8
  %v3412 = load i64, ptr %slot15, align 8
  %p3413 = inttoptr i64 %v3412 to ptr
  %ld3414 = load i32, ptr %p3413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3414, ptr %slot604, align 8
  %v3415 = load i32, ptr %slot604, align 8
  %op3416 = and i32 %v3415, 24
  store i32 %op3416, ptr %slot604, align 8
  %v3417 = load i32, ptr %slot604, align 8
  %cmp3418 = icmp eq i32 %v3417, 0
  %cv3419 = zext i1 %cmp3418 to i32
  store i32 %cv3419, ptr %slot605, align 8
  %v3420 = load i32, ptr %slot603, align 8
  %v3421 = load i32, ptr %slot605, align 8
  %op3422 = and i32 %v3420, %v3421
  store i32 %op3422, ptr %slot606, align 8
  %v3423 = load i32, ptr %slot606, align 8
  %cv3424 = zext i32 %v3423 to i64
  %cond3425 = icmp ne i64 %cv3424, 0
  br i1 %cond3425, label %bb_rcprivateown806, label %bb_rcprivateloan806
bb_rcprivateown806:
  %v3426 = load i64, ptr %slot23, align 8
  store i64 %v3426, ptr %slot607, align 8
  %v3427 = load i64, ptr %slot42, align 8
  store i64 %v3427, ptr %slot608, align 8
  %v3428 = load i64, ptr %slot602, align 8
  %v3429 = load i64, ptr %slot607, align 8
  %op3430 = sub i64 %v3428, %v3429
  store i64 %op3430, ptr %slot609, align 8
  %v3431 = load i64, ptr %slot607, align 8
  %v3432 = load i64, ptr %slot602, align 8
  %op3433 = sub i64 %v3431, %v3432
  store i64 %op3433, ptr %slot610, align 8
  %v3434 = load i64, ptr %slot609, align 8
  %cmp3435 = icmp ult i64 %v3434, 8
  %cv3436 = zext i1 %cmp3435 to i32
  store i32 %cv3436, ptr %slot611, align 8
  %v3437 = load i64, ptr %slot610, align 8
  %cmp3438 = icmp ult i64 %v3437, 8
  %cv3439 = zext i1 %cmp3438 to i32
  store i32 %cv3439, ptr %slot612, align 8
  %v3440 = load i32, ptr %slot611, align 8
  %v3441 = load i32, ptr %slot612, align 8
  %op3442 = or i32 %v3440, %v3441
  store i32 %op3442, ptr %slot613, align 8
  %v3443 = load i32, ptr %slot613, align 8
  %cv3444 = zext i32 %v3443 to i64
  %cond3445 = icmp ne i64 %cv3444, 0
  br i1 %cond3445, label %bb_rcmoveslow809, label %bb_rcmovecheck809
bb_rcmovecheck809:
  %v3446 = load i64, ptr %slot602, align 8
  %p3448 = inttoptr i64 %v3446 to ptr
  %gep3449 = getelementptr i8, ptr %p3448, i64 0
  %op3447 = ptrtoint ptr %gep3449 to i64
  store i64 %op3447, ptr %slot614, align 8
  %v3450 = load i64, ptr %slot614, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %ld3452 = load i64, ptr %p3451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3452, ptr %slot615, align 8
  %v3453 = load i64, ptr %slot615, align 8
  %cmp3454 = icmp ne i64 %v3453, 0
  %cv3455 = zext i1 %cmp3454 to i32
  store i32 %cv3455, ptr %slot616, align 8
  %v3456 = load i32, ptr %slot616, align 8
  %cv3457 = zext i32 %v3456 to i64
  %cond3458 = icmp ne i64 %cv3457, 0
  br i1 %cond3458, label %bb_rcmoveheader817, label %bb_rcmovenext817
bb_rcmoveheader817:
  %v3459 = load i64, ptr %slot615, align 8
  %op3460 = sub i64 %v3459, 16
  store i64 %op3460, ptr %slot617, align 8
  %v3461 = load i64, ptr %slot615, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  %rgep3463 = getelementptr i8, ptr %p3462, i64 -16
  %ld3464 = load i64, ptr %rgep3463, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3464, ptr %slot618, align 8
  %v3465 = load i64, ptr %slot618, align 8
  %op3466 = and i64 %v3465, 5764607523034234881
  store i64 %op3466, ptr %slot619, align 8
  %v3467 = load i64, ptr %slot619, align 8
  %cmp3468 = icmp ne i64 %v3467, 0
  %cv3469 = zext i1 %cmp3468 to i32
  store i32 %cv3469, ptr %slot620, align 8
  %v3470 = load i32, ptr %slot620, align 8
  %cv3471 = zext i32 %v3470 to i64
  %cond3472 = icmp ne i64 %cv3471, 0
  br i1 %cond3472, label %bb_rcmoveslow809, label %bb_rcmovenext817
bb_rcmovenext817:
  %v3473 = load i64, ptr %slot602, align 8
  %v3474 = load i64, ptr %slot607, align 8
  %p3475 = inttoptr i64 %v3473 to ptr
  %p3476 = inttoptr i64 %v3474 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3476, ptr %p3475, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3477 = load i64, ptr %slot602, align 8
  %p3478 = inttoptr i64 %v3477 to ptr
  store i64 0, ptr %p3478, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved809
bb_rcmoveslow809:
  %v3479 = load i64, ptr %slot41, align 8
  %v3480 = load i64, ptr %slot607, align 8
  %v3481 = load i64, ptr %slot602, align 8
  %v3482 = load i64, ptr %slot608, align 8
  %cv3483 = trunc i64 %v3482 to i32
  %call3484 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v3479, i64 %v3480, i64 %v3481, i32 %cv3483) nomerge, !dbg !148
  store i32 %call3484, ptr %slot621, align 8
  %v3485 = load i32, ptr %slot621, align 8
  %cv3486 = zext i32 %v3485 to i64
  %cond3487 = icmp ne i64 %cv3486, 0
  br i1 %cond3487, label %bb_rcsuccess824, label %bb_rcfailure824
bb_rcfailure824:
  %v3488 = load i64, ptr %slot41, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %call3490 = call i32 @myl_rc_take_failure(ptr %p3489) nomerge, !dbg !148
  store i32 %call3490, ptr %slot622, align 8
  %v3491 = load i64, ptr %slot1, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %v3493 = load i32, ptr %slot622, align 8
  %call3494 = call i32 @myl_qbe_rc_status(ptr %p3492, i32 %v3493) nomerge, !dbg !148
  store i32 %call3494, ptr %slot623, align 8
  br label %bb_failure
bb_rcsuccess824:
  br label %bb_rcmoved809
bb_rcmoved809:
  %v3495 = load i64, ptr %slot14, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  store i32 0, ptr %p3496, align 4, !alias.scope !3, !noalias !4
  %v3497 = load i64, ptr %slot17, align 8
  %p3498 = inttoptr i64 %v3497 to ptr
  store i32 2, ptr %p3498, align 4, !alias.scope !3, !noalias !4
  %v3499 = load i64, ptr %slot16, align 8
  %p3500 = inttoptr i64 %v3499 to ptr
  store i32 1, ptr %p3500, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared806
bb_rcprivateloan806:
  %v3501 = load i64, ptr %slot14, align 8
  %p3502 = inttoptr i64 %v3501 to ptr
  %ld3503 = load i32, ptr %p3502, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3503, ptr %slot624, align 8
  %v3504 = load i64, ptr %slot15, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  %ld3506 = load i32, ptr %p3505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3506, ptr %slot625, align 8
  %v3507 = load i32, ptr %slot625, align 8
  %cmp3508 = icmp eq i32 %v3507, 16
  %cv3509 = zext i1 %cmp3508 to i32
  store i32 %cv3509, ptr %slot626, align 8
  %v3510 = load i32, ptr %slot626, align 8
  %v3511 = load i32, ptr %slot624, align 8
  %op3512 = and i32 %v3510, %v3511
  store i32 %op3512, ptr %slot626, align 8
  %v3513 = load i32, ptr %slot626, align 8
  %cv3514 = zext i32 %v3513 to i64
  %cond3515 = icmp ne i64 %cv3514, 0
  br i1 %cond3515, label %bb_rcprivatemove806, label %bb_rcprivatenew806
bb_rcprivatemove806:
  %v3516 = load i64, ptr %slot23, align 8
  store i64 %v3516, ptr %slot627, align 8
  %v3517 = load i64, ptr %slot602, align 8
  %v3518 = load i64, ptr %slot627, align 8
  %p3519 = inttoptr i64 %v3517 to ptr
  %p3520 = inttoptr i64 %v3518 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3520, ptr %p3519, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3521 = load i64, ptr %slot602, align 8
  %p3522 = inttoptr i64 %v3521 to ptr
  store i64 0, ptr %p3522, align 8, !alias.scope !3, !noalias !4
  %v3523 = load i64, ptr %slot17, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  store i32 2, ptr %p3524, align 4, !alias.scope !3, !noalias !4
  %v3525 = load i64, ptr %slot17, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  store i32 16, ptr %p3526, align 4, !alias.scope !3, !noalias !4
  %v3527 = load i64, ptr %slot16, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  store i32 1, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  %v3529 = load i64, ptr %slot14, align 8
  %p3530 = inttoptr i64 %v3529 to ptr
  store i32 0, ptr %p3530, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared806
bb_rcprivatenew806:
  %v3531 = load i64, ptr %slot23, align 8
  store i64 %v3531, ptr %slot628, align 8
  %v3532 = load i64, ptr %slot602, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  %ld3534 = load i64, ptr %p3533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3534, ptr %slot629, align 8
  %v3535 = load i64, ptr %slot629, align 8
  %cmp3536 = icmp ne i64 %v3535, 0
  %cv3537 = zext i1 %cmp3536 to i32
  store i32 %cv3537, ptr %slot630, align 8
  %v3538 = load i32, ptr %slot630, align 8
  %cv3539 = zext i32 %v3538 to i64
  %cond3540 = icmp ne i64 %cv3539, 0
  br i1 %cond3540, label %bb_rcgnn842, label %bb_rcgstore842
bb_rcgnn842:
  %v3541 = load i64, ptr %slot629, align 8
  %op3542 = sub i64 %v3541, 16
  store i64 %op3542, ptr %slot631, align 8
  %v3543 = load i64, ptr %slot629, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  %rgep3545 = getelementptr i8, ptr %p3544, i64 -16
  %ld3546 = load i64, ptr %rgep3545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3546, ptr %slot632, align 8
  %v3547 = load i64, ptr %slot632, align 8
  %op3548 = and i64 %v3547, 4611686018427387906
  store i64 %op3548, ptr %slot633, align 8
  %v3549 = load i64, ptr %slot633, align 8
  %cmp3550 = icmp ne i64 %v3549, 0
  %cv3551 = zext i1 %cmp3550 to i32
  store i32 %cv3551, ptr %slot634, align 8
  %v3552 = load i32, ptr %slot634, align 8
  %cv3553 = zext i32 %v3552 to i64
  %cond3554 = icmp ne i64 %cv3553, 0
  br i1 %cond3554, label %bb_rcgstore842, label %bb_rcginc842
bb_rcginc842:
  %v3555 = load i64, ptr %slot629, align 8
  %op3556 = sub i64 %v3555, 24
  store i64 %op3556, ptr %slot635, align 8
  %v3557 = load i64, ptr %slot629, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  %rgep3559 = getelementptr i8, ptr %p3558, i64 -24
  %ld3560 = load i64, ptr %rgep3559, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3560, ptr %slot636, align 8
  %v3561 = load i64, ptr %slot636, align 8
  %op3562 = add i64 %v3561, 1
  store i64 %op3562, ptr %slot637, align 8
  %v3563 = load i64, ptr %slot637, align 8
  %cmp3564 = icmp eq i64 %v3563, 0
  %cv3565 = zext i1 %cmp3564 to i32
  store i32 %cv3565, ptr %slot638, align 8
  %v3566 = load i32, ptr %slot638, align 8
  %cv3567 = zext i32 %v3566 to i64
  %cond3568 = icmp ne i64 %cv3567, 0
  br i1 %cond3568, label %bb_rcglimit842, label %bb_rcgcapacity842
bb_rcglimit842:
  %v3569 = load i64, ptr %slot1, align 8
  %p3570 = inttoptr i64 %v3569 to ptr
  %call3571 = call i32 @myl_qbe_rc_status(ptr %p3570, i32 2) nomerge, !dbg !148
  store i32 %call3571, ptr %slot639, align 8
  br label %bb_failure
bb_rcgcapacity842:
  %v3572 = load i64, ptr %slot637, align 8
  %v3573 = load i64, ptr %slot629, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  %rgep3575 = getelementptr i8, ptr %p3574, i64 -24
  store i64 %v3572, ptr %rgep3575, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore842
bb_rcgstore842:
  %v3576 = load i64, ptr %slot629, align 8
  %v3577 = load i64, ptr %slot628, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  store i64 %v3576, ptr %p3578, align 8, !alias.scope !3, !noalias !4
  %v3579 = load i64, ptr %slot17, align 8
  %p3580 = inttoptr i64 %v3579 to ptr
  store i32 2, ptr %p3580, align 4, !alias.scope !3, !noalias !4
  %v3581 = load i64, ptr %slot17, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  store i32 16, ptr %p3582, align 4, !alias.scope !3, !noalias !4
  %v3583 = load i64, ptr %slot16, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  store i32 1, ptr %p3584, align 4, !alias.scope !3, !noalias !4
  %v3585 = load i64, ptr %slot14, align 8
  %p3586 = inttoptr i64 %v3585 to ptr
  %ld3587 = load i32, ptr %p3586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3587, ptr %slot640, align 8
  %v3588 = load i32, ptr %slot640, align 8
  %cv3589 = zext i32 %v3588 to i64
  %cond3590 = icmp ne i64 %cv3589, 0
  br i1 %cond3590, label %bb_rcslotdrop858, label %bb_rcslotdone858
bb_rcslotdrop858:
  %v3591 = load i64, ptr %slot14, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  store i32 0, ptr %p3592, align 4, !alias.scope !3, !noalias !4
  %v3593 = load i64, ptr %slot20, align 8
  store i64 %v3593, ptr %slot641, align 8
  %v3594 = load i64, ptr %slot15, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  %ld3596 = load i32, ptr %p3595, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3596, ptr %slot642, align 8
  %v3597 = load i32, ptr %slot642, align 8
  %op3598 = and i32 %v3597, 28
  store i32 %op3598, ptr %slot643, align 8
  %v3599 = load i32, ptr %slot643, align 8
  %cv3600 = zext i32 %v3599 to i64
  %cond3601 = icmp ne i64 %cv3600, 0
  br i1 %cond3601, label %bb_rcslotrole858, label %bb_rcslotowner858
bb_rcslotrole858:
  %v3602 = load i64, ptr %slot41, align 8
  store i64 %v3602, ptr %slot644, align 8
  %v3603 = load i64, ptr %slot641, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  %ld3605 = load i64, ptr %p3604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3605, ptr %slot645, align 8
  %v3606 = load i64, ptr %slot645, align 8
  %cmp3607 = icmp ne i64 %v3606, 0
  %cv3608 = zext i1 %cmp3607 to i32
  store i32 %cv3608, ptr %slot646, align 8
  %v3609 = load i32, ptr %slot646, align 8
  %cv3610 = zext i32 %v3609 to i64
  %cond3611 = icmp ne i64 %cv3610, 0
  br i1 %cond3611, label %bb_rcgnn874, label %bb_rcgdone874
bb_rcgnn874:
  %v3612 = load i64, ptr %slot645, align 8
  %op3613 = sub i64 %v3612, 16
  store i64 %op3613, ptr %slot647, align 8
  %v3614 = load i64, ptr %slot645, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  %rgep3616 = getelementptr i8, ptr %p3615, i64 -16
  %ld3617 = load i64, ptr %rgep3616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3617, ptr %slot648, align 8
  %v3618 = load i64, ptr %slot648, align 8
  %op3619 = and i64 %v3618, 4611686018427387906
  store i64 %op3619, ptr %slot649, align 8
  %v3620 = load i64, ptr %slot649, align 8
  %cmp3621 = icmp ne i64 %v3620, 0
  %cv3622 = zext i1 %cmp3621 to i32
  store i32 %cv3622, ptr %slot650, align 8
  %v3623 = load i32, ptr %slot650, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcgclear874, label %bb_rcgcounted874
bb_rcgcounted874:
  %v3626 = load i64, ptr %slot645, align 8
  %op3627 = sub i64 %v3626, 24
  store i64 %op3627, ptr %slot651, align 8
  %v3628 = load i64, ptr %slot645, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  %rgep3630 = getelementptr i8, ptr %p3629, i64 -24
  %ld3631 = load i64, ptr %rgep3630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3631, ptr %slot652, align 8
  %v3632 = load i64, ptr %slot652, align 8
  %op3633 = sub i64 %v3632, 1
  store i64 %op3633, ptr %slot653, align 8
  %v3634 = load i64, ptr %slot653, align 8
  %cmp3635 = icmp eq i64 %v3634, 0
  %cv3636 = zext i1 %cmp3635 to i32
  store i32 %cv3636, ptr %slot654, align 8
  %v3637 = load i32, ptr %slot654, align 8
  %cv3638 = zext i32 %v3637 to i64
  %cond3639 = icmp ne i64 %cv3638, 0
  br i1 %cond3639, label %bb_rcglast874, label %bb_rcgdec874
bb_rcglast874:
  %v3640 = load i64, ptr %slot645, align 8
  %op3641 = sub i64 %v3640, 32
  store i64 %op3641, ptr %slot655, align 8
  %v3642 = load i64, ptr %slot645, align 8
  %p3643 = inttoptr i64 %v3642 to ptr
  %rgep3644 = getelementptr i8, ptr %p3643, i64 -32
  %ld3645 = load i64, ptr %rgep3644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3645, ptr %slot656, align 8
  %v3646 = load i64, ptr %slot656, align 8
  %cmp3647 = icmp ne i64 %v3646, 0
  %cv3648 = zext i1 %cmp3647 to i32
  store i32 %cv3648, ptr %slot657, align 8
  %v3649 = load i32, ptr %slot657, align 8
  %cv3650 = zext i32 %v3649 to i64
  %cond3651 = icmp ne i64 %cv3650, 0
  br i1 %cond3651, label %bb_rcgdec874, label %bb_rcgslow874
bb_rcgslow874:
  %v3652 = load i64, ptr %slot644, align 8
  %v3653 = load i64, ptr %slot641, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3652, i64 %v3653) nomerge, !dbg !148
  br label %bb_rcgdone874
bb_rcgdec874:
  %v3654 = load i64, ptr %slot653, align 8
  %v3655 = load i64, ptr %slot645, align 8
  %p3656 = inttoptr i64 %v3655 to ptr
  %rgep3657 = getelementptr i8, ptr %p3656, i64 -24
  store i64 %v3654, ptr %rgep3657, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear874
bb_rcgclear874:
  %v3658 = load i64, ptr %slot641, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  store i64 0, ptr %p3659, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone874
bb_rcgdone874:
  br label %bb_rcslotdone858
bb_rcslotowner858:
  %v3660 = load i64, ptr %slot41, align 8
  store i64 %v3660, ptr %slot658, align 8
  %v3661 = load i64, ptr %slot641, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %ld3663 = load i64, ptr %p3662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3663, ptr %slot659, align 8
  %v3664 = load i64, ptr %slot659, align 8
  %cmp3665 = icmp ne i64 %v3664, 0
  %cv3666 = zext i1 %cmp3665 to i32
  store i32 %cv3666, ptr %slot660, align 8
  %v3667 = load i32, ptr %slot660, align 8
  %cv3668 = zext i32 %v3667 to i64
  %cond3669 = icmp ne i64 %cv3668, 0
  br i1 %cond3669, label %bb_rcgnn889, label %bb_rcgdone889
bb_rcgnn889:
  %v3670 = load i64, ptr %slot659, align 8
  %op3671 = sub i64 %v3670, 16
  store i64 %op3671, ptr %slot661, align 8
  %v3672 = load i64, ptr %slot659, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  %rgep3674 = getelementptr i8, ptr %p3673, i64 -16
  %ld3675 = load i64, ptr %rgep3674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3675, ptr %slot662, align 8
  %v3676 = load i64, ptr %slot662, align 8
  %op3677 = and i64 %v3676, 4611686018427387906
  store i64 %op3677, ptr %slot663, align 8
  %v3678 = load i64, ptr %slot663, align 8
  %cmp3679 = icmp ne i64 %v3678, 0
  %cv3680 = zext i1 %cmp3679 to i32
  store i32 %cv3680, ptr %slot664, align 8
  %v3681 = load i32, ptr %slot664, align 8
  %cv3682 = zext i32 %v3681 to i64
  %cond3683 = icmp ne i64 %cv3682, 0
  br i1 %cond3683, label %bb_rcgclear889, label %bb_rcgcounted889
bb_rcgcounted889:
  %v3684 = load i64, ptr %slot659, align 8
  %op3685 = sub i64 %v3684, 32
  store i64 %op3685, ptr %slot665, align 8
  %v3686 = load i64, ptr %slot659, align 8
  %p3687 = inttoptr i64 %v3686 to ptr
  %rgep3688 = getelementptr i8, ptr %p3687, i64 -32
  %ld3689 = load i64, ptr %rgep3688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3689, ptr %slot666, align 8
  %v3690 = load i64, ptr %slot666, align 8
  %op3691 = sub i64 %v3690, 1
  store i64 %op3691, ptr %slot667, align 8
  %v3692 = load i64, ptr %slot667, align 8
  %cmp3693 = icmp eq i64 %v3692, 0
  %cv3694 = zext i1 %cmp3693 to i32
  store i32 %cv3694, ptr %slot668, align 8
  %v3695 = load i32, ptr %slot668, align 8
  %cv3696 = zext i32 %v3695 to i64
  %cond3697 = icmp ne i64 %cv3696, 0
  br i1 %cond3697, label %bb_rcglast889, label %bb_rcgdec889
bb_rcglast889:
  %v3698 = load i64, ptr %slot659, align 8
  %op3699 = sub i64 %v3698, 24
  store i64 %op3699, ptr %slot669, align 8
  %v3700 = load i64, ptr %slot659, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %rgep3702 = getelementptr i8, ptr %p3701, i64 -24
  %ld3703 = load i64, ptr %rgep3702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3703, ptr %slot670, align 8
  %v3704 = load i64, ptr %slot670, align 8
  %cmp3705 = icmp ne i64 %v3704, 0
  %cv3706 = zext i1 %cmp3705 to i32
  store i32 %cv3706, ptr %slot671, align 8
  %v3707 = load i32, ptr %slot671, align 8
  %cv3708 = zext i32 %v3707 to i64
  %cond3709 = icmp ne i64 %cv3708, 0
  br i1 %cond3709, label %bb_rcgdec889, label %bb_rcgslow889
bb_rcgslow889:
  %v3710 = load i64, ptr %slot658, align 8
  %v3711 = load i64, ptr %slot641, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3710, i64 %v3711) nomerge, !dbg !148
  br label %bb_rcgdone889
bb_rcgdec889:
  %v3712 = load i64, ptr %slot667, align 8
  %v3713 = load i64, ptr %slot659, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  %rgep3715 = getelementptr i8, ptr %p3714, i64 -32
  store i64 %v3712, ptr %rgep3715, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear889
bb_rcgclear889:
  %v3716 = load i64, ptr %slot641, align 8
  %p3717 = inttoptr i64 %v3716 to ptr
  store i64 0, ptr %p3717, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone889
bb_rcgdone889:
  br label %bb_rcslotdone858
bb_rcslotdone858:
  br label %bb_rcprivateprepared806
bb_rcprivateprepared806:
  %v3718 = load i64, ptr %slot10, align 8
  %p3719 = inttoptr i64 %v3718 to ptr
  %ld3720 = load i32, ptr %p3719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3720, ptr %slot672, align 8
  %v3721 = load i32, ptr %slot672, align 8
  %cv3722 = zext i32 %v3721 to i64
  %cond3723 = icmp ne i64 %cv3722, 0
  br i1 %cond3723, label %bb_rcslotdrop896, label %bb_rcslotdone896
bb_rcslotdrop896:
  %v3724 = load i64, ptr %slot10, align 8
  %p3725 = inttoptr i64 %v3724 to ptr
  store i32 0, ptr %p3725, align 4, !alias.scope !3, !noalias !4
  %v3726 = load i64, ptr %slot31, align 8
  store i64 %v3726, ptr %slot673, align 8
  %v3727 = load i64, ptr %slot11, align 8
  %p3728 = inttoptr i64 %v3727 to ptr
  %ld3729 = load i32, ptr %p3728, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3729, ptr %slot674, align 8
  %v3730 = load i32, ptr %slot674, align 8
  %op3731 = and i32 %v3730, 28
  store i32 %op3731, ptr %slot675, align 8
  %v3732 = load i32, ptr %slot675, align 8
  %cv3733 = zext i32 %v3732 to i64
  %cond3734 = icmp ne i64 %cv3733, 0
  br i1 %cond3734, label %bb_rcslotrole896, label %bb_rcslotowner896
bb_rcslotrole896:
  %v3735 = load i64, ptr %slot41, align 8
  store i64 %v3735, ptr %slot676, align 8
  %v3736 = load i64, ptr %slot673, align 8
  %p3737 = inttoptr i64 %v3736 to ptr
  %ld3738 = load i64, ptr %p3737, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3738, ptr %slot677, align 8
  %v3739 = load i64, ptr %slot677, align 8
  %cmp3740 = icmp ne i64 %v3739, 0
  %cv3741 = zext i1 %cmp3740 to i32
  store i32 %cv3741, ptr %slot678, align 8
  %v3742 = load i32, ptr %slot678, align 8
  %cv3743 = zext i32 %v3742 to i64
  %cond3744 = icmp ne i64 %cv3743, 0
  br i1 %cond3744, label %bb_rcgnn912, label %bb_rcgdone912
bb_rcgnn912:
  %v3745 = load i64, ptr %slot677, align 8
  %op3746 = sub i64 %v3745, 16
  store i64 %op3746, ptr %slot679, align 8
  %v3747 = load i64, ptr %slot677, align 8
  %p3748 = inttoptr i64 %v3747 to ptr
  %rgep3749 = getelementptr i8, ptr %p3748, i64 -16
  %ld3750 = load i64, ptr %rgep3749, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3750, ptr %slot680, align 8
  %v3751 = load i64, ptr %slot680, align 8
  %op3752 = and i64 %v3751, 4611686018427387906
  store i64 %op3752, ptr %slot681, align 8
  %v3753 = load i64, ptr %slot681, align 8
  %cmp3754 = icmp ne i64 %v3753, 0
  %cv3755 = zext i1 %cmp3754 to i32
  store i32 %cv3755, ptr %slot682, align 8
  %v3756 = load i32, ptr %slot682, align 8
  %cv3757 = zext i32 %v3756 to i64
  %cond3758 = icmp ne i64 %cv3757, 0
  br i1 %cond3758, label %bb_rcgclear912, label %bb_rcgcounted912
bb_rcgcounted912:
  %v3759 = load i64, ptr %slot677, align 8
  %op3760 = sub i64 %v3759, 24
  store i64 %op3760, ptr %slot683, align 8
  %v3761 = load i64, ptr %slot677, align 8
  %p3762 = inttoptr i64 %v3761 to ptr
  %rgep3763 = getelementptr i8, ptr %p3762, i64 -24
  %ld3764 = load i64, ptr %rgep3763, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3764, ptr %slot684, align 8
  %v3765 = load i64, ptr %slot684, align 8
  %op3766 = sub i64 %v3765, 1
  store i64 %op3766, ptr %slot685, align 8
  %v3767 = load i64, ptr %slot685, align 8
  %cmp3768 = icmp eq i64 %v3767, 0
  %cv3769 = zext i1 %cmp3768 to i32
  store i32 %cv3769, ptr %slot686, align 8
  %v3770 = load i32, ptr %slot686, align 8
  %cv3771 = zext i32 %v3770 to i64
  %cond3772 = icmp ne i64 %cv3771, 0
  br i1 %cond3772, label %bb_rcglast912, label %bb_rcgdec912
bb_rcglast912:
  %v3773 = load i64, ptr %slot677, align 8
  %op3774 = sub i64 %v3773, 32
  store i64 %op3774, ptr %slot687, align 8
  %v3775 = load i64, ptr %slot677, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  %rgep3777 = getelementptr i8, ptr %p3776, i64 -32
  %ld3778 = load i64, ptr %rgep3777, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3778, ptr %slot688, align 8
  %v3779 = load i64, ptr %slot688, align 8
  %cmp3780 = icmp ne i64 %v3779, 0
  %cv3781 = zext i1 %cmp3780 to i32
  store i32 %cv3781, ptr %slot689, align 8
  %v3782 = load i32, ptr %slot689, align 8
  %cv3783 = zext i32 %v3782 to i64
  %cond3784 = icmp ne i64 %cv3783, 0
  br i1 %cond3784, label %bb_rcgdec912, label %bb_rcgslow912
bb_rcgslow912:
  %v3785 = load i64, ptr %slot676, align 8
  %v3786 = load i64, ptr %slot673, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3785, i64 %v3786) nomerge, !dbg !148
  br label %bb_rcgdone912
bb_rcgdec912:
  %v3787 = load i64, ptr %slot685, align 8
  %v3788 = load i64, ptr %slot677, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  %rgep3790 = getelementptr i8, ptr %p3789, i64 -24
  store i64 %v3787, ptr %rgep3790, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear912
bb_rcgclear912:
  %v3791 = load i64, ptr %slot673, align 8
  %p3792 = inttoptr i64 %v3791 to ptr
  store i64 0, ptr %p3792, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone912
bb_rcgdone912:
  br label %bb_rcslotdone896
bb_rcslotowner896:
  %v3793 = load i64, ptr %slot41, align 8
  store i64 %v3793, ptr %slot690, align 8
  %v3794 = load i64, ptr %slot673, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  %ld3796 = load i64, ptr %p3795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3796, ptr %slot691, align 8
  %v3797 = load i64, ptr %slot691, align 8
  %cmp3798 = icmp ne i64 %v3797, 0
  %cv3799 = zext i1 %cmp3798 to i32
  store i32 %cv3799, ptr %slot692, align 8
  %v3800 = load i32, ptr %slot692, align 8
  %cv3801 = zext i32 %v3800 to i64
  %cond3802 = icmp ne i64 %cv3801, 0
  br i1 %cond3802, label %bb_rcgnn927, label %bb_rcgdone927
bb_rcgnn927:
  %v3803 = load i64, ptr %slot691, align 8
  %op3804 = sub i64 %v3803, 16
  store i64 %op3804, ptr %slot693, align 8
  %v3805 = load i64, ptr %slot691, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %rgep3807 = getelementptr i8, ptr %p3806, i64 -16
  %ld3808 = load i64, ptr %rgep3807, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3808, ptr %slot694, align 8
  %v3809 = load i64, ptr %slot694, align 8
  %op3810 = and i64 %v3809, 4611686018427387906
  store i64 %op3810, ptr %slot695, align 8
  %v3811 = load i64, ptr %slot695, align 8
  %cmp3812 = icmp ne i64 %v3811, 0
  %cv3813 = zext i1 %cmp3812 to i32
  store i32 %cv3813, ptr %slot696, align 8
  %v3814 = load i32, ptr %slot696, align 8
  %cv3815 = zext i32 %v3814 to i64
  %cond3816 = icmp ne i64 %cv3815, 0
  br i1 %cond3816, label %bb_rcgclear927, label %bb_rcgcounted927
bb_rcgcounted927:
  %v3817 = load i64, ptr %slot691, align 8
  %op3818 = sub i64 %v3817, 32
  store i64 %op3818, ptr %slot697, align 8
  %v3819 = load i64, ptr %slot691, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %rgep3821 = getelementptr i8, ptr %p3820, i64 -32
  %ld3822 = load i64, ptr %rgep3821, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3822, ptr %slot698, align 8
  %v3823 = load i64, ptr %slot698, align 8
  %op3824 = sub i64 %v3823, 1
  store i64 %op3824, ptr %slot699, align 8
  %v3825 = load i64, ptr %slot699, align 8
  %cmp3826 = icmp eq i64 %v3825, 0
  %cv3827 = zext i1 %cmp3826 to i32
  store i32 %cv3827, ptr %slot700, align 8
  %v3828 = load i32, ptr %slot700, align 8
  %cv3829 = zext i32 %v3828 to i64
  %cond3830 = icmp ne i64 %cv3829, 0
  br i1 %cond3830, label %bb_rcglast927, label %bb_rcgdec927
bb_rcglast927:
  %v3831 = load i64, ptr %slot691, align 8
  %op3832 = sub i64 %v3831, 24
  store i64 %op3832, ptr %slot701, align 8
  %v3833 = load i64, ptr %slot691, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %rgep3835 = getelementptr i8, ptr %p3834, i64 -24
  %ld3836 = load i64, ptr %rgep3835, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3836, ptr %slot702, align 8
  %v3837 = load i64, ptr %slot702, align 8
  %cmp3838 = icmp ne i64 %v3837, 0
  %cv3839 = zext i1 %cmp3838 to i32
  store i32 %cv3839, ptr %slot703, align 8
  %v3840 = load i32, ptr %slot703, align 8
  %cv3841 = zext i32 %v3840 to i64
  %cond3842 = icmp ne i64 %cv3841, 0
  br i1 %cond3842, label %bb_rcgdec927, label %bb_rcgslow927
bb_rcgslow927:
  %v3843 = load i64, ptr %slot690, align 8
  %v3844 = load i64, ptr %slot673, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3843, i64 %v3844) nomerge, !dbg !148
  br label %bb_rcgdone927
bb_rcgdec927:
  %v3845 = load i64, ptr %slot699, align 8
  %v3846 = load i64, ptr %slot691, align 8
  %p3847 = inttoptr i64 %v3846 to ptr
  %rgep3848 = getelementptr i8, ptr %p3847, i64 -32
  store i64 %v3845, ptr %rgep3848, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear927
bb_rcgclear927:
  %v3849 = load i64, ptr %slot673, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  store i64 0, ptr %p3850, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone927
bb_rcgdone927:
  br label %bb_rcslotdone896
bb_rcslotdone896:
  %v3851 = load i64, ptr %slot31, align 8
  store i64 %v3851, ptr %slot704, align 8
  %v3852 = load i64, ptr %slot23, align 8
  store i64 %v3852, ptr %slot705, align 8
  %v3853 = load i64, ptr %slot705, align 8
  %v3854 = load i64, ptr %slot704, align 8
  %p3855 = inttoptr i64 %v3853 to ptr
  %p3856 = inttoptr i64 %v3854 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3856, ptr %p3855, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3857 = load i64, ptr %slot16, align 8
  %p3858 = inttoptr i64 %v3857 to ptr
  store i32 0, ptr %p3858, align 4, !alias.scope !3, !noalias !4
  %v3859 = load i64, ptr %slot11, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  store i32 2, ptr %p3860, align 4, !alias.scope !3, !noalias !4
  %v3861 = load i64, ptr %slot17, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  %ld3863 = load i32, ptr %p3862, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3863, ptr %slot706, align 8
  %v3864 = load i32, ptr %slot706, align 8
  %v3865 = load i64, ptr %slot11, align 8
  %p3866 = inttoptr i64 %v3865 to ptr
  store i32 %v3864, ptr %p3866, align 4, !alias.scope !3, !noalias !4
  %v3867 = load i64, ptr %slot10, align 8
  %p3868 = inttoptr i64 %v3867 to ptr
  store i32 1, ptr %p3868, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined742
bb_rcholdjoined742:
  %v3869 = load i64, ptr %slot31, align 8
  %p3870 = inttoptr i64 %v3869 to ptr
  %ld3871 = load i64, ptr %p3870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3871, ptr %slot707, align 8
  %v3872 = load i64, ptr %slot707, align 8
  %op3873 = add i64 %v3872, 0
  store i64 %op3873, ptr %slot708, align 8
  %v3874 = load i64, ptr %slot708, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  %ld3876 = load i64, ptr %p3875, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3876, ptr %slot709, align 8
  %v3877 = load i64, ptr %slot709, align 8
  %v3878 = load i64, ptr %slot33, align 8
  %p3879 = inttoptr i64 %v3878 to ptr
  store i64 %v3877, ptr %p3879, align 8, !alias.scope !3, !noalias !4
  %v3880 = load i64, ptr %slot33, align 8
  %p3881 = inttoptr i64 %v3880 to ptr
  %ld3882 = load i64, ptr %p3881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3882, ptr %slot710, align 8
  %v3883 = load i64, ptr %slot710, align 8
  %cmp3884 = icmp ugt i64 %v3883, 9223372036854775807
  %cv3885 = zext i1 %cmp3884 to i64
  store i64 %cv3885, ptr %slot711, align 8
  %v3886 = load i64, ptr %slot711, align 8
  %cond3887 = icmp ne i64 %v3886, 0
  br i1 %cond3887, label %bb_cast_overflow943, label %bb_cast_ok943
bb_cast_overflow943:
  %v3888 = load i64, ptr %slot1, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  %v3890 = load i64, ptr %slot710, align 8
  call void @myl_qbe_fail_cast(ptr %p3889, i64 %v3890, i64 320) nomerge, !dbg !150
  unreachable
bb_cast_ok943:
  %v3891 = load i64, ptr %slot710, align 8
  %v3892 = load i64, ptr %slot33, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  store i64 %v3891, ptr %p3893, align 8, !alias.scope !3, !noalias !4
  %v3894 = load i64, ptr %slot26, align 8
  %v3895 = load i64, ptr %slot34, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  store i64 %v3894, ptr %p3896, align 8, !alias.scope !3, !noalias !4
  %v3897 = load i64, ptr %slot34, align 8
  %p3898 = inttoptr i64 %v3897 to ptr
  %ld3899 = load i64, ptr %p3898, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3899, ptr %slot712, align 8
  %v3900 = load i64, ptr %slot712, align 8
  %op3901 = add i64 %v3900, 8
  store i64 %op3901, ptr %slot713, align 8
  %v3902 = load i64, ptr %slot713, align 8
  %v3903 = load i64, ptr %slot34, align 8
  %p3904 = inttoptr i64 %v3903 to ptr
  store i64 %v3902, ptr %p3904, align 8, !alias.scope !3, !noalias !4
  %v3905 = load i64, ptr %slot34, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  %ld3907 = load i64, ptr %p3906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3907, ptr %slot714, align 8
  %v3908 = load i64, ptr %slot714, align 8
  %op3909 = add i64 %v3908, 24
  store i64 %op3909, ptr %slot715, align 8
  %v3910 = load i64, ptr %slot715, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  %ld3912 = load i64, ptr %p3911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3912, ptr %slot716, align 8
  %v3913 = load i64, ptr %slot716, align 8
  %v3914 = load i64, ptr %slot34, align 8
  %p3915 = inttoptr i64 %v3914 to ptr
  store i64 %v3913, ptr %p3915, align 8, !alias.scope !3, !noalias !4
  %v3916 = load i64, ptr %slot32, align 8
  %p3917 = inttoptr i64 %v3916 to ptr
  %ld3918 = load i64, ptr %p3917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3918, ptr %slot717, align 8
  %v3919 = load i64, ptr %slot33, align 8
  %p3920 = inttoptr i64 %v3919 to ptr
  %ld3921 = load i64, ptr %p3920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3921, ptr %slot718, align 8
  %v3922 = load i64, ptr %slot34, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  %ld3924 = load i64, ptr %p3923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3924, ptr %slot719, align 8
  %v3925 = load i64, ptr %slot1, align 8
  %v3926 = load i64, ptr %slot717, align 8
  %v3927 = load i64, ptr %slot718, align 8
  %v3928 = load i64, ptr %slot719, align 8
  call void @myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d(ptr sret([24 x i8]) align 8 %callresult721, i64 %v3925, i64 %v3926, i64 %v3927, i64 %v3928) nomerge, !dbg !152
  %addr3929 = ptrtoint ptr %callresult721 to i64
  store i64 %addr3929, ptr %slot720, align 8
  %v3930 = load i64, ptr %slot720, align 8
  %v3931 = load i64, ptr %slot32, align 8
  %p3932 = inttoptr i64 %v3931 to ptr
  store i64 %v3930, ptr %p3932, align 8, !alias.scope !3, !noalias !4
  %v3933 = load i64, ptr %slot32, align 8
  %p3934 = inttoptr i64 %v3933 to ptr
  %ld3935 = load i64, ptr %p3934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3935, ptr %slot722, align 8
  %v3936 = load i64, ptr %slot23, align 8
  store i64 %v3936, ptr %slot723, align 8
  %v3937 = load i64, ptr %slot722, align 8
  %v3938 = load i64, ptr %slot723, align 8
  %p3939 = inttoptr i64 %v3937 to ptr
  %p3940 = inttoptr i64 %v3938 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3940, ptr %p3939, i64 24, i1 false)
  %v3941 = load i64, ptr %slot17, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  store i32 2, ptr %p3942, align 4, !alias.scope !3, !noalias !4
  %v3943 = load i64, ptr %slot16, align 8
  %p3944 = inttoptr i64 %v3943 to ptr
  store i32 1, ptr %p3944, align 4, !alias.scope !3, !noalias !4
  %v3945 = load i64, ptr %slot12, align 8
  %p3946 = inttoptr i64 %v3945 to ptr
  %ld3947 = load i32, ptr %p3946, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3947, ptr %slot724, align 8
  %v3948 = load i32, ptr %slot724, align 8
  %cv3949 = zext i32 %v3948 to i64
  %cond3950 = icmp ne i64 %cv3949, 0
  br i1 %cond3950, label %bb_rcslotdrop977, label %bb_rcslotdone977
bb_rcslotdrop977:
  %v3951 = load i64, ptr %slot12, align 8
  %p3952 = inttoptr i64 %v3951 to ptr
  store i32 0, ptr %p3952, align 4, !alias.scope !3, !noalias !4
  %v3953 = load i64, ptr %slot19, align 8
  store i64 %v3953, ptr %slot725, align 8
  %v3954 = load i64, ptr %slot13, align 8
  %p3955 = inttoptr i64 %v3954 to ptr
  %ld3956 = load i32, ptr %p3955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3956, ptr %slot726, align 8
  %v3957 = load i32, ptr %slot726, align 8
  %op3958 = and i32 %v3957, 28
  store i32 %op3958, ptr %slot727, align 8
  %v3959 = load i32, ptr %slot727, align 8
  %cv3960 = zext i32 %v3959 to i64
  %cond3961 = icmp ne i64 %cv3960, 0
  br i1 %cond3961, label %bb_rcslotrole977, label %bb_rcslotowner977
bb_rcslotrole977:
  %v3962 = load i64, ptr %slot41, align 8
  store i64 %v3962, ptr %slot728, align 8
  %v3963 = load i64, ptr %slot728, align 8
  %v3964 = load i64, ptr %slot725, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3963, i64 %v3964) nomerge, !dbg !152
  br label %bb_rcslotdone977
bb_rcslotowner977:
  %v3965 = load i64, ptr %slot41, align 8
  store i64 %v3965, ptr %slot729, align 8
  %v3966 = load i64, ptr %slot729, align 8
  %v3967 = load i64, ptr %slot725, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3966, i64 %v3967) nomerge, !dbg !152
  br label %bb_rcslotdone977
bb_rcslotdone977:
  %v3968 = load i64, ptr %slot19, align 8
  store i64 %v3968, ptr %slot730, align 8
  %v3969 = load i64, ptr %slot23, align 8
  store i64 %v3969, ptr %slot731, align 8
  %v3970 = load i64, ptr %slot731, align 8
  %v3971 = load i64, ptr %slot730, align 8
  %p3972 = inttoptr i64 %v3970 to ptr
  %p3973 = inttoptr i64 %v3971 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3973, ptr %p3972, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3974 = load i64, ptr %slot13, align 8
  %p3975 = inttoptr i64 %v3974 to ptr
  store i32 2, ptr %p3975, align 4, !alias.scope !3, !noalias !4
  %v3976 = load i64, ptr %slot17, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  %ld3978 = load i32, ptr %p3977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3978, ptr %slot732, align 8
  %v3979 = load i32, ptr %slot732, align 8
  %v3980 = load i64, ptr %slot13, align 8
  %p3981 = inttoptr i64 %v3980 to ptr
  store i32 %v3979, ptr %p3981, align 4, !alias.scope !3, !noalias !4
  %v3982 = load i64, ptr %slot16, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  store i32 0, ptr %p3983, align 4, !alias.scope !3, !noalias !4
  %v3984 = load i64, ptr %slot12, align 8
  %p3985 = inttoptr i64 %v3984 to ptr
  store i32 1, ptr %p3985, align 4, !alias.scope !3, !noalias !4
  %v3986 = load i64, ptr %slot730, align 8
  %v3987 = load i64, ptr %slot32, align 8
  %p3988 = inttoptr i64 %v3987 to ptr
  store i64 %v3986, ptr %p3988, align 8, !alias.scope !3, !noalias !4
  %v3989 = load i64, ptr %slot32, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  %ld3991 = load i64, ptr %p3990, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3991, ptr %slot733, align 8
  %v3992 = load i64, ptr %slot733, align 8
  %p3993 = inttoptr i64 %v3992 to ptr
  %ld3994 = load i32, ptr %p3993, align 4, !alias.scope !3, !noalias !4
  %ext3995 = zext i32 %ld3994 to i64
  store i64 %ext3995, ptr %slot734, align 8
  %v3996 = load i64, ptr %slot734, align 8
  %cmp3997 = icmp eq i64 %v3996, 1
  %cv3998 = zext i1 %cmp3997 to i64
  store i64 %cv3998, ptr %slot735, align 8
  %v3999 = load i64, ptr %slot735, align 8
  %cond4000 = icmp ne i64 %v3999, 0
  br i1 %cond4000, label %bb_errtrace994, label %bb_errtraced994
bb_errtrace994:
  %p4001 = inttoptr i64 ptrtoint (ptr @myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p4001, i64 8589934647) "call-inline-cost"="0", !dbg !154
  br label %bb_errtraced994
bb_errtraced994:
  %v4002 = load i64, ptr %slot32, align 8
  %p4003 = inttoptr i64 %v4002 to ptr
  %ld4004 = load i64, ptr %p4003, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4004, ptr %slot736, align 8
  %v4005 = load i64, ptr %slot23, align 8
  store i64 %v4005, ptr %slot737, align 8
  %v4006 = load i64, ptr %slot42, align 8
  store i64 %v4006, ptr %slot738, align 8
  %v4007 = load i64, ptr %slot41, align 8
  %v4008 = load i64, ptr %slot737, align 8
  %v4009 = load i64, ptr %slot736, align 8
  %v4010 = load i64, ptr %slot738, align 8
  %cv4011 = trunc i64 %v4010 to i32
  %call4012 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v4007, i64 %v4008, i64 %v4009, i32 %cv4011) nomerge, !dbg !154
  store i32 %call4012, ptr %slot739, align 8
  %v4013 = load i32, ptr %slot739, align 8
  %cv4014 = zext i32 %v4013 to i64
  %cond4015 = icmp ne i64 %cv4014, 0
  br i1 %cond4015, label %bb_rcsuccess999, label %bb_rcfailure999
bb_rcfailure999:
  %v4016 = load i64, ptr %slot41, align 8
  %p4017 = inttoptr i64 %v4016 to ptr
  %call4018 = call i32 @myl_rc_take_failure(ptr %p4017) nomerge, !dbg !154
  store i32 %call4018, ptr %slot740, align 8
  %v4019 = load i64, ptr %slot1, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  %v4021 = load i32, ptr %slot740, align 8
  %call4022 = call i32 @myl_qbe_rc_status(ptr %p4020, i32 %v4021) nomerge, !dbg !154
  store i32 %call4022, ptr %slot741, align 8
  br label %bb_failure
bb_rcsuccess999:
  %v4023 = load i64, ptr %slot12, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  store i32 0, ptr %p4024, align 4, !alias.scope !3, !noalias !4
  %v4025 = load i64, ptr %slot17, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  store i32 2, ptr %p4026, align 4, !alias.scope !3, !noalias !4
  %v4027 = load i64, ptr %slot16, align 8
  %p4028 = inttoptr i64 %v4027 to ptr
  store i32 1, ptr %p4028, align 4, !alias.scope !3, !noalias !4
  %v4029 = load i64, ptr %slot23, align 8
  store i64 %v4029, ptr %slot742, align 8
  %v4030 = load i64, ptr %slot16, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  store i32 0, ptr %p4031, align 4, !alias.scope !3, !noalias !4
  %v4032 = load i64, ptr %slot12, align 8
  %p4033 = inttoptr i64 %v4032 to ptr
  %ld4034 = load i32, ptr %p4033, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4034, ptr %slot743, align 8
  %v4035 = load i32, ptr %slot743, align 8
  %cv4036 = zext i32 %v4035 to i64
  %cond4037 = icmp ne i64 %cv4036, 0
  br i1 %cond4037, label %bb_rcslotdrop1009, label %bb_rcslotdone1009
bb_rcslotdrop1009:
  %v4038 = load i64, ptr %slot12, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  store i32 0, ptr %p4039, align 4, !alias.scope !3, !noalias !4
  %v4040 = load i64, ptr %slot19, align 8
  store i64 %v4040, ptr %slot744, align 8
  %v4041 = load i64, ptr %slot13, align 8
  %p4042 = inttoptr i64 %v4041 to ptr
  %ld4043 = load i32, ptr %p4042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4043, ptr %slot745, align 8
  %v4044 = load i32, ptr %slot745, align 8
  %op4045 = and i32 %v4044, 28
  store i32 %op4045, ptr %slot746, align 8
  %v4046 = load i32, ptr %slot746, align 8
  %cv4047 = zext i32 %v4046 to i64
  %cond4048 = icmp ne i64 %cv4047, 0
  br i1 %cond4048, label %bb_rcslotrole1009, label %bb_rcslotowner1009
bb_rcslotrole1009:
  %v4049 = load i64, ptr %slot41, align 8
  store i64 %v4049, ptr %slot747, align 8
  %v4050 = load i64, ptr %slot747, align 8
  %v4051 = load i64, ptr %slot744, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4050, i64 %v4051) nomerge, !dbg !154
  br label %bb_rcslotdone1009
bb_rcslotowner1009:
  %v4052 = load i64, ptr %slot41, align 8
  store i64 %v4052, ptr %slot748, align 8
  %v4053 = load i64, ptr %slot748, align 8
  %v4054 = load i64, ptr %slot744, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4053, i64 %v4054) nomerge, !dbg !154
  br label %bb_rcslotdone1009
bb_rcslotdone1009:
  %v4055 = load i64, ptr %slot10, align 8
  %p4056 = inttoptr i64 %v4055 to ptr
  %ld4057 = load i32, ptr %p4056, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4057, ptr %slot749, align 8
  %v4058 = load i32, ptr %slot749, align 8
  %cv4059 = zext i32 %v4058 to i64
  %cond4060 = icmp ne i64 %cv4059, 0
  br i1 %cond4060, label %bb_rcslotdrop1018, label %bb_rcslotdone1018
bb_rcslotdrop1018:
  %v4061 = load i64, ptr %slot10, align 8
  %p4062 = inttoptr i64 %v4061 to ptr
  store i32 0, ptr %p4062, align 4, !alias.scope !3, !noalias !4
  %v4063 = load i64, ptr %slot31, align 8
  store i64 %v4063, ptr %slot750, align 8
  %v4064 = load i64, ptr %slot11, align 8
  %p4065 = inttoptr i64 %v4064 to ptr
  %ld4066 = load i32, ptr %p4065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4066, ptr %slot751, align 8
  %v4067 = load i32, ptr %slot751, align 8
  %op4068 = and i32 %v4067, 28
  store i32 %op4068, ptr %slot752, align 8
  %v4069 = load i32, ptr %slot752, align 8
  %cv4070 = zext i32 %v4069 to i64
  %cond4071 = icmp ne i64 %cv4070, 0
  br i1 %cond4071, label %bb_rcslotrole1018, label %bb_rcslotowner1018
bb_rcslotrole1018:
  %v4072 = load i64, ptr %slot41, align 8
  store i64 %v4072, ptr %slot753, align 8
  %v4073 = load i64, ptr %slot750, align 8
  %p4074 = inttoptr i64 %v4073 to ptr
  %ld4075 = load i64, ptr %p4074, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4075, ptr %slot754, align 8
  %v4076 = load i64, ptr %slot754, align 8
  %cmp4077 = icmp ne i64 %v4076, 0
  %cv4078 = zext i1 %cmp4077 to i32
  store i32 %cv4078, ptr %slot755, align 8
  %v4079 = load i32, ptr %slot755, align 8
  %cv4080 = zext i32 %v4079 to i64
  %cond4081 = icmp ne i64 %cv4080, 0
  br i1 %cond4081, label %bb_rcgnn1034, label %bb_rcgdone1034
bb_rcgnn1034:
  %v4082 = load i64, ptr %slot754, align 8
  %op4083 = sub i64 %v4082, 16
  store i64 %op4083, ptr %slot756, align 8
  %v4084 = load i64, ptr %slot754, align 8
  %p4085 = inttoptr i64 %v4084 to ptr
  %rgep4086 = getelementptr i8, ptr %p4085, i64 -16
  %ld4087 = load i64, ptr %rgep4086, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4087, ptr %slot757, align 8
  %v4088 = load i64, ptr %slot757, align 8
  %op4089 = and i64 %v4088, 4611686018427387906
  store i64 %op4089, ptr %slot758, align 8
  %v4090 = load i64, ptr %slot758, align 8
  %cmp4091 = icmp ne i64 %v4090, 0
  %cv4092 = zext i1 %cmp4091 to i32
  store i32 %cv4092, ptr %slot759, align 8
  %v4093 = load i32, ptr %slot759, align 8
  %cv4094 = zext i32 %v4093 to i64
  %cond4095 = icmp ne i64 %cv4094, 0
  br i1 %cond4095, label %bb_rcgclear1034, label %bb_rcgcounted1034
bb_rcgcounted1034:
  %v4096 = load i64, ptr %slot754, align 8
  %op4097 = sub i64 %v4096, 24
  store i64 %op4097, ptr %slot760, align 8
  %v4098 = load i64, ptr %slot754, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  %rgep4100 = getelementptr i8, ptr %p4099, i64 -24
  %ld4101 = load i64, ptr %rgep4100, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4101, ptr %slot761, align 8
  %v4102 = load i64, ptr %slot761, align 8
  %op4103 = sub i64 %v4102, 1
  store i64 %op4103, ptr %slot762, align 8
  %v4104 = load i64, ptr %slot762, align 8
  %cmp4105 = icmp eq i64 %v4104, 0
  %cv4106 = zext i1 %cmp4105 to i32
  store i32 %cv4106, ptr %slot763, align 8
  %v4107 = load i32, ptr %slot763, align 8
  %cv4108 = zext i32 %v4107 to i64
  %cond4109 = icmp ne i64 %cv4108, 0
  br i1 %cond4109, label %bb_rcglast1034, label %bb_rcgdec1034
bb_rcglast1034:
  %v4110 = load i64, ptr %slot754, align 8
  %op4111 = sub i64 %v4110, 32
  store i64 %op4111, ptr %slot764, align 8
  %v4112 = load i64, ptr %slot754, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  %rgep4114 = getelementptr i8, ptr %p4113, i64 -32
  %ld4115 = load i64, ptr %rgep4114, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4115, ptr %slot765, align 8
  %v4116 = load i64, ptr %slot765, align 8
  %cmp4117 = icmp ne i64 %v4116, 0
  %cv4118 = zext i1 %cmp4117 to i32
  store i32 %cv4118, ptr %slot766, align 8
  %v4119 = load i32, ptr %slot766, align 8
  %cv4120 = zext i32 %v4119 to i64
  %cond4121 = icmp ne i64 %cv4120, 0
  br i1 %cond4121, label %bb_rcgdec1034, label %bb_rcgslow1034
bb_rcgslow1034:
  %v4122 = load i64, ptr %slot753, align 8
  %v4123 = load i64, ptr %slot750, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4122, i64 %v4123) nomerge, !dbg !154
  br label %bb_rcgdone1034
bb_rcgdec1034:
  %v4124 = load i64, ptr %slot762, align 8
  %v4125 = load i64, ptr %slot754, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  %rgep4127 = getelementptr i8, ptr %p4126, i64 -24
  store i64 %v4124, ptr %rgep4127, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1034
bb_rcgclear1034:
  %v4128 = load i64, ptr %slot750, align 8
  %p4129 = inttoptr i64 %v4128 to ptr
  store i64 0, ptr %p4129, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1034
bb_rcgdone1034:
  br label %bb_rcslotdone1018
bb_rcslotowner1018:
  %v4130 = load i64, ptr %slot41, align 8
  store i64 %v4130, ptr %slot767, align 8
  %v4131 = load i64, ptr %slot750, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  %ld4133 = load i64, ptr %p4132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4133, ptr %slot768, align 8
  %v4134 = load i64, ptr %slot768, align 8
  %cmp4135 = icmp ne i64 %v4134, 0
  %cv4136 = zext i1 %cmp4135 to i32
  store i32 %cv4136, ptr %slot769, align 8
  %v4137 = load i32, ptr %slot769, align 8
  %cv4138 = zext i32 %v4137 to i64
  %cond4139 = icmp ne i64 %cv4138, 0
  br i1 %cond4139, label %bb_rcgnn1049, label %bb_rcgdone1049
bb_rcgnn1049:
  %v4140 = load i64, ptr %slot768, align 8
  %op4141 = sub i64 %v4140, 16
  store i64 %op4141, ptr %slot770, align 8
  %v4142 = load i64, ptr %slot768, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  %rgep4144 = getelementptr i8, ptr %p4143, i64 -16
  %ld4145 = load i64, ptr %rgep4144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4145, ptr %slot771, align 8
  %v4146 = load i64, ptr %slot771, align 8
  %op4147 = and i64 %v4146, 4611686018427387906
  store i64 %op4147, ptr %slot772, align 8
  %v4148 = load i64, ptr %slot772, align 8
  %cmp4149 = icmp ne i64 %v4148, 0
  %cv4150 = zext i1 %cmp4149 to i32
  store i32 %cv4150, ptr %slot773, align 8
  %v4151 = load i32, ptr %slot773, align 8
  %cv4152 = zext i32 %v4151 to i64
  %cond4153 = icmp ne i64 %cv4152, 0
  br i1 %cond4153, label %bb_rcgclear1049, label %bb_rcgcounted1049
bb_rcgcounted1049:
  %v4154 = load i64, ptr %slot768, align 8
  %op4155 = sub i64 %v4154, 32
  store i64 %op4155, ptr %slot774, align 8
  %v4156 = load i64, ptr %slot768, align 8
  %p4157 = inttoptr i64 %v4156 to ptr
  %rgep4158 = getelementptr i8, ptr %p4157, i64 -32
  %ld4159 = load i64, ptr %rgep4158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4159, ptr %slot775, align 8
  %v4160 = load i64, ptr %slot775, align 8
  %op4161 = sub i64 %v4160, 1
  store i64 %op4161, ptr %slot776, align 8
  %v4162 = load i64, ptr %slot776, align 8
  %cmp4163 = icmp eq i64 %v4162, 0
  %cv4164 = zext i1 %cmp4163 to i32
  store i32 %cv4164, ptr %slot777, align 8
  %v4165 = load i32, ptr %slot777, align 8
  %cv4166 = zext i32 %v4165 to i64
  %cond4167 = icmp ne i64 %cv4166, 0
  br i1 %cond4167, label %bb_rcglast1049, label %bb_rcgdec1049
bb_rcglast1049:
  %v4168 = load i64, ptr %slot768, align 8
  %op4169 = sub i64 %v4168, 24
  store i64 %op4169, ptr %slot778, align 8
  %v4170 = load i64, ptr %slot768, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %rgep4172 = getelementptr i8, ptr %p4171, i64 -24
  %ld4173 = load i64, ptr %rgep4172, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4173, ptr %slot779, align 8
  %v4174 = load i64, ptr %slot779, align 8
  %cmp4175 = icmp ne i64 %v4174, 0
  %cv4176 = zext i1 %cmp4175 to i32
  store i32 %cv4176, ptr %slot780, align 8
  %v4177 = load i32, ptr %slot780, align 8
  %cv4178 = zext i32 %v4177 to i64
  %cond4179 = icmp ne i64 %cv4178, 0
  br i1 %cond4179, label %bb_rcgdec1049, label %bb_rcgslow1049
bb_rcgslow1049:
  %v4180 = load i64, ptr %slot767, align 8
  %v4181 = load i64, ptr %slot750, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4180, i64 %v4181) nomerge, !dbg !154
  br label %bb_rcgdone1049
bb_rcgdec1049:
  %v4182 = load i64, ptr %slot776, align 8
  %v4183 = load i64, ptr %slot768, align 8
  %p4184 = inttoptr i64 %v4183 to ptr
  %rgep4185 = getelementptr i8, ptr %p4184, i64 -32
  store i64 %v4182, ptr %rgep4185, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1049
bb_rcgclear1049:
  %v4186 = load i64, ptr %slot750, align 8
  %p4187 = inttoptr i64 %v4186 to ptr
  store i64 0, ptr %p4187, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1049
bb_rcgdone1049:
  br label %bb_rcslotdone1018
bb_rcslotdone1018:
  %v4188 = load i64, ptr %slot8, align 8
  %p4189 = inttoptr i64 %v4188 to ptr
  %ld4190 = load i32, ptr %p4189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4190, ptr %slot781, align 8
  %v4191 = load i32, ptr %slot781, align 8
  %cv4192 = zext i32 %v4191 to i64
  %cond4193 = icmp ne i64 %cv4192, 0
  br i1 %cond4193, label %bb_rcslotdrop1055, label %bb_rcslotdone1055
bb_rcslotdrop1055:
  %v4194 = load i64, ptr %slot8, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  store i32 0, ptr %p4195, align 4, !alias.scope !3, !noalias !4
  %v4196 = load i64, ptr %slot27, align 8
  store i64 %v4196, ptr %slot782, align 8
  %v4197 = load i64, ptr %slot9, align 8
  %p4198 = inttoptr i64 %v4197 to ptr
  %ld4199 = load i32, ptr %p4198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4199, ptr %slot783, align 8
  %v4200 = load i32, ptr %slot783, align 8
  %op4201 = and i32 %v4200, 28
  store i32 %op4201, ptr %slot784, align 8
  %v4202 = load i32, ptr %slot784, align 8
  %cv4203 = zext i32 %v4202 to i64
  %cond4204 = icmp ne i64 %cv4203, 0
  br i1 %cond4204, label %bb_rcslotrole1055, label %bb_rcslotowner1055
bb_rcslotrole1055:
  %v4205 = load i64, ptr %slot41, align 8
  store i64 %v4205, ptr %slot785, align 8
  %v4206 = load i64, ptr %slot782, align 8
  %p4207 = inttoptr i64 %v4206 to ptr
  %ld4208 = load i64, ptr %p4207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4208, ptr %slot786, align 8
  %v4209 = load i64, ptr %slot786, align 8
  %cmp4210 = icmp ne i64 %v4209, 0
  %cv4211 = zext i1 %cmp4210 to i32
  store i32 %cv4211, ptr %slot787, align 8
  %v4212 = load i32, ptr %slot787, align 8
  %cv4213 = zext i32 %v4212 to i64
  %cond4214 = icmp ne i64 %cv4213, 0
  br i1 %cond4214, label %bb_rcgnn1071, label %bb_rcgdone1071
bb_rcgnn1071:
  %v4215 = load i64, ptr %slot786, align 8
  %op4216 = sub i64 %v4215, 16
  store i64 %op4216, ptr %slot788, align 8
  %v4217 = load i64, ptr %slot786, align 8
  %p4218 = inttoptr i64 %v4217 to ptr
  %rgep4219 = getelementptr i8, ptr %p4218, i64 -16
  %ld4220 = load i64, ptr %rgep4219, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4220, ptr %slot789, align 8
  %v4221 = load i64, ptr %slot789, align 8
  %op4222 = and i64 %v4221, 4611686018427387906
  store i64 %op4222, ptr %slot790, align 8
  %v4223 = load i64, ptr %slot790, align 8
  %cmp4224 = icmp ne i64 %v4223, 0
  %cv4225 = zext i1 %cmp4224 to i32
  store i32 %cv4225, ptr %slot791, align 8
  %v4226 = load i32, ptr %slot791, align 8
  %cv4227 = zext i32 %v4226 to i64
  %cond4228 = icmp ne i64 %cv4227, 0
  br i1 %cond4228, label %bb_rcgclear1071, label %bb_rcgcounted1071
bb_rcgcounted1071:
  %v4229 = load i64, ptr %slot786, align 8
  %op4230 = sub i64 %v4229, 24
  store i64 %op4230, ptr %slot792, align 8
  %v4231 = load i64, ptr %slot786, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %rgep4233 = getelementptr i8, ptr %p4232, i64 -24
  %ld4234 = load i64, ptr %rgep4233, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4234, ptr %slot793, align 8
  %v4235 = load i64, ptr %slot793, align 8
  %op4236 = sub i64 %v4235, 1
  store i64 %op4236, ptr %slot794, align 8
  %v4237 = load i64, ptr %slot794, align 8
  %cmp4238 = icmp eq i64 %v4237, 0
  %cv4239 = zext i1 %cmp4238 to i32
  store i32 %cv4239, ptr %slot795, align 8
  %v4240 = load i32, ptr %slot795, align 8
  %cv4241 = zext i32 %v4240 to i64
  %cond4242 = icmp ne i64 %cv4241, 0
  br i1 %cond4242, label %bb_rcglast1071, label %bb_rcgdec1071
bb_rcglast1071:
  %v4243 = load i64, ptr %slot786, align 8
  %op4244 = sub i64 %v4243, 32
  store i64 %op4244, ptr %slot796, align 8
  %v4245 = load i64, ptr %slot786, align 8
  %p4246 = inttoptr i64 %v4245 to ptr
  %rgep4247 = getelementptr i8, ptr %p4246, i64 -32
  %ld4248 = load i64, ptr %rgep4247, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4248, ptr %slot797, align 8
  %v4249 = load i64, ptr %slot797, align 8
  %cmp4250 = icmp ne i64 %v4249, 0
  %cv4251 = zext i1 %cmp4250 to i32
  store i32 %cv4251, ptr %slot798, align 8
  %v4252 = load i32, ptr %slot798, align 8
  %cv4253 = zext i32 %v4252 to i64
  %cond4254 = icmp ne i64 %cv4253, 0
  br i1 %cond4254, label %bb_rcgdec1071, label %bb_rcgslow1071
bb_rcgslow1071:
  %v4255 = load i64, ptr %slot785, align 8
  %v4256 = load i64, ptr %slot782, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4255, i64 %v4256) nomerge, !dbg !154
  br label %bb_rcgdone1071
bb_rcgdec1071:
  %v4257 = load i64, ptr %slot794, align 8
  %v4258 = load i64, ptr %slot786, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  %rgep4260 = getelementptr i8, ptr %p4259, i64 -24
  store i64 %v4257, ptr %rgep4260, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1071
bb_rcgclear1071:
  %v4261 = load i64, ptr %slot782, align 8
  %p4262 = inttoptr i64 %v4261 to ptr
  store i64 0, ptr %p4262, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1071
bb_rcgdone1071:
  br label %bb_rcslotdone1055
bb_rcslotowner1055:
  %v4263 = load i64, ptr %slot41, align 8
  store i64 %v4263, ptr %slot799, align 8
  %v4264 = load i64, ptr %slot782, align 8
  %p4265 = inttoptr i64 %v4264 to ptr
  %ld4266 = load i64, ptr %p4265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4266, ptr %slot800, align 8
  %v4267 = load i64, ptr %slot800, align 8
  %cmp4268 = icmp ne i64 %v4267, 0
  %cv4269 = zext i1 %cmp4268 to i32
  store i32 %cv4269, ptr %slot801, align 8
  %v4270 = load i32, ptr %slot801, align 8
  %cv4271 = zext i32 %v4270 to i64
  %cond4272 = icmp ne i64 %cv4271, 0
  br i1 %cond4272, label %bb_rcgnn1086, label %bb_rcgdone1086
bb_rcgnn1086:
  %v4273 = load i64, ptr %slot800, align 8
  %op4274 = sub i64 %v4273, 16
  store i64 %op4274, ptr %slot802, align 8
  %v4275 = load i64, ptr %slot800, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  %rgep4277 = getelementptr i8, ptr %p4276, i64 -16
  %ld4278 = load i64, ptr %rgep4277, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4278, ptr %slot803, align 8
  %v4279 = load i64, ptr %slot803, align 8
  %op4280 = and i64 %v4279, 4611686018427387906
  store i64 %op4280, ptr %slot804, align 8
  %v4281 = load i64, ptr %slot804, align 8
  %cmp4282 = icmp ne i64 %v4281, 0
  %cv4283 = zext i1 %cmp4282 to i32
  store i32 %cv4283, ptr %slot805, align 8
  %v4284 = load i32, ptr %slot805, align 8
  %cv4285 = zext i32 %v4284 to i64
  %cond4286 = icmp ne i64 %cv4285, 0
  br i1 %cond4286, label %bb_rcgclear1086, label %bb_rcgcounted1086
bb_rcgcounted1086:
  %v4287 = load i64, ptr %slot800, align 8
  %op4288 = sub i64 %v4287, 32
  store i64 %op4288, ptr %slot806, align 8
  %v4289 = load i64, ptr %slot800, align 8
  %p4290 = inttoptr i64 %v4289 to ptr
  %rgep4291 = getelementptr i8, ptr %p4290, i64 -32
  %ld4292 = load i64, ptr %rgep4291, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4292, ptr %slot807, align 8
  %v4293 = load i64, ptr %slot807, align 8
  %op4294 = sub i64 %v4293, 1
  store i64 %op4294, ptr %slot808, align 8
  %v4295 = load i64, ptr %slot808, align 8
  %cmp4296 = icmp eq i64 %v4295, 0
  %cv4297 = zext i1 %cmp4296 to i32
  store i32 %cv4297, ptr %slot809, align 8
  %v4298 = load i32, ptr %slot809, align 8
  %cv4299 = zext i32 %v4298 to i64
  %cond4300 = icmp ne i64 %cv4299, 0
  br i1 %cond4300, label %bb_rcglast1086, label %bb_rcgdec1086
bb_rcglast1086:
  %v4301 = load i64, ptr %slot800, align 8
  %op4302 = sub i64 %v4301, 24
  store i64 %op4302, ptr %slot810, align 8
  %v4303 = load i64, ptr %slot800, align 8
  %p4304 = inttoptr i64 %v4303 to ptr
  %rgep4305 = getelementptr i8, ptr %p4304, i64 -24
  %ld4306 = load i64, ptr %rgep4305, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4306, ptr %slot811, align 8
  %v4307 = load i64, ptr %slot811, align 8
  %cmp4308 = icmp ne i64 %v4307, 0
  %cv4309 = zext i1 %cmp4308 to i32
  store i32 %cv4309, ptr %slot812, align 8
  %v4310 = load i32, ptr %slot812, align 8
  %cv4311 = zext i32 %v4310 to i64
  %cond4312 = icmp ne i64 %cv4311, 0
  br i1 %cond4312, label %bb_rcgdec1086, label %bb_rcgslow1086
bb_rcgslow1086:
  %v4313 = load i64, ptr %slot799, align 8
  %v4314 = load i64, ptr %slot782, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4313, i64 %v4314) nomerge, !dbg !154
  br label %bb_rcgdone1086
bb_rcgdec1086:
  %v4315 = load i64, ptr %slot808, align 8
  %v4316 = load i64, ptr %slot800, align 8
  %p4317 = inttoptr i64 %v4316 to ptr
  %rgep4318 = getelementptr i8, ptr %p4317, i64 -32
  store i64 %v4315, ptr %rgep4318, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1086
bb_rcgclear1086:
  %v4319 = load i64, ptr %slot782, align 8
  %p4320 = inttoptr i64 %v4319 to ptr
  store i64 0, ptr %p4320, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1086
bb_rcgdone1086:
  br label %bb_rcslotdone1055
bb_rcslotdone1055:
  %v4321 = load i64, ptr %slot6, align 8
  %p4322 = inttoptr i64 %v4321 to ptr
  %ld4323 = load i32, ptr %p4322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4323, ptr %slot813, align 8
  %v4324 = load i32, ptr %slot813, align 8
  %cv4325 = zext i32 %v4324 to i64
  %cond4326 = icmp ne i64 %cv4325, 0
  br i1 %cond4326, label %bb_rcslotdrop1092, label %bb_rcslotdone1092
bb_rcslotdrop1092:
  %v4327 = load i64, ptr %slot6, align 8
  %p4328 = inttoptr i64 %v4327 to ptr
  store i32 0, ptr %p4328, align 4, !alias.scope !3, !noalias !4
  %v4329 = load i64, ptr %slot26, align 8
  store i64 %v4329, ptr %slot814, align 8
  %v4330 = load i64, ptr %slot7, align 8
  %p4331 = inttoptr i64 %v4330 to ptr
  %ld4332 = load i32, ptr %p4331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4332, ptr %slot815, align 8
  %v4333 = load i32, ptr %slot815, align 8
  %op4334 = and i32 %v4333, 28
  store i32 %op4334, ptr %slot816, align 8
  %v4335 = load i32, ptr %slot816, align 8
  %cv4336 = zext i32 %v4335 to i64
  %cond4337 = icmp ne i64 %cv4336, 0
  br i1 %cond4337, label %bb_rcslotrole1092, label %bb_rcslotowner1092
bb_rcslotrole1092:
  %v4338 = load i64, ptr %slot41, align 8
  store i64 %v4338, ptr %slot817, align 8
  %v4339 = load i64, ptr %slot817, align 8
  %v4340 = load i64, ptr %slot814, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v4339, i64 %v4340) nomerge, !dbg !154
  br label %bb_rcslotdone1092
bb_rcslotowner1092:
  %v4341 = load i64, ptr %slot41, align 8
  store i64 %v4341, ptr %slot818, align 8
  %v4342 = load i64, ptr %slot818, align 8
  %v4343 = load i64, ptr %slot814, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v4342, i64 %v4343) nomerge, !dbg !154
  br label %bb_rcslotdone1092
bb_rcslotdone1092:
  %v4344 = load i64, ptr %slot742, align 8
  %p4345 = inttoptr i64 %v4344 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4345, i64 24, i1 false)
  ret void
bb_failure:
  %v4346 = load i64, ptr %slot5, align 8
  %p4347 = inttoptr i64 %v4346 to ptr
  call void @llvm.memset.p0.i64(ptr %p4347, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !154
  %v4348 = load i64, ptr %slot5, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4349, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v4350 = load i64, ptr %slot5, align 8
  %p4351 = inttoptr i64 %v4350 to ptr
  call void @llvm.memset.p0.i64(ptr %p4351, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !154
  %v4352 = load i64, ptr %slot5, align 8
  %p4353 = inttoptr i64 %v4352 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4353, i64 24, i1 false)
  ret void
}

@myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_212e271fe05de3e6f3ffd32ac47b6f61a493b89d19f38db2b86ba3d72c8c702d(ptr sret([24 x i8]) align 8, i64, i64, i64, i64)
declare void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8, i64, i64, i64)
declare void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_iteration(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64, i64)
declare i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394", linkageName: "myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4566338305288621253, i64 0, !"myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!124 = !DILocation(line: 11, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!126 = !DILocation(line: 14, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!128 = !DILocation(line: 15, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!130 = !DILocation(line: 19, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!132 = !DILocation(line: 26, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!136 = !DILocation(line: 33, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!138 = !DILocation(line: 34, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!140 = !DILocation(line: 36, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!142 = !DILocation(line: 39, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!144 = !DILocation(line: 43, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!146 = !DILocation(line: 48, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!148 = !DILocation(line: 49, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!150 = !DILocation(line: 51, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!152 = !DILocation(line: 55, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!154 = !DILocation(line: 56, column: 0, scope: !155)
