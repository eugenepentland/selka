target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v19 = load i64, ptr %slot1, align 8
  %op20 = add i64 %v19, 32
  store i64 %op20, ptr %slot4, align 8
  %mem21 = alloca i8, i64 16, align 8
  %ptr22 = ptrtoint ptr %mem21 to i64
  store i64 %ptr22, ptr %slot5, align 8
  %mem23 = alloca i8, i64 8, align 8
  %ptr24 = ptrtoint ptr %mem23 to i64
  store i64 %ptr24, ptr %slot6, align 8
  %mem25 = alloca i8, i64 8, align 8
  %ptr26 = ptrtoint ptr %mem25 to i64
  store i64 %ptr26, ptr %slot7, align 8
  %mem27 = alloca i8, i64 8, align 8
  %ptr28 = ptrtoint ptr %mem27 to i64
  store i64 %ptr28, ptr %slot8, align 8
  %mem29 = alloca i8, i64 8, align 8
  %ptr30 = ptrtoint ptr %mem29 to i64
  store i64 %ptr30, ptr %slot9, align 8
  %mem31 = alloca i8, i64 16, align 8
  %ptr32 = ptrtoint ptr %mem31 to i64
  store i64 %ptr32, ptr %slot10, align 8
  %v33 = load i64, ptr %slot2, align 8
  %v34 = load i64, ptr %slot6, align 8
  %p35 = inttoptr i64 %v34 to ptr
  store i64 %v33, ptr %p35, align 8, !alias.scope !3, !noalias !4
  %v36 = load i64, ptr %slot3, align 8
  %v37 = load i64, ptr %slot7, align 8
  %p38 = inttoptr i64 %v37 to ptr
  store i64 %v36, ptr %p38, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v39 = load i64, ptr %slot6, align 8
  %p40 = inttoptr i64 %v39 to ptr
  %ld41 = load i64, ptr %p40, align 8, !alias.scope !3, !noalias !4
  store i64 %ld41, ptr %slot11, align 8
  %v42 = load i64, ptr %slot11, align 8
  %v43 = load i64, ptr %slot8, align 8
  %p44 = inttoptr i64 %v43 to ptr
  store i64 %v42, ptr %p44, align 8, !alias.scope !3, !noalias !4
  %v45 = load i64, ptr %slot7, align 8
  %p46 = inttoptr i64 %v45 to ptr
  %ld47 = load i64, ptr %p46, align 8, !alias.scope !3, !noalias !4
  store i64 %ld47, ptr %slot12, align 8
  %v48 = load i64, ptr %slot12, align 8
  %v49 = load i64, ptr %slot9, align 8
  %p50 = inttoptr i64 %v49 to ptr
  store i64 %v48, ptr %p50, align 8, !alias.scope !3, !noalias !4
  %v51 = load i64, ptr %slot10, align 8
  store i64 %v51, ptr %slot13, align 8
  %v52 = load i64, ptr %slot13, align 8
  %p54 = inttoptr i64 %v52 to ptr
  %gep55 = getelementptr i8, ptr %p54, i64 0
  %op53 = ptrtoint ptr %gep55 to i64
  store i64 %op53, ptr %slot14, align 8
  %v56 = load i64, ptr %slot8, align 8
  %p57 = inttoptr i64 %v56 to ptr
  %ld58 = load i64, ptr %p57, align 8, !alias.scope !3, !noalias !4
  store i64 %ld58, ptr %slot15, align 8
  %v59 = load i64, ptr %slot15, align 8
  %v60 = load i64, ptr %slot14, align 8
  %p61 = inttoptr i64 %v60 to ptr
  store i64 %v59, ptr %p61, align 8, !alias.scope !3, !noalias !4
  %v62 = load i64, ptr %slot13, align 8
  %p64 = inttoptr i64 %v62 to ptr
  %gep65 = getelementptr i8, ptr %p64, i64 8
  %op63 = ptrtoint ptr %gep65 to i64
  store i64 %op63, ptr %slot16, align 8
  %v66 = load i64, ptr %slot9, align 8
  %p67 = inttoptr i64 %v66 to ptr
  %ld68 = load i64, ptr %p67, align 8, !alias.scope !3, !noalias !4
  store i64 %ld68, ptr %slot17, align 8
  %v69 = load i64, ptr %slot17, align 8
  %v70 = load i64, ptr %slot16, align 8
  %p71 = inttoptr i64 %v70 to ptr
  store i64 %v69, ptr %p71, align 8, !alias.scope !3, !noalias !4
  %v72 = load i64, ptr %slot13, align 8
  %v73 = load i64, ptr %slot8, align 8
  %p74 = inttoptr i64 %v73 to ptr
  store i64 %v72, ptr %p74, align 8, !alias.scope !3, !noalias !4
  %v75 = load i64, ptr %slot8, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %ld77 = load i64, ptr %p76, align 8, !alias.scope !3, !noalias !4
  store i64 %ld77, ptr %slot18, align 8
  %v78 = load i64, ptr %slot18, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %ret80 = load { i64, i64 }, ptr %p79, align 8
  ret { i64, i64 } %ret80
bb_failure:
  %v81 = load i64, ptr %slot5, align 8
  %p82 = inttoptr i64 %v81 to ptr
  call void @llvm.memset.p0.i64(ptr %p82, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v83 = load i64, ptr %slot5, align 8
  %p84 = inttoptr i64 %v83 to ptr
  %ret85 = load { i64, i64 }, ptr %p84, align 8
  ret { i64, i64 } %ret85
bb_entry_failure:
  %v86 = load i64, ptr %slot5, align 8
  %p87 = inttoptr i64 %v86 to ptr
  call void @llvm.memset.p0.i64(ptr %p87, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v88 = load i64, ptr %slot5, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ret90 = load { i64, i64 }, ptr %p89, align 8
  ret { i64, i64 } %ret90
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow", linkageName: "myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14835400035324940323, i64 0, !"myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!110 = !DILocation(line: 4, column: 0, scope: !111)
