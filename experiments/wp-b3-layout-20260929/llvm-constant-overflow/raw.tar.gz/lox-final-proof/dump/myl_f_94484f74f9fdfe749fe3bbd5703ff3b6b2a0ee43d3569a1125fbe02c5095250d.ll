target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %callresult13 = alloca [16 x i8], align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v17 = load i64, ptr %slot1, align 8
  %op18 = add i64 %v17, 32
  store i64 %op18, ptr %slot3, align 8
  %mem19 = alloca i8, i64 8, align 8
  %ptr20 = ptrtoint ptr %mem19 to i64
  store i64 %ptr20, ptr %slot4, align 8
  %mem21 = alloca i8, i64 8, align 8
  %ptr22 = ptrtoint ptr %mem21 to i64
  store i64 %ptr22, ptr %slot5, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem23 = alloca i8, i64 8, align 8
  %ptr24 = ptrtoint ptr %mem23 to i64
  store i64 %ptr24, ptr %slot6, align 8
  %v25 = load i64, ptr %slot1, align 8
  %op26 = add i64 %v25, 64
  store i64 %op26, ptr %slot7, align 8
  %v27 = load i64, ptr %slot7, align 8
  %p28 = inttoptr i64 %v27 to ptr
  %ld29 = load i64, ptr %p28, align 8, !alias.scope !4, !noalias !3
  store i64 %ld29, ptr %slot8, align 8
  %stack30 = call ptr @llvm.stacksave()
  %stackaddr31 = ptrtoint ptr %stack30 to i64
  %v32 = load i64, ptr %slot8, align 8
  %cmp33 = icmp ult i64 %stackaddr31, %v32
  %cv34 = zext i1 %cmp33 to i64
  store i64 %cv34, ptr %slot9, align 8
  %v35 = load i64, ptr %slot9, align 8
  %cond36 = icmp ne i64 %v35, 0
  br i1 %cond36, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v37 = load i64, ptr %slot1, align 8
  %p38 = inttoptr i64 %v37 to ptr
  call void @myl_qbe_fail_frame(ptr %p38) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v39 = load i64, ptr %slot2, align 8
  %v40 = load i64, ptr %slot4, align 8
  %p41 = inttoptr i64 %v40 to ptr
  store i64 %v39, ptr %p41, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v42 = load i64, ptr %slot4, align 8
  %p43 = inttoptr i64 %v42 to ptr
  %ld44 = load i64, ptr %p43, align 8, !alias.scope !3, !noalias !4
  store i64 %ld44, ptr %slot10, align 8
  %v45 = load i64, ptr %slot10, align 8
  %v46 = load i64, ptr %slot5, align 8
  %p47 = inttoptr i64 %v46 to ptr
  store i64 %v45, ptr %p47, align 8, !alias.scope !3, !noalias !4
  %v48 = load i64, ptr %slot5, align 8
  %p49 = inttoptr i64 %v48 to ptr
  %ld50 = load i64, ptr %p49, align 8, !alias.scope !3, !noalias !4
  store i64 %ld50, ptr %slot11, align 8
  %v51 = load i64, ptr %slot1, align 8
  %v52 = load i64, ptr %slot11, align 8
  %call53 = call { i64, i64 } @myl_f_cb51e0dd7840af78b8d3f65cd883ca525c8c73ff445227a508c4c557b220dad4(i64 %v51, i64 %v52) nomerge, !dbg !112
  store { i64, i64 } %call53, ptr %callresult13, align 8
  %addr54 = ptrtoint ptr %callresult13 to i64
  store i64 %addr54, ptr %slot12, align 8
  %v55 = load i64, ptr %slot12, align 8
  %v56 = load i64, ptr %slot5, align 8
  %p57 = inttoptr i64 %v56 to ptr
  store i64 %v55, ptr %p57, align 8, !alias.scope !3, !noalias !4
  %v58 = load i64, ptr %slot5, align 8
  %p59 = inttoptr i64 %v58 to ptr
  %ld60 = load i64, ptr %p59, align 8, !alias.scope !3, !noalias !4
  store i64 %ld60, ptr %slot14, align 8
  %v61 = load i64, ptr %slot1, align 8
  %v62 = load i64, ptr %slot14, align 8
  %call63 = call i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64 %v61, i64 %v62) nomerge, !dbg !114
  store i64 %call63, ptr %slot15, align 8
  %v64 = load i64, ptr %slot15, align 8
  %v65 = load i64, ptr %slot5, align 8
  %p66 = inttoptr i64 %v65 to ptr
  store i64 %v64, ptr %p66, align 8, !alias.scope !3, !noalias !4
  %v67 = load i64, ptr %slot5, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %ld69 = load i64, ptr %p68, align 8, !alias.scope !3, !noalias !4
  store i64 %ld69, ptr %slot16, align 8
  %v70 = load i64, ptr %slot16, align 8
  ret i64 %v70
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64, i64)
declare { i64, i64 } @myl_f_cb51e0dd7840af78b8d3f65cd883ca525c8c73ff445227a508c4c557b220dad4(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d", linkageName: "myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4532671777719538202, i64 0, !"myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
