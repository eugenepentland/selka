target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_a62237a217de3982fbfb627a26b10e96a04d1ecfbbb6de64b0c4ab216d4aa7d4(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v31 = load i64, ptr %slot1, align 8
  %op32 = add i64 %v31, 32
  store i64 %op32, ptr %slot3, align 8
  %mem33 = alloca i8, i64 8, align 8
  %ptr34 = ptrtoint ptr %mem33 to i64
  store i64 %ptr34, ptr %slot4, align 8
  %mem35 = alloca i8, i64 8, align 8
  %ptr36 = ptrtoint ptr %mem35 to i64
  store i64 %ptr36, ptr %slot5, align 8
  %mem37 = alloca i8, i64 8, align 8
  %ptr38 = ptrtoint ptr %mem37 to i64
  store i64 %ptr38, ptr %slot6, align 8
  %mem39 = alloca i8, i64 8, align 8
  %ptr40 = ptrtoint ptr %mem39 to i64
  store i64 %ptr40, ptr %slot7, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem41 = alloca i8, i64 8, align 8
  %ptr42 = ptrtoint ptr %mem41 to i64
  store i64 %ptr42, ptr %slot8, align 8
  %v43 = load i64, ptr %slot1, align 8
  %op44 = add i64 %v43, 64
  store i64 %op44, ptr %slot9, align 8
  %v45 = load i64, ptr %slot9, align 8
  %p46 = inttoptr i64 %v45 to ptr
  %ld47 = load i64, ptr %p46, align 8, !alias.scope !4, !noalias !3
  store i64 %ld47, ptr %slot10, align 8
  %stack48 = call ptr @llvm.stacksave()
  %stackaddr49 = ptrtoint ptr %stack48 to i64
  %v50 = load i64, ptr %slot10, align 8
  %cmp51 = icmp ult i64 %stackaddr49, %v50
  %cv52 = zext i1 %cmp51 to i64
  store i64 %cv52, ptr %slot11, align 8
  %v53 = load i64, ptr %slot11, align 8
  %cond54 = icmp ne i64 %v53, 0
  br i1 %cond54, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v55 = load i64, ptr %slot1, align 8
  %p56 = inttoptr i64 %v55 to ptr
  call void @myl_qbe_fail_frame(ptr %p56) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v57 = load i64, ptr %slot2, align 8
  %v58 = load i64, ptr %slot4, align 8
  %p59 = inttoptr i64 %v58 to ptr
  store i64 %v57, ptr %p59, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v60 = load i64, ptr %slot4, align 8
  %p61 = inttoptr i64 %v60 to ptr
  %ld62 = load i64, ptr %p61, align 8, !alias.scope !3, !noalias !4
  store i64 %ld62, ptr %slot12, align 8
  %v63 = load i64, ptr %slot12, align 8
  %v64 = load i64, ptr %slot6, align 8
  %p65 = inttoptr i64 %v64 to ptr
  store i64 %v63, ptr %p65, align 8, !alias.scope !3, !noalias !4
  %v66 = load i64, ptr %slot7, align 8
  %p67 = inttoptr i64 %v66 to ptr
  store i64 26, ptr %p67, align 8, !alias.scope !3, !noalias !4
  %v68 = load i64, ptr %slot6, align 8
  %p69 = inttoptr i64 %v68 to ptr
  %ld70 = load i64, ptr %p69, align 8, !alias.scope !3, !noalias !4
  store i64 %ld70, ptr %slot13, align 8
  %v71 = load i64, ptr %slot7, align 8
  %p72 = inttoptr i64 %v71 to ptr
  %ld73 = load i64, ptr %p72, align 8, !alias.scope !3, !noalias !4
  store i64 %ld73, ptr %slot14, align 8
  %v74 = load i64, ptr %slot1, align 8
  %v75 = load i64, ptr %slot13, align 8
  %v76 = load i64, ptr %slot14, align 8
  %call77 = call i64 @myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd(i64 %v74, i64 %v75, i64 %v76) nomerge, !dbg !112
  store i64 %call77, ptr %slot15, align 8
  %v78 = load i64, ptr %slot15, align 8
  %v79 = load i64, ptr %slot6, align 8
  %p80 = inttoptr i64 %v79 to ptr
  store i64 %v78, ptr %p80, align 8, !alias.scope !3, !noalias !4
  %v81 = load i64, ptr %slot6, align 8
  %p82 = inttoptr i64 %v81 to ptr
  %ld83 = load i64, ptr %p82, align 8, !alias.scope !3, !noalias !4
  store i64 %ld83, ptr %slot16, align 8
  %v84 = load i64, ptr %slot16, align 8
  %v85 = load i64, ptr %slot5, align 8
  %p86 = inttoptr i64 %v85 to ptr
  store i64 %v84, ptr %p86, align 8, !alias.scope !3, !noalias !4
  %v87 = load i64, ptr %slot4, align 8
  %p88 = inttoptr i64 %v87 to ptr
  %ld89 = load i64, ptr %p88, align 8, !alias.scope !3, !noalias !4
  store i64 %ld89, ptr %slot17, align 8
  %v90 = load i64, ptr %slot17, align 8
  %v91 = load i64, ptr %slot6, align 8
  %p92 = inttoptr i64 %v91 to ptr
  store i64 %v90, ptr %p92, align 8, !alias.scope !3, !noalias !4
  %v93 = load i64, ptr %slot7, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i64 4, ptr %p94, align 8, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot6, align 8
  %p96 = inttoptr i64 %v95 to ptr
  %ld97 = load i64, ptr %p96, align 8, !alias.scope !3, !noalias !4
  store i64 %ld97, ptr %slot18, align 8
  %v98 = load i64, ptr %slot7, align 8
  %p99 = inttoptr i64 %v98 to ptr
  %ld100 = load i64, ptr %p99, align 8, !alias.scope !3, !noalias !4
  store i64 %ld100, ptr %slot19, align 8
  %v101 = load i64, ptr %slot1, align 8
  %v102 = load i64, ptr %slot18, align 8
  %v103 = load i64, ptr %slot19, align 8
  %call104 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v101, i64 %v102, i64 %v103) nomerge, !dbg !114
  store i64 %call104, ptr %slot20, align 8
  %v105 = load i64, ptr %slot20, align 8
  %v106 = load i64, ptr %slot6, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i64 %v105, ptr %p107, align 8, !alias.scope !3, !noalias !4
  %v108 = load i64, ptr %slot4, align 8
  %p109 = inttoptr i64 %v108 to ptr
  %ld110 = load i64, ptr %p109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld110, ptr %slot21, align 8
  %v111 = load i64, ptr %slot21, align 8
  %v112 = load i64, ptr %slot6, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 %v111, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot7, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 3, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot6, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot22, align 8
  %v119 = load i64, ptr %slot7, align 8
  %p120 = inttoptr i64 %v119 to ptr
  %ld121 = load i64, ptr %p120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld121, ptr %slot23, align 8
  %v122 = load i64, ptr %slot1, align 8
  %v123 = load i64, ptr %slot22, align 8
  %v124 = load i64, ptr %slot23, align 8
  %call125 = call i64 @myl_f_46a59f8862e37daa969cb4df4cc800faed429195ebd08b19eb8f05429bb98d66(i64 %v122, i64 %v123, i64 %v124) nomerge, !dbg !116
  store i64 %call125, ptr %slot24, align 8
  %v126 = load i64, ptr %slot24, align 8
  %v127 = load i64, ptr %slot6, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 %v126, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot4, align 8
  %p130 = inttoptr i64 %v129 to ptr
  %ld131 = load i64, ptr %p130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld131, ptr %slot25, align 8
  %v132 = load i64, ptr %slot25, align 8
  %v133 = load i64, ptr %slot6, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i64 %v132, ptr %p134, align 8, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot5, align 8
  %p136 = inttoptr i64 %v135 to ptr
  %ld137 = load i64, ptr %p136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld137, ptr %slot26, align 8
  %v138 = load i64, ptr %slot26, align 8
  %v139 = load i64, ptr %slot7, align 8
  %p140 = inttoptr i64 %v139 to ptr
  store i64 %v138, ptr %p140, align 8, !alias.scope !3, !noalias !4
  %v141 = load i64, ptr %slot6, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %ld143 = load i64, ptr %p142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld143, ptr %slot27, align 8
  %v144 = load i64, ptr %slot7, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld146, ptr %slot28, align 8
  %v147 = load i64, ptr %slot1, align 8
  %v148 = load i64, ptr %slot27, align 8
  %v149 = load i64, ptr %slot28, align 8
  %call150 = call i64 @myl_f_c72c06ab3343e69c1ed6db828ac50a49dff722092c98b646b2bb7ddde6931cfb(i64 %v147, i64 %v148, i64 %v149) nomerge, !dbg !118
  store i64 %call150, ptr %slot29, align 8
  %v151 = load i64, ptr %slot29, align 8
  %v152 = load i64, ptr %slot6, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 %v151, ptr %p153, align 8, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot6, align 8
  %p155 = inttoptr i64 %v154 to ptr
  store i64 0, ptr %p155, align 8, !alias.scope !3, !noalias !4
  %v156 = load i64, ptr %slot6, align 8
  %p157 = inttoptr i64 %v156 to ptr
  %ld158 = load i64, ptr %p157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld158, ptr %slot30, align 8
  %v159 = load i64, ptr %slot30, align 8
  ret i64 %v159
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare i64 @myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd(i64, i64, i64)
declare i64 @myl_f_46a59f8862e37daa969cb4df4cc800faed429195ebd08b19eb8f05429bb98d66(i64, i64, i64)
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare i64 @myl_f_c72c06ab3343e69c1ed6db828ac50a49dff722092c98b646b2bb7ddde6931cfb(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a62237a217de3982fbfb627a26b10e96a04d1ecfbbb6de64b0c4ab216d4aa7d4", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a62237a217de3982fbfb627a26b10e96a04d1ecfbbb6de64b0c4ab216d4aa7d4", linkageName: "myl_f_a62237a217de3982fbfb627a26b10e96a04d1ecfbbb6de64b0c4ab216d4aa7d4", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10964489372684200944, i64 0, !"myl_f_a62237a217de3982fbfb627a26b10e96a04d1ecfbbb6de64b0c4ab216d4aa7d4"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!114 = !DILocation(line: 7, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!116 = !DILocation(line: 11, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!118 = !DILocation(line: 15, column: 0, scope: !119)
