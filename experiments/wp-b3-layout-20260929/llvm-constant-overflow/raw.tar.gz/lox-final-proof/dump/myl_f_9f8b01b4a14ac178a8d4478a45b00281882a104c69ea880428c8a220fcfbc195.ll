target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_9f8b01b4a14ac178a8d4478a45b00281882a104c69ea880428c8a220fcfbc195(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i32, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i32, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i32, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i32, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i32, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i32, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i32, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i32, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i32, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i32, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i32, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i32, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i32, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i32, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i32, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i32, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i32, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i32, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i32, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i32, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i32, align 8
  %slot1170 = alloca i32, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i32, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i32, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i32, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i32, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i32, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i32, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i32, align 8
  %slot1200 = alloca i32, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i32, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i32, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i32, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i32, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i32, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i32, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i32, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i32, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i32, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i32, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i32, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i32, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i32, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i32, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i32, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i32, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i32, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i32, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i32, align 8
  %slot1301 = alloca i32, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i32, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i32, align 8
  %slot1307 = alloca i32, align 8
  %slot1308 = alloca i32, align 8
  %slot1309 = alloca i32, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i32, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i32, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i32, align 8
  %slot1328 = alloca i32, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i32, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i32, align 8
  %slot1341 = alloca i32, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i32, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i32, align 8
  %slot1346 = alloca i32, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i32, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i32, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i32, align 8
  %slot1354 = alloca i32, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i32, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i32, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i32, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i32, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i32, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i32, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i32, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i32, align 8
  %slot1400 = alloca i32, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i32, align 8
  %slot1407 = alloca i32, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i32, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i64, align 8
  %slot1412 = alloca i32, align 8
  %slot1413 = alloca i32, align 8
  %slot1414 = alloca i32, align 8
  %slot1415 = alloca i32, align 8
  %slot1416 = alloca i32, align 8
  %slot1417 = alloca i32, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i32, align 8
  %slot1421 = alloca i32, align 8
  %slot1422 = alloca i32, align 8
  %slot1423 = alloca i32, align 8
  %slot1424 = alloca i64, align 8
  %slot1425 = alloca i32, align 8
  %slot1426 = alloca i32, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i32, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i32, align 8
  %slot1432 = alloca i32, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i32, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i32, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i32, align 8
  %slot1444 = alloca i32, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i64, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i64, align 8
  %slot1450 = alloca i64, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i32, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i32, align 8
  %slot1459 = alloca i64, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i32, align 8
  %slot1463 = alloca i32, align 8
  %slot1464 = alloca i32, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i32, align 8
  %slot1467 = alloca i32, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i32, align 8
  %slot1473 = alloca i64, align 8
  %slot1474 = alloca i64, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i32, align 8
  %slot1477 = alloca i64, align 8
  %slot1478 = alloca i32, align 8
  %slot1479 = alloca i32, align 8
  %slot1480 = alloca i64, align 8
  %slot1481 = alloca i64, align 8
  %slot1482 = alloca i32, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i64, align 8
  %slot1485 = alloca i64, align 8
  %slot1486 = alloca i32, align 8
  %slot1487 = alloca i64, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i32, align 8
  %slot1491 = alloca i64, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i32, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i64, align 8
  %slot1496 = alloca i32, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i32, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i32, align 8
  %slot1505 = alloca i64, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i32, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i64, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i32, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i64, align 8
  %slot1516 = alloca i32, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i64, align 8
  %slot1519 = alloca i32, align 8
  %slot1520 = alloca i32, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i64, align 8
  %slot1523 = alloca i32, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i32, align 8
  %slot1526 = alloca i32, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i64, align 8
  %slot1529 = alloca i32, align 8
  %slot1530 = alloca i64, align 8
  %slot1531 = alloca i64, align 8
  %slot1532 = alloca i64, align 8
  %slot1533 = alloca i32, align 8
  %slot1534 = alloca i64, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i64, align 8
  %slot1537 = alloca i32, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i64, align 8
  %slot1540 = alloca i32, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i32, align 8
  %slot1544 = alloca i64, align 8
  %slot1545 = alloca i64, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i32, align 8
  %slot1548 = alloca i64, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i64, align 8
  %slot1551 = alloca i32, align 8
  %slot1552 = alloca i64, align 8
  %slot1553 = alloca i64, align 8
  %slot1554 = alloca i32, align 8
  %slot1555 = alloca i64, align 8
  %slot1556 = alloca i64, align 8
  %slot1557 = alloca i64, align 8
  %slot1558 = alloca i64, align 8
  %slot1559 = alloca i64, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i64, align 8
  %slot1562 = alloca i64, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i32, align 8
  %slot1566 = alloca i32, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i64, align 8
  %slot1569 = alloca i64, align 8
  %slot1570 = alloca i32, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i32, align 8
  %slot1573 = alloca i64, align 8
  %slot1574 = alloca i64, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i32, align 8
  %slot1577 = alloca i64, align 8
  %slot1578 = alloca i64, align 8
  %slot1579 = alloca i64, align 8
  %slot1580 = alloca i64, align 8
  %slot1581 = alloca i32, align 8
  %slot1582 = alloca i64, align 8
  %slot1583 = alloca i64, align 8
  %slot1584 = alloca i64, align 8
  %slot1585 = alloca i32, align 8
  %slot1586 = alloca i64, align 8
  %slot1587 = alloca i64, align 8
  %slot1588 = alloca i32, align 8
  %slot1589 = alloca i32, align 8
  %slot1590 = alloca i32, align 8
  %slot1591 = alloca i64, align 8
  %slot1592 = alloca i64, align 8
  %slot1593 = alloca i32, align 8
  %slot1594 = alloca i64, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i32, align 8
  %slot1597 = alloca i64, align 8
  %slot1598 = alloca i64, align 8
  %slot1599 = alloca i64, align 8
  %slot1600 = alloca i32, align 8
  %slot1601 = alloca i64, align 8
  %slot1602 = alloca i64, align 8
  %slot1603 = alloca i32, align 8
  %slot1604 = alloca i64, align 8
  %slot1605 = alloca i64, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i64, align 8
  %slot1608 = alloca i64, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i64, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i64, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i64, align 8
  %slot1616 = alloca i64, align 8
  %slot1617 = alloca i64, align 8
  %slot1618 = alloca i32, align 8
  %slot1619 = alloca i64, align 8
  %slot1620 = alloca i64, align 8
  %slot1621 = alloca i64, align 8
  %slot1622 = alloca i64, align 8
  %slot1623 = alloca i64, align 8
  %slot1624 = alloca i64, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i64, align 8
  %slot1627 = alloca i64, align 8
  %slot1628 = alloca i64, align 8
  %slot1629 = alloca i64, align 8
  %slot1630 = alloca i64, align 8
  %slot1631 = alloca i64, align 8
  %slot1632 = alloca i64, align 8
  %slot1633 = alloca i32, align 8
  %slot1634 = alloca i64, align 8
  %slot1635 = alloca i64, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i32, align 8
  %slot1638 = alloca i64, align 8
  %slot1639 = alloca i32, align 8
  %slot1640 = alloca i32, align 8
  %slot1641 = alloca i64, align 8
  %slot1642 = alloca i64, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i64, align 8
  %slot1645 = alloca i64, align 8
  %slot1646 = alloca i64, align 8
  %slot1647 = alloca i64, align 8
  %slot1648 = alloca i64, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i64, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i64, align 8
  %slot1653 = alloca i64, align 8
  %slot1654 = alloca i64, align 8
  %slot1655 = alloca i64, align 8
  %slot1656 = alloca i64, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i64, align 8
  %slot1659 = alloca i64, align 8
  %slot1660 = alloca i64, align 8
  %slot1661 = alloca i64, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i64, align 8
  %slot1664 = alloca i64, align 8
  %slot1665 = alloca i64, align 8
  %slot1666 = alloca i64, align 8
  %slot1667 = alloca i64, align 8
  %slot1668 = alloca i64, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i32, align 8
  %slot1671 = alloca i32, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i32, align 8
  %slot1674 = alloca i32, align 8
  %slot1675 = alloca i64, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i64, align 8
  %slot1678 = alloca i64, align 8
  %slot1679 = alloca i32, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i64, align 8
  %slot1682 = alloca i64, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i32, align 8
  %slot1685 = alloca i64, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i32, align 8
  %slot1688 = alloca i64, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i32, align 8
  %slot1691 = alloca i64, align 8
  %slot1692 = alloca i64, align 8
  %slot1693 = alloca i32, align 8
  %slot1694 = alloca i64, align 8
  %slot1695 = alloca i64, align 8
  %slot1696 = alloca i32, align 8
  %slot1697 = alloca i64, align 8
  %slot1698 = alloca i64, align 8
  %slot1699 = alloca i32, align 8
  %slot1700 = alloca i64, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i64, align 8
  %slot1703 = alloca i32, align 8
  %slot1704 = alloca i64, align 8
  %slot1705 = alloca i64, align 8
  %slot1706 = alloca i32, align 8
  %slot1707 = alloca i64, align 8
  %slot1708 = alloca i64, align 8
  %slot1709 = alloca i32, align 8
  %slot1710 = alloca i32, align 8
  %slot1711 = alloca i32, align 8
  %slot1712 = alloca i64, align 8
  %slot1713 = alloca i64, align 8
  %slot1714 = alloca i32, align 8
  %slot1715 = alloca i64, align 8
  %slot1716 = alloca i64, align 8
  %slot1717 = alloca i64, align 8
  %slot1718 = alloca i32, align 8
  %slot1719 = alloca i64, align 8
  %slot1720 = alloca i64, align 8
  %slot1721 = alloca i32, align 8
  %slot1722 = alloca i64, align 8
  %slot1723 = alloca i64, align 8
  %slot1724 = alloca i32, align 8
  %slot1725 = alloca i32, align 8
  %slot1726 = alloca i32, align 8
  %slot1727 = alloca i64, align 8
  %slot1728 = alloca i32, align 8
  %slot1729 = alloca i64, align 8
  %slot1730 = alloca i64, align 8
  %slot1731 = alloca i64, align 8
  %slot1732 = alloca i64, align 8
  %slot1733 = alloca i64, align 8
  %slot1734 = alloca i64, align 8
  %slot1735 = alloca i64, align 8
  %slot1736 = alloca i64, align 8
  %slot1737 = alloca i64, align 8
  %slot1738 = alloca i64, align 8
  %slot1739 = alloca i64, align 8
  %slot1740 = alloca i64, align 8
  %slot1741 = alloca i64, align 8
  %slot1742 = alloca i64, align 8
  %slot1743 = alloca i64, align 8
  %slot1744 = alloca i64, align 8
  %slot1745 = alloca i64, align 8
  %slot1746 = alloca i64, align 8
  %slot1747 = alloca i64, align 8
  %slot1748 = alloca i32, align 8
  %slot1749 = alloca i64, align 8
  %slot1750 = alloca i64, align 8
  %slot1751 = alloca i64, align 8
  %slot1752 = alloca i64, align 8
  %slot1753 = alloca i64, align 8
  %slot1754 = alloca i64, align 8
  %slot1755 = alloca i64, align 8
  %slot1756 = alloca i64, align 8
  %slot1757 = alloca i64, align 8
  %slot1758 = alloca i64, align 8
  %slot1759 = alloca i64, align 8
  %slot1760 = alloca i64, align 8
  %slot1761 = alloca i64, align 8
  %slot1762 = alloca i64, align 8
  %slot1763 = alloca i32, align 8
  %slot1764 = alloca i64, align 8
  %slot1765 = alloca i32, align 8
  %slot1766 = alloca i32, align 8
  %slot1767 = alloca i64, align 8
  %slot1768 = alloca i32, align 8
  %slot1769 = alloca i32, align 8
  %slot1770 = alloca i64, align 8
  %slot1771 = alloca i64, align 8
  %slot1772 = alloca i64, align 8
  %slot1773 = alloca i32, align 8
  %slot1774 = alloca i32, align 8
  %slot1775 = alloca i64, align 8
  %slot1776 = alloca i32, align 8
  %slot1777 = alloca i32, align 8
  %slot1778 = alloca i64, align 8
  %slot1779 = alloca i64, align 8
  %slot1780 = alloca i32, align 8
  %slot1781 = alloca i64, align 8
  %slot1782 = alloca i32, align 8
  %slot1783 = alloca i32, align 8
  %slot1784 = alloca i64, align 8
  %slot1785 = alloca i64, align 8
  %slot1786 = alloca i32, align 8
  %slot1787 = alloca i64, align 8
  %slot1788 = alloca i32, align 8
  %slot1789 = alloca i32, align 8
  %slot1790 = alloca i64, align 8
  %slot1791 = alloca i64, align 8
  %slot1792 = alloca i32, align 8
  %slot1793 = alloca i64, align 8
  %slot1794 = alloca i32, align 8
  %slot1795 = alloca i32, align 8
  %slot1796 = alloca i64, align 8
  %slot1797 = alloca i64, align 8
  %slot1798 = alloca i32, align 8
  %slot1799 = alloca i64, align 8
  %slot1800 = alloca i64, align 8
  %slot1801 = alloca i64, align 8
  %slot1802 = alloca i32, align 8
  %slot1803 = alloca i64, align 8
  %slot1804 = alloca i64, align 8
  %slot1805 = alloca i64, align 8
  %slot1806 = alloca i32, align 8
  %slot1807 = alloca i64, align 8
  %slot1808 = alloca i64, align 8
  %slot1809 = alloca i32, align 8
  %slot1810 = alloca i64, align 8
  %slot1811 = alloca i64, align 8
  %slot1812 = alloca i32, align 8
  %slot1813 = alloca i64, align 8
  %slot1814 = alloca i64, align 8
  %slot1815 = alloca i64, align 8
  %slot1816 = alloca i32, align 8
  %slot1817 = alloca i64, align 8
  %slot1818 = alloca i64, align 8
  %slot1819 = alloca i64, align 8
  %slot1820 = alloca i32, align 8
  %slot1821 = alloca i64, align 8
  %slot1822 = alloca i64, align 8
  %slot1823 = alloca i32, align 8
  %slot1824 = alloca i32, align 8
  %slot1825 = alloca i64, align 8
  %slot1826 = alloca i32, align 8
  %slot1827 = alloca i32, align 8
  %slot1828 = alloca i64, align 8
  %slot1829 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  %v1830 = load i64, ptr %slot1, align 8
  %op1831 = add i64 %v1830, 32
  store i64 %op1831, ptr %slot6, align 8
  %mem1832 = alloca i8, i64 8, align 8
  %ptr1833 = ptrtoint ptr %mem1832 to i64
  store i64 %ptr1833, ptr %slot7, align 8
  %mem1834 = alloca i8, i64 8, align 8
  %ptr1835 = ptrtoint ptr %mem1834 to i64
  store i64 %ptr1835, ptr %slot8, align 8
  %mem1836 = alloca i8, i64 8, align 8
  %ptr1837 = ptrtoint ptr %mem1836 to i64
  store i64 %ptr1837, ptr %slot9, align 8
  %mem1838 = alloca i8, i64 8, align 8
  %ptr1839 = ptrtoint ptr %mem1838 to i64
  store i64 %ptr1839, ptr %slot10, align 8
  %mem1840 = alloca i8, i64 8, align 8
  %ptr1841 = ptrtoint ptr %mem1840 to i64
  store i64 %ptr1841, ptr %slot11, align 8
  %mem1842 = alloca i8, i64 8, align 8
  %ptr1843 = ptrtoint ptr %mem1842 to i64
  store i64 %ptr1843, ptr %slot12, align 8
  %mem1844 = alloca i8, i64 8, align 8
  %ptr1845 = ptrtoint ptr %mem1844 to i64
  store i64 %ptr1845, ptr %slot13, align 8
  %mem1846 = alloca i8, i64 8, align 8
  %ptr1847 = ptrtoint ptr %mem1846 to i64
  store i64 %ptr1847, ptr %slot14, align 8
  %mem1848 = alloca i8, i64 8, align 8
  %ptr1849 = ptrtoint ptr %mem1848 to i64
  store i64 %ptr1849, ptr %slot15, align 8
  %mem1850 = alloca i8, i64 8, align 8
  %ptr1851 = ptrtoint ptr %mem1850 to i64
  store i64 %ptr1851, ptr %slot16, align 8
  %mem1852 = alloca i8, i64 8, align 8
  %ptr1853 = ptrtoint ptr %mem1852 to i64
  store i64 %ptr1853, ptr %slot17, align 8
  %mem1854 = alloca i8, i64 8, align 8
  %ptr1855 = ptrtoint ptr %mem1854 to i64
  store i64 %ptr1855, ptr %slot18, align 8
  %mem1856 = alloca i8, i64 8, align 8
  %ptr1857 = ptrtoint ptr %mem1856 to i64
  store i64 %ptr1857, ptr %slot19, align 8
  %mem1858 = alloca i8, i64 8, align 8
  %ptr1859 = ptrtoint ptr %mem1858 to i64
  store i64 %ptr1859, ptr %slot20, align 8
  %mem1860 = alloca i8, i64 8, align 8
  %ptr1861 = ptrtoint ptr %mem1860 to i64
  store i64 %ptr1861, ptr %slot21, align 8
  %mem1862 = alloca i8, i64 8, align 8
  %ptr1863 = ptrtoint ptr %mem1862 to i64
  store i64 %ptr1863, ptr %slot22, align 8
  %mem1864 = alloca i8, i64 8, align 8
  %ptr1865 = ptrtoint ptr %mem1864 to i64
  store i64 %ptr1865, ptr %slot23, align 8
  %mem1866 = alloca i8, i64 392, align 8
  %ptr1867 = ptrtoint ptr %mem1866 to i64
  store i64 %ptr1867, ptr %slot24, align 8
  %mem1868 = alloca i8, i64 88, align 8
  %ptr1869 = ptrtoint ptr %mem1868 to i64
  store i64 %ptr1869, ptr %slot25, align 8
  %mem1870 = alloca i8, i64 8, align 8
  %ptr1871 = ptrtoint ptr %mem1870 to i64
  store i64 %ptr1871, ptr %slot26, align 8
  %mem1872 = alloca i8, i64 8, align 8
  %ptr1873 = ptrtoint ptr %mem1872 to i64
  store i64 %ptr1873, ptr %slot27, align 8
  %mem1874 = alloca i8, i64 392, align 8
  %ptr1875 = ptrtoint ptr %mem1874 to i64
  store i64 %ptr1875, ptr %slot28, align 8
  %mem1876 = alloca i8, i64 32, align 8
  %ptr1877 = ptrtoint ptr %mem1876 to i64
  store i64 %ptr1877, ptr %slot29, align 8
  %v1878 = load i64, ptr %slot29, align 8
  %p1880 = inttoptr i64 %v1878 to ptr
  %gep1881 = getelementptr i8, ptr %p1880, i64 24
  %op1879 = ptrtoint ptr %gep1881 to i64
  store i64 %op1879, ptr %slot30, align 8
  %v1882 = load i64, ptr %slot30, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  store i64 0, ptr %p1883, align 8, !alias.scope !3, !noalias !4
  %mem1884 = alloca i8, i64 32, align 8
  %ptr1885 = ptrtoint ptr %mem1884 to i64
  store i64 %ptr1885, ptr %slot31, align 8
  %v1886 = load i64, ptr %slot31, align 8
  %p1888 = inttoptr i64 %v1886 to ptr
  %gep1889 = getelementptr i8, ptr %p1888, i64 24
  %op1887 = ptrtoint ptr %gep1889 to i64
  store i64 %op1887, ptr %slot32, align 8
  %v1890 = load i64, ptr %slot32, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  store i64 0, ptr %p1891, align 8, !alias.scope !3, !noalias !4
  %mem1892 = alloca i8, i64 32, align 8
  %ptr1893 = ptrtoint ptr %mem1892 to i64
  store i64 %ptr1893, ptr %slot33, align 8
  %v1894 = load i64, ptr %slot33, align 8
  %p1896 = inttoptr i64 %v1894 to ptr
  %gep1897 = getelementptr i8, ptr %p1896, i64 24
  %op1895 = ptrtoint ptr %gep1897 to i64
  store i64 %op1895, ptr %slot34, align 8
  %v1898 = load i64, ptr %slot34, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  store i64 0, ptr %p1899, align 8, !alias.scope !3, !noalias !4
  %mem1900 = alloca i8, i64 24, align 8
  %ptr1901 = ptrtoint ptr %mem1900 to i64
  store i64 %ptr1901, ptr %slot35, align 8
  %mem1902 = alloca i8, i64 8, align 8
  %ptr1903 = ptrtoint ptr %mem1902 to i64
  store i64 %ptr1903, ptr %slot36, align 8
  %mem1904 = alloca i8, i64 8, align 8
  %ptr1905 = ptrtoint ptr %mem1904 to i64
  store i64 %ptr1905, ptr %slot37, align 8
  %mem1906 = alloca i8, i64 8, align 8
  %ptr1907 = ptrtoint ptr %mem1906 to i64
  store i64 %ptr1907, ptr %slot38, align 8
  %mem1908 = alloca i8, i64 8, align 8
  %ptr1909 = ptrtoint ptr %mem1908 to i64
  store i64 %ptr1909, ptr %slot39, align 8
  %mem1910 = alloca i8, i64 8, align 8
  %ptr1911 = ptrtoint ptr %mem1910 to i64
  store i64 %ptr1911, ptr %slot40, align 8
  %mem1912 = alloca i8, i64 8, align 8
  %ptr1913 = ptrtoint ptr %mem1912 to i64
  store i64 %ptr1913, ptr %slot41, align 8
  %mem1914 = alloca i8, i64 88, align 8
  %ptr1915 = ptrtoint ptr %mem1914 to i64
  store i64 %ptr1915, ptr %slot42, align 8
  %mem1916 = alloca i8, i64 8, align 8
  %ptr1917 = ptrtoint ptr %mem1916 to i64
  store i64 %ptr1917, ptr %slot43, align 8
  %mem1918 = alloca i8, i64 8, align 8
  %ptr1919 = ptrtoint ptr %mem1918 to i64
  store i64 %ptr1919, ptr %slot44, align 8
  %mem1920 = alloca i8, i64 8, align 8
  %ptr1921 = ptrtoint ptr %mem1920 to i64
  store i64 %ptr1921, ptr %slot45, align 8
  %mem1922 = alloca i8, i64 8, align 8
  %ptr1923 = ptrtoint ptr %mem1922 to i64
  store i64 %ptr1923, ptr %slot46, align 8
  %mem1924 = alloca i8, i64 16, align 8
  %ptr1925 = ptrtoint ptr %mem1924 to i64
  store i64 %ptr1925, ptr %slot47, align 8
  %mem1926 = alloca i8, i64 8, align 8
  %ptr1927 = ptrtoint ptr %mem1926 to i64
  store i64 %ptr1927, ptr %slot48, align 8
  %mem1928 = alloca i8, i64 88, align 8
  %ptr1929 = ptrtoint ptr %mem1928 to i64
  store i64 %ptr1929, ptr %slot49, align 8
  %mem1930 = alloca i8, i64 8, align 8
  %ptr1931 = ptrtoint ptr %mem1930 to i64
  store i64 %ptr1931, ptr %slot50, align 8
  %mem1932 = alloca i8, i64 8, align 8
  %ptr1933 = ptrtoint ptr %mem1932 to i64
  store i64 %ptr1933, ptr %slot51, align 8
  %mem1934 = alloca i8, i64 88, align 8
  %ptr1935 = ptrtoint ptr %mem1934 to i64
  store i64 %ptr1935, ptr %slot52, align 8
  %mem1936 = alloca i8, i64 8, align 8
  %ptr1937 = ptrtoint ptr %mem1936 to i64
  store i64 %ptr1937, ptr %slot53, align 8
  %mem1938 = alloca i8, i64 8, align 8
  %ptr1939 = ptrtoint ptr %mem1938 to i64
  store i64 %ptr1939, ptr %slot54, align 8
  %mem1940 = alloca i8, i64 56, align 8
  %ptr1941 = ptrtoint ptr %mem1940 to i64
  store i64 %ptr1941, ptr %slot55, align 8
  %mem1942 = alloca i8, i64 8, align 8
  %ptr1943 = ptrtoint ptr %mem1942 to i64
  store i64 %ptr1943, ptr %slot56, align 8
  %mem1944 = alloca i8, i64 8, align 8
  %ptr1945 = ptrtoint ptr %mem1944 to i64
  store i64 %ptr1945, ptr %slot57, align 8
  %mem1946 = alloca i8, i64 8, align 8
  %ptr1947 = ptrtoint ptr %mem1946 to i64
  store i64 %ptr1947, ptr %slot58, align 8
  %mem1948 = alloca i8, i64 8, align 8
  %ptr1949 = ptrtoint ptr %mem1948 to i64
  store i64 %ptr1949, ptr %slot59, align 8
  %mem1950 = alloca i8, i64 16, align 8
  %ptr1951 = ptrtoint ptr %mem1950 to i64
  store i64 %ptr1951, ptr %slot60, align 8
  %mem1952 = alloca i8, i64 88, align 8
  %ptr1953 = ptrtoint ptr %mem1952 to i64
  store i64 %ptr1953, ptr %slot61, align 8
  %mem1954 = alloca i8, i64 88, align 8
  %ptr1955 = ptrtoint ptr %mem1954 to i64
  store i64 %ptr1955, ptr %slot62, align 8
  %mem1956 = alloca i8, i64 56, align 8
  %ptr1957 = ptrtoint ptr %mem1956 to i64
  store i64 %ptr1957, ptr %slot63, align 8
  %mem1958 = alloca i8, i64 56, align 8
  %ptr1959 = ptrtoint ptr %mem1958 to i64
  store i64 %ptr1959, ptr %slot64, align 8
  br label %bb_frameadmit3
bb_frameadmit3:
  %mem1960 = alloca i8, i64 8, align 8
  %ptr1961 = ptrtoint ptr %mem1960 to i64
  store i64 %ptr1961, ptr %slot65, align 8
  %v1962 = load i64, ptr %slot1, align 8
  %op1963 = add i64 %v1962, 64
  store i64 %op1963, ptr %slot66, align 8
  %v1964 = load i64, ptr %slot66, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %ld1966 = load i64, ptr %p1965, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1966, ptr %slot67, align 8
  %stack1967 = call ptr @llvm.stacksave()
  %stackaddr1968 = ptrtoint ptr %stack1967 to i64
  %v1969 = load i64, ptr %slot67, align 8
  %cmp1970 = icmp ult i64 %stackaddr1968, %v1969
  %cv1971 = zext i1 %cmp1970 to i64
  store i64 %cv1971, ptr %slot68, align 8
  %v1972 = load i64, ptr %slot68, align 8
  %cond1973 = icmp ne i64 %v1972, 0
  br i1 %cond1973, label %bb_floorfail5, label %bb_stackadmit4
bb_floorfail5:
  %v1974 = load i64, ptr %slot1, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  call void @myl_qbe_fail_frame(ptr %p1975) nomerge, !dbg !110
  unreachable
bb_stackadmit4:
  %mem1976 = alloca i8, i64 88, align 8
  %ptr1977 = ptrtoint ptr %mem1976 to i64
  store i64 %ptr1977, ptr %slot69, align 8
  %v1978 = load i64, ptr %slot40, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  store i64 0, ptr %p1979, align 8, !alias.scope !3, !noalias !4
  %v1980 = load i64, ptr %slot45, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  store i64 0, ptr %p1981, align 8, !alias.scope !3, !noalias !4
  %v1982 = load i64, ptr %slot48, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  store i64 0, ptr %p1983, align 8, !alias.scope !3, !noalias !4
  %v1984 = load i64, ptr %slot51, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  store i64 0, ptr %p1985, align 8, !alias.scope !3, !noalias !4
  %v1986 = load i64, ptr %slot54, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  store i64 0, ptr %p1987, align 8, !alias.scope !3, !noalias !4
  %v1988 = load i64, ptr %slot2, align 8
  %v1989 = load i64, ptr %slot36, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  store i64 %v1988, ptr %p1990, align 8, !alias.scope !3, !noalias !4
  %v1991 = load i64, ptr %slot3, align 8
  %v1992 = load i64, ptr %slot37, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  store i64 %v1991, ptr %p1993, align 8, !alias.scope !3, !noalias !4
  %v1994 = load i64, ptr %slot4, align 8
  %v1995 = load i64, ptr %slot38, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i64 %v1994, ptr %p1996, align 8, !alias.scope !3, !noalias !4
  %v1997 = load i64, ptr %slot5, align 8
  %v1998 = load i64, ptr %slot39, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  store i64 %v1997, ptr %p1999, align 8, !alias.scope !3, !noalias !4
  %v2000 = load i64, ptr %slot1, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  %call2002 = call ptr @myl_qbe_heap(ptr %p2001) nomerge, !dbg !112
  %calladdr2003 = ptrtoint ptr %call2002 to i64
  store i64 %calladdr2003, ptr %slot70, align 8
  %v2004 = load i64, ptr %slot1, align 8
  %p2005 = inttoptr i64 %v2004 to ptr
  %call2006 = call i64 @myl_qbe_region_mark(ptr %p2005) nomerge, !dbg !112
  store i64 %call2006, ptr %slot71, align 8
  %v2007 = load i64, ptr %slot7, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  store i32 0, ptr %p2008, align 4, !alias.scope !3, !noalias !4
  %v2009 = load i64, ptr %slot8, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  store i32 0, ptr %p2010, align 4, !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot9, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  store i32 0, ptr %p2012, align 4, !alias.scope !3, !noalias !4
  %v2013 = load i64, ptr %slot10, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  store i32 0, ptr %p2014, align 4, !alias.scope !3, !noalias !4
  %v2015 = load i64, ptr %slot11, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  store i32 0, ptr %p2016, align 4, !alias.scope !3, !noalias !4
  %v2017 = load i64, ptr %slot12, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  store i32 0, ptr %p2018, align 4, !alias.scope !3, !noalias !4
  %v2019 = load i64, ptr %slot13, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  store i32 0, ptr %p2020, align 4, !alias.scope !3, !noalias !4
  %v2021 = load i64, ptr %slot14, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  store i32 0, ptr %p2022, align 4, !alias.scope !3, !noalias !4
  %v2023 = load i64, ptr %slot15, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i32 0, ptr %p2024, align 4, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot16, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  store i32 0, ptr %p2026, align 4, !alias.scope !3, !noalias !4
  %v2027 = load i64, ptr %slot17, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  store i32 0, ptr %p2028, align 4, !alias.scope !3, !noalias !4
  %v2029 = load i64, ptr %slot18, align 8
  %p2030 = inttoptr i64 %v2029 to ptr
  store i32 0, ptr %p2030, align 4, !alias.scope !3, !noalias !4
  %v2031 = load i64, ptr %slot19, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  store i32 0, ptr %p2032, align 4, !alias.scope !3, !noalias !4
  %v2033 = load i64, ptr %slot20, align 8
  %p2034 = inttoptr i64 %v2033 to ptr
  store i32 0, ptr %p2034, align 4, !alias.scope !3, !noalias !4
  %v2035 = load i64, ptr %slot21, align 8
  %p2036 = inttoptr i64 %v2035 to ptr
  store i32 0, ptr %p2036, align 4, !alias.scope !3, !noalias !4
  %v2037 = load i64, ptr %slot22, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  store i32 0, ptr %p2038, align 4, !alias.scope !3, !noalias !4
  %v2039 = load i64, ptr %slot23, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  store i32 0, ptr %p2040, align 4, !alias.scope !3, !noalias !4
  %v2041 = load i64, ptr %slot8, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  store i32 2, ptr %p2042, align 4, !alias.scope !3, !noalias !4
  %v2043 = load i64, ptr %slot10, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  store i32 2, ptr %p2044, align 4, !alias.scope !3, !noalias !4
  %v2045 = load i64, ptr %slot12, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  store i32 2, ptr %p2046, align 4, !alias.scope !3, !noalias !4
  %v2047 = load i64, ptr %slot14, align 8
  %p2048 = inttoptr i64 %v2047 to ptr
  store i32 2, ptr %p2048, align 4, !alias.scope !3, !noalias !4
  %v2049 = load i64, ptr %slot16, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i32 2, ptr %p2050, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v2051 = load i64, ptr %slot36, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  %ld2053 = load i64, ptr %p2052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2053, ptr %slot72, align 8
  %v2054 = load i64, ptr %slot72, align 8
  %v2055 = load i64, ptr %slot57, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  store i64 %v2054, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  %v2057 = load i64, ptr %slot57, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %ld2059 = load i64, ptr %p2058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2059, ptr %slot73, align 8
  %v2060 = load i64, ptr %slot73, align 8
  %op2061 = add i64 %v2060, 376
  store i64 %op2061, ptr %slot74, align 8
  %v2062 = load i64, ptr %slot74, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  %ld2064 = load i64, ptr %p2063, align 8
  store i64 %ld2064, ptr %slot75, align 8
  %v2065 = load i64, ptr %slot75, align 8
  %v2066 = load i64, ptr %slot57, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  store i64 %v2065, ptr %p2067, align 8, !alias.scope !3, !noalias !4
  %v2068 = load i64, ptr %slot17, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  %ld2070 = load i32, ptr %p2069, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2070, ptr %slot76, align 8
  %v2071 = load i32, ptr %slot76, align 8
  %cv2072 = zext i32 %v2071 to i64
  %cond2073 = icmp ne i64 %cv2072, 0
  br i1 %cond2073, label %bb_rcslotdrop26, label %bb_rcslotdone26
bb_rcslotdrop26:
  %v2074 = load i64, ptr %slot17, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i32 0, ptr %p2075, align 4, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot24, align 8
  store i64 %v2076, ptr %slot77, align 8
  %v2077 = load i64, ptr %slot18, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  %ld2079 = load i32, ptr %p2078, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2079, ptr %slot78, align 8
  %v2080 = load i32, ptr %slot78, align 8
  %op2081 = and i32 %v2080, 28
  store i32 %op2081, ptr %slot79, align 8
  %v2082 = load i32, ptr %slot79, align 8
  %cv2083 = zext i32 %v2082 to i64
  %cond2084 = icmp ne i64 %cv2083, 0
  br i1 %cond2084, label %bb_rcslotrole26, label %bb_rcslotowner26
bb_rcslotrole26:
  %v2085 = load i64, ptr %slot70, align 8
  store i64 %v2085, ptr %slot80, align 8
  %v2086 = load i64, ptr %slot80, align 8
  %v2087 = load i64, ptr %slot77, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2086, i64 %v2087) nomerge, !dbg !114
  br label %bb_rcslotdone26
bb_rcslotowner26:
  %v2088 = load i64, ptr %slot70, align 8
  store i64 %v2088, ptr %slot81, align 8
  %v2089 = load i64, ptr %slot81, align 8
  %v2090 = load i64, ptr %slot77, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2089, i64 %v2090) nomerge, !dbg !114
  br label %bb_rcslotdone26
bb_rcslotdone26:
  %v2091 = load i64, ptr %slot57, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %ld2093 = load i64, ptr %p2092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2093, ptr %slot82, align 8
  %v2094 = load i64, ptr %slot82, align 8
  %v2095 = load i64, ptr %slot40, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  store i64 %v2094, ptr %p2096, align 8, !alias.scope !3, !noalias !4
  %v2097 = load i64, ptr %slot37, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  %ld2099 = load i64, ptr %p2098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2099, ptr %slot83, align 8
  %v2100 = load i64, ptr %slot83, align 8
  %v2101 = load i64, ptr %slot57, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  store i64 %v2100, ptr %p2102, align 8, !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot57, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  %ld2105 = load i64, ptr %p2104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2105, ptr %slot84, align 8
  %v2106 = load i64, ptr %slot84, align 8
  %v2107 = load i64, ptr %slot41, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  store i64 %v2106, ptr %p2108, align 8, !alias.scope !3, !noalias !4
  %v2109 = load i64, ptr %slot41, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  %ld2111 = load i64, ptr %p2110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2111, ptr %slot85, align 8
  %v2112 = load i64, ptr %slot85, align 8
  %v2113 = load i64, ptr %slot57, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  store i64 %v2112, ptr %p2114, align 8, !alias.scope !3, !noalias !4
  %v2115 = load i64, ptr %slot58, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i64 0, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot58, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  %ld2119 = load i64, ptr %p2118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2119, ptr %slot86, align 8
  %v2120 = load i64, ptr %slot57, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  %ld2122 = load i64, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2122, ptr %slot87, align 8
  %v2123 = load i64, ptr %slot87, align 8
  %v2124 = load i64, ptr %slot86, align 8
  %cmp2125 = icmp slt i64 %v2123, %v2124
  %cv2126 = zext i1 %cmp2125 to i64
  store i64 %cv2126, ptr %slot88, align 8
  %v2127 = load i64, ptr %slot88, align 8
  %v2128 = load i64, ptr %slot57, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  store i64 %v2127, ptr %p2129, align 8, !alias.scope !3, !noalias !4
  %v2130 = load i64, ptr %slot57, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  %ld2132 = load i64, ptr %p2131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2132, ptr %slot89, align 8
  %v2133 = load i64, ptr %slot89, align 8
  %cond2134 = icmp ne i64 %v2133, 0
  br i1 %cond2134, label %bb_next41, label %bb_i14
bb_next41:
  %v2135 = load i64, ptr %slot40, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  %ld2137 = load i64, ptr %p2136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2137, ptr %slot90, align 8
  %v2138 = load i64, ptr %slot90, align 8
  %op2139 = add i64 %v2138, 0
  store i64 %op2139, ptr %slot91, align 8
  %v2140 = load i64, ptr %slot91, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %ld2142 = load i64, ptr %p2141, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2142, ptr %slot92, align 8
  %v2143 = load i64, ptr %slot92, align 8
  %v2144 = load i64, ptr %slot57, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  store i64 %v2143, ptr %p2145, align 8, !alias.scope !3, !noalias !4
  %v2146 = load i64, ptr %slot57, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  %ld2148 = load i64, ptr %p2147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2148, ptr %slot93, align 8
  %v2149 = load i64, ptr %slot93, align 8
  %cmp2150 = icmp ugt i64 %v2149, 9223372036854775807
  %cv2151 = zext i1 %cmp2150 to i64
  store i64 %cv2151, ptr %slot94, align 8
  %v2152 = load i64, ptr %slot94, align 8
  %cond2153 = icmp ne i64 %v2152, 0
  br i1 %cond2153, label %bb_cast_overflow46, label %bb_cast_ok46
bb_cast_overflow46:
  %v2154 = load i64, ptr %slot1, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  %v2156 = load i64, ptr %slot93, align 8
  call void @myl_qbe_fail_cast(ptr %p2155, i64 %v2156, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok46:
  %v2157 = load i64, ptr %slot93, align 8
  %v2158 = load i64, ptr %slot57, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  store i64 %v2157, ptr %p2159, align 8, !alias.scope !3, !noalias !4
  %v2160 = load i64, ptr %slot41, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  %ld2162 = load i64, ptr %p2161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2162, ptr %slot95, align 8
  %v2163 = load i64, ptr %slot95, align 8
  %v2164 = load i64, ptr %slot58, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  store i64 %v2163, ptr %p2165, align 8, !alias.scope !3, !noalias !4
  %v2166 = load i64, ptr %slot58, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %ld2168 = load i64, ptr %p2167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2168, ptr %slot96, align 8
  %v2169 = load i64, ptr %slot57, align 8
  %p2170 = inttoptr i64 %v2169 to ptr
  %ld2171 = load i64, ptr %p2170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2171, ptr %slot97, align 8
  %v2172 = load i64, ptr %slot97, align 8
  %v2173 = load i64, ptr %slot96, align 8
  %ovpair2175 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2172, i64 %v2173)
  %op2174 = extractvalue { i64, i1 } %ovpair2175, 0
  %ov2176 = extractvalue { i64, i1 } %ovpair2175, 1
  store i64 %op2174, ptr %slot98, align 8
  %v2177 = load i64, ptr %slot97, align 8
  %v2178 = load i64, ptr %slot98, align 8
  %op2179 = xor i64 %v2177, %v2178
  store i64 %op2179, ptr %slot99, align 8
  %v2180 = load i64, ptr %slot96, align 8
  %v2181 = load i64, ptr %slot98, align 8
  %op2182 = xor i64 %v2180, %v2181
  store i64 %op2182, ptr %slot100, align 8
  %v2183 = load i64, ptr %slot99, align 8
  %v2184 = load i64, ptr %slot100, align 8
  %op2185 = and i64 %v2183, %v2184
  store i64 %op2185, ptr %slot101, align 8
  %cv2186 = zext i1 %ov2176 to i64
  store i64 %cv2186, ptr %slot102, align 8
  %v2187 = load i64, ptr %slot102, align 8
  %cond2188 = icmp ne i64 %v2187, 0
  br i1 %cond2188, label %bb_overflow50, label %bb_checked50
bb_overflow50:
  %v2189 = load i64, ptr %slot1, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  %v2191 = load i64, ptr %slot97, align 8
  %v2192 = load i64, ptr %slot96, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2190, i64 0, i64 %v2191, i64 %v2192, i64 64) nomerge, !dbg !118
  unreachable
bb_checked50:
  %v2193 = load i64, ptr %slot98, align 8
  %v2194 = load i64, ptr %slot57, align 8
  %p2195 = inttoptr i64 %v2194 to ptr
  store i64 %v2193, ptr %p2195, align 8, !alias.scope !3, !noalias !4
  %v2196 = load i64, ptr %slot57, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %ld2198 = load i64, ptr %p2197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2198, ptr %slot103, align 8
  %v2199 = load i64, ptr %slot103, align 8
  %v2200 = load i64, ptr %slot41, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  store i64 %v2199, ptr %p2201, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v2202 = load i64, ptr %slot41, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %ld2204 = load i64, ptr %p2203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2204, ptr %slot104, align 8
  %v2205 = load i64, ptr %slot104, align 8
  %v2206 = load i64, ptr %slot57, align 8
  %p2207 = inttoptr i64 %v2206 to ptr
  store i64 %v2205, ptr %p2207, align 8, !alias.scope !3, !noalias !4
  %v2208 = load i64, ptr %slot40, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  %ld2210 = load i64, ptr %p2209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2210, ptr %slot105, align 8
  %v2211 = load i64, ptr %slot57, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  %ld2213 = load i64, ptr %p2212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2213, ptr %slot106, align 8
  %v2214 = load i64, ptr %slot105, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  %ld2216 = load i64, ptr %p2215, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2216, ptr %slot107, align 8
  %v2217 = load i64, ptr %slot106, align 8
  %v2218 = load i64, ptr %slot107, align 8
  %cmp2219 = icmp ult i64 %v2217, %v2218
  %cv2220 = zext i1 %cmp2219 to i64
  store i64 %cv2220, ptr %slot108, align 8
  %v2221 = load i64, ptr %slot108, align 8
  %cond2222 = icmp ne i64 %v2221, 0
  br i1 %cond2222, label %bb_success62, label %bb_failed62
bb_failed62:
  %v2223 = load i64, ptr %slot1, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %v2225 = load i64, ptr %slot106, align 8
  %v2226 = load i64, ptr %slot107, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2224, i64 %v2225, i64 %v2226) nomerge, !dbg !120
  unreachable
bb_success62:
  %v2227 = load i64, ptr %slot105, align 8
  %op2228 = add i64 %v2227, 32
  store i64 %op2228, ptr %slot109, align 8
  %v2229 = load i64, ptr %slot109, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  %ld2231 = load i64, ptr %p2230, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2231, ptr %slot110, align 8
  %v2232 = load i64, ptr %slot106, align 8
  %op2233 = mul i64 %v2232, 88
  store i64 %op2233, ptr %slot111, align 8
  %v2234 = load i64, ptr %slot110, align 8
  %v2235 = load i64, ptr %slot111, align 8
  %op2236 = add i64 %v2234, %v2235
  store i64 %op2236, ptr %slot112, align 8
  %v2237 = load i64, ptr %slot69, align 8
  store i64 %v2237, ptr %slot113, align 8
  %v2238 = load i64, ptr %slot112, align 8
  %v2239 = load i64, ptr %slot113, align 8
  %p2240 = inttoptr i64 %v2238 to ptr
  %p2241 = inttoptr i64 %v2239 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2241, ptr %p2240, i64 88, i1 false), !alias.scope !10000000
  %v2242 = load i64, ptr %slot113, align 8
  %v2243 = load i64, ptr %slot57, align 8
  %p2244 = inttoptr i64 %v2243 to ptr
  store i64 %v2242, ptr %p2244, align 8, !alias.scope !3, !noalias !4
  %v2245 = load i64, ptr %slot57, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  %ld2247 = load i64, ptr %p2246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2247, ptr %slot114, align 8
  %v2248 = load i64, ptr %slot28, align 8
  store i64 %v2248, ptr %slot115, align 8
  %v2249 = load i64, ptr %slot70, align 8
  %v2250 = load i64, ptr %slot115, align 8
  %v2251 = load i64, ptr %slot114, align 8
  %call2252 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v2249, i64 %v2250, i64 %v2251) nomerge, !dbg !120
  store i32 %call2252, ptr %slot116, align 8
  %v2253 = load i32, ptr %slot116, align 8
  %cv2254 = zext i32 %v2253 to i64
  %cond2255 = icmp ne i64 %cv2254, 0
  br i1 %cond2255, label %bb_rcsuccess71, label %bb_rcfailure71
bb_rcfailure71:
  %v2256 = load i64, ptr %slot70, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %call2258 = call i32 @myl_rc_take_failure(ptr %p2257) nomerge, !dbg !120
  store i32 %call2258, ptr %slot117, align 8
  %v2259 = load i64, ptr %slot1, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  %v2261 = load i32, ptr %slot117, align 8
  %call2262 = call i32 @myl_qbe_rc_status(ptr %p2260, i32 %v2261) nomerge, !dbg !120
  store i32 %call2262, ptr %slot118, align 8
  br label %bb_failure
bb_rcsuccess71:
  %v2263 = load i64, ptr %slot22, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i32 2, ptr %p2264, align 4, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot22, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i32 16, ptr %p2266, align 4, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot21, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  store i32 1, ptr %p2268, align 4, !alias.scope !3, !noalias !4
  %v2269 = load i64, ptr %slot24, align 8
  store i64 %v2269, ptr %slot119, align 8
  %v2270 = load i64, ptr %slot28, align 8
  store i64 %v2270, ptr %slot120, align 8
  %v2271 = load i64, ptr %slot120, align 8
  %v2272 = load i64, ptr %slot119, align 8
  %p2273 = inttoptr i64 %v2271 to ptr
  %p2274 = inttoptr i64 %v2272 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2274, ptr %p2273, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2275 = load i64, ptr %slot18, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  store i32 2, ptr %p2276, align 4, !alias.scope !3, !noalias !4
  %v2277 = load i64, ptr %slot22, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %ld2279 = load i32, ptr %p2278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2279, ptr %slot121, align 8
  %v2280 = load i32, ptr %slot121, align 8
  %v2281 = load i64, ptr %slot18, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  store i32 %v2280, ptr %p2282, align 4, !alias.scope !3, !noalias !4
  %v2283 = load i64, ptr %slot21, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  store i32 0, ptr %p2284, align 4, !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot17, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  store i32 1, ptr %p2286, align 4, !alias.scope !3, !noalias !4
  %v2287 = load i64, ptr %slot119, align 8
  %v2288 = load i64, ptr %slot57, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i64 %v2287, ptr %p2289, align 8, !alias.scope !3, !noalias !4
  %v2290 = load i64, ptr %slot57, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i64, ptr %p2291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2292, ptr %slot122, align 8
  %v2293 = load i64, ptr %slot17, align 8
  %p2294 = inttoptr i64 %v2293 to ptr
  %ld2295 = load i32, ptr %p2294, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2295, ptr %slot123, align 8
  %v2296 = load i64, ptr %slot18, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %ld2298 = load i32, ptr %p2297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2298, ptr %slot124, align 8
  %v2299 = load i32, ptr %slot124, align 8
  %op2300 = and i32 %v2299, 24
  store i32 %op2300, ptr %slot124, align 8
  %v2301 = load i32, ptr %slot124, align 8
  %cmp2302 = icmp eq i32 %v2301, 0
  %cv2303 = zext i1 %cmp2302 to i32
  store i32 %cv2303, ptr %slot125, align 8
  %v2304 = load i32, ptr %slot123, align 8
  %v2305 = load i32, ptr %slot125, align 8
  %op2306 = and i32 %v2304, %v2305
  store i32 %op2306, ptr %slot126, align 8
  %v2307 = load i64, ptr %slot71, align 8
  store i64 %v2307, ptr %slot127, align 8
  %v2308 = load i32, ptr %slot126, align 8
  %op2309 = mul i32 %v2308, 4
  store i32 %op2309, ptr %slot128, align 8
  %v2310 = load i32, ptr %slot128, align 8
  %op2311 = or i32 %v2310, 0
  store i32 %op2311, ptr %slot129, align 8
  %v2312 = load i64, ptr %slot28, align 8
  store i64 %v2312, ptr %slot130, align 8
  %v2313 = load i64, ptr %slot70, align 8
  %v2314 = load i64, ptr %slot130, align 8
  %v2315 = load i64, ptr %slot122, align 8
  %v2316 = load i64, ptr %slot127, align 8
  %cv2317 = trunc i64 %v2316 to i32
  %v2318 = load i32, ptr %slot129, align 8
  %call2319 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v2313, i64 %v2314, i64 %v2315, i32 %cv2317, i32 %v2318) nomerge, !dbg !122
  store i32 %call2319, ptr %slot131, align 8
  %v2320 = load i32, ptr %slot131, align 8
  %cv2321 = zext i32 %v2320 to i64
  %cond2322 = icmp ne i64 %cv2321, 0
  br i1 %cond2322, label %bb_rcsuccess99, label %bb_rcfailure99
bb_rcfailure99:
  %v2323 = load i64, ptr %slot70, align 8
  %p2324 = inttoptr i64 %v2323 to ptr
  %call2325 = call i32 @myl_rc_take_failure(ptr %p2324) nomerge, !dbg !122
  store i32 %call2325, ptr %slot132, align 8
  %v2326 = load i64, ptr %slot1, align 8
  %p2327 = inttoptr i64 %v2326 to ptr
  %v2328 = load i32, ptr %slot132, align 8
  %call2329 = call i32 @myl_qbe_rc_status(ptr %p2327, i32 %v2328) nomerge, !dbg !122
  store i32 %call2329, ptr %slot133, align 8
  br label %bb_failure
bb_rcsuccess99:
  %v2330 = load i32, ptr %slot126, align 8
  %cv2331 = zext i32 %v2330 to i64
  %cond2332 = icmp ne i64 %cv2331, 0
  br i1 %cond2332, label %bb_rchtaken102, label %bb_rchcopied102
bb_rchcopied102:
  %v2333 = load i64, ptr %slot17, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %ld2335 = load i32, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2335, ptr %slot134, align 8
  %v2336 = load i32, ptr %slot134, align 8
  %cv2337 = zext i32 %v2336 to i64
  %cond2338 = icmp ne i64 %cv2337, 0
  br i1 %cond2338, label %bb_rcslotdrop105, label %bb_rcslotdone105
bb_rcslotdrop105:
  %v2339 = load i64, ptr %slot17, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  store i32 0, ptr %p2340, align 4, !alias.scope !3, !noalias !4
  %v2341 = load i64, ptr %slot24, align 8
  store i64 %v2341, ptr %slot135, align 8
  %v2342 = load i64, ptr %slot18, align 8
  %p2343 = inttoptr i64 %v2342 to ptr
  %ld2344 = load i32, ptr %p2343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2344, ptr %slot136, align 8
  %v2345 = load i32, ptr %slot136, align 8
  %op2346 = and i32 %v2345, 28
  store i32 %op2346, ptr %slot137, align 8
  %v2347 = load i32, ptr %slot137, align 8
  %cv2348 = zext i32 %v2347 to i64
  %cond2349 = icmp ne i64 %cv2348, 0
  br i1 %cond2349, label %bb_rcslotrole105, label %bb_rcslotowner105
bb_rcslotrole105:
  %v2350 = load i64, ptr %slot70, align 8
  store i64 %v2350, ptr %slot138, align 8
  %v2351 = load i64, ptr %slot138, align 8
  %v2352 = load i64, ptr %slot135, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2351, i64 %v2352) nomerge, !dbg !122
  br label %bb_rcslotdone105
bb_rcslotowner105:
  %v2353 = load i64, ptr %slot70, align 8
  store i64 %v2353, ptr %slot139, align 8
  %v2354 = load i64, ptr %slot139, align 8
  %v2355 = load i64, ptr %slot135, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2354, i64 %v2355) nomerge, !dbg !122
  br label %bb_rcslotdone105
bb_rcslotdone105:
  br label %bb_rchprepared102
bb_rchtaken102:
  %v2356 = load i64, ptr %slot17, align 8
  %p2357 = inttoptr i64 %v2356 to ptr
  store i32 0, ptr %p2357, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared102
bb_rchprepared102:
  %v2358 = load i64, ptr %slot22, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  store i32 2, ptr %p2359, align 4, !alias.scope !3, !noalias !4
  %v2360 = load i64, ptr %slot21, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  store i32 1, ptr %p2361, align 4, !alias.scope !3, !noalias !4
  %v2362 = load i64, ptr %slot24, align 8
  store i64 %v2362, ptr %slot140, align 8
  %v2363 = load i64, ptr %slot28, align 8
  store i64 %v2363, ptr %slot141, align 8
  %v2364 = load i64, ptr %slot141, align 8
  %v2365 = load i64, ptr %slot140, align 8
  %p2366 = inttoptr i64 %v2364 to ptr
  %p2367 = inttoptr i64 %v2365 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2367, ptr %p2366, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2368 = load i64, ptr %slot18, align 8
  %p2369 = inttoptr i64 %v2368 to ptr
  store i32 2, ptr %p2369, align 4, !alias.scope !3, !noalias !4
  %v2370 = load i64, ptr %slot22, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  %ld2372 = load i32, ptr %p2371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2372, ptr %slot142, align 8
  %v2373 = load i32, ptr %slot142, align 8
  %v2374 = load i64, ptr %slot18, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  store i32 %v2373, ptr %p2375, align 4, !alias.scope !3, !noalias !4
  %v2376 = load i64, ptr %slot21, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  store i32 0, ptr %p2377, align 4, !alias.scope !3, !noalias !4
  %v2378 = load i64, ptr %slot17, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  store i32 1, ptr %p2379, align 4, !alias.scope !3, !noalias !4
  %v2380 = load i64, ptr %slot140, align 8
  %v2381 = load i64, ptr %slot57, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  store i64 %v2380, ptr %p2382, align 8, !alias.scope !3, !noalias !4
  %v2383 = load i64, ptr %slot57, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  %ld2385 = load i64, ptr %p2384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2385, ptr %slot143, align 8
  %v2386 = load i64, ptr %slot28, align 8
  store i64 %v2386, ptr %slot144, align 8
  %v2387 = load i64, ptr %slot71, align 8
  store i64 %v2387, ptr %slot145, align 8
  %v2388 = load i64, ptr %slot70, align 8
  %v2389 = load i64, ptr %slot144, align 8
  %v2390 = load i64, ptr %slot143, align 8
  %v2391 = load i64, ptr %slot145, align 8
  %cv2392 = trunc i64 %v2391 to i32
  %call2393 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v2388, i64 %v2389, i64 %v2390, i32 %cv2392) nomerge, !dbg !124
  store i32 %call2393, ptr %slot146, align 8
  %v2394 = load i32, ptr %slot146, align 8
  %cv2395 = zext i32 %v2394 to i64
  %cond2396 = icmp ne i64 %cv2395, 0
  br i1 %cond2396, label %bb_rcsuccess127, label %bb_rcfailure127
bb_rcfailure127:
  %v2397 = load i64, ptr %slot70, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  %call2399 = call i32 @myl_rc_take_failure(ptr %p2398) nomerge, !dbg !124
  store i32 %call2399, ptr %slot147, align 8
  %v2400 = load i64, ptr %slot1, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %v2402 = load i32, ptr %slot147, align 8
  %call2403 = call i32 @myl_qbe_rc_status(ptr %p2401, i32 %v2402) nomerge, !dbg !124
  store i32 %call2403, ptr %slot148, align 8
  br label %bb_failure
bb_rcsuccess127:
  %v2404 = load i64, ptr %slot17, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  store i32 0, ptr %p2405, align 4, !alias.scope !3, !noalias !4
  %v2406 = load i64, ptr %slot22, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  store i32 2, ptr %p2407, align 4, !alias.scope !3, !noalias !4
  %v2408 = load i64, ptr %slot21, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  store i32 1, ptr %p2409, align 4, !alias.scope !3, !noalias !4
  %v2410 = load i64, ptr %slot7, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  %ld2412 = load i32, ptr %p2411, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2412, ptr %slot149, align 8
  %v2413 = load i32, ptr %slot149, align 8
  %cv2414 = zext i32 %v2413 to i64
  %cond2415 = icmp ne i64 %cv2414, 0
  br i1 %cond2415, label %bb_rcslotdrop136, label %bb_rcslotdone136
bb_rcslotdrop136:
  %v2416 = load i64, ptr %slot7, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  store i32 0, ptr %p2417, align 4, !alias.scope !3, !noalias !4
  %v2418 = load i64, ptr %slot42, align 8
  store i64 %v2418, ptr %slot150, align 8
  %v2419 = load i64, ptr %slot8, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  %ld2421 = load i32, ptr %p2420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2421, ptr %slot151, align 8
  %v2422 = load i32, ptr %slot151, align 8
  %op2423 = and i32 %v2422, 28
  store i32 %op2423, ptr %slot152, align 8
  %v2424 = load i32, ptr %slot152, align 8
  %cv2425 = zext i32 %v2424 to i64
  %cond2426 = icmp ne i64 %cv2425, 0
  br i1 %cond2426, label %bb_rcslotrole136, label %bb_rcslotowner136
bb_rcslotrole136:
  %v2427 = load i64, ptr %slot70, align 8
  store i64 %v2427, ptr %slot153, align 8
  %v2428 = load i64, ptr %slot153, align 8
  %v2429 = load i64, ptr %slot150, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2428, i64 %v2429) nomerge, !dbg !124
  br label %bb_rcslotdone136
bb_rcslotowner136:
  %v2430 = load i64, ptr %slot70, align 8
  store i64 %v2430, ptr %slot154, align 8
  %v2431 = load i64, ptr %slot154, align 8
  %v2432 = load i64, ptr %slot150, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2431, i64 %v2432) nomerge, !dbg !124
  br label %bb_rcslotdone136
bb_rcslotdone136:
  %v2433 = load i64, ptr %slot42, align 8
  store i64 %v2433, ptr %slot155, align 8
  %v2434 = load i64, ptr %slot28, align 8
  store i64 %v2434, ptr %slot156, align 8
  %v2435 = load i64, ptr %slot156, align 8
  %v2436 = load i64, ptr %slot155, align 8
  %p2437 = inttoptr i64 %v2435 to ptr
  %p2438 = inttoptr i64 %v2436 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2438, ptr %p2437, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2439 = load i64, ptr %slot21, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  store i32 0, ptr %p2440, align 4, !alias.scope !3, !noalias !4
  %v2441 = load i64, ptr %slot8, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  store i32 2, ptr %p2442, align 4, !alias.scope !3, !noalias !4
  %v2443 = load i64, ptr %slot22, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  %ld2445 = load i32, ptr %p2444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2445, ptr %slot157, align 8
  %v2446 = load i32, ptr %slot157, align 8
  %v2447 = load i64, ptr %slot8, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  store i32 %v2446, ptr %p2448, align 4, !alias.scope !3, !noalias !4
  %v2449 = load i64, ptr %slot7, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  store i32 1, ptr %p2450, align 4, !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot42, align 8
  %v2452 = load i64, ptr %slot57, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  store i64 %v2451, ptr %p2453, align 8, !alias.scope !3, !noalias !4
  %v2454 = load i64, ptr %slot57, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %ld2456 = load i64, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2456, ptr %slot158, align 8
  %v2457 = load i64, ptr %slot158, align 8
  %op2458 = add i64 %v2457, 0
  store i64 %op2458, ptr %slot159, align 8
  %v2459 = load i64, ptr %slot159, align 8
  %v2460 = load i64, ptr %slot57, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  store i64 %v2459, ptr %p2461, align 8, !alias.scope !3, !noalias !4
  %v2462 = load i64, ptr %slot17, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  %ld2464 = load i32, ptr %p2463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2464, ptr %slot160, align 8
  %v2465 = load i32, ptr %slot160, align 8
  %cv2466 = zext i32 %v2465 to i64
  %cond2467 = icmp ne i64 %cv2466, 0
  br i1 %cond2467, label %bb_rcslotdrop154, label %bb_rcslotdone154
bb_rcslotdrop154:
  %v2468 = load i64, ptr %slot17, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  store i32 0, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  %v2470 = load i64, ptr %slot24, align 8
  store i64 %v2470, ptr %slot161, align 8
  %v2471 = load i64, ptr %slot18, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %ld2473 = load i32, ptr %p2472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2473, ptr %slot162, align 8
  %v2474 = load i32, ptr %slot162, align 8
  %op2475 = and i32 %v2474, 28
  store i32 %op2475, ptr %slot163, align 8
  %v2476 = load i32, ptr %slot163, align 8
  %cv2477 = zext i32 %v2476 to i64
  %cond2478 = icmp ne i64 %cv2477, 0
  br i1 %cond2478, label %bb_rcslotrole154, label %bb_rcslotowner154
bb_rcslotrole154:
  %v2479 = load i64, ptr %slot70, align 8
  store i64 %v2479, ptr %slot164, align 8
  %v2480 = load i64, ptr %slot164, align 8
  %v2481 = load i64, ptr %slot161, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2480, i64 %v2481) nomerge, !dbg !126
  br label %bb_rcslotdone154
bb_rcslotowner154:
  %v2482 = load i64, ptr %slot70, align 8
  store i64 %v2482, ptr %slot165, align 8
  %v2483 = load i64, ptr %slot165, align 8
  %v2484 = load i64, ptr %slot161, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2483, i64 %v2484) nomerge, !dbg !126
  br label %bb_rcslotdone154
bb_rcslotdone154:
  %v2485 = load i64, ptr %slot57, align 8
  %p2486 = inttoptr i64 %v2485 to ptr
  %ld2487 = load i64, ptr %p2486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2487, ptr %slot166, align 8
  %v2488 = load i64, ptr %slot166, align 8
  %op2489 = add i64 %v2488, 8
  store i64 %op2489, ptr %slot167, align 8
  %v2490 = load i64, ptr %slot167, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  %ld2492 = load i64, ptr %p2491, align 8
  store i64 %ld2492, ptr %slot168, align 8
  %v2493 = load i64, ptr %slot168, align 8
  %v2494 = load i64, ptr %slot57, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  store i64 %v2493, ptr %p2495, align 8, !alias.scope !3, !noalias !4
  %v2496 = load i64, ptr %slot17, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  %ld2498 = load i32, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2498, ptr %slot169, align 8
  %v2499 = load i32, ptr %slot169, align 8
  %cv2500 = zext i32 %v2499 to i64
  %cond2501 = icmp ne i64 %cv2500, 0
  br i1 %cond2501, label %bb_rcslotdrop166, label %bb_rcslotdone166
bb_rcslotdrop166:
  %v2502 = load i64, ptr %slot17, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  store i32 0, ptr %p2503, align 4, !alias.scope !3, !noalias !4
  %v2504 = load i64, ptr %slot24, align 8
  store i64 %v2504, ptr %slot170, align 8
  %v2505 = load i64, ptr %slot18, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %ld2507 = load i32, ptr %p2506, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2507, ptr %slot171, align 8
  %v2508 = load i32, ptr %slot171, align 8
  %op2509 = and i32 %v2508, 28
  store i32 %op2509, ptr %slot172, align 8
  %v2510 = load i32, ptr %slot172, align 8
  %cv2511 = zext i32 %v2510 to i64
  %cond2512 = icmp ne i64 %cv2511, 0
  br i1 %cond2512, label %bb_rcslotrole166, label %bb_rcslotowner166
bb_rcslotrole166:
  %v2513 = load i64, ptr %slot70, align 8
  store i64 %v2513, ptr %slot173, align 8
  %v2514 = load i64, ptr %slot173, align 8
  %v2515 = load i64, ptr %slot170, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2514, i64 %v2515) nomerge, !dbg !128
  br label %bb_rcslotdone166
bb_rcslotowner166:
  %v2516 = load i64, ptr %slot70, align 8
  store i64 %v2516, ptr %slot174, align 8
  %v2517 = load i64, ptr %slot174, align 8
  %v2518 = load i64, ptr %slot170, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2517, i64 %v2518) nomerge, !dbg !128
  br label %bb_rcslotdone166
bb_rcslotdone166:
  %v2519 = load i64, ptr %slot57, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  %ld2521 = load i64, ptr %p2520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2521, ptr %slot175, align 8
  %v2522 = load i64, ptr %slot175, align 8
  %v2523 = load i64, ptr %slot43, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  store i64 %v2522, ptr %p2524, align 8, !alias.scope !3, !noalias !4
  %v2525 = load i64, ptr %slot57, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  store i64 0, ptr %p2526, align 8, !alias.scope !3, !noalias !4
  %v2527 = load i64, ptr %slot57, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  %ld2529 = load i64, ptr %p2528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2529, ptr %slot176, align 8
  %v2530 = load i64, ptr %slot176, align 8
  %v2531 = load i64, ptr %slot44, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  store i64 %v2530, ptr %p2532, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i24:
  %v2533 = load i64, ptr %slot44, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  %ld2535 = load i64, ptr %p2534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2535, ptr %slot177, align 8
  %v2536 = load i64, ptr %slot177, align 8
  %v2537 = load i64, ptr %slot57, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i64 %v2536, ptr %p2538, align 8, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot43, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  %ld2541 = load i64, ptr %p2540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2541, ptr %slot178, align 8
  %v2542 = load i64, ptr %slot178, align 8
  %v2543 = load i64, ptr %slot58, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  store i64 %v2542, ptr %p2544, align 8, !alias.scope !3, !noalias !4
  %v2545 = load i64, ptr %slot58, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  %ld2547 = load i64, ptr %p2546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2547, ptr %slot179, align 8
  %v2548 = load i64, ptr %slot57, align 8
  %p2549 = inttoptr i64 %v2548 to ptr
  %ld2550 = load i64, ptr %p2549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2550, ptr %slot180, align 8
  %v2551 = load i64, ptr %slot180, align 8
  %v2552 = load i64, ptr %slot179, align 8
  %cmp2553 = icmp slt i64 %v2551, %v2552
  %cv2554 = zext i1 %cmp2553 to i64
  store i64 %cv2554, ptr %slot181, align 8
  %v2555 = load i64, ptr %slot181, align 8
  %v2556 = load i64, ptr %slot57, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  store i64 %v2555, ptr %p2557, align 8, !alias.scope !3, !noalias !4
  %v2558 = load i64, ptr %slot57, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  %ld2560 = load i64, ptr %p2559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2560, ptr %slot182, align 8
  %v2561 = load i64, ptr %slot182, align 8
  %cond2562 = icmp ne i64 %v2561, 0
  br i1 %cond2562, label %bb_next181, label %bb_i64
bb_next181:
  %v2563 = load i64, ptr %slot42, align 8
  %v2564 = load i64, ptr %slot57, align 8
  %p2565 = inttoptr i64 %v2564 to ptr
  store i64 %v2563, ptr %p2565, align 8, !alias.scope !3, !noalias !4
  %v2566 = load i64, ptr %slot57, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  %ld2568 = load i64, ptr %p2567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2568, ptr %slot183, align 8
  %v2569 = load i64, ptr %slot183, align 8
  %op2570 = add i64 %v2569, 72
  store i64 %op2570, ptr %slot184, align 8
  %v2571 = load i64, ptr %slot184, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  %ld2573 = load i64, ptr %p2572, align 8
  store i64 %ld2573, ptr %slot185, align 8
  %v2574 = load i64, ptr %slot185, align 8
  %v2575 = load i64, ptr %slot57, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  store i64 %v2574, ptr %p2576, align 8, !alias.scope !3, !noalias !4
  %v2577 = load i64, ptr %slot57, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %ld2579 = load i64, ptr %p2578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2579, ptr %slot186, align 8
  %v2580 = load i64, ptr %slot186, align 8
  %v2581 = load i64, ptr %slot26, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i64 %v2580, ptr %p2582, align 8, !alias.scope !3, !noalias !4
  %v2583 = load i64, ptr %slot26, align 8
  store i64 %v2583, ptr %slot187, align 8
  %v2584 = load i64, ptr %slot28, align 8
  store i64 %v2584, ptr %slot188, align 8
  %v2585 = load i64, ptr %slot187, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  %ld2587 = load i64, ptr %p2586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2587, ptr %slot189, align 8
  %v2588 = load i64, ptr %slot189, align 8
  %cmp2589 = icmp ne i64 %v2588, 0
  %cv2590 = zext i1 %cmp2589 to i32
  store i32 %cv2590, ptr %slot190, align 8
  %v2591 = load i32, ptr %slot190, align 8
  %cv2592 = zext i32 %v2591 to i64
  %cond2593 = icmp ne i64 %cv2592, 0
  br i1 %cond2593, label %bb_rcgnn188, label %bb_rcgstore188
bb_rcgnn188:
  %v2594 = load i64, ptr %slot189, align 8
  %op2595 = sub i64 %v2594, 16
  store i64 %op2595, ptr %slot191, align 8
  %v2596 = load i64, ptr %slot189, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  %rgep2598 = getelementptr i8, ptr %p2597, i64 -16
  %ld2599 = load i64, ptr %rgep2598, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2599, ptr %slot192, align 8
  %v2600 = load i64, ptr %slot192, align 8
  %op2601 = and i64 %v2600, 4611686018427387906
  store i64 %op2601, ptr %slot193, align 8
  %v2602 = load i64, ptr %slot193, align 8
  %cmp2603 = icmp ne i64 %v2602, 0
  %cv2604 = zext i1 %cmp2603 to i32
  store i32 %cv2604, ptr %slot194, align 8
  %v2605 = load i32, ptr %slot194, align 8
  %cv2606 = zext i32 %v2605 to i64
  %cond2607 = icmp ne i64 %cv2606, 0
  br i1 %cond2607, label %bb_rcgstore188, label %bb_rcginc188
bb_rcginc188:
  %v2608 = load i64, ptr %slot189, align 8
  %op2609 = sub i64 %v2608, 24
  store i64 %op2609, ptr %slot195, align 8
  %v2610 = load i64, ptr %slot189, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  %rgep2612 = getelementptr i8, ptr %p2611, i64 -24
  %ld2613 = load i64, ptr %rgep2612, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2613, ptr %slot196, align 8
  %v2614 = load i64, ptr %slot196, align 8
  %op2615 = add i64 %v2614, 1
  store i64 %op2615, ptr %slot197, align 8
  %v2616 = load i64, ptr %slot197, align 8
  %cmp2617 = icmp eq i64 %v2616, 0
  %cv2618 = zext i1 %cmp2617 to i32
  store i32 %cv2618, ptr %slot198, align 8
  %v2619 = load i32, ptr %slot198, align 8
  %cv2620 = zext i32 %v2619 to i64
  %cond2621 = icmp ne i64 %cv2620, 0
  br i1 %cond2621, label %bb_rcglimit188, label %bb_rcgcapacity188
bb_rcglimit188:
  %v2622 = load i64, ptr %slot1, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %call2624 = call i32 @myl_qbe_rc_status(ptr %p2623, i32 2) nomerge, !dbg !130
  store i32 %call2624, ptr %slot199, align 8
  br label %bb_failure
bb_rcgcapacity188:
  %v2625 = load i64, ptr %slot197, align 8
  %v2626 = load i64, ptr %slot189, align 8
  %p2627 = inttoptr i64 %v2626 to ptr
  %rgep2628 = getelementptr i8, ptr %p2627, i64 -24
  store i64 %v2625, ptr %rgep2628, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore188
bb_rcgstore188:
  %v2629 = load i64, ptr %slot189, align 8
  %v2630 = load i64, ptr %slot188, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  store i64 %v2629, ptr %p2631, align 8, !alias.scope !3, !noalias !4
  %v2632 = load i64, ptr %slot22, align 8
  %p2633 = inttoptr i64 %v2632 to ptr
  store i32 2, ptr %p2633, align 4, !alias.scope !3, !noalias !4
  %v2634 = load i64, ptr %slot22, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  store i32 16, ptr %p2635, align 4, !alias.scope !3, !noalias !4
  %v2636 = load i64, ptr %slot21, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  store i32 1, ptr %p2637, align 4, !alias.scope !3, !noalias !4
  %v2638 = load i64, ptr %slot17, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  %ld2640 = load i32, ptr %p2639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2640, ptr %slot200, align 8
  %v2641 = load i32, ptr %slot200, align 8
  %cv2642 = zext i32 %v2641 to i64
  %cond2643 = icmp ne i64 %cv2642, 0
  br i1 %cond2643, label %bb_rcslotdrop204, label %bb_rcslotdone204
bb_rcslotdrop204:
  %v2644 = load i64, ptr %slot17, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  store i32 0, ptr %p2645, align 4, !alias.scope !3, !noalias !4
  %v2646 = load i64, ptr %slot24, align 8
  store i64 %v2646, ptr %slot201, align 8
  %v2647 = load i64, ptr %slot18, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %ld2649 = load i32, ptr %p2648, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2649, ptr %slot202, align 8
  %v2650 = load i32, ptr %slot202, align 8
  %op2651 = and i32 %v2650, 28
  store i32 %op2651, ptr %slot203, align 8
  %v2652 = load i32, ptr %slot203, align 8
  %cv2653 = zext i32 %v2652 to i64
  %cond2654 = icmp ne i64 %cv2653, 0
  br i1 %cond2654, label %bb_rcslotrole204, label %bb_rcslotowner204
bb_rcslotrole204:
  %v2655 = load i64, ptr %slot70, align 8
  store i64 %v2655, ptr %slot204, align 8
  %v2656 = load i64, ptr %slot204, align 8
  %v2657 = load i64, ptr %slot201, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2656, i64 %v2657) nomerge, !dbg !130
  br label %bb_rcslotdone204
bb_rcslotowner204:
  %v2658 = load i64, ptr %slot70, align 8
  store i64 %v2658, ptr %slot205, align 8
  %v2659 = load i64, ptr %slot205, align 8
  %v2660 = load i64, ptr %slot201, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2659, i64 %v2660) nomerge, !dbg !130
  br label %bb_rcslotdone204
bb_rcslotdone204:
  %v2661 = load i64, ptr %slot24, align 8
  store i64 %v2661, ptr %slot206, align 8
  %v2662 = load i64, ptr %slot28, align 8
  store i64 %v2662, ptr %slot207, align 8
  %v2663 = load i64, ptr %slot207, align 8
  %v2664 = load i64, ptr %slot206, align 8
  %p2665 = inttoptr i64 %v2663 to ptr
  %p2666 = inttoptr i64 %v2664 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2666, ptr %p2665, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2667 = load i64, ptr %slot18, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  store i32 2, ptr %p2668, align 4, !alias.scope !3, !noalias !4
  %v2669 = load i64, ptr %slot22, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  %ld2671 = load i32, ptr %p2670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2671, ptr %slot208, align 8
  %v2672 = load i32, ptr %slot208, align 8
  %v2673 = load i64, ptr %slot18, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  store i32 %v2672, ptr %p2674, align 4, !alias.scope !3, !noalias !4
  %v2675 = load i64, ptr %slot21, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  store i32 0, ptr %p2676, align 4, !alias.scope !3, !noalias !4
  %v2677 = load i64, ptr %slot17, align 8
  %p2678 = inttoptr i64 %v2677 to ptr
  store i32 1, ptr %p2678, align 4, !alias.scope !3, !noalias !4
  %v2679 = load i64, ptr %slot206, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  %ld2681 = load i64, ptr %p2680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2681, ptr %slot209, align 8
  %v2682 = load i64, ptr %slot209, align 8
  %v2683 = load i64, ptr %slot57, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i64 %v2682, ptr %p2684, align 8, !alias.scope !3, !noalias !4
  %v2685 = load i64, ptr %slot57, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %ld2687 = load i64, ptr %p2686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2687, ptr %slot210, align 8
  %v2688 = load i64, ptr %slot210, align 8
  %v2689 = load i64, ptr %slot26, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  store i64 %v2688, ptr %p2690, align 8, !alias.scope !3, !noalias !4
  %v2691 = load i64, ptr %slot26, align 8
  store i64 %v2691, ptr %slot211, align 8
  %v2692 = load i64, ptr %slot17, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  %ld2694 = load i32, ptr %p2693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2694, ptr %slot212, align 8
  %v2695 = load i64, ptr %slot18, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  %ld2697 = load i32, ptr %p2696, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2697, ptr %slot213, align 8
  %v2698 = load i32, ptr %slot213, align 8
  %op2699 = and i32 %v2698, 24
  store i32 %op2699, ptr %slot213, align 8
  %v2700 = load i32, ptr %slot213, align 8
  %cmp2701 = icmp eq i32 %v2700, 0
  %cv2702 = zext i1 %cmp2701 to i32
  store i32 %cv2702, ptr %slot214, align 8
  %v2703 = load i32, ptr %slot212, align 8
  %v2704 = load i32, ptr %slot214, align 8
  %op2705 = and i32 %v2703, %v2704
  store i32 %op2705, ptr %slot215, align 8
  %v2706 = load i32, ptr %slot215, align 8
  %cv2707 = zext i32 %v2706 to i64
  %cond2708 = icmp ne i64 %cv2707, 0
  br i1 %cond2708, label %bb_rcprivateown228, label %bb_rcprivateloan228
bb_rcprivateown228:
  %v2709 = load i64, ptr %slot28, align 8
  store i64 %v2709, ptr %slot216, align 8
  %v2710 = load i64, ptr %slot71, align 8
  store i64 %v2710, ptr %slot217, align 8
  %v2711 = load i64, ptr %slot211, align 8
  %v2712 = load i64, ptr %slot216, align 8
  %op2713 = sub i64 %v2711, %v2712
  store i64 %op2713, ptr %slot218, align 8
  %v2714 = load i64, ptr %slot216, align 8
  %v2715 = load i64, ptr %slot211, align 8
  %op2716 = sub i64 %v2714, %v2715
  store i64 %op2716, ptr %slot219, align 8
  %v2717 = load i64, ptr %slot218, align 8
  %cmp2718 = icmp ult i64 %v2717, 8
  %cv2719 = zext i1 %cmp2718 to i32
  store i32 %cv2719, ptr %slot220, align 8
  %v2720 = load i64, ptr %slot219, align 8
  %cmp2721 = icmp ult i64 %v2720, 8
  %cv2722 = zext i1 %cmp2721 to i32
  store i32 %cv2722, ptr %slot221, align 8
  %v2723 = load i32, ptr %slot220, align 8
  %v2724 = load i32, ptr %slot221, align 8
  %op2725 = or i32 %v2723, %v2724
  store i32 %op2725, ptr %slot222, align 8
  %v2726 = load i32, ptr %slot222, align 8
  %cv2727 = zext i32 %v2726 to i64
  %cond2728 = icmp ne i64 %cv2727, 0
  br i1 %cond2728, label %bb_rcmoveslow231, label %bb_rcmovecheck231
bb_rcmovecheck231:
  %v2729 = load i64, ptr %slot211, align 8
  %p2731 = inttoptr i64 %v2729 to ptr
  %gep2732 = getelementptr i8, ptr %p2731, i64 0
  %op2730 = ptrtoint ptr %gep2732 to i64
  store i64 %op2730, ptr %slot223, align 8
  %v2733 = load i64, ptr %slot223, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  %ld2735 = load i64, ptr %p2734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2735, ptr %slot224, align 8
  %v2736 = load i64, ptr %slot224, align 8
  %cmp2737 = icmp ne i64 %v2736, 0
  %cv2738 = zext i1 %cmp2737 to i32
  store i32 %cv2738, ptr %slot225, align 8
  %v2739 = load i32, ptr %slot225, align 8
  %cv2740 = zext i32 %v2739 to i64
  %cond2741 = icmp ne i64 %cv2740, 0
  br i1 %cond2741, label %bb_rcmoveheader239, label %bb_rcmovenext239
bb_rcmoveheader239:
  %v2742 = load i64, ptr %slot224, align 8
  %op2743 = sub i64 %v2742, 16
  store i64 %op2743, ptr %slot226, align 8
  %v2744 = load i64, ptr %slot224, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  %rgep2746 = getelementptr i8, ptr %p2745, i64 -16
  %ld2747 = load i64, ptr %rgep2746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2747, ptr %slot227, align 8
  %v2748 = load i64, ptr %slot227, align 8
  %op2749 = and i64 %v2748, 5764607523034234881
  store i64 %op2749, ptr %slot228, align 8
  %v2750 = load i64, ptr %slot228, align 8
  %cmp2751 = icmp ne i64 %v2750, 0
  %cv2752 = zext i1 %cmp2751 to i32
  store i32 %cv2752, ptr %slot229, align 8
  %v2753 = load i32, ptr %slot229, align 8
  %cv2754 = zext i32 %v2753 to i64
  %cond2755 = icmp ne i64 %cv2754, 0
  br i1 %cond2755, label %bb_rcmoveslow231, label %bb_rcmovenext239
bb_rcmovenext239:
  %v2756 = load i64, ptr %slot211, align 8
  %v2757 = load i64, ptr %slot216, align 8
  %p2758 = inttoptr i64 %v2756 to ptr
  %p2759 = inttoptr i64 %v2757 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2759, ptr %p2758, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2760 = load i64, ptr %slot211, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  store i64 0, ptr %p2761, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved231
bb_rcmoveslow231:
  %v2762 = load i64, ptr %slot70, align 8
  %v2763 = load i64, ptr %slot216, align 8
  %v2764 = load i64, ptr %slot211, align 8
  %v2765 = load i64, ptr %slot217, align 8
  %cv2766 = trunc i64 %v2765 to i32
  %call2767 = call i32 @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_take(i64 %v2762, i64 %v2763, i64 %v2764, i32 %cv2766) nomerge, !dbg !132
  store i32 %call2767, ptr %slot230, align 8
  %v2768 = load i32, ptr %slot230, align 8
  %cv2769 = zext i32 %v2768 to i64
  %cond2770 = icmp ne i64 %cv2769, 0
  br i1 %cond2770, label %bb_rcsuccess246, label %bb_rcfailure246
bb_rcfailure246:
  %v2771 = load i64, ptr %slot70, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  %call2773 = call i32 @myl_rc_take_failure(ptr %p2772) nomerge, !dbg !132
  store i32 %call2773, ptr %slot231, align 8
  %v2774 = load i64, ptr %slot1, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  %v2776 = load i32, ptr %slot231, align 8
  %call2777 = call i32 @myl_qbe_rc_status(ptr %p2775, i32 %v2776) nomerge, !dbg !132
  store i32 %call2777, ptr %slot232, align 8
  br label %bb_failure
bb_rcsuccess246:
  br label %bb_rcmoved231
bb_rcmoved231:
  %v2778 = load i64, ptr %slot17, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  store i32 0, ptr %p2779, align 4, !alias.scope !3, !noalias !4
  %v2780 = load i64, ptr %slot22, align 8
  %p2781 = inttoptr i64 %v2780 to ptr
  store i32 2, ptr %p2781, align 4, !alias.scope !3, !noalias !4
  %v2782 = load i64, ptr %slot21, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i32 1, ptr %p2783, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared228
bb_rcprivateloan228:
  %v2784 = load i64, ptr %slot17, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  %ld2786 = load i32, ptr %p2785, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2786, ptr %slot233, align 8
  %v2787 = load i64, ptr %slot18, align 8
  %p2788 = inttoptr i64 %v2787 to ptr
  %ld2789 = load i32, ptr %p2788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2789, ptr %slot234, align 8
  %v2790 = load i32, ptr %slot234, align 8
  %cmp2791 = icmp eq i32 %v2790, 16
  %cv2792 = zext i1 %cmp2791 to i32
  store i32 %cv2792, ptr %slot235, align 8
  %v2793 = load i32, ptr %slot235, align 8
  %v2794 = load i32, ptr %slot233, align 8
  %op2795 = and i32 %v2793, %v2794
  store i32 %op2795, ptr %slot235, align 8
  %v2796 = load i32, ptr %slot235, align 8
  %cv2797 = zext i32 %v2796 to i64
  %cond2798 = icmp ne i64 %cv2797, 0
  br i1 %cond2798, label %bb_rcprivatemove228, label %bb_rcprivatenew228
bb_rcprivatemove228:
  %v2799 = load i64, ptr %slot28, align 8
  store i64 %v2799, ptr %slot236, align 8
  %v2800 = load i64, ptr %slot211, align 8
  %v2801 = load i64, ptr %slot236, align 8
  %p2802 = inttoptr i64 %v2800 to ptr
  %p2803 = inttoptr i64 %v2801 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2803, ptr %p2802, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2804 = load i64, ptr %slot211, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i64 0, ptr %p2805, align 8, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot22, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i32 2, ptr %p2807, align 4, !alias.scope !3, !noalias !4
  %v2808 = load i64, ptr %slot22, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  store i32 16, ptr %p2809, align 4, !alias.scope !3, !noalias !4
  %v2810 = load i64, ptr %slot21, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  store i32 1, ptr %p2811, align 4, !alias.scope !3, !noalias !4
  %v2812 = load i64, ptr %slot17, align 8
  %p2813 = inttoptr i64 %v2812 to ptr
  store i32 0, ptr %p2813, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared228
bb_rcprivatenew228:
  %v2814 = load i64, ptr %slot28, align 8
  store i64 %v2814, ptr %slot237, align 8
  %v2815 = load i64, ptr %slot211, align 8
  %p2816 = inttoptr i64 %v2815 to ptr
  %ld2817 = load i64, ptr %p2816, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2817, ptr %slot238, align 8
  %v2818 = load i64, ptr %slot238, align 8
  %cmp2819 = icmp ne i64 %v2818, 0
  %cv2820 = zext i1 %cmp2819 to i32
  store i32 %cv2820, ptr %slot239, align 8
  %v2821 = load i32, ptr %slot239, align 8
  %cv2822 = zext i32 %v2821 to i64
  %cond2823 = icmp ne i64 %cv2822, 0
  br i1 %cond2823, label %bb_rcgnn264, label %bb_rcgstore264
bb_rcgnn264:
  %v2824 = load i64, ptr %slot238, align 8
  %op2825 = sub i64 %v2824, 16
  store i64 %op2825, ptr %slot240, align 8
  %v2826 = load i64, ptr %slot238, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  %rgep2828 = getelementptr i8, ptr %p2827, i64 -16
  %ld2829 = load i64, ptr %rgep2828, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2829, ptr %slot241, align 8
  %v2830 = load i64, ptr %slot241, align 8
  %op2831 = and i64 %v2830, 4611686018427387906
  store i64 %op2831, ptr %slot242, align 8
  %v2832 = load i64, ptr %slot242, align 8
  %cmp2833 = icmp ne i64 %v2832, 0
  %cv2834 = zext i1 %cmp2833 to i32
  store i32 %cv2834, ptr %slot243, align 8
  %v2835 = load i32, ptr %slot243, align 8
  %cv2836 = zext i32 %v2835 to i64
  %cond2837 = icmp ne i64 %cv2836, 0
  br i1 %cond2837, label %bb_rcgstore264, label %bb_rcginc264
bb_rcginc264:
  %v2838 = load i64, ptr %slot238, align 8
  %op2839 = sub i64 %v2838, 24
  store i64 %op2839, ptr %slot244, align 8
  %v2840 = load i64, ptr %slot238, align 8
  %p2841 = inttoptr i64 %v2840 to ptr
  %rgep2842 = getelementptr i8, ptr %p2841, i64 -24
  %ld2843 = load i64, ptr %rgep2842, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2843, ptr %slot245, align 8
  %v2844 = load i64, ptr %slot245, align 8
  %op2845 = add i64 %v2844, 1
  store i64 %op2845, ptr %slot246, align 8
  %v2846 = load i64, ptr %slot246, align 8
  %cmp2847 = icmp eq i64 %v2846, 0
  %cv2848 = zext i1 %cmp2847 to i32
  store i32 %cv2848, ptr %slot247, align 8
  %v2849 = load i32, ptr %slot247, align 8
  %cv2850 = zext i32 %v2849 to i64
  %cond2851 = icmp ne i64 %cv2850, 0
  br i1 %cond2851, label %bb_rcglimit264, label %bb_rcgcapacity264
bb_rcglimit264:
  %v2852 = load i64, ptr %slot1, align 8
  %p2853 = inttoptr i64 %v2852 to ptr
  %call2854 = call i32 @myl_qbe_rc_status(ptr %p2853, i32 2) nomerge, !dbg !132
  store i32 %call2854, ptr %slot248, align 8
  br label %bb_failure
bb_rcgcapacity264:
  %v2855 = load i64, ptr %slot246, align 8
  %v2856 = load i64, ptr %slot238, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  %rgep2858 = getelementptr i8, ptr %p2857, i64 -24
  store i64 %v2855, ptr %rgep2858, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore264
bb_rcgstore264:
  %v2859 = load i64, ptr %slot238, align 8
  %v2860 = load i64, ptr %slot237, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  store i64 %v2859, ptr %p2861, align 8, !alias.scope !3, !noalias !4
  %v2862 = load i64, ptr %slot22, align 8
  %p2863 = inttoptr i64 %v2862 to ptr
  store i32 2, ptr %p2863, align 4, !alias.scope !3, !noalias !4
  %v2864 = load i64, ptr %slot22, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  store i32 16, ptr %p2865, align 4, !alias.scope !3, !noalias !4
  %v2866 = load i64, ptr %slot21, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  store i32 1, ptr %p2867, align 4, !alias.scope !3, !noalias !4
  %v2868 = load i64, ptr %slot17, align 8
  %p2869 = inttoptr i64 %v2868 to ptr
  %ld2870 = load i32, ptr %p2869, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2870, ptr %slot249, align 8
  %v2871 = load i32, ptr %slot249, align 8
  %cv2872 = zext i32 %v2871 to i64
  %cond2873 = icmp ne i64 %cv2872, 0
  br i1 %cond2873, label %bb_rcslotdrop280, label %bb_rcslotdone280
bb_rcslotdrop280:
  %v2874 = load i64, ptr %slot17, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  store i32 0, ptr %p2875, align 4, !alias.scope !3, !noalias !4
  %v2876 = load i64, ptr %slot24, align 8
  store i64 %v2876, ptr %slot250, align 8
  %v2877 = load i64, ptr %slot18, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %ld2879 = load i32, ptr %p2878, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2879, ptr %slot251, align 8
  %v2880 = load i32, ptr %slot251, align 8
  %op2881 = and i32 %v2880, 28
  store i32 %op2881, ptr %slot252, align 8
  %v2882 = load i32, ptr %slot252, align 8
  %cv2883 = zext i32 %v2882 to i64
  %cond2884 = icmp ne i64 %cv2883, 0
  br i1 %cond2884, label %bb_rcslotrole280, label %bb_rcslotowner280
bb_rcslotrole280:
  %v2885 = load i64, ptr %slot70, align 8
  store i64 %v2885, ptr %slot253, align 8
  %v2886 = load i64, ptr %slot250, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  %ld2888 = load i64, ptr %p2887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2888, ptr %slot254, align 8
  %v2889 = load i64, ptr %slot254, align 8
  %cmp2890 = icmp ne i64 %v2889, 0
  %cv2891 = zext i1 %cmp2890 to i32
  store i32 %cv2891, ptr %slot255, align 8
  %v2892 = load i32, ptr %slot255, align 8
  %cv2893 = zext i32 %v2892 to i64
  %cond2894 = icmp ne i64 %cv2893, 0
  br i1 %cond2894, label %bb_rcgnn296, label %bb_rcgdone296
bb_rcgnn296:
  %v2895 = load i64, ptr %slot254, align 8
  %op2896 = sub i64 %v2895, 16
  store i64 %op2896, ptr %slot256, align 8
  %v2897 = load i64, ptr %slot254, align 8
  %p2898 = inttoptr i64 %v2897 to ptr
  %rgep2899 = getelementptr i8, ptr %p2898, i64 -16
  %ld2900 = load i64, ptr %rgep2899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2900, ptr %slot257, align 8
  %v2901 = load i64, ptr %slot257, align 8
  %op2902 = and i64 %v2901, 4611686018427387906
  store i64 %op2902, ptr %slot258, align 8
  %v2903 = load i64, ptr %slot258, align 8
  %cmp2904 = icmp ne i64 %v2903, 0
  %cv2905 = zext i1 %cmp2904 to i32
  store i32 %cv2905, ptr %slot259, align 8
  %v2906 = load i32, ptr %slot259, align 8
  %cv2907 = zext i32 %v2906 to i64
  %cond2908 = icmp ne i64 %cv2907, 0
  br i1 %cond2908, label %bb_rcgclear296, label %bb_rcgcounted296
bb_rcgcounted296:
  %v2909 = load i64, ptr %slot254, align 8
  %op2910 = sub i64 %v2909, 24
  store i64 %op2910, ptr %slot260, align 8
  %v2911 = load i64, ptr %slot254, align 8
  %p2912 = inttoptr i64 %v2911 to ptr
  %rgep2913 = getelementptr i8, ptr %p2912, i64 -24
  %ld2914 = load i64, ptr %rgep2913, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2914, ptr %slot261, align 8
  %v2915 = load i64, ptr %slot261, align 8
  %op2916 = sub i64 %v2915, 1
  store i64 %op2916, ptr %slot262, align 8
  %v2917 = load i64, ptr %slot262, align 8
  %cmp2918 = icmp eq i64 %v2917, 0
  %cv2919 = zext i1 %cmp2918 to i32
  store i32 %cv2919, ptr %slot263, align 8
  %v2920 = load i32, ptr %slot263, align 8
  %cv2921 = zext i32 %v2920 to i64
  %cond2922 = icmp ne i64 %cv2921, 0
  br i1 %cond2922, label %bb_rcglast296, label %bb_rcgdec296
bb_rcglast296:
  %v2923 = load i64, ptr %slot254, align 8
  %op2924 = sub i64 %v2923, 32
  store i64 %op2924, ptr %slot264, align 8
  %v2925 = load i64, ptr %slot254, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  %rgep2927 = getelementptr i8, ptr %p2926, i64 -32
  %ld2928 = load i64, ptr %rgep2927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2928, ptr %slot265, align 8
  %v2929 = load i64, ptr %slot265, align 8
  %cmp2930 = icmp ne i64 %v2929, 0
  %cv2931 = zext i1 %cmp2930 to i32
  store i32 %cv2931, ptr %slot266, align 8
  %v2932 = load i32, ptr %slot266, align 8
  %cv2933 = zext i32 %v2932 to i64
  %cond2934 = icmp ne i64 %cv2933, 0
  br i1 %cond2934, label %bb_rcgdec296, label %bb_rcgslow296
bb_rcgslow296:
  %v2935 = load i64, ptr %slot253, align 8
  %v2936 = load i64, ptr %slot250, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v2935, i64 %v2936) nomerge, !dbg !132
  br label %bb_rcgdone296
bb_rcgdec296:
  %v2937 = load i64, ptr %slot262, align 8
  %v2938 = load i64, ptr %slot254, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  %rgep2940 = getelementptr i8, ptr %p2939, i64 -24
  store i64 %v2937, ptr %rgep2940, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear296
bb_rcgclear296:
  %v2941 = load i64, ptr %slot250, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  store i64 0, ptr %p2942, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone296
bb_rcgdone296:
  br label %bb_rcslotdone280
bb_rcslotowner280:
  %v2943 = load i64, ptr %slot70, align 8
  store i64 %v2943, ptr %slot267, align 8
  %v2944 = load i64, ptr %slot250, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  %ld2946 = load i64, ptr %p2945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2946, ptr %slot268, align 8
  %v2947 = load i64, ptr %slot268, align 8
  %cmp2948 = icmp ne i64 %v2947, 0
  %cv2949 = zext i1 %cmp2948 to i32
  store i32 %cv2949, ptr %slot269, align 8
  %v2950 = load i32, ptr %slot269, align 8
  %cv2951 = zext i32 %v2950 to i64
  %cond2952 = icmp ne i64 %cv2951, 0
  br i1 %cond2952, label %bb_rcgnn311, label %bb_rcgdone311
bb_rcgnn311:
  %v2953 = load i64, ptr %slot268, align 8
  %op2954 = sub i64 %v2953, 16
  store i64 %op2954, ptr %slot270, align 8
  %v2955 = load i64, ptr %slot268, align 8
  %p2956 = inttoptr i64 %v2955 to ptr
  %rgep2957 = getelementptr i8, ptr %p2956, i64 -16
  %ld2958 = load i64, ptr %rgep2957, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2958, ptr %slot271, align 8
  %v2959 = load i64, ptr %slot271, align 8
  %op2960 = and i64 %v2959, 4611686018427387906
  store i64 %op2960, ptr %slot272, align 8
  %v2961 = load i64, ptr %slot272, align 8
  %cmp2962 = icmp ne i64 %v2961, 0
  %cv2963 = zext i1 %cmp2962 to i32
  store i32 %cv2963, ptr %slot273, align 8
  %v2964 = load i32, ptr %slot273, align 8
  %cv2965 = zext i32 %v2964 to i64
  %cond2966 = icmp ne i64 %cv2965, 0
  br i1 %cond2966, label %bb_rcgclear311, label %bb_rcgcounted311
bb_rcgcounted311:
  %v2967 = load i64, ptr %slot268, align 8
  %op2968 = sub i64 %v2967, 32
  store i64 %op2968, ptr %slot274, align 8
  %v2969 = load i64, ptr %slot268, align 8
  %p2970 = inttoptr i64 %v2969 to ptr
  %rgep2971 = getelementptr i8, ptr %p2970, i64 -32
  %ld2972 = load i64, ptr %rgep2971, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2972, ptr %slot275, align 8
  %v2973 = load i64, ptr %slot275, align 8
  %op2974 = sub i64 %v2973, 1
  store i64 %op2974, ptr %slot276, align 8
  %v2975 = load i64, ptr %slot276, align 8
  %cmp2976 = icmp eq i64 %v2975, 0
  %cv2977 = zext i1 %cmp2976 to i32
  store i32 %cv2977, ptr %slot277, align 8
  %v2978 = load i32, ptr %slot277, align 8
  %cv2979 = zext i32 %v2978 to i64
  %cond2980 = icmp ne i64 %cv2979, 0
  br i1 %cond2980, label %bb_rcglast311, label %bb_rcgdec311
bb_rcglast311:
  %v2981 = load i64, ptr %slot268, align 8
  %op2982 = sub i64 %v2981, 24
  store i64 %op2982, ptr %slot278, align 8
  %v2983 = load i64, ptr %slot268, align 8
  %p2984 = inttoptr i64 %v2983 to ptr
  %rgep2985 = getelementptr i8, ptr %p2984, i64 -24
  %ld2986 = load i64, ptr %rgep2985, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2986, ptr %slot279, align 8
  %v2987 = load i64, ptr %slot279, align 8
  %cmp2988 = icmp ne i64 %v2987, 0
  %cv2989 = zext i1 %cmp2988 to i32
  store i32 %cv2989, ptr %slot280, align 8
  %v2990 = load i32, ptr %slot280, align 8
  %cv2991 = zext i32 %v2990 to i64
  %cond2992 = icmp ne i64 %cv2991, 0
  br i1 %cond2992, label %bb_rcgdec311, label %bb_rcgslow311
bb_rcgslow311:
  %v2993 = load i64, ptr %slot267, align 8
  %v2994 = load i64, ptr %slot250, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v2993, i64 %v2994) nomerge, !dbg !132
  br label %bb_rcgdone311
bb_rcgdec311:
  %v2995 = load i64, ptr %slot276, align 8
  %v2996 = load i64, ptr %slot268, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  %rgep2998 = getelementptr i8, ptr %p2997, i64 -32
  store i64 %v2995, ptr %rgep2998, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear311
bb_rcgclear311:
  %v2999 = load i64, ptr %slot250, align 8
  %p3000 = inttoptr i64 %v2999 to ptr
  store i64 0, ptr %p3000, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone311
bb_rcgdone311:
  br label %bb_rcslotdone280
bb_rcslotdone280:
  br label %bb_rcprivateprepared228
bb_rcprivateprepared228:
  %v3001 = load i64, ptr %slot9, align 8
  %p3002 = inttoptr i64 %v3001 to ptr
  %ld3003 = load i32, ptr %p3002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3003, ptr %slot281, align 8
  %v3004 = load i32, ptr %slot281, align 8
  %cv3005 = zext i32 %v3004 to i64
  %cond3006 = icmp ne i64 %cv3005, 0
  br i1 %cond3006, label %bb_rcslotdrop318, label %bb_rcslotdone318
bb_rcslotdrop318:
  %v3007 = load i64, ptr %slot9, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  store i32 0, ptr %p3008, align 4, !alias.scope !3, !noalias !4
  %v3009 = load i64, ptr %slot45, align 8
  store i64 %v3009, ptr %slot282, align 8
  %v3010 = load i64, ptr %slot10, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  %ld3012 = load i32, ptr %p3011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3012, ptr %slot283, align 8
  %v3013 = load i32, ptr %slot283, align 8
  %op3014 = and i32 %v3013, 28
  store i32 %op3014, ptr %slot284, align 8
  %v3015 = load i32, ptr %slot284, align 8
  %cv3016 = zext i32 %v3015 to i64
  %cond3017 = icmp ne i64 %cv3016, 0
  br i1 %cond3017, label %bb_rcslotrole318, label %bb_rcslotowner318
bb_rcslotrole318:
  %v3018 = load i64, ptr %slot70, align 8
  store i64 %v3018, ptr %slot285, align 8
  %v3019 = load i64, ptr %slot282, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %ld3021 = load i64, ptr %p3020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3021, ptr %slot286, align 8
  %v3022 = load i64, ptr %slot286, align 8
  %cmp3023 = icmp ne i64 %v3022, 0
  %cv3024 = zext i1 %cmp3023 to i32
  store i32 %cv3024, ptr %slot287, align 8
  %v3025 = load i32, ptr %slot287, align 8
  %cv3026 = zext i32 %v3025 to i64
  %cond3027 = icmp ne i64 %cv3026, 0
  br i1 %cond3027, label %bb_rcgnn334, label %bb_rcgdone334
bb_rcgnn334:
  %v3028 = load i64, ptr %slot286, align 8
  %op3029 = sub i64 %v3028, 16
  store i64 %op3029, ptr %slot288, align 8
  %v3030 = load i64, ptr %slot286, align 8
  %p3031 = inttoptr i64 %v3030 to ptr
  %rgep3032 = getelementptr i8, ptr %p3031, i64 -16
  %ld3033 = load i64, ptr %rgep3032, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3033, ptr %slot289, align 8
  %v3034 = load i64, ptr %slot289, align 8
  %op3035 = and i64 %v3034, 4611686018427387906
  store i64 %op3035, ptr %slot290, align 8
  %v3036 = load i64, ptr %slot290, align 8
  %cmp3037 = icmp ne i64 %v3036, 0
  %cv3038 = zext i1 %cmp3037 to i32
  store i32 %cv3038, ptr %slot291, align 8
  %v3039 = load i32, ptr %slot291, align 8
  %cv3040 = zext i32 %v3039 to i64
  %cond3041 = icmp ne i64 %cv3040, 0
  br i1 %cond3041, label %bb_rcgclear334, label %bb_rcgcounted334
bb_rcgcounted334:
  %v3042 = load i64, ptr %slot286, align 8
  %op3043 = sub i64 %v3042, 24
  store i64 %op3043, ptr %slot292, align 8
  %v3044 = load i64, ptr %slot286, align 8
  %p3045 = inttoptr i64 %v3044 to ptr
  %rgep3046 = getelementptr i8, ptr %p3045, i64 -24
  %ld3047 = load i64, ptr %rgep3046, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3047, ptr %slot293, align 8
  %v3048 = load i64, ptr %slot293, align 8
  %op3049 = sub i64 %v3048, 1
  store i64 %op3049, ptr %slot294, align 8
  %v3050 = load i64, ptr %slot294, align 8
  %cmp3051 = icmp eq i64 %v3050, 0
  %cv3052 = zext i1 %cmp3051 to i32
  store i32 %cv3052, ptr %slot295, align 8
  %v3053 = load i32, ptr %slot295, align 8
  %cv3054 = zext i32 %v3053 to i64
  %cond3055 = icmp ne i64 %cv3054, 0
  br i1 %cond3055, label %bb_rcglast334, label %bb_rcgdec334
bb_rcglast334:
  %v3056 = load i64, ptr %slot286, align 8
  %op3057 = sub i64 %v3056, 32
  store i64 %op3057, ptr %slot296, align 8
  %v3058 = load i64, ptr %slot286, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  %rgep3060 = getelementptr i8, ptr %p3059, i64 -32
  %ld3061 = load i64, ptr %rgep3060, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3061, ptr %slot297, align 8
  %v3062 = load i64, ptr %slot297, align 8
  %cmp3063 = icmp ne i64 %v3062, 0
  %cv3064 = zext i1 %cmp3063 to i32
  store i32 %cv3064, ptr %slot298, align 8
  %v3065 = load i32, ptr %slot298, align 8
  %cv3066 = zext i32 %v3065 to i64
  %cond3067 = icmp ne i64 %cv3066, 0
  br i1 %cond3067, label %bb_rcgdec334, label %bb_rcgslow334
bb_rcgslow334:
  %v3068 = load i64, ptr %slot285, align 8
  %v3069 = load i64, ptr %slot282, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v3068, i64 %v3069) nomerge, !dbg !132
  br label %bb_rcgdone334
bb_rcgdec334:
  %v3070 = load i64, ptr %slot294, align 8
  %v3071 = load i64, ptr %slot286, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  %rgep3073 = getelementptr i8, ptr %p3072, i64 -24
  store i64 %v3070, ptr %rgep3073, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear334
bb_rcgclear334:
  %v3074 = load i64, ptr %slot282, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  store i64 0, ptr %p3075, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone334
bb_rcgdone334:
  br label %bb_rcslotdone318
bb_rcslotowner318:
  %v3076 = load i64, ptr %slot70, align 8
  store i64 %v3076, ptr %slot299, align 8
  %v3077 = load i64, ptr %slot282, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  %ld3079 = load i64, ptr %p3078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3079, ptr %slot300, align 8
  %v3080 = load i64, ptr %slot300, align 8
  %cmp3081 = icmp ne i64 %v3080, 0
  %cv3082 = zext i1 %cmp3081 to i32
  store i32 %cv3082, ptr %slot301, align 8
  %v3083 = load i32, ptr %slot301, align 8
  %cv3084 = zext i32 %v3083 to i64
  %cond3085 = icmp ne i64 %cv3084, 0
  br i1 %cond3085, label %bb_rcgnn349, label %bb_rcgdone349
bb_rcgnn349:
  %v3086 = load i64, ptr %slot300, align 8
  %op3087 = sub i64 %v3086, 16
  store i64 %op3087, ptr %slot302, align 8
  %v3088 = load i64, ptr %slot300, align 8
  %p3089 = inttoptr i64 %v3088 to ptr
  %rgep3090 = getelementptr i8, ptr %p3089, i64 -16
  %ld3091 = load i64, ptr %rgep3090, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3091, ptr %slot303, align 8
  %v3092 = load i64, ptr %slot303, align 8
  %op3093 = and i64 %v3092, 4611686018427387906
  store i64 %op3093, ptr %slot304, align 8
  %v3094 = load i64, ptr %slot304, align 8
  %cmp3095 = icmp ne i64 %v3094, 0
  %cv3096 = zext i1 %cmp3095 to i32
  store i32 %cv3096, ptr %slot305, align 8
  %v3097 = load i32, ptr %slot305, align 8
  %cv3098 = zext i32 %v3097 to i64
  %cond3099 = icmp ne i64 %cv3098, 0
  br i1 %cond3099, label %bb_rcgclear349, label %bb_rcgcounted349
bb_rcgcounted349:
  %v3100 = load i64, ptr %slot300, align 8
  %op3101 = sub i64 %v3100, 32
  store i64 %op3101, ptr %slot306, align 8
  %v3102 = load i64, ptr %slot300, align 8
  %p3103 = inttoptr i64 %v3102 to ptr
  %rgep3104 = getelementptr i8, ptr %p3103, i64 -32
  %ld3105 = load i64, ptr %rgep3104, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3105, ptr %slot307, align 8
  %v3106 = load i64, ptr %slot307, align 8
  %op3107 = sub i64 %v3106, 1
  store i64 %op3107, ptr %slot308, align 8
  %v3108 = load i64, ptr %slot308, align 8
  %cmp3109 = icmp eq i64 %v3108, 0
  %cv3110 = zext i1 %cmp3109 to i32
  store i32 %cv3110, ptr %slot309, align 8
  %v3111 = load i32, ptr %slot309, align 8
  %cv3112 = zext i32 %v3111 to i64
  %cond3113 = icmp ne i64 %cv3112, 0
  br i1 %cond3113, label %bb_rcglast349, label %bb_rcgdec349
bb_rcglast349:
  %v3114 = load i64, ptr %slot300, align 8
  %op3115 = sub i64 %v3114, 24
  store i64 %op3115, ptr %slot310, align 8
  %v3116 = load i64, ptr %slot300, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  %rgep3118 = getelementptr i8, ptr %p3117, i64 -24
  %ld3119 = load i64, ptr %rgep3118, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3119, ptr %slot311, align 8
  %v3120 = load i64, ptr %slot311, align 8
  %cmp3121 = icmp ne i64 %v3120, 0
  %cv3122 = zext i1 %cmp3121 to i32
  store i32 %cv3122, ptr %slot312, align 8
  %v3123 = load i32, ptr %slot312, align 8
  %cv3124 = zext i32 %v3123 to i64
  %cond3125 = icmp ne i64 %cv3124, 0
  br i1 %cond3125, label %bb_rcgdec349, label %bb_rcgslow349
bb_rcgslow349:
  %v3126 = load i64, ptr %slot299, align 8
  %v3127 = load i64, ptr %slot282, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v3126, i64 %v3127) nomerge, !dbg !132
  br label %bb_rcgdone349
bb_rcgdec349:
  %v3128 = load i64, ptr %slot308, align 8
  %v3129 = load i64, ptr %slot300, align 8
  %p3130 = inttoptr i64 %v3129 to ptr
  %rgep3131 = getelementptr i8, ptr %p3130, i64 -32
  store i64 %v3128, ptr %rgep3131, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear349
bb_rcgclear349:
  %v3132 = load i64, ptr %slot282, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  store i64 0, ptr %p3133, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone349
bb_rcgdone349:
  br label %bb_rcslotdone318
bb_rcslotdone318:
  %v3134 = load i64, ptr %slot45, align 8
  store i64 %v3134, ptr %slot313, align 8
  %v3135 = load i64, ptr %slot28, align 8
  store i64 %v3135, ptr %slot314, align 8
  %v3136 = load i64, ptr %slot314, align 8
  %v3137 = load i64, ptr %slot313, align 8
  %p3138 = inttoptr i64 %v3136 to ptr
  %p3139 = inttoptr i64 %v3137 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3139, ptr %p3138, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3140 = load i64, ptr %slot21, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  store i32 0, ptr %p3141, align 4, !alias.scope !3, !noalias !4
  %v3142 = load i64, ptr %slot10, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  store i32 2, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  %v3144 = load i64, ptr %slot22, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  %ld3146 = load i32, ptr %p3145, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3146, ptr %slot315, align 8
  %v3147 = load i32, ptr %slot315, align 8
  %v3148 = load i64, ptr %slot10, align 8
  %p3149 = inttoptr i64 %v3148 to ptr
  store i32 %v3147, ptr %p3149, align 4, !alias.scope !3, !noalias !4
  %v3150 = load i64, ptr %slot9, align 8
  %p3151 = inttoptr i64 %v3150 to ptr
  store i32 1, ptr %p3151, align 4, !alias.scope !3, !noalias !4
  %v3152 = load i64, ptr %slot44, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  %ld3154 = load i64, ptr %p3153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3154, ptr %slot316, align 8
  %v3155 = load i64, ptr %slot316, align 8
  %v3156 = load i64, ptr %slot57, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  store i64 %v3155, ptr %p3157, align 8, !alias.scope !3, !noalias !4
  %v3158 = load i64, ptr %slot57, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  %ld3160 = load i64, ptr %p3159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3160, ptr %slot317, align 8
  %v3161 = load i64, ptr %slot317, align 8
  %v3162 = load i64, ptr %slot46, align 8
  %p3163 = inttoptr i64 %v3162 to ptr
  store i64 %v3161, ptr %p3163, align 8, !alias.scope !3, !noalias !4
  %v3164 = load i64, ptr %slot46, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  %ld3166 = load i64, ptr %p3165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3166, ptr %slot318, align 8
  %v3167 = load i64, ptr %slot318, align 8
  %v3168 = load i64, ptr %slot57, align 8
  %p3169 = inttoptr i64 %v3168 to ptr
  store i64 %v3167, ptr %p3169, align 8, !alias.scope !3, !noalias !4
  %v3170 = load i64, ptr %slot58, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  store i64 0, ptr %p3171, align 8, !alias.scope !3, !noalias !4
  %v3172 = load i64, ptr %slot58, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  %ld3174 = load i64, ptr %p3173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3174, ptr %slot319, align 8
  %v3175 = load i64, ptr %slot57, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  %ld3177 = load i64, ptr %p3176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3177, ptr %slot320, align 8
  %v3178 = load i64, ptr %slot320, align 8
  %v3179 = load i64, ptr %slot319, align 8
  %cmp3180 = icmp slt i64 %v3178, %v3179
  %cv3181 = zext i1 %cmp3180 to i64
  store i64 %cv3181, ptr %slot321, align 8
  %v3182 = load i64, ptr %slot321, align 8
  %v3183 = load i64, ptr %slot57, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  store i64 %v3182, ptr %p3184, align 8, !alias.scope !3, !noalias !4
  %v3185 = load i64, ptr %slot57, align 8
  %p3186 = inttoptr i64 %v3185 to ptr
  %ld3187 = load i64, ptr %p3186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3187, ptr %slot322, align 8
  %v3188 = load i64, ptr %slot322, align 8
  %cond3189 = icmp ne i64 %v3188, 0
  br i1 %cond3189, label %bb_next367, label %bb_i42
bb_next367:
  %v3190 = load i64, ptr %slot45, align 8
  %p3191 = inttoptr i64 %v3190 to ptr
  %ld3192 = load i64, ptr %p3191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3192, ptr %slot323, align 8
  %v3193 = load i64, ptr %slot323, align 8
  %op3194 = add i64 %v3193, 0
  store i64 %op3194, ptr %slot324, align 8
  %v3195 = load i64, ptr %slot324, align 8
  %p3196 = inttoptr i64 %v3195 to ptr
  %ld3197 = load i64, ptr %p3196, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3197, ptr %slot325, align 8
  %v3198 = load i64, ptr %slot325, align 8
  %v3199 = load i64, ptr %slot57, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  store i64 %v3198, ptr %p3200, align 8, !alias.scope !3, !noalias !4
  %v3201 = load i64, ptr %slot57, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  %ld3203 = load i64, ptr %p3202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3203, ptr %slot326, align 8
  %v3204 = load i64, ptr %slot326, align 8
  %cmp3205 = icmp ugt i64 %v3204, 9223372036854775807
  %cv3206 = zext i1 %cmp3205 to i64
  store i64 %cv3206, ptr %slot327, align 8
  %v3207 = load i64, ptr %slot327, align 8
  %cond3208 = icmp ne i64 %v3207, 0
  br i1 %cond3208, label %bb_cast_overflow372, label %bb_cast_ok372
bb_cast_overflow372:
  %v3209 = load i64, ptr %slot1, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  %v3211 = load i64, ptr %slot326, align 8
  call void @myl_qbe_fail_cast(ptr %p3210, i64 %v3211, i64 320) nomerge, !dbg !134
  unreachable
bb_cast_ok372:
  %v3212 = load i64, ptr %slot326, align 8
  %v3213 = load i64, ptr %slot57, align 8
  %p3214 = inttoptr i64 %v3213 to ptr
  store i64 %v3212, ptr %p3214, align 8, !alias.scope !3, !noalias !4
  %v3215 = load i64, ptr %slot46, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  %ld3217 = load i64, ptr %p3216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3217, ptr %slot328, align 8
  %v3218 = load i64, ptr %slot328, align 8
  %v3219 = load i64, ptr %slot58, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  store i64 %v3218, ptr %p3220, align 8, !alias.scope !3, !noalias !4
  %v3221 = load i64, ptr %slot58, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  %ld3223 = load i64, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3223, ptr %slot329, align 8
  %v3224 = load i64, ptr %slot57, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  %ld3226 = load i64, ptr %p3225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3226, ptr %slot330, align 8
  %v3227 = load i64, ptr %slot330, align 8
  %v3228 = load i64, ptr %slot329, align 8
  %ovpair3230 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3227, i64 %v3228)
  %op3229 = extractvalue { i64, i1 } %ovpair3230, 0
  %ov3231 = extractvalue { i64, i1 } %ovpair3230, 1
  store i64 %op3229, ptr %slot331, align 8
  %v3232 = load i64, ptr %slot330, align 8
  %v3233 = load i64, ptr %slot331, align 8
  %op3234 = xor i64 %v3232, %v3233
  store i64 %op3234, ptr %slot332, align 8
  %v3235 = load i64, ptr %slot329, align 8
  %v3236 = load i64, ptr %slot331, align 8
  %op3237 = xor i64 %v3235, %v3236
  store i64 %op3237, ptr %slot333, align 8
  %v3238 = load i64, ptr %slot332, align 8
  %v3239 = load i64, ptr %slot333, align 8
  %op3240 = and i64 %v3238, %v3239
  store i64 %op3240, ptr %slot334, align 8
  %cv3241 = zext i1 %ov3231 to i64
  store i64 %cv3241, ptr %slot335, align 8
  %v3242 = load i64, ptr %slot335, align 8
  %cond3243 = icmp ne i64 %v3242, 0
  br i1 %cond3243, label %bb_overflow376, label %bb_checked376
bb_overflow376:
  %v3244 = load i64, ptr %slot1, align 8
  %p3245 = inttoptr i64 %v3244 to ptr
  %v3246 = load i64, ptr %slot330, align 8
  %v3247 = load i64, ptr %slot329, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3245, i64 0, i64 %v3246, i64 %v3247, i64 64) nomerge, !dbg !136
  unreachable
bb_checked376:
  %v3248 = load i64, ptr %slot331, align 8
  %v3249 = load i64, ptr %slot57, align 8
  %p3250 = inttoptr i64 %v3249 to ptr
  store i64 %v3248, ptr %p3250, align 8, !alias.scope !3, !noalias !4
  %v3251 = load i64, ptr %slot57, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  %ld3253 = load i64, ptr %p3252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3253, ptr %slot336, align 8
  %v3254 = load i64, ptr %slot336, align 8
  %v3255 = load i64, ptr %slot46, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  store i64 %v3254, ptr %p3256, align 8, !alias.scope !3, !noalias !4
  br label %bb_i42
bb_i42:
  %v3257 = load i64, ptr %slot46, align 8
  %p3258 = inttoptr i64 %v3257 to ptr
  %ld3259 = load i64, ptr %p3258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3259, ptr %slot337, align 8
  %v3260 = load i64, ptr %slot337, align 8
  %v3261 = load i64, ptr %slot57, align 8
  %p3262 = inttoptr i64 %v3261 to ptr
  store i64 %v3260, ptr %p3262, align 8, !alias.scope !3, !noalias !4
  %v3263 = load i64, ptr %slot45, align 8
  %p3264 = inttoptr i64 %v3263 to ptr
  %ld3265 = load i64, ptr %p3264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3265, ptr %slot338, align 8
  %v3266 = load i64, ptr %slot57, align 8
  %p3267 = inttoptr i64 %v3266 to ptr
  %ld3268 = load i64, ptr %p3267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3268, ptr %slot339, align 8
  %v3269 = load i64, ptr %slot338, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  %ld3271 = load i64, ptr %p3270, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3271, ptr %slot340, align 8
  %v3272 = load i64, ptr %slot339, align 8
  %v3273 = load i64, ptr %slot340, align 8
  %cmp3274 = icmp ult i64 %v3272, %v3273
  %cv3275 = zext i1 %cmp3274 to i64
  store i64 %cv3275, ptr %slot341, align 8
  %v3276 = load i64, ptr %slot341, align 8
  %cond3277 = icmp ne i64 %v3276, 0
  br i1 %cond3277, label %bb_success388, label %bb_failed388
bb_failed388:
  %v3278 = load i64, ptr %slot1, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  %v3280 = load i64, ptr %slot339, align 8
  %v3281 = load i64, ptr %slot340, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3279, i64 %v3280, i64 %v3281) nomerge, !dbg !138
  unreachable
bb_success388:
  %v3282 = load i64, ptr %slot338, align 8
  %op3283 = add i64 %v3282, 32
  store i64 %op3283, ptr %slot342, align 8
  %v3284 = load i64, ptr %slot342, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  %ld3286 = load i64, ptr %p3285, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3286, ptr %slot343, align 8
  %v3287 = load i64, ptr %slot339, align 8
  %op3288 = mul i64 %v3287, 16
  store i64 %op3288, ptr %slot344, align 8
  %v3289 = load i64, ptr %slot343, align 8
  %v3290 = load i64, ptr %slot344, align 8
  %op3291 = add i64 %v3289, %v3290
  store i64 %op3291, ptr %slot345, align 8
  %v3292 = load i64, ptr %slot345, align 8
  %v3293 = load i64, ptr %slot57, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  store i64 %v3292, ptr %p3294, align 8, !alias.scope !3, !noalias !4
  %v3295 = load i64, ptr %slot57, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  %ld3297 = load i64, ptr %p3296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3297, ptr %slot346, align 8
  %v3298 = load i64, ptr %slot346, align 8
  %v3299 = load i64, ptr %slot47, align 8
  %p3300 = inttoptr i64 %v3298 to ptr
  %p3301 = inttoptr i64 %v3299 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3301, ptr %p3300, i64 16, i1 false)
  %v3302 = load i64, ptr %slot9, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  %ld3304 = load i32, ptr %p3303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3304, ptr %slot347, align 8
  %v3305 = load i32, ptr %slot347, align 8
  %cv3306 = zext i32 %v3305 to i64
  %cond3307 = icmp ne i64 %cv3306, 0
  br i1 %cond3307, label %bb_rcslotdrop396, label %bb_rcslotdone396
bb_rcslotdrop396:
  %v3308 = load i64, ptr %slot9, align 8
  %p3309 = inttoptr i64 %v3308 to ptr
  store i32 0, ptr %p3309, align 4, !alias.scope !3, !noalias !4
  %v3310 = load i64, ptr %slot45, align 8
  store i64 %v3310, ptr %slot348, align 8
  %v3311 = load i64, ptr %slot10, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  %ld3313 = load i32, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3313, ptr %slot349, align 8
  %v3314 = load i32, ptr %slot349, align 8
  %op3315 = and i32 %v3314, 28
  store i32 %op3315, ptr %slot350, align 8
  %v3316 = load i32, ptr %slot350, align 8
  %cv3317 = zext i32 %v3316 to i64
  %cond3318 = icmp ne i64 %cv3317, 0
  br i1 %cond3318, label %bb_rcslotrole396, label %bb_rcslotowner396
bb_rcslotrole396:
  %v3319 = load i64, ptr %slot70, align 8
  store i64 %v3319, ptr %slot351, align 8
  %v3320 = load i64, ptr %slot348, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  %ld3322 = load i64, ptr %p3321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3322, ptr %slot352, align 8
  %v3323 = load i64, ptr %slot352, align 8
  %cmp3324 = icmp ne i64 %v3323, 0
  %cv3325 = zext i1 %cmp3324 to i32
  store i32 %cv3325, ptr %slot353, align 8
  %v3326 = load i32, ptr %slot353, align 8
  %cv3327 = zext i32 %v3326 to i64
  %cond3328 = icmp ne i64 %cv3327, 0
  br i1 %cond3328, label %bb_rcgnn412, label %bb_rcgdone412
bb_rcgnn412:
  %v3329 = load i64, ptr %slot352, align 8
  %op3330 = sub i64 %v3329, 16
  store i64 %op3330, ptr %slot354, align 8
  %v3331 = load i64, ptr %slot352, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  %rgep3333 = getelementptr i8, ptr %p3332, i64 -16
  %ld3334 = load i64, ptr %rgep3333, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3334, ptr %slot355, align 8
  %v3335 = load i64, ptr %slot355, align 8
  %op3336 = and i64 %v3335, 4611686018427387906
  store i64 %op3336, ptr %slot356, align 8
  %v3337 = load i64, ptr %slot356, align 8
  %cmp3338 = icmp ne i64 %v3337, 0
  %cv3339 = zext i1 %cmp3338 to i32
  store i32 %cv3339, ptr %slot357, align 8
  %v3340 = load i32, ptr %slot357, align 8
  %cv3341 = zext i32 %v3340 to i64
  %cond3342 = icmp ne i64 %cv3341, 0
  br i1 %cond3342, label %bb_rcgclear412, label %bb_rcgcounted412
bb_rcgcounted412:
  %v3343 = load i64, ptr %slot352, align 8
  %op3344 = sub i64 %v3343, 24
  store i64 %op3344, ptr %slot358, align 8
  %v3345 = load i64, ptr %slot352, align 8
  %p3346 = inttoptr i64 %v3345 to ptr
  %rgep3347 = getelementptr i8, ptr %p3346, i64 -24
  %ld3348 = load i64, ptr %rgep3347, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3348, ptr %slot359, align 8
  %v3349 = load i64, ptr %slot359, align 8
  %op3350 = sub i64 %v3349, 1
  store i64 %op3350, ptr %slot360, align 8
  %v3351 = load i64, ptr %slot360, align 8
  %cmp3352 = icmp eq i64 %v3351, 0
  %cv3353 = zext i1 %cmp3352 to i32
  store i32 %cv3353, ptr %slot361, align 8
  %v3354 = load i32, ptr %slot361, align 8
  %cv3355 = zext i32 %v3354 to i64
  %cond3356 = icmp ne i64 %cv3355, 0
  br i1 %cond3356, label %bb_rcglast412, label %bb_rcgdec412
bb_rcglast412:
  %v3357 = load i64, ptr %slot352, align 8
  %op3358 = sub i64 %v3357, 32
  store i64 %op3358, ptr %slot362, align 8
  %v3359 = load i64, ptr %slot352, align 8
  %p3360 = inttoptr i64 %v3359 to ptr
  %rgep3361 = getelementptr i8, ptr %p3360, i64 -32
  %ld3362 = load i64, ptr %rgep3361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3362, ptr %slot363, align 8
  %v3363 = load i64, ptr %slot363, align 8
  %cmp3364 = icmp ne i64 %v3363, 0
  %cv3365 = zext i1 %cmp3364 to i32
  store i32 %cv3365, ptr %slot364, align 8
  %v3366 = load i32, ptr %slot364, align 8
  %cv3367 = zext i32 %v3366 to i64
  %cond3368 = icmp ne i64 %cv3367, 0
  br i1 %cond3368, label %bb_rcgdec412, label %bb_rcgslow412
bb_rcgslow412:
  %v3369 = load i64, ptr %slot351, align 8
  %v3370 = load i64, ptr %slot348, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v3369, i64 %v3370) nomerge, !dbg !140
  br label %bb_rcgdone412
bb_rcgdec412:
  %v3371 = load i64, ptr %slot360, align 8
  %v3372 = load i64, ptr %slot352, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  %rgep3374 = getelementptr i8, ptr %p3373, i64 -24
  store i64 %v3371, ptr %rgep3374, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear412
bb_rcgclear412:
  %v3375 = load i64, ptr %slot348, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  store i64 0, ptr %p3376, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone412
bb_rcgdone412:
  br label %bb_rcslotdone396
bb_rcslotowner396:
  %v3377 = load i64, ptr %slot70, align 8
  store i64 %v3377, ptr %slot365, align 8
  %v3378 = load i64, ptr %slot348, align 8
  %p3379 = inttoptr i64 %v3378 to ptr
  %ld3380 = load i64, ptr %p3379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3380, ptr %slot366, align 8
  %v3381 = load i64, ptr %slot366, align 8
  %cmp3382 = icmp ne i64 %v3381, 0
  %cv3383 = zext i1 %cmp3382 to i32
  store i32 %cv3383, ptr %slot367, align 8
  %v3384 = load i32, ptr %slot367, align 8
  %cv3385 = zext i32 %v3384 to i64
  %cond3386 = icmp ne i64 %cv3385, 0
  br i1 %cond3386, label %bb_rcgnn427, label %bb_rcgdone427
bb_rcgnn427:
  %v3387 = load i64, ptr %slot366, align 8
  %op3388 = sub i64 %v3387, 16
  store i64 %op3388, ptr %slot368, align 8
  %v3389 = load i64, ptr %slot366, align 8
  %p3390 = inttoptr i64 %v3389 to ptr
  %rgep3391 = getelementptr i8, ptr %p3390, i64 -16
  %ld3392 = load i64, ptr %rgep3391, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3392, ptr %slot369, align 8
  %v3393 = load i64, ptr %slot369, align 8
  %op3394 = and i64 %v3393, 4611686018427387906
  store i64 %op3394, ptr %slot370, align 8
  %v3395 = load i64, ptr %slot370, align 8
  %cmp3396 = icmp ne i64 %v3395, 0
  %cv3397 = zext i1 %cmp3396 to i32
  store i32 %cv3397, ptr %slot371, align 8
  %v3398 = load i32, ptr %slot371, align 8
  %cv3399 = zext i32 %v3398 to i64
  %cond3400 = icmp ne i64 %cv3399, 0
  br i1 %cond3400, label %bb_rcgclear427, label %bb_rcgcounted427
bb_rcgcounted427:
  %v3401 = load i64, ptr %slot366, align 8
  %op3402 = sub i64 %v3401, 32
  store i64 %op3402, ptr %slot372, align 8
  %v3403 = load i64, ptr %slot366, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  %rgep3405 = getelementptr i8, ptr %p3404, i64 -32
  %ld3406 = load i64, ptr %rgep3405, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3406, ptr %slot373, align 8
  %v3407 = load i64, ptr %slot373, align 8
  %op3408 = sub i64 %v3407, 1
  store i64 %op3408, ptr %slot374, align 8
  %v3409 = load i64, ptr %slot374, align 8
  %cmp3410 = icmp eq i64 %v3409, 0
  %cv3411 = zext i1 %cmp3410 to i32
  store i32 %cv3411, ptr %slot375, align 8
  %v3412 = load i32, ptr %slot375, align 8
  %cv3413 = zext i32 %v3412 to i64
  %cond3414 = icmp ne i64 %cv3413, 0
  br i1 %cond3414, label %bb_rcglast427, label %bb_rcgdec427
bb_rcglast427:
  %v3415 = load i64, ptr %slot366, align 8
  %op3416 = sub i64 %v3415, 24
  store i64 %op3416, ptr %slot376, align 8
  %v3417 = load i64, ptr %slot366, align 8
  %p3418 = inttoptr i64 %v3417 to ptr
  %rgep3419 = getelementptr i8, ptr %p3418, i64 -24
  %ld3420 = load i64, ptr %rgep3419, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3420, ptr %slot377, align 8
  %v3421 = load i64, ptr %slot377, align 8
  %cmp3422 = icmp ne i64 %v3421, 0
  %cv3423 = zext i1 %cmp3422 to i32
  store i32 %cv3423, ptr %slot378, align 8
  %v3424 = load i32, ptr %slot378, align 8
  %cv3425 = zext i32 %v3424 to i64
  %cond3426 = icmp ne i64 %cv3425, 0
  br i1 %cond3426, label %bb_rcgdec427, label %bb_rcgslow427
bb_rcgslow427:
  %v3427 = load i64, ptr %slot365, align 8
  %v3428 = load i64, ptr %slot348, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v3427, i64 %v3428) nomerge, !dbg !140
  br label %bb_rcgdone427
bb_rcgdec427:
  %v3429 = load i64, ptr %slot374, align 8
  %v3430 = load i64, ptr %slot366, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %rgep3432 = getelementptr i8, ptr %p3431, i64 -32
  store i64 %v3429, ptr %rgep3432, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear427
bb_rcgclear427:
  %v3433 = load i64, ptr %slot348, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  store i64 0, ptr %p3434, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone427
bb_rcgdone427:
  br label %bb_rcslotdone396
bb_rcslotdone396:
  %v3435 = load i64, ptr %slot47, align 8
  %v3436 = load i64, ptr %slot57, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  store i64 %v3435, ptr %p3437, align 8, !alias.scope !3, !noalias !4
  %v3438 = load i64, ptr %slot57, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  %ld3440 = load i64, ptr %p3439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3440, ptr %slot379, align 8
  %v3441 = load i64, ptr %slot379, align 8
  %op3442 = add i64 %v3441, 0
  store i64 %op3442, ptr %slot380, align 8
  %v3443 = load i64, ptr %slot380, align 8
  %p3444 = inttoptr i64 %v3443 to ptr
  %ld3445 = load i64, ptr %p3444, align 8
  store i64 %ld3445, ptr %slot381, align 8
  %v3446 = load i64, ptr %slot381, align 8
  %v3447 = load i64, ptr %slot57, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  store i64 %v3446, ptr %p3448, align 8, !alias.scope !3, !noalias !4
  %v3449 = load i64, ptr %slot38, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  %ld3451 = load i64, ptr %p3450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3451, ptr %slot382, align 8
  %v3452 = load i64, ptr %slot382, align 8
  %v3453 = load i64, ptr %slot58, align 8
  %p3454 = inttoptr i64 %v3453 to ptr
  store i64 %v3452, ptr %p3454, align 8, !alias.scope !3, !noalias !4
  %v3455 = load i64, ptr %slot58, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  %ld3457 = load i64, ptr %p3456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3457, ptr %slot383, align 8
  %v3458 = load i64, ptr %slot57, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  %ld3460 = load i64, ptr %p3459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3460, ptr %slot384, align 8
  %v3461 = load i64, ptr %slot384, align 8
  %v3462 = load i64, ptr %slot383, align 8
  %cmp3463 = icmp eq i64 %v3461, %v3462
  %cv3464 = zext i1 %cmp3463 to i64
  store i64 %cv3464, ptr %slot385, align 8
  %v3465 = load i64, ptr %slot385, align 8
  %v3466 = load i64, ptr %slot57, align 8
  %p3467 = inttoptr i64 %v3466 to ptr
  store i64 %v3465, ptr %p3467, align 8, !alias.scope !3, !noalias !4
  %v3468 = load i64, ptr %slot57, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  %ld3470 = load i64, ptr %p3469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3470, ptr %slot386, align 8
  %v3471 = load i64, ptr %slot386, align 8
  %cond3472 = icmp ne i64 %v3471, 0
  br i1 %cond3472, label %bb_next439, label %bb_i55
bb_next439:
  %v3473 = load i64, ptr %slot47, align 8
  %v3474 = load i64, ptr %slot57, align 8
  %p3475 = inttoptr i64 %v3474 to ptr
  store i64 %v3473, ptr %p3475, align 8, !alias.scope !3, !noalias !4
  %v3476 = load i64, ptr %slot57, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  %ld3478 = load i64, ptr %p3477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3478, ptr %slot387, align 8
  %v3479 = load i64, ptr %slot387, align 8
  %op3480 = add i64 %v3479, 8
  store i64 %op3480, ptr %slot388, align 8
  %v3481 = load i64, ptr %slot388, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  %ld3483 = load i8, ptr %p3482, align 1
  %ext3484 = zext i8 %ld3483 to i64
  store i64 %ext3484, ptr %slot389, align 8
  %v3485 = load i64, ptr %slot389, align 8
  %v3486 = load i64, ptr %slot57, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  store i64 %v3485, ptr %p3487, align 8, !alias.scope !3, !noalias !4
  %v3488 = load i64, ptr %slot39, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %ld3490 = load i64, ptr %p3489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3490, ptr %slot390, align 8
  %v3491 = load i64, ptr %slot390, align 8
  %v3492 = load i64, ptr %slot58, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  store i64 %v3491, ptr %p3493, align 8, !alias.scope !3, !noalias !4
  %v3494 = load i64, ptr %slot58, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  %ld3496 = load i64, ptr %p3495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3496, ptr %slot391, align 8
  %v3497 = load i64, ptr %slot57, align 8
  %p3498 = inttoptr i64 %v3497 to ptr
  %ld3499 = load i64, ptr %p3498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3499, ptr %slot392, align 8
  %v3500 = load i64, ptr %slot392, align 8
  %v3501 = load i64, ptr %slot391, align 8
  %cmp3502 = icmp eq i64 %v3500, %v3501
  %cv3503 = zext i1 %cmp3502 to i64
  store i64 %cv3503, ptr %slot393, align 8
  %v3504 = load i64, ptr %slot393, align 8
  %v3505 = load i64, ptr %slot57, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  store i64 %v3504, ptr %p3506, align 8, !alias.scope !3, !noalias !4
  br label %bb_i56
bb_i55:
  %v3507 = load i64, ptr %slot57, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  store i64 0, ptr %p3508, align 8, !alias.scope !3, !noalias !4
  br label %bb_i56
bb_i56:
  %v3509 = load i64, ptr %slot57, align 8
  %p3510 = inttoptr i64 %v3509 to ptr
  %ld3511 = load i64, ptr %p3510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3511, ptr %slot394, align 8
  %v3512 = load i64, ptr %slot394, align 8
  %cond3513 = icmp ne i64 %v3512, 0
  br i1 %cond3513, label %bb_next447, label %bb_i59
bb_next447:
  %v3514 = load i64, ptr %slot44, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  %ld3516 = load i64, ptr %p3515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3516, ptr %slot395, align 8
  %v3517 = load i64, ptr %slot395, align 8
  %v3518 = load i64, ptr %slot57, align 8
  %p3519 = inttoptr i64 %v3518 to ptr
  store i64 %v3517, ptr %p3519, align 8, !alias.scope !3, !noalias !4
  %v3520 = load i64, ptr %slot57, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  %ld3522 = load i64, ptr %p3521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3522, ptr %slot396, align 8
  %v3523 = load i64, ptr %slot29, align 8
  %p3525 = inttoptr i64 %v3523 to ptr
  %gep3526 = getelementptr i8, ptr %p3525, i64 24
  %op3524 = ptrtoint ptr %gep3526 to i64
  store i64 %op3524, ptr %slot397, align 8
  %v3527 = load i64, ptr %slot397, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  %ld3529 = load i32, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3529, ptr %slot398, align 8
  %v3530 = load i64, ptr %slot31, align 8
  %p3532 = inttoptr i64 %v3530 to ptr
  %gep3533 = getelementptr i8, ptr %p3532, i64 24
  %op3531 = ptrtoint ptr %gep3533 to i64
  store i64 %op3531, ptr %slot399, align 8
  %v3534 = load i64, ptr %slot399, align 8
  %p3535 = inttoptr i64 %v3534 to ptr
  %ld3536 = load i32, ptr %p3535, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3536, ptr %slot400, align 8
  %v3537 = load i32, ptr %slot398, align 8
  %v3538 = load i32, ptr %slot400, align 8
  %op3539 = or i32 %v3537, %v3538
  store i32 %op3539, ptr %slot401, align 8
  %v3540 = load i64, ptr %slot33, align 8
  %p3542 = inttoptr i64 %v3540 to ptr
  %gep3543 = getelementptr i8, ptr %p3542, i64 24
  %op3541 = ptrtoint ptr %gep3543 to i64
  store i64 %op3541, ptr %slot402, align 8
  %v3544 = load i64, ptr %slot402, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  %ld3546 = load i32, ptr %p3545, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3546, ptr %slot403, align 8
  %v3547 = load i32, ptr %slot401, align 8
  %v3548 = load i32, ptr %slot403, align 8
  %op3549 = or i32 %v3547, %v3548
  store i32 %op3549, ptr %slot404, align 8
  %v3550 = load i32, ptr %slot404, align 8
  %cv3551 = zext i32 %v3550 to i64
  %cond3552 = icmp ne i64 %cv3551, 0
  br i1 %cond3552, label %bb_rcscopesopen457, label %bb_rcscopesclosed457
bb_rcscopesopen457:
  %v3553 = load i64, ptr %slot35, align 8
  %p3555 = inttoptr i64 %v3553 to ptr
  %gep3556 = getelementptr i8, ptr %p3555, i64 0
  %op3554 = ptrtoint ptr %gep3556 to i64
  store i64 %op3554, ptr %slot405, align 8
  %v3557 = load i64, ptr %slot29, align 8
  %v3558 = load i64, ptr %slot405, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  store i64 %v3557, ptr %p3559, align 8, !alias.scope !3, !noalias !4
  %v3560 = load i64, ptr %slot35, align 8
  %p3562 = inttoptr i64 %v3560 to ptr
  %gep3563 = getelementptr i8, ptr %p3562, i64 8
  %op3561 = ptrtoint ptr %gep3563 to i64
  store i64 %op3561, ptr %slot406, align 8
  %v3564 = load i64, ptr %slot31, align 8
  %v3565 = load i64, ptr %slot406, align 8
  %p3566 = inttoptr i64 %v3565 to ptr
  store i64 %v3564, ptr %p3566, align 8, !alias.scope !3, !noalias !4
  %v3567 = load i64, ptr %slot35, align 8
  %p3569 = inttoptr i64 %v3567 to ptr
  %gep3570 = getelementptr i8, ptr %p3569, i64 16
  %op3568 = ptrtoint ptr %gep3570 to i64
  store i64 %op3568, ptr %slot407, align 8
  %v3571 = load i64, ptr %slot33, align 8
  %v3572 = load i64, ptr %slot407, align 8
  %p3573 = inttoptr i64 %v3572 to ptr
  store i64 %v3571, ptr %p3573, align 8, !alias.scope !3, !noalias !4
  %v3574 = load i64, ptr %slot1, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  %v3576 = load i64, ptr %slot35, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p3575, ptr %p3577, i64 3) nomerge, !dbg !142
  br label %bb_rcscopesclosed457
bb_rcscopesclosed457:
  %v3578 = load i64, ptr %slot17, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  %ld3580 = load i32, ptr %p3579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3580, ptr %slot408, align 8
  %v3581 = load i32, ptr %slot408, align 8
  %cv3582 = zext i32 %v3581 to i64
  %cond3583 = icmp ne i64 %cv3582, 0
  br i1 %cond3583, label %bb_rcslotdrop463, label %bb_rcslotdone463
bb_rcslotdrop463:
  %v3584 = load i64, ptr %slot17, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  store i32 0, ptr %p3585, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone463
bb_rcslotdone463:
  %v3586 = load i64, ptr %slot15, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  %ld3588 = load i32, ptr %p3587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3588, ptr %slot409, align 8
  %v3589 = load i32, ptr %slot409, align 8
  %cv3590 = zext i32 %v3589 to i64
  %cond3591 = icmp ne i64 %cv3590, 0
  br i1 %cond3591, label %bb_rcslotdrop466, label %bb_rcslotdone466
bb_rcslotdrop466:
  %v3592 = load i64, ptr %slot15, align 8
  %p3593 = inttoptr i64 %v3592 to ptr
  store i32 0, ptr %p3593, align 4, !alias.scope !3, !noalias !4
  %v3594 = load i64, ptr %slot55, align 8
  store i64 %v3594, ptr %slot410, align 8
  %v3595 = load i64, ptr %slot16, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  %ld3597 = load i32, ptr %p3596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3597, ptr %slot411, align 8
  %v3598 = load i32, ptr %slot411, align 8
  %op3599 = and i32 %v3598, 28
  store i32 %op3599, ptr %slot412, align 8
  %v3600 = load i32, ptr %slot412, align 8
  %cv3601 = zext i32 %v3600 to i64
  %cond3602 = icmp ne i64 %cv3601, 0
  br i1 %cond3602, label %bb_rcslotrole466, label %bb_rcslotowner466
bb_rcslotrole466:
  %v3603 = load i64, ptr %slot70, align 8
  store i64 %v3603, ptr %slot413, align 8
  %v3604 = load i64, ptr %slot413, align 8
  %v3605 = load i64, ptr %slot410, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3604, i64 %v3605) nomerge, !dbg !142
  br label %bb_rcslotdone466
bb_rcslotowner466:
  %v3606 = load i64, ptr %slot70, align 8
  store i64 %v3606, ptr %slot414, align 8
  %v3607 = load i64, ptr %slot414, align 8
  %v3608 = load i64, ptr %slot410, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3607, i64 %v3608) nomerge, !dbg !142
  br label %bb_rcslotdone466
bb_rcslotdone466:
  %v3609 = load i64, ptr %slot13, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  %ld3611 = load i32, ptr %p3610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3611, ptr %slot415, align 8
  %v3612 = load i32, ptr %slot415, align 8
  %cv3613 = zext i32 %v3612 to i64
  %cond3614 = icmp ne i64 %cv3613, 0
  br i1 %cond3614, label %bb_rcslotdrop512, label %bb_rcslotdone512
bb_rcslotdrop512:
  %v3615 = load i64, ptr %slot13, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  store i32 0, ptr %p3616, align 4, !alias.scope !3, !noalias !4
  %v3617 = load i64, ptr %slot52, align 8
  store i64 %v3617, ptr %slot416, align 8
  %v3618 = load i64, ptr %slot14, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  %ld3620 = load i32, ptr %p3619, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3620, ptr %slot417, align 8
  %v3621 = load i32, ptr %slot417, align 8
  %op3622 = and i32 %v3621, 28
  store i32 %op3622, ptr %slot418, align 8
  %v3623 = load i32, ptr %slot418, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcslotrole512, label %bb_rcslotowner512
bb_rcslotrole512:
  %v3626 = load i64, ptr %slot70, align 8
  store i64 %v3626, ptr %slot419, align 8
  %v3627 = load i64, ptr %slot419, align 8
  %v3628 = load i64, ptr %slot416, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3627, i64 %v3628) nomerge, !dbg !142
  br label %bb_rcslotdone512
bb_rcslotowner512:
  %v3629 = load i64, ptr %slot70, align 8
  store i64 %v3629, ptr %slot420, align 8
  %v3630 = load i64, ptr %slot420, align 8
  %v3631 = load i64, ptr %slot416, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3630, i64 %v3631) nomerge, !dbg !142
  br label %bb_rcslotdone512
bb_rcslotdone512:
  %v3632 = load i64, ptr %slot11, align 8
  %p3633 = inttoptr i64 %v3632 to ptr
  %ld3634 = load i32, ptr %p3633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3634, ptr %slot421, align 8
  %v3635 = load i32, ptr %slot421, align 8
  %cv3636 = zext i32 %v3635 to i64
  %cond3637 = icmp ne i64 %cv3636, 0
  br i1 %cond3637, label %bb_rcslotdrop558, label %bb_rcslotdone558
bb_rcslotdrop558:
  %v3638 = load i64, ptr %slot11, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  store i32 0, ptr %p3639, align 4, !alias.scope !3, !noalias !4
  %v3640 = load i64, ptr %slot49, align 8
  store i64 %v3640, ptr %slot422, align 8
  %v3641 = load i64, ptr %slot12, align 8
  %p3642 = inttoptr i64 %v3641 to ptr
  %ld3643 = load i32, ptr %p3642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3643, ptr %slot423, align 8
  %v3644 = load i32, ptr %slot423, align 8
  %op3645 = and i32 %v3644, 28
  store i32 %op3645, ptr %slot424, align 8
  %v3646 = load i32, ptr %slot424, align 8
  %cv3647 = zext i32 %v3646 to i64
  %cond3648 = icmp ne i64 %cv3647, 0
  br i1 %cond3648, label %bb_rcslotrole558, label %bb_rcslotowner558
bb_rcslotrole558:
  %v3649 = load i64, ptr %slot70, align 8
  store i64 %v3649, ptr %slot425, align 8
  %v3650 = load i64, ptr %slot425, align 8
  %v3651 = load i64, ptr %slot422, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3650, i64 %v3651) nomerge, !dbg !142
  br label %bb_rcslotdone558
bb_rcslotowner558:
  %v3652 = load i64, ptr %slot70, align 8
  store i64 %v3652, ptr %slot426, align 8
  %v3653 = load i64, ptr %slot426, align 8
  %v3654 = load i64, ptr %slot422, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3653, i64 %v3654) nomerge, !dbg !142
  br label %bb_rcslotdone558
bb_rcslotdone558:
  %v3655 = load i64, ptr %slot9, align 8
  %p3656 = inttoptr i64 %v3655 to ptr
  %ld3657 = load i32, ptr %p3656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3657, ptr %slot427, align 8
  %v3658 = load i32, ptr %slot427, align 8
  %cv3659 = zext i32 %v3658 to i64
  %cond3660 = icmp ne i64 %cv3659, 0
  br i1 %cond3660, label %bb_rcslotdrop604, label %bb_rcslotdone604
bb_rcslotdrop604:
  %v3661 = load i64, ptr %slot9, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  store i32 0, ptr %p3662, align 4, !alias.scope !3, !noalias !4
  %v3663 = load i64, ptr %slot45, align 8
  store i64 %v3663, ptr %slot428, align 8
  %v3664 = load i64, ptr %slot10, align 8
  %p3665 = inttoptr i64 %v3664 to ptr
  %ld3666 = load i32, ptr %p3665, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3666, ptr %slot429, align 8
  %v3667 = load i32, ptr %slot429, align 8
  %op3668 = and i32 %v3667, 28
  store i32 %op3668, ptr %slot430, align 8
  %v3669 = load i32, ptr %slot430, align 8
  %cv3670 = zext i32 %v3669 to i64
  %cond3671 = icmp ne i64 %cv3670, 0
  br i1 %cond3671, label %bb_rcslotrole604, label %bb_rcslotowner604
bb_rcslotrole604:
  %v3672 = load i64, ptr %slot70, align 8
  store i64 %v3672, ptr %slot431, align 8
  %v3673 = load i64, ptr %slot428, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %ld3675 = load i64, ptr %p3674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3675, ptr %slot432, align 8
  %v3676 = load i64, ptr %slot432, align 8
  %cmp3677 = icmp ne i64 %v3676, 0
  %cv3678 = zext i1 %cmp3677 to i32
  store i32 %cv3678, ptr %slot433, align 8
  %v3679 = load i32, ptr %slot433, align 8
  %cv3680 = zext i32 %v3679 to i64
  %cond3681 = icmp ne i64 %cv3680, 0
  br i1 %cond3681, label %bb_rcgnn620, label %bb_rcgdone620
bb_rcgnn620:
  %v3682 = load i64, ptr %slot432, align 8
  %op3683 = sub i64 %v3682, 16
  store i64 %op3683, ptr %slot434, align 8
  %v3684 = load i64, ptr %slot432, align 8
  %p3685 = inttoptr i64 %v3684 to ptr
  %rgep3686 = getelementptr i8, ptr %p3685, i64 -16
  %ld3687 = load i64, ptr %rgep3686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3687, ptr %slot435, align 8
  %v3688 = load i64, ptr %slot435, align 8
  %op3689 = and i64 %v3688, 4611686018427387906
  store i64 %op3689, ptr %slot436, align 8
  %v3690 = load i64, ptr %slot436, align 8
  %cmp3691 = icmp ne i64 %v3690, 0
  %cv3692 = zext i1 %cmp3691 to i32
  store i32 %cv3692, ptr %slot437, align 8
  %v3693 = load i32, ptr %slot437, align 8
  %cv3694 = zext i32 %v3693 to i64
  %cond3695 = icmp ne i64 %cv3694, 0
  br i1 %cond3695, label %bb_rcgclear620, label %bb_rcgcounted620
bb_rcgcounted620:
  %v3696 = load i64, ptr %slot432, align 8
  %op3697 = sub i64 %v3696, 24
  store i64 %op3697, ptr %slot438, align 8
  %v3698 = load i64, ptr %slot432, align 8
  %p3699 = inttoptr i64 %v3698 to ptr
  %rgep3700 = getelementptr i8, ptr %p3699, i64 -24
  %ld3701 = load i64, ptr %rgep3700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3701, ptr %slot439, align 8
  %v3702 = load i64, ptr %slot439, align 8
  %op3703 = sub i64 %v3702, 1
  store i64 %op3703, ptr %slot440, align 8
  %v3704 = load i64, ptr %slot440, align 8
  %cmp3705 = icmp eq i64 %v3704, 0
  %cv3706 = zext i1 %cmp3705 to i32
  store i32 %cv3706, ptr %slot441, align 8
  %v3707 = load i32, ptr %slot441, align 8
  %cv3708 = zext i32 %v3707 to i64
  %cond3709 = icmp ne i64 %cv3708, 0
  br i1 %cond3709, label %bb_rcglast620, label %bb_rcgdec620
bb_rcglast620:
  %v3710 = load i64, ptr %slot432, align 8
  %op3711 = sub i64 %v3710, 32
  store i64 %op3711, ptr %slot442, align 8
  %v3712 = load i64, ptr %slot432, align 8
  %p3713 = inttoptr i64 %v3712 to ptr
  %rgep3714 = getelementptr i8, ptr %p3713, i64 -32
  %ld3715 = load i64, ptr %rgep3714, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3715, ptr %slot443, align 8
  %v3716 = load i64, ptr %slot443, align 8
  %cmp3717 = icmp ne i64 %v3716, 0
  %cv3718 = zext i1 %cmp3717 to i32
  store i32 %cv3718, ptr %slot444, align 8
  %v3719 = load i32, ptr %slot444, align 8
  %cv3720 = zext i32 %v3719 to i64
  %cond3721 = icmp ne i64 %cv3720, 0
  br i1 %cond3721, label %bb_rcgdec620, label %bb_rcgslow620
bb_rcgslow620:
  %v3722 = load i64, ptr %slot431, align 8
  %v3723 = load i64, ptr %slot428, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v3722, i64 %v3723) nomerge, !dbg !142
  br label %bb_rcgdone620
bb_rcgdec620:
  %v3724 = load i64, ptr %slot440, align 8
  %v3725 = load i64, ptr %slot432, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  %rgep3727 = getelementptr i8, ptr %p3726, i64 -24
  store i64 %v3724, ptr %rgep3727, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear620
bb_rcgclear620:
  %v3728 = load i64, ptr %slot428, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  store i64 0, ptr %p3729, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone620
bb_rcgdone620:
  br label %bb_rcslotdone604
bb_rcslotowner604:
  %v3730 = load i64, ptr %slot70, align 8
  store i64 %v3730, ptr %slot445, align 8
  %v3731 = load i64, ptr %slot428, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  %ld3733 = load i64, ptr %p3732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3733, ptr %slot446, align 8
  %v3734 = load i64, ptr %slot446, align 8
  %cmp3735 = icmp ne i64 %v3734, 0
  %cv3736 = zext i1 %cmp3735 to i32
  store i32 %cv3736, ptr %slot447, align 8
  %v3737 = load i32, ptr %slot447, align 8
  %cv3738 = zext i32 %v3737 to i64
  %cond3739 = icmp ne i64 %cv3738, 0
  br i1 %cond3739, label %bb_rcgnn635, label %bb_rcgdone635
bb_rcgnn635:
  %v3740 = load i64, ptr %slot446, align 8
  %op3741 = sub i64 %v3740, 16
  store i64 %op3741, ptr %slot448, align 8
  %v3742 = load i64, ptr %slot446, align 8
  %p3743 = inttoptr i64 %v3742 to ptr
  %rgep3744 = getelementptr i8, ptr %p3743, i64 -16
  %ld3745 = load i64, ptr %rgep3744, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3745, ptr %slot449, align 8
  %v3746 = load i64, ptr %slot449, align 8
  %op3747 = and i64 %v3746, 4611686018427387906
  store i64 %op3747, ptr %slot450, align 8
  %v3748 = load i64, ptr %slot450, align 8
  %cmp3749 = icmp ne i64 %v3748, 0
  %cv3750 = zext i1 %cmp3749 to i32
  store i32 %cv3750, ptr %slot451, align 8
  %v3751 = load i32, ptr %slot451, align 8
  %cv3752 = zext i32 %v3751 to i64
  %cond3753 = icmp ne i64 %cv3752, 0
  br i1 %cond3753, label %bb_rcgclear635, label %bb_rcgcounted635
bb_rcgcounted635:
  %v3754 = load i64, ptr %slot446, align 8
  %op3755 = sub i64 %v3754, 32
  store i64 %op3755, ptr %slot452, align 8
  %v3756 = load i64, ptr %slot446, align 8
  %p3757 = inttoptr i64 %v3756 to ptr
  %rgep3758 = getelementptr i8, ptr %p3757, i64 -32
  %ld3759 = load i64, ptr %rgep3758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3759, ptr %slot453, align 8
  %v3760 = load i64, ptr %slot453, align 8
  %op3761 = sub i64 %v3760, 1
  store i64 %op3761, ptr %slot454, align 8
  %v3762 = load i64, ptr %slot454, align 8
  %cmp3763 = icmp eq i64 %v3762, 0
  %cv3764 = zext i1 %cmp3763 to i32
  store i32 %cv3764, ptr %slot455, align 8
  %v3765 = load i32, ptr %slot455, align 8
  %cv3766 = zext i32 %v3765 to i64
  %cond3767 = icmp ne i64 %cv3766, 0
  br i1 %cond3767, label %bb_rcglast635, label %bb_rcgdec635
bb_rcglast635:
  %v3768 = load i64, ptr %slot446, align 8
  %op3769 = sub i64 %v3768, 24
  store i64 %op3769, ptr %slot456, align 8
  %v3770 = load i64, ptr %slot446, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  %rgep3772 = getelementptr i8, ptr %p3771, i64 -24
  %ld3773 = load i64, ptr %rgep3772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3773, ptr %slot457, align 8
  %v3774 = load i64, ptr %slot457, align 8
  %cmp3775 = icmp ne i64 %v3774, 0
  %cv3776 = zext i1 %cmp3775 to i32
  store i32 %cv3776, ptr %slot458, align 8
  %v3777 = load i32, ptr %slot458, align 8
  %cv3778 = zext i32 %v3777 to i64
  %cond3779 = icmp ne i64 %cv3778, 0
  br i1 %cond3779, label %bb_rcgdec635, label %bb_rcgslow635
bb_rcgslow635:
  %v3780 = load i64, ptr %slot445, align 8
  %v3781 = load i64, ptr %slot428, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v3780, i64 %v3781) nomerge, !dbg !142
  br label %bb_rcgdone635
bb_rcgdec635:
  %v3782 = load i64, ptr %slot454, align 8
  %v3783 = load i64, ptr %slot446, align 8
  %p3784 = inttoptr i64 %v3783 to ptr
  %rgep3785 = getelementptr i8, ptr %p3784, i64 -32
  store i64 %v3782, ptr %rgep3785, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear635
bb_rcgclear635:
  %v3786 = load i64, ptr %slot428, align 8
  %p3787 = inttoptr i64 %v3786 to ptr
  store i64 0, ptr %p3787, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone635
bb_rcgdone635:
  br label %bb_rcslotdone604
bb_rcslotdone604:
  %v3788 = load i64, ptr %slot7, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  %ld3790 = load i32, ptr %p3789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3790, ptr %slot459, align 8
  %v3791 = load i32, ptr %slot459, align 8
  %cv3792 = zext i32 %v3791 to i64
  %cond3793 = icmp ne i64 %cv3792, 0
  br i1 %cond3793, label %bb_rcslotdrop641, label %bb_rcslotdone641
bb_rcslotdrop641:
  %v3794 = load i64, ptr %slot7, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  store i32 0, ptr %p3795, align 4, !alias.scope !3, !noalias !4
  %v3796 = load i64, ptr %slot42, align 8
  store i64 %v3796, ptr %slot460, align 8
  %v3797 = load i64, ptr %slot8, align 8
  %p3798 = inttoptr i64 %v3797 to ptr
  %ld3799 = load i32, ptr %p3798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3799, ptr %slot461, align 8
  %v3800 = load i32, ptr %slot461, align 8
  %op3801 = and i32 %v3800, 28
  store i32 %op3801, ptr %slot462, align 8
  %v3802 = load i32, ptr %slot462, align 8
  %cv3803 = zext i32 %v3802 to i64
  %cond3804 = icmp ne i64 %cv3803, 0
  br i1 %cond3804, label %bb_rcslotrole641, label %bb_rcslotowner641
bb_rcslotrole641:
  %v3805 = load i64, ptr %slot70, align 8
  store i64 %v3805, ptr %slot463, align 8
  %v3806 = load i64, ptr %slot463, align 8
  %v3807 = load i64, ptr %slot460, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3806, i64 %v3807) nomerge, !dbg !142
  br label %bb_rcslotdone641
bb_rcslotowner641:
  %v3808 = load i64, ptr %slot70, align 8
  store i64 %v3808, ptr %slot464, align 8
  %v3809 = load i64, ptr %slot464, align 8
  %v3810 = load i64, ptr %slot460, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3809, i64 %v3810) nomerge, !dbg !142
  br label %bb_rcslotdone641
bb_rcslotdone641:
  %v3811 = load i64, ptr %slot396, align 8
  ret i64 %v3811
bb_i59:
  %v3812 = load i64, ptr %slot44, align 8
  %p3813 = inttoptr i64 %v3812 to ptr
  %ld3814 = load i64, ptr %p3813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3814, ptr %slot465, align 8
  %v3815 = load i64, ptr %slot465, align 8
  %v3816 = load i64, ptr %slot57, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  store i64 %v3815, ptr %p3817, align 8, !alias.scope !3, !noalias !4
  %v3818 = load i64, ptr %slot58, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  store i64 1, ptr %p3819, align 8, !alias.scope !3, !noalias !4
  %v3820 = load i64, ptr %slot58, align 8
  %p3821 = inttoptr i64 %v3820 to ptr
  %ld3822 = load i64, ptr %p3821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3822, ptr %slot466, align 8
  %v3823 = load i64, ptr %slot57, align 8
  %p3824 = inttoptr i64 %v3823 to ptr
  %ld3825 = load i64, ptr %p3824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3825, ptr %slot467, align 8
  %v3826 = load i64, ptr %slot467, align 8
  %v3827 = load i64, ptr %slot466, align 8
  %ovpair3829 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3826, i64 %v3827)
  %op3828 = extractvalue { i64, i1 } %ovpair3829, 0
  %ov3830 = extractvalue { i64, i1 } %ovpair3829, 1
  store i64 %op3828, ptr %slot468, align 8
  %cv3831 = zext i1 %ov3830 to i64
  store i64 %cv3831, ptr %slot469, align 8
  %v3832 = load i64, ptr %slot469, align 8
  %cond3833 = icmp ne i64 %v3832, 0
  br i1 %cond3833, label %bb_overflow697, label %bb_checked697
bb_overflow697:
  %v3834 = load i64, ptr %slot1, align 8
  %p3835 = inttoptr i64 %v3834 to ptr
  %v3836 = load i64, ptr %slot467, align 8
  %v3837 = load i64, ptr %slot466, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3835, i64 0, i64 %v3836, i64 %v3837, i64 64) nomerge, !dbg !144
  unreachable
bb_checked697:
  %v3838 = load i64, ptr %slot468, align 8
  %v3839 = load i64, ptr %slot57, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  store i64 %v3838, ptr %p3840, align 8, !alias.scope !3, !noalias !4
  %v3841 = load i64, ptr %slot57, align 8
  %p3842 = inttoptr i64 %v3841 to ptr
  %ld3843 = load i64, ptr %p3842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3843, ptr %slot470, align 8
  %v3844 = load i64, ptr %slot470, align 8
  %v3845 = load i64, ptr %slot44, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  store i64 %v3844, ptr %p3846, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i64:
  %v3847 = load i64, ptr %slot43, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  %ld3849 = load i64, ptr %p3848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3849, ptr %slot471, align 8
  %v3850 = load i64, ptr %slot471, align 8
  %v3851 = load i64, ptr %slot57, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  store i64 %v3850, ptr %p3852, align 8, !alias.scope !3, !noalias !4
  %v3853 = load i64, ptr %slot58, align 8
  %p3854 = inttoptr i64 %v3853 to ptr
  store i64 256, ptr %p3854, align 8, !alias.scope !3, !noalias !4
  %v3855 = load i64, ptr %slot58, align 8
  %p3856 = inttoptr i64 %v3855 to ptr
  %ld3857 = load i64, ptr %p3856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3857, ptr %slot472, align 8
  %v3858 = load i64, ptr %slot57, align 8
  %p3859 = inttoptr i64 %v3858 to ptr
  %ld3860 = load i64, ptr %p3859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3860, ptr %slot473, align 8
  %v3861 = load i64, ptr %slot473, align 8
  %v3862 = load i64, ptr %slot472, align 8
  %cmp3863 = icmp eq i64 %v3861, %v3862
  %cv3864 = zext i1 %cmp3863 to i64
  store i64 %cv3864, ptr %slot474, align 8
  %v3865 = load i64, ptr %slot474, align 8
  %v3866 = load i64, ptr %slot57, align 8
  %p3867 = inttoptr i64 %v3866 to ptr
  store i64 %v3865, ptr %p3867, align 8, !alias.scope !3, !noalias !4
  %v3868 = load i64, ptr %slot57, align 8
  %p3869 = inttoptr i64 %v3868 to ptr
  %ld3870 = load i64, ptr %p3869, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3870, ptr %slot475, align 8
  %v3871 = load i64, ptr %slot475, align 8
  %cond3872 = icmp ne i64 %v3871, 0
  br i1 %cond3872, label %bb_next705, label %bb_i74
bb_next705:
  %v3873 = load i64, ptr %slot36, align 8
  %p3874 = inttoptr i64 %v3873 to ptr
  %ld3875 = load i64, ptr %p3874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3875, ptr %slot476, align 8
  %v3876 = load i64, ptr %slot476, align 8
  %v3877 = load i64, ptr %slot57, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  store i64 %v3876, ptr %p3878, align 8, !alias.scope !3, !noalias !4
  %p3879 = inttoptr i64 ptrtoint (ptr @myl_lit_c00e440f315419997e6162b5571fda77267d1f58d08a0b2342c382685e685043 to i64) to ptr
  %ld3880 = load i64, ptr %p3879, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3880, ptr %slot477, align 8
  %v3881 = load i64, ptr %slot477, align 8
  %v3882 = load i64, ptr %slot58, align 8
  %p3883 = inttoptr i64 %v3882 to ptr
  store i64 %v3881, ptr %p3883, align 8, !alias.scope !3, !noalias !4
  %v3884 = load i64, ptr %slot58, align 8
  %p3885 = inttoptr i64 %v3884 to ptr
  %ld3886 = load i64, ptr %p3885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3886, ptr %slot478, align 8
  %v3887 = load i64, ptr %slot478, align 8
  %v3888 = load i64, ptr %slot27, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  store i64 %v3887, ptr %p3889, align 8, !alias.scope !3, !noalias !4
  %v3890 = load i64, ptr %slot27, align 8
  store i64 %v3890, ptr %slot479, align 8
  %v3891 = load i64, ptr %slot28, align 8
  store i64 %v3891, ptr %slot480, align 8
  %v3892 = load i64, ptr %slot479, align 8
  %v3893 = load i64, ptr %slot480, align 8
  %p3894 = inttoptr i64 %v3892 to ptr
  %p3895 = inttoptr i64 %v3893 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3895, ptr %p3894, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3896 = load i64, ptr %slot22, align 8
  %p3897 = inttoptr i64 %v3896 to ptr
  store i32 2, ptr %p3897, align 4, !alias.scope !3, !noalias !4
  %v3898 = load i64, ptr %slot21, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  store i32 1, ptr %p3899, align 4, !alias.scope !3, !noalias !4
  %v3900 = load i64, ptr %slot25, align 8
  store i64 %v3900, ptr %slot481, align 8
  %v3901 = load i64, ptr %slot28, align 8
  store i64 %v3901, ptr %slot482, align 8
  %v3902 = load i64, ptr %slot482, align 8
  %v3903 = load i64, ptr %slot481, align 8
  %p3904 = inttoptr i64 %v3902 to ptr
  %p3905 = inttoptr i64 %v3903 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3905, ptr %p3904, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3906 = load i64, ptr %slot20, align 8
  %p3907 = inttoptr i64 %v3906 to ptr
  store i32 2, ptr %p3907, align 4, !alias.scope !3, !noalias !4
  %v3908 = load i64, ptr %slot22, align 8
  %p3909 = inttoptr i64 %v3908 to ptr
  %ld3910 = load i32, ptr %p3909, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3910, ptr %slot483, align 8
  %v3911 = load i32, ptr %slot483, align 8
  %v3912 = load i64, ptr %slot20, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  store i32 %v3911, ptr %p3913, align 4, !alias.scope !3, !noalias !4
  %v3914 = load i64, ptr %slot21, align 8
  %p3915 = inttoptr i64 %v3914 to ptr
  store i32 0, ptr %p3915, align 4, !alias.scope !3, !noalias !4
  %v3916 = load i64, ptr %slot19, align 8
  %p3917 = inttoptr i64 %v3916 to ptr
  store i32 1, ptr %p3917, align 4, !alias.scope !3, !noalias !4
  %v3918 = load i64, ptr %slot481, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  %ld3920 = load i64, ptr %p3919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3920, ptr %slot484, align 8
  %v3921 = load i64, ptr %slot484, align 8
  %v3922 = load i64, ptr %slot58, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  store i64 %v3921, ptr %p3923, align 8, !alias.scope !3, !noalias !4
  %v3924 = load i64, ptr %slot57, align 8
  %p3925 = inttoptr i64 %v3924 to ptr
  %ld3926 = load i64, ptr %p3925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3926, ptr %slot485, align 8
  %v3927 = load i64, ptr %slot58, align 8
  %p3928 = inttoptr i64 %v3927 to ptr
  %ld3929 = load i64, ptr %p3928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3929, ptr %slot486, align 8
  %v3930 = load i64, ptr %slot1, align 8
  %v3931 = load i64, ptr %slot485, align 8
  %v3932 = load i64, ptr %slot486, align 8
  %call3933 = call i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64 %v3930, i64 %v3931, i64 %v3932) nomerge, !dbg !146
  store i64 %call3933, ptr %slot487, align 8
  %v3934 = load i64, ptr %slot487, align 8
  %v3935 = load i64, ptr %slot57, align 8
  %p3936 = inttoptr i64 %v3935 to ptr
  store i64 %v3934, ptr %p3936, align 8, !alias.scope !3, !noalias !4
  %v3937 = load i64, ptr %slot17, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  %ld3939 = load i32, ptr %p3938, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3939, ptr %slot488, align 8
  %v3940 = load i32, ptr %slot488, align 8
  %cv3941 = zext i32 %v3940 to i64
  %cond3942 = icmp ne i64 %cv3941, 0
  br i1 %cond3942, label %bb_rcslotdrop727, label %bb_rcslotdone727
bb_rcslotdrop727:
  %v3943 = load i64, ptr %slot17, align 8
  %p3944 = inttoptr i64 %v3943 to ptr
  store i32 0, ptr %p3944, align 4, !alias.scope !3, !noalias !4
  %v3945 = load i64, ptr %slot24, align 8
  store i64 %v3945, ptr %slot489, align 8
  %v3946 = load i64, ptr %slot18, align 8
  %p3947 = inttoptr i64 %v3946 to ptr
  %ld3948 = load i32, ptr %p3947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3948, ptr %slot490, align 8
  %v3949 = load i32, ptr %slot490, align 8
  %op3950 = and i32 %v3949, 28
  store i32 %op3950, ptr %slot491, align 8
  %v3951 = load i32, ptr %slot491, align 8
  %cv3952 = zext i32 %v3951 to i64
  %cond3953 = icmp ne i64 %cv3952, 0
  br i1 %cond3953, label %bb_rcslotrole727, label %bb_rcslotowner727
bb_rcslotrole727:
  %v3954 = load i64, ptr %slot70, align 8
  store i64 %v3954, ptr %slot492, align 8
  %v3955 = load i64, ptr %slot492, align 8
  %v3956 = load i64, ptr %slot489, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3955, i64 %v3956) nomerge, !dbg !146
  br label %bb_rcslotdone727
bb_rcslotowner727:
  %v3957 = load i64, ptr %slot70, align 8
  store i64 %v3957, ptr %slot493, align 8
  %v3958 = load i64, ptr %slot493, align 8
  %v3959 = load i64, ptr %slot489, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3958, i64 %v3959) nomerge, !dbg !146
  br label %bb_rcslotdone727
bb_rcslotdone727:
  %v3960 = load i64, ptr %slot19, align 8
  %p3961 = inttoptr i64 %v3960 to ptr
  %ld3962 = load i32, ptr %p3961, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3962, ptr %slot494, align 8
  %v3963 = load i32, ptr %slot494, align 8
  %cv3964 = zext i32 %v3963 to i64
  %cond3965 = icmp ne i64 %cv3964, 0
  br i1 %cond3965, label %bb_rcslotdrop736, label %bb_rcslotdone736
bb_rcslotdrop736:
  %v3966 = load i64, ptr %slot19, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  store i32 0, ptr %p3967, align 4, !alias.scope !3, !noalias !4
  %v3968 = load i64, ptr %slot25, align 8
  store i64 %v3968, ptr %slot495, align 8
  %v3969 = load i64, ptr %slot20, align 8
  %p3970 = inttoptr i64 %v3969 to ptr
  %ld3971 = load i32, ptr %p3970, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3971, ptr %slot496, align 8
  %v3972 = load i32, ptr %slot496, align 8
  %op3973 = and i32 %v3972, 28
  store i32 %op3973, ptr %slot497, align 8
  %v3974 = load i32, ptr %slot497, align 8
  %cv3975 = zext i32 %v3974 to i64
  %cond3976 = icmp ne i64 %cv3975, 0
  br i1 %cond3976, label %bb_rcslotrole736, label %bb_rcslotowner736
bb_rcslotrole736:
  %v3977 = load i64, ptr %slot70, align 8
  store i64 %v3977, ptr %slot498, align 8
  %v3978 = load i64, ptr %slot495, align 8
  %p3979 = inttoptr i64 %v3978 to ptr
  %ld3980 = load i64, ptr %p3979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3980, ptr %slot499, align 8
  %v3981 = load i64, ptr %slot499, align 8
  %cmp3982 = icmp ne i64 %v3981, 0
  %cv3983 = zext i1 %cmp3982 to i32
  store i32 %cv3983, ptr %slot500, align 8
  %v3984 = load i32, ptr %slot500, align 8
  %cv3985 = zext i32 %v3984 to i64
  %cond3986 = icmp ne i64 %cv3985, 0
  br i1 %cond3986, label %bb_rcgnn752, label %bb_rcgdone752
bb_rcgnn752:
  %v3987 = load i64, ptr %slot499, align 8
  %op3988 = sub i64 %v3987, 16
  store i64 %op3988, ptr %slot501, align 8
  %v3989 = load i64, ptr %slot499, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  %rgep3991 = getelementptr i8, ptr %p3990, i64 -16
  %ld3992 = load i64, ptr %rgep3991, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3992, ptr %slot502, align 8
  %v3993 = load i64, ptr %slot502, align 8
  %op3994 = and i64 %v3993, 4611686018427387906
  store i64 %op3994, ptr %slot503, align 8
  %v3995 = load i64, ptr %slot503, align 8
  %cmp3996 = icmp ne i64 %v3995, 0
  %cv3997 = zext i1 %cmp3996 to i32
  store i32 %cv3997, ptr %slot504, align 8
  %v3998 = load i32, ptr %slot504, align 8
  %cv3999 = zext i32 %v3998 to i64
  %cond4000 = icmp ne i64 %cv3999, 0
  br i1 %cond4000, label %bb_rcgclear752, label %bb_rcgcounted752
bb_rcgcounted752:
  %v4001 = load i64, ptr %slot499, align 8
  %op4002 = sub i64 %v4001, 24
  store i64 %op4002, ptr %slot505, align 8
  %v4003 = load i64, ptr %slot499, align 8
  %p4004 = inttoptr i64 %v4003 to ptr
  %rgep4005 = getelementptr i8, ptr %p4004, i64 -24
  %ld4006 = load i64, ptr %rgep4005, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4006, ptr %slot506, align 8
  %v4007 = load i64, ptr %slot506, align 8
  %op4008 = sub i64 %v4007, 1
  store i64 %op4008, ptr %slot507, align 8
  %v4009 = load i64, ptr %slot507, align 8
  %cmp4010 = icmp eq i64 %v4009, 0
  %cv4011 = zext i1 %cmp4010 to i32
  store i32 %cv4011, ptr %slot508, align 8
  %v4012 = load i32, ptr %slot508, align 8
  %cv4013 = zext i32 %v4012 to i64
  %cond4014 = icmp ne i64 %cv4013, 0
  br i1 %cond4014, label %bb_rcglast752, label %bb_rcgdec752
bb_rcglast752:
  %v4015 = load i64, ptr %slot499, align 8
  %op4016 = sub i64 %v4015, 32
  store i64 %op4016, ptr %slot509, align 8
  %v4017 = load i64, ptr %slot499, align 8
  %p4018 = inttoptr i64 %v4017 to ptr
  %rgep4019 = getelementptr i8, ptr %p4018, i64 -32
  %ld4020 = load i64, ptr %rgep4019, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4020, ptr %slot510, align 8
  %v4021 = load i64, ptr %slot510, align 8
  %cmp4022 = icmp ne i64 %v4021, 0
  %cv4023 = zext i1 %cmp4022 to i32
  store i32 %cv4023, ptr %slot511, align 8
  %v4024 = load i32, ptr %slot511, align 8
  %cv4025 = zext i32 %v4024 to i64
  %cond4026 = icmp ne i64 %cv4025, 0
  br i1 %cond4026, label %bb_rcgdec752, label %bb_rcgslow752
bb_rcgslow752:
  %v4027 = load i64, ptr %slot498, align 8
  %v4028 = load i64, ptr %slot495, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4027, i64 %v4028) nomerge, !dbg !146
  br label %bb_rcgdone752
bb_rcgdec752:
  %v4029 = load i64, ptr %slot507, align 8
  %v4030 = load i64, ptr %slot499, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  %rgep4032 = getelementptr i8, ptr %p4031, i64 -24
  store i64 %v4029, ptr %rgep4032, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear752
bb_rcgclear752:
  %v4033 = load i64, ptr %slot495, align 8
  %p4034 = inttoptr i64 %v4033 to ptr
  store i64 0, ptr %p4034, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone752
bb_rcgdone752:
  br label %bb_rcslotdone736
bb_rcslotowner736:
  %v4035 = load i64, ptr %slot70, align 8
  store i64 %v4035, ptr %slot512, align 8
  %v4036 = load i64, ptr %slot495, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  %ld4038 = load i64, ptr %p4037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4038, ptr %slot513, align 8
  %v4039 = load i64, ptr %slot513, align 8
  %cmp4040 = icmp ne i64 %v4039, 0
  %cv4041 = zext i1 %cmp4040 to i32
  store i32 %cv4041, ptr %slot514, align 8
  %v4042 = load i32, ptr %slot514, align 8
  %cv4043 = zext i32 %v4042 to i64
  %cond4044 = icmp ne i64 %cv4043, 0
  br i1 %cond4044, label %bb_rcgnn767, label %bb_rcgdone767
bb_rcgnn767:
  %v4045 = load i64, ptr %slot513, align 8
  %op4046 = sub i64 %v4045, 16
  store i64 %op4046, ptr %slot515, align 8
  %v4047 = load i64, ptr %slot513, align 8
  %p4048 = inttoptr i64 %v4047 to ptr
  %rgep4049 = getelementptr i8, ptr %p4048, i64 -16
  %ld4050 = load i64, ptr %rgep4049, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4050, ptr %slot516, align 8
  %v4051 = load i64, ptr %slot516, align 8
  %op4052 = and i64 %v4051, 4611686018427387906
  store i64 %op4052, ptr %slot517, align 8
  %v4053 = load i64, ptr %slot517, align 8
  %cmp4054 = icmp ne i64 %v4053, 0
  %cv4055 = zext i1 %cmp4054 to i32
  store i32 %cv4055, ptr %slot518, align 8
  %v4056 = load i32, ptr %slot518, align 8
  %cv4057 = zext i32 %v4056 to i64
  %cond4058 = icmp ne i64 %cv4057, 0
  br i1 %cond4058, label %bb_rcgclear767, label %bb_rcgcounted767
bb_rcgcounted767:
  %v4059 = load i64, ptr %slot513, align 8
  %op4060 = sub i64 %v4059, 32
  store i64 %op4060, ptr %slot519, align 8
  %v4061 = load i64, ptr %slot513, align 8
  %p4062 = inttoptr i64 %v4061 to ptr
  %rgep4063 = getelementptr i8, ptr %p4062, i64 -32
  %ld4064 = load i64, ptr %rgep4063, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4064, ptr %slot520, align 8
  %v4065 = load i64, ptr %slot520, align 8
  %op4066 = sub i64 %v4065, 1
  store i64 %op4066, ptr %slot521, align 8
  %v4067 = load i64, ptr %slot521, align 8
  %cmp4068 = icmp eq i64 %v4067, 0
  %cv4069 = zext i1 %cmp4068 to i32
  store i32 %cv4069, ptr %slot522, align 8
  %v4070 = load i32, ptr %slot522, align 8
  %cv4071 = zext i32 %v4070 to i64
  %cond4072 = icmp ne i64 %cv4071, 0
  br i1 %cond4072, label %bb_rcglast767, label %bb_rcgdec767
bb_rcglast767:
  %v4073 = load i64, ptr %slot513, align 8
  %op4074 = sub i64 %v4073, 24
  store i64 %op4074, ptr %slot523, align 8
  %v4075 = load i64, ptr %slot513, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  %rgep4077 = getelementptr i8, ptr %p4076, i64 -24
  %ld4078 = load i64, ptr %rgep4077, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4078, ptr %slot524, align 8
  %v4079 = load i64, ptr %slot524, align 8
  %cmp4080 = icmp ne i64 %v4079, 0
  %cv4081 = zext i1 %cmp4080 to i32
  store i32 %cv4081, ptr %slot525, align 8
  %v4082 = load i32, ptr %slot525, align 8
  %cv4083 = zext i32 %v4082 to i64
  %cond4084 = icmp ne i64 %cv4083, 0
  br i1 %cond4084, label %bb_rcgdec767, label %bb_rcgslow767
bb_rcgslow767:
  %v4085 = load i64, ptr %slot512, align 8
  %v4086 = load i64, ptr %slot495, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4085, i64 %v4086) nomerge, !dbg !146
  br label %bb_rcgdone767
bb_rcgdec767:
  %v4087 = load i64, ptr %slot521, align 8
  %v4088 = load i64, ptr %slot513, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  %rgep4090 = getelementptr i8, ptr %p4089, i64 -32
  store i64 %v4087, ptr %rgep4090, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear767
bb_rcgclear767:
  %v4091 = load i64, ptr %slot495, align 8
  %p4092 = inttoptr i64 %v4091 to ptr
  store i64 0, ptr %p4092, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone767
bb_rcgdone767:
  br label %bb_rcslotdone736
bb_rcslotdone736:
  %v4093 = load i64, ptr %slot57, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  store i64 0, ptr %p4094, align 8, !alias.scope !3, !noalias !4
  %v4095 = load i64, ptr %slot57, align 8
  %p4096 = inttoptr i64 %v4095 to ptr
  %ld4097 = load i64, ptr %p4096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4097, ptr %slot526, align 8
  %v4098 = load i64, ptr %slot29, align 8
  %p4100 = inttoptr i64 %v4098 to ptr
  %gep4101 = getelementptr i8, ptr %p4100, i64 24
  %op4099 = ptrtoint ptr %gep4101 to i64
  store i64 %op4099, ptr %slot527, align 8
  %v4102 = load i64, ptr %slot527, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  %ld4104 = load i32, ptr %p4103, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4104, ptr %slot528, align 8
  %v4105 = load i64, ptr %slot31, align 8
  %p4107 = inttoptr i64 %v4105 to ptr
  %gep4108 = getelementptr i8, ptr %p4107, i64 24
  %op4106 = ptrtoint ptr %gep4108 to i64
  store i64 %op4106, ptr %slot529, align 8
  %v4109 = load i64, ptr %slot529, align 8
  %p4110 = inttoptr i64 %v4109 to ptr
  %ld4111 = load i32, ptr %p4110, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4111, ptr %slot530, align 8
  %v4112 = load i32, ptr %slot528, align 8
  %v4113 = load i32, ptr %slot530, align 8
  %op4114 = or i32 %v4112, %v4113
  store i32 %op4114, ptr %slot531, align 8
  %v4115 = load i64, ptr %slot33, align 8
  %p4117 = inttoptr i64 %v4115 to ptr
  %gep4118 = getelementptr i8, ptr %p4117, i64 24
  %op4116 = ptrtoint ptr %gep4118 to i64
  store i64 %op4116, ptr %slot532, align 8
  %v4119 = load i64, ptr %slot532, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  %ld4121 = load i32, ptr %p4120, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4121, ptr %slot533, align 8
  %v4122 = load i32, ptr %slot531, align 8
  %v4123 = load i32, ptr %slot533, align 8
  %op4124 = or i32 %v4122, %v4123
  store i32 %op4124, ptr %slot534, align 8
  %v4125 = load i32, ptr %slot534, align 8
  %cv4126 = zext i32 %v4125 to i64
  %cond4127 = icmp ne i64 %cv4126, 0
  br i1 %cond4127, label %bb_rcscopesopen780, label %bb_rcscopesclosed780
bb_rcscopesopen780:
  %v4128 = load i64, ptr %slot35, align 8
  %p4130 = inttoptr i64 %v4128 to ptr
  %gep4131 = getelementptr i8, ptr %p4130, i64 0
  %op4129 = ptrtoint ptr %gep4131 to i64
  store i64 %op4129, ptr %slot535, align 8
  %v4132 = load i64, ptr %slot29, align 8
  %v4133 = load i64, ptr %slot535, align 8
  %p4134 = inttoptr i64 %v4133 to ptr
  store i64 %v4132, ptr %p4134, align 8, !alias.scope !3, !noalias !4
  %v4135 = load i64, ptr %slot35, align 8
  %p4137 = inttoptr i64 %v4135 to ptr
  %gep4138 = getelementptr i8, ptr %p4137, i64 8
  %op4136 = ptrtoint ptr %gep4138 to i64
  store i64 %op4136, ptr %slot536, align 8
  %v4139 = load i64, ptr %slot31, align 8
  %v4140 = load i64, ptr %slot536, align 8
  %p4141 = inttoptr i64 %v4140 to ptr
  store i64 %v4139, ptr %p4141, align 8, !alias.scope !3, !noalias !4
  %v4142 = load i64, ptr %slot35, align 8
  %p4144 = inttoptr i64 %v4142 to ptr
  %gep4145 = getelementptr i8, ptr %p4144, i64 16
  %op4143 = ptrtoint ptr %gep4145 to i64
  store i64 %op4143, ptr %slot537, align 8
  %v4146 = load i64, ptr %slot33, align 8
  %v4147 = load i64, ptr %slot537, align 8
  %p4148 = inttoptr i64 %v4147 to ptr
  store i64 %v4146, ptr %p4148, align 8, !alias.scope !3, !noalias !4
  %v4149 = load i64, ptr %slot1, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  %v4151 = load i64, ptr %slot35, align 8
  %p4152 = inttoptr i64 %v4151 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p4150, ptr %p4152, i64 3) nomerge, !dbg !148
  br label %bb_rcscopesclosed780
bb_rcscopesclosed780:
  %v4153 = load i64, ptr %slot17, align 8
  %p4154 = inttoptr i64 %v4153 to ptr
  %ld4155 = load i32, ptr %p4154, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4155, ptr %slot538, align 8
  %v4156 = load i32, ptr %slot538, align 8
  %cv4157 = zext i32 %v4156 to i64
  %cond4158 = icmp ne i64 %cv4157, 0
  br i1 %cond4158, label %bb_rcslotdrop786, label %bb_rcslotdone786
bb_rcslotdrop786:
  %v4159 = load i64, ptr %slot17, align 8
  %p4160 = inttoptr i64 %v4159 to ptr
  store i32 0, ptr %p4160, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone786
bb_rcslotdone786:
  %v4161 = load i64, ptr %slot15, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %ld4163 = load i32, ptr %p4162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4163, ptr %slot539, align 8
  %v4164 = load i32, ptr %slot539, align 8
  %cv4165 = zext i32 %v4164 to i64
  %cond4166 = icmp ne i64 %cv4165, 0
  br i1 %cond4166, label %bb_rcslotdrop789, label %bb_rcslotdone789
bb_rcslotdrop789:
  %v4167 = load i64, ptr %slot15, align 8
  %p4168 = inttoptr i64 %v4167 to ptr
  store i32 0, ptr %p4168, align 4, !alias.scope !3, !noalias !4
  %v4169 = load i64, ptr %slot55, align 8
  store i64 %v4169, ptr %slot540, align 8
  %v4170 = load i64, ptr %slot16, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %ld4172 = load i32, ptr %p4171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4172, ptr %slot541, align 8
  %v4173 = load i32, ptr %slot541, align 8
  %op4174 = and i32 %v4173, 28
  store i32 %op4174, ptr %slot542, align 8
  %v4175 = load i32, ptr %slot542, align 8
  %cv4176 = zext i32 %v4175 to i64
  %cond4177 = icmp ne i64 %cv4176, 0
  br i1 %cond4177, label %bb_rcslotrole789, label %bb_rcslotowner789
bb_rcslotrole789:
  %v4178 = load i64, ptr %slot70, align 8
  store i64 %v4178, ptr %slot543, align 8
  %v4179 = load i64, ptr %slot543, align 8
  %v4180 = load i64, ptr %slot540, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4179, i64 %v4180) nomerge, !dbg !148
  br label %bb_rcslotdone789
bb_rcslotowner789:
  %v4181 = load i64, ptr %slot70, align 8
  store i64 %v4181, ptr %slot544, align 8
  %v4182 = load i64, ptr %slot544, align 8
  %v4183 = load i64, ptr %slot540, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4182, i64 %v4183) nomerge, !dbg !148
  br label %bb_rcslotdone789
bb_rcslotdone789:
  %v4184 = load i64, ptr %slot13, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  %ld4186 = load i32, ptr %p4185, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4186, ptr %slot545, align 8
  %v4187 = load i32, ptr %slot545, align 8
  %cv4188 = zext i32 %v4187 to i64
  %cond4189 = icmp ne i64 %cv4188, 0
  br i1 %cond4189, label %bb_rcslotdrop835, label %bb_rcslotdone835
bb_rcslotdrop835:
  %v4190 = load i64, ptr %slot13, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  store i32 0, ptr %p4191, align 4, !alias.scope !3, !noalias !4
  %v4192 = load i64, ptr %slot52, align 8
  store i64 %v4192, ptr %slot546, align 8
  %v4193 = load i64, ptr %slot14, align 8
  %p4194 = inttoptr i64 %v4193 to ptr
  %ld4195 = load i32, ptr %p4194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4195, ptr %slot547, align 8
  %v4196 = load i32, ptr %slot547, align 8
  %op4197 = and i32 %v4196, 28
  store i32 %op4197, ptr %slot548, align 8
  %v4198 = load i32, ptr %slot548, align 8
  %cv4199 = zext i32 %v4198 to i64
  %cond4200 = icmp ne i64 %cv4199, 0
  br i1 %cond4200, label %bb_rcslotrole835, label %bb_rcslotowner835
bb_rcslotrole835:
  %v4201 = load i64, ptr %slot70, align 8
  store i64 %v4201, ptr %slot549, align 8
  %v4202 = load i64, ptr %slot549, align 8
  %v4203 = load i64, ptr %slot546, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4202, i64 %v4203) nomerge, !dbg !148
  br label %bb_rcslotdone835
bb_rcslotowner835:
  %v4204 = load i64, ptr %slot70, align 8
  store i64 %v4204, ptr %slot550, align 8
  %v4205 = load i64, ptr %slot550, align 8
  %v4206 = load i64, ptr %slot546, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4205, i64 %v4206) nomerge, !dbg !148
  br label %bb_rcslotdone835
bb_rcslotdone835:
  %v4207 = load i64, ptr %slot11, align 8
  %p4208 = inttoptr i64 %v4207 to ptr
  %ld4209 = load i32, ptr %p4208, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4209, ptr %slot551, align 8
  %v4210 = load i32, ptr %slot551, align 8
  %cv4211 = zext i32 %v4210 to i64
  %cond4212 = icmp ne i64 %cv4211, 0
  br i1 %cond4212, label %bb_rcslotdrop881, label %bb_rcslotdone881
bb_rcslotdrop881:
  %v4213 = load i64, ptr %slot11, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  store i32 0, ptr %p4214, align 4, !alias.scope !3, !noalias !4
  %v4215 = load i64, ptr %slot49, align 8
  store i64 %v4215, ptr %slot552, align 8
  %v4216 = load i64, ptr %slot12, align 8
  %p4217 = inttoptr i64 %v4216 to ptr
  %ld4218 = load i32, ptr %p4217, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4218, ptr %slot553, align 8
  %v4219 = load i32, ptr %slot553, align 8
  %op4220 = and i32 %v4219, 28
  store i32 %op4220, ptr %slot554, align 8
  %v4221 = load i32, ptr %slot554, align 8
  %cv4222 = zext i32 %v4221 to i64
  %cond4223 = icmp ne i64 %cv4222, 0
  br i1 %cond4223, label %bb_rcslotrole881, label %bb_rcslotowner881
bb_rcslotrole881:
  %v4224 = load i64, ptr %slot70, align 8
  store i64 %v4224, ptr %slot555, align 8
  %v4225 = load i64, ptr %slot555, align 8
  %v4226 = load i64, ptr %slot552, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4225, i64 %v4226) nomerge, !dbg !148
  br label %bb_rcslotdone881
bb_rcslotowner881:
  %v4227 = load i64, ptr %slot70, align 8
  store i64 %v4227, ptr %slot556, align 8
  %v4228 = load i64, ptr %slot556, align 8
  %v4229 = load i64, ptr %slot552, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4228, i64 %v4229) nomerge, !dbg !148
  br label %bb_rcslotdone881
bb_rcslotdone881:
  %v4230 = load i64, ptr %slot9, align 8
  %p4231 = inttoptr i64 %v4230 to ptr
  %ld4232 = load i32, ptr %p4231, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4232, ptr %slot557, align 8
  %v4233 = load i32, ptr %slot557, align 8
  %cv4234 = zext i32 %v4233 to i64
  %cond4235 = icmp ne i64 %cv4234, 0
  br i1 %cond4235, label %bb_rcslotdrop927, label %bb_rcslotdone927
bb_rcslotdrop927:
  %v4236 = load i64, ptr %slot9, align 8
  %p4237 = inttoptr i64 %v4236 to ptr
  store i32 0, ptr %p4237, align 4, !alias.scope !3, !noalias !4
  %v4238 = load i64, ptr %slot45, align 8
  store i64 %v4238, ptr %slot558, align 8
  %v4239 = load i64, ptr %slot10, align 8
  %p4240 = inttoptr i64 %v4239 to ptr
  %ld4241 = load i32, ptr %p4240, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4241, ptr %slot559, align 8
  %v4242 = load i32, ptr %slot559, align 8
  %op4243 = and i32 %v4242, 28
  store i32 %op4243, ptr %slot560, align 8
  %v4244 = load i32, ptr %slot560, align 8
  %cv4245 = zext i32 %v4244 to i64
  %cond4246 = icmp ne i64 %cv4245, 0
  br i1 %cond4246, label %bb_rcslotrole927, label %bb_rcslotowner927
bb_rcslotrole927:
  %v4247 = load i64, ptr %slot70, align 8
  store i64 %v4247, ptr %slot561, align 8
  %v4248 = load i64, ptr %slot558, align 8
  %p4249 = inttoptr i64 %v4248 to ptr
  %ld4250 = load i64, ptr %p4249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4250, ptr %slot562, align 8
  %v4251 = load i64, ptr %slot562, align 8
  %cmp4252 = icmp ne i64 %v4251, 0
  %cv4253 = zext i1 %cmp4252 to i32
  store i32 %cv4253, ptr %slot563, align 8
  %v4254 = load i32, ptr %slot563, align 8
  %cv4255 = zext i32 %v4254 to i64
  %cond4256 = icmp ne i64 %cv4255, 0
  br i1 %cond4256, label %bb_rcgnn943, label %bb_rcgdone943
bb_rcgnn943:
  %v4257 = load i64, ptr %slot562, align 8
  %op4258 = sub i64 %v4257, 16
  store i64 %op4258, ptr %slot564, align 8
  %v4259 = load i64, ptr %slot562, align 8
  %p4260 = inttoptr i64 %v4259 to ptr
  %rgep4261 = getelementptr i8, ptr %p4260, i64 -16
  %ld4262 = load i64, ptr %rgep4261, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4262, ptr %slot565, align 8
  %v4263 = load i64, ptr %slot565, align 8
  %op4264 = and i64 %v4263, 4611686018427387906
  store i64 %op4264, ptr %slot566, align 8
  %v4265 = load i64, ptr %slot566, align 8
  %cmp4266 = icmp ne i64 %v4265, 0
  %cv4267 = zext i1 %cmp4266 to i32
  store i32 %cv4267, ptr %slot567, align 8
  %v4268 = load i32, ptr %slot567, align 8
  %cv4269 = zext i32 %v4268 to i64
  %cond4270 = icmp ne i64 %cv4269, 0
  br i1 %cond4270, label %bb_rcgclear943, label %bb_rcgcounted943
bb_rcgcounted943:
  %v4271 = load i64, ptr %slot562, align 8
  %op4272 = sub i64 %v4271, 24
  store i64 %op4272, ptr %slot568, align 8
  %v4273 = load i64, ptr %slot562, align 8
  %p4274 = inttoptr i64 %v4273 to ptr
  %rgep4275 = getelementptr i8, ptr %p4274, i64 -24
  %ld4276 = load i64, ptr %rgep4275, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4276, ptr %slot569, align 8
  %v4277 = load i64, ptr %slot569, align 8
  %op4278 = sub i64 %v4277, 1
  store i64 %op4278, ptr %slot570, align 8
  %v4279 = load i64, ptr %slot570, align 8
  %cmp4280 = icmp eq i64 %v4279, 0
  %cv4281 = zext i1 %cmp4280 to i32
  store i32 %cv4281, ptr %slot571, align 8
  %v4282 = load i32, ptr %slot571, align 8
  %cv4283 = zext i32 %v4282 to i64
  %cond4284 = icmp ne i64 %cv4283, 0
  br i1 %cond4284, label %bb_rcglast943, label %bb_rcgdec943
bb_rcglast943:
  %v4285 = load i64, ptr %slot562, align 8
  %op4286 = sub i64 %v4285, 32
  store i64 %op4286, ptr %slot572, align 8
  %v4287 = load i64, ptr %slot562, align 8
  %p4288 = inttoptr i64 %v4287 to ptr
  %rgep4289 = getelementptr i8, ptr %p4288, i64 -32
  %ld4290 = load i64, ptr %rgep4289, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4290, ptr %slot573, align 8
  %v4291 = load i64, ptr %slot573, align 8
  %cmp4292 = icmp ne i64 %v4291, 0
  %cv4293 = zext i1 %cmp4292 to i32
  store i32 %cv4293, ptr %slot574, align 8
  %v4294 = load i32, ptr %slot574, align 8
  %cv4295 = zext i32 %v4294 to i64
  %cond4296 = icmp ne i64 %cv4295, 0
  br i1 %cond4296, label %bb_rcgdec943, label %bb_rcgslow943
bb_rcgslow943:
  %v4297 = load i64, ptr %slot561, align 8
  %v4298 = load i64, ptr %slot558, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v4297, i64 %v4298) nomerge, !dbg !148
  br label %bb_rcgdone943
bb_rcgdec943:
  %v4299 = load i64, ptr %slot570, align 8
  %v4300 = load i64, ptr %slot562, align 8
  %p4301 = inttoptr i64 %v4300 to ptr
  %rgep4302 = getelementptr i8, ptr %p4301, i64 -24
  store i64 %v4299, ptr %rgep4302, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear943
bb_rcgclear943:
  %v4303 = load i64, ptr %slot558, align 8
  %p4304 = inttoptr i64 %v4303 to ptr
  store i64 0, ptr %p4304, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone943
bb_rcgdone943:
  br label %bb_rcslotdone927
bb_rcslotowner927:
  %v4305 = load i64, ptr %slot70, align 8
  store i64 %v4305, ptr %slot575, align 8
  %v4306 = load i64, ptr %slot558, align 8
  %p4307 = inttoptr i64 %v4306 to ptr
  %ld4308 = load i64, ptr %p4307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4308, ptr %slot576, align 8
  %v4309 = load i64, ptr %slot576, align 8
  %cmp4310 = icmp ne i64 %v4309, 0
  %cv4311 = zext i1 %cmp4310 to i32
  store i32 %cv4311, ptr %slot577, align 8
  %v4312 = load i32, ptr %slot577, align 8
  %cv4313 = zext i32 %v4312 to i64
  %cond4314 = icmp ne i64 %cv4313, 0
  br i1 %cond4314, label %bb_rcgnn958, label %bb_rcgdone958
bb_rcgnn958:
  %v4315 = load i64, ptr %slot576, align 8
  %op4316 = sub i64 %v4315, 16
  store i64 %op4316, ptr %slot578, align 8
  %v4317 = load i64, ptr %slot576, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  %rgep4319 = getelementptr i8, ptr %p4318, i64 -16
  %ld4320 = load i64, ptr %rgep4319, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4320, ptr %slot579, align 8
  %v4321 = load i64, ptr %slot579, align 8
  %op4322 = and i64 %v4321, 4611686018427387906
  store i64 %op4322, ptr %slot580, align 8
  %v4323 = load i64, ptr %slot580, align 8
  %cmp4324 = icmp ne i64 %v4323, 0
  %cv4325 = zext i1 %cmp4324 to i32
  store i32 %cv4325, ptr %slot581, align 8
  %v4326 = load i32, ptr %slot581, align 8
  %cv4327 = zext i32 %v4326 to i64
  %cond4328 = icmp ne i64 %cv4327, 0
  br i1 %cond4328, label %bb_rcgclear958, label %bb_rcgcounted958
bb_rcgcounted958:
  %v4329 = load i64, ptr %slot576, align 8
  %op4330 = sub i64 %v4329, 32
  store i64 %op4330, ptr %slot582, align 8
  %v4331 = load i64, ptr %slot576, align 8
  %p4332 = inttoptr i64 %v4331 to ptr
  %rgep4333 = getelementptr i8, ptr %p4332, i64 -32
  %ld4334 = load i64, ptr %rgep4333, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4334, ptr %slot583, align 8
  %v4335 = load i64, ptr %slot583, align 8
  %op4336 = sub i64 %v4335, 1
  store i64 %op4336, ptr %slot584, align 8
  %v4337 = load i64, ptr %slot584, align 8
  %cmp4338 = icmp eq i64 %v4337, 0
  %cv4339 = zext i1 %cmp4338 to i32
  store i32 %cv4339, ptr %slot585, align 8
  %v4340 = load i32, ptr %slot585, align 8
  %cv4341 = zext i32 %v4340 to i64
  %cond4342 = icmp ne i64 %cv4341, 0
  br i1 %cond4342, label %bb_rcglast958, label %bb_rcgdec958
bb_rcglast958:
  %v4343 = load i64, ptr %slot576, align 8
  %op4344 = sub i64 %v4343, 24
  store i64 %op4344, ptr %slot586, align 8
  %v4345 = load i64, ptr %slot576, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  %rgep4347 = getelementptr i8, ptr %p4346, i64 -24
  %ld4348 = load i64, ptr %rgep4347, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4348, ptr %slot587, align 8
  %v4349 = load i64, ptr %slot587, align 8
  %cmp4350 = icmp ne i64 %v4349, 0
  %cv4351 = zext i1 %cmp4350 to i32
  store i32 %cv4351, ptr %slot588, align 8
  %v4352 = load i32, ptr %slot588, align 8
  %cv4353 = zext i32 %v4352 to i64
  %cond4354 = icmp ne i64 %cv4353, 0
  br i1 %cond4354, label %bb_rcgdec958, label %bb_rcgslow958
bb_rcgslow958:
  %v4355 = load i64, ptr %slot575, align 8
  %v4356 = load i64, ptr %slot558, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v4355, i64 %v4356) nomerge, !dbg !148
  br label %bb_rcgdone958
bb_rcgdec958:
  %v4357 = load i64, ptr %slot584, align 8
  %v4358 = load i64, ptr %slot576, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  %rgep4360 = getelementptr i8, ptr %p4359, i64 -32
  store i64 %v4357, ptr %rgep4360, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear958
bb_rcgclear958:
  %v4361 = load i64, ptr %slot558, align 8
  %p4362 = inttoptr i64 %v4361 to ptr
  store i64 0, ptr %p4362, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone958
bb_rcgdone958:
  br label %bb_rcslotdone927
bb_rcslotdone927:
  %v4363 = load i64, ptr %slot7, align 8
  %p4364 = inttoptr i64 %v4363 to ptr
  %ld4365 = load i32, ptr %p4364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4365, ptr %slot589, align 8
  %v4366 = load i32, ptr %slot589, align 8
  %cv4367 = zext i32 %v4366 to i64
  %cond4368 = icmp ne i64 %cv4367, 0
  br i1 %cond4368, label %bb_rcslotdrop964, label %bb_rcslotdone964
bb_rcslotdrop964:
  %v4369 = load i64, ptr %slot7, align 8
  %p4370 = inttoptr i64 %v4369 to ptr
  store i32 0, ptr %p4370, align 4, !alias.scope !3, !noalias !4
  %v4371 = load i64, ptr %slot42, align 8
  store i64 %v4371, ptr %slot590, align 8
  %v4372 = load i64, ptr %slot8, align 8
  %p4373 = inttoptr i64 %v4372 to ptr
  %ld4374 = load i32, ptr %p4373, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4374, ptr %slot591, align 8
  %v4375 = load i32, ptr %slot591, align 8
  %op4376 = and i32 %v4375, 28
  store i32 %op4376, ptr %slot592, align 8
  %v4377 = load i32, ptr %slot592, align 8
  %cv4378 = zext i32 %v4377 to i64
  %cond4379 = icmp ne i64 %cv4378, 0
  br i1 %cond4379, label %bb_rcslotrole964, label %bb_rcslotowner964
bb_rcslotrole964:
  %v4380 = load i64, ptr %slot70, align 8
  store i64 %v4380, ptr %slot593, align 8
  %v4381 = load i64, ptr %slot593, align 8
  %v4382 = load i64, ptr %slot590, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4381, i64 %v4382) nomerge, !dbg !148
  br label %bb_rcslotdone964
bb_rcslotowner964:
  %v4383 = load i64, ptr %slot70, align 8
  store i64 %v4383, ptr %slot594, align 8
  %v4384 = load i64, ptr %slot594, align 8
  %v4385 = load i64, ptr %slot590, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4384, i64 %v4385) nomerge, !dbg !148
  br label %bb_rcslotdone964
bb_rcslotdone964:
  %v4386 = load i64, ptr %slot526, align 8
  ret i64 %v4386
bb_i74:
  %v4387 = load i64, ptr %slot42, align 8
  %v4388 = load i64, ptr %slot57, align 8
  %p4389 = inttoptr i64 %v4388 to ptr
  store i64 %v4387, ptr %p4389, align 8, !alias.scope !3, !noalias !4
  %v4390 = load i64, ptr %slot57, align 8
  %p4391 = inttoptr i64 %v4390 to ptr
  %ld4392 = load i64, ptr %p4391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4392, ptr %slot595, align 8
  %v4393 = load i64, ptr %slot595, align 8
  %op4394 = add i64 %v4393, 72
  store i64 %op4394, ptr %slot596, align 8
  %v4395 = load i64, ptr %slot596, align 8
  %p4396 = inttoptr i64 %v4395 to ptr
  %ld4397 = load i64, ptr %p4396, align 8
  store i64 %ld4397, ptr %slot597, align 8
  %v4398 = load i64, ptr %slot597, align 8
  %v4399 = load i64, ptr %slot57, align 8
  %p4400 = inttoptr i64 %v4399 to ptr
  store i64 %v4398, ptr %p4400, align 8, !alias.scope !3, !noalias !4
  %v4401 = load i64, ptr %slot57, align 8
  %p4402 = inttoptr i64 %v4401 to ptr
  %ld4403 = load i64, ptr %p4402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4403, ptr %slot598, align 8
  %v4404 = load i64, ptr %slot598, align 8
  %v4405 = load i64, ptr %slot26, align 8
  %p4406 = inttoptr i64 %v4405 to ptr
  store i64 %v4404, ptr %p4406, align 8, !alias.scope !3, !noalias !4
  %v4407 = load i64, ptr %slot26, align 8
  store i64 %v4407, ptr %slot599, align 8
  %v4408 = load i64, ptr %slot28, align 8
  store i64 %v4408, ptr %slot600, align 8
  %v4409 = load i64, ptr %slot599, align 8
  %p4410 = inttoptr i64 %v4409 to ptr
  %ld4411 = load i64, ptr %p4410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4411, ptr %slot601, align 8
  %v4412 = load i64, ptr %slot601, align 8
  %cmp4413 = icmp ne i64 %v4412, 0
  %cv4414 = zext i1 %cmp4413 to i32
  store i32 %cv4414, ptr %slot602, align 8
  %v4415 = load i32, ptr %slot602, align 8
  %cv4416 = zext i32 %v4415 to i64
  %cond4417 = icmp ne i64 %cv4416, 0
  br i1 %cond4417, label %bb_rcgnn1024, label %bb_rcgstore1024
bb_rcgnn1024:
  %v4418 = load i64, ptr %slot601, align 8
  %op4419 = sub i64 %v4418, 16
  store i64 %op4419, ptr %slot603, align 8
  %v4420 = load i64, ptr %slot601, align 8
  %p4421 = inttoptr i64 %v4420 to ptr
  %rgep4422 = getelementptr i8, ptr %p4421, i64 -16
  %ld4423 = load i64, ptr %rgep4422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4423, ptr %slot604, align 8
  %v4424 = load i64, ptr %slot604, align 8
  %op4425 = and i64 %v4424, 4611686018427387906
  store i64 %op4425, ptr %slot605, align 8
  %v4426 = load i64, ptr %slot605, align 8
  %cmp4427 = icmp ne i64 %v4426, 0
  %cv4428 = zext i1 %cmp4427 to i32
  store i32 %cv4428, ptr %slot606, align 8
  %v4429 = load i32, ptr %slot606, align 8
  %cv4430 = zext i32 %v4429 to i64
  %cond4431 = icmp ne i64 %cv4430, 0
  br i1 %cond4431, label %bb_rcgstore1024, label %bb_rcginc1024
bb_rcginc1024:
  %v4432 = load i64, ptr %slot601, align 8
  %op4433 = sub i64 %v4432, 24
  store i64 %op4433, ptr %slot607, align 8
  %v4434 = load i64, ptr %slot601, align 8
  %p4435 = inttoptr i64 %v4434 to ptr
  %rgep4436 = getelementptr i8, ptr %p4435, i64 -24
  %ld4437 = load i64, ptr %rgep4436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4437, ptr %slot608, align 8
  %v4438 = load i64, ptr %slot608, align 8
  %op4439 = add i64 %v4438, 1
  store i64 %op4439, ptr %slot609, align 8
  %v4440 = load i64, ptr %slot609, align 8
  %cmp4441 = icmp eq i64 %v4440, 0
  %cv4442 = zext i1 %cmp4441 to i32
  store i32 %cv4442, ptr %slot610, align 8
  %v4443 = load i32, ptr %slot610, align 8
  %cv4444 = zext i32 %v4443 to i64
  %cond4445 = icmp ne i64 %cv4444, 0
  br i1 %cond4445, label %bb_rcglimit1024, label %bb_rcgcapacity1024
bb_rcglimit1024:
  %v4446 = load i64, ptr %slot1, align 8
  %p4447 = inttoptr i64 %v4446 to ptr
  %call4448 = call i32 @myl_qbe_rc_status(ptr %p4447, i32 2) nomerge, !dbg !150
  store i32 %call4448, ptr %slot611, align 8
  br label %bb_failure
bb_rcgcapacity1024:
  %v4449 = load i64, ptr %slot609, align 8
  %v4450 = load i64, ptr %slot601, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  %rgep4452 = getelementptr i8, ptr %p4451, i64 -24
  store i64 %v4449, ptr %rgep4452, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1024
bb_rcgstore1024:
  %v4453 = load i64, ptr %slot601, align 8
  %v4454 = load i64, ptr %slot600, align 8
  %p4455 = inttoptr i64 %v4454 to ptr
  store i64 %v4453, ptr %p4455, align 8, !alias.scope !3, !noalias !4
  %v4456 = load i64, ptr %slot22, align 8
  %p4457 = inttoptr i64 %v4456 to ptr
  store i32 2, ptr %p4457, align 4, !alias.scope !3, !noalias !4
  %v4458 = load i64, ptr %slot22, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  store i32 16, ptr %p4459, align 4, !alias.scope !3, !noalias !4
  %v4460 = load i64, ptr %slot21, align 8
  %p4461 = inttoptr i64 %v4460 to ptr
  store i32 1, ptr %p4461, align 4, !alias.scope !3, !noalias !4
  %v4462 = load i64, ptr %slot17, align 8
  %p4463 = inttoptr i64 %v4462 to ptr
  %ld4464 = load i32, ptr %p4463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4464, ptr %slot612, align 8
  %v4465 = load i32, ptr %slot612, align 8
  %cv4466 = zext i32 %v4465 to i64
  %cond4467 = icmp ne i64 %cv4466, 0
  br i1 %cond4467, label %bb_rcslotdrop1040, label %bb_rcslotdone1040
bb_rcslotdrop1040:
  %v4468 = load i64, ptr %slot17, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  store i32 0, ptr %p4469, align 4, !alias.scope !3, !noalias !4
  %v4470 = load i64, ptr %slot24, align 8
  store i64 %v4470, ptr %slot613, align 8
  %v4471 = load i64, ptr %slot18, align 8
  %p4472 = inttoptr i64 %v4471 to ptr
  %ld4473 = load i32, ptr %p4472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4473, ptr %slot614, align 8
  %v4474 = load i32, ptr %slot614, align 8
  %op4475 = and i32 %v4474, 28
  store i32 %op4475, ptr %slot615, align 8
  %v4476 = load i32, ptr %slot615, align 8
  %cv4477 = zext i32 %v4476 to i64
  %cond4478 = icmp ne i64 %cv4477, 0
  br i1 %cond4478, label %bb_rcslotrole1040, label %bb_rcslotowner1040
bb_rcslotrole1040:
  %v4479 = load i64, ptr %slot70, align 8
  store i64 %v4479, ptr %slot616, align 8
  %v4480 = load i64, ptr %slot616, align 8
  %v4481 = load i64, ptr %slot613, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4480, i64 %v4481) nomerge, !dbg !150
  br label %bb_rcslotdone1040
bb_rcslotowner1040:
  %v4482 = load i64, ptr %slot70, align 8
  store i64 %v4482, ptr %slot617, align 8
  %v4483 = load i64, ptr %slot617, align 8
  %v4484 = load i64, ptr %slot613, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4483, i64 %v4484) nomerge, !dbg !150
  br label %bb_rcslotdone1040
bb_rcslotdone1040:
  %v4485 = load i64, ptr %slot24, align 8
  store i64 %v4485, ptr %slot618, align 8
  %v4486 = load i64, ptr %slot28, align 8
  store i64 %v4486, ptr %slot619, align 8
  %v4487 = load i64, ptr %slot619, align 8
  %v4488 = load i64, ptr %slot618, align 8
  %p4489 = inttoptr i64 %v4487 to ptr
  %p4490 = inttoptr i64 %v4488 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4490, ptr %p4489, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4491 = load i64, ptr %slot18, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  store i32 2, ptr %p4492, align 4, !alias.scope !3, !noalias !4
  %v4493 = load i64, ptr %slot22, align 8
  %p4494 = inttoptr i64 %v4493 to ptr
  %ld4495 = load i32, ptr %p4494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4495, ptr %slot620, align 8
  %v4496 = load i32, ptr %slot620, align 8
  %v4497 = load i64, ptr %slot18, align 8
  %p4498 = inttoptr i64 %v4497 to ptr
  store i32 %v4496, ptr %p4498, align 4, !alias.scope !3, !noalias !4
  %v4499 = load i64, ptr %slot21, align 8
  %p4500 = inttoptr i64 %v4499 to ptr
  store i32 0, ptr %p4500, align 4, !alias.scope !3, !noalias !4
  %v4501 = load i64, ptr %slot17, align 8
  %p4502 = inttoptr i64 %v4501 to ptr
  store i32 1, ptr %p4502, align 4, !alias.scope !3, !noalias !4
  %v4503 = load i64, ptr %slot618, align 8
  %p4504 = inttoptr i64 %v4503 to ptr
  %ld4505 = load i64, ptr %p4504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4505, ptr %slot621, align 8
  %v4506 = load i64, ptr %slot621, align 8
  %v4507 = load i64, ptr %slot57, align 8
  %p4508 = inttoptr i64 %v4507 to ptr
  store i64 %v4506, ptr %p4508, align 8, !alias.scope !3, !noalias !4
  %v4509 = load i64, ptr %slot57, align 8
  %p4510 = inttoptr i64 %v4509 to ptr
  %ld4511 = load i64, ptr %p4510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4511, ptr %slot622, align 8
  %v4512 = load i64, ptr %slot42, align 8
  store i64 %v4512, ptr %slot623, align 8
  %v4513 = load i64, ptr %slot17, align 8
  %p4514 = inttoptr i64 %v4513 to ptr
  %ld4515 = load i32, ptr %p4514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4515, ptr %slot624, align 8
  %v4516 = load i32, ptr %slot624, align 8
  %cv4517 = zext i32 %v4516 to i64
  %cond4518 = icmp ne i64 %cv4517, 0
  br i1 %cond4518, label %bb_rcslotdrop1061, label %bb_rcslotdone1061
bb_rcslotdrop1061:
  %v4519 = load i64, ptr %slot17, align 8
  %p4520 = inttoptr i64 %v4519 to ptr
  store i32 0, ptr %p4520, align 4, !alias.scope !3, !noalias !4
  %v4521 = load i64, ptr %slot24, align 8
  store i64 %v4521, ptr %slot625, align 8
  %v4522 = load i64, ptr %slot18, align 8
  %p4523 = inttoptr i64 %v4522 to ptr
  %ld4524 = load i32, ptr %p4523, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4524, ptr %slot626, align 8
  %v4525 = load i32, ptr %slot626, align 8
  %op4526 = and i32 %v4525, 28
  store i32 %op4526, ptr %slot627, align 8
  %v4527 = load i32, ptr %slot627, align 8
  %cv4528 = zext i32 %v4527 to i64
  %cond4529 = icmp ne i64 %cv4528, 0
  br i1 %cond4529, label %bb_rcslotrole1061, label %bb_rcslotowner1061
bb_rcslotrole1061:
  %v4530 = load i64, ptr %slot70, align 8
  store i64 %v4530, ptr %slot628, align 8
  %v4531 = load i64, ptr %slot625, align 8
  %p4532 = inttoptr i64 %v4531 to ptr
  %ld4533 = load i64, ptr %p4532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4533, ptr %slot629, align 8
  %v4534 = load i64, ptr %slot629, align 8
  %cmp4535 = icmp ne i64 %v4534, 0
  %cv4536 = zext i1 %cmp4535 to i32
  store i32 %cv4536, ptr %slot630, align 8
  %v4537 = load i32, ptr %slot630, align 8
  %cv4538 = zext i32 %v4537 to i64
  %cond4539 = icmp ne i64 %cv4538, 0
  br i1 %cond4539, label %bb_rcgnn1077, label %bb_rcgdone1077
bb_rcgnn1077:
  %v4540 = load i64, ptr %slot629, align 8
  %op4541 = sub i64 %v4540, 16
  store i64 %op4541, ptr %slot631, align 8
  %v4542 = load i64, ptr %slot629, align 8
  %p4543 = inttoptr i64 %v4542 to ptr
  %rgep4544 = getelementptr i8, ptr %p4543, i64 -16
  %ld4545 = load i64, ptr %rgep4544, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4545, ptr %slot632, align 8
  %v4546 = load i64, ptr %slot632, align 8
  %op4547 = and i64 %v4546, 4611686018427387906
  store i64 %op4547, ptr %slot633, align 8
  %v4548 = load i64, ptr %slot633, align 8
  %cmp4549 = icmp ne i64 %v4548, 0
  %cv4550 = zext i1 %cmp4549 to i32
  store i32 %cv4550, ptr %slot634, align 8
  %v4551 = load i32, ptr %slot634, align 8
  %cv4552 = zext i32 %v4551 to i64
  %cond4553 = icmp ne i64 %cv4552, 0
  br i1 %cond4553, label %bb_rcgclear1077, label %bb_rcgcounted1077
bb_rcgcounted1077:
  %v4554 = load i64, ptr %slot629, align 8
  %op4555 = sub i64 %v4554, 24
  store i64 %op4555, ptr %slot635, align 8
  %v4556 = load i64, ptr %slot629, align 8
  %p4557 = inttoptr i64 %v4556 to ptr
  %rgep4558 = getelementptr i8, ptr %p4557, i64 -24
  %ld4559 = load i64, ptr %rgep4558, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4559, ptr %slot636, align 8
  %v4560 = load i64, ptr %slot636, align 8
  %op4561 = sub i64 %v4560, 1
  store i64 %op4561, ptr %slot637, align 8
  %v4562 = load i64, ptr %slot637, align 8
  %cmp4563 = icmp eq i64 %v4562, 0
  %cv4564 = zext i1 %cmp4563 to i32
  store i32 %cv4564, ptr %slot638, align 8
  %v4565 = load i32, ptr %slot638, align 8
  %cv4566 = zext i32 %v4565 to i64
  %cond4567 = icmp ne i64 %cv4566, 0
  br i1 %cond4567, label %bb_rcglast1077, label %bb_rcgdec1077
bb_rcglast1077:
  %v4568 = load i64, ptr %slot629, align 8
  %op4569 = sub i64 %v4568, 32
  store i64 %op4569, ptr %slot639, align 8
  %v4570 = load i64, ptr %slot629, align 8
  %p4571 = inttoptr i64 %v4570 to ptr
  %rgep4572 = getelementptr i8, ptr %p4571, i64 -32
  %ld4573 = load i64, ptr %rgep4572, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4573, ptr %slot640, align 8
  %v4574 = load i64, ptr %slot640, align 8
  %cmp4575 = icmp ne i64 %v4574, 0
  %cv4576 = zext i1 %cmp4575 to i32
  store i32 %cv4576, ptr %slot641, align 8
  %v4577 = load i32, ptr %slot641, align 8
  %cv4578 = zext i32 %v4577 to i64
  %cond4579 = icmp ne i64 %cv4578, 0
  br i1 %cond4579, label %bb_rcgdec1077, label %bb_rcgslow1077
bb_rcgslow1077:
  %v4580 = load i64, ptr %slot628, align 8
  %v4581 = load i64, ptr %slot625, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v4580, i64 %v4581) nomerge, !dbg !152
  br label %bb_rcgdone1077
bb_rcgdec1077:
  %v4582 = load i64, ptr %slot637, align 8
  %v4583 = load i64, ptr %slot629, align 8
  %p4584 = inttoptr i64 %v4583 to ptr
  %rgep4585 = getelementptr i8, ptr %p4584, i64 -24
  store i64 %v4582, ptr %rgep4585, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1077
bb_rcgclear1077:
  %v4586 = load i64, ptr %slot625, align 8
  %p4587 = inttoptr i64 %v4586 to ptr
  store i64 0, ptr %p4587, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1077
bb_rcgdone1077:
  br label %bb_rcslotdone1061
bb_rcslotowner1061:
  %v4588 = load i64, ptr %slot70, align 8
  store i64 %v4588, ptr %slot642, align 8
  %v4589 = load i64, ptr %slot625, align 8
  %p4590 = inttoptr i64 %v4589 to ptr
  %ld4591 = load i64, ptr %p4590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4591, ptr %slot643, align 8
  %v4592 = load i64, ptr %slot643, align 8
  %cmp4593 = icmp ne i64 %v4592, 0
  %cv4594 = zext i1 %cmp4593 to i32
  store i32 %cv4594, ptr %slot644, align 8
  %v4595 = load i32, ptr %slot644, align 8
  %cv4596 = zext i32 %v4595 to i64
  %cond4597 = icmp ne i64 %cv4596, 0
  br i1 %cond4597, label %bb_rcgnn1092, label %bb_rcgdone1092
bb_rcgnn1092:
  %v4598 = load i64, ptr %slot643, align 8
  %op4599 = sub i64 %v4598, 16
  store i64 %op4599, ptr %slot645, align 8
  %v4600 = load i64, ptr %slot643, align 8
  %p4601 = inttoptr i64 %v4600 to ptr
  %rgep4602 = getelementptr i8, ptr %p4601, i64 -16
  %ld4603 = load i64, ptr %rgep4602, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4603, ptr %slot646, align 8
  %v4604 = load i64, ptr %slot646, align 8
  %op4605 = and i64 %v4604, 4611686018427387906
  store i64 %op4605, ptr %slot647, align 8
  %v4606 = load i64, ptr %slot647, align 8
  %cmp4607 = icmp ne i64 %v4606, 0
  %cv4608 = zext i1 %cmp4607 to i32
  store i32 %cv4608, ptr %slot648, align 8
  %v4609 = load i32, ptr %slot648, align 8
  %cv4610 = zext i32 %v4609 to i64
  %cond4611 = icmp ne i64 %cv4610, 0
  br i1 %cond4611, label %bb_rcgclear1092, label %bb_rcgcounted1092
bb_rcgcounted1092:
  %v4612 = load i64, ptr %slot643, align 8
  %op4613 = sub i64 %v4612, 32
  store i64 %op4613, ptr %slot649, align 8
  %v4614 = load i64, ptr %slot643, align 8
  %p4615 = inttoptr i64 %v4614 to ptr
  %rgep4616 = getelementptr i8, ptr %p4615, i64 -32
  %ld4617 = load i64, ptr %rgep4616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4617, ptr %slot650, align 8
  %v4618 = load i64, ptr %slot650, align 8
  %op4619 = sub i64 %v4618, 1
  store i64 %op4619, ptr %slot651, align 8
  %v4620 = load i64, ptr %slot651, align 8
  %cmp4621 = icmp eq i64 %v4620, 0
  %cv4622 = zext i1 %cmp4621 to i32
  store i32 %cv4622, ptr %slot652, align 8
  %v4623 = load i32, ptr %slot652, align 8
  %cv4624 = zext i32 %v4623 to i64
  %cond4625 = icmp ne i64 %cv4624, 0
  br i1 %cond4625, label %bb_rcglast1092, label %bb_rcgdec1092
bb_rcglast1092:
  %v4626 = load i64, ptr %slot643, align 8
  %op4627 = sub i64 %v4626, 24
  store i64 %op4627, ptr %slot653, align 8
  %v4628 = load i64, ptr %slot643, align 8
  %p4629 = inttoptr i64 %v4628 to ptr
  %rgep4630 = getelementptr i8, ptr %p4629, i64 -24
  %ld4631 = load i64, ptr %rgep4630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4631, ptr %slot654, align 8
  %v4632 = load i64, ptr %slot654, align 8
  %cmp4633 = icmp ne i64 %v4632, 0
  %cv4634 = zext i1 %cmp4633 to i32
  store i32 %cv4634, ptr %slot655, align 8
  %v4635 = load i32, ptr %slot655, align 8
  %cv4636 = zext i32 %v4635 to i64
  %cond4637 = icmp ne i64 %cv4636, 0
  br i1 %cond4637, label %bb_rcgdec1092, label %bb_rcgslow1092
bb_rcgslow1092:
  %v4638 = load i64, ptr %slot642, align 8
  %v4639 = load i64, ptr %slot625, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v4638, i64 %v4639) nomerge, !dbg !152
  br label %bb_rcgdone1092
bb_rcgdec1092:
  %v4640 = load i64, ptr %slot651, align 8
  %v4641 = load i64, ptr %slot643, align 8
  %p4642 = inttoptr i64 %v4641 to ptr
  %rgep4643 = getelementptr i8, ptr %p4642, i64 -32
  store i64 %v4640, ptr %rgep4643, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1092
bb_rcgclear1092:
  %v4644 = load i64, ptr %slot625, align 8
  %p4645 = inttoptr i64 %v4644 to ptr
  store i64 0, ptr %p4645, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1092
bb_rcgdone1092:
  br label %bb_rcslotdone1061
bb_rcslotdone1061:
  %v4646 = load i64, ptr %slot623, align 8
  %p4648 = inttoptr i64 %v4646 to ptr
  %gep4649 = getelementptr i8, ptr %p4648, i64 72
  %op4647 = ptrtoint ptr %gep4649 to i64
  store i64 %op4647, ptr %slot656, align 8
  store i64 0, ptr %slot657, align 8
  %v4650 = load i64, ptr %slot656, align 8
  %p4651 = inttoptr i64 %v4650 to ptr
  %ld4652 = load i64, ptr %p4651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4652, ptr %slot658, align 8
  %v4653 = load i64, ptr %slot658, align 8
  %cmp4654 = icmp ne i64 %v4653, 0
  %cv4655 = zext i1 %cmp4654 to i32
  store i32 %cv4655, ptr %slot659, align 8
  %v4656 = load i32, ptr %slot659, align 8
  %cv4657 = zext i32 %v4656 to i64
  %cond4658 = icmp ne i64 %cv4657, 0
  br i1 %cond4658, label %bb_rcguniquenn1098, label %bb_rcgunique1098
bb_rcguniquenn1098:
  %v4659 = load i64, ptr %slot658, align 8
  %op4660 = sub i64 %v4659, 16
  store i64 %op4660, ptr %slot660, align 8
  %v4661 = load i64, ptr %slot658, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %rgep4663 = getelementptr i8, ptr %p4662, i64 -16
  %ld4664 = load i64, ptr %rgep4663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4664, ptr %slot661, align 8
  %v4665 = load i64, ptr %slot661, align 8
  %op4666 = and i64 %v4665, 6917529027641081858
  store i64 %op4666, ptr %slot662, align 8
  %v4667 = load i64, ptr %slot662, align 8
  %cmp4668 = icmp ne i64 %v4667, 0
  %cv4669 = zext i1 %cmp4668 to i32
  store i32 %cv4669, ptr %slot663, align 8
  %v4670 = load i32, ptr %slot663, align 8
  %cv4671 = zext i32 %v4670 to i64
  %cond4672 = icmp ne i64 %cv4671, 0
  br i1 %cond4672, label %bb_rcguniqueslow1098, label %bb_rcguniquecount1098
bb_rcguniquecount1098:
  %v4673 = load i64, ptr %slot658, align 8
  %op4674 = sub i64 %v4673, 32
  store i64 %op4674, ptr %slot664, align 8
  %v4675 = load i64, ptr %slot658, align 8
  %p4676 = inttoptr i64 %v4675 to ptr
  %rgep4677 = getelementptr i8, ptr %p4676, i64 -32
  %ld4678 = load i64, ptr %rgep4677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4678, ptr %slot665, align 8
  %v4679 = load i64, ptr %slot665, align 8
  %cmp4680 = icmp ult i64 %v4679, 2
  %cv4681 = zext i1 %cmp4680 to i32
  store i32 %cv4681, ptr %slot666, align 8
  %v4682 = load i32, ptr %slot666, align 8
  %cv4683 = zext i32 %v4682 to i64
  %cond4684 = icmp ne i64 %cv4683, 0
  br i1 %cond4684, label %bb_rcgunique1098, label %bb_rcguniqueslow1098
bb_rcguniqueslow1098:
  %v4685 = load i64, ptr %slot1, align 8
  %p4686 = inttoptr i64 %v4685 to ptr
  %p4687 = inttoptr i64 ptrtoint (ptr @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee to i64) to ptr
  %v4688 = load i64, ptr %slot656, align 8
  %p4689 = inttoptr i64 %v4688 to ptr
  %v4690 = load i64, ptr %slot657, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  %call4692 = call i32 @myl_qbe_rc_unique_field(ptr %p4686, ptr %p4687, ptr %p4689, ptr %p4691) nomerge, !dbg !152
  store i32 %call4692, ptr %slot667, align 8
  %v4693 = load i32, ptr %slot667, align 8
  %cv4694 = zext i32 %v4693 to i64
  %cond4695 = icmp ne i64 %cv4694, 0
  br i1 %cond4695, label %bb_rcunique1108, label %bb_failure
bb_rcunique1108:
  br label %bb_rcgunique1098
bb_rcgunique1098:
  %v4696 = load i64, ptr %slot656, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  %ld4698 = load i64, ptr %p4697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4698, ptr %slot668, align 8
  %v4699 = load i64, ptr %slot668, align 8
  %v4700 = load i64, ptr %slot57, align 8
  %p4701 = inttoptr i64 %v4700 to ptr
  store i64 %v4699, ptr %p4701, align 8, !alias.scope !3, !noalias !4
  %v4702 = load i64, ptr %slot57, align 8
  %p4703 = inttoptr i64 %v4702 to ptr
  %ld4704 = load i64, ptr %p4703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4704, ptr %slot669, align 8
  %v4705 = load i64, ptr %slot17, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  %ld4707 = load i32, ptr %p4706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4707, ptr %slot670, align 8
  %v4708 = load i32, ptr %slot670, align 8
  %cv4709 = zext i32 %v4708 to i64
  %cond4710 = icmp ne i64 %cv4709, 0
  br i1 %cond4710, label %bb_rcslotdrop1113, label %bb_rcslotdone1113
bb_rcslotdrop1113:
  %v4711 = load i64, ptr %slot17, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  store i32 0, ptr %p4712, align 4, !alias.scope !3, !noalias !4
  %v4713 = load i64, ptr %slot24, align 8
  store i64 %v4713, ptr %slot671, align 8
  %v4714 = load i64, ptr %slot18, align 8
  %p4715 = inttoptr i64 %v4714 to ptr
  %ld4716 = load i32, ptr %p4715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4716, ptr %slot672, align 8
  %v4717 = load i32, ptr %slot672, align 8
  %op4718 = and i32 %v4717, 28
  store i32 %op4718, ptr %slot673, align 8
  %v4719 = load i32, ptr %slot673, align 8
  %cv4720 = zext i32 %v4719 to i64
  %cond4721 = icmp ne i64 %cv4720, 0
  br i1 %cond4721, label %bb_rcslotrole1113, label %bb_rcslotowner1113
bb_rcslotrole1113:
  %v4722 = load i64, ptr %slot70, align 8
  store i64 %v4722, ptr %slot674, align 8
  %v4723 = load i64, ptr %slot671, align 8
  %p4724 = inttoptr i64 %v4723 to ptr
  %ld4725 = load i64, ptr %p4724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4725, ptr %slot675, align 8
  %v4726 = load i64, ptr %slot675, align 8
  %cmp4727 = icmp ne i64 %v4726, 0
  %cv4728 = zext i1 %cmp4727 to i32
  store i32 %cv4728, ptr %slot676, align 8
  %v4729 = load i32, ptr %slot676, align 8
  %cv4730 = zext i32 %v4729 to i64
  %cond4731 = icmp ne i64 %cv4730, 0
  br i1 %cond4731, label %bb_rcgnn1129, label %bb_rcgdone1129
bb_rcgnn1129:
  %v4732 = load i64, ptr %slot675, align 8
  %op4733 = sub i64 %v4732, 16
  store i64 %op4733, ptr %slot677, align 8
  %v4734 = load i64, ptr %slot675, align 8
  %p4735 = inttoptr i64 %v4734 to ptr
  %rgep4736 = getelementptr i8, ptr %p4735, i64 -16
  %ld4737 = load i64, ptr %rgep4736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4737, ptr %slot678, align 8
  %v4738 = load i64, ptr %slot678, align 8
  %op4739 = and i64 %v4738, 4611686018427387906
  store i64 %op4739, ptr %slot679, align 8
  %v4740 = load i64, ptr %slot679, align 8
  %cmp4741 = icmp ne i64 %v4740, 0
  %cv4742 = zext i1 %cmp4741 to i32
  store i32 %cv4742, ptr %slot680, align 8
  %v4743 = load i32, ptr %slot680, align 8
  %cv4744 = zext i32 %v4743 to i64
  %cond4745 = icmp ne i64 %cv4744, 0
  br i1 %cond4745, label %bb_rcgclear1129, label %bb_rcgcounted1129
bb_rcgcounted1129:
  %v4746 = load i64, ptr %slot675, align 8
  %op4747 = sub i64 %v4746, 24
  store i64 %op4747, ptr %slot681, align 8
  %v4748 = load i64, ptr %slot675, align 8
  %p4749 = inttoptr i64 %v4748 to ptr
  %rgep4750 = getelementptr i8, ptr %p4749, i64 -24
  %ld4751 = load i64, ptr %rgep4750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4751, ptr %slot682, align 8
  %v4752 = load i64, ptr %slot682, align 8
  %op4753 = sub i64 %v4752, 1
  store i64 %op4753, ptr %slot683, align 8
  %v4754 = load i64, ptr %slot683, align 8
  %cmp4755 = icmp eq i64 %v4754, 0
  %cv4756 = zext i1 %cmp4755 to i32
  store i32 %cv4756, ptr %slot684, align 8
  %v4757 = load i32, ptr %slot684, align 8
  %cv4758 = zext i32 %v4757 to i64
  %cond4759 = icmp ne i64 %cv4758, 0
  br i1 %cond4759, label %bb_rcglast1129, label %bb_rcgdec1129
bb_rcglast1129:
  %v4760 = load i64, ptr %slot675, align 8
  %op4761 = sub i64 %v4760, 32
  store i64 %op4761, ptr %slot685, align 8
  %v4762 = load i64, ptr %slot675, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  %rgep4764 = getelementptr i8, ptr %p4763, i64 -32
  %ld4765 = load i64, ptr %rgep4764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4765, ptr %slot686, align 8
  %v4766 = load i64, ptr %slot686, align 8
  %cmp4767 = icmp ne i64 %v4766, 0
  %cv4768 = zext i1 %cmp4767 to i32
  store i32 %cv4768, ptr %slot687, align 8
  %v4769 = load i32, ptr %slot687, align 8
  %cv4770 = zext i32 %v4769 to i64
  %cond4771 = icmp ne i64 %cv4770, 0
  br i1 %cond4771, label %bb_rcgdec1129, label %bb_rcgslow1129
bb_rcgslow1129:
  %v4772 = load i64, ptr %slot674, align 8
  %v4773 = load i64, ptr %slot671, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v4772, i64 %v4773) nomerge, !dbg !152
  br label %bb_rcgdone1129
bb_rcgdec1129:
  %v4774 = load i64, ptr %slot683, align 8
  %v4775 = load i64, ptr %slot675, align 8
  %p4776 = inttoptr i64 %v4775 to ptr
  %rgep4777 = getelementptr i8, ptr %p4776, i64 -24
  store i64 %v4774, ptr %rgep4777, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1129
bb_rcgclear1129:
  %v4778 = load i64, ptr %slot671, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  store i64 0, ptr %p4779, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1129
bb_rcgdone1129:
  br label %bb_rcslotdone1113
bb_rcslotowner1113:
  %v4780 = load i64, ptr %slot70, align 8
  store i64 %v4780, ptr %slot688, align 8
  %v4781 = load i64, ptr %slot671, align 8
  %p4782 = inttoptr i64 %v4781 to ptr
  %ld4783 = load i64, ptr %p4782, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4783, ptr %slot689, align 8
  %v4784 = load i64, ptr %slot689, align 8
  %cmp4785 = icmp ne i64 %v4784, 0
  %cv4786 = zext i1 %cmp4785 to i32
  store i32 %cv4786, ptr %slot690, align 8
  %v4787 = load i32, ptr %slot690, align 8
  %cv4788 = zext i32 %v4787 to i64
  %cond4789 = icmp ne i64 %cv4788, 0
  br i1 %cond4789, label %bb_rcgnn1144, label %bb_rcgdone1144
bb_rcgnn1144:
  %v4790 = load i64, ptr %slot689, align 8
  %op4791 = sub i64 %v4790, 16
  store i64 %op4791, ptr %slot691, align 8
  %v4792 = load i64, ptr %slot689, align 8
  %p4793 = inttoptr i64 %v4792 to ptr
  %rgep4794 = getelementptr i8, ptr %p4793, i64 -16
  %ld4795 = load i64, ptr %rgep4794, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4795, ptr %slot692, align 8
  %v4796 = load i64, ptr %slot692, align 8
  %op4797 = and i64 %v4796, 4611686018427387906
  store i64 %op4797, ptr %slot693, align 8
  %v4798 = load i64, ptr %slot693, align 8
  %cmp4799 = icmp ne i64 %v4798, 0
  %cv4800 = zext i1 %cmp4799 to i32
  store i32 %cv4800, ptr %slot694, align 8
  %v4801 = load i32, ptr %slot694, align 8
  %cv4802 = zext i32 %v4801 to i64
  %cond4803 = icmp ne i64 %cv4802, 0
  br i1 %cond4803, label %bb_rcgclear1144, label %bb_rcgcounted1144
bb_rcgcounted1144:
  %v4804 = load i64, ptr %slot689, align 8
  %op4805 = sub i64 %v4804, 32
  store i64 %op4805, ptr %slot695, align 8
  %v4806 = load i64, ptr %slot689, align 8
  %p4807 = inttoptr i64 %v4806 to ptr
  %rgep4808 = getelementptr i8, ptr %p4807, i64 -32
  %ld4809 = load i64, ptr %rgep4808, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4809, ptr %slot696, align 8
  %v4810 = load i64, ptr %slot696, align 8
  %op4811 = sub i64 %v4810, 1
  store i64 %op4811, ptr %slot697, align 8
  %v4812 = load i64, ptr %slot697, align 8
  %cmp4813 = icmp eq i64 %v4812, 0
  %cv4814 = zext i1 %cmp4813 to i32
  store i32 %cv4814, ptr %slot698, align 8
  %v4815 = load i32, ptr %slot698, align 8
  %cv4816 = zext i32 %v4815 to i64
  %cond4817 = icmp ne i64 %cv4816, 0
  br i1 %cond4817, label %bb_rcglast1144, label %bb_rcgdec1144
bb_rcglast1144:
  %v4818 = load i64, ptr %slot689, align 8
  %op4819 = sub i64 %v4818, 24
  store i64 %op4819, ptr %slot699, align 8
  %v4820 = load i64, ptr %slot689, align 8
  %p4821 = inttoptr i64 %v4820 to ptr
  %rgep4822 = getelementptr i8, ptr %p4821, i64 -24
  %ld4823 = load i64, ptr %rgep4822, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4823, ptr %slot700, align 8
  %v4824 = load i64, ptr %slot700, align 8
  %cmp4825 = icmp ne i64 %v4824, 0
  %cv4826 = zext i1 %cmp4825 to i32
  store i32 %cv4826, ptr %slot701, align 8
  %v4827 = load i32, ptr %slot701, align 8
  %cv4828 = zext i32 %v4827 to i64
  %cond4829 = icmp ne i64 %cv4828, 0
  br i1 %cond4829, label %bb_rcgdec1144, label %bb_rcgslow1144
bb_rcgslow1144:
  %v4830 = load i64, ptr %slot688, align 8
  %v4831 = load i64, ptr %slot671, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v4830, i64 %v4831) nomerge, !dbg !152
  br label %bb_rcgdone1144
bb_rcgdec1144:
  %v4832 = load i64, ptr %slot697, align 8
  %v4833 = load i64, ptr %slot689, align 8
  %p4834 = inttoptr i64 %v4833 to ptr
  %rgep4835 = getelementptr i8, ptr %p4834, i64 -32
  store i64 %v4832, ptr %rgep4835, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1144
bb_rcgclear1144:
  %v4836 = load i64, ptr %slot671, align 8
  %p4837 = inttoptr i64 %v4836 to ptr
  store i64 0, ptr %p4837, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1144
bb_rcgdone1144:
  br label %bb_rcslotdone1113
bb_rcslotdone1113:
  %v4838 = load i64, ptr %slot29, align 8
  store i64 %v4838, ptr %slot702, align 8
  %v4839 = load i64, ptr %slot70, align 8
  %v4840 = load i64, ptr %slot702, align 8
  %p4841 = inttoptr i64 %v4840 to ptr
  store i64 %v4839, ptr %p4841, align 8, !alias.scope !3, !noalias !4
  %v4842 = load i64, ptr %slot70, align 8
  %p4844 = inttoptr i64 %v4842 to ptr
  %gep4845 = getelementptr i8, ptr %p4844, i64 5640
  %op4843 = ptrtoint ptr %gep4845 to i64
  store i64 %op4843, ptr %slot703, align 8
  %v4846 = load i64, ptr %slot703, align 8
  %p4847 = inttoptr i64 %v4846 to ptr
  %ld4848 = load i64, ptr %p4847, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4848, ptr %slot704, align 8
  %v4849 = load i64, ptr %slot704, align 8
  %op4850 = add i64 %v4849, 248
  store i64 %op4850, ptr %slot705, align 8
  %v4851 = load i64, ptr %slot705, align 8
  %p4852 = inttoptr i64 %v4851 to ptr
  %ld4853 = load i64, ptr %p4852, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4853, ptr %slot706, align 8
  %v4854 = load i64, ptr %slot702, align 8
  %p4856 = inttoptr i64 %v4854 to ptr
  %gep4857 = getelementptr i8, ptr %p4856, i64 8
  %op4855 = ptrtoint ptr %gep4857 to i64
  store i64 %op4855, ptr %slot707, align 8
  %v4858 = load i64, ptr %slot706, align 8
  %v4859 = load i64, ptr %slot707, align 8
  %p4860 = inttoptr i64 %v4859 to ptr
  store i64 %v4858, ptr %p4860, align 8, !alias.scope !3, !noalias !4
  %v4861 = load i64, ptr %slot702, align 8
  %p4863 = inttoptr i64 %v4861 to ptr
  %gep4864 = getelementptr i8, ptr %p4863, i64 16
  %op4862 = ptrtoint ptr %gep4864 to i64
  store i64 %op4862, ptr %slot708, align 8
  %v4865 = load i64, ptr %slot708, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  store i64 0, ptr %p4866, align 8, !alias.scope !3, !noalias !4
  %v4867 = load i64, ptr %slot70, align 8
  %p4869 = inttoptr i64 %v4867 to ptr
  %gep4870 = getelementptr i8, ptr %p4869, i64 112
  %op4868 = ptrtoint ptr %gep4870 to i64
  store i64 %op4868, ptr %slot709, align 8
  %v4871 = load i64, ptr %slot702, align 8
  %p4873 = inttoptr i64 %v4871 to ptr
  %gep4874 = getelementptr i8, ptr %p4873, i64 24
  %op4872 = ptrtoint ptr %gep4874 to i64
  store i64 %op4872, ptr %slot710, align 8
  %v4875 = load i64, ptr %slot702, align 8
  %p4877 = inttoptr i64 %v4875 to ptr
  %gep4878 = getelementptr i8, ptr %p4877, i64 28
  %op4876 = ptrtoint ptr %gep4878 to i64
  store i64 %op4876, ptr %slot711, align 8
  %v4879 = load i64, ptr %slot709, align 8
  %p4880 = inttoptr i64 %v4879 to ptr
  %ld4881 = load i32, ptr %p4880, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld4881, ptr %slot712, align 8
  %v4882 = load i64, ptr %slot710, align 8
  %p4883 = inttoptr i64 %v4882 to ptr
  store i32 1, ptr %p4883, align 4, !alias.scope !3, !noalias !4
  %v4884 = load i32, ptr %slot712, align 8
  %v4885 = load i64, ptr %slot711, align 8
  %p4886 = inttoptr i64 %v4885 to ptr
  store i32 %v4884, ptr %p4886, align 4, !alias.scope !3, !noalias !4
  %v4887 = load i64, ptr %slot702, align 8
  %v4888 = load i64, ptr %slot705, align 8
  %p4889 = inttoptr i64 %v4888 to ptr
  store i64 %v4887, ptr %p4889, align 8, !alias.scope !9999998, !noalias !9999999
  %v4890 = load i64, ptr %slot669, align 8
  %cmp4891 = icmp ne i64 %v4890, 0
  %cv4892 = zext i1 %cmp4891 to i32
  store i32 %cv4892, ptr %slot713, align 8
  %v4893 = load i32, ptr %slot713, align 8
  %cv4894 = zext i32 %v4893 to i64
  %cond4895 = icmp ne i64 %cv4894, 0
  br i1 %cond4895, label %bb_rcspinmark1196, label %bb_rcspindone1196
bb_rcspinmark1196:
  %v4896 = load i64, ptr %slot669, align 8
  %op4897 = sub i64 %v4896, 16
  store i64 %op4897, ptr %slot714, align 8
  %v4898 = load i64, ptr %slot669, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  %rgep4900 = getelementptr i8, ptr %p4899, i64 -16
  %ld4901 = load i64, ptr %rgep4900, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4901, ptr %slot715, align 8
  %v4902 = load i64, ptr %slot715, align 8
  %op4903 = and i64 %v4902, 2
  store i64 %op4903, ptr %slot716, align 8
  %v4904 = load i64, ptr %slot716, align 8
  %cmp4905 = icmp ne i64 %v4904, 0
  %cv4906 = zext i1 %cmp4905 to i32
  store i32 %cv4906, ptr %slot717, align 8
  %v4907 = load i32, ptr %slot717, align 8
  %cv4908 = zext i32 %v4907 to i64
  %cond4909 = icmp ne i64 %cv4908, 0
  br i1 %cond4909, label %bb_rcspindone1196, label %bb_rcspintype1196
bb_rcspintype1196:
  %v4910 = load i64, ptr %slot715, align 8
  %op4911 = and i64 %v4910, 4611686018427387907
  store i64 %op4911, ptr %slot718, align 8
  %v4912 = load i64, ptr %slot718, align 8
  %cmp4913 = icmp eq i64 %v4912, 0
  %cv4914 = zext i1 %cmp4913 to i32
  store i32 %cv4914, ptr %slot719, align 8
  %v4915 = load i32, ptr %slot719, align 8
  %cv4916 = zext i32 %v4915 to i64
  %cond4917 = icmp ne i64 %cv4916, 0
  br i1 %cond4917, label %bb_rcs1204, label %bb_rcspinslow1196
bb_rcs1204:
  %v4918 = load i64, ptr %slot669, align 8
  %op4919 = sub i64 %v4918, 8
  store i64 %op4919, ptr %slot720, align 8
  %v4920 = load i64, ptr %slot669, align 8
  %p4921 = inttoptr i64 %v4920 to ptr
  %rgep4922 = getelementptr i8, ptr %p4921, i64 -8
  %ld4923 = load i64, ptr %rgep4922, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4923, ptr %slot721, align 8
  %p4924 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld4925 = load i64, ptr %p4924, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4925, ptr %slot722, align 8
  %v4926 = load i64, ptr %slot721, align 8
  %v4927 = load i64, ptr %slot722, align 8
  %cmp4928 = icmp eq i64 %v4926, %v4927
  %cv4929 = zext i1 %cmp4928 to i32
  store i32 %cv4929, ptr %slot723, align 8
  %v4930 = load i32, ptr %slot723, align 8
  %cv4931 = zext i32 %v4930 to i64
  %cond4932 = icmp ne i64 %cv4931, 0
  br i1 %cond4932, label %bb_rcs1209, label %bb_rcspinslow1196
bb_rcs1209:
  %v4933 = load i64, ptr %slot70, align 8
  %p4935 = inttoptr i64 %v4933 to ptr
  %gep4936 = getelementptr i8, ptr %p4935, i64 5640
  %op4934 = ptrtoint ptr %gep4936 to i64
  store i64 %op4934, ptr %slot724, align 8
  %v4937 = load i64, ptr %slot724, align 8
  %p4938 = inttoptr i64 %v4937 to ptr
  %ld4939 = load i64, ptr %p4938, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4939, ptr %slot725, align 8
  %v4940 = load i64, ptr %slot725, align 8
  %op4941 = add i64 %v4940, 256
  store i64 %op4941, ptr %slot726, align 8
  %v4942 = load i64, ptr %slot726, align 8
  %p4943 = inttoptr i64 %v4942 to ptr
  %ld4944 = load i64, ptr %p4943, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4944, ptr %slot727, align 8
  %v4945 = load i64, ptr %slot727, align 8
  %cmp4946 = icmp ne i64 %v4945, 0
  %cv4947 = zext i1 %cmp4946 to i32
  store i32 %cv4947, ptr %slot728, align 8
  %v4948 = load i32, ptr %slot728, align 8
  %cv4949 = zext i32 %v4948 to i64
  %cond4950 = icmp ne i64 %cv4949, 0
  br i1 %cond4950, label %bb_rcs1215, label %bb_rcspinslow1196
bb_rcs1215:
  %v4951 = load i64, ptr %slot70, align 8
  %p4953 = inttoptr i64 %v4951 to ptr
  %gep4954 = getelementptr i8, ptr %p4953, i64 24
  %op4952 = ptrtoint ptr %gep4954 to i64
  store i64 %op4952, ptr %slot729, align 8
  %v4955 = load i64, ptr %slot729, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  %ld4957 = load i64, ptr %p4956, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4957, ptr %slot730, align 8
  %v4958 = load i64, ptr %slot730, align 8
  %op4959 = add i64 %v4958, 40
  store i64 %op4959, ptr %slot731, align 8
  %v4960 = load i64, ptr %slot731, align 8
  %v4961 = load i64, ptr %slot730, align 8
  %cmp4962 = icmp uge i64 %v4960, %v4961
  %cv4963 = zext i1 %cmp4962 to i32
  store i32 %cv4963, ptr %slot732, align 8
  %v4964 = load i32, ptr %slot732, align 8
  %cv4965 = zext i32 %v4964 to i64
  %cond4966 = icmp ne i64 %cv4965, 0
  br i1 %cond4966, label %bb_rcs1220, label %bb_rcspinslow1196
bb_rcs1220:
  %v4967 = load i64, ptr %slot70, align 8
  %p4969 = inttoptr i64 %v4967 to ptr
  %gep4970 = getelementptr i8, ptr %p4969, i64 88
  %op4968 = ptrtoint ptr %gep4970 to i64
  store i64 %op4968, ptr %slot733, align 8
  %v4971 = load i64, ptr %slot733, align 8
  %p4972 = inttoptr i64 %v4971 to ptr
  %ld4973 = load i64, ptr %p4972, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4973, ptr %slot734, align 8
  %v4974 = load i64, ptr %slot734, align 8
  %cmp4975 = icmp eq i64 %v4974, 0
  %cv4976 = zext i1 %cmp4975 to i32
  store i32 %cv4976, ptr %slot735, align 8
  %v4977 = load i64, ptr %slot731, align 8
  %v4978 = load i64, ptr %slot734, align 8
  %cmp4979 = icmp ule i64 %v4977, %v4978
  %cv4980 = zext i1 %cmp4979 to i32
  store i32 %cv4980, ptr %slot736, align 8
  %v4981 = load i32, ptr %slot735, align 8
  %v4982 = load i32, ptr %slot736, align 8
  %op4983 = or i32 %v4981, %v4982
  store i32 %op4983, ptr %slot737, align 8
  %v4984 = load i32, ptr %slot737, align 8
  %cv4985 = zext i32 %v4984 to i64
  %cond4986 = icmp ne i64 %cv4985, 0
  br i1 %cond4986, label %bb_rcs1226, label %bb_rcspinslow1196
bb_rcs1226:
  %v4987 = load i64, ptr %slot669, align 8
  %op4988 = sub i64 %v4987, 24
  store i64 %op4988, ptr %slot738, align 8
  %v4989 = load i64, ptr %slot669, align 8
  %p4990 = inttoptr i64 %v4989 to ptr
  %rgep4991 = getelementptr i8, ptr %p4990, i64 -24
  %ld4992 = load i64, ptr %rgep4991, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4992, ptr %slot739, align 8
  %v4993 = load i64, ptr %slot739, align 8
  %cmp4994 = icmp ne i64 %v4993, 18446744073709551615
  %cv4995 = zext i1 %cmp4994 to i32
  store i32 %cv4995, ptr %slot740, align 8
  %v4996 = load i32, ptr %slot740, align 8
  %cv4997 = zext i32 %v4996 to i64
  %cond4998 = icmp ne i64 %cv4997, 0
  br i1 %cond4998, label %bb_rcs1230, label %bb_rcspinslow1196
bb_rcs1230:
  %v4999 = load i64, ptr %slot669, align 8
  %op5000 = add i64 %v4999, 32
  store i64 %op5000, ptr %slot741, align 8
  %v5001 = load i64, ptr %slot741, align 8
  %p5002 = inttoptr i64 %v5001 to ptr
  %ld5003 = load i64, ptr %p5002, align 8
  store i64 %ld5003, ptr %slot742, align 8
  %v5004 = load i64, ptr %slot742, align 8
  %cmp5005 = icmp ne i64 %v5004, 0
  %cv5006 = zext i1 %cmp5005 to i32
  store i32 %cv5006, ptr %slot743, align 8
  %v5007 = load i32, ptr %slot743, align 8
  %cv5008 = zext i32 %v5007 to i64
  %cond5009 = icmp ne i64 %cv5008, 0
  br i1 %cond5009, label %bb_rcspinbacking1196, label %bb_rcspincommit1196
bb_rcspinbacking1196:
  %v5010 = load i64, ptr %slot742, align 8
  %op5011 = sub i64 %v5010, 16
  store i64 %op5011, ptr %slot744, align 8
  %v5012 = load i64, ptr %slot742, align 8
  %p5013 = inttoptr i64 %v5012 to ptr
  %rgep5014 = getelementptr i8, ptr %p5013, i64 -16
  %ld5015 = load i64, ptr %rgep5014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5015, ptr %slot745, align 8
  %v5016 = load i64, ptr %slot745, align 8
  %op5017 = and i64 %v5016, 4611686018427387907
  store i64 %op5017, ptr %slot746, align 8
  %v5018 = load i64, ptr %slot746, align 8
  %cmp5019 = icmp eq i64 %v5018, 0
  %cv5020 = zext i1 %cmp5019 to i32
  store i32 %cv5020, ptr %slot747, align 8
  %v5021 = load i32, ptr %slot747, align 8
  %cv5022 = zext i32 %v5021 to i64
  %cond5023 = icmp ne i64 %cv5022, 0
  br i1 %cond5023, label %bb_rcs1238, label %bb_rcspinslow1196
bb_rcs1238:
  %v5024 = load i64, ptr %slot742, align 8
  %op5025 = sub i64 %v5024, 24
  store i64 %op5025, ptr %slot748, align 8
  %v5026 = load i64, ptr %slot742, align 8
  %p5027 = inttoptr i64 %v5026 to ptr
  %rgep5028 = getelementptr i8, ptr %p5027, i64 -24
  %ld5029 = load i64, ptr %rgep5028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5029, ptr %slot749, align 8
  %v5030 = load i64, ptr %slot749, align 8
  %cmp5031 = icmp ne i64 %v5030, 18446744073709551615
  %cv5032 = zext i1 %cmp5031 to i32
  store i32 %cv5032, ptr %slot750, align 8
  %v5033 = load i32, ptr %slot750, align 8
  %cv5034 = zext i32 %v5033 to i64
  %cond5035 = icmp ne i64 %cv5034, 0
  br i1 %cond5035, label %bb_rcs1242, label %bb_rcspinslow1196
bb_rcs1242:
  br label %bb_rcspincommit1196
bb_rcspincommit1196:
  %v5036 = load i64, ptr %slot727, align 8
  %p5037 = inttoptr i64 %v5036 to ptr
  %ld5038 = load i64, ptr %p5037, align 8
  store i64 %ld5038, ptr %slot751, align 8
  %v5039 = load i64, ptr %slot725, align 8
  %op5040 = add i64 %v5039, 256
  store i64 %op5040, ptr %slot752, align 8
  %v5041 = load i64, ptr %slot751, align 8
  %v5042 = load i64, ptr %slot752, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  store i64 %v5041, ptr %p5043, align 8, !alias.scope !9999998, !noalias !9999999
  %v5044 = load i64, ptr %slot725, align 8
  %op5045 = add i64 %v5044, 264
  store i64 %op5045, ptr %slot753, align 8
  %v5046 = load i64, ptr %slot753, align 8
  %p5047 = inttoptr i64 %v5046 to ptr
  %ld5048 = load i64, ptr %p5047, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5048, ptr %slot754, align 8
  %v5049 = load i64, ptr %slot754, align 8
  %op5050 = add i64 %v5049, 18446744073709551615
  store i64 %op5050, ptr %slot755, align 8
  %v5051 = load i64, ptr %slot755, align 8
  %v5052 = load i64, ptr %slot753, align 8
  %p5053 = inttoptr i64 %v5052 to ptr
  store i64 %v5051, ptr %p5053, align 8, !alias.scope !9999998, !noalias !9999999
  %v5054 = load i64, ptr %slot70, align 8
  %p5056 = inttoptr i64 %v5054 to ptr
  %gep5057 = getelementptr i8, ptr %p5056, i64 24
  %op5055 = ptrtoint ptr %gep5057 to i64
  store i64 %op5055, ptr %slot756, align 8
  %v5058 = load i64, ptr %slot756, align 8
  %p5059 = inttoptr i64 %v5058 to ptr
  %ld5060 = load i64, ptr %p5059, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5060, ptr %slot757, align 8
  %v5061 = load i64, ptr %slot757, align 8
  %op5062 = add i64 %v5061, 40
  store i64 %op5062, ptr %slot758, align 8
  %v5063 = load i64, ptr %slot758, align 8
  %v5064 = load i64, ptr %slot756, align 8
  %p5065 = inttoptr i64 %v5064 to ptr
  store i64 %v5063, ptr %p5065, align 8, !alias.scope !9999998, !noalias !9999999
  %v5066 = load i64, ptr %slot725, align 8
  %op5067 = add i64 %v5066, 48
  store i64 %op5067, ptr %slot759, align 8
  %v5068 = load i64, ptr %slot759, align 8
  %p5069 = inttoptr i64 %v5068 to ptr
  %ld5070 = load i64, ptr %p5069, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5070, ptr %slot760, align 8
  %v5071 = load i64, ptr %slot760, align 8
  %op5072 = add i64 %v5071, 40
  store i64 %op5072, ptr %slot761, align 8
  %v5073 = load i64, ptr %slot761, align 8
  %v5074 = load i64, ptr %slot759, align 8
  %p5075 = inttoptr i64 %v5074 to ptr
  store i64 %v5073, ptr %p5075, align 8, !alias.scope !9999998, !noalias !9999999
  %v5076 = load i64, ptr %slot669, align 8
  %op5077 = sub i64 %v5076, 24
  store i64 %op5077, ptr %slot762, align 8
  %v5078 = load i64, ptr %slot669, align 8
  %p5079 = inttoptr i64 %v5078 to ptr
  %rgep5080 = getelementptr i8, ptr %p5079, i64 -24
  %ld5081 = load i64, ptr %rgep5080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5081, ptr %slot763, align 8
  %v5082 = load i64, ptr %slot763, align 8
  %op5083 = add i64 %v5082, 1
  store i64 %op5083, ptr %slot764, align 8
  %v5084 = load i64, ptr %slot764, align 8
  %v5085 = load i64, ptr %slot669, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  %rgep5087 = getelementptr i8, ptr %p5086, i64 -24
  store i64 %v5084, ptr %rgep5087, align 8, !alias.scope !9, !noalias !10
  %v5088 = load i64, ptr %slot742, align 8
  %cmp5089 = icmp ne i64 %v5088, 0
  %cv5090 = zext i1 %cmp5089 to i32
  store i32 %cv5090, ptr %slot765, align 8
  %v5091 = load i32, ptr %slot765, align 8
  %cv5092 = zext i32 %v5091 to i64
  %cond5093 = icmp ne i64 %cv5092, 0
  br i1 %cond5093, label %bb_rcspinhold1196, label %bb_rcspinjournal1196
bb_rcspinhold1196:
  %v5094 = load i64, ptr %slot742, align 8
  %op5095 = sub i64 %v5094, 24
  store i64 %op5095, ptr %slot766, align 8
  %v5096 = load i64, ptr %slot742, align 8
  %p5097 = inttoptr i64 %v5096 to ptr
  %rgep5098 = getelementptr i8, ptr %p5097, i64 -24
  %ld5099 = load i64, ptr %rgep5098, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5099, ptr %slot767, align 8
  %v5100 = load i64, ptr %slot767, align 8
  %op5101 = add i64 %v5100, 1
  store i64 %op5101, ptr %slot768, align 8
  %v5102 = load i64, ptr %slot768, align 8
  %v5103 = load i64, ptr %slot742, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  %rgep5105 = getelementptr i8, ptr %p5104, i64 -24
  store i64 %v5102, ptr %rgep5105, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal1196
bb_rcspinjournal1196:
  %v5106 = load i64, ptr %slot715, align 8
  %op5107 = and i64 %v5106, 1152921504606846976
  store i64 %op5107, ptr %slot769, align 8
  %v5108 = load i64, ptr %slot715, align 8
  %op5109 = or i64 %v5108, 1152921504606846976
  store i64 %op5109, ptr %slot770, align 8
  %v5110 = load i64, ptr %slot669, align 8
  %op5111 = sub i64 %v5110, 16
  store i64 %op5111, ptr %slot771, align 8
  %v5112 = load i64, ptr %slot770, align 8
  %v5113 = load i64, ptr %slot669, align 8
  %p5114 = inttoptr i64 %v5113 to ptr
  %rgep5115 = getelementptr i8, ptr %p5114, i64 -16
  store i64 %v5112, ptr %rgep5115, align 8, !alias.scope !9, !noalias !10
  %v5116 = load i64, ptr %slot702, align 8
  %p5118 = inttoptr i64 %v5116 to ptr
  %gep5119 = getelementptr i8, ptr %p5118, i64 16
  %op5117 = ptrtoint ptr %gep5119 to i64
  store i64 %op5117, ptr %slot772, align 8
  %v5120 = load i64, ptr %slot772, align 8
  %p5121 = inttoptr i64 %v5120 to ptr
  %ld5122 = load i64, ptr %p5121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5122, ptr %slot773, align 8
  %v5123 = load i64, ptr %slot727, align 8
  %op5124 = add i64 %v5123, 0
  store i64 %op5124, ptr %slot774, align 8
  %v5125 = load i64, ptr %slot773, align 8
  %v5126 = load i64, ptr %slot774, align 8
  %p5127 = inttoptr i64 %v5126 to ptr
  store i64 %v5125, ptr %p5127, align 8, !alias.scope !9999998, !noalias !9999999
  %v5128 = load i64, ptr %slot727, align 8
  %op5129 = add i64 %v5128, 8
  store i64 %op5129, ptr %slot775, align 8
  %v5130 = load i64, ptr %slot669, align 8
  %v5131 = load i64, ptr %slot775, align 8
  %p5132 = inttoptr i64 %v5131 to ptr
  store i64 %v5130, ptr %p5132, align 8, !alias.scope !9999998, !noalias !9999999
  %v5133 = load i64, ptr %slot727, align 8
  %op5134 = add i64 %v5133, 16
  store i64 %op5134, ptr %slot776, align 8
  %v5135 = load i64, ptr %slot769, align 8
  %v5136 = load i64, ptr %slot776, align 8
  %p5137 = inttoptr i64 %v5136 to ptr
  store i64 %v5135, ptr %p5137, align 8, !alias.scope !9999998, !noalias !9999999
  %v5138 = load i64, ptr %slot727, align 8
  %op5139 = add i64 %v5138, 24
  store i64 %op5139, ptr %slot777, align 8
  %v5140 = load i64, ptr %slot777, align 8
  %p5141 = inttoptr i64 %v5140 to ptr
  store i32 1, ptr %p5141, align 4, !alias.scope !9999998, !noalias !9999999
  %v5142 = load i64, ptr %slot727, align 8
  %op5143 = add i64 %v5142, 32
  store i64 %op5143, ptr %slot778, align 8
  %v5144 = load i64, ptr %slot742, align 8
  %v5145 = load i64, ptr %slot778, align 8
  %p5146 = inttoptr i64 %v5145 to ptr
  store i64 %v5144, ptr %p5146, align 8, !alias.scope !9999998, !noalias !9999999
  %v5147 = load i64, ptr %slot702, align 8
  %p5149 = inttoptr i64 %v5147 to ptr
  %gep5150 = getelementptr i8, ptr %p5149, i64 16
  %op5148 = ptrtoint ptr %gep5150 to i64
  store i64 %op5148, ptr %slot779, align 8
  %v5151 = load i64, ptr %slot727, align 8
  %v5152 = load i64, ptr %slot779, align 8
  %p5153 = inttoptr i64 %v5152 to ptr
  store i64 %v5151, ptr %p5153, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone1196
bb_rcspinslow1196:
  %v5154 = load i64, ptr %slot1, align 8
  %p5155 = inttoptr i64 %v5154 to ptr
  %v5156 = load i64, ptr %slot702, align 8
  %p5157 = inttoptr i64 %v5156 to ptr
  %v5158 = load i64, ptr %slot669, align 8
  %p5159 = inttoptr i64 %v5158 to ptr
  %call5160 = call i32 @myl_qbe_rc_scope_pin(ptr %p5155, ptr %p5157, ptr %p5159) nomerge, !dbg !152
  store i32 %call5160, ptr %slot780, align 8
  %v5161 = load i32, ptr %slot780, align 8
  %cv5162 = zext i32 %v5161 to i64
  %cond5163 = icmp ne i64 %cv5162, 0
  br i1 %cond5163, label %bb_rcunique1273, label %bb_failure
bb_rcunique1273:
  br label %bb_rcspindone1196
bb_rcspindone1196:
  %v5164 = load i64, ptr %slot669, align 8
  %v5165 = load i64, ptr %slot48, align 8
  %p5166 = inttoptr i64 %v5165 to ptr
  store i64 %v5164, ptr %p5166, align 8, !alias.scope !3, !noalias !4
  %v5167 = load i64, ptr %slot38, align 8
  %p5168 = inttoptr i64 %v5167 to ptr
  %ld5169 = load i64, ptr %p5168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5169, ptr %slot781, align 8
  %v5170 = load i64, ptr %slot781, align 8
  %v5171 = load i64, ptr %slot57, align 8
  %p5172 = inttoptr i64 %v5171 to ptr
  store i64 %v5170, ptr %p5172, align 8, !alias.scope !3, !noalias !4
  %v5173 = load i64, ptr %slot39, align 8
  %p5174 = inttoptr i64 %v5173 to ptr
  %ld5175 = load i64, ptr %p5174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5175, ptr %slot782, align 8
  %v5176 = load i64, ptr %slot782, align 8
  %v5177 = load i64, ptr %slot58, align 8
  %p5178 = inttoptr i64 %v5177 to ptr
  store i64 %v5176, ptr %p5178, align 8, !alias.scope !3, !noalias !4
  %v5179 = load i64, ptr %slot60, align 8
  store i64 %v5179, ptr %slot783, align 8
  %v5180 = load i64, ptr %slot71, align 8
  store i64 %v5180, ptr %slot784, align 8
  %v5181 = load i64, ptr %slot57, align 8
  store i64 %v5181, ptr %slot785, align 8
  %v5182 = load i64, ptr %slot783, align 8
  %p5184 = inttoptr i64 %v5182 to ptr
  %gep5185 = getelementptr i8, ptr %p5184, i64 0
  %op5183 = ptrtoint ptr %gep5185 to i64
  store i64 %op5183, ptr %slot786, align 8
  %v5186 = load i64, ptr %slot785, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  %ld5188 = load i64, ptr %p5187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5188, ptr %slot787, align 8
  %v5189 = load i64, ptr %slot787, align 8
  %v5190 = load i64, ptr %slot786, align 8
  %p5191 = inttoptr i64 %v5190 to ptr
  store i64 %v5189, ptr %p5191, align 8, !alias.scope !3, !noalias !4
  %v5192 = load i64, ptr %slot58, align 8
  store i64 %v5192, ptr %slot788, align 8
  %v5193 = load i64, ptr %slot783, align 8
  %p5195 = inttoptr i64 %v5193 to ptr
  %gep5196 = getelementptr i8, ptr %p5195, i64 8
  %op5194 = ptrtoint ptr %gep5196 to i64
  store i64 %op5194, ptr %slot789, align 8
  %v5197 = load i64, ptr %slot788, align 8
  %p5198 = inttoptr i64 %v5197 to ptr
  %ld5199 = load i8, ptr %p5198, align 1, !alias.scope !3, !noalias !4
  %ext5200 = zext i8 %ld5199 to i64
  store i64 %ext5200, ptr %slot790, align 8
  %v5201 = load i64, ptr %slot790, align 8
  %cv5202 = trunc i64 %v5201 to i8
  %v5203 = load i64, ptr %slot789, align 8
  %p5204 = inttoptr i64 %v5203 to ptr
  store i8 %cv5202, ptr %p5204, align 1, !alias.scope !3, !noalias !4
  %v5205 = load i64, ptr %slot783, align 8
  %v5206 = load i64, ptr %slot57, align 8
  %p5207 = inttoptr i64 %v5206 to ptr
  store i64 %v5205, ptr %p5207, align 8, !alias.scope !3, !noalias !4
  %v5208 = load i64, ptr %slot48, align 8
  %p5209 = inttoptr i64 %v5208 to ptr
  %ld5210 = load i64, ptr %p5209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5210, ptr %slot791, align 8
  %v5211 = load i64, ptr %slot57, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  %ld5213 = load i64, ptr %p5212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5213, ptr %slot792, align 8
  %v5214 = load i64, ptr %slot70, align 8
  %v5215 = load i64, ptr %slot791, align 8
  %v5216 = load i64, ptr %slot792, align 8
  %call5217 = call i32 @myl_t_c0235a2002b47316e7055cdcc9950d30a5168fa64698c21e07a3f1d907870193_rcg_list_append(i64 %v5214, i64 %v5215, i64 %v5216) nomerge, !dbg !154
  store i32 %call5217, ptr %slot793, align 8
  %v5218 = load i32, ptr %slot793, align 8
  %cv5219 = zext i32 %v5218 to i64
  %cond5220 = icmp ne i64 %cv5219, 0
  br i1 %cond5220, label %bb_success1287, label %bb_failed1287
bb_failed1287:
  %v5221 = load i64, ptr %slot1, align 8
  %p5222 = inttoptr i64 %v5221 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5222) nomerge, !dbg !154
  unreachable
bb_success1287:
  %v5223 = load i64, ptr %slot57, align 8
  %p5224 = inttoptr i64 %v5223 to ptr
  store i64 0, ptr %p5224, align 8, !alias.scope !3, !noalias !4
  %v5225 = load i64, ptr %slot29, align 8
  store i64 %v5225, ptr %slot794, align 8
  %v5226 = load i64, ptr %slot794, align 8
  %p5228 = inttoptr i64 %v5226 to ptr
  %gep5229 = getelementptr i8, ptr %p5228, i64 24
  %op5227 = ptrtoint ptr %gep5229 to i64
  store i64 %op5227, ptr %slot795, align 8
  %v5230 = load i64, ptr %slot795, align 8
  %p5231 = inttoptr i64 %v5230 to ptr
  %ld5232 = load i32, ptr %p5231, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5232, ptr %slot796, align 8
  %v5233 = load i32, ptr %slot796, align 8
  %cv5234 = zext i32 %v5233 to i64
  %cond5235 = icmp ne i64 %cv5234, 0
  br i1 %cond5235, label %bb_rcsendactive1289, label %bb_rcsenddone1289
bb_rcsendactive1289:
  %v5236 = load i64, ptr %slot70, align 8
  %p5238 = inttoptr i64 %v5236 to ptr
  %gep5239 = getelementptr i8, ptr %p5238, i64 5640
  %op5237 = ptrtoint ptr %gep5239 to i64
  store i64 %op5237, ptr %slot797, align 8
  %v5240 = load i64, ptr %slot797, align 8
  %p5241 = inttoptr i64 %v5240 to ptr
  %ld5242 = load i64, ptr %p5241, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5242, ptr %slot798, align 8
  %v5243 = load i64, ptr %slot798, align 8
  %op5244 = add i64 %v5243, 248
  store i64 %op5244, ptr %slot799, align 8
  %v5245 = load i64, ptr %slot799, align 8
  %p5246 = inttoptr i64 %v5245 to ptr
  %ld5247 = load i64, ptr %p5246, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5247, ptr %slot800, align 8
  %v5248 = load i64, ptr %slot800, align 8
  %v5249 = load i64, ptr %slot794, align 8
  %cmp5250 = icmp eq i64 %v5248, %v5249
  %cv5251 = zext i1 %cmp5250 to i32
  store i32 %cv5251, ptr %slot801, align 8
  %v5252 = load i32, ptr %slot801, align 8
  %cv5253 = zext i32 %v5252 to i64
  %cond5254 = icmp ne i64 %cv5253, 0
  br i1 %cond5254, label %bb_rcs1297, label %bb_rcsendslow1289
bb_rcs1297:
  %v5255 = load i64, ptr %slot798, align 8
  %op5256 = add i64 %v5255, 200
  store i64 %op5256, ptr %slot802, align 8
  %v5257 = load i64, ptr %slot802, align 8
  %p5258 = inttoptr i64 %v5257 to ptr
  %ld5259 = load i64, ptr %p5258, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5259, ptr %slot803, align 8
  %v5260 = load i64, ptr %slot803, align 8
  %cmp5261 = icmp eq i64 %v5260, 0
  %cv5262 = zext i1 %cmp5261 to i32
  store i32 %cv5262, ptr %slot804, align 8
  %v5263 = load i32, ptr %slot804, align 8
  %cv5264 = zext i32 %v5263 to i64
  %cond5265 = icmp ne i64 %cv5264, 0
  br i1 %cond5265, label %bb_rcs1301, label %bb_rcsendslow1289
bb_rcs1301:
  %v5266 = load i64, ptr %slot794, align 8
  %p5268 = inttoptr i64 %v5266 to ptr
  %gep5269 = getelementptr i8, ptr %p5268, i64 16
  %op5267 = ptrtoint ptr %gep5269 to i64
  store i64 %op5267, ptr %slot805, align 8
  %v5270 = load i64, ptr %slot805, align 8
  %p5271 = inttoptr i64 %v5270 to ptr
  %ld5272 = load i64, ptr %p5271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5272, ptr %slot806, align 8
  %v5273 = load i64, ptr %slot806, align 8
  %cmp5274 = icmp ne i64 %v5273, 0
  %cv5275 = zext i1 %cmp5274 to i32
  store i32 %cv5275, ptr %slot807, align 8
  %v5276 = load i32, ptr %slot807, align 8
  %cv5277 = zext i32 %v5276 to i64
  %cond5278 = icmp ne i64 %cv5277, 0
  br i1 %cond5278, label %bb_rcsendnode1289, label %bb_rcsendunlink1289
bb_rcsendnode1289:
  %v5279 = load i64, ptr %slot806, align 8
  %op5280 = add i64 %v5279, 0
  store i64 %op5280, ptr %slot808, align 8
  %v5281 = load i64, ptr %slot808, align 8
  %p5282 = inttoptr i64 %v5281 to ptr
  %ld5283 = load i64, ptr %p5282, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5283, ptr %slot809, align 8
  %v5284 = load i64, ptr %slot809, align 8
  %cmp5285 = icmp eq i64 %v5284, 0
  %cv5286 = zext i1 %cmp5285 to i32
  store i32 %cv5286, ptr %slot810, align 8
  %v5287 = load i32, ptr %slot810, align 8
  %cv5288 = zext i32 %v5287 to i64
  %cond5289 = icmp ne i64 %cv5288, 0
  br i1 %cond5289, label %bb_rcs1308, label %bb_rcsendslow1289
bb_rcs1308:
  %v5290 = load i64, ptr %slot798, align 8
  %op5291 = add i64 %v5290, 264
  store i64 %op5291, ptr %slot811, align 8
  %v5292 = load i64, ptr %slot811, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  %ld5294 = load i64, ptr %p5293, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5294, ptr %slot812, align 8
  %v5295 = load i64, ptr %slot812, align 8
  %cmp5296 = icmp ult i64 %v5295, 32
  %cv5297 = zext i1 %cmp5296 to i32
  store i32 %cv5297, ptr %slot813, align 8
  %v5298 = load i32, ptr %slot813, align 8
  %cv5299 = zext i32 %v5298 to i64
  %cond5300 = icmp ne i64 %cv5299, 0
  br i1 %cond5300, label %bb_rcs1312, label %bb_rcsendslow1289
bb_rcs1312:
  %v5301 = load i64, ptr %slot806, align 8
  %op5302 = add i64 %v5301, 8
  store i64 %op5302, ptr %slot814, align 8
  %v5303 = load i64, ptr %slot814, align 8
  %p5304 = inttoptr i64 %v5303 to ptr
  %ld5305 = load i64, ptr %p5304, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5305, ptr %slot815, align 8
  %v5306 = load i64, ptr %slot815, align 8
  %cmp5307 = icmp ne i64 %v5306, 0
  %cv5308 = zext i1 %cmp5307 to i32
  store i32 %cv5308, ptr %slot816, align 8
  %v5309 = load i32, ptr %slot816, align 8
  %cv5310 = zext i32 %v5309 to i64
  %cond5311 = icmp ne i64 %cv5310, 0
  br i1 %cond5311, label %bb_rcs1316, label %bb_rcsendslow1289
bb_rcs1316:
  %v5312 = load i64, ptr %slot815, align 8
  %op5313 = sub i64 %v5312, 16
  store i64 %op5313, ptr %slot817, align 8
  %v5314 = load i64, ptr %slot815, align 8
  %p5315 = inttoptr i64 %v5314 to ptr
  %rgep5316 = getelementptr i8, ptr %p5315, i64 -16
  %ld5317 = load i64, ptr %rgep5316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5317, ptr %slot818, align 8
  %v5318 = load i64, ptr %slot818, align 8
  %op5319 = and i64 %v5318, 4611686018427387907
  store i64 %op5319, ptr %slot819, align 8
  %v5320 = load i64, ptr %slot819, align 8
  %cmp5321 = icmp eq i64 %v5320, 0
  %cv5322 = zext i1 %cmp5321 to i32
  store i32 %cv5322, ptr %slot820, align 8
  %v5323 = load i32, ptr %slot820, align 8
  %cv5324 = zext i32 %v5323 to i64
  %cond5325 = icmp ne i64 %cv5324, 0
  br i1 %cond5325, label %bb_rcs1321, label %bb_rcsendslow1289
bb_rcs1321:
  %v5326 = load i64, ptr %slot815, align 8
  %op5327 = sub i64 %v5326, 24
  store i64 %op5327, ptr %slot821, align 8
  %v5328 = load i64, ptr %slot815, align 8
  %p5329 = inttoptr i64 %v5328 to ptr
  %rgep5330 = getelementptr i8, ptr %p5329, i64 -24
  %ld5331 = load i64, ptr %rgep5330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5331, ptr %slot822, align 8
  %v5332 = load i64, ptr %slot822, align 8
  %cmp5333 = icmp ne i64 %v5332, 0
  %cv5334 = zext i1 %cmp5333 to i32
  store i32 %cv5334, ptr %slot823, align 8
  %v5335 = load i32, ptr %slot823, align 8
  %cv5336 = zext i32 %v5335 to i64
  %cond5337 = icmp ne i64 %cv5336, 0
  br i1 %cond5337, label %bb_rcs1325, label %bb_rcsendslow1289
bb_rcs1325:
  %v5338 = load i64, ptr %slot815, align 8
  %op5339 = sub i64 %v5338, 32
  store i64 %op5339, ptr %slot824, align 8
  %v5340 = load i64, ptr %slot815, align 8
  %p5341 = inttoptr i64 %v5340 to ptr
  %rgep5342 = getelementptr i8, ptr %p5341, i64 -32
  %ld5343 = load i64, ptr %rgep5342, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5343, ptr %slot825, align 8
  %v5344 = load i64, ptr %slot822, align 8
  %cmp5345 = icmp ugt i64 %v5344, 1
  %cv5346 = zext i1 %cmp5345 to i32
  store i32 %cv5346, ptr %slot826, align 8
  %v5347 = load i64, ptr %slot825, align 8
  %cmp5348 = icmp ne i64 %v5347, 0
  %cv5349 = zext i1 %cmp5348 to i32
  store i32 %cv5349, ptr %slot827, align 8
  %v5350 = load i32, ptr %slot826, align 8
  %v5351 = load i32, ptr %slot827, align 8
  %op5352 = or i32 %v5350, %v5351
  store i32 %op5352, ptr %slot828, align 8
  %v5353 = load i32, ptr %slot828, align 8
  %cv5354 = zext i32 %v5353 to i64
  %cond5355 = icmp ne i64 %cv5354, 0
  br i1 %cond5355, label %bb_rcs1331, label %bb_rcsendslow1289
bb_rcs1331:
  %v5356 = load i64, ptr %slot806, align 8
  %op5357 = add i64 %v5356, 32
  store i64 %op5357, ptr %slot829, align 8
  %v5358 = load i64, ptr %slot829, align 8
  %p5359 = inttoptr i64 %v5358 to ptr
  %ld5360 = load i64, ptr %p5359, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5360, ptr %slot830, align 8
  %v5361 = load i64, ptr %slot830, align 8
  %cmp5362 = icmp ne i64 %v5361, 0
  %cv5363 = zext i1 %cmp5362 to i32
  store i32 %cv5363, ptr %slot831, align 8
  %v5364 = load i32, ptr %slot831, align 8
  %cv5365 = zext i32 %v5364 to i64
  %cond5366 = icmp ne i64 %cv5365, 0
  br i1 %cond5366, label %bb_rcsendbacking1289, label %bb_rcsendcommit1289
bb_rcsendbacking1289:
  %v5367 = load i64, ptr %slot830, align 8
  %op5368 = sub i64 %v5367, 16
  store i64 %op5368, ptr %slot832, align 8
  %v5369 = load i64, ptr %slot830, align 8
  %p5370 = inttoptr i64 %v5369 to ptr
  %rgep5371 = getelementptr i8, ptr %p5370, i64 -16
  %ld5372 = load i64, ptr %rgep5371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5372, ptr %slot833, align 8
  %v5373 = load i64, ptr %slot833, align 8
  %op5374 = and i64 %v5373, 4611686018427387907
  store i64 %op5374, ptr %slot834, align 8
  %v5375 = load i64, ptr %slot834, align 8
  %cmp5376 = icmp eq i64 %v5375, 0
  %cv5377 = zext i1 %cmp5376 to i32
  store i32 %cv5377, ptr %slot835, align 8
  %v5378 = load i32, ptr %slot835, align 8
  %cv5379 = zext i32 %v5378 to i64
  %cond5380 = icmp ne i64 %cv5379, 0
  br i1 %cond5380, label %bb_rcs1339, label %bb_rcsendslow1289
bb_rcs1339:
  %v5381 = load i64, ptr %slot830, align 8
  %op5382 = sub i64 %v5381, 24
  store i64 %op5382, ptr %slot836, align 8
  %v5383 = load i64, ptr %slot830, align 8
  %p5384 = inttoptr i64 %v5383 to ptr
  %rgep5385 = getelementptr i8, ptr %p5384, i64 -24
  %ld5386 = load i64, ptr %rgep5385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5386, ptr %slot837, align 8
  %v5387 = load i64, ptr %slot837, align 8
  %cmp5388 = icmp ne i64 %v5387, 0
  %cv5389 = zext i1 %cmp5388 to i32
  store i32 %cv5389, ptr %slot838, align 8
  %v5390 = load i32, ptr %slot838, align 8
  %cv5391 = zext i32 %v5390 to i64
  %cond5392 = icmp ne i64 %cv5391, 0
  br i1 %cond5392, label %bb_rcs1343, label %bb_rcsendslow1289
bb_rcs1343:
  %v5393 = load i64, ptr %slot830, align 8
  %op5394 = sub i64 %v5393, 32
  store i64 %op5394, ptr %slot839, align 8
  %v5395 = load i64, ptr %slot830, align 8
  %p5396 = inttoptr i64 %v5395 to ptr
  %rgep5397 = getelementptr i8, ptr %p5396, i64 -32
  %ld5398 = load i64, ptr %rgep5397, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5398, ptr %slot840, align 8
  %v5399 = load i64, ptr %slot837, align 8
  %cmp5400 = icmp ugt i64 %v5399, 1
  %cv5401 = zext i1 %cmp5400 to i32
  store i32 %cv5401, ptr %slot841, align 8
  %v5402 = load i64, ptr %slot840, align 8
  %cmp5403 = icmp ne i64 %v5402, 0
  %cv5404 = zext i1 %cmp5403 to i32
  store i32 %cv5404, ptr %slot842, align 8
  %v5405 = load i32, ptr %slot841, align 8
  %v5406 = load i32, ptr %slot842, align 8
  %op5407 = or i32 %v5405, %v5406
  store i32 %op5407, ptr %slot843, align 8
  %v5408 = load i32, ptr %slot843, align 8
  %cv5409 = zext i32 %v5408 to i64
  %cond5410 = icmp ne i64 %cv5409, 0
  br i1 %cond5410, label %bb_rcs1349, label %bb_rcsendslow1289
bb_rcs1349:
  br label %bb_rcsendcommit1289
bb_rcsendcommit1289:
  %v5411 = load i64, ptr %slot806, align 8
  %op5412 = add i64 %v5411, 24
  store i64 %op5412, ptr %slot844, align 8
  %v5413 = load i64, ptr %slot844, align 8
  %p5414 = inttoptr i64 %v5413 to ptr
  %ld5415 = load i32, ptr %p5414, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld5415, ptr %slot845, align 8
  %v5416 = load i32, ptr %slot845, align 8
  %cv5417 = zext i32 %v5416 to i64
  %cond5418 = icmp ne i64 %cv5417, 0
  br i1 %cond5418, label %bb_rcsendrestore1289, label %bb_rcsendreturned1289
bb_rcsendrestore1289:
  %v5419 = load i64, ptr %slot806, align 8
  %op5420 = add i64 %v5419, 16
  store i64 %op5420, ptr %slot846, align 8
  %v5421 = load i64, ptr %slot846, align 8
  %p5422 = inttoptr i64 %v5421 to ptr
  %ld5423 = load i64, ptr %p5422, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5423, ptr %slot847, align 8
  %v5424 = load i64, ptr %slot818, align 8
  %op5425 = and i64 %v5424, 17293822569102704639
  store i64 %op5425, ptr %slot848, align 8
  %v5426 = load i64, ptr %slot848, align 8
  %v5427 = load i64, ptr %slot847, align 8
  %op5428 = or i64 %v5426, %v5427
  store i64 %op5428, ptr %slot849, align 8
  %v5429 = load i64, ptr %slot815, align 8
  %op5430 = sub i64 %v5429, 16
  store i64 %op5430, ptr %slot850, align 8
  %v5431 = load i64, ptr %slot849, align 8
  %v5432 = load i64, ptr %slot815, align 8
  %p5433 = inttoptr i64 %v5432 to ptr
  %rgep5434 = getelementptr i8, ptr %p5433, i64 -16
  store i64 %v5431, ptr %rgep5434, align 8, !alias.scope !9, !noalias !10
  %v5435 = load i64, ptr %slot794, align 8
  %p5437 = inttoptr i64 %v5435 to ptr
  %gep5438 = getelementptr i8, ptr %p5437, i64 16
  %op5436 = ptrtoint ptr %gep5438 to i64
  store i64 %op5436, ptr %slot851, align 8
  br label %bb_rcsendreturned1289
bb_rcsendreturned1289:
  %v5439 = load i64, ptr %slot851, align 8
  %p5440 = inttoptr i64 %v5439 to ptr
  store i64 0, ptr %p5440, align 8, !alias.scope !3, !noalias !4
  %v5441 = load i64, ptr %slot798, align 8
  %op5442 = add i64 %v5441, 256
  store i64 %op5442, ptr %slot852, align 8
  %v5443 = load i64, ptr %slot852, align 8
  %p5444 = inttoptr i64 %v5443 to ptr
  %ld5445 = load i64, ptr %p5444, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5445, ptr %slot853, align 8
  %v5446 = load i64, ptr %slot806, align 8
  %op5447 = add i64 %v5446, 0
  store i64 %op5447, ptr %slot854, align 8
  %v5448 = load i64, ptr %slot853, align 8
  %v5449 = load i64, ptr %slot854, align 8
  %p5450 = inttoptr i64 %v5449 to ptr
  store i64 %v5448, ptr %p5450, align 8, !alias.scope !9999998, !noalias !9999999
  %v5451 = load i64, ptr %slot798, align 8
  %op5452 = add i64 %v5451, 256
  store i64 %op5452, ptr %slot855, align 8
  %v5453 = load i64, ptr %slot806, align 8
  %v5454 = load i64, ptr %slot855, align 8
  %p5455 = inttoptr i64 %v5454 to ptr
  store i64 %v5453, ptr %p5455, align 8, !alias.scope !9999998, !noalias !9999999
  %v5456 = load i64, ptr %slot798, align 8
  %op5457 = add i64 %v5456, 264
  store i64 %op5457, ptr %slot856, align 8
  %v5458 = load i64, ptr %slot856, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  %ld5460 = load i64, ptr %p5459, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5460, ptr %slot857, align 8
  %v5461 = load i64, ptr %slot857, align 8
  %op5462 = add i64 %v5461, 1
  store i64 %op5462, ptr %slot858, align 8
  %v5463 = load i64, ptr %slot858, align 8
  %v5464 = load i64, ptr %slot856, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i64 %v5463, ptr %p5465, align 8, !alias.scope !9999998, !noalias !9999999
  %v5466 = load i64, ptr %slot70, align 8
  %p5468 = inttoptr i64 %v5466 to ptr
  %gep5469 = getelementptr i8, ptr %p5468, i64 24
  %op5467 = ptrtoint ptr %gep5469 to i64
  store i64 %op5467, ptr %slot859, align 8
  %v5470 = load i64, ptr %slot859, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  %ld5472 = load i64, ptr %p5471, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5472, ptr %slot860, align 8
  %v5473 = load i64, ptr %slot860, align 8
  %op5474 = add i64 %v5473, 18446744073709551576
  store i64 %op5474, ptr %slot861, align 8
  %v5475 = load i64, ptr %slot861, align 8
  %v5476 = load i64, ptr %slot859, align 8
  %p5477 = inttoptr i64 %v5476 to ptr
  store i64 %v5475, ptr %p5477, align 8, !alias.scope !9999998, !noalias !9999999
  %v5478 = load i64, ptr %slot798, align 8
  %op5479 = add i64 %v5478, 48
  store i64 %op5479, ptr %slot862, align 8
  %v5480 = load i64, ptr %slot862, align 8
  %p5481 = inttoptr i64 %v5480 to ptr
  %ld5482 = load i64, ptr %p5481, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5482, ptr %slot863, align 8
  %v5483 = load i64, ptr %slot863, align 8
  %op5484 = add i64 %v5483, 18446744073709551576
  store i64 %op5484, ptr %slot864, align 8
  %v5485 = load i64, ptr %slot864, align 8
  %v5486 = load i64, ptr %slot862, align 8
  %p5487 = inttoptr i64 %v5486 to ptr
  store i64 %v5485, ptr %p5487, align 8, !alias.scope !9999998, !noalias !9999999
  %v5488 = load i64, ptr %slot830, align 8
  %cmp5489 = icmp ne i64 %v5488, 0
  %cv5490 = zext i1 %cmp5489 to i32
  store i32 %cv5490, ptr %slot865, align 8
  %v5491 = load i32, ptr %slot865, align 8
  %cv5492 = zext i32 %v5491 to i64
  %cond5493 = icmp ne i64 %cv5492, 0
  br i1 %cond5493, label %bb_rcsenddropbacking1289, label %bb_rcsenddroppayload1289
bb_rcsenddropbacking1289:
  %v5494 = load i64, ptr %slot830, align 8
  %op5495 = sub i64 %v5494, 24
  store i64 %op5495, ptr %slot866, align 8
  %v5496 = load i64, ptr %slot830, align 8
  %p5497 = inttoptr i64 %v5496 to ptr
  %rgep5498 = getelementptr i8, ptr %p5497, i64 -24
  %ld5499 = load i64, ptr %rgep5498, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5499, ptr %slot867, align 8
  %v5500 = load i64, ptr %slot867, align 8
  %op5501 = add i64 %v5500, 18446744073709551615
  store i64 %op5501, ptr %slot868, align 8
  %v5502 = load i64, ptr %slot868, align 8
  %v5503 = load i64, ptr %slot830, align 8
  %p5504 = inttoptr i64 %v5503 to ptr
  %rgep5505 = getelementptr i8, ptr %p5504, i64 -24
  store i64 %v5502, ptr %rgep5505, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload1289
bb_rcsenddroppayload1289:
  %v5506 = load i64, ptr %slot815, align 8
  %op5507 = sub i64 %v5506, 24
  store i64 %op5507, ptr %slot869, align 8
  %v5508 = load i64, ptr %slot815, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  %rgep5510 = getelementptr i8, ptr %p5509, i64 -24
  %ld5511 = load i64, ptr %rgep5510, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5511, ptr %slot870, align 8
  %v5512 = load i64, ptr %slot870, align 8
  %op5513 = add i64 %v5512, 18446744073709551615
  store i64 %op5513, ptr %slot871, align 8
  %v5514 = load i64, ptr %slot871, align 8
  %v5515 = load i64, ptr %slot815, align 8
  %p5516 = inttoptr i64 %v5515 to ptr
  %rgep5517 = getelementptr i8, ptr %p5516, i64 -24
  store i64 %v5514, ptr %rgep5517, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink1289
bb_rcsendunlink1289:
  %v5518 = load i64, ptr %slot794, align 8
  %p5520 = inttoptr i64 %v5518 to ptr
  %gep5521 = getelementptr i8, ptr %p5520, i64 8
  %op5519 = ptrtoint ptr %gep5521 to i64
  store i64 %op5519, ptr %slot872, align 8
  %v5522 = load i64, ptr %slot872, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  %ld5524 = load i64, ptr %p5523, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5524, ptr %slot873, align 8
  %v5525 = load i64, ptr %slot798, align 8
  %op5526 = add i64 %v5525, 248
  store i64 %op5526, ptr %slot874, align 8
  %v5527 = load i64, ptr %slot873, align 8
  %v5528 = load i64, ptr %slot874, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  store i64 %v5527, ptr %p5529, align 8, !alias.scope !9999998, !noalias !9999999
  %v5530 = load i64, ptr %slot794, align 8
  %p5532 = inttoptr i64 %v5530 to ptr
  %gep5533 = getelementptr i8, ptr %p5532, i64 24
  %op5531 = ptrtoint ptr %gep5533 to i64
  store i64 %op5531, ptr %slot875, align 8
  %v5534 = load i64, ptr %slot794, align 8
  %p5536 = inttoptr i64 %v5534 to ptr
  %gep5537 = getelementptr i8, ptr %p5536, i64 8
  %op5535 = ptrtoint ptr %gep5537 to i64
  store i64 %op5535, ptr %slot876, align 8
  %v5538 = load i64, ptr %slot875, align 8
  %p5539 = inttoptr i64 %v5538 to ptr
  store i32 0, ptr %p5539, align 4, !alias.scope !3, !noalias !4
  %v5540 = load i64, ptr %slot876, align 8
  %p5541 = inttoptr i64 %v5540 to ptr
  store i64 0, ptr %p5541, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone1289
bb_rcsendslow1289:
  %v5542 = load i64, ptr %slot1, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  %v5544 = load i64, ptr %slot794, align 8
  %p5545 = inttoptr i64 %v5544 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p5543, ptr %p5545) nomerge, !dbg !154
  br label %bb_rcsenddone1289
bb_rcsenddone1289:
  %v5546 = load i64, ptr %slot43, align 8
  %p5547 = inttoptr i64 %v5546 to ptr
  %ld5548 = load i64, ptr %p5547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5548, ptr %slot877, align 8
  %v5549 = load i64, ptr %slot877, align 8
  %v5550 = load i64, ptr %slot57, align 8
  %p5551 = inttoptr i64 %v5550 to ptr
  store i64 %v5549, ptr %p5551, align 8, !alias.scope !3, !noalias !4
  %v5552 = load i64, ptr %slot58, align 8
  %p5553 = inttoptr i64 %v5552 to ptr
  store i64 1, ptr %p5553, align 8, !alias.scope !3, !noalias !4
  %v5554 = load i64, ptr %slot58, align 8
  %p5555 = inttoptr i64 %v5554 to ptr
  %ld5556 = load i64, ptr %p5555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5556, ptr %slot878, align 8
  %v5557 = load i64, ptr %slot57, align 8
  %p5558 = inttoptr i64 %v5557 to ptr
  %ld5559 = load i64, ptr %p5558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5559, ptr %slot879, align 8
  %v5560 = load i64, ptr %slot879, align 8
  %v5561 = load i64, ptr %slot878, align 8
  %ovpair5563 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5560, i64 %v5561)
  %op5562 = extractvalue { i64, i1 } %ovpair5563, 0
  %ov5564 = extractvalue { i64, i1 } %ovpair5563, 1
  store i64 %op5562, ptr %slot880, align 8
  %cv5565 = zext i1 %ov5564 to i64
  store i64 %cv5565, ptr %slot881, align 8
  %v5566 = load i64, ptr %slot881, align 8
  %cond5567 = icmp ne i64 %v5566, 0
  br i1 %cond5567, label %bb_overflow1386, label %bb_checked1386
bb_overflow1386:
  %v5568 = load i64, ptr %slot1, align 8
  %p5569 = inttoptr i64 %v5568 to ptr
  %v5570 = load i64, ptr %slot879, align 8
  %v5571 = load i64, ptr %slot878, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5569, i64 0, i64 %v5570, i64 %v5571, i64 64) nomerge, !dbg !156
  unreachable
bb_checked1386:
  %v5572 = load i64, ptr %slot880, align 8
  %v5573 = load i64, ptr %slot57, align 8
  %p5574 = inttoptr i64 %v5573 to ptr
  store i64 %v5572, ptr %p5574, align 8, !alias.scope !3, !noalias !4
  %v5575 = load i64, ptr %slot57, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  %ld5577 = load i64, ptr %p5576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5577, ptr %slot882, align 8
  %v5578 = load i64, ptr %slot882, align 8
  %v5579 = load i64, ptr %slot50, align 8
  %p5580 = inttoptr i64 %v5579 to ptr
  store i64 %v5578, ptr %p5580, align 8, !alias.scope !3, !noalias !4
  %v5581 = load i64, ptr %slot42, align 8
  %v5582 = load i64, ptr %slot57, align 8
  %p5583 = inttoptr i64 %v5582 to ptr
  store i64 %v5581, ptr %p5583, align 8, !alias.scope !3, !noalias !4
  %v5584 = load i64, ptr %slot57, align 8
  %p5585 = inttoptr i64 %v5584 to ptr
  %ld5586 = load i64, ptr %p5585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5586, ptr %slot883, align 8
  %v5587 = load i64, ptr %slot17, align 8
  %p5588 = inttoptr i64 %v5587 to ptr
  %ld5589 = load i32, ptr %p5588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5589, ptr %slot884, align 8
  %v5590 = load i64, ptr %slot18, align 8
  %p5591 = inttoptr i64 %v5590 to ptr
  %ld5592 = load i32, ptr %p5591, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5592, ptr %slot885, align 8
  %v5593 = load i32, ptr %slot885, align 8
  %op5594 = and i32 %v5593, 24
  store i32 %op5594, ptr %slot885, align 8
  %v5595 = load i32, ptr %slot885, align 8
  %cmp5596 = icmp eq i32 %v5595, 0
  %cv5597 = zext i1 %cmp5596 to i32
  store i32 %cv5597, ptr %slot886, align 8
  %v5598 = load i32, ptr %slot884, align 8
  %v5599 = load i32, ptr %slot886, align 8
  %op5600 = and i32 %v5598, %v5599
  store i32 %op5600, ptr %slot887, align 8
  %v5601 = load i32, ptr %slot887, align 8
  %cv5602 = zext i32 %v5601 to i64
  %cond5603 = icmp ne i64 %cv5602, 0
  br i1 %cond5603, label %bb_rcprivateown1396, label %bb_rcprivateloan1396
bb_rcprivateown1396:
  %v5604 = load i64, ptr %slot28, align 8
  store i64 %v5604, ptr %slot888, align 8
  %v5605 = load i64, ptr %slot71, align 8
  store i64 %v5605, ptr %slot889, align 8
  %v5606 = load i64, ptr %slot70, align 8
  %v5607 = load i64, ptr %slot888, align 8
  %v5608 = load i64, ptr %slot883, align 8
  %v5609 = load i64, ptr %slot889, align 8
  %cv5610 = trunc i64 %v5609 to i32
  %call5611 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v5606, i64 %v5607, i64 %v5608, i32 %cv5610) nomerge, !dbg !158
  store i32 %call5611, ptr %slot890, align 8
  %v5612 = load i32, ptr %slot890, align 8
  %cv5613 = zext i32 %v5612 to i64
  %cond5614 = icmp ne i64 %cv5613, 0
  br i1 %cond5614, label %bb_rcsuccess1400, label %bb_rcfailure1400
bb_rcfailure1400:
  %v5615 = load i64, ptr %slot70, align 8
  %p5616 = inttoptr i64 %v5615 to ptr
  %call5617 = call i32 @myl_rc_take_failure(ptr %p5616) nomerge, !dbg !158
  store i32 %call5617, ptr %slot891, align 8
  %v5618 = load i64, ptr %slot1, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  %v5620 = load i32, ptr %slot891, align 8
  %call5621 = call i32 @myl_qbe_rc_status(ptr %p5619, i32 %v5620) nomerge, !dbg !158
  store i32 %call5621, ptr %slot892, align 8
  br label %bb_failure
bb_rcsuccess1400:
  %v5622 = load i64, ptr %slot17, align 8
  %p5623 = inttoptr i64 %v5622 to ptr
  store i32 0, ptr %p5623, align 4, !alias.scope !3, !noalias !4
  %v5624 = load i64, ptr %slot22, align 8
  %p5625 = inttoptr i64 %v5624 to ptr
  store i32 2, ptr %p5625, align 4, !alias.scope !3, !noalias !4
  %v5626 = load i64, ptr %slot21, align 8
  %p5627 = inttoptr i64 %v5626 to ptr
  store i32 1, ptr %p5627, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1396
bb_rcprivateloan1396:
  %v5628 = load i64, ptr %slot28, align 8
  store i64 %v5628, ptr %slot893, align 8
  %v5629 = load i64, ptr %slot70, align 8
  %v5630 = load i64, ptr %slot893, align 8
  %v5631 = load i64, ptr %slot883, align 8
  %call5632 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v5629, i64 %v5630, i64 %v5631) nomerge, !dbg !158
  store i32 %call5632, ptr %slot894, align 8
  %v5633 = load i32, ptr %slot894, align 8
  %cv5634 = zext i32 %v5633 to i64
  %cond5635 = icmp ne i64 %cv5634, 0
  br i1 %cond5635, label %bb_rcsuccess1408, label %bb_rcfailure1408
bb_rcfailure1408:
  %v5636 = load i64, ptr %slot70, align 8
  %p5637 = inttoptr i64 %v5636 to ptr
  %call5638 = call i32 @myl_rc_take_failure(ptr %p5637) nomerge, !dbg !158
  store i32 %call5638, ptr %slot895, align 8
  %v5639 = load i64, ptr %slot1, align 8
  %p5640 = inttoptr i64 %v5639 to ptr
  %v5641 = load i32, ptr %slot895, align 8
  %call5642 = call i32 @myl_qbe_rc_status(ptr %p5640, i32 %v5641) nomerge, !dbg !158
  store i32 %call5642, ptr %slot896, align 8
  br label %bb_failure
bb_rcsuccess1408:
  %v5643 = load i64, ptr %slot22, align 8
  %p5644 = inttoptr i64 %v5643 to ptr
  store i32 2, ptr %p5644, align 4, !alias.scope !3, !noalias !4
  %v5645 = load i64, ptr %slot22, align 8
  %p5646 = inttoptr i64 %v5645 to ptr
  store i32 16, ptr %p5646, align 4, !alias.scope !3, !noalias !4
  %v5647 = load i64, ptr %slot21, align 8
  %p5648 = inttoptr i64 %v5647 to ptr
  store i32 1, ptr %p5648, align 4, !alias.scope !3, !noalias !4
  %v5649 = load i64, ptr %slot17, align 8
  %p5650 = inttoptr i64 %v5649 to ptr
  %ld5651 = load i32, ptr %p5650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5651, ptr %slot897, align 8
  %v5652 = load i32, ptr %slot897, align 8
  %cv5653 = zext i32 %v5652 to i64
  %cond5654 = icmp ne i64 %cv5653, 0
  br i1 %cond5654, label %bb_rcslotdrop1416, label %bb_rcslotdone1416
bb_rcslotdrop1416:
  %v5655 = load i64, ptr %slot17, align 8
  %p5656 = inttoptr i64 %v5655 to ptr
  store i32 0, ptr %p5656, align 4, !alias.scope !3, !noalias !4
  %v5657 = load i64, ptr %slot24, align 8
  store i64 %v5657, ptr %slot898, align 8
  %v5658 = load i64, ptr %slot18, align 8
  %p5659 = inttoptr i64 %v5658 to ptr
  %ld5660 = load i32, ptr %p5659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5660, ptr %slot899, align 8
  %v5661 = load i32, ptr %slot899, align 8
  %op5662 = and i32 %v5661, 28
  store i32 %op5662, ptr %slot900, align 8
  %v5663 = load i32, ptr %slot900, align 8
  %cv5664 = zext i32 %v5663 to i64
  %cond5665 = icmp ne i64 %cv5664, 0
  br i1 %cond5665, label %bb_rcslotrole1416, label %bb_rcslotowner1416
bb_rcslotrole1416:
  %v5666 = load i64, ptr %slot70, align 8
  store i64 %v5666, ptr %slot901, align 8
  %v5667 = load i64, ptr %slot901, align 8
  %v5668 = load i64, ptr %slot898, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5667, i64 %v5668) nomerge, !dbg !158
  br label %bb_rcslotdone1416
bb_rcslotowner1416:
  %v5669 = load i64, ptr %slot70, align 8
  store i64 %v5669, ptr %slot902, align 8
  %v5670 = load i64, ptr %slot902, align 8
  %v5671 = load i64, ptr %slot898, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5670, i64 %v5671) nomerge, !dbg !158
  br label %bb_rcslotdone1416
bb_rcslotdone1416:
  br label %bb_rcprivateprepared1396
bb_rcprivateprepared1396:
  %v5672 = load i64, ptr %slot11, align 8
  %p5673 = inttoptr i64 %v5672 to ptr
  %ld5674 = load i32, ptr %p5673, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5674, ptr %slot903, align 8
  %v5675 = load i32, ptr %slot903, align 8
  %cv5676 = zext i32 %v5675 to i64
  %cond5677 = icmp ne i64 %cv5676, 0
  br i1 %cond5677, label %bb_rcslotdrop1426, label %bb_rcslotdone1426
bb_rcslotdrop1426:
  %v5678 = load i64, ptr %slot11, align 8
  %p5679 = inttoptr i64 %v5678 to ptr
  store i32 0, ptr %p5679, align 4, !alias.scope !3, !noalias !4
  %v5680 = load i64, ptr %slot49, align 8
  store i64 %v5680, ptr %slot904, align 8
  %v5681 = load i64, ptr %slot12, align 8
  %p5682 = inttoptr i64 %v5681 to ptr
  %ld5683 = load i32, ptr %p5682, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5683, ptr %slot905, align 8
  %v5684 = load i32, ptr %slot905, align 8
  %op5685 = and i32 %v5684, 28
  store i32 %op5685, ptr %slot906, align 8
  %v5686 = load i32, ptr %slot906, align 8
  %cv5687 = zext i32 %v5686 to i64
  %cond5688 = icmp ne i64 %cv5687, 0
  br i1 %cond5688, label %bb_rcslotrole1426, label %bb_rcslotowner1426
bb_rcslotrole1426:
  %v5689 = load i64, ptr %slot70, align 8
  store i64 %v5689, ptr %slot907, align 8
  %v5690 = load i64, ptr %slot907, align 8
  %v5691 = load i64, ptr %slot904, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5690, i64 %v5691) nomerge, !dbg !158
  br label %bb_rcslotdone1426
bb_rcslotowner1426:
  %v5692 = load i64, ptr %slot70, align 8
  store i64 %v5692, ptr %slot908, align 8
  %v5693 = load i64, ptr %slot908, align 8
  %v5694 = load i64, ptr %slot904, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5693, i64 %v5694) nomerge, !dbg !158
  br label %bb_rcslotdone1426
bb_rcslotdone1426:
  %v5695 = load i64, ptr %slot49, align 8
  store i64 %v5695, ptr %slot909, align 8
  %v5696 = load i64, ptr %slot28, align 8
  store i64 %v5696, ptr %slot910, align 8
  %v5697 = load i64, ptr %slot910, align 8
  %v5698 = load i64, ptr %slot909, align 8
  %p5699 = inttoptr i64 %v5697 to ptr
  %p5700 = inttoptr i64 %v5698 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5700, ptr %p5699, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v5701 = load i64, ptr %slot21, align 8
  %p5702 = inttoptr i64 %v5701 to ptr
  store i32 0, ptr %p5702, align 4, !alias.scope !3, !noalias !4
  %v5703 = load i64, ptr %slot12, align 8
  %p5704 = inttoptr i64 %v5703 to ptr
  store i32 2, ptr %p5704, align 4, !alias.scope !3, !noalias !4
  %v5705 = load i64, ptr %slot22, align 8
  %p5706 = inttoptr i64 %v5705 to ptr
  %ld5707 = load i32, ptr %p5706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5707, ptr %slot911, align 8
  %v5708 = load i32, ptr %slot911, align 8
  %v5709 = load i64, ptr %slot12, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  store i32 %v5708, ptr %p5710, align 4, !alias.scope !3, !noalias !4
  %v5711 = load i64, ptr %slot11, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  store i32 1, ptr %p5712, align 4, !alias.scope !3, !noalias !4
  %v5713 = load i64, ptr %slot42, align 8
  %v5714 = load i64, ptr %slot57, align 8
  %p5715 = inttoptr i64 %v5714 to ptr
  store i64 %v5713, ptr %p5715, align 8, !alias.scope !3, !noalias !4
  %v5716 = load i64, ptr %slot57, align 8
  %p5717 = inttoptr i64 %v5716 to ptr
  %ld5718 = load i64, ptr %p5717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5718, ptr %slot912, align 8
  %v5719 = load i64, ptr %slot17, align 8
  %p5720 = inttoptr i64 %v5719 to ptr
  %ld5721 = load i32, ptr %p5720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5721, ptr %slot913, align 8
  %v5722 = load i64, ptr %slot18, align 8
  %p5723 = inttoptr i64 %v5722 to ptr
  %ld5724 = load i32, ptr %p5723, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5724, ptr %slot914, align 8
  %v5725 = load i32, ptr %slot914, align 8
  %op5726 = and i32 %v5725, 24
  store i32 %op5726, ptr %slot914, align 8
  %v5727 = load i32, ptr %slot914, align 8
  %cmp5728 = icmp eq i32 %v5727, 0
  %cv5729 = zext i1 %cmp5728 to i32
  store i32 %cv5729, ptr %slot915, align 8
  %v5730 = load i32, ptr %slot913, align 8
  %v5731 = load i32, ptr %slot915, align 8
  %op5732 = and i32 %v5730, %v5731
  store i32 %op5732, ptr %slot916, align 8
  %v5733 = load i32, ptr %slot916, align 8
  %cv5734 = zext i32 %v5733 to i64
  %cond5735 = icmp ne i64 %cv5734, 0
  br i1 %cond5735, label %bb_rcprivateown1447, label %bb_rcprivateloan1447
bb_rcprivateown1447:
  %v5736 = load i64, ptr %slot28, align 8
  store i64 %v5736, ptr %slot917, align 8
  %v5737 = load i64, ptr %slot71, align 8
  store i64 %v5737, ptr %slot918, align 8
  %v5738 = load i64, ptr %slot70, align 8
  %v5739 = load i64, ptr %slot917, align 8
  %v5740 = load i64, ptr %slot912, align 8
  %v5741 = load i64, ptr %slot918, align 8
  %cv5742 = trunc i64 %v5741 to i32
  %call5743 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v5738, i64 %v5739, i64 %v5740, i32 %cv5742) nomerge, !dbg !160
  store i32 %call5743, ptr %slot919, align 8
  %v5744 = load i32, ptr %slot919, align 8
  %cv5745 = zext i32 %v5744 to i64
  %cond5746 = icmp ne i64 %cv5745, 0
  br i1 %cond5746, label %bb_rcsuccess1451, label %bb_rcfailure1451
bb_rcfailure1451:
  %v5747 = load i64, ptr %slot70, align 8
  %p5748 = inttoptr i64 %v5747 to ptr
  %call5749 = call i32 @myl_rc_take_failure(ptr %p5748) nomerge, !dbg !160
  store i32 %call5749, ptr %slot920, align 8
  %v5750 = load i64, ptr %slot1, align 8
  %p5751 = inttoptr i64 %v5750 to ptr
  %v5752 = load i32, ptr %slot920, align 8
  %call5753 = call i32 @myl_qbe_rc_status(ptr %p5751, i32 %v5752) nomerge, !dbg !160
  store i32 %call5753, ptr %slot921, align 8
  br label %bb_failure
bb_rcsuccess1451:
  %v5754 = load i64, ptr %slot17, align 8
  %p5755 = inttoptr i64 %v5754 to ptr
  store i32 0, ptr %p5755, align 4, !alias.scope !3, !noalias !4
  %v5756 = load i64, ptr %slot22, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  store i32 2, ptr %p5757, align 4, !alias.scope !3, !noalias !4
  %v5758 = load i64, ptr %slot21, align 8
  %p5759 = inttoptr i64 %v5758 to ptr
  store i32 1, ptr %p5759, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1447
bb_rcprivateloan1447:
  %v5760 = load i64, ptr %slot28, align 8
  store i64 %v5760, ptr %slot922, align 8
  %v5761 = load i64, ptr %slot70, align 8
  %v5762 = load i64, ptr %slot922, align 8
  %v5763 = load i64, ptr %slot912, align 8
  %call5764 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v5761, i64 %v5762, i64 %v5763) nomerge, !dbg !160
  store i32 %call5764, ptr %slot923, align 8
  %v5765 = load i32, ptr %slot923, align 8
  %cv5766 = zext i32 %v5765 to i64
  %cond5767 = icmp ne i64 %cv5766, 0
  br i1 %cond5767, label %bb_rcsuccess1459, label %bb_rcfailure1459
bb_rcfailure1459:
  %v5768 = load i64, ptr %slot70, align 8
  %p5769 = inttoptr i64 %v5768 to ptr
  %call5770 = call i32 @myl_rc_take_failure(ptr %p5769) nomerge, !dbg !160
  store i32 %call5770, ptr %slot924, align 8
  %v5771 = load i64, ptr %slot1, align 8
  %p5772 = inttoptr i64 %v5771 to ptr
  %v5773 = load i32, ptr %slot924, align 8
  %call5774 = call i32 @myl_qbe_rc_status(ptr %p5772, i32 %v5773) nomerge, !dbg !160
  store i32 %call5774, ptr %slot925, align 8
  br label %bb_failure
bb_rcsuccess1459:
  %v5775 = load i64, ptr %slot22, align 8
  %p5776 = inttoptr i64 %v5775 to ptr
  store i32 2, ptr %p5776, align 4, !alias.scope !3, !noalias !4
  %v5777 = load i64, ptr %slot22, align 8
  %p5778 = inttoptr i64 %v5777 to ptr
  store i32 16, ptr %p5778, align 4, !alias.scope !3, !noalias !4
  %v5779 = load i64, ptr %slot21, align 8
  %p5780 = inttoptr i64 %v5779 to ptr
  store i32 1, ptr %p5780, align 4, !alias.scope !3, !noalias !4
  %v5781 = load i64, ptr %slot17, align 8
  %p5782 = inttoptr i64 %v5781 to ptr
  %ld5783 = load i32, ptr %p5782, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5783, ptr %slot926, align 8
  %v5784 = load i32, ptr %slot926, align 8
  %cv5785 = zext i32 %v5784 to i64
  %cond5786 = icmp ne i64 %cv5785, 0
  br i1 %cond5786, label %bb_rcslotdrop1467, label %bb_rcslotdone1467
bb_rcslotdrop1467:
  %v5787 = load i64, ptr %slot17, align 8
  %p5788 = inttoptr i64 %v5787 to ptr
  store i32 0, ptr %p5788, align 4, !alias.scope !3, !noalias !4
  %v5789 = load i64, ptr %slot24, align 8
  store i64 %v5789, ptr %slot927, align 8
  %v5790 = load i64, ptr %slot18, align 8
  %p5791 = inttoptr i64 %v5790 to ptr
  %ld5792 = load i32, ptr %p5791, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5792, ptr %slot928, align 8
  %v5793 = load i32, ptr %slot928, align 8
  %op5794 = and i32 %v5793, 28
  store i32 %op5794, ptr %slot929, align 8
  %v5795 = load i32, ptr %slot929, align 8
  %cv5796 = zext i32 %v5795 to i64
  %cond5797 = icmp ne i64 %cv5796, 0
  br i1 %cond5797, label %bb_rcslotrole1467, label %bb_rcslotowner1467
bb_rcslotrole1467:
  %v5798 = load i64, ptr %slot70, align 8
  store i64 %v5798, ptr %slot930, align 8
  %v5799 = load i64, ptr %slot930, align 8
  %v5800 = load i64, ptr %slot927, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5799, i64 %v5800) nomerge, !dbg !160
  br label %bb_rcslotdone1467
bb_rcslotowner1467:
  %v5801 = load i64, ptr %slot70, align 8
  store i64 %v5801, ptr %slot931, align 8
  %v5802 = load i64, ptr %slot931, align 8
  %v5803 = load i64, ptr %slot927, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5802, i64 %v5803) nomerge, !dbg !160
  br label %bb_rcslotdone1467
bb_rcslotdone1467:
  br label %bb_rcprivateprepared1447
bb_rcprivateprepared1447:
  %v5804 = load i64, ptr %slot11, align 8
  %p5805 = inttoptr i64 %v5804 to ptr
  %ld5806 = load i32, ptr %p5805, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5806, ptr %slot932, align 8
  %v5807 = load i32, ptr %slot932, align 8
  %cv5808 = zext i32 %v5807 to i64
  %cond5809 = icmp ne i64 %cv5808, 0
  br i1 %cond5809, label %bb_rcslotdrop1477, label %bb_rcslotdone1477
bb_rcslotdrop1477:
  %v5810 = load i64, ptr %slot11, align 8
  %p5811 = inttoptr i64 %v5810 to ptr
  store i32 0, ptr %p5811, align 4, !alias.scope !3, !noalias !4
  %v5812 = load i64, ptr %slot49, align 8
  store i64 %v5812, ptr %slot933, align 8
  %v5813 = load i64, ptr %slot12, align 8
  %p5814 = inttoptr i64 %v5813 to ptr
  %ld5815 = load i32, ptr %p5814, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5815, ptr %slot934, align 8
  %v5816 = load i32, ptr %slot934, align 8
  %op5817 = and i32 %v5816, 28
  store i32 %op5817, ptr %slot935, align 8
  %v5818 = load i32, ptr %slot935, align 8
  %cv5819 = zext i32 %v5818 to i64
  %cond5820 = icmp ne i64 %cv5819, 0
  br i1 %cond5820, label %bb_rcslotrole1477, label %bb_rcslotowner1477
bb_rcslotrole1477:
  %v5821 = load i64, ptr %slot70, align 8
  store i64 %v5821, ptr %slot936, align 8
  %v5822 = load i64, ptr %slot936, align 8
  %v5823 = load i64, ptr %slot933, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5822, i64 %v5823) nomerge, !dbg !160
  br label %bb_rcslotdone1477
bb_rcslotowner1477:
  %v5824 = load i64, ptr %slot70, align 8
  store i64 %v5824, ptr %slot937, align 8
  %v5825 = load i64, ptr %slot937, align 8
  %v5826 = load i64, ptr %slot933, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5825, i64 %v5826) nomerge, !dbg !160
  br label %bb_rcslotdone1477
bb_rcslotdone1477:
  %v5827 = load i64, ptr %slot49, align 8
  store i64 %v5827, ptr %slot938, align 8
  %v5828 = load i64, ptr %slot28, align 8
  store i64 %v5828, ptr %slot939, align 8
  %v5829 = load i64, ptr %slot939, align 8
  %v5830 = load i64, ptr %slot938, align 8
  %p5831 = inttoptr i64 %v5829 to ptr
  %p5832 = inttoptr i64 %v5830 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5832, ptr %p5831, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v5833 = load i64, ptr %slot21, align 8
  %p5834 = inttoptr i64 %v5833 to ptr
  store i32 0, ptr %p5834, align 4, !alias.scope !3, !noalias !4
  %v5835 = load i64, ptr %slot12, align 8
  %p5836 = inttoptr i64 %v5835 to ptr
  store i32 2, ptr %p5836, align 4, !alias.scope !3, !noalias !4
  %v5837 = load i64, ptr %slot22, align 8
  %p5838 = inttoptr i64 %v5837 to ptr
  %ld5839 = load i32, ptr %p5838, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5839, ptr %slot940, align 8
  %v5840 = load i32, ptr %slot940, align 8
  %v5841 = load i64, ptr %slot12, align 8
  %p5842 = inttoptr i64 %v5841 to ptr
  store i32 %v5840, ptr %p5842, align 4, !alias.scope !3, !noalias !4
  %v5843 = load i64, ptr %slot11, align 8
  %p5844 = inttoptr i64 %v5843 to ptr
  store i32 1, ptr %p5844, align 4, !alias.scope !3, !noalias !4
  %v5845 = load i64, ptr %slot49, align 8
  %v5846 = load i64, ptr %slot57, align 8
  %p5847 = inttoptr i64 %v5846 to ptr
  store i64 %v5845, ptr %p5847, align 8, !alias.scope !3, !noalias !4
  %v5848 = load i64, ptr %slot49, align 8
  %v5849 = load i64, ptr %slot58, align 8
  %p5850 = inttoptr i64 %v5849 to ptr
  store i64 %v5848, ptr %p5850, align 8, !alias.scope !3, !noalias !4
  %v5851 = load i64, ptr %slot58, align 8
  %p5852 = inttoptr i64 %v5851 to ptr
  %ld5853 = load i64, ptr %p5852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5853, ptr %slot941, align 8
  %v5854 = load i64, ptr %slot941, align 8
  %op5855 = add i64 %v5854, 0
  store i64 %op5855, ptr %slot942, align 8
  %v5856 = load i64, ptr %slot942, align 8
  %v5857 = load i64, ptr %slot58, align 8
  %p5858 = inttoptr i64 %v5857 to ptr
  store i64 %v5856, ptr %p5858, align 8, !alias.scope !3, !noalias !4
  %v5859 = load i64, ptr %slot58, align 8
  %p5860 = inttoptr i64 %v5859 to ptr
  %ld5861 = load i64, ptr %p5860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5861, ptr %slot943, align 8
  %v5862 = load i64, ptr %slot28, align 8
  store i64 %v5862, ptr %slot944, align 8
  %v5863 = load i64, ptr %slot70, align 8
  %v5864 = load i64, ptr %slot944, align 8
  %v5865 = load i64, ptr %slot943, align 8
  %call5866 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64 %v5863, i64 %v5864, i64 %v5865) nomerge, !dbg !162
  store i32 %call5866, ptr %slot945, align 8
  %v5867 = load i32, ptr %slot945, align 8
  %cv5868 = zext i32 %v5867 to i64
  %cond5869 = icmp ne i64 %cv5868, 0
  br i1 %cond5869, label %bb_rcsuccess1496, label %bb_rcfailure1496
bb_rcfailure1496:
  %v5870 = load i64, ptr %slot70, align 8
  %p5871 = inttoptr i64 %v5870 to ptr
  %call5872 = call i32 @myl_rc_take_failure(ptr %p5871) nomerge, !dbg !162
  store i32 %call5872, ptr %slot946, align 8
  %v5873 = load i64, ptr %slot1, align 8
  %p5874 = inttoptr i64 %v5873 to ptr
  %v5875 = load i32, ptr %slot946, align 8
  %call5876 = call i32 @myl_qbe_rc_status(ptr %p5874, i32 %v5875) nomerge, !dbg !162
  store i32 %call5876, ptr %slot947, align 8
  br label %bb_failure
bb_rcsuccess1496:
  %v5877 = load i64, ptr %slot22, align 8
  %p5878 = inttoptr i64 %v5877 to ptr
  store i32 2, ptr %p5878, align 4, !alias.scope !3, !noalias !4
  %v5879 = load i64, ptr %slot22, align 8
  %p5880 = inttoptr i64 %v5879 to ptr
  store i32 16, ptr %p5880, align 4, !alias.scope !3, !noalias !4
  %v5881 = load i64, ptr %slot21, align 8
  %p5882 = inttoptr i64 %v5881 to ptr
  store i32 1, ptr %p5882, align 4, !alias.scope !3, !noalias !4
  %v5883 = load i64, ptr %slot19, align 8
  %p5884 = inttoptr i64 %v5883 to ptr
  %ld5885 = load i32, ptr %p5884, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5885, ptr %slot948, align 8
  %v5886 = load i32, ptr %slot948, align 8
  %cv5887 = zext i32 %v5886 to i64
  %cond5888 = icmp ne i64 %cv5887, 0
  br i1 %cond5888, label %bb_rcslotdrop1504, label %bb_rcslotdone1504
bb_rcslotdrop1504:
  %v5889 = load i64, ptr %slot19, align 8
  %p5890 = inttoptr i64 %v5889 to ptr
  store i32 0, ptr %p5890, align 4, !alias.scope !3, !noalias !4
  %v5891 = load i64, ptr %slot25, align 8
  store i64 %v5891, ptr %slot949, align 8
  %v5892 = load i64, ptr %slot20, align 8
  %p5893 = inttoptr i64 %v5892 to ptr
  %ld5894 = load i32, ptr %p5893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5894, ptr %slot950, align 8
  %v5895 = load i32, ptr %slot950, align 8
  %op5896 = and i32 %v5895, 28
  store i32 %op5896, ptr %slot951, align 8
  %v5897 = load i32, ptr %slot951, align 8
  %cv5898 = zext i32 %v5897 to i64
  %cond5899 = icmp ne i64 %cv5898, 0
  br i1 %cond5899, label %bb_rcslotrole1504, label %bb_rcslotowner1504
bb_rcslotrole1504:
  %v5900 = load i64, ptr %slot70, align 8
  store i64 %v5900, ptr %slot952, align 8
  %v5901 = load i64, ptr %slot952, align 8
  %v5902 = load i64, ptr %slot949, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5901, i64 %v5902) nomerge, !dbg !162
  br label %bb_rcslotdone1504
bb_rcslotowner1504:
  %v5903 = load i64, ptr %slot70, align 8
  store i64 %v5903, ptr %slot953, align 8
  %v5904 = load i64, ptr %slot953, align 8
  %v5905 = load i64, ptr %slot949, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5904, i64 %v5905) nomerge, !dbg !162
  br label %bb_rcslotdone1504
bb_rcslotdone1504:
  %v5906 = load i64, ptr %slot25, align 8
  store i64 %v5906, ptr %slot954, align 8
  %v5907 = load i64, ptr %slot28, align 8
  store i64 %v5907, ptr %slot955, align 8
  %v5908 = load i64, ptr %slot955, align 8
  %v5909 = load i64, ptr %slot954, align 8
  %p5910 = inttoptr i64 %v5908 to ptr
  %p5911 = inttoptr i64 %v5909 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5911, ptr %p5910, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v5912 = load i64, ptr %slot20, align 8
  %p5913 = inttoptr i64 %v5912 to ptr
  store i32 2, ptr %p5913, align 4, !alias.scope !3, !noalias !4
  %v5914 = load i64, ptr %slot22, align 8
  %p5915 = inttoptr i64 %v5914 to ptr
  %ld5916 = load i32, ptr %p5915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5916, ptr %slot956, align 8
  %v5917 = load i32, ptr %slot956, align 8
  %v5918 = load i64, ptr %slot20, align 8
  %p5919 = inttoptr i64 %v5918 to ptr
  store i32 %v5917, ptr %p5919, align 4, !alias.scope !3, !noalias !4
  %v5920 = load i64, ptr %slot21, align 8
  %p5921 = inttoptr i64 %v5920 to ptr
  store i32 0, ptr %p5921, align 4, !alias.scope !3, !noalias !4
  %v5922 = load i64, ptr %slot19, align 8
  %p5923 = inttoptr i64 %v5922 to ptr
  store i32 1, ptr %p5923, align 4, !alias.scope !3, !noalias !4
  %v5924 = load i64, ptr %slot954, align 8
  %v5925 = load i64, ptr %slot58, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  store i64 %v5924, ptr %p5926, align 8, !alias.scope !3, !noalias !4
  %v5927 = load i64, ptr %slot50, align 8
  %p5928 = inttoptr i64 %v5927 to ptr
  %ld5929 = load i64, ptr %p5928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5929, ptr %slot957, align 8
  %v5930 = load i64, ptr %slot957, align 8
  %v5931 = load i64, ptr %slot59, align 8
  %p5932 = inttoptr i64 %v5931 to ptr
  store i64 %v5930, ptr %p5932, align 8, !alias.scope !3, !noalias !4
  %v5933 = load i64, ptr %slot58, align 8
  %p5934 = inttoptr i64 %v5933 to ptr
  %ld5935 = load i64, ptr %p5934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5935, ptr %slot958, align 8
  %v5936 = load i64, ptr %slot19, align 8
  %p5937 = inttoptr i64 %v5936 to ptr
  %ld5938 = load i32, ptr %p5937, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5938, ptr %slot959, align 8
  %v5939 = load i64, ptr %slot20, align 8
  %p5940 = inttoptr i64 %v5939 to ptr
  %ld5941 = load i32, ptr %p5940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5941, ptr %slot960, align 8
  %v5942 = load i32, ptr %slot960, align 8
  %op5943 = and i32 %v5942, 24
  store i32 %op5943, ptr %slot960, align 8
  %v5944 = load i32, ptr %slot960, align 8
  %cmp5945 = icmp eq i32 %v5944, 0
  %cv5946 = zext i1 %cmp5945 to i32
  store i32 %cv5946, ptr %slot961, align 8
  %v5947 = load i32, ptr %slot959, align 8
  %v5948 = load i32, ptr %slot961, align 8
  %op5949 = and i32 %v5947, %v5948
  store i32 %op5949, ptr %slot962, align 8
  %v5950 = load i32, ptr %slot962, align 8
  %cv5951 = zext i32 %v5950 to i64
  %cond5952 = icmp ne i64 %cv5951, 0
  br i1 %cond5952, label %bb_rctake1521, label %bb_rccopy1521
bb_rctake1521:
  %v5953 = load i64, ptr %slot28, align 8
  store i64 %v5953, ptr %slot963, align 8
  %v5954 = load i64, ptr %slot71, align 8
  store i64 %v5954, ptr %slot964, align 8
  %v5955 = load i64, ptr %slot958, align 8
  %v5956 = load i64, ptr %slot963, align 8
  %op5957 = sub i64 %v5955, %v5956
  store i64 %op5957, ptr %slot965, align 8
  %v5958 = load i64, ptr %slot963, align 8
  %v5959 = load i64, ptr %slot958, align 8
  %op5960 = sub i64 %v5958, %v5959
  store i64 %op5960, ptr %slot966, align 8
  %v5961 = load i64, ptr %slot965, align 8
  %cmp5962 = icmp ult i64 %v5961, 48
  %cv5963 = zext i1 %cmp5962 to i32
  store i32 %cv5963, ptr %slot967, align 8
  %v5964 = load i64, ptr %slot966, align 8
  %cmp5965 = icmp ult i64 %v5964, 48
  %cv5966 = zext i1 %cmp5965 to i32
  store i32 %cv5966, ptr %slot968, align 8
  %v5967 = load i32, ptr %slot967, align 8
  %v5968 = load i32, ptr %slot968, align 8
  %op5969 = or i32 %v5967, %v5968
  store i32 %op5969, ptr %slot969, align 8
  %v5970 = load i32, ptr %slot969, align 8
  %cv5971 = zext i32 %v5970 to i64
  %cond5972 = icmp ne i64 %cv5971, 0
  br i1 %cond5972, label %bb_rcmoveslow1530, label %bb_rcmovecheck1530
bb_rcmovecheck1530:
  %v5973 = load i64, ptr %slot958, align 8
  %op5974 = add i64 %v5973, 16
  store i64 %op5974, ptr %slot970, align 8
  %v5975 = load i64, ptr %slot970, align 8
  %p5976 = inttoptr i64 %v5975 to ptr
  %ld5977 = load i64, ptr %p5976, align 8
  store i64 %ld5977, ptr %slot971, align 8
  %v5978 = load i64, ptr %slot971, align 8
  %cmp5979 = icmp ne i64 %v5978, 0
  %cv5980 = zext i1 %cmp5979 to i32
  store i32 %cv5980, ptr %slot972, align 8
  %v5981 = load i32, ptr %slot972, align 8
  %cv5982 = zext i32 %v5981 to i64
  %cond5983 = icmp ne i64 %cv5982, 0
  br i1 %cond5983, label %bb_rcmoveheader1538, label %bb_rcmovenext1538
bb_rcmoveheader1538:
  %v5984 = load i64, ptr %slot971, align 8
  %op5985 = sub i64 %v5984, 16
  store i64 %op5985, ptr %slot973, align 8
  %v5986 = load i64, ptr %slot971, align 8
  %p5987 = inttoptr i64 %v5986 to ptr
  %rgep5988 = getelementptr i8, ptr %p5987, i64 -16
  %ld5989 = load i64, ptr %rgep5988, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5989, ptr %slot974, align 8
  %v5990 = load i64, ptr %slot974, align 8
  %op5991 = and i64 %v5990, 5764607523034234881
  store i64 %op5991, ptr %slot975, align 8
  %v5992 = load i64, ptr %slot975, align 8
  %cmp5993 = icmp ne i64 %v5992, 0
  %cv5994 = zext i1 %cmp5993 to i32
  store i32 %cv5994, ptr %slot976, align 8
  %v5995 = load i32, ptr %slot976, align 8
  %cv5996 = zext i32 %v5995 to i64
  %cond5997 = icmp ne i64 %cv5996, 0
  br i1 %cond5997, label %bb_rcmoveslow1530, label %bb_rcmovenext1538
bb_rcmovenext1538:
  %v5998 = load i64, ptr %slot958, align 8
  %op5999 = add i64 %v5998, 24
  store i64 %op5999, ptr %slot977, align 8
  %v6000 = load i64, ptr %slot977, align 8
  %p6001 = inttoptr i64 %v6000 to ptr
  %ld6002 = load i64, ptr %p6001, align 8
  store i64 %ld6002, ptr %slot978, align 8
  %v6003 = load i64, ptr %slot978, align 8
  %cmp6004 = icmp ne i64 %v6003, 0
  %cv6005 = zext i1 %cmp6004 to i32
  store i32 %cv6005, ptr %slot979, align 8
  %v6006 = load i32, ptr %slot979, align 8
  %cv6007 = zext i32 %v6006 to i64
  %cond6008 = icmp ne i64 %cv6007, 0
  br i1 %cond6008, label %bb_rcmoveheader1546, label %bb_rcmovenext1546
bb_rcmoveheader1546:
  %v6009 = load i64, ptr %slot978, align 8
  %op6010 = sub i64 %v6009, 16
  store i64 %op6010, ptr %slot980, align 8
  %v6011 = load i64, ptr %slot978, align 8
  %p6012 = inttoptr i64 %v6011 to ptr
  %rgep6013 = getelementptr i8, ptr %p6012, i64 -16
  %ld6014 = load i64, ptr %rgep6013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6014, ptr %slot981, align 8
  %v6015 = load i64, ptr %slot981, align 8
  %op6016 = and i64 %v6015, 5764607523034234881
  store i64 %op6016, ptr %slot982, align 8
  %v6017 = load i64, ptr %slot982, align 8
  %cmp6018 = icmp ne i64 %v6017, 0
  %cv6019 = zext i1 %cmp6018 to i32
  store i32 %cv6019, ptr %slot983, align 8
  %v6020 = load i32, ptr %slot983, align 8
  %cv6021 = zext i32 %v6020 to i64
  %cond6022 = icmp ne i64 %cv6021, 0
  br i1 %cond6022, label %bb_rcmoveslow1530, label %bb_rcmovenext1546
bb_rcmovenext1546:
  %v6023 = load i64, ptr %slot958, align 8
  %op6024 = add i64 %v6023, 32
  store i64 %op6024, ptr %slot984, align 8
  %v6025 = load i64, ptr %slot984, align 8
  %p6026 = inttoptr i64 %v6025 to ptr
  %ld6027 = load i64, ptr %p6026, align 8
  store i64 %ld6027, ptr %slot985, align 8
  %v6028 = load i64, ptr %slot985, align 8
  %cmp6029 = icmp ne i64 %v6028, 0
  %cv6030 = zext i1 %cmp6029 to i32
  store i32 %cv6030, ptr %slot986, align 8
  %v6031 = load i32, ptr %slot986, align 8
  %cv6032 = zext i32 %v6031 to i64
  %cond6033 = icmp ne i64 %cv6032, 0
  br i1 %cond6033, label %bb_rcmoveheader1554, label %bb_rcmovenext1554
bb_rcmoveheader1554:
  %v6034 = load i64, ptr %slot985, align 8
  %op6035 = sub i64 %v6034, 16
  store i64 %op6035, ptr %slot987, align 8
  %v6036 = load i64, ptr %slot985, align 8
  %p6037 = inttoptr i64 %v6036 to ptr
  %rgep6038 = getelementptr i8, ptr %p6037, i64 -16
  %ld6039 = load i64, ptr %rgep6038, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6039, ptr %slot988, align 8
  %v6040 = load i64, ptr %slot988, align 8
  %op6041 = and i64 %v6040, 5764607523034234881
  store i64 %op6041, ptr %slot989, align 8
  %v6042 = load i64, ptr %slot989, align 8
  %cmp6043 = icmp ne i64 %v6042, 0
  %cv6044 = zext i1 %cmp6043 to i32
  store i32 %cv6044, ptr %slot990, align 8
  %v6045 = load i32, ptr %slot990, align 8
  %cv6046 = zext i32 %v6045 to i64
  %cond6047 = icmp ne i64 %cv6046, 0
  br i1 %cond6047, label %bb_rcmoveslow1530, label %bb_rcmovenext1554
bb_rcmovenext1554:
  %v6048 = load i64, ptr %slot958, align 8
  %v6049 = load i64, ptr %slot963, align 8
  %p6050 = inttoptr i64 %v6048 to ptr
  %p6051 = inttoptr i64 %v6049 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6051, ptr %p6050, i64 48, i1 false)
  %v6052 = load i64, ptr %slot958, align 8
  %p6053 = inttoptr i64 %v6052 to ptr
  store i64 0, ptr %p6053, align 8
  %v6054 = load i64, ptr %slot958, align 8
  %op6055 = add i64 %v6054, 8
  store i64 %op6055, ptr %slot991, align 8
  %v6056 = load i64, ptr %slot991, align 8
  %p6057 = inttoptr i64 %v6056 to ptr
  store i64 0, ptr %p6057, align 8
  %v6058 = load i64, ptr %slot958, align 8
  %op6059 = add i64 %v6058, 16
  store i64 %op6059, ptr %slot992, align 8
  %v6060 = load i64, ptr %slot992, align 8
  %p6061 = inttoptr i64 %v6060 to ptr
  store i64 0, ptr %p6061, align 8
  %v6062 = load i64, ptr %slot958, align 8
  %op6063 = add i64 %v6062, 24
  store i64 %op6063, ptr %slot993, align 8
  %v6064 = load i64, ptr %slot993, align 8
  %p6065 = inttoptr i64 %v6064 to ptr
  store i64 0, ptr %p6065, align 8
  %v6066 = load i64, ptr %slot958, align 8
  %op6067 = add i64 %v6066, 32
  store i64 %op6067, ptr %slot994, align 8
  %v6068 = load i64, ptr %slot994, align 8
  %p6069 = inttoptr i64 %v6068 to ptr
  store i64 0, ptr %p6069, align 8
  %v6070 = load i64, ptr %slot958, align 8
  %op6071 = add i64 %v6070, 40
  store i64 %op6071, ptr %slot995, align 8
  %v6072 = load i64, ptr %slot995, align 8
  %p6073 = inttoptr i64 %v6072 to ptr
  store i64 0, ptr %p6073, align 8
  br label %bb_rcmoved1530
bb_rcmoveslow1530:
  %v6074 = load i64, ptr %slot70, align 8
  %v6075 = load i64, ptr %slot963, align 8
  %v6076 = load i64, ptr %slot958, align 8
  %v6077 = load i64, ptr %slot964, align 8
  %cv6078 = trunc i64 %v6077 to i32
  %call6079 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v6074, i64 %v6075, i64 %v6076, i32 %cv6078) nomerge, !dbg !164
  store i32 %call6079, ptr %slot996, align 8
  %v6080 = load i32, ptr %slot996, align 8
  %cv6081 = zext i32 %v6080 to i64
  %cond6082 = icmp ne i64 %cv6081, 0
  br i1 %cond6082, label %bb_rcsuccess1566, label %bb_rcfailure1566
bb_rcfailure1566:
  %v6083 = load i64, ptr %slot70, align 8
  %p6084 = inttoptr i64 %v6083 to ptr
  %call6085 = call i32 @myl_rc_take_failure(ptr %p6084) nomerge, !dbg !164
  store i32 %call6085, ptr %slot997, align 8
  %v6086 = load i64, ptr %slot1, align 8
  %p6087 = inttoptr i64 %v6086 to ptr
  %v6088 = load i32, ptr %slot997, align 8
  %call6089 = call i32 @myl_qbe_rc_status(ptr %p6087, i32 %v6088) nomerge, !dbg !164
  store i32 %call6089, ptr %slot998, align 8
  br label %bb_failure
bb_rcsuccess1566:
  br label %bb_rcmoved1530
bb_rcmoved1530:
  %v6090 = load i64, ptr %slot19, align 8
  %p6091 = inttoptr i64 %v6090 to ptr
  store i32 0, ptr %p6091, align 4, !alias.scope !3, !noalias !4
  %v6092 = load i64, ptr %slot22, align 8
  %p6093 = inttoptr i64 %v6092 to ptr
  store i32 2, ptr %p6093, align 4, !alias.scope !3, !noalias !4
  %v6094 = load i64, ptr %slot21, align 8
  %p6095 = inttoptr i64 %v6094 to ptr
  store i32 1, ptr %p6095, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1521
bb_rccopy1521:
  %v6096 = load i64, ptr %slot28, align 8
  store i64 %v6096, ptr %slot999, align 8
  %v6097 = load i64, ptr %slot71, align 8
  store i64 %v6097, ptr %slot1000, align 8
  %v6098 = load i64, ptr %slot70, align 8
  %v6099 = load i64, ptr %slot999, align 8
  %v6100 = load i64, ptr %slot958, align 8
  %v6101 = load i64, ptr %slot1000, align 8
  %cv6102 = trunc i64 %v6101 to i32
  %call6103 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64 %v6098, i64 %v6099, i64 %v6100, i32 %cv6102) nomerge, !dbg !164
  store i32 %call6103, ptr %slot1001, align 8
  %v6104 = load i32, ptr %slot1001, align 8
  %cv6105 = zext i32 %v6104 to i64
  %cond6106 = icmp ne i64 %cv6105, 0
  br i1 %cond6106, label %bb_rcsuccess1575, label %bb_rcfailure1575
bb_rcfailure1575:
  %v6107 = load i64, ptr %slot70, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  %call6109 = call i32 @myl_rc_take_failure(ptr %p6108) nomerge, !dbg !164
  store i32 %call6109, ptr %slot1002, align 8
  %v6110 = load i64, ptr %slot1, align 8
  %p6111 = inttoptr i64 %v6110 to ptr
  %v6112 = load i32, ptr %slot1002, align 8
  %call6113 = call i32 @myl_qbe_rc_status(ptr %p6111, i32 %v6112) nomerge, !dbg !164
  store i32 %call6113, ptr %slot1003, align 8
  br label %bb_failure
bb_rcsuccess1575:
  %v6114 = load i64, ptr %slot22, align 8
  %p6115 = inttoptr i64 %v6114 to ptr
  store i32 2, ptr %p6115, align 4, !alias.scope !3, !noalias !4
  %v6116 = load i64, ptr %slot21, align 8
  %p6117 = inttoptr i64 %v6116 to ptr
  store i32 1, ptr %p6117, align 4, !alias.scope !3, !noalias !4
  %v6118 = load i64, ptr %slot19, align 8
  %p6119 = inttoptr i64 %v6118 to ptr
  %ld6120 = load i32, ptr %p6119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6120, ptr %slot1004, align 8
  %v6121 = load i32, ptr %slot1004, align 8
  %cv6122 = zext i32 %v6121 to i64
  %cond6123 = icmp ne i64 %cv6122, 0
  br i1 %cond6123, label %bb_rcslotdrop1582, label %bb_rcslotdone1582
bb_rcslotdrop1582:
  %v6124 = load i64, ptr %slot19, align 8
  %p6125 = inttoptr i64 %v6124 to ptr
  store i32 0, ptr %p6125, align 4, !alias.scope !3, !noalias !4
  %v6126 = load i64, ptr %slot25, align 8
  store i64 %v6126, ptr %slot1005, align 8
  %v6127 = load i64, ptr %slot20, align 8
  %p6128 = inttoptr i64 %v6127 to ptr
  %ld6129 = load i32, ptr %p6128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6129, ptr %slot1006, align 8
  %v6130 = load i32, ptr %slot1006, align 8
  %op6131 = and i32 %v6130, 28
  store i32 %op6131, ptr %slot1007, align 8
  %v6132 = load i32, ptr %slot1007, align 8
  %cv6133 = zext i32 %v6132 to i64
  %cond6134 = icmp ne i64 %cv6133, 0
  br i1 %cond6134, label %bb_rcslotrole1582, label %bb_rcslotowner1582
bb_rcslotrole1582:
  %v6135 = load i64, ptr %slot70, align 8
  store i64 %v6135, ptr %slot1008, align 8
  %v6136 = load i64, ptr %slot1008, align 8
  %v6137 = load i64, ptr %slot1005, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v6136, i64 %v6137) nomerge, !dbg !164
  br label %bb_rcslotdone1582
bb_rcslotowner1582:
  %v6138 = load i64, ptr %slot70, align 8
  store i64 %v6138, ptr %slot1009, align 8
  %v6139 = load i64, ptr %slot1009, align 8
  %v6140 = load i64, ptr %slot1005, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v6139, i64 %v6140) nomerge, !dbg !164
  br label %bb_rcslotdone1582
bb_rcslotdone1582:
  br label %bb_rcprepared1521
bb_rcprepared1521:
  %v6141 = load i64, ptr %slot28, align 8
  store i64 %v6141, ptr %slot1010, align 8
  %v6142 = load i64, ptr %slot61, align 8
  store i64 %v6142, ptr %slot1011, align 8
  %v6143 = load i64, ptr %slot1010, align 8
  %v6144 = load i64, ptr %slot1011, align 8
  %p6145 = inttoptr i64 %v6143 to ptr
  %p6146 = inttoptr i64 %v6144 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6146, ptr %p6145, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v6147 = load i64, ptr %slot21, align 8
  %p6148 = inttoptr i64 %v6147 to ptr
  store i32 0, ptr %p6148, align 4, !alias.scope !3, !noalias !4
  %v6149 = load i64, ptr %slot23, align 8
  %p6150 = inttoptr i64 %v6149 to ptr
  store i32 1, ptr %p6150, align 4, !alias.scope !3, !noalias !4
  %v6151 = load i64, ptr %slot71, align 8
  store i64 %v6151, ptr %slot1012, align 8
  %v6152 = load i64, ptr %slot59, align 8
  store i64 %v6152, ptr %slot1013, align 8
  %v6153 = load i64, ptr %slot1011, align 8
  %p6155 = inttoptr i64 %v6153 to ptr
  %gep6156 = getelementptr i8, ptr %p6155, i64 8
  %op6154 = ptrtoint ptr %gep6156 to i64
  store i64 %op6154, ptr %slot1014, align 8
  %v6157 = load i64, ptr %slot1013, align 8
  %p6158 = inttoptr i64 %v6157 to ptr
  %ld6159 = load i64, ptr %p6158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6159, ptr %slot1015, align 8
  %v6160 = load i64, ptr %slot1015, align 8
  %v6161 = load i64, ptr %slot1014, align 8
  %p6162 = inttoptr i64 %v6161 to ptr
  store i64 %v6160, ptr %p6162, align 8, !alias.scope !3, !noalias !4
  %v6163 = load i64, ptr %slot1011, align 8
  %v6164 = load i64, ptr %slot58, align 8
  %p6165 = inttoptr i64 %v6164 to ptr
  store i64 %v6163, ptr %p6165, align 8, !alias.scope !3, !noalias !4
  %v6166 = load i64, ptr %slot58, align 8
  %p6167 = inttoptr i64 %v6166 to ptr
  %ld6168 = load i64, ptr %p6167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6168, ptr %slot1016, align 8
  %v6169 = load i64, ptr %slot28, align 8
  store i64 %v6169, ptr %slot1017, align 8
  %v6170 = load i64, ptr %slot1016, align 8
  %v6171 = load i64, ptr %slot1017, align 8
  %p6172 = inttoptr i64 %v6170 to ptr
  %p6173 = inttoptr i64 %v6171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6173, ptr %p6172, i64 48, i1 false)
  %v6174 = load i64, ptr %slot22, align 8
  %p6175 = inttoptr i64 %v6174 to ptr
  store i32 2, ptr %p6175, align 4, !alias.scope !3, !noalias !4
  %v6176 = load i64, ptr %slot21, align 8
  %p6177 = inttoptr i64 %v6176 to ptr
  store i32 1, ptr %p6177, align 4, !alias.scope !3, !noalias !4
  %v6178 = load i64, ptr %slot19, align 8
  %p6179 = inttoptr i64 %v6178 to ptr
  %ld6180 = load i32, ptr %p6179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6180, ptr %slot1018, align 8
  %v6181 = load i32, ptr %slot1018, align 8
  %cv6182 = zext i32 %v6181 to i64
  %cond6183 = icmp ne i64 %cv6182, 0
  br i1 %cond6183, label %bb_rcslotdrop1604, label %bb_rcslotdone1604
bb_rcslotdrop1604:
  %v6184 = load i64, ptr %slot19, align 8
  %p6185 = inttoptr i64 %v6184 to ptr
  store i32 0, ptr %p6185, align 4, !alias.scope !3, !noalias !4
  %v6186 = load i64, ptr %slot25, align 8
  store i64 %v6186, ptr %slot1019, align 8
  %v6187 = load i64, ptr %slot20, align 8
  %p6188 = inttoptr i64 %v6187 to ptr
  %ld6189 = load i32, ptr %p6188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6189, ptr %slot1020, align 8
  %v6190 = load i32, ptr %slot1020, align 8
  %op6191 = and i32 %v6190, 28
  store i32 %op6191, ptr %slot1021, align 8
  %v6192 = load i32, ptr %slot1021, align 8
  %cv6193 = zext i32 %v6192 to i64
  %cond6194 = icmp ne i64 %cv6193, 0
  br i1 %cond6194, label %bb_rcslotrole1604, label %bb_rcslotowner1604
bb_rcslotrole1604:
  %v6195 = load i64, ptr %slot70, align 8
  store i64 %v6195, ptr %slot1022, align 8
  %v6196 = load i64, ptr %slot1022, align 8
  %v6197 = load i64, ptr %slot1019, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v6196, i64 %v6197) nomerge, !dbg !164
  br label %bb_rcslotdone1604
bb_rcslotowner1604:
  %v6198 = load i64, ptr %slot70, align 8
  store i64 %v6198, ptr %slot1023, align 8
  %v6199 = load i64, ptr %slot1023, align 8
  %v6200 = load i64, ptr %slot1019, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v6199, i64 %v6200) nomerge, !dbg !164
  br label %bb_rcslotdone1604
bb_rcslotdone1604:
  %v6201 = load i64, ptr %slot25, align 8
  store i64 %v6201, ptr %slot1024, align 8
  %v6202 = load i64, ptr %slot28, align 8
  store i64 %v6202, ptr %slot1025, align 8
  %v6203 = load i64, ptr %slot1025, align 8
  %v6204 = load i64, ptr %slot1024, align 8
  %p6205 = inttoptr i64 %v6203 to ptr
  %p6206 = inttoptr i64 %v6204 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6206, ptr %p6205, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v6207 = load i64, ptr %slot20, align 8
  %p6208 = inttoptr i64 %v6207 to ptr
  store i32 2, ptr %p6208, align 4, !alias.scope !3, !noalias !4
  %v6209 = load i64, ptr %slot22, align 8
  %p6210 = inttoptr i64 %v6209 to ptr
  %ld6211 = load i32, ptr %p6210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6211, ptr %slot1026, align 8
  %v6212 = load i32, ptr %slot1026, align 8
  %v6213 = load i64, ptr %slot20, align 8
  %p6214 = inttoptr i64 %v6213 to ptr
  store i32 %v6212, ptr %p6214, align 4, !alias.scope !3, !noalias !4
  %v6215 = load i64, ptr %slot21, align 8
  %p6216 = inttoptr i64 %v6215 to ptr
  store i32 0, ptr %p6216, align 4, !alias.scope !3, !noalias !4
  %v6217 = load i64, ptr %slot19, align 8
  %p6218 = inttoptr i64 %v6217 to ptr
  store i32 1, ptr %p6218, align 4, !alias.scope !3, !noalias !4
  %v6219 = load i64, ptr %slot1024, align 8
  %v6220 = load i64, ptr %slot58, align 8
  %p6221 = inttoptr i64 %v6220 to ptr
  store i64 %v6219, ptr %p6221, align 8, !alias.scope !3, !noalias !4
  %v6222 = load i64, ptr %slot58, align 8
  %p6223 = inttoptr i64 %v6222 to ptr
  %ld6224 = load i64, ptr %p6223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6224, ptr %slot1027, align 8
  %v6225 = load i64, ptr %slot19, align 8
  %p6226 = inttoptr i64 %v6225 to ptr
  %ld6227 = load i32, ptr %p6226, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6227, ptr %slot1028, align 8
  %v6228 = load i64, ptr %slot20, align 8
  %p6229 = inttoptr i64 %v6228 to ptr
  %ld6230 = load i32, ptr %p6229, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6230, ptr %slot1029, align 8
  %v6231 = load i32, ptr %slot1029, align 8
  %op6232 = and i32 %v6231, 24
  store i32 %op6232, ptr %slot1029, align 8
  %v6233 = load i32, ptr %slot1029, align 8
  %cmp6234 = icmp eq i32 %v6233, 0
  %cv6235 = zext i1 %cmp6234 to i32
  store i32 %cv6235, ptr %slot1030, align 8
  %v6236 = load i32, ptr %slot1028, align 8
  %v6237 = load i32, ptr %slot1030, align 8
  %op6238 = and i32 %v6236, %v6237
  store i32 %op6238, ptr %slot1031, align 8
  %v6239 = load i64, ptr %slot71, align 8
  store i64 %v6239, ptr %slot1032, align 8
  %v6240 = load i32, ptr %slot1031, align 8
  %op6241 = mul i32 %v6240, 4
  store i32 %op6241, ptr %slot1033, align 8
  %v6242 = load i32, ptr %slot1033, align 8
  %op6243 = or i32 %v6242, 0
  store i32 %op6243, ptr %slot1034, align 8
  %v6244 = load i64, ptr %slot28, align 8
  store i64 %v6244, ptr %slot1035, align 8
  %v6245 = load i64, ptr %slot70, align 8
  %v6246 = load i64, ptr %slot1035, align 8
  %v6247 = load i64, ptr %slot1027, align 8
  %v6248 = load i64, ptr %slot1032, align 8
  %cv6249 = trunc i64 %v6248 to i32
  %v6250 = load i32, ptr %slot1034, align 8
  %call6251 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v6245, i64 %v6246, i64 %v6247, i32 %cv6249, i32 %v6250) nomerge, !dbg !166
  store i32 %call6251, ptr %slot1036, align 8
  %v6252 = load i32, ptr %slot1036, align 8
  %cv6253 = zext i32 %v6252 to i64
  %cond6254 = icmp ne i64 %cv6253, 0
  br i1 %cond6254, label %bb_rcsuccess1633, label %bb_rcfailure1633
bb_rcfailure1633:
  %v6255 = load i64, ptr %slot70, align 8
  %p6256 = inttoptr i64 %v6255 to ptr
  %call6257 = call i32 @myl_rc_take_failure(ptr %p6256) nomerge, !dbg !166
  store i32 %call6257, ptr %slot1037, align 8
  %v6258 = load i64, ptr %slot1, align 8
  %p6259 = inttoptr i64 %v6258 to ptr
  %v6260 = load i32, ptr %slot1037, align 8
  %call6261 = call i32 @myl_qbe_rc_status(ptr %p6259, i32 %v6260) nomerge, !dbg !166
  store i32 %call6261, ptr %slot1038, align 8
  br label %bb_failure
bb_rcsuccess1633:
  %v6262 = load i32, ptr %slot1031, align 8
  %cv6263 = zext i32 %v6262 to i64
  %cond6264 = icmp ne i64 %cv6263, 0
  br i1 %cond6264, label %bb_rchtaken1636, label %bb_rchcopied1636
bb_rchcopied1636:
  %v6265 = load i64, ptr %slot19, align 8
  %p6266 = inttoptr i64 %v6265 to ptr
  %ld6267 = load i32, ptr %p6266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6267, ptr %slot1039, align 8
  %v6268 = load i32, ptr %slot1039, align 8
  %cv6269 = zext i32 %v6268 to i64
  %cond6270 = icmp ne i64 %cv6269, 0
  br i1 %cond6270, label %bb_rcslotdrop1639, label %bb_rcslotdone1639
bb_rcslotdrop1639:
  %v6271 = load i64, ptr %slot19, align 8
  %p6272 = inttoptr i64 %v6271 to ptr
  store i32 0, ptr %p6272, align 4, !alias.scope !3, !noalias !4
  %v6273 = load i64, ptr %slot25, align 8
  store i64 %v6273, ptr %slot1040, align 8
  %v6274 = load i64, ptr %slot20, align 8
  %p6275 = inttoptr i64 %v6274 to ptr
  %ld6276 = load i32, ptr %p6275, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6276, ptr %slot1041, align 8
  %v6277 = load i32, ptr %slot1041, align 8
  %op6278 = and i32 %v6277, 28
  store i32 %op6278, ptr %slot1042, align 8
  %v6279 = load i32, ptr %slot1042, align 8
  %cv6280 = zext i32 %v6279 to i64
  %cond6281 = icmp ne i64 %cv6280, 0
  br i1 %cond6281, label %bb_rcslotrole1639, label %bb_rcslotowner1639
bb_rcslotrole1639:
  %v6282 = load i64, ptr %slot70, align 8
  store i64 %v6282, ptr %slot1043, align 8
  %v6283 = load i64, ptr %slot1043, align 8
  %v6284 = load i64, ptr %slot1040, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v6283, i64 %v6284) nomerge, !dbg !166
  br label %bb_rcslotdone1639
bb_rcslotowner1639:
  %v6285 = load i64, ptr %slot70, align 8
  store i64 %v6285, ptr %slot1044, align 8
  %v6286 = load i64, ptr %slot1044, align 8
  %v6287 = load i64, ptr %slot1040, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v6286, i64 %v6287) nomerge, !dbg !166
  br label %bb_rcslotdone1639
bb_rcslotdone1639:
  br label %bb_rchprepared1636
bb_rchtaken1636:
  %v6288 = load i64, ptr %slot19, align 8
  %p6289 = inttoptr i64 %v6288 to ptr
  store i32 0, ptr %p6289, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1636
bb_rchprepared1636:
  %v6290 = load i64, ptr %slot22, align 8
  %p6291 = inttoptr i64 %v6290 to ptr
  store i32 2, ptr %p6291, align 4, !alias.scope !3, !noalias !4
  %v6292 = load i64, ptr %slot21, align 8
  %p6293 = inttoptr i64 %v6292 to ptr
  store i32 1, ptr %p6293, align 4, !alias.scope !3, !noalias !4
  %v6294 = load i64, ptr %slot25, align 8
  store i64 %v6294, ptr %slot1045, align 8
  %v6295 = load i64, ptr %slot28, align 8
  store i64 %v6295, ptr %slot1046, align 8
  %v6296 = load i64, ptr %slot1046, align 8
  %v6297 = load i64, ptr %slot1045, align 8
  %p6298 = inttoptr i64 %v6296 to ptr
  %p6299 = inttoptr i64 %v6297 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6299, ptr %p6298, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v6300 = load i64, ptr %slot20, align 8
  %p6301 = inttoptr i64 %v6300 to ptr
  store i32 2, ptr %p6301, align 4, !alias.scope !3, !noalias !4
  %v6302 = load i64, ptr %slot22, align 8
  %p6303 = inttoptr i64 %v6302 to ptr
  %ld6304 = load i32, ptr %p6303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6304, ptr %slot1047, align 8
  %v6305 = load i32, ptr %slot1047, align 8
  %v6306 = load i64, ptr %slot20, align 8
  %p6307 = inttoptr i64 %v6306 to ptr
  store i32 %v6305, ptr %p6307, align 4, !alias.scope !3, !noalias !4
  %v6308 = load i64, ptr %slot21, align 8
  %p6309 = inttoptr i64 %v6308 to ptr
  store i32 0, ptr %p6309, align 4, !alias.scope !3, !noalias !4
  %v6310 = load i64, ptr %slot19, align 8
  %p6311 = inttoptr i64 %v6310 to ptr
  store i32 1, ptr %p6311, align 4, !alias.scope !3, !noalias !4
  %v6312 = load i64, ptr %slot1045, align 8
  %v6313 = load i64, ptr %slot58, align 8
  %p6314 = inttoptr i64 %v6313 to ptr
  store i64 %v6312, ptr %p6314, align 8, !alias.scope !3, !noalias !4
  %v6315 = load i64, ptr %slot57, align 8
  %p6316 = inttoptr i64 %v6315 to ptr
  %ld6317 = load i64, ptr %p6316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6317, ptr %slot1048, align 8
  %v6318 = load i64, ptr %slot17, align 8
  %p6319 = inttoptr i64 %v6318 to ptr
  %ld6320 = load i32, ptr %p6319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6320, ptr %slot1049, align 8
  %v6321 = load i64, ptr %slot18, align 8
  %p6322 = inttoptr i64 %v6321 to ptr
  %ld6323 = load i32, ptr %p6322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6323, ptr %slot1050, align 8
  %v6324 = load i32, ptr %slot1050, align 8
  %op6325 = and i32 %v6324, 24
  store i32 %op6325, ptr %slot1050, align 8
  %v6326 = load i32, ptr %slot1050, align 8
  %cmp6327 = icmp eq i32 %v6326, 0
  %cv6328 = zext i1 %cmp6327 to i32
  store i32 %cv6328, ptr %slot1051, align 8
  %v6329 = load i32, ptr %slot1049, align 8
  %v6330 = load i32, ptr %slot1051, align 8
  %op6331 = and i32 %v6329, %v6330
  store i32 %op6331, ptr %slot1052, align 8
  %v6332 = load i32, ptr %slot1052, align 8
  %cv6333 = zext i32 %v6332 to i64
  %cond6334 = icmp ne i64 %cv6333, 0
  br i1 %cond6334, label %bb_rctake1658, label %bb_rccopy1658
bb_rctake1658:
  %v6335 = load i64, ptr %slot28, align 8
  store i64 %v6335, ptr %slot1053, align 8
  %v6336 = load i64, ptr %slot71, align 8
  store i64 %v6336, ptr %slot1054, align 8
  %v6337 = load i64, ptr %slot70, align 8
  %v6338 = load i64, ptr %slot1053, align 8
  %v6339 = load i64, ptr %slot1048, align 8
  %v6340 = load i64, ptr %slot1054, align 8
  %cv6341 = trunc i64 %v6340 to i32
  %call6342 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v6337, i64 %v6338, i64 %v6339, i32 %cv6341) nomerge, !dbg !168
  store i32 %call6342, ptr %slot1055, align 8
  %v6343 = load i32, ptr %slot1055, align 8
  %cv6344 = zext i32 %v6343 to i64
  %cond6345 = icmp ne i64 %cv6344, 0
  br i1 %cond6345, label %bb_rcsuccess1668, label %bb_rcfailure1668
bb_rcfailure1668:
  %v6346 = load i64, ptr %slot70, align 8
  %p6347 = inttoptr i64 %v6346 to ptr
  %call6348 = call i32 @myl_rc_take_failure(ptr %p6347) nomerge, !dbg !168
  store i32 %call6348, ptr %slot1056, align 8
  %v6349 = load i64, ptr %slot1, align 8
  %p6350 = inttoptr i64 %v6349 to ptr
  %v6351 = load i32, ptr %slot1056, align 8
  %call6352 = call i32 @myl_qbe_rc_status(ptr %p6350, i32 %v6351) nomerge, !dbg !168
  store i32 %call6352, ptr %slot1057, align 8
  br label %bb_failure
bb_rcsuccess1668:
  %v6353 = load i64, ptr %slot17, align 8
  %p6354 = inttoptr i64 %v6353 to ptr
  store i32 0, ptr %p6354, align 4, !alias.scope !3, !noalias !4
  %v6355 = load i64, ptr %slot22, align 8
  %p6356 = inttoptr i64 %v6355 to ptr
  store i32 2, ptr %p6356, align 4, !alias.scope !3, !noalias !4
  %v6357 = load i64, ptr %slot21, align 8
  %p6358 = inttoptr i64 %v6357 to ptr
  store i32 1, ptr %p6358, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1658
bb_rccopy1658:
  %v6359 = load i64, ptr %slot28, align 8
  store i64 %v6359, ptr %slot1058, align 8
  %v6360 = load i64, ptr %slot71, align 8
  store i64 %v6360, ptr %slot1059, align 8
  %v6361 = load i64, ptr %slot70, align 8
  %v6362 = load i64, ptr %slot1058, align 8
  %v6363 = load i64, ptr %slot1048, align 8
  %v6364 = load i64, ptr %slot1059, align 8
  %cv6365 = trunc i64 %v6364 to i32
  %call6366 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v6361, i64 %v6362, i64 %v6363, i32 %cv6365) nomerge, !dbg !168
  store i32 %call6366, ptr %slot1060, align 8
  %v6367 = load i32, ptr %slot1060, align 8
  %cv6368 = zext i32 %v6367 to i64
  %cond6369 = icmp ne i64 %cv6368, 0
  br i1 %cond6369, label %bb_rcsuccess1677, label %bb_rcfailure1677
bb_rcfailure1677:
  %v6370 = load i64, ptr %slot70, align 8
  %p6371 = inttoptr i64 %v6370 to ptr
  %call6372 = call i32 @myl_rc_take_failure(ptr %p6371) nomerge, !dbg !168
  store i32 %call6372, ptr %slot1061, align 8
  %v6373 = load i64, ptr %slot1, align 8
  %p6374 = inttoptr i64 %v6373 to ptr
  %v6375 = load i32, ptr %slot1061, align 8
  %call6376 = call i32 @myl_qbe_rc_status(ptr %p6374, i32 %v6375) nomerge, !dbg !168
  store i32 %call6376, ptr %slot1062, align 8
  br label %bb_failure
bb_rcsuccess1677:
  %v6377 = load i64, ptr %slot22, align 8
  %p6378 = inttoptr i64 %v6377 to ptr
  store i32 2, ptr %p6378, align 4, !alias.scope !3, !noalias !4
  %v6379 = load i64, ptr %slot21, align 8
  %p6380 = inttoptr i64 %v6379 to ptr
  store i32 1, ptr %p6380, align 4, !alias.scope !3, !noalias !4
  %v6381 = load i64, ptr %slot17, align 8
  %p6382 = inttoptr i64 %v6381 to ptr
  %ld6383 = load i32, ptr %p6382, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6383, ptr %slot1063, align 8
  %v6384 = load i32, ptr %slot1063, align 8
  %cv6385 = zext i32 %v6384 to i64
  %cond6386 = icmp ne i64 %cv6385, 0
  br i1 %cond6386, label %bb_rcslotdrop1684, label %bb_rcslotdone1684
bb_rcslotdrop1684:
  %v6387 = load i64, ptr %slot17, align 8
  %p6388 = inttoptr i64 %v6387 to ptr
  store i32 0, ptr %p6388, align 4, !alias.scope !3, !noalias !4
  %v6389 = load i64, ptr %slot24, align 8
  store i64 %v6389, ptr %slot1064, align 8
  %v6390 = load i64, ptr %slot18, align 8
  %p6391 = inttoptr i64 %v6390 to ptr
  %ld6392 = load i32, ptr %p6391, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6392, ptr %slot1065, align 8
  %v6393 = load i32, ptr %slot1065, align 8
  %op6394 = and i32 %v6393, 28
  store i32 %op6394, ptr %slot1066, align 8
  %v6395 = load i32, ptr %slot1066, align 8
  %cv6396 = zext i32 %v6395 to i64
  %cond6397 = icmp ne i64 %cv6396, 0
  br i1 %cond6397, label %bb_rcslotrole1684, label %bb_rcslotowner1684
bb_rcslotrole1684:
  %v6398 = load i64, ptr %slot70, align 8
  store i64 %v6398, ptr %slot1067, align 8
  %v6399 = load i64, ptr %slot1067, align 8
  %v6400 = load i64, ptr %slot1064, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6399, i64 %v6400) nomerge, !dbg !168
  br label %bb_rcslotdone1684
bb_rcslotowner1684:
  %v6401 = load i64, ptr %slot70, align 8
  store i64 %v6401, ptr %slot1068, align 8
  %v6402 = load i64, ptr %slot1068, align 8
  %v6403 = load i64, ptr %slot1064, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6402, i64 %v6403) nomerge, !dbg !168
  br label %bb_rcslotdone1684
bb_rcslotdone1684:
  br label %bb_rcprepared1658
bb_rcprepared1658:
  %v6404 = load i64, ptr %slot28, align 8
  store i64 %v6404, ptr %slot1069, align 8
  %v6405 = load i64, ptr %slot62, align 8
  store i64 %v6405, ptr %slot1070, align 8
  %v6406 = load i64, ptr %slot1069, align 8
  %v6407 = load i64, ptr %slot1070, align 8
  %p6408 = inttoptr i64 %v6406 to ptr
  %p6409 = inttoptr i64 %v6407 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6409, ptr %p6408, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v6410 = load i64, ptr %slot21, align 8
  %p6411 = inttoptr i64 %v6410 to ptr
  store i32 0, ptr %p6411, align 4, !alias.scope !3, !noalias !4
  %v6412 = load i64, ptr %slot23, align 8
  %p6413 = inttoptr i64 %v6412 to ptr
  store i32 1, ptr %p6413, align 4, !alias.scope !3, !noalias !4
  %v6414 = load i64, ptr %slot71, align 8
  store i64 %v6414, ptr %slot1071, align 8
  %v6415 = load i64, ptr %slot58, align 8
  %p6416 = inttoptr i64 %v6415 to ptr
  %ld6417 = load i64, ptr %p6416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6417, ptr %slot1072, align 8
  %v6418 = load i64, ptr %slot1070, align 8
  %p6420 = inttoptr i64 %v6418 to ptr
  %gep6421 = getelementptr i8, ptr %p6420, i64 0
  %op6419 = ptrtoint ptr %gep6421 to i64
  store i64 %op6419, ptr %slot1073, align 8
  %v6422 = load i64, ptr %slot28, align 8
  store i64 %v6422, ptr %slot1074, align 8
  %v6423 = load i64, ptr %slot58, align 8
  %p6424 = inttoptr i64 %v6423 to ptr
  %ld6425 = load i64, ptr %p6424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6425, ptr %slot1075, align 8
  %v6426 = load i64, ptr %slot28, align 8
  store i64 %v6426, ptr %slot1076, align 8
  %v6427 = load i64, ptr %slot71, align 8
  store i64 %v6427, ptr %slot1077, align 8
  %v6428 = load i64, ptr %slot1075, align 8
  %op6429 = add i64 %v6428, 16
  store i64 %op6429, ptr %slot1078, align 8
  %v6430 = load i64, ptr %slot1078, align 8
  %p6431 = inttoptr i64 %v6430 to ptr
  %ld6432 = load i64, ptr %p6431, align 8
  store i64 %ld6432, ptr %slot1079, align 8
  %v6433 = load i64, ptr %slot1079, align 8
  %cmp6434 = icmp ne i64 %v6433, 0
  %cv6435 = zext i1 %cmp6434 to i32
  store i32 %cv6435, ptr %slot1080, align 8
  %v6436 = load i32, ptr %slot1080, align 8
  %cv6437 = zext i32 %v6436 to i64
  %cond6438 = icmp ne i64 %cv6437, 0
  br i1 %cond6438, label %bb_rcmoveheader1706, label %bb_rcmovenext1706
bb_rcmoveheader1706:
  %v6439 = load i64, ptr %slot1079, align 8
  %op6440 = sub i64 %v6439, 16
  store i64 %op6440, ptr %slot1081, align 8
  %v6441 = load i64, ptr %slot1079, align 8
  %p6442 = inttoptr i64 %v6441 to ptr
  %rgep6443 = getelementptr i8, ptr %p6442, i64 -16
  %ld6444 = load i64, ptr %rgep6443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6444, ptr %slot1082, align 8
  %v6445 = load i64, ptr %slot1082, align 8
  %op6446 = and i64 %v6445, 5764607523034234881
  store i64 %op6446, ptr %slot1083, align 8
  %v6447 = load i64, ptr %slot1083, align 8
  %cmp6448 = icmp ne i64 %v6447, 0
  %cv6449 = zext i1 %cmp6448 to i32
  store i32 %cv6449, ptr %slot1084, align 8
  %v6450 = load i32, ptr %slot1084, align 8
  %cv6451 = zext i32 %v6450 to i64
  %cond6452 = icmp ne i64 %cv6451, 0
  br i1 %cond6452, label %bb_rcmoveslow1703, label %bb_rcmovenext1706
bb_rcmovenext1706:
  %v6453 = load i64, ptr %slot1075, align 8
  %op6454 = add i64 %v6453, 24
  store i64 %op6454, ptr %slot1085, align 8
  %v6455 = load i64, ptr %slot1085, align 8
  %p6456 = inttoptr i64 %v6455 to ptr
  %ld6457 = load i64, ptr %p6456, align 8
  store i64 %ld6457, ptr %slot1086, align 8
  %v6458 = load i64, ptr %slot1086, align 8
  %cmp6459 = icmp ne i64 %v6458, 0
  %cv6460 = zext i1 %cmp6459 to i32
  store i32 %cv6460, ptr %slot1087, align 8
  %v6461 = load i32, ptr %slot1087, align 8
  %cv6462 = zext i32 %v6461 to i64
  %cond6463 = icmp ne i64 %cv6462, 0
  br i1 %cond6463, label %bb_rcmoveheader1714, label %bb_rcmovenext1714
bb_rcmoveheader1714:
  %v6464 = load i64, ptr %slot1086, align 8
  %op6465 = sub i64 %v6464, 16
  store i64 %op6465, ptr %slot1088, align 8
  %v6466 = load i64, ptr %slot1086, align 8
  %p6467 = inttoptr i64 %v6466 to ptr
  %rgep6468 = getelementptr i8, ptr %p6467, i64 -16
  %ld6469 = load i64, ptr %rgep6468, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6469, ptr %slot1089, align 8
  %v6470 = load i64, ptr %slot1089, align 8
  %op6471 = and i64 %v6470, 5764607523034234881
  store i64 %op6471, ptr %slot1090, align 8
  %v6472 = load i64, ptr %slot1090, align 8
  %cmp6473 = icmp ne i64 %v6472, 0
  %cv6474 = zext i1 %cmp6473 to i32
  store i32 %cv6474, ptr %slot1091, align 8
  %v6475 = load i32, ptr %slot1091, align 8
  %cv6476 = zext i32 %v6475 to i64
  %cond6477 = icmp ne i64 %cv6476, 0
  br i1 %cond6477, label %bb_rcmoveslow1703, label %bb_rcmovenext1714
bb_rcmovenext1714:
  %v6478 = load i64, ptr %slot1075, align 8
  %op6479 = add i64 %v6478, 32
  store i64 %op6479, ptr %slot1092, align 8
  %v6480 = load i64, ptr %slot1092, align 8
  %p6481 = inttoptr i64 %v6480 to ptr
  %ld6482 = load i64, ptr %p6481, align 8
  store i64 %ld6482, ptr %slot1093, align 8
  %v6483 = load i64, ptr %slot1093, align 8
  %cmp6484 = icmp ne i64 %v6483, 0
  %cv6485 = zext i1 %cmp6484 to i32
  store i32 %cv6485, ptr %slot1094, align 8
  %v6486 = load i32, ptr %slot1094, align 8
  %cv6487 = zext i32 %v6486 to i64
  %cond6488 = icmp ne i64 %cv6487, 0
  br i1 %cond6488, label %bb_rcmoveheader1722, label %bb_rcmovenext1722
bb_rcmoveheader1722:
  %v6489 = load i64, ptr %slot1093, align 8
  %op6490 = sub i64 %v6489, 16
  store i64 %op6490, ptr %slot1095, align 8
  %v6491 = load i64, ptr %slot1093, align 8
  %p6492 = inttoptr i64 %v6491 to ptr
  %rgep6493 = getelementptr i8, ptr %p6492, i64 -16
  %ld6494 = load i64, ptr %rgep6493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6494, ptr %slot1096, align 8
  %v6495 = load i64, ptr %slot1096, align 8
  %op6496 = and i64 %v6495, 5764607523034234881
  store i64 %op6496, ptr %slot1097, align 8
  %v6497 = load i64, ptr %slot1097, align 8
  %cmp6498 = icmp ne i64 %v6497, 0
  %cv6499 = zext i1 %cmp6498 to i32
  store i32 %cv6499, ptr %slot1098, align 8
  %v6500 = load i32, ptr %slot1098, align 8
  %cv6501 = zext i32 %v6500 to i64
  %cond6502 = icmp ne i64 %cv6501, 0
  br i1 %cond6502, label %bb_rcmoveslow1703, label %bb_rcmovenext1722
bb_rcmovenext1722:
  %v6503 = load i64, ptr %slot1075, align 8
  %v6504 = load i64, ptr %slot1076, align 8
  %p6505 = inttoptr i64 %v6503 to ptr
  %p6506 = inttoptr i64 %v6504 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6506, ptr %p6505, i64 48, i1 false)
  %v6507 = load i64, ptr %slot1075, align 8
  %p6508 = inttoptr i64 %v6507 to ptr
  store i64 0, ptr %p6508, align 8
  %v6509 = load i64, ptr %slot1075, align 8
  %op6510 = add i64 %v6509, 8
  store i64 %op6510, ptr %slot1099, align 8
  %v6511 = load i64, ptr %slot1099, align 8
  %p6512 = inttoptr i64 %v6511 to ptr
  store i64 0, ptr %p6512, align 8
  %v6513 = load i64, ptr %slot1075, align 8
  %op6514 = add i64 %v6513, 16
  store i64 %op6514, ptr %slot1100, align 8
  %v6515 = load i64, ptr %slot1100, align 8
  %p6516 = inttoptr i64 %v6515 to ptr
  store i64 0, ptr %p6516, align 8
  %v6517 = load i64, ptr %slot1075, align 8
  %op6518 = add i64 %v6517, 24
  store i64 %op6518, ptr %slot1101, align 8
  %v6519 = load i64, ptr %slot1101, align 8
  %p6520 = inttoptr i64 %v6519 to ptr
  store i64 0, ptr %p6520, align 8
  %v6521 = load i64, ptr %slot1075, align 8
  %op6522 = add i64 %v6521, 32
  store i64 %op6522, ptr %slot1102, align 8
  %v6523 = load i64, ptr %slot1102, align 8
  %p6524 = inttoptr i64 %v6523 to ptr
  store i64 0, ptr %p6524, align 8
  %v6525 = load i64, ptr %slot1075, align 8
  %op6526 = add i64 %v6525, 40
  store i64 %op6526, ptr %slot1103, align 8
  %v6527 = load i64, ptr %slot1103, align 8
  %p6528 = inttoptr i64 %v6527 to ptr
  store i64 0, ptr %p6528, align 8
  br label %bb_rcmoved1703
bb_rcmoveslow1703:
  %v6529 = load i64, ptr %slot70, align 8
  %v6530 = load i64, ptr %slot1076, align 8
  %v6531 = load i64, ptr %slot1075, align 8
  %v6532 = load i64, ptr %slot1077, align 8
  %cv6533 = trunc i64 %v6532 to i32
  %call6534 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v6529, i64 %v6530, i64 %v6531, i32 %cv6533) nomerge, !dbg !168
  store i32 %call6534, ptr %slot1104, align 8
  %v6535 = load i32, ptr %slot1104, align 8
  %cv6536 = zext i32 %v6535 to i64
  %cond6537 = icmp ne i64 %cv6536, 0
  br i1 %cond6537, label %bb_rcsuccess1734, label %bb_rcfailure1734
bb_rcfailure1734:
  %v6538 = load i64, ptr %slot70, align 8
  %p6539 = inttoptr i64 %v6538 to ptr
  %call6540 = call i32 @myl_rc_take_failure(ptr %p6539) nomerge, !dbg !168
  store i32 %call6540, ptr %slot1105, align 8
  %v6541 = load i64, ptr %slot1, align 8
  %p6542 = inttoptr i64 %v6541 to ptr
  %v6543 = load i32, ptr %slot1105, align 8
  %call6544 = call i32 @myl_qbe_rc_status(ptr %p6542, i32 %v6543) nomerge, !dbg !168
  store i32 %call6544, ptr %slot1106, align 8
  br label %bb_failure
bb_rcsuccess1734:
  br label %bb_rcmoved1703
bb_rcmoved1703:
  %v6545 = load i64, ptr %slot19, align 8
  %p6546 = inttoptr i64 %v6545 to ptr
  store i32 0, ptr %p6546, align 4, !alias.scope !3, !noalias !4
  %v6547 = load i64, ptr %slot22, align 8
  %p6548 = inttoptr i64 %v6547 to ptr
  store i32 2, ptr %p6548, align 4, !alias.scope !3, !noalias !4
  %v6549 = load i64, ptr %slot21, align 8
  %p6550 = inttoptr i64 %v6549 to ptr
  store i32 1, ptr %p6550, align 4, !alias.scope !3, !noalias !4
  %v6551 = load i64, ptr %slot28, align 8
  store i64 %v6551, ptr %slot1107, align 8
  %v6552 = load i64, ptr %slot1107, align 8
  %v6553 = load i64, ptr %slot1074, align 8
  %p6554 = inttoptr i64 %v6552 to ptr
  %p6555 = inttoptr i64 %v6553 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6555, ptr %p6554, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v6556 = load i64, ptr %slot21, align 8
  %p6557 = inttoptr i64 %v6556 to ptr
  store i32 0, ptr %p6557, align 4, !alias.scope !3, !noalias !4
  %v6558 = load i64, ptr %slot22, align 8
  %p6559 = inttoptr i64 %v6558 to ptr
  store i32 2, ptr %p6559, align 4, !alias.scope !3, !noalias !4
  %v6560 = load i64, ptr %slot21, align 8
  %p6561 = inttoptr i64 %v6560 to ptr
  store i32 1, ptr %p6561, align 4, !alias.scope !3, !noalias !4
  %v6562 = load i64, ptr %slot70, align 8
  store i64 %v6562, ptr %slot1108, align 8
  %v6563 = load i64, ptr %slot1108, align 8
  %v6564 = load i64, ptr %slot1073, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v6563, i64 %v6564) nomerge, !dbg !168
  %v6565 = load i64, ptr %slot1074, align 8
  %v6566 = load i64, ptr %slot1073, align 8
  %p6567 = inttoptr i64 %v6565 to ptr
  %p6568 = inttoptr i64 %v6566 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6568, ptr %p6567, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v6569 = load i64, ptr %slot21, align 8
  %p6570 = inttoptr i64 %v6569 to ptr
  store i32 0, ptr %p6570, align 4, !alias.scope !3, !noalias !4
  %v6571 = load i64, ptr %slot1070, align 8
  %v6572 = load i64, ptr %slot57, align 8
  %p6573 = inttoptr i64 %v6572 to ptr
  store i64 %v6571, ptr %p6573, align 8, !alias.scope !3, !noalias !4
  %v6574 = load i64, ptr %slot57, align 8
  %p6575 = inttoptr i64 %v6574 to ptr
  %ld6576 = load i64, ptr %p6575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6576, ptr %slot1109, align 8
  %v6577 = load i64, ptr %slot28, align 8
  store i64 %v6577, ptr %slot1110, align 8
  %v6578 = load i64, ptr %slot1109, align 8
  %v6579 = load i64, ptr %slot1110, align 8
  %p6580 = inttoptr i64 %v6578 to ptr
  %p6581 = inttoptr i64 %v6579 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6581, ptr %p6580, i64 88, i1 false)
  %v6582 = load i64, ptr %slot22, align 8
  %p6583 = inttoptr i64 %v6582 to ptr
  store i32 2, ptr %p6583, align 4, !alias.scope !3, !noalias !4
  %v6584 = load i64, ptr %slot21, align 8
  %p6585 = inttoptr i64 %v6584 to ptr
  store i32 1, ptr %p6585, align 4, !alias.scope !3, !noalias !4
  %v6586 = load i64, ptr %slot17, align 8
  %p6587 = inttoptr i64 %v6586 to ptr
  %ld6588 = load i32, ptr %p6587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6588, ptr %slot1111, align 8
  %v6589 = load i32, ptr %slot1111, align 8
  %cv6590 = zext i32 %v6589 to i64
  %cond6591 = icmp ne i64 %cv6590, 0
  br i1 %cond6591, label %bb_rcslotdrop1752, label %bb_rcslotdone1752
bb_rcslotdrop1752:
  %v6592 = load i64, ptr %slot17, align 8
  %p6593 = inttoptr i64 %v6592 to ptr
  store i32 0, ptr %p6593, align 4, !alias.scope !3, !noalias !4
  %v6594 = load i64, ptr %slot24, align 8
  store i64 %v6594, ptr %slot1112, align 8
  %v6595 = load i64, ptr %slot18, align 8
  %p6596 = inttoptr i64 %v6595 to ptr
  %ld6597 = load i32, ptr %p6596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6597, ptr %slot1113, align 8
  %v6598 = load i32, ptr %slot1113, align 8
  %op6599 = and i32 %v6598, 28
  store i32 %op6599, ptr %slot1114, align 8
  %v6600 = load i32, ptr %slot1114, align 8
  %cv6601 = zext i32 %v6600 to i64
  %cond6602 = icmp ne i64 %cv6601, 0
  br i1 %cond6602, label %bb_rcslotrole1752, label %bb_rcslotowner1752
bb_rcslotrole1752:
  %v6603 = load i64, ptr %slot70, align 8
  store i64 %v6603, ptr %slot1115, align 8
  %v6604 = load i64, ptr %slot1115, align 8
  %v6605 = load i64, ptr %slot1112, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6604, i64 %v6605) nomerge, !dbg !168
  br label %bb_rcslotdone1752
bb_rcslotowner1752:
  %v6606 = load i64, ptr %slot70, align 8
  store i64 %v6606, ptr %slot1116, align 8
  %v6607 = load i64, ptr %slot1116, align 8
  %v6608 = load i64, ptr %slot1112, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6607, i64 %v6608) nomerge, !dbg !168
  br label %bb_rcslotdone1752
bb_rcslotdone1752:
  %v6609 = load i64, ptr %slot19, align 8
  %p6610 = inttoptr i64 %v6609 to ptr
  %ld6611 = load i32, ptr %p6610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6611, ptr %slot1117, align 8
  %v6612 = load i32, ptr %slot1117, align 8
  %cv6613 = zext i32 %v6612 to i64
  %cond6614 = icmp ne i64 %cv6613, 0
  br i1 %cond6614, label %bb_rcslotdrop1761, label %bb_rcslotdone1761
bb_rcslotdrop1761:
  %v6615 = load i64, ptr %slot19, align 8
  %p6616 = inttoptr i64 %v6615 to ptr
  store i32 0, ptr %p6616, align 4, !alias.scope !3, !noalias !4
  %v6617 = load i64, ptr %slot25, align 8
  store i64 %v6617, ptr %slot1118, align 8
  %v6618 = load i64, ptr %slot20, align 8
  %p6619 = inttoptr i64 %v6618 to ptr
  %ld6620 = load i32, ptr %p6619, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6620, ptr %slot1119, align 8
  %v6621 = load i32, ptr %slot1119, align 8
  %op6622 = and i32 %v6621, 28
  store i32 %op6622, ptr %slot1120, align 8
  %v6623 = load i32, ptr %slot1120, align 8
  %cv6624 = zext i32 %v6623 to i64
  %cond6625 = icmp ne i64 %cv6624, 0
  br i1 %cond6625, label %bb_rcslotrole1761, label %bb_rcslotowner1761
bb_rcslotrole1761:
  %v6626 = load i64, ptr %slot70, align 8
  store i64 %v6626, ptr %slot1121, align 8
  %v6627 = load i64, ptr %slot1121, align 8
  %v6628 = load i64, ptr %slot1118, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v6627, i64 %v6628) nomerge, !dbg !168
  br label %bb_rcslotdone1761
bb_rcslotowner1761:
  %v6629 = load i64, ptr %slot70, align 8
  store i64 %v6629, ptr %slot1122, align 8
  %v6630 = load i64, ptr %slot1122, align 8
  %v6631 = load i64, ptr %slot1118, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v6630, i64 %v6631) nomerge, !dbg !168
  br label %bb_rcslotdone1761
bb_rcslotdone1761:
  %v6632 = load i64, ptr %slot24, align 8
  store i64 %v6632, ptr %slot1123, align 8
  %v6633 = load i64, ptr %slot28, align 8
  store i64 %v6633, ptr %slot1124, align 8
  %v6634 = load i64, ptr %slot1124, align 8
  %v6635 = load i64, ptr %slot1123, align 8
  %p6636 = inttoptr i64 %v6634 to ptr
  %p6637 = inttoptr i64 %v6635 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6637, ptr %p6636, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v6638 = load i64, ptr %slot18, align 8
  %p6639 = inttoptr i64 %v6638 to ptr
  store i32 2, ptr %p6639, align 4, !alias.scope !3, !noalias !4
  %v6640 = load i64, ptr %slot22, align 8
  %p6641 = inttoptr i64 %v6640 to ptr
  %ld6642 = load i32, ptr %p6641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6642, ptr %slot1125, align 8
  %v6643 = load i32, ptr %slot1125, align 8
  %v6644 = load i64, ptr %slot18, align 8
  %p6645 = inttoptr i64 %v6644 to ptr
  store i32 %v6643, ptr %p6645, align 4, !alias.scope !3, !noalias !4
  %v6646 = load i64, ptr %slot21, align 8
  %p6647 = inttoptr i64 %v6646 to ptr
  store i32 0, ptr %p6647, align 4, !alias.scope !3, !noalias !4
  %v6648 = load i64, ptr %slot17, align 8
  %p6649 = inttoptr i64 %v6648 to ptr
  store i32 1, ptr %p6649, align 4, !alias.scope !3, !noalias !4
  %v6650 = load i64, ptr %slot1123, align 8
  %v6651 = load i64, ptr %slot57, align 8
  %p6652 = inttoptr i64 %v6651 to ptr
  store i64 %v6650, ptr %p6652, align 8, !alias.scope !3, !noalias !4
  %v6653 = load i64, ptr %slot57, align 8
  %p6654 = inttoptr i64 %v6653 to ptr
  %ld6655 = load i64, ptr %p6654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6655, ptr %slot1126, align 8
  %v6656 = load i64, ptr %slot17, align 8
  %p6657 = inttoptr i64 %v6656 to ptr
  %ld6658 = load i32, ptr %p6657, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6658, ptr %slot1127, align 8
  %v6659 = load i64, ptr %slot18, align 8
  %p6660 = inttoptr i64 %v6659 to ptr
  %ld6661 = load i32, ptr %p6660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6661, ptr %slot1128, align 8
  %v6662 = load i32, ptr %slot1128, align 8
  %op6663 = and i32 %v6662, 24
  store i32 %op6663, ptr %slot1128, align 8
  %v6664 = load i32, ptr %slot1128, align 8
  %cmp6665 = icmp eq i32 %v6664, 0
  %cv6666 = zext i1 %cmp6665 to i32
  store i32 %cv6666, ptr %slot1129, align 8
  %v6667 = load i32, ptr %slot1127, align 8
  %v6668 = load i32, ptr %slot1129, align 8
  %op6669 = and i32 %v6667, %v6668
  store i32 %op6669, ptr %slot1130, align 8
  %v6670 = load i32, ptr %slot1130, align 8
  %cv6671 = zext i32 %v6670 to i64
  %cond6672 = icmp ne i64 %cv6671, 0
  br i1 %cond6672, label %bb_rctake1777, label %bb_rccopy1777
bb_rctake1777:
  %v6673 = load i64, ptr %slot28, align 8
  store i64 %v6673, ptr %slot1131, align 8
  %v6674 = load i64, ptr %slot71, align 8
  store i64 %v6674, ptr %slot1132, align 8
  %v6675 = load i64, ptr %slot70, align 8
  %v6676 = load i64, ptr %slot1131, align 8
  %v6677 = load i64, ptr %slot1126, align 8
  %v6678 = load i64, ptr %slot1132, align 8
  %cv6679 = trunc i64 %v6678 to i32
  %call6680 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v6675, i64 %v6676, i64 %v6677, i32 %cv6679) nomerge, !dbg !170
  store i32 %call6680, ptr %slot1133, align 8
  %v6681 = load i32, ptr %slot1133, align 8
  %cv6682 = zext i32 %v6681 to i64
  %cond6683 = icmp ne i64 %cv6682, 0
  br i1 %cond6683, label %bb_rcsuccess1787, label %bb_rcfailure1787
bb_rcfailure1787:
  %v6684 = load i64, ptr %slot70, align 8
  %p6685 = inttoptr i64 %v6684 to ptr
  %call6686 = call i32 @myl_rc_take_failure(ptr %p6685) nomerge, !dbg !170
  store i32 %call6686, ptr %slot1134, align 8
  %v6687 = load i64, ptr %slot1, align 8
  %p6688 = inttoptr i64 %v6687 to ptr
  %v6689 = load i32, ptr %slot1134, align 8
  %call6690 = call i32 @myl_qbe_rc_status(ptr %p6688, i32 %v6689) nomerge, !dbg !170
  store i32 %call6690, ptr %slot1135, align 8
  br label %bb_failure
bb_rcsuccess1787:
  %v6691 = load i64, ptr %slot17, align 8
  %p6692 = inttoptr i64 %v6691 to ptr
  store i32 0, ptr %p6692, align 4, !alias.scope !3, !noalias !4
  %v6693 = load i64, ptr %slot22, align 8
  %p6694 = inttoptr i64 %v6693 to ptr
  store i32 2, ptr %p6694, align 4, !alias.scope !3, !noalias !4
  %v6695 = load i64, ptr %slot21, align 8
  %p6696 = inttoptr i64 %v6695 to ptr
  store i32 1, ptr %p6696, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1777
bb_rccopy1777:
  %v6697 = load i64, ptr %slot28, align 8
  store i64 %v6697, ptr %slot1136, align 8
  %v6698 = load i64, ptr %slot71, align 8
  store i64 %v6698, ptr %slot1137, align 8
  %v6699 = load i64, ptr %slot70, align 8
  %v6700 = load i64, ptr %slot1136, align 8
  %v6701 = load i64, ptr %slot1126, align 8
  %v6702 = load i64, ptr %slot1137, align 8
  %cv6703 = trunc i64 %v6702 to i32
  %call6704 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v6699, i64 %v6700, i64 %v6701, i32 %cv6703) nomerge, !dbg !170
  store i32 %call6704, ptr %slot1138, align 8
  %v6705 = load i32, ptr %slot1138, align 8
  %cv6706 = zext i32 %v6705 to i64
  %cond6707 = icmp ne i64 %cv6706, 0
  br i1 %cond6707, label %bb_rcsuccess1796, label %bb_rcfailure1796
bb_rcfailure1796:
  %v6708 = load i64, ptr %slot70, align 8
  %p6709 = inttoptr i64 %v6708 to ptr
  %call6710 = call i32 @myl_rc_take_failure(ptr %p6709) nomerge, !dbg !170
  store i32 %call6710, ptr %slot1139, align 8
  %v6711 = load i64, ptr %slot1, align 8
  %p6712 = inttoptr i64 %v6711 to ptr
  %v6713 = load i32, ptr %slot1139, align 8
  %call6714 = call i32 @myl_qbe_rc_status(ptr %p6712, i32 %v6713) nomerge, !dbg !170
  store i32 %call6714, ptr %slot1140, align 8
  br label %bb_failure
bb_rcsuccess1796:
  %v6715 = load i64, ptr %slot22, align 8
  %p6716 = inttoptr i64 %v6715 to ptr
  store i32 2, ptr %p6716, align 4, !alias.scope !3, !noalias !4
  %v6717 = load i64, ptr %slot21, align 8
  %p6718 = inttoptr i64 %v6717 to ptr
  store i32 1, ptr %p6718, align 4, !alias.scope !3, !noalias !4
  %v6719 = load i64, ptr %slot17, align 8
  %p6720 = inttoptr i64 %v6719 to ptr
  %ld6721 = load i32, ptr %p6720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6721, ptr %slot1141, align 8
  %v6722 = load i32, ptr %slot1141, align 8
  %cv6723 = zext i32 %v6722 to i64
  %cond6724 = icmp ne i64 %cv6723, 0
  br i1 %cond6724, label %bb_rcslotdrop1803, label %bb_rcslotdone1803
bb_rcslotdrop1803:
  %v6725 = load i64, ptr %slot17, align 8
  %p6726 = inttoptr i64 %v6725 to ptr
  store i32 0, ptr %p6726, align 4, !alias.scope !3, !noalias !4
  %v6727 = load i64, ptr %slot24, align 8
  store i64 %v6727, ptr %slot1142, align 8
  %v6728 = load i64, ptr %slot18, align 8
  %p6729 = inttoptr i64 %v6728 to ptr
  %ld6730 = load i32, ptr %p6729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6730, ptr %slot1143, align 8
  %v6731 = load i32, ptr %slot1143, align 8
  %op6732 = and i32 %v6731, 28
  store i32 %op6732, ptr %slot1144, align 8
  %v6733 = load i32, ptr %slot1144, align 8
  %cv6734 = zext i32 %v6733 to i64
  %cond6735 = icmp ne i64 %cv6734, 0
  br i1 %cond6735, label %bb_rcslotrole1803, label %bb_rcslotowner1803
bb_rcslotrole1803:
  %v6736 = load i64, ptr %slot70, align 8
  store i64 %v6736, ptr %slot1145, align 8
  %v6737 = load i64, ptr %slot1145, align 8
  %v6738 = load i64, ptr %slot1142, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6737, i64 %v6738) nomerge, !dbg !170
  br label %bb_rcslotdone1803
bb_rcslotowner1803:
  %v6739 = load i64, ptr %slot70, align 8
  store i64 %v6739, ptr %slot1146, align 8
  %v6740 = load i64, ptr %slot1146, align 8
  %v6741 = load i64, ptr %slot1142, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6740, i64 %v6741) nomerge, !dbg !170
  br label %bb_rcslotdone1803
bb_rcslotdone1803:
  br label %bb_rcprepared1777
bb_rcprepared1777:
  %v6742 = load i64, ptr %slot7, align 8
  %p6743 = inttoptr i64 %v6742 to ptr
  %ld6744 = load i32, ptr %p6743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6744, ptr %slot1147, align 8
  %v6745 = load i32, ptr %slot1147, align 8
  %cv6746 = zext i32 %v6745 to i64
  %cond6747 = icmp ne i64 %cv6746, 0
  br i1 %cond6747, label %bb_rcslotdrop1813, label %bb_rcslotdone1813
bb_rcslotdrop1813:
  %v6748 = load i64, ptr %slot7, align 8
  %p6749 = inttoptr i64 %v6748 to ptr
  store i32 0, ptr %p6749, align 4, !alias.scope !3, !noalias !4
  %v6750 = load i64, ptr %slot42, align 8
  store i64 %v6750, ptr %slot1148, align 8
  %v6751 = load i64, ptr %slot8, align 8
  %p6752 = inttoptr i64 %v6751 to ptr
  %ld6753 = load i32, ptr %p6752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6753, ptr %slot1149, align 8
  %v6754 = load i32, ptr %slot1149, align 8
  %op6755 = and i32 %v6754, 28
  store i32 %op6755, ptr %slot1150, align 8
  %v6756 = load i32, ptr %slot1150, align 8
  %cv6757 = zext i32 %v6756 to i64
  %cond6758 = icmp ne i64 %cv6757, 0
  br i1 %cond6758, label %bb_rcslotrole1813, label %bb_rcslotowner1813
bb_rcslotrole1813:
  %v6759 = load i64, ptr %slot70, align 8
  store i64 %v6759, ptr %slot1151, align 8
  %v6760 = load i64, ptr %slot1151, align 8
  %v6761 = load i64, ptr %slot1148, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6760, i64 %v6761) nomerge, !dbg !170
  br label %bb_rcslotdone1813
bb_rcslotowner1813:
  %v6762 = load i64, ptr %slot70, align 8
  store i64 %v6762, ptr %slot1152, align 8
  %v6763 = load i64, ptr %slot1152, align 8
  %v6764 = load i64, ptr %slot1148, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6763, i64 %v6764) nomerge, !dbg !170
  br label %bb_rcslotdone1813
bb_rcslotdone1813:
  %v6765 = load i64, ptr %slot42, align 8
  store i64 %v6765, ptr %slot1153, align 8
  %v6766 = load i64, ptr %slot28, align 8
  store i64 %v6766, ptr %slot1154, align 8
  %v6767 = load i64, ptr %slot1154, align 8
  %v6768 = load i64, ptr %slot1153, align 8
  %p6769 = inttoptr i64 %v6767 to ptr
  %p6770 = inttoptr i64 %v6768 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6770, ptr %p6769, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v6771 = load i64, ptr %slot21, align 8
  %p6772 = inttoptr i64 %v6771 to ptr
  store i32 0, ptr %p6772, align 4, !alias.scope !3, !noalias !4
  %v6773 = load i64, ptr %slot8, align 8
  %p6774 = inttoptr i64 %v6773 to ptr
  store i32 2, ptr %p6774, align 4, !alias.scope !3, !noalias !4
  %v6775 = load i64, ptr %slot22, align 8
  %p6776 = inttoptr i64 %v6775 to ptr
  %ld6777 = load i32, ptr %p6776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6777, ptr %slot1155, align 8
  %v6778 = load i32, ptr %slot1155, align 8
  %v6779 = load i64, ptr %slot8, align 8
  %p6780 = inttoptr i64 %v6779 to ptr
  store i32 %v6778, ptr %p6780, align 4, !alias.scope !3, !noalias !4
  %v6781 = load i64, ptr %slot7, align 8
  %p6782 = inttoptr i64 %v6781 to ptr
  store i32 1, ptr %p6782, align 4, !alias.scope !3, !noalias !4
  %v6783 = load i64, ptr %slot57, align 8
  %p6784 = inttoptr i64 %v6783 to ptr
  store i64 0, ptr %p6784, align 8, !alias.scope !3, !noalias !4
  %v6785 = load i64, ptr %slot42, align 8
  %v6786 = load i64, ptr %slot57, align 8
  %p6787 = inttoptr i64 %v6786 to ptr
  store i64 %v6785, ptr %p6787, align 8, !alias.scope !3, !noalias !4
  %v6788 = load i64, ptr %slot57, align 8
  %p6789 = inttoptr i64 %v6788 to ptr
  %ld6790 = load i64, ptr %p6789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6790, ptr %slot1156, align 8
  %v6791 = load i64, ptr %slot17, align 8
  %p6792 = inttoptr i64 %v6791 to ptr
  %ld6793 = load i32, ptr %p6792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6793, ptr %slot1157, align 8
  %v6794 = load i64, ptr %slot18, align 8
  %p6795 = inttoptr i64 %v6794 to ptr
  %ld6796 = load i32, ptr %p6795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6796, ptr %slot1158, align 8
  %v6797 = load i32, ptr %slot1158, align 8
  %op6798 = and i32 %v6797, 24
  store i32 %op6798, ptr %slot1158, align 8
  %v6799 = load i32, ptr %slot1158, align 8
  %cmp6800 = icmp eq i32 %v6799, 0
  %cv6801 = zext i1 %cmp6800 to i32
  store i32 %cv6801, ptr %slot1159, align 8
  %v6802 = load i32, ptr %slot1157, align 8
  %v6803 = load i32, ptr %slot1159, align 8
  %op6804 = and i32 %v6802, %v6803
  store i32 %op6804, ptr %slot1160, align 8
  %v6805 = load i32, ptr %slot1160, align 8
  %cv6806 = zext i32 %v6805 to i64
  %cond6807 = icmp ne i64 %cv6806, 0
  br i1 %cond6807, label %bb_rcprivateown1834, label %bb_rcprivateloan1834
bb_rcprivateown1834:
  %v6808 = load i64, ptr %slot28, align 8
  store i64 %v6808, ptr %slot1161, align 8
  %v6809 = load i64, ptr %slot71, align 8
  store i64 %v6809, ptr %slot1162, align 8
  %v6810 = load i64, ptr %slot70, align 8
  %v6811 = load i64, ptr %slot1161, align 8
  %v6812 = load i64, ptr %slot1156, align 8
  %v6813 = load i64, ptr %slot1162, align 8
  %cv6814 = trunc i64 %v6813 to i32
  %call6815 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v6810, i64 %v6811, i64 %v6812, i32 %cv6814) nomerge, !dbg !172
  store i32 %call6815, ptr %slot1163, align 8
  %v6816 = load i32, ptr %slot1163, align 8
  %cv6817 = zext i32 %v6816 to i64
  %cond6818 = icmp ne i64 %cv6817, 0
  br i1 %cond6818, label %bb_rcsuccess1838, label %bb_rcfailure1838
bb_rcfailure1838:
  %v6819 = load i64, ptr %slot70, align 8
  %p6820 = inttoptr i64 %v6819 to ptr
  %call6821 = call i32 @myl_rc_take_failure(ptr %p6820) nomerge, !dbg !172
  store i32 %call6821, ptr %slot1164, align 8
  %v6822 = load i64, ptr %slot1, align 8
  %p6823 = inttoptr i64 %v6822 to ptr
  %v6824 = load i32, ptr %slot1164, align 8
  %call6825 = call i32 @myl_qbe_rc_status(ptr %p6823, i32 %v6824) nomerge, !dbg !172
  store i32 %call6825, ptr %slot1165, align 8
  br label %bb_failure
bb_rcsuccess1838:
  %v6826 = load i64, ptr %slot17, align 8
  %p6827 = inttoptr i64 %v6826 to ptr
  store i32 0, ptr %p6827, align 4, !alias.scope !3, !noalias !4
  %v6828 = load i64, ptr %slot22, align 8
  %p6829 = inttoptr i64 %v6828 to ptr
  store i32 2, ptr %p6829, align 4, !alias.scope !3, !noalias !4
  %v6830 = load i64, ptr %slot21, align 8
  %p6831 = inttoptr i64 %v6830 to ptr
  store i32 1, ptr %p6831, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1834
bb_rcprivateloan1834:
  %v6832 = load i64, ptr %slot28, align 8
  store i64 %v6832, ptr %slot1166, align 8
  %v6833 = load i64, ptr %slot70, align 8
  %v6834 = load i64, ptr %slot1166, align 8
  %v6835 = load i64, ptr %slot1156, align 8
  %call6836 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v6833, i64 %v6834, i64 %v6835) nomerge, !dbg !172
  store i32 %call6836, ptr %slot1167, align 8
  %v6837 = load i32, ptr %slot1167, align 8
  %cv6838 = zext i32 %v6837 to i64
  %cond6839 = icmp ne i64 %cv6838, 0
  br i1 %cond6839, label %bb_rcsuccess1846, label %bb_rcfailure1846
bb_rcfailure1846:
  %v6840 = load i64, ptr %slot70, align 8
  %p6841 = inttoptr i64 %v6840 to ptr
  %call6842 = call i32 @myl_rc_take_failure(ptr %p6841) nomerge, !dbg !172
  store i32 %call6842, ptr %slot1168, align 8
  %v6843 = load i64, ptr %slot1, align 8
  %p6844 = inttoptr i64 %v6843 to ptr
  %v6845 = load i32, ptr %slot1168, align 8
  %call6846 = call i32 @myl_qbe_rc_status(ptr %p6844, i32 %v6845) nomerge, !dbg !172
  store i32 %call6846, ptr %slot1169, align 8
  br label %bb_failure
bb_rcsuccess1846:
  %v6847 = load i64, ptr %slot22, align 8
  %p6848 = inttoptr i64 %v6847 to ptr
  store i32 2, ptr %p6848, align 4, !alias.scope !3, !noalias !4
  %v6849 = load i64, ptr %slot22, align 8
  %p6850 = inttoptr i64 %v6849 to ptr
  store i32 16, ptr %p6850, align 4, !alias.scope !3, !noalias !4
  %v6851 = load i64, ptr %slot21, align 8
  %p6852 = inttoptr i64 %v6851 to ptr
  store i32 1, ptr %p6852, align 4, !alias.scope !3, !noalias !4
  %v6853 = load i64, ptr %slot17, align 8
  %p6854 = inttoptr i64 %v6853 to ptr
  %ld6855 = load i32, ptr %p6854, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6855, ptr %slot1170, align 8
  %v6856 = load i32, ptr %slot1170, align 8
  %cv6857 = zext i32 %v6856 to i64
  %cond6858 = icmp ne i64 %cv6857, 0
  br i1 %cond6858, label %bb_rcslotdrop1854, label %bb_rcslotdone1854
bb_rcslotdrop1854:
  %v6859 = load i64, ptr %slot17, align 8
  %p6860 = inttoptr i64 %v6859 to ptr
  store i32 0, ptr %p6860, align 4, !alias.scope !3, !noalias !4
  %v6861 = load i64, ptr %slot24, align 8
  store i64 %v6861, ptr %slot1171, align 8
  %v6862 = load i64, ptr %slot18, align 8
  %p6863 = inttoptr i64 %v6862 to ptr
  %ld6864 = load i32, ptr %p6863, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6864, ptr %slot1172, align 8
  %v6865 = load i32, ptr %slot1172, align 8
  %op6866 = and i32 %v6865, 28
  store i32 %op6866, ptr %slot1173, align 8
  %v6867 = load i32, ptr %slot1173, align 8
  %cv6868 = zext i32 %v6867 to i64
  %cond6869 = icmp ne i64 %cv6868, 0
  br i1 %cond6869, label %bb_rcslotrole1854, label %bb_rcslotowner1854
bb_rcslotrole1854:
  %v6870 = load i64, ptr %slot70, align 8
  store i64 %v6870, ptr %slot1174, align 8
  %v6871 = load i64, ptr %slot1174, align 8
  %v6872 = load i64, ptr %slot1171, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6871, i64 %v6872) nomerge, !dbg !172
  br label %bb_rcslotdone1854
bb_rcslotowner1854:
  %v6873 = load i64, ptr %slot70, align 8
  store i64 %v6873, ptr %slot1175, align 8
  %v6874 = load i64, ptr %slot1175, align 8
  %v6875 = load i64, ptr %slot1171, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6874, i64 %v6875) nomerge, !dbg !172
  br label %bb_rcslotdone1854
bb_rcslotdone1854:
  br label %bb_rcprivateprepared1834
bb_rcprivateprepared1834:
  %v6876 = load i64, ptr %slot13, align 8
  %p6877 = inttoptr i64 %v6876 to ptr
  %ld6878 = load i32, ptr %p6877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6878, ptr %slot1176, align 8
  %v6879 = load i32, ptr %slot1176, align 8
  %cv6880 = zext i32 %v6879 to i64
  %cond6881 = icmp ne i64 %cv6880, 0
  br i1 %cond6881, label %bb_rcslotdrop1864, label %bb_rcslotdone1864
bb_rcslotdrop1864:
  %v6882 = load i64, ptr %slot13, align 8
  %p6883 = inttoptr i64 %v6882 to ptr
  store i32 0, ptr %p6883, align 4, !alias.scope !3, !noalias !4
  %v6884 = load i64, ptr %slot52, align 8
  store i64 %v6884, ptr %slot1177, align 8
  %v6885 = load i64, ptr %slot14, align 8
  %p6886 = inttoptr i64 %v6885 to ptr
  %ld6887 = load i32, ptr %p6886, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6887, ptr %slot1178, align 8
  %v6888 = load i32, ptr %slot1178, align 8
  %op6889 = and i32 %v6888, 28
  store i32 %op6889, ptr %slot1179, align 8
  %v6890 = load i32, ptr %slot1179, align 8
  %cv6891 = zext i32 %v6890 to i64
  %cond6892 = icmp ne i64 %cv6891, 0
  br i1 %cond6892, label %bb_rcslotrole1864, label %bb_rcslotowner1864
bb_rcslotrole1864:
  %v6893 = load i64, ptr %slot70, align 8
  store i64 %v6893, ptr %slot1180, align 8
  %v6894 = load i64, ptr %slot1180, align 8
  %v6895 = load i64, ptr %slot1177, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6894, i64 %v6895) nomerge, !dbg !172
  br label %bb_rcslotdone1864
bb_rcslotowner1864:
  %v6896 = load i64, ptr %slot70, align 8
  store i64 %v6896, ptr %slot1181, align 8
  %v6897 = load i64, ptr %slot1181, align 8
  %v6898 = load i64, ptr %slot1177, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6897, i64 %v6898) nomerge, !dbg !172
  br label %bb_rcslotdone1864
bb_rcslotdone1864:
  %v6899 = load i64, ptr %slot52, align 8
  store i64 %v6899, ptr %slot1182, align 8
  %v6900 = load i64, ptr %slot28, align 8
  store i64 %v6900, ptr %slot1183, align 8
  %v6901 = load i64, ptr %slot1183, align 8
  %v6902 = load i64, ptr %slot1182, align 8
  %p6903 = inttoptr i64 %v6901 to ptr
  %p6904 = inttoptr i64 %v6902 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6904, ptr %p6903, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v6905 = load i64, ptr %slot21, align 8
  %p6906 = inttoptr i64 %v6905 to ptr
  store i32 0, ptr %p6906, align 4, !alias.scope !3, !noalias !4
  %v6907 = load i64, ptr %slot14, align 8
  %p6908 = inttoptr i64 %v6907 to ptr
  store i32 2, ptr %p6908, align 4, !alias.scope !3, !noalias !4
  %v6909 = load i64, ptr %slot22, align 8
  %p6910 = inttoptr i64 %v6909 to ptr
  %ld6911 = load i32, ptr %p6910, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6911, ptr %slot1184, align 8
  %v6912 = load i32, ptr %slot1184, align 8
  %v6913 = load i64, ptr %slot14, align 8
  %p6914 = inttoptr i64 %v6913 to ptr
  store i32 %v6912, ptr %p6914, align 4, !alias.scope !3, !noalias !4
  %v6915 = load i64, ptr %slot13, align 8
  %p6916 = inttoptr i64 %v6915 to ptr
  store i32 1, ptr %p6916, align 4, !alias.scope !3, !noalias !4
  %v6917 = load i64, ptr %slot36, align 8
  %p6918 = inttoptr i64 %v6917 to ptr
  %ld6919 = load i64, ptr %p6918, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6919, ptr %slot1185, align 8
  %v6920 = load i64, ptr %slot1185, align 8
  %v6921 = load i64, ptr %slot57, align 8
  %p6922 = inttoptr i64 %v6921 to ptr
  store i64 %v6920, ptr %p6922, align 8, !alias.scope !3, !noalias !4
  %v6923 = load i64, ptr %slot57, align 8
  %p6924 = inttoptr i64 %v6923 to ptr
  %ld6925 = load i64, ptr %p6924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6925, ptr %slot1186, align 8
  %v6926 = load i64, ptr %slot1186, align 8
  %op6927 = add i64 %v6926, 376
  store i64 %op6927, ptr %slot1187, align 8
  %v6928 = load i64, ptr %slot1187, align 8
  %p6929 = inttoptr i64 %v6928 to ptr
  %ld6930 = load i64, ptr %p6929, align 8
  store i64 %ld6930, ptr %slot1188, align 8
  %v6931 = load i64, ptr %slot1188, align 8
  %v6932 = load i64, ptr %slot57, align 8
  %p6933 = inttoptr i64 %v6932 to ptr
  store i64 %v6931, ptr %p6933, align 8, !alias.scope !3, !noalias !4
  %v6934 = load i64, ptr %slot17, align 8
  %p6935 = inttoptr i64 %v6934 to ptr
  %ld6936 = load i32, ptr %p6935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6936, ptr %slot1189, align 8
  %v6937 = load i32, ptr %slot1189, align 8
  %cv6938 = zext i32 %v6937 to i64
  %cond6939 = icmp ne i64 %cv6938, 0
  br i1 %cond6939, label %bb_rcslotdrop1884, label %bb_rcslotdone1884
bb_rcslotdrop1884:
  %v6940 = load i64, ptr %slot17, align 8
  %p6941 = inttoptr i64 %v6940 to ptr
  store i32 0, ptr %p6941, align 4, !alias.scope !3, !noalias !4
  %v6942 = load i64, ptr %slot24, align 8
  store i64 %v6942, ptr %slot1190, align 8
  %v6943 = load i64, ptr %slot18, align 8
  %p6944 = inttoptr i64 %v6943 to ptr
  %ld6945 = load i32, ptr %p6944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6945, ptr %slot1191, align 8
  %v6946 = load i32, ptr %slot1191, align 8
  %op6947 = and i32 %v6946, 28
  store i32 %op6947, ptr %slot1192, align 8
  %v6948 = load i32, ptr %slot1192, align 8
  %cv6949 = zext i32 %v6948 to i64
  %cond6950 = icmp ne i64 %cv6949, 0
  br i1 %cond6950, label %bb_rcslotrole1884, label %bb_rcslotowner1884
bb_rcslotrole1884:
  %v6951 = load i64, ptr %slot70, align 8
  store i64 %v6951, ptr %slot1193, align 8
  %v6952 = load i64, ptr %slot1193, align 8
  %v6953 = load i64, ptr %slot1190, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v6952, i64 %v6953) nomerge, !dbg !174
  br label %bb_rcslotdone1884
bb_rcslotowner1884:
  %v6954 = load i64, ptr %slot70, align 8
  store i64 %v6954, ptr %slot1194, align 8
  %v6955 = load i64, ptr %slot1194, align 8
  %v6956 = load i64, ptr %slot1190, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v6955, i64 %v6956) nomerge, !dbg !174
  br label %bb_rcslotdone1884
bb_rcslotdone1884:
  %v6957 = load i64, ptr %slot57, align 8
  %p6958 = inttoptr i64 %v6957 to ptr
  %ld6959 = load i64, ptr %p6958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6959, ptr %slot1195, align 8
  %v6960 = load i64, ptr %slot36, align 8
  %p6961 = inttoptr i64 %v6960 to ptr
  %ld6962 = load i64, ptr %p6961, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6962, ptr %slot1196, align 8
  %v6963 = load i64, ptr %slot17, align 8
  %p6964 = inttoptr i64 %v6963 to ptr
  %ld6965 = load i32, ptr %p6964, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6965, ptr %slot1197, align 8
  %v6966 = load i32, ptr %slot1197, align 8
  %cv6967 = zext i32 %v6966 to i64
  %cond6968 = icmp ne i64 %cv6967, 0
  br i1 %cond6968, label %bb_rcslotdrop1896, label %bb_rcslotdone1896
bb_rcslotdrop1896:
  %v6969 = load i64, ptr %slot17, align 8
  %p6970 = inttoptr i64 %v6969 to ptr
  store i32 0, ptr %p6970, align 4, !alias.scope !3, !noalias !4
  %v6971 = load i64, ptr %slot24, align 8
  store i64 %v6971, ptr %slot1198, align 8
  %v6972 = load i64, ptr %slot18, align 8
  %p6973 = inttoptr i64 %v6972 to ptr
  %ld6974 = load i32, ptr %p6973, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6974, ptr %slot1199, align 8
  %v6975 = load i32, ptr %slot1199, align 8
  %op6976 = and i32 %v6975, 28
  store i32 %op6976, ptr %slot1200, align 8
  %v6977 = load i32, ptr %slot1200, align 8
  %cv6978 = zext i32 %v6977 to i64
  %cond6979 = icmp ne i64 %cv6978, 0
  br i1 %cond6979, label %bb_rcslotrole1896, label %bb_rcslotowner1896
bb_rcslotrole1896:
  %v6980 = load i64, ptr %slot70, align 8
  store i64 %v6980, ptr %slot1201, align 8
  %v6981 = load i64, ptr %slot1198, align 8
  %p6982 = inttoptr i64 %v6981 to ptr
  %ld6983 = load i64, ptr %p6982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6983, ptr %slot1202, align 8
  %v6984 = load i64, ptr %slot1202, align 8
  %cmp6985 = icmp ne i64 %v6984, 0
  %cv6986 = zext i1 %cmp6985 to i32
  store i32 %cv6986, ptr %slot1203, align 8
  %v6987 = load i32, ptr %slot1203, align 8
  %cv6988 = zext i32 %v6987 to i64
  %cond6989 = icmp ne i64 %cv6988, 0
  br i1 %cond6989, label %bb_rcgnn1912, label %bb_rcgdone1912
bb_rcgnn1912:
  %v6990 = load i64, ptr %slot1202, align 8
  %op6991 = sub i64 %v6990, 16
  store i64 %op6991, ptr %slot1204, align 8
  %v6992 = load i64, ptr %slot1202, align 8
  %p6993 = inttoptr i64 %v6992 to ptr
  %rgep6994 = getelementptr i8, ptr %p6993, i64 -16
  %ld6995 = load i64, ptr %rgep6994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6995, ptr %slot1205, align 8
  %v6996 = load i64, ptr %slot1205, align 8
  %op6997 = and i64 %v6996, 4611686018427387906
  store i64 %op6997, ptr %slot1206, align 8
  %v6998 = load i64, ptr %slot1206, align 8
  %cmp6999 = icmp ne i64 %v6998, 0
  %cv7000 = zext i1 %cmp6999 to i32
  store i32 %cv7000, ptr %slot1207, align 8
  %v7001 = load i32, ptr %slot1207, align 8
  %cv7002 = zext i32 %v7001 to i64
  %cond7003 = icmp ne i64 %cv7002, 0
  br i1 %cond7003, label %bb_rcgclear1912, label %bb_rcgcounted1912
bb_rcgcounted1912:
  %v7004 = load i64, ptr %slot1202, align 8
  %op7005 = sub i64 %v7004, 24
  store i64 %op7005, ptr %slot1208, align 8
  %v7006 = load i64, ptr %slot1202, align 8
  %p7007 = inttoptr i64 %v7006 to ptr
  %rgep7008 = getelementptr i8, ptr %p7007, i64 -24
  %ld7009 = load i64, ptr %rgep7008, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7009, ptr %slot1209, align 8
  %v7010 = load i64, ptr %slot1209, align 8
  %op7011 = sub i64 %v7010, 1
  store i64 %op7011, ptr %slot1210, align 8
  %v7012 = load i64, ptr %slot1210, align 8
  %cmp7013 = icmp eq i64 %v7012, 0
  %cv7014 = zext i1 %cmp7013 to i32
  store i32 %cv7014, ptr %slot1211, align 8
  %v7015 = load i32, ptr %slot1211, align 8
  %cv7016 = zext i32 %v7015 to i64
  %cond7017 = icmp ne i64 %cv7016, 0
  br i1 %cond7017, label %bb_rcglast1912, label %bb_rcgdec1912
bb_rcglast1912:
  %v7018 = load i64, ptr %slot1202, align 8
  %op7019 = sub i64 %v7018, 32
  store i64 %op7019, ptr %slot1212, align 8
  %v7020 = load i64, ptr %slot1202, align 8
  %p7021 = inttoptr i64 %v7020 to ptr
  %rgep7022 = getelementptr i8, ptr %p7021, i64 -32
  %ld7023 = load i64, ptr %rgep7022, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7023, ptr %slot1213, align 8
  %v7024 = load i64, ptr %slot1213, align 8
  %cmp7025 = icmp ne i64 %v7024, 0
  %cv7026 = zext i1 %cmp7025 to i32
  store i32 %cv7026, ptr %slot1214, align 8
  %v7027 = load i32, ptr %slot1214, align 8
  %cv7028 = zext i32 %v7027 to i64
  %cond7029 = icmp ne i64 %cv7028, 0
  br i1 %cond7029, label %bb_rcgdec1912, label %bb_rcgslow1912
bb_rcgslow1912:
  %v7030 = load i64, ptr %slot1201, align 8
  %v7031 = load i64, ptr %slot1198, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v7030, i64 %v7031) nomerge, !dbg !176
  br label %bb_rcgdone1912
bb_rcgdec1912:
  %v7032 = load i64, ptr %slot1210, align 8
  %v7033 = load i64, ptr %slot1202, align 8
  %p7034 = inttoptr i64 %v7033 to ptr
  %rgep7035 = getelementptr i8, ptr %p7034, i64 -24
  store i64 %v7032, ptr %rgep7035, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1912
bb_rcgclear1912:
  %v7036 = load i64, ptr %slot1198, align 8
  %p7037 = inttoptr i64 %v7036 to ptr
  store i64 0, ptr %p7037, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1912
bb_rcgdone1912:
  br label %bb_rcslotdone1896
bb_rcslotowner1896:
  %v7038 = load i64, ptr %slot70, align 8
  store i64 %v7038, ptr %slot1215, align 8
  %v7039 = load i64, ptr %slot1198, align 8
  %p7040 = inttoptr i64 %v7039 to ptr
  %ld7041 = load i64, ptr %p7040, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7041, ptr %slot1216, align 8
  %v7042 = load i64, ptr %slot1216, align 8
  %cmp7043 = icmp ne i64 %v7042, 0
  %cv7044 = zext i1 %cmp7043 to i32
  store i32 %cv7044, ptr %slot1217, align 8
  %v7045 = load i32, ptr %slot1217, align 8
  %cv7046 = zext i32 %v7045 to i64
  %cond7047 = icmp ne i64 %cv7046, 0
  br i1 %cond7047, label %bb_rcgnn1927, label %bb_rcgdone1927
bb_rcgnn1927:
  %v7048 = load i64, ptr %slot1216, align 8
  %op7049 = sub i64 %v7048, 16
  store i64 %op7049, ptr %slot1218, align 8
  %v7050 = load i64, ptr %slot1216, align 8
  %p7051 = inttoptr i64 %v7050 to ptr
  %rgep7052 = getelementptr i8, ptr %p7051, i64 -16
  %ld7053 = load i64, ptr %rgep7052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7053, ptr %slot1219, align 8
  %v7054 = load i64, ptr %slot1219, align 8
  %op7055 = and i64 %v7054, 4611686018427387906
  store i64 %op7055, ptr %slot1220, align 8
  %v7056 = load i64, ptr %slot1220, align 8
  %cmp7057 = icmp ne i64 %v7056, 0
  %cv7058 = zext i1 %cmp7057 to i32
  store i32 %cv7058, ptr %slot1221, align 8
  %v7059 = load i32, ptr %slot1221, align 8
  %cv7060 = zext i32 %v7059 to i64
  %cond7061 = icmp ne i64 %cv7060, 0
  br i1 %cond7061, label %bb_rcgclear1927, label %bb_rcgcounted1927
bb_rcgcounted1927:
  %v7062 = load i64, ptr %slot1216, align 8
  %op7063 = sub i64 %v7062, 32
  store i64 %op7063, ptr %slot1222, align 8
  %v7064 = load i64, ptr %slot1216, align 8
  %p7065 = inttoptr i64 %v7064 to ptr
  %rgep7066 = getelementptr i8, ptr %p7065, i64 -32
  %ld7067 = load i64, ptr %rgep7066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7067, ptr %slot1223, align 8
  %v7068 = load i64, ptr %slot1223, align 8
  %op7069 = sub i64 %v7068, 1
  store i64 %op7069, ptr %slot1224, align 8
  %v7070 = load i64, ptr %slot1224, align 8
  %cmp7071 = icmp eq i64 %v7070, 0
  %cv7072 = zext i1 %cmp7071 to i32
  store i32 %cv7072, ptr %slot1225, align 8
  %v7073 = load i32, ptr %slot1225, align 8
  %cv7074 = zext i32 %v7073 to i64
  %cond7075 = icmp ne i64 %cv7074, 0
  br i1 %cond7075, label %bb_rcglast1927, label %bb_rcgdec1927
bb_rcglast1927:
  %v7076 = load i64, ptr %slot1216, align 8
  %op7077 = sub i64 %v7076, 24
  store i64 %op7077, ptr %slot1226, align 8
  %v7078 = load i64, ptr %slot1216, align 8
  %p7079 = inttoptr i64 %v7078 to ptr
  %rgep7080 = getelementptr i8, ptr %p7079, i64 -24
  %ld7081 = load i64, ptr %rgep7080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7081, ptr %slot1227, align 8
  %v7082 = load i64, ptr %slot1227, align 8
  %cmp7083 = icmp ne i64 %v7082, 0
  %cv7084 = zext i1 %cmp7083 to i32
  store i32 %cv7084, ptr %slot1228, align 8
  %v7085 = load i32, ptr %slot1228, align 8
  %cv7086 = zext i32 %v7085 to i64
  %cond7087 = icmp ne i64 %cv7086, 0
  br i1 %cond7087, label %bb_rcgdec1927, label %bb_rcgslow1927
bb_rcgslow1927:
  %v7088 = load i64, ptr %slot1215, align 8
  %v7089 = load i64, ptr %slot1198, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v7088, i64 %v7089) nomerge, !dbg !176
  br label %bb_rcgdone1927
bb_rcgdec1927:
  %v7090 = load i64, ptr %slot1224, align 8
  %v7091 = load i64, ptr %slot1216, align 8
  %p7092 = inttoptr i64 %v7091 to ptr
  %rgep7093 = getelementptr i8, ptr %p7092, i64 -32
  store i64 %v7090, ptr %rgep7093, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1927
bb_rcgclear1927:
  %v7094 = load i64, ptr %slot1198, align 8
  %p7095 = inttoptr i64 %v7094 to ptr
  store i64 0, ptr %p7095, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1927
bb_rcgdone1927:
  br label %bb_rcslotdone1896
bb_rcslotdone1896:
  %v7096 = load i64, ptr %slot1196, align 8
  %op7097 = add i64 %v7096, 376
  store i64 %op7097, ptr %slot1229, align 8
  store i64 0, ptr %slot1230, align 8
  %v7098 = load i64, ptr %slot1229, align 8
  %p7099 = inttoptr i64 %v7098 to ptr
  %ld7100 = load i64, ptr %p7099, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7100, ptr %slot1231, align 8
  %v7101 = load i64, ptr %slot1231, align 8
  %cmp7102 = icmp ne i64 %v7101, 0
  %cv7103 = zext i1 %cmp7102 to i32
  store i32 %cv7103, ptr %slot1232, align 8
  %v7104 = load i32, ptr %slot1232, align 8
  %cv7105 = zext i32 %v7104 to i64
  %cond7106 = icmp ne i64 %cv7105, 0
  br i1 %cond7106, label %bb_rcguniquenn1933, label %bb_rcgunique1933
bb_rcguniquenn1933:
  %v7107 = load i64, ptr %slot1231, align 8
  %op7108 = sub i64 %v7107, 16
  store i64 %op7108, ptr %slot1233, align 8
  %v7109 = load i64, ptr %slot1231, align 8
  %p7110 = inttoptr i64 %v7109 to ptr
  %rgep7111 = getelementptr i8, ptr %p7110, i64 -16
  %ld7112 = load i64, ptr %rgep7111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7112, ptr %slot1234, align 8
  %v7113 = load i64, ptr %slot1234, align 8
  %op7114 = and i64 %v7113, 6917529027641081858
  store i64 %op7114, ptr %slot1235, align 8
  %v7115 = load i64, ptr %slot1235, align 8
  %cmp7116 = icmp ne i64 %v7115, 0
  %cv7117 = zext i1 %cmp7116 to i32
  store i32 %cv7117, ptr %slot1236, align 8
  %v7118 = load i32, ptr %slot1236, align 8
  %cv7119 = zext i32 %v7118 to i64
  %cond7120 = icmp ne i64 %cv7119, 0
  br i1 %cond7120, label %bb_rcguniqueslow1933, label %bb_rcguniquecount1933
bb_rcguniquecount1933:
  %v7121 = load i64, ptr %slot1231, align 8
  %op7122 = sub i64 %v7121, 32
  store i64 %op7122, ptr %slot1237, align 8
  %v7123 = load i64, ptr %slot1231, align 8
  %p7124 = inttoptr i64 %v7123 to ptr
  %rgep7125 = getelementptr i8, ptr %p7124, i64 -32
  %ld7126 = load i64, ptr %rgep7125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7126, ptr %slot1238, align 8
  %v7127 = load i64, ptr %slot1238, align 8
  %cmp7128 = icmp ult i64 %v7127, 2
  %cv7129 = zext i1 %cmp7128 to i32
  store i32 %cv7129, ptr %slot1239, align 8
  %v7130 = load i32, ptr %slot1239, align 8
  %cv7131 = zext i32 %v7130 to i64
  %cond7132 = icmp ne i64 %cv7131, 0
  br i1 %cond7132, label %bb_rcgunique1933, label %bb_rcguniqueslow1933
bb_rcguniqueslow1933:
  %v7133 = load i64, ptr %slot1, align 8
  %p7134 = inttoptr i64 %v7133 to ptr
  %p7135 = inttoptr i64 ptrtoint (ptr @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda to i64) to ptr
  %v7136 = load i64, ptr %slot1229, align 8
  %p7137 = inttoptr i64 %v7136 to ptr
  %v7138 = load i64, ptr %slot1230, align 8
  %p7139 = inttoptr i64 %v7138 to ptr
  %call7140 = call i32 @myl_qbe_rc_unique_field(ptr %p7134, ptr %p7135, ptr %p7137, ptr %p7139) nomerge, !dbg !176
  store i32 %call7140, ptr %slot1240, align 8
  %v7141 = load i32, ptr %slot1240, align 8
  %cv7142 = zext i32 %v7141 to i64
  %cond7143 = icmp ne i64 %cv7142, 0
  br i1 %cond7143, label %bb_rcunique1943, label %bb_failure
bb_rcunique1943:
  br label %bb_rcgunique1933
bb_rcgunique1933:
  %v7144 = load i64, ptr %slot1229, align 8
  %p7145 = inttoptr i64 %v7144 to ptr
  %ld7146 = load i64, ptr %p7145, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7146, ptr %slot1241, align 8
  %v7147 = load i64, ptr %slot1241, align 8
  %v7148 = load i64, ptr %slot57, align 8
  %p7149 = inttoptr i64 %v7148 to ptr
  store i64 %v7147, ptr %p7149, align 8, !alias.scope !3, !noalias !4
  %v7150 = load i64, ptr %slot57, align 8
  %p7151 = inttoptr i64 %v7150 to ptr
  %ld7152 = load i64, ptr %p7151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7152, ptr %slot1242, align 8
  %v7153 = load i64, ptr %slot17, align 8
  %p7154 = inttoptr i64 %v7153 to ptr
  %ld7155 = load i32, ptr %p7154, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7155, ptr %slot1243, align 8
  %v7156 = load i32, ptr %slot1243, align 8
  %cv7157 = zext i32 %v7156 to i64
  %cond7158 = icmp ne i64 %cv7157, 0
  br i1 %cond7158, label %bb_rcslotdrop1948, label %bb_rcslotdone1948
bb_rcslotdrop1948:
  %v7159 = load i64, ptr %slot17, align 8
  %p7160 = inttoptr i64 %v7159 to ptr
  store i32 0, ptr %p7160, align 4, !alias.scope !3, !noalias !4
  %v7161 = load i64, ptr %slot24, align 8
  store i64 %v7161, ptr %slot1244, align 8
  %v7162 = load i64, ptr %slot18, align 8
  %p7163 = inttoptr i64 %v7162 to ptr
  %ld7164 = load i32, ptr %p7163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7164, ptr %slot1245, align 8
  %v7165 = load i32, ptr %slot1245, align 8
  %op7166 = and i32 %v7165, 28
  store i32 %op7166, ptr %slot1246, align 8
  %v7167 = load i32, ptr %slot1246, align 8
  %cv7168 = zext i32 %v7167 to i64
  %cond7169 = icmp ne i64 %cv7168, 0
  br i1 %cond7169, label %bb_rcslotrole1948, label %bb_rcslotowner1948
bb_rcslotrole1948:
  %v7170 = load i64, ptr %slot70, align 8
  store i64 %v7170, ptr %slot1247, align 8
  %v7171 = load i64, ptr %slot1244, align 8
  %p7172 = inttoptr i64 %v7171 to ptr
  %ld7173 = load i64, ptr %p7172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7173, ptr %slot1248, align 8
  %v7174 = load i64, ptr %slot1248, align 8
  %cmp7175 = icmp ne i64 %v7174, 0
  %cv7176 = zext i1 %cmp7175 to i32
  store i32 %cv7176, ptr %slot1249, align 8
  %v7177 = load i32, ptr %slot1249, align 8
  %cv7178 = zext i32 %v7177 to i64
  %cond7179 = icmp ne i64 %cv7178, 0
  br i1 %cond7179, label %bb_rcgnn1964, label %bb_rcgdone1964
bb_rcgnn1964:
  %v7180 = load i64, ptr %slot1248, align 8
  %op7181 = sub i64 %v7180, 16
  store i64 %op7181, ptr %slot1250, align 8
  %v7182 = load i64, ptr %slot1248, align 8
  %p7183 = inttoptr i64 %v7182 to ptr
  %rgep7184 = getelementptr i8, ptr %p7183, i64 -16
  %ld7185 = load i64, ptr %rgep7184, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7185, ptr %slot1251, align 8
  %v7186 = load i64, ptr %slot1251, align 8
  %op7187 = and i64 %v7186, 4611686018427387906
  store i64 %op7187, ptr %slot1252, align 8
  %v7188 = load i64, ptr %slot1252, align 8
  %cmp7189 = icmp ne i64 %v7188, 0
  %cv7190 = zext i1 %cmp7189 to i32
  store i32 %cv7190, ptr %slot1253, align 8
  %v7191 = load i32, ptr %slot1253, align 8
  %cv7192 = zext i32 %v7191 to i64
  %cond7193 = icmp ne i64 %cv7192, 0
  br i1 %cond7193, label %bb_rcgclear1964, label %bb_rcgcounted1964
bb_rcgcounted1964:
  %v7194 = load i64, ptr %slot1248, align 8
  %op7195 = sub i64 %v7194, 24
  store i64 %op7195, ptr %slot1254, align 8
  %v7196 = load i64, ptr %slot1248, align 8
  %p7197 = inttoptr i64 %v7196 to ptr
  %rgep7198 = getelementptr i8, ptr %p7197, i64 -24
  %ld7199 = load i64, ptr %rgep7198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7199, ptr %slot1255, align 8
  %v7200 = load i64, ptr %slot1255, align 8
  %op7201 = sub i64 %v7200, 1
  store i64 %op7201, ptr %slot1256, align 8
  %v7202 = load i64, ptr %slot1256, align 8
  %cmp7203 = icmp eq i64 %v7202, 0
  %cv7204 = zext i1 %cmp7203 to i32
  store i32 %cv7204, ptr %slot1257, align 8
  %v7205 = load i32, ptr %slot1257, align 8
  %cv7206 = zext i32 %v7205 to i64
  %cond7207 = icmp ne i64 %cv7206, 0
  br i1 %cond7207, label %bb_rcglast1964, label %bb_rcgdec1964
bb_rcglast1964:
  %v7208 = load i64, ptr %slot1248, align 8
  %op7209 = sub i64 %v7208, 32
  store i64 %op7209, ptr %slot1258, align 8
  %v7210 = load i64, ptr %slot1248, align 8
  %p7211 = inttoptr i64 %v7210 to ptr
  %rgep7212 = getelementptr i8, ptr %p7211, i64 -32
  %ld7213 = load i64, ptr %rgep7212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7213, ptr %slot1259, align 8
  %v7214 = load i64, ptr %slot1259, align 8
  %cmp7215 = icmp ne i64 %v7214, 0
  %cv7216 = zext i1 %cmp7215 to i32
  store i32 %cv7216, ptr %slot1260, align 8
  %v7217 = load i32, ptr %slot1260, align 8
  %cv7218 = zext i32 %v7217 to i64
  %cond7219 = icmp ne i64 %cv7218, 0
  br i1 %cond7219, label %bb_rcgdec1964, label %bb_rcgslow1964
bb_rcgslow1964:
  %v7220 = load i64, ptr %slot1247, align 8
  %v7221 = load i64, ptr %slot1244, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v7220, i64 %v7221) nomerge, !dbg !176
  br label %bb_rcgdone1964
bb_rcgdec1964:
  %v7222 = load i64, ptr %slot1256, align 8
  %v7223 = load i64, ptr %slot1248, align 8
  %p7224 = inttoptr i64 %v7223 to ptr
  %rgep7225 = getelementptr i8, ptr %p7224, i64 -24
  store i64 %v7222, ptr %rgep7225, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1964
bb_rcgclear1964:
  %v7226 = load i64, ptr %slot1244, align 8
  %p7227 = inttoptr i64 %v7226 to ptr
  store i64 0, ptr %p7227, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1964
bb_rcgdone1964:
  br label %bb_rcslotdone1948
bb_rcslotowner1948:
  %v7228 = load i64, ptr %slot70, align 8
  store i64 %v7228, ptr %slot1261, align 8
  %v7229 = load i64, ptr %slot1244, align 8
  %p7230 = inttoptr i64 %v7229 to ptr
  %ld7231 = load i64, ptr %p7230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7231, ptr %slot1262, align 8
  %v7232 = load i64, ptr %slot1262, align 8
  %cmp7233 = icmp ne i64 %v7232, 0
  %cv7234 = zext i1 %cmp7233 to i32
  store i32 %cv7234, ptr %slot1263, align 8
  %v7235 = load i32, ptr %slot1263, align 8
  %cv7236 = zext i32 %v7235 to i64
  %cond7237 = icmp ne i64 %cv7236, 0
  br i1 %cond7237, label %bb_rcgnn1979, label %bb_rcgdone1979
bb_rcgnn1979:
  %v7238 = load i64, ptr %slot1262, align 8
  %op7239 = sub i64 %v7238, 16
  store i64 %op7239, ptr %slot1264, align 8
  %v7240 = load i64, ptr %slot1262, align 8
  %p7241 = inttoptr i64 %v7240 to ptr
  %rgep7242 = getelementptr i8, ptr %p7241, i64 -16
  %ld7243 = load i64, ptr %rgep7242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7243, ptr %slot1265, align 8
  %v7244 = load i64, ptr %slot1265, align 8
  %op7245 = and i64 %v7244, 4611686018427387906
  store i64 %op7245, ptr %slot1266, align 8
  %v7246 = load i64, ptr %slot1266, align 8
  %cmp7247 = icmp ne i64 %v7246, 0
  %cv7248 = zext i1 %cmp7247 to i32
  store i32 %cv7248, ptr %slot1267, align 8
  %v7249 = load i32, ptr %slot1267, align 8
  %cv7250 = zext i32 %v7249 to i64
  %cond7251 = icmp ne i64 %cv7250, 0
  br i1 %cond7251, label %bb_rcgclear1979, label %bb_rcgcounted1979
bb_rcgcounted1979:
  %v7252 = load i64, ptr %slot1262, align 8
  %op7253 = sub i64 %v7252, 32
  store i64 %op7253, ptr %slot1268, align 8
  %v7254 = load i64, ptr %slot1262, align 8
  %p7255 = inttoptr i64 %v7254 to ptr
  %rgep7256 = getelementptr i8, ptr %p7255, i64 -32
  %ld7257 = load i64, ptr %rgep7256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7257, ptr %slot1269, align 8
  %v7258 = load i64, ptr %slot1269, align 8
  %op7259 = sub i64 %v7258, 1
  store i64 %op7259, ptr %slot1270, align 8
  %v7260 = load i64, ptr %slot1270, align 8
  %cmp7261 = icmp eq i64 %v7260, 0
  %cv7262 = zext i1 %cmp7261 to i32
  store i32 %cv7262, ptr %slot1271, align 8
  %v7263 = load i32, ptr %slot1271, align 8
  %cv7264 = zext i32 %v7263 to i64
  %cond7265 = icmp ne i64 %cv7264, 0
  br i1 %cond7265, label %bb_rcglast1979, label %bb_rcgdec1979
bb_rcglast1979:
  %v7266 = load i64, ptr %slot1262, align 8
  %op7267 = sub i64 %v7266, 24
  store i64 %op7267, ptr %slot1272, align 8
  %v7268 = load i64, ptr %slot1262, align 8
  %p7269 = inttoptr i64 %v7268 to ptr
  %rgep7270 = getelementptr i8, ptr %p7269, i64 -24
  %ld7271 = load i64, ptr %rgep7270, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7271, ptr %slot1273, align 8
  %v7272 = load i64, ptr %slot1273, align 8
  %cmp7273 = icmp ne i64 %v7272, 0
  %cv7274 = zext i1 %cmp7273 to i32
  store i32 %cv7274, ptr %slot1274, align 8
  %v7275 = load i32, ptr %slot1274, align 8
  %cv7276 = zext i32 %v7275 to i64
  %cond7277 = icmp ne i64 %cv7276, 0
  br i1 %cond7277, label %bb_rcgdec1979, label %bb_rcgslow1979
bb_rcgslow1979:
  %v7278 = load i64, ptr %slot1261, align 8
  %v7279 = load i64, ptr %slot1244, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v7278, i64 %v7279) nomerge, !dbg !176
  br label %bb_rcgdone1979
bb_rcgdec1979:
  %v7280 = load i64, ptr %slot1270, align 8
  %v7281 = load i64, ptr %slot1262, align 8
  %p7282 = inttoptr i64 %v7281 to ptr
  %rgep7283 = getelementptr i8, ptr %p7282, i64 -32
  store i64 %v7280, ptr %rgep7283, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1979
bb_rcgclear1979:
  %v7284 = load i64, ptr %slot1244, align 8
  %p7285 = inttoptr i64 %v7284 to ptr
  store i64 0, ptr %p7285, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1979
bb_rcgdone1979:
  br label %bb_rcslotdone1948
bb_rcslotdone1948:
  %v7286 = load i64, ptr %slot1242, align 8
  %v7287 = load i64, ptr %slot51, align 8
  %p7288 = inttoptr i64 %v7287 to ptr
  store i64 %v7286, ptr %p7288, align 8, !alias.scope !3, !noalias !4
  %v7289 = load i64, ptr %slot37, align 8
  %p7290 = inttoptr i64 %v7289 to ptr
  %ld7291 = load i64, ptr %p7290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7291, ptr %slot1275, align 8
  %v7292 = load i64, ptr %slot1275, align 8
  %v7293 = load i64, ptr %slot57, align 8
  %p7294 = inttoptr i64 %v7293 to ptr
  store i64 %v7292, ptr %p7294, align 8, !alias.scope !3, !noalias !4
  %v7295 = load i64, ptr %slot57, align 8
  %p7296 = inttoptr i64 %v7295 to ptr
  %ld7297 = load i64, ptr %p7296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7297, ptr %slot1276, align 8
  %v7298 = load i64, ptr %slot1276, align 8
  %v7299 = load i64, ptr %slot53, align 8
  %p7300 = inttoptr i64 %v7299 to ptr
  store i64 %v7298, ptr %p7300, align 8, !alias.scope !3, !noalias !4
  %v7301 = load i64, ptr %slot53, align 8
  %p7302 = inttoptr i64 %v7301 to ptr
  %ld7303 = load i64, ptr %p7302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7303, ptr %slot1277, align 8
  %v7304 = load i64, ptr %slot1277, align 8
  %v7305 = load i64, ptr %slot57, align 8
  %p7306 = inttoptr i64 %v7305 to ptr
  store i64 %v7304, ptr %p7306, align 8, !alias.scope !3, !noalias !4
  %v7307 = load i64, ptr %slot58, align 8
  %p7308 = inttoptr i64 %v7307 to ptr
  store i64 0, ptr %p7308, align 8, !alias.scope !3, !noalias !4
  %v7309 = load i64, ptr %slot58, align 8
  %p7310 = inttoptr i64 %v7309 to ptr
  %ld7311 = load i64, ptr %p7310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7311, ptr %slot1278, align 8
  %v7312 = load i64, ptr %slot57, align 8
  %p7313 = inttoptr i64 %v7312 to ptr
  %ld7314 = load i64, ptr %p7313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7314, ptr %slot1279, align 8
  %v7315 = load i64, ptr %slot1279, align 8
  %v7316 = load i64, ptr %slot1278, align 8
  %cmp7317 = icmp slt i64 %v7315, %v7316
  %cv7318 = zext i1 %cmp7317 to i64
  store i64 %cv7318, ptr %slot1280, align 8
  %v7319 = load i64, ptr %slot1280, align 8
  %v7320 = load i64, ptr %slot57, align 8
  %p7321 = inttoptr i64 %v7320 to ptr
  store i64 %v7319, ptr %p7321, align 8, !alias.scope !3, !noalias !4
  %v7322 = load i64, ptr %slot57, align 8
  %p7323 = inttoptr i64 %v7322 to ptr
  %ld7324 = load i64, ptr %p7323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7324, ptr %slot1281, align 8
  %v7325 = load i64, ptr %slot1281, align 8
  %cond7326 = icmp ne i64 %v7325, 0
  br i1 %cond7326, label %bb_next2027, label %bb_i116
bb_next2027:
  %v7327 = load i64, ptr %slot51, align 8
  %p7328 = inttoptr i64 %v7327 to ptr
  %ld7329 = load i64, ptr %p7328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7329, ptr %slot1282, align 8
  %v7330 = load i64, ptr %slot1282, align 8
  %op7331 = add i64 %v7330, 0
  store i64 %op7331, ptr %slot1283, align 8
  %v7332 = load i64, ptr %slot1283, align 8
  %p7333 = inttoptr i64 %v7332 to ptr
  %ld7334 = load i64, ptr %p7333, align 8, !alias.scope !6, !noalias !7
  store i64 %ld7334, ptr %slot1284, align 8
  %v7335 = load i64, ptr %slot1284, align 8
  %v7336 = load i64, ptr %slot57, align 8
  %p7337 = inttoptr i64 %v7336 to ptr
  store i64 %v7335, ptr %p7337, align 8, !alias.scope !3, !noalias !4
  %v7338 = load i64, ptr %slot57, align 8
  %p7339 = inttoptr i64 %v7338 to ptr
  %ld7340 = load i64, ptr %p7339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7340, ptr %slot1285, align 8
  %v7341 = load i64, ptr %slot1285, align 8
  %cmp7342 = icmp ugt i64 %v7341, 9223372036854775807
  %cv7343 = zext i1 %cmp7342 to i64
  store i64 %cv7343, ptr %slot1286, align 8
  %v7344 = load i64, ptr %slot1286, align 8
  %cond7345 = icmp ne i64 %v7344, 0
  br i1 %cond7345, label %bb_cast_overflow2032, label %bb_cast_ok2032
bb_cast_overflow2032:
  %v7346 = load i64, ptr %slot1, align 8
  %p7347 = inttoptr i64 %v7346 to ptr
  %v7348 = load i64, ptr %slot1285, align 8
  call void @myl_qbe_fail_cast(ptr %p7347, i64 %v7348, i64 320) nomerge, !dbg !178
  unreachable
bb_cast_ok2032:
  %v7349 = load i64, ptr %slot1285, align 8
  %v7350 = load i64, ptr %slot57, align 8
  %p7351 = inttoptr i64 %v7350 to ptr
  store i64 %v7349, ptr %p7351, align 8, !alias.scope !3, !noalias !4
  %v7352 = load i64, ptr %slot53, align 8
  %p7353 = inttoptr i64 %v7352 to ptr
  %ld7354 = load i64, ptr %p7353, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7354, ptr %slot1287, align 8
  %v7355 = load i64, ptr %slot1287, align 8
  %v7356 = load i64, ptr %slot58, align 8
  %p7357 = inttoptr i64 %v7356 to ptr
  store i64 %v7355, ptr %p7357, align 8, !alias.scope !3, !noalias !4
  %v7358 = load i64, ptr %slot58, align 8
  %p7359 = inttoptr i64 %v7358 to ptr
  %ld7360 = load i64, ptr %p7359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7360, ptr %slot1288, align 8
  %v7361 = load i64, ptr %slot57, align 8
  %p7362 = inttoptr i64 %v7361 to ptr
  %ld7363 = load i64, ptr %p7362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7363, ptr %slot1289, align 8
  %v7364 = load i64, ptr %slot1289, align 8
  %v7365 = load i64, ptr %slot1288, align 8
  %ovpair7367 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v7364, i64 %v7365)
  %op7366 = extractvalue { i64, i1 } %ovpair7367, 0
  %ov7368 = extractvalue { i64, i1 } %ovpair7367, 1
  store i64 %op7366, ptr %slot1290, align 8
  %v7369 = load i64, ptr %slot1289, align 8
  %v7370 = load i64, ptr %slot1290, align 8
  %op7371 = xor i64 %v7369, %v7370
  store i64 %op7371, ptr %slot1291, align 8
  %v7372 = load i64, ptr %slot1288, align 8
  %v7373 = load i64, ptr %slot1290, align 8
  %op7374 = xor i64 %v7372, %v7373
  store i64 %op7374, ptr %slot1292, align 8
  %v7375 = load i64, ptr %slot1291, align 8
  %v7376 = load i64, ptr %slot1292, align 8
  %op7377 = and i64 %v7375, %v7376
  store i64 %op7377, ptr %slot1293, align 8
  %cv7378 = zext i1 %ov7368 to i64
  store i64 %cv7378, ptr %slot1294, align 8
  %v7379 = load i64, ptr %slot1294, align 8
  %cond7380 = icmp ne i64 %v7379, 0
  br i1 %cond7380, label %bb_overflow2036, label %bb_checked2036
bb_overflow2036:
  %v7381 = load i64, ptr %slot1, align 8
  %p7382 = inttoptr i64 %v7381 to ptr
  %v7383 = load i64, ptr %slot1289, align 8
  %v7384 = load i64, ptr %slot1288, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p7382, i64 0, i64 %v7383, i64 %v7384, i64 64) nomerge, !dbg !180
  unreachable
bb_checked2036:
  %v7385 = load i64, ptr %slot1290, align 8
  %v7386 = load i64, ptr %slot57, align 8
  %p7387 = inttoptr i64 %v7386 to ptr
  store i64 %v7385, ptr %p7387, align 8, !alias.scope !3, !noalias !4
  %v7388 = load i64, ptr %slot57, align 8
  %p7389 = inttoptr i64 %v7388 to ptr
  %ld7390 = load i64, ptr %p7389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7390, ptr %slot1295, align 8
  %v7391 = load i64, ptr %slot1295, align 8
  %v7392 = load i64, ptr %slot53, align 8
  %p7393 = inttoptr i64 %v7392 to ptr
  store i64 %v7391, ptr %p7393, align 8, !alias.scope !3, !noalias !4
  br label %bb_i116
bb_i116:
  %v7394 = load i64, ptr %slot53, align 8
  %p7395 = inttoptr i64 %v7394 to ptr
  %ld7396 = load i64, ptr %p7395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7396, ptr %slot1296, align 8
  %v7397 = load i64, ptr %slot1296, align 8
  %v7398 = load i64, ptr %slot57, align 8
  %p7399 = inttoptr i64 %v7398 to ptr
  store i64 %v7397, ptr %p7399, align 8, !alias.scope !3, !noalias !4
  %v7400 = load i64, ptr %slot52, align 8
  %v7401 = load i64, ptr %slot58, align 8
  %p7402 = inttoptr i64 %v7401 to ptr
  store i64 %v7400, ptr %p7402, align 8, !alias.scope !3, !noalias !4
  %v7403 = load i64, ptr %slot58, align 8
  %p7404 = inttoptr i64 %v7403 to ptr
  %ld7405 = load i64, ptr %p7404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7405, ptr %slot1297, align 8
  %v7406 = load i64, ptr %slot19, align 8
  %p7407 = inttoptr i64 %v7406 to ptr
  %ld7408 = load i32, ptr %p7407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7408, ptr %slot1298, align 8
  %v7409 = load i64, ptr %slot20, align 8
  %p7410 = inttoptr i64 %v7409 to ptr
  %ld7411 = load i32, ptr %p7410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7411, ptr %slot1299, align 8
  %v7412 = load i32, ptr %slot1299, align 8
  %op7413 = and i32 %v7412, 24
  store i32 %op7413, ptr %slot1299, align 8
  %v7414 = load i32, ptr %slot1299, align 8
  %cmp7415 = icmp eq i32 %v7414, 0
  %cv7416 = zext i1 %cmp7415 to i32
  store i32 %cv7416, ptr %slot1300, align 8
  %v7417 = load i32, ptr %slot1298, align 8
  %v7418 = load i32, ptr %slot1300, align 8
  %op7419 = and i32 %v7417, %v7418
  store i32 %op7419, ptr %slot1301, align 8
  %v7420 = load i64, ptr %slot71, align 8
  store i64 %v7420, ptr %slot1302, align 8
  %v7421 = load i32, ptr %slot1301, align 8
  %op7422 = mul i32 %v7421, 4
  store i32 %op7422, ptr %slot1303, align 8
  %v7423 = load i32, ptr %slot1303, align 8
  %op7424 = or i32 %v7423, 0
  store i32 %op7424, ptr %slot1304, align 8
  %v7425 = load i64, ptr %slot28, align 8
  store i64 %v7425, ptr %slot1305, align 8
  %v7426 = load i64, ptr %slot70, align 8
  %v7427 = load i64, ptr %slot1305, align 8
  %v7428 = load i64, ptr %slot1297, align 8
  %v7429 = load i64, ptr %slot1302, align 8
  %cv7430 = trunc i64 %v7429 to i32
  %v7431 = load i32, ptr %slot1304, align 8
  %call7432 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v7426, i64 %v7427, i64 %v7428, i32 %cv7430, i32 %v7431) nomerge, !dbg !182
  store i32 %call7432, ptr %slot1306, align 8
  %v7433 = load i32, ptr %slot1306, align 8
  %cv7434 = zext i32 %v7433 to i64
  %cond7435 = icmp ne i64 %cv7434, 0
  br i1 %cond7435, label %bb_rcsuccess2057, label %bb_rcfailure2057
bb_rcfailure2057:
  %v7436 = load i64, ptr %slot70, align 8
  %p7437 = inttoptr i64 %v7436 to ptr
  %call7438 = call i32 @myl_rc_take_failure(ptr %p7437) nomerge, !dbg !182
  store i32 %call7438, ptr %slot1307, align 8
  %v7439 = load i64, ptr %slot1, align 8
  %p7440 = inttoptr i64 %v7439 to ptr
  %v7441 = load i32, ptr %slot1307, align 8
  %call7442 = call i32 @myl_qbe_rc_status(ptr %p7440, i32 %v7441) nomerge, !dbg !182
  store i32 %call7442, ptr %slot1308, align 8
  br label %bb_failure
bb_rcsuccess2057:
  %v7443 = load i32, ptr %slot1301, align 8
  %cv7444 = zext i32 %v7443 to i64
  %cond7445 = icmp ne i64 %cv7444, 0
  br i1 %cond7445, label %bb_rchtaken2060, label %bb_rchcopied2060
bb_rchcopied2060:
  %v7446 = load i64, ptr %slot19, align 8
  %p7447 = inttoptr i64 %v7446 to ptr
  %ld7448 = load i32, ptr %p7447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7448, ptr %slot1309, align 8
  %v7449 = load i32, ptr %slot1309, align 8
  %cv7450 = zext i32 %v7449 to i64
  %cond7451 = icmp ne i64 %cv7450, 0
  br i1 %cond7451, label %bb_rcslotdrop2063, label %bb_rcslotdone2063
bb_rcslotdrop2063:
  %v7452 = load i64, ptr %slot19, align 8
  %p7453 = inttoptr i64 %v7452 to ptr
  store i32 0, ptr %p7453, align 4, !alias.scope !3, !noalias !4
  %v7454 = load i64, ptr %slot25, align 8
  store i64 %v7454, ptr %slot1310, align 8
  %v7455 = load i64, ptr %slot20, align 8
  %p7456 = inttoptr i64 %v7455 to ptr
  %ld7457 = load i32, ptr %p7456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7457, ptr %slot1311, align 8
  %v7458 = load i32, ptr %slot1311, align 8
  %op7459 = and i32 %v7458, 28
  store i32 %op7459, ptr %slot1312, align 8
  %v7460 = load i32, ptr %slot1312, align 8
  %cv7461 = zext i32 %v7460 to i64
  %cond7462 = icmp ne i64 %cv7461, 0
  br i1 %cond7462, label %bb_rcslotrole2063, label %bb_rcslotowner2063
bb_rcslotrole2063:
  %v7463 = load i64, ptr %slot70, align 8
  store i64 %v7463, ptr %slot1313, align 8
  %v7464 = load i64, ptr %slot1313, align 8
  %v7465 = load i64, ptr %slot1310, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7464, i64 %v7465) nomerge, !dbg !182
  br label %bb_rcslotdone2063
bb_rcslotowner2063:
  %v7466 = load i64, ptr %slot70, align 8
  store i64 %v7466, ptr %slot1314, align 8
  %v7467 = load i64, ptr %slot1314, align 8
  %v7468 = load i64, ptr %slot1310, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7467, i64 %v7468) nomerge, !dbg !182
  br label %bb_rcslotdone2063
bb_rcslotdone2063:
  br label %bb_rchprepared2060
bb_rchtaken2060:
  %v7469 = load i64, ptr %slot19, align 8
  %p7470 = inttoptr i64 %v7469 to ptr
  store i32 0, ptr %p7470, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared2060
bb_rchprepared2060:
  %v7471 = load i64, ptr %slot22, align 8
  %p7472 = inttoptr i64 %v7471 to ptr
  store i32 2, ptr %p7472, align 4, !alias.scope !3, !noalias !4
  %v7473 = load i64, ptr %slot21, align 8
  %p7474 = inttoptr i64 %v7473 to ptr
  store i32 1, ptr %p7474, align 4, !alias.scope !3, !noalias !4
  %v7475 = load i64, ptr %slot25, align 8
  store i64 %v7475, ptr %slot1315, align 8
  %v7476 = load i64, ptr %slot28, align 8
  store i64 %v7476, ptr %slot1316, align 8
  %v7477 = load i64, ptr %slot1316, align 8
  %v7478 = load i64, ptr %slot1315, align 8
  %p7479 = inttoptr i64 %v7477 to ptr
  %p7480 = inttoptr i64 %v7478 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7480, ptr %p7479, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v7481 = load i64, ptr %slot20, align 8
  %p7482 = inttoptr i64 %v7481 to ptr
  store i32 2, ptr %p7482, align 4, !alias.scope !3, !noalias !4
  %v7483 = load i64, ptr %slot22, align 8
  %p7484 = inttoptr i64 %v7483 to ptr
  %ld7485 = load i32, ptr %p7484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7485, ptr %slot1317, align 8
  %v7486 = load i32, ptr %slot1317, align 8
  %v7487 = load i64, ptr %slot20, align 8
  %p7488 = inttoptr i64 %v7487 to ptr
  store i32 %v7486, ptr %p7488, align 4, !alias.scope !3, !noalias !4
  %v7489 = load i64, ptr %slot21, align 8
  %p7490 = inttoptr i64 %v7489 to ptr
  store i32 0, ptr %p7490, align 4, !alias.scope !3, !noalias !4
  %v7491 = load i64, ptr %slot19, align 8
  %p7492 = inttoptr i64 %v7491 to ptr
  store i32 1, ptr %p7492, align 4, !alias.scope !3, !noalias !4
  %v7493 = load i64, ptr %slot1315, align 8
  %v7494 = load i64, ptr %slot58, align 8
  %p7495 = inttoptr i64 %v7494 to ptr
  store i64 %v7493, ptr %p7495, align 8, !alias.scope !3, !noalias !4
  %v7496 = load i64, ptr %slot51, align 8
  %p7497 = inttoptr i64 %v7496 to ptr
  %ld7498 = load i64, ptr %p7497, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7498, ptr %slot1318, align 8
  %v7499 = load i64, ptr %slot58, align 8
  %p7500 = inttoptr i64 %v7499 to ptr
  %ld7501 = load i64, ptr %p7500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7501, ptr %slot1319, align 8
  %v7502 = load i64, ptr %slot57, align 8
  %p7503 = inttoptr i64 %v7502 to ptr
  %ld7504 = load i64, ptr %p7503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7504, ptr %slot1320, align 8
  %v7505 = load i64, ptr %slot1318, align 8
  %p7506 = inttoptr i64 %v7505 to ptr
  %ld7507 = load i64, ptr %p7506, align 8, !alias.scope !6, !noalias !7
  store i64 %ld7507, ptr %slot1321, align 8
  %v7508 = load i64, ptr %slot1320, align 8
  %v7509 = load i64, ptr %slot1321, align 8
  %cmp7510 = icmp ult i64 %v7508, %v7509
  %cv7511 = zext i1 %cmp7510 to i64
  store i64 %cv7511, ptr %slot1322, align 8
  %v7512 = load i64, ptr %slot1322, align 8
  %cond7513 = icmp ne i64 %v7512, 0
  br i1 %cond7513, label %bb_success2087, label %bb_failed2087
bb_failed2087:
  %v7514 = load i64, ptr %slot1, align 8
  %p7515 = inttoptr i64 %v7514 to ptr
  %v7516 = load i64, ptr %slot1320, align 8
  %v7517 = load i64, ptr %slot1321, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p7515, i64 %v7516, i64 %v7517) nomerge, !dbg !184
  unreachable
bb_success2087:
  %v7518 = load i64, ptr %slot58, align 8
  %p7519 = inttoptr i64 %v7518 to ptr
  %ld7520 = load i64, ptr %p7519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7520, ptr %slot1323, align 8
  %v7521 = load i64, ptr %slot70, align 8
  %v7522 = load i64, ptr %slot1318, align 8
  %v7523 = load i64, ptr %slot1320, align 8
  %v7524 = load i64, ptr %slot1323, align 8
  %call7525 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64 %v7521, i64 %v7522, i64 %v7523, i64 %v7524) nomerge, !dbg !184
  store i32 %call7525, ptr %slot1324, align 8
  %v7526 = load i32, ptr %slot1324, align 8
  %cv7527 = zext i32 %v7526 to i64
  %cond7528 = icmp ne i64 %cv7527, 0
  br i1 %cond7528, label %bb_success2090, label %bb_failed2090
bb_failed2090:
  %v7529 = load i64, ptr %slot1, align 8
  %p7530 = inttoptr i64 %v7529 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7530) nomerge, !dbg !184
  unreachable
bb_success2090:
  %v7531 = load i64, ptr %slot57, align 8
  %p7532 = inttoptr i64 %v7531 to ptr
  store i64 0, ptr %p7532, align 8, !alias.scope !3, !noalias !4
  %v7533 = load i64, ptr %slot19, align 8
  %p7534 = inttoptr i64 %v7533 to ptr
  %ld7535 = load i32, ptr %p7534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7535, ptr %slot1325, align 8
  %v7536 = load i32, ptr %slot1325, align 8
  %cv7537 = zext i32 %v7536 to i64
  %cond7538 = icmp ne i64 %cv7537, 0
  br i1 %cond7538, label %bb_rcslotdrop2093, label %bb_rcslotdone2093
bb_rcslotdrop2093:
  %v7539 = load i64, ptr %slot19, align 8
  %p7540 = inttoptr i64 %v7539 to ptr
  store i32 0, ptr %p7540, align 4, !alias.scope !3, !noalias !4
  %v7541 = load i64, ptr %slot25, align 8
  store i64 %v7541, ptr %slot1326, align 8
  %v7542 = load i64, ptr %slot20, align 8
  %p7543 = inttoptr i64 %v7542 to ptr
  %ld7544 = load i32, ptr %p7543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7544, ptr %slot1327, align 8
  %v7545 = load i32, ptr %slot1327, align 8
  %op7546 = and i32 %v7545, 28
  store i32 %op7546, ptr %slot1328, align 8
  %v7547 = load i32, ptr %slot1328, align 8
  %cv7548 = zext i32 %v7547 to i64
  %cond7549 = icmp ne i64 %cv7548, 0
  br i1 %cond7549, label %bb_rcslotrole2093, label %bb_rcslotowner2093
bb_rcslotrole2093:
  %v7550 = load i64, ptr %slot70, align 8
  store i64 %v7550, ptr %slot1329, align 8
  %v7551 = load i64, ptr %slot1329, align 8
  %v7552 = load i64, ptr %slot1326, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7551, i64 %v7552) nomerge, !dbg !184
  br label %bb_rcslotdone2093
bb_rcslotowner2093:
  %v7553 = load i64, ptr %slot70, align 8
  store i64 %v7553, ptr %slot1330, align 8
  %v7554 = load i64, ptr %slot1330, align 8
  %v7555 = load i64, ptr %slot1326, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7554, i64 %v7555) nomerge, !dbg !184
  br label %bb_rcslotdone2093
bb_rcslotdone2093:
  %v7556 = load i64, ptr %slot42, align 8
  %v7557 = load i64, ptr %slot57, align 8
  %p7558 = inttoptr i64 %v7557 to ptr
  store i64 %v7556, ptr %p7558, align 8, !alias.scope !3, !noalias !4
  %v7559 = load i64, ptr %slot57, align 8
  %p7560 = inttoptr i64 %v7559 to ptr
  %ld7561 = load i64, ptr %p7560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7561, ptr %slot1331, align 8
  %v7562 = load i64, ptr %slot1331, align 8
  %op7563 = add i64 %v7562, 0
  store i64 %op7563, ptr %slot1332, align 8
  %v7564 = load i64, ptr %slot1332, align 8
  %v7565 = load i64, ptr %slot57, align 8
  %p7566 = inttoptr i64 %v7565 to ptr
  store i64 %v7564, ptr %p7566, align 8, !alias.scope !3, !noalias !4
  %v7567 = load i64, ptr %slot17, align 8
  %p7568 = inttoptr i64 %v7567 to ptr
  %ld7569 = load i32, ptr %p7568, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7569, ptr %slot1333, align 8
  %v7570 = load i32, ptr %slot1333, align 8
  %cv7571 = zext i32 %v7570 to i64
  %cond7572 = icmp ne i64 %cv7571, 0
  br i1 %cond7572, label %bb_rcslotdrop2104, label %bb_rcslotdone2104
bb_rcslotdrop2104:
  %v7573 = load i64, ptr %slot17, align 8
  %p7574 = inttoptr i64 %v7573 to ptr
  store i32 0, ptr %p7574, align 4, !alias.scope !3, !noalias !4
  %v7575 = load i64, ptr %slot24, align 8
  store i64 %v7575, ptr %slot1334, align 8
  %v7576 = load i64, ptr %slot18, align 8
  %p7577 = inttoptr i64 %v7576 to ptr
  %ld7578 = load i32, ptr %p7577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7578, ptr %slot1335, align 8
  %v7579 = load i32, ptr %slot1335, align 8
  %op7580 = and i32 %v7579, 28
  store i32 %op7580, ptr %slot1336, align 8
  %v7581 = load i32, ptr %slot1336, align 8
  %cv7582 = zext i32 %v7581 to i64
  %cond7583 = icmp ne i64 %cv7582, 0
  br i1 %cond7583, label %bb_rcslotrole2104, label %bb_rcslotowner2104
bb_rcslotrole2104:
  %v7584 = load i64, ptr %slot70, align 8
  store i64 %v7584, ptr %slot1337, align 8
  %v7585 = load i64, ptr %slot1337, align 8
  %v7586 = load i64, ptr %slot1334, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7585, i64 %v7586) nomerge, !dbg !186
  br label %bb_rcslotdone2104
bb_rcslotowner2104:
  %v7587 = load i64, ptr %slot70, align 8
  store i64 %v7587, ptr %slot1338, align 8
  %v7588 = load i64, ptr %slot1338, align 8
  %v7589 = load i64, ptr %slot1334, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7588, i64 %v7589) nomerge, !dbg !186
  br label %bb_rcslotdone2104
bb_rcslotdone2104:
  %v7590 = load i64, ptr %slot57, align 8
  %p7591 = inttoptr i64 %v7590 to ptr
  %ld7592 = load i64, ptr %p7591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7592, ptr %slot1339, align 8
  %v7593 = load i64, ptr %slot17, align 8
  %p7594 = inttoptr i64 %v7593 to ptr
  %ld7595 = load i32, ptr %p7594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7595, ptr %slot1340, align 8
  %v7596 = load i64, ptr %slot18, align 8
  %p7597 = inttoptr i64 %v7596 to ptr
  %ld7598 = load i32, ptr %p7597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7598, ptr %slot1341, align 8
  %v7599 = load i32, ptr %slot1341, align 8
  %op7600 = and i32 %v7599, 24
  store i32 %op7600, ptr %slot1341, align 8
  %v7601 = load i32, ptr %slot1341, align 8
  %cmp7602 = icmp eq i32 %v7601, 0
  %cv7603 = zext i1 %cmp7602 to i32
  store i32 %cv7603, ptr %slot1342, align 8
  %v7604 = load i32, ptr %slot1340, align 8
  %v7605 = load i32, ptr %slot1342, align 8
  %op7606 = and i32 %v7604, %v7605
  store i32 %op7606, ptr %slot1343, align 8
  %v7607 = load i64, ptr %slot71, align 8
  store i64 %v7607, ptr %slot1344, align 8
  %v7608 = load i32, ptr %slot1343, align 8
  %op7609 = mul i32 %v7608, 4
  store i32 %op7609, ptr %slot1345, align 8
  %v7610 = load i32, ptr %slot1345, align 8
  %op7611 = or i32 %v7610, 0
  store i32 %op7611, ptr %slot1346, align 8
  %v7612 = load i64, ptr %slot28, align 8
  store i64 %v7612, ptr %slot1347, align 8
  %v7613 = load i64, ptr %slot70, align 8
  %v7614 = load i64, ptr %slot1347, align 8
  %v7615 = load i64, ptr %slot1339, align 8
  %v7616 = load i64, ptr %slot1344, align 8
  %cv7617 = trunc i64 %v7616 to i32
  %v7618 = load i32, ptr %slot1346, align 8
  %call7619 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v7613, i64 %v7614, i64 %v7615, i32 %cv7617, i32 %v7618) nomerge, !dbg !188
  store i32 %call7619, ptr %slot1348, align 8
  %v7620 = load i32, ptr %slot1348, align 8
  %cv7621 = zext i32 %v7620 to i64
  %cond7622 = icmp ne i64 %cv7621, 0
  br i1 %cond7622, label %bb_rcsuccess2125, label %bb_rcfailure2125
bb_rcfailure2125:
  %v7623 = load i64, ptr %slot70, align 8
  %p7624 = inttoptr i64 %v7623 to ptr
  %call7625 = call i32 @myl_rc_take_failure(ptr %p7624) nomerge, !dbg !188
  store i32 %call7625, ptr %slot1349, align 8
  %v7626 = load i64, ptr %slot1, align 8
  %p7627 = inttoptr i64 %v7626 to ptr
  %v7628 = load i32, ptr %slot1349, align 8
  %call7629 = call i32 @myl_qbe_rc_status(ptr %p7627, i32 %v7628) nomerge, !dbg !188
  store i32 %call7629, ptr %slot1350, align 8
  br label %bb_failure
bb_rcsuccess2125:
  %v7630 = load i32, ptr %slot1343, align 8
  %cv7631 = zext i32 %v7630 to i64
  %cond7632 = icmp ne i64 %cv7631, 0
  br i1 %cond7632, label %bb_rchtaken2128, label %bb_rchcopied2128
bb_rchcopied2128:
  %v7633 = load i64, ptr %slot17, align 8
  %p7634 = inttoptr i64 %v7633 to ptr
  %ld7635 = load i32, ptr %p7634, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7635, ptr %slot1351, align 8
  %v7636 = load i32, ptr %slot1351, align 8
  %cv7637 = zext i32 %v7636 to i64
  %cond7638 = icmp ne i64 %cv7637, 0
  br i1 %cond7638, label %bb_rcslotdrop2131, label %bb_rcslotdone2131
bb_rcslotdrop2131:
  %v7639 = load i64, ptr %slot17, align 8
  %p7640 = inttoptr i64 %v7639 to ptr
  store i32 0, ptr %p7640, align 4, !alias.scope !3, !noalias !4
  %v7641 = load i64, ptr %slot24, align 8
  store i64 %v7641, ptr %slot1352, align 8
  %v7642 = load i64, ptr %slot18, align 8
  %p7643 = inttoptr i64 %v7642 to ptr
  %ld7644 = load i32, ptr %p7643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7644, ptr %slot1353, align 8
  %v7645 = load i32, ptr %slot1353, align 8
  %op7646 = and i32 %v7645, 28
  store i32 %op7646, ptr %slot1354, align 8
  %v7647 = load i32, ptr %slot1354, align 8
  %cv7648 = zext i32 %v7647 to i64
  %cond7649 = icmp ne i64 %cv7648, 0
  br i1 %cond7649, label %bb_rcslotrole2131, label %bb_rcslotowner2131
bb_rcslotrole2131:
  %v7650 = load i64, ptr %slot70, align 8
  store i64 %v7650, ptr %slot1355, align 8
  %v7651 = load i64, ptr %slot1355, align 8
  %v7652 = load i64, ptr %slot1352, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v7651, i64 %v7652) nomerge, !dbg !188
  br label %bb_rcslotdone2131
bb_rcslotowner2131:
  %v7653 = load i64, ptr %slot70, align 8
  store i64 %v7653, ptr %slot1356, align 8
  %v7654 = load i64, ptr %slot1356, align 8
  %v7655 = load i64, ptr %slot1352, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v7654, i64 %v7655) nomerge, !dbg !188
  br label %bb_rcslotdone2131
bb_rcslotdone2131:
  br label %bb_rchprepared2128
bb_rchtaken2128:
  %v7656 = load i64, ptr %slot17, align 8
  %p7657 = inttoptr i64 %v7656 to ptr
  store i32 0, ptr %p7657, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared2128
bb_rchprepared2128:
  %v7658 = load i64, ptr %slot22, align 8
  %p7659 = inttoptr i64 %v7658 to ptr
  store i32 2, ptr %p7659, align 4, !alias.scope !3, !noalias !4
  %v7660 = load i64, ptr %slot21, align 8
  %p7661 = inttoptr i64 %v7660 to ptr
  store i32 1, ptr %p7661, align 4, !alias.scope !3, !noalias !4
  %v7662 = load i64, ptr %slot24, align 8
  store i64 %v7662, ptr %slot1357, align 8
  %v7663 = load i64, ptr %slot28, align 8
  store i64 %v7663, ptr %slot1358, align 8
  %v7664 = load i64, ptr %slot1358, align 8
  %v7665 = load i64, ptr %slot1357, align 8
  %p7666 = inttoptr i64 %v7664 to ptr
  %p7667 = inttoptr i64 %v7665 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7667, ptr %p7666, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v7668 = load i64, ptr %slot18, align 8
  %p7669 = inttoptr i64 %v7668 to ptr
  store i32 2, ptr %p7669, align 4, !alias.scope !3, !noalias !4
  %v7670 = load i64, ptr %slot22, align 8
  %p7671 = inttoptr i64 %v7670 to ptr
  %ld7672 = load i32, ptr %p7671, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7672, ptr %slot1359, align 8
  %v7673 = load i32, ptr %slot1359, align 8
  %v7674 = load i64, ptr %slot18, align 8
  %p7675 = inttoptr i64 %v7674 to ptr
  store i32 %v7673, ptr %p7675, align 4, !alias.scope !3, !noalias !4
  %v7676 = load i64, ptr %slot21, align 8
  %p7677 = inttoptr i64 %v7676 to ptr
  store i32 0, ptr %p7677, align 4, !alias.scope !3, !noalias !4
  %v7678 = load i64, ptr %slot17, align 8
  %p7679 = inttoptr i64 %v7678 to ptr
  store i32 1, ptr %p7679, align 4, !alias.scope !3, !noalias !4
  %v7680 = load i64, ptr %slot1357, align 8
  %v7681 = load i64, ptr %slot57, align 8
  %p7682 = inttoptr i64 %v7681 to ptr
  store i64 %v7680, ptr %p7682, align 8, !alias.scope !3, !noalias !4
  %v7683 = load i64, ptr %slot63, align 8
  store i64 %v7683, ptr %slot1360, align 8
  %v7684 = load i64, ptr %slot1360, align 8
  %p7685 = inttoptr i64 %v7684 to ptr
  store i64 0, ptr %p7685, align 8, !alias.scope !3, !noalias !4
  %v7686 = load i64, ptr %slot1360, align 8
  %p7688 = inttoptr i64 %v7686 to ptr
  %gep7689 = getelementptr i8, ptr %p7688, i64 8
  %op7687 = ptrtoint ptr %gep7689 to i64
  store i64 %op7687, ptr %slot1361, align 8
  %v7690 = load i64, ptr %slot1361, align 8
  %p7691 = inttoptr i64 %v7690 to ptr
  store i64 0, ptr %p7691, align 8, !alias.scope !3, !noalias !4
  %v7692 = load i64, ptr %slot1360, align 8
  %p7694 = inttoptr i64 %v7692 to ptr
  %gep7695 = getelementptr i8, ptr %p7694, i64 16
  %op7693 = ptrtoint ptr %gep7695 to i64
  store i64 %op7693, ptr %slot1362, align 8
  %v7696 = load i64, ptr %slot1362, align 8
  %p7697 = inttoptr i64 %v7696 to ptr
  store i64 0, ptr %p7697, align 8, !alias.scope !3, !noalias !4
  %v7698 = load i64, ptr %slot1360, align 8
  %p7700 = inttoptr i64 %v7698 to ptr
  %gep7701 = getelementptr i8, ptr %p7700, i64 24
  %op7699 = ptrtoint ptr %gep7701 to i64
  store i64 %op7699, ptr %slot1363, align 8
  %v7702 = load i64, ptr %slot1363, align 8
  %p7703 = inttoptr i64 %v7702 to ptr
  store i64 0, ptr %p7703, align 8, !alias.scope !3, !noalias !4
  %v7704 = load i64, ptr %slot1360, align 8
  %p7706 = inttoptr i64 %v7704 to ptr
  %gep7707 = getelementptr i8, ptr %p7706, i64 32
  %op7705 = ptrtoint ptr %gep7707 to i64
  store i64 %op7705, ptr %slot1364, align 8
  %v7708 = load i64, ptr %slot1364, align 8
  %p7709 = inttoptr i64 %v7708 to ptr
  store i64 0, ptr %p7709, align 8, !alias.scope !3, !noalias !4
  %v7710 = load i64, ptr %slot1360, align 8
  %p7712 = inttoptr i64 %v7710 to ptr
  %gep7713 = getelementptr i8, ptr %p7712, i64 40
  %op7711 = ptrtoint ptr %gep7713 to i64
  store i64 %op7711, ptr %slot1365, align 8
  %v7714 = load i64, ptr %slot1365, align 8
  %p7715 = inttoptr i64 %v7714 to ptr
  store i64 0, ptr %p7715, align 8, !alias.scope !3, !noalias !4
  %v7716 = load i64, ptr %slot1360, align 8
  %p7718 = inttoptr i64 %v7716 to ptr
  %gep7719 = getelementptr i8, ptr %p7718, i64 48
  %op7717 = ptrtoint ptr %gep7719 to i64
  store i64 %op7717, ptr %slot1366, align 8
  %v7720 = load i64, ptr %slot1366, align 8
  %p7721 = inttoptr i64 %v7720 to ptr
  store i64 0, ptr %p7721, align 8, !alias.scope !3, !noalias !4
  %v7722 = load i64, ptr %slot1360, align 8
  %p7723 = inttoptr i64 %v7722 to ptr
  store i32 2, ptr %p7723, align 4, !alias.scope !3, !noalias !4
  %v7724 = load i64, ptr %slot23, align 8
  %p7725 = inttoptr i64 %v7724 to ptr
  store i32 1, ptr %p7725, align 4, !alias.scope !3, !noalias !4
  %v7726 = load i64, ptr %slot57, align 8
  %p7727 = inttoptr i64 %v7726 to ptr
  %ld7728 = load i64, ptr %p7727, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7728, ptr %slot1367, align 8
  %v7729 = load i64, ptr %slot1360, align 8
  %p7731 = inttoptr i64 %v7729 to ptr
  %gep7732 = getelementptr i8, ptr %p7731, i64 8
  %op7730 = ptrtoint ptr %gep7732 to i64
  store i64 %op7730, ptr %slot1368, align 8
  %v7733 = load i64, ptr %slot71, align 8
  store i64 %v7733, ptr %slot1369, align 8
  %v7734 = load i64, ptr %slot57, align 8
  %p7735 = inttoptr i64 %v7734 to ptr
  %ld7736 = load i64, ptr %p7735, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7736, ptr %slot1370, align 8
  %v7737 = load i64, ptr %slot28, align 8
  store i64 %v7737, ptr %slot1371, align 8
  %v7738 = load i64, ptr %slot71, align 8
  store i64 %v7738, ptr %slot1372, align 8
  %v7739 = load i64, ptr %slot1370, align 8
  %op7740 = add i64 %v7739, 16
  store i64 %op7740, ptr %slot1373, align 8
  %v7741 = load i64, ptr %slot1373, align 8
  %p7742 = inttoptr i64 %v7741 to ptr
  %ld7743 = load i64, ptr %p7742, align 8
  store i64 %ld7743, ptr %slot1374, align 8
  %v7744 = load i64, ptr %slot1374, align 8
  %cmp7745 = icmp ne i64 %v7744, 0
  %cv7746 = zext i1 %cmp7745 to i32
  store i32 %cv7746, ptr %slot1375, align 8
  %v7747 = load i32, ptr %slot1375, align 8
  %cv7748 = zext i32 %v7747 to i64
  %cond7749 = icmp ne i64 %cv7748, 0
  br i1 %cond7749, label %bb_rcmoveheader2167, label %bb_rcmovenext2167
bb_rcmoveheader2167:
  %v7750 = load i64, ptr %slot1374, align 8
  %op7751 = sub i64 %v7750, 16
  store i64 %op7751, ptr %slot1376, align 8
  %v7752 = load i64, ptr %slot1374, align 8
  %p7753 = inttoptr i64 %v7752 to ptr
  %rgep7754 = getelementptr i8, ptr %p7753, i64 -16
  %ld7755 = load i64, ptr %rgep7754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7755, ptr %slot1377, align 8
  %v7756 = load i64, ptr %slot1377, align 8
  %op7757 = and i64 %v7756, 5764607523034234881
  store i64 %op7757, ptr %slot1378, align 8
  %v7758 = load i64, ptr %slot1378, align 8
  %cmp7759 = icmp ne i64 %v7758, 0
  %cv7760 = zext i1 %cmp7759 to i32
  store i32 %cv7760, ptr %slot1379, align 8
  %v7761 = load i32, ptr %slot1379, align 8
  %cv7762 = zext i32 %v7761 to i64
  %cond7763 = icmp ne i64 %cv7762, 0
  br i1 %cond7763, label %bb_rcmoveslow2164, label %bb_rcmovenext2167
bb_rcmovenext2167:
  %v7764 = load i64, ptr %slot1370, align 8
  %op7765 = add i64 %v7764, 24
  store i64 %op7765, ptr %slot1380, align 8
  %v7766 = load i64, ptr %slot1380, align 8
  %p7767 = inttoptr i64 %v7766 to ptr
  %ld7768 = load i64, ptr %p7767, align 8
  store i64 %ld7768, ptr %slot1381, align 8
  %v7769 = load i64, ptr %slot1381, align 8
  %cmp7770 = icmp ne i64 %v7769, 0
  %cv7771 = zext i1 %cmp7770 to i32
  store i32 %cv7771, ptr %slot1382, align 8
  %v7772 = load i32, ptr %slot1382, align 8
  %cv7773 = zext i32 %v7772 to i64
  %cond7774 = icmp ne i64 %cv7773, 0
  br i1 %cond7774, label %bb_rcmoveheader2175, label %bb_rcmovenext2175
bb_rcmoveheader2175:
  %v7775 = load i64, ptr %slot1381, align 8
  %op7776 = sub i64 %v7775, 16
  store i64 %op7776, ptr %slot1383, align 8
  %v7777 = load i64, ptr %slot1381, align 8
  %p7778 = inttoptr i64 %v7777 to ptr
  %rgep7779 = getelementptr i8, ptr %p7778, i64 -16
  %ld7780 = load i64, ptr %rgep7779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7780, ptr %slot1384, align 8
  %v7781 = load i64, ptr %slot1384, align 8
  %op7782 = and i64 %v7781, 5764607523034234881
  store i64 %op7782, ptr %slot1385, align 8
  %v7783 = load i64, ptr %slot1385, align 8
  %cmp7784 = icmp ne i64 %v7783, 0
  %cv7785 = zext i1 %cmp7784 to i32
  store i32 %cv7785, ptr %slot1386, align 8
  %v7786 = load i32, ptr %slot1386, align 8
  %cv7787 = zext i32 %v7786 to i64
  %cond7788 = icmp ne i64 %cv7787, 0
  br i1 %cond7788, label %bb_rcmoveslow2164, label %bb_rcmovenext2175
bb_rcmovenext2175:
  %v7789 = load i64, ptr %slot1370, align 8
  %op7790 = add i64 %v7789, 32
  store i64 %op7790, ptr %slot1387, align 8
  %v7791 = load i64, ptr %slot1387, align 8
  %p7792 = inttoptr i64 %v7791 to ptr
  %ld7793 = load i64, ptr %p7792, align 8
  store i64 %ld7793, ptr %slot1388, align 8
  %v7794 = load i64, ptr %slot1388, align 8
  %cmp7795 = icmp ne i64 %v7794, 0
  %cv7796 = zext i1 %cmp7795 to i32
  store i32 %cv7796, ptr %slot1389, align 8
  %v7797 = load i32, ptr %slot1389, align 8
  %cv7798 = zext i32 %v7797 to i64
  %cond7799 = icmp ne i64 %cv7798, 0
  br i1 %cond7799, label %bb_rcmoveheader2183, label %bb_rcmovenext2183
bb_rcmoveheader2183:
  %v7800 = load i64, ptr %slot1388, align 8
  %op7801 = sub i64 %v7800, 16
  store i64 %op7801, ptr %slot1390, align 8
  %v7802 = load i64, ptr %slot1388, align 8
  %p7803 = inttoptr i64 %v7802 to ptr
  %rgep7804 = getelementptr i8, ptr %p7803, i64 -16
  %ld7805 = load i64, ptr %rgep7804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7805, ptr %slot1391, align 8
  %v7806 = load i64, ptr %slot1391, align 8
  %op7807 = and i64 %v7806, 5764607523034234881
  store i64 %op7807, ptr %slot1392, align 8
  %v7808 = load i64, ptr %slot1392, align 8
  %cmp7809 = icmp ne i64 %v7808, 0
  %cv7810 = zext i1 %cmp7809 to i32
  store i32 %cv7810, ptr %slot1393, align 8
  %v7811 = load i32, ptr %slot1393, align 8
  %cv7812 = zext i32 %v7811 to i64
  %cond7813 = icmp ne i64 %cv7812, 0
  br i1 %cond7813, label %bb_rcmoveslow2164, label %bb_rcmovenext2183
bb_rcmovenext2183:
  %v7814 = load i64, ptr %slot1370, align 8
  %v7815 = load i64, ptr %slot1371, align 8
  %p7816 = inttoptr i64 %v7814 to ptr
  %p7817 = inttoptr i64 %v7815 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7817, ptr %p7816, i64 48, i1 false)
  %v7818 = load i64, ptr %slot1370, align 8
  %p7819 = inttoptr i64 %v7818 to ptr
  store i64 0, ptr %p7819, align 8
  %v7820 = load i64, ptr %slot1370, align 8
  %op7821 = add i64 %v7820, 8
  store i64 %op7821, ptr %slot1394, align 8
  %v7822 = load i64, ptr %slot1394, align 8
  %p7823 = inttoptr i64 %v7822 to ptr
  store i64 0, ptr %p7823, align 8
  %v7824 = load i64, ptr %slot1370, align 8
  %op7825 = add i64 %v7824, 16
  store i64 %op7825, ptr %slot1395, align 8
  %v7826 = load i64, ptr %slot1395, align 8
  %p7827 = inttoptr i64 %v7826 to ptr
  store i64 0, ptr %p7827, align 8
  %v7828 = load i64, ptr %slot1370, align 8
  %op7829 = add i64 %v7828, 24
  store i64 %op7829, ptr %slot1396, align 8
  %v7830 = load i64, ptr %slot1396, align 8
  %p7831 = inttoptr i64 %v7830 to ptr
  store i64 0, ptr %p7831, align 8
  %v7832 = load i64, ptr %slot1370, align 8
  %op7833 = add i64 %v7832, 32
  store i64 %op7833, ptr %slot1397, align 8
  %v7834 = load i64, ptr %slot1397, align 8
  %p7835 = inttoptr i64 %v7834 to ptr
  store i64 0, ptr %p7835, align 8
  %v7836 = load i64, ptr %slot1370, align 8
  %op7837 = add i64 %v7836, 40
  store i64 %op7837, ptr %slot1398, align 8
  %v7838 = load i64, ptr %slot1398, align 8
  %p7839 = inttoptr i64 %v7838 to ptr
  store i64 0, ptr %p7839, align 8
  br label %bb_rcmoved2164
bb_rcmoveslow2164:
  %v7840 = load i64, ptr %slot70, align 8
  %v7841 = load i64, ptr %slot1371, align 8
  %v7842 = load i64, ptr %slot1370, align 8
  %v7843 = load i64, ptr %slot1372, align 8
  %cv7844 = trunc i64 %v7843 to i32
  %call7845 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v7840, i64 %v7841, i64 %v7842, i32 %cv7844) nomerge, !dbg !190
  store i32 %call7845, ptr %slot1399, align 8
  %v7846 = load i32, ptr %slot1399, align 8
  %cv7847 = zext i32 %v7846 to i64
  %cond7848 = icmp ne i64 %cv7847, 0
  br i1 %cond7848, label %bb_rcsuccess2195, label %bb_rcfailure2195
bb_rcfailure2195:
  %v7849 = load i64, ptr %slot70, align 8
  %p7850 = inttoptr i64 %v7849 to ptr
  %call7851 = call i32 @myl_rc_take_failure(ptr %p7850) nomerge, !dbg !190
  store i32 %call7851, ptr %slot1400, align 8
  %v7852 = load i64, ptr %slot1, align 8
  %p7853 = inttoptr i64 %v7852 to ptr
  %v7854 = load i32, ptr %slot1400, align 8
  %call7855 = call i32 @myl_qbe_rc_status(ptr %p7853, i32 %v7854) nomerge, !dbg !190
  store i32 %call7855, ptr %slot1401, align 8
  br label %bb_failure
bb_rcsuccess2195:
  br label %bb_rcmoved2164
bb_rcmoved2164:
  %v7856 = load i64, ptr %slot17, align 8
  %p7857 = inttoptr i64 %v7856 to ptr
  store i32 0, ptr %p7857, align 4, !alias.scope !3, !noalias !4
  %v7858 = load i64, ptr %slot22, align 8
  %p7859 = inttoptr i64 %v7858 to ptr
  store i32 2, ptr %p7859, align 4, !alias.scope !3, !noalias !4
  %v7860 = load i64, ptr %slot21, align 8
  %p7861 = inttoptr i64 %v7860 to ptr
  store i32 1, ptr %p7861, align 4, !alias.scope !3, !noalias !4
  %v7862 = load i64, ptr %slot28, align 8
  store i64 %v7862, ptr %slot1402, align 8
  %v7863 = load i64, ptr %slot1402, align 8
  %v7864 = load i64, ptr %slot1368, align 8
  %p7865 = inttoptr i64 %v7863 to ptr
  %p7866 = inttoptr i64 %v7864 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7866, ptr %p7865, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v7867 = load i64, ptr %slot21, align 8
  %p7868 = inttoptr i64 %v7867 to ptr
  store i32 0, ptr %p7868, align 4, !alias.scope !3, !noalias !4
  %v7869 = load i64, ptr %slot1360, align 8
  %v7870 = load i64, ptr %slot57, align 8
  %p7871 = inttoptr i64 %v7870 to ptr
  store i64 %v7869, ptr %p7871, align 8, !alias.scope !3, !noalias !4
  %v7872 = load i64, ptr %slot57, align 8
  %p7873 = inttoptr i64 %v7872 to ptr
  %ld7874 = load i64, ptr %p7873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7874, ptr %slot1403, align 8
  %v7875 = load i64, ptr %slot24, align 8
  store i64 %v7875, ptr %slot1404, align 8
  %v7876 = load i64, ptr %slot1403, align 8
  %v7877 = load i64, ptr %slot1404, align 8
  %p7878 = inttoptr i64 %v7876 to ptr
  %p7879 = inttoptr i64 %v7877 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7879, ptr %p7878, i64 56, i1 false)
  %v7880 = load i64, ptr %slot18, align 8
  %p7881 = inttoptr i64 %v7880 to ptr
  store i32 2, ptr %p7881, align 4, !alias.scope !3, !noalias !4
  %v7882 = load i64, ptr %slot17, align 8
  %p7883 = inttoptr i64 %v7882 to ptr
  store i32 1, ptr %p7883, align 4, !alias.scope !3, !noalias !4
  %v7884 = load i64, ptr %slot1404, align 8
  %v7885 = load i64, ptr %slot57, align 8
  %p7886 = inttoptr i64 %v7885 to ptr
  store i64 %v7884, ptr %p7886, align 8, !alias.scope !3, !noalias !4
  %v7887 = load i64, ptr %slot57, align 8
  %p7888 = inttoptr i64 %v7887 to ptr
  %ld7889 = load i64, ptr %p7888, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7889, ptr %slot1405, align 8
  %v7890 = load i64, ptr %slot17, align 8
  %p7891 = inttoptr i64 %v7890 to ptr
  %ld7892 = load i32, ptr %p7891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7892, ptr %slot1406, align 8
  %v7893 = load i64, ptr %slot18, align 8
  %p7894 = inttoptr i64 %v7893 to ptr
  %ld7895 = load i32, ptr %p7894, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7895, ptr %slot1407, align 8
  %v7896 = load i32, ptr %slot1407, align 8
  %op7897 = and i32 %v7896, 24
  store i32 %op7897, ptr %slot1407, align 8
  %v7898 = load i32, ptr %slot1407, align 8
  %cmp7899 = icmp eq i32 %v7898, 0
  %cv7900 = zext i1 %cmp7899 to i32
  store i32 %cv7900, ptr %slot1408, align 8
  %v7901 = load i32, ptr %slot1406, align 8
  %v7902 = load i32, ptr %slot1408, align 8
  %op7903 = and i32 %v7901, %v7902
  store i32 %op7903, ptr %slot1409, align 8
  %v7904 = load i32, ptr %slot1409, align 8
  %cv7905 = zext i32 %v7904 to i64
  %cond7906 = icmp ne i64 %cv7905, 0
  br i1 %cond7906, label %bb_rcprivateown2214, label %bb_rcprivateloan2214
bb_rcprivateown2214:
  %v7907 = load i64, ptr %slot28, align 8
  store i64 %v7907, ptr %slot1410, align 8
  %v7908 = load i64, ptr %slot71, align 8
  store i64 %v7908, ptr %slot1411, align 8
  %v7909 = load i64, ptr %slot70, align 8
  %v7910 = load i64, ptr %slot1410, align 8
  %v7911 = load i64, ptr %slot1405, align 8
  %v7912 = load i64, ptr %slot1411, align 8
  %cv7913 = trunc i64 %v7912 to i32
  %call7914 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v7909, i64 %v7910, i64 %v7911, i32 %cv7913) nomerge, !dbg !192
  store i32 %call7914, ptr %slot1412, align 8
  %v7915 = load i32, ptr %slot1412, align 8
  %cv7916 = zext i32 %v7915 to i64
  %cond7917 = icmp ne i64 %cv7916, 0
  br i1 %cond7917, label %bb_rcsuccess2218, label %bb_rcfailure2218
bb_rcfailure2218:
  %v7918 = load i64, ptr %slot70, align 8
  %p7919 = inttoptr i64 %v7918 to ptr
  %call7920 = call i32 @myl_rc_take_failure(ptr %p7919) nomerge, !dbg !192
  store i32 %call7920, ptr %slot1413, align 8
  %v7921 = load i64, ptr %slot1, align 8
  %p7922 = inttoptr i64 %v7921 to ptr
  %v7923 = load i32, ptr %slot1413, align 8
  %call7924 = call i32 @myl_qbe_rc_status(ptr %p7922, i32 %v7923) nomerge, !dbg !192
  store i32 %call7924, ptr %slot1414, align 8
  br label %bb_failure
bb_rcsuccess2218:
  %v7925 = load i64, ptr %slot17, align 8
  %p7926 = inttoptr i64 %v7925 to ptr
  store i32 0, ptr %p7926, align 4, !alias.scope !3, !noalias !4
  %v7927 = load i64, ptr %slot22, align 8
  %p7928 = inttoptr i64 %v7927 to ptr
  store i32 2, ptr %p7928, align 4, !alias.scope !3, !noalias !4
  %v7929 = load i64, ptr %slot21, align 8
  %p7930 = inttoptr i64 %v7929 to ptr
  store i32 1, ptr %p7930, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2214
bb_rcprivateloan2214:
  %v7931 = load i64, ptr %slot17, align 8
  %p7932 = inttoptr i64 %v7931 to ptr
  %ld7933 = load i32, ptr %p7932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7933, ptr %slot1415, align 8
  %v7934 = load i64, ptr %slot18, align 8
  %p7935 = inttoptr i64 %v7934 to ptr
  %ld7936 = load i32, ptr %p7935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7936, ptr %slot1416, align 8
  %v7937 = load i32, ptr %slot1416, align 8
  %cmp7938 = icmp eq i32 %v7937, 16
  %cv7939 = zext i1 %cmp7938 to i32
  store i32 %cv7939, ptr %slot1417, align 8
  %v7940 = load i32, ptr %slot1417, align 8
  %v7941 = load i32, ptr %slot1415, align 8
  %op7942 = and i32 %v7940, %v7941
  store i32 %op7942, ptr %slot1417, align 8
  %v7943 = load i32, ptr %slot1417, align 8
  %cv7944 = zext i32 %v7943 to i64
  %cond7945 = icmp ne i64 %cv7944, 0
  br i1 %cond7945, label %bb_rcprivatemove2214, label %bb_rcprivatenew2214
bb_rcprivatemove2214:
  %v7946 = load i64, ptr %slot28, align 8
  store i64 %v7946, ptr %slot1418, align 8
  %v7947 = load i64, ptr %slot1405, align 8
  %v7948 = load i64, ptr %slot1418, align 8
  %p7949 = inttoptr i64 %v7947 to ptr
  %p7950 = inttoptr i64 %v7948 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7950, ptr %p7949, i64 56, i1 false)
  %v7951 = load i64, ptr %slot1405, align 8
  %p7952 = inttoptr i64 %v7951 to ptr
  call void @llvm.memset.p0.i64(ptr %p7952, i8 0, i64 56, i1 false), !dbg !192
  %v7953 = load i64, ptr %slot22, align 8
  %p7954 = inttoptr i64 %v7953 to ptr
  store i32 2, ptr %p7954, align 4, !alias.scope !3, !noalias !4
  %v7955 = load i64, ptr %slot22, align 8
  %p7956 = inttoptr i64 %v7955 to ptr
  store i32 16, ptr %p7956, align 4, !alias.scope !3, !noalias !4
  %v7957 = load i64, ptr %slot21, align 8
  %p7958 = inttoptr i64 %v7957 to ptr
  store i32 1, ptr %p7958, align 4, !alias.scope !3, !noalias !4
  %v7959 = load i64, ptr %slot17, align 8
  %p7960 = inttoptr i64 %v7959 to ptr
  store i32 0, ptr %p7960, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2214
bb_rcprivatenew2214:
  %v7961 = load i64, ptr %slot28, align 8
  store i64 %v7961, ptr %slot1419, align 8
  %v7962 = load i64, ptr %slot70, align 8
  %v7963 = load i64, ptr %slot1419, align 8
  %v7964 = load i64, ptr %slot1405, align 8
  %call7965 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v7962, i64 %v7963, i64 %v7964) nomerge, !dbg !192
  store i32 %call7965, ptr %slot1420, align 8
  %v7966 = load i32, ptr %slot1420, align 8
  %cv7967 = zext i32 %v7966 to i64
  %cond7968 = icmp ne i64 %cv7967, 0
  br i1 %cond7968, label %bb_rcsuccess2236, label %bb_rcfailure2236
bb_rcfailure2236:
  %v7969 = load i64, ptr %slot70, align 8
  %p7970 = inttoptr i64 %v7969 to ptr
  %call7971 = call i32 @myl_rc_take_failure(ptr %p7970) nomerge, !dbg !192
  store i32 %call7971, ptr %slot1421, align 8
  %v7972 = load i64, ptr %slot1, align 8
  %p7973 = inttoptr i64 %v7972 to ptr
  %v7974 = load i32, ptr %slot1421, align 8
  %call7975 = call i32 @myl_qbe_rc_status(ptr %p7973, i32 %v7974) nomerge, !dbg !192
  store i32 %call7975, ptr %slot1422, align 8
  br label %bb_failure
bb_rcsuccess2236:
  %v7976 = load i64, ptr %slot22, align 8
  %p7977 = inttoptr i64 %v7976 to ptr
  store i32 2, ptr %p7977, align 4, !alias.scope !3, !noalias !4
  %v7978 = load i64, ptr %slot22, align 8
  %p7979 = inttoptr i64 %v7978 to ptr
  store i32 16, ptr %p7979, align 4, !alias.scope !3, !noalias !4
  %v7980 = load i64, ptr %slot21, align 8
  %p7981 = inttoptr i64 %v7980 to ptr
  store i32 1, ptr %p7981, align 4, !alias.scope !3, !noalias !4
  %v7982 = load i64, ptr %slot17, align 8
  %p7983 = inttoptr i64 %v7982 to ptr
  %ld7984 = load i32, ptr %p7983, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7984, ptr %slot1423, align 8
  %v7985 = load i32, ptr %slot1423, align 8
  %cv7986 = zext i32 %v7985 to i64
  %cond7987 = icmp ne i64 %cv7986, 0
  br i1 %cond7987, label %bb_rcslotdrop2244, label %bb_rcslotdone2244
bb_rcslotdrop2244:
  %v7988 = load i64, ptr %slot17, align 8
  %p7989 = inttoptr i64 %v7988 to ptr
  store i32 0, ptr %p7989, align 4, !alias.scope !3, !noalias !4
  %v7990 = load i64, ptr %slot24, align 8
  store i64 %v7990, ptr %slot1424, align 8
  %v7991 = load i64, ptr %slot18, align 8
  %p7992 = inttoptr i64 %v7991 to ptr
  %ld7993 = load i32, ptr %p7992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7993, ptr %slot1425, align 8
  %v7994 = load i32, ptr %slot1425, align 8
  %op7995 = and i32 %v7994, 28
  store i32 %op7995, ptr %slot1426, align 8
  %v7996 = load i32, ptr %slot1426, align 8
  %cv7997 = zext i32 %v7996 to i64
  %cond7998 = icmp ne i64 %cv7997, 0
  br i1 %cond7998, label %bb_rcslotrole2244, label %bb_rcslotowner2244
bb_rcslotrole2244:
  %v7999 = load i64, ptr %slot70, align 8
  store i64 %v7999, ptr %slot1427, align 8
  %v8000 = load i64, ptr %slot1427, align 8
  %v8001 = load i64, ptr %slot1424, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v8000, i64 %v8001) nomerge, !dbg !192
  br label %bb_rcslotdone2244
bb_rcslotowner2244:
  %v8002 = load i64, ptr %slot70, align 8
  store i64 %v8002, ptr %slot1428, align 8
  %v8003 = load i64, ptr %slot1428, align 8
  %v8004 = load i64, ptr %slot1424, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v8003, i64 %v8004) nomerge, !dbg !192
  br label %bb_rcslotdone2244
bb_rcslotdone2244:
  br label %bb_rcprivateprepared2214
bb_rcprivateprepared2214:
  %v8005 = load i64, ptr %slot15, align 8
  %p8006 = inttoptr i64 %v8005 to ptr
  %ld8007 = load i32, ptr %p8006, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8007, ptr %slot1429, align 8
  %v8008 = load i32, ptr %slot1429, align 8
  %cv8009 = zext i32 %v8008 to i64
  %cond8010 = icmp ne i64 %cv8009, 0
  br i1 %cond8010, label %bb_rcslotdrop2254, label %bb_rcslotdone2254
bb_rcslotdrop2254:
  %v8011 = load i64, ptr %slot15, align 8
  %p8012 = inttoptr i64 %v8011 to ptr
  store i32 0, ptr %p8012, align 4, !alias.scope !3, !noalias !4
  %v8013 = load i64, ptr %slot55, align 8
  store i64 %v8013, ptr %slot1430, align 8
  %v8014 = load i64, ptr %slot16, align 8
  %p8015 = inttoptr i64 %v8014 to ptr
  %ld8016 = load i32, ptr %p8015, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8016, ptr %slot1431, align 8
  %v8017 = load i32, ptr %slot1431, align 8
  %op8018 = and i32 %v8017, 28
  store i32 %op8018, ptr %slot1432, align 8
  %v8019 = load i32, ptr %slot1432, align 8
  %cv8020 = zext i32 %v8019 to i64
  %cond8021 = icmp ne i64 %cv8020, 0
  br i1 %cond8021, label %bb_rcslotrole2254, label %bb_rcslotowner2254
bb_rcslotrole2254:
  %v8022 = load i64, ptr %slot70, align 8
  store i64 %v8022, ptr %slot1433, align 8
  %v8023 = load i64, ptr %slot1433, align 8
  %v8024 = load i64, ptr %slot1430, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v8023, i64 %v8024) nomerge, !dbg !192
  br label %bb_rcslotdone2254
bb_rcslotowner2254:
  %v8025 = load i64, ptr %slot70, align 8
  store i64 %v8025, ptr %slot1434, align 8
  %v8026 = load i64, ptr %slot1434, align 8
  %v8027 = load i64, ptr %slot1430, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v8026, i64 %v8027) nomerge, !dbg !192
  br label %bb_rcslotdone2254
bb_rcslotdone2254:
  %v8028 = load i64, ptr %slot55, align 8
  store i64 %v8028, ptr %slot1435, align 8
  %v8029 = load i64, ptr %slot28, align 8
  store i64 %v8029, ptr %slot1436, align 8
  %v8030 = load i64, ptr %slot1436, align 8
  %v8031 = load i64, ptr %slot1435, align 8
  %p8032 = inttoptr i64 %v8030 to ptr
  %p8033 = inttoptr i64 %v8031 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8033, ptr %p8032, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v8034 = load i64, ptr %slot21, align 8
  %p8035 = inttoptr i64 %v8034 to ptr
  store i32 0, ptr %p8035, align 4, !alias.scope !3, !noalias !4
  %v8036 = load i64, ptr %slot16, align 8
  %p8037 = inttoptr i64 %v8036 to ptr
  store i32 2, ptr %p8037, align 4, !alias.scope !3, !noalias !4
  %v8038 = load i64, ptr %slot22, align 8
  %p8039 = inttoptr i64 %v8038 to ptr
  %ld8040 = load i32, ptr %p8039, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8040, ptr %slot1437, align 8
  %v8041 = load i32, ptr %slot1437, align 8
  %v8042 = load i64, ptr %slot16, align 8
  %p8043 = inttoptr i64 %v8042 to ptr
  store i32 %v8041, ptr %p8043, align 4, !alias.scope !3, !noalias !4
  %v8044 = load i64, ptr %slot15, align 8
  %p8045 = inttoptr i64 %v8044 to ptr
  store i32 1, ptr %p8045, align 4, !alias.scope !3, !noalias !4
  %v8046 = load i64, ptr %slot36, align 8
  %p8047 = inttoptr i64 %v8046 to ptr
  %ld8048 = load i64, ptr %p8047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8048, ptr %slot1438, align 8
  %v8049 = load i64, ptr %slot1438, align 8
  %v8050 = load i64, ptr %slot57, align 8
  %p8051 = inttoptr i64 %v8050 to ptr
  store i64 %v8049, ptr %p8051, align 8, !alias.scope !3, !noalias !4
  %v8052 = load i64, ptr %slot57, align 8
  %p8053 = inttoptr i64 %v8052 to ptr
  %ld8054 = load i64, ptr %p8053, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8054, ptr %slot1439, align 8
  %v8055 = load i64, ptr %slot1439, align 8
  %op8056 = add i64 %v8055, 0
  store i64 %op8056, ptr %slot1440, align 8
  %v8057 = load i64, ptr %slot1440, align 8
  %v8058 = load i64, ptr %slot57, align 8
  %p8059 = inttoptr i64 %v8058 to ptr
  store i64 %v8057, ptr %p8059, align 8, !alias.scope !3, !noalias !4
  %v8060 = load i64, ptr %slot17, align 8
  %p8061 = inttoptr i64 %v8060 to ptr
  %ld8062 = load i32, ptr %p8061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8062, ptr %slot1441, align 8
  %v8063 = load i32, ptr %slot1441, align 8
  %cv8064 = zext i32 %v8063 to i64
  %cond8065 = icmp ne i64 %cv8064, 0
  br i1 %cond8065, label %bb_rcslotdrop2273, label %bb_rcslotdone2273
bb_rcslotdrop2273:
  %v8066 = load i64, ptr %slot17, align 8
  %p8067 = inttoptr i64 %v8066 to ptr
  store i32 0, ptr %p8067, align 4, !alias.scope !3, !noalias !4
  %v8068 = load i64, ptr %slot24, align 8
  store i64 %v8068, ptr %slot1442, align 8
  %v8069 = load i64, ptr %slot18, align 8
  %p8070 = inttoptr i64 %v8069 to ptr
  %ld8071 = load i32, ptr %p8070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8071, ptr %slot1443, align 8
  %v8072 = load i32, ptr %slot1443, align 8
  %op8073 = and i32 %v8072, 28
  store i32 %op8073, ptr %slot1444, align 8
  %v8074 = load i32, ptr %slot1444, align 8
  %cv8075 = zext i32 %v8074 to i64
  %cond8076 = icmp ne i64 %cv8075, 0
  br i1 %cond8076, label %bb_rcslotrole2273, label %bb_rcslotowner2273
bb_rcslotrole2273:
  %v8077 = load i64, ptr %slot70, align 8
  store i64 %v8077, ptr %slot1445, align 8
  %v8078 = load i64, ptr %slot1445, align 8
  %v8079 = load i64, ptr %slot1442, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v8078, i64 %v8079) nomerge, !dbg !194
  br label %bb_rcslotdone2273
bb_rcslotowner2273:
  %v8080 = load i64, ptr %slot70, align 8
  store i64 %v8080, ptr %slot1446, align 8
  %v8081 = load i64, ptr %slot1446, align 8
  %v8082 = load i64, ptr %slot1442, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v8081, i64 %v8082) nomerge, !dbg !194
  br label %bb_rcslotdone2273
bb_rcslotdone2273:
  %v8083 = load i64, ptr %slot57, align 8
  %p8084 = inttoptr i64 %v8083 to ptr
  %ld8085 = load i64, ptr %p8084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8085, ptr %slot1447, align 8
  %v8086 = load i64, ptr %slot1447, align 8
  %op8087 = add i64 %v8086, 0
  store i64 %op8087, ptr %slot1448, align 8
  %v8088 = load i64, ptr %slot1448, align 8
  %p8089 = inttoptr i64 %v8088 to ptr
  %ld8090 = load i64, ptr %p8089, align 8
  store i64 %ld8090, ptr %slot1449, align 8
  %v8091 = load i64, ptr %slot1449, align 8
  %v8092 = load i64, ptr %slot57, align 8
  %p8093 = inttoptr i64 %v8092 to ptr
  store i64 %v8091, ptr %p8093, align 8, !alias.scope !3, !noalias !4
  %v8094 = load i64, ptr %slot57, align 8
  %p8095 = inttoptr i64 %v8094 to ptr
  %ld8096 = load i64, ptr %p8095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8096, ptr %slot1450, align 8
  %v8097 = load i64, ptr %slot1450, align 8
  %v8098 = load i64, ptr %slot26, align 8
  %p8099 = inttoptr i64 %v8098 to ptr
  store i64 %v8097, ptr %p8099, align 8, !alias.scope !3, !noalias !4
  %v8100 = load i64, ptr %slot26, align 8
  store i64 %v8100, ptr %slot1451, align 8
  %v8101 = load i64, ptr %slot28, align 8
  store i64 %v8101, ptr %slot1452, align 8
  %v8102 = load i64, ptr %slot1451, align 8
  %p8103 = inttoptr i64 %v8102 to ptr
  %ld8104 = load i64, ptr %p8103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8104, ptr %slot1453, align 8
  %v8105 = load i64, ptr %slot1453, align 8
  %cmp8106 = icmp ne i64 %v8105, 0
  %cv8107 = zext i1 %cmp8106 to i32
  store i32 %cv8107, ptr %slot1454, align 8
  %v8108 = load i32, ptr %slot1454, align 8
  %cv8109 = zext i32 %v8108 to i64
  %cond8110 = icmp ne i64 %cv8109, 0
  br i1 %cond8110, label %bb_rcgnn2287, label %bb_rcgstore2287
bb_rcgnn2287:
  %v8111 = load i64, ptr %slot1453, align 8
  %op8112 = sub i64 %v8111, 16
  store i64 %op8112, ptr %slot1455, align 8
  %v8113 = load i64, ptr %slot1453, align 8
  %p8114 = inttoptr i64 %v8113 to ptr
  %rgep8115 = getelementptr i8, ptr %p8114, i64 -16
  %ld8116 = load i64, ptr %rgep8115, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8116, ptr %slot1456, align 8
  %v8117 = load i64, ptr %slot1456, align 8
  %op8118 = and i64 %v8117, 4611686018427387906
  store i64 %op8118, ptr %slot1457, align 8
  %v8119 = load i64, ptr %slot1457, align 8
  %cmp8120 = icmp ne i64 %v8119, 0
  %cv8121 = zext i1 %cmp8120 to i32
  store i32 %cv8121, ptr %slot1458, align 8
  %v8122 = load i32, ptr %slot1458, align 8
  %cv8123 = zext i32 %v8122 to i64
  %cond8124 = icmp ne i64 %cv8123, 0
  br i1 %cond8124, label %bb_rcgstore2287, label %bb_rcginc2287
bb_rcginc2287:
  %v8125 = load i64, ptr %slot1453, align 8
  %op8126 = sub i64 %v8125, 24
  store i64 %op8126, ptr %slot1459, align 8
  %v8127 = load i64, ptr %slot1453, align 8
  %p8128 = inttoptr i64 %v8127 to ptr
  %rgep8129 = getelementptr i8, ptr %p8128, i64 -24
  %ld8130 = load i64, ptr %rgep8129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8130, ptr %slot1460, align 8
  %v8131 = load i64, ptr %slot1460, align 8
  %op8132 = add i64 %v8131, 1
  store i64 %op8132, ptr %slot1461, align 8
  %v8133 = load i64, ptr %slot1461, align 8
  %cmp8134 = icmp eq i64 %v8133, 0
  %cv8135 = zext i1 %cmp8134 to i32
  store i32 %cv8135, ptr %slot1462, align 8
  %v8136 = load i32, ptr %slot1462, align 8
  %cv8137 = zext i32 %v8136 to i64
  %cond8138 = icmp ne i64 %cv8137, 0
  br i1 %cond8138, label %bb_rcglimit2287, label %bb_rcgcapacity2287
bb_rcglimit2287:
  %v8139 = load i64, ptr %slot1, align 8
  %p8140 = inttoptr i64 %v8139 to ptr
  %call8141 = call i32 @myl_qbe_rc_status(ptr %p8140, i32 2) nomerge, !dbg !196
  store i32 %call8141, ptr %slot1463, align 8
  br label %bb_failure
bb_rcgcapacity2287:
  %v8142 = load i64, ptr %slot1461, align 8
  %v8143 = load i64, ptr %slot1453, align 8
  %p8144 = inttoptr i64 %v8143 to ptr
  %rgep8145 = getelementptr i8, ptr %p8144, i64 -24
  store i64 %v8142, ptr %rgep8145, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore2287
bb_rcgstore2287:
  %v8146 = load i64, ptr %slot1453, align 8
  %v8147 = load i64, ptr %slot1452, align 8
  %p8148 = inttoptr i64 %v8147 to ptr
  store i64 %v8146, ptr %p8148, align 8, !alias.scope !3, !noalias !4
  %v8149 = load i64, ptr %slot22, align 8
  %p8150 = inttoptr i64 %v8149 to ptr
  store i32 2, ptr %p8150, align 4, !alias.scope !3, !noalias !4
  %v8151 = load i64, ptr %slot22, align 8
  %p8152 = inttoptr i64 %v8151 to ptr
  store i32 16, ptr %p8152, align 4, !alias.scope !3, !noalias !4
  %v8153 = load i64, ptr %slot21, align 8
  %p8154 = inttoptr i64 %v8153 to ptr
  store i32 1, ptr %p8154, align 4, !alias.scope !3, !noalias !4
  %v8155 = load i64, ptr %slot17, align 8
  %p8156 = inttoptr i64 %v8155 to ptr
  %ld8157 = load i32, ptr %p8156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8157, ptr %slot1464, align 8
  %v8158 = load i32, ptr %slot1464, align 8
  %cv8159 = zext i32 %v8158 to i64
  %cond8160 = icmp ne i64 %cv8159, 0
  br i1 %cond8160, label %bb_rcslotdrop2303, label %bb_rcslotdone2303
bb_rcslotdrop2303:
  %v8161 = load i64, ptr %slot17, align 8
  %p8162 = inttoptr i64 %v8161 to ptr
  store i32 0, ptr %p8162, align 4, !alias.scope !3, !noalias !4
  %v8163 = load i64, ptr %slot24, align 8
  store i64 %v8163, ptr %slot1465, align 8
  %v8164 = load i64, ptr %slot18, align 8
  %p8165 = inttoptr i64 %v8164 to ptr
  %ld8166 = load i32, ptr %p8165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8166, ptr %slot1466, align 8
  %v8167 = load i32, ptr %slot1466, align 8
  %op8168 = and i32 %v8167, 28
  store i32 %op8168, ptr %slot1467, align 8
  %v8169 = load i32, ptr %slot1467, align 8
  %cv8170 = zext i32 %v8169 to i64
  %cond8171 = icmp ne i64 %cv8170, 0
  br i1 %cond8171, label %bb_rcslotrole2303, label %bb_rcslotowner2303
bb_rcslotrole2303:
  %v8172 = load i64, ptr %slot70, align 8
  store i64 %v8172, ptr %slot1468, align 8
  %v8173 = load i64, ptr %slot1468, align 8
  %v8174 = load i64, ptr %slot1465, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8173, i64 %v8174) nomerge, !dbg !196
  br label %bb_rcslotdone2303
bb_rcslotowner2303:
  %v8175 = load i64, ptr %slot70, align 8
  store i64 %v8175, ptr %slot1469, align 8
  %v8176 = load i64, ptr %slot1469, align 8
  %v8177 = load i64, ptr %slot1465, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8176, i64 %v8177) nomerge, !dbg !196
  br label %bb_rcslotdone2303
bb_rcslotdone2303:
  %v8178 = load i64, ptr %slot24, align 8
  store i64 %v8178, ptr %slot1470, align 8
  %v8179 = load i64, ptr %slot28, align 8
  store i64 %v8179, ptr %slot1471, align 8
  %v8180 = load i64, ptr %slot1471, align 8
  %v8181 = load i64, ptr %slot1470, align 8
  %p8182 = inttoptr i64 %v8180 to ptr
  %p8183 = inttoptr i64 %v8181 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8183, ptr %p8182, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8184 = load i64, ptr %slot18, align 8
  %p8185 = inttoptr i64 %v8184 to ptr
  store i32 2, ptr %p8185, align 4, !alias.scope !3, !noalias !4
  %v8186 = load i64, ptr %slot22, align 8
  %p8187 = inttoptr i64 %v8186 to ptr
  %ld8188 = load i32, ptr %p8187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8188, ptr %slot1472, align 8
  %v8189 = load i32, ptr %slot1472, align 8
  %v8190 = load i64, ptr %slot18, align 8
  %p8191 = inttoptr i64 %v8190 to ptr
  store i32 %v8189, ptr %p8191, align 4, !alias.scope !3, !noalias !4
  %v8192 = load i64, ptr %slot21, align 8
  %p8193 = inttoptr i64 %v8192 to ptr
  store i32 0, ptr %p8193, align 4, !alias.scope !3, !noalias !4
  %v8194 = load i64, ptr %slot17, align 8
  %p8195 = inttoptr i64 %v8194 to ptr
  store i32 1, ptr %p8195, align 4, !alias.scope !3, !noalias !4
  %v8196 = load i64, ptr %slot1470, align 8
  %p8197 = inttoptr i64 %v8196 to ptr
  %ld8198 = load i64, ptr %p8197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8198, ptr %slot1473, align 8
  %v8199 = load i64, ptr %slot1473, align 8
  %v8200 = load i64, ptr %slot57, align 8
  %p8201 = inttoptr i64 %v8200 to ptr
  store i64 %v8199, ptr %p8201, align 8, !alias.scope !3, !noalias !4
  %v8202 = load i64, ptr %slot57, align 8
  %p8203 = inttoptr i64 %v8202 to ptr
  %ld8204 = load i64, ptr %p8203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8204, ptr %slot1474, align 8
  %v8205 = load i64, ptr %slot36, align 8
  %p8206 = inttoptr i64 %v8205 to ptr
  %ld8207 = load i64, ptr %p8206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8207, ptr %slot1475, align 8
  %v8208 = load i64, ptr %slot17, align 8
  %p8209 = inttoptr i64 %v8208 to ptr
  %ld8210 = load i32, ptr %p8209, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8210, ptr %slot1476, align 8
  %v8211 = load i32, ptr %slot1476, align 8
  %cv8212 = zext i32 %v8211 to i64
  %cond8213 = icmp ne i64 %cv8212, 0
  br i1 %cond8213, label %bb_rcslotdrop2324, label %bb_rcslotdone2324
bb_rcslotdrop2324:
  %v8214 = load i64, ptr %slot17, align 8
  %p8215 = inttoptr i64 %v8214 to ptr
  store i32 0, ptr %p8215, align 4, !alias.scope !3, !noalias !4
  %v8216 = load i64, ptr %slot24, align 8
  store i64 %v8216, ptr %slot1477, align 8
  %v8217 = load i64, ptr %slot18, align 8
  %p8218 = inttoptr i64 %v8217 to ptr
  %ld8219 = load i32, ptr %p8218, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8219, ptr %slot1478, align 8
  %v8220 = load i32, ptr %slot1478, align 8
  %op8221 = and i32 %v8220, 28
  store i32 %op8221, ptr %slot1479, align 8
  %v8222 = load i32, ptr %slot1479, align 8
  %cv8223 = zext i32 %v8222 to i64
  %cond8224 = icmp ne i64 %cv8223, 0
  br i1 %cond8224, label %bb_rcslotrole2324, label %bb_rcslotowner2324
bb_rcslotrole2324:
  %v8225 = load i64, ptr %slot70, align 8
  store i64 %v8225, ptr %slot1480, align 8
  %v8226 = load i64, ptr %slot1477, align 8
  %p8227 = inttoptr i64 %v8226 to ptr
  %ld8228 = load i64, ptr %p8227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8228, ptr %slot1481, align 8
  %v8229 = load i64, ptr %slot1481, align 8
  %cmp8230 = icmp ne i64 %v8229, 0
  %cv8231 = zext i1 %cmp8230 to i32
  store i32 %cv8231, ptr %slot1482, align 8
  %v8232 = load i32, ptr %slot1482, align 8
  %cv8233 = zext i32 %v8232 to i64
  %cond8234 = icmp ne i64 %cv8233, 0
  br i1 %cond8234, label %bb_rcgnn2340, label %bb_rcgdone2340
bb_rcgnn2340:
  %v8235 = load i64, ptr %slot1481, align 8
  %op8236 = sub i64 %v8235, 16
  store i64 %op8236, ptr %slot1483, align 8
  %v8237 = load i64, ptr %slot1481, align 8
  %p8238 = inttoptr i64 %v8237 to ptr
  %rgep8239 = getelementptr i8, ptr %p8238, i64 -16
  %ld8240 = load i64, ptr %rgep8239, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8240, ptr %slot1484, align 8
  %v8241 = load i64, ptr %slot1484, align 8
  %op8242 = and i64 %v8241, 4611686018427387906
  store i64 %op8242, ptr %slot1485, align 8
  %v8243 = load i64, ptr %slot1485, align 8
  %cmp8244 = icmp ne i64 %v8243, 0
  %cv8245 = zext i1 %cmp8244 to i32
  store i32 %cv8245, ptr %slot1486, align 8
  %v8246 = load i32, ptr %slot1486, align 8
  %cv8247 = zext i32 %v8246 to i64
  %cond8248 = icmp ne i64 %cv8247, 0
  br i1 %cond8248, label %bb_rcgclear2340, label %bb_rcgcounted2340
bb_rcgcounted2340:
  %v8249 = load i64, ptr %slot1481, align 8
  %op8250 = sub i64 %v8249, 24
  store i64 %op8250, ptr %slot1487, align 8
  %v8251 = load i64, ptr %slot1481, align 8
  %p8252 = inttoptr i64 %v8251 to ptr
  %rgep8253 = getelementptr i8, ptr %p8252, i64 -24
  %ld8254 = load i64, ptr %rgep8253, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8254, ptr %slot1488, align 8
  %v8255 = load i64, ptr %slot1488, align 8
  %op8256 = sub i64 %v8255, 1
  store i64 %op8256, ptr %slot1489, align 8
  %v8257 = load i64, ptr %slot1489, align 8
  %cmp8258 = icmp eq i64 %v8257, 0
  %cv8259 = zext i1 %cmp8258 to i32
  store i32 %cv8259, ptr %slot1490, align 8
  %v8260 = load i32, ptr %slot1490, align 8
  %cv8261 = zext i32 %v8260 to i64
  %cond8262 = icmp ne i64 %cv8261, 0
  br i1 %cond8262, label %bb_rcglast2340, label %bb_rcgdec2340
bb_rcglast2340:
  %v8263 = load i64, ptr %slot1481, align 8
  %op8264 = sub i64 %v8263, 32
  store i64 %op8264, ptr %slot1491, align 8
  %v8265 = load i64, ptr %slot1481, align 8
  %p8266 = inttoptr i64 %v8265 to ptr
  %rgep8267 = getelementptr i8, ptr %p8266, i64 -32
  %ld8268 = load i64, ptr %rgep8267, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8268, ptr %slot1492, align 8
  %v8269 = load i64, ptr %slot1492, align 8
  %cmp8270 = icmp ne i64 %v8269, 0
  %cv8271 = zext i1 %cmp8270 to i32
  store i32 %cv8271, ptr %slot1493, align 8
  %v8272 = load i32, ptr %slot1493, align 8
  %cv8273 = zext i32 %v8272 to i64
  %cond8274 = icmp ne i64 %cv8273, 0
  br i1 %cond8274, label %bb_rcgdec2340, label %bb_rcgslow2340
bb_rcgslow2340:
  %v8275 = load i64, ptr %slot1480, align 8
  %v8276 = load i64, ptr %slot1477, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v8275, i64 %v8276) nomerge, !dbg !198
  br label %bb_rcgdone2340
bb_rcgdec2340:
  %v8277 = load i64, ptr %slot1489, align 8
  %v8278 = load i64, ptr %slot1481, align 8
  %p8279 = inttoptr i64 %v8278 to ptr
  %rgep8280 = getelementptr i8, ptr %p8279, i64 -24
  store i64 %v8277, ptr %rgep8280, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2340
bb_rcgclear2340:
  %v8281 = load i64, ptr %slot1477, align 8
  %p8282 = inttoptr i64 %v8281 to ptr
  store i64 0, ptr %p8282, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2340
bb_rcgdone2340:
  br label %bb_rcslotdone2324
bb_rcslotowner2324:
  %v8283 = load i64, ptr %slot70, align 8
  store i64 %v8283, ptr %slot1494, align 8
  %v8284 = load i64, ptr %slot1477, align 8
  %p8285 = inttoptr i64 %v8284 to ptr
  %ld8286 = load i64, ptr %p8285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8286, ptr %slot1495, align 8
  %v8287 = load i64, ptr %slot1495, align 8
  %cmp8288 = icmp ne i64 %v8287, 0
  %cv8289 = zext i1 %cmp8288 to i32
  store i32 %cv8289, ptr %slot1496, align 8
  %v8290 = load i32, ptr %slot1496, align 8
  %cv8291 = zext i32 %v8290 to i64
  %cond8292 = icmp ne i64 %cv8291, 0
  br i1 %cond8292, label %bb_rcgnn2355, label %bb_rcgdone2355
bb_rcgnn2355:
  %v8293 = load i64, ptr %slot1495, align 8
  %op8294 = sub i64 %v8293, 16
  store i64 %op8294, ptr %slot1497, align 8
  %v8295 = load i64, ptr %slot1495, align 8
  %p8296 = inttoptr i64 %v8295 to ptr
  %rgep8297 = getelementptr i8, ptr %p8296, i64 -16
  %ld8298 = load i64, ptr %rgep8297, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8298, ptr %slot1498, align 8
  %v8299 = load i64, ptr %slot1498, align 8
  %op8300 = and i64 %v8299, 4611686018427387906
  store i64 %op8300, ptr %slot1499, align 8
  %v8301 = load i64, ptr %slot1499, align 8
  %cmp8302 = icmp ne i64 %v8301, 0
  %cv8303 = zext i1 %cmp8302 to i32
  store i32 %cv8303, ptr %slot1500, align 8
  %v8304 = load i32, ptr %slot1500, align 8
  %cv8305 = zext i32 %v8304 to i64
  %cond8306 = icmp ne i64 %cv8305, 0
  br i1 %cond8306, label %bb_rcgclear2355, label %bb_rcgcounted2355
bb_rcgcounted2355:
  %v8307 = load i64, ptr %slot1495, align 8
  %op8308 = sub i64 %v8307, 32
  store i64 %op8308, ptr %slot1501, align 8
  %v8309 = load i64, ptr %slot1495, align 8
  %p8310 = inttoptr i64 %v8309 to ptr
  %rgep8311 = getelementptr i8, ptr %p8310, i64 -32
  %ld8312 = load i64, ptr %rgep8311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8312, ptr %slot1502, align 8
  %v8313 = load i64, ptr %slot1502, align 8
  %op8314 = sub i64 %v8313, 1
  store i64 %op8314, ptr %slot1503, align 8
  %v8315 = load i64, ptr %slot1503, align 8
  %cmp8316 = icmp eq i64 %v8315, 0
  %cv8317 = zext i1 %cmp8316 to i32
  store i32 %cv8317, ptr %slot1504, align 8
  %v8318 = load i32, ptr %slot1504, align 8
  %cv8319 = zext i32 %v8318 to i64
  %cond8320 = icmp ne i64 %cv8319, 0
  br i1 %cond8320, label %bb_rcglast2355, label %bb_rcgdec2355
bb_rcglast2355:
  %v8321 = load i64, ptr %slot1495, align 8
  %op8322 = sub i64 %v8321, 24
  store i64 %op8322, ptr %slot1505, align 8
  %v8323 = load i64, ptr %slot1495, align 8
  %p8324 = inttoptr i64 %v8323 to ptr
  %rgep8325 = getelementptr i8, ptr %p8324, i64 -24
  %ld8326 = load i64, ptr %rgep8325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8326, ptr %slot1506, align 8
  %v8327 = load i64, ptr %slot1506, align 8
  %cmp8328 = icmp ne i64 %v8327, 0
  %cv8329 = zext i1 %cmp8328 to i32
  store i32 %cv8329, ptr %slot1507, align 8
  %v8330 = load i32, ptr %slot1507, align 8
  %cv8331 = zext i32 %v8330 to i64
  %cond8332 = icmp ne i64 %cv8331, 0
  br i1 %cond8332, label %bb_rcgdec2355, label %bb_rcgslow2355
bb_rcgslow2355:
  %v8333 = load i64, ptr %slot1494, align 8
  %v8334 = load i64, ptr %slot1477, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v8333, i64 %v8334) nomerge, !dbg !198
  br label %bb_rcgdone2355
bb_rcgdec2355:
  %v8335 = load i64, ptr %slot1503, align 8
  %v8336 = load i64, ptr %slot1495, align 8
  %p8337 = inttoptr i64 %v8336 to ptr
  %rgep8338 = getelementptr i8, ptr %p8337, i64 -32
  store i64 %v8335, ptr %rgep8338, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2355
bb_rcgclear2355:
  %v8339 = load i64, ptr %slot1477, align 8
  %p8340 = inttoptr i64 %v8339 to ptr
  store i64 0, ptr %p8340, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2355
bb_rcgdone2355:
  br label %bb_rcslotdone2324
bb_rcslotdone2324:
  %v8341 = load i64, ptr %slot1475, align 8
  %op8342 = add i64 %v8341, 0
  store i64 %op8342, ptr %slot1508, align 8
  %v8343 = load i64, ptr %slot1508, align 8
  %op8344 = add i64 %v8343, 0
  store i64 %op8344, ptr %slot1509, align 8
  store i64 0, ptr %slot1510, align 8
  %v8345 = load i64, ptr %slot1509, align 8
  %p8346 = inttoptr i64 %v8345 to ptr
  %ld8347 = load i64, ptr %p8346, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8347, ptr %slot1511, align 8
  %v8348 = load i64, ptr %slot1511, align 8
  %cmp8349 = icmp ne i64 %v8348, 0
  %cv8350 = zext i1 %cmp8349 to i32
  store i32 %cv8350, ptr %slot1512, align 8
  %v8351 = load i32, ptr %slot1512, align 8
  %cv8352 = zext i32 %v8351 to i64
  %cond8353 = icmp ne i64 %cv8352, 0
  br i1 %cond8353, label %bb_rcguniquenn2362, label %bb_rcgunique2362
bb_rcguniquenn2362:
  %v8354 = load i64, ptr %slot1511, align 8
  %op8355 = sub i64 %v8354, 16
  store i64 %op8355, ptr %slot1513, align 8
  %v8356 = load i64, ptr %slot1511, align 8
  %p8357 = inttoptr i64 %v8356 to ptr
  %rgep8358 = getelementptr i8, ptr %p8357, i64 -16
  %ld8359 = load i64, ptr %rgep8358, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8359, ptr %slot1514, align 8
  %v8360 = load i64, ptr %slot1514, align 8
  %op8361 = and i64 %v8360, 6917529027641081858
  store i64 %op8361, ptr %slot1515, align 8
  %v8362 = load i64, ptr %slot1515, align 8
  %cmp8363 = icmp ne i64 %v8362, 0
  %cv8364 = zext i1 %cmp8363 to i32
  store i32 %cv8364, ptr %slot1516, align 8
  %v8365 = load i32, ptr %slot1516, align 8
  %cv8366 = zext i32 %v8365 to i64
  %cond8367 = icmp ne i64 %cv8366, 0
  br i1 %cond8367, label %bb_rcguniqueslow2362, label %bb_rcguniquecount2362
bb_rcguniquecount2362:
  %v8368 = load i64, ptr %slot1511, align 8
  %op8369 = sub i64 %v8368, 32
  store i64 %op8369, ptr %slot1517, align 8
  %v8370 = load i64, ptr %slot1511, align 8
  %p8371 = inttoptr i64 %v8370 to ptr
  %rgep8372 = getelementptr i8, ptr %p8371, i64 -32
  %ld8373 = load i64, ptr %rgep8372, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8373, ptr %slot1518, align 8
  %v8374 = load i64, ptr %slot1518, align 8
  %cmp8375 = icmp ult i64 %v8374, 2
  %cv8376 = zext i1 %cmp8375 to i32
  store i32 %cv8376, ptr %slot1519, align 8
  %v8377 = load i32, ptr %slot1519, align 8
  %cv8378 = zext i32 %v8377 to i64
  %cond8379 = icmp ne i64 %cv8378, 0
  br i1 %cond8379, label %bb_rcgunique2362, label %bb_rcguniqueslow2362
bb_rcguniqueslow2362:
  %v8380 = load i64, ptr %slot1, align 8
  %p8381 = inttoptr i64 %v8380 to ptr
  %p8382 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v8383 = load i64, ptr %slot1509, align 8
  %p8384 = inttoptr i64 %v8383 to ptr
  %v8385 = load i64, ptr %slot1510, align 8
  %p8386 = inttoptr i64 %v8385 to ptr
  %call8387 = call i32 @myl_qbe_rc_unique_field(ptr %p8381, ptr %p8382, ptr %p8384, ptr %p8386) nomerge, !dbg !198
  store i32 %call8387, ptr %slot1520, align 8
  %v8388 = load i32, ptr %slot1520, align 8
  %cv8389 = zext i32 %v8388 to i64
  %cond8390 = icmp ne i64 %cv8389, 0
  br i1 %cond8390, label %bb_rcunique2372, label %bb_failure
bb_rcunique2372:
  br label %bb_rcgunique2362
bb_rcgunique2362:
  %v8391 = load i64, ptr %slot1509, align 8
  %p8392 = inttoptr i64 %v8391 to ptr
  %ld8393 = load i64, ptr %p8392, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8393, ptr %slot1521, align 8
  %v8394 = load i64, ptr %slot1521, align 8
  %v8395 = load i64, ptr %slot57, align 8
  %p8396 = inttoptr i64 %v8395 to ptr
  store i64 %v8394, ptr %p8396, align 8, !alias.scope !3, !noalias !4
  %v8397 = load i64, ptr %slot57, align 8
  %p8398 = inttoptr i64 %v8397 to ptr
  %ld8399 = load i64, ptr %p8398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8399, ptr %slot1522, align 8
  %v8400 = load i64, ptr %slot17, align 8
  %p8401 = inttoptr i64 %v8400 to ptr
  %ld8402 = load i32, ptr %p8401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8402, ptr %slot1523, align 8
  %v8403 = load i32, ptr %slot1523, align 8
  %cv8404 = zext i32 %v8403 to i64
  %cond8405 = icmp ne i64 %cv8404, 0
  br i1 %cond8405, label %bb_rcslotdrop2377, label %bb_rcslotdone2377
bb_rcslotdrop2377:
  %v8406 = load i64, ptr %slot17, align 8
  %p8407 = inttoptr i64 %v8406 to ptr
  store i32 0, ptr %p8407, align 4, !alias.scope !3, !noalias !4
  %v8408 = load i64, ptr %slot24, align 8
  store i64 %v8408, ptr %slot1524, align 8
  %v8409 = load i64, ptr %slot18, align 8
  %p8410 = inttoptr i64 %v8409 to ptr
  %ld8411 = load i32, ptr %p8410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8411, ptr %slot1525, align 8
  %v8412 = load i32, ptr %slot1525, align 8
  %op8413 = and i32 %v8412, 28
  store i32 %op8413, ptr %slot1526, align 8
  %v8414 = load i32, ptr %slot1526, align 8
  %cv8415 = zext i32 %v8414 to i64
  %cond8416 = icmp ne i64 %cv8415, 0
  br i1 %cond8416, label %bb_rcslotrole2377, label %bb_rcslotowner2377
bb_rcslotrole2377:
  %v8417 = load i64, ptr %slot70, align 8
  store i64 %v8417, ptr %slot1527, align 8
  %v8418 = load i64, ptr %slot1524, align 8
  %p8419 = inttoptr i64 %v8418 to ptr
  %ld8420 = load i64, ptr %p8419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8420, ptr %slot1528, align 8
  %v8421 = load i64, ptr %slot1528, align 8
  %cmp8422 = icmp ne i64 %v8421, 0
  %cv8423 = zext i1 %cmp8422 to i32
  store i32 %cv8423, ptr %slot1529, align 8
  %v8424 = load i32, ptr %slot1529, align 8
  %cv8425 = zext i32 %v8424 to i64
  %cond8426 = icmp ne i64 %cv8425, 0
  br i1 %cond8426, label %bb_rcgnn2393, label %bb_rcgdone2393
bb_rcgnn2393:
  %v8427 = load i64, ptr %slot1528, align 8
  %op8428 = sub i64 %v8427, 16
  store i64 %op8428, ptr %slot1530, align 8
  %v8429 = load i64, ptr %slot1528, align 8
  %p8430 = inttoptr i64 %v8429 to ptr
  %rgep8431 = getelementptr i8, ptr %p8430, i64 -16
  %ld8432 = load i64, ptr %rgep8431, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8432, ptr %slot1531, align 8
  %v8433 = load i64, ptr %slot1531, align 8
  %op8434 = and i64 %v8433, 4611686018427387906
  store i64 %op8434, ptr %slot1532, align 8
  %v8435 = load i64, ptr %slot1532, align 8
  %cmp8436 = icmp ne i64 %v8435, 0
  %cv8437 = zext i1 %cmp8436 to i32
  store i32 %cv8437, ptr %slot1533, align 8
  %v8438 = load i32, ptr %slot1533, align 8
  %cv8439 = zext i32 %v8438 to i64
  %cond8440 = icmp ne i64 %cv8439, 0
  br i1 %cond8440, label %bb_rcgclear2393, label %bb_rcgcounted2393
bb_rcgcounted2393:
  %v8441 = load i64, ptr %slot1528, align 8
  %op8442 = sub i64 %v8441, 24
  store i64 %op8442, ptr %slot1534, align 8
  %v8443 = load i64, ptr %slot1528, align 8
  %p8444 = inttoptr i64 %v8443 to ptr
  %rgep8445 = getelementptr i8, ptr %p8444, i64 -24
  %ld8446 = load i64, ptr %rgep8445, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8446, ptr %slot1535, align 8
  %v8447 = load i64, ptr %slot1535, align 8
  %op8448 = sub i64 %v8447, 1
  store i64 %op8448, ptr %slot1536, align 8
  %v8449 = load i64, ptr %slot1536, align 8
  %cmp8450 = icmp eq i64 %v8449, 0
  %cv8451 = zext i1 %cmp8450 to i32
  store i32 %cv8451, ptr %slot1537, align 8
  %v8452 = load i32, ptr %slot1537, align 8
  %cv8453 = zext i32 %v8452 to i64
  %cond8454 = icmp ne i64 %cv8453, 0
  br i1 %cond8454, label %bb_rcglast2393, label %bb_rcgdec2393
bb_rcglast2393:
  %v8455 = load i64, ptr %slot1528, align 8
  %op8456 = sub i64 %v8455, 32
  store i64 %op8456, ptr %slot1538, align 8
  %v8457 = load i64, ptr %slot1528, align 8
  %p8458 = inttoptr i64 %v8457 to ptr
  %rgep8459 = getelementptr i8, ptr %p8458, i64 -32
  %ld8460 = load i64, ptr %rgep8459, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8460, ptr %slot1539, align 8
  %v8461 = load i64, ptr %slot1539, align 8
  %cmp8462 = icmp ne i64 %v8461, 0
  %cv8463 = zext i1 %cmp8462 to i32
  store i32 %cv8463, ptr %slot1540, align 8
  %v8464 = load i32, ptr %slot1540, align 8
  %cv8465 = zext i32 %v8464 to i64
  %cond8466 = icmp ne i64 %cv8465, 0
  br i1 %cond8466, label %bb_rcgdec2393, label %bb_rcgslow2393
bb_rcgslow2393:
  %v8467 = load i64, ptr %slot1527, align 8
  %v8468 = load i64, ptr %slot1524, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v8467, i64 %v8468) nomerge, !dbg !198
  br label %bb_rcgdone2393
bb_rcgdec2393:
  %v8469 = load i64, ptr %slot1536, align 8
  %v8470 = load i64, ptr %slot1528, align 8
  %p8471 = inttoptr i64 %v8470 to ptr
  %rgep8472 = getelementptr i8, ptr %p8471, i64 -24
  store i64 %v8469, ptr %rgep8472, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2393
bb_rcgclear2393:
  %v8473 = load i64, ptr %slot1524, align 8
  %p8474 = inttoptr i64 %v8473 to ptr
  store i64 0, ptr %p8474, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2393
bb_rcgdone2393:
  br label %bb_rcslotdone2377
bb_rcslotowner2377:
  %v8475 = load i64, ptr %slot70, align 8
  store i64 %v8475, ptr %slot1541, align 8
  %v8476 = load i64, ptr %slot1524, align 8
  %p8477 = inttoptr i64 %v8476 to ptr
  %ld8478 = load i64, ptr %p8477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8478, ptr %slot1542, align 8
  %v8479 = load i64, ptr %slot1542, align 8
  %cmp8480 = icmp ne i64 %v8479, 0
  %cv8481 = zext i1 %cmp8480 to i32
  store i32 %cv8481, ptr %slot1543, align 8
  %v8482 = load i32, ptr %slot1543, align 8
  %cv8483 = zext i32 %v8482 to i64
  %cond8484 = icmp ne i64 %cv8483, 0
  br i1 %cond8484, label %bb_rcgnn2408, label %bb_rcgdone2408
bb_rcgnn2408:
  %v8485 = load i64, ptr %slot1542, align 8
  %op8486 = sub i64 %v8485, 16
  store i64 %op8486, ptr %slot1544, align 8
  %v8487 = load i64, ptr %slot1542, align 8
  %p8488 = inttoptr i64 %v8487 to ptr
  %rgep8489 = getelementptr i8, ptr %p8488, i64 -16
  %ld8490 = load i64, ptr %rgep8489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8490, ptr %slot1545, align 8
  %v8491 = load i64, ptr %slot1545, align 8
  %op8492 = and i64 %v8491, 4611686018427387906
  store i64 %op8492, ptr %slot1546, align 8
  %v8493 = load i64, ptr %slot1546, align 8
  %cmp8494 = icmp ne i64 %v8493, 0
  %cv8495 = zext i1 %cmp8494 to i32
  store i32 %cv8495, ptr %slot1547, align 8
  %v8496 = load i32, ptr %slot1547, align 8
  %cv8497 = zext i32 %v8496 to i64
  %cond8498 = icmp ne i64 %cv8497, 0
  br i1 %cond8498, label %bb_rcgclear2408, label %bb_rcgcounted2408
bb_rcgcounted2408:
  %v8499 = load i64, ptr %slot1542, align 8
  %op8500 = sub i64 %v8499, 32
  store i64 %op8500, ptr %slot1548, align 8
  %v8501 = load i64, ptr %slot1542, align 8
  %p8502 = inttoptr i64 %v8501 to ptr
  %rgep8503 = getelementptr i8, ptr %p8502, i64 -32
  %ld8504 = load i64, ptr %rgep8503, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8504, ptr %slot1549, align 8
  %v8505 = load i64, ptr %slot1549, align 8
  %op8506 = sub i64 %v8505, 1
  store i64 %op8506, ptr %slot1550, align 8
  %v8507 = load i64, ptr %slot1550, align 8
  %cmp8508 = icmp eq i64 %v8507, 0
  %cv8509 = zext i1 %cmp8508 to i32
  store i32 %cv8509, ptr %slot1551, align 8
  %v8510 = load i32, ptr %slot1551, align 8
  %cv8511 = zext i32 %v8510 to i64
  %cond8512 = icmp ne i64 %cv8511, 0
  br i1 %cond8512, label %bb_rcglast2408, label %bb_rcgdec2408
bb_rcglast2408:
  %v8513 = load i64, ptr %slot1542, align 8
  %op8514 = sub i64 %v8513, 24
  store i64 %op8514, ptr %slot1552, align 8
  %v8515 = load i64, ptr %slot1542, align 8
  %p8516 = inttoptr i64 %v8515 to ptr
  %rgep8517 = getelementptr i8, ptr %p8516, i64 -24
  %ld8518 = load i64, ptr %rgep8517, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8518, ptr %slot1553, align 8
  %v8519 = load i64, ptr %slot1553, align 8
  %cmp8520 = icmp ne i64 %v8519, 0
  %cv8521 = zext i1 %cmp8520 to i32
  store i32 %cv8521, ptr %slot1554, align 8
  %v8522 = load i32, ptr %slot1554, align 8
  %cv8523 = zext i32 %v8522 to i64
  %cond8524 = icmp ne i64 %cv8523, 0
  br i1 %cond8524, label %bb_rcgdec2408, label %bb_rcgslow2408
bb_rcgslow2408:
  %v8525 = load i64, ptr %slot1541, align 8
  %v8526 = load i64, ptr %slot1524, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v8525, i64 %v8526) nomerge, !dbg !198
  br label %bb_rcgdone2408
bb_rcgdec2408:
  %v8527 = load i64, ptr %slot1550, align 8
  %v8528 = load i64, ptr %slot1542, align 8
  %p8529 = inttoptr i64 %v8528 to ptr
  %rgep8530 = getelementptr i8, ptr %p8529, i64 -32
  store i64 %v8527, ptr %rgep8530, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2408
bb_rcgclear2408:
  %v8531 = load i64, ptr %slot1524, align 8
  %p8532 = inttoptr i64 %v8531 to ptr
  store i64 0, ptr %p8532, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2408
bb_rcgdone2408:
  br label %bb_rcslotdone2377
bb_rcslotdone2377:
  %v8533 = load i64, ptr %slot33, align 8
  store i64 %v8533, ptr %slot1555, align 8
  %v8534 = load i64, ptr %slot70, align 8
  %v8535 = load i64, ptr %slot1555, align 8
  %p8536 = inttoptr i64 %v8535 to ptr
  store i64 %v8534, ptr %p8536, align 8, !alias.scope !3, !noalias !4
  %v8537 = load i64, ptr %slot70, align 8
  %p8539 = inttoptr i64 %v8537 to ptr
  %gep8540 = getelementptr i8, ptr %p8539, i64 5640
  %op8538 = ptrtoint ptr %gep8540 to i64
  store i64 %op8538, ptr %slot1556, align 8
  %v8541 = load i64, ptr %slot1556, align 8
  %p8542 = inttoptr i64 %v8541 to ptr
  %ld8543 = load i64, ptr %p8542, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8543, ptr %slot1557, align 8
  %v8544 = load i64, ptr %slot1557, align 8
  %op8545 = add i64 %v8544, 248
  store i64 %op8545, ptr %slot1558, align 8
  %v8546 = load i64, ptr %slot1558, align 8
  %p8547 = inttoptr i64 %v8546 to ptr
  %ld8548 = load i64, ptr %p8547, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8548, ptr %slot1559, align 8
  %v8549 = load i64, ptr %slot1555, align 8
  %p8551 = inttoptr i64 %v8549 to ptr
  %gep8552 = getelementptr i8, ptr %p8551, i64 8
  %op8550 = ptrtoint ptr %gep8552 to i64
  store i64 %op8550, ptr %slot1560, align 8
  %v8553 = load i64, ptr %slot1559, align 8
  %v8554 = load i64, ptr %slot1560, align 8
  %p8555 = inttoptr i64 %v8554 to ptr
  store i64 %v8553, ptr %p8555, align 8, !alias.scope !3, !noalias !4
  %v8556 = load i64, ptr %slot1555, align 8
  %p8558 = inttoptr i64 %v8556 to ptr
  %gep8559 = getelementptr i8, ptr %p8558, i64 16
  %op8557 = ptrtoint ptr %gep8559 to i64
  store i64 %op8557, ptr %slot1561, align 8
  %v8560 = load i64, ptr %slot1561, align 8
  %p8561 = inttoptr i64 %v8560 to ptr
  store i64 0, ptr %p8561, align 8, !alias.scope !3, !noalias !4
  %v8562 = load i64, ptr %slot70, align 8
  %p8564 = inttoptr i64 %v8562 to ptr
  %gep8565 = getelementptr i8, ptr %p8564, i64 112
  %op8563 = ptrtoint ptr %gep8565 to i64
  store i64 %op8563, ptr %slot1562, align 8
  %v8566 = load i64, ptr %slot1555, align 8
  %p8568 = inttoptr i64 %v8566 to ptr
  %gep8569 = getelementptr i8, ptr %p8568, i64 24
  %op8567 = ptrtoint ptr %gep8569 to i64
  store i64 %op8567, ptr %slot1563, align 8
  %v8570 = load i64, ptr %slot1555, align 8
  %p8572 = inttoptr i64 %v8570 to ptr
  %gep8573 = getelementptr i8, ptr %p8572, i64 28
  %op8571 = ptrtoint ptr %gep8573 to i64
  store i64 %op8571, ptr %slot1564, align 8
  %v8574 = load i64, ptr %slot1562, align 8
  %p8575 = inttoptr i64 %v8574 to ptr
  %ld8576 = load i32, ptr %p8575, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld8576, ptr %slot1565, align 8
  %v8577 = load i64, ptr %slot1563, align 8
  %p8578 = inttoptr i64 %v8577 to ptr
  store i32 1, ptr %p8578, align 4, !alias.scope !3, !noalias !4
  %v8579 = load i32, ptr %slot1565, align 8
  %v8580 = load i64, ptr %slot1564, align 8
  %p8581 = inttoptr i64 %v8580 to ptr
  store i32 %v8579, ptr %p8581, align 4, !alias.scope !3, !noalias !4
  %v8582 = load i64, ptr %slot1555, align 8
  %v8583 = load i64, ptr %slot1558, align 8
  %p8584 = inttoptr i64 %v8583 to ptr
  store i64 %v8582, ptr %p8584, align 8, !alias.scope !9999998, !noalias !9999999
  %v8585 = load i64, ptr %slot1522, align 8
  %cmp8586 = icmp ne i64 %v8585, 0
  %cv8587 = zext i1 %cmp8586 to i32
  store i32 %cv8587, ptr %slot1566, align 8
  %v8588 = load i32, ptr %slot1566, align 8
  %cv8589 = zext i32 %v8588 to i64
  %cond8590 = icmp ne i64 %cv8589, 0
  br i1 %cond8590, label %bb_rcspinmark2460, label %bb_rcspindone2460
bb_rcspinmark2460:
  %v8591 = load i64, ptr %slot1522, align 8
  %op8592 = sub i64 %v8591, 16
  store i64 %op8592, ptr %slot1567, align 8
  %v8593 = load i64, ptr %slot1522, align 8
  %p8594 = inttoptr i64 %v8593 to ptr
  %rgep8595 = getelementptr i8, ptr %p8594, i64 -16
  %ld8596 = load i64, ptr %rgep8595, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8596, ptr %slot1568, align 8
  %v8597 = load i64, ptr %slot1568, align 8
  %op8598 = and i64 %v8597, 2
  store i64 %op8598, ptr %slot1569, align 8
  %v8599 = load i64, ptr %slot1569, align 8
  %cmp8600 = icmp ne i64 %v8599, 0
  %cv8601 = zext i1 %cmp8600 to i32
  store i32 %cv8601, ptr %slot1570, align 8
  %v8602 = load i32, ptr %slot1570, align 8
  %cv8603 = zext i32 %v8602 to i64
  %cond8604 = icmp ne i64 %cv8603, 0
  br i1 %cond8604, label %bb_rcspindone2460, label %bb_rcspintype2460
bb_rcspintype2460:
  %v8605 = load i64, ptr %slot1568, align 8
  %op8606 = and i64 %v8605, 4611686018427387907
  store i64 %op8606, ptr %slot1571, align 8
  %v8607 = load i64, ptr %slot1571, align 8
  %cmp8608 = icmp eq i64 %v8607, 0
  %cv8609 = zext i1 %cmp8608 to i32
  store i32 %cv8609, ptr %slot1572, align 8
  %v8610 = load i32, ptr %slot1572, align 8
  %cv8611 = zext i32 %v8610 to i64
  %cond8612 = icmp ne i64 %cv8611, 0
  br i1 %cond8612, label %bb_rcs2468, label %bb_rcspinslow2460
bb_rcs2468:
  %v8613 = load i64, ptr %slot1522, align 8
  %op8614 = sub i64 %v8613, 8
  store i64 %op8614, ptr %slot1573, align 8
  %v8615 = load i64, ptr %slot1522, align 8
  %p8616 = inttoptr i64 %v8615 to ptr
  %rgep8617 = getelementptr i8, ptr %p8616, i64 -8
  %ld8618 = load i64, ptr %rgep8617, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8618, ptr %slot1574, align 8
  %p8619 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld8620 = load i64, ptr %p8619, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8620, ptr %slot1575, align 8
  %v8621 = load i64, ptr %slot1574, align 8
  %v8622 = load i64, ptr %slot1575, align 8
  %cmp8623 = icmp eq i64 %v8621, %v8622
  %cv8624 = zext i1 %cmp8623 to i32
  store i32 %cv8624, ptr %slot1576, align 8
  %v8625 = load i32, ptr %slot1576, align 8
  %cv8626 = zext i32 %v8625 to i64
  %cond8627 = icmp ne i64 %cv8626, 0
  br i1 %cond8627, label %bb_rcs2473, label %bb_rcspinslow2460
bb_rcs2473:
  %v8628 = load i64, ptr %slot70, align 8
  %p8630 = inttoptr i64 %v8628 to ptr
  %gep8631 = getelementptr i8, ptr %p8630, i64 5640
  %op8629 = ptrtoint ptr %gep8631 to i64
  store i64 %op8629, ptr %slot1577, align 8
  %v8632 = load i64, ptr %slot1577, align 8
  %p8633 = inttoptr i64 %v8632 to ptr
  %ld8634 = load i64, ptr %p8633, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8634, ptr %slot1578, align 8
  %v8635 = load i64, ptr %slot1578, align 8
  %op8636 = add i64 %v8635, 256
  store i64 %op8636, ptr %slot1579, align 8
  %v8637 = load i64, ptr %slot1579, align 8
  %p8638 = inttoptr i64 %v8637 to ptr
  %ld8639 = load i64, ptr %p8638, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8639, ptr %slot1580, align 8
  %v8640 = load i64, ptr %slot1580, align 8
  %cmp8641 = icmp ne i64 %v8640, 0
  %cv8642 = zext i1 %cmp8641 to i32
  store i32 %cv8642, ptr %slot1581, align 8
  %v8643 = load i32, ptr %slot1581, align 8
  %cv8644 = zext i32 %v8643 to i64
  %cond8645 = icmp ne i64 %cv8644, 0
  br i1 %cond8645, label %bb_rcs2479, label %bb_rcspinslow2460
bb_rcs2479:
  %v8646 = load i64, ptr %slot70, align 8
  %p8648 = inttoptr i64 %v8646 to ptr
  %gep8649 = getelementptr i8, ptr %p8648, i64 24
  %op8647 = ptrtoint ptr %gep8649 to i64
  store i64 %op8647, ptr %slot1582, align 8
  %v8650 = load i64, ptr %slot1582, align 8
  %p8651 = inttoptr i64 %v8650 to ptr
  %ld8652 = load i64, ptr %p8651, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8652, ptr %slot1583, align 8
  %v8653 = load i64, ptr %slot1583, align 8
  %op8654 = add i64 %v8653, 40
  store i64 %op8654, ptr %slot1584, align 8
  %v8655 = load i64, ptr %slot1584, align 8
  %v8656 = load i64, ptr %slot1583, align 8
  %cmp8657 = icmp uge i64 %v8655, %v8656
  %cv8658 = zext i1 %cmp8657 to i32
  store i32 %cv8658, ptr %slot1585, align 8
  %v8659 = load i32, ptr %slot1585, align 8
  %cv8660 = zext i32 %v8659 to i64
  %cond8661 = icmp ne i64 %cv8660, 0
  br i1 %cond8661, label %bb_rcs2484, label %bb_rcspinslow2460
bb_rcs2484:
  %v8662 = load i64, ptr %slot70, align 8
  %p8664 = inttoptr i64 %v8662 to ptr
  %gep8665 = getelementptr i8, ptr %p8664, i64 88
  %op8663 = ptrtoint ptr %gep8665 to i64
  store i64 %op8663, ptr %slot1586, align 8
  %v8666 = load i64, ptr %slot1586, align 8
  %p8667 = inttoptr i64 %v8666 to ptr
  %ld8668 = load i64, ptr %p8667, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8668, ptr %slot1587, align 8
  %v8669 = load i64, ptr %slot1587, align 8
  %cmp8670 = icmp eq i64 %v8669, 0
  %cv8671 = zext i1 %cmp8670 to i32
  store i32 %cv8671, ptr %slot1588, align 8
  %v8672 = load i64, ptr %slot1584, align 8
  %v8673 = load i64, ptr %slot1587, align 8
  %cmp8674 = icmp ule i64 %v8672, %v8673
  %cv8675 = zext i1 %cmp8674 to i32
  store i32 %cv8675, ptr %slot1589, align 8
  %v8676 = load i32, ptr %slot1588, align 8
  %v8677 = load i32, ptr %slot1589, align 8
  %op8678 = or i32 %v8676, %v8677
  store i32 %op8678, ptr %slot1590, align 8
  %v8679 = load i32, ptr %slot1590, align 8
  %cv8680 = zext i32 %v8679 to i64
  %cond8681 = icmp ne i64 %cv8680, 0
  br i1 %cond8681, label %bb_rcs2490, label %bb_rcspinslow2460
bb_rcs2490:
  %v8682 = load i64, ptr %slot1522, align 8
  %op8683 = sub i64 %v8682, 24
  store i64 %op8683, ptr %slot1591, align 8
  %v8684 = load i64, ptr %slot1522, align 8
  %p8685 = inttoptr i64 %v8684 to ptr
  %rgep8686 = getelementptr i8, ptr %p8685, i64 -24
  %ld8687 = load i64, ptr %rgep8686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8687, ptr %slot1592, align 8
  %v8688 = load i64, ptr %slot1592, align 8
  %cmp8689 = icmp ne i64 %v8688, 18446744073709551615
  %cv8690 = zext i1 %cmp8689 to i32
  store i32 %cv8690, ptr %slot1593, align 8
  %v8691 = load i32, ptr %slot1593, align 8
  %cv8692 = zext i32 %v8691 to i64
  %cond8693 = icmp ne i64 %cv8692, 0
  br i1 %cond8693, label %bb_rcs2494, label %bb_rcspinslow2460
bb_rcs2494:
  %v8694 = load i64, ptr %slot1522, align 8
  %op8695 = add i64 %v8694, 32
  store i64 %op8695, ptr %slot1594, align 8
  %v8696 = load i64, ptr %slot1594, align 8
  %p8697 = inttoptr i64 %v8696 to ptr
  %ld8698 = load i64, ptr %p8697, align 8
  store i64 %ld8698, ptr %slot1595, align 8
  %v8699 = load i64, ptr %slot1595, align 8
  %cmp8700 = icmp ne i64 %v8699, 0
  %cv8701 = zext i1 %cmp8700 to i32
  store i32 %cv8701, ptr %slot1596, align 8
  %v8702 = load i32, ptr %slot1596, align 8
  %cv8703 = zext i32 %v8702 to i64
  %cond8704 = icmp ne i64 %cv8703, 0
  br i1 %cond8704, label %bb_rcspinbacking2460, label %bb_rcspincommit2460
bb_rcspinbacking2460:
  %v8705 = load i64, ptr %slot1595, align 8
  %op8706 = sub i64 %v8705, 16
  store i64 %op8706, ptr %slot1597, align 8
  %v8707 = load i64, ptr %slot1595, align 8
  %p8708 = inttoptr i64 %v8707 to ptr
  %rgep8709 = getelementptr i8, ptr %p8708, i64 -16
  %ld8710 = load i64, ptr %rgep8709, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8710, ptr %slot1598, align 8
  %v8711 = load i64, ptr %slot1598, align 8
  %op8712 = and i64 %v8711, 4611686018427387907
  store i64 %op8712, ptr %slot1599, align 8
  %v8713 = load i64, ptr %slot1599, align 8
  %cmp8714 = icmp eq i64 %v8713, 0
  %cv8715 = zext i1 %cmp8714 to i32
  store i32 %cv8715, ptr %slot1600, align 8
  %v8716 = load i32, ptr %slot1600, align 8
  %cv8717 = zext i32 %v8716 to i64
  %cond8718 = icmp ne i64 %cv8717, 0
  br i1 %cond8718, label %bb_rcs2502, label %bb_rcspinslow2460
bb_rcs2502:
  %v8719 = load i64, ptr %slot1595, align 8
  %op8720 = sub i64 %v8719, 24
  store i64 %op8720, ptr %slot1601, align 8
  %v8721 = load i64, ptr %slot1595, align 8
  %p8722 = inttoptr i64 %v8721 to ptr
  %rgep8723 = getelementptr i8, ptr %p8722, i64 -24
  %ld8724 = load i64, ptr %rgep8723, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8724, ptr %slot1602, align 8
  %v8725 = load i64, ptr %slot1602, align 8
  %cmp8726 = icmp ne i64 %v8725, 18446744073709551615
  %cv8727 = zext i1 %cmp8726 to i32
  store i32 %cv8727, ptr %slot1603, align 8
  %v8728 = load i32, ptr %slot1603, align 8
  %cv8729 = zext i32 %v8728 to i64
  %cond8730 = icmp ne i64 %cv8729, 0
  br i1 %cond8730, label %bb_rcs2506, label %bb_rcspinslow2460
bb_rcs2506:
  br label %bb_rcspincommit2460
bb_rcspincommit2460:
  %v8731 = load i64, ptr %slot1580, align 8
  %p8732 = inttoptr i64 %v8731 to ptr
  %ld8733 = load i64, ptr %p8732, align 8
  store i64 %ld8733, ptr %slot1604, align 8
  %v8734 = load i64, ptr %slot1578, align 8
  %op8735 = add i64 %v8734, 256
  store i64 %op8735, ptr %slot1605, align 8
  %v8736 = load i64, ptr %slot1604, align 8
  %v8737 = load i64, ptr %slot1605, align 8
  %p8738 = inttoptr i64 %v8737 to ptr
  store i64 %v8736, ptr %p8738, align 8, !alias.scope !9999998, !noalias !9999999
  %v8739 = load i64, ptr %slot1578, align 8
  %op8740 = add i64 %v8739, 264
  store i64 %op8740, ptr %slot1606, align 8
  %v8741 = load i64, ptr %slot1606, align 8
  %p8742 = inttoptr i64 %v8741 to ptr
  %ld8743 = load i64, ptr %p8742, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8743, ptr %slot1607, align 8
  %v8744 = load i64, ptr %slot1607, align 8
  %op8745 = add i64 %v8744, 18446744073709551615
  store i64 %op8745, ptr %slot1608, align 8
  %v8746 = load i64, ptr %slot1608, align 8
  %v8747 = load i64, ptr %slot1606, align 8
  %p8748 = inttoptr i64 %v8747 to ptr
  store i64 %v8746, ptr %p8748, align 8, !alias.scope !9999998, !noalias !9999999
  %v8749 = load i64, ptr %slot70, align 8
  %p8751 = inttoptr i64 %v8749 to ptr
  %gep8752 = getelementptr i8, ptr %p8751, i64 24
  %op8750 = ptrtoint ptr %gep8752 to i64
  store i64 %op8750, ptr %slot1609, align 8
  %v8753 = load i64, ptr %slot1609, align 8
  %p8754 = inttoptr i64 %v8753 to ptr
  %ld8755 = load i64, ptr %p8754, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8755, ptr %slot1610, align 8
  %v8756 = load i64, ptr %slot1610, align 8
  %op8757 = add i64 %v8756, 40
  store i64 %op8757, ptr %slot1611, align 8
  %v8758 = load i64, ptr %slot1611, align 8
  %v8759 = load i64, ptr %slot1609, align 8
  %p8760 = inttoptr i64 %v8759 to ptr
  store i64 %v8758, ptr %p8760, align 8, !alias.scope !9999998, !noalias !9999999
  %v8761 = load i64, ptr %slot1578, align 8
  %op8762 = add i64 %v8761, 48
  store i64 %op8762, ptr %slot1612, align 8
  %v8763 = load i64, ptr %slot1612, align 8
  %p8764 = inttoptr i64 %v8763 to ptr
  %ld8765 = load i64, ptr %p8764, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8765, ptr %slot1613, align 8
  %v8766 = load i64, ptr %slot1613, align 8
  %op8767 = add i64 %v8766, 40
  store i64 %op8767, ptr %slot1614, align 8
  %v8768 = load i64, ptr %slot1614, align 8
  %v8769 = load i64, ptr %slot1612, align 8
  %p8770 = inttoptr i64 %v8769 to ptr
  store i64 %v8768, ptr %p8770, align 8, !alias.scope !9999998, !noalias !9999999
  %v8771 = load i64, ptr %slot1522, align 8
  %op8772 = sub i64 %v8771, 24
  store i64 %op8772, ptr %slot1615, align 8
  %v8773 = load i64, ptr %slot1522, align 8
  %p8774 = inttoptr i64 %v8773 to ptr
  %rgep8775 = getelementptr i8, ptr %p8774, i64 -24
  %ld8776 = load i64, ptr %rgep8775, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8776, ptr %slot1616, align 8
  %v8777 = load i64, ptr %slot1616, align 8
  %op8778 = add i64 %v8777, 1
  store i64 %op8778, ptr %slot1617, align 8
  %v8779 = load i64, ptr %slot1617, align 8
  %v8780 = load i64, ptr %slot1522, align 8
  %p8781 = inttoptr i64 %v8780 to ptr
  %rgep8782 = getelementptr i8, ptr %p8781, i64 -24
  store i64 %v8779, ptr %rgep8782, align 8, !alias.scope !9, !noalias !10
  %v8783 = load i64, ptr %slot1595, align 8
  %cmp8784 = icmp ne i64 %v8783, 0
  %cv8785 = zext i1 %cmp8784 to i32
  store i32 %cv8785, ptr %slot1618, align 8
  %v8786 = load i32, ptr %slot1618, align 8
  %cv8787 = zext i32 %v8786 to i64
  %cond8788 = icmp ne i64 %cv8787, 0
  br i1 %cond8788, label %bb_rcspinhold2460, label %bb_rcspinjournal2460
bb_rcspinhold2460:
  %v8789 = load i64, ptr %slot1595, align 8
  %op8790 = sub i64 %v8789, 24
  store i64 %op8790, ptr %slot1619, align 8
  %v8791 = load i64, ptr %slot1595, align 8
  %p8792 = inttoptr i64 %v8791 to ptr
  %rgep8793 = getelementptr i8, ptr %p8792, i64 -24
  %ld8794 = load i64, ptr %rgep8793, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8794, ptr %slot1620, align 8
  %v8795 = load i64, ptr %slot1620, align 8
  %op8796 = add i64 %v8795, 1
  store i64 %op8796, ptr %slot1621, align 8
  %v8797 = load i64, ptr %slot1621, align 8
  %v8798 = load i64, ptr %slot1595, align 8
  %p8799 = inttoptr i64 %v8798 to ptr
  %rgep8800 = getelementptr i8, ptr %p8799, i64 -24
  store i64 %v8797, ptr %rgep8800, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal2460
bb_rcspinjournal2460:
  %v8801 = load i64, ptr %slot1568, align 8
  %op8802 = and i64 %v8801, 1152921504606846976
  store i64 %op8802, ptr %slot1622, align 8
  %v8803 = load i64, ptr %slot1568, align 8
  %op8804 = or i64 %v8803, 1152921504606846976
  store i64 %op8804, ptr %slot1623, align 8
  %v8805 = load i64, ptr %slot1522, align 8
  %op8806 = sub i64 %v8805, 16
  store i64 %op8806, ptr %slot1624, align 8
  %v8807 = load i64, ptr %slot1623, align 8
  %v8808 = load i64, ptr %slot1522, align 8
  %p8809 = inttoptr i64 %v8808 to ptr
  %rgep8810 = getelementptr i8, ptr %p8809, i64 -16
  store i64 %v8807, ptr %rgep8810, align 8, !alias.scope !9, !noalias !10
  %v8811 = load i64, ptr %slot1555, align 8
  %p8813 = inttoptr i64 %v8811 to ptr
  %gep8814 = getelementptr i8, ptr %p8813, i64 16
  %op8812 = ptrtoint ptr %gep8814 to i64
  store i64 %op8812, ptr %slot1625, align 8
  %v8815 = load i64, ptr %slot1625, align 8
  %p8816 = inttoptr i64 %v8815 to ptr
  %ld8817 = load i64, ptr %p8816, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8817, ptr %slot1626, align 8
  %v8818 = load i64, ptr %slot1580, align 8
  %op8819 = add i64 %v8818, 0
  store i64 %op8819, ptr %slot1627, align 8
  %v8820 = load i64, ptr %slot1626, align 8
  %v8821 = load i64, ptr %slot1627, align 8
  %p8822 = inttoptr i64 %v8821 to ptr
  store i64 %v8820, ptr %p8822, align 8, !alias.scope !9999998, !noalias !9999999
  %v8823 = load i64, ptr %slot1580, align 8
  %op8824 = add i64 %v8823, 8
  store i64 %op8824, ptr %slot1628, align 8
  %v8825 = load i64, ptr %slot1522, align 8
  %v8826 = load i64, ptr %slot1628, align 8
  %p8827 = inttoptr i64 %v8826 to ptr
  store i64 %v8825, ptr %p8827, align 8, !alias.scope !9999998, !noalias !9999999
  %v8828 = load i64, ptr %slot1580, align 8
  %op8829 = add i64 %v8828, 16
  store i64 %op8829, ptr %slot1629, align 8
  %v8830 = load i64, ptr %slot1622, align 8
  %v8831 = load i64, ptr %slot1629, align 8
  %p8832 = inttoptr i64 %v8831 to ptr
  store i64 %v8830, ptr %p8832, align 8, !alias.scope !9999998, !noalias !9999999
  %v8833 = load i64, ptr %slot1580, align 8
  %op8834 = add i64 %v8833, 24
  store i64 %op8834, ptr %slot1630, align 8
  %v8835 = load i64, ptr %slot1630, align 8
  %p8836 = inttoptr i64 %v8835 to ptr
  store i32 1, ptr %p8836, align 4, !alias.scope !9999998, !noalias !9999999
  %v8837 = load i64, ptr %slot1580, align 8
  %op8838 = add i64 %v8837, 32
  store i64 %op8838, ptr %slot1631, align 8
  %v8839 = load i64, ptr %slot1595, align 8
  %v8840 = load i64, ptr %slot1631, align 8
  %p8841 = inttoptr i64 %v8840 to ptr
  store i64 %v8839, ptr %p8841, align 8, !alias.scope !9999998, !noalias !9999999
  %v8842 = load i64, ptr %slot1555, align 8
  %p8844 = inttoptr i64 %v8842 to ptr
  %gep8845 = getelementptr i8, ptr %p8844, i64 16
  %op8843 = ptrtoint ptr %gep8845 to i64
  store i64 %op8843, ptr %slot1632, align 8
  %v8846 = load i64, ptr %slot1580, align 8
  %v8847 = load i64, ptr %slot1632, align 8
  %p8848 = inttoptr i64 %v8847 to ptr
  store i64 %v8846, ptr %p8848, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone2460
bb_rcspinslow2460:
  %v8849 = load i64, ptr %slot1, align 8
  %p8850 = inttoptr i64 %v8849 to ptr
  %v8851 = load i64, ptr %slot1555, align 8
  %p8852 = inttoptr i64 %v8851 to ptr
  %v8853 = load i64, ptr %slot1522, align 8
  %p8854 = inttoptr i64 %v8853 to ptr
  %call8855 = call i32 @myl_qbe_rc_scope_pin(ptr %p8850, ptr %p8852, ptr %p8854) nomerge, !dbg !198
  store i32 %call8855, ptr %slot1633, align 8
  %v8856 = load i32, ptr %slot1633, align 8
  %cv8857 = zext i32 %v8856 to i64
  %cond8858 = icmp ne i64 %cv8857, 0
  br i1 %cond8858, label %bb_rcunique2537, label %bb_failure
bb_rcunique2537:
  br label %bb_rcspindone2460
bb_rcspindone2460:
  %v8859 = load i64, ptr %slot1522, align 8
  %v8860 = load i64, ptr %slot54, align 8
  %p8861 = inttoptr i64 %v8860 to ptr
  store i64 %v8859, ptr %p8861, align 8, !alias.scope !3, !noalias !4
  %v8862 = load i64, ptr %slot42, align 8
  %v8863 = load i64, ptr %slot57, align 8
  %p8864 = inttoptr i64 %v8863 to ptr
  store i64 %v8862, ptr %p8864, align 8, !alias.scope !3, !noalias !4
  %v8865 = load i64, ptr %slot57, align 8
  %p8866 = inttoptr i64 %v8865 to ptr
  %ld8867 = load i64, ptr %p8866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8867, ptr %slot1634, align 8
  %v8868 = load i64, ptr %slot1634, align 8
  %op8869 = add i64 %v8868, 48
  store i64 %op8869, ptr %slot1635, align 8
  %v8870 = load i64, ptr %slot1635, align 8
  %p8871 = inttoptr i64 %v8870 to ptr
  %ld8872 = load i64, ptr %p8871, align 8
  store i64 %ld8872, ptr %slot1636, align 8
  %v8873 = load i64, ptr %slot1636, align 8
  %v8874 = load i64, ptr %slot57, align 8
  %p8875 = inttoptr i64 %v8874 to ptr
  store i64 %v8873, ptr %p8875, align 8, !alias.scope !3, !noalias !4
  %v8876 = load i64, ptr %slot17, align 8
  %p8877 = inttoptr i64 %v8876 to ptr
  %ld8878 = load i32, ptr %p8877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8878, ptr %slot1637, align 8
  %v8879 = load i32, ptr %slot1637, align 8
  %cv8880 = zext i32 %v8879 to i64
  %cond8881 = icmp ne i64 %cv8880, 0
  br i1 %cond8881, label %bb_rcslotdrop2543, label %bb_rcslotdone2543
bb_rcslotdrop2543:
  %v8882 = load i64, ptr %slot17, align 8
  %p8883 = inttoptr i64 %v8882 to ptr
  store i32 0, ptr %p8883, align 4, !alias.scope !3, !noalias !4
  %v8884 = load i64, ptr %slot24, align 8
  store i64 %v8884, ptr %slot1638, align 8
  %v8885 = load i64, ptr %slot18, align 8
  %p8886 = inttoptr i64 %v8885 to ptr
  %ld8887 = load i32, ptr %p8886, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8887, ptr %slot1639, align 8
  %v8888 = load i32, ptr %slot1639, align 8
  %op8889 = and i32 %v8888, 28
  store i32 %op8889, ptr %slot1640, align 8
  %v8890 = load i32, ptr %slot1640, align 8
  %cv8891 = zext i32 %v8890 to i64
  %cond8892 = icmp ne i64 %cv8891, 0
  br i1 %cond8892, label %bb_rcslotrole2543, label %bb_rcslotowner2543
bb_rcslotrole2543:
  %v8893 = load i64, ptr %slot70, align 8
  store i64 %v8893, ptr %slot1641, align 8
  %v8894 = load i64, ptr %slot1641, align 8
  %v8895 = load i64, ptr %slot1638, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v8894, i64 %v8895) nomerge, !dbg !200
  br label %bb_rcslotdone2543
bb_rcslotowner2543:
  %v8896 = load i64, ptr %slot70, align 8
  store i64 %v8896, ptr %slot1642, align 8
  %v8897 = load i64, ptr %slot1642, align 8
  %v8898 = load i64, ptr %slot1638, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v8897, i64 %v8898) nomerge, !dbg !200
  br label %bb_rcslotdone2543
bb_rcslotdone2543:
  %v8899 = load i64, ptr %slot57, align 8
  %p8900 = inttoptr i64 %v8899 to ptr
  %ld8901 = load i64, ptr %p8900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8901, ptr %slot1643, align 8
  %v8902 = load i64, ptr %slot1643, align 8
  %v8903 = load i64, ptr %slot56, align 8
  %p8904 = inttoptr i64 %v8903 to ptr
  store i64 %v8902, ptr %p8904, align 8, !alias.scope !3, !noalias !4
  %v8905 = load i64, ptr %slot56, align 8
  %p8906 = inttoptr i64 %v8905 to ptr
  %ld8907 = load i64, ptr %p8906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8907, ptr %slot1644, align 8
  %v8908 = load i64, ptr %slot1644, align 8
  %v8909 = load i64, ptr %slot57, align 8
  %p8910 = inttoptr i64 %v8909 to ptr
  store i64 %v8908, ptr %p8910, align 8, !alias.scope !3, !noalias !4
  %v8911 = load i64, ptr %slot58, align 8
  %p8912 = inttoptr i64 %v8911 to ptr
  store i64 0, ptr %p8912, align 8, !alias.scope !3, !noalias !4
  %v8913 = load i64, ptr %slot58, align 8
  %p8914 = inttoptr i64 %v8913 to ptr
  %ld8915 = load i64, ptr %p8914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8915, ptr %slot1645, align 8
  %v8916 = load i64, ptr %slot57, align 8
  %p8917 = inttoptr i64 %v8916 to ptr
  %ld8918 = load i64, ptr %p8917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8918, ptr %slot1646, align 8
  %v8919 = load i64, ptr %slot1646, align 8
  %v8920 = load i64, ptr %slot1645, align 8
  %cmp8921 = icmp slt i64 %v8919, %v8920
  %cv8922 = zext i1 %cmp8921 to i64
  store i64 %cv8922, ptr %slot1647, align 8
  %v8923 = load i64, ptr %slot1647, align 8
  %v8924 = load i64, ptr %slot57, align 8
  %p8925 = inttoptr i64 %v8924 to ptr
  store i64 %v8923, ptr %p8925, align 8, !alias.scope !3, !noalias !4
  %v8926 = load i64, ptr %slot57, align 8
  %p8927 = inttoptr i64 %v8926 to ptr
  %ld8928 = load i64, ptr %p8927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8928, ptr %slot1648, align 8
  %v8929 = load i64, ptr %slot1648, align 8
  %cond8930 = icmp ne i64 %v8929, 0
  br i1 %cond8930, label %bb_next2556, label %bb_i142
bb_next2556:
  %v8931 = load i64, ptr %slot54, align 8
  %p8932 = inttoptr i64 %v8931 to ptr
  %ld8933 = load i64, ptr %p8932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8933, ptr %slot1649, align 8
  %v8934 = load i64, ptr %slot1649, align 8
  %op8935 = add i64 %v8934, 0
  store i64 %op8935, ptr %slot1650, align 8
  %v8936 = load i64, ptr %slot1650, align 8
  %p8937 = inttoptr i64 %v8936 to ptr
  %ld8938 = load i64, ptr %p8937, align 8, !alias.scope !6, !noalias !7
  store i64 %ld8938, ptr %slot1651, align 8
  %v8939 = load i64, ptr %slot1651, align 8
  %v8940 = load i64, ptr %slot57, align 8
  %p8941 = inttoptr i64 %v8940 to ptr
  store i64 %v8939, ptr %p8941, align 8, !alias.scope !3, !noalias !4
  %v8942 = load i64, ptr %slot57, align 8
  %p8943 = inttoptr i64 %v8942 to ptr
  %ld8944 = load i64, ptr %p8943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8944, ptr %slot1652, align 8
  %v8945 = load i64, ptr %slot1652, align 8
  %cmp8946 = icmp ugt i64 %v8945, 9223372036854775807
  %cv8947 = zext i1 %cmp8946 to i64
  store i64 %cv8947, ptr %slot1653, align 8
  %v8948 = load i64, ptr %slot1653, align 8
  %cond8949 = icmp ne i64 %v8948, 0
  br i1 %cond8949, label %bb_cast_overflow2561, label %bb_cast_ok2561
bb_cast_overflow2561:
  %v8950 = load i64, ptr %slot1, align 8
  %p8951 = inttoptr i64 %v8950 to ptr
  %v8952 = load i64, ptr %slot1652, align 8
  call void @myl_qbe_fail_cast(ptr %p8951, i64 %v8952, i64 320) nomerge, !dbg !202
  unreachable
bb_cast_ok2561:
  %v8953 = load i64, ptr %slot1652, align 8
  %v8954 = load i64, ptr %slot57, align 8
  %p8955 = inttoptr i64 %v8954 to ptr
  store i64 %v8953, ptr %p8955, align 8, !alias.scope !3, !noalias !4
  %v8956 = load i64, ptr %slot56, align 8
  %p8957 = inttoptr i64 %v8956 to ptr
  %ld8958 = load i64, ptr %p8957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8958, ptr %slot1654, align 8
  %v8959 = load i64, ptr %slot1654, align 8
  %v8960 = load i64, ptr %slot58, align 8
  %p8961 = inttoptr i64 %v8960 to ptr
  store i64 %v8959, ptr %p8961, align 8, !alias.scope !3, !noalias !4
  %v8962 = load i64, ptr %slot58, align 8
  %p8963 = inttoptr i64 %v8962 to ptr
  %ld8964 = load i64, ptr %p8963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8964, ptr %slot1655, align 8
  %v8965 = load i64, ptr %slot57, align 8
  %p8966 = inttoptr i64 %v8965 to ptr
  %ld8967 = load i64, ptr %p8966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8967, ptr %slot1656, align 8
  %v8968 = load i64, ptr %slot1656, align 8
  %v8969 = load i64, ptr %slot1655, align 8
  %ovpair8971 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v8968, i64 %v8969)
  %op8970 = extractvalue { i64, i1 } %ovpair8971, 0
  %ov8972 = extractvalue { i64, i1 } %ovpair8971, 1
  store i64 %op8970, ptr %slot1657, align 8
  %v8973 = load i64, ptr %slot1656, align 8
  %v8974 = load i64, ptr %slot1657, align 8
  %op8975 = xor i64 %v8973, %v8974
  store i64 %op8975, ptr %slot1658, align 8
  %v8976 = load i64, ptr %slot1655, align 8
  %v8977 = load i64, ptr %slot1657, align 8
  %op8978 = xor i64 %v8976, %v8977
  store i64 %op8978, ptr %slot1659, align 8
  %v8979 = load i64, ptr %slot1658, align 8
  %v8980 = load i64, ptr %slot1659, align 8
  %op8981 = and i64 %v8979, %v8980
  store i64 %op8981, ptr %slot1660, align 8
  %cv8982 = zext i1 %ov8972 to i64
  store i64 %cv8982, ptr %slot1661, align 8
  %v8983 = load i64, ptr %slot1661, align 8
  %cond8984 = icmp ne i64 %v8983, 0
  br i1 %cond8984, label %bb_overflow2565, label %bb_checked2565
bb_overflow2565:
  %v8985 = load i64, ptr %slot1, align 8
  %p8986 = inttoptr i64 %v8985 to ptr
  %v8987 = load i64, ptr %slot1656, align 8
  %v8988 = load i64, ptr %slot1655, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p8986, i64 0, i64 %v8987, i64 %v8988, i64 64) nomerge, !dbg !204
  unreachable
bb_checked2565:
  %v8989 = load i64, ptr %slot1657, align 8
  %v8990 = load i64, ptr %slot57, align 8
  %p8991 = inttoptr i64 %v8990 to ptr
  store i64 %v8989, ptr %p8991, align 8, !alias.scope !3, !noalias !4
  %v8992 = load i64, ptr %slot57, align 8
  %p8993 = inttoptr i64 %v8992 to ptr
  %ld8994 = load i64, ptr %p8993, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8994, ptr %slot1662, align 8
  %v8995 = load i64, ptr %slot1662, align 8
  %v8996 = load i64, ptr %slot56, align 8
  %p8997 = inttoptr i64 %v8996 to ptr
  store i64 %v8995, ptr %p8997, align 8, !alias.scope !3, !noalias !4
  br label %bb_i142
bb_i142:
  %v8998 = load i64, ptr %slot56, align 8
  %p8999 = inttoptr i64 %v8998 to ptr
  %ld9000 = load i64, ptr %p8999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9000, ptr %slot1663, align 8
  %v9001 = load i64, ptr %slot1663, align 8
  %v9002 = load i64, ptr %slot57, align 8
  %p9003 = inttoptr i64 %v9002 to ptr
  store i64 %v9001, ptr %p9003, align 8, !alias.scope !3, !noalias !4
  %v9004 = load i64, ptr %slot55, align 8
  %v9005 = load i64, ptr %slot64, align 8
  %p9006 = inttoptr i64 %v9004 to ptr
  %p9007 = inttoptr i64 %v9005 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9007, ptr %p9006, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v9008 = load i64, ptr %slot64, align 8
  %v9009 = load i64, ptr %slot58, align 8
  %p9010 = inttoptr i64 %v9009 to ptr
  store i64 %v9008, ptr %p9010, align 8, !alias.scope !3, !noalias !4
  %v9011 = load i64, ptr %slot54, align 8
  %p9012 = inttoptr i64 %v9011 to ptr
  %ld9013 = load i64, ptr %p9012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9013, ptr %slot1664, align 8
  %v9014 = load i64, ptr %slot58, align 8
  %p9015 = inttoptr i64 %v9014 to ptr
  %ld9016 = load i64, ptr %p9015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9016, ptr %slot1665, align 8
  %v9017 = load i64, ptr %slot57, align 8
  %p9018 = inttoptr i64 %v9017 to ptr
  %ld9019 = load i64, ptr %p9018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9019, ptr %slot1666, align 8
  %v9020 = load i64, ptr %slot1664, align 8
  %p9021 = inttoptr i64 %v9020 to ptr
  %ld9022 = load i64, ptr %p9021, align 8, !alias.scope !6, !noalias !7
  store i64 %ld9022, ptr %slot1667, align 8
  %v9023 = load i64, ptr %slot1666, align 8
  %v9024 = load i64, ptr %slot1667, align 8
  %cmp9025 = icmp ult i64 %v9023, %v9024
  %cv9026 = zext i1 %cmp9025 to i64
  store i64 %cv9026, ptr %slot1668, align 8
  %v9027 = load i64, ptr %slot1668, align 8
  %cond9028 = icmp ne i64 %v9027, 0
  br i1 %cond9028, label %bb_success2578, label %bb_failed2578
bb_failed2578:
  %v9029 = load i64, ptr %slot1, align 8
  %p9030 = inttoptr i64 %v9029 to ptr
  %v9031 = load i64, ptr %slot1666, align 8
  %v9032 = load i64, ptr %slot1667, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p9030, i64 %v9031, i64 %v9032) nomerge, !dbg !206
  unreachable
bb_success2578:
  %v9033 = load i64, ptr %slot58, align 8
  %p9034 = inttoptr i64 %v9033 to ptr
  %ld9035 = load i64, ptr %p9034, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9035, ptr %slot1669, align 8
  %v9036 = load i64, ptr %slot70, align 8
  %v9037 = load i64, ptr %slot1664, align 8
  %v9038 = load i64, ptr %slot1666, align 8
  %v9039 = load i64, ptr %slot1669, align 8
  %call9040 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v9036, i64 %v9037, i64 %v9038, i64 %v9039) nomerge, !dbg !206
  store i32 %call9040, ptr %slot1670, align 8
  %v9041 = load i32, ptr %slot1670, align 8
  %cv9042 = zext i32 %v9041 to i64
  %cond9043 = icmp ne i64 %cv9042, 0
  br i1 %cond9043, label %bb_success2581, label %bb_failed2581
bb_failed2581:
  %v9044 = load i64, ptr %slot1, align 8
  %p9045 = inttoptr i64 %v9044 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9045) nomerge, !dbg !206
  unreachable
bb_success2581:
  %v9046 = load i64, ptr %slot57, align 8
  %p9047 = inttoptr i64 %v9046 to ptr
  store i64 0, ptr %p9047, align 8, !alias.scope !3, !noalias !4
  %v9048 = load i64, ptr %slot19, align 8
  %p9049 = inttoptr i64 %v9048 to ptr
  %ld9050 = load i32, ptr %p9049, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9050, ptr %slot1671, align 8
  %v9051 = load i32, ptr %slot1671, align 8
  %cv9052 = zext i32 %v9051 to i64
  %cond9053 = icmp ne i64 %cv9052, 0
  br i1 %cond9053, label %bb_rcslotdrop2584, label %bb_rcslotdone2584
bb_rcslotdrop2584:
  %v9054 = load i64, ptr %slot19, align 8
  %p9055 = inttoptr i64 %v9054 to ptr
  store i32 0, ptr %p9055, align 4, !alias.scope !3, !noalias !4
  %v9056 = load i64, ptr %slot25, align 8
  store i64 %v9056, ptr %slot1672, align 8
  %v9057 = load i64, ptr %slot20, align 8
  %p9058 = inttoptr i64 %v9057 to ptr
  %ld9059 = load i32, ptr %p9058, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9059, ptr %slot1673, align 8
  %v9060 = load i32, ptr %slot1673, align 8
  %op9061 = and i32 %v9060, 28
  store i32 %op9061, ptr %slot1674, align 8
  %v9062 = load i32, ptr %slot1674, align 8
  %cv9063 = zext i32 %v9062 to i64
  %cond9064 = icmp ne i64 %cv9063, 0
  br i1 %cond9064, label %bb_rcslotrole2584, label %bb_rcslotowner2584
bb_rcslotrole2584:
  %v9065 = load i64, ptr %slot70, align 8
  store i64 %v9065, ptr %slot1675, align 8
  %v9066 = load i64, ptr %slot1675, align 8
  %v9067 = load i64, ptr %slot1672, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v9066, i64 %v9067) nomerge, !dbg !206
  br label %bb_rcslotdone2584
bb_rcslotowner2584:
  %v9068 = load i64, ptr %slot70, align 8
  store i64 %v9068, ptr %slot1676, align 8
  %v9069 = load i64, ptr %slot1676, align 8
  %v9070 = load i64, ptr %slot1672, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v9069, i64 %v9070) nomerge, !dbg !206
  br label %bb_rcslotdone2584
bb_rcslotdone2584:
  %v9071 = load i64, ptr %slot33, align 8
  store i64 %v9071, ptr %slot1677, align 8
  %v9072 = load i64, ptr %slot1677, align 8
  %p9074 = inttoptr i64 %v9072 to ptr
  %gep9075 = getelementptr i8, ptr %p9074, i64 24
  %op9073 = ptrtoint ptr %gep9075 to i64
  store i64 %op9073, ptr %slot1678, align 8
  %v9076 = load i64, ptr %slot1678, align 8
  %p9077 = inttoptr i64 %v9076 to ptr
  %ld9078 = load i32, ptr %p9077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9078, ptr %slot1679, align 8
  %v9079 = load i32, ptr %slot1679, align 8
  %cv9080 = zext i32 %v9079 to i64
  %cond9081 = icmp ne i64 %cv9080, 0
  br i1 %cond9081, label %bb_rcsendactive2592, label %bb_rcsenddone2592
bb_rcsendactive2592:
  %v9082 = load i64, ptr %slot70, align 8
  %p9084 = inttoptr i64 %v9082 to ptr
  %gep9085 = getelementptr i8, ptr %p9084, i64 5640
  %op9083 = ptrtoint ptr %gep9085 to i64
  store i64 %op9083, ptr %slot1680, align 8
  %v9086 = load i64, ptr %slot1680, align 8
  %p9087 = inttoptr i64 %v9086 to ptr
  %ld9088 = load i64, ptr %p9087, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9088, ptr %slot1681, align 8
  %v9089 = load i64, ptr %slot1681, align 8
  %op9090 = add i64 %v9089, 248
  store i64 %op9090, ptr %slot1682, align 8
  %v9091 = load i64, ptr %slot1682, align 8
  %p9092 = inttoptr i64 %v9091 to ptr
  %ld9093 = load i64, ptr %p9092, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9093, ptr %slot1683, align 8
  %v9094 = load i64, ptr %slot1683, align 8
  %v9095 = load i64, ptr %slot1677, align 8
  %cmp9096 = icmp eq i64 %v9094, %v9095
  %cv9097 = zext i1 %cmp9096 to i32
  store i32 %cv9097, ptr %slot1684, align 8
  %v9098 = load i32, ptr %slot1684, align 8
  %cv9099 = zext i32 %v9098 to i64
  %cond9100 = icmp ne i64 %cv9099, 0
  br i1 %cond9100, label %bb_rcs2600, label %bb_rcsendslow2592
bb_rcs2600:
  %v9101 = load i64, ptr %slot1681, align 8
  %op9102 = add i64 %v9101, 200
  store i64 %op9102, ptr %slot1685, align 8
  %v9103 = load i64, ptr %slot1685, align 8
  %p9104 = inttoptr i64 %v9103 to ptr
  %ld9105 = load i64, ptr %p9104, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9105, ptr %slot1686, align 8
  %v9106 = load i64, ptr %slot1686, align 8
  %cmp9107 = icmp eq i64 %v9106, 0
  %cv9108 = zext i1 %cmp9107 to i32
  store i32 %cv9108, ptr %slot1687, align 8
  %v9109 = load i32, ptr %slot1687, align 8
  %cv9110 = zext i32 %v9109 to i64
  %cond9111 = icmp ne i64 %cv9110, 0
  br i1 %cond9111, label %bb_rcs2604, label %bb_rcsendslow2592
bb_rcs2604:
  %v9112 = load i64, ptr %slot1677, align 8
  %p9114 = inttoptr i64 %v9112 to ptr
  %gep9115 = getelementptr i8, ptr %p9114, i64 16
  %op9113 = ptrtoint ptr %gep9115 to i64
  store i64 %op9113, ptr %slot1688, align 8
  %v9116 = load i64, ptr %slot1688, align 8
  %p9117 = inttoptr i64 %v9116 to ptr
  %ld9118 = load i64, ptr %p9117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9118, ptr %slot1689, align 8
  %v9119 = load i64, ptr %slot1689, align 8
  %cmp9120 = icmp ne i64 %v9119, 0
  %cv9121 = zext i1 %cmp9120 to i32
  store i32 %cv9121, ptr %slot1690, align 8
  %v9122 = load i32, ptr %slot1690, align 8
  %cv9123 = zext i32 %v9122 to i64
  %cond9124 = icmp ne i64 %cv9123, 0
  br i1 %cond9124, label %bb_rcsendnode2592, label %bb_rcsendunlink2592
bb_rcsendnode2592:
  %v9125 = load i64, ptr %slot1689, align 8
  %op9126 = add i64 %v9125, 0
  store i64 %op9126, ptr %slot1691, align 8
  %v9127 = load i64, ptr %slot1691, align 8
  %p9128 = inttoptr i64 %v9127 to ptr
  %ld9129 = load i64, ptr %p9128, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9129, ptr %slot1692, align 8
  %v9130 = load i64, ptr %slot1692, align 8
  %cmp9131 = icmp eq i64 %v9130, 0
  %cv9132 = zext i1 %cmp9131 to i32
  store i32 %cv9132, ptr %slot1693, align 8
  %v9133 = load i32, ptr %slot1693, align 8
  %cv9134 = zext i32 %v9133 to i64
  %cond9135 = icmp ne i64 %cv9134, 0
  br i1 %cond9135, label %bb_rcs2611, label %bb_rcsendslow2592
bb_rcs2611:
  %v9136 = load i64, ptr %slot1681, align 8
  %op9137 = add i64 %v9136, 264
  store i64 %op9137, ptr %slot1694, align 8
  %v9138 = load i64, ptr %slot1694, align 8
  %p9139 = inttoptr i64 %v9138 to ptr
  %ld9140 = load i64, ptr %p9139, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9140, ptr %slot1695, align 8
  %v9141 = load i64, ptr %slot1695, align 8
  %cmp9142 = icmp ult i64 %v9141, 32
  %cv9143 = zext i1 %cmp9142 to i32
  store i32 %cv9143, ptr %slot1696, align 8
  %v9144 = load i32, ptr %slot1696, align 8
  %cv9145 = zext i32 %v9144 to i64
  %cond9146 = icmp ne i64 %cv9145, 0
  br i1 %cond9146, label %bb_rcs2615, label %bb_rcsendslow2592
bb_rcs2615:
  %v9147 = load i64, ptr %slot1689, align 8
  %op9148 = add i64 %v9147, 8
  store i64 %op9148, ptr %slot1697, align 8
  %v9149 = load i64, ptr %slot1697, align 8
  %p9150 = inttoptr i64 %v9149 to ptr
  %ld9151 = load i64, ptr %p9150, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9151, ptr %slot1698, align 8
  %v9152 = load i64, ptr %slot1698, align 8
  %cmp9153 = icmp ne i64 %v9152, 0
  %cv9154 = zext i1 %cmp9153 to i32
  store i32 %cv9154, ptr %slot1699, align 8
  %v9155 = load i32, ptr %slot1699, align 8
  %cv9156 = zext i32 %v9155 to i64
  %cond9157 = icmp ne i64 %cv9156, 0
  br i1 %cond9157, label %bb_rcs2619, label %bb_rcsendslow2592
bb_rcs2619:
  %v9158 = load i64, ptr %slot1698, align 8
  %op9159 = sub i64 %v9158, 16
  store i64 %op9159, ptr %slot1700, align 8
  %v9160 = load i64, ptr %slot1698, align 8
  %p9161 = inttoptr i64 %v9160 to ptr
  %rgep9162 = getelementptr i8, ptr %p9161, i64 -16
  %ld9163 = load i64, ptr %rgep9162, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9163, ptr %slot1701, align 8
  %v9164 = load i64, ptr %slot1701, align 8
  %op9165 = and i64 %v9164, 4611686018427387907
  store i64 %op9165, ptr %slot1702, align 8
  %v9166 = load i64, ptr %slot1702, align 8
  %cmp9167 = icmp eq i64 %v9166, 0
  %cv9168 = zext i1 %cmp9167 to i32
  store i32 %cv9168, ptr %slot1703, align 8
  %v9169 = load i32, ptr %slot1703, align 8
  %cv9170 = zext i32 %v9169 to i64
  %cond9171 = icmp ne i64 %cv9170, 0
  br i1 %cond9171, label %bb_rcs2624, label %bb_rcsendslow2592
bb_rcs2624:
  %v9172 = load i64, ptr %slot1698, align 8
  %op9173 = sub i64 %v9172, 24
  store i64 %op9173, ptr %slot1704, align 8
  %v9174 = load i64, ptr %slot1698, align 8
  %p9175 = inttoptr i64 %v9174 to ptr
  %rgep9176 = getelementptr i8, ptr %p9175, i64 -24
  %ld9177 = load i64, ptr %rgep9176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9177, ptr %slot1705, align 8
  %v9178 = load i64, ptr %slot1705, align 8
  %cmp9179 = icmp ne i64 %v9178, 0
  %cv9180 = zext i1 %cmp9179 to i32
  store i32 %cv9180, ptr %slot1706, align 8
  %v9181 = load i32, ptr %slot1706, align 8
  %cv9182 = zext i32 %v9181 to i64
  %cond9183 = icmp ne i64 %cv9182, 0
  br i1 %cond9183, label %bb_rcs2628, label %bb_rcsendslow2592
bb_rcs2628:
  %v9184 = load i64, ptr %slot1698, align 8
  %op9185 = sub i64 %v9184, 32
  store i64 %op9185, ptr %slot1707, align 8
  %v9186 = load i64, ptr %slot1698, align 8
  %p9187 = inttoptr i64 %v9186 to ptr
  %rgep9188 = getelementptr i8, ptr %p9187, i64 -32
  %ld9189 = load i64, ptr %rgep9188, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9189, ptr %slot1708, align 8
  %v9190 = load i64, ptr %slot1705, align 8
  %cmp9191 = icmp ugt i64 %v9190, 1
  %cv9192 = zext i1 %cmp9191 to i32
  store i32 %cv9192, ptr %slot1709, align 8
  %v9193 = load i64, ptr %slot1708, align 8
  %cmp9194 = icmp ne i64 %v9193, 0
  %cv9195 = zext i1 %cmp9194 to i32
  store i32 %cv9195, ptr %slot1710, align 8
  %v9196 = load i32, ptr %slot1709, align 8
  %v9197 = load i32, ptr %slot1710, align 8
  %op9198 = or i32 %v9196, %v9197
  store i32 %op9198, ptr %slot1711, align 8
  %v9199 = load i32, ptr %slot1711, align 8
  %cv9200 = zext i32 %v9199 to i64
  %cond9201 = icmp ne i64 %cv9200, 0
  br i1 %cond9201, label %bb_rcs2634, label %bb_rcsendslow2592
bb_rcs2634:
  %v9202 = load i64, ptr %slot1689, align 8
  %op9203 = add i64 %v9202, 32
  store i64 %op9203, ptr %slot1712, align 8
  %v9204 = load i64, ptr %slot1712, align 8
  %p9205 = inttoptr i64 %v9204 to ptr
  %ld9206 = load i64, ptr %p9205, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9206, ptr %slot1713, align 8
  %v9207 = load i64, ptr %slot1713, align 8
  %cmp9208 = icmp ne i64 %v9207, 0
  %cv9209 = zext i1 %cmp9208 to i32
  store i32 %cv9209, ptr %slot1714, align 8
  %v9210 = load i32, ptr %slot1714, align 8
  %cv9211 = zext i32 %v9210 to i64
  %cond9212 = icmp ne i64 %cv9211, 0
  br i1 %cond9212, label %bb_rcsendbacking2592, label %bb_rcsendcommit2592
bb_rcsendbacking2592:
  %v9213 = load i64, ptr %slot1713, align 8
  %op9214 = sub i64 %v9213, 16
  store i64 %op9214, ptr %slot1715, align 8
  %v9215 = load i64, ptr %slot1713, align 8
  %p9216 = inttoptr i64 %v9215 to ptr
  %rgep9217 = getelementptr i8, ptr %p9216, i64 -16
  %ld9218 = load i64, ptr %rgep9217, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9218, ptr %slot1716, align 8
  %v9219 = load i64, ptr %slot1716, align 8
  %op9220 = and i64 %v9219, 4611686018427387907
  store i64 %op9220, ptr %slot1717, align 8
  %v9221 = load i64, ptr %slot1717, align 8
  %cmp9222 = icmp eq i64 %v9221, 0
  %cv9223 = zext i1 %cmp9222 to i32
  store i32 %cv9223, ptr %slot1718, align 8
  %v9224 = load i32, ptr %slot1718, align 8
  %cv9225 = zext i32 %v9224 to i64
  %cond9226 = icmp ne i64 %cv9225, 0
  br i1 %cond9226, label %bb_rcs2642, label %bb_rcsendslow2592
bb_rcs2642:
  %v9227 = load i64, ptr %slot1713, align 8
  %op9228 = sub i64 %v9227, 24
  store i64 %op9228, ptr %slot1719, align 8
  %v9229 = load i64, ptr %slot1713, align 8
  %p9230 = inttoptr i64 %v9229 to ptr
  %rgep9231 = getelementptr i8, ptr %p9230, i64 -24
  %ld9232 = load i64, ptr %rgep9231, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9232, ptr %slot1720, align 8
  %v9233 = load i64, ptr %slot1720, align 8
  %cmp9234 = icmp ne i64 %v9233, 0
  %cv9235 = zext i1 %cmp9234 to i32
  store i32 %cv9235, ptr %slot1721, align 8
  %v9236 = load i32, ptr %slot1721, align 8
  %cv9237 = zext i32 %v9236 to i64
  %cond9238 = icmp ne i64 %cv9237, 0
  br i1 %cond9238, label %bb_rcs2646, label %bb_rcsendslow2592
bb_rcs2646:
  %v9239 = load i64, ptr %slot1713, align 8
  %op9240 = sub i64 %v9239, 32
  store i64 %op9240, ptr %slot1722, align 8
  %v9241 = load i64, ptr %slot1713, align 8
  %p9242 = inttoptr i64 %v9241 to ptr
  %rgep9243 = getelementptr i8, ptr %p9242, i64 -32
  %ld9244 = load i64, ptr %rgep9243, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9244, ptr %slot1723, align 8
  %v9245 = load i64, ptr %slot1720, align 8
  %cmp9246 = icmp ugt i64 %v9245, 1
  %cv9247 = zext i1 %cmp9246 to i32
  store i32 %cv9247, ptr %slot1724, align 8
  %v9248 = load i64, ptr %slot1723, align 8
  %cmp9249 = icmp ne i64 %v9248, 0
  %cv9250 = zext i1 %cmp9249 to i32
  store i32 %cv9250, ptr %slot1725, align 8
  %v9251 = load i32, ptr %slot1724, align 8
  %v9252 = load i32, ptr %slot1725, align 8
  %op9253 = or i32 %v9251, %v9252
  store i32 %op9253, ptr %slot1726, align 8
  %v9254 = load i32, ptr %slot1726, align 8
  %cv9255 = zext i32 %v9254 to i64
  %cond9256 = icmp ne i64 %cv9255, 0
  br i1 %cond9256, label %bb_rcs2652, label %bb_rcsendslow2592
bb_rcs2652:
  br label %bb_rcsendcommit2592
bb_rcsendcommit2592:
  %v9257 = load i64, ptr %slot1689, align 8
  %op9258 = add i64 %v9257, 24
  store i64 %op9258, ptr %slot1727, align 8
  %v9259 = load i64, ptr %slot1727, align 8
  %p9260 = inttoptr i64 %v9259 to ptr
  %ld9261 = load i32, ptr %p9260, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld9261, ptr %slot1728, align 8
  %v9262 = load i32, ptr %slot1728, align 8
  %cv9263 = zext i32 %v9262 to i64
  %cond9264 = icmp ne i64 %cv9263, 0
  br i1 %cond9264, label %bb_rcsendrestore2592, label %bb_rcsendreturned2592
bb_rcsendrestore2592:
  %v9265 = load i64, ptr %slot1689, align 8
  %op9266 = add i64 %v9265, 16
  store i64 %op9266, ptr %slot1729, align 8
  %v9267 = load i64, ptr %slot1729, align 8
  %p9268 = inttoptr i64 %v9267 to ptr
  %ld9269 = load i64, ptr %p9268, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9269, ptr %slot1730, align 8
  %v9270 = load i64, ptr %slot1701, align 8
  %op9271 = and i64 %v9270, 17293822569102704639
  store i64 %op9271, ptr %slot1731, align 8
  %v9272 = load i64, ptr %slot1731, align 8
  %v9273 = load i64, ptr %slot1730, align 8
  %op9274 = or i64 %v9272, %v9273
  store i64 %op9274, ptr %slot1732, align 8
  %v9275 = load i64, ptr %slot1698, align 8
  %op9276 = sub i64 %v9275, 16
  store i64 %op9276, ptr %slot1733, align 8
  %v9277 = load i64, ptr %slot1732, align 8
  %v9278 = load i64, ptr %slot1698, align 8
  %p9279 = inttoptr i64 %v9278 to ptr
  %rgep9280 = getelementptr i8, ptr %p9279, i64 -16
  store i64 %v9277, ptr %rgep9280, align 8, !alias.scope !9, !noalias !10
  %v9281 = load i64, ptr %slot1677, align 8
  %p9283 = inttoptr i64 %v9281 to ptr
  %gep9284 = getelementptr i8, ptr %p9283, i64 16
  %op9282 = ptrtoint ptr %gep9284 to i64
  store i64 %op9282, ptr %slot1734, align 8
  br label %bb_rcsendreturned2592
bb_rcsendreturned2592:
  %v9285 = load i64, ptr %slot1734, align 8
  %p9286 = inttoptr i64 %v9285 to ptr
  store i64 0, ptr %p9286, align 8, !alias.scope !3, !noalias !4
  %v9287 = load i64, ptr %slot1681, align 8
  %op9288 = add i64 %v9287, 256
  store i64 %op9288, ptr %slot1735, align 8
  %v9289 = load i64, ptr %slot1735, align 8
  %p9290 = inttoptr i64 %v9289 to ptr
  %ld9291 = load i64, ptr %p9290, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9291, ptr %slot1736, align 8
  %v9292 = load i64, ptr %slot1689, align 8
  %op9293 = add i64 %v9292, 0
  store i64 %op9293, ptr %slot1737, align 8
  %v9294 = load i64, ptr %slot1736, align 8
  %v9295 = load i64, ptr %slot1737, align 8
  %p9296 = inttoptr i64 %v9295 to ptr
  store i64 %v9294, ptr %p9296, align 8, !alias.scope !9999998, !noalias !9999999
  %v9297 = load i64, ptr %slot1681, align 8
  %op9298 = add i64 %v9297, 256
  store i64 %op9298, ptr %slot1738, align 8
  %v9299 = load i64, ptr %slot1689, align 8
  %v9300 = load i64, ptr %slot1738, align 8
  %p9301 = inttoptr i64 %v9300 to ptr
  store i64 %v9299, ptr %p9301, align 8, !alias.scope !9999998, !noalias !9999999
  %v9302 = load i64, ptr %slot1681, align 8
  %op9303 = add i64 %v9302, 264
  store i64 %op9303, ptr %slot1739, align 8
  %v9304 = load i64, ptr %slot1739, align 8
  %p9305 = inttoptr i64 %v9304 to ptr
  %ld9306 = load i64, ptr %p9305, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9306, ptr %slot1740, align 8
  %v9307 = load i64, ptr %slot1740, align 8
  %op9308 = add i64 %v9307, 1
  store i64 %op9308, ptr %slot1741, align 8
  %v9309 = load i64, ptr %slot1741, align 8
  %v9310 = load i64, ptr %slot1739, align 8
  %p9311 = inttoptr i64 %v9310 to ptr
  store i64 %v9309, ptr %p9311, align 8, !alias.scope !9999998, !noalias !9999999
  %v9312 = load i64, ptr %slot70, align 8
  %p9314 = inttoptr i64 %v9312 to ptr
  %gep9315 = getelementptr i8, ptr %p9314, i64 24
  %op9313 = ptrtoint ptr %gep9315 to i64
  store i64 %op9313, ptr %slot1742, align 8
  %v9316 = load i64, ptr %slot1742, align 8
  %p9317 = inttoptr i64 %v9316 to ptr
  %ld9318 = load i64, ptr %p9317, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9318, ptr %slot1743, align 8
  %v9319 = load i64, ptr %slot1743, align 8
  %op9320 = add i64 %v9319, 18446744073709551576
  store i64 %op9320, ptr %slot1744, align 8
  %v9321 = load i64, ptr %slot1744, align 8
  %v9322 = load i64, ptr %slot1742, align 8
  %p9323 = inttoptr i64 %v9322 to ptr
  store i64 %v9321, ptr %p9323, align 8, !alias.scope !9999998, !noalias !9999999
  %v9324 = load i64, ptr %slot1681, align 8
  %op9325 = add i64 %v9324, 48
  store i64 %op9325, ptr %slot1745, align 8
  %v9326 = load i64, ptr %slot1745, align 8
  %p9327 = inttoptr i64 %v9326 to ptr
  %ld9328 = load i64, ptr %p9327, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9328, ptr %slot1746, align 8
  %v9329 = load i64, ptr %slot1746, align 8
  %op9330 = add i64 %v9329, 18446744073709551576
  store i64 %op9330, ptr %slot1747, align 8
  %v9331 = load i64, ptr %slot1747, align 8
  %v9332 = load i64, ptr %slot1745, align 8
  %p9333 = inttoptr i64 %v9332 to ptr
  store i64 %v9331, ptr %p9333, align 8, !alias.scope !9999998, !noalias !9999999
  %v9334 = load i64, ptr %slot1713, align 8
  %cmp9335 = icmp ne i64 %v9334, 0
  %cv9336 = zext i1 %cmp9335 to i32
  store i32 %cv9336, ptr %slot1748, align 8
  %v9337 = load i32, ptr %slot1748, align 8
  %cv9338 = zext i32 %v9337 to i64
  %cond9339 = icmp ne i64 %cv9338, 0
  br i1 %cond9339, label %bb_rcsenddropbacking2592, label %bb_rcsenddroppayload2592
bb_rcsenddropbacking2592:
  %v9340 = load i64, ptr %slot1713, align 8
  %op9341 = sub i64 %v9340, 24
  store i64 %op9341, ptr %slot1749, align 8
  %v9342 = load i64, ptr %slot1713, align 8
  %p9343 = inttoptr i64 %v9342 to ptr
  %rgep9344 = getelementptr i8, ptr %p9343, i64 -24
  %ld9345 = load i64, ptr %rgep9344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9345, ptr %slot1750, align 8
  %v9346 = load i64, ptr %slot1750, align 8
  %op9347 = add i64 %v9346, 18446744073709551615
  store i64 %op9347, ptr %slot1751, align 8
  %v9348 = load i64, ptr %slot1751, align 8
  %v9349 = load i64, ptr %slot1713, align 8
  %p9350 = inttoptr i64 %v9349 to ptr
  %rgep9351 = getelementptr i8, ptr %p9350, i64 -24
  store i64 %v9348, ptr %rgep9351, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload2592
bb_rcsenddroppayload2592:
  %v9352 = load i64, ptr %slot1698, align 8
  %op9353 = sub i64 %v9352, 24
  store i64 %op9353, ptr %slot1752, align 8
  %v9354 = load i64, ptr %slot1698, align 8
  %p9355 = inttoptr i64 %v9354 to ptr
  %rgep9356 = getelementptr i8, ptr %p9355, i64 -24
  %ld9357 = load i64, ptr %rgep9356, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9357, ptr %slot1753, align 8
  %v9358 = load i64, ptr %slot1753, align 8
  %op9359 = add i64 %v9358, 18446744073709551615
  store i64 %op9359, ptr %slot1754, align 8
  %v9360 = load i64, ptr %slot1754, align 8
  %v9361 = load i64, ptr %slot1698, align 8
  %p9362 = inttoptr i64 %v9361 to ptr
  %rgep9363 = getelementptr i8, ptr %p9362, i64 -24
  store i64 %v9360, ptr %rgep9363, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink2592
bb_rcsendunlink2592:
  %v9364 = load i64, ptr %slot1677, align 8
  %p9366 = inttoptr i64 %v9364 to ptr
  %gep9367 = getelementptr i8, ptr %p9366, i64 8
  %op9365 = ptrtoint ptr %gep9367 to i64
  store i64 %op9365, ptr %slot1755, align 8
  %v9368 = load i64, ptr %slot1755, align 8
  %p9369 = inttoptr i64 %v9368 to ptr
  %ld9370 = load i64, ptr %p9369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9370, ptr %slot1756, align 8
  %v9371 = load i64, ptr %slot1681, align 8
  %op9372 = add i64 %v9371, 248
  store i64 %op9372, ptr %slot1757, align 8
  %v9373 = load i64, ptr %slot1756, align 8
  %v9374 = load i64, ptr %slot1757, align 8
  %p9375 = inttoptr i64 %v9374 to ptr
  store i64 %v9373, ptr %p9375, align 8, !alias.scope !9999998, !noalias !9999999
  %v9376 = load i64, ptr %slot1677, align 8
  %p9378 = inttoptr i64 %v9376 to ptr
  %gep9379 = getelementptr i8, ptr %p9378, i64 24
  %op9377 = ptrtoint ptr %gep9379 to i64
  store i64 %op9377, ptr %slot1758, align 8
  %v9380 = load i64, ptr %slot1677, align 8
  %p9382 = inttoptr i64 %v9380 to ptr
  %gep9383 = getelementptr i8, ptr %p9382, i64 8
  %op9381 = ptrtoint ptr %gep9383 to i64
  store i64 %op9381, ptr %slot1759, align 8
  %v9384 = load i64, ptr %slot1758, align 8
  %p9385 = inttoptr i64 %v9384 to ptr
  store i32 0, ptr %p9385, align 4, !alias.scope !3, !noalias !4
  %v9386 = load i64, ptr %slot1759, align 8
  %p9387 = inttoptr i64 %v9386 to ptr
  store i64 0, ptr %p9387, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone2592
bb_rcsendslow2592:
  %v9388 = load i64, ptr %slot1, align 8
  %p9389 = inttoptr i64 %v9388 to ptr
  %v9390 = load i64, ptr %slot1677, align 8
  %p9391 = inttoptr i64 %v9390 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p9389, ptr %p9391) nomerge, !dbg !206
  br label %bb_rcsenddone2592
bb_rcsenddone2592:
  %v9392 = load i64, ptr %slot43, align 8
  %p9393 = inttoptr i64 %v9392 to ptr
  %ld9394 = load i64, ptr %p9393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9394, ptr %slot1760, align 8
  %v9395 = load i64, ptr %slot1760, align 8
  %v9396 = load i64, ptr %slot57, align 8
  %p9397 = inttoptr i64 %v9396 to ptr
  store i64 %v9395, ptr %p9397, align 8, !alias.scope !3, !noalias !4
  %v9398 = load i64, ptr %slot57, align 8
  %p9399 = inttoptr i64 %v9398 to ptr
  %ld9400 = load i64, ptr %p9399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9400, ptr %slot1761, align 8
  %v9401 = load i64, ptr %slot29, align 8
  %p9403 = inttoptr i64 %v9401 to ptr
  %gep9404 = getelementptr i8, ptr %p9403, i64 24
  %op9402 = ptrtoint ptr %gep9404 to i64
  store i64 %op9402, ptr %slot1762, align 8
  %v9405 = load i64, ptr %slot1762, align 8
  %p9406 = inttoptr i64 %v9405 to ptr
  %ld9407 = load i32, ptr %p9406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9407, ptr %slot1763, align 8
  %v9408 = load i64, ptr %slot31, align 8
  %p9410 = inttoptr i64 %v9408 to ptr
  %gep9411 = getelementptr i8, ptr %p9410, i64 24
  %op9409 = ptrtoint ptr %gep9411 to i64
  store i64 %op9409, ptr %slot1764, align 8
  %v9412 = load i64, ptr %slot1764, align 8
  %p9413 = inttoptr i64 %v9412 to ptr
  %ld9414 = load i32, ptr %p9413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9414, ptr %slot1765, align 8
  %v9415 = load i32, ptr %slot1763, align 8
  %v9416 = load i32, ptr %slot1765, align 8
  %op9417 = or i32 %v9415, %v9416
  store i32 %op9417, ptr %slot1766, align 8
  %v9418 = load i64, ptr %slot33, align 8
  %p9420 = inttoptr i64 %v9418 to ptr
  %gep9421 = getelementptr i8, ptr %p9420, i64 24
  %op9419 = ptrtoint ptr %gep9421 to i64
  store i64 %op9419, ptr %slot1767, align 8
  %v9422 = load i64, ptr %slot1767, align 8
  %p9423 = inttoptr i64 %v9422 to ptr
  %ld9424 = load i32, ptr %p9423, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9424, ptr %slot1768, align 8
  %v9425 = load i32, ptr %slot1766, align 8
  %v9426 = load i32, ptr %slot1768, align 8
  %op9427 = or i32 %v9425, %v9426
  store i32 %op9427, ptr %slot1769, align 8
  %v9428 = load i32, ptr %slot1769, align 8
  %cv9429 = zext i32 %v9428 to i64
  %cond9430 = icmp ne i64 %cv9429, 0
  br i1 %cond9430, label %bb_rcscopesopen2696, label %bb_rcscopesclosed2696
bb_rcscopesopen2696:
  %v9431 = load i64, ptr %slot35, align 8
  %p9433 = inttoptr i64 %v9431 to ptr
  %gep9434 = getelementptr i8, ptr %p9433, i64 0
  %op9432 = ptrtoint ptr %gep9434 to i64
  store i64 %op9432, ptr %slot1770, align 8
  %v9435 = load i64, ptr %slot29, align 8
  %v9436 = load i64, ptr %slot1770, align 8
  %p9437 = inttoptr i64 %v9436 to ptr
  store i64 %v9435, ptr %p9437, align 8, !alias.scope !3, !noalias !4
  %v9438 = load i64, ptr %slot35, align 8
  %p9440 = inttoptr i64 %v9438 to ptr
  %gep9441 = getelementptr i8, ptr %p9440, i64 8
  %op9439 = ptrtoint ptr %gep9441 to i64
  store i64 %op9439, ptr %slot1771, align 8
  %v9442 = load i64, ptr %slot31, align 8
  %v9443 = load i64, ptr %slot1771, align 8
  %p9444 = inttoptr i64 %v9443 to ptr
  store i64 %v9442, ptr %p9444, align 8, !alias.scope !3, !noalias !4
  %v9445 = load i64, ptr %slot35, align 8
  %p9447 = inttoptr i64 %v9445 to ptr
  %gep9448 = getelementptr i8, ptr %p9447, i64 16
  %op9446 = ptrtoint ptr %gep9448 to i64
  store i64 %op9446, ptr %slot1772, align 8
  %v9449 = load i64, ptr %slot33, align 8
  %v9450 = load i64, ptr %slot1772, align 8
  %p9451 = inttoptr i64 %v9450 to ptr
  store i64 %v9449, ptr %p9451, align 8, !alias.scope !3, !noalias !4
  %v9452 = load i64, ptr %slot1, align 8
  %p9453 = inttoptr i64 %v9452 to ptr
  %v9454 = load i64, ptr %slot35, align 8
  %p9455 = inttoptr i64 %v9454 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p9453, ptr %p9455, i64 3) nomerge, !dbg !208
  br label %bb_rcscopesclosed2696
bb_rcscopesclosed2696:
  %v9456 = load i64, ptr %slot17, align 8
  %p9457 = inttoptr i64 %v9456 to ptr
  %ld9458 = load i32, ptr %p9457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9458, ptr %slot1773, align 8
  %v9459 = load i32, ptr %slot1773, align 8
  %cv9460 = zext i32 %v9459 to i64
  %cond9461 = icmp ne i64 %cv9460, 0
  br i1 %cond9461, label %bb_rcslotdrop2702, label %bb_rcslotdone2702
bb_rcslotdrop2702:
  %v9462 = load i64, ptr %slot17, align 8
  %p9463 = inttoptr i64 %v9462 to ptr
  store i32 0, ptr %p9463, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2702
bb_rcslotdone2702:
  %v9464 = load i64, ptr %slot15, align 8
  %p9465 = inttoptr i64 %v9464 to ptr
  %ld9466 = load i32, ptr %p9465, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9466, ptr %slot1774, align 8
  %v9467 = load i32, ptr %slot1774, align 8
  %cv9468 = zext i32 %v9467 to i64
  %cond9469 = icmp ne i64 %cv9468, 0
  br i1 %cond9469, label %bb_rcslotdrop2705, label %bb_rcslotdone2705
bb_rcslotdrop2705:
  %v9470 = load i64, ptr %slot15, align 8
  %p9471 = inttoptr i64 %v9470 to ptr
  store i32 0, ptr %p9471, align 4, !alias.scope !3, !noalias !4
  %v9472 = load i64, ptr %slot55, align 8
  store i64 %v9472, ptr %slot1775, align 8
  %v9473 = load i64, ptr %slot16, align 8
  %p9474 = inttoptr i64 %v9473 to ptr
  %ld9475 = load i32, ptr %p9474, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9475, ptr %slot1776, align 8
  %v9476 = load i32, ptr %slot1776, align 8
  %op9477 = and i32 %v9476, 28
  store i32 %op9477, ptr %slot1777, align 8
  %v9478 = load i32, ptr %slot1777, align 8
  %cv9479 = zext i32 %v9478 to i64
  %cond9480 = icmp ne i64 %cv9479, 0
  br i1 %cond9480, label %bb_rcslotrole2705, label %bb_rcslotowner2705
bb_rcslotrole2705:
  %v9481 = load i64, ptr %slot70, align 8
  store i64 %v9481, ptr %slot1778, align 8
  %v9482 = load i64, ptr %slot1778, align 8
  %v9483 = load i64, ptr %slot1775, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v9482, i64 %v9483) nomerge, !dbg !208
  br label %bb_rcslotdone2705
bb_rcslotowner2705:
  %v9484 = load i64, ptr %slot70, align 8
  store i64 %v9484, ptr %slot1779, align 8
  %v9485 = load i64, ptr %slot1779, align 8
  %v9486 = load i64, ptr %slot1775, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v9485, i64 %v9486) nomerge, !dbg !208
  br label %bb_rcslotdone2705
bb_rcslotdone2705:
  %v9487 = load i64, ptr %slot13, align 8
  %p9488 = inttoptr i64 %v9487 to ptr
  %ld9489 = load i32, ptr %p9488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9489, ptr %slot1780, align 8
  %v9490 = load i32, ptr %slot1780, align 8
  %cv9491 = zext i32 %v9490 to i64
  %cond9492 = icmp ne i64 %cv9491, 0
  br i1 %cond9492, label %bb_rcslotdrop2751, label %bb_rcslotdone2751
bb_rcslotdrop2751:
  %v9493 = load i64, ptr %slot13, align 8
  %p9494 = inttoptr i64 %v9493 to ptr
  store i32 0, ptr %p9494, align 4, !alias.scope !3, !noalias !4
  %v9495 = load i64, ptr %slot52, align 8
  store i64 %v9495, ptr %slot1781, align 8
  %v9496 = load i64, ptr %slot14, align 8
  %p9497 = inttoptr i64 %v9496 to ptr
  %ld9498 = load i32, ptr %p9497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9498, ptr %slot1782, align 8
  %v9499 = load i32, ptr %slot1782, align 8
  %op9500 = and i32 %v9499, 28
  store i32 %op9500, ptr %slot1783, align 8
  %v9501 = load i32, ptr %slot1783, align 8
  %cv9502 = zext i32 %v9501 to i64
  %cond9503 = icmp ne i64 %cv9502, 0
  br i1 %cond9503, label %bb_rcslotrole2751, label %bb_rcslotowner2751
bb_rcslotrole2751:
  %v9504 = load i64, ptr %slot70, align 8
  store i64 %v9504, ptr %slot1784, align 8
  %v9505 = load i64, ptr %slot1784, align 8
  %v9506 = load i64, ptr %slot1781, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v9505, i64 %v9506) nomerge, !dbg !208
  br label %bb_rcslotdone2751
bb_rcslotowner2751:
  %v9507 = load i64, ptr %slot70, align 8
  store i64 %v9507, ptr %slot1785, align 8
  %v9508 = load i64, ptr %slot1785, align 8
  %v9509 = load i64, ptr %slot1781, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v9508, i64 %v9509) nomerge, !dbg !208
  br label %bb_rcslotdone2751
bb_rcslotdone2751:
  %v9510 = load i64, ptr %slot11, align 8
  %p9511 = inttoptr i64 %v9510 to ptr
  %ld9512 = load i32, ptr %p9511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9512, ptr %slot1786, align 8
  %v9513 = load i32, ptr %slot1786, align 8
  %cv9514 = zext i32 %v9513 to i64
  %cond9515 = icmp ne i64 %cv9514, 0
  br i1 %cond9515, label %bb_rcslotdrop2797, label %bb_rcslotdone2797
bb_rcslotdrop2797:
  %v9516 = load i64, ptr %slot11, align 8
  %p9517 = inttoptr i64 %v9516 to ptr
  store i32 0, ptr %p9517, align 4, !alias.scope !3, !noalias !4
  %v9518 = load i64, ptr %slot49, align 8
  store i64 %v9518, ptr %slot1787, align 8
  %v9519 = load i64, ptr %slot12, align 8
  %p9520 = inttoptr i64 %v9519 to ptr
  %ld9521 = load i32, ptr %p9520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9521, ptr %slot1788, align 8
  %v9522 = load i32, ptr %slot1788, align 8
  %op9523 = and i32 %v9522, 28
  store i32 %op9523, ptr %slot1789, align 8
  %v9524 = load i32, ptr %slot1789, align 8
  %cv9525 = zext i32 %v9524 to i64
  %cond9526 = icmp ne i64 %cv9525, 0
  br i1 %cond9526, label %bb_rcslotrole2797, label %bb_rcslotowner2797
bb_rcslotrole2797:
  %v9527 = load i64, ptr %slot70, align 8
  store i64 %v9527, ptr %slot1790, align 8
  %v9528 = load i64, ptr %slot1790, align 8
  %v9529 = load i64, ptr %slot1787, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v9528, i64 %v9529) nomerge, !dbg !208
  br label %bb_rcslotdone2797
bb_rcslotowner2797:
  %v9530 = load i64, ptr %slot70, align 8
  store i64 %v9530, ptr %slot1791, align 8
  %v9531 = load i64, ptr %slot1791, align 8
  %v9532 = load i64, ptr %slot1787, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v9531, i64 %v9532) nomerge, !dbg !208
  br label %bb_rcslotdone2797
bb_rcslotdone2797:
  %v9533 = load i64, ptr %slot9, align 8
  %p9534 = inttoptr i64 %v9533 to ptr
  %ld9535 = load i32, ptr %p9534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9535, ptr %slot1792, align 8
  %v9536 = load i32, ptr %slot1792, align 8
  %cv9537 = zext i32 %v9536 to i64
  %cond9538 = icmp ne i64 %cv9537, 0
  br i1 %cond9538, label %bb_rcslotdrop2843, label %bb_rcslotdone2843
bb_rcslotdrop2843:
  %v9539 = load i64, ptr %slot9, align 8
  %p9540 = inttoptr i64 %v9539 to ptr
  store i32 0, ptr %p9540, align 4, !alias.scope !3, !noalias !4
  %v9541 = load i64, ptr %slot45, align 8
  store i64 %v9541, ptr %slot1793, align 8
  %v9542 = load i64, ptr %slot10, align 8
  %p9543 = inttoptr i64 %v9542 to ptr
  %ld9544 = load i32, ptr %p9543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9544, ptr %slot1794, align 8
  %v9545 = load i32, ptr %slot1794, align 8
  %op9546 = and i32 %v9545, 28
  store i32 %op9546, ptr %slot1795, align 8
  %v9547 = load i32, ptr %slot1795, align 8
  %cv9548 = zext i32 %v9547 to i64
  %cond9549 = icmp ne i64 %cv9548, 0
  br i1 %cond9549, label %bb_rcslotrole2843, label %bb_rcslotowner2843
bb_rcslotrole2843:
  %v9550 = load i64, ptr %slot70, align 8
  store i64 %v9550, ptr %slot1796, align 8
  %v9551 = load i64, ptr %slot1793, align 8
  %p9552 = inttoptr i64 %v9551 to ptr
  %ld9553 = load i64, ptr %p9552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9553, ptr %slot1797, align 8
  %v9554 = load i64, ptr %slot1797, align 8
  %cmp9555 = icmp ne i64 %v9554, 0
  %cv9556 = zext i1 %cmp9555 to i32
  store i32 %cv9556, ptr %slot1798, align 8
  %v9557 = load i32, ptr %slot1798, align 8
  %cv9558 = zext i32 %v9557 to i64
  %cond9559 = icmp ne i64 %cv9558, 0
  br i1 %cond9559, label %bb_rcgnn2859, label %bb_rcgdone2859
bb_rcgnn2859:
  %v9560 = load i64, ptr %slot1797, align 8
  %op9561 = sub i64 %v9560, 16
  store i64 %op9561, ptr %slot1799, align 8
  %v9562 = load i64, ptr %slot1797, align 8
  %p9563 = inttoptr i64 %v9562 to ptr
  %rgep9564 = getelementptr i8, ptr %p9563, i64 -16
  %ld9565 = load i64, ptr %rgep9564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9565, ptr %slot1800, align 8
  %v9566 = load i64, ptr %slot1800, align 8
  %op9567 = and i64 %v9566, 4611686018427387906
  store i64 %op9567, ptr %slot1801, align 8
  %v9568 = load i64, ptr %slot1801, align 8
  %cmp9569 = icmp ne i64 %v9568, 0
  %cv9570 = zext i1 %cmp9569 to i32
  store i32 %cv9570, ptr %slot1802, align 8
  %v9571 = load i32, ptr %slot1802, align 8
  %cv9572 = zext i32 %v9571 to i64
  %cond9573 = icmp ne i64 %cv9572, 0
  br i1 %cond9573, label %bb_rcgclear2859, label %bb_rcgcounted2859
bb_rcgcounted2859:
  %v9574 = load i64, ptr %slot1797, align 8
  %op9575 = sub i64 %v9574, 24
  store i64 %op9575, ptr %slot1803, align 8
  %v9576 = load i64, ptr %slot1797, align 8
  %p9577 = inttoptr i64 %v9576 to ptr
  %rgep9578 = getelementptr i8, ptr %p9577, i64 -24
  %ld9579 = load i64, ptr %rgep9578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9579, ptr %slot1804, align 8
  %v9580 = load i64, ptr %slot1804, align 8
  %op9581 = sub i64 %v9580, 1
  store i64 %op9581, ptr %slot1805, align 8
  %v9582 = load i64, ptr %slot1805, align 8
  %cmp9583 = icmp eq i64 %v9582, 0
  %cv9584 = zext i1 %cmp9583 to i32
  store i32 %cv9584, ptr %slot1806, align 8
  %v9585 = load i32, ptr %slot1806, align 8
  %cv9586 = zext i32 %v9585 to i64
  %cond9587 = icmp ne i64 %cv9586, 0
  br i1 %cond9587, label %bb_rcglast2859, label %bb_rcgdec2859
bb_rcglast2859:
  %v9588 = load i64, ptr %slot1797, align 8
  %op9589 = sub i64 %v9588, 32
  store i64 %op9589, ptr %slot1807, align 8
  %v9590 = load i64, ptr %slot1797, align 8
  %p9591 = inttoptr i64 %v9590 to ptr
  %rgep9592 = getelementptr i8, ptr %p9591, i64 -32
  %ld9593 = load i64, ptr %rgep9592, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9593, ptr %slot1808, align 8
  %v9594 = load i64, ptr %slot1808, align 8
  %cmp9595 = icmp ne i64 %v9594, 0
  %cv9596 = zext i1 %cmp9595 to i32
  store i32 %cv9596, ptr %slot1809, align 8
  %v9597 = load i32, ptr %slot1809, align 8
  %cv9598 = zext i32 %v9597 to i64
  %cond9599 = icmp ne i64 %cv9598, 0
  br i1 %cond9599, label %bb_rcgdec2859, label %bb_rcgslow2859
bb_rcgslow2859:
  %v9600 = load i64, ptr %slot1796, align 8
  %v9601 = load i64, ptr %slot1793, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v9600, i64 %v9601) nomerge, !dbg !208
  br label %bb_rcgdone2859
bb_rcgdec2859:
  %v9602 = load i64, ptr %slot1805, align 8
  %v9603 = load i64, ptr %slot1797, align 8
  %p9604 = inttoptr i64 %v9603 to ptr
  %rgep9605 = getelementptr i8, ptr %p9604, i64 -24
  store i64 %v9602, ptr %rgep9605, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2859
bb_rcgclear2859:
  %v9606 = load i64, ptr %slot1793, align 8
  %p9607 = inttoptr i64 %v9606 to ptr
  store i64 0, ptr %p9607, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2859
bb_rcgdone2859:
  br label %bb_rcslotdone2843
bb_rcslotowner2843:
  %v9608 = load i64, ptr %slot70, align 8
  store i64 %v9608, ptr %slot1810, align 8
  %v9609 = load i64, ptr %slot1793, align 8
  %p9610 = inttoptr i64 %v9609 to ptr
  %ld9611 = load i64, ptr %p9610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9611, ptr %slot1811, align 8
  %v9612 = load i64, ptr %slot1811, align 8
  %cmp9613 = icmp ne i64 %v9612, 0
  %cv9614 = zext i1 %cmp9613 to i32
  store i32 %cv9614, ptr %slot1812, align 8
  %v9615 = load i32, ptr %slot1812, align 8
  %cv9616 = zext i32 %v9615 to i64
  %cond9617 = icmp ne i64 %cv9616, 0
  br i1 %cond9617, label %bb_rcgnn2874, label %bb_rcgdone2874
bb_rcgnn2874:
  %v9618 = load i64, ptr %slot1811, align 8
  %op9619 = sub i64 %v9618, 16
  store i64 %op9619, ptr %slot1813, align 8
  %v9620 = load i64, ptr %slot1811, align 8
  %p9621 = inttoptr i64 %v9620 to ptr
  %rgep9622 = getelementptr i8, ptr %p9621, i64 -16
  %ld9623 = load i64, ptr %rgep9622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9623, ptr %slot1814, align 8
  %v9624 = load i64, ptr %slot1814, align 8
  %op9625 = and i64 %v9624, 4611686018427387906
  store i64 %op9625, ptr %slot1815, align 8
  %v9626 = load i64, ptr %slot1815, align 8
  %cmp9627 = icmp ne i64 %v9626, 0
  %cv9628 = zext i1 %cmp9627 to i32
  store i32 %cv9628, ptr %slot1816, align 8
  %v9629 = load i32, ptr %slot1816, align 8
  %cv9630 = zext i32 %v9629 to i64
  %cond9631 = icmp ne i64 %cv9630, 0
  br i1 %cond9631, label %bb_rcgclear2874, label %bb_rcgcounted2874
bb_rcgcounted2874:
  %v9632 = load i64, ptr %slot1811, align 8
  %op9633 = sub i64 %v9632, 32
  store i64 %op9633, ptr %slot1817, align 8
  %v9634 = load i64, ptr %slot1811, align 8
  %p9635 = inttoptr i64 %v9634 to ptr
  %rgep9636 = getelementptr i8, ptr %p9635, i64 -32
  %ld9637 = load i64, ptr %rgep9636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9637, ptr %slot1818, align 8
  %v9638 = load i64, ptr %slot1818, align 8
  %op9639 = sub i64 %v9638, 1
  store i64 %op9639, ptr %slot1819, align 8
  %v9640 = load i64, ptr %slot1819, align 8
  %cmp9641 = icmp eq i64 %v9640, 0
  %cv9642 = zext i1 %cmp9641 to i32
  store i32 %cv9642, ptr %slot1820, align 8
  %v9643 = load i32, ptr %slot1820, align 8
  %cv9644 = zext i32 %v9643 to i64
  %cond9645 = icmp ne i64 %cv9644, 0
  br i1 %cond9645, label %bb_rcglast2874, label %bb_rcgdec2874
bb_rcglast2874:
  %v9646 = load i64, ptr %slot1811, align 8
  %op9647 = sub i64 %v9646, 24
  store i64 %op9647, ptr %slot1821, align 8
  %v9648 = load i64, ptr %slot1811, align 8
  %p9649 = inttoptr i64 %v9648 to ptr
  %rgep9650 = getelementptr i8, ptr %p9649, i64 -24
  %ld9651 = load i64, ptr %rgep9650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9651, ptr %slot1822, align 8
  %v9652 = load i64, ptr %slot1822, align 8
  %cmp9653 = icmp ne i64 %v9652, 0
  %cv9654 = zext i1 %cmp9653 to i32
  store i32 %cv9654, ptr %slot1823, align 8
  %v9655 = load i32, ptr %slot1823, align 8
  %cv9656 = zext i32 %v9655 to i64
  %cond9657 = icmp ne i64 %cv9656, 0
  br i1 %cond9657, label %bb_rcgdec2874, label %bb_rcgslow2874
bb_rcgslow2874:
  %v9658 = load i64, ptr %slot1810, align 8
  %v9659 = load i64, ptr %slot1793, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v9658, i64 %v9659) nomerge, !dbg !208
  br label %bb_rcgdone2874
bb_rcgdec2874:
  %v9660 = load i64, ptr %slot1819, align 8
  %v9661 = load i64, ptr %slot1811, align 8
  %p9662 = inttoptr i64 %v9661 to ptr
  %rgep9663 = getelementptr i8, ptr %p9662, i64 -32
  store i64 %v9660, ptr %rgep9663, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2874
bb_rcgclear2874:
  %v9664 = load i64, ptr %slot1793, align 8
  %p9665 = inttoptr i64 %v9664 to ptr
  store i64 0, ptr %p9665, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2874
bb_rcgdone2874:
  br label %bb_rcslotdone2843
bb_rcslotdone2843:
  %v9666 = load i64, ptr %slot7, align 8
  %p9667 = inttoptr i64 %v9666 to ptr
  %ld9668 = load i32, ptr %p9667, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9668, ptr %slot1824, align 8
  %v9669 = load i32, ptr %slot1824, align 8
  %cv9670 = zext i32 %v9669 to i64
  %cond9671 = icmp ne i64 %cv9670, 0
  br i1 %cond9671, label %bb_rcslotdrop2880, label %bb_rcslotdone2880
bb_rcslotdrop2880:
  %v9672 = load i64, ptr %slot7, align 8
  %p9673 = inttoptr i64 %v9672 to ptr
  store i32 0, ptr %p9673, align 4, !alias.scope !3, !noalias !4
  %v9674 = load i64, ptr %slot42, align 8
  store i64 %v9674, ptr %slot1825, align 8
  %v9675 = load i64, ptr %slot8, align 8
  %p9676 = inttoptr i64 %v9675 to ptr
  %ld9677 = load i32, ptr %p9676, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9677, ptr %slot1826, align 8
  %v9678 = load i32, ptr %slot1826, align 8
  %op9679 = and i32 %v9678, 28
  store i32 %op9679, ptr %slot1827, align 8
  %v9680 = load i32, ptr %slot1827, align 8
  %cv9681 = zext i32 %v9680 to i64
  %cond9682 = icmp ne i64 %cv9681, 0
  br i1 %cond9682, label %bb_rcslotrole2880, label %bb_rcslotowner2880
bb_rcslotrole2880:
  %v9683 = load i64, ptr %slot70, align 8
  store i64 %v9683, ptr %slot1828, align 8
  %v9684 = load i64, ptr %slot1828, align 8
  %v9685 = load i64, ptr %slot1825, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v9684, i64 %v9685) nomerge, !dbg !208
  br label %bb_rcslotdone2880
bb_rcslotowner2880:
  %v9686 = load i64, ptr %slot70, align 8
  store i64 %v9686, ptr %slot1829, align 8
  %v9687 = load i64, ptr %slot1829, align 8
  %v9688 = load i64, ptr %slot1825, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v9687, i64 %v9688) nomerge, !dbg !208
  br label %bb_rcslotdone2880
bb_rcslotdone2880:
  %v9689 = load i64, ptr %slot1761, align 8
  ret i64 %v9689
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_c00e440f315419997e6162b5571fda77267d1f58d08a0b2342c382685e685043 = external global i8, align 8
@myl_native_list_header_type = external global i8, align 8
@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8
@myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda = external global i8, align 8
@myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64, i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64, i64)
declare i32 @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_take(i64, i64, i64, i32)
declare void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64, i64)
declare i32 @myl_t_c0235a2002b47316e7055cdcc9950d30a5168fa64698c21e07a3f1d907870193_rcg_list_append(i64, i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11}
!11 = distinct !{!11, !0, !"element 88v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9f8b01b4a14ac178a8d4478a45b00281882a104c69ea880428c8a220fcfbc195", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9f8b01b4a14ac178a8d4478a45b00281882a104c69ea880428c8a220fcfbc195", linkageName: "myl_f_9f8b01b4a14ac178a8d4478a45b00281882a104c69ea880428c8a220fcfbc195", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3821863575376577216, i64 0, !"myl_f_9f8b01b4a14ac178a8d4478a45b00281882a104c69ea880428c8a220fcfbc195"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!116 = !DILocation(line: 11, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!120 = !DILocation(line: 16, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!126 = !DILocation(line: 20, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!128 = !DILocation(line: 21, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!130 = !DILocation(line: 30, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!132 = !DILocation(line: 31, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!134 = !DILocation(line: 39, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!136 = !DILocation(line: 41, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!138 = !DILocation(line: 44, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!140 = !DILocation(line: 45, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!142 = !DILocation(line: 59, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!144 = !DILocation(line: 62, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!146 = !DILocation(line: 71, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!148 = !DILocation(line: 74, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!150 = !DILocation(line: 76, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!152 = !DILocation(line: 77, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647183)
!154 = !DILocation(line: 81, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647215)
!156 = !DILocation(line: 85, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647239)
!158 = !DILocation(line: 88, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647255)
!160 = !DILocation(line: 90, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647279)
!162 = !DILocation(line: 93, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647295)
!164 = !DILocation(line: 95, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!166 = !DILocation(line: 96, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647311)
!168 = !DILocation(line: 97, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647319)
!170 = !DILocation(line: 98, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647351)
!172 = !DILocation(line: 102, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647367)
!174 = !DILocation(line: 104, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647375)
!176 = !DILocation(line: 105, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647439)
!178 = !DILocation(line: 113, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647455)
!180 = !DILocation(line: 115, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647487)
!182 = !DILocation(line: 119, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647495)
!184 = !DILocation(line: 120, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647519)
!186 = !DILocation(line: 123, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647527)
!188 = !DILocation(line: 124, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647535)
!190 = !DILocation(line: 125, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647543)
!192 = !DILocation(line: 126, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647559)
!194 = !DILocation(line: 128, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647567)
!196 = !DILocation(line: 129, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647575)
!198 = !DILocation(line: 130, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647591)
!200 = !DILocation(line: 132, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647647)
!202 = !DILocation(line: 139, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647663)
!204 = !DILocation(line: 141, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647703)
!206 = !DILocation(line: 146, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647727)
!208 = !DILocation(line: 149, column: 0, scope: !209)
