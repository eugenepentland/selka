target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_157bc77b45a4ecb850aa96ee9697e989f0c07c64274d2cc18365bc6001dfc2f0(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v195 = load i64, ptr %slot1, align 8
  %op196 = add i64 %v195, 32
  store i64 %op196, ptr %slot4, align 8
  %mem197 = alloca i8, i64 16, align 8
  %ptr198 = ptrtoint ptr %mem197 to i64
  store i64 %ptr198, ptr %slot5, align 8
  %mem199 = alloca i8, i64 8, align 8
  %ptr200 = ptrtoint ptr %mem199 to i64
  store i64 %ptr200, ptr %slot6, align 8
  %mem201 = alloca i8, i64 8, align 8
  %ptr202 = ptrtoint ptr %mem201 to i64
  store i64 %ptr202, ptr %slot7, align 8
  %mem203 = alloca i8, i64 8, align 8
  %ptr204 = ptrtoint ptr %mem203 to i64
  store i64 %ptr204, ptr %slot8, align 8
  %mem205 = alloca i8, i64 8, align 8
  %ptr206 = ptrtoint ptr %mem205 to i64
  store i64 %ptr206, ptr %slot9, align 8
  %mem207 = alloca i8, i64 8, align 8
  %ptr208 = ptrtoint ptr %mem207 to i64
  store i64 %ptr208, ptr %slot10, align 8
  %mem209 = alloca i8, i64 16, align 8
  %ptr210 = ptrtoint ptr %mem209 to i64
  store i64 %ptr210, ptr %slot11, align 8
  %mem211 = alloca i8, i64 8, align 8
  %ptr212 = ptrtoint ptr %mem211 to i64
  store i64 %ptr212, ptr %slot12, align 8
  %mem213 = alloca i8, i64 16, align 8
  %ptr214 = ptrtoint ptr %mem213 to i64
  store i64 %ptr214, ptr %slot13, align 8
  %mem215 = alloca i8, i64 8, align 8
  %ptr216 = ptrtoint ptr %mem215 to i64
  store i64 %ptr216, ptr %slot14, align 8
  %mem217 = alloca i8, i64 8, align 8
  %ptr218 = ptrtoint ptr %mem217 to i64
  store i64 %ptr218, ptr %slot15, align 8
  %mem219 = alloca i8, i64 8, align 8
  %ptr220 = ptrtoint ptr %mem219 to i64
  store i64 %ptr220, ptr %slot16, align 8
  %mem221 = alloca i8, i64 8, align 8
  %ptr222 = ptrtoint ptr %mem221 to i64
  store i64 %ptr222, ptr %slot17, align 8
  %mem223 = alloca i8, i64 8, align 8
  %ptr224 = ptrtoint ptr %mem223 to i64
  store i64 %ptr224, ptr %slot18, align 8
  %mem225 = alloca i8, i64 16, align 8
  %ptr226 = ptrtoint ptr %mem225 to i64
  store i64 %ptr226, ptr %slot19, align 8
  %mem227 = alloca i8, i64 16, align 8
  %ptr228 = ptrtoint ptr %mem227 to i64
  store i64 %ptr228, ptr %slot20, align 8
  %mem229 = alloca i8, i64 8, align 8
  %ptr230 = ptrtoint ptr %mem229 to i64
  store i64 %ptr230, ptr %slot21, align 8
  %mem231 = alloca i8, i64 16, align 8
  %ptr232 = ptrtoint ptr %mem231 to i64
  store i64 %ptr232, ptr %slot22, align 8
  %v233 = load i64, ptr %slot2, align 8
  %v234 = load i64, ptr %slot14, align 8
  %p235 = inttoptr i64 %v234 to ptr
  store i64 %v233, ptr %p235, align 8, !alias.scope !3, !noalias !4
  %v236 = load i64, ptr %slot3, align 8
  %v237 = load i64, ptr %slot15, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot1, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %call241 = call ptr @myl_qbe_heap(ptr %p240) nomerge, !dbg !110
  %calladdr242 = ptrtoint ptr %call241 to i64
  store i64 %calladdr242, ptr %slot23, align 8
  %v243 = load i64, ptr %slot1, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %call245 = call i64 @myl_qbe_region_mark(ptr %p244) nomerge, !dbg !110
  store i64 %call245, ptr %slot24, align 8
  %v246 = load i64, ptr %slot6, align 8
  %p247 = inttoptr i64 %v246 to ptr
  store i32 0, ptr %p247, align 4, !alias.scope !3, !noalias !4
  %v248 = load i64, ptr %slot7, align 8
  %p249 = inttoptr i64 %v248 to ptr
  store i32 0, ptr %p249, align 4, !alias.scope !3, !noalias !4
  %v250 = load i64, ptr %slot8, align 8
  %p251 = inttoptr i64 %v250 to ptr
  store i32 0, ptr %p251, align 4, !alias.scope !3, !noalias !4
  %v252 = load i64, ptr %slot9, align 8
  %p253 = inttoptr i64 %v252 to ptr
  store i32 0, ptr %p253, align 4, !alias.scope !3, !noalias !4
  %v254 = load i64, ptr %slot10, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i32 0, ptr %p255, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v256 = load i64, ptr %slot15, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot25, align 8
  %v259 = load i64, ptr %slot25, align 8
  %v260 = load i64, ptr %slot16, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i64 %v259, ptr %p261, align 8, !alias.scope !3, !noalias !4
  %v262 = load i64, ptr %slot16, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %ld264 = load i64, ptr %p263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld264, ptr %slot26, align 8
  %v265 = load i64, ptr %slot26, align 8
  %op266 = add i64 %v265, 0
  store i64 %op266, ptr %slot27, align 8
  %v267 = load i64, ptr %slot27, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %ld269 = load i64, ptr %p268, align 8
  store i64 %ld269, ptr %slot28, align 8
  %v270 = load i64, ptr %slot28, align 8
  %v271 = load i64, ptr %slot16, align 8
  %p272 = inttoptr i64 %v271 to ptr
  store i64 %v270, ptr %p272, align 8, !alias.scope !3, !noalias !4
  %v273 = load i64, ptr %slot14, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld275, ptr %slot29, align 8
  %v276 = load i64, ptr %slot29, align 8
  %v277 = load i64, ptr %slot17, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i64 %v276, ptr %p278, align 8, !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot17, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i64, ptr %p280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld281, ptr %slot30, align 8
  %v282 = load i64, ptr %slot30, align 8
  %op283 = add i64 %v282, 0
  store i64 %op283, ptr %slot31, align 8
  %v284 = load i64, ptr %slot31, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !4, !noalias !3
  store i64 %ld286, ptr %slot32, align 8
  %v287 = load i64, ptr %slot32, align 8
  %v288 = load i64, ptr %slot17, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i64 %v287, ptr %p289, align 8, !alias.scope !3, !noalias !4
  %v290 = load i64, ptr %slot17, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i64, ptr %p291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld292, ptr %slot33, align 8
  %v293 = load i64, ptr %slot16, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot34, align 8
  %v296 = load i64, ptr %slot34, align 8
  %v297 = load i64, ptr %slot33, align 8
  %cmp298 = icmp slt i64 %v296, %v297
  %cv299 = zext i1 %cmp298 to i64
  store i64 %cv299, ptr %slot35, align 8
  %v300 = load i64, ptr %slot35, align 8
  %v301 = load i64, ptr %slot16, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i64 %v300, ptr %p302, align 8, !alias.scope !3, !noalias !4
  %v303 = load i64, ptr %slot16, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot36, align 8
  %v306 = load i64, ptr %slot36, align 8
  %cond307 = icmp ne i64 %v306, 0
  br i1 %cond307, label %bb_next12, label %bb_i9
bb_next12:
  %p308 = inttoptr i64 ptrtoint (ptr @myl_lit_1a69ccf47387ae009a008f5f1b7a2d308379629465792632f22bcb30afb3ab52 to i64) to ptr
  %ld309 = load i64, ptr %p308, align 8, !alias.scope !4, !noalias !3
  store i64 %ld309, ptr %slot37, align 8
  %v310 = load i64, ptr %slot37, align 8
  %v311 = load i64, ptr %slot16, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i64 %v310, ptr %p312, align 8, !alias.scope !3, !noalias !4
  %v313 = load i64, ptr %slot16, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld315, ptr %slot38, align 8
  %v316 = load i64, ptr %slot38, align 8
  %v317 = load i64, ptr %slot12, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i64 %v316, ptr %p318, align 8, !alias.scope !3, !noalias !4
  %v319 = load i64, ptr %slot12, align 8
  store i64 %v319, ptr %slot39, align 8
  %v320 = load i64, ptr %slot13, align 8
  store i64 %v320, ptr %slot40, align 8
  %v321 = load i64, ptr %slot39, align 8
  %v322 = load i64, ptr %slot40, align 8
  %p323 = inttoptr i64 %v321 to ptr
  %p324 = inttoptr i64 %v322 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p324, ptr %p323, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot9, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i32 2, ptr %p326, align 4, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot8, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i32 1, ptr %p328, align 4, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot11, align 8
  store i64 %v329, ptr %slot41, align 8
  %v330 = load i64, ptr %slot13, align 8
  store i64 %v330, ptr %slot42, align 8
  %v331 = load i64, ptr %slot42, align 8
  %v332 = load i64, ptr %slot41, align 8
  %p333 = inttoptr i64 %v331 to ptr
  %p334 = inttoptr i64 %v332 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p334, ptr %p333, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot7, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i32 2, ptr %p336, align 4, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot9, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i32, ptr %p338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld339, ptr %slot43, align 8
  %v340 = load i32, ptr %slot43, align 8
  %v341 = load i64, ptr %slot7, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i32 %v340, ptr %p342, align 4, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot8, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i32 0, ptr %p344, align 4, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot6, align 8
  %p346 = inttoptr i64 %v345 to ptr
  store i32 1, ptr %p346, align 4, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot41, align 8
  %p348 = inttoptr i64 %v347 to ptr
  %ld349 = load i64, ptr %p348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld349, ptr %slot44, align 8
  %v350 = load i64, ptr %slot44, align 8
  %v351 = load i64, ptr %slot16, align 8
  %p352 = inttoptr i64 %v351 to ptr
  store i64 %v350, ptr %p352, align 8, !alias.scope !3, !noalias !4
  %v353 = load i64, ptr %slot19, align 8
  store i64 %v353, ptr %slot45, align 8
  %v354 = load i64, ptr %slot45, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i64 0, ptr %p355, align 8, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot45, align 8
  %p358 = inttoptr i64 %v356 to ptr
  %gep359 = getelementptr i8, ptr %p358, i64 8
  %op357 = ptrtoint ptr %gep359 to i64
  store i64 %op357, ptr %slot46, align 8
  %v360 = load i64, ptr %slot46, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i64 0, ptr %p361, align 8, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot45, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i32 1, ptr %p363, align 4, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot10, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i32 1, ptr %p365, align 4, !alias.scope !3, !noalias !4
  %v366 = load i64, ptr %slot16, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot47, align 8
  %v369 = load i64, ptr %slot47, align 8
  %v370 = load i64, ptr %slot12, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i64 %v369, ptr %p371, align 8, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot12, align 8
  store i64 %v372, ptr %slot48, align 8
  %v373 = load i64, ptr %slot45, align 8
  %p375 = inttoptr i64 %v373 to ptr
  %gep376 = getelementptr i8, ptr %p375, i64 8
  %op374 = ptrtoint ptr %gep376 to i64
  store i64 %op374, ptr %slot49, align 8
  %v377 = load i64, ptr %slot24, align 8
  store i64 %v377, ptr %slot50, align 8
  %v378 = load i64, ptr %slot16, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %ld380 = load i64, ptr %p379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld380, ptr %slot51, align 8
  %v381 = load i64, ptr %slot51, align 8
  %v382 = load i64, ptr %slot12, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i64 %v381, ptr %p383, align 8, !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot12, align 8
  store i64 %v384, ptr %slot52, align 8
  %v385 = load i64, ptr %slot13, align 8
  store i64 %v385, ptr %slot53, align 8
  %v386 = load i64, ptr %slot24, align 8
  store i64 %v386, ptr %slot54, align 8
  %v387 = load i64, ptr %slot52, align 8
  %p389 = inttoptr i64 %v387 to ptr
  %gep390 = getelementptr i8, ptr %p389, i64 0
  %op388 = ptrtoint ptr %gep390 to i64
  store i64 %op388, ptr %slot55, align 8
  %v391 = load i64, ptr %slot55, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i64, ptr %p392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld393, ptr %slot56, align 8
  %v394 = load i64, ptr %slot56, align 8
  %cmp395 = icmp ne i64 %v394, 0
  %cv396 = zext i1 %cmp395 to i32
  store i32 %cv396, ptr %slot57, align 8
  %v397 = load i32, ptr %slot57, align 8
  %cv398 = zext i32 %v397 to i64
  %cond399 = icmp ne i64 %cv398, 0
  br i1 %cond399, label %bb_rcmoveheader43, label %bb_rcmovenext43
bb_rcmoveheader43:
  %v400 = load i64, ptr %slot56, align 8
  %op401 = sub i64 %v400, 16
  store i64 %op401, ptr %slot58, align 8
  %v402 = load i64, ptr %slot56, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %rgep404 = getelementptr i8, ptr %p403, i64 -16
  %ld405 = load i64, ptr %rgep404, align 8, !alias.scope !9, !noalias !10
  store i64 %ld405, ptr %slot59, align 8
  %v406 = load i64, ptr %slot59, align 8
  %op407 = and i64 %v406, 5764607523034234881
  store i64 %op407, ptr %slot60, align 8
  %v408 = load i64, ptr %slot60, align 8
  %cmp409 = icmp ne i64 %v408, 0
  %cv410 = zext i1 %cmp409 to i32
  store i32 %cv410, ptr %slot61, align 8
  %v411 = load i32, ptr %slot61, align 8
  %cv412 = zext i32 %v411 to i64
  %cond413 = icmp ne i64 %cv412, 0
  br i1 %cond413, label %bb_rcmoveslow40, label %bb_rcmovenext43
bb_rcmovenext43:
  %v414 = load i64, ptr %slot52, align 8
  %v415 = load i64, ptr %slot53, align 8
  %p416 = inttoptr i64 %v414 to ptr
  %p417 = inttoptr i64 %v415 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p417, ptr %p416, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v418 = load i64, ptr %slot52, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i64 0, ptr %p419, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved40
bb_rcmoveslow40:
  %v420 = load i64, ptr %slot23, align 8
  %v421 = load i64, ptr %slot53, align 8
  %v422 = load i64, ptr %slot52, align 8
  %v423 = load i64, ptr %slot54, align 8
  %cv424 = trunc i64 %v423 to i32
  %call425 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v420, i64 %v421, i64 %v422, i32 %cv424) nomerge, !dbg !112
  store i32 %call425, ptr %slot62, align 8
  %v426 = load i32, ptr %slot62, align 8
  %cv427 = zext i32 %v426 to i64
  %cond428 = icmp ne i64 %cv427, 0
  br i1 %cond428, label %bb_rcsuccess50, label %bb_rcfailure50
bb_rcfailure50:
  %v429 = load i64, ptr %slot23, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %call431 = call i32 @myl_rc_take_failure(ptr %p430) nomerge, !dbg !112
  store i32 %call431, ptr %slot63, align 8
  %v432 = load i64, ptr %slot1, align 8
  %p433 = inttoptr i64 %v432 to ptr
  %v434 = load i32, ptr %slot63, align 8
  %call435 = call i32 @myl_qbe_rc_status(ptr %p433, i32 %v434) nomerge, !dbg !112
  store i32 %call435, ptr %slot64, align 8
  br label %bb_failure
bb_rcsuccess50:
  br label %bb_rcmoved40
bb_rcmoved40:
  %v436 = load i64, ptr %slot6, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i32 0, ptr %p437, align 4, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot9, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i32 2, ptr %p439, align 4, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot8, align 8
  %p441 = inttoptr i64 %v440 to ptr
  store i32 1, ptr %p441, align 4, !alias.scope !3, !noalias !4
  %v442 = load i64, ptr %slot13, align 8
  store i64 %v442, ptr %slot65, align 8
  %v443 = load i64, ptr %slot65, align 8
  %v444 = load i64, ptr %slot49, align 8
  %p445 = inttoptr i64 %v443 to ptr
  %p446 = inttoptr i64 %v444 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p446, ptr %p445, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot8, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i32 0, ptr %p448, align 4, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot45, align 8
  %v450 = load i64, ptr %slot16, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 %v449, ptr %p451, align 8, !alias.scope !3, !noalias !4
  %p452 = inttoptr i64 ptrtoint (ptr @myl_f_157bc77b45a4ecb850aa96ee9697e989f0c07c64274d2cc18365bc6001dfc2f0_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p452, i64 7) "call-inline-cost"="0", !dbg !112
  %v453 = load i64, ptr %slot16, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %ld455 = load i64, ptr %p454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld455, ptr %slot66, align 8
  %v456 = load i64, ptr %slot11, align 8
  store i64 %v456, ptr %slot67, align 8
  %v457 = load i64, ptr %slot66, align 8
  %v458 = load i64, ptr %slot67, align 8
  %p459 = inttoptr i64 %v457 to ptr
  %p460 = inttoptr i64 %v458 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p460, ptr %p459, i64 16, i1 false)
  %v461 = load i64, ptr %slot7, align 8
  %p462 = inttoptr i64 %v461 to ptr
  store i32 2, ptr %p462, align 4, !alias.scope !3, !noalias !4
  %v463 = load i64, ptr %slot6, align 8
  %p464 = inttoptr i64 %v463 to ptr
  store i32 1, ptr %p464, align 4, !alias.scope !3, !noalias !4
  %v465 = load i64, ptr %slot67, align 8
  %v466 = load i64, ptr %slot16, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i64 %v465, ptr %p467, align 8, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot16, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %ld470 = load i64, ptr %p469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld470, ptr %slot68, align 8
  %v471 = load i64, ptr %slot16, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld473, ptr %slot69, align 8
  %v474 = load i64, ptr %slot13, align 8
  store i64 %v474, ptr %slot70, align 8
  %v475 = load i64, ptr %slot24, align 8
  store i64 %v475, ptr %slot71, align 8
  %v476 = load i64, ptr %slot23, align 8
  %v477 = load i64, ptr %slot70, align 8
  %v478 = load i64, ptr %slot69, align 8
  %v479 = load i64, ptr %slot71, align 8
  %cv480 = trunc i64 %v479 to i32
  %call481 = call i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64 %v476, i64 %v477, i64 %v478, i32 %cv480) nomerge, !dbg !114
  store i32 %call481, ptr %slot72, align 8
  %v482 = load i32, ptr %slot72, align 8
  %cv483 = zext i32 %v482 to i64
  %cond484 = icmp ne i64 %cv483, 0
  br i1 %cond484, label %bb_rcsuccess67, label %bb_rcfailure67
bb_rcfailure67:
  %v485 = load i64, ptr %slot23, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %call487 = call i32 @myl_rc_take_failure(ptr %p486) nomerge, !dbg !114
  store i32 %call487, ptr %slot73, align 8
  %v488 = load i64, ptr %slot1, align 8
  %p489 = inttoptr i64 %v488 to ptr
  %v490 = load i32, ptr %slot73, align 8
  %call491 = call i32 @myl_qbe_rc_status(ptr %p489, i32 %v490) nomerge, !dbg !114
  store i32 %call491, ptr %slot74, align 8
  br label %bb_failure
bb_rcsuccess67:
  %v492 = load i64, ptr %slot6, align 8
  %p493 = inttoptr i64 %v492 to ptr
  store i32 0, ptr %p493, align 4, !alias.scope !3, !noalias !4
  %v494 = load i64, ptr %slot9, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i32 2, ptr %p495, align 4, !alias.scope !3, !noalias !4
  %v496 = load i64, ptr %slot8, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i32 1, ptr %p497, align 4, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot13, align 8
  store i64 %v498, ptr %slot75, align 8
  %v499 = load i64, ptr %slot8, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i32 0, ptr %p500, align 4, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot6, align 8
  %p502 = inttoptr i64 %v501 to ptr
  %ld503 = load i32, ptr %p502, align 4, !alias.scope !3, !noalias !4
  store i32 %ld503, ptr %slot76, align 8
  %v504 = load i32, ptr %slot76, align 8
  %cv505 = zext i32 %v504 to i64
  %cond506 = icmp ne i64 %cv505, 0
  br i1 %cond506, label %bb_rcslotdrop77, label %bb_rcslotdone77
bb_rcslotdrop77:
  %v507 = load i64, ptr %slot6, align 8
  %p508 = inttoptr i64 %v507 to ptr
  store i32 0, ptr %p508, align 4, !alias.scope !3, !noalias !4
  %v509 = load i64, ptr %slot11, align 8
  store i64 %v509, ptr %slot77, align 8
  %v510 = load i64, ptr %slot7, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i32, ptr %p511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld512, ptr %slot78, align 8
  %v513 = load i32, ptr %slot78, align 8
  %op514 = and i32 %v513, 28
  store i32 %op514, ptr %slot79, align 8
  %v515 = load i32, ptr %slot79, align 8
  %cv516 = zext i32 %v515 to i64
  %cond517 = icmp ne i64 %cv516, 0
  br i1 %cond517, label %bb_rcslotrole77, label %bb_rcslotowner77
bb_rcslotrole77:
  %v518 = load i64, ptr %slot23, align 8
  store i64 %v518, ptr %slot80, align 8
  %v519 = load i64, ptr %slot80, align 8
  %v520 = load i64, ptr %slot77, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64 %v519, i64 %v520) nomerge, !dbg !114
  br label %bb_rcslotdone77
bb_rcslotowner77:
  %v521 = load i64, ptr %slot23, align 8
  store i64 %v521, ptr %slot81, align 8
  %v522 = load i64, ptr %slot81, align 8
  %v523 = load i64, ptr %slot77, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64 %v522, i64 %v523) nomerge, !dbg !114
  br label %bb_rcslotdone77
bb_rcslotdone77:
  %v524 = load i64, ptr %slot75, align 8
  %p525 = inttoptr i64 %v524 to ptr
  %ret526 = load { i64, i64 }, ptr %p525, align 8
  ret { i64, i64 } %ret526
bb_i9:
  %v527 = load i64, ptr %slot14, align 8
  %p528 = inttoptr i64 %v527 to ptr
  %ld529 = load i64, ptr %p528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld529, ptr %slot82, align 8
  %v530 = load i64, ptr %slot82, align 8
  %v531 = load i64, ptr %slot16, align 8
  %p532 = inttoptr i64 %v531 to ptr
  store i64 %v530, ptr %p532, align 8, !alias.scope !3, !noalias !4
  %v533 = load i64, ptr %slot16, align 8
  %p534 = inttoptr i64 %v533 to ptr
  %ld535 = load i64, ptr %p534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld535, ptr %slot83, align 8
  %v536 = load i64, ptr %slot83, align 8
  %op537 = add i64 %v536, 0
  store i64 %op537, ptr %slot84, align 8
  %v538 = load i64, ptr %slot84, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8
  store i64 %ld540, ptr %slot85, align 8
  %v541 = load i64, ptr %slot85, align 8
  %v542 = load i64, ptr %slot16, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i64 %v541, ptr %p543, align 8, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot17, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i64 0, ptr %p545, align 8, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot17, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %ld548 = load i64, ptr %p547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld548, ptr %slot86, align 8
  %v549 = load i64, ptr %slot16, align 8
  %p550 = inttoptr i64 %v549 to ptr
  %ld551 = load i64, ptr %p550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld551, ptr %slot87, align 8
  %v552 = load i64, ptr %slot87, align 8
  %v553 = load i64, ptr %slot86, align 8
  %cmp554 = icmp slt i64 %v552, %v553
  %cv555 = zext i1 %cmp554 to i64
  store i64 %cv555, ptr %slot88, align 8
  %v556 = load i64, ptr %slot88, align 8
  %v557 = load i64, ptr %slot16, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i64 %v556, ptr %p558, align 8, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot16, align 8
  %p560 = inttoptr i64 %v559 to ptr
  %ld561 = load i64, ptr %p560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld561, ptr %slot89, align 8
  %v562 = load i64, ptr %slot89, align 8
  %cond563 = icmp ne i64 %v562, 0
  br i1 %cond563, label %bb_next92, label %bb_i23
bb_next92:
  %v564 = load i64, ptr %slot15, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %ld566 = load i64, ptr %p565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld566, ptr %slot90, align 8
  %v567 = load i64, ptr %slot90, align 8
  %v568 = load i64, ptr %slot16, align 8
  %p569 = inttoptr i64 %v568 to ptr
  store i64 %v567, ptr %p569, align 8, !alias.scope !3, !noalias !4
  %v570 = load i64, ptr %slot16, align 8
  %p571 = inttoptr i64 %v570 to ptr
  %ld572 = load i64, ptr %p571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld572, ptr %slot91, align 8
  %v573 = load i64, ptr %slot91, align 8
  %op574 = add i64 %v573, 0
  store i64 %op574, ptr %slot92, align 8
  %v575 = load i64, ptr %slot92, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i64, ptr %p576, align 8
  store i64 %ld577, ptr %slot93, align 8
  %v578 = load i64, ptr %slot93, align 8
  %v579 = load i64, ptr %slot16, align 8
  %p580 = inttoptr i64 %v579 to ptr
  store i64 %v578, ptr %p580, align 8, !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot17, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 9223372036854775807, ptr %p582, align 8, !alias.scope !3, !noalias !4
  br label %bb_i18
bb_i18:
  %v583 = load i64, ptr %slot14, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot94, align 8
  %v586 = load i64, ptr %slot94, align 8
  %v587 = load i64, ptr %slot18, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i64 %v586, ptr %p588, align 8, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot18, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i64, ptr %p590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld591, ptr %slot95, align 8
  %v592 = load i64, ptr %slot95, align 8
  %op593 = add i64 %v592, 0
  store i64 %op593, ptr %slot96, align 8
  %v594 = load i64, ptr %slot96, align 8
  %p595 = inttoptr i64 %v594 to ptr
  %ld596 = load i64, ptr %p595, align 8, !alias.scope !4, !noalias !3
  store i64 %ld596, ptr %slot97, align 8
  %v597 = load i64, ptr %slot97, align 8
  %v598 = load i64, ptr %slot18, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i64 %v597, ptr %p599, align 8, !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot18, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %ld602 = load i64, ptr %p601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld602, ptr %slot98, align 8
  %v603 = load i64, ptr %slot17, align 8
  %p604 = inttoptr i64 %v603 to ptr
  %ld605 = load i64, ptr %p604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld605, ptr %slot99, align 8
  %v606 = load i64, ptr %slot99, align 8
  %v607 = load i64, ptr %slot98, align 8
  %ovpair609 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v606, i64 %v607)
  %op608 = extractvalue { i64, i1 } %ovpair609, 0
  %ov610 = extractvalue { i64, i1 } %ovpair609, 1
  store i64 %op608, ptr %slot100, align 8
  %v611 = load i64, ptr %slot99, align 8
  %v612 = load i64, ptr %slot100, align 8
  %op613 = xor i64 %v611, %v612
  store i64 %op613, ptr %slot101, align 8
  %v614 = load i64, ptr %slot98, align 8
  %v615 = load i64, ptr %slot100, align 8
  %op616 = xor i64 %v614, %v615
  store i64 %op616, ptr %slot102, align 8
  %v617 = load i64, ptr %slot101, align 8
  %v618 = load i64, ptr %slot102, align 8
  %op619 = and i64 %v617, %v618
  store i64 %op619, ptr %slot103, align 8
  %cv620 = zext i1 %ov610 to i64
  store i64 %cv620, ptr %slot104, align 8
  %v621 = load i64, ptr %slot104, align 8
  %cond622 = icmp ne i64 %v621, 0
  br i1 %cond622, label %bb_overflow102, label %bb_checked102
bb_overflow102:
  %v623 = load i64, ptr %slot1, align 8
  %p624 = inttoptr i64 %v623 to ptr
  %v625 = load i64, ptr %slot99, align 8
  %v626 = load i64, ptr %slot98, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p624, i64 0, i64 %v625, i64 %v626, i64 64) nomerge, !dbg !116
  unreachable
bb_checked102:
  %v627 = load i64, ptr %slot100, align 8
  %v628 = load i64, ptr %slot17, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i64 %v627, ptr %p629, align 8, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot17, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ld632 = load i64, ptr %p631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld632, ptr %slot105, align 8
  %v633 = load i64, ptr %slot16, align 8
  %p634 = inttoptr i64 %v633 to ptr
  %ld635 = load i64, ptr %p634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld635, ptr %slot106, align 8
  %v636 = load i64, ptr %slot106, align 8
  %v637 = load i64, ptr %slot105, align 8
  %cmp638 = icmp sgt i64 %v636, %v637
  %cv639 = zext i1 %cmp638 to i64
  store i64 %cv639, ptr %slot107, align 8
  %v640 = load i64, ptr %slot107, align 8
  %v641 = load i64, ptr %slot16, align 8
  %p642 = inttoptr i64 %v641 to ptr
  store i64 %v640, ptr %p642, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i23:
  %v643 = load i64, ptr %slot16, align 8
  %p644 = inttoptr i64 %v643 to ptr
  store i64 0, ptr %p644, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i24:
  %v645 = load i64, ptr %slot16, align 8
  %p646 = inttoptr i64 %v645 to ptr
  %ld647 = load i64, ptr %p646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld647, ptr %slot108, align 8
  %v648 = load i64, ptr %slot108, align 8
  %cond649 = icmp ne i64 %v648, 0
  br i1 %cond649, label %bb_next111, label %bb_i28
bb_next111:
  %p650 = inttoptr i64 ptrtoint (ptr @myl_lit_b41f42941b311c0582cd1a64f4d298d1f40e9e8d49ae3743d6188750dab9ffae to i64) to ptr
  %ld651 = load i64, ptr %p650, align 8, !alias.scope !4, !noalias !3
  store i64 %ld651, ptr %slot109, align 8
  %v652 = load i64, ptr %slot109, align 8
  %v653 = load i64, ptr %slot16, align 8
  %p654 = inttoptr i64 %v653 to ptr
  store i64 %v652, ptr %p654, align 8, !alias.scope !3, !noalias !4
  %v655 = load i64, ptr %slot16, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i64, ptr %p656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld657, ptr %slot110, align 8
  %v658 = load i64, ptr %slot110, align 8
  %v659 = load i64, ptr %slot12, align 8
  %p660 = inttoptr i64 %v659 to ptr
  store i64 %v658, ptr %p660, align 8, !alias.scope !3, !noalias !4
  %v661 = load i64, ptr %slot12, align 8
  store i64 %v661, ptr %slot111, align 8
  %v662 = load i64, ptr %slot13, align 8
  store i64 %v662, ptr %slot112, align 8
  %v663 = load i64, ptr %slot111, align 8
  %v664 = load i64, ptr %slot112, align 8
  %p665 = inttoptr i64 %v663 to ptr
  %p666 = inttoptr i64 %v664 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p666, ptr %p665, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot9, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 2, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot8, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i32 1, ptr %p670, align 4, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot11, align 8
  store i64 %v671, ptr %slot113, align 8
  %v672 = load i64, ptr %slot13, align 8
  store i64 %v672, ptr %slot114, align 8
  %v673 = load i64, ptr %slot114, align 8
  %v674 = load i64, ptr %slot113, align 8
  %p675 = inttoptr i64 %v673 to ptr
  %p676 = inttoptr i64 %v674 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p676, ptr %p675, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v677 = load i64, ptr %slot7, align 8
  %p678 = inttoptr i64 %v677 to ptr
  store i32 2, ptr %p678, align 4, !alias.scope !3, !noalias !4
  %v679 = load i64, ptr %slot9, align 8
  %p680 = inttoptr i64 %v679 to ptr
  %ld681 = load i32, ptr %p680, align 4, !alias.scope !3, !noalias !4
  store i32 %ld681, ptr %slot115, align 8
  %v682 = load i32, ptr %slot115, align 8
  %v683 = load i64, ptr %slot7, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i32 %v682, ptr %p684, align 4, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot8, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i32 0, ptr %p686, align 4, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot6, align 8
  %p688 = inttoptr i64 %v687 to ptr
  store i32 1, ptr %p688, align 4, !alias.scope !3, !noalias !4
  %v689 = load i64, ptr %slot113, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i64, ptr %p690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld691, ptr %slot116, align 8
  %v692 = load i64, ptr %slot116, align 8
  %v693 = load i64, ptr %slot16, align 8
  %p694 = inttoptr i64 %v693 to ptr
  store i64 %v692, ptr %p694, align 8, !alias.scope !3, !noalias !4
  %v695 = load i64, ptr %slot20, align 8
  store i64 %v695, ptr %slot117, align 8
  %v696 = load i64, ptr %slot117, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i64 0, ptr %p697, align 8, !alias.scope !3, !noalias !4
  %v698 = load i64, ptr %slot117, align 8
  %p700 = inttoptr i64 %v698 to ptr
  %gep701 = getelementptr i8, ptr %p700, i64 8
  %op699 = ptrtoint ptr %gep701 to i64
  store i64 %op699, ptr %slot118, align 8
  %v702 = load i64, ptr %slot118, align 8
  %p703 = inttoptr i64 %v702 to ptr
  store i64 0, ptr %p703, align 8, !alias.scope !3, !noalias !4
  %v704 = load i64, ptr %slot117, align 8
  %p705 = inttoptr i64 %v704 to ptr
  store i32 1, ptr %p705, align 4, !alias.scope !3, !noalias !4
  %v706 = load i64, ptr %slot10, align 8
  %p707 = inttoptr i64 %v706 to ptr
  store i32 1, ptr %p707, align 4, !alias.scope !3, !noalias !4
  %v708 = load i64, ptr %slot16, align 8
  %p709 = inttoptr i64 %v708 to ptr
  %ld710 = load i64, ptr %p709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld710, ptr %slot119, align 8
  %v711 = load i64, ptr %slot119, align 8
  %v712 = load i64, ptr %slot12, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i64 %v711, ptr %p713, align 8, !alias.scope !3, !noalias !4
  %v714 = load i64, ptr %slot12, align 8
  store i64 %v714, ptr %slot120, align 8
  %v715 = load i64, ptr %slot117, align 8
  %p717 = inttoptr i64 %v715 to ptr
  %gep718 = getelementptr i8, ptr %p717, i64 8
  %op716 = ptrtoint ptr %gep718 to i64
  store i64 %op716, ptr %slot121, align 8
  %v719 = load i64, ptr %slot24, align 8
  store i64 %v719, ptr %slot122, align 8
  %v720 = load i64, ptr %slot16, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %ld722 = load i64, ptr %p721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld722, ptr %slot123, align 8
  %v723 = load i64, ptr %slot123, align 8
  %v724 = load i64, ptr %slot12, align 8
  %p725 = inttoptr i64 %v724 to ptr
  store i64 %v723, ptr %p725, align 8, !alias.scope !3, !noalias !4
  %v726 = load i64, ptr %slot12, align 8
  store i64 %v726, ptr %slot124, align 8
  %v727 = load i64, ptr %slot13, align 8
  store i64 %v727, ptr %slot125, align 8
  %v728 = load i64, ptr %slot24, align 8
  store i64 %v728, ptr %slot126, align 8
  %v729 = load i64, ptr %slot124, align 8
  %p731 = inttoptr i64 %v729 to ptr
  %gep732 = getelementptr i8, ptr %p731, i64 0
  %op730 = ptrtoint ptr %gep732 to i64
  store i64 %op730, ptr %slot127, align 8
  %v733 = load i64, ptr %slot127, align 8
  %p734 = inttoptr i64 %v733 to ptr
  %ld735 = load i64, ptr %p734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld735, ptr %slot128, align 8
  %v736 = load i64, ptr %slot128, align 8
  %cmp737 = icmp ne i64 %v736, 0
  %cv738 = zext i1 %cmp737 to i32
  store i32 %cv738, ptr %slot129, align 8
  %v739 = load i32, ptr %slot129, align 8
  %cv740 = zext i32 %v739 to i64
  %cond741 = icmp ne i64 %cv740, 0
  br i1 %cond741, label %bb_rcmoveheader142, label %bb_rcmovenext142
bb_rcmoveheader142:
  %v742 = load i64, ptr %slot128, align 8
  %op743 = sub i64 %v742, 16
  store i64 %op743, ptr %slot130, align 8
  %v744 = load i64, ptr %slot128, align 8
  %p745 = inttoptr i64 %v744 to ptr
  %rgep746 = getelementptr i8, ptr %p745, i64 -16
  %ld747 = load i64, ptr %rgep746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld747, ptr %slot131, align 8
  %v748 = load i64, ptr %slot131, align 8
  %op749 = and i64 %v748, 5764607523034234881
  store i64 %op749, ptr %slot132, align 8
  %v750 = load i64, ptr %slot132, align 8
  %cmp751 = icmp ne i64 %v750, 0
  %cv752 = zext i1 %cmp751 to i32
  store i32 %cv752, ptr %slot133, align 8
  %v753 = load i32, ptr %slot133, align 8
  %cv754 = zext i32 %v753 to i64
  %cond755 = icmp ne i64 %cv754, 0
  br i1 %cond755, label %bb_rcmoveslow139, label %bb_rcmovenext142
bb_rcmovenext142:
  %v756 = load i64, ptr %slot124, align 8
  %v757 = load i64, ptr %slot125, align 8
  %p758 = inttoptr i64 %v756 to ptr
  %p759 = inttoptr i64 %v757 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p759, ptr %p758, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot124, align 8
  %p761 = inttoptr i64 %v760 to ptr
  store i64 0, ptr %p761, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved139
bb_rcmoveslow139:
  %v762 = load i64, ptr %slot23, align 8
  %v763 = load i64, ptr %slot125, align 8
  %v764 = load i64, ptr %slot124, align 8
  %v765 = load i64, ptr %slot126, align 8
  %cv766 = trunc i64 %v765 to i32
  %call767 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v762, i64 %v763, i64 %v764, i32 %cv766) nomerge, !dbg !118
  store i32 %call767, ptr %slot134, align 8
  %v768 = load i32, ptr %slot134, align 8
  %cv769 = zext i32 %v768 to i64
  %cond770 = icmp ne i64 %cv769, 0
  br i1 %cond770, label %bb_rcsuccess149, label %bb_rcfailure149
bb_rcfailure149:
  %v771 = load i64, ptr %slot23, align 8
  %p772 = inttoptr i64 %v771 to ptr
  %call773 = call i32 @myl_rc_take_failure(ptr %p772) nomerge, !dbg !118
  store i32 %call773, ptr %slot135, align 8
  %v774 = load i64, ptr %slot1, align 8
  %p775 = inttoptr i64 %v774 to ptr
  %v776 = load i32, ptr %slot135, align 8
  %call777 = call i32 @myl_qbe_rc_status(ptr %p775, i32 %v776) nomerge, !dbg !118
  store i32 %call777, ptr %slot136, align 8
  br label %bb_failure
bb_rcsuccess149:
  br label %bb_rcmoved139
bb_rcmoved139:
  %v778 = load i64, ptr %slot6, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i32 0, ptr %p779, align 4, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot9, align 8
  %p781 = inttoptr i64 %v780 to ptr
  store i32 2, ptr %p781, align 4, !alias.scope !3, !noalias !4
  %v782 = load i64, ptr %slot8, align 8
  %p783 = inttoptr i64 %v782 to ptr
  store i32 1, ptr %p783, align 4, !alias.scope !3, !noalias !4
  %v784 = load i64, ptr %slot13, align 8
  store i64 %v784, ptr %slot137, align 8
  %v785 = load i64, ptr %slot137, align 8
  %v786 = load i64, ptr %slot121, align 8
  %p787 = inttoptr i64 %v785 to ptr
  %p788 = inttoptr i64 %v786 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p788, ptr %p787, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v789 = load i64, ptr %slot8, align 8
  %p790 = inttoptr i64 %v789 to ptr
  store i32 0, ptr %p790, align 4, !alias.scope !3, !noalias !4
  %v791 = load i64, ptr %slot117, align 8
  %v792 = load i64, ptr %slot16, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i64 %v791, ptr %p793, align 8, !alias.scope !3, !noalias !4
  %p794 = inttoptr i64 ptrtoint (ptr @myl_f_157bc77b45a4ecb850aa96ee9697e989f0c07c64274d2cc18365bc6001dfc2f0_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p794, i64 26) "call-inline-cost"="0", !dbg !118
  %v795 = load i64, ptr %slot16, align 8
  %p796 = inttoptr i64 %v795 to ptr
  %ld797 = load i64, ptr %p796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld797, ptr %slot138, align 8
  %v798 = load i64, ptr %slot11, align 8
  store i64 %v798, ptr %slot139, align 8
  %v799 = load i64, ptr %slot138, align 8
  %v800 = load i64, ptr %slot139, align 8
  %p801 = inttoptr i64 %v799 to ptr
  %p802 = inttoptr i64 %v800 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p802, ptr %p801, i64 16, i1 false)
  %v803 = load i64, ptr %slot7, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i32 2, ptr %p804, align 4, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot6, align 8
  %p806 = inttoptr i64 %v805 to ptr
  store i32 1, ptr %p806, align 4, !alias.scope !3, !noalias !4
  %v807 = load i64, ptr %slot139, align 8
  %v808 = load i64, ptr %slot16, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i64 %v807, ptr %p809, align 8, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot16, align 8
  %p811 = inttoptr i64 %v810 to ptr
  %ld812 = load i64, ptr %p811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld812, ptr %slot140, align 8
  %v813 = load i64, ptr %slot16, align 8
  %p814 = inttoptr i64 %v813 to ptr
  %ld815 = load i64, ptr %p814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld815, ptr %slot141, align 8
  %v816 = load i64, ptr %slot13, align 8
  store i64 %v816, ptr %slot142, align 8
  %v817 = load i64, ptr %slot24, align 8
  store i64 %v817, ptr %slot143, align 8
  %v818 = load i64, ptr %slot23, align 8
  %v819 = load i64, ptr %slot142, align 8
  %v820 = load i64, ptr %slot141, align 8
  %v821 = load i64, ptr %slot143, align 8
  %cv822 = trunc i64 %v821 to i32
  %call823 = call i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64 %v818, i64 %v819, i64 %v820, i32 %cv822) nomerge, !dbg !120
  store i32 %call823, ptr %slot144, align 8
  %v824 = load i32, ptr %slot144, align 8
  %cv825 = zext i32 %v824 to i64
  %cond826 = icmp ne i64 %cv825, 0
  br i1 %cond826, label %bb_rcsuccess166, label %bb_rcfailure166
bb_rcfailure166:
  %v827 = load i64, ptr %slot23, align 8
  %p828 = inttoptr i64 %v827 to ptr
  %call829 = call i32 @myl_rc_take_failure(ptr %p828) nomerge, !dbg !120
  store i32 %call829, ptr %slot145, align 8
  %v830 = load i64, ptr %slot1, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %v832 = load i32, ptr %slot145, align 8
  %call833 = call i32 @myl_qbe_rc_status(ptr %p831, i32 %v832) nomerge, !dbg !120
  store i32 %call833, ptr %slot146, align 8
  br label %bb_failure
bb_rcsuccess166:
  %v834 = load i64, ptr %slot6, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i32 0, ptr %p835, align 4, !alias.scope !3, !noalias !4
  %v836 = load i64, ptr %slot9, align 8
  %p837 = inttoptr i64 %v836 to ptr
  store i32 2, ptr %p837, align 4, !alias.scope !3, !noalias !4
  %v838 = load i64, ptr %slot8, align 8
  %p839 = inttoptr i64 %v838 to ptr
  store i32 1, ptr %p839, align 4, !alias.scope !3, !noalias !4
  %v840 = load i64, ptr %slot13, align 8
  store i64 %v840, ptr %slot147, align 8
  %v841 = load i64, ptr %slot8, align 8
  %p842 = inttoptr i64 %v841 to ptr
  store i32 0, ptr %p842, align 4, !alias.scope !3, !noalias !4
  %v843 = load i64, ptr %slot6, align 8
  %p844 = inttoptr i64 %v843 to ptr
  %ld845 = load i32, ptr %p844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld845, ptr %slot148, align 8
  %v846 = load i32, ptr %slot148, align 8
  %cv847 = zext i32 %v846 to i64
  %cond848 = icmp ne i64 %cv847, 0
  br i1 %cond848, label %bb_rcslotdrop176, label %bb_rcslotdone176
bb_rcslotdrop176:
  %v849 = load i64, ptr %slot6, align 8
  %p850 = inttoptr i64 %v849 to ptr
  store i32 0, ptr %p850, align 4, !alias.scope !3, !noalias !4
  %v851 = load i64, ptr %slot11, align 8
  store i64 %v851, ptr %slot149, align 8
  %v852 = load i64, ptr %slot7, align 8
  %p853 = inttoptr i64 %v852 to ptr
  %ld854 = load i32, ptr %p853, align 4, !alias.scope !3, !noalias !4
  store i32 %ld854, ptr %slot150, align 8
  %v855 = load i32, ptr %slot150, align 8
  %op856 = and i32 %v855, 28
  store i32 %op856, ptr %slot151, align 8
  %v857 = load i32, ptr %slot151, align 8
  %cv858 = zext i32 %v857 to i64
  %cond859 = icmp ne i64 %cv858, 0
  br i1 %cond859, label %bb_rcslotrole176, label %bb_rcslotowner176
bb_rcslotrole176:
  %v860 = load i64, ptr %slot23, align 8
  store i64 %v860, ptr %slot152, align 8
  %v861 = load i64, ptr %slot152, align 8
  %v862 = load i64, ptr %slot149, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64 %v861, i64 %v862) nomerge, !dbg !120
  br label %bb_rcslotdone176
bb_rcslotowner176:
  %v863 = load i64, ptr %slot23, align 8
  store i64 %v863, ptr %slot153, align 8
  %v864 = load i64, ptr %slot153, align 8
  %v865 = load i64, ptr %slot149, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64 %v864, i64 %v865) nomerge, !dbg !120
  br label %bb_rcslotdone176
bb_rcslotdone176:
  %v866 = load i64, ptr %slot147, align 8
  %p867 = inttoptr i64 %v866 to ptr
  %ret868 = load { i64, i64 }, ptr %p867, align 8
  ret { i64, i64 } %ret868
bb_i28:
  %v869 = load i64, ptr %slot15, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %ld871 = load i64, ptr %p870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld871, ptr %slot154, align 8
  %v872 = load i64, ptr %slot154, align 8
  %v873 = load i64, ptr %slot16, align 8
  %p874 = inttoptr i64 %v873 to ptr
  store i64 %v872, ptr %p874, align 8, !alias.scope !3, !noalias !4
  %v875 = load i64, ptr %slot16, align 8
  %p876 = inttoptr i64 %v875 to ptr
  %ld877 = load i64, ptr %p876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld877, ptr %slot155, align 8
  %v878 = load i64, ptr %slot155, align 8
  %op879 = add i64 %v878, 0
  store i64 %op879, ptr %slot156, align 8
  %v880 = load i64, ptr %slot156, align 8
  %p881 = inttoptr i64 %v880 to ptr
  %ld882 = load i64, ptr %p881, align 8
  store i64 %ld882, ptr %slot157, align 8
  %v883 = load i64, ptr %slot157, align 8
  %v884 = load i64, ptr %slot16, align 8
  %p885 = inttoptr i64 %v884 to ptr
  store i64 %v883, ptr %p885, align 8, !alias.scope !3, !noalias !4
  %v886 = load i64, ptr %slot14, align 8
  %p887 = inttoptr i64 %v886 to ptr
  %ld888 = load i64, ptr %p887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld888, ptr %slot158, align 8
  %v889 = load i64, ptr %slot158, align 8
  %v890 = load i64, ptr %slot17, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i64 %v889, ptr %p891, align 8, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot17, align 8
  %p893 = inttoptr i64 %v892 to ptr
  %ld894 = load i64, ptr %p893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld894, ptr %slot159, align 8
  %v895 = load i64, ptr %slot159, align 8
  %op896 = add i64 %v895, 0
  store i64 %op896, ptr %slot160, align 8
  %v897 = load i64, ptr %slot160, align 8
  %p898 = inttoptr i64 %v897 to ptr
  %ld899 = load i64, ptr %p898, align 8, !alias.scope !4, !noalias !3
  store i64 %ld899, ptr %slot161, align 8
  %v900 = load i64, ptr %slot161, align 8
  %v901 = load i64, ptr %slot17, align 8
  %p902 = inttoptr i64 %v901 to ptr
  store i64 %v900, ptr %p902, align 8, !alias.scope !3, !noalias !4
  %v903 = load i64, ptr %slot17, align 8
  %p904 = inttoptr i64 %v903 to ptr
  %ld905 = load i64, ptr %p904, align 8, !alias.scope !3, !noalias !4
  store i64 %ld905, ptr %slot162, align 8
  %v906 = load i64, ptr %slot16, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %ld908 = load i64, ptr %p907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld908, ptr %slot163, align 8
  %v909 = load i64, ptr %slot163, align 8
  %v910 = load i64, ptr %slot162, align 8
  %ovpair912 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v909, i64 %v910)
  %op911 = extractvalue { i64, i1 } %ovpair912, 0
  %ov913 = extractvalue { i64, i1 } %ovpair912, 1
  store i64 %op911, ptr %slot164, align 8
  %v914 = load i64, ptr %slot163, align 8
  %v915 = load i64, ptr %slot162, align 8
  %op916 = xor i64 %v914, %v915
  store i64 %op916, ptr %slot165, align 8
  %v917 = load i64, ptr %slot163, align 8
  %v918 = load i64, ptr %slot164, align 8
  %op919 = xor i64 %v917, %v918
  store i64 %op919, ptr %slot166, align 8
  %v920 = load i64, ptr %slot165, align 8
  %v921 = load i64, ptr %slot166, align 8
  %op922 = and i64 %v920, %v921
  store i64 %op922, ptr %slot167, align 8
  %cv923 = zext i1 %ov913 to i64
  store i64 %cv923, ptr %slot168, align 8
  %v924 = load i64, ptr %slot168, align 8
  %cond925 = icmp ne i64 %v924, 0
  br i1 %cond925, label %bb_overflow193, label %bb_checked193
bb_overflow193:
  %v926 = load i64, ptr %slot1, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %v928 = load i64, ptr %slot163, align 8
  %v929 = load i64, ptr %slot162, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p927, i64 1, i64 %v928, i64 %v929, i64 64) nomerge, !dbg !122
  unreachable
bb_checked193:
  %v930 = load i64, ptr %slot164, align 8
  %v931 = load i64, ptr %slot16, align 8
  %p932 = inttoptr i64 %v931 to ptr
  store i64 %v930, ptr %p932, align 8, !alias.scope !3, !noalias !4
  %v933 = load i64, ptr %slot21, align 8
  store i64 %v933, ptr %slot169, align 8
  %v934 = load i64, ptr %slot24, align 8
  store i64 %v934, ptr %slot170, align 8
  %v935 = load i64, ptr %slot16, align 8
  store i64 %v935, ptr %slot171, align 8
  %v936 = load i64, ptr %slot169, align 8
  %p938 = inttoptr i64 %v936 to ptr
  %gep939 = getelementptr i8, ptr %p938, i64 0
  %op937 = ptrtoint ptr %gep939 to i64
  store i64 %op937, ptr %slot172, align 8
  %v940 = load i64, ptr %slot171, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %ld942 = load i64, ptr %p941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld942, ptr %slot173, align 8
  %v943 = load i64, ptr %slot173, align 8
  %v944 = load i64, ptr %slot172, align 8
  %p945 = inttoptr i64 %v944 to ptr
  store i64 %v943, ptr %p945, align 8, !alias.scope !3, !noalias !4
  %v946 = load i64, ptr %slot169, align 8
  %v947 = load i64, ptr %slot16, align 8
  %p948 = inttoptr i64 %v947 to ptr
  store i64 %v946, ptr %p948, align 8, !alias.scope !3, !noalias !4
  %v949 = load i64, ptr %slot22, align 8
  store i64 %v949, ptr %slot174, align 8
  %v950 = load i64, ptr %slot174, align 8
  %p951 = inttoptr i64 %v950 to ptr
  store i64 0, ptr %p951, align 8, !alias.scope !3, !noalias !4
  %v952 = load i64, ptr %slot174, align 8
  %p954 = inttoptr i64 %v952 to ptr
  %gep955 = getelementptr i8, ptr %p954, i64 8
  %op953 = ptrtoint ptr %gep955 to i64
  store i64 %op953, ptr %slot175, align 8
  %v956 = load i64, ptr %slot175, align 8
  %p957 = inttoptr i64 %v956 to ptr
  store i64 0, ptr %p957, align 8, !alias.scope !3, !noalias !4
  %v958 = load i64, ptr %slot174, align 8
  %p959 = inttoptr i64 %v958 to ptr
  store i32 0, ptr %p959, align 4, !alias.scope !3, !noalias !4
  %v960 = load i64, ptr %slot10, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i32 1, ptr %p961, align 4, !alias.scope !3, !noalias !4
  %v962 = load i64, ptr %slot16, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ld964 = load i64, ptr %p963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld964, ptr %slot176, align 8
  %v965 = load i64, ptr %slot174, align 8
  %p967 = inttoptr i64 %v965 to ptr
  %gep968 = getelementptr i8, ptr %p967, i64 8
  %op966 = ptrtoint ptr %gep968 to i64
  store i64 %op966, ptr %slot177, align 8
  %v969 = load i64, ptr %slot24, align 8
  store i64 %v969, ptr %slot178, align 8
  %v970 = load i64, ptr %slot176, align 8
  %v971 = load i64, ptr %slot177, align 8
  %p972 = inttoptr i64 %v970 to ptr
  %p973 = inttoptr i64 %v971 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p973, ptr %p972, i64 8, i1 false)
  %v974 = load i64, ptr %slot174, align 8
  %v975 = load i64, ptr %slot16, align 8
  %p976 = inttoptr i64 %v975 to ptr
  store i64 %v974, ptr %p976, align 8, !alias.scope !3, !noalias !4
  %v977 = load i64, ptr %slot16, align 8
  %p978 = inttoptr i64 %v977 to ptr
  %ld979 = load i64, ptr %p978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld979, ptr %slot179, align 8
  %v980 = load i64, ptr %slot11, align 8
  store i64 %v980, ptr %slot180, align 8
  %v981 = load i64, ptr %slot179, align 8
  %v982 = load i64, ptr %slot180, align 8
  %p983 = inttoptr i64 %v981 to ptr
  %p984 = inttoptr i64 %v982 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p984, ptr %p983, i64 16, i1 false)
  %v985 = load i64, ptr %slot7, align 8
  %p986 = inttoptr i64 %v985 to ptr
  store i32 2, ptr %p986, align 4, !alias.scope !3, !noalias !4
  %v987 = load i64, ptr %slot6, align 8
  %p988 = inttoptr i64 %v987 to ptr
  store i32 1, ptr %p988, align 4, !alias.scope !3, !noalias !4
  %v989 = load i64, ptr %slot180, align 8
  %v990 = load i64, ptr %slot16, align 8
  %p991 = inttoptr i64 %v990 to ptr
  store i64 %v989, ptr %p991, align 8, !alias.scope !3, !noalias !4
  %v992 = load i64, ptr %slot16, align 8
  %p993 = inttoptr i64 %v992 to ptr
  %ld994 = load i64, ptr %p993, align 8, !alias.scope !3, !noalias !4
  store i64 %ld994, ptr %slot181, align 8
  %v995 = load i64, ptr %slot16, align 8
  %p996 = inttoptr i64 %v995 to ptr
  %ld997 = load i64, ptr %p996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld997, ptr %slot182, align 8
  %v998 = load i64, ptr %slot13, align 8
  store i64 %v998, ptr %slot183, align 8
  %v999 = load i64, ptr %slot24, align 8
  store i64 %v999, ptr %slot184, align 8
  %v1000 = load i64, ptr %slot23, align 8
  %v1001 = load i64, ptr %slot183, align 8
  %v1002 = load i64, ptr %slot182, align 8
  %v1003 = load i64, ptr %slot184, align 8
  %cv1004 = trunc i64 %v1003 to i32
  %call1005 = call i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64 %v1000, i64 %v1001, i64 %v1002, i32 %cv1004) nomerge, !dbg !124
  store i32 %call1005, ptr %slot185, align 8
  %v1006 = load i32, ptr %slot185, align 8
  %cv1007 = zext i32 %v1006 to i64
  %cond1008 = icmp ne i64 %cv1007, 0
  br i1 %cond1008, label %bb_rcsuccess219, label %bb_rcfailure219
bb_rcfailure219:
  %v1009 = load i64, ptr %slot23, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  %call1011 = call i32 @myl_rc_take_failure(ptr %p1010) nomerge, !dbg !124
  store i32 %call1011, ptr %slot186, align 8
  %v1012 = load i64, ptr %slot1, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  %v1014 = load i32, ptr %slot186, align 8
  %call1015 = call i32 @myl_qbe_rc_status(ptr %p1013, i32 %v1014) nomerge, !dbg !124
  store i32 %call1015, ptr %slot187, align 8
  br label %bb_failure
bb_rcsuccess219:
  %v1016 = load i64, ptr %slot6, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  store i32 0, ptr %p1017, align 4, !alias.scope !3, !noalias !4
  %v1018 = load i64, ptr %slot9, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  store i32 2, ptr %p1019, align 4, !alias.scope !3, !noalias !4
  %v1020 = load i64, ptr %slot8, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  store i32 1, ptr %p1021, align 4, !alias.scope !3, !noalias !4
  %v1022 = load i64, ptr %slot13, align 8
  store i64 %v1022, ptr %slot188, align 8
  %v1023 = load i64, ptr %slot8, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  store i32 0, ptr %p1024, align 4, !alias.scope !3, !noalias !4
  %v1025 = load i64, ptr %slot6, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  %ld1027 = load i32, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1027, ptr %slot189, align 8
  %v1028 = load i32, ptr %slot189, align 8
  %cv1029 = zext i32 %v1028 to i64
  %cond1030 = icmp ne i64 %cv1029, 0
  br i1 %cond1030, label %bb_rcslotdrop229, label %bb_rcslotdone229
bb_rcslotdrop229:
  %v1031 = load i64, ptr %slot6, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  store i32 0, ptr %p1032, align 4, !alias.scope !3, !noalias !4
  %v1033 = load i64, ptr %slot11, align 8
  store i64 %v1033, ptr %slot190, align 8
  %v1034 = load i64, ptr %slot7, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i32, ptr %p1035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1036, ptr %slot191, align 8
  %v1037 = load i32, ptr %slot191, align 8
  %op1038 = and i32 %v1037, 28
  store i32 %op1038, ptr %slot192, align 8
  %v1039 = load i32, ptr %slot192, align 8
  %cv1040 = zext i32 %v1039 to i64
  %cond1041 = icmp ne i64 %cv1040, 0
  br i1 %cond1041, label %bb_rcslotrole229, label %bb_rcslotowner229
bb_rcslotrole229:
  %v1042 = load i64, ptr %slot23, align 8
  store i64 %v1042, ptr %slot193, align 8
  %v1043 = load i64, ptr %slot193, align 8
  %v1044 = load i64, ptr %slot190, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64 %v1043, i64 %v1044) nomerge, !dbg !124
  br label %bb_rcslotdone229
bb_rcslotowner229:
  %v1045 = load i64, ptr %slot23, align 8
  store i64 %v1045, ptr %slot194, align 8
  %v1046 = load i64, ptr %slot194, align 8
  %v1047 = load i64, ptr %slot190, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64 %v1046, i64 %v1047) nomerge, !dbg !124
  br label %bb_rcslotdone229
bb_rcslotdone229:
  %v1048 = load i64, ptr %slot188, align 8
  %p1049 = inttoptr i64 %v1048 to ptr
  %ret1050 = load { i64, i64 }, ptr %p1049, align 8
  ret { i64, i64 } %ret1050
bb_failure:
  %v1051 = load i64, ptr %slot5, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  call void @llvm.memset.p0.i64(ptr %p1052, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !124
  %v1053 = load i64, ptr %slot5, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  %ret1055 = load { i64, i64 }, ptr %p1054, align 8
  ret { i64, i64 } %ret1055
bb_entry_failure:
  %v1056 = load i64, ptr %slot5, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  call void @llvm.memset.p0.i64(ptr %p1057, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !124
  %v1058 = load i64, ptr %slot5, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %ret1060 = load { i64, i64 }, ptr %p1059, align 8
  ret { i64, i64 } %ret1060
}

@myl_f_157bc77b45a4ecb850aa96ee9697e989f0c07c64274d2cc18365bc6001dfc2f0_meta = external global i8, align 8
@myl_lit_1a69ccf47387ae009a008f5f1b7a2d308379629465792632f22bcb30afb3ab52 = external global i8, align 8
@myl_lit_b41f42941b311c0582cd1a64f4d298d1f40e9e8d49ae3743d6188750dab9ffae = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64, i64)
declare i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_157bc77b45a4ecb850aa96ee9697e989f0c07c64274d2cc18365bc6001dfc2f0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_157bc77b45a4ecb850aa96ee9697e989f0c07c64274d2cc18365bc6001dfc2f0", linkageName: "myl_f_157bc77b45a4ecb850aa96ee9697e989f0c07c64274d2cc18365bc6001dfc2f0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 383762132517688487, i64 0, !"myl_f_157bc77b45a4ecb850aa96ee9697e989f0c07c64274d2cc18365bc6001dfc2f0"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!112 = !DILocation(line: 8, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!114 = !DILocation(line: 9, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!116 = !DILocation(line: 21, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!118 = !DILocation(line: 27, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!120 = !DILocation(line: 28, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!122 = !DILocation(line: 33, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!124 = !DILocation(line: 36, column: 0, scope: !125)
