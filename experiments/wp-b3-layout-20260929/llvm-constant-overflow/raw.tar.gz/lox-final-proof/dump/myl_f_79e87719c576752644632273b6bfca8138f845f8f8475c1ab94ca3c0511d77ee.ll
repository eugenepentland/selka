target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v160 = load i64, ptr %slot1, align 8
  %op161 = add i64 %v160, 32
  store i64 %op161, ptr %slot4, align 8
  %mem162 = alloca i8, i64 16, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot5, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot6, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot7, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot8, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot9, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot10, align 8
  %mem174 = alloca i8, i64 16, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot11, align 8
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot12, align 8
  %mem178 = alloca i8, i64 16, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot13, align 8
  %mem180 = alloca i8, i64 8, align 8
  %ptr181 = ptrtoint ptr %mem180 to i64
  store i64 %ptr181, ptr %slot14, align 8
  %mem182 = alloca i8, i64 8, align 8
  %ptr183 = ptrtoint ptr %mem182 to i64
  store i64 %ptr183, ptr %slot15, align 8
  %mem184 = alloca i8, i64 8, align 8
  %ptr185 = ptrtoint ptr %mem184 to i64
  store i64 %ptr185, ptr %slot16, align 8
  %mem186 = alloca i8, i64 8, align 8
  %ptr187 = ptrtoint ptr %mem186 to i64
  store i64 %ptr187, ptr %slot17, align 8
  %mem188 = alloca i8, i64 8, align 8
  %ptr189 = ptrtoint ptr %mem188 to i64
  store i64 %ptr189, ptr %slot18, align 8
  %mem190 = alloca i8, i64 8, align 8
  %ptr191 = ptrtoint ptr %mem190 to i64
  store i64 %ptr191, ptr %slot19, align 8
  %mem192 = alloca i8, i64 16, align 8
  %ptr193 = ptrtoint ptr %mem192 to i64
  store i64 %ptr193, ptr %slot20, align 8
  %mem194 = alloca i8, i64 8, align 8
  %ptr195 = ptrtoint ptr %mem194 to i64
  store i64 %ptr195, ptr %slot21, align 8
  %mem196 = alloca i8, i64 16, align 8
  %ptr197 = ptrtoint ptr %mem196 to i64
  store i64 %ptr197, ptr %slot22, align 8
  %v198 = load i64, ptr %slot2, align 8
  %v199 = load i64, ptr %slot14, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 %v198, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot3, align 8
  %v202 = load i64, ptr %slot15, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 %v201, ptr %p203, align 8, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot1, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %call206 = call ptr @myl_qbe_heap(ptr %p205) nomerge, !dbg !110
  %calladdr207 = ptrtoint ptr %call206 to i64
  store i64 %calladdr207, ptr %slot23, align 8
  %v208 = load i64, ptr %slot1, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %call210 = call i64 @myl_qbe_region_mark(ptr %p209) nomerge, !dbg !110
  store i64 %call210, ptr %slot24, align 8
  %v211 = load i64, ptr %slot6, align 8
  %p212 = inttoptr i64 %v211 to ptr
  store i32 0, ptr %p212, align 4, !alias.scope !3, !noalias !4
  %v213 = load i64, ptr %slot7, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i32 0, ptr %p214, align 4, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot8, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i32 0, ptr %p216, align 4, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot9, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i32 0, ptr %p218, align 4, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot10, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i32 0, ptr %p220, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v221 = load i64, ptr %slot17, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i64 9223372036854775807, ptr %p222, align 8, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_i2:
  %v223 = load i64, ptr %slot15, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ld225 = load i64, ptr %p224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld225, ptr %slot25, align 8
  %v226 = load i64, ptr %slot25, align 8
  %v227 = load i64, ptr %slot18, align 8
  %p228 = inttoptr i64 %v227 to ptr
  store i64 %v226, ptr %p228, align 8, !alias.scope !3, !noalias !4
  %v229 = load i64, ptr %slot18, align 8
  %p230 = inttoptr i64 %v229 to ptr
  %ld231 = load i64, ptr %p230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld231, ptr %slot26, align 8
  %v232 = load i64, ptr %slot17, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot27, align 8
  %v235 = load i64, ptr %slot26, align 8
  %cmp236 = icmp eq i64 %v235, 0
  %cv237 = zext i1 %cmp236 to i64
  store i64 %cv237, ptr %slot28, align 8
  %v238 = load i64, ptr %slot28, align 8
  %cond239 = icmp ne i64 %v238, 0
  br i1 %cond239, label %bb_division3, label %bb_nonzero3
bb_division3:
  %v240 = load i64, ptr %slot1, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %v242 = load i64, ptr %slot27, align 8
  %v243 = load i64, ptr %slot26, align 8
  call void @myl_qbe_fail_division(ptr %p241, i64 5, i64 %v242, i64 %v243) nomerge, !dbg !112
  unreachable
bb_nonzero3:
  %v244 = load i64, ptr %slot27, align 8
  %cmp245 = icmp eq i64 %v244, 9223372036854775808
  %cv246 = zext i1 %cmp245 to i64
  store i64 %cv246, ptr %slot29, align 8
  %v247 = load i64, ptr %slot26, align 8
  %cmp248 = icmp eq i64 %v247, 18446744073709551615
  %cv249 = zext i1 %cmp248 to i64
  store i64 %cv249, ptr %slot30, align 8
  %v250 = load i64, ptr %slot29, align 8
  %v251 = load i64, ptr %slot30, align 8
  %op252 = and i64 %v250, %v251
  store i64 %op252, ptr %slot31, align 8
  %v253 = load i64, ptr %slot31, align 8
  %cond254 = icmp ne i64 %v253, 0
  br i1 %cond254, label %bb_overflow3, label %bb_checked3
bb_overflow3:
  %v255 = load i64, ptr %slot1, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %v257 = load i64, ptr %slot27, align 8
  %v258 = load i64, ptr %slot26, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p256, i64 5, i64 %v257, i64 %v258, i64 64) nomerge, !dbg !112
  unreachable
bb_checked3:
  %v259 = load i64, ptr %slot27, align 8
  %v260 = load i64, ptr %slot26, align 8
  %op261 = sdiv i64 %v259, %v260
  store i64 %op261, ptr %slot32, align 8
  %v262 = load i64, ptr %slot27, align 8
  %v263 = load i64, ptr %slot26, align 8
  %op264 = srem i64 %v262, %v263
  store i64 %op264, ptr %slot33, align 8
  %v265 = load i64, ptr %slot33, align 8
  %cmp266 = icmp ne i64 %v265, 0
  %cv267 = zext i1 %cmp266 to i64
  store i64 %cv267, ptr %slot34, align 8
  %v268 = load i64, ptr %slot33, align 8
  %v269 = load i64, ptr %slot26, align 8
  %op270 = xor i64 %v268, %v269
  store i64 %op270, ptr %slot35, align 8
  %v271 = load i64, ptr %slot35, align 8
  %cmp272 = icmp slt i64 %v271, 0
  %cv273 = zext i1 %cmp272 to i64
  store i64 %cv273, ptr %slot36, align 8
  %v274 = load i64, ptr %slot34, align 8
  %v275 = load i64, ptr %slot36, align 8
  %op276 = and i64 %v274, %v275
  store i64 %op276, ptr %slot37, align 8
  %v277 = load i64, ptr %slot37, align 8
  %neg278 = sub i64 0, %v277
  store i64 %neg278, ptr %slot38, align 8
  %v279 = load i64, ptr %slot32, align 8
  %v280 = load i64, ptr %slot37, align 8
  %op281 = sub i64 %v279, %v280
  store i64 %op281, ptr %slot32, align 8
  %v282 = load i64, ptr %slot32, align 8
  %v283 = load i64, ptr %slot17, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 %v282, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot17, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i64, ptr %p286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld287, ptr %slot39, align 8
  %v288 = load i64, ptr %slot39, align 8
  %v289 = load i64, ptr %slot16, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i64 %v288, ptr %p290, align 8, !alias.scope !3, !noalias !4
  %v291 = load i64, ptr %slot14, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %ld293 = load i64, ptr %p292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld293, ptr %slot40, align 8
  %v294 = load i64, ptr %slot40, align 8
  %v295 = load i64, ptr %slot17, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i64 %v294, ptr %p296, align 8, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot16, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot41, align 8
  %v300 = load i64, ptr %slot41, align 8
  %v301 = load i64, ptr %slot18, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i64 %v300, ptr %p302, align 8, !alias.scope !3, !noalias !4
  %v303 = load i64, ptr %slot18, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot42, align 8
  %v306 = load i64, ptr %slot17, align 8
  %p307 = inttoptr i64 %v306 to ptr
  %ld308 = load i64, ptr %p307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld308, ptr %slot43, align 8
  %v309 = load i64, ptr %slot43, align 8
  %v310 = load i64, ptr %slot42, align 8
  %cmp311 = icmp sgt i64 %v309, %v310
  %cv312 = zext i1 %cmp311 to i64
  store i64 %cv312, ptr %slot44, align 8
  %v313 = load i64, ptr %slot44, align 8
  %v314 = load i64, ptr %slot17, align 8
  %p315 = inttoptr i64 %v314 to ptr
  store i64 %v313, ptr %p315, align 8, !alias.scope !3, !noalias !4
  %v316 = load i64, ptr %slot17, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %ld318 = load i64, ptr %p317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld318, ptr %slot45, align 8
  %v319 = load i64, ptr %slot45, align 8
  %cond320 = icmp ne i64 %v319, 0
  br i1 %cond320, label %bb_next21, label %bb_i11
bb_next21:
  %v321 = load i64, ptr %slot17, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i64 1, ptr %p322, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i11:
  %v323 = load i64, ptr %slot14, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %ld325 = load i64, ptr %p324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld325, ptr %slot46, align 8
  %v326 = load i64, ptr %slot46, align 8
  %v327 = load i64, ptr %slot17, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 %v326, ptr %p328, align 8, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot18, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i64 0, ptr %p330, align 8, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot16, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %ld333 = load i64, ptr %p332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld333, ptr %slot47, align 8
  %v334 = load i64, ptr %slot47, align 8
  %v335 = load i64, ptr %slot19, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 %v334, ptr %p336, align 8, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot19, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot48, align 8
  %v340 = load i64, ptr %slot18, align 8
  %p341 = inttoptr i64 %v340 to ptr
  %ld342 = load i64, ptr %p341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld342, ptr %slot49, align 8
  %v343 = load i64, ptr %slot49, align 8
  %v344 = load i64, ptr %slot48, align 8
  %ovpair346 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v343, i64 %v344)
  %op345 = extractvalue { i64, i1 } %ovpair346, 0
  %ov347 = extractvalue { i64, i1 } %ovpair346, 1
  store i64 %op345, ptr %slot50, align 8
  %v348 = load i64, ptr %slot49, align 8
  %v349 = load i64, ptr %slot48, align 8
  %op350 = xor i64 %v348, %v349
  store i64 %op350, ptr %slot51, align 8
  %v351 = load i64, ptr %slot49, align 8
  %v352 = load i64, ptr %slot50, align 8
  %op353 = xor i64 %v351, %v352
  store i64 %op353, ptr %slot52, align 8
  %v354 = load i64, ptr %slot51, align 8
  %v355 = load i64, ptr %slot52, align 8
  %op356 = and i64 %v354, %v355
  store i64 %op356, ptr %slot53, align 8
  %cv357 = zext i1 %ov347 to i64
  store i64 %cv357, ptr %slot54, align 8
  %v358 = load i64, ptr %slot54, align 8
  %cond359 = icmp ne i64 %v358, 0
  br i1 %cond359, label %bb_overflow25, label %bb_checked25
bb_overflow25:
  %v360 = load i64, ptr %slot1, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %v362 = load i64, ptr %slot49, align 8
  %v363 = load i64, ptr %slot48, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p361, i64 1, i64 %v362, i64 %v363, i64 64) nomerge, !dbg !114
  unreachable
bb_checked25:
  %v364 = load i64, ptr %slot50, align 8
  %v365 = load i64, ptr %slot18, align 8
  %p366 = inttoptr i64 %v365 to ptr
  store i64 %v364, ptr %p366, align 8, !alias.scope !3, !noalias !4
  %v367 = load i64, ptr %slot18, align 8
  %p368 = inttoptr i64 %v367 to ptr
  %ld369 = load i64, ptr %p368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld369, ptr %slot55, align 8
  %v370 = load i64, ptr %slot17, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i64, ptr %p371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld372, ptr %slot56, align 8
  %v373 = load i64, ptr %slot56, align 8
  %v374 = load i64, ptr %slot55, align 8
  %cmp375 = icmp slt i64 %v373, %v374
  %cv376 = zext i1 %cmp375 to i64
  store i64 %cv376, ptr %slot57, align 8
  %v377 = load i64, ptr %slot57, align 8
  %v378 = load i64, ptr %slot17, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i64 %v377, ptr %p379, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i16:
  %v380 = load i64, ptr %slot17, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot58, align 8
  %v383 = load i64, ptr %slot58, align 8
  %cond384 = icmp ne i64 %v383, 0
  br i1 %cond384, label %bb_next34, label %bb_i20
bb_next34:
  %p385 = inttoptr i64 ptrtoint (ptr @myl_lit_6aa0d7cbc5974fbf558d31cd0d56fc35358d28044055f5efa85445ac9711a167 to i64) to ptr
  %ld386 = load i64, ptr %p385, align 8, !alias.scope !4, !noalias !3
  store i64 %ld386, ptr %slot59, align 8
  %v387 = load i64, ptr %slot59, align 8
  %v388 = load i64, ptr %slot17, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 %v387, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot17, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot60, align 8
  %v393 = load i64, ptr %slot60, align 8
  %v394 = load i64, ptr %slot12, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 %v393, ptr %p395, align 8, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot12, align 8
  store i64 %v396, ptr %slot61, align 8
  %v397 = load i64, ptr %slot13, align 8
  store i64 %v397, ptr %slot62, align 8
  %v398 = load i64, ptr %slot61, align 8
  %v399 = load i64, ptr %slot62, align 8
  %p400 = inttoptr i64 %v398 to ptr
  %p401 = inttoptr i64 %v399 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p401, ptr %p400, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot9, align 8
  %p403 = inttoptr i64 %v402 to ptr
  store i32 2, ptr %p403, align 4, !alias.scope !3, !noalias !4
  %v404 = load i64, ptr %slot8, align 8
  %p405 = inttoptr i64 %v404 to ptr
  store i32 1, ptr %p405, align 4, !alias.scope !3, !noalias !4
  %v406 = load i64, ptr %slot11, align 8
  store i64 %v406, ptr %slot63, align 8
  %v407 = load i64, ptr %slot13, align 8
  store i64 %v407, ptr %slot64, align 8
  %v408 = load i64, ptr %slot64, align 8
  %v409 = load i64, ptr %slot63, align 8
  %p410 = inttoptr i64 %v408 to ptr
  %p411 = inttoptr i64 %v409 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p411, ptr %p410, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v412 = load i64, ptr %slot7, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i32 2, ptr %p413, align 4, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot9, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i32, ptr %p415, align 4, !alias.scope !3, !noalias !4
  store i32 %ld416, ptr %slot65, align 8
  %v417 = load i32, ptr %slot65, align 8
  %v418 = load i64, ptr %slot7, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i32 %v417, ptr %p419, align 4, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot8, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i32 0, ptr %p421, align 4, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot6, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i32 1, ptr %p423, align 4, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot63, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %ld426 = load i64, ptr %p425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld426, ptr %slot66, align 8
  %v427 = load i64, ptr %slot66, align 8
  %v428 = load i64, ptr %slot17, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 %v427, ptr %p429, align 8, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot20, align 8
  store i64 %v430, ptr %slot67, align 8
  %v431 = load i64, ptr %slot67, align 8
  %p432 = inttoptr i64 %v431 to ptr
  store i64 0, ptr %p432, align 8, !alias.scope !3, !noalias !4
  %v433 = load i64, ptr %slot67, align 8
  %p435 = inttoptr i64 %v433 to ptr
  %gep436 = getelementptr i8, ptr %p435, i64 8
  %op434 = ptrtoint ptr %gep436 to i64
  store i64 %op434, ptr %slot68, align 8
  %v437 = load i64, ptr %slot68, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i64 0, ptr %p438, align 8, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot67, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i32 1, ptr %p440, align 4, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot10, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i32 1, ptr %p442, align 4, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot17, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i64, ptr %p444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld445, ptr %slot69, align 8
  %v446 = load i64, ptr %slot69, align 8
  %v447 = load i64, ptr %slot12, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i64 %v446, ptr %p448, align 8, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot12, align 8
  store i64 %v449, ptr %slot70, align 8
  %v450 = load i64, ptr %slot67, align 8
  %p452 = inttoptr i64 %v450 to ptr
  %gep453 = getelementptr i8, ptr %p452, i64 8
  %op451 = ptrtoint ptr %gep453 to i64
  store i64 %op451, ptr %slot71, align 8
  %v454 = load i64, ptr %slot24, align 8
  store i64 %v454, ptr %slot72, align 8
  %v455 = load i64, ptr %slot17, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %ld457 = load i64, ptr %p456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld457, ptr %slot73, align 8
  %v458 = load i64, ptr %slot73, align 8
  %v459 = load i64, ptr %slot12, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i64 %v458, ptr %p460, align 8, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot12, align 8
  store i64 %v461, ptr %slot74, align 8
  %v462 = load i64, ptr %slot13, align 8
  store i64 %v462, ptr %slot75, align 8
  %v463 = load i64, ptr %slot24, align 8
  store i64 %v463, ptr %slot76, align 8
  %v464 = load i64, ptr %slot74, align 8
  %p466 = inttoptr i64 %v464 to ptr
  %gep467 = getelementptr i8, ptr %p466, i64 0
  %op465 = ptrtoint ptr %gep467 to i64
  store i64 %op465, ptr %slot77, align 8
  %v468 = load i64, ptr %slot77, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %ld470 = load i64, ptr %p469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld470, ptr %slot78, align 8
  %v471 = load i64, ptr %slot78, align 8
  %cmp472 = icmp ne i64 %v471, 0
  %cv473 = zext i1 %cmp472 to i32
  store i32 %cv473, ptr %slot79, align 8
  %v474 = load i32, ptr %slot79, align 8
  %cv475 = zext i32 %v474 to i64
  %cond476 = icmp ne i64 %cv475, 0
  br i1 %cond476, label %bb_rcmoveheader65, label %bb_rcmovenext65
bb_rcmoveheader65:
  %v477 = load i64, ptr %slot78, align 8
  %op478 = sub i64 %v477, 16
  store i64 %op478, ptr %slot80, align 8
  %v479 = load i64, ptr %slot78, align 8
  %p480 = inttoptr i64 %v479 to ptr
  %rgep481 = getelementptr i8, ptr %p480, i64 -16
  %ld482 = load i64, ptr %rgep481, align 8, !alias.scope !9, !noalias !10
  store i64 %ld482, ptr %slot81, align 8
  %v483 = load i64, ptr %slot81, align 8
  %op484 = and i64 %v483, 5764607523034234881
  store i64 %op484, ptr %slot82, align 8
  %v485 = load i64, ptr %slot82, align 8
  %cmp486 = icmp ne i64 %v485, 0
  %cv487 = zext i1 %cmp486 to i32
  store i32 %cv487, ptr %slot83, align 8
  %v488 = load i32, ptr %slot83, align 8
  %cv489 = zext i32 %v488 to i64
  %cond490 = icmp ne i64 %cv489, 0
  br i1 %cond490, label %bb_rcmoveslow62, label %bb_rcmovenext65
bb_rcmovenext65:
  %v491 = load i64, ptr %slot74, align 8
  %v492 = load i64, ptr %slot75, align 8
  %p493 = inttoptr i64 %v491 to ptr
  %p494 = inttoptr i64 %v492 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p494, ptr %p493, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot74, align 8
  %p496 = inttoptr i64 %v495 to ptr
  store i64 0, ptr %p496, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved62
bb_rcmoveslow62:
  %v497 = load i64, ptr %slot23, align 8
  %v498 = load i64, ptr %slot75, align 8
  %v499 = load i64, ptr %slot74, align 8
  %v500 = load i64, ptr %slot76, align 8
  %cv501 = trunc i64 %v500 to i32
  %call502 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v497, i64 %v498, i64 %v499, i32 %cv501) nomerge, !dbg !116
  store i32 %call502, ptr %slot84, align 8
  %v503 = load i32, ptr %slot84, align 8
  %cv504 = zext i32 %v503 to i64
  %cond505 = icmp ne i64 %cv504, 0
  br i1 %cond505, label %bb_rcsuccess72, label %bb_rcfailure72
bb_rcfailure72:
  %v506 = load i64, ptr %slot23, align 8
  %p507 = inttoptr i64 %v506 to ptr
  %call508 = call i32 @myl_rc_take_failure(ptr %p507) nomerge, !dbg !116
  store i32 %call508, ptr %slot85, align 8
  %v509 = load i64, ptr %slot1, align 8
  %p510 = inttoptr i64 %v509 to ptr
  %v511 = load i32, ptr %slot85, align 8
  %call512 = call i32 @myl_qbe_rc_status(ptr %p510, i32 %v511) nomerge, !dbg !116
  store i32 %call512, ptr %slot86, align 8
  br label %bb_failure
bb_rcsuccess72:
  br label %bb_rcmoved62
bb_rcmoved62:
  %v513 = load i64, ptr %slot6, align 8
  %p514 = inttoptr i64 %v513 to ptr
  store i32 0, ptr %p514, align 4, !alias.scope !3, !noalias !4
  %v515 = load i64, ptr %slot9, align 8
  %p516 = inttoptr i64 %v515 to ptr
  store i32 2, ptr %p516, align 4, !alias.scope !3, !noalias !4
  %v517 = load i64, ptr %slot8, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i32 1, ptr %p518, align 4, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot13, align 8
  store i64 %v519, ptr %slot87, align 8
  %v520 = load i64, ptr %slot87, align 8
  %v521 = load i64, ptr %slot71, align 8
  %p522 = inttoptr i64 %v520 to ptr
  %p523 = inttoptr i64 %v521 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p523, ptr %p522, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot8, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i32 0, ptr %p525, align 4, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot67, align 8
  %v527 = load i64, ptr %slot17, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i64 %v526, ptr %p528, align 8, !alias.scope !3, !noalias !4
  %p529 = inttoptr i64 ptrtoint (ptr @myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p529, i64 18) "call-inline-cost"="0", !dbg !116
  %v530 = load i64, ptr %slot17, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot88, align 8
  %v533 = load i64, ptr %slot11, align 8
  store i64 %v533, ptr %slot89, align 8
  %v534 = load i64, ptr %slot88, align 8
  %v535 = load i64, ptr %slot89, align 8
  %p536 = inttoptr i64 %v534 to ptr
  %p537 = inttoptr i64 %v535 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p537, ptr %p536, i64 16, i1 false)
  %v538 = load i64, ptr %slot7, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i32 2, ptr %p539, align 4, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot6, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i32 1, ptr %p541, align 4, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot89, align 8
  %v543 = load i64, ptr %slot17, align 8
  %p544 = inttoptr i64 %v543 to ptr
  store i64 %v542, ptr %p544, align 8, !alias.scope !3, !noalias !4
  %v545 = load i64, ptr %slot17, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %ld547 = load i64, ptr %p546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld547, ptr %slot90, align 8
  %v548 = load i64, ptr %slot17, align 8
  %p549 = inttoptr i64 %v548 to ptr
  %ld550 = load i64, ptr %p549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld550, ptr %slot91, align 8
  %v551 = load i64, ptr %slot13, align 8
  store i64 %v551, ptr %slot92, align 8
  %v552 = load i64, ptr %slot24, align 8
  store i64 %v552, ptr %slot93, align 8
  %v553 = load i64, ptr %slot23, align 8
  %v554 = load i64, ptr %slot92, align 8
  %v555 = load i64, ptr %slot91, align 8
  %v556 = load i64, ptr %slot93, align 8
  %cv557 = trunc i64 %v556 to i32
  %call558 = call i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64 %v553, i64 %v554, i64 %v555, i32 %cv557) nomerge, !dbg !118
  store i32 %call558, ptr %slot94, align 8
  %v559 = load i32, ptr %slot94, align 8
  %cv560 = zext i32 %v559 to i64
  %cond561 = icmp ne i64 %cv560, 0
  br i1 %cond561, label %bb_rcsuccess89, label %bb_rcfailure89
bb_rcfailure89:
  %v562 = load i64, ptr %slot23, align 8
  %p563 = inttoptr i64 %v562 to ptr
  %call564 = call i32 @myl_rc_take_failure(ptr %p563) nomerge, !dbg !118
  store i32 %call564, ptr %slot95, align 8
  %v565 = load i64, ptr %slot1, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %v567 = load i32, ptr %slot95, align 8
  %call568 = call i32 @myl_qbe_rc_status(ptr %p566, i32 %v567) nomerge, !dbg !118
  store i32 %call568, ptr %slot96, align 8
  br label %bb_failure
bb_rcsuccess89:
  %v569 = load i64, ptr %slot6, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i32 0, ptr %p570, align 4, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot9, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i32 2, ptr %p572, align 4, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot8, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i32 1, ptr %p574, align 4, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot13, align 8
  store i64 %v575, ptr %slot97, align 8
  %v576 = load i64, ptr %slot8, align 8
  %p577 = inttoptr i64 %v576 to ptr
  store i32 0, ptr %p577, align 4, !alias.scope !3, !noalias !4
  %v578 = load i64, ptr %slot6, align 8
  %p579 = inttoptr i64 %v578 to ptr
  %ld580 = load i32, ptr %p579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld580, ptr %slot98, align 8
  %v581 = load i32, ptr %slot98, align 8
  %cv582 = zext i32 %v581 to i64
  %cond583 = icmp ne i64 %cv582, 0
  br i1 %cond583, label %bb_rcslotdrop99, label %bb_rcslotdone99
bb_rcslotdrop99:
  %v584 = load i64, ptr %slot6, align 8
  %p585 = inttoptr i64 %v584 to ptr
  store i32 0, ptr %p585, align 4, !alias.scope !3, !noalias !4
  %v586 = load i64, ptr %slot11, align 8
  store i64 %v586, ptr %slot99, align 8
  %v587 = load i64, ptr %slot7, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %ld589 = load i32, ptr %p588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld589, ptr %slot100, align 8
  %v590 = load i32, ptr %slot100, align 8
  %op591 = and i32 %v590, 28
  store i32 %op591, ptr %slot101, align 8
  %v592 = load i32, ptr %slot101, align 8
  %cv593 = zext i32 %v592 to i64
  %cond594 = icmp ne i64 %cv593, 0
  br i1 %cond594, label %bb_rcslotrole99, label %bb_rcslotowner99
bb_rcslotrole99:
  %v595 = load i64, ptr %slot23, align 8
  store i64 %v595, ptr %slot102, align 8
  %v596 = load i64, ptr %slot102, align 8
  %v597 = load i64, ptr %slot99, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64 %v596, i64 %v597) nomerge, !dbg !118
  br label %bb_rcslotdone99
bb_rcslotowner99:
  %v598 = load i64, ptr %slot23, align 8
  store i64 %v598, ptr %slot103, align 8
  %v599 = load i64, ptr %slot103, align 8
  %v600 = load i64, ptr %slot99, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64 %v599, i64 %v600) nomerge, !dbg !118
  br label %bb_rcslotdone99
bb_rcslotdone99:
  %v601 = load i64, ptr %slot97, align 8
  %p602 = inttoptr i64 %v601 to ptr
  %ret603 = load { i64, i64 }, ptr %p602, align 8
  ret { i64, i64 } %ret603
bb_i20:
  %v604 = load i64, ptr %slot14, align 8
  %p605 = inttoptr i64 %v604 to ptr
  %ld606 = load i64, ptr %p605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld606, ptr %slot104, align 8
  %v607 = load i64, ptr %slot104, align 8
  %v608 = load i64, ptr %slot17, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i64 %v607, ptr %p609, align 8, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot15, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i64, ptr %p611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld612, ptr %slot105, align 8
  %v613 = load i64, ptr %slot105, align 8
  %v614 = load i64, ptr %slot18, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i64 %v613, ptr %p615, align 8, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot18, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i64, ptr %p617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld618, ptr %slot106, align 8
  %v619 = load i64, ptr %slot17, align 8
  %p620 = inttoptr i64 %v619 to ptr
  %ld621 = load i64, ptr %p620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld621, ptr %slot107, align 8
  %v622 = load i64, ptr %slot107, align 8
  %v623 = load i64, ptr %slot106, align 8
  %ovpair625 = call { i64, i1 } @llvm.smul.with.overflow.i64(i64 %v622, i64 %v623)
  %op624 = extractvalue { i64, i1 } %ovpair625, 0
  %ov626 = extractvalue { i64, i1 } %ovpair625, 1
  store i64 %op624, ptr %slot108, align 8
  %v627 = load i64, ptr %slot107, align 8
  %op628 = and i64 %v627, 4294967295
  store i64 %op628, ptr %slot109, align 8
  %v629 = load i64, ptr %slot107, align 8
  %op630 = lshr i64 %v629, 32
  store i64 %op630, ptr %slot110, align 8
  %v631 = load i64, ptr %slot106, align 8
  %op632 = and i64 %v631, 4294967295
  store i64 %op632, ptr %slot111, align 8
  %v633 = load i64, ptr %slot106, align 8
  %op634 = lshr i64 %v633, 32
  store i64 %op634, ptr %slot112, align 8
  %v635 = load i64, ptr %slot109, align 8
  %v636 = load i64, ptr %slot111, align 8
  %op637 = mul i64 %v635, %v636
  store i64 %op637, ptr %slot113, align 8
  %v638 = load i64, ptr %slot113, align 8
  %op639 = lshr i64 %v638, 32
  store i64 %op639, ptr %slot114, align 8
  %v640 = load i64, ptr %slot110, align 8
  %v641 = load i64, ptr %slot111, align 8
  %op642 = mul i64 %v640, %v641
  store i64 %op642, ptr %slot115, align 8
  %v643 = load i64, ptr %slot115, align 8
  %v644 = load i64, ptr %slot114, align 8
  %op645 = add i64 %v643, %v644
  store i64 %op645, ptr %slot116, align 8
  %v646 = load i64, ptr %slot116, align 8
  %op647 = and i64 %v646, 4294967295
  store i64 %op647, ptr %slot117, align 8
  %v648 = load i64, ptr %slot116, align 8
  %op649 = lshr i64 %v648, 32
  store i64 %op649, ptr %slot118, align 8
  %v650 = load i64, ptr %slot109, align 8
  %v651 = load i64, ptr %slot112, align 8
  %op652 = mul i64 %v650, %v651
  store i64 %op652, ptr %slot119, align 8
  %v653 = load i64, ptr %slot119, align 8
  %v654 = load i64, ptr %slot117, align 8
  %op655 = add i64 %v653, %v654
  store i64 %op655, ptr %slot120, align 8
  %v656 = load i64, ptr %slot120, align 8
  %op657 = lshr i64 %v656, 32
  store i64 %op657, ptr %slot121, align 8
  %v658 = load i64, ptr %slot110, align 8
  %v659 = load i64, ptr %slot112, align 8
  %op660 = mul i64 %v658, %v659
  store i64 %op660, ptr %slot122, align 8
  %v661 = load i64, ptr %slot122, align 8
  %v662 = load i64, ptr %slot118, align 8
  %op663 = add i64 %v661, %v662
  store i64 %op663, ptr %slot123, align 8
  %v664 = load i64, ptr %slot123, align 8
  %v665 = load i64, ptr %slot121, align 8
  %op666 = add i64 %v664, %v665
  store i64 %op666, ptr %slot124, align 8
  %v667 = load i64, ptr %slot107, align 8
  %cmp668 = icmp slt i64 %v667, 0
  %cv669 = zext i1 %cmp668 to i64
  store i64 %cv669, ptr %slot125, align 8
  %v670 = load i64, ptr %slot106, align 8
  %cmp671 = icmp slt i64 %v670, 0
  %cv672 = zext i1 %cmp671 to i64
  store i64 %cv672, ptr %slot126, align 8
  %v673 = load i64, ptr %slot125, align 8
  %neg674 = sub i64 0, %v673
  store i64 %neg674, ptr %slot127, align 8
  %v675 = load i64, ptr %slot126, align 8
  %neg676 = sub i64 0, %v675
  store i64 %neg676, ptr %slot128, align 8
  %v677 = load i64, ptr %slot106, align 8
  %v678 = load i64, ptr %slot127, align 8
  %op679 = and i64 %v677, %v678
  store i64 %op679, ptr %slot129, align 8
  %v680 = load i64, ptr %slot107, align 8
  %v681 = load i64, ptr %slot128, align 8
  %op682 = and i64 %v680, %v681
  store i64 %op682, ptr %slot130, align 8
  %v683 = load i64, ptr %slot124, align 8
  %v684 = load i64, ptr %slot129, align 8
  %op685 = sub i64 %v683, %v684
  store i64 %op685, ptr %slot131, align 8
  %v686 = load i64, ptr %slot131, align 8
  %v687 = load i64, ptr %slot130, align 8
  %op688 = sub i64 %v686, %v687
  store i64 %op688, ptr %slot131, align 8
  %v689 = load i64, ptr %slot108, align 8
  %op690 = ashr i64 %v689, 63
  store i64 %op690, ptr %slot132, align 8
  %cv691 = zext i1 %ov626 to i64
  store i64 %cv691, ptr %slot133, align 8
  %v692 = load i64, ptr %slot133, align 8
  %cond693 = icmp ne i64 %v692, 0
  br i1 %cond693, label %bb_overflow110, label %bb_checked110
bb_overflow110:
  %v694 = load i64, ptr %slot1, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %v696 = load i64, ptr %slot107, align 8
  %v697 = load i64, ptr %slot106, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p695, i64 2, i64 %v696, i64 %v697, i64 64) nomerge, !dbg !120
  unreachable
bb_checked110:
  %v698 = load i64, ptr %slot108, align 8
  %v699 = load i64, ptr %slot17, align 8
  %p700 = inttoptr i64 %v699 to ptr
  store i64 %v698, ptr %p700, align 8, !alias.scope !3, !noalias !4
  %v701 = load i64, ptr %slot21, align 8
  store i64 %v701, ptr %slot134, align 8
  %v702 = load i64, ptr %slot24, align 8
  store i64 %v702, ptr %slot135, align 8
  %v703 = load i64, ptr %slot17, align 8
  store i64 %v703, ptr %slot136, align 8
  %v704 = load i64, ptr %slot134, align 8
  %p706 = inttoptr i64 %v704 to ptr
  %gep707 = getelementptr i8, ptr %p706, i64 0
  %op705 = ptrtoint ptr %gep707 to i64
  store i64 %op705, ptr %slot137, align 8
  %v708 = load i64, ptr %slot136, align 8
  %p709 = inttoptr i64 %v708 to ptr
  %ld710 = load i64, ptr %p709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld710, ptr %slot138, align 8
  %v711 = load i64, ptr %slot138, align 8
  %v712 = load i64, ptr %slot137, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i64 %v711, ptr %p713, align 8, !alias.scope !3, !noalias !4
  %v714 = load i64, ptr %slot134, align 8
  %v715 = load i64, ptr %slot17, align 8
  %p716 = inttoptr i64 %v715 to ptr
  store i64 %v714, ptr %p716, align 8, !alias.scope !3, !noalias !4
  %v717 = load i64, ptr %slot22, align 8
  store i64 %v717, ptr %slot139, align 8
  %v718 = load i64, ptr %slot139, align 8
  %p719 = inttoptr i64 %v718 to ptr
  store i64 0, ptr %p719, align 8, !alias.scope !3, !noalias !4
  %v720 = load i64, ptr %slot139, align 8
  %p722 = inttoptr i64 %v720 to ptr
  %gep723 = getelementptr i8, ptr %p722, i64 8
  %op721 = ptrtoint ptr %gep723 to i64
  store i64 %op721, ptr %slot140, align 8
  %v724 = load i64, ptr %slot140, align 8
  %p725 = inttoptr i64 %v724 to ptr
  store i64 0, ptr %p725, align 8, !alias.scope !3, !noalias !4
  %v726 = load i64, ptr %slot139, align 8
  %p727 = inttoptr i64 %v726 to ptr
  store i32 0, ptr %p727, align 4, !alias.scope !3, !noalias !4
  %v728 = load i64, ptr %slot10, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i32 1, ptr %p729, align 4, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot17, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i64, ptr %p731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld732, ptr %slot141, align 8
  %v733 = load i64, ptr %slot139, align 8
  %p735 = inttoptr i64 %v733 to ptr
  %gep736 = getelementptr i8, ptr %p735, i64 8
  %op734 = ptrtoint ptr %gep736 to i64
  store i64 %op734, ptr %slot142, align 8
  %v737 = load i64, ptr %slot24, align 8
  store i64 %v737, ptr %slot143, align 8
  %v738 = load i64, ptr %slot141, align 8
  %v739 = load i64, ptr %slot142, align 8
  %p740 = inttoptr i64 %v738 to ptr
  %p741 = inttoptr i64 %v739 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p741, ptr %p740, i64 8, i1 false)
  %v742 = load i64, ptr %slot139, align 8
  %v743 = load i64, ptr %slot17, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i64 %v742, ptr %p744, align 8, !alias.scope !3, !noalias !4
  %v745 = load i64, ptr %slot17, align 8
  %p746 = inttoptr i64 %v745 to ptr
  %ld747 = load i64, ptr %p746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld747, ptr %slot144, align 8
  %v748 = load i64, ptr %slot11, align 8
  store i64 %v748, ptr %slot145, align 8
  %v749 = load i64, ptr %slot144, align 8
  %v750 = load i64, ptr %slot145, align 8
  %p751 = inttoptr i64 %v749 to ptr
  %p752 = inttoptr i64 %v750 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p752, ptr %p751, i64 16, i1 false)
  %v753 = load i64, ptr %slot7, align 8
  %p754 = inttoptr i64 %v753 to ptr
  store i32 2, ptr %p754, align 4, !alias.scope !3, !noalias !4
  %v755 = load i64, ptr %slot6, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i32 1, ptr %p756, align 4, !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot145, align 8
  %v758 = load i64, ptr %slot17, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i64 %v757, ptr %p759, align 8, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot17, align 8
  %p761 = inttoptr i64 %v760 to ptr
  %ld762 = load i64, ptr %p761, align 8, !alias.scope !3, !noalias !4
  store i64 %ld762, ptr %slot146, align 8
  %v763 = load i64, ptr %slot17, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %ld765 = load i64, ptr %p764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld765, ptr %slot147, align 8
  %v766 = load i64, ptr %slot13, align 8
  store i64 %v766, ptr %slot148, align 8
  %v767 = load i64, ptr %slot24, align 8
  store i64 %v767, ptr %slot149, align 8
  %v768 = load i64, ptr %slot23, align 8
  %v769 = load i64, ptr %slot148, align 8
  %v770 = load i64, ptr %slot147, align 8
  %v771 = load i64, ptr %slot149, align 8
  %cv772 = trunc i64 %v771 to i32
  %call773 = call i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64 %v768, i64 %v769, i64 %v770, i32 %cv772) nomerge, !dbg !122
  store i32 %call773, ptr %slot150, align 8
  %v774 = load i32, ptr %slot150, align 8
  %cv775 = zext i32 %v774 to i64
  %cond776 = icmp ne i64 %cv775, 0
  br i1 %cond776, label %bb_rcsuccess157, label %bb_rcfailure157
bb_rcfailure157:
  %v777 = load i64, ptr %slot23, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %call779 = call i32 @myl_rc_take_failure(ptr %p778) nomerge, !dbg !122
  store i32 %call779, ptr %slot151, align 8
  %v780 = load i64, ptr %slot1, align 8
  %p781 = inttoptr i64 %v780 to ptr
  %v782 = load i32, ptr %slot151, align 8
  %call783 = call i32 @myl_qbe_rc_status(ptr %p781, i32 %v782) nomerge, !dbg !122
  store i32 %call783, ptr %slot152, align 8
  br label %bb_failure
bb_rcsuccess157:
  %v784 = load i64, ptr %slot6, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i32 0, ptr %p785, align 4, !alias.scope !3, !noalias !4
  %v786 = load i64, ptr %slot9, align 8
  %p787 = inttoptr i64 %v786 to ptr
  store i32 2, ptr %p787, align 4, !alias.scope !3, !noalias !4
  %v788 = load i64, ptr %slot8, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i32 1, ptr %p789, align 4, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot13, align 8
  store i64 %v790, ptr %slot153, align 8
  %v791 = load i64, ptr %slot8, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i32 0, ptr %p792, align 4, !alias.scope !3, !noalias !4
  %v793 = load i64, ptr %slot6, align 8
  %p794 = inttoptr i64 %v793 to ptr
  %ld795 = load i32, ptr %p794, align 4, !alias.scope !3, !noalias !4
  store i32 %ld795, ptr %slot154, align 8
  %v796 = load i32, ptr %slot154, align 8
  %cv797 = zext i32 %v796 to i64
  %cond798 = icmp ne i64 %cv797, 0
  br i1 %cond798, label %bb_rcslotdrop167, label %bb_rcslotdone167
bb_rcslotdrop167:
  %v799 = load i64, ptr %slot6, align 8
  %p800 = inttoptr i64 %v799 to ptr
  store i32 0, ptr %p800, align 4, !alias.scope !3, !noalias !4
  %v801 = load i64, ptr %slot11, align 8
  store i64 %v801, ptr %slot155, align 8
  %v802 = load i64, ptr %slot7, align 8
  %p803 = inttoptr i64 %v802 to ptr
  %ld804 = load i32, ptr %p803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld804, ptr %slot156, align 8
  %v805 = load i32, ptr %slot156, align 8
  %op806 = and i32 %v805, 28
  store i32 %op806, ptr %slot157, align 8
  %v807 = load i32, ptr %slot157, align 8
  %cv808 = zext i32 %v807 to i64
  %cond809 = icmp ne i64 %cv808, 0
  br i1 %cond809, label %bb_rcslotrole167, label %bb_rcslotowner167
bb_rcslotrole167:
  %v810 = load i64, ptr %slot23, align 8
  store i64 %v810, ptr %slot158, align 8
  %v811 = load i64, ptr %slot158, align 8
  %v812 = load i64, ptr %slot155, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64 %v811, i64 %v812) nomerge, !dbg !122
  br label %bb_rcslotdone167
bb_rcslotowner167:
  %v813 = load i64, ptr %slot23, align 8
  store i64 %v813, ptr %slot159, align 8
  %v814 = load i64, ptr %slot159, align 8
  %v815 = load i64, ptr %slot155, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64 %v814, i64 %v815) nomerge, !dbg !122
  br label %bb_rcslotdone167
bb_rcslotdone167:
  %v816 = load i64, ptr %slot153, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %ret818 = load { i64, i64 }, ptr %p817, align 8
  ret { i64, i64 } %ret818
bb_failure:
  %v819 = load i64, ptr %slot5, align 8
  %p820 = inttoptr i64 %v819 to ptr
  call void @llvm.memset.p0.i64(ptr %p820, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v821 = load i64, ptr %slot5, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ret823 = load { i64, i64 }, ptr %p822, align 8
  ret { i64, i64 } %ret823
bb_entry_failure:
  %v824 = load i64, ptr %slot5, align 8
  %p825 = inttoptr i64 %v824 to ptr
  call void @llvm.memset.p0.i64(ptr %p825, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v826 = load i64, ptr %slot5, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ret828 = load { i64, i64 }, ptr %p827, align 8
  ret { i64, i64 } %ret828
}

@myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee_meta = external global i8, align 8
@myl_lit_6aa0d7cbc5974fbf558d31cd0d56fc35358d28044055f5efa85445ac9711a167 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.smul.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64, i64)
declare i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee", linkageName: "myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14108202634774294030, i64 0, !"myl_f_79e87719c576752644632273b6bfca8138f845f8f8475c1ab94ca3c0511d77ee"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!112 = !DILocation(line: 4, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!114 = !DILocation(line: 15, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!116 = !DILocation(line: 19, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!118 = !DILocation(line: 20, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!120 = !DILocation(line: 23, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!122 = !DILocation(line: 26, column: 0, scope: !123)
