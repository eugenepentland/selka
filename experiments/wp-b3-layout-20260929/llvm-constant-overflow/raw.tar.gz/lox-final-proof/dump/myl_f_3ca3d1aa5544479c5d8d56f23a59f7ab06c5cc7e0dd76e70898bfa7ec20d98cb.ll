target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %callresult278 = alloca [16 x i8], align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v349 = load i64, ptr %slot1, align 8
  %op350 = add i64 %v349, 32
  store i64 %op350, ptr %slot5, align 8
  %mem351 = alloca i8, i64 8, align 8
  %ptr352 = ptrtoint ptr %mem351 to i64
  store i64 %ptr352, ptr %slot6, align 8
  %mem353 = alloca i8, i64 8, align 8
  %ptr354 = ptrtoint ptr %mem353 to i64
  store i64 %ptr354, ptr %slot7, align 8
  %mem355 = alloca i8, i64 8, align 8
  %ptr356 = ptrtoint ptr %mem355 to i64
  store i64 %ptr356, ptr %slot8, align 8
  %mem357 = alloca i8, i64 8, align 8
  %ptr358 = ptrtoint ptr %mem357 to i64
  store i64 %ptr358, ptr %slot9, align 8
  %mem359 = alloca i8, i64 8, align 8
  %ptr360 = ptrtoint ptr %mem359 to i64
  store i64 %ptr360, ptr %slot10, align 8
  %mem361 = alloca i8, i64 8, align 8
  %ptr362 = ptrtoint ptr %mem361 to i64
  store i64 %ptr362, ptr %slot11, align 8
  %mem363 = alloca i8, i64 208, align 8
  %ptr364 = ptrtoint ptr %mem363 to i64
  store i64 %ptr364, ptr %slot12, align 8
  %mem365 = alloca i8, i64 8, align 8
  %ptr366 = ptrtoint ptr %mem365 to i64
  store i64 %ptr366, ptr %slot13, align 8
  %mem367 = alloca i8, i64 8, align 8
  %ptr368 = ptrtoint ptr %mem367 to i64
  store i64 %ptr368, ptr %slot14, align 8
  %mem369 = alloca i8, i64 8, align 8
  %ptr370 = ptrtoint ptr %mem369 to i64
  store i64 %ptr370, ptr %slot15, align 8
  %mem371 = alloca i8, i64 8, align 8
  %ptr372 = ptrtoint ptr %mem371 to i64
  store i64 %ptr372, ptr %slot16, align 8
  %mem373 = alloca i8, i64 8, align 8
  %ptr374 = ptrtoint ptr %mem373 to i64
  store i64 %ptr374, ptr %slot17, align 8
  %mem375 = alloca i8, i64 8, align 8
  %ptr376 = ptrtoint ptr %mem375 to i64
  store i64 %ptr376, ptr %slot18, align 8
  %mem377 = alloca i8, i64 8, align 8
  %ptr378 = ptrtoint ptr %mem377 to i64
  store i64 %ptr378, ptr %slot19, align 8
  %mem379 = alloca i8, i64 8, align 8
  %ptr380 = ptrtoint ptr %mem379 to i64
  store i64 %ptr380, ptr %slot20, align 8
  %mem381 = alloca i8, i64 8, align 8
  %ptr382 = ptrtoint ptr %mem381 to i64
  store i64 %ptr382, ptr %slot21, align 8
  %mem383 = alloca i8, i64 32, align 8
  %ptr384 = ptrtoint ptr %mem383 to i64
  store i64 %ptr384, ptr %slot22, align 8
  %mem385 = alloca i8, i64 8, align 8
  %ptr386 = ptrtoint ptr %mem385 to i64
  store i64 %ptr386, ptr %slot23, align 8
  %mem387 = alloca i8, i64 8, align 8
  %ptr388 = ptrtoint ptr %mem387 to i64
  store i64 %ptr388, ptr %slot24, align 8
  %mem389 = alloca i8, i64 8, align 8
  %ptr390 = ptrtoint ptr %mem389 to i64
  store i64 %ptr390, ptr %slot25, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem391 = alloca i8, i64 8, align 8
  %ptr392 = ptrtoint ptr %mem391 to i64
  store i64 %ptr392, ptr %slot26, align 8
  %v393 = load i64, ptr %slot1, align 8
  %op394 = add i64 %v393, 64
  store i64 %op394, ptr %slot27, align 8
  %v395 = load i64, ptr %slot27, align 8
  %p396 = inttoptr i64 %v395 to ptr
  %ld397 = load i64, ptr %p396, align 8, !alias.scope !4, !noalias !3
  store i64 %ld397, ptr %slot28, align 8
  %stack398 = call ptr @llvm.stacksave()
  %stackaddr399 = ptrtoint ptr %stack398 to i64
  %v400 = load i64, ptr %slot28, align 8
  %cmp401 = icmp ult i64 %stackaddr399, %v400
  %cv402 = zext i1 %cmp401 to i64
  store i64 %cv402, ptr %slot29, align 8
  %v403 = load i64, ptr %slot29, align 8
  %cond404 = icmp ne i64 %v403, 0
  br i1 %cond404, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v405 = load i64, ptr %slot1, align 8
  %p406 = inttoptr i64 %v405 to ptr
  call void @myl_qbe_fail_frame(ptr %p406) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v407 = load i64, ptr %slot16, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i64 0, ptr %p408, align 8, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot17, align 8
  %p410 = inttoptr i64 %v409 to ptr
  store i64 0, ptr %p410, align 8, !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot20, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i64 0, ptr %p412, align 8, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot23, align 8
  %p414 = inttoptr i64 %v413 to ptr
  store i64 0, ptr %p414, align 8, !alias.scope !3, !noalias !4
  %v415 = load i64, ptr %slot2, align 8
  %v416 = load i64, ptr %slot13, align 8
  %p417 = inttoptr i64 %v416 to ptr
  store i64 %v415, ptr %p417, align 8, !alias.scope !3, !noalias !4
  %v418 = load i64, ptr %slot3, align 8
  %v419 = load i64, ptr %slot14, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i64 %v418, ptr %p420, align 8, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot4, align 8
  %v422 = load i64, ptr %slot15, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i64 %v421, ptr %p423, align 8, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot1, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %call426 = call ptr @myl_qbe_heap(ptr %p425) nomerge, !dbg !112
  %calladdr427 = ptrtoint ptr %call426 to i64
  store i64 %calladdr427, ptr %slot30, align 8
  %v428 = load i64, ptr %slot1, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %call430 = call i64 @myl_qbe_region_mark(ptr %p429) nomerge, !dbg !112
  store i64 %call430, ptr %slot31, align 8
  %v431 = load i64, ptr %slot6, align 8
  %p432 = inttoptr i64 %v431 to ptr
  store i32 0, ptr %p432, align 4, !alias.scope !3, !noalias !4
  %v433 = load i64, ptr %slot7, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i32 0, ptr %p434, align 4, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot8, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i32 0, ptr %p436, align 4, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot9, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i32 0, ptr %p438, align 4, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot10, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i32 0, ptr %p440, align 4, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot7, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i32 2, ptr %p442, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v443 = load i64, ptr %slot13, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i64, ptr %p444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld445, ptr %slot32, align 8
  %v446 = load i64, ptr %slot32, align 8
  %v447 = load i64, ptr %slot24, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i64 %v446, ptr %p448, align 8, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot24, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %ld451 = load i64, ptr %p450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld451, ptr %slot33, align 8
  %v452 = load i64, ptr %slot33, align 8
  %op453 = add i64 %v452, 32
  store i64 %op453, ptr %slot34, align 8
  %v454 = load i64, ptr %slot34, align 8
  %v455 = load i64, ptr %slot24, align 8
  %p456 = inttoptr i64 %v455 to ptr
  store i64 %v454, ptr %p456, align 8, !alias.scope !3, !noalias !4
  %v457 = load i64, ptr %slot24, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %ld459 = load i64, ptr %p458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld459, ptr %slot35, align 8
  %v460 = load i64, ptr %slot35, align 8
  %op461 = add i64 %v460, 0
  store i64 %op461, ptr %slot36, align 8
  %v462 = load i64, ptr %slot36, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i64, ptr %p463, align 8
  store i64 %ld464, ptr %slot37, align 8
  %v465 = load i64, ptr %slot37, align 8
  %v466 = load i64, ptr %slot24, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i64 %v465, ptr %p467, align 8, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot24, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %ld470 = load i64, ptr %p469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld470, ptr %slot38, align 8
  %v471 = load i64, ptr %slot38, align 8
  %v472 = load i64, ptr %slot11, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i64 %v471, ptr %p473, align 8, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot11, align 8
  store i64 %v474, ptr %slot39, align 8
  store i32 0, ptr %slot40, align 8
  %v475 = load i64, ptr %slot8, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %ld477 = load i32, ptr %p476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld477, ptr %slot41, align 8
  %v478 = load i32, ptr %slot41, align 8
  %op479 = and i32 %v478, 24
  store i32 %op479, ptr %slot41, align 8
  %v480 = load i32, ptr %slot41, align 8
  %cmp481 = icmp eq i32 %v480, 0
  %cv482 = zext i1 %cmp481 to i32
  store i32 %cv482, ptr %slot42, align 8
  %v483 = load i32, ptr %slot40, align 8
  %v484 = load i32, ptr %slot42, align 8
  %op485 = and i32 %v483, %v484
  store i32 %op485, ptr %slot43, align 8
  %v486 = load i32, ptr %slot43, align 8
  %cv487 = zext i32 %v486 to i64
  %cond488 = icmp ne i64 %cv487, 0
  br i1 %cond488, label %bb_rctake37, label %bb_rccopy37
bb_rctake37:
  %v489 = load i64, ptr %slot12, align 8
  store i64 %v489, ptr %slot44, align 8
  %v490 = load i64, ptr %slot31, align 8
  store i64 %v490, ptr %slot45, align 8
  %v491 = load i64, ptr %slot39, align 8
  %v492 = load i64, ptr %slot44, align 8
  %op493 = sub i64 %v491, %v492
  store i64 %op493, ptr %slot46, align 8
  %v494 = load i64, ptr %slot44, align 8
  %v495 = load i64, ptr %slot39, align 8
  %op496 = sub i64 %v494, %v495
  store i64 %op496, ptr %slot47, align 8
  %v497 = load i64, ptr %slot46, align 8
  %cmp498 = icmp ult i64 %v497, 8
  %cv499 = zext i1 %cmp498 to i32
  store i32 %cv499, ptr %slot48, align 8
  %v500 = load i64, ptr %slot47, align 8
  %cmp501 = icmp ult i64 %v500, 8
  %cv502 = zext i1 %cmp501 to i32
  store i32 %cv502, ptr %slot49, align 8
  %v503 = load i32, ptr %slot48, align 8
  %v504 = load i32, ptr %slot49, align 8
  %op505 = or i32 %v503, %v504
  store i32 %op505, ptr %slot50, align 8
  %v506 = load i32, ptr %slot50, align 8
  %cv507 = zext i32 %v506 to i64
  %cond508 = icmp ne i64 %cv507, 0
  br i1 %cond508, label %bb_rcmoveslow46, label %bb_rcmovecheck46
bb_rcmovecheck46:
  %v509 = load i64, ptr %slot39, align 8
  %p511 = inttoptr i64 %v509 to ptr
  %gep512 = getelementptr i8, ptr %p511, i64 0
  %op510 = ptrtoint ptr %gep512 to i64
  store i64 %op510, ptr %slot51, align 8
  %v513 = load i64, ptr %slot51, align 8
  %p514 = inttoptr i64 %v513 to ptr
  %ld515 = load i64, ptr %p514, align 8, !alias.scope !3, !noalias !4
  store i64 %ld515, ptr %slot52, align 8
  %v516 = load i64, ptr %slot52, align 8
  %cmp517 = icmp ne i64 %v516, 0
  %cv518 = zext i1 %cmp517 to i32
  store i32 %cv518, ptr %slot53, align 8
  %v519 = load i32, ptr %slot53, align 8
  %cv520 = zext i32 %v519 to i64
  %cond521 = icmp ne i64 %cv520, 0
  br i1 %cond521, label %bb_rcmoveheader54, label %bb_rcmovenext54
bb_rcmoveheader54:
  %v522 = load i64, ptr %slot52, align 8
  %op523 = sub i64 %v522, 16
  store i64 %op523, ptr %slot54, align 8
  %v524 = load i64, ptr %slot52, align 8
  %p525 = inttoptr i64 %v524 to ptr
  %rgep526 = getelementptr i8, ptr %p525, i64 -16
  %ld527 = load i64, ptr %rgep526, align 8, !alias.scope !9, !noalias !10
  store i64 %ld527, ptr %slot55, align 8
  %v528 = load i64, ptr %slot55, align 8
  %op529 = and i64 %v528, 5764607523034234881
  store i64 %op529, ptr %slot56, align 8
  %v530 = load i64, ptr %slot56, align 8
  %cmp531 = icmp ne i64 %v530, 0
  %cv532 = zext i1 %cmp531 to i32
  store i32 %cv532, ptr %slot57, align 8
  %v533 = load i32, ptr %slot57, align 8
  %cv534 = zext i32 %v533 to i64
  %cond535 = icmp ne i64 %cv534, 0
  br i1 %cond535, label %bb_rcmoveslow46, label %bb_rcmovenext54
bb_rcmovenext54:
  %v536 = load i64, ptr %slot39, align 8
  %v537 = load i64, ptr %slot44, align 8
  %p538 = inttoptr i64 %v536 to ptr
  %p539 = inttoptr i64 %v537 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p539, ptr %p538, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot39, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 0, ptr %p541, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved46
bb_rcmoveslow46:
  %v542 = load i64, ptr %slot30, align 8
  %v543 = load i64, ptr %slot44, align 8
  %v544 = load i64, ptr %slot39, align 8
  %v545 = load i64, ptr %slot45, align 8
  %cv546 = trunc i64 %v545 to i32
  %call547 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v542, i64 %v543, i64 %v544, i32 %cv546) nomerge, !dbg !114
  store i32 %call547, ptr %slot58, align 8
  %v548 = load i32, ptr %slot58, align 8
  %cv549 = zext i32 %v548 to i64
  %cond550 = icmp ne i64 %cv549, 0
  br i1 %cond550, label %bb_rcsuccess61, label %bb_rcfailure61
bb_rcfailure61:
  %v551 = load i64, ptr %slot30, align 8
  %p552 = inttoptr i64 %v551 to ptr
  %call553 = call i32 @myl_rc_take_failure(ptr %p552) nomerge, !dbg !114
  store i32 %call553, ptr %slot59, align 8
  %v554 = load i64, ptr %slot1, align 8
  %p555 = inttoptr i64 %v554 to ptr
  %v556 = load i32, ptr %slot59, align 8
  %call557 = call i32 @myl_qbe_rc_status(ptr %p555, i32 %v556) nomerge, !dbg !114
  store i32 %call557, ptr %slot60, align 8
  br label %bb_failure
bb_rcsuccess61:
  br label %bb_rcmoved46
bb_rcmoved46:
  %v558 = load i64, ptr %slot10, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i32 2, ptr %p559, align 4, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot9, align 8
  %p561 = inttoptr i64 %v560 to ptr
  store i32 1, ptr %p561, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared37
bb_rccopy37:
  %v562 = load i64, ptr %slot12, align 8
  store i64 %v562, ptr %slot61, align 8
  %v563 = load i64, ptr %slot31, align 8
  store i64 %v563, ptr %slot62, align 8
  %v564 = load i64, ptr %slot39, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %ld566 = load i64, ptr %p565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld566, ptr %slot63, align 8
  %v567 = load i64, ptr %slot63, align 8
  %cmp568 = icmp ne i64 %v567, 0
  %cv569 = zext i1 %cmp568 to i32
  store i32 %cv569, ptr %slot64, align 8
  %v570 = load i32, ptr %slot64, align 8
  %cv571 = zext i32 %v570 to i64
  %cond572 = icmp ne i64 %cv571, 0
  br i1 %cond572, label %bb_rcgnn70, label %bb_rcgplain70
bb_rcgnn70:
  %v573 = load i64, ptr %slot63, align 8
  %op574 = sub i64 %v573, 16
  store i64 %op574, ptr %slot65, align 8
  %v575 = load i64, ptr %slot63, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %rgep577 = getelementptr i8, ptr %p576, i64 -16
  %ld578 = load i64, ptr %rgep577, align 8, !alias.scope !9, !noalias !10
  store i64 %ld578, ptr %slot66, align 8
  %v579 = load i64, ptr %slot66, align 8
  %op580 = and i64 %v579, 4611686018427387906
  store i64 %op580, ptr %slot67, align 8
  %v581 = load i64, ptr %slot67, align 8
  %cmp582 = icmp ne i64 %v581, 0
  %cv583 = zext i1 %cmp582 to i32
  store i32 %cv583, ptr %slot68, align 8
  %v584 = load i32, ptr %slot68, align 8
  %cv585 = zext i32 %v584 to i64
  %cond586 = icmp ne i64 %cv585, 0
  br i1 %cond586, label %bb_rcgspecial70, label %bb_rcginc70
bb_rcginc70:
  %v587 = load i64, ptr %slot63, align 8
  %op588 = sub i64 %v587, 32
  store i64 %op588, ptr %slot69, align 8
  %v589 = load i64, ptr %slot63, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %rgep591 = getelementptr i8, ptr %p590, i64 -32
  %ld592 = load i64, ptr %rgep591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld592, ptr %slot70, align 8
  %v593 = load i64, ptr %slot70, align 8
  %op594 = add i64 %v593, 1
  store i64 %op594, ptr %slot71, align 8
  %v595 = load i64, ptr %slot71, align 8
  %cmp596 = icmp eq i64 %v595, 0
  %cv597 = zext i1 %cmp596 to i32
  store i32 %cv597, ptr %slot72, align 8
  %v598 = load i32, ptr %slot72, align 8
  %cv599 = zext i32 %v598 to i64
  %cond600 = icmp ne i64 %cv599, 0
  br i1 %cond600, label %bb_rcglimit70, label %bb_rcgcapacity70
bb_rcglimit70:
  %v601 = load i64, ptr %slot1, align 8
  %p602 = inttoptr i64 %v601 to ptr
  %call603 = call i32 @myl_qbe_rc_status(ptr %p602, i32 2) nomerge, !dbg !114
  store i32 %call603, ptr %slot73, align 8
  br label %bb_failure
bb_rcgcapacity70:
  %v604 = load i64, ptr %slot71, align 8
  %v605 = load i64, ptr %slot63, align 8
  %p606 = inttoptr i64 %v605 to ptr
  %rgep607 = getelementptr i8, ptr %p606, i64 -32
  store i64 %v604, ptr %rgep607, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain70
bb_rcgspecial70:
  %v608 = load i64, ptr %slot66, align 8
  %op609 = and i64 %v608, 4611686018427387904
  store i64 %op609, ptr %slot74, align 8
  %v610 = load i64, ptr %slot74, align 8
  %cmp611 = icmp ne i64 %v610, 0
  %cv612 = zext i1 %cmp611 to i32
  store i32 %cv612, ptr %slot75, align 8
  %v613 = load i32, ptr %slot75, align 8
  %cv614 = zext i32 %v613 to i64
  %cond615 = icmp ne i64 %cv614, 0
  br i1 %cond615, label %bb_rcgslow70, label %bb_rcgplain70
bb_rcgslow70:
  %v616 = load i64, ptr %slot30, align 8
  %v617 = load i64, ptr %slot61, align 8
  %v618 = load i64, ptr %slot39, align 8
  %v619 = load i64, ptr %slot62, align 8
  %cv620 = trunc i64 %v619 to i32
  %call621 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64 %v616, i64 %v617, i64 %v618, i32 %cv620) nomerge, !dbg !114
  store i32 %call621, ptr %slot76, align 8
  %v622 = load i32, ptr %slot76, align 8
  %cv623 = zext i32 %v622 to i64
  %cond624 = icmp ne i64 %cv623, 0
  br i1 %cond624, label %bb_rcsuccess84, label %bb_rcfailure84
bb_rcfailure84:
  %v625 = load i64, ptr %slot30, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %call627 = call i32 @myl_rc_take_failure(ptr %p626) nomerge, !dbg !114
  store i32 %call627, ptr %slot77, align 8
  %v628 = load i64, ptr %slot1, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %v630 = load i32, ptr %slot77, align 8
  %call631 = call i32 @myl_qbe_rc_status(ptr %p629, i32 %v630) nomerge, !dbg !114
  store i32 %call631, ptr %slot78, align 8
  br label %bb_failure
bb_rcsuccess84:
  br label %bb_rcgdone70
bb_rcgplain70:
  %v632 = load i64, ptr %slot63, align 8
  %v633 = load i64, ptr %slot61, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i64 %v632, ptr %p634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone70
bb_rcgdone70:
  %v635 = load i64, ptr %slot10, align 8
  %p636 = inttoptr i64 %v635 to ptr
  store i32 2, ptr %p636, align 4, !alias.scope !3, !noalias !4
  %v637 = load i64, ptr %slot9, align 8
  %p638 = inttoptr i64 %v637 to ptr
  store i32 1, ptr %p638, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared37
bb_rcprepared37:
  %v639 = load i64, ptr %slot6, align 8
  %p640 = inttoptr i64 %v639 to ptr
  %ld641 = load i32, ptr %p640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld641, ptr %slot79, align 8
  %v642 = load i32, ptr %slot79, align 8
  %cv643 = zext i32 %v642 to i64
  %cond644 = icmp ne i64 %cv643, 0
  br i1 %cond644, label %bb_rcslotdrop129, label %bb_rcslotdone129
bb_rcslotdrop129:
  %v645 = load i64, ptr %slot6, align 8
  %p646 = inttoptr i64 %v645 to ptr
  store i32 0, ptr %p646, align 4, !alias.scope !3, !noalias !4
  %v647 = load i64, ptr %slot16, align 8
  store i64 %v647, ptr %slot80, align 8
  %v648 = load i64, ptr %slot7, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i32, ptr %p649, align 4, !alias.scope !3, !noalias !4
  store i32 %ld650, ptr %slot81, align 8
  %v651 = load i32, ptr %slot81, align 8
  %op652 = and i32 %v651, 28
  store i32 %op652, ptr %slot82, align 8
  %v653 = load i32, ptr %slot82, align 8
  %cv654 = zext i32 %v653 to i64
  %cond655 = icmp ne i64 %cv654, 0
  br i1 %cond655, label %bb_rcslotrole129, label %bb_rcslotowner129
bb_rcslotrole129:
  %v656 = load i64, ptr %slot30, align 8
  store i64 %v656, ptr %slot83, align 8
  %v657 = load i64, ptr %slot80, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld659, ptr %slot84, align 8
  %v660 = load i64, ptr %slot84, align 8
  %cmp661 = icmp ne i64 %v660, 0
  %cv662 = zext i1 %cmp661 to i32
  store i32 %cv662, ptr %slot85, align 8
  %v663 = load i32, ptr %slot85, align 8
  %cv664 = zext i32 %v663 to i64
  %cond665 = icmp ne i64 %cv664, 0
  br i1 %cond665, label %bb_rcgnn145, label %bb_rcgdone145
bb_rcgnn145:
  %v666 = load i64, ptr %slot84, align 8
  %op667 = sub i64 %v666, 16
  store i64 %op667, ptr %slot86, align 8
  %v668 = load i64, ptr %slot84, align 8
  %p669 = inttoptr i64 %v668 to ptr
  %rgep670 = getelementptr i8, ptr %p669, i64 -16
  %ld671 = load i64, ptr %rgep670, align 8, !alias.scope !9, !noalias !10
  store i64 %ld671, ptr %slot87, align 8
  %v672 = load i64, ptr %slot87, align 8
  %op673 = and i64 %v672, 4611686018427387906
  store i64 %op673, ptr %slot88, align 8
  %v674 = load i64, ptr %slot88, align 8
  %cmp675 = icmp ne i64 %v674, 0
  %cv676 = zext i1 %cmp675 to i32
  store i32 %cv676, ptr %slot89, align 8
  %v677 = load i32, ptr %slot89, align 8
  %cv678 = zext i32 %v677 to i64
  %cond679 = icmp ne i64 %cv678, 0
  br i1 %cond679, label %bb_rcgclear145, label %bb_rcgcounted145
bb_rcgcounted145:
  %v680 = load i64, ptr %slot84, align 8
  %op681 = sub i64 %v680, 24
  store i64 %op681, ptr %slot90, align 8
  %v682 = load i64, ptr %slot84, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %rgep684 = getelementptr i8, ptr %p683, i64 -24
  %ld685 = load i64, ptr %rgep684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld685, ptr %slot91, align 8
  %v686 = load i64, ptr %slot91, align 8
  %op687 = sub i64 %v686, 1
  store i64 %op687, ptr %slot92, align 8
  %v688 = load i64, ptr %slot92, align 8
  %cmp689 = icmp eq i64 %v688, 0
  %cv690 = zext i1 %cmp689 to i32
  store i32 %cv690, ptr %slot93, align 8
  %v691 = load i32, ptr %slot93, align 8
  %cv692 = zext i32 %v691 to i64
  %cond693 = icmp ne i64 %cv692, 0
  br i1 %cond693, label %bb_rcglast145, label %bb_rcgdec145
bb_rcglast145:
  %v694 = load i64, ptr %slot84, align 8
  %op695 = sub i64 %v694, 32
  store i64 %op695, ptr %slot94, align 8
  %v696 = load i64, ptr %slot84, align 8
  %p697 = inttoptr i64 %v696 to ptr
  %rgep698 = getelementptr i8, ptr %p697, i64 -32
  %ld699 = load i64, ptr %rgep698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld699, ptr %slot95, align 8
  %v700 = load i64, ptr %slot95, align 8
  %cmp701 = icmp ne i64 %v700, 0
  %cv702 = zext i1 %cmp701 to i32
  store i32 %cv702, ptr %slot96, align 8
  %v703 = load i32, ptr %slot96, align 8
  %cv704 = zext i32 %v703 to i64
  %cond705 = icmp ne i64 %cv704, 0
  br i1 %cond705, label %bb_rcgdec145, label %bb_rcgslow145
bb_rcgslow145:
  %v706 = load i64, ptr %slot83, align 8
  %v707 = load i64, ptr %slot80, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v706, i64 %v707) nomerge, !dbg !114
  br label %bb_rcgdone145
bb_rcgdec145:
  %v708 = load i64, ptr %slot92, align 8
  %v709 = load i64, ptr %slot84, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %rgep711 = getelementptr i8, ptr %p710, i64 -24
  store i64 %v708, ptr %rgep711, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear145
bb_rcgclear145:
  %v712 = load i64, ptr %slot80, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i64 0, ptr %p713, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone145
bb_rcgdone145:
  br label %bb_rcslotdone129
bb_rcslotowner129:
  %v714 = load i64, ptr %slot30, align 8
  store i64 %v714, ptr %slot97, align 8
  %v715 = load i64, ptr %slot80, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %ld717 = load i64, ptr %p716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld717, ptr %slot98, align 8
  %v718 = load i64, ptr %slot98, align 8
  %cmp719 = icmp ne i64 %v718, 0
  %cv720 = zext i1 %cmp719 to i32
  store i32 %cv720, ptr %slot99, align 8
  %v721 = load i32, ptr %slot99, align 8
  %cv722 = zext i32 %v721 to i64
  %cond723 = icmp ne i64 %cv722, 0
  br i1 %cond723, label %bb_rcgnn160, label %bb_rcgdone160
bb_rcgnn160:
  %v724 = load i64, ptr %slot98, align 8
  %op725 = sub i64 %v724, 16
  store i64 %op725, ptr %slot100, align 8
  %v726 = load i64, ptr %slot98, align 8
  %p727 = inttoptr i64 %v726 to ptr
  %rgep728 = getelementptr i8, ptr %p727, i64 -16
  %ld729 = load i64, ptr %rgep728, align 8, !alias.scope !9, !noalias !10
  store i64 %ld729, ptr %slot101, align 8
  %v730 = load i64, ptr %slot101, align 8
  %op731 = and i64 %v730, 4611686018427387906
  store i64 %op731, ptr %slot102, align 8
  %v732 = load i64, ptr %slot102, align 8
  %cmp733 = icmp ne i64 %v732, 0
  %cv734 = zext i1 %cmp733 to i32
  store i32 %cv734, ptr %slot103, align 8
  %v735 = load i32, ptr %slot103, align 8
  %cv736 = zext i32 %v735 to i64
  %cond737 = icmp ne i64 %cv736, 0
  br i1 %cond737, label %bb_rcgclear160, label %bb_rcgcounted160
bb_rcgcounted160:
  %v738 = load i64, ptr %slot98, align 8
  %op739 = sub i64 %v738, 32
  store i64 %op739, ptr %slot104, align 8
  %v740 = load i64, ptr %slot98, align 8
  %p741 = inttoptr i64 %v740 to ptr
  %rgep742 = getelementptr i8, ptr %p741, i64 -32
  %ld743 = load i64, ptr %rgep742, align 8, !alias.scope !9, !noalias !10
  store i64 %ld743, ptr %slot105, align 8
  %v744 = load i64, ptr %slot105, align 8
  %op745 = sub i64 %v744, 1
  store i64 %op745, ptr %slot106, align 8
  %v746 = load i64, ptr %slot106, align 8
  %cmp747 = icmp eq i64 %v746, 0
  %cv748 = zext i1 %cmp747 to i32
  store i32 %cv748, ptr %slot107, align 8
  %v749 = load i32, ptr %slot107, align 8
  %cv750 = zext i32 %v749 to i64
  %cond751 = icmp ne i64 %cv750, 0
  br i1 %cond751, label %bb_rcglast160, label %bb_rcgdec160
bb_rcglast160:
  %v752 = load i64, ptr %slot98, align 8
  %op753 = sub i64 %v752, 24
  store i64 %op753, ptr %slot108, align 8
  %v754 = load i64, ptr %slot98, align 8
  %p755 = inttoptr i64 %v754 to ptr
  %rgep756 = getelementptr i8, ptr %p755, i64 -24
  %ld757 = load i64, ptr %rgep756, align 8, !alias.scope !9, !noalias !10
  store i64 %ld757, ptr %slot109, align 8
  %v758 = load i64, ptr %slot109, align 8
  %cmp759 = icmp ne i64 %v758, 0
  %cv760 = zext i1 %cmp759 to i32
  store i32 %cv760, ptr %slot110, align 8
  %v761 = load i32, ptr %slot110, align 8
  %cv762 = zext i32 %v761 to i64
  %cond763 = icmp ne i64 %cv762, 0
  br i1 %cond763, label %bb_rcgdec160, label %bb_rcgslow160
bb_rcgslow160:
  %v764 = load i64, ptr %slot97, align 8
  %v765 = load i64, ptr %slot80, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v764, i64 %v765) nomerge, !dbg !114
  br label %bb_rcgdone160
bb_rcgdec160:
  %v766 = load i64, ptr %slot106, align 8
  %v767 = load i64, ptr %slot98, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %rgep769 = getelementptr i8, ptr %p768, i64 -32
  store i64 %v766, ptr %rgep769, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear160
bb_rcgclear160:
  %v770 = load i64, ptr %slot80, align 8
  %p771 = inttoptr i64 %v770 to ptr
  store i64 0, ptr %p771, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone160
bb_rcgdone160:
  br label %bb_rcslotdone129
bb_rcslotdone129:
  %v772 = load i64, ptr %slot16, align 8
  store i64 %v772, ptr %slot111, align 8
  %v773 = load i64, ptr %slot12, align 8
  store i64 %v773, ptr %slot112, align 8
  %v774 = load i64, ptr %slot112, align 8
  %v775 = load i64, ptr %slot111, align 8
  %p776 = inttoptr i64 %v774 to ptr
  %p777 = inttoptr i64 %v775 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p777, ptr %p776, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v778 = load i64, ptr %slot9, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i32 0, ptr %p779, align 4, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot7, align 8
  %p781 = inttoptr i64 %v780 to ptr
  store i32 2, ptr %p781, align 4, !alias.scope !3, !noalias !4
  %v782 = load i64, ptr %slot10, align 8
  %p783 = inttoptr i64 %v782 to ptr
  %ld784 = load i32, ptr %p783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld784, ptr %slot113, align 8
  %v785 = load i32, ptr %slot113, align 8
  %v786 = load i64, ptr %slot7, align 8
  %p787 = inttoptr i64 %v786 to ptr
  store i32 %v785, ptr %p787, align 4, !alias.scope !3, !noalias !4
  %v788 = load i64, ptr %slot6, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i32 1, ptr %p789, align 4, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot13, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %ld792 = load i64, ptr %p791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld792, ptr %slot114, align 8
  %v793 = load i64, ptr %slot114, align 8
  %v794 = load i64, ptr %slot24, align 8
  %p795 = inttoptr i64 %v794 to ptr
  store i64 %v793, ptr %p795, align 8, !alias.scope !3, !noalias !4
  %v796 = load i64, ptr %slot24, align 8
  %p797 = inttoptr i64 %v796 to ptr
  %ld798 = load i64, ptr %p797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld798, ptr %slot115, align 8
  %v799 = load i64, ptr %slot115, align 8
  %op800 = add i64 %v799, 32
  store i64 %op800, ptr %slot116, align 8
  %v801 = load i64, ptr %slot116, align 8
  %v802 = load i64, ptr %slot24, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i64 %v801, ptr %p803, align 8, !alias.scope !3, !noalias !4
  %v804 = load i64, ptr %slot24, align 8
  %p805 = inttoptr i64 %v804 to ptr
  %ld806 = load i64, ptr %p805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld806, ptr %slot117, align 8
  %v807 = load i64, ptr %slot117, align 8
  %op808 = add i64 %v807, 8
  store i64 %op808, ptr %slot118, align 8
  %v809 = load i64, ptr %slot118, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %ld811 = load i64, ptr %p810, align 8
  store i64 %ld811, ptr %slot119, align 8
  %v812 = load i64, ptr %slot119, align 8
  %v813 = load i64, ptr %slot24, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i64 %v812, ptr %p814, align 8, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot25, align 8
  %p816 = inttoptr i64 %v815 to ptr
  store i64 0, ptr %p816, align 8, !alias.scope !3, !noalias !4
  %v817 = load i64, ptr %slot25, align 8
  %p818 = inttoptr i64 %v817 to ptr
  %ld819 = load i64, ptr %p818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld819, ptr %slot120, align 8
  %v820 = load i64, ptr %slot24, align 8
  %p821 = inttoptr i64 %v820 to ptr
  %ld822 = load i64, ptr %p821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld822, ptr %slot121, align 8
  %v823 = load i64, ptr %slot121, align 8
  %v824 = load i64, ptr %slot120, align 8
  %cmp825 = icmp eq i64 %v823, %v824
  %cv826 = zext i1 %cmp825 to i64
  store i64 %cv826, ptr %slot122, align 8
  %v827 = load i64, ptr %slot122, align 8
  %v828 = load i64, ptr %slot24, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 %v827, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot24, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %ld832 = load i64, ptr %p831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld832, ptr %slot123, align 8
  %v833 = load i64, ptr %slot123, align 8
  %cond834 = icmp ne i64 %v833, 0
  br i1 %cond834, label %bb_next199, label %bb_i13
bb_next199:
  %v835 = load i64, ptr %slot24, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i64 18446744073709551615, ptr %p836, align 8, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot24, align 8
  %p838 = inttoptr i64 %v837 to ptr
  %ld839 = load i64, ptr %p838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld839, ptr %slot124, align 8
  %v840 = load i64, ptr %slot6, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %ld842 = load i32, ptr %p841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld842, ptr %slot125, align 8
  %v843 = load i32, ptr %slot125, align 8
  %cv844 = zext i32 %v843 to i64
  %cond845 = icmp ne i64 %cv844, 0
  br i1 %cond845, label %bb_rcslotdrop242, label %bb_rcslotdone242
bb_rcslotdrop242:
  %v846 = load i64, ptr %slot6, align 8
  %p847 = inttoptr i64 %v846 to ptr
  store i32 0, ptr %p847, align 4, !alias.scope !3, !noalias !4
  %v848 = load i64, ptr %slot16, align 8
  store i64 %v848, ptr %slot126, align 8
  %v849 = load i64, ptr %slot7, align 8
  %p850 = inttoptr i64 %v849 to ptr
  %ld851 = load i32, ptr %p850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld851, ptr %slot127, align 8
  %v852 = load i32, ptr %slot127, align 8
  %op853 = and i32 %v852, 28
  store i32 %op853, ptr %slot128, align 8
  %v854 = load i32, ptr %slot128, align 8
  %cv855 = zext i32 %v854 to i64
  %cond856 = icmp ne i64 %cv855, 0
  br i1 %cond856, label %bb_rcslotrole242, label %bb_rcslotowner242
bb_rcslotrole242:
  %v857 = load i64, ptr %slot30, align 8
  store i64 %v857, ptr %slot129, align 8
  %v858 = load i64, ptr %slot126, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %ld860 = load i64, ptr %p859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld860, ptr %slot130, align 8
  %v861 = load i64, ptr %slot130, align 8
  %cmp862 = icmp ne i64 %v861, 0
  %cv863 = zext i1 %cmp862 to i32
  store i32 %cv863, ptr %slot131, align 8
  %v864 = load i32, ptr %slot131, align 8
  %cv865 = zext i32 %v864 to i64
  %cond866 = icmp ne i64 %cv865, 0
  br i1 %cond866, label %bb_rcgnn258, label %bb_rcgdone258
bb_rcgnn258:
  %v867 = load i64, ptr %slot130, align 8
  %op868 = sub i64 %v867, 16
  store i64 %op868, ptr %slot132, align 8
  %v869 = load i64, ptr %slot130, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %rgep871 = getelementptr i8, ptr %p870, i64 -16
  %ld872 = load i64, ptr %rgep871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld872, ptr %slot133, align 8
  %v873 = load i64, ptr %slot133, align 8
  %op874 = and i64 %v873, 4611686018427387906
  store i64 %op874, ptr %slot134, align 8
  %v875 = load i64, ptr %slot134, align 8
  %cmp876 = icmp ne i64 %v875, 0
  %cv877 = zext i1 %cmp876 to i32
  store i32 %cv877, ptr %slot135, align 8
  %v878 = load i32, ptr %slot135, align 8
  %cv879 = zext i32 %v878 to i64
  %cond880 = icmp ne i64 %cv879, 0
  br i1 %cond880, label %bb_rcgclear258, label %bb_rcgcounted258
bb_rcgcounted258:
  %v881 = load i64, ptr %slot130, align 8
  %op882 = sub i64 %v881, 24
  store i64 %op882, ptr %slot136, align 8
  %v883 = load i64, ptr %slot130, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %rgep885 = getelementptr i8, ptr %p884, i64 -24
  %ld886 = load i64, ptr %rgep885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld886, ptr %slot137, align 8
  %v887 = load i64, ptr %slot137, align 8
  %op888 = sub i64 %v887, 1
  store i64 %op888, ptr %slot138, align 8
  %v889 = load i64, ptr %slot138, align 8
  %cmp890 = icmp eq i64 %v889, 0
  %cv891 = zext i1 %cmp890 to i32
  store i32 %cv891, ptr %slot139, align 8
  %v892 = load i32, ptr %slot139, align 8
  %cv893 = zext i32 %v892 to i64
  %cond894 = icmp ne i64 %cv893, 0
  br i1 %cond894, label %bb_rcglast258, label %bb_rcgdec258
bb_rcglast258:
  %v895 = load i64, ptr %slot130, align 8
  %op896 = sub i64 %v895, 32
  store i64 %op896, ptr %slot140, align 8
  %v897 = load i64, ptr %slot130, align 8
  %p898 = inttoptr i64 %v897 to ptr
  %rgep899 = getelementptr i8, ptr %p898, i64 -32
  %ld900 = load i64, ptr %rgep899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld900, ptr %slot141, align 8
  %v901 = load i64, ptr %slot141, align 8
  %cmp902 = icmp ne i64 %v901, 0
  %cv903 = zext i1 %cmp902 to i32
  store i32 %cv903, ptr %slot142, align 8
  %v904 = load i32, ptr %slot142, align 8
  %cv905 = zext i32 %v904 to i64
  %cond906 = icmp ne i64 %cv905, 0
  br i1 %cond906, label %bb_rcgdec258, label %bb_rcgslow258
bb_rcgslow258:
  %v907 = load i64, ptr %slot129, align 8
  %v908 = load i64, ptr %slot126, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v907, i64 %v908) nomerge, !dbg !116
  br label %bb_rcgdone258
bb_rcgdec258:
  %v909 = load i64, ptr %slot138, align 8
  %v910 = load i64, ptr %slot130, align 8
  %p911 = inttoptr i64 %v910 to ptr
  %rgep912 = getelementptr i8, ptr %p911, i64 -24
  store i64 %v909, ptr %rgep912, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear258
bb_rcgclear258:
  %v913 = load i64, ptr %slot126, align 8
  %p914 = inttoptr i64 %v913 to ptr
  store i64 0, ptr %p914, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone258
bb_rcgdone258:
  br label %bb_rcslotdone242
bb_rcslotowner242:
  %v915 = load i64, ptr %slot30, align 8
  store i64 %v915, ptr %slot143, align 8
  %v916 = load i64, ptr %slot126, align 8
  %p917 = inttoptr i64 %v916 to ptr
  %ld918 = load i64, ptr %p917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld918, ptr %slot144, align 8
  %v919 = load i64, ptr %slot144, align 8
  %cmp920 = icmp ne i64 %v919, 0
  %cv921 = zext i1 %cmp920 to i32
  store i32 %cv921, ptr %slot145, align 8
  %v922 = load i32, ptr %slot145, align 8
  %cv923 = zext i32 %v922 to i64
  %cond924 = icmp ne i64 %cv923, 0
  br i1 %cond924, label %bb_rcgnn273, label %bb_rcgdone273
bb_rcgnn273:
  %v925 = load i64, ptr %slot144, align 8
  %op926 = sub i64 %v925, 16
  store i64 %op926, ptr %slot146, align 8
  %v927 = load i64, ptr %slot144, align 8
  %p928 = inttoptr i64 %v927 to ptr
  %rgep929 = getelementptr i8, ptr %p928, i64 -16
  %ld930 = load i64, ptr %rgep929, align 8, !alias.scope !9, !noalias !10
  store i64 %ld930, ptr %slot147, align 8
  %v931 = load i64, ptr %slot147, align 8
  %op932 = and i64 %v931, 4611686018427387906
  store i64 %op932, ptr %slot148, align 8
  %v933 = load i64, ptr %slot148, align 8
  %cmp934 = icmp ne i64 %v933, 0
  %cv935 = zext i1 %cmp934 to i32
  store i32 %cv935, ptr %slot149, align 8
  %v936 = load i32, ptr %slot149, align 8
  %cv937 = zext i32 %v936 to i64
  %cond938 = icmp ne i64 %cv937, 0
  br i1 %cond938, label %bb_rcgclear273, label %bb_rcgcounted273
bb_rcgcounted273:
  %v939 = load i64, ptr %slot144, align 8
  %op940 = sub i64 %v939, 32
  store i64 %op940, ptr %slot150, align 8
  %v941 = load i64, ptr %slot144, align 8
  %p942 = inttoptr i64 %v941 to ptr
  %rgep943 = getelementptr i8, ptr %p942, i64 -32
  %ld944 = load i64, ptr %rgep943, align 8, !alias.scope !9, !noalias !10
  store i64 %ld944, ptr %slot151, align 8
  %v945 = load i64, ptr %slot151, align 8
  %op946 = sub i64 %v945, 1
  store i64 %op946, ptr %slot152, align 8
  %v947 = load i64, ptr %slot152, align 8
  %cmp948 = icmp eq i64 %v947, 0
  %cv949 = zext i1 %cmp948 to i32
  store i32 %cv949, ptr %slot153, align 8
  %v950 = load i32, ptr %slot153, align 8
  %cv951 = zext i32 %v950 to i64
  %cond952 = icmp ne i64 %cv951, 0
  br i1 %cond952, label %bb_rcglast273, label %bb_rcgdec273
bb_rcglast273:
  %v953 = load i64, ptr %slot144, align 8
  %op954 = sub i64 %v953, 24
  store i64 %op954, ptr %slot154, align 8
  %v955 = load i64, ptr %slot144, align 8
  %p956 = inttoptr i64 %v955 to ptr
  %rgep957 = getelementptr i8, ptr %p956, i64 -24
  %ld958 = load i64, ptr %rgep957, align 8, !alias.scope !9, !noalias !10
  store i64 %ld958, ptr %slot155, align 8
  %v959 = load i64, ptr %slot155, align 8
  %cmp960 = icmp ne i64 %v959, 0
  %cv961 = zext i1 %cmp960 to i32
  store i32 %cv961, ptr %slot156, align 8
  %v962 = load i32, ptr %slot156, align 8
  %cv963 = zext i32 %v962 to i64
  %cond964 = icmp ne i64 %cv963, 0
  br i1 %cond964, label %bb_rcgdec273, label %bb_rcgslow273
bb_rcgslow273:
  %v965 = load i64, ptr %slot143, align 8
  %v966 = load i64, ptr %slot126, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v965, i64 %v966) nomerge, !dbg !116
  br label %bb_rcgdone273
bb_rcgdec273:
  %v967 = load i64, ptr %slot152, align 8
  %v968 = load i64, ptr %slot144, align 8
  %p969 = inttoptr i64 %v968 to ptr
  %rgep970 = getelementptr i8, ptr %p969, i64 -32
  store i64 %v967, ptr %rgep970, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear273
bb_rcgclear273:
  %v971 = load i64, ptr %slot126, align 8
  %p972 = inttoptr i64 %v971 to ptr
  store i64 0, ptr %p972, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone273
bb_rcgdone273:
  br label %bb_rcslotdone242
bb_rcslotdone242:
  %v973 = load i64, ptr %slot124, align 8
  ret i64 %v973
bb_i13:
  %v974 = load i64, ptr %slot16, align 8
  %p975 = inttoptr i64 %v974 to ptr
  %ld976 = load i64, ptr %p975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld976, ptr %slot157, align 8
  %v977 = load i64, ptr %slot157, align 8
  %v978 = load i64, ptr %slot24, align 8
  %p979 = inttoptr i64 %v978 to ptr
  store i64 %v977, ptr %p979, align 8, !alias.scope !3, !noalias !4
  %v980 = load i64, ptr %slot24, align 8
  %p981 = inttoptr i64 %v980 to ptr
  %ld982 = load i64, ptr %p981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld982, ptr %slot158, align 8
  %v983 = load i64, ptr %slot158, align 8
  %v984 = load i64, ptr %slot17, align 8
  %p985 = inttoptr i64 %v984 to ptr
  store i64 %v983, ptr %p985, align 8, !alias.scope !3, !noalias !4
  %v986 = load i64, ptr %slot17, align 8
  %p987 = inttoptr i64 %v986 to ptr
  %ld988 = load i64, ptr %p987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld988, ptr %slot159, align 8
  %v989 = load i64, ptr %slot159, align 8
  %op990 = add i64 %v989, 0
  store i64 %op990, ptr %slot160, align 8
  %v991 = load i64, ptr %slot160, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %ld993 = load i64, ptr %p992, align 8, !alias.scope !6, !noalias !7
  store i64 %ld993, ptr %slot161, align 8
  %v994 = load i64, ptr %slot161, align 8
  %v995 = load i64, ptr %slot24, align 8
  %p996 = inttoptr i64 %v995 to ptr
  store i64 %v994, ptr %p996, align 8, !alias.scope !3, !noalias !4
  %v997 = load i64, ptr %slot24, align 8
  %p998 = inttoptr i64 %v997 to ptr
  %ld999 = load i64, ptr %p998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld999, ptr %slot162, align 8
  %v1000 = load i64, ptr %slot162, align 8
  %cmp1001 = icmp ugt i64 %v1000, 9223372036854775807
  %cv1002 = zext i1 %cmp1001 to i64
  store i64 %cv1002, ptr %slot163, align 8
  %v1003 = load i64, ptr %slot163, align 8
  %cond1004 = icmp ne i64 %v1003, 0
  br i1 %cond1004, label %bb_cast_overflow330, label %bb_cast_ok330
bb_cast_overflow330:
  %v1005 = load i64, ptr %slot1, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  %v1007 = load i64, ptr %slot162, align 8
  call void @myl_qbe_fail_cast(ptr %p1006, i64 %v1007, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok330:
  %v1008 = load i64, ptr %slot162, align 8
  %v1009 = load i64, ptr %slot24, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  store i64 %v1008, ptr %p1010, align 8, !alias.scope !3, !noalias !4
  %v1011 = load i64, ptr %slot25, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  store i64 1, ptr %p1012, align 8, !alias.scope !3, !noalias !4
  %v1013 = load i64, ptr %slot25, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  %ld1015 = load i64, ptr %p1014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1015, ptr %slot164, align 8
  %v1016 = load i64, ptr %slot24, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %ld1018 = load i64, ptr %p1017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1018, ptr %slot165, align 8
  %v1019 = load i64, ptr %slot165, align 8
  %v1020 = load i64, ptr %slot164, align 8
  %ovpair1022 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1019, i64 %v1020)
  %op1021 = extractvalue { i64, i1 } %ovpair1022, 0
  %ov1023 = extractvalue { i64, i1 } %ovpair1022, 1
  store i64 %op1021, ptr %slot166, align 8
  %cv1024 = zext i1 %ov1023 to i64
  store i64 %cv1024, ptr %slot167, align 8
  %v1025 = load i64, ptr %slot167, align 8
  %cond1026 = icmp ne i64 %v1025, 0
  br i1 %cond1026, label %bb_overflow333, label %bb_checked333
bb_overflow333:
  %v1027 = load i64, ptr %slot1, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  %v1029 = load i64, ptr %slot165, align 8
  %v1030 = load i64, ptr %slot164, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1028, i64 1, i64 %v1029, i64 %v1030, i64 64) nomerge, !dbg !120
  unreachable
bb_checked333:
  %v1031 = load i64, ptr %slot166, align 8
  %v1032 = load i64, ptr %slot24, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  store i64 %v1031, ptr %p1033, align 8, !alias.scope !3, !noalias !4
  %v1034 = load i64, ptr %slot24, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i64, ptr %p1035, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1036, ptr %slot168, align 8
  %v1037 = load i64, ptr %slot168, align 8
  %v1038 = load i64, ptr %slot18, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  store i64 %v1037, ptr %p1039, align 8, !alias.scope !3, !noalias !4
  %v1040 = load i64, ptr %slot15, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %ld1042 = load i64, ptr %p1041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1042, ptr %slot169, align 8
  %v1043 = load i64, ptr %slot169, align 8
  %v1044 = load i64, ptr %slot24, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i64 %v1043, ptr %p1045, align 8, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot18, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %ld1048 = load i64, ptr %p1047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1048, ptr %slot170, align 8
  %v1049 = load i64, ptr %slot170, align 8
  %v1050 = load i64, ptr %slot25, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  store i64 %v1049, ptr %p1051, align 8, !alias.scope !3, !noalias !4
  %v1052 = load i64, ptr %slot25, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  %ld1054 = load i64, ptr %p1053, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1054, ptr %slot171, align 8
  %v1055 = load i64, ptr %slot171, align 8
  %cmp1056 = icmp slt i64 %v1055, 0
  %cv1057 = zext i1 %cmp1056 to i64
  store i64 %cv1057, ptr %slot172, align 8
  %v1058 = load i64, ptr %slot171, align 8
  %cmp1059 = icmp sgt i64 %v1058, 4294967295
  %cv1060 = zext i1 %cmp1059 to i64
  store i64 %cv1060, ptr %slot173, align 8
  %v1061 = load i64, ptr %slot172, align 8
  %v1062 = load i64, ptr %slot173, align 8
  %op1063 = or i64 %v1061, %v1062
  store i64 %op1063, ptr %slot174, align 8
  %v1064 = load i64, ptr %slot174, align 8
  %cond1065 = icmp ne i64 %v1064, 0
  br i1 %cond1065, label %bb_cast_overflow342, label %bb_cast_ok342
bb_cast_overflow342:
  %v1066 = load i64, ptr %slot1, align 8
  %p1067 = inttoptr i64 %v1066 to ptr
  %v1068 = load i64, ptr %slot171, align 8
  call void @myl_qbe_fail_cast(ptr %p1067, i64 %v1068, i64 32) nomerge, !dbg !122
  unreachable
bb_cast_ok342:
  %v1069 = load i64, ptr %slot171, align 8
  %v1070 = load i64, ptr %slot25, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  store i64 %v1069, ptr %p1071, align 8, !alias.scope !3, !noalias !4
  %v1072 = load i64, ptr %slot25, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i64, ptr %p1073, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1074, ptr %slot175, align 8
  %v1075 = load i64, ptr %slot24, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  %ld1077 = load i64, ptr %p1076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1077, ptr %slot176, align 8
  %v1078 = load i64, ptr %slot176, align 8
  %v1079 = load i64, ptr %slot175, align 8
  %op1080 = and i64 %v1078, %v1079
  store i64 %op1080, ptr %slot177, align 8
  %v1081 = load i64, ptr %slot177, align 8
  %op1082 = shl i64 %v1081, 32
  store i64 %op1082, ptr %slot178, align 8
  %v1083 = load i64, ptr %slot178, align 8
  %op1084 = lshr i64 %v1083, 32
  store i64 %op1084, ptr %slot179, align 8
  %v1085 = load i64, ptr %slot179, align 8
  %v1086 = load i64, ptr %slot24, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  store i64 %v1085, ptr %p1087, align 8, !alias.scope !3, !noalias !4
  %v1088 = load i64, ptr %slot24, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  %ld1090 = load i64, ptr %p1089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1090, ptr %slot180, align 8
  %v1091 = load i64, ptr %slot180, align 8
  %v1092 = load i64, ptr %slot24, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  store i64 %v1091, ptr %p1093, align 8, !alias.scope !3, !noalias !4
  %v1094 = load i64, ptr %slot24, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  %ld1096 = load i64, ptr %p1095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1096, ptr %slot181, align 8
  %v1097 = load i64, ptr %slot181, align 8
  %v1098 = load i64, ptr %slot19, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  store i64 %v1097, ptr %p1099, align 8, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_i26:
  %v1100 = load i64, ptr %slot16, align 8
  %p1101 = inttoptr i64 %v1100 to ptr
  %ld1102 = load i64, ptr %p1101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1102, ptr %slot182, align 8
  %v1103 = load i64, ptr %slot182, align 8
  %v1104 = load i64, ptr %slot24, align 8
  %p1105 = inttoptr i64 %v1104 to ptr
  store i64 %v1103, ptr %p1105, align 8, !alias.scope !3, !noalias !4
  %v1106 = load i64, ptr %slot24, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  %ld1108 = load i64, ptr %p1107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1108, ptr %slot183, align 8
  %v1109 = load i64, ptr %slot183, align 8
  %v1110 = load i64, ptr %slot20, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  store i64 %v1109, ptr %p1111, align 8, !alias.scope !3, !noalias !4
  %v1112 = load i64, ptr %slot19, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  %ld1114 = load i64, ptr %p1113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1114, ptr %slot184, align 8
  %v1115 = load i64, ptr %slot184, align 8
  %v1116 = load i64, ptr %slot24, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  store i64 %v1115, ptr %p1117, align 8, !alias.scope !3, !noalias !4
  %v1118 = load i64, ptr %slot24, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  %ld1120 = load i64, ptr %p1119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1120, ptr %slot185, align 8
  %v1121 = load i64, ptr %slot185, align 8
  %v1122 = load i64, ptr %slot21, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  store i64 %v1121, ptr %p1123, align 8, !alias.scope !3, !noalias !4
  %v1124 = load i64, ptr %slot21, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  %ld1126 = load i64, ptr %p1125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1126, ptr %slot186, align 8
  %v1127 = load i64, ptr %slot186, align 8
  %v1128 = load i64, ptr %slot24, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  store i64 %v1127, ptr %p1129, align 8, !alias.scope !3, !noalias !4
  %v1130 = load i64, ptr %slot25, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  store i64 0, ptr %p1131, align 8, !alias.scope !3, !noalias !4
  %v1132 = load i64, ptr %slot25, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  %ld1134 = load i64, ptr %p1133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1134, ptr %slot187, align 8
  %v1135 = load i64, ptr %slot24, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  %ld1137 = load i64, ptr %p1136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1137, ptr %slot188, align 8
  %v1138 = load i64, ptr %slot188, align 8
  %v1139 = load i64, ptr %slot187, align 8
  %cmp1140 = icmp slt i64 %v1138, %v1139
  %cv1141 = zext i1 %cmp1140 to i64
  store i64 %cv1141, ptr %slot189, align 8
  %v1142 = load i64, ptr %slot189, align 8
  %v1143 = load i64, ptr %slot24, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i64 %v1142, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  %v1145 = load i64, ptr %slot24, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  %ld1147 = load i64, ptr %p1146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1147, ptr %slot190, align 8
  %v1148 = load i64, ptr %slot190, align 8
  %cond1149 = icmp ne i64 %v1148, 0
  br i1 %cond1149, label %bb_next359, label %bb_i39
bb_next359:
  %v1150 = load i64, ptr %slot20, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i64, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1152, ptr %slot191, align 8
  %v1153 = load i64, ptr %slot191, align 8
  %op1154 = add i64 %v1153, 0
  store i64 %op1154, ptr %slot192, align 8
  %v1155 = load i64, ptr %slot192, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  %ld1157 = load i64, ptr %p1156, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1157, ptr %slot193, align 8
  %v1158 = load i64, ptr %slot193, align 8
  %v1159 = load i64, ptr %slot24, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  store i64 %v1158, ptr %p1160, align 8, !alias.scope !3, !noalias !4
  %v1161 = load i64, ptr %slot24, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  %ld1163 = load i64, ptr %p1162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1163, ptr %slot194, align 8
  %v1164 = load i64, ptr %slot194, align 8
  %cmp1165 = icmp ugt i64 %v1164, 9223372036854775807
  %cv1166 = zext i1 %cmp1165 to i64
  store i64 %cv1166, ptr %slot195, align 8
  %v1167 = load i64, ptr %slot195, align 8
  %cond1168 = icmp ne i64 %v1167, 0
  br i1 %cond1168, label %bb_cast_overflow364, label %bb_cast_ok364
bb_cast_overflow364:
  %v1169 = load i64, ptr %slot1, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  %v1171 = load i64, ptr %slot194, align 8
  call void @myl_qbe_fail_cast(ptr %p1170, i64 %v1171, i64 320) nomerge, !dbg !124
  unreachable
bb_cast_ok364:
  %v1172 = load i64, ptr %slot194, align 8
  %v1173 = load i64, ptr %slot24, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  store i64 %v1172, ptr %p1174, align 8, !alias.scope !3, !noalias !4
  %v1175 = load i64, ptr %slot21, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  %ld1177 = load i64, ptr %p1176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1177, ptr %slot196, align 8
  %v1178 = load i64, ptr %slot196, align 8
  %v1179 = load i64, ptr %slot25, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  store i64 %v1178, ptr %p1180, align 8, !alias.scope !3, !noalias !4
  %v1181 = load i64, ptr %slot25, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %ld1183 = load i64, ptr %p1182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1183, ptr %slot197, align 8
  %v1184 = load i64, ptr %slot24, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  %ld1186 = load i64, ptr %p1185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1186, ptr %slot198, align 8
  %v1187 = load i64, ptr %slot198, align 8
  %v1188 = load i64, ptr %slot197, align 8
  %ovpair1190 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1187, i64 %v1188)
  %op1189 = extractvalue { i64, i1 } %ovpair1190, 0
  %ov1191 = extractvalue { i64, i1 } %ovpair1190, 1
  store i64 %op1189, ptr %slot199, align 8
  %v1192 = load i64, ptr %slot198, align 8
  %v1193 = load i64, ptr %slot199, align 8
  %op1194 = xor i64 %v1192, %v1193
  store i64 %op1194, ptr %slot200, align 8
  %v1195 = load i64, ptr %slot197, align 8
  %v1196 = load i64, ptr %slot199, align 8
  %op1197 = xor i64 %v1195, %v1196
  store i64 %op1197, ptr %slot201, align 8
  %v1198 = load i64, ptr %slot200, align 8
  %v1199 = load i64, ptr %slot201, align 8
  %op1200 = and i64 %v1198, %v1199
  store i64 %op1200, ptr %slot202, align 8
  %cv1201 = zext i1 %ov1191 to i64
  store i64 %cv1201, ptr %slot203, align 8
  %v1202 = load i64, ptr %slot203, align 8
  %cond1203 = icmp ne i64 %v1202, 0
  br i1 %cond1203, label %bb_overflow368, label %bb_checked368
bb_overflow368:
  %v1204 = load i64, ptr %slot1, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  %v1206 = load i64, ptr %slot198, align 8
  %v1207 = load i64, ptr %slot197, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1205, i64 0, i64 %v1206, i64 %v1207, i64 64) nomerge, !dbg !126
  unreachable
bb_checked368:
  %v1208 = load i64, ptr %slot199, align 8
  %v1209 = load i64, ptr %slot24, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i64 %v1208, ptr %p1210, align 8, !alias.scope !3, !noalias !4
  %v1211 = load i64, ptr %slot24, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  %ld1213 = load i64, ptr %p1212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1213, ptr %slot204, align 8
  %v1214 = load i64, ptr %slot204, align 8
  %v1215 = load i64, ptr %slot21, align 8
  %p1216 = inttoptr i64 %v1215 to ptr
  store i64 %v1214, ptr %p1216, align 8, !alias.scope !3, !noalias !4
  br label %bb_i39
bb_i39:
  %v1217 = load i64, ptr %slot21, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  %ld1219 = load i64, ptr %p1218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1219, ptr %slot205, align 8
  %v1220 = load i64, ptr %slot205, align 8
  %v1221 = load i64, ptr %slot24, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  store i64 %v1220, ptr %p1222, align 8, !alias.scope !3, !noalias !4
  %v1223 = load i64, ptr %slot20, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  %ld1225 = load i64, ptr %p1224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1225, ptr %slot206, align 8
  %v1226 = load i64, ptr %slot24, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  %ld1228 = load i64, ptr %p1227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1228, ptr %slot207, align 8
  %v1229 = load i64, ptr %slot206, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  %ld1231 = load i64, ptr %p1230, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1231, ptr %slot208, align 8
  %v1232 = load i64, ptr %slot207, align 8
  %v1233 = load i64, ptr %slot208, align 8
  %cmp1234 = icmp ult i64 %v1232, %v1233
  %cv1235 = zext i1 %cmp1234 to i64
  store i64 %cv1235, ptr %slot209, align 8
  %v1236 = load i64, ptr %slot209, align 8
  %cond1237 = icmp ne i64 %v1236, 0
  br i1 %cond1237, label %bb_success380, label %bb_failed380
bb_failed380:
  %v1238 = load i64, ptr %slot1, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  %v1240 = load i64, ptr %slot207, align 8
  %v1241 = load i64, ptr %slot208, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1239, i64 %v1240, i64 %v1241) nomerge, !dbg !128
  unreachable
bb_success380:
  %v1242 = load i64, ptr %slot206, align 8
  %op1243 = add i64 %v1242, 32
  store i64 %op1243, ptr %slot210, align 8
  %v1244 = load i64, ptr %slot210, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %ld1246 = load i64, ptr %p1245, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1246, ptr %slot211, align 8
  %v1247 = load i64, ptr %slot207, align 8
  %op1248 = mul i64 %v1247, 32
  store i64 %op1248, ptr %slot212, align 8
  %v1249 = load i64, ptr %slot211, align 8
  %v1250 = load i64, ptr %slot212, align 8
  %op1251 = add i64 %v1249, %v1250
  store i64 %op1251, ptr %slot213, align 8
  %v1252 = load i64, ptr %slot213, align 8
  %v1253 = load i64, ptr %slot24, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  store i64 %v1252, ptr %p1254, align 8, !alias.scope !3, !noalias !4
  %v1255 = load i64, ptr %slot24, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  %ld1257 = load i64, ptr %p1256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1257, ptr %slot214, align 8
  %v1258 = load i64, ptr %slot214, align 8
  %v1259 = load i64, ptr %slot22, align 8
  %p1260 = inttoptr i64 %v1258 to ptr
  %p1261 = inttoptr i64 %v1259 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1261, ptr %p1260, i64 32, i1 false)
  %v1262 = load i64, ptr %slot22, align 8
  %v1263 = load i64, ptr %slot24, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  store i64 %v1262, ptr %p1264, align 8, !alias.scope !3, !noalias !4
  %v1265 = load i64, ptr %slot24, align 8
  %p1266 = inttoptr i64 %v1265 to ptr
  %ld1267 = load i64, ptr %p1266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1267, ptr %slot215, align 8
  %v1268 = load i64, ptr %slot215, align 8
  %op1269 = add i64 %v1268, 0
  store i64 %op1269, ptr %slot216, align 8
  %v1270 = load i64, ptr %slot216, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  %ld1272 = load i64, ptr %p1271, align 8
  store i64 %ld1272, ptr %slot217, align 8
  %v1273 = load i64, ptr %slot217, align 8
  %v1274 = load i64, ptr %slot24, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i64 %v1273, ptr %p1275, align 8, !alias.scope !3, !noalias !4
  %v1276 = load i64, ptr %slot25, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  store i64 18446744073709551615, ptr %p1277, align 8, !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot25, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  %ld1280 = load i64, ptr %p1279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1280, ptr %slot218, align 8
  %v1281 = load i64, ptr %slot24, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  %ld1283 = load i64, ptr %p1282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1283, ptr %slot219, align 8
  %v1284 = load i64, ptr %slot219, align 8
  %v1285 = load i64, ptr %slot218, align 8
  %cmp1286 = icmp eq i64 %v1284, %v1285
  %cv1287 = zext i1 %cmp1286 to i64
  store i64 %cv1287, ptr %slot220, align 8
  %v1288 = load i64, ptr %slot220, align 8
  %v1289 = load i64, ptr %slot24, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  store i64 %v1288, ptr %p1290, align 8, !alias.scope !3, !noalias !4
  %v1291 = load i64, ptr %slot24, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  %ld1293 = load i64, ptr %p1292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1293, ptr %slot221, align 8
  %v1294 = load i64, ptr %slot221, align 8
  %cond1295 = icmp ne i64 %v1294, 0
  br i1 %cond1295, label %bb_next393, label %bb_i56
bb_next393:
  %v1296 = load i64, ptr %slot22, align 8
  %v1297 = load i64, ptr %slot24, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  store i64 %v1296, ptr %p1298, align 8, !alias.scope !3, !noalias !4
  %v1299 = load i64, ptr %slot24, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  %ld1301 = load i64, ptr %p1300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1301, ptr %slot222, align 8
  %v1302 = load i64, ptr %slot222, align 8
  %op1303 = add i64 %v1302, 16
  store i64 %op1303, ptr %slot223, align 8
  %v1304 = load i64, ptr %slot223, align 8
  %v1305 = load i64, ptr %slot24, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  store i64 %v1304, ptr %p1306, align 8, !alias.scope !3, !noalias !4
  %v1307 = load i64, ptr %slot24, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  %ld1309 = load i64, ptr %p1308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1309, ptr %slot224, align 8
  %v1310 = load i64, ptr %slot224, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  %ld1312 = load i32, ptr %p1311, align 4
  %ext1313 = zext i32 %ld1312 to i64
  store i64 %ext1313, ptr %slot225, align 8
  %v1314 = load i64, ptr %slot225, align 8
  %cmp1315 = icmp eq i64 %v1314, 0
  %cv1316 = zext i1 %cmp1315 to i64
  store i64 %cv1316, ptr %slot226, align 8
  %v1317 = load i64, ptr %slot226, align 8
  %cond1318 = icmp ne i64 %v1317, 0
  br i1 %cond1318, label %bb_rcarm397, label %bb_rcarmnext397
bb_rcarm397:
  br label %bb_i50
bb_rcarmnext397:
  %v1319 = load i64, ptr %slot225, align 8
  %cmp1320 = icmp eq i64 %v1319, 1
  %cv1321 = zext i1 %cmp1320 to i64
  store i64 %cv1321, ptr %slot227, align 8
  %v1322 = load i64, ptr %slot227, align 8
  %cond1323 = icmp ne i64 %v1322, 0
  br i1 %cond1323, label %bb_rcarm398, label %bb_rcarmnext398
bb_rcarm398:
  br label %bb_i52
bb_rcarmnext398:
  %v1324 = load i64, ptr %slot225, align 8
  %cmp1325 = icmp eq i64 %v1324, 2
  %cv1326 = zext i1 %cmp1325 to i64
  store i64 %cv1326, ptr %slot228, align 8
  %v1327 = load i64, ptr %slot228, align 8
  %cond1328 = icmp ne i64 %v1327, 0
  br i1 %cond1328, label %bb_rcarm399, label %bb_rcarmnext399
bb_rcarm399:
  br label %bb_i53
bb_rcarmnext399:
  %v1329 = load i64, ptr %slot225, align 8
  %cmp1330 = icmp eq i64 %v1329, 3
  %cv1331 = zext i1 %cmp1330 to i64
  store i64 %cv1331, ptr %slot229, align 8
  %v1332 = load i64, ptr %slot229, align 8
  %cond1333 = icmp ne i64 %v1332, 0
  br i1 %cond1333, label %bb_rcarm400, label %bb_rcarmnext400
bb_rcarm400:
  br label %bb_i54
bb_rcarmnext400:
  br label %bb_failure
bb_i50:
  %v1334 = load i64, ptr %slot24, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i64 18446744073709551615, ptr %p1335, align 8, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot24, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  %ld1338 = load i64, ptr %p1337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1338, ptr %slot230, align 8
  %v1339 = load i64, ptr %slot6, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  %ld1341 = load i32, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1341, ptr %slot231, align 8
  %v1342 = load i32, ptr %slot231, align 8
  %cv1343 = zext i32 %v1342 to i64
  %cond1344 = icmp ne i64 %cv1343, 0
  br i1 %cond1344, label %bb_rcslotdrop444, label %bb_rcslotdone444
bb_rcslotdrop444:
  %v1345 = load i64, ptr %slot6, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  store i32 0, ptr %p1346, align 4, !alias.scope !3, !noalias !4
  %v1347 = load i64, ptr %slot16, align 8
  store i64 %v1347, ptr %slot232, align 8
  %v1348 = load i64, ptr %slot7, align 8
  %p1349 = inttoptr i64 %v1348 to ptr
  %ld1350 = load i32, ptr %p1349, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1350, ptr %slot233, align 8
  %v1351 = load i32, ptr %slot233, align 8
  %op1352 = and i32 %v1351, 28
  store i32 %op1352, ptr %slot234, align 8
  %v1353 = load i32, ptr %slot234, align 8
  %cv1354 = zext i32 %v1353 to i64
  %cond1355 = icmp ne i64 %cv1354, 0
  br i1 %cond1355, label %bb_rcslotrole444, label %bb_rcslotowner444
bb_rcslotrole444:
  %v1356 = load i64, ptr %slot30, align 8
  store i64 %v1356, ptr %slot235, align 8
  %v1357 = load i64, ptr %slot232, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  %ld1359 = load i64, ptr %p1358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1359, ptr %slot236, align 8
  %v1360 = load i64, ptr %slot236, align 8
  %cmp1361 = icmp ne i64 %v1360, 0
  %cv1362 = zext i1 %cmp1361 to i32
  store i32 %cv1362, ptr %slot237, align 8
  %v1363 = load i32, ptr %slot237, align 8
  %cv1364 = zext i32 %v1363 to i64
  %cond1365 = icmp ne i64 %cv1364, 0
  br i1 %cond1365, label %bb_rcgnn460, label %bb_rcgdone460
bb_rcgnn460:
  %v1366 = load i64, ptr %slot236, align 8
  %op1367 = sub i64 %v1366, 16
  store i64 %op1367, ptr %slot238, align 8
  %v1368 = load i64, ptr %slot236, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  %rgep1370 = getelementptr i8, ptr %p1369, i64 -16
  %ld1371 = load i64, ptr %rgep1370, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1371, ptr %slot239, align 8
  %v1372 = load i64, ptr %slot239, align 8
  %op1373 = and i64 %v1372, 4611686018427387906
  store i64 %op1373, ptr %slot240, align 8
  %v1374 = load i64, ptr %slot240, align 8
  %cmp1375 = icmp ne i64 %v1374, 0
  %cv1376 = zext i1 %cmp1375 to i32
  store i32 %cv1376, ptr %slot241, align 8
  %v1377 = load i32, ptr %slot241, align 8
  %cv1378 = zext i32 %v1377 to i64
  %cond1379 = icmp ne i64 %cv1378, 0
  br i1 %cond1379, label %bb_rcgclear460, label %bb_rcgcounted460
bb_rcgcounted460:
  %v1380 = load i64, ptr %slot236, align 8
  %op1381 = sub i64 %v1380, 24
  store i64 %op1381, ptr %slot242, align 8
  %v1382 = load i64, ptr %slot236, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %rgep1384 = getelementptr i8, ptr %p1383, i64 -24
  %ld1385 = load i64, ptr %rgep1384, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1385, ptr %slot243, align 8
  %v1386 = load i64, ptr %slot243, align 8
  %op1387 = sub i64 %v1386, 1
  store i64 %op1387, ptr %slot244, align 8
  %v1388 = load i64, ptr %slot244, align 8
  %cmp1389 = icmp eq i64 %v1388, 0
  %cv1390 = zext i1 %cmp1389 to i32
  store i32 %cv1390, ptr %slot245, align 8
  %v1391 = load i32, ptr %slot245, align 8
  %cv1392 = zext i32 %v1391 to i64
  %cond1393 = icmp ne i64 %cv1392, 0
  br i1 %cond1393, label %bb_rcglast460, label %bb_rcgdec460
bb_rcglast460:
  %v1394 = load i64, ptr %slot236, align 8
  %op1395 = sub i64 %v1394, 32
  store i64 %op1395, ptr %slot246, align 8
  %v1396 = load i64, ptr %slot236, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  %rgep1398 = getelementptr i8, ptr %p1397, i64 -32
  %ld1399 = load i64, ptr %rgep1398, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1399, ptr %slot247, align 8
  %v1400 = load i64, ptr %slot247, align 8
  %cmp1401 = icmp ne i64 %v1400, 0
  %cv1402 = zext i1 %cmp1401 to i32
  store i32 %cv1402, ptr %slot248, align 8
  %v1403 = load i32, ptr %slot248, align 8
  %cv1404 = zext i32 %v1403 to i64
  %cond1405 = icmp ne i64 %cv1404, 0
  br i1 %cond1405, label %bb_rcgdec460, label %bb_rcgslow460
bb_rcgslow460:
  %v1406 = load i64, ptr %slot235, align 8
  %v1407 = load i64, ptr %slot232, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v1406, i64 %v1407) nomerge, !dbg !130
  br label %bb_rcgdone460
bb_rcgdec460:
  %v1408 = load i64, ptr %slot244, align 8
  %v1409 = load i64, ptr %slot236, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  %rgep1411 = getelementptr i8, ptr %p1410, i64 -24
  store i64 %v1408, ptr %rgep1411, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear460
bb_rcgclear460:
  %v1412 = load i64, ptr %slot232, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  store i64 0, ptr %p1413, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone460
bb_rcgdone460:
  br label %bb_rcslotdone444
bb_rcslotowner444:
  %v1414 = load i64, ptr %slot30, align 8
  store i64 %v1414, ptr %slot249, align 8
  %v1415 = load i64, ptr %slot232, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  %ld1417 = load i64, ptr %p1416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1417, ptr %slot250, align 8
  %v1418 = load i64, ptr %slot250, align 8
  %cmp1419 = icmp ne i64 %v1418, 0
  %cv1420 = zext i1 %cmp1419 to i32
  store i32 %cv1420, ptr %slot251, align 8
  %v1421 = load i32, ptr %slot251, align 8
  %cv1422 = zext i32 %v1421 to i64
  %cond1423 = icmp ne i64 %cv1422, 0
  br i1 %cond1423, label %bb_rcgnn475, label %bb_rcgdone475
bb_rcgnn475:
  %v1424 = load i64, ptr %slot250, align 8
  %op1425 = sub i64 %v1424, 16
  store i64 %op1425, ptr %slot252, align 8
  %v1426 = load i64, ptr %slot250, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  %rgep1428 = getelementptr i8, ptr %p1427, i64 -16
  %ld1429 = load i64, ptr %rgep1428, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1429, ptr %slot253, align 8
  %v1430 = load i64, ptr %slot253, align 8
  %op1431 = and i64 %v1430, 4611686018427387906
  store i64 %op1431, ptr %slot254, align 8
  %v1432 = load i64, ptr %slot254, align 8
  %cmp1433 = icmp ne i64 %v1432, 0
  %cv1434 = zext i1 %cmp1433 to i32
  store i32 %cv1434, ptr %slot255, align 8
  %v1435 = load i32, ptr %slot255, align 8
  %cv1436 = zext i32 %v1435 to i64
  %cond1437 = icmp ne i64 %cv1436, 0
  br i1 %cond1437, label %bb_rcgclear475, label %bb_rcgcounted475
bb_rcgcounted475:
  %v1438 = load i64, ptr %slot250, align 8
  %op1439 = sub i64 %v1438, 32
  store i64 %op1439, ptr %slot256, align 8
  %v1440 = load i64, ptr %slot250, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %rgep1442 = getelementptr i8, ptr %p1441, i64 -32
  %ld1443 = load i64, ptr %rgep1442, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1443, ptr %slot257, align 8
  %v1444 = load i64, ptr %slot257, align 8
  %op1445 = sub i64 %v1444, 1
  store i64 %op1445, ptr %slot258, align 8
  %v1446 = load i64, ptr %slot258, align 8
  %cmp1447 = icmp eq i64 %v1446, 0
  %cv1448 = zext i1 %cmp1447 to i32
  store i32 %cv1448, ptr %slot259, align 8
  %v1449 = load i32, ptr %slot259, align 8
  %cv1450 = zext i32 %v1449 to i64
  %cond1451 = icmp ne i64 %cv1450, 0
  br i1 %cond1451, label %bb_rcglast475, label %bb_rcgdec475
bb_rcglast475:
  %v1452 = load i64, ptr %slot250, align 8
  %op1453 = sub i64 %v1452, 24
  store i64 %op1453, ptr %slot260, align 8
  %v1454 = load i64, ptr %slot250, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %rgep1456 = getelementptr i8, ptr %p1455, i64 -24
  %ld1457 = load i64, ptr %rgep1456, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1457, ptr %slot261, align 8
  %v1458 = load i64, ptr %slot261, align 8
  %cmp1459 = icmp ne i64 %v1458, 0
  %cv1460 = zext i1 %cmp1459 to i32
  store i32 %cv1460, ptr %slot262, align 8
  %v1461 = load i32, ptr %slot262, align 8
  %cv1462 = zext i32 %v1461 to i64
  %cond1463 = icmp ne i64 %cv1462, 0
  br i1 %cond1463, label %bb_rcgdec475, label %bb_rcgslow475
bb_rcgslow475:
  %v1464 = load i64, ptr %slot249, align 8
  %v1465 = load i64, ptr %slot232, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1464, i64 %v1465) nomerge, !dbg !130
  br label %bb_rcgdone475
bb_rcgdec475:
  %v1466 = load i64, ptr %slot258, align 8
  %v1467 = load i64, ptr %slot250, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  %rgep1469 = getelementptr i8, ptr %p1468, i64 -32
  store i64 %v1466, ptr %rgep1469, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear475
bb_rcgclear475:
  %v1470 = load i64, ptr %slot232, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  store i64 0, ptr %p1471, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone475
bb_rcgdone475:
  br label %bb_rcslotdone444
bb_rcslotdone444:
  %v1472 = load i64, ptr %slot230, align 8
  ret i64 %v1472
bb_i52:
  br label %bb_i55
bb_i53:
  br label %bb_i55
bb_i54:
  br label %bb_i55
bb_i55:
  br label %bb_i82
bb_i56:
  %v1473 = load i64, ptr %slot22, align 8
  %v1474 = load i64, ptr %slot24, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  store i64 %v1473, ptr %p1475, align 8, !alias.scope !3, !noalias !4
  %v1476 = load i64, ptr %slot24, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  %ld1478 = load i64, ptr %p1477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1478, ptr %slot263, align 8
  %v1479 = load i64, ptr %slot263, align 8
  %op1480 = add i64 %v1479, 8
  store i64 %op1480, ptr %slot264, align 8
  %v1481 = load i64, ptr %slot264, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  %ld1483 = load i32, ptr %p1482, align 4
  %ext1484 = zext i32 %ld1483 to i64
  store i64 %ext1484, ptr %slot265, align 8
  %v1485 = load i64, ptr %slot265, align 8
  %v1486 = load i64, ptr %slot24, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  store i64 %v1485, ptr %p1487, align 8, !alias.scope !3, !noalias !4
  %v1488 = load i64, ptr %slot15, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  %ld1490 = load i64, ptr %p1489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1490, ptr %slot266, align 8
  %v1491 = load i64, ptr %slot266, align 8
  %v1492 = load i64, ptr %slot25, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  store i64 %v1491, ptr %p1493, align 8, !alias.scope !3, !noalias !4
  %v1494 = load i64, ptr %slot25, align 8
  %p1495 = inttoptr i64 %v1494 to ptr
  %ld1496 = load i64, ptr %p1495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1496, ptr %slot267, align 8
  %v1497 = load i64, ptr %slot24, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  %ld1499 = load i64, ptr %p1498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1499, ptr %slot268, align 8
  %v1500 = load i64, ptr %slot268, align 8
  %v1501 = load i64, ptr %slot267, align 8
  %cmp1502 = icmp eq i64 %v1500, %v1501
  %cv1503 = zext i1 %cmp1502 to i64
  store i64 %cv1503, ptr %slot269, align 8
  %v1504 = load i64, ptr %slot269, align 8
  %v1505 = load i64, ptr %slot24, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  store i64 %v1504, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  %v1507 = load i64, ptr %slot24, align 8
  %p1508 = inttoptr i64 %v1507 to ptr
  %ld1509 = load i64, ptr %p1508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1509, ptr %slot270, align 8
  %v1510 = load i64, ptr %slot270, align 8
  %cond1511 = icmp ne i64 %v1510, 0
  br i1 %cond1511, label %bb_next533, label %bb_i82
bb_next533:
  %v1512 = load i64, ptr %slot13, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  %ld1514 = load i64, ptr %p1513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1514, ptr %slot271, align 8
  %v1515 = load i64, ptr %slot271, align 8
  %v1516 = load i64, ptr %slot24, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  store i64 %v1515, ptr %p1517, align 8, !alias.scope !3, !noalias !4
  %v1518 = load i64, ptr %slot22, align 8
  %v1519 = load i64, ptr %slot25, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  store i64 %v1518, ptr %p1520, align 8, !alias.scope !3, !noalias !4
  %v1521 = load i64, ptr %slot25, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  %ld1523 = load i64, ptr %p1522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1523, ptr %slot272, align 8
  %v1524 = load i64, ptr %slot272, align 8
  %op1525 = add i64 %v1524, 0
  store i64 %op1525, ptr %slot273, align 8
  %v1526 = load i64, ptr %slot273, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  %ld1528 = load i64, ptr %p1527, align 8
  store i64 %ld1528, ptr %slot274, align 8
  %v1529 = load i64, ptr %slot274, align 8
  %v1530 = load i64, ptr %slot25, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  store i64 %v1529, ptr %p1531, align 8, !alias.scope !3, !noalias !4
  %v1532 = load i64, ptr %slot24, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  %ld1534 = load i64, ptr %p1533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1534, ptr %slot275, align 8
  %v1535 = load i64, ptr %slot25, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  %ld1537 = load i64, ptr %p1536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1537, ptr %slot276, align 8
  %v1538 = load i64, ptr %slot1, align 8
  %v1539 = load i64, ptr %slot275, align 8
  %v1540 = load i64, ptr %slot276, align 8
  %call1541 = call { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64 %v1538, i64 %v1539, i64 %v1540) nomerge, !dbg !132
  store { i64, i64 } %call1541, ptr %callresult278, align 8
  %addr1542 = ptrtoint ptr %callresult278 to i64
  store i64 %addr1542, ptr %slot277, align 8
  %v1543 = load i64, ptr %slot277, align 8
  %v1544 = load i64, ptr %slot24, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  store i64 %v1543, ptr %p1545, align 8, !alias.scope !3, !noalias !4
  %v1546 = load i64, ptr %slot24, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  %ld1548 = load i64, ptr %p1547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1548, ptr %slot279, align 8
  %v1549 = load i64, ptr %slot279, align 8
  %op1550 = add i64 %v1549, 0
  store i64 %op1550, ptr %slot280, align 8
  %v1551 = load i64, ptr %slot280, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %ld1553 = load i64, ptr %p1552, align 8
  store i64 %ld1553, ptr %slot281, align 8
  %v1554 = load i64, ptr %slot281, align 8
  %v1555 = load i64, ptr %slot24, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  store i64 %v1554, ptr %p1556, align 8, !alias.scope !3, !noalias !4
  %v1557 = load i64, ptr %slot24, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  %ld1559 = load i64, ptr %p1558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1559, ptr %slot282, align 8
  %v1560 = load i64, ptr %slot282, align 8
  %v1561 = load i64, ptr %slot23, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  store i64 %v1560, ptr %p1562, align 8, !alias.scope !3, !noalias !4
  %v1563 = load i64, ptr %slot23, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  %ld1565 = load i64, ptr %p1564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1565, ptr %slot283, align 8
  %v1566 = load i64, ptr %slot283, align 8
  %v1567 = load i64, ptr %slot24, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i64 %v1566, ptr %p1568, align 8, !alias.scope !3, !noalias !4
  %v1569 = load i64, ptr %slot24, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  %ld1571 = load i64, ptr %p1570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1571, ptr %slot284, align 8
  %v1572 = load i64, ptr %slot284, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  %ld1574 = load i64, ptr %p1573, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1574, ptr %slot285, align 8
  %v1575 = load i64, ptr %slot285, align 8
  %v1576 = load i64, ptr %slot24, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  store i64 %v1575, ptr %p1577, align 8, !alias.scope !3, !noalias !4
  %v1578 = load i64, ptr %slot14, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  %ld1580 = load i64, ptr %p1579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1580, ptr %slot286, align 8
  %v1581 = load i64, ptr %slot286, align 8
  %v1582 = load i64, ptr %slot25, align 8
  %p1583 = inttoptr i64 %v1582 to ptr
  store i64 %v1581, ptr %p1583, align 8, !alias.scope !3, !noalias !4
  %v1584 = load i64, ptr %slot25, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %ld1586 = load i64, ptr %p1585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1586, ptr %slot287, align 8
  %v1587 = load i64, ptr %slot287, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  %ld1589 = load i64, ptr %p1588, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1589, ptr %slot288, align 8
  %v1590 = load i64, ptr %slot288, align 8
  %v1591 = load i64, ptr %slot25, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i64 %v1590, ptr %p1592, align 8, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot25, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  %ld1595 = load i64, ptr %p1594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1595, ptr %slot289, align 8
  %v1596 = load i64, ptr %slot24, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %ld1598 = load i64, ptr %p1597, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1598, ptr %slot290, align 8
  %v1599 = load i64, ptr %slot290, align 8
  %v1600 = load i64, ptr %slot289, align 8
  %cmp1601 = icmp eq i64 %v1599, %v1600
  %cv1602 = zext i1 %cmp1601 to i64
  store i64 %cv1602, ptr %slot291, align 8
  %v1603 = load i64, ptr %slot291, align 8
  %v1604 = load i64, ptr %slot24, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i64 %v1603, ptr %p1605, align 8, !alias.scope !3, !noalias !4
  %v1606 = load i64, ptr %slot24, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %ld1608 = load i64, ptr %p1607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1608, ptr %slot292, align 8
  %v1609 = load i64, ptr %slot292, align 8
  %cond1610 = icmp ne i64 %v1609, 0
  br i1 %cond1610, label %bb_next646, label %bb_i77
bb_next646:
  %v1611 = load i64, ptr %slot23, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %ld1613 = load i64, ptr %p1612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1613, ptr %slot293, align 8
  %v1614 = load i64, ptr %slot293, align 8
  %v1615 = load i64, ptr %slot24, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  store i64 %v1614, ptr %p1616, align 8, !alias.scope !3, !noalias !4
  %v1617 = load i64, ptr %slot14, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %ld1619 = load i64, ptr %p1618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1619, ptr %slot294, align 8
  %v1620 = load i64, ptr %slot294, align 8
  %v1621 = load i64, ptr %slot25, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i64 %v1620, ptr %p1622, align 8, !alias.scope !3, !noalias !4
  %v1623 = load i64, ptr %slot24, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  %ld1625 = load i64, ptr %p1624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1625, ptr %slot295, align 8
  %v1626 = load i64, ptr %slot25, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i64, ptr %p1627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1628, ptr %slot296, align 8
  %v1629 = load i64, ptr %slot24, align 8
  store i64 %v1629, ptr %slot297, align 8
  %v1630 = load i64, ptr %slot25, align 8
  store i64 %v1630, ptr %slot298, align 8
  %p1631 = inttoptr i64 ptrtoint (ptr @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9 to i64) to ptr
  %v1632 = load i64, ptr %slot297, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %v1634 = load i64, ptr %slot298, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  %call1636 = call i32 @myl_native_equal(ptr %p1631, ptr %p1633, ptr %p1635) nomerge, !dbg !134
  store i32 %call1636, ptr %slot299, align 8
  %v1637 = load i32, ptr %slot299, align 8
  %cmp1638 = icmp sge i32 %v1637, 0
  %cv1639 = zext i1 %cmp1638 to i32
  store i32 %cv1639, ptr %slot300, align 8
  %v1640 = load i32, ptr %slot300, align 8
  %cv1641 = zext i32 %v1640 to i64
  %cond1642 = icmp ne i64 %cv1641, 0
  br i1 %cond1642, label %bb_equalok654, label %bb_equalerror654
bb_equalerror654:
  %v1643 = load i64, ptr %slot1, align 8
  %p1644 = inttoptr i64 %v1643 to ptr
  %v1645 = load i32, ptr %slot299, align 8
  call void @myl_qbe_fail_equality(ptr %p1644, i32 %v1645) nomerge, !dbg !134
  unreachable
bb_equalok654:
  %v1646 = load i32, ptr %slot299, align 8
  %ext1647 = zext i32 %v1646 to i64
  store i64 %ext1647, ptr %slot301, align 8
  %v1648 = load i64, ptr %slot301, align 8
  %v1649 = load i64, ptr %slot24, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  store i64 %v1648, ptr %p1650, align 8, !alias.scope !3, !noalias !4
  br label %bb_i78
bb_i77:
  %v1651 = load i64, ptr %slot24, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  store i64 0, ptr %p1652, align 8, !alias.scope !3, !noalias !4
  br label %bb_i78
bb_i78:
  %v1653 = load i64, ptr %slot24, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  %ld1655 = load i64, ptr %p1654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1655, ptr %slot302, align 8
  %v1656 = load i64, ptr %slot302, align 8
  %cond1657 = icmp ne i64 %v1656, 0
  br i1 %cond1657, label %bb_next731, label %bb_i82
bb_next731:
  %v1658 = load i64, ptr %slot22, align 8
  %v1659 = load i64, ptr %slot24, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i64 %v1658, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot24, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  %ld1663 = load i64, ptr %p1662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1663, ptr %slot303, align 8
  %v1664 = load i64, ptr %slot303, align 8
  %op1665 = add i64 %v1664, 0
  store i64 %op1665, ptr %slot304, align 8
  %v1666 = load i64, ptr %slot304, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  %ld1668 = load i64, ptr %p1667, align 8
  store i64 %ld1668, ptr %slot305, align 8
  %v1669 = load i64, ptr %slot305, align 8
  %v1670 = load i64, ptr %slot24, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  store i64 %v1669, ptr %p1671, align 8, !alias.scope !3, !noalias !4
  %v1672 = load i64, ptr %slot24, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %ld1674 = load i64, ptr %p1673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1674, ptr %slot306, align 8
  %v1675 = load i64, ptr %slot6, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  %ld1677 = load i32, ptr %p1676, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1677, ptr %slot307, align 8
  %v1678 = load i32, ptr %slot307, align 8
  %cv1679 = zext i32 %v1678 to i64
  %cond1680 = icmp ne i64 %cv1679, 0
  br i1 %cond1680, label %bb_rcslotdrop777, label %bb_rcslotdone777
bb_rcslotdrop777:
  %v1681 = load i64, ptr %slot6, align 8
  %p1682 = inttoptr i64 %v1681 to ptr
  store i32 0, ptr %p1682, align 4, !alias.scope !3, !noalias !4
  %v1683 = load i64, ptr %slot16, align 8
  store i64 %v1683, ptr %slot308, align 8
  %v1684 = load i64, ptr %slot7, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  %ld1686 = load i32, ptr %p1685, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1686, ptr %slot309, align 8
  %v1687 = load i32, ptr %slot309, align 8
  %op1688 = and i32 %v1687, 28
  store i32 %op1688, ptr %slot310, align 8
  %v1689 = load i32, ptr %slot310, align 8
  %cv1690 = zext i32 %v1689 to i64
  %cond1691 = icmp ne i64 %cv1690, 0
  br i1 %cond1691, label %bb_rcslotrole777, label %bb_rcslotowner777
bb_rcslotrole777:
  %v1692 = load i64, ptr %slot30, align 8
  store i64 %v1692, ptr %slot311, align 8
  %v1693 = load i64, ptr %slot308, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  %ld1695 = load i64, ptr %p1694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1695, ptr %slot312, align 8
  %v1696 = load i64, ptr %slot312, align 8
  %cmp1697 = icmp ne i64 %v1696, 0
  %cv1698 = zext i1 %cmp1697 to i32
  store i32 %cv1698, ptr %slot313, align 8
  %v1699 = load i32, ptr %slot313, align 8
  %cv1700 = zext i32 %v1699 to i64
  %cond1701 = icmp ne i64 %cv1700, 0
  br i1 %cond1701, label %bb_rcgnn793, label %bb_rcgdone793
bb_rcgnn793:
  %v1702 = load i64, ptr %slot312, align 8
  %op1703 = sub i64 %v1702, 16
  store i64 %op1703, ptr %slot314, align 8
  %v1704 = load i64, ptr %slot312, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  %rgep1706 = getelementptr i8, ptr %p1705, i64 -16
  %ld1707 = load i64, ptr %rgep1706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1707, ptr %slot315, align 8
  %v1708 = load i64, ptr %slot315, align 8
  %op1709 = and i64 %v1708, 4611686018427387906
  store i64 %op1709, ptr %slot316, align 8
  %v1710 = load i64, ptr %slot316, align 8
  %cmp1711 = icmp ne i64 %v1710, 0
  %cv1712 = zext i1 %cmp1711 to i32
  store i32 %cv1712, ptr %slot317, align 8
  %v1713 = load i32, ptr %slot317, align 8
  %cv1714 = zext i32 %v1713 to i64
  %cond1715 = icmp ne i64 %cv1714, 0
  br i1 %cond1715, label %bb_rcgclear793, label %bb_rcgcounted793
bb_rcgcounted793:
  %v1716 = load i64, ptr %slot312, align 8
  %op1717 = sub i64 %v1716, 24
  store i64 %op1717, ptr %slot318, align 8
  %v1718 = load i64, ptr %slot312, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  %rgep1720 = getelementptr i8, ptr %p1719, i64 -24
  %ld1721 = load i64, ptr %rgep1720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1721, ptr %slot319, align 8
  %v1722 = load i64, ptr %slot319, align 8
  %op1723 = sub i64 %v1722, 1
  store i64 %op1723, ptr %slot320, align 8
  %v1724 = load i64, ptr %slot320, align 8
  %cmp1725 = icmp eq i64 %v1724, 0
  %cv1726 = zext i1 %cmp1725 to i32
  store i32 %cv1726, ptr %slot321, align 8
  %v1727 = load i32, ptr %slot321, align 8
  %cv1728 = zext i32 %v1727 to i64
  %cond1729 = icmp ne i64 %cv1728, 0
  br i1 %cond1729, label %bb_rcglast793, label %bb_rcgdec793
bb_rcglast793:
  %v1730 = load i64, ptr %slot312, align 8
  %op1731 = sub i64 %v1730, 32
  store i64 %op1731, ptr %slot322, align 8
  %v1732 = load i64, ptr %slot312, align 8
  %p1733 = inttoptr i64 %v1732 to ptr
  %rgep1734 = getelementptr i8, ptr %p1733, i64 -32
  %ld1735 = load i64, ptr %rgep1734, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1735, ptr %slot323, align 8
  %v1736 = load i64, ptr %slot323, align 8
  %cmp1737 = icmp ne i64 %v1736, 0
  %cv1738 = zext i1 %cmp1737 to i32
  store i32 %cv1738, ptr %slot324, align 8
  %v1739 = load i32, ptr %slot324, align 8
  %cv1740 = zext i32 %v1739 to i64
  %cond1741 = icmp ne i64 %cv1740, 0
  br i1 %cond1741, label %bb_rcgdec793, label %bb_rcgslow793
bb_rcgslow793:
  %v1742 = load i64, ptr %slot311, align 8
  %v1743 = load i64, ptr %slot308, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v1742, i64 %v1743) nomerge, !dbg !136
  br label %bb_rcgdone793
bb_rcgdec793:
  %v1744 = load i64, ptr %slot320, align 8
  %v1745 = load i64, ptr %slot312, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  %rgep1747 = getelementptr i8, ptr %p1746, i64 -24
  store i64 %v1744, ptr %rgep1747, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear793
bb_rcgclear793:
  %v1748 = load i64, ptr %slot308, align 8
  %p1749 = inttoptr i64 %v1748 to ptr
  store i64 0, ptr %p1749, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone793
bb_rcgdone793:
  br label %bb_rcslotdone777
bb_rcslotowner777:
  %v1750 = load i64, ptr %slot30, align 8
  store i64 %v1750, ptr %slot325, align 8
  %v1751 = load i64, ptr %slot308, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  %ld1753 = load i64, ptr %p1752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1753, ptr %slot326, align 8
  %v1754 = load i64, ptr %slot326, align 8
  %cmp1755 = icmp ne i64 %v1754, 0
  %cv1756 = zext i1 %cmp1755 to i32
  store i32 %cv1756, ptr %slot327, align 8
  %v1757 = load i32, ptr %slot327, align 8
  %cv1758 = zext i32 %v1757 to i64
  %cond1759 = icmp ne i64 %cv1758, 0
  br i1 %cond1759, label %bb_rcgnn808, label %bb_rcgdone808
bb_rcgnn808:
  %v1760 = load i64, ptr %slot326, align 8
  %op1761 = sub i64 %v1760, 16
  store i64 %op1761, ptr %slot328, align 8
  %v1762 = load i64, ptr %slot326, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %rgep1764 = getelementptr i8, ptr %p1763, i64 -16
  %ld1765 = load i64, ptr %rgep1764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1765, ptr %slot329, align 8
  %v1766 = load i64, ptr %slot329, align 8
  %op1767 = and i64 %v1766, 4611686018427387906
  store i64 %op1767, ptr %slot330, align 8
  %v1768 = load i64, ptr %slot330, align 8
  %cmp1769 = icmp ne i64 %v1768, 0
  %cv1770 = zext i1 %cmp1769 to i32
  store i32 %cv1770, ptr %slot331, align 8
  %v1771 = load i32, ptr %slot331, align 8
  %cv1772 = zext i32 %v1771 to i64
  %cond1773 = icmp ne i64 %cv1772, 0
  br i1 %cond1773, label %bb_rcgclear808, label %bb_rcgcounted808
bb_rcgcounted808:
  %v1774 = load i64, ptr %slot326, align 8
  %op1775 = sub i64 %v1774, 32
  store i64 %op1775, ptr %slot332, align 8
  %v1776 = load i64, ptr %slot326, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  %rgep1778 = getelementptr i8, ptr %p1777, i64 -32
  %ld1779 = load i64, ptr %rgep1778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1779, ptr %slot333, align 8
  %v1780 = load i64, ptr %slot333, align 8
  %op1781 = sub i64 %v1780, 1
  store i64 %op1781, ptr %slot334, align 8
  %v1782 = load i64, ptr %slot334, align 8
  %cmp1783 = icmp eq i64 %v1782, 0
  %cv1784 = zext i1 %cmp1783 to i32
  store i32 %cv1784, ptr %slot335, align 8
  %v1785 = load i32, ptr %slot335, align 8
  %cv1786 = zext i32 %v1785 to i64
  %cond1787 = icmp ne i64 %cv1786, 0
  br i1 %cond1787, label %bb_rcglast808, label %bb_rcgdec808
bb_rcglast808:
  %v1788 = load i64, ptr %slot326, align 8
  %op1789 = sub i64 %v1788, 24
  store i64 %op1789, ptr %slot336, align 8
  %v1790 = load i64, ptr %slot326, align 8
  %p1791 = inttoptr i64 %v1790 to ptr
  %rgep1792 = getelementptr i8, ptr %p1791, i64 -24
  %ld1793 = load i64, ptr %rgep1792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1793, ptr %slot337, align 8
  %v1794 = load i64, ptr %slot337, align 8
  %cmp1795 = icmp ne i64 %v1794, 0
  %cv1796 = zext i1 %cmp1795 to i32
  store i32 %cv1796, ptr %slot338, align 8
  %v1797 = load i32, ptr %slot338, align 8
  %cv1798 = zext i32 %v1797 to i64
  %cond1799 = icmp ne i64 %cv1798, 0
  br i1 %cond1799, label %bb_rcgdec808, label %bb_rcgslow808
bb_rcgslow808:
  %v1800 = load i64, ptr %slot325, align 8
  %v1801 = load i64, ptr %slot308, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1800, i64 %v1801) nomerge, !dbg !136
  br label %bb_rcgdone808
bb_rcgdec808:
  %v1802 = load i64, ptr %slot334, align 8
  %v1803 = load i64, ptr %slot326, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %rgep1805 = getelementptr i8, ptr %p1804, i64 -32
  store i64 %v1802, ptr %rgep1805, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear808
bb_rcgclear808:
  %v1806 = load i64, ptr %slot308, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  store i64 0, ptr %p1807, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone808
bb_rcgdone808:
  br label %bb_rcslotdone777
bb_rcslotdone777:
  %v1808 = load i64, ptr %slot306, align 8
  ret i64 %v1808
bb_i82:
  %v1809 = load i64, ptr %slot19, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  %ld1811 = load i64, ptr %p1810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1811, ptr %slot339, align 8
  %v1812 = load i64, ptr %slot339, align 8
  %v1813 = load i64, ptr %slot24, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i64 %v1812, ptr %p1814, align 8, !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot25, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  store i64 1, ptr %p1816, align 8, !alias.scope !3, !noalias !4
  %v1817 = load i64, ptr %slot25, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  %ld1819 = load i64, ptr %p1818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1819, ptr %slot340, align 8
  %v1820 = load i64, ptr %slot24, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  %ld1822 = load i64, ptr %p1821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1822, ptr %slot341, align 8
  %v1823 = load i64, ptr %slot341, align 8
  %v1824 = load i64, ptr %slot340, align 8
  %ovpair1826 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1823, i64 %v1824)
  %op1825 = extractvalue { i64, i1 } %ovpair1826, 0
  %ov1827 = extractvalue { i64, i1 } %ovpair1826, 1
  store i64 %op1825, ptr %slot342, align 8
  %cv1828 = zext i1 %ov1827 to i64
  store i64 %cv1828, ptr %slot343, align 8
  %v1829 = load i64, ptr %slot343, align 8
  %cond1830 = icmp ne i64 %v1829, 0
  br i1 %cond1830, label %bb_overflow861, label %bb_checked861
bb_overflow861:
  %v1831 = load i64, ptr %slot1, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  %v1833 = load i64, ptr %slot341, align 8
  %v1834 = load i64, ptr %slot340, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1832, i64 0, i64 %v1833, i64 %v1834, i64 64) nomerge, !dbg !138
  unreachable
bb_checked861:
  %v1835 = load i64, ptr %slot342, align 8
  %v1836 = load i64, ptr %slot24, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  store i64 %v1835, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  %v1838 = load i64, ptr %slot18, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  %ld1840 = load i64, ptr %p1839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1840, ptr %slot344, align 8
  %v1841 = load i64, ptr %slot344, align 8
  %v1842 = load i64, ptr %slot25, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  store i64 %v1841, ptr %p1843, align 8, !alias.scope !3, !noalias !4
  %v1844 = load i64, ptr %slot25, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  %ld1846 = load i64, ptr %p1845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1846, ptr %slot345, align 8
  %v1847 = load i64, ptr %slot24, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  %ld1849 = load i64, ptr %p1848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1849, ptr %slot346, align 8
  %v1850 = load i64, ptr %slot346, align 8
  %v1851 = load i64, ptr %slot345, align 8
  %op1852 = and i64 %v1850, %v1851
  store i64 %op1852, ptr %slot347, align 8
  %v1853 = load i64, ptr %slot347, align 8
  %v1854 = load i64, ptr %slot24, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  store i64 %v1853, ptr %p1855, align 8, !alias.scope !3, !noalias !4
  %v1856 = load i64, ptr %slot24, align 8
  %p1857 = inttoptr i64 %v1856 to ptr
  %ld1858 = load i64, ptr %p1857, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1858, ptr %slot348, align 8
  %v1859 = load i64, ptr %slot348, align 8
  %v1860 = load i64, ptr %slot19, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  store i64 %v1859, ptr %p1861, align 8, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64, i64, i64)
declare i32 @myl_native_equal(ptr, ptr, ptr)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_equality(ptr, i32) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb", linkageName: "myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14593475165900974363, i64 0, !"myl_f_3ca3d1aa5544479c5d8d56f23a59f7ab06c5cc7e0dd76e70898bfa7ec20d98cb"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!118 = !DILocation(line: 17, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!120 = !DILocation(line: 19, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!122 = !DILocation(line: 23, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!124 = !DILocation(line: 36, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!126 = !DILocation(line: 38, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!128 = !DILocation(line: 41, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!130 = !DILocation(line: 52, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!132 = !DILocation(line: 65, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!134 = !DILocation(line: 76, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!136 = !DILocation(line: 82, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647215)
!138 = !DILocation(line: 85, column: 0, scope: !139)
