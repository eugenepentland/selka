target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_7ed5e5db1a870833aaf6cf104d303f9f9c5cad2c1ab868ef69a232d64277da59(ptr sret([48 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3, i64 %p_a4) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %callresult54 = alloca [208 x i8], align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %callresult78 = alloca [40 x i8], align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  store i64 %p_a4, ptr %slot6, align 8
  %v535 = load i64, ptr %slot1, align 8
  %op536 = add i64 %v535, 32
  store i64 %op536, ptr %slot7, align 8
  %mem537 = alloca i8, i64 48, align 8
  %ptr538 = ptrtoint ptr %mem537 to i64
  store i64 %ptr538, ptr %slot8, align 8
  %mem539 = alloca i8, i64 8, align 8
  %ptr540 = ptrtoint ptr %mem539 to i64
  store i64 %ptr540, ptr %slot9, align 8
  %mem541 = alloca i8, i64 8, align 8
  %ptr542 = ptrtoint ptr %mem541 to i64
  store i64 %ptr542, ptr %slot10, align 8
  %mem543 = alloca i8, i64 8, align 8
  %ptr544 = ptrtoint ptr %mem543 to i64
  store i64 %ptr544, ptr %slot11, align 8
  %mem545 = alloca i8, i64 8, align 8
  %ptr546 = ptrtoint ptr %mem545 to i64
  store i64 %ptr546, ptr %slot12, align 8
  %mem547 = alloca i8, i64 8, align 8
  %ptr548 = ptrtoint ptr %mem547 to i64
  store i64 %ptr548, ptr %slot13, align 8
  %mem549 = alloca i8, i64 8, align 8
  %ptr550 = ptrtoint ptr %mem549 to i64
  store i64 %ptr550, ptr %slot14, align 8
  %mem551 = alloca i8, i64 8, align 8
  %ptr552 = ptrtoint ptr %mem551 to i64
  store i64 %ptr552, ptr %slot15, align 8
  %mem553 = alloca i8, i64 8, align 8
  %ptr554 = ptrtoint ptr %mem553 to i64
  store i64 %ptr554, ptr %slot16, align 8
  %mem555 = alloca i8, i64 8, align 8
  %ptr556 = ptrtoint ptr %mem555 to i64
  store i64 %ptr556, ptr %slot17, align 8
  %mem557 = alloca i8, i64 8, align 8
  %ptr558 = ptrtoint ptr %mem557 to i64
  store i64 %ptr558, ptr %slot18, align 8
  %mem559 = alloca i8, i64 8, align 8
  %ptr560 = ptrtoint ptr %mem559 to i64
  store i64 %ptr560, ptr %slot19, align 8
  %mem561 = alloca i8, i64 8, align 8
  %ptr562 = ptrtoint ptr %mem561 to i64
  store i64 %ptr562, ptr %slot20, align 8
  %mem563 = alloca i8, i64 8, align 8
  %ptr564 = ptrtoint ptr %mem563 to i64
  store i64 %ptr564, ptr %slot21, align 8
  %mem565 = alloca i8, i64 208, align 8
  %ptr566 = ptrtoint ptr %mem565 to i64
  store i64 %ptr566, ptr %slot22, align 8
  %mem567 = alloca i8, i64 40, align 8
  %ptr568 = ptrtoint ptr %mem567 to i64
  store i64 %ptr568, ptr %slot23, align 8
  %mem569 = alloca i8, i64 40, align 8
  %ptr570 = ptrtoint ptr %mem569 to i64
  store i64 %ptr570, ptr %slot24, align 8
  %mem571 = alloca i8, i64 8, align 8
  %ptr572 = ptrtoint ptr %mem571 to i64
  store i64 %ptr572, ptr %slot25, align 8
  %mem573 = alloca i8, i64 8, align 8
  %ptr574 = ptrtoint ptr %mem573 to i64
  store i64 %ptr574, ptr %slot26, align 8
  %mem575 = alloca i8, i64 208, align 8
  %ptr576 = ptrtoint ptr %mem575 to i64
  store i64 %ptr576, ptr %slot27, align 8
  %mem577 = alloca i8, i64 8, align 8
  %ptr578 = ptrtoint ptr %mem577 to i64
  store i64 %ptr578, ptr %slot28, align 8
  %mem579 = alloca i8, i64 8, align 8
  %ptr580 = ptrtoint ptr %mem579 to i64
  store i64 %ptr580, ptr %slot29, align 8
  %mem581 = alloca i8, i64 8, align 8
  %ptr582 = ptrtoint ptr %mem581 to i64
  store i64 %ptr582, ptr %slot30, align 8
  %mem583 = alloca i8, i64 8, align 8
  %ptr584 = ptrtoint ptr %mem583 to i64
  store i64 %ptr584, ptr %slot31, align 8
  %mem585 = alloca i8, i64 8, align 8
  %ptr586 = ptrtoint ptr %mem585 to i64
  store i64 %ptr586, ptr %slot32, align 8
  %mem587 = alloca i8, i64 208, align 8
  %ptr588 = ptrtoint ptr %mem587 to i64
  store i64 %ptr588, ptr %slot33, align 8
  %mem589 = alloca i8, i64 40, align 8
  %ptr590 = ptrtoint ptr %mem589 to i64
  store i64 %ptr590, ptr %slot34, align 8
  %mem591 = alloca i8, i64 8, align 8
  %ptr592 = ptrtoint ptr %mem591 to i64
  store i64 %ptr592, ptr %slot35, align 8
  %mem593 = alloca i8, i64 8, align 8
  %ptr594 = ptrtoint ptr %mem593 to i64
  store i64 %ptr594, ptr %slot36, align 8
  %mem595 = alloca i8, i64 8, align 8
  %ptr596 = ptrtoint ptr %mem595 to i64
  store i64 %ptr596, ptr %slot37, align 8
  %mem597 = alloca i8, i64 8, align 8
  %ptr598 = ptrtoint ptr %mem597 to i64
  store i64 %ptr598, ptr %slot38, align 8
  %mem599 = alloca i8, i64 8, align 8
  %ptr600 = ptrtoint ptr %mem599 to i64
  store i64 %ptr600, ptr %slot39, align 8
  %mem601 = alloca i8, i64 8, align 8
  %ptr602 = ptrtoint ptr %mem601 to i64
  store i64 %ptr602, ptr %slot40, align 8
  %mem603 = alloca i8, i64 8, align 8
  %ptr604 = ptrtoint ptr %mem603 to i64
  store i64 %ptr604, ptr %slot41, align 8
  %mem605 = alloca i8, i64 48, align 8
  %ptr606 = ptrtoint ptr %mem605 to i64
  store i64 %ptr606, ptr %slot42, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem607 = alloca i8, i64 8, align 8
  %ptr608 = ptrtoint ptr %mem607 to i64
  store i64 %ptr608, ptr %slot43, align 8
  %v609 = load i64, ptr %slot1, align 8
  %op610 = add i64 %v609, 64
  store i64 %op610, ptr %slot44, align 8
  %v611 = load i64, ptr %slot44, align 8
  %p612 = inttoptr i64 %v611 to ptr
  %ld613 = load i64, ptr %p612, align 8, !alias.scope !4, !noalias !3
  store i64 %ld613, ptr %slot45, align 8
  %stack614 = call ptr @llvm.stacksave()
  %stackaddr615 = ptrtoint ptr %stack614 to i64
  %v616 = load i64, ptr %slot45, align 8
  %cmp617 = icmp ult i64 %stackaddr615, %v616
  %cv618 = zext i1 %cmp617 to i64
  store i64 %cv618, ptr %slot46, align 8
  %v619 = load i64, ptr %slot46, align 8
  %cond620 = icmp ne i64 %v619, 0
  br i1 %cond620, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v621 = load i64, ptr %slot1, align 8
  %p622 = inttoptr i64 %v621 to ptr
  call void @myl_qbe_fail_frame(ptr %p622) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v623 = load i64, ptr %slot2, align 8
  %v624 = load i64, ptr %slot28, align 8
  %p625 = inttoptr i64 %v624 to ptr
  store i64 %v623, ptr %p625, align 8, !alias.scope !3, !noalias !4
  %v626 = load i64, ptr %slot3, align 8
  %v627 = load i64, ptr %slot29, align 8
  %p628 = inttoptr i64 %v627 to ptr
  store i64 %v626, ptr %p628, align 8, !alias.scope !3, !noalias !4
  %v629 = load i64, ptr %slot4, align 8
  %v630 = load i64, ptr %slot30, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i64 %v629, ptr %p631, align 8, !alias.scope !3, !noalias !4
  %v632 = load i64, ptr %slot5, align 8
  %v633 = load i64, ptr %slot31, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i64 %v632, ptr %p634, align 8, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot6, align 8
  %v636 = load i64, ptr %slot32, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i64 %v635, ptr %p637, align 8, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot1, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %call640 = call ptr @myl_qbe_heap(ptr %p639) nomerge, !dbg !112
  %calladdr641 = ptrtoint ptr %call640 to i64
  store i64 %calladdr641, ptr %slot47, align 8
  %v642 = load i64, ptr %slot1, align 8
  %p643 = inttoptr i64 %v642 to ptr
  %call644 = call i64 @myl_qbe_region_mark(ptr %p643) nomerge, !dbg !112
  store i64 %call644, ptr %slot48, align 8
  %v645 = load i64, ptr %slot9, align 8
  %p646 = inttoptr i64 %v645 to ptr
  store i32 0, ptr %p646, align 4, !alias.scope !3, !noalias !4
  %v647 = load i64, ptr %slot10, align 8
  %p648 = inttoptr i64 %v647 to ptr
  store i32 0, ptr %p648, align 4, !alias.scope !3, !noalias !4
  %v649 = load i64, ptr %slot11, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i32 0, ptr %p650, align 4, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot12, align 8
  %p652 = inttoptr i64 %v651 to ptr
  store i32 0, ptr %p652, align 4, !alias.scope !3, !noalias !4
  %v653 = load i64, ptr %slot13, align 8
  %p654 = inttoptr i64 %v653 to ptr
  store i32 0, ptr %p654, align 4, !alias.scope !3, !noalias !4
  %v655 = load i64, ptr %slot14, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i32 0, ptr %p656, align 4, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot15, align 8
  %p658 = inttoptr i64 %v657 to ptr
  store i32 0, ptr %p658, align 4, !alias.scope !3, !noalias !4
  %v659 = load i64, ptr %slot16, align 8
  %p660 = inttoptr i64 %v659 to ptr
  store i32 0, ptr %p660, align 4, !alias.scope !3, !noalias !4
  %v661 = load i64, ptr %slot17, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i32 0, ptr %p662, align 4, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot18, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i32 0, ptr %p664, align 4, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot19, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i32 0, ptr %p666, align 4, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot20, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 0, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot21, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i32 0, ptr %p670, align 4, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot10, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i32 2, ptr %p672, align 4, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot12, align 8
  %p674 = inttoptr i64 %v673 to ptr
  store i32 2, ptr %p674, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v675 = load i64, ptr %slot30, align 8
  %p676 = inttoptr i64 %v675 to ptr
  %ld677 = load i64, ptr %p676, align 8, !alias.scope !3, !noalias !4
  store i64 %ld677, ptr %slot49, align 8
  %v678 = load i64, ptr %slot49, align 8
  %v679 = load i64, ptr %slot36, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i64 %v678, ptr %p680, align 8, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot32, align 8
  %p682 = inttoptr i64 %v681 to ptr
  %ld683 = load i64, ptr %p682, align 8, !alias.scope !3, !noalias !4
  store i64 %ld683, ptr %slot50, align 8
  %v684 = load i64, ptr %slot50, align 8
  %v685 = load i64, ptr %slot37, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i64 %v684, ptr %p686, align 8, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot36, align 8
  %p688 = inttoptr i64 %v687 to ptr
  %ld689 = load i64, ptr %p688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld689, ptr %slot51, align 8
  %v690 = load i64, ptr %slot37, align 8
  %p691 = inttoptr i64 %v690 to ptr
  %ld692 = load i64, ptr %p691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld692, ptr %slot52, align 8
  %v693 = load i64, ptr %slot1, align 8
  %v694 = load i64, ptr %slot51, align 8
  %v695 = load i64, ptr %slot52, align 8
  call void @myl_f_6ebf82ddbc9178c16b7df30bf24fbe017e8b8f1c3e98435ddaa9d24a62c703dc(ptr sret([208 x i8]) align 8 %callresult54, i64 %v693, i64 %v694, i64 %v695) nomerge, !dbg !114
  %addr696 = ptrtoint ptr %callresult54 to i64
  store i64 %addr696, ptr %slot53, align 8
  %v697 = load i64, ptr %slot53, align 8
  %v698 = load i64, ptr %slot36, align 8
  %p699 = inttoptr i64 %v698 to ptr
  store i64 %v697, ptr %p699, align 8, !alias.scope !3, !noalias !4
  %v700 = load i64, ptr %slot36, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %ld702 = load i64, ptr %p701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld702, ptr %slot55, align 8
  %v703 = load i64, ptr %slot27, align 8
  store i64 %v703, ptr %slot56, align 8
  %v704 = load i64, ptr %slot55, align 8
  %v705 = load i64, ptr %slot56, align 8
  %p706 = inttoptr i64 %v704 to ptr
  %p707 = inttoptr i64 %v705 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p707, ptr %p706, i64 208, i1 false)
  %v708 = load i64, ptr %slot20, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i32 2, ptr %p709, align 4, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot19, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i32 1, ptr %p711, align 4, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot22, align 8
  store i64 %v712, ptr %slot57, align 8
  %v713 = load i64, ptr %slot27, align 8
  store i64 %v713, ptr %slot58, align 8
  %v714 = load i64, ptr %slot58, align 8
  %v715 = load i64, ptr %slot57, align 8
  %p716 = inttoptr i64 %v714 to ptr
  %p717 = inttoptr i64 %v715 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p717, ptr %p716, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v718 = load i64, ptr %slot14, align 8
  %p719 = inttoptr i64 %v718 to ptr
  store i32 2, ptr %p719, align 4, !alias.scope !3, !noalias !4
  %v720 = load i64, ptr %slot20, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %ld722 = load i32, ptr %p721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld722, ptr %slot59, align 8
  %v723 = load i32, ptr %slot59, align 8
  %v724 = load i64, ptr %slot14, align 8
  %p725 = inttoptr i64 %v724 to ptr
  store i32 %v723, ptr %p725, align 4, !alias.scope !3, !noalias !4
  %v726 = load i64, ptr %slot19, align 8
  %p727 = inttoptr i64 %v726 to ptr
  store i32 0, ptr %p727, align 4, !alias.scope !3, !noalias !4
  %v728 = load i64, ptr %slot13, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i32 1, ptr %p729, align 4, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot57, align 8
  %v731 = load i64, ptr %slot36, align 8
  %p732 = inttoptr i64 %v731 to ptr
  store i64 %v730, ptr %p732, align 8, !alias.scope !3, !noalias !4
  %v733 = load i64, ptr %slot36, align 8
  %p734 = inttoptr i64 %v733 to ptr
  %ld735 = load i64, ptr %p734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld735, ptr %slot60, align 8
  %v736 = load i64, ptr %slot27, align 8
  store i64 %v736, ptr %slot61, align 8
  %v737 = load i64, ptr %slot48, align 8
  store i64 %v737, ptr %slot62, align 8
  %v738 = load i64, ptr %slot47, align 8
  %v739 = load i64, ptr %slot61, align 8
  %v740 = load i64, ptr %slot60, align 8
  %v741 = load i64, ptr %slot62, align 8
  %cv742 = trunc i64 %v741 to i32
  %call743 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64 %v738, i64 %v739, i64 %v740, i32 %cv742) nomerge, !dbg !116
  store i32 %call743, ptr %slot63, align 8
  %v744 = load i32, ptr %slot63, align 8
  %cv745 = zext i32 %v744 to i64
  %cond746 = icmp ne i64 %cv745, 0
  br i1 %cond746, label %bb_rcsuccess31, label %bb_rcfailure31
bb_rcfailure31:
  %v747 = load i64, ptr %slot47, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %call749 = call i32 @myl_rc_take_failure(ptr %p748) nomerge, !dbg !116
  store i32 %call749, ptr %slot64, align 8
  %v750 = load i64, ptr %slot1, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %v752 = load i32, ptr %slot64, align 8
  %call753 = call i32 @myl_qbe_rc_status(ptr %p751, i32 %v752) nomerge, !dbg !116
  store i32 %call753, ptr %slot65, align 8
  br label %bb_failure
bb_rcsuccess31:
  %v754 = load i64, ptr %slot13, align 8
  %p755 = inttoptr i64 %v754 to ptr
  store i32 0, ptr %p755, align 4, !alias.scope !3, !noalias !4
  %v756 = load i64, ptr %slot20, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i32 2, ptr %p757, align 4, !alias.scope !3, !noalias !4
  %v758 = load i64, ptr %slot19, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i32 1, ptr %p759, align 4, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot9, align 8
  %p761 = inttoptr i64 %v760 to ptr
  %ld762 = load i32, ptr %p761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld762, ptr %slot66, align 8
  %v763 = load i32, ptr %slot66, align 8
  %cv764 = zext i32 %v763 to i64
  %cond765 = icmp ne i64 %cv764, 0
  br i1 %cond765, label %bb_rcslotdrop40, label %bb_rcslotdone40
bb_rcslotdrop40:
  %v766 = load i64, ptr %slot9, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i32 0, ptr %p767, align 4, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot33, align 8
  store i64 %v768, ptr %slot67, align 8
  %v769 = load i64, ptr %slot10, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %ld771 = load i32, ptr %p770, align 4, !alias.scope !3, !noalias !4
  store i32 %ld771, ptr %slot68, align 8
  %v772 = load i32, ptr %slot68, align 8
  %op773 = and i32 %v772, 28
  store i32 %op773, ptr %slot69, align 8
  %v774 = load i32, ptr %slot69, align 8
  %cv775 = zext i32 %v774 to i64
  %cond776 = icmp ne i64 %cv775, 0
  br i1 %cond776, label %bb_rcslotrole40, label %bb_rcslotowner40
bb_rcslotrole40:
  %v777 = load i64, ptr %slot47, align 8
  store i64 %v777, ptr %slot70, align 8
  %v778 = load i64, ptr %slot70, align 8
  %v779 = load i64, ptr %slot67, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v778, i64 %v779) nomerge, !dbg !116
  br label %bb_rcslotdone40
bb_rcslotowner40:
  %v780 = load i64, ptr %slot47, align 8
  store i64 %v780, ptr %slot71, align 8
  %v781 = load i64, ptr %slot71, align 8
  %v782 = load i64, ptr %slot67, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v781, i64 %v782) nomerge, !dbg !116
  br label %bb_rcslotdone40
bb_rcslotdone40:
  %v783 = load i64, ptr %slot33, align 8
  store i64 %v783, ptr %slot72, align 8
  %v784 = load i64, ptr %slot27, align 8
  store i64 %v784, ptr %slot73, align 8
  %v785 = load i64, ptr %slot73, align 8
  %v786 = load i64, ptr %slot72, align 8
  %p787 = inttoptr i64 %v785 to ptr
  %p788 = inttoptr i64 %v786 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p788, ptr %p787, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v789 = load i64, ptr %slot19, align 8
  %p790 = inttoptr i64 %v789 to ptr
  store i32 0, ptr %p790, align 4, !alias.scope !3, !noalias !4
  %v791 = load i64, ptr %slot10, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i32 2, ptr %p792, align 4, !alias.scope !3, !noalias !4
  %v793 = load i64, ptr %slot20, align 8
  %p794 = inttoptr i64 %v793 to ptr
  %ld795 = load i32, ptr %p794, align 4, !alias.scope !3, !noalias !4
  store i32 %ld795, ptr %slot74, align 8
  %v796 = load i32, ptr %slot74, align 8
  %v797 = load i64, ptr %slot10, align 8
  %p798 = inttoptr i64 %v797 to ptr
  store i32 %v796, ptr %p798, align 4, !alias.scope !3, !noalias !4
  %v799 = load i64, ptr %slot9, align 8
  %p800 = inttoptr i64 %v799 to ptr
  store i32 1, ptr %p800, align 4, !alias.scope !3, !noalias !4
  %v801 = load i64, ptr %slot31, align 8
  %p802 = inttoptr i64 %v801 to ptr
  %ld803 = load i64, ptr %p802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld803, ptr %slot75, align 8
  %v804 = load i64, ptr %slot75, align 8
  %v805 = load i64, ptr %slot36, align 8
  %p806 = inttoptr i64 %v805 to ptr
  store i64 %v804, ptr %p806, align 8, !alias.scope !3, !noalias !4
  %v807 = load i64, ptr %slot36, align 8
  %p808 = inttoptr i64 %v807 to ptr
  %ld809 = load i64, ptr %p808, align 8, !alias.scope !3, !noalias !4
  store i64 %ld809, ptr %slot76, align 8
  %v810 = load i64, ptr %slot1, align 8
  %v811 = load i64, ptr %slot76, align 8
  call void @myl_f_3fa1fce991adab79730ee8c7bc958ee62467f0563d7015944308565f4efbc770(ptr sret([40 x i8]) align 8 %callresult78, i64 %v810, i64 %v811) nomerge, !dbg !118
  %addr812 = ptrtoint ptr %callresult78 to i64
  store i64 %addr812, ptr %slot77, align 8
  %v813 = load i64, ptr %slot77, align 8
  %v814 = load i64, ptr %slot36, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i64 %v813, ptr %p815, align 8, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot36, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %ld818 = load i64, ptr %p817, align 8, !alias.scope !3, !noalias !4
  store i64 %ld818, ptr %slot79, align 8
  %v819 = load i64, ptr %slot27, align 8
  store i64 %v819, ptr %slot80, align 8
  %v820 = load i64, ptr %slot79, align 8
  %v821 = load i64, ptr %slot80, align 8
  %p822 = inttoptr i64 %v820 to ptr
  %p823 = inttoptr i64 %v821 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p823, ptr %p822, i64 40, i1 false)
  %v824 = load i64, ptr %slot20, align 8
  %p825 = inttoptr i64 %v824 to ptr
  store i32 2, ptr %p825, align 4, !alias.scope !3, !noalias !4
  %v826 = load i64, ptr %slot19, align 8
  %p827 = inttoptr i64 %v826 to ptr
  store i32 1, ptr %p827, align 4, !alias.scope !3, !noalias !4
  %v828 = load i64, ptr %slot22, align 8
  store i64 %v828, ptr %slot81, align 8
  %v829 = load i64, ptr %slot27, align 8
  store i64 %v829, ptr %slot82, align 8
  %v830 = load i64, ptr %slot82, align 8
  %v831 = load i64, ptr %slot81, align 8
  %p832 = inttoptr i64 %v830 to ptr
  %p833 = inttoptr i64 %v831 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p833, ptr %p832, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v834 = load i64, ptr %slot14, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i32 2, ptr %p835, align 4, !alias.scope !3, !noalias !4
  %v836 = load i64, ptr %slot20, align 8
  %p837 = inttoptr i64 %v836 to ptr
  %ld838 = load i32, ptr %p837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld838, ptr %slot83, align 8
  %v839 = load i32, ptr %slot83, align 8
  %v840 = load i64, ptr %slot14, align 8
  %p841 = inttoptr i64 %v840 to ptr
  store i32 %v839, ptr %p841, align 4, !alias.scope !3, !noalias !4
  %v842 = load i64, ptr %slot19, align 8
  %p843 = inttoptr i64 %v842 to ptr
  store i32 0, ptr %p843, align 4, !alias.scope !3, !noalias !4
  %v844 = load i64, ptr %slot13, align 8
  %p845 = inttoptr i64 %v844 to ptr
  store i32 1, ptr %p845, align 4, !alias.scope !3, !noalias !4
  %v846 = load i64, ptr %slot81, align 8
  %v847 = load i64, ptr %slot36, align 8
  %p848 = inttoptr i64 %v847 to ptr
  store i64 %v846, ptr %p848, align 8, !alias.scope !3, !noalias !4
  %v849 = load i64, ptr %slot36, align 8
  %p850 = inttoptr i64 %v849 to ptr
  %ld851 = load i64, ptr %p850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld851, ptr %slot84, align 8
  %v852 = load i64, ptr %slot27, align 8
  store i64 %v852, ptr %slot85, align 8
  %v853 = load i64, ptr %slot48, align 8
  store i64 %v853, ptr %slot86, align 8
  %v854 = load i64, ptr %slot84, align 8
  %op855 = add i64 %v854, 0
  store i64 %op855, ptr %slot87, align 8
  %v856 = load i64, ptr %slot87, align 8
  %p857 = inttoptr i64 %v856 to ptr
  %ld858 = load i64, ptr %p857, align 8
  store i64 %ld858, ptr %slot88, align 8
  %v859 = load i64, ptr %slot88, align 8
  %cmp860 = icmp ne i64 %v859, 0
  %cv861 = zext i1 %cmp860 to i32
  store i32 %cv861, ptr %slot89, align 8
  %v862 = load i32, ptr %slot89, align 8
  %cv863 = zext i32 %v862 to i64
  %cond864 = icmp ne i64 %cv863, 0
  br i1 %cond864, label %bb_rcmoveheader75, label %bb_rcmovenext75
bb_rcmoveheader75:
  %v865 = load i64, ptr %slot88, align 8
  %op866 = sub i64 %v865, 16
  store i64 %op866, ptr %slot90, align 8
  %v867 = load i64, ptr %slot88, align 8
  %p868 = inttoptr i64 %v867 to ptr
  %rgep869 = getelementptr i8, ptr %p868, i64 -16
  %ld870 = load i64, ptr %rgep869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld870, ptr %slot91, align 8
  %v871 = load i64, ptr %slot91, align 8
  %op872 = and i64 %v871, 5764607523034234881
  store i64 %op872, ptr %slot92, align 8
  %v873 = load i64, ptr %slot92, align 8
  %cmp874 = icmp ne i64 %v873, 0
  %cv875 = zext i1 %cmp874 to i32
  store i32 %cv875, ptr %slot93, align 8
  %v876 = load i32, ptr %slot93, align 8
  %cv877 = zext i32 %v876 to i64
  %cond878 = icmp ne i64 %cv877, 0
  br i1 %cond878, label %bb_rcmoveslow72, label %bb_rcmovenext75
bb_rcmovenext75:
  %v879 = load i64, ptr %slot84, align 8
  %op880 = add i64 %v879, 8
  store i64 %op880, ptr %slot94, align 8
  %v881 = load i64, ptr %slot94, align 8
  %p882 = inttoptr i64 %v881 to ptr
  %ld883 = load i64, ptr %p882, align 8
  store i64 %ld883, ptr %slot95, align 8
  %v884 = load i64, ptr %slot95, align 8
  %cmp885 = icmp ne i64 %v884, 0
  %cv886 = zext i1 %cmp885 to i32
  store i32 %cv886, ptr %slot96, align 8
  %v887 = load i32, ptr %slot96, align 8
  %cv888 = zext i32 %v887 to i64
  %cond889 = icmp ne i64 %cv888, 0
  br i1 %cond889, label %bb_rcmoveheader83, label %bb_rcmovenext83
bb_rcmoveheader83:
  %v890 = load i64, ptr %slot95, align 8
  %op891 = sub i64 %v890, 16
  store i64 %op891, ptr %slot97, align 8
  %v892 = load i64, ptr %slot95, align 8
  %p893 = inttoptr i64 %v892 to ptr
  %rgep894 = getelementptr i8, ptr %p893, i64 -16
  %ld895 = load i64, ptr %rgep894, align 8, !alias.scope !9, !noalias !10
  store i64 %ld895, ptr %slot98, align 8
  %v896 = load i64, ptr %slot98, align 8
  %op897 = and i64 %v896, 5764607523034234881
  store i64 %op897, ptr %slot99, align 8
  %v898 = load i64, ptr %slot99, align 8
  %cmp899 = icmp ne i64 %v898, 0
  %cv900 = zext i1 %cmp899 to i32
  store i32 %cv900, ptr %slot100, align 8
  %v901 = load i32, ptr %slot100, align 8
  %cv902 = zext i32 %v901 to i64
  %cond903 = icmp ne i64 %cv902, 0
  br i1 %cond903, label %bb_rcmoveslow72, label %bb_rcmovenext83
bb_rcmovenext83:
  %v904 = load i64, ptr %slot84, align 8
  %v905 = load i64, ptr %slot85, align 8
  %p906 = inttoptr i64 %v904 to ptr
  %p907 = inttoptr i64 %v905 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p907, ptr %p906, i64 40, i1 false)
  %v908 = load i64, ptr %slot84, align 8
  %p909 = inttoptr i64 %v908 to ptr
  store i64 0, ptr %p909, align 8
  %v910 = load i64, ptr %slot84, align 8
  %op911 = add i64 %v910, 8
  store i64 %op911, ptr %slot101, align 8
  %v912 = load i64, ptr %slot101, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i64 0, ptr %p913, align 8
  %v914 = load i64, ptr %slot84, align 8
  %op915 = add i64 %v914, 16
  store i64 %op915, ptr %slot102, align 8
  %v916 = load i64, ptr %slot102, align 8
  %p917 = inttoptr i64 %v916 to ptr
  store i64 0, ptr %p917, align 8
  %v918 = load i64, ptr %slot84, align 8
  %op919 = add i64 %v918, 24
  store i64 %op919, ptr %slot103, align 8
  %v920 = load i64, ptr %slot103, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i64 0, ptr %p921, align 8
  %v922 = load i64, ptr %slot84, align 8
  %op923 = add i64 %v922, 32
  store i64 %op923, ptr %slot104, align 8
  %v924 = load i64, ptr %slot104, align 8
  %p925 = inttoptr i64 %v924 to ptr
  store i64 0, ptr %p925, align 8
  br label %bb_rcmoved72
bb_rcmoveslow72:
  %v926 = load i64, ptr %slot47, align 8
  %v927 = load i64, ptr %slot85, align 8
  %v928 = load i64, ptr %slot84, align 8
  %v929 = load i64, ptr %slot86, align 8
  %cv930 = trunc i64 %v929 to i32
  %call931 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v926, i64 %v927, i64 %v928, i32 %cv930) nomerge, !dbg !120
  store i32 %call931, ptr %slot105, align 8
  %v932 = load i32, ptr %slot105, align 8
  %cv933 = zext i32 %v932 to i64
  %cond934 = icmp ne i64 %cv933, 0
  br i1 %cond934, label %bb_rcsuccess94, label %bb_rcfailure94
bb_rcfailure94:
  %v935 = load i64, ptr %slot47, align 8
  %p936 = inttoptr i64 %v935 to ptr
  %call937 = call i32 @myl_rc_take_failure(ptr %p936) nomerge, !dbg !120
  store i32 %call937, ptr %slot106, align 8
  %v938 = load i64, ptr %slot1, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %v940 = load i32, ptr %slot106, align 8
  %call941 = call i32 @myl_qbe_rc_status(ptr %p939, i32 %v940) nomerge, !dbg !120
  store i32 %call941, ptr %slot107, align 8
  br label %bb_failure
bb_rcsuccess94:
  br label %bb_rcmoved72
bb_rcmoved72:
  %v942 = load i64, ptr %slot13, align 8
  %p943 = inttoptr i64 %v942 to ptr
  store i32 0, ptr %p943, align 4, !alias.scope !3, !noalias !4
  %v944 = load i64, ptr %slot20, align 8
  %p945 = inttoptr i64 %v944 to ptr
  store i32 2, ptr %p945, align 4, !alias.scope !3, !noalias !4
  %v946 = load i64, ptr %slot19, align 8
  %p947 = inttoptr i64 %v946 to ptr
  store i32 1, ptr %p947, align 4, !alias.scope !3, !noalias !4
  %v948 = load i64, ptr %slot11, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %ld950 = load i32, ptr %p949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld950, ptr %slot108, align 8
  %v951 = load i32, ptr %slot108, align 8
  %cv952 = zext i32 %v951 to i64
  %cond953 = icmp ne i64 %cv952, 0
  br i1 %cond953, label %bb_rcslotdrop103, label %bb_rcslotdone103
bb_rcslotdrop103:
  %v954 = load i64, ptr %slot11, align 8
  %p955 = inttoptr i64 %v954 to ptr
  store i32 0, ptr %p955, align 4, !alias.scope !3, !noalias !4
  %v956 = load i64, ptr %slot34, align 8
  store i64 %v956, ptr %slot109, align 8
  %v957 = load i64, ptr %slot12, align 8
  %p958 = inttoptr i64 %v957 to ptr
  %ld959 = load i32, ptr %p958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld959, ptr %slot110, align 8
  %v960 = load i32, ptr %slot110, align 8
  %op961 = and i32 %v960, 28
  store i32 %op961, ptr %slot111, align 8
  %v962 = load i32, ptr %slot111, align 8
  %cv963 = zext i32 %v962 to i64
  %cond964 = icmp ne i64 %cv963, 0
  br i1 %cond964, label %bb_rcslotrole103, label %bb_rcslotowner103
bb_rcslotrole103:
  %v965 = load i64, ptr %slot47, align 8
  store i64 %v965, ptr %slot112, align 8
  %v966 = load i64, ptr %slot112, align 8
  %v967 = load i64, ptr %slot109, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v966, i64 %v967) nomerge, !dbg !120
  br label %bb_rcslotdone103
bb_rcslotowner103:
  %v968 = load i64, ptr %slot47, align 8
  store i64 %v968, ptr %slot113, align 8
  %v969 = load i64, ptr %slot113, align 8
  %v970 = load i64, ptr %slot109, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v969, i64 %v970) nomerge, !dbg !120
  br label %bb_rcslotdone103
bb_rcslotdone103:
  %v971 = load i64, ptr %slot34, align 8
  store i64 %v971, ptr %slot114, align 8
  %v972 = load i64, ptr %slot27, align 8
  store i64 %v972, ptr %slot115, align 8
  %v973 = load i64, ptr %slot115, align 8
  %v974 = load i64, ptr %slot114, align 8
  %p975 = inttoptr i64 %v973 to ptr
  %p976 = inttoptr i64 %v974 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p976, ptr %p975, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v977 = load i64, ptr %slot19, align 8
  %p978 = inttoptr i64 %v977 to ptr
  store i32 0, ptr %p978, align 4, !alias.scope !3, !noalias !4
  %v979 = load i64, ptr %slot12, align 8
  %p980 = inttoptr i64 %v979 to ptr
  store i32 2, ptr %p980, align 4, !alias.scope !3, !noalias !4
  %v981 = load i64, ptr %slot20, align 8
  %p982 = inttoptr i64 %v981 to ptr
  %ld983 = load i32, ptr %p982, align 4, !alias.scope !3, !noalias !4
  store i32 %ld983, ptr %slot116, align 8
  %v984 = load i32, ptr %slot116, align 8
  %v985 = load i64, ptr %slot12, align 8
  %p986 = inttoptr i64 %v985 to ptr
  store i32 %v984, ptr %p986, align 4, !alias.scope !3, !noalias !4
  %v987 = load i64, ptr %slot11, align 8
  %p988 = inttoptr i64 %v987 to ptr
  store i32 1, ptr %p988, align 4, !alias.scope !3, !noalias !4
  %v989 = load i64, ptr %slot33, align 8
  %v990 = load i64, ptr %slot36, align 8
  %p991 = inttoptr i64 %v990 to ptr
  store i64 %v989, ptr %p991, align 8, !alias.scope !3, !noalias !4
  %v992 = load i64, ptr %slot34, align 8
  %v993 = load i64, ptr %slot37, align 8
  %p994 = inttoptr i64 %v993 to ptr
  store i64 %v992, ptr %p994, align 8, !alias.scope !3, !noalias !4
  %v995 = load i64, ptr %slot28, align 8
  %p996 = inttoptr i64 %v995 to ptr
  %ld997 = load i64, ptr %p996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld997, ptr %slot117, align 8
  %v998 = load i64, ptr %slot117, align 8
  %v999 = load i64, ptr %slot38, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  store i64 %v998, ptr %p1000, align 8, !alias.scope !3, !noalias !4
  %v1001 = load i64, ptr %slot29, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  %ld1003 = load i64, ptr %p1002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1003, ptr %slot118, align 8
  %v1004 = load i64, ptr %slot118, align 8
  %v1005 = load i64, ptr %slot39, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  store i64 %v1004, ptr %p1006, align 8, !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot36, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  %ld1009 = load i64, ptr %p1008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1009, ptr %slot119, align 8
  %v1010 = load i64, ptr %slot37, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  %ld1012 = load i64, ptr %p1011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1012, ptr %slot120, align 8
  %v1013 = load i64, ptr %slot38, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  %ld1015 = load i64, ptr %p1014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1015, ptr %slot121, align 8
  %v1016 = load i64, ptr %slot39, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %ld1018 = load i64, ptr %p1017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1018, ptr %slot122, align 8
  %v1019 = load i64, ptr %slot1, align 8
  %v1020 = load i64, ptr %slot119, align 8
  %v1021 = load i64, ptr %slot120, align 8
  %v1022 = load i64, ptr %slot121, align 8
  %v1023 = load i64, ptr %slot122, align 8
  %call1024 = call i64 @myl_f_6750db8c8d1c4cf1c4854bf3a36c914802b0c65c931aa2f1c3cbbb68270b2fbe(i64 %v1019, i64 %v1020, i64 %v1021, i64 %v1022, i64 %v1023) nomerge, !dbg !122
  store i64 %call1024, ptr %slot123, align 8
  %v1025 = load i64, ptr %slot123, align 8
  %v1026 = load i64, ptr %slot36, align 8
  %p1027 = inttoptr i64 %v1026 to ptr
  store i64 %v1025, ptr %p1027, align 8, !alias.scope !3, !noalias !4
  %v1028 = load i64, ptr %slot13, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  %ld1030 = load i32, ptr %p1029, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1030, ptr %slot124, align 8
  %v1031 = load i32, ptr %slot124, align 8
  %cv1032 = zext i32 %v1031 to i64
  %cond1033 = icmp ne i64 %cv1032, 0
  br i1 %cond1033, label %bb_rcslotdrop126, label %bb_rcslotdone126
bb_rcslotdrop126:
  %v1034 = load i64, ptr %slot13, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  store i32 0, ptr %p1035, align 4, !alias.scope !3, !noalias !4
  %v1036 = load i64, ptr %slot22, align 8
  store i64 %v1036, ptr %slot125, align 8
  %v1037 = load i64, ptr %slot14, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  %ld1039 = load i32, ptr %p1038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1039, ptr %slot126, align 8
  %v1040 = load i32, ptr %slot126, align 8
  %op1041 = and i32 %v1040, 28
  store i32 %op1041, ptr %slot127, align 8
  %v1042 = load i32, ptr %slot127, align 8
  %cv1043 = zext i32 %v1042 to i64
  %cond1044 = icmp ne i64 %cv1043, 0
  br i1 %cond1044, label %bb_rcslotrole126, label %bb_rcslotowner126
bb_rcslotrole126:
  %v1045 = load i64, ptr %slot47, align 8
  store i64 %v1045, ptr %slot128, align 8
  %v1046 = load i64, ptr %slot128, align 8
  %v1047 = load i64, ptr %slot125, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1046, i64 %v1047) nomerge, !dbg !122
  br label %bb_rcslotdone126
bb_rcslotowner126:
  %v1048 = load i64, ptr %slot47, align 8
  store i64 %v1048, ptr %slot129, align 8
  %v1049 = load i64, ptr %slot129, align 8
  %v1050 = load i64, ptr %slot125, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1049, i64 %v1050) nomerge, !dbg !122
  br label %bb_rcslotdone126
bb_rcslotdone126:
  %v1051 = load i64, ptr %slot15, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %ld1053 = load i32, ptr %p1052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1053, ptr %slot130, align 8
  %v1054 = load i32, ptr %slot130, align 8
  %cv1055 = zext i32 %v1054 to i64
  %cond1056 = icmp ne i64 %cv1055, 0
  br i1 %cond1056, label %bb_rcslotdrop135, label %bb_rcslotdone135
bb_rcslotdrop135:
  %v1057 = load i64, ptr %slot15, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i32 0, ptr %p1058, align 4, !alias.scope !3, !noalias !4
  %v1059 = load i64, ptr %slot23, align 8
  store i64 %v1059, ptr %slot131, align 8
  %v1060 = load i64, ptr %slot16, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  %ld1062 = load i32, ptr %p1061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1062, ptr %slot132, align 8
  %v1063 = load i32, ptr %slot132, align 8
  %op1064 = and i32 %v1063, 28
  store i32 %op1064, ptr %slot133, align 8
  %v1065 = load i32, ptr %slot133, align 8
  %cv1066 = zext i32 %v1065 to i64
  %cond1067 = icmp ne i64 %cv1066, 0
  br i1 %cond1067, label %bb_rcslotrole135, label %bb_rcslotowner135
bb_rcslotrole135:
  %v1068 = load i64, ptr %slot47, align 8
  store i64 %v1068, ptr %slot134, align 8
  %v1069 = load i64, ptr %slot134, align 8
  %v1070 = load i64, ptr %slot131, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1069, i64 %v1070) nomerge, !dbg !122
  br label %bb_rcslotdone135
bb_rcslotowner135:
  %v1071 = load i64, ptr %slot47, align 8
  store i64 %v1071, ptr %slot135, align 8
  %v1072 = load i64, ptr %slot135, align 8
  %v1073 = load i64, ptr %slot131, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1072, i64 %v1073) nomerge, !dbg !122
  br label %bb_rcslotdone135
bb_rcslotdone135:
  %v1074 = load i64, ptr %slot17, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  %ld1076 = load i32, ptr %p1075, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1076, ptr %slot136, align 8
  %v1077 = load i32, ptr %slot136, align 8
  %cv1078 = zext i32 %v1077 to i64
  %cond1079 = icmp ne i64 %cv1078, 0
  br i1 %cond1079, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v1080 = load i64, ptr %slot17, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  store i32 0, ptr %p1081, align 4, !alias.scope !3, !noalias !4
  %v1082 = load i64, ptr %slot24, align 8
  store i64 %v1082, ptr %slot137, align 8
  %v1083 = load i64, ptr %slot18, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  %ld1085 = load i32, ptr %p1084, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1085, ptr %slot138, align 8
  %v1086 = load i32, ptr %slot138, align 8
  %op1087 = and i32 %v1086, 28
  store i32 %op1087, ptr %slot139, align 8
  %v1088 = load i32, ptr %slot139, align 8
  %cv1089 = zext i32 %v1088 to i64
  %cond1090 = icmp ne i64 %cv1089, 0
  br i1 %cond1090, label %bb_rcslotrole144, label %bb_rcslotowner144
bb_rcslotrole144:
  %v1091 = load i64, ptr %slot47, align 8
  store i64 %v1091, ptr %slot140, align 8
  %v1092 = load i64, ptr %slot137, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %ld1094 = load i64, ptr %p1093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1094, ptr %slot141, align 8
  %v1095 = load i64, ptr %slot141, align 8
  %cmp1096 = icmp ne i64 %v1095, 0
  %cv1097 = zext i1 %cmp1096 to i32
  store i32 %cv1097, ptr %slot142, align 8
  %v1098 = load i32, ptr %slot142, align 8
  %cv1099 = zext i32 %v1098 to i64
  %cond1100 = icmp ne i64 %cv1099, 0
  br i1 %cond1100, label %bb_rcgnn160, label %bb_rcgdone160
bb_rcgnn160:
  %v1101 = load i64, ptr %slot141, align 8
  %op1102 = sub i64 %v1101, 16
  store i64 %op1102, ptr %slot143, align 8
  %v1103 = load i64, ptr %slot141, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  %rgep1105 = getelementptr i8, ptr %p1104, i64 -16
  %ld1106 = load i64, ptr %rgep1105, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1106, ptr %slot144, align 8
  %v1107 = load i64, ptr %slot144, align 8
  %op1108 = and i64 %v1107, 4611686018427387906
  store i64 %op1108, ptr %slot145, align 8
  %v1109 = load i64, ptr %slot145, align 8
  %cmp1110 = icmp ne i64 %v1109, 0
  %cv1111 = zext i1 %cmp1110 to i32
  store i32 %cv1111, ptr %slot146, align 8
  %v1112 = load i32, ptr %slot146, align 8
  %cv1113 = zext i32 %v1112 to i64
  %cond1114 = icmp ne i64 %cv1113, 0
  br i1 %cond1114, label %bb_rcgclear160, label %bb_rcgcounted160
bb_rcgcounted160:
  %v1115 = load i64, ptr %slot141, align 8
  %op1116 = sub i64 %v1115, 24
  store i64 %op1116, ptr %slot147, align 8
  %v1117 = load i64, ptr %slot141, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %rgep1119 = getelementptr i8, ptr %p1118, i64 -24
  %ld1120 = load i64, ptr %rgep1119, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1120, ptr %slot148, align 8
  %v1121 = load i64, ptr %slot148, align 8
  %op1122 = sub i64 %v1121, 1
  store i64 %op1122, ptr %slot149, align 8
  %v1123 = load i64, ptr %slot149, align 8
  %cmp1124 = icmp eq i64 %v1123, 0
  %cv1125 = zext i1 %cmp1124 to i32
  store i32 %cv1125, ptr %slot150, align 8
  %v1126 = load i32, ptr %slot150, align 8
  %cv1127 = zext i32 %v1126 to i64
  %cond1128 = icmp ne i64 %cv1127, 0
  br i1 %cond1128, label %bb_rcglast160, label %bb_rcgdec160
bb_rcglast160:
  %v1129 = load i64, ptr %slot141, align 8
  %op1130 = sub i64 %v1129, 32
  store i64 %op1130, ptr %slot151, align 8
  %v1131 = load i64, ptr %slot141, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  %rgep1133 = getelementptr i8, ptr %p1132, i64 -32
  %ld1134 = load i64, ptr %rgep1133, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1134, ptr %slot152, align 8
  %v1135 = load i64, ptr %slot152, align 8
  %cmp1136 = icmp ne i64 %v1135, 0
  %cv1137 = zext i1 %cmp1136 to i32
  store i32 %cv1137, ptr %slot153, align 8
  %v1138 = load i32, ptr %slot153, align 8
  %cv1139 = zext i32 %v1138 to i64
  %cond1140 = icmp ne i64 %cv1139, 0
  br i1 %cond1140, label %bb_rcgdec160, label %bb_rcgslow160
bb_rcgslow160:
  %v1141 = load i64, ptr %slot140, align 8
  %v1142 = load i64, ptr %slot137, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1141, i64 %v1142) nomerge, !dbg !122
  br label %bb_rcgdone160
bb_rcgdec160:
  %v1143 = load i64, ptr %slot149, align 8
  %v1144 = load i64, ptr %slot141, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %rgep1146 = getelementptr i8, ptr %p1145, i64 -24
  store i64 %v1143, ptr %rgep1146, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear160
bb_rcgclear160:
  %v1147 = load i64, ptr %slot137, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  store i64 0, ptr %p1148, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone160
bb_rcgdone160:
  br label %bb_rcslotdone144
bb_rcslotowner144:
  %v1149 = load i64, ptr %slot47, align 8
  store i64 %v1149, ptr %slot154, align 8
  %v1150 = load i64, ptr %slot137, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i64, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1152, ptr %slot155, align 8
  %v1153 = load i64, ptr %slot155, align 8
  %cmp1154 = icmp ne i64 %v1153, 0
  %cv1155 = zext i1 %cmp1154 to i32
  store i32 %cv1155, ptr %slot156, align 8
  %v1156 = load i32, ptr %slot156, align 8
  %cv1157 = zext i32 %v1156 to i64
  %cond1158 = icmp ne i64 %cv1157, 0
  br i1 %cond1158, label %bb_rcgnn175, label %bb_rcgdone175
bb_rcgnn175:
  %v1159 = load i64, ptr %slot155, align 8
  %op1160 = sub i64 %v1159, 16
  store i64 %op1160, ptr %slot157, align 8
  %v1161 = load i64, ptr %slot155, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  %rgep1163 = getelementptr i8, ptr %p1162, i64 -16
  %ld1164 = load i64, ptr %rgep1163, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1164, ptr %slot158, align 8
  %v1165 = load i64, ptr %slot158, align 8
  %op1166 = and i64 %v1165, 4611686018427387906
  store i64 %op1166, ptr %slot159, align 8
  %v1167 = load i64, ptr %slot159, align 8
  %cmp1168 = icmp ne i64 %v1167, 0
  %cv1169 = zext i1 %cmp1168 to i32
  store i32 %cv1169, ptr %slot160, align 8
  %v1170 = load i32, ptr %slot160, align 8
  %cv1171 = zext i32 %v1170 to i64
  %cond1172 = icmp ne i64 %cv1171, 0
  br i1 %cond1172, label %bb_rcgclear175, label %bb_rcgcounted175
bb_rcgcounted175:
  %v1173 = load i64, ptr %slot155, align 8
  %op1174 = sub i64 %v1173, 32
  store i64 %op1174, ptr %slot161, align 8
  %v1175 = load i64, ptr %slot155, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  %rgep1177 = getelementptr i8, ptr %p1176, i64 -32
  %ld1178 = load i64, ptr %rgep1177, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1178, ptr %slot162, align 8
  %v1179 = load i64, ptr %slot162, align 8
  %op1180 = sub i64 %v1179, 1
  store i64 %op1180, ptr %slot163, align 8
  %v1181 = load i64, ptr %slot163, align 8
  %cmp1182 = icmp eq i64 %v1181, 0
  %cv1183 = zext i1 %cmp1182 to i32
  store i32 %cv1183, ptr %slot164, align 8
  %v1184 = load i32, ptr %slot164, align 8
  %cv1185 = zext i32 %v1184 to i64
  %cond1186 = icmp ne i64 %cv1185, 0
  br i1 %cond1186, label %bb_rcglast175, label %bb_rcgdec175
bb_rcglast175:
  %v1187 = load i64, ptr %slot155, align 8
  %op1188 = sub i64 %v1187, 24
  store i64 %op1188, ptr %slot165, align 8
  %v1189 = load i64, ptr %slot155, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  %rgep1191 = getelementptr i8, ptr %p1190, i64 -24
  %ld1192 = load i64, ptr %rgep1191, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1192, ptr %slot166, align 8
  %v1193 = load i64, ptr %slot166, align 8
  %cmp1194 = icmp ne i64 %v1193, 0
  %cv1195 = zext i1 %cmp1194 to i32
  store i32 %cv1195, ptr %slot167, align 8
  %v1196 = load i32, ptr %slot167, align 8
  %cv1197 = zext i32 %v1196 to i64
  %cond1198 = icmp ne i64 %cv1197, 0
  br i1 %cond1198, label %bb_rcgdec175, label %bb_rcgslow175
bb_rcgslow175:
  %v1199 = load i64, ptr %slot154, align 8
  %v1200 = load i64, ptr %slot137, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1199, i64 %v1200) nomerge, !dbg !122
  br label %bb_rcgdone175
bb_rcgdec175:
  %v1201 = load i64, ptr %slot163, align 8
  %v1202 = load i64, ptr %slot155, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  %rgep1204 = getelementptr i8, ptr %p1203, i64 -32
  store i64 %v1201, ptr %rgep1204, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear175
bb_rcgclear175:
  %v1205 = load i64, ptr %slot137, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  store i64 0, ptr %p1206, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone175
bb_rcgdone175:
  br label %bb_rcslotdone144
bb_rcslotdone144:
  %v1207 = load i64, ptr %slot36, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  %ld1209 = load i64, ptr %p1208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1209, ptr %slot168, align 8
  %v1210 = load i64, ptr %slot168, align 8
  %v1211 = load i64, ptr %slot35, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i64 %v1210, ptr %p1212, align 8, !alias.scope !3, !noalias !4
  %v1213 = load i64, ptr %slot35, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i64, ptr %p1214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1215, ptr %slot169, align 8
  %v1216 = load i64, ptr %slot169, align 8
  %v1217 = load i64, ptr %slot36, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  store i64 %v1216, ptr %p1218, align 8, !alias.scope !3, !noalias !4
  %v1219 = load i64, ptr %slot34, align 8
  %v1220 = load i64, ptr %slot37, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  store i64 %v1219, ptr %p1221, align 8, !alias.scope !3, !noalias !4
  %v1222 = load i64, ptr %slot37, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  %ld1224 = load i64, ptr %p1223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1224, ptr %slot170, align 8
  %v1225 = load i64, ptr %slot170, align 8
  %op1226 = add i64 %v1225, 0
  store i64 %op1226, ptr %slot171, align 8
  %v1227 = load i64, ptr %slot171, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  %ld1229 = load i64, ptr %p1228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1229, ptr %slot172, align 8
  %v1230 = load i64, ptr %slot172, align 8
  %v1231 = load i64, ptr %slot37, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  store i64 %v1230, ptr %p1232, align 8, !alias.scope !3, !noalias !4
  %v1233 = load i64, ptr %slot37, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  %ld1235 = load i64, ptr %p1234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1235, ptr %slot173, align 8
  %v1236 = load i64, ptr %slot173, align 8
  %v1237 = load i64, ptr %slot25, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  store i64 %v1236, ptr %p1238, align 8, !alias.scope !3, !noalias !4
  %v1239 = load i64, ptr %slot25, align 8
  store i64 %v1239, ptr %slot174, align 8
  %v1240 = load i64, ptr %slot27, align 8
  store i64 %v1240, ptr %slot175, align 8
  %v1241 = load i64, ptr %slot174, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %ld1243 = load i64, ptr %p1242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1243, ptr %slot176, align 8
  %v1244 = load i64, ptr %slot176, align 8
  %cmp1245 = icmp ne i64 %v1244, 0
  %cv1246 = zext i1 %cmp1245 to i32
  store i32 %cv1246, ptr %slot177, align 8
  %v1247 = load i32, ptr %slot177, align 8
  %cv1248 = zext i32 %v1247 to i64
  %cond1249 = icmp ne i64 %cv1248, 0
  br i1 %cond1249, label %bb_rcgnn188, label %bb_rcgstore188
bb_rcgnn188:
  %v1250 = load i64, ptr %slot176, align 8
  %op1251 = sub i64 %v1250, 16
  store i64 %op1251, ptr %slot178, align 8
  %v1252 = load i64, ptr %slot176, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  %rgep1254 = getelementptr i8, ptr %p1253, i64 -16
  %ld1255 = load i64, ptr %rgep1254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1255, ptr %slot179, align 8
  %v1256 = load i64, ptr %slot179, align 8
  %op1257 = and i64 %v1256, 4611686018427387906
  store i64 %op1257, ptr %slot180, align 8
  %v1258 = load i64, ptr %slot180, align 8
  %cmp1259 = icmp ne i64 %v1258, 0
  %cv1260 = zext i1 %cmp1259 to i32
  store i32 %cv1260, ptr %slot181, align 8
  %v1261 = load i32, ptr %slot181, align 8
  %cv1262 = zext i32 %v1261 to i64
  %cond1263 = icmp ne i64 %cv1262, 0
  br i1 %cond1263, label %bb_rcgstore188, label %bb_rcginc188
bb_rcginc188:
  %v1264 = load i64, ptr %slot176, align 8
  %op1265 = sub i64 %v1264, 24
  store i64 %op1265, ptr %slot182, align 8
  %v1266 = load i64, ptr %slot176, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %rgep1268 = getelementptr i8, ptr %p1267, i64 -24
  %ld1269 = load i64, ptr %rgep1268, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1269, ptr %slot183, align 8
  %v1270 = load i64, ptr %slot183, align 8
  %op1271 = add i64 %v1270, 1
  store i64 %op1271, ptr %slot184, align 8
  %v1272 = load i64, ptr %slot184, align 8
  %cmp1273 = icmp eq i64 %v1272, 0
  %cv1274 = zext i1 %cmp1273 to i32
  store i32 %cv1274, ptr %slot185, align 8
  %v1275 = load i32, ptr %slot185, align 8
  %cv1276 = zext i32 %v1275 to i64
  %cond1277 = icmp ne i64 %cv1276, 0
  br i1 %cond1277, label %bb_rcglimit188, label %bb_rcgcapacity188
bb_rcglimit188:
  %v1278 = load i64, ptr %slot1, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  %call1280 = call i32 @myl_qbe_rc_status(ptr %p1279, i32 2) nomerge, !dbg !124
  store i32 %call1280, ptr %slot186, align 8
  br label %bb_failure
bb_rcgcapacity188:
  %v1281 = load i64, ptr %slot184, align 8
  %v1282 = load i64, ptr %slot176, align 8
  %p1283 = inttoptr i64 %v1282 to ptr
  %rgep1284 = getelementptr i8, ptr %p1283, i64 -24
  store i64 %v1281, ptr %rgep1284, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore188
bb_rcgstore188:
  %v1285 = load i64, ptr %slot176, align 8
  %v1286 = load i64, ptr %slot175, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  store i64 %v1285, ptr %p1287, align 8, !alias.scope !3, !noalias !4
  %v1288 = load i64, ptr %slot20, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  store i32 2, ptr %p1289, align 4, !alias.scope !3, !noalias !4
  %v1290 = load i64, ptr %slot20, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  store i32 16, ptr %p1291, align 4, !alias.scope !3, !noalias !4
  %v1292 = load i64, ptr %slot19, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  store i32 1, ptr %p1293, align 4, !alias.scope !3, !noalias !4
  %v1294 = load i64, ptr %slot15, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  %ld1296 = load i32, ptr %p1295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1296, ptr %slot187, align 8
  %v1297 = load i32, ptr %slot187, align 8
  %cv1298 = zext i32 %v1297 to i64
  %cond1299 = icmp ne i64 %cv1298, 0
  br i1 %cond1299, label %bb_rcslotdrop204, label %bb_rcslotdone204
bb_rcslotdrop204:
  %v1300 = load i64, ptr %slot15, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i32 0, ptr %p1301, align 4, !alias.scope !3, !noalias !4
  %v1302 = load i64, ptr %slot23, align 8
  store i64 %v1302, ptr %slot188, align 8
  %v1303 = load i64, ptr %slot16, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  %ld1305 = load i32, ptr %p1304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1305, ptr %slot189, align 8
  %v1306 = load i32, ptr %slot189, align 8
  %op1307 = and i32 %v1306, 28
  store i32 %op1307, ptr %slot190, align 8
  %v1308 = load i32, ptr %slot190, align 8
  %cv1309 = zext i32 %v1308 to i64
  %cond1310 = icmp ne i64 %cv1309, 0
  br i1 %cond1310, label %bb_rcslotrole204, label %bb_rcslotowner204
bb_rcslotrole204:
  %v1311 = load i64, ptr %slot47, align 8
  store i64 %v1311, ptr %slot191, align 8
  %v1312 = load i64, ptr %slot191, align 8
  %v1313 = load i64, ptr %slot188, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1312, i64 %v1313) nomerge, !dbg !124
  br label %bb_rcslotdone204
bb_rcslotowner204:
  %v1314 = load i64, ptr %slot47, align 8
  store i64 %v1314, ptr %slot192, align 8
  %v1315 = load i64, ptr %slot192, align 8
  %v1316 = load i64, ptr %slot188, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1315, i64 %v1316) nomerge, !dbg !124
  br label %bb_rcslotdone204
bb_rcslotdone204:
  %v1317 = load i64, ptr %slot23, align 8
  store i64 %v1317, ptr %slot193, align 8
  %v1318 = load i64, ptr %slot27, align 8
  store i64 %v1318, ptr %slot194, align 8
  %v1319 = load i64, ptr %slot194, align 8
  %v1320 = load i64, ptr %slot193, align 8
  %p1321 = inttoptr i64 %v1319 to ptr
  %p1322 = inttoptr i64 %v1320 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1322, ptr %p1321, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1323 = load i64, ptr %slot16, align 8
  %p1324 = inttoptr i64 %v1323 to ptr
  store i32 2, ptr %p1324, align 4, !alias.scope !3, !noalias !4
  %v1325 = load i64, ptr %slot20, align 8
  %p1326 = inttoptr i64 %v1325 to ptr
  %ld1327 = load i32, ptr %p1326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1327, ptr %slot195, align 8
  %v1328 = load i32, ptr %slot195, align 8
  %v1329 = load i64, ptr %slot16, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  store i32 %v1328, ptr %p1330, align 4, !alias.scope !3, !noalias !4
  %v1331 = load i64, ptr %slot19, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  store i32 0, ptr %p1332, align 4, !alias.scope !3, !noalias !4
  %v1333 = load i64, ptr %slot15, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  store i32 1, ptr %p1334, align 4, !alias.scope !3, !noalias !4
  %v1335 = load i64, ptr %slot193, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  %ld1337 = load i64, ptr %p1336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1337, ptr %slot196, align 8
  %v1338 = load i64, ptr %slot196, align 8
  %v1339 = load i64, ptr %slot37, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  store i64 %v1338, ptr %p1340, align 8, !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot37, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  %ld1343 = load i64, ptr %p1342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1343, ptr %slot197, align 8
  %v1344 = load i64, ptr %slot1, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  %v1346 = load i64, ptr %slot197, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %call1348 = call ptr @myl_qbe_bytes_snapshot(ptr %p1345, ptr %p1347) nomerge, !dbg !126
  %calladdr1349 = ptrtoint ptr %call1348 to i64
  store i64 %calladdr1349, ptr %slot198, align 8
  %v1350 = load i64, ptr %slot198, align 8
  %v1351 = load i64, ptr %slot37, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  store i64 %v1350, ptr %p1352, align 8, !alias.scope !3, !noalias !4
  %v1353 = load i64, ptr %slot37, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %ld1355 = load i64, ptr %p1354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1355, ptr %slot199, align 8
  %v1356 = load i64, ptr %slot199, align 8
  %v1357 = load i64, ptr %slot25, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  store i64 %v1356, ptr %p1358, align 8, !alias.scope !3, !noalias !4
  %v1359 = load i64, ptr %slot25, align 8
  store i64 %v1359, ptr %slot200, align 8
  %v1360 = load i64, ptr %slot27, align 8
  store i64 %v1360, ptr %slot201, align 8
  %v1361 = load i64, ptr %slot200, align 8
  %v1362 = load i64, ptr %slot201, align 8
  %p1363 = inttoptr i64 %v1361 to ptr
  %p1364 = inttoptr i64 %v1362 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1364, ptr %p1363, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1365 = load i64, ptr %slot20, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  store i32 2, ptr %p1366, align 4, !alias.scope !3, !noalias !4
  %v1367 = load i64, ptr %slot19, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  store i32 1, ptr %p1368, align 4, !alias.scope !3, !noalias !4
  %v1369 = load i64, ptr %slot15, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %ld1371 = load i32, ptr %p1370, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1371, ptr %slot202, align 8
  %v1372 = load i32, ptr %slot202, align 8
  %cv1373 = zext i32 %v1372 to i64
  %cond1374 = icmp ne i64 %cv1373, 0
  br i1 %cond1374, label %bb_rcslotdrop229, label %bb_rcslotdone229
bb_rcslotdrop229:
  %v1375 = load i64, ptr %slot15, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i32 0, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot23, align 8
  store i64 %v1377, ptr %slot203, align 8
  %v1378 = load i64, ptr %slot16, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  %ld1380 = load i32, ptr %p1379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1380, ptr %slot204, align 8
  %v1381 = load i32, ptr %slot204, align 8
  %op1382 = and i32 %v1381, 28
  store i32 %op1382, ptr %slot205, align 8
  %v1383 = load i32, ptr %slot205, align 8
  %cv1384 = zext i32 %v1383 to i64
  %cond1385 = icmp ne i64 %cv1384, 0
  br i1 %cond1385, label %bb_rcslotrole229, label %bb_rcslotowner229
bb_rcslotrole229:
  %v1386 = load i64, ptr %slot47, align 8
  store i64 %v1386, ptr %slot206, align 8
  %v1387 = load i64, ptr %slot203, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  %ld1389 = load i64, ptr %p1388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1389, ptr %slot207, align 8
  %v1390 = load i64, ptr %slot207, align 8
  %cmp1391 = icmp ne i64 %v1390, 0
  %cv1392 = zext i1 %cmp1391 to i32
  store i32 %cv1392, ptr %slot208, align 8
  %v1393 = load i32, ptr %slot208, align 8
  %cv1394 = zext i32 %v1393 to i64
  %cond1395 = icmp ne i64 %cv1394, 0
  br i1 %cond1395, label %bb_rcgnn245, label %bb_rcgdone245
bb_rcgnn245:
  %v1396 = load i64, ptr %slot207, align 8
  %op1397 = sub i64 %v1396, 16
  store i64 %op1397, ptr %slot209, align 8
  %v1398 = load i64, ptr %slot207, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  %rgep1400 = getelementptr i8, ptr %p1399, i64 -16
  %ld1401 = load i64, ptr %rgep1400, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1401, ptr %slot210, align 8
  %v1402 = load i64, ptr %slot210, align 8
  %op1403 = and i64 %v1402, 4611686018427387906
  store i64 %op1403, ptr %slot211, align 8
  %v1404 = load i64, ptr %slot211, align 8
  %cmp1405 = icmp ne i64 %v1404, 0
  %cv1406 = zext i1 %cmp1405 to i32
  store i32 %cv1406, ptr %slot212, align 8
  %v1407 = load i32, ptr %slot212, align 8
  %cv1408 = zext i32 %v1407 to i64
  %cond1409 = icmp ne i64 %cv1408, 0
  br i1 %cond1409, label %bb_rcgclear245, label %bb_rcgcounted245
bb_rcgcounted245:
  %v1410 = load i64, ptr %slot207, align 8
  %op1411 = sub i64 %v1410, 24
  store i64 %op1411, ptr %slot213, align 8
  %v1412 = load i64, ptr %slot207, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  %rgep1414 = getelementptr i8, ptr %p1413, i64 -24
  %ld1415 = load i64, ptr %rgep1414, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1415, ptr %slot214, align 8
  %v1416 = load i64, ptr %slot214, align 8
  %op1417 = sub i64 %v1416, 1
  store i64 %op1417, ptr %slot215, align 8
  %v1418 = load i64, ptr %slot215, align 8
  %cmp1419 = icmp eq i64 %v1418, 0
  %cv1420 = zext i1 %cmp1419 to i32
  store i32 %cv1420, ptr %slot216, align 8
  %v1421 = load i32, ptr %slot216, align 8
  %cv1422 = zext i32 %v1421 to i64
  %cond1423 = icmp ne i64 %cv1422, 0
  br i1 %cond1423, label %bb_rcglast245, label %bb_rcgdec245
bb_rcglast245:
  %v1424 = load i64, ptr %slot207, align 8
  %op1425 = sub i64 %v1424, 32
  store i64 %op1425, ptr %slot217, align 8
  %v1426 = load i64, ptr %slot207, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  %rgep1428 = getelementptr i8, ptr %p1427, i64 -32
  %ld1429 = load i64, ptr %rgep1428, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1429, ptr %slot218, align 8
  %v1430 = load i64, ptr %slot218, align 8
  %cmp1431 = icmp ne i64 %v1430, 0
  %cv1432 = zext i1 %cmp1431 to i32
  store i32 %cv1432, ptr %slot219, align 8
  %v1433 = load i32, ptr %slot219, align 8
  %cv1434 = zext i32 %v1433 to i64
  %cond1435 = icmp ne i64 %cv1434, 0
  br i1 %cond1435, label %bb_rcgdec245, label %bb_rcgslow245
bb_rcgslow245:
  %v1436 = load i64, ptr %slot206, align 8
  %v1437 = load i64, ptr %slot203, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1436, i64 %v1437) nomerge, !dbg !126
  br label %bb_rcgdone245
bb_rcgdec245:
  %v1438 = load i64, ptr %slot215, align 8
  %v1439 = load i64, ptr %slot207, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  %rgep1441 = getelementptr i8, ptr %p1440, i64 -24
  store i64 %v1438, ptr %rgep1441, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear245
bb_rcgclear245:
  %v1442 = load i64, ptr %slot203, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  store i64 0, ptr %p1443, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone245
bb_rcgdone245:
  br label %bb_rcslotdone229
bb_rcslotowner229:
  %v1444 = load i64, ptr %slot47, align 8
  store i64 %v1444, ptr %slot220, align 8
  %v1445 = load i64, ptr %slot203, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  %ld1447 = load i64, ptr %p1446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1447, ptr %slot221, align 8
  %v1448 = load i64, ptr %slot221, align 8
  %cmp1449 = icmp ne i64 %v1448, 0
  %cv1450 = zext i1 %cmp1449 to i32
  store i32 %cv1450, ptr %slot222, align 8
  %v1451 = load i32, ptr %slot222, align 8
  %cv1452 = zext i32 %v1451 to i64
  %cond1453 = icmp ne i64 %cv1452, 0
  br i1 %cond1453, label %bb_rcgnn260, label %bb_rcgdone260
bb_rcgnn260:
  %v1454 = load i64, ptr %slot221, align 8
  %op1455 = sub i64 %v1454, 16
  store i64 %op1455, ptr %slot223, align 8
  %v1456 = load i64, ptr %slot221, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %rgep1458 = getelementptr i8, ptr %p1457, i64 -16
  %ld1459 = load i64, ptr %rgep1458, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1459, ptr %slot224, align 8
  %v1460 = load i64, ptr %slot224, align 8
  %op1461 = and i64 %v1460, 4611686018427387906
  store i64 %op1461, ptr %slot225, align 8
  %v1462 = load i64, ptr %slot225, align 8
  %cmp1463 = icmp ne i64 %v1462, 0
  %cv1464 = zext i1 %cmp1463 to i32
  store i32 %cv1464, ptr %slot226, align 8
  %v1465 = load i32, ptr %slot226, align 8
  %cv1466 = zext i32 %v1465 to i64
  %cond1467 = icmp ne i64 %cv1466, 0
  br i1 %cond1467, label %bb_rcgclear260, label %bb_rcgcounted260
bb_rcgcounted260:
  %v1468 = load i64, ptr %slot221, align 8
  %op1469 = sub i64 %v1468, 32
  store i64 %op1469, ptr %slot227, align 8
  %v1470 = load i64, ptr %slot221, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  %rgep1472 = getelementptr i8, ptr %p1471, i64 -32
  %ld1473 = load i64, ptr %rgep1472, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1473, ptr %slot228, align 8
  %v1474 = load i64, ptr %slot228, align 8
  %op1475 = sub i64 %v1474, 1
  store i64 %op1475, ptr %slot229, align 8
  %v1476 = load i64, ptr %slot229, align 8
  %cmp1477 = icmp eq i64 %v1476, 0
  %cv1478 = zext i1 %cmp1477 to i32
  store i32 %cv1478, ptr %slot230, align 8
  %v1479 = load i32, ptr %slot230, align 8
  %cv1480 = zext i32 %v1479 to i64
  %cond1481 = icmp ne i64 %cv1480, 0
  br i1 %cond1481, label %bb_rcglast260, label %bb_rcgdec260
bb_rcglast260:
  %v1482 = load i64, ptr %slot221, align 8
  %op1483 = sub i64 %v1482, 24
  store i64 %op1483, ptr %slot231, align 8
  %v1484 = load i64, ptr %slot221, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %rgep1486 = getelementptr i8, ptr %p1485, i64 -24
  %ld1487 = load i64, ptr %rgep1486, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1487, ptr %slot232, align 8
  %v1488 = load i64, ptr %slot232, align 8
  %cmp1489 = icmp ne i64 %v1488, 0
  %cv1490 = zext i1 %cmp1489 to i32
  store i32 %cv1490, ptr %slot233, align 8
  %v1491 = load i32, ptr %slot233, align 8
  %cv1492 = zext i32 %v1491 to i64
  %cond1493 = icmp ne i64 %cv1492, 0
  br i1 %cond1493, label %bb_rcgdec260, label %bb_rcgslow260
bb_rcgslow260:
  %v1494 = load i64, ptr %slot220, align 8
  %v1495 = load i64, ptr %slot203, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v1494, i64 %v1495) nomerge, !dbg !126
  br label %bb_rcgdone260
bb_rcgdec260:
  %v1496 = load i64, ptr %slot229, align 8
  %v1497 = load i64, ptr %slot221, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  %rgep1499 = getelementptr i8, ptr %p1498, i64 -32
  store i64 %v1496, ptr %rgep1499, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear260
bb_rcgclear260:
  %v1500 = load i64, ptr %slot203, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  store i64 0, ptr %p1501, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone260
bb_rcgdone260:
  br label %bb_rcslotdone229
bb_rcslotdone229:
  %v1502 = load i64, ptr %slot23, align 8
  store i64 %v1502, ptr %slot234, align 8
  %v1503 = load i64, ptr %slot27, align 8
  store i64 %v1503, ptr %slot235, align 8
  %v1504 = load i64, ptr %slot235, align 8
  %v1505 = load i64, ptr %slot234, align 8
  %p1506 = inttoptr i64 %v1504 to ptr
  %p1507 = inttoptr i64 %v1505 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1507, ptr %p1506, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1508 = load i64, ptr %slot16, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  store i32 2, ptr %p1509, align 4, !alias.scope !3, !noalias !4
  %v1510 = load i64, ptr %slot20, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  %ld1512 = load i32, ptr %p1511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1512, ptr %slot236, align 8
  %v1513 = load i32, ptr %slot236, align 8
  %v1514 = load i64, ptr %slot16, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  store i32 %v1513, ptr %p1515, align 4, !alias.scope !3, !noalias !4
  %v1516 = load i64, ptr %slot19, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  store i32 0, ptr %p1517, align 4, !alias.scope !3, !noalias !4
  %v1518 = load i64, ptr %slot15, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  store i32 1, ptr %p1519, align 4, !alias.scope !3, !noalias !4
  %v1520 = load i64, ptr %slot234, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  %ld1522 = load i64, ptr %p1521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1522, ptr %slot237, align 8
  %v1523 = load i64, ptr %slot237, align 8
  %v1524 = load i64, ptr %slot37, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  store i64 %v1523, ptr %p1525, align 8, !alias.scope !3, !noalias !4
  %v1526 = load i64, ptr %slot34, align 8
  %v1527 = load i64, ptr %slot38, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  store i64 %v1526, ptr %p1528, align 8, !alias.scope !3, !noalias !4
  %v1529 = load i64, ptr %slot38, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  %ld1531 = load i64, ptr %p1530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1531, ptr %slot238, align 8
  %v1532 = load i64, ptr %slot238, align 8
  %op1533 = add i64 %v1532, 8
  store i64 %op1533, ptr %slot239, align 8
  %v1534 = load i64, ptr %slot239, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  %ld1536 = load i64, ptr %p1535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1536, ptr %slot240, align 8
  %v1537 = load i64, ptr %slot240, align 8
  %v1538 = load i64, ptr %slot38, align 8
  %p1539 = inttoptr i64 %v1538 to ptr
  store i64 %v1537, ptr %p1539, align 8, !alias.scope !3, !noalias !4
  %v1540 = load i64, ptr %slot38, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  %ld1542 = load i64, ptr %p1541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1542, ptr %slot241, align 8
  %v1543 = load i64, ptr %slot241, align 8
  %v1544 = load i64, ptr %slot26, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  store i64 %v1543, ptr %p1545, align 8, !alias.scope !3, !noalias !4
  %v1546 = load i64, ptr %slot26, align 8
  store i64 %v1546, ptr %slot242, align 8
  %v1547 = load i64, ptr %slot27, align 8
  store i64 %v1547, ptr %slot243, align 8
  %v1548 = load i64, ptr %slot242, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  %ld1550 = load i64, ptr %p1549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1550, ptr %slot244, align 8
  %v1551 = load i64, ptr %slot244, align 8
  %cmp1552 = icmp ne i64 %v1551, 0
  %cv1553 = zext i1 %cmp1552 to i32
  store i32 %cv1553, ptr %slot245, align 8
  %v1554 = load i32, ptr %slot245, align 8
  %cv1555 = zext i32 %v1554 to i64
  %cond1556 = icmp ne i64 %cv1555, 0
  br i1 %cond1556, label %bb_rcgnn280, label %bb_rcgstore280
bb_rcgnn280:
  %v1557 = load i64, ptr %slot244, align 8
  %op1558 = sub i64 %v1557, 16
  store i64 %op1558, ptr %slot246, align 8
  %v1559 = load i64, ptr %slot244, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %rgep1561 = getelementptr i8, ptr %p1560, i64 -16
  %ld1562 = load i64, ptr %rgep1561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1562, ptr %slot247, align 8
  %v1563 = load i64, ptr %slot247, align 8
  %op1564 = and i64 %v1563, 4611686018427387906
  store i64 %op1564, ptr %slot248, align 8
  %v1565 = load i64, ptr %slot248, align 8
  %cmp1566 = icmp ne i64 %v1565, 0
  %cv1567 = zext i1 %cmp1566 to i32
  store i32 %cv1567, ptr %slot249, align 8
  %v1568 = load i32, ptr %slot249, align 8
  %cv1569 = zext i32 %v1568 to i64
  %cond1570 = icmp ne i64 %cv1569, 0
  br i1 %cond1570, label %bb_rcgstore280, label %bb_rcginc280
bb_rcginc280:
  %v1571 = load i64, ptr %slot244, align 8
  %op1572 = sub i64 %v1571, 24
  store i64 %op1572, ptr %slot250, align 8
  %v1573 = load i64, ptr %slot244, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  %rgep1575 = getelementptr i8, ptr %p1574, i64 -24
  %ld1576 = load i64, ptr %rgep1575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1576, ptr %slot251, align 8
  %v1577 = load i64, ptr %slot251, align 8
  %op1578 = add i64 %v1577, 1
  store i64 %op1578, ptr %slot252, align 8
  %v1579 = load i64, ptr %slot252, align 8
  %cmp1580 = icmp eq i64 %v1579, 0
  %cv1581 = zext i1 %cmp1580 to i32
  store i32 %cv1581, ptr %slot253, align 8
  %v1582 = load i32, ptr %slot253, align 8
  %cv1583 = zext i32 %v1582 to i64
  %cond1584 = icmp ne i64 %cv1583, 0
  br i1 %cond1584, label %bb_rcglimit280, label %bb_rcgcapacity280
bb_rcglimit280:
  %v1585 = load i64, ptr %slot1, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  %call1587 = call i32 @myl_qbe_rc_status(ptr %p1586, i32 2) nomerge, !dbg !128
  store i32 %call1587, ptr %slot254, align 8
  br label %bb_failure
bb_rcgcapacity280:
  %v1588 = load i64, ptr %slot252, align 8
  %v1589 = load i64, ptr %slot244, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %rgep1591 = getelementptr i8, ptr %p1590, i64 -24
  store i64 %v1588, ptr %rgep1591, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore280
bb_rcgstore280:
  %v1592 = load i64, ptr %slot244, align 8
  %v1593 = load i64, ptr %slot243, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  store i64 %v1592, ptr %p1594, align 8, !alias.scope !3, !noalias !4
  %v1595 = load i64, ptr %slot20, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  store i32 2, ptr %p1596, align 4, !alias.scope !3, !noalias !4
  %v1597 = load i64, ptr %slot20, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  store i32 16, ptr %p1598, align 4, !alias.scope !3, !noalias !4
  %v1599 = load i64, ptr %slot19, align 8
  %p1600 = inttoptr i64 %v1599 to ptr
  store i32 1, ptr %p1600, align 4, !alias.scope !3, !noalias !4
  %v1601 = load i64, ptr %slot17, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  %ld1603 = load i32, ptr %p1602, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1603, ptr %slot255, align 8
  %v1604 = load i32, ptr %slot255, align 8
  %cv1605 = zext i32 %v1604 to i64
  %cond1606 = icmp ne i64 %cv1605, 0
  br i1 %cond1606, label %bb_rcslotdrop296, label %bb_rcslotdone296
bb_rcslotdrop296:
  %v1607 = load i64, ptr %slot17, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  store i32 0, ptr %p1608, align 4, !alias.scope !3, !noalias !4
  %v1609 = load i64, ptr %slot24, align 8
  store i64 %v1609, ptr %slot256, align 8
  %v1610 = load i64, ptr %slot18, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  %ld1612 = load i32, ptr %p1611, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1612, ptr %slot257, align 8
  %v1613 = load i32, ptr %slot257, align 8
  %op1614 = and i32 %v1613, 28
  store i32 %op1614, ptr %slot258, align 8
  %v1615 = load i32, ptr %slot258, align 8
  %cv1616 = zext i32 %v1615 to i64
  %cond1617 = icmp ne i64 %cv1616, 0
  br i1 %cond1617, label %bb_rcslotrole296, label %bb_rcslotowner296
bb_rcslotrole296:
  %v1618 = load i64, ptr %slot47, align 8
  store i64 %v1618, ptr %slot259, align 8
  %v1619 = load i64, ptr %slot259, align 8
  %v1620 = load i64, ptr %slot256, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1619, i64 %v1620) nomerge, !dbg !128
  br label %bb_rcslotdone296
bb_rcslotowner296:
  %v1621 = load i64, ptr %slot47, align 8
  store i64 %v1621, ptr %slot260, align 8
  %v1622 = load i64, ptr %slot260, align 8
  %v1623 = load i64, ptr %slot256, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1622, i64 %v1623) nomerge, !dbg !128
  br label %bb_rcslotdone296
bb_rcslotdone296:
  %v1624 = load i64, ptr %slot24, align 8
  store i64 %v1624, ptr %slot261, align 8
  %v1625 = load i64, ptr %slot27, align 8
  store i64 %v1625, ptr %slot262, align 8
  %v1626 = load i64, ptr %slot262, align 8
  %v1627 = load i64, ptr %slot261, align 8
  %p1628 = inttoptr i64 %v1626 to ptr
  %p1629 = inttoptr i64 %v1627 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1629, ptr %p1628, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot18, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i32 2, ptr %p1631, align 4, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot20, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  %ld1634 = load i32, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1634, ptr %slot263, align 8
  %v1635 = load i32, ptr %slot263, align 8
  %v1636 = load i64, ptr %slot18, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  store i32 %v1635, ptr %p1637, align 4, !alias.scope !3, !noalias !4
  %v1638 = load i64, ptr %slot19, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 0, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot17, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  store i32 1, ptr %p1641, align 4, !alias.scope !3, !noalias !4
  %v1642 = load i64, ptr %slot261, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  %ld1644 = load i64, ptr %p1643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1644, ptr %slot264, align 8
  %v1645 = load i64, ptr %slot264, align 8
  %v1646 = load i64, ptr %slot38, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  store i64 %v1645, ptr %p1647, align 8, !alias.scope !3, !noalias !4
  %v1648 = load i64, ptr %slot38, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  %ld1650 = load i64, ptr %p1649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1650, ptr %slot265, align 8
  %v1651 = load i64, ptr %slot1, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  %v1653 = load i64, ptr %slot265, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  %call1655 = call ptr @myl_qbe_bytes_snapshot(ptr %p1652, ptr %p1654) nomerge, !dbg !130
  %calladdr1656 = ptrtoint ptr %call1655 to i64
  store i64 %calladdr1656, ptr %slot266, align 8
  %v1657 = load i64, ptr %slot266, align 8
  %v1658 = load i64, ptr %slot38, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  store i64 %v1657, ptr %p1659, align 8, !alias.scope !3, !noalias !4
  %v1660 = load i64, ptr %slot38, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  %ld1662 = load i64, ptr %p1661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1662, ptr %slot267, align 8
  %v1663 = load i64, ptr %slot267, align 8
  %v1664 = load i64, ptr %slot26, align 8
  %p1665 = inttoptr i64 %v1664 to ptr
  store i64 %v1663, ptr %p1665, align 8, !alias.scope !3, !noalias !4
  %v1666 = load i64, ptr %slot26, align 8
  store i64 %v1666, ptr %slot268, align 8
  %v1667 = load i64, ptr %slot27, align 8
  store i64 %v1667, ptr %slot269, align 8
  %v1668 = load i64, ptr %slot268, align 8
  %v1669 = load i64, ptr %slot269, align 8
  %p1670 = inttoptr i64 %v1668 to ptr
  %p1671 = inttoptr i64 %v1669 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1671, ptr %p1670, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1672 = load i64, ptr %slot20, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  store i32 2, ptr %p1673, align 4, !alias.scope !3, !noalias !4
  %v1674 = load i64, ptr %slot19, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i32 1, ptr %p1675, align 4, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot17, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  %ld1678 = load i32, ptr %p1677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1678, ptr %slot270, align 8
  %v1679 = load i32, ptr %slot270, align 8
  %cv1680 = zext i32 %v1679 to i64
  %cond1681 = icmp ne i64 %cv1680, 0
  br i1 %cond1681, label %bb_rcslotdrop321, label %bb_rcslotdone321
bb_rcslotdrop321:
  %v1682 = load i64, ptr %slot17, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  store i32 0, ptr %p1683, align 4, !alias.scope !3, !noalias !4
  %v1684 = load i64, ptr %slot24, align 8
  store i64 %v1684, ptr %slot271, align 8
  %v1685 = load i64, ptr %slot18, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %ld1687 = load i32, ptr %p1686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1687, ptr %slot272, align 8
  %v1688 = load i32, ptr %slot272, align 8
  %op1689 = and i32 %v1688, 28
  store i32 %op1689, ptr %slot273, align 8
  %v1690 = load i32, ptr %slot273, align 8
  %cv1691 = zext i32 %v1690 to i64
  %cond1692 = icmp ne i64 %cv1691, 0
  br i1 %cond1692, label %bb_rcslotrole321, label %bb_rcslotowner321
bb_rcslotrole321:
  %v1693 = load i64, ptr %slot47, align 8
  store i64 %v1693, ptr %slot274, align 8
  %v1694 = load i64, ptr %slot271, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  %ld1696 = load i64, ptr %p1695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1696, ptr %slot275, align 8
  %v1697 = load i64, ptr %slot275, align 8
  %cmp1698 = icmp ne i64 %v1697, 0
  %cv1699 = zext i1 %cmp1698 to i32
  store i32 %cv1699, ptr %slot276, align 8
  %v1700 = load i32, ptr %slot276, align 8
  %cv1701 = zext i32 %v1700 to i64
  %cond1702 = icmp ne i64 %cv1701, 0
  br i1 %cond1702, label %bb_rcgnn337, label %bb_rcgdone337
bb_rcgnn337:
  %v1703 = load i64, ptr %slot275, align 8
  %op1704 = sub i64 %v1703, 16
  store i64 %op1704, ptr %slot277, align 8
  %v1705 = load i64, ptr %slot275, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %rgep1707 = getelementptr i8, ptr %p1706, i64 -16
  %ld1708 = load i64, ptr %rgep1707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1708, ptr %slot278, align 8
  %v1709 = load i64, ptr %slot278, align 8
  %op1710 = and i64 %v1709, 4611686018427387906
  store i64 %op1710, ptr %slot279, align 8
  %v1711 = load i64, ptr %slot279, align 8
  %cmp1712 = icmp ne i64 %v1711, 0
  %cv1713 = zext i1 %cmp1712 to i32
  store i32 %cv1713, ptr %slot280, align 8
  %v1714 = load i32, ptr %slot280, align 8
  %cv1715 = zext i32 %v1714 to i64
  %cond1716 = icmp ne i64 %cv1715, 0
  br i1 %cond1716, label %bb_rcgclear337, label %bb_rcgcounted337
bb_rcgcounted337:
  %v1717 = load i64, ptr %slot275, align 8
  %op1718 = sub i64 %v1717, 24
  store i64 %op1718, ptr %slot281, align 8
  %v1719 = load i64, ptr %slot275, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  %rgep1721 = getelementptr i8, ptr %p1720, i64 -24
  %ld1722 = load i64, ptr %rgep1721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1722, ptr %slot282, align 8
  %v1723 = load i64, ptr %slot282, align 8
  %op1724 = sub i64 %v1723, 1
  store i64 %op1724, ptr %slot283, align 8
  %v1725 = load i64, ptr %slot283, align 8
  %cmp1726 = icmp eq i64 %v1725, 0
  %cv1727 = zext i1 %cmp1726 to i32
  store i32 %cv1727, ptr %slot284, align 8
  %v1728 = load i32, ptr %slot284, align 8
  %cv1729 = zext i32 %v1728 to i64
  %cond1730 = icmp ne i64 %cv1729, 0
  br i1 %cond1730, label %bb_rcglast337, label %bb_rcgdec337
bb_rcglast337:
  %v1731 = load i64, ptr %slot275, align 8
  %op1732 = sub i64 %v1731, 32
  store i64 %op1732, ptr %slot285, align 8
  %v1733 = load i64, ptr %slot275, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  %rgep1735 = getelementptr i8, ptr %p1734, i64 -32
  %ld1736 = load i64, ptr %rgep1735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1736, ptr %slot286, align 8
  %v1737 = load i64, ptr %slot286, align 8
  %cmp1738 = icmp ne i64 %v1737, 0
  %cv1739 = zext i1 %cmp1738 to i32
  store i32 %cv1739, ptr %slot287, align 8
  %v1740 = load i32, ptr %slot287, align 8
  %cv1741 = zext i32 %v1740 to i64
  %cond1742 = icmp ne i64 %cv1741, 0
  br i1 %cond1742, label %bb_rcgdec337, label %bb_rcgslow337
bb_rcgslow337:
  %v1743 = load i64, ptr %slot274, align 8
  %v1744 = load i64, ptr %slot271, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1743, i64 %v1744) nomerge, !dbg !130
  br label %bb_rcgdone337
bb_rcgdec337:
  %v1745 = load i64, ptr %slot283, align 8
  %v1746 = load i64, ptr %slot275, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %rgep1748 = getelementptr i8, ptr %p1747, i64 -24
  store i64 %v1745, ptr %rgep1748, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear337
bb_rcgclear337:
  %v1749 = load i64, ptr %slot271, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  store i64 0, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone337
bb_rcgdone337:
  br label %bb_rcslotdone321
bb_rcslotowner321:
  %v1751 = load i64, ptr %slot47, align 8
  store i64 %v1751, ptr %slot288, align 8
  %v1752 = load i64, ptr %slot271, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  %ld1754 = load i64, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1754, ptr %slot289, align 8
  %v1755 = load i64, ptr %slot289, align 8
  %cmp1756 = icmp ne i64 %v1755, 0
  %cv1757 = zext i1 %cmp1756 to i32
  store i32 %cv1757, ptr %slot290, align 8
  %v1758 = load i32, ptr %slot290, align 8
  %cv1759 = zext i32 %v1758 to i64
  %cond1760 = icmp ne i64 %cv1759, 0
  br i1 %cond1760, label %bb_rcgnn352, label %bb_rcgdone352
bb_rcgnn352:
  %v1761 = load i64, ptr %slot289, align 8
  %op1762 = sub i64 %v1761, 16
  store i64 %op1762, ptr %slot291, align 8
  %v1763 = load i64, ptr %slot289, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  %rgep1765 = getelementptr i8, ptr %p1764, i64 -16
  %ld1766 = load i64, ptr %rgep1765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1766, ptr %slot292, align 8
  %v1767 = load i64, ptr %slot292, align 8
  %op1768 = and i64 %v1767, 4611686018427387906
  store i64 %op1768, ptr %slot293, align 8
  %v1769 = load i64, ptr %slot293, align 8
  %cmp1770 = icmp ne i64 %v1769, 0
  %cv1771 = zext i1 %cmp1770 to i32
  store i32 %cv1771, ptr %slot294, align 8
  %v1772 = load i32, ptr %slot294, align 8
  %cv1773 = zext i32 %v1772 to i64
  %cond1774 = icmp ne i64 %cv1773, 0
  br i1 %cond1774, label %bb_rcgclear352, label %bb_rcgcounted352
bb_rcgcounted352:
  %v1775 = load i64, ptr %slot289, align 8
  %op1776 = sub i64 %v1775, 32
  store i64 %op1776, ptr %slot295, align 8
  %v1777 = load i64, ptr %slot289, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  %rgep1779 = getelementptr i8, ptr %p1778, i64 -32
  %ld1780 = load i64, ptr %rgep1779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1780, ptr %slot296, align 8
  %v1781 = load i64, ptr %slot296, align 8
  %op1782 = sub i64 %v1781, 1
  store i64 %op1782, ptr %slot297, align 8
  %v1783 = load i64, ptr %slot297, align 8
  %cmp1784 = icmp eq i64 %v1783, 0
  %cv1785 = zext i1 %cmp1784 to i32
  store i32 %cv1785, ptr %slot298, align 8
  %v1786 = load i32, ptr %slot298, align 8
  %cv1787 = zext i32 %v1786 to i64
  %cond1788 = icmp ne i64 %cv1787, 0
  br i1 %cond1788, label %bb_rcglast352, label %bb_rcgdec352
bb_rcglast352:
  %v1789 = load i64, ptr %slot289, align 8
  %op1790 = sub i64 %v1789, 24
  store i64 %op1790, ptr %slot299, align 8
  %v1791 = load i64, ptr %slot289, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  %rgep1793 = getelementptr i8, ptr %p1792, i64 -24
  %ld1794 = load i64, ptr %rgep1793, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1794, ptr %slot300, align 8
  %v1795 = load i64, ptr %slot300, align 8
  %cmp1796 = icmp ne i64 %v1795, 0
  %cv1797 = zext i1 %cmp1796 to i32
  store i32 %cv1797, ptr %slot301, align 8
  %v1798 = load i32, ptr %slot301, align 8
  %cv1799 = zext i32 %v1798 to i64
  %cond1800 = icmp ne i64 %cv1799, 0
  br i1 %cond1800, label %bb_rcgdec352, label %bb_rcgslow352
bb_rcgslow352:
  %v1801 = load i64, ptr %slot288, align 8
  %v1802 = load i64, ptr %slot271, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v1801, i64 %v1802) nomerge, !dbg !130
  br label %bb_rcgdone352
bb_rcgdec352:
  %v1803 = load i64, ptr %slot297, align 8
  %v1804 = load i64, ptr %slot289, align 8
  %p1805 = inttoptr i64 %v1804 to ptr
  %rgep1806 = getelementptr i8, ptr %p1805, i64 -32
  store i64 %v1803, ptr %rgep1806, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear352
bb_rcgclear352:
  %v1807 = load i64, ptr %slot271, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i64 0, ptr %p1808, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone352
bb_rcgdone352:
  br label %bb_rcslotdone321
bb_rcslotdone321:
  %v1809 = load i64, ptr %slot24, align 8
  store i64 %v1809, ptr %slot302, align 8
  %v1810 = load i64, ptr %slot27, align 8
  store i64 %v1810, ptr %slot303, align 8
  %v1811 = load i64, ptr %slot303, align 8
  %v1812 = load i64, ptr %slot302, align 8
  %p1813 = inttoptr i64 %v1811 to ptr
  %p1814 = inttoptr i64 %v1812 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1814, ptr %p1813, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot18, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  store i32 2, ptr %p1816, align 4, !alias.scope !3, !noalias !4
  %v1817 = load i64, ptr %slot20, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  %ld1819 = load i32, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1819, ptr %slot304, align 8
  %v1820 = load i32, ptr %slot304, align 8
  %v1821 = load i64, ptr %slot18, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  store i32 %v1820, ptr %p1822, align 4, !alias.scope !3, !noalias !4
  %v1823 = load i64, ptr %slot19, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  store i32 0, ptr %p1824, align 4, !alias.scope !3, !noalias !4
  %v1825 = load i64, ptr %slot17, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  store i32 1, ptr %p1826, align 4, !alias.scope !3, !noalias !4
  %v1827 = load i64, ptr %slot302, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %ld1829 = load i64, ptr %p1828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1829, ptr %slot305, align 8
  %v1830 = load i64, ptr %slot305, align 8
  %v1831 = load i64, ptr %slot38, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  store i64 %v1830, ptr %p1832, align 8, !alias.scope !3, !noalias !4
  %v1833 = load i64, ptr %slot33, align 8
  %v1834 = load i64, ptr %slot39, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  store i64 %v1833, ptr %p1835, align 8, !alias.scope !3, !noalias !4
  %v1836 = load i64, ptr %slot39, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %ld1838 = load i64, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1838, ptr %slot306, align 8
  %v1839 = load i64, ptr %slot306, align 8
  %op1840 = add i64 %v1839, 96
  store i64 %op1840, ptr %slot307, align 8
  %v1841 = load i64, ptr %slot307, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %ld1843 = load i64, ptr %p1842, align 8
  store i64 %ld1843, ptr %slot308, align 8
  %v1844 = load i64, ptr %slot308, align 8
  %v1845 = load i64, ptr %slot39, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  store i64 %v1844, ptr %p1846, align 8, !alias.scope !3, !noalias !4
  %v1847 = load i64, ptr %slot33, align 8
  %v1848 = load i64, ptr %slot40, align 8
  %p1849 = inttoptr i64 %v1848 to ptr
  store i64 %v1847, ptr %p1849, align 8, !alias.scope !3, !noalias !4
  %v1850 = load i64, ptr %slot40, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  %ld1852 = load i64, ptr %p1851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1852, ptr %slot309, align 8
  %v1853 = load i64, ptr %slot309, align 8
  %op1854 = add i64 %v1853, 104
  store i64 %op1854, ptr %slot310, align 8
  %v1855 = load i64, ptr %slot310, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %ld1857 = load i64, ptr %p1856, align 8
  store i64 %ld1857, ptr %slot311, align 8
  %v1858 = load i64, ptr %slot311, align 8
  %v1859 = load i64, ptr %slot40, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  store i64 %v1858, ptr %p1860, align 8, !alias.scope !3, !noalias !4
  %v1861 = load i64, ptr %slot33, align 8
  %v1862 = load i64, ptr %slot41, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i64 %v1861, ptr %p1863, align 8, !alias.scope !3, !noalias !4
  %v1864 = load i64, ptr %slot41, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  %ld1866 = load i64, ptr %p1865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1866, ptr %slot312, align 8
  %v1867 = load i64, ptr %slot312, align 8
  %op1868 = add i64 %v1867, 112
  store i64 %op1868, ptr %slot313, align 8
  %v1869 = load i64, ptr %slot313, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  %ld1871 = load i64, ptr %p1870, align 8
  store i64 %ld1871, ptr %slot314, align 8
  %v1872 = load i64, ptr %slot314, align 8
  %v1873 = load i64, ptr %slot41, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  store i64 %v1872, ptr %p1874, align 8, !alias.scope !3, !noalias !4
  %v1875 = load i64, ptr %slot42, align 8
  store i64 %v1875, ptr %slot315, align 8
  %v1876 = load i64, ptr %slot315, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i64 0, ptr %p1877, align 8, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot315, align 8
  %p1880 = inttoptr i64 %v1878 to ptr
  %gep1881 = getelementptr i8, ptr %p1880, i64 8
  %op1879 = ptrtoint ptr %gep1881 to i64
  store i64 %op1879, ptr %slot316, align 8
  %v1882 = load i64, ptr %slot316, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  store i64 0, ptr %p1883, align 8, !alias.scope !3, !noalias !4
  %v1884 = load i64, ptr %slot315, align 8
  %p1886 = inttoptr i64 %v1884 to ptr
  %gep1887 = getelementptr i8, ptr %p1886, i64 16
  %op1885 = ptrtoint ptr %gep1887 to i64
  store i64 %op1885, ptr %slot317, align 8
  %v1888 = load i64, ptr %slot317, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i64 0, ptr %p1889, align 8, !alias.scope !3, !noalias !4
  %v1890 = load i64, ptr %slot315, align 8
  %p1892 = inttoptr i64 %v1890 to ptr
  %gep1893 = getelementptr i8, ptr %p1892, i64 24
  %op1891 = ptrtoint ptr %gep1893 to i64
  store i64 %op1891, ptr %slot318, align 8
  %v1894 = load i64, ptr %slot318, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  store i64 0, ptr %p1895, align 8, !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot315, align 8
  %p1898 = inttoptr i64 %v1896 to ptr
  %gep1899 = getelementptr i8, ptr %p1898, i64 32
  %op1897 = ptrtoint ptr %gep1899 to i64
  store i64 %op1897, ptr %slot319, align 8
  %v1900 = load i64, ptr %slot319, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  store i64 0, ptr %p1901, align 8, !alias.scope !3, !noalias !4
  %v1902 = load i64, ptr %slot315, align 8
  %p1904 = inttoptr i64 %v1902 to ptr
  %gep1905 = getelementptr i8, ptr %p1904, i64 40
  %op1903 = ptrtoint ptr %gep1905 to i64
  store i64 %op1903, ptr %slot320, align 8
  %v1906 = load i64, ptr %slot320, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i64 0, ptr %p1907, align 8, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot21, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  store i32 1, ptr %p1909, align 4, !alias.scope !3, !noalias !4
  %v1910 = load i64, ptr %slot48, align 8
  store i64 %v1910, ptr %slot321, align 8
  %v1911 = load i64, ptr %slot36, align 8
  store i64 %v1911, ptr %slot322, align 8
  %v1912 = load i64, ptr %slot315, align 8
  %p1914 = inttoptr i64 %v1912 to ptr
  %gep1915 = getelementptr i8, ptr %p1914, i64 0
  %op1913 = ptrtoint ptr %gep1915 to i64
  store i64 %op1913, ptr %slot323, align 8
  %v1916 = load i64, ptr %slot322, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  %ld1918 = load i64, ptr %p1917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1918, ptr %slot324, align 8
  %v1919 = load i64, ptr %slot324, align 8
  %v1920 = load i64, ptr %slot323, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  store i64 %v1919, ptr %p1921, align 8, !alias.scope !3, !noalias !4
  %v1922 = load i64, ptr %slot37, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %ld1924 = load i64, ptr %p1923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1924, ptr %slot325, align 8
  %v1925 = load i64, ptr %slot325, align 8
  %v1926 = load i64, ptr %slot25, align 8
  %p1927 = inttoptr i64 %v1926 to ptr
  store i64 %v1925, ptr %p1927, align 8, !alias.scope !3, !noalias !4
  %v1928 = load i64, ptr %slot25, align 8
  store i64 %v1928, ptr %slot326, align 8
  %v1929 = load i64, ptr %slot315, align 8
  %p1931 = inttoptr i64 %v1929 to ptr
  %gep1932 = getelementptr i8, ptr %p1931, i64 8
  %op1930 = ptrtoint ptr %gep1932 to i64
  store i64 %op1930, ptr %slot327, align 8
  %v1933 = load i64, ptr %slot37, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  %ld1935 = load i64, ptr %p1934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1935, ptr %slot328, align 8
  %v1936 = load i64, ptr %slot328, align 8
  %v1937 = load i64, ptr %slot25, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  store i64 %v1936, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  %v1939 = load i64, ptr %slot25, align 8
  store i64 %v1939, ptr %slot329, align 8
  %v1940 = load i64, ptr %slot15, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  %ld1942 = load i32, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1942, ptr %slot330, align 8
  %v1943 = load i64, ptr %slot16, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  %ld1945 = load i32, ptr %p1944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1945, ptr %slot331, align 8
  %v1946 = load i32, ptr %slot331, align 8
  %op1947 = and i32 %v1946, 24
  store i32 %op1947, ptr %slot331, align 8
  %v1948 = load i32, ptr %slot331, align 8
  %cmp1949 = icmp eq i32 %v1948, 0
  %cv1950 = zext i1 %cmp1949 to i32
  store i32 %cv1950, ptr %slot332, align 8
  %v1951 = load i32, ptr %slot330, align 8
  %v1952 = load i32, ptr %slot332, align 8
  %op1953 = and i32 %v1951, %v1952
  store i32 %op1953, ptr %slot333, align 8
  %v1954 = load i32, ptr %slot333, align 8
  %cv1955 = zext i32 %v1954 to i64
  %cond1956 = icmp ne i64 %cv1955, 0
  br i1 %cond1956, label %bb_rctake418, label %bb_rccopy418
bb_rctake418:
  %v1957 = load i64, ptr %slot27, align 8
  store i64 %v1957, ptr %slot334, align 8
  %v1958 = load i64, ptr %slot48, align 8
  store i64 %v1958, ptr %slot335, align 8
  %v1959 = load i64, ptr %slot329, align 8
  %v1960 = load i64, ptr %slot334, align 8
  %op1961 = sub i64 %v1959, %v1960
  store i64 %op1961, ptr %slot336, align 8
  %v1962 = load i64, ptr %slot334, align 8
  %v1963 = load i64, ptr %slot329, align 8
  %op1964 = sub i64 %v1962, %v1963
  store i64 %op1964, ptr %slot337, align 8
  %v1965 = load i64, ptr %slot336, align 8
  %cmp1966 = icmp ult i64 %v1965, 8
  %cv1967 = zext i1 %cmp1966 to i32
  store i32 %cv1967, ptr %slot338, align 8
  %v1968 = load i64, ptr %slot337, align 8
  %cmp1969 = icmp ult i64 %v1968, 8
  %cv1970 = zext i1 %cmp1969 to i32
  store i32 %cv1970, ptr %slot339, align 8
  %v1971 = load i32, ptr %slot338, align 8
  %v1972 = load i32, ptr %slot339, align 8
  %op1973 = or i32 %v1971, %v1972
  store i32 %op1973, ptr %slot340, align 8
  %v1974 = load i32, ptr %slot340, align 8
  %cv1975 = zext i32 %v1974 to i64
  %cond1976 = icmp ne i64 %cv1975, 0
  br i1 %cond1976, label %bb_rcmoveslow427, label %bb_rcmovecheck427
bb_rcmovecheck427:
  %v1977 = load i64, ptr %slot329, align 8
  %p1979 = inttoptr i64 %v1977 to ptr
  %gep1980 = getelementptr i8, ptr %p1979, i64 0
  %op1978 = ptrtoint ptr %gep1980 to i64
  store i64 %op1978, ptr %slot341, align 8
  %v1981 = load i64, ptr %slot341, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  %ld1983 = load i64, ptr %p1982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1983, ptr %slot342, align 8
  %v1984 = load i64, ptr %slot342, align 8
  %cmp1985 = icmp ne i64 %v1984, 0
  %cv1986 = zext i1 %cmp1985 to i32
  store i32 %cv1986, ptr %slot343, align 8
  %v1987 = load i32, ptr %slot343, align 8
  %cv1988 = zext i32 %v1987 to i64
  %cond1989 = icmp ne i64 %cv1988, 0
  br i1 %cond1989, label %bb_rcmoveheader435, label %bb_rcmovenext435
bb_rcmoveheader435:
  %v1990 = load i64, ptr %slot342, align 8
  %op1991 = sub i64 %v1990, 16
  store i64 %op1991, ptr %slot344, align 8
  %v1992 = load i64, ptr %slot342, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  %rgep1994 = getelementptr i8, ptr %p1993, i64 -16
  %ld1995 = load i64, ptr %rgep1994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1995, ptr %slot345, align 8
  %v1996 = load i64, ptr %slot345, align 8
  %op1997 = and i64 %v1996, 5764607523034234881
  store i64 %op1997, ptr %slot346, align 8
  %v1998 = load i64, ptr %slot346, align 8
  %cmp1999 = icmp ne i64 %v1998, 0
  %cv2000 = zext i1 %cmp1999 to i32
  store i32 %cv2000, ptr %slot347, align 8
  %v2001 = load i32, ptr %slot347, align 8
  %cv2002 = zext i32 %v2001 to i64
  %cond2003 = icmp ne i64 %cv2002, 0
  br i1 %cond2003, label %bb_rcmoveslow427, label %bb_rcmovenext435
bb_rcmovenext435:
  %v2004 = load i64, ptr %slot329, align 8
  %v2005 = load i64, ptr %slot334, align 8
  %p2006 = inttoptr i64 %v2004 to ptr
  %p2007 = inttoptr i64 %v2005 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2007, ptr %p2006, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2008 = load i64, ptr %slot329, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  store i64 0, ptr %p2009, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved427
bb_rcmoveslow427:
  %v2010 = load i64, ptr %slot47, align 8
  %v2011 = load i64, ptr %slot334, align 8
  %v2012 = load i64, ptr %slot329, align 8
  %v2013 = load i64, ptr %slot335, align 8
  %cv2014 = trunc i64 %v2013 to i32
  %call2015 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2010, i64 %v2011, i64 %v2012, i32 %cv2014) nomerge, !dbg !132
  store i32 %call2015, ptr %slot348, align 8
  %v2016 = load i32, ptr %slot348, align 8
  %cv2017 = zext i32 %v2016 to i64
  %cond2018 = icmp ne i64 %cv2017, 0
  br i1 %cond2018, label %bb_rcsuccess442, label %bb_rcfailure442
bb_rcfailure442:
  %v2019 = load i64, ptr %slot47, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %call2021 = call i32 @myl_rc_take_failure(ptr %p2020) nomerge, !dbg !132
  store i32 %call2021, ptr %slot349, align 8
  %v2022 = load i64, ptr %slot1, align 8
  %p2023 = inttoptr i64 %v2022 to ptr
  %v2024 = load i32, ptr %slot349, align 8
  %call2025 = call i32 @myl_qbe_rc_status(ptr %p2023, i32 %v2024) nomerge, !dbg !132
  store i32 %call2025, ptr %slot350, align 8
  br label %bb_failure
bb_rcsuccess442:
  br label %bb_rcmoved427
bb_rcmoved427:
  %v2026 = load i64, ptr %slot15, align 8
  %p2027 = inttoptr i64 %v2026 to ptr
  store i32 0, ptr %p2027, align 4, !alias.scope !3, !noalias !4
  %v2028 = load i64, ptr %slot20, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  store i32 2, ptr %p2029, align 4, !alias.scope !3, !noalias !4
  %v2030 = load i64, ptr %slot19, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  store i32 1, ptr %p2031, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared418
bb_rccopy418:
  %v2032 = load i64, ptr %slot27, align 8
  store i64 %v2032, ptr %slot351, align 8
  %v2033 = load i64, ptr %slot48, align 8
  store i64 %v2033, ptr %slot352, align 8
  %v2034 = load i64, ptr %slot329, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %ld2036 = load i64, ptr %p2035, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2036, ptr %slot353, align 8
  %v2037 = load i64, ptr %slot353, align 8
  %cmp2038 = icmp ne i64 %v2037, 0
  %cv2039 = zext i1 %cmp2038 to i32
  store i32 %cv2039, ptr %slot354, align 8
  %v2040 = load i32, ptr %slot354, align 8
  %cv2041 = zext i32 %v2040 to i64
  %cond2042 = icmp ne i64 %cv2041, 0
  br i1 %cond2042, label %bb_rcgnn451, label %bb_rcgplain451
bb_rcgnn451:
  %v2043 = load i64, ptr %slot353, align 8
  %op2044 = sub i64 %v2043, 16
  store i64 %op2044, ptr %slot355, align 8
  %v2045 = load i64, ptr %slot353, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  %rgep2047 = getelementptr i8, ptr %p2046, i64 -16
  %ld2048 = load i64, ptr %rgep2047, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2048, ptr %slot356, align 8
  %v2049 = load i64, ptr %slot356, align 8
  %op2050 = and i64 %v2049, 4611686018427387906
  store i64 %op2050, ptr %slot357, align 8
  %v2051 = load i64, ptr %slot357, align 8
  %cmp2052 = icmp ne i64 %v2051, 0
  %cv2053 = zext i1 %cmp2052 to i32
  store i32 %cv2053, ptr %slot358, align 8
  %v2054 = load i32, ptr %slot358, align 8
  %cv2055 = zext i32 %v2054 to i64
  %cond2056 = icmp ne i64 %cv2055, 0
  br i1 %cond2056, label %bb_rcgspecial451, label %bb_rcginc451
bb_rcginc451:
  %v2057 = load i64, ptr %slot353, align 8
  %op2058 = sub i64 %v2057, 32
  store i64 %op2058, ptr %slot359, align 8
  %v2059 = load i64, ptr %slot353, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  %rgep2061 = getelementptr i8, ptr %p2060, i64 -32
  %ld2062 = load i64, ptr %rgep2061, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2062, ptr %slot360, align 8
  %v2063 = load i64, ptr %slot360, align 8
  %op2064 = add i64 %v2063, 1
  store i64 %op2064, ptr %slot361, align 8
  %v2065 = load i64, ptr %slot361, align 8
  %cmp2066 = icmp eq i64 %v2065, 0
  %cv2067 = zext i1 %cmp2066 to i32
  store i32 %cv2067, ptr %slot362, align 8
  %v2068 = load i32, ptr %slot362, align 8
  %cv2069 = zext i32 %v2068 to i64
  %cond2070 = icmp ne i64 %cv2069, 0
  br i1 %cond2070, label %bb_rcglimit451, label %bb_rcgcapacity451
bb_rcglimit451:
  %v2071 = load i64, ptr %slot1, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  %call2073 = call i32 @myl_qbe_rc_status(ptr %p2072, i32 2) nomerge, !dbg !132
  store i32 %call2073, ptr %slot363, align 8
  br label %bb_failure
bb_rcgcapacity451:
  %v2074 = load i64, ptr %slot361, align 8
  %v2075 = load i64, ptr %slot353, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %rgep2077 = getelementptr i8, ptr %p2076, i64 -32
  store i64 %v2074, ptr %rgep2077, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain451
bb_rcgspecial451:
  %v2078 = load i64, ptr %slot356, align 8
  %op2079 = and i64 %v2078, 4611686018427387904
  store i64 %op2079, ptr %slot364, align 8
  %v2080 = load i64, ptr %slot364, align 8
  %cmp2081 = icmp ne i64 %v2080, 0
  %cv2082 = zext i1 %cmp2081 to i32
  store i32 %cv2082, ptr %slot365, align 8
  %v2083 = load i32, ptr %slot365, align 8
  %cv2084 = zext i32 %v2083 to i64
  %cond2085 = icmp ne i64 %cv2084, 0
  br i1 %cond2085, label %bb_rcgslow451, label %bb_rcgplain451
bb_rcgslow451:
  %v2086 = load i64, ptr %slot47, align 8
  %v2087 = load i64, ptr %slot351, align 8
  %v2088 = load i64, ptr %slot329, align 8
  %v2089 = load i64, ptr %slot352, align 8
  %cv2090 = trunc i64 %v2089 to i32
  %call2091 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v2086, i64 %v2087, i64 %v2088, i32 %cv2090) nomerge, !dbg !132
  store i32 %call2091, ptr %slot366, align 8
  %v2092 = load i32, ptr %slot366, align 8
  %cv2093 = zext i32 %v2092 to i64
  %cond2094 = icmp ne i64 %cv2093, 0
  br i1 %cond2094, label %bb_rcsuccess465, label %bb_rcfailure465
bb_rcfailure465:
  %v2095 = load i64, ptr %slot47, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  %call2097 = call i32 @myl_rc_take_failure(ptr %p2096) nomerge, !dbg !132
  store i32 %call2097, ptr %slot367, align 8
  %v2098 = load i64, ptr %slot1, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  %v2100 = load i32, ptr %slot367, align 8
  %call2101 = call i32 @myl_qbe_rc_status(ptr %p2099, i32 %v2100) nomerge, !dbg !132
  store i32 %call2101, ptr %slot368, align 8
  br label %bb_failure
bb_rcsuccess465:
  br label %bb_rcgdone451
bb_rcgplain451:
  %v2102 = load i64, ptr %slot353, align 8
  %v2103 = load i64, ptr %slot351, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  store i64 %v2102, ptr %p2104, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone451
bb_rcgdone451:
  %v2105 = load i64, ptr %slot20, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  store i32 2, ptr %p2106, align 4, !alias.scope !3, !noalias !4
  %v2107 = load i64, ptr %slot19, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  store i32 1, ptr %p2108, align 4, !alias.scope !3, !noalias !4
  %v2109 = load i64, ptr %slot15, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  %ld2111 = load i32, ptr %p2110, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2111, ptr %slot369, align 8
  %v2112 = load i32, ptr %slot369, align 8
  %cv2113 = zext i32 %v2112 to i64
  %cond2114 = icmp ne i64 %cv2113, 0
  br i1 %cond2114, label %bb_rcslotdrop472, label %bb_rcslotdone472
bb_rcslotdrop472:
  %v2115 = load i64, ptr %slot15, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i32 0, ptr %p2116, align 4, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot23, align 8
  store i64 %v2117, ptr %slot370, align 8
  %v2118 = load i64, ptr %slot16, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  %ld2120 = load i32, ptr %p2119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2120, ptr %slot371, align 8
  %v2121 = load i32, ptr %slot371, align 8
  %op2122 = and i32 %v2121, 28
  store i32 %op2122, ptr %slot372, align 8
  %v2123 = load i32, ptr %slot372, align 8
  %cv2124 = zext i32 %v2123 to i64
  %cond2125 = icmp ne i64 %cv2124, 0
  br i1 %cond2125, label %bb_rcslotrole472, label %bb_rcslotowner472
bb_rcslotrole472:
  %v2126 = load i64, ptr %slot47, align 8
  store i64 %v2126, ptr %slot373, align 8
  %v2127 = load i64, ptr %slot370, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  %ld2129 = load i64, ptr %p2128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2129, ptr %slot374, align 8
  %v2130 = load i64, ptr %slot374, align 8
  %cmp2131 = icmp ne i64 %v2130, 0
  %cv2132 = zext i1 %cmp2131 to i32
  store i32 %cv2132, ptr %slot375, align 8
  %v2133 = load i32, ptr %slot375, align 8
  %cv2134 = zext i32 %v2133 to i64
  %cond2135 = icmp ne i64 %cv2134, 0
  br i1 %cond2135, label %bb_rcgnn488, label %bb_rcgdone488
bb_rcgnn488:
  %v2136 = load i64, ptr %slot374, align 8
  %op2137 = sub i64 %v2136, 16
  store i64 %op2137, ptr %slot376, align 8
  %v2138 = load i64, ptr %slot374, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  %rgep2140 = getelementptr i8, ptr %p2139, i64 -16
  %ld2141 = load i64, ptr %rgep2140, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2141, ptr %slot377, align 8
  %v2142 = load i64, ptr %slot377, align 8
  %op2143 = and i64 %v2142, 4611686018427387906
  store i64 %op2143, ptr %slot378, align 8
  %v2144 = load i64, ptr %slot378, align 8
  %cmp2145 = icmp ne i64 %v2144, 0
  %cv2146 = zext i1 %cmp2145 to i32
  store i32 %cv2146, ptr %slot379, align 8
  %v2147 = load i32, ptr %slot379, align 8
  %cv2148 = zext i32 %v2147 to i64
  %cond2149 = icmp ne i64 %cv2148, 0
  br i1 %cond2149, label %bb_rcgclear488, label %bb_rcgcounted488
bb_rcgcounted488:
  %v2150 = load i64, ptr %slot374, align 8
  %op2151 = sub i64 %v2150, 24
  store i64 %op2151, ptr %slot380, align 8
  %v2152 = load i64, ptr %slot374, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  %rgep2154 = getelementptr i8, ptr %p2153, i64 -24
  %ld2155 = load i64, ptr %rgep2154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2155, ptr %slot381, align 8
  %v2156 = load i64, ptr %slot381, align 8
  %op2157 = sub i64 %v2156, 1
  store i64 %op2157, ptr %slot382, align 8
  %v2158 = load i64, ptr %slot382, align 8
  %cmp2159 = icmp eq i64 %v2158, 0
  %cv2160 = zext i1 %cmp2159 to i32
  store i32 %cv2160, ptr %slot383, align 8
  %v2161 = load i32, ptr %slot383, align 8
  %cv2162 = zext i32 %v2161 to i64
  %cond2163 = icmp ne i64 %cv2162, 0
  br i1 %cond2163, label %bb_rcglast488, label %bb_rcgdec488
bb_rcglast488:
  %v2164 = load i64, ptr %slot374, align 8
  %op2165 = sub i64 %v2164, 32
  store i64 %op2165, ptr %slot384, align 8
  %v2166 = load i64, ptr %slot374, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %rgep2168 = getelementptr i8, ptr %p2167, i64 -32
  %ld2169 = load i64, ptr %rgep2168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2169, ptr %slot385, align 8
  %v2170 = load i64, ptr %slot385, align 8
  %cmp2171 = icmp ne i64 %v2170, 0
  %cv2172 = zext i1 %cmp2171 to i32
  store i32 %cv2172, ptr %slot386, align 8
  %v2173 = load i32, ptr %slot386, align 8
  %cv2174 = zext i32 %v2173 to i64
  %cond2175 = icmp ne i64 %cv2174, 0
  br i1 %cond2175, label %bb_rcgdec488, label %bb_rcgslow488
bb_rcgslow488:
  %v2176 = load i64, ptr %slot373, align 8
  %v2177 = load i64, ptr %slot370, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2176, i64 %v2177) nomerge, !dbg !132
  br label %bb_rcgdone488
bb_rcgdec488:
  %v2178 = load i64, ptr %slot382, align 8
  %v2179 = load i64, ptr %slot374, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  %rgep2181 = getelementptr i8, ptr %p2180, i64 -24
  store i64 %v2178, ptr %rgep2181, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear488
bb_rcgclear488:
  %v2182 = load i64, ptr %slot370, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i64 0, ptr %p2183, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone488
bb_rcgdone488:
  br label %bb_rcslotdone472
bb_rcslotowner472:
  %v2184 = load i64, ptr %slot47, align 8
  store i64 %v2184, ptr %slot387, align 8
  %v2185 = load i64, ptr %slot370, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %ld2187 = load i64, ptr %p2186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2187, ptr %slot388, align 8
  %v2188 = load i64, ptr %slot388, align 8
  %cmp2189 = icmp ne i64 %v2188, 0
  %cv2190 = zext i1 %cmp2189 to i32
  store i32 %cv2190, ptr %slot389, align 8
  %v2191 = load i32, ptr %slot389, align 8
  %cv2192 = zext i32 %v2191 to i64
  %cond2193 = icmp ne i64 %cv2192, 0
  br i1 %cond2193, label %bb_rcgnn503, label %bb_rcgdone503
bb_rcgnn503:
  %v2194 = load i64, ptr %slot388, align 8
  %op2195 = sub i64 %v2194, 16
  store i64 %op2195, ptr %slot390, align 8
  %v2196 = load i64, ptr %slot388, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %rgep2198 = getelementptr i8, ptr %p2197, i64 -16
  %ld2199 = load i64, ptr %rgep2198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2199, ptr %slot391, align 8
  %v2200 = load i64, ptr %slot391, align 8
  %op2201 = and i64 %v2200, 4611686018427387906
  store i64 %op2201, ptr %slot392, align 8
  %v2202 = load i64, ptr %slot392, align 8
  %cmp2203 = icmp ne i64 %v2202, 0
  %cv2204 = zext i1 %cmp2203 to i32
  store i32 %cv2204, ptr %slot393, align 8
  %v2205 = load i32, ptr %slot393, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcgclear503, label %bb_rcgcounted503
bb_rcgcounted503:
  %v2208 = load i64, ptr %slot388, align 8
  %op2209 = sub i64 %v2208, 32
  store i64 %op2209, ptr %slot394, align 8
  %v2210 = load i64, ptr %slot388, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  %rgep2212 = getelementptr i8, ptr %p2211, i64 -32
  %ld2213 = load i64, ptr %rgep2212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2213, ptr %slot395, align 8
  %v2214 = load i64, ptr %slot395, align 8
  %op2215 = sub i64 %v2214, 1
  store i64 %op2215, ptr %slot396, align 8
  %v2216 = load i64, ptr %slot396, align 8
  %cmp2217 = icmp eq i64 %v2216, 0
  %cv2218 = zext i1 %cmp2217 to i32
  store i32 %cv2218, ptr %slot397, align 8
  %v2219 = load i32, ptr %slot397, align 8
  %cv2220 = zext i32 %v2219 to i64
  %cond2221 = icmp ne i64 %cv2220, 0
  br i1 %cond2221, label %bb_rcglast503, label %bb_rcgdec503
bb_rcglast503:
  %v2222 = load i64, ptr %slot388, align 8
  %op2223 = sub i64 %v2222, 24
  store i64 %op2223, ptr %slot398, align 8
  %v2224 = load i64, ptr %slot388, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %rgep2226 = getelementptr i8, ptr %p2225, i64 -24
  %ld2227 = load i64, ptr %rgep2226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2227, ptr %slot399, align 8
  %v2228 = load i64, ptr %slot399, align 8
  %cmp2229 = icmp ne i64 %v2228, 0
  %cv2230 = zext i1 %cmp2229 to i32
  store i32 %cv2230, ptr %slot400, align 8
  %v2231 = load i32, ptr %slot400, align 8
  %cv2232 = zext i32 %v2231 to i64
  %cond2233 = icmp ne i64 %cv2232, 0
  br i1 %cond2233, label %bb_rcgdec503, label %bb_rcgslow503
bb_rcgslow503:
  %v2234 = load i64, ptr %slot387, align 8
  %v2235 = load i64, ptr %slot370, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2234, i64 %v2235) nomerge, !dbg !132
  br label %bb_rcgdone503
bb_rcgdec503:
  %v2236 = load i64, ptr %slot396, align 8
  %v2237 = load i64, ptr %slot388, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  %rgep2239 = getelementptr i8, ptr %p2238, i64 -32
  store i64 %v2236, ptr %rgep2239, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear503
bb_rcgclear503:
  %v2240 = load i64, ptr %slot370, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  store i64 0, ptr %p2241, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone503
bb_rcgdone503:
  br label %bb_rcslotdone472
bb_rcslotdone472:
  br label %bb_rcprepared418
bb_rcprepared418:
  %v2242 = load i64, ptr %slot27, align 8
  store i64 %v2242, ptr %slot401, align 8
  %v2243 = load i64, ptr %slot401, align 8
  %v2244 = load i64, ptr %slot327, align 8
  %p2245 = inttoptr i64 %v2243 to ptr
  %p2246 = inttoptr i64 %v2244 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2246, ptr %p2245, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2247 = load i64, ptr %slot19, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  store i32 0, ptr %p2248, align 4, !alias.scope !3, !noalias !4
  %v2249 = load i64, ptr %slot38, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  %ld2251 = load i64, ptr %p2250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2251, ptr %slot402, align 8
  %v2252 = load i64, ptr %slot402, align 8
  %v2253 = load i64, ptr %slot26, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i64 %v2252, ptr %p2254, align 8, !alias.scope !3, !noalias !4
  %v2255 = load i64, ptr %slot26, align 8
  store i64 %v2255, ptr %slot403, align 8
  %v2256 = load i64, ptr %slot315, align 8
  %p2258 = inttoptr i64 %v2256 to ptr
  %gep2259 = getelementptr i8, ptr %p2258, i64 16
  %op2257 = ptrtoint ptr %gep2259 to i64
  store i64 %op2257, ptr %slot404, align 8
  %v2260 = load i64, ptr %slot38, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  %ld2262 = load i64, ptr %p2261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2262, ptr %slot405, align 8
  %v2263 = load i64, ptr %slot405, align 8
  %v2264 = load i64, ptr %slot26, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  store i64 %v2263, ptr %p2265, align 8, !alias.scope !3, !noalias !4
  %v2266 = load i64, ptr %slot26, align 8
  store i64 %v2266, ptr %slot406, align 8
  %v2267 = load i64, ptr %slot17, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %ld2269 = load i32, ptr %p2268, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2269, ptr %slot407, align 8
  %v2270 = load i64, ptr %slot18, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  %ld2272 = load i32, ptr %p2271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2272, ptr %slot408, align 8
  %v2273 = load i32, ptr %slot408, align 8
  %op2274 = and i32 %v2273, 24
  store i32 %op2274, ptr %slot408, align 8
  %v2275 = load i32, ptr %slot408, align 8
  %cmp2276 = icmp eq i32 %v2275, 0
  %cv2277 = zext i1 %cmp2276 to i32
  store i32 %cv2277, ptr %slot409, align 8
  %v2278 = load i32, ptr %slot407, align 8
  %v2279 = load i32, ptr %slot409, align 8
  %op2280 = and i32 %v2278, %v2279
  store i32 %op2280, ptr %slot410, align 8
  %v2281 = load i32, ptr %slot410, align 8
  %cv2282 = zext i32 %v2281 to i64
  %cond2283 = icmp ne i64 %cv2282, 0
  br i1 %cond2283, label %bb_rctake514, label %bb_rccopy514
bb_rctake514:
  %v2284 = load i64, ptr %slot27, align 8
  store i64 %v2284, ptr %slot411, align 8
  %v2285 = load i64, ptr %slot48, align 8
  store i64 %v2285, ptr %slot412, align 8
  %v2286 = load i64, ptr %slot406, align 8
  %v2287 = load i64, ptr %slot411, align 8
  %op2288 = sub i64 %v2286, %v2287
  store i64 %op2288, ptr %slot413, align 8
  %v2289 = load i64, ptr %slot411, align 8
  %v2290 = load i64, ptr %slot406, align 8
  %op2291 = sub i64 %v2289, %v2290
  store i64 %op2291, ptr %slot414, align 8
  %v2292 = load i64, ptr %slot413, align 8
  %cmp2293 = icmp ult i64 %v2292, 8
  %cv2294 = zext i1 %cmp2293 to i32
  store i32 %cv2294, ptr %slot415, align 8
  %v2295 = load i64, ptr %slot414, align 8
  %cmp2296 = icmp ult i64 %v2295, 8
  %cv2297 = zext i1 %cmp2296 to i32
  store i32 %cv2297, ptr %slot416, align 8
  %v2298 = load i32, ptr %slot415, align 8
  %v2299 = load i32, ptr %slot416, align 8
  %op2300 = or i32 %v2298, %v2299
  store i32 %op2300, ptr %slot417, align 8
  %v2301 = load i32, ptr %slot417, align 8
  %cv2302 = zext i32 %v2301 to i64
  %cond2303 = icmp ne i64 %cv2302, 0
  br i1 %cond2303, label %bb_rcmoveslow523, label %bb_rcmovecheck523
bb_rcmovecheck523:
  %v2304 = load i64, ptr %slot406, align 8
  %p2306 = inttoptr i64 %v2304 to ptr
  %gep2307 = getelementptr i8, ptr %p2306, i64 0
  %op2305 = ptrtoint ptr %gep2307 to i64
  store i64 %op2305, ptr %slot418, align 8
  %v2308 = load i64, ptr %slot418, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  %ld2310 = load i64, ptr %p2309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2310, ptr %slot419, align 8
  %v2311 = load i64, ptr %slot419, align 8
  %cmp2312 = icmp ne i64 %v2311, 0
  %cv2313 = zext i1 %cmp2312 to i32
  store i32 %cv2313, ptr %slot420, align 8
  %v2314 = load i32, ptr %slot420, align 8
  %cv2315 = zext i32 %v2314 to i64
  %cond2316 = icmp ne i64 %cv2315, 0
  br i1 %cond2316, label %bb_rcmoveheader531, label %bb_rcmovenext531
bb_rcmoveheader531:
  %v2317 = load i64, ptr %slot419, align 8
  %op2318 = sub i64 %v2317, 16
  store i64 %op2318, ptr %slot421, align 8
  %v2319 = load i64, ptr %slot419, align 8
  %p2320 = inttoptr i64 %v2319 to ptr
  %rgep2321 = getelementptr i8, ptr %p2320, i64 -16
  %ld2322 = load i64, ptr %rgep2321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2322, ptr %slot422, align 8
  %v2323 = load i64, ptr %slot422, align 8
  %op2324 = and i64 %v2323, 5764607523034234881
  store i64 %op2324, ptr %slot423, align 8
  %v2325 = load i64, ptr %slot423, align 8
  %cmp2326 = icmp ne i64 %v2325, 0
  %cv2327 = zext i1 %cmp2326 to i32
  store i32 %cv2327, ptr %slot424, align 8
  %v2328 = load i32, ptr %slot424, align 8
  %cv2329 = zext i32 %v2328 to i64
  %cond2330 = icmp ne i64 %cv2329, 0
  br i1 %cond2330, label %bb_rcmoveslow523, label %bb_rcmovenext531
bb_rcmovenext531:
  %v2331 = load i64, ptr %slot406, align 8
  %v2332 = load i64, ptr %slot411, align 8
  %p2333 = inttoptr i64 %v2331 to ptr
  %p2334 = inttoptr i64 %v2332 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2334, ptr %p2333, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2335 = load i64, ptr %slot406, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  store i64 0, ptr %p2336, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved523
bb_rcmoveslow523:
  %v2337 = load i64, ptr %slot47, align 8
  %v2338 = load i64, ptr %slot411, align 8
  %v2339 = load i64, ptr %slot406, align 8
  %v2340 = load i64, ptr %slot412, align 8
  %cv2341 = trunc i64 %v2340 to i32
  %call2342 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2337, i64 %v2338, i64 %v2339, i32 %cv2341) nomerge, !dbg !132
  store i32 %call2342, ptr %slot425, align 8
  %v2343 = load i32, ptr %slot425, align 8
  %cv2344 = zext i32 %v2343 to i64
  %cond2345 = icmp ne i64 %cv2344, 0
  br i1 %cond2345, label %bb_rcsuccess538, label %bb_rcfailure538
bb_rcfailure538:
  %v2346 = load i64, ptr %slot47, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %call2348 = call i32 @myl_rc_take_failure(ptr %p2347) nomerge, !dbg !132
  store i32 %call2348, ptr %slot426, align 8
  %v2349 = load i64, ptr %slot1, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  %v2351 = load i32, ptr %slot426, align 8
  %call2352 = call i32 @myl_qbe_rc_status(ptr %p2350, i32 %v2351) nomerge, !dbg !132
  store i32 %call2352, ptr %slot427, align 8
  br label %bb_failure
bb_rcsuccess538:
  br label %bb_rcmoved523
bb_rcmoved523:
  %v2353 = load i64, ptr %slot17, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  store i32 0, ptr %p2354, align 4, !alias.scope !3, !noalias !4
  %v2355 = load i64, ptr %slot20, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i32 2, ptr %p2356, align 4, !alias.scope !3, !noalias !4
  %v2357 = load i64, ptr %slot19, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i32 1, ptr %p2358, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared514
bb_rccopy514:
  %v2359 = load i64, ptr %slot27, align 8
  store i64 %v2359, ptr %slot428, align 8
  %v2360 = load i64, ptr %slot48, align 8
  store i64 %v2360, ptr %slot429, align 8
  %v2361 = load i64, ptr %slot406, align 8
  %p2362 = inttoptr i64 %v2361 to ptr
  %ld2363 = load i64, ptr %p2362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2363, ptr %slot430, align 8
  %v2364 = load i64, ptr %slot430, align 8
  %cmp2365 = icmp ne i64 %v2364, 0
  %cv2366 = zext i1 %cmp2365 to i32
  store i32 %cv2366, ptr %slot431, align 8
  %v2367 = load i32, ptr %slot431, align 8
  %cv2368 = zext i32 %v2367 to i64
  %cond2369 = icmp ne i64 %cv2368, 0
  br i1 %cond2369, label %bb_rcgnn547, label %bb_rcgplain547
bb_rcgnn547:
  %v2370 = load i64, ptr %slot430, align 8
  %op2371 = sub i64 %v2370, 16
  store i64 %op2371, ptr %slot432, align 8
  %v2372 = load i64, ptr %slot430, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %rgep2374 = getelementptr i8, ptr %p2373, i64 -16
  %ld2375 = load i64, ptr %rgep2374, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2375, ptr %slot433, align 8
  %v2376 = load i64, ptr %slot433, align 8
  %op2377 = and i64 %v2376, 4611686018427387906
  store i64 %op2377, ptr %slot434, align 8
  %v2378 = load i64, ptr %slot434, align 8
  %cmp2379 = icmp ne i64 %v2378, 0
  %cv2380 = zext i1 %cmp2379 to i32
  store i32 %cv2380, ptr %slot435, align 8
  %v2381 = load i32, ptr %slot435, align 8
  %cv2382 = zext i32 %v2381 to i64
  %cond2383 = icmp ne i64 %cv2382, 0
  br i1 %cond2383, label %bb_rcgspecial547, label %bb_rcginc547
bb_rcginc547:
  %v2384 = load i64, ptr %slot430, align 8
  %op2385 = sub i64 %v2384, 32
  store i64 %op2385, ptr %slot436, align 8
  %v2386 = load i64, ptr %slot430, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  %rgep2388 = getelementptr i8, ptr %p2387, i64 -32
  %ld2389 = load i64, ptr %rgep2388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2389, ptr %slot437, align 8
  %v2390 = load i64, ptr %slot437, align 8
  %op2391 = add i64 %v2390, 1
  store i64 %op2391, ptr %slot438, align 8
  %v2392 = load i64, ptr %slot438, align 8
  %cmp2393 = icmp eq i64 %v2392, 0
  %cv2394 = zext i1 %cmp2393 to i32
  store i32 %cv2394, ptr %slot439, align 8
  %v2395 = load i32, ptr %slot439, align 8
  %cv2396 = zext i32 %v2395 to i64
  %cond2397 = icmp ne i64 %cv2396, 0
  br i1 %cond2397, label %bb_rcglimit547, label %bb_rcgcapacity547
bb_rcglimit547:
  %v2398 = load i64, ptr %slot1, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  %call2400 = call i32 @myl_qbe_rc_status(ptr %p2399, i32 2) nomerge, !dbg !132
  store i32 %call2400, ptr %slot440, align 8
  br label %bb_failure
bb_rcgcapacity547:
  %v2401 = load i64, ptr %slot438, align 8
  %v2402 = load i64, ptr %slot430, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  %rgep2404 = getelementptr i8, ptr %p2403, i64 -32
  store i64 %v2401, ptr %rgep2404, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain547
bb_rcgspecial547:
  %v2405 = load i64, ptr %slot433, align 8
  %op2406 = and i64 %v2405, 4611686018427387904
  store i64 %op2406, ptr %slot441, align 8
  %v2407 = load i64, ptr %slot441, align 8
  %cmp2408 = icmp ne i64 %v2407, 0
  %cv2409 = zext i1 %cmp2408 to i32
  store i32 %cv2409, ptr %slot442, align 8
  %v2410 = load i32, ptr %slot442, align 8
  %cv2411 = zext i32 %v2410 to i64
  %cond2412 = icmp ne i64 %cv2411, 0
  br i1 %cond2412, label %bb_rcgslow547, label %bb_rcgplain547
bb_rcgslow547:
  %v2413 = load i64, ptr %slot47, align 8
  %v2414 = load i64, ptr %slot428, align 8
  %v2415 = load i64, ptr %slot406, align 8
  %v2416 = load i64, ptr %slot429, align 8
  %cv2417 = trunc i64 %v2416 to i32
  %call2418 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v2413, i64 %v2414, i64 %v2415, i32 %cv2417) nomerge, !dbg !132
  store i32 %call2418, ptr %slot443, align 8
  %v2419 = load i32, ptr %slot443, align 8
  %cv2420 = zext i32 %v2419 to i64
  %cond2421 = icmp ne i64 %cv2420, 0
  br i1 %cond2421, label %bb_rcsuccess561, label %bb_rcfailure561
bb_rcfailure561:
  %v2422 = load i64, ptr %slot47, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  %call2424 = call i32 @myl_rc_take_failure(ptr %p2423) nomerge, !dbg !132
  store i32 %call2424, ptr %slot444, align 8
  %v2425 = load i64, ptr %slot1, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %v2427 = load i32, ptr %slot444, align 8
  %call2428 = call i32 @myl_qbe_rc_status(ptr %p2426, i32 %v2427) nomerge, !dbg !132
  store i32 %call2428, ptr %slot445, align 8
  br label %bb_failure
bb_rcsuccess561:
  br label %bb_rcgdone547
bb_rcgplain547:
  %v2429 = load i64, ptr %slot430, align 8
  %v2430 = load i64, ptr %slot428, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  store i64 %v2429, ptr %p2431, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone547
bb_rcgdone547:
  %v2432 = load i64, ptr %slot20, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  store i32 2, ptr %p2433, align 4, !alias.scope !3, !noalias !4
  %v2434 = load i64, ptr %slot19, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  store i32 1, ptr %p2435, align 4, !alias.scope !3, !noalias !4
  %v2436 = load i64, ptr %slot17, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  %ld2438 = load i32, ptr %p2437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2438, ptr %slot446, align 8
  %v2439 = load i32, ptr %slot446, align 8
  %cv2440 = zext i32 %v2439 to i64
  %cond2441 = icmp ne i64 %cv2440, 0
  br i1 %cond2441, label %bb_rcslotdrop568, label %bb_rcslotdone568
bb_rcslotdrop568:
  %v2442 = load i64, ptr %slot17, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  store i32 0, ptr %p2443, align 4, !alias.scope !3, !noalias !4
  %v2444 = load i64, ptr %slot24, align 8
  store i64 %v2444, ptr %slot447, align 8
  %v2445 = load i64, ptr %slot18, align 8
  %p2446 = inttoptr i64 %v2445 to ptr
  %ld2447 = load i32, ptr %p2446, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2447, ptr %slot448, align 8
  %v2448 = load i32, ptr %slot448, align 8
  %op2449 = and i32 %v2448, 28
  store i32 %op2449, ptr %slot449, align 8
  %v2450 = load i32, ptr %slot449, align 8
  %cv2451 = zext i32 %v2450 to i64
  %cond2452 = icmp ne i64 %cv2451, 0
  br i1 %cond2452, label %bb_rcslotrole568, label %bb_rcslotowner568
bb_rcslotrole568:
  %v2453 = load i64, ptr %slot47, align 8
  store i64 %v2453, ptr %slot450, align 8
  %v2454 = load i64, ptr %slot447, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %ld2456 = load i64, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2456, ptr %slot451, align 8
  %v2457 = load i64, ptr %slot451, align 8
  %cmp2458 = icmp ne i64 %v2457, 0
  %cv2459 = zext i1 %cmp2458 to i32
  store i32 %cv2459, ptr %slot452, align 8
  %v2460 = load i32, ptr %slot452, align 8
  %cv2461 = zext i32 %v2460 to i64
  %cond2462 = icmp ne i64 %cv2461, 0
  br i1 %cond2462, label %bb_rcgnn584, label %bb_rcgdone584
bb_rcgnn584:
  %v2463 = load i64, ptr %slot451, align 8
  %op2464 = sub i64 %v2463, 16
  store i64 %op2464, ptr %slot453, align 8
  %v2465 = load i64, ptr %slot451, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  %rgep2467 = getelementptr i8, ptr %p2466, i64 -16
  %ld2468 = load i64, ptr %rgep2467, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2468, ptr %slot454, align 8
  %v2469 = load i64, ptr %slot454, align 8
  %op2470 = and i64 %v2469, 4611686018427387906
  store i64 %op2470, ptr %slot455, align 8
  %v2471 = load i64, ptr %slot455, align 8
  %cmp2472 = icmp ne i64 %v2471, 0
  %cv2473 = zext i1 %cmp2472 to i32
  store i32 %cv2473, ptr %slot456, align 8
  %v2474 = load i32, ptr %slot456, align 8
  %cv2475 = zext i32 %v2474 to i64
  %cond2476 = icmp ne i64 %cv2475, 0
  br i1 %cond2476, label %bb_rcgclear584, label %bb_rcgcounted584
bb_rcgcounted584:
  %v2477 = load i64, ptr %slot451, align 8
  %op2478 = sub i64 %v2477, 24
  store i64 %op2478, ptr %slot457, align 8
  %v2479 = load i64, ptr %slot451, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  %rgep2481 = getelementptr i8, ptr %p2480, i64 -24
  %ld2482 = load i64, ptr %rgep2481, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2482, ptr %slot458, align 8
  %v2483 = load i64, ptr %slot458, align 8
  %op2484 = sub i64 %v2483, 1
  store i64 %op2484, ptr %slot459, align 8
  %v2485 = load i64, ptr %slot459, align 8
  %cmp2486 = icmp eq i64 %v2485, 0
  %cv2487 = zext i1 %cmp2486 to i32
  store i32 %cv2487, ptr %slot460, align 8
  %v2488 = load i32, ptr %slot460, align 8
  %cv2489 = zext i32 %v2488 to i64
  %cond2490 = icmp ne i64 %cv2489, 0
  br i1 %cond2490, label %bb_rcglast584, label %bb_rcgdec584
bb_rcglast584:
  %v2491 = load i64, ptr %slot451, align 8
  %op2492 = sub i64 %v2491, 32
  store i64 %op2492, ptr %slot461, align 8
  %v2493 = load i64, ptr %slot451, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  %rgep2495 = getelementptr i8, ptr %p2494, i64 -32
  %ld2496 = load i64, ptr %rgep2495, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2496, ptr %slot462, align 8
  %v2497 = load i64, ptr %slot462, align 8
  %cmp2498 = icmp ne i64 %v2497, 0
  %cv2499 = zext i1 %cmp2498 to i32
  store i32 %cv2499, ptr %slot463, align 8
  %v2500 = load i32, ptr %slot463, align 8
  %cv2501 = zext i32 %v2500 to i64
  %cond2502 = icmp ne i64 %cv2501, 0
  br i1 %cond2502, label %bb_rcgdec584, label %bb_rcgslow584
bb_rcgslow584:
  %v2503 = load i64, ptr %slot450, align 8
  %v2504 = load i64, ptr %slot447, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2503, i64 %v2504) nomerge, !dbg !132
  br label %bb_rcgdone584
bb_rcgdec584:
  %v2505 = load i64, ptr %slot459, align 8
  %v2506 = load i64, ptr %slot451, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  %rgep2508 = getelementptr i8, ptr %p2507, i64 -24
  store i64 %v2505, ptr %rgep2508, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear584
bb_rcgclear584:
  %v2509 = load i64, ptr %slot447, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  store i64 0, ptr %p2510, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone584
bb_rcgdone584:
  br label %bb_rcslotdone568
bb_rcslotowner568:
  %v2511 = load i64, ptr %slot47, align 8
  store i64 %v2511, ptr %slot464, align 8
  %v2512 = load i64, ptr %slot447, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  %ld2514 = load i64, ptr %p2513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2514, ptr %slot465, align 8
  %v2515 = load i64, ptr %slot465, align 8
  %cmp2516 = icmp ne i64 %v2515, 0
  %cv2517 = zext i1 %cmp2516 to i32
  store i32 %cv2517, ptr %slot466, align 8
  %v2518 = load i32, ptr %slot466, align 8
  %cv2519 = zext i32 %v2518 to i64
  %cond2520 = icmp ne i64 %cv2519, 0
  br i1 %cond2520, label %bb_rcgnn599, label %bb_rcgdone599
bb_rcgnn599:
  %v2521 = load i64, ptr %slot465, align 8
  %op2522 = sub i64 %v2521, 16
  store i64 %op2522, ptr %slot467, align 8
  %v2523 = load i64, ptr %slot465, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  %rgep2525 = getelementptr i8, ptr %p2524, i64 -16
  %ld2526 = load i64, ptr %rgep2525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2526, ptr %slot468, align 8
  %v2527 = load i64, ptr %slot468, align 8
  %op2528 = and i64 %v2527, 4611686018427387906
  store i64 %op2528, ptr %slot469, align 8
  %v2529 = load i64, ptr %slot469, align 8
  %cmp2530 = icmp ne i64 %v2529, 0
  %cv2531 = zext i1 %cmp2530 to i32
  store i32 %cv2531, ptr %slot470, align 8
  %v2532 = load i32, ptr %slot470, align 8
  %cv2533 = zext i32 %v2532 to i64
  %cond2534 = icmp ne i64 %cv2533, 0
  br i1 %cond2534, label %bb_rcgclear599, label %bb_rcgcounted599
bb_rcgcounted599:
  %v2535 = load i64, ptr %slot465, align 8
  %op2536 = sub i64 %v2535, 32
  store i64 %op2536, ptr %slot471, align 8
  %v2537 = load i64, ptr %slot465, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  %rgep2539 = getelementptr i8, ptr %p2538, i64 -32
  %ld2540 = load i64, ptr %rgep2539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2540, ptr %slot472, align 8
  %v2541 = load i64, ptr %slot472, align 8
  %op2542 = sub i64 %v2541, 1
  store i64 %op2542, ptr %slot473, align 8
  %v2543 = load i64, ptr %slot473, align 8
  %cmp2544 = icmp eq i64 %v2543, 0
  %cv2545 = zext i1 %cmp2544 to i32
  store i32 %cv2545, ptr %slot474, align 8
  %v2546 = load i32, ptr %slot474, align 8
  %cv2547 = zext i32 %v2546 to i64
  %cond2548 = icmp ne i64 %cv2547, 0
  br i1 %cond2548, label %bb_rcglast599, label %bb_rcgdec599
bb_rcglast599:
  %v2549 = load i64, ptr %slot465, align 8
  %op2550 = sub i64 %v2549, 24
  store i64 %op2550, ptr %slot475, align 8
  %v2551 = load i64, ptr %slot465, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %rgep2553 = getelementptr i8, ptr %p2552, i64 -24
  %ld2554 = load i64, ptr %rgep2553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2554, ptr %slot476, align 8
  %v2555 = load i64, ptr %slot476, align 8
  %cmp2556 = icmp ne i64 %v2555, 0
  %cv2557 = zext i1 %cmp2556 to i32
  store i32 %cv2557, ptr %slot477, align 8
  %v2558 = load i32, ptr %slot477, align 8
  %cv2559 = zext i32 %v2558 to i64
  %cond2560 = icmp ne i64 %cv2559, 0
  br i1 %cond2560, label %bb_rcgdec599, label %bb_rcgslow599
bb_rcgslow599:
  %v2561 = load i64, ptr %slot464, align 8
  %v2562 = load i64, ptr %slot447, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2561, i64 %v2562) nomerge, !dbg !132
  br label %bb_rcgdone599
bb_rcgdec599:
  %v2563 = load i64, ptr %slot473, align 8
  %v2564 = load i64, ptr %slot465, align 8
  %p2565 = inttoptr i64 %v2564 to ptr
  %rgep2566 = getelementptr i8, ptr %p2565, i64 -32
  store i64 %v2563, ptr %rgep2566, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear599
bb_rcgclear599:
  %v2567 = load i64, ptr %slot447, align 8
  %p2568 = inttoptr i64 %v2567 to ptr
  store i64 0, ptr %p2568, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone599
bb_rcgdone599:
  br label %bb_rcslotdone568
bb_rcslotdone568:
  br label %bb_rcprepared514
bb_rcprepared514:
  %v2569 = load i64, ptr %slot27, align 8
  store i64 %v2569, ptr %slot478, align 8
  %v2570 = load i64, ptr %slot478, align 8
  %v2571 = load i64, ptr %slot404, align 8
  %p2572 = inttoptr i64 %v2570 to ptr
  %p2573 = inttoptr i64 %v2571 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2573, ptr %p2572, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2574 = load i64, ptr %slot19, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  store i32 0, ptr %p2575, align 4, !alias.scope !3, !noalias !4
  %v2576 = load i64, ptr %slot39, align 8
  store i64 %v2576, ptr %slot479, align 8
  %v2577 = load i64, ptr %slot315, align 8
  %p2579 = inttoptr i64 %v2577 to ptr
  %gep2580 = getelementptr i8, ptr %p2579, i64 24
  %op2578 = ptrtoint ptr %gep2580 to i64
  store i64 %op2578, ptr %slot480, align 8
  %v2581 = load i64, ptr %slot479, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  %ld2583 = load i64, ptr %p2582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2583, ptr %slot481, align 8
  %v2584 = load i64, ptr %slot481, align 8
  %v2585 = load i64, ptr %slot480, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  store i64 %v2584, ptr %p2586, align 8, !alias.scope !3, !noalias !4
  %v2587 = load i64, ptr %slot40, align 8
  store i64 %v2587, ptr %slot482, align 8
  %v2588 = load i64, ptr %slot315, align 8
  %p2590 = inttoptr i64 %v2588 to ptr
  %gep2591 = getelementptr i8, ptr %p2590, i64 32
  %op2589 = ptrtoint ptr %gep2591 to i64
  store i64 %op2589, ptr %slot483, align 8
  %v2592 = load i64, ptr %slot482, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  %ld2594 = load i64, ptr %p2593, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2594, ptr %slot484, align 8
  %v2595 = load i64, ptr %slot484, align 8
  %v2596 = load i64, ptr %slot483, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  store i64 %v2595, ptr %p2597, align 8, !alias.scope !3, !noalias !4
  %v2598 = load i64, ptr %slot41, align 8
  store i64 %v2598, ptr %slot485, align 8
  %v2599 = load i64, ptr %slot315, align 8
  %p2601 = inttoptr i64 %v2599 to ptr
  %gep2602 = getelementptr i8, ptr %p2601, i64 40
  %op2600 = ptrtoint ptr %gep2602 to i64
  store i64 %op2600, ptr %slot486, align 8
  %v2603 = load i64, ptr %slot485, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  %ld2605 = load i64, ptr %p2604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2605, ptr %slot487, align 8
  %v2606 = load i64, ptr %slot487, align 8
  %v2607 = load i64, ptr %slot486, align 8
  %p2608 = inttoptr i64 %v2607 to ptr
  store i64 %v2606, ptr %p2608, align 8, !alias.scope !3, !noalias !4
  %v2609 = load i64, ptr %slot315, align 8
  %v2610 = load i64, ptr %slot36, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i64 %v2609, ptr %p2611, align 8, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot36, align 8
  %p2613 = inttoptr i64 %v2612 to ptr
  %ld2614 = load i64, ptr %p2613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2614, ptr %slot488, align 8
  %v2615 = load i64, ptr %slot22, align 8
  store i64 %v2615, ptr %slot489, align 8
  %v2616 = load i64, ptr %slot488, align 8
  %v2617 = load i64, ptr %slot489, align 8
  %p2618 = inttoptr i64 %v2616 to ptr
  %p2619 = inttoptr i64 %v2617 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2619, ptr %p2618, i64 48, i1 false)
  %v2620 = load i64, ptr %slot14, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  store i32 2, ptr %p2621, align 4, !alias.scope !3, !noalias !4
  %v2622 = load i64, ptr %slot13, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  store i32 1, ptr %p2623, align 4, !alias.scope !3, !noalias !4
  %v2624 = load i64, ptr %slot489, align 8
  %v2625 = load i64, ptr %slot36, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  store i64 %v2624, ptr %p2626, align 8, !alias.scope !3, !noalias !4
  %v2627 = load i64, ptr %slot36, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  %ld2629 = load i64, ptr %p2628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2629, ptr %slot490, align 8
  %v2630 = load i64, ptr %slot36, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  %ld2632 = load i64, ptr %p2631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2632, ptr %slot491, align 8
  %v2633 = load i64, ptr %slot27, align 8
  store i64 %v2633, ptr %slot492, align 8
  %v2634 = load i64, ptr %slot48, align 8
  store i64 %v2634, ptr %slot493, align 8
  %v2635 = load i64, ptr %slot491, align 8
  %op2636 = add i64 %v2635, 8
  store i64 %op2636, ptr %slot494, align 8
  %v2637 = load i64, ptr %slot494, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %ld2639 = load i64, ptr %p2638, align 8
  store i64 %ld2639, ptr %slot495, align 8
  %v2640 = load i64, ptr %slot495, align 8
  %cmp2641 = icmp ne i64 %v2640, 0
  %cv2642 = zext i1 %cmp2641 to i32
  store i32 %cv2642, ptr %slot496, align 8
  %v2643 = load i32, ptr %slot496, align 8
  %cv2644 = zext i32 %v2643 to i64
  %cond2645 = icmp ne i64 %cv2644, 0
  br i1 %cond2645, label %bb_rcmoveheader625, label %bb_rcmovenext625
bb_rcmoveheader625:
  %v2646 = load i64, ptr %slot495, align 8
  %op2647 = sub i64 %v2646, 16
  store i64 %op2647, ptr %slot497, align 8
  %v2648 = load i64, ptr %slot495, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %rgep2650 = getelementptr i8, ptr %p2649, i64 -16
  %ld2651 = load i64, ptr %rgep2650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2651, ptr %slot498, align 8
  %v2652 = load i64, ptr %slot498, align 8
  %op2653 = and i64 %v2652, 5764607523034234881
  store i64 %op2653, ptr %slot499, align 8
  %v2654 = load i64, ptr %slot499, align 8
  %cmp2655 = icmp ne i64 %v2654, 0
  %cv2656 = zext i1 %cmp2655 to i32
  store i32 %cv2656, ptr %slot500, align 8
  %v2657 = load i32, ptr %slot500, align 8
  %cv2658 = zext i32 %v2657 to i64
  %cond2659 = icmp ne i64 %cv2658, 0
  br i1 %cond2659, label %bb_rcmoveslow622, label %bb_rcmovenext625
bb_rcmovenext625:
  %v2660 = load i64, ptr %slot491, align 8
  %op2661 = add i64 %v2660, 16
  store i64 %op2661, ptr %slot501, align 8
  %v2662 = load i64, ptr %slot501, align 8
  %p2663 = inttoptr i64 %v2662 to ptr
  %ld2664 = load i64, ptr %p2663, align 8
  store i64 %ld2664, ptr %slot502, align 8
  %v2665 = load i64, ptr %slot502, align 8
  %cmp2666 = icmp ne i64 %v2665, 0
  %cv2667 = zext i1 %cmp2666 to i32
  store i32 %cv2667, ptr %slot503, align 8
  %v2668 = load i32, ptr %slot503, align 8
  %cv2669 = zext i32 %v2668 to i64
  %cond2670 = icmp ne i64 %cv2669, 0
  br i1 %cond2670, label %bb_rcmoveheader633, label %bb_rcmovenext633
bb_rcmoveheader633:
  %v2671 = load i64, ptr %slot502, align 8
  %op2672 = sub i64 %v2671, 16
  store i64 %op2672, ptr %slot504, align 8
  %v2673 = load i64, ptr %slot502, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  %rgep2675 = getelementptr i8, ptr %p2674, i64 -16
  %ld2676 = load i64, ptr %rgep2675, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2676, ptr %slot505, align 8
  %v2677 = load i64, ptr %slot505, align 8
  %op2678 = and i64 %v2677, 5764607523034234881
  store i64 %op2678, ptr %slot506, align 8
  %v2679 = load i64, ptr %slot506, align 8
  %cmp2680 = icmp ne i64 %v2679, 0
  %cv2681 = zext i1 %cmp2680 to i32
  store i32 %cv2681, ptr %slot507, align 8
  %v2682 = load i32, ptr %slot507, align 8
  %cv2683 = zext i32 %v2682 to i64
  %cond2684 = icmp ne i64 %cv2683, 0
  br i1 %cond2684, label %bb_rcmoveslow622, label %bb_rcmovenext633
bb_rcmovenext633:
  %v2685 = load i64, ptr %slot491, align 8
  %v2686 = load i64, ptr %slot492, align 8
  %p2687 = inttoptr i64 %v2685 to ptr
  %p2688 = inttoptr i64 %v2686 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2688, ptr %p2687, i64 48, i1 false)
  %v2689 = load i64, ptr %slot491, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  store i64 0, ptr %p2690, align 8
  %v2691 = load i64, ptr %slot491, align 8
  %op2692 = add i64 %v2691, 8
  store i64 %op2692, ptr %slot508, align 8
  %v2693 = load i64, ptr %slot508, align 8
  %p2694 = inttoptr i64 %v2693 to ptr
  store i64 0, ptr %p2694, align 8
  %v2695 = load i64, ptr %slot491, align 8
  %op2696 = add i64 %v2695, 16
  store i64 %op2696, ptr %slot509, align 8
  %v2697 = load i64, ptr %slot509, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  store i64 0, ptr %p2698, align 8
  %v2699 = load i64, ptr %slot491, align 8
  %op2700 = add i64 %v2699, 24
  store i64 %op2700, ptr %slot510, align 8
  %v2701 = load i64, ptr %slot510, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  store i64 0, ptr %p2702, align 8
  %v2703 = load i64, ptr %slot491, align 8
  %op2704 = add i64 %v2703, 32
  store i64 %op2704, ptr %slot511, align 8
  %v2705 = load i64, ptr %slot511, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  store i64 0, ptr %p2706, align 8
  %v2707 = load i64, ptr %slot491, align 8
  %op2708 = add i64 %v2707, 40
  store i64 %op2708, ptr %slot512, align 8
  %v2709 = load i64, ptr %slot512, align 8
  %p2710 = inttoptr i64 %v2709 to ptr
  store i64 0, ptr %p2710, align 8
  br label %bb_rcmoved622
bb_rcmoveslow622:
  %v2711 = load i64, ptr %slot47, align 8
  %v2712 = load i64, ptr %slot492, align 8
  %v2713 = load i64, ptr %slot491, align 8
  %v2714 = load i64, ptr %slot493, align 8
  %cv2715 = trunc i64 %v2714 to i32
  %call2716 = call i32 @myl_t_395a5135976932e25085bfb4bdf1f47faaa75c053388f38fd2216bdd623ca5ba_rcg_take(i64 %v2711, i64 %v2712, i64 %v2713, i32 %cv2715) nomerge, !dbg !134
  store i32 %call2716, ptr %slot513, align 8
  %v2717 = load i32, ptr %slot513, align 8
  %cv2718 = zext i32 %v2717 to i64
  %cond2719 = icmp ne i64 %cv2718, 0
  br i1 %cond2719, label %bb_rcsuccess645, label %bb_rcfailure645
bb_rcfailure645:
  %v2720 = load i64, ptr %slot47, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  %call2722 = call i32 @myl_rc_take_failure(ptr %p2721) nomerge, !dbg !134
  store i32 %call2722, ptr %slot514, align 8
  %v2723 = load i64, ptr %slot1, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  %v2725 = load i32, ptr %slot514, align 8
  %call2726 = call i32 @myl_qbe_rc_status(ptr %p2724, i32 %v2725) nomerge, !dbg !134
  store i32 %call2726, ptr %slot515, align 8
  br label %bb_failure
bb_rcsuccess645:
  br label %bb_rcmoved622
bb_rcmoved622:
  %v2727 = load i64, ptr %slot13, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  store i32 0, ptr %p2728, align 4, !alias.scope !3, !noalias !4
  %v2729 = load i64, ptr %slot20, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  store i32 2, ptr %p2730, align 4, !alias.scope !3, !noalias !4
  %v2731 = load i64, ptr %slot19, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  store i32 1, ptr %p2732, align 4, !alias.scope !3, !noalias !4
  %v2733 = load i64, ptr %slot27, align 8
  store i64 %v2733, ptr %slot516, align 8
  %v2734 = load i64, ptr %slot19, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  store i32 0, ptr %p2735, align 4, !alias.scope !3, !noalias !4
  %v2736 = load i64, ptr %slot13, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  %ld2738 = load i32, ptr %p2737, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2738, ptr %slot517, align 8
  %v2739 = load i32, ptr %slot517, align 8
  %cv2740 = zext i32 %v2739 to i64
  %cond2741 = icmp ne i64 %cv2740, 0
  br i1 %cond2741, label %bb_rcslotdrop655, label %bb_rcslotdone655
bb_rcslotdrop655:
  %v2742 = load i64, ptr %slot13, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  store i32 0, ptr %p2743, align 4, !alias.scope !3, !noalias !4
  %v2744 = load i64, ptr %slot22, align 8
  store i64 %v2744, ptr %slot518, align 8
  %v2745 = load i64, ptr %slot14, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  %ld2747 = load i32, ptr %p2746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2747, ptr %slot519, align 8
  %v2748 = load i32, ptr %slot519, align 8
  %op2749 = and i32 %v2748, 28
  store i32 %op2749, ptr %slot520, align 8
  %v2750 = load i32, ptr %slot520, align 8
  %cv2751 = zext i32 %v2750 to i64
  %cond2752 = icmp ne i64 %cv2751, 0
  br i1 %cond2752, label %bb_rcslotrole655, label %bb_rcslotowner655
bb_rcslotrole655:
  %v2753 = load i64, ptr %slot47, align 8
  store i64 %v2753, ptr %slot521, align 8
  %v2754 = load i64, ptr %slot521, align 8
  %v2755 = load i64, ptr %slot518, align 8
  call void @myl_t_395a5135976932e25085bfb4bdf1f47faaa75c053388f38fd2216bdd623ca5ba_rcg_unloan(i64 %v2754, i64 %v2755) nomerge, !dbg !134
  br label %bb_rcslotdone655
bb_rcslotowner655:
  %v2756 = load i64, ptr %slot47, align 8
  store i64 %v2756, ptr %slot522, align 8
  %v2757 = load i64, ptr %slot522, align 8
  %v2758 = load i64, ptr %slot518, align 8
  call void @myl_t_395a5135976932e25085bfb4bdf1f47faaa75c053388f38fd2216bdd623ca5ba_rcg_drop(i64 %v2757, i64 %v2758) nomerge, !dbg !134
  br label %bb_rcslotdone655
bb_rcslotdone655:
  %v2759 = load i64, ptr %slot11, align 8
  %p2760 = inttoptr i64 %v2759 to ptr
  %ld2761 = load i32, ptr %p2760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2761, ptr %slot523, align 8
  %v2762 = load i32, ptr %slot523, align 8
  %cv2763 = zext i32 %v2762 to i64
  %cond2764 = icmp ne i64 %cv2763, 0
  br i1 %cond2764, label %bb_rcslotdrop664, label %bb_rcslotdone664
bb_rcslotdrop664:
  %v2765 = load i64, ptr %slot11, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  store i32 0, ptr %p2766, align 4, !alias.scope !3, !noalias !4
  %v2767 = load i64, ptr %slot34, align 8
  store i64 %v2767, ptr %slot524, align 8
  %v2768 = load i64, ptr %slot12, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  %ld2770 = load i32, ptr %p2769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2770, ptr %slot525, align 8
  %v2771 = load i32, ptr %slot525, align 8
  %op2772 = and i32 %v2771, 28
  store i32 %op2772, ptr %slot526, align 8
  %v2773 = load i32, ptr %slot526, align 8
  %cv2774 = zext i32 %v2773 to i64
  %cond2775 = icmp ne i64 %cv2774, 0
  br i1 %cond2775, label %bb_rcslotrole664, label %bb_rcslotowner664
bb_rcslotrole664:
  %v2776 = load i64, ptr %slot47, align 8
  store i64 %v2776, ptr %slot527, align 8
  %v2777 = load i64, ptr %slot527, align 8
  %v2778 = load i64, ptr %slot524, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v2777, i64 %v2778) nomerge, !dbg !134
  br label %bb_rcslotdone664
bb_rcslotowner664:
  %v2779 = load i64, ptr %slot47, align 8
  store i64 %v2779, ptr %slot528, align 8
  %v2780 = load i64, ptr %slot528, align 8
  %v2781 = load i64, ptr %slot524, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2780, i64 %v2781) nomerge, !dbg !134
  br label %bb_rcslotdone664
bb_rcslotdone664:
  %v2782 = load i64, ptr %slot9, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  %ld2784 = load i32, ptr %p2783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2784, ptr %slot529, align 8
  %v2785 = load i32, ptr %slot529, align 8
  %cv2786 = zext i32 %v2785 to i64
  %cond2787 = icmp ne i64 %cv2786, 0
  br i1 %cond2787, label %bb_rcslotdrop673, label %bb_rcslotdone673
bb_rcslotdrop673:
  %v2788 = load i64, ptr %slot9, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  store i32 0, ptr %p2789, align 4, !alias.scope !3, !noalias !4
  %v2790 = load i64, ptr %slot33, align 8
  store i64 %v2790, ptr %slot530, align 8
  %v2791 = load i64, ptr %slot10, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %ld2793 = load i32, ptr %p2792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2793, ptr %slot531, align 8
  %v2794 = load i32, ptr %slot531, align 8
  %op2795 = and i32 %v2794, 28
  store i32 %op2795, ptr %slot532, align 8
  %v2796 = load i32, ptr %slot532, align 8
  %cv2797 = zext i32 %v2796 to i64
  %cond2798 = icmp ne i64 %cv2797, 0
  br i1 %cond2798, label %bb_rcslotrole673, label %bb_rcslotowner673
bb_rcslotrole673:
  %v2799 = load i64, ptr %slot47, align 8
  store i64 %v2799, ptr %slot533, align 8
  %v2800 = load i64, ptr %slot533, align 8
  %v2801 = load i64, ptr %slot530, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2800, i64 %v2801) nomerge, !dbg !134
  br label %bb_rcslotdone673
bb_rcslotowner673:
  %v2802 = load i64, ptr %slot47, align 8
  store i64 %v2802, ptr %slot534, align 8
  %v2803 = load i64, ptr %slot534, align 8
  %v2804 = load i64, ptr %slot530, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2803, i64 %v2804) nomerge, !dbg !134
  br label %bb_rcslotdone673
bb_rcslotdone673:
  %v2805 = load i64, ptr %slot516, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2806, i64 48, i1 false)
  ret void
bb_failure:
  %v2807 = load i64, ptr %slot8, align 8
  %p2808 = inttoptr i64 %v2807 to ptr
  call void @llvm.memset.p0.i64(ptr %p2808, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v2809 = load i64, ptr %slot8, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2810, i64 48, i1 false)
  ret void
bb_entry_failure:
  %v2811 = load i64, ptr %slot8, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  call void @llvm.memset.p0.i64(ptr %p2812, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v2813 = load i64, ptr %slot8, align 8
  %p2814 = inttoptr i64 %v2813 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2814, i64 48, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_3fa1fce991adab79730ee8c7bc958ee62467f0563d7015944308565f4efbc770(ptr sret([40 x i8]) align 8, i64, i64)
declare i64 @myl_f_6750db8c8d1c4cf1c4854bf3a36c914802b0c65c931aa2f1c3cbbb68270b2fbe(i64, i64, i64, i64, i64)
declare void @myl_f_6ebf82ddbc9178c16b7df30bf24fbe017e8b8f1c3e98435ddaa9d24a62c703dc(ptr sret([208 x i8]) align 8, i64, i64, i64)
declare ptr @myl_qbe_bytes_snapshot(ptr, ptr)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64, i64)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_395a5135976932e25085bfb4bdf1f47faaa75c053388f38fd2216bdd623ca5ba_rcg_drop(i64, i64)
declare i32 @myl_t_395a5135976932e25085bfb4bdf1f47faaa75c053388f38fd2216bdd623ca5ba_rcg_take(i64, i64, i64, i32)
declare void @myl_t_395a5135976932e25085bfb4bdf1f47faaa75c053388f38fd2216bdd623ca5ba_rcg_unloan(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64, i64, i64, i32)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_7ed5e5db1a870833aaf6cf104d303f9f9c5cad2c1ab868ef69a232d64277da59", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_7ed5e5db1a870833aaf6cf104d303f9f9c5cad2c1ab868ef69a232d64277da59", linkageName: "myl_f_7ed5e5db1a870833aaf6cf104d303f9f9c5cad2c1ab868ef69a232d64277da59", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 18349771128897731055, i64 0, !"myl_f_7ed5e5db1a870833aaf6cf104d303f9f9c5cad2c1ab868ef69a232d64277da59"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!120 = !DILocation(line: 7, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!122 = !DILocation(line: 12, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!126 = !DILocation(line: 17, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!130 = !DILocation(line: 20, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!132 = !DILocation(line: 27, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!134 = !DILocation(line: 28, column: 0, scope: !135)
