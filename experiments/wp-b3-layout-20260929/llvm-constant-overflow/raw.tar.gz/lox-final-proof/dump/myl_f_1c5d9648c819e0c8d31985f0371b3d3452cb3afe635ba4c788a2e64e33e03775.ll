target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775(i64 %p_ctx) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i32, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  %v70 = load i64, ptr %slot1, align 8
  %op71 = add i64 %v70, 32
  store i64 %op71, ptr %slot2, align 8
  %mem72 = alloca i8, i64 8, align 8
  %ptr73 = ptrtoint ptr %mem72 to i64
  store i64 %ptr73, ptr %slot3, align 8
  %mem74 = alloca i8, i64 8, align 8
  %ptr75 = ptrtoint ptr %mem74 to i64
  store i64 %ptr75, ptr %slot4, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot5, align 8
  %mem78 = alloca i8, i64 8, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot6, align 8
  %mem80 = alloca i8, i64 8, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot7, align 8
  %mem82 = alloca i8, i64 8, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot8, align 8
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot9, align 8
  %mem86 = alloca i8, i64 8, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot10, align 8
  %v88 = load i64, ptr %slot1, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %call90 = call ptr @myl_qbe_heap(ptr %p89) nomerge, !dbg !110
  %calladdr91 = ptrtoint ptr %call90 to i64
  store i64 %calladdr91, ptr %slot11, align 8
  %v92 = load i64, ptr %slot1, align 8
  %p93 = inttoptr i64 %v92 to ptr
  %call94 = call i64 @myl_qbe_region_mark(ptr %p93) nomerge, !dbg !110
  store i64 %call94, ptr %slot12, align 8
  %v95 = load i64, ptr %slot3, align 8
  %p96 = inttoptr i64 %v95 to ptr
  store i32 0, ptr %p96, align 4, !alias.scope !3, !noalias !4
  %v97 = load i64, ptr %slot4, align 8
  %p98 = inttoptr i64 %v97 to ptr
  store i32 0, ptr %p98, align 4, !alias.scope !3, !noalias !4
  %v99 = load i64, ptr %slot5, align 8
  %p100 = inttoptr i64 %v99 to ptr
  store i32 0, ptr %p100, align 4, !alias.scope !3, !noalias !4
  %v101 = load i64, ptr %slot6, align 8
  %p102 = inttoptr i64 %v101 to ptr
  store i32 0, ptr %p102, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %p103 = inttoptr i64 ptrtoint (ptr @myl_lit_53beca18892d5027da95cf5218f2ce6ed55f2f49a89a46fc2c0da5220764cdfc to i64) to ptr
  %ld104 = load i64, ptr %p103, align 8, !alias.scope !4, !noalias !3
  store i64 %ld104, ptr %slot13, align 8
  %v105 = load i64, ptr %slot13, align 8
  %v106 = load i64, ptr %slot10, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i64 %v105, ptr %p107, align 8, !alias.scope !3, !noalias !4
  %v108 = load i64, ptr %slot10, align 8
  %p109 = inttoptr i64 %v108 to ptr
  %ld110 = load i64, ptr %p109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld110, ptr %slot14, align 8
  %v111 = load i64, ptr %slot14, align 8
  %v112 = load i64, ptr %slot8, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 %v111, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot8, align 8
  store i64 %v114, ptr %slot15, align 8
  %v115 = load i64, ptr %slot9, align 8
  store i64 %v115, ptr %slot16, align 8
  %v116 = load i64, ptr %slot15, align 8
  %v117 = load i64, ptr %slot16, align 8
  %p118 = inttoptr i64 %v116 to ptr
  %p119 = inttoptr i64 %v117 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p119, ptr %p118, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot6, align 8
  %p121 = inttoptr i64 %v120 to ptr
  store i32 2, ptr %p121, align 4, !alias.scope !3, !noalias !4
  %v122 = load i64, ptr %slot5, align 8
  %p123 = inttoptr i64 %v122 to ptr
  store i32 1, ptr %p123, align 4, !alias.scope !3, !noalias !4
  %v124 = load i64, ptr %slot7, align 8
  store i64 %v124, ptr %slot17, align 8
  %v125 = load i64, ptr %slot9, align 8
  store i64 %v125, ptr %slot18, align 8
  %v126 = load i64, ptr %slot18, align 8
  %v127 = load i64, ptr %slot17, align 8
  %p128 = inttoptr i64 %v126 to ptr
  %p129 = inttoptr i64 %v127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p129, ptr %p128, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot4, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i32 2, ptr %p131, align 4, !alias.scope !3, !noalias !4
  %v132 = load i64, ptr %slot6, align 8
  %p133 = inttoptr i64 %v132 to ptr
  %ld134 = load i32, ptr %p133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld134, ptr %slot19, align 8
  %v135 = load i32, ptr %slot19, align 8
  %v136 = load i64, ptr %slot4, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i32 %v135, ptr %p137, align 4, !alias.scope !3, !noalias !4
  %v138 = load i64, ptr %slot5, align 8
  %p139 = inttoptr i64 %v138 to ptr
  store i32 0, ptr %p139, align 4, !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot3, align 8
  %p141 = inttoptr i64 %v140 to ptr
  store i32 1, ptr %p141, align 4, !alias.scope !3, !noalias !4
  %v142 = load i64, ptr %slot17, align 8
  %p143 = inttoptr i64 %v142 to ptr
  %ld144 = load i64, ptr %p143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld144, ptr %slot20, align 8
  %v145 = load i64, ptr %slot20, align 8
  %v146 = load i64, ptr %slot10, align 8
  %p147 = inttoptr i64 %v146 to ptr
  store i64 %v145, ptr %p147, align 8, !alias.scope !3, !noalias !4
  %v148 = load i64, ptr %slot10, align 8
  %p149 = inttoptr i64 %v148 to ptr
  %ld150 = load i64, ptr %p149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld150, ptr %slot21, align 8
  %v151 = load i64, ptr %slot10, align 8
  %p152 = inttoptr i64 %v151 to ptr
  %ld153 = load i64, ptr %p152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld153, ptr %slot22, align 8
  %v154 = load i64, ptr %slot22, align 8
  %v155 = load i64, ptr %slot8, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 %v154, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot8, align 8
  store i64 %v157, ptr %slot23, align 8
  %v158 = load i64, ptr %slot9, align 8
  store i64 %v158, ptr %slot24, align 8
  %v159 = load i64, ptr %slot12, align 8
  store i64 %v159, ptr %slot25, align 8
  %v160 = load i64, ptr %slot23, align 8
  %p162 = inttoptr i64 %v160 to ptr
  %gep163 = getelementptr i8, ptr %p162, i64 0
  %op161 = ptrtoint ptr %gep163 to i64
  store i64 %op161, ptr %slot26, align 8
  %v164 = load i64, ptr %slot26, align 8
  %p165 = inttoptr i64 %v164 to ptr
  %ld166 = load i64, ptr %p165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld166, ptr %slot27, align 8
  %v167 = load i64, ptr %slot27, align 8
  %cmp168 = icmp ne i64 %v167, 0
  %cv169 = zext i1 %cmp168 to i32
  store i32 %cv169, ptr %slot28, align 8
  %v170 = load i32, ptr %slot28, align 8
  %cv171 = zext i32 %v170 to i64
  %cond172 = icmp ne i64 %cv171, 0
  br i1 %cond172, label %bb_rcmoveheader24, label %bb_rcmovenext24
bb_rcmoveheader24:
  %v173 = load i64, ptr %slot27, align 8
  %op174 = sub i64 %v173, 16
  store i64 %op174, ptr %slot29, align 8
  %v175 = load i64, ptr %slot27, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %rgep177 = getelementptr i8, ptr %p176, i64 -16
  %ld178 = load i64, ptr %rgep177, align 8, !alias.scope !9, !noalias !10
  store i64 %ld178, ptr %slot30, align 8
  %v179 = load i64, ptr %slot30, align 8
  %op180 = and i64 %v179, 5764607523034234881
  store i64 %op180, ptr %slot31, align 8
  %v181 = load i64, ptr %slot31, align 8
  %cmp182 = icmp ne i64 %v181, 0
  %cv183 = zext i1 %cmp182 to i32
  store i32 %cv183, ptr %slot32, align 8
  %v184 = load i32, ptr %slot32, align 8
  %cv185 = zext i32 %v184 to i64
  %cond186 = icmp ne i64 %cv185, 0
  br i1 %cond186, label %bb_rcmoveslow21, label %bb_rcmovenext24
bb_rcmovenext24:
  %v187 = load i64, ptr %slot23, align 8
  %v188 = load i64, ptr %slot24, align 8
  %p189 = inttoptr i64 %v187 to ptr
  %p190 = inttoptr i64 %v188 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p190, ptr %p189, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot23, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 0, ptr %p192, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved21
bb_rcmoveslow21:
  %v193 = load i64, ptr %slot11, align 8
  %v194 = load i64, ptr %slot24, align 8
  %v195 = load i64, ptr %slot23, align 8
  %v196 = load i64, ptr %slot25, align 8
  %cv197 = trunc i64 %v196 to i32
  %call198 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v193, i64 %v194, i64 %v195, i32 %cv197) nomerge, !dbg !112
  store i32 %call198, ptr %slot33, align 8
  %v199 = load i32, ptr %slot33, align 8
  %cv200 = zext i32 %v199 to i64
  %cond201 = icmp ne i64 %cv200, 0
  br i1 %cond201, label %bb_rcsuccess31, label %bb_rcfailure31
bb_rcfailure31:
  %v202 = load i64, ptr %slot11, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %call204 = call i32 @myl_rc_take_failure(ptr %p203) nomerge, !dbg !112
  store i32 %call204, ptr %slot34, align 8
  %v205 = load i64, ptr %slot1, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %v207 = load i32, ptr %slot34, align 8
  %call208 = call i32 @myl_qbe_rc_status(ptr %p206, i32 %v207) nomerge, !dbg !112
  store i32 %call208, ptr %slot35, align 8
  br label %bb_failure
bb_rcsuccess31:
  br label %bb_rcmoved21
bb_rcmoved21:
  %v209 = load i64, ptr %slot3, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i32 0, ptr %p210, align 4, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot6, align 8
  %p212 = inttoptr i64 %v211 to ptr
  store i32 2, ptr %p212, align 4, !alias.scope !3, !noalias !4
  %v213 = load i64, ptr %slot5, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i32 1, ptr %p214, align 4, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot9, align 8
  store i64 %v215, ptr %slot36, align 8
  %v216 = load i64, ptr %slot36, align 8
  %p217 = inttoptr i64 %v216 to ptr
  %ld218 = load i64, ptr %p217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld218, ptr %slot37, align 8
  %v219 = load i64, ptr %slot5, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i32 0, ptr %p220, align 4, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot3, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i32, ptr %p222, align 4, !alias.scope !3, !noalias !4
  store i32 %ld223, ptr %slot38, align 8
  %v224 = load i32, ptr %slot38, align 8
  %cv225 = zext i32 %v224 to i64
  %cond226 = icmp ne i64 %cv225, 0
  br i1 %cond226, label %bb_rcslotdrop42, label %bb_rcslotdone42
bb_rcslotdrop42:
  %v227 = load i64, ptr %slot3, align 8
  %p228 = inttoptr i64 %v227 to ptr
  store i32 0, ptr %p228, align 4, !alias.scope !3, !noalias !4
  %v229 = load i64, ptr %slot7, align 8
  store i64 %v229, ptr %slot39, align 8
  %v230 = load i64, ptr %slot4, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i32, ptr %p231, align 4, !alias.scope !3, !noalias !4
  store i32 %ld232, ptr %slot40, align 8
  %v233 = load i32, ptr %slot40, align 8
  %op234 = and i32 %v233, 28
  store i32 %op234, ptr %slot41, align 8
  %v235 = load i32, ptr %slot41, align 8
  %cv236 = zext i32 %v235 to i64
  %cond237 = icmp ne i64 %cv236, 0
  br i1 %cond237, label %bb_rcslotrole42, label %bb_rcslotowner42
bb_rcslotrole42:
  %v238 = load i64, ptr %slot11, align 8
  store i64 %v238, ptr %slot42, align 8
  %v239 = load i64, ptr %slot39, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %ld241 = load i64, ptr %p240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld241, ptr %slot43, align 8
  %v242 = load i64, ptr %slot43, align 8
  %cmp243 = icmp ne i64 %v242, 0
  %cv244 = zext i1 %cmp243 to i32
  store i32 %cv244, ptr %slot44, align 8
  %v245 = load i32, ptr %slot44, align 8
  %cv246 = zext i32 %v245 to i64
  %cond247 = icmp ne i64 %cv246, 0
  br i1 %cond247, label %bb_rcgnn58, label %bb_rcgdone58
bb_rcgnn58:
  %v248 = load i64, ptr %slot43, align 8
  %op249 = sub i64 %v248, 16
  store i64 %op249, ptr %slot45, align 8
  %v250 = load i64, ptr %slot43, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %rgep252 = getelementptr i8, ptr %p251, i64 -16
  %ld253 = load i64, ptr %rgep252, align 8, !alias.scope !9, !noalias !10
  store i64 %ld253, ptr %slot46, align 8
  %v254 = load i64, ptr %slot46, align 8
  %op255 = and i64 %v254, 4611686018427387906
  store i64 %op255, ptr %slot47, align 8
  %v256 = load i64, ptr %slot47, align 8
  %cmp257 = icmp ne i64 %v256, 0
  %cv258 = zext i1 %cmp257 to i32
  store i32 %cv258, ptr %slot48, align 8
  %v259 = load i32, ptr %slot48, align 8
  %cv260 = zext i32 %v259 to i64
  %cond261 = icmp ne i64 %cv260, 0
  br i1 %cond261, label %bb_rcgclear58, label %bb_rcgcounted58
bb_rcgcounted58:
  %v262 = load i64, ptr %slot43, align 8
  %op263 = sub i64 %v262, 24
  store i64 %op263, ptr %slot49, align 8
  %v264 = load i64, ptr %slot43, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %rgep266 = getelementptr i8, ptr %p265, i64 -24
  %ld267 = load i64, ptr %rgep266, align 8, !alias.scope !9, !noalias !10
  store i64 %ld267, ptr %slot50, align 8
  %v268 = load i64, ptr %slot50, align 8
  %op269 = sub i64 %v268, 1
  store i64 %op269, ptr %slot51, align 8
  %v270 = load i64, ptr %slot51, align 8
  %cmp271 = icmp eq i64 %v270, 0
  %cv272 = zext i1 %cmp271 to i32
  store i32 %cv272, ptr %slot52, align 8
  %v273 = load i32, ptr %slot52, align 8
  %cv274 = zext i32 %v273 to i64
  %cond275 = icmp ne i64 %cv274, 0
  br i1 %cond275, label %bb_rcglast58, label %bb_rcgdec58
bb_rcglast58:
  %v276 = load i64, ptr %slot43, align 8
  %op277 = sub i64 %v276, 32
  store i64 %op277, ptr %slot53, align 8
  %v278 = load i64, ptr %slot43, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %rgep280 = getelementptr i8, ptr %p279, i64 -32
  %ld281 = load i64, ptr %rgep280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld281, ptr %slot54, align 8
  %v282 = load i64, ptr %slot54, align 8
  %cmp283 = icmp ne i64 %v282, 0
  %cv284 = zext i1 %cmp283 to i32
  store i32 %cv284, ptr %slot55, align 8
  %v285 = load i32, ptr %slot55, align 8
  %cv286 = zext i32 %v285 to i64
  %cond287 = icmp ne i64 %cv286, 0
  br i1 %cond287, label %bb_rcgdec58, label %bb_rcgslow58
bb_rcgslow58:
  %v288 = load i64, ptr %slot42, align 8
  %v289 = load i64, ptr %slot39, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v288, i64 %v289) nomerge, !dbg !112
  br label %bb_rcgdone58
bb_rcgdec58:
  %v290 = load i64, ptr %slot51, align 8
  %v291 = load i64, ptr %slot43, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %rgep293 = getelementptr i8, ptr %p292, i64 -24
  store i64 %v290, ptr %rgep293, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear58
bb_rcgclear58:
  %v294 = load i64, ptr %slot39, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 0, ptr %p295, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone58
bb_rcgdone58:
  br label %bb_rcslotdone42
bb_rcslotowner42:
  %v296 = load i64, ptr %slot11, align 8
  store i64 %v296, ptr %slot56, align 8
  %v297 = load i64, ptr %slot39, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot57, align 8
  %v300 = load i64, ptr %slot57, align 8
  %cmp301 = icmp ne i64 %v300, 0
  %cv302 = zext i1 %cmp301 to i32
  store i32 %cv302, ptr %slot58, align 8
  %v303 = load i32, ptr %slot58, align 8
  %cv304 = zext i32 %v303 to i64
  %cond305 = icmp ne i64 %cv304, 0
  br i1 %cond305, label %bb_rcgnn73, label %bb_rcgdone73
bb_rcgnn73:
  %v306 = load i64, ptr %slot57, align 8
  %op307 = sub i64 %v306, 16
  store i64 %op307, ptr %slot59, align 8
  %v308 = load i64, ptr %slot57, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %rgep310 = getelementptr i8, ptr %p309, i64 -16
  %ld311 = load i64, ptr %rgep310, align 8, !alias.scope !9, !noalias !10
  store i64 %ld311, ptr %slot60, align 8
  %v312 = load i64, ptr %slot60, align 8
  %op313 = and i64 %v312, 4611686018427387906
  store i64 %op313, ptr %slot61, align 8
  %v314 = load i64, ptr %slot61, align 8
  %cmp315 = icmp ne i64 %v314, 0
  %cv316 = zext i1 %cmp315 to i32
  store i32 %cv316, ptr %slot62, align 8
  %v317 = load i32, ptr %slot62, align 8
  %cv318 = zext i32 %v317 to i64
  %cond319 = icmp ne i64 %cv318, 0
  br i1 %cond319, label %bb_rcgclear73, label %bb_rcgcounted73
bb_rcgcounted73:
  %v320 = load i64, ptr %slot57, align 8
  %op321 = sub i64 %v320, 32
  store i64 %op321, ptr %slot63, align 8
  %v322 = load i64, ptr %slot57, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %rgep324 = getelementptr i8, ptr %p323, i64 -32
  %ld325 = load i64, ptr %rgep324, align 8, !alias.scope !9, !noalias !10
  store i64 %ld325, ptr %slot64, align 8
  %v326 = load i64, ptr %slot64, align 8
  %op327 = sub i64 %v326, 1
  store i64 %op327, ptr %slot65, align 8
  %v328 = load i64, ptr %slot65, align 8
  %cmp329 = icmp eq i64 %v328, 0
  %cv330 = zext i1 %cmp329 to i32
  store i32 %cv330, ptr %slot66, align 8
  %v331 = load i32, ptr %slot66, align 8
  %cv332 = zext i32 %v331 to i64
  %cond333 = icmp ne i64 %cv332, 0
  br i1 %cond333, label %bb_rcglast73, label %bb_rcgdec73
bb_rcglast73:
  %v334 = load i64, ptr %slot57, align 8
  %op335 = sub i64 %v334, 24
  store i64 %op335, ptr %slot67, align 8
  %v336 = load i64, ptr %slot57, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %rgep338 = getelementptr i8, ptr %p337, i64 -24
  %ld339 = load i64, ptr %rgep338, align 8, !alias.scope !9, !noalias !10
  store i64 %ld339, ptr %slot68, align 8
  %v340 = load i64, ptr %slot68, align 8
  %cmp341 = icmp ne i64 %v340, 0
  %cv342 = zext i1 %cmp341 to i32
  store i32 %cv342, ptr %slot69, align 8
  %v343 = load i32, ptr %slot69, align 8
  %cv344 = zext i32 %v343 to i64
  %cond345 = icmp ne i64 %cv344, 0
  br i1 %cond345, label %bb_rcgdec73, label %bb_rcgslow73
bb_rcgslow73:
  %v346 = load i64, ptr %slot56, align 8
  %v347 = load i64, ptr %slot39, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v346, i64 %v347) nomerge, !dbg !112
  br label %bb_rcgdone73
bb_rcgdec73:
  %v348 = load i64, ptr %slot65, align 8
  %v349 = load i64, ptr %slot57, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %rgep351 = getelementptr i8, ptr %p350, i64 -32
  store i64 %v348, ptr %rgep351, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear73
bb_rcgclear73:
  %v352 = load i64, ptr %slot39, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i64 0, ptr %p353, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone73
bb_rcgdone73:
  br label %bb_rcslotdone42
bb_rcslotdone42:
  %v354 = load i64, ptr %slot37, align 8
  ret i64 %v354
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_53beca18892d5027da95cf5218f2ce6ed55f2f49a89a46fc2c0da5220764cdfc = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775", linkageName: "myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 911446056458954329, i64 0, !"myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
