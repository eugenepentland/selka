target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v109 = load i64, ptr %slot1, align 8
  %op110 = add i64 %v109, 32
  store i64 %op110, ptr %slot4, align 8
  %mem111 = alloca i8, i64 40, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot5, align 8
  %mem113 = alloca i8, i64 8, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot6, align 8
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot7, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot8, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot9, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot10, align 8
  %mem123 = alloca i8, i64 8, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot11, align 8
  %mem125 = alloca i8, i64 40, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot12, align 8
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot13, align 8
  %mem129 = alloca i8, i64 8, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot14, align 8
  %mem131 = alloca i8, i64 40, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot15, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot16, align 8
  %mem135 = alloca i8, i64 8, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot17, align 8
  %mem137 = alloca i8, i64 8, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot18, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot19, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot20, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot21, align 8
  %mem145 = alloca i8, i64 8, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot22, align 8
  %mem147 = alloca i8, i64 40, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot23, align 8
  %v149 = load i64, ptr %slot2, align 8
  %v150 = load i64, ptr %slot16, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot3, align 8
  %v153 = load i64, ptr %slot17, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 %v152, ptr %p154, align 8, !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot1, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %call157 = call ptr @myl_qbe_heap(ptr %p156) nomerge, !dbg !110
  %calladdr158 = ptrtoint ptr %call157 to i64
  store i64 %calladdr158, ptr %slot24, align 8
  %v159 = load i64, ptr %slot1, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %call161 = call i64 @myl_qbe_region_mark(ptr %p160) nomerge, !dbg !110
  store i64 %call161, ptr %slot25, align 8
  %v162 = load i64, ptr %slot6, align 8
  %p163 = inttoptr i64 %v162 to ptr
  store i32 0, ptr %p163, align 4, !alias.scope !3, !noalias !4
  %v164 = load i64, ptr %slot7, align 8
  %p165 = inttoptr i64 %v164 to ptr
  store i32 0, ptr %p165, align 4, !alias.scope !3, !noalias !4
  %v166 = load i64, ptr %slot8, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i32 0, ptr %p167, align 4, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot9, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i32 0, ptr %p169, align 4, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot10, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i32 0, ptr %p171, align 4, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot11, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i32 0, ptr %p173, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v174 = load i64, ptr %slot17, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %ld176 = load i64, ptr %p175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld176, ptr %slot26, align 8
  %v177 = load i64, ptr %slot26, align 8
  %v178 = load i64, ptr %slot18, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i64 %v177, ptr %p179, align 8, !alias.scope !3, !noalias !4
  %v180 = load i64, ptr %slot16, align 8
  %p181 = inttoptr i64 %v180 to ptr
  %ld182 = load i64, ptr %p181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld182, ptr %slot27, align 8
  %v183 = load i64, ptr %slot27, align 8
  %v184 = load i64, ptr %slot19, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i64 %v183, ptr %p185, align 8, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot19, align 8
  %p187 = inttoptr i64 %v186 to ptr
  %ld188 = load i64, ptr %p187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld188, ptr %slot28, align 8
  %v189 = load i64, ptr %slot28, align 8
  %op190 = add i64 %v189, 8
  store i64 %op190, ptr %slot29, align 8
  %v191 = load i64, ptr %slot29, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8
  store i64 %ld193, ptr %slot30, align 8
  %v194 = load i64, ptr %slot30, align 8
  %v195 = load i64, ptr %slot19, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i64 %v194, ptr %p196, align 8, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot16, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot31, align 8
  %v200 = load i64, ptr %slot31, align 8
  %v201 = load i64, ptr %slot20, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot20, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot32, align 8
  %v206 = load i64, ptr %slot32, align 8
  %op207 = add i64 %v206, 16
  store i64 %op207, ptr %slot33, align 8
  %v208 = load i64, ptr %slot33, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8
  store i64 %ld210, ptr %slot34, align 8
  %v211 = load i64, ptr %slot34, align 8
  %v212 = load i64, ptr %slot20, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot16, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot35, align 8
  %v217 = load i64, ptr %slot35, align 8
  %v218 = load i64, ptr %slot21, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot21, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot36, align 8
  %v223 = load i64, ptr %slot36, align 8
  %op224 = add i64 %v223, 8
  store i64 %op224, ptr %slot37, align 8
  %v225 = load i64, ptr %slot37, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8
  store i64 %ld227, ptr %slot38, align 8
  %v228 = load i64, ptr %slot38, align 8
  %v229 = load i64, ptr %slot21, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 %v228, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot21, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld233, ptr %slot39, align 8
  %v234 = load i64, ptr %slot20, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %ld236 = load i64, ptr %p235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld236, ptr %slot40, align 8
  %v237 = load i64, ptr %slot40, align 8
  %v238 = load i64, ptr %slot39, align 8
  %ovpair240 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v237, i64 %v238)
  %op239 = extractvalue { i64, i1 } %ovpair240, 0
  %ov241 = extractvalue { i64, i1 } %ovpair240, 1
  store i64 %op239, ptr %slot41, align 8
  %v242 = load i64, ptr %slot40, align 8
  %v243 = load i64, ptr %slot39, align 8
  %op244 = xor i64 %v242, %v243
  store i64 %op244, ptr %slot42, align 8
  %v245 = load i64, ptr %slot40, align 8
  %v246 = load i64, ptr %slot41, align 8
  %op247 = xor i64 %v245, %v246
  store i64 %op247, ptr %slot43, align 8
  %v248 = load i64, ptr %slot42, align 8
  %v249 = load i64, ptr %slot43, align 8
  %op250 = and i64 %v248, %v249
  store i64 %op250, ptr %slot44, align 8
  %cv251 = zext i1 %ov241 to i64
  store i64 %cv251, ptr %slot45, align 8
  %v252 = load i64, ptr %slot45, align 8
  %cond253 = icmp ne i64 %v252, 0
  br i1 %cond253, label %bb_overflow43, label %bb_checked43
bb_overflow43:
  %v254 = load i64, ptr %slot1, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %v256 = load i64, ptr %slot40, align 8
  %v257 = load i64, ptr %slot39, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p255, i64 1, i64 %v256, i64 %v257, i64 64) nomerge, !dbg !112
  unreachable
bb_checked43:
  %v258 = load i64, ptr %slot41, align 8
  %v259 = load i64, ptr %slot20, align 8
  %p260 = inttoptr i64 %v259 to ptr
  store i64 %v258, ptr %p260, align 8, !alias.scope !3, !noalias !4
  %v261 = load i64, ptr %slot16, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i64, ptr %p262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld263, ptr %slot46, align 8
  %v264 = load i64, ptr %slot46, align 8
  %v265 = load i64, ptr %slot21, align 8
  %p266 = inttoptr i64 %v265 to ptr
  store i64 %v264, ptr %p266, align 8, !alias.scope !3, !noalias !4
  %v267 = load i64, ptr %slot21, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %ld269 = load i64, ptr %p268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld269, ptr %slot47, align 8
  %v270 = load i64, ptr %slot47, align 8
  %op271 = add i64 %v270, 24
  store i64 %op271, ptr %slot48, align 8
  %v272 = load i64, ptr %slot48, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %ld274 = load i64, ptr %p273, align 8
  store i64 %ld274, ptr %slot49, align 8
  %v275 = load i64, ptr %slot49, align 8
  %v276 = load i64, ptr %slot21, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i64 %v275, ptr %p277, align 8, !alias.scope !3, !noalias !4
  %p278 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld279 = load i64, ptr %p278, align 8, !alias.scope !4, !noalias !3
  store i64 %ld279, ptr %slot50, align 8
  %v280 = load i64, ptr %slot50, align 8
  %v281 = load i64, ptr %slot22, align 8
  %p282 = inttoptr i64 %v281 to ptr
  store i64 %v280, ptr %p282, align 8, !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot22, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld285, ptr %slot51, align 8
  %v286 = load i64, ptr %slot51, align 8
  %v287 = load i64, ptr %slot14, align 8
  %p288 = inttoptr i64 %v287 to ptr
  store i64 %v286, ptr %p288, align 8, !alias.scope !3, !noalias !4
  %v289 = load i64, ptr %slot14, align 8
  store i64 %v289, ptr %slot52, align 8
  %v290 = load i64, ptr %slot15, align 8
  store i64 %v290, ptr %slot53, align 8
  %v291 = load i64, ptr %slot52, align 8
  %v292 = load i64, ptr %slot53, align 8
  %p293 = inttoptr i64 %v291 to ptr
  %p294 = inttoptr i64 %v292 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p294, ptr %p293, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot10, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i32 2, ptr %p296, align 4, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot9, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i32 1, ptr %p298, align 4, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot13, align 8
  store i64 %v299, ptr %slot54, align 8
  %v300 = load i64, ptr %slot15, align 8
  store i64 %v300, ptr %slot55, align 8
  %v301 = load i64, ptr %slot55, align 8
  %v302 = load i64, ptr %slot54, align 8
  %p303 = inttoptr i64 %v301 to ptr
  %p304 = inttoptr i64 %v302 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p304, ptr %p303, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot10, align 8
  %p306 = inttoptr i64 %v305 to ptr
  %ld307 = load i32, ptr %p306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld307, ptr %slot56, align 8
  %v308 = load i64, ptr %slot9, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i32 0, ptr %p309, align 4, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot8, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i32 1, ptr %p311, align 4, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot54, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %ld314 = load i64, ptr %p313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld314, ptr %slot57, align 8
  %v315 = load i64, ptr %slot57, align 8
  %v316 = load i64, ptr %slot22, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i64 %v315, ptr %p317, align 8, !alias.scope !3, !noalias !4
  %v318 = load i64, ptr %slot23, align 8
  store i64 %v318, ptr %slot58, align 8
  %v319 = load i64, ptr %slot58, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i64 0, ptr %p320, align 8, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot58, align 8
  %p323 = inttoptr i64 %v321 to ptr
  %gep324 = getelementptr i8, ptr %p323, i64 8
  %op322 = ptrtoint ptr %gep324 to i64
  store i64 %op322, ptr %slot59, align 8
  %v325 = load i64, ptr %slot59, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i64 0, ptr %p326, align 8, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot58, align 8
  %p329 = inttoptr i64 %v327 to ptr
  %gep330 = getelementptr i8, ptr %p329, i64 16
  %op328 = ptrtoint ptr %gep330 to i64
  store i64 %op328, ptr %slot60, align 8
  %v331 = load i64, ptr %slot60, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i64 0, ptr %p332, align 8, !alias.scope !3, !noalias !4
  %v333 = load i64, ptr %slot58, align 8
  %p335 = inttoptr i64 %v333 to ptr
  %gep336 = getelementptr i8, ptr %p335, i64 24
  %op334 = ptrtoint ptr %gep336 to i64
  store i64 %op334, ptr %slot61, align 8
  %v337 = load i64, ptr %slot61, align 8
  %p338 = inttoptr i64 %v337 to ptr
  store i64 0, ptr %p338, align 8, !alias.scope !3, !noalias !4
  %v339 = load i64, ptr %slot58, align 8
  %p341 = inttoptr i64 %v339 to ptr
  %gep342 = getelementptr i8, ptr %p341, i64 32
  %op340 = ptrtoint ptr %gep342 to i64
  store i64 %op340, ptr %slot62, align 8
  %v343 = load i64, ptr %slot62, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i64 0, ptr %p344, align 8, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot11, align 8
  %p346 = inttoptr i64 %v345 to ptr
  store i32 1, ptr %p346, align 4, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot25, align 8
  store i64 %v347, ptr %slot63, align 8
  %v348 = load i64, ptr %slot18, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i64, ptr %p349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld350, ptr %slot64, align 8
  %v351 = load i64, ptr %slot58, align 8
  %p353 = inttoptr i64 %v351 to ptr
  %gep354 = getelementptr i8, ptr %p353, i64 0
  %op352 = ptrtoint ptr %gep354 to i64
  store i64 %op352, ptr %slot65, align 8
  %v355 = load i64, ptr %slot64, align 8
  %v356 = load i64, ptr %slot65, align 8
  %p357 = inttoptr i64 %v355 to ptr
  %p358 = inttoptr i64 %v356 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p358, ptr %p357, i64 4, i1 false), !alias.scope !10000000
  %v359 = load i64, ptr %slot19, align 8
  store i64 %v359, ptr %slot66, align 8
  %v360 = load i64, ptr %slot58, align 8
  %p362 = inttoptr i64 %v360 to ptr
  %gep363 = getelementptr i8, ptr %p362, i64 8
  %op361 = ptrtoint ptr %gep363 to i64
  store i64 %op361, ptr %slot67, align 8
  %v364 = load i64, ptr %slot66, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot68, align 8
  %v367 = load i64, ptr %slot68, align 8
  %v368 = load i64, ptr %slot67, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i64 %v367, ptr %p369, align 8, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot20, align 8
  store i64 %v370, ptr %slot69, align 8
  %v371 = load i64, ptr %slot58, align 8
  %p373 = inttoptr i64 %v371 to ptr
  %gep374 = getelementptr i8, ptr %p373, i64 16
  %op372 = ptrtoint ptr %gep374 to i64
  store i64 %op372, ptr %slot70, align 8
  %v375 = load i64, ptr %slot69, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %ld377 = load i64, ptr %p376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld377, ptr %slot71, align 8
  %v378 = load i64, ptr %slot71, align 8
  %v379 = load i64, ptr %slot70, align 8
  %p380 = inttoptr i64 %v379 to ptr
  store i64 %v378, ptr %p380, align 8, !alias.scope !3, !noalias !4
  %v381 = load i64, ptr %slot21, align 8
  store i64 %v381, ptr %slot72, align 8
  %v382 = load i64, ptr %slot58, align 8
  %p384 = inttoptr i64 %v382 to ptr
  %gep385 = getelementptr i8, ptr %p384, i64 24
  %op383 = ptrtoint ptr %gep385 to i64
  store i64 %op383, ptr %slot73, align 8
  %v386 = load i64, ptr %slot72, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot74, align 8
  %v389 = load i64, ptr %slot74, align 8
  %v390 = load i64, ptr %slot73, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i64 %v389, ptr %p391, align 8, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot22, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i64, ptr %p393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot75, align 8
  %v395 = load i64, ptr %slot75, align 8
  %v396 = load i64, ptr %slot14, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 %v395, ptr %p397, align 8, !alias.scope !3, !noalias !4
  %v398 = load i64, ptr %slot14, align 8
  store i64 %v398, ptr %slot76, align 8
  %v399 = load i64, ptr %slot58, align 8
  %p401 = inttoptr i64 %v399 to ptr
  %gep402 = getelementptr i8, ptr %p401, i64 32
  %op400 = ptrtoint ptr %gep402 to i64
  store i64 %op400, ptr %slot77, align 8
  %v403 = load i64, ptr %slot22, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ld405 = load i64, ptr %p404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld405, ptr %slot78, align 8
  %v406 = load i64, ptr %slot78, align 8
  %v407 = load i64, ptr %slot14, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i64 %v406, ptr %p408, align 8, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot14, align 8
  store i64 %v409, ptr %slot79, align 8
  %v410 = load i64, ptr %slot15, align 8
  store i64 %v410, ptr %slot80, align 8
  %v411 = load i64, ptr %slot25, align 8
  store i64 %v411, ptr %slot81, align 8
  %v412 = load i64, ptr %slot79, align 8
  %p414 = inttoptr i64 %v412 to ptr
  %gep415 = getelementptr i8, ptr %p414, i64 0
  %op413 = ptrtoint ptr %gep415 to i64
  store i64 %op413, ptr %slot82, align 8
  %v416 = load i64, ptr %slot82, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %ld418 = load i64, ptr %p417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld418, ptr %slot83, align 8
  %v419 = load i64, ptr %slot83, align 8
  %cmp420 = icmp ne i64 %v419, 0
  %cv421 = zext i1 %cmp420 to i32
  store i32 %cv421, ptr %slot84, align 8
  %v422 = load i32, ptr %slot84, align 8
  %cv423 = zext i32 %v422 to i64
  %cond424 = icmp ne i64 %cv423, 0
  br i1 %cond424, label %bb_rcmoveheader106, label %bb_rcmovenext106
bb_rcmoveheader106:
  %v425 = load i64, ptr %slot83, align 8
  %op426 = sub i64 %v425, 16
  store i64 %op426, ptr %slot85, align 8
  %v427 = load i64, ptr %slot83, align 8
  %p428 = inttoptr i64 %v427 to ptr
  %rgep429 = getelementptr i8, ptr %p428, i64 -16
  %ld430 = load i64, ptr %rgep429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld430, ptr %slot86, align 8
  %v431 = load i64, ptr %slot86, align 8
  %op432 = and i64 %v431, 5764607523034234881
  store i64 %op432, ptr %slot87, align 8
  %v433 = load i64, ptr %slot87, align 8
  %cmp434 = icmp ne i64 %v433, 0
  %cv435 = zext i1 %cmp434 to i32
  store i32 %cv435, ptr %slot88, align 8
  %v436 = load i32, ptr %slot88, align 8
  %cv437 = zext i32 %v436 to i64
  %cond438 = icmp ne i64 %cv437, 0
  br i1 %cond438, label %bb_rcmoveslow103, label %bb_rcmovenext106
bb_rcmovenext106:
  %v439 = load i64, ptr %slot79, align 8
  %v440 = load i64, ptr %slot80, align 8
  %p441 = inttoptr i64 %v439 to ptr
  %p442 = inttoptr i64 %v440 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p442, ptr %p441, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot79, align 8
  %p444 = inttoptr i64 %v443 to ptr
  store i64 0, ptr %p444, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved103
bb_rcmoveslow103:
  %v445 = load i64, ptr %slot24, align 8
  %v446 = load i64, ptr %slot80, align 8
  %v447 = load i64, ptr %slot79, align 8
  %v448 = load i64, ptr %slot81, align 8
  %cv449 = trunc i64 %v448 to i32
  %call450 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v445, i64 %v446, i64 %v447, i32 %cv449) nomerge, !dbg !114
  store i32 %call450, ptr %slot89, align 8
  %v451 = load i32, ptr %slot89, align 8
  %cv452 = zext i32 %v451 to i64
  %cond453 = icmp ne i64 %cv452, 0
  br i1 %cond453, label %bb_rcsuccess113, label %bb_rcfailure113
bb_rcfailure113:
  %v454 = load i64, ptr %slot24, align 8
  %p455 = inttoptr i64 %v454 to ptr
  %call456 = call i32 @myl_rc_take_failure(ptr %p455) nomerge, !dbg !114
  store i32 %call456, ptr %slot90, align 8
  %v457 = load i64, ptr %slot1, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %v459 = load i32, ptr %slot90, align 8
  %call460 = call i32 @myl_qbe_rc_status(ptr %p458, i32 %v459) nomerge, !dbg !114
  store i32 %call460, ptr %slot91, align 8
  br label %bb_failure
bb_rcsuccess113:
  br label %bb_rcmoved103
bb_rcmoved103:
  %v461 = load i64, ptr %slot8, align 8
  %p462 = inttoptr i64 %v461 to ptr
  store i32 0, ptr %p462, align 4, !alias.scope !3, !noalias !4
  %v463 = load i64, ptr %slot10, align 8
  %p464 = inttoptr i64 %v463 to ptr
  store i32 2, ptr %p464, align 4, !alias.scope !3, !noalias !4
  %v465 = load i64, ptr %slot9, align 8
  %p466 = inttoptr i64 %v465 to ptr
  store i32 1, ptr %p466, align 4, !alias.scope !3, !noalias !4
  %v467 = load i64, ptr %slot15, align 8
  store i64 %v467, ptr %slot92, align 8
  %v468 = load i64, ptr %slot92, align 8
  %v469 = load i64, ptr %slot77, align 8
  %p470 = inttoptr i64 %v468 to ptr
  %p471 = inttoptr i64 %v469 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p471, ptr %p470, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot9, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i32 0, ptr %p473, align 4, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot58, align 8
  %v475 = load i64, ptr %slot18, align 8
  %p476 = inttoptr i64 %v475 to ptr
  store i64 %v474, ptr %p476, align 8, !alias.scope !3, !noalias !4
  %v477 = load i64, ptr %slot18, align 8
  %p478 = inttoptr i64 %v477 to ptr
  %ld479 = load i64, ptr %p478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld479, ptr %slot93, align 8
  %v480 = load i64, ptr %slot12, align 8
  store i64 %v480, ptr %slot94, align 8
  %v481 = load i64, ptr %slot93, align 8
  %v482 = load i64, ptr %slot94, align 8
  %p483 = inttoptr i64 %v481 to ptr
  %p484 = inttoptr i64 %v482 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p484, ptr %p483, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v485 = load i64, ptr %slot7, align 8
  %p486 = inttoptr i64 %v485 to ptr
  store i32 2, ptr %p486, align 4, !alias.scope !3, !noalias !4
  %v487 = load i64, ptr %slot6, align 8
  %p488 = inttoptr i64 %v487 to ptr
  store i32 1, ptr %p488, align 4, !alias.scope !3, !noalias !4
  %v489 = load i64, ptr %slot94, align 8
  %v490 = load i64, ptr %slot18, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i64 %v489, ptr %p491, align 8, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot18, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i64, ptr %p493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld494, ptr %slot95, align 8
  %v495 = load i64, ptr %slot18, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %ld497 = load i64, ptr %p496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld497, ptr %slot96, align 8
  %v498 = load i64, ptr %slot15, align 8
  store i64 %v498, ptr %slot97, align 8
  %v499 = load i64, ptr %slot25, align 8
  store i64 %v499, ptr %slot98, align 8
  %v500 = load i64, ptr %slot24, align 8
  %v501 = load i64, ptr %slot97, align 8
  %v502 = load i64, ptr %slot96, align 8
  %v503 = load i64, ptr %slot98, align 8
  %cv504 = trunc i64 %v503 to i32
  %call505 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v500, i64 %v501, i64 %v502, i32 %cv504) nomerge, !dbg !116
  store i32 %call505, ptr %slot99, align 8
  %v506 = load i32, ptr %slot99, align 8
  %cv507 = zext i32 %v506 to i64
  %cond508 = icmp ne i64 %cv507, 0
  br i1 %cond508, label %bb_rcsuccess130, label %bb_rcfailure130
bb_rcfailure130:
  %v509 = load i64, ptr %slot24, align 8
  %p510 = inttoptr i64 %v509 to ptr
  %call511 = call i32 @myl_rc_take_failure(ptr %p510) nomerge, !dbg !116
  store i32 %call511, ptr %slot100, align 8
  %v512 = load i64, ptr %slot1, align 8
  %p513 = inttoptr i64 %v512 to ptr
  %v514 = load i32, ptr %slot100, align 8
  %call515 = call i32 @myl_qbe_rc_status(ptr %p513, i32 %v514) nomerge, !dbg !116
  store i32 %call515, ptr %slot101, align 8
  br label %bb_failure
bb_rcsuccess130:
  %v516 = load i64, ptr %slot6, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i32 0, ptr %p517, align 4, !alias.scope !3, !noalias !4
  %v518 = load i64, ptr %slot10, align 8
  %p519 = inttoptr i64 %v518 to ptr
  store i32 2, ptr %p519, align 4, !alias.scope !3, !noalias !4
  %v520 = load i64, ptr %slot9, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i32 1, ptr %p521, align 4, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot15, align 8
  store i64 %v522, ptr %slot102, align 8
  %v523 = load i64, ptr %slot9, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 0, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot6, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i32, ptr %p526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld527, ptr %slot103, align 8
  %v528 = load i32, ptr %slot103, align 8
  %cv529 = zext i32 %v528 to i64
  %cond530 = icmp ne i64 %cv529, 0
  br i1 %cond530, label %bb_rcslotdrop140, label %bb_rcslotdone140
bb_rcslotdrop140:
  %v531 = load i64, ptr %slot6, align 8
  %p532 = inttoptr i64 %v531 to ptr
  store i32 0, ptr %p532, align 4, !alias.scope !3, !noalias !4
  %v533 = load i64, ptr %slot12, align 8
  store i64 %v533, ptr %slot104, align 8
  %v534 = load i64, ptr %slot7, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i32, ptr %p535, align 4, !alias.scope !3, !noalias !4
  store i32 %ld536, ptr %slot105, align 8
  %v537 = load i32, ptr %slot105, align 8
  %op538 = and i32 %v537, 28
  store i32 %op538, ptr %slot106, align 8
  %v539 = load i32, ptr %slot106, align 8
  %cv540 = zext i32 %v539 to i64
  %cond541 = icmp ne i64 %cv540, 0
  br i1 %cond541, label %bb_rcslotrole140, label %bb_rcslotowner140
bb_rcslotrole140:
  %v542 = load i64, ptr %slot24, align 8
  store i64 %v542, ptr %slot107, align 8
  %v543 = load i64, ptr %slot107, align 8
  %v544 = load i64, ptr %slot104, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v543, i64 %v544) nomerge, !dbg !116
  br label %bb_rcslotdone140
bb_rcslotowner140:
  %v545 = load i64, ptr %slot24, align 8
  store i64 %v545, ptr %slot108, align 8
  %v546 = load i64, ptr %slot108, align 8
  %v547 = load i64, ptr %slot104, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v546, i64 %v547) nomerge, !dbg !116
  br label %bb_rcslotdone140
bb_rcslotdone140:
  %v548 = load i64, ptr %slot102, align 8
  %p549 = inttoptr i64 %v548 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p549, i64 40, i1 false)
  ret void
bb_failure:
  %v550 = load i64, ptr %slot5, align 8
  %p551 = inttoptr i64 %v550 to ptr
  call void @llvm.memset.p0.i64(ptr %p551, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v552 = load i64, ptr %slot5, align 8
  %p553 = inttoptr i64 %v552 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p553, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v554 = load i64, ptr %slot5, align 8
  %p555 = inttoptr i64 %v554 to ptr
  call void @llvm.memset.p0.i64(ptr %p555, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v556 = load i64, ptr %slot5, align 8
  %p557 = inttoptr i64 %v556 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p557, i64 40, i1 false)
  ret void
}

@myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d", linkageName: "myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2147175293578674613, i64 0, !"myl_f_8a73522daccb35975c1e54ce1f58822dc82d67687a5b15f69628f8bab957104d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!112 = !DILocation(line: 8, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!114 = !DILocation(line: 12, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
