target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_905c657b4f5ea0605cf216d63756b0789867b90e538230151e831f1d61dfbb70(i64 %p_ctx, i64 %p_a0) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v32 = load i64, ptr %slot1, align 8
  %op33 = add i64 %v32, 32
  store i64 %op33, ptr %slot3, align 8
  %mem34 = alloca i8, i64 8, align 8
  %ptr35 = ptrtoint ptr %mem34 to i64
  store i64 %ptr35, ptr %slot4, align 8
  %mem36 = alloca i8, i64 8, align 8
  %ptr37 = ptrtoint ptr %mem36 to i64
  store i64 %ptr37, ptr %slot5, align 8
  %mem38 = alloca i8, i64 8, align 8
  %ptr39 = ptrtoint ptr %mem38 to i64
  store i64 %ptr39, ptr %slot6, align 8
  %v40 = load i64, ptr %slot2, align 8
  %v41 = load i64, ptr %slot4, align 8
  %p42 = inttoptr i64 %v41 to ptr
  store i64 %v40, ptr %p42, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v43 = load i64, ptr %slot4, align 8
  %p44 = inttoptr i64 %v43 to ptr
  %ld45 = load i64, ptr %p44, align 8, !alias.scope !3, !noalias !4
  store i64 %ld45, ptr %slot7, align 8
  %v46 = load i64, ptr %slot7, align 8
  %v47 = load i64, ptr %slot5, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 %v46, ptr %p48, align 8, !alias.scope !3, !noalias !4
  %v49 = load i64, ptr %slot6, align 8
  %p50 = inttoptr i64 %v49 to ptr
  store i64 97, ptr %p50, align 8, !alias.scope !3, !noalias !4
  %v51 = load i64, ptr %slot6, align 8
  %p52 = inttoptr i64 %v51 to ptr
  %ld53 = load i64, ptr %p52, align 8, !alias.scope !3, !noalias !4
  store i64 %ld53, ptr %slot8, align 8
  %v54 = load i64, ptr %slot5, align 8
  %p55 = inttoptr i64 %v54 to ptr
  %ld56 = load i64, ptr %p55, align 8, !alias.scope !3, !noalias !4
  store i64 %ld56, ptr %slot9, align 8
  %v57 = load i64, ptr %slot9, align 8
  %v58 = load i64, ptr %slot8, align 8
  %cmp59 = icmp sge i64 %v57, %v58
  %cv60 = zext i1 %cmp59 to i64
  store i64 %cv60, ptr %slot10, align 8
  %v61 = load i64, ptr %slot10, align 8
  %v62 = load i64, ptr %slot5, align 8
  %p63 = inttoptr i64 %v62 to ptr
  store i64 %v61, ptr %p63, align 8, !alias.scope !3, !noalias !4
  %v64 = load i64, ptr %slot5, align 8
  %p65 = inttoptr i64 %v64 to ptr
  %ld66 = load i64, ptr %p65, align 8, !alias.scope !3, !noalias !4
  store i64 %ld66, ptr %slot11, align 8
  %v67 = load i64, ptr %slot11, align 8
  %cond68 = icmp ne i64 %v67, 0
  br i1 %cond68, label %bb_next5, label %bb_i8
bb_next5:
  %v69 = load i64, ptr %slot4, align 8
  %p70 = inttoptr i64 %v69 to ptr
  %ld71 = load i64, ptr %p70, align 8, !alias.scope !3, !noalias !4
  store i64 %ld71, ptr %slot12, align 8
  %v72 = load i64, ptr %slot12, align 8
  %v73 = load i64, ptr %slot5, align 8
  %p74 = inttoptr i64 %v73 to ptr
  store i64 %v72, ptr %p74, align 8, !alias.scope !3, !noalias !4
  %v75 = load i64, ptr %slot6, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 122, ptr %p76, align 8, !alias.scope !3, !noalias !4
  %v77 = load i64, ptr %slot6, align 8
  %p78 = inttoptr i64 %v77 to ptr
  %ld79 = load i64, ptr %p78, align 8, !alias.scope !3, !noalias !4
  store i64 %ld79, ptr %slot13, align 8
  %v80 = load i64, ptr %slot5, align 8
  %p81 = inttoptr i64 %v80 to ptr
  %ld82 = load i64, ptr %p81, align 8, !alias.scope !3, !noalias !4
  store i64 %ld82, ptr %slot14, align 8
  %v83 = load i64, ptr %slot14, align 8
  %v84 = load i64, ptr %slot13, align 8
  %cmp85 = icmp sle i64 %v83, %v84
  %cv86 = zext i1 %cmp85 to i64
  store i64 %cv86, ptr %slot15, align 8
  %v87 = load i64, ptr %slot15, align 8
  %v88 = load i64, ptr %slot5, align 8
  %p89 = inttoptr i64 %v88 to ptr
  store i64 %v87, ptr %p89, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i8:
  %v90 = load i64, ptr %slot5, align 8
  %p91 = inttoptr i64 %v90 to ptr
  store i64 0, ptr %p91, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i9:
  %v92 = load i64, ptr %slot5, align 8
  %p93 = inttoptr i64 %v92 to ptr
  %ld94 = load i64, ptr %p93, align 8, !alias.scope !3, !noalias !4
  store i64 %ld94, ptr %slot16, align 8
  %v95 = load i64, ptr %slot16, align 8
  %cond96 = icmp ne i64 %v95, 0
  br i1 %cond96, label %bb_next10, label %bb_i12
bb_next10:
  %v97 = load i64, ptr %slot5, align 8
  %p98 = inttoptr i64 %v97 to ptr
  store i64 1, ptr %p98, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i12:
  %v99 = load i64, ptr %slot4, align 8
  %p100 = inttoptr i64 %v99 to ptr
  %ld101 = load i64, ptr %p100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld101, ptr %slot17, align 8
  %v102 = load i64, ptr %slot17, align 8
  %v103 = load i64, ptr %slot5, align 8
  %p104 = inttoptr i64 %v103 to ptr
  store i64 %v102, ptr %p104, align 8, !alias.scope !3, !noalias !4
  %v105 = load i64, ptr %slot6, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i64 65, ptr %p106, align 8, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot6, align 8
  %p108 = inttoptr i64 %v107 to ptr
  %ld109 = load i64, ptr %p108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld109, ptr %slot18, align 8
  %v110 = load i64, ptr %slot5, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld112, ptr %slot19, align 8
  %v113 = load i64, ptr %slot19, align 8
  %v114 = load i64, ptr %slot18, align 8
  %cmp115 = icmp sge i64 %v113, %v114
  %cv116 = zext i1 %cmp115 to i64
  store i64 %cv116, ptr %slot20, align 8
  %v117 = load i64, ptr %slot20, align 8
  %v118 = load i64, ptr %slot5, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot5, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %ld122 = load i64, ptr %p121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot21, align 8
  %v123 = load i64, ptr %slot21, align 8
  %cond124 = icmp ne i64 %v123, 0
  br i1 %cond124, label %bb_next15, label %bb_i20
bb_next15:
  %v125 = load i64, ptr %slot4, align 8
  %p126 = inttoptr i64 %v125 to ptr
  %ld127 = load i64, ptr %p126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld127, ptr %slot22, align 8
  %v128 = load i64, ptr %slot22, align 8
  %v129 = load i64, ptr %slot5, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i64 %v128, ptr %p130, align 8, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot6, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i64 90, ptr %p132, align 8, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot6, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot23, align 8
  %v136 = load i64, ptr %slot5, align 8
  %p137 = inttoptr i64 %v136 to ptr
  %ld138 = load i64, ptr %p137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld138, ptr %slot24, align 8
  %v139 = load i64, ptr %slot24, align 8
  %v140 = load i64, ptr %slot23, align 8
  %cmp141 = icmp sle i64 %v139, %v140
  %cv142 = zext i1 %cmp141 to i64
  store i64 %cv142, ptr %slot25, align 8
  %v143 = load i64, ptr %slot25, align 8
  %v144 = load i64, ptr %slot5, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 %v143, ptr %p145, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i20:
  %v146 = load i64, ptr %slot5, align 8
  %p147 = inttoptr i64 %v146 to ptr
  store i64 0, ptr %p147, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v148 = load i64, ptr %slot5, align 8
  %p149 = inttoptr i64 %v148 to ptr
  %ld150 = load i64, ptr %p149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld150, ptr %slot26, align 8
  %v151 = load i64, ptr %slot26, align 8
  %cond152 = icmp ne i64 %v151, 0
  br i1 %cond152, label %bb_next20, label %bb_i24
bb_next20:
  %v153 = load i64, ptr %slot5, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 1, ptr %p154, align 8, !alias.scope !3, !noalias !4
  br label %bb_i27
bb_i24:
  %v155 = load i64, ptr %slot4, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld157, ptr %slot27, align 8
  %v158 = load i64, ptr %slot27, align 8
  %v159 = load i64, ptr %slot5, align 8
  %p160 = inttoptr i64 %v159 to ptr
  store i64 %v158, ptr %p160, align 8, !alias.scope !3, !noalias !4
  %v161 = load i64, ptr %slot6, align 8
  %p162 = inttoptr i64 %v161 to ptr
  store i64 95, ptr %p162, align 8, !alias.scope !3, !noalias !4
  %v163 = load i64, ptr %slot6, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld165, ptr %slot28, align 8
  %v166 = load i64, ptr %slot5, align 8
  %p167 = inttoptr i64 %v166 to ptr
  %ld168 = load i64, ptr %p167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld168, ptr %slot29, align 8
  %v169 = load i64, ptr %slot29, align 8
  %v170 = load i64, ptr %slot28, align 8
  %cmp171 = icmp eq i64 %v169, %v170
  %cv172 = zext i1 %cmp171 to i64
  store i64 %cv172, ptr %slot30, align 8
  %v173 = load i64, ptr %slot30, align 8
  %v174 = load i64, ptr %slot5, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i64 %v173, ptr %p175, align 8, !alias.scope !3, !noalias !4
  br label %bb_i27
bb_i27:
  %v176 = load i64, ptr %slot5, align 8
  %p177 = inttoptr i64 %v176 to ptr
  %ld178 = load i64, ptr %p177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld178, ptr %slot31, align 8
  %v179 = load i64, ptr %slot31, align 8
  ret i64 %v179
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
