target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %callresult59 = alloca [24 x i8], align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v247 = load i64, ptr %slot1, align 8
  %op248 = add i64 %v247, 32
  store i64 %op248, ptr %slot4, align 8
  %mem249 = alloca i8, i64 8, align 8
  %ptr250 = ptrtoint ptr %mem249 to i64
  store i64 %ptr250, ptr %slot5, align 8
  %mem251 = alloca i8, i64 8, align 8
  %ptr252 = ptrtoint ptr %mem251 to i64
  store i64 %ptr252, ptr %slot6, align 8
  %mem253 = alloca i8, i64 8, align 8
  %ptr254 = ptrtoint ptr %mem253 to i64
  store i64 %ptr254, ptr %slot7, align 8
  %mem255 = alloca i8, i64 8, align 8
  %ptr256 = ptrtoint ptr %mem255 to i64
  store i64 %ptr256, ptr %slot8, align 8
  %mem257 = alloca i8, i64 8, align 8
  %ptr258 = ptrtoint ptr %mem257 to i64
  store i64 %ptr258, ptr %slot9, align 8
  %mem259 = alloca i8, i64 8, align 8
  %ptr260 = ptrtoint ptr %mem259 to i64
  store i64 %ptr260, ptr %slot10, align 8
  %mem261 = alloca i8, i64 392, align 8
  %ptr262 = ptrtoint ptr %mem261 to i64
  store i64 %ptr262, ptr %slot11, align 8
  %mem263 = alloca i8, i64 8, align 8
  %ptr264 = ptrtoint ptr %mem263 to i64
  store i64 %ptr264, ptr %slot12, align 8
  %mem265 = alloca i8, i64 392, align 8
  %ptr266 = ptrtoint ptr %mem265 to i64
  store i64 %ptr266, ptr %slot13, align 8
  %mem267 = alloca i8, i64 8, align 8
  %ptr268 = ptrtoint ptr %mem267 to i64
  store i64 %ptr268, ptr %slot14, align 8
  %mem269 = alloca i8, i64 8, align 8
  %ptr270 = ptrtoint ptr %mem269 to i64
  store i64 %ptr270, ptr %slot15, align 8
  %mem271 = alloca i8, i64 8, align 8
  %ptr272 = ptrtoint ptr %mem271 to i64
  store i64 %ptr272, ptr %slot16, align 8
  %mem273 = alloca i8, i64 8, align 8
  %ptr274 = ptrtoint ptr %mem273 to i64
  store i64 %ptr274, ptr %slot17, align 8
  %mem275 = alloca i8, i64 8, align 8
  %ptr276 = ptrtoint ptr %mem275 to i64
  store i64 %ptr276, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem277 = alloca i8, i64 8, align 8
  %ptr278 = ptrtoint ptr %mem277 to i64
  store i64 %ptr278, ptr %slot19, align 8
  %v279 = load i64, ptr %slot1, align 8
  %op280 = add i64 %v279, 64
  store i64 %op280, ptr %slot20, align 8
  %v281 = load i64, ptr %slot20, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !4, !noalias !3
  store i64 %ld283, ptr %slot21, align 8
  %stack284 = call ptr @llvm.stacksave()
  %stackaddr285 = ptrtoint ptr %stack284 to i64
  %v286 = load i64, ptr %slot21, align 8
  %cmp287 = icmp ult i64 %stackaddr285, %v286
  %cv288 = zext i1 %cmp287 to i64
  store i64 %cv288, ptr %slot22, align 8
  %v289 = load i64, ptr %slot22, align 8
  %cond290 = icmp ne i64 %v289, 0
  br i1 %cond290, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v291 = load i64, ptr %slot1, align 8
  %p292 = inttoptr i64 %v291 to ptr
  call void @myl_qbe_fail_frame(ptr %p292) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v293 = load i64, ptr %slot16, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i64 0, ptr %p294, align 8, !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot2, align 8
  %v296 = load i64, ptr %slot14, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i64 %v295, ptr %p297, align 8, !alias.scope !3, !noalias !4
  %v298 = load i64, ptr %slot3, align 8
  %v299 = load i64, ptr %slot15, align 8
  %p300 = inttoptr i64 %v299 to ptr
  store i64 %v298, ptr %p300, align 8, !alias.scope !3, !noalias !4
  %v301 = load i64, ptr %slot1, align 8
  %p302 = inttoptr i64 %v301 to ptr
  %call303 = call ptr @myl_qbe_heap(ptr %p302) nomerge, !dbg !112
  %calladdr304 = ptrtoint ptr %call303 to i64
  store i64 %calladdr304, ptr %slot23, align 8
  %v305 = load i64, ptr %slot1, align 8
  %p306 = inttoptr i64 %v305 to ptr
  %call307 = call i64 @myl_qbe_region_mark(ptr %p306) nomerge, !dbg !112
  store i64 %call307, ptr %slot24, align 8
  %v308 = load i64, ptr %slot5, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i32 0, ptr %p309, align 4, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot6, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i32 0, ptr %p311, align 4, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot7, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i32 0, ptr %p313, align 4, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot8, align 8
  %p315 = inttoptr i64 %v314 to ptr
  store i32 0, ptr %p315, align 4, !alias.scope !3, !noalias !4
  %v316 = load i64, ptr %slot9, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i32 0, ptr %p317, align 4, !alias.scope !3, !noalias !4
  %v318 = load i64, ptr %slot10, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i32 0, ptr %p319, align 4, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot6, align 8
  %p321 = inttoptr i64 %v320 to ptr
  store i32 2, ptr %p321, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v322 = load i64, ptr %slot14, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %ld324 = load i64, ptr %p323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld324, ptr %slot25, align 8
  %v325 = load i64, ptr %slot25, align 8
  %v326 = load i64, ptr %slot17, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i64 %v325, ptr %p327, align 8, !alias.scope !3, !noalias !4
  %v328 = load i64, ptr %slot15, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i64, ptr %p329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld330, ptr %slot26, align 8
  %v331 = load i64, ptr %slot26, align 8
  %v332 = load i64, ptr %slot18, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 %v331, ptr %p333, align 8, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot17, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %ld336 = load i64, ptr %p335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld336, ptr %slot27, align 8
  %v337 = load i64, ptr %slot18, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot28, align 8
  %v340 = load i64, ptr %slot1, align 8
  %v341 = load i64, ptr %slot27, align 8
  %v342 = load i64, ptr %slot28, align 8
  %call343 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v340, i64 %v341, i64 %v342) nomerge, !dbg !114
  store i64 %call343, ptr %slot29, align 8
  %v344 = load i64, ptr %slot29, align 8
  %v345 = load i64, ptr %slot17, align 8
  %p346 = inttoptr i64 %v345 to ptr
  store i64 %v344, ptr %p346, align 8, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot7, align 8
  %p348 = inttoptr i64 %v347 to ptr
  %ld349 = load i32, ptr %p348, align 4, !alias.scope !3, !noalias !4
  store i32 %ld349, ptr %slot30, align 8
  %v350 = load i32, ptr %slot30, align 8
  %cv351 = zext i32 %v350 to i64
  %cond352 = icmp ne i64 %cv351, 0
  br i1 %cond352, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v353 = load i64, ptr %slot7, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i32 0, ptr %p354, align 4, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot11, align 8
  store i64 %v355, ptr %slot31, align 8
  %v356 = load i64, ptr %slot8, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i32, ptr %p357, align 4, !alias.scope !3, !noalias !4
  store i32 %ld358, ptr %slot32, align 8
  %v359 = load i32, ptr %slot32, align 8
  %op360 = and i32 %v359, 28
  store i32 %op360, ptr %slot33, align 8
  %v361 = load i32, ptr %slot33, align 8
  %cv362 = zext i32 %v361 to i64
  %cond363 = icmp ne i64 %cv362, 0
  br i1 %cond363, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v364 = load i64, ptr %slot23, align 8
  store i64 %v364, ptr %slot34, align 8
  %v365 = load i64, ptr %slot34, align 8
  %v366 = load i64, ptr %slot31, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v365, i64 %v366) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v367 = load i64, ptr %slot23, align 8
  store i64 %v367, ptr %slot35, align 8
  %v368 = load i64, ptr %slot35, align 8
  %v369 = load i64, ptr %slot31, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v368, i64 %v369) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v370 = load i64, ptr %slot14, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i64, ptr %p371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld372, ptr %slot36, align 8
  %v373 = load i64, ptr %slot36, align 8
  %v374 = load i64, ptr %slot17, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i64 %v373, ptr %p375, align 8, !alias.scope !3, !noalias !4
  %v376 = load i64, ptr %slot18, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i64 255, ptr %p377, align 8, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot17, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %ld380 = load i64, ptr %p379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld380, ptr %slot37, align 8
  %v381 = load i64, ptr %slot18, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %ld383 = load i64, ptr %p382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld383, ptr %slot38, align 8
  %v384 = load i64, ptr %slot1, align 8
  %v385 = load i64, ptr %slot37, align 8
  %v386 = load i64, ptr %slot38, align 8
  %call387 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v384, i64 %v385, i64 %v386) nomerge, !dbg !116
  store i64 %call387, ptr %slot39, align 8
  %v388 = load i64, ptr %slot39, align 8
  %v389 = load i64, ptr %slot17, align 8
  %p390 = inttoptr i64 %v389 to ptr
  store i64 %v388, ptr %p390, align 8, !alias.scope !3, !noalias !4
  %v391 = load i64, ptr %slot7, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i32, ptr %p392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld393, ptr %slot40, align 8
  %v394 = load i32, ptr %slot40, align 8
  %cv395 = zext i32 %v394 to i64
  %cond396 = icmp ne i64 %cv395, 0
  br i1 %cond396, label %bb_rcslotdrop29, label %bb_rcslotdone29
bb_rcslotdrop29:
  %v397 = load i64, ptr %slot7, align 8
  %p398 = inttoptr i64 %v397 to ptr
  store i32 0, ptr %p398, align 4, !alias.scope !3, !noalias !4
  %v399 = load i64, ptr %slot11, align 8
  store i64 %v399, ptr %slot41, align 8
  %v400 = load i64, ptr %slot8, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %ld402 = load i32, ptr %p401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld402, ptr %slot42, align 8
  %v403 = load i32, ptr %slot42, align 8
  %op404 = and i32 %v403, 28
  store i32 %op404, ptr %slot43, align 8
  %v405 = load i32, ptr %slot43, align 8
  %cv406 = zext i32 %v405 to i64
  %cond407 = icmp ne i64 %cv406, 0
  br i1 %cond407, label %bb_rcslotrole29, label %bb_rcslotowner29
bb_rcslotrole29:
  %v408 = load i64, ptr %slot23, align 8
  store i64 %v408, ptr %slot44, align 8
  %v409 = load i64, ptr %slot44, align 8
  %v410 = load i64, ptr %slot41, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v409, i64 %v410) nomerge, !dbg !116
  br label %bb_rcslotdone29
bb_rcslotowner29:
  %v411 = load i64, ptr %slot23, align 8
  store i64 %v411, ptr %slot45, align 8
  %v412 = load i64, ptr %slot45, align 8
  %v413 = load i64, ptr %slot41, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v412, i64 %v413) nomerge, !dbg !116
  br label %bb_rcslotdone29
bb_rcslotdone29:
  %v414 = load i64, ptr %slot14, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot46, align 8
  %v417 = load i64, ptr %slot46, align 8
  %v418 = load i64, ptr %slot17, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i64 %v417, ptr %p419, align 8, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot18, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i64 255, ptr %p421, align 8, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot17, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i64, ptr %p423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot47, align 8
  %v425 = load i64, ptr %slot18, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i64, ptr %p426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld427, ptr %slot48, align 8
  %v428 = load i64, ptr %slot1, align 8
  %v429 = load i64, ptr %slot47, align 8
  %v430 = load i64, ptr %slot48, align 8
  %call431 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v428, i64 %v429, i64 %v430) nomerge, !dbg !118
  store i64 %call431, ptr %slot49, align 8
  %v432 = load i64, ptr %slot49, align 8
  %v433 = load i64, ptr %slot17, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i64 %v432, ptr %p434, align 8, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot7, align 8
  %p436 = inttoptr i64 %v435 to ptr
  %ld437 = load i32, ptr %p436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld437, ptr %slot50, align 8
  %v438 = load i32, ptr %slot50, align 8
  %cv439 = zext i32 %v438 to i64
  %cond440 = icmp ne i64 %cv439, 0
  br i1 %cond440, label %bb_rcslotdrop42, label %bb_rcslotdone42
bb_rcslotdrop42:
  %v441 = load i64, ptr %slot7, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i32 0, ptr %p442, align 4, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot11, align 8
  store i64 %v443, ptr %slot51, align 8
  %v444 = load i64, ptr %slot8, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i32, ptr %p445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld446, ptr %slot52, align 8
  %v447 = load i32, ptr %slot52, align 8
  %op448 = and i32 %v447, 28
  store i32 %op448, ptr %slot53, align 8
  %v449 = load i32, ptr %slot53, align 8
  %cv450 = zext i32 %v449 to i64
  %cond451 = icmp ne i64 %cv450, 0
  br i1 %cond451, label %bb_rcslotrole42, label %bb_rcslotowner42
bb_rcslotrole42:
  %v452 = load i64, ptr %slot23, align 8
  store i64 %v452, ptr %slot54, align 8
  %v453 = load i64, ptr %slot54, align 8
  %v454 = load i64, ptr %slot51, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v453, i64 %v454) nomerge, !dbg !118
  br label %bb_rcslotdone42
bb_rcslotowner42:
  %v455 = load i64, ptr %slot23, align 8
  store i64 %v455, ptr %slot55, align 8
  %v456 = load i64, ptr %slot55, align 8
  %v457 = load i64, ptr %slot51, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v456, i64 %v457) nomerge, !dbg !118
  br label %bb_rcslotdone42
bb_rcslotdone42:
  %v458 = load i64, ptr %slot14, align 8
  %p459 = inttoptr i64 %v458 to ptr
  %ld460 = load i64, ptr %p459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld460, ptr %slot56, align 8
  %v461 = load i64, ptr %slot56, align 8
  %v462 = load i64, ptr %slot17, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i64 %v461, ptr %p463, align 8, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot17, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i64, ptr %p465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld466, ptr %slot57, align 8
  %v467 = load i64, ptr %slot1, align 8
  %v468 = load i64, ptr %slot57, align 8
  call void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8 %callresult59, i64 %v467, i64 %v468) nomerge, !dbg !120
  %addr469 = ptrtoint ptr %callresult59 to i64
  store i64 %addr469, ptr %slot58, align 8
  %v470 = load i64, ptr %slot58, align 8
  %v471 = load i64, ptr %slot17, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i64 %v470, ptr %p472, align 8, !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot17, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %ld475 = load i64, ptr %p474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld475, ptr %slot60, align 8
  %v476 = load i64, ptr %slot13, align 8
  store i64 %v476, ptr %slot61, align 8
  %v477 = load i64, ptr %slot60, align 8
  %v478 = load i64, ptr %slot61, align 8
  %p479 = inttoptr i64 %v477 to ptr
  %p480 = inttoptr i64 %v478 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p480, ptr %p479, i64 24, i1 false)
  %v481 = load i64, ptr %slot10, align 8
  %p482 = inttoptr i64 %v481 to ptr
  store i32 2, ptr %p482, align 4, !alias.scope !3, !noalias !4
  %v483 = load i64, ptr %slot9, align 8
  %p484 = inttoptr i64 %v483 to ptr
  store i32 1, ptr %p484, align 4, !alias.scope !3, !noalias !4
  %v485 = load i64, ptr %slot7, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i32, ptr %p486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld487, ptr %slot62, align 8
  %v488 = load i32, ptr %slot62, align 8
  %cv489 = zext i32 %v488 to i64
  %cond490 = icmp ne i64 %cv489, 0
  br i1 %cond490, label %bb_rcslotdrop58, label %bb_rcslotdone58
bb_rcslotdrop58:
  %v491 = load i64, ptr %slot7, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i32 0, ptr %p492, align 4, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot11, align 8
  store i64 %v493, ptr %slot63, align 8
  %v494 = load i64, ptr %slot8, align 8
  %p495 = inttoptr i64 %v494 to ptr
  %ld496 = load i32, ptr %p495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld496, ptr %slot64, align 8
  %v497 = load i32, ptr %slot64, align 8
  %op498 = and i32 %v497, 28
  store i32 %op498, ptr %slot65, align 8
  %v499 = load i32, ptr %slot65, align 8
  %cv500 = zext i32 %v499 to i64
  %cond501 = icmp ne i64 %cv500, 0
  br i1 %cond501, label %bb_rcslotrole58, label %bb_rcslotowner58
bb_rcslotrole58:
  %v502 = load i64, ptr %slot23, align 8
  store i64 %v502, ptr %slot66, align 8
  %v503 = load i64, ptr %slot66, align 8
  %v504 = load i64, ptr %slot63, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v503, i64 %v504) nomerge, !dbg !120
  br label %bb_rcslotdone58
bb_rcslotowner58:
  %v505 = load i64, ptr %slot23, align 8
  store i64 %v505, ptr %slot67, align 8
  %v506 = load i64, ptr %slot67, align 8
  %v507 = load i64, ptr %slot63, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v506, i64 %v507) nomerge, !dbg !120
  br label %bb_rcslotdone58
bb_rcslotdone58:
  %v508 = load i64, ptr %slot11, align 8
  store i64 %v508, ptr %slot68, align 8
  %v509 = load i64, ptr %slot13, align 8
  store i64 %v509, ptr %slot69, align 8
  %v510 = load i64, ptr %slot69, align 8
  %v511 = load i64, ptr %slot68, align 8
  %p512 = inttoptr i64 %v510 to ptr
  %p513 = inttoptr i64 %v511 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p513, ptr %p512, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v514 = load i64, ptr %slot8, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i32 2, ptr %p515, align 4, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot10, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i32, ptr %p517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld518, ptr %slot70, align 8
  %v519 = load i32, ptr %slot70, align 8
  %v520 = load i64, ptr %slot8, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i32 %v519, ptr %p521, align 4, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot9, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i32 0, ptr %p523, align 4, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot7, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i32 1, ptr %p525, align 4, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot68, align 8
  %v527 = load i64, ptr %slot17, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i64 %v526, ptr %p528, align 8, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot17, align 8
  %p530 = inttoptr i64 %v529 to ptr
  %ld531 = load i64, ptr %p530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld531, ptr %slot71, align 8
  %v532 = load i64, ptr %slot71, align 8
  %op533 = add i64 %v532, 0
  store i64 %op533, ptr %slot72, align 8
  %v534 = load i64, ptr %slot72, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i64, ptr %p535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld536, ptr %slot73, align 8
  %v537 = load i64, ptr %slot73, align 8
  %v538 = load i64, ptr %slot17, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i64 %v537, ptr %p539, align 8, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot17, align 8
  %p541 = inttoptr i64 %v540 to ptr
  %ld542 = load i64, ptr %p541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld542, ptr %slot74, align 8
  %v543 = load i64, ptr %slot74, align 8
  %v544 = load i64, ptr %slot12, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i64 %v543, ptr %p545, align 8, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot12, align 8
  store i64 %v546, ptr %slot75, align 8
  %v547 = load i64, ptr %slot13, align 8
  store i64 %v547, ptr %slot76, align 8
  %v548 = load i64, ptr %slot75, align 8
  %p549 = inttoptr i64 %v548 to ptr
  %ld550 = load i64, ptr %p549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld550, ptr %slot77, align 8
  %v551 = load i64, ptr %slot77, align 8
  %cmp552 = icmp ne i64 %v551, 0
  %cv553 = zext i1 %cmp552 to i32
  store i32 %cv553, ptr %slot78, align 8
  %v554 = load i32, ptr %slot78, align 8
  %cv555 = zext i32 %v554 to i64
  %cond556 = icmp ne i64 %cv555, 0
  br i1 %cond556, label %bb_rcgnn80, label %bb_rcgstore80
bb_rcgnn80:
  %v557 = load i64, ptr %slot77, align 8
  %op558 = sub i64 %v557, 16
  store i64 %op558, ptr %slot79, align 8
  %v559 = load i64, ptr %slot77, align 8
  %p560 = inttoptr i64 %v559 to ptr
  %rgep561 = getelementptr i8, ptr %p560, i64 -16
  %ld562 = load i64, ptr %rgep561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld562, ptr %slot80, align 8
  %v563 = load i64, ptr %slot80, align 8
  %op564 = and i64 %v563, 4611686018427387906
  store i64 %op564, ptr %slot81, align 8
  %v565 = load i64, ptr %slot81, align 8
  %cmp566 = icmp ne i64 %v565, 0
  %cv567 = zext i1 %cmp566 to i32
  store i32 %cv567, ptr %slot82, align 8
  %v568 = load i32, ptr %slot82, align 8
  %cv569 = zext i32 %v568 to i64
  %cond570 = icmp ne i64 %cv569, 0
  br i1 %cond570, label %bb_rcgstore80, label %bb_rcginc80
bb_rcginc80:
  %v571 = load i64, ptr %slot77, align 8
  %op572 = sub i64 %v571, 24
  store i64 %op572, ptr %slot83, align 8
  %v573 = load i64, ptr %slot77, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %rgep575 = getelementptr i8, ptr %p574, i64 -24
  %ld576 = load i64, ptr %rgep575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld576, ptr %slot84, align 8
  %v577 = load i64, ptr %slot84, align 8
  %op578 = add i64 %v577, 1
  store i64 %op578, ptr %slot85, align 8
  %v579 = load i64, ptr %slot85, align 8
  %cmp580 = icmp eq i64 %v579, 0
  %cv581 = zext i1 %cmp580 to i32
  store i32 %cv581, ptr %slot86, align 8
  %v582 = load i32, ptr %slot86, align 8
  %cv583 = zext i32 %v582 to i64
  %cond584 = icmp ne i64 %cv583, 0
  br i1 %cond584, label %bb_rcglimit80, label %bb_rcgcapacity80
bb_rcglimit80:
  %v585 = load i64, ptr %slot1, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %call587 = call i32 @myl_qbe_rc_status(ptr %p586, i32 2) nomerge, !dbg !122
  store i32 %call587, ptr %slot87, align 8
  br label %bb_failure
bb_rcgcapacity80:
  %v588 = load i64, ptr %slot85, align 8
  %v589 = load i64, ptr %slot77, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %rgep591 = getelementptr i8, ptr %p590, i64 -24
  store i64 %v588, ptr %rgep591, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore80
bb_rcgstore80:
  %v592 = load i64, ptr %slot77, align 8
  %v593 = load i64, ptr %slot76, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i64 %v592, ptr %p594, align 8, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot10, align 8
  %p596 = inttoptr i64 %v595 to ptr
  store i32 2, ptr %p596, align 4, !alias.scope !3, !noalias !4
  %v597 = load i64, ptr %slot10, align 8
  %p598 = inttoptr i64 %v597 to ptr
  store i32 16, ptr %p598, align 4, !alias.scope !3, !noalias !4
  %v599 = load i64, ptr %slot9, align 8
  %p600 = inttoptr i64 %v599 to ptr
  store i32 1, ptr %p600, align 4, !alias.scope !3, !noalias !4
  %v601 = load i64, ptr %slot7, align 8
  %p602 = inttoptr i64 %v601 to ptr
  %ld603 = load i32, ptr %p602, align 4, !alias.scope !3, !noalias !4
  store i32 %ld603, ptr %slot88, align 8
  %v604 = load i32, ptr %slot88, align 8
  %cv605 = zext i32 %v604 to i64
  %cond606 = icmp ne i64 %cv605, 0
  br i1 %cond606, label %bb_rcslotdrop96, label %bb_rcslotdone96
bb_rcslotdrop96:
  %v607 = load i64, ptr %slot7, align 8
  %p608 = inttoptr i64 %v607 to ptr
  store i32 0, ptr %p608, align 4, !alias.scope !3, !noalias !4
  %v609 = load i64, ptr %slot11, align 8
  store i64 %v609, ptr %slot89, align 8
  %v610 = load i64, ptr %slot8, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i32, ptr %p611, align 4, !alias.scope !3, !noalias !4
  store i32 %ld612, ptr %slot90, align 8
  %v613 = load i32, ptr %slot90, align 8
  %op614 = and i32 %v613, 28
  store i32 %op614, ptr %slot91, align 8
  %v615 = load i32, ptr %slot91, align 8
  %cv616 = zext i32 %v615 to i64
  %cond617 = icmp ne i64 %cv616, 0
  br i1 %cond617, label %bb_rcslotrole96, label %bb_rcslotowner96
bb_rcslotrole96:
  %v618 = load i64, ptr %slot23, align 8
  store i64 %v618, ptr %slot92, align 8
  %v619 = load i64, ptr %slot92, align 8
  %v620 = load i64, ptr %slot89, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v619, i64 %v620) nomerge, !dbg !122
  br label %bb_rcslotdone96
bb_rcslotowner96:
  %v621 = load i64, ptr %slot23, align 8
  store i64 %v621, ptr %slot93, align 8
  %v622 = load i64, ptr %slot93, align 8
  %v623 = load i64, ptr %slot89, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v622, i64 %v623) nomerge, !dbg !122
  br label %bb_rcslotdone96
bb_rcslotdone96:
  %v624 = load i64, ptr %slot11, align 8
  store i64 %v624, ptr %slot94, align 8
  %v625 = load i64, ptr %slot13, align 8
  store i64 %v625, ptr %slot95, align 8
  %v626 = load i64, ptr %slot95, align 8
  %v627 = load i64, ptr %slot94, align 8
  %p628 = inttoptr i64 %v626 to ptr
  %p629 = inttoptr i64 %v627 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p629, ptr %p628, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot8, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i32 2, ptr %p631, align 4, !alias.scope !3, !noalias !4
  %v632 = load i64, ptr %slot10, align 8
  %p633 = inttoptr i64 %v632 to ptr
  %ld634 = load i32, ptr %p633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld634, ptr %slot96, align 8
  %v635 = load i32, ptr %slot96, align 8
  %v636 = load i64, ptr %slot8, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i32 %v635, ptr %p637, align 4, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot9, align 8
  %p639 = inttoptr i64 %v638 to ptr
  store i32 0, ptr %p639, align 4, !alias.scope !3, !noalias !4
  %v640 = load i64, ptr %slot7, align 8
  %p641 = inttoptr i64 %v640 to ptr
  store i32 1, ptr %p641, align 4, !alias.scope !3, !noalias !4
  %v642 = load i64, ptr %slot94, align 8
  %p643 = inttoptr i64 %v642 to ptr
  %ld644 = load i64, ptr %p643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld644, ptr %slot97, align 8
  %v645 = load i64, ptr %slot97, align 8
  %v646 = load i64, ptr %slot17, align 8
  %p647 = inttoptr i64 %v646 to ptr
  store i64 %v645, ptr %p647, align 8, !alias.scope !3, !noalias !4
  %v648 = load i64, ptr %slot17, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i64, ptr %p649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld650, ptr %slot98, align 8
  %v651 = load i64, ptr %slot98, align 8
  %v652 = load i64, ptr %slot12, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i64 %v651, ptr %p653, align 8, !alias.scope !3, !noalias !4
  %v654 = load i64, ptr %slot12, align 8
  store i64 %v654, ptr %slot99, align 8
  %v655 = load i64, ptr %slot7, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i32, ptr %p656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld657, ptr %slot100, align 8
  %v658 = load i64, ptr %slot8, align 8
  %p659 = inttoptr i64 %v658 to ptr
  %ld660 = load i32, ptr %p659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld660, ptr %slot101, align 8
  %v661 = load i32, ptr %slot101, align 8
  %op662 = and i32 %v661, 24
  store i32 %op662, ptr %slot101, align 8
  %v663 = load i32, ptr %slot101, align 8
  %cmp664 = icmp eq i32 %v663, 0
  %cv665 = zext i1 %cmp664 to i32
  store i32 %cv665, ptr %slot102, align 8
  %v666 = load i32, ptr %slot100, align 8
  %v667 = load i32, ptr %slot102, align 8
  %op668 = and i32 %v666, %v667
  store i32 %op668, ptr %slot103, align 8
  %v669 = load i32, ptr %slot103, align 8
  %cv670 = zext i32 %v669 to i64
  %cond671 = icmp ne i64 %cv670, 0
  br i1 %cond671, label %bb_rcprivateown120, label %bb_rcprivateloan120
bb_rcprivateown120:
  %v672 = load i64, ptr %slot13, align 8
  store i64 %v672, ptr %slot104, align 8
  %v673 = load i64, ptr %slot24, align 8
  store i64 %v673, ptr %slot105, align 8
  %v674 = load i64, ptr %slot99, align 8
  %v675 = load i64, ptr %slot104, align 8
  %op676 = sub i64 %v674, %v675
  store i64 %op676, ptr %slot106, align 8
  %v677 = load i64, ptr %slot104, align 8
  %v678 = load i64, ptr %slot99, align 8
  %op679 = sub i64 %v677, %v678
  store i64 %op679, ptr %slot107, align 8
  %v680 = load i64, ptr %slot106, align 8
  %cmp681 = icmp ult i64 %v680, 8
  %cv682 = zext i1 %cmp681 to i32
  store i32 %cv682, ptr %slot108, align 8
  %v683 = load i64, ptr %slot107, align 8
  %cmp684 = icmp ult i64 %v683, 8
  %cv685 = zext i1 %cmp684 to i32
  store i32 %cv685, ptr %slot109, align 8
  %v686 = load i32, ptr %slot108, align 8
  %v687 = load i32, ptr %slot109, align 8
  %op688 = or i32 %v686, %v687
  store i32 %op688, ptr %slot110, align 8
  %v689 = load i32, ptr %slot110, align 8
  %cv690 = zext i32 %v689 to i64
  %cond691 = icmp ne i64 %cv690, 0
  br i1 %cond691, label %bb_rcmoveslow123, label %bb_rcmovecheck123
bb_rcmovecheck123:
  %v692 = load i64, ptr %slot99, align 8
  %p694 = inttoptr i64 %v692 to ptr
  %gep695 = getelementptr i8, ptr %p694, i64 0
  %op693 = ptrtoint ptr %gep695 to i64
  store i64 %op693, ptr %slot111, align 8
  %v696 = load i64, ptr %slot111, align 8
  %p697 = inttoptr i64 %v696 to ptr
  %ld698 = load i64, ptr %p697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld698, ptr %slot112, align 8
  %v699 = load i64, ptr %slot112, align 8
  %cmp700 = icmp ne i64 %v699, 0
  %cv701 = zext i1 %cmp700 to i32
  store i32 %cv701, ptr %slot113, align 8
  %v702 = load i32, ptr %slot113, align 8
  %cv703 = zext i32 %v702 to i64
  %cond704 = icmp ne i64 %cv703, 0
  br i1 %cond704, label %bb_rcmoveheader131, label %bb_rcmovenext131
bb_rcmoveheader131:
  %v705 = load i64, ptr %slot112, align 8
  %op706 = sub i64 %v705, 16
  store i64 %op706, ptr %slot114, align 8
  %v707 = load i64, ptr %slot112, align 8
  %p708 = inttoptr i64 %v707 to ptr
  %rgep709 = getelementptr i8, ptr %p708, i64 -16
  %ld710 = load i64, ptr %rgep709, align 8, !alias.scope !9, !noalias !10
  store i64 %ld710, ptr %slot115, align 8
  %v711 = load i64, ptr %slot115, align 8
  %op712 = and i64 %v711, 5764607523034234881
  store i64 %op712, ptr %slot116, align 8
  %v713 = load i64, ptr %slot116, align 8
  %cmp714 = icmp ne i64 %v713, 0
  %cv715 = zext i1 %cmp714 to i32
  store i32 %cv715, ptr %slot117, align 8
  %v716 = load i32, ptr %slot117, align 8
  %cv717 = zext i32 %v716 to i64
  %cond718 = icmp ne i64 %cv717, 0
  br i1 %cond718, label %bb_rcmoveslow123, label %bb_rcmovenext131
bb_rcmovenext131:
  %v719 = load i64, ptr %slot99, align 8
  %v720 = load i64, ptr %slot104, align 8
  %p721 = inttoptr i64 %v719 to ptr
  %p722 = inttoptr i64 %v720 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p722, ptr %p721, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v723 = load i64, ptr %slot99, align 8
  %p724 = inttoptr i64 %v723 to ptr
  store i64 0, ptr %p724, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved123
bb_rcmoveslow123:
  %v725 = load i64, ptr %slot23, align 8
  %v726 = load i64, ptr %slot104, align 8
  %v727 = load i64, ptr %slot99, align 8
  %v728 = load i64, ptr %slot105, align 8
  %cv729 = trunc i64 %v728 to i32
  %call730 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v725, i64 %v726, i64 %v727, i32 %cv729) nomerge, !dbg !124
  store i32 %call730, ptr %slot118, align 8
  %v731 = load i32, ptr %slot118, align 8
  %cv732 = zext i32 %v731 to i64
  %cond733 = icmp ne i64 %cv732, 0
  br i1 %cond733, label %bb_rcsuccess138, label %bb_rcfailure138
bb_rcfailure138:
  %v734 = load i64, ptr %slot23, align 8
  %p735 = inttoptr i64 %v734 to ptr
  %call736 = call i32 @myl_rc_take_failure(ptr %p735) nomerge, !dbg !124
  store i32 %call736, ptr %slot119, align 8
  %v737 = load i64, ptr %slot1, align 8
  %p738 = inttoptr i64 %v737 to ptr
  %v739 = load i32, ptr %slot119, align 8
  %call740 = call i32 @myl_qbe_rc_status(ptr %p738, i32 %v739) nomerge, !dbg !124
  store i32 %call740, ptr %slot120, align 8
  br label %bb_failure
bb_rcsuccess138:
  br label %bb_rcmoved123
bb_rcmoved123:
  %v741 = load i64, ptr %slot7, align 8
  %p742 = inttoptr i64 %v741 to ptr
  store i32 0, ptr %p742, align 4, !alias.scope !3, !noalias !4
  %v743 = load i64, ptr %slot10, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i32 2, ptr %p744, align 4, !alias.scope !3, !noalias !4
  %v745 = load i64, ptr %slot9, align 8
  %p746 = inttoptr i64 %v745 to ptr
  store i32 1, ptr %p746, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared120
bb_rcprivateloan120:
  %v747 = load i64, ptr %slot7, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %ld749 = load i32, ptr %p748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld749, ptr %slot121, align 8
  %v750 = load i64, ptr %slot8, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %ld752 = load i32, ptr %p751, align 4, !alias.scope !3, !noalias !4
  store i32 %ld752, ptr %slot122, align 8
  %v753 = load i32, ptr %slot122, align 8
  %cmp754 = icmp eq i32 %v753, 16
  %cv755 = zext i1 %cmp754 to i32
  store i32 %cv755, ptr %slot123, align 8
  %v756 = load i32, ptr %slot123, align 8
  %v757 = load i32, ptr %slot121, align 8
  %op758 = and i32 %v756, %v757
  store i32 %op758, ptr %slot123, align 8
  %v759 = load i32, ptr %slot123, align 8
  %cv760 = zext i32 %v759 to i64
  %cond761 = icmp ne i64 %cv760, 0
  br i1 %cond761, label %bb_rcprivatemove120, label %bb_rcprivatenew120
bb_rcprivatemove120:
  %v762 = load i64, ptr %slot13, align 8
  store i64 %v762, ptr %slot124, align 8
  %v763 = load i64, ptr %slot99, align 8
  %v764 = load i64, ptr %slot124, align 8
  %p765 = inttoptr i64 %v763 to ptr
  %p766 = inttoptr i64 %v764 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p766, ptr %p765, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v767 = load i64, ptr %slot99, align 8
  %p768 = inttoptr i64 %v767 to ptr
  store i64 0, ptr %p768, align 8, !alias.scope !3, !noalias !4
  %v769 = load i64, ptr %slot10, align 8
  %p770 = inttoptr i64 %v769 to ptr
  store i32 2, ptr %p770, align 4, !alias.scope !3, !noalias !4
  %v771 = load i64, ptr %slot10, align 8
  %p772 = inttoptr i64 %v771 to ptr
  store i32 16, ptr %p772, align 4, !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot9, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i32 1, ptr %p774, align 4, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot7, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i32 0, ptr %p776, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared120
bb_rcprivatenew120:
  %v777 = load i64, ptr %slot13, align 8
  store i64 %v777, ptr %slot125, align 8
  %v778 = load i64, ptr %slot99, align 8
  %p779 = inttoptr i64 %v778 to ptr
  %ld780 = load i64, ptr %p779, align 8, !alias.scope !3, !noalias !4
  store i64 %ld780, ptr %slot126, align 8
  %v781 = load i64, ptr %slot126, align 8
  %cmp782 = icmp ne i64 %v781, 0
  %cv783 = zext i1 %cmp782 to i32
  store i32 %cv783, ptr %slot127, align 8
  %v784 = load i32, ptr %slot127, align 8
  %cv785 = zext i32 %v784 to i64
  %cond786 = icmp ne i64 %cv785, 0
  br i1 %cond786, label %bb_rcgnn156, label %bb_rcgstore156
bb_rcgnn156:
  %v787 = load i64, ptr %slot126, align 8
  %op788 = sub i64 %v787, 16
  store i64 %op788, ptr %slot128, align 8
  %v789 = load i64, ptr %slot126, align 8
  %p790 = inttoptr i64 %v789 to ptr
  %rgep791 = getelementptr i8, ptr %p790, i64 -16
  %ld792 = load i64, ptr %rgep791, align 8, !alias.scope !9, !noalias !10
  store i64 %ld792, ptr %slot129, align 8
  %v793 = load i64, ptr %slot129, align 8
  %op794 = and i64 %v793, 4611686018427387906
  store i64 %op794, ptr %slot130, align 8
  %v795 = load i64, ptr %slot130, align 8
  %cmp796 = icmp ne i64 %v795, 0
  %cv797 = zext i1 %cmp796 to i32
  store i32 %cv797, ptr %slot131, align 8
  %v798 = load i32, ptr %slot131, align 8
  %cv799 = zext i32 %v798 to i64
  %cond800 = icmp ne i64 %cv799, 0
  br i1 %cond800, label %bb_rcgstore156, label %bb_rcginc156
bb_rcginc156:
  %v801 = load i64, ptr %slot126, align 8
  %op802 = sub i64 %v801, 24
  store i64 %op802, ptr %slot132, align 8
  %v803 = load i64, ptr %slot126, align 8
  %p804 = inttoptr i64 %v803 to ptr
  %rgep805 = getelementptr i8, ptr %p804, i64 -24
  %ld806 = load i64, ptr %rgep805, align 8, !alias.scope !9, !noalias !10
  store i64 %ld806, ptr %slot133, align 8
  %v807 = load i64, ptr %slot133, align 8
  %op808 = add i64 %v807, 1
  store i64 %op808, ptr %slot134, align 8
  %v809 = load i64, ptr %slot134, align 8
  %cmp810 = icmp eq i64 %v809, 0
  %cv811 = zext i1 %cmp810 to i32
  store i32 %cv811, ptr %slot135, align 8
  %v812 = load i32, ptr %slot135, align 8
  %cv813 = zext i32 %v812 to i64
  %cond814 = icmp ne i64 %cv813, 0
  br i1 %cond814, label %bb_rcglimit156, label %bb_rcgcapacity156
bb_rcglimit156:
  %v815 = load i64, ptr %slot1, align 8
  %p816 = inttoptr i64 %v815 to ptr
  %call817 = call i32 @myl_qbe_rc_status(ptr %p816, i32 2) nomerge, !dbg !124
  store i32 %call817, ptr %slot136, align 8
  br label %bb_failure
bb_rcgcapacity156:
  %v818 = load i64, ptr %slot134, align 8
  %v819 = load i64, ptr %slot126, align 8
  %p820 = inttoptr i64 %v819 to ptr
  %rgep821 = getelementptr i8, ptr %p820, i64 -24
  store i64 %v818, ptr %rgep821, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore156
bb_rcgstore156:
  %v822 = load i64, ptr %slot126, align 8
  %v823 = load i64, ptr %slot125, align 8
  %p824 = inttoptr i64 %v823 to ptr
  store i64 %v822, ptr %p824, align 8, !alias.scope !3, !noalias !4
  %v825 = load i64, ptr %slot10, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i32 2, ptr %p826, align 4, !alias.scope !3, !noalias !4
  %v827 = load i64, ptr %slot10, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i32 16, ptr %p828, align 4, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot9, align 8
  %p830 = inttoptr i64 %v829 to ptr
  store i32 1, ptr %p830, align 4, !alias.scope !3, !noalias !4
  %v831 = load i64, ptr %slot7, align 8
  %p832 = inttoptr i64 %v831 to ptr
  %ld833 = load i32, ptr %p832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld833, ptr %slot137, align 8
  %v834 = load i32, ptr %slot137, align 8
  %cv835 = zext i32 %v834 to i64
  %cond836 = icmp ne i64 %cv835, 0
  br i1 %cond836, label %bb_rcslotdrop172, label %bb_rcslotdone172
bb_rcslotdrop172:
  %v837 = load i64, ptr %slot7, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i32 0, ptr %p838, align 4, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot11, align 8
  store i64 %v839, ptr %slot138, align 8
  %v840 = load i64, ptr %slot8, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %ld842 = load i32, ptr %p841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld842, ptr %slot139, align 8
  %v843 = load i32, ptr %slot139, align 8
  %op844 = and i32 %v843, 28
  store i32 %op844, ptr %slot140, align 8
  %v845 = load i32, ptr %slot140, align 8
  %cv846 = zext i32 %v845 to i64
  %cond847 = icmp ne i64 %cv846, 0
  br i1 %cond847, label %bb_rcslotrole172, label %bb_rcslotowner172
bb_rcslotrole172:
  %v848 = load i64, ptr %slot23, align 8
  store i64 %v848, ptr %slot141, align 8
  %v849 = load i64, ptr %slot138, align 8
  %p850 = inttoptr i64 %v849 to ptr
  %ld851 = load i64, ptr %p850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld851, ptr %slot142, align 8
  %v852 = load i64, ptr %slot142, align 8
  %cmp853 = icmp ne i64 %v852, 0
  %cv854 = zext i1 %cmp853 to i32
  store i32 %cv854, ptr %slot143, align 8
  %v855 = load i32, ptr %slot143, align 8
  %cv856 = zext i32 %v855 to i64
  %cond857 = icmp ne i64 %cv856, 0
  br i1 %cond857, label %bb_rcgnn188, label %bb_rcgdone188
bb_rcgnn188:
  %v858 = load i64, ptr %slot142, align 8
  %op859 = sub i64 %v858, 16
  store i64 %op859, ptr %slot144, align 8
  %v860 = load i64, ptr %slot142, align 8
  %p861 = inttoptr i64 %v860 to ptr
  %rgep862 = getelementptr i8, ptr %p861, i64 -16
  %ld863 = load i64, ptr %rgep862, align 8, !alias.scope !9, !noalias !10
  store i64 %ld863, ptr %slot145, align 8
  %v864 = load i64, ptr %slot145, align 8
  %op865 = and i64 %v864, 4611686018427387906
  store i64 %op865, ptr %slot146, align 8
  %v866 = load i64, ptr %slot146, align 8
  %cmp867 = icmp ne i64 %v866, 0
  %cv868 = zext i1 %cmp867 to i32
  store i32 %cv868, ptr %slot147, align 8
  %v869 = load i32, ptr %slot147, align 8
  %cv870 = zext i32 %v869 to i64
  %cond871 = icmp ne i64 %cv870, 0
  br i1 %cond871, label %bb_rcgclear188, label %bb_rcgcounted188
bb_rcgcounted188:
  %v872 = load i64, ptr %slot142, align 8
  %op873 = sub i64 %v872, 24
  store i64 %op873, ptr %slot148, align 8
  %v874 = load i64, ptr %slot142, align 8
  %p875 = inttoptr i64 %v874 to ptr
  %rgep876 = getelementptr i8, ptr %p875, i64 -24
  %ld877 = load i64, ptr %rgep876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld877, ptr %slot149, align 8
  %v878 = load i64, ptr %slot149, align 8
  %op879 = sub i64 %v878, 1
  store i64 %op879, ptr %slot150, align 8
  %v880 = load i64, ptr %slot150, align 8
  %cmp881 = icmp eq i64 %v880, 0
  %cv882 = zext i1 %cmp881 to i32
  store i32 %cv882, ptr %slot151, align 8
  %v883 = load i32, ptr %slot151, align 8
  %cv884 = zext i32 %v883 to i64
  %cond885 = icmp ne i64 %cv884, 0
  br i1 %cond885, label %bb_rcglast188, label %bb_rcgdec188
bb_rcglast188:
  %v886 = load i64, ptr %slot142, align 8
  %op887 = sub i64 %v886, 32
  store i64 %op887, ptr %slot152, align 8
  %v888 = load i64, ptr %slot142, align 8
  %p889 = inttoptr i64 %v888 to ptr
  %rgep890 = getelementptr i8, ptr %p889, i64 -32
  %ld891 = load i64, ptr %rgep890, align 8, !alias.scope !9, !noalias !10
  store i64 %ld891, ptr %slot153, align 8
  %v892 = load i64, ptr %slot153, align 8
  %cmp893 = icmp ne i64 %v892, 0
  %cv894 = zext i1 %cmp893 to i32
  store i32 %cv894, ptr %slot154, align 8
  %v895 = load i32, ptr %slot154, align 8
  %cv896 = zext i32 %v895 to i64
  %cond897 = icmp ne i64 %cv896, 0
  br i1 %cond897, label %bb_rcgdec188, label %bb_rcgslow188
bb_rcgslow188:
  %v898 = load i64, ptr %slot141, align 8
  %v899 = load i64, ptr %slot138, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v898, i64 %v899) nomerge, !dbg !124
  br label %bb_rcgdone188
bb_rcgdec188:
  %v900 = load i64, ptr %slot150, align 8
  %v901 = load i64, ptr %slot142, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %rgep903 = getelementptr i8, ptr %p902, i64 -24
  store i64 %v900, ptr %rgep903, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear188
bb_rcgclear188:
  %v904 = load i64, ptr %slot138, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i64 0, ptr %p905, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone188
bb_rcgdone188:
  br label %bb_rcslotdone172
bb_rcslotowner172:
  %v906 = load i64, ptr %slot23, align 8
  store i64 %v906, ptr %slot155, align 8
  %v907 = load i64, ptr %slot138, align 8
  %p908 = inttoptr i64 %v907 to ptr
  %ld909 = load i64, ptr %p908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld909, ptr %slot156, align 8
  %v910 = load i64, ptr %slot156, align 8
  %cmp911 = icmp ne i64 %v910, 0
  %cv912 = zext i1 %cmp911 to i32
  store i32 %cv912, ptr %slot157, align 8
  %v913 = load i32, ptr %slot157, align 8
  %cv914 = zext i32 %v913 to i64
  %cond915 = icmp ne i64 %cv914, 0
  br i1 %cond915, label %bb_rcgnn203, label %bb_rcgdone203
bb_rcgnn203:
  %v916 = load i64, ptr %slot156, align 8
  %op917 = sub i64 %v916, 16
  store i64 %op917, ptr %slot158, align 8
  %v918 = load i64, ptr %slot156, align 8
  %p919 = inttoptr i64 %v918 to ptr
  %rgep920 = getelementptr i8, ptr %p919, i64 -16
  %ld921 = load i64, ptr %rgep920, align 8, !alias.scope !9, !noalias !10
  store i64 %ld921, ptr %slot159, align 8
  %v922 = load i64, ptr %slot159, align 8
  %op923 = and i64 %v922, 4611686018427387906
  store i64 %op923, ptr %slot160, align 8
  %v924 = load i64, ptr %slot160, align 8
  %cmp925 = icmp ne i64 %v924, 0
  %cv926 = zext i1 %cmp925 to i32
  store i32 %cv926, ptr %slot161, align 8
  %v927 = load i32, ptr %slot161, align 8
  %cv928 = zext i32 %v927 to i64
  %cond929 = icmp ne i64 %cv928, 0
  br i1 %cond929, label %bb_rcgclear203, label %bb_rcgcounted203
bb_rcgcounted203:
  %v930 = load i64, ptr %slot156, align 8
  %op931 = sub i64 %v930, 32
  store i64 %op931, ptr %slot162, align 8
  %v932 = load i64, ptr %slot156, align 8
  %p933 = inttoptr i64 %v932 to ptr
  %rgep934 = getelementptr i8, ptr %p933, i64 -32
  %ld935 = load i64, ptr %rgep934, align 8, !alias.scope !9, !noalias !10
  store i64 %ld935, ptr %slot163, align 8
  %v936 = load i64, ptr %slot163, align 8
  %op937 = sub i64 %v936, 1
  store i64 %op937, ptr %slot164, align 8
  %v938 = load i64, ptr %slot164, align 8
  %cmp939 = icmp eq i64 %v938, 0
  %cv940 = zext i1 %cmp939 to i32
  store i32 %cv940, ptr %slot165, align 8
  %v941 = load i32, ptr %slot165, align 8
  %cv942 = zext i32 %v941 to i64
  %cond943 = icmp ne i64 %cv942, 0
  br i1 %cond943, label %bb_rcglast203, label %bb_rcgdec203
bb_rcglast203:
  %v944 = load i64, ptr %slot156, align 8
  %op945 = sub i64 %v944, 24
  store i64 %op945, ptr %slot166, align 8
  %v946 = load i64, ptr %slot156, align 8
  %p947 = inttoptr i64 %v946 to ptr
  %rgep948 = getelementptr i8, ptr %p947, i64 -24
  %ld949 = load i64, ptr %rgep948, align 8, !alias.scope !9, !noalias !10
  store i64 %ld949, ptr %slot167, align 8
  %v950 = load i64, ptr %slot167, align 8
  %cmp951 = icmp ne i64 %v950, 0
  %cv952 = zext i1 %cmp951 to i32
  store i32 %cv952, ptr %slot168, align 8
  %v953 = load i32, ptr %slot168, align 8
  %cv954 = zext i32 %v953 to i64
  %cond955 = icmp ne i64 %cv954, 0
  br i1 %cond955, label %bb_rcgdec203, label %bb_rcgslow203
bb_rcgslow203:
  %v956 = load i64, ptr %slot155, align 8
  %v957 = load i64, ptr %slot138, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v956, i64 %v957) nomerge, !dbg !124
  br label %bb_rcgdone203
bb_rcgdec203:
  %v958 = load i64, ptr %slot164, align 8
  %v959 = load i64, ptr %slot156, align 8
  %p960 = inttoptr i64 %v959 to ptr
  %rgep961 = getelementptr i8, ptr %p960, i64 -32
  store i64 %v958, ptr %rgep961, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear203
bb_rcgclear203:
  %v962 = load i64, ptr %slot138, align 8
  %p963 = inttoptr i64 %v962 to ptr
  store i64 0, ptr %p963, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone203
bb_rcgdone203:
  br label %bb_rcslotdone172
bb_rcslotdone172:
  br label %bb_rcprivateprepared120
bb_rcprivateprepared120:
  %v964 = load i64, ptr %slot5, align 8
  %p965 = inttoptr i64 %v964 to ptr
  %ld966 = load i32, ptr %p965, align 4, !alias.scope !3, !noalias !4
  store i32 %ld966, ptr %slot169, align 8
  %v967 = load i32, ptr %slot169, align 8
  %cv968 = zext i32 %v967 to i64
  %cond969 = icmp ne i64 %cv968, 0
  br i1 %cond969, label %bb_rcslotdrop210, label %bb_rcslotdone210
bb_rcslotdrop210:
  %v970 = load i64, ptr %slot5, align 8
  %p971 = inttoptr i64 %v970 to ptr
  store i32 0, ptr %p971, align 4, !alias.scope !3, !noalias !4
  %v972 = load i64, ptr %slot16, align 8
  store i64 %v972, ptr %slot170, align 8
  %v973 = load i64, ptr %slot6, align 8
  %p974 = inttoptr i64 %v973 to ptr
  %ld975 = load i32, ptr %p974, align 4, !alias.scope !3, !noalias !4
  store i32 %ld975, ptr %slot171, align 8
  %v976 = load i32, ptr %slot171, align 8
  %op977 = and i32 %v976, 28
  store i32 %op977, ptr %slot172, align 8
  %v978 = load i32, ptr %slot172, align 8
  %cv979 = zext i32 %v978 to i64
  %cond980 = icmp ne i64 %cv979, 0
  br i1 %cond980, label %bb_rcslotrole210, label %bb_rcslotowner210
bb_rcslotrole210:
  %v981 = load i64, ptr %slot23, align 8
  store i64 %v981, ptr %slot173, align 8
  %v982 = load i64, ptr %slot170, align 8
  %p983 = inttoptr i64 %v982 to ptr
  %ld984 = load i64, ptr %p983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld984, ptr %slot174, align 8
  %v985 = load i64, ptr %slot174, align 8
  %cmp986 = icmp ne i64 %v985, 0
  %cv987 = zext i1 %cmp986 to i32
  store i32 %cv987, ptr %slot175, align 8
  %v988 = load i32, ptr %slot175, align 8
  %cv989 = zext i32 %v988 to i64
  %cond990 = icmp ne i64 %cv989, 0
  br i1 %cond990, label %bb_rcgnn226, label %bb_rcgdone226
bb_rcgnn226:
  %v991 = load i64, ptr %slot174, align 8
  %op992 = sub i64 %v991, 16
  store i64 %op992, ptr %slot176, align 8
  %v993 = load i64, ptr %slot174, align 8
  %p994 = inttoptr i64 %v993 to ptr
  %rgep995 = getelementptr i8, ptr %p994, i64 -16
  %ld996 = load i64, ptr %rgep995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld996, ptr %slot177, align 8
  %v997 = load i64, ptr %slot177, align 8
  %op998 = and i64 %v997, 4611686018427387906
  store i64 %op998, ptr %slot178, align 8
  %v999 = load i64, ptr %slot178, align 8
  %cmp1000 = icmp ne i64 %v999, 0
  %cv1001 = zext i1 %cmp1000 to i32
  store i32 %cv1001, ptr %slot179, align 8
  %v1002 = load i32, ptr %slot179, align 8
  %cv1003 = zext i32 %v1002 to i64
  %cond1004 = icmp ne i64 %cv1003, 0
  br i1 %cond1004, label %bb_rcgclear226, label %bb_rcgcounted226
bb_rcgcounted226:
  %v1005 = load i64, ptr %slot174, align 8
  %op1006 = sub i64 %v1005, 24
  store i64 %op1006, ptr %slot180, align 8
  %v1007 = load i64, ptr %slot174, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  %rgep1009 = getelementptr i8, ptr %p1008, i64 -24
  %ld1010 = load i64, ptr %rgep1009, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1010, ptr %slot181, align 8
  %v1011 = load i64, ptr %slot181, align 8
  %op1012 = sub i64 %v1011, 1
  store i64 %op1012, ptr %slot182, align 8
  %v1013 = load i64, ptr %slot182, align 8
  %cmp1014 = icmp eq i64 %v1013, 0
  %cv1015 = zext i1 %cmp1014 to i32
  store i32 %cv1015, ptr %slot183, align 8
  %v1016 = load i32, ptr %slot183, align 8
  %cv1017 = zext i32 %v1016 to i64
  %cond1018 = icmp ne i64 %cv1017, 0
  br i1 %cond1018, label %bb_rcglast226, label %bb_rcgdec226
bb_rcglast226:
  %v1019 = load i64, ptr %slot174, align 8
  %op1020 = sub i64 %v1019, 32
  store i64 %op1020, ptr %slot184, align 8
  %v1021 = load i64, ptr %slot174, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %rgep1023 = getelementptr i8, ptr %p1022, i64 -32
  %ld1024 = load i64, ptr %rgep1023, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1024, ptr %slot185, align 8
  %v1025 = load i64, ptr %slot185, align 8
  %cmp1026 = icmp ne i64 %v1025, 0
  %cv1027 = zext i1 %cmp1026 to i32
  store i32 %cv1027, ptr %slot186, align 8
  %v1028 = load i32, ptr %slot186, align 8
  %cv1029 = zext i32 %v1028 to i64
  %cond1030 = icmp ne i64 %cv1029, 0
  br i1 %cond1030, label %bb_rcgdec226, label %bb_rcgslow226
bb_rcgslow226:
  %v1031 = load i64, ptr %slot173, align 8
  %v1032 = load i64, ptr %slot170, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1031, i64 %v1032) nomerge, !dbg !124
  br label %bb_rcgdone226
bb_rcgdec226:
  %v1033 = load i64, ptr %slot182, align 8
  %v1034 = load i64, ptr %slot174, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %rgep1036 = getelementptr i8, ptr %p1035, i64 -24
  store i64 %v1033, ptr %rgep1036, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear226
bb_rcgclear226:
  %v1037 = load i64, ptr %slot170, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  store i64 0, ptr %p1038, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone226
bb_rcgdone226:
  br label %bb_rcslotdone210
bb_rcslotowner210:
  %v1039 = load i64, ptr %slot23, align 8
  store i64 %v1039, ptr %slot187, align 8
  %v1040 = load i64, ptr %slot170, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %ld1042 = load i64, ptr %p1041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1042, ptr %slot188, align 8
  %v1043 = load i64, ptr %slot188, align 8
  %cmp1044 = icmp ne i64 %v1043, 0
  %cv1045 = zext i1 %cmp1044 to i32
  store i32 %cv1045, ptr %slot189, align 8
  %v1046 = load i32, ptr %slot189, align 8
  %cv1047 = zext i32 %v1046 to i64
  %cond1048 = icmp ne i64 %cv1047, 0
  br i1 %cond1048, label %bb_rcgnn241, label %bb_rcgdone241
bb_rcgnn241:
  %v1049 = load i64, ptr %slot188, align 8
  %op1050 = sub i64 %v1049, 16
  store i64 %op1050, ptr %slot190, align 8
  %v1051 = load i64, ptr %slot188, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %rgep1053 = getelementptr i8, ptr %p1052, i64 -16
  %ld1054 = load i64, ptr %rgep1053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1054, ptr %slot191, align 8
  %v1055 = load i64, ptr %slot191, align 8
  %op1056 = and i64 %v1055, 4611686018427387906
  store i64 %op1056, ptr %slot192, align 8
  %v1057 = load i64, ptr %slot192, align 8
  %cmp1058 = icmp ne i64 %v1057, 0
  %cv1059 = zext i1 %cmp1058 to i32
  store i32 %cv1059, ptr %slot193, align 8
  %v1060 = load i32, ptr %slot193, align 8
  %cv1061 = zext i32 %v1060 to i64
  %cond1062 = icmp ne i64 %cv1061, 0
  br i1 %cond1062, label %bb_rcgclear241, label %bb_rcgcounted241
bb_rcgcounted241:
  %v1063 = load i64, ptr %slot188, align 8
  %op1064 = sub i64 %v1063, 32
  store i64 %op1064, ptr %slot194, align 8
  %v1065 = load i64, ptr %slot188, align 8
  %p1066 = inttoptr i64 %v1065 to ptr
  %rgep1067 = getelementptr i8, ptr %p1066, i64 -32
  %ld1068 = load i64, ptr %rgep1067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1068, ptr %slot195, align 8
  %v1069 = load i64, ptr %slot195, align 8
  %op1070 = sub i64 %v1069, 1
  store i64 %op1070, ptr %slot196, align 8
  %v1071 = load i64, ptr %slot196, align 8
  %cmp1072 = icmp eq i64 %v1071, 0
  %cv1073 = zext i1 %cmp1072 to i32
  store i32 %cv1073, ptr %slot197, align 8
  %v1074 = load i32, ptr %slot197, align 8
  %cv1075 = zext i32 %v1074 to i64
  %cond1076 = icmp ne i64 %cv1075, 0
  br i1 %cond1076, label %bb_rcglast241, label %bb_rcgdec241
bb_rcglast241:
  %v1077 = load i64, ptr %slot188, align 8
  %op1078 = sub i64 %v1077, 24
  store i64 %op1078, ptr %slot198, align 8
  %v1079 = load i64, ptr %slot188, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  %rgep1081 = getelementptr i8, ptr %p1080, i64 -24
  %ld1082 = load i64, ptr %rgep1081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1082, ptr %slot199, align 8
  %v1083 = load i64, ptr %slot199, align 8
  %cmp1084 = icmp ne i64 %v1083, 0
  %cv1085 = zext i1 %cmp1084 to i32
  store i32 %cv1085, ptr %slot200, align 8
  %v1086 = load i32, ptr %slot200, align 8
  %cv1087 = zext i32 %v1086 to i64
  %cond1088 = icmp ne i64 %cv1087, 0
  br i1 %cond1088, label %bb_rcgdec241, label %bb_rcgslow241
bb_rcgslow241:
  %v1089 = load i64, ptr %slot187, align 8
  %v1090 = load i64, ptr %slot170, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1089, i64 %v1090) nomerge, !dbg !124
  br label %bb_rcgdone241
bb_rcgdec241:
  %v1091 = load i64, ptr %slot196, align 8
  %v1092 = load i64, ptr %slot188, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %rgep1094 = getelementptr i8, ptr %p1093, i64 -32
  store i64 %v1091, ptr %rgep1094, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear241
bb_rcgclear241:
  %v1095 = load i64, ptr %slot170, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  store i64 0, ptr %p1096, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone241
bb_rcgdone241:
  br label %bb_rcslotdone210
bb_rcslotdone210:
  %v1097 = load i64, ptr %slot16, align 8
  store i64 %v1097, ptr %slot201, align 8
  %v1098 = load i64, ptr %slot13, align 8
  store i64 %v1098, ptr %slot202, align 8
  %v1099 = load i64, ptr %slot202, align 8
  %v1100 = load i64, ptr %slot201, align 8
  %p1101 = inttoptr i64 %v1099 to ptr
  %p1102 = inttoptr i64 %v1100 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1102, ptr %p1101, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1103 = load i64, ptr %slot9, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  store i32 0, ptr %p1104, align 4, !alias.scope !3, !noalias !4
  %v1105 = load i64, ptr %slot6, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  store i32 2, ptr %p1106, align 4, !alias.scope !3, !noalias !4
  %v1107 = load i64, ptr %slot10, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  %ld1109 = load i32, ptr %p1108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1109, ptr %slot203, align 8
  %v1110 = load i32, ptr %slot203, align 8
  %v1111 = load i64, ptr %slot6, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i32 %v1110, ptr %p1112, align 4, !alias.scope !3, !noalias !4
  %v1113 = load i64, ptr %slot5, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  store i32 1, ptr %p1114, align 4, !alias.scope !3, !noalias !4
  %v1115 = load i64, ptr %slot16, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  %ld1117 = load i64, ptr %p1116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1117, ptr %slot204, align 8
  %v1118 = load i64, ptr %slot204, align 8
  %op1119 = add i64 %v1118, 0
  store i64 %op1119, ptr %slot205, align 8
  %v1120 = load i64, ptr %slot205, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  %ld1122 = load i64, ptr %p1121, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1122, ptr %slot206, align 8
  %v1123 = load i64, ptr %slot206, align 8
  %v1124 = load i64, ptr %slot17, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  store i64 %v1123, ptr %p1125, align 8, !alias.scope !3, !noalias !4
  %v1126 = load i64, ptr %slot17, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  %ld1128 = load i64, ptr %p1127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1128, ptr %slot207, align 8
  %v1129 = load i64, ptr %slot207, align 8
  %cmp1130 = icmp ugt i64 %v1129, 9223372036854775807
  %cv1131 = zext i1 %cmp1130 to i64
  store i64 %cv1131, ptr %slot208, align 8
  %v1132 = load i64, ptr %slot208, align 8
  %cond1133 = icmp ne i64 %v1132, 0
  br i1 %cond1133, label %bb_cast_overflow257, label %bb_cast_ok257
bb_cast_overflow257:
  %v1134 = load i64, ptr %slot1, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  %v1136 = load i64, ptr %slot207, align 8
  call void @myl_qbe_fail_cast(ptr %p1135, i64 %v1136, i64 320) nomerge, !dbg !126
  unreachable
bb_cast_ok257:
  %v1137 = load i64, ptr %slot207, align 8
  %v1138 = load i64, ptr %slot17, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i64 %v1137, ptr %p1139, align 8, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot18, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i64 2, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot18, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %ld1144 = load i64, ptr %p1143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1144, ptr %slot209, align 8
  %v1145 = load i64, ptr %slot17, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  %ld1147 = load i64, ptr %p1146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1147, ptr %slot210, align 8
  %v1148 = load i64, ptr %slot210, align 8
  %v1149 = load i64, ptr %slot209, align 8
  %op1150 = sub i64 %v1148, %v1149
  store i64 %op1150, ptr %slot211, align 8
  %v1151 = load i64, ptr %slot210, align 8
  %cmp1152 = icmp slt i64 %v1151, 9223372036854775810
  %cv1153 = zext i1 %cmp1152 to i64
  store i64 %cv1153, ptr %slot212, align 8
  %v1154 = load i64, ptr %slot212, align 8
  %cond1155 = icmp ne i64 %v1154, 0
  br i1 %cond1155, label %bb_overflow260, label %bb_checked260
bb_overflow260:
  %v1156 = load i64, ptr %slot1, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %v1158 = load i64, ptr %slot210, align 8
  %v1159 = load i64, ptr %slot209, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1157, i64 1, i64 %v1158, i64 %v1159, i64 64) nomerge, !dbg !128
  unreachable
bb_checked260:
  %v1160 = load i64, ptr %slot211, align 8
  %v1161 = load i64, ptr %slot17, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  store i64 %v1160, ptr %p1162, align 8, !alias.scope !3, !noalias !4
  %v1163 = load i64, ptr %slot17, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %ld1165 = load i64, ptr %p1164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1165, ptr %slot213, align 8
  %v1166 = load i64, ptr %slot7, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  %ld1168 = load i32, ptr %p1167, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1168, ptr %slot214, align 8
  %v1169 = load i32, ptr %slot214, align 8
  %cv1170 = zext i32 %v1169 to i64
  %cond1171 = icmp ne i64 %cv1170, 0
  br i1 %cond1171, label %bb_rcslotdrop265, label %bb_rcslotdone265
bb_rcslotdrop265:
  %v1172 = load i64, ptr %slot7, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i32 0, ptr %p1173, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone265
bb_rcslotdone265:
  %v1174 = load i64, ptr %slot5, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %ld1176 = load i32, ptr %p1175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1176, ptr %slot215, align 8
  %v1177 = load i32, ptr %slot215, align 8
  %cv1178 = zext i32 %v1177 to i64
  %cond1179 = icmp ne i64 %cv1178, 0
  br i1 %cond1179, label %bb_rcslotdrop268, label %bb_rcslotdone268
bb_rcslotdrop268:
  %v1180 = load i64, ptr %slot5, align 8
  %p1181 = inttoptr i64 %v1180 to ptr
  store i32 0, ptr %p1181, align 4, !alias.scope !3, !noalias !4
  %v1182 = load i64, ptr %slot16, align 8
  store i64 %v1182, ptr %slot216, align 8
  %v1183 = load i64, ptr %slot6, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %ld1185 = load i32, ptr %p1184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1185, ptr %slot217, align 8
  %v1186 = load i32, ptr %slot217, align 8
  %op1187 = and i32 %v1186, 28
  store i32 %op1187, ptr %slot218, align 8
  %v1188 = load i32, ptr %slot218, align 8
  %cv1189 = zext i32 %v1188 to i64
  %cond1190 = icmp ne i64 %cv1189, 0
  br i1 %cond1190, label %bb_rcslotrole268, label %bb_rcslotowner268
bb_rcslotrole268:
  %v1191 = load i64, ptr %slot23, align 8
  store i64 %v1191, ptr %slot219, align 8
  %v1192 = load i64, ptr %slot216, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  %ld1194 = load i64, ptr %p1193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1194, ptr %slot220, align 8
  %v1195 = load i64, ptr %slot220, align 8
  %cmp1196 = icmp ne i64 %v1195, 0
  %cv1197 = zext i1 %cmp1196 to i32
  store i32 %cv1197, ptr %slot221, align 8
  %v1198 = load i32, ptr %slot221, align 8
  %cv1199 = zext i32 %v1198 to i64
  %cond1200 = icmp ne i64 %cv1199, 0
  br i1 %cond1200, label %bb_rcgnn284, label %bb_rcgdone284
bb_rcgnn284:
  %v1201 = load i64, ptr %slot220, align 8
  %op1202 = sub i64 %v1201, 16
  store i64 %op1202, ptr %slot222, align 8
  %v1203 = load i64, ptr %slot220, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  %rgep1205 = getelementptr i8, ptr %p1204, i64 -16
  %ld1206 = load i64, ptr %rgep1205, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1206, ptr %slot223, align 8
  %v1207 = load i64, ptr %slot223, align 8
  %op1208 = and i64 %v1207, 4611686018427387906
  store i64 %op1208, ptr %slot224, align 8
  %v1209 = load i64, ptr %slot224, align 8
  %cmp1210 = icmp ne i64 %v1209, 0
  %cv1211 = zext i1 %cmp1210 to i32
  store i32 %cv1211, ptr %slot225, align 8
  %v1212 = load i32, ptr %slot225, align 8
  %cv1213 = zext i32 %v1212 to i64
  %cond1214 = icmp ne i64 %cv1213, 0
  br i1 %cond1214, label %bb_rcgclear284, label %bb_rcgcounted284
bb_rcgcounted284:
  %v1215 = load i64, ptr %slot220, align 8
  %op1216 = sub i64 %v1215, 24
  store i64 %op1216, ptr %slot226, align 8
  %v1217 = load i64, ptr %slot220, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  %rgep1219 = getelementptr i8, ptr %p1218, i64 -24
  %ld1220 = load i64, ptr %rgep1219, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1220, ptr %slot227, align 8
  %v1221 = load i64, ptr %slot227, align 8
  %op1222 = sub i64 %v1221, 1
  store i64 %op1222, ptr %slot228, align 8
  %v1223 = load i64, ptr %slot228, align 8
  %cmp1224 = icmp eq i64 %v1223, 0
  %cv1225 = zext i1 %cmp1224 to i32
  store i32 %cv1225, ptr %slot229, align 8
  %v1226 = load i32, ptr %slot229, align 8
  %cv1227 = zext i32 %v1226 to i64
  %cond1228 = icmp ne i64 %cv1227, 0
  br i1 %cond1228, label %bb_rcglast284, label %bb_rcgdec284
bb_rcglast284:
  %v1229 = load i64, ptr %slot220, align 8
  %op1230 = sub i64 %v1229, 32
  store i64 %op1230, ptr %slot230, align 8
  %v1231 = load i64, ptr %slot220, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  %rgep1233 = getelementptr i8, ptr %p1232, i64 -32
  %ld1234 = load i64, ptr %rgep1233, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1234, ptr %slot231, align 8
  %v1235 = load i64, ptr %slot231, align 8
  %cmp1236 = icmp ne i64 %v1235, 0
  %cv1237 = zext i1 %cmp1236 to i32
  store i32 %cv1237, ptr %slot232, align 8
  %v1238 = load i32, ptr %slot232, align 8
  %cv1239 = zext i32 %v1238 to i64
  %cond1240 = icmp ne i64 %cv1239, 0
  br i1 %cond1240, label %bb_rcgdec284, label %bb_rcgslow284
bb_rcgslow284:
  %v1241 = load i64, ptr %slot219, align 8
  %v1242 = load i64, ptr %slot216, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1241, i64 %v1242) nomerge, !dbg !130
  br label %bb_rcgdone284
bb_rcgdec284:
  %v1243 = load i64, ptr %slot228, align 8
  %v1244 = load i64, ptr %slot220, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %rgep1246 = getelementptr i8, ptr %p1245, i64 -24
  store i64 %v1243, ptr %rgep1246, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear284
bb_rcgclear284:
  %v1247 = load i64, ptr %slot216, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  store i64 0, ptr %p1248, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone284
bb_rcgdone284:
  br label %bb_rcslotdone268
bb_rcslotowner268:
  %v1249 = load i64, ptr %slot23, align 8
  store i64 %v1249, ptr %slot233, align 8
  %v1250 = load i64, ptr %slot216, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  %ld1252 = load i64, ptr %p1251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1252, ptr %slot234, align 8
  %v1253 = load i64, ptr %slot234, align 8
  %cmp1254 = icmp ne i64 %v1253, 0
  %cv1255 = zext i1 %cmp1254 to i32
  store i32 %cv1255, ptr %slot235, align 8
  %v1256 = load i32, ptr %slot235, align 8
  %cv1257 = zext i32 %v1256 to i64
  %cond1258 = icmp ne i64 %cv1257, 0
  br i1 %cond1258, label %bb_rcgnn299, label %bb_rcgdone299
bb_rcgnn299:
  %v1259 = load i64, ptr %slot234, align 8
  %op1260 = sub i64 %v1259, 16
  store i64 %op1260, ptr %slot236, align 8
  %v1261 = load i64, ptr %slot234, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %rgep1263 = getelementptr i8, ptr %p1262, i64 -16
  %ld1264 = load i64, ptr %rgep1263, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1264, ptr %slot237, align 8
  %v1265 = load i64, ptr %slot237, align 8
  %op1266 = and i64 %v1265, 4611686018427387906
  store i64 %op1266, ptr %slot238, align 8
  %v1267 = load i64, ptr %slot238, align 8
  %cmp1268 = icmp ne i64 %v1267, 0
  %cv1269 = zext i1 %cmp1268 to i32
  store i32 %cv1269, ptr %slot239, align 8
  %v1270 = load i32, ptr %slot239, align 8
  %cv1271 = zext i32 %v1270 to i64
  %cond1272 = icmp ne i64 %cv1271, 0
  br i1 %cond1272, label %bb_rcgclear299, label %bb_rcgcounted299
bb_rcgcounted299:
  %v1273 = load i64, ptr %slot234, align 8
  %op1274 = sub i64 %v1273, 32
  store i64 %op1274, ptr %slot240, align 8
  %v1275 = load i64, ptr %slot234, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  %rgep1277 = getelementptr i8, ptr %p1276, i64 -32
  %ld1278 = load i64, ptr %rgep1277, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1278, ptr %slot241, align 8
  %v1279 = load i64, ptr %slot241, align 8
  %op1280 = sub i64 %v1279, 1
  store i64 %op1280, ptr %slot242, align 8
  %v1281 = load i64, ptr %slot242, align 8
  %cmp1282 = icmp eq i64 %v1281, 0
  %cv1283 = zext i1 %cmp1282 to i32
  store i32 %cv1283, ptr %slot243, align 8
  %v1284 = load i32, ptr %slot243, align 8
  %cv1285 = zext i32 %v1284 to i64
  %cond1286 = icmp ne i64 %cv1285, 0
  br i1 %cond1286, label %bb_rcglast299, label %bb_rcgdec299
bb_rcglast299:
  %v1287 = load i64, ptr %slot234, align 8
  %op1288 = sub i64 %v1287, 24
  store i64 %op1288, ptr %slot244, align 8
  %v1289 = load i64, ptr %slot234, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  %rgep1291 = getelementptr i8, ptr %p1290, i64 -24
  %ld1292 = load i64, ptr %rgep1291, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1292, ptr %slot245, align 8
  %v1293 = load i64, ptr %slot245, align 8
  %cmp1294 = icmp ne i64 %v1293, 0
  %cv1295 = zext i1 %cmp1294 to i32
  store i32 %cv1295, ptr %slot246, align 8
  %v1296 = load i32, ptr %slot246, align 8
  %cv1297 = zext i32 %v1296 to i64
  %cond1298 = icmp ne i64 %cv1297, 0
  br i1 %cond1298, label %bb_rcgdec299, label %bb_rcgslow299
bb_rcgslow299:
  %v1299 = load i64, ptr %slot233, align 8
  %v1300 = load i64, ptr %slot216, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1299, i64 %v1300) nomerge, !dbg !130
  br label %bb_rcgdone299
bb_rcgdec299:
  %v1301 = load i64, ptr %slot242, align 8
  %v1302 = load i64, ptr %slot234, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  %rgep1304 = getelementptr i8, ptr %p1303, i64 -32
  store i64 %v1301, ptr %rgep1304, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear299
bb_rcgclear299:
  %v1305 = load i64, ptr %slot216, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  store i64 0, ptr %p1306, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone299
bb_rcgdone299:
  br label %bb_rcslotdone268
bb_rcslotdone268:
  %v1307 = load i64, ptr %slot213, align 8
  ret i64 %v1307
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8, i64, i64)
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd", linkageName: "myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14841311613465104692, i64 0, !"myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!118 = !DILocation(line: 11, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!122 = !DILocation(line: 15, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!128 = !DILocation(line: 20, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!130 = !DILocation(line: 21, column: 0, scope: !131)
