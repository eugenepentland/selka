target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_cbe1707b21afebc3b90c5909fa922f058c733c160a519833fe605ca52599fb91(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v13 = load i64, ptr %slot1, align 8
  %op14 = add i64 %v13, 32
  store i64 %op14, ptr %slot3, align 8
  %mem15 = alloca i8, i64 8, align 8
  %ptr16 = ptrtoint ptr %mem15 to i64
  store i64 %ptr16, ptr %slot4, align 8
  %mem17 = alloca i8, i64 8, align 8
  %ptr18 = ptrtoint ptr %mem17 to i64
  store i64 %ptr18, ptr %slot5, align 8
  %mem19 = alloca i8, i64 8, align 8
  %ptr20 = ptrtoint ptr %mem19 to i64
  store i64 %ptr20, ptr %slot6, align 8
  %mem21 = alloca i8, i64 8, align 8
  %ptr22 = ptrtoint ptr %mem21 to i64
  store i64 %ptr22, ptr %slot7, align 8
  %v23 = load i64, ptr %slot2, align 8
  %v24 = load i64, ptr %slot5, align 8
  %p25 = inttoptr i64 %v24 to ptr
  store i64 %v23, ptr %p25, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v26 = load i64, ptr %slot5, align 8
  %p27 = inttoptr i64 %v26 to ptr
  %ld28 = load i64, ptr %p27, align 8, !alias.scope !3, !noalias !4
  store i64 %ld28, ptr %slot8, align 8
  %v29 = load i64, ptr %slot8, align 8
  %v30 = load i64, ptr %slot6, align 8
  %p31 = inttoptr i64 %v30 to ptr
  store i64 %v29, ptr %p31, align 8, !alias.scope !3, !noalias !4
  %v32 = load i64, ptr %slot7, align 8
  store i64 %v32, ptr %slot9, align 8
  %v33 = load i64, ptr %slot9, align 8
  %p35 = inttoptr i64 %v33 to ptr
  %gep36 = getelementptr i8, ptr %p35, i64 0
  %op34 = ptrtoint ptr %gep36 to i64
  store i64 %op34, ptr %slot10, align 8
  %v37 = load i64, ptr %slot6, align 8
  %p38 = inttoptr i64 %v37 to ptr
  %ld39 = load i64, ptr %p38, align 8, !alias.scope !3, !noalias !4
  store i64 %ld39, ptr %slot11, align 8
  %v40 = load i64, ptr %slot11, align 8
  %v41 = load i64, ptr %slot10, align 8
  %p42 = inttoptr i64 %v41 to ptr
  store i64 %v40, ptr %p42, align 8, !alias.scope !3, !noalias !4
  %v43 = load i64, ptr %slot9, align 8
  %v44 = load i64, ptr %slot6, align 8
  %p45 = inttoptr i64 %v44 to ptr
  store i64 %v43, ptr %p45, align 8, !alias.scope !3, !noalias !4
  %v46 = load i64, ptr %slot6, align 8
  %p47 = inttoptr i64 %v46 to ptr
  %ld48 = load i64, ptr %p47, align 8, !alias.scope !3, !noalias !4
  store i64 %ld48, ptr %slot12, align 8
  %v49 = load i64, ptr %slot12, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ret51 = load i64, ptr %p50, align 8
  ret i64 %ret51
bb_failure:
  %v52 = load i64, ptr %slot4, align 8
  %p53 = inttoptr i64 %v52 to ptr
  call void @llvm.memset.p0.i64(ptr %p53, i8 0, i64 8, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v54 = load i64, ptr %slot4, align 8
  %p55 = inttoptr i64 %v54 to ptr
  %ret56 = load i64, ptr %p55, align 8
  ret i64 %ret56
bb_entry_failure:
  %v57 = load i64, ptr %slot4, align 8
  %p58 = inttoptr i64 %v57 to ptr
  call void @llvm.memset.p0.i64(ptr %p58, i8 0, i64 8, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v59 = load i64, ptr %slot4, align 8
  %p60 = inttoptr i64 %v59 to ptr
  %ret61 = load i64, ptr %p60, align 8
  ret i64 %ret61
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_cbe1707b21afebc3b90c5909fa922f058c733c160a519833fe605ca52599fb91", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_cbe1707b21afebc3b90c5909fa922f058c733c160a519833fe605ca52599fb91", linkageName: "myl_f_cbe1707b21afebc3b90c5909fa922f058c733c160a519833fe605ca52599fb91", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8903491840482712900, i64 0, !"myl_f_cbe1707b21afebc3b90c5909fa922f058c733c160a519833fe605ca52599fb91"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
