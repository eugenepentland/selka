target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_8a26e9a4615ca34682c5764acec261356b4869f23d43f0849ec12dd016904162(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %callresult68 = alloca [16 x i8], align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %callresult80 = alloca [24 x i8], align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %callresult191 = alloca [16 x i8], align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %callresult207 = alloca [16 x i8], align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %callresult222 = alloca [24 x i8], align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i32, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %callresult877 = alloca [16 x i8], align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v919 = load i64, ptr %slot1, align 8
  %op920 = add i64 %v919, 32
  store i64 %op920, ptr %slot4, align 8
  %mem921 = alloca i8, i64 8, align 8
  %ptr922 = ptrtoint ptr %mem921 to i64
  store i64 %ptr922, ptr %slot5, align 8
  %mem923 = alloca i8, i64 8, align 8
  %ptr924 = ptrtoint ptr %mem923 to i64
  store i64 %ptr924, ptr %slot6, align 8
  %mem925 = alloca i8, i64 8, align 8
  %ptr926 = ptrtoint ptr %mem925 to i64
  store i64 %ptr926, ptr %slot7, align 8
  %mem927 = alloca i8, i64 8, align 8
  %ptr928 = ptrtoint ptr %mem927 to i64
  store i64 %ptr928, ptr %slot8, align 8
  %mem929 = alloca i8, i64 8, align 8
  %ptr930 = ptrtoint ptr %mem929 to i64
  store i64 %ptr930, ptr %slot9, align 8
  %mem931 = alloca i8, i64 8, align 8
  %ptr932 = ptrtoint ptr %mem931 to i64
  store i64 %ptr932, ptr %slot10, align 8
  %mem933 = alloca i8, i64 8, align 8
  %ptr934 = ptrtoint ptr %mem933 to i64
  store i64 %ptr934, ptr %slot11, align 8
  %mem935 = alloca i8, i64 8, align 8
  %ptr936 = ptrtoint ptr %mem935 to i64
  store i64 %ptr936, ptr %slot12, align 8
  %mem937 = alloca i8, i64 8, align 8
  %ptr938 = ptrtoint ptr %mem937 to i64
  store i64 %ptr938, ptr %slot13, align 8
  %mem939 = alloca i8, i64 8, align 8
  %ptr940 = ptrtoint ptr %mem939 to i64
  store i64 %ptr940, ptr %slot14, align 8
  %mem941 = alloca i8, i64 8, align 8
  %ptr942 = ptrtoint ptr %mem941 to i64
  store i64 %ptr942, ptr %slot15, align 8
  %mem943 = alloca i8, i64 8, align 8
  %ptr944 = ptrtoint ptr %mem943 to i64
  store i64 %ptr944, ptr %slot16, align 8
  %mem945 = alloca i8, i64 8, align 8
  %ptr946 = ptrtoint ptr %mem945 to i64
  store i64 %ptr946, ptr %slot17, align 8
  %mem947 = alloca i8, i64 8, align 8
  %ptr948 = ptrtoint ptr %mem947 to i64
  store i64 %ptr948, ptr %slot18, align 8
  %mem949 = alloca i8, i64 8, align 8
  %ptr950 = ptrtoint ptr %mem949 to i64
  store i64 %ptr950, ptr %slot19, align 8
  %mem951 = alloca i8, i64 8, align 8
  %ptr952 = ptrtoint ptr %mem951 to i64
  store i64 %ptr952, ptr %slot20, align 8
  %mem953 = alloca i8, i64 8, align 8
  %ptr954 = ptrtoint ptr %mem953 to i64
  store i64 %ptr954, ptr %slot21, align 8
  %mem955 = alloca i8, i64 208, align 8
  %ptr956 = ptrtoint ptr %mem955 to i64
  store i64 %ptr956, ptr %slot22, align 8
  %mem957 = alloca i8, i64 208, align 8
  %ptr958 = ptrtoint ptr %mem957 to i64
  store i64 %ptr958, ptr %slot23, align 8
  %mem959 = alloca i8, i64 208, align 8
  %ptr960 = ptrtoint ptr %mem959 to i64
  store i64 %ptr960, ptr %slot24, align 8
  %mem961 = alloca i8, i64 32, align 8
  %ptr962 = ptrtoint ptr %mem961 to i64
  store i64 %ptr962, ptr %slot25, align 8
  %v963 = load i64, ptr %slot25, align 8
  %p965 = inttoptr i64 %v963 to ptr
  %gep966 = getelementptr i8, ptr %p965, i64 24
  %op964 = ptrtoint ptr %gep966 to i64
  store i64 %op964, ptr %slot26, align 8
  %v967 = load i64, ptr %slot26, align 8
  %p968 = inttoptr i64 %v967 to ptr
  store i64 0, ptr %p968, align 8, !alias.scope !3, !noalias !4
  %mem969 = alloca i8, i64 8, align 8
  %ptr970 = ptrtoint ptr %mem969 to i64
  store i64 %ptr970, ptr %slot27, align 8
  %mem971 = alloca i8, i64 8, align 8
  %ptr972 = ptrtoint ptr %mem971 to i64
  store i64 %ptr972, ptr %slot28, align 8
  %mem973 = alloca i8, i64 8, align 8
  %ptr974 = ptrtoint ptr %mem973 to i64
  store i64 %ptr974, ptr %slot29, align 8
  %mem975 = alloca i8, i64 8, align 8
  %ptr976 = ptrtoint ptr %mem975 to i64
  store i64 %ptr976, ptr %slot30, align 8
  %mem977 = alloca i8, i64 16, align 8
  %ptr978 = ptrtoint ptr %mem977 to i64
  store i64 %ptr978, ptr %slot31, align 8
  %mem979 = alloca i8, i64 8, align 8
  %ptr980 = ptrtoint ptr %mem979 to i64
  store i64 %ptr980, ptr %slot32, align 8
  %mem981 = alloca i8, i64 24, align 8
  %ptr982 = ptrtoint ptr %mem981 to i64
  store i64 %ptr982, ptr %slot33, align 8
  %mem983 = alloca i8, i64 24, align 8
  %ptr984 = ptrtoint ptr %mem983 to i64
  store i64 %ptr984, ptr %slot34, align 8
  %mem985 = alloca i8, i64 16, align 8
  %ptr986 = ptrtoint ptr %mem985 to i64
  store i64 %ptr986, ptr %slot35, align 8
  %mem987 = alloca i8, i64 8, align 8
  %ptr988 = ptrtoint ptr %mem987 to i64
  store i64 %ptr988, ptr %slot36, align 8
  %mem989 = alloca i8, i64 56, align 8
  %ptr990 = ptrtoint ptr %mem989 to i64
  store i64 %ptr990, ptr %slot37, align 8
  %mem991 = alloca i8, i64 8, align 8
  %ptr992 = ptrtoint ptr %mem991 to i64
  store i64 %ptr992, ptr %slot38, align 8
  %mem993 = alloca i8, i64 8, align 8
  %ptr994 = ptrtoint ptr %mem993 to i64
  store i64 %ptr994, ptr %slot39, align 8
  %mem995 = alloca i8, i64 8, align 8
  %ptr996 = ptrtoint ptr %mem995 to i64
  store i64 %ptr996, ptr %slot40, align 8
  %mem997 = alloca i8, i64 8, align 8
  %ptr998 = ptrtoint ptr %mem997 to i64
  store i64 %ptr998, ptr %slot41, align 8
  %mem999 = alloca i8, i64 8, align 8
  %ptr1000 = ptrtoint ptr %mem999 to i64
  store i64 %ptr1000, ptr %slot42, align 8
  %mem1001 = alloca i8, i64 8, align 8
  %ptr1002 = ptrtoint ptr %mem1001 to i64
  store i64 %ptr1002, ptr %slot43, align 8
  %mem1003 = alloca i8, i64 24, align 8
  %ptr1004 = ptrtoint ptr %mem1003 to i64
  store i64 %ptr1004, ptr %slot44, align 8
  %mem1005 = alloca i8, i64 56, align 8
  %ptr1006 = ptrtoint ptr %mem1005 to i64
  store i64 %ptr1006, ptr %slot45, align 8
  %mem1007 = alloca i8, i64 56, align 8
  %ptr1008 = ptrtoint ptr %mem1007 to i64
  store i64 %ptr1008, ptr %slot46, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem1009 = alloca i8, i64 8, align 8
  %ptr1010 = ptrtoint ptr %mem1009 to i64
  store i64 %ptr1010, ptr %slot47, align 8
  %v1011 = load i64, ptr %slot1, align 8
  %op1012 = add i64 %v1011, 64
  store i64 %op1012, ptr %slot48, align 8
  %v1013 = load i64, ptr %slot48, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  %ld1015 = load i64, ptr %p1014, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1015, ptr %slot49, align 8
  %stack1016 = call ptr @llvm.stacksave()
  %stackaddr1017 = ptrtoint ptr %stack1016 to i64
  %v1018 = load i64, ptr %slot49, align 8
  %cmp1019 = icmp ult i64 %stackaddr1017, %v1018
  %cv1020 = zext i1 %cmp1019 to i64
  store i64 %cv1020, ptr %slot50, align 8
  %v1021 = load i64, ptr %slot50, align 8
  %cond1022 = icmp ne i64 %v1021, 0
  br i1 %cond1022, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v1023 = load i64, ptr %slot1, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  call void @myl_qbe_fail_frame(ptr %p1024) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %v1025 = load i64, ptr %slot36, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  store i64 0, ptr %p1026, align 8, !alias.scope !3, !noalias !4
  %v1027 = load i64, ptr %slot2, align 8
  %v1028 = load i64, ptr %slot28, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  store i64 %v1027, ptr %p1029, align 8, !alias.scope !3, !noalias !4
  %v1030 = load i64, ptr %slot3, align 8
  %v1031 = load i64, ptr %slot29, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  store i64 %v1030, ptr %p1032, align 8, !alias.scope !3, !noalias !4
  %v1033 = load i64, ptr %slot1, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  %call1035 = call ptr @myl_qbe_heap(ptr %p1034) nomerge, !dbg !112
  %calladdr1036 = ptrtoint ptr %call1035 to i64
  store i64 %calladdr1036, ptr %slot51, align 8
  %v1037 = load i64, ptr %slot1, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  %call1039 = call i64 @myl_qbe_region_mark(ptr %p1038) nomerge, !dbg !112
  store i64 %call1039, ptr %slot52, align 8
  %v1040 = load i64, ptr %slot5, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  store i32 0, ptr %p1041, align 4, !alias.scope !3, !noalias !4
  %v1042 = load i64, ptr %slot6, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  store i32 0, ptr %p1043, align 4, !alias.scope !3, !noalias !4
  %v1044 = load i64, ptr %slot7, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i32 0, ptr %p1045, align 4, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot8, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  store i32 0, ptr %p1047, align 4, !alias.scope !3, !noalias !4
  %v1048 = load i64, ptr %slot9, align 8
  %p1049 = inttoptr i64 %v1048 to ptr
  store i32 0, ptr %p1049, align 4, !alias.scope !3, !noalias !4
  %v1050 = load i64, ptr %slot10, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  store i32 0, ptr %p1051, align 4, !alias.scope !3, !noalias !4
  %v1052 = load i64, ptr %slot11, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  store i32 0, ptr %p1053, align 4, !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot12, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  store i32 0, ptr %p1055, align 4, !alias.scope !3, !noalias !4
  %v1056 = load i64, ptr %slot13, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  store i32 0, ptr %p1057, align 4, !alias.scope !3, !noalias !4
  %v1058 = load i64, ptr %slot14, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  store i32 0, ptr %p1059, align 4, !alias.scope !3, !noalias !4
  %v1060 = load i64, ptr %slot15, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  store i32 0, ptr %p1061, align 4, !alias.scope !3, !noalias !4
  %v1062 = load i64, ptr %slot16, align 8
  %p1063 = inttoptr i64 %v1062 to ptr
  store i32 0, ptr %p1063, align 4, !alias.scope !3, !noalias !4
  %v1064 = load i64, ptr %slot17, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  store i32 0, ptr %p1065, align 4, !alias.scope !3, !noalias !4
  %v1066 = load i64, ptr %slot18, align 8
  %p1067 = inttoptr i64 %v1066 to ptr
  store i32 0, ptr %p1067, align 4, !alias.scope !3, !noalias !4
  %v1068 = load i64, ptr %slot19, align 8
  %p1069 = inttoptr i64 %v1068 to ptr
  store i32 0, ptr %p1069, align 4, !alias.scope !3, !noalias !4
  %v1070 = load i64, ptr %slot20, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  store i32 0, ptr %p1071, align 4, !alias.scope !3, !noalias !4
  %v1072 = load i64, ptr %slot21, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  store i32 0, ptr %p1073, align 4, !alias.scope !3, !noalias !4
  %v1074 = load i64, ptr %slot6, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  store i32 2, ptr %p1075, align 4, !alias.scope !3, !noalias !4
  %v1076 = load i64, ptr %slot8, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  store i32 2, ptr %p1077, align 4, !alias.scope !3, !noalias !4
  %v1078 = load i64, ptr %slot10, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  store i32 2, ptr %p1079, align 4, !alias.scope !3, !noalias !4
  %v1080 = load i64, ptr %slot12, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  store i32 2, ptr %p1081, align 4, !alias.scope !3, !noalias !4
  %v1082 = load i64, ptr %slot14, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  store i32 2, ptr %p1083, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1084 = load i64, ptr %slot29, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %ld1086 = load i64, ptr %p1085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1086, ptr %slot53, align 8
  %v1087 = load i64, ptr %slot53, align 8
  %v1088 = load i64, ptr %slot39, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  store i64 %v1087, ptr %p1089, align 8, !alias.scope !3, !noalias !4
  %v1090 = load i64, ptr %slot39, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  %ld1092 = load i64, ptr %p1091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1092, ptr %slot54, align 8
  %v1093 = load i64, ptr %slot1, align 8
  %v1094 = load i64, ptr %slot54, align 8
  %call1095 = call i64 @myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d(i64 %v1093, i64 %v1094) nomerge, !dbg !114
  store i64 %call1095, ptr %slot55, align 8
  %v1096 = load i64, ptr %slot55, align 8
  %v1097 = load i64, ptr %slot39, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  store i64 %v1096, ptr %p1098, align 8, !alias.scope !3, !noalias !4
  %v1099 = load i64, ptr %slot15, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  %ld1101 = load i32, ptr %p1100, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1101, ptr %slot56, align 8
  %v1102 = load i32, ptr %slot56, align 8
  %cv1103 = zext i32 %v1102 to i64
  %cond1104 = icmp ne i64 %cv1103, 0
  br i1 %cond1104, label %bb_rcslotdrop21, label %bb_rcslotdone21
bb_rcslotdrop21:
  %v1105 = load i64, ptr %slot15, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  store i32 0, ptr %p1106, align 4, !alias.scope !3, !noalias !4
  %v1107 = load i64, ptr %slot22, align 8
  store i64 %v1107, ptr %slot57, align 8
  %v1108 = load i64, ptr %slot16, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %ld1110 = load i32, ptr %p1109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1110, ptr %slot58, align 8
  %v1111 = load i32, ptr %slot58, align 8
  %op1112 = and i32 %v1111, 28
  store i32 %op1112, ptr %slot59, align 8
  %v1113 = load i32, ptr %slot59, align 8
  %cv1114 = zext i32 %v1113 to i64
  %cond1115 = icmp ne i64 %cv1114, 0
  br i1 %cond1115, label %bb_rcslotrole21, label %bb_rcslotowner21
bb_rcslotrole21:
  %v1116 = load i64, ptr %slot51, align 8
  store i64 %v1116, ptr %slot60, align 8
  %v1117 = load i64, ptr %slot60, align 8
  %v1118 = load i64, ptr %slot57, align 8
  call void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_unloan(i64 %v1117, i64 %v1118) nomerge, !dbg !114
  br label %bb_rcslotdone21
bb_rcslotowner21:
  %v1119 = load i64, ptr %slot51, align 8
  store i64 %v1119, ptr %slot61, align 8
  %v1120 = load i64, ptr %slot61, align 8
  %v1121 = load i64, ptr %slot57, align 8
  call void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_drop(i64 %v1120, i64 %v1121) nomerge, !dbg !114
  br label %bb_rcslotdone21
bb_rcslotdone21:
  %v1122 = load i64, ptr %slot39, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  %ld1124 = load i64, ptr %p1123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1124, ptr %slot62, align 8
  %v1125 = load i64, ptr %slot62, align 8
  %v1126 = load i64, ptr %slot30, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  store i64 %v1125, ptr %p1127, align 8, !alias.scope !3, !noalias !4
  %v1128 = load i64, ptr %slot28, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %ld1130 = load i64, ptr %p1129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1130, ptr %slot63, align 8
  %v1131 = load i64, ptr %slot63, align 8
  %v1132 = load i64, ptr %slot39, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  store i64 %v1131, ptr %p1133, align 8, !alias.scope !3, !noalias !4
  %v1134 = load i64, ptr %slot28, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  %ld1136 = load i64, ptr %p1135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1136, ptr %slot64, align 8
  %v1137 = load i64, ptr %slot64, align 8
  %v1138 = load i64, ptr %slot40, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i64 %v1137, ptr %p1139, align 8, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot41, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i64 1, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot40, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %ld1144 = load i64, ptr %p1143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1144, ptr %slot65, align 8
  %v1145 = load i64, ptr %slot41, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  %ld1147 = load i64, ptr %p1146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1147, ptr %slot66, align 8
  %v1148 = load i64, ptr %slot1, align 8
  %v1149 = load i64, ptr %slot65, align 8
  %v1150 = load i64, ptr %slot66, align 8
  %call1151 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v1148, i64 %v1149, i64 %v1150) nomerge, !dbg !116
  store { i64, i64 } %call1151, ptr %callresult68, align 8
  %addr1152 = ptrtoint ptr %callresult68 to i64
  store i64 %addr1152, ptr %slot67, align 8
  %v1153 = load i64, ptr %slot67, align 8
  %v1154 = load i64, ptr %slot40, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i64 %v1153, ptr %p1155, align 8, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot17, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %ld1158 = load i32, ptr %p1157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1158, ptr %slot69, align 8
  %v1159 = load i32, ptr %slot69, align 8
  %cv1160 = zext i32 %v1159 to i64
  %cond1161 = icmp ne i64 %cv1160, 0
  br i1 %cond1161, label %bb_rcslotdrop36, label %bb_rcslotdone36
bb_rcslotdrop36:
  %v1162 = load i64, ptr %slot17, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  store i32 0, ptr %p1163, align 4, !alias.scope !3, !noalias !4
  %v1164 = load i64, ptr %slot23, align 8
  store i64 %v1164, ptr %slot70, align 8
  %v1165 = load i64, ptr %slot18, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  %ld1167 = load i32, ptr %p1166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1167, ptr %slot71, align 8
  %v1168 = load i32, ptr %slot71, align 8
  %op1169 = and i32 %v1168, 28
  store i32 %op1169, ptr %slot72, align 8
  %v1170 = load i32, ptr %slot72, align 8
  %cv1171 = zext i32 %v1170 to i64
  %cond1172 = icmp ne i64 %cv1171, 0
  br i1 %cond1172, label %bb_rcslotrole36, label %bb_rcslotowner36
bb_rcslotrole36:
  %v1173 = load i64, ptr %slot51, align 8
  store i64 %v1173, ptr %slot73, align 8
  %v1174 = load i64, ptr %slot73, align 8
  %v1175 = load i64, ptr %slot70, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1174, i64 %v1175) nomerge, !dbg !116
  br label %bb_rcslotdone36
bb_rcslotowner36:
  %v1176 = load i64, ptr %slot51, align 8
  store i64 %v1176, ptr %slot74, align 8
  %v1177 = load i64, ptr %slot74, align 8
  %v1178 = load i64, ptr %slot70, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1177, i64 %v1178) nomerge, !dbg !116
  br label %bb_rcslotdone36
bb_rcslotdone36:
  %v1179 = load i64, ptr %slot40, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  %ld1181 = load i64, ptr %p1180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1181, ptr %slot75, align 8
  %v1182 = load i64, ptr %slot1, align 8
  %v1183 = load i64, ptr %slot75, align 8
  %call1184 = call i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64 %v1182, i64 %v1183) nomerge, !dbg !118
  store i64 %call1184, ptr %slot76, align 8
  %v1185 = load i64, ptr %slot76, align 8
  %v1186 = load i64, ptr %slot40, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  store i64 %v1185, ptr %p1187, align 8, !alias.scope !3, !noalias !4
  %v1188 = load i64, ptr %slot39, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  %ld1190 = load i64, ptr %p1189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1190, ptr %slot77, align 8
  %v1191 = load i64, ptr %slot40, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %ld1193 = load i64, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1193, ptr %slot78, align 8
  %v1194 = load i64, ptr %slot1, align 8
  %v1195 = load i64, ptr %slot77, align 8
  %v1196 = load i64, ptr %slot78, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult80, i64 %v1194, i64 %v1195, i64 %v1196) nomerge, !dbg !120
  %addr1197 = ptrtoint ptr %callresult80 to i64
  store i64 %addr1197, ptr %slot79, align 8
  %v1198 = load i64, ptr %slot79, align 8
  %v1199 = load i64, ptr %slot39, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  store i64 %v1198, ptr %p1200, align 8, !alias.scope !3, !noalias !4
  %v1201 = load i64, ptr %slot39, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %ld1203 = load i64, ptr %p1202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1203, ptr %slot81, align 8
  %v1204 = load i64, ptr %slot24, align 8
  store i64 %v1204, ptr %slot82, align 8
  %v1205 = load i64, ptr %slot81, align 8
  %v1206 = load i64, ptr %slot82, align 8
  %p1207 = inttoptr i64 %v1205 to ptr
  %p1208 = inttoptr i64 %v1206 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1208, ptr %p1207, i64 24, i1 false)
  %v1209 = load i64, ptr %slot20, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i32 2, ptr %p1210, align 4, !alias.scope !3, !noalias !4
  %v1211 = load i64, ptr %slot19, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i32 1, ptr %p1212, align 4, !alias.scope !3, !noalias !4
  %v1213 = load i64, ptr %slot15, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i32, ptr %p1214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1215, ptr %slot83, align 8
  %v1216 = load i32, ptr %slot83, align 8
  %cv1217 = zext i32 %v1216 to i64
  %cond1218 = icmp ne i64 %cv1217, 0
  br i1 %cond1218, label %bb_rcslotdrop54, label %bb_rcslotdone54
bb_rcslotdrop54:
  %v1219 = load i64, ptr %slot15, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  store i32 0, ptr %p1220, align 4, !alias.scope !3, !noalias !4
  %v1221 = load i64, ptr %slot22, align 8
  store i64 %v1221, ptr %slot84, align 8
  %v1222 = load i64, ptr %slot16, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  %ld1224 = load i32, ptr %p1223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1224, ptr %slot85, align 8
  %v1225 = load i32, ptr %slot85, align 8
  %op1226 = and i32 %v1225, 28
  store i32 %op1226, ptr %slot86, align 8
  %v1227 = load i32, ptr %slot86, align 8
  %cv1228 = zext i32 %v1227 to i64
  %cond1229 = icmp ne i64 %cv1228, 0
  br i1 %cond1229, label %bb_rcslotrole54, label %bb_rcslotowner54
bb_rcslotrole54:
  %v1230 = load i64, ptr %slot51, align 8
  store i64 %v1230, ptr %slot87, align 8
  %v1231 = load i64, ptr %slot87, align 8
  %v1232 = load i64, ptr %slot84, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1231, i64 %v1232) nomerge, !dbg !120
  br label %bb_rcslotdone54
bb_rcslotowner54:
  %v1233 = load i64, ptr %slot51, align 8
  store i64 %v1233, ptr %slot88, align 8
  %v1234 = load i64, ptr %slot88, align 8
  %v1235 = load i64, ptr %slot84, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1234, i64 %v1235) nomerge, !dbg !120
  br label %bb_rcslotdone54
bb_rcslotdone54:
  %v1236 = load i64, ptr %slot22, align 8
  store i64 %v1236, ptr %slot89, align 8
  %v1237 = load i64, ptr %slot24, align 8
  store i64 %v1237, ptr %slot90, align 8
  %v1238 = load i64, ptr %slot90, align 8
  %v1239 = load i64, ptr %slot89, align 8
  %p1240 = inttoptr i64 %v1238 to ptr
  %p1241 = inttoptr i64 %v1239 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1241, ptr %p1240, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1242 = load i64, ptr %slot16, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  store i32 2, ptr %p1243, align 4, !alias.scope !3, !noalias !4
  %v1244 = load i64, ptr %slot20, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %ld1246 = load i32, ptr %p1245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1246, ptr %slot91, align 8
  %v1247 = load i32, ptr %slot91, align 8
  %v1248 = load i64, ptr %slot16, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i32 %v1247, ptr %p1249, align 4, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot19, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  store i32 0, ptr %p1251, align 4, !alias.scope !3, !noalias !4
  %v1252 = load i64, ptr %slot15, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  store i32 1, ptr %p1253, align 4, !alias.scope !3, !noalias !4
  %v1254 = load i64, ptr %slot89, align 8
  %v1255 = load i64, ptr %slot39, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  store i64 %v1254, ptr %p1256, align 8, !alias.scope !3, !noalias !4
  %v1257 = load i64, ptr %slot39, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %ld1259 = load i64, ptr %p1258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1259, ptr %slot92, align 8
  %v1260 = load i64, ptr %slot92, align 8
  %op1261 = add i64 %v1260, 8
  store i64 %op1261, ptr %slot93, align 8
  %v1262 = load i64, ptr %slot93, align 8
  %v1263 = load i64, ptr %slot39, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  store i64 %v1262, ptr %p1264, align 8, !alias.scope !3, !noalias !4
  %v1265 = load i64, ptr %slot39, align 8
  %p1266 = inttoptr i64 %v1265 to ptr
  %ld1267 = load i64, ptr %p1266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1267, ptr %slot94, align 8
  %v1268 = load i64, ptr %slot24, align 8
  store i64 %v1268, ptr %slot95, align 8
  %v1269 = load i64, ptr %slot51, align 8
  %v1270 = load i64, ptr %slot95, align 8
  %v1271 = load i64, ptr %slot94, align 8
  %call1272 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v1269, i64 %v1270, i64 %v1271) nomerge, !dbg !122
  store i32 %call1272, ptr %slot96, align 8
  %v1273 = load i32, ptr %slot96, align 8
  %cv1274 = zext i32 %v1273 to i64
  %cond1275 = icmp ne i64 %cv1274, 0
  br i1 %cond1275, label %bb_rcsuccess74, label %bb_rcfailure74
bb_rcfailure74:
  %v1276 = load i64, ptr %slot51, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  %call1278 = call i32 @myl_rc_take_failure(ptr %p1277) nomerge, !dbg !122
  store i32 %call1278, ptr %slot97, align 8
  %v1279 = load i64, ptr %slot1, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  %v1281 = load i32, ptr %slot97, align 8
  %call1282 = call i32 @myl_qbe_rc_status(ptr %p1280, i32 %v1281) nomerge, !dbg !122
  store i32 %call1282, ptr %slot98, align 8
  br label %bb_failure
bb_rcsuccess74:
  %v1283 = load i64, ptr %slot20, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  store i32 2, ptr %p1284, align 4, !alias.scope !3, !noalias !4
  %v1285 = load i64, ptr %slot20, align 8
  %p1286 = inttoptr i64 %v1285 to ptr
  store i32 16, ptr %p1286, align 4, !alias.scope !3, !noalias !4
  %v1287 = load i64, ptr %slot19, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i32 1, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot15, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  %ld1291 = load i32, ptr %p1290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1291, ptr %slot99, align 8
  %v1292 = load i32, ptr %slot99, align 8
  %cv1293 = zext i32 %v1292 to i64
  %cond1294 = icmp ne i64 %cv1293, 0
  br i1 %cond1294, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v1295 = load i64, ptr %slot15, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  store i32 0, ptr %p1296, align 4, !alias.scope !3, !noalias !4
  %v1297 = load i64, ptr %slot22, align 8
  store i64 %v1297, ptr %slot100, align 8
  %v1298 = load i64, ptr %slot16, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  %ld1300 = load i32, ptr %p1299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1300, ptr %slot101, align 8
  %v1301 = load i32, ptr %slot101, align 8
  %op1302 = and i32 %v1301, 28
  store i32 %op1302, ptr %slot102, align 8
  %v1303 = load i32, ptr %slot102, align 8
  %cv1304 = zext i32 %v1303 to i64
  %cond1305 = icmp ne i64 %cv1304, 0
  br i1 %cond1305, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v1306 = load i64, ptr %slot51, align 8
  store i64 %v1306, ptr %slot103, align 8
  %v1307 = load i64, ptr %slot103, align 8
  %v1308 = load i64, ptr %slot100, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1307, i64 %v1308) nomerge, !dbg !122
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v1309 = load i64, ptr %slot51, align 8
  store i64 %v1309, ptr %slot104, align 8
  %v1310 = load i64, ptr %slot104, align 8
  %v1311 = load i64, ptr %slot100, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v1310, i64 %v1311) nomerge, !dbg !122
  br label %bb_rcslotdone82
bb_rcslotdone82:
  %v1312 = load i64, ptr %slot22, align 8
  store i64 %v1312, ptr %slot105, align 8
  %v1313 = load i64, ptr %slot24, align 8
  store i64 %v1313, ptr %slot106, align 8
  %v1314 = load i64, ptr %slot106, align 8
  %v1315 = load i64, ptr %slot105, align 8
  %p1316 = inttoptr i64 %v1314 to ptr
  %p1317 = inttoptr i64 %v1315 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1317, ptr %p1316, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1318 = load i64, ptr %slot16, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i32 2, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  %v1320 = load i64, ptr %slot20, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  %ld1322 = load i32, ptr %p1321, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1322, ptr %slot107, align 8
  %v1323 = load i32, ptr %slot107, align 8
  %v1324 = load i64, ptr %slot16, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  store i32 %v1323, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  %v1326 = load i64, ptr %slot19, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  store i32 0, ptr %p1327, align 4, !alias.scope !3, !noalias !4
  %v1328 = load i64, ptr %slot15, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 1, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot105, align 8
  %v1331 = load i64, ptr %slot39, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  store i64 %v1330, ptr %p1332, align 8, !alias.scope !3, !noalias !4
  %v1333 = load i64, ptr %slot39, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  %ld1335 = load i64, ptr %p1334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1335, ptr %slot108, align 8
  %v1336 = load i64, ptr %slot15, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  %ld1338 = load i32, ptr %p1337, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1338, ptr %slot109, align 8
  %v1339 = load i64, ptr %slot16, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  %ld1341 = load i32, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1341, ptr %slot110, align 8
  %v1342 = load i32, ptr %slot110, align 8
  %op1343 = and i32 %v1342, 24
  store i32 %op1343, ptr %slot110, align 8
  %v1344 = load i32, ptr %slot110, align 8
  %cmp1345 = icmp eq i32 %v1344, 0
  %cv1346 = zext i1 %cmp1345 to i32
  store i32 %cv1346, ptr %slot111, align 8
  %v1347 = load i32, ptr %slot109, align 8
  %v1348 = load i32, ptr %slot111, align 8
  %op1349 = and i32 %v1347, %v1348
  store i32 %op1349, ptr %slot112, align 8
  %v1350 = load i32, ptr %slot112, align 8
  %cv1351 = zext i32 %v1350 to i64
  %cond1352 = icmp ne i64 %cv1351, 0
  br i1 %cond1352, label %bb_rctake98, label %bb_rccopy98
bb_rctake98:
  %v1353 = load i64, ptr %slot24, align 8
  store i64 %v1353, ptr %slot113, align 8
  %v1354 = load i64, ptr %slot52, align 8
  store i64 %v1354, ptr %slot114, align 8
  %v1355 = load i64, ptr %slot108, align 8
  %v1356 = load i64, ptr %slot113, align 8
  %op1357 = sub i64 %v1355, %v1356
  store i64 %op1357, ptr %slot115, align 8
  %v1358 = load i64, ptr %slot113, align 8
  %v1359 = load i64, ptr %slot108, align 8
  %op1360 = sub i64 %v1358, %v1359
  store i64 %op1360, ptr %slot116, align 8
  %v1361 = load i64, ptr %slot115, align 8
  %cmp1362 = icmp ult i64 %v1361, 16
  %cv1363 = zext i1 %cmp1362 to i32
  store i32 %cv1363, ptr %slot117, align 8
  %v1364 = load i64, ptr %slot116, align 8
  %cmp1365 = icmp ult i64 %v1364, 16
  %cv1366 = zext i1 %cmp1365 to i32
  store i32 %cv1366, ptr %slot118, align 8
  %v1367 = load i32, ptr %slot117, align 8
  %v1368 = load i32, ptr %slot118, align 8
  %op1369 = or i32 %v1367, %v1368
  store i32 %op1369, ptr %slot119, align 8
  %v1370 = load i32, ptr %slot119, align 8
  %cv1371 = zext i32 %v1370 to i64
  %cond1372 = icmp ne i64 %cv1371, 0
  br i1 %cond1372, label %bb_rcmoveslow107, label %bb_rcmovecheck107
bb_rcmovecheck107:
  %v1373 = load i64, ptr %slot108, align 8
  %op1374 = add i64 %v1373, 0
  store i64 %op1374, ptr %slot120, align 8
  %v1375 = load i64, ptr %slot120, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i64, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1377, ptr %slot121, align 8
  %v1378 = load i64, ptr %slot121, align 8
  %cmp1379 = icmp ne i64 %v1378, 0
  %cv1380 = zext i1 %cmp1379 to i32
  store i32 %cv1380, ptr %slot122, align 8
  %v1381 = load i32, ptr %slot122, align 8
  %cv1382 = zext i32 %v1381 to i64
  %cond1383 = icmp ne i64 %cv1382, 0
  br i1 %cond1383, label %bb_rcmoveheader115, label %bb_rcmovenext115
bb_rcmoveheader115:
  %v1384 = load i64, ptr %slot121, align 8
  %op1385 = sub i64 %v1384, 16
  store i64 %op1385, ptr %slot123, align 8
  %v1386 = load i64, ptr %slot121, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  %rgep1388 = getelementptr i8, ptr %p1387, i64 -16
  %ld1389 = load i64, ptr %rgep1388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1389, ptr %slot124, align 8
  %v1390 = load i64, ptr %slot124, align 8
  %op1391 = and i64 %v1390, 5764607523034234881
  store i64 %op1391, ptr %slot125, align 8
  %v1392 = load i64, ptr %slot125, align 8
  %cmp1393 = icmp ne i64 %v1392, 0
  %cv1394 = zext i1 %cmp1393 to i32
  store i32 %cv1394, ptr %slot126, align 8
  %v1395 = load i32, ptr %slot126, align 8
  %cv1396 = zext i32 %v1395 to i64
  %cond1397 = icmp ne i64 %cv1396, 0
  br i1 %cond1397, label %bb_rcmoveslow107, label %bb_rcmovenext115
bb_rcmovenext115:
  %v1398 = load i64, ptr %slot108, align 8
  %v1399 = load i64, ptr %slot113, align 8
  %p1400 = inttoptr i64 %v1398 to ptr
  %p1401 = inttoptr i64 %v1399 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1401, ptr %p1400, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot108, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  store i64 0, ptr %p1403, align 8, !alias.scope !3, !noalias !4
  %v1404 = load i64, ptr %slot108, align 8
  %op1405 = add i64 %v1404, 8
  store i64 %op1405, ptr %slot127, align 8
  %v1406 = load i64, ptr %slot127, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i64 0, ptr %p1407, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved107
bb_rcmoveslow107:
  %v1408 = load i64, ptr %slot51, align 8
  %v1409 = load i64, ptr %slot113, align 8
  %v1410 = load i64, ptr %slot108, align 8
  %v1411 = load i64, ptr %slot114, align 8
  %cv1412 = trunc i64 %v1411 to i32
  %call1413 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v1408, i64 %v1409, i64 %v1410, i32 %cv1412) nomerge, !dbg !124
  store i32 %call1413, ptr %slot128, align 8
  %v1414 = load i32, ptr %slot128, align 8
  %cv1415 = zext i32 %v1414 to i64
  %cond1416 = icmp ne i64 %cv1415, 0
  br i1 %cond1416, label %bb_rcsuccess123, label %bb_rcfailure123
bb_rcfailure123:
  %v1417 = load i64, ptr %slot51, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  %call1419 = call i32 @myl_rc_take_failure(ptr %p1418) nomerge, !dbg !124
  store i32 %call1419, ptr %slot129, align 8
  %v1420 = load i64, ptr %slot1, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  %v1422 = load i32, ptr %slot129, align 8
  %call1423 = call i32 @myl_qbe_rc_status(ptr %p1421, i32 %v1422) nomerge, !dbg !124
  store i32 %call1423, ptr %slot130, align 8
  br label %bb_failure
bb_rcsuccess123:
  br label %bb_rcmoved107
bb_rcmoved107:
  %v1424 = load i64, ptr %slot15, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i32 0, ptr %p1425, align 4, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot20, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  store i32 2, ptr %p1427, align 4, !alias.scope !3, !noalias !4
  %v1428 = load i64, ptr %slot19, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  store i32 1, ptr %p1429, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared98
bb_rccopy98:
  %v1430 = load i64, ptr %slot24, align 8
  store i64 %v1430, ptr %slot131, align 8
  %v1431 = load i64, ptr %slot52, align 8
  store i64 %v1431, ptr %slot132, align 8
  %v1432 = load i64, ptr %slot51, align 8
  %v1433 = load i64, ptr %slot131, align 8
  %v1434 = load i64, ptr %slot108, align 8
  %v1435 = load i64, ptr %slot132, align 8
  %cv1436 = trunc i64 %v1435 to i32
  %call1437 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v1432, i64 %v1433, i64 %v1434, i32 %cv1436) nomerge, !dbg !124
  store i32 %call1437, ptr %slot133, align 8
  %v1438 = load i32, ptr %slot133, align 8
  %cv1439 = zext i32 %v1438 to i64
  %cond1440 = icmp ne i64 %cv1439, 0
  br i1 %cond1440, label %bb_rcsuccess132, label %bb_rcfailure132
bb_rcfailure132:
  %v1441 = load i64, ptr %slot51, align 8
  %p1442 = inttoptr i64 %v1441 to ptr
  %call1443 = call i32 @myl_rc_take_failure(ptr %p1442) nomerge, !dbg !124
  store i32 %call1443, ptr %slot134, align 8
  %v1444 = load i64, ptr %slot1, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  %v1446 = load i32, ptr %slot134, align 8
  %call1447 = call i32 @myl_qbe_rc_status(ptr %p1445, i32 %v1446) nomerge, !dbg !124
  store i32 %call1447, ptr %slot135, align 8
  br label %bb_failure
bb_rcsuccess132:
  %v1448 = load i64, ptr %slot20, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  store i32 2, ptr %p1449, align 4, !alias.scope !3, !noalias !4
  %v1450 = load i64, ptr %slot19, align 8
  %p1451 = inttoptr i64 %v1450 to ptr
  store i32 1, ptr %p1451, align 4, !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot15, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  %ld1454 = load i32, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1454, ptr %slot136, align 8
  %v1455 = load i32, ptr %slot136, align 8
  %cv1456 = zext i32 %v1455 to i64
  %cond1457 = icmp ne i64 %cv1456, 0
  br i1 %cond1457, label %bb_rcslotdrop139, label %bb_rcslotdone139
bb_rcslotdrop139:
  %v1458 = load i64, ptr %slot15, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i32 0, ptr %p1459, align 4, !alias.scope !3, !noalias !4
  %v1460 = load i64, ptr %slot22, align 8
  store i64 %v1460, ptr %slot137, align 8
  %v1461 = load i64, ptr %slot16, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  %ld1463 = load i32, ptr %p1462, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1463, ptr %slot138, align 8
  %v1464 = load i32, ptr %slot138, align 8
  %op1465 = and i32 %v1464, 28
  store i32 %op1465, ptr %slot139, align 8
  %v1466 = load i32, ptr %slot139, align 8
  %cv1467 = zext i32 %v1466 to i64
  %cond1468 = icmp ne i64 %cv1467, 0
  br i1 %cond1468, label %bb_rcslotrole139, label %bb_rcslotowner139
bb_rcslotrole139:
  %v1469 = load i64, ptr %slot51, align 8
  store i64 %v1469, ptr %slot140, align 8
  %v1470 = load i64, ptr %slot140, align 8
  %v1471 = load i64, ptr %slot137, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v1470, i64 %v1471) nomerge, !dbg !124
  br label %bb_rcslotdone139
bb_rcslotowner139:
  %v1472 = load i64, ptr %slot137, align 8
  %p1474 = inttoptr i64 %v1472 to ptr
  %gep1475 = getelementptr i8, ptr %p1474, i64 0
  %op1473 = ptrtoint ptr %gep1475 to i64
  store i64 %op1473, ptr %slot141, align 8
  %v1476 = load i64, ptr %slot51, align 8
  store i64 %v1476, ptr %slot142, align 8
  %v1477 = load i64, ptr %slot141, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  %ld1479 = load i64, ptr %p1478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1479, ptr %slot143, align 8
  %v1480 = load i64, ptr %slot143, align 8
  %cmp1481 = icmp ne i64 %v1480, 0
  %cv1482 = zext i1 %cmp1481 to i32
  store i32 %cv1482, ptr %slot144, align 8
  %v1483 = load i32, ptr %slot144, align 8
  %cv1484 = zext i32 %v1483 to i64
  %cond1485 = icmp ne i64 %cv1484, 0
  br i1 %cond1485, label %bb_rcgnn157, label %bb_rcgdone157
bb_rcgnn157:
  %v1486 = load i64, ptr %slot143, align 8
  %op1487 = sub i64 %v1486, 16
  store i64 %op1487, ptr %slot145, align 8
  %v1488 = load i64, ptr %slot143, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  %rgep1490 = getelementptr i8, ptr %p1489, i64 -16
  %ld1491 = load i64, ptr %rgep1490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1491, ptr %slot146, align 8
  %v1492 = load i64, ptr %slot146, align 8
  %op1493 = and i64 %v1492, 4611686018427387906
  store i64 %op1493, ptr %slot147, align 8
  %v1494 = load i64, ptr %slot147, align 8
  %cmp1495 = icmp ne i64 %v1494, 0
  %cv1496 = zext i1 %cmp1495 to i32
  store i32 %cv1496, ptr %slot148, align 8
  %v1497 = load i32, ptr %slot148, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcgclear157, label %bb_rcgcounted157
bb_rcgcounted157:
  %v1500 = load i64, ptr %slot143, align 8
  %op1501 = sub i64 %v1500, 32
  store i64 %op1501, ptr %slot149, align 8
  %v1502 = load i64, ptr %slot143, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %rgep1504 = getelementptr i8, ptr %p1503, i64 -32
  %ld1505 = load i64, ptr %rgep1504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1505, ptr %slot150, align 8
  %v1506 = load i64, ptr %slot150, align 8
  %op1507 = sub i64 %v1506, 1
  store i64 %op1507, ptr %slot151, align 8
  %v1508 = load i64, ptr %slot151, align 8
  %cmp1509 = icmp eq i64 %v1508, 0
  %cv1510 = zext i1 %cmp1509 to i32
  store i32 %cv1510, ptr %slot152, align 8
  %v1511 = load i32, ptr %slot152, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcglast157, label %bb_rcgdec157
bb_rcglast157:
  %v1514 = load i64, ptr %slot143, align 8
  %op1515 = sub i64 %v1514, 24
  store i64 %op1515, ptr %slot153, align 8
  %v1516 = load i64, ptr %slot143, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %rgep1518 = getelementptr i8, ptr %p1517, i64 -24
  %ld1519 = load i64, ptr %rgep1518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1519, ptr %slot154, align 8
  %v1520 = load i64, ptr %slot154, align 8
  %cmp1521 = icmp ne i64 %v1520, 0
  %cv1522 = zext i1 %cmp1521 to i32
  store i32 %cv1522, ptr %slot155, align 8
  %v1523 = load i32, ptr %slot155, align 8
  %cv1524 = zext i32 %v1523 to i64
  %cond1525 = icmp ne i64 %cv1524, 0
  br i1 %cond1525, label %bb_rcgdec157, label %bb_rcgslow157
bb_rcgslow157:
  %v1526 = load i64, ptr %slot142, align 8
  %v1527 = load i64, ptr %slot141, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1526, i64 %v1527) nomerge, !dbg !124
  br label %bb_rcgdone157
bb_rcgdec157:
  %v1528 = load i64, ptr %slot151, align 8
  %v1529 = load i64, ptr %slot143, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  %rgep1531 = getelementptr i8, ptr %p1530, i64 -32
  store i64 %v1528, ptr %rgep1531, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear157
bb_rcgclear157:
  %v1532 = load i64, ptr %slot141, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  store i64 0, ptr %p1533, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone157
bb_rcgdone157:
  %v1534 = load i64, ptr %slot137, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  store i64 0, ptr %p1535, align 8, !alias.scope !3, !noalias !4
  %v1536 = load i64, ptr %slot137, align 8
  %p1538 = inttoptr i64 %v1536 to ptr
  %gep1539 = getelementptr i8, ptr %p1538, i64 8
  %op1537 = ptrtoint ptr %gep1539 to i64
  store i64 %op1537, ptr %slot156, align 8
  %v1540 = load i64, ptr %slot156, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  store i64 0, ptr %p1541, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone139
bb_rcslotdone139:
  br label %bb_rcprepared98
bb_rcprepared98:
  %v1542 = load i64, ptr %slot5, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  %ld1544 = load i32, ptr %p1543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1544, ptr %slot157, align 8
  %v1545 = load i32, ptr %slot157, align 8
  %cv1546 = zext i32 %v1545 to i64
  %cond1547 = icmp ne i64 %cv1546, 0
  br i1 %cond1547, label %bb_rcslotdrop165, label %bb_rcslotdone165
bb_rcslotdrop165:
  %v1548 = load i64, ptr %slot5, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  store i32 0, ptr %p1549, align 4, !alias.scope !3, !noalias !4
  %v1550 = load i64, ptr %slot31, align 8
  store i64 %v1550, ptr %slot158, align 8
  %v1551 = load i64, ptr %slot6, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %ld1553 = load i32, ptr %p1552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1553, ptr %slot159, align 8
  %v1554 = load i32, ptr %slot159, align 8
  %op1555 = and i32 %v1554, 28
  store i32 %op1555, ptr %slot160, align 8
  %v1556 = load i32, ptr %slot160, align 8
  %cv1557 = zext i32 %v1556 to i64
  %cond1558 = icmp ne i64 %cv1557, 0
  br i1 %cond1558, label %bb_rcslotrole165, label %bb_rcslotowner165
bb_rcslotrole165:
  %v1559 = load i64, ptr %slot51, align 8
  store i64 %v1559, ptr %slot161, align 8
  %v1560 = load i64, ptr %slot161, align 8
  %v1561 = load i64, ptr %slot158, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v1560, i64 %v1561) nomerge, !dbg !124
  br label %bb_rcslotdone165
bb_rcslotowner165:
  %v1562 = load i64, ptr %slot158, align 8
  %p1564 = inttoptr i64 %v1562 to ptr
  %gep1565 = getelementptr i8, ptr %p1564, i64 0
  %op1563 = ptrtoint ptr %gep1565 to i64
  store i64 %op1563, ptr %slot162, align 8
  %v1566 = load i64, ptr %slot51, align 8
  store i64 %v1566, ptr %slot163, align 8
  %v1567 = load i64, ptr %slot162, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  %ld1569 = load i64, ptr %p1568, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1569, ptr %slot164, align 8
  %v1570 = load i64, ptr %slot164, align 8
  %cmp1571 = icmp ne i64 %v1570, 0
  %cv1572 = zext i1 %cmp1571 to i32
  store i32 %cv1572, ptr %slot165, align 8
  %v1573 = load i32, ptr %slot165, align 8
  %cv1574 = zext i32 %v1573 to i64
  %cond1575 = icmp ne i64 %cv1574, 0
  br i1 %cond1575, label %bb_rcgnn183, label %bb_rcgdone183
bb_rcgnn183:
  %v1576 = load i64, ptr %slot164, align 8
  %op1577 = sub i64 %v1576, 16
  store i64 %op1577, ptr %slot166, align 8
  %v1578 = load i64, ptr %slot164, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  %rgep1580 = getelementptr i8, ptr %p1579, i64 -16
  %ld1581 = load i64, ptr %rgep1580, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1581, ptr %slot167, align 8
  %v1582 = load i64, ptr %slot167, align 8
  %op1583 = and i64 %v1582, 4611686018427387906
  store i64 %op1583, ptr %slot168, align 8
  %v1584 = load i64, ptr %slot168, align 8
  %cmp1585 = icmp ne i64 %v1584, 0
  %cv1586 = zext i1 %cmp1585 to i32
  store i32 %cv1586, ptr %slot169, align 8
  %v1587 = load i32, ptr %slot169, align 8
  %cv1588 = zext i32 %v1587 to i64
  %cond1589 = icmp ne i64 %cv1588, 0
  br i1 %cond1589, label %bb_rcgclear183, label %bb_rcgcounted183
bb_rcgcounted183:
  %v1590 = load i64, ptr %slot164, align 8
  %op1591 = sub i64 %v1590, 32
  store i64 %op1591, ptr %slot170, align 8
  %v1592 = load i64, ptr %slot164, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  %rgep1594 = getelementptr i8, ptr %p1593, i64 -32
  %ld1595 = load i64, ptr %rgep1594, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1595, ptr %slot171, align 8
  %v1596 = load i64, ptr %slot171, align 8
  %op1597 = sub i64 %v1596, 1
  store i64 %op1597, ptr %slot172, align 8
  %v1598 = load i64, ptr %slot172, align 8
  %cmp1599 = icmp eq i64 %v1598, 0
  %cv1600 = zext i1 %cmp1599 to i32
  store i32 %cv1600, ptr %slot173, align 8
  %v1601 = load i32, ptr %slot173, align 8
  %cv1602 = zext i32 %v1601 to i64
  %cond1603 = icmp ne i64 %cv1602, 0
  br i1 %cond1603, label %bb_rcglast183, label %bb_rcgdec183
bb_rcglast183:
  %v1604 = load i64, ptr %slot164, align 8
  %op1605 = sub i64 %v1604, 24
  store i64 %op1605, ptr %slot174, align 8
  %v1606 = load i64, ptr %slot164, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %rgep1608 = getelementptr i8, ptr %p1607, i64 -24
  %ld1609 = load i64, ptr %rgep1608, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1609, ptr %slot175, align 8
  %v1610 = load i64, ptr %slot175, align 8
  %cmp1611 = icmp ne i64 %v1610, 0
  %cv1612 = zext i1 %cmp1611 to i32
  store i32 %cv1612, ptr %slot176, align 8
  %v1613 = load i32, ptr %slot176, align 8
  %cv1614 = zext i32 %v1613 to i64
  %cond1615 = icmp ne i64 %cv1614, 0
  br i1 %cond1615, label %bb_rcgdec183, label %bb_rcgslow183
bb_rcgslow183:
  %v1616 = load i64, ptr %slot163, align 8
  %v1617 = load i64, ptr %slot162, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1616, i64 %v1617) nomerge, !dbg !124
  br label %bb_rcgdone183
bb_rcgdec183:
  %v1618 = load i64, ptr %slot172, align 8
  %v1619 = load i64, ptr %slot164, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  %rgep1621 = getelementptr i8, ptr %p1620, i64 -32
  store i64 %v1618, ptr %rgep1621, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear183
bb_rcgclear183:
  %v1622 = load i64, ptr %slot162, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i64 0, ptr %p1623, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone183
bb_rcgdone183:
  %v1624 = load i64, ptr %slot158, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i64 0, ptr %p1625, align 8, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot158, align 8
  %p1628 = inttoptr i64 %v1626 to ptr
  %gep1629 = getelementptr i8, ptr %p1628, i64 8
  %op1627 = ptrtoint ptr %gep1629 to i64
  store i64 %op1627, ptr %slot177, align 8
  %v1630 = load i64, ptr %slot177, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i64 0, ptr %p1631, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone165
bb_rcslotdone165:
  %v1632 = load i64, ptr %slot31, align 8
  store i64 %v1632, ptr %slot178, align 8
  %v1633 = load i64, ptr %slot24, align 8
  store i64 %v1633, ptr %slot179, align 8
  %v1634 = load i64, ptr %slot179, align 8
  %v1635 = load i64, ptr %slot178, align 8
  %p1636 = inttoptr i64 %v1634 to ptr
  %p1637 = inttoptr i64 %v1635 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1637, ptr %p1636, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1638 = load i64, ptr %slot19, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 0, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot6, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  store i32 2, ptr %p1641, align 4, !alias.scope !3, !noalias !4
  %v1642 = load i64, ptr %slot20, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  %ld1644 = load i32, ptr %p1643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1644, ptr %slot180, align 8
  %v1645 = load i32, ptr %slot180, align 8
  %v1646 = load i64, ptr %slot6, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  store i32 %v1645, ptr %p1647, align 4, !alias.scope !3, !noalias !4
  %v1648 = load i64, ptr %slot5, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  store i32 1, ptr %p1649, align 4, !alias.scope !3, !noalias !4
  %v1650 = load i64, ptr %slot31, align 8
  %v1651 = load i64, ptr %slot39, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  store i64 %v1650, ptr %p1652, align 8, !alias.scope !3, !noalias !4
  %v1653 = load i64, ptr %slot30, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  %ld1655 = load i64, ptr %p1654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1655, ptr %slot181, align 8
  %v1656 = load i64, ptr %slot181, align 8
  %v1657 = load i64, ptr %slot40, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  store i64 %v1656, ptr %p1658, align 8, !alias.scope !3, !noalias !4
  %v1659 = load i64, ptr %slot28, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %ld1661 = load i64, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1661, ptr %slot182, align 8
  %v1662 = load i64, ptr %slot182, align 8
  %v1663 = load i64, ptr %slot41, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  store i64 %v1662, ptr %p1664, align 8, !alias.scope !3, !noalias !4
  %v1665 = load i64, ptr %slot30, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  %ld1667 = load i64, ptr %p1666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1667, ptr %slot183, align 8
  %v1668 = load i64, ptr %slot183, align 8
  %v1669 = load i64, ptr %slot42, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  store i64 %v1668, ptr %p1670, align 8, !alias.scope !3, !noalias !4
  %v1671 = load i64, ptr %slot41, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  %ld1673 = load i64, ptr %p1672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1673, ptr %slot184, align 8
  %v1674 = load i64, ptr %slot42, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  %ld1676 = load i64, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1676, ptr %slot185, align 8
  %v1677 = load i64, ptr %slot1, align 8
  %v1678 = load i64, ptr %slot184, align 8
  %v1679 = load i64, ptr %slot185, align 8
  %call1680 = call i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64 %v1677, i64 %v1678, i64 %v1679) nomerge, !dbg !126
  store i64 %call1680, ptr %slot186, align 8
  %v1681 = load i64, ptr %slot186, align 8
  %v1682 = load i64, ptr %slot41, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  store i64 %v1681, ptr %p1683, align 8, !alias.scope !3, !noalias !4
  %v1684 = load i64, ptr %slot28, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  %ld1686 = load i64, ptr %p1685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1686, ptr %slot187, align 8
  %v1687 = load i64, ptr %slot187, align 8
  %v1688 = load i64, ptr %slot42, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  store i64 %v1687, ptr %p1689, align 8, !alias.scope !3, !noalias !4
  %v1690 = load i64, ptr %slot43, align 8
  %p1691 = inttoptr i64 %v1690 to ptr
  store i64 0, ptr %p1691, align 8, !alias.scope !3, !noalias !4
  %v1692 = load i64, ptr %slot42, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  %ld1694 = load i64, ptr %p1693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1694, ptr %slot188, align 8
  %v1695 = load i64, ptr %slot43, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  %ld1697 = load i64, ptr %p1696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1697, ptr %slot189, align 8
  %v1698 = load i64, ptr %slot1, align 8
  %v1699 = load i64, ptr %slot188, align 8
  %v1700 = load i64, ptr %slot189, align 8
  %call1701 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v1698, i64 %v1699, i64 %v1700) nomerge, !dbg !128
  store { i64, i64 } %call1701, ptr %callresult191, align 8
  %addr1702 = ptrtoint ptr %callresult191 to i64
  store i64 %addr1702, ptr %slot190, align 8
  %v1703 = load i64, ptr %slot190, align 8
  %v1704 = load i64, ptr %slot42, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  store i64 %v1703, ptr %p1705, align 8, !alias.scope !3, !noalias !4
  %v1706 = load i64, ptr %slot39, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  %ld1708 = load i64, ptr %p1707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1708, ptr %slot192, align 8
  %v1709 = load i64, ptr %slot40, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %ld1711 = load i64, ptr %p1710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1711, ptr %slot193, align 8
  %v1712 = load i64, ptr %slot41, align 8
  %p1713 = inttoptr i64 %v1712 to ptr
  %ld1714 = load i64, ptr %p1713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1714, ptr %slot194, align 8
  %v1715 = load i64, ptr %slot42, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  %ld1717 = load i64, ptr %p1716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1717, ptr %slot195, align 8
  %v1718 = load i64, ptr %slot1, align 8
  %v1719 = load i64, ptr %slot192, align 8
  %v1720 = load i64, ptr %slot193, align 8
  %v1721 = load i64, ptr %slot194, align 8
  %v1722 = load i64, ptr %slot195, align 8
  %call1723 = call i64 @myl_f_72cbd8b3ebb02b19d0384fb691061873bba08de6d559f9babec1767adabac444(i64 %v1718, i64 %v1719, i64 %v1720, i64 %v1721, i64 %v1722) nomerge, !dbg !130
  store i64 %call1723, ptr %slot196, align 8
  %v1724 = load i64, ptr %slot196, align 8
  %v1725 = load i64, ptr %slot39, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i64 %v1724, ptr %p1726, align 8, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot15, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  %ld1729 = load i32, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1729, ptr %slot197, align 8
  %v1730 = load i32, ptr %slot197, align 8
  %cv1731 = zext i32 %v1730 to i64
  %cond1732 = icmp ne i64 %cv1731, 0
  br i1 %cond1732, label %bb_rcslotdrop230, label %bb_rcslotdone230
bb_rcslotdrop230:
  %v1733 = load i64, ptr %slot15, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 0, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot22, align 8
  store i64 %v1735, ptr %slot198, align 8
  %v1736 = load i64, ptr %slot16, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %ld1738 = load i32, ptr %p1737, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1738, ptr %slot199, align 8
  %v1739 = load i32, ptr %slot199, align 8
  %op1740 = and i32 %v1739, 28
  store i32 %op1740, ptr %slot200, align 8
  %v1741 = load i32, ptr %slot200, align 8
  %cv1742 = zext i32 %v1741 to i64
  %cond1743 = icmp ne i64 %cv1742, 0
  br i1 %cond1743, label %bb_rcslotrole230, label %bb_rcslotowner230
bb_rcslotrole230:
  %v1744 = load i64, ptr %slot51, align 8
  store i64 %v1744, ptr %slot201, align 8
  %v1745 = load i64, ptr %slot201, align 8
  %v1746 = load i64, ptr %slot198, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v1745, i64 %v1746) nomerge, !dbg !130
  br label %bb_rcslotdone230
bb_rcslotowner230:
  %v1747 = load i64, ptr %slot51, align 8
  store i64 %v1747, ptr %slot202, align 8
  %v1748 = load i64, ptr %slot202, align 8
  %v1749 = load i64, ptr %slot198, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v1748, i64 %v1749) nomerge, !dbg !130
  br label %bb_rcslotdone230
bb_rcslotdone230:
  %v1750 = load i64, ptr %slot28, align 8
  %p1751 = inttoptr i64 %v1750 to ptr
  %ld1752 = load i64, ptr %p1751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1752, ptr %slot203, align 8
  %v1753 = load i64, ptr %slot203, align 8
  %v1754 = load i64, ptr %slot39, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  store i64 %v1753, ptr %p1755, align 8, !alias.scope !3, !noalias !4
  %v1756 = load i64, ptr %slot40, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  store i64 1, ptr %p1757, align 8, !alias.scope !3, !noalias !4
  %v1758 = load i64, ptr %slot39, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %ld1760 = load i64, ptr %p1759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1760, ptr %slot204, align 8
  %v1761 = load i64, ptr %slot40, align 8
  %p1762 = inttoptr i64 %v1761 to ptr
  %ld1763 = load i64, ptr %p1762, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1763, ptr %slot205, align 8
  %v1764 = load i64, ptr %slot1, align 8
  %v1765 = load i64, ptr %slot204, align 8
  %v1766 = load i64, ptr %slot205, align 8
  %call1767 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v1764, i64 %v1765, i64 %v1766) nomerge, !dbg !132
  store { i64, i64 } %call1767, ptr %callresult207, align 8
  %addr1768 = ptrtoint ptr %callresult207 to i64
  store i64 %addr1768, ptr %slot206, align 8
  %v1769 = load i64, ptr %slot206, align 8
  %v1770 = load i64, ptr %slot39, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  store i64 %v1769, ptr %p1771, align 8, !alias.scope !3, !noalias !4
  %v1772 = load i64, ptr %slot15, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  %ld1774 = load i32, ptr %p1773, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1774, ptr %slot208, align 8
  %v1775 = load i32, ptr %slot208, align 8
  %cv1776 = zext i32 %v1775 to i64
  %cond1777 = icmp ne i64 %cv1776, 0
  br i1 %cond1777, label %bb_rcslotdrop243, label %bb_rcslotdone243
bb_rcslotdrop243:
  %v1778 = load i64, ptr %slot15, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i32 0, ptr %p1779, align 4, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot22, align 8
  store i64 %v1780, ptr %slot209, align 8
  %v1781 = load i64, ptr %slot16, align 8
  %p1782 = inttoptr i64 %v1781 to ptr
  %ld1783 = load i32, ptr %p1782, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1783, ptr %slot210, align 8
  %v1784 = load i32, ptr %slot210, align 8
  %op1785 = and i32 %v1784, 28
  store i32 %op1785, ptr %slot211, align 8
  %v1786 = load i32, ptr %slot211, align 8
  %cv1787 = zext i32 %v1786 to i64
  %cond1788 = icmp ne i64 %cv1787, 0
  br i1 %cond1788, label %bb_rcslotrole243, label %bb_rcslotowner243
bb_rcslotrole243:
  %v1789 = load i64, ptr %slot51, align 8
  store i64 %v1789, ptr %slot212, align 8
  %v1790 = load i64, ptr %slot212, align 8
  %v1791 = load i64, ptr %slot209, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1790, i64 %v1791) nomerge, !dbg !132
  br label %bb_rcslotdone243
bb_rcslotowner243:
  %v1792 = load i64, ptr %slot51, align 8
  store i64 %v1792, ptr %slot213, align 8
  %v1793 = load i64, ptr %slot213, align 8
  %v1794 = load i64, ptr %slot209, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1793, i64 %v1794) nomerge, !dbg !132
  br label %bb_rcslotdone243
bb_rcslotdone243:
  %v1795 = load i64, ptr %slot39, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  %ld1797 = load i64, ptr %p1796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1797, ptr %slot214, align 8
  %v1798 = load i64, ptr %slot1, align 8
  %v1799 = load i64, ptr %slot214, align 8
  %call1800 = call i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64 %v1798, i64 %v1799) nomerge, !dbg !134
  store i64 %call1800, ptr %slot215, align 8
  %v1801 = load i64, ptr %slot215, align 8
  %v1802 = load i64, ptr %slot39, align 8
  %p1803 = inttoptr i64 %v1802 to ptr
  store i64 %v1801, ptr %p1803, align 8, !alias.scope !3, !noalias !4
  %v1804 = load i64, ptr %slot39, align 8
  %p1805 = inttoptr i64 %v1804 to ptr
  %ld1806 = load i64, ptr %p1805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1806, ptr %slot216, align 8
  %v1807 = load i64, ptr %slot216, align 8
  %v1808 = load i64, ptr %slot32, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  store i64 %v1807, ptr %p1809, align 8, !alias.scope !3, !noalias !4
  %v1810 = load i64, ptr %slot28, align 8
  %p1811 = inttoptr i64 %v1810 to ptr
  %ld1812 = load i64, ptr %p1811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1812, ptr %slot217, align 8
  %v1813 = load i64, ptr %slot217, align 8
  %v1814 = load i64, ptr %slot39, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  store i64 %v1813, ptr %p1815, align 8, !alias.scope !3, !noalias !4
  %v1816 = load i64, ptr %slot32, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  %ld1818 = load i64, ptr %p1817, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1818, ptr %slot218, align 8
  %v1819 = load i64, ptr %slot218, align 8
  %v1820 = load i64, ptr %slot40, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i64 %v1819, ptr %p1821, align 8, !alias.scope !3, !noalias !4
  %v1822 = load i64, ptr %slot39, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  %ld1824 = load i64, ptr %p1823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1824, ptr %slot219, align 8
  %v1825 = load i64, ptr %slot40, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %ld1827 = load i64, ptr %p1826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1827, ptr %slot220, align 8
  %v1828 = load i64, ptr %slot1, align 8
  %v1829 = load i64, ptr %slot219, align 8
  %v1830 = load i64, ptr %slot220, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult222, i64 %v1828, i64 %v1829, i64 %v1830) nomerge, !dbg !136
  %addr1831 = ptrtoint ptr %callresult222 to i64
  store i64 %addr1831, ptr %slot221, align 8
  %v1832 = load i64, ptr %slot221, align 8
  %v1833 = load i64, ptr %slot39, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  store i64 %v1832, ptr %p1834, align 8, !alias.scope !3, !noalias !4
  %v1835 = load i64, ptr %slot39, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  %ld1837 = load i64, ptr %p1836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1837, ptr %slot223, align 8
  %v1838 = load i64, ptr %slot24, align 8
  store i64 %v1838, ptr %slot224, align 8
  %v1839 = load i64, ptr %slot223, align 8
  %v1840 = load i64, ptr %slot224, align 8
  %p1841 = inttoptr i64 %v1839 to ptr
  %p1842 = inttoptr i64 %v1840 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1842, ptr %p1841, i64 24, i1 false)
  %v1843 = load i64, ptr %slot20, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  store i32 2, ptr %p1844, align 4, !alias.scope !3, !noalias !4
  %v1845 = load i64, ptr %slot19, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  store i32 1, ptr %p1846, align 4, !alias.scope !3, !noalias !4
  %v1847 = load i64, ptr %slot15, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  %ld1849 = load i32, ptr %p1848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1849, ptr %slot225, align 8
  %v1850 = load i32, ptr %slot225, align 8
  %cv1851 = zext i32 %v1850 to i64
  %cond1852 = icmp ne i64 %cv1851, 0
  br i1 %cond1852, label %bb_rcslotdrop264, label %bb_rcslotdone264
bb_rcslotdrop264:
  %v1853 = load i64, ptr %slot15, align 8
  %p1854 = inttoptr i64 %v1853 to ptr
  store i32 0, ptr %p1854, align 4, !alias.scope !3, !noalias !4
  %v1855 = load i64, ptr %slot22, align 8
  store i64 %v1855, ptr %slot226, align 8
  %v1856 = load i64, ptr %slot16, align 8
  %p1857 = inttoptr i64 %v1856 to ptr
  %ld1858 = load i32, ptr %p1857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1858, ptr %slot227, align 8
  %v1859 = load i32, ptr %slot227, align 8
  %op1860 = and i32 %v1859, 28
  store i32 %op1860, ptr %slot228, align 8
  %v1861 = load i32, ptr %slot228, align 8
  %cv1862 = zext i32 %v1861 to i64
  %cond1863 = icmp ne i64 %cv1862, 0
  br i1 %cond1863, label %bb_rcslotrole264, label %bb_rcslotowner264
bb_rcslotrole264:
  %v1864 = load i64, ptr %slot51, align 8
  store i64 %v1864, ptr %slot229, align 8
  %v1865 = load i64, ptr %slot229, align 8
  %v1866 = load i64, ptr %slot226, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1865, i64 %v1866) nomerge, !dbg !136
  br label %bb_rcslotdone264
bb_rcslotowner264:
  %v1867 = load i64, ptr %slot51, align 8
  store i64 %v1867, ptr %slot230, align 8
  %v1868 = load i64, ptr %slot230, align 8
  %v1869 = load i64, ptr %slot226, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1868, i64 %v1869) nomerge, !dbg !136
  br label %bb_rcslotdone264
bb_rcslotdone264:
  %v1870 = load i64, ptr %slot22, align 8
  store i64 %v1870, ptr %slot231, align 8
  %v1871 = load i64, ptr %slot24, align 8
  store i64 %v1871, ptr %slot232, align 8
  %v1872 = load i64, ptr %slot232, align 8
  %v1873 = load i64, ptr %slot231, align 8
  %p1874 = inttoptr i64 %v1872 to ptr
  %p1875 = inttoptr i64 %v1873 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1875, ptr %p1874, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1876 = load i64, ptr %slot16, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i32 2, ptr %p1877, align 4, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot20, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %ld1880 = load i32, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1880, ptr %slot233, align 8
  %v1881 = load i32, ptr %slot233, align 8
  %v1882 = load i64, ptr %slot16, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  store i32 %v1881, ptr %p1883, align 4, !alias.scope !3, !noalias !4
  %v1884 = load i64, ptr %slot19, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i32 0, ptr %p1885, align 4, !alias.scope !3, !noalias !4
  %v1886 = load i64, ptr %slot15, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i32 1, ptr %p1887, align 4, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot231, align 8
  %v1889 = load i64, ptr %slot39, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  store i64 %v1888, ptr %p1890, align 8, !alias.scope !3, !noalias !4
  %v1891 = load i64, ptr %slot39, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %ld1893 = load i64, ptr %p1892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1893, ptr %slot234, align 8
  %v1894 = load i64, ptr %slot24, align 8
  store i64 %v1894, ptr %slot235, align 8
  %v1895 = load i64, ptr %slot52, align 8
  store i64 %v1895, ptr %slot236, align 8
  %v1896 = load i64, ptr %slot234, align 8
  %op1897 = add i64 %v1896, 8
  store i64 %op1897, ptr %slot237, align 8
  %v1898 = load i64, ptr %slot237, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  %ld1900 = load i64, ptr %p1899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1900, ptr %slot238, align 8
  %v1901 = load i64, ptr %slot238, align 8
  %cmp1902 = icmp ne i64 %v1901, 0
  %cv1903 = zext i1 %cmp1902 to i32
  store i32 %cv1903, ptr %slot239, align 8
  %v1904 = load i32, ptr %slot239, align 8
  %cv1905 = zext i32 %v1904 to i64
  %cond1906 = icmp ne i64 %cv1905, 0
  br i1 %cond1906, label %bb_rcmoveheader285, label %bb_rcmovenext285
bb_rcmoveheader285:
  %v1907 = load i64, ptr %slot238, align 8
  %op1908 = sub i64 %v1907, 16
  store i64 %op1908, ptr %slot240, align 8
  %v1909 = load i64, ptr %slot238, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  %rgep1911 = getelementptr i8, ptr %p1910, i64 -16
  %ld1912 = load i64, ptr %rgep1911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1912, ptr %slot241, align 8
  %v1913 = load i64, ptr %slot241, align 8
  %op1914 = and i64 %v1913, 5764607523034234881
  store i64 %op1914, ptr %slot242, align 8
  %v1915 = load i64, ptr %slot242, align 8
  %cmp1916 = icmp ne i64 %v1915, 0
  %cv1917 = zext i1 %cmp1916 to i32
  store i32 %cv1917, ptr %slot243, align 8
  %v1918 = load i32, ptr %slot243, align 8
  %cv1919 = zext i32 %v1918 to i64
  %cond1920 = icmp ne i64 %cv1919, 0
  br i1 %cond1920, label %bb_rcmoveslow282, label %bb_rcmovenext285
bb_rcmovenext285:
  %v1921 = load i64, ptr %slot234, align 8
  %v1922 = load i64, ptr %slot235, align 8
  %p1923 = inttoptr i64 %v1921 to ptr
  %p1924 = inttoptr i64 %v1922 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1924, ptr %p1923, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1925 = load i64, ptr %slot234, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  store i64 0, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  %v1927 = load i64, ptr %slot234, align 8
  %op1928 = add i64 %v1927, 8
  store i64 %op1928, ptr %slot244, align 8
  %v1929 = load i64, ptr %slot244, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  store i64 0, ptr %p1930, align 8, !alias.scope !3, !noalias !4
  %v1931 = load i64, ptr %slot234, align 8
  %op1932 = add i64 %v1931, 16
  store i64 %op1932, ptr %slot245, align 8
  %v1933 = load i64, ptr %slot245, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  store i64 0, ptr %p1934, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved282
bb_rcmoveslow282:
  %v1935 = load i64, ptr %slot51, align 8
  %v1936 = load i64, ptr %slot235, align 8
  %v1937 = load i64, ptr %slot234, align 8
  %v1938 = load i64, ptr %slot236, align 8
  %cv1939 = trunc i64 %v1938 to i32
  %call1940 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v1935, i64 %v1936, i64 %v1937, i32 %cv1939) nomerge, !dbg !138
  store i32 %call1940, ptr %slot246, align 8
  %v1941 = load i32, ptr %slot246, align 8
  %cv1942 = zext i32 %v1941 to i64
  %cond1943 = icmp ne i64 %cv1942, 0
  br i1 %cond1943, label %bb_rcsuccess294, label %bb_rcfailure294
bb_rcfailure294:
  %v1944 = load i64, ptr %slot51, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  %call1946 = call i32 @myl_rc_take_failure(ptr %p1945) nomerge, !dbg !138
  store i32 %call1946, ptr %slot247, align 8
  %v1947 = load i64, ptr %slot1, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  %v1949 = load i32, ptr %slot247, align 8
  %call1950 = call i32 @myl_qbe_rc_status(ptr %p1948, i32 %v1949) nomerge, !dbg !138
  store i32 %call1950, ptr %slot248, align 8
  br label %bb_failure
bb_rcsuccess294:
  br label %bb_rcmoved282
bb_rcmoved282:
  %v1951 = load i64, ptr %slot15, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  store i32 0, ptr %p1952, align 4, !alias.scope !3, !noalias !4
  %v1953 = load i64, ptr %slot20, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i32 2, ptr %p1954, align 4, !alias.scope !3, !noalias !4
  %v1955 = load i64, ptr %slot19, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  store i32 1, ptr %p1956, align 4, !alias.scope !3, !noalias !4
  %v1957 = load i64, ptr %slot7, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  %ld1959 = load i32, ptr %p1958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1959, ptr %slot249, align 8
  %v1960 = load i32, ptr %slot249, align 8
  %cv1961 = zext i32 %v1960 to i64
  %cond1962 = icmp ne i64 %cv1961, 0
  br i1 %cond1962, label %bb_rcslotdrop303, label %bb_rcslotdone303
bb_rcslotdrop303:
  %v1963 = load i64, ptr %slot7, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  store i32 0, ptr %p1964, align 4, !alias.scope !3, !noalias !4
  %v1965 = load i64, ptr %slot33, align 8
  store i64 %v1965, ptr %slot250, align 8
  %v1966 = load i64, ptr %slot8, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  %ld1968 = load i32, ptr %p1967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1968, ptr %slot251, align 8
  %v1969 = load i32, ptr %slot251, align 8
  %op1970 = and i32 %v1969, 28
  store i32 %op1970, ptr %slot252, align 8
  %v1971 = load i32, ptr %slot252, align 8
  %cv1972 = zext i32 %v1971 to i64
  %cond1973 = icmp ne i64 %cv1972, 0
  br i1 %cond1973, label %bb_rcslotrole303, label %bb_rcslotowner303
bb_rcslotrole303:
  %v1974 = load i64, ptr %slot51, align 8
  store i64 %v1974, ptr %slot253, align 8
  %v1975 = load i64, ptr %slot253, align 8
  %v1976 = load i64, ptr %slot250, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1975, i64 %v1976) nomerge, !dbg !138
  br label %bb_rcslotdone303
bb_rcslotowner303:
  %v1977 = load i64, ptr %slot250, align 8
  %p1979 = inttoptr i64 %v1977 to ptr
  %gep1980 = getelementptr i8, ptr %p1979, i64 8
  %op1978 = ptrtoint ptr %gep1980 to i64
  store i64 %op1978, ptr %slot254, align 8
  %v1981 = load i64, ptr %slot51, align 8
  store i64 %v1981, ptr %slot255, align 8
  %v1982 = load i64, ptr %slot254, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  %ld1984 = load i64, ptr %p1983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1984, ptr %slot256, align 8
  %v1985 = load i64, ptr %slot256, align 8
  %cmp1986 = icmp ne i64 %v1985, 0
  %cv1987 = zext i1 %cmp1986 to i32
  store i32 %cv1987, ptr %slot257, align 8
  %v1988 = load i32, ptr %slot257, align 8
  %cv1989 = zext i32 %v1988 to i64
  %cond1990 = icmp ne i64 %cv1989, 0
  br i1 %cond1990, label %bb_rcgnn321, label %bb_rcgdone321
bb_rcgnn321:
  %v1991 = load i64, ptr %slot256, align 8
  %op1992 = sub i64 %v1991, 16
  store i64 %op1992, ptr %slot258, align 8
  %v1993 = load i64, ptr %slot256, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  %rgep1995 = getelementptr i8, ptr %p1994, i64 -16
  %ld1996 = load i64, ptr %rgep1995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1996, ptr %slot259, align 8
  %v1997 = load i64, ptr %slot259, align 8
  %op1998 = and i64 %v1997, 4611686018427387906
  store i64 %op1998, ptr %slot260, align 8
  %v1999 = load i64, ptr %slot260, align 8
  %cmp2000 = icmp ne i64 %v1999, 0
  %cv2001 = zext i1 %cmp2000 to i32
  store i32 %cv2001, ptr %slot261, align 8
  %v2002 = load i32, ptr %slot261, align 8
  %cv2003 = zext i32 %v2002 to i64
  %cond2004 = icmp ne i64 %cv2003, 0
  br i1 %cond2004, label %bb_rcgclear321, label %bb_rcgcounted321
bb_rcgcounted321:
  %v2005 = load i64, ptr %slot256, align 8
  %op2006 = sub i64 %v2005, 32
  store i64 %op2006, ptr %slot262, align 8
  %v2007 = load i64, ptr %slot256, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  %rgep2009 = getelementptr i8, ptr %p2008, i64 -32
  %ld2010 = load i64, ptr %rgep2009, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2010, ptr %slot263, align 8
  %v2011 = load i64, ptr %slot263, align 8
  %op2012 = sub i64 %v2011, 1
  store i64 %op2012, ptr %slot264, align 8
  %v2013 = load i64, ptr %slot264, align 8
  %cmp2014 = icmp eq i64 %v2013, 0
  %cv2015 = zext i1 %cmp2014 to i32
  store i32 %cv2015, ptr %slot265, align 8
  %v2016 = load i32, ptr %slot265, align 8
  %cv2017 = zext i32 %v2016 to i64
  %cond2018 = icmp ne i64 %cv2017, 0
  br i1 %cond2018, label %bb_rcglast321, label %bb_rcgdec321
bb_rcglast321:
  %v2019 = load i64, ptr %slot256, align 8
  %op2020 = sub i64 %v2019, 24
  store i64 %op2020, ptr %slot266, align 8
  %v2021 = load i64, ptr %slot256, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  %rgep2023 = getelementptr i8, ptr %p2022, i64 -24
  %ld2024 = load i64, ptr %rgep2023, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2024, ptr %slot267, align 8
  %v2025 = load i64, ptr %slot267, align 8
  %cmp2026 = icmp ne i64 %v2025, 0
  %cv2027 = zext i1 %cmp2026 to i32
  store i32 %cv2027, ptr %slot268, align 8
  %v2028 = load i32, ptr %slot268, align 8
  %cv2029 = zext i32 %v2028 to i64
  %cond2030 = icmp ne i64 %cv2029, 0
  br i1 %cond2030, label %bb_rcgdec321, label %bb_rcgslow321
bb_rcgslow321:
  %v2031 = load i64, ptr %slot255, align 8
  %v2032 = load i64, ptr %slot254, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2031, i64 %v2032) nomerge, !dbg !138
  br label %bb_rcgdone321
bb_rcgdec321:
  %v2033 = load i64, ptr %slot264, align 8
  %v2034 = load i64, ptr %slot256, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %rgep2036 = getelementptr i8, ptr %p2035, i64 -32
  store i64 %v2033, ptr %rgep2036, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear321
bb_rcgclear321:
  %v2037 = load i64, ptr %slot254, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  store i64 0, ptr %p2038, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone321
bb_rcgdone321:
  %v2039 = load i64, ptr %slot250, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  store i64 0, ptr %p2040, align 8, !alias.scope !3, !noalias !4
  %v2041 = load i64, ptr %slot250, align 8
  %p2043 = inttoptr i64 %v2041 to ptr
  %gep2044 = getelementptr i8, ptr %p2043, i64 8
  %op2042 = ptrtoint ptr %gep2044 to i64
  store i64 %op2042, ptr %slot269, align 8
  %v2045 = load i64, ptr %slot269, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  store i64 0, ptr %p2046, align 8, !alias.scope !3, !noalias !4
  %v2047 = load i64, ptr %slot250, align 8
  %p2049 = inttoptr i64 %v2047 to ptr
  %gep2050 = getelementptr i8, ptr %p2049, i64 16
  %op2048 = ptrtoint ptr %gep2050 to i64
  store i64 %op2048, ptr %slot270, align 8
  %v2051 = load i64, ptr %slot270, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  store i64 0, ptr %p2052, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone303
bb_rcslotdone303:
  %v2053 = load i64, ptr %slot33, align 8
  store i64 %v2053, ptr %slot271, align 8
  %v2054 = load i64, ptr %slot24, align 8
  store i64 %v2054, ptr %slot272, align 8
  %v2055 = load i64, ptr %slot272, align 8
  %v2056 = load i64, ptr %slot271, align 8
  %p2057 = inttoptr i64 %v2055 to ptr
  %p2058 = inttoptr i64 %v2056 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2058, ptr %p2057, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2059 = load i64, ptr %slot19, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  store i32 0, ptr %p2060, align 4, !alias.scope !3, !noalias !4
  %v2061 = load i64, ptr %slot8, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  store i32 2, ptr %p2062, align 4, !alias.scope !3, !noalias !4
  %v2063 = load i64, ptr %slot20, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  %ld2065 = load i32, ptr %p2064, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2065, ptr %slot273, align 8
  %v2066 = load i32, ptr %slot273, align 8
  %v2067 = load i64, ptr %slot8, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  store i32 %v2066, ptr %p2068, align 4, !alias.scope !3, !noalias !4
  %v2069 = load i64, ptr %slot7, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  store i32 1, ptr %p2070, align 4, !alias.scope !3, !noalias !4
  %v2071 = load i64, ptr %slot31, align 8
  %v2072 = load i64, ptr %slot39, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  store i64 %v2071, ptr %p2073, align 8, !alias.scope !3, !noalias !4
  %v2074 = load i64, ptr %slot39, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %ld2076 = load i64, ptr %p2075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2076, ptr %slot274, align 8
  %v2077 = load i64, ptr %slot15, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  %ld2079 = load i32, ptr %p2078, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2079, ptr %slot275, align 8
  %v2080 = load i64, ptr %slot16, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  %ld2082 = load i32, ptr %p2081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2082, ptr %slot276, align 8
  %v2083 = load i32, ptr %slot276, align 8
  %op2084 = and i32 %v2083, 24
  store i32 %op2084, ptr %slot276, align 8
  %v2085 = load i32, ptr %slot276, align 8
  %cmp2086 = icmp eq i32 %v2085, 0
  %cv2087 = zext i1 %cmp2086 to i32
  store i32 %cv2087, ptr %slot277, align 8
  %v2088 = load i32, ptr %slot275, align 8
  %v2089 = load i32, ptr %slot277, align 8
  %op2090 = and i32 %v2088, %v2089
  store i32 %op2090, ptr %slot278, align 8
  %v2091 = load i32, ptr %slot278, align 8
  %cv2092 = zext i32 %v2091 to i64
  %cond2093 = icmp ne i64 %cv2092, 0
  br i1 %cond2093, label %bb_rcprivateown341, label %bb_rcprivateloan341
bb_rcprivateown341:
  %v2094 = load i64, ptr %slot24, align 8
  store i64 %v2094, ptr %slot279, align 8
  %v2095 = load i64, ptr %slot52, align 8
  store i64 %v2095, ptr %slot280, align 8
  %v2096 = load i64, ptr %slot274, align 8
  %v2097 = load i64, ptr %slot279, align 8
  %op2098 = sub i64 %v2096, %v2097
  store i64 %op2098, ptr %slot281, align 8
  %v2099 = load i64, ptr %slot279, align 8
  %v2100 = load i64, ptr %slot274, align 8
  %op2101 = sub i64 %v2099, %v2100
  store i64 %op2101, ptr %slot282, align 8
  %v2102 = load i64, ptr %slot281, align 8
  %cmp2103 = icmp ult i64 %v2102, 16
  %cv2104 = zext i1 %cmp2103 to i32
  store i32 %cv2104, ptr %slot283, align 8
  %v2105 = load i64, ptr %slot282, align 8
  %cmp2106 = icmp ult i64 %v2105, 16
  %cv2107 = zext i1 %cmp2106 to i32
  store i32 %cv2107, ptr %slot284, align 8
  %v2108 = load i32, ptr %slot283, align 8
  %v2109 = load i32, ptr %slot284, align 8
  %op2110 = or i32 %v2108, %v2109
  store i32 %op2110, ptr %slot285, align 8
  %v2111 = load i32, ptr %slot285, align 8
  %cv2112 = zext i32 %v2111 to i64
  %cond2113 = icmp ne i64 %cv2112, 0
  br i1 %cond2113, label %bb_rcmoveslow344, label %bb_rcmovecheck344
bb_rcmovecheck344:
  %v2114 = load i64, ptr %slot274, align 8
  %op2115 = add i64 %v2114, 0
  store i64 %op2115, ptr %slot286, align 8
  %v2116 = load i64, ptr %slot286, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  %ld2118 = load i64, ptr %p2117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2118, ptr %slot287, align 8
  %v2119 = load i64, ptr %slot287, align 8
  %cmp2120 = icmp ne i64 %v2119, 0
  %cv2121 = zext i1 %cmp2120 to i32
  store i32 %cv2121, ptr %slot288, align 8
  %v2122 = load i32, ptr %slot288, align 8
  %cv2123 = zext i32 %v2122 to i64
  %cond2124 = icmp ne i64 %cv2123, 0
  br i1 %cond2124, label %bb_rcmoveheader352, label %bb_rcmovenext352
bb_rcmoveheader352:
  %v2125 = load i64, ptr %slot287, align 8
  %op2126 = sub i64 %v2125, 16
  store i64 %op2126, ptr %slot289, align 8
  %v2127 = load i64, ptr %slot287, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  %rgep2129 = getelementptr i8, ptr %p2128, i64 -16
  %ld2130 = load i64, ptr %rgep2129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2130, ptr %slot290, align 8
  %v2131 = load i64, ptr %slot290, align 8
  %op2132 = and i64 %v2131, 5764607523034234881
  store i64 %op2132, ptr %slot291, align 8
  %v2133 = load i64, ptr %slot291, align 8
  %cmp2134 = icmp ne i64 %v2133, 0
  %cv2135 = zext i1 %cmp2134 to i32
  store i32 %cv2135, ptr %slot292, align 8
  %v2136 = load i32, ptr %slot292, align 8
  %cv2137 = zext i32 %v2136 to i64
  %cond2138 = icmp ne i64 %cv2137, 0
  br i1 %cond2138, label %bb_rcmoveslow344, label %bb_rcmovenext352
bb_rcmovenext352:
  %v2139 = load i64, ptr %slot274, align 8
  %v2140 = load i64, ptr %slot279, align 8
  %p2141 = inttoptr i64 %v2139 to ptr
  %p2142 = inttoptr i64 %v2140 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2142, ptr %p2141, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2143 = load i64, ptr %slot274, align 8
  %p2144 = inttoptr i64 %v2143 to ptr
  store i64 0, ptr %p2144, align 8, !alias.scope !3, !noalias !4
  %v2145 = load i64, ptr %slot274, align 8
  %op2146 = add i64 %v2145, 8
  store i64 %op2146, ptr %slot293, align 8
  %v2147 = load i64, ptr %slot293, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  store i64 0, ptr %p2148, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved344
bb_rcmoveslow344:
  %v2149 = load i64, ptr %slot51, align 8
  %v2150 = load i64, ptr %slot279, align 8
  %v2151 = load i64, ptr %slot274, align 8
  %v2152 = load i64, ptr %slot280, align 8
  %cv2153 = trunc i64 %v2152 to i32
  %call2154 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v2149, i64 %v2150, i64 %v2151, i32 %cv2153) nomerge, !dbg !140
  store i32 %call2154, ptr %slot294, align 8
  %v2155 = load i32, ptr %slot294, align 8
  %cv2156 = zext i32 %v2155 to i64
  %cond2157 = icmp ne i64 %cv2156, 0
  br i1 %cond2157, label %bb_rcsuccess360, label %bb_rcfailure360
bb_rcfailure360:
  %v2158 = load i64, ptr %slot51, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  %call2160 = call i32 @myl_rc_take_failure(ptr %p2159) nomerge, !dbg !140
  store i32 %call2160, ptr %slot295, align 8
  %v2161 = load i64, ptr %slot1, align 8
  %p2162 = inttoptr i64 %v2161 to ptr
  %v2163 = load i32, ptr %slot295, align 8
  %call2164 = call i32 @myl_qbe_rc_status(ptr %p2162, i32 %v2163) nomerge, !dbg !140
  store i32 %call2164, ptr %slot296, align 8
  br label %bb_failure
bb_rcsuccess360:
  br label %bb_rcmoved344
bb_rcmoved344:
  %v2165 = load i64, ptr %slot15, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  store i32 0, ptr %p2166, align 4, !alias.scope !3, !noalias !4
  %v2167 = load i64, ptr %slot20, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  store i32 2, ptr %p2168, align 4, !alias.scope !3, !noalias !4
  %v2169 = load i64, ptr %slot19, align 8
  %p2170 = inttoptr i64 %v2169 to ptr
  store i32 1, ptr %p2170, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared341
bb_rcprivateloan341:
  %v2171 = load i64, ptr %slot24, align 8
  store i64 %v2171, ptr %slot297, align 8
  %v2172 = load i64, ptr %slot51, align 8
  %v2173 = load i64, ptr %slot297, align 8
  %v2174 = load i64, ptr %slot274, align 8
  %call2175 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v2172, i64 %v2173, i64 %v2174) nomerge, !dbg !140
  store i32 %call2175, ptr %slot298, align 8
  %v2176 = load i32, ptr %slot298, align 8
  %cv2177 = zext i32 %v2176 to i64
  %cond2178 = icmp ne i64 %cv2177, 0
  br i1 %cond2178, label %bb_rcsuccess368, label %bb_rcfailure368
bb_rcfailure368:
  %v2179 = load i64, ptr %slot51, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  %call2181 = call i32 @myl_rc_take_failure(ptr %p2180) nomerge, !dbg !140
  store i32 %call2181, ptr %slot299, align 8
  %v2182 = load i64, ptr %slot1, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  %v2184 = load i32, ptr %slot299, align 8
  %call2185 = call i32 @myl_qbe_rc_status(ptr %p2183, i32 %v2184) nomerge, !dbg !140
  store i32 %call2185, ptr %slot300, align 8
  br label %bb_failure
bb_rcsuccess368:
  %v2186 = load i64, ptr %slot20, align 8
  %p2187 = inttoptr i64 %v2186 to ptr
  store i32 2, ptr %p2187, align 4, !alias.scope !3, !noalias !4
  %v2188 = load i64, ptr %slot20, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  store i32 16, ptr %p2189, align 4, !alias.scope !3, !noalias !4
  %v2190 = load i64, ptr %slot19, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  store i32 1, ptr %p2191, align 4, !alias.scope !3, !noalias !4
  %v2192 = load i64, ptr %slot15, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %ld2194 = load i32, ptr %p2193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2194, ptr %slot301, align 8
  %v2195 = load i32, ptr %slot301, align 8
  %cv2196 = zext i32 %v2195 to i64
  %cond2197 = icmp ne i64 %cv2196, 0
  br i1 %cond2197, label %bb_rcslotdrop376, label %bb_rcslotdone376
bb_rcslotdrop376:
  %v2198 = load i64, ptr %slot15, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  store i32 0, ptr %p2199, align 4, !alias.scope !3, !noalias !4
  %v2200 = load i64, ptr %slot22, align 8
  store i64 %v2200, ptr %slot302, align 8
  %v2201 = load i64, ptr %slot16, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  %ld2203 = load i32, ptr %p2202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2203, ptr %slot303, align 8
  %v2204 = load i32, ptr %slot303, align 8
  %op2205 = and i32 %v2204, 28
  store i32 %op2205, ptr %slot304, align 8
  %v2206 = load i32, ptr %slot304, align 8
  %cv2207 = zext i32 %v2206 to i64
  %cond2208 = icmp ne i64 %cv2207, 0
  br i1 %cond2208, label %bb_rcslotrole376, label %bb_rcslotowner376
bb_rcslotrole376:
  %v2209 = load i64, ptr %slot51, align 8
  store i64 %v2209, ptr %slot305, align 8
  %v2210 = load i64, ptr %slot305, align 8
  %v2211 = load i64, ptr %slot302, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2210, i64 %v2211) nomerge, !dbg !140
  br label %bb_rcslotdone376
bb_rcslotowner376:
  %v2212 = load i64, ptr %slot302, align 8
  %p2214 = inttoptr i64 %v2212 to ptr
  %gep2215 = getelementptr i8, ptr %p2214, i64 0
  %op2213 = ptrtoint ptr %gep2215 to i64
  store i64 %op2213, ptr %slot306, align 8
  %v2216 = load i64, ptr %slot51, align 8
  store i64 %v2216, ptr %slot307, align 8
  %v2217 = load i64, ptr %slot306, align 8
  %p2218 = inttoptr i64 %v2217 to ptr
  %ld2219 = load i64, ptr %p2218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2219, ptr %slot308, align 8
  %v2220 = load i64, ptr %slot308, align 8
  %cmp2221 = icmp ne i64 %v2220, 0
  %cv2222 = zext i1 %cmp2221 to i32
  store i32 %cv2222, ptr %slot309, align 8
  %v2223 = load i32, ptr %slot309, align 8
  %cv2224 = zext i32 %v2223 to i64
  %cond2225 = icmp ne i64 %cv2224, 0
  br i1 %cond2225, label %bb_rcgnn394, label %bb_rcgdone394
bb_rcgnn394:
  %v2226 = load i64, ptr %slot308, align 8
  %op2227 = sub i64 %v2226, 16
  store i64 %op2227, ptr %slot310, align 8
  %v2228 = load i64, ptr %slot308, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  %rgep2230 = getelementptr i8, ptr %p2229, i64 -16
  %ld2231 = load i64, ptr %rgep2230, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2231, ptr %slot311, align 8
  %v2232 = load i64, ptr %slot311, align 8
  %op2233 = and i64 %v2232, 4611686018427387906
  store i64 %op2233, ptr %slot312, align 8
  %v2234 = load i64, ptr %slot312, align 8
  %cmp2235 = icmp ne i64 %v2234, 0
  %cv2236 = zext i1 %cmp2235 to i32
  store i32 %cv2236, ptr %slot313, align 8
  %v2237 = load i32, ptr %slot313, align 8
  %cv2238 = zext i32 %v2237 to i64
  %cond2239 = icmp ne i64 %cv2238, 0
  br i1 %cond2239, label %bb_rcgclear394, label %bb_rcgcounted394
bb_rcgcounted394:
  %v2240 = load i64, ptr %slot308, align 8
  %op2241 = sub i64 %v2240, 32
  store i64 %op2241, ptr %slot314, align 8
  %v2242 = load i64, ptr %slot308, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  %rgep2244 = getelementptr i8, ptr %p2243, i64 -32
  %ld2245 = load i64, ptr %rgep2244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2245, ptr %slot315, align 8
  %v2246 = load i64, ptr %slot315, align 8
  %op2247 = sub i64 %v2246, 1
  store i64 %op2247, ptr %slot316, align 8
  %v2248 = load i64, ptr %slot316, align 8
  %cmp2249 = icmp eq i64 %v2248, 0
  %cv2250 = zext i1 %cmp2249 to i32
  store i32 %cv2250, ptr %slot317, align 8
  %v2251 = load i32, ptr %slot317, align 8
  %cv2252 = zext i32 %v2251 to i64
  %cond2253 = icmp ne i64 %cv2252, 0
  br i1 %cond2253, label %bb_rcglast394, label %bb_rcgdec394
bb_rcglast394:
  %v2254 = load i64, ptr %slot308, align 8
  %op2255 = sub i64 %v2254, 24
  store i64 %op2255, ptr %slot318, align 8
  %v2256 = load i64, ptr %slot308, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %rgep2258 = getelementptr i8, ptr %p2257, i64 -24
  %ld2259 = load i64, ptr %rgep2258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2259, ptr %slot319, align 8
  %v2260 = load i64, ptr %slot319, align 8
  %cmp2261 = icmp ne i64 %v2260, 0
  %cv2262 = zext i1 %cmp2261 to i32
  store i32 %cv2262, ptr %slot320, align 8
  %v2263 = load i32, ptr %slot320, align 8
  %cv2264 = zext i32 %v2263 to i64
  %cond2265 = icmp ne i64 %cv2264, 0
  br i1 %cond2265, label %bb_rcgdec394, label %bb_rcgslow394
bb_rcgslow394:
  %v2266 = load i64, ptr %slot307, align 8
  %v2267 = load i64, ptr %slot306, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2266, i64 %v2267) nomerge, !dbg !140
  br label %bb_rcgdone394
bb_rcgdec394:
  %v2268 = load i64, ptr %slot316, align 8
  %v2269 = load i64, ptr %slot308, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  %rgep2271 = getelementptr i8, ptr %p2270, i64 -32
  store i64 %v2268, ptr %rgep2271, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear394
bb_rcgclear394:
  %v2272 = load i64, ptr %slot306, align 8
  %p2273 = inttoptr i64 %v2272 to ptr
  store i64 0, ptr %p2273, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone394
bb_rcgdone394:
  %v2274 = load i64, ptr %slot302, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  store i64 0, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  %v2276 = load i64, ptr %slot302, align 8
  %p2278 = inttoptr i64 %v2276 to ptr
  %gep2279 = getelementptr i8, ptr %p2278, i64 8
  %op2277 = ptrtoint ptr %gep2279 to i64
  store i64 %op2277, ptr %slot321, align 8
  %v2280 = load i64, ptr %slot321, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  store i64 0, ptr %p2281, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone376
bb_rcslotdone376:
  br label %bb_rcprivateprepared341
bb_rcprivateprepared341:
  %v2282 = load i64, ptr %slot11, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  %ld2284 = load i32, ptr %p2283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2284, ptr %slot322, align 8
  %v2285 = load i32, ptr %slot322, align 8
  %cv2286 = zext i32 %v2285 to i64
  %cond2287 = icmp ne i64 %cv2286, 0
  br i1 %cond2287, label %bb_rcslotdrop402, label %bb_rcslotdone402
bb_rcslotdrop402:
  %v2288 = load i64, ptr %slot11, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i32 0, ptr %p2289, align 4, !alias.scope !3, !noalias !4
  %v2290 = load i64, ptr %slot35, align 8
  store i64 %v2290, ptr %slot323, align 8
  %v2291 = load i64, ptr %slot12, align 8
  %p2292 = inttoptr i64 %v2291 to ptr
  %ld2293 = load i32, ptr %p2292, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2293, ptr %slot324, align 8
  %v2294 = load i32, ptr %slot324, align 8
  %op2295 = and i32 %v2294, 28
  store i32 %op2295, ptr %slot325, align 8
  %v2296 = load i32, ptr %slot325, align 8
  %cv2297 = zext i32 %v2296 to i64
  %cond2298 = icmp ne i64 %cv2297, 0
  br i1 %cond2298, label %bb_rcslotrole402, label %bb_rcslotowner402
bb_rcslotrole402:
  %v2299 = load i64, ptr %slot51, align 8
  store i64 %v2299, ptr %slot326, align 8
  %v2300 = load i64, ptr %slot326, align 8
  %v2301 = load i64, ptr %slot323, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2300, i64 %v2301) nomerge, !dbg !140
  br label %bb_rcslotdone402
bb_rcslotowner402:
  %v2302 = load i64, ptr %slot323, align 8
  %p2304 = inttoptr i64 %v2302 to ptr
  %gep2305 = getelementptr i8, ptr %p2304, i64 0
  %op2303 = ptrtoint ptr %gep2305 to i64
  store i64 %op2303, ptr %slot327, align 8
  %v2306 = load i64, ptr %slot51, align 8
  store i64 %v2306, ptr %slot328, align 8
  %v2307 = load i64, ptr %slot327, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  %ld2309 = load i64, ptr %p2308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2309, ptr %slot329, align 8
  %v2310 = load i64, ptr %slot329, align 8
  %cmp2311 = icmp ne i64 %v2310, 0
  %cv2312 = zext i1 %cmp2311 to i32
  store i32 %cv2312, ptr %slot330, align 8
  %v2313 = load i32, ptr %slot330, align 8
  %cv2314 = zext i32 %v2313 to i64
  %cond2315 = icmp ne i64 %cv2314, 0
  br i1 %cond2315, label %bb_rcgnn420, label %bb_rcgdone420
bb_rcgnn420:
  %v2316 = load i64, ptr %slot329, align 8
  %op2317 = sub i64 %v2316, 16
  store i64 %op2317, ptr %slot331, align 8
  %v2318 = load i64, ptr %slot329, align 8
  %p2319 = inttoptr i64 %v2318 to ptr
  %rgep2320 = getelementptr i8, ptr %p2319, i64 -16
  %ld2321 = load i64, ptr %rgep2320, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2321, ptr %slot332, align 8
  %v2322 = load i64, ptr %slot332, align 8
  %op2323 = and i64 %v2322, 4611686018427387906
  store i64 %op2323, ptr %slot333, align 8
  %v2324 = load i64, ptr %slot333, align 8
  %cmp2325 = icmp ne i64 %v2324, 0
  %cv2326 = zext i1 %cmp2325 to i32
  store i32 %cv2326, ptr %slot334, align 8
  %v2327 = load i32, ptr %slot334, align 8
  %cv2328 = zext i32 %v2327 to i64
  %cond2329 = icmp ne i64 %cv2328, 0
  br i1 %cond2329, label %bb_rcgclear420, label %bb_rcgcounted420
bb_rcgcounted420:
  %v2330 = load i64, ptr %slot329, align 8
  %op2331 = sub i64 %v2330, 32
  store i64 %op2331, ptr %slot335, align 8
  %v2332 = load i64, ptr %slot329, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  %rgep2334 = getelementptr i8, ptr %p2333, i64 -32
  %ld2335 = load i64, ptr %rgep2334, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2335, ptr %slot336, align 8
  %v2336 = load i64, ptr %slot336, align 8
  %op2337 = sub i64 %v2336, 1
  store i64 %op2337, ptr %slot337, align 8
  %v2338 = load i64, ptr %slot337, align 8
  %cmp2339 = icmp eq i64 %v2338, 0
  %cv2340 = zext i1 %cmp2339 to i32
  store i32 %cv2340, ptr %slot338, align 8
  %v2341 = load i32, ptr %slot338, align 8
  %cv2342 = zext i32 %v2341 to i64
  %cond2343 = icmp ne i64 %cv2342, 0
  br i1 %cond2343, label %bb_rcglast420, label %bb_rcgdec420
bb_rcglast420:
  %v2344 = load i64, ptr %slot329, align 8
  %op2345 = sub i64 %v2344, 24
  store i64 %op2345, ptr %slot339, align 8
  %v2346 = load i64, ptr %slot329, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %rgep2348 = getelementptr i8, ptr %p2347, i64 -24
  %ld2349 = load i64, ptr %rgep2348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2349, ptr %slot340, align 8
  %v2350 = load i64, ptr %slot340, align 8
  %cmp2351 = icmp ne i64 %v2350, 0
  %cv2352 = zext i1 %cmp2351 to i32
  store i32 %cv2352, ptr %slot341, align 8
  %v2353 = load i32, ptr %slot341, align 8
  %cv2354 = zext i32 %v2353 to i64
  %cond2355 = icmp ne i64 %cv2354, 0
  br i1 %cond2355, label %bb_rcgdec420, label %bb_rcgslow420
bb_rcgslow420:
  %v2356 = load i64, ptr %slot328, align 8
  %v2357 = load i64, ptr %slot327, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2356, i64 %v2357) nomerge, !dbg !140
  br label %bb_rcgdone420
bb_rcgdec420:
  %v2358 = load i64, ptr %slot337, align 8
  %v2359 = load i64, ptr %slot329, align 8
  %p2360 = inttoptr i64 %v2359 to ptr
  %rgep2361 = getelementptr i8, ptr %p2360, i64 -32
  store i64 %v2358, ptr %rgep2361, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear420
bb_rcgclear420:
  %v2362 = load i64, ptr %slot327, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  store i64 0, ptr %p2363, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone420
bb_rcgdone420:
  %v2364 = load i64, ptr %slot323, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  store i64 0, ptr %p2365, align 8, !alias.scope !3, !noalias !4
  %v2366 = load i64, ptr %slot323, align 8
  %p2368 = inttoptr i64 %v2366 to ptr
  %gep2369 = getelementptr i8, ptr %p2368, i64 8
  %op2367 = ptrtoint ptr %gep2369 to i64
  store i64 %op2367, ptr %slot342, align 8
  %v2370 = load i64, ptr %slot342, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  store i64 0, ptr %p2371, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone402
bb_rcslotdone402:
  %v2372 = load i64, ptr %slot35, align 8
  store i64 %v2372, ptr %slot343, align 8
  %v2373 = load i64, ptr %slot24, align 8
  store i64 %v2373, ptr %slot344, align 8
  %v2374 = load i64, ptr %slot344, align 8
  %v2375 = load i64, ptr %slot343, align 8
  %p2376 = inttoptr i64 %v2374 to ptr
  %p2377 = inttoptr i64 %v2375 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2377, ptr %p2376, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2378 = load i64, ptr %slot19, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  store i32 0, ptr %p2379, align 4, !alias.scope !3, !noalias !4
  %v2380 = load i64, ptr %slot12, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  store i32 2, ptr %p2381, align 4, !alias.scope !3, !noalias !4
  %v2382 = load i64, ptr %slot20, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  %ld2384 = load i32, ptr %p2383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2384, ptr %slot345, align 8
  %v2385 = load i32, ptr %slot345, align 8
  %v2386 = load i64, ptr %slot12, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  store i32 %v2385, ptr %p2387, align 4, !alias.scope !3, !noalias !4
  %v2388 = load i64, ptr %slot11, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  store i32 1, ptr %p2389, align 4, !alias.scope !3, !noalias !4
  %v2390 = load i64, ptr %slot33, align 8
  %v2391 = load i64, ptr %slot39, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  store i64 %v2390, ptr %p2392, align 8, !alias.scope !3, !noalias !4
  %v2393 = load i64, ptr %slot39, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  %ld2395 = load i64, ptr %p2394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2395, ptr %slot346, align 8
  %v2396 = load i64, ptr %slot15, align 8
  %p2397 = inttoptr i64 %v2396 to ptr
  %ld2398 = load i32, ptr %p2397, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2398, ptr %slot347, align 8
  %v2399 = load i64, ptr %slot16, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %ld2401 = load i32, ptr %p2400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2401, ptr %slot348, align 8
  %v2402 = load i32, ptr %slot348, align 8
  %op2403 = and i32 %v2402, 24
  store i32 %op2403, ptr %slot348, align 8
  %v2404 = load i32, ptr %slot348, align 8
  %cmp2405 = icmp eq i32 %v2404, 0
  %cv2406 = zext i1 %cmp2405 to i32
  store i32 %cv2406, ptr %slot349, align 8
  %v2407 = load i32, ptr %slot347, align 8
  %v2408 = load i32, ptr %slot349, align 8
  %op2409 = and i32 %v2407, %v2408
  store i32 %op2409, ptr %slot350, align 8
  %v2410 = load i32, ptr %slot350, align 8
  %cv2411 = zext i32 %v2410 to i64
  %cond2412 = icmp ne i64 %cv2411, 0
  br i1 %cond2412, label %bb_rcprivateown439, label %bb_rcprivateloan439
bb_rcprivateown439:
  %v2413 = load i64, ptr %slot24, align 8
  store i64 %v2413, ptr %slot351, align 8
  %v2414 = load i64, ptr %slot52, align 8
  store i64 %v2414, ptr %slot352, align 8
  %v2415 = load i64, ptr %slot346, align 8
  %v2416 = load i64, ptr %slot351, align 8
  %op2417 = sub i64 %v2415, %v2416
  store i64 %op2417, ptr %slot353, align 8
  %v2418 = load i64, ptr %slot351, align 8
  %v2419 = load i64, ptr %slot346, align 8
  %op2420 = sub i64 %v2418, %v2419
  store i64 %op2420, ptr %slot354, align 8
  %v2421 = load i64, ptr %slot353, align 8
  %cmp2422 = icmp ult i64 %v2421, 24
  %cv2423 = zext i1 %cmp2422 to i32
  store i32 %cv2423, ptr %slot355, align 8
  %v2424 = load i64, ptr %slot354, align 8
  %cmp2425 = icmp ult i64 %v2424, 24
  %cv2426 = zext i1 %cmp2425 to i32
  store i32 %cv2426, ptr %slot356, align 8
  %v2427 = load i32, ptr %slot355, align 8
  %v2428 = load i32, ptr %slot356, align 8
  %op2429 = or i32 %v2427, %v2428
  store i32 %op2429, ptr %slot357, align 8
  %v2430 = load i32, ptr %slot357, align 8
  %cv2431 = zext i32 %v2430 to i64
  %cond2432 = icmp ne i64 %cv2431, 0
  br i1 %cond2432, label %bb_rcmoveslow442, label %bb_rcmovecheck442
bb_rcmovecheck442:
  %v2433 = load i64, ptr %slot346, align 8
  %op2434 = add i64 %v2433, 8
  store i64 %op2434, ptr %slot358, align 8
  %v2435 = load i64, ptr %slot358, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  %ld2437 = load i64, ptr %p2436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2437, ptr %slot359, align 8
  %v2438 = load i64, ptr %slot359, align 8
  %cmp2439 = icmp ne i64 %v2438, 0
  %cv2440 = zext i1 %cmp2439 to i32
  store i32 %cv2440, ptr %slot360, align 8
  %v2441 = load i32, ptr %slot360, align 8
  %cv2442 = zext i32 %v2441 to i64
  %cond2443 = icmp ne i64 %cv2442, 0
  br i1 %cond2443, label %bb_rcmoveheader450, label %bb_rcmovenext450
bb_rcmoveheader450:
  %v2444 = load i64, ptr %slot359, align 8
  %op2445 = sub i64 %v2444, 16
  store i64 %op2445, ptr %slot361, align 8
  %v2446 = load i64, ptr %slot359, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  %rgep2448 = getelementptr i8, ptr %p2447, i64 -16
  %ld2449 = load i64, ptr %rgep2448, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2449, ptr %slot362, align 8
  %v2450 = load i64, ptr %slot362, align 8
  %op2451 = and i64 %v2450, 5764607523034234881
  store i64 %op2451, ptr %slot363, align 8
  %v2452 = load i64, ptr %slot363, align 8
  %cmp2453 = icmp ne i64 %v2452, 0
  %cv2454 = zext i1 %cmp2453 to i32
  store i32 %cv2454, ptr %slot364, align 8
  %v2455 = load i32, ptr %slot364, align 8
  %cv2456 = zext i32 %v2455 to i64
  %cond2457 = icmp ne i64 %cv2456, 0
  br i1 %cond2457, label %bb_rcmoveslow442, label %bb_rcmovenext450
bb_rcmovenext450:
  %v2458 = load i64, ptr %slot346, align 8
  %v2459 = load i64, ptr %slot351, align 8
  %p2460 = inttoptr i64 %v2458 to ptr
  %p2461 = inttoptr i64 %v2459 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2461, ptr %p2460, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2462 = load i64, ptr %slot346, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  store i64 0, ptr %p2463, align 8, !alias.scope !3, !noalias !4
  %v2464 = load i64, ptr %slot346, align 8
  %op2465 = add i64 %v2464, 8
  store i64 %op2465, ptr %slot365, align 8
  %v2466 = load i64, ptr %slot365, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  store i64 0, ptr %p2467, align 8, !alias.scope !3, !noalias !4
  %v2468 = load i64, ptr %slot346, align 8
  %op2469 = add i64 %v2468, 16
  store i64 %op2469, ptr %slot366, align 8
  %v2470 = load i64, ptr %slot366, align 8
  %p2471 = inttoptr i64 %v2470 to ptr
  store i64 0, ptr %p2471, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved442
bb_rcmoveslow442:
  %v2472 = load i64, ptr %slot51, align 8
  %v2473 = load i64, ptr %slot351, align 8
  %v2474 = load i64, ptr %slot346, align 8
  %v2475 = load i64, ptr %slot352, align 8
  %cv2476 = trunc i64 %v2475 to i32
  %call2477 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2472, i64 %v2473, i64 %v2474, i32 %cv2476) nomerge, !dbg !142
  store i32 %call2477, ptr %slot367, align 8
  %v2478 = load i32, ptr %slot367, align 8
  %cv2479 = zext i32 %v2478 to i64
  %cond2480 = icmp ne i64 %cv2479, 0
  br i1 %cond2480, label %bb_rcsuccess459, label %bb_rcfailure459
bb_rcfailure459:
  %v2481 = load i64, ptr %slot51, align 8
  %p2482 = inttoptr i64 %v2481 to ptr
  %call2483 = call i32 @myl_rc_take_failure(ptr %p2482) nomerge, !dbg !142
  store i32 %call2483, ptr %slot368, align 8
  %v2484 = load i64, ptr %slot1, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  %v2486 = load i32, ptr %slot368, align 8
  %call2487 = call i32 @myl_qbe_rc_status(ptr %p2485, i32 %v2486) nomerge, !dbg !142
  store i32 %call2487, ptr %slot369, align 8
  br label %bb_failure
bb_rcsuccess459:
  br label %bb_rcmoved442
bb_rcmoved442:
  %v2488 = load i64, ptr %slot15, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  store i32 0, ptr %p2489, align 4, !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot20, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  store i32 2, ptr %p2491, align 4, !alias.scope !3, !noalias !4
  %v2492 = load i64, ptr %slot19, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  store i32 1, ptr %p2493, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared439
bb_rcprivateloan439:
  %v2494 = load i64, ptr %slot24, align 8
  store i64 %v2494, ptr %slot370, align 8
  %v2495 = load i64, ptr %slot51, align 8
  %v2496 = load i64, ptr %slot370, align 8
  %v2497 = load i64, ptr %slot346, align 8
  %call2498 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64 %v2495, i64 %v2496, i64 %v2497) nomerge, !dbg !142
  store i32 %call2498, ptr %slot371, align 8
  %v2499 = load i32, ptr %slot371, align 8
  %cv2500 = zext i32 %v2499 to i64
  %cond2501 = icmp ne i64 %cv2500, 0
  br i1 %cond2501, label %bb_rcsuccess467, label %bb_rcfailure467
bb_rcfailure467:
  %v2502 = load i64, ptr %slot51, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  %call2504 = call i32 @myl_rc_take_failure(ptr %p2503) nomerge, !dbg !142
  store i32 %call2504, ptr %slot372, align 8
  %v2505 = load i64, ptr %slot1, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %v2507 = load i32, ptr %slot372, align 8
  %call2508 = call i32 @myl_qbe_rc_status(ptr %p2506, i32 %v2507) nomerge, !dbg !142
  store i32 %call2508, ptr %slot373, align 8
  br label %bb_failure
bb_rcsuccess467:
  %v2509 = load i64, ptr %slot20, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  store i32 2, ptr %p2510, align 4, !alias.scope !3, !noalias !4
  %v2511 = load i64, ptr %slot20, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  store i32 16, ptr %p2512, align 4, !alias.scope !3, !noalias !4
  %v2513 = load i64, ptr %slot19, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  store i32 1, ptr %p2514, align 4, !alias.scope !3, !noalias !4
  %v2515 = load i64, ptr %slot15, align 8
  %p2516 = inttoptr i64 %v2515 to ptr
  %ld2517 = load i32, ptr %p2516, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2517, ptr %slot374, align 8
  %v2518 = load i32, ptr %slot374, align 8
  %cv2519 = zext i32 %v2518 to i64
  %cond2520 = icmp ne i64 %cv2519, 0
  br i1 %cond2520, label %bb_rcslotdrop475, label %bb_rcslotdone475
bb_rcslotdrop475:
  %v2521 = load i64, ptr %slot15, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i32 0, ptr %p2522, align 4, !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot22, align 8
  store i64 %v2523, ptr %slot375, align 8
  %v2524 = load i64, ptr %slot16, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  %ld2526 = load i32, ptr %p2525, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2526, ptr %slot376, align 8
  %v2527 = load i32, ptr %slot376, align 8
  %op2528 = and i32 %v2527, 28
  store i32 %op2528, ptr %slot377, align 8
  %v2529 = load i32, ptr %slot377, align 8
  %cv2530 = zext i32 %v2529 to i64
  %cond2531 = icmp ne i64 %cv2530, 0
  br i1 %cond2531, label %bb_rcslotrole475, label %bb_rcslotowner475
bb_rcslotrole475:
  %v2532 = load i64, ptr %slot51, align 8
  store i64 %v2532, ptr %slot378, align 8
  %v2533 = load i64, ptr %slot378, align 8
  %v2534 = load i64, ptr %slot375, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2533, i64 %v2534) nomerge, !dbg !142
  br label %bb_rcslotdone475
bb_rcslotowner475:
  %v2535 = load i64, ptr %slot375, align 8
  %p2537 = inttoptr i64 %v2535 to ptr
  %gep2538 = getelementptr i8, ptr %p2537, i64 8
  %op2536 = ptrtoint ptr %gep2538 to i64
  store i64 %op2536, ptr %slot379, align 8
  %v2539 = load i64, ptr %slot51, align 8
  store i64 %v2539, ptr %slot380, align 8
  %v2540 = load i64, ptr %slot379, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  %ld2542 = load i64, ptr %p2541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2542, ptr %slot381, align 8
  %v2543 = load i64, ptr %slot381, align 8
  %cmp2544 = icmp ne i64 %v2543, 0
  %cv2545 = zext i1 %cmp2544 to i32
  store i32 %cv2545, ptr %slot382, align 8
  %v2546 = load i32, ptr %slot382, align 8
  %cv2547 = zext i32 %v2546 to i64
  %cond2548 = icmp ne i64 %cv2547, 0
  br i1 %cond2548, label %bb_rcgnn493, label %bb_rcgdone493
bb_rcgnn493:
  %v2549 = load i64, ptr %slot381, align 8
  %op2550 = sub i64 %v2549, 16
  store i64 %op2550, ptr %slot383, align 8
  %v2551 = load i64, ptr %slot381, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %rgep2553 = getelementptr i8, ptr %p2552, i64 -16
  %ld2554 = load i64, ptr %rgep2553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2554, ptr %slot384, align 8
  %v2555 = load i64, ptr %slot384, align 8
  %op2556 = and i64 %v2555, 4611686018427387906
  store i64 %op2556, ptr %slot385, align 8
  %v2557 = load i64, ptr %slot385, align 8
  %cmp2558 = icmp ne i64 %v2557, 0
  %cv2559 = zext i1 %cmp2558 to i32
  store i32 %cv2559, ptr %slot386, align 8
  %v2560 = load i32, ptr %slot386, align 8
  %cv2561 = zext i32 %v2560 to i64
  %cond2562 = icmp ne i64 %cv2561, 0
  br i1 %cond2562, label %bb_rcgclear493, label %bb_rcgcounted493
bb_rcgcounted493:
  %v2563 = load i64, ptr %slot381, align 8
  %op2564 = sub i64 %v2563, 32
  store i64 %op2564, ptr %slot387, align 8
  %v2565 = load i64, ptr %slot381, align 8
  %p2566 = inttoptr i64 %v2565 to ptr
  %rgep2567 = getelementptr i8, ptr %p2566, i64 -32
  %ld2568 = load i64, ptr %rgep2567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2568, ptr %slot388, align 8
  %v2569 = load i64, ptr %slot388, align 8
  %op2570 = sub i64 %v2569, 1
  store i64 %op2570, ptr %slot389, align 8
  %v2571 = load i64, ptr %slot389, align 8
  %cmp2572 = icmp eq i64 %v2571, 0
  %cv2573 = zext i1 %cmp2572 to i32
  store i32 %cv2573, ptr %slot390, align 8
  %v2574 = load i32, ptr %slot390, align 8
  %cv2575 = zext i32 %v2574 to i64
  %cond2576 = icmp ne i64 %cv2575, 0
  br i1 %cond2576, label %bb_rcglast493, label %bb_rcgdec493
bb_rcglast493:
  %v2577 = load i64, ptr %slot381, align 8
  %op2578 = sub i64 %v2577, 24
  store i64 %op2578, ptr %slot391, align 8
  %v2579 = load i64, ptr %slot381, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  %rgep2581 = getelementptr i8, ptr %p2580, i64 -24
  %ld2582 = load i64, ptr %rgep2581, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2582, ptr %slot392, align 8
  %v2583 = load i64, ptr %slot392, align 8
  %cmp2584 = icmp ne i64 %v2583, 0
  %cv2585 = zext i1 %cmp2584 to i32
  store i32 %cv2585, ptr %slot393, align 8
  %v2586 = load i32, ptr %slot393, align 8
  %cv2587 = zext i32 %v2586 to i64
  %cond2588 = icmp ne i64 %cv2587, 0
  br i1 %cond2588, label %bb_rcgdec493, label %bb_rcgslow493
bb_rcgslow493:
  %v2589 = load i64, ptr %slot380, align 8
  %v2590 = load i64, ptr %slot379, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2589, i64 %v2590) nomerge, !dbg !142
  br label %bb_rcgdone493
bb_rcgdec493:
  %v2591 = load i64, ptr %slot389, align 8
  %v2592 = load i64, ptr %slot381, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  %rgep2594 = getelementptr i8, ptr %p2593, i64 -32
  store i64 %v2591, ptr %rgep2594, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear493
bb_rcgclear493:
  %v2595 = load i64, ptr %slot379, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  store i64 0, ptr %p2596, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone493
bb_rcgdone493:
  %v2597 = load i64, ptr %slot375, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  store i64 0, ptr %p2598, align 8, !alias.scope !3, !noalias !4
  %v2599 = load i64, ptr %slot375, align 8
  %p2601 = inttoptr i64 %v2599 to ptr
  %gep2602 = getelementptr i8, ptr %p2601, i64 8
  %op2600 = ptrtoint ptr %gep2602 to i64
  store i64 %op2600, ptr %slot394, align 8
  %v2603 = load i64, ptr %slot394, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  store i64 0, ptr %p2604, align 8, !alias.scope !3, !noalias !4
  %v2605 = load i64, ptr %slot375, align 8
  %p2607 = inttoptr i64 %v2605 to ptr
  %gep2608 = getelementptr i8, ptr %p2607, i64 16
  %op2606 = ptrtoint ptr %gep2608 to i64
  store i64 %op2606, ptr %slot395, align 8
  %v2609 = load i64, ptr %slot395, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  store i64 0, ptr %p2610, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone475
bb_rcslotdone475:
  br label %bb_rcprivateprepared439
bb_rcprivateprepared439:
  %v2611 = load i64, ptr %slot9, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %ld2613 = load i32, ptr %p2612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2613, ptr %slot396, align 8
  %v2614 = load i32, ptr %slot396, align 8
  %cv2615 = zext i32 %v2614 to i64
  %cond2616 = icmp ne i64 %cv2615, 0
  br i1 %cond2616, label %bb_rcslotdrop502, label %bb_rcslotdone502
bb_rcslotdrop502:
  %v2617 = load i64, ptr %slot9, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  store i32 0, ptr %p2618, align 4, !alias.scope !3, !noalias !4
  %v2619 = load i64, ptr %slot34, align 8
  store i64 %v2619, ptr %slot397, align 8
  %v2620 = load i64, ptr %slot10, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  %ld2622 = load i32, ptr %p2621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2622, ptr %slot398, align 8
  %v2623 = load i32, ptr %slot398, align 8
  %op2624 = and i32 %v2623, 28
  store i32 %op2624, ptr %slot399, align 8
  %v2625 = load i32, ptr %slot399, align 8
  %cv2626 = zext i32 %v2625 to i64
  %cond2627 = icmp ne i64 %cv2626, 0
  br i1 %cond2627, label %bb_rcslotrole502, label %bb_rcslotowner502
bb_rcslotrole502:
  %v2628 = load i64, ptr %slot51, align 8
  store i64 %v2628, ptr %slot400, align 8
  %v2629 = load i64, ptr %slot400, align 8
  %v2630 = load i64, ptr %slot397, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2629, i64 %v2630) nomerge, !dbg !142
  br label %bb_rcslotdone502
bb_rcslotowner502:
  %v2631 = load i64, ptr %slot397, align 8
  %p2633 = inttoptr i64 %v2631 to ptr
  %gep2634 = getelementptr i8, ptr %p2633, i64 8
  %op2632 = ptrtoint ptr %gep2634 to i64
  store i64 %op2632, ptr %slot401, align 8
  %v2635 = load i64, ptr %slot51, align 8
  store i64 %v2635, ptr %slot402, align 8
  %v2636 = load i64, ptr %slot401, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  %ld2638 = load i64, ptr %p2637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2638, ptr %slot403, align 8
  %v2639 = load i64, ptr %slot403, align 8
  %cmp2640 = icmp ne i64 %v2639, 0
  %cv2641 = zext i1 %cmp2640 to i32
  store i32 %cv2641, ptr %slot404, align 8
  %v2642 = load i32, ptr %slot404, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcgnn520, label %bb_rcgdone520
bb_rcgnn520:
  %v2645 = load i64, ptr %slot403, align 8
  %op2646 = sub i64 %v2645, 16
  store i64 %op2646, ptr %slot405, align 8
  %v2647 = load i64, ptr %slot403, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %rgep2649 = getelementptr i8, ptr %p2648, i64 -16
  %ld2650 = load i64, ptr %rgep2649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2650, ptr %slot406, align 8
  %v2651 = load i64, ptr %slot406, align 8
  %op2652 = and i64 %v2651, 4611686018427387906
  store i64 %op2652, ptr %slot407, align 8
  %v2653 = load i64, ptr %slot407, align 8
  %cmp2654 = icmp ne i64 %v2653, 0
  %cv2655 = zext i1 %cmp2654 to i32
  store i32 %cv2655, ptr %slot408, align 8
  %v2656 = load i32, ptr %slot408, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcgclear520, label %bb_rcgcounted520
bb_rcgcounted520:
  %v2659 = load i64, ptr %slot403, align 8
  %op2660 = sub i64 %v2659, 32
  store i64 %op2660, ptr %slot409, align 8
  %v2661 = load i64, ptr %slot403, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %rgep2663 = getelementptr i8, ptr %p2662, i64 -32
  %ld2664 = load i64, ptr %rgep2663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2664, ptr %slot410, align 8
  %v2665 = load i64, ptr %slot410, align 8
  %op2666 = sub i64 %v2665, 1
  store i64 %op2666, ptr %slot411, align 8
  %v2667 = load i64, ptr %slot411, align 8
  %cmp2668 = icmp eq i64 %v2667, 0
  %cv2669 = zext i1 %cmp2668 to i32
  store i32 %cv2669, ptr %slot412, align 8
  %v2670 = load i32, ptr %slot412, align 8
  %cv2671 = zext i32 %v2670 to i64
  %cond2672 = icmp ne i64 %cv2671, 0
  br i1 %cond2672, label %bb_rcglast520, label %bb_rcgdec520
bb_rcglast520:
  %v2673 = load i64, ptr %slot403, align 8
  %op2674 = sub i64 %v2673, 24
  store i64 %op2674, ptr %slot413, align 8
  %v2675 = load i64, ptr %slot403, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  %rgep2677 = getelementptr i8, ptr %p2676, i64 -24
  %ld2678 = load i64, ptr %rgep2677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2678, ptr %slot414, align 8
  %v2679 = load i64, ptr %slot414, align 8
  %cmp2680 = icmp ne i64 %v2679, 0
  %cv2681 = zext i1 %cmp2680 to i32
  store i32 %cv2681, ptr %slot415, align 8
  %v2682 = load i32, ptr %slot415, align 8
  %cv2683 = zext i32 %v2682 to i64
  %cond2684 = icmp ne i64 %cv2683, 0
  br i1 %cond2684, label %bb_rcgdec520, label %bb_rcgslow520
bb_rcgslow520:
  %v2685 = load i64, ptr %slot402, align 8
  %v2686 = load i64, ptr %slot401, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2685, i64 %v2686) nomerge, !dbg !142
  br label %bb_rcgdone520
bb_rcgdec520:
  %v2687 = load i64, ptr %slot411, align 8
  %v2688 = load i64, ptr %slot403, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %rgep2690 = getelementptr i8, ptr %p2689, i64 -32
  store i64 %v2687, ptr %rgep2690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear520
bb_rcgclear520:
  %v2691 = load i64, ptr %slot401, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  store i64 0, ptr %p2692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone520
bb_rcgdone520:
  %v2693 = load i64, ptr %slot397, align 8
  %p2694 = inttoptr i64 %v2693 to ptr
  store i64 0, ptr %p2694, align 8, !alias.scope !3, !noalias !4
  %v2695 = load i64, ptr %slot397, align 8
  %p2697 = inttoptr i64 %v2695 to ptr
  %gep2698 = getelementptr i8, ptr %p2697, i64 8
  %op2696 = ptrtoint ptr %gep2698 to i64
  store i64 %op2696, ptr %slot416, align 8
  %v2699 = load i64, ptr %slot416, align 8
  %p2700 = inttoptr i64 %v2699 to ptr
  store i64 0, ptr %p2700, align 8, !alias.scope !3, !noalias !4
  %v2701 = load i64, ptr %slot397, align 8
  %p2703 = inttoptr i64 %v2701 to ptr
  %gep2704 = getelementptr i8, ptr %p2703, i64 16
  %op2702 = ptrtoint ptr %gep2704 to i64
  store i64 %op2702, ptr %slot417, align 8
  %v2705 = load i64, ptr %slot417, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  store i64 0, ptr %p2706, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone502
bb_rcslotdone502:
  %v2707 = load i64, ptr %slot34, align 8
  store i64 %v2707, ptr %slot418, align 8
  %v2708 = load i64, ptr %slot24, align 8
  store i64 %v2708, ptr %slot419, align 8
  %v2709 = load i64, ptr %slot419, align 8
  %v2710 = load i64, ptr %slot418, align 8
  %p2711 = inttoptr i64 %v2709 to ptr
  %p2712 = inttoptr i64 %v2710 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2712, ptr %p2711, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2713 = load i64, ptr %slot19, align 8
  %p2714 = inttoptr i64 %v2713 to ptr
  store i32 0, ptr %p2714, align 4, !alias.scope !3, !noalias !4
  %v2715 = load i64, ptr %slot10, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  store i32 2, ptr %p2716, align 4, !alias.scope !3, !noalias !4
  %v2717 = load i64, ptr %slot20, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  %ld2719 = load i32, ptr %p2718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2719, ptr %slot420, align 8
  %v2720 = load i32, ptr %slot420, align 8
  %v2721 = load i64, ptr %slot10, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  store i32 %v2720, ptr %p2722, align 4, !alias.scope !3, !noalias !4
  %v2723 = load i64, ptr %slot9, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  store i32 1, ptr %p2724, align 4, !alias.scope !3, !noalias !4
  %v2725 = load i64, ptr %slot33, align 8
  %v2726 = load i64, ptr %slot39, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i64 %v2725, ptr %p2727, align 8, !alias.scope !3, !noalias !4
  %v2728 = load i64, ptr %slot39, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  %ld2730 = load i64, ptr %p2729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2730, ptr %slot421, align 8
  %v2731 = load i64, ptr %slot15, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  %ld2733 = load i32, ptr %p2732, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2733, ptr %slot422, align 8
  %v2734 = load i64, ptr %slot16, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  %ld2736 = load i32, ptr %p2735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2736, ptr %slot423, align 8
  %v2737 = load i32, ptr %slot423, align 8
  %op2738 = and i32 %v2737, 24
  store i32 %op2738, ptr %slot423, align 8
  %v2739 = load i32, ptr %slot423, align 8
  %cmp2740 = icmp eq i32 %v2739, 0
  %cv2741 = zext i1 %cmp2740 to i32
  store i32 %cv2741, ptr %slot424, align 8
  %v2742 = load i32, ptr %slot422, align 8
  %v2743 = load i32, ptr %slot424, align 8
  %op2744 = and i32 %v2742, %v2743
  store i32 %op2744, ptr %slot425, align 8
  %v2745 = load i32, ptr %slot425, align 8
  %cv2746 = zext i32 %v2745 to i64
  %cond2747 = icmp ne i64 %cv2746, 0
  br i1 %cond2747, label %bb_rcprivateown540, label %bb_rcprivateloan540
bb_rcprivateown540:
  %v2748 = load i64, ptr %slot24, align 8
  store i64 %v2748, ptr %slot426, align 8
  %v2749 = load i64, ptr %slot52, align 8
  store i64 %v2749, ptr %slot427, align 8
  %v2750 = load i64, ptr %slot421, align 8
  %v2751 = load i64, ptr %slot426, align 8
  %op2752 = sub i64 %v2750, %v2751
  store i64 %op2752, ptr %slot428, align 8
  %v2753 = load i64, ptr %slot426, align 8
  %v2754 = load i64, ptr %slot421, align 8
  %op2755 = sub i64 %v2753, %v2754
  store i64 %op2755, ptr %slot429, align 8
  %v2756 = load i64, ptr %slot428, align 8
  %cmp2757 = icmp ult i64 %v2756, 24
  %cv2758 = zext i1 %cmp2757 to i32
  store i32 %cv2758, ptr %slot430, align 8
  %v2759 = load i64, ptr %slot429, align 8
  %cmp2760 = icmp ult i64 %v2759, 24
  %cv2761 = zext i1 %cmp2760 to i32
  store i32 %cv2761, ptr %slot431, align 8
  %v2762 = load i32, ptr %slot430, align 8
  %v2763 = load i32, ptr %slot431, align 8
  %op2764 = or i32 %v2762, %v2763
  store i32 %op2764, ptr %slot432, align 8
  %v2765 = load i32, ptr %slot432, align 8
  %cv2766 = zext i32 %v2765 to i64
  %cond2767 = icmp ne i64 %cv2766, 0
  br i1 %cond2767, label %bb_rcmoveslow543, label %bb_rcmovecheck543
bb_rcmovecheck543:
  %v2768 = load i64, ptr %slot421, align 8
  %op2769 = add i64 %v2768, 8
  store i64 %op2769, ptr %slot433, align 8
  %v2770 = load i64, ptr %slot433, align 8
  %p2771 = inttoptr i64 %v2770 to ptr
  %ld2772 = load i64, ptr %p2771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2772, ptr %slot434, align 8
  %v2773 = load i64, ptr %slot434, align 8
  %cmp2774 = icmp ne i64 %v2773, 0
  %cv2775 = zext i1 %cmp2774 to i32
  store i32 %cv2775, ptr %slot435, align 8
  %v2776 = load i32, ptr %slot435, align 8
  %cv2777 = zext i32 %v2776 to i64
  %cond2778 = icmp ne i64 %cv2777, 0
  br i1 %cond2778, label %bb_rcmoveheader551, label %bb_rcmovenext551
bb_rcmoveheader551:
  %v2779 = load i64, ptr %slot434, align 8
  %op2780 = sub i64 %v2779, 16
  store i64 %op2780, ptr %slot436, align 8
  %v2781 = load i64, ptr %slot434, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  %rgep2783 = getelementptr i8, ptr %p2782, i64 -16
  %ld2784 = load i64, ptr %rgep2783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2784, ptr %slot437, align 8
  %v2785 = load i64, ptr %slot437, align 8
  %op2786 = and i64 %v2785, 5764607523034234881
  store i64 %op2786, ptr %slot438, align 8
  %v2787 = load i64, ptr %slot438, align 8
  %cmp2788 = icmp ne i64 %v2787, 0
  %cv2789 = zext i1 %cmp2788 to i32
  store i32 %cv2789, ptr %slot439, align 8
  %v2790 = load i32, ptr %slot439, align 8
  %cv2791 = zext i32 %v2790 to i64
  %cond2792 = icmp ne i64 %cv2791, 0
  br i1 %cond2792, label %bb_rcmoveslow543, label %bb_rcmovenext551
bb_rcmovenext551:
  %v2793 = load i64, ptr %slot421, align 8
  %v2794 = load i64, ptr %slot426, align 8
  %p2795 = inttoptr i64 %v2793 to ptr
  %p2796 = inttoptr i64 %v2794 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2796, ptr %p2795, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2797 = load i64, ptr %slot421, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  store i64 0, ptr %p2798, align 8, !alias.scope !3, !noalias !4
  %v2799 = load i64, ptr %slot421, align 8
  %op2800 = add i64 %v2799, 8
  store i64 %op2800, ptr %slot440, align 8
  %v2801 = load i64, ptr %slot440, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  store i64 0, ptr %p2802, align 8, !alias.scope !3, !noalias !4
  %v2803 = load i64, ptr %slot421, align 8
  %op2804 = add i64 %v2803, 16
  store i64 %op2804, ptr %slot441, align 8
  %v2805 = load i64, ptr %slot441, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  store i64 0, ptr %p2806, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved543
bb_rcmoveslow543:
  %v2807 = load i64, ptr %slot51, align 8
  %v2808 = load i64, ptr %slot426, align 8
  %v2809 = load i64, ptr %slot421, align 8
  %v2810 = load i64, ptr %slot427, align 8
  %cv2811 = trunc i64 %v2810 to i32
  %call2812 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2807, i64 %v2808, i64 %v2809, i32 %cv2811) nomerge, !dbg !144
  store i32 %call2812, ptr %slot442, align 8
  %v2813 = load i32, ptr %slot442, align 8
  %cv2814 = zext i32 %v2813 to i64
  %cond2815 = icmp ne i64 %cv2814, 0
  br i1 %cond2815, label %bb_rcsuccess560, label %bb_rcfailure560
bb_rcfailure560:
  %v2816 = load i64, ptr %slot51, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  %call2818 = call i32 @myl_rc_take_failure(ptr %p2817) nomerge, !dbg !144
  store i32 %call2818, ptr %slot443, align 8
  %v2819 = load i64, ptr %slot1, align 8
  %p2820 = inttoptr i64 %v2819 to ptr
  %v2821 = load i32, ptr %slot443, align 8
  %call2822 = call i32 @myl_qbe_rc_status(ptr %p2820, i32 %v2821) nomerge, !dbg !144
  store i32 %call2822, ptr %slot444, align 8
  br label %bb_failure
bb_rcsuccess560:
  br label %bb_rcmoved543
bb_rcmoved543:
  %v2823 = load i64, ptr %slot15, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  store i32 0, ptr %p2824, align 4, !alias.scope !3, !noalias !4
  %v2825 = load i64, ptr %slot20, align 8
  %p2826 = inttoptr i64 %v2825 to ptr
  store i32 2, ptr %p2826, align 4, !alias.scope !3, !noalias !4
  %v2827 = load i64, ptr %slot19, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  store i32 1, ptr %p2828, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared540
bb_rcprivateloan540:
  %v2829 = load i64, ptr %slot24, align 8
  store i64 %v2829, ptr %slot445, align 8
  %v2830 = load i64, ptr %slot51, align 8
  %v2831 = load i64, ptr %slot445, align 8
  %v2832 = load i64, ptr %slot421, align 8
  %call2833 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64 %v2830, i64 %v2831, i64 %v2832) nomerge, !dbg !144
  store i32 %call2833, ptr %slot446, align 8
  %v2834 = load i32, ptr %slot446, align 8
  %cv2835 = zext i32 %v2834 to i64
  %cond2836 = icmp ne i64 %cv2835, 0
  br i1 %cond2836, label %bb_rcsuccess568, label %bb_rcfailure568
bb_rcfailure568:
  %v2837 = load i64, ptr %slot51, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  %call2839 = call i32 @myl_rc_take_failure(ptr %p2838) nomerge, !dbg !144
  store i32 %call2839, ptr %slot447, align 8
  %v2840 = load i64, ptr %slot1, align 8
  %p2841 = inttoptr i64 %v2840 to ptr
  %v2842 = load i32, ptr %slot447, align 8
  %call2843 = call i32 @myl_qbe_rc_status(ptr %p2841, i32 %v2842) nomerge, !dbg !144
  store i32 %call2843, ptr %slot448, align 8
  br label %bb_failure
bb_rcsuccess568:
  %v2844 = load i64, ptr %slot20, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  store i32 2, ptr %p2845, align 4, !alias.scope !3, !noalias !4
  %v2846 = load i64, ptr %slot20, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  store i32 16, ptr %p2847, align 4, !alias.scope !3, !noalias !4
  %v2848 = load i64, ptr %slot19, align 8
  %p2849 = inttoptr i64 %v2848 to ptr
  store i32 1, ptr %p2849, align 4, !alias.scope !3, !noalias !4
  %v2850 = load i64, ptr %slot15, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  %ld2852 = load i32, ptr %p2851, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2852, ptr %slot449, align 8
  %v2853 = load i32, ptr %slot449, align 8
  %cv2854 = zext i32 %v2853 to i64
  %cond2855 = icmp ne i64 %cv2854, 0
  br i1 %cond2855, label %bb_rcslotdrop576, label %bb_rcslotdone576
bb_rcslotdrop576:
  %v2856 = load i64, ptr %slot15, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  store i32 0, ptr %p2857, align 4, !alias.scope !3, !noalias !4
  %v2858 = load i64, ptr %slot22, align 8
  store i64 %v2858, ptr %slot450, align 8
  %v2859 = load i64, ptr %slot16, align 8
  %p2860 = inttoptr i64 %v2859 to ptr
  %ld2861 = load i32, ptr %p2860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2861, ptr %slot451, align 8
  %v2862 = load i32, ptr %slot451, align 8
  %op2863 = and i32 %v2862, 28
  store i32 %op2863, ptr %slot452, align 8
  %v2864 = load i32, ptr %slot452, align 8
  %cv2865 = zext i32 %v2864 to i64
  %cond2866 = icmp ne i64 %cv2865, 0
  br i1 %cond2866, label %bb_rcslotrole576, label %bb_rcslotowner576
bb_rcslotrole576:
  %v2867 = load i64, ptr %slot51, align 8
  store i64 %v2867, ptr %slot453, align 8
  %v2868 = load i64, ptr %slot453, align 8
  %v2869 = load i64, ptr %slot450, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2868, i64 %v2869) nomerge, !dbg !144
  br label %bb_rcslotdone576
bb_rcslotowner576:
  %v2870 = load i64, ptr %slot450, align 8
  %p2872 = inttoptr i64 %v2870 to ptr
  %gep2873 = getelementptr i8, ptr %p2872, i64 8
  %op2871 = ptrtoint ptr %gep2873 to i64
  store i64 %op2871, ptr %slot454, align 8
  %v2874 = load i64, ptr %slot51, align 8
  store i64 %v2874, ptr %slot455, align 8
  %v2875 = load i64, ptr %slot454, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %ld2877 = load i64, ptr %p2876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2877, ptr %slot456, align 8
  %v2878 = load i64, ptr %slot456, align 8
  %cmp2879 = icmp ne i64 %v2878, 0
  %cv2880 = zext i1 %cmp2879 to i32
  store i32 %cv2880, ptr %slot457, align 8
  %v2881 = load i32, ptr %slot457, align 8
  %cv2882 = zext i32 %v2881 to i64
  %cond2883 = icmp ne i64 %cv2882, 0
  br i1 %cond2883, label %bb_rcgnn594, label %bb_rcgdone594
bb_rcgnn594:
  %v2884 = load i64, ptr %slot456, align 8
  %op2885 = sub i64 %v2884, 16
  store i64 %op2885, ptr %slot458, align 8
  %v2886 = load i64, ptr %slot456, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  %rgep2888 = getelementptr i8, ptr %p2887, i64 -16
  %ld2889 = load i64, ptr %rgep2888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2889, ptr %slot459, align 8
  %v2890 = load i64, ptr %slot459, align 8
  %op2891 = and i64 %v2890, 4611686018427387906
  store i64 %op2891, ptr %slot460, align 8
  %v2892 = load i64, ptr %slot460, align 8
  %cmp2893 = icmp ne i64 %v2892, 0
  %cv2894 = zext i1 %cmp2893 to i32
  store i32 %cv2894, ptr %slot461, align 8
  %v2895 = load i32, ptr %slot461, align 8
  %cv2896 = zext i32 %v2895 to i64
  %cond2897 = icmp ne i64 %cv2896, 0
  br i1 %cond2897, label %bb_rcgclear594, label %bb_rcgcounted594
bb_rcgcounted594:
  %v2898 = load i64, ptr %slot456, align 8
  %op2899 = sub i64 %v2898, 32
  store i64 %op2899, ptr %slot462, align 8
  %v2900 = load i64, ptr %slot456, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  %rgep2902 = getelementptr i8, ptr %p2901, i64 -32
  %ld2903 = load i64, ptr %rgep2902, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2903, ptr %slot463, align 8
  %v2904 = load i64, ptr %slot463, align 8
  %op2905 = sub i64 %v2904, 1
  store i64 %op2905, ptr %slot464, align 8
  %v2906 = load i64, ptr %slot464, align 8
  %cmp2907 = icmp eq i64 %v2906, 0
  %cv2908 = zext i1 %cmp2907 to i32
  store i32 %cv2908, ptr %slot465, align 8
  %v2909 = load i32, ptr %slot465, align 8
  %cv2910 = zext i32 %v2909 to i64
  %cond2911 = icmp ne i64 %cv2910, 0
  br i1 %cond2911, label %bb_rcglast594, label %bb_rcgdec594
bb_rcglast594:
  %v2912 = load i64, ptr %slot456, align 8
  %op2913 = sub i64 %v2912, 24
  store i64 %op2913, ptr %slot466, align 8
  %v2914 = load i64, ptr %slot456, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  %rgep2916 = getelementptr i8, ptr %p2915, i64 -24
  %ld2917 = load i64, ptr %rgep2916, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2917, ptr %slot467, align 8
  %v2918 = load i64, ptr %slot467, align 8
  %cmp2919 = icmp ne i64 %v2918, 0
  %cv2920 = zext i1 %cmp2919 to i32
  store i32 %cv2920, ptr %slot468, align 8
  %v2921 = load i32, ptr %slot468, align 8
  %cv2922 = zext i32 %v2921 to i64
  %cond2923 = icmp ne i64 %cv2922, 0
  br i1 %cond2923, label %bb_rcgdec594, label %bb_rcgslow594
bb_rcgslow594:
  %v2924 = load i64, ptr %slot455, align 8
  %v2925 = load i64, ptr %slot454, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2924, i64 %v2925) nomerge, !dbg !144
  br label %bb_rcgdone594
bb_rcgdec594:
  %v2926 = load i64, ptr %slot464, align 8
  %v2927 = load i64, ptr %slot456, align 8
  %p2928 = inttoptr i64 %v2927 to ptr
  %rgep2929 = getelementptr i8, ptr %p2928, i64 -32
  store i64 %v2926, ptr %rgep2929, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear594
bb_rcgclear594:
  %v2930 = load i64, ptr %slot454, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  store i64 0, ptr %p2931, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone594
bb_rcgdone594:
  %v2932 = load i64, ptr %slot450, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  store i64 0, ptr %p2933, align 8, !alias.scope !3, !noalias !4
  %v2934 = load i64, ptr %slot450, align 8
  %p2936 = inttoptr i64 %v2934 to ptr
  %gep2937 = getelementptr i8, ptr %p2936, i64 8
  %op2935 = ptrtoint ptr %gep2937 to i64
  store i64 %op2935, ptr %slot469, align 8
  %v2938 = load i64, ptr %slot469, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  store i64 0, ptr %p2939, align 8, !alias.scope !3, !noalias !4
  %v2940 = load i64, ptr %slot450, align 8
  %p2942 = inttoptr i64 %v2940 to ptr
  %gep2943 = getelementptr i8, ptr %p2942, i64 16
  %op2941 = ptrtoint ptr %gep2943 to i64
  store i64 %op2941, ptr %slot470, align 8
  %v2944 = load i64, ptr %slot470, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  store i64 0, ptr %p2945, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone576
bb_rcslotdone576:
  br label %bb_rcprivateprepared540
bb_rcprivateprepared540:
  %v2946 = load i64, ptr %slot9, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  %ld2948 = load i32, ptr %p2947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2948, ptr %slot471, align 8
  %v2949 = load i32, ptr %slot471, align 8
  %cv2950 = zext i32 %v2949 to i64
  %cond2951 = icmp ne i64 %cv2950, 0
  br i1 %cond2951, label %bb_rcslotdrop603, label %bb_rcslotdone603
bb_rcslotdrop603:
  %v2952 = load i64, ptr %slot9, align 8
  %p2953 = inttoptr i64 %v2952 to ptr
  store i32 0, ptr %p2953, align 4, !alias.scope !3, !noalias !4
  %v2954 = load i64, ptr %slot34, align 8
  store i64 %v2954, ptr %slot472, align 8
  %v2955 = load i64, ptr %slot10, align 8
  %p2956 = inttoptr i64 %v2955 to ptr
  %ld2957 = load i32, ptr %p2956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2957, ptr %slot473, align 8
  %v2958 = load i32, ptr %slot473, align 8
  %op2959 = and i32 %v2958, 28
  store i32 %op2959, ptr %slot474, align 8
  %v2960 = load i32, ptr %slot474, align 8
  %cv2961 = zext i32 %v2960 to i64
  %cond2962 = icmp ne i64 %cv2961, 0
  br i1 %cond2962, label %bb_rcslotrole603, label %bb_rcslotowner603
bb_rcslotrole603:
  %v2963 = load i64, ptr %slot51, align 8
  store i64 %v2963, ptr %slot475, align 8
  %v2964 = load i64, ptr %slot475, align 8
  %v2965 = load i64, ptr %slot472, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2964, i64 %v2965) nomerge, !dbg !144
  br label %bb_rcslotdone603
bb_rcslotowner603:
  %v2966 = load i64, ptr %slot472, align 8
  %p2968 = inttoptr i64 %v2966 to ptr
  %gep2969 = getelementptr i8, ptr %p2968, i64 8
  %op2967 = ptrtoint ptr %gep2969 to i64
  store i64 %op2967, ptr %slot476, align 8
  %v2970 = load i64, ptr %slot51, align 8
  store i64 %v2970, ptr %slot477, align 8
  %v2971 = load i64, ptr %slot476, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  %ld2973 = load i64, ptr %p2972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2973, ptr %slot478, align 8
  %v2974 = load i64, ptr %slot478, align 8
  %cmp2975 = icmp ne i64 %v2974, 0
  %cv2976 = zext i1 %cmp2975 to i32
  store i32 %cv2976, ptr %slot479, align 8
  %v2977 = load i32, ptr %slot479, align 8
  %cv2978 = zext i32 %v2977 to i64
  %cond2979 = icmp ne i64 %cv2978, 0
  br i1 %cond2979, label %bb_rcgnn621, label %bb_rcgdone621
bb_rcgnn621:
  %v2980 = load i64, ptr %slot478, align 8
  %op2981 = sub i64 %v2980, 16
  store i64 %op2981, ptr %slot480, align 8
  %v2982 = load i64, ptr %slot478, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  %rgep2984 = getelementptr i8, ptr %p2983, i64 -16
  %ld2985 = load i64, ptr %rgep2984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2985, ptr %slot481, align 8
  %v2986 = load i64, ptr %slot481, align 8
  %op2987 = and i64 %v2986, 4611686018427387906
  store i64 %op2987, ptr %slot482, align 8
  %v2988 = load i64, ptr %slot482, align 8
  %cmp2989 = icmp ne i64 %v2988, 0
  %cv2990 = zext i1 %cmp2989 to i32
  store i32 %cv2990, ptr %slot483, align 8
  %v2991 = load i32, ptr %slot483, align 8
  %cv2992 = zext i32 %v2991 to i64
  %cond2993 = icmp ne i64 %cv2992, 0
  br i1 %cond2993, label %bb_rcgclear621, label %bb_rcgcounted621
bb_rcgcounted621:
  %v2994 = load i64, ptr %slot478, align 8
  %op2995 = sub i64 %v2994, 32
  store i64 %op2995, ptr %slot484, align 8
  %v2996 = load i64, ptr %slot478, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  %rgep2998 = getelementptr i8, ptr %p2997, i64 -32
  %ld2999 = load i64, ptr %rgep2998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2999, ptr %slot485, align 8
  %v3000 = load i64, ptr %slot485, align 8
  %op3001 = sub i64 %v3000, 1
  store i64 %op3001, ptr %slot486, align 8
  %v3002 = load i64, ptr %slot486, align 8
  %cmp3003 = icmp eq i64 %v3002, 0
  %cv3004 = zext i1 %cmp3003 to i32
  store i32 %cv3004, ptr %slot487, align 8
  %v3005 = load i32, ptr %slot487, align 8
  %cv3006 = zext i32 %v3005 to i64
  %cond3007 = icmp ne i64 %cv3006, 0
  br i1 %cond3007, label %bb_rcglast621, label %bb_rcgdec621
bb_rcglast621:
  %v3008 = load i64, ptr %slot478, align 8
  %op3009 = sub i64 %v3008, 24
  store i64 %op3009, ptr %slot488, align 8
  %v3010 = load i64, ptr %slot478, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  %rgep3012 = getelementptr i8, ptr %p3011, i64 -24
  %ld3013 = load i64, ptr %rgep3012, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3013, ptr %slot489, align 8
  %v3014 = load i64, ptr %slot489, align 8
  %cmp3015 = icmp ne i64 %v3014, 0
  %cv3016 = zext i1 %cmp3015 to i32
  store i32 %cv3016, ptr %slot490, align 8
  %v3017 = load i32, ptr %slot490, align 8
  %cv3018 = zext i32 %v3017 to i64
  %cond3019 = icmp ne i64 %cv3018, 0
  br i1 %cond3019, label %bb_rcgdec621, label %bb_rcgslow621
bb_rcgslow621:
  %v3020 = load i64, ptr %slot477, align 8
  %v3021 = load i64, ptr %slot476, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3020, i64 %v3021) nomerge, !dbg !144
  br label %bb_rcgdone621
bb_rcgdec621:
  %v3022 = load i64, ptr %slot486, align 8
  %v3023 = load i64, ptr %slot478, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  %rgep3025 = getelementptr i8, ptr %p3024, i64 -32
  store i64 %v3022, ptr %rgep3025, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear621
bb_rcgclear621:
  %v3026 = load i64, ptr %slot476, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  store i64 0, ptr %p3027, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone621
bb_rcgdone621:
  %v3028 = load i64, ptr %slot472, align 8
  %p3029 = inttoptr i64 %v3028 to ptr
  store i64 0, ptr %p3029, align 8, !alias.scope !3, !noalias !4
  %v3030 = load i64, ptr %slot472, align 8
  %p3032 = inttoptr i64 %v3030 to ptr
  %gep3033 = getelementptr i8, ptr %p3032, i64 8
  %op3031 = ptrtoint ptr %gep3033 to i64
  store i64 %op3031, ptr %slot491, align 8
  %v3034 = load i64, ptr %slot491, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  store i64 0, ptr %p3035, align 8, !alias.scope !3, !noalias !4
  %v3036 = load i64, ptr %slot472, align 8
  %p3038 = inttoptr i64 %v3036 to ptr
  %gep3039 = getelementptr i8, ptr %p3038, i64 16
  %op3037 = ptrtoint ptr %gep3039 to i64
  store i64 %op3037, ptr %slot492, align 8
  %v3040 = load i64, ptr %slot492, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  store i64 0, ptr %p3041, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone603
bb_rcslotdone603:
  %v3042 = load i64, ptr %slot34, align 8
  store i64 %v3042, ptr %slot493, align 8
  %v3043 = load i64, ptr %slot24, align 8
  store i64 %v3043, ptr %slot494, align 8
  %v3044 = load i64, ptr %slot494, align 8
  %v3045 = load i64, ptr %slot493, align 8
  %p3046 = inttoptr i64 %v3044 to ptr
  %p3047 = inttoptr i64 %v3045 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3047, ptr %p3046, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3048 = load i64, ptr %slot19, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  store i32 0, ptr %p3049, align 4, !alias.scope !3, !noalias !4
  %v3050 = load i64, ptr %slot10, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  store i32 2, ptr %p3051, align 4, !alias.scope !3, !noalias !4
  %v3052 = load i64, ptr %slot20, align 8
  %p3053 = inttoptr i64 %v3052 to ptr
  %ld3054 = load i32, ptr %p3053, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3054, ptr %slot495, align 8
  %v3055 = load i32, ptr %slot495, align 8
  %v3056 = load i64, ptr %slot10, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i32 %v3055, ptr %p3057, align 4, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot9, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  store i32 1, ptr %p3059, align 4, !alias.scope !3, !noalias !4
  %v3060 = load i64, ptr %slot34, align 8
  %v3061 = load i64, ptr %slot39, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  store i64 %v3060, ptr %p3062, align 8, !alias.scope !3, !noalias !4
  %v3063 = load i64, ptr %slot35, align 8
  %v3064 = load i64, ptr %slot40, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  store i64 %v3063, ptr %p3065, align 8, !alias.scope !3, !noalias !4
  %v3066 = load i64, ptr %slot40, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  %ld3068 = load i64, ptr %p3067, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3068, ptr %slot496, align 8
  %v3069 = load i64, ptr %slot17, align 8
  %p3070 = inttoptr i64 %v3069 to ptr
  %ld3071 = load i32, ptr %p3070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3071, ptr %slot497, align 8
  %v3072 = load i64, ptr %slot18, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  %ld3074 = load i32, ptr %p3073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3074, ptr %slot498, align 8
  %v3075 = load i32, ptr %slot498, align 8
  %op3076 = and i32 %v3075, 24
  store i32 %op3076, ptr %slot498, align 8
  %v3077 = load i32, ptr %slot498, align 8
  %cmp3078 = icmp eq i32 %v3077, 0
  %cv3079 = zext i1 %cmp3078 to i32
  store i32 %cv3079, ptr %slot499, align 8
  %v3080 = load i32, ptr %slot497, align 8
  %v3081 = load i32, ptr %slot499, align 8
  %op3082 = and i32 %v3080, %v3081
  store i32 %op3082, ptr %slot500, align 8
  %v3083 = load i64, ptr %slot52, align 8
  store i64 %v3083, ptr %slot501, align 8
  %v3084 = load i32, ptr %slot500, align 8
  %op3085 = mul i32 %v3084, 4
  store i32 %op3085, ptr %slot502, align 8
  %v3086 = load i32, ptr %slot502, align 8
  %op3087 = or i32 %v3086, 0
  store i32 %op3087, ptr %slot503, align 8
  %v3088 = load i64, ptr %slot24, align 8
  store i64 %v3088, ptr %slot504, align 8
  %v3089 = load i64, ptr %slot51, align 8
  %v3090 = load i64, ptr %slot504, align 8
  %v3091 = load i64, ptr %slot496, align 8
  %v3092 = load i64, ptr %slot501, align 8
  %cv3093 = trunc i64 %v3092 to i32
  %v3094 = load i32, ptr %slot503, align 8
  %call3095 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64 %v3089, i64 %v3090, i64 %v3091, i32 %cv3093, i32 %v3094) nomerge, !dbg !146
  store i32 %call3095, ptr %slot505, align 8
  %v3096 = load i32, ptr %slot505, align 8
  %cv3097 = zext i32 %v3096 to i64
  %cond3098 = icmp ne i64 %cv3097, 0
  br i1 %cond3098, label %bb_rcsuccess648, label %bb_rcfailure648
bb_rcfailure648:
  %v3099 = load i64, ptr %slot51, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  %call3101 = call i32 @myl_rc_take_failure(ptr %p3100) nomerge, !dbg !146
  store i32 %call3101, ptr %slot506, align 8
  %v3102 = load i64, ptr %slot1, align 8
  %p3103 = inttoptr i64 %v3102 to ptr
  %v3104 = load i32, ptr %slot506, align 8
  %call3105 = call i32 @myl_qbe_rc_status(ptr %p3103, i32 %v3104) nomerge, !dbg !146
  store i32 %call3105, ptr %slot507, align 8
  br label %bb_failure
bb_rcsuccess648:
  %v3106 = load i32, ptr %slot500, align 8
  %cv3107 = zext i32 %v3106 to i64
  %cond3108 = icmp ne i64 %cv3107, 0
  br i1 %cond3108, label %bb_rchtaken651, label %bb_rchcopied651
bb_rchcopied651:
  %v3109 = load i64, ptr %slot17, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  %ld3111 = load i32, ptr %p3110, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3111, ptr %slot508, align 8
  %v3112 = load i32, ptr %slot508, align 8
  %cv3113 = zext i32 %v3112 to i64
  %cond3114 = icmp ne i64 %cv3113, 0
  br i1 %cond3114, label %bb_rcslotdrop654, label %bb_rcslotdone654
bb_rcslotdrop654:
  %v3115 = load i64, ptr %slot17, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  store i32 0, ptr %p3116, align 4, !alias.scope !3, !noalias !4
  %v3117 = load i64, ptr %slot23, align 8
  store i64 %v3117, ptr %slot509, align 8
  %v3118 = load i64, ptr %slot18, align 8
  %p3119 = inttoptr i64 %v3118 to ptr
  %ld3120 = load i32, ptr %p3119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3120, ptr %slot510, align 8
  %v3121 = load i32, ptr %slot510, align 8
  %op3122 = and i32 %v3121, 28
  store i32 %op3122, ptr %slot511, align 8
  %v3123 = load i32, ptr %slot511, align 8
  %cv3124 = zext i32 %v3123 to i64
  %cond3125 = icmp ne i64 %cv3124, 0
  br i1 %cond3125, label %bb_rcslotrole654, label %bb_rcslotowner654
bb_rcslotrole654:
  %v3126 = load i64, ptr %slot51, align 8
  store i64 %v3126, ptr %slot512, align 8
  %v3127 = load i64, ptr %slot512, align 8
  %v3128 = load i64, ptr %slot509, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3127, i64 %v3128) nomerge, !dbg !146
  br label %bb_rcslotdone654
bb_rcslotowner654:
  %v3129 = load i64, ptr %slot51, align 8
  store i64 %v3129, ptr %slot513, align 8
  %v3130 = load i64, ptr %slot513, align 8
  %v3131 = load i64, ptr %slot509, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3130, i64 %v3131) nomerge, !dbg !146
  br label %bb_rcslotdone654
bb_rcslotdone654:
  br label %bb_rchprepared651
bb_rchtaken651:
  %v3132 = load i64, ptr %slot17, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  store i32 0, ptr %p3133, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared651
bb_rchprepared651:
  %v3134 = load i64, ptr %slot20, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  store i32 2, ptr %p3135, align 4, !alias.scope !3, !noalias !4
  %v3136 = load i64, ptr %slot19, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  store i32 1, ptr %p3137, align 4, !alias.scope !3, !noalias !4
  %v3138 = load i64, ptr %slot23, align 8
  store i64 %v3138, ptr %slot514, align 8
  %v3139 = load i64, ptr %slot24, align 8
  store i64 %v3139, ptr %slot515, align 8
  %v3140 = load i64, ptr %slot515, align 8
  %v3141 = load i64, ptr %slot514, align 8
  %p3142 = inttoptr i64 %v3140 to ptr
  %p3143 = inttoptr i64 %v3141 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3143, ptr %p3142, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3144 = load i64, ptr %slot18, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  store i32 2, ptr %p3145, align 4, !alias.scope !3, !noalias !4
  %v3146 = load i64, ptr %slot20, align 8
  %p3147 = inttoptr i64 %v3146 to ptr
  %ld3148 = load i32, ptr %p3147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3148, ptr %slot516, align 8
  %v3149 = load i32, ptr %slot516, align 8
  %v3150 = load i64, ptr %slot18, align 8
  %p3151 = inttoptr i64 %v3150 to ptr
  store i32 %v3149, ptr %p3151, align 4, !alias.scope !3, !noalias !4
  %v3152 = load i64, ptr %slot19, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  store i32 0, ptr %p3153, align 4, !alias.scope !3, !noalias !4
  %v3154 = load i64, ptr %slot17, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  store i32 1, ptr %p3155, align 4, !alias.scope !3, !noalias !4
  %v3156 = load i64, ptr %slot514, align 8
  %v3157 = load i64, ptr %slot40, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  store i64 %v3156, ptr %p3158, align 8, !alias.scope !3, !noalias !4
  %v3159 = load i64, ptr %slot39, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  %ld3161 = load i64, ptr %p3160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3161, ptr %slot517, align 8
  %v3162 = load i64, ptr %slot15, align 8
  %p3163 = inttoptr i64 %v3162 to ptr
  %ld3164 = load i32, ptr %p3163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3164, ptr %slot518, align 8
  %v3165 = load i64, ptr %slot16, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %ld3167 = load i32, ptr %p3166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3167, ptr %slot519, align 8
  %v3168 = load i32, ptr %slot519, align 8
  %op3169 = and i32 %v3168, 24
  store i32 %op3169, ptr %slot519, align 8
  %v3170 = load i32, ptr %slot519, align 8
  %cmp3171 = icmp eq i32 %v3170, 0
  %cv3172 = zext i1 %cmp3171 to i32
  store i32 %cv3172, ptr %slot520, align 8
  %v3173 = load i32, ptr %slot518, align 8
  %v3174 = load i32, ptr %slot520, align 8
  %op3175 = and i32 %v3173, %v3174
  store i32 %op3175, ptr %slot521, align 8
  %v3176 = load i32, ptr %slot521, align 8
  %cv3177 = zext i32 %v3176 to i64
  %cond3178 = icmp ne i64 %cv3177, 0
  br i1 %cond3178, label %bb_rctake673, label %bb_rccopy673
bb_rctake673:
  %v3179 = load i64, ptr %slot24, align 8
  store i64 %v3179, ptr %slot522, align 8
  %v3180 = load i64, ptr %slot52, align 8
  store i64 %v3180, ptr %slot523, align 8
  %v3181 = load i64, ptr %slot517, align 8
  %v3182 = load i64, ptr %slot522, align 8
  %op3183 = sub i64 %v3181, %v3182
  store i64 %op3183, ptr %slot524, align 8
  %v3184 = load i64, ptr %slot522, align 8
  %v3185 = load i64, ptr %slot517, align 8
  %op3186 = sub i64 %v3184, %v3185
  store i64 %op3186, ptr %slot525, align 8
  %v3187 = load i64, ptr %slot524, align 8
  %cmp3188 = icmp ult i64 %v3187, 24
  %cv3189 = zext i1 %cmp3188 to i32
  store i32 %cv3189, ptr %slot526, align 8
  %v3190 = load i64, ptr %slot525, align 8
  %cmp3191 = icmp ult i64 %v3190, 24
  %cv3192 = zext i1 %cmp3191 to i32
  store i32 %cv3192, ptr %slot527, align 8
  %v3193 = load i32, ptr %slot526, align 8
  %v3194 = load i32, ptr %slot527, align 8
  %op3195 = or i32 %v3193, %v3194
  store i32 %op3195, ptr %slot528, align 8
  %v3196 = load i32, ptr %slot528, align 8
  %cv3197 = zext i32 %v3196 to i64
  %cond3198 = icmp ne i64 %cv3197, 0
  br i1 %cond3198, label %bb_rcmoveslow682, label %bb_rcmovecheck682
bb_rcmovecheck682:
  %v3199 = load i64, ptr %slot517, align 8
  %op3200 = add i64 %v3199, 8
  store i64 %op3200, ptr %slot529, align 8
  %v3201 = load i64, ptr %slot529, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  %ld3203 = load i64, ptr %p3202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3203, ptr %slot530, align 8
  %v3204 = load i64, ptr %slot530, align 8
  %cmp3205 = icmp ne i64 %v3204, 0
  %cv3206 = zext i1 %cmp3205 to i32
  store i32 %cv3206, ptr %slot531, align 8
  %v3207 = load i32, ptr %slot531, align 8
  %cv3208 = zext i32 %v3207 to i64
  %cond3209 = icmp ne i64 %cv3208, 0
  br i1 %cond3209, label %bb_rcmoveheader690, label %bb_rcmovenext690
bb_rcmoveheader690:
  %v3210 = load i64, ptr %slot530, align 8
  %op3211 = sub i64 %v3210, 16
  store i64 %op3211, ptr %slot532, align 8
  %v3212 = load i64, ptr %slot530, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %rgep3214 = getelementptr i8, ptr %p3213, i64 -16
  %ld3215 = load i64, ptr %rgep3214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3215, ptr %slot533, align 8
  %v3216 = load i64, ptr %slot533, align 8
  %op3217 = and i64 %v3216, 5764607523034234881
  store i64 %op3217, ptr %slot534, align 8
  %v3218 = load i64, ptr %slot534, align 8
  %cmp3219 = icmp ne i64 %v3218, 0
  %cv3220 = zext i1 %cmp3219 to i32
  store i32 %cv3220, ptr %slot535, align 8
  %v3221 = load i32, ptr %slot535, align 8
  %cv3222 = zext i32 %v3221 to i64
  %cond3223 = icmp ne i64 %cv3222, 0
  br i1 %cond3223, label %bb_rcmoveslow682, label %bb_rcmovenext690
bb_rcmovenext690:
  %v3224 = load i64, ptr %slot517, align 8
  %v3225 = load i64, ptr %slot522, align 8
  %p3226 = inttoptr i64 %v3224 to ptr
  %p3227 = inttoptr i64 %v3225 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3227, ptr %p3226, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3228 = load i64, ptr %slot517, align 8
  %p3229 = inttoptr i64 %v3228 to ptr
  store i64 0, ptr %p3229, align 8, !alias.scope !3, !noalias !4
  %v3230 = load i64, ptr %slot517, align 8
  %op3231 = add i64 %v3230, 8
  store i64 %op3231, ptr %slot536, align 8
  %v3232 = load i64, ptr %slot536, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i64 0, ptr %p3233, align 8, !alias.scope !3, !noalias !4
  %v3234 = load i64, ptr %slot517, align 8
  %op3235 = add i64 %v3234, 16
  store i64 %op3235, ptr %slot537, align 8
  %v3236 = load i64, ptr %slot537, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  store i64 0, ptr %p3237, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved682
bb_rcmoveslow682:
  %v3238 = load i64, ptr %slot51, align 8
  %v3239 = load i64, ptr %slot522, align 8
  %v3240 = load i64, ptr %slot517, align 8
  %v3241 = load i64, ptr %slot523, align 8
  %cv3242 = trunc i64 %v3241 to i32
  %call3243 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v3238, i64 %v3239, i64 %v3240, i32 %cv3242) nomerge, !dbg !148
  store i32 %call3243, ptr %slot538, align 8
  %v3244 = load i32, ptr %slot538, align 8
  %cv3245 = zext i32 %v3244 to i64
  %cond3246 = icmp ne i64 %cv3245, 0
  br i1 %cond3246, label %bb_rcsuccess699, label %bb_rcfailure699
bb_rcfailure699:
  %v3247 = load i64, ptr %slot51, align 8
  %p3248 = inttoptr i64 %v3247 to ptr
  %call3249 = call i32 @myl_rc_take_failure(ptr %p3248) nomerge, !dbg !148
  store i32 %call3249, ptr %slot539, align 8
  %v3250 = load i64, ptr %slot1, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  %v3252 = load i32, ptr %slot539, align 8
  %call3253 = call i32 @myl_qbe_rc_status(ptr %p3251, i32 %v3252) nomerge, !dbg !148
  store i32 %call3253, ptr %slot540, align 8
  br label %bb_failure
bb_rcsuccess699:
  br label %bb_rcmoved682
bb_rcmoved682:
  %v3254 = load i64, ptr %slot15, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  store i32 0, ptr %p3255, align 4, !alias.scope !3, !noalias !4
  %v3256 = load i64, ptr %slot20, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  store i32 2, ptr %p3257, align 4, !alias.scope !3, !noalias !4
  %v3258 = load i64, ptr %slot19, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  store i32 1, ptr %p3259, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared673
bb_rccopy673:
  %v3260 = load i64, ptr %slot24, align 8
  store i64 %v3260, ptr %slot541, align 8
  %v3261 = load i64, ptr %slot52, align 8
  store i64 %v3261, ptr %slot542, align 8
  %v3262 = load i64, ptr %slot51, align 8
  %v3263 = load i64, ptr %slot541, align 8
  %v3264 = load i64, ptr %slot517, align 8
  %v3265 = load i64, ptr %slot542, align 8
  %cv3266 = trunc i64 %v3265 to i32
  %call3267 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64 %v3262, i64 %v3263, i64 %v3264, i32 %cv3266) nomerge, !dbg !148
  store i32 %call3267, ptr %slot543, align 8
  %v3268 = load i32, ptr %slot543, align 8
  %cv3269 = zext i32 %v3268 to i64
  %cond3270 = icmp ne i64 %cv3269, 0
  br i1 %cond3270, label %bb_rcsuccess708, label %bb_rcfailure708
bb_rcfailure708:
  %v3271 = load i64, ptr %slot51, align 8
  %p3272 = inttoptr i64 %v3271 to ptr
  %call3273 = call i32 @myl_rc_take_failure(ptr %p3272) nomerge, !dbg !148
  store i32 %call3273, ptr %slot544, align 8
  %v3274 = load i64, ptr %slot1, align 8
  %p3275 = inttoptr i64 %v3274 to ptr
  %v3276 = load i32, ptr %slot544, align 8
  %call3277 = call i32 @myl_qbe_rc_status(ptr %p3275, i32 %v3276) nomerge, !dbg !148
  store i32 %call3277, ptr %slot545, align 8
  br label %bb_failure
bb_rcsuccess708:
  %v3278 = load i64, ptr %slot20, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  store i32 2, ptr %p3279, align 4, !alias.scope !3, !noalias !4
  %v3280 = load i64, ptr %slot19, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  store i32 1, ptr %p3281, align 4, !alias.scope !3, !noalias !4
  %v3282 = load i64, ptr %slot15, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %ld3284 = load i32, ptr %p3283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3284, ptr %slot546, align 8
  %v3285 = load i32, ptr %slot546, align 8
  %cv3286 = zext i32 %v3285 to i64
  %cond3287 = icmp ne i64 %cv3286, 0
  br i1 %cond3287, label %bb_rcslotdrop715, label %bb_rcslotdone715
bb_rcslotdrop715:
  %v3288 = load i64, ptr %slot15, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i32 0, ptr %p3289, align 4, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot22, align 8
  store i64 %v3290, ptr %slot547, align 8
  %v3291 = load i64, ptr %slot16, align 8
  %p3292 = inttoptr i64 %v3291 to ptr
  %ld3293 = load i32, ptr %p3292, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3293, ptr %slot548, align 8
  %v3294 = load i32, ptr %slot548, align 8
  %op3295 = and i32 %v3294, 28
  store i32 %op3295, ptr %slot549, align 8
  %v3296 = load i32, ptr %slot549, align 8
  %cv3297 = zext i32 %v3296 to i64
  %cond3298 = icmp ne i64 %cv3297, 0
  br i1 %cond3298, label %bb_rcslotrole715, label %bb_rcslotowner715
bb_rcslotrole715:
  %v3299 = load i64, ptr %slot51, align 8
  store i64 %v3299, ptr %slot550, align 8
  %v3300 = load i64, ptr %slot550, align 8
  %v3301 = load i64, ptr %slot547, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3300, i64 %v3301) nomerge, !dbg !148
  br label %bb_rcslotdone715
bb_rcslotowner715:
  %v3302 = load i64, ptr %slot51, align 8
  store i64 %v3302, ptr %slot551, align 8
  %v3303 = load i64, ptr %slot551, align 8
  %v3304 = load i64, ptr %slot547, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3303, i64 %v3304) nomerge, !dbg !148
  br label %bb_rcslotdone715
bb_rcslotdone715:
  br label %bb_rcprepared673
bb_rcprepared673:
  %v3305 = load i64, ptr %slot24, align 8
  store i64 %v3305, ptr %slot552, align 8
  %v3306 = load i64, ptr %slot44, align 8
  store i64 %v3306, ptr %slot553, align 8
  %v3307 = load i64, ptr %slot552, align 8
  %v3308 = load i64, ptr %slot553, align 8
  %p3309 = inttoptr i64 %v3307 to ptr
  %p3310 = inttoptr i64 %v3308 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3310, ptr %p3309, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot19, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  store i32 0, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  %v3313 = load i64, ptr %slot21, align 8
  %p3314 = inttoptr i64 %v3313 to ptr
  store i32 1, ptr %p3314, align 4, !alias.scope !3, !noalias !4
  %v3315 = load i64, ptr %slot52, align 8
  store i64 %v3315, ptr %slot554, align 8
  %v3316 = load i64, ptr %slot40, align 8
  %p3317 = inttoptr i64 %v3316 to ptr
  %ld3318 = load i64, ptr %p3317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3318, ptr %slot555, align 8
  %v3319 = load i64, ptr %slot553, align 8
  %p3321 = inttoptr i64 %v3319 to ptr
  %gep3322 = getelementptr i8, ptr %p3321, i64 8
  %op3320 = ptrtoint ptr %gep3322 to i64
  store i64 %op3320, ptr %slot556, align 8
  %v3323 = load i64, ptr %slot24, align 8
  store i64 %v3323, ptr %slot557, align 8
  %v3324 = load i64, ptr %slot40, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %ld3326 = load i64, ptr %p3325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3326, ptr %slot558, align 8
  %v3327 = load i64, ptr %slot24, align 8
  store i64 %v3327, ptr %slot559, align 8
  %v3328 = load i64, ptr %slot52, align 8
  store i64 %v3328, ptr %slot560, align 8
  %v3329 = load i64, ptr %slot558, align 8
  %op3330 = add i64 %v3329, 0
  store i64 %op3330, ptr %slot561, align 8
  %v3331 = load i64, ptr %slot561, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  %ld3333 = load i64, ptr %p3332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3333, ptr %slot562, align 8
  %v3334 = load i64, ptr %slot562, align 8
  %cmp3335 = icmp ne i64 %v3334, 0
  %cv3336 = zext i1 %cmp3335 to i32
  store i32 %cv3336, ptr %slot563, align 8
  %v3337 = load i32, ptr %slot563, align 8
  %cv3338 = zext i32 %v3337 to i64
  %cond3339 = icmp ne i64 %cv3338, 0
  br i1 %cond3339, label %bb_rcmoveheader737, label %bb_rcmovenext737
bb_rcmoveheader737:
  %v3340 = load i64, ptr %slot562, align 8
  %op3341 = sub i64 %v3340, 16
  store i64 %op3341, ptr %slot564, align 8
  %v3342 = load i64, ptr %slot562, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  %rgep3344 = getelementptr i8, ptr %p3343, i64 -16
  %ld3345 = load i64, ptr %rgep3344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3345, ptr %slot565, align 8
  %v3346 = load i64, ptr %slot565, align 8
  %op3347 = and i64 %v3346, 5764607523034234881
  store i64 %op3347, ptr %slot566, align 8
  %v3348 = load i64, ptr %slot566, align 8
  %cmp3349 = icmp ne i64 %v3348, 0
  %cv3350 = zext i1 %cmp3349 to i32
  store i32 %cv3350, ptr %slot567, align 8
  %v3351 = load i32, ptr %slot567, align 8
  %cv3352 = zext i32 %v3351 to i64
  %cond3353 = icmp ne i64 %cv3352, 0
  br i1 %cond3353, label %bb_rcmoveslow734, label %bb_rcmovenext737
bb_rcmovenext737:
  %v3354 = load i64, ptr %slot558, align 8
  %v3355 = load i64, ptr %slot559, align 8
  %p3356 = inttoptr i64 %v3354 to ptr
  %p3357 = inttoptr i64 %v3355 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3357, ptr %p3356, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3358 = load i64, ptr %slot558, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  store i64 0, ptr %p3359, align 8, !alias.scope !3, !noalias !4
  %v3360 = load i64, ptr %slot558, align 8
  %op3361 = add i64 %v3360, 8
  store i64 %op3361, ptr %slot568, align 8
  %v3362 = load i64, ptr %slot568, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  store i64 0, ptr %p3363, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved734
bb_rcmoveslow734:
  %v3364 = load i64, ptr %slot51, align 8
  %v3365 = load i64, ptr %slot559, align 8
  %v3366 = load i64, ptr %slot558, align 8
  %v3367 = load i64, ptr %slot560, align 8
  %cv3368 = trunc i64 %v3367 to i32
  %call3369 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v3364, i64 %v3365, i64 %v3366, i32 %cv3368) nomerge, !dbg !148
  store i32 %call3369, ptr %slot569, align 8
  %v3370 = load i32, ptr %slot569, align 8
  %cv3371 = zext i32 %v3370 to i64
  %cond3372 = icmp ne i64 %cv3371, 0
  br i1 %cond3372, label %bb_rcsuccess745, label %bb_rcfailure745
bb_rcfailure745:
  %v3373 = load i64, ptr %slot51, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  %call3375 = call i32 @myl_rc_take_failure(ptr %p3374) nomerge, !dbg !148
  store i32 %call3375, ptr %slot570, align 8
  %v3376 = load i64, ptr %slot1, align 8
  %p3377 = inttoptr i64 %v3376 to ptr
  %v3378 = load i32, ptr %slot570, align 8
  %call3379 = call i32 @myl_qbe_rc_status(ptr %p3377, i32 %v3378) nomerge, !dbg !148
  store i32 %call3379, ptr %slot571, align 8
  br label %bb_failure
bb_rcsuccess745:
  br label %bb_rcmoved734
bb_rcmoved734:
  %v3380 = load i64, ptr %slot17, align 8
  %p3381 = inttoptr i64 %v3380 to ptr
  store i32 0, ptr %p3381, align 4, !alias.scope !3, !noalias !4
  %v3382 = load i64, ptr %slot20, align 8
  %p3383 = inttoptr i64 %v3382 to ptr
  store i32 2, ptr %p3383, align 4, !alias.scope !3, !noalias !4
  %v3384 = load i64, ptr %slot19, align 8
  %p3385 = inttoptr i64 %v3384 to ptr
  store i32 1, ptr %p3385, align 4, !alias.scope !3, !noalias !4
  %v3386 = load i64, ptr %slot24, align 8
  store i64 %v3386, ptr %slot572, align 8
  %v3387 = load i64, ptr %slot572, align 8
  %v3388 = load i64, ptr %slot557, align 8
  %p3389 = inttoptr i64 %v3387 to ptr
  %p3390 = inttoptr i64 %v3388 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3390, ptr %p3389, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3391 = load i64, ptr %slot19, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  store i32 0, ptr %p3392, align 4, !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot20, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  store i32 2, ptr %p3394, align 4, !alias.scope !3, !noalias !4
  %v3395 = load i64, ptr %slot19, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  store i32 1, ptr %p3396, align 4, !alias.scope !3, !noalias !4
  %v3397 = load i64, ptr %slot51, align 8
  store i64 %v3397, ptr %slot573, align 8
  %v3398 = load i64, ptr %slot573, align 8
  %v3399 = load i64, ptr %slot556, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3398, i64 %v3399) nomerge, !dbg !148
  %v3400 = load i64, ptr %slot557, align 8
  %v3401 = load i64, ptr %slot556, align 8
  %p3402 = inttoptr i64 %v3400 to ptr
  %p3403 = inttoptr i64 %v3401 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3403, ptr %p3402, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3404 = load i64, ptr %slot19, align 8
  %p3405 = inttoptr i64 %v3404 to ptr
  store i32 0, ptr %p3405, align 4, !alias.scope !3, !noalias !4
  %v3406 = load i64, ptr %slot553, align 8
  %v3407 = load i64, ptr %slot39, align 8
  %p3408 = inttoptr i64 %v3407 to ptr
  store i64 %v3406, ptr %p3408, align 8, !alias.scope !3, !noalias !4
  %v3409 = load i64, ptr %slot39, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  %ld3411 = load i64, ptr %p3410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3411, ptr %slot574, align 8
  %v3412 = load i64, ptr %slot24, align 8
  store i64 %v3412, ptr %slot575, align 8
  %v3413 = load i64, ptr %slot574, align 8
  %v3414 = load i64, ptr %slot575, align 8
  %p3415 = inttoptr i64 %v3413 to ptr
  %p3416 = inttoptr i64 %v3414 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3416, ptr %p3415, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3417 = load i64, ptr %slot20, align 8
  %p3418 = inttoptr i64 %v3417 to ptr
  store i32 2, ptr %p3418, align 4, !alias.scope !3, !noalias !4
  %v3419 = load i64, ptr %slot19, align 8
  %p3420 = inttoptr i64 %v3419 to ptr
  store i32 1, ptr %p3420, align 4, !alias.scope !3, !noalias !4
  %v3421 = load i64, ptr %slot15, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  %ld3423 = load i32, ptr %p3422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3423, ptr %slot576, align 8
  %v3424 = load i32, ptr %slot576, align 8
  %cv3425 = zext i32 %v3424 to i64
  %cond3426 = icmp ne i64 %cv3425, 0
  br i1 %cond3426, label %bb_rcslotdrop763, label %bb_rcslotdone763
bb_rcslotdrop763:
  %v3427 = load i64, ptr %slot15, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  store i32 0, ptr %p3428, align 4, !alias.scope !3, !noalias !4
  %v3429 = load i64, ptr %slot22, align 8
  store i64 %v3429, ptr %slot577, align 8
  %v3430 = load i64, ptr %slot16, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %ld3432 = load i32, ptr %p3431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3432, ptr %slot578, align 8
  %v3433 = load i32, ptr %slot578, align 8
  %op3434 = and i32 %v3433, 28
  store i32 %op3434, ptr %slot579, align 8
  %v3435 = load i32, ptr %slot579, align 8
  %cv3436 = zext i32 %v3435 to i64
  %cond3437 = icmp ne i64 %cv3436, 0
  br i1 %cond3437, label %bb_rcslotrole763, label %bb_rcslotowner763
bb_rcslotrole763:
  %v3438 = load i64, ptr %slot51, align 8
  store i64 %v3438, ptr %slot580, align 8
  %v3439 = load i64, ptr %slot580, align 8
  %v3440 = load i64, ptr %slot577, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3439, i64 %v3440) nomerge, !dbg !148
  br label %bb_rcslotdone763
bb_rcslotowner763:
  %v3441 = load i64, ptr %slot51, align 8
  store i64 %v3441, ptr %slot581, align 8
  %v3442 = load i64, ptr %slot581, align 8
  %v3443 = load i64, ptr %slot577, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3442, i64 %v3443) nomerge, !dbg !148
  br label %bb_rcslotdone763
bb_rcslotdone763:
  %v3444 = load i64, ptr %slot17, align 8
  %p3445 = inttoptr i64 %v3444 to ptr
  %ld3446 = load i32, ptr %p3445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3446, ptr %slot582, align 8
  %v3447 = load i32, ptr %slot582, align 8
  %cv3448 = zext i32 %v3447 to i64
  %cond3449 = icmp ne i64 %cv3448, 0
  br i1 %cond3449, label %bb_rcslotdrop772, label %bb_rcslotdone772
bb_rcslotdrop772:
  %v3450 = load i64, ptr %slot17, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  store i32 0, ptr %p3451, align 4, !alias.scope !3, !noalias !4
  %v3452 = load i64, ptr %slot23, align 8
  store i64 %v3452, ptr %slot583, align 8
  %v3453 = load i64, ptr %slot18, align 8
  %p3454 = inttoptr i64 %v3453 to ptr
  %ld3455 = load i32, ptr %p3454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3455, ptr %slot584, align 8
  %v3456 = load i32, ptr %slot584, align 8
  %op3457 = and i32 %v3456, 28
  store i32 %op3457, ptr %slot585, align 8
  %v3458 = load i32, ptr %slot585, align 8
  %cv3459 = zext i32 %v3458 to i64
  %cond3460 = icmp ne i64 %cv3459, 0
  br i1 %cond3460, label %bb_rcslotrole772, label %bb_rcslotowner772
bb_rcslotrole772:
  %v3461 = load i64, ptr %slot51, align 8
  store i64 %v3461, ptr %slot586, align 8
  %v3462 = load i64, ptr %slot586, align 8
  %v3463 = load i64, ptr %slot583, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3462, i64 %v3463) nomerge, !dbg !148
  br label %bb_rcslotdone772
bb_rcslotowner772:
  %v3464 = load i64, ptr %slot51, align 8
  store i64 %v3464, ptr %slot587, align 8
  %v3465 = load i64, ptr %slot587, align 8
  %v3466 = load i64, ptr %slot583, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3465, i64 %v3466) nomerge, !dbg !148
  br label %bb_rcslotdone772
bb_rcslotdone772:
  %v3467 = load i64, ptr %slot22, align 8
  store i64 %v3467, ptr %slot588, align 8
  %v3468 = load i64, ptr %slot24, align 8
  store i64 %v3468, ptr %slot589, align 8
  %v3469 = load i64, ptr %slot589, align 8
  %v3470 = load i64, ptr %slot588, align 8
  %p3471 = inttoptr i64 %v3469 to ptr
  %p3472 = inttoptr i64 %v3470 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3472, ptr %p3471, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3473 = load i64, ptr %slot16, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  store i32 2, ptr %p3474, align 4, !alias.scope !3, !noalias !4
  %v3475 = load i64, ptr %slot20, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  %ld3477 = load i32, ptr %p3476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3477, ptr %slot590, align 8
  %v3478 = load i32, ptr %slot590, align 8
  %v3479 = load i64, ptr %slot16, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  store i32 %v3478, ptr %p3480, align 4, !alias.scope !3, !noalias !4
  %v3481 = load i64, ptr %slot19, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  store i32 0, ptr %p3482, align 4, !alias.scope !3, !noalias !4
  %v3483 = load i64, ptr %slot15, align 8
  %p3484 = inttoptr i64 %v3483 to ptr
  store i32 1, ptr %p3484, align 4, !alias.scope !3, !noalias !4
  %v3485 = load i64, ptr %slot588, align 8
  %v3486 = load i64, ptr %slot39, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  store i64 %v3485, ptr %p3487, align 8, !alias.scope !3, !noalias !4
  %v3488 = load i64, ptr %slot39, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %ld3490 = load i64, ptr %p3489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3490, ptr %slot591, align 8
  %v3491 = load i64, ptr %slot15, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %ld3493 = load i32, ptr %p3492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3493, ptr %slot592, align 8
  %v3494 = load i64, ptr %slot16, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  %ld3496 = load i32, ptr %p3495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3496, ptr %slot593, align 8
  %v3497 = load i32, ptr %slot593, align 8
  %op3498 = and i32 %v3497, 24
  store i32 %op3498, ptr %slot593, align 8
  %v3499 = load i32, ptr %slot593, align 8
  %cmp3500 = icmp eq i32 %v3499, 0
  %cv3501 = zext i1 %cmp3500 to i32
  store i32 %cv3501, ptr %slot594, align 8
  %v3502 = load i32, ptr %slot592, align 8
  %v3503 = load i32, ptr %slot594, align 8
  %op3504 = and i32 %v3502, %v3503
  store i32 %op3504, ptr %slot595, align 8
  %v3505 = load i32, ptr %slot595, align 8
  %cv3506 = zext i32 %v3505 to i64
  %cond3507 = icmp ne i64 %cv3506, 0
  br i1 %cond3507, label %bb_rctake788, label %bb_rccopy788
bb_rctake788:
  %v3508 = load i64, ptr %slot24, align 8
  store i64 %v3508, ptr %slot596, align 8
  %v3509 = load i64, ptr %slot52, align 8
  store i64 %v3509, ptr %slot597, align 8
  %v3510 = load i64, ptr %slot591, align 8
  %v3511 = load i64, ptr %slot596, align 8
  %op3512 = sub i64 %v3510, %v3511
  store i64 %op3512, ptr %slot598, align 8
  %v3513 = load i64, ptr %slot596, align 8
  %v3514 = load i64, ptr %slot591, align 8
  %op3515 = sub i64 %v3513, %v3514
  store i64 %op3515, ptr %slot599, align 8
  %v3516 = load i64, ptr %slot598, align 8
  %cmp3517 = icmp ult i64 %v3516, 24
  %cv3518 = zext i1 %cmp3517 to i32
  store i32 %cv3518, ptr %slot600, align 8
  %v3519 = load i64, ptr %slot599, align 8
  %cmp3520 = icmp ult i64 %v3519, 24
  %cv3521 = zext i1 %cmp3520 to i32
  store i32 %cv3521, ptr %slot601, align 8
  %v3522 = load i32, ptr %slot600, align 8
  %v3523 = load i32, ptr %slot601, align 8
  %op3524 = or i32 %v3522, %v3523
  store i32 %op3524, ptr %slot602, align 8
  %v3525 = load i32, ptr %slot602, align 8
  %cv3526 = zext i32 %v3525 to i64
  %cond3527 = icmp ne i64 %cv3526, 0
  br i1 %cond3527, label %bb_rcmoveslow797, label %bb_rcmovecheck797
bb_rcmovecheck797:
  %v3528 = load i64, ptr %slot591, align 8
  %op3529 = add i64 %v3528, 8
  store i64 %op3529, ptr %slot603, align 8
  %v3530 = load i64, ptr %slot603, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  %ld3532 = load i64, ptr %p3531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3532, ptr %slot604, align 8
  %v3533 = load i64, ptr %slot604, align 8
  %cmp3534 = icmp ne i64 %v3533, 0
  %cv3535 = zext i1 %cmp3534 to i32
  store i32 %cv3535, ptr %slot605, align 8
  %v3536 = load i32, ptr %slot605, align 8
  %cv3537 = zext i32 %v3536 to i64
  %cond3538 = icmp ne i64 %cv3537, 0
  br i1 %cond3538, label %bb_rcmoveheader805, label %bb_rcmovenext805
bb_rcmoveheader805:
  %v3539 = load i64, ptr %slot604, align 8
  %op3540 = sub i64 %v3539, 16
  store i64 %op3540, ptr %slot606, align 8
  %v3541 = load i64, ptr %slot604, align 8
  %p3542 = inttoptr i64 %v3541 to ptr
  %rgep3543 = getelementptr i8, ptr %p3542, i64 -16
  %ld3544 = load i64, ptr %rgep3543, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3544, ptr %slot607, align 8
  %v3545 = load i64, ptr %slot607, align 8
  %op3546 = and i64 %v3545, 5764607523034234881
  store i64 %op3546, ptr %slot608, align 8
  %v3547 = load i64, ptr %slot608, align 8
  %cmp3548 = icmp ne i64 %v3547, 0
  %cv3549 = zext i1 %cmp3548 to i32
  store i32 %cv3549, ptr %slot609, align 8
  %v3550 = load i32, ptr %slot609, align 8
  %cv3551 = zext i32 %v3550 to i64
  %cond3552 = icmp ne i64 %cv3551, 0
  br i1 %cond3552, label %bb_rcmoveslow797, label %bb_rcmovenext805
bb_rcmovenext805:
  %v3553 = load i64, ptr %slot591, align 8
  %v3554 = load i64, ptr %slot596, align 8
  %p3555 = inttoptr i64 %v3553 to ptr
  %p3556 = inttoptr i64 %v3554 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3556, ptr %p3555, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3557 = load i64, ptr %slot591, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  store i64 0, ptr %p3558, align 8, !alias.scope !3, !noalias !4
  %v3559 = load i64, ptr %slot591, align 8
  %op3560 = add i64 %v3559, 8
  store i64 %op3560, ptr %slot610, align 8
  %v3561 = load i64, ptr %slot610, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  store i64 0, ptr %p3562, align 8, !alias.scope !3, !noalias !4
  %v3563 = load i64, ptr %slot591, align 8
  %op3564 = add i64 %v3563, 16
  store i64 %op3564, ptr %slot611, align 8
  %v3565 = load i64, ptr %slot611, align 8
  %p3566 = inttoptr i64 %v3565 to ptr
  store i64 0, ptr %p3566, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved797
bb_rcmoveslow797:
  %v3567 = load i64, ptr %slot51, align 8
  %v3568 = load i64, ptr %slot596, align 8
  %v3569 = load i64, ptr %slot591, align 8
  %v3570 = load i64, ptr %slot597, align 8
  %cv3571 = trunc i64 %v3570 to i32
  %call3572 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v3567, i64 %v3568, i64 %v3569, i32 %cv3571) nomerge, !dbg !150
  store i32 %call3572, ptr %slot612, align 8
  %v3573 = load i32, ptr %slot612, align 8
  %cv3574 = zext i32 %v3573 to i64
  %cond3575 = icmp ne i64 %cv3574, 0
  br i1 %cond3575, label %bb_rcsuccess814, label %bb_rcfailure814
bb_rcfailure814:
  %v3576 = load i64, ptr %slot51, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  %call3578 = call i32 @myl_rc_take_failure(ptr %p3577) nomerge, !dbg !150
  store i32 %call3578, ptr %slot613, align 8
  %v3579 = load i64, ptr %slot1, align 8
  %p3580 = inttoptr i64 %v3579 to ptr
  %v3581 = load i32, ptr %slot613, align 8
  %call3582 = call i32 @myl_qbe_rc_status(ptr %p3580, i32 %v3581) nomerge, !dbg !150
  store i32 %call3582, ptr %slot614, align 8
  br label %bb_failure
bb_rcsuccess814:
  br label %bb_rcmoved797
bb_rcmoved797:
  %v3583 = load i64, ptr %slot15, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  store i32 0, ptr %p3584, align 4, !alias.scope !3, !noalias !4
  %v3585 = load i64, ptr %slot20, align 8
  %p3586 = inttoptr i64 %v3585 to ptr
  store i32 2, ptr %p3586, align 4, !alias.scope !3, !noalias !4
  %v3587 = load i64, ptr %slot19, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  store i32 1, ptr %p3588, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared788
bb_rccopy788:
  %v3589 = load i64, ptr %slot24, align 8
  store i64 %v3589, ptr %slot615, align 8
  %v3590 = load i64, ptr %slot52, align 8
  store i64 %v3590, ptr %slot616, align 8
  %v3591 = load i64, ptr %slot51, align 8
  %v3592 = load i64, ptr %slot615, align 8
  %v3593 = load i64, ptr %slot591, align 8
  %v3594 = load i64, ptr %slot616, align 8
  %cv3595 = trunc i64 %v3594 to i32
  %call3596 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64 %v3591, i64 %v3592, i64 %v3593, i32 %cv3595) nomerge, !dbg !150
  store i32 %call3596, ptr %slot617, align 8
  %v3597 = load i32, ptr %slot617, align 8
  %cv3598 = zext i32 %v3597 to i64
  %cond3599 = icmp ne i64 %cv3598, 0
  br i1 %cond3599, label %bb_rcsuccess823, label %bb_rcfailure823
bb_rcfailure823:
  %v3600 = load i64, ptr %slot51, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  %call3602 = call i32 @myl_rc_take_failure(ptr %p3601) nomerge, !dbg !150
  store i32 %call3602, ptr %slot618, align 8
  %v3603 = load i64, ptr %slot1, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  %v3605 = load i32, ptr %slot618, align 8
  %call3606 = call i32 @myl_qbe_rc_status(ptr %p3604, i32 %v3605) nomerge, !dbg !150
  store i32 %call3606, ptr %slot619, align 8
  br label %bb_failure
bb_rcsuccess823:
  %v3607 = load i64, ptr %slot20, align 8
  %p3608 = inttoptr i64 %v3607 to ptr
  store i32 2, ptr %p3608, align 4, !alias.scope !3, !noalias !4
  %v3609 = load i64, ptr %slot19, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  store i32 1, ptr %p3610, align 4, !alias.scope !3, !noalias !4
  %v3611 = load i64, ptr %slot15, align 8
  %p3612 = inttoptr i64 %v3611 to ptr
  %ld3613 = load i32, ptr %p3612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3613, ptr %slot620, align 8
  %v3614 = load i32, ptr %slot620, align 8
  %cv3615 = zext i32 %v3614 to i64
  %cond3616 = icmp ne i64 %cv3615, 0
  br i1 %cond3616, label %bb_rcslotdrop830, label %bb_rcslotdone830
bb_rcslotdrop830:
  %v3617 = load i64, ptr %slot15, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  store i32 0, ptr %p3618, align 4, !alias.scope !3, !noalias !4
  %v3619 = load i64, ptr %slot22, align 8
  store i64 %v3619, ptr %slot621, align 8
  %v3620 = load i64, ptr %slot16, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %ld3622 = load i32, ptr %p3621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3622, ptr %slot622, align 8
  %v3623 = load i32, ptr %slot622, align 8
  %op3624 = and i32 %v3623, 28
  store i32 %op3624, ptr %slot623, align 8
  %v3625 = load i32, ptr %slot623, align 8
  %cv3626 = zext i32 %v3625 to i64
  %cond3627 = icmp ne i64 %cv3626, 0
  br i1 %cond3627, label %bb_rcslotrole830, label %bb_rcslotowner830
bb_rcslotrole830:
  %v3628 = load i64, ptr %slot51, align 8
  store i64 %v3628, ptr %slot624, align 8
  %v3629 = load i64, ptr %slot624, align 8
  %v3630 = load i64, ptr %slot621, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3629, i64 %v3630) nomerge, !dbg !150
  br label %bb_rcslotdone830
bb_rcslotowner830:
  %v3631 = load i64, ptr %slot621, align 8
  %p3633 = inttoptr i64 %v3631 to ptr
  %gep3634 = getelementptr i8, ptr %p3633, i64 8
  %op3632 = ptrtoint ptr %gep3634 to i64
  store i64 %op3632, ptr %slot625, align 8
  %v3635 = load i64, ptr %slot51, align 8
  store i64 %v3635, ptr %slot626, align 8
  %v3636 = load i64, ptr %slot625, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  %ld3638 = load i64, ptr %p3637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3638, ptr %slot627, align 8
  %v3639 = load i64, ptr %slot627, align 8
  %cmp3640 = icmp ne i64 %v3639, 0
  %cv3641 = zext i1 %cmp3640 to i32
  store i32 %cv3641, ptr %slot628, align 8
  %v3642 = load i32, ptr %slot628, align 8
  %cv3643 = zext i32 %v3642 to i64
  %cond3644 = icmp ne i64 %cv3643, 0
  br i1 %cond3644, label %bb_rcgnn848, label %bb_rcgdone848
bb_rcgnn848:
  %v3645 = load i64, ptr %slot627, align 8
  %op3646 = sub i64 %v3645, 16
  store i64 %op3646, ptr %slot629, align 8
  %v3647 = load i64, ptr %slot627, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  %rgep3649 = getelementptr i8, ptr %p3648, i64 -16
  %ld3650 = load i64, ptr %rgep3649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3650, ptr %slot630, align 8
  %v3651 = load i64, ptr %slot630, align 8
  %op3652 = and i64 %v3651, 4611686018427387906
  store i64 %op3652, ptr %slot631, align 8
  %v3653 = load i64, ptr %slot631, align 8
  %cmp3654 = icmp ne i64 %v3653, 0
  %cv3655 = zext i1 %cmp3654 to i32
  store i32 %cv3655, ptr %slot632, align 8
  %v3656 = load i32, ptr %slot632, align 8
  %cv3657 = zext i32 %v3656 to i64
  %cond3658 = icmp ne i64 %cv3657, 0
  br i1 %cond3658, label %bb_rcgclear848, label %bb_rcgcounted848
bb_rcgcounted848:
  %v3659 = load i64, ptr %slot627, align 8
  %op3660 = sub i64 %v3659, 32
  store i64 %op3660, ptr %slot633, align 8
  %v3661 = load i64, ptr %slot627, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %rgep3663 = getelementptr i8, ptr %p3662, i64 -32
  %ld3664 = load i64, ptr %rgep3663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3664, ptr %slot634, align 8
  %v3665 = load i64, ptr %slot634, align 8
  %op3666 = sub i64 %v3665, 1
  store i64 %op3666, ptr %slot635, align 8
  %v3667 = load i64, ptr %slot635, align 8
  %cmp3668 = icmp eq i64 %v3667, 0
  %cv3669 = zext i1 %cmp3668 to i32
  store i32 %cv3669, ptr %slot636, align 8
  %v3670 = load i32, ptr %slot636, align 8
  %cv3671 = zext i32 %v3670 to i64
  %cond3672 = icmp ne i64 %cv3671, 0
  br i1 %cond3672, label %bb_rcglast848, label %bb_rcgdec848
bb_rcglast848:
  %v3673 = load i64, ptr %slot627, align 8
  %op3674 = sub i64 %v3673, 24
  store i64 %op3674, ptr %slot637, align 8
  %v3675 = load i64, ptr %slot627, align 8
  %p3676 = inttoptr i64 %v3675 to ptr
  %rgep3677 = getelementptr i8, ptr %p3676, i64 -24
  %ld3678 = load i64, ptr %rgep3677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3678, ptr %slot638, align 8
  %v3679 = load i64, ptr %slot638, align 8
  %cmp3680 = icmp ne i64 %v3679, 0
  %cv3681 = zext i1 %cmp3680 to i32
  store i32 %cv3681, ptr %slot639, align 8
  %v3682 = load i32, ptr %slot639, align 8
  %cv3683 = zext i32 %v3682 to i64
  %cond3684 = icmp ne i64 %cv3683, 0
  br i1 %cond3684, label %bb_rcgdec848, label %bb_rcgslow848
bb_rcgslow848:
  %v3685 = load i64, ptr %slot626, align 8
  %v3686 = load i64, ptr %slot625, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3685, i64 %v3686) nomerge, !dbg !150
  br label %bb_rcgdone848
bb_rcgdec848:
  %v3687 = load i64, ptr %slot635, align 8
  %v3688 = load i64, ptr %slot627, align 8
  %p3689 = inttoptr i64 %v3688 to ptr
  %rgep3690 = getelementptr i8, ptr %p3689, i64 -32
  store i64 %v3687, ptr %rgep3690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear848
bb_rcgclear848:
  %v3691 = load i64, ptr %slot625, align 8
  %p3692 = inttoptr i64 %v3691 to ptr
  store i64 0, ptr %p3692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone848
bb_rcgdone848:
  %v3693 = load i64, ptr %slot621, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  store i64 0, ptr %p3694, align 8, !alias.scope !3, !noalias !4
  %v3695 = load i64, ptr %slot621, align 8
  %p3697 = inttoptr i64 %v3695 to ptr
  %gep3698 = getelementptr i8, ptr %p3697, i64 8
  %op3696 = ptrtoint ptr %gep3698 to i64
  store i64 %op3696, ptr %slot640, align 8
  %v3699 = load i64, ptr %slot640, align 8
  %p3700 = inttoptr i64 %v3699 to ptr
  store i64 0, ptr %p3700, align 8, !alias.scope !3, !noalias !4
  %v3701 = load i64, ptr %slot621, align 8
  %p3703 = inttoptr i64 %v3701 to ptr
  %gep3704 = getelementptr i8, ptr %p3703, i64 16
  %op3702 = ptrtoint ptr %gep3704 to i64
  store i64 %op3702, ptr %slot641, align 8
  %v3705 = load i64, ptr %slot641, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  store i64 0, ptr %p3706, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone830
bb_rcslotdone830:
  br label %bb_rcprepared788
bb_rcprepared788:
  %v3707 = load i64, ptr %slot7, align 8
  %p3708 = inttoptr i64 %v3707 to ptr
  %ld3709 = load i32, ptr %p3708, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3709, ptr %slot642, align 8
  %v3710 = load i32, ptr %slot642, align 8
  %cv3711 = zext i32 %v3710 to i64
  %cond3712 = icmp ne i64 %cv3711, 0
  br i1 %cond3712, label %bb_rcslotdrop857, label %bb_rcslotdone857
bb_rcslotdrop857:
  %v3713 = load i64, ptr %slot7, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  store i32 0, ptr %p3714, align 4, !alias.scope !3, !noalias !4
  %v3715 = load i64, ptr %slot33, align 8
  store i64 %v3715, ptr %slot643, align 8
  %v3716 = load i64, ptr %slot8, align 8
  %p3717 = inttoptr i64 %v3716 to ptr
  %ld3718 = load i32, ptr %p3717, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3718, ptr %slot644, align 8
  %v3719 = load i32, ptr %slot644, align 8
  %op3720 = and i32 %v3719, 28
  store i32 %op3720, ptr %slot645, align 8
  %v3721 = load i32, ptr %slot645, align 8
  %cv3722 = zext i32 %v3721 to i64
  %cond3723 = icmp ne i64 %cv3722, 0
  br i1 %cond3723, label %bb_rcslotrole857, label %bb_rcslotowner857
bb_rcslotrole857:
  %v3724 = load i64, ptr %slot51, align 8
  store i64 %v3724, ptr %slot646, align 8
  %v3725 = load i64, ptr %slot646, align 8
  %v3726 = load i64, ptr %slot643, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3725, i64 %v3726) nomerge, !dbg !150
  br label %bb_rcslotdone857
bb_rcslotowner857:
  %v3727 = load i64, ptr %slot643, align 8
  %p3729 = inttoptr i64 %v3727 to ptr
  %gep3730 = getelementptr i8, ptr %p3729, i64 8
  %op3728 = ptrtoint ptr %gep3730 to i64
  store i64 %op3728, ptr %slot647, align 8
  %v3731 = load i64, ptr %slot51, align 8
  store i64 %v3731, ptr %slot648, align 8
  %v3732 = load i64, ptr %slot647, align 8
  %p3733 = inttoptr i64 %v3732 to ptr
  %ld3734 = load i64, ptr %p3733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3734, ptr %slot649, align 8
  %v3735 = load i64, ptr %slot649, align 8
  %cmp3736 = icmp ne i64 %v3735, 0
  %cv3737 = zext i1 %cmp3736 to i32
  store i32 %cv3737, ptr %slot650, align 8
  %v3738 = load i32, ptr %slot650, align 8
  %cv3739 = zext i32 %v3738 to i64
  %cond3740 = icmp ne i64 %cv3739, 0
  br i1 %cond3740, label %bb_rcgnn875, label %bb_rcgdone875
bb_rcgnn875:
  %v3741 = load i64, ptr %slot649, align 8
  %op3742 = sub i64 %v3741, 16
  store i64 %op3742, ptr %slot651, align 8
  %v3743 = load i64, ptr %slot649, align 8
  %p3744 = inttoptr i64 %v3743 to ptr
  %rgep3745 = getelementptr i8, ptr %p3744, i64 -16
  %ld3746 = load i64, ptr %rgep3745, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3746, ptr %slot652, align 8
  %v3747 = load i64, ptr %slot652, align 8
  %op3748 = and i64 %v3747, 4611686018427387906
  store i64 %op3748, ptr %slot653, align 8
  %v3749 = load i64, ptr %slot653, align 8
  %cmp3750 = icmp ne i64 %v3749, 0
  %cv3751 = zext i1 %cmp3750 to i32
  store i32 %cv3751, ptr %slot654, align 8
  %v3752 = load i32, ptr %slot654, align 8
  %cv3753 = zext i32 %v3752 to i64
  %cond3754 = icmp ne i64 %cv3753, 0
  br i1 %cond3754, label %bb_rcgclear875, label %bb_rcgcounted875
bb_rcgcounted875:
  %v3755 = load i64, ptr %slot649, align 8
  %op3756 = sub i64 %v3755, 32
  store i64 %op3756, ptr %slot655, align 8
  %v3757 = load i64, ptr %slot649, align 8
  %p3758 = inttoptr i64 %v3757 to ptr
  %rgep3759 = getelementptr i8, ptr %p3758, i64 -32
  %ld3760 = load i64, ptr %rgep3759, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3760, ptr %slot656, align 8
  %v3761 = load i64, ptr %slot656, align 8
  %op3762 = sub i64 %v3761, 1
  store i64 %op3762, ptr %slot657, align 8
  %v3763 = load i64, ptr %slot657, align 8
  %cmp3764 = icmp eq i64 %v3763, 0
  %cv3765 = zext i1 %cmp3764 to i32
  store i32 %cv3765, ptr %slot658, align 8
  %v3766 = load i32, ptr %slot658, align 8
  %cv3767 = zext i32 %v3766 to i64
  %cond3768 = icmp ne i64 %cv3767, 0
  br i1 %cond3768, label %bb_rcglast875, label %bb_rcgdec875
bb_rcglast875:
  %v3769 = load i64, ptr %slot649, align 8
  %op3770 = sub i64 %v3769, 24
  store i64 %op3770, ptr %slot659, align 8
  %v3771 = load i64, ptr %slot649, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  %rgep3773 = getelementptr i8, ptr %p3772, i64 -24
  %ld3774 = load i64, ptr %rgep3773, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3774, ptr %slot660, align 8
  %v3775 = load i64, ptr %slot660, align 8
  %cmp3776 = icmp ne i64 %v3775, 0
  %cv3777 = zext i1 %cmp3776 to i32
  store i32 %cv3777, ptr %slot661, align 8
  %v3778 = load i32, ptr %slot661, align 8
  %cv3779 = zext i32 %v3778 to i64
  %cond3780 = icmp ne i64 %cv3779, 0
  br i1 %cond3780, label %bb_rcgdec875, label %bb_rcgslow875
bb_rcgslow875:
  %v3781 = load i64, ptr %slot648, align 8
  %v3782 = load i64, ptr %slot647, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3781, i64 %v3782) nomerge, !dbg !150
  br label %bb_rcgdone875
bb_rcgdec875:
  %v3783 = load i64, ptr %slot657, align 8
  %v3784 = load i64, ptr %slot649, align 8
  %p3785 = inttoptr i64 %v3784 to ptr
  %rgep3786 = getelementptr i8, ptr %p3785, i64 -32
  store i64 %v3783, ptr %rgep3786, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear875
bb_rcgclear875:
  %v3787 = load i64, ptr %slot647, align 8
  %p3788 = inttoptr i64 %v3787 to ptr
  store i64 0, ptr %p3788, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone875
bb_rcgdone875:
  %v3789 = load i64, ptr %slot643, align 8
  %p3790 = inttoptr i64 %v3789 to ptr
  store i64 0, ptr %p3790, align 8, !alias.scope !3, !noalias !4
  %v3791 = load i64, ptr %slot643, align 8
  %p3793 = inttoptr i64 %v3791 to ptr
  %gep3794 = getelementptr i8, ptr %p3793, i64 8
  %op3792 = ptrtoint ptr %gep3794 to i64
  store i64 %op3792, ptr %slot662, align 8
  %v3795 = load i64, ptr %slot662, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  store i64 0, ptr %p3796, align 8, !alias.scope !3, !noalias !4
  %v3797 = load i64, ptr %slot643, align 8
  %p3799 = inttoptr i64 %v3797 to ptr
  %gep3800 = getelementptr i8, ptr %p3799, i64 16
  %op3798 = ptrtoint ptr %gep3800 to i64
  store i64 %op3798, ptr %slot663, align 8
  %v3801 = load i64, ptr %slot663, align 8
  %p3802 = inttoptr i64 %v3801 to ptr
  store i64 0, ptr %p3802, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone857
bb_rcslotdone857:
  %v3803 = load i64, ptr %slot33, align 8
  store i64 %v3803, ptr %slot664, align 8
  %v3804 = load i64, ptr %slot24, align 8
  store i64 %v3804, ptr %slot665, align 8
  %v3805 = load i64, ptr %slot665, align 8
  %v3806 = load i64, ptr %slot664, align 8
  %p3807 = inttoptr i64 %v3805 to ptr
  %p3808 = inttoptr i64 %v3806 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3808, ptr %p3807, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3809 = load i64, ptr %slot19, align 8
  %p3810 = inttoptr i64 %v3809 to ptr
  store i32 0, ptr %p3810, align 4, !alias.scope !3, !noalias !4
  %v3811 = load i64, ptr %slot8, align 8
  %p3812 = inttoptr i64 %v3811 to ptr
  store i32 2, ptr %p3812, align 4, !alias.scope !3, !noalias !4
  %v3813 = load i64, ptr %slot20, align 8
  %p3814 = inttoptr i64 %v3813 to ptr
  %ld3815 = load i32, ptr %p3814, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3815, ptr %slot666, align 8
  %v3816 = load i32, ptr %slot666, align 8
  %v3817 = load i64, ptr %slot8, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  store i32 %v3816, ptr %p3818, align 4, !alias.scope !3, !noalias !4
  %v3819 = load i64, ptr %slot7, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  store i32 1, ptr %p3820, align 4, !alias.scope !3, !noalias !4
  %v3821 = load i64, ptr %slot39, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  store i64 0, ptr %p3822, align 8, !alias.scope !3, !noalias !4
  %v3823 = load i64, ptr %slot33, align 8
  %v3824 = load i64, ptr %slot39, align 8
  %p3825 = inttoptr i64 %v3824 to ptr
  store i64 %v3823, ptr %p3825, align 8, !alias.scope !3, !noalias !4
  %v3826 = load i64, ptr %slot39, align 8
  %p3827 = inttoptr i64 %v3826 to ptr
  %ld3828 = load i64, ptr %p3827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3828, ptr %slot667, align 8
  %v3829 = load i64, ptr %slot15, align 8
  %p3830 = inttoptr i64 %v3829 to ptr
  %ld3831 = load i32, ptr %p3830, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3831, ptr %slot668, align 8
  %v3832 = load i64, ptr %slot16, align 8
  %p3833 = inttoptr i64 %v3832 to ptr
  %ld3834 = load i32, ptr %p3833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3834, ptr %slot669, align 8
  %v3835 = load i32, ptr %slot669, align 8
  %op3836 = and i32 %v3835, 24
  store i32 %op3836, ptr %slot669, align 8
  %v3837 = load i32, ptr %slot669, align 8
  %cmp3838 = icmp eq i32 %v3837, 0
  %cv3839 = zext i1 %cmp3838 to i32
  store i32 %cv3839, ptr %slot670, align 8
  %v3840 = load i32, ptr %slot668, align 8
  %v3841 = load i32, ptr %slot670, align 8
  %op3842 = and i32 %v3840, %v3841
  store i32 %op3842, ptr %slot671, align 8
  %v3843 = load i64, ptr %slot52, align 8
  store i64 %v3843, ptr %slot672, align 8
  %v3844 = load i32, ptr %slot671, align 8
  %op3845 = mul i32 %v3844, 4
  store i32 %op3845, ptr %slot673, align 8
  %v3846 = load i32, ptr %slot673, align 8
  %op3847 = or i32 %v3846, 0
  store i32 %op3847, ptr %slot674, align 8
  %v3848 = load i64, ptr %slot24, align 8
  store i64 %v3848, ptr %slot675, align 8
  %v3849 = load i64, ptr %slot51, align 8
  %v3850 = load i64, ptr %slot675, align 8
  %v3851 = load i64, ptr %slot667, align 8
  %v3852 = load i64, ptr %slot672, align 8
  %cv3853 = trunc i64 %v3852 to i32
  %v3854 = load i32, ptr %slot674, align 8
  %call3855 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_publish(i64 %v3849, i64 %v3850, i64 %v3851, i32 %cv3853, i32 %v3854) nomerge, !dbg !152
  store i32 %call3855, ptr %slot676, align 8
  %v3856 = load i32, ptr %slot676, align 8
  %cv3857 = zext i32 %v3856 to i64
  %cond3858 = icmp ne i64 %cv3857, 0
  br i1 %cond3858, label %bb_rcsuccess902, label %bb_rcfailure902
bb_rcfailure902:
  %v3859 = load i64, ptr %slot51, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  %call3861 = call i32 @myl_rc_take_failure(ptr %p3860) nomerge, !dbg !152
  store i32 %call3861, ptr %slot677, align 8
  %v3862 = load i64, ptr %slot1, align 8
  %p3863 = inttoptr i64 %v3862 to ptr
  %v3864 = load i32, ptr %slot677, align 8
  %call3865 = call i32 @myl_qbe_rc_status(ptr %p3863, i32 %v3864) nomerge, !dbg !152
  store i32 %call3865, ptr %slot678, align 8
  br label %bb_failure
bb_rcsuccess902:
  %v3866 = load i32, ptr %slot671, align 8
  %cv3867 = zext i32 %v3866 to i64
  %cond3868 = icmp ne i64 %cv3867, 0
  br i1 %cond3868, label %bb_rchtaken905, label %bb_rchcopied905
bb_rchcopied905:
  %v3869 = load i64, ptr %slot15, align 8
  %p3870 = inttoptr i64 %v3869 to ptr
  %ld3871 = load i32, ptr %p3870, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3871, ptr %slot679, align 8
  %v3872 = load i32, ptr %slot679, align 8
  %cv3873 = zext i32 %v3872 to i64
  %cond3874 = icmp ne i64 %cv3873, 0
  br i1 %cond3874, label %bb_rcslotdrop908, label %bb_rcslotdone908
bb_rcslotdrop908:
  %v3875 = load i64, ptr %slot15, align 8
  %p3876 = inttoptr i64 %v3875 to ptr
  store i32 0, ptr %p3876, align 4, !alias.scope !3, !noalias !4
  %v3877 = load i64, ptr %slot22, align 8
  store i64 %v3877, ptr %slot680, align 8
  %v3878 = load i64, ptr %slot16, align 8
  %p3879 = inttoptr i64 %v3878 to ptr
  %ld3880 = load i32, ptr %p3879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3880, ptr %slot681, align 8
  %v3881 = load i32, ptr %slot681, align 8
  %op3882 = and i32 %v3881, 28
  store i32 %op3882, ptr %slot682, align 8
  %v3883 = load i32, ptr %slot682, align 8
  %cv3884 = zext i32 %v3883 to i64
  %cond3885 = icmp ne i64 %cv3884, 0
  br i1 %cond3885, label %bb_rcslotrole908, label %bb_rcslotowner908
bb_rcslotrole908:
  %v3886 = load i64, ptr %slot51, align 8
  store i64 %v3886, ptr %slot683, align 8
  %v3887 = load i64, ptr %slot683, align 8
  %v3888 = load i64, ptr %slot680, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3887, i64 %v3888) nomerge, !dbg !152
  br label %bb_rcslotdone908
bb_rcslotowner908:
  %v3889 = load i64, ptr %slot51, align 8
  store i64 %v3889, ptr %slot684, align 8
  %v3890 = load i64, ptr %slot684, align 8
  %v3891 = load i64, ptr %slot680, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3890, i64 %v3891) nomerge, !dbg !152
  br label %bb_rcslotdone908
bb_rcslotdone908:
  br label %bb_rchprepared905
bb_rchtaken905:
  %v3892 = load i64, ptr %slot15, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  store i32 0, ptr %p3893, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared905
bb_rchprepared905:
  %v3894 = load i64, ptr %slot20, align 8
  %p3895 = inttoptr i64 %v3894 to ptr
  store i32 2, ptr %p3895, align 4, !alias.scope !3, !noalias !4
  %v3896 = load i64, ptr %slot19, align 8
  %p3897 = inttoptr i64 %v3896 to ptr
  store i32 1, ptr %p3897, align 4, !alias.scope !3, !noalias !4
  %v3898 = load i64, ptr %slot22, align 8
  store i64 %v3898, ptr %slot685, align 8
  %v3899 = load i64, ptr %slot24, align 8
  store i64 %v3899, ptr %slot686, align 8
  %v3900 = load i64, ptr %slot686, align 8
  %v3901 = load i64, ptr %slot685, align 8
  %p3902 = inttoptr i64 %v3900 to ptr
  %p3903 = inttoptr i64 %v3901 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3903, ptr %p3902, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3904 = load i64, ptr %slot16, align 8
  %p3905 = inttoptr i64 %v3904 to ptr
  store i32 2, ptr %p3905, align 4, !alias.scope !3, !noalias !4
  %v3906 = load i64, ptr %slot20, align 8
  %p3907 = inttoptr i64 %v3906 to ptr
  %ld3908 = load i32, ptr %p3907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3908, ptr %slot687, align 8
  %v3909 = load i32, ptr %slot687, align 8
  %v3910 = load i64, ptr %slot16, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  store i32 %v3909, ptr %p3911, align 4, !alias.scope !3, !noalias !4
  %v3912 = load i64, ptr %slot19, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  store i32 0, ptr %p3913, align 4, !alias.scope !3, !noalias !4
  %v3914 = load i64, ptr %slot15, align 8
  %p3915 = inttoptr i64 %v3914 to ptr
  store i32 1, ptr %p3915, align 4, !alias.scope !3, !noalias !4
  %v3916 = load i64, ptr %slot685, align 8
  %v3917 = load i64, ptr %slot39, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  store i64 %v3916, ptr %p3918, align 8, !alias.scope !3, !noalias !4
  %v3919 = load i64, ptr %slot45, align 8
  store i64 %v3919, ptr %slot688, align 8
  %v3920 = load i64, ptr %slot688, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  store i64 0, ptr %p3921, align 8, !alias.scope !3, !noalias !4
  %v3922 = load i64, ptr %slot688, align 8
  %p3924 = inttoptr i64 %v3922 to ptr
  %gep3925 = getelementptr i8, ptr %p3924, i64 8
  %op3923 = ptrtoint ptr %gep3925 to i64
  store i64 %op3923, ptr %slot689, align 8
  %v3926 = load i64, ptr %slot689, align 8
  %p3927 = inttoptr i64 %v3926 to ptr
  store i64 0, ptr %p3927, align 8, !alias.scope !3, !noalias !4
  %v3928 = load i64, ptr %slot688, align 8
  %p3930 = inttoptr i64 %v3928 to ptr
  %gep3931 = getelementptr i8, ptr %p3930, i64 16
  %op3929 = ptrtoint ptr %gep3931 to i64
  store i64 %op3929, ptr %slot690, align 8
  %v3932 = load i64, ptr %slot690, align 8
  %p3933 = inttoptr i64 %v3932 to ptr
  store i64 0, ptr %p3933, align 8, !alias.scope !3, !noalias !4
  %v3934 = load i64, ptr %slot688, align 8
  %p3936 = inttoptr i64 %v3934 to ptr
  %gep3937 = getelementptr i8, ptr %p3936, i64 24
  %op3935 = ptrtoint ptr %gep3937 to i64
  store i64 %op3935, ptr %slot691, align 8
  %v3938 = load i64, ptr %slot691, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  store i64 0, ptr %p3939, align 8, !alias.scope !3, !noalias !4
  %v3940 = load i64, ptr %slot688, align 8
  %p3942 = inttoptr i64 %v3940 to ptr
  %gep3943 = getelementptr i8, ptr %p3942, i64 32
  %op3941 = ptrtoint ptr %gep3943 to i64
  store i64 %op3941, ptr %slot692, align 8
  %v3944 = load i64, ptr %slot692, align 8
  %p3945 = inttoptr i64 %v3944 to ptr
  store i64 0, ptr %p3945, align 8, !alias.scope !3, !noalias !4
  %v3946 = load i64, ptr %slot688, align 8
  %p3948 = inttoptr i64 %v3946 to ptr
  %gep3949 = getelementptr i8, ptr %p3948, i64 40
  %op3947 = ptrtoint ptr %gep3949 to i64
  store i64 %op3947, ptr %slot693, align 8
  %v3950 = load i64, ptr %slot693, align 8
  %p3951 = inttoptr i64 %v3950 to ptr
  store i64 0, ptr %p3951, align 8, !alias.scope !3, !noalias !4
  %v3952 = load i64, ptr %slot688, align 8
  %p3954 = inttoptr i64 %v3952 to ptr
  %gep3955 = getelementptr i8, ptr %p3954, i64 48
  %op3953 = ptrtoint ptr %gep3955 to i64
  store i64 %op3953, ptr %slot694, align 8
  %v3956 = load i64, ptr %slot694, align 8
  %p3957 = inttoptr i64 %v3956 to ptr
  store i64 0, ptr %p3957, align 8, !alias.scope !3, !noalias !4
  %v3958 = load i64, ptr %slot688, align 8
  %p3959 = inttoptr i64 %v3958 to ptr
  store i32 6, ptr %p3959, align 4, !alias.scope !3, !noalias !4
  %v3960 = load i64, ptr %slot21, align 8
  %p3961 = inttoptr i64 %v3960 to ptr
  store i32 1, ptr %p3961, align 4, !alias.scope !3, !noalias !4
  %v3962 = load i64, ptr %slot39, align 8
  %p3963 = inttoptr i64 %v3962 to ptr
  %ld3964 = load i64, ptr %p3963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3964, ptr %slot695, align 8
  %v3965 = load i64, ptr %slot688, align 8
  %p3967 = inttoptr i64 %v3965 to ptr
  %gep3968 = getelementptr i8, ptr %p3967, i64 8
  %op3966 = ptrtoint ptr %gep3968 to i64
  store i64 %op3966, ptr %slot696, align 8
  %v3969 = load i64, ptr %slot52, align 8
  store i64 %v3969, ptr %slot697, align 8
  %v3970 = load i64, ptr %slot39, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  %ld3972 = load i64, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3972, ptr %slot698, align 8
  %v3973 = load i64, ptr %slot24, align 8
  store i64 %v3973, ptr %slot699, align 8
  %v3974 = load i64, ptr %slot52, align 8
  store i64 %v3974, ptr %slot700, align 8
  %v3975 = load i64, ptr %slot698, align 8
  %op3976 = add i64 %v3975, 8
  store i64 %op3976, ptr %slot701, align 8
  %v3977 = load i64, ptr %slot701, align 8
  %p3978 = inttoptr i64 %v3977 to ptr
  %ld3979 = load i64, ptr %p3978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3979, ptr %slot702, align 8
  %v3980 = load i64, ptr %slot702, align 8
  %cmp3981 = icmp ne i64 %v3980, 0
  %cv3982 = zext i1 %cmp3981 to i32
  store i32 %cv3982, ptr %slot703, align 8
  %v3983 = load i32, ptr %slot703, align 8
  %cv3984 = zext i32 %v3983 to i64
  %cond3985 = icmp ne i64 %cv3984, 0
  br i1 %cond3985, label %bb_rcmoveheader944, label %bb_rcmovenext944
bb_rcmoveheader944:
  %v3986 = load i64, ptr %slot702, align 8
  %op3987 = sub i64 %v3986, 16
  store i64 %op3987, ptr %slot704, align 8
  %v3988 = load i64, ptr %slot702, align 8
  %p3989 = inttoptr i64 %v3988 to ptr
  %rgep3990 = getelementptr i8, ptr %p3989, i64 -16
  %ld3991 = load i64, ptr %rgep3990, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3991, ptr %slot705, align 8
  %v3992 = load i64, ptr %slot705, align 8
  %op3993 = and i64 %v3992, 5764607523034234881
  store i64 %op3993, ptr %slot706, align 8
  %v3994 = load i64, ptr %slot706, align 8
  %cmp3995 = icmp ne i64 %v3994, 0
  %cv3996 = zext i1 %cmp3995 to i32
  store i32 %cv3996, ptr %slot707, align 8
  %v3997 = load i32, ptr %slot707, align 8
  %cv3998 = zext i32 %v3997 to i64
  %cond3999 = icmp ne i64 %cv3998, 0
  br i1 %cond3999, label %bb_rcmoveslow941, label %bb_rcmovenext944
bb_rcmovenext944:
  %v4000 = load i64, ptr %slot698, align 8
  %v4001 = load i64, ptr %slot699, align 8
  %p4002 = inttoptr i64 %v4000 to ptr
  %p4003 = inttoptr i64 %v4001 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4003, ptr %p4002, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4004 = load i64, ptr %slot698, align 8
  %p4005 = inttoptr i64 %v4004 to ptr
  store i64 0, ptr %p4005, align 8, !alias.scope !3, !noalias !4
  %v4006 = load i64, ptr %slot698, align 8
  %op4007 = add i64 %v4006, 8
  store i64 %op4007, ptr %slot708, align 8
  %v4008 = load i64, ptr %slot708, align 8
  %p4009 = inttoptr i64 %v4008 to ptr
  store i64 0, ptr %p4009, align 8, !alias.scope !3, !noalias !4
  %v4010 = load i64, ptr %slot698, align 8
  %op4011 = add i64 %v4010, 16
  store i64 %op4011, ptr %slot709, align 8
  %v4012 = load i64, ptr %slot709, align 8
  %p4013 = inttoptr i64 %v4012 to ptr
  store i64 0, ptr %p4013, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved941
bb_rcmoveslow941:
  %v4014 = load i64, ptr %slot51, align 8
  %v4015 = load i64, ptr %slot699, align 8
  %v4016 = load i64, ptr %slot698, align 8
  %v4017 = load i64, ptr %slot700, align 8
  %cv4018 = trunc i64 %v4017 to i32
  %call4019 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v4014, i64 %v4015, i64 %v4016, i32 %cv4018) nomerge, !dbg !154
  store i32 %call4019, ptr %slot710, align 8
  %v4020 = load i32, ptr %slot710, align 8
  %cv4021 = zext i32 %v4020 to i64
  %cond4022 = icmp ne i64 %cv4021, 0
  br i1 %cond4022, label %bb_rcsuccess953, label %bb_rcfailure953
bb_rcfailure953:
  %v4023 = load i64, ptr %slot51, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  %call4025 = call i32 @myl_rc_take_failure(ptr %p4024) nomerge, !dbg !154
  store i32 %call4025, ptr %slot711, align 8
  %v4026 = load i64, ptr %slot1, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  %v4028 = load i32, ptr %slot711, align 8
  %call4029 = call i32 @myl_qbe_rc_status(ptr %p4027, i32 %v4028) nomerge, !dbg !154
  store i32 %call4029, ptr %slot712, align 8
  br label %bb_failure
bb_rcsuccess953:
  br label %bb_rcmoved941
bb_rcmoved941:
  %v4030 = load i64, ptr %slot15, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  store i32 0, ptr %p4031, align 4, !alias.scope !3, !noalias !4
  %v4032 = load i64, ptr %slot20, align 8
  %p4033 = inttoptr i64 %v4032 to ptr
  store i32 2, ptr %p4033, align 4, !alias.scope !3, !noalias !4
  %v4034 = load i64, ptr %slot19, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  store i32 1, ptr %p4035, align 4, !alias.scope !3, !noalias !4
  %v4036 = load i64, ptr %slot24, align 8
  store i64 %v4036, ptr %slot713, align 8
  %v4037 = load i64, ptr %slot713, align 8
  %v4038 = load i64, ptr %slot696, align 8
  %p4039 = inttoptr i64 %v4037 to ptr
  %p4040 = inttoptr i64 %v4038 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4040, ptr %p4039, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4041 = load i64, ptr %slot19, align 8
  %p4042 = inttoptr i64 %v4041 to ptr
  store i32 0, ptr %p4042, align 4, !alias.scope !3, !noalias !4
  %v4043 = load i64, ptr %slot688, align 8
  %v4044 = load i64, ptr %slot39, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  store i64 %v4043, ptr %p4045, align 8, !alias.scope !3, !noalias !4
  %v4046 = load i64, ptr %slot39, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  %ld4048 = load i64, ptr %p4047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4048, ptr %slot714, align 8
  %v4049 = load i64, ptr %slot22, align 8
  store i64 %v4049, ptr %slot715, align 8
  %v4050 = load i64, ptr %slot714, align 8
  %v4051 = load i64, ptr %slot715, align 8
  %p4052 = inttoptr i64 %v4050 to ptr
  %p4053 = inttoptr i64 %v4051 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4053, ptr %p4052, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4054 = load i64, ptr %slot16, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  store i32 2, ptr %p4055, align 4, !alias.scope !3, !noalias !4
  %v4056 = load i64, ptr %slot15, align 8
  %p4057 = inttoptr i64 %v4056 to ptr
  store i32 1, ptr %p4057, align 4, !alias.scope !3, !noalias !4
  %v4058 = load i64, ptr %slot715, align 8
  %v4059 = load i64, ptr %slot39, align 8
  %p4060 = inttoptr i64 %v4059 to ptr
  store i64 %v4058, ptr %p4060, align 8, !alias.scope !3, !noalias !4
  %v4061 = load i64, ptr %slot39, align 8
  %p4062 = inttoptr i64 %v4061 to ptr
  %ld4063 = load i64, ptr %p4062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4063, ptr %slot716, align 8
  %v4064 = load i64, ptr %slot15, align 8
  %p4065 = inttoptr i64 %v4064 to ptr
  %ld4066 = load i32, ptr %p4065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4066, ptr %slot717, align 8
  %v4067 = load i64, ptr %slot16, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  %ld4069 = load i32, ptr %p4068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4069, ptr %slot718, align 8
  %v4070 = load i32, ptr %slot718, align 8
  %op4071 = and i32 %v4070, 24
  store i32 %op4071, ptr %slot718, align 8
  %v4072 = load i32, ptr %slot718, align 8
  %cmp4073 = icmp eq i32 %v4072, 0
  %cv4074 = zext i1 %cmp4073 to i32
  store i32 %cv4074, ptr %slot719, align 8
  %v4075 = load i32, ptr %slot717, align 8
  %v4076 = load i32, ptr %slot719, align 8
  %op4077 = and i32 %v4075, %v4076
  store i32 %op4077, ptr %slot720, align 8
  %v4078 = load i32, ptr %slot720, align 8
  %cv4079 = zext i32 %v4078 to i64
  %cond4080 = icmp ne i64 %cv4079, 0
  br i1 %cond4080, label %bb_rcprivateown972, label %bb_rcprivateloan972
bb_rcprivateown972:
  %v4081 = load i64, ptr %slot24, align 8
  store i64 %v4081, ptr %slot721, align 8
  %v4082 = load i64, ptr %slot52, align 8
  store i64 %v4082, ptr %slot722, align 8
  %v4083 = load i64, ptr %slot51, align 8
  %v4084 = load i64, ptr %slot721, align 8
  %v4085 = load i64, ptr %slot716, align 8
  %v4086 = load i64, ptr %slot722, align 8
  %cv4087 = trunc i64 %v4086 to i32
  %call4088 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v4083, i64 %v4084, i64 %v4085, i32 %cv4087) nomerge, !dbg !156
  store i32 %call4088, ptr %slot723, align 8
  %v4089 = load i32, ptr %slot723, align 8
  %cv4090 = zext i32 %v4089 to i64
  %cond4091 = icmp ne i64 %cv4090, 0
  br i1 %cond4091, label %bb_rcsuccess976, label %bb_rcfailure976
bb_rcfailure976:
  %v4092 = load i64, ptr %slot51, align 8
  %p4093 = inttoptr i64 %v4092 to ptr
  %call4094 = call i32 @myl_rc_take_failure(ptr %p4093) nomerge, !dbg !156
  store i32 %call4094, ptr %slot724, align 8
  %v4095 = load i64, ptr %slot1, align 8
  %p4096 = inttoptr i64 %v4095 to ptr
  %v4097 = load i32, ptr %slot724, align 8
  %call4098 = call i32 @myl_qbe_rc_status(ptr %p4096, i32 %v4097) nomerge, !dbg !156
  store i32 %call4098, ptr %slot725, align 8
  br label %bb_failure
bb_rcsuccess976:
  %v4099 = load i64, ptr %slot15, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  store i32 0, ptr %p4100, align 4, !alias.scope !3, !noalias !4
  %v4101 = load i64, ptr %slot20, align 8
  %p4102 = inttoptr i64 %v4101 to ptr
  store i32 2, ptr %p4102, align 4, !alias.scope !3, !noalias !4
  %v4103 = load i64, ptr %slot19, align 8
  %p4104 = inttoptr i64 %v4103 to ptr
  store i32 1, ptr %p4104, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared972
bb_rcprivateloan972:
  %v4105 = load i64, ptr %slot15, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  %ld4107 = load i32, ptr %p4106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4107, ptr %slot726, align 8
  %v4108 = load i64, ptr %slot16, align 8
  %p4109 = inttoptr i64 %v4108 to ptr
  %ld4110 = load i32, ptr %p4109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4110, ptr %slot727, align 8
  %v4111 = load i32, ptr %slot727, align 8
  %cmp4112 = icmp eq i32 %v4111, 16
  %cv4113 = zext i1 %cmp4112 to i32
  store i32 %cv4113, ptr %slot728, align 8
  %v4114 = load i32, ptr %slot728, align 8
  %v4115 = load i32, ptr %slot726, align 8
  %op4116 = and i32 %v4114, %v4115
  store i32 %op4116, ptr %slot728, align 8
  %v4117 = load i32, ptr %slot728, align 8
  %cv4118 = zext i32 %v4117 to i64
  %cond4119 = icmp ne i64 %cv4118, 0
  br i1 %cond4119, label %bb_rcprivatemove972, label %bb_rcprivatenew972
bb_rcprivatemove972:
  %v4120 = load i64, ptr %slot24, align 8
  store i64 %v4120, ptr %slot729, align 8
  %v4121 = load i64, ptr %slot716, align 8
  %v4122 = load i64, ptr %slot729, align 8
  %p4123 = inttoptr i64 %v4121 to ptr
  %p4124 = inttoptr i64 %v4122 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4124, ptr %p4123, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4125 = load i64, ptr %slot716, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  call void @llvm.memset.p0.i64(ptr %p4126, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !156
  %v4127 = load i64, ptr %slot20, align 8
  %p4128 = inttoptr i64 %v4127 to ptr
  store i32 2, ptr %p4128, align 4, !alias.scope !3, !noalias !4
  %v4129 = load i64, ptr %slot20, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  store i32 16, ptr %p4130, align 4, !alias.scope !3, !noalias !4
  %v4131 = load i64, ptr %slot19, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  store i32 1, ptr %p4132, align 4, !alias.scope !3, !noalias !4
  %v4133 = load i64, ptr %slot15, align 8
  %p4134 = inttoptr i64 %v4133 to ptr
  store i32 0, ptr %p4134, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared972
bb_rcprivatenew972:
  %v4135 = load i64, ptr %slot24, align 8
  store i64 %v4135, ptr %slot730, align 8
  %v4136 = load i64, ptr %slot51, align 8
  %v4137 = load i64, ptr %slot730, align 8
  %v4138 = load i64, ptr %slot716, align 8
  %call4139 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v4136, i64 %v4137, i64 %v4138) nomerge, !dbg !156
  store i32 %call4139, ptr %slot731, align 8
  %v4140 = load i32, ptr %slot731, align 8
  %cv4141 = zext i32 %v4140 to i64
  %cond4142 = icmp ne i64 %cv4141, 0
  br i1 %cond4142, label %bb_rcsuccess994, label %bb_rcfailure994
bb_rcfailure994:
  %v4143 = load i64, ptr %slot51, align 8
  %p4144 = inttoptr i64 %v4143 to ptr
  %call4145 = call i32 @myl_rc_take_failure(ptr %p4144) nomerge, !dbg !156
  store i32 %call4145, ptr %slot732, align 8
  %v4146 = load i64, ptr %slot1, align 8
  %p4147 = inttoptr i64 %v4146 to ptr
  %v4148 = load i32, ptr %slot732, align 8
  %call4149 = call i32 @myl_qbe_rc_status(ptr %p4147, i32 %v4148) nomerge, !dbg !156
  store i32 %call4149, ptr %slot733, align 8
  br label %bb_failure
bb_rcsuccess994:
  %v4150 = load i64, ptr %slot20, align 8
  %p4151 = inttoptr i64 %v4150 to ptr
  store i32 2, ptr %p4151, align 4, !alias.scope !3, !noalias !4
  %v4152 = load i64, ptr %slot20, align 8
  %p4153 = inttoptr i64 %v4152 to ptr
  store i32 16, ptr %p4153, align 4, !alias.scope !3, !noalias !4
  %v4154 = load i64, ptr %slot19, align 8
  %p4155 = inttoptr i64 %v4154 to ptr
  store i32 1, ptr %p4155, align 4, !alias.scope !3, !noalias !4
  %v4156 = load i64, ptr %slot15, align 8
  %p4157 = inttoptr i64 %v4156 to ptr
  %ld4158 = load i32, ptr %p4157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4158, ptr %slot734, align 8
  %v4159 = load i32, ptr %slot734, align 8
  %cv4160 = zext i32 %v4159 to i64
  %cond4161 = icmp ne i64 %cv4160, 0
  br i1 %cond4161, label %bb_rcslotdrop1002, label %bb_rcslotdone1002
bb_rcslotdrop1002:
  %v4162 = load i64, ptr %slot15, align 8
  %p4163 = inttoptr i64 %v4162 to ptr
  store i32 0, ptr %p4163, align 4, !alias.scope !3, !noalias !4
  %v4164 = load i64, ptr %slot22, align 8
  store i64 %v4164, ptr %slot735, align 8
  %v4165 = load i64, ptr %slot16, align 8
  %p4166 = inttoptr i64 %v4165 to ptr
  %ld4167 = load i32, ptr %p4166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4167, ptr %slot736, align 8
  %v4168 = load i32, ptr %slot736, align 8
  %op4169 = and i32 %v4168, 28
  store i32 %op4169, ptr %slot737, align 8
  %v4170 = load i32, ptr %slot737, align 8
  %cv4171 = zext i32 %v4170 to i64
  %cond4172 = icmp ne i64 %cv4171, 0
  br i1 %cond4172, label %bb_rcslotrole1002, label %bb_rcslotowner1002
bb_rcslotrole1002:
  %v4173 = load i64, ptr %slot51, align 8
  store i64 %v4173, ptr %slot738, align 8
  %v4174 = load i64, ptr %slot738, align 8
  %v4175 = load i64, ptr %slot735, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4174, i64 %v4175) nomerge, !dbg !156
  br label %bb_rcslotdone1002
bb_rcslotowner1002:
  %v4176 = load i64, ptr %slot51, align 8
  store i64 %v4176, ptr %slot739, align 8
  %v4177 = load i64, ptr %slot739, align 8
  %v4178 = load i64, ptr %slot735, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4177, i64 %v4178) nomerge, !dbg !156
  br label %bb_rcslotdone1002
bb_rcslotdone1002:
  br label %bb_rcprivateprepared972
bb_rcprivateprepared972:
  %v4179 = load i64, ptr %slot13, align 8
  %p4180 = inttoptr i64 %v4179 to ptr
  %ld4181 = load i32, ptr %p4180, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4181, ptr %slot740, align 8
  %v4182 = load i32, ptr %slot740, align 8
  %cv4183 = zext i32 %v4182 to i64
  %cond4184 = icmp ne i64 %cv4183, 0
  br i1 %cond4184, label %bb_rcslotdrop1012, label %bb_rcslotdone1012
bb_rcslotdrop1012:
  %v4185 = load i64, ptr %slot13, align 8
  %p4186 = inttoptr i64 %v4185 to ptr
  store i32 0, ptr %p4186, align 4, !alias.scope !3, !noalias !4
  %v4187 = load i64, ptr %slot37, align 8
  store i64 %v4187, ptr %slot741, align 8
  %v4188 = load i64, ptr %slot14, align 8
  %p4189 = inttoptr i64 %v4188 to ptr
  %ld4190 = load i32, ptr %p4189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4190, ptr %slot742, align 8
  %v4191 = load i32, ptr %slot742, align 8
  %op4192 = and i32 %v4191, 28
  store i32 %op4192, ptr %slot743, align 8
  %v4193 = load i32, ptr %slot743, align 8
  %cv4194 = zext i32 %v4193 to i64
  %cond4195 = icmp ne i64 %cv4194, 0
  br i1 %cond4195, label %bb_rcslotrole1012, label %bb_rcslotowner1012
bb_rcslotrole1012:
  %v4196 = load i64, ptr %slot51, align 8
  store i64 %v4196, ptr %slot744, align 8
  %v4197 = load i64, ptr %slot744, align 8
  %v4198 = load i64, ptr %slot741, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4197, i64 %v4198) nomerge, !dbg !156
  br label %bb_rcslotdone1012
bb_rcslotowner1012:
  %v4199 = load i64, ptr %slot51, align 8
  store i64 %v4199, ptr %slot745, align 8
  %v4200 = load i64, ptr %slot745, align 8
  %v4201 = load i64, ptr %slot741, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4200, i64 %v4201) nomerge, !dbg !156
  br label %bb_rcslotdone1012
bb_rcslotdone1012:
  %v4202 = load i64, ptr %slot37, align 8
  store i64 %v4202, ptr %slot746, align 8
  %v4203 = load i64, ptr %slot24, align 8
  store i64 %v4203, ptr %slot747, align 8
  %v4204 = load i64, ptr %slot747, align 8
  %v4205 = load i64, ptr %slot746, align 8
  %p4206 = inttoptr i64 %v4204 to ptr
  %p4207 = inttoptr i64 %v4205 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4207, ptr %p4206, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4208 = load i64, ptr %slot19, align 8
  %p4209 = inttoptr i64 %v4208 to ptr
  store i32 0, ptr %p4209, align 4, !alias.scope !3, !noalias !4
  %v4210 = load i64, ptr %slot14, align 8
  %p4211 = inttoptr i64 %v4210 to ptr
  store i32 2, ptr %p4211, align 4, !alias.scope !3, !noalias !4
  %v4212 = load i64, ptr %slot20, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  %ld4214 = load i32, ptr %p4213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4214, ptr %slot748, align 8
  %v4215 = load i32, ptr %slot748, align 8
  %v4216 = load i64, ptr %slot14, align 8
  %p4217 = inttoptr i64 %v4216 to ptr
  store i32 %v4215, ptr %p4217, align 4, !alias.scope !3, !noalias !4
  %v4218 = load i64, ptr %slot13, align 8
  %p4219 = inttoptr i64 %v4218 to ptr
  store i32 1, ptr %p4219, align 4, !alias.scope !3, !noalias !4
  %v4220 = load i64, ptr %slot28, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  %ld4222 = load i64, ptr %p4221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4222, ptr %slot749, align 8
  %v4223 = load i64, ptr %slot749, align 8
  %v4224 = load i64, ptr %slot39, align 8
  %p4225 = inttoptr i64 %v4224 to ptr
  store i64 %v4223, ptr %p4225, align 8, !alias.scope !3, !noalias !4
  %v4226 = load i64, ptr %slot39, align 8
  %p4227 = inttoptr i64 %v4226 to ptr
  %ld4228 = load i64, ptr %p4227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4228, ptr %slot750, align 8
  %v4229 = load i64, ptr %slot750, align 8
  %op4230 = add i64 %v4229, 0
  store i64 %op4230, ptr %slot751, align 8
  %v4231 = load i64, ptr %slot751, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %ld4233 = load i64, ptr %p4232, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4233, ptr %slot752, align 8
  %v4234 = load i64, ptr %slot752, align 8
  %v4235 = load i64, ptr %slot39, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  store i64 %v4234, ptr %p4236, align 8, !alias.scope !3, !noalias !4
  %v4237 = load i64, ptr %slot15, align 8
  %p4238 = inttoptr i64 %v4237 to ptr
  %ld4239 = load i32, ptr %p4238, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4239, ptr %slot753, align 8
  %v4240 = load i32, ptr %slot753, align 8
  %cv4241 = zext i32 %v4240 to i64
  %cond4242 = icmp ne i64 %cv4241, 0
  br i1 %cond4242, label %bb_rcslotdrop1032, label %bb_rcslotdone1032
bb_rcslotdrop1032:
  %v4243 = load i64, ptr %slot15, align 8
  %p4244 = inttoptr i64 %v4243 to ptr
  store i32 0, ptr %p4244, align 4, !alias.scope !3, !noalias !4
  %v4245 = load i64, ptr %slot22, align 8
  store i64 %v4245, ptr %slot754, align 8
  %v4246 = load i64, ptr %slot16, align 8
  %p4247 = inttoptr i64 %v4246 to ptr
  %ld4248 = load i32, ptr %p4247, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4248, ptr %slot755, align 8
  %v4249 = load i32, ptr %slot755, align 8
  %op4250 = and i32 %v4249, 28
  store i32 %op4250, ptr %slot756, align 8
  %v4251 = load i32, ptr %slot756, align 8
  %cv4252 = zext i32 %v4251 to i64
  %cond4253 = icmp ne i64 %cv4252, 0
  br i1 %cond4253, label %bb_rcslotrole1032, label %bb_rcslotowner1032
bb_rcslotrole1032:
  %v4254 = load i64, ptr %slot51, align 8
  store i64 %v4254, ptr %slot757, align 8
  %v4255 = load i64, ptr %slot757, align 8
  %v4256 = load i64, ptr %slot754, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4255, i64 %v4256) nomerge, !dbg !158
  br label %bb_rcslotdone1032
bb_rcslotowner1032:
  %v4257 = load i64, ptr %slot51, align 8
  store i64 %v4257, ptr %slot758, align 8
  %v4258 = load i64, ptr %slot758, align 8
  %v4259 = load i64, ptr %slot754, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4258, i64 %v4259) nomerge, !dbg !158
  br label %bb_rcslotdone1032
bb_rcslotdone1032:
  %v4260 = load i64, ptr %slot39, align 8
  %p4261 = inttoptr i64 %v4260 to ptr
  %ld4262 = load i64, ptr %p4261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4262, ptr %slot759, align 8
  %v4263 = load i64, ptr %slot28, align 8
  %p4264 = inttoptr i64 %v4263 to ptr
  %ld4265 = load i64, ptr %p4264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4265, ptr %slot760, align 8
  %v4266 = load i64, ptr %slot15, align 8
  %p4267 = inttoptr i64 %v4266 to ptr
  %ld4268 = load i32, ptr %p4267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4268, ptr %slot761, align 8
  %v4269 = load i32, ptr %slot761, align 8
  %cv4270 = zext i32 %v4269 to i64
  %cond4271 = icmp ne i64 %cv4270, 0
  br i1 %cond4271, label %bb_rcslotdrop1044, label %bb_rcslotdone1044
bb_rcslotdrop1044:
  %v4272 = load i64, ptr %slot15, align 8
  %p4273 = inttoptr i64 %v4272 to ptr
  store i32 0, ptr %p4273, align 4, !alias.scope !3, !noalias !4
  %v4274 = load i64, ptr %slot22, align 8
  store i64 %v4274, ptr %slot762, align 8
  %v4275 = load i64, ptr %slot16, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  %ld4277 = load i32, ptr %p4276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4277, ptr %slot763, align 8
  %v4278 = load i32, ptr %slot763, align 8
  %op4279 = and i32 %v4278, 28
  store i32 %op4279, ptr %slot764, align 8
  %v4280 = load i32, ptr %slot764, align 8
  %cv4281 = zext i32 %v4280 to i64
  %cond4282 = icmp ne i64 %cv4281, 0
  br i1 %cond4282, label %bb_rcslotrole1044, label %bb_rcslotowner1044
bb_rcslotrole1044:
  %v4283 = load i64, ptr %slot51, align 8
  store i64 %v4283, ptr %slot765, align 8
  %v4284 = load i64, ptr %slot762, align 8
  %p4285 = inttoptr i64 %v4284 to ptr
  %ld4286 = load i64, ptr %p4285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4286, ptr %slot766, align 8
  %v4287 = load i64, ptr %slot766, align 8
  %cmp4288 = icmp ne i64 %v4287, 0
  %cv4289 = zext i1 %cmp4288 to i32
  store i32 %cv4289, ptr %slot767, align 8
  %v4290 = load i32, ptr %slot767, align 8
  %cv4291 = zext i32 %v4290 to i64
  %cond4292 = icmp ne i64 %cv4291, 0
  br i1 %cond4292, label %bb_rcgnn1060, label %bb_rcgdone1060
bb_rcgnn1060:
  %v4293 = load i64, ptr %slot766, align 8
  %op4294 = sub i64 %v4293, 16
  store i64 %op4294, ptr %slot768, align 8
  %v4295 = load i64, ptr %slot766, align 8
  %p4296 = inttoptr i64 %v4295 to ptr
  %rgep4297 = getelementptr i8, ptr %p4296, i64 -16
  %ld4298 = load i64, ptr %rgep4297, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4298, ptr %slot769, align 8
  %v4299 = load i64, ptr %slot769, align 8
  %op4300 = and i64 %v4299, 4611686018427387906
  store i64 %op4300, ptr %slot770, align 8
  %v4301 = load i64, ptr %slot770, align 8
  %cmp4302 = icmp ne i64 %v4301, 0
  %cv4303 = zext i1 %cmp4302 to i32
  store i32 %cv4303, ptr %slot771, align 8
  %v4304 = load i32, ptr %slot771, align 8
  %cv4305 = zext i32 %v4304 to i64
  %cond4306 = icmp ne i64 %cv4305, 0
  br i1 %cond4306, label %bb_rcgclear1060, label %bb_rcgcounted1060
bb_rcgcounted1060:
  %v4307 = load i64, ptr %slot766, align 8
  %op4308 = sub i64 %v4307, 24
  store i64 %op4308, ptr %slot772, align 8
  %v4309 = load i64, ptr %slot766, align 8
  %p4310 = inttoptr i64 %v4309 to ptr
  %rgep4311 = getelementptr i8, ptr %p4310, i64 -24
  %ld4312 = load i64, ptr %rgep4311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4312, ptr %slot773, align 8
  %v4313 = load i64, ptr %slot773, align 8
  %op4314 = sub i64 %v4313, 1
  store i64 %op4314, ptr %slot774, align 8
  %v4315 = load i64, ptr %slot774, align 8
  %cmp4316 = icmp eq i64 %v4315, 0
  %cv4317 = zext i1 %cmp4316 to i32
  store i32 %cv4317, ptr %slot775, align 8
  %v4318 = load i32, ptr %slot775, align 8
  %cv4319 = zext i32 %v4318 to i64
  %cond4320 = icmp ne i64 %cv4319, 0
  br i1 %cond4320, label %bb_rcglast1060, label %bb_rcgdec1060
bb_rcglast1060:
  %v4321 = load i64, ptr %slot766, align 8
  %op4322 = sub i64 %v4321, 32
  store i64 %op4322, ptr %slot776, align 8
  %v4323 = load i64, ptr %slot766, align 8
  %p4324 = inttoptr i64 %v4323 to ptr
  %rgep4325 = getelementptr i8, ptr %p4324, i64 -32
  %ld4326 = load i64, ptr %rgep4325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4326, ptr %slot777, align 8
  %v4327 = load i64, ptr %slot777, align 8
  %cmp4328 = icmp ne i64 %v4327, 0
  %cv4329 = zext i1 %cmp4328 to i32
  store i32 %cv4329, ptr %slot778, align 8
  %v4330 = load i32, ptr %slot778, align 8
  %cv4331 = zext i32 %v4330 to i64
  %cond4332 = icmp ne i64 %cv4331, 0
  br i1 %cond4332, label %bb_rcgdec1060, label %bb_rcgslow1060
bb_rcgslow1060:
  %v4333 = load i64, ptr %slot765, align 8
  %v4334 = load i64, ptr %slot762, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v4333, i64 %v4334) nomerge, !dbg !160
  br label %bb_rcgdone1060
bb_rcgdec1060:
  %v4335 = load i64, ptr %slot774, align 8
  %v4336 = load i64, ptr %slot766, align 8
  %p4337 = inttoptr i64 %v4336 to ptr
  %rgep4338 = getelementptr i8, ptr %p4337, i64 -24
  store i64 %v4335, ptr %rgep4338, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1060
bb_rcgclear1060:
  %v4339 = load i64, ptr %slot762, align 8
  %p4340 = inttoptr i64 %v4339 to ptr
  store i64 0, ptr %p4340, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1060
bb_rcgdone1060:
  br label %bb_rcslotdone1044
bb_rcslotowner1044:
  %v4341 = load i64, ptr %slot51, align 8
  store i64 %v4341, ptr %slot779, align 8
  %v4342 = load i64, ptr %slot762, align 8
  %p4343 = inttoptr i64 %v4342 to ptr
  %ld4344 = load i64, ptr %p4343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4344, ptr %slot780, align 8
  %v4345 = load i64, ptr %slot780, align 8
  %cmp4346 = icmp ne i64 %v4345, 0
  %cv4347 = zext i1 %cmp4346 to i32
  store i32 %cv4347, ptr %slot781, align 8
  %v4348 = load i32, ptr %slot781, align 8
  %cv4349 = zext i32 %v4348 to i64
  %cond4350 = icmp ne i64 %cv4349, 0
  br i1 %cond4350, label %bb_rcgnn1075, label %bb_rcgdone1075
bb_rcgnn1075:
  %v4351 = load i64, ptr %slot780, align 8
  %op4352 = sub i64 %v4351, 16
  store i64 %op4352, ptr %slot782, align 8
  %v4353 = load i64, ptr %slot780, align 8
  %p4354 = inttoptr i64 %v4353 to ptr
  %rgep4355 = getelementptr i8, ptr %p4354, i64 -16
  %ld4356 = load i64, ptr %rgep4355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4356, ptr %slot783, align 8
  %v4357 = load i64, ptr %slot783, align 8
  %op4358 = and i64 %v4357, 4611686018427387906
  store i64 %op4358, ptr %slot784, align 8
  %v4359 = load i64, ptr %slot784, align 8
  %cmp4360 = icmp ne i64 %v4359, 0
  %cv4361 = zext i1 %cmp4360 to i32
  store i32 %cv4361, ptr %slot785, align 8
  %v4362 = load i32, ptr %slot785, align 8
  %cv4363 = zext i32 %v4362 to i64
  %cond4364 = icmp ne i64 %cv4363, 0
  br i1 %cond4364, label %bb_rcgclear1075, label %bb_rcgcounted1075
bb_rcgcounted1075:
  %v4365 = load i64, ptr %slot780, align 8
  %op4366 = sub i64 %v4365, 32
  store i64 %op4366, ptr %slot786, align 8
  %v4367 = load i64, ptr %slot780, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  %rgep4369 = getelementptr i8, ptr %p4368, i64 -32
  %ld4370 = load i64, ptr %rgep4369, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4370, ptr %slot787, align 8
  %v4371 = load i64, ptr %slot787, align 8
  %op4372 = sub i64 %v4371, 1
  store i64 %op4372, ptr %slot788, align 8
  %v4373 = load i64, ptr %slot788, align 8
  %cmp4374 = icmp eq i64 %v4373, 0
  %cv4375 = zext i1 %cmp4374 to i32
  store i32 %cv4375, ptr %slot789, align 8
  %v4376 = load i32, ptr %slot789, align 8
  %cv4377 = zext i32 %v4376 to i64
  %cond4378 = icmp ne i64 %cv4377, 0
  br i1 %cond4378, label %bb_rcglast1075, label %bb_rcgdec1075
bb_rcglast1075:
  %v4379 = load i64, ptr %slot780, align 8
  %op4380 = sub i64 %v4379, 24
  store i64 %op4380, ptr %slot790, align 8
  %v4381 = load i64, ptr %slot780, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  %rgep4383 = getelementptr i8, ptr %p4382, i64 -24
  %ld4384 = load i64, ptr %rgep4383, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4384, ptr %slot791, align 8
  %v4385 = load i64, ptr %slot791, align 8
  %cmp4386 = icmp ne i64 %v4385, 0
  %cv4387 = zext i1 %cmp4386 to i32
  store i32 %cv4387, ptr %slot792, align 8
  %v4388 = load i32, ptr %slot792, align 8
  %cv4389 = zext i32 %v4388 to i64
  %cond4390 = icmp ne i64 %cv4389, 0
  br i1 %cond4390, label %bb_rcgdec1075, label %bb_rcgslow1075
bb_rcgslow1075:
  %v4391 = load i64, ptr %slot779, align 8
  %v4392 = load i64, ptr %slot762, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v4391, i64 %v4392) nomerge, !dbg !160
  br label %bb_rcgdone1075
bb_rcgdec1075:
  %v4393 = load i64, ptr %slot788, align 8
  %v4394 = load i64, ptr %slot780, align 8
  %p4395 = inttoptr i64 %v4394 to ptr
  %rgep4396 = getelementptr i8, ptr %p4395, i64 -32
  store i64 %v4393, ptr %rgep4396, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1075
bb_rcgclear1075:
  %v4397 = load i64, ptr %slot762, align 8
  %p4398 = inttoptr i64 %v4397 to ptr
  store i64 0, ptr %p4398, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1075
bb_rcgdone1075:
  br label %bb_rcslotdone1044
bb_rcslotdone1044:
  %v4399 = load i64, ptr %slot760, align 8
  %op4400 = add i64 %v4399, 0
  store i64 %op4400, ptr %slot793, align 8
  store i64 0, ptr %slot794, align 8
  %v4401 = load i64, ptr %slot793, align 8
  %p4402 = inttoptr i64 %v4401 to ptr
  %ld4403 = load i64, ptr %p4402, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4403, ptr %slot795, align 8
  %v4404 = load i64, ptr %slot795, align 8
  %cmp4405 = icmp ne i64 %v4404, 0
  %cv4406 = zext i1 %cmp4405 to i32
  store i32 %cv4406, ptr %slot796, align 8
  %v4407 = load i32, ptr %slot796, align 8
  %cv4408 = zext i32 %v4407 to i64
  %cond4409 = icmp ne i64 %cv4408, 0
  br i1 %cond4409, label %bb_rcguniquenn1081, label %bb_rcgunique1081
bb_rcguniquenn1081:
  %v4410 = load i64, ptr %slot795, align 8
  %op4411 = sub i64 %v4410, 16
  store i64 %op4411, ptr %slot797, align 8
  %v4412 = load i64, ptr %slot795, align 8
  %p4413 = inttoptr i64 %v4412 to ptr
  %rgep4414 = getelementptr i8, ptr %p4413, i64 -16
  %ld4415 = load i64, ptr %rgep4414, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4415, ptr %slot798, align 8
  %v4416 = load i64, ptr %slot798, align 8
  %op4417 = and i64 %v4416, 6917529027641081858
  store i64 %op4417, ptr %slot799, align 8
  %v4418 = load i64, ptr %slot799, align 8
  %cmp4419 = icmp ne i64 %v4418, 0
  %cv4420 = zext i1 %cmp4419 to i32
  store i32 %cv4420, ptr %slot800, align 8
  %v4421 = load i32, ptr %slot800, align 8
  %cv4422 = zext i32 %v4421 to i64
  %cond4423 = icmp ne i64 %cv4422, 0
  br i1 %cond4423, label %bb_rcguniqueslow1081, label %bb_rcguniquecount1081
bb_rcguniquecount1081:
  %v4424 = load i64, ptr %slot795, align 8
  %op4425 = sub i64 %v4424, 32
  store i64 %op4425, ptr %slot801, align 8
  %v4426 = load i64, ptr %slot795, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  %rgep4428 = getelementptr i8, ptr %p4427, i64 -32
  %ld4429 = load i64, ptr %rgep4428, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4429, ptr %slot802, align 8
  %v4430 = load i64, ptr %slot802, align 8
  %cmp4431 = icmp ult i64 %v4430, 2
  %cv4432 = zext i1 %cmp4431 to i32
  store i32 %cv4432, ptr %slot803, align 8
  %v4433 = load i32, ptr %slot803, align 8
  %cv4434 = zext i32 %v4433 to i64
  %cond4435 = icmp ne i64 %cv4434, 0
  br i1 %cond4435, label %bb_rcgunique1081, label %bb_rcguniqueslow1081
bb_rcguniqueslow1081:
  %v4436 = load i64, ptr %slot1, align 8
  %p4437 = inttoptr i64 %v4436 to ptr
  %p4438 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v4439 = load i64, ptr %slot793, align 8
  %p4440 = inttoptr i64 %v4439 to ptr
  %v4441 = load i64, ptr %slot794, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  %call4443 = call i32 @myl_qbe_rc_unique_field(ptr %p4437, ptr %p4438, ptr %p4440, ptr %p4442) nomerge, !dbg !160
  store i32 %call4443, ptr %slot804, align 8
  %v4444 = load i32, ptr %slot804, align 8
  %cv4445 = zext i32 %v4444 to i64
  %cond4446 = icmp ne i64 %cv4445, 0
  br i1 %cond4446, label %bb_rcunique1091, label %bb_failure
bb_rcunique1091:
  br label %bb_rcgunique1081
bb_rcgunique1081:
  %v4447 = load i64, ptr %slot793, align 8
  %p4448 = inttoptr i64 %v4447 to ptr
  %ld4449 = load i64, ptr %p4448, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4449, ptr %slot805, align 8
  %v4450 = load i64, ptr %slot805, align 8
  %v4451 = load i64, ptr %slot39, align 8
  %p4452 = inttoptr i64 %v4451 to ptr
  store i64 %v4450, ptr %p4452, align 8, !alias.scope !3, !noalias !4
  %v4453 = load i64, ptr %slot39, align 8
  %p4454 = inttoptr i64 %v4453 to ptr
  %ld4455 = load i64, ptr %p4454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4455, ptr %slot806, align 8
  %v4456 = load i64, ptr %slot15, align 8
  %p4457 = inttoptr i64 %v4456 to ptr
  %ld4458 = load i32, ptr %p4457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4458, ptr %slot807, align 8
  %v4459 = load i32, ptr %slot807, align 8
  %cv4460 = zext i32 %v4459 to i64
  %cond4461 = icmp ne i64 %cv4460, 0
  br i1 %cond4461, label %bb_rcslotdrop1096, label %bb_rcslotdone1096
bb_rcslotdrop1096:
  %v4462 = load i64, ptr %slot15, align 8
  %p4463 = inttoptr i64 %v4462 to ptr
  store i32 0, ptr %p4463, align 4, !alias.scope !3, !noalias !4
  %v4464 = load i64, ptr %slot22, align 8
  store i64 %v4464, ptr %slot808, align 8
  %v4465 = load i64, ptr %slot16, align 8
  %p4466 = inttoptr i64 %v4465 to ptr
  %ld4467 = load i32, ptr %p4466, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4467, ptr %slot809, align 8
  %v4468 = load i32, ptr %slot809, align 8
  %op4469 = and i32 %v4468, 28
  store i32 %op4469, ptr %slot810, align 8
  %v4470 = load i32, ptr %slot810, align 8
  %cv4471 = zext i32 %v4470 to i64
  %cond4472 = icmp ne i64 %cv4471, 0
  br i1 %cond4472, label %bb_rcslotrole1096, label %bb_rcslotowner1096
bb_rcslotrole1096:
  %v4473 = load i64, ptr %slot51, align 8
  store i64 %v4473, ptr %slot811, align 8
  %v4474 = load i64, ptr %slot808, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  %ld4476 = load i64, ptr %p4475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4476, ptr %slot812, align 8
  %v4477 = load i64, ptr %slot812, align 8
  %cmp4478 = icmp ne i64 %v4477, 0
  %cv4479 = zext i1 %cmp4478 to i32
  store i32 %cv4479, ptr %slot813, align 8
  %v4480 = load i32, ptr %slot813, align 8
  %cv4481 = zext i32 %v4480 to i64
  %cond4482 = icmp ne i64 %cv4481, 0
  br i1 %cond4482, label %bb_rcgnn1112, label %bb_rcgdone1112
bb_rcgnn1112:
  %v4483 = load i64, ptr %slot812, align 8
  %op4484 = sub i64 %v4483, 16
  store i64 %op4484, ptr %slot814, align 8
  %v4485 = load i64, ptr %slot812, align 8
  %p4486 = inttoptr i64 %v4485 to ptr
  %rgep4487 = getelementptr i8, ptr %p4486, i64 -16
  %ld4488 = load i64, ptr %rgep4487, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4488, ptr %slot815, align 8
  %v4489 = load i64, ptr %slot815, align 8
  %op4490 = and i64 %v4489, 4611686018427387906
  store i64 %op4490, ptr %slot816, align 8
  %v4491 = load i64, ptr %slot816, align 8
  %cmp4492 = icmp ne i64 %v4491, 0
  %cv4493 = zext i1 %cmp4492 to i32
  store i32 %cv4493, ptr %slot817, align 8
  %v4494 = load i32, ptr %slot817, align 8
  %cv4495 = zext i32 %v4494 to i64
  %cond4496 = icmp ne i64 %cv4495, 0
  br i1 %cond4496, label %bb_rcgclear1112, label %bb_rcgcounted1112
bb_rcgcounted1112:
  %v4497 = load i64, ptr %slot812, align 8
  %op4498 = sub i64 %v4497, 24
  store i64 %op4498, ptr %slot818, align 8
  %v4499 = load i64, ptr %slot812, align 8
  %p4500 = inttoptr i64 %v4499 to ptr
  %rgep4501 = getelementptr i8, ptr %p4500, i64 -24
  %ld4502 = load i64, ptr %rgep4501, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4502, ptr %slot819, align 8
  %v4503 = load i64, ptr %slot819, align 8
  %op4504 = sub i64 %v4503, 1
  store i64 %op4504, ptr %slot820, align 8
  %v4505 = load i64, ptr %slot820, align 8
  %cmp4506 = icmp eq i64 %v4505, 0
  %cv4507 = zext i1 %cmp4506 to i32
  store i32 %cv4507, ptr %slot821, align 8
  %v4508 = load i32, ptr %slot821, align 8
  %cv4509 = zext i32 %v4508 to i64
  %cond4510 = icmp ne i64 %cv4509, 0
  br i1 %cond4510, label %bb_rcglast1112, label %bb_rcgdec1112
bb_rcglast1112:
  %v4511 = load i64, ptr %slot812, align 8
  %op4512 = sub i64 %v4511, 32
  store i64 %op4512, ptr %slot822, align 8
  %v4513 = load i64, ptr %slot812, align 8
  %p4514 = inttoptr i64 %v4513 to ptr
  %rgep4515 = getelementptr i8, ptr %p4514, i64 -32
  %ld4516 = load i64, ptr %rgep4515, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4516, ptr %slot823, align 8
  %v4517 = load i64, ptr %slot823, align 8
  %cmp4518 = icmp ne i64 %v4517, 0
  %cv4519 = zext i1 %cmp4518 to i32
  store i32 %cv4519, ptr %slot824, align 8
  %v4520 = load i32, ptr %slot824, align 8
  %cv4521 = zext i32 %v4520 to i64
  %cond4522 = icmp ne i64 %cv4521, 0
  br i1 %cond4522, label %bb_rcgdec1112, label %bb_rcgslow1112
bb_rcgslow1112:
  %v4523 = load i64, ptr %slot811, align 8
  %v4524 = load i64, ptr %slot808, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v4523, i64 %v4524) nomerge, !dbg !160
  br label %bb_rcgdone1112
bb_rcgdec1112:
  %v4525 = load i64, ptr %slot820, align 8
  %v4526 = load i64, ptr %slot812, align 8
  %p4527 = inttoptr i64 %v4526 to ptr
  %rgep4528 = getelementptr i8, ptr %p4527, i64 -24
  store i64 %v4525, ptr %rgep4528, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1112
bb_rcgclear1112:
  %v4529 = load i64, ptr %slot808, align 8
  %p4530 = inttoptr i64 %v4529 to ptr
  store i64 0, ptr %p4530, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1112
bb_rcgdone1112:
  br label %bb_rcslotdone1096
bb_rcslotowner1096:
  %v4531 = load i64, ptr %slot51, align 8
  store i64 %v4531, ptr %slot825, align 8
  %v4532 = load i64, ptr %slot808, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  %ld4534 = load i64, ptr %p4533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4534, ptr %slot826, align 8
  %v4535 = load i64, ptr %slot826, align 8
  %cmp4536 = icmp ne i64 %v4535, 0
  %cv4537 = zext i1 %cmp4536 to i32
  store i32 %cv4537, ptr %slot827, align 8
  %v4538 = load i32, ptr %slot827, align 8
  %cv4539 = zext i32 %v4538 to i64
  %cond4540 = icmp ne i64 %cv4539, 0
  br i1 %cond4540, label %bb_rcgnn1127, label %bb_rcgdone1127
bb_rcgnn1127:
  %v4541 = load i64, ptr %slot826, align 8
  %op4542 = sub i64 %v4541, 16
  store i64 %op4542, ptr %slot828, align 8
  %v4543 = load i64, ptr %slot826, align 8
  %p4544 = inttoptr i64 %v4543 to ptr
  %rgep4545 = getelementptr i8, ptr %p4544, i64 -16
  %ld4546 = load i64, ptr %rgep4545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4546, ptr %slot829, align 8
  %v4547 = load i64, ptr %slot829, align 8
  %op4548 = and i64 %v4547, 4611686018427387906
  store i64 %op4548, ptr %slot830, align 8
  %v4549 = load i64, ptr %slot830, align 8
  %cmp4550 = icmp ne i64 %v4549, 0
  %cv4551 = zext i1 %cmp4550 to i32
  store i32 %cv4551, ptr %slot831, align 8
  %v4552 = load i32, ptr %slot831, align 8
  %cv4553 = zext i32 %v4552 to i64
  %cond4554 = icmp ne i64 %cv4553, 0
  br i1 %cond4554, label %bb_rcgclear1127, label %bb_rcgcounted1127
bb_rcgcounted1127:
  %v4555 = load i64, ptr %slot826, align 8
  %op4556 = sub i64 %v4555, 32
  store i64 %op4556, ptr %slot832, align 8
  %v4557 = load i64, ptr %slot826, align 8
  %p4558 = inttoptr i64 %v4557 to ptr
  %rgep4559 = getelementptr i8, ptr %p4558, i64 -32
  %ld4560 = load i64, ptr %rgep4559, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4560, ptr %slot833, align 8
  %v4561 = load i64, ptr %slot833, align 8
  %op4562 = sub i64 %v4561, 1
  store i64 %op4562, ptr %slot834, align 8
  %v4563 = load i64, ptr %slot834, align 8
  %cmp4564 = icmp eq i64 %v4563, 0
  %cv4565 = zext i1 %cmp4564 to i32
  store i32 %cv4565, ptr %slot835, align 8
  %v4566 = load i32, ptr %slot835, align 8
  %cv4567 = zext i32 %v4566 to i64
  %cond4568 = icmp ne i64 %cv4567, 0
  br i1 %cond4568, label %bb_rcglast1127, label %bb_rcgdec1127
bb_rcglast1127:
  %v4569 = load i64, ptr %slot826, align 8
  %op4570 = sub i64 %v4569, 24
  store i64 %op4570, ptr %slot836, align 8
  %v4571 = load i64, ptr %slot826, align 8
  %p4572 = inttoptr i64 %v4571 to ptr
  %rgep4573 = getelementptr i8, ptr %p4572, i64 -24
  %ld4574 = load i64, ptr %rgep4573, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4574, ptr %slot837, align 8
  %v4575 = load i64, ptr %slot837, align 8
  %cmp4576 = icmp ne i64 %v4575, 0
  %cv4577 = zext i1 %cmp4576 to i32
  store i32 %cv4577, ptr %slot838, align 8
  %v4578 = load i32, ptr %slot838, align 8
  %cv4579 = zext i32 %v4578 to i64
  %cond4580 = icmp ne i64 %cv4579, 0
  br i1 %cond4580, label %bb_rcgdec1127, label %bb_rcgslow1127
bb_rcgslow1127:
  %v4581 = load i64, ptr %slot825, align 8
  %v4582 = load i64, ptr %slot808, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v4581, i64 %v4582) nomerge, !dbg !160
  br label %bb_rcgdone1127
bb_rcgdec1127:
  %v4583 = load i64, ptr %slot834, align 8
  %v4584 = load i64, ptr %slot826, align 8
  %p4585 = inttoptr i64 %v4584 to ptr
  %rgep4586 = getelementptr i8, ptr %p4585, i64 -32
  store i64 %v4583, ptr %rgep4586, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1127
bb_rcgclear1127:
  %v4587 = load i64, ptr %slot808, align 8
  %p4588 = inttoptr i64 %v4587 to ptr
  store i64 0, ptr %p4588, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1127
bb_rcgdone1127:
  br label %bb_rcslotdone1096
bb_rcslotdone1096:
  %v4589 = load i64, ptr %slot806, align 8
  %v4590 = load i64, ptr %slot36, align 8
  %p4591 = inttoptr i64 %v4590 to ptr
  store i64 %v4589, ptr %p4591, align 8, !alias.scope !3, !noalias !4
  %v4592 = load i64, ptr %slot32, align 8
  %p4593 = inttoptr i64 %v4592 to ptr
  %ld4594 = load i64, ptr %p4593, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4594, ptr %slot839, align 8
  %v4595 = load i64, ptr %slot839, align 8
  %v4596 = load i64, ptr %slot39, align 8
  %p4597 = inttoptr i64 %v4596 to ptr
  store i64 %v4595, ptr %p4597, align 8, !alias.scope !3, !noalias !4
  %v4598 = load i64, ptr %slot39, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %ld4600 = load i64, ptr %p4599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4600, ptr %slot840, align 8
  %v4601 = load i64, ptr %slot840, align 8
  %v4602 = load i64, ptr %slot38, align 8
  %p4603 = inttoptr i64 %v4602 to ptr
  store i64 %v4601, ptr %p4603, align 8, !alias.scope !3, !noalias !4
  %v4604 = load i64, ptr %slot38, align 8
  %p4605 = inttoptr i64 %v4604 to ptr
  %ld4606 = load i64, ptr %p4605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4606, ptr %slot841, align 8
  %v4607 = load i64, ptr %slot841, align 8
  %v4608 = load i64, ptr %slot39, align 8
  %p4609 = inttoptr i64 %v4608 to ptr
  store i64 %v4607, ptr %p4609, align 8, !alias.scope !3, !noalias !4
  %v4610 = load i64, ptr %slot40, align 8
  %p4611 = inttoptr i64 %v4610 to ptr
  store i64 0, ptr %p4611, align 8, !alias.scope !3, !noalias !4
  %v4612 = load i64, ptr %slot40, align 8
  %p4613 = inttoptr i64 %v4612 to ptr
  %ld4614 = load i64, ptr %p4613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4614, ptr %slot842, align 8
  %v4615 = load i64, ptr %slot39, align 8
  %p4616 = inttoptr i64 %v4615 to ptr
  %ld4617 = load i64, ptr %p4616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4617, ptr %slot843, align 8
  %v4618 = load i64, ptr %slot843, align 8
  %v4619 = load i64, ptr %slot842, align 8
  %cmp4620 = icmp slt i64 %v4618, %v4619
  %cv4621 = zext i1 %cmp4620 to i64
  store i64 %cv4621, ptr %slot844, align 8
  %v4622 = load i64, ptr %slot844, align 8
  %v4623 = load i64, ptr %slot39, align 8
  %p4624 = inttoptr i64 %v4623 to ptr
  store i64 %v4622, ptr %p4624, align 8, !alias.scope !3, !noalias !4
  %v4625 = load i64, ptr %slot39, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  %ld4627 = load i64, ptr %p4626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4627, ptr %slot845, align 8
  %v4628 = load i64, ptr %slot845, align 8
  %cond4629 = icmp ne i64 %v4628, 0
  br i1 %cond4629, label %bb_next1175, label %bb_i61
bb_next1175:
  %v4630 = load i64, ptr %slot36, align 8
  %p4631 = inttoptr i64 %v4630 to ptr
  %ld4632 = load i64, ptr %p4631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4632, ptr %slot846, align 8
  %v4633 = load i64, ptr %slot846, align 8
  %op4634 = add i64 %v4633, 0
  store i64 %op4634, ptr %slot847, align 8
  %v4635 = load i64, ptr %slot847, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  %ld4637 = load i64, ptr %p4636, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4637, ptr %slot848, align 8
  %v4638 = load i64, ptr %slot848, align 8
  %v4639 = load i64, ptr %slot39, align 8
  %p4640 = inttoptr i64 %v4639 to ptr
  store i64 %v4638, ptr %p4640, align 8, !alias.scope !3, !noalias !4
  %v4641 = load i64, ptr %slot39, align 8
  %p4642 = inttoptr i64 %v4641 to ptr
  %ld4643 = load i64, ptr %p4642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4643, ptr %slot849, align 8
  %v4644 = load i64, ptr %slot849, align 8
  %cmp4645 = icmp ugt i64 %v4644, 9223372036854775807
  %cv4646 = zext i1 %cmp4645 to i64
  store i64 %cv4646, ptr %slot850, align 8
  %v4647 = load i64, ptr %slot850, align 8
  %cond4648 = icmp ne i64 %v4647, 0
  br i1 %cond4648, label %bb_cast_overflow1180, label %bb_cast_ok1180
bb_cast_overflow1180:
  %v4649 = load i64, ptr %slot1, align 8
  %p4650 = inttoptr i64 %v4649 to ptr
  %v4651 = load i64, ptr %slot849, align 8
  call void @myl_qbe_fail_cast(ptr %p4650, i64 %v4651, i64 320) nomerge, !dbg !162
  unreachable
bb_cast_ok1180:
  %v4652 = load i64, ptr %slot849, align 8
  %v4653 = load i64, ptr %slot39, align 8
  %p4654 = inttoptr i64 %v4653 to ptr
  store i64 %v4652, ptr %p4654, align 8, !alias.scope !3, !noalias !4
  %v4655 = load i64, ptr %slot38, align 8
  %p4656 = inttoptr i64 %v4655 to ptr
  %ld4657 = load i64, ptr %p4656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4657, ptr %slot851, align 8
  %v4658 = load i64, ptr %slot851, align 8
  %v4659 = load i64, ptr %slot40, align 8
  %p4660 = inttoptr i64 %v4659 to ptr
  store i64 %v4658, ptr %p4660, align 8, !alias.scope !3, !noalias !4
  %v4661 = load i64, ptr %slot40, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %ld4663 = load i64, ptr %p4662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4663, ptr %slot852, align 8
  %v4664 = load i64, ptr %slot39, align 8
  %p4665 = inttoptr i64 %v4664 to ptr
  %ld4666 = load i64, ptr %p4665, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4666, ptr %slot853, align 8
  %v4667 = load i64, ptr %slot853, align 8
  %v4668 = load i64, ptr %slot852, align 8
  %ovpair4670 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4667, i64 %v4668)
  %op4669 = extractvalue { i64, i1 } %ovpair4670, 0
  %ov4671 = extractvalue { i64, i1 } %ovpair4670, 1
  store i64 %op4669, ptr %slot854, align 8
  %v4672 = load i64, ptr %slot853, align 8
  %v4673 = load i64, ptr %slot854, align 8
  %op4674 = xor i64 %v4672, %v4673
  store i64 %op4674, ptr %slot855, align 8
  %v4675 = load i64, ptr %slot852, align 8
  %v4676 = load i64, ptr %slot854, align 8
  %op4677 = xor i64 %v4675, %v4676
  store i64 %op4677, ptr %slot856, align 8
  %v4678 = load i64, ptr %slot855, align 8
  %v4679 = load i64, ptr %slot856, align 8
  %op4680 = and i64 %v4678, %v4679
  store i64 %op4680, ptr %slot857, align 8
  %cv4681 = zext i1 %ov4671 to i64
  store i64 %cv4681, ptr %slot858, align 8
  %v4682 = load i64, ptr %slot858, align 8
  %cond4683 = icmp ne i64 %v4682, 0
  br i1 %cond4683, label %bb_overflow1184, label %bb_checked1184
bb_overflow1184:
  %v4684 = load i64, ptr %slot1, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  %v4686 = load i64, ptr %slot853, align 8
  %v4687 = load i64, ptr %slot852, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4685, i64 0, i64 %v4686, i64 %v4687, i64 64) nomerge, !dbg !164
  unreachable
bb_checked1184:
  %v4688 = load i64, ptr %slot854, align 8
  %v4689 = load i64, ptr %slot39, align 8
  %p4690 = inttoptr i64 %v4689 to ptr
  store i64 %v4688, ptr %p4690, align 8, !alias.scope !3, !noalias !4
  %v4691 = load i64, ptr %slot39, align 8
  %p4692 = inttoptr i64 %v4691 to ptr
  %ld4693 = load i64, ptr %p4692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4693, ptr %slot859, align 8
  %v4694 = load i64, ptr %slot859, align 8
  %v4695 = load i64, ptr %slot38, align 8
  %p4696 = inttoptr i64 %v4695 to ptr
  store i64 %v4694, ptr %p4696, align 8, !alias.scope !3, !noalias !4
  br label %bb_i61
bb_i61:
  %v4697 = load i64, ptr %slot38, align 8
  %p4698 = inttoptr i64 %v4697 to ptr
  %ld4699 = load i64, ptr %p4698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4699, ptr %slot860, align 8
  %v4700 = load i64, ptr %slot860, align 8
  %v4701 = load i64, ptr %slot39, align 8
  %p4702 = inttoptr i64 %v4701 to ptr
  store i64 %v4700, ptr %p4702, align 8, !alias.scope !3, !noalias !4
  %v4703 = load i64, ptr %slot37, align 8
  %v4704 = load i64, ptr %slot46, align 8
  %p4705 = inttoptr i64 %v4703 to ptr
  %p4706 = inttoptr i64 %v4704 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4706, ptr %p4705, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4707 = load i64, ptr %slot46, align 8
  %v4708 = load i64, ptr %slot40, align 8
  %p4709 = inttoptr i64 %v4708 to ptr
  store i64 %v4707, ptr %p4709, align 8, !alias.scope !3, !noalias !4
  %v4710 = load i64, ptr %slot36, align 8
  %p4711 = inttoptr i64 %v4710 to ptr
  %ld4712 = load i64, ptr %p4711, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4712, ptr %slot861, align 8
  %v4713 = load i64, ptr %slot40, align 8
  %p4714 = inttoptr i64 %v4713 to ptr
  %ld4715 = load i64, ptr %p4714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4715, ptr %slot862, align 8
  %v4716 = load i64, ptr %slot39, align 8
  %p4717 = inttoptr i64 %v4716 to ptr
  %ld4718 = load i64, ptr %p4717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4718, ptr %slot863, align 8
  %v4719 = load i64, ptr %slot861, align 8
  %p4720 = inttoptr i64 %v4719 to ptr
  %ld4721 = load i64, ptr %p4720, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4721, ptr %slot864, align 8
  %v4722 = load i64, ptr %slot863, align 8
  %v4723 = load i64, ptr %slot864, align 8
  %cmp4724 = icmp ult i64 %v4722, %v4723
  %cv4725 = zext i1 %cmp4724 to i64
  store i64 %cv4725, ptr %slot865, align 8
  %v4726 = load i64, ptr %slot865, align 8
  %cond4727 = icmp ne i64 %v4726, 0
  br i1 %cond4727, label %bb_success1197, label %bb_failed1197
bb_failed1197:
  %v4728 = load i64, ptr %slot1, align 8
  %p4729 = inttoptr i64 %v4728 to ptr
  %v4730 = load i64, ptr %slot863, align 8
  %v4731 = load i64, ptr %slot864, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p4729, i64 %v4730, i64 %v4731) nomerge, !dbg !166
  unreachable
bb_success1197:
  %v4732 = load i64, ptr %slot40, align 8
  %p4733 = inttoptr i64 %v4732 to ptr
  %ld4734 = load i64, ptr %p4733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4734, ptr %slot866, align 8
  %v4735 = load i64, ptr %slot51, align 8
  %v4736 = load i64, ptr %slot861, align 8
  %v4737 = load i64, ptr %slot863, align 8
  %v4738 = load i64, ptr %slot866, align 8
  %call4739 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v4735, i64 %v4736, i64 %v4737, i64 %v4738) nomerge, !dbg !166
  store i32 %call4739, ptr %slot867, align 8
  %v4740 = load i32, ptr %slot867, align 8
  %cv4741 = zext i32 %v4740 to i64
  %cond4742 = icmp ne i64 %cv4741, 0
  br i1 %cond4742, label %bb_success1200, label %bb_failed1200
bb_failed1200:
  %v4743 = load i64, ptr %slot1, align 8
  %p4744 = inttoptr i64 %v4743 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4744) nomerge, !dbg !166
  unreachable
bb_success1200:
  %v4745 = load i64, ptr %slot39, align 8
  %p4746 = inttoptr i64 %v4745 to ptr
  store i64 0, ptr %p4746, align 8, !alias.scope !3, !noalias !4
  %v4747 = load i64, ptr %slot17, align 8
  %p4748 = inttoptr i64 %v4747 to ptr
  %ld4749 = load i32, ptr %p4748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4749, ptr %slot868, align 8
  %v4750 = load i32, ptr %slot868, align 8
  %cv4751 = zext i32 %v4750 to i64
  %cond4752 = icmp ne i64 %cv4751, 0
  br i1 %cond4752, label %bb_rcslotdrop1203, label %bb_rcslotdone1203
bb_rcslotdrop1203:
  %v4753 = load i64, ptr %slot17, align 8
  %p4754 = inttoptr i64 %v4753 to ptr
  store i32 0, ptr %p4754, align 4, !alias.scope !3, !noalias !4
  %v4755 = load i64, ptr %slot23, align 8
  store i64 %v4755, ptr %slot869, align 8
  %v4756 = load i64, ptr %slot18, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  %ld4758 = load i32, ptr %p4757, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4758, ptr %slot870, align 8
  %v4759 = load i32, ptr %slot870, align 8
  %op4760 = and i32 %v4759, 28
  store i32 %op4760, ptr %slot871, align 8
  %v4761 = load i32, ptr %slot871, align 8
  %cv4762 = zext i32 %v4761 to i64
  %cond4763 = icmp ne i64 %cv4762, 0
  br i1 %cond4763, label %bb_rcslotrole1203, label %bb_rcslotowner1203
bb_rcslotrole1203:
  %v4764 = load i64, ptr %slot51, align 8
  store i64 %v4764, ptr %slot872, align 8
  %v4765 = load i64, ptr %slot872, align 8
  %v4766 = load i64, ptr %slot869, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4765, i64 %v4766) nomerge, !dbg !166
  br label %bb_rcslotdone1203
bb_rcslotowner1203:
  %v4767 = load i64, ptr %slot51, align 8
  store i64 %v4767, ptr %slot873, align 8
  %v4768 = load i64, ptr %slot873, align 8
  %v4769 = load i64, ptr %slot869, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4768, i64 %v4769) nomerge, !dbg !166
  br label %bb_rcslotdone1203
bb_rcslotdone1203:
  %v4770 = load i64, ptr %slot28, align 8
  %p4771 = inttoptr i64 %v4770 to ptr
  %ld4772 = load i64, ptr %p4771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4772, ptr %slot874, align 8
  %v4773 = load i64, ptr %slot874, align 8
  %v4774 = load i64, ptr %slot39, align 8
  %p4775 = inttoptr i64 %v4774 to ptr
  store i64 %v4773, ptr %p4775, align 8, !alias.scope !3, !noalias !4
  %v4776 = load i64, ptr %slot39, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %ld4778 = load i64, ptr %p4777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4778, ptr %slot875, align 8
  %v4779 = load i64, ptr %slot1, align 8
  %v4780 = load i64, ptr %slot875, align 8
  %call4781 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v4779, i64 %v4780) nomerge, !dbg !168
  store { i64, i64 } %call4781, ptr %callresult877, align 8
  %addr4782 = ptrtoint ptr %callresult877 to i64
  store i64 %addr4782, ptr %slot876, align 8
  %v4783 = load i64, ptr %slot876, align 8
  %v4784 = load i64, ptr %slot39, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  store i64 %v4783, ptr %p4785, align 8, !alias.scope !3, !noalias !4
  %v4786 = load i64, ptr %slot15, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  %ld4788 = load i32, ptr %p4787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4788, ptr %slot878, align 8
  %v4789 = load i32, ptr %slot878, align 8
  %cv4790 = zext i32 %v4789 to i64
  %cond4791 = icmp ne i64 %cv4790, 0
  br i1 %cond4791, label %bb_rcslotdrop1215, label %bb_rcslotdone1215
bb_rcslotdrop1215:
  %v4792 = load i64, ptr %slot15, align 8
  %p4793 = inttoptr i64 %v4792 to ptr
  store i32 0, ptr %p4793, align 4, !alias.scope !3, !noalias !4
  %v4794 = load i64, ptr %slot22, align 8
  store i64 %v4794, ptr %slot879, align 8
  %v4795 = load i64, ptr %slot16, align 8
  %p4796 = inttoptr i64 %v4795 to ptr
  %ld4797 = load i32, ptr %p4796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4797, ptr %slot880, align 8
  %v4798 = load i32, ptr %slot880, align 8
  %op4799 = and i32 %v4798, 28
  store i32 %op4799, ptr %slot881, align 8
  %v4800 = load i32, ptr %slot881, align 8
  %cv4801 = zext i32 %v4800 to i64
  %cond4802 = icmp ne i64 %cv4801, 0
  br i1 %cond4802, label %bb_rcslotrole1215, label %bb_rcslotowner1215
bb_rcslotrole1215:
  %v4803 = load i64, ptr %slot51, align 8
  store i64 %v4803, ptr %slot882, align 8
  %v4804 = load i64, ptr %slot882, align 8
  %v4805 = load i64, ptr %slot879, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4804, i64 %v4805) nomerge, !dbg !168
  br label %bb_rcslotdone1215
bb_rcslotowner1215:
  %v4806 = load i64, ptr %slot51, align 8
  store i64 %v4806, ptr %slot883, align 8
  %v4807 = load i64, ptr %slot883, align 8
  %v4808 = load i64, ptr %slot879, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4807, i64 %v4808) nomerge, !dbg !168
  br label %bb_rcslotdone1215
bb_rcslotdone1215:
  %v4809 = load i64, ptr %slot39, align 8
  %p4810 = inttoptr i64 %v4809 to ptr
  store i64 0, ptr %p4810, align 8, !alias.scope !3, !noalias !4
  %v4811 = load i64, ptr %slot39, align 8
  %p4812 = inttoptr i64 %v4811 to ptr
  %ld4813 = load i64, ptr %p4812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4813, ptr %slot884, align 8
  %v4814 = load i64, ptr %slot25, align 8
  %p4816 = inttoptr i64 %v4814 to ptr
  %gep4817 = getelementptr i8, ptr %p4816, i64 24
  %op4815 = ptrtoint ptr %gep4817 to i64
  store i64 %op4815, ptr %slot885, align 8
  %v4818 = load i64, ptr %slot885, align 8
  %p4819 = inttoptr i64 %v4818 to ptr
  %ld4820 = load i32, ptr %p4819, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4820, ptr %slot886, align 8
  %v4821 = load i32, ptr %slot886, align 8
  %cv4822 = zext i32 %v4821 to i64
  %cond4823 = icmp ne i64 %cv4822, 0
  br i1 %cond4823, label %bb_rcscopesopen1225, label %bb_rcscopesclosed1225
bb_rcscopesopen1225:
  %v4824 = load i64, ptr %slot27, align 8
  %p4826 = inttoptr i64 %v4824 to ptr
  %gep4827 = getelementptr i8, ptr %p4826, i64 0
  %op4825 = ptrtoint ptr %gep4827 to i64
  store i64 %op4825, ptr %slot887, align 8
  %v4828 = load i64, ptr %slot25, align 8
  %v4829 = load i64, ptr %slot887, align 8
  %p4830 = inttoptr i64 %v4829 to ptr
  store i64 %v4828, ptr %p4830, align 8, !alias.scope !3, !noalias !4
  %v4831 = load i64, ptr %slot1, align 8
  %p4832 = inttoptr i64 %v4831 to ptr
  %v4833 = load i64, ptr %slot27, align 8
  %p4834 = inttoptr i64 %v4833 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p4832, ptr %p4834, i64 1) nomerge, !dbg !170
  br label %bb_rcscopesclosed1225
bb_rcscopesclosed1225:
  %v4835 = load i64, ptr %slot15, align 8
  %p4836 = inttoptr i64 %v4835 to ptr
  %ld4837 = load i32, ptr %p4836, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4837, ptr %slot888, align 8
  %v4838 = load i32, ptr %slot888, align 8
  %cv4839 = zext i32 %v4838 to i64
  %cond4840 = icmp ne i64 %cv4839, 0
  br i1 %cond4840, label %bb_rcslotdrop1229, label %bb_rcslotdone1229
bb_rcslotdrop1229:
  %v4841 = load i64, ptr %slot15, align 8
  %p4842 = inttoptr i64 %v4841 to ptr
  store i32 0, ptr %p4842, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1229
bb_rcslotdone1229:
  %v4843 = load i64, ptr %slot13, align 8
  %p4844 = inttoptr i64 %v4843 to ptr
  %ld4845 = load i32, ptr %p4844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4845, ptr %slot889, align 8
  %v4846 = load i32, ptr %slot889, align 8
  %cv4847 = zext i32 %v4846 to i64
  %cond4848 = icmp ne i64 %cv4847, 0
  br i1 %cond4848, label %bb_rcslotdrop1232, label %bb_rcslotdone1232
bb_rcslotdrop1232:
  %v4849 = load i64, ptr %slot13, align 8
  %p4850 = inttoptr i64 %v4849 to ptr
  store i32 0, ptr %p4850, align 4, !alias.scope !3, !noalias !4
  %v4851 = load i64, ptr %slot37, align 8
  store i64 %v4851, ptr %slot890, align 8
  %v4852 = load i64, ptr %slot14, align 8
  %p4853 = inttoptr i64 %v4852 to ptr
  %ld4854 = load i32, ptr %p4853, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4854, ptr %slot891, align 8
  %v4855 = load i32, ptr %slot891, align 8
  %op4856 = and i32 %v4855, 28
  store i32 %op4856, ptr %slot892, align 8
  %v4857 = load i32, ptr %slot892, align 8
  %cv4858 = zext i32 %v4857 to i64
  %cond4859 = icmp ne i64 %cv4858, 0
  br i1 %cond4859, label %bb_rcslotrole1232, label %bb_rcslotowner1232
bb_rcslotrole1232:
  %v4860 = load i64, ptr %slot51, align 8
  store i64 %v4860, ptr %slot893, align 8
  %v4861 = load i64, ptr %slot893, align 8
  %v4862 = load i64, ptr %slot890, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4861, i64 %v4862) nomerge, !dbg !170
  br label %bb_rcslotdone1232
bb_rcslotowner1232:
  %v4863 = load i64, ptr %slot51, align 8
  store i64 %v4863, ptr %slot894, align 8
  %v4864 = load i64, ptr %slot894, align 8
  %v4865 = load i64, ptr %slot890, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4864, i64 %v4865) nomerge, !dbg !170
  br label %bb_rcslotdone1232
bb_rcslotdone1232:
  %v4866 = load i64, ptr %slot11, align 8
  %p4867 = inttoptr i64 %v4866 to ptr
  %ld4868 = load i32, ptr %p4867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4868, ptr %slot895, align 8
  %v4869 = load i32, ptr %slot895, align 8
  %cv4870 = zext i32 %v4869 to i64
  %cond4871 = icmp ne i64 %cv4870, 0
  br i1 %cond4871, label %bb_rcslotdrop1278, label %bb_rcslotdone1278
bb_rcslotdrop1278:
  %v4872 = load i64, ptr %slot11, align 8
  %p4873 = inttoptr i64 %v4872 to ptr
  store i32 0, ptr %p4873, align 4, !alias.scope !3, !noalias !4
  %v4874 = load i64, ptr %slot35, align 8
  store i64 %v4874, ptr %slot896, align 8
  %v4875 = load i64, ptr %slot12, align 8
  %p4876 = inttoptr i64 %v4875 to ptr
  %ld4877 = load i32, ptr %p4876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4877, ptr %slot897, align 8
  %v4878 = load i32, ptr %slot897, align 8
  %op4879 = and i32 %v4878, 28
  store i32 %op4879, ptr %slot898, align 8
  %v4880 = load i32, ptr %slot898, align 8
  %cv4881 = zext i32 %v4880 to i64
  %cond4882 = icmp ne i64 %cv4881, 0
  br i1 %cond4882, label %bb_rcslotrole1278, label %bb_rcslotowner1278
bb_rcslotrole1278:
  %v4883 = load i64, ptr %slot51, align 8
  store i64 %v4883, ptr %slot899, align 8
  %v4884 = load i64, ptr %slot899, align 8
  %v4885 = load i64, ptr %slot896, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4884, i64 %v4885) nomerge, !dbg !170
  br label %bb_rcslotdone1278
bb_rcslotowner1278:
  %v4886 = load i64, ptr %slot51, align 8
  store i64 %v4886, ptr %slot900, align 8
  %v4887 = load i64, ptr %slot900, align 8
  %v4888 = load i64, ptr %slot896, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4887, i64 %v4888) nomerge, !dbg !170
  br label %bb_rcslotdone1278
bb_rcslotdone1278:
  %v4889 = load i64, ptr %slot9, align 8
  %p4890 = inttoptr i64 %v4889 to ptr
  %ld4891 = load i32, ptr %p4890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4891, ptr %slot901, align 8
  %v4892 = load i32, ptr %slot901, align 8
  %cv4893 = zext i32 %v4892 to i64
  %cond4894 = icmp ne i64 %cv4893, 0
  br i1 %cond4894, label %bb_rcslotdrop1287, label %bb_rcslotdone1287
bb_rcslotdrop1287:
  %v4895 = load i64, ptr %slot9, align 8
  %p4896 = inttoptr i64 %v4895 to ptr
  store i32 0, ptr %p4896, align 4, !alias.scope !3, !noalias !4
  %v4897 = load i64, ptr %slot34, align 8
  store i64 %v4897, ptr %slot902, align 8
  %v4898 = load i64, ptr %slot10, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  %ld4900 = load i32, ptr %p4899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4900, ptr %slot903, align 8
  %v4901 = load i32, ptr %slot903, align 8
  %op4902 = and i32 %v4901, 28
  store i32 %op4902, ptr %slot904, align 8
  %v4903 = load i32, ptr %slot904, align 8
  %cv4904 = zext i32 %v4903 to i64
  %cond4905 = icmp ne i64 %cv4904, 0
  br i1 %cond4905, label %bb_rcslotrole1287, label %bb_rcslotowner1287
bb_rcslotrole1287:
  %v4906 = load i64, ptr %slot51, align 8
  store i64 %v4906, ptr %slot905, align 8
  %v4907 = load i64, ptr %slot905, align 8
  %v4908 = load i64, ptr %slot902, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v4907, i64 %v4908) nomerge, !dbg !170
  br label %bb_rcslotdone1287
bb_rcslotowner1287:
  %v4909 = load i64, ptr %slot51, align 8
  store i64 %v4909, ptr %slot906, align 8
  %v4910 = load i64, ptr %slot906, align 8
  %v4911 = load i64, ptr %slot902, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v4910, i64 %v4911) nomerge, !dbg !170
  br label %bb_rcslotdone1287
bb_rcslotdone1287:
  %v4912 = load i64, ptr %slot7, align 8
  %p4913 = inttoptr i64 %v4912 to ptr
  %ld4914 = load i32, ptr %p4913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4914, ptr %slot907, align 8
  %v4915 = load i32, ptr %slot907, align 8
  %cv4916 = zext i32 %v4915 to i64
  %cond4917 = icmp ne i64 %cv4916, 0
  br i1 %cond4917, label %bb_rcslotdrop1296, label %bb_rcslotdone1296
bb_rcslotdrop1296:
  %v4918 = load i64, ptr %slot7, align 8
  %p4919 = inttoptr i64 %v4918 to ptr
  store i32 0, ptr %p4919, align 4, !alias.scope !3, !noalias !4
  %v4920 = load i64, ptr %slot33, align 8
  store i64 %v4920, ptr %slot908, align 8
  %v4921 = load i64, ptr %slot8, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  %ld4923 = load i32, ptr %p4922, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4923, ptr %slot909, align 8
  %v4924 = load i32, ptr %slot909, align 8
  %op4925 = and i32 %v4924, 28
  store i32 %op4925, ptr %slot910, align 8
  %v4926 = load i32, ptr %slot910, align 8
  %cv4927 = zext i32 %v4926 to i64
  %cond4928 = icmp ne i64 %cv4927, 0
  br i1 %cond4928, label %bb_rcslotrole1296, label %bb_rcslotowner1296
bb_rcslotrole1296:
  %v4929 = load i64, ptr %slot51, align 8
  store i64 %v4929, ptr %slot911, align 8
  %v4930 = load i64, ptr %slot911, align 8
  %v4931 = load i64, ptr %slot908, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v4930, i64 %v4931) nomerge, !dbg !170
  br label %bb_rcslotdone1296
bb_rcslotowner1296:
  %v4932 = load i64, ptr %slot51, align 8
  store i64 %v4932, ptr %slot912, align 8
  %v4933 = load i64, ptr %slot912, align 8
  %v4934 = load i64, ptr %slot908, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v4933, i64 %v4934) nomerge, !dbg !170
  br label %bb_rcslotdone1296
bb_rcslotdone1296:
  %v4935 = load i64, ptr %slot5, align 8
  %p4936 = inttoptr i64 %v4935 to ptr
  %ld4937 = load i32, ptr %p4936, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4937, ptr %slot913, align 8
  %v4938 = load i32, ptr %slot913, align 8
  %cv4939 = zext i32 %v4938 to i64
  %cond4940 = icmp ne i64 %cv4939, 0
  br i1 %cond4940, label %bb_rcslotdrop1305, label %bb_rcslotdone1305
bb_rcslotdrop1305:
  %v4941 = load i64, ptr %slot5, align 8
  %p4942 = inttoptr i64 %v4941 to ptr
  store i32 0, ptr %p4942, align 4, !alias.scope !3, !noalias !4
  %v4943 = load i64, ptr %slot31, align 8
  store i64 %v4943, ptr %slot914, align 8
  %v4944 = load i64, ptr %slot6, align 8
  %p4945 = inttoptr i64 %v4944 to ptr
  %ld4946 = load i32, ptr %p4945, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4946, ptr %slot915, align 8
  %v4947 = load i32, ptr %slot915, align 8
  %op4948 = and i32 %v4947, 28
  store i32 %op4948, ptr %slot916, align 8
  %v4949 = load i32, ptr %slot916, align 8
  %cv4950 = zext i32 %v4949 to i64
  %cond4951 = icmp ne i64 %cv4950, 0
  br i1 %cond4951, label %bb_rcslotrole1305, label %bb_rcslotowner1305
bb_rcslotrole1305:
  %v4952 = load i64, ptr %slot51, align 8
  store i64 %v4952, ptr %slot917, align 8
  %v4953 = load i64, ptr %slot917, align 8
  %v4954 = load i64, ptr %slot914, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4953, i64 %v4954) nomerge, !dbg !170
  br label %bb_rcslotdone1305
bb_rcslotowner1305:
  %v4955 = load i64, ptr %slot51, align 8
  store i64 %v4955, ptr %slot918, align 8
  %v4956 = load i64, ptr %slot918, align 8
  %v4957 = load i64, ptr %slot914, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4956, i64 %v4957) nomerge, !dbg !170
  br label %bb_rcslotdone1305
bb_rcslotdone1305:
  %v4958 = load i64, ptr %slot884, align 8
  ret i64 %v4958
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare i64 @myl_f_72cbd8b3ebb02b19d0384fb691061873bba08de6d559f9babec1767adabac444(i64, i64, i64, i64, i64)
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare i64 @myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d(i64, i64)
declare i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64, i64, i64)
declare i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64, i64)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64, i64, i64)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64, i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_drop(i64, i64)
declare void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8a26e9a4615ca34682c5764acec261356b4869f23d43f0849ec12dd016904162", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8a26e9a4615ca34682c5764acec261356b4869f23d43f0849ec12dd016904162", linkageName: "myl_f_8a26e9a4615ca34682c5764acec261356b4869f23d43f0849ec12dd016904162", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 794192270789751950, i64 0, !"myl_f_8a26e9a4615ca34682c5764acec261356b4869f23d43f0849ec12dd016904162"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!124 = !DILocation(line: 11, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!126 = !DILocation(line: 16, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!130 = !DILocation(line: 20, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!132 = !DILocation(line: 24, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!134 = !DILocation(line: 25, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!136 = !DILocation(line: 29, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!138 = !DILocation(line: 30, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!140 = !DILocation(line: 32, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!142 = !DILocation(line: 34, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!144 = !DILocation(line: 36, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!146 = !DILocation(line: 39, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!148 = !DILocation(line: 40, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!150 = !DILocation(line: 41, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!152 = !DILocation(line: 45, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!154 = !DILocation(line: 46, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!156 = !DILocation(line: 47, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!158 = !DILocation(line: 49, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!160 = !DILocation(line: 50, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!162 = !DILocation(line: 58, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!164 = !DILocation(line: 60, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!166 = !DILocation(line: 65, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!168 = !DILocation(line: 68, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!170 = !DILocation(line: 71, column: 0, scope: !171)
